create Package Body      Pkg_Budget Is
  Procedure_Brk_Exp Exception; --调用过程失败异常
  Ipt_Param_Err_Exp Exception; --输入参数错误异常
  Sql_Not_Found_Exp Exception; --变更数据无效异常
  Record_Not_Exist_Exp Exception; --记录不存在异常
  Check_Data_Exp    Exception; --对应虚拟预算检查失败异常
  v_y       Constant Varchar2(1) := 'Y'; --是
  v_n       Constant Varchar2(1) := 'N'; --否
  v_Nl      Constant Varchar2(2) := Chr(13) || Chr(10); --换行
  v_Null    Constant Varchar2(4) := 'NULL'; --空值
  v_Success Constant Varchar2(7) := 'SUCCESS'; --成功返回

  v_Chk_Bgt_Change_Flag Varchar2(1) Not Null := v_y; --操作预算时是否检查备用金并同步财务处理

 /*===============================================================
  * Program Name:   p_Synchro_Budget_Frame
  * Purpose     :   同步预算框架
   ===============================================================*/
  procedure p_Synchro_Budget_Frame(p_Data_Flow_Id In Number, --预算流ID
                                   --主体ID
                                   p_Entity_Id In Number,
                                   --用户ID
                                   p_User_Id In Varchar2,
                                   --返回结果：成功返回"SUCCESS"，失败返回原因
                                   p_Result Out Varchar2) Is

    v_Pp Constant Varchar2(80) := '同步预算框架失败，';

    --预算层次游标
    Cursor c_Bgt_Smt Is
      Select budget_segment_level Bgt_Smt_Level,
             budget_segment_pre_level Bgt_Smt_Pre_Level,
             Decode(Nvl(control_flag, v_Null), v_n, -1, 1) If_Bgt_Cntrl,
             Replace(Replace(Replace(Upper(Budget_Segment_Sql),
                                     ':P_ENTITY_ID',
                                     To_Char(p_Entity_Id)),
                             ':P_USER_ID',
                             To_Char(p_User_Id)),
                     ':P_DATA_FLOW_ID',
                     To_Char(p_Data_Flow_Id)) Bgt_Smt_Sql
        From t_pol_budget_segment
       Where Data_Flow_Id = p_Data_Flow_Id
       Order By Bgt_Smt_Level;

    --预算层次数组
    Type t_Bgt_Smt Is Record(
      Bgt_Smt_Used  Number,
      Cursor_Handle Number,
      Cursor_Exenum Number,
      Pre_Level     Number,
      If_Bgt_Cntrl  Number,
      Sql_Add_Where Varchar2(40),
      Bgt_Smt_Sql   Varchar2(4000));
    Type t_Bgt_Smts Is Varray(6) Of t_Bgt_Smt;
    r_Smts t_Bgt_Smts;

    --预算单元数组
    Type t_Bgt_Ttl Is Record(
      Budget_Tree_Id Number,
      Entity_Id       Number,
      Data_Id         Number,
      Data_Code       Varchar2(100),
      Data_Name       Varchar2(100));
    Type t_Bgt_Ttls Is Varray(6) Of t_Bgt_Ttl;
    r_Ttls t_Bgt_Ttls;

    v_Budget_Type Number; --预算类型
    v_Budget_Segment_Levels Number; --预算体系层次

  Begin
    --建保存点
    Savepoint Sp_Synchro_Budget_Frame;

    --检查参数
    if p_Data_Flow_Id is null or p_Entity_Id is null or p_User_Id is null then
      p_Result := '输入参数分别为(' || To_Char(p_Entity_Id) || ',' ||
                  To_Char(p_Data_Flow_Id) || ',' || To_Char(p_User_Id) || ')';
      Raise Ipt_Param_Err_Exp;
    end if;

    --检查流程定义
    p_Result := '检查流程定义(' || To_Char(p_Data_Flow_Id) || ')';
    Select Budget_Segment_Levels, Budget_Type
      Into v_Budget_Segment_Levels, v_Budget_Type
      From t_pol_budget_data_flow
     Where Data_Flow_Id = p_Data_Flow_Id
       And Budget_Segment_Levels = Trunc(Budget_Segment_Levels)
       And Budget_Segment_Levels Between 1 And 6;

    --检查层次数量
    p_Result := '检查层次数量(' || To_Char(p_Data_Flow_Id) || ')';
    Select v_Success
      Into p_Result
      From (Select Nvl(Sum(1), 0) Budget_Segment_Levels
              From t_pol_budget_segment
             Where Data_Flow_Id = p_Data_Flow_Id)
     Where Budget_Segment_Levels = v_Budget_Segment_Levels;

    --检查层次定义(主要检查Budget_Segment_Level和Budget_Segment_Pre_Level)
    p_Result := '检查层次定义(' || To_Char(p_Data_Flow_Id) || ')';
    Select v_Success
      Into p_Result
      From Dual
     Where Not Exists
     (Select Null
              From t_pol_budget_segment
             Where Data_Flow_Id = p_Data_Flow_Id
               And Not (Budget_Segment_Level = Trunc(Budget_Segment_Level) And
                    Budget_Segment_Level Between 1 And
                    v_Budget_Segment_Levels And
                    Budget_Segment_Pre_Level =
                    Trunc(Budget_Segment_Pre_Level) And
                    Budget_Segment_Pre_Level Between 0 And
                    (v_Budget_Segment_Levels - 1) And
                    Budget_Segment_Level > Budget_Segment_Pre_Level));

    --预算层次数组、节点数组初始化
    r_Smts := t_Bgt_Smts(Null, Null, Null, Null, Null, Null);
    r_Ttls := t_Bgt_Ttls(Null, Null, Null, Null, Null, Null);

    For i In 1 .. 6 Loop
      r_Smts(i).Bgt_Smt_Used := -1;
      r_Smts(i).Cursor_Handle := Null;
      r_Smts(i).Cursor_Exenum := Null;
      r_Smts(i).Pre_Level := 0;
      r_Smts(i).If_Bgt_Cntrl := 1;
      r_Smts(i).Sql_Add_Where := Null;
      r_Smts(i).Bgt_Smt_Sql := Null;

      r_Ttls(i).Budget_Tree_Id := Null;
      r_Ttls(i).Entity_Id := Null;
      r_Ttls(i).Data_Id := Null;
      r_Ttls(i).Data_Code := Null;
      r_Ttls(i).Data_Name := Null;
    End Loop;

    For r_Bgt_Smt In c_Bgt_Smt Loop
      Select 1,
             r_Bgt_Smt.Bgt_Smt_Pre_Level,
             r_Bgt_Smt.If_Bgt_Cntrl,
             r_Bgt_Smt.Bgt_Smt_Sql
        Into r_Smts(r_Bgt_Smt.Bgt_Smt_Level).Bgt_Smt_Used,
             r_Smts(r_Bgt_Smt.Bgt_Smt_Level).Pre_Level,
             r_Smts(r_Bgt_Smt.Bgt_Smt_Level).If_Bgt_Cntrl,
             r_Smts(r_Bgt_Smt.Bgt_Smt_Level).Bgt_Smt_Sql
        From Dual;
    End Loop;

    --一层游标
    If Nvl(r_Smts(1).Bgt_Smt_Used, -1) > 0 Then
      --动态游标
      p_Result := '动态SQL查询1';
      r_Smts(1).Cursor_Handle := Dbms_Sql.Open_Cursor;
      Dbms_Sql.Parse(r_Smts(1).Cursor_Handle, r_Smts(1).Bgt_Smt_Sql, Dbms_Sql.Native);
      Dbms_Sql.Define_Column(r_Smts(1).Cursor_Handle, 1, r_Ttls(1).Data_Id);
      Dbms_Sql.Define_Column(r_Smts(1).Cursor_Handle, 2, r_Ttls(1).Data_Code, 100);
      Dbms_Sql.Define_Column(r_Smts(1).Cursor_Handle, 3, r_Ttls(1).Data_Name, 100);
      Dbms_Sql.Define_Column(r_Smts(1).Cursor_Handle, 5, r_Ttls(1).Entity_Id);
      r_Smts(1).Cursor_Exenum := Dbms_Sql.Execute(r_Smts(1).Cursor_Handle);

      --游标循环
      While Dbms_Sql.Fetch_Rows(r_Smts(1).Cursor_Handle) <> 0 Loop
        --游标取值
        Dbms_Sql.Column_Value(r_Smts(1).Cursor_Handle, 1, r_Ttls(1).Data_Id);
        Dbms_Sql.Column_Value(r_Smts(1).Cursor_Handle, 2, r_Ttls(1).Data_Code);
        Dbms_Sql.Column_Value(r_Smts(1).Cursor_Handle, 3, r_Ttls(1).Data_Name);
        Dbms_Sql.Column_Value(r_Smts(1).Cursor_Handle, 5, r_Ttls(1).Entity_Id);

        --获取节点
        Begin
          Select budget_tree_id
            Into r_Ttls(1).Budget_Tree_Id
            From t_pol_budget_tree
           Where Data_Flow_Id = p_Data_Flow_Id
             And entity_id = p_Entity_Id
             And Budget_Segment_01_Id = r_Ttls(1).Data_Id
             And Budget_Segment_02_Id = -1
             And Budget_Segment_03_Id = -1
             And Budget_Segment_04_Id = -1
             And Budget_Segment_05_Id = -1
             And Budget_Segment_06_Id = -1;
        Exception
          When No_Data_Found Then
            --获取节点ID
            Select s_pol_budget_tree.Nextval
              Into r_Ttls(1).Budget_Tree_Id
              From Dual;
            --插入节点
            Insert Into t_pol_budget_tree
              (budget_tree_id,
               object_type,
               budget_tree_name,
               budget_tree_desc,
               budget_tree_level,
               budget_tree_pre_id,
               last_year_amount,
               beginning_balance_amount,
               effective_amount,
               reserve_amount,
               current_new_amount,
               current_occupation_amount,
               ending_balance_amount,
               settle_flag,
               cust_flag,
               budget_lower_amount,
               fee_lower_amount,
               budget_segment_01_id,
               budget_segment_01_code,
               budget_segment_01_name,
               budget_segment_02_id,
               budget_segment_02_code,
               budget_segment_02_name,
               budget_segment_03_id,
               budget_segment_03_code,
               budget_segment_03_name,
               budget_segment_04_id,
               budget_segment_04_code,
               budget_segment_04_name,
               budget_segment_05_id,
               budget_segment_05_code,
               budget_segment_05_name,
               budget_segment_06_id,
               budget_segment_06_code,
               budget_segment_06_name,
               data_flow_id,
               control_flag,
               entity_id,
               sales_center_id,
               created_by,
               creation_date,
               last_updated_by,
               last_update_date,
               pre_field_01,
               pre_field_02,
               pre_field_03,
               pre_field_04,
               pre_field_05,
               pre_field_06)
            Values
              (r_Ttls(1).Budget_Tree_Id,
               v_Budget_Type,
               r_Ttls(1).Data_Name,
               r_Ttls(1).Data_Name,
               1,
               -1,
               0,
               0,
               0,
               0,
               0,
               0,
               0,
               0,
               1,
               0,
               0,
               r_Ttls(1).Data_Id,
               r_Ttls(1).Data_Code,
               r_Ttls(1).Data_Name,
               -1,
               Null,
               Null,
               -1,
               Null,
               Null,
               -1,
               Null,
               Null,
               -1,
               Null,
               Null,
               -1,
               Null,
               Null,
               p_Data_Flow_Id,
               Decode(Nvl(r_Smts(1).If_Bgt_Cntrl, 1), -1, v_n, v_y),
               p_Entity_Id,
               1,
               p_User_Id,
               Sysdate,
               p_User_Id,
               Sysdate,
               Null,
               Null,
               Null,
               Null,
               Null,
               Null);
        End;

        --二层游标
        If Nvl(r_Smts(2).Bgt_Smt_Used, -1) > 0 Then
          --拼接SQL
          Select Decode(Nvl(r_Smts(2).Pre_Level, 0),
                        1, (' WHERE Pre_Id = ' || To_Char(r_Ttls(1).Data_Id)),
                        '')
            Into r_Smts(2).Sql_Add_Where
            From Dual;

          --动态游标
          p_Result := '动态SQL查询2';
          r_Smts(2).Cursor_Handle := Dbms_Sql.Open_Cursor;
          Dbms_Sql.Parse(r_Smts(2).Cursor_Handle, r_Smts(2).Bgt_Smt_Sql || r_Smts(2).Sql_Add_Where, Dbms_Sql.Native);
          Dbms_Sql.Define_Column(r_Smts(2).Cursor_Handle, 1, r_Ttls(2).Data_Id);
          Dbms_Sql.Define_Column(r_Smts(2).Cursor_Handle, 2, r_Ttls(2).Data_Code, 100);
          Dbms_Sql.Define_Column(r_Smts(2).Cursor_Handle, 3, r_Ttls(2).Data_Name, 100);
          Dbms_Sql.Define_Column(r_Smts(2).Cursor_Handle, 5, r_Ttls(2).Entity_Id);
          r_Smts(2).Cursor_Exenum := Dbms_Sql.Execute(r_Smts(2).Cursor_Handle);

          --游标循环
          While Dbms_Sql.Fetch_Rows(r_Smts(2).Cursor_Handle) <> 0 Loop
            --游标取值
            Dbms_Sql.Column_Value(r_Smts(2).Cursor_Handle, 1, r_Ttls(2).Data_Id);
            Dbms_Sql.Column_Value(r_Smts(2).Cursor_Handle, 2, r_Ttls(2).Data_Code);
            Dbms_Sql.Column_Value(r_Smts(2).Cursor_Handle, 3, r_Ttls(2).Data_Name);
            Dbms_Sql.Column_Value(r_Smts(2).Cursor_Handle, 5, r_Ttls(2).Entity_Id);

            --获取节点
            Begin
              Select budget_tree_id
                Into r_Ttls(2).Budget_Tree_Id
                From t_pol_budget_tree
               Where Data_Flow_Id = p_Data_Flow_Id
                 And Entity_Id = p_Entity_Id
                 And Budget_Segment_01_Id = r_Ttls(1).Data_Id
                 And Budget_Segment_02_Id = r_Ttls(2).Data_Id
                 And Budget_Segment_03_Id = -1
                 And Budget_Segment_04_Id = -1
                 And Budget_Segment_05_Id = -1
                 And Budget_Segment_06_Id = -1;
            Exception
              When No_Data_Found Then
                --获取节点ID
                Select s_pol_budget_tree.Nextval
                  Into r_Ttls(2).Budget_Tree_Id
                  From Dual;

                --插入节点
                Insert Into t_pol_budget_tree
                  (budget_tree_id,
                   object_type,
                   budget_tree_name,
                   budget_tree_desc,
                   budget_tree_level,
                   budget_tree_pre_id,
                   last_year_amount,
                   beginning_balance_amount,
                   effective_amount,
                   reserve_amount,
                   current_new_amount,
                   current_occupation_amount,
                   ending_balance_amount,
                   settle_flag,
                   cust_flag,
                   budget_lower_amount,
                   fee_lower_amount,
                   budget_segment_01_id,
                   budget_segment_01_code,
                   budget_segment_01_name,
                   budget_segment_02_id,
                   budget_segment_02_code,
                   budget_segment_02_name,
                   budget_segment_03_id,
                   budget_segment_03_code,
                   budget_segment_03_name,
                   budget_segment_04_id,
                   budget_segment_04_code,
                   budget_segment_04_name,
                   budget_segment_05_id,
                   budget_segment_05_code,
                   budget_segment_05_name,
                   budget_segment_06_id,
                   budget_segment_06_code,
                   budget_segment_06_name,
                   data_flow_id,
                   control_flag,
                   entity_id,
                   sales_center_id,
                   created_by,
                   creation_date,
                   last_updated_by,
                   last_update_date,
                   pre_field_01,
                   pre_field_02,
                   pre_field_03,
                   pre_field_04,
                   pre_field_05,
                   pre_field_06)
                Values
                  (r_Ttls(2).Budget_Tree_Id,
                   v_Budget_Type,
                   r_Ttls(2).Data_Name,
                   (r_Ttls(1).Data_Name || ' ' || r_Ttls(2).Data_Name),
                   2,
                   r_Ttls(1).Budget_Tree_Id,
                   0,
                   0,
                   0,
                   0,
                   0,
                   0,
                   0,
                   0,
                   1,
                   0,
                   0,
                   r_Ttls(1).Data_Id,
                   r_Ttls(1).Data_Code,
                   r_Ttls(1).Data_Name,
                   r_Ttls(2).Data_Id,
                   r_Ttls(2).Data_Code,
                   r_Ttls(2).Data_Name,
                   -1,
                   Null,
                   Null,
                   -1,
                   Null,
                   Null,
                   -1,
                   Null,
                   Null,
                   -1,
                   Null,
                   Null,
                   p_Data_Flow_Id,
                   Decode(Nvl(r_Smts(2).If_Bgt_Cntrl, 1), -1, v_n, v_y),
                   p_Entity_Id,
                   1,
                   p_User_Id,
                   Sysdate,
                   p_User_Id,
                   Sysdate,
                   Null,
                   Null,
                   Null,
                   Null,
                   Null,
                   Null);
            End;

            --三层游标
            If Nvl(r_Smts(3).Bgt_Smt_Used, -1) > 0 Then
              --拼接SQL
              Select Decode(Nvl(r_Smts(3).Pre_Level, 0),
                            1, (' WHERE Pre_Id = ' || To_Char(r_Ttls(1).Data_Id)),
                            2, (' WHERE Pre_Id = ' || To_Char(r_Ttls(2).Data_Id)),
                            '')
                Into r_Smts(3).Sql_Add_Where
                From Dual;

              --动态游标
              p_Result := '动态SQL查询3';
              r_Smts(3).Cursor_Handle := Dbms_Sql.Open_Cursor;
              Dbms_Sql.Parse(r_Smts(3).Cursor_Handle, r_Smts(3).Bgt_Smt_Sql || r_Smts(3).Sql_Add_Where, Dbms_Sql.Native);
              Dbms_Sql.Define_Column(r_Smts(3).Cursor_Handle, 1, r_Ttls(3).Data_Id);
              Dbms_Sql.Define_Column(r_Smts(3).Cursor_Handle, 2, r_Ttls(3).Data_Code, 100);
              Dbms_Sql.Define_Column(r_Smts(3).Cursor_Handle, 3, r_Ttls(3).Data_Name, 100);
              Dbms_Sql.Define_Column(r_Smts(3).Cursor_Handle, 5, r_Ttls(3).Entity_Id);
              r_Smts(3).Cursor_Exenum := Dbms_Sql.Execute(r_Smts(3).Cursor_Handle);

              --游标循环
              While Dbms_Sql.Fetch_Rows(r_Smts(3).Cursor_Handle) <> 0 Loop
                --游标取值
                Dbms_Sql.Column_Value(r_Smts(3).Cursor_Handle, 1, r_Ttls(3).Data_Id);
                Dbms_Sql.Column_Value(r_Smts(3).Cursor_Handle, 2, r_Ttls(3).Data_Code);
                Dbms_Sql.Column_Value(r_Smts(3).Cursor_Handle, 3, r_Ttls(3).Data_Name);
                Dbms_Sql.Column_Value(r_Smts(3).Cursor_Handle, 5, r_Ttls(3).Entity_Id);

                --获取节点
                Begin
                  Select budget_tree_id
                    Into r_Ttls(3).Budget_Tree_Id
                    From t_pol_budget_tree
                   Where Data_Flow_Id = p_Data_Flow_Id
                     And Entity_Id = p_Entity_Id
                     And Budget_Segment_01_Id = r_Ttls(1).Data_Id
                     And Budget_Segment_02_Id = r_Ttls(2).Data_Id
                     And Budget_Segment_03_Id = r_Ttls(3).Data_Id
                     And Budget_Segment_04_Id = -1
                     And Budget_Segment_05_Id = -1
                     And Budget_Segment_06_Id = -1;
                Exception
                  When No_Data_Found Then
                    --获取节点ID
                    Select s_pol_budget_tree.Nextval
                      Into r_Ttls(3).Budget_Tree_Id
                      From Dual;

                    --插入节点
                    Insert Into t_pol_budget_tree
                      (budget_tree_id,
                       object_type,
                       budget_tree_name,
                       budget_tree_desc,
                       budget_tree_level,
                       budget_tree_pre_id,
                       last_year_amount,
                       beginning_balance_amount,
                       effective_amount,
                       reserve_amount,
                       current_new_amount,
                       current_occupation_amount,
                       ending_balance_amount,
                       settle_flag,
                       cust_flag,
                       budget_lower_amount,
                       fee_lower_amount,
                       budget_segment_01_id,
                       budget_segment_01_code,
                       budget_segment_01_name,
                       budget_segment_02_id,
                       budget_segment_02_code,
                       budget_segment_02_name,
                       budget_segment_03_id,
                       budget_segment_03_code,
                       budget_segment_03_name,
                       budget_segment_04_id,
                       budget_segment_04_code,
                       budget_segment_04_name,
                       budget_segment_05_id,
                       budget_segment_05_code,
                       budget_segment_05_name,
                       budget_segment_06_id,
                       budget_segment_06_code,
                       budget_segment_06_name,
                       data_flow_id,
                       control_flag,
                       entity_id,
                       sales_center_id,
                       created_by,
                       creation_date,
                       last_updated_by,
                       last_update_date,
                       pre_field_01,
                       pre_field_02,
                       pre_field_03,
                       pre_field_04,
                       pre_field_05,
                       pre_field_06)
                    Values
                      (r_Ttls(3).Budget_Tree_Id,
                       v_Budget_Type,
                       r_Ttls(3).Data_Name,
                       (r_Ttls(1).Data_Name || ' ' || r_Ttls(2).Data_Name || ' ' || r_Ttls(3)
                       .Data_Name),
                       3,
                       r_Ttls(2).Budget_Tree_Id,
                       0,
                       0,
                       0,
                       0,
                       0,
                       0,
                       0,
                       0,
                       1,
                       0,
                       0,
                       r_Ttls(1).Data_Id,
                       r_Ttls(1).Data_Code,
                       r_Ttls(1).Data_Name,
                       r_Ttls(2).Data_Id,
                       r_Ttls(2).Data_Code,
                       r_Ttls(2).Data_Name,
                       r_Ttls(3).Data_Id,
                       r_Ttls(3).Data_Code,
                       r_Ttls(3).Data_Name,
                       -1,
                       Null,
                       Null,
                       -1,
                       Null,
                       Null,
                       -1,
                       Null,
                       Null,
                       p_Data_Flow_Id,
                       Decode(Nvl(r_Smts(3).If_Bgt_Cntrl, 1), -1, v_n, v_y),
                       p_Entity_Id,
                       1,
                       p_User_Id,
                       Sysdate,
                       p_User_Id,
                       Sysdate,
                       Null,
                       Null,
                       Null,
                       Null,
                       Null,
                       Null);
                End;

                --四层游标
                If Nvl(r_Smts(4).Bgt_Smt_Used, -1) > 0 Then
                  --拼接SQL
                  Select Decode(Nvl(r_Smts(4).Pre_Level, 0),
                                1, (' WHERE Pre_Id = ' || To_Char(r_Ttls(1).Data_Id)),
                                2, (' WHERE Pre_Id = ' || To_Char(r_Ttls(2).Data_Id)),
                                3, (' WHERE Pre_Id = ' || To_Char(r_Ttls(3).Data_Id)),
                                '')
                    Into r_Smts(4).Sql_Add_Where
                    From Dual;

                  --动态游标
                  p_Result := '动态SQL查询4';
                  r_Smts(4).Cursor_Handle := Dbms_Sql.Open_Cursor;
                  Dbms_Sql.Parse(r_Smts(4).Cursor_Handle, r_Smts(4).Bgt_Smt_Sql || r_Smts(4).Sql_Add_Where, Dbms_Sql.Native);
                  Dbms_Sql.Define_Column(r_Smts(4).Cursor_Handle, 1, r_Ttls(4).Data_Id);
                  Dbms_Sql.Define_Column(r_Smts(4).Cursor_Handle, 2, r_Ttls(4).Data_Code, 100);
                  Dbms_Sql.Define_Column(r_Smts(4).Cursor_Handle, 3, r_Ttls(4).Data_Name, 100);
                  Dbms_Sql.Define_Column(r_Smts(4).Cursor_Handle, 5, r_Ttls(4).Entity_Id);
                  r_Smts(4).Cursor_Exenum := Dbms_Sql.Execute(r_Smts(4).Cursor_Handle);

                  --游标循环
                  While Dbms_Sql.Fetch_Rows(r_Smts(4).Cursor_Handle) <> 0 Loop
                    --游标取值
                    Dbms_Sql.Column_Value(r_Smts(4).Cursor_Handle, 1, r_Ttls(4).Data_Id);
                    Dbms_Sql.Column_Value(r_Smts(4).Cursor_Handle, 2, r_Ttls(4).Data_Code);
                    Dbms_Sql.Column_Value(r_Smts(4).Cursor_Handle, 3, r_Ttls(4).Data_Name);
                    Dbms_Sql.Column_Value(r_Smts(4).Cursor_Handle, 5, r_Ttls(4).Entity_Id);

                    --获取节点
                    Begin
                      Select budget_tree_id
                        Into r_Ttls(4).Budget_Tree_Id
                        From t_pol_budget_tree
                       Where Data_Flow_Id = p_Data_Flow_Id
                         And Entity_Id = p_Entity_Id
                         And Budget_Segment_01_Id = r_Ttls(1).Data_Id
                         And Budget_Segment_02_Id = r_Ttls(2).Data_Id
                         And Budget_Segment_03_Id = r_Ttls(3).Data_Id
                         And Budget_Segment_04_Id = r_Ttls(4).Data_Id
                         And Budget_Segment_05_Id = -1
                         And Budget_Segment_06_Id = -1;
                    Exception
                      When No_Data_Found Then
                        --获取节点ID
                        Select s_pol_budget_tree.Nextval
                          Into r_Ttls(4).Budget_Tree_Id
                          From Dual;

                        --插入节点
                        Insert Into t_pol_budget_tree
                          (budget_tree_id,
                           object_type,
                           budget_tree_name,
                           budget_tree_desc,
                           budget_tree_level,
                           budget_tree_pre_id,
                           last_year_amount,
                           beginning_balance_amount,
                           effective_amount,
                           reserve_amount,
                           current_new_amount,
                           current_occupation_amount,
                           ending_balance_amount,
                           settle_flag,
                           cust_flag,
                           budget_lower_amount,
                           fee_lower_amount,
                           budget_segment_01_id,
                           budget_segment_01_code,
                           budget_segment_01_name,
                           budget_segment_02_id,
                           budget_segment_02_code,
                           budget_segment_02_name,
                           budget_segment_03_id,
                           budget_segment_03_code,
                           budget_segment_03_name,
                           budget_segment_04_id,
                           budget_segment_04_code,
                           budget_segment_04_name,
                           budget_segment_05_id,
                           budget_segment_05_code,
                           budget_segment_05_name,
                           budget_segment_06_id,
                           budget_segment_06_code,
                           budget_segment_06_name,
                           data_flow_id,
                           control_flag,
                           entity_id,
                           sales_center_id,
                           created_by,
                           creation_date,
                           last_updated_by,
                           last_update_date,
                           pre_field_01,
                           pre_field_02,
                           pre_field_03,
                           pre_field_04,
                           pre_field_05,
                           pre_field_06)
                        Values
                          (r_Ttls(4).Budget_Tree_Id,
                           v_Budget_Type,
                           r_Ttls(4).Data_Name,
                           (r_Ttls(1)
                           .Data_Name || ' ' || r_Ttls(2).Data_Name || ' ' || r_Ttls(3)
                           .Data_Name || ' ' || r_Ttls(4).Data_Name),
                           4,
                           r_Ttls(3).Budget_Tree_Id,
                           0,
                           0,
                           0,
                           0,
                           0,
                           0,
                           0,
                           0,
                           1,
                           0,
                           0,
                           r_Ttls(1).Data_Id,
                           r_Ttls(1).Data_Code,
                           r_Ttls(1).Data_Name,
                           r_Ttls(2).Data_Id,
                           r_Ttls(2).Data_Code,
                           r_Ttls(2).Data_Name,
                           r_Ttls(3).Data_Id,
                           r_Ttls(3).Data_Code,
                           r_Ttls(3).Data_Name,
                           r_Ttls(4).Data_Id,
                           r_Ttls(4).Data_Code,
                           r_Ttls(4).Data_Name,
                           -1,
                           Null,
                           Null,
                           -1,
                           Null,
                           Null,
                           p_Data_Flow_Id,
                           Decode(Nvl(r_Smts(4).If_Bgt_Cntrl, 1), -1, v_n, v_y),
                           p_Entity_Id,
                           1,
                           p_User_Id,
                           Sysdate,
                           p_User_Id,
                           Sysdate,
                           Null,
                           Null,
                           Null,
                           Null,
                           Null,
                           Null);
                    End;

                    --五层游标
                    If Nvl(r_Smts(5).Bgt_Smt_Used, -1) > 0 Then
                      --拼接SQL
                      Select Decode(Nvl(r_Smts(5).Pre_Level, 0),
                                    1, (' WHERE Pre_Id = ' || To_Char(r_Ttls(1).Data_Id)),
                                    2, (' WHERE Pre_Id = ' || To_Char(r_Ttls(2).Data_Id)),
                                    3, (' WHERE Pre_Id = ' || To_Char(r_Ttls(3).Data_Id)),
                                    4, (' WHERE Pre_Id = ' || To_Char(r_Ttls(4).Data_Id)),
                                    '')
                        Into r_Smts(5).Sql_Add_Where
                        From Dual;

                      --动态游标
                      p_Result := '动态SQL查询5';
                      r_Smts(5).Cursor_Handle := Dbms_Sql.Open_Cursor;
                      Dbms_Sql.Parse(r_Smts(5).Cursor_Handle, r_Smts(5).Bgt_Smt_Sql || r_Smts(5).Sql_Add_Where, Dbms_Sql.Native);
                      Dbms_Sql.Define_Column(r_Smts(5).Cursor_Handle, 1, r_Ttls(5).Data_Id);
                      Dbms_Sql.Define_Column(r_Smts(5).Cursor_Handle, 2, r_Ttls(5).Data_Code, 100);
                      Dbms_Sql.Define_Column(r_Smts(5).Cursor_Handle, 3, r_Ttls(5).Data_Name, 100);
                      Dbms_Sql.Define_Column(r_Smts(5).Cursor_Handle, 5, r_Ttls(5).Entity_Id);
                      r_Smts(5).Cursor_Exenum := Dbms_Sql.Execute(r_Smts(5).Cursor_Handle);

                      --游标循环
                      While Dbms_Sql.Fetch_Rows(r_Smts(5).Cursor_Handle) <> 0 Loop
                        --游标取值
                        Dbms_Sql.Column_Value(r_Smts(5).Cursor_Handle, 1, r_Ttls(5).Data_Id);
                        Dbms_Sql.Column_Value(r_Smts(5).Cursor_Handle, 2, r_Ttls(5).Data_Code);
                        Dbms_Sql.Column_Value(r_Smts(5).Cursor_Handle, 3, r_Ttls(5).Data_Name);
                        Dbms_Sql.Column_Value(r_Smts(5).Cursor_Handle, 5, r_Ttls(5).Entity_Id);

                        --获取节点
                        Begin
                          Select budget_tree_id
                            Into r_Ttls(5).Budget_Tree_Id
                            From t_pol_budget_tree
                           Where Data_Flow_Id = p_Data_Flow_Id
                             And Entity_Id = p_Entity_Id
                             And Budget_Segment_01_Id = r_Ttls(1).Data_Id
                             And Budget_Segment_02_Id = r_Ttls(2).Data_Id
                             And Budget_Segment_03_Id = r_Ttls(3).Data_Id
                             And Budget_Segment_04_Id = r_Ttls(4).Data_Id
                             And Budget_Segment_05_Id = r_Ttls(5).Data_Id
                             And Budget_Segment_06_Id = -1;
                        Exception
                          When No_Data_Found Then
                            --获取节点ID
                            Select s_pol_budget_tree.Nextval
                              Into r_Ttls(5).Budget_Tree_Id
                              From Dual;

                            --插入节点
                            Insert Into t_pol_budget_tree
                              (budget_tree_id,
                               object_type,
                               budget_tree_name,
                               budget_tree_desc,
                               budget_tree_level,
                               budget_tree_pre_id,
                               last_year_amount,
                               beginning_balance_amount,
                               effective_amount,
                               reserve_amount,
                               current_new_amount,
                               current_occupation_amount,
                               ending_balance_amount,
                               settle_flag,
                               cust_flag,
                               budget_lower_amount,
                               fee_lower_amount,
                               budget_segment_01_id,
                               budget_segment_01_code,
                               budget_segment_01_name,
                               budget_segment_02_id,
                               budget_segment_02_code,
                               budget_segment_02_name,
                               budget_segment_03_id,
                               budget_segment_03_code,
                               budget_segment_03_name,
                               budget_segment_04_id,
                               budget_segment_04_code,
                               budget_segment_04_name,
                               budget_segment_05_id,
                               budget_segment_05_code,
                               budget_segment_05_name,
                               budget_segment_06_id,
                               budget_segment_06_code,
                               budget_segment_06_name,
                               data_flow_id,
                               control_flag,
                               entity_id,
                               sales_center_id,
                               created_by,
                               creation_date,
                               last_updated_by,
                               last_update_date,
                               pre_field_01,
                               pre_field_02,
                               pre_field_03,
                               pre_field_04,
                               pre_field_05,
                               pre_field_06)
                            Values
                              (r_Ttls(5).Budget_Tree_Id,
                               v_Budget_Type,
                               r_Ttls(5).Data_Name,
                               (r_Ttls(1)
                               .Data_Name || ' ' || r_Ttls(2).Data_Name || ' ' || r_Ttls(3)
                               .Data_Name || ' ' || r_Ttls(4).Data_Name || ' ' || r_Ttls(5)
                               .Data_Name),
                               5,
                               r_Ttls(4).Budget_Tree_Id,
                               0,
                               0,
                               0,
                               0,
                               0,
                               0,
                               0,
                               0,
                               1,
                               0,
                               0,
                               r_Ttls(1).Data_Id,
                               r_Ttls(1).Data_Code,
                               r_Ttls(1).Data_Name,
                               r_Ttls(2).Data_Id,
                               r_Ttls(2).Data_Code,
                               r_Ttls(2).Data_Name,
                               r_Ttls(3).Data_Id,
                               r_Ttls(3).Data_Code,
                               r_Ttls(3).Data_Name,
                               r_Ttls(4).Data_Id,
                               r_Ttls(4).Data_Code,
                               r_Ttls(4).Data_Name,
                               r_Ttls(5).Data_Id,
                               r_Ttls(5).Data_Code,
                               r_Ttls(5).Data_Name,
                               -1,
                               Null,
                               Null,
                               p_Data_Flow_Id,
                               Decode(Nvl(r_Smts(5).If_Bgt_Cntrl, 1), -1, v_n, v_y),
                               p_Entity_Id,
                               1,
                               p_User_Id,
                               Sysdate,
                               p_User_Id,
                               Sysdate,
                               Null,
                               Null,
                               Null,
                               Null,
                               Null,
                               Null);
                        End;

                        --六层游标
                        If Nvl(r_Smts(6).Bgt_Smt_Used, -1) > 0 Then
                          --拼接SQL
                          Select Decode(Nvl(r_Smts(6).Pre_Level, 0),
                                        1, (' WHERE Pre_Id = ' || To_Char(r_Ttls(1).Data_Id)),
                                        2, (' WHERE Pre_Id = ' || To_Char(r_Ttls(2).Data_Id)),
                                        3, (' WHERE Pre_Id = ' || To_Char(r_Ttls(3).Data_Id)),
                                        4, (' WHERE Pre_Id = ' || To_Char(r_Ttls(4).Data_Id)),
                                        5, (' WHERE Pre_Id = ' || To_Char(r_Ttls(5).Data_Id)),
                                        '')
                            Into r_Smts(6).Sql_Add_Where
                            From Dual;

                          --动态游标
                          p_Result := '动态SQL查询6';
                          r_Smts(6).Cursor_Handle := Dbms_Sql.Open_Cursor;
                          Dbms_Sql.Parse(r_Smts(6).Cursor_Handle, r_Smts(6).Bgt_Smt_Sql || r_Smts(6).Sql_Add_Where, Dbms_Sql.Native);
                          Dbms_Sql.Define_Column(r_Smts(6).Cursor_Handle, 1, r_Ttls(6).Data_Id);
                          Dbms_Sql.Define_Column(r_Smts(6).Cursor_Handle, 2, r_Ttls(6).Data_Code, 100);
                          Dbms_Sql.Define_Column(r_Smts(6).Cursor_Handle, 3, r_Ttls(6).Data_Name, 100);
                          Dbms_Sql.Define_Column(r_Smts(6).Cursor_Handle, 5, r_Ttls(6).Entity_Id);
                          r_Smts(6).Cursor_Exenum := Dbms_Sql.Execute(r_Smts(6).Cursor_Handle);

                          --游标循环
                          While Dbms_Sql.Fetch_Rows(r_Smts(6).Cursor_Handle) <> 0 Loop
                            --游标取值
                            Dbms_Sql.Column_Value(r_Smts(6).Cursor_Handle, 1, r_Ttls(6).Data_Id);
                            Dbms_Sql.Column_Value(r_Smts(6).Cursor_Handle, 2, r_Ttls(6).Data_Code);
                            Dbms_Sql.Column_Value(r_Smts(6).Cursor_Handle, 3, r_Ttls(6).Data_Name);
                            Dbms_Sql.Column_Value(r_Smts(6).Cursor_Handle, 5, r_Ttls(6).Entity_Id);

                            --获取节点
                            Begin
                              Select budget_tree_id
                                Into r_Ttls(6).Budget_Tree_Id
                                From t_pol_budget_tree
                               Where Data_Flow_Id = p_Data_Flow_Id
                                 And Entity_Id = p_Entity_Id
                                 And Budget_Tree_Level = 6
                                 And Budget_Segment_01_Id = r_Ttls(1).Data_Id
                                 And Budget_Segment_02_Id = r_Ttls(2).Data_Id
                                 And Budget_Segment_03_Id = r_Ttls(3).Data_Id
                                 And Budget_Segment_04_Id = r_Ttls(4).Data_Id
                                 And Budget_Segment_05_Id = r_Ttls(5).Data_Id
                                 And Budget_Segment_06_Id = r_Ttls(6).Data_Id;
                            Exception
                              When No_Data_Found Then
                                --获取节点ID
                                Select s_pol_budget_tree.Nextval
                                  Into r_Ttls(6).Budget_Tree_Id
                                  From Dual;

                                --插入节点
                                Insert Into t_pol_budget_tree
                                  (budget_tree_id,
                                   object_type,
                                   budget_tree_name,
                                   budget_tree_desc,
                                   budget_tree_level,
                                   budget_tree_pre_id,
                                   last_year_amount,
                                   beginning_balance_amount,
                                   effective_amount,
                                   reserve_amount,
                                   current_new_amount,
                                   current_occupation_amount,
                                   ending_balance_amount,
                                   settle_flag,
                                   cust_flag,
                                   budget_lower_amount,
                                   fee_lower_amount,
                                   budget_segment_01_id,
                                   budget_segment_01_code,
                                   budget_segment_01_name,
                                   budget_segment_02_id,
                                   budget_segment_02_code,
                                   budget_segment_02_name,
                                   budget_segment_03_id,
                                   budget_segment_03_code,
                                   budget_segment_03_name,
                                   budget_segment_04_id,
                                   budget_segment_04_code,
                                   budget_segment_04_name,
                                   budget_segment_05_id,
                                   budget_segment_05_code,
                                   budget_segment_05_name,
                                   budget_segment_06_id,
                                   budget_segment_06_code,
                                   budget_segment_06_name,
                                   data_flow_id,
                                   control_flag,
                                   entity_id,
                                   sales_center_id,
                                   created_by,
                                   creation_date,
                                   last_updated_by,
                                   last_update_date,
                                   pre_field_01,
                                   pre_field_02,
                                   pre_field_03,
                                   pre_field_04,
                                   pre_field_05,
                                   pre_field_06)
                                Values
                                  (r_Ttls(6).Budget_Tree_Id,
                                   v_Budget_Type,
                                   r_Ttls(6).Data_Name,
                                   (r_Ttls(1)
                                   .Data_Name || ' ' || r_Ttls(2).Data_Name || ' ' || r_Ttls(3)
                                   .Data_Name || ' ' || r_Ttls(4).Data_Name || ' ' || r_Ttls(5)
                                   .Data_Name || ' ' || r_Ttls(6).Data_Name),
                                   6,
                                   r_Ttls(5).Budget_Tree_Id,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   1,
                                   0,
                                   0,
                                   r_Ttls(1).Data_Id,
                                   r_Ttls(1).Data_Code,
                                   r_Ttls(1).Data_Name,
                                   r_Ttls(2).Data_Id,
                                   r_Ttls(2).Data_Code,
                                   r_Ttls(2).Data_Name,
                                   r_Ttls(3).Data_Id,
                                   r_Ttls(3).Data_Code,
                                   r_Ttls(3).Data_Name,
                                   r_Ttls(4).Data_Id,
                                   r_Ttls(4).Data_Code,
                                   r_Ttls(4).Data_Name,
                                   r_Ttls(5).Data_Id,
                                   r_Ttls(5).Data_Code,
                                   r_Ttls(5).Data_Name,
                                   r_Ttls(6).Data_Id,
                                   r_Ttls(6).Data_Code,
                                   r_Ttls(6).Data_Name,
                                   p_Data_Flow_Id,
                                   Decode(Nvl(r_Smts(6).If_Bgt_Cntrl, 1), -1, v_n, v_y),
                                   p_Entity_Id,
                                   1,
                                   p_User_Id,
                                   Sysdate,
                                   p_User_Id,
                                   Sysdate,
                                   Null,
                                   Null,
                                   Null,
                                   Null,
                                   Null,
                                   Null);
                            End;
                          End Loop;
                          Dbms_Sql.Close_Cursor(r_Smts(6).Cursor_Handle);
                        End If;
                      End Loop;
                      Dbms_Sql.Close_Cursor(r_Smts(5).Cursor_Handle);
                    End If;
                  End Loop;
                  Dbms_Sql.Close_Cursor(r_Smts(4).Cursor_Handle);
                End If;
              End Loop;
              Dbms_Sql.Close_Cursor(r_Smts(3).Cursor_Handle);
            End If;
          End Loop;
          Dbms_Sql.Close_Cursor(r_Smts(2).Cursor_Handle);
        End If;
      End Loop;
      Dbms_Sql.Close_Cursor(r_Smts(1).Cursor_Handle);
    End If;

    --成功处理返回
    p_Result := v_Success;
  Exception
    When Procedure_Brk_Exp Then
      p_Result := v_Pp || '调用错误：' || v_Nl || p_Result;
      Rollback To Savepoint Sp_Synchro_Budget_Frame;
    When Ipt_Param_Err_Exp Then
      p_Result := v_Pp || '参数错误：' || p_Result;
      Rollback To Savepoint Sp_Synchro_Budget_Frame;
    When Sql_Not_Found_Exp Then
      p_Result := v_Pp || '更新无效：' || p_Result;
      Rollback To Savepoint Sp_Synchro_Budget_Frame;
    When No_Data_Found Then
      p_Result := v_Pp || '查无记录：' || p_Result;
      Rollback To Savepoint Sp_Synchro_Budget_Frame;
    When Too_Many_Rows Then
      p_Result := v_Pp || '查多记录：' || p_Result;
      Rollback To Savepoint Sp_Synchro_Budget_Frame;
    When Others Then
      p_Result := v_Pp || '未知错误：' || p_Result || v_Nl || Sqlcode || ': ' || Sqlerrm;
      Rollback To Savepoint Sp_Synchro_Budget_Frame;
      If Sqlcode = -6508 Then
        dbms_session.reset_package;
      End if;
  End p_Synchro_Budget_Frame;

 /*===============================================================
  * Program Name:   p_Chk_Bgt_Flow_System
  * Purpose     :   检查整个预算流体系
   ===============================================================*/
  Procedure p_Chk_Bgt_Flow_System(p_Data_Flow_Id In Number,
                                  --预算流ID
                                  p_Entity_Id In Number,
                                  --主体ID
                                  p_Result Out Varchar2
                                  --返回结果：成功返回"SUCCESS"，失败返回原因
                                  ) Is

    v_Pp Constant Varchar2(80) := '检查整个预算流体系失败，';
    tempId Number;
  Begin
    --检查参数
    If p_Data_Flow_Id Is Null Or p_Entity_Id Is Null Then
      p_Result := '输入参数分别为(' || To_Char(p_Data_Flow_Id) || ',' || To_Char(p_Entity_Id) || ')';
      Raise Ipt_Param_Err_Exp;
    End If;

    --检查预算树是否已经创建
    p_Result := '预算流体系(' || To_Char(p_Data_Flow_Id) || ')';
    select t.budget_tree_id into tempId from t_Pol_Budget_tree t where t.data_flow_id = p_Data_Flow_Id and rownum = 1;

    --检查预算框架的完整性，不存在除顶点外的没有父节点的预算节点
    p_Result := '检查预算框架完整(' || To_Char(p_Data_Flow_Id) || ',' || To_Char(p_Entity_Id) || ')';
    Select v_Success
      Into p_Result
      From Dual
     Where Not Exists (Select Null
              From t_pol_budget_tree a
             Where a.Data_Flow_Id = p_Data_Flow_Id
               And a.Entity_Id = p_Entity_Id
               And a.Budget_Tree_Pre_Id <> '-1'
               And Not Exists
             (Select Null
                      From t_pol_budget_tree b
                     Where b.Budget_Tree_Id = a.Budget_Tree_Pre_Id
                       And b.Data_Flow_Id = p_Data_Flow_Id
                       And b.Entity_Id = p_Entity_Id));

    --检查预算框架节点层次，不存在层次不正确的节点
    p_Result := '检查节点层次正确(' || To_Char(p_Data_Flow_Id) || ',' || To_Char(p_Entity_Id) || ')';
    Select v_Success
      Into p_Result
      From Dual
     Where Not Exists
     (Select Null
              From (Select Budget_Tree_Id,
                           Budget_Tree_Level,
                           Level Budget_Tree_Id_Level
                      From t_pol_budget_tree
                     Start With Budget_Tree_Id In
                                (Select Budget_Tree_Id
                                   From t_pol_budget_tree
                                  Where Data_Flow_Id = p_Data_Flow_Id
                                    And Entity_Id = p_Entity_Id
                                    And Budget_Tree_Pre_Id = '-1')
                    Connect By Budget_Tree_Pre_Id = Prior to_char(Budget_Tree_Id))
             Where Budget_Tree_Level <> Budget_Tree_Id_Level);

    --上层的下层预算汇总 = 下层所有节点的“当前预算”的汇总值；
    --上层的下层费用汇总 = 下层所有节点的“当前费用+下层费用汇总”的汇总值；
    p_Result := '检查金额回写正确(' || To_Char(p_Data_Flow_Id) || ',' || To_Char(p_Entity_Id) || ')';
    Select v_Success
      Into p_Result
      From Dual
     Where Not Exists
     (Select Budget_Tree_Id,
                   Nvl(Sum(Budget_01), 0) Budget_01,
                   Nvl(Sum(Budget_02), 0) Budget_01,
                   Nvl(Sum(Budget_01), 0) - Nvl(Sum(Budget_02), 0) Budget_00,
                   Nvl(Sum(Fee_01), 0) Fee_01,
                   Nvl(Sum(Fee_02), 0) Fee_02,
                   Nvl(Sum(Fee_01), 0) - Nvl(Sum(Fee_02), 0) Fee_00
              From (Select Budget_Tree_Id,
                           Budget_Lower_Amount Budget_01,
                           0 Budget_02,
                           Fee_Lower_Amount Fee_01,
                           0 Fee_02
                      From t_pol_budget_tree
                     Where Data_Flow_Id = p_Data_Flow_Id
                       And Entity_Id = p_Entity_Id
                    Union All
                    Select TO_NUMBER(Budget_Tree_Pre_Id) Budget_Tree_Id,
                           0 Budget_01,
                           Sum(Current_New_Amount) Budget_02,
                           0 Fee_01,
                           (Nvl(Sum(Current_Occupation_Amount), 0) +
                           Nvl(Sum(Fee_Lower_Amount), 0)) Fee_02
                      From t_pol_budget_tree
                     Where Data_Flow_Id = p_Data_Flow_Id
                       And Entity_Id = p_Entity_Id
                       And Budget_Tree_Pre_Id <> '-1'
                     Group By Budget_Tree_Pre_Id)
             Group By Budget_Tree_Id
            Having Nvl(Sum(Budget_01), 0) <> Nvl(Sum(Budget_02), 0) Or Nvl(Sum(Fee_01), 0) <> Nvl(Sum(Fee_02), 0));

    --两个预算金额字段必须大于等于0；
    --当前预算 >= 下层预算汇总；
    p_Result := '检查预算控制正确(' || To_Char(p_Data_Flow_Id) || ',' || To_Char(p_Entity_Id) || ')';
    Select v_Success
      Into p_Result
      From Dual
     Where Not Exists
     (Select Null
              From t_pol_budget_tree
             Where Data_Flow_Id = p_Data_Flow_Id
               And Entity_Id = p_Entity_Id
               And (Nvl(Effective_Amount, 0) < 0 Or
                   Nvl(Budget_Lower_Amount, 0) < 0 Or
                   Nvl(Effective_Amount, 0) < Nvl(Budget_Lower_Amount, 0)));

    --严控时，“(当前预算 - 当前费用 - 取较大值(下层预算汇总,下层费用汇总)) >= 0
    --!!! 能报的费用 >= 能调的预算，因为可能存在负的费用
    --★★★
    p_Result := '检查费用控制正确(' || To_Char(p_Data_Flow_Id) || ',' || To_Char(p_Entity_Id) || ')';
    Select v_Success
      Into p_Result
      From Dual
     Where Not Exists (Select Null
              From t_pol_budget_tree
             Where Data_Flow_Id = p_Data_Flow_Id
               And Entity_Id = p_Entity_Id
               And Nvl(Control_Flag, v_Null) = v_y
               And (Nvl(Effective_Amount, 0) -
                   Greatest(Nvl(Current_Occupation_Amount, 0), 0) -
                   Greatest(Nvl(Budget_Lower_Amount, 0), Nvl(Fee_Lower_Amount, 0), 0)) < 0);

    --检查节点汇总明细一致
    p_Result := '检查事务数据一致(' || To_Char(p_Data_Flow_Id) || ',' || To_Char(p_Entity_Id) || ')';
    Select v_Success
      Into p_Result
      From Dual
     Where Not Exists
     (Select Budget_Tree_Id,
                   Nvl(Sum(Budget_01), 0) Budget_01,
                   Nvl(Sum(Budget_02), 0) Budget_02,
                   Nvl(Sum(Budget_01), 0) - Nvl(Sum(Budget_02), 0) Budget_00,
                   Nvl(Sum(Fee_01), 0) Fee_01,
                   Nvl(Sum(Fee_02), 0) Fee_02,
                   Nvl(Sum(Fee_01), 0) - Nvl(Sum(Fee_02), 0) Fee_00
              From (Select Budget_Tree_Id,
                           Effective_Amount Budget_01,
                           0 Budget_02,
                           current_Occupation_Amount Fee_01,
                           0 Fee_02
                      From t_pol_budget_tree
                     Where Data_Flow_Id = p_Data_Flow_Id
                       And Entity_Id = p_Entity_Id
                    Union All
                    Select Budget_Tree_Id,
                           0 Budget_01,
                           Nvl(Sum(Budget_Detail_Amount), 0) Budget_02,
                           0 Fee_01,
                           0 Fee_02
                      From t_pol_budget_detail
                     Where Budget_Tree_Id In
                           (Select Budget_Tree_Id
                              From t_pol_budget_tree
                             Where Data_Flow_Id = p_Data_Flow_Id
                               And Entity_Id = p_Entity_Id)
                       And Check_Flag = v_y
                     Group By Budget_Tree_Id
                    Union All
                    Select Budget_Tree_Id,
                           0 Budget_01,
                           0 Budget_02,
                           0 Fee_01,
                           Nvl(Sum(Fee_Detail_Amount), 0) Fee_02
                      From t_Pol_Budget_Fee_Detail
                     Where Budget_Tree_Id In
                           (Select Budget_Tree_Id
                              From t_pol_budget_tree
                             Where Data_Flow_Id = p_Data_Flow_Id
                               And Entity_Id = p_Entity_Id)
                       And Check_Flag = v_y
                     Group By Budget_Tree_Id
                    )
             Group By Budget_Tree_Id
            Having Nvl(Sum(Budget_01), 0) <> Nvl(Sum(Budget_02), 0) Or Nvl(Sum(Fee_01), 0) <> Nvl(Sum(Fee_02), 0));

    --成功处理返回
    p_Result := v_Success;
  Exception
    --返回错误信息，回滚到保存点
    When Procedure_Brk_Exp Then
      p_Result := v_Pp || '调用错误：' || v_Nl || p_Result;
    When Ipt_Param_Err_Exp Then
      p_Result := v_Pp || '参数错误：' || p_Result;
    When Sql_Not_Found_Exp Then
      p_Result := v_Pp || '更新无效：' || p_Result;
    When No_Data_Found Then
      p_Result := v_Pp || '查无记录：' || p_Result;
    When Too_Many_Rows Then
      p_Result := v_Pp || '查多记录：' || p_Result;
    When Others Then
      p_Result := v_Pp || '未知错误：' || p_Result || v_Nl || Sqlcode || ': ' || Sqlerrm;
      If Sqlcode = -6508 Then
        dbms_session.reset_package;
      End If;
  End p_Chk_Bgt_Flow_System;

 /*===============================================================
  * Program Name:   p_Write_Fee
  * Purpose     :   回写节点费用
   ===============================================================*/
  Procedure p_Write_Fee(p_Data_Flow_Id In Number,
                        --数据流程ID，不能为空
                        p_Entity_Id In Number,
                        --主体ID，不能为空
                        p_Budget_Tree_Id In Number,
                        --预算树单元ID，不能为空
                        p_Fee_Type In Varchar2,
                        --费用类型，不能为空
                        p_Fee_Id In Number,
                        --费用单ID，不能为空
                        p_Fee_Code In Varchar2,
                        --费用单号，不能为空
                        p_Comments In Varchar2,
                        --备注信息
                        p_Pre_Field_01 In Varchar2,
                        --备用字段
                        p_Pre_Field_02 In Varchar2,
                        --备用字段
                        p_Pre_Field_03 In Varchar2,
                        --备用字段
                        p_Pre_Field_04 In Varchar2,
                        --备用字段
                        p_Pre_Field_05 In Varchar2,
                        --备用字段
                        p_Pre_Field_06 In Varchar2,
                        --备用字段
                        p_Pre_Field_07 In Varchar2,
                        --备用字段
                        p_Pre_Field_08 In Varchar2,
                        --备用字段
                        p_Pre_Field_09 In Varchar2,
                        --备用字段
                        p_Fee In Number,
                        --费用金额，不能为空，可正可负，两位小数
                        p_User_Id In Number,
                        --用户ID
                        p_Result Out Varchar2
                        --返回结果：成功返回"SUCCESS"，失败返回原因
                        ) Is

    CURSOR C_LOCK IS
      SELECT *
        FROM t_Pol_Budget_Tree
       Where Budget_Tree_Id in (Select Budget_Tree_Id
                                    From t_Pol_Budget_Tree
                                    Start With Budget_Tree_Id = p_Budget_Tree_Id
                                  Connect By Budget_Tree_Id = Prior Budget_Tree_Pre_Id)
        For Update Nowait;

    v_Pp                     Constant Varchar2(80) := '写节点费用失败，';
    v_Budget_Tree_Desc      t_Pol_Budget_Tree.Budget_Tree_Desc%type := '';
    v_Lower_CTL_Budget       number; --下层严控预算
    v_Lower_NO_CTL_FEE       number; --下层非严控费用
    v_Ok                     varchar2(1);
    V_LOWER_CTL_FLAG         VARCHAR2(1);  --下层是否严控
    v_Budget_Type            number; --预算树类型
  Begin
    v_Ok := v_y;

    --检查参数
    If p_Data_Flow_Id Is Null Or p_Entity_Id Is Null Or
       p_Budget_Tree_Id Is Null Or p_Fee_Type Is Null Or p_Fee_Id Is Null Or
       p_Fee_Code Is Null Or p_User_Id Is Null Then
      p_Result := Substrb('输入参数分别为(' || To_Char(p_Data_Flow_Id) || ',' ||
                          To_Char(p_Entity_Id) || ',' ||
                          To_Char(p_Budget_Tree_Id) || ',' || p_Fee_Type || ',' ||
                          To_Char(p_Fee_Id) || ',' || p_Fee_Code || ',' ||
                          To_Char(p_Fee) || ',' || To_Char(p_User_Id) || ')',
                          1,
                          240);
      Raise Ipt_Param_Err_Exp;
    End If;

    --根据费用是否为0确定处理
    If Nvl(p_Fee, 0) = 0 Then
      --中断处理，成功返回
      p_Result := v_Success;
      Return;
    End If;

    --2006-12-05 王小华增加 取预算单元节点名称描述
    p_Result := Substrb('检查预算来源失败,请确定各参数是否正确,参数信息:(' || '数据流ID: ' ||
                        To_Char(p_Data_Flow_Id) || ',' || '主体ID:' ||
                        To_Char(p_Entity_Id) || ',' ||
                        '预算单元ID:' || To_Char(p_Budget_Tree_Id) || ')',
                        1,
                        240);

    --取预算节点描述
    Select Budget_Tree_Desc
      Into v_Budget_Tree_Desc
      From t_Pol_Budget_Tree
     Where Budget_Tree_Id = p_Budget_Tree_Id
       And Data_Flow_Id = p_Data_Flow_Id
       And Entity_Id = p_Entity_Id;

    --锁定要更新的预算节点
    OPEN C_LOCK;
    CLOSE C_LOCK;

    --检查上级节点预算控制并读锁定，注意费用允许为负
    if Nvl(p_Fee, 0) > 0 then
    begin
      --将下级节点严控初始为“N”，使系统检查传入的严控节点
      V_LOWER_CTL_FLAG := 'N';
      For r_Nod In
      (
                SELECT
                  *
                FROM
                  (
                    Select Budget_Tree_Id
                           ,Budget_Tree_Desc
                           ,Nvl(Control_Flag, 'N') Budget_CTL_Flag
                           ,bt.budget_tree_level
                           ,Nvl(Budget_Total_Amount, 0) Budget_Total_Amount
                           ,Nvl(Budget_Lower_Amount, 0) Budget_Lower_Amount
                           ,Nvl(Fee_Total_Amount, 0) Fee_Total_Amount
                           ,Nvl(Fee_Lower_Amount, 0) Fee_Lower_Amount
                           ,level BUDGET_LEVEL
                      From t_Pol_Budget_Tree bt
                      Start With Budget_Tree_Id = p_Budget_Tree_Id
                    Connect By Budget_Tree_Id = Prior Budget_Tree_Pre_Id
                  )
                --WHERE
                --  Budget_CTL_Flag = v_y
                ORDER BY
                  BUDGET_LEVEL
      ) Loop
        --对于下层节点为不严控，且当前节点为严控(包括对于当前传入的节点为严控)，则检查
        if r_Nod.Budget_CTL_Flag = v_y and V_LOWER_CTL_FLAG = v_n then
          v_Budget_Tree_Desc := r_Nod.budget_Tree_Desc;
          p_Result := Substrb('检查预算余额失败,参数信息:(' || r_Nod.budget_Tree_Desc || ':' ||
                              '预算余额不足,' || ',' ||-- '数据流ID:' ||
                             -- To_Char(p_Data_Flow_Id) || ',' || '主体ID:' ||
                             -- To_Char(p_Entity_Id) || ',' ||
                              '预算单元ID:' || To_Char(r_Nod.Budget_Tree_Id) || ','||
                              '费用金额:' || To_Char(p_Fee) || ')' || v_Nl
                              ,1
                              ,240);

          --锁数据
          --select 0
          --  into v_Lower_CTL_Budget
          --  from t_Mf_Fee_Budget_Total bt
          -- where bt.budget_total_id = r_Nod.Budget_Total_Id
          --   for update nowait;

          Select SUM(decode(bt.Control_Flag
                             ,v_y,Greatest(nvl(bt.Budget_Total_Amount,0),nvl(bt.fee_total_amount,0))
                             ,0
                           )
                 ) --求下层严控预算总额
                 ,sum(decode(bt.Control_Flag
                             ,v_y,0
                             ,bt.fee_total_amount
                           )
                 ) --求下层非严控费用
            into v_Lower_CTL_Budget
                 ,v_Lower_NO_CTL_FEE
            From t_Pol_Budget_Tree  bt
           start with bt.Budget_Tree_Pre_Id = to_char(r_Nod.Budget_Tree_Id)
          connect by (bt.Budget_Tree_Pre_Id = prior to_char(bt.budget_tree_id))
                 and (nvl(prior bt.Control_Flag,v_n) = v_n);

          v_Lower_CTL_Budget :=nvl(v_Lower_CTL_Budget,0);
          v_Lower_NO_CTL_FEE :=nvl(v_Lower_NO_CTL_FEE,0);

          --结点可用费用金额 = 该结点预算-该结点发生的费用-下层严控预算-下层非严控费用
          if r_Nod.Budget_Total_Amount --该结点预算
            - r_Nod.Fee_Total_Amount --该结点发生的费用
            - v_Lower_CTL_Budget --下层严控预算
            - v_Lower_NO_CTL_FEE --下层非严控费用
            < p_Fee
          then
            p_Result := '预算结点:'||v_Nl||v_Budget_Tree_Desc ||v_Nl||'可用预算为'||
                        (r_Nod.Budget_Total_Amount - r_Nod.Fee_Total_Amount - v_Lower_CTL_Budget - v_Lower_NO_CTL_FEE)
                        ||'，不足以执行本次业务操作。';
            v_Ok := v_n;
          end if;

          exit;
        end if;
        --记录当前节点是否严控，作为下级节点严控标志，用于下一循环中
        V_LOWER_CTL_FLAG := r_Nod.Budget_CTL_Flag;
      end loop;
    exception
      when others then
        if Sqlcode = -54 then
          p_Result :=  '预算结点 '||v_Nl||v_Budget_Tree_Desc ||v_Nl||' 正被其它用户锁定不能修改，请稍待再试。';
          v_Ok := v_n;
        else
          raise;
        end if;
    end;
    end if;

    if v_Ok = v_y then
      p_Result := '插入费用单据时出错!信息:' || '数据单元:' || To_Char(p_Budget_Tree_Id);
      --插入费用明细单据，并标识为审核通过
      Insert Into t_Pol_Budget_Fee_Detail
        (Fee_Detail_Id,
        Budget_Tree_Id,
        Entity_Id,
        Fee_Type,
        Fee_Id,
        Fee_Code,
        Fee_Detail_Amount,
        Created_By,
        Creation_Date,
        Last_Updated_By,
        Last_Update_Date,
        Refer_Flag,
        Check_Flag,
        Remark,
        Pre_Field_01,
        Pre_Field_02,
        Pre_Field_03,
        Pre_Field_04,
        Pre_Field_05,
        Pre_Field_06)
      Values
        (s_Pol_Budget_Fee_Detail.Nextval,
        p_Budget_Tree_Id,
        p_Entity_Id,
        p_Fee_Type,
        p_Fee_Id,
        p_Fee_Code,
        p_Fee,
        p_User_Id,
        Sysdate,
        p_User_Id,
        Sysdate,
        v_y,
        v_y,
        p_Comments,
        p_Pre_Field_01,
        p_Pre_Field_02,
        p_Pre_Field_03,
        p_Pre_Field_04,
        p_Pre_Field_05,
        p_Pre_Field_06);

      --2006-12-21王小华增加
      p_Result := '插入费用单据后,回写本层节点时出错!';
      --回写节点费用
      Update t_Pol_Budget_Tree
         Set Fee_Total_Amount = Nvl(Fee_Total_Amount, 0) + Nvl(p_Fee, 0)
       Where Budget_Tree_Id = p_Budget_Tree_Id;

      --2014-08-08操作政策预算树时,回写本期占用和期末余额
      p_Result := '回写本期占用和期末余额时出错!';
      Select Object_Type
        Into v_Budget_Type
        From t_Pol_Budget_Tree
       Where Budget_Tree_Id = p_Budget_Tree_Id;
      if (v_Budget_Type = '1') then
        Update t_Pol_Budget_Tree
           Set Current_Occupation_Amount = Nvl(Fee_Total_Amount, 0),
               Ending_Balance_Amount = Nvl(Last_Year_Amount, 0) + Nvl(Beginning_Balance_Amount, 0) + Nvl(Current_New_Amount, 0) - Nvl(Fee_Total_Amount, 0)
         Where Budget_Tree_Id = p_Budget_Tree_Id;
      end if;

      p_Result := '回写本层节点后,回写上级节点时出错!';
      Update t_Pol_Budget_Tree
         Set Fee_Lower_Amount = Nvl(Fee_Lower_Amount, 0) + Nvl(p_Fee, 0)
       Where Budget_Tree_Id in (Select Budget_Tree_Id
                                    From t_Pol_Budget_Tree
                                    Where Budget_Tree_Id <> p_Budget_Tree_Id
                                   Start With Budget_Tree_Id = p_Budget_Tree_Id
                                 Connect By Budget_Tree_Id = Prior Budget_Tree_Pre_Id);

      --成功处理返回
      p_Result := v_Success;
    end if;
  Exception
    --返回错误信息，回滚到保存点
    When Procedure_Brk_Exp Then
      p_Result := v_Pp || '调用错误：' || v_Nl || p_Result;
    When Ipt_Param_Err_Exp Then
      p_Result := v_Pp || '参数错误：' || p_Result;
    When Sql_Not_Found_Exp Then
      p_Result := v_Pp || '更新无效：' || p_Result;
    When No_Data_Found Then
      p_Result := v_Pp || '查无记录：' || p_Result;
    When Too_Many_Rows Then
      p_Result := v_Pp || '查多记录：' || p_Result;
    When Others Then
      if (Sqlcode = -54) then
        p_Result := v_Pp || '预算节点被其他用户锁定，请稍后再试（'|| '数据流ID: ' ||
                        To_Char(p_Data_Flow_Id) || ',' || '主体ID:' ||
                        To_Char(p_Entity_Id) || ',' ||
                        '预算单元ID:' || To_Char(p_Budget_Tree_Id) || ')';
      else
        p_Result := substrb(v_Pp || '未知错误：' || p_Result || v_Nl || Sqlcode || ': ' || Sqlerrm, 1, 200);
      end if;
  end p_Write_Fee;

 /*===============================================================
  * Program Name:   p_Write_Fee
  * Purpose     :   回写节点费用
   ===============================================================*/
  Procedure p_Write_Fee(p_Data_Flow_Id In Number,
                        --数据流程ID，不能为空
                        p_Entity_Id In Number,
                        --主体ID，不能为空
                        p_Budget_Tree_Id In Number,
                        --预算树单元ID，不能为空
                        p_Fee_Type In Varchar2,
                        --费用类型，不能为空
                        p_Fee_Id In Number,
                        --费用单ID，不能为空
                        p_Fee_Code In Varchar2,
                        --费用单号，不能为空
                        p_Comments In Varchar2,
                        --备注信息
                        p_Pre_Field_01 In Varchar2,
                        --备用字段
                        p_Fee In Number,
                        --费用金额，不能为空，可正可负，两位小数
                        p_User_Id In Number,
                        --用户ID
                        p_Result Out Varchar2
                        --返回结果：成功返回"SUCCESS"，失败返回原因
                        ) Is

    v_Pp Constant Varchar2(80) := '回写节点费用失败，';

  Begin
    --建保存点
    --SAVEPOINT Sp_Write_Fee;

    --检查参数
    If p_Data_Flow_Id Is Null Or p_Entity_Id Is Null Or
       p_Budget_Tree_Id Is Null Or p_Fee_Type Is Null Or p_Fee_Id Is Null Or
       p_Fee_Code Is Null Or
      --Nvl(p_Fee, 0) = 0 OR
      --Nvl(p_Fee, 0) <> Trunc(Nvl(p_Fee, 0), 2) Or --20080904 何加源修改 取消两位小数控制
       p_User_Id Is Null Then
      p_Result := '输入参数分别为(' || To_Char(p_Data_Flow_Id) || ',' ||
                  To_Char(p_Entity_Id) || ',' ||
                  To_Char(p_Budget_Tree_Id) || ',' || p_Fee_Type || ',' ||
                  To_Char(p_Fee_Id) || ',' || p_Fee_Code || ',' ||
                  To_Char(p_Fee) || ',' || To_Char(p_User_Id) || ')';
      Raise Ipt_Param_Err_Exp;
    End If;

    --根据费用是否为0确定处理
    If Nvl(p_Fee, 0) = 0 Then
      --中断处理，成功返回
      p_Result := v_Success;
      Return;
    End If;

    --调用过程回写节点费用
    p_Write_Fee(p_Data_Flow_Id,
                p_Entity_Id,
                p_Budget_Tree_Id,
                p_Fee_Type,
                p_Fee_Id,
                p_Fee_Code,
                p_Comments,
                p_Pre_Field_01,
                Null,
                Null,
                Null,
                Null,
                Null,
                Null,
                Null,
                Null,
                p_Fee,
                p_User_Id,
                p_Result);
    If Nvl(p_Result, v_Null) <> v_Success Then
      Raise Procedure_Brk_Exp;
    End If;

    --成功处理返回
    p_Result := v_Success;
  Exception
    --返回错误信息，回滚到保存点
    When Procedure_Brk_Exp Then
      p_Result := v_Pp || '调用错误：' || v_Nl || p_Result;
      --ROLLBACK TO SAVEPOINT Sp_Write_Fee;
    When Ipt_Param_Err_Exp Then
      p_Result := v_Pp || '参数错误：' || p_Result;
      --ROLLBACK TO SAVEPOINT Sp_Write_Fee;
    When Sql_Not_Found_Exp Then
      p_Result := v_Pp || '更新无效：' || p_Result;
      --ROLLBACK TO SAVEPOINT Sp_Write_Fee;
    When No_Data_Found Then
      p_Result := v_Pp || '查无记录：' || p_Result;
      --ROLLBACK TO SAVEPOINT Sp_Write_Fee;
    When Too_Many_Rows Then
      p_Result := v_Pp || '查多记录：' || p_Result;
      --ROLLBACK TO SAVEPOINT Sp_Write_Fee;
    When Others Then
      p_Result := v_Pp || '未知错误：' || p_Result || v_Nl || Sqlcode || ': ' || Sqlerrm;
      --ROLLBACK TO SAVEPOINT Sp_Write_Fee;
  End p_Write_Fee;

 /*===============================================================
  * Program Name:   p_Write_Fee
  * Purpose     :   回写节点费用
   ===============================================================*/
  Procedure p_Write_Fee(p_Data_Flow_Id In Number,
                        --数据流程ID，不能为空
                        p_Entity_Id In Number,
                        --主体ID，不能为空
                        p_Budget_Segment_01_Id In Number Default -1,
                        --预算层次01IDxing
                        p_Budget_Segment_02_Id In Number Default -1,
                        --预算层次02ID
                        p_Budget_Segment_03_Id In Number Default -1,
                        --预算层次03ID
                        p_Budget_Segment_04_Id In Number Default -1,
                        --预算层次04ID
                        p_Budget_Segment_05_Id In Number Default -1,
                        --预算层次05ID
                        p_Budget_Segment_06_Id In Number Default -1,
                        --预算层次06ID
                        p_Fee_Type In Varchar2,
                        --费用类型，不能为空
                        p_Fee_Id In Number,
                        --费用单ID，不能为空
                        p_Fee_Code In Varchar2,
                        --费用单号，不能为空
                        p_Comments In Varchar2,
                        --备注信息
                        p_Pre_Field_01 In Varchar2,
                        --备用字段
                        p_Fee In Number,
                        --费用金额，不能为空，可正可负，两位小数
                        p_User_Id In Number,
                        --用户ID
                        p_Result Out Varchar2
                        --返回结果：成功返回"SUCCESS"，失败返回原因
                        ) Is

    v_Pp Constant Varchar2(80) := '回写节点费用失败，';

    v_Budget_Tree_Id Number; --预算节点ID

  Begin
    --建保存点
    --SAVEPOINT Sp_Write_Fee;

    --检查参数
    If p_Data_Flow_Id Is Null Or p_Entity_Id Is Null Or
       p_Budget_Segment_01_Id Is Null Or p_Budget_Segment_02_Id Is Null Or
       p_Budget_Segment_03_Id Is Null Or p_Budget_Segment_04_Id Is Null Or
       p_Budget_Segment_05_Id Is Null Or p_Budget_Segment_06_Id Is Null Or
       p_Fee_Type Is Null Or p_Fee_Id Is Null Or p_Fee_Code Is Null Or
      --Nvl(p_Fee, 0) = 0 OR
      --Nvl(p_Fee, 0) <> Trunc(Nvl(p_Fee, 0), 2) Or --20080904 何加源修改 取消两位小数控制
       p_User_Id Is Null Then
      p_Result := '输入参数分别为(' || To_Char(p_Data_Flow_Id) || ',' ||
                  To_Char(p_Entity_Id) || ',' ||
                  To_Char(p_Budget_Segment_01_Id) || ',' ||
                  To_Char(p_Budget_Segment_02_Id) || ',' ||
                  To_Char(p_Budget_Segment_03_Id) || ',' ||
                  To_Char(p_Budget_Segment_04_Id) || ',' ||
                  To_Char(p_Budget_Segment_05_Id) || ',' ||
                  To_Char(p_Budget_Segment_06_Id) || ',' || p_Fee_Type || ',' ||
                  To_Char(p_Fee_Id) || ',' || p_Fee_Code || ',' ||
                  To_Char(p_Fee) || ',' || To_Char(p_User_Id) || ')';
      Raise Ipt_Param_Err_Exp;
    End If;

    --根据费用是否为0确定处理
    If Nvl(p_Fee, 0) = 0 Then
      --中断处理，成功返回
      p_Result := v_Success;
      Return;
    End If;

    --根据层次获取指定预算单元
    p_Result := Substrb(('根据层次获取指定预算单元(' || To_Char(p_Data_Flow_Id) || ',' ||
                        To_Char(p_Entity_Id) || ',' ||
                        To_Char(p_Budget_Segment_01_Id) || ',' ||
                        To_Char(p_Budget_Segment_02_Id) || ',' ||
                        To_Char(p_Budget_Segment_03_Id) || ',' ||
                        To_Char(p_Budget_Segment_04_Id) || ',' ||
                        To_Char(p_Budget_Segment_05_Id) || ',' ||
                        To_Char(p_Budget_Segment_06_Id) || ')' || v_Nl ||
                        '该预算单元不存在，请重新选择，或者联系系统管理员！'),
                        1,
                        240);
    Select Budget_Tree_Id
      Into v_Budget_Tree_Id
      From t_Pol_Budget_Tree
     Where Data_Flow_Id = p_Data_Flow_Id
       And Entity_Id = p_Entity_Id
       And Budget_Segment_01_Id = p_Budget_Segment_01_Id
       And Budget_Segment_02_Id = p_Budget_Segment_02_Id
       And Budget_Segment_03_Id = p_Budget_Segment_03_Id
       And Budget_Segment_04_Id = p_Budget_Segment_04_Id
       And Budget_Segment_05_Id = p_Budget_Segment_05_Id
       And Budget_Segment_06_Id = p_Budget_Segment_06_Id;

    --调用过程回写节点费用
    p_Write_Fee(p_Data_Flow_Id,
                p_Entity_Id,
                v_Budget_Tree_Id,
                p_Fee_Type,
                p_Fee_Id,
                p_Fee_Code,
                p_Comments,
                p_Pre_Field_01,
                Null,
                Null,
                Null,
                Null,
                Null,
                Null,
                Null,
                Null,
                p_Fee,
                p_User_Id,
                p_Result);
    If Nvl(p_Result, v_Null) <> v_Success Then
      Raise Procedure_Brk_Exp;
    End If;

    --成功处理返回
    p_Result := v_Success;
  Exception
    --返回错误信息，回滚到保存点
    When Procedure_Brk_Exp Then
      p_Result := v_Pp || '调用错误：' || v_Nl || p_Result;
      --ROLLBACK TO SAVEPOINT Sp_Write_Fee;
    When Ipt_Param_Err_Exp Then
      p_Result := v_Pp || '参数错误：' || p_Result;
      --ROLLBACK TO SAVEPOINT Sp_Write_Fee;
    When Sql_Not_Found_Exp Then
      p_Result := v_Pp || '更新无效：' || p_Result;
      --ROLLBACK TO SAVEPOINT Sp_Write_Fee;
    When No_Data_Found Then
      p_Result := v_Pp || '查无记录：' || p_Result;
      --ROLLBACK TO SAVEPOINT Sp_Write_Fee;
    When Too_Many_Rows Then
      p_Result := v_Pp || '查多记录：' || p_Result;
      --ROLLBACK TO SAVEPOINT Sp_Write_Fee;
    When Others Then
      p_Result := v_Pp || '未知错误：' || p_Result || v_Nl || Sqlcode || ': ' || Sqlerrm;
      --ROLLBACK TO SAVEPOINT Sp_Write_Fee;
  End p_Write_Fee;

 /*===============================================================
  * Program Name:   p_Direct_Adjust_Budget
  * Purpose     :   直接增加或减少预算的过程
   ===============================================================*/
  Procedure p_Direct_Adjust_Budget(p_Data_Flow_Id In Number,
                                   p_Entity_Id In Number,
                                   p_Budget_Tree_Id In Number,
                                   p_Amount In Number,
                                   p_Budget_Order_Id In Number Default -1,
                                   p_Budget_Order_Code In Varchar2,
                                   p_Adjust_Type In Varchar2,
                                   p_Comments In Varchar2,
                                   p_User_Id In Number,
                                   p_Result Out Varchar2) Is

    v_Pp Constant Varchar2(200) := '从系统外直接追加指定正预算到指定单元（负金额反向）失败，';
    v_Budget_Detail_Id  Number; --预算明细单据ID
    v_Budget_Detail_Ids Varchar2(4000); --预算明细单据ID链
    v_Budget_Type       number; --预算结构类型（1:政策预算;2:费用预算）

  Begin
    --检查参数
    IF p_Data_Flow_Id IS NULL OR p_Entity_Id IS NULL OR
       p_Adjust_Type IS NULL OR p_Budget_Tree_Id IS NULL OR
       NVL(p_Amount, 0) = 0 OR
       NVL(p_Amount, 0) <> TRUNC(NVL(p_Amount, 0), 2) OR p_User_Id IS NULL THEN
      p_Result := '输入参数分别为(' || TO_CHAR(p_Data_Flow_Id) || ',' ||
                  TO_CHAR(p_Entity_Id) || ',' ||
                  TO_CHAR(p_Budget_Tree_Id) || ',' || TO_CHAR(p_User_Id) || ',' ||
                  TO_CHAR(p_Amount) || ')';
      RAISE Ipt_Param_Err_Exp;
    END IF;

    --检查并读锁定预算树单元
    p_Result := '检查并读锁定预算树单元失败(' || TO_CHAR(p_Data_Flow_Id) || ',' ||
                TO_CHAR(p_Entity_Id) || ',' || TO_CHAR(p_Budget_Tree_Id) || ')';

    SELECT V_SUCCESS
      INTO P_RESULT
      FROM t_Pol_Budget_Tree
     WHERE BUDGET_Tree_ID = p_Budget_Tree_Id
       AND DATA_FLOW_ID = p_Data_Flow_Id
       AND ENTITY_ID = p_Entity_Id
       FOR UPDATE NOWAIT;

    --插入预算明细单据表，形成ID链，供下一步审核用
    For r_Nod In (Select Budget_Tree_Id,
                         Sign(Nvl(p_Amount, 0))*Level Level_Num
                    From t_Pol_Budget_Tree
                   Start With Budget_Tree_Id = p_Budget_Tree_Id
                  Connect By Budget_Tree_Id = Prior Budget_Tree_Pre_Id
                   Order By Level_Num Desc) Loop
      --获取预算明细单据ID
      Select s_Pol_Budget_Detail.Nextval
        Into v_Budget_Detail_Id
        From Dual;

      --插入预算明细单据表
      Insert Into t_Pol_Budget_Detail
        (Budget_Detail_Id,
         Budget_Tree_Id,
         Entity_Id,
         Budget_Type,
         Budget_Id,
         Budget_Code,
         Budget_Detail_Amount,
         Created_By,
         Creation_Date,
         Last_Updated_By,
         Last_Update_Date,
         Refer_Flag,
         Check_Flag,
         Remark)
      Values
        (v_Budget_Detail_Id,
         r_Nod.Budget_Tree_Id,
         p_Entity_Id,
         p_Adjust_Type,
         p_Budget_Order_Id,
         Substrb(p_Budget_Order_Code, 1, 20),
         Nvl(p_Amount, 0),
         p_User_Id,
         Sysdate,
         p_User_Id,
         Sysdate,
         v_y,
         v_n,
         Substrb(p_Comments, 1, 240));

      --链接预算明细单据ID
      v_Budget_Detail_Ids := v_Budget_Detail_Ids || To_Char(v_Budget_Detail_Id) || ' ';
    End Loop;

    --审核预算明细单据链
    p_Check_Adjust_Budget_Details(p_Data_Flow_Id,
                                  p_Entity_Id,
                                  v_Budget_Detail_Ids,
                                  p_User_Id,
                                  v_Budget_Detail_Id,
                                  p_Result);
    If Nvl(p_Result, v_Null) <> v_Success Then
      Raise Procedure_Brk_Exp;
    End If;

    --2014-11-25 获取预算结构类型
    Select Object_Type
      Into v_Budget_Type
      From t_Pol_Budget_Tree
     Where Budget_Tree_Id = p_Budget_Tree_Id
       And Data_Flow_Id = p_Data_Flow_Id
       And Entity_Id = p_Entity_Id;

    --2014-11-25 判断是否是政策预算，在当前节点修改一些金额
    If(v_Budget_Type = '1') Then
        --更新本期新增
        Update t_Pol_Budget_Tree
           Set Current_New_Amount = Nvl(Current_New_Amount, 0) +  Nvl(p_Amount, 0)
         Where Budget_Tree_Id = p_Budget_Tree_Id;

        --更新期末余额
        Update t_Pol_Budget_Tree
           Set Ending_Balance_Amount = Nvl(Last_Year_Amount, 0) +  Nvl(Beginning_Balance_Amount, 0) +
               Nvl(Current_New_Amount, 0) - Nvl(Current_Occupation_Amount, 0)
         Where Budget_Tree_Id = p_Budget_Tree_Id;
    End If;

    --成功处理返回
    p_Result := v_Success;
  Exception
    --返回错误信息，回滚到保存点
    When Procedure_Brk_Exp Then
      p_Result := v_Pp || '调用错误：' || v_Nl || p_Result;
      --ROLLBACK TO SAVEPOINT Spi_Direct_Super_Add_Budget;
    When Ipt_Param_Err_Exp Then
      p_Result := v_Pp || '参数错误：' || p_Result;
      --ROLLBACK TO SAVEPOINT Spi_Direct_Super_Add_Budget;
    When Sql_Not_Found_Exp Then
      p_Result := v_Pp || '更新无效：' || p_Result;
      --ROLLBACK TO SAVEPOINT Spi_Direct_Super_Add_Budget;
    When No_Data_Found Then
      p_Result := v_Pp || '查无记录：' || p_Result;
      --ROLLBACK TO SAVEPOINT Spi_Direct_Super_Add_Budget;
    When Too_Many_Rows Then
      p_Result := v_Pp || '查多记录：' || p_Result;
      --ROLLBACK TO SAVEPOINT Spi_Direct_Super_Add_Budget;
    When Others Then
      p_Result := v_Pp || '未知错误：' || p_Result || v_Nl || Sqlcode || ': ' || Sqlerrm;
      --ROLLBACK TO SAVEPOINT Spi_Direct_Super_Add_Budget;
  End p_Direct_Adjust_Budget;

  /*===============================================================
  * Program Name:   p_Check_Adjust_Budget_Detail
  * Purpose     :   不用严控的预算调整明细类型
   ===============================================================*/
  Procedure p_Check_Adjust_Budget_Detail(p_Data_Flow_Id In Number,
                                         --预算流ID
                                         p_Entity_Id In Number,
                                         --主体ID
                                         p_Budget_Detail_Id In Number,
                                         --预算明细单据ID
                                         P_Num_Index In number,
                                         --参数顺序
                                         p_User_Id In Number,
                                         --用户ID
                                         p_Result Out Varchar2
                                         --返回结果：成功返回"SUCCESS"，失败返回原因
                                         ) Is

    v_Pp Constant Varchar2(80) := '审核预算明细单据失败，';

    v_Param_Entity_Id Number; --参数实体ID

    v_Budget_Tree_Id       Number; --预算树单元ID
    v_Budget_Tree_Desc     Varchar2(240); --预算树单元描述
    v_Budget_Tree_Level    Number; --预算树单元层次
    v_Budget_Tree_Value    Number; --预算树单元层次ID
    v_Budget_Tree_Pre_Id   Number; --上级预算树单元ID
    v_Budget_Detail_Amount  Number; --预算明细单据金额
    v_Count                 Number;
    v_True_Data_Flow_Id     Number;
    v_Virtual_Data_Flow_Id  Number;
    v_Virtual_Flag          Varchar2(10);
    v_Budget_Segment_Type   Varchar2(50);
    v_Budget_Segment_Name   Varchar2(50);
    v_Budget_Segment_Level  Number;
    v_Message               Varchar2(200);
    v_Pre_Field_01          Varchar2(10);
    v_Bool                  Boolean;
    v_Return_Message        Varchar2(200);
    v_Flag                  Varchar2(10);
    v_Data_Flow_Level       Number;
    v_Sale_Year_Id          Number;
    v_True_Budget           Number;
    v_Amount                Number;
    v_Flag_01               Varchar2(10);
    v_Flag_02               Varchar2(10);
    v_Flag_03               Varchar2(10);
    v_Flag_04               Varchar2(10);
    Virtual_Budget_Total_Id Number;
    v_RSD_LEVLE_FLAG        Varchar2(1); --20071122 龙海增加
    v_budget_type           varchar2(40);
    v_relax_check           varchar2(10); --是否取消严控
    v_Budget_Type_11        number; --预算树类型
    v_Bgt_Lower_Check_flag    varchar2(10);  --预算金额检查
    v_Ok                     varchar2(1);
    V_LOWER_CTL_FLAG         VARCHAR2(1);  --下层是否严控
    v_Lower_CTL_Budget       number; --下层严控预算
    v_Lower_NO_CTL_FEE       number; --下层非严控费用
    v_Bgt_upper_Need_Check   varchar2(10);  --
  Begin
    --建保存点
    --SAVEPOINT Sp_Check_Budget_Detail;

    --检查参数
    If p_Data_Flow_Id Is Null Or p_Entity_Id Is Null Or
       p_Budget_Detail_Id Is Null Or p_User_Id Is Null Then
      p_Result := '输入参数分别为(' || To_Char(p_Data_Flow_Id) || ',' ||
                  To_Char(p_Entity_Id) || ',' ||
                  To_Char(p_Budget_Detail_Id) || ',' || To_Char(p_User_Id) || ')';
      Raise Ipt_Param_Err_Exp;
    End If;

    v_Ok := v_y;

    --检查并读锁定预算明细单据
    p_Result := '检查并读锁定预算明细单据失败-(' || To_Char(p_Budget_Detail_Id) || ')';
    Select Nvl(Budget_Tree_Id, -1),
           Nvl(Budget_Detail_Amount, 0),
           Budget_Type
      Into v_Budget_Tree_Id, v_Budget_Detail_Amount, v_budget_type --新加获取Budget_Type
      From t_Pol_Budget_Detail
     Where Budget_Detail_Id = p_Budget_Detail_Id
       And Nvl(Refer_Flag, v_Null) = v_y
       And Nvl(Check_Flag, v_Null) = v_n
       And Nvl(Budget_Detail_Amount, 0) <> 0
       And Nvl(Budget_Detail_Amount, 0) =
           Trunc(Nvl(Budget_Detail_Amount, 0), 2)
       For Update Nowait;

    -- 根据参数MF预算调整可不严控和快码DIRECT_ADJUST_TYPE决定是否严控预算
    if v_relax_check = 'Y' then
      begin
        select 'Y'
          into v_relax_check
          from up_Codelist pl
         where pl.codetype = 'DIRECT_ADJUST_TYPE'
           --and sysdate between pl.begin_date and
           --    Nvl(pl.end_date, sysdate + 1)
           and pl.code_value = v_budget_type;
      exception
        when No_Data_Found then
          v_relax_check := 'N';
      end;
    else
      v_relax_check := 'N';
    end if;

    --检查并读锁定预算树单元
    --??? 调出预算时是严格还是宽松？是否需要根据严控标识来判断？
    --底层实现允许宽松调出，高层操作不让调出
    --★★★

     --获取父类节点，用于更新下层预算回写
      Select Budget_Tree_Pre_Id,
             Budget_Tree_Level,
             Decode(Budget_Tree_Level,
                    1, Budget_Segment_01_Id,
                    2, Budget_Segment_02_Id,
                    3, Budget_Segment_03_Id,
                    4, Budget_Segment_04_Id,
                    5, Budget_Segment_05_Id,
                    6, Budget_Segment_06_Id,
                    -1),
             Budget_Tree_Desc
        Into v_Budget_Tree_Pre_Id,
             v_Budget_Tree_Level,
             v_Budget_Tree_Value,
             v_Budget_Tree_Desc
        From t_Pol_Budget_Tree
       Where Budget_Tree_Id = v_Budget_Tree_Id
         And Data_Flow_Id = p_Data_Flow_Id
         And Entity_Id = p_Entity_Id;

   IF (v_budget_type = '2') AND (v_Budget_Detail_Amount > 0) THEN
     --直接追加不判断预算是否足够
     v_Ok := v_y;
   ELSE
    p_Result := '检查并读锁定预算树单元失败(' || To_Char(p_Data_Flow_Id) || ',' ||
                To_Char(p_Entity_Id) || ',' ||
                To_Char(v_Budget_Tree_Id) || ',' ||
                To_Char(v_Budget_Detail_Amount) || ')';

    if v_relax_check = 'Y' then
      Select Budget_Tree_Pre_Id,
             Budget_Tree_Level,
             Decode(Budget_Tree_Level,
                    1, Budget_Segment_01_Id,
                    2, Budget_Segment_02_Id,
                    3, Budget_Segment_03_Id,
                    4, Budget_Segment_04_Id,
                    5, Budget_Segment_05_Id,
                    6, Budget_Segment_06_Id,
                    -1),
             Budget_Tree_Desc
        Into v_Budget_Tree_Pre_Id,
             v_Budget_Tree_Level,
             v_Budget_Tree_Value,
             v_Budget_Tree_Desc
        From t_Pol_Budget_Tree
       Where Budget_Tree_Id = v_Budget_Tree_Id
         And Data_Flow_Id = p_Data_Flow_Id
         And Entity_Id = p_Entity_Id
         And (Nvl(v_Budget_Detail_Amount, 0) < 0 And
             --直接追加或扣减预算时并设置为不检查预算时(v_relax_check = 'Y')取消此项检查
             /*(Nvl(Budget_Total_Amount, 0) + Nvl(v_Budget_Detail_Amount, 0)) >=
                                               Nvl(Budget_Lower_Amount, 0) And
                                               Nvl(Budget_Lower_Amount, 0) >= 0 And*/
             (Nvl(Control_Flag, v_Null) = v_y And
             ((Nvl(Budget_Total_Amount, 0) +
             Nvl(v_Budget_Detail_Amount, 0)) -
             Greatest(Nvl(Fee_Total_Amount, 0), 0) -
             Greatest(Nvl(Budget_Lower_Amount, 0),
                         Nvl(Fee_Lower_Amount, 0),
                         --直接追加或扣减预算时并设置为不检查预算时(v_relax_check = 'Y')不严控
                         --0)) >= 0 Or Nvl(Pre_Field_01, v_Null) = v_n) Or
                         0)) >= 0 Or Nvl('N', v_Null) = v_n) Or --不用严控
             Nvl(v_Budget_Detail_Amount, 0) >= 0)
         For Update Nowait;
         v_Ok := v_y;
    else
      if p_Num_Index = 1 then
        Select Budget_Tree_Pre_Id,
               Budget_Tree_Level,
               Decode(Budget_Tree_Level,
                      1, Budget_Segment_01_Id,
                      2, Budget_Segment_02_Id,
                      3, Budget_Segment_03_Id,
                      4, Budget_Segment_04_Id,
                      5, Budget_Segment_05_Id,
                      6, Budget_Segment_06_Id,
                      -1),
               Budget_Tree_Desc
          Into v_Budget_Tree_Pre_Id,
               v_Budget_Tree_Level,
               v_Budget_Tree_Value,
               v_Budget_Tree_Desc
          From t_Pol_Budget_Tree
         Where Budget_Tree_Id = v_Budget_Tree_Id
           And Data_Flow_Id = p_Data_Flow_Id
           And Entity_Id = p_Entity_Id
           And (Nvl(v_Budget_Detail_Amount, 0) < 0 And
               (Nvl(Budget_Total_Amount, 0) + Nvl(v_Budget_Detail_Amount, 0)) >=
               Nvl(Budget_Lower_Amount, 0) And
               Nvl(Budget_Lower_Amount, 0) >= 0 And
               (Nvl(Control_Flag, v_Null) = v_y And
               ((Nvl(Budget_Total_Amount, 0) +
               Nvl(v_Budget_Detail_Amount, 0)) -
               Greatest(Nvl(Fee_Total_Amount, 0), 0) -
               Greatest(Nvl(Budget_Lower_Amount, 0),
                           Nvl(Fee_Lower_Amount, 0),
                           0)) >= 0 Or Nvl(Control_Flag, v_Null) = v_n) Or
               Nvl(v_Budget_Detail_Amount, 0) >= 0)
           For Update Nowait;
           v_Ok := v_y;
       end if;
    end if;
    --上级预算树单元存在时处理

      v_Bgt_Lower_Check_flag := 'N';
      v_Bgt_upper_Need_Check := 'N';
      For r_Adjust_Line_Nod In
        (
            SELECT
              *
            FROM
              (
                Select Budget_Tree_Id
                       ,Budget_Tree_Desc
                       ,Nvl(Control_Flag, 'N') Budget_CTL_Flag
                       ,bt.budget_tree_level
                       ,Nvl(Budget_Total_Amount, 0) Budget_Total_Amount
                       ,Nvl(Budget_Lower_Amount, 0) Budget_Lower_Amount
                       ,Nvl(Fee_Total_Amount, 0) Fee_Total_Amount
                       ,Nvl(Fee_Lower_Amount, 0) Fee_Lower_Amount
                       ,level BUDGET_LEVEL
                  From t_Pol_Budget_Tree bt
                  Start With Budget_Tree_Id = v_Budget_Tree_Id
                Connect By Budget_Tree_Id = Prior Budget_Tree_Pre_Id
              )
            --WHERE Budget_Tree_Id <> p_Budget_Tree_Id
            ORDER BY
              BUDGET_LEVEL
        )
       Loop

          p_Result := '[预算不允许为负]预算树调整金额后为负数，检查并读锁定预算树单元失败(' || To_Char(p_Data_Flow_Id) || ',' ||
                To_Char(p_Entity_Id) || ',' ||
                To_Char(v_Budget_Tree_Id) || ',' ||
                To_Char(v_Budget_Detail_Amount) || ')';
          Select Budget_Tree_Desc--,
                 --Budget_Tree_Pre_Id
            Into v_Budget_Tree_Desc--,
            --v_Budget_Tree_Pre_Id
            From t_Pol_Budget_Tree
           Where Budget_Tree_Id = r_Adjust_Line_Nod.Budget_Tree_Id;

         --若当前节点等于最下层的节点,首先判断预算金额追加预算后是否为负
         IF (v_Budget_Tree_Id = r_Adjust_Line_Nod.Budget_Tree_Id) And (p_Num_Index = 1) THEN
           BEGIN
             Select
                   Budget_Tree_Level,
                   Decode(Budget_Tree_Level,
                          1, Budget_Segment_01_Id,
                          2, Budget_Segment_02_Id,
                          3, Budget_Segment_03_Id,
                          4, Budget_Segment_04_Id,
                          5, Budget_Segment_05_Id,
                          6, Budget_Segment_06_Id,
                          -1),
                   'Y'
              Into v_Budget_Tree_Level,
                   v_Budget_Tree_Value,
                   v_Bgt_Lower_Check_flag
              From t_Pol_Budget_Tree
             Where Budget_Tree_Id = r_Adjust_Line_Nod.Budget_Tree_Id-- --p_Budget_Tree_Id--
               And Data_Flow_Id = p_Data_Flow_Id
               And Entity_Id = p_Entity_Id
               And (Nvl(v_Budget_Detail_Amount, 0) < 0 And
                   (Nvl(Budget_Total_Amount, 0) + Nvl(v_Budget_Detail_Amount, 0)) >=
                   Nvl(Budget_Lower_Amount, 0) And
                   Nvl(Budget_Lower_Amount, 0) >= 0 And
                   (Nvl(Control_Flag, v_Null) = v_y And
                   ((Nvl(Budget_Total_Amount, 0) + Nvl(v_Budget_Detail_Amount, 0)) -
                   Greatest(Nvl(Fee_Total_Amount, 0), 0) -
                   Greatest(Nvl(Budget_Lower_Amount, 0),
                               Nvl(Fee_Lower_Amount, 0),
                               0)) >= 0 Or Nvl(Control_Flag, v_Null) = v_n) Or
                   Nvl(v_Budget_Detail_Amount, 0) >= 0)
               For Update Nowait;
               v_Bgt_Lower_Check_flag := 'Y';    --无异常则最下层判断通过
              EXCEPTION WHEN OTHERS THEN
               v_Bgt_Lower_Check_flag := 'N';
            END;
            --如果预算判断通过，且为严控，则预算足够
            IF (v_Bgt_Lower_Check_flag = 'Y') and (r_Adjust_Line_Nod.Budget_Ctl_Flag = 'Y') THEN
              v_Ok := v_y;
            END IF;
            --如果最底层预算不严控，且判断通过，需要增加上级预算是否足够
            IF (v_Bgt_Lower_Check_flag = 'Y') and (r_Adjust_Line_Nod.Budget_Ctl_Flag = 'N') THEN
              v_Bgt_upper_Need_Check := v_y;
            END IF;
            --如果预算判断不通过，则为不通过
            IF (v_Bgt_Lower_Check_flag = 'N') THEN
              v_Ok := v_n;
            END IF;
            --如果最底层判断通过， 且不严控，则还需判断上层严控的节点
          ELSIF (v_Budget_Tree_Id <> r_Adjust_Line_Nod.Budget_Tree_Id) AND
             (v_Bgt_Lower_Check_flag = 'Y') AND
             (r_Adjust_Line_Nod.Budget_Ctl_Flag = 'Y') AND
             (v_Bgt_upper_Need_Check = v_y) THEN

            --对于下层节点为不严控，且当前节点为严控(包括对于当前传入的节点为严控)，则检查
            if r_Adjust_Line_Nod.Budget_CTL_Flag = v_y and V_LOWER_CTL_FLAG = v_n then

              v_Budget_Tree_Desc := r_Adjust_Line_Nod.budget_Tree_Desc;
              p_Result := Substrb('检查预算余额失败,参数信息:(' || r_Adjust_Line_Nod.budget_Tree_Desc || ':' ||
                                  '预算余额不足,' || ',' ||-- '数据流ID:' ||
                                 -- To_Char(p_Data_Flow_Id) || ',' || '主体ID:' ||
                                 -- To_Char(p_Entity_Id) || ',' ||
                                  '预算单元ID:' || To_Char(r_Adjust_Line_Nod.Budget_Tree_Id) || ','||
                                  '费用金额:' || To_Char(v_Budget_Detail_Amount) || ')' || v_Nl
                                  ,1
                                  ,240);

              Select SUM(decode(bt.Control_Flag
                                 ,v_y,Greatest(nvl(bt.Budget_Total_Amount,0),nvl(bt.fee_total_amount,0))
                                 ,0
                               )
                     ) --求下层严控预算总额
                     ,sum(decode(bt.Control_Flag
                                 ,v_y,0
                                 ,bt.fee_total_amount
                               )
                     ) --求下层非严控费用
                into v_Lower_CTL_Budget
                     ,v_Lower_NO_CTL_FEE
                From t_Pol_Budget_Tree  bt
               start with bt.Budget_Tree_Pre_Id = to_char(r_Adjust_Line_Nod.Budget_Tree_Id)
              connect by (bt.Budget_Tree_Pre_Id = prior to_char(bt.budget_tree_id))
                     and (nvl(prior bt.Control_Flag,v_n) = v_n);

              v_Lower_CTL_Budget :=nvl(v_Lower_CTL_Budget,0);
              v_Lower_NO_CTL_FEE :=nvl(v_Lower_NO_CTL_FEE,0);

              --结点可用费用金额 = 该结点预算-该结点发生的费用-下层严控预算-下层非严控费用
              if r_Adjust_Line_Nod.Budget_Total_Amount --该结点预算
                - r_Adjust_Line_Nod.Fee_Total_Amount --该结点发生的费用
                - v_Lower_CTL_Budget --下层严控预算
                - v_Lower_NO_CTL_FEE --下层非严控费用
                + v_Budget_Detail_Amount
                 < 0
              then
                p_Result := '预算结点:'||v_Nl||v_Budget_Tree_Desc ||v_Nl||'可用预算为'||
                            (r_Adjust_Line_Nod.Budget_Total_Amount - r_Adjust_Line_Nod.Fee_Total_Amount - v_Lower_CTL_Budget - v_Lower_NO_CTL_FEE)
                            ||'，不足以执行调整预算操作。';
                v_Ok := v_n;
              end if;

              exit;
            end if;
          END IF;

           --记录当前节点是否严控，作为下级节点严控标志，用于下一循环中
           V_LOWER_CTL_FLAG := r_Adjust_Line_Nod.Budget_CTL_Flag;
        END LOOP;
     END IF;

/*    If Nvl(v_Budget_Tree_Pre_Id, -1) <> -1 Then
      --检查并读锁定上级预算树单元
      --预算往下分配时比较宽松，没有考虑下层费用情况
      --★★★

      p_Result := '检查并读锁定上级预算树单元失败(' || To_Char(p_Data_Flow_Id) || ',' ||
                  To_Char(p_Entity_Id) || ',' ||
                  To_Char(v_Budget_Tree_Pre_Id) || ',' ||
                  To_Char(v_Budget_Detail_Amount) || ')';
    if v_relax_check = 'Y' then --是否不严格检查 add by liuhuan
      Select v_Success
        Into p_Result
        From t_Pol_Budget_Tree
       Where Budget_Tree_Id = v_Budget_Tree_Pre_Id
         And Data_Flow_Id = p_Data_Flow_Id
         And Entity_Id = p_Entity_Id
         And (Nvl(v_Budget_Detail_Amount, 0) > 0 And
             --直接追加或扣减预算时并设置为不检查预算时(v_relax_check = 'Y')取消此项检查
             \*Nvl(Budget_Total_Amount, 0) >=
             (Nvl(Budget_Lower_Amount, 0) + Nvl(v_Budget_Detail_Amount, 0)) And
             (Nvl(Budget_Lower_Amount, 0) + Nvl(v_Budget_Detail_Amount, 0)) >= 0 And*\
             (Nvl(Control_Flag, v_Null) = v_y And
             (Nvl(Budget_Total_Amount, 0) -
             Greatest(Nvl(Fee_Total_Amount, 0), 0) -
             Greatest((Nvl(Budget_Lower_Amount, 0) +
                         Nvl(v_Budget_Detail_Amount, 0)),
                         --直接追加或扣减预算时并设置为不检查预算时(v_relax_check = 'Y')不严控
                         \*0)) >= 0 Or Nvl(Pre_Field_01, v_Null) = v_n) Or*\
                         0)) >= 0 Or Nvl('N', v_Null) = v_n) Or
             Nvl(v_Budget_Detail_Amount, 0) <= 0)
         For Update Nowait;
     else
      Select v_Success
        Into p_Result
        From t_Pol_Budget_Tree
       Where Budget_Tree_Id = v_Budget_Tree_Pre_Id
         And Data_Flow_Id = p_Data_Flow_Id
         And Entity_Id = p_Entity_Id
         And (Nvl(v_Budget_Detail_Amount, 0) > 0 And
             Nvl(Budget_Total_Amount, 0) >=
             (Nvl(Budget_Lower_Amount, 0) + Nvl(v_Budget_Detail_Amount, 0)) And
             (Nvl(Budget_Lower_Amount, 0) + Nvl(v_Budget_Detail_Amount, 0)) >= 0 And
             (Nvl(Control_Flag, v_Null) = v_y And
             (Nvl(Budget_Total_Amount, 0) -
             Greatest(Nvl(Fee_Total_Amount, 0), 0) -
             Greatest((Nvl(Budget_Lower_Amount, 0) +
                         Nvl(v_Budget_Detail_Amount, 0)),
                         0)) >= 0 Or Nvl(Control_Flag, v_Null) = v_n) Or
             Nvl(v_Budget_Detail_Amount, 0) <= 0)
         For Update Nowait;
     end if;
    End If;*/

    IF (v_Ok = v_y) THEN
      --修改预算明细单据为审核状态
      Update t_Pol_Budget_Detail
         Set Check_Flag       = v_y,
             Last_Updated_By  = p_User_Id,
             Last_Update_Date = Sysdate
       Where Budget_Detail_Id = p_Budget_Detail_Id;

      --修改预算树单元当前预算金额
      Update t_Pol_Budget_Tree
         Set Budget_Total_Amount = Nvl(Budget_Total_Amount, 0) +
                                   Nvl(v_Budget_Detail_Amount, 0),
             Last_Updated_By     = p_User_Id,
             Last_Update_Date    = Sysdate
       Where Budget_Tree_Id = v_Budget_Tree_Id;

      --修改上级预算树单元下级预算汇总金额
      If Nvl(v_Budget_Tree_Pre_Id, -1) <> -1 Then
        Update t_Pol_Budget_Tree
           Set Budget_Lower_Amount = Nvl(Budget_Lower_Amount, 0) +
                                     Nvl(v_Budget_Detail_Amount, 0),
               Last_Updated_By     = p_User_Id,
               Last_Update_Date    = Sysdate
         Where Budget_Tree_Id = v_Budget_Tree_Pre_Id;
      End If;
    END IF;

    --成功处理返回
    p_Result := v_Success;
  Exception
    --返回错误信息，回滚到保存点
    When Procedure_Brk_Exp Then
      p_Result := v_Pp || '调用错误：' || v_Nl || p_Result;
      --ROLLBACK TO SAVEPOINT Sp_Check_Budget_Detail;
    When Ipt_Param_Err_Exp Then
      p_Result := v_Pp || '参数错误：' || p_Result;
      --ROLLBACK TO SAVEPOINT Sp_Check_Budget_Detail;
    When Sql_Not_Found_Exp Then
      p_Result := v_Pp || '更新无效：' || p_Result;
      --ROLLBACK TO SAVEPOINT Sp_Check_Budget_Detail;
    When No_Data_Found Then
      p_Result := v_Pp || '查无记录：' || p_Result;
      --ROLLBACK TO SAVEPOINT Sp_Check_Budget_Detail;
    When Too_Many_Rows Then
      p_Result := v_Pp || '查多记录：' || p_Result;
      --ROLLBACK TO SAVEPOINT Sp_Check_Budget_Detail;
    When Others Then
      p_Result := v_Pp || '未知错误：' || p_Result || v_Nl || Sqlcode || ': ' || Sqlerrm;
      --ROLLBACK TO SAVEPOINT Sp_Check_Budget_Detail;
  End p_Check_Adjust_Budget_Detail;

 /*===============================================================
  * Program Name:   p_Check_Adjust_Budget_Details
  * Purpose     :   不用严控的预算调整明细类型
   ===============================================================*/
  Procedure p_Check_Adjust_Budget_Details(p_Data_Flow_Id In Number,
                                          --预算流ID
                                          p_Entity_Id In Number,
                                          --主体ID
                                          p_Budget_Detail_Ids In Varchar2,
                                          --预算明细单据ID串（间隔空格）
                                          p_User_Id In Number,
                                          --用户ID
                                          p_Budget_Detail_Id Out Number,
                                          --返回供定位使用的预算明细单据ID
                                          p_Result Out Varchar2
                                          --返回结果：成功返回"SUCCESS"，失败返回原因
                                          ) Is

    v_Pp Constant Varchar2(80) := '批量审核预算明细单据失败，';

    v_Left  Number Not Null := 0; --左点
    v_Right Number Not Null := 0; --右点

    v_Budget_Detail_Ids Varchar2(4000); --预算明细单据ID串

    v_Num_Index number;
    v_BUSINESS_TYPE VARCHAR2(10);
  Begin
    --建保存点
    --SAVEPOINT Sp_Check_Budget_Details;

    --检查参数
    If p_Data_Flow_Id Is Null Or p_Entity_Id Is Null Or
       p_User_Id Is Null Or Nvl(Lengthb(Trim(p_Budget_Detail_Ids)), 0) < 1 Or
       Nvl(Lengthb(Trim(p_Budget_Detail_Ids)), 0) > 1998 Then
      p_Result := '输入参数分别为(' || To_Char(p_Data_Flow_Id) || ',' ||
                  To_Char(p_Entity_Id) || ',' ||
                  To_Char(p_User_Id) || ',' || p_Budget_Detail_Ids || ')';
      Raise Ipt_Param_Err_Exp;
    End If;

    --初始化返回结果
    p_Result := v_Success;

    v_Num_Index := 0;

    --初始化预算明细单据ID串
    v_Budget_Detail_Ids := ' ' || Trim(p_Budget_Detail_Ids) || ' ';

    --分解、检查、审核预算明细ID串
    v_Left := Instrb(v_Budget_Detail_Ids, ' ', 1, 1) + 1;
    Loop
      --初始化预算明细单据ID
      p_Budget_Detail_Id := -1;

      --根据左点定位右点
      v_Right := Instrb(v_Budget_Detail_Ids, ' ', v_Left, 1);

      If v_Right > v_Left
      --根据左点、右点处理
       Then
        --确定预算明细单据ID
        p_Budget_Detail_Id := To_Number(Substrb(v_Budget_Detail_Ids,
                                                v_Left,
                                                v_Right - v_Left));

        --根据右点推进左点
        v_Left := v_Right + 1;
      Elsif v_Right = v_Left
      --多个空格时继续推进左点
       Then
        v_Left := v_Right + 1;
      Else
        --处理完毕，正常关闭循环
        Exit;
      End If;

      v_Num_Index := v_Num_Index + 1;
      --预算明细单据ID存在时处理
      If Nvl(p_Budget_Detail_Id, -1) <> -1 Then
        --审核预算明细单据
        p_Check_Adjust_Budget_Detail(p_Data_Flow_Id,
                                     p_Entity_Id,
                                     p_Budget_Detail_Id,
                                     v_Num_Index,
                                     p_User_Id,
                                     p_Result);
        If Nvl(p_Result, v_Null) <> v_Success Then
          --处理失败，中断返回
          Exit;
        End If;
      End If;
    End Loop;

    --检查处理结果
    If Nvl(p_Result, v_Null) <> v_Success Then
      Raise Procedure_Brk_Exp;
    End If;

    --成功处理返回
    p_Result := v_Success;
  Exception
    --返回错误信息，回滚到保存点
    When Procedure_Brk_Exp Then
      p_Result := v_Pp || '调用错误：' || v_Nl || p_Result;
      --ROLLBACK TO SAVEPOINT Sp_Check_Budget_Details;
    When Ipt_Param_Err_Exp Then
      p_Result := v_Pp || '参数错误：' || p_Result;
      --ROLLBACK TO SAVEPOINT Sp_Check_Budget_Details;
    When Sql_Not_Found_Exp Then
      p_Result := v_Pp || '更新无效：' || p_Result;
      --ROLLBACK TO SAVEPOINT Sp_Check_Budget_Details;
    When No_Data_Found Then
      p_Result := v_Pp || '查无记录：' || p_Result;
      --ROLLBACK TO SAVEPOINT Sp_Check_Budget_Details;
    When Too_Many_Rows Then
      p_Result := v_Pp || '查多记录：' || p_Result;
      --ROLLBACK TO SAVEPOINT Sp_Check_Budget_Details;
    When Others Then
      p_Result := v_Pp || '未知错误：' || p_Result || v_Nl || Sqlcode || ': ' || Sqlerrm;
      --ROLLBACK TO SAVEPOINT Sp_Check_Budget_Details;
  End p_Check_Adjust_Budget_Details;

 /*===============================================================
  * Program Name:   p_Check_Budget_Detail
  * Purpose     :   审核预算明细单据
   ===============================================================*/
  Procedure p_Check_Budget_Detail(p_Data_Flow_Id In Number,
                                  --预算流ID
                                  p_Entity_Id In Number,
                                  --主体ID
                                  p_Budget_Detail_Id In Number,
                                  --预算明细单据ID
                                  p_User_Id In Number,
                                  --用户ID
                                  p_Result Out Varchar2
                                  --返回结果：成功返回"SUCCESS"，失败返回原因
                                  ) Is

    v_Pp Constant Varchar2(80) := '审核预算明细单据失败，';

    v_Param_Entity_Id Number; --参数实体ID

    v_Budget_Tree_Id       Number; --预算树单元ID
    v_Budget_Tree_Desc     Varchar2(240); --预算树单元描述
    v_Budget_Tree_Level    Number; --预算树单元层次
    v_Budget_Tree_Value    Number; --预算树单元层次ID
    v_Budget_Tree_Pre_Id   Number; --上级预算树单元ID
    v_Budget_Detail_Amount  Number; --预算明细单据金额
    v_Count                 Number;
    v_True_Data_Flow_Id     Number;
    v_Virtual_Data_Flow_Id  Number;
    v_Virtual_Flag          Varchar2(10);
    v_Budget_Segment_Type   Varchar2(50);
    v_Budget_Segment_Name   Varchar2(50);
    v_Budget_Segment_Level  Number;
    v_Message               Varchar2(200);
    v_Pre_Field_01          Varchar2(10);
    v_Bool                  Boolean;
    v_Return_Message        Varchar2(200);
    v_Flag                  Varchar2(10);
    v_Data_Flow_Level       Number;
    v_Sale_Year_Id          Number;
    v_True_Budget           Number;
    v_Amount                Number;
    v_Flag_01               Varchar2(10);
    v_Flag_02               Varchar2(10);
    v_Flag_03               Varchar2(10);
    v_Flag_04               Varchar2(10);
    Virtual_Budget_Tree_Id Number;
    v_RSD_LEVLE_FLAG        Varchar2(1); --20071122 龙海增加
  Begin
    --建保存点
    --SAVEPOINT Sp_Check_Budget_Detail;

    --检查参数
    If p_Data_Flow_Id Is Null Or p_Entity_Id Is Null Or
       p_Budget_Detail_Id Is Null Or p_User_Id Is Null Then
      p_Result := '输入参数分别为(' || To_Char(p_Data_Flow_Id) || ',' ||
                  To_Char(p_Entity_Id) || ',' ||
                  To_Char(p_Budget_Detail_Id) || ',' || To_Char(p_User_Id) || ')';
      Raise Ipt_Param_Err_Exp;
    End If;

    --获取虚拟预算控制参数
    --Pkg_Sm.p_Sm_Get_Entity_Param('MF虚拟预算忽略错误', p_Entity_Id, v_Virtual_Flag);

    --检查并读锁定预算明细单据
    p_Result := '检查并读锁定预算明细单据失败-(' || To_Char(p_Budget_Detail_Id) || ')';
    Select Nvl(Budget_Tree_Id, -1), Nvl(Budget_Detail_Amount, 0)
      Into v_Budget_Tree_Id, v_Budget_Detail_Amount
      From t_Pol_Budget_Detail
     Where Budget_Detail_Id = p_Budget_Detail_Id
       And Nvl(Refer_Flag, v_Null) = v_y
       And Nvl(Check_Flag, v_Null) = v_n
       And Nvl(Budget_Detail_Amount, 0) <> 0
       And Nvl(Budget_Detail_Amount, 0) =
           Trunc(Nvl(Budget_Detail_Amount, 0), 2)
       For Update Nowait;

    --检查并读锁定预算树单元
    --??? 调出预算时是严格还是宽松？是否需要根据严控标识来判断？
    --底层实现允许宽松调出，高层操作不让调出
    --★★★

    p_Result := '检查并读锁定预算树单元失败(' || To_Char(p_Data_Flow_Id) || ',' ||
                To_Char(p_Entity_Id) || ',' ||
                To_Char(v_Budget_Tree_Id) || ',' ||
                To_Char(v_Budget_Detail_Amount) || ')';
    Select Budget_Tree_Pre_Id,
           Budget_Tree_Level,
           Decode(Budget_Tree_Level,
                  1, Budget_Segment_01_Id,
                  2, Budget_Segment_02_Id,
                  3, Budget_Segment_03_Id,
                  4, Budget_Segment_04_Id,
                  5, Budget_Segment_05_Id,
                  6, Budget_Segment_06_Id,
                  -1),
           Budget_Tree_Desc
      Into v_Budget_Tree_Pre_Id,
           v_Budget_Tree_Level,
           v_Budget_Tree_Value,
           v_Budget_Tree_Desc
      From t_Pol_Budget_Tree
     Where Budget_Tree_Id = v_Budget_Tree_Id
       And Data_Flow_Id = p_Data_Flow_Id
       And Entity_Id = p_Entity_Id
       And (Nvl(v_Budget_Detail_Amount, 0) < 0 And
           (Nvl(Budget_Total_Amount, 0) + Nvl(v_Budget_Detail_Amount, 0)) >=
           Nvl(Budget_Lower_Amount, 0) And
           Nvl(Budget_Lower_Amount, 0) >= 0 And
           (Nvl(Control_Flag, v_Null) = v_y And
           ((Nvl(Budget_Total_Amount, 0) + Nvl(v_Budget_Detail_Amount, 0)) -
           Greatest(Nvl(Fee_Total_Amount, 0), 0) -
           Greatest(Nvl(Budget_Lower_Amount, 0),
                       Nvl(Fee_Lower_Amount, 0),
                       0)) >= 0 Or Nvl(Control_Flag, v_Null) = v_n) Or
          -- F_GET_Segment03(BUDGET_SEGMENT_03_NAME, p_Entity_Id)='Y' Or

           Nvl(v_Budget_Detail_Amount, 0) >= 0)
       For Update Nowait;

    --上级预算树单元存在时处理

    If Nvl(v_Budget_Tree_Pre_Id, -1) <> -1 Then
      --检查并读锁定上级预算树单元
      --预算往下分配时比较宽松，没有考虑下层费用情况
      --★★★

      p_Result := '检查并读锁定上级预算树单元失败(' || To_Char(p_Data_Flow_Id) || ',' ||
                  To_Char(p_Entity_Id) || ',' ||
                  To_Char(v_Budget_Tree_Pre_Id) || ',' ||
                  To_Char(v_Budget_Detail_Amount) || ')';
      Select v_Success
        Into p_Result
        From t_Pol_Budget_Tree
       Where Budget_Tree_Id = v_Budget_Tree_Pre_Id
         And Data_Flow_Id = p_Data_Flow_Id
         And Entity_Id = p_Entity_Id
         And (Nvl(v_Budget_Detail_Amount, 0) > 0 And
             Nvl(Budget_Total_Amount, 0) >=
             (Nvl(Budget_Lower_Amount, 0) + Nvl(v_Budget_Detail_Amount, 0)) And
             (Nvl(Budget_Lower_Amount, 0) + Nvl(v_Budget_Detail_Amount, 0)) >= 0 And
             (Nvl(Control_Flag, v_Null) = v_y And
             (Nvl(Budget_Total_Amount, 0) -
             Greatest(Nvl(Fee_Total_Amount, 0), 0) -
             Greatest((Nvl(Budget_Lower_Amount, 0) +
                         Nvl(v_Budget_Detail_Amount, 0)),
                         0)) >= 0 Or Nvl(Control_Flag, v_Null) = v_n) Or
             Nvl(v_Budget_Detail_Amount, 0) <= 0)
         For Update Nowait;
    End If;

    --备用金调整同步财务处理
    --检查全局变量标识，是否进入预付款处理
    If Nvl(v_Chk_Bgt_Change_Flag, v_Null) = v_y Then
      --形成参数实体ID
      Select To_Number(To_Char(v_Budget_Tree_Value) ||
                       To_Char(p_Data_Flow_Id) ||
                       To_Char(p_Entity_Id) ||
                       To_Char(v_Budget_Tree_Level))
        Into v_Param_Entity_Id
        From Dual;

      --检查当前预算流、主主体、预算层次是否是否是备用金一层
      --Pkg_Pub_f_p.p_Chk_Param('备用金调整时做预付款', v_y, 'ENTITY', v_Param_Entity_Id, p_Result);
      /*If Nvl(p_Result, v_Null) = v_Success Then
        --不允许备用金如此调整
        p_Result := '备用金不能如此调整，只能通过发放、报账、回收处理';
        Raise Procedure_Brk_Exp;
      End If;*/
    End If;

    --修改预算明细单据为审核状态
    Update t_Pol_Budget_Detail
       Set Check_Flag       = v_y,
           Last_Updated_By  = p_User_Id,
           Last_Update_Date = Sysdate
     Where Budget_Detail_Id = p_Budget_Detail_Id;

    --修改预算树单元当前预算金额
    Update t_Pol_Budget_Tree
       Set Budget_Total_Amount = Nvl(Budget_Total_Amount, 0) +
                                 Nvl(v_Budget_Detail_Amount, 0),
           Last_Updated_By     = p_User_Id,
           Last_Update_Date    = Sysdate
     Where Budget_Tree_Id = v_Budget_Tree_Id;

    --修改上级预算树单元下级预算汇总金额
    If Nvl(v_Budget_Tree_Pre_Id, -1) <> -1 Then
      Update t_Pol_Budget_Tree
         Set Budget_Lower_Amount = Nvl(Budget_Lower_Amount, 0) +
                                   Nvl(v_Budget_Detail_Amount, 0),
             Last_Updated_By     = p_User_Id,
             Last_Update_Date    = Sysdate
       Where Budget_Tree_Id = v_Budget_Tree_Pre_Id;
    End If;

    --成功处理返回
    p_Result := v_Success;
  Exception
    --返回错误信息，回滚到保存点
    When Procedure_Brk_Exp Then
      p_Result := v_Pp || '调用错误：' || v_Nl || p_Result;
      --ROLLBACK TO SAVEPOINT Sp_Check_Budget_Detail;
    When Ipt_Param_Err_Exp Then
      p_Result := v_Pp || '参数错误：' || p_Result;
      --ROLLBACK TO SAVEPOINT Sp_Check_Budget_Detail;
    When Sql_Not_Found_Exp Then
      p_Result := v_Pp || '更新无效：' || p_Result;
      --ROLLBACK TO SAVEPOINT Sp_Check_Budget_Detail;
    When Check_Data_Exp Then
      p_Result := v_Pp || '检查失败：' || p_Result;
    When No_Data_Found Then
      p_Result := v_Pp || '查无记录：' || p_Result;
      --ROLLBACK TO SAVEPOINT Sp_Check_Budget_Detail;
    When Too_Many_Rows Then
      p_Result := v_Pp || '查多记录：' || p_Result;
      --ROLLBACK TO SAVEPOINT Sp_Check_Budget_Detail;
    When Others Then
      p_Result := v_Pp || '未知错误：' || p_Result || v_Nl || Sqlcode || ': ' || Sqlerrm;
      --ROLLBACK TO SAVEPOINT Sp_Check_Budget_Detail;
  End p_Check_Budget_Detail;

 /*===============================================================
  * Program Name:   p_Check_Budget_Detail
  * Purpose     :   审核预算明细单据
   ===============================================================*/
  Procedure p_Check_Budget_Detail(p_Data_Flow_Id In Number,
                                  --预算流ID
                                  p_Entity_Id In Number,
                                  --主体ID
                                  p_Budget_Detail_Id In Number,
                                  --预算明细单据ID
                                  p_Chk_Bgt_Change_Flag In Varchar2,
                                  --备用金调整
                                  p_User_Id In Number,
                                  --用户ID
                                  p_Result Out Varchar2
                                  --返回结果：成功返回"SUCCESS"，失败返回原因
                                  ) Is

    v_Pp Constant Varchar2(80) := '审核预算明细单据失败，';

  Begin
    --建保存点
    Savepoint Sp_Check_Budget_Detail;

    --检查参数
    If p_Data_Flow_Id Is Null Or p_Entity_Id Is Null Or
       p_Budget_Detail_Id Is Null Or
       Nvl(p_Chk_Bgt_Change_Flag, v_Null) Not In (v_n, v_y) Or
       p_User_Id Is Null Then
      p_Result := '输入参数分别为(' || To_Char(p_Data_Flow_Id) || ',' ||
                  To_Char(p_Entity_Id) || ',' ||
                  To_Char(p_Budget_Detail_Id) || ',' ||
                  p_Chk_Bgt_Change_Flag || ',' || To_Char(p_User_Id) || ')';
      Raise Ipt_Param_Err_Exp;
    End If;

    --更新全局变量
    Select Decode(Nvl(p_Chk_Bgt_Change_Flag, v_Null), v_n, v_n, v_y)
      Into v_Chk_Bgt_Change_Flag
      From Dual;

    --检查并读锁定预算明细单据
    p_Check_Budget_Detail(p_Data_Flow_Id,
                          p_Entity_Id,
                          p_Budget_Detail_Id,
                          p_User_Id,
                          p_Result);
    If Nvl(p_Result, v_Null) <> v_Success Then
      Raise Procedure_Brk_Exp;
    End If;

    --将全局变量恢复原值
    v_Chk_Bgt_Change_Flag := v_y;

    --成功处理返回
    p_Result := v_Success;
  Exception
    --返回错误信息，回滚到保存点
    When Procedure_Brk_Exp Then
      p_Result := v_Pp || '调用错误：' || v_Nl || p_Result;
      Rollback To Savepoint Sp_Check_Budget_Detail;
    When Ipt_Param_Err_Exp Then
      p_Result := v_Pp || '参数错误：' || p_Result;
      Rollback To Savepoint Sp_Check_Budget_Detail;
    When Sql_Not_Found_Exp Then
      p_Result := v_Pp || '更新无效：' || p_Result;
      Rollback To Savepoint Sp_Check_Budget_Detail;
    When No_Data_Found Then
      p_Result := v_Pp || '查无记录：' || p_Result;
      Rollback To Savepoint Sp_Check_Budget_Detail;
    When Too_Many_Rows Then
      p_Result := v_Pp || '查多记录：' || p_Result;
      Rollback To Savepoint Sp_Check_Budget_Detail;
    When Others Then
      p_Result := v_Pp || '未知错误：' || p_Result || v_Nl || Sqlcode || ': ' || Sqlerrm;
      Rollback To Savepoint Sp_Check_Budget_Detail;
  End p_Check_Budget_Detail;

 /*===============================================================
  * Program Name:   p_Check_Budget_Details
  * Purpose     :   批量审核预算明细单据
   ===============================================================*/
  Procedure p_Check_Budget_Details(p_Data_Flow_Id In Number,
                                   --预算流ID
                                   p_Entity_Id In Number,
                                   --主体ID
                                   p_Budget_Detail_Ids In Varchar2,
                                   --预算明细单据ID串（间隔空格）
                                   p_User_Id In Number,
                                   --用户ID
                                   p_Budget_Detail_Id Out Number,
                                   --返回供定位使用的预算明细单据ID
                                   p_Result Out Varchar2
                                   --返回结果：成功返回"SUCCESS"，失败返回原因
                                   ) Is

    v_Pp Constant Varchar2(80) := '批量审核预算明细单据失败，';

    v_Left  Number Not Null := 0; --左点
    v_Right Number Not Null := 0; --右点

    v_Budget_Detail_Ids Varchar2(4000); --预算明细单据ID串

  Begin
    --建保存点
    --SAVEPOINT Sp_Check_Budget_Details;

    --检查参数
    If p_Data_Flow_Id Is Null Or p_Entity_Id Is Null Or
       p_User_Id Is Null Or Nvl(Lengthb(Trim(p_Budget_Detail_Ids)), 0) < 1 Or
       Nvl(Lengthb(Trim(p_Budget_Detail_Ids)), 0) > 1998 Then
      p_Result := '输入参数分别为(' || To_Char(p_Data_Flow_Id) || ',' ||
                  To_Char(p_Entity_Id) || ',' ||
                  To_Char(p_User_Id) || ',' || p_Budget_Detail_Ids || ')';
      Raise Ipt_Param_Err_Exp;
    End If;

    --初始化返回结果
    p_Result := v_Success;

    --初始化预算明细单据ID串
    v_Budget_Detail_Ids := ' ' || Trim(p_Budget_Detail_Ids) || ' ';

    --分解、检查、审核预算明细ID串
    v_Left := Instrb(v_Budget_Detail_Ids, ' ', 1, 1) + 1;
    Loop
      --初始化预算明细单据ID
      p_Budget_Detail_Id := -1;

      --根据左点定位右点
      v_Right := Instrb(v_Budget_Detail_Ids, ' ', v_Left, 1);

      If v_Right > v_Left
      --根据左点、右点处理
       Then
        --确定预算明细单据ID
        p_Budget_Detail_Id := To_Number(Substrb(v_Budget_Detail_Ids,
                                                v_Left,
                                                v_Right - v_Left));

        --根据右点推进左点
        v_Left := v_Right + 1;
      Elsif v_Right = v_Left
      --多个空格时继续推进左点
       Then
        v_Left := v_Right + 1;
      Else
        --处理完毕，正常关闭循环
        Exit;
      End If;

      --预算明细单据ID存在时处理
      If Nvl(p_Budget_Detail_Id, -1) <> -1 Then
        --审核预算明细单据
        p_Check_Budget_Detail(p_Data_Flow_Id,
                              p_Entity_Id,
                              p_Budget_Detail_Id,
                              p_User_Id,
                              p_Result);
        If Nvl(p_Result, v_Null) <> v_Success Then
          --处理失败，中断返回
          Exit;
        End If;
      End If;
    End Loop;

    --检查处理结果
    If Nvl(p_Result, v_Null) <> v_Success Then
      Raise Procedure_Brk_Exp;
    End If;

    --成功处理返回
    p_Result := v_Success;
  Exception
    --返回错误信息，回滚到保存点
    When Procedure_Brk_Exp Then
      p_Result := v_Pp || '调用错误：' || v_Nl || p_Result;
      --ROLLBACK TO SAVEPOINT Sp_Check_Budget_Details;
    When Ipt_Param_Err_Exp Then
      p_Result := v_Pp || '参数错误：' || p_Result;
      --ROLLBACK TO SAVEPOINT Sp_Check_Budget_Details;
    When Sql_Not_Found_Exp Then
      p_Result := v_Pp || '更新无效：' || p_Result;
      --ROLLBACK TO SAVEPOINT Sp_Check_Budget_Details;
    When No_Data_Found Then
      p_Result := v_Pp || '查无记录：' || p_Result;
      --ROLLBACK TO SAVEPOINT Sp_Check_Budget_Details;
    When Too_Many_Rows Then
      p_Result := v_Pp || '查多记录：' || p_Result;
      --ROLLBACK TO SAVEPOINT Sp_Check_Budget_Details;
    When Others Then
      p_Result := v_Pp || '未知错误：' || p_Result || v_Nl || Sqlcode || ': ' || Sqlerrm;
      --ROLLBACK TO SAVEPOINT Sp_Check_Budget_Details;
  End p_Check_Budget_Details;

 /*===============================================================
  * Program Name:   p_Check_Budget_Details
  * Purpose     :   批量审核预算明细单据
   ===============================================================*/
  Procedure p_Check_Budget_Details(p_Data_Flow_Id In Number,
                                   --预算流ID
                                   p_Entity_Id In Number,
                                   --主体ID
                                   p_Budget_Detail_Ids In Varchar2,
                                   --预算明细单据ID串（间隔空格）
                                   p_Chk_Bgt_Change_Flag In Varchar2,
                                   --备用金调整
                                   p_User_Id In Number,
                                   --用户ID
                                   p_Budget_Detail_Id Out Number,
                                   --返回供定位使用的预算明细单据ID
                                   p_Result Out Varchar2
                                   --返回结果：成功返回"SUCCESS"，失败返回原因
                                   ) Is

    v_Pp Constant Varchar2(80) := '批量审核预算明细单据失败，';

  Begin
    --建保存点
    Savepoint Sp_Check_Budget_Details;

    --检查参数
    If p_Data_Flow_Id Is Null Or p_Entity_Id Is Null Or
       Nvl(p_Chk_Bgt_Change_Flag, v_Null) Not In (v_n, v_y) Or
       p_User_Id Is Null Or Nvl(Lengthb(Trim(p_Budget_Detail_Ids)), 0) < 1 Or
       Nvl(Lengthb(Trim(p_Budget_Detail_Ids)), 0) > 1998 Then
      p_Result := '输入参数分别为(' || To_Char(p_Data_Flow_Id) || ',' ||
                  To_Char(p_Entity_Id) || ',' ||
                  p_Chk_Bgt_Change_Flag || ',' || To_Char(p_User_Id) || ',' ||
                  p_Budget_Detail_Ids || ')';
      Raise Ipt_Param_Err_Exp;
    End If;

    --更新全局变量
    Select Decode(Nvl(p_Chk_Bgt_Change_Flag, v_Null), v_n, v_n, v_y)
      Into v_Chk_Bgt_Change_Flag
      From Dual;

    --检查并读锁定预算明细单据
    p_Check_Budget_Details(p_Data_Flow_Id,
                           p_Entity_Id,
                           p_Budget_Detail_Ids,
                           p_User_Id,
                           p_Budget_Detail_Id,
                           p_Result);
    If Nvl(p_Result, v_Null) <> v_Success Then
      Raise Procedure_Brk_Exp;
    End If;

    --将全局变量恢复原值
    v_Chk_Bgt_Change_Flag := v_y;

    --成功处理返回
    p_Result := v_Success;
  Exception
    --返回错误信息，回滚到保存点
    When Procedure_Brk_Exp Then
      p_Result := v_Pp || '调用错误：' || v_Nl || p_Result;
      Rollback To Savepoint Sp_Check_Budget_Details;
    When Ipt_Param_Err_Exp Then
      p_Result := v_Pp || '参数错误：' || p_Result;
      Rollback To Savepoint Sp_Check_Budget_Details;
    When Sql_Not_Found_Exp Then
      p_Result := v_Pp || '更新无效：' || p_Result;
      Rollback To Savepoint Sp_Check_Budget_Details;
    When No_Data_Found Then
      p_Result := v_Pp || '查无记录：' || p_Result;
      Rollback To Savepoint Sp_Check_Budget_Details;
    When Too_Many_Rows Then
      p_Result := v_Pp || '查多记录：' || p_Result;
      Rollback To Savepoint Sp_Check_Budget_Details;
    When Others Then
      p_Result := v_Pp || '未知错误：' || p_Result || v_Nl || Sqlcode || ': ' || Sqlerrm;
      Rollback To Savepoint Sp_Check_Budget_Details;
  End p_Check_Budget_Details;

 /*===============================================================
  * Program Name:   p_Budget_Detail_Import
  * Purpose     :   预算明细导入
   ===============================================================*/
  Procedure p_Budget_Detail_Import(pTopLevel_ID in T_POL_BUDGET_TREE.BUDGET_TREE_ID%type,
                                   --预算树ID
                                   pIMP_ID in T_POL_BUDGET_DETAIL_IMPORT.IMP_ID%type,
                                   --导入批号
                                   pUserID in number,
                                   --用户ID
                                   pResult in out Varchar2
                                   --返回值
                                   ) is
  begin
    Savepoint FuncStart;
    for vTemp in (select t.budget_tree_id,
                         t.data_flow_id,
                         t.entity_id,
                         nvl(i.budget_type, '直接追加') budget_type,
                         i.budget_detail_amount,
                         i.remark
                    from t_Pol_Budget_Detail_Import i,
                         t_Pol_Budget_Tree         t
                   where t.budget_segment_02_code || '' =
                         i.level2_code || ''
                     and nvl(t.budget_segment_03_code, 'NULL') || '' =
                         nvl(i.level3_code, 'NULL') || ''
                     and nvl(t.budget_segment_04_code, 'NULL') || '' =
                         nvl(i.level4_code, 'NULL') || ''
                     and nvl(t.budget_segment_05_code, 'NULL') || '' =
                         nvl(i.level5_code, 'NULL') || ''
                     and nvl(t.budget_segment_06_code, 'NULL') || '' =
                         nvl(i.level6_code, 'NULL') || ''
                     and (t.data_flow_id, t.entity_id,
                          t.budget_segment_01_id) =
                         (select h.data_flow_id,
                                 h.entity_id,
                                 h.budget_segment_01_id
                            from t_Pol_Budget_Tree h
                           where h.budget_tree_id = pTopLevel_ID)
                     and i.imp_id = pIMP_ID) loop
      pkg_budget.p_Direct_Super_Add_Budget(vTemp.data_flow_id, -- IN NUMBER, --预算流ID
                                           vTemp.Entity_ID, -- IN NUMBER, --主体ID
                                           vTemp.budget_tree_id, -- IN NUMBER, --预算树单元ID
                                           vTemp.budget_detail_amount, -- IN NUMBER, --追加指定预算
                                           -1, --p_Budget_Order_Id  IN NUMBER DEFAULT -1, --预算操作关联单据ID
                                           null, --p_Budget_Order_Code  IN VARCHAR2, --预算操作管理单据编码
                                           vTemp.remark, --IN VARCHAR2, --备注信息
                                           pUserID, --p_User_Id  IN NUMBER, --用户ID
                                           pResult -- OUT VARCHAR2 --返回结果：成功返回"SUCCESS"，失败返回原因
                                           );
      if (pResult <> 'SUCCESS') THEN
        rollback to Savepoint FuncStart;
        exit;
      end if;
    end loop;
    delete t_Pol_Budget_Detail_Import i where i.imp_id = pIMP_ID;
  end p_Budget_Detail_Import;

 /*===============================================================
  * Program Name:   p_Budget_Detail_Import
  * Purpose     :   预算明细导入
   ===============================================================*/
  Procedure p_Budget_Detail_Import(PTOPLEVEL_ID IN T_POL_BUDGET_TREE.BUDGET_TREE_ID%type,
                                   --预算树ID
                                   PIMP_ID IN T_POL_BUDGET_DETAIL_IMPORT.IMP_ID%type,
                                   --导入批号
                                   PUSERID IN number,
                                   --用户ID
                                   PCANERROR IN Varchar2,
                                   --允许导入出错
                                   -- N: 不允许导入出错，有错误则全部终止。
                                   -- Y: 允许导入出错，有错跳过。
                                   PRESULT IN OUT Varchar2
                                   --返回值
                                   ) is

    CURSOR C_TEMP IS
      SELECT T.BUDGET_Tree_ID,
             T.DATA_FLOW_ID,
             T.ENTITY_ID,
             NVL(I.BUDGET_TYPE, '直接追加') BUDGET_TYPE,
             I.BUDGET_DETAIL_AMOUNT,
             I.REMARK,
             I.ID
        FROM t_Pol_Budget_Detail_Import I,
             t_Pol_Budget_Tree         T,
             t_Pol_Budget_Tree         H
       WHERE T.BUDGET_SEGMENT_02_CODE || '' = I.LEVEL2_CODE || ''
         AND NVL(T.BUDGET_SEGMENT_03_CODE, 'NULL') || '' =
             NVL(I.LEVEL3_CODE, 'NULL') || ''
         AND NVL(T.BUDGET_SEGMENT_04_CODE, 'NULL') || '' =
             NVL(I.LEVEL4_CODE, 'NULL') || ''
         AND NVL(T.BUDGET_SEGMENT_05_CODE, 'NULL') || '' =
             NVL(I.LEVEL5_CODE, 'NULL') || ''
         AND NVL(T.BUDGET_SEGMENT_06_CODE, 'NULL') || '' =
             NVL(I.LEVEL6_CODE, 'NULL') || ''
         AND T.DATA_FLOW_ID = H.DATA_FLOW_ID
         AND T.ENTITY_ID = H.ENTITY_ID
         AND T.BUDGET_SEGMENT_01_ID = H.BUDGET_SEGMENT_01_ID
         AND H.Budget_Tree_Id = PTOPLEVEL_ID
         AND I.IMP_ID = PIMP_ID
       ORDER BY I.BUDGET_DETAIL_AMOUNT DESC;

    VBI_ID  VARCHAR2(4000);
    VRESULT VARCHAR2(4000);
    R_TEMP  C_TEMP%ROWTYPE;
  BEGIN
    SAVEPOINT FUNCSTART;
    VRESULT := 'SUCCESS';

    FOR VTEMP IN C_TEMP LOOP

      PKG_BUDGET.P_DIRECT_SUPER_ADD_BUDGET(VTEMP.DATA_FLOW_ID, -- IN NUMBER, --预算流ID
                                           VTEMP.ENTITY_ID, -- IN NUMBER, --主体ID
                                           VTEMP.BUDGET_Tree_ID, -- IN NUMBER, --预算树单元ID
                                           VTEMP.BUDGET_DETAIL_AMOUNT, -- IN NUMBER, --追加指定预算
                                           -1, --P_BUDGET_ORDER_ID  IN NUMBER DEFAULT -1, --预算操作关联单据ID
                                           NULL, --P_BUDGET_ORDER_CODE  IN VARCHAR2, --预算操作管理单据编码
                                           VTEMP.REMARK, --IN VARCHAR2, --备注信息
                                           PUSERID, --P_USER_ID IN NUMBER, --用户ID
                                           PRESULT -- OUT VARCHAR2 --返回结果：成功返回"SUCCESS"，失败返回原因
                                           );

      IF (PCANERROR = 'N') AND (PRESULT <> 'SUCCESS') THEN
        ROLLBACK TO SAVEPOINT FUNCSTART;
        EXIT;
      END IF;

      IF (PCANERROR = 'Y') AND (PRESULT <> 'SUCCESS') THEN
        VBI_ID  := VBI_ID || TO_CHAR(VTEMP.ID) || ',';
        VRESULT := PRESULT;

        EXECUTE IMMEDIATE 'UPDATE T_POL_BUDGET_DETAIL_IMPORT SET ERROR_COMMENTS=''' ||
                          PRESULT || '''' || ' WHERE IMP_ID = ' ||
                          TO_CHAR(PIMP_ID) || ' AND BI_ID =' || TO_CHAR(VTEMP.ID);
      END IF;

    END LOOP;

    OPEN C_TEMP;
    FETCH C_TEMP
      INTO R_TEMP;

    IF C_TEMP%NOTFOUND THEN
      RAISE NO_DATA_FOUND;
    END IF;

    IF LENGTH(VBI_ID) > 1 THEN
      VBI_ID := SUBSTR(VBI_ID, 1, LENGTH(VBI_ID) - 1);

      EXECUTE IMMEDIATE 'DELETE T_POL_BUDGET_DETAIL_IMPORT I WHERE I.IMP_ID = ' ||
                        PIMP_ID || ' AND I.ID NOT IN (' || VBI_ID || ')';

    ELSE
      EXECUTE IMMEDIATE 'DELETE T_POL_BUDGET_DETAIL_IMPORT I WHERE I.IMP_ID = ' || PIMP_ID;
    END IF;

    IF (PCANERROR = 'Y') THEN
      PRESULT := VRESULT;
    END IF;

  EXCEPTION
    --返回错误信息，回滚到保存点
    WHEN NO_DATA_FOUND THEN
      PRESULT := '没有可导入的有效记录。';

  END p_Budget_Detail_Import;

 /*===============================================================
  * Program Name:   p_Direct_Super_Add_Budget
  * Purpose     :   从系统外直接追加指定正预算到指定单元（负金额反向）
   ===============================================================*/
  Procedure p_Direct_Super_Add_Budget(p_Data_Flow_Id In Number,
                                      --预算流ID
                                      p_Entity_Id In Number,
                                      --主体ID
                                      p_Budget_Tree_Id In Number,
                                      --预算树单元ID
                                      p_Amount In Number,
                                      --追加指定预算
                                      p_Budget_Order_Id In Number Default -1,
                                      --预算操作关联单据ID
                                      p_Budget_Order_Code In Varchar2,
                                      --预算操作管理单据编码
                                      p_Comments In Varchar2,
                                      --备注信息
                                      p_User_Id In Number,
                                      --用户ID
                                      p_Result Out Varchar2
                                      --返回结果：成功返回"SUCCESS"，失败返回原因
                                      ) Is

    v_Pp Constant Varchar2(200) := '从系统外直接追加指定正预算到指定单元（负金额反向）失败，';

    v_Budget_Detail_Id  Number; --预算明细单据ID
    v_Budget_Detail_Ids Varchar2(4000); --预算明细单据ID链
    v_Budget_Type       number; --预算结构类型（1:政策预算;2:费用预算）

  Begin
    --建保存点
    --SAVEPOINT Spi_Direct_Super_Add_Budget;

    --检查参数
    If p_Data_Flow_Id Is Null Or p_Entity_Id Is Null Or
       p_Budget_Tree_Id Is Null Or Nvl(p_Amount, 0) = 0 Or
       Nvl(p_Amount, 0) <> Trunc(Nvl(p_Amount, 0), 2) Or p_User_Id Is Null Then
      p_Result := '输入参数分别为(' || To_Char(p_Data_Flow_Id) || ',' ||
                  To_Char(p_Entity_Id) || ',' ||
                  To_Char(p_Budget_Tree_Id) || ',' || To_Char(p_User_Id) || ',' ||
                  To_Char(p_Amount) || ')';
      Raise Ipt_Param_Err_Exp;
    End If;

    --检查并读锁定预算树单元
    p_Result := '检查并读锁定预算树单元失败(' || To_Char(p_Data_Flow_Id) || ',' ||
                To_Char(p_Entity_Id) || ',' ||
                To_Char(p_Budget_Tree_Id) || ')';
    Select v_Success
      Into p_Result
      From t_Pol_Budget_Tree
     Where Budget_Tree_Id = p_Budget_Tree_Id
       And Data_Flow_Id = p_Data_Flow_Id
       And Entity_Id = p_Entity_Id
       For Update Nowait;

    --初始化预算明细单据ID串
    v_Budget_Detail_Ids := ' ';

    --插入预算明细单据表，形成ID链，供下一步审核用
    For r_Nod In (Select Budget_Tree_Id,
                         Sign(Nvl(p_Amount, 0))*Level Level_Num
                    From t_Pol_Budget_Tree
                   Start With Budget_Tree_Id = p_Budget_Tree_Id
                  Connect By Budget_Tree_Id = Prior Budget_Tree_Pre_Id
                   Order By Level_Num Desc) Loop
      --获取预算明细单据ID
      Select s_Pol_Budget_Detail.Nextval
        Into v_Budget_Detail_Id
        From Dual;

      --插入预算明细单据表
      Insert Into t_Pol_Budget_Detail
        (Budget_Detail_Id,
         Budget_Tree_Id,
         Entity_Id,
         Budget_Type,
         Budget_Id,
         Budget_Code,
         Budget_Detail_Amount,
         Created_By,
         Creation_Date,
         Last_Updated_By,
         Last_Update_Date,
         Refer_Flag,
         Check_Flag,
         Remark)
      Values
        (v_Budget_Detail_Id,
         r_Nod.Budget_Tree_Id,
         p_Entity_Id,
         '直接追加',
         p_Budget_Order_Id,
         Substrb(p_Budget_Order_Code, 1, 20),
         Nvl(p_Amount, 0),
         p_User_Id,
         Sysdate,
         p_User_Id,
         Sysdate,
         v_y,
         v_n,
         Substrb(p_Comments, 1, 240));

      --链接预算明细单据ID
      v_Budget_Detail_Ids := v_Budget_Detail_Ids || To_Char(v_Budget_Detail_Id) || ' ';
    End Loop;

    --审核预算明细单据链
    p_Check_Budget_Details(p_Data_Flow_Id,
                           p_Entity_Id,
                           v_Budget_Detail_Ids,
                           p_User_Id,
                           v_Budget_Detail_Id,
                           p_Result);
    If Nvl(p_Result, v_Null) <> v_Success Then
      Raise Procedure_Brk_Exp;
    End If;

    --2014-11-25 获取预算结构类型
    Select Object_Type
      Into v_Budget_Type
      From t_Pol_Budget_Tree
     Where Budget_Tree_Id = p_Budget_Tree_Id
       And Data_Flow_Id = p_Data_Flow_Id
       And Entity_Id = p_Entity_Id;

    --2014-11-25 判断是否是政策预算，在当前节点修改一些金额
    If(v_Budget_Type = '1') Then
        --更新本期新增
        Update t_Pol_Budget_Tree
           Set Current_New_Amount = Nvl(Current_New_Amount, 0) +  Nvl(p_Amount, 0)
         Where Budget_Tree_Id = p_Budget_Tree_Id;

        --更新期末余额
        Update t_Pol_Budget_Tree
           Set Ending_Balance_Amount = Nvl(Last_Year_Amount, 0) +  Nvl(Beginning_Balance_Amount, 0) +
               Nvl(Current_New_Amount, 0) - Nvl(Current_Occupation_Amount, 0)
         Where Budget_Tree_Id = p_Budget_Tree_Id;
    End If;

    --成功处理返回
    p_Result := v_Success;
  Exception
    --返回错误信息，回滚到保存点
    When Procedure_Brk_Exp Then
      p_Result := v_Pp || '调用错误：' || v_Nl || p_Result;
      --ROLLBACK TO SAVEPOINT Spi_Direct_Super_Add_Budget;
    When Ipt_Param_Err_Exp Then
      p_Result := v_Pp || '参数错误：' || p_Result;
      --ROLLBACK TO SAVEPOINT Spi_Direct_Super_Add_Budget;
    When Sql_Not_Found_Exp Then
      p_Result := v_Pp || '更新无效：' || p_Result;
      --ROLLBACK TO SAVEPOINT Spi_Direct_Super_Add_Budget;
    When No_Data_Found Then
      p_Result := v_Pp || '查无记录：' || p_Result;
      --ROLLBACK TO SAVEPOINT Spi_Direct_Super_Add_Budget;
    When Too_Many_Rows Then
      p_Result := v_Pp || '查多记录：' || p_Result;
      --ROLLBACK TO SAVEPOINT Spi_Direct_Super_Add_Budget;
    When Others Then
      p_Result := v_Pp || '未知错误：' || p_Result || v_Nl || Sqlcode || ': ' || Sqlerrm;
      --ROLLBACK TO SAVEPOINT Spi_Direct_Super_Add_Budget;
  End p_Direct_Super_Add_Budget;

  -------------------------------------------------------------------------------
  /*同步占用预算（触发器调用，不能够回滚）*/
  -------------------------------------------------------------------------------
  PROCEDURE p_Sync_Upd_Budget(p_Entity_Id              IN NUMBER, --主体ID
                              p_Data_Flow_Id           IN NUMBER, --数据流程ID
                              p_Budget_Tree_Id        IN NUMBER, --预算树单元ID
                              p_Source_Type            IN VARCHAR2, --来源类型
                              p_Source_Id              IN NUMBER, --来源单ID
                              p_Source_Code            IN VARCHAR2, --来源单号
                              p_Sum_Amount             IN NUMBER, --费用总额
                              p_User_Id                IN NUMBER, --用户ID
                              p_Comments               IN VARCHAR2, --备注信息
                              p_Pre_Field_01           IN VARCHAR2, --备用字段01
                              p_Pre_Field_02           IN VARCHAR2, --备用字段02
                              p_Pre_Field_03           IN VARCHAR2, --备用字段03
                              p_Pre_Field_04           IN VARCHAR2, --备用字段04
                              p_Pre_Field_05           IN VARCHAR2, --备用字段05
                              p_Pre_Field_06           IN VARCHAR2, --备用字段06
                              p_Pre_Field_07           IN VARCHAR2, --备用字段07
                              p_Pre_Field_08           IN VARCHAR2, --备用字段08
                              p_Pre_Field_09           IN VARCHAR2, --备用字段09
                              p_Result                 OUT VARCHAR2 --返回结果：成功返回"SUCCESS"，失败返回原因
                              ) IS
    v_Pp CONSTANT VARCHAR2(50) := '同步占用预算';
    v_Sum_Amount NUMBER NOT NULL := 0; --汇总费用
  BEGIN
    --检查参数
    IF p_Entity_Id IS NULL OR p_Data_Flow_Id IS NULL OR
       p_Budget_Tree_Id IS NULL OR p_Source_Type IS NULL OR
       p_Source_Id IS NULL OR p_Source_Code IS NULL OR p_Sum_Amount IS NULL OR
       p_User_Id IS NULL THEN
      p_Result := v_Pp || '失败：输入参数部分为空或错误(' ||
                  To_Char(p_Entity_Id) || ',' ||
                  To_Char(p_Data_Flow_Id) || ',' ||
                  To_Char(p_Budget_Tree_Id) || ',' || p_Source_Type || ',' ||
                  To_Char(p_Source_Id) || ',' || p_Source_Code || ',' ||
                  To_Char(p_Sum_Amount) || ',' || To_Char(p_User_Id) || ')';
    ELSE
      --初始结果
      p_Result := v_Success;
    END IF;
    --同步占用预算
    IF Nvl(p_Result, v_Null) = v_Success THEN
      --检查费用明细，获取汇总费用
      SELECT Nvl(SUM(Fee_Detail_Amount), 0)
        INTO v_Sum_Amount
        FROM t_Pol_Budget_Fee_Detail
       WHERE Budget_Tree_Id = p_Budget_Tree_Id
         AND Fee_Type = p_Source_Type
         AND Fee_Id = p_Source_Id;
      --当调整金额部位0时，同步登记费用
      --20070117 龙海修改 解决费用单据与费用明细金额相差0.01问题
      --IF Round((p_Sum_Amount - v_Sum_Amount), 2) <> 0
      IF (Round(p_Sum_Amount, 2) - Round(v_Sum_Amount, 2)) <> 0 THEN
        Pkg_Budget.p_Write_Fee(p_Data_Flow_Id,
                               p_Entity_Id,
                               p_Budget_Tree_Id,
                               p_Source_Type,
                               p_Source_Id,
                               Substrb(p_Source_Code, 1, 30),
                               Substrb(p_Comments, 1, 240),
                               Substrb(p_Pre_Field_01, 1, 20),
                               Substrb(p_Pre_Field_02, 1, 20),
                               Substrb(p_Pre_Field_03, 1, 20),
                               Substrb(p_Pre_Field_04, 1, 20),
                               Substrb(p_Pre_Field_05, 1, 20),
                               Substrb(p_Pre_Field_06, 1, 20),
                               Substrb(p_Pre_Field_07, 1, 20),
                               Substrb(p_Pre_Field_08, 1, 20),
                               Substrb(p_Pre_Field_09, 1, 20),
                               --20070117 龙海修改 解决费用单据与费用明细金额相差0.01问题
                               --Round((p_Sum_Amount - v_Sum_Amount), 2),
                               (Round(p_Sum_Amount, 2) -
                               Round(v_Sum_Amount, 2)),
                               p_User_Id,
                               p_Result);
        IF Nvl(p_Result, v_Null) <> v_Success THEN
          p_Result := v_Pp || '失败' || v_Nl || p_Result;
        END IF;
        --20060829 龙海增加
        IF Nvl(p_Result, v_Null) = v_Success THEN
          FOR c_Fee_Detail IN (SELECT Budget_Tree_Id,
                                      Fee_Type,
                                      Fee_Id,
                                      SUM(Fee_Detail_Amount) Fee_Detail_Amount
                                 FROM t_Pol_Budget_Fee_Detail d
                                WHERE Budget_Tree_Id != p_Budget_Tree_Id
                                  AND Budget_Tree_Id IS NOT NULL
                                  AND Fee_Type = p_Source_Type
                                  AND Fee_Id = p_Source_Id
                                  AND EXISTS
                                (SELECT 1
                                         FROM t_Pol_Budget_Tree t
                                        WHERE t.Budget_Tree_Id =
                                              d.Budget_Tree_Id)
                                GROUP BY Budget_Tree_Id, Fee_Type, Fee_Id
                               HAVING SUM(Fee_Detail_Amount) <> 0) LOOP
            Pkg_Budget.p_Write_Fee(p_Data_Flow_Id,
                                   p_Entity_Id,
                                   c_Fee_Detail.Budget_Tree_Id,
                                   p_Source_Type,
                                   p_Source_Id,
                                   Substrb(p_Source_Code, 1, 30),
                                   Substrb(p_Comments, 1, 240),
                                   Substrb(p_Pre_Field_01, 1, 20),
                                   Substrb(p_Pre_Field_02, 1, 20),
                                   Substrb(p_Pre_Field_03, 1, 20),
                                   Substrb(p_Pre_Field_04, 1, 20),
                                   Substrb(p_Pre_Field_05, 1, 20),
                                   Substrb(p_Pre_Field_06, 1, 20),
                                   Substrb(p_Pre_Field_07, 1, 20),
                                   Substrb(p_Pre_Field_08, 1, 20),
                                   Substrb(p_Pre_Field_09, 1, 20),
                                   -c_Fee_Detail.Fee_Detail_Amount,
                                   p_User_Id,
                                   p_Result);
            IF Nvl(p_Result, v_Null) <> v_Success THEN
              p_Result := Substrb(v_Pp || '失败' || v_Nl || p_Result, 1, 240);
              EXIT;
            END IF;
          END LOOP;
        END IF;
      END IF;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      p_Result := v_Pp || '失败：未知错误：' || SQLERRM;
  END p_Sync_Upd_Budget;

  -----------------------------------------------------------------------------
  --      获取主体语义                                                       --
  -----------------------------------------------------------------------------
  PROCEDURE p_Get_Entity_Semantic(P_SEMANTIC_ID            IN NUMBER   --语义ID
                                 ,P_ENTITY_ID              IN NUMBER   --主体ID
                                 ,P_SEMANTIC_TYPE         OUT VARCHAR2 --语义类型：SQL取值、计算公式
                                 ,P_SEMANTIC_VAL          OUT VARCHAR2 --语义值
                                 ,P_PRE_PROC_SQL          OUT VARCHAR2 --预执行语句
                                 ,P_QUERY_CODE            OUT VARCHAR2 --查询条件编码
                                 ,P_MESSAGE               OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
                                 ) IS
    N_SEMANTIC_ID        NUMBER;
    L_GET_VAL_SQL        VARCHAR2(4000);
    L_GET_VAL_EXPRESSION VARCHAR2(240);
    L_QUERY_CODE         VARCHAR2(40);
    L_PRE_PROC_SQL       VARCHAR2(4000);

  BEGIN
    P_MESSAGE := 'OK';

    --取系统语义
    BEGIN
      SELECT S.SEMANTIC_ID
           , S.SEMANTIC_TYPE
           , S.GET_VAL_SQL
           , S.GET_VAL_EXPRESSION
           , S.QUERY_CODE
           , S.PRE_PROC_SQL
        INTO N_SEMANTIC_ID
           , P_SEMANTIC_TYPE
           , L_GET_VAL_SQL
           , L_GET_VAL_EXPRESSION
           , L_QUERY_CODE
           , L_PRE_PROC_SQL
        FROM T_POL_SEMANTIC S
       WHERE S.SEMANTIC_ID = P_SEMANTIC_ID;
      --判断语义类型
      --IF (P_SEMANTIC_TYPE = 'SQL取值') THEN
      IF (P_SEMANTIC_TYPE = '1') THEN
        P_SEMANTIC_VAL := L_GET_VAL_SQL;
        P_PRE_PROC_SQL := L_PRE_PROC_SQL;
      ELSE
        P_SEMANTIC_VAL := L_GET_VAL_EXPRESSION;
      END IF;
      P_QUERY_CODE := L_QUERY_CODE;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        P_MESSAGE := '没有定义系统语义';
    END;

  END;

 /*===============================================================
  * Program Name:   p_Calculation_Formula_Analyze
  * Purpose     :   计算公式解析过程
   ===============================================================*/
  PROCEDURE p_Calculation_Formula_Analyze(p_Formula_Id              IN NUMBER   --公式ID
                                          ,p_Entity_Id              IN NUMBER   --主体ID
                                          ,p_Result                 OUT VARCHAR2 --返回结果：成功返回"SUCCESS"，失败返回原因
                                          ) Is
    v_Pp CONSTANT VARCHAR2(50) := '计算公式解析失败，';
    v_Get_Val_Expression Varchar2(4000); --取值表达式

    --定义游标
    Cursor c_Items Is
         Select regexp_substr(v_Get_Val_Expression, '[^)|(|/|+|*|-]+', 1, level) as item
           from dual
     connect by level <= regexp_count(v_Get_Val_Expression, '[^)|(|/|+|*|-]+');
    r_Items c_Items%rowtype;
    Cursor c_Params Is
         Select t.calc_formu_lines_name, t.const_val, t.param_name
           From t_Pol_Budget_Calc_Formu_Lines t
          Where t.calculation_id = p_Formula_Id
            and t.value_type = '2'; --常量取值
    r_Params c_Params%rowtype;

    v_Temp Varchar2(100); --临时变量

    v_Semantic_Id  Varchar2(100); --语义id
    v_conditon     Varchar2(4000); --查询条件
    --v_Accrual_Rate NUMBER; --计提率

    v_Semantic_Type        Varchar2(240);
    v_Semantic_Val         Varchar2(4000);
    v_Pre_Proc_Sql         Varchar2(4000);
    v_Query_Code           Varchar2(40);
  Begin
    --检查参数
    IF p_Entity_Id IS NULL OR p_Formula_Id IS NULL THEN
      p_Result := v_Pp || '输入参数部分为空或错误(' ||
                  To_Char(p_Entity_Id) || ',' ||
                  To_Char(p_Formula_Id) || ')';
      Raise Ipt_Param_Err_Exp;
    ELSE
      --初始结果
      p_Result := v_Success;
    END IF;

    --检查取值表达式与行表是否一致
    p_Result := '检查取值表达式(' || To_Char(p_Formula_Id) || ')';
    Select Get_Val_Expression
      Into v_Get_Val_Expression
      From t_Pol_Budget_Calculation_Formu
     Where Calculation_Id = p_Formula_Id;
    --dbms_output.put_line(v_Get_Val_Expression);

    --过滤运算符号
    OPEN c_Items;
    Loop
      Fetch c_Items Into r_Items;
      Exit When c_Items%Notfound;
      --dbms_output.put_line(r_Items.item);
      Begin
        Select Calc_Formu_Lines_Name
          Into v_Temp
          From t_Pol_Budget_Calc_Formu_Lines t
         Where t.calculation_id = p_Formula_Id
           And t.calc_formu_lines_name = r_Items.item;
      Exception
        When No_Data_Found Then
          p_Result := '计算公式定义错误';
          return;
      End;
    End Loop;
    Close c_Items;

    --解析公式
    --如果不止一条记录,需要作判断,报异常信息,退出
    Begin
      Select semantic_id，query_condition
        Into v_Semantic_Id，v_conditon
        From t_Pol_Budget_Calc_Formu_Lines t
       Where t.calculation_id = p_Formula_Id
         and t.value_type = '1'; --语义取值
    Exception
      When Too_Many_Rows Then
        p_Result := '语义定义过多';
        return;
    End;

    --根据语义id获取语义
    p_Get_Entity_Semantic(v_Semantic_Id
                          ,p_Entity_Id
                          ,v_Semantic_Type
                          ,v_Semantic_Val
                          ,v_Pre_Proc_Sql
                          ,v_Query_Code
                          ,p_Result);

    --IF(v_Semantic_Type = 'SQL取值') THEN
    IF(v_Semantic_Type = '1') THEN
      OPEN c_Params;
      Loop
        Fetch c_Params Into r_Params;
        Exit When c_Params%Notfound;
        Begin
          --判断参数在语义里面有没有定义,如果没有,则报异常信息
          If INSTR(v_Semantic_Val, ':' || r_Params.Param_Name, 1, 1) = 0 Then
            p_Result := r_Params.Calc_Formu_Lines_Name || '的参数名称[' || r_Params.Param_Name || ']在语义里面没有定义！';
            return;
          End If;

          --替换参数为具体值
          Select Replace(v_Semantic_Val, ':' || r_Params.Param_Name, r_Params.Const_Val)
            Into v_Semantic_Val
            From Dual;
        Exception
          When No_Data_Found Then
            p_Result := '计算公式定义错误';
            return;
        End;
      End Loop;
      Close c_Params;
    END IF;

    --先删除以前解析过的关联记录,然后插入公式解析表
    delete from t_Pol_Budget_Calculation_Expre t
          where t.calculation_id = p_Formula_Id;
    Insert Into t_Pol_Budget_Calculation_Expre
     (Express_Id,
      Calculation_Id,
      Get_Val_Expression,
      Excel_Express,
      Db_Express,
      Condition,
      Prior_Level,
      Created_By,
      Creation_Date,
      Last_Updated_By,
      Last_Update_Date)
    Values
      (S_POL_BUDGET_CALCULATION_EXPRE.NEXTVAL,
       p_Formula_Id,
       v_Semantic_Val,
       Null,
       Null,
       v_conditon,
       1,
       'admin',
       Sysdate,
       'admin',
       Sysdate);

    --成功处理返回
    p_Result := v_Success;

  EXCEPTION
    When Ipt_Param_Err_Exp Then
      p_Result := v_Pp || '参数错误：' || p_Result;
    When Others Then
      p_Result := v_Pp || '未知错误' || Sqlcode || ': ' || Sqlerrm;

  End p_Calculation_Formula_Analyze;

 /*===============================================================
  * Program Name:   p_Source_Calculation
  * Purpose     :   预算来源计算过程
   ===============================================================*/
  PROCEDURE p_Source_Calculation(p_Formula_Id              IN NUMBER   --公式ID
                                 ,p_Period_Id              IN NUMBER   --计算阶段ID
                                 ,p_Begin_Date             IN DATE     --开始日期
                                 ,p_End_Date               IN DATE     --结束日期
                                 ,p_Entity_Id              IN NUMBER   --主体ID
                                 ,p_Result                 OUT VARCHAR2 --返回结果：成功返回"SUCCESS"，失败返回原因
                                 ) Is
    v_Policy_Section_Id      NUMBER;
    v_Policy_Section_Code    VARCHAR2(200);
    v_Policy_Section_Name    VARCHAR2(200);

    v_Budget_Result_Id       NUMBER; --预算计算结果ID
    v_Budget_Result_Code     VARCHAR2(200); --计算结果编号

    N_CUR                    NUMBER;
    N_ROW                    NUMBER;
    v_Exist                  NUMBER; --记录是否存在

    v_Semantic_Val           VARCHAR2(20000); --取值SQL
    v_conditon               VARCHAR2(20000); --查询条件

    V_SEMANTIC_VAL_0         VARCHAR2(20000);
    V_SEMANTIC_VAL_1         VARCHAR2(20000);


    v_Sem VARCHAR2(4000); --取值SQL

  Begin
    p_Result := v_Success;

    --读取公式分解表
    Select t.Get_Val_Expression, t.Condition
      Into v_Semantic_Val, v_conditon
      From t_Pol_Budget_Calculation_Expre t
     Where t.calculation_id = p_Formula_Id;

    --dbms_output.put_line(p_Result);
    If (nvl(p_Result, v_Null) = v_Success) And nvl(length(v_Semantic_Val), 0) > 0 Then
      --处理执行语句
      select count(t.Budget_Result_Id)
        Into v_Exist
        from t_Pol_Budget_Result_Head t
        where t.Budget_Calc_Period_Id = p_Period_Id;

      If v_Exist > 0 Then
        --更新预算计算结果头表
        Select t.Budget_Result_Id
          Into v_Budget_Result_Id
          from t_Pol_Budget_Result_Head t
         where t.Budget_Calc_Period_Id = p_Period_Id;

        Update t_Pol_Budget_Result_Head t
           Set t.Budget_Cal_Begin_Date = p_Begin_Date,
               t.Budget_Cal_End_Date   = p_End_Date,
               t.Budget_Result_Status  = '0',
               t.Last_Updated_By       = 'admin',
               t.Last_Update_Date      = Sysdate
         Where t.budget_calc_period_id = p_Period_Id;
      Else
        --插入预算计算结果头表
        Select S_POL_BUDGET_RESULT_HEAD.NEXTVAL
          Into v_Budget_Result_Id
          from dual;

        v_Budget_Result_Code := PKG_BD.F_GET_BILL_NO('polBudgetCalculationCode', null, p_Entity_Id, NULL);

        Select t.calculation_id, '', t.calculation_name
          Into v_Policy_Section_Id, v_Policy_Section_Code, v_Policy_Section_Name
          from t_Pol_Budget_Calculation_Formu t
         where t.calculation_id = p_Formula_Id;

        Insert Into t_Pol_Budget_Result_Head
          (Budget_Result_Id,
           Budget_Result_Code,
           Policy_Section_Id,
           Policy_Section_Code,
           Policy_Section_Name,
           Budget_Cal_Begin_Date,
           Budget_Cal_End_Date,
           Entity_Id,
           Budget_Result_Status,
           Budget_Calc_Period_Id,
           Created_By,
           Creation_Date,
           Last_Updated_By,
           Last_Update_Date,
           Pre_Field_01,
           Pre_Field_02,
           Pre_Field_03,
           Pre_Field_04,
           Pre_Field_05,
           Pre_Field_06)
        Values
          (v_Budget_Result_Id,
           v_Budget_Result_Code,
           v_Policy_Section_Id,
           v_Policy_Section_Code,
           v_Policy_Section_Name,
           p_Begin_Date,
           p_End_Date,
           p_Entity_Id,
           0, --结果状态
           p_Period_Id,
           'admin',
           Sysdate,
           'admin',
           Sysdate,
           null,
           null,
           null,
           null,
           null,
           null);
      End If;

      If v_conditon Is Not Null Then
         SELECT v_Semantic_Val || ' Where ' || v_conditon
           INTO v_Semantic_Val
           FROM DUAL;
      End If;

      --先删除原来的数据
      If v_Exist > 0 Then
        delete t_Pol_Budget_Result_Line t where t.budget_result_id = v_Budget_Result_Id;
      End If;

      --插入预算计算结果行表
      V_SEMANTIC_VAL_1 := 'insert into t_Pol_Budget_Result_Line('
                       || 'Budget_Result_Line_Id,'
                       || 'Budget_Result_Id,'
                       || 'Budget_Adjust_Amount,'
                       || 'Budget_Adjust_Reason,'
                       || 'Calculation_Amount,'
                       || 'Final_Amount,'
                       || 'Sales_Center_Id,'
                       || 'Sales_Center_Code,'
                       || 'Sales_Center_Name,'
                       || 'Created_By,'
                       || 'Creation_Date,'
                       || 'Last_Updated_By,'
                       || 'Last_Update_Date,'
                       || 'Pre_Field_01,'
                       || 'Pre_Field_02,'
                       || 'Pre_Field_03,'
                       || 'Pre_Field_04,'
                       || 'Pre_Field_05,'
                       || 'Pre_Field_06)'
                       || 'SELECT S_POL_BUDGET_RESULT_LINE.NEXTVAL,'
                       || TO_CHAR(v_Budget_Result_Id) || ','
                       || '  0,'
                       || '  null,'
                       || '  to_char(amount,''9999999.99''),'
                       || '  to_char(amount,''9999999.99''),'
                       || '  id,'
                       || '  code,'
                       || '  name,'
                       || '  ''admin'','
                       || '  Sysdate,'
                       || '  ''admin'','
                       || '  Sysdate,'
                       || '  null,'
                       || '  null,'
                       || '  null,'
                       || '  null,'
                       || '  null,'
                       || '  null'
                       || ' FROM ( ';
      SELECT nvl(V_SEMANTIC_VAL_1,'') || nvl(v_Semantic_Val,'') || ')'
        INTO V_SEMANTIC_VAL_0
        FROM DUAL;
      --V_SEMANTIC_VAL_0 := V_SEMANTIC_VAL_1 || v_Semantic_Val || ')';
      --dbms_output.put_line(V_SEMANTIC_VAL_0);

      --打开光标
      N_CUR := DBMS_SQL.OPEN_CURSOR;
      --解析动态SQL语句
      DBMS_SQL.PARSE(N_CUR, V_SEMANTIC_VAL_0, DBMS_SQL.NATIVE);
      --绑定输入参数
      IF INSTR(V_SEMANTIC_VAL_0, ':P_BEGIN_DATE', 1, 1) > 0 THEN
        DBMS_SQL.BIND_VARIABLE(N_CUR, ':P_BEGIN_DATE', p_Begin_Date);
      END IF;
      IF INSTR(V_SEMANTIC_VAL_0, ':P_END_DATE', 1, 1) > 0 THEN
        DBMS_SQL.BIND_VARIABLE(N_CUR, ':P_END_DATE', p_End_Date);
      END IF;
      IF INSTR(V_SEMANTIC_VAL_0, ':P_ENTITY_ID', 1, 1) > 0 THEN
        DBMS_SQL.BIND_VARIABLE(N_CUR, ':P_ENTITY_ID', p_Entity_Id);
      END IF;
      --执行语句
      N_ROW := DBMS_SQL.EXECUTE(N_CUR);
      --关闭光标
      DBMS_SQL.CLOSE_CURSOR(N_CUR);
    End If;

  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      p_Result := '计算错误';

  End p_Source_Calculation;

 /*===============================================================
  * Program Name:   p_Period_CarryOver_Budget
  * Purpose     :   月度结转预算的过程
   ===============================================================*/
  Procedure p_Period_CarryOver_Budget(p_Data_Flow_Id In Number,
                                      p_Entity_Id In Number,
                                      p_Budget_Tree_Id In Number,
                                      p_Amount In Number,
                                      p_Budget_Order_Id In Number Default -1,
                                      p_Budget_Order_Code In Varchar2,
                                      p_Adjust_Type In Varchar2,
                                      p_Comments In Varchar2,
                                      p_User_Id In Number,
                                      p_Result Out Varchar2) Is

    v_Pp Constant Varchar2(200) := '月度结转预算失败，';
    v_Budget_Detail_Id  Number; --预算明细单据ID
    v_Budget_Detail_Ids Varchar2(4000); --预算明细单据ID链
    --v_Budget_Type       number; --预算结构类型（1:政策预算;2:费用预算）
    --v_Settle_Flag       Varchar2(2); --预算结转标示

  Begin
    --检查参数
    IF p_Data_Flow_Id IS NULL OR p_Entity_Id IS NULL OR
       p_Adjust_Type IS NULL OR p_Budget_Tree_Id IS NULL OR
       NVL(p_Amount, 0) = 0 OR
       NVL(p_Amount, 0) <> TRUNC(NVL(p_Amount, 0), 2) OR p_User_Id IS NULL THEN
      p_Result := '输入参数分别为(' || TO_CHAR(p_Data_Flow_Id) || ',' ||
                  TO_CHAR(p_Entity_Id) || ',' ||
                  TO_CHAR(p_Budget_Tree_Id) || ',' || TO_CHAR(p_User_Id) || ',' ||
                  TO_CHAR(p_Amount) || ')';
      RAISE Ipt_Param_Err_Exp;
    END IF;

    --2014-11-25 获取预算结构类型
    /*Select Object_Type
      Into v_Budget_Type
      From t_Pol_Budget_Tree
     Where Budget_Tree_Id = p_Budget_Tree_Id
       And Data_Flow_Id = p_Data_Flow_Id
       And Entity_Id = p_Entity_Id;

    If(v_Budget_Type <> '1') Then
      p_Result := '非政策预算，不能做月度结转，';
      RAISE Ipt_Param_Err_Exp;
    End If;*/
    --add by liangym2 取消控制 2018-6-20

    /* commented by xiaoxu 取消控制 2018-09-10
    --获取预算结转标示
    Select Settle_Flag
      Into v_Settle_Flag
      From t_Pol_Budget_Tree
     Where Budget_Tree_Id = p_Budget_Tree_Id
       And Data_Flow_Id = p_Data_Flow_Id
       And Entity_Id = p_Entity_Id;

    If p_Amount < 0 And v_Settle_Flag = 'Y' Then
      p_Result := '调出节点已经结转，不能做月度结转，';
      RAISE Ipt_Param_Err_Exp;
    End If;
    */

    --检查并读锁定预算树单元
    p_Result := '检查并读锁定预算树单元失败(' || TO_CHAR(p_Data_Flow_Id) || ',' ||
                TO_CHAR(p_Entity_Id) || ',' || TO_CHAR(p_Budget_Tree_Id) || ')';

    SELECT V_SUCCESS
      INTO P_RESULT
      FROM t_Pol_Budget_Tree
     WHERE BUDGET_Tree_ID = p_Budget_Tree_Id
       AND DATA_FLOW_ID = p_Data_Flow_Id
       AND ENTITY_ID = p_Entity_Id
       FOR UPDATE NOWAIT;

    --插入预算明细单据表，形成ID链，供下一步审核用
    For r_Nod In (Select Budget_Tree_Id,
                         Sign(Nvl(p_Amount, 0))*Level Level_Num
                    From t_Pol_Budget_Tree
                   Start With Budget_Tree_Id = p_Budget_Tree_Id
                  Connect By Budget_Tree_Id = Prior Budget_Tree_Pre_Id
                   Order By Level_Num Desc) Loop
      --获取预算明细单据ID
      Select s_Pol_Budget_Detail.Nextval
        Into v_Budget_Detail_Id
        From Dual;

      --插入预算明细单据表
      Insert Into t_Pol_Budget_Detail
        (Budget_Detail_Id,
         Budget_Tree_Id,
         Entity_Id,
         Budget_Type,
         Budget_Id,
         Budget_Code,
         Budget_Detail_Amount,
         Created_By,
         Creation_Date,
         Last_Updated_By,
         Last_Update_Date,
         Refer_Flag,
         Check_Flag,
         Remark)
      Values
        (v_Budget_Detail_Id,
         r_Nod.Budget_Tree_Id,
         p_Entity_Id,
         p_Adjust_Type,
         p_Budget_Order_Id,
         Substrb(p_Budget_Order_Code, 1, 20),
         Nvl(p_Amount, 0),
         p_User_Id,
         Sysdate,
         p_User_Id,
         Sysdate,
         v_y,
         v_n,
         Substrb(p_Comments, 1, 240));

      --链接预算明细单据ID
      v_Budget_Detail_Ids := v_Budget_Detail_Ids || To_Char(v_Budget_Detail_Id) || ' ';
    End Loop;

    --审核预算明细单据链
    p_Check_Adjust_Budget_Details(p_Data_Flow_Id,
                                  p_Entity_Id,
                                  v_Budget_Detail_Ids,
                                  p_User_Id,
                                  v_Budget_Detail_Id,
                                  p_Result);
    If Nvl(p_Result, v_Null) <> v_Success Then
      Raise Procedure_Brk_Exp;
    End If;

    --转出月度
    If p_Amount < 0 Then
      --更新本期新增
      Update t_Pol_Budget_Tree
         Set Current_New_Amount = Nvl(Current_New_Amount, 0) +  Nvl(p_Amount, 0)
       Where Budget_Tree_Id = p_Budget_Tree_Id;

      --更新结转标示
      Update t_Pol_Budget_Tree
         Set Settle_Flag = 'Y'
       Where Budget_Tree_Id = p_Budget_Tree_Id;
    --转入月度
    ElsIf p_Amount > 0 Then
      --更新期初余额
      Update t_Pol_Budget_Tree
         Set Beginning_Balance_Amount = Nvl(Beginning_Balance_Amount, 0) +  Nvl(p_Amount, 0)
       Where Budget_Tree_Id = p_Budget_Tree_Id;
    End If;

    --更新期末余额
    Update t_Pol_Budget_Tree
       Set Ending_Balance_Amount = Nvl(Last_Year_Amount, 0) +  Nvl(Beginning_Balance_Amount, 0) +
           Nvl(Current_New_Amount, 0) - Nvl(Current_Occupation_Amount, 0)
     Where Budget_Tree_Id = p_Budget_Tree_Id;

    --成功处理返回
    p_Result := v_Success;
  Exception
    --返回错误信息，回滚到保存点
    When Procedure_Brk_Exp Then
      p_Result := v_Pp || '调用错误：' || v_Nl || p_Result;
      --ROLLBACK TO SAVEPOINT Spi_Direct_Super_Add_Budget;
    When Ipt_Param_Err_Exp Then
      p_Result := v_Pp || '参数错误：' || p_Result;
      --ROLLBACK TO SAVEPOINT Spi_Direct_Super_Add_Budget;
    When Sql_Not_Found_Exp Then
      p_Result := v_Pp || '更新无效：' || p_Result;
      --ROLLBACK TO SAVEPOINT Spi_Direct_Super_Add_Budget;
    When No_Data_Found Then
      p_Result := v_Pp || '查无记录：' || p_Result;
      --ROLLBACK TO SAVEPOINT Spi_Direct_Super_Add_Budget;
    When Too_Many_Rows Then
      p_Result := v_Pp || '查多记录：' || p_Result;
      --ROLLBACK TO SAVEPOINT Spi_Direct_Super_Add_Budget;
    When Others Then
      p_Result := v_Pp || '未知错误：' || p_Result || v_Nl || Sqlcode || ': ' || Sqlerrm;
      --ROLLBACK TO SAVEPOINT Spi_Direct_Super_Add_Budget;
  End p_Period_CarryOver_Budget;

 /*===============================================================
  * Program Name:   p_Year_CarryOver_Budget
  * Purpose     :   年度结转预算的过程
   ===============================================================*/
  Procedure p_Year_CarryOver_Budget(p_Data_Flow_Id In Number,
                                    p_Entity_Id In Number,
                                    p_Budget_Tree_Id In Number,
                                    p_Amount In Number,
                                    p_Budget_Order_Id In Number Default -1,
                                    p_Budget_Order_Code In Varchar2,
                                    p_Adjust_Type In Varchar2,
                                    p_Comments In Varchar2,
                                    p_User_Id In Number,
                                    p_Result Out Varchar2) Is

    v_Pp Constant Varchar2(200) := '年度结转预算失败，';
    v_Budget_Detail_Id  Number; --预算明细单据ID
    v_Budget_Detail_Ids Varchar2(4000); --预算明细单据ID链
    --v_Budget_Type       number; --预算结构类型（1:政策预算;2:费用预算）
    --v_Settle_Flag       Varchar2(2); --预算结转标示

  Begin
    --检查参数
    IF p_Data_Flow_Id IS NULL OR p_Entity_Id IS NULL OR
       p_Adjust_Type IS NULL OR p_Budget_Tree_Id IS NULL OR
       NVL(p_Amount, 0) = 0 OR
       NVL(p_Amount, 0) <> TRUNC(NVL(p_Amount, 0), 2) OR p_User_Id IS NULL THEN
      p_Result := '输入参数分别为(' || TO_CHAR(p_Data_Flow_Id) || ',' ||
                  TO_CHAR(p_Entity_Id) || ',' ||
                  TO_CHAR(p_Budget_Tree_Id) || ',' || TO_CHAR(p_User_Id) || ',' ||
                  TO_CHAR(p_Amount) || ')';
      RAISE Ipt_Param_Err_Exp;
    END IF;

    --2014-11-25 获取预算结构类型
    /*Select Object_Type
      Into v_Budget_Type
      From t_Pol_Budget_Tree
     Where Budget_Tree_Id = p_Budget_Tree_Id
       And Data_Flow_Id = p_Data_Flow_Id
       And Entity_Id = p_Entity_Id;

    If(v_Budget_Type <> '1') Then
      p_Result := '非政策预算，不能做年度结转，';
      RAISE Ipt_Param_Err_Exp;
    End If;*/
    --add by liangym2 取消控制 2018-6-20

    /* commented by xiaoxu 取消控制 2018-09-10
    --获取预算结转标示
    Select Settle_Flag
      Into v_Settle_Flag
      From t_Pol_Budget_Tree
     Where Budget_Tree_Id = p_Budget_Tree_Id
       And Data_Flow_Id = p_Data_Flow_Id
       And Entity_Id = p_Entity_Id;

    If p_Amount < 0 And v_Settle_Flag = 'Y' Then
      p_Result := '调出节点已经结转，不能做年度结转，';
      RAISE Ipt_Param_Err_Exp;
    End If;
    */

    --检查并读锁定预算树单元
    p_Result := '检查并读锁定预算树单元失败(' || TO_CHAR(p_Data_Flow_Id) || ',' ||
                TO_CHAR(p_Entity_Id) || ',' || TO_CHAR(p_Budget_Tree_Id) || ')';

    SELECT V_SUCCESS
      INTO P_RESULT
      FROM t_Pol_Budget_Tree
     WHERE BUDGET_Tree_ID = p_Budget_Tree_Id
       AND DATA_FLOW_ID = p_Data_Flow_Id
       AND ENTITY_ID = p_Entity_Id
       FOR UPDATE NOWAIT;

    --插入预算明细单据表，形成ID链，供下一步审核用
    For r_Nod In (Select Budget_Tree_Id,
                         Sign(Nvl(p_Amount, 0))*Level Level_Num
                    From t_Pol_Budget_Tree
                   Start With Budget_Tree_Id = p_Budget_Tree_Id
                  Connect By Budget_Tree_Id = Prior Budget_Tree_Pre_Id
                   Order By Level_Num Desc) Loop
      --获取预算明细单据ID
      Select s_Pol_Budget_Detail.Nextval
        Into v_Budget_Detail_Id
        From Dual;

      --插入预算明细单据表
      Insert Into t_Pol_Budget_Detail
        (Budget_Detail_Id,
         Budget_Tree_Id,
         Entity_Id,
         Budget_Type,
         Budget_Id,
         Budget_Code,
         Budget_Detail_Amount,
         Created_By,
         Creation_Date,
         Last_Updated_By,
         Last_Update_Date,
         Refer_Flag,
         Check_Flag,
         Remark)
      Values
        (v_Budget_Detail_Id,
         r_Nod.Budget_Tree_Id,
         p_Entity_Id,
         p_Adjust_Type,
         p_Budget_Order_Id,
         Substrb(p_Budget_Order_Code, 1, 20),
         Nvl(p_Amount, 0),
         p_User_Id,
         Sysdate,
         p_User_Id,
         Sysdate,
         v_y,
         v_n,
         Substrb(p_Comments, 1, 240));

      --链接预算明细单据ID
      v_Budget_Detail_Ids := v_Budget_Detail_Ids || To_Char(v_Budget_Detail_Id) || ' ';
    End Loop;

    --审核预算明细单据链
    p_Check_Adjust_Budget_Details(p_Data_Flow_Id,
                                  p_Entity_Id,
                                  v_Budget_Detail_Ids,
                                  p_User_Id,
                                  v_Budget_Detail_Id,
                                  p_Result);
    If Nvl(p_Result, v_Null) <> v_Success Then
      Raise Procedure_Brk_Exp;
    End If;

    --转出年度
    If p_Amount < 0 Then
      --更新本期新增
      Update t_Pol_Budget_Tree
         Set Current_New_Amount = Nvl(Current_New_Amount, 0) +  Nvl(p_Amount, 0)
       Where Budget_Tree_Id = p_Budget_Tree_Id;

      --更新结转标示
      Update t_Pol_Budget_Tree
         Set Settle_Flag = 'Y'
       Where Budget_Tree_Id = p_Budget_Tree_Id;
    --转入年度
    ElsIf p_Amount > 0 Then
      --更新上年结转
      Update t_Pol_Budget_Tree
         Set Last_Year_Amount = Nvl(Last_Year_Amount, 0) +  Nvl(p_Amount, 0)
       Where Budget_Tree_Id = p_Budget_Tree_Id;
    End If;

    --更新期末余额
    Update t_Pol_Budget_Tree
       Set Ending_Balance_Amount = Nvl(Last_Year_Amount, 0) +  Nvl(Beginning_Balance_Amount, 0) +
           Nvl(Current_New_Amount, 0) - Nvl(Current_Occupation_Amount, 0)
     Where Budget_Tree_Id = p_Budget_Tree_Id;

    --成功处理返回
    p_Result := v_Success;
  Exception
    --返回错误信息，回滚到保存点
    When Procedure_Brk_Exp Then
      p_Result := v_Pp || '调用错误：' || v_Nl || p_Result;
      --ROLLBACK TO SAVEPOINT Spi_Direct_Super_Add_Budget;
    When Ipt_Param_Err_Exp Then
      p_Result := v_Pp || '参数错误：' || p_Result;
      --ROLLBACK TO SAVEPOINT Spi_Direct_Super_Add_Budget;
    When Sql_Not_Found_Exp Then
      p_Result := v_Pp || '更新无效：' || p_Result;
      --ROLLBACK TO SAVEPOINT Spi_Direct_Super_Add_Budget;
    When No_Data_Found Then
      p_Result := v_Pp || '查无记录：' || p_Result;
      --ROLLBACK TO SAVEPOINT Spi_Direct_Super_Add_Budget;
    When Too_Many_Rows Then
      p_Result := v_Pp || '查多记录：' || p_Result;
      --ROLLBACK TO SAVEPOINT Spi_Direct_Super_Add_Budget;
    When Others Then
      p_Result := v_Pp || '未知错误：' || p_Result || v_Nl || Sqlcode || ': ' || Sqlerrm;
      --ROLLBACK TO SAVEPOINT Spi_Direct_Super_Add_Budget;
  End p_Year_CarryOver_Budget;

 /*===============================================================
  * Program Name:   p_Check_Fee
  * Purpose     :   检查节点费用
   ===============================================================*/
  Procedure p_Check_Fee(p_Data_Flow_Id In Number,
                        --数据流程ID，不能为空
                        p_Entity_Id In Number,
                        --主体ID，不能为空
                        p_Budget_Tree_Id In Number,
                        --预算树单元ID，不能为空
                        p_Fee_Type In Varchar2,
                        --费用类型，不能为空
                        p_Fee_Id In Number,
                        --费用单ID，不能为空
                        p_Fee_Code In Varchar2,
                        --费用单号，不能为空
                        p_Comments In Varchar2,
                        --备注信息
                        p_Pre_Field_01 In Varchar2,
                        --备用字段
                        p_Pre_Field_02 In Varchar2,
                        --备用字段
                        p_Pre_Field_03 In Varchar2,
                        --备用字段
                        p_Pre_Field_04 In Varchar2,
                        --备用字段
                        p_Pre_Field_05 In Varchar2,
                        --备用字段
                        p_Pre_Field_06 In Varchar2,
                        --备用字段
                        p_Pre_Field_07 In Varchar2,
                        --备用字段
                        p_Pre_Field_08 In Varchar2,
                        --备用字段
                        p_Pre_Field_09 In Varchar2,
                        --备用字段
                        p_Fee In Number,
                        --费用金额，不能为空，可正可负，两位小数
                        p_User_Id In Number,
                        --用户ID
                        p_Result Out Varchar2
                        --返回结果：成功返回"SUCCESS"，失败返回原因
                        ) Is

    CURSOR C_LOCK IS
      SELECT *
        FROM t_Pol_Budget_Tree
       Where Budget_Tree_Id in (Select Budget_Tree_Id
                                    From t_Pol_Budget_Tree
                                    Start With Budget_Tree_Id = p_Budget_Tree_Id
                                  Connect By Budget_Tree_Id = Prior Budget_Tree_Pre_Id)
        For Update Nowait;

    v_Pp                   Constant Varchar2(80) := '';--检查节点费用失败，
    v_Budget_Tree_Desc     t_Pol_Budget_Tree.Budget_Tree_Desc%type := '';
    v_Lower_CTL_Budget     number; --下层严控预算
    v_Lower_NO_CTL_FEE     number; --下层非严控费用
    v_Ok                   varchar2(1);
    V_LOWER_CTL_FLAG       VARCHAR2(1);  --下层是否严控
    v_Budget_Type          number; --预算树类型
    v_Budget_Tree_Level    Number; --预算树单元层次
    v_Budget_Tree_Value    Number; --预算树单元层次ID
    v_Budget_Tree_Pre_Id   Number; --上级预算树单元ID
    v_Bgt_Lower_Check_flag varchar2(10);  --预算金额检查
    v_Bgt_upper_Need_Check varchar2(10);
    v_Ctrl_Budget_Flag     varchar2(10);
  Begin
    v_Ok := v_y;
    v_Budget_Tree_Desc := '';

    --检查参数
    If p_Data_Flow_Id Is Null Or p_Entity_Id Is Null Or
       p_Budget_Tree_Id Is Null Or p_Fee_Type Is Null Or p_Fee_Id Is Null Or
       p_Fee_Code Is Null Or p_User_Id Is Null Then
      p_Result := Substrb('输入参数分别为(' || To_Char(p_Data_Flow_Id) || ',' ||
                          To_Char(p_Entity_Id) || ',' ||
                          To_Char(p_Budget_Tree_Id) || ',' || p_Fee_Type || ',' ||
                          To_Char(p_Fee_Id) || ',' || p_Fee_Code || ',' ||
                          To_Char(p_Fee) || ',' || To_Char(p_User_Id) || ')',
                          1,
                          240);
      Raise Ipt_Param_Err_Exp;
    End If;

    --根据费用是否为0确定处理
    If Nvl(p_Fee, 0) = 0 Then
      --中断处理，成功返回
      p_Result := v_Success;
      Return;
    End If;
    
    --获取预算进度控制的系统参数 20161213
    BEGIN
      PKG_BD.P_GET_PARAMETER_VALUE('CTRL_BUDGET_SCHE_FLAG', p_Entity_Id, null, null, v_Ctrl_Budget_Flag);
    EXCEPTION
      WHEN OTHERS THEN
        p_Result := '获取预算进度控制的系统参数失败';
        Raise Ipt_Param_Err_Exp;
    END;
    --系统参数未启用，则获取预算流的预算进度控制参数 2019-07-23
    IF v_Ctrl_Budget_Flag = 'N' THEN
      BEGIN
        SELECT NVL(F.CTRL_RATE_FLAG, 'N')
          INTO V_CTRL_BUDGET_FLAG
          FROM T_POL_BUDGET_DATA_FLOW F
         WHERE F.DATA_FLOW_ID = P_DATA_FLOW_ID;
      EXCEPTION
        WHEN OTHERS THEN
          P_RESULT := '获取预算流的预算进度控制参数失败';
          RAISE IPT_PARAM_ERR_EXP;
      END;
    END IF;

    --2006-12-05 王小华增加 取预算单元节点名称描述
    p_Result := Substrb('检查预算来源失败,请确定各参数是否正确,参数信息:(' || '数据流ID: ' ||
                        To_Char(p_Data_Flow_Id) || ',' || '主体ID:' ||
                        To_Char(p_Entity_Id) || ',' ||
                        '预算单元ID:' || To_Char(p_Budget_Tree_Id) || ')',
                        1,
                        240);

    --取预算节点描述
    Select Budget_Tree_Desc
      Into v_Budget_Tree_Desc
      From t_Pol_Budget_Tree
     Where Budget_Tree_Id = p_Budget_Tree_Id
       And Data_Flow_Id = p_Data_Flow_Id
       And Entity_Id = p_Entity_Id;

    --锁定要更新的预算节点
    OPEN C_LOCK;
    CLOSE C_LOCK;

    --------------一般用于检查政策申请
    --检查上级节点预算控制并读锁定，注意费用允许为负
    if Nvl(p_Fee, 0) > 0 then   --金额为正的，主要用于政策申请金额的判断
    begin
      --将下级节点严控初始为“N”，使系统检查传入的严控节点
      V_LOWER_CTL_FLAG := 'N';
      For r_Nod In
      (
                SELECT
                  *
                FROM
                  (
                    Select Budget_Tree_Id
                           ,Budget_Tree_Desc
                           ,Nvl(Control_Flag, 'N') Budget_CTL_Flag
                           ,bt.budget_tree_level
                           ,Nvl(Budget_Total_Amount, 0) Budget_Total_Amount
                           ,Nvl(Budget_Lower_Amount, 0) Budget_Lower_Amount
                           ,Nvl(Fee_Total_Amount, 0) Fee_Total_Amount
                           ,Nvl(Fee_Lower_Amount, 0) Fee_Lower_Amount
                           ,level BUDGET_LEVEL
                           ,CTRL_SCHE_RATE
                      From t_Pol_Budget_Tree bt
                      Start With Budget_Tree_Id = p_Budget_Tree_Id
                    Connect By Budget_Tree_Id = Prior Budget_Tree_Pre_Id
                  )
                --WHERE
                --  Budget_CTL_Flag = v_y
                ORDER BY
                  BUDGET_LEVEL
      ) Loop
        IF v_Ctrl_Budget_Flag = 'N' THEN
          --对于下层节点为不严控，且当前节点为严控(包括对于当前传入的节点为严控)，则检查
          IF r_Nod.Budget_CTL_Flag = v_y and V_LOWER_CTL_FLAG = v_n THEN
            v_Budget_Tree_Desc := r_Nod.budget_Tree_Desc;
            p_Result := Substrb('检查预算余额失败,参数信息:(' || r_Nod.budget_Tree_Desc || ':' ||
                                '预算余额不足,' || ',' ||-- '数据流ID:' ||
                               -- To_Char(p_Data_Flow_Id) || ',' || '主体ID:' ||
                               -- To_Char(p_Entity_Id) || ',' ||
                                '预算单元ID:' || To_Char(r_Nod.Budget_Tree_Id) || ','||
                                '费用金额:' || To_Char(p_Fee) || ')' || v_Nl
                                ,1
                                ,240);

            Select SUM(decode(bt.Control_Flag
                               ,v_y,Greatest(nvl(bt.Budget_Total_Amount,0),nvl(bt.fee_total_amount,0))
                               ,0
                             )
                   ) --求下层严控预算总额
                   ,sum(decode(bt.Control_Flag
                               ,v_y,0
                               ,bt.fee_total_amount
                             )
                   ) --求下层非严控费用
              into v_Lower_CTL_Budget
                   ,v_Lower_NO_CTL_FEE
              From t_Pol_Budget_Tree  bt
             start with bt.Budget_Tree_Pre_Id = to_char(r_Nod.Budget_Tree_Id)
            connect by (bt.Budget_Tree_Pre_Id = prior to_char(bt.budget_tree_id))
                   and (nvl(prior bt.Control_Flag,v_n) = v_n);

            v_Lower_CTL_Budget :=nvl(v_Lower_CTL_Budget,0);
            v_Lower_NO_CTL_FEE :=nvl(v_Lower_NO_CTL_FEE,0);

            --结点可用费用金额 = 该结点预算-该结点发生的费用-下层严控预算-下层非严控费用
            if r_Nod.Budget_Total_Amount --该结点预算
              - r_Nod.Fee_Total_Amount --该结点发生的费用
              - v_Lower_CTL_Budget --下层严控预算
              - v_Lower_NO_CTL_FEE --下层非严控费用
              < p_Fee
            then
              p_Result := '预算节点:'||v_Nl||v_Budget_Tree_Desc ||v_Nl||'可用预算(节点预算-已发生费用-下层严控预算-下层已发生费用)为:'||
                          TO_CHAR(r_Nod.Budget_Total_Amount - r_Nod.Fee_Total_Amount - v_Lower_CTL_Budget - v_Lower_NO_CTL_FEE)
                          ||'，不足以执行送审操作。'||v_Nl||
                          '该节点预算:'||TO_CHAR(r_Nod.Budget_Total_Amount)||
                          ',该节点已发生的费用:'||TO_CHAR(r_Nod.Fee_Total_Amount)||
                          ',下层严控预算:'||TO_CHAR(v_Lower_CTL_Budget)||
                          ',下层非严控费用:'||TO_CHAR(v_Lower_NO_CTL_FEE);
              v_Ok := v_n;
            end if; --ENF OF 判断预算是否足够

            EXIT;  --退出循环 从下往上找到第一个严控的，判断预算足够后就约定满足预算条件
          END IF;--ENF OF if r_Nod.Budget_CTL_Flag = v_y and V_LOWER_CTL_FLAG = v_n then
          --记录当前节点是否严控，作为下级节点严控标志，用于下一循环中
          V_LOWER_CTL_FLAG := r_Nod.Budget_CTL_Flag;
        ELSIF v_Ctrl_Budget_Flag = 'Y' THEN  --启用预算进度控制 20161213  生活事业部每个节点都为严控，每个节点都要判断预算是否足够
            IF v_Ok = v_y THEN
              v_Budget_Tree_Desc := r_Nod.budget_Tree_Desc;
              p_Result := Substrb('检查预算余额失败,参数信息:(' || r_Nod.budget_Tree_Desc || ':' ||
                                  '预算余额不足,' || ',' ||-- '数据流ID:' ||
                                 -- To_Char(p_Data_Flow_Id) || ',' || '主体ID:' ||
                                 -- To_Char(p_Entity_Id) || ',' ||
                                  '预算单元ID:' || To_Char(r_Nod.Budget_Tree_Id) || ','||
                                  '费用金额:' || To_Char(p_Fee) || ')' || v_Nl
                                  ,1
                                  ,240);
/*              Select SUM(decode(bt.Control_Flag
                                 ,v_y,Greatest(nvl(bt.Budget_Total_Amount,0),nvl(bt.fee_total_amount,0))
                                 ,0
                               )
                     ) --求下层严控预算总额
                     ,sum(decode(bt.Control_Flag
                                 ,v_y,0
                                 ,bt.fee_total_amount
                               )
                     ) --求下层非严控费用
                into v_Lower_CTL_Budget
                     ,v_Lower_NO_CTL_FEE
                From t_Pol_Budget_Tree  bt
               start with bt.Budget_Tree_Pre_Id = r_Nod.Budget_Tree_Id
              connect by (bt.Budget_Tree_Pre_Id = prior bt.budget_tree_id)
                     and (nvl(prior bt.Control_Flag,v_n) = v_n);

              v_Lower_CTL_Budget :=nvl(v_Lower_CTL_Budget,0);
              v_Lower_NO_CTL_FEE :=nvl(v_Lower_NO_CTL_FEE,0);*/

              --结点可用费用金额 = 该结点预算-该结点发生的费用-下层费用回写
              if r_Nod.Budget_Total_Amount * NVL(r_Nod.Ctrl_Sche_Rate, 1) --该结点预算
                - r_Nod.Fee_Total_Amount --该结点发生的费用
                - r_Nod.Fee_Lower_Amount --下层费用回写
                -- - v_Lower_CTL_Budget --下层严控预算
                -- - v_Lower_NO_CTL_FEE --下层非严控费用
                < p_Fee
              then
                p_Result := '预算节点:'||v_Nl||v_Budget_Tree_Desc ||v_Nl||'可用预算(节点预算*控制进度-已发生费用-下层费用回写)为:'||
                            TO_CHAR(r_Nod.Budget_Total_Amount* NVL(r_Nod.Ctrl_Sche_Rate, 1) - r_Nod.Fee_Total_Amount -  r_Nod.Fee_Lower_Amount)
                            ||'，不足以执行送审操作。'||v_Nl||
                            '节点预算*控制进度('||TO_CHAR(r_Nod.Budget_Total_Amount)||'*'||TO_CHAR(NVL(r_Nod.Ctrl_Sche_Rate, 1))||'):'||TO_CHAR(r_Nod.Budget_Total_Amount* NVL(r_Nod.Ctrl_Sche_Rate, 1))||
                            ',已发生费用:'||TO_CHAR(r_Nod.Fee_Total_Amount)||
                            ',下层费用回写:'||TO_CHAR(r_Nod.Fee_Lower_Amount);
                v_Ok := v_n;
              end if; --ENF OF 判断预算是否足够 
           END IF;   
        END IF;
      end loop;
    exception
      when others then
        if Sqlcode = -54 then
          p_Result :=  '预算结点 '||v_Nl||v_Budget_Tree_Desc ||v_Nl||' 正被其它用户锁定不能修改，请稍待再试。';
          v_Ok := v_n;
        else
          raise;
        end if;
    end;
    end if;

    --预算调整申请检查
    IF p_Fee_Type = '预算调整申请' THEN
      v_Bgt_Lower_Check_flag := 'N';
      v_Bgt_upper_Need_Check := 'N';
      For r_Adjust_Line_Nod In
        (
            SELECT
              *
            FROM
              (
                Select Budget_Tree_Id
                       ,Budget_Tree_Desc
                       ,Nvl(Control_Flag, 'N') Budget_CTL_Flag
                       ,bt.budget_tree_level
                       ,Nvl(Budget_Total_Amount, 0) Budget_Total_Amount
                       ,Nvl(Budget_Lower_Amount, 0) Budget_Lower_Amount
                       ,Nvl(Fee_Total_Amount, 0) Fee_Total_Amount
                       ,Nvl(Fee_Lower_Amount, 0) Fee_Lower_Amount
                       ,level BUDGET_LEVEL
                  From t_Pol_Budget_Tree bt
                  Start With Budget_Tree_Id = p_Budget_Tree_Id
                Connect By Budget_Tree_Id = Prior Budget_Tree_Pre_Id
              )
            --WHERE Budget_Tree_Id <> p_Budget_Tree_Id
            ORDER BY
              BUDGET_LEVEL
        )
       Loop

          p_Result := '[预算不允许为负]预算树调整金额后为负数，检查并读锁定预算树单元失败(' || To_Char(p_Data_Flow_Id) || ',' ||
                To_Char(p_Entity_Id) || ',' ||
                To_Char(p_Budget_Tree_Id) || ',' ||
                To_Char(p_Fee) || ')';
          Select Budget_Tree_Desc,
                 Budget_Tree_Pre_Id
            Into v_Budget_Tree_Desc,
            v_Budget_Tree_Pre_Id
            From t_Pol_Budget_Tree
           Where Budget_Tree_Id = r_Adjust_Line_Nod.Budget_Tree_Id;

         --若当前节点等于最下层的节点,首先判断预算金额追加预算后是否为负
         IF p_Budget_Tree_Id = r_Adjust_Line_Nod.Budget_Tree_Id THEN
           BEGIN
             Select
                   Budget_Tree_Level,
                   Decode(Budget_Tree_Level,
                          1, Budget_Segment_01_Id,
                          2, Budget_Segment_02_Id,
                          3, Budget_Segment_03_Id,
                          4, Budget_Segment_04_Id,
                          5, Budget_Segment_05_Id,
                          6, Budget_Segment_06_Id,
                          -1),
                   'Y'
              Into v_Budget_Tree_Level,
                   v_Budget_Tree_Value,
                   v_Bgt_Lower_Check_flag
              From t_Pol_Budget_Tree
             Where Budget_Tree_Id = r_Adjust_Line_Nod.Budget_Tree_Id-- --p_Budget_Tree_Id--
               And Data_Flow_Id = p_Data_Flow_Id
               And Entity_Id = p_Entity_Id
               And (Nvl(p_Fee, 0) < 0 And
                   (Nvl(Budget_Total_Amount, 0) + Nvl(p_Fee, 0)) >=
                   Nvl(Budget_Lower_Amount, 0) And
                   Nvl(Budget_Lower_Amount, 0) >= 0 And
                   (Nvl(Control_Flag, v_Null) = v_y And
                   ((Nvl(Budget_Total_Amount, 0) + Nvl(p_Fee, 0)) -
                   Greatest(Nvl(Fee_Total_Amount, 0), 0) -
                   Greatest(Nvl(Budget_Lower_Amount, 0),
                               Nvl(Fee_Lower_Amount, 0),
                               0)) >= 0 Or Nvl(Control_Flag, v_Null) = v_n) Or
                   Nvl(p_Fee, 0) >= 0)
               For Update Nowait;
               v_Bgt_Lower_Check_flag := 'Y';    --无异常则最下层判断通过
              EXCEPTION WHEN OTHERS THEN
               v_Bgt_Lower_Check_flag := 'N';
            END;
            ----------------若预算在下层，当前预算严控，从当层调出，需要判断下层预算是否足够。

            --如果预算判断通过，且为严控，则预算足够
            IF (v_Bgt_Lower_Check_flag = 'Y') and (r_Adjust_Line_Nod.Budget_Ctl_Flag = 'Y') THEN
              v_Ok := v_y;
            END IF;
            --如果最底层预算不严控，且判断通过，需要增加上级预算是否足够
            IF (v_Bgt_Lower_Check_flag = 'Y') and (r_Adjust_Line_Nod.Budget_Ctl_Flag = 'N') THEN
              v_Bgt_upper_Need_Check := v_y;
            END IF;
            --如果最底层预算判断不通过，则为不通过
            IF (v_Bgt_Lower_Check_flag = 'N') THEN
              v_Ok := v_n;
              /*----------------若预算在下层，当前节点预算严控，从当层调出，需要判断下层预算是否足够。
              IF (r_Adjust_Line_Nod.Budget_Ctl_Flag = 'Y') THEN
                p_Result := Substrb('检查预算余额失败,参数信息:(' || r_Adjust_Line_Nod.budget_Tree_Desc || ':' ||
                                    '预算余额不足,' || ',' ||-- '数据流ID:' ||
                                   -- To_Char(p_Data_Flow_Id) || ',' || '主体ID:' ||
                                   -- To_Char(p_Entity_Id) || ',' ||
                                    '预算单元ID:' || To_Char(r_Adjust_Line_Nod.Budget_Tree_Id) || ','||
                                    '费用金额:' || To_Char(p_Fee) || ')' || v_Nl
                                    ,1
                                    ,240);

                Select SUM(decode(bt.Control_Flag
                                   ,v_y,Greatest(nvl(bt.Budget_Total_Amount,0),nvl(bt.fee_total_amount,0))
                                   ,0
                                 )
                       ) --求下层严控预算总额
                       ,sum(decode(bt.Control_Flag
                                   ,v_y,0
                                   ,bt.fee_total_amount
                                 )
                       ) --求下层非严控费用
                  into v_Lower_CTL_Budget
                       ,v_Lower_NO_CTL_FEE
                  From t_Pol_Budget_Tree  bt
                 start with bt.Budget_Tree_Pre_Id = r_Adjust_Line_Nod.Budget_Tree_Id
                connect by (bt.Budget_Tree_Pre_Id = prior bt.budget_tree_id)
                       and (nvl(prior bt.Control_Flag,v_n) = v_n);

                v_Lower_CTL_Budget :=nvl(v_Lower_CTL_Budget,0);
                v_Lower_NO_CTL_FEE :=nvl(v_Lower_NO_CTL_FEE,0);

                --结点可用费用金额 = 该结点预算-该结点发生的费用-下层严控预算-下层非严控费用
                if r_Adjust_Line_Nod.Budget_Total_Amount --该结点预算
                  - r_Adjust_Line_Nod.Fee_Total_Amount --该结点发生的费用
                  - v_Lower_CTL_Budget --下层严控预算
                  - v_Lower_NO_CTL_FEE --下层非严控费用
                  + p_Fee
                   < 0
                then
                  p_Result := '预算结点:'||v_Nl||v_Budget_Tree_Desc ||v_Nl||'可用预算为'||
                              (r_Adjust_Line_Nod.Budget_Total_Amount - r_Adjust_Line_Nod.Fee_Total_Amount - v_Lower_CTL_Budget - v_Lower_NO_CTL_FEE)
                              ||'，不足以执行调整预算操作。';
                  v_Ok := v_n;
                  v_Bgt_upper_Need_Check := v_n;
                else
                  v_Ok := v_y;
                  v_Bgt_upper_Need_Check := v_n;
                end if;
              ELSE --当层校验不通过，且非严控，则需要判断上层节点
                v_Bgt_upper_Need_Check := v_y;
              END IF;  */
            END IF;

            --如果最底层判断通过， 且不严控，则还需判断上层严控的节点
          ELSIF (p_Budget_Tree_Id <> r_Adjust_Line_Nod.Budget_Tree_Id) AND
             (v_Bgt_Lower_Check_flag = 'Y') AND
             (r_Adjust_Line_Nod.Budget_Ctl_Flag = 'Y') AND
             (v_Bgt_upper_Need_Check = v_y) THEN

            --对于下层节点为不严控，且当前节点为严控(包括对于当前传入的节点为严控)，则检查
            if r_Adjust_Line_Nod.Budget_CTL_Flag = v_y and V_LOWER_CTL_FLAG = v_n then

              v_Budget_Tree_Desc := r_Adjust_Line_Nod.budget_Tree_Desc;
              p_Result := Substrb('检查预算余额失败,参数信息:(' || r_Adjust_Line_Nod.budget_Tree_Desc || ':' ||
                                  '预算余额不足,' || ',' ||-- '数据流ID:' ||
                                 -- To_Char(p_Data_Flow_Id) || ',' || '主体ID:' ||
                                 -- To_Char(p_Entity_Id) || ',' ||
                                  '预算单元ID:' || To_Char(r_Adjust_Line_Nod.Budget_Tree_Id) || ','||
                                  '费用金额:' || To_Char(p_Fee) || ')' || v_Nl
                                  ,1
                                  ,240);

              Select SUM(decode(bt.Control_Flag
                                 ,v_y,Greatest(nvl(bt.Budget_Total_Amount,0),nvl(bt.fee_total_amount,0))
                                 ,0
                               )
                     ) --求下层严控预算总额
                     ,sum(decode(bt.Control_Flag
                                 ,v_y,0
                                 ,bt.fee_total_amount
                               )
                     ) --求下层非严控费用
                into v_Lower_CTL_Budget
                     ,v_Lower_NO_CTL_FEE
                From t_Pol_Budget_Tree  bt
               start with bt.Budget_Tree_Pre_Id = to_char(r_Adjust_Line_Nod.Budget_Tree_Id)
              connect by (bt.Budget_Tree_Pre_Id = prior to_char(bt.budget_tree_id))
                     and (nvl(prior bt.Control_Flag,v_n) = v_n);

              v_Lower_CTL_Budget :=nvl(v_Lower_CTL_Budget,0);
              v_Lower_NO_CTL_FEE :=nvl(v_Lower_NO_CTL_FEE,0);

              --结点可用费用金额 = 该结点预算-该结点发生的费用-下层严控预算-下层非严控费用
              if r_Adjust_Line_Nod.Budget_Total_Amount --该结点预算
                - r_Adjust_Line_Nod.Fee_Total_Amount --该结点发生的费用
                - v_Lower_CTL_Budget --下层严控预算
                - v_Lower_NO_CTL_FEE --下层非严控费用
                + p_Fee
                 < 0
              then
                p_Result := '预算结点:'||v_Nl||v_Budget_Tree_Desc ||v_Nl||'可用预算为'||
                            (r_Adjust_Line_Nod.Budget_Total_Amount - r_Adjust_Line_Nod.Fee_Total_Amount - v_Lower_CTL_Budget - v_Lower_NO_CTL_FEE)
                            ||'，不足以执行调整预算操作。';
                v_Ok := v_n;
              end if;

              exit;
            end if;

/*            --如果是上层节点，上层节点判断的时候要扣掉当前下级回写的预算
            Select Budget_Tree_Pre_Id,
                 Budget_Tree_Level,
                 Decode(Budget_Tree_Level,
                        1, Budget_Segment_01_Id,
                        2, Budget_Segment_02_Id,
                        3, Budget_Segment_03_Id,
                        4, Budget_Segment_04_Id,
                        5, Budget_Segment_05_Id,
                        6, Budget_Segment_06_Id,
                        -1),
                 Budget_Tree_Desc
            Into v_Budget_Tree_Pre_Id,
                 v_Budget_Tree_Level,
                 v_Budget_Tree_Value,
                 v_Budget_Tree_Desc
            From t_Pol_Budget_Tree
           Where Budget_Tree_Id = r_Adjust_Line_Nod.Budget_Tree_Id-- --p_Budget_Tree_Id--
             And Data_Flow_Id = p_Data_Flow_Id
             And Entity_Id = p_Entity_Id
             And (Nvl(p_Fee, 0) < 0 And
                 (Nvl(Budget_Total_Amount, 0) + Nvl(p_Fee, 0)) >=
                 Nvl(Budget_Lower_Amount, 0)+ Nvl(p_Fee, 0) And
                 Nvl(Budget_Lower_Amount, 0)+ Nvl(p_Fee, 0) >= 0 And
                 (Nvl(Control_Flag, v_Null) = v_y And
                 ((Nvl(Budget_Total_Amount, 0) + Nvl(p_Fee, 0)) -
                 Greatest(Nvl(Fee_Total_Amount, 0), 0) -
                 Greatest(Nvl(Budget_Lower_Amount, 0)+ Nvl(p_Fee, 0),
                             Nvl(Fee_Lower_Amount, 0),
                             0)) >= 0 Or Nvl(Control_Flag, v_Null) = v_n) Or
                 Nvl(p_Fee, 0) >= 0)
             For Update Nowait;*/
          END IF;

          --上级预算树单元存在时处理

/*          If Nvl(v_Budget_Tree_Pre_Id, -1) <> -1 Then
            --检查并读锁定上级预算树单元
            --预算往下分配时比较宽松，没有考虑下层费用情况
            --★★★

            p_Result := '[预算不允许为负]预算树调整金额后为负数，检查并读锁定上级预算树单元失败(' || To_Char(p_Data_Flow_Id) || ',' ||
                        To_Char(p_Entity_Id) || ',' ||
                        To_Char(v_Budget_Tree_Pre_Id) || ',' ||
                        To_Char(p_Fee) || ')';
            Select Budget_Tree_Desc
            Into v_Budget_Tree_Desc
            From t_Pol_Budget_Tree
           Where Budget_Tree_Id = v_Budget_Tree_Pre_Id;

            Select v_Success
              Into p_Result
              From t_Pol_Budget_Tree
             Where Budget_Tree_Id = v_Budget_Tree_Pre_Id
               And Data_Flow_Id = p_Data_Flow_Id
               And Entity_Id = p_Entity_Id
               And (Nvl(p_Fee, 0) > 0 And
                   Nvl(Budget_Total_Amount, 0) >=
                   (Nvl(Budget_Lower_Amount, 0) + Nvl(p_Fee, 0)) And
                   (Nvl(Budget_Lower_Amount, 0) + Nvl(p_Fee, 0)) >= 0 And
                   (Nvl(Control_Flag, v_Null) = v_y And
                   (Nvl(Budget_Total_Amount, 0) -
                   Greatest(Nvl(Fee_Total_Amount, 0), 0) -
                   Greatest((Nvl(Budget_Lower_Amount, 0) +
                               Nvl(p_Fee, 0)),
                               0)) >= 0 Or Nvl(Control_Flag, v_Null) = v_n) Or
                   Nvl(p_Fee, 0) <= 0)
               For Update Nowait;
         End If;*/
           --记录当前节点是否严控，作为下级节点严控标志，用于下一循环中
           V_LOWER_CTL_FLAG := r_Adjust_Line_Nod.Budget_CTL_Flag;
        END LOOP;
    END IF;

    if v_Ok = v_y then
      --成功处理返回
      p_Result := v_Success;
    end if;
  Exception
    --返回错误信息，回滚到保存点
    When Procedure_Brk_Exp Then
      p_Result := v_Pp || '调用错误：' || v_Nl || v_Budget_Tree_Desc || p_Result;
    When Ipt_Param_Err_Exp Then
      p_Result := v_Pp || '参数错误：'|| v_Budget_Tree_Desc || p_Result;
    When Sql_Not_Found_Exp Then
      p_Result := v_Pp || '更新无效：' || v_Budget_Tree_Desc|| p_Result;
    When No_Data_Found Then
      p_Result := v_Pp || '查无记录：'|| v_Budget_Tree_Desc || p_Result;
    When Too_Many_Rows Then
      p_Result := v_Pp || '查多记录：'|| v_Budget_Tree_Desc || p_Result;
    When Others Then
      if (Sqlcode = -54) then
        p_Result := v_Pp || '预算节点被其他用户锁定，请稍后再试（'|| '数据流ID: ' ||
                        To_Char(p_Data_Flow_Id) || ',' || '主体ID:' ||
                        To_Char(p_Entity_Id) || ',' ||
                        '预算单元ID:' || To_Char(p_Budget_Tree_Id) || ')';
      else
        p_Result := substrb(v_Pp || '未知错误：' || p_Result || v_Nl || Sqlcode || ': ' || Sqlerrm, 1, 200);
      end if;
  end p_Check_Fee;

 /*===============================================================
  * Program Name:   p_Check_Fee
  * Purpose     :   检查节点费用
   ===============================================================*/
  Procedure p_Check_Fee(p_Data_Flow_Id In Number,
                        --数据流程ID，不能为空
                        p_Entity_Id In Number,
                        --主体ID，不能为空
                        p_Budget_Segment_01_Id In Number Default -1,
                        --预算层次01ID
                        p_Budget_Segment_02_Id In Number Default -1,
                        --预算层次02ID
                        p_Budget_Segment_03_Id In Number Default -1,
                        --预算层次03ID
                        p_Budget_Segment_04_Id In Number Default -1,
                        --预算层次04ID
                        p_Budget_Segment_05_Id In Number Default -1,
                        --预算层次05ID
                        p_Budget_Segment_06_Id In Number Default -1,
                        --预算层次06ID
                        p_Fee_Type In Varchar2,
                        --费用类型，不能为空
                        p_Fee_Id In Number,
                        --费用单ID，不能为空
                        p_Fee_Code In Varchar2,
                        --费用单号，不能为空
                        p_Comments In Varchar2,
                        --备注信息
                        p_Pre_Field_01 In Varchar2,
                        --备用字段
                        p_Fee In Number,
                        --费用金额，不能为空，可正可负，两位小数
                        p_User_Id In Number,
                        --用户ID
                        p_Result Out Varchar2
                        --返回结果：成功返回"SUCCESS"，失败返回原因
                        ) Is

    v_Pp Constant Varchar2(80) := '';--检查节点费用失败，

    v_Budget_Tree_Id Number; --预算节点ID

  Begin
    --建保存点
    --SAVEPOINT Sp_Write_Fee;

    --检查参数
    If p_Data_Flow_Id Is Null Or p_Entity_Id Is Null Or
       p_Budget_Segment_01_Id Is Null Or p_Budget_Segment_02_Id Is Null Or
       p_Budget_Segment_03_Id Is Null Or p_Budget_Segment_04_Id Is Null Or
       p_Budget_Segment_05_Id Is Null Or p_Budget_Segment_06_Id Is Null Or
       p_Fee_Type Is Null Or p_Fee_Id Is Null Or p_Fee_Code Is Null Or
       --Nvl(p_Fee, 0) = 0 OR
       --Nvl(p_Fee, 0) <> Trunc(Nvl(p_Fee, 0), 2) Or --20080904 何加源修改 取消两位小数控制
       p_User_Id Is Null Then
      p_Result := '输入参数分别为(' || To_Char(p_Data_Flow_Id) || ',' ||
                  To_Char(p_Entity_Id) || ',' ||
                  To_Char(p_Budget_Segment_01_Id) || ',' ||
                  To_Char(p_Budget_Segment_02_Id) || ',' ||
                  To_Char(p_Budget_Segment_03_Id) || ',' ||
                  To_Char(p_Budget_Segment_04_Id) || ',' ||
                  To_Char(p_Budget_Segment_05_Id) || ',' ||
                  To_Char(p_Budget_Segment_06_Id) || ',' || p_Fee_Type || ',' ||
                  To_Char(p_Fee_Id) || ',' || p_Fee_Code || ',' ||
                  To_Char(p_Fee) || ',' || To_Char(p_User_Id) || ')';
      Raise Ipt_Param_Err_Exp;
    End If;

    --根据费用是否为0确定处理
    If Nvl(p_Fee, 0) = 0 Then
      --中断处理，成功返回
      p_Result := v_Success;
      Return;
    End If;

    --根据层次获取指定预算单元
    p_Result := Substrb(('根据层次获取指定预算单元(' || To_Char(p_Data_Flow_Id) || ',' ||
                        To_Char(p_Entity_Id) || ',' ||
                        To_Char(p_Budget_Segment_01_Id) || ',' ||
                        To_Char(p_Budget_Segment_02_Id) || ',' ||
                        To_Char(p_Budget_Segment_03_Id) || ',' ||
                        To_Char(p_Budget_Segment_04_Id) || ',' ||
                        To_Char(p_Budget_Segment_05_Id) || ',' ||
                        To_Char(p_Budget_Segment_06_Id) || ')' || v_Nl ||
                        '该预算单元不存在，请重新选择，或者联系系统管理员！'),
                        1,
                        240);
    Select Budget_Tree_Id
      Into v_Budget_Tree_Id
      From t_Pol_Budget_Tree
     Where Data_Flow_Id = p_Data_Flow_Id
       And Entity_Id = p_Entity_Id
       And Budget_Segment_01_Id = p_Budget_Segment_01_Id
       And Budget_Segment_02_Id = p_Budget_Segment_02_Id
       And Budget_Segment_03_Id = p_Budget_Segment_03_Id
       And Budget_Segment_04_Id = p_Budget_Segment_04_Id
       And Budget_Segment_05_Id = p_Budget_Segment_05_Id
       And Budget_Segment_06_Id = p_Budget_Segment_06_Id;

    --调用过程检查节点费用
    p_Check_Fee(p_Data_Flow_Id,
                p_Entity_Id,
                v_Budget_Tree_Id,
                p_Fee_Type,
                p_Fee_Id,
                p_Fee_Code,
                p_Comments,
                p_Pre_Field_01,
                Null,
                Null,
                Null,
                Null,
                Null,
                Null,
                Null,
                Null,
                p_Fee,
                p_User_Id,
                p_Result);
    If Nvl(p_Result, v_Null) <> v_Success Then
      Raise Procedure_Brk_Exp;
    End If;

    --成功处理返回
    p_Result := v_Success;
  Exception
    --返回错误信息，回滚到保存点
    When Procedure_Brk_Exp Then
      p_Result := v_Pp || '调用错误：' || v_Nl || p_Result;
      --ROLLBACK TO SAVEPOINT Sp_Write_Fee;
    When Ipt_Param_Err_Exp Then
      p_Result := v_Pp || '参数错误：' || p_Result;
      --ROLLBACK TO SAVEPOINT Sp_Write_Fee;
    When Sql_Not_Found_Exp Then
      p_Result := v_Pp || '更新无效：' || p_Result;
      --ROLLBACK TO SAVEPOINT Sp_Write_Fee;
    When No_Data_Found Then
      p_Result := v_Pp || '查无记录：' || p_Result;
      --ROLLBACK TO SAVEPOINT Sp_Write_Fee;
    When Too_Many_Rows Then
      p_Result := v_Pp || '查多记录：' || p_Result;
      --ROLLBACK TO SAVEPOINT Sp_Write_Fee;
    When Others Then
      p_Result := v_Pp || '未知错误：' || p_Result || v_Nl || Sqlcode || ': ' || Sqlerrm;
      --ROLLBACK TO SAVEPOINT Sp_Write_Fee;
  End p_Check_Fee;

 /*===============================================================
  * Program Name:   F_GET_Segment03
  * Purpose     :   是否可以负数报账
   ===============================================================*/
  function F_GET_Segment03(p_Budget_Segment_Name Varchar2,
                           p_Entity_Id number)
    return    Varchar2 is
     vResult  Varchar2(1);
  begin

    /*Select Nvl((Select 'Y'
               From Dual
              Where p_Budget_Segment_Name In
                    (Select Sep.Parameter_Value
                       From t_Sm_Entity_Parameters Sep
                      Where Sep.Parameter_Id = (Select Ssp.Parameter_Id
                                                  From t_Sm_System_Parameters Ssp
                                                 Where Ssp.Parameter_Code = '负数报账')
                        And Sep.Finance_Entity_Id = p_Entity_Id)),
             'N')
    Into Vresult
    From Dual;*/

    return(vResult);
  end F_GET_Segment03;

  /*=====================检查预算调整金额----已作废
  */
  Procedure P_CHECK_BUDGET_FEE(P_BUDGET_ADJUST_LINE_ID In Number,
                               p_Result Out Varchar2
                               )IS
   P_BUSINESS_TYPE  VARCHAR2(2);
   P_BUDGET_ADJUST_CODE VARCHAR2(100);
   P_BUDGET_TREE_ID_IN NUMBER;
   P_BUDGET_TREE_ID_OUT NUMBER;
   P_BUDGET_ADJUST_AMOUNT NUMBER;
   P_DATA_FLOW_ID NUMBER;
   P_ENTITY_ID NUMBER;
   P_CREATE_BY VARCHAR2(32);
   P_USER_ID NUMBER;
   P_BUDGET_SEGMENT_01_ID NUMBER;
   P_BUDGET_SEGMENT_02_ID NUMBER;
   P_BUDGET_SEGMENT_03_ID NUMBER;
   P_BUDGET_SEGMENT_04_ID NUMBER;
   P_BUDGET_SEGMENT_05_ID NUMBER;
   P_BUDGET_SEGMENT_06_ID NUMBER;
   BEGIN
     p_Result := 'SUCCESS';

     BEGIN
       SELECT B.BUSINESS_TYPE,
              B.BUDGET_ADJUST_CODE,
              A.BUDGET_TREE_ID_IN,
              A.BUDGET_TREE_ID_OUT,
              A.BUDGET_ADJUST_AMOUNT,
              A.CREATED_BY
         INTO P_BUSINESS_TYPE,
              P_BUDGET_ADJUST_CODE,
              P_BUDGET_TREE_ID_IN,
              P_BUDGET_TREE_ID_OUT,
              P_BUDGET_ADJUST_AMOUNT,
              P_CREATE_BY
         FROM T_POL_BUDGET_ADJUST_LINE A,
              T_POL_BUDGET_ADJUST_HEAD B
        WHERE A.BUDGET_ADJUST_ID = B.BUDGET_ADJUST_ID
          AND A.BUDGET_ADJUST_LINE_ID = P_BUDGET_ADJUST_LINE_ID;
     END;

     BEGIN
       SELECT PX.USER_ID
         INTO P_USER_ID
         FROM UP_ORG_USER PX
        WHERE PX.ACCOUNT = P_CREATE_BY;
     END;

     IF P_BUSINESS_TYPE = 2 THEN
       SELECT PA.DATA_FLOW_ID,
              PA.ENTITY_ID,
              PA.BUDGET_SEGMENT_01_ID,
              PA.BUDGET_SEGMENT_02_ID,
              PA.BUDGET_SEGMENT_03_ID,
              PA.BUDGET_SEGMENT_04_ID,
              PA.BUDGET_SEGMENT_05_ID,
              PA.BUDGET_SEGMENT_06_ID
         INTO P_DATA_FLOW_ID,
              P_ENTITY_ID,
              P_BUDGET_SEGMENT_01_ID,
              P_BUDGET_SEGMENT_02_ID,
              P_BUDGET_SEGMENT_03_ID,
              P_BUDGET_SEGMENT_04_ID,
              P_BUDGET_SEGMENT_05_ID,
              P_BUDGET_SEGMENT_06_ID
         FROM T_POL_BUDGET_TREE PA
        WHERE PA.BUDGET_TREE_ID = P_BUDGET_TREE_ID_IN;

        p_Check_Fee(P_DATA_FLOW_ID,
                    P_ENTITY_ID,
                    NVL(P_BUDGET_SEGMENT_01_ID, -1),
                    NVL(P_BUDGET_SEGMENT_02_ID, -1),
                    NVL(P_BUDGET_SEGMENT_03_ID, -1),
                    NVL(P_BUDGET_SEGMENT_04_ID, -1),
                    NVL(P_BUDGET_SEGMENT_05_ID, -1),
                    NVL(P_BUDGET_SEGMENT_06_ID, -1),
                    '预算调整申请',
                    P_BUDGET_ADJUST_LINE_ID,
                    P_BUDGET_ADJUST_CODE,
                    NULL,
                    NULL,
                    -P_BUDGET_ADJUST_AMOUNT,
                    NVL(P_USER_ID, -1),
                    p_Result);
     END IF;

     IF P_BUSINESS_TYPE = 1 THEN
       SELECT PA.DATA_FLOW_ID,
              PA.ENTITY_ID,
              PA.BUDGET_SEGMENT_01_ID,
              PA.BUDGET_SEGMENT_02_ID,
              PA.BUDGET_SEGMENT_03_ID,
              PA.BUDGET_SEGMENT_04_ID,
              PA.BUDGET_SEGMENT_05_ID,
              PA.BUDGET_SEGMENT_06_ID
         INTO P_DATA_FLOW_ID,
              P_ENTITY_ID,
              P_BUDGET_SEGMENT_01_ID,
              P_BUDGET_SEGMENT_02_ID,
              P_BUDGET_SEGMENT_03_ID,
              P_BUDGET_SEGMENT_04_ID,
              P_BUDGET_SEGMENT_05_ID,
              P_BUDGET_SEGMENT_06_ID
         FROM T_POL_BUDGET_TREE PA
        WHERE PA.BUDGET_TREE_ID = P_BUDGET_TREE_ID_OUT;

        p_Check_Fee(P_DATA_FLOW_ID,
                    P_ENTITY_ID,
                    NVL(P_BUDGET_SEGMENT_01_ID, -1),
                    NVL(P_BUDGET_SEGMENT_02_ID, -1),
                    NVL(P_BUDGET_SEGMENT_03_ID, -1),
                    NVL(P_BUDGET_SEGMENT_04_ID, -1),
                    NVL(P_BUDGET_SEGMENT_05_ID, -1),
                    NVL(P_BUDGET_SEGMENT_06_ID, -1),
                    '预算调整申请',
                    P_BUDGET_ADJUST_LINE_ID,
                    P_BUDGET_ADJUST_CODE,
                    NULL,
                    NULL,
                    P_BUDGET_ADJUST_AMOUNT,
                    NVL(P_USER_ID, -1),
                    p_Result);
     END IF;

   END;

 /*===============================================================
  * Program Name:   P_JUDGE_BUDGET_ADJUST
  * Purpose     :   检查预算调整单是否足够
   ===============================================================*/
   Procedure P_JUDGE_BUDGET_ADJUST(P_BUDGET_ADJUST_HEAD_ID In Number,
                                p_Result Out Varchar2
                           )IS
     /*
     1：调出调入
      调出    调入   调整金额
      减少    增加    正数
      增加    减少    负数

      2：直接追加
       直接追加       调整金额
         增加          正数
         减少          负数
      */
     CURSOR C_BUDGET_LINE IS
      -- 调入调出为正数的，判断调出节点
       SELECT PL.BUDGET_TREE_ID_OUT AS TREE_ID, SUM(PL.BUDGET_ADJUST_AMOUNT) * -1 AS ADJUST_AMOUNT
         FROM T_POL_BUDGET_ADJUST_HEAD PH,
              T_POL_BUDGET_ADJUST_LINE PL
         WHERE PH.BUDGET_ADJUST_ID = P_BUDGET_ADJUST_HEAD_ID
           AND PH.BUDGET_ADJUST_ID = PL.BUDGET_ADJUST_ID
           AND PH.BUSINESS_TYPE = 1  --调出调入
           AND PL.BUDGET_ADJUST_AMOUNT > 0
         GROUP BY PL.BUDGET_TREE_ID_OUT
         UNION ALL
       -- 调入调出为负数的，判断调入节点
       SELECT PL.BUDGET_TREE_ID_IN AS TREE_ID, SUM(PL.BUDGET_ADJUST_AMOUNT)  AS ADJUST_AMOUNT
         FROM T_POL_BUDGET_ADJUST_HEAD PH,
              T_POL_BUDGET_ADJUST_LINE PL
         WHERE PH.BUDGET_ADJUST_ID = P_BUDGET_ADJUST_HEAD_ID
           AND PH.BUDGET_ADJUST_ID = PL.BUDGET_ADJUST_ID
           AND PH.BUSINESS_TYPE = 1  --调出调入
           AND PL.BUDGET_ADJUST_AMOUNT < 0
         GROUP BY PL.BUDGET_TREE_ID_IN
         UNION ALL
       --直接追加为负数的，需要判断调入节点是否有足够的预算
       SELECT PL.BUDGET_TREE_ID_IN AS TREE_ID, SUM(PL.BUDGET_ADJUST_AMOUNT) AS ADJUST_AMOUNT
         FROM T_POL_BUDGET_ADJUST_HEAD PH,
              T_POL_BUDGET_ADJUST_LINE PL
         WHERE PH.BUDGET_ADJUST_ID = P_BUDGET_ADJUST_HEAD_ID
           AND PH.BUDGET_ADJUST_ID = PL.BUDGET_ADJUST_ID
           AND PH.BUSINESS_TYPE = 2  --直接追加
           AND PL.BUDGET_ADJUST_AMOUNT < 0
         GROUP BY PL.BUDGET_TREE_ID_IN
         ;
     --R_BUDGET_LINE C_BUDGET_LINE%ROWTYPE;
     V_USER_ID  NUMBER;
     V_DATA_FLOW_ID NUMBER;
     V_ENTITY_ID NUMBER;
     V_BUDGET_ADJUST_CODE VARCHAR2(100);
     V_BUDGET_SEGMENT_01_ID NUMBER;
     V_BUDGET_SEGMENT_02_ID NUMBER;
     V_BUDGET_SEGMENT_03_ID NUMBER;
     V_BUDGET_SEGMENT_04_ID NUMBER;
     V_BUDGET_SEGMENT_05_ID NUMBER;
     V_BUDGET_SEGMENT_06_ID NUMBER;
   BEGIN
     p_Result := 'SUCCESS';

     BEGIN
       SELECT PX.USER_ID,
              PH.BUDGET_ADJUST_CODE
         INTO V_USER_ID,
              V_BUDGET_ADJUST_CODE
         FROM T_POL_BUDGET_ADJUST_HEAD PH,
              UP_ORG_USER PX
        WHERE PH.BUDGET_ADJUST_ID = P_BUDGET_ADJUST_HEAD_ID
          AND PH.CREATED_BY = PX.ACCOUNT;
     END;

     FOR R_BUDGET_LINE IN C_BUDGET_LINE LOOP
       IF p_Result <> v_Success THEN
         EXIT;
       ELSE
         SELECT PA.DATA_FLOW_ID,
                PA.ENTITY_ID,
                PA.BUDGET_SEGMENT_01_ID,
                PA.BUDGET_SEGMENT_02_ID,
                PA.BUDGET_SEGMENT_03_ID,
                PA.BUDGET_SEGMENT_04_ID,
                PA.BUDGET_SEGMENT_05_ID,
                PA.BUDGET_SEGMENT_06_ID
           INTO V_DATA_FLOW_ID,
                V_ENTITY_ID,
                V_BUDGET_SEGMENT_01_ID,
                V_BUDGET_SEGMENT_02_ID,
                V_BUDGET_SEGMENT_03_ID,
                V_BUDGET_SEGMENT_04_ID,
                V_BUDGET_SEGMENT_05_ID,
                V_BUDGET_SEGMENT_06_ID
           FROM T_POL_BUDGET_TREE PA
          WHERE PA.BUDGET_TREE_ID = R_BUDGET_LINE.TREE_ID;

          p_Check_Fee(V_DATA_FLOW_ID,
                      V_ENTITY_ID,
                      NVL(V_BUDGET_SEGMENT_01_ID, -1),
                      NVL(V_BUDGET_SEGMENT_02_ID, -1),
                      NVL(V_BUDGET_SEGMENT_03_ID, -1),
                      NVL(V_BUDGET_SEGMENT_04_ID, -1),
                      NVL(V_BUDGET_SEGMENT_05_ID, -1),
                      NVL(V_BUDGET_SEGMENT_06_ID, -1),
                      '预算调整申请',
                      P_BUDGET_ADJUST_HEAD_ID,
                      V_BUDGET_ADJUST_CODE,
                      NULL,
                      NULL,
                      R_BUDGET_LINE.ADJUST_AMOUNT,
                      NVL(V_USER_ID, -1),
                      p_Result);
       END IF;
     END LOOP;
   END P_JUDGE_BUDGET_ADJUST;


   /*
   *  获取预算占用标识位
   *  hutao
   */
   PROCEDURE P_GET_BUDGET_FLAG(P_BUDGET_ADJUST_ID  IN NUMBER,
                               P_RESULT            OUT VARCHAR2
                               )IS
   BEGIN
     SELECT PA.BUDGET_OUT_FLAG
       INTO P_RESULT
       FROM T_POL_BUDGET_ADJUST_HEAD PA
      WHERE PA.BUDGET_ADJUST_ID = P_BUDGET_ADJUST_ID;
   END;

   /*===============================================================
  * Program Name:   P_BUDGET_ADJUST_CHECK
  * Purpose     :   预算调整执行预算过程
   ===============================================================*/
   PROCEDURE P_BUDGET_ADJUST_CHECK(P_BUDGET_ADJUST_HEAD_ID In Number,
                                  P_TO_CHECK_FLAG IN Varchar2,--送审
                                  P_CHECKED_FLAG IN Varchar2, --审核
                                  P_REJECT_FLAG IN Varchar2,  --驳回
                                  P_INVALID_FLAG IN Varchar2,  --作废
                                  p_Result Out Varchar2
                               )IS
     v_Pp Constant Varchar2(80) := '占用预算失败，';
     V_BUSINESS_TYPE Varchar2(10);
     V_USER_ID  NUMBER;
   BEGIN
     p_Result := v_Success;
     SAVEPOINT SP_ADJUST_CHECK;

     --获取预算调整 类型
     SELECT PH.BUSINESS_TYPE, OU.USER_ID
       INTO V_BUSINESS_TYPE, V_USER_ID
       FROM T_POL_BUDGET_ADJUST_HEAD PH,
            UP_ORG_USER OU
      WHERE PH.BUDGET_ADJUST_ID = P_BUDGET_ADJUST_HEAD_ID
        AND PH.CREATED_BY = OU.ACCOUNT;

     FOR C_ADJUST_LINE IN (
        --调出调入--调出--调入
        SELECT PH.DATA_FLOW_ID,
               PH.ENTITY_ID,
               PL.BUDGET_ADJUST_LINE_ID,
               PL.BUDGET_TREE_ID_OUT,
               PL.BUDGET_ADJUST_AMOUNT * -1 AS ADJUST_REDUCE_AMOUNT,
               PL.BUDGET_TREE_ID_IN,
               PL.BUDGET_ADJUST_AMOUNT AS ADJUST_ADD_AMOUNT,
               PH.CREATED_BY,
               NVL(PH.BUDGET_OUT_FLAG, 'N') BUDGET_OUT_FLAG, --调出影响预算标记位
               NVL(PH.BUDGET_FLAG, 'N') BUDGET_FLAG,  --调入占用预算标记位
               PH.BUDGET_ADJUST_CODE,
               PH.COMMENTS,
               PH.BUSINESS_TYPE
          FROM T_POL_BUDGET_ADJUST_HEAD PH, T_POL_BUDGET_ADJUST_LINE PL
         WHERE PH.BUDGET_ADJUST_ID = P_BUDGET_ADJUST_HEAD_ID
           AND PH.BUDGET_ADJUST_ID = PL.BUDGET_ADJUST_ID
           AND PH.BUSINESS_TYPE = 1
         UNION ALL
        --直接追加
        SELECT PH.DATA_FLOW_ID,
               PH.ENTITY_ID,
               PL.BUDGET_ADJUST_LINE_ID,
               0 BUDGET_TREE_ID_OUT,
               0 AS ADJUST_REDUCE_AMOUNT,
               PL.BUDGET_TREE_ID_IN,
               PL.BUDGET_ADJUST_AMOUNT AS ADJUST_ADD_AMOUNT,
               PH.CREATED_BY,
               NVL(PH.BUDGET_OUT_FLAG, 'N') BUDGET_OUT_FLAG, --调出影响预算标记位
               NVL(PH.BUDGET_FLAG, 'N') BUDGET_FLAG,  --调入占用预算标记位
               PH.BUDGET_ADJUST_CODE,
               PH.COMMENTS,
               PH.BUSINESS_TYPE
         FROM T_POL_BUDGET_ADJUST_HEAD PH,
              T_POL_BUDGET_ADJUST_LINE PL
         WHERE PH.BUDGET_ADJUST_ID = P_BUDGET_ADJUST_HEAD_ID
           AND PH.BUDGET_ADJUST_ID = PL.BUDGET_ADJUST_ID
           AND PH.BUSINESS_TYPE = 2
                           )
     LOOP
       --提交时候，调出调入的，先扣减预算
       IF C_ADJUST_LINE.BUSINESS_TYPE = '1' THEN
         IF P_TO_CHECK_FLAG = 'Y' THEN
           IF (p_Result = v_Success) and (C_ADJUST_LINE.BUDGET_OUT_FLAG = 'N') THEN
             p_Direct_Adjust_Budget(C_ADJUST_LINE.DATA_FLOW_ID,
                                       C_ADJUST_LINE.Entity_Id,
                                       C_ADJUST_LINE.BUDGET_TREE_ID_OUT,
                                       C_ADJUST_LINE.ADJUST_REDUCE_AMOUNT,
                                       C_ADJUST_LINE.BUDGET_ADJUST_LINE_ID,
                                       C_ADJUST_LINE.BUDGET_ADJUST_CODE,
                                       C_ADJUST_LINE.BUSINESS_TYPE,--'预算调整申请',
                                       C_ADJUST_LINE.COMMENTS,
                                       V_USER_ID,
                                       p_Result);
           END IF;
         END IF;
         IF (P_REJECT_FLAG = 'Y') OR (P_INVALID_FLAG = 'Y') THEN  --撤回、驳回时候，调出调入反向追加预算
           IF (p_Result = v_Success) and (C_ADJUST_LINE.BUDGET_OUT_FLAG = 'Y') THEN
             p_Direct_Adjust_Budget(C_ADJUST_LINE.DATA_FLOW_ID,
                                       C_ADJUST_LINE.Entity_Id,
                                       C_ADJUST_LINE.BUDGET_TREE_ID_OUT,
                                       C_ADJUST_LINE.ADJUST_ADD_AMOUNT,
                                       C_ADJUST_LINE.BUDGET_ADJUST_LINE_ID,
                                       C_ADJUST_LINE.BUDGET_ADJUST_CODE,
                                       C_ADJUST_LINE.BUSINESS_TYPE,--'预算调整申请',
                                       C_ADJUST_LINE.COMMENTS,
                                       V_USER_ID,
                                       p_Result);
           END IF;
         END IF;
       END IF;

       IF P_CHECKED_FLAG = 'Y' THEN
         IF (p_Result = v_Success) and (NVL(C_ADJUST_LINE.BUDGET_FLAG,'N') = 'N')
             AND (NVL(C_ADJUST_LINE.BUDGET_TREE_ID_IN, 0) <> 0) THEN
           p_Direct_Adjust_Budget(C_ADJUST_LINE.DATA_FLOW_ID,
                                     C_ADJUST_LINE.Entity_Id,
                                     C_ADJUST_LINE.BUDGET_TREE_ID_IN,
                                     C_ADJUST_LINE.ADJUST_ADD_AMOUNT,
                                     C_ADJUST_LINE.BUDGET_ADJUST_LINE_ID,
                                     C_ADJUST_LINE.BUDGET_ADJUST_CODE,
                                     C_ADJUST_LINE.BUSINESS_TYPE,--'预算调整申请',
                                     C_ADJUST_LINE.COMMENTS,
                                     V_USER_ID,
                                     p_Result);
         END IF;
       END IF;
     END LOOP;

     --处理预算后，更新标记位
     IF (p_Result = v_Success) THEN
       IF V_BUSINESS_TYPE = '1' THEN
         IF P_TO_CHECK_FLAG = 'Y' THEN
           UPDATE T_POL_BUDGET_ADJUST_HEAD PH
             SET PH.BUDGET_OUT_FLAG = 'Y'
            WHERE PH.BUDGET_ADJUST_ID = P_BUDGET_ADJUST_HEAD_ID;
         END IF;
         IF P_REJECT_FLAG = 'Y' THEN  --撤回、驳回时候，调出调入反向追加预算
           UPDATE T_POL_BUDGET_ADJUST_HEAD PH
             SET PH.BUDGET_OUT_FLAG = 'N'
            WHERE PH.BUDGET_ADJUST_ID = P_BUDGET_ADJUST_HEAD_ID;
         END IF;
       END IF;

       --作废更新标记为
       IF P_INVALID_FLAG = 'Y' THEN
         UPDATE T_POL_BUDGET_ADJUST_HEAD PH
             SET PH.BUDGET_OUT_FLAG = 'N',
                 PH.BUDGET_FLAG = 'N',
                 PH.REFER_FLAG = '2'
            WHERE PH.BUDGET_ADJUST_ID = P_BUDGET_ADJUST_HEAD_ID;
       END IF;

       IF P_CHECKED_FLAG = 'Y' THEN
         UPDATE T_POL_BUDGET_ADJUST_HEAD PH
           SET PH.BUDGET_FLAG = 'Y'
          WHERE PH.BUDGET_ADJUST_ID = P_BUDGET_ADJUST_HEAD_ID;
       END IF;
     END IF;
   Exception
    When Procedure_Brk_Exp Then
      p_Result := v_Pp || '调用错误：' || v_Nl || p_Result;
      Rollback To Savepoint SP_ADJUST_CHECK;
    When Ipt_Param_Err_Exp Then
      p_Result := v_Pp || '参数错误：' || p_Result;
      Rollback To Savepoint SP_ADJUST_CHECK;
    When Sql_Not_Found_Exp Then
      p_Result := v_Pp || '更新无效：' || p_Result;
      Rollback To Savepoint SP_ADJUST_CHECK;
    When No_Data_Found Then
      p_Result := v_Pp || '查无记录：' || p_Result;
      Rollback To Savepoint SP_ADJUST_CHECK;
    When Too_Many_Rows Then
      p_Result := v_Pp || '查多记录：' || p_Result;
      Rollback To Savepoint SP_ADJUST_CHECK;
    When Others Then
      p_Result := v_Pp || '未知错误：' || p_Result || v_Nl || Sqlcode || ': ' || Sqlerrm;
      Rollback To Savepoint SP_ADJUST_CHECK;
      If Sqlcode = -6508 Then
        dbms_session.reset_package;
      End if;
   END P_BUDGET_ADJUST_CHECK;
   
   /*===============================================================
  * Program Name:   P_BUDGET_CTRL_ADJUST
  * Purpose     :   预算进度调整过程
   ===============================================================*/
  PROCEDURE P_BUDGET_CTRL_ADJUST(P_CTRL_BATCH_ID In Number,
                                  p_User_Id IN Varchar2,
                                  p_Result Out Varchar2
                               ) IS
  v_laryer number;
  v_pa     number;
  BEGIN
    p_Result := v_Success;
    SAVEPOINT SP_CTRL_ADJUST;
    FOR CTRL_ADJUST IN (SELECT PS.CTRL_ID, PS.DATA_FLOW_ID, PS.BUDGET_TREE_ID, PS.CTRL_SCHE_RATE
                          FROM T_POL_BUDGET_CTRL_SCHEDULE PS WHERE PS.CTRL_BATCH_ID = P_CTRL_BATCH_ID)
    LOOP
      UPDATE T_POL_BUDGET_TREE PT
         SET PT.CTRL_SCHE_RATE = DECODE(CTRL_ADJUST.CTRL_SCHE_RATE, 1, NULL, 0, NULL, CTRL_ADJUST.CTRL_SCHE_RATE),
             PT.LAST_UPDATED_BY = p_User_Id,
             PT.LAST_UPDATE_DATE = SYSDATE
       WHERE PT.BUDGET_TREE_ID = CTRL_ADJUST.BUDGET_TREE_ID
         AND PT.DATA_FLOW_ID = CTRL_ADJUST.DATA_FLOW_ID;  
         
      UPDATE T_POL_BUDGET_CTRL_SCHEDULE PC
         SET PC.EXEC_FLAG = 'Y',
             PC.LAST_UPDATED_BY = p_User_Id,
             PC.LAST_UPDATE_DATE = SYSDATE 
       WHERE PC.CTRL_ID = CTRL_ADJUST.CTRL_ID;
    END LOOP;
   /* select case
           when a.budget_segment_03_code is not null and
                a.budget_segment_04_code is null then
            3
           when a.budget_segment_04_code is not null and
                a.budget_segment_05_code is null then
            4
           when a.budget_segment_05_code is not null and
                a.budget_segment_06_code is null then
            5
           when a.budget_segment_06_code is not null then
            5
         end
    into v_laryer
    from t_pol_budget_ctrl_schedule a
   where a.ctrl_batch_id =  P_CTRL_BATCH_ID
     and rownum = 1;
 
  if v_laryer = 6 then
    --计算第5层
    for lay5 in (select a.budget_segment_01_code,
                        a.budget_segment_02_code,
                        a.budget_segment_03_code,
                        a.budget_segment_04_code,
                        a.budget_segment_05_code,
                        a.data_flow_id
                   from t_pol_budget_ctrl_schedule a
                  where a.ctrl_batch_id = P_CTRL_BATCH_ID
                  group by a.budget_segment_01_code,
                           a.budget_segment_02_code,
                           a.budget_segment_03_code,
                           a.budget_segment_04_code,
                           a.budget_segment_05_code,
                           a.data_flow_id) loop
      --查询子节点的值
    
      --更新到父节点
      update cims.t_pol_budget_tree a
         set a.ctrl_sche_rate =
             (select (sum(a.budget_total_amount * a.ctrl_sche_rate) /
                     decode(sum(a.budget_total_amount),0,1,decode(sum(a.budget_total_amount),0,1,sum(a.budget_total_amount))))
              
                from cims.t_pol_budget_tree a
               where 1 = 1
                 and budget_segment_01_code = lay5.budget_segment_01_code
                 and budget_segment_02_code = lay5.budget_segment_02_code
                 and budget_segment_03_code = lay5.budget_segment_03_code
                 and budget_segment_04_code = lay5.budget_segment_04_code
                 and budget_segment_05_code = lay5.budget_segment_05_code
                 and budget_segment_06_code is not null
                 and a.data_flow_id = lay5.data_flow_id
                 and a.ctrl_sche_rate is not null
             
               group by a.budget_segment_01_code,
                        a.budget_segment_02_code,
                        a.budget_segment_03_code,
                        a.budget_segment_04_code,
                        a.budget_segment_05_code,
                        a.data_flow_id)
       where 1 = 1
         and budget_segment_01_code = lay5.budget_segment_01_code
         and budget_segment_02_code = lay5.budget_segment_02_code
         and budget_segment_03_code = lay5.budget_segment_03_code
         and budget_segment_04_code = lay5.budget_segment_04_code
         and budget_segment_05_code = lay5.budget_segment_05_code
         and budget_segment_06_code is null;
    end loop;
    end if ;
   if v_laryer = 5 then
    --计算第4层
    for lay4 in (select a.budget_segment_01_code,
                        a.budget_segment_02_code,
                        a.budget_segment_03_code,
                        a.budget_segment_04_code,
                        a.data_flow_id
                   from t_pol_budget_ctrl_schedule a
                  where a.ctrl_batch_id = P_CTRL_BATCH_ID
                  group by a.budget_segment_01_code,
                           a.budget_segment_02_code,
                           a.budget_segment_03_code,
                           a.budget_segment_04_code,
                           a.data_flow_id) loop
      --查询子节点的值
    
      
      --更新到父节点
      update cims.t_pol_budget_tree a
         set a.ctrl_sche_rate =
             (select (sum(a.budget_total_amount * a.ctrl_sche_rate) /
                     decode(sum(a.budget_total_amount),0,1,sum(a.budget_total_amount)))
                from cims.t_pol_budget_tree a
               where 1 = 1
                 and budget_segment_01_code = lay4.budget_segment_01_code
                 and budget_segment_02_code = lay4.budget_segment_02_code
                 and budget_segment_03_code = lay4.budget_segment_03_code
                 and budget_segment_04_code = lay4.budget_segment_04_code
                 and budget_segment_05_code is not null
                 and budget_segment_06_code is null
                 and a.data_flow_id = lay4.data_flow_id
                 and a.ctrl_sche_rate is not null
             
               group by a.budget_segment_01_code,
                        a.budget_segment_02_code,
                        a.budget_segment_03_code,
                        a.budget_segment_04_code,
                        a.data_flow_id)
       where 1 = 1
         and budget_segment_01_code = lay4.budget_segment_01_code
         and budget_segment_02_code = lay4.budget_segment_02_code
         and budget_segment_03_code = lay4.budget_segment_03_code
         and budget_segment_04_code = lay4.budget_segment_04_code
         and budget_segment_05_code is null;
    end loop;
  end if;
  --非6层结构的直接计算
  --计算第3层    
  for lay3 in (select a.budget_segment_01_code,
                      a.budget_segment_02_code,
                      a.budget_segment_03_code,
                      
                      a.data_flow_id
                 from t_pol_budget_ctrl_schedule a
                where a.ctrl_batch_id = P_CTRL_BATCH_ID
                group by a.budget_segment_01_code,
                         a.budget_segment_02_code,
                         a.budget_segment_03_code,
                         
                         a.data_flow_id) loop
    --查询子节点的值
  
    --更新到父节点
    update cims.t_pol_budget_tree a
       set a.ctrl_sche_rate =
           (select nvl((sum(a.budget_total_amount * a.ctrl_sche_rate) /
                       decode(sum(a.budget_total_amount),0,1,sum(a.budget_total_amount))),
                       0)
              from cims.t_pol_budget_tree a
             where 1 = 1
               and budget_segment_01_code = lay3.budget_segment_01_code
               and budget_segment_02_code = lay3.budget_segment_02_code
               and budget_segment_03_code = lay3.budget_segment_03_code
               and budget_segment_04_code is not null
               and budget_segment_05_code is null
               and a.data_flow_id = lay3.data_flow_id
               and a.ctrl_sche_rate is not null
               
             group by a.budget_segment_01_code,
                      a.budget_segment_02_code,
                      a.budget_segment_03_code,
                      a.data_flow_id)
     where 1 = 1
       and budget_segment_01_code = lay3.budget_segment_01_code
       and budget_segment_02_code = lay3.budget_segment_02_code
       and budget_segment_03_code is not null
       and budget_segment_04_code is null;
  end loop;
  --计算第2层    
  for lay2 in (select a.budget_segment_01_code,
                      a.budget_segment_02_code,
                      
                      a.data_flow_id
                 from t_pol_budget_ctrl_schedule a
                where a.ctrl_batch_id = P_CTRL_BATCH_ID
                group by a.budget_segment_01_code,
                         a.budget_segment_02_code,
                         
                         a.data_flow_id) loop
  
    --更新到父节点
    update cims.t_pol_budget_tree a
       set a.ctrl_sche_rate =
           (select (sum(a.budget_total_amount * a.ctrl_sche_rate) /
                   decode(sum(a.budget_total_amount),0,1,sum(a.budget_total_amount)))
            
              from cims.t_pol_budget_tree a
             where 1 = 1
               and budget_segment_01_code = lay2.budget_segment_01_code
               and budget_segment_02_code = lay2.budget_segment_02_code
               and budget_segment_03_code is not null
               and budget_segment_04_code is null
               and a.data_flow_id = lay2.data_flow_id
               and a.ctrl_sche_rate is not null
              
             group by a.budget_segment_01_code,
                      a.budget_segment_02_code,
                      a.data_flow_id)
     where 1 = 1
       and budget_segment_01_code = lay2.budget_segment_01_code
       and budget_segment_02_code = lay2.budget_segment_02_code
       and budget_segment_03_code is null;
  end loop;
  --计算第1层    
  for lay1 in (select a.budget_segment_01_code,
                      
                      a.data_flow_id
                 from t_pol_budget_ctrl_schedule a
                where a.ctrl_batch_id = P_CTRL_BATCH_ID
                group by a.budget_segment_01_code,
                         
                         a.data_flow_id) loop
    --查询子节点的值
  
    --更新到父节点
    update cims.t_pol_budget_tree a
       set a.ctrl_sche_rate =
           (select (sum(a.budget_total_amount * a.ctrl_sche_rate) /
                   decode(sum(a.budget_total_amount),0,1,sum(a.budget_total_amount)))
              from cims.t_pol_budget_tree a
             where 1 = 1
               and budget_segment_01_code = lay1.budget_segment_01_code
               and budget_segment_02_code is not null
               and budget_segment_03_code is null
               and a.data_flow_id = lay1.data_flow_id
               and a.ctrl_sche_rate is not null
             
             group by a.budget_segment_01_code, a.data_flow_id)
     where 1 = 1
       and budget_segment_01_code = lay1.budget_segment_01_code
       and budget_segment_02_code is null;
  end loop;*/
    Exception
      When Others Then
        p_Result := '批量更新进度错误：' || Sqlcode || ': ' || Sqlerrm;
        Rollback To Savepoint SP_CTRL_ADJUST;
  END P_BUDGET_CTRL_ADJUST;
  
  /*===============================================================
   * Program Name:   P_JUDGE_CROSS_BUDGET_ADJUST
   * Purpose     :   检查跨主体预算调整单预算是否足够
  =================================================================*/
  PROCEDURE P_JUDGE_CROSS_BUDGET_ADJUST(P_BUDGET_ADJUST_HEAD_ID IN NUMBER
                                       ,P_RESULT OUT VARCHAR2) IS
    CURSOR C_BUDGET_LINE IS
       SELECT PL.BUDGET_TREE_ID_OUT AS TREE_ID, (PL.BUDGET_ADJUST_AMOUNT * (-1)) AS ADJUST_AMOUNT
         FROM T_POL_BUDGET_ADJUST_CROSS_HEAD PH,
              T_POL_BUDGET_ADJUST_CROSS_LINE PL
         WHERE PH.BUDGET_ADJUST_ID = P_BUDGET_ADJUST_HEAD_ID
           AND PH.BUDGET_ADJUST_ID = PL.BUDGET_ADJUST_ID
           AND PL.BUDGET_ADJUST_AMOUNT > 0;
     V_USER_ID  NUMBER;
     V_DATA_FLOW_ID NUMBER;
     V_ENTITY_ID NUMBER;
     V_BUDGET_ADJUST_CODE VARCHAR2(100);
     V_BUDGET_SEGMENT_01_ID NUMBER;
     V_BUDGET_SEGMENT_02_ID NUMBER;
     V_BUDGET_SEGMENT_03_ID NUMBER;
     V_BUDGET_SEGMENT_04_ID NUMBER;
     V_BUDGET_SEGMENT_05_ID NUMBER;
     V_BUDGET_SEGMENT_06_ID NUMBER;
   BEGIN
     P_RESULT := 'SUCCESS';
     
     BEGIN
       SELECT PX.USER_ID,
              PH.BUDGET_ADJUST_CODE
         INTO V_USER_ID,
              V_BUDGET_ADJUST_CODE
         FROM T_POL_BUDGET_ADJUST_CROSS_HEAD PH,
              UP_ORG_USER PX
        WHERE PH.BUDGET_ADJUST_ID = P_BUDGET_ADJUST_HEAD_ID
          AND PH.CREATED_BY = PX.ACCOUNT;
     END;

     FOR R_BUDGET_LINE IN C_BUDGET_LINE LOOP
       IF P_RESULT <> V_SUCCESS THEN
         EXIT;
       ELSE
         SELECT PA.DATA_FLOW_ID,
                PA.ENTITY_ID,
                PA.BUDGET_SEGMENT_01_ID,
                PA.BUDGET_SEGMENT_02_ID,
                PA.BUDGET_SEGMENT_03_ID,
                PA.BUDGET_SEGMENT_04_ID,
                PA.BUDGET_SEGMENT_05_ID,
                PA.BUDGET_SEGMENT_06_ID
           INTO V_DATA_FLOW_ID,
                V_ENTITY_ID,
                V_BUDGET_SEGMENT_01_ID,
                V_BUDGET_SEGMENT_02_ID,
                V_BUDGET_SEGMENT_03_ID,
                V_BUDGET_SEGMENT_04_ID,
                V_BUDGET_SEGMENT_05_ID,
                V_BUDGET_SEGMENT_06_ID
           FROM T_POL_BUDGET_TREE PA
          WHERE PA.BUDGET_TREE_ID = R_BUDGET_LINE.TREE_ID;

          P_CHECK_FEE(V_DATA_FLOW_ID,
                      V_ENTITY_ID,
                      NVL(V_BUDGET_SEGMENT_01_ID, -1),
                      NVL(V_BUDGET_SEGMENT_02_ID, -1),
                      NVL(V_BUDGET_SEGMENT_03_ID, -1),
                      NVL(V_BUDGET_SEGMENT_04_ID, -1),
                      NVL(V_BUDGET_SEGMENT_05_ID, -1),
                      NVL(V_BUDGET_SEGMENT_06_ID, -1),
                      '预算调整申请',
                      P_BUDGET_ADJUST_HEAD_ID,
                      V_BUDGET_ADJUST_CODE,
                      NULL,
                      NULL,
                      R_BUDGET_LINE.ADJUST_AMOUNT,
                      NVL(V_USER_ID, -1),
                      P_RESULT);
       END IF;
     END LOOP;
  END P_JUDGE_CROSS_BUDGET_ADJUST;
  
  /*===============================================================
  * Program Name:   P_EXECUTE_CROSS_BUDGET_ADJUST
  * Purpose     :   执行跨主体预算调整
  ===============================================================*/
  PROCEDURE P_EXECUTE_CROSS_BUDGET_ADJUST(P_BUDGET_ADJUST_HEAD_ID IN NUMBER
                                         ,P_TO_CHECK_FLAG         IN VARCHAR2 --送审
                                         ,P_CHECKED_FLAG          IN VARCHAR2 --审核
                                         ,P_REJECT_FLAG           IN VARCHAR2 --驳回
                                         ,P_INVALID_FLAG          IN VARCHAR2 --作废
                                         ,P_RESULT                OUT VARCHAR2) IS
    V_PP CONSTANT VARCHAR2(80) := '占用预算失败，';
    V_USER_ID       NUMBER;
  BEGIN
    P_RESULT := V_SUCCESS;
    SAVEPOINT SP_ADJUST_CHECK;
  
    --获取预算调整 类型
    SELECT OU.USER_ID
      INTO V_USER_ID
      FROM T_POL_BUDGET_ADJUST_CROSS_HEAD PH, UP_ORG_USER OU
     WHERE PH.BUDGET_ADJUST_ID = P_BUDGET_ADJUST_HEAD_ID
       AND PH.CREATED_BY = OU.ACCOUNT;
  
    FOR C_ADJUST_LINE IN (SELECT PH.OUT_DATA_FLOW_ID
                                ,PH.ENTITY_ID OUT_ENTITY_ID
                                ,PH.IN_DATA_FLOW_ID
                                ,PH.IN_DATA_FLOW_ENTITY_ID IN_ENTITY_ID
                                ,PL.BUDGET_ADJUST_LINE_ID
                                ,PL.BUDGET_TREE_ID_OUT
                                ,PL.BUDGET_ADJUST_AMOUNT * -1 AS ADJUST_REDUCE_AMOUNT
                                ,PL.BUDGET_TREE_ID_IN
                                ,PL.BUDGET_ADJUST_AMOUNT AS ADJUST_ADD_AMOUNT
                                ,PH.CREATED_BY
                                ,NVL(PH.BUDGET_OUT_FLAG, 'N') BUDGET_OUT_FLAG
                                ,NVL(PH.BUDGET_IN_FLAG, 'N') BUDGET_IN_FLAG
                                ,PH.BUDGET_ADJUST_CODE
                                ,PH.BUSINESS_TYPE
                                ,PH.COMMENTS
                            FROM T_POL_BUDGET_ADJUST_CROSS_HEAD PH
                                ,T_POL_BUDGET_ADJUST_CROSS_LINE PL
                           WHERE PH.BUDGET_ADJUST_ID = P_BUDGET_ADJUST_HEAD_ID
                             AND PH.BUDGET_ADJUST_ID = PL.BUDGET_ADJUST_ID)
    LOOP
      --提交的时候，先扣减调出节点预算
      IF P_TO_CHECK_FLAG = 'Y' THEN
        IF (P_RESULT = V_SUCCESS) AND (C_ADJUST_LINE.BUDGET_OUT_FLAG = 'N') THEN
          P_DIRECT_ADJUST_BUDGET(C_ADJUST_LINE.OUT_DATA_FLOW_ID,
                                 C_ADJUST_LINE.OUT_ENTITY_ID,
                                 C_ADJUST_LINE.BUDGET_TREE_ID_OUT,
                                 C_ADJUST_LINE.ADJUST_REDUCE_AMOUNT,
                                 C_ADJUST_LINE.BUDGET_ADJUST_LINE_ID,
                                 C_ADJUST_LINE.BUDGET_ADJUST_CODE,
                                 C_ADJUST_LINE.BUSINESS_TYPE,
                                 C_ADJUST_LINE.COMMENTS,
                                 V_USER_ID,
                                 P_RESULT);
        END IF;
      END IF;
      
      --撤回、驳回、作废，反向追加调出节点预算
      IF (P_REJECT_FLAG = 'Y') OR (P_INVALID_FLAG = 'Y') THEN 
        IF (P_RESULT = V_SUCCESS) AND (C_ADJUST_LINE.BUDGET_OUT_FLAG = 'Y') THEN
          P_DIRECT_ADJUST_BUDGET(C_ADJUST_LINE.OUT_DATA_FLOW_ID,
                                 C_ADJUST_LINE.OUT_ENTITY_ID,
                                 C_ADJUST_LINE.BUDGET_TREE_ID_OUT,
                                 C_ADJUST_LINE.ADJUST_ADD_AMOUNT,
                                 C_ADJUST_LINE.BUDGET_ADJUST_LINE_ID,
                                 C_ADJUST_LINE.BUDGET_ADJUST_CODE,
                                 C_ADJUST_LINE.BUSINESS_TYPE,
                                 C_ADJUST_LINE.COMMENTS,
                                 V_USER_ID,
                                 P_RESULT);
        END IF;
      END IF;
      
      --审核通过
      IF P_CHECKED_FLAG = 'Y' THEN
        IF (P_RESULT = V_SUCCESS) AND
           (NVL(C_ADJUST_LINE.BUDGET_IN_FLAG, 'N') = 'N') AND
           (NVL(C_ADJUST_LINE.BUDGET_TREE_ID_IN, 0) <> 0) THEN
          P_DIRECT_ADJUST_BUDGET(C_ADJUST_LINE.IN_DATA_FLOW_ID,
                                 C_ADJUST_LINE.IN_ENTITY_ID,
                                 C_ADJUST_LINE.BUDGET_TREE_ID_IN,
                                 C_ADJUST_LINE.ADJUST_ADD_AMOUNT,
                                 C_ADJUST_LINE.BUDGET_ADJUST_LINE_ID,
                                 C_ADJUST_LINE.BUDGET_ADJUST_CODE,
                                 C_ADJUST_LINE.BUSINESS_TYPE,
                                 C_ADJUST_LINE.COMMENTS,
                                 V_USER_ID,
                                 P_RESULT);
        END IF;
      END IF;
    END LOOP;
  
    --处理预算后，更新状态、预算标记位
    IF (P_RESULT = V_SUCCESS) THEN
      IF P_TO_CHECK_FLAG = 'Y' THEN
        UPDATE T_POL_BUDGET_ADJUST_CROSS_HEAD PH
           SET PH.BUDGET_OUT_FLAG = 'Y'
              ,PH.STATUS          = '1'
              ,PH.VERSION         = PH.VERSION + 1
         WHERE PH.BUDGET_ADJUST_ID = P_BUDGET_ADJUST_HEAD_ID;
      END IF;
      
      IF P_CHECKED_FLAG = 'Y' THEN
        UPDATE T_POL_BUDGET_ADJUST_CROSS_HEAD PH
           SET PH.BUDGET_IN_FLAG = 'Y'
              ,PH.STATUS         = '3'
              ,PH.VERSION        = PH.VERSION + 1
         WHERE PH.BUDGET_ADJUST_ID = P_BUDGET_ADJUST_HEAD_ID;
      END IF;
      
      IF P_REJECT_FLAG = 'Y' THEN
        UPDATE T_POL_BUDGET_ADJUST_CROSS_HEAD PH
           SET PH.BUDGET_OUT_FLAG = 'N'
              ,PH.STATUS          = '4'
              ,PH.VERSION         = PH.VERSION + 1
         WHERE PH.BUDGET_ADJUST_ID = P_BUDGET_ADJUST_HEAD_ID;
      END IF;
      
      IF P_INVALID_FLAG = 'Y' THEN
        UPDATE T_POL_BUDGET_ADJUST_CROSS_HEAD PH
           SET PH.BUDGET_OUT_FLAG = 'N'
              ,PH.STATUS          = '2'
              ,PH.VERSION         = PH.VERSION + 1
         WHERE PH.BUDGET_ADJUST_ID = P_BUDGET_ADJUST_HEAD_ID;
      END IF;
    END IF;
  EXCEPTION
    WHEN PROCEDURE_BRK_EXP THEN
      P_RESULT := V_PP || '调用错误：' || V_NL || P_RESULT;
      ROLLBACK TO SAVEPOINT SP_ADJUST_CHECK;
    WHEN IPT_PARAM_ERR_EXP THEN
      P_RESULT := V_PP || '参数错误：' || P_RESULT;
      ROLLBACK TO SAVEPOINT SP_ADJUST_CHECK;
    WHEN SQL_NOT_FOUND_EXP THEN
      P_RESULT := V_PP || '更新无效：' || P_RESULT;
      ROLLBACK TO SAVEPOINT SP_ADJUST_CHECK;
    WHEN NO_DATA_FOUND THEN
      P_RESULT := V_PP || '查无记录：' || P_RESULT;
      ROLLBACK TO SAVEPOINT SP_ADJUST_CHECK;
    WHEN TOO_MANY_ROWS THEN
      P_RESULT := V_PP || '查多记录：' || P_RESULT;
      ROLLBACK TO SAVEPOINT SP_ADJUST_CHECK;
    WHEN OTHERS THEN
      P_RESULT := V_PP || '未知错误：' || P_RESULT || V_NL || SQLCODE || ': ' || SQLERRM;
      ROLLBACK TO SAVEPOINT SP_ADJUST_CHECK;
      IF SQLCODE = -6508 THEN
        DBMS_SESSION.RESET_PACKAGE;
      END IF;
  END P_EXECUTE_CROSS_BUDGET_ADJUST;

End Pkg_Budget;
/

