create PACKAGE      pkg_inv_reconciliation
IS
   err_success                     NUMBER;                             --成功
   g_ret_code                      NUMBER;                           --错误码
   g_ret_desc                      VARCHAR2 (256);                 --错误描述
   g_bill_status_audit             VARCHAR2 (2);                 --已审核。11
   g_bill_status_recv              VARCHAR2 (2);                 --已接收。13
   g_reconciliation_flag_success   VARCHAR2 (2);             --对账结果：成功
   g_reconciliation_flag_fail      VARCHAR2 (2);             --对账结果：失败
   g_reconciliation_status_open VARCHAR2(2);--对账状态：打开
   g_reconciliation_status_close VARCHAR2(2);--对账状态：关闭
   --单据类型bill_type_code
   g_so                            VARCHAR2 (100);              --1020:销售单
   g_so_red                        VARCHAR2 (100);          --1021:销售红冲单
   g_so_return                     VARCHAR2 (100);          --1031:销售退货单
   g_so_return_red                 VARCHAR2 (100);      --1032:销售退货红冲单
   g_po_transit                    VARCHAR2 (100);          --1001:采购中转单
   g_po_transit_red                VARCHAR2 (100);      --1002:采购中转红冲单
   g_po_transit_return             VARCHAR2 (100);      --1003:采购中转退货单
   g_po_transit_return_red         VARCHAR2 (100);  --1004:采购中转退货红冲单
   g_po_transit_repair             VARCHAR2 (100);  --1005:采购中转返修入库单
   g_po_transit_repair_red         VARCHAR2 (100);
   --1006:采购中转返修入库红冲单
   g_po_factory_tran               VARCHAR2 (100);          --1007:工厂中转单
   g_po_factory_tran_red           VARCHAR2 (100);      --1008:工厂中转红冲单
   g_po_factory_tran_return        VARCHAR2 (100);      --1009:工厂中转退货单
   g_po_factory_tran_return_red    VARCHAR2 (100);  --1010:工厂中转退货红冲单
   g_po                            VARCHAR2 (100);              --1011:采购单
   g_po_red                        VARCHAR2 (100);          --1012:采购红冲单
   g_po_preferential               VARCHAR2 (100);        --1013:优惠品采购单
   g_po_preferential_red           VARCHAR2 (100);    --1014:优惠品采购红冲单
   g_po_material                   VARCHAR2 (100);          --1015:物料采购单
   g_po_material_red               VARCHAR2 (100);      --1016:物料采购红冲单
   g_po_material_return            VARCHAR2 (100);      --1017:物料采购退货单
   g_po_material_return_red        VARCHAR2 (100);  --1018:物料采购退货红冲单
   g_trsf                          VARCHAR2 (100);          --1033:正常调拨单
   g_trsf_red                      VARCHAR2 (100);      --1034:正常调拨红冲单
   g_trsf_status                   VARCHAR2 (100);      --1035:状态调整调拨单
   g_check_profit                  VARCHAR2 (100);          --1036:盘盈入库单
   g_check_loss                    VARCHAR2 (100);          --1037:盘亏出库单
   g_check_gift                    VARCHAR2 (100);          --1038:赠送发出单
   g_check_gift_red                VARCHAR2 (100);      --1039:赠送发出红冲单
   g_stockup                       VARCHAR2 (100);              --1019:备货单
   g_send                          VARCHAR2 (100);      --1040:推广物料发放单

--对账主过程
   PROCEDURE p_inv_reconciliation_main (
      in_entity_id   IN       NUMBER,                            --经营主体ID
      on_ret_code    OUT      NUMBER,                                --错误码
      on_ret_desc    OUT      VARCHAR2                             --错误描述
   );
END pkg_inv_reconciliation;
/

