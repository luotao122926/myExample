create procedure P_INV_TRANSACTION_JOBS is
  -- declare
  cursor c_entitys is
    select * from cims.v_bd_entity;
begin
  -- PO库存事务对账
  for entity_l in c_entitys loop
    P_INV_PO_TRANSACTION(entity_l.entity_id);
    commit;
  end loop;

  -- 销售库存事务对账
  for entity_l in c_entitys loop
    P_INV_SO_TRANSACTION(entity_l.entity_id);
    commit;
  end loop;

  -- 调拨库存事务
  for entity_l in c_entitys loop
    P_INV_TRSF_TRANSACTION(entity_l.entity_id);
    commit;
  end loop;

  -- 盘点库存事务
  for entity_l in c_entitys loop
    P_INV_CHECK_TRANSACTION(entity_l.entity_id);
    commit;
  end loop;

  -- 推广物料发放
  for entity_l in c_entitys loop
    P_INV_PMT_TRANSACTION(entity_l.entity_id);
    commit;
  end loop;

   -- 更新库存事务对账日期-库存事务处理日期
  for entity_l in c_entitys loop
    P_INV_UPDATE_TRANSACTIONDATE(entity_l.entity_id);
    commit;
  end loop;
end P_INV_TRANSACTION_JOBS;
/

