create procedure P_INV_STORAGE(O_RESULT     OUT VARCHAR2, --返回错误码
                                            O_RESULT_MSG OUT VARCHAR2 --返回错误信息
                                            ) is

  --查询游标
  cursor V_STORAGE_cost is
    select dl.ENTITY_ID,
           dl.SITE_CODE,
           dl.SITE_NAME,
           dl.STORAGE_NUM,
           dl.STORAGE_NAME,
           dl.STIRGE_ADDR,
           dl.INV_STATUS
      from A3_C_IMS_WAREHOUSE dl;

  --临时变量，游标
  TEMP_V_STORAGE_ROW V_STORAGE_cost%ROWTYPE;

  --临时变量
  TEMP_CountSite number;

BEGIN
  O_RESULT     := '1';
  O_RESULT_MSG := '';

  BEGIN
    --打开游标
    open V_STORAGE_cost;

    LOOP
      FETCH V_STORAGE_cost
        INTO TEMP_V_STORAGE_ROW;
      EXIT WHEN V_STORAGE_cost%NOTFOUND;

      --设置回滚点
      SAVEPOINT savepoint_1;

      --把视图数据保存到本地表INTF_INV_STORAGE
      --判断更新或插入
      select count(1)
        INTO TEMP_CountSite
        from INTF_INV_STORAGE t
       where t.STORAGE_NUM = TEMP_V_STORAGE_ROW.STORAGE_NUM;

O_RESULT_MSG := O_RESULT_MSG||'||'||TEMP_V_STORAGE_ROW.STORAGE_NUM;

      IF (TEMP_CountSite = 0) THEN

        --insert
        insert into INTF_INV_STORAGE
          (INTF_INV_STORAGE_ID,
           SITE_CODE,
           SITE_NAME,
           STORAGE_NUM,
           STORAGE_NAME,
           STORAGE_ADDR,
           INV_STATUS)
        VALUES
          (S_INTF_INV_STORAGE.nextval,
           TEMP_V_STORAGE_ROW.SITE_CODE,
           TEMP_V_STORAGE_ROW.SITE_NAME,
           TEMP_V_STORAGE_ROW.STORAGE_NUM,
           TEMP_V_STORAGE_ROW.STORAGE_NAME,
           TEMP_V_STORAGE_ROW.STIRGE_ADDR,
           TEMP_V_STORAGE_ROW.INV_STATUS);

      ELSE

        --select t.ENTITY_ID,T.SITE_CODE,T.SITE_NAME,T.STORAGE_NUM,T.STORAGE_NAME,T.STIRGE_ADDR,T.INV_STATUS from A3_C_IMS_WAREHOUSE t

        update INTF_INV_STORAGE t
           set t.SITE_CODE    = TEMP_V_STORAGE_ROW.SITE_CODE,
               t.SITE_NAME    = TEMP_V_STORAGE_ROW.SITE_NAME,
               t.STORAGE_NAME = TEMP_V_STORAGE_ROW.STORAGE_NAME,
               t.STORAGE_ADDR  = TEMP_V_STORAGE_ROW.STIRGE_ADDR,
               t.INV_STATUS   = TEMP_V_STORAGE_ROW.INV_STATUS
         where t.STORAGE_NUM = TEMP_V_STORAGE_ROW.STORAGE_NUM;

      END IF;

    END LOOP;
    --commit;
    CLOSE V_STORAGE_cost;
  Exception
    When no_data_found THEN
      --回滚
      O_RESULT     := '0';
      O_RESULT_MSG := O_RESULT_MSG || 'no_data_found';
      --ROLLBACK TO SAVEPOINT savepoint_1;

  END;

end P_INV_STORAGE;

/

