create PACKAGE      PKG_SO_TO_POX IS

  --销售转采购：总部销售单结算后销司PO单才引入NC控制标识
  V_NC_PO_INTF_CONTROL_FLAG           CONSTANT VARCHAR2(64) := 'SO_TO_PO_NC_PO_INTF_CONTROL_FLAG';
  --PO引NC接口表，推送标识
  V_PO_NC_INV_INTF_STATUS_WAIT         CONSTANT VARCHAR2(4) :=  'WT';
  -- Author  : HEJY3
  -- Purpose : 销售转采购

  ---------------------------------------------------------
  --从销售单生成采购单
  ---------------------------------------------------------
  PROCEDURE P_SO_TO_POX_USEPARAM(IN_ENTITY_ID  IN NUMBER, --主体ID
                                 IN_PARAM_ID   IN NUMBER, --转采购参数表ID
                                 IN_USER_CODE  IN VARCHAR2, --操作用户
                                 OUT_PO_NUMBER OUT VARCHAR2, --采购单号
                                 OUT_RESULT    IN OUT VARCHAR2);

  ---------------------------------------------------------
  --生成代理商客户的销售单
  --销售单为自提，或直发且非安得接收
  ---------------------------------------------------------
  PROCEDURE P_TO_CUST_SO_USEPARAM(IN_ENTITY_ID  IN NUMBER, --主体ID
                                  IN_PARAM_ID   IN NUMBER, --转采购参数表ID
                                  IN_USER_CODE  IN VARCHAR2, --操作用户
                                  OUT_SO_NUMBER OUT VARCHAR2, --销售单号
                                  OUT_RESULT    IN OUT VARCHAR2);

  ---------------------------------------------------------
  --生成代理商客户的发运计划
  --销售单为直发且安得接收
  ---------------------------------------------------------
  PROCEDURE P_TO_CUST_SHIP_PLAN_USEPARAM(IN_ENTITY_ID   IN NUMBER, --主体ID
                                         IN_PARAM_ID    IN NUMBER, --转采购参数表ID
                                         IN_USER_CODE   IN VARCHAR2, --操作用户
                                         OUT_SHIP_BATCH OUT NUMBER, --发运批次ID
                                         OUT_RESULT     IN OUT VARCHAR2);

  ---------------------------------------------------------
  --提货订单二次发运库存占用
  ---------------------------------------------------------
  PROCEDURE P_LG_ORDER_PRE_INV_OCCUPY(IN_ENTITY_ID     IN NUMBER, --主体ID
                                      IN_ORDER_HEAD_ID IN NUMBER, --提货订单ID
                                      IN_ORDER_LINE_ID IN NUMBER, --提货订单行ID
                                      IN_OCCUPY_SIGN   IN NUMBER, --1 占用，-1 释放
                                      IN_USER_CODE     IN VARCHAR2, --操作用户
                                      OUT_RESULT       IN OUT VARCHAR2);

  ---------------------------------------------------------
  --生成预占用数据，用于提货订单二次发运
  --销售单为非直发，但是有来源客户提货订单
  ---------------------------------------------------------
  PROCEDURE P_PRE_INV_OCCUPY_USEPARAM(IN_ENTITY_ID IN NUMBER, --主体ID
                                      IN_PARAM_ID  IN NUMBER, --转采购参数表ID
                                      IN_USER_CODE IN VARCHAR2, --操作用户
                                      OUT_RESULT   IN OUT VARCHAR2);

  ---------------------------------------------------------
  --生成状态调拨单据
  --转采购销售单实收破损数大于0的产品
  ---------------------------------------------------------
  PROCEDURE P_TO_INV_TRSF_USEPARAM(IN_ENTITY_ID    IN NUMBER, --主体ID
                                   IN_PARAM_ID     IN NUMBER, --转采购参数表ID
                                   IN_OPT_TYPE     IN VARCHAR2, --处理类型 02 破损，03 残次品
                                   IN_USER_CODE    IN VARCHAR2, --操作用户
                                   OUT_TRSF_NUMBER OUT VARCHAR2, --调拨单据号
                                   OUT_RESULT      IN OUT VARCHAR2);

  ---------------------------------------------------------
  --生成承运商全赔单据
  --转采购销售单短少数大于0的产品
  ---------------------------------------------------------
  PROCEDURE P_TO_LGVENDOR_CLAIM_USEPARAM(IN_ENTITY_ID     IN NUMBER, --主体ID
                                         IN_PARAM_ID      IN NUMBER, --转采购参数表ID
                                         IN_USER_CODE     IN VARCHAR2, --操作用户
                                         OUT_CLAIM_NUMBER OUT VARCHAR2, --全赔销售单据号
                                         OUT_RESULT   IN OUT VARCHAR2);
  ---------------------------------------------------------
  --生成退货申请单
  --转采购销售单拒收数大于0的产品
  ---------------------------------------------------------
  PROCEDURE P_TO_INV_RETURN_USEPARAM(IN_ENTITY_ID IN NUMBER, --主体ID
                                   IN_PARAM_ID  IN NUMBER, --转采购参数表ID
                                   IN_USER_CODE IN VARCHAR2, --操作用户
                                   OUT_RETURN_NUMBER OUT VARCHAR2, --退货申请单据号
                                   OUT_RESULT   IN OUT VARCHAR2);
  ---------------------------------------------------------
  --销售转采购折扣类型或扣率修改后，款项处理
  ---------------------------------------------------------
  PROCEDURE P_SO_ADJUST_CREDIT(IN_ENTITY_ID IN NUMBER, --主体ID
                               IN_PARAM_ID  IN NUMBER, --转采购参数表ID
                               IN_USER_CODE IN VARCHAR2, --操作用户
                               OUT_RESULT   IN OUT VARCHAR2);

  
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2018-03-27
  *     创建者：周建刚
  *   功能说明：总部销售单结算更新销司PO价格以及PO引NC接口表信息
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_SETTLE_PO_UPDATE(P_SO_HEADER_ID IN T_SO_HEADER.SO_HEADER_ID%TYPE, --销售单头id
                                  P_RESULT       IN OUT NUMBER, --返回错误ID
                                  P_ERR_MSG      IN OUT VARCHAR2 --返回错误信息
                                  );
  
  ---------------------------------------------------------
  --修改直发标志、自提需二次发运款项处理
  ---------------------------------------------------------
  PROCEDURE P_SO_MODIFY_FLAG_UPD_AMOUNT(IN_SO_HEADER_ID IN T_SO_HEADER.SO_HEADER_ID%TYPE, --销售单头id
                                        IN_SIGN         IN NUMBER, --方向：1 增加锁款 2 减少锁款
                                        IN_USER_CODE    IN VARCHAR2, --操作用户
                                        OUT_RESULT      IN OUT VARCHAR2);
  
  ---------------------------------------------------------
  --生成预占用数据，用于提货订单二次发运
  --销售生成中转单类型触发
  ---------------------------------------------------------
  PROCEDURE P_PRE_INV_OCCUPY_USEINVPO(IN_ENTITY_ID IN NUMBER, --主体ID
                                      IN_PO_ID  IN NUMBER, --中转单头ID
                                      IN_USER_CODE IN VARCHAR2, --操作用户
                                      OUT_RESULT   IN OUT VARCHAR2);
                                
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2018-02-28
  *     创建者：周建刚
  *   功能说明：根据供方主体销售单的签收信息，更新需方主体销售的签收信息
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_RECEIVE_BY_PO_ENTITY_SO(P_ENTITY_ID            IN NUMBER,    --主体ID
                                         P_START_DATE           IN VARCHAR2,  --起始日期
                                         P_RESULT               OUT NUMBER,   --返回错误ID
                                         P_ERR_MSG              OUT VARCHAR2  --返回错误信息
                                         );
  -------------------------------------------------------------------------------
END PKG_SO_TO_POX;
/

