create PACKAGE BODY PKG_SL AS

  -----------------------------------------------------------------------------
  --      生成分库指令明细，供各个生成分库指令的程序调用                     --
  -----------------------------------------------------------------------------
  PROCEDURE P_CREATE_ALLOT_DETAIL(
    IN_ALLOT_ORDER_ID         IN  NUMBER   --分库指令ID
    ,IN_ENTITY_ID             IN  NUMBER   --经营主体ID
    ,IS_USER_ACCOUNT          IN  VARCHAR2 --用户账号
  ) IS
  BEGIN
    --根据配套关系生成分库指令明细
    --由于可能会存在产品属性非套件，而存在配套关系，需增加对产品属性的控制，与退货申请的逻辑保持一致
    INSERT INTO T_SL_ALLOT_ORDER_DETAIL
    (
      ALLOT_ORDER_DETAIL_ID
      ,ALLOT_ORDER_LINE_ID
      ,ALLOT_ORDER_ID
      ,ITEM_ID
      ,ITEM_CODE
      ,ITEM_NAME
      ,ITEM_UOM
      ,SET_ITEM_ID
      ,SET_ITEM_CODE
      ,SET_ITEM_NAME
      ,SET_ITEM_UOM
      ,ASS_QTY
      ,QUANTITY
      ,CREATED_BY
      ,CREATION_DATE
      ,LAST_UPDATED_BY
      ,LAST_UPDATE_DATE
    )
    SELECT
      S_SL_ALLOT_ORDER_DETAIL.NEXTVAL ALLOT_ORDER_DETAIL_ID
      ,AOL.ALLOT_ORDER_LINE_ID
      ,IN_ALLOT_ORDER_ID ALLOT_ORDER_ID
      ,NVL(ASS.SUB_ITEM_ID,AOL.ITEM_ID) ITEM_ID
      ,NVL(ASS.SUB_ITEM_CODE,AOL.ITEM_CODE) ITEM_CODE
      ,NVL(ASS.SUB_ITEM_NAME,AOL.ITEM_NAME) ITEM_NAME
      ,NVL(ASS.SUB_ITEM_UOM,AOL.ITEM_UOM) ITEM_UOM
      ,ASS.SET_ITEM_ID
      ,DECODE(ASS.SET_ITEM_ID,NULL,NULL,AOL.ITEM_CODE) SET_ITEM_CODE
      ,DECODE(ASS.SET_ITEM_ID,NULL,NULL,AOL.ITEM_NAME) SET_ITEM_NAME
      ,DECODE(ASS.SET_ITEM_ID,NULL,NULL,AOL.ITEM_UOM) SET_ITEM_UOM
      ,NVL(ASS.QUANTITY,1) ASS_QTY
      ,AOL.QUANTITY * NVL(ASS.QUANTITY,1) QUANTITY
      ,IS_USER_ACCOUNT CREATED_BY
      ,SYSDATE CREATION_DATE
      ,IS_USER_ACCOUNT LAST_UPDATED_BY
      ,SYSDATE LAST_UPDATE_DATE
    FROM
      T_SL_ALLOT_ORDER_LINE AOL
      ,(
        SELECT
          IA.ITEM_ID SET_ITEM_ID
          ,IAS.ITEM_ID SUB_ITEM_ID
          ,IAS.QUANTITY
          ,I.ITEM_CODE SUB_ITEM_CODE
          ,I.ITEM_NAME SUB_ITEM_NAME
          ,I.DEFAULTUNIT SUB_ITEM_UOM
        FROM
          T_BD_ITEM_ASSEMBLIES IA
          ,T_BD_ITEM_ASSEMBLIES_SUB IAS
          ,T_BD_ITEM I
          ,T_BD_ITEM I_SET
        WHERE
          IA.ITEM_ASSEMBLY_ID = IAS.ITEM_ASSEMBLY_ID
          AND IAS.ITEM_ID = I.ITEM_ID
          AND IA.ITEM_ID = I_SET.ITEM_ID
          AND I_SET.PRODUCTFORM = 'SET_PRODUCT'
          AND IA.ENTITY_ID = IN_ENTITY_ID
          AND TRUNC(SYSDATE) BETWEEN IA.BEGIN_DATE AND NVL(IA.END_DATE,TRUNC(SYSDATE))
          AND TRUNC(SYSDATE) BETWEEN IAS.BEGIN_DATE AND NVL(IAS.END_DATE,TRUNC(SYSDATE))
      ) ASS
    WHERE
      AOL.ITEM_ID = ASS.SET_ITEM_ID(+)
      AND AOL.ALLOT_ORDER_ID = IN_ALLOT_ORDER_ID;

  END P_CREATE_ALLOT_DETAIL;

  -----------------------------------------------------------------------------
  --      更新分库指令明细的取消数量，供各个更新分库指令的程序调用           --
  -----------------------------------------------------------------------------
  PROCEDURE P_UPDATE_DETAIL_CANCEL_QTY(
    IN_ALLOT_ORDER_ID         IN  NUMBER   --分库指令ID
    ,IS_USER_ACCOUNT          IN  VARCHAR2 --用户账号
  ) IS
  BEGIN
    --根据配套关系更新分库指令明细取消数量
    UPDATE
      T_SL_ALLOT_ORDER_DETAIL AOD
    SET
      CANCEL_QTY =
      (
        SELECT
          AOD.ASS_QTY*NVL(AOL.CANCEL_QTY,0)
        FROM
          T_SL_ALLOT_ORDER_LINE AOL
        WHERE
          AOL.ALLOT_ORDER_LINE_ID = AOD.ALLOT_ORDER_LINE_ID
      )
      ,LAST_UPDATED_BY = IS_USER_ACCOUNT
      ,LAST_UPDATE_DATE = SYSDATE 
    WHERE
      AOD.ALLOT_ORDER_ID = IN_ALLOT_ORDER_ID
      AND EXISTS(
        SELECT
          1
        FROM
          T_SL_ALLOT_ORDER_LINE AOL
        WHERE
          AOL.ALLOT_ORDER_LINE_ID = AOD.ALLOT_ORDER_LINE_ID
          AND AOD.ASS_QTY*NVL(AOL.CANCEL_QTY,0) <> NVL(AOD.CANCEL_QTY,0)
      );

  END P_UPDATE_DETAIL_CANCEL_QTY;

  -----------------------------------------------------------------------------
  --      更新分库指令明细的取消数量，供各个更新分库指令的程序调用           --
  -----------------------------------------------------------------------------
  PROCEDURE P_UPDATE_DETAIL_ADD_QTY(
    IN_ALLOT_ORDER_ID         IN  NUMBER   --分库指令ID
    ,IS_USER_ACCOUNT          IN  VARCHAR2 --用户账号
  ) IS
  BEGIN
    --根据配套关系更新分库指令明细取消数量
    UPDATE
      T_SL_ALLOT_ORDER_DETAIL AOD
    SET
      ADD_QTY =
      (
        SELECT
          AOD.ASS_QTY*NVL(AOL.ADD_QTY,0)
        FROM
          T_SL_ALLOT_ORDER_LINE AOL
        WHERE
          AOL.ALLOT_ORDER_LINE_ID = AOD.ALLOT_ORDER_LINE_ID
      )
      ,LAST_UPDATED_BY = IS_USER_ACCOUNT
      ,LAST_UPDATE_DATE = SYSDATE 
    WHERE
      AOD.ALLOT_ORDER_ID = IN_ALLOT_ORDER_ID
      AND EXISTS(
        SELECT
          1
        FROM
          T_SL_ALLOT_ORDER_LINE AOL
        WHERE
          AOL.ALLOT_ORDER_LINE_ID = AOD.ALLOT_ORDER_LINE_ID
          AND AOD.ASS_QTY*NVL(AOL.ADD_QTY,0) <> NVL(AOD.ADD_QTY,0)
      );

  END P_UPDATE_DETAIL_ADD_QTY;

  -----------------------------------------------------------------------------
  --      发货通知单生成分库指令
  --对于取消数量，需检查原发货通知单是否有足够的可取消数量
  -----------------------------------------------------------------------------
  PROCEDURE P_SHIP_DOC_ALLOT(
    IN_SHIP_DOC_ID            IN  NUMBER   --发货通知单ID
    ,IS_USER_ACCOUNT          IN  VARCHAR2 --用户账号
    ,OS_MESSAGE               OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  ) IS
    S_STEP             VARCHAR2(40);
    N_ENTITY_ID        NUMBER;
    S_DOC_STATUS       VARCHAR2(32);
    S_ALLOT_ORDER_NUM  VARCHAR2(32);
    S_ORIGIN_SHIP_DOC_CODE VARCHAR2(32);
    S_SHIP_DOC_CODE    VARCHAR2(32);
    N_ALLOT_ORDER_ID   NUMBER;
    N_SOURCE_BILL_ID   NUMBER;
    S_MESSAGE          VARCHAR2(1000);
  BEGIN
    OS_MESSAGE := 'OK';
    SAVEPOINT SP;

    --锁定发货通知单，获取主体ID
    BEGIN
      SELECT
        ENTITY_ID
        ,DOC_STATUS
        ,ORIGIN_SHIP_DOC_CODE
        ,SHIP_DOC_CODE
      INTO
        N_ENTITY_ID
        ,S_DOC_STATUS
        ,S_ORIGIN_SHIP_DOC_CODE
        ,S_SHIP_DOC_CODE
      FROM
        T_LG_SHIP_DOC
      WHERE
        SHIP_DOC_ID = IN_SHIP_DOC_ID
      FOR UPDATE NOWAIT;
    EXCEPTION
      WHEN TIMEOUT_ON_RESOURCE THEN
        OS_MESSAGE := '锁定发货通知单不成功！请稍后再试。';
    END;

    --正常单据则生成分库指令，红冲单据则冲减发货数量
    IF OS_MESSAGE = 'OK' THEN
      --00:正常单据
      IF S_DOC_STATUS = '00' THEN

        --检查是否已生成分库指令
        IF OS_MESSAGE = 'OK' THEN
          BEGIN
            SELECT
              ALLOT_ORDER_NUM
            INTO
              S_ALLOT_ORDER_NUM
            FROM
              T_SL_ALLOT_ORDER
            WHERE
              SOURCE_TYPE = 'SHIP_DOC'
              AND SOURCE_BILL_ID = IN_SHIP_DOC_ID
              AND ROWNUM = 1;
            OS_MESSAGE := '当前发货通知单已生成分库指令[' || S_ALLOT_ORDER_NUM || '],不能重复生成！';
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              NULL;
          END;
        END IF;

        --取出指令号
        IF OS_MESSAGE = 'OK' THEN
          S_STEP := '取出指令号';
          S_ALLOT_ORDER_NUM := PKG_BD.F_GET_BILL_NO('ALLOT_ORDER',NULL,N_ENTITY_ID,NULL);
        END IF;

        --取出指令ID
        IF OS_MESSAGE = 'OK' THEN
          S_STEP := '取出指令ID';
          SELECT
            S_SL_ALLOT_ORDER.NEXTVAL
          INTO
            N_ALLOT_ORDER_ID
          FROM
            DUAL;
        END IF;

        --写分库指令头表(发货通知单表没有ACCOUNT_ID，需关联取出)
        IF OS_MESSAGE = 'OK' THEN
          S_STEP := '写分库指令头表';
          INSERT INTO T_SL_ALLOT_ORDER
          (
            ALLOT_ORDER_ID
            ,ENTITY_ID
            ,ALLOT_ORDER_NUM
            ,IN_OUT_TYPE
            ,BUSINESS_TYPE
            ,STATUS
            ,ALLOTED_FLAG
            ,SOURCE_TYPE
            ,SOURCE_BILL_ID
            ,SOURCE_BILL_NUM
            ,SOURCE_BILL_DATE
            ,PLAN_SHIP_DATE
            ,INVENTORY_ID
            ,INVENTORY_CODE
            ,INVENTORY_NAME
            ,CUSTOMER_ID
            ,CUSTOMER_CODE
            ,CUSTOMER_NAME
            ,SALES_CENTER_ID
            ,SALES_CENTER_CODE
            ,SALES_CENTER_NAME
            ,ACCOUNT_ID
            ,CARRIER_ID
            ,CARRIER_CODE
            ,CARRIER_NAME
            ,VEHICLE_BRAND
            ,REMARK
            ,CREATED_BY
            ,CREATION_DATE
            ,LAST_UPDATED_BY
            ,LAST_UPDATE_DATE
          )
          SELECT
            N_ALLOT_ORDER_ID ALLOT_ORDER_ID
            ,SD.ENTITY_ID
            ,S_ALLOT_ORDER_NUM ALLOT_ORDER_NUM
            ,'OUT' IN_OUT_TYPE
            ,DECODE(SD.CONSIGNEE_INVENTORY_ID,NULL,'1006','1008') BUSINESS_TYPE  --存在接收仓则认为是调拨，否则销售
            ,'CREATED' STATUS
            ,'N' ALLOTED_FLAG
            ,'SHIP_DOC' SOURCE_TYPE
            ,IN_SHIP_DOC_ID SOURCE_BILL_ID
            ,SD.SHIP_DOC_CODE SOURCE_BILL_NUM
            ,SD.DOC_DATE SOURCE_BILL_DATE
            ,SD.REQUIRE_SHIP_DATE PLAN_SHIP_DATE
            ,SD.SHIP_INVENTORY_ID INVENTORY_ID
            ,SD.SHIP_INVENTORY_CODE INVENTORY_CODE
            ,SD.SHIP_INVENTORY_NAME INVENTORY_NAME
            ,SD.CUSTOMER_ID
            ,SD.CUSTOMER_CODE
            ,SD.CUSTOMER_NAME
            ,SD.SALES_CENTER_ID
            ,OU.CODE SALES_CENTER_CODE
            ,OU.NAME SALES_CENTER_NAME
            ,CA.ACCOUNT_ID
            ,SD.VENDOR_ID CARRIER_ID
            ,SD.VENDOR_CODE CARRIER_CODE
            ,SD.VENDOR_NAME CARRIER_NAME
            ,NULL VEHICLE_BRAND
            ,SD.REMARK
            ,IS_USER_ACCOUNT CREATED_BY
            ,SYSDATE CREATION_DATE
            ,IS_USER_ACCOUNT LAST_UPDATED_BY
            ,SYSDATE LAST_UPDATE_DATE
          FROM
            T_LG_SHIP_DOC SD
            ,T_CUSTOMER_ACCOUNT CA
            ,UP_ORG_UNIT OU
          WHERE
            SD.ACCOUNT_CODE = CA.ACCOUNT_CODE(+)
            AND SD.CUSTOMER_ID = CA.CUSTOMER_ID(+)
            AND SD.SALES_CENTER_ID = OU.UNIT_ID
            AND SD.SHIP_DOC_ID = IN_SHIP_DOC_ID;
        END IF;

        --写分库指令行表(发货通知单行表没有ITEM_ID，需关联取出)
        IF OS_MESSAGE = 'OK' THEN
          S_STEP := '写分库指令行表';
          INSERT INTO T_SL_ALLOT_ORDER_LINE
          (
            ALLOT_ORDER_LINE_ID
            ,ALLOT_ORDER_ID
            ,ITEM_ID
            ,ITEM_CODE
            ,ITEM_NAME
            ,ITEM_UOM
            ,QUANTITY
            ,SOURCE_LINE_ID
            ,CREATED_BY
            ,CREATION_DATE
            ,LAST_UPDATED_BY
            ,LAST_UPDATE_DATE
          )
          SELECT
            S_SL_ALLOT_ORDER_LINE.NEXTVAL ALLOT_ORDER_LINE_ID
            ,N_ALLOT_ORDER_ID ALLOT_ORDER_ID
            ,I.ITEM_ID
            ,I.ITEM_CODE
            ,I.ITEM_NAME
            ,I.DEFAULTUNIT ITEM_UOM
            ,SDL.ITEM_QTY QUANTITY
            ,SDL.SHIP_DOC_LINE_ID SOURCE_LINE_ID
            ,IS_USER_ACCOUNT CREATED_BY
            ,SYSDATE CREATION_DATE
            ,IS_USER_ACCOUNT LAST_UPDATED_BY
            ,SYSDATE LAST_UPDATE_DATE
          FROM
            T_LG_SHIP_DOC_LINE SDL
            ,T_BD_ITEM I
          WHERE
            SDL.ITEM_CODE = I.ITEM_CODE
            AND SDL.SHIP_DOC_ID = IN_SHIP_DOC_ID
            AND SDL.ITEM_QTY > 0;
        END IF;

        --根据配套关系写分库指令明细表
        IF OS_MESSAGE = 'OK' THEN
          S_STEP := '写分库指令明细表';
          P_CREATE_ALLOT_DETAIL(N_ALLOT_ORDER_ID, N_ENTITY_ID, IS_USER_ACCOUNT);
        END IF;
      ELSE
        --S_DOC_STATUS = 01:红冲单据，通过原发货通知单找分库指令，扣减数量
        --取原发货通知单的分库指令，并锁定
        S_STEP := '取原发货通知单的分库指令';
        BEGIN
          SELECT
            ALLOT_ORDER_ID
            ,SOURCE_BILL_ID
          INTO
            N_ALLOT_ORDER_ID
            ,N_SOURCE_BILL_ID
          FROM
            T_SL_ALLOT_ORDER
          WHERE
            SOURCE_BILL_NUM = S_ORIGIN_SHIP_DOC_CODE
            AND SOURCE_TYPE = 'SHIP_DOC'
            AND ENTITY_ID = N_ENTITY_ID;
        EXCEPTION
          WHEN TIMEOUT_ON_RESOURCE THEN
            OS_MESSAGE := '锁定源发货通知单对应的分库指令不成功，请稍候重试！';
        END;

        --检查是否有足够的可取消数量(红冲发货通知单行没有记录原行ID，需通过来源单号ID、来源类型、产品ID来获取)
        IF OS_MESSAGE = 'OK' THEN
          S_STEP := '检查可取消数量';
          S_MESSAGE := NULL;
          FOR R_CAN_CANCEL IN
          (
            SELECT
              AOL.ITEM_CODE
              ,SDL1.ITEM_QTY
              ,AOL.QUANTITY - NVL(AOL.CANCEL_QTY,0) - NVL(AOL.ALLOT_QTY,0) CAN_CANCEL_QTY
            FROM
              T_SL_ALLOT_ORDER_LINE AOL
              ,T_LG_SHIP_DOC_LINE SDL0
              ,T_LG_SHIP_DOC_LINE SDL1
            WHERE
              AOL.SOURCE_LINE_ID = SDL0.SHIP_DOC_LINE_ID
              AND SDL0.ORIGIN_TYPE = SDL1.ORIGIN_TYPE
              AND SDL0.ORIGIN_ORDER_ID = SDL1.ORIGIN_ORDER_ID
              AND SDL0.ORIGIN_LINE_ID = SDL1.ORIGIN_LINE_ID
              AND SDL0.ITEM_CODE = SDL1.ITEM_CODE
              AND AOL.ALLOT_ORDER_ID = N_ALLOT_ORDER_ID
              AND SDL0.SHIP_DOC_ID = N_SOURCE_BILL_ID
              AND SDL1.SHIP_DOC_ID = IN_SHIP_DOC_ID
              AND SDL1.ITEM_QTY > AOL.QUANTITY - NVL(AOL.CANCEL_QTY,0) - NVL(AOL.ALLOT_QTY,0)
          )
          LOOP
            IF S_MESSAGE IS NULL THEN
              S_MESSAGE := '[' || R_CAN_CANCEL.ITEM_CODE || ']取消:' || TO_CHAR(R_CAN_CANCEL.ITEM_QTY) || ',可取消:' || TO_CHAR(R_CAN_CANCEL.CAN_CANCEL_QTY);
            ELSE
              S_MESSAGE := S_MESSAGE || ';[' || R_CAN_CANCEL.ITEM_CODE || ']取消:' || TO_CHAR(R_CAN_CANCEL.ITEM_QTY) || ',可取消:' || TO_CHAR(R_CAN_CANCEL.CAN_CANCEL_QTY);
            END IF;
          END LOOP;
          IF S_MESSAGE IS NOT NULL THEN
            OS_MESSAGE := '以下产品没有足够的可取消数量：' || S_MESSAGE;
          END IF;
        END IF;

        --更新指令行取消数量
        IF OS_MESSAGE = 'OK' THEN
          S_STEP := '更新指令行取消数量';
          UPDATE
            T_SL_ALLOT_ORDER_LINE AOL
          SET
            CANCEL_QTY =
            (
              SELECT
                NVL(AOL.CANCEL_QTY,0) + NVL(SDL1.ITEM_QTY,0)
              FROM
                T_LG_SHIP_DOC_LINE SDL0
                ,T_LG_SHIP_DOC_LINE SDL1
              WHERE
                AOL.SOURCE_LINE_ID = SDL0.SHIP_DOC_LINE_ID
                AND SDL0.ORIGIN_TYPE = SDL1.ORIGIN_TYPE
                AND SDL0.ORIGIN_ORDER_ID = SDL1.ORIGIN_ORDER_ID
                AND SDL0.ORIGIN_LINE_ID = SDL1.ORIGIN_LINE_ID
                AND SDL0.ITEM_CODE = SDL1.ITEM_CODE
                AND SDL0.SHIP_DOC_ID = N_SOURCE_BILL_ID
                AND SDL1.SHIP_DOC_ID = IN_SHIP_DOC_ID
            )
          WHERE
            AOL.ALLOT_ORDER_ID = N_ALLOT_ORDER_ID
            AND EXISTS(
              SELECT
                1
              FROM
                T_LG_SHIP_DOC_LINE SDL0
                ,T_LG_SHIP_DOC_LINE SDL1
              WHERE
                AOL.SOURCE_LINE_ID = SDL0.SHIP_DOC_LINE_ID
                AND SDL0.ORIGIN_TYPE = SDL1.ORIGIN_TYPE
                AND SDL0.ORIGIN_ORDER_ID = SDL1.ORIGIN_ORDER_ID
                AND SDL0.ORIGIN_LINE_ID = SDL1.ORIGIN_LINE_ID
                AND SDL0.ITEM_CODE = SDL1.ITEM_CODE
                AND SDL0.SHIP_DOC_ID = N_SOURCE_BILL_ID
                AND SDL1.SHIP_DOC_ID = IN_SHIP_DOC_ID
            );
        END IF;

        --根据指令行更新指令明细取消数量
        IF OS_MESSAGE = 'OK' THEN
          S_STEP := '更新指令明细取消数量';
          P_UPDATE_DETAIL_CANCEL_QTY(N_ALLOT_ORDER_ID, IS_USER_ACCOUNT);
        END IF;

        --记录核销历史，由于发货通知单行没有记录原发货通知单行ID，故需通过产品关联取出
        IF OS_MESSAGE = 'OK' THEN
          S_STEP := '记录核销历史';
          INSERT INTO T_SL_ALLOT_ORDER_APPLIED
          (
            APPLIED_ID
            ,ALLOT_ORDER_ID
            ,ALLOT_ORDER_LINE_ID
            ,SOURCE_TYPE
            ,SOURCE_BILL_ID
            ,SOURCE_BILL_NUM
            ,SOURCE_LINE_ID
            ,APPLIED_TYPE
            ,APPLIED_DATE
            ,QUANTITY
            ,CREATED_BY
            ,CREATION_DATE
            ,LAST_UPDATED_BY
            ,LAST_UPDATE_DATE
          )
          SELECT
            S_SL_ALLOT_ORDER_APPLIED.NEXTVAL APPLIED_ID
            ,N_ALLOT_ORDER_ID ALLOT_ORDER_ID
            ,AOL.ALLOT_ORDER_LINE_ID
            ,'SHIP_DOC' SOURCE_TYPE
            ,IN_SHIP_DOC_ID SOURCE_BILL_ID
            ,S_SHIP_DOC_CODE SOURCE_BILL_NUM
            ,SDL.SHIP_DOC_LINE_ID SOURCE_LINE_ID
            ,'红冲' APPLIED_TYPE
            ,TRUNC(SYSDATE) APPLIED_DATE
            ,SDL.ITEM_QTY QUANTITY
            ,IS_USER_ACCOUNT CREATED_BY
            ,SYSDATE CREATION_DATE
            ,IS_USER_ACCOUNT LAST_UPDATED_BY
            ,SYSDATE LAST_UPDATE_DATE
          FROM
            T_SL_ALLOT_ORDER_LINE AOL
            ,T_LG_SHIP_DOC_LINE SDL
          WHERE
            AOL.ITEM_CODE = SDL.ITEM_CODE
            AND AOL.ALLOT_ORDER_ID = N_ALLOT_ORDER_ID
            AND SDL.SHIP_DOC_ID = IN_SHIP_DOC_ID;
        END IF;
      END IF;
    END IF;

    IF OS_MESSAGE <> 'OK' THEN
      ROLLBACK TO SAVEPOINT SP;
    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK TO SAVEPOINT SP;
      OS_MESSAGE := '发货通知单生成分库指令-'|| S_STEP || ':' || SQLERRM;
  END P_SHIP_DOC_ALLOT;

  -----------------------------------------------------------------------------
  --  调拨单据红冲，增加分库指令的取消数量，记录核销历史                       --
  -----------------------------------------------------------------------------
  PROCEDURE P_TRSF_ORDER_CANCEL(
    IN_TRSF_ORDER_ID          IN  NUMBER   --调拨单ID
    ,IS_TRSF_ORDER_NUM        IN  VARCHAR2 --调拨单号
    ,IN_SRC_TRSF_ORDER_ID     IN  NUMBER   --原调拨单ID
    ,IS_IN_OUT_TYPE           IN  VARCHAR2 --出入库类型：IN\OUT 
    ,IS_USER_ACCOUNT          IN  VARCHAR2 --用户账号
    ,OS_MESSAGE               OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  ) IS
    S_STEP             VARCHAR2(40);
    N_CNT              NUMBER;
    N_ALLOT_ORDER_ID   NUMBER;
  BEGIN
    OS_MESSAGE := 'OK';
    SAVEPOINT SP;
    
    --取原分库指令ID
    IF OS_MESSAGE = 'OK' THEN
      S_STEP := '取原分库指令ID';
      SELECT
        ALLOT_ORDER_ID
      INTO
        N_ALLOT_ORDER_ID
      FROM
        T_SL_ALLOT_ORDER
      WHERE
        SOURCE_BILL_ID = IN_SRC_TRSF_ORDER_ID
        AND SOURCE_TYPE = 'TRSF_ORDER'
        AND IN_OUT_TYPE = IS_IN_OUT_TYPE;
    END IF;

    --检查是否已有对应的核销历史
    S_STEP := '检查核销历史';
    SELECT
      COUNT(*)
    INTO
      N_CNT  
    FROM
      T_SL_ALLOT_ORDER_APPLIED
    WHERE
      SOURCE_BILL_ID = IN_TRSF_ORDER_ID
      AND SOURCE_TYPE = 'TRSF_ORDER'
      AND ALLOT_ORDER_ID = N_ALLOT_ORDER_ID
      AND ROWNUM = 1;
    IF N_CNT > 0 THEN
      OS_MESSAGE := '当前调拨单已核销，不能重复核销';
    END IF;
    
    --增加取消数量
    IF OS_MESSAGE = 'OK' THEN
      UPDATE
        T_SL_ALLOT_ORDER_LINE AOL
      SET
        CANCEL_QTY =
        (
          SELECT
            NVL(AOL.CANCEL_QTY,0) + TOL.BILLED_QTY
          FROM
            T_INV_TRSF_ORDER_LINE TOL
          WHERE
            TOL.ORDER_LINE_ID_ORIG = AOL.ALLOT_ORDER_LINE_ID
            AND TOL.TRSF_ORDER_ID = IN_TRSF_ORDER_ID
        )
        ,LAST_UPDATED_BY = IS_USER_ACCOUNT
        ,LAST_UPDATE_DATE = SYSDATE
      WHERE
        ALLOT_ORDER_ID = N_ALLOT_ORDER_ID
        AND EXISTS(
          SELECT
            1
          FROM
            T_INV_TRSF_ORDER_LINE TOL
          WHERE
            TOL.ORDER_LINE_ID_ORIG = AOL.ALLOT_ORDER_LINE_ID
            AND TOL.TRSF_ORDER_ID = IN_TRSF_ORDER_ID
        );
    END IF;
    
    --更新分库指令明细的取消数量
    IF OS_MESSAGE = 'OK' THEN
      S_STEP := '更新指令明细取消数量';
      P_UPDATE_DETAIL_CANCEL_QTY(N_ALLOT_ORDER_ID, IS_USER_ACCOUNT);
    END IF;
    
    --记录核销历史
    IF OS_MESSAGE = 'OK' THEN
      S_STEP := '记录核销历史';
      INSERT INTO T_SL_ALLOT_ORDER_APPLIED
      (
        APPLIED_ID
        ,ALLOT_ORDER_ID
        ,ALLOT_ORDER_LINE_ID
        ,SOURCE_TYPE
        ,SOURCE_BILL_ID
        ,SOURCE_BILL_NUM
        ,SOURCE_LINE_ID
        ,APPLIED_TYPE
        ,APPLIED_DATE
        ,QUANTITY
        ,CREATED_BY
        ,CREATION_DATE
        ,LAST_UPDATED_BY
        ,LAST_UPDATE_DATE
      )
      SELECT
        S_SL_ALLOT_ORDER_APPLIED.NEXTVAL APPLIED_ID
        ,N_ALLOT_ORDER_ID ALLOT_ORDER_ID
        ,AOL.ALLOT_ORDER_LINE_ID
        ,'TRSF_ORDER' SOURCE_TYPE
        ,IN_TRSF_ORDER_ID SOURCE_BILL_ID
        ,IS_TRSF_ORDER_NUM SOURCE_BILL_NUM
        ,TOL.TRSF_ORDER_LINE_ID SOURCE_LINE_ID
        ,'红冲' APPLIED_TYPE
        ,TRUNC(SYSDATE) APPLIED_DATE
        ,TOL.BILLED_QTY QUANTITY
        ,IS_USER_ACCOUNT CREATED_BY
        ,SYSDATE CREATION_DATE
        ,IS_USER_ACCOUNT LAST_UPDATED_BY
        ,SYSDATE LAST_UPDATE_DATE
      FROM
        T_SL_ALLOT_ORDER_LINE AOL
        ,T_INV_TRSF_ORDER_LINE TOL
      WHERE
        AOL.SOURCE_LINE_ID = TOL.ORDER_LINE_ID_ORIG
        AND AOL.ALLOT_ORDER_ID = N_ALLOT_ORDER_ID
        AND TOL.TRSF_ORDER_ID = IN_TRSF_ORDER_ID;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK TO SAVEPOINT SP;
      OS_MESSAGE := '调拨单红冲取消分库指令-'|| S_STEP || ':' || SQLERRM;
  END P_TRSF_ORDER_CANCEL;

  -----------------------------------------------------------------------------
  --  调拨单据补单，增加分库指令的补单数量，记录核销历史                       --
  -----------------------------------------------------------------------------
  PROCEDURE P_TRSF_ORDER_ADD(
    IN_TRSF_ORDER_ID          IN  NUMBER   --调拨单ID
    ,IS_TRSF_ORDER_NUM        IN  VARCHAR2 --调拨单号
    ,IN_SRC_TRSF_ORDER_ID     IN  NUMBER   --原调拨单ID
    ,IS_IN_OUT_TYPE           IN  VARCHAR2 --出入库类型：IN\OUT 
    ,IS_USER_ACCOUNT          IN  VARCHAR2 --用户账号
    ,OS_MESSAGE               OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  ) IS
    S_STEP             VARCHAR2(40);
    N_CNT              NUMBER;
    N_ALLOT_ORDER_ID   NUMBER;
  BEGIN
    OS_MESSAGE := 'OK';
    SAVEPOINT SP;
    
    --取原分库指令ID
    IF OS_MESSAGE = 'OK' THEN
      S_STEP := '取原分库指令ID';
      SELECT
        ALLOT_ORDER_ID
      INTO
        N_ALLOT_ORDER_ID
      FROM
        T_SL_ALLOT_ORDER
      WHERE
        SOURCE_BILL_ID = IN_SRC_TRSF_ORDER_ID
        AND SOURCE_TYPE = 'TRSF_ORDER'
        AND IN_OUT_TYPE = IS_IN_OUT_TYPE;
    END IF;
    
    --检查是否已有对应的核销历史
    S_STEP := '检查核销历史';
    SELECT
      COUNT(*)
    INTO
      N_CNT  
    FROM
      T_SL_ALLOT_ORDER_APPLIED
    WHERE
      SOURCE_BILL_ID = IN_TRSF_ORDER_ID
      AND SOURCE_TYPE = 'TRSF_ORDER'
      AND ALLOT_ORDER_ID = N_ALLOT_ORDER_ID
      AND ROWNUM = 1;
    IF N_CNT > 0 THEN
      OS_MESSAGE := '当前调拨单已核销，不能重复核销';
    END IF;
    
    --增加补单数量
    IF OS_MESSAGE = 'OK' THEN
      UPDATE
        T_SL_ALLOT_ORDER_LINE AOL
      SET
        ADD_QTY =
        (
          SELECT
            NVL(AOL.ADD_QTY,0) + TOL.BILLED_QTY
          FROM
            T_INV_TRSF_ORDER_LINE TOL
            ,T_INV_TRSF_ORDER_LINE SRC 
          WHERE
            TOL.ITEM_ID = SRC.ITEM_ID
            AND TOL.TRSF_ORDER_ID = IN_TRSF_ORDER_ID
            AND SRC.TRSF_ORDER_ID = IN_SRC_TRSF_ORDER_ID
            AND SRC.TRSF_ORDER_LINE_ID = AOL.SOURCE_LINE_ID
        )
        ,LAST_UPDATED_BY = IS_USER_ACCOUNT
        ,LAST_UPDATE_DATE = SYSDATE
      WHERE
        ALLOT_ORDER_ID = N_ALLOT_ORDER_ID
        AND EXISTS(
          SELECT
            1
          FROM
            T_INV_TRSF_ORDER_LINE TOL
            ,T_INV_TRSF_ORDER_LINE SRC 
          WHERE
            TOL.ITEM_ID = SRC.ITEM_ID
            AND TOL.TRSF_ORDER_ID = IN_TRSF_ORDER_ID
            AND SRC.TRSF_ORDER_ID = IN_SRC_TRSF_ORDER_ID
            AND SRC.TRSF_ORDER_LINE_ID = AOL.SOURCE_LINE_ID
        );
    END IF;
    
    --更新分库指令明细的取消数量
    IF OS_MESSAGE = 'OK' THEN
      S_STEP := '更新指令明细取消数量';
      P_UPDATE_DETAIL_ADD_QTY(N_ALLOT_ORDER_ID, IS_USER_ACCOUNT);
    END IF;
    
    --记录核销历史
    IF OS_MESSAGE = 'OK' THEN
      S_STEP := '记录核销历史';
      INSERT INTO T_SL_ALLOT_ORDER_APPLIED
      (
        APPLIED_ID
        ,ALLOT_ORDER_ID
        ,ALLOT_ORDER_LINE_ID
        ,SOURCE_TYPE
        ,SOURCE_BILL_ID
        ,SOURCE_BILL_NUM
        ,SOURCE_LINE_ID
        ,APPLIED_TYPE
        ,APPLIED_DATE
        ,QUANTITY
        ,CREATED_BY
        ,CREATION_DATE
        ,LAST_UPDATED_BY
        ,LAST_UPDATE_DATE
      )
      SELECT
        S_SL_ALLOT_ORDER_APPLIED.NEXTVAL APPLIED_ID
        ,N_ALLOT_ORDER_ID ALLOT_ORDER_ID
        ,AOL.ALLOT_ORDER_LINE_ID
        ,'TRSF_ORDER' SOURCE_TYPE
        ,IN_TRSF_ORDER_ID SOURCE_BILL_ID
        ,IS_TRSF_ORDER_NUM SOURCE_BILL_NUM
        ,TOL.TRSF_ORDER_LINE_ID SOURCE_LINE_ID
        ,'补单' APPLIED_TYPE
        ,TRUNC(SYSDATE) APPLIED_DATE
        ,TOL.BILLED_QTY QUANTITY
        ,IS_USER_ACCOUNT CREATED_BY
        ,SYSDATE CREATION_DATE
        ,IS_USER_ACCOUNT LAST_UPDATED_BY
        ,SYSDATE LAST_UPDATE_DATE
      FROM
        T_SL_ALLOT_ORDER_LINE AOL
        ,T_INV_TRSF_ORDER_LINE TOL
      WHERE
        AOL.SOURCE_LINE_ID = TOL.ORDER_LINE_ID_ORIG
        AND AOL.ALLOT_ORDER_ID = N_ALLOT_ORDER_ID
        AND TOL.TRSF_ORDER_ID = IN_TRSF_ORDER_ID;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK TO SAVEPOINT SP;
      OS_MESSAGE := '调拨单补单更新分库指令-'|| S_STEP || ':' || SQLERRM;
  END P_TRSF_ORDER_ADD;

  -----------------------------------------------------------------------------
  --  调拨单据正常发货，生成分库指令                                         --
  -----------------------------------------------------------------------------
  PROCEDURE P_TRSF_ORDER_TO_ALLOT(
    IN_TRSF_ORDER_ID          IN  NUMBER   --调拨单ID
    ,IN_ENTITY_ID             IN  VARCHAR2 --调拨单号
    ,IN_IN_OUT_TYPE           IN  VARCHAR2 --出入库类型:IN\OUT
    ,IS_USER_ACCOUNT          IN  VARCHAR2 --用户账号
    ,OS_MESSAGE               OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  ) IS
    S_STEP             VARCHAR2(40);
    S_ALLOT_ORDER_NUM  VARCHAR2(32);
    N_ALLOT_ORDER_ID   NUMBER;
    S_ACTION           VARCHAR2(40);
  BEGIN
    OS_MESSAGE := 'OK';
    SAVEPOINT SP;
    IF IN_IN_OUT_TYPE = 'IN' THEN
      S_ACTION := '接收';
    ELSE
      S_ACTION := '发货';
    END IF;
    
    --检查是否已生成分库指令
    BEGIN
      SELECT
        ALLOT_ORDER_NUM
      INTO
        S_ALLOT_ORDER_NUM
      FROM
        T_SL_ALLOT_ORDER
      WHERE
        SOURCE_TYPE = 'TRSF_ORDER'
        AND SOURCE_BILL_ID = IN_TRSF_ORDER_ID
        AND IN_OUT_TYPE = IN_IN_OUT_TYPE
        AND ROWNUM = 1;
      OS_MESSAGE := '当前调拨单' || S_ACTION || '已生成分库指令[' || S_ALLOT_ORDER_NUM || '],不能重复生成！';
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        NULL;
    END;

    --取出指令号
    IF OS_MESSAGE = 'OK' THEN
      S_STEP := '取出指令号';
      S_ALLOT_ORDER_NUM := PKG_BD.F_GET_BILL_NO('ALLOT_ORDER',NULL,IN_ENTITY_ID,NULL);
    END IF;

    --取出指令ID
    IF OS_MESSAGE = 'OK' THEN
      S_STEP := '取出指令ID';
      SELECT
        S_SL_ALLOT_ORDER.NEXTVAL
      INTO
        N_ALLOT_ORDER_ID
      FROM
        DUAL;
    END IF;

    --写分库指令头表
    IF OS_MESSAGE = 'OK' THEN
      S_STEP := '写分库指令头表';
      INSERT INTO T_SL_ALLOT_ORDER
      (
        ALLOT_ORDER_ID
        ,ENTITY_ID
        ,ALLOT_ORDER_NUM
        ,IN_OUT_TYPE
        ,BUSINESS_TYPE
        ,STATUS
        ,ALLOTED_FLAG
        ,SOURCE_TYPE
        ,SOURCE_BILL_ID
        ,SOURCE_BILL_NUM
        ,SOURCE_BILL_DATE
        ,PLAN_SHIP_DATE
        ,INVENTORY_ID
        ,INVENTORY_CODE
        ,INVENTORY_NAME
        ,CUSTOMER_ID
        ,CUSTOMER_CODE
        ,CUSTOMER_NAME
        ,SALES_CENTER_ID
        ,SALES_CENTER_CODE
        ,SALES_CENTER_NAME
        ,ACCOUNT_ID
        ,CARRIER_ID
        ,CARRIER_CODE
        ,CARRIER_NAME
        ,VEHICLE_BRAND
        ,REMARK
        ,CREATED_BY
        ,CREATION_DATE
        ,LAST_UPDATED_BY
        ,LAST_UPDATE_DATE
      )
      SELECT
        N_ALLOT_ORDER_ID ALLOT_ORDER_ID
        ,O.ENTITY_ID
        ,S_ALLOT_ORDER_NUM ALLOT_ORDER_NUM
        ,IN_IN_OUT_TYPE IN_OUT_TYPE
        ,'1008' BUSINESS_TYPE  --调拨
        ,'CREATED' STATUS
        ,'N' ALLOTED_FLAG
        ,'TRSF_ORDER' SOURCE_TYPE
        ,IN_TRSF_ORDER_ID SOURCE_BILL_ID
        ,O.TRSF_ORDER_NUM SOURCE_BILL_NUM
        ,O.CREATION_DATE SOURCE_BILL_DATE  --调拨单没有单据日期
        ,NULL PLAN_SHIP_DATE
        ,DECODE(IN_IN_OUT_TYPE, 'IN', O.CONSIGNEE_INV_ID, O.SHIP_INV_ID) INVENTORY_ID
        ,DECODE(IN_IN_OUT_TYPE, 'IN', O.CONSIGNEE_INV_CODE, O.SHIP_INV_CODE) INVENTORY_CODE
        ,DECODE(IN_IN_OUT_TYPE, 'IN', O.CONSIGNEE_INV_NAME, O.SHIP_INV_NAME) INVENTORY_NAME
        ,NULL CUSTOMER_ID
        ,NULL CUSTOMER_CODE
        ,NULL CUSTOMER_NAME
        ,O.SALES_CENTER_ID
        ,O.SALES_CENTER_CODE
        ,O.SALES_CENTER_NAME
        ,NULL ACCOUNT_ID
        ,NULL CARRIER_ID
        ,NULL CARRIER_CODE
        ,NULL CARRIER_NAME
        ,NULL VEHICLE_BRAND
        ,O.REMARK
        ,IS_USER_ACCOUNT CREATED_BY
        ,SYSDATE CREATION_DATE
        ,IS_USER_ACCOUNT LAST_UPDATED_BY
        ,SYSDATE LAST_UPDATE_DATE
      FROM
        T_INV_TRSF_ORDER O
      WHERE
        O.TRSF_ORDER_ID = IN_TRSF_ORDER_ID;
    END IF;

    --写分库指令行表(发货通知单行表没有ITEM_ID，需关联取出)
    IF OS_MESSAGE = 'OK' THEN
      S_STEP := '写分库指令行表';
      INSERT INTO T_SL_ALLOT_ORDER_LINE
      (
        ALLOT_ORDER_LINE_ID
        ,ALLOT_ORDER_ID
        ,ITEM_ID
        ,ITEM_CODE
        ,ITEM_NAME
        ,ITEM_UOM
        ,QUANTITY
        ,SOURCE_LINE_ID
        ,CREATED_BY
        ,CREATION_DATE
        ,LAST_UPDATED_BY
        ,LAST_UPDATE_DATE
      )
      SELECT
        S_SL_ALLOT_ORDER_LINE.NEXTVAL ALLOT_ORDER_LINE_ID
        ,N_ALLOT_ORDER_ID ALLOT_ORDER_ID
        ,TOL.ITEM_ID
        ,TOL.ITEM_CODE
        ,TOL.ITEM_NAME
        ,TOL.UOM
        ,TOL.BILLED_QTY QUANTITY
        ,TOL.TRSF_ORDER_LINE_ID SOURCE_LINE_ID
        ,IS_USER_ACCOUNT CREATED_BY
        ,SYSDATE CREATION_DATE
        ,IS_USER_ACCOUNT LAST_UPDATED_BY
        ,SYSDATE LAST_UPDATE_DATE
      FROM
        T_INV_TRSF_ORDER_LINE TOL
      WHERE
        TOL.TRSF_ORDER_ID = IN_TRSF_ORDER_ID
        AND TOL.BILLED_QTY > 0;
    END IF;

    --根据配套关系写分库指令明细表
    IF OS_MESSAGE = 'OK' THEN
      S_STEP := '写分库指令明细表';
      P_CREATE_ALLOT_DETAIL(N_ALLOT_ORDER_ID, IN_ENTITY_ID, IS_USER_ACCOUNT);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK TO SAVEPOINT SP;
      OS_MESSAGE := '调拨单' || S_ACTION || '生成分库指令-'|| S_STEP || ':' || SQLERRM;
  END P_TRSF_ORDER_TO_ALLOT;

  -----------------------------------------------------------------------------
  --  调拨单(发出)生成分库指令                                                    --
  -----------------------------------------------------------------------------
  PROCEDURE P_TRSF_ORDER_SEND_ALLOT(
    IN_TRSF_ORDER_ID          IN  NUMBER   --调拨单ID
    ,IS_USER_ACCOUNT          IN  VARCHAR2 --用户账号
    ,OS_MESSAGE               OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  ) IS
    N_ENTITY_ID        NUMBER;
    N_OLD_ORDER_ID     NUMBER;
    N_OLD_TRSF_ORDER_ID NUMBER;
    S_TRSF_ORDER_NUM   VARCHAR2(32);
  BEGIN
    OS_MESSAGE := 'OK';
    SAVEPOINT SP;

    --锁定调拨单，获取主体ID
    BEGIN
      SELECT
        ENTITY_ID
        ,OLD_ORDER_ID
        ,OLD_TRSF_ORDER_ID
        ,TRSF_ORDER_NUM
      INTO
        N_ENTITY_ID
        ,N_OLD_ORDER_ID
        ,N_OLD_TRSF_ORDER_ID
        ,S_TRSF_ORDER_NUM
      FROM
        T_INV_TRSF_ORDER
      WHERE
        TRSF_ORDER_ID = IN_TRSF_ORDER_ID
      FOR UPDATE NOWAIT;
    EXCEPTION
      WHEN TIMEOUT_ON_RESOURCE THEN
        OS_MESSAGE := '锁定调拨单不成功！请稍后再试。';
    END;

    
    IF OS_MESSAGE = 'OK' THEN
      IF N_OLD_ORDER_ID IS NOT NULL THEN
        --红冲单，则增加取消数量，记录核销信息
        P_TRSF_ORDER_CANCEL(IN_TRSF_ORDER_ID, S_TRSF_ORDER_NUM, N_OLD_ORDER_ID, 'OUT', IS_USER_ACCOUNT, OS_MESSAGE);
      ELSIF N_OLD_TRSF_ORDER_ID IS NOT NULL THEN
        --补单，则增加补单数量，记录核销信息
        P_TRSF_ORDER_ADD(IN_TRSF_ORDER_ID, S_TRSF_ORDER_NUM, N_OLD_ORDER_ID, 'OUT', IS_USER_ACCOUNT, OS_MESSAGE);
      ELSE
        --正常单据，则生成分库指令
        P_TRSF_ORDER_TO_ALLOT(IN_TRSF_ORDER_ID, N_ENTITY_ID, 'OUT', IS_USER_ACCOUNT, OS_MESSAGE);
      END IF;
    END IF;

    IF OS_MESSAGE <> 'OK' THEN
      ROLLBACK TO SAVEPOINT SP;
    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK TO SAVEPOINT SP;
      OS_MESSAGE := '调拨单发货生成分库指令:' || SQLERRM;
  END P_TRSF_ORDER_SEND_ALLOT;

  -----------------------------------------------------------------------------
  --  调拨单(接收)生成分库指令                                                     --
  -----------------------------------------------------------------------------
  PROCEDURE P_TRSF_ORDER_REV_ALLOT(
    IN_TRSF_ORDER_ID          IN  NUMBER   --调拨单ID
    ,IS_USER_ACCOUNT          IN  VARCHAR2 --用户账号
    ,OS_MESSAGE               OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  ) IS
    N_ENTITY_ID        NUMBER;
    N_OLD_ORDER_ID     NUMBER;
    N_OLD_TRSF_ORDER_ID NUMBER;
    S_TRSF_ORDER_NUM   VARCHAR2(32);
  BEGIN
    OS_MESSAGE := 'OK';
    SAVEPOINT SP;

    --锁定调拨单，获取主体ID
    BEGIN
      SELECT
        ENTITY_ID
        ,OLD_ORDER_ID
        ,OLD_TRSF_ORDER_ID
        ,TRSF_ORDER_NUM
      INTO
        N_ENTITY_ID
        ,N_OLD_ORDER_ID
        ,N_OLD_TRSF_ORDER_ID
        ,S_TRSF_ORDER_NUM
      FROM
        T_INV_TRSF_ORDER
      WHERE
        TRSF_ORDER_ID = IN_TRSF_ORDER_ID
      FOR UPDATE NOWAIT;
    EXCEPTION
      WHEN TIMEOUT_ON_RESOURCE THEN
        OS_MESSAGE := '锁定调拨单不成功！请稍后再试。';
    END;

    IF OS_MESSAGE = 'OK' THEN
      IF N_OLD_ORDER_ID IS NOT NULL THEN
        --红冲单，则增加取消数量，记录核销信息
        P_TRSF_ORDER_CANCEL(IN_TRSF_ORDER_ID, S_TRSF_ORDER_NUM, N_OLD_ORDER_ID, 'IN', IS_USER_ACCOUNT, OS_MESSAGE);
      ELSIF N_OLD_TRSF_ORDER_ID IS NOT NULL THEN
        --补单，则增加补单数量，记录核销信息
        P_TRSF_ORDER_ADD(IN_TRSF_ORDER_ID, S_TRSF_ORDER_NUM, N_OLD_ORDER_ID, 'IN', IS_USER_ACCOUNT, OS_MESSAGE);
      ELSE
        --正常单据，则生成分库指令
        P_TRSF_ORDER_TO_ALLOT(IN_TRSF_ORDER_ID, N_ENTITY_ID, 'IN', IS_USER_ACCOUNT, OS_MESSAGE);
      END IF;
    END IF;

    IF OS_MESSAGE <> 'OK' THEN
      ROLLBACK TO SAVEPOINT SP;
    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK TO SAVEPOINT SP;
      OS_MESSAGE := '调拨单接收生成分库指令:' || SQLERRM;
  END P_TRSF_ORDER_REV_ALLOT;

  -----------------------------------------------------------------------------
  --  销售单(全陪)更新分库指令取消数量                                       --
  -----------------------------------------------------------------------------
  PROCEDURE P_SO_CANCEL_ALLOT(
    IN_SO_HEADER_ID           IN  NUMBER   --销售单ID
    ,IS_USER_ACCOUNT          IN  VARCHAR2 --用户账号
    ,OS_MESSAGE               OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  ) IS
    N_ENTITY_ID        NUMBER;
    N_ALLOT_ORDER_ID   NUMBER;
    N_TRSF_ORDER_ID    NUMBER;
    S_SO_NUM           VARCHAR2(32);
    S_STEP             VARCHAR2(40);
    N_CNT              NUMBER;
    N_BILL_TYPE_ID     NUMBER;
    N_SIGN             NUMBER;  --数量符号
  BEGIN
    OS_MESSAGE := 'OK';
    SAVEPOINT SP;

    --检查是否来源的调拨单，且存在对应的调拨单接收分库
    BEGIN
      SELECT
        ALLOT_ORDER_ID
      INTO
        N_ALLOT_ORDER_ID
      FROM
        T_SO_HEADER H
        ,T_SL_ALLOT_ORDER AO
      WHERE
        H.RAW_SRC_BILL_ID = AO.SOURCE_BILL_ID
        AND H.RAW_SRC_TYPE = '03'
        AND AO.SOURCE_TYPE = 'TRSF_ORDER'
        AND H.SO_HEADER_ID = IN_SO_HEADER_ID
        AND ROWNUM = 1;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        N_ALLOT_ORDER_ID := NULL;
    END;
    
    --只有对应调拨单接收才处理核销
    IF N_ALLOT_ORDER_ID IS NOT NULL THEN
      --锁定销售单，获取主体ID
      BEGIN
        SELECT
          ENTITY_ID
          ,SO_NUM
          ,RAW_SRC_BILL_ID
          ,BILL_TYPE_ID
        INTO
          N_ENTITY_ID
          ,S_SO_NUM
          ,N_TRSF_ORDER_ID
          ,N_BILL_TYPE_ID
        FROM
          T_SO_HEADER
        WHERE
          SO_HEADER_ID = IN_SO_HEADER_ID
        FOR UPDATE NOWAIT;
      EXCEPTION
        WHEN TIMEOUT_ON_RESOURCE THEN
          OS_MESSAGE := '锁定销售单不成功！请稍后再试。';
      END;

      IF OS_MESSAGE = 'OK' THEN
        --增加取消数量，记录核销信息
        --检查是否已有对应的核销历史
        S_STEP := '检查核销历史';
        SELECT
          COUNT(*)
        INTO
          N_CNT  
        FROM
          T_SL_ALLOT_ORDER_APPLIED
        WHERE
          SOURCE_BILL_ID = IN_SO_HEADER_ID
          AND SOURCE_TYPE = 'SO'
          AND ALLOT_ORDER_ID = N_ALLOT_ORDER_ID
          AND ROWNUM = 1;
        IF N_CNT > 0 THEN
          OS_MESSAGE := '当前销售单已核销，不能重复核销';
        END IF;
        
        --取数量方向
        IF OS_MESSAGE = 'OK' THEN
          SELECT
            DECODE(TT.ACTION_TYPE,'02',1,-1)
          INTO
            N_SIGN
          FROM
            T_INV_BILL_TYPES BT
            ,T_INV_TRANSACTION_TYPES TT
          WHERE
            BT.TRANSACTION_TYPE_ID = TT.TRANSACTION_TYPE_ID
            AND BT.BILL_TYPE_ID = N_BILL_TYPE_ID;
        END IF;
        
        --增加取消数量
        IF OS_MESSAGE = 'OK' THEN
          UPDATE
            T_SL_ALLOT_ORDER_LINE AOL
          SET
            CANCEL_QTY =
            (
              SELECT
                NVL(AOL.CANCEL_QTY,0) + SL.ITEM_QTY*N_SIGN
              FROM
                T_SO_LINE SL
                ,T_INV_TRSF_ORDER_LINE SRC 
              WHERE
                SL.RAW_SRC_LINE_ID = SRC.TRSF_ORDER_LINE_ID
                AND SL.SO_HEADER_ID = IN_SO_HEADER_ID
                AND SRC.TRSF_ORDER_ID = N_TRSF_ORDER_ID
                AND SRC.TRSF_ORDER_LINE_ID = AOL.SOURCE_LINE_ID
            )
            ,LAST_UPDATED_BY = IS_USER_ACCOUNT
            ,LAST_UPDATE_DATE = SYSDATE
          WHERE
            ALLOT_ORDER_ID = N_ALLOT_ORDER_ID
            AND EXISTS(
              SELECT
                1
              FROM
                T_SO_LINE SL
                ,T_INV_TRSF_ORDER_LINE SRC 
              WHERE
                SL.RAW_SRC_LINE_ID = SRC.TRSF_ORDER_LINE_ID
                AND SL.SO_HEADER_ID = IN_SO_HEADER_ID
                AND SRC.TRSF_ORDER_ID = N_TRSF_ORDER_ID
                AND SRC.TRSF_ORDER_LINE_ID = AOL.SOURCE_LINE_ID
            );
        END IF;
        
        --更新分库指令明细的取消数量
        IF OS_MESSAGE = 'OK' THEN
          S_STEP := '更新指令明细取消数量';
          P_UPDATE_DETAIL_CANCEL_QTY(N_ALLOT_ORDER_ID, IS_USER_ACCOUNT);
        END IF;
        
        --记录核销历史
        IF OS_MESSAGE = 'OK' THEN
          S_STEP := '记录核销历史';
          INSERT INTO T_SL_ALLOT_ORDER_APPLIED
          (
            APPLIED_ID
            ,ALLOT_ORDER_ID
            ,ALLOT_ORDER_LINE_ID
            ,SOURCE_TYPE
            ,SOURCE_BILL_ID
            ,SOURCE_BILL_NUM
            ,SOURCE_LINE_ID
            ,APPLIED_TYPE
            ,APPLIED_DATE
            ,QUANTITY
            ,CREATED_BY
            ,CREATION_DATE
            ,LAST_UPDATED_BY
            ,LAST_UPDATE_DATE
          )
          SELECT
            S_SL_ALLOT_ORDER_APPLIED.NEXTVAL APPLIED_ID
            ,N_ALLOT_ORDER_ID ALLOT_ORDER_ID
            ,AOL.ALLOT_ORDER_LINE_ID
            ,'SO' SOURCE_TYPE
            ,IN_SO_HEADER_ID SOURCE_BILL_ID
            ,S_SO_NUM SOURCE_BILL_NUM
            ,SL.SO_LINE_ID SOURCE_LINE_ID
            ,'红冲' APPLIED_TYPE
            ,TRUNC(SYSDATE) APPLIED_DATE
            ,SL.ITEM_QTY*N_SIGN
            ,IS_USER_ACCOUNT CREATED_BY
            ,SYSDATE CREATION_DATE
            ,IS_USER_ACCOUNT LAST_UPDATED_BY
            ,SYSDATE LAST_UPDATE_DATE
          FROM
            T_SL_ALLOT_ORDER_LINE AOL
            ,T_SO_LINE SL
          WHERE
            AOL.SOURCE_LINE_ID = SL.RAW_SRC_LINE_ID
            AND AOL.ALLOT_ORDER_ID = N_ALLOT_ORDER_ID
            AND SL.SO_HEADER_ID = IN_SO_HEADER_ID;
        END IF;
        
      END IF;

      IF OS_MESSAGE <> 'OK' THEN
        ROLLBACK TO SAVEPOINT SP;
      END IF;
    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK TO SAVEPOINT SP;
      OS_MESSAGE := '调拨单接收生成分库指令-'|| S_STEP || ':' || SQLERRM;
  END P_SO_CANCEL_ALLOT;

  -----------------------------------------------------------------------------
  --  销售单自动核销分库处理，通过JOB调用                                    --
  -----------------------------------------------------------------------------
  PROCEDURE P_AUTO_SO_APPLIED(
    IN_ENTITY_ID              IN  NUMBER   --主体ID
  ) IS
    S_USER_ID          VARCHAR2(32);
    S_PARAM_VALUE      VARCHAR2(240);
    D_BEGIN_DATE       DATE;
    D_END_DATE         DATE;
    S_MESSAGE          VARCHAR2(4000);
    S_MSG              VARCHAR2(4000);
  BEGIN
    S_MESSAGE := 'OK';
    
    --取出自动核销人
    BEGIN
      S_USER_ID := PKG_BD.F_GET_PARAMETER_VALUE('SL_AUTO_USER',IN_ENTITY_ID);
      S_MESSAGE := 'OK';
    EXCEPTION
      WHEN OTHERS THEN
        S_MESSAGE := '取参数SL_AUTO_USER出错:' || SQLERRM;
        S_MSG := PKG_BD.F_ADD_ERROR_LOG('PKG_SL.P_AUTO_SO_APPLIED', NULL, S_MESSAGE);
    END;

    --取出最后核销日期+1,作为开始处理核销日期
    BEGIN
      S_PARAM_VALUE := PKG_BD.F_GET_PARAMETER_VALUE('SL_LAST_APPLIED_DATE',IN_ENTITY_ID);
      IF S_PARAM_VALUE IS NULL THEN
        D_BEGIN_DATE := TO_DATE('2015-01-01','YYYY-MM-DD');
      ELSE
        D_BEGIN_DATE := TO_DATE(S_PARAM_VALUE,'YYYY-MM-DD')+1;
      END IF;
      S_MESSAGE := 'OK';
    EXCEPTION
      WHEN OTHERS THEN
        S_MESSAGE := '取参数SL_LAST_APPLIED_DATE出错:' || SQLERRM;
        S_MSG := PKG_BD.F_ADD_ERROR_LOG('PKG_SL.P_AUTO_SO_APPLIED', NULL, S_MESSAGE);
    END;

    --取昨天作为结束处理核销日期
    D_END_DATE := TRUNC(SYSDATE)-1;
    
    --处理核销
    FOR C_SO IN
    (
      SELECT
        H.SO_HEADER_ID
      FROM
        T_SO_HEADER H
        ,T_SL_ALLOT_ORDER AO
      WHERE
        H.RAW_SRC_BILL_ID = AO.SOURCE_BILL_ID
        AND H.RAW_SRC_TYPE = '03'
        AND AO.SOURCE_TYPE = 'TRSF_ORDER'
        AND H.ENTITY_ID = IN_ENTITY_ID
        AND SO_DATE BETWEEN D_BEGIN_DATE AND D_END_DATE
    )
    LOOP
      P_SO_CANCEL_ALLOT(C_SO.SO_HEADER_ID, S_USER_ID, S_MESSAGE);
      IF S_MESSAGE <> 'OK' THEN
        EXIT;
      END IF;
    END LOOP;
    
    IF S_MESSAGE = 'OK' THEN
      --成功则记录最后核销日期，并提交
      UPDATE
        T_BD_PARAM_ENTITY
      SET
        ENTITY_VALUE = TO_CHAR(D_END_DATE,'YYYY-MM-DD')
      WHERE
        ENTITY_ID = IN_ENTITY_ID
        AND PARAM_LIST_ID =
        (
          SELECT
            PARAM_LIST_ID
          FROM
            T_BD_PARAM_LIST
          WHERE
            PARAM_CODE = 'SL_LAST_APPLIED_DATE'
        );
      COMMIT;
    ELSE
      --失败则记录出错信息
      ROLLBACK;
      S_MSG := PKG_BD.F_ADD_ERROR_LOG('PKG_SL.P_AUTO_SO_APPLIED', NULL, S_MESSAGE);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK TO SAVEPOINT SP;
      S_MSG := PKG_BD.F_ADD_ERROR_LOG('PKG_SL.P_AUTO_SO_APPLIED', NULL, SQLERRM);
  END P_AUTO_SO_APPLIED;

  -----------------------------------------------------------------------------
  --  销售退货申请生成分库指令                                                   --
  -----------------------------------------------------------------------------
  PROCEDURE P_RETURN_APPLY_ALLOT(
    IN_RETURN_APPLY_ID        IN  NUMBER   --退货申请ID
    ,IS_USER_ACCOUNT          IN  VARCHAR2 --用户账号
    ,OS_MESSAGE               OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  ) IS
    S_STEP             VARCHAR2(40);
    N_ENTITY_ID        NUMBER;
    S_ALLOT_ORDER_NUM  VARCHAR2(32);
    N_ALLOT_ORDER_ID   NUMBER;
  BEGIN
    OS_MESSAGE := 'OK';
    SAVEPOINT SP;

    --锁定退货申请，获取主体ID
    BEGIN
      SELECT
        ENTITY_ID
      INTO
        N_ENTITY_ID
      FROM
        T_SO_RETURN_APPLY_HEADER
      WHERE
        APPLY_HEADER_ID = IN_RETURN_APPLY_ID
      FOR UPDATE NOWAIT;
    EXCEPTION
      WHEN TIMEOUT_ON_RESOURCE THEN
        OS_MESSAGE := '锁定销售退货申请不成功！请稍后再试。';
    END;

    --检查是否已生成分库指令
    IF OS_MESSAGE = 'OK' THEN
      BEGIN
        SELECT
          ALLOT_ORDER_NUM
        INTO
          S_ALLOT_ORDER_NUM
        FROM
          T_SL_ALLOT_ORDER
        WHERE
          SOURCE_TYPE = 'RETURN_APPLY'
          AND SOURCE_BILL_ID = IN_RETURN_APPLY_ID
          AND ROWNUM = 1;
        OS_MESSAGE := '当前销售退货申请已生成分库指令[' || S_ALLOT_ORDER_NUM || '],不能重复生成！';
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          NULL;
      END;
    END IF;

    --取出指令号
    IF OS_MESSAGE = 'OK' THEN
      S_STEP := '取出指令号';
      S_ALLOT_ORDER_NUM := PKG_BD.F_GET_BILL_NO('ALLOT_ORDER',NULL,N_ENTITY_ID,NULL);
    END IF;

    --取出指令ID
    IF OS_MESSAGE = 'OK' THEN
      S_STEP := '取出指令ID';
      SELECT
        S_SL_ALLOT_ORDER.NEXTVAL
      INTO
        N_ALLOT_ORDER_ID
      FROM
        DUAL;
    END IF;

    --写分库指令头表(发货通知单表没有ACCOUNT_ID，需关联取出)
    IF OS_MESSAGE = 'OK' THEN
      S_STEP := '写分库指令头表';
      INSERT INTO T_SL_ALLOT_ORDER
      (
        ALLOT_ORDER_ID
        ,ENTITY_ID
        ,ALLOT_ORDER_NUM
        ,IN_OUT_TYPE
        ,BUSINESS_TYPE
        ,STATUS
        ,ALLOTED_FLAG
        ,SOURCE_TYPE
        ,SOURCE_BILL_ID
        ,SOURCE_BILL_NUM
        ,SOURCE_BILL_DATE
        ,PLAN_SHIP_DATE
        ,INVENTORY_ID
        ,INVENTORY_CODE
        ,INVENTORY_NAME
        ,CUSTOMER_ID
        ,CUSTOMER_CODE
        ,CUSTOMER_NAME
        ,SALES_CENTER_ID
        ,SALES_CENTER_CODE
        ,SALES_CENTER_NAME
        ,ACCOUNT_ID
        ,CARRIER_ID
        ,CARRIER_CODE
        ,CARRIER_NAME
        ,VEHICLE_BRAND
        ,REMARK
        ,CREATED_BY
        ,CREATION_DATE
        ,LAST_UPDATED_BY
        ,LAST_UPDATE_DATE
      )
      SELECT
        N_ALLOT_ORDER_ID ALLOT_ORDER_ID
        ,RAH.ENTITY_ID
        ,S_ALLOT_ORDER_NUM ALLOT_ORDER_NUM
        ,'IN' IN_OUT_TYPE
        ,'1007' BUSINESS_TYPE  --销售退货申请
        ,'CREATED' STATUS
        ,'N' ALLOTED_FLAG
        ,'RETURN_APPLY' SOURCE_TYPE
        ,IN_RETURN_APPLY_ID SOURCE_BILL_ID
        ,RAH.BILL_NUM SOURCE_BILL_NUM
        ,RAH.BILL_DATE SOURCE_BILL_DATE
        ,NULL PLAN_SHIP_DATE
        ,RAH.RECEIVE_INV_ID INVENTORY_ID
        ,RAH.RECEIVE_INV_CODE INVENTORY_CODE
        ,RAH.RECEIVE_INV_NAME INVENTORY_NAME
        ,RAH.CUSTOMER_ID
        ,RAH.CUSTOMER_CODE
        ,RAH.CUSTOMER_NAME
        ,RAH.SALES_CENTER_ID
        ,RAH.SALES_CENTER_CODE
        ,RAH.SALES_CENTER_NAME
        ,RAH.ACCOUNT_ID
        ,NULL CARRIER_ID
        ,NULL CARRIER_CODE
        ,NULL CARRIER_NAME
        ,NULL VEHICLE_BRAND
        ,RAH.REMARK
        ,IS_USER_ACCOUNT CREATED_BY
        ,SYSDATE CREATION_DATE
        ,IS_USER_ACCOUNT LAST_UPDATED_BY
        ,SYSDATE LAST_UPDATE_DATE
      FROM
        T_SO_RETURN_APPLY_HEADER RAH
      WHERE
        RAH.APPLY_HEADER_ID = IN_RETURN_APPLY_ID;
    END IF;

    --写分库指令行表(发货通知单行表没有ITEM_ID，需关联取出)
    IF OS_MESSAGE = 'OK' THEN
      S_STEP := '写分库指令行表';
      INSERT INTO T_SL_ALLOT_ORDER_LINE
      (
        ALLOT_ORDER_LINE_ID
        ,ALLOT_ORDER_ID
        ,ITEM_ID
        ,ITEM_CODE
        ,ITEM_NAME
        ,ITEM_UOM
        ,QUANTITY
        ,SOURCE_LINE_ID
        ,CREATED_BY
        ,CREATION_DATE
        ,LAST_UPDATED_BY
        ,LAST_UPDATE_DATE
      )
      SELECT
        S_SL_ALLOT_ORDER_LINE.NEXTVAL ALLOT_ORDER_LINE_ID
        ,N_ALLOT_ORDER_ID ALLOT_ORDER_ID
        ,RALD.COMPONENT_ID ITEM_ID
        ,RALD.COMPONENT_CODE ITEM_CODE
        ,RALD.COMPONENT_NAME ITEM_NAME
        ,RALD.COMPONENT_UOM ITEM_UOM
        ,RALD.COMPONENT_QTY QUANTITY
        ,RALD.APPLY_LINE_DETAIL_ID SOURCE_LINE_ID
        ,IS_USER_ACCOUNT CREATED_BY
        ,SYSDATE CREATION_DATE
        ,IS_USER_ACCOUNT LAST_UPDATED_BY
        ,SYSDATE LAST_UPDATE_DATE
      FROM
        T_SO_RETURN_APPLY_LINE_DETAIL RALD
      WHERE
        RALD.APPLY_HEADER_ID = IN_RETURN_APPLY_ID
        AND RALD.COMPONENT_QTY > 0;
    END IF;

    --根据配套关系写分库指令明细表
    IF OS_MESSAGE = 'OK' THEN
      S_STEP := '写分库指令明细表';
      P_CREATE_ALLOT_DETAIL(N_ALLOT_ORDER_ID, N_ENTITY_ID, IS_USER_ACCOUNT);
    END IF;

    IF OS_MESSAGE <> 'OK' THEN
      ROLLBACK TO SAVEPOINT SP;
    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK TO SAVEPOINT SP;
      OS_MESSAGE := '发货销售退货申请生成分库指令-'|| S_STEP || ':' || SQLERRM;
  END P_RETURN_APPLY_ALLOT;

  -----------------------------------------------------------------------------
  --  盘点单生成分库指令                                                               --
  -----------------------------------------------------------------------------
  PROCEDURE P_CHECK_ORDER_ALLOT(
    IN_CHECK_ORDER_ID         IN  NUMBER   --盘点单ID
    ,IS_USER_ACCOUNT          IN  VARCHAR2 --用户账号
    ,OS_MESSAGE               OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  ) IS
    S_STEP                VARCHAR2(40);
    N_ENTITY_ID           NUMBER;
    N_CHECK_ORDER_TYPE_ID NUMBER;
    S_ALLOT_ORDER_NUM     VARCHAR2(32);
    N_ALLOT_ORDER_ID      NUMBER;
    S_IN_OUT_TYPE         VARCHAR2(32);
  BEGIN
    OS_MESSAGE := 'OK';
    SAVEPOINT SP;

    --锁定退货申请，获取主体ID
    BEGIN
      SELECT
        ENTITY_ID
        ,CHECK_ORDER_TYPE_ID
      INTO
        N_ENTITY_ID
        ,N_CHECK_ORDER_TYPE_ID
      FROM
        T_INV_CHECK_ORDERS
      WHERE
        CHECK_ORDER_ID = IN_CHECK_ORDER_ID
        AND PO_STATUS = '14'  --已执行
      FOR UPDATE NOWAIT;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        OS_MESSAGE := '盘点单未执行，或锁定盘点单不成功！请稍后再试。';
    END;

    --检查是否已生成分库指令
    IF OS_MESSAGE = 'OK' THEN
      BEGIN
        SELECT
          ALLOT_ORDER_NUM
        INTO
          S_ALLOT_ORDER_NUM
        FROM
          T_SL_ALLOT_ORDER
        WHERE
          SOURCE_TYPE = 'CHECK_ORDER'
          AND SOURCE_BILL_ID = IN_CHECK_ORDER_ID
          AND ROWNUM = 1;
        OS_MESSAGE := '当前盘点单已生成分库指令[' || S_ALLOT_ORDER_NUM || '],不能重复生成！';
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          NULL;
      END;
    END IF;

    --取出入库类型
    IF OS_MESSAGE = 'OK' THEN
      S_STEP := '取出入库类型';
      SELECT
        DECODE(TT.ACTION_TYPE,'02','OUT','IN')
      INTO
        S_IN_OUT_TYPE
      FROM
        T_INV_BILL_TYPES BT
        ,T_INV_TRANSACTION_TYPES TT
      WHERE
        BT.TRANSACTION_TYPE_ID = TT.TRANSACTION_TYPE_ID
        AND BT.BILL_TYPE_ID = N_CHECK_ORDER_TYPE_ID;
    END IF;

    --取出指令号
    IF OS_MESSAGE = 'OK' THEN
      S_STEP := '取指令号';
      S_ALLOT_ORDER_NUM := PKG_BD.F_GET_BILL_NO('ALLOT_ORDER',NULL,N_ENTITY_ID,NULL);
    END IF;

    --取出指令ID
    IF OS_MESSAGE = 'OK' THEN
      S_STEP := '取出指令ID';
      SELECT
        S_SL_ALLOT_ORDER.NEXTVAL
      INTO
        N_ALLOT_ORDER_ID
      FROM
        DUAL;
    END IF;

    --写分库指令头表(发货通知单表没有ACCOUNT_ID，需关联取出)
    IF OS_MESSAGE = 'OK' THEN
      S_STEP := '写分库指令头表';
      INSERT INTO T_SL_ALLOT_ORDER
      (
        ALLOT_ORDER_ID
        ,ENTITY_ID
        ,ALLOT_ORDER_NUM
        ,IN_OUT_TYPE
        ,BUSINESS_TYPE
        ,STATUS
        ,ALLOTED_FLAG
        ,SOURCE_TYPE
        ,SOURCE_BILL_ID
        ,SOURCE_BILL_NUM
        ,SOURCE_BILL_DATE
        ,PLAN_SHIP_DATE
        ,INVENTORY_ID
        ,INVENTORY_CODE
        ,INVENTORY_NAME
        ,CUSTOMER_ID
        ,CUSTOMER_CODE
        ,CUSTOMER_NAME
        ,SALES_CENTER_ID
        ,SALES_CENTER_CODE
        ,SALES_CENTER_NAME
        ,ACCOUNT_ID
        ,CARRIER_ID
        ,CARRIER_CODE
        ,CARRIER_NAME
        ,VEHICLE_BRAND
        ,REMARK
        ,CREATED_BY
        ,CREATION_DATE
        ,LAST_UPDATED_BY
        ,LAST_UPDATE_DATE
      )
      SELECT
        N_ALLOT_ORDER_ID ALLOT_ORDER_ID
        ,CO.ENTITY_ID
        ,S_ALLOT_ORDER_NUM ALLOT_ORDER_NUM
        ,S_IN_OUT_TYPE IN_OUT_TYPE
        ,'1009' BUSINESS_TYPE  --盘点
        ,'CREATED' STATUS
        ,'N' ALLOTED_FLAG
        ,'CHECK_ORDER' SOURCE_TYPE
        ,IN_CHECK_ORDER_ID SOURCE_BILL_ID
        ,CO.CHECK_ORDER_NUM SOURCE_BILL_NUM
        ,CO.DOC_DATE SOURCE_BILL_DATE
        ,NULL PLAN_SHIP_DATE
        ,CO.INV_ID INVENTORY_ID
        ,CO.INV_CODE INVENTORY_CODE
        ,CO.INV_NAME INVENTORY_NAME
        ,NULL CUSTOMER_ID
        ,NULL CUSTOMER_CODE
        ,NULL CUSTOMER_NAME
        ,CO.SALES_CENTER_ID
        ,CO.SALES_CENTER_CODE
        ,CO.SALES_CENTER_NAME
        ,NULL ACCOUNT_ID
        ,NULL CARRIER_ID
        ,NULL CARRIER_CODE
        ,NULL CARRIER_NAME
        ,NULL VEHICLE_BRAND
        ,CO.REMARK
        ,IS_USER_ACCOUNT CREATED_BY
        ,SYSDATE CREATION_DATE
        ,IS_USER_ACCOUNT LAST_UPDATED_BY
        ,SYSDATE LAST_UPDATE_DATE
      FROM
        T_INV_CHECK_ORDERS CO
      WHERE
        CO.CHECK_ORDER_ID = IN_CHECK_ORDER_ID;
    END IF;

    --写分库指令行表
    IF OS_MESSAGE = 'OK' THEN
      S_STEP := '写分库指令行表';
      INSERT INTO T_SL_ALLOT_ORDER_LINE
      (
        ALLOT_ORDER_LINE_ID
        ,ALLOT_ORDER_ID
        ,ITEM_ID
        ,ITEM_CODE
        ,ITEM_NAME
        ,ITEM_UOM
        ,QUANTITY
        ,SOURCE_LINE_ID
        ,CREATED_BY
        ,CREATION_DATE
        ,LAST_UPDATED_BY
        ,LAST_UPDATE_DATE
      )
      SELECT
        S_SL_ALLOT_ORDER_LINE.NEXTVAL ALLOT_ORDER_LINE_ID
        ,N_ALLOT_ORDER_ID ALLOT_ORDER_ID
        ,COL.ITEM_ID
        ,COL.ITEM_CODE
        ,COL.ITEM_NAME
        ,COL.UOM_CODE ITEM_UOM
        ,COL.EXEC_QTY QUANTITY
        ,COL.CHECK_ORDER_LINE_ID SOURCE_LINE_ID
        ,IS_USER_ACCOUNT CREATED_BY
        ,SYSDATE CREATION_DATE
        ,IS_USER_ACCOUNT LAST_UPDATED_BY
        ,SYSDATE LAST_UPDATE_DATE
      FROM
        T_INV_CHECK_ORDER_LINES COL
      WHERE
        COL.CHECK_ORDER_ID = IN_CHECK_ORDER_ID
        AND COL.EXEC_QTY > 0;
    END IF;

    --根据配套关系写分库指令明细表
    IF OS_MESSAGE = 'OK' THEN
      S_STEP := '写分库指令明细表';
      P_CREATE_ALLOT_DETAIL(N_ALLOT_ORDER_ID, N_ENTITY_ID, IS_USER_ACCOUNT);
    END IF;

    IF OS_MESSAGE <> 'OK' THEN
      ROLLBACK TO SAVEPOINT SP;
    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK TO SAVEPOINT SP;
      OS_MESSAGE := '发货通知单生成分库指令-'|| S_STEP || ':' || SQLERRM;
  END P_CHECK_ORDER_ALLOT;

  -----------------------------------------------------------------------------
  --  将实发数量记录到实际发货信息表中（用于生成销售单、调拨单）             --
  -----------------------------------------------------------------------------
  PROCEDURE P_TO_ACTUAL_SHIP(
    IN_BILL_HEADER_ID         IN  NUMBER   --库位单ID
    ,IS_USER_ID               IN  VARCHAR2 --用户ID
    ,OS_MESSAGE               OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  ) IS
    S_STEP             VARCHAR2(40);
    S_BILL_STATUS      VARCHAR2(32);
    S_SOURCE_TYPE      VARCHAR2(32);
    N_SHIP_DOC_ID      NUMBER;
    N_CNT              NUMBER;
    N_ACTUAL_SHIP_ID   NUMBER;
    S_BILL_NUMBER      VARCHAR2(32);
  BEGIN
    OS_MESSAGE := 'OK';
    SAVEPOINT SP;

    --锁定库位单表
    BEGIN
      SELECT
        BILL_STATUS
        ,SOURCE_TYPE
        ,SOURCE_BILL_ID
        ,BILL_NUMBER
      INTO
        S_BILL_STATUS
        ,S_SOURCE_TYPE
        ,N_SHIP_DOC_ID
        ,S_BILL_NUMBER
      FROM
        T_SL_BILL_HEADER
      WHERE
        BILL_HEADER_ID = IN_BILL_HEADER_ID
      FOR UPDATE NOWAIT;
      IF S_BILL_STATUS <> 'AFFRIMED' THEN
        OS_MESSAGE := '只有确认状态的库位单才能写实际发货信息。';
      ELSIF S_SOURCE_TYPE <> 'SHIP_DOC' THEN
        OS_MESSAGE := '只有来源于发货通知单的库位单才能写实际发货信息。';
      END IF;
    EXCEPTION
      WHEN TIMEOUT_ON_RESOURCE THEN
        OS_MESSAGE := '锁定库位单不成功！请稍后再试。';
    END;

    --检查是否已写发货信息表
    IF OS_MESSAGE = 'OK' THEN
      S_STEP := '检查是否已写发货信息';
      SELECT
        COUNT(*)
      INTO
        N_CNT
      FROM
        T_LG_ACTUAL_SHIP
      WHERE
        SOURCE_BILL_ID = IN_BILL_HEADER_ID
        AND SOURCE_TYPE = 'SL_BILL'
        AND ROWNUM = 1;
      IF N_CNT > 0 THEN
        OS_MESSAGE := '当前库位单已写发货信息，不能重复发货！';
      END IF;
    END IF;

    --写发货信息
    IF OS_MESSAGE = 'OK' THEN
      --按发货通知单对应的来源单据号分组，循环生成发货信息
      S_STEP := '写发货信息';
      FOR R_BILL IN
      (
        SELECT DISTINCT
          SDL.SALES_MAIN_TYPE
          ,SDL.ORIGIN_TYPE
          ,SDL.ORIGIN_ORDER_NUM
          ,SDL.ORIGIN_ORDER_ID
          ,SDL.SALES_ORDER_TYPE_ID
        FROM
          T_SL_BILL_LINE BL
          ,T_LG_SHIP_DOC_LINE SDL
        WHERE
          BL.SOURCE_LINE_ID = SDL.SHIP_DOC_LINE_ID
          AND BL.BILL_HEADER_ID = IN_BILL_HEADER_ID
      )
      LOOP
        --获取发货信息头ID
        SELECT
          S_LG_ACTUAL_SHIP.NEXTVAL
        INTO
          N_ACTUAL_SHIP_ID
        FROM
          DUAL;

        --写发货信息头表
        INSERT INTO T_LG_ACTUAL_SHIP
        (
          ACTUAL_SHIP_ID
          ,ENTITY_ID
          ,SALES_MAIN_TYPE
          ,VEHICLE_NUM
          ,SALES_ORDER_TYPE_ID
          ,VENDOR_ID
          ,VENDOR_CODE
          ,VENDOR_NAME
          ,SHIP_INVENTORY_ID
          ,CONSIGNEE_INVENTORY_ID
          ,CONSIGNEE_LOCATION_CODE
          ,CONSIGNEE_ADDR
          ,SHIP_WAY
          ,ORIGIN_TYPE
          ,ORIGIN_ORDER_NUM
          ,ORIGIN_ORDER_ID
          ,CUSTOMER_ID
          ,CUSTOMER_CODE
          ,CUSTOMER_NAME
          ,ACCOUNT_CODE
          ,SHIP_DATE
          ,SOURCE_TYPE
          ,SOURCE_BILL_ID
          ,SOURCE_BILL_NUM
          ,CREATED_BY
          ,CREATION_DATE
          ,LAST_UPDATED_BY
          ,LAST_UPDATE_DATE
        )
        SELECT
          N_ACTUAL_SHIP_ID ACTUAL_SHIP_ID
          ,SD.ENTITY_ID
          ,R_BILL.SALES_MAIN_TYPE
          ,NVL(SD.VEHICLE_NUM,S_BILL_NUMBER) VEHICLE_NUM
          ,R_BILL.SALES_ORDER_TYPE_ID
          ,SD.VENDOR_ID
          ,SD.VENDOR_CODE
          ,SD.VENDOR_NAME
          ,SD.SHIP_INVENTORY_ID
          ,SD.CONSIGNEE_INVENTORY_ID
          ,SD.CONSIGNEE_LOCATION_CODE
          ,SD.CONSIGNEE_ADDR
          ,SD.SHIP_WAY
          ,R_BILL.ORIGIN_TYPE
          ,R_BILL.ORIGIN_ORDER_NUM
          ,R_BILL.ORIGIN_ORDER_ID
          ,SD.CUSTOMER_ID
          ,SD.CUSTOMER_CODE
          ,SD.CUSTOMER_NAME
          ,SD.ACCOUNT_CODE
          ,TRUNC(SYSDATE) SHIP_DATE
          ,'SL_BILL' SOURCE_TYPE
          ,IN_BILL_HEADER_ID SOURCE_BILL_ID
          ,S_BILL_NUMBER SOURCE_BILL_NUM
          ,IS_USER_ID CREATED_BY
          ,SYSDATE CREATION_DATE
          ,IS_USER_ID LAST_UPDATED_BY
          ,SYSDATE LAST_UPDATE_DATE
        FROM
          T_LG_SHIP_DOC SD
        WHERE
          SD.SHIP_DOC_ID = N_SHIP_DOC_ID;

        --写发货信息行表(将最小的库位单行ID带到发货信息表中)，为了简化逻辑，暂不处理配套关系
        INSERT INTO T_LG_ACTUAL_SHIP_LINE
        (
          SOURCE_BILL_LINE_ID
          ,ORIGIN_SHIP_PLAN_ID
          ,ACTUAL_SHIP_LINE_ID
          ,SHIP_INFO_ID
          ,SHIP_DOC_LINE_ID
          ,ORIGIN_LINE_ID
          ,ITEM_CODE
          ,ITEM_NAME
          ,ITEM_QTY
          ,CREATED_BY
          ,CREATION_DATE
          ,LAST_UPDATED_BY
          ,LAST_UPDATE_DATE
        )
        SELECT
          L.BILL_LINE_ID SOURCE_BILL_LINE_ID
          ,L.ORIGIN_SHIP_PLAN_ID
          ,S_LG_ACTUAL_SHIP_LINE.NEXTVAL ACTUAL_SHIP_LINE_ID
          ,N_ACTUAL_SHIP_ID SHIP_INFO_ID
          ,L.SHIP_DOC_LINE_ID
          ,L.ORIGIN_LINE_ID
          ,L.ITEM_CODE
          ,L.ITEM_DESC ITEM_NAME
          ,L.QUANTITY ITEM_QTY
          ,IS_USER_ID CREATED_BY
          ,SYSDATE CREATION_DATE
          ,IS_USER_ID LAST_UPDATED_BY
          ,SYSDATE LAST_UPDATE_DATE
        FROM
          (
            SELECT
              ORIGIN_SHIP_PLAN_ID
              ,SHIP_DOC_LINE_ID
              ,ORIGIN_LINE_ID
              ,ITEM_CODE
              ,ITEM_DESC
              ,MIN(QUANTITY) QUANTITY 
              ,MIN(BILL_LINE_ID) BILL_LINE_ID
            FROM
              (
                SELECT
                  SDL.ORIGIN_SHIP_PLAN_ID
                  ,SDL.SHIP_DOC_LINE_ID
                  ,SDL.ORIGIN_LINE_ID
                  ,SDL.ITEM_CODE
                  ,SDL.ITEM_DESC
                  ,BL.ITEM_ID
                  ,ROUND(SUM(BL.QUANTITY/NVL(AOD.ASS_QTY,1))) QUANTITY
                  ,MIN(BL.BILL_LINE_ID) BILL_LINE_ID
                FROM
                  T_SL_BILL_LINE BL
                  ,T_LG_SHIP_DOC SD
                  ,T_LG_SHIP_DOC_LINE SDL
                  ,T_SL_ALLOT_ORDER_DETAIL AOD
                WHERE
                  BL.SOURCE_LINE_ID = SDL.SHIP_DOC_LINE_ID
                  AND SDL.SHIP_DOC_ID = N_SHIP_DOC_ID
                  AND SD.SHIP_DOC_ID = N_SHIP_DOC_ID
                  AND BL.BILL_HEADER_ID = IN_BILL_HEADER_ID
                  AND SDL.ORIGIN_TYPE = R_BILL.ORIGIN_TYPE
                  AND SDL.ORIGIN_ORDER_ID = R_BILL.ORIGIN_ORDER_ID
                  AND BL.ALLOT_ORDER_DETAIL_ID = AOD.ALLOT_ORDER_DETAIL_ID
                GROUP BY
                  SDL.ORIGIN_SHIP_PLAN_ID
                  ,SDL.SHIP_DOC_LINE_ID
                  ,SDL.ORIGIN_LINE_ID
                  ,SDL.ITEM_CODE
                  ,SDL.ITEM_DESC
                  ,BL.ITEM_ID
              )
            GROUP BY
              ORIGIN_SHIP_PLAN_ID
              ,SHIP_DOC_LINE_ID
              ,ORIGIN_LINE_ID
              ,ITEM_CODE
              ,ITEM_DESC
          ) L;

      END LOOP;
    END IF;

    IF OS_MESSAGE <> 'OK' THEN
      ROLLBACK TO SAVEPOINT SP;
    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK TO SAVEPOINT SP;
      OS_MESSAGE := '写实际发货信息(库位单ID:' || TO_CHAR(IN_BILL_HEADER_ID) || ')-'|| S_STEP || ':' || SQLERRM;
  END P_TO_ACTUAL_SHIP;

  -----------------------------------------------------------------------------
  --  将实收数量记录到退货信息表中（用于生成销售退货单）                     --
  -----------------------------------------------------------------------------
  PROCEDURE P_TO_RETURN_RECEIVE(
    IN_BILL_HEADER_ID         IN  NUMBER   --库位单ID
    ,IS_USER_ID               IN  VARCHAR2 --用户ID
    ,OS_MESSAGE               OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  )
  IS
    S_STEP             VARCHAR2(40);
    S_BILL_NUMBER      VARCHAR2(40);
    S_BILL_STATUS      VARCHAR2(32);
    S_SOURCE_TYPE      VARCHAR2(32);
    S_RETURN_APPLY_NUM VARCHAR2(32);
    S_REV_INV_CODE     VARCHAR2(32);
    S_REMARK           VARCHAR2(240);
    N_CNT              NUMBER;
  BEGIN
    OS_MESSAGE := 'OK';
    SAVEPOINT SP;

    --锁定库位单表
    BEGIN
      SELECT
        BILL_NUMBER
        ,BILL_STATUS
        ,SOURCE_TYPE
        ,SOURCE_BILL_NUM
        ,REV_INV_CODE
        ,REMARK
      INTO
        S_BILL_NUMBER
        ,S_BILL_STATUS
        ,S_SOURCE_TYPE
        ,S_RETURN_APPLY_NUM
        ,S_REV_INV_CODE
        ,S_REMARK
      FROM
        T_SL_BILL_HEADER
      WHERE
        BILL_HEADER_ID = IN_BILL_HEADER_ID
      FOR UPDATE NOWAIT;
      IF S_BILL_STATUS <> 'AFFRIMED' THEN
        OS_MESSAGE := '只有确认状态的库位单才能写退货签收信息。';
      ELSIF S_SOURCE_TYPE <> 'RETURN_APPLY' THEN
        OS_MESSAGE := '只有来源于退货申请的库位单才能写退货签收信息。';
      END IF;
    EXCEPTION
      WHEN TIMEOUT_ON_RESOURCE THEN
        OS_MESSAGE := '锁定库位单不成功！请稍后再试。';
    END;

    --检查是否已写退货签收信息表
    IF OS_MESSAGE = 'OK' THEN
      S_STEP := '检查是否已写退货签收信息';
      SELECT
        COUNT(*)
      INTO
        N_CNT
      FROM
        T_SO_RETURN_RECEIVE
      WHERE
        SOURCE_BILL_ID = IN_BILL_HEADER_ID
        AND SOURCE_TYPE = 'SL_BILL'
        AND ROWNUM = 1;
      IF N_CNT > 0 THEN
        OS_MESSAGE := '当前库位单已写退货签收信息，不能重复收货！';
      END IF;
    END IF;

    --写退货签收信息
    IF OS_MESSAGE = 'OK' THEN
      S_STEP := '写退货签收信息';
      INSERT INTO T_SO_RETURN_RECEIVE
      (
        RTN_RECV_ID
        ,BILL_NUM
        ,APPLY_LINE_DETAIL_ID
        ,SOURCE_TYPE
        ,SOURCE_BILL_ID
        ,SOURCE_BILL_NUM
        ,ITEM_CODE
        ,ITEM_STATUS
        ,RECEIVED_QTY
        ,RECEIVE_INV_CODE
        ,TO_DETAIL_FLAG
        ,REMARK
        ,CREATED_BY
        ,CREATION_DATE
        ,LAST_UPDATED_BY
        ,LAST_UPDATE_DATE
      )
      SELECT
        S_SO_RETURN_RECEIVE.NEXTVAL RTN_RECV_ID
        ,S_RETURN_APPLY_NUM BILL_NUM
        ,SOURCE_LINE_ID APPLY_LINE_DETAIL_ID
        ,'SL_BILL' SOURCE_TYPE
        ,IN_BILL_HEADER_ID SOURCE_BILL_ID
        ,S_BILL_NUMBER SOURCE_BILL_NUM
        ,BL.ITEM_CODE
        ,'S01' ITEM_STATUS   --正品
        ,BL.AFFIRM_QTY RECEIVED_QTY
        ,S_REV_INV_CODE RECEIVE_INV_CODE
        ,'N' TO_DETAIL_FLAG
        ,S_REMARK REMARK
        ,IS_USER_ID CREATED_BY
        ,SYSDATE CREATION_DATE
        ,IS_USER_ID LAST_UPDATED_BY
        ,SYSDATE LAST_UPDATE_DATE
      FROM
        T_SL_BILL_LINE BL
      WHERE
        BL.BILL_HEADER_ID = IN_BILL_HEADER_ID;
    END IF;

    IF OS_MESSAGE <> 'OK' THEN
      ROLLBACK TO SAVEPOINT SP;
    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK TO SAVEPOINT SP;
      OS_MESSAGE := '写退货签收信息(库位单ID:' || TO_CHAR(IN_BILL_HEADER_ID) || ')-'|| S_STEP || ':' || SQLERRM;
  END P_TO_RETURN_RECEIVE;

  -----------------------------------------------------------------------------
  --  分库结果生成库位单                                                    --
  -----------------------------------------------------------------------------
  PROCEDURE P_ALLOT_RESULT_TO_BILL(
     IN_BATCH_ID              IN  NUMBER   --盘点单ID
    ,IN_ALLOT_ORDER_ID        IN  NUMBER   --分库指令ID
    ,IS_USER_ACCOUNT          IN  VARCHAR2 --用户账号
    ,ID_BILLDATE              IN  DATE     --单据日期
    ,OS_BILLHEADERID          OUT VARCHAR2   --库位单ID
    ,OS_BILLNUMBER            OUT VARCHAR2   --库位单号
    ,OS_MESSAGE               OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  ) IS
       N_BILL_HEADER_ID   NUMBER;
       S_BILL_NUMBER      VARCHAR2(32);
       N_SEND_INV_ID      NUMBER;
       S_SEND_INV_CODE    VARCHAR2(32);
       S_SEND_INV_DESC    VARCHAR2(240);
       N_REV_INV_ID       NUMBER;
       S_REV_INV_CODE     VARCHAR2(32);
       S_REV_INV_DESC     VARCHAR2(240);
       S_TO_BILL_FLAG     VARCHAR2(4);
       N_SET_QUANTITY     NUMBER;
       N_TEM_K            NUMBER;
       N_SET_QUANTITY_TEM NUMBER;
       N_SET_K            NUMBER;
       N_NEED_QUANTITY    NUMBER;

       D_DATE         DATE;
       S_YEAR         VARCHAR2(8);
       S_MONTH        VARCHAR2(8);
       N_PERIOD_ID    NUMBER;
       S_YEAR_MONTH   VARCHAR2(8);
       i NUMBER;
       S_CHILD_MESSAGE VARCHAR2(200);
       TYPE ID_ARRAY IS TABLE OF NUMBER
       INDEX BY BINARY_INTEGER;
       N_BILL_HEADER_ARRAY   ID_ARRAY;
       
       N_ALLOT_ORDER_ID NUMBER;

    BEGIN
       OS_MESSAGE          := 'OK';
       N_TEM_K := 0;
       N_SET_K := 0;
       i :=1;

       D_DATE := ID_BILLDATE;
       S_YEAR  := TO_CHAR(D_DATE,'YYYY');
       S_MONTH := TO_CHAR(D_DATE,'MM');
       S_YEAR_MONTH := S_YEAR||'-'||S_MONTH;

       --锁定分库批次,获取库位单是否生成库位单状态
       BEGIN
        SELECT
          TO_BILL_FLAG
        INTO
          S_TO_BILL_FLAG
        FROM
          T_SL_ALLOT_BATCH
        WHERE
           ALLOT_BATCH_ID = IN_BATCH_ID
           AND ROWNUM = 1
        FOR UPDATE NOWAIT;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          OS_MESSAGE := '锁定分库批次不成功！请稍后再试。';
          RETURN;
      END;
      
        --锁定分库指令
       BEGIN
        SELECT
          ALLOT_ORDER_ID
        INTO
          N_ALLOT_ORDER_ID
        FROM
          T_SL_ALLOT_ORDER
        WHERE
           ALLOT_ORDER_ID = IN_ALLOT_ORDER_ID
           AND ROWNUM = 1
        FOR UPDATE NOWAIT;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          OS_MESSAGE := '锁定分库指令不成功！请稍后再试。';
          RETURN;
      END;

      IF S_TO_BILL_FLAG='Y' THEN
              OS_MESSAGE := '当前批次已生成库位单,不能重复生成！';
             RETURN;
      END IF;

      FOR ALLOT_RESULT_ROW IN (
          SELECT DISTINCT  R.FACT_INV_ID,
                  R.FACT_INV_CODE,
                  R.FACT_INV_NAME,
                  O.INVENTORY_ID,
                  O.INVENTORY_CODE,
                  O.INVENTORY_NAME,
                  O.CUSTOMER_ID,
                  O.CUSTOMER_CODE,
                  O.CUSTOMER_NAME,
                  O.SALES_CENTER_ID,
                  O.SALES_CENTER_CODE,
                  O.SALES_CENTER_NAME,
                  O.ACCOUNT_ID,
                  O.CARRIER_ID,
                  O.CARRIER_CODE,
                  O.CARRIER_NAME,
                  O.VEHICLE_BRAND,
                  O.ENTITY_ID,
                  O.BUSINESS_TYPE,
                  O.SOURCE_TYPE,
                  O.SOURCE_BILL_ID,
                  O.SOURCE_BILL_NUM,
                  B.BILL_TYPE_ID ,
                  ST.SOURCE_TYPE_CODE,
                  BT.CANCEL_FLAG,
                  TT.ACTION_TYPE,
                  O.REMARK,
                  o.ALLOT_ORDER_ID,
                  o.ALLOT_ORDER_NUM
            FROM  T_SL_ALLOT_BATCH B,
                  T_SL_ALLOT_RESULT R,
                  T_SL_ALLOT_ORDER O,
                  T_INV_BILL_TYPES BT,
                  T_INV_SOURCE_TYPES ST,
                  T_INV_TRANSACTION_TYPES TT
            WHERE B.ALLOT_BATCH_ID = R.ALLOT_BATCH_ID
            AND   R.ALLOT_ORDER_ID = O.ALLOT_ORDER_ID
            AND   B.BILL_TYPE_ID = BT.BILL_TYPE_ID(+)
            AND   BT.SOURCE_TYPE_ID = ST.SOURCE_TYPE_ID(+)
            AND   BT.TRANSACTION_TYPE_ID = TT.TRANSACTION_TYPE_ID(+)
            AND   B.ALLOT_BATCH_ID = IN_BATCH_ID
       )
       LOOP
        BEGIN
           SELECT
            S_SL_BILL_HEADER.NEXTVAL
          INTO
            N_BILL_HEADER_ID
          FROM
            DUAL;
          IF ALLOT_RESULT_ROW.ACTION_TYPE = '01' THEN
                  N_SEND_INV_ID   := NULL;
                  S_SEND_INV_CODE := NULL;
                  S_SEND_INV_DESC := NULL;
                  N_REV_INV_ID    := ALLOT_RESULT_ROW.FACT_INV_ID;
                  S_REV_INV_CODE  := ALLOT_RESULT_ROW.FACT_INV_CODE;
                  S_REV_INV_DESC  := ALLOT_RESULT_ROW.FACT_INV_NAME;
          ELSIF ALLOT_RESULT_ROW.ACTION_TYPE = '02' THEN
                  N_SEND_INV_ID   := ALLOT_RESULT_ROW.FACT_INV_ID;
                  S_SEND_INV_CODE := ALLOT_RESULT_ROW.FACT_INV_CODE;
                  S_SEND_INV_DESC := ALLOT_RESULT_ROW.FACT_INV_NAME;
                  N_REV_INV_ID    := NULL;
                  S_REV_INV_CODE  := NULL;
                  S_REV_INV_DESC  := NULL;
          ELSE
                  OS_MESSAGE          := '发货指令数据无效ACTION_TYPE不能等于03';
                  
                  RETURN;
          END IF;
          
          BEGIN
            SELECT
              PERIOD_ID
            INTO
              N_PERIOD_ID
            FROM
              T_INV_INVENTORY_PERIODS
            WHERE
              PERIOD_NAME = S_YEAR_MONTH
              AND ENTITY_ID = ALLOT_RESULT_ROW.ENTITY_ID
              AND ROWNUM = 1;
         EXCEPTION
            WHEN NO_DATA_FOUND THEN
                OS_MESSAGE := '当前月份期间不存在';
            RETURN;
         END;

          N_BILL_HEADER_ARRAY(i) := N_BILL_HEADER_ID;
          i:=i+1;

          S_BILL_NUMBER := PKG_BD.F_GET_BILL_NO('SL_BILL',NULL,ALLOT_RESULT_ROW.ENTITY_ID,NULL);
          OS_BILLNUMBER := OS_BILLNUMBER||','||S_BILL_NUMBER;
          OS_BILLHEADERID  := OS_BILLHEADERID||','||N_BILL_HEADER_ID;
          INSERT INTO T_SL_BILL_HEADER(
                       BILL_HEADER_ID,
                       INVENTORY_ID,
                       INVENTORY_CODE,
                       INVENTORY_NAME,
                       CUSTOMER_ID,
                       CUSTOMER_CODE,
                       CUSTOMER_NAME,
                       SALES_CENTER_ID,
                       SALES_CENTER_CODE,
                       SALES_CENTER_NAME,
                       ACCOUNT_ID,
                       CARRIER_ID,
                       CARRIER_CODE,
                       CARRIER_NAME,
                       VEHICLE_BRAND,
                       CREATED_BY,
                       CREATION_DATE,
                       LAST_UPDATED_BY,
                       LAST_UPDATE_DATE,
                       ENTITY_ID,
                       BILL_NUMBER,
                       BILL_DATE,
                       BILL_TYPE_ID,
                       BILL_STATUS,
                       CANCEL_FLAG,
                       BUSINESS_TYPE,
                       OLD_BILL_NUMBER,
                       SOURCE_TYPE_CODE,
                       REMARK,
                       LOAD_UNIT,
                       SEND_INV_ID,
                       SEND_INV_CODE,
                       SEND_INV_DESC,
                       REV_INV_ID,
                       REV_INV_CODE,
                       REV_INV_DESC,
                       SOURCE_TYPE,
                       SOURCE_BILL_ID,
                       SOURCE_BILL_NUM,
                       PERIOD_ID,
                       LOCK_FLAG,
                       ALLOT_ORDER_ID,
                       ALLOT_ORDER_NUM
                       )
          VALUES(N_BILL_HEADER_ID,
                 ALLOT_RESULT_ROW.INVENTORY_ID,
                 ALLOT_RESULT_ROW.INVENTORY_CODE,
                 ALLOT_RESULT_ROW.INVENTORY_NAME,
                 ALLOT_RESULT_ROW.CUSTOMER_ID,
                 ALLOT_RESULT_ROW.CUSTOMER_CODE,
                 ALLOT_RESULT_ROW.CUSTOMER_NAME,
                 ALLOT_RESULT_ROW.SALES_CENTER_ID,
                 ALLOT_RESULT_ROW.SALES_CENTER_CODE,
                 ALLOT_RESULT_ROW.SALES_CENTER_NAME,
                 ALLOT_RESULT_ROW.ACCOUNT_ID,
                 ALLOT_RESULT_ROW.CARRIER_ID,
                 ALLOT_RESULT_ROW.CARRIER_CODE,
                 ALLOT_RESULT_ROW.CARRIER_NAME,
                 ALLOT_RESULT_ROW.VEHICLE_BRAND,
                 IS_USER_ACCOUNT,
                 SYSDATE,
                 IS_USER_ACCOUNT,
                 SYSDATE,
                 ALLOT_RESULT_ROW.ENTITY_ID,
                 S_BILL_NUMBER,
                 ID_BILLDATE,
                 ALLOT_RESULT_ROW.BILL_TYPE_ID,
                 'CREATED',
                 'N',
                 ALLOT_RESULT_ROW.BUSINESS_TYPE,
                 NULL,
                 ALLOT_RESULT_ROW.SOURCE_TYPE_CODE,
                 ALLOT_RESULT_ROW.REMARK,
                 NULL,
                 N_SEND_INV_ID,
                 S_SEND_INV_CODE,
                 S_SEND_INV_DESC,
                 N_REV_INV_ID,
                 S_REV_INV_CODE,
                 S_REV_INV_DESC,
                 ALLOT_RESULT_ROW.SOURCE_TYPE,
                 ALLOT_RESULT_ROW.SOURCE_BILL_ID,
                 ALLOT_RESULT_ROW.SOURCE_BILL_NUM,
                 N_PERIOD_ID,
                 'N',
                 ALLOT_RESULT_ROW.ALLOT_ORDER_ID,
                 ALLOT_RESULT_ROW.ALLOT_ORDER_NUM
          );

          INSERT INTO T_SL_BILL_LINE (
                      BILL_LINE_ID,
                      ALLOT_ORDER_ID,
                      BILL_HEADER_ID,
                      ALLOT_ORDER_DETAIL_ID,
                      OLD_LINE_ID,
                      LINE_NUM,
                      ITEM_ID,
                      ITEM_CODE,
                      ITEM_NAME,
                      ITEM_UOM,
                      ITEM_BAR_CODE,
                      SEND_LOCATION_ID,
                      SEND_LOCATION_CODE,
                      SEND_LOCATION_NAME,
                      SEND_ITEM_BATCH,
                      REV_LOCATION_ID,
                      REV_LOCATION_CODE,
                      REV_LOCATION_NAME,
                      REV_ITEM_BATCH,
                      SEND_ITEM_STATUS,
                      REV_ITEM_STATUS,
                      QUANTITY,
                      CANCEL_QTY,
                      AFFIRM_QTY,
                      SOURCE_LINE_ID,
                      REMARK,
                      CREATED_BY,
                      CREATION_DATE,
                      LAST_UPDATED_BY,
                      LAST_UPDATE_DATE)
              SELECT  S_SL_BILL_LINE.NEXTVAL,
                            R.ALLOT_ORDER_ID,
                            N_BILL_HEADER_ID,
                            R.ALLOT_ORDER_DETAIL_ID,
                            NULL,
                            ROWNUM,
                            R.ITEM_ID,
                            R.ITEM_CODE,
                            R.ITEM_NAME,
                            R.ITEM_UOM,
                            IT.BARCODE,
                            DECODE(ALLOT_RESULT_ROW.ACTION_TYPE,'01',NULL,R.LOCATION_ID),
                            DECODE(ALLOT_RESULT_ROW.ACTION_TYPE,'01',NULL,R.LOCATION_CODE),
                            DECODE(ALLOT_RESULT_ROW.ACTION_TYPE,'01',NULL,R.LOCATION_NAME),
                            DECODE(ALLOT_RESULT_ROW.ACTION_TYPE,'01',NULL,R.ITEM_BATCH),
                            DECODE(ALLOT_RESULT_ROW.ACTION_TYPE,'02',NULL,R.LOCATION_ID),
                            DECODE(ALLOT_RESULT_ROW.ACTION_TYPE,'02',NULL,R.LOCATION_CODE),
                            DECODE(ALLOT_RESULT_ROW.ACTION_TYPE,'02',NULL,R.LOCATION_NAME),
                            DECODE(ALLOT_RESULT_ROW.ACTION_TYPE,'02',NULL,R.ITEM_BATCH),
                            DECODE(ALLOT_RESULT_ROW.ACTION_TYPE,'01',NULL,R.ITEM_STATUS),
                            DECODE(ALLOT_RESULT_ROW.ACTION_TYPE,'02',NULL,R.ITEM_STATUS),
                            R.QUANTITY,
                            NULL,
                            NULL,
                            L.SOURCE_LINE_ID,
                            NULL,
                            IS_USER_ACCOUNT,
                            SYSDATE,
                            IS_USER_ACCOUNT,
                            SYSDATE

            FROM T_SL_ALLOT_RESULT R,
                 T_BD_ITEM IT,
                 T_SL_ALLOT_ORDER O,
                 T_SL_ALLOT_BATCH B,
                 T_SL_ALLOT_ORDER_DETAIL D,
                 T_SL_ALLOT_ORDER_LINE L
            WHERE R.ALLOT_ORDER_ID = O.ALLOT_ORDER_ID AND
                  IT.ITEM_ID = R.ITEM_ID AND
                  B.ALLOT_BATCH_ID = R.ALLOT_BATCH_ID AND
                  R.ALLOT_ORDER_DETAIL_ID = D.ALLOT_ORDER_DETAIL_ID AND
                  D.ALLOT_ORDER_LINE_ID = l.allot_order_line_id AND
                  l.allot_order_id = r.allot_order_id and
                  l.allot_order_id = d.allot_order_id and

                  nvl(R.FACT_INV_ID,-1) = nvl(ALLOT_RESULT_ROW.FACT_INV_ID,-1) AND
                  nvl(O.INVENTORY_ID,-1) = nvl(ALLOT_RESULT_ROW.INVENTORY_ID,-1) AND
                  nvl(O.CUSTOMER_ID,-1) = nvl(ALLOT_RESULT_ROW.CUSTOMER_ID,-1) AND
                  nvl(O.SALES_CENTER_ID,-1) = nvl(ALLOT_RESULT_ROW.SALES_CENTER_ID,-1) AND
                  nvl(O.ACCOUNT_ID,-1) = nvl(ALLOT_RESULT_ROW.ACCOUNT_ID,-1) AND
                  nvl(O.CARRIER_ID,-1) = nvl(ALLOT_RESULT_ROW.CARRIER_ID,-1) AND
                  nvl(O.VEHICLE_BRAND,'NULL') =  nvl(ALLOT_RESULT_ROW.VEHICLE_BRAND,'NULL') AND
                  nvl(O.ENTITY_ID,-1) = nvl(ALLOT_RESULT_ROW.ENTITY_ID,-1) AND
                  nvl(O.BUSINESS_TYPE,'NULL') =  nvl(ALLOT_RESULT_ROW.BUSINESS_TYPE,'NULL') AND
                  nvl(B.BILL_TYPE_ID,-1) =  nvl(ALLOT_RESULT_ROW.BILL_TYPE_ID,-1) AND

                  R.ALLOT_BATCH_ID=IN_BATCH_ID;
        EXCEPTION
               WHEN OTHERS THEN
               OS_MESSAGE := SUBSTR(SQLERRM(SQLCODE), 1, 256);
               
               RETURN;
        END;
       END LOOP;
       --更新批次为已生成库位单
       UPDATE T_SL_ALLOT_BATCH
       SET TO_BILL_FLAG = 'Y',
           ALLOT_DATE = SYSDATE,
           LAST_UPDATED_BY = IS_USER_ACCOUNT,
           LAST_UPDATE_DATE = SYSDATE
       WHERE  ALLOT_BATCH_ID=IN_BATCH_ID;

       --更新分库明细分库数量
      UPDATE T_SL_ALLOT_ORDER_DETAIL D SET D.ALLOT_QTY =
        (SELECT SUM(NVL(R.QUANTITY,0))  FROM
           T_SL_ALLOT_RESULT R,
           T_SL_ALLOT_BATCH  B
         WHERE R.ALLOT_BATCH_ID = B.ALLOT_BATCH_ID
         AND B.TO_BILL_FLAG='Y' AND R.ALLOT_ORDER_DETAIL_ID = D.ALLOT_ORDER_DETAIL_ID
        )
       WHERE EXISTS (SELECT (1) FROM T_SL_ALLOT_RESULT R
                   WHERE R.ALLOT_ORDER_DETAIL_ID = D.ALLOT_ORDER_DETAIL_ID
                   AND   R.ALLOT_BATCH_ID = IN_BATCH_ID
       );

       FOR ALLOT_ORDER_LINE_ROW IN (SELECT L.ALLOT_ORDER_LINE_ID,
                                           L.ITEM_ID,
                                           L.ITEM_CODE,
                                           L.QUANTITY,
                                           L.ALLOT_QTY
                FROM  T_SL_ALLOT_ORDER_LINE L
                WHERE EXISTS (
                  SELECT (1) FROM T_SL_ALLOT_ORDER_DETAIL DR,
                                  T_SL_ALLOT_RESULT RR
                  WHERE RR.ALLOT_ORDER_DETAIL_ID = DR.ALLOT_ORDER_DETAIL_ID
                  AND DR.ALLOT_ORDER_LINE_ID = L.ALLOT_ORDER_LINE_ID
                  AND RR.ALLOT_BATCH_ID =  IN_BATCH_ID
        ))
        LOOP
           BEGIN
                N_SET_K := 0;
                N_TEM_K := 0;
                N_SET_QUANTITY :=0;
                FOR ALLOT_DETAIL_RELA_ROW IN (
                      SELECT DR.QUANTITY,
                             DR.ALLOT_QTY,
                             DR.ASS_QTY
                      FROM T_SL_ALLOT_ORDER_DETAIL DR
                      WHERE DR.ALLOT_ORDER_LINE_ID = ALLOT_ORDER_LINE_ROW.ALLOT_ORDER_LINE_ID
                 )
                 LOOP
                    BEGIN
                         IF ALLOT_DETAIL_RELA_ROW.ASS_QTY = 0 THEN
                            EXIT;
                         ELSE
                            BEGIN
                              IF N_TEM_K = 0 THEN
                                N_SET_QUANTITY := NVL(ALLOT_DETAIL_RELA_ROW.ALLOT_QTY,0)/ALLOT_DETAIL_RELA_ROW.ASS_QTY;
                                N_TEM_K := 1;
                              END IF;
                              N_SET_QUANTITY_TEM := NVL(ALLOT_DETAIL_RELA_ROW.ALLOT_QTY,0)/ALLOT_DETAIL_RELA_ROW.ASS_QTY;
                              IF N_SET_QUANTITY <> N_SET_QUANTITY_TEM THEN
                                       OS_MESSAGE := '分配结果存在套机不配套['||ALLOT_ORDER_LINE_ROW.ITEM_CODE||']';
                                       N_SET_K := 1;
                                       
                                       RETURN;
                              END IF;
                            END;
                           END IF;
                     END;
                 END LOOP;


                 IF N_SET_K = 0 THEN
                        UPDATE T_SL_ALLOT_ORDER_LINE
                        SET    ALLOT_QTY = N_SET_QUANTITY,
                               LAST_UPDATED_BY = IS_USER_ACCOUNT,
                               LAST_UPDATE_DATE = SYSDATE
                        WHERE ALLOT_ORDER_LINE_ID=ALLOT_ORDER_LINE_ROW.ALLOT_ORDER_LINE_ID ;
                 END IF;
           END;
       END LOOP;


       --更新指令分库信息
       FOR ALLOT_ORDER_ROW IN (
              SELECT O.ALLOT_ORDER_ID,
                     SUM(NVL(D.ALLOT_QTY,0)) ALLOT_QTY,
                     SUM(NVL(D.ADD_QTY,0))   ADD_QTY,
                     SUM(NVL(D.QUANTITY,0))  QUANTITY,
                     SUM(NVL(D.CANCEL_QTY,0)) CANCEL_QTY,
                     SUM(NVL(D.ALLOT_CANCEL_QTY,0)) ALLOT_CANCEL_QTY
              FROM T_SL_ALLOT_ORDER O,
                            T_SL_ALLOT_ORDER_DETAIL D
               WHERE O.ALLOT_ORDER_ID = D.ALLOT_ORDER_ID
               AND   EXISTS (SELECT (1) FROM
                             T_SL_ALLOT_RESULT RR
                             WHERE   RR.ALLOT_ORDER_ID = O.ALLOT_ORDER_ID
                             AND     RR.ALLOT_BATCH_ID = IN_BATCH_ID
               )
               GROUP BY O.ALLOT_ORDER_ID
        )
        LOOP
          BEGIN
               N_NEED_QUANTITY := (ALLOT_ORDER_ROW.QUANTITY + ALLOT_ORDER_ROW.ADD_QTY - ALLOT_ORDER_ROW.CANCEL_QTY+ALLOT_ORDER_ROW.ALLOT_CANCEL_QTY);
               IF    N_NEED_QUANTITY  = ALLOT_ORDER_ROW.ALLOT_QTY    THEN
                   UPDATE　T_SL_ALLOT_ORDER set
                           STATUS = 'ALLOTED',
                           ALLOTED_FLAG='Y',
                           ALLOTED_DATE=SYSDATE,
                           LAST_UPDATED_BY=IS_USER_ACCOUNT,
                           LAST_UPDATE_DATE=SYSDATE
                    WHERE  ALLOT_ORDER_ID= ALLOT_ORDER_ROW.ALLOT_ORDER_ID;
               ELSIF  N_NEED_QUANTITY > ALLOT_ORDER_ROW.ALLOT_QTY AND  ALLOT_ORDER_ROW.ALLOT_QTY>0 THEN
                   UPDATE T_SL_ALLOT_ORDER　SET
                           STATUS = 'ALLOTING',
                           ALLOTED_FLAG='N',
                           ALLOTED_DATE=null,
                           LAST_UPDATED_BY=IS_USER_ACCOUNT,
                           LAST_UPDATE_DATE=SYSDATE
                    WHERE  ALLOT_ORDER_ID= ALLOT_ORDER_ROW.ALLOT_ORDER_ID;
               END IF;
          EXCEPTION
               WHEN OTHERS THEN
               OS_MESSAGE := SUBSTR(SQLERRM(SQLCODE), 1, 256);
               
               RETURN;
          END;
        END LOOP;
        --自动审核

        FOR j IN 1 .. N_BILL_HEADER_ARRAY.COUNT LOOP
             P_ALLOT_BILL_CHECK(N_BILL_HEADER_ARRAY(j),ID_BILLDATE,IS_USER_ACCOUNT,S_CHILD_MESSAGE);
             IF S_CHILD_MESSAGE<>'OK' THEN
               OS_MESSAGE := S_CHILD_MESSAGE;
               
               RETURN;
             END IF;
        END LOOP;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        NULL;
      WHEN OTHERS THEN
        OS_MESSAGE := SUBSTR(SQLERRM(SQLCODE), 1, 256);
        
    END P_ALLOT_RESULT_TO_BILL;


  ------------------------------------------------------------------------------
  ---   功能描述： 更新库位现有量                                  ---
  ------------------------------------------------------------------------------
 PROCEDURE P_UPDATE_ONHAND(
                     IN_BILL_HEADER_ID IN  NUMBER, --库位单ID
                     IS_USER_ACCOUNT   IN  VARCHAR2, --用户
                     IN_STATE          IN  NUMBER, --更新状态 1 确认 更新库位实存数 2 审核 更新库位账面数
                     OS_MESSAGE        OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
 )IS
          S_NEGATIVE_FLAG VARCHAR2(100);
          S_ACTION_TYPE   VARCHAR2(100);
          S_CANCEL_FLAG   VARCHAR2(100);
          N_ACCOUNT_QTY   NUMBER;
          S_ITEM_CODE     VARCHAR2(100);
          LOCATION_CODE   VARCHAR2(100);
		  ITEM_BATCH      VARCHAR2(100);
    BEGIN
          OS_MESSAGE        := 'OK';
          
          BEGIN 
	           SELECT BT.NEGATIVE_INVENTORY_FLAG,
			          TT.ACTION_TYPE, 
			          H.CANCEL_FLAG
			   INTO   S_NEGATIVE_FLAG,  
			          S_ACTION_TYPE,
			          S_CANCEL_FLAG            
			   FROM T_INV_BILL_TYPES BT,
			        T_INV_SOURCE_TYPES ST ,
			        T_INV_TRANSACTION_TYPES TT,
			        T_SL_BILL_HEADER H
			   WHERE  BT.SOURCE_TYPE_ID = ST.SOURCE_TYPE_ID 
			   AND    BT.TRANSACTION_TYPE_ID = TT.TRANSACTION_TYPE_ID 
			   AND    BT.BILL_TYPE_ID = H.BILL_TYPE_ID
			   AND    H.BILL_HEADER_ID = IN_BILL_HEADER_ID
			   AND ROWNUM=1;
          EXCEPTION
	        WHEN NO_DATA_FOUND THEN
	          OS_MESSAGE := '库位单单据类型数据不完整';
	          RETURN;
	          WHEN OTHERS THEN
		      OS_MESSAGE := SUBSTR(SQLERRM(SQLCODE), 1, 256);
		      RETURN;
		  END; 
          
          --确认
          IF IN_STATE = 1 THEN
                --入库数
                MERGE INTO T_SL_ONHAND O
                USING (SELECT
                           SUM(H.REV_INV_SIGN*NVL(L.AFFIRM_QTY,0)) AFFIRM_QTY,
                           L.REV_LOCATION_ID,
                           L.ITEM_ID,
                           H.ENTITY_ID,
                           L.REV_ITEM_BATCH,
                           L.REV_ITEM_STATUS ITEM_STATUS,
                           H.REV_INV_ID FACT_INV_ID
                        FROM T_SL_BILL_LINE L,
                             T_SL_BILL_HEADER H
                        WHERE H.BILL_HEADER_ID = L.BILL_HEADER_ID AND
                              L.REV_LOCATION_ID IS NOT NULL AND
                              L.BILL_HEADER_ID=IN_BILL_HEADER_ID
                        GROUP BY L.REV_LOCATION_ID,
                                 L.ITEM_ID,
                                 H.ENTITY_ID,
                                 L.REV_ITEM_BATCH,
                                 L.REV_ITEM_STATUS,
                                 H.REV_INV_ID ) B

                ON (B.REV_LOCATION_ID = O.LOCATION_ID
                AND B.ITEM_ID = O.ITEM_ID
                AND B.ENTITY_ID=O.ENTITY_ID
                AND B.REV_ITEM_BATCH = O.ITEM_BATCH 
                AND B.ITEM_STATUS = O.ITEM_STATUS 
                )
                WHEN MATCHED THEN
                        UPDATE SET O.FACT_QTY = (O.FACT_QTY+B.AFFIRM_QTY),O.LAST_UPDATED_BY = IS_USER_ACCOUNT,
                                                 O.LAST_UPDATE_DATE= SYSDATE
                WHEN NOT MATCHED THEN
                       INSERT (ONHAND_ID,LOCATION_ID,FACT_INV_ID,ENTITY_ID,
                              ITEM_ID, ITEM_STATUS, ITEM_BATCH, ACCOUNT_QTY,
                              FACT_QTY, CREATED_BY,CREATION_DATE,LAST_UPDATED_BY,LAST_UPDATE_DATE)
                        VALUES (S_SL_ONHAND.NEXTVAL,B.REV_LOCATION_ID, B.FACT_INV_ID, B.ENTITY_ID,
                                B.ITEM_ID,B.ITEM_STATUS,B.REV_ITEM_BATCH,0,B.AFFIRM_QTY,
                                IS_USER_ACCOUNT,SYSDATE,IS_USER_ACCOUNT,SYSDATE);

                 --出库数
                MERGE INTO T_SL_ONHAND O
                USING (SELECT
                           SUM(H.SEND_INV_SIGN*NVL(L.AFFIRM_QTY,0)) AFFIRM_QTY,
                           L.SEND_LOCATION_ID,
                           L.ITEM_ID,
                           H.ENTITY_ID,
                           L.SEND_ITEM_BATCH,
                           L.SEND_ITEM_STATUS ITEM_STATUS,
                           H.SEND_INV_ID  FACT_INV_ID
                        FROM T_SL_BILL_LINE L,
                             T_SL_BILL_HEADER H 
                        WHERE H.BILL_HEADER_ID = L.BILL_HEADER_ID AND
                              L.SEND_LOCATION_ID IS NOT NULL AND
                              L.BILL_HEADER_ID=IN_BILL_HEADER_ID
                        GROUP BY L.SEND_LOCATION_ID,
                                 L.ITEM_ID,
                                 H.ENTITY_ID,
                                 L.SEND_ITEM_BATCH,
                                 L.SEND_ITEM_STATUS,
                                 H.SEND_INV_ID ) B
                ON (B.SEND_LOCATION_ID = O.LOCATION_ID
                AND B.ITEM_ID = O.ITEM_ID
                AND B.ENTITY_ID=O.ENTITY_ID
                AND B.SEND_ITEM_BATCH = O.ITEM_BATCH 
                AND B.ITEM_STATUS = O.ITEM_STATUS 
                )
                WHEN MATCHED THEN
                        UPDATE SET O.FACT_QTY = (O.FACT_QTY+B.AFFIRM_QTY),O.LAST_UPDATED_BY = IS_USER_ACCOUNT,
                                                 O.LAST_UPDATE_DATE= SYSDATE
                WHEN NOT MATCHED THEN
                       INSERT (ONHAND_ID,LOCATION_ID,FACT_INV_ID,ENTITY_ID,
                              ITEM_ID,ITEM_STATUS,ITEM_BATCH,ACCOUNT_QTY,
                              FACT_QTY,CREATED_BY,CREATION_DATE,LAST_UPDATED_BY,LAST_UPDATE_DATE)
                        VALUES (S_SL_ONHAND.NEXTVAL,B.SEND_LOCATION_ID,B.FACT_INV_ID,B.ENTITY_ID,
                                B.ITEM_ID,B.ITEM_STATUS,B.SEND_ITEM_BATCH,0,B.AFFIRM_QTY,
                                IS_USER_ACCOUNT,SYSDATE,IS_USER_ACCOUNT,SYSDATE);
             ---审核
            ELSE
                --入库数
                MERGE INTO T_SL_ONHAND O
                USING (SELECT
                           L.REV_LOCATION_ID,
                           SUM(H.REV_INV_SIGN*NVL(L.QUANTITY,0)) QUANTITY,
                           L.ITEM_ID,
                           H.ENTITY_ID,
                           L.REV_ITEM_BATCH,
                           L.REV_ITEM_STATUS ITEM_STATUS,
                           H.REV_INV_ID FACT_INV_ID
                        FROM T_SL_BILL_LINE L,
                             T_SL_BILL_HEADER H
                        WHERE H.BILL_HEADER_ID = L.BILL_HEADER_ID AND
                              L.REV_LOCATION_ID IS NOT NULL AND
                              L.BILL_HEADER_ID=IN_BILL_HEADER_ID
                        GROUP BY L.REV_LOCATION_ID,
                                 L.ITEM_ID,
                                 H.ENTITY_ID,
                                 L.REV_ITEM_BATCH,
                                 L.REV_ITEM_STATUS,
                                 H.REV_INV_ID ) B
                ON (B.REV_LOCATION_ID = O.LOCATION_ID
                AND B.ITEM_ID = O.ITEM_ID
                AND B.ENTITY_ID=O.ENTITY_ID
                AND B.REV_ITEM_BATCH = O.ITEM_BATCH 
                AND B.ITEM_STATUS = O.ITEM_STATUS 
                )
                WHEN MATCHED THEN
                        UPDATE SET O.ACCOUNT_QTY = (O.ACCOUNT_QTY+B.QUANTITY),O.LAST_UPDATED_BY = IS_USER_ACCOUNT,
                                                 O.LAST_UPDATE_DATE= SYSDATE
                WHEN NOT MATCHED THEN
                       INSERT (ONHAND_ID,LOCATION_ID, FACT_INV_ID, ENTITY_ID,
                              ITEM_ID, ITEM_STATUS, ITEM_BATCH, ACCOUNT_QTY,
                              FACT_QTY, CREATED_BY,CREATION_DATE,LAST_UPDATED_BY,LAST_UPDATE_DATE)
                        VALUES (S_SL_ONHAND.NEXTVAL,B.REV_LOCATION_ID, B.FACT_INV_ID, B.ENTITY_ID,
                                B.ITEM_ID,B.ITEM_STATUS,B.REV_ITEM_BATCH,B.QUANTITY,0,
                                IS_USER_ACCOUNT,SYSDATE,IS_USER_ACCOUNT,SYSDATE);


                 --出库数
                MERGE INTO T_SL_ONHAND O
                USING (SELECT
                           SUM(H.SEND_INV_SIGN*NVL(L.QUANTITY,0)) QUANTITY,
                           L.SEND_LOCATION_ID,
                           L.ITEM_ID,
                           H.ENTITY_ID,
                           L.SEND_ITEM_BATCH,
                           L.SEND_ITEM_STATUS ITEM_STATUS,
                           H.SEND_INV_ID  FACT_INV_ID
                        FROM T_SL_BILL_LINE L,
                             T_SL_BILL_HEADER H
                        WHERE H.BILL_HEADER_ID = L.BILL_HEADER_ID AND
                              L.SEND_LOCATION_ID IS NOT NULL AND
                              L.BILL_HEADER_ID=IN_BILL_HEADER_ID
                        GROUP BY L.SEND_LOCATION_ID,
                                 L.ITEM_ID,
                                 H.ENTITY_ID,
                                 L.SEND_ITEM_BATCH,
                                 L.SEND_ITEM_STATUS,
                                 H.SEND_INV_ID ) B
                ON (B.SEND_LOCATION_ID = O.LOCATION_ID
                AND B.ITEM_ID = O.ITEM_ID
                AND B.ENTITY_ID=O.ENTITY_ID
                AND B.SEND_ITEM_BATCH = O.ITEM_BATCH
                AND B.ITEM_STATUS = O.ITEM_STATUS 
                )
                WHEN MATCHED THEN
                        UPDATE SET O.ACCOUNT_QTY = (O.ACCOUNT_QTY+B.QUANTITY),O.LAST_UPDATED_BY = IS_USER_ACCOUNT,
                                                 O.LAST_UPDATE_DATE= SYSDATE
                WHEN NOT MATCHED THEN
                       INSERT (ONHAND_ID,LOCATION_ID, FACT_INV_ID, ENTITY_ID,
                              ITEM_ID, ITEM_STATUS, ITEM_BATCH, ACCOUNT_QTY,
                              FACT_QTY, CREATED_BY,CREATION_DATE,LAST_UPDATED_BY,LAST_UPDATE_DATE)
                        VALUES (S_SL_ONHAND.NEXTVAL,B.SEND_LOCATION_ID, B.FACT_INV_ID, B.ENTITY_ID,
                                B.ITEM_ID,B.ITEM_STATUS,B.SEND_ITEM_BATCH,B.QUANTITY,0,
                                IS_USER_ACCOUNT,SYSDATE,IS_USER_ACCOUNT,SYSDATE);
            END IF;
            --删除为0库位存量
              DELETE FROM T_SL_ONHAND WHERE ACCOUNT_QTY =0 AND FACT_QTY=0;
              
            --负库存判断 
            IF S_NEGATIVE_FLAG='N' and S_ACTION_TYPE<>'01'  THEN   
                  IF (S_ACTION_TYPE='02' or S_ACTION_TYPE='03') and S_CANCEL_FLAG='N' THEN
                          BEGIN
					            SELECT D.ACCOUNT_QTY,
							            L.ITEM_CODE,
							            L.SEND_LOCATION_CODE,
							            L.SEND_ITEM_BATCH
							    INTO
							           N_ACCOUNT_QTY,
							           S_ITEM_CODE,
							           LOCATION_CODE,
							           ITEM_BATCH 	
					            FROM T_SL_ONHAND D,
					                 T_SL_BILL_LINE L,
					                 T_SL_BILL_HEADER H		                
								 WHERE H.BILL_HEADER_ID = L.BILL_HEADER_ID
								 AND   H.ENTITY_ID = D.ENTITY_ID
								 AND   D.LOCATION_ID = L.SEND_LOCATION_ID
								 AND   D.ITEM_ID = L.ITEM_ID
								 AND   D.ITEM_BATCH = L.SEND_ITEM_BATCH
								 AND   H.BILL_HEADER_ID = IN_BILL_HEADER_ID
								 AND   D.ACCOUNT_QTY <0  AND ROWNUM=1;
								 IF N_ACCOUNT_QTY IS NOT NULL AND N_ACCOUNT_QTY<0 THEN 
								      OS_MESSAGE := '库存不足：[库位：'||LOCATION_CODE||'批次：'||ITEM_BATCH||'产品：'||S_ITEM_CODE||']';
								      RETURN;
								 END IF;  
					       EXCEPTION
					            WHEN NO_DATA_FOUND THEN
					                NULL;
					       END;
                   END IF; 
                   IF (S_ACTION_TYPE='02' or S_ACTION_TYPE='03') and S_CANCEL_FLAG='Y' THEN
                          BEGIN
					            SELECT  D.ACCOUNT_QTY,
							            L.ITEM_CODE,
							            L.REV_LOCATION_CODE,
							            L.REV_ITEM_BATCH
							   INTO
							           N_ACCOUNT_QTY,
							           S_ITEM_CODE,
							           LOCATION_CODE,
							           ITEM_BATCH 	          
					            FROM T_SL_ONHAND D,
					                 T_SL_BILL_LINE L,
					                 T_SL_BILL_HEADER H		                
								 WHERE H.BILL_HEADER_ID = L.BILL_HEADER_ID
								 AND   H.ENTITY_ID = D.ENTITY_ID
								 AND   D.LOCATION_ID = L.REV_LOCATION_ID
								 AND   D.ITEM_ID = L.ITEM_ID
								 AND   D.ITEM_BATCH = L.REV_ITEM_BATCH
								 AND   H.BILL_HEADER_ID = IN_BILL_HEADER_ID
								 AND   D.ACCOUNT_QTY <0  AND ROWNUM=1;
								 IF N_ACCOUNT_QTY IS NOT NULL AND N_ACCOUNT_QTY<0 THEN 
								      OS_MESSAGE := '库存不足：[库位：'||LOCATION_CODE||'批次：'||ITEM_BATCH||'产品：'||S_ITEM_CODE||']';
								      RETURN;
								 END IF;  
					       EXCEPTION
					            WHEN NO_DATA_FOUND THEN
					                NULL;
					       END;
                   END IF;    
            END IF;  

    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        NULL;
      WHEN OTHERS THEN
        OS_MESSAGE := SUBSTR(SQLERRM(SQLCODE), 1, 256);
        
  END P_UPDATE_ONHAND;

  ------------------------------------------------------------------------------
  ---  功能描述： 确认库位单               ---
  ------------------------------------------------------------------------------
  PROCEDURE P_ALLOT_BILL_AFFIRM(
                               IN_BILL_HEADER_ID IN  NUMBER,  --库位单ID
                               ID_BILLDATE       IN  DATE,     --确认日期
                               IS_USER_ACCOUNT   IN  VARCHAR2,--用户ID
                               OS_REMARK         OUT VARCHAR2, --返回库位单备注信息
                               OS_MESSAGE        OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
 )IS
      S_BILL_STATUS_CHECKED T_SL_BILL_HEADER.BILL_STATUS%TYPE;
      S_MESSAGE_CHILD VARCHAR2(2000);
      S_BILL_STATUS   VARCHAR2(200);
      S_SOURCETYPE    VARCHAR2(200);
      N_SOURCE_BILL_ID NUMBER;
      S_MESSAGE_SHIP  VARCHAR2(2000);
      S_MESSAGE_SO_SHIP  VARCHAR2(2000);
      S_MESSAGE_SO    VARCHAR2(2000);
      S_CANCEL_FLAG    VARCHAR2(200);
      N_P_RESULT_SO   NUMBER;
      S_MESSAGE_RETURN  VARCHAR2(2000);
      N_INVENTORY_ID  NUMBER;
      S_SO_NUM  VARCHAR2(500);
      S_BILLNUMBER  VARCHAR2(500);
      
       N_SET_QUANTITY     NUMBER;
       N_TEM_K            NUMBER;
       N_SET_QUANTITY_TEM NUMBER;
       N_SET_K            NUMBER;
       N_NEED_QUANTITY    NUMBER;
       
       N_ALLOT_ORDER_ID  NUMBER;
       N_ALLOT_ORDER_ID_OLD  NUMBER;
       
       S_P_RESULT_SO_STATE   VARCHAR2(200);
       S_MESSAGE_SO_MSG  VARCHAR2(200);
      
    BEGIN
      OS_MESSAGE        := 'OK';
      S_BILL_STATUS_CHECKED := 'AFFRIMED';
      OS_REMARK :='';

      --锁定库位单,获取库位单状态
      BEGIN
        SELECT
          BILL_STATUS,
          SOURCE_TYPE,
          SOURCE_BILL_ID,
          BILL_NUMBER,
          CANCEL_FLAG,
          ALLOT_ORDER_ID
        INTO
          S_BILL_STATUS,
          S_SOURCETYPE,
          N_SOURCE_BILL_ID,
          S_BILLNUMBER,
          S_CANCEL_FLAG,
          N_ALLOT_ORDER_ID
        FROM
          T_SL_BILL_HEADER
        WHERE
          BILL_HEADER_ID = IN_BILL_HEADER_ID
        FOR UPDATE NOWAIT;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          OS_MESSAGE := '锁定库位单不成功！请稍后再试。';
          RETURN;
      END;
      
       --锁定分库指令
       BEGIN
       
        IF  N_ALLOT_ORDER_ID IS NOT NULL THEN
	        SELECT
	          ALLOT_ORDER_ID
	        INTO 
	          N_ALLOT_ORDER_ID_OLD   
	        FROM
	          T_SL_ALLOT_ORDER
	        WHERE
	           ALLOT_ORDER_ID = N_ALLOT_ORDER_ID
	           AND ROWNUM = 1
	        FOR UPDATE NOWAIT;
        END IF;
        
      EXCEPTION
        WHEN OTHERS THEN
          OS_MESSAGE := '锁定分库指令不成功！请稍后再试。';
          RETURN;
          
          
      END;
      

      IF S_BILL_STATUS = S_BILL_STATUS_CHECKED THEN
          OS_MESSAGE := '库位单已经被确认了，不能再次确认';
          RETURN;
      END IF;
      IF S_BILL_STATUS = 'DISCARDED' THEN
          OS_MESSAGE := '库位单已经被作废了，不能确认';
          RETURN;
      END IF;

      --更新库位状态
      UPDATE T_SL_BILL_HEADER SET BILL_STATUS = S_BILL_STATUS_CHECKED,
                                  AFFIRM_BY = IS_USER_ACCOUNT,
                                  AFFIRM_DATE = ID_BILLDATE,
                                  LAST_UPDATED_BY = IS_USER_ACCOUNT,
                                  LAST_UPDATE_DATE= SYSDATE
      WHERE  BILL_HEADER_ID = IN_BILL_HEADER_ID;
      --更新库位单行确认数量
      UPDATE T_SL_BILL_LINE
      SET AFFIRM_QTY = QUANTITY
      WHERE BILL_HEADER_ID=IN_BILL_HEADER_ID;

      UPDATE T_SL_ALLOT_ORDER_DETAIL B
      SET  ALLOT_AFFIRM_QTY =(SELECT  SUM(CASE WHEN H.CANCEL_FLAG='N' THEN L.AFFIRM_QTY  
	                                           WHEN H.CANCEL_FLAG='Y' THEN -1*NVL(L.AFFIRM_QTY,0)
	                                           ELSE 0
                                      END)      
                             FROM T_SL_BILL_LINE L,T_SL_BILL_HEADER H
                             WHERE B.ALLOT_ORDER_DETAIL_ID= L.ALLOT_ORDER_DETAIL_ID
                             AND   L.BILL_HEADER_ID = H.BILL_HEADER_ID
                             AND   H.BILL_STATUS = S_BILL_STATUS_CHECKED )                    
       WHERE EXISTS (SELECT 1 FROM T_SL_BILL_LINE A,
                                   T_SL_BILL_HEADER C
                     WHERE  A.BILL_HEADER_ID = C.BILL_HEADER_ID
                     AND    A.ALLOT_ORDER_DETAIL_ID=B.ALLOT_ORDER_DETAIL_ID
                     AND    A.BILL_HEADER_ID=IN_BILL_HEADER_ID);
                     
      --更新分库指令行 确认数量
      FOR ALLOT_ORDER_LINE_ROW IN (SELECT L.ALLOT_ORDER_LINE_ID,
                                          L.ITEM_ID,
                                          L.ITEM_CODE,
                                          L.QUANTITY,
                                          L.ALLOT_QTY
				                FROM  T_SL_ALLOT_ORDER_LINE L
				                WHERE EXISTS (
				                  SELECT (1) FROM T_SL_ALLOT_ORDER_DETAIL DR,
				                                  T_SL_BILL_LINE RR
				                  WHERE RR.ALLOT_ORDER_DETAIL_ID = DR.ALLOT_ORDER_DETAIL_ID
				                  AND DR.ALLOT_ORDER_LINE_ID = L.ALLOT_ORDER_LINE_ID
				                  AND RR.BILL_HEADER_ID =  IN_BILL_HEADER_ID
        ))
        LOOP
           BEGIN
                N_SET_K := 0;
                N_TEM_K := 0;
                N_SET_QUANTITY :=0;
                FOR ALLOT_DETAIL_RELA_ROW IN (
                      SELECT DR.QUANTITY,
                             DR.ALLOT_QTY,
                             DR.CANCEL_QTY,
                             DR.ASS_QTY,
                             DR.ALLOT_CANCEL_QTY,
                             DR.ALLOT_AFFIRM_QTY
                      FROM T_SL_ALLOT_ORDER_DETAIL DR
                      WHERE DR.ALLOT_ORDER_LINE_ID = ALLOT_ORDER_LINE_ROW.ALLOT_ORDER_LINE_ID
                 )
                 LOOP
                    BEGIN
                         IF ALLOT_DETAIL_RELA_ROW.ASS_QTY = 0 THEN
                            EXIT;
                         ELSE
                            BEGIN
                              IF N_TEM_K = 0 THEN
                                N_SET_QUANTITY := NVL(ALLOT_DETAIL_RELA_ROW.ALLOT_AFFIRM_QTY,0)/ALLOT_DETAIL_RELA_ROW.ASS_QTY;
                                N_TEM_K := 1;
                              END IF;
                              N_SET_QUANTITY_TEM := NVL(ALLOT_DETAIL_RELA_ROW.ALLOT_AFFIRM_QTY,0)/ALLOT_DETAIL_RELA_ROW.ASS_QTY;
                              IF N_SET_QUANTITY_TEM > N_SET_QUANTITY THEN
                                  N_SET_QUANTITY := N_SET_QUANTITY_TEM;
                              END IF;
                            END;
                          END IF;
                     END;
                 END LOOP;

                 IF N_SET_K = 0 THEN
                        UPDATE T_SL_ALLOT_ORDER_LINE
                        SET    ALLOT_AFFIRM_QTY = N_SET_QUANTITY,
                               LAST_UPDATED_BY = IS_USER_ACCOUNT,
                               LAST_UPDATE_DATE = SYSDATE
                        WHERE ALLOT_ORDER_LINE_ID=ALLOT_ORDER_LINE_ROW.ALLOT_ORDER_LINE_ID ;
                 END IF;
           END;
        END LOOP;   

      --更新库位现有量 实存数量
      P_UPDATE_ONHAND(IN_BILL_HEADER_ID,IS_USER_ACCOUNT,1,S_MESSAGE_CHILD);

      IF S_MESSAGE_CHILD <> 'OK' THEN
         OS_MESSAGE     := S_MESSAGE_CHILD;
         
         RETURN;
      END IF;

      --待做  回调其他业务  如调拨单
      IF S_SOURCETYPE = 'SHIP_DOC' and S_CANCEL_FLAG='N' THEN
           BEGIN
            SELECT CONSIGNEE_INVENTORY_ID
            INTO N_INVENTORY_ID
            FROM T_LG_SHIP_DOC
            WHERE SHIP_DOC_ID = N_SOURCE_BILL_ID
            AND ROWNUM = 1;
            IF N_INVENTORY_ID IS NULL THEN --销售
            	 P_TO_ACTUAL_SHIP(IN_BILL_HEADER_ID,IS_USER_ACCOUNT,S_MESSAGE_SO_SHIP);
            	 IF S_MESSAGE_SO_SHIP <> 'OK' THEN
		                  OS_MESSAGE     := S_MESSAGE_SO_SHIP;
		                  
		                  RETURN;
			     END IF; 
                 FOR N_ACTUAL_ID IN(
			         SELECT ACTUAL_SHIP_ID 
			         FROM  T_LG_ACTUAL_SHIP 
                     WHERE SOURCE_TYPE ='SL_BILL' 
			         AND SOURCE_BILL_ID=IN_BILL_HEADER_ID)
			       LOOP
			        BEGIN
			            --调用销售
			            PKG_SO_BIZ.P_SO_ENTRY_SHIP(N_ACTUAL_ID.ACTUAL_SHIP_ID,IS_USER_ACCOUNT,N_P_RESULT_SO,S_MESSAGE_SO);
			            IF N_P_RESULT_SO < 0 THEN
			                  OS_MESSAGE     := S_MESSAGE_SO;
                              RETURN;
			            END IF;  
			            --回写数量
			            PKG_LG_CONTRACT.P_SHIP_CONFIRM(N_ACTUAL_ID.ACTUAL_SHIP_ID,IS_USER_ACCOUNT,S_P_RESULT_SO_STATE,S_MESSAGE_SO_MSG);
			            IF S_P_RESULT_SO_STATE = '0' THEN
			                   OS_MESSAGE     := S_MESSAGE_SO_MSG;
                               RETURN;
			            END IF;  
			             
			            

			        END;
			      END LOOP;
			      S_SO_NUM := PKG_SO_BIZ.F_GET_SO_NUM_BY_SRCTYPE('SL_BILL',S_BILLNUMBER);
			      UPDATE T_SL_BILL_HEADER SET  REMARK = nvl(REMARK,'')||S_SO_NUM WHERE BILL_HEADER_ID=IN_BILL_HEADER_ID;
			      OS_REMARK := S_SO_NUM;
			      
            ELSE --调拨
                P_TO_ACTUAL_SHIP(IN_BILL_HEADER_ID,IS_USER_ACCOUNT,S_MESSAGE_SHIP);
                IF S_MESSAGE_SHIP <> 'OK' THEN
		                  OS_MESSAGE    := S_MESSAGE_SHIP;  
		                  RETURN;
			    END IF; 
                FOR N_ACTUAL_ID IN(
			         SELECT ACTUAL_SHIP_ID 
			         FROM  T_LG_ACTUAL_SHIP 
                     WHERE SOURCE_TYPE ='SL_BILL' 
			         AND SOURCE_BILL_ID=IN_BILL_HEADER_ID)
			       LOOP
			        BEGIN
			            --回写数量
			            PKG_LG_CONTRACT.P_SHIP_CONFIRM(N_ACTUAL_ID.ACTUAL_SHIP_ID,IS_USER_ACCOUNT,S_P_RESULT_SO_STATE,S_MESSAGE_SO_MSG);
			            IF S_P_RESULT_SO_STATE = '0' THEN
			                   OS_MESSAGE     := S_MESSAGE_SO_MSG;
                               RETURN;
			            END IF; 
			            
                    END;
			      END LOOP;
                
            END IF;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
               null;
        END;
      END IF;
      IF S_SOURCETYPE = 'RETURN_APPLY' and S_CANCEL_FLAG='N' THEN--销售退货
           P_TO_RETURN_RECEIVE(IN_BILL_HEADER_ID,IS_USER_ACCOUNT,S_MESSAGE_RETURN);
           IF S_MESSAGE_RETURN <> 'OK' THEN
             OS_MESSAGE     := S_MESSAGE_RETURN;
             
             RETURN;
           END IF;
      END IF;

    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        OS_MESSAGE     := 'OK';
        RETURN;
      WHEN OTHERS THEN
        OS_MESSAGE := SUBSTR(SQLERRM(SQLCODE), 1, 256);
        
    END P_ALLOT_BILL_AFFIRM;

  ------------------------------------------------------------------------------
  ---  功能描述： 审核库位单               ---
  ------------------------------------------------------------------------------
  PROCEDURE P_ALLOT_BILL_CHECK(
                               IN_BILL_HEADER_ID IN  NUMBER,  --库位单ID
                               ID_BILLDATE       IN  DATE,     --审核日期
                               IS_USER_ACCOUNT   IN  VARCHAR2,--用户账号
                               OS_MESSAGE        OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
   )IS
      S_BILL_STATUS_CHECKED T_SL_BILL_HEADER.BILL_STATUS%TYPE;
      S_MESSAGE_CHILD VARCHAR2(200);
      S_BILL_STATUS VARCHAR2(200);
      S_CANCEL_FLAG VARCHAR2(2);
      S_ACTION_TYPE VARCHAR2(10);
      S_OLD_BILL_NUMBER VARCHAR2(32);
      
      N_SET_QUANTITY     NUMBER;
      N_TEM_K            NUMBER;
      N_SET_QUANTITY_TEM NUMBER;
      N_SET_K            NUMBER;
      N_NEED_QUANTITY    NUMBER;

      N_REV_INV_SIGN    NUMBER;
      N_SEND_INV_SIGN   NUMBER;  
      
      N_REV_INV_ID      NUMBER; 
      N_SEND_INV_ID     NUMBER;     
      
       N_ALLOT_ORDER_ID_OLD  NUMBER;
       N_ALLOT_ORDER_ID  NUMBER;     
      
    BEGIN
      OS_MESSAGE        := 'OK';
      S_BILL_STATUS_CHECKED := 'CHECKED';
      

       --锁定库位单,获取库位单状态
     BEGIN
        SELECT
          H.BILL_STATUS,
          H.CANCEL_FLAG,
          H.OLD_BILL_NUMBER,
          TT.ACTION_TYPE,
          H.REV_INV_ID,
          H.SEND_INV_ID,
          H.ALLOT_ORDER_ID
        INTO
          S_BILL_STATUS,
          S_CANCEL_FLAG,
          S_OLD_BILL_NUMBER,
          S_ACTION_TYPE,
          N_REV_INV_ID,
          N_SEND_INV_ID,
          N_ALLOT_ORDER_ID
        FROM
          T_SL_BILL_HEADER H,
          T_INV_BILL_TYPES BT,
          T_INV_SOURCE_TYPES ST,
          T_INV_TRANSACTION_TYPES TT
        WHERE
          BT.BILL_TYPE_ID(+)  = H.BILL_TYPE_ID AND
	      BT.SOURCE_TYPE_ID = ST.SOURCE_TYPE_ID(+) AND
	      BT.TRANSACTION_TYPE_ID = TT.TRANSACTION_TYPE_ID(+) AND
          H.BILL_HEADER_ID = IN_BILL_HEADER_ID
          AND ROWNUM=1
        FOR UPDATE NOWAIT;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          OS_MESSAGE := '锁定库位单不成功！请稍后再试。';
          RETURN;
      END;
      
             --锁定分库指令
       BEGIN
       
        IF  N_ALLOT_ORDER_ID IS NOT NULL THEN
	        SELECT
	          ALLOT_ORDER_ID
	        INTO 
	          N_ALLOT_ORDER_ID_OLD
	        FROM
	          T_SL_ALLOT_ORDER
	        WHERE
	           ALLOT_ORDER_ID = N_ALLOT_ORDER_ID
	           AND ROWNUM = 1
	        FOR UPDATE NOWAIT;
        END IF;
        
      EXCEPTION
        WHEN OTHERS THEN
          OS_MESSAGE := '锁定分库指令不成功！请稍后再试。';
          RETURN;
      END;

      IF S_BILL_STATUS = S_BILL_STATUS_CHECKED THEN
          OS_MESSAGE := '库位单已经被审核了，不能再次审核';
          RETURN;
      END IF;
      IF S_BILL_STATUS = 'DISCARDED' THEN
          OS_MESSAGE := '库位单已经被作废了，不能审核';
          RETURN;
      END IF;
      IF S_BILL_STATUS = 'AFFRIMED' THEN
          OS_MESSAGE := '库位单已经被确认了，不能审核';
          RETURN;
      END IF;
      
      N_REV_INV_SIGN  := 0;
      N_SEND_INV_SIGN := 0;
      
      IF    S_ACTION_TYPE = '01'  and  N_REV_INV_ID is not null   THEN
             N_REV_INV_SIGN  := 1;
             N_SEND_INV_SIGN := 0;
      ELSIF  S_ACTION_TYPE = '02' and  N_REV_INV_ID is not null   THEN
             N_REV_INV_SIGN  := -1;
             N_SEND_INV_SIGN := 0;
      ELSIF  S_ACTION_TYPE = '02' and  N_SEND_INV_ID is not null   THEN
             N_REV_INV_SIGN  := 0;
             N_SEND_INV_SIGN := -1;   
      ELSIF  S_ACTION_TYPE = '01' and  N_SEND_INV_ID is not null   THEN
             N_REV_INV_SIGN  := 0;
             N_SEND_INV_SIGN := 1;        
      ELSIF  S_ACTION_TYPE = '03' and  S_CANCEL_FLAG ='N'   THEN
             N_REV_INV_SIGN  := 1;
             N_SEND_INV_SIGN := -1;         
      ELSIF  S_ACTION_TYPE = '03' and  S_CANCEL_FLAG ='Y'   THEN
             N_REV_INV_SIGN  := -1;
             N_SEND_INV_SIGN := 1;             
      END IF;
       
      --更新库位单状态
      UPDATE T_SL_BILL_HEADER SET BILL_STATUS = S_BILL_STATUS_CHECKED,
                                  CHECK_BY = IS_USER_ACCOUNT,
                                  REV_INV_SIGN=N_REV_INV_SIGN,
                                  SEND_INV_SIGN=N_SEND_INV_SIGN,
                                  CHECK_DATE = ID_BILLDATE,
                                  LAST_UPDATED_BY = IS_USER_ACCOUNT,
                                  LAST_UPDATE_DATE= SYSDATE
      WHERE  BILL_HEADER_ID = IN_BILL_HEADER_ID;
      
      
      --如果是红单，更新相应的指令明细表的取消数量
      IF S_CANCEL_FLAG = 'Y' THEN
         UPDATE T_SL_ALLOT_ORDER_DETAIL B
         SET  ALLOT_CANCEL_QTY =(SELECT SUM(NVL(L.QUANTITY,0))
                           FROM T_SL_BILL_LINE L,T_SL_BILL_HEADER H
                           WHERE B.ALLOT_ORDER_DETAIL_ID= L.ALLOT_ORDER_DETAIL_ID
                           AND   L.BILL_HEADER_ID = H.BILL_HEADER_ID
                           AND   H.CANCEL_FLAG = 'Y'
                           AND   H.BILL_STATUS IN ('CHECKED','AFFRIMED') )
          WHERE EXISTS (SELECT 1 FROM T_SL_BILL_LINE A,
                                     T_SL_BILL_HEADER C
                         WHERE  A.BILL_HEADER_ID = C.BILL_HEADER_ID
                         AND    A.ALLOT_ORDER_DETAIL_ID=B.ALLOT_ORDER_DETAIL_ID
                         AND    A.BILL_HEADER_ID=IN_BILL_HEADER_ID  );

           --更新分库指令行 取消数量
           FOR ALLOT_ORDER_LINE_ROW IN (SELECT L.ALLOT_ORDER_LINE_ID,
	                                           L.ITEM_ID,
	                                           L.ITEM_CODE,
	                                           L.QUANTITY,
	                                           L.ALLOT_QTY
					                FROM  T_SL_ALLOT_ORDER_LINE L
					                WHERE EXISTS (
					                  SELECT (1) FROM T_SL_ALLOT_ORDER_DETAIL DR,
					                                  T_SL_BILL_LINE RR
					                  WHERE RR.ALLOT_ORDER_DETAIL_ID = DR.ALLOT_ORDER_DETAIL_ID
					                  AND DR.ALLOT_ORDER_LINE_ID = L.ALLOT_ORDER_LINE_ID
					                  AND RR.BILL_HEADER_ID =  IN_BILL_HEADER_ID
	        ))
	        LOOP
	           BEGIN
	                N_SET_K := 0;
	                N_TEM_K := 0;
	                N_SET_QUANTITY :=0;
	                FOR ALLOT_DETAIL_RELA_ROW IN (
	                      SELECT DR.QUANTITY,
	                             DR.ALLOT_QTY,
	                             DR.CANCEL_QTY,
	                             DR.ASS_QTY,
	                             DR.ALLOT_CANCEL_QTY
	                      FROM T_SL_ALLOT_ORDER_DETAIL DR
	                      WHERE DR.ALLOT_ORDER_LINE_ID = ALLOT_ORDER_LINE_ROW.ALLOT_ORDER_LINE_ID
	                 )
	                 LOOP
	                    BEGIN
	                         IF ALLOT_DETAIL_RELA_ROW.ASS_QTY = 0 THEN
	                            EXIT;
	                         ELSE
	                            BEGIN
	                              IF N_TEM_K = 0 THEN
	                                N_SET_QUANTITY := NVL(ALLOT_DETAIL_RELA_ROW.ALLOT_CANCEL_QTY,0)/ALLOT_DETAIL_RELA_ROW.ASS_QTY;
	                                N_TEM_K := 1;
	                              END IF;
	                              N_SET_QUANTITY_TEM := NVL(ALLOT_DETAIL_RELA_ROW.ALLOT_CANCEL_QTY,0)/ALLOT_DETAIL_RELA_ROW.ASS_QTY;
	                              IF N_SET_QUANTITY_TEM <> N_SET_QUANTITY THEN
	                                   OS_MESSAGE := '红冲数量存在套机不配套['||ALLOT_ORDER_LINE_ROW.ITEM_CODE||']';
                                       N_SET_K := 1;
                                       RETURN;
	                              END IF;
	                            END;
	                          END IF;
	                     END;
	                 END LOOP;
	
	                 IF N_SET_K = 0 THEN
	                        UPDATE T_SL_ALLOT_ORDER_LINE
	                        SET    ALLOT_CANCEL_QTY = N_SET_QUANTITY,
	                               LAST_UPDATED_BY = IS_USER_ACCOUNT,
	                               LAST_UPDATE_DATE = SYSDATE
	                        WHERE ALLOT_ORDER_LINE_ID=ALLOT_ORDER_LINE_ROW.ALLOT_ORDER_LINE_ID ;
	                 END IF;
	           END;
	        END LOOP;
	        
	        --更新指令分库信息
	       FOR ALLOT_ORDER_ROW IN (
	              SELECT O.ALLOT_ORDER_ID,
	                     SUM(NVL(D.ALLOT_QTY,0)) ALLOT_QTY,
	                     SUM(NVL(D.ADD_QTY,0))   ADD_QTY,
	                     SUM(NVL(D.QUANTITY,0))  QUANTITY,
	                     SUM(NVL(D.CANCEL_QTY,0)) CANCEL_QTY,
	                     SUM(NVL(D.ALLOT_CANCEL_QTY,0)) ALLOT_CANCEL_QTY
	              FROM T_SL_ALLOT_ORDER O,
	                            T_SL_ALLOT_ORDER_DETAIL D
	               WHERE O.ALLOT_ORDER_ID = D.ALLOT_ORDER_ID
	               AND   EXISTS (SELECT (1) FROM
	                             T_SL_BILL_HEADER RR
	                             WHERE   RR.ALLOT_ORDER_ID = O.ALLOT_ORDER_ID
	                             AND     RR.BILL_HEADER_ID =  IN_BILL_HEADER_ID
	               )
	               GROUP BY O.ALLOT_ORDER_ID
	        )
	        LOOP
	          BEGIN
	               N_NEED_QUANTITY := (ALLOT_ORDER_ROW.QUANTITY + ALLOT_ORDER_ROW.ADD_QTY - ALLOT_ORDER_ROW.CANCEL_QTY+ALLOT_ORDER_ROW.ALLOT_CANCEL_QTY);
	               IF   N_NEED_QUANTITY  = ALLOT_ORDER_ROW.ALLOT_QTY    THEN
	                   UPDATE　T_SL_ALLOT_ORDER set
	                           STATUS = 'ALLOTED',
	                           ALLOTED_FLAG='Y',
	                           ALLOTED_DATE=SYSDATE,
	                           LAST_UPDATED_BY=IS_USER_ACCOUNT,
	                           LAST_UPDATE_DATE=SYSDATE
	                    WHERE  ALLOT_ORDER_ID= ALLOT_ORDER_ROW.ALLOT_ORDER_ID;
	               ELSIF  N_NEED_QUANTITY > ALLOT_ORDER_ROW.ALLOT_QTY AND  ALLOT_ORDER_ROW.ALLOT_QTY>0 THEN
	                   UPDATE T_SL_ALLOT_ORDER　SET
	                           STATUS = 'ALLOTING',
	                           ALLOTED_FLAG='N',
	                           ALLOTED_DATE=null,
	                           LAST_UPDATED_BY=IS_USER_ACCOUNT,
	                           LAST_UPDATE_DATE=SYSDATE
	                    WHERE  ALLOT_ORDER_ID= ALLOT_ORDER_ROW.ALLOT_ORDER_ID;
	               END IF;
	          EXCEPTION
	               WHEN OTHERS THEN
	               OS_MESSAGE := SUBSTR(SQLERRM(SQLCODE), 1, 256); 
	               RETURN;
	          END;
	        END LOOP;
	        
      END IF;
      
      P_UPDATE_ONHAND(IN_BILL_HEADER_ID,IS_USER_ACCOUNT,2,S_MESSAGE_CHILD);
      IF S_MESSAGE_CHILD <> 'OK' THEN
          OS_MESSAGE     := S_MESSAGE_CHILD;
         
         RETURN;
      END IF;

    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        OS_MESSAGE     := 'OK';
        RETURN;
      WHEN OTHERS THEN
        OS_MESSAGE := SUBSTR(SQLERRM(SQLCODE), 1, 256);
        
    END P_ALLOT_BILL_CHECK;

  ------------------------------------------------------------------------------
  ---  功能描述： 自动审核给定时间之前的所有库位单                ---
  ------------------------------------------------------------------------------
  PROCEDURE P_AUTO_CHECK(
                               ID_CURRENT_DATE IN  DATE,      --当前日期
                               IS_USER_ACCOUNT        IN  VARCHAR2,--用户ID
                               IN_ENTITY_ID           IN  NUMBER,   --主体ID
                               OS_MESSAGE        OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
    )IS
       BILL_STATUS_CREATED T_SL_BILL_HEADER.BILL_STATUS%TYPE;
       S_MESSAGE_CHILD VARCHAR2(200);
       S_USER_ID VARCHAR2(100);
    BEGIN
       OS_MESSAGE          := 'OK';
       BILL_STATUS_CREATED := 'CREATED';
       S_USER_ID := PKG_BD.F_GET_PARAMETER_VALUE('SL_AUTO_USER',IN_ENTITY_ID);
       --查询当前时间之前的未审核库位单
       FOR BILL_HEADER IN (
         SELECT BILL_HEADER_ID
         FROM  T_SL_BILL_HEADER
         WHERE BILL_DATE<=ID_CURRENT_DATE
         AND BILL_STATUS=BILL_STATUS_CREATED
         AND ENTITY_ID=IN_ENTITY_ID
         )LOOP
        BEGIN
            --审核库位单
            P_ALLOT_BILL_CHECK(BILL_HEADER.BILL_HEADER_ID,ID_CURRENT_DATE,S_USER_ID,S_MESSAGE_CHILD);
              IF S_MESSAGE_CHILD <> 'OK' THEN
		          OS_MESSAGE     := NVL(OS_MESSAGE,'')||S_MESSAGE_CHILD;
		          ROLLBACK;
		      END IF;
            commit;
            EXCEPTION
               WHEN OTHERS THEN
                 ROLLBACK;
        END;
       END LOOP;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        NULL;
      WHEN OTHERS THEN
        OS_MESSAGE := SUBSTR(SQLERRM(SQLCODE), 1, 256);
        ROLLBACK;
    END P_AUTO_CHECK;

  ------------------------------------------------------------------------------
  ---  功能描述： 库位收发存冻结                                             ---
  ------------------------------------------------------------------------------
  PROCEDURE P_SFC_FREEZE(
                       ID_CURRENT_DATE IN  DATE,  --当前日期
                       IS_USER_ACCOUNT      IN  VARCHAR2, --用户ID
                       IN_ENTITY_ID         IN  NUMBER,   --主体ID
                       OS_MESSAGE      OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
 )IS
       D_PREV_DATE DATE;
       S_PREV_YEAR VARCHAR2(8);
       S_PREV_MONTH VARCHAR2(8);
       S_PREV_YEAR_MONTH VARCHAR2(8);
       S_CURRENT_YEAR VARCHAR2(8);
       S_CURRENT_MONTH VARCHAR2(8);
       S_CURRENT_YEAR_MONTH VARCHAR2(8);
       N_CURRENT_PERIOD_ID NUMBER;
       N_PREV_PERIOD_ID NUMBER;
       D_CURRENT_FIRST DATE;
       D_CURRENT_LAST DATE;
       N_SFC_FREEZE_ID NUMBER;
       D_CUR_DATE DATE;
       S_USER_ID VARCHAR2(100);
    BEGIN
       OS_MESSAGE          := 'OK';
       D_CUR_DATE          := ADD_MONTHS(ID_CURRENT_DATE,-1);
       S_CURRENT_YEAR      := TO_CHAR(D_CUR_DATE,'YYYY');
       S_CURRENT_MONTH     := TO_CHAR(D_CUR_DATE,'MM');
       S_CURRENT_YEAR_MONTH :=S_CURRENT_YEAR||'-'||S_CURRENT_MONTH;

       D_PREV_DATE  :=  ADD_MONTHS(D_CUR_DATE,-1);
       S_PREV_YEAR  := TO_CHAR(D_PREV_DATE,'YYYY');
       S_PREV_MONTH := TO_CHAR(D_PREV_DATE,'MM');
       S_PREV_YEAR_MONTH := S_PREV_YEAR||'-'||S_PREV_MONTH;

       D_CURRENT_FIRST := TRUNC(D_CUR_DATE,'MONTH');
       D_CURRENT_LAST :=  LAST_DAY(TRUNC(D_CUR_DATE,'MONTH'));
        S_USER_ID := PKG_BD.F_GET_PARAMETER_VALUE('SL_AUTO_USER',IN_ENTITY_ID);
       BEGIN
            SELECT
              PERIOD_ID
            INTO
              N_CURRENT_PERIOD_ID
            FROM
              T_INV_INVENTORY_PERIODS
            WHERE
              PERIOD_NAME = S_CURRENT_YEAR_MONTH
              AND ENTITY_ID = IN_ENTITY_ID
              AND ROWNUM = 1;
       EXCEPTION
            WHEN NO_DATA_FOUND THEN
                OS_MESSAGE := '当前月份期间不存在';
            RETURN;
        END;

        delete from T_SL_SFC_FREEZE where  PERIOD_ID = N_CURRENT_PERIOD_ID and  ENTITY_ID=IN_ENTITY_ID;
        
        BEGIN
            SELECT
              PERIOD_ID
            INTO
              N_PREV_PERIOD_ID
            FROM
              T_INV_INVENTORY_PERIODS
            WHERE
              PERIOD_NAME = S_PREV_YEAR_MONTH
              AND ENTITY_ID = IN_ENTITY_ID
              AND ROWNUM = 1;
        EXCEPTION
            WHEN NO_DATA_FOUND THEN
            NULL;
        END;
              --入库数 账面数
              MERGE INTO T_SL_SFC_FREEZE O
              USING (SELECT 
                           H.INVENTORY_ID,
                           L.REV_LOCATION_ID,
                           L.ITEM_ID,
                           L.REV_ITEM_BATCH,
                           H.ENTITY_ID,
                           H.REV_INV_ID FACT_INV_ID,
                           L.REV_ITEM_STATUS ITEM_STATUS,
                           SUM(CASE WHEN H.BUSINESS_TYPE ='33'   THEN  H.REV_INV_SIGN*NVL(L.QUANTITY,0) --理库入库数量
                                    ELSE 0 END
                           ) QUANTITY33,
                          SUM(CASE WHEN H.BUSINESS_TYPE ='1009'  THEN  H.REV_INV_SIGN*NVL(L.QUANTITY,0) --盘点入库数量
                                    ELSE 0 END
                           ) QUANTITY1009,
                           SUM(CASE WHEN H.BUSINESS_TYPE ='1008' THEN  H.REV_INV_SIGN*NVL(L.QUANTITY,0) --调拨入库数量
                                    ELSE 0 END
                           ) QUANTITY1008,
                           SUM(CASE WHEN H.BUSINESS_TYPE ='1007' THEN  H.REV_INV_SIGN*NVL(L.QUANTITY,0) --销售退货入库数量
                                    ELSE 0 END
                           ) QUANTITY1007,
                           SUM(CASE WHEN H.BUSINESS_TYPE ='1006' THEN  H.REV_INV_SIGN*NVL(L.QUANTITY,0) --销售入库数量
                                    ELSE 0 END
                           ) QUANTITY1006

                    FROM  T_SL_BILL_LINE L,
                          T_SL_BILL_HEADER H
                    WHERE L.BILL_HEADER_ID = H.BILL_HEADER_ID
                    AND   L.REV_LOCATION_ID IS NOT NULL
                    AND   H.BILL_STATUS in ('CHECKED','AFFRIMED')
                    AND   H.PERIOD_ID = N_CURRENT_PERIOD_ID
                    AND   H.ENTITY_ID = IN_ENTITY_ID
                    GROUP BY H.INVENTORY_ID,L.REV_LOCATION_ID,L.ITEM_ID,L.REV_ITEM_BATCH,H.ENTITY_ID,H.REV_INV_ID,L.REV_ITEM_STATUS
              ) B

              ON (B.REV_LOCATION_ID = O.LOCATION_ID
              AND B.ITEM_ID = O.ITEM_ID
              AND B.ENTITY_ID=O.ENTITY_ID
              AND B.REV_ITEM_BATCH = O.ITEM_BATCH
              AND B.FACT_INV_ID = O.FACT_INV_ID
              AND B.ITEM_STATUS = O.ITEM_STATUS
              AND O.INVENTORY_ID = B.INVENTORY_ID
              AND O.STORE_TYPE = 'A'
              AND O.PERIOD_ID = N_CURRENT_PERIOD_ID
             )
              WHEN MATCHED THEN
                      UPDATE SET O.TRSF_QTY = nvl(O.TRSF_QTY,0)+B.QUANTITY1008,
                                 O.SALE_QTY = nvl(O.SALE_QTY,0)+B.QUANTITY1006,
                                 O.BACK_QTY  = nvl(O.BACK_QTY,0)+B.QUANTITY1007,
                                 O.CHK_QTY  = nvl(O.CHK_QTY,0)+B.QUANTITY1009,
                                 O.ADJUST_QTY  = nvl(O.ADJUST_QTY,0)+B.QUANTITY33,
                                 O.LAST_UPDATED_BY = S_USER_ID,
                                 O.LAST_UPDATE_DATE= SYSDATE
              WHEN NOT MATCHED THEN
                     INSERT (SFC_FREEZE_ID,LOCATION_ID, FACT_INV_ID, ENTITY_ID,PERIOD_ID,
                            ITEM_ID,ITEM_STATUS,ITEM_BATCH,STORE_TYPE,TRSF_QTY,
                            SALE_QTY,BACK_QTY,CHK_QTY,ADJUST_QTY,CREATED_BY,CREATION_DATE,LAST_UPDATED_BY,LAST_UPDATE_DATE,INVENTORY_ID)
                      VALUES (S_SL_SFC_FREEZE.NEXTVAL,B.REV_LOCATION_ID,B.FACT_INV_ID, B.ENTITY_ID,N_CURRENT_PERIOD_ID,
                              B.ITEM_ID,B.ITEM_STATUS,B.REV_ITEM_BATCH,'A',B.QUANTITY1008,B.QUANTITY1006,B.QUANTITY1007,
                              B.QUANTITY1009,B.QUANTITY33,
                              S_USER_ID,SYSDATE,S_USER_ID,SYSDATE,B.INVENTORY_ID);

              --出库数 账面数
              MERGE INTO T_SL_SFC_FREEZE O
              USING (SELECT L.SEND_LOCATION_ID,
                            H.INVENTORY_ID,
                            L.ITEM_ID,
                            L.SEND_ITEM_BATCH,
                            H.ENTITY_ID,
                            H.SEND_INV_ID FACT_INV_ID,
                            L.SEND_ITEM_STATUS ITEM_STATUS,

                           SUM(CASE WHEN H.BUSINESS_TYPE ='33'    THEN  H.SEND_INV_SIGN*NVL(L.QUANTITY,0) --理库出库数量
                                    ELSE 0 END
                           ) QUANTITY33,
                           SUM(CASE WHEN H.BUSINESS_TYPE ='1009'  THEN  H.SEND_INV_SIGN*NVL(L.QUANTITY,0) --盘点出库数量
                                    ELSE 0 END
                           ) QUANTITY1009,
                           SUM(CASE WHEN H.BUSINESS_TYPE ='1006'  THEN  H.SEND_INV_SIGN*NVL(L.QUANTITY,0) --销售出库数量
                                    ELSE 0 END
                           ) QUANTITY1006,
                           SUM(CASE WHEN H.BUSINESS_TYPE ='1007'  THEN  H.SEND_INV_SIGN*NVL(L.QUANTITY,0) --销售退货出库数量
                                    ELSE 0 END
                           ) QUANTITY1007,
                           SUM(CASE WHEN H.BUSINESS_TYPE ='1008'  THEN  H.SEND_INV_SIGN*NVL(L.QUANTITY,0) --调拨出库数量
                                    ELSE 0 END
                           ) QUANTITY1008

                    FROM  T_SL_BILL_LINE L,
                          T_SL_BILL_HEADER H
                    WHERE L.BILL_HEADER_ID = H.BILL_HEADER_ID
                    AND   H.BILL_STATUS in ('CHECKED','AFFRIMED')
                    AND   L.SEND_LOCATION_ID is not null
                    AND   H.PERIOD_ID = N_CURRENT_PERIOD_ID
                    AND   H.ENTITY_ID = IN_ENTITY_ID
                    GROUP BY H.INVENTORY_ID,L.SEND_LOCATION_ID,L.ITEM_ID,L.SEND_ITEM_BATCH,H.ENTITY_ID,H.SEND_INV_ID, L.SEND_ITEM_STATUS
              ) B

              ON (B.SEND_LOCATION_ID = O.LOCATION_ID
              AND B.ITEM_ID = O.ITEM_ID
              AND B.ENTITY_ID=O.ENTITY_ID
              AND B.SEND_ITEM_BATCH = O.ITEM_BATCH
              AND B.FACT_INV_ID = O.FACT_INV_ID
              AND B.ITEM_STATUS = O.ITEM_STATUS
              AND O.INVENTORY_ID = B.INVENTORY_ID
              AND O.STORE_TYPE = 'A'
              AND O.PERIOD_ID = N_CURRENT_PERIOD_ID
             )
              WHEN MATCHED THEN
                      UPDATE SET O.TRSF_QTY = nvl(O.TRSF_QTY,0)+B.QUANTITY1008,
                                 O.SALE_QTY = nvl(O.SALE_QTY,0)+B.QUANTITY1006,
                                 O.BACK_QTY  = nvl(O.BACK_QTY,0)+B.QUANTITY1007,
                                 O.CHK_QTY  = nvl(O.CHK_QTY,0)+B.QUANTITY1009,
                                 O.ADJUST_QTY  = nvl(O.ADJUST_QTY,0)+B.QUANTITY33,
                                 O.LAST_UPDATED_BY = S_USER_ID,
                                 O.LAST_UPDATE_DATE= SYSDATE
              WHEN NOT MATCHED THEN
                     INSERT (SFC_FREEZE_ID,LOCATION_ID, FACT_INV_ID, ENTITY_ID,PERIOD_ID,
                            ITEM_ID,ITEM_STATUS, ITEM_BATCH,STORE_TYPE,TRSF_QTY,
                            SALE_QTY,BACK_QTY,CHK_QTY,ADJUST_QTY,CREATED_BY,CREATION_DATE,LAST_UPDATED_BY,LAST_UPDATE_DATE,INVENTORY_ID)
                      VALUES (S_SL_SFC_FREEZE.NEXTVAL,B.SEND_LOCATION_ID,B.FACT_INV_ID, B.ENTITY_ID,N_CURRENT_PERIOD_ID,
                              B.ITEM_ID,B.ITEM_STATUS,B.SEND_ITEM_BATCH,'A',B.QUANTITY1008,
                              B.QUANTITY1006,B.QUANTITY1007,B.QUANTITY1009,B.QUANTITY33,
                              S_USER_ID,SYSDATE,S_USER_ID,SYSDATE,B.INVENTORY_ID);

                 --入库数 实存数
              MERGE INTO T_SL_SFC_FREEZE O
              USING (SELECT 
                           H.INVENTORY_ID,
                           L.REV_LOCATION_ID,
                           L.ITEM_ID,
                           L.REV_ITEM_BATCH,
                           H.ENTITY_ID,
                           H.REV_INV_ID FACT_INV_ID,
                           L.REV_ITEM_STATUS ITEM_STATUS,

                           SUM(CASE WHEN H.BUSINESS_TYPE ='33'   THEN  H.REV_INV_SIGN*NVL(L.AFFIRM_QTY,0) --理库入库数量
                                    ELSE 0 END
                           ) QUANTITY33,
                           SUM(CASE WHEN H.BUSINESS_TYPE ='1009' THEN  H.REV_INV_SIGN*NVL(L.AFFIRM_QTY,0) --盘点入库数量
                                    ELSE 0 END
                           ) QUANTITY1009,
                          SUM(CASE WHEN H.BUSINESS_TYPE ='1006'  THEN  H.REV_INV_SIGN*NVL(L.AFFIRM_QTY,0) --销售入库数量
                                    ELSE 0 END
                           ) QUANTITY1006,
                           SUM(CASE WHEN H.BUSINESS_TYPE ='1007' THEN  H.REV_INV_SIGN*NVL(L.AFFIRM_QTY,0) --销售退货入库数量
                                    ELSE 0 END
                           ) QUANTITY1007,
                           SUM(CASE WHEN H.BUSINESS_TYPE ='1008' THEN  H.REV_INV_SIGN*NVL(L.AFFIRM_QTY,0) --仓库调拨入库数量
                                    ELSE 0 END
                           ) QUANTITY1008

                    FROM  T_SL_BILL_LINE L,
                          T_SL_BILL_HEADER H
                    WHERE L.BILL_HEADER_ID = H.BILL_HEADER_ID
                    AND   L.REV_LOCATION_ID IS NOT NULL
                    AND   H.BILL_STATUS = 'AFFRIMED'
                    AND   H.PERIOD_ID = N_CURRENT_PERIOD_ID
                    AND   H.ENTITY_ID = IN_ENTITY_ID
                    GROUP BY H.INVENTORY_ID,L.REV_LOCATION_ID,L.ITEM_ID,L.REV_ITEM_BATCH,H.ENTITY_ID,H.REV_INV_ID,L.REV_ITEM_STATUS
              ) B

              ON (B.REV_LOCATION_ID = O.LOCATION_ID
              AND B.ITEM_ID = O.ITEM_ID
              AND B.ENTITY_ID=O.ENTITY_ID
              AND O.INVENTORY_ID = B.INVENTORY_ID
              AND B.REV_ITEM_BATCH = O.ITEM_BATCH
              AND B.FACT_INV_ID = O.FACT_INV_ID
              AND B.ITEM_STATUS = O.ITEM_STATUS
              AND O.STORE_TYPE = 'F'
              AND O.PERIOD_ID = N_CURRENT_PERIOD_ID
             )
              WHEN MATCHED THEN
                      UPDATE SET O.TRSF_QTY = nvl(O.TRSF_QTY,0)+B.QUANTITY1008,
                                 O.SALE_QTY = nvl(O.SALE_QTY,0)+B.QUANTITY1006,
                                 O.BACK_QTY  = nvl(O.BACK_QTY,0)+B.QUANTITY1007,
                                 O.CHK_QTY  = nvl(O.CHK_QTY,0)+B.QUANTITY1009,
                                 O.ADJUST_QTY  = nvl(O.ADJUST_QTY,0)+B.QUANTITY33,
                                 O.LAST_UPDATED_BY = S_USER_ID,
                                 O.LAST_UPDATE_DATE= SYSDATE
              WHEN NOT MATCHED THEN
                     INSERT (SFC_FREEZE_ID,LOCATION_ID, FACT_INV_ID, ENTITY_ID,PERIOD_ID,
                            ITEM_ID,ITEM_STATUS, ITEM_BATCH,STORE_TYPE,TRSF_QTY,
                            SALE_QTY,BACK_QTY,CHK_QTY,ADJUST_QTY,CREATED_BY,CREATION_DATE,LAST_UPDATED_BY,LAST_UPDATE_DATE,INVENTORY_ID)
                      VALUES (S_SL_SFC_FREEZE.NEXTVAL,B.REV_LOCATION_ID,B.FACT_INV_ID, B.ENTITY_ID,N_CURRENT_PERIOD_ID,
                              B.ITEM_ID,B.ITEM_STATUS,B.REV_ITEM_BATCH,'F',B.QUANTITY1008,B.QUANTITY1006,B.QUANTITY1007,
                              B.QUANTITY1009,B.QUANTITY33,
                              S_USER_ID,SYSDATE,S_USER_ID,SYSDATE,B.INVENTORY_ID);


              --出库数 实存数
              MERGE INTO T_SL_SFC_FREEZE O
              USING (SELECT 
                           H.INVENTORY_ID,
                           L.SEND_LOCATION_ID,
                           L.ITEM_ID,
                           L.SEND_ITEM_BATCH,
                           H.ENTITY_ID,
                           H.SEND_INV_ID FACT_INV_ID,
                           L.SEND_ITEM_STATUS ITEM_STATUS,
                           SUM(CASE WHEN H.BUSINESS_TYPE ='33'   THEN  H.SEND_INV_SIGN*NVL(L.AFFIRM_QTY,0) --理库出库数量
                                    ELSE 0 END
                           ) QUANTITY33,
                           SUM(CASE WHEN H.BUSINESS_TYPE ='1009' THEN  H.SEND_INV_SIGN*NVL(L.AFFIRM_QTY,0) --盘点出库数量
                                    ELSE 0 END
                           ) QUANTITY1009,
                          SUM(CASE WHEN H.BUSINESS_TYPE ='1006'  THEN  H.SEND_INV_SIGN*NVL(L.AFFIRM_QTY,0) --销售出库数量
                                    ELSE 0 END
                           ) QUANTITY1006,
                           SUM(CASE WHEN H.BUSINESS_TYPE ='1007' THEN  H.SEND_INV_SIGN*NVL(L.AFFIRM_QTY,0) --销售退货出库数量
                                    ELSE 0 END
                           ) QUANTITY1007,
                           SUM(CASE WHEN H.BUSINESS_TYPE ='1008' THEN  H.SEND_INV_SIGN*NVL(L.AFFIRM_QTY,0) --调拨出库数量
                                    ELSE 0 END
                           ) QUANTITY1008
                    FROM  T_SL_BILL_LINE L,
                          T_SL_BILL_HEADER H
                    WHERE L.BILL_HEADER_ID = H.BILL_HEADER_ID
                    AND   L.SEND_LOCATION_ID is not null
                    AND   H.BILL_STATUS = 'AFFRIMED'
                    AND   H.PERIOD_ID = N_CURRENT_PERIOD_ID
                    AND   H.ENTITY_ID = IN_ENTITY_ID
                    GROUP BY H.INVENTORY_ID,L.SEND_LOCATION_ID,L.ITEM_ID,L.SEND_ITEM_BATCH,H.ENTITY_ID,H.SEND_INV_ID,L.SEND_ITEM_STATUS
              ) B

              ON (B.SEND_LOCATION_ID = O.LOCATION_ID
              AND B.ITEM_ID = O.ITEM_ID
              AND B.ENTITY_ID=O.ENTITY_ID
              AND B.SEND_ITEM_BATCH = O.ITEM_BATCH
              AND B.FACT_INV_ID = O.FACT_INV_ID
              AND B.ITEM_STATUS = O.ITEM_STATUS
              AND O.INVENTORY_ID = B.INVENTORY_ID
              AND O.STORE_TYPE = 'F'
              AND O.PERIOD_ID = N_CURRENT_PERIOD_ID
             )
              WHEN MATCHED THEN
                      UPDATE SET O.TRSF_QTY = nvl(O.TRSF_QTY,0)+B.QUANTITY1008,
                                 O.SALE_QTY = nvl(O.SALE_QTY,0)+B.QUANTITY1006,
                                 O.BACK_QTY  = nvl(O.BACK_QTY,0)+B.QUANTITY1007,
                                 O.CHK_QTY  = nvl(O.CHK_QTY,0)+B.QUANTITY1009,
                                 O.ADJUST_QTY  = nvl(O.ADJUST_QTY,0)+B.QUANTITY33,
                                 O.LAST_UPDATED_BY = S_USER_ID,
                                 O.LAST_UPDATE_DATE= SYSDATE
              WHEN NOT MATCHED THEN
                     INSERT (SFC_FREEZE_ID,LOCATION_ID, FACT_INV_ID, ENTITY_ID,PERIOD_ID,
                            ITEM_ID,ITEM_STATUS, ITEM_BATCH,STORE_TYPE,TRSF_QTY,
                            SALE_QTY,BACK_QTY,CHK_QTY,ADJUST_QTY,CREATED_BY,CREATION_DATE,LAST_UPDATED_BY,LAST_UPDATE_DATE,INVENTORY_ID)
                      VALUES (S_SL_SFC_FREEZE.NEXTVAL,B.SEND_LOCATION_ID,B.FACT_INV_ID, B.ENTITY_ID,N_CURRENT_PERIOD_ID,
                              B.ITEM_ID,B.ITEM_STATUS,B.SEND_ITEM_BATCH,'F',B.QUANTITY1008,
                              B.QUANTITY1006,B.QUANTITY1007,B.QUANTITY1009,B.QUANTITY33,
                              S_USER_ID,SYSDATE,S_USER_ID,SYSDATE,B.INVENTORY_ID);

           IF  N_PREV_PERIOD_ID IS NOT NULL THEN
                --更新期初数
               UPDATE  T_SL_SFC_FREEZE C SET  INIT_QTY =
               (SELECT END_QTY FROM T_SL_SFC_FREEZE N
                WHERE C.LOCATION_ID=N.LOCATION_ID
                AND   C.FACT_INV_ID = N.FACT_INV_ID
                AND   C.ENTITY_ID = N.ENTITY_ID
                AND   c.INVENTORY_ID = n.INVENTORY_ID
                AND   C.ITEM_ID = N.ITEM_ID
                AND   C.ITEM_STATUS = N.ITEM_STATUS
                AND   C.ITEM_BATCH = N.ITEM_BATCH
                AND   C.STORE_TYPE = N.STORE_TYPE
                AND   N.PERIOD_ID = N_PREV_PERIOD_ID
                AND ROWNUM=1
               )
             WHERE PERIOD_ID = N_CURRENT_PERIOD_ID;
           END IF;

           --更新期末数
           UPDATE  T_SL_SFC_FREEZE C 
           SET  END_QTY = (NVL(INIT_QTY,0)+NVL(TRSF_QTY,0)+NVL(SALE_QTY,0)+NVL(BACK_QTY,0)+NVL(CHK_QTY,0)+NVL(ADJUST_QTY,0))
           WHERE PERIOD_ID = N_CURRENT_PERIOD_ID;
           --提交
           COMMIT;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        NULL;
      WHEN OTHERS THEN
        OS_MESSAGE := SUBSTR(SQLERRM(SQLCODE), 1, 256);
        ROLLBACK;
    END P_SFC_FREEZE;

END PKG_SL;
/

