create Package      PKG_AR_INVOICE Is

  --错误类型，返回值
  Err_Ok                       Constant Varchar2(10) := 'OK';
  Err_Yes                      Constant Varchar2(10) := 'Y';
  Err_No                       Constant Varchar2(10) := 'N';
  Err_Param_Err                Constant Varchar2(50) := '参数不在允许的范围内';
  Err_Unknow                   Constant Varchar2(50) := '不明错误：';
  Err_Dup_Queue                Constant Varchar2(50) := '重复的打印队列';
  Err_Trx_In_Queue             Constant Varchar2(50) := '发票已在队列中';
  Err_Trx_Not_In_Queue         Constant Varchar2(50) := '发票不在队列中';
  Err_Trx_Cannt_Printed        Constant Varchar2(50) := '非未开票状态的发票不能开票';
  Err_Trx_Cannt_Cancel_Printed Constant Varchar2(50) := '非准备开票状态的发票不能取消开票';
  Err_Trx_Printed              Constant Varchar2(50) := '此发票项已经打印';
  Err_Trx_No_Found             Constant Varchar2(50) := '发票找不到';
  Err_Trx_Cannt_Disable        Constant Varchar2(50) := '发票不能失效/禁止打印';
  Err_Order_No_Found           Constant Varchar2(50) := '销售单找不到';
  Err_Trx_Not_Cancelable       Constant Varchar2(50) := '发票不能作废';
  v_Nl                         Constant Varchar2(2) := Chr(13) || Chr(10); --换行
  v_Null                       Constant Varchar2(4) := 'null'; --空值

  Ea_Report2adm      Constant Varchar2(50) := '出错，请找系统管理员。';
  Tpt_Commontaxpayer Constant Varchar2(50) := 'GeneralTaxpayer'; -- '一般纳税人';

  Unlimit_Trxamount Constant Number := 10000000000;

  Handle_By_Discount_Union Constant Varchar2(100) := 'DISCOUNT_UNION'; --'产生专门用于发票打印的汇总的折扣折让行';
  Handle_By_Discount_Line  Constant Varchar2(100) := 'DISCOUNT_LINE'; --'产生用于商品正负间隔的折扣折让行';

  --Trx State 发票状态
  --未知状态
  Ts_Unknow      Constant Varchar2(40) := 'TS_UNKNOW';
  --未开票
  Ts_Not_Printed Constant Varchar2(40) := 'TS_NOT_PRINTED';
  --准备开票
  Ts_In_Queue    Constant Varchar2(40) := 'TS_IN_QUEUE';
  --已开票
  Ts_Printed     Constant Varchar2(40) := 'TS_PRINTED';
  --不能开票
  Ts_Unprintable Constant Varchar2(40) := 'TS_UNPRINTABLE';
  -- Ts_Outport     Constant Varchar2(40) := 'TS_OUTPORT';
  --已锁定
  Ts_Locked      Constant Varchar2(40) := 'TS_LOCKED';

  --Trans_type 转换方式
  Tt_Normal                 Constant Varchar2(40) := 'NORMAL'; --普通方式合并
  Tt_Ignore_Discount        Constant Varchar2(40) := 'IGNORE_DISCOUNT'; --忽略折扣合并
  Tt_Single_Batch_Row       Constant Varchar2(40) := 'SINGLE_BATCH_ROW'; --单虚拟商品合并
  Tt_Hide_Discount_Line     Constant Varchar2(40) := 'HIDE_DISCOUNT_LINE'; --保存时不产生虚拟折扣行
  Tt_DISCOUNT_DISTRIBUTION_GOODS     Constant Varchar2(40) := 'DISCOUNT_DISTRIBUTION_GOODS'; --折扣分配商品行
  Tt_RETURN_DISTRIBUTION_GOODS     Constant Varchar2(40) := 'RETURN_DISTRIBUTION_GOODS'; --折扣分配商品行

  --备注常量
  Mc_Trx_Header_Code Constant Varchar2(50) := '[TRX_HEADER_CODE]';
  
  
    --定义开票配置记录集
  TYPE TYPE_AR_CONF IS RECORD(
      TRX_RATE               NUMBER,        --税率
      MAX_TRX_AMOUNT         NUMBER(20,2),  --最大开票额
      MAX_DISCOUNT_LIMT      NUMBER(20,2),  --最大折扣率
      WHETHER_SPLIT          VARCHAR2(2)--是否允许拆分
  );
  
    -- 取银行账户
  function F_GET_CUSTOMER_BANK(
      p_Entity_Id       Number,  
      p_Customer_Id     Number
   ) 
   return varchar2;
   
     -- 取客户银行名称 add by huanghb12
  function F_GET_CUSTOMER_BANK_NAME(
      p_Entity_Id       Number,  
      p_Customer_Id     Number
   ) 
   return varchar2;
    
  -- 取客户银行账号 add by huanghb12
  function F_GET_CUSTOMER_BANK_ACCOUNT(
      p_Entity_Id       Number,  
      p_Customer_Id     Number
   ) 
   return varchar2;

  ------------------------------------------------------------------------
  --Author: Nicro.Li
  --Purpose: 获取AR客户参数设置信息
  ------------------------------------------------------------------------
  Function f_Get_Ar_Config(p_Entity_Id       Number,
                           p_Sales_Center_Id Number Default Null,
                           p_Customer_Id     Number Default Null,
                           p_Ou_id           Number Default Null)
    Return Type_Ar_Config;

  --得到发票折扣率
  Function Get_Trx_Discount_Amount(p_Trx_Id t_So_Trx_Headers.Idtrx_Id%Type --发票ID
                                   ) Return Number;

  --发票作废和（针对一个发票池头进行作废）
  Procedure Cancel_So_Trx(p_Trx_Id  In t_So_Trx_Headers.Idtrx_Id%Type --作废的发票号码
                         ,
                          p_User_Id In t_So_Trx_Headers.Created_By%Type
                          --用户ID
                         ,
                          p_Result Out Varchar2
                          --返回值
                          );

  /*
  过程描述：用于检查发票状态是否可进行相关操作
  参数说明：
  P_TRX_ID   发票头ID
  CHECK_TYPE 检查类型（此检查用于什么操作）
  P_RESULT 反回参数，如果返回值不为 ERR_OK 则表示检查失败
  */
  Procedure p_Check_Status(p_Trx_Id   In Number,
                           Check_Type In Varchar2,
                           p_Result   In Out Varchar2);

   --删除单张发票及相关表记录
   Procedure p_Delete_Trx(p_Trx_Id In Number, p_Result In Out Varchar2);

   --多对多情况下关联删除发票
    Procedure p_Delete_Trx_Cascade(p_Trx_Id In Number, p_Result In Out Varchar2);

  --取消发票池中的发票，取消形式：删除发票号，删除与该笔发票拆分相关的记录
    Procedure p_Cancel_Trx_Split(p_Trx_Id In t_So_Trx_Headers.Idtrx_Id%Type --发票池ID
                                                        , p_Result Out Varchar2
                                                         --返回值
                                                         );
  --取消发票打印队列
    Procedure p_Cancel_Trx_Print_Queue(p_Trx_Id In t_So_Trx_Headers.Idtrx_Id%Type --发票池ID
                                  , p_User_Account In t_So_Trx_Headers.Created_By%Type
                                   --用户ID
                                  , p_Result Out Varchar2
                                   --返回值
                                   );
  --把发票放入打印队列
    Procedure p_Ins_Trx_Print_Queue(p_Trx_Id In t_So_Trx_Headers.Idtrx_Id%Type --发票池ID
                               , p_User_Account In t_So_Trx_Headers.Created_By%Type
                                --用户ID
                               , p_Result Out Varchar2
                                --返回值
                                );
  --------------------------------------------------------------------------
  --Author: Nicro.Li
  --Created: 2014-10-15
  --把发票池接口表的数据转换成正式发票池数据
  --------------------------------------------------------------------------
  Procedure p_Create_So_Trx(p_Trx_Oi_Header_Id In t_So_Trx_Oi_Headers.Toh_Id%Type, --转换用的接口ID
                            p_User_Code        In Varchar2, --用户ID
                            p_Trx_Header_Code  Out t_So_Trx_Headers.Trx_Header_Code%Type, --返回发票池头编码
                            p_Result           Out Varchar2 --返回值
                            );
                            
                            
   --Author: guibr
  --Created: 2016-07-01
  --把发票池接口表的数据转换成正式发票池数据   洗衣机最新开票方式 
  --国税总局统一要求，升级后将使用商品编码开具发票   营改增新开票方式
  --------------------------------------------------------------------------
  Procedure p_Create_So_Trx_added(p_Trx_Oi_Header_Id In t_So_Trx_Oi_Headers.Toh_Id%Type, --转换用的接口ID
                                  p_User_Code        In Varchar2, --用户ID
                                  p_So_Trx_Head_Id   In Number,
                                  p_Max_Discount_Rate In Number,
                                  P_Cancel_Order_In_Trx In Varchar2,
                                  P_Trx_Rate        In Number,
                                  p_Result           Out Varchar2 --返回值
                                  );    
 
  --------------------------------------------------------------------------
  --Author: guibr
  --Created: 2016-01-25
  --分配折扣行
  --------------------------------------------------------------------------
  Procedure P_CREATE_DISCOUNT_SPILT(IN_IDTRX_ID In t_so_trx_headers.IDTRX_ID%Type, --发票头ID
                                    IN_SO_DISCOUNT_SUM number,
                                    IN_SO_PLUS_SUM number,
                                    IN_SO_TRX_COUNT number,
                                    p_Result Out Varchar2 --返回值
                           );                                 
                                                         

   --------------------------------------------------------------------------
  --Author: guibr
  --Created: 2016-01-25
  --校验发票开票金额，销售单金额是否超额开票
  --------------------------------------------------------------------------
  Procedure P_CHECK_PREPARE_TRX(IN_IDTRX_ID In t_so_trx_headers.IDTRX_ID%Type, --发票头ID
                           p_Result Out Varchar2 --返回值
                           );


  --------------------------------------------------------------------------
  --Author: guibr
  --Created: 2016-01-25
  --校验发票开票金额，销售单金额是否超额开票
  --------------------------------------------------------------------------
  Procedure P_CHECK_SO_TRX(IN_IDTRX_ID In t_so_trx_headers.IDTRX_ID%Type, --发票头ID
                           p_Result Out Varchar2 --返回值
                           );


    --------------------------------------------------------------------------
  --Author: guibr
  --Created: 2016-01-25
  --冻结开票易明细数据
  --------------------------------------------------------------------------
  Procedure P_FREEZE_SO_TRX(IN_IDTRX_ID In t_so_trx_headers.IDTRX_ID%Type, --发票头ID
                           p_Result Out Varchar2 --返回值
                           );
                           
                           
     --------------------------------------------------------------------------
  --Author: guibr
  --Created: 2016-07-28
  --检查开票折扣行限制
  --------------------------------------------------------------------------
  Procedure P_CHECK_DISCOUNT_ROW(IN_IDTRX_ID In t_so_trx_headers.IDTRX_ID%Type, --发票头ID
                             p_Result Out Varchar2 --返回值
                           );                          


   --------------------------------------------------------------------------
  --Author: guibr
  --Created: 2016-07-28
  --获取开票配置信息
  --------------------------------------------------------------------------
  PROCEDURE P_GET_AR_CONFIG(P_ENTITY_ID       IN   NUMBER,
                            P_SALES_CENTER_ID IN   NUMBER,
                            P_CUSTOMER_ID     IN   NUMBER,
                            P_OU_ID           IN   NUMBER,
                            P_AR_CONF  OUT  TYPE_AR_CONF
                          );
                          
  --------------------------------------------------------------------------
  --Author: guibr
  --Created: 2016-10-17
  --检查开票是否允许拆分
  --------------------------------------------------------------------------
  Procedure P_CHECK_ALLOW_SPLIT(IN_IDTRX_ID In t_so_trx_headers.IDTRX_ID%Type, --发票头ID
                                IS_WHETHER_SPLIT IN VARCHAR2,
                                OS_ENTITY_CUST_FLAG OUT VARCHAR2,
                                OS_DISCOUNT_TAG     OUT VARCHAR2,
                                p_Result Out Varchar2 --返回值
                           );   
                           
                           
  --------------------------------------------------------------------------
  --Author: guibr
  --Created: 2016-10-19
  --处理内部客户开票信息引入关联开票接口
  --------------------------------------------------------------------------
  Procedure P_ENTITY_CUST_IMP_INTF(
                           IN_ENTITY_ID IN NUMBER,
                             OS_MESSAGE OUT VARCHAR2); --返回值  
    
  --------------------------------------------------------------------------
  --Author: guibr
  --Created: 2016-10-19
  --处理内部客户税控信息引入关联开票接口
  --------------------------------------------------------------------------
  Procedure P_ENTITY_CUST_TAX_INTF(
                           IN_ENTITY_ID IN NUMBER,
                            OS_MESSAGE OUT VARCHAR2); --返回值  
    
  
  --------------------------------------------------------------------------
  --Author: guibr
  --Created: 2016-10-19
  --处理内部客户关联交易号更新发票接口
  --------------------------------------------------------------------------
  Procedure P_ENTITY_CUST_INVOICE_INTF(
                           IN_ENTITY_ID IN NUMBER,
                             OS_MESSAGE OUT VARCHAR2); --返回值  );  --返回值 
    
    
  
    --------------------------------------------------------------------------
  --Author: guibr
  --Created: 2016-10-23
  --处理接口处理标志重置
  --------------------------------------------------------------------------
  Procedure P_ENTITY_CUST_RESET(OS_MESSAGE Out Varchar2);  --返回值      
    
  
  --------------------------------------------------------------------------
  --Author: guibr
  --Created: 2016-12-09
  --销售单对冲自动写入关联交易预开票
  --------------------------------------------------------------------------
  Procedure P_ENTITY_SO_TAX(
                            IN_ENTITY_ID IN NUMBER,
                             OS_MESSAGE OUT VARCHAR2); --返回值  
     
  
                          
  --------------------------------------------------------------------------
  --Author: guibr
  --Created: 2016-12-09
  --销售单对冲自动写入发票池
  --------------------------------------------------------------------------
  Procedure P_ENTITY_SO_TAX_AUTO(
                             IN_HEADERS_ID IN NUMBER,
                             IS_NUM_STR IN VARCHAR2,
                             IS_ENTITY_FLAG IN VARCHAR2,
                             IS_CREATED_BY IN VARCHAR2,
                             IS_INVOICE_NUM IN VARCHAR2,
                             IS_PARAM_ECM_COLLECT IN VARCHAR2,
                             IS_VAT_RATE IN VARCHAR2,
                             OS_MESSAGE OUT VARCHAR2); --返回值                            
   
  --------------------------------------------------------------------------
  --Author: guibr
  --Created: 2017-03-23
  --取消ERP税控信息
  --------------------------------------------------------------------------                          
  Procedure P_SO_TAX_CANCEL(IS_IDTRX_ID IN VARCHAR2,
                            USER_ACCOUNT IN VARCHAR2,
                            OS_MESSAGE OUT VARCHAR2);   
                            
  --------------------------------------------------------------------------
  --Author: guibr
  --Created: 2017-03-23
  --取消销售单税控信息CIMS开票
  --------------------------------------------------------------------------                              
  Procedure P_SO_HEADER_CANCEL(IS_SOHEADER_ID IN NUMBER,
                            OS_MESSAGE OUT VARCHAR2);   
                            
                            
                            
  --------------------------------------------------------------------------
  --Author: guibr
  --Created: 2019-04-01
  --电子发票初始化 指定条件发票走电子票
  --------------------------------------------------------------------------                              
  Procedure P_SO_E_INVOICE_INI(IN_ENTITY_ID IN NUMBER,
                               OS_MESSAGE OUT VARCHAR2);                          
                            
                            
    --------------------------------------------------------------------------
  --Author: guibr
  --Created: 2019-04-01
  --电子发票创建
  --------------------------------------------------------------------------                              
  Procedure P_SO_E_INVOICE_CREATE(IN_ENTITY_ID IN NUMBER,
                               OS_MESSAGE OUT VARCHAR2);                                                                            

End PKG_AR_INVOICE;
/

