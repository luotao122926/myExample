create package      PKG_PLN_INTF_CCS is

----------------------------------------------------------------------
  -- Author  : WILDWIND
  -- Created : 2014/12/2 16:50:50
  -- Purpose : CCS接口包
  --           校验接口表数据，将接口表数据同步到正式表中
  ----------------------------------------------------------------------
  TYPE R_MONTHPLAN_ITEM is record(
    ITEM_ID                T_PLN_ORDER_LINE.Item_Id%TYPE,
    ITEM_CODE              T_BD_ITEM.Item_Code%TYPE,
    ITEM_NAME              T_BD_ITEM.Item_Name%TYPE,
    DEFAULTUNIT            T_BD_ITEM.Defaultunit%TYPE,
    ITEM_PRICE             T_PLN_ORDER_LINE.Item_Price%TYPE,
    PRODUCING_AREA_ID      T_PLN_ORDER_LINE.Producing_Area_Id%TYPE,
    PRODUCING_AREA_CODE    T_PLN_ORDER_LINE.Producing_Area_Code%TYPE,
    PRODUCING_AREA_NAME    T_PLN_ORDER_LINE.Producing_Area_Name%TYPE,
    MONTH_NUM              T_PLN_ORDER_LINE.Check_Qty%TYPE,
    WEEK_NUM               T_PLN_ORDER_LINE.Check_Qty%TYPE,
    CANUSE_NUM             T_PLN_ORDER_LINE.Check_Qty%TYPE);

  Type T_MONTHPLAN_ITEM_TABLE Is Table Of R_MONTHPLAN_ITEM;

  Type cur_type Is Ref Cursor;

  V_CCS_EXCEPTION exception;
  /*
   提货订单接口函数
  */
  PROCEDURE P_CREATE_INTF_LG_ORDER(p_Intf_Id      IN NUMBER, --提货订单接口表订单头ID
                                   p_Result       OUT VARCHAR2);

  /*
   计划订单接口函数
  */
  PROCEDURE P_CREATE_INTF_PL_ORDER(p_Intf_Id      IN NUMBER, --计划订单接口表订单头ID
                                   p_Result       OUT VARCHAR2);
  
  /*
   计划订单接口函数
  */
  PROCEDURE P_CREATE_INTF_PL_ORDER_NEW(p_Intf_Id      IN NUMBER, --计划订单接口表订单头ID
                                       p_Result       OUT VARCHAR2);

  Function F_GET_PERIOD(p_Order_Type_Id In Number, --单据类型ID
                        p_Entity_Id     In Number --主体ID
                        ) Return Number;

  function F_GET_PARAMETER_VALUE
  --取系统参数值
  (
   P_CONFIG_CODE    t_bd_param_list.param_code%type,  --参数配置编码
   P_ENTITY_ID      up_org_unit.ENTITY_ID%type, --业务主体ID
   P_UNIT_ID        up_org_unit.Unit_Id%type default null, --中心ID
   P_CUSTOMER_ID    t_customer_header.customer_id%type default null --客户ID
   ) return varchar2;


   function F_GET_MONTH_PLAN(

            P_EntityId             Number,             --主体
            P_Sales_Center_Id      Number,             --中心ID
            P_Account_Id           Number,             --账户ID
            P_Item_Main_Type       varchar2,           --产品大类
            P_Item_Sub_Type        varchar2,           --产品小类
            P_Period_Id            Number,             --周期
            P_Order_Type_id        Number              --订单类型

   ) return T_MONTHPLAN_ITEM_TABLE pipelined;

   function F_GET_MONTH_PLAN_TEST(
            P_EntityId             Number,
            P_Sales_Center_Id      Number,
            P_Account_Id           Number,
            P_Item_Main_Type       varchar2,
            P_Item_Sub_Type        varchar2,
            P_Period_Id            Number,
            P_Order_Type_id        Number

   ) return varchar2 ;


   function F_GET_WEEK_CAN_APPLY_NUM(
            P_EntityId             Number,
            P_Sales_Center_Id      Number,
            P_Account_Id           Number,
            P_Item_Main_Type       varchar2,
            P_Item_Sub_Type        varchar2,
            P_Period_Id            Number,
            P_Order_Type_id        Number,
            P_Item_id              Number,
            P_PRODUCING_AREA_ID    Number

   ) return number;

   Procedure P_GET_WEEK_CAN_APPLY_NUM(
                            P_EntityId             in Number,
                            P_Sales_Center_Id      in Number,
                            P_Account_Id           in Number,
                            P_Item_Main_Type       in varchar2,
                            P_Item_Sub_Type        in varchar2,
                            P_Period_Id            in Number,
                            P_Order_Type_id        in Number,
                            P_Item_id              in Number,
                            P_PRODUCING_AREA_ID    in Number,
                            P_CanApplyNum          out number
                            );
   /*
     获取排产信息
   */
   function F_GET_VEHICLE_INFO(
            p_OrderHead_Id         Number
   ) return varchar2;

   /*
     获取排产信息
   */
   function F_GET_VEHICLE_INFO_MONTH(
            p_OrderHead_Id         Number
   ) return varchar2;

  --------------------------------------------------------------------------------------------
  --  获取营销中心的最优产地，默认考虑商品最优物流成本
  --  P_ITEM_ID传入为空或者0时，只取营销中心的最优产的
  --
  --------------------------------------------------------------------------------------------
  Function F_Get_Cen_Prod_Area(p_Sales_Center_Id In Number,
                               p_Item_Id         In Number,
                               p_Entity_Id       In Number)
  return number;
  
  /*
   月预测接口
  */
  PROCEDURE P_CREATE_MONTH_FORECAST(P_INTF_ID      IN NUMBER, --月预测接口表ID
                                    P_RESULT       OUT VARCHAR2);
  
  /*
   获取产品最优产地
  */
  FUNCTION F_GET_ITEM_PROD_AREA(P_ENTITY_ID       IN NUMBER,
                                P_SALES_CENTER_ID IN NUMBER,
                                P_ITEM_CODE       IN VARCHAR2,
                                p_Item_Life_Cycle In Varchar2 Default 'Y' --add by lizhen 2016-04-22
                                )
  RETURN NUMBER;
  
  -----------------------------------------------------------------------------
  -- AUTHOR  : Nicro.Li
  -- CREATED : 2015-12-09
  -- PURPOSE : 订单送审前检查到款金额，检查金额时增加非送审锁款单据的金额检查，需扣减该部份款项
  --IN_DISCOUNT_TYPE参数说明：ALL：先检查常到款，不足时再检查折让到款 COMMON:只检查常规到款 DISCOUNT：只检查折让到款
  -----------------------------------------------------------------------------
  Procedure p_Submit_Check_Amount(p_Order_Type_Id   In Number, --单据类型ID
                                  p_Customer_Id     In Number, --客户ID
                                  p_Account_Id      In Number, --账户ID
                                  p_Sales_Main_Type In Varchar2, --产品大类
                                  p_Amount          In Number, --提货金额
                                  p_Discount_Amount In Number, --折扣金额额
                                  p_Result          In Out Varchar2, --返回结果：SUCCESS——>过程执行完成；FAILURE——>中途抛错
                                  p_Message         Out Varchar2, --返回信息：这里的值初始为SUCCESS
                                  IN_DISCOUNT_TYPE  In Varchar2 Default 'ALL' --ADD BY LIZHEN 2017-08-17增加检查到款类型
                                  );

-----------------------------------------------------------------------------
  -- AUTHOR  : Nicro.Li
  -- CREATED : 2016-04-05
  -- PURPOSE : 根据产品、单据送审类型获取产品的库存可用量（符合条件仓库的汇总）
  -----------------------------------------------------------------------------                                      
  Function f_Get_Lgorder_Noship_Qty(p_Entity_Id         In Number, ----主体ID
                                    p_Item_Code   In Varchar2, --产品编码
                                    p_Order_Submit_Type In Varchar2, --单据送审类型
                                    p_User_Code         In Varchar2 --用户编码
                                    ) Return Number;
  -----------------------------------------------------------------------------
  -- AUTHOR  : Nicro.Li
  -- CREATED : 2016-04-05
  -- PURPOSE : 根据产品、单据送审类型获取产品的库存可用量（符合条件仓库的汇总）
  -----------------------------------------------------------------------------
  Function f_Get_Item_Usable_Qty(p_Entity_Id         In Number, ----主体ID
                                 p_Item_Code         In Varchar2, --产品编码
                                 p_Order_Submit_Type In Varchar2, --单据送审类型
                                 p_Sales_Center_Id   In Number, --营销中心ID
                                 p_Lg_Order_Noship   In Varchar2, --是否扣减已评未发货数量  Y:扣减  N:不扣减
                                 p_Producing_Area_Id In Number, ----产地ID
                                 p_User_Code         In Varchar2) Return Number ; 
 
  -----------------------------------------------------------------------------
  -- AUTHOR  : Nicro.Li
  -- CREATED : 2016-04-12
  -- PURPOSE : 根据产品、产地ID获取APS剩余产能
  -----------------------------------------------------------------------------
  Function f_Get_Item_Capacity_Qty(p_Producing_Area_Id In Number, ----产地ID
                                   p_Item_Code         In Varchar2 --产品编码
                                   ) Return Number;
                                   
  -----------------------------------------------------------------------------
  -- AUTHOR  : Nicro.Li
  -- CREATED : 2016-05-05
  -- PURPOSE : 根据返回提货订单行的产能可视可满足数量
  -----------------------------------------------------------------------------
  Function f_Get_Line_Capacity_Qty(p_Order_Line_Id     In Number, --提货订单行ID
                                   p_Order_Submit_Type In Varchar2, --单据送审类型
                                   p_Sales_Center_Id   In Number, --营销中心ID
                                   p_Lg_Order_Noship   In Varchar2, --是否扣减已评未发货数量  Y:扣减  N:不扣减                                                    
                                   p_User_Code         In Varchar2 --用户编码
                                   ) Return Number; 
                                   
  -----------------------------------------------------------------------------
  -- AUTHOR  : Nicro.Li
  -- CREATED : 2016-05-11
  -- PURPOSE : 返回提货订单行的产能可视未满足数量
  -----------------------------------------------------------------------------
  Function f_Get_Line_NotCapacity_Qty(p_Order_Line_Id     In Number --提货订单行ID
                                     ) Return Number;  
  
  -----------------------------------------------------------------------------
  -- AUTHOR  : Nicro.Li
  -- CREATED : 2016-05-21
  -- PURPOSE : 提货订单送审完成后，提交APS处理产能可视请求
  -----------------------------------------------------------------------------
  Procedure p_Submit_Aps_Capacity_Request(p_Lg_Order_Head_Id In Number,  --提货订单头ID
                                          p_Result           Out Varchar2 --返回错误信息
                                          );
  -----------------------------------------------------------------------------
  -- AUTHOR  : Nicro.Li
  -- CREATED : 2016-05-24
  -- PURPOSE : CCS已引APS产能可视的订单状态关闭订单
  -----------------------------------------------------------------------------
  Procedure p_Close_LgOrder_Capacity(p_Lg_Order_Head_Id In Number, --提货订单头ID
                                     p_Result           In Out Varchar2 --关闭订单原因，返回错误信息
                                     );
                                     
  ------------------------------------------------------------------------------------------
  ---- AUTHOR  : Nicro.Li
  -- CREATED : 2016-06-29
  -- PURPOSE : 提货订单产能可视检查、产能不足时方法默认返回成功，但会同时返回产可视异常信息
  ------------------------------------------------------------------------------------------
  Procedure p_Chk_Item_Capacity(p_Entity_Id     In Number, --主体ID
                                p_Param_Id      In Number, ----订单头ID
                                p_User_Code     In Varchar2, ----用户ID
                                p_Result        In Out Varchar2, --成功则反回 SUCCESS 失败则返回失败原因
                                p_Chk_Msg       In Out Varchar2 --产能检查不通过时返回错误信息
                                );                                  
  ------------------------------------------------------------------------------------------
  ---- AUTHOR  : ex_dengjh
  -- CREATED : 2017-03-31
  -- PURPOSE : 获取产品可用量
  ------------------------------------------------------------------------------------------
  Procedure P_GET_ITEM_USABLE_QTY(IN_ENTITY_ID         in NUMBER, --主体ID
                                  IN_ITEM_CODE         in VARCHAR2, --产品编码
                                  IN_ORDER_SUBMIT_TYPE in VARCHAR2, --提货订单评审类型
                                  IN_SALES_CENTER_ID   in NUMBER, --中心ID
                                  IN_CUSTOMER_ID       IN NUMBER, --客户ID
                                  IN_LG_ORDER_NOSHIP   in VARCHAR2, --是否扣减已评未发货量
                                  IN_PRODUCING_AREA_ID in NUMBER, --产地ID
                                  IN_USER_CODE         in VARCHAR2, --用户
                                  OUT_CEN_INV_QTY      out NUMBER, --中心仓库存
                                  OUT_HQ_INV_QTY       out NUMBER, --基地仓库存
                                  OUT_CAPACITY_QTY     out NUMBER, --当前剩余产能数量（预计可供货量）
                                  OUT_ASSIGN_QTY       out NUMBER, --月度剩余分配量
                                  OUT_RESULT           out VARCHAR2 --成功返回SUCCESS，失败返回错误信息
                                  );
  
  ------------------------------------------------------------------------------------------
  ---- AUTHOR  : ex_dengjh
  -- CREATED : 2017-04-05
  -- PURPOSE : 获取产品严控标识及分配量
  ------------------------------------------------------------------------------------------
  Procedure p_Chk_Item_Capacity_and_assign(IN_ENTITY_ID        in NUMBER, --主体ID
                                           IN_PARAM_ID         in NUMBER, --产能检查参数集ID
                                           IN_SALES_CENTER_ID  in NUMBER, --中心ID
                                           IN_CUSTOMER_ID       IN NUMBER, --客户ID
                                           IN_USER_CODE        in VARCHAR2, --用户
                                           OUT_RESULT          out VARCHAR2, --返回结果，成功返回SUCCESS，否则返回错误信息
                                           OUT_CAP_STRICT_FLAG out VARCHAR2, --产能严控标志
                                           OUT_CHK_MSG         out VARCHAR2 --产能检查不通过时返回提示信息
                                           );    
  -----------------------------------------------------------------------------
  --更新来自CCS的库存水位
  -----------------------------------------------------------------------------
  PROCEDURE P_UPDATE_PLN_STOCK
  (
    IN_ENTITY_ID           IN NUMBER,--单据头ID
    P_RESULT               IN OUT NUMBER, --返回错误ID
    P_ERR_MSG              IN OUT VARCHAR2 --返回错误信息
  );
  
  -----------------------------------------------------------------------------
  --校验需求提交
  -----------------------------------------------------------------------------
  PROCEDURE P_CHECK_DEMAND_FORECAST(IN_CHK_BATCH_ID IN NUMBER, --校验批次ID
                                    OUT_RESULT      OUT VARCHAR2, --返回结果，成功返回SUCCESS，否则返回错误信息
                                    OUT_CHK_MSG     OUT VARCHAR2, --校验提示信息
                                    OUT_PROMPT	    OUT VARCHAR2,
                                    OUT_ITEM_CODE   OUT VARCHAR2
                                    );
  ----------------------------------------------------------------------
  -- Author  : lilh6
  -- Created : 2018-11-05
  -- Purpose : 获取价格,销售预测使用
  ----------------------------------------------------------------------
  Procedure p_Get_New_Item_Price(p_Acc_Id         In t_Customer_Account.Account_Id%Type, --账户ID
                                 p_Item_Code      In t_Bd_Item.Item_Code%Type, --产品编码
                                 p_Bill_Date      In Varchar2, --单据日期,YYYYMMDD
                                 p_Price_List_Id  In t_Bd_Price_List.Price_List_Id%Type, --价格列表ID
                                 p_Entity_Id      In Up_Org_Unit.Entity_Id%Type, --业务主体ID
                                 p_Price          Out Number, --返回价格
                                 p_Discount       Out Number, --返回折扣率
                                 p_Month_Discount Out Number, --返回月返
                                 p_Cx_Flag        Out Varchar2 --返回是否促销机
                                 );
  ----------------------------------------------------------------------
  -- Author  : lilh6
  -- Created : 2019-02-18
  -- Purpose : 代销单生成
  ----------------------------------------------------------------------
  Procedure p_Create_Intf_Dx_Order(p_Intf_Id     In Number, --代销单接口表订单头ID
                                   p_Appendix_Id In Varchar2, --附件id
                                   p_Result      Out Varchar2,
                                   p_Result_Num  Out Varchar2);
                                                                                                                                                                          
end PKG_PLN_INTF_CCS;
/

