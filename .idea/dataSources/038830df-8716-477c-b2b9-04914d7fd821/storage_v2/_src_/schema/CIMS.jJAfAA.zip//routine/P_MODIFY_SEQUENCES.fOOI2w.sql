create procedure p_modify_sequences is
  --更新各序列值的动态sql语句
  str_sql varchar2(4000);
  --是否修改成功,未发生异常返回true
  r boolean;


begin
  r := f_modify_sequence('s_bd_esb_log', 't_bd_esb_log', 'esb_log_id');  --示例
end p_modify_sequences;
/

