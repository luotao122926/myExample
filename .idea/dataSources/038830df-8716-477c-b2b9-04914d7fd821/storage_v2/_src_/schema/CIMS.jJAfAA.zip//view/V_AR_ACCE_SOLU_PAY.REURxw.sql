create view V_AR_ACCE_SOLU_PAY as
select   l.cash_receipt_lines_id || l.sales_main_type_id id,
         l.cash_receipt_lines_id, l.cash_receipt_id, l.amount,
         sum (nvl (acc.solution_pay_amount, 0)) solution_amount,
         l.amount - sum (nvl (acc.solution_pay_amount, 0)) un_solution_amount,
         l.sales_main_type_id, l.sales_main_type_code, l.sales_main_type_name,
         l.entity_id, l.remark,'' DELIVERY_NOTICE_CODE
    from cims.t_ar_cash_receipt_lines l left join cims.t_ar_acce_solu_pay acc
         on l.cash_receipt_lines_id = acc.cash_receipt_lines_id
       and acc.solution_pay_status in ('2', '3')
   where exists (
            select h.receipt_method_id
              from cims.t_ar_cash_receipt_headers h,
                   cims.t_ar_receipt_methods m
             where l.cash_receipt_id = h.cash_receipt_id
               and h.receipt_status_id not in (1, 2)
               and h.receipt_method_id = m.receipt_method_id
               and m.receipt_type = '3')
group by l.cash_receipt_lines_id,
         l.cash_receipt_id,
         l.amount,
         l.sales_main_type_id,
         l.sales_main_type_code,
         l.sales_main_type_name,
         l.entity_id,
         l.remark
/

comment on table V_AR_ACCE_SOLU_PAY is '三方承兑解付明细视图'
/

comment on column V_AR_ACCE_SOLU_PAY.ID is 'id'
/

comment on column V_AR_ACCE_SOLU_PAY.CASH_RECEIPT_LINES_ID is '收款单据行ID'
/

comment on column V_AR_ACCE_SOLU_PAY.CASH_RECEIPT_ID is '收款单据ID'
/

comment on column V_AR_ACCE_SOLU_PAY.AMOUNT is '金额'
/

comment on column V_AR_ACCE_SOLU_PAY.SOLUTION_AMOUNT is '已解付金额'
/

comment on column V_AR_ACCE_SOLU_PAY.UN_SOLUTION_AMOUNT is '未解付金额'
/

comment on column V_AR_ACCE_SOLU_PAY.SALES_MAIN_TYPE_ID is '营销大类ID'
/

comment on column V_AR_ACCE_SOLU_PAY.SALES_MAIN_TYPE_CODE is '营销大类编码'
/

comment on column V_AR_ACCE_SOLU_PAY.SALES_MAIN_TYPE_NAME is '营销大类名称'
/

comment on column V_AR_ACCE_SOLU_PAY.ENTITY_ID is '主体ID'
/

comment on column V_AR_ACCE_SOLU_PAY.REMARK is '备注'
/

comment on column V_AR_ACCE_SOLU_PAY.DELIVERY_NOTICE_CODE is '提货通知单号（解付单号）'
/

