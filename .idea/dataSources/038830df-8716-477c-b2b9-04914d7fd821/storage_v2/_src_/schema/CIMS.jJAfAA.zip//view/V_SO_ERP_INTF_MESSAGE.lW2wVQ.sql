create view V_SO_ERP_INTF_MESSAGE as
SELECT ('' || OL.OE_LINES_ID || '-' || BD.BACK_DETAIL_ID) AS KID, --唯一值字段
       OL.OE_LINES_ID,
       BD.BACK_DETAIL_ID,
       SH.SO_NUM, --单据号
       SH.SO_DATE, --单据日期
       SH.BILL_TYPE_NAME, --单据类型
       --sh.biz_src_bill_type_name,
       SH.SO_STATUS, --单据状态
       OH.GEN_TRX_STATUS, --so生成状态
       OH.GEN_TRX_DATE,
       OH.INV_TRX_STATUS, --so挑库状态
       OH.INV_TRX_DATE,
       OH.UPDATE_TRX_STATUS, --so变更
       OH.UPDATE_TRX_DATE,
       OH.SHIP_TRX_STATUS, --发运确定
       OH.SHIP_TRX_DATE,
       OH.BOOK_TRX_STATUS, --登记
       OH.BOOK_TRX_DATE,
       OH.RMA_RECEIVE_TRX_STATUS, --RMA接收
       OH.RMA_RECEIVE_TRX_DATE,
       BD.SOURCE_ID1             AS CIMS_SO_ID, --cims系统的销售单据id
       BD.SOURCE_ID2             AS CIMS_SO_LINE_ID, --cims系统的销售单据行id
       BD.SOURCE_ID3             AS CIMS_SO_LINE_DETAIL_ID, --cims系统的销售单据明细id
       OL.ORDERED_ITEM           AS ITEM_CODE, --产品编码
       SL.ITEM_NAME, --产品名称
       OL.ORDERED_QUANTITY       AS ITEM_QTY, --产品数量
       OL.ORDER_QUANTITY_UOM     AS ITEM_UOM, --产品单位
       OL.UNIT_SELLING_PRICE     AS ITEM_SETTLE_PRICE, --产品结算价格
       OL.ITEM_TYPE_CODE, --erp产品类型编码
       OL.RETURN_REASON_CODE, --提货原因编码
       BD.TARGET_ID1             AS ERP_SO_ID, --erp系统订单id
       BD.TARGET_ID2             AS ERP_SO_LINE_ID, --erp系统订单行id
       BD.TARGET_ID3             AS ERP_SO_LINE_DETAIL_ID, --erp系统订单行明细id
       BD.STATUS                 AS ERP_RETURN_STATUS, --erp系统返回状态
       BD.ERROR_CODE             AS ERP_ERROR_CODE, --erp系统返回错误编码
       BD.ERROR_MESSAGE          AS ERP_ERROR_MESSAGE, --erp系统返回错误信息
       SH.ERP_ORDER_HEADER_ID    AS RT_ORDER_ID, --关联订单ID add by chen.wj 20150317
       SH.ERP_LOGIST_HEADER_ID   AS RT_LOGIST_ID, --关联物流订单ID add by chen.wj 20150317
       OH.GEN_REQUEST_ID, --SO生成请求ESB流水ID add by chen.wj 20150317
       OH.UPDATE_REQUEST_ID, --SO变更请求ESB流水ID add by chen.wj 20150317
       OH.RMA_RECEIVE_REQUEST_ID, --RMA接收请求ESB流水ID add by chen.wj 20150317
       OH.ERROR_MSG              AS REQUEST_ESB_ERRMSG, --请求ESB错误信息 add by chen.wj 20150317
       SH.ENTITY_ID
  FROM INTF_OE_HEADERS_IFACE_ALL OH --接口头表
       ,INTF_OE_LINES_IFACE_ALL OL --接口行表
       ,T_SO_HEADER SH
       ,T_SO_LINE SL
       ,T_BD_ESB_RESULT_BACK_DETAIL BD --ESB异步接口返回结果表明细
 WHERE OL.OE_HEADERS_ID = OH.OE_HEADERS_ID
 AND SH.SO_NUM = OH.ORDER_NUMBER
 AND OL.ORIG_SYS_LINE_REF = SL.SO_LINE_ID
 AND SH.SO_HEADER_ID = SL.SO_HEADER_ID
 AND BD.SOURCE_ID1 = OH.ORIG_SYS_DOCUMENT_REF(+)
 WITH READ ONLY
/

