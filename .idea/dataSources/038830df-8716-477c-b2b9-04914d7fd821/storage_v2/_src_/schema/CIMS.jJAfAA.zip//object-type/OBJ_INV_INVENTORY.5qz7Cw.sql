create TYPE "OBJ_INV_INVENTORY" As Object
(
  INVENTORY_ID             NUMBER,
  INVENTORY_CODE           VARCHAR2(100),
  DISTRICT_ID              NUMBER,
  DISTRICT_CODE            VARCHAR2(32)
)
/

