create PACKAGE BODY PKG_BD_PRICE_CMS IS

  -----------------------------------------------------------------------------
  --    定制价格列表插入到接口头表    --add by liangym2
  -----------------------------------------------------------------------------
  PROCEDURE PRC_LIST_TO_INTF(IN_ENTITY_ID     IN NUMBER, --主体ID
                             IN_PRICE_LIST_ID IN NUMBER, --价格列表ID
                             IN_PRICE_ADJ_ID  IN OUT NUMBER, --价格调整ID
                             IS_SOURCE_TYPE   IN VARCHAR2, --价格调整来源类型 空 价格列表通过 0 价格列表调整通过 1 多价格列表批量调整通过- 1全量同步
                             OS_MESSAGE       OUT VARCHAR2, --返回提示信息
                             OS_PRE_FIELD01   OUT VARCHAR2, --预留参数
                             OS_PRE_FIELD02   OUT VARCHAR2, --预留参数
                             OS_PRE_FIELD03   OUT VARCHAR2, --预留参数
                             OS_PRE_FIELD04   OUT VARCHAR2, --预留参数
                             OS_PRE_FIELD05   OUT VARCHAR2, --预留参数
                             OS_PRE_FIELD06   OUT VARCHAR2) IS
    --VN_INTF_LIST_ID NUMBER;
  BEGIN
    IF (0 < IN_PRICE_LIST_ID AND
       (IS_SOURCE_TYPE IS NULL OR '-1' = IS_SOURCE_TYPE)) OR
       (('0' = IS_SOURCE_TYPE OR '1' = IS_SOURCE_TYPE) AND
       0 < IN_PRICE_ADJ_ID) THEN
      DELETE FROM INTF_PRICE_TO_CMS DF
       WHERE DF.ENTITY_ID = IN_ENTITY_ID
         AND DF.PRICE_LIST_ID = NVL(IN_PRICE_LIST_ID, DF.PRICE_LIST_ID)
         AND DF.PRICE_ADJUST_ID = NVL(IN_PRICE_ADJ_ID, 0)
         AND DF.MODIFY_SOURCE = NVL(IS_SOURCE_TYPE, 'N');
      IF '-1' = IS_SOURCE_TYPE THEN
        SELECT SEQ_BD_INTF_PRICE_ID.NEXTVAL INTO IN_PRICE_ADJ_ID FROM DUAL;
      END IF;
    
      INSERT INTO INTF_PRICE_TO_CMS
        (INTF_LIST_ID,
         PRICE_LIST_ID,
         LIST_NAME,
         LIST_TYPE,
         LIST_DESC,
         BEGIN_DATE,
         END_DATE,
         CREATED_BY,
         CREATION_DATE,
         LAST_UPDATED_BY,
         LAST_UPDATE_DATE,
         ENTITY_ID,
         ACTIVE_FLAG,
         RESPONSE_TYPE,
         PRICE_ADJUST_ID,
         MODIFY_SOURCE)
        SELECT SEQ_BD_INTF_PRICE_ID.NEXTVAL,
               PRICE_LIST_ID,
               LIST_NAME,
               LIST_TYPE,
               LIST_DESC,
               BEGIN_DATE,
               END_DATE,
               CREATED_BY,
               CREATION_DATE,
               LAST_UPDATED_BY,
               LAST_UPDATE_DATE,
               ENTITY_ID,
               ACTIVE_FLAG,
               'I',
               NVL(IN_PRICE_ADJ_ID, 0),
               NVL(IS_SOURCE_TYPE, 'N')
          FROM T_BD_PRICE_LIST L
         WHERE ((L.PRICE_LIST_ID = IN_PRICE_LIST_ID AND
               (IS_SOURCE_TYPE IS NULL OR '-1' = IS_SOURCE_TYPE)) OR
               ('0' = IS_SOURCE_TYPE AND
               L.PRICE_LIST_ID =
               (SELECT AD.PRICE_LIST_ID
                    FROM T_BD_PRICE_ADJUST AD
                   WHERE AD.ADJUST_LIST_ID = IN_PRICE_ADJ_ID
                     AND AD.ENTITY_ID = IN_ENTITY_ID)) OR
               ('1' = IS_SOURCE_TYPE AND
               L.PRICE_LIST_ID IN
               (SELECT DISTINCT MD.LIST_ID
                    FROM T_BD_MULTI_PRICE_MODIFY_DETAIL MD
                   WHERE MD.MODIFY_LIST_ID = IN_PRICE_ADJ_ID
                     AND MD.ENTITY_ID = IN_ENTITY_ID)))
           AND L.ENTITY_ID = IN_ENTITY_ID
           --AND L.LIST_TYPE IN ('24', '25', '26', '27')
           --BD_PRICE_LIST_TYPE_FILTER add by liangym2 2018-4-11 添加价格列表类型级联 避免后续增加
           AND L.LIST_TYPE IN (SELECT CL.CODE_VALUE FROM V_UP_CODELIST CL WHERE CL.CODETYPE='BD_PRICE_LIST_TYPE'
           --
           AND (CL.ENTITY_ID IS NULL OR CL.ENTITY_ID = IN_ENTITY_ID)
           --级联属性为CMS
           AND CL.FILTER = 'CMS'
           )
        --‘分销商定制价’、‘代理商定制价’、‘运营商定制价’、‘直营商定制价’
        --ORDER BY L.PRICE_LIST_ID
        --
        ;
      IF 0 < SQL%ROWCOUNT THEN
        OS_PRE_FIELD01 := 'CMS';
      END IF;
    END IF;
    OS_MESSAGE := 'SUCCESS';
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      OS_MESSAGE := '定制价格列表插入到接口头表异常：' || ',' || IN_PRICE_LIST_ID || ',' ||
                    IN_PRICE_ADJ_ID || ',' || IS_SOURCE_TYPE || '[SQLCODE：' ||
                    SQLCODE || '，MSG：' || SQLERRM || ']';
  END PRC_LIST_TO_INTF;
  -----------------------------------------------------------------------------
  --    定制价格列表插入到接口行表    --add by liangym2
  -----------------------------------------------------------------------------
  PROCEDURE PRC_LINE_TO_INTF(IN_ENTITY_ID     IN NUMBER, --主体ID
                             IN_PRICE_LIST_ID IN NUMBER, --价格列表ID
                             IN_PRICE_ADJ_ID  IN NUMBER, --价格调整ID
                             IS_SOURCE_TYPE   IN VARCHAR2, --价格调整来源类型
                             OS_MESSAGE       OUT VARCHAR2, --返回提示信息
                             OS_PRE_FIELD01   OUT VARCHAR2, --预留参数
                             OS_PRE_FIELD02   OUT VARCHAR2, --预留参数
                             OS_PRE_FIELD03   OUT VARCHAR2, --预留参数
                             OS_PRE_FIELD04   OUT VARCHAR2, --预留参数
                             OS_PRE_FIELD05   OUT VARCHAR2, --预留参数
                             OS_PRE_FIELD06   OUT VARCHAR2) IS
  BEGIN
    INSERT INTO INTF_PRICE_LINE_TO_CMS
      (INTF_LINE_ID,
       INTF_LIST_ID,
       PRICE_LINE_ID,
       PRICE_LIST_ID,
       ITEM_ID,
       ITEM_CODE,
       ITEM_NAME,
       COMPETITE_ATTR,
       CHANNEL_ATTR,
       UNIT_CODE,
       LIST_PRICE,
       FLOOR_PRICE,
       COST_PRICE,
       RETAIL_PRICE,
       DISCOUNT,
       BEGIN_DATE,
       END_DATE,
       CREATED_BY,
       CREATION_DATE,
       LAST_UPDATED_BY,
       LAST_UPDATE_DATE,
       REMARK,
       ENTITY_ID,
       ACTIVE_FLAG,
       RESPONSE_TYPE)
      SELECT SEQ_BD_INTF_PRICE_ID.NEXTVAL,
             DF.INTF_LIST_ID,
             LL.PRICE_LINE_ID,
             DF.PRICE_LIST_ID,
             LL.ITEM_ID,
             LL.ITEM_CODE,
             LL.ITEM_NAME,
             LL.COMPETITE_ATTR,
             LL.CHANNEL_ATTR,
             LL.UNIT_CODE,
             LL.LIST_PRICE,
             LL.FLOOR_PRICE,
             LL.COST_PRICE,
             LL.RETAIL_PRICE,
             LL.DISCOUNT,
             LL.BEGIN_DATE,
             LL.END_DATE,
             LL.CREATED_BY,
             LL.CREATION_DATE,
             LL.LAST_UPDATED_BY,
             LL.LAST_UPDATE_DATE,
             LL.REMARK,
             LL.ENTITY_ID,
             LL.ACTIVE_FLAG,
             'I'
        FROM INTF_PRICE_TO_CMS DF
       INNER JOIN T_BD_PRICE_LINE LL
          ON (LL.ENTITY_ID = IN_ENTITY_ID AND
             LL.PRICE_LIST_ID = DF.PRICE_LIST_ID)
       WHERE DF.ENTITY_ID = IN_ENTITY_ID
         AND DF.PRICE_LIST_ID = NVL(IN_PRICE_LIST_ID, DF.PRICE_LIST_ID)
         AND DF.PRICE_ADJUST_ID = NVL(IN_PRICE_ADJ_ID, 0)
         AND DF.MODIFY_SOURCE = NVL(IS_SOURCE_TYPE, 'N');
    --IF '-1' <> IS_SOURCE_TYPE THEN
    INSERT INTO INTF_PRICE_LINE_TO_CMS
      (INTF_LINE_ID,
       INTF_LIST_ID,
       PRICE_LINE_ID,
       PRICE_LIST_ID,
       ITEM_ID,
       ITEM_CODE,
       ITEM_NAME,
       COMPETITE_ATTR,
       CHANNEL_ATTR,
       UNIT_CODE,
       LIST_PRICE,
       FLOOR_PRICE,
       COST_PRICE,
       RETAIL_PRICE,
       DISCOUNT,
       BEGIN_DATE,
       END_DATE,
       CREATED_BY,
       CREATION_DATE,
       LAST_UPDATED_BY,
       LAST_UPDATE_DATE,
       REMARK,
       ENTITY_ID,
       ACTIVE_FLAG,
       RESPONSE_TYPE)
      SELECT SEQ_BD_INTF_PRICE_ID.NEXTVAL,
             DF.INTF_LIST_ID,
             LL.PRICE_LINE_ID,
             DF.PRICE_LIST_ID,
             LL.ITEM_ID,
             LL.ITEM_CODE,
             LL.ITEM_NAME,
             LL.COMPETITE_ATTR,
             LL.CHANNEL_ATTR,
             LL.UNIT_CODE,
             LL.LIST_PRICE,
             LL.FLOOR_PRICE,
             LL.COST_PRICE,
             LL.RETAIL_PRICE,
             LL.DISCOUNT,
             LL.BEGIN_DATE,
             LL.END_DATE,
             LL.CREATED_BY,
             LL.CREATION_DATE,
             LL.LAST_UPDATED_BY,
             LL.LAST_UPDATE_DATE,
             LL.REMARK,
             LL.ENTITY_ID,
             'N', --删除的有效标识都是N
             --LL.ACTIVE_FLAG,
             'I'
        FROM INTF_PRICE_TO_CMS DF
       INNER JOIN T_BD_PRICE_LINE_DL LL
          ON (LL.ENTITY_ID = IN_ENTITY_ID AND
             LL.PRICE_LIST_ID = DF.PRICE_LIST_ID)
       WHERE DF.ENTITY_ID = IN_ENTITY_ID
         AND DF.PRICE_LIST_ID = NVL(IN_PRICE_LIST_ID, DF.PRICE_LIST_ID)
         AND DF.PRICE_ADJUST_ID =
             DECODE(IS_SOURCE_TYPE,
                     '-1',
                     DF.PRICE_ADJUST_ID,
                     NVL(IN_PRICE_ADJ_ID, 0))
         AND DF.MODIFY_SOURCE = NVL(IS_SOURCE_TYPE, 'N');
    --END IF;
    OS_MESSAGE := 'SUCCESS';
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      OS_MESSAGE := '定制价格列表插入到接口行表异常：' || ',' || IN_PRICE_LIST_ID || ',' ||
                    IN_PRICE_ADJ_ID || ',' || IS_SOURCE_TYPE || '[SQLCODE：' ||
                    SQLCODE || '，MSG：' || SQLERRM || ']';
  END PRC_LINE_TO_INTF;

END PKG_BD_PRICE_CMS;
/

