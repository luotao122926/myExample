create PACKAGE BODY PKG_CREDIT_CYCLE_DELAYPAY IS

  /*
  *  获取营销大类编码（客户经营产品中第一个信用等级最高的营销大类）
  */
  FUNCTION F_GET_SALES_MAIN_TYPE(P_ENTITY_ID   NUMBER, --客户ID
                                 P_CUSTOMER_ID NUMBER --主体ID
                                 ) RETURN P_CURSOR IS
    V_SALES_MAIN_TYPE   VARCHAR2(32);
    V_LEVEL             NUMBER := 0;
    V_TWELVE_AMOUNT     NUMBER := 0; --客户前12个月销售金额
    V_TWELVE_AMOUNT_CUS NUMBER := 0; --营销大类对应的客户前12个月销售金额
    V_MAIN_TYPE_CURSOR  P_CURSOR;
    V_SYS_PARAM         VARCHAR2(32); --是否按品类控制额度系统参数
  
    CURSOR C_MAIN_TYPE_LEVEL IS
      SELECT T.SALES_MAIN_TYPE_CODE,
             NVL(T.CUSTOM_CREDIT_LEVEL, 0) CREDIT_LEVEL
        FROM CIMS.T_CUSTOMER_SALES_MAIN_TYPE T
       WHERE T.ENTITY_ID = P_ENTITY_ID
         AND T.CUSTOM_ID = P_CUSTOMER_ID
       ORDER BY NVL(T.CUSTOM_CREDIT_LEVEL, 0) DESC;
    MAIN_TYPE_LEVEL_ROW C_MAIN_TYPE_LEVEL%ROWTYPE; --配置项分组客户数据
  
  BEGIN
    --获取系统参数，是否按品类控制额度
    PKG_BD.P_GET_PARAMETER_VALUE(P_CONFIG_CODE => 'if_control_by_type',
                                 P_ENTITY_ID   => P_ENTITY_ID,
                                 P_UNIT_ID     => '',
                                 P_CUSTOMER_ID => '',
                                 P_PARAM_VALUE => V_SYS_PARAM);
    IF V_SYS_PARAM = 'Y' THEN
      BEGIN
        OPEN V_MAIN_TYPE_CURSOR FOR
          SELECT T.SALES_MAIN_TYPE_CODE
            FROM CIMS.T_CUSTOMER_SALES_MAIN_TYPE T
           WHERE T.ENTITY_ID = P_ENTITY_ID
             AND T.CUSTOM_ID = P_CUSTOMER_ID
             AND PKG_CREDIT_TOOLS.FUN_GET_SALES_AMOUNT_BY_DATE(P_ENTITY_ID       => P_ENTITY_ID,
                                                               P_CUSTOMER_ID     => P_CUSTOMER_ID,
                                                               P_BEGIN_DATE      => TO_CHAR(ADD_MONTHS(TRUNC(SYSDATE,
                                                                                                             'MM'),
                                                                                                       -12),
                                                                                            'YYYYMMDD'),
                                                               P_END_DATE        => TO_CHAR(TRUNC(SYSDATE,
                                                                                                  'MM') - 1,
                                                                                            'YYYYMMDD'),
                                                               P_SALES_MAIN_TYPE => T.SALES_MAIN_TYPE_CODE) > 0;
      
        RETURN V_MAIN_TYPE_CURSOR;
      END;
    ELSE
      FOR MAIN_TYPE_LEVEL_ROW IN C_MAIN_TYPE_LEVEL LOOP
        BEGIN
          --获取前12个月销售金额
          SELECT PKG_CREDIT_TOOLS.FUN_GET_SALES_AMOUNT_BY_DATE(P_ENTITY_ID       => P_ENTITY_ID,
                                                               P_CUSTOMER_ID     => P_CUSTOMER_ID,
                                                               P_BEGIN_DATE      => TO_CHAR(ADD_MONTHS(TRUNC(SYSDATE,
                                                                                                             'MM'),
                                                                                                       -12),
                                                                                            'YYYYMMDD'),
                                                               P_END_DATE        => TO_CHAR(TRUNC(SYSDATE,
                                                                                                  'MM') - 1,
                                                                                            'YYYYMMDD'),
                                                               P_SALES_MAIN_TYPE => MAIN_TYPE_LEVEL_ROW.SALES_MAIN_TYPE_CODE)
            INTO V_TWELVE_AMOUNT_CUS
            FROM DUAL;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            V_ERROR_INFO        := PKG_BD.F_ADD_ERROR_LOG('PKG_CREDIT_CYCLE_DELAYPAY.F_GET_SALES_MAIN_TYPE',
                                                          SQLCODE,
                                                          SUBSTR('获取客户前12个月销售金额（客户可提货金额）为空，主体' ||
                                                                 P_ENTITY_ID ||
                                                                 '、客户' ||
                                                                 P_CUSTOMER_ID ||
                                                                 '、大类' ||
                                                                 MAIN_TYPE_LEVEL_ROW.SALES_MAIN_TYPE_CODE ||
                                                                 '，请检查！' ||
                                                                 SQLERRM,
                                                                 1,
                                                                 240) ||
                                                          SQLERRM);
            V_TWELVE_AMOUNT_CUS := 0;
          WHEN OTHERS THEN
            V_ERROR_INFO        := PKG_BD.F_ADD_ERROR_LOG('PKG_CREDIT_CYCLE_DELAYPAY.F_GET_SALES_MAIN_TYPE',
                                                          SQLCODE,
                                                          SUBSTR('获取客户前12个月销售金额（客户可提货金额）失败，主体' ||
                                                                 P_ENTITY_ID ||
                                                                 '、客户' ||
                                                                 P_CUSTOMER_ID ||
                                                                 '、大类' ||
                                                                 MAIN_TYPE_LEVEL_ROW.SALES_MAIN_TYPE_CODE ||
                                                                 '，请检查！' ||
                                                                 SQLERRM,
                                                                 1,
                                                                 240) ||
                                                          SQLERRM);
            V_TWELVE_AMOUNT_CUS := 0;
        END;
        --查询客户等级、大类信息 ，比较等级，取最高等级；若等级相等，则取对应可提货金额最高的
        IF MAIN_TYPE_LEVEL_ROW.CREDIT_LEVEL > V_LEVEL THEN
          V_LEVEL           := MAIN_TYPE_LEVEL_ROW.CREDIT_LEVEL;
          V_TWELVE_AMOUNT   := V_TWELVE_AMOUNT_CUS;
          V_SALES_MAIN_TYPE := MAIN_TYPE_LEVEL_ROW.SALES_MAIN_TYPE_CODE;
        ELSIF MAIN_TYPE_LEVEL_ROW.CREDIT_LEVEL = V_LEVEL THEN
          IF V_TWELVE_AMOUNT < V_TWELVE_AMOUNT_CUS THEN
            V_SALES_MAIN_TYPE := MAIN_TYPE_LEVEL_ROW.SALES_MAIN_TYPE_CODE;
            V_TWELVE_AMOUNT   := V_TWELVE_AMOUNT_CUS;
          END IF;
        ELSE
          V_TWELVE_AMOUNT   := V_TWELVE_AMOUNT_CUS;
          V_SALES_MAIN_TYPE := MAIN_TYPE_LEVEL_ROW.SALES_MAIN_TYPE_CODE;
        END IF;
      END LOOP;
      OPEN V_MAIN_TYPE_CURSOR FOR
        SELECT V_SALES_MAIN_TYPE FROM DUAL;
      RETURN V_MAIN_TYPE_CURSOR;
    END IF;
  
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      RETURN NULL;
    WHEN OTHERS THEN
      V_ERROR_INFO := PKG_BD.F_ADD_ERROR_LOG('PKG_CREDIT_CYCLE_DELAYPAY.F_GET_SALES_BY_CREDIT_LINE',
                                             SQLCODE,
                                             SUBSTR('根据主体ID=' || P_ENTITY_ID ||
                                                    '和客户ID=' ||
                                                    P_CUSTOMER_ID ||
                                                    '查寻相应营销大类信息异常！请检查！' ||
                                                    SQLERRM,
                                                    1,
                                                    240) || SQLERRM);
  END;

  /*
  *   记录不能自动生成循环铺底的历史信息
  */
  PROCEDURE P_SAVE_CYCLE_DELAY_ERROR(P_ENTITY_ID   NUMBER, --主体ID
                                     P_CUSTOMER_ID NUMBER, --客户ID
                                     P_CENTER_ID   NUMBER, --营销中心ID
                                     P_CONFIG_ID   NUMBER, --配置ID
                                     P_ERROR_INFO  VARCHAR2 -- 错误信息
                                     ) IS
  BEGIN
  
    INSERT INTO CIMS.T_CREDIT_DELAYPAY_CYCLE_ERRO
      (ID,
       ENTITY_ID,
       CUSTOM_ID,
       CENTER_ID,
       CONFIG_ID,
       ERRO_INFO,
       CREATION_DATE,
       ATTRIBUTE1,
       ATTRIBUTE2,
       ATTRIBUTE3)
    VALUES
      (S_CREDIT_DELAYPAY_CYCLE_ERRO.NEXTVAL,
       P_ENTITY_ID,
       P_CUSTOMER_ID,
       P_CENTER_ID,
       P_CONFIG_ID,
       P_ERROR_INFO,
       SYSDATE,
       NULL,
       NULL,
       NULL);
  EXCEPTION
    WHEN OTHERS THEN
      V_ERROR_INFO := PKG_BD.F_ADD_ERROR_LOG('PKG_CREDIT_CYCLE_DELAYPAY.P_SAVE_CYCLE_DELAY_ERROR',
                                             SQLCODE,
                                             SUBSTR('记录循环铺底生成错误信息失败！请检查！' ||
                                                    SQLERRM,
                                                    1,
                                                    240) || SQLERRM);
  END;

  /*
  *   获取逾期期限
  */
  FUNCTION F_GET_CUST_DEADLINE(P_ENTITY_ID   NUMBER, --客户ID
                               P_CUSTOMER_ID NUMBER --主体ID
                               ) RETURN NUMBER IS
    V_OVERDUE_DAYS NUMBER := 0;
  BEGIN
    --测试，如果查询结果为空，是否会抛异常
    SELECT NVL(MAX(T.DEADLINE), 0)
      INTO V_OVERDUE_DAYS
      FROM T_CREDIT_RATING_CUSTOMER T
     WHERE T.MIDEA_MARKET_MODE IN
           (SELECT CB.COOPERATION_MODEL
              FROM T_CUSTOMER_BRAND CB
             WHERE CB.CUSTOMER_ID = P_CUSTOMER_ID
               AND CB.ACTIVE_FLAG = 'Active'
               AND T.ENTITY_ID = CB.ENTITY_ID)
       AND T.ENTITY_ID = P_ENTITY_ID;
    RETURN V_OVERDUE_DAYS;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      RETURN 0;
    WHEN OTHERS THEN
      V_ERROR_INFO := PKG_BD.F_ADD_ERROR_LOG('PKG_CREDIT_CYCLE_DELAYPAY.F_GET_CUST_DEADLINE',
                                             SQLCODE,
                                             SUBSTR('根据主体ID=' || P_ENTITY_ID ||
                                                    '和客户ID=' ||
                                                    P_CUSTOMER_ID ||
                                                    '查寻相应客户合作类型应收逾期天数异常！请检查！' ||
                                                    SQLERRM,
                                                    1,
                                                    240) || SQLERRM);
  END;

  /*
  *   获取逾期未还款标志
  */
  FUNCTION F_GET_OVERDUE_REPAYMENT(P_ENTITY_ID      NUMBER, --主体ID
                                   P_CUSTOMER_ID    NUMBER, --客户ID
                                   P_CENTER_ID      NUMBER, --中心ID
                                   P_MAIN_TYPE_CODE VARCHAR2 --大类
                                   ) RETURN NUMBER IS
    V_OVERDUE_FLAG NUMBER := 0;
  BEGIN
    SELECT COUNT(*)
      INTO V_OVERDUE_FLAG
      FROM CIMS.T_CREDIT_DELAYPAY L
     WHERE L.ENTITY_ID = P_ENTITY_ID
       AND L.CUSTOMER_ID = P_CUSTOMER_ID
       AND L.SALES_CENTER_ID = P_CENTER_ID
       AND L.SALES_MAIN_TYPE = P_MAIN_TYPE_CODE
       AND NVL(L.PAYED_FLAG, 1) <> '1';
    RETURN V_OVERDUE_FLAG;
  EXCEPTION
    WHEN OTHERS THEN
      V_ERROR_INFO := PKG_BD.F_ADD_ERROR_LOG('PKG_CREDIT_CYCLE_DELAYPAY.F_GET_OVERDUE_REPAYMENT',
                                             SQLCODE,
                                             SUBSTR('根据主体ID=' || P_ENTITY_ID ||
                                                    '、客户ID=' ||
                                                    P_CUSTOMER_ID || '、中心ID' ||
                                                    P_CENTER_ID ||
                                                    '查寻铺底行，是否还清标志异常！请检查！' ||
                                                    SQLERRM,
                                                    1,
                                                    240) || SQLERRM);
  END;

  /*
  *   获取客户可用信用额度 
  */
  FUNCTION F_GET_CUST_CAN_USE_AMOUNT(P_ENTITY_ID            NUMBER, --主体ID
                                     P_CUSTOMER_ID          NUMBER, --客户ID
                                     P_ACCOUNT_ID           NUMBER, --账户ID
                                     P_SALES_MAIN_TYPE_CODE VARCHAR2 --大类
                                     ) RETURN NUMBER IS
    V_GROUP_ID       NUMBER; --额度组ID
    V_CAN_USE_AMOUNT NUMBER := 0;
  BEGIN
    --获取额度组ID
    --2017-4-22 获取额度组增加账户ID liangym2
    V_GROUP_ID := PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(P_ENTITY_ID,
                                                         P_CUSTOMER_ID,
                                                         P_SALES_MAIN_TYPE_CODE,
                                                         P_ACCOUNT_ID);
    SELECT V.CREDIT_LINE
      INTO V_CAN_USE_AMOUNT
      FROM V_SALES_DELAY_ACCOUNT_AMOUNT V
     WHERE V.ENTITY_ID = P_ENTITY_ID
       AND V.CUSTOMER_ID = P_CUSTOMER_ID
       AND NVL(V.ACCOUNT_ID, P_ACCOUNT_ID) = P_ACCOUNT_ID
       AND NVL(V.CREDIT_GROUP_ID, V_GROUP_ID) = V_GROUP_ID
       AND V.SALES_MAIN_TYPE = P_SALES_MAIN_TYPE_CODE
       AND (V.ACCOUNT_ID IS NULL OR V.ACCOUNT_CODE IS NULL OR EXISTS
            (SELECT 1
               FROM T_CUSTOMER_ACCOUNT T
              WHERE T.ACCOUNT_ID = V.ACCOUNT_ID
                AND 1 = T.ACCOUNT_STATUS));
    RETURN V_CAN_USE_AMOUNT;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      RETURN 0;
    WHEN OTHERS THEN
      V_ERROR_INFO := PKG_BD.F_ADD_ERROR_LOG('PKG_CREDIT_CYCLE_DELAYPAY.P_GET_CUST_CAN_USE_AMOUNT',
                                             SQLCODE,
                                             SUBSTR('根据主体ID=' || P_ENTITY_ID ||
                                                    '、客户ID=' ||
                                                    P_CUSTOMER_ID || '、账户=' ||
                                                    P_ACCOUNT_ID || '、大类=' ||
                                                    P_SALES_MAIN_TYPE_CODE ||
                                                    '、额度组ID=' || V_GROUP_ID ||
                                                    '查寻可用信用额度异常！请检查！' ||
                                                    SQLERRM,
                                                    1,
                                                    240) || SQLERRM);
    
  END;

  /*
  *   获取账龄 
  */
  PROCEDURE P_GET_AGE(P_ENTITY_ID     NUMBER, --主体ID
                      P_CUSTOMER_CODE VARCHAR2, --客户编码
                      P_CENTER_CODE   VARCHAR2, --营销中心编码
                      P_ONE_AGE       OUT NUMBER, --1个月账龄
                      P_ONE_HALF_AGE  OUT NUMBER, --1.5个月账龄
                      P_TWO_AGE       OUT NUMBER, --2个月账龄
                      P_TWO_HALF_AGE  OUT NUMBER, --2.5个月账龄
                      P_THREE_AGE     OUT NUMBER, --3个月账龄
                      P_THREE_UP_AGE  OUT NUMBER, --3个月以上账龄
                      P_MESSAGE       OUT VARCHAR2) IS
  BEGIN
    P_MESSAGE := 'SUCCESS';
    SELECT SUM(MONTH1) ONEAGE,
           SUM(MONTH15) ONEHALFAGE,
           SUM(MONTH2) TWOAGE,
           SUM(MONTH25) TWOHALFAGE,
           SUM(MONTH3) THREEAGE,
           SUM((MONTH4 + MONTH5 + MONTH6 + MONTH7 + MONTH8 + MONTH9 +
               MONTH10 + MONTH11 + MONTH12 + MONTH13)) THREEUPAGE
      INTO P_ONE_AGE,
           P_ONE_HALF_AGE,
           P_TWO_AGE,
           P_TWO_HALF_AGE,
           P_THREE_AGE,
           P_THREE_UP_AGE
      FROM CIMS.T_SO_ACCOUNT_AGE_FREEZE T
     WHERE T.ENTITY_ID = P_ENTITY_ID
       AND T.FREEZE_DATE = TO_CHAR(TRUNC(SYSDATE, 'DD') - 1, 'YYYY-MM-DD')
       AND T.CUSTOMER_CODE = P_CUSTOMER_CODE
       AND T.SALES_CENTER_CODE = P_CENTER_CODE;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      P_ONE_AGE      := NULL;
      P_ONE_HALF_AGE := NULL;
      P_TWO_AGE      := NULL;
      P_TWO_HALF_AGE := NULL;
      P_THREE_AGE    := NULL;
      P_THREE_UP_AGE := NULL;
    WHEN OTHERS THEN
      P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_CREDIT_CYCLE_DELAYPAY.P_GET_AGE',
                                          SQLCODE,
                                          P_MESSAGE ||
                                          SUBSTR('根据主体' || P_ENTITY_ID ||
                                                 '、客户' || P_CUSTOMER_CODE || '中心' ||
                                                 P_CENTER_CODE ||
                                                 '查寻账龄异常！请检查！' || SQLERRM,
                                                 1,
                                                 240) || SQLERRM);
  END;

  /*
  *   获取年度任务
  */
  FUNCTION F_GET_YEAR_TASK(P_ENTITY_ID   NUMBER, --主体ID
                           P_CUSTOMER_ID NUMBER, --客户ID
                           P_CENTER_ID   NUMBER --营销中心ID
                           ) RETURN NUMBER IS
    V_YEAR_TASK NUMBER := 0;
  BEGIN
    SELECT D.DATA_VALUE
      INTO V_YEAR_TASK
      FROM CIMS.T_POL_POLICY_OUT_DATA D
     WHERE D.ENTITY_ID = P_ENTITY_ID
       AND D.CUSTOMER_ID = P_CUSTOMER_ID
       AND D.SALES_CENTER_ID = P_CENTER_ID
       AND TO_CHAR(D.DATA_DATE, 'YYYY-MM-DD') =
           TO_CHAR(TRUNC(SYSDATE, 'YYYY'), 'YYYY-MM-DD')
       AND D.OUT_DATA_TYPE =
           (SELECT U.CODE_VALUE
              FROM CIMS.UP_CODELIST U
             WHERE U.CODETYPE = 'POL_OUT_DATA_ITEM'
               AND U.CODE_NAME = '年度销售任务');
    RETURN V_YEAR_TASK;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      RETURN NULL;
    WHEN OTHERS THEN
      V_ERROR_INFO := PKG_BD.F_ADD_ERROR_LOG('PKG_CREDIT_CYCLE_DELAYPAY.P_GET_AGE',
                                             SQLCODE,
                                             SUBSTR('根据主体' || P_ENTITY_ID ||
                                                    '、客户' || P_CUSTOMER_ID || '中心' ||
                                                    P_CENTER_ID ||
                                                    '查寻年度销售任务异常！请检查！' ||
                                                    SQLERRM,
                                                    1,
                                                    240) || SQLERRM);
  END;

  /*
  *   本年累计完成金额 
  */
  FUNCTION F_GET_TOTAL_FINISH_AMOUNT(P_ENTITY_ID   NUMBER, --主体ID
                                     P_CUSTOMER_ID NUMBER, --客户ID
                                     P_CENTER_ID   NUMBER --营销中心ID
                                     ) RETURN NUMBER IS
    V_THIS_TOTAL_AMOUNT NUMBER := 0;
  BEGIN
    SELECT SUM(TE.PLUS_MINUS_FLAG * H.LIST_AMOUNT) AS LIST_AMOUNT
      INTO V_THIS_TOTAL_AMOUNT
      FROM CIMS.T_SO_HEADER             H,
           CIMS.T_SO_TYPE_EXTEND        TE,
           CIMS.T_SO_BILL_TYPE_RELATION TR
     WHERE H.BILL_TYPE_ID = TE.BILL_TYPE_ID
       AND H.BILL_TYPE_ID = TR.BILL_TYPE_ID
       AND TR.SRC_TYPE_CODE NOT IN ('1009', '1010')
       AND H.SO_DATE BETWEEN TRUNC(SYSDATE, 'YYYY') AND
           TRUNC(SYSDATE, 'MM') - 1
       AND H.ENTITY_ID = P_ENTITY_ID
       AND H.CUSTOMER_ID = P_CUSTOMER_ID
       AND H.SALES_CENTER_ID = P_CENTER_ID;
    RETURN V_THIS_TOTAL_AMOUNT;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      RETURN NULL;
    WHEN OTHERS THEN
      V_ERROR_INFO := PKG_BD.F_ADD_ERROR_LOG('PKG_CREDIT_CYCLE_DELAYPAY.F_GET_TOTAL_FINISH_AMOUNT',
                                             SQLCODE,
                                             SUBSTR('根据主体' || P_ENTITY_ID ||
                                                    '、客户' || P_CUSTOMER_ID || '中心' ||
                                                    P_CENTER_ID ||
                                                    '查寻本年累计完成金额异常！请检查！' ||
                                                    SQLERRM,
                                                    1,
                                                    240) || SQLERRM);
  END;

  /*
  *  获取销售大区
  */
  PROCEDURE P_GET_SALES_SAGION(P_ENTITY_ID   NUMBER, --主体ID
                               P_CUSTOMER_ID NUMBER, --客户ID
                               P_CENTER_ID   NUMBER, --中心ID
                               P_SAGION_ID   OUT NUMBER, --销售大区ID
                               P_SAGION_CODE OUT VARCHAR2, --销售大区编码
                               P_SAGION_NAME OUT VARCHAR2, --销售大区名称
                               P_MESSAGE     OUT VARCHAR2 --错误信息
                               ) IS
  BEGIN
    P_MESSAGE := 'SUCCESS';
    SELECT V.SALES_REGION_ID, V.SALES_REGION_CODE, V.SALES_REGION_NAME
      INTO P_SAGION_ID, P_SAGION_CODE, P_SAGION_NAME
      FROM V_BD_SALES_REGION V
      LEFT JOIN T_CUSTOMER_ORG O
        ON O.SALES_REGION_ID = V.SALES_REGION_ID
     WHERE O.ENTITY_ID = P_ENTITY_ID
       AND O.CUSTOMER_ID = P_CUSTOMER_ID
       AND O.SALES_CENTER_ID = P_CENTER_ID;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      P_MESSAGE := '根据主体' || P_ENTITY_ID || '、客户' || P_CUSTOMER_ID || '中心' ||
                   P_CENTER_ID || '查寻销售区域为空';
    WHEN OTHERS THEN
      V_ERROR_INFO := PKG_BD.F_ADD_ERROR_LOG('PKG_CREDIT_CYCLE_DELAYPAY.F_GET_TOTAL_FINISH_AMOUNT',
                                             SQLCODE,
                                             SUBSTR('根据主体' || P_ENTITY_ID ||
                                                    '、客户' || P_CUSTOMER_ID || '中心' ||
                                                    P_CENTER_ID ||
                                                    '查寻销售区域异常！请检查！' ||
                                                    SQLERRM,
                                                    1,
                                                    240) || SQLERRM);
  END;

  /*
  *  获取交叉铺底
  */
  FUNCTION F_GET_CROSS_DELAYPAY(P_ENTITY_ID   NUMBER, --主体ID
                                P_CUSTOMER_ID NUMBER, --客户ID
                                P_ACCOUNT_ID  NUMBER, --账户ID
                                P_ITEM_CLASS  VARCHAR2, --大类编码
                                P_BILL_TYPE   VARCHAR2, --单据类型
                                P_DELAY_TYPE  VARCHAR2, --铺底类型
                                P_APPLY_DATE  DATE, --申请日期
                                P_END_DATE    DATE --终止日期
                                ) RETURN NUMBER IS
    V_CROSS_COUNT  NUMBER := 0;
    V_ENTITY_GROUP T_BD_PARAM_LIST.DEFAULT_VALUE%TYPE;
  BEGIN
    --获取主体编码（经销商模式、销售公司模式）
    PKG_BD.P_GET_PARAMETER_VALUE('ar_entity_group',
                                 P_ENTITY_ID,
                                 null,
                                 null,
                                 V_ENTITY_GROUP);
    IF V_ENTITY_GROUP = 'XSGS' THEN
      BEGIN
        SELECT COUNT(*)
          INTO V_CROSS_COUNT
          FROM CIMS.T_CREDIT_DELAYPAY L
         WHERE L.ENTITY_ID = P_ENTITY_ID
           AND L.CUSTOMER_ID = P_CUSTOMER_ID
           AND L.ACCOUNT_ID = P_ACCOUNT_ID
           AND L.SALES_MAIN_TYPE = P_ITEM_CLASS
           AND ((P_APPLY_DATE BETWEEN L.REQUIS_DATE AND L.END_DATE) OR
               (P_END_DATE BETWEEN L.REQUIS_DATE AND L.END_DATE))
           AND L.BILL_TYPE_ID = P_BILL_TYPE
           AND L.DELAYPAY_TYPE = '1'
           AND L.BILL_STATUS <> '5'
           AND L.BILL_STATUS <> '6';
      END;
    ELSE
      BEGIN
        SELECT COUNT(*)
          INTO V_CROSS_COUNT
          FROM CIMS.T_CREDIT_DELAYPAY L
         WHERE L.ENTITY_ID = P_ENTITY_ID
           AND L.CUSTOMER_ID = P_CUSTOMER_ID
           AND L.ACCOUNT_ID = P_ACCOUNT_ID
           AND L.SALES_MAIN_TYPE = P_ITEM_CLASS
           AND ((P_APPLY_DATE BETWEEN L.REQUIS_DATE AND L.END_DATE) OR
               (P_END_DATE BETWEEN L.REQUIS_DATE AND L.END_DATE))
           AND L.DELAYPAY_TYPE = P_DELAY_TYPE
           AND L.BILL_STATUS <> '5'
           AND L.BILL_STATUS <> '6';
      END;
    END IF;
    RETURN V_CROSS_COUNT;
  EXCEPTION
    WHEN OTHERS THEN
      V_ERROR_INFO := PKG_BD.F_ADD_ERROR_LOG('PKG_CREDIT_CYCLE_DELAYPAY.F_GET_TOTAL_FINISH_AMOUNT',
                                             SQLCODE,
                                             SUBSTR('根据主体' || P_ENTITY_ID ||
                                                    '、客户' || P_CUSTOMER_ID || '账户' ||
                                                    P_ACCOUNT_ID || '大类' ||
                                                    P_ITEM_CLASS ||
                                                    '查寻交叉铺底异常！请检查！' ||
                                                    SQLERRM,
                                                    1,
                                                    240) || SQLERRM);
  END;

  /*
  *  获取客户前12个月销售金额（按账户汇总，金额< 0 则取0）
  */
  FUNCTION F_GET_SALES_AMOUNT_ACC_TOTAL(P_ENTITY_ID   NUMBER,
                                        P_CUSTOMER_ID NUMBER,
                                        P_BEGIN_DATE  VARCHAR2,
                                        P_END_DATE    VARCHAR2) RETURN NUMBER IS
    V_RESULT     NUMBER := 0;
    V_ACC_AMOUNT NUMBER := 0;
    CURSOR C_ACCOUNT IS
      SELECT T.ACCOUNT_ID
        FROM CIMS.T_CUSTOMER_ACCOUNT T
       WHERE T.ENTITY_ID = P_ENTITY_ID
         AND T.CUSTOMER_ID = P_CUSTOMER_ID
       GROUP BY T.ACCOUNT_ID;
    ACCOUNT_ROW C_ACCOUNT%ROWTYPE; --账户行
  BEGIN
    --获取当前客户下的所有账户
    FOR ACCOUNT_ROW IN C_ACCOUNT LOOP
      --根据主体、客户、账户获取前12个月销售金额
      V_ACC_AMOUNT := PKG_CREDIT_TOOLS.FUN_GET_SALES_AMOUNT_BY_ACC(P_ENTITY_ID,
                                                                   P_CUSTOMER_ID,
                                                                   P_BEGIN_DATE,
                                                                   P_END_DATE,
                                                                   ACCOUNT_ROW.ACCOUNT_ID);
      IF V_ACC_AMOUNT < 0 THEN
        V_ACC_AMOUNT := 0;
      END IF;
      --账户销售金额汇总
      V_RESULT := V_RESULT + V_ACC_AMOUNT;
    END LOOP;
    RETURN V_RESULT;
  END;

  --------------------------------- 铺底单生成 start ------------------------------------------------------------------
  /*
  * 铺底单据生成（单张）
  */
  PROCEDURE P_CREDIT_DELAYPAY_CREATE(P_ENTITY_ID               IN NUMBER, --主体ID
                                     P_CUSTOMER_ID             IN NUMBER, --客户ID
                                     P_CUSTOMER_CODE           IN T_CREDIT_DELAYPAY_CYCLE_CONFIG.CUSTOMER_CODE%TYPE, --客户编码
                                     P_CUSTOMER_NAME           IN T_CREDIT_DELAYPAY_CYCLE_CONFIG.CUSTOMER_CODE%TYPE, --客户名称
                                     P_CENTER_ID               IN NUMBER, --中心ID
                                     P_CENTER_CODE             IN T_CREDIT_DELAYPAY_CYCLE_CONFIG.SALES_CENTER_CODE%TYPE, --中心编码
                                     P_CENTER_NAME             IN T_CREDIT_DELAYPAY_CYCLE_CONFIG.SALES_CENTER_NAME%TYPE, --中心名称
                                     P_ACCOUNT_ID              IN NUMBER, --账户ID
                                     P_ACCOUNT_CODE            IN V_CUSTOMER_ACCOUNT_SALECENTER.ACCOUNT_CODE%TYPE, --账户编码
                                     P_ITEM_CODE               IN T_CUSTOMER_SALES_MAIN_TYPE.SALES_MAIN_TYPE_CODE%TYPE, --大类编码
                                     P_USE_AMOUNT              IN NUMBER, --可用信用额度
                                     P_ACC_TOTAL_TWELVE_AMOUNT IN NUMBER, --客户对应账户前12个销售金额总和
                                     P_MESSAGE                 OUT VARCHAR2 --成功返回'SUCCESS'，否则返回出错信息
                                     ) IS
  
    V_OVERDUE_DAYS         NUMBER; --逾期天数
    V_ACC_LAST_YEAR_AMOUNT NUMBER; --账户前12个月销售金额
    V_APPLY_AMOUNT         NUMBER; --申请金额
    V_ONE_AGE              NUMBER; --1个月账龄
    V_ONE_HALF_AGE         NUMBER; --1.5个月账龄
    V_TWO_AGE              NUMBER; --2个月账龄
    V_TWO_HALF_AGE         NUMBER; --2.5个月账龄
    V_THREE_AGE            NUMBER; --3个月账龄
    V_THREE_UP_AGE         NUMBER; --3个月以上账龄
    V_THIS_TOTAL_AMOUNT    NUMBER; --本年累计完成金额
    V_YEAR_TASK            T_POL_POLICY_OUT_DATA.DATA_VALUE%TYPE; --年度任务
    V_SAGION_ID            NUMBER; --销售大区ID
    V_SAGION_CODE          V_BD_SALES_REGION.SALES_REGION_CODE%TYPE; --销售大区编码
    V_SAGION_NAME          V_BD_SALES_REGION.SALES_REGION_NAME%TYPE; --销售大区名称
  
    V_CUR_DATE DATE; --系统时间
    V_END_DATE DATE; --终止日期
  
    V_S_HEAD_ID          NUMBER; --铺底头表主键序列值
    V_S_LINE_ID          NUMBER; --铺底行表主键序列值
    V_BILL_NUM           VARCHAR2(32); --铺底单据号
    V_UPDATE_AMOUNT_FLAG NUMBER; --更新客户款项返回错误ID
    V_EXSIST_CROSS_DELAY NUMBER; --存在交叉铺底数
    V_PAYED_COUNT        NUMBER; --是否还清
  
  BEGIN
    P_MESSAGE  := 'SUCCESS';
    V_CUR_DATE := TRUNC(SYSDATE, 'DD');
    V_END_DATE := ADD_MONTHS(TRUNC(SYSDATE, 'MM') - 1, 1);
    --必填项：营销大类、账户、销售区域、申请金额
    V_APPLY_AMOUNT := 0;
    --校验账户状态
    V_ERROR_INFO := PKG_CUSTOMER_PUB.F_CHECK_CUST_HAVE_FREEZING_MSG(P_ACTION_FLAG     => '01',
                                                                    P_CUSTOMER_ID     => P_CUSTOMER_ID,
                                                                    P_ENTITY_ID       => P_ENTITY_ID,
                                                                    P_SALES_CENTER_ID => P_CENTER_ID,
                                                                    P_ACCOUNT_ID      => P_ACCOUNT_ID);
    --记录不能生成循环铺底原因
    IF V_ERROR_INFO <> 'SUCCESS' THEN
      GOTO END3;
    END IF;
  
    --校验是否存在交叉铺底，若存在，则不生成铺底单据
    V_EXSIST_CROSS_DELAY := F_GET_CROSS_DELAYPAY(P_ENTITY_ID   => P_ENTITY_ID,
                                                 P_CUSTOMER_ID => P_CUSTOMER_ID,
                                                 P_ACCOUNT_ID  => P_ACCOUNT_ID,
                                                 P_ITEM_CLASS  => P_ITEM_CODE,
                                                 P_BILL_TYPE   => '4',
                                                 P_DELAY_TYPE  => '2',
                                                 P_APPLY_DATE  => V_CUR_DATE,
                                                 P_END_DATE    => V_END_DATE);
    IF V_EXSIST_CROSS_DELAY <> 0 THEN
      --记录不能生成循环铺底原因
      V_ERROR_INFO := '存在交叉铺底：主体' || P_ENTITY_ID || '、客户' || P_CUSTOMER_ID ||
                      '、账户' || P_ACCOUNT_ID || '、大类' || P_ITEM_CODE;
      GOTO END3;
    END IF;
  
    --校验是否逾期未还清
    V_PAYED_COUNT := F_GET_OVERDUE_REPAYMENT(P_ENTITY_ID      => P_ENTITY_ID,
                                             P_CUSTOMER_ID    => P_CUSTOMER_ID,
                                             P_CENTER_ID      => P_CENTER_ID,
                                             P_MAIN_TYPE_CODE => P_ITEM_CODE);
    IF V_EXSIST_CROSS_DELAY <> 0 THEN
      --记录不能生成循环铺底原因
      V_ERROR_INFO := '存在逾期未还清铺底：主体' || P_ENTITY_ID || '、客户' ||
                      P_CUSTOMER_ID || '、中心' || P_CENTER_ID || '、大类' ||
                      P_ITEM_CODE;
      GOTO END3;
    END IF;
  
    --获取销售大区
    P_GET_SALES_SAGION(P_ENTITY_ID   => P_ENTITY_ID,
                       P_CUSTOMER_ID => P_CUSTOMER_ID,
                       P_CENTER_ID   => P_CENTER_ID,
                       P_SAGION_ID   => V_SAGION_ID,
                       P_SAGION_CODE => V_SAGION_CODE,
                       P_SAGION_NAME => V_SAGION_NAME,
                       P_MESSAGE     => V_ERROR_INFO);
    --记录不能生成循环铺底原因
    IF V_ERROR_INFO <> 'SUCCESS' THEN
      GOTO END3;
    END IF;
    --获取申请金额（可用信用额度*销售金额占比）
    --账户对应的前12个月销售金额
    V_ACC_LAST_YEAR_AMOUNT := PKG_CREDIT_TOOLS.FUN_GET_SALES_AMOUNT_BY_ACC(P_ENTITY_ID   => P_ENTITY_ID,
                                                                           P_CUSTOMER_ID => P_CUSTOMER_ID,
                                                                           --系统日期的前12个月第一天
                                                                           P_BEGIN_DATE => TO_CHAR(ADD_MONTHS(TRUNC(SYSDATE,
                                                                                                                    'MM'),
                                                                                                              -12),
                                                                                                   'YYYYMMDD'),
                                                                           --系统日期的上个月最后一天
                                                                           P_END_DATE   => TO_CHAR(TRUNC(SYSDATE,
                                                                                                         'MM') - 1,
                                                                                                   'YYYYMMDD'),
                                                                           P_ACCOUNT_ID => P_ACCOUNT_ID);
  
    --计算申请金额、审批金额
    IF P_USE_AMOUNT = 0 THEN
      V_ERROR_INFO := '可用信用额度=0（主体' || P_ENTITY_ID || '、客户' ||
                      P_CUSTOMER_ID || '、账户' || P_ACCOUNT_ID || '、大类' ||
                      P_ITEM_CODE || '）';
      --必须有销售金额，才可以申请铺底，故此处不生成铺底单
      GOTO END3;
    ELSIF P_ACC_TOTAL_TWELVE_AMOUNT = 0 THEN
      V_ERROR_INFO := '客户前12个月销售金额=0（主体' || P_ENTITY_ID || '、客户' ||
                      P_CUSTOMER_ID || '、大类' || P_ITEM_CODE ||
                      '），即客户对应的所有账户累计12月销售金额=0，负数值按0累计';
      --必须有销售金额，才可以申请铺底，故此处不生成铺底单
      GOTO END3;
    ELSIF V_ACC_LAST_YEAR_AMOUNT = 0 THEN
      V_ERROR_INFO := '账户前12个月销售金额=0（主体' || P_ENTITY_ID || '、客户' ||
                      P_CUSTOMER_ID || '、账户' || P_ACCOUNT_ID || '）';
      --必须有销售金额，才可以申请铺底，故此处不生成铺底单
      GOTO END3;
    ELSE
      --申请金额=可用信用额度*账户销售金额占比
      V_APPLY_AMOUNT := ROUND(P_USE_AMOUNT * (V_ACC_LAST_YEAR_AMOUNT /
                              P_ACC_TOTAL_TWELVE_AMOUNT),
                              2);
    END IF;
  
    --非必填项，查询结果可以为空
    --本年累计完成金额
    V_THIS_TOTAL_AMOUNT := F_GET_TOTAL_FINISH_AMOUNT(P_ENTITY_ID   => P_ENTITY_ID,
                                                     P_CUSTOMER_ID => P_CUSTOMER_ID,
                                                     P_CENTER_ID   => P_CENTER_ID);
  
    --年度任务
    V_YEAR_TASK := F_GET_YEAR_TASK(P_ENTITY_ID   => P_ENTITY_ID,
                                   P_CUSTOMER_ID => P_CUSTOMER_ID,
                                   P_CENTER_ID   => P_CENTER_ID);
  
    --账龄
    P_GET_AGE(P_ENTITY_ID     => P_ENTITY_ID,
              P_CUSTOMER_CODE => P_CUSTOMER_CODE,
              P_CENTER_CODE   => P_CENTER_CODE,
              P_ONE_AGE       => V_ONE_AGE, --返回1个月账龄
              P_ONE_HALF_AGE  => V_ONE_HALF_AGE, --返回1.5个月账龄
              P_TWO_AGE       => V_TWO_AGE, --返回2个月账龄
              P_TWO_HALF_AGE  => V_TWO_HALF_AGE, --返回2.5个月账龄
              P_THREE_AGE     => V_THREE_AGE, --返回3个月账龄
              P_THREE_UP_AGE  => V_THREE_UP_AGE, --返回3.5个月账龄
              P_MESSAGE       => V_ERROR_INFO --返回错误新
              );
    --记录不能生成循环铺底原因
    IF V_ERROR_INFO <> 'SUCCESS' THEN
      GOTO END3;
    END IF;
  
    --获取逾期天数，用于计算还款日期
    V_OVERDUE_DAYS := F_GET_CUST_DEADLINE(P_ENTITY_ID   => P_ENTITY_ID,
                                          P_CUSTOMER_ID => P_CUSTOMER_ID);
  
    --获取头表主键序列
    SELECT S_CREDIT_DELAYPAY_HEAD.NEXTVAL INTO V_S_HEAD_ID FROM DUAL;
    --获取铺底单据号
    BEGIN
      V_BILL_NUM := PKG_BD.F_GET_BILL_NO(P_BILL_TYPE  => 'CreditDelayBillNum',
                                         P_PREFIX_ADD => Null,
                                         P_ENTITY_ID  => P_ENTITY_ID,
                                         P_USER_ID    => NULL);
    EXCEPTION
      WHEN OTHERS THEN
        V_ERROR_INFO := SUBSTRB('从序列获取铺底单据编码出错！请检查！' || SQLERRM,
                                1,
                                240);
        --记录不能生成循环铺底原因
        GOTO END3;
    END;
    BEGIN
      --插入铺底头
      INSERT INTO T_CREDIT_DELAYPAY_HEAD
        (BILL_HEAD_ID,
         BILL_NUM,
         ENTITY_ID,
         BILL_STATUS,
         CREATE_BY,
         CREATION_TIME,
         BILL_DATE,
         BILL_TYPE_ID,
         DELAYPAY_TYPE,
         REQUIS_DATE,
         END_DATE,
         PLANPAY_DATE,
         LAST_APPROVAL_TIME,
         VERSION,
         ATTRIBUTE1)
      VALUES
        (
         --主键，头ID
         V_S_HEAD_ID,
         --铺底单据号
         V_BILL_NUM,
         --主体ID
         P_ENTITY_ID,
         --单据状态，已审=‘3’
         '3',
         --制单人
         'program',
         --制单时间
         V_CUR_DATE,
         --单据日期
         V_CUR_DATE,
         --单据类型，循环铺底=‘4’
         '4',
         --铺底类型，铺底不跨月=‘2’
         '2',
         --申请日期
         V_CUR_DATE,
         --终止日期
         V_END_DATE,
         --还款日期（若逾期天数<>0，还款日期=申请日期+逾期天数；否则还款日期=终止日期）
         DECODE(V_OVERDUE_DAYS, 0, V_END_DATE, V_CUR_DATE + V_OVERDUE_DAYS),
         --最终审批时间
         V_CUR_DATE,
         --版本号
         0,
         '循环铺底系统自动生成');
    EXCEPTION
      WHEN OTHERS THEN
        P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_CREDIT_CYCLE_DELAYPAY.P_CREDIT_DELAYPAY_CREATE',
                                            SQLCODE,
                                            SUBSTRB('循环铺底插入头表出错！请检查！' ||
                                                    SQLERRM,
                                                    1,
                                                    240) || SQLERRM);
        --记录不能生成循环铺底原因
        V_ERROR_INFO := P_MESSAGE;
        GOTO END3;
    END;
  
    --获取铺底行主键序列
    SELECT S_CREDIT_DELAYPAY.NEXTVAL INTO V_S_LINE_ID FROM DUAL;
    --插入铺底行
    BEGIN
      INSERT INTO CIMS.T_CREDIT_DELAYPAY
        (BILL_ID,
         ENTITY_ID,
         BILL_NUM,
         BILL_STATUS,
         CREATE_BY,
         CREATION_TIME,
         BILL_DATE,
         BILL_TYPE_ID,
         CUSTOMER_ID,
         CUSTOMER_CODE,
         CUSTOMER_NAME,
         ACCOUNT_ID,
         ACCOUNT_CODE,
         SALES_CENTER_ID,
         SALES_CENTER_CODE,
         SALES_CENTER_NAME,
         SALES_REGION_ID,
         SALES_REGION_CODE,
         SALES_REGION_NAME,
         SALES_MAIN_TYPE,
         DELAYPAY_TYPE,
         REQUIS_DATE,
         END_DATE,
         PLANPAY_DATE,
         REQUIS_AMOUNT,
         APPROVALED_AMOUNT,
         APPROVAL_AMOUNT,
         LAST_APPROVAL_TIME,
         VERSION,
         BILL_HEAD_ID,
         YEAR_TASK,
         THIS_YEAR_TOTAL_FINISH_AMOUNT,
         ONE_AGE,
         ONE_HALF_AGE,
         TWO_AGE,
         TWO_HALF_AGE,
         THREE_AGE,
         THREE_UP_AGE)
      VALUES
        (
         --行ID
         V_S_LINE_ID,
         --主体
         P_ENTITY_ID,
         --单据行号
         V_BILL_NUM,
         --单据状态
         '3',
         --制单人
         'program',
         --制单时间
         V_CUR_DATE,
         --单据日期
         V_CUR_DATE,
         --单据类型
         '4',
         --客户ID
         P_CUSTOMER_ID,
         --客户编码
         P_CUSTOMER_CODE,
         --客户名称
         P_CUSTOMER_NAME,
         --账户ID
         P_ACCOUNT_ID,
         --账户编码
         P_ACCOUNT_CODE,
         --中心ID
         P_CENTER_ID,
         --中心编码
         P_CENTER_CODE,
         --中心名称
         P_CENTER_NAME,
         --销售大区ID
         V_SAGION_ID,
         --销售大区编码
         V_SAGION_CODE,
         --销售大区名称
         V_SAGION_NAME,
         --营销大类编码
         P_ITEM_CODE,
         --铺底类型，铺底（不跨月）=2
         '2',
         --申请日期
         V_CUR_DATE,
         --终止日期
         V_END_DATE,
         --还款日期（若逾期天数<>0，还款日期=申请日期+逾期天数；否则还款日期=终止日期）
         DECODE(V_OVERDUE_DAYS, 0, V_END_DATE, V_CUR_DATE + V_OVERDUE_DAYS),
         --申请金额
         V_APPLY_AMOUNT,
         --审批金额    
         V_APPLY_AMOUNT,
         --实际铺底金额    
         V_APPLY_AMOUNT,
         --最终审批时间
         V_CUR_DATE,
         --版本号
         0,
         --头ID
         V_S_HEAD_ID,
         --年度任务
         V_YEAR_TASK,
         --本年累计完成金额
         V_THIS_TOTAL_AMOUNT,
         --1个月账龄
         V_ONE_AGE,
         --1.5个月账龄
         V_ONE_HALF_AGE,
         --2个月账龄
         V_TWO_AGE,
         --2.5个月账龄
         V_TWO_HALF_AGE,
         --3个月账龄
         V_THREE_AGE,
         --3个月以上账龄
         V_THREE_UP_AGE);
    EXCEPTION
      WHEN OTHERS THEN
        P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_CREDIT_CYCLE_DELAYPAY.P_CREDIT_DELAYPAY_CREATE',
                                            SQLCODE,
                                            SUBSTRB('循环铺底插入行表出错！请检查！' ||
                                                    SQLERRM,
                                                    1,
                                                    240) || SQLERRM);
        --记录不能生成循环铺底原因
        V_ERROR_INFO := P_MESSAGE;
        GOTO END3;
    END;
  
    --减少客户款项中的铺底额度:
    --铺底单据不为临时铺底（铺底单据为常规铺底、超额铺底、循环铺底）时，p_action_type = 22；
    PKG_CREDIT_ACCOUNT_CONTROL.PRC_CREDIT_SALES_BILL(P_ENTITY_ID       => P_ENTITY_ID,
                                                     P_ACTION_TYPE     => '22',
                                                     P_Settlement_SUM  => V_APPLY_AMOUNT,
                                                     P_Discount_SUM    => NULL,
                                                     P_SALES_MAIN_TYPE => P_ITEM_CODE,
                                                     P_ACCOUNT_ID      => P_ACCOUNT_ID,
                                                     P_CUSTOMER_ID     => P_CUSTOMER_ID,
                                                     P_PROJ_NUMBER     => NULL,
                                                     P_CREATED_MODE    => NULL,
                                                     P_ORDER_ID        => V_S_LINE_ID,
                                                     P_ORDER_TYPE      => '4',
                                                     P_USERNAME        => 'program',
                                                     --输出参数
                                                     P_RESULT  => V_UPDATE_AMOUNT_FLAG,
                                                     P_ERR_MSG => V_ERROR_INFO);
  
    IF V_UPDATE_AMOUNT_FLAG <> 0 THEN
      V_ERROR_INFO := '主体' || P_ENTITY_ID || '、客户' || P_CUSTOMER_ID ||
                      '、账户' || P_ACCOUNT_ID || '、大类' || P_ITEM_CODE || '，' ||
                      V_ERROR_INFO;
      GOTO END3;
    ELSE
      P_MESSAGE := 'SUCCESS';
    END IF;
    <<END3>>
    P_MESSAGE := V_ERROR_INFO;
  END;
  --------------------------------- 铺底单生成 end ------------------------------------------------------

  --获取营销大类编码（客户经营产品中第一个信用等级最高的营销大类）
  FUNCTION F_GET_SALES_MAIN_TYPE_BY_LEVEL(P_ENTITY_ID   NUMBER, --客户ID
                                          P_CUSTOMER_ID NUMBER --主体ID
                                          ) RETURN VARCHAR2 IS
    V_SALES_MAIN_TYPE VARCHAR2(32);
    V_LEVEL           NUMBER := 0;
    CURSOR C_MAIN_TYPE_LEVEL IS
      SELECT T.SALES_MAIN_TYPE_CODE,
             NVL(T.CUSTOM_CREDIT_LEVEL, 0) CREDIT_LEVEL
        FROM CIMS.T_CUSTOMER_SALES_MAIN_TYPE T
       WHERE T.ENTITY_ID = P_ENTITY_ID
         AND T.CUSTOM_ID = P_CUSTOMER_ID
       ORDER BY NVL(T.CUSTOM_CREDIT_LEVEL, 0) DESC;
    MAIN_TYPE_LEVEL_ROW C_MAIN_TYPE_LEVEL%ROWTYPE; --配置项分组客户数据
  
  BEGIN
  
    FOR MAIN_TYPE_LEVEL_ROW IN C_MAIN_TYPE_LEVEL LOOP
      V_LEVEL := MAIN_TYPE_LEVEL_ROW.CREDIT_LEVEL;
    
    END LOOP;
    --测试，如果查询结果为空，是否会抛异常
    SELECT S.SALES_MAIN_TYPE_CODE
      INTO V_SALES_MAIN_TYPE
      FROM (SELECT T.SALES_MAIN_TYPE_CODE, NVL(T.CUSTOM_CREDIT_LEVEL, 0)
              FROM CIMS.T_CUSTOMER_SALES_MAIN_TYPE T
             WHERE T.ENTITY_ID = P_ENTITY_ID
               AND T.CUSTOM_ID = P_CUSTOMER_ID
             ORDER BY NVL(T.CUSTOM_CREDIT_LEVEL, 0) DESC) S
     WHERE ROWNUM = 1;
    --查询客户等级、大类信息
    --比较等级，取最高等级；若等级相等，则取对应可提货金额最高的
    RETURN V_SALES_MAIN_TYPE;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      RETURN NULL;
    WHEN OTHERS THEN
      V_ERROR_INFO := PKG_BD.F_ADD_ERROR_LOG('PKG_CREDIT_CYCLE_DELAYPAY.F_GET_SALES_BY_CREDIT_LINE',
                                             SQLCODE,
                                             SUBSTR('根据主体ID=' || P_ENTITY_ID ||
                                                    '和客户ID=' ||
                                                    P_CUSTOMER_ID ||
                                                    '查寻相应营销大类信息异常！请检查！' ||
                                                    SQLERRM,
                                                    1,
                                                    240) || SQLERRM);
  END;

  ------------------------------------循环铺底生成 start ------------------------------------------------
  /*
  *    循环生成铺底头、行
  *    1、根据循环铺底配置表，分组获取有效的主体、客户；
  *    2、根据主体，获取系统参数“if_control_by_type”，判断是否按品类控制额度；
  *    3、按品类控制，获取“前12个月销售提货金额”> 0 的营销大类（可能有1条或者多条）；
  *       3.1、循环铺底配置，获取有效的主体、客户、中心，加上营销大类，循环生成铺底单据（一条配置，生成多条铺底单）；
  *    4、不按品类控制，优先取客户信用等级最高的营销大类，如果信用等级相同取12个月销量最高的大类。（只有一条）；
  *       4.1、循环铺底配置，获取有效的主体、客户、中心，加上营销大类，生成铺底单据（一条配置，生成一条铺底单）；
  */
  PROCEDURE P_CREDIT_CYCLE_DELAYPAY_CREATE(P_MESSAGE OUT VARCHAR2 --成功返回'SUCCESS'，否则返回出错信息
                                           ) IS
    V_ENTITY_ID        NUMBER; --主体ID
    V_CUSTOMER_ID      NUMBER; --客户ID
    C_MAIN_TYPE_CURSOR P_CURSOR; --定义动态游标，营销大类
    R_MAIN_TYPE        T_CUSTOMER_SALES_MAIN_TYPE.SALES_MAIN_TYPE_CODE%TYPE;
  
    V_SALES_CENTER_ID         NUMBER; --中心ID
    V_ACCOUNT_ID              NUMBER; --账户ID
    V_ACCOUNT_CODE            V_CUSTOMER_ACCOUNT_SALECENTER.account_code%TYPE; --账户编码
    V_SALES_MAIN_TYPE_CODE    T_CUSTOMER_SALES_MAIN_TYPE.SALES_MAIN_TYPE_CODE%TYPE; --营销大类编码
    V_TOTAL_ACC_TWELVE_AMOUNT NUMBER; --客户所有账户累计的前12个月销售金额
    V_USE_AMOUNT              NUMBER; --可用信用额度
  
    --配置项分组客户数据
    CURSOR C_CYCLE_CUSTOM IS
      SELECT C.ENTITY_ID, C.CUSTOMER_ID
        FROM CIMS.T_CREDIT_DELAYPAY_CYCLE_CONFIG C
       WHERE C.START_DATE <= TRUNC(SYSDATE, 'DD')
         AND (C.END_DATE IS NULL OR C.END_DATE >= TRUNC(SYSDATE, 'DD'))
         AND C.ENTITY_ID IS NOT NULL
         AND C.CUSTOMER_ID IS NOT NULL
         AND C.SALES_CENTER_ID IS NOT NULL
       GROUP BY C.ENTITY_ID, C.CUSTOMER_ID;
    --配置项分组客户行数据    
    CUSTOM_ROW C_CYCLE_CUSTOM%ROWTYPE;
  
    --循环配置项
    CURSOR C_CYCLE_CONFIG IS
      SELECT *
        FROM CIMS.T_CREDIT_DELAYPAY_CYCLE_CONFIG C
       WHERE C.START_DATE <= TRUNC(SYSDATE, 'DD')
         AND (C.END_DATE IS NULL OR C.END_DATE >= TRUNC(SYSDATE, 'DD'))
         AND C.ENTITY_ID = V_ENTITY_ID
         AND C.CUSTOMER_ID = V_CUSTOMER_ID
         AND C.SALES_CENTER_ID IS NOT NULL;
    --配置项行数据
    CONFIG_ROW C_CYCLE_CONFIG%ROWTYPE;
  
  BEGIN
    P_MESSAGE := 'SUCCESS';
    -------------------------------------循环客户-------------------------------------
    FOR CUSTOM_ROW IN C_CYCLE_CUSTOM LOOP
      V_ENTITY_ID   := CUSTOM_ROW.ENTITY_ID;
      V_CUSTOMER_ID := CUSTOM_ROW.CUSTOMER_ID;
      --统计所有账户前12个月销售金额（负数金额取值为0）
      V_TOTAL_ACC_TWELVE_AMOUNT := F_GET_SALES_AMOUNT_ACC_TOTAL(P_ENTITY_ID   => V_ENTITY_ID,
                                                                P_CUSTOMER_ID => V_CUSTOMER_ID,
                                                                --系统日期的前12个月第一天
                                                                P_BEGIN_DATE => TO_CHAR(ADD_MONTHS(TRUNC(SYSDATE,
                                                                                                         'MM'),
                                                                                                   -12),
                                                                                        'YYYYMMDD'),
                                                                --系统日期的上个月最后一天
                                                                P_END_DATE => TO_CHAR(TRUNC(SYSDATE,
                                                                                            'MM') - 1,
                                                                                      'YYYYMMDD'));
    
      IF V_TOTAL_ACC_TWELVE_AMOUNT <= 0 THEN
        --记录不能生成循环铺底原因
        V_ERROR_INFO := '主体ID=' || V_ENTITY_ID || '、客户ID=' || V_CUSTOMER_ID ||
                        '，客户前12个月销售金额<=0';
        GOTO END1;
      END IF;
      --获取营销大类
      C_MAIN_TYPE_CURSOR := F_GET_SALES_MAIN_TYPE(V_ENTITY_ID,
                                                  V_CUSTOMER_ID);
    
      -----------------循环大类-----------------
      LOOP
        FETCH C_MAIN_TYPE_CURSOR
          INTO R_MAIN_TYPE;
        EXIT WHEN C_MAIN_TYPE_CURSOR%NOTFOUND;
        V_SALES_MAIN_TYPE_CODE := R_MAIN_TYPE;
        V_USE_AMOUNT           := 0;
        ------------------循环配置信息------------------
        FOR CONFIG_ROW IN C_CYCLE_CONFIG LOOP
          V_SALES_CENTER_ID := CONFIG_ROW.SALES_CENTER_ID;
          --根据主体、客户、中心，获取账户
          BEGIN
            SELECT V.ACCOUNT_ID, V.ACCOUNT_CODE
              INTO V_ACCOUNT_ID, V_ACCOUNT_CODE
              FROM CIMS.V_CUSTOMER_ACCOUNT_SALECENTER V
             WHERE V.ENTITY_ID = V_ENTITY_ID
               AND V.CUSTOMER_ID = V_CUSTOMER_ID
               AND V.SALES_CENTER_ID = V_SALES_CENTER_ID;
          EXCEPTION
            WHEN OTHERS THEN
              --记录不能生成循环铺底原因
              V_ERROR_INFO := '获取账户异常';
              GOTO END2;
          END;
        
          --根据主体、客户、账户、大类，获取可用信用额度
          IF V_USE_AMOUNT = 0 THEN
            V_USE_AMOUNT := F_GET_CUST_CAN_USE_AMOUNT(V_ENTITY_ID,
                                                      V_CUSTOMER_ID,
                                                      V_ACCOUNT_ID,
                                                      V_SALES_MAIN_TYPE_CODE);
          END IF;
          --调用单张铺底单生成
          P_CREDIT_DELAYPAY_CREATE(P_ENTITY_ID               => V_ENTITY_ID,
                                   P_CUSTOMER_ID             => V_CUSTOMER_ID,
                                   P_CUSTOMER_CODE           => CONFIG_ROW.CUSTOMER_CODE,
                                   P_CUSTOMER_NAME           => CONFIG_ROW.CUSTOMER_NAME,
                                   P_CENTER_ID               => V_SALES_CENTER_ID,
                                   P_CENTER_CODE             => CONFIG_ROW.SALES_CENTER_CODE,
                                   P_CENTER_NAME             => CONFIG_ROW.SALES_CENTER_NAME,
                                   P_ACCOUNT_ID              => V_ACCOUNT_ID,
                                   P_ACCOUNT_CODE            => V_ACCOUNT_CODE,
                                   P_ITEM_CODE               => V_SALES_MAIN_TYPE_CODE,
                                   P_USE_AMOUNT              => V_USE_AMOUNT,
                                   P_ACC_TOTAL_TWELVE_AMOUNT => V_TOTAL_ACC_TWELVE_AMOUNT,
                                   P_MESSAGE                 => V_ERROR_INFO);
          IF V_ERROR_INFO <> 'SUCCESS' THEN
            --记录不能生成循环铺底原因
            ROLLBACK;
            P_SAVE_CYCLE_DELAY_ERROR(P_ENTITY_ID   => V_ENTITY_ID,
                                     P_CUSTOMER_ID => V_CUSTOMER_ID,
                                     P_CENTER_ID   => V_SALES_CENTER_ID,
                                     P_CONFIG_ID   => NULL,
                                     P_ERROR_INFO  => V_ERROR_INFO);
          END IF;
          COMMIT;
          <<END2>>
          V_ERROR_INFO := 'SUCCESS';
          P_MESSAGE    := 'SUCCESS';
        END LOOP;
      END LOOP;
      <<END1>>
      IF V_ERROR_INFO <> 'SUCCESS' THEN
        P_SAVE_CYCLE_DELAY_ERROR(P_ENTITY_ID   => V_ENTITY_ID,
                                 P_CUSTOMER_ID => V_CUSTOMER_ID,
                                 P_CENTER_ID   => V_SALES_CENTER_ID,
                                 P_CONFIG_ID   => NULL,
                                 P_ERROR_INFO  => V_ERROR_INFO);
        COMMIT;
      END IF;
      V_ERROR_INFO := 'SUCCESS';
      P_MESSAGE    := 'SUCCESS';
    END LOOP;
  END;
  ------------------------------------循环铺底生成 end --------------------------------------------------------

END PKG_CREDIT_CYCLE_DELAYPAY;
/

