create PACKAGE BODY PKG_AR IS
  -- AUTHOR  : ANHT
  -- CREATED : 2014/8/12 9:56:03

  PROCEDURE P_FEETURNFEE_LG_POL(P_RECEIPT_METHOD_ID          IN NUMBER, --收款方法ID,物流费-转到款和返利-转到款对应的收款方法ID，根据主题区分
                                P_ACCOUNT_ID                 IN NUMBER, --账户ID
                                P_REIM_AMOUNT                IN NUMBER, --报销金额
                                P_REMAEK                     IN VARCHAR2, --备注
                                P_ENTITY_ID                  IN NUMBER, --主体ID
                                P_FEE_REIM_ID                IN VARCHAR2, --报销ID，物流费转到款时传入，与引入EMS的批文ID一致
                                P_FEE_APPLY_ID               IN VARCHAR2, --批文ID，返利转到款时传入，与引入EMS的批文ID一致
                                P_SOURCE_ID                  IN NUMBER, --来源ID，来源表中的主键
                                P_SALES_MAIN_TYPE_CODE_LINES IN VARCHAR2, --营销大类编码，多个营销大类时用逗号分隔
                                P_REIM_AMOUNT_LINES          IN VARCHAR2, --报销金额，若多个营销大类的情况则用逗号分隔
                                P_MESSAGE                    OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
                                ) IS

    V_CASH_RECEIPT_ID           NUMBER; --收款单据ID
    V_CUSTOMER_ID               NUMBER; --客户ID
    V_CUSTOMER_CODE             VARCHAR2(100); --客户编码
    --V_CASH_RECEIPT_CODE         VARCHAR2(32); --收款单据号
    V_SALES_MAIN_TYPE_CODE_LINE PKG_BD_UTIL.T_VARRAY := PKG_BD_UTIL.T_VARRAY(); --声明集合 分款中的营销大类
    V_REIM_AMOUNT_LINE          PKG_BD_UTIL.T_VARRAY := PKG_BD_UTIL.T_VARRAY(); --声明集合 分款中的报销金额
    V_BIZ_EXCEPTION EXCEPTION; --自定义业务异常

  BEGIN
    P_MESSAGE := 'OK';
    --收款单据ID
    SELECT S_INTF_AR_CASH_RECEIPT_HEADERS.NEXTVAL
      INTO V_CASH_RECEIPT_ID
      FROM DUAL;

    --客户ID，客户编码
    BEGIN
      SELECT DISTINCT CUSTOMER_ID, CUSTOMER_CODE
        INTO V_CUSTOMER_ID, V_CUSTOMER_CODE
        FROM V_CUST_ACCOUNT V
       WHERE V.ACCOUNT_ID = P_ACCOUNT_ID;
    EXCEPTION
      WHEN OTHERS THEN
        P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR.P_FEETURNFEE_LG_POL',
                                            SQLCODE,
                                            '取客户ID和客户编码失败！：' || SUBSTR(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, 1, 100) ||SQLERRM);
        RAISE V_BIZ_EXCEPTION;
    END;

    --收款单据号
/*  BEGIN
      V_CASH_RECEIPT_CODE := PKG_BD.F_GET_BILL_NO('ARARCODE',
                                                  NULL,
                                                  NULL,
                                                  NULL);
    EXCEPTION
      WHEN OTHERS THEN
        P_MESSAGE := '取收款单据号失败！';
        RAISE V_BIZ_EXCEPTION;
    END;
*/
    --判断金额不能为空
    IF P_REIM_AMOUNT IS NULL THEN
      P_MESSAGE := '金额不能为空！';
      RAISE V_BIZ_EXCEPTION;
    END IF;

    --插入收款头接口表
    BEGIN
      INSERT INTO INTF_AR_CASH_RECEIPT_HEADERS
        (CASH_RECEIPT_ID,
         RECEIPT_METHOD_ID,
         ACCOUNT_ID,
         CUSTOMER_ID,
         CUSTOMER_CODE,
         --CASH_RECEIPT_CODE,
         CASH_RECEIPT_DATE,
         REIM_AMOUNT,
         CURRENCY_CODE,
         CREATION_DATE,
         REMAEK,
         ENTITY_ID,
         SOURCE_ID,
         SOURCE_SYSTEM,
         FEE_REIM_ID,
         FEE_APPLY_ID)
      VALUES
        (V_CASH_RECEIPT_ID,
         P_RECEIPT_METHOD_ID,
         P_ACCOUNT_ID,
         V_CUSTOMER_ID,
         V_CUSTOMER_CODE,
         --V_CASH_RECEIPT_CODE,
         SYSDATE,
         P_REIM_AMOUNT,
         'CNY',
         SYSDATE,
         P_REMAEK,
         P_ENTITY_ID,
         P_SOURCE_ID,
         'CIMS',
         P_FEE_REIM_ID,
         P_FEE_APPLY_ID);
    EXCEPTION
      WHEN OTHERS THEN

        ROLLBACK;
        --记录出错信息
        P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR.P_FEETURNFEE_LG_POL',
                                            SQLCODE,
                                            '插入收款头表失败！：' || SUBSTR(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, 1, 100) ||SQLERRM);
        RAISE V_BIZ_EXCEPTION;
    END;

    --插入分款表
    BEGIN
      V_SALES_MAIN_TYPE_CODE_LINE := PKG_BD_UTIL.STR_SPLIT(P_SALES_MAIN_TYPE_CODE_LINES, ',');
      V_REIM_AMOUNT_LINE          := PKG_BD_UTIL.STR_SPLIT(P_REIM_AMOUNT_LINES, ',');

      --遍历营销大类，插入分款表
      FOR I IN 1 .. V_SALES_MAIN_TYPE_CODE_LINE.COUNT() LOOP
        INSERT INTO INTF_AR_CASH_RECEIPT_LINES
          (CASH_RECEIPT_LINES_ID,
           CASH_RECEIPT_ID,
           REIM_AMOUNT,
           SALES_MAIN_TYPE_CODE,
           SALES_MAIN_TYPE_NAME,
           SOURCE_SYSTEM)
        VALUES
          (S_INTF_AR_CASH_RECEIPT_LINES.NEXTVAL,
           V_CASH_RECEIPT_ID,
           NVL(V_REIM_AMOUNT_LINE(I),0),
           V_SALES_MAIN_TYPE_CODE_LINE(I),
           (SELECT NVL(CLASS_NAME, '')
              FROM T_BD_ITEM_CLASS
             WHERE CLASS_CODE = V_SALES_MAIN_TYPE_CODE_LINE(I)
               AND CLASS_TYPE = 'M'
               AND ENTITY_ID = P_ENTITY_ID),
           'CIMS');
      END LOOP;

    EXCEPTION
      WHEN OTHERS THEN

        ROLLBACK;
        --记录出错信息
        P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR.P_FEETURNFEE_LG_POL',
                                            SQLCODE,
                                            '插入收款行表失败！：' || SUBSTR(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, 1, 100) ||SQLERRM);
        RAISE V_BIZ_EXCEPTION;
    END;

    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      NULL;
  END;

END PKG_AR;
/

