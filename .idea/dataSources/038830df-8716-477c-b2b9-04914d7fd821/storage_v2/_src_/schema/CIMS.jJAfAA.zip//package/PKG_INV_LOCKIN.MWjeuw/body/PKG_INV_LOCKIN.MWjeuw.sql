create Package Body      PKG_INV_LOCKIN Is

  -----------------------------------------------------------------------------
  --  锁定库存|解锁库存                                            --
  -----------------------------------------------------------------------------


  --------------------------------------------------------------------------
   --Author: guibr
   --Created: 2019-02-18
   --锁定库存|解锁库存  处理
   --------------------------------------------------------------------------
   Procedure P_LOCKIN_MAIN_BY_DISTRICT(
               IS_DISTRICT_CODE  IN  VARCHAR2
               ,IS_ITEM_CODE      IN  VARCHAR2
               ,IS_ITEM_CLASS_CODE  IN out VARCHAR2
               ,IN_ENTITY_ID     IN  NUMBER
               ,IS_INVENTORY_CODE   IN VARCHAR2
               ,IS_SHARE_VENDOR_CODE IN VARCHAR2
               ,IN_LOCK_QTY      IN  NUMBER
               ,IS_LOCK_TYPE     IN  VARCHAR2
               ,IN_LOCK_LEVEL    IN  NUMBER
               ,IS_DELIVERY_NUMBER  IN  VARCHAR2
               ,IS_ORDER_NUMBER  IN  VARCHAR2
               ,IS_CHILD_ORDER_NUMBER  IN  VARCHAR2
               ,IS_USER_CODE     IN  varchar2
               ,IS_sales_center_code in varchar2
               ,OS_INVENTORY_LOCK  OUT VARCHAR2 --返回锁定释放仓库及对应数量
               ,OS_MESSAGE   OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
               ,OS_JSON_MSG   OUT VARCHAR2 --成功则返回“OK”，否则返回格式化出错信息
   )
   IS
     N_ITEM_ID NUMBER;
     N_SET_ITEM_ID NUMBER;
     S_ITEM_UON VARCHAR2(100);
     N_ENTITY_ID NUMBER;
     S_CHILD_MESSAGE VARCHAR2(4000);
     N_CRRENT_LOCK_QTY NUMBER;
     N_ALL_LOCK_QTY NUMBER;
     S_LOCK_COMPLETION VARCHAR2(2);
     N_ASSEMBLIES_COUNT NUMBER;
     N_ASSEMBLIES_UNIT NUMBER;
     N_SET_LOCK_QTY NUMBER;
     N_USABLE_ITEM_QOH_QTY NUMBER;
     N_ALL_QOH_QTY NUMBER;
     N_LOCKIN_TRAN_ID NUMBER;

     N_FACT_LOCK_QTY NUMBER;
     S_ITEM_NAME VARCHAR2(300);
     S_PRODUCTMODEL VARCHAR2(500);
     v_sales_main_type varchar2(100);
     v_msg varchar2(1000);
   BEGIN
     v_msg := IS_DISTRICT_CODE||','||IS_ITEM_CODE||','||IS_ITEM_CLASS_CODE||','||IN_ENTITY_ID||','||
              IN_LOCK_QTY||','||IS_LOCK_TYPE||','||IN_LOCK_LEVEL||','||IS_DELIVERY_NUMBER||','||
              IS_ORDER_NUMBER||','||IS_CHILD_ORDER_NUMBER;
     v_msg := pkg_bd.F_ADD_ERROR_LOG('P_LOCKIN_MAIN_BY_DISTRICT','0000',v_msg);
       OS_MESSAGE := 'OK';
       OS_JSON_MSG := 'OK';
       IF IN_LOCK_QTY=0 OR IN_LOCK_QTY IS NULL THEN
          RETURN;  --等于0 直接返回
       END IF;
     IF IN_ENTITY_ID IS NULL THEN
        if IS_ITEM_CLASS_CODE is null then
           select a.sales_main_type into v_sales_main_type from t_bd_item a where a.item_code=IS_ITEM_CODE and rownum=1;
           IS_ITEM_CLASS_CODE:=v_sales_main_type;
        end if;
        SELECT
           PKG_INV_PUB.F_GET_ENTITY_CLASSCODE(IS_ITEM_CLASS_CODE)
        INTO
           N_ENTITY_ID
        FROM DUAL;
      ELSE
         N_ENTITY_ID :=IN_ENTITY_ID;
      END IF;

      IF N_ENTITY_ID = 0 THEN
           OS_MESSAGE :=
            '锁定|解锁库存量异常：经营大类(编码:'
                 || IS_ITEM_CLASS_CODE
                 || ')的编码不存在';
         RETURN;
      END IF;

       BEGIN
           SELECT I.ITEM_ID
                 ,I.DEFAULTUNIT
                 ,I.ENTITY_ID
                 ,I.ITEM_NAME
                 ,I.PRODUCTMODEL
             INTO N_ITEM_ID
                 ,S_ITEM_UON
                 ,N_ENTITY_ID
                 ,S_ITEM_NAME
                 ,S_PRODUCTMODEL
             FROM T_BD_ITEM I
             WHERE I.ITEM_CODE = IS_ITEM_CODE
             AND   I.ENTITY_ID = N_ENTITY_ID;
             N_SET_ITEM_ID:= N_ITEM_ID;
       EXCEPTION
              WHEN NO_DATA_FOUND THEN
                OS_MESSAGE :=
                  '锁定|解锁库存量异常：经营大类(编码:'
                       || IS_ITEM_CLASS_CODE
                       || ');产品(编码:'
                       || IS_ITEM_CODE
                       || ')的产品不存在';
              RETURN;
        END;


        SELECT COUNT(1),SUM(S.QUANTITY) INTO N_ASSEMBLIES_COUNT,N_ASSEMBLIES_UNIT FROM CIMS.T_BD_ITEM_ASSEMBLIES P
        INNER JOIN CIMS.T_BD_ITEM_ASSEMBLIES_SUB S ON P.ITEM_ASSEMBLY_ID = S.ITEM_ASSEMBLY_ID
        WHERE P.ACTIVE_FLAG ='Y' AND P.ITEM_CODE=IS_ITEM_CODE AND P.ENTITY_ID=N_ENTITY_ID;

        IF  N_ASSEMBLIES_COUNT > 0 THEN  --套机处理
            IF IN_LOCK_QTY>0 THEN   --套机锁定开始
                N_LOCKIN_TRAN_ID := S_INV_LOCKIN_TRAN.Nextval;
                N_ALL_QOH_QTY := 0;
                FOR INVENTORIES_ROW IN (
                    SELECT INVENTORY_ID,INVENTORY_CODE FROM TABLE(PKG_INV_LOCKIN.F_GET_INV_LIST(N_ENTITY_ID,IS_LOCK_TYPE,IS_DISTRICT_CODE,IS_sales_center_code,IS_INVENTORY_CODE))
                )
                LOOP
                   BEGIN
                         N_USABLE_ITEM_QOH_QTY := PKG_INV_PUB.F_GET_ITEM_INV_QOH(P_ENTITY_ID  => N_ENTITY_ID,
                                                                        P_INVENTORY_ID      => INVENTORIES_ROW.INVENTORY_ID,
                                                                        P_ITEM_ID           => N_ITEM_ID,
                                                                        P_USER_CODE         => IS_USER_CODE,
                                                                        P_GET_QOH_TYPE      => 2,
                                                                        P_COUNT_OCCOUP_FLAG => 'Y');
                        IF N_USABLE_ITEM_QOH_QTY>0 THEN
                           INSERT INTO T_INV_LOCKIN_TRAN(LOCKIN_TRAN_ID,INVENTORY_ID,INVENTORY_CODE,QTY)
                           VALUES(N_LOCKIN_TRAN_ID,INVENTORIES_ROW.INVENTORY_ID,INVENTORIES_ROW.INVENTORY_CODE,N_USABLE_ITEM_QOH_QTY);
                           N_ALL_QOH_QTY := N_ALL_QOH_QTY+N_USABLE_ITEM_QOH_QTY;
                        END IF;
                   END;
                END LOOP;
                --经营主体、区域编码、区域名称、产品编码、产品名称、库存数量、需求数量
                IF NVL(N_ALL_QOH_QTY,0) < IN_LOCK_QTY THEN
                        OS_MESSAGE :=
                                  '锁定库存量异常：经营主体(ID:'
                               || N_ENTITY_ID
                               || ');区域(区域编码:'
                               || IS_DISTRICT_CODE
                               || ');仓库(仓库编码:'
                               || IS_INVENTORY_CODE
                               || ');产品(产品编码:'
                               || IS_ITEM_CODE
                               || ')的库存可用|锁定不足！(库存：('
                               || N_ALL_QOH_QTY
                               ||'),单据需求：'
                               ||IN_LOCK_QTY
                               ||')';

                         OS_JSON_MSG := '{productModel:"'||S_PRODUCTMODEL||'",entityId:'||N_ENTITY_ID||',itemCode:"'||IS_ITEM_CODE||'",itemName:"'||S_ITEM_NAME||'",handQty:'||N_ALL_QOH_QTY||',qty:'||IN_LOCK_QTY||'}';
                        RETURN;
               END IF;

                N_SET_LOCK_QTY:=IN_LOCK_QTY;

                FOR INV_QOH_ROW IN (
                    SELECT INVENTORY_ID,INVENTORY_CODE,QTY FROM T_INV_LOCKIN_TRAN WHERE LOCKIN_TRAN_ID=N_LOCKIN_TRAN_ID ORDER BY QTY DESC
                )
                LOOP
                   BEGIN
                     IF  INV_QOH_ROW.QTY >= N_SET_LOCK_QTY THEN
                        FOR ITEM_ROW IN (
                            SELECT S.ITEM_ID,S.ITEM_CODE,S.ITEM_UOM,S.ITEM_NAME,S.QUANTITY FROM CIMS.T_BD_ITEM_ASSEMBLIES P
                            INNER JOIN CIMS.T_BD_ITEM_ASSEMBLIES_SUB S ON P.ITEM_ASSEMBLY_ID = S.ITEM_ASSEMBLY_ID
                            WHERE P.ACTIVE_FLAG ='Y' AND P.ITEM_CODE=IS_ITEM_CODE AND P.ENTITY_ID=N_ENTITY_ID
                            ORDER BY S.ITEM_CODE
                        )LOOP
                            BEGIN
                                   N_ITEM_ID := ITEM_ROW.ITEM_ID;
                                   S_ITEM_UON := ITEM_ROW.ITEM_UOM;
                                   S_ITEM_NAME:= ITEM_ROW.ITEM_NAME;

                                   N_CRRENT_LOCK_QTY := N_SET_LOCK_QTY*ITEM_ROW.QUANTITY;

                                   P_LOCKIN_HAND(0
                                          ,N_ENTITY_ID
                                          ,INV_QOH_ROW.INVENTORY_ID
                                          ,INV_QOH_ROW.INVENTORY_CODE
                                          ,N_ITEM_ID
                                          ,ITEM_ROW.ITEM_CODE
                                          ,S_ITEM_UON
                                          ,S_ITEM_NAME
                                          ,S_PRODUCTMODEL
                                          ,N_CRRENT_LOCK_QTY
                                          ,'N'
                                          ,IS_LOCK_TYPE
                                          ,IN_LOCK_LEVEL
                                          ,IS_USER_CODE
                                          ,N_FACT_LOCK_QTY
                                          ,S_CHILD_MESSAGE
                                          ,OS_JSON_MSG
                                        );
                                     IF S_CHILD_MESSAGE<>'OK' THEN
                                         OS_MESSAGE := S_CHILD_MESSAGE;
                                         RETURN;
                                     ELSE
                                          P_LOCKIN_HISTORY_ADD(N_ENTITY_ID   --插入锁定事物
                                            ,IS_SHARE_VENDOR_CODE
                                            ,INV_QOH_ROW.INVENTORY_ID
                                            ,INV_QOH_ROW.INVENTORY_CODE
                                            ,N_ITEM_ID
                                            ,ITEM_ROW.ITEM_CODE
                                            ,S_ITEM_UON
                                            ,N_CRRENT_LOCK_QTY
                                            ,N_SET_ITEM_ID
                                            ,N_SET_LOCK_QTY
                                            ,IS_LOCK_TYPE
                                            ,IN_LOCK_LEVEL
                                            ,IS_DELIVERY_NUMBER
                                            ,IS_ORDER_NUMBER
                                            ,IS_CHILD_ORDER_NUMBER
                                            ,IS_USER_CODE
                                            ,S_CHILD_MESSAGE
                                           );
                                     END IF;
                            END;
                          END LOOP;
                          N_SET_LOCK_QTY := 0;
                          EXIT;
                     ELSE
                         FOR ITEM_ROW IN (
                            SELECT S.ITEM_ID,S.ITEM_CODE,S.ITEM_UOM,S.ITEM_NAME,S.QUANTITY FROM CIMS.T_BD_ITEM_ASSEMBLIES P
                            INNER JOIN CIMS.T_BD_ITEM_ASSEMBLIES_SUB S ON P.ITEM_ASSEMBLY_ID = S.ITEM_ASSEMBLY_ID
                            WHERE P.ACTIVE_FLAG ='Y' AND P.ITEM_CODE=IS_ITEM_CODE AND P.ENTITY_ID=N_ENTITY_ID
                            ORDER BY S.ITEM_CODE
                        )LOOP
                            BEGIN
                                  N_ITEM_ID := ITEM_ROW.ITEM_ID;
                                  S_ITEM_UON := ITEM_ROW.ITEM_UOM;
                                  S_ITEM_NAME:= ITEM_ROW.ITEM_NAME;

                                   N_CRRENT_LOCK_QTY := INV_QOH_ROW.QTY*ITEM_ROW.QUANTITY;

                                   P_LOCKIN_HAND(0
                                          ,N_ENTITY_ID
                                          ,INV_QOH_ROW.INVENTORY_ID
                                          ,INV_QOH_ROW.INVENTORY_CODE
                                          ,N_ITEM_ID
                                          ,ITEM_ROW.ITEM_CODE
                                          ,S_ITEM_UON
                                          ,S_ITEM_NAME
                                           ,S_PRODUCTMODEL
                                          ,N_CRRENT_LOCK_QTY
                                          ,'N'
                                          ,IS_LOCK_TYPE
                                          ,IN_LOCK_LEVEL
                                          ,IS_USER_CODE
                                          ,N_FACT_LOCK_QTY
                                          ,S_CHILD_MESSAGE
                                          ,OS_JSON_MSG
                                        );
                                     IF S_CHILD_MESSAGE<>'OK' THEN
                                         OS_MESSAGE := S_CHILD_MESSAGE;
                                         RETURN;
                                     ELSE
                                          P_LOCKIN_HISTORY_ADD(N_ENTITY_ID   --插入锁定事物
                                            ,IS_SHARE_VENDOR_CODE
                                            ,INV_QOH_ROW.INVENTORY_ID
                                            ,INV_QOH_ROW.INVENTORY_CODE
                                            ,N_ITEM_ID
                                            ,ITEM_ROW.ITEM_CODE
                                            ,S_ITEM_UON
                                            ,N_CRRENT_LOCK_QTY
                                            ,N_SET_ITEM_ID
                                            ,INV_QOH_ROW.QTY
                                            ,IS_LOCK_TYPE
                                            ,IN_LOCK_LEVEL
                                            ,IS_DELIVERY_NUMBER
                                            ,IS_ORDER_NUMBER
                                            ,IS_CHILD_ORDER_NUMBER
                                            ,IS_USER_CODE
                                            ,S_CHILD_MESSAGE
                                           );

                                     END IF;
                            END;
                          END LOOP;
                          N_SET_LOCK_QTY := N_SET_LOCK_QTY-INV_QOH_ROW.QTY;
                     END IF;
                   END;
                END LOOP;
          ELSE    --套件释放库存开始
                N_SET_LOCK_QTY:=IN_LOCK_QTY;
                FOR INV_QOH_ROW IN (
                      SELECT
                           INVENTORY_ID
                          ,INVENTORY_CODE
                          ,SUM(NVL(TRANSACTION_QUANTITY,0)) TRANSACTION_QUANTITY
                       FROM
                          CIMS.T_INV_LOCKIN_HISTORY
                       WHERE
                            BUSINESS_NUM = IS_ORDER_NUMBER
                        AND ENTITY_ID= N_ENTITY_ID
                        AND SET_ITEM_ID = N_SET_ITEM_ID
                        AND LOCK_TYPE = IS_LOCK_TYPE
                        AND LOCK_LEVEL = IN_LOCK_LEVEL
                      GROUP BY
                            INVENTORY_ID
                           ,INVENTORY_CODE
                           HAVING SUM(TRANSACTION_QUANTITY)>0)
                 LOOP
                     BEGIN
                          N_USABLE_ITEM_QOH_QTY := floor(INV_QOH_ROW.TRANSACTION_QUANTITY/N_ASSEMBLIES_UNIT);
                          IF N_USABLE_ITEM_QOH_QTY >= ABS(N_SET_LOCK_QTY) THEN
                               FOR ITEM_ROW IN (
                                  SELECT S.ITEM_ID,S.ITEM_CODE,S.ITEM_UOM,S.ITEM_NAME,S.QUANTITY FROM CIMS.T_BD_ITEM_ASSEMBLIES P
                                  INNER JOIN CIMS.T_BD_ITEM_ASSEMBLIES_SUB S ON P.ITEM_ASSEMBLY_ID = S.ITEM_ASSEMBLY_ID
                                  WHERE P.ACTIVE_FLAG ='Y' AND P.ITEM_CODE=IS_ITEM_CODE AND P.ENTITY_ID=N_ENTITY_ID
                                  ORDER BY S.ITEM_CODE
                              )LOOP
                                  BEGIN
                                         N_ITEM_ID := ITEM_ROW.ITEM_ID;
                                         S_ITEM_UON := ITEM_ROW.ITEM_UOM;
                                         S_ITEM_NAME:= ITEM_ROW.ITEM_NAME;

                                         N_CRRENT_LOCK_QTY := N_SET_LOCK_QTY*ITEM_ROW.QUANTITY;

                                         P_LOCKIN_HAND(0
                                                ,N_ENTITY_ID
                                                ,INV_QOH_ROW.INVENTORY_ID
                                                ,INV_QOH_ROW.INVENTORY_CODE
                                                ,N_ITEM_ID
                                                ,ITEM_ROW.ITEM_CODE
                                                ,S_ITEM_UON
                                                ,S_ITEM_NAME
                                                 ,S_PRODUCTMODEL
                                                ,N_CRRENT_LOCK_QTY
                                                ,'N'
                                                ,IS_LOCK_TYPE
                                                ,IN_LOCK_LEVEL
                                                ,IS_USER_CODE
                                                ,N_FACT_LOCK_QTY
                                                ,S_CHILD_MESSAGE
                                                ,OS_JSON_MSG
                                              );
                                           IF S_CHILD_MESSAGE<>'OK' THEN
                                               OS_MESSAGE := S_CHILD_MESSAGE;
                                               RETURN;
                                           ELSE
                                                P_LOCKIN_HISTORY_ADD(N_ENTITY_ID   --插入锁定事物
                                                 ,IS_SHARE_VENDOR_CODE
                                                  ,INV_QOH_ROW.INVENTORY_ID
                                                  ,INV_QOH_ROW.INVENTORY_CODE
                                                  ,N_ITEM_ID
                                                  ,ITEM_ROW.ITEM_CODE
                                                  ,S_ITEM_UON
                                                  ,N_CRRENT_LOCK_QTY
                                                  ,N_SET_ITEM_ID
                                                  ,N_SET_LOCK_QTY
                                                  ,IS_LOCK_TYPE
                                                  ,IN_LOCK_LEVEL
                                                  ,IS_DELIVERY_NUMBER
                                                  ,IS_ORDER_NUMBER
                                                  ,IS_CHILD_ORDER_NUMBER
                                                  ,IS_USER_CODE
                                                  ,S_CHILD_MESSAGE
                                                 );
                                           END IF;
                                  END;
                                END LOOP;
                               OS_INVENTORY_LOCK := OS_INVENTORY_LOCK||','||INV_QOH_ROW.INVENTORY_CODE||':'||-1*N_SET_LOCK_QTY;
                               N_SET_LOCK_QTY := 0;
                              EXIT;
                          ELSE
                              FOR ITEM_ROW IN (
                                  SELECT S.ITEM_ID,S.ITEM_CODE,S.ITEM_UOM,S.ITEM_NAME,S.QUANTITY FROM CIMS.T_BD_ITEM_ASSEMBLIES P
                                  INNER JOIN CIMS.T_BD_ITEM_ASSEMBLIES_SUB S ON P.ITEM_ASSEMBLY_ID = S.ITEM_ASSEMBLY_ID
                                  WHERE P.ACTIVE_FLAG ='Y' AND P.ITEM_CODE=IS_ITEM_CODE AND P.ENTITY_ID=N_ENTITY_ID
                                  ORDER BY S.ITEM_CODE
                              )LOOP
                                  BEGIN
                                         N_ITEM_ID := ITEM_ROW.ITEM_ID;
                                         S_ITEM_UON := ITEM_ROW.ITEM_UOM;
                                         S_ITEM_NAME:= ITEM_ROW.ITEM_NAME;

                                         N_CRRENT_LOCK_QTY := -1*N_USABLE_ITEM_QOH_QTY*ITEM_ROW.QUANTITY;

                                         P_LOCKIN_HAND(0
                                                ,N_ENTITY_ID
                                                ,INV_QOH_ROW.INVENTORY_ID
                                                ,INV_QOH_ROW.INVENTORY_CODE
                                                ,N_ITEM_ID
                                                ,ITEM_ROW.ITEM_CODE
                                                ,S_ITEM_UON
                                                ,S_ITEM_NAME
                                                  ,S_PRODUCTMODEL
                                                ,N_CRRENT_LOCK_QTY
                                                ,'N'
                                                ,IS_LOCK_TYPE
                                                ,IN_LOCK_LEVEL
                                                ,IS_USER_CODE
                                                ,N_FACT_LOCK_QTY
                                                ,S_CHILD_MESSAGE
                                                ,OS_JSON_MSG
                                              );
                                           IF S_CHILD_MESSAGE<>'OK' THEN
                                               OS_MESSAGE := S_CHILD_MESSAGE;
                                               RETURN;
                                           ELSE
                                                P_LOCKIN_HISTORY_ADD(N_ENTITY_ID   --插入锁定事物
                                                  ,IS_SHARE_VENDOR_CODE
                                                  ,INV_QOH_ROW.INVENTORY_ID
                                                  ,INV_QOH_ROW.INVENTORY_CODE
                                                  ,N_ITEM_ID
                                                  ,ITEM_ROW.ITEM_CODE
                                                  ,S_ITEM_UON
                                                  ,N_CRRENT_LOCK_QTY
                                                  ,N_SET_ITEM_ID
                                                  ,-1*N_USABLE_ITEM_QOH_QTY
                                                  ,IS_LOCK_TYPE
                                                  ,IN_LOCK_LEVEL
                                                  ,IS_DELIVERY_NUMBER
                                                  ,IS_ORDER_NUMBER
                                                  ,IS_CHILD_ORDER_NUMBER
                                                  ,IS_USER_CODE
                                                  ,S_CHILD_MESSAGE
                                                 );

                                           END IF;
                                  END;
                                 END LOOP;
                                 OS_INVENTORY_LOCK := OS_INVENTORY_LOCK||','||INV_QOH_ROW.INVENTORY_CODE||':'||N_USABLE_ITEM_QOH_QTY;
                                 N_SET_LOCK_QTY := N_SET_LOCK_QTY + N_USABLE_ITEM_QOH_QTY;
                          END IF;
                     END;
                 END LOOP;
                      IF N_SET_LOCK_QTY<>0 THEN
                             OS_MESSAGE :=
                                '解锁库存量异常：经营主体(ID:'
                               || N_ENTITY_ID
                               || ');区域(区域编码:'
                               || IS_DISTRICT_CODE
                               || ');仓库(仓库编码:'
                               || IS_INVENTORY_CODE
                               || ');产品(产品编码:'
                               || IS_ITEM_CODE
                               || ')的库存锁定不足！(锁定：('
                               || ABS(IN_LOCK_QTY-N_SET_LOCK_QTY)
                               ||'),单据需求：'
                               ||IN_LOCK_QTY
                               ||')';

                             OS_JSON_MSG := '{productModel:"'||S_PRODUCTMODEL||'",entityId:'||N_ENTITY_ID||',itemCode:"'||IS_ITEM_CODE||'",itemName:"'||S_ITEM_NAME||'",handQty:'||ABS(IN_LOCK_QTY-N_SET_LOCK_QTY)||',qty:'||IN_LOCK_QTY||'}';
                           RETURN;
                      END IF;
              END IF;     --套件释放库存结束

           ELSE       --散件库存处理

                    N_CRRENT_LOCK_QTY:=IN_LOCK_QTY;
                    S_LOCK_COMPLETION := 'N';
                    N_ALL_LOCK_QTY:=0;
                    IF N_CRRENT_LOCK_QTY>0 THEN  --锁定库存  --散件库存锁定
                        P_LOCKIN_ADD_HAND(N_ENTITY_ID
                                         ,IS_SHARE_VENDOR_CODE
                                         ,IS_INVENTORY_CODE
                                         ,IS_DISTRICT_CODE
                                         ,N_ITEM_ID
                                         ,IS_ITEM_CODE
                                         ,S_ITEM_UON
                                         ,S_ITEM_NAME
                                          ,S_PRODUCTMODEL
                                         ,N_CRRENT_LOCK_QTY
                                         ,IS_LOCK_TYPE
                                         ,IN_LOCK_LEVEL
                                         ,IS_DELIVERY_NUMBER
                                         ,IS_ORDER_NUMBER
                                         ,IS_CHILD_ORDER_NUMBER
                                         ,IS_USER_CODE
                                         ,IS_sales_center_code
                                         ,S_LOCK_COMPLETION
                                         ,N_ALL_LOCK_QTY
                                         ,OS_INVENTORY_LOCK
                                         ,S_CHILD_MESSAGE
                                         ,OS_JSON_MSG
                                       );
                       IF S_CHILD_MESSAGE<>'OK' THEN
                             OS_MESSAGE := S_CHILD_MESSAGE;
                             RETURN;
                       END IF;
                    ELSE  --散件库存释放
                        P_LOCKIN_SUB_HAND(N_ENTITY_ID
                                         ,IS_SHARE_VENDOR_CODE
                                         ,N_ITEM_ID
                                         ,IS_ITEM_CODE
                                         ,S_ITEM_UON
                                         ,S_ITEM_NAME
                                           ,S_PRODUCTMODEL
                                         ,N_CRRENT_LOCK_QTY
                                         ,IS_LOCK_TYPE
                                         ,IN_LOCK_LEVEL
                                         ,IS_DELIVERY_NUMBER
                                         ,IS_ORDER_NUMBER
                                         ,IS_CHILD_ORDER_NUMBER
                                         ,IS_USER_CODE
                                         ,S_LOCK_COMPLETION
                                         ,N_ALL_LOCK_QTY
                                         ,OS_INVENTORY_LOCK
                                         ,S_CHILD_MESSAGE
                                         ,OS_JSON_MSG
                          );
                       IF S_CHILD_MESSAGE<>'OK' THEN
                             OS_MESSAGE := S_CHILD_MESSAGE;
                             RETURN;
                       END IF;
                    END IF;--散件库存释放结束

                    IF S_LOCK_COMPLETION='N' THEN
                      OS_MESSAGE :=
                                '锁定|解锁库存量异常：经营主体(ID:'
                             || N_ENTITY_ID
                             || ');区域(区域编码:'
                             || IS_DISTRICT_CODE
                             || ');仓库(仓库编码:'
                             || IS_INVENTORY_CODE
                             || ');产品(产品编码:'
                             || IS_ITEM_CODE
                             || ')的库存可用|锁定不足！(库存：('
                             || N_ALL_LOCK_QTY
                             ||'),单据需求：'
                             ||IN_LOCK_QTY
                             ||')';

                        OS_JSON_MSG := '{productModel:"'||S_PRODUCTMODEL||'",entityId:'||N_ENTITY_ID||',itemCode:"'||IS_ITEM_CODE||'",itemName:"'||S_ITEM_NAME||'",handQty:'||N_ALL_LOCK_QTY||',qty:'||IN_LOCK_QTY||'}';
                         RETURN;
                   END IF;
          END IF;
     v_msg := pkg_bd.F_ADD_ERROR_LOG('P_LOCKIN_MAIN_BY_DISTRICT','0000',OS_MESSAGE||OS_JSON_MSG);
   END;


   --------------------------------------------------------------------------
   --Author: guibr
   --Created: 2019-02-18
   --锁定库存|解锁库存  处理
   --------------------------------------------------------------------------
   Procedure P_LOCKIN_MAIN(
                IN_BATCH_NUM     IN  NUMBER
               ,IS_LOCK_TYPE     IN  VARCHAR2
               ,IN_LOCK_LEVEL    IN  NUMBER
               ,IS_USER_CODE     IN  VARCHAR2
               ,OS_MESSAGE   OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
   )
   IS
     S_CHILD_MESSAGE VARCHAR2(4000);
     N_FACT_LOCK_QTY NUMBER;
   BEGIN
       OS_MESSAGE := 'OK';
        FOR LOCKIN_HISTORY_ROW IN (
           SELECT * FROM T_INV_LOCKIN_HISTORY where BATCH_NUM = IN_BATCH_NUM ORDER BY ITEM_ID
        )
        LOOP
           BEGIN
            /*    P_LOCKIN_HAND(
                             LOCKIN_HISTORY_ROW.TRANSACTION_ID
                            ,LOCKIN_HISTORY_ROW.ENTITY_ID
                            ,LOCKIN_HISTORY_ROW.INVENTORY_ID
                            ,LOCKIN_HISTORY_ROW.INVENTORY_CODE
                            ,LOCKIN_HISTORY_ROW.ITEM_ID
                            ,LOCKIN_HISTORY_ROW.ITEM_CODE
                            ,LOCKIN_HISTORY_ROW.TRANSACTION_UOM
                            ,LOCKIN_HISTORY_ROW.TRANSACTION_QUANTITY
                            ,'N'
                            ,IS_LOCK_TYPE
                            ,IN_LOCK_LEVEL
                            ,IS_USER_CODE
                            ,N_FACT_LOCK_QTY
                            ,S_CHILD_MESSAGE
                          );*/
                IF S_CHILD_MESSAGE<>'OK' THEN
                   OS_MESSAGE := S_CHILD_MESSAGE;
                   RETURN;
                END IF;
           END;
         END LOOP;
   END;


  --------------------------------------------------------------------------
  --Author: guibr
  --Created: 2019-02-18
  --锁定库存|解锁库存
  --------------------------------------------------------------------------
  Procedure P_LOCKIN_HAND(
                IN_TRANSACTION_ID     IN  NUMBER
               ,IN_ENTITY_ID     IN  NUMBER
               ,IN_INVENTORY_ID  IN  NUMBER
               ,IS_INVENTORY_CODE  IN  VARCHAR2
               ,IN_ITEM_ID       IN  NUMBER
               ,IS_ITEM_CODE     IN  VARCHAR2
               ,IS_ITEM_UOM      IN  VARCHAR2
               ,IS_ITEM_NAME     IN  VARCHAR2
               ,IS_PRODUCTMODEL   IN  VARCHAR2
               ,IN_LOCK_QTY      IN  NUMBER
               ,NEED_LOCK        IN  VARCHAR2  --Y|N 按需锁定，仓库有多少锁定多少，不检查仓库库存 按需锁定需要插入锁定事物历史
               ,IS_LOCK_TYPE     IN  VARCHAR2
               ,IN_LOCK_LEVEL    IN  NUMBER
               ,IS_USER_CODE     IN  varchar2
               ,ON_FACT_LOCK_QTY OUT  NUMBER  --按需锁定需要 返回实际锁定数量
               ,OS_MESSAGE   OUT VARCHAR2    --成功则返回“OK”，否则返回出错信息
               ,OS_JSON_MSG   OUT VARCHAR2 --成功则返回“OK”，否则返回格式化出错信息
    ) --返回值
    IS
      N_ONHAND_QUANTITY   NUMBER;
      N_USABLE_ITEM_QOH_QTY NUMBER;
      N_HAND_LOCK_COUNT  NUMBER;
      N_CURRENT_LOCK_QTY  NUMBER;

      N_PARENT_LOCK_QTY  NUMBER;
      N_CHILD_LOCK_QTY  NUMBER;

      N_NEED_LOCK_QTY NUMBER;
      N_FACT_LOCK_QTY NUMBER;
  BEGIN
      OS_MESSAGE := 'OK';
      IF IN_LOCK_QTY=0 THEN
         ON_FACT_LOCK_QTY :=0;
         RETURN;  --等于0 直接返回
      END IF;
      N_NEED_LOCK_QTY := IN_LOCK_QTY;
      IF N_NEED_LOCK_QTY> 0 THEN

            IF IN_LOCK_LEVEL = 0 THEN --0级库存
                  BEGIN
                     SELECT
                         QUANTITY
                       INTO
                         N_ONHAND_QUANTITY
                     FROM
                         T_INV_ONHAND
                     WHERE
                         ENTITY_ID = IN_ENTITY_ID
                     AND INVENTORY_ID = IN_INVENTORY_ID
                     AND ITEM_ID = IN_ITEM_ID
                     FOR UPDATE;
                 EXCEPTION
                    WHEN NO_DATA_FOUND THEN
                      IF NEED_LOCK = 'N' THEN --不是按需锁定 直接提示异常
                         OS_MESSAGE :=
                                    '锁定库存量异常：经营主体(ID:'
                                 || IN_ENTITY_ID
                                 || ');仓库(仓库编码:'
                                 || IS_INVENTORY_CODE
                                 || ');产品(产品编码:'
                                 || IS_ITEM_CODE
                                 || ')的库存现有量不存在！(库存：'
                                 ||(0)
                                 ||',单据需求：'
                                 ||N_NEED_LOCK_QTY
                                 ||')';

                             OS_JSON_MSG := '{productModel:"'||IS_PRODUCTMODEL||'",entityId:'||IN_ENTITY_ID||',itemCode:"'||IS_ITEM_CODE||'",itemName:"'||IS_ITEM_NAME||'",handQty:'||0||',qty:'||N_NEED_LOCK_QTY||'}';
                           RETURN;
                       ELSE     --本次锁定数量为0
                          ON_FACT_LOCK_QTY:=0;
                          RETURN;
                       END IF;
                 END;

                  N_USABLE_ITEM_QOH_QTY := PKG_INV_PUB.F_GET_ITEM_INV_QOH(P_ENTITY_ID  => IN_ENTITY_ID,
                                                                      P_INVENTORY_ID      => IN_INVENTORY_ID,
                                                                      P_ITEM_ID           => IN_ITEM_ID,
                                                                      P_USER_CODE         => IS_USER_CODE,
                                                                      P_GET_QOH_TYPE      => 2,
                                                                      P_COUNT_OCCOUP_FLAG => 'Y');

                      IF NEED_LOCK = 'N' THEN --不是按需锁定 直接提示异常
                          IF N_USABLE_ITEM_QOH_QTY <=0 OR N_USABLE_ITEM_QOH_QTY-N_NEED_LOCK_QTY<0 THEN
                             OS_MESSAGE :=
                                          '锁定库存量异常：经营主体(ID:'
                                       || IN_ENTITY_ID
                                       || ');仓库(仓库编码:'
                                       || IS_INVENTORY_CODE
                                       || ');产品(产品编码:'
                                       || IS_ITEM_CODE
                                       || ')的库存可用量不足！(库存可用量：'
                                       ||(N_USABLE_ITEM_QOH_QTY)
                                       ||',单据需求：'
                                       ||N_NEED_LOCK_QTY
                                       ||')';

                                 OS_JSON_MSG := '{productModel:"'||IS_PRODUCTMODEL||'",entityId:'||IN_ENTITY_ID||',itemCode:"'||IS_ITEM_CODE||'",itemName:"'||IS_ITEM_NAME||'",handQty:'||N_USABLE_ITEM_QOH_QTY||',qty:'||N_NEED_LOCK_QTY||'}';

                            RETURN;
                          END IF;
                          ON_FACT_LOCK_QTY:=N_NEED_LOCK_QTY;
                      ELSE
                          IF N_USABLE_ITEM_QOH_QTY <=0 THEN --本次锁定数量为0
                               ON_FACT_LOCK_QTY:=0;
                             RETURN;
                          ELSIF N_USABLE_ITEM_QOH_QTY-N_NEED_LOCK_QTY<0 THEN
                               ON_FACT_LOCK_QTY:= N_USABLE_ITEM_QOH_QTY;
                               N_NEED_LOCK_QTY:= N_USABLE_ITEM_QOH_QTY;
                          ELSE
                               ON_FACT_LOCK_QTY:= N_NEED_LOCK_QTY;
                          END IF;
                     END IF;

            ELSE     --上级锁定库存

                BEGIN
                     SELECT
                         QUANTITY
                       INTO
                         N_PARENT_LOCK_QTY
                     FROM
                         T_INV_LOCKIN
                     WHERE ENTITY_ID = IN_ENTITY_ID
                       AND INVENTORY_ID = IN_INVENTORY_ID
                       AND ITEM_ID = IN_ITEM_ID
                       --AND LOCKIN_ID = IN_PARENT_LOCKIN_ID
                       AND LOCK_LEVEL = IN_LOCK_LEVEL-1
                       AND LOCK_TYPE = IS_LOCK_TYPE
                     FOR UPDATE;
                 EXCEPTION
                    WHEN NO_DATA_FOUND THEN
                     IF NEED_LOCK = 'N' THEN --不是按需锁定 直接提示异常
                           OS_MESSAGE :=
                                      '锁定库存量异常：经营主体(ID:'
                                   || IN_ENTITY_ID
                                   || ');仓库(仓库编码:'
                                   || IS_INVENTORY_CODE
                                   || ');产品(产品编码:'
                                   || IS_ITEM_CODE
                                   || ')的上级库存锁定量不存在！(库存：'
                                   ||(0)
                                   ||',单据需求：'
                                   ||N_NEED_LOCK_QTY
                                   ||')';

                                 OS_JSON_MSG := '{productModel:"'||IS_PRODUCTMODEL||'",entityId:'||IN_ENTITY_ID||',itemCode:"'||IS_ITEM_CODE||'",itemName:"'||IS_ITEM_NAME||'",handQty:'||0||',qty:'||N_NEED_LOCK_QTY||'}';

                        RETURN;
                     ELSE     --本次锁定数量为0
                          ON_FACT_LOCK_QTY:=0;
                          RETURN;
                     END IF;
                 END;

                 BEGIN
                      SELECT QUANTITY
                       INTO  N_CHILD_LOCK_QTY
                       FROM  T_INV_LOCKIN
                      WHERE ENTITY_ID = IN_ENTITY_ID
                        AND  INVENTORY_ID = IN_INVENTORY_ID
                        AND  ITEM_ID = IN_ITEM_ID
                       -- AND  PARENT_LOCKIN_ID = IN_PARENT_LOCKIN_ID
                        AND LOCK_LEVEL = IN_LOCK_LEVEL
                        AND  LOCK_TYPE = IS_LOCK_TYPE
                   FOR UPDATE;
                 EXCEPTION
                    WHEN NO_DATA_FOUND THEN
                       N_CHILD_LOCK_QTY := 0;
                 END;

                 N_USABLE_ITEM_QOH_QTY := N_PARENT_LOCK_QTY - N_CHILD_LOCK_QTY;
                 IF NEED_LOCK = 'N' THEN --不是按需锁定 直接提示异常
                       IF N_USABLE_ITEM_QOH_QTY <=0 OR N_USABLE_ITEM_QOH_QTY-N_NEED_LOCK_QTY<0 THEN
                             OS_MESSAGE :=
                                          '锁定库存量异常：经营主体(ID:'
                                       || IN_ENTITY_ID
                                       || ');仓库(仓库编码:'
                                       || IS_INVENTORY_CODE
                                       || ');产品(产品编码:'
                                       || IS_ITEM_CODE
                                       || ')的库存可用量不足！(库存可用量：'
                                       ||(N_USABLE_ITEM_QOH_QTY)
                                       ||',单据需求：'
                                       ||N_NEED_LOCK_QTY
                                       ||')';

                                    OS_JSON_MSG := '{productModel:"'||IS_PRODUCTMODEL||'",entityId:'||IN_ENTITY_ID||',itemCode:"'||IS_ITEM_CODE||'",itemName:"'||IS_ITEM_NAME||'",handQty:'||N_USABLE_ITEM_QOH_QTY||',qty:'||N_NEED_LOCK_QTY||'}';

                            RETURN;
                       END IF;
                       ON_FACT_LOCK_QTY:=N_NEED_LOCK_QTY;
                ELSE
                       IF N_USABLE_ITEM_QOH_QTY <=0 THEN --本次锁定数量为0
                           ON_FACT_LOCK_QTY:=0;
                         RETURN;
                       ELSIF N_USABLE_ITEM_QOH_QTY-N_NEED_LOCK_QTY<0 THEN
                           ON_FACT_LOCK_QTY:= N_USABLE_ITEM_QOH_QTY;
                           N_NEED_LOCK_QTY:= N_USABLE_ITEM_QOH_QTY;
                       ELSE
                          ON_FACT_LOCK_QTY:= N_NEED_LOCK_QTY;
                       END IF;
               END IF;

            END IF;
       ELSE
          ON_FACT_LOCK_QTY := N_NEED_LOCK_QTY;
       END IF;
           N_FACT_LOCK_QTY := ON_FACT_LOCK_QTY;

          SELECT COUNT (*)
              INTO N_HAND_LOCK_COUNT
              FROM T_INV_LOCKIN
             WHERE ENTITY_ID = IN_ENTITY_ID
               AND INVENTORY_ID = IN_INVENTORY_ID
               AND ITEM_ID = IN_ITEM_ID
               AND LOCK_LEVEL = IN_LOCK_LEVEL
               AND LOCK_TYPE = IS_LOCK_TYPE;

          IF N_HAND_LOCK_COUNT <= 0 THEN
                  IF  IN_LOCK_QTY < 0 THEN
                      IF NEED_LOCK = 'N' THEN --不是按需锁定 直接提示异常
                           OS_MESSAGE :=
                                          '解锁库存量异常：经营主体(ID:'
                                       || IN_ENTITY_ID
                                       || ');仓库(仓库编码:'
                                       || IS_INVENTORY_CODE
                                       || ');产品(产品编码:'
                                       || IS_ITEM_CODE
                                       || ')的库存锁定量不足！(库存锁定量：'
                                       ||(0)
                                       ||',单据需求：'
                                       ||IN_LOCK_QTY
                                       ||')';

                                 OS_JSON_MSG := '{productModel:"'||IS_PRODUCTMODEL||'",entityId:'||IN_ENTITY_ID||',itemCode:"'||IS_ITEM_CODE||'",itemName:"'||IS_ITEM_NAME||'",handQty:'||0||',qty:'||N_NEED_LOCK_QTY||'}';
                            RETURN;
                       ELSE
                          N_FACT_LOCK_QTY:=0;
                          RETURN;
                      END IF;
                  END IF;


                   INSERT INTO T_INV_LOCKIN(CREATED_BY, CREATION_DATE, ENTITY_ID,
                            INVENTORY_ID, LOCKIN_ID, ITEM_ID,
                            LAST_TRANSACTION_ID, LAST_UPDATED_BY, LAST_UPDATE_DATE, QUANTITY,
                            REMARK, TRANSACTION_UOM,LOCK_LEVEL,LOCK_TYPE)
                     VALUES (IS_USER_CODE, SYSDATE, IN_ENTITY_ID,
                            IN_INVENTORY_ID, S_INV_LOCKIN.NEXTVAL, IN_ITEM_ID,
                            IN_TRANSACTION_ID, IS_USER_CODE, SYSDATE, N_FACT_LOCK_QTY,
                            NULL, IS_ITEM_UOM,IN_LOCK_LEVEL,IS_LOCK_TYPE);
          ELSE
                    SELECT QUANTITY
                       INTO N_CURRENT_LOCK_QTY
                       FROM T_INV_LOCKIN
                      WHERE ENTITY_ID = IN_ENTITY_ID
                        AND  INVENTORY_ID = IN_INVENTORY_ID
                        AND  ITEM_ID = IN_ITEM_ID
                        AND LOCK_LEVEL = IN_LOCK_LEVEL
                        AND  LOCK_TYPE = IS_LOCK_TYPE
                   FOR UPDATE;

                    IF  IN_LOCK_QTY < 0 THEN
                        IF NEED_LOCK = 'N' THEN --不是按需锁定 直接提示异常
                               IF N_CURRENT_LOCK_QTY < ABS(IN_LOCK_QTY) THEN
                                   OS_MESSAGE :=
                                                  '解锁库存量异常：经营主体(ID:'
                                               || IN_ENTITY_ID
                                               || ');仓库(仓库编码:'
                                               || IS_INVENTORY_CODE
                                               || ');产品(产品编码:'
                                               || IS_ITEM_CODE
                                               || ')的库存锁定量不足！(库存锁定量：'
                                               ||'('||N_CURRENT_LOCK_QTY||')'
                                               ||',单据需求：'
                                               ||IN_LOCK_QTY
                                               ||')';
                                            OS_JSON_MSG := '{productModel:"'||IS_PRODUCTMODEL||'",entityId:'||IN_ENTITY_ID||',itemCode:"'||IS_ITEM_CODE||'",itemName:"'||IS_ITEM_NAME||'",handQty:'||N_CURRENT_LOCK_QTY||',qty:'||IN_LOCK_QTY||'}';

                                  RETURN;
                               ELSE
                                    N_FACT_LOCK_QTY := IN_LOCK_QTY;
                               END IF;
                       ELSE
                               IF N_CURRENT_LOCK_QTY < ABS(IN_LOCK_QTY) THEN
                                   N_FACT_LOCK_QTY := -1*N_CURRENT_LOCK_QTY;
                               ELSE
                                   N_FACT_LOCK_QTY := IN_LOCK_QTY;
                               END IF;
                       END IF;
                  END IF;

                   UPDATE T_INV_LOCKIN
                      SET QUANTITY = QUANTITY + N_FACT_LOCK_QTY,
                           LAST_TRANSACTION_ID = IN_TRANSACTION_ID,
                           LAST_UPDATED_BY = IS_USER_CODE,
                           LAST_UPDATE_DATE = SYSDATE
                    WHERE ENTITY_ID = IN_ENTITY_ID
                     AND  INVENTORY_ID = IN_INVENTORY_ID
                     AND  ITEM_ID = IN_ITEM_ID
                     AND LOCK_LEVEL = IN_LOCK_LEVEL
                     AND  LOCK_TYPE = IS_LOCK_TYPE;

                 IF  IN_LOCK_QTY < 0 THEN
                     UPDATE T_INV_LOCKIN
                        SET QUANTITY = QUANTITY + N_FACT_LOCK_QTY,
                             LAST_TRANSACTION_ID = IN_TRANSACTION_ID,
                             LAST_UPDATED_BY = IS_USER_CODE,
                             LAST_UPDATE_DATE = SYSDATE
                      WHERE ENTITY_ID = IN_ENTITY_ID
                       AND  INVENTORY_ID = IN_INVENTORY_ID
                       AND  ITEM_ID = IN_ITEM_ID
                       AND LOCK_LEVEL < IN_LOCK_LEVEL
                       AND  LOCK_TYPE = IS_LOCK_TYPE;
                 END IF;

         END IF;
  END;


   --------------------------------------------------------------------------
  --Author: guibr
  --Created: 2019-03-02
  --按订单  区域锁定库存
  --------------------------------------------------------------------------
  Procedure P_LOCKIN_ADD_HAND(
               IN_ENTITY_ID     IN  NUMBER
                 ,IS_SHARE_VENDOR_CODE  IN VARCHAR2
               ,IS_INVENTORY_CODE   IN VARCHAR2
               ,IS_DISTRICT_CODE  IN  VARCHAR2
               ,IN_ITEM_ID       IN  NUMBER
               ,IS_ITEM_CODE     IN  VARCHAR2
               ,IS_ITEM_UOM      IN  VARCHAR2
               ,IS_ITEM_NAME     IN  VARCHAR2
               ,IS_PRODUCTMODEL   IN  VARCHAR2
               ,IN_LOCK_QTY      IN  NUMBER
               ,IS_LOCK_TYPE     IN  VARCHAR2
               ,IN_LOCK_LEVEL    IN  NUMBER
               ,IS_DELIVERY_NUMBER  IN  VARCHAR2
               ,IS_ORDER_NUMBER  IN  VARCHAR2
               ,IS_CHILD_ORDER_NUMBER  IN  VARCHAR2
               ,IS_USER_CODE     IN  varchar2
               ,IS_sales_center_code in varchar2
               ,OS_UNLOCK_COMPLETION OUT VARCHAR2  --返回是否解锁完成标志
               ,ON_FACT_LOCK_QTY OUT NUMBER  --返回实际解锁数量
               ,OS_INVENTORY_LOCK  OUT VARCHAR2 --返回锁定释放仓库及对应数量
               ,OS_MESSAGE   OUT VARCHAR2    --成功则返回“OK”，否则返回出错信息
               ,OS_JSON_MSG   OUT VARCHAR2 --成功则返回“OK”，否则返回格式化出错信息
    ) --返回值
    IS
       N_FACT_LOCK_QTY NUMBER;
       N_CRRENT_LOCK_QTY NUMBER;
       N_ALL_LOCK_QTY NUMBER;
       S_LOCK_COMPLETION VARCHAR2(2);
       S_CHILD_MESSAGE VARCHAR2(4000);
   BEGIN
        S_LOCK_COMPLETION := 'N';
        N_CRRENT_LOCK_QTY :=  IN_LOCK_QTY;
        N_ALL_LOCK_QTY :=0;
        FOR INVENTORIES_ROW IN (
            SELECT INVENTORY_ID,INVENTORY_CODE FROM TABLE(PKG_INV_LOCKIN.F_GET_INV_LIST(IN_ENTITY_ID,IS_LOCK_TYPE,IS_DISTRICT_CODE,IS_sales_center_code,IS_INVENTORY_CODE))
      )
        LOOP
           BEGIN
              P_LOCKIN_HAND(0
                      ,IN_ENTITY_ID
                      ,INVENTORIES_ROW.INVENTORY_ID
                      ,INVENTORIES_ROW.INVENTORY_CODE
                      ,IN_ITEM_ID
                      ,IS_ITEM_CODE
                      ,IS_ITEM_UOM
                      ,IS_ITEM_NAME
                      ,IS_PRODUCTMODEL
                      ,N_CRRENT_LOCK_QTY
                      ,'Y'
                      ,IS_LOCK_TYPE
                      ,IN_LOCK_LEVEL
                      ,IS_USER_CODE
                      ,N_FACT_LOCK_QTY
                      ,S_CHILD_MESSAGE
                      ,OS_JSON_MSG
                      );
              IF S_CHILD_MESSAGE<>'OK' THEN
                   OS_MESSAGE := S_CHILD_MESSAGE;
                   RETURN;
              ELSE
                 P_LOCKIN_HISTORY_ADD(IN_ENTITY_ID   --插入锁定事物
                                    ,IS_SHARE_VENDOR_CODE
                                    ,INVENTORIES_ROW.INVENTORY_ID
                                    ,INVENTORIES_ROW.INVENTORY_CODE
                                    ,IN_ITEM_ID
                                    ,IS_ITEM_CODE
                                    ,IS_ITEM_UOM
                                    ,N_FACT_LOCK_QTY
                                    ,IN_ITEM_ID
                                    ,N_FACT_LOCK_QTY
                                    ,IS_LOCK_TYPE
                                    ,IN_LOCK_LEVEL
                                    ,IS_DELIVERY_NUMBER
                                    ,IS_ORDER_NUMBER
                                    ,IS_CHILD_ORDER_NUMBER
                                    ,IS_USER_CODE
                                    ,S_CHILD_MESSAGE
                 );

                 N_ALL_LOCK_QTY:=N_ALL_LOCK_QTY+N_FACT_LOCK_QTY;
                 IF N_FACT_LOCK_QTY<>0 THEN
                      OS_INVENTORY_LOCK := OS_INVENTORY_LOCK||','||INVENTORIES_ROW.INVENTORY_CODE||':'||N_FACT_LOCK_QTY;
                 END IF;
                 IF  N_CRRENT_LOCK_QTY-N_FACT_LOCK_QTY =0 THEN --锁定|解锁完毕
                      S_LOCK_COMPLETION:='Y';
                      EXIT;
                 ELSE
                      N_CRRENT_LOCK_QTY:=N_CRRENT_LOCK_QTY-N_FACT_LOCK_QTY;
                 END IF;
              END IF;
           END;
        END LOOP;

       OS_UNLOCK_COMPLETION:=  S_LOCK_COMPLETION;
       ON_FACT_LOCK_QTY := N_ALL_LOCK_QTY;
   END;

  --------------------------------------------------------------------------
  --Author: guibr
  --Created: 2019-03-02
  --按订单解锁库存
  --------------------------------------------------------------------------
  Procedure P_LOCKIN_SUB_HAND(
               IN_ENTITY_ID     IN  NUMBER
                 ,IS_SHARE_VENDOR_CODE  IN VARCHAR2
               ,IN_ITEM_ID       IN  NUMBER
               ,IS_ITEM_CODE     IN  VARCHAR2
               ,IS_ITEM_UOM      IN  VARCHAR2
               ,IS_ITEM_NAME     IN  VARCHAR2
               ,IS_PRODUCTMODEL   IN  VARCHAR2
               ,IN_LOCK_QTY      IN  NUMBER
               ,IS_LOCK_TYPE     IN  VARCHAR2
               ,IN_LOCK_LEVEL    IN  NUMBER
               ,IS_DELIVERY_NUMBER  IN  VARCHAR2
               ,IS_ORDER_NUMBER  IN  VARCHAR2
               ,IS_CHILD_ORDER_NUMBER  IN  VARCHAR2
               ,IS_USER_CODE     IN  VARCHAR2
               ,OS_UNLOCK_COMPLETION OUT VARCHAR2  --返回是否解锁完成标志
               ,ON_FACT_UNLOCK_QTY OUT NUMBER  --返回实际解锁数量
               ,OS_INVENTORY_LOCK  OUT VARCHAR2 --返回锁定释放仓库及对应数量
               ,OS_MESSAGE   OUT VARCHAR2    --成功则返回“OK”，否则返回出错信息
               ,OS_JSON_MSG   OUT VARCHAR2 --成功则返回“OK”，否则返回格式化出错信息
    ) --返回值
    IS

      N_CRRENT_LOCK_QTY NUMBER;
      N_ALL_UNLOCK_QTY NUMBER;
      S_LOCK_COMPLETION VARCHAR2(2);

      N_HAND_LOCK_COUNT  NUMBER;
      N_HAND_LOCK_QTY  NUMBER;

      N_UNLOCK_QTY NUMBER;
      N_UNLOCK_AFTER_QTY NUMBER;
      S_CHILD_MESSAGE VARCHAR2(4000);
    BEGIN
         OS_MESSAGE :=   'OK';
         N_CRRENT_LOCK_QTY := IN_LOCK_QTY;
         S_LOCK_COMPLETION:='N';
         N_ALL_UNLOCK_QTY :=0;
         FOR INVENTORIES_ROW IN (
               SELECT
                   INVENTORY_ID
                  ,INVENTORY_CODE
                  ,SUM(TRANSACTION_QUANTITY) TRANSACTION_QUANTITY
               FROM
                  CIMS.T_INV_LOCKIN_HISTORY
               WHERE
                    BUSINESS_NUM = IS_ORDER_NUMBER
                AND ENTITY_ID= IN_ENTITY_ID
                AND ITEM_ID = IN_ITEM_ID
                AND LOCK_TYPE = IS_LOCK_TYPE
                AND LOCK_LEVEL = IN_LOCK_LEVEL
              GROUP BY
                 INVENTORY_ID
                ,INVENTORY_CODE
               HAVING SUM(TRANSACTION_QUANTITY)>0
          ) LOOP
                BEGIN
                       SELECT COUNT (*)
                        INTO N_HAND_LOCK_COUNT
                        FROM T_INV_LOCKIN
                       WHERE ENTITY_ID = IN_ENTITY_ID
                         AND INVENTORY_ID = INVENTORIES_ROW.INVENTORY_ID
                         AND ITEM_ID = IN_ITEM_ID
                         AND LOCK_LEVEL = IN_LOCK_LEVEL
                         AND LOCK_TYPE = IS_LOCK_TYPE;

                         IF N_HAND_LOCK_COUNT > 0 THEN
                              SELECT QUANTITY
                                 INTO N_HAND_LOCK_QTY
                                 FROM T_INV_LOCKIN
                                WHERE ENTITY_ID = IN_ENTITY_ID
                                  AND  INVENTORY_ID = INVENTORIES_ROW.INVENTORY_ID
                                  AND  ITEM_ID = IN_ITEM_ID
                                  AND LOCK_LEVEL = IN_LOCK_LEVEL
                                  AND  LOCK_TYPE = IS_LOCK_TYPE
                             FOR UPDATE;


                             IF INVENTORIES_ROW.TRANSACTION_QUANTITY <= N_HAND_LOCK_QTY THEN
                                   N_UNLOCK_AFTER_QTY := N_CRRENT_LOCK_QTY+INVENTORIES_ROW.TRANSACTION_QUANTITY;
                                   IF N_UNLOCK_AFTER_QTY >= 0 THEN
                                         N_UNLOCK_QTY := N_CRRENT_LOCK_QTY;
                                         N_ALL_UNLOCK_QTY:= -1*N_UNLOCK_QTY+N_ALL_UNLOCK_QTY;
                                         N_CRRENT_LOCK_QTY:=0;
                                         S_LOCK_COMPLETION:='Y';

                                         OS_INVENTORY_LOCK := OS_INVENTORY_LOCK||','||INVENTORIES_ROW.INVENTORY_CODE||':'||-1*N_UNLOCK_QTY;

                                         P_LOCKIN_HISTORY_ADD(IN_ENTITY_ID   --插入解锁事物
                                                             ,IS_SHARE_VENDOR_CODE
                                                            ,INVENTORIES_ROW.INVENTORY_ID
                                                            ,INVENTORIES_ROW.INVENTORY_CODE
                                                            ,IN_ITEM_ID
                                                            ,IS_ITEM_CODE
                                                            ,IS_ITEM_UOM
                                                            ,N_UNLOCK_QTY
                                                            ,IN_ITEM_ID
                                                            ,N_UNLOCK_QTY
                                                            ,IS_LOCK_TYPE
                                                            ,IN_LOCK_LEVEL
                                                            ,IS_DELIVERY_NUMBER
                                                            ,IS_ORDER_NUMBER
                                                            ,IS_CHILD_ORDER_NUMBER
                                                            ,IS_USER_CODE
                                                            ,S_CHILD_MESSAGE
                                          );

                                         UPDATE T_INV_LOCKIN
                                         SET QUANTITY = QUANTITY + N_UNLOCK_QTY,
                                               LAST_TRANSACTION_ID = 0,
                                               LAST_UPDATED_BY = IS_USER_CODE,
                                               LAST_UPDATE_DATE = SYSDATE
                                        WHERE ENTITY_ID = IN_ENTITY_ID
                                         AND  INVENTORY_ID = INVENTORIES_ROW.INVENTORY_ID
                                         AND  ITEM_ID = IN_ITEM_ID
                                         AND LOCK_LEVEL = IN_LOCK_LEVEL
                                         AND  LOCK_TYPE <= IS_LOCK_TYPE;
                                      EXIT;  --解锁完成 退出循环
                                   ELSE
                                         N_UNLOCK_QTY := -1*INVENTORIES_ROW.TRANSACTION_QUANTITY;
                                         N_CRRENT_LOCK_QTY:=N_CRRENT_LOCK_QTY+ (-1*N_UNLOCK_QTY);
                                         N_ALL_UNLOCK_QTY:= -1*N_UNLOCK_QTY+N_ALL_UNLOCK_QTY;
                                         OS_INVENTORY_LOCK := OS_INVENTORY_LOCK||','||INVENTORIES_ROW.INVENTORY_CODE||':'||-1*N_UNLOCK_QTY;


                                        P_LOCKIN_HISTORY_ADD(IN_ENTITY_ID   --插入解锁事物
                                                            ,IS_SHARE_VENDOR_CODE
                                                            ,INVENTORIES_ROW.INVENTORY_ID
                                                            ,INVENTORIES_ROW.INVENTORY_CODE
                                                            ,IN_ITEM_ID
                                                            ,IS_ITEM_CODE
                                                            ,IS_ITEM_UOM
                                                            ,N_UNLOCK_QTY
                                                            ,IN_ITEM_ID
                                                            ,N_UNLOCK_QTY
                                                            ,IS_LOCK_TYPE
                                                            ,IN_LOCK_LEVEL
                                                            ,IS_DELIVERY_NUMBER
                                                            ,IS_ORDER_NUMBER
                                                            ,IS_CHILD_ORDER_NUMBER
                                                            ,IS_USER_CODE
                                                            ,S_CHILD_MESSAGE
                                          );

                                         UPDATE T_INV_LOCKIN
                                         SET QUANTITY = QUANTITY + N_UNLOCK_QTY,
                                               LAST_TRANSACTION_ID = 0,
                                               LAST_UPDATED_BY = IS_USER_CODE,
                                               LAST_UPDATE_DATE = SYSDATE
                                        WHERE ENTITY_ID = IN_ENTITY_ID
                                         AND  INVENTORY_ID = INVENTORIES_ROW.INVENTORY_ID
                                         AND  ITEM_ID = IN_ITEM_ID
                                         AND LOCK_LEVEL = IN_LOCK_LEVEL
                                         AND  LOCK_TYPE <= IS_LOCK_TYPE;
                              END IF;
                             ELSE
                                  OS_MESSAGE :=
                                  '解锁库存量异常：经营主体(ID:'
                                     || IN_ENTITY_ID
                                     || ');客户订单(订单号:'
                                     || IS_ORDER_NUMBER
                                     || ');仓库(仓库编码:'
                                     || INVENTORIES_ROW.INVENTORY_CODE
                                     || ');产品(产品编码:'
                                     || IS_ITEM_CODE
                                     || ')的库存锁定量不足！(锁定库存：'
                                     ||'('||N_HAND_LOCK_QTY||')'
                                     ||',可解锁数量：'
                                     || INVENTORIES_ROW.TRANSACTION_QUANTITY
                                     ||')';

                                      OS_JSON_MSG := '{productModel:"'||IS_PRODUCTMODEL||'",entityId:'||IN_ENTITY_ID||',itemCode:"'||IS_ITEM_CODE||'",itemName:"'||IS_ITEM_NAME||'",handQty:'||N_HAND_LOCK_QTY||',qty:'||INVENTORIES_ROW.TRANSACTION_QUANTITY||'}';

                                 RETURN;
                             END IF;
                         ELSE
                              OS_MESSAGE :=
                                  '解锁库存量异常：经营主体(ID:'
                               || IN_ENTITY_ID
                               || ');客户订单(订单号:'
                               || IS_ORDER_NUMBER
                               || ');仓库(仓库编码:'
                               || INVENTORIES_ROW.INVENTORY_CODE
                               || ');产品(产品编码:'
                               || IS_ITEM_CODE
                               || ')的库存锁定量不足！(锁定库存：'
                               ||'(0)'
                               ||',可解锁数量：'
                               || INVENTORIES_ROW.TRANSACTION_QUANTITY
                               ||')';

                               OS_JSON_MSG := '{productModel:"'||IS_PRODUCTMODEL||'",entityId:'||IN_ENTITY_ID||',itemCode:"'||IS_ITEM_CODE||'",itemName:"'||IS_ITEM_NAME||'",handQty:'||0||',qty:'||INVENTORIES_ROW.TRANSACTION_QUANTITY||'}';

                           RETURN;
                       END IF;
                END;
            END LOOP;

           OS_UNLOCK_COMPLETION:=  S_LOCK_COMPLETION;
           ON_FACT_UNLOCK_QTY := N_ALL_UNLOCK_QTY;
    END;



   --------------------------------------------------------------------------
  --Author: guibr
  --Created: 2019-02-18
  --插入锁定事物历史
  --------------------------------------------------------------------------
  Procedure P_LOCKIN_HISTORY_ADD(
               IN_ENTITY_ID     IN  NUMBER
               ,IS_SHARE_VENDOR_CODE IN VARCHAR2
               ,IN_INVENTORY_ID  IN  NUMBER
               ,IS_INVENTORY_CODE  IN  VARCHAR2
               ,IN_ITEM_ID       IN  NUMBER
               ,IS_ITEM_CODE     IN  VARCHAR2
               ,IS_ITEM_UOM      IN  VARCHAR2
               ,IN_LOCK_QTY      IN  NUMBER
               ,IN_SET_ITEM_ID   IN  NUMBER
               ,IN_SET_QTY   IN  NUMBER
               ,IS_LOCK_TYPE     IN  VARCHAR2
               ,IN_LOCK_LEVEL    IN  NUMBER
               ,IS_DELIVERY_NUMBER  IN  VARCHAR2
               ,IS_ORDER_NUMBER  IN  VARCHAR2
               ,IS_CHILD_ORDER_NUMBER  IN  VARCHAR2
               ,IS_USER_CODE     IN  VARCHAR2
               ,OS_MESSAGE   OUT VARCHAR2    --成功则返回“OK”，否则返回出错信息
    ) --返回值
    IS
    S_ORDER_NUMBER  VARCHAR2(100);
    S_CHILD_ORDER_NUMBER  VARCHAR2(100);
    S_DELIVERY_NUMBER  VARCHAR2(100);
  BEGIN
    OS_MESSAGE :=   'OK';
    S_ORDER_NUMBER :=NVL(IS_ORDER_NUMBER,'0');
    S_CHILD_ORDER_NUMBER :=NVL(IS_CHILD_ORDER_NUMBER,'0');
    S_DELIVERY_NUMBER := NVL(IS_DELIVERY_NUMBER,'0');
    INSERT INTO T_INV_LOCKIN_HISTORY(ENTITY_ID,TRANSACTION_ID,TRANSACTION_DATE,BATCH_NUM,BATCH_STATE,BUSINESS_STATE,BUSINESS_NUM,CHILD_BUSINESS_NUM,ITEM_ID,ITEM_CODE,ITEM_NAME,TRANSACTION_UOM,INVENTORY_ID,INVENTORY_CODE,INVENTORY_NAME,TRANSACTION_QUANTITY,LOCK_TYPE,LOCK_LEVEL,CREATED_BY,CREATION_DATE,LAST_UPDATED_BY,LAST_UPDATE_DATE,REMARK,SET_ITEM_ID,SET_TRANSACTION_QUANTITY,SHARE_VENDOR_CODE)
         VALUES (IN_ENTITY_ID,S_INV_LOCKIN_HISTORY.NEXTVAL,TRUNC(SYSDATE, 'DD'),S_DELIVERY_NUMBER,'Y','1',S_ORDER_NUMBER,S_CHILD_ORDER_NUMBER,IN_ITEM_ID,IS_ITEM_CODE,null,IS_ITEM_UOM,IN_INVENTORY_ID,IS_INVENTORY_CODE,null,IN_LOCK_QTY,IS_LOCK_TYPE,IN_LOCK_LEVEL,IS_USER_CODE,SYSDATE,IS_USER_CODE,SYSDATE,null,IN_SET_ITEM_ID,IN_SET_QTY,IS_SHARE_VENDOR_CODE);
  END;


 ------------------------------------------------------------
  /*   根据锁定类型获取不同的仓库列表         */
  ------------------------------------------------------------
  FUNCTION F_GET_INV_LIST(P_ENTITY_ID     IN NUMBER,
                          P_LOCKIN_TYPE   IN VARCHAR2, --网批 standard|库存共享 share|仓库 inv
                          P_DISTRICT_CODE IN VARCHAR2,
                          P_SALES_CENTER_CODE IN VARCHAR2,
                          P_INVENTORY_CODE   IN VARCHAR2
                          )
    RETURN TBL_INV_INVENTORY
    PIPELINED IS
    R_INV_INVENTORY OBJ_INV_INVENTORY;

  BEGIN
    IF P_LOCKIN_TYPE = 'standard' THEN
         FOR R_INV IN (
             SELECT INVENTORY_ID,INVENTORY_CODE FROM TABLE(PKG_INV_PUB.F_GET_AREA_INV_LIST(P_ENTITY_ID,P_DISTRICT_CODE,P_SALES_CENTER_CODE))
         ) LOOP
         R_INV_INVENTORY := OBJ_INV_INVENTORY(R_INV.INVENTORY_ID,
                                              R_INV.INVENTORY_CODE,
                                              null,
                                              null
                                             );
        PIPE ROW(R_INV_INVENTORY);
        END LOOP;
        RETURN;
   ELSIF  P_LOCKIN_TYPE = 'inv' OR (P_LOCKIN_TYPE = 'share' and P_INVENTORY_CODE IS  NOT NULL ) THEN
         FOR R_INV IN (
             select T.INVENTORY_ID,T.INVENTORY_CODE
             from cims.t_inv_inventories t where
              t.entity_id = P_ENTITY_ID
              and t.inventory_code = P_INVENTORY_CODE
         )LOOP
           R_INV_INVENTORY := OBJ_INV_INVENTORY(R_INV.INVENTORY_ID,
                                              R_INV.INVENTORY_CODE,
                                              null,
                                              null
                                             );
        PIPE ROW(R_INV_INVENTORY);
        END LOOP;
        RETURN;

    ELSIF P_LOCKIN_TYPE = 'share' THEN
         FOR R_INV IN (
              select distinct T.INVENTORY_ID,T.INVENTORY_CODE
              from cims.t_bd_lg_site_district sd,
                   cims.T_BD_LG_SITE_INV      si,
                   cims.t_inv_inventories t
             where si.site_code = sd.site_code
               and si.entity_id = sd.entity_id
               and t.entity_id = si.entity_id
               and t.inventory_code = si.inventory_code
               and si.status = 'Y' --状态为生效状态  待确认
               and sd.entity_id = P_ENTITY_ID        --根据主体
               and sd.district_code = P_DISTRICT_CODE --根据区域*/
               and t.sales_center_code = DECODE(P_ENTITY_ID,32,NVL(P_SALES_CENTER_CODE,T.SALES_CENTER_CODE),T.SALES_CENTER_CODE)--只有32主体才生效中心
        ) LOOP
         R_INV_INVENTORY := OBJ_INV_INVENTORY(R_INV.INVENTORY_ID,
                                              R_INV.INVENTORY_CODE,
                                              null,
                                              null
                                             );
        PIPE ROW(R_INV_INVENTORY);
        END LOOP;
        RETURN;

    ELSE
        FOR R_INV IN (
             select T.INVENTORY_ID,T.INVENTORY_CODE
             from cims.t_inv_inventories t where
              t.entity_id = P_ENTITY_ID
              and t.inventory_code = P_INVENTORY_CODE
         )LOOP
           R_INV_INVENTORY := OBJ_INV_INVENTORY(R_INV.INVENTORY_ID,
                                              R_INV.INVENTORY_CODE,
                                              null,
                                              null
                                             );
        PIPE ROW(R_INV_INVENTORY);
        END LOOP;
        RETURN;
    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      NULL;
  END;



END PKG_INV_LOCKIN;
/

