create PACKAGE PKG_AR_CIMSTOERP_CHECK is

-- CIMS与ERPAR对账
  PROCEDURE P_CIMSTOERP_CHECK
(
  P_MESSAGE                  out varchar2 --成功则返回“SUCCESS”，否则返回出错信息
                                );

END PKG_AR_CIMSTOERP_CHECK;
/

