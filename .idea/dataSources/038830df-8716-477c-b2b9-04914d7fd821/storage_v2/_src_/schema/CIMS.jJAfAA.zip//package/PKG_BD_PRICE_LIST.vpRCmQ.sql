create PACKAGE      PKG_BD_PRICE_LIST AS
  -----------------------------------------------------------------------------
  --  停用价格列表行      --add by liangym2
  -----------------------------------------------------------------------------
  PROCEDURE STOP_PRICE_LINE(IN_ENTITY_ID        IN NUMBER
                           ,IN_PRICE_LIST_ID    IN NUMBER
                           ,IN_ITEM_ID          IN NUMBER
                           ,IS_CHANNEL_ATTR     IN VARCHAR2
                           ,ID_STOP_DATE        IN DATE
                           ,IN_ADJUST_SRC_ID    IN NUMBER
                           ,IN_ADJUST_LINE_ID   IN NUMBER
                           ,IN_ADJUST_SRC_NUM   IN VARCHAR2
                           ,IS_LAST_UPDATE_BY   IN VARCHAR2
                           ,ID_LAST_UPDATE_DATE IN DATE
                           ,OS_MESSAGE          OUT VARCHAR2 --返回提示信息
                            );
                            
  -----------------------------------------------------------------------------
  --  多价格列表批量调整通过检查 锁表       --add by liangym2
  -----------------------------------------------------------------------------
  PROCEDURE MULTI_PRICE_MODIFY_CHECK(IN_ENTITY_ID      IN NUMBER
                                    ,IN_MODIFY_LIST_ID IN NUMBER
                                    ,IS_MESSAGE        IN VARCHAR2
                                    ,OS_MESSAGE        OUT VARCHAR2 --返回提示信息
                                     );
                                     
  -----------------------------------------------------------------------------
  --  价格列表通过回写其他接口表       --add by liangym2
  -----------------------------------------------------------------------------
  PROCEDURE PRICE_SUCCESS_WRITE(IN_ENTITY_ID      IN NUMBER
                               ,IN_LIST_ID        IN NUMBER
                               ,IN_ADJUST_LIST_ID IN NUMBER
                               ,IS_MODIFY_SOURCE  IN VARCHAR2
                               ,IS_LAST_UPDATE_BY IN VARCHAR2
                               ,OS_MESSAGE        OUT VARCHAR2 --返回提示信息
                                );
                                
  -----------------------------------------------------------------------------
  --  多价格列表批量调整通过回写正式表        --add by liangym2
  -----------------------------------------------------------------------------
  PROCEDURE MULTI_PRICE_MODIFY_WRITE(IN_ENTITY_ID      IN NUMBER
                                    ,IN_MODIFY_LIST_ID IN NUMBER
                                    ,IS_LAST_UPDATE_BY IN VARCHAR2
                                    ,OS_MESSAGE        OUT VARCHAR2 --返回提示信息
                                     );

  -----------------------------------------------------------------------------
  --  价格列表调整通过检查 锁表       --add by liangym2
  -----------------------------------------------------------------------------
  PROCEDURE PRICE_ADJUST_CHECK(IN_ENTITY_ID      IN NUMBER
                              ,IN_ADJUST_LIST_ID IN NUMBER
                              ,IS_MESSAGE        IN VARCHAR2
                              ,OS_MESSAGE        OUT VARCHAR2 --返回提示信息
                               );

  -----------------------------------------------------------------------------
  --  价格列表调整通过回写正式表        --add by liangym2
  ----如果价格调整功能限制启用日期必须是当天，使用该存储过程
  -----------------------------------------------------------------------------
  PROCEDURE PRICE_ADJUST_WRITE(IN_ENTITY_ID      IN NUMBER
                              ,IN_ADJUST_LIST_ID IN NUMBER
                              ,IS_LAST_UPDATE_BY IN VARCHAR2
                              ,OS_MESSAGE        OUT VARCHAR2 --返回提示信息
                               );

  -----------------------------------------------------------------------------
  --  价格列表调整通过回写正式表        --add by liangym2
  -----------------------------------------------------------------------------
  PROCEDURE PRICE_ADJUST_WRITE_NONDEL(IN_ENTITY_ID      IN NUMBER
                                     ,IN_ADJUST_LIST_ID IN NUMBER
                                     ,IS_LAST_UPDATE_BY IN VARCHAR2
                                     ,OS_MESSAGE        OUT VARCHAR2 --返回提示信息
                                      );
  
  --------------------------------------------------------------------
  --  价格列表调整或多价格列表批量调整审核通过后，写产品价格外发接口表
  --------------------------------------------------------------------
  PROCEDURE PRICE_ADJUST_2_ITEM_PRICE_INTF(IS_LAST_UPDATE_DATE IN VARCHAR2,
                                        OS_MESSAGE          OUT VARCHAR2 --返回提示信息
                                        );

END PKG_BD_PRICE_LIST;
/

