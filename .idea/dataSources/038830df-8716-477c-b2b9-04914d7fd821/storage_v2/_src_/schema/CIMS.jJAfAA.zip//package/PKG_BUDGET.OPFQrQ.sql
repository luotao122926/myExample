create Package      Pkg_Budget Is

 /*===============================================================
  * Program Name:   p_Synchro_Budget_Frame
  * Purpose     :   同步预算框架
   ===============================================================*/
  procedure p_Synchro_Budget_Frame(p_Data_Flow_Id In Number,
                                   --预算流ID
                                   p_Entity_Id      In Number,
                                   --主体ID
                                   p_User_Id        In Varchar2,
                                   --用户ID
                                   p_Result         Out Varchar2
                                   --返回结果：成功返回"SUCCESS"，失败返回原因
                                   );

 /*===============================================================
  * Program Name:   p_Chk_Bgt_Flow_System
  * Purpose     :   检查整个预算流体系
   ===============================================================*/
  Procedure p_Chk_Bgt_Flow_System(p_Data_Flow_Id In Number,
                                  --预算流ID
                                  p_Entity_Id      In Number,
                                  --主体ID
                                  p_Result         Out Varchar2
                                  --返回结果：成功返回"SUCCESS"，失败返回原因
                                  );

 /*===============================================================
  * Program Name:   p_Write_Fee
  * Purpose     :   回写节点费用
   ===============================================================*/
  Procedure p_Write_Fee(p_Data_Flow_Id In Number,
                        --预算流ID，不能为空
                        p_Entity_Id In Number,
                        --主体ID，不能为空
                        p_Budget_Tree_Id In Number,
                        --预算树单元ID，不能为空
                        p_Fee_Type In Varchar2,
                        --费用类型，不能为空
                        p_Fee_Id In Number,
                        --费用单ID，不能为空
                        p_Fee_Code In Varchar2,
                        --费用单号，不能为空
                        p_Comments In Varchar2,
                        --备注信息
                        p_Pre_Field_01 In Varchar2,
                        --备用字段
                        p_Pre_Field_02 In Varchar2,
                        --备用字段
                        p_Pre_Field_03 In Varchar2,
                        --备用字段
                        p_Pre_Field_04 In Varchar2,
                        --备用字段
                        p_Pre_Field_05 In Varchar2,
                        --备用字段
                        p_Pre_Field_06 In Varchar2,
                        --备用字段
                        p_Pre_Field_07 In Varchar2,
                        --备用字段
                        p_Pre_Field_08 In Varchar2,
                        --备用字段
                        p_Pre_Field_09 In Varchar2,
                        --备用字段
                        p_Fee In Number,
                        --费用金额，不能为空，可正可负，两位小数
                        p_User_Id In Number,
                        --用户ID
                        p_Result Out Varchar2
                        --返回结果：成功返回"SUCCESS"，失败返回原因
                        );

 /*===============================================================
  * Program Name:   p_Write_Fee
  * Purpose     :   回写节点费用
   ===============================================================*/
  Procedure p_Write_Fee(p_Data_Flow_Id In Number,
                        --预算流ID，不能为空
                        p_Entity_Id In Number,
                        --主体ID，不能为空
                        p_Budget_Tree_Id In Number,
                        --预算树单元ID，不能为空
                        p_Fee_Type In Varchar2,
                        --费用类型，不能为空
                        p_Fee_Id In Number,
                        --费用单ID，不能为空
                        p_Fee_Code In Varchar2,
                        --费用单号，不能为空
                        p_Comments In Varchar2,
                        --备注信息
                        p_Pre_Field_01 In Varchar2,
                        --备用字段
                        p_Fee In Number,
                        --费用金额，不能为空，可正可负，两位小数
                        p_User_Id In Number,
                        --用户ID
                        p_Result Out Varchar2
                        --返回结果：成功返回"SUCCESS"，失败返回原因
                        );

 /*===============================================================
  * Program Name:   p_Write_Fee
  * Purpose     :   回写节点费用
   ===============================================================*/
  Procedure p_Write_Fee(p_Data_Flow_Id In Number,
                        --预算流ID，不能为空
                        p_Entity_Id In Number,
                        --主体ID，不能为空
                        p_Budget_Segment_01_Id In Number Default -1,
                        --预算层次01ID
                        p_Budget_Segment_02_Id In Number Default -1,
                        --预算层次02ID
                        p_Budget_Segment_03_Id In Number Default -1,
                        --预算层次03ID
                        p_Budget_Segment_04_Id In Number Default -1,
                        --预算层次04ID
                        p_Budget_Segment_05_Id In Number Default -1,
                        --预算层次05ID
                        p_Budget_Segment_06_Id In Number Default -1,
                        --预算层次06ID
                        p_Fee_Type In Varchar2,
                        --费用类型，不能为空
                        p_Fee_Id In Number,
                        --费用单ID，不能为空
                        p_Fee_Code In Varchar2,
                        --费用单号，不能为空
                        p_Comments In Varchar2,
                        --备注信息
                        p_Pre_Field_01 In Varchar2,
                        --备用字段
                        p_Fee In Number,
                        --费用金额，不能为空，可正可负，两位小数
                        p_User_Id In Number,
                        --用户ID
                        p_Result Out Varchar2
                        --返回结果：成功返回"SUCCESS"，失败返回原因
                        );

  /*-----------------------------------------------------------------------*/
  /*--------------------- 许云志增加直接增加或减少预算的过程 ----------------*/
  /*-----------------------------------------------------------------------*/
  Procedure p_Direct_Adjust_Budget(p_Data_Flow_Id In Number,
                                   --预算流ID
                                   p_Entity_Id In Number,
                                   --主体ID
                                   p_Budget_Tree_Id In Number,
                                   --预算树单元ID
                                   p_Amount In Number,
                                   --追加指定预算
                                   p_Budget_Order_Id In Number Default -1,
                                   --预算操作关联单据ID
                                   p_Budget_Order_Code In Varchar2,
                                   --预算操作管理单据编码
                                   p_Adjust_Type In Varchar2,
                                   --预算调整类型 预借（支）预算回收 溢价导预算
                                   p_Comments In Varchar2,
                                   --备注信息
                                   p_User_Id In Number,
                                   --用户ID
                                   p_Result Out Varchar2
                                   --返回结果：成功返回"SUCCESS"，失败返回原因
                                   );

  -------------------------------------------------------------------------------------------
  -- 刘欢 增加 2008-12-24
  --同过程p_Check_Budget_Detail，增加处理不用严控的预算调整明细类型
  ---------------------------------------------------------------------------------------
  Procedure p_Check_Adjust_Budget_Detail(p_Data_Flow_Id In Number,
                                         --预算流ID
                                         p_Entity_Id In Number,
                                         --主体ID
                                         p_Budget_Detail_Id In Number,
                                         --预算明细单据ID,
                                         P_Num_Index In number,
                                         --参数顺序
                                         p_User_Id In Number,
                                         --用户ID
                                         p_Result Out Varchar2
                                         --返回结果：成功返回"SUCCESS"，失败返回原因
                                         );

  ----------------------------------------------------------------------
  -- 刘欢 增加 2008-12-24
  --同过程p_Check_Details，增加处理不用严控的预算调整明细类型
  -----------------------------------------------------------------------
  Procedure p_Check_Adjust_Budget_Details(p_Data_Flow_Id In Number,
                                          --预算流ID
                                          p_Entity_Id In Number,
                                          --主体ID
                                          p_Budget_Detail_Ids In Varchar2,
                                          --预算明细单据ID串（间隔空格）
                                          p_User_Id In Number,
                                          --用户ID
                                          p_Budget_Detail_Id Out Number,
                                          --返回供定位使用的预算明细单据ID
                                          p_Result Out Varchar2
                                          --返回结果：成功返回"SUCCESS"，失败返回原因
                                          );

 /*===============================================================
  * Program Name:   p_Check_Budget_Detail
  * Purpose     :   审核预算明细单据
   ===============================================================*/
  Procedure p_Check_Budget_Detail(p_Data_Flow_Id In Number,
                                  --预算流ID
                                  p_Entity_Id In Number,
                                  --主体ID
                                  p_Budget_Detail_Id In Number,
                                  --预算明细单据ID
                                  p_User_Id In Number,
                                  --用户ID
                                  p_Result Out Varchar2
                                  --返回结果：成功返回"SUCCESS"，失败返回原因
                                  );

 /*===============================================================
  * Program Name:   p_Check_Budget_Detail
  * Purpose     :   审核预算明细单据
   ===============================================================*/
  Procedure p_Check_Budget_Detail(p_Data_Flow_Id In Number,
                                  --预算流ID
                                  p_Entity_Id In Number,
                                  --主体ID
                                  p_Budget_Detail_Id In Number,
                                  --预算明细单据ID
                                  p_Chk_Bgt_Change_Flag In Varchar2,
                                  --备用金调整
                                  p_User_Id In Number,
                                  --用户ID
                                  p_Result Out Varchar2
                                  --返回结果：成功返回"SUCCESS"，失败返回原因
                                  );

 /*===============================================================
  * Program Name:   p_Check_Budget_Detail
  * Purpose     :   批量审核预算明细单据
   ===============================================================*/
  Procedure p_Check_Budget_Details(p_Data_Flow_Id In Number,
                                   --预算流ID
                                   p_Entity_Id In Number,
                                   --主体ID
                                   p_Budget_Detail_Ids In Varchar2,
                                   --预算明细单据ID串（间隔空格）
                                   p_User_Id In Number,
                                   --用户ID
                                   p_Budget_Detail_Id Out Number,
                                   --返回供定位使用的预算明细单据ID
                                   p_Result Out Varchar2
                                   --返回结果：成功返回"SUCCESS"，失败返回原因
                                   );

 /*===============================================================
  * Program Name:   p_Check_Budget_Detail
  * Purpose     :   批量审核预算明细单据
   ===============================================================*/
  Procedure p_Check_Budget_Details(p_Data_Flow_Id In Number,
                                   --预算流ID
                                   p_Entity_Id In Number,
                                   --主体ID
                                   p_Budget_Detail_Ids In Varchar2,
                                   --预算明细单据ID串（间隔空格）
                                   p_Chk_Bgt_Change_Flag In Varchar2,
                                   --备用金调整
                                   p_User_Id In Number,
                                   --用户ID
                                   p_Budget_Detail_Id Out Number,
                                   --返回供定位使用的预算明细单据ID
                                   p_Result Out Varchar2
                                   --返回结果：成功返回"SUCCESS"，失败返回原因
                                   );

 /*===============================================================
  * Program Name:   p_Budget_Detail_Import
  * Purpose     :   预算明细导入
   ===============================================================*/
  Procedure p_Budget_Detail_Import(pTopLevel_ID in T_POL_BUDGET_TREE.BUDGET_TREE_ID%type,
                                   --预算树ID
                                   pIMP_ID in T_POL_BUDGET_DETAIL_IMPORT.IMP_ID%type,
                                   --导入批号
                                   pUserID in number,
                                   --用户ID
                                   pResult in out Varchar2
                                   --返回值
                                   );

 /*===============================================================
  * Program Name:   p_Budget_Detail_Import
  * Purpose     :   预算明细导入
   ===============================================================*/
  Procedure p_Budget_Detail_Import(pTopLevel_ID in T_POL_BUDGET_TREE.BUDGET_TREE_ID%type,
                                   --预算树ID
                                   pIMP_ID in T_POL_BUDGET_DETAIL_IMPORT.IMP_ID%type,
                                   --导入批号
                                   pUserID in number,
                                   --用户ID
                                   pCanError in Varchar2,
                                   --允许导入出错
                                   pResult in out Varchar2
                                   --返回值
                                   );

  /*===============================================================
  * Program Name:   p_Direct_Super_Add_Budget
  * Purpose     :   从系统外直接追加指定正预算到指定单元（负金额反向）
   ===============================================================*/
  Procedure p_Direct_Super_Add_Budget(p_Data_Flow_Id In Number,
                                      --预算流ID
                                      p_Entity_Id In Number,
                                      --主体ID
                                      p_Budget_Tree_Id In Number,
                                      --预算树单元ID
                                      p_Amount In Number,
                                      --追加指定预算
                                      p_Budget_Order_Id In Number Default -1,
                                      --预算操作关联单据ID
                                      p_Budget_Order_Code In Varchar2,
                                      --预算操作管理单据编码
                                      p_Comments In Varchar2,
                                      --备注信息
                                      p_User_Id In Number,
                                      --用户ID
                                      p_Result Out Varchar2
                                      --返回结果：成功返回"SUCCESS"，失败返回原因
                                      );
  -------------------------------------------------------------------------------
  /*同步占用预算（触发器调用，不能够回滚）*/
  -------------------------------------------------------------------------------
  PROCEDURE p_Sync_Upd_Budget(p_Entity_Id              IN NUMBER, --主体ID
                              p_Data_Flow_Id           IN NUMBER, --预算流ID
                              p_Budget_Tree_Id        IN NUMBER, --预算树单元ID
                              p_Source_Type            IN VARCHAR2, --来源类型
                              p_Source_Id              IN NUMBER, --来源单ID
                              p_Source_Code            IN VARCHAR2, --来源单号
                              p_Sum_Amount             IN NUMBER, --费用总额
                              p_User_Id                IN NUMBER, --用户ID
                              p_Comments               IN VARCHAR2, --备注信息
                              p_Pre_Field_01           IN VARCHAR2, --备用字段01
                              p_Pre_Field_02           IN VARCHAR2, --备用字段02
                              p_Pre_Field_03           IN VARCHAR2, --备用字段03
                              p_Pre_Field_04           IN VARCHAR2, --备用字段04
                              p_Pre_Field_05           IN VARCHAR2, --备用字段05
                              p_Pre_Field_06           IN VARCHAR2, --备用字段06
                              p_Pre_Field_07           IN VARCHAR2, --备用字段07
                              p_Pre_Field_08           IN VARCHAR2, --备用字段08
                              p_Pre_Field_09           IN VARCHAR2, --备用字段09
                              p_Result                 OUT VARCHAR2 --返回结果：成功返回"SUCCESS"，失败返回原因
                              );

  -----------------------------------------------------------------------------
  --      获取主体语义                                                       --
  -----------------------------------------------------------------------------
  PROCEDURE p_Get_Entity_Semantic(P_SEMANTIC_ID            IN NUMBER   --语义ID
                                 ,P_ENTITY_ID              IN NUMBER   --主体ID
                                 ,P_SEMANTIC_TYPE         OUT VARCHAR2 --语义类型：SQL取值、计算公式
                                 ,P_SEMANTIC_VAL          OUT VARCHAR2 --语义值
                                 ,P_PRE_PROC_SQL          OUT VARCHAR2 --预执行语句
                                 ,P_QUERY_CODE            OUT VARCHAR2 --查询条件编码
                                 ,P_MESSAGE               OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
                                 );

 /*===============================================================
  * Program Name:   p_Calculation_Formula_Parse
  * Purpose     :   计算公式解析过程
   ===============================================================*/
  PROCEDURE p_Calculation_Formula_Analyze(p_Formula_Id              IN NUMBER   --公式ID
                                          ,p_Entity_Id              IN NUMBER   --主体ID
                                          ,p_Result                 OUT VARCHAR2 --返回结果：成功返回"SUCCESS"，失败返回原因
                                          );

 /*===============================================================
  * Program Name:   p_Source_Calculation
  * Purpose     :   预算来源计算过程
   ===============================================================*/
  PROCEDURE p_Source_Calculation(p_Formula_Id              IN NUMBER   --公式ID
                                 ,p_Period_Id              IN NUMBER   --计算阶段ID
                                 ,p_Begin_Date             IN DATE     --开始日期
                                 ,p_End_Date               IN DATE     --结束日期
                                 ,p_Entity_Id              IN NUMBER   --主体ID
                                 ,p_Result                 OUT VARCHAR2 --返回结果：成功返回"SUCCESS"，失败返回原因
                                 );

 /*===============================================================
  * Program Name:   p_Period_CarryOver_Budget
  * Purpose     :   月度结转预算的过程
   ===============================================================*/
  Procedure p_Period_CarryOver_Budget(p_Data_Flow_Id In Number,
                                      --预算流ID
                                      p_Entity_Id In Number,
                                      --主体ID
                                      p_Budget_Tree_Id In Number,
                                      --预算树单元ID
                                      p_Amount In Number,
                                      --追加指定预算
                                      p_Budget_Order_Id In Number Default -1,
                                      --预算操作关联单据ID
                                      p_Budget_Order_Code In Varchar2,
                                      --预算操作管理单据编码
                                      p_Adjust_Type In Varchar2,
                                      --预算调整类型 预借（支）预算回收 溢价导预算
                                      p_Comments In Varchar2,
                                      --备注信息
                                      p_User_Id In Number,
                                      --用户ID
                                      p_Result Out Varchar2
                                      --返回结果：成功返回"SUCCESS"，失败返回原因
                                      );

 /*===============================================================
  * Program Name:   p_Year_CarryOver_Budget
  * Purpose     :   年度结转预算的过程
   ===============================================================*/
  Procedure p_Year_CarryOver_Budget(p_Data_Flow_Id In Number,
                                    --预算流ID
                                    p_Entity_Id In Number,
                                    --主体ID
                                    p_Budget_Tree_Id In Number,
                                    --预算树单元ID
                                    p_Amount In Number,
                                    --追加指定预算
                                    p_Budget_Order_Id In Number Default -1,
                                    --预算操作关联单据ID
                                    p_Budget_Order_Code In Varchar2,
                                    --预算操作管理单据编码
                                    p_Adjust_Type In Varchar2,
                                    --预算调整类型 预借（支）预算回收 溢价导预算
                                    p_Comments In Varchar2,
                                    --备注信息
                                    p_User_Id In Number,
                                    --用户ID
                                    p_Result Out Varchar2
                                    --返回结果：成功返回"SUCCESS"，失败返回原因
                                    );

 /*===============================================================
  * Program Name:   p_Check_Fee
  * Purpose     :   检查节点费用
   ===============================================================*/
  Procedure p_Check_Fee(p_Data_Flow_Id In Number,
                        --数据流程ID，不能为空
                        p_Entity_Id In Number,
                        --主体ID，不能为空
                        p_Budget_Tree_Id In Number,
                        --预算树单元ID，不能为空
                        p_Fee_Type In Varchar2,
                        --费用类型，不能为空
                        p_Fee_Id In Number,
                        --费用单ID，不能为空
                        p_Fee_Code In Varchar2,
                        --费用单号，不能为空
                        p_Comments In Varchar2,
                        --备注信息
                        p_Pre_Field_01 In Varchar2,
                        --备用字段
                        p_Pre_Field_02 In Varchar2,
                        --备用字段
                        p_Pre_Field_03 In Varchar2,
                        --备用字段
                        p_Pre_Field_04 In Varchar2,
                        --备用字段
                        p_Pre_Field_05 In Varchar2,
                        --备用字段
                        p_Pre_Field_06 In Varchar2,
                        --备用字段
                        p_Pre_Field_07 In Varchar2,
                        --备用字段
                        p_Pre_Field_08 In Varchar2,
                        --备用字段
                        p_Pre_Field_09 In Varchar2,
                        --备用字段
                        p_Fee In Number,
                        --费用金额，不能为空，可正可负，两位小数
                        p_User_Id In Number,
                        --用户ID
                        p_Result Out Varchar2
                        --返回结果：成功返回"SUCCESS"，失败返回原因
                        );

 /*===============================================================
  * Program Name:   p_Check_Fee
  * Purpose     :   检查节点费用
   ===============================================================*/
  Procedure p_Check_Fee(p_Data_Flow_Id In Number,
                        --数据流程ID，不能为空
                        p_Entity_Id In Number,
                        --主体ID，不能为空
                        p_Budget_Segment_01_Id In Number Default -1,
                        --预算层次01ID
                        p_Budget_Segment_02_Id In Number Default -1,
                        --预算层次02ID
                        p_Budget_Segment_03_Id In Number Default -1,
                        --预算层次03ID
                        p_Budget_Segment_04_Id In Number Default -1,
                        --预算层次04ID
                        p_Budget_Segment_05_Id In Number Default -1,
                        --预算层次05ID
                        p_Budget_Segment_06_Id In Number Default -1,
                        --预算层次06ID
                        p_Fee_Type In Varchar2,
                        --费用类型，不能为空
                        p_Fee_Id In Number,
                        --费用单ID，不能为空
                        p_Fee_Code In Varchar2,
                        --费用单号，不能为空
                        p_Comments In Varchar2,
                        --备注信息
                        p_Pre_Field_01 In Varchar2,
                        --备用字段
                        p_Fee In Number,
                        --费用金额，不能为空，可正可负，两位小数
                        p_User_Id In Number,
                        --用户ID
                        p_Result Out Varchar2
                        --返回结果：成功返回"SUCCESS"，失败返回原因
                        );

 /*===============================================================
  * Program Name:   F_GET_Segment03
  * Purpose     :   是否可以负数报账
   ===============================================================*/
  function F_GET_Segment03(p_Budget_Segment_Name Varchar2,
                           p_Entity_Id number)
    return    Varchar2;

  Procedure P_CHECK_BUDGET_FEE(P_BUDGET_ADJUST_LINE_ID In Number,
                               p_Result Out Varchar2
                               );

 /*===============================================================
  * Program Name:   P_JUDGE_BUDGET_ADJUST
  * Purpose     :   检查预算调整单是否足够
   ===============================================================*/
  Procedure P_JUDGE_BUDGET_ADJUST(P_BUDGET_ADJUST_HEAD_ID In Number,
                                  p_Result Out Varchar2
                               );

  PROCEDURE P_GET_BUDGET_FLAG(P_BUDGET_ADJUST_ID IN NUMBER,
                               P_RESULT OUT VARCHAR2);

   /*===============================================================
  * Program Name:   P_BUDGET_ADJUST_CHECK
  * Purpose     :   预算调整执行预算过程
   ===============================================================*/
  PROCEDURE P_BUDGET_ADJUST_CHECK(P_BUDGET_ADJUST_HEAD_ID In Number,
                                  P_TO_CHECK_FLAG IN Varchar2,
                                  P_CHECKED_FLAG IN Varchar2,
                                  P_REJECT_FLAG IN Varchar2,
                                  P_INVALID_FLAG IN Varchar2,
                                  p_Result Out Varchar2
                               );


 /*===============================================================
  * Program Name:   P_BUDGET_CTRL_ADJUST
  * Purpose     :   预算进度调整过程
  ===============================================================*/
  PROCEDURE P_BUDGET_CTRL_ADJUST(P_CTRL_BATCH_ID In Number,
                                  p_User_Id IN Varchar2,
                                  p_Result Out Varchar2
                               );
  
  /*===============================================================
   * Program Name:   P_JUDGE_CROSS_BUDGET_ADJUST
   * Purpose     :   检查跨主体预算调整单预算是否足够
  =================================================================*/
  PROCEDURE P_JUDGE_CROSS_BUDGET_ADJUST(P_BUDGET_ADJUST_HEAD_ID IN NUMBER
                                       ,P_RESULT OUT VARCHAR2);
  
  /*===============================================================
  * Program Name:   P_EXECUTE_CROSS_BUDGET_ADJUST
  * Purpose     :   执行跨主体预算调整
  ===============================================================*/
 PROCEDURE P_EXECUTE_CROSS_BUDGET_ADJUST(P_BUDGET_ADJUST_HEAD_ID IN NUMBER
                                        ,P_TO_CHECK_FLAG         IN VARCHAR2
                                        ,P_CHECKED_FLAG          IN VARCHAR2
                                        ,P_REJECT_FLAG           IN VARCHAR2
                                        ,P_INVALID_FLAG          IN VARCHAR2
                                        ,P_RESULT                OUT VARCHAR2);
  
End Pkg_Budget;
/

