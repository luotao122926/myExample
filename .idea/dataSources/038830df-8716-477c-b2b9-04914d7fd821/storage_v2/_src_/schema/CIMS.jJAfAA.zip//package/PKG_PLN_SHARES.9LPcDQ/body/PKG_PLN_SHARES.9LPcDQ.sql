create Package Body      Pkg_Pln_Shares Is
  v_Nl      Constant Varchar2(2) := Chr(13) || Chr(10); --换行
  v_Null    Constant Varchar2(4) := 'null'; --空值
  v_Close   Constant Varchar2(2) := 'C'; --关闭
  v_Success Constant Varchar2(10) := 'SUCCESS';
  v_Base_Exception Exception; --自定义异常

  v_Docking_System_A3    Constant Varchar2(100) := 'A3'; --A3系统管理仓库
  v_Docking_System_CIMS  Constant Varchar2(100) := 'CIMS'; --CIMS系统管理的仓库
  v_Operation_Auditing Constant Varchar2(100) := 'AUDITING';   --审核
  v_Operation_Receiving Constant Varchar2(100) := 'RECEIVING';  --接收

  ---------------------------------------------------------------------------------
  -- Author  : NICRO.LI
  -- Created : 2014-08-20 10:43:59
  -- Purpose : 订单管理 自动生成发货计划
  ---------------------------------------------------------------------------------
  Procedure p_Auto_Create_Share(p_Pln_Order_Line_Id In Number, --订单行ID
                                p_Inventory_Id      In Number, --仓库ID(财务仓)
                                p_Trans_Sign_Flag   In Number, --生成发货计划方向，1：生成发货计划  -1：取消发货计划
                                p_Trans_Share_Qty   In Number, --分配数量（只传正数）
                                p_Entity_Id         In Number, --主体ID
                                p_Pln_Wip_Ord_Match In Varchar, --工单与订单新匹配模式
                                p_User_Code         In Varchar2,
                                p_Result            Out Varchar2,
                                p_Inv_Affirm_Flag   In Varchar2 Default v_False, --库存评审标志
                                p_Sub_Item_id       In Number Default Null       --散件产品ID
                                ) Is
    v_Value                Varchar2(2000);
    v_Count                Number;
    v_Item_Id              Number;
    v_Item_Code            t_Bd_Item.Item_Code%Type;
    v_Item_Name            t_Bd_Item.Item_Name%Type;
    v_Usable_Carry_Qty     Number;
    v_Inv_Usable_Carry_Qty Number;  --库存评审已分配未下达数量
    v_Sum_Share_Qty        Number;
    v_Item_Occupy_Qty      Number;
    v_Usable_Occupy_Qty    Number;
    v_Usable_So_Order_Qty  Number;
    v_Order_Share_Id       Number;
    v_Sub_Item_Occupy_Qty  Number; --散件占用数量
    v_Ass_Item_Occupy_Qty  Number; --散件转套件占用数量
    r_Pln_Order_Head       t_Pln_Order_Head%Rowtype;
    v_Unit_Volume          Number;
    v_Check_Share_Qty      Number := 0;
  Begin
    p_Result := v_Success;
    If p_Trans_Share_Qty Is Not Null And p_Trans_Share_Qty = 0 Then
      Return;
    End If;
    Select Count(1)
      Into v_Count
      From t_Inv_Inventories Ii
     Where Ii.Inventory_Id = p_Inventory_Id
       And Ii.Entity_Id = p_Entity_Id;
    If Nvl(v_Count, 0) = 0 Then
      v_Value := '检查发货仓库ID失败，仓库ID：' || To_Char(p_Inventory_Id);
      Raise v_Base_Exception;
    End If;

    Begin
      v_Value := '获取订单行套件商品信息，订单行ID：' || To_Char(p_Pln_Order_Line_Id);
      Select Pol.Item_Id, Pol.Item_Code, Pol.Item_Desc
        Into v_Item_Id, v_Item_Code, v_Item_Name
        From t_Pln_Order_Line Pol
       Where Pol.Order_Line_Id = p_Pln_Order_Line_Id;
    Exception
      When Others Then
        Raise v_Base_Exception;
    End;
    Begin
      Select *
        Into r_Pln_Order_Head
        From t_Pln_Order_Head Oh
       Where Oh.Order_Head_Id In
             (Select Order_Head_Id
                From t_Pln_Order_Line Ol
               Where Ol.Order_Line_Id = p_Pln_Order_Line_Id);
    Exception
      When Others Then
        v_Value := '获取订单头信息失败，订单行ID：' || To_Char(p_Pln_Order_Line_Id) || v_Nl ||
                   Sqlerrm;
        Raise v_Base_Exception;
    End;

    Begin
      v_Value := '计算商品已分配数量，商品ID:' || v_Item_Id;
      --统计所有已分配行数据，因为占用数包含订单行所有占用
      Select /*Nvl(Sum(Decode(Oss.Source_Order_Share_Id,
                            Null,
                            Nvl(Oss.Share_Qty, 0) - Nvl(Oss.Carry_Qty, 0),
                            0)),
                 0),*/ --add by lizhen 2015-01-13 取消分配行数量时调拨申请接收生成数据不参与计算
              --modi by lizhen 2015-01-22 所以发货计划都允许做破损。
              Nvl(Sum(Nvl(Oss.Share_Qty, 0) - Nvl(Oss.Carry_Qty, 0)), 0),
             /*Nvl(Sum(Decode(Nvl(Oss.Inv_Share_Flag, v_False),
                        v_False,
                        Nvl(Oss.Share_Qty, 0) - Nvl(Oss.Carry_Qty, 0),
                        0)),
             0),*/ --MODI BY LIZHEN 2015-01-13 库存评审允许做破损调拨
             Nvl(Sum(Nvl(Oss.Share_Qty, 0)), 0),
             Nvl(Sum(Nvl(Oss.Share_Qty, 0) - Nvl(Oss.So_Order_Qty, 0)), 0)
        --已分配未下达数量       总分配数量      已分配未开单数量
        Into v_Usable_Carry_Qty, v_Sum_Share_Qty, v_Usable_So_Order_Qty
        From t_Pln_Order_Share_Shipment Oss
       Where Oss.Item_Id = v_Item_Id
         And Oss.Entity_Id = p_Entity_Id
         And Oss.Inventory_From_Id = p_Inventory_Id
         And Nvl(Oss.Close_Flag, v_False) <> v_Close
         And Nvl(Oss.Share_Qty, 0) > Nvl(Oss.So_Order_Qty, 0)
            --增加工单与订单新匹配模式下取可用分配数量条件
         And (p_Pln_Wip_Ord_Match = v_False Or
             (p_Pln_Wip_Ord_Match = v_True And
             Oss.Origin_Line_Id = p_Pln_Order_Line_Id));
    Exception
      When No_Data_Found Then
        v_Usable_Carry_Qty    := 0;
        v_Usable_So_Order_Qty := 0;
        v_Sum_Share_Qty       := 0;
      When Others Then
        Raise v_Base_Exception;
    End;

    If Nvl(v_Sum_Share_Qty, 0) = 0 And p_Trans_Sign_Flag = -1 Then
      --红冲中转单，未生成分配行，或者生成分配行的分配数量为0，则直接退出，不需更新分配行数据。
      --v_Value := '订单行未生成订单发货计划，取消发货计划数量失败！';
      Return;
    End If;

    v_Item_Occupy_Qty := Pkg_Pln_Inv_Occupy.f_Item_Ass_Occupy_Qty(p_Inventory_Id,
                                                                  v_Item_Id,
                                                                  p_Pln_Wip_Ord_Match,
                                                                  p_Entity_Id,
                                                                  p_Pln_Order_Line_Id);
    --中转单红冲时，需比较被冲销散件的占用
    If p_Sub_Item_id Is Not Null Then
      v_Sub_Item_Occupy_Qty := Pkg_Pln_Inv_Occupy.f_Item_Ass_Occupy_Qty(p_Inventory_Id,
                                                                        p_Sub_Item_id,
                                                                        p_Pln_Wip_Ord_Match,
                                                                        p_Entity_Id,
                                                                        p_Pln_Order_Line_Id);
      --把散件的库存占用数按套散件关系系数转换成套件数量
      Select Trunc(v_Sub_Item_Occupy_Qty /
                   Nvl((Select Ias.Quantity
                         From t_Bd_Item_Assemblies     Bia,
                              t_Bd_Item_Assemblies_Sub Ias
                        Where Bia.Item_Assembly_Id = Ias.Item_Assembly_Id
                          And Bia.Entity_Id = Ias.Entity_Id
                          And Trunc(Sysdate) Between Bia.Begin_Date And
                              Nvl(Bia.End_Date, Sysdate)
                          And Trunc(Sysdate) Between Ias.Begin_Date And
                              Nvl(Ias.End_Date, Trunc(Sysdate))
                          And Bia.Item_Id = v_Item_Id
                          And Ias.Item_Id = p_Sub_Item_Id
                       Union All
                       --非套件产品
                       Select 1 Quantity
                         From t_Bd_Item Tbi
                        Where Tbi.Item_Id = v_Item_Id
                          And Not Exists
                        (Select 1
                                 From t_Bd_Item_Assemblies Bia
                                Where Bia.Item_Id = Tbi.Item_Id
                                  And Trunc(Sysdate) Between Bia.Begin_Date And
                                      Nvl(Bia.End_Date, Sysdate))),
                       1))
        Into v_Ass_Item_Occupy_Qty
        From Dual;
    Else
      v_Ass_Item_Occupy_Qty := v_Item_Occupy_Qty;
    End If;
    If v_Item_Occupy_Qty - Nvl(v_Usable_So_Order_Qty, 0) <= 0 And p_Trans_Sign_Flag = 1 Then
      --当前散件行的已锁定数量>套件的已锁定数量时，则不需更新发货计划
      --由于在匹配过程进行的中转单加锁与解锁，本过程获取的锁定数为加、解锁后的数据
      --在本过程比较时不需要加入中转单行数量进行对比
      Return;
    End If;
    If Nvl(v_Ass_Item_Occupy_Qty, 0) >= Nvl(v_Usable_So_Order_Qty, 0) And
      p_Trans_Sign_Flag = -1 Then
      --当前散件行转换成套件的已占用数量  > 套件的已分配未开单数量时，则不需取消发货计划
      --由于在匹配过程进行的中转单加锁与解锁，本过程获取的锁定数为加、解锁后的数据
      --在本过程比较时不需要加入中转单行数量进行对比
      Return;
    End If;

    If p_Trans_Sign_Flag = -1 Then
      v_Usable_Occupy_Qty := Least(Abs(Nvl(v_Ass_Item_Occupy_Qty, 0)
                              - Nvl(v_Usable_So_Order_Qty, 0)), Abs(p_Trans_Share_Qty));
      If v_Usable_Occupy_Qty > Nvl(v_Usable_Carry_Qty, 0) Then
        v_Value := '检查取消发货计划数量失败，订单发货计划行已分配未下达数量：【' || To_Char(v_Usable_Carry_Qty) ||
                   '】，本次取消发货计划数量：【' || To_Char(Abs(v_Usable_Occupy_Qty)) ||
                   '】，已分配未下达数量小于取消发货计划数量，取消失败。' || v_Nl ||
                   '订单行ID：' || To_Char(p_Pln_Order_Line_Id) || v_Nl ||
                   '订单号：' || r_Pln_Order_Head.Order_Number || v_Nl ||
                   '产品编码：' || v_Item_Code || v_Nl ||
                   '发货仓库ID：' || To_Char(p_Inventory_Id) || v_Nl ||
                   '是否库存评审：' || p_Inv_Affirm_Flag;
        Raise v_Base_Exception;
      End If;
    Else
      --本次可生成分配行数量
      v_Usable_Occupy_Qty := Least(v_Item_Occupy_Qty - v_Usable_So_Order_Qty, Abs(p_Trans_Share_Qty));
    End If;
    If v_Usable_Occupy_Qty > 0 Then
      --检查入库自动生成分配数量是否超过订单行可分配数量
      v_Count := 0;
      If Nvl(p_Trans_Sign_Flag, 1) = 1 Then
        Select Count(1)
          Into v_Count
          From t_Pln_Order_Line Pol
         Where Pol.Order_Line_Id = p_Pln_Order_Line_Id
           And Nvl(Pol.Can_Produce_Qty, 0) + Nvl(Pol.Inv_Affirm_Qty, 0) -
               Nvl(Pol.Cancel_Inv_Check_Qty, 0) -
               Nvl(Pol.Cancel_Inv_In_Qty, 0) -
               Nvl((Select Sum(Nvl(Oss.Share_Qty, 0))
                     From t_Pln_Order_Share_Shipment Oss
                    Where Oss.Origin_Line_Id = Pol.Order_Line_Id),
                   0) < v_Usable_Occupy_Qty;
        If v_Count > 0 Then
          v_Value := '当前生成分配行的入库数量，大于订单行剩余可分配数量！订单行ID：' ||
                     p_Pln_Order_Line_Id || '，待分配数量：' ||
                     v_Usable_Occupy_Qty;
          Raise v_Base_Exception;
        End If;
      End If;
      --add by lizhen 2015-02-28 获取产品外包装体积
      Begin
        Select To_Number(Bi.Packingsize)
          Into v_Unit_Volume
          From t_Bd_Item Bi
         Where Bi.Item_Id = v_Item_Id
           And Bi.Entity_Id = p_Entity_Id;
      Exception
        When Others Then
          v_Unit_Volume := 0;
      End;
      --查找订单行是否已生成分配行，如存在则直接更新分配行的已分配数量，否行新生成分配行
      Update t_Pln_Order_Share_Shipment Oss
         Set Oss.Share_Qty        = Nvl(Oss.Share_Qty, 0) +
                                    v_Usable_Occupy_Qty * p_Trans_Sign_Flag,
             Oss.Close_Flag       = Decode(Sign(Nvl(Oss.Share_Qty, 0) +
                                                v_Usable_Occupy_Qty *
                                                p_Trans_Sign_Flag -
                                                Nvl(Oss.Carry_Qty, 0)),
                                           1,
                                           v_False,
                                           v_True),
             Oss.Unit_Volume      = v_Unit_Volume,
             Oss.Last_Update_Date = Sysdate,
             Oss.Version = Nvl(Oss.Version, 0) + 1
       Where Oss.Origin_Line_Id = p_Pln_Order_Line_Id
         And Oss.Item_Id = v_Item_Id
         And Oss.Inventory_From_Id = p_Inventory_Id
         And Oss.Entity_Id = p_Entity_Id
         And Nvl(Oss.Inv_Share_Flag, v_False) = p_Inv_Affirm_Flag
         AND (p_Trans_Sign_Flag = 1 OR (p_Trans_Sign_Flag = -1 AND nvl(oss.share_qty, 0) - nvl(oss.carry_qty, 0) >= v_Usable_Occupy_Qty))
         --add by lizhen 2015-01-23 减少分配数量时检查已分配未下达是否满足
         /*And (p_Trans_Sign_Flag = 1 Or
         (Nvl(Oss.Share_Qty, 0) - Nvl(Oss.Carry_Qty, 0) >= p_Trans_Share_Qty) And p_Trans_Sign_Flag = -1)*/
         --And oss.source_order_share_id Is Null --modi by lizhen 2015-01-23 调拨生成分配行允许破损调拨
         And Rownum = 1
         --add by lizhen 2015-03-30 检查分配行分配数量是否为负数
         Returning oss.order_share_id, Oss.Share_Qty Into v_Order_Share_Id, v_Check_Share_Qty;
      If Nvl(v_Check_Share_Qty, 0) < 0 Then
        v_Value := '更新发货计划行分配数据失败，出现分配数量负数！' || v_Nl ||
                     '订单行ID：' || To_Char(p_Pln_Order_Line_Id) || v_Nl ||
                     '发货仓库ID：' || To_Char(p_Inventory_Id) || v_Nl ||
                     '是否库存评审：' || p_Inv_Affirm_Flag || v_Nl ||
                     '本次取消分配数量：' || To_Char(v_Usable_Occupy_Qty);
          Raise v_Base_Exception;
      End If;
      If Sql%Notfound Then
        --更新订单行待分配数量
        If Nvl(p_Trans_Sign_Flag, 1) = 1 Then
          p_Create_Share_Shipment(p_Entity_Id       => p_Entity_Id, --主体ID
                                  p_Order_Line_Id   => p_Pln_Order_Line_Id, --订单行
                                  p_Inventory_Id    => p_Inventory_Id, --仓库ID
                                  p_Trans_Qty       => v_Usable_Occupy_Qty, --分配数量
                                  p_User_Code       => p_User_Code, --用户ID
                                  p_Result          => v_Value, --正
                                  p_Ord_Share_Id    => v_Order_Share_Id, --返回分配行ID
                                  p_Inv_Affirm_Flag => p_Inv_Affirm_Flag --是否库存评审
                                  );
          If v_Value <> v_Success Then
            Raise v_Base_Exception;
          End If;
        Elsif p_Trans_Sign_Flag = -1 Then
          v_Value := '未找到可更新的发货计划行，可能是已分配未下达数量小于本次取消数量！' || v_Nl ||
                     '订单行ID：' || To_Char(p_Pln_Order_Line_Id) || v_Nl ||
                     '发货仓库ID：' || To_Char(p_Inventory_Id) || v_Nl ||
                     '是否库存评审：' || p_Inv_Affirm_Flag || v_Nl ||
                     '本次取消分配数量：' || To_Char(v_Usable_Occupy_Qty);
          Raise v_Base_Exception;
        End If;
      Else
        --更新分配表待下达数量
        Update t_Pln_Order_Share_Shipment Oss
           Set Oss.Carrying_Qty = Decode(Sign(Nvl(Oss.Share_Qty, 0) -
                                              Nvl(Oss.Carry_Qty, 0)),
                                         -1,
                                         0,
                                         Nvl(Oss.Share_Qty, 0) -
                                         Nvl(Oss.Carry_Qty, 0))
         Where Oss.Origin_Line_Id = p_Pln_Order_Line_Id
           And Oss.Item_Id = v_Item_Id
           And Oss.Inventory_From_Id = p_Inventory_Id
           And Oss.Entity_Id = p_Entity_Id
           And Nvl(Oss.Inv_Share_Flag, v_False) = p_Inv_Affirm_Flag --
           --And oss.source_order_share_id Is Null
           And Oss.Order_Share_Id = v_Order_Share_Id
           And Rownum = 1
           --Returning oss.order_share_id Into v_Order_Share_Id
           ;

        Insert Into t_Pln_Order_Share_History
          (Order_Share_History_Id, --
           Entity_Id, --
           Order_Header_Id, --
           Order_Line_Id, --
           Order_Share_Id, --
           Item_Id, --
           Item_Code, --
           Item_Name, --
           Inventory_From_Id, --
           Option_Type, --
           Quantity, --
           Batch_Tran_Id, --自动分配批ID
           Base_Allot_Flag, --基地间调拨
           Sales_Order_Type_Id, --单据类型ID
           Discount_Type_Id, --折扣类型ID
           Created_By, --
           Creation_Date, --
           Last_Updated_By, --
           Last_Update_Date, --
           Remark --
           )
        Values
          (s_Pln_Order_Share_History.Nextval,
           p_Entity_Id,
           r_Pln_Order_Head.Order_Head_Id,
           p_Pln_Order_Line_Id,
           v_Order_Share_Id,
           v_Item_Id,
           v_Item_Code,
           v_Item_Name,
           p_Inventory_Id,
           Decode(p_Trans_Sign_Flag, -1, '取消分配', '自动分配'),
           v_Usable_Occupy_Qty * p_Trans_Sign_Flag,
           Null, --自动分配批ID
           Null, --基地间调拨
           Null, --单据类型ID
           Null, --折扣类型ID
           p_User_Code,
           Sysdate,
           p_User_Code,
           Sysdate,
           '自动更新分配行数量，分配数据处理！p_Auto_Create_Share');
      End If;
      --更新订单已分配数量
      Update t_Pln_Order_Line Pol
         Set Pol.Share_Qty        = Nvl(Pol.Share_Qty, 0) +
                                    Nvl(v_Usable_Occupy_Qty, 0) *
                                    p_Trans_Sign_Flag,
             Pol.Last_Update_Date = Sysdate,
             Pol.Begin_Share_Date = Nvl(Pol.Begin_Share_Date, Trunc(Sysdate)),
             Pol.End_Share_Date   = Trunc(Sysdate),
             Pol.Version = Nvl(Pol.Version, 0) + 1
       Where Pol.Order_Line_Id = p_Pln_Order_Line_Id;

      --更新明细表已分配数量
      Update t_Pln_Order_Detail Pod
         Set Pod.Share_Qty        = Nvl(Pod.Share_Qty, 0) +
                                    Nvl(v_Usable_Occupy_Qty, 0) *
                                    p_Trans_Sign_Flag  *
                                    --add by lizhen 2015-09-17 增加套散件已下达数量更新时，必须*散件基数
                                    Pkg_Pln_Pub.f_Get_Item_Assembly_Base(p_Ass_Item_Id => v_Item_Id,
                                                                         p_Sub_Item_Id => Pod.Item_Id),
             Pod.Last_Update_Date = Sysdate,
             Pod.Version          = Nvl(Pod.Version, 0) + 1
       Where Pod.Order_Line_Id = p_Pln_Order_Line_Id;
    End If;

    If p_Result <> v_Success Then
      Rollback;
    End If;
  Exception
    When v_Base_Exception Then
      Rollback;
      p_Result := v_Value;
    When Others Then
      Rollback;
      p_Result := v_Value || v_Nl || Sqlerrm;
  End;

  -----------------------------------------------------------------------------------------
  --Author: Nicro.Li
  --Purpose:生成订单库存发货计划
  -----------------------------------------------------------------------------------------
  Procedure p_Create_Share_Shipment(p_Entity_Id             In Number, --主体ID
                                    p_Order_Line_Id         In Number, --订单行
                                    p_Inventory_Id          In Number, --仓库ID
                                    p_Trans_Qty             In Number, --分配数量
                                    p_User_Code             In Varchar2, --用户ID
                                    p_Result                Out Varchar2,
                                    p_Ord_Share_Id          Out Number,
                                    p_Inv_Affirm_Flag       In Varchar2 Default v_False, --是否库存评审
                                    p_Source_Order_Share_Id In Number Default Null --来源分配行ID
                                    ) Is
    v_Value             Varchar2(2000);
    v_Order_Share_Id    Number;
    v_Pln_Wip_Ord_Match Varchar2(10);
    v_Order_Line_Id     Number;
    r_Order_Line        t_Pln_Order_Line%Rowtype;
    r_Order_Head        t_Pln_Order_Head%Rowtype;

    v_Inventory_Code Varchar2(40);
    v_Inventory_Desc Varchar2(240);

    v_Inventory_To_Id   Number; --收货仓库ID
    v_Inventory_To_Code Varchar2(40); --收货仓库编码
    v_Inventory_To_Desc Varchar2(240); --收货仓库描述
    v_Price_List_Id     Number;
    v_Price_System_Id   Number;
    v_Discount_Rate     Number; --折扣
    v_Unit_Volume       Number; --单位体积
    v_Price             Number := 0; --返回价格
    v_Discount          Number := 0; --返回折扣率
    v_Month_Discount    Number := 0; --返回月返
    v_Cx_Flag           Varchar2(10); --返回是否促销机
    v_So_Bill_Type_id   Number;
    v_Is_Cusg_Flag          Varchar2(10);  --直发标志
    v_Consignee_Id          Number; --Consignee_Id, --收货单位ID
    v_Consignee_Code        Varchar2(100); --Consignee_Code, --收货单位编码
    v_Consignee_Name        Varchar2(240); --Consignee_Name, --收货单位名称
    v_Consignee_Addr        Varchar2(240); --Consignee_Address_Name, --收货单位地址
    v_Consignee_Contact_Id  Varchar2(240); --收货单位联系人ID
    v_Consignee_Contract    Varchar2(100); --收货单位联系人
    v_Consignee_Tel         Varchar2(100); --收货单位联系电话
    v_Inv_Base_Flag         Varchar2(10); --基地仓标志
    v_Inv_Prdc_Area_Id      Number;   --仓库所属产地
    v_Bill_Type_Code        Varchar2(100);

    --20150425 add by wildwind 需求：生成发货计划行更新产品描述信息
    v_Item_Name         VARCHAR2(240);
    r_Pln_Order_Type    t_Pln_Order_Type%Rowtype;
    v_item_plot_ratio t_pln_order_share_shipment.item_plot_ratio%type;
  Begin
    p_Result := v_Success;
    --获取工单与订单是否完全匹配参数
    v_Pln_Wip_Ord_Match := Pkg_Bd.f_Get_Parameter_Value('PLN_WIP_ORD_MATCH',
                                                        p_Entity_Id);
    --从分配行生成发货计划
    If p_Source_Order_Share_Id Is Not Null Then
      Select Oss.Origin_Line_Id
        Into v_Order_Line_Id
        From t_Pln_Order_Share_Shipment Oss
       Where Oss.Order_Share_Id = p_Source_Order_Share_Id
         And Oss.Entity_Id = p_Entity_Id;
    Else
      v_Order_Line_Id := p_Order_Line_Id;
    End If;
    Begin
      v_Value := '锁定订单行表数据';
      Select *
        Into r_Order_Line
        From t_Pln_Order_Line l
       Where l.Entity_Id = p_Entity_Id
         And l.Order_Line_Id = v_Order_Line_Id;

      Select *
        Into r_Order_Head
        From t_Pln_Order_Head h
       Where h.Entity_Id = p_Entity_Id
         And h.Order_Head_Id = r_Order_Line.Order_Head_Id;
    Exception
      When Others Then
        v_Value := v_Value || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;
    --add by lizhen 2015-12-03 查询订单单据类型数据
    Begin
      Select Ot.*
        Into r_Pln_Order_Type
        From t_Pln_Order_Type Ot
       Where Ot.Order_Type_Id = r_Order_Head.Order_Type_Id;
    Exception
      When Others Then
        v_Value := '获取单据类型数据失败，单据类型ID：' ||
                   To_Char(r_Order_Head.Order_Type_Id) || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;

    Begin
      If r_Order_Head.Sys_Source = 'IMS' Then
        v_Is_Cusg_Flag := v_True;
        Select Coh.Ims_Consignee_Id,
               Coh.Ims_Customer_Code,
               Coh.Ims_Customer_Name,
               Coh.Consignee_Addr,
               Coh.Consignee_Contract,
               Coh.Consignee_Tel
          Into v_Consignee_Id,
               v_Consignee_Code,
               v_Consignee_Name,
               v_Consignee_Addr,
               v_Consignee_Contract,
               v_Consignee_Tel
          From Intf_Cust_Order_Head Coh
         Where Coh.Pre_Field_01 = To_Char(r_Order_Head.Order_Head_Id)
           And Coh.Intf_Status = '04' --已成功引入CIMS订单
           And Coh.Entity_Id = p_Entity_Id;
      End If;
    Exception
      When Others Then
        v_Value := '获取IMS客户订单直发地址失败。' || v_Nl || '订单头ID：' ||
                   To_Char(r_Order_Head.Order_Head_Id) || v_Nl || '来源订单单号：' ||
                   r_Order_Head.Source_Order_Number || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;
    Begin
      v_Value := '取发货仓库信息！';
      If p_Result = v_Success Then
        Select Ii.Inventory_Code, Ii.Inventory_Name, ii.base_flag, ii.producing_area_id
          Into v_Inventory_Code, v_Inventory_Desc, v_Inv_Base_Flag, v_Inv_Prdc_Area_Id
          From t_Inv_Inventories Ii
         Where Ii.Entity_Id = p_Entity_Id
           And Ii.Inventory_Id = p_Inventory_Id
           And Trunc(Sysdate) Between Ii.Begin_Date And
               Nvl(Ii.End_Date, Sysdate + 1);
      End If;
    Exception
      When Others Then
        v_Value := '失败，' || v_Value || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;
    --仓库所属产地ID为运力任务控制功能增加，在前台页面按仓库所属产地汇总本次运力
    --传入物流模块，检查运力。
    If Nvl(v_Inv_Base_Flag, v_False) = v_True And v_Inv_Prdc_Area_Id Is Null Then
      v_Value := '仓库编码属性为基地仓，未配置仓库对应产地信息，生成发货计划失败。' ||
        v_Nl || '仓库编码：' || v_Inventory_Code;
      Raise v_Base_Exception;
    End If;

    Begin
      Select Uc.Code_Value
        Into v_Bill_Type_Code
        From Up_Codelist Uc, Up_Codelist_Entity Uce, v_So_Bill_Type Sbt
       Where Uc.Codetype = 'PLN_LG_DEFAULT_SO_ORDER_TYPE'
         And Uc.Id = Uce.Codelist_Id
         And Sbt.Entity_Id = Uce.Entity_Id
         And Sbt.Bill_Type_Code = Uc.Code_Value
         And Nvl(Sbt.Promotion_Flay, 'N') = 'N'
         And Uc.Enabled = 0
         And Uce.Entity_Id = p_Entity_Id;
    Exception
      When Others Then
        v_Value := '获取销售单单据类型的CODELIST设置失败，CODELIST编码：PLN_LG_DEFAULT_SO_ORDER_TYPE' || v_Nl ||
                   Sqlerrm;
        Raise v_Base_Exception;
    End;
    Begin
      Select Bt.Bill_Type_Id
        Into v_So_Bill_Type_Id
        From t_Inv_Bill_Types Bt
       Where Bt.Entity_Id = p_Entity_Id
         And v_Bill_Type_Code = Bt.Bill_Type_Code
         And Bt.Cancel_Flag = v_False
         And Rownum <= 1;
    Exception
      When Others Then
        v_So_Bill_Type_Id := Null;
        v_Value := '查找销售单据类型失败，销售单据类型编码：' || v_Bill_Type_Code;
        Raise v_Base_Exception;
    End;

    /*Begin
      Select t.Bill_Type_Id
        Into v_So_Bill_Type_Id
        From v_So_Bill_Type t
       Where t.Entity_Id = p_Entity_Id
         And Rownum <= 1;
    Exception
      When Others Then
        v_So_Bill_Type_Id := Null;
    End;*/

    Begin
      v_Value             := '取收货仓仓库资料！';
      v_Inventory_To_Id   := Null;
      v_Inventory_To_Code := Null;
      v_Inventory_To_Desc := Null;
    Exception
      When Others Then
        v_Inventory_To_Id   := Null;
        v_Inventory_To_Code := Null;
        v_Inventory_To_Desc := Null;
    End;

    Begin
      Select To_Number(Bi.Packingsize),bi.item_name, bi.item_plot_ratio
        Into v_Unit_Volume,v_Item_Name, v_item_plot_ratio
        From t_Bd_Item Bi
       Where Bi.Item_Id = r_Order_Line.Item_Id
         And Bi.Entity_Id = p_Entity_Id;
    Exception
      When Others Then
        v_Unit_Volume := 0;
        v_Item_Name:=nvl(v_Item_Name,r_Order_Line.Item_Desc); --add by wildwind
    End;

    -- 产品中心不需获取销售年度、价格体系、价格列表，商品价格，默认为0。

    v_Price_System_Id := 0;
    v_Price_List_Id   := 0;
    --modi by lizhen 2015-12-03 送审锁款的单据不再重新取单价，按订单行生成分配行单价
    If Nvl(r_Order_Head.Lock_Amount_Flag, r_Pln_Order_Type.Chk_Cusg_Amount_Flag) != 'S' Then
      Begin
        Pkg_Bd_Price.p_Get_Price(p_Acc_Id         => r_Order_Head.Account_Id, --账户ID
                                 p_Item_Code      => r_Order_Line.Item_Code, --产品ID
                                 p_Bill_Date      => To_Char(Trunc(Sysdate), 'YYYYMMDD'), --单据日期
                                 p_Price_List_Id  => Null, --价格列表ID
                                 p_Entity_Id      => p_Entity_Id, --业务主体ID
                                 p_Price          => v_Price, --返回价格
                                 p_Discount       => v_Discount, --返回折扣率
                                 p_Month_Discount => v_Month_Discount, --返回月返
                                 p_Cx_Flag        => v_Cx_Flag --返回是否促销机
                                 );
      Exception
        When Others Then
          v_Price := Null;
          v_Discount := Null;
          v_Month_Discount := Null;
          v_Cx_Flag := 'N';
      End;
    Else
      v_Price := r_Order_Line.Item_Price;
      v_Discount := r_Order_Line.Discount_Rate;
      v_Month_Discount := r_Order_Line.Ordered_Discount_Rate;
      v_Cx_Flag := 'N';
    End If;
    --modi by lizhen 生成发货计划时不检查价格是否为空
    /*If v_Price Is Null Then
      v_Value := '获取产品价格失败，产品编码：' || r_Order_Line.Item_Code ||
          '，账户ID：' || To_Char(r_Order_Head.Account_Id) || v_Nl || Sqlerrm;
      Raise v_Base_Exception;
    End If;*/

    Begin
      v_Value := '插入定制机库存分配明细表资料！';
      Select s_Pln_Order_Share_Shipment.Nextval
        Into v_Order_Share_Id
        From Dual;

      Insert Into t_Pln_Order_Share_Shipment
        (Entity_Id, --业务主体
         Order_Share_Id, --订单分配ID
         Sales_Center_Id, --营销中心ID
         Sales_Center_Code, --营销中心编码
         Sales_Center_Name, --营销中心名称
         Customer_Id, --客户ID
         Customer_Code, --客户编码
         Customer_Name, --客户名称
         Account_Id, --账户ID
         Account_Code, --账户编码
         Account_Name, --账户名称
         Item_Id, --产品ID
         Item_Code, --产品编码
         Item_Name, --产品名称
         Item_Uom, --产品单位
         Unit_Volume, --套件单位体积
         Producing_Area_Id, --产地ID
         Price_List_Id, --价格列表ID
         Price_System_Id, --价格体系ID
         Discount_Type_Id, --折扣类型ID
         List_Price, --列表价格
         Discount_Rate, --折扣率
         Share_Qty, --已分配数量
         Carrying_Qty, --待下达数量
         Sales_Order_Type_Id, --单据类型ID
         Inv_Share_Flag, --库存评审分配标志
         Origin_Type, --来源类型
         Origin_Head_Id, --来源头ID（订单头ID）
         Origin_Head_Code, --来源头编码（订单编码）
         Origin_Line_Id, --来源行ID（订单行ID）
         Source_Order_Share_Id, --来源组织ID（调拨单生成后回写该字段）
         Inventory_From_Id, --发货仓库ID
         Inventory_Code_From, --发货仓库编码
         Inventory_Desc_From, --发货仓库名称
         Invoice_Contract_Id, --开票单位联系人ID
         Invoice_Contract, --开票单位联系人
         Invoice_Tel, --开票单位联系电话
         Incept_Address_Id, --收货地点ID
         Consignee_Id, --收货单位ID
         Consignee_Code, --收货单位编码
         Consignee_Name, --收货单位名称
         Consignee_Address_Name, --收货单位地址
         Consignee_Extend_Addr, --收货扩展地址
         Consignee_Address_Code, --收货单位地址编码
         Consignee_Contact_Id, --收货单位联系人ID
         Consignee_Contract, --收货单位联系人
         Consignee_Tel, --收货单位联系电话
         Ship_Mode, --发运方式
         Is_Pick_Flag, --是否自提
         Is_Cusg_Flag, --是否直发标志
         Close_Flag, --单据关闭标志
         Carry_Error_Msg, --下达运力任务错误信息
         Re_Cal_Mark, --订单红冲重算标志
         Created_By, --创建人
         Creation_Date, --创建日期
         Last_Updated_By, --最后更新人
         Last_Update_Date, --最后更新时间
         Remark, --备注
         inv_affirm_qty, --库存评审数量
         check_qty, --评审数量
         cancel_inv_check_qty, --库存评审取消数量
         cancel_inv_in_qty,  --入库及调整取消数量
         Inventory_Prdc_Area_id,  --仓库所属产地ID
         Ordered_Discount_Rate,  --月返  --add by lizhen 2015-10-12
         Lock_Amount_Flag   --款项锁定标志  --ADD BY LIZHEN 2015-12-03
         ,item_plot_ratio
         )
        Select p_Entity_Id, --ENTITY_ID, --业务主体
               v_Order_Share_Id, --订单分配ID
               r_Order_Head.Sales_Center_Id, --营销中心ID
               r_Order_Head.Sales_Center_Code, --营销中心编码
               r_Order_Head.Sales_Center_Name, --营销中心名称
               r_Order_Head.Customer_Id, --客户ID
               r_Order_Head.Customer_Code, --客户编码
               r_Order_Head.Customer_Name, --客户名称
               r_Order_Head.Account_Id, --账户ID
               r_Order_Head.Account_Code, --账户编码
               r_Order_Head.Account_Name, --账户名称
               r_Order_Line.Item_Id, --产品ID
               r_Order_Line.Item_Code, --产品编码
               v_Item_Name, --产品名称 modify by wildwind 20150425
               r_Order_Line.Item_Uom, --产品单位
               v_Unit_Volume, --套件单位体积(外包装体积，不含配体)
               r_Order_Line.Producing_Area_Id, --产地ID
               r_Order_Line.Price_List_Id, --价格列表ID
               r_Order_Line.Price_System_Id, --价格体系ID
               r_Order_Line.Discount_Type_Id, --折扣类型ID
               v_Price, --列表价格
               v_Discount, --折扣率
               p_Trans_Qty, --已分配数量
               p_Trans_Qty, --Carrying_Qty, --待下达数量
               v_So_Bill_Type_Id, --sales_order_type_id销售单据类型ID
               p_Inv_Affirm_Flag, --库存评审分配标志
               r_Order_Head.Order_Type_Name, --来源类型
               r_Order_Head.Order_Head_Id, --来源头ID（订单头ID）
               r_Order_Head.Order_Number, --来源头编码（订单编码）
               r_Order_Line.Order_Line_Id, --来源行ID（订单行ID）
               p_Source_Order_Share_Id, --Source_Order_Share_Id, --来源组织ID（调拨单生成后回写该字段）
               p_Inventory_Id, -- Inventory_From_Id, --发货仓库ID
               v_Inventory_Code, --Inventory_Code_From, --发货仓库编码
               v_Inventory_Desc, --Inventory_Desc_From, --发货仓库名称
               r_Order_Head.Invoice_Contract_Id, --开票单位联系人ID
               r_Order_Head.Invoice_Contract, --开票单位联系人
               r_Order_Head.Invoice_Tel, --开票单位联系电话
               r_Order_Head.Consignment_Addr_Id, --Incept_Address_Id, --收货地点ID
               Decode(v_Is_Cusg_Flag,
                      v_True,
                      v_Consignee_Id,
                      r_Order_Head.Consignee_Id), --Consignee_Id, --收货单位ID
               Decode(v_Is_Cusg_Flag,
                      v_True,
                      v_Consignee_Code,
                      r_Order_Head.Customer_Code), --Consignee_Code, --收货单位编码
               Decode(v_Is_Cusg_Flag,
                      v_True,
                      v_Consignee_Name,
                      r_Order_Head.Customer_Name), --Consignee_Name, --收货单位名称
               Decode(v_Is_Cusg_Flag,
                      v_True,
                      v_Consignee_Addr,
                      r_Order_Head.Consignee_Addr), --Consignee_Address_Name, --收货单位地址
               Null, --Consignee_Extend_Addr, --收货扩展地址
               r_Order_Head.Consignee_Addr_Code, --收货单位地址编码
               Decode(v_Is_Cusg_Flag,
                      v_True,
                      0,
                      r_Order_Head.Consignee_Contact_Id), --收货单位联系人ID
               Decode(v_Is_Cusg_Flag,
                      v_True,
                      v_Consignee_Contract,
                      r_Order_Head.Consignee_Contract), --收货单位联系人
               Decode(v_Is_Cusg_Flag,
                      v_True,
                      v_Consignee_Tel,
                      r_Order_Head.Consignee_Tel), --收货单位联系电话
               '01', --Ship_Mode, --发运方式
               Null, --Is_Pick_Flag, --是否自提
               v_Is_Cusg_Flag, --Is_Cusg_Flag, --是否直发标志
               v_False, --Close_Flag, --单据关闭标志
               Null, --Carry_Error_Msg, --下达运力任务错误信息
               0, --Re_Cal_Mark, --订单红冲重算标志
               p_User_Code, --Created_By, --创建人
               Sysdate, --Creation_Date, --创建日期
               p_User_Code, -- Last_Updated_By, --最后更新人
               Sysdate, --Last_Update_Date, --最后更新时间
               substr(r_Order_Head.Remark||';'||r_Order_Line.Remark,1,80), --Remark --备注
               r_Order_Line.Inv_Affirm_Qty,-- inv_affirm_qty, --库存评审数量
               r_Order_Line.Check_Qty, --check_qty, --评审数量
               r_Order_Line.Cancel_Inv_Check_Qty, --cancel_inv_check_qty, --库存评审取消数量
               r_Order_Line.Cancel_Inv_In_Qty,  --cancel_inv_in_qty  --入库及调整取消数量
               v_Inv_Prdc_Area_Id, --Inventory_Prdc_Area_id  --仓库所属产地ID
               v_Month_Discount, --月返  --add by lizhen 2015-10-12
               Nvl(r_Order_Head.Lock_Amount_Flag, r_Pln_Order_Type.Chk_Cusg_Amount_Flag) --款项锁定标志--add by lizhen 2015-10-12
               ,v_item_plot_ratio
          From Dual;
    Exception
      When Others Then
        v_Value := v_Value || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;

    Begin
      v_Value := '插入单据操作历史记录';
      Insert Into t_Pln_Order_Share_History
        (Order_Share_History_Id, --
         Entity_Id, --
         Order_Header_Id, --
         Order_Line_Id, --
         Order_Share_Id, --
         Item_Id, --
         Item_Code, --
         Item_Name, --
         Inventory_From_Id, --
         Option_Type, --
         Quantity, --
         Batch_Tran_Id, --自动分配批ID
         Base_Allot_Flag, --基地间调拨
         Sales_Order_Type_Id, --单据类型ID
         Discount_Type_Id, --折扣类型ID
         Created_By, --
         Creation_Date, --
         Last_Updated_By, --
         Last_Update_Date, --
         Remark, --
         IS_CUSG_FLAG
         )
      Values
        (s_Pln_Order_Share_History.Nextval,
         p_Entity_Id,
         r_Order_Head.Order_Head_Id,
         v_Order_Line_Id,
         v_Order_Share_Id,
         r_Order_Line.Item_Id,
         r_Order_Line.Item_Code, --保留订单上的产品编码
         r_Order_Line.Item_Desc,
         p_Inventory_Id,
         '确认分配',
         p_Trans_Qty,
         Null, --自动分配批ID
         Null, --基地间调拨
         v_So_Bill_Type_id, --单据类型ID
         Null, --折扣类型ID
         p_User_Code,
         Sysdate,
         p_User_Code,
         Sysdate,
         '定制机订单分配，分配数据处理！',
         v_Is_Cusg_Flag);
    Exception
      When Others Then
        Raise v_Base_Exception;
    End;
    If p_Result <> v_Success Then
      Rollback;
    End If;
    p_Ord_Share_Id := v_Order_Share_Id;
  Exception
    When v_Base_Exception Then
      Rollback;
      p_Result := v_Value;
    When Others Then
      Rollback;
      p_Result := v_Value;
  End;

  ---------------------------------------------------------------------------------
  -- Author  : NICRO.LI
  -- Created : 2014-10-20 10:43:59
  -- Purpose : 订单管理 调拨单接收按来源发货计划ID生成新发货计划行
  ---------------------------------------------------------------------------------
  Procedure p_Receive_Create_Share(p_Order_Share_Id        In Number, --订单行ID
                                   p_Inventory_Id          In Number, --仓库ID(财务仓)
                                   p_Trans_Sign_Flag       In Number, --生成发货计划方向，1：生成发货计划  -1：取消发货计划
                                   p_Trans_Share_Qty       In Number, --分配数量（只传正数）
                                   p_Entity_Id             In Number, --主体ID
                                   p_Pln_Wip_Ord_Match     In Varchar, --工单与订单新匹配模式
                                   p_Trans_Order_Type_Name In Varchar2, --调拨单据类型名称
                                   p_Trans_Order_Head_Id   In Number,
                                   p_Trans_Order_Number    In Varchar2,
                                   p_Trans_Order_Line_Id   In Number,
                                   p_User_Code             In Varchar2,
                                   p_Result                Out Varchar2,
                                   p_Inv_Affirm_Flag       In Varchar2 Default v_False --库存评审标志
                                   ) Is
    v_Value               Varchar2(2000);
    v_Count               Number;
    v_Item_Id             Number;
    v_Item_Code           t_Bd_Item.Item_Code%Type;
    v_Item_Name           t_Bd_Item.Item_Name%Type;
    v_Usable_Share_Qty    Number;
    v_Sum_Share_Qty       Number;
    v_Item_Occupy_Qty     Number;
    v_Usable_Occupy_Qty   Number;
    v_Usable_So_Order_Qty Number;
    r_Share_Ship          t_Pln_Order_Share_Shipment%Rowtype;
    v_Order_Line_Id       Number;
    v_Order_Share_Id      Number;

  Begin
    p_Result := v_Success;
    Select Count(1)
      Into v_Count
      From t_Inv_Inventories Ii
     Where Ii.Inventory_Id = p_Inventory_Id
       And Ii.Entity_Id = p_Entity_Id;
    If Nvl(v_Count, 0) = 0 Then
      v_Value := '检查发货仓库ID失败，仓库ID：' || To_Char(p_Inventory_Id);
      Raise v_Base_Exception;
    End If;

    If p_Trans_Share_Qty Is Null Then
      v_Value := '检查参数失败，本次调拨数量为空。';
      Raise v_Base_Exception;
    End If;

    Begin
      Select *
        Into r_Share_Ship
        From t_Pln_Order_Share_Shipment Oss
       Where Oss.Entity_Id = p_Entity_Id
         And Oss.Order_Share_Id = p_Order_Share_Id;
    Exception
      When Others Then
        v_Value := '获取计划订单发货计划行失败，发货计划行ID：' || To_Char(p_Order_Share_Id) || v_Nl ||
                   Sqlerrm;
        Raise v_Base_Exception;
    End;

    Begin
      v_Value := '获取订单行套件商品信息，订单行ID：' ||
                 To_Char(r_Share_Ship.Origin_Line_Id);
      Select Pol.Item_Id, Pol.Item_Code, Pol.Item_Desc
        Into v_Item_Id, v_Item_Code, v_Item_Name
        From t_Pln_Order_Line Pol
       Where Pol.Order_Line_Id = r_Share_Ship.Origin_Line_Id;
    Exception
      When Others Then
        Raise v_Base_Exception;
    End;

    If p_Trans_Sign_Flag = 1 Then
      Pkg_Pln_Inv_Occupy.p_Affirm_Occupy_Stocks(p_Inventory_Id      => p_Inventory_Id,
                                                p_Item_Id           => r_Share_Ship.Item_Id,
                                                p_Occupy_Qty        => Abs(p_Trans_Share_Qty), --必须传正数
                                                p_Match_Pln_To_Wip  => p_Pln_Wip_Ord_Match,
                                                p_Action_Desc       => '调拨单接收仓库存占用',
                                                p_Entity_Id         => p_Entity_Id,
                                                p_Origin_Type       => r_Share_Ship.Origin_Type,
                                                p_Origin_Head_Id    => r_Share_Ship.Origin_Head_Id,
                                                p_Origin_Number     => r_Share_Ship.Origin_Head_Code,
                                                p_Origin_Line_Id    => r_Share_Ship.Origin_Line_Id,
                                                p_Source_Order_Type => p_Trans_Order_Type_Name,
                                                p_Source_Head_Id    => p_Trans_Order_Head_Id,
                                                p_Source_Number     => p_Trans_Order_Number,
                                                p_Source_Line_Id    => p_Trans_Order_Line_Id,
                                                p_User_Code         => p_User_Code,
                                                p_Result            => v_Count,
                                                p_Err_Msg           => v_Value);
    Elsif p_Trans_Sign_Flag = -1 Then
      Begin
        --调拨单红冲，发货仓库解锁
        Pkg_Pln_Inv_Occupy.p_Affirm_Unoccupy_Stocks(p_Inventory_Id      => p_Inventory_Id,
                                                    p_Item_Id           => r_Share_Ship.Item_Id,
                                                    p_Occupy_Qty        => Abs(p_Trans_Share_Qty),
                                                    p_Match_Pln_To_Wip  => p_Pln_Wip_Ord_Match,
                                                    p_Action_Desc       => '调拨单红冲接收仓库存占用',
                                                    p_Entity_Id         => p_Entity_Id,
                                                    p_Origin_Type       => r_Share_Ship.Origin_Type,
                                                    p_Origin_Head_Id    => r_Share_Ship.Origin_Head_Id,
                                                    p_Origin_Number     => r_Share_Ship.Origin_Head_Code,
                                                    p_Origin_Line_Id    => r_Share_Ship.Origin_Line_Id,
                                                    p_Source_Order_Type => p_Trans_Order_Type_Name,
                                                    p_Source_Head_Id    => p_Trans_Order_Head_Id,
                                                    p_Source_Number     => p_Trans_Order_Number,
                                                    p_Source_Line_Id    => p_Trans_Order_Line_Id,
                                                    p_User_Code         => p_User_Code,
                                                    p_Allow_No_Occupy   => 'N',
                                                    p_Result            => v_Count,
                                                    p_Err_Msg           => v_Value);
      End;
    End If;
    If v_Value <> v_Success Then
      Raise v_Base_Exception;
    End If;

    Begin
      v_Value := '计算商品已分配数量，商品ID:' || v_Item_Id;
      Select Nvl(Sum(Nvl(Oss.Share_Qty, 0) - Nvl(Oss.Carry_Qty, 0)), 0),
             Nvl(Sum(Nvl(Oss.Share_Qty, 0)), 0),
             Nvl(Sum(Nvl(Oss.Share_Qty, 0) - Nvl(Oss.So_Order_Qty, 0)), 0)
        Into v_Usable_Share_Qty, v_Sum_Share_Qty, v_Usable_So_Order_Qty
      --可用分配数量 ＝ 已分配数量 － 已下达数量
        From t_Pln_Order_Share_Shipment Oss
       Where Oss.Item_Id = v_Item_Id
         And Oss.Entity_Id = p_Entity_Id
         And Oss.Inventory_From_Id = p_Inventory_Id
         And Nvl(Oss.Close_Flag, v_False) <> v_Close
         And Oss.Origin_Type <> '客户订单'
         And Nvl(Oss.Share_Qty, 0) > Nvl(Oss.So_Order_Qty, 0)
            --增加工单与订单新匹配模式下取可用分配数量条件
         And (p_Pln_Wip_Ord_Match = v_False Or
             (p_Pln_Wip_Ord_Match = v_True And
             Oss.Origin_Line_Id = r_Share_Ship.Origin_Line_Id));
    Exception
      When No_Data_Found Then
        v_Usable_Share_Qty    := 0;
        v_Usable_So_Order_Qty := 0;
        v_Sum_Share_Qty       := 0;
      When Others Then
        Raise v_Base_Exception;
    End;

    If Nvl(v_Sum_Share_Qty, 0) = 0 And p_Trans_Sign_Flag = -1 Then
      --红冲中转单，未生成分配行，或者生成分配行的分配数量为0，则直接退出，不需更新分配行数据。
      v_Value := '订单行未生成订单发货计划，取消发货计划数量失败！';
      Raise v_Base_Exception;
    End If;

    v_Item_Occupy_Qty := Pkg_Pln_Inv_Occupy.f_Item_Ass_Occupy_Qty(p_Inventory_Id,
                                                                  v_Item_Id,
                                                                  p_Pln_Wip_Ord_Match,
                                                                  p_Entity_Id,
                                                                  r_Share_Ship.Origin_Line_Id);

    --If v_Item_Occupy_Qty - Nvl(v_Sum_Share_Qty, 0) < 0 And
    --MODI BY LIZHEN 2015-01-30 检查已分配未开单数据与占用数量是否一致
    If v_Item_Occupy_Qty - Nvl(v_Usable_So_Order_Qty, 0) < 0 And
       p_Trans_Sign_Flag = 1 Then
      --当前散件行的已锁定数量>套件的已锁定数量时，则不需取消定制机分配，否则取消分配
      --由于在匹配过程进行的中转单加锁与解锁，本过程获取的锁定数为加、解锁后的数据
      --在本过程比较时不需要加入中转单行数量进行对比
      v_Value := '订单库存占用不足，当前订单行（' || r_Share_Ship.Origin_Line_Id ||
                 '）库存占用数量（' || To_Char(v_Item_Occupy_Qty) || '）小于已分配未开单数量（' ||
                 To_Char(v_Sum_Share_Qty) || '） ';
      Raise v_Base_Exception;
    End If;

    If p_Trans_Sign_Flag = -1 Then
      If Abs(p_Trans_Share_Qty) > v_Usable_Share_Qty Then
        v_Value := '检查可红冲数量失败，订单发货计划行可下达数量：【' ||
                   To_Char(v_Usable_Share_Qty) || '】，本次取消发货计划数量：【' ||
                   To_Char(Abs(p_Trans_Share_Qty)) ||
                   '】，可下达数量小于取消发货计划数量，取消失败。';
        Raise v_Base_Exception;
      Else
        v_Usable_Occupy_Qty := Abs(p_Trans_Share_Qty);
      End If;
    Else
      --本次可生成分配行数量
      v_Usable_Occupy_Qty := v_Item_Occupy_Qty - v_Usable_So_Order_Qty;
    End If;
    If v_Usable_Occupy_Qty > 0 Then
      --检查入库自动生成分配数量是否超过订单行可分配数量
      v_Count := 0;
      /*If Nvl(p_Trans_Sign_Flag, 1) = 1 Then
        Select Count(1)
          Into v_Count
          From t_Pln_Order_Line Pol
         Where Pol.Order_Line_Id = r_share_ship.origin_line_id
           And Nvl(Pol.Can_Produce_Qty, 0) + Nvl(Pol.Inv_Affirm_Qty, 0) -
               Nvl(Pol.Cancel_Inv_Check_Qty, 0) -
               Nvl(Pol.Cancel_Inv_In_Qty, 0) -
               Nvl((Select Sum(Nvl(Oss.Share_Qty, 0))
                     From t_Pln_Order_Share_Shipment Oss
                    Where Oss.Origin_Line_Id = Pol.Order_Line_Id),
                   0) < v_Usable_Occupy_Qty;
        If v_Count > 0 Then
          v_Value := '当前生成分配行的入库数量，大于订单行剩余可分配数量！订单行ID：' ||
                     p_Pln_Order_Line_Id || '，待分配数量：' ||
                     v_Usable_Occupy_Qty;
          Raise v_Base_Exception;
        End If;
      End If;*/
      --查找订单行是否已生成分配行，如存在则直接更新分配行的已分配数量，否行新生成分配行
      Update t_Pln_Order_Share_Shipment Oss
         Set Oss.Share_Qty        = Nvl(Oss.Share_Qty, 0) +
                                    v_Usable_Occupy_Qty * p_Trans_Sign_Flag,
             Oss.Close_Flag       = Decode(Sign(Nvl(Oss.Share_Qty, 0) +
                                                v_Usable_Occupy_Qty *
                                                p_Trans_Sign_Flag -
                                                Nvl(Oss.Carry_Qty, 0)),
                                           1,
                                           v_False,
                                           v_True),
             Oss.Last_Update_Date = Sysdate,
             Oss.Version = Nvl(Oss.Version, 0) + 1
       Where Oss.Origin_Line_Id = r_Share_Ship.Origin_Line_Id
         And Oss.Item_Id = v_Item_Id
         And Oss.Inventory_From_Id = p_Inventory_Id
         And Oss.Entity_Id = p_Entity_Id
         And Nvl(Oss.Inv_Share_Flag, v_False) = p_Inv_Affirm_Flag
         And Oss.Source_Order_Share_Id = p_Order_Share_Id
         And Rownum = 1
      Returning Oss.Order_Share_Id Into v_Order_Share_Id;
      If Sql%Notfound Then
        --更新订单行待分配数量
        If Nvl(p_Trans_Sign_Flag, 1) = 1 Then
          p_Create_Share_Shipment(p_Entity_Id             => p_Entity_Id, --主体ID
                                  p_Order_Line_Id         => r_Share_Ship.Origin_Line_Id, --订单行
                                  p_Inventory_Id          => p_Inventory_Id, --仓库ID
                                  p_Trans_Qty             => v_Usable_Occupy_Qty, --分配数量
                                  p_User_Code             => p_User_Code, --用户ID
                                  p_Result                => v_Value, --正
                                  p_Ord_Share_Id          => v_Order_Share_Id, --返回分配行ID
                                  p_Inv_Affirm_Flag       => p_Inv_Affirm_Flag, --是否库存评审
                                  p_Source_Order_Share_Id => p_Order_Share_Id --来源发货计划行ID
                                  );
          If v_Value <> v_Success Then
            Raise v_Base_Exception;
          End If;
        End If;
      Else
        Insert Into t_Pln_Order_Share_History
          (Order_Share_History_Id, --
           Entity_Id, --
           Order_Header_Id, --
           Order_Line_Id, --
           Order_Share_Id, --
           Item_Id, --
           Item_Code, --
           Item_Name, --
           Inventory_From_Id, --
           Option_Type, --
           Quantity, --
           Batch_Tran_Id, --自动分配批ID
           Base_Allot_Flag, --基地间调拨
           Sales_Order_Type_Id, --单据类型ID
           Discount_Type_Id, --折扣类型ID
           Created_By, --
           Creation_Date, --
           Last_Updated_By, --
           Last_Update_Date, --
           Remark --
           )
        Values
          (s_Pln_Order_Share_History.Nextval,
           p_Entity_Id,
           r_Share_Ship.Origin_Head_Id,
           r_Share_Ship.Origin_Line_Id,
           v_Order_Share_Id,
           v_Item_Id,
           v_Item_Code,
           v_Item_Name,
           p_Inventory_Id,
           Decode(p_Trans_Sign_Flag, -1, '取消分配', '自动分配'),
           v_Usable_Occupy_Qty * p_Trans_Sign_Flag,
           Null, --自动分配批ID
           Null, --基地间调拨
           Null, --单据类型ID
           Null, --折扣类型ID
           p_User_Code,
           Sysdate,
           p_User_Code,
           Sysdate,
           '订单发货计划调拨，分配数据处理！');
      End If;
      --更新分配表待下达数量
      Update t_Pln_Order_Share_Shipment Oss
         Set Oss.Carrying_Qty = Decode(Sign(Nvl(Oss.Share_Qty, 0) -
                                            Nvl(Oss.Carry_Qty, 0)),
                                       -1,
                                       0,
                                       Nvl(Oss.Share_Qty, 0) -
                                       Nvl(Oss.Carry_Qty, 0))
       Where Oss.Origin_Line_Id = r_Share_Ship.Origin_Line_Id
         And Oss.Item_Id = v_Item_Id
         And Oss.Inventory_From_Id = p_Inventory_Id
         And Oss.Entity_Id = p_Entity_Id
         And Nvl(Oss.Inv_Share_Flag, v_False) = p_Inv_Affirm_Flag --
         And Oss.Source_Order_Share_Id = p_Order_Share_Id
         And Rownum = 1
      Returning Oss.Order_Share_Id Into v_Order_Share_Id;

      Update t_Pln_Order_Line Pol
         Set Pol.Carry_Qty        = Nvl(Pol.Carry_Qty, 0) +
                                    -1 * Nvl(v_Usable_Occupy_Qty, 0) *
                                    p_Trans_Sign_Flag,
             Pol.So_Order_Qty     = Nvl(Pol.So_Order_Qty, 0) +
                                    -1 * Nvl(v_Usable_Occupy_Qty, 0) *
                                    p_Trans_Sign_Flag,
             Pol.Last_Update_Date = Sysdate,
             Pol.Version = Nvl(Pol.Version, 0) + 1
       Where Pol.Order_Line_Id = r_Share_Ship.Origin_Line_Id;

      --更新明细表已分配数量
      Update t_Pln_Order_Detail Pod
         Set Pod.Carry_Qty        = Nvl(Pod.Carry_Qty, 0) +
                                    -1 * Nvl(v_Usable_Occupy_Qty, 0) *
                                    p_Trans_Sign_Flag,
             Pod.So_Order_Qty     = Nvl(Pod.So_Order_Qty, 0) +
                                    -1 * Nvl(v_Usable_Occupy_Qty, 0) *
                                    p_Trans_Sign_Flag,
             Pod.Last_Update_Date = Sysdate,
             Pod.Version = Nvl(Pod.Version, 0) + 1
       Where Pod.Order_Line_Id = r_Share_Ship.Origin_Line_Id;
      --更新来源分配行单据的数据信息，把新生成数据量减掉
      Update t_Pln_Order_Share_Shipment Oss
         Set Oss.Share_Qty        = Nvl(Oss.Share_Qty, 0) +
                                    -1 * Nvl(v_Usable_Occupy_Qty, 0) *
                                    p_Trans_Sign_Flag,
             Oss.Carry_Qty        = Nvl(Oss.Carry_Qty, 0) +
                                    -1 * Nvl(v_Usable_Occupy_Qty, 0) *
                                    p_Trans_Sign_Flag,
             Oss.So_Order_Qty     = Nvl(Oss.So_Order_Qty, 0) +
                                    -1 * Nvl(v_Usable_Occupy_Qty, 0) *
                                    p_Trans_Sign_Flag,
             Oss.Carrying_Qty     = Nvl(Oss.Share_Qty, 0) +
                                    -1 * Nvl(v_Usable_Occupy_Qty, 0) *
                                    p_Trans_Sign_Flag -
                                    (Nvl(Oss.Carry_Qty, 0) +
                                     -1 * Nvl(v_Usable_Occupy_Qty, 0) *
                                     p_Trans_Sign_Flag),
             Oss.Last_Update_Date = Sysdate,
             Oss.Last_Updated_By  = p_User_Code,
             Oss.Version = Nvl(Oss.Version, 0) + 1
       Where Oss.Order_Share_Id = p_Order_Share_Id;
    End If;

    If p_Result <> v_Success Then
      Rollback;
    End If;
  Exception
    When v_Base_Exception Then
      Rollback;
      p_Result := v_Value;
    When Others Then
      Rollback;
      p_Result := v_Value || v_Nl || Sqlerrm;
  End;

  ---------------------------------------------------------------------------------
  -- Author  : NICRO.LI
  -- Created : 2014-10-20 10:43:59
  -- Purpose : 订单管理 调拨单接收按来源发货计划ID生成新发货计划行
  ---------------------------------------------------------------------------------
  Procedure p_Transfer_To_Shipment(p_Transfer_Head_Id In Number, --调拨单头ID
                                   p_Operation_Type   In Varchar2, --操作类型：AUDITING:审核、RECEIVING:接收
                                   p_Entity_Id        In Number, --主体ID
                                   p_User_Code        In Varchar2, --用户编码
                                   p_Result           Out Varchar2) Is
    Cursor c_Trsf_Head Is
      Select *
        From t_Inv_Trsf_Order Ito
       Where Ito.Entity_Id = p_Entity_Id
         And Ito.Trsf_Order_Id = p_Transfer_Head_Id
         For Update Nowait;
    r_Trsf_Head c_Trsf_Head%Rowtype;

    Cursor c_Trsf_Line Is
      Select *
        From t_Inv_Trsf_Order_Line Tol
       Where Tol.Trsf_Order_Id = p_Transfer_Head_Id
         And Tol.Entity_Id = p_Entity_Id;
    r_Trsf_Line c_Trsf_Line%Rowtype;

    v_Value                     Varchar2(2000);
    v_Count                     Number;
    v_Bill_Cancel_Flag          Varchar2(3); --是否红冲单
    v_Bill_Special_Occupy_Flag  Varchar2(3); --特殊库存占用
    v_Bill_Type_Name            t_Inv_Bill_Types.Bill_Type_Name%Type;
    v_Pln_Wip_Ord_Match         Varchar2(3);
    r_Share_Ship                t_Pln_Order_Share_Shipment%Rowtype;
    v_Is_Lock_Inv_Flag          Varchar2(3);
    v_Origin_Type_Name          Varchar2(100);
    v_Origin_Order_Number       Varchar2(100);
    v_Origin_Order_Head_Id      Number;
    v_Origin_Order_Line_Id      Number;
    v_Transaction_Flag          Varchar2(100);
    v_Bill_Perild_Head_Id       Number;
    v_Ass_Receiv_Qty            Number;
    v_Is_Center_Trsf            VARCHAR2(1) := 'N';
  Begin
    p_Result := v_Success;
    If p_Operation_Type Not In
       (v_Operation_Auditing, v_Operation_Receiving) Then
      v_Value := '检查参数失败，单据操作类型错误。操作类型编码：' || p_Operation_Type;
      Raise v_Base_Exception;
    End If;

    Begin
      --获取工单与订单是否完全匹配参数
      v_Pln_Wip_Ord_Match := Pkg_Bd.f_Get_Parameter_Value('PLN_WIP_ORD_MATCH',
                                                          p_Entity_Id);
    Exception
      When Others Then
        v_Value := '获取主体参数失败，主体参数编码：PLN_WIP_ORD_MATCH  ' || to_char(p_Entity_Id) ||  v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;
    Begin
      Open c_Trsf_Head;
    Exception
      When Others Then
        v_Value := '查询调拨单头表数据失败，头ID：' || p_Transfer_Head_Id || v_Nl ||
                   Sqlerrm || v_Nl || Sqlcode;
        Raise v_Base_Exception;
    End;
    Fetch c_Trsf_Head
      Into r_Trsf_Head;

    Begin
      Select Bt.Cancel_Flag,
             Bt.Bill_Type_Name,
             Nvl(Bt.Special_Occupy_Flag, v_False),
             Bt.Bill_Period_Head_Id
        Into v_Bill_Cancel_Flag,
             v_Bill_Type_Name,
             v_Bill_Special_Occupy_Flag,
             v_Bill_Perild_Head_Id
        From t_Inv_Bill_Types Bt
       Where Bt.Bill_Type_Id = r_Trsf_Head.Bill_Type_Id;
    Exception
      When Others Then
        v_Value := '获取单据类型属性失败，单据类型ID：' || r_Trsf_Head.Bill_Type_Id;
        Raise v_Base_Exception;
    End;

    --说明：调拨单红冲时，发货仓库、接收仓库信息保留与蓝单数据一致，不会互换
    If v_Bill_Cancel_Flag = 'Y' And r_Trsf_Head.Old_Order_id Is Null Then
      v_Value := '调拨单红冲类型错误，调拨单蓝单头ID为空。调拨单头ID：' || p_Transfer_Head_Id;
      Raise v_Base_Exception;
    End If;
    --状态调拨单据 只做一次事务，在做破损的占用释放时，不判断单据执行动作
    If v_Bill_Special_Occupy_Flag = v_true Then
      p_Order_Special_Occupy(p_Entity_Id     => p_Entity_Id,
                             p_Order_Head_Id => p_Transfer_Head_Id,
                             p_Bill_Type_Id  => r_Trsf_Head.Bill_Type_Id,
                             p_User_Code     => p_User_Code,
                             p_Result        => v_Value);
      If v_Value <> v_Success Then
        v_Value := '调拨单特殊占用失败，调拨单头ID：' || p_Transfer_Head_Id || v_Nl || v_Value;
        Raise v_Base_Exception;
      End If;
    Elsif r_Trsf_Head.Orig_Order_Type = '01'
      And v_Bill_Special_Occupy_Flag = v_False Then  --订单发货计划调拨
      Select Count(1)
        Into v_Count
        From t_Pln_Order_Head Oh, t_Pln_Order_Type Ot
       Where Oh.Order_Type_Id = Ot.Order_Type_Id
         And Oh.Order_Head_Id = r_Trsf_Head.Orig_Order_Id
         And Oh.Entity_Id = p_Entity_Id
         And r_Trsf_Head.Orig_Order_Type = '01'
         And Nvl(Ot.Is_Lock_Inv_Flag, v_False) = v_True
         and nvl(ot.lock_inv_from_trsf, v_True) = v_True; --20180419 hejy3 调拨接收锁定库存标志为Y才处理
      --非库存占用方式订单类型，不执行后面的代码
      If v_Count = 0 Then
        Return;
      End If;
      --打开调拨单行表
      Begin
        Open c_Trsf_Line;
      Exception
        When Others Then
          v_Value := '查询调拨单行表数据失败，调拨单头ID：' || To_Char(p_Transfer_Head_Id) || v_Nl ||
                     Sqlerrm || v_Nl || Sqlcode;
          Raise v_Base_Exception;
      End;
      Loop
        Fetch c_Trsf_Line
          Into r_Trsf_Line;
        Exit When c_Trsf_Line%Notfound;
        
        --20160317 何加源 中心备货提货订单接收时不需再生成分配行
        v_Is_Center_Trsf := 'N';
        BEGIN
          SELECT COUNT(1) INTO v_Count
            FROM T_PLN_LG_ORDER_HEAD H, UP_CODELIST C, UP_CODELIST_ENTITY E
           WHERE C.ID = E.CODELIST_ID
             AND E.ENTITY_ID = p_Entity_Id
             AND E.CODE_VALUE = TO_CHAR(H.ORDER_TYPE_ID)
             AND E.ENABLED = '0'
             AND C.CODETYPE = 'PLG_LGORDER_CENTER_TRANSFER'
             AND H.ORDER_HEAD_ID = r_Trsf_Line.Lg_Order_Head_Id;
        END;
        
        IF v_Count > 0 THEN
          v_Is_Center_Trsf := 'Y';
        END IF;
        
        Begin
          Select *
            Into r_Share_Ship
            From t_Pln_Order_Share_Shipment Oss
           Where Oss.Entity_Id = p_Entity_Id
             And Oss.Item_Id = r_Trsf_Line.Item_Id
             And Oss.Inventory_From_Id = r_Trsf_Head.Ship_Inv_Id
             And Oss.Order_Share_Id = r_Trsf_Line.Origin_Ship_Plan_Id;
        Exception
          When Others Then
            v_Value := '获取订单发货计划行失败，发货计划行ID：' ||
                       r_Trsf_Line.Origin_Ship_Plan_Id;
            Raise v_Base_Exception;
        End;

          --调拨单审核
          If p_Operation_Type = v_Operation_Auditing Then
          If v_Bill_Cancel_Flag = v_False Then
            --审核时发货仓库存占用释放
            Pkg_Pln_Inv_Occupy.p_Soorder_Unoccupy_Stocks(p_Inventory_Id      => r_Trsf_Head.Ship_Inv_Id,
                                                         p_Item_Id           => r_Trsf_Line.Item_Id,
                                                         p_Occupy_Qty        => Abs(r_Trsf_Line.Billed_Qty),
                                                         p_Match_Pln_To_Wip  => v_Pln_Wip_Ord_Match,
                                                         p_Action_Desc       => '调拨单发货仓库存占用释放',
                                                         p_Entity_Id         => p_Entity_Id,
                                                         p_Origin_Type       => r_Share_Ship.Origin_Type,
                                                         p_Origin_Head_Id    => r_Share_Ship.Origin_Head_Id,
                                                         p_Origin_Number     => r_Share_Ship.Origin_Head_Code,
                                                         p_Origin_Line_Id    => r_Share_Ship.Origin_Line_Id,
                                                         p_Source_Order_Type => v_Bill_Type_Name,
                                                         p_Source_Head_Id    => r_Trsf_Head.Trsf_Order_Id,
                                                         p_Source_Number     => r_Trsf_Head.Orig_Order_Num,
                                                         p_Source_Line_Id    => r_Trsf_Line.Trsf_Order_Line_Id,
                                                         p_User_Code         => p_User_Code,
                                                         p_Allow_No_Occupy   => 'N',
                                                         p_Result            => v_Count,
                                                         p_Err_Msg           => v_Value);
            If v_Value <> v_Success Then
              v_Value := '调拨单发货仓库存占用释放失败。' || v_Nl || v_Value;
              Raise v_Base_Exception;
            End If;

            --更新发货计划行的已开单数量
            Pkg_Pln_Pub.p_Upd_Pln_So_Order_Qty(p_Order_Share_Id  => r_Share_Ship.Order_Share_Id,
                                               p_So_Order_Line_Id => Null,
                                               p_Trans_Order_Qty => r_Trsf_Line.Billed_Qty,
                                               p_Trans_Sign_Flag => 1,
                                               p_Entity_Id       => p_Entity_Id,
                                               p_User_Code       => p_User_Code,
                                               p_Result          => v_Value);
            If v_Value <> v_Success Then
              v_Value := '调拨单审核，更新订单发货计划行已开单数量失败。发货计划行ID' ||
                         To_Char(r_Share_Ship.Order_Share_Id) || v_Nl ||
                         v_Value;
              Raise v_Base_Exception;
            End If;
          Else
            Null;
            --调拨单红冲审核
            --MODI BY LIZHEN 2015-01-18
            --调拨红冲单据为蓝单审核后生成，还未接收，所以红冲单审核对接收仓不必更新、释放数量
            --调拨蓝单接收后不允许红冲，如果仓库错误则在订单发货计划进行反调拨
            /*p_Receive_Create_Share(p_Order_Share_Id        => r_Share_Ship.Order_Share_Id, --订单行ID
                                   p_Inventory_Id          => r_Trsf_Head.Consignee_Inv_Id, --仓库ID(财务仓)
                                   p_Trans_Sign_Flag       => -1, --生成发货计划方向，1：生成发货计划  -1：取消发货计划
                                   p_Trans_Share_Qty       => r_Trsf_Line.Billed_Qty, --分配数量（只传正数）
                                   p_Entity_Id             => p_Entity_Id, --主体ID
                                   p_Pln_Wip_Ord_Match     => v_Pln_Wip_Ord_Match, --工单与订单新匹配模式
                                   p_Trans_Order_Type_Name => v_Bill_Type_Name, --调拨单据类型名称
                                   p_Trans_Order_Head_Id   => r_Trsf_Head.Trsf_Order_Id,
                                   p_Trans_Order_Number    => r_Trsf_Head.Trsf_Order_Num,
                                   p_Trans_Order_Line_Id   => r_Trsf_Line.Trsf_Order_Line_Id,
                                   p_User_Code             => p_User_Code,
                                   p_Result                => v_Value,
                                   p_Inv_Affirm_Flag       => r_Share_Ship.Inv_Share_Flag --库存评审标志
                                   );
            If v_Value <> v_Success Then
              v_Value := '调拨单红冲审核，更新发货计划行已配数量。来源发货计划行ID' ||
                         To_Char(r_Share_Ship.Order_Share_Id) || v_Nl ||
                         v_Value;
              Raise v_Base_Exception;
            End If;*/
          End If;
        Elsif p_Operation_Type = v_Operation_Receiving AND v_Is_Center_Trsf = 'N' Then
          If v_Bill_Cancel_Flag = v_False Then
            --add by lizhen 2015-01-22 正常调拨时取明细行数量进行配套
            Begin
              Select Max(LEAST(/*Max*/(Trunc((Nvl(Ord.Rcv_Qty, 0) +
                               Nvl(Ord.Damaged_Qty, 0)) /
                               Pkg_Pln_Pub.f_Get_Item_Assembly_Base(Tol.Item_Id,
                                                                    Ord.Item_Id))),
                           NVL(TOL.BILLED_QTY, 0)))
                 Into v_Ass_Receiv_Qty
                From t_Inv_Trsf_Order_Line        Tol,
                     t_Inv_Trsf_Order_Line_Detail Ord
               Where Tol.Trsf_Order_Line_Id = r_Trsf_Line.Trsf_Order_Line_Id
                 And tol.entity_id = p_Entity_Id
                 And Tol.Trsf_Order_Line_Id = Ord.Trsf_Order_Line_Id;
            Exception
              When Others Then
                v_Value := '根据调拨单据明细行配套接收数据失败。' || v_Nl ||
                         '调拨单行ID：' || To_Char(r_Trsf_Line.Trsf_Order_Line_Id);
                Raise v_Base_Exception;
            End;
            /*If v_Ass_Receiv_Qty = 0 Then
              v_Value := '根据调拨单据明细行配套接收数据失败。' || v_Nl ||
                         '数量：' || To_Char(v_Ass_Receiv_Qty);
              Raise v_Base_Exception;
            End If;*/
            --调拨单接收
            p_Receive_Create_Share(p_Order_Share_Id        => r_Share_Ship.Order_Share_Id, --订单行ID
                                   p_Inventory_Id          => r_Trsf_Head.Consignee_Inv_Id, --仓库ID(财务仓)
                                   p_Trans_Sign_Flag       => 1, --生成发货计划方向，1：生成发货计划  -1：取消发货计划
                                   --modi by lizhen 生成分配行的数量= 正常接收数量 + 破损调拨套数
                                   p_Trans_Share_Qty       => Abs(Nvl(v_Ass_Receiv_Qty, 0)), --分配数量（只传正数）
                                   p_Entity_Id             => p_Entity_Id, --主体ID
                                   p_Pln_Wip_Ord_Match     => v_Pln_Wip_Ord_Match, --工单与订单新匹配模式
                                   p_Trans_Order_Type_Name => v_Bill_Type_Name, --调拨单据类型名称
                                   p_Trans_Order_Head_Id   => r_Trsf_Head.Trsf_Order_Id,
                                   p_Trans_Order_Number    => r_Trsf_Head.Trsf_Order_Num,
                                   p_Trans_Order_Line_Id   => r_Trsf_Line.Trsf_Order_Line_Id,
                                   p_User_Code             => p_User_Code,
                                   p_Result                => v_Value,
                                   p_Inv_Affirm_Flag       => r_Share_Ship.Inv_Share_Flag --库存评审标志
                                   );
            If v_Value <> v_Success Then
              v_Value := '调拨单审核，生成发货计划行失败。来源发货计划行ID' ||
                         To_Char(r_Share_Ship.Order_Share_Id) || v_Nl ||
                         v_Value;
              Raise v_Base_Exception;
            End If;
          Else
            Null;
            --调拨单红冲接收, 红冲单据无破损。
            --MODI BY LIZHEN 2017-04-18
            --调拨单据红冲不做库存锁定处理
            /*Pkg_Pln_Inv_Occupy.p_Soorder_Occupy_Stocks(p_Inventory_Id      => r_Trsf_Head.Ship_Inv_Id,
                                                       p_Item_Id           => r_Trsf_Line.Item_Id,
                                                       p_Occupy_Qty        => Abs(r_Trsf_Line.Billed_Qty), --必须传正数
                                                       p_Match_Pln_To_Wip  => v_Pln_Wip_Ord_Match,
                                                       p_Action_Desc       => '调拨单红冲接收仓库存占用',
                                                       p_Entity_Id         => p_Entity_Id,
                                                       p_Origin_Type       => r_Share_Ship.Origin_Type,
                                                       p_Origin_Head_Id    => r_Share_Ship.Origin_Head_Id,
                                                       p_Origin_Number     => r_Share_Ship.Origin_Head_Code,
                                                       p_Origin_Line_Id    => r_Share_Ship.Origin_Line_Id,
                                                       p_Source_Order_Type => v_Bill_Type_Name,
                                                       p_Source_Head_Id    => r_Trsf_Head.Trsf_Order_Id,
                                                       p_Source_Number     => r_Trsf_Head.Trsf_Order_Num,
                                                       p_Source_Line_Id    => r_Trsf_Line.Trsf_Order_Line_Id,
                                                       p_User_Code         => p_User_Code,
                                                       p_Result            => v_Count,
                                                       p_Err_Msg           => v_Value);
            If v_Value <> v_Success Then
              v_Value := '调拨单红冲接收，接收仓库存占用失败。来源发货计划行ID' ||
                         To_Char(r_Share_Ship.Order_Share_Id) || v_Nl ||
                         v_Value;
              Raise v_Base_Exception;
            End If;
            If r_Share_Ship.Carry_Qty < r_Trsf_Line.Billed_Qty Then
              v_Value := '计划订单发货计划更新失败，取消下达数量（' ||
                         To_Char(r_Trsf_Line.Billed_Qty) || '）大于已下达数量（' ||
                         To_Char(r_Share_Ship.Carry_Qty) || '）';
              Raise v_Base_Exception;
            End If;
            If r_Share_Ship.So_Order_Qty < r_Trsf_Line.Billed_Qty Then
              v_Value := '计划订单发货计划更新失败，取消已开单数量（' ||
                         To_Char(r_Trsf_Line.Billed_Qty) || '）大于已开单数量（' ||
                         To_Char(r_Share_Ship.So_Order_Qty) || '）';
              Raise v_Base_Exception;
            End If;
            --更新源发货计划行的已下达数量、已开单数量，用于重新下达运力发货
            --更新发货计划行的已开单数量
            Pkg_Pln_Pub.p_Upd_Pln_So_Order_Qty(p_Order_Share_Id => r_Share_Ship.Order_Share_Id,
                                               p_So_Order_Line_Id => Null,
                                               p_Trans_Order_Qty => r_Trsf_Line.Billed_Qty,
                                               p_Trans_Sign_Flag => -1,
                                               p_Entity_Id => p_Entity_Id,
                                               p_User_Code => p_User_Code,
                                               p_Result => v_Value
                                               );
            If v_Value <> v_Success Then
              v_Value := '调拨单红冲接收，更新订单发货计划行已开单数量失败。发货计划行ID' ||
                         To_Char(r_Share_Ship.Order_Share_Id) || v_Nl ||
                         v_Value;
              Raise v_Base_Exception;
            End If;*/
          End If;
        End IF;
      End Loop;
      Close c_Trsf_Line;
    Elsif r_Trsf_Head.Orig_Order_Type IN ('02','03')
      And v_Bill_Special_Occupy_Flag = v_False Then
      --调拨申请
      -- ADD BY LIZHEN 2014-12-29  增加调拨申请单据的库存占用处理
      --打开调拨单行表
      Begin
        Open c_Trsf_Line;
      Exception
        When Others Then
          v_Value := '查询调拨单行表数据失败，调拨单头ID：' || To_Char(p_Transfer_Head_Id) || v_Nl ||
                     Sqlerrm || v_Nl || Sqlcode;
          Raise v_Base_Exception;
      End;
      Loop
        Fetch c_Trsf_Line
          Into r_Trsf_Line;
        Exit When c_Trsf_Line%Notfound;
        Begin
          Select Loh.Order_Type_Name,
                 Loh.Order_Head_Id,
                 Loh.Order_Number,
                 Lol.Order_Line_Id,
                 Pot.Is_Lock_Inv_Flag
            Into v_Origin_Type_Name,
                 v_Origin_Order_Head_Id,
                 v_Origin_Order_Number,
                 v_Origin_Order_Line_Id,
                 v_Is_Lock_Inv_Flag
            From t_Pln_Lg_Order_Head Loh,
                 t_Pln_Lg_Order_Line Lol,
                 t_Pln_Order_Type    Pot
           Where Loh.Order_Head_Id = Lol.Order_Head_Id
             And Loh.Order_Head_Id = r_Trsf_Head.Orig_Order_Id
             And Pot.Order_Type_Id = Loh.Order_Type_Id
             And Lol.Order_Line_Id = r_Trsf_Line.Order_Line_Id_Orig;
        Exception
          When Others Then
            v_Value := '检查调拨申请单失败。调拨申请单ID：' ||
                       To_Char(r_Trsf_Head.Orig_Order_Id) || v_Nl ||
                       Sqlerrm;
            Raise v_Base_Exception;
        End;
        If Nvl(v_Is_Lock_Inv_Flag, v_False) = v_False Then
          --不占用库存的直接返回，不往后处理
          Return;
        End If;
        If p_Operation_Type = v_Operation_Auditing Then
          If v_Bill_Cancel_Flag = v_False Then
            --审核时发货仓库存占用释放
            Pkg_Pln_Inv_Occupy.p_Soorder_Unoccupy_Stocks(p_Inventory_Id      => r_Trsf_Head.Ship_Inv_Id,
                                                         p_Item_Id           => r_Trsf_Line.Item_Id,
                                                         p_Occupy_Qty        => Abs(r_Trsf_Line.Billed_Qty),
                                                         p_Match_Pln_To_Wip  => 'A',
                                                         p_Action_Desc       => '调拨单发货仓库存占用释放',
                                                         p_Entity_Id         => p_Entity_Id,
                                                         p_Origin_Type       => v_Origin_Type_Name,
                                                         p_Origin_Head_Id    => v_Origin_Order_Head_Id,
                                                         p_Origin_Number     => v_Origin_Order_Number,
                                                         p_Origin_Line_Id    => v_Origin_Order_Line_Id,
                                                         p_Source_Order_Type => v_Bill_Type_Name,
                                                         p_Source_Head_Id    => r_Trsf_Head.Trsf_Order_Id,
                                                         p_Source_Number     => r_Trsf_Head.Orig_Order_Num,
                                                         p_Source_Line_Id    => r_Trsf_Line.Trsf_Order_Line_Id,
                                                         p_User_Code         => p_User_Code,
                                                         p_Allow_No_Occupy   => 'N',
                                                         p_Result            => v_Count,
                                                         p_Err_Msg           => v_Value);
          Else
            Null;
            /*Pkg_Pln_Inv_Occupy.p_Soorder_Occupy_Stocks(p_Inventory_Id      => r_Trsf_Head.Ship_Inv_Id,
                                                       p_Item_Id           => r_Trsf_Line.Item_Id,
                                                       p_Occupy_Qty        => Abs(r_Trsf_Line.Billed_Qty),
                                                       p_Match_Pln_To_Wip  => 'A',
                                                       p_Action_Desc       => '调拨单发货仓库存占用',
                                                       p_Entity_Id         => p_Entity_Id,
                                                       p_Origin_Type       => v_Origin_Type_Name,
                                                       p_Origin_Head_Id    => v_Origin_Order_Head_Id,
                                                       p_Origin_Number     => v_Origin_Order_Number,
                                                       p_Origin_Line_Id    => v_Origin_Order_Line_Id,
                                                       p_Source_Order_Type => v_Bill_Type_Name,
                                                       p_Source_Head_Id    => r_Trsf_Head.Trsf_Order_Id,
                                                       p_Source_Number     => r_Trsf_Head.Trsf_Order_Num,
                                                       p_Source_Line_Id    => r_Trsf_Line.Trsf_Order_Line_Id,
                                                       p_User_Code         => p_User_Code,
                                                       p_Result            => v_Count,
                                                       p_Err_Msg           => v_Value);*/
          End If;
          If v_Value <> v_Success Then
            v_Value := '调拨单发货仓库存占用失败。' || v_Nl || v_Value;
            Raise v_Base_Exception;
          End If;
        End If;
      End Loop;
    End If;
    Close c_Trsf_Head;
  Exception
    When v_Base_Exception Then
      Rollback;
      p_Result := v_Value;
    When Others Then
      Rollback;
      p_Result := v_Value || v_Nl || Sqlerrm;
  End;

  -----------------------------------------------------------------------------------------
  --Author: Nicro.Li
  --Purpose: 计划订单发货计划下达到物流运力计划
  -----------------------------------------------------------------------------------------
  Procedure p_Share_To_Lgshipplan(p_Entity_Id        In Number, --主体ID,
                                  p_Order_Share_Id   In Number, --明细行ID
                                  p_Order_Type       In Varchar2, --运力任务单据下达类型  1006:销售  1008：调拨
                                  p_User_Code        In Varchar2, --用户ID
                                  p_Lg_Plan_Batch_Id In Number, --物流批次ID
                                  p_Result           Out Varchar2,
                                  p_Msg              Out Varchar2
                                  ) Is
    v_Value Varchar2(2000);

    Cursor c_Share_Shipment Is
      Select *
        From t_Pln_Order_Share_Shipment Oss
       Where Oss.Order_Share_Id = p_Order_Share_Id
       For Update Nowait;
    r_Back_Share_Ship   t_Pln_Order_Share_Shipment%Rowtype;
    r_Share_Shipment    c_Share_Shipment%Rowtype;
    r_Order_Line        t_Pln_Order_Line%Rowtype;
    r_Order_Head        t_Pln_Order_Head%Rowtype;
    v_Pln_Wip_Ord_Match Varchar2(10);
    v_Multi_Entity      Varchar2(10);
    v_Count             Number;
    v_Ord_Occupy_Qty    Number;
    v_Noord_Occupy_Qty  Number;
    v_Nocarry_Qty       Number;
    v_Sp_Msg            Varchar2(2000);
    v_Sp_Reloccupy_Qty  Number;
    v_Sales_Main_Type   Varchar2(100);
    --20150425 add by wildwind 需求：下达更新产品描述信息
    v_Item_Name         VARCHAR2(240);
    v_Lg_Ship_Pln_Id    Number;
    V_Consignee_Location_Code   Varchar2(100);
    v_Ship_To_Location_Id       Number;
    v_Account_Amount            Number;
    v_Discount_Amount           Number;
    v_lgShip_Doc_id             Number;
    v_Inv_Recive_Ou_Id        Number;
    v_Inv_Send_Ou_Id          Number;
    v_Docking_System          Varchar2(100);
    v_Price             Number := 0; --返回价格
    v_Discount          Number := 0; --返回折扣率
    v_Month_Discount    Number := 0; --返回月返
    v_Cx_Flag           Varchar2(10); --返回是否促销机

    v_Sales_Center_Id       Number;
    v_Sales_Center_Code     Varchar2(100);
    v_Sales_Center_Name     Varchar2(240);
    v_Customer_Id           Number;
    v_Customer_Code         Varchar2(100);
    v_Customer_Name         Varchar2(240);
    v_So_Bill_Type_Id       Number;
    v_Bill_Type_Code        Varchar2(100);
    v_Lg_Order_Review_Flag  Varchar2(3) := 'N'; --提货订单评审
    r_Lg_Order_Head    t_Pln_Lg_Order_head%Rowtype;
    r_Lg_Order_Line    t_Pln_Lg_Order_Line%Rowtype;
    v_Lg_Ship_Review_Qty    Number;  --提货订单已评审未下达
    v_return_code           number;
    v_order_head_remark     Varchar2(240);
    v_Pln_Is_Merge_Lg_Order Varchar2(100);
    v_Default_Lock_Amount_Flag  Varchar2(20);
    v_Out_Line_Flag             t_Inv_Inventories.Out_Line_Flag%Type;
    v_customer_channel_type   varchar2(50);
    v_is_modify_address       t_pln_lg_order_head.is_modify_address%Type;

	v_New_Price             Number;    --add by xuhongjiu 2016-01-13 取计划行上的价格
    v_New_Discount_Rate     Number;    --add by xuhongjiu 2016-01-13 取计划行上的扣率
    v_New_Month_Discount_Rate        Number;  --add by xuhongjiu 2016-01-13 取计划行上的月返
    v_New_Account_Amount    Number; --结算金额
    v_New_Discount_Amount   Number; --折让金额

    v_Consignee_Add_4_Flag    Varchar2(10); --add by lizhen 2016-01-16
    v_direct_send_now_flag    varchar2(10); --add by xuhongjiu 2016-05-06  本次是否直发
    v_client_carry_flag VARCHAR2(10);
    v_Ims_Lg_Opt_Id NUMBER;
    V_BILL_TYPE_CODE1 VARCHAR2(100);
    v_address_check VARCHAR2(10) := 'Y';
    V_IS_INV_ADDRESS VARCHAR2(10);
    v_Trsf_Amount NUMBER;
    v_Trsf_Dis_Amount NUMBER;
    v_Trsf_Sales_Main_Type t_bd_item.sales_main_type%TYPE;
    V_OS_ATTRIB01 Varchar2(1000);
    V_OS_ATTRIB02 Varchar2(1000);
    v_Send_Inv_Stock_Type t_inv_inventories.stock_type%type; --20170621 hejy3 发货仓库存货类型
    v_Rev_Inv_Stock_Type t_inv_inventories.stock_type%type; --20170621 hejy3 收货仓库存货类型
    v_Price_Apply_Use_Discount t_bd_param_list.default_value%type := 'N'; --20170710 hejy3 价格批文开单使用折扣
    v_Need_Lock_Agent_Amount boolean := false;
    v_agent_order_lock_amount_flag t_pln_lg_order_head.lock_amount_flag%type;
    v_Origin_Head_Id number;
    v_Order_Type_Code varchar2(100);
    v_Order_Type_Id number;
    v_Source_Type varchar2(10);
    V_IS_CENTER_TRSF VARCHAR2(2) := 'N'; --20170107 hejy3 是否中心备货提货订单
    v_Source_Order_Number intf_lg_ship_plan.source_order_number%type; --来源单号
    V_TRANSPORT_LINE_ID T_LG_TRANSPORT_LINE_LMS.TRANSPORT_LINE_ID%TYPE; --线路ID
    V_TRANSPORT_LINE_CODE T_LG_TRANSPORT_LINE_LMS.Transport_Line_Code%type;--线路编码
    V_ASSEMBLE_LINE_ID T_LG_ASSEMBLE_LINE.ASSEMBLE_LINE_ID%TYPE;--集拼线路ID
    V_ASSEMBLE_LINE_CODE T_LG_ASSEMBLE_LINE.ASSEMBLE_LINE_CODE%TYPE;--集拼线路编码
    V_ASSEMBLE_LINE_NAME T_LG_ASSEMBLE_LINE.ASSEMBLE_LINE_NAME%TYPE;--集拼线路名称
    v_send_inv_district_id number; --发货仓库区域ID
    v_send_inv_district_code t_bd_district.district_code%type; --发货仓库区域编码
    v_send_inv_district_name t_bd_district.district_name%type; --发货仓库区域名称
    V_Consignee_Location_name t_bd_district.district_name%type;
    
    V_CRM_ADDRESS_ID T_CUSTOMER_ADDRESS.SIEBEL_ADDRESS_ID%TYPE;
    
    V_COLLAGE_ENTITY_ID NUMBER;
	v_c2m_flag          varchar2(100); --C2M标识
    v_Wip_Entity_Code   Varchar2(256); --工单号
  Begin
    p_Result := v_Success;
    v_Value  := v_Success;
    --获取工单与订单是否完全匹配参数
    v_Pln_Wip_Ord_Match := Pkg_Bd.f_Get_Parameter_Value('PLN_WIP_ORD_MATCH',
                                                        p_Entity_Id);
    -- PLN启用多主体采购
    /*v_Multi_Entity := Nvl(Pkg_Bd.f_Get_Parameter_Value('PLN_MULTI_ENTITY',
                                                       p_Entity_Id),
                          v_False);*/
    Begin
      --获取T+N订单结转模式  add by lizhen 2015-07-15
      v_Pln_Is_Merge_Lg_Order := Pkg_Bd.f_Get_Parameter_Value('PLN_IS_MERGE_LG_ORDER',
                                                              p_Entity_Id);
    Exception
      When Others Then
        v_Value := '获取主体参数失败，主体参数编码【PLN_IS_MERGE_LG_ORDER】！' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;
    
    --20170710 hejy3 获取价格批文开单使用折扣参数
    Begin
      v_Price_Apply_Use_Discount := Pkg_Bd.f_Get_Parameter_Value('PLN_PRICE_APPLY_USE_DISCOUNT',
                                                          p_Entity_Id);
    Exception
      When Others Then
        v_Price_Apply_Use_Discount := 'N';
    End;
    
    Begin
      Select *
        Into r_Back_Share_Ship
        From t_Pln_Order_Share_Shipment Oss
       Where Oss.Order_Share_Id = p_Order_Share_Id;
    Exception
      When Others Then
        v_Value := '打开订单发货计划表失败！' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;

    --add by lizhen 2016-01-16 快码设置是否不启用4级收货地点
    Begin
      Select Nvl(Uc.Code_Value, 'Y')
        Into v_Consignee_Add_4_Flag
        From Up_Codelist Uc
       Where Uc.Codetype = 'PLN_CONSIGNEE_ADD_4'
         And Uc.Enabled = 0;
    Exception
      When Others Then
        v_Consignee_Add_4_Flag := 'Y';
    End;

    --add by lizhen 2015-02-12 提货订单评审数据，先更新发
    Begin
      If r_Back_Share_Ship.Lg_Order_Head_Id Is Not Null And
         r_Back_Share_Ship.Lg_Order_Line_Id Is Not Null Then
        Begin
          Select *
            Into r_Lg_Order_Head
            From t_Pln_Lg_Order_Head Oh
           Where Oh.Order_Head_Id = r_Back_Share_Ship.Lg_Order_Head_Id;
         v_order_head_remark := r_Lg_Order_Head.Remark;
        Exception
          When Others Then
            v_Value := '打开提货订单单头失败!' || v_Nl || '单头ID：' ||
                       To_Char(r_Back_Share_Ship.Lg_Order_Head_Id) || v_Nl ||
                       Sqlerrm;
            Raise v_Base_Exception;
        End;
         
        IF (r_Lg_Order_Head.Origin_Order_Status = 'DELETE') THEN
            v_Value := '订单[' ||
                          r_Lg_Order_Head.Order_Number ||
                          ']，对应的外部采购单[' || r_Lg_Order_Head.Origin_Order_Number || ']已经被删除，不能再评审/发货等操作！';
            Raise v_Base_Exception;
        END IF;

        --add by xuhongjiu 2016-05-05
        IF r_Lg_Order_Head.Sys_Source in ('IMS', 'CIMS') THEN
          IF r_Lg_Order_Head.Is_Cancel_Direct_Send = 'Y' THEN
            v_direct_send_now_flag := v_False;
            v_client_carry_flag := v_False;
          ELSE
            v_direct_send_now_flag := r_Lg_Order_Head.Direct_Send_Flag;
            v_client_carry_flag := r_Lg_Order_Head.Client_Carry_Flag;
          END IF;
        ELSE
          Select Case
                 When (Nvl(r_Lg_Order_Head.Direct_Send_Flag, 'N') = 'Y' And
                     Nvl(r_Lg_Order_Head.Is_Cancel_Direct_Send, 'N') = 'N') Then
                  v_True
                 Else
                  v_False
                 End
           Into v_direct_send_now_flag
           From dual;
           v_client_carry_flag := r_Lg_Order_Head.Client_Carry_Flag;
         END IF;

        --add by xuhongjiu 是否校验收货地址使用
        Begin
          Select h.is_modify_address
            Into v_is_modify_address
            From t_Pln_Lg_Order_Head h
           Where h.Order_Head_Id = r_Back_Share_Ship.Lg_Order_Head_Id;
        Exception
          When Others Then
            v_Value := '查询提货订单头上的是否修改过地（IS_MODIFY_ADDRESS）字段失败，' || v_Nl || '提货单头ID：' ||
                       To_Char(r_Back_Share_Ship.Lg_Order_Head_Id) || v_Nl ||
                       Sqlerrm;
            Raise v_Base_Exception;
         End;
        Begin
          Select *
            Into r_Lg_Order_Line
            From t_Pln_Lg_Order_Line Ol
           Where Ol.Order_Line_Id = r_Back_Share_Ship.Lg_Order_Line_Id;
        Exception
          When Others Then
            v_Value := '打开提货订单行失败!' || v_Nl || '单ID：' ||
                       To_Char(r_Back_Share_Ship.Lg_Order_Line_Id) || v_Nl ||
                       Sqlerrm;
            Raise v_Base_Exception;
        End;
        v_Lg_Order_Review_Flag := v_True;
        Update t_Pln_Order_Share_Shipment Oss
           Set Oss.Customer_Id            = r_Lg_Order_Head.Customer_Id,
               Oss.Customer_Code          = r_Lg_Order_Head.Customer_Code,
               Oss.Customer_Name          = r_Lg_Order_Head.Customer_Name,
               Oss.Invoice_Contract_Id    = r_Lg_Order_Head.Invoice_Contact_Id,
               Oss.Invoice_Contract       = r_Lg_Order_Head.Invoice_Contract,
               Oss.Invoice_Tel            = r_Lg_Order_Head.Invoice_Tel,
               Oss.Account_Id             = r_Lg_Order_Head.Account_Id,
               Oss.Account_Code           = r_Lg_Order_Head.Account_Code,
               Oss.Account_Name           = r_Lg_Order_Head.Account_Name,
               Oss.Consignee_Id           = r_Lg_Order_Head.Consignee_Id,
               Oss.Consignee_Code         = r_Lg_Order_Head.Consignee_Code,
               Oss.Consignee_Name         = r_Lg_Order_Head.Consignee_Name,
               Oss.Consignee_Address_Name = r_Lg_Order_Head.Consignee_Addr_Name,
               Oss.Consignee_Extend_Addr  = r_Lg_Order_Head.Consignee_Extend_Addr,
               Oss.Incept_Address_Id      = r_Lg_Order_Head.Consignment_Add_Id,
               Oss.Consignee_Address_Code = r_Lg_Order_Head.Consignee_Addr_Code,
               Oss.Consignee_Contact_Id   = r_Lg_Order_Head.Consignee_Contact_Id,
               Oss.Consignee_Contract     = r_Lg_Order_Head.Consignee_Contract,
               Oss.Consignee_Tel          = r_Lg_Order_Head.Consignee_Tel,
               Oss.Is_Cusg_Flag           = v_direct_send_now_flag,   --modi by xuhongjiu 2016-05-05
               --Oss.Is_Pick_Flag           = r_Lg_Order_Head.Client_Carry_Flag,
               oss.is_pick_flag           = v_client_carry_flag, --自提标志
               Oss.Discount_Rate          = r_Lg_Order_Line.Discount_Rate,
               Oss.Ordered_Discount_Rate  = r_Lg_Order_Line.Ordered_Discount_Rate, --add by lizhen 2015-10-12
               Oss.Plan_Send_Date         = Trunc(Sysdate),
               Oss.Ship_Type              = r_Lg_Order_Head.Ship_Type,
               --add by ex_zhangcc 2016-1-25
               Oss.Sales_Order_Type_Id    =r_Lg_Order_Line.Sales_Order_Type_Id,
               --ADD BY ZCC 新增批文信息
               Oss.Project_Order_Type     =r_Lg_Order_Line.Project_Order_Type,
               Oss.Project_Order_Number   =r_Lg_Order_Line.Project_Order_Number,
               Oss.Apply_List_Price       =r_Lg_Order_Line.Apply_List_Price,
               Oss.Apply_Discount_Rate    =r_Lg_Order_Line.Apply_Discount_Rate,
               Oss.Project_Order_Line_Id  =r_Lg_Order_Line.Project_Order_Line_Id,
               Oss.Price_Apply_Id         =r_Lg_Order_Line.Price_Apply_Id,
               Oss.Is_Project_Flag        =r_Lg_Order_Head.Project_Order_Flag,
               Oss.Lock_Amount_Flag       = r_Lg_Order_Head.Lock_Amount_Flag,  --add by lizhen 2015-07-17
               Oss.Ship_Mode              = r_Lg_Order_Head.Ship_Mode --add by lizhen 2016-02-23
               ,Oss.Inventory_To_Id       = r_Lg_Order_Head.Inventory_To_Id
               ,oss.rcv_inv_code          = r_Lg_Order_Head.Rcv_Inv_Code
               ,oss.rcv_inv_name          = r_Lg_Order_Head.Rcv_Inv_Name
               ,Oss.Discount_Type         = r_Lg_Order_Line.Discount_Type -- add by lizhen 2017-04-17
               --20170619 hejy3 客户订单号和订单日期
							 ,Oss.Customer_Order_Number = r_Lg_Order_Head.Customer_Order_Number
               ,oss.customer_order_date = r_Lg_Order_Head.Customer_Order_Date
         Where Oss.Order_Share_Id = p_Order_Share_Id;

         Begin
           Select Bsc.Sales_Center_Id,
                  Bsc.Sales_Center_Code,
                  Bsc.Sales_Center_Name
             Into r_Lg_Order_Head.Sales_Center_Id,
                  r_Lg_Order_Head.Sales_Center_Code,
                  r_Lg_Order_Head.Sales_Center_Name
             From Cims.t_Customer_Org              Tco,
                  Cims.t_Customer_Acc_Org_Relation Acr,
                  Cims.v_Bd_Sales_Center           Bsc
            Where Tco.Customer_Id = r_Lg_Order_Head.Customer_Id
              And Tco.Customer_Org_Id = Acr.Customer_Org_Id
              And Acr.Account_Id = r_Lg_Order_Head.Account_Id
              And Bsc.Sales_Center_Id = Tco.Sales_Center_Id
              And Tco.Active_Flag = 'Active';
         Exception
           When Others Then
             v_Value := '根据客户、账户信息获取营销中心失败！' || v_Nl || '客户编码：' ||
                         r_Order_Head.Customer_Code || v_Nl || '账户ID：' ||
                         r_Order_Head.Account_Id || v_Nl || Sqlerrm;
             Raise v_Base_Exception;
         End;

        --add by lizhen 2015-07-15 TN模式的更新营销中心信息
        --If v_Pln_Is_Merge_Lg_Order In ('TN_SUM', 'TN_SINGLE') Then
        Update t_Pln_Order_Share_Shipment Oss
           Set Oss.Sales_Center_Id   = r_Lg_Order_Head.Sales_Center_Id,
               Oss.Sales_Center_Code = r_Lg_Order_Head.Sales_Center_Code,
               Oss.Sales_Center_Name = r_Lg_Order_Head.Sales_Center_Name
         Where Oss.Order_Share_Id = p_Order_Share_Id;
        --End If;
        Else
          v_direct_send_now_flag := r_Back_Share_Ship.Is_Cusg_Flag;
          v_client_carry_flag := r_Back_Share_Ship.Is_Pick_Flag;
      End If;
    End;
    Open c_Share_Shipment;
    Loop
      Fetch c_Share_Shipment
        Into r_Share_Shipment;
      Exit When c_Share_Shipment%Notfound Or p_Result <> v_Success;
      If v_Value = v_Success Then
        Begin
          Select *
            Into r_Order_Line
            From t_Pln_Order_Line Pol
           Where Pol.Order_Line_Id = r_Share_Shipment.Origin_Line_Id;
        Exception
          When Others Then
            v_Value := '取商品订单行信息出错！';
            Raise v_Base_Exception;
        End;
      End If;
      Begin
        Select Tii.Out_Line_Flag, tii.district_id
          Into v_Out_Line_Flag, v_send_inv_district_id
          From t_Inv_Inventories Tii
         Where Tii.Inventory_Id = r_Share_Shipment.Inventory_From_Id
           --add by lizhen 2017-06-23 增加客户OU库存组织检查
           And 'Y' = Pkg_Inv_Pub.f_Get_Custimer_Inv_Org(In_Entity_Id       => Tii.Entity_Id,
                                                        In_Customer_Id     => r_Share_Shipment.Customer_Id,
                                                        In_Organization_Id => Tii.Organization_Id);
      Exception
        When No_Data_Found Then
          v_Value := '获取仓库数据失败，请检查客户OU组织与仓库组织是否一致！' || v_Nl ||
            '仓库编码：' || r_Share_Shipment.Inventory_Code_From;
          Raise v_Base_Exception;
        When Others Then
          v_Value := '获取发货仓库下线直发标志失败！' || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
      End;
      Pkg_Pln_Pub.p_Check_Item_Rounding(p_Entity_Id => r_Share_Shipment.Entity_Id,
                                        p_Item_Id   => r_Share_Shipment.Item_Id,
                                        p_Check_Qty => r_Share_Shipment.Carrying_Qty,
                                        p_Result    => v_Value);
      If v_Value != v_Success Then
        v_Value := v_Value || v_Nl ||
          '订单单号：' || r_Share_Shipment.Origin_Head_Code;
        Raise v_Base_Exception;
      End If;
      If v_Value = v_Success Then
        Begin
          Select *
            Into r_Order_Head
            From t_Pln_Order_Head Poh
           Where Poh.Order_Head_Id = r_Share_Shipment.Origin_Head_Id;
        Exception
          When Others Then
            v_Value := '取商品订单头信息出错！';
            Raise v_Base_Exception;
        End;
      End If;
      --add by lizhen 2015-07-17
      Begin
        If v_Lg_Order_Review_Flag = v_False Then
          --非提货订单发货计划发货
          Select Ot.Chk_Cusg_Amount_Flag
            Into v_Default_Lock_Amount_Flag
            From t_Pln_Order_Type Ot
           Where Ot.Order_Type_Id = r_Order_Head.Order_Type_Id;
          --modi by lizhen 2016-01-20
          If r_Share_Shipment.Lock_Amount_Flag Is Null Then
            r_Share_Shipment.Lock_Amount_Flag := v_Default_Lock_Amount_Flag;
          End If;
        Else
          --提货订单发货计划发货
          Select Nvl(r_Lg_Order_Head.Lock_Amount_Flag,
                     (Select Ot.Chk_Cusg_Amount_Flag
                        From t_Pln_Order_Type Ot
                       Where Ot.Order_Type_Id = r_Lg_Order_Head.Order_Type_Id))
            Into v_Default_Lock_Amount_Flag
            From Dual;
          --modi by lizhen 2015-08-19
          r_Share_Shipment.Lock_Amount_Flag := v_Default_Lock_Amount_Flag;
        End If;
      Exception
        When Others Then
          v_Value := '获取订单单据类型的默认锁款标志失败！' || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
      End;
      --add by lizhen 增加根据 客户、账户ID取营销中心信息
      --保证传入运力任务计划的营销中心、客户、账户一致(主要为多主体采购）
      If v_Value = v_Success Then
        --modi by lizhen 2015-07-28 下线直发仓调拨时，无账户信息，取发货计划中心信息
        --modi by lizhen 2016-11-04 调拨下达时，不检查中心、客户、账户之间的关系
        If Nvl(v_Out_Line_Flag, 'N') != 'Y' And p_Order_Type != '1008' Then
          Begin
            Select Bsc.Sales_Center_Id,
                   Bsc.Sales_Center_Code,
                   Bsc.Sales_Center_Name
              Into v_Sales_Center_Id,
                   v_Sales_Center_Code,
                   v_Sales_Center_Name
              From Cims.t_Customer_Org              Tco,
                   Cims.t_Customer_Acc_Org_Relation Acr,
                   Cims.v_Bd_Sales_Center           Bsc
             Where Tco.Customer_Id = r_Share_Shipment.Customer_Id
               And Tco.Customer_Org_Id = Acr.Customer_Org_Id
               And Acr.Account_Id = r_Share_Shipment.Account_Id
               And Bsc.Sales_Center_Id = Tco.Sales_Center_Id;
          Exception
            When Others Then
              v_Value := '根据客户、账户信息获取营销中心失败！' || v_Nl || '客户ID：' ||
                         r_Share_Shipment.Customer_Code || v_Nl || '账户ID：' ||
                         r_Share_Shipment.Account_Id || v_Nl || Sqlerrm;
              Raise v_Base_Exception;
          End;
        Else
          Select r_Share_Shipment.Sales_Center_Id,
                 r_Share_Shipment.Sales_Center_Code,
                 r_Share_Shipment.Sales_Center_Name
            Into v_Sales_Center_Id,
                 v_Sales_Center_Code,
                 v_Sales_Center_Name
            From Dual;
        End If;
      End If;

      If v_Value = v_Success Then
        --modi by lizhen 2015-07-28 下线直发仓调拨时，无账户信息，客户信息为空
        If Nvl(v_Out_Line_Flag, 'N') != 'Y' Then
          Begin
            Select Tch.Customer_Id, Tch.Customer_Code, Tch.Customer_Name
              Into v_Customer_Id, v_Customer_Code, v_Customer_Name
              From t_Customer_Header Tch
             Where Tch.Customer_Id = r_Share_Shipment.Customer_Id;
          Exception
            When Others Then
              v_Value := '失败：检查客户资料！客户编码：' || r_Share_Shipment.Customer_Code || v_Nl ||
                         Sqlerrm;
              Raise v_Base_Exception;
          End;
        Else
          v_Customer_Id := Null;
          v_Customer_Code := Null;
          v_Customer_Name := Null;
        End If;
      End If;

      --20161123 hejy3 增加客户有效性和内部客户检查，非调拨需检查
      IF v_Value = v_Success AND p_Order_Type <> '1008' THEN
        PKG_PLN_PUB.P_CHK_ERP_COST_AND_SUPPLIER(P_ENTITY_ID       => p_Entity_Id,
                                                P_SALES_CENTER_ID => v_Sales_Center_Id,
                                                P_CUSTOMER_ID     => r_Share_Shipment.Customer_Id,
                                                P_ACCOUNT_ID      => r_Share_Shipment.Account_Id,
                                                P_INVENTORY_ID    => r_Share_Shipment.Inventory_From_Id,
                                                P_ORDER_TYPE_ID   => r_Order_Head.Order_Type_Id,
                                                P_ITEM_ID_LIST    => to_char(r_Share_Shipment.Item_Id),
                                                P_RESULT          => v_Value);
        IF v_Value <> v_Success THEN
          RAISE v_Base_Exception;
        END IF;
      END IF;

      --ADD BY LIZHEN 2015-01-10 增加检查客户，是否经营产品所属的营销大数
      --MODI BY LIZHEN 2015-07-28 下线直发仓为调拨不检查客户的经营产品大类
      If Nvl(v_Out_Line_Flag, 'N') != 'Y' Then
        Begin
          Select Smt.Sales_Main_Type_Code
            Into v_Sales_Main_Type
            From t_Customer_Sales_Main_Type Smt
           Where Smt.Custom_Id = r_Share_Shipment.Customer_Id
             And Smt.Entity_Id = p_Entity_Id
             And Smt.Active_Flag = 'Active'
             And Smt.Sales_Main_Type_Code In
                 (Select Bi.Sales_Main_Type
                    From t_Bd_Item Bi
                   Where Bi.Item_Code = r_Share_Shipment.Item_Code
                     And Bi.Entity_Id = Smt.Entity_Id);
        Exception
          When Others Then
            v_Value := '检查客户经营产品营销大类失败！' || v_Nl || '客户编码：' ||
                       r_Share_Shipment.Customer_Code || v_Nl || '产品编码：' ||
                       r_Share_Shipment.Item_Code || v_Nl || Sqlerrm;
            Raise v_Base_Exception;
        End;
      End If;

      If v_Value = v_Success Then
        Select Count(1)
          Into v_Count
          From t_Inv_Bill_Types Bt
         Where Bt.Bill_Type_Id = r_Share_Shipment.Sales_Order_Type_Id
           And Trunc(Sysdate) Between Bt.Begin_Date And
               Trunc(Nvl(Bt.End_Date, Sysdate))
           And Bt.Entity_Id = p_Entity_Id;
        If v_Count = 0 Then
          v_Value := '单据类型不存在，或都单据类型已失效。单据类型ID：' || r_Share_Shipment.Sales_Order_Type_Id;
          Raise v_Base_Exception;
        End If;
      End If;

      If v_Value = v_Success Then
        -- 检查商品库存数量是否满足此次下达需求！
        If v_Pln_Wip_Ord_Match <> v_True Then
          v_Ord_Occupy_Qty := Pkg_Pln_Inv_Occupy.f_Get_Item_Occupy_Qty(r_Share_Shipment.Inventory_From_Id,
                                                                       r_Share_Shipment.Item_Id,
                                                                       p_Entity_Id,
                                                                       v_Pln_Wip_Ord_Match);

          Select Nvl(Sum(Nvl(Oss.Carry_Qty, 0) - Nvl(Oss.So_Order_Qty, 0)),
                     0)
            Into v_Nocarry_Qty
            From t_Pln_Order_Share_Shipment Oss
           Where Oss.Item_Id = r_Share_Shipment.Item_Id
             And Oss.Inventory_From_Id = r_Share_Shipment.Inventory_From_Id
             And Oss.Origin_Type <> '客户订单'
             And Oss.Carry_Qty > Oss.So_Order_Qty;
        Else
          v_Ord_Occupy_Qty := Pkg_Pln_Inv_Occupy.f_Item_Ass_Occupy_Qty(r_Share_Shipment.Inventory_From_Id,
                                                          r_Share_Shipment.Item_Id,
                                                          v_Pln_Wip_Ord_Match,
                                                          p_Entity_Id,
                                                          r_Share_Shipment.Origin_Line_Id);

          --获取已下达未开单数量
          Select Nvl(Sum(Oss.Carry_Qty - Oss.So_Order_Qty), 0)
            Into v_Nocarry_Qty
            From t_Pln_Order_Share_Shipment Oss
           Where Oss.Item_Id = r_Share_Shipment.Item_Id
             And Oss.Inventory_From_Id = r_Share_Shipment.Inventory_From_Id
             And Oss.Origin_Line_Id = r_Share_Shipment.Origin_Line_Id
             And Oss.Origin_Type <> '客户订单'
             And Oss.Carry_Qty > Oss.So_Order_Qty;
          v_Noord_Occupy_Qty := 0;
          /*Begin
            Select Sum(Nvl(Uh.Sp_Unlock_Qty, 0))
              Into v_Sp_Unlock_Qty
              From t_Inv_Sp_Unlock_History Uh, t_Mtl_Material Mm
             Where Uh.item_id = Mm.item_id
               And Uh.Entity_Id = Mm.Entity_Id
               And Uh.Inventory_Id = r_Week_Order_Share.Inventory_From_Id
               And Uh.Origin_Line_Id = r_Week_Order_Share.Origin_Line_Id
               And Uh.Entity_Id = r_Week_Order_Share.Entity_Id
               And Uh.item_id In
                   (Select Ms.item_id
                      From t_Mtl_Material_Assemblies    Ma,
                           t_Mtl_Material_Subassemblies Ms
                     Where Ma.Material_Assembly_Id =
                           Ms.Material_Assembly_Id
                       And Ma.Entity_Id = r_Week_Order_Share.Entity_Id
                       And Ma.item_id = r_Week_Order_Share.item_id
                    Union
                    Select r_Week_Order_Share.item_id item_id
                      From Dual);
          Exception
            When No_Data_Found Then
              v_Sp_Unlock_Qty := 0;
            When Others Then
              v_Value := '获取散件破损调拨数量失败！' || Sqlerrm;
          End;*/
          If v_Pln_Wip_Ord_Match = v_Pln_Wip_Ord_Match And
             Nvl(v_Sp_Reloccupy_Qty, 0) > 0 Then
            v_Sp_Msg := '套件商品：' || r_Share_Shipment.Item_Code ||
                        '，存在散件破损拨释放数量：' || To_Char(v_Sp_Reloccupy_Qty) || '。';
          Else
            v_Sp_Msg := '';
          End If;
        End If;

        --add by lizhen 2015-03-18 获取提货订单未评审的发货计划数量
        Begin
          Select Sum(Osr.Review_Qty)
            Into v_Lg_Ship_Review_Qty
            From t_Pln_Lg_Order_Ship_Review Osr
           Where Osr.Entity_Id = p_Entity_Id
             And Osr.Origin_Order_Head_Id = r_Share_Shipment.Origin_Head_Id
             And Osr.Origin_Order_Line_Id = r_Share_Shipment.Origin_Line_Id
             And Osr.Origin_Order_Share_Id = r_Share_Shipment.Order_Share_Id
             And Osr.Order_Line_Id != r_Share_Shipment.Lg_Order_Line_Id
             And Osr.Order_Head_Id != r_Share_Shipment.Lg_Order_Head_Id
             And Nvl(Osr.Review_Status, 'N') = 'N';
        Exception
          When No_Data_Found Then
            v_Lg_Ship_Review_Qty := 0;
          When Others Then
            v_Value := '获取提货订单未评审的发货计划数量失败！';
            Raise v_Base_Exception;
        End;
        If Nvl(r_Share_Shipment.Share_Qty, 0) - Nvl(r_Share_Shipment.Carrying_Qty, 0)
          - Nvl(r_Share_Shipment.Carry_Qty, 0) < Nvl(v_Lg_Ship_Review_Qty, 0) Then
          v_Value := '发货计划下达失败，当前可下达数量不满足下达需求。' || v_Nl ||
            '订单单号：' || r_Share_Shipment.Origin_Head_Code || v_Nl ||
            '产品编码：' || r_Share_Shipment.Item_Code || v_Nl ||
            '未下达数量：' || To_Char(Nvl(r_Share_Shipment.Share_Qty, 0) - Nvl(r_Share_Shipment.Carry_Qty, 0)) || v_Nl ||
            '本次下达数量：' || To_Char(Nvl(r_Share_Shipment.Carrying_Qty, 0)) || v_Nl ||
            '提货订单发货计划未评审数量：' || To_Char(Nvl(v_Lg_Ship_Review_Qty, 0)) || v_Nl ||
            '未下达数量-本次下达数量 < 提货订单发货计划未评审数量，下达失败。'
            ;
          Raise v_Base_Exception;
        End If;

        --下达未开单数量+现下达数量<=库存-物流订单锁-采购退货数量
        If Nvl(v_Nocarry_Qty, 0) + Nvl(r_Share_Shipment.Carrying_Qty, 0) >
           Nvl(v_Ord_Occupy_Qty, 0) + Nvl(v_Noord_Occupy_Qty, 0) Then
          v_Value := '商品库存现有数量' ||
                     To_Char(v_Noord_Occupy_Qty + v_Ord_Occupy_Qty) ||
                     '小于已下达未开单数' || To_Char(Nvl(v_Nocarry_Qty, 0)) ||
                     '+现下达数量' ||
                     To_Char(Nvl(r_Share_Shipment.Carrying_Qty, 0)) ||
                     ',无法满足此次运力任务下达数量需求，本次可下达数量：【' ||
                     To_Char(v_Noord_Occupy_Qty + v_Ord_Occupy_Qty -
                             Nvl(v_Nocarry_Qty, 0)) || '】。' || v_Nl ||
                     v_Sp_Msg;
          Raise v_Base_Exception;
        End If;
      End If;
      
      --获取系统参数，中心备货提货订单是否使用仓库地址
      BEGIN
        V_IS_INV_ADDRESS := PKG_BD.F_GET_PARAMETER_VALUE('PLN_LG_ORDER_INV_ADDRESS',
                                                         p_Entity_Id);
      EXCEPTION
        WHEN OTHERS THEN
          P_RESULT := '获取PLN_LG_ORDER_INV_ADDRESS参数失败！' || V_NL ||
                      SQLERRM;
        RAISE V_BASE_EXCEPTION;
      END;
      --add by lilh6 中心备货提货订单 16-9-20
      BEGIN
        SELECT UCL.CODE_NAME
          INTO V_BILL_TYPE_CODE1
          FROM UP_CODELIST UCL, UP_CODELIST_ENTITY UCLE
         WHERE UCL.CODETYPE = 'PLG_LGORDER_CENTER_TRANSFER'
           AND UCL.ID = UCLE.CODELIST_ID
           AND UCL.ENABLED = 0
           AND UCL.CODE_VALUE = TO_CHAR(r_Lg_Order_Head.Order_Type_Id)
           AND UCLE.ENTITY_ID = p_Entity_Id;
      
        --中心备货提货订单不需检查4级地址
        IF V_IS_INV_ADDRESS = 'Y' THEN
          V_ADDRESS_CHECK     := 'N';
        ELSE 
          V_ADDRESS_CHECK     := 'Y';
        END IF;
        
        V_IS_CENTER_TRSF := 'Y';
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          V_BILL_TYPE_CODE1 := NULL;
        WHEN OTHERS THEN
          P_RESULT := '获取中心备货提货订单单据类型的CODELIST设置失败，CODELIST编码：PLG_LGORDER_CENTER_TRANSFER' || V_NL ||
                      SQLERRM;
          RAISE V_BASE_EXCEPTION;
      END;

      --自提、调拨单不检查收货单位地址
      If Nvl(r_Share_Shipment.Is_Cusg_Flag, v_False) <> v_True AND V_ADDRESS_CHECK != 'N' AND
        Nvl(r_Share_Shipment.Is_Pick_Flag, 'N') <> 'Y' And p_Order_Type != '1008'
        --add by xuhongjiu 修改过收货地址的不校验
        And nvl(v_is_modify_address,'N') = 'N' Then
        if v_Lg_Order_Review_Flag = v_True and nvl(r_Lg_Order_Head.Is_Chk_Consinee_Address, 'A') = 'N' then
          Begin
            Select Bd.Row_Id, Bd.District_Code
              Into v_Ship_To_Location_Id, v_Consignee_Location_Code
              From t_Bd_District Bd
             Where Bd.District_Code = r_Share_Shipment.Consignee_Address_Code
               And Bd.Level_Seq = Decode(v_Consignee_Add_4_Flag, 'N', Bd.Level_Seq, 5);  --add by lizhen 2016-01-15
          Exception
            When Others Then
              v_Value := '检查收货地点编码失败！收货地点编码：' ||
                         r_Share_Shipment.Consignee_Address_Code || v_Nl ||
                         Sqlerrm;
              Raise v_Base_Exception;
          End;
        else
          Begin
            --modi by lizhen 2016-01-16 客户收货地点取4级地址信息
            Select Decode(v_Consignee_Add_4_Flag, 'N', nvl(tca.towns, Tca.Area), Tca.Towns), Tbd.Row_Id
              Into v_Consignee_Location_Code, v_Ship_To_Location_Id
              From t_Customer_Address         Tca,
                   t_Bd_District              Tbd,
                   t_Customer_Account_Address Caa
             Where Tca.Customer_Id = r_Share_Shipment.Customer_Id
               And Tca.Address_Type = 'ShipTo'
               And Tca.Active_Flag = 'Active'
               And Tbd.District_Code = Decode(v_Consignee_Add_4_Flag, 'N', nvl(tca.towns, Tca.Area), Tca.Towns)
               And Caa.Address_Id = Tca.Address_Id
               And Caa.Account_Id = r_Share_Shipment.Account_Id
               And Tca.Address_Id = r_Share_Shipment.Consignee_Id
               And Tbd.Level_Seq = Decode(v_Consignee_Add_4_Flag, 'N', Tbd.Level_Seq, 5);
          Exception
            When Others Then
              v_Value := '失败，检查收货地址失败，收货地址不存在或者已失效！' || v_Nl || '客户编码：' ||
                         r_Share_Shipment.Customer_Code || v_Nl || '账户编码：' ||
                         r_Share_Shipment.Account_Code || v_Nl || '收货地址ID：' ||
                         To_Char(r_Share_Shipment.Consignee_Id) || v_Nl || Sqlerrm;
              Raise v_Base_Exception;
          End;
        end if;
      Elsif p_Order_Type = '1008' Then
        if V_IS_CENTER_TRSF = 'Y' then
          Begin
            Select Bd.Row_Id, Bd.District_Code
              Into v_Ship_To_Location_Id, v_Consignee_Location_Code
              From t_Bd_District Bd
             Where Bd.District_Code = r_Lg_Order_Head.Consignee_Addr_Code
               And Bd.Level_Seq = Decode(v_Consignee_Add_4_Flag, 'N', Bd.Level_Seq, 5);  --add by lizhen 2016-01-15
          Exception
            When Others Then
              v_Value := '检查地点编码失败！收货地点编码：' ||
                         r_Lg_Order_Head.Consignee_Addr_Code || v_Nl ||
                         Sqlerrm;
              Raise v_Base_Exception;
          End;
        else
          Begin
            --modi by lizhen 2016-01-16 客户收货地点取4级地址信息
            Select Ii.District_Id, Bd.District_Code
              Into v_Ship_To_Location_Id, v_Consignee_Location_Code
              From t_Inv_Inventories Ii, t_Bd_District Bd
             Where Ii.Inventory_Id = r_Share_Shipment.Inventory_To_Id
               And Bd.Row_Id = Ii.District_Id
               And Bd.Level_Seq = Decode(v_Consignee_Add_4_Flag, 'N', Bd.Level_Seq, 5);  --add by lizhen 2016-01-16
          Exception
            When Others Then
              v_Value := '失败，检查仓库的收货地点失败！收货仓库编码：' ||
                         r_Share_Shipment.Rcv_Inv_Code || v_Nl || Sqlerrm;
              Raise v_Base_Exception;
          End;
        end if;
      Elsif Nvl(r_Share_Shipment.Is_Cusg_Flag, v_False) = v_True Or
        Nvl(r_Share_Shipment.Is_Pick_Flag, v_False) = v_True Then
        --Todo  检查IMS直发客户地址、自提。
        if r_Share_Shipment.Is_Cusg_Flag = v_True and r_Share_Shipment.Agent_Order_Id is null
          and r_Share_Shipment.Transfer_Cust_Id is not null
          and r_Share_Shipment.Transfer_Account_Id is not null
          and nvl(v_Lg_Order_Review_Flag,'N') = v_False
        then
          begin
            Select Decode(v_Consignee_Add_4_Flag, 'N', nvl(tca.towns, Tca.Area), Tca.Towns), Tbd.Row_Id
              Into v_Consignee_Location_Code, v_Ship_To_Location_Id
              From t_Customer_Address         Tca,
                   t_Bd_District              Tbd,
                   t_Customer_Account_Address Caa
             Where Tca.Customer_Id = r_Share_Shipment.Transfer_Cust_Id
               And Tca.Address_Type = 'ShipTo'
               And Tca.Active_Flag = 'Active'
               And Tbd.District_Code = Decode(v_Consignee_Add_4_Flag, 'N', nvl(tca.towns, Tca.Area), Tca.Towns)
               And Caa.Address_Id = Tca.Address_Id
               And Caa.Account_Id = r_Share_Shipment.Transfer_Account_Id
               And Tca.Address_Id = r_Share_Shipment.Consignee_Id
               and tca.entity_id = r_Share_Shipment.Transfer_Entity_Id
               And Tbd.Level_Seq = Decode(v_Consignee_Add_4_Flag, 'N', Tbd.Level_Seq, 5);
          Exception
            When Others Then
              v_Value := '失败，检查收货地址失败，收货地址不存在或者已失效！' || v_Nl ||
                         '直发客户编码：' || r_Share_Shipment.Transfer_Cust_Code || v_Nl ||
                         '直发账户编码：' || r_Share_Shipment.Transfer_Account_Code || v_Nl ||
                         '收货地址ID：' || To_Char(r_Share_Shipment.Consignee_Id) || ',收货地址：' || v_Nl || r_Share_Shipment.Consignee_Address_Name ||
                         Sqlerrm;
              Raise v_Base_Exception;
          End;
        end if;
        
        Begin
          --modi by lizhen 2016-01-16 客户收货地点取4级地址信息
          Select Bd.Row_Id, Bd.District_Code
            Into v_Ship_To_Location_Id, v_Consignee_Location_Code
            From t_Bd_District Bd
           Where Bd.District_Code = r_Share_Shipment.Consignee_Address_Code
             And Bd.Level_Seq = Decode(v_Consignee_Add_4_Flag, 'N', Bd.Level_Seq, 5);  --add by lizhen 2016-01-15
        Exception
          When Others Then
            v_Value := '检查客户直发信息的发货地点编码失败！收货地点编码：' ||
                       r_Share_Shipment.Consignee_Address_Code || v_Nl ||
                       Sqlerrm;
            Raise v_Base_Exception;
        End;
      Elsif Nvl(v_is_modify_address, 'N') = 'Y' Then
        --add by xuhongjiu 修改过地址的  2016-03-31
        Begin
          Select Bd.Row_Id, Bd.District_Code
            Into v_Ship_To_Location_Id, v_Consignee_Location_Code
            From t_Bd_District Bd
           Where Bd.District_Code = r_Share_Shipment.Consignee_Address_Code;
        Exception
          When Others Then
            v_Value := '检查客户直发信息的发货地点编码失败！收货地点编码：' ||
                       r_Share_Shipment.Consignee_Address_Code || v_Nl ||
                       Sqlerrm;
            Raise v_Base_Exception;
        End;
      elsif v_address_check = 'N' then
        --使用仓库的中心备货提货订单
        Begin
          Select Bd.Row_Id, Bd.District_Code
            Into v_Ship_To_Location_Id, v_Consignee_Location_Code
            From t_Bd_District Bd
           Where Bd.District_Code = r_Lg_Order_Head.Consignee_Addr_Code;
        Exception
          When Others Then
            v_Value := '检查发货地点编码失败！收货地点编码：' ||
                       r_Lg_Order_Head.Consignee_Addr_Code || v_Nl ||
                       Sqlerrm;
            Raise v_Base_Exception;
        End;
      End If;
      
      --获取主数据地址ID
      BEGIN
        SELECT A.SIEBEL_ADDRESS_ID
          INTO V_CRM_ADDRESS_ID
          FROM T_CUSTOMER_ADDRESS A
         WHERE A.ADDRESS_ID = r_Share_Shipment.Consignee_Id;
      EXCEPTION
        WHEN OTHERS THEN
          V_CRM_ADDRESS_ID := NULL;
      END;

      --MODI BY LIZHEN 2015-01-08 自提不检查收货地点信息
      If v_Value = v_Success And r_Share_Shipment.Is_Pick_Flag <> 'Y' Then
        Select Count(*)
          Into v_Count
          From t_bd_district bd
         Where bd.row_id = r_Share_Shipment.Incept_Address_Id;
        If v_Count = 0 Then
          v_Value := '失败，检查收货地点失败！收货地点ID:' ||
                     To_Char(r_Share_Shipment.Incept_Address_Id);
          Raise v_Base_Exception;
        End If;
      End If;

      If v_Value = v_Success Then
        Select Count(*)
          Into v_Count
          From t_Inv_Inventories Ii
         Where Ii.Inventory_Id = r_Share_Shipment.Inventory_From_Id
           And Ii.Entity_Id = p_Entity_Id
           And Trunc(Sysdate) Between Ii.Begin_Date And
               Trunc(Nvl(Ii.End_Date, Sysdate + 1));
        If v_Count = 0 Then
          v_Value := '失败，检查发货仓库资料有效性！仓库编码:' ||
                     r_Share_Shipment.Inventory_Code_From;
          Raise v_Base_Exception;
        End If;
      End If;

      --调拨单 检查收货仓库
      If v_Value = v_Success And p_Order_Type = '1008' /*And
         Nvl(r_Share_Shipment.Is_Cusg_Flag, 'N') <> 'Y'*/ Then
        if Nvl(r_Share_Shipment.Is_Cusg_Flag, 'N') <> 'Y' then
          Select Count(*)
            Into v_Count
            From t_Inv_Inventories II
           Where Ii.Inventory_Id = r_Share_Shipment.Inventory_To_Id
             And Ii.Entity_Id = p_Entity_Id
             And Sysdate Between Ii.Begin_Date And
                 Nvl(Ii.End_Date, Sysdate + 1);
          If v_Count = 0 Then
            v_Value := '检查收货仓库资料有效性失败！仓库ID：' ||
                     r_Share_Shipment.Inventory_To_Id;
            Raise v_Base_Exception;
          End If;
        end if;
        
        --20180530 hejy3 控制调拨收发仓不能相同
        if r_Share_Shipment.Inventory_From_Id = r_Share_Shipment.Inventory_To_Id then
          v_Value := '调拨接收仓库和发货仓库不能相同，请重新选择调拨接收仓库';
          raise v_Base_Exception;
        end if;
      End If;

      --调拨时检查收货仓库和发货仓库是否在同一经营组织,获取发货仓所属管理系统
      Begin
        Select Tio.Organization_Id, Tii.Docking_System, tii.stock_type --20170621 hejy3 发货仓库存货类型
          Into v_Inv_Send_Ou_Id, v_Docking_System, v_Send_Inv_Stock_Type --20170621 hejy3 发货仓库存货类型
          From t_Inv_Inventories Tii, t_Inv_Organization Tio
         Where Tii.Organization_Id = Tio.Organization_Id
           And Tii.Entity_Id = p_Entity_Id
           AND tio.entity_id = tii.entity_id -- add by windwind 20150425 防止多主体脏数据
           And Tii.Inventory_Id = r_Share_Shipment.Inventory_From_Id;
      Exception
        When Others Then
          v_Value := '获取发货仓库经营组织失败，收货仓库编码：' ||
                      r_Share_Shipment.Inventory_Code_From;
          Raise v_Base_Exception;
      End;
      If v_Value = v_Success And p_Order_Type = '1008' Then
        Begin
          Select Tio.Organization_Id, tii.stock_type --20170621 hejy3 收货仓库存货类型
            Into v_Inv_Recive_Ou_Id, v_Rev_Inv_Stock_Type --20170621 hejy3 收货仓库存货类型
            From t_Inv_Inventories Tii, t_Inv_Organization Tio
           Where Tii.Organization_Id = Tio.Organization_Id
             And Tii.Entity_Id = p_Entity_Id
             AND tio.entity_id = tii.entity_id
             And Tii.Inventory_Id = r_Share_Shipment.Inventory_To_Id;
        Exception
          When Others Then
            v_Value := '获取收货仓库经营组织失败，收货仓库编码：' ||
                        r_Share_Shipment.Rcv_Inv_Code;
            Raise v_Base_Exception;
        End;

        --20170621 hejy3 仓库存货类型检查
        If v_Inv_Recive_Ou_Id <> v_Inv_Send_Ou_Id or v_Send_Inv_Stock_Type <> v_Rev_Inv_Stock_Type Then
          v_Value := '调拨单收货仓库与发货仓库必须为同一经营组织或相同存货类型。收货仓库经营组织ID（' || To_Char(v_Inv_Recive_Ou_Id) ||
                      '），发货仓库经营组织ID（' || To_Char(v_Inv_Send_Ou_Id) ||
                      '），收货仓库存货类型（'||v_Rev_Inv_Stock_Type||'），发货仓库存货类型（'||v_Send_Inv_Stock_Type||'），请重新选择收货仓库信息。';
          Raise v_Base_Exception;
        End If;
      End If;

      If v_Value = v_Success Then
        Begin
          Select i.Sales_Main_Type,i.item_name
            Into v_Sales_Main_Type,v_Item_Name  --20150425 add by wildwind
            From t_Bd_Item i
           Where i.Item_Id = r_Share_Shipment.Item_Id;
        Exception
          When Others Then
            v_Value := '获取产品营销大类与产品描述失败，产品编码：' || r_Share_Shipment.Item_Code || v_Nl ||
                       Sqlerrm;
            Raise v_Base_Exception;
        End;
      End If;

      --If v_Value = v_Success And p_Order_Type = '销售' Then
      If v_Lg_Order_Review_Flag = v_False Then
        --modi by lizhen 2015-07-28 下线直发不取最新价格
        --modi by lizhen 2015-12-03 送审锁款的单据不再重新取单价，按订单分配行（单价来源于订单行）生成分配行单价
        If Nvl(r_Order_Head.Lock_Amount_Flag, v_Default_Lock_Amount_Flag) != 'S' Then
          -- add by ex_zhangcc 2015-1-18 如果是批文 不从提货订单来 则不用重新取
          If Nvl(v_Out_Line_Flag, 'N') != 'Y' And r_Share_Shipment.Project_Order_Number Is Null 
            --add by lizhen 2016-11-04 调拨单据不需要重新取单价
            And p_Order_Type != '1008' Then
            Begin
              Pkg_Bd_Price.p_Get_Price(p_Acc_Id         => r_Share_Shipment.Account_Id, --账户ID
                                       p_Item_Code      => r_Share_Shipment.Item_Code, --产品ID
                                       p_Bill_Date      => To_Char(Trunc(Sysdate), 'YYYYMMDD'), --单据日期
                                       p_Price_List_Id  => Null, --价格列表ID
                                       p_Entity_Id      => p_Entity_Id, --业务主体ID
                                       p_Price          => v_Price, --返回价格
                                       p_Discount       => v_Discount, --返回折扣率
                                       p_Month_Discount => v_Month_Discount, --返回月返
                                       p_Cx_Flag        => v_Cx_Flag --返回是否促销机
                                       );
            Exception
              When Others Then
                v_Value := '获取产品价格失败，产品编码：' || r_Order_Line.Item_Code ||
                  '，账户ID：' || To_Char(r_Order_Head.Account_Id) || v_Nl || Sqlerrm;
                Raise v_Base_Exception;
            End;
            v_Discount := r_Share_Shipment.Discount_Rate;
          Else
            Select Decode(r_Share_Shipment.Project_Order_Number,
                          Null,
                          r_Share_Shipment.List_Price,
                          r_Share_Shipment.Apply_List_Price),
                   Decode(r_Share_Shipment.Project_Order_Number,
                          Null,
                          r_Share_Shipment.Discount_Rate,
                          --20170717 hejy3 价格批文申请使用折扣
                          Decode(v_Price_Apply_Use_Discount,
                                 'Y',
                                 Nvl(r_Share_Shipment.Apply_Discount_Rate, 0),
                                 0)),
                   r_Share_Shipment.Ordered_Discount_Rate
              Into v_Price, v_Discount, v_Month_Discount
              From Dual;
            /*
            v_Price := r_Share_Shipment.List_Price;
            v_Discount := r_Share_Shipment.Discount_Rate;
            v_Month_Discount := r_Share_Shipment.Ordered_Discount_Rate; -- add by lizhen 2015-10-12
            */
          End If;
        Else
          v_Price := r_Share_Shipment.List_Price;
          v_Discount := r_Share_Shipment.Discount_Rate;
          v_Month_Discount := r_Share_Shipment.Ordered_Discount_Rate; -- add by lizhen 2015-10-12
        End If;
      Else
        Select Decode(r_Lg_Order_Line.Project_Order_Type,
                      Null,
                      r_Lg_Order_Line.List_Price,
                      r_Lg_Order_Line.Apply_List_Price),
               Decode(r_Lg_Order_Line.Project_Order_Type,
                      Null,
                      r_Lg_Order_Line.Discount_Rate,
                      --0  --modi by lizhen 2015-12-17 批文折扣率为0，单价已被折扣
                      --20170717 hejy3 价格批文申请使用折扣
                      decode(v_Price_Apply_Use_Discount, 'Y', nvl(r_Lg_Order_Line.Apply_Discount_Rate, 0), 0)
                      ),
               r_Lg_Order_Line.Ordered_Discount_Rate  --add by lizhen 2015-10-12
          Into v_Price, v_Discount, v_Month_Discount
          From Dual;
      End If;
      --modi by lizhen 2015-07-28 提货订单发货不在订单发货计划锁款，在提货订单评审发货时锁款
      If v_Value = v_Success And p_Order_Type = '1006' And v_Lg_Order_Review_Flag = v_False Then
        If v_Price Is Null Then
          v_Value := '产品无价格，订单下达失败。' || v_NL || '产品编码：' || r_Order_Line.Item_Code ||
            '，账户ID：' || To_Char(r_Order_Head.Account_Id);
          Raise v_Base_Exception;
        End If;
        v_Account_Amount := (r_Share_Shipment.Carrying_Qty * v_Price
          * (100 - nvl(v_Discount, 0) - Nvl(v_Month_Discount, 0))) / 100;
          --modi by lizhen 2015-10-12
          --* (100 - nvl(v_Discount, 0)))) / 100;

        v_Discount_Amount := (r_Share_Shipment.Carrying_Qty * v_Price
          * nvl(v_Discount, 0)) / 100;
        --add by lizhen 2015-07-17 订单发货时才进行锁款操作
        If Nvl(r_Share_Shipment.Lock_Amount_Flag, v_Default_Lock_Amount_Flag) = pkg_pln_pub.V_LOCK_AMOUNT_FLAG_Y Then
          /*Pkg_Credit_Account_Control.Prc_Credit_Order_Bill(p_Entity_Id, --主体ID
                                                           1, --动作
                                                           Round(v_Account_Amount, 2), --结算金额
                                                           Round(v_Discount_Amount, 2), --折让金额
                                                           --20170517 hejy3 按行营销大类
                                                           --v_Sales_Main_Type,
                                                           nvl(r_Order_Line.Sales_Main_Type, v_Sales_Main_Type),
                                                           r_Share_Shipment.Account_Id, --账户ID
                                                           r_Share_Shipment.Customer_Id, --客户ID
                                                           Null, --项目编码
                                                           r_Share_Shipment.Origin_Head_Id, --单据头ID
                                                           --r_Share_Shipment.Origin_Type, --单据类型名
                                                           r_Order_Head.Order_Type_Code, --20160912 hejy3 传入订单类型编码
                                                           p_User_Code,
                                                           v_Count,
                                                           v_Value,
                                                           r_Share_Shipment.Discount_Type  --add by lizhen 2017-08-08
                                                           );*/
          pkg_pln_pub.P_CUSTOMER_AMOUNT_PROCESS(IN_ENTITY_ID       => p_Entity_Id,
                                                IN_ORDER_TYPE_ID   => r_Order_Head.Order_Type_Id,
                                                IN_ORDER_TYPE_CODE => r_Order_Head.Order_Type_Code,
                                                IN_CUSTOMER_ID     => r_Share_Shipment.Customer_Id,
                                                IN_ACCOUNT_ID      => r_Share_Shipment.Account_Id,
                                                IN_SALES_MAIN_TYPE => nvl(r_Order_Line.Sales_Main_Type, v_Sales_Main_Type),
                                                IN_ACTION_TYPE     => 1,
                                                IN_SOURCE_TYPE     => '01',
                                                IN_ORDER_ID        => r_Share_Shipment.Origin_Head_Id,
                                                IN_PROJ_NUMBER     => null,
                                                IN_DISCOUNT_TYPE   => r_Share_Shipment.Discount_Type,
                                                IN_AMOUNT          => Round(v_Account_Amount, 2),
                                                IN_DIS_AMOUNT      => Round(v_Discount_Amount, 2),
                                                IN_RECORD_ERR      => 'N',
                                                IN_USER_CODE       => Round(v_Discount_Amount, 2),
                                                OUT_RESULT         => v_Value);
        Elsif Nvl(r_Share_Shipment.Lock_Amount_Flag, v_Default_Lock_Amount_Flag) = 'RT' Then
          --ADD BY LIZHEN 2015-07-17 推广物料资源提货
          Null;
        End If;
        If v_Value <> v_Success Then
          /*v_Value := '总部客户编码：' || r_Share_Shipment.Customer_Code ||
                     '，校验资金失败：' || v_Value || v_Nl || Sqlerrm;*/
          v_Value := '计划订单下达处理客户款项失败(锁款方式:'||Nvl(r_Share_Shipment.Lock_Amount_Flag, v_Default_Lock_Amount_Flag)||')！' || v_Nl || v_Value;
          Raise v_Base_Exception;
        End If;
      End If;
      
      --add by lizhen 2017-08-24计划订单进行调拨时，不锁定款项
      If v_Value = v_Success And p_Order_Type = '1008' And r_Share_Shipment.Lock_Amount_Flag = 'Y' 
        And v_Lg_Order_Review_Flag = v_False Then
        r_Share_Shipment.Lock_Amount_Flag := 'N';
      End If;      

      --modi by lizhen 2016-01-19 提货订单计划发货为非多主体采购订单，不需重新做解锁款操作
      If r_Share_Shipment.Account_Code <> r_Order_Head.Account_Code And v_Lg_Order_Review_Flag = v_False And
         nvl(r_Back_Share_Ship.Lock_Amount_Flag,'_') = 'S' Then

         If nvl(v_Account_Amount,0) > 0 Then
            --增加写到物流的客户的锁款
            /*Pkg_Credit_Account_Control.Prc_Credit_Order_Bill(p_Entity_Id, --主体ID
                                                           1, --动作(增加信用占用）
                                                           Round(v_Account_Amount, 2), --结算金额
                                                           Round(v_Discount_Amount, 2), --折让金额
                                                           --20170517 hejy3 按行营销大类
                                                           --v_Sales_Main_Type,
                                                           nvl(r_Order_Line.Sales_Main_Type, v_Sales_Main_Type),
                                                           r_Share_Shipment.Account_Id, --账户ID
                                                           r_Share_Shipment.Customer_Id, --客户ID
                                                           Null, --项目编码
                                                           r_Share_Shipment.Origin_Head_Id, --单据头ID
                                                           --r_Share_Shipment.Origin_Type, --单据类型名
                                                           r_Order_Head.Order_Type_Code, --20160912 hejy3 传入订单类型编码
                                                           p_User_Code,
                                                           v_Count,
                                                           p_Result,
                                                           r_Share_Shipment.Discount_Type  --add by lizhen 2017-08-08
                                                           );

           If p_Result <> v_Success Then
            v_Value := '多主体采购订单下达加锁款项失败。' || v_Nl ||
              '客户编码：' || r_Share_Shipment.Customer_Code || v_Nl ||
              '账户编码：' || r_Share_Shipment.Account_Code || v_Nl ||
              '产品大类：' || v_Sales_Main_Type || v_Nl ||
              '校验资金失败：' || p_Result || v_Nl || Sqlerrm;
            Raise v_Base_Exception;
           End If;*/
           pkg_pln_pub.P_CUSTOMER_AMOUNT_PROCESS(IN_ENTITY_ID       => p_Entity_Id,
                                                 IN_ORDER_TYPE_ID   => r_Order_Head.Order_Type_Id,
                                                 IN_ORDER_TYPE_CODE => r_Order_Head.Order_Type_Code,
                                                 IN_CUSTOMER_ID     => r_Share_Shipment.Customer_Id,
                                                 IN_ACCOUNT_ID      => r_Share_Shipment.Account_Id,
                                                 IN_SALES_MAIN_TYPE => nvl(r_Order_Line.Sales_Main_Type, v_Sales_Main_Type),
                                                 IN_ACTION_TYPE     => 1,
                                                 IN_SOURCE_TYPE     => '01',
                                                 IN_ORDER_ID        => r_Share_Shipment.Origin_Head_Id,
                                                 IN_PROJ_NUMBER     => null,
                                                 IN_DISCOUNT_TYPE   => r_Share_Shipment.Discount_Type,
                                                 IN_AMOUNT          => Round(v_Account_Amount, 2),
                                                 IN_DIS_AMOUNT      => Round(v_Discount_Amount, 2),
                                                 IN_RECORD_ERR      => 'N',
                                                 IN_USER_CODE       => p_User_Code,
                                                 OUT_RESULT         => v_Value);
           If v_Value <> v_Success Then
             v_Value := '多主体采购处理客户款项失败(锁款方式:'||r_Back_Share_Ship.Lock_Amount_Flag||')！' || v_Nl || v_Value;
             Raise v_Base_Exception;
           End If;
         End If;

            Begin
             --增加本来计划订单的客户的锁款
             Select l.item_price,
                    l.discount_rate,
                    l.ordered_discount_rate
               Into v_New_Price,
                    v_New_Discount_Rate,
                    v_New_Month_Discount_Rate
               From t_Pln_Order_Line l
              Where l.order_line_id = r_Share_Shipment.Origin_Line_Id;
           Exception
             When Others Then
              v_Value := '查询计划行表信息失败，订单行ID：' || r_Share_Shipment.Origin_Line_Id || v_Nl || Sqlerrm;
             Raise v_Base_Exception;
            End;

            v_New_Account_Amount := (r_Share_Shipment.Carrying_Qty * v_New_Price
              * (100 - nvl(v_New_Discount_Rate, 0) - Nvl(v_New_Month_Discount_Rate, 0))) / 100;
            v_New_Discount_Amount := (r_Share_Shipment.Carrying_Qty * v_New_Price
              * nvl(v_New_Discount_Rate, 0)) / 100;

            If nvl(v_New_Account_Amount,0) > 0 Then
            --减少原来客户的锁款
            /*Pkg_Credit_Account_Control.Prc_Credit_Order_Bill(p_Entity_Id, --主体ID
                                                           2, --动作(取消信用占用）
                                                           Round(v_New_Account_Amount, 2), --结算金额
                                                           Round(v_New_Discount_Amount, 2), --折让金额
                                                           --20170517 hejy3 按行营销大类
                                                           --v_Sales_Main_Type,
                                                           nvl(r_Order_Line.Sales_Main_Type, v_Sales_Main_Type),
                                                           r_Order_Head.Account_Id, --账户ID
                                                           r_Order_Head.Customer_Id, --客户ID
                                                           Null, --项目编码
                                                           r_Share_Shipment.Origin_Head_Id, --单据头ID
                                                           --r_Share_Shipment.Origin_Type, --单据类型名
                                                           r_Order_Head.Order_Type_Code, --20160912 hejy3 传入订单类型编码
                                                           p_User_Code,
                                                           v_Count,
                                                           p_Result,
                                                           r_Share_Shipment.Discount_Type  --add by lizhen 2017-08-08
                                                           );

           If p_Result <> v_Success Then
            v_Value := '多主体采购订单解锁款项失败。' || v_Nl ||
              '客户编码：' || r_Order_Head.Customer_Code || v_Nl ||
              '账户编码：' || r_Order_Head.Account_Code || v_Nl ||
              '产品大类：' || v_Sales_Main_Type || v_Nl ||
              '校验资金失败：' || p_Result || v_Nl || Sqlerrm;
            Raise v_Base_Exception;
           End If;*/
           pkg_pln_pub.P_CUSTOMER_AMOUNT_PROCESS(IN_ENTITY_ID       => p_Entity_Id,
                                                 IN_ORDER_TYPE_ID   => r_Order_Head.Order_Type_Id,
                                                 IN_ORDER_TYPE_CODE => r_Order_Head.Order_Type_Code,
                                                 IN_CUSTOMER_ID     => r_Order_Head.Customer_Id,
                                                 IN_ACCOUNT_ID      => r_Order_Head.Account_Id,
                                                 IN_SALES_MAIN_TYPE => nvl(r_Order_Line.Sales_Main_Type, v_Sales_Main_Type),
                                                 IN_ACTION_TYPE     => 2,
                                                 IN_SOURCE_TYPE     => '01',
                                                 IN_ORDER_ID        => r_Share_Shipment.Origin_Head_Id,
                                                 IN_PROJ_NUMBER     => null,
                                                 IN_DISCOUNT_TYPE   => r_Share_Shipment.Discount_Type,
                                                 IN_AMOUNT          => Round(v_New_Account_Amount, 2),
                                                 IN_DIS_AMOUNT      => Round(v_New_Discount_Amount, 2),
                                                 IN_RECORD_ERR      => 'N',
                                                 IN_USER_CODE       => p_User_Code,
                                                 OUT_RESULT         => v_Value);
           If v_Value <> v_Success Then
             v_Value := '多主体采购处理客户款项失败(锁款方式:'||r_Back_Share_Ship.Lock_Amount_Flag||')！' || v_Nl || v_Value;
             Raise v_Base_Exception;
           End If;
         End If;

      End If;
      
      --送审锁款处理
      If v_Value = v_Success And p_Order_Type = '1006' And v_Lg_Order_Review_Flag = v_False Then
        --add by lizhen 2015-07-17 订单发货时才进行锁款操作
        If Nvl(r_Share_Shipment.Lock_Amount_Flag, v_Default_Lock_Amount_Flag) = pkg_pln_pub.V_LOCK_AMOUNT_FLAG_S Then
          pkg_pln_pub.P_CUSTOMER_AMOUNT_PROCESS(IN_ENTITY_ID       => p_Entity_Id,
                                                IN_ORDER_TYPE_ID   => r_Order_Head.Order_Type_Id,
                                                IN_ORDER_TYPE_CODE => r_Order_Head.Order_Type_Code,
                                                IN_CUSTOMER_ID     => r_Share_Shipment.Customer_Id,
                                                IN_ACCOUNT_ID      => r_Share_Shipment.Account_Id,
                                                IN_SALES_MAIN_TYPE => nvl(r_Order_Line.Sales_Main_Type, v_Sales_Main_Type),
                                                IN_ACTION_TYPE     => 28,
                                                IN_SOURCE_TYPE     => '01',
                                                IN_ORDER_ID        => r_Share_Shipment.Origin_Head_Id,
                                                IN_PROJ_NUMBER     => null,
                                                IN_DISCOUNT_TYPE   => r_Share_Shipment.Discount_Type,
                                                IN_AMOUNT          => Round(v_Account_Amount, 2),
                                                IN_DIS_AMOUNT      => Round(v_Discount_Amount, 2),
                                                IN_RECORD_ERR      => 'N',
                                                IN_USER_CODE       => Round(v_Discount_Amount, 2),
                                                OUT_RESULT         => v_Value);
          If v_Value <> v_Success Then
            v_Value := '计划订单下达处理客户款项失败(锁款方式:'||Nvl(r_Share_Shipment.Lock_Amount_Flag, v_Default_Lock_Amount_Flag)||')！' || v_Nl || v_Value;
            Raise v_Base_Exception;
          End If;
        End If;
      End If;
      
      --20170428 hejy3 直发CIMS客户款项、批文锁定处理
      IF r_Share_Shipment.Transfer_Cust_Id IS NOT NULL AND r_Share_Shipment.Transfer_Entity_Id IS NOT NULL
        --20171030 hejy3 没有关联代理商订单才做锁定处理
        --and r_Share_Shipment.Agent_Order_Number is null
      THEN
        IF r_Share_Shipment.Agent_Order_Number is not null then
          /*begin
            select h.order_head_id, h.lock_amount_flag, h.order_type_code, '02'
              into v_Origin_Head_Id,
                   v_agent_order_lock_amount_flag,
                   v_Order_Type_Code,
                   v_Source_Type
              from t_pln_lg_order_head h
             where h.order_head_id = r_Share_Shipment.Agent_Order_Id;
          exception
            when others then
              v_Value := '获取代理商订单锁款标志失败，' || v_Nl ||
                      '代理商订单ID：' || to_char(r_Share_Shipment.Agent_Order_Id) ||
                      '代理商订单号：' || r_Share_Shipment.Agent_Order_Number ||
                      Sqlerrm;
              Raise v_Base_Exception;
          end;
          
          if v_agent_order_lock_amount_flag = 'Y' THEN
            v_Need_Lock_Agent_Amount := true;
          else
            v_Need_Lock_Agent_Amount := false;
          END IF;*/
          v_Need_Lock_Agent_Amount := false;
        else
          v_Need_Lock_Agent_Amount := true;
          v_Origin_Head_Id := r_Share_Shipment.Origin_Head_Id;
          v_Order_Type_Code := r_Order_Head.Order_Type_Code;
          v_Order_Type_Id := r_Order_Head.Order_Type_Id;
          v_Source_Type := '01';
        end if;
        
        if v_Need_Lock_Agent_Amount then
          v_Trsf_Amount := (r_Share_Shipment.Carrying_Qty * r_Share_Shipment.Transfer_List_Price
            * (100 - nvl(r_Share_Shipment.Transfer_Discount_Rate, 0) - Nvl(r_Share_Shipment.Transfer_Month_Discount_Rate, 0))) / 100;
          v_Trsf_Dis_Amount := (r_Share_Shipment.Carrying_Qty * r_Share_Shipment.Transfer_List_Price
            * nvl(r_Share_Shipment.Transfer_Discount_Rate, 0)) / 100;
          
          BEGIN
            SELECT BI.SALES_MAIN_TYPE INTO v_Trsf_Sales_Main_Type
              FROM T_BD_ITEM BI
             WHERE BI.ENTITY_ID = r_Share_Shipment.Transfer_Entity_Id
               AND BI.ITEM_CODE = r_Share_Shipment.Item_Code;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              v_Value := '获取分部产品营销大类失败，在分部主体未找到对应编码的产品' ||
                         '，产品编码：' || r_Share_Shipment.Item_Code;
              Raise v_Base_Exception;
          END;
          
          /*Pkg_Credit_Account_Control.Prc_Credit_Order_Bill(r_Share_Shipment.Transfer_Entity_Id, --主体ID
                                                           1, --动作
                                                           Round(v_Trsf_Amount, 2), --结算金额
                                                           Round(v_Trsf_Dis_Amount, 2), --折让金额
                                                           v_Trsf_Sales_Main_Type,
                                                           r_Share_Shipment.Transfer_Account_Id, --账户ID
                                                           r_Share_Shipment.Transfer_Cust_Id, --客户ID
                                                           Null, --项目编码
                                                           --r_Share_Shipment.Origin_Head_Id, --单据头ID
                                                           v_Origin_Head_Id,
                                                           --r_Share_Shipment.Origin_Type, --单据类型名
                                                           --r_Order_Head.Order_Type_Code, --20160912 hejy3 传入订单类型编码
                                                           v_Order_Type_Code,
                                                           p_User_Code,
                                                           v_Count,
                                                           v_Value,
                                                           r_Share_Shipment.Discount_Type  --add by lizhen 2017-08-08
                                                           );
          
          If v_Value <> v_Success Then
            v_Value := '分部客户编码：' || r_Share_Shipment.Transfer_Cust_Code ||
                       '，校验资金失败：' || v_Value || v_Nl || Sqlerrm;
            Raise v_Base_Exception;
          End If;
          
          IF nvl(r_Share_Shipment.Transfer_Discount_Type, 'COMMON') != 'COMMON' THEN
            PKG_CREDIT_DIS.P_CHECK_DIS_AMOUNT(IN_ACTION_TYPE     => 1,
                                              IN_ENTITY_ID       => r_Share_Shipment.Transfer_Entity_Id,
                                              IN_ACCOUNT_ID      => r_Share_Shipment.Transfer_Account_Id,
                                              --IS_SOURCE_TYPE     => '01', --快码 SO_SRC_TYPE
                                              IS_SOURCE_TYPE     => v_Source_Type, --快码 SO_SRC_TYPE
                                              --IN_SOURCE_BILL_ID  => r_Share_Shipment.Origin_Head_Id,
                                              IN_SOURCE_BILL_ID  => v_Origin_Head_Id,
                                              IS_SALES_MAIN_TYPE => v_Trsf_Sales_Main_Type,
                                              IS_DISCOUNT_TYPE   => r_Share_Shipment.Transfer_Discount_Type,
                                              IN_AMOUNT          => v_Trsf_Amount,
                                              IS_USER_NAME       => p_User_Code,
                                              IS_ATTRIB01        => NULL,
                                              IS_ATTRIB02        => NULL,
                                              ON_RESULT          => v_Count,
                                              OS_MESSAGE         => v_Value,
                                              OS_ATTRIB01        => V_OS_ATTRIB01,
                                              OS_ATTRIB02        => V_OS_ATTRIB02);
            
            IF v_Value <> v_Success THEN
              v_Value := '分部客户编码：' || r_Share_Shipment.Transfer_Cust_Code ||
                         '，营销大类' || v_Trsf_Sales_Main_Type ||
                         '，折让到款校验资金失败：' || v_Value || v_Nl || Sqlerrm;
              Raise v_Base_Exception;
            END IF;
          END IF;*/
          pkg_pln_pub.P_CUSTOMER_AMOUNT_PROCESS(IN_ENTITY_ID       => r_Share_Shipment.Transfer_Entity_Id,
                                                IN_ORDER_TYPE_ID   => v_Order_Type_Id,
                                                IN_ORDER_TYPE_CODE => v_Order_Type_Code,
                                                IN_CUSTOMER_ID     => r_Share_Shipment.Transfer_Cust_Id,
                                                IN_ACCOUNT_ID      => r_Share_Shipment.Transfer_Account_Id,
                                                IN_SALES_MAIN_TYPE => v_Trsf_Sales_Main_Type,
                                                IN_ACTION_TYPE     => 1,
                                                IN_SOURCE_TYPE     => v_Source_Type,
                                                IN_ORDER_ID        => r_Share_Shipment.Origin_Head_Id,
                                                IN_PROJ_NUMBER     => null,
                                                IN_DISCOUNT_TYPE   => r_Share_Shipment.Transfer_Discount_Type,
                                                IN_AMOUNT          => Round(v_Trsf_Amount, 2),
                                                IN_DIS_AMOUNT      => Round(v_Trsf_Dis_Amount, 2),
                                                IN_RECORD_ERR      => 'N',
                                                IN_USER_CODE       => p_User_Code,
                                                OUT_RESULT         => v_Value);
          if v_Value <> v_Success then
            v_Value := '计划订单直发客户，处理客户款项失败！' || v_Nl || v_Value;
            raise v_Base_Exception;
          END IF;
        end if;
        
        IF r_Share_Shipment.Transfer_Price_Apply_Type IS NOT NULL and r_Share_Shipment.Agent_Order_Number is null THEN
          PKG_BD_PRICE.P_APPLY_LOCK(P_APPLY_DETAIL_ID => r_Share_Shipment.Transfer_Price_Line_Id,
                                    P_LOCK_CNT        => r_Share_Shipment.Carrying_Qty,
                                    P_BILL_NO         => r_Share_Shipment.Origin_Head_Code,
                                    P_RETURN_CODE     => v_Value,
                                    P_RETURN_MSG      => p_Result);
          IF v_Value = '1' THEN --返回1表示成功
            v_Value := v_Success;
            p_Result := v_Success;
          ELSE
            v_Value := '批文号：'||r_Share_Shipment.Transfer_Price_Apply_Code||
                       '，产品编码：'||r_Share_Shipment.Item_Code||
                       '，数量：' || to_char(r_Share_Shipment.Carrying_Qty) || v_Nl ||
                       '锁定分部客户批文数量失败，错误信息：' || p_Result;
            RAISE v_Base_Exception;
          END IF;
        END IF;
      END IF;
      
      --hejy3 20160618 关联了代理商订单
      IF r_Share_Shipment.Agent_Order_Id IS NOT NULL AND r_Share_Shipment.Agent_Order_Number IS NOT NULL AND
        r_Share_Shipment.Agent_Order_Line_Id IS NOT NULL THEN
        --写操作接口表
        --CIMS接口表
        INSERT INTO INTF_PLN_LG_ORDER_OPT
          (ENTITY_ID,
           INTF_OPT_ID,
           OPT_TYPE,
           ORDER_HEAD_ID,
           ORDER_LINE_ID,
           SYS_SOURCE,
           SOURCE_HEAD_ID,
           SOURCE_LINE_ID,
           OPT_QUANTITY,
           DEAL_MONEY,
           DEAL_FLAG,
           CREATED_BY,
           CREATION_DATE,
           ORDER_SHARE_ID)
        SELECT p_Entity_Id,
               S_INTF_PLN_LG_ORDER_OPT.NEXTVAL,
               '制定发货需求计划下达',
               S.ORIGIN_HEAD_ID,
               S.ORIGIN_LINE_ID,
               'CIMS',
               S.AGENT_ORDER_ID,
               S.AGENT_ORDER_LINE_ID,
               S.CARRY_QTY,
               '不处理款项',
               'C',
               p_User_Code,
               SYSDATE,
               S.ORDER_SHARE_ID
          FROM T_PLN_ORDER_SHARE_SHIPMENT S
         WHERE S.ORDER_SHARE_ID = p_Order_Share_Id;
        
        --20171030 hejy3 关联代理商订单
        IF r_Share_Shipment.Transfer_Account_Code IS NULL THEN
          /*SELECT IMS_S_IO_LG_ORDER_OPT.NEXTVAL INTO v_Ims_Lg_Opt_Id FROM dual;
          
          --IMS接口表
          INSERT INTO IMS_IO_LG_ORDER_OPT
            (IO_OPT_ID,
             OPT_TYPE,
             ORDER_HEAD_ID,
             ORDER_LINE_ID,
             SYS_SOURCE,
             SOURCE_HEAD_ID,
             SOURCE_LINE_ID,
             OPT_QUANTITY,
             DEAL_MONEY,
             DEAL_FLAG,
             CREATED_BY,
             CREATION_DATE)
          SELECT v_Ims_Lg_Opt_Id,
                 '制定发货需求计划下达',
                 s.origin_head_id,
                 s.origin_line_id,
                 'IMS',
                 s.agent_order_id,
                 s.agent_order_line_id,
                 s.carrying_qty,
                 '加锁款项',
                 'N',
                 p_User_Code,
                 SYSDATE
            FROM T_PLN_ORDER_SHARE_SHIPMENT S
           WHERE S.ORDER_SHARE_ID = p_Order_Share_Id;
          
          --调用IMS过程处理
          pkg_pln_intf_ims.p_WriteBack_Ims_Lg_Order(p_Io_Opt_Id => v_Ims_Lg_Opt_Id, p_Result => p_Result);
          IF p_Result <> v_Success THEN
            v_Value := '回写IMS订单信息失败' || v_Nl ||
                       '计划订单号：' || r_Share_Shipment.Origin_Head_Code || v_Nl ||
                       '发货仓库：' || r_Share_Shipment.Inventory_Code_From || v_Nl ||
                       '产品编码：' || r_Share_Shipment.Item_Code || v_Nl ||
                       '代理商订单号：' || r_Share_Shipment.Agent_Order_Number || v_Nl ||
                       '回写代理商订单失败：' || p_Result;
            Raise v_Base_Exception;
          END IF;*/null;
        else
          pkg_pln_lg_order.p_Update_Lg_Order_Direct_Qty(
               In_Lg_Order_Id => r_Share_Shipment.Agent_Order_Id,
               In_Lg_Order_Line_Id => r_Share_Shipment.Agent_Order_Line_Id,
               In_Qty => r_Share_Shipment.Carrying_Qty,
               In_Qty_Sign => 1,
               In_User_Code => p_User_Code,
               Out_Result => p_Result
          );
          
          IF p_Result <> v_Success THEN
            v_Value := '回写CIMS代理商订单失败' || p_Result || v_Nl ||
                       '代理商订单号：' || r_Share_Shipment.Agent_Order_Number || v_Nl ||
                       '计划订单号：' || r_Share_Shipment.Origin_Head_Code || v_Nl ||
                       '发货仓库：' || r_Share_Shipment.Inventory_Code_From || v_Nl ||
                       '产品编码：' || r_Share_Shipment.Item_Code;
            Raise v_Base_Exception;
          end if;
        END IF;
      END IF;
      
      If (p_Result = v_Success) And (r_Share_Shipment.Carrying_Qty > 0) Then
        --获取运输线路和集拼线路
        BEGIN
          SELECT d.district_code, d.district_name
            into v_send_inv_district_code, v_send_inv_district_name
            FROM T_BD_DISTRICT D
           WHERE D.ROW_ID = v_send_inv_district_id;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            v_Value := '根据发货仓库获取发货地点失败，请检查仓库是否维护了区域信息！' || v_Nl ||
                        '发货仓库：' || r_Share_Shipment.Inventory_Code_From;
            Raise v_Base_Exception;
        END;
        
        V_COLLAGE_ENTITY_ID := PKG_LG_COMMON.P_GET_ENTITY_GROUP(r_Share_Shipment.Entity_Id);
        
        BEGIN
          SELECT A.TRANSPORT_LINE_ID,
                 A.TRANSPORT_LINE_CODE,
                 L.ASSEMBLE_LINE_ID,
                 L.ASSEMBLE_LINE_CODE,
                 L.ASSEMBLE_LINE_NAME
            INTO V_TRANSPORT_LINE_ID,
                 V_TRANSPORT_LINE_CODE,
                 V_ASSEMBLE_LINE_ID,
                 V_ASSEMBLE_LINE_CODE,
                 V_ASSEMBLE_LINE_NAME
            FROM TABLE(PKG_PLN_REPORT.F_GET_LG_TRANSPORT_LINE_PROD(v_send_inv_district_code,
                                                                  v_Consignee_Location_Code,
                                                                  r_Share_Shipment.Prescription,
                                                                  V_COLLAGE_ENTITY_ID)) A,
                 T_LG_ASSEMBLE_LINE L
           WHERE A.ENTITY_ID = L.ENTITY_ID
             AND A.ASSEMBLE_LINE = L.ASSEMBLE_LINE_CODE;
        EXCEPTION
          WHEN OTHERS THEN
            IF r_Share_Shipment.Is_Collage = 'Y' THEN
              begin
                select d.district_name
                  into V_Consignee_Location_name
                  from t_bd_district d
                 where d.district_code = v_Consignee_Location_Code;
              exception
                when others then
                  V_Consignee_Location_name := null;
              end;
              v_Value := '根据收发货地点获取运输线路和集拼线路失败，请检查运输线路是否存在或有效（菜单：物流管理-基础数据-运输线路维护），若不存在请联系LMS维护数据！！' || v_Nl ||
                          '发货地点：' || v_send_inv_district_code || ' ' || v_send_inv_district_name || v_Nl ||
                          '收货地点：' || v_Consignee_Location_Code || ' ' || V_Consignee_Location_name || v_Nl ||
                          '运输产品：' || r_Share_Shipment.Prescription || ' ' || r_Share_Shipment.Prescription_Name;
              Raise v_Base_Exception;
            ELSE
              NULL;
            END IF;
        END;
        Declare
          v_Customer_Id_d   Number;
          v_Customer_Code_d Varchar2(40);
          v_Customer_Name_d Varchar2(40);
          v_lg_order_number varchar2(100);
          v_lg_order_head_id number;
          v_lg_order_line_id number;
        Begin
          -- add by zcc 2015-6-18
          --查询提货订单号
          If r_Share_Shipment.Lg_Order_Head_Id Is Not Null And r_Share_Shipment.Lg_Order_Line_Id Is Not Null Then
            select
             h.order_number,
             l.order_line_id,
             l.order_head_id,
             h.customer_channel_type,
             h.source_order_number,
             t.c2m_sign
            into
             v_lg_order_number,
             v_lg_order_line_id,
             v_lg_order_head_id,
             v_customer_channel_type,
             v_Source_Order_Number,
             v_c2m_flag
            from  t_pln_lg_order_head  h ,
                  t_pln_lg_order_line  l,
                  t_Pln_Order_Type t
            where h.order_head_id=l.order_head_id
                  and h.order_head_id=r_Share_Shipment.Lg_Order_Head_Id
                  and l.order_line_id=r_Share_Shipment.Lg_Order_Line_Id
				  and h.order_type_id = t.order_type_id;
          else
            if p_Order_Type = '1008' then --调拨
              begin
                select h.Origin_Order_Number , t.c2m_sign into v_Source_Order_Number, v_c2m_flag
                  from t_pln_lg_relation r, t_pln_lg_order_head h, t_Pln_Order_Type t
                 where r.order_line_id = r_Share_Shipment.Origin_Line_Id
                   and r.order_head_id = r_Share_Shipment.Origin_Head_Id
                   and r.lg_order_head_id = h.order_head_id
                   and h.order_type_id = t.order_type_id;
              exception
                when others then
                  v_Source_Order_Number := null;
              end;
            end if;
          End If;
          
           -- add by jiangwei29 如果为定制订单,带出工单号
             if (v_c2m_flag is not null) then 
               begin
                select wor.wip_entity_code
                   into v_Wip_Entity_Code
                  from  Cims.t_Pln_Wip_Order_Relation Wor
                   where wor.order_line_id = r_Share_Shipment.Origin_Line_Id;
                    exception
                when others then
                  v_Wip_Entity_Code := '';
                end;
              end if;

          --插入运力任务接口表资料！
          Select s_Intf_Lg_Ship_Plan.Nextval
            Into v_Lg_Ship_Pln_Id
            From Dual;
          Insert Into Intf_Lg_Ship_Plan
            (Ship_Plan_Id, --发货计划号
             Entity_Id, --主体ID
             Sales_Main_Type, --营销大类
             Item_Code, --产品编码
             Item_Desc, --产品描述
             Item_Uom, --产品单位
             Item_Qty, --拆分后
             Item_Price, --产品价格
             Customer_Id, --客户ID
             Customer_Code, --客户编码
             Customer_Name, --客户名称
             Account_Code, --账户编码
             Customer_Contacts, --客户联系人
             Customer_Contacts_Phones, --客户联系人电话
             Origin_Origin_Type, --上级来源类型
             Origin_Origin_Order_Code, --上级来源编码
             Origin_Origin_Head_Id, --上级来源单据头ID
             Origin_Origin_Line_Id, --上级来源单据行ID
             Origin_Type, --01：计划订单 02：提货订单 03 ：调拨订单 04：促销品
             Origin_Order_Num, --来源单据号
             Origin_Order_Id, --来源单据头ID
             Origin_Line_Id, --来源单据行ID
             Origin_Ship_Plan_Id, --来源计划ID
             Ship_Way, --运输方式 01：汽运 02：海运 03：铁运 04:空运 05:快递 06 其他
             Ship_Type, --00 工厂发货 01省内发货 02异地调拨 03直发超市
             Load_Vehicle_Type, --装车类型 00整车 01零担
             Ship_Inventory_Id, --通过发货仓库ID
             Consignee_Inventory_Id, --收货仓库ID
             Sales_Order_Type_Id, --销售单据类型ID
             Settlement_Type, --00一般结算、01特批结算、02工程买断结算。
             --Ship_To_Location_Id, --收货地点ID
             Consignee_Location_Code, --收货地点编码
             Consignee_Addr, --收货地址
             Consignee_Company_Id, --收货单位ID
             Consignee_Company_Code, --收货单位编码
             Consignee_Company_Name, --收货单位名称
             Consignee_Company_Addr, --收货单位地址
             Consignee_Company_Contact_Id, --收货单位联系人ID
             Consignee_Company_Contract, --收货单位联系人
             Consignee_Company_Tel, --收货单位联系电话
             Sales_Center_Id, --所在营销中心ID
             Sales_Center_Code, --营销中心编码
             Sales_Center_Name, --所在营销中心名称
             Ship_Info_Date, --生成发货通知单日期
             Require_Ship_Date, --要求发货日期
             Require_Arrive_Date, --要求到货日期
             Pick_Flag, --自提标识 Y：是  N：否
             Is_Cusg_Flag, --是否直发标志
             Transfer_Customer_Id, --直发客户ID
             Transfer_Customer_Code, --直发客户编码
             Transfer_Customer_Name, --直发客户名称
             Base_Allot_Flag, --基地间调拨
             Status, --状态 00：未同步 01：已同步
             Month_Discount_Rate, --月返
             Discount_Rate, --扣率
             Materials_Flag, --是否有物料
             Remark, --备注
             Created_By, --创建人
             Creation_Date, --创建日期
             Last_Updated_By, --最后更新人
             Last_Update_Date, --最后更新时间
             Customer_Order_Number, --客户单号（苏宁、国美）
             Batch_Deal_Num  , --批次处理编号
             PROJECT_ORDER_TYPE	,--批文类型
             PROJECT_ORDER_NUMBER	,--批文号
             PROJECT_ORDER_HEAD_ID,--批文头ID
             PROJECT_ORDER_LINE_ID,--批文行ID
             APPLY_LIST_PRICE,--批文申请价
             APPLY_DISCOUNT_RATE,--申请折扣
             PROJECT_ORDER_FLAG,	 --是否工程机
             ORDER_HEAD_REMARKS,    --订单头备注
             lg_order_number, --提货订单号
             Lock_Amount_Flag,  --锁定金额标志
             Customer_Channel_Type,
             lg_order_review_flag --add by lizhen 2015-11-24 评审类型
             ,agent_order_id --代理商订单ID
             ,agent_order_number --代理商订单号
             ,agent_order_line_id, --代理商订单行ID
             e_platform,   --平台 add by lilh6 2016-8-10
             qt_order --add by lilh6  2016-9-12 齐套号
             ,EXPECT_DATE, --20160914 hejy3 预计到货日期
              source_type  --161124 lilh6    紧急程度
             ,SOURCE_ORDER_NUMBER --20170516 hejy3 上级系统单据号
             ,PROJ_REG_CODE --20170519 hejy3 项目登录号
             ,CCS_PROJ_REG_CODE --20170519 hejy3 项目登录号
             ,customer_order_date --20170619 hejy3 客户订单日期
						 ,SYS_SOURCE_ORDER_NUM --add by lizhen 2017-04-11 CCS单号
             ,Consignment_Date --add by lizhen 2017-04-13 期望到货日期
             ,Discount_Type --add by lizhen 2017-04-17 折扣类型
             ,TRANSFER_SO_BILL_TYPE_ID
             ,TRANSFER_ENTITY_ID
             ,TRANSFER_DISCOUNT_TYPE
             ,TRANSFER_ACCOUNT_ID
             ,TRANSFER_ACCOUNT_CODE
             ,TRANSFER_PRICE_APPLY_TYPE
             ,TRANSFER_PRICE_APPLY_ID
             ,TRANSFER_PRICE_APPLY_CODE
             ,TRANSFER_PRICE_LINE_ID
             ,TRANSFER_LIST_PRICE
             ,TRANSFER_DISCOUNT_RATE
             ,TRANSFER_MONTH_DISCOUNT_RATE
						 ,TRANSFER_ITEM_MAIN_TYPE
             ,TRANSFER_LOCK_AMOUNT_FLAG
						 ,match_number --配比数 add by lizhen 2017-06-08
             ,begin_number  --起订数 add by lizhen 2017-06-08
             ,ITEM_COMPETITE_ATTR --20170727 hejy3 引入产品竞争属性
             ,belong_to_center_id --20170516 划拨中心客户 lilh6
             ,belong_to_center_code
             ,belong_to_center_name
             ,belong_to_customer_id
             ,belong_to_customer_code
             ,belong_to_customer_name
            /* ,Belong_To_Center_Code --add by lizhen 2017-10-16归属中心编码
             ,Belong_To_Center_Name --add by lizhen 2017-10-16归属中心名称*/
             ,ORDER_TYPE_NAME --订单类型名称
               ,CENTER_CHECK_DATE --中心评审时间
               ,PLN_CREATION_DATE 
               ,WAIT_FOR_PREAPPOINT_FLAG  --待预约标志 lilh6 2018-3-22
             ,BOOK_RECEIPT_DATE  --预约收货日期 lilh6 2018-3-22
             ,book_order_num   --预约单号 lilh6 2018-4-26
             ,Book_Num_Cims   --CIMS预约单号 huanghb12 2018-08-14
             ,Book_Type   --CIMS预约单号 huanghb12 2018-09-12
               ,TRANSPORT_LINE_ID --线路ID
               ,TRANSPORT_LINE_CODE --线路编码
               ,ASSEMBLE_LINE_ID --集拼线路ID
               ,ASSEMBLE_LINE_CODE --集拼线路编码
               ,ASSEMBLE_LINE_NAME --集拼线路名称
               ,PRESCRIPTION --运输产品编码
               ,PRESCRIPTION_NAME --运输产品名称
               ,EXPECTED_DATE --送达日期
               ,EFFECTIVE_DATE --时效有效期
               ,IS_COLLAGE --集拼标志
               ,MIN_QUANTITY --最小方量
               ,MAX_QUANTITY --最大方量
               ,TIME_LIMITATION --在途时效
               ,PRESCRIPTION_DISCOUNT --时效产品折扣
               ,CRM_ADDRESS_ID
               ,item_plot_ratio
               ,RESERVATION_COLLECT_BOOK_FLAG
               ,prescription_type
               ,pre_limite
               ,DISTRIBUTION_CENTER_CODE --配送中心编码
               ,DISTRIBUTION_CENTER_NAME --配送中心名称
               ,DISTRIBUTION_WAREHOUSE_CODE  --仓库编码(配送中心)
               ,DISTRIBUTION_WAREHOUSE_NAME  --仓库名称(配送中心)
               ,ORIGIN_VERNDOR_CODE  --供应商编码(外部系统给美的分配的编码)
               ,ORIGIN_VERNDOR_NAME  --供应商名称(外部系统给美的分配的名称)
               ,ORIGIN_SALES_TYPE_CODE  --营销类型编码(外部系统订单单据中产品的营销分类，天猫库容可视接口用到)
               ,ORIGIN_SALES_TYPE_NAME  --营销类型名称(外部系统订单单据中产品的营销分类，天猫库容可视接口用到)
               ,BUS_MOD_TYPE  --订单运作模式(C2M标识) jiangwei29
               ,WIP_ENTITY_CODE  --工单号 jiangwei29
               ,customize_flag
			   ,lg_process_type  --物流处理类型 jiangwei29
             )

            Select v_Lg_Ship_Pln_Id, --发货计划号ID
                   p_Entity_Id, --主体ID
                   --20170517 hejy3 按行营销大类
                   --v_Sales_Main_Type, --营销大类
                   nvl(decode(v_Lg_Order_Review_Flag, v_False, r_Order_Line.Sales_Main_Type, r_Lg_Order_Line.Sales_Main_Type), v_Sales_Main_Type),
                   r_Share_Shipment.Item_Code, --产品编码
                   --20150425 modify by wildwind
                   --'r_Share_Shipment.Item_name' change to 'v_Item_Name'
                   v_Item_Name, --产品描述
                   r_Share_Shipment.Item_Uom, --产品单位
                   r_Share_Shipment.Carrying_Qty, --拆分后
                   v_Price, --产品价格
                   v_Customer_Id, --客户ID    --modi lizhen 2015-01-12 重新取客户表信息
                   v_Customer_Code, --客户编码 --modi lizhen 2015-01-12 重新取客户表信息
                   v_Customer_Name, --客户名称 --modi lizhen 2015-01-12 重新取客户表信息
                   r_Share_Shipment.Account_Code, --账户编码
                   r_Share_Shipment.Invoice_Contract, --客户联系人
                   r_Share_Shipment.Invoice_Tel, --客户联系人电话
                   Decode(v_Lg_Order_Review_Flag, v_True, '02', Null), --Origin_Origin_Type, --上级来源类型 --modi by lizhen 2015-07-16
                   --计划订单转提货标识
                   Decode(v_Lg_Order_Review_Flag, v_True, v_lg_order_number, Null), --Origin_Origin_Order_Code, --上级来源编码
                   Decode(v_Lg_Order_Review_Flag, v_True, v_lg_order_head_id, Null), --Origin_Origin_Head_Id, --上级来源单据头ID
                   Decode(v_Lg_Order_Review_Flag, v_True, v_lg_order_line_id, Null), --Origin_Origin_Line_Id, --上级来源单据行ID
                   '01', --Origin_Type, --01：计划订单 02：提货订单 03 ：调拨订单 04：促销品
                   r_Share_Shipment.Origin_Head_Code, --Origin_Order_Num, --来源单据号
                   r_Share_Shipment.Origin_Head_Id, --Origin_Order_Id, --来源单据头ID
                   r_Share_Shipment.Origin_Line_Id, --Origin_Line_Id, --来源单据行ID
                   r_Share_Shipment.Order_Share_Id, --Origin_Ship_Plan_Id, --来源计划ID
                   r_Share_Shipment.Ship_Mode, --Ship_Way, --运输方式 01：汽运 02：海运 03：铁运 04:空运 05:快递 06 其他
                   Nvl(r_Share_Shipment.Ship_Type, '01'), --Ship_Type, --01 工厂发货 02省内发货 03异地调拨 04直发超市 --modi by lizhen 2015-03-16
                   '01', --Load_Vehicle_Type, --装车类型 01整车 02零担
                   r_Share_Shipment.Inventory_From_Id, --Ship_Inventory_Id, --通过发货仓库ID
                   decode(p_Order_Type, '1008', r_Share_Shipment.Inventory_To_Id, null), --Consignee_Inventory_Id, --收货仓库ID
                   r_Share_Shipment.Sales_Order_Type_Id, --销售单据类型ID
                   '00', --Settlement_Type, --00一般结算、01特批结算、02工程买断结算。
                   --v_Ship_To_Location_Id, --收货地点ID
                   V_Consignee_Location_Code, --Consignee_Location_Code, --收货地点编码
                   r_Share_Shipment.Consignee_Address_Name, -- Consignee_Addr, --收货地址
                   r_Share_Shipment.Consignee_Id, --Consignee_Company_Id, --收货单位ID
                   r_Share_Shipment.Consignee_Code, --Consignee_Company_Code, --收货单位编码
                   r_Share_Shipment.Consignee_Name, --Consignee_Company_Name, --收货单位名称
                   r_Share_Shipment.Consignee_Address_Name, --Consignee_Company_Addr, --收货单位地址
                   r_Share_Shipment.Consignee_Contact_Id, --Consignee_Company_Contact_Id, --收货单位联系人ID
                   r_Share_Shipment.Consignee_Contract, --Consignee_Company_Contract, --收货单位联系人
                   r_Share_Shipment.Consignee_Tel, --Consignee_Company_Tel, --收货单位联系电话
                   v_Sales_Center_Id, --所在营销中心ID
                   v_Sales_Center_Code, --营销中心编码
                   v_Sales_Center_Name, --所在营销中心名称
                   trunc(Sysdate), --Ship_Info_Date, --生成发货通知单日期
                   r_Share_Shipment.Plan_Send_Date, --Require_Ship_Date, --要求发货日期
                   --r_Share_Shipment.Plan_Send_Date, --Require_Arrive_Date, --要求到货日期
                   decode(r_Share_Shipment.Prescription_Type,
                          '1',
                          nvl(r_Share_Shipment.Expected_Date, r_Share_Shipment.Plan_Send_Date),
                          r_Share_Shipment.Plan_Send_Date),
                   --Nvl(r_Share_Shipment.Is_Pick_Flag, v_False), --自提标识 Y：是  N：否
                   nvl(v_client_carry_flag, v_False), --自提标识 Y：是  N：否
                   v_direct_send_now_flag, --是否直发标志
                   r_Share_Shipment.Transfer_Cust_Id, --直发客户ID
                   r_Share_Shipment.Transfer_Cust_code, --直发客户编码
                   r_Share_Shipment.Transfer_Cust_Name, --直发客户名称
                   r_Share_Shipment.Is_Base_Flag, --Base_Allot_Flag, --基地间调拨
                   '00', --Status, --状态 00：未同步 01：已同步
                   v_Month_Discount, --Month_Discount_Rate, --月返
                   v_Discount, --扣率
                   Null, --Materials_Flag, --是否有物料
                   r_Share_Shipment.Remark, --备注
                   p_User_Code, --Created_By, --创建人
                   Sysdate, --Creation_Date, --创建日期
                   p_User_Code, --Last_Updated_By, --最后更新人
                   Sysdate, --Last_Update_Date
                   r_Share_Shipment.Customer_Order_Number, --客户单号
                   p_Lg_Plan_Batch_Id,
                   r_Share_Shipment.Project_Order_Type,--批文类型
                   r_Share_Shipment.Project_Order_Number,--批文号
                   r_Share_Shipment.Price_Apply_Id,--批文头ID
                   r_Share_Shipment.Project_Order_Line_Id,--批文行ID
                   r_Share_Shipment.Apply_List_Price,--批文申请价
                   r_Share_Shipment.Apply_Discount_Rate,--批文申请折扣
                   r_Share_Shipment.Is_Project_Flag,--是否工程机
                   Decode(v_Lg_Order_Review_Flag, v_True, v_order_head_remark, r_Share_Shipment.Remark),   --订单头备注
                   v_lg_order_number,
                   Nvl(r_Share_Shipment.Lock_Amount_Flag, v_Default_Lock_Amount_Flag),  --add by lizhen 2015-07-17 金额锁定标志
                   v_customer_channel_type, --add by zcc 2015-8-3
                   '03' --lg_order_review_flag add by lizhen 2015-11-24 评审类型
                   ,r_Share_Shipment.Agent_Order_Id
                   ,r_Share_Shipment.Agent_Order_Number
                   ,r_Share_Shipment.Agent_Order_Line_Id,
                   r_Lg_Order_Head.e_Platform,  --平台
                   r_Lg_Order_Head.Carload_Meet_Num --add by lilh6  2016-9-12 齐套号
                   ,r_Lg_Order_Head.expected_arrival_date, --20160914 hejy3 预计到货日期
                   r_Lg_Order_Line.Source_Type  --161124 lilh6    紧急程度
                   --,r_Lg_Order_Head.SOURCE_ORDER_NUMBER --20170516 hejy3 上级系统单据号
                   ,v_Source_Order_Number
                   ,r_Lg_Order_Head.PROJ_REG_CODE --20170519 hejy3 项目登录号
                   ,r_Lg_Order_Head.CCS_PROJ_REG_CODE --20170519 hejy3 项目登录号
                   ,r_Share_Shipment.Customer_Order_Date --20170619 hejy3 客户订单日期
									 ,Decode(r_Lg_Order_Head.Sys_Source,  --add by lizhen 2017-04-11 CCS单号SYS_SOURCE_ORDER_NUM
                           'CCS',
                           r_Lg_Order_Head.Source_Order_Number,
                           Decode(r_Lg_Order_Head.Sys_Origin,
                                  'CCS',
                                  r_Lg_Order_Head.Origin_Order_Number,
                                  Null))
                   ,r_Lg_Order_Head.Consignment_Date --add by lizhen 2017-04-13 期望到货日期
                   ,r_Share_Shipment.Discount_Type --add by lizhen 2017-04-17 折扣类型
                   ,r_Share_Shipment.Transfer_So_Bill_Type_Id
                   ,r_Share_Shipment.Transfer_Entity_Id
                   ,r_Share_Shipment.Transfer_Discount_Type
                   ,r_Share_Shipment.Transfer_Account_Id
                   ,r_Share_Shipment.Transfer_Account_Code
                   ,r_Share_Shipment.Transfer_Price_Apply_Type
                   ,r_Share_Shipment.Transfer_Price_Apply_Id
                   ,r_Share_Shipment.Transfer_Price_Apply_Code
                   ,r_Share_Shipment.Transfer_Price_Line_Id
                   ,r_Share_Shipment.Transfer_List_Price
                   ,r_Share_Shipment.Transfer_Discount_Rate
                   ,r_Share_Shipment.Transfer_Month_Discount_Rate
									 ,v_Trsf_Sales_Main_Type
                   --20171030 hejy3 关联代理商订单
                   --,'Y'
                   ,DECODE(r_Share_Shipment.Agent_Order_Number, null, 'Y', 'N')
                   ,r_Lg_Order_Line.Match_Number --配比数 add by lizhen 2017-06-08
                   ,r_Lg_Order_Line.Begin_Number  --起订数 add by lizhen 2017-06-08
                   ,r_Lg_Order_Line.ITEM_COMPETITE_ATTR --20170727 hejy3 引入产品竞争属性
                  ,r_Lg_Order_Head.Belong_To_Center_Id
                  ,r_Lg_Order_Head.Belong_To_Center_Code
                  ,r_Lg_Order_Head.Belong_To_Center_Name
                  ,r_Lg_Order_Head.Belong_To_Customer_Id
                  ,r_Lg_Order_Head.Belong_To_Customer_Code
                  ,r_Lg_Order_Head.Belong_To_Customer_Name
                  /* ,r_Lg_Order_Head.Belong_To_Center_Code --add by lizhen 2017-10-16归属中心编码
                   ,r_Lg_Order_Head.Belong_To_Center_Name --add by lizhen 2017-10-16归属中心名称*/
                   ,Decode(v_Lg_Order_Review_Flag, v_True, r_Lg_Order_Head.Order_Type_Name, r_Order_Head.Order_Type_Name)
                   ,Decode(v_Lg_Order_Review_Flag, v_True, r_Lg_Order_Head.Center_Checkup_Date, r_Order_Head.Center_Check_Date)
                   ,Decode(v_Lg_Order_Review_Flag, v_True, r_Lg_Order_Head.Creation_Date, r_Order_Head.Creation_Date)
                   --,decode(r_lg_order_line.Reservation_Collect_Book_Flag, 'Y', 'Y', r_Lg_Order_Head.wait_for_preappoint_flag)  --待预约标志 lilh6 2018-3-22
                   ,Decode(v_Lg_Order_Review_Flag, v_True, decode(r_lg_order_line.Reservation_Collect_Book_Flag, 'Y', 'Y', r_Lg_Order_Head.wait_for_preappoint_flag), r_Share_Shipment.Preappoint_Flag) --add by houhs 2019-04-29 取预约标识
                   ,r_Lg_Order_Line.book_receipt_date  --预约收货日期 lilh6 2018-3-22
                   ,r_Lg_Order_Line.Book_Request  --预约单号  lilh6 2018-4-26
                   ,r_Lg_Order_Line.Book_Num_Cims  --CIMS预约单号 huanghb12 2018-08-14
                   ,r_Lg_Order_Head.book_type  --CIMS预约单号 huanghb12 2018-09-12
                   ,V_TRANSPORT_LINE_ID --线路ID
                     ,V_TRANSPORT_LINE_CODE --线路编码
                     ,V_ASSEMBLE_LINE_ID --集拼线路ID
                     ,V_ASSEMBLE_LINE_CODE --集拼线路编码
                     ,V_ASSEMBLE_LINE_NAME --集拼线路名称
                     ,r_Share_Shipment.Prescription --运输产品编码
                     ,r_Share_Shipment.Prescription_Name --运输产品名称
                     ,r_Share_Shipment.EXPECTED_DATE --送达日期
                     ,r_Share_Shipment.EFFECTIVE_DATE --时效有效期
                     ,nvl(r_Share_Shipment.IS_COLLAGE,'N') --集拼标志
                     ,r_Share_Shipment.MIN_QUANTITY --最小方量
                     ,r_Share_Shipment.MAX_QUANTITY --最大方量
                     ,r_Share_Shipment.TIME_LIMITATION --在途时效
                     ,r_Share_Shipment.Prescription_Discount --时效产品折扣
                     ,V_CRM_ADDRESS_ID
                     ,r_Share_Shipment.Item_Plot_Ratio
                     ,r_lg_order_line.Reservation_Collect_Book_Flag
                     ,r_Share_Shipment.Prescription_Type
                     ,r_Share_Shipment.pre_limite
                     ,r_Lg_Order_Head.DISTRIBUTION_CENTER_CODE --配送中心编码
                     ,r_Lg_Order_Head.DISTRIBUTION_CENTER_NAME --配送中心名称
                     ,r_Lg_Order_Head.DISTRIBUTION_WAREHOUSE_CODE  --仓库编码(配送中心)
                     ,r_Lg_Order_Head.DISTRIBUTION_WAREHOUSE_NAME  --仓库名称(配送中心)
                     ,r_Lg_Order_Head.ORIGIN_VERNDOR_CODE  --供应商编码(外部系统给美的分配的编码)
                     ,r_Lg_Order_Head.ORIGIN_VERNDOR_NAME  --供应商名称(外部系统给美的分配的名称)
                     ,r_Lg_Order_Head.ORIGIN_SALES_TYPE_CODE  --营销类型编码(外部系统订单单据中产品的营销分类，天猫库容可视接口用到)
                     ,r_Lg_Order_Head.ORIGIN_SALES_TYPE_NAME  --营销类型名称(外部系统订单单据中产品的营销分类，天猫库容可视接口用到)
                     ,v_c2m_flag          --订单运作模式(C2M标识) jiangwei29
                     ,v_Wip_Entity_Code   -- 工单号  jiangwei29
                     ,nvl(r_Lg_Order_Head.Customize_Flag, 'N')
					 ,r_Lg_Order_Head.Lg_Process_Type   --物流处理类型 jiangwei29
              From Dual;
        Exception
          When Others Then
            v_Value := '插入运力任务接口表资料。' || Sqlerrm;
            Raise v_Base_Exception;
        End;
        /*   --modi by lizhen 2015-03-17 运力任务只写接口表，在JAVA后台调公用过方法处理,传批次ID
        If v_Value = v_Success Then
          Pkg_Lg_Ship.p_Lg_Generation_Ship_Plan(v_Lg_Ship_Pln_Id, --接口表ID
                                                p_User_Code, --用户ID
                                                p_Result,
                                                v_Value,
                                                v_lgShip_Doc_id);
          If p_Result <> '1' Then
            v_Value := '生成运力任务计划失败：' || v_Value;
            Raise v_Base_Exception;
          Else
            --发货仓库为A3管理
            If Nvl(v_Docking_System, v_Docking_System_CIMS) = v_Docking_System_A3
              And r_Share_Shipment.Is_Pick_Flag = v_True Then
              --更新当前发货计划行的发货通知单ID
              Update t_Pln_Order_Share_Shipment Oss
                 Set Oss.Pre_Field_04 = To_Char(v_Lgship_Doc_Id)
               Where Oss.Order_Share_Id = r_Share_Shipment.Order_Share_Id;
            Elsif  Nvl(v_Docking_System, v_Docking_System_CIMS) = v_Docking_System_CIMS --发货仓库为CIMS管理
              And r_Share_Shipment.Is_Pick_Flag = v_True Then
              Pkg_Sl.p_Ship_Doc_Allot(In_Ship_Doc_Id  => v_lgShip_Doc_id, --发货通知单ID
                                      Is_User_Account => p_User_Code, --用户账号
                                      Os_Message      => v_Value --成功则返回“OK”，否则返回出错信息
                                      );
              If v_Value != 'OK' Then
                v_Value := '调用Pkg_Sl.p_Ship_Doc_Allot生成分库单失败！' || v_Nl || v_Value;
                Raise v_Base_Exception;
              End If;
            End If;
            v_Value := v_Success;
            p_Result := v_Success;
          End If;
        End If;
        */
      End If;
      /*   --modi by lizhen 2015-03-17 运力任务只写接口表，在JAVA后台调公用过方法处理,传批次ID
      If v_Value = v_Success Then
        --更新订单商品行与商品仓库明细行已下达数量！
        Pkg_Pln_Pub.p_Upd_Pln_Carry_Qty(r_Share_Shipment.Order_Share_Id,
                                        r_Share_Shipment.Carrying_Qty,
                                        1,
                                        p_Entity_Id,
                                        p_User_Code,
                                        v_Value);
        If v_Value <> v_Success Then
          Raise v_Base_Exception;
        End If;
      End If;
	    */
      --MODI BY LIZHEN 2015-01-08
      --检查当前发货计划是否为多主体采购，是否把客户收货地址等切换回订单头表的需求客户
      If r_Share_Shipment.Sales_Center_Id <> v_Sales_Center_Id Then
          Select Count(Cr.Customer_Id)
            Into v_Count
            From t_Pln_Company_Rela Cr
           Where Cr.Customer_Id = r_Share_Shipment.Sales_Center_Id
             And Cr.Rela_Customer_Id = v_Sales_Center_Id
             And Trunc(Sysdate) Between Cr.Begin_Date And
                 Trunc(Nvl(Cr.End_Date, Sysdate));
        If v_Count <= 0 Then
          v_Value := '未找到销售公司间多主体采购关系设置！' || v_Nl ||
            '主销售公司名称：' || r_Share_Shipment.Sales_Center_Name || v_Nl ||
            '关联销售公司名称：' || v_Sales_Center_Name;
          Raise v_Base_Exception;
        Else
          Update t_Pln_Order_Share_Shipment Oss
             Set Oss.Customer_Id            = r_Order_Head.Customer_Id,
                 Oss.Customer_Code          = r_Order_Head.Customer_Code,
                 Oss.Customer_Name          = r_Order_Head.Customer_Name,
                 Oss.Account_Id             = r_Order_Head.Account_Id,
                 Oss.Account_Code           = r_Order_Head.Account_Code,
                 Oss.Account_Name           = r_Order_Head.Account_Name,
                 Oss.Consignee_Id           = r_Order_Head.Consignee_Id,
                 Oss.Consignee_Code         = r_Order_Head.Consignee_Code,
                 Oss.Consignee_Name         = r_Order_Head.Consignee_Name,
                 Oss.Consignee_Address_Name = r_Order_Head.Consignee_Addr,
                 Oss.Incept_Address_Id      = r_Order_Head.Consignment_Addr_Id,
                 Oss.Consignee_Address_Code = r_Order_Head.Consignee_Addr_Code,
                 Oss.Consignee_Contact_Id   = r_Order_Head.Consignee_Contact_Id,
                 Oss.Consignee_Contract     = r_Order_Head.Consignee_Contract,
                 Oss.Consignee_Tel          = r_Order_Head.Consignee_Tel,
                 Oss.Invoice_Contract_Id    = r_Order_Head.Invoice_Contract_Id,
                 Oss.Invoice_Contract       = r_Order_Head.Invoice_Contract,
                 Oss.Invoice_Tel            = r_Order_Head.Invoice_Tel
           Where Oss.Order_Share_Id = r_Share_Shipment.Order_Share_Id;
        End If;
      End If;
      --add by lizhen 2015-01-27 调拨单据类型，下达成功后把单据类型更新为销售，并从订单头更新收货地址
      If p_Order_Type = '1008' Then
        Begin
          Select Uc.Code_Value
            Into v_Bill_Type_Code
            From Up_Codelist Uc, Up_Codelist_Entity Uce, v_So_Bill_Type Sbt
           Where Uc.Codetype = 'PLN_LG_DEFAULT_SO_ORDER_TYPE'
             And Uc.Id = Uce.Codelist_Id
             And Sbt.Entity_Id = Uce.Entity_Id
             And Sbt.Bill_Type_Code = Uc.Code_Value
             And Nvl(Sbt.Promotion_Flay, 'N') = 'N'
             And Uc.Enabled = 0
             And Uce.Entity_Id = p_Entity_Id;
        Exception
          When Others Then
            v_Value := '获取销售单单据类型的CODELIST设置失败，CODELIST编码：PLN_LG_DEFAULT_SO_ORDER_TYPE' || v_Nl ||
                        Sqlerrm;
            Raise v_Base_Exception;
        End;
        Begin
          Select Bt.Bill_Type_Id
            Into v_So_Bill_Type_Id
            From t_Inv_Bill_Types Bt
           Where Bt.Entity_Id = p_Entity_Id
             And v_Bill_Type_Code = Bt.Bill_Type_Code
             And Bt.Cancel_Flag = v_False
             And Rownum <= 1;
        Exception
          When Others Then
            v_So_Bill_Type_Id := Null;
            v_Value := '查找销售单据类型失败，销售单据类型编码：' || v_Bill_Type_Code || v_Nl || Sqlerrm;
            Raise v_Base_Exception;
        End;
        Update t_Pln_Order_Share_Shipment Oss
           Set Oss.Consignee_Id           = Null,
               Oss.Consignee_Code         = oss.customer_code,
               Oss.Consignee_Name         = oss.customer_name,
               Oss.Consignee_Address_Name = Null,
               Oss.Incept_Address_Id      = Null,
               Oss.Consignee_Address_Code = Null,
               Oss.Consignee_Contact_Id   = Null,
               Oss.Consignee_Contract     = Null,
               Oss.Consignee_Tel          = Null,
               Oss.Invoice_Contract_Id    = r_Order_Head.Invoice_Contract_Id,
               Oss.Invoice_Contract       = r_Order_Head.Invoice_Contract,
               Oss.Invoice_Tel            = r_Order_Head.Invoice_Tel,
               Oss.Sales_Order_Type_Id    = v_So_Bill_Type_Id,
               Oss.Inventory_To_Id        = Null,
               Oss.Rcv_Inv_Code           = Null,
               Oss.Rcv_Inv_Name           = Null
         Where Oss.Order_Share_Id = r_Share_Shipment.Order_Share_Id;
      End If;
      --add by lizhen 2015-01-27 下达完后折扣率清为0
      Update t_Pln_Order_Share_Shipment Oss
         Set Oss.Discount_Rate = 0
       Where Oss.Order_Share_Id = r_Share_Shipment.Order_Share_Id;
      
      --20160618 hejy3 下达完后更新代理商订单信息
      UPDATE T_PLN_ORDER_SHARE_SHIPMENT S
         SET S.AGENT_ORDER_ID = NULL, S.AGENT_ORDER_NUMBER = NULL, S.AGENT_ORDER_LINE_ID = NULL
       WHERE S.ORDER_SHARE_ID = p_Order_Share_Id;

      -- add by zcc 如果不是提货又存在批文 需要锁定批文信息
      If r_Share_Shipment.Lg_Order_Head_Id Is  Null And
         r_Share_Shipment.Lg_Order_Line_Id Is  Null
         then
           -- 存在批文信息
            if r_Share_Shipment.Project_Order_Line_Id is not null And
               r_Share_Shipment.Price_Apply_Id is not null
             then
              --成功的数据锁定批文量add by zcc
             pkg_bd_price.P_APPLY_LOCK(
              r_Share_Shipment.Project_Order_Line_Id, --批文明细ID
              r_Share_Shipment.Carrying_Qty       , --锁定数量
              r_Share_Shipment.Origin_Head_Code  ,-- 关联单号
              v_return_code    , --返回编码，1成功，0失败
              p_Result      --返回提示信息
             );
             if v_return_code=1 then
             --更新t_Pln_Order_Share_Shipment批文信息
               p_Result :=v_Success;
               v_Value :=v_Success;
               Update t_Pln_Order_Share_Shipment Oss
               Set Oss.Discount_Rate = 0,
               Oss.Project_Order_Type     =null,
               Oss.Project_Order_Number   =null,
               Oss.Project_Order_Line_Id  =null,
               Oss.Price_Apply_Id         =null,
               Oss.Apply_List_Price       =null,
               Oss.Apply_Discount_Rate    =null,
               Oss.Ordered_Discount_Rate  =Null
               Where Oss.Order_Share_Id = r_Share_Shipment.Order_Share_Id;
               end if ;
             end if ;
      end if ;
      --add by lizhen 2015-02-13 发货计划行恢复成原始数据
      If v_Lg_Order_Review_Flag = v_True Then
        Update t_Pln_Order_Share_Shipment Oss
           Set Oss.Customer_Id            = r_Back_Share_Ship.Customer_Id,
               Oss.Customer_Code          = r_Back_Share_Ship.Customer_Code,
               Oss.Customer_Name          = r_Back_Share_Ship.Customer_Name,
               Oss.Invoice_Contract_Id    = r_Back_Share_Ship.Invoice_Contract_Id,
               Oss.Invoice_Contract       = r_Back_Share_Ship.Invoice_Contract,
               Oss.Invoice_Tel            = r_Back_Share_Ship.Invoice_Tel,
               Oss.Account_Id             = r_Back_Share_Ship.Account_Id,
               Oss.Account_Code           = r_Back_Share_Ship.Account_Code,
               Oss.Account_Name           = r_Back_Share_Ship.Account_Name,
               Oss.Consignee_Id           = r_Back_Share_Ship.Consignee_Id,
               Oss.Consignee_Code         = r_Back_Share_Ship.Consignee_Code,
               Oss.Consignee_Name         = r_Back_Share_Ship.Consignee_Name,
               Oss.Consignee_Address_Name = r_Back_Share_Ship.Consignee_Address_Name,
               Oss.Consignee_Extend_Addr  = r_Back_Share_Ship.Consignee_Extend_Addr,
               Oss.Incept_Address_Id      = r_Back_Share_Ship.Incept_Address_Id,
               Oss.Consignee_Address_Code = r_Back_Share_Ship.Consignee_Address_Code,
               Oss.Consignee_Contact_Id   = r_Back_Share_Ship.Consignee_Contact_Id,
               Oss.Consignee_Contract     = r_Back_Share_Ship.Consignee_Contract,
               Oss.Consignee_Tel          = r_Back_Share_Ship.Consignee_Tel,
               Oss.Is_Cusg_Flag           = r_Back_Share_Ship.Is_Cusg_Flag,
               Oss.Is_Pick_Flag           = r_Back_Share_Ship.Is_Pick_Flag,
               Oss.Discount_Rate          = r_Back_Share_Ship.Discount_Rate,
               Oss.Plan_Send_Date         = Null,
               Oss.Ship_Type              = r_Back_Share_Ship.Ship_Type,
               Oss.Project_Order_Type     =null,
               Oss.Project_Order_Number   =null,
               Oss.Project_Order_Line_Id  =null,
               Oss.Price_Apply_Id         =null,
               Oss.Apply_List_Price       =null,
               Oss.Apply_Discount_Rate    =null,
               oss.ordered_discount_rate  =Null,
               oss.prescription           = Null,
               oss.Prescription_Name      = Null,
               oss.expected_date          = Null,
               oss.effective_date         = Null,
               oss.is_collage             = Null,
               oss.min_quantity           = Null,
               oss.max_quantity           = Null,
               oss.time_limitation        = Null,
               oss.prescription_discount  = Null,
               Oss.Ship_Mode = '01', --add by lizhen 2016-02-23
               Oss.Lock_Amount_Flag = r_Back_Share_Ship.Lock_Amount_Flag --add by lizhen 2016-03-03
               ,Oss.Discount_Type = r_Back_Share_Ship.Discount_Type  --add by lizhen 2017-04-17
               ,Oss.Customer_Order_Number = r_Back_Share_Ship.Customer_Order_Number -- add by lizhen 2017-05-31
         Where Oss.Order_Share_Id = p_Order_Share_Id;

        --add by lizhen 2015-07-15 TN模式的更新营销中心信息
        --If v_Pln_Is_Merge_Lg_Order In ('TN_SUM', 'TN_SINGLE') Then
        Update t_Pln_Order_Share_Shipment Oss
           Set Oss.Sales_Center_Id   = r_Back_Share_Ship.Sales_Center_Id,
               Oss.Sales_Center_Code = r_Back_Share_Ship.Sales_Center_Code,
               Oss.Sales_Center_Name = r_Back_Share_Ship.Sales_Center_Name
         Where Oss.Order_Share_Id = p_Order_Share_Id;
        --End If;
      End If;
      
      Update t_Pln_Order_Share_Shipment Oss
         Set Oss.Lg_Order_Head_Id = null,
             Oss.Lg_Order_Line_Id = null,
             Oss.Carrying_Qty     = null,
             oss.prescription = null,
             oss.prescription_name = null,
             oss.expected_date = null,
             oss.effective_date = null,
             oss.is_collage = null,
             oss.min_quantity = null,
             oss.max_quantity = null,
             oss.time_limitation = null,
             oss.prescription_discount = null,
             oss.prescription_type = null,
             oss.pre_limite = null
       Where Oss.Order_Share_Id = p_Order_Share_Id;
    End Loop;
    Close c_Share_Shipment;

    If v_Value <> v_Success Then
      Rollback;
      p_Result := v_Value;
    End If;
  Exception
    When v_Base_Exception Then
      Rollback;
      p_Result := v_Value;
    When Others Then
      p_Result := '失败：' || v_Value || Sqlerrm;
      Rollback;
  End;

  -----------------------------------------------------------------------------------------
  --Author: Nicro.Li
  --Purpose: 计划订单发货计划下达到物流运力计划
  -----------------------------------------------------------------------------------------
  Procedure p_Share_To_Lgshipplan_All(p_Entity_Id        In Number, --主主体ID,
                                      p_Order_Shares     In Varchar2, --发货计划ID列表
                                      p_User_Code        In Varchar2, --用户编码
                                      p_Result           In Out Varchar2, --成功返回“SUCCESS”
                                      p_Msg              In Out Varchar2,
                                      p_Lg_Plan_Batch_Id Out Number --物流批次ID
                                      ) Is
    v_Value Varchar2(2000);
    Type c_Get_Shares Is Ref Cursor; --声明动态游标
    v_Get_Shares c_Get_Shares;
    r_Get_Shares t_Pln_Order_Share_Shipment%Rowtype;

    v_Err_Count          Number := 0;
    v_Success_Count      Number := 0;
    v_source_type_id     Number;
    v_Source_Type_Code   Varchar2(100);
    v_Lg_Plan_Batch_Id   Number;
    v_return_code        Number;
  Begin
    p_Result := v_Success;
    --ADD BY LIZHEN 2015-03-17 获取批次ID
    Select s_Intf_Lg_Batch_Num.Nextval Into v_Lg_Plan_Batch_Id From Dual;
    If p_Result = v_Success Then
      Begin
        Open v_Get_Shares For 'Select Oss.*
                                From t_Pln_Order_Share_Shipment Oss,
                                     t_Pln_Order_Head  Poh,
                                     t_Pln_Order_Line  Pol,
                                     t_Pln_Order_Type  Pot
                               Where Oss.Origin_Head_Id = Poh.Order_Head_Id
                                 And Pol.Order_Head_Id = Poh.Order_Head_Id
                                 And Pol.Order_Line_Id = Oss.Origin_Line_Id
                                 And Pot.Order_Type_Id = Poh.Order_Type_Id
                                 And Pot.Entity_Id = Poh.Entity_Id
                                 And Oss.Order_Share_Id In (' || p_Order_Shares || ')
                               Order By poh.Period_Id,
                                        Pot.Storage_Priority,
                                        poh.Refer_Date,
                                        POL.Can_Produce_Qty
                                   ';/*For Update Nowait*/
      Exception
        When Others Then
          p_Result := '查询订单发货计划失败，发货计划ID：' || p_Order_Shares || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
      End;

      Loop
        Fetch v_Get_Shares
          Into r_Get_Shares;
        If v_Get_Shares%Rowcount = 0 Then
          p_Result := '查询订单发货计划失败，未找到需下达的数据，发货计划ID：' || p_Order_Shares;
          Raise v_Base_Exception;
        End If;
        Exit When v_Get_Shares%Notfound;
        Begin
          Select st.source_type_code
            Into v_Source_Type_Code
            From t_Inv_Bill_Types t,t_inv_source_types st
           Where t.Bill_Type_Id = r_Get_Shares.Sales_Order_Type_Id
             And st.source_type_id = t.source_type_id
             And t.Entity_Id = p_Entity_Id;
        Exception
          When Others Then
            p_Result := '业务单据类型不存在，单据类型ID:' || To_Char(r_Get_Shares.Sales_Order_Type_Id) ||
              Sqlerrm;
            Raise v_Base_Exception;
        End;

        --生成物流运力计划
        If p_Result = v_Success Then
          p_Share_To_Lgshipplan(p_Entity_Id, --主主体ID,
                                r_Get_Shares.Order_Share_Id, --订单发货计划ID
                                v_Source_Type_Code, --运力任务单据下达类型 1006:销售  1008：调拨
                                p_User_Code, --用户编码
                                v_Lg_Plan_Batch_Id, --物流运力批次ID
                                v_Value,
                                p_Msg);
          If v_Value <> v_Success Then
            --Rollback; --回滚错误数据，更新错误信息
            v_Err_Count := v_Err_Count + 1;
            Update t_Pln_Order_Share_Shipment Oss
               Set Oss.Carry_Error_Msg = Substr(v_Value, 1, 500),
                   Oss.Carrying_Qty    = Oss.Share_Qty -
                                         Nvl(Oss.Carry_Qty, 0),
                   oss.pre_field_04 = Null,
                   Oss.Version = Nvl(Oss.Version, 0) + 1
             Where Oss.Order_Share_Id = r_Get_Shares.Order_Share_Id;
            p_Result := v_Value;
            --Commit;
          Else
               v_Success_Count := v_Success_Count + 1;
            Update t_Pln_Order_Share_Shipment Oss
               Set Oss.Carry_Error_Msg = Null,
               Oss.Version = Nvl(Oss.Version, 0) + 1
             Where Oss.Order_Share_Id = r_Get_Shares.Order_Share_Id;
            --Commit; --成功的数据做COMMIT
          End If;
        Else
          Exit;
        End If;
      End Loop;
      Close v_Get_Shares;
    End If;

    p_Msg := '下达物流发货计划资料：成功(' || To_Char(v_Success_Count) || '笔)，失败(' ||
             To_Char(v_Err_Count) || '笔)！';
    p_Lg_Plan_Batch_Id := v_Lg_Plan_Batch_Id;
  Exception
    When v_Base_Exception Then
      Rollback;
      p_Result := p_Result;
      p_Msg := '下达物流发货计划资料：成功(' || To_Char(v_Success_Count) || '笔)，失败(' ||
             To_Char(v_Err_Count) || '笔)！';
      p_Lg_Plan_Batch_Id := -1;
    When Others Then
      p_Result := p_Result || v_Nl || Sqlerrm;
      p_Msg := '下达物流发货计划资料：成功(' || To_Char(v_Success_Count) || '笔)，失败(' ||
             To_Char(v_Err_Count) || '笔)！';
      p_Lg_Plan_Batch_Id := -1;
  End;

  -----------------------------------------------------------------------------------------
  --Author: Nicro.Li
  --Purpose: 计划订单特殊占用释放库存  检查是否需要更新订单发货需求计划数量
  --该过程作废，不再使用代码注释
  -----------------------------------------------------------------------------------------
  Procedure p_Special_Upd_Share(p_Order_Line_Id In Number, --计划订单行ID
                                p_Inventory_Id  In Number, --发货仓库
                                p_Execute_Qty   In Number, --特殊占用释放数量
                                p_Entity_Id     In Number, --主体ID
                                p_User_Code     In Varchar2, --用户编码
                                p_Result        In Out Varchar2 --成功返回“SUCCESS”
                                ) Is
    Cursor c_Order_Line Is
      Select Poh.Order_Head_Id,
             Poh.Order_Number,
             Poh.Order_Type_Id,
             Poh.Order_Type_Name,
             Pol.Order_Line_Id,
             Pol.Item_Id,
             Pol.Item_Code,
             Pol.Item_Desc,
             --已分配未下达，不做破损调拨
             Nvl((Select Sum(Nvl(Oss.Share_Qty, 0))
                   From t_Pln_Order_Share_Shipment Oss
                  Where Oss.Origin_Head_Id = Poh.Order_Head_Id
                    And Oss.Origin_Line_Id = Pol.Order_Line_Id
                    And Oss.Inventory_From_Id = p_Inventory_Id
                    And Nvl(Oss.Inv_Share_Flag, 'N') = 'N'),
                 0) Share_Qty,
             --库存评审数量，不参与计算破损调拨
             Nvl((Select Sum((Nvl(Oss.Share_Qty, 0) -
                            Nvl(Oss.So_Order_Qty, 0)))
                   From t_Pln_Order_Share_Shipment Oss
                  Where Oss.Origin_Head_Id = Poh.Order_Head_Id
                    And Oss.Origin_Line_Id = Pol.Order_Line_Id
                    And Oss.Inventory_From_Id = p_Inventory_Id
                    And Nvl(Oss.Inv_Share_Flag, 'N') = 'Y'),
                 0) Affirm_Share_Qty
        From t_Pln_Order_Head Poh, t_Pln_Order_Line Pol
       Where Poh.Order_Head_Id = Pol.Order_Head_Id
         And Pol.Order_Line_Id = p_Order_Line_Id
         And Poh.Entity_Id = p_Entity_Id
            --单据类型必须是占用库存
         And Exists
       (Select 1
                From t_Pln_Order_Type Pot
               Where Pot.Order_Type_Id = Poh.Order_Type_Id
                 And Nvl(Pot.Is_Lock_Inv_Flag, 'N') = 'Y')
         For Update Nowait;
    r_Order_Line c_Order_Line%Rowtype;

    v_Value             Varchar2(2000);
    v_Pln_Wip_Ord_Match Varchar2(3);
    v_Item_Occupy_Qty   Number;
    v_Usable_Share_Qty  Number;
  Begin
    p_Result            := 'p_Special_Upd_Share过程已作废';
    /*v_Pln_Wip_Ord_Match := Pkg_Bd.f_Get_Parameter_Value('PLN_WIP_ORD_MATCH',
                                                        p_Entity_Id);
    Begin
      Open c_Order_Line;
    Exception
      When Others Then
        v_Value := '打开订单行数据失败';
        Raise v_Base_Exception;
    End;
    Fetch c_Order_Line
      Into r_Order_Line;
    If c_Order_Line%Notfound Then
      Return;
    End If;
    --取订单行产品占用数量
    v_Item_Occupy_Qty := Pkg_Pln_Inv_Occupy.f_Item_Ass_Occupy_Qty(p_Inventory_Id     => p_Inventory_Id,
                                                                  p_Item_Id          => r_Order_Line.Item_Id,
                                                                  p_Match_Pln_To_Wip => v_Pln_Wip_Ord_Match,
                                                                  p_Entity_Id        => p_Entity_Id,
                                                                  p_Origin_Line_Id   => p_Order_Line_Id);
    --获取本次可以更新发货计划行的数量
    If Nvl(v_Item_Occupy_Qty, 0) > Nvl(r_Order_Line.Share_Qty, 0) +
       Nvl(r_Order_Line.Affirm_Share_Qty, 0) Then
      v_Usable_Share_Qty := Least(Nvl(v_Item_Occupy_Qty, 0) -
                                  Nvl(r_Order_Line.Share_Qty, 0) -
                                  Nvl(r_Order_Line.Affirm_Share_Qty, 0),
                                  Nvl(p_Execute_Qty, 0));
    End If;
    If Nvl(v_Usable_Share_Qty, 0) > 0 Then
      p_Auto_Create_Share(p_Pln_Order_Line_Id => p_Order_Line_Id,
                          p_Inventory_Id      => p_Inventory_Id,
                          p_Trans_Sign_Flag   => -1,
                          p_Trans_Share_Qty   => v_Usable_Share_Qty,
                          p_Entity_Id         => p_Entity_Id,
                          p_Pln_Wip_Ord_Match => v_Pln_Wip_Ord_Match,
                          p_User_Code         => p_User_Code,
                          p_Result            => v_Value);
      If v_Value <> v_Success Then
        v_Value := '更新发货计划行分配数量失败，' || v_Value;
        Raise v_Base_Exception;
      End If;
    End If;*/
  Exception
    When v_Base_Exception Then
      p_Result := '更新发货计划行数据失败：' || v_Nl || v_Value;
      Rollback;
    When Others Then
      p_Result := '更新发货计划行数据失败：' || v_Nl || v_Value || Sqlerrm;
      Rollback;
  End;

  -----------------------------------------------------------------------------------------
  --Author: Nicro.Li
  --Purpose: 计划订单特殊占用、释放库存  特殊占用含：破损调拨、采购退货、库存盘点
  -----------------------------------------------------------------------------------------
  Procedure p_Execute_Special_Occupy(p_Entity_Id               In Number, --主体ID,
                                     p_Item_Id                 In Number, --产品ID
                                     p_Inventory_Id            In Number, --仓库ID
                                     p_Execute_Qty             In Varchar2, --特殊占用执行数量
                                     p_Special_type            In Varchar2, --类型: 41:破损调拨、42:盘盈亏、43:采购退货
                                     p_Special_Order_Type_Name In Varchar2, --单据类型名称
                                     p_Special_Order_Head_id   In Number,   --单据头ID
                                     p_Special_Order_Number    In Varchar2, --单据单号
                                     p_Special_Order_Line_id   In Varchar2, --单据行ID
                                     p_User_Code               In Varchar2, --用户编码
                                     p_Result                  In Out Varchar2 --成功返回“SUCCESS”
                                     ) Is
    Cursor c_Pln_Order Is
      Select Pln.*,
       --优先匹配中转入库的订单数据
       Case
         When (Pln.Item_Occupy_Qty - Pln.Not_So_Order_Qty -
              Pln.Affirm_Share_Qty) > 0 Then
          Decode(Sign(pln.can_unlock_affirm_qty), 1, 2, 1)
         Else
          3
       End Inv_Affirm_Flag
        From (Select Poh.Order_Head_Id,
                     Poh.Order_Number,
                     Poh.Order_Type_Id,
                     Pol.Order_Line_Id,
                     Pol.Item_Id         Ass_Item_Id,
                     Pol.Item_Code       Ass_Item_Code,
                     Pol.Item_Desc       Ass_Item_Desc,
                     Oio.Item_Id         Sub_Item_Id,
                     Tbi.Item_Code       Sub_Item_Code,
                     Tbi.Item_Name       Sub_Item_Desc,
                     Pot.Storage_Priority,  --add by lizhen 2016-09-27
                     --获取最后入库日期
                     Nvl((Select Max(Pld.Executed_Date)
                        From t_Inv_Po_Wip_Detail Pld
                       Where Pld.Order_Header_Id = Poh.Order_Head_Id
                         And Pld.Order_Line_Id = Oio.Origin_Line_Id
                         And Pld.Item_Id = Oio.Item_Id), Trunc(Sysdate - 90)) Max_Supply_Date,
                     --库存占用数量
                     Nvl(Oio.Stock_Affirm_Qty, 0) +
                     Nvl(Oio.Supply_Qty, 0) -
                     Nvl(Oio.So_Order_Qty, 0) -
                     Nvl(Oio.Sundry_Qty, 0) -
                     --modi by lizhen 2015-04-09 库存占用量扣减已发货确认未执行的中转红冲单
                     pkg_pln_inv_occupy.f_Get_Item_Read_Wip_Qty(p_Inventory_Id => Oio.Inventory_Id,
                                                                p_Sub_Item_Id => Oio.Item_Id,
                                                                p_Entity_Id => Oio.Entity_Id,
                                                                p_Order_Line_Id => Oio.Origin_Line_Id)
                     Item_Occupy_Qty,
                     --已下达未发货，不做破损调拨
                     Nvl((Select Sum((Nvl(Oss.Carry_Qty, 0) -
                                    Nvl(Oss.So_Order_Qty, 0)) *
                                    Pkg_Pln_Pub.f_Get_Item_Assembly_Base(Pol.Item_Id,
                                                                         Oio.Item_Id))
                           From t_Pln_Order_Share_Shipment Oss
                          Where Oss.Origin_Head_Id = Poh.Order_Head_Id
                            And Oss.Origin_Line_Id = Pol.Order_Line_Id
                            And Oss.Inventory_From_Id = Oio.Inventory_Id
                            And Nvl(Oss.Inv_Share_Flag, 'N') = 'N'),
                         0) Not_So_Order_Qty,
                     --库存评审数量，不参与计算破损调拨
                     Nvl((Select Sum((Nvl(Oss.Share_Qty, 0) -
                                    Nvl(Oss.So_Order_Qty, 0)) *
                                    Pkg_Pln_Pub.f_Get_Item_Assembly_Base(Pol.Item_Id,
                                                                         Oio.Item_Id))
                           From t_Pln_Order_Share_Shipment Oss
                          Where Oss.Origin_Head_Id = Poh.Order_Head_Id
                            And Oss.Origin_Line_Id = Pol.Order_Line_Id
                            And Oss.Inventory_From_Id = Oio.Inventory_Id
                            And Nvl(Oss.Inv_Share_Flag, 'N') = 'Y'),
                         0) Affirm_Share_Qty,
                      --库存评审数量，可用于破损调拨数量
                      Nvl((Select Sum((Nvl(Oss.Share_Qty, 0) -
                                    Nvl(Oss.Carry_Qty, 0)) *
                                    Pkg_Pln_Pub.f_Get_Item_Assembly_Base(Pol.Item_Id,
                                                                         Oio.Item_Id))
                           From t_Pln_Order_Share_Shipment Oss
                          Where Oss.Origin_Head_Id = Poh.Order_Head_Id
                            And Oss.Origin_Line_Id = Pol.Order_Line_Id
                            And Oss.Inventory_From_Id = Oio.Inventory_Id
                            And Nvl(Oss.Inv_Share_Flag, 'N') = 'Y'),
                         0) Can_UnLock_Affirm_Qty
                From t_Pln_Order_Head   Poh,
                     t_Pln_Order_Line   Pol,
                     t_pln_order_period Pop,
                     t_Pln_Order_Inv_Occupy Oio,
                     t_Bd_Item  Tbi,
                     t_Pln_Order_Type       Pot   --add by lizhen 2016-09-27
               Where Poh.Order_Head_Id = Pol.Order_Head_Id
                 And Poh.Order_Head_Id = Oio.Origin_Head_Id
                 And Pol.Order_Line_Id = Oio.Origin_Line_Id
                 And Pop.Period_Id = Poh.Period_Id
                 And Pop.Entity_Id = Poh.Entity_Id
                 And Pop.Period_Type IN ('周', 'T+3周期')
                 And Tbi.Item_Id       = Oio.Item_Id
                 And Oio.Item_Id       = p_Item_id
                 And Oio.Inventory_Id  = p_Inventory_Id
                 And Pot.Order_Type_Id = Poh.Order_Type_Id --add by lizhen 2016-09-27
                 AND poh.form_state IN (32, 306) --20160713 hejy3 已排产、评审完毕才参与特殊占用
                 --MODI BY LIZHEN 2015-01-13 库存评审数量参与破损调拨
                 /*And Exists
               (Select 1
                        From t_Inv_Po_Wip_Detail Pld
                       Where Pld.Order_Header_Id = Poh.Order_Head_Id
                         And Pld.Order_Line_Id = Oio.Order_Line_Id
                         And Pld.Order_Detail_Id = Oio.Order_Detail_Id
                         And Pld.Item_Id = Oio.Item_Id)*/
                    --单据类型必须是占用库存
                 And Exists
               (Select 1
                        From t_Pln_Order_Type Pot
                       Where Pot.Order_Type_Id = Poh.Order_Type_Id
                         And Nvl(Pot.Is_Lock_Inv_Flag, 'N') = 'Y')
                 And Nvl(Oio.Stock_Affirm_Qty, 0) +
                     Nvl(Oio.Supply_Qty, 0) -
                     Nvl(Oio.So_Order_Qty, 0) -
                     Nvl(Oio.Sundry_Qty, 0) > 0) Pln
         Where (Pln.Item_Occupy_Qty - Pln.Not_So_Order_Qty - Pln.Affirm_Share_Qty) > 0
               Or Pln.Can_Unlock_Affirm_Qty > 0
       Order By Storage_Priority Desc, --add by lizhen 2016-09-27
         Max_Supply_Date Desc, Inv_Affirm_Flag, Can_Unlock_Affirm_Qty Desc;
    r_Pln_Order            c_Pln_Order%Rowtype;

    Cursor c_Order_Single(p_Order_Line_Id Number) Is
      Select Pln.*,
       --优先匹配中转入库的订单数据
       Case
         When (Pln.Item_Occupy_Qty - Pln.Not_So_Order_Qty -
              Pln.Affirm_Share_Qty) > 0 Then
          Decode(Sign(pln.can_unlock_affirm_qty), 1, 2, 1)
         Else
          3
       End Inv_Affirm_Flag
        From (Select Poh.Order_Head_Id,
                     Poh.Order_Number,
                     Poh.Order_Type_Id,
                     Pol.Order_Line_Id,
                     Pol.Item_Id         Ass_Item_Id,
                     Pol.Item_Code       Ass_Item_Code,
                     Pol.Item_Desc       Ass_Item_Desc,
                     Oio.Item_Id         Sub_Item_Id,
                     Tbi.Item_Code       Sub_Item_Code,
                     Tbi.Item_Name       Sub_Item_Desc,
                     Pot.Storage_Priority, --add by lizhen 2016-09-27
                     --获取最后入库日期
                     Nvl((Select Max(Pld.Executed_Date)
                        From t_Inv_Po_Wip_Detail Pld
                       Where Pld.Order_Header_Id = Poh.Order_Head_Id
                         And Pld.Order_Line_Id = Oio.Origin_Line_Id
                         And Pld.Item_Id = Oio.Item_Id), Trunc(Sysdate - 90)) Max_Supply_Date,
                     --库存占用数量
                     Nvl(Oio.Stock_Affirm_Qty, 0) +
                     Nvl(Oio.Supply_Qty, 0) -
                     Nvl(Oio.So_Order_Qty, 0) -
                     Nvl(Oio.Sundry_Qty, 0) -
                     --modi by lizhen 2015-04-09 库存占用量扣减已发货确认未执行的中转红冲单
                     pkg_pln_inv_occupy.f_Get_Item_Read_Wip_Qty(p_Inventory_Id => Oio.Inventory_Id,
                                                                p_Sub_Item_Id => Oio.Item_Id,
                                                                p_Entity_Id => Oio.Entity_Id,
                                                                p_Order_Line_Id => Oio.Origin_Line_Id)
                     Item_Occupy_Qty,
                     --已下达未发货，不做破损调拨
                     Nvl((Select Sum((Nvl(Oss.Carry_Qty, 0) -
                                    Nvl(Oss.So_Order_Qty, 0)) *
                                    Pkg_Pln_Pub.f_Get_Item_Assembly_Base(Pol.Item_Id,
                                                                         Oio.Item_Id))
                           From t_Pln_Order_Share_Shipment Oss
                          Where Oss.Origin_Head_Id = Poh.Order_Head_Id
                            And Oss.Origin_Line_Id = Pol.Order_Line_Id
                            And Oss.Inventory_From_Id = Oio.Inventory_Id
                            And Nvl(Oss.Inv_Share_Flag, 'N') = 'N'),
                         0) Not_So_Order_Qty,
                     --库存评审数量，不参与计算破损调拨
                     Nvl((Select Sum((Nvl(Oss.Share_Qty, 0) -
                                    Nvl(Oss.So_Order_Qty, 0)) *
                                    Pkg_Pln_Pub.f_Get_Item_Assembly_Base(Pol.Item_Id,
                                                                         Oio.Item_Id))
                           From t_Pln_Order_Share_Shipment Oss
                          Where Oss.Origin_Head_Id = Poh.Order_Head_Id
                            And Oss.Origin_Line_Id = Pol.Order_Line_Id
                            And Oss.Inventory_From_Id = Oio.Inventory_Id
                            And Nvl(Oss.Inv_Share_Flag, 'N') = 'Y'),
                         0) Affirm_Share_Qty,
                      --库存评审数量，可用于破损调拨数量
                      Nvl((Select Sum((Nvl(Oss.Share_Qty, 0) -
                                    Nvl(Oss.Carry_Qty, 0)) *
                                    Pkg_Pln_Pub.f_Get_Item_Assembly_Base(Pol.Item_Id,
                                                                         Oio.Item_Id))
                           From t_Pln_Order_Share_Shipment Oss
                          Where Oss.Origin_Head_Id = Poh.Order_Head_Id
                            And Oss.Origin_Line_Id = Pol.Order_Line_Id
                            And Oss.Inventory_From_Id = Oio.Inventory_Id
                            And Nvl(Oss.Inv_Share_Flag, 'N') = 'Y'),
                         0) Can_UnLock_Affirm_Qty
                From t_Pln_Order_Head   Poh,
                     t_Pln_Order_Line   Pol,
                     t_Pln_Order_Inv_Occupy Oio,
                     t_Bd_Item  Tbi,
                     t_Pln_Order_Type       Pot --add by lizhen 2016-09-27
               Where Poh.Order_Head_Id = Pol.Order_Head_Id
                 And Poh.Order_Head_Id = Oio.Origin_Head_Id
                 And Pol.Order_Line_Id = Oio.Origin_Line_Id
                 And Tbi.Item_Id       = Oio.Item_Id
                 And Oio.Item_Id       = p_Item_id
                 And Oio.Inventory_Id  = p_Inventory_Id
                 And Pol.Order_Line_Id = p_Order_Line_id
                 And Pot.Order_Type_Id = Poh.Order_Type_Id  --add by lizhen 2016-09-27
                 AND poh.form_state IN (32, 306) --20160713 hejy3 已排产、评审完毕才参与特殊占用
                 --MODI BY LIZHEN 2015-01-13 库存评审数量参与破损调拨
                 /*And Exists
               (Select 1
                        From t_Inv_Po_Wip_Detail Pld
                       Where Pld.Order_Header_Id = Poh.Order_Head_Id
                         And Pld.Order_Line_Id = Oio.Order_Line_Id
                         And Pld.Order_Detail_Id = Oio.Order_Detail_Id
                         And Pld.Item_Id = Oio.Item_Id)*/
                    --单据类型必须是占用库存
                 And Exists
               (Select 1
                        From t_Pln_Order_Type Pot
                       Where Pot.Order_Type_Id = Poh.Order_Type_Id
                         And Nvl(Pot.Is_Lock_Inv_Flag, 'N') = 'Y')
                 And Nvl(Oio.Stock_Affirm_Qty, 0) +
                     Nvl(Oio.Supply_Qty, 0) -
                     Nvl(Oio.So_Order_Qty, 0) -
                     Nvl(Oio.Sundry_Qty, 0) > 0) Pln
         Where (Pln.Item_Occupy_Qty - Pln.Not_So_Order_Qty - Pln.Affirm_Share_Qty) > 0
               Or Pln.Can_Unlock_Affirm_Qty > 0
       Order By Storage_Priority Desc,
        Max_Supply_Date Desc, Inv_Affirm_Flag, Can_Unlock_Affirm_Qty Desc;
    r_Order_Single         c_Order_Single%Rowtype;
    v_Value                Varchar2(2000);
    v_Err_Num              Number;
    v_Pln_Wip_Ord_Match    Varchar2(100);
    v_Qoh_Qty              Number; --库存现有量
    v_Usable_Qoh_Qty       Number; --库存可用量
    v_Occupy_Qty           Number; --库存占用量
    v_Need_Release_Occ_Qty Number; --需占用释放数量
    v_Special_Occupy_Qty   Number; --特殊占用数量
    v_Item_Occupy_Qty      Number;  --商品库存占用量
    v_Share_Cancel_Qty     Number; --需取消分配数量

    v_Red_Head_id          Number;
    v_Red_LIne_id          Number;
	v_nega_flag            varchar2(32);--中转出货是否允许负库存
    v_Red_Order_Flag       Varchar2(3) := 'N';
    v_Execute_Qty          Number;
    v_Item_Code            Varchar2(100);
    v_Inventory_Code       Varchar2(100);
    v_Inv_Affirm_Special_Qty Number;
    v_Inv_Affirm_Flag      Varchar2(3);
  Begin
    p_Result := v_Success;
    v_Value  := v_Success;
    v_Execute_Qty := p_Execute_Qty;
    pkg_bd.F_ADD_ERROR_LOG('p_Execute_Special_Occupy', '0','计划订单特殊占用,仓库ID='||p_Inventory_Id||',数量='||p_Execute_Qty||',占用类型='||p_Special_type);
    --获取工单与订单是否完全匹配参数
    If p_Special_type = '43' Then
      Begin
	  -- modi by jiangwei29 20-04-08 是否允许负库存
        Select Iph.Old_Po_Id, Ipl.Po_Line_Id_Old, iph.nega_inv_flag
          Into v_Red_Head_Id, v_Red_Line_Id, v_nega_flag
          From t_Inv_Po_Headers Iph,
               t_Inv_Po_Lines   Ipl,
               t_Inv_Bill_Types Bt
         Where Iph.Po_Id = Ipl.Po_Id
           And Iph.Po_Type_Id = Bt.Bill_Type_Id
           And Iph.Po_Id = p_Special_Order_Head_Id
           And Ipl.Po_Line_Id = p_Special_Order_Line_Id
           And Iph.Inv_Finance_Id = p_Inventory_Id
           --modi by lizhen 2015-03-30 采购退货特珠占用放在发货确认时处理
           --原来为执行执行状态“14”
           And Iph.Po_Status = '21' --add by lizhen 2015-03-24
           And Ipl.Item_Id = p_Item_Id;
      Exception
        When Others Then
          v_Value := '获取采购退货单失败！' || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
      End;
    End If;
    If v_Red_Head_Id Is Not Null And v_Red_LIne_id Is Not Null Then
      v_Red_Order_Flag := v_True;
    End If;
    v_Pln_Wip_Ord_Match := Pkg_Bd.f_Get_Parameter_Value('PLN_WIP_ORD_MATCH',
                                                        p_Entity_Id);
    --获取产品编码信息
    Begin
      Select Bi.Item_Code
        Into v_Item_Code
        From t_Bd_Item Bi
       Where Bi.Entity_Id = p_Entity_Id
         And Bi.Item_Id = p_Item_Id;
    Exception
      When Others Then
        v_Value := '获取产品编码失败，产品ID：' || To_Char(p_Item_Id) || v_Nl ||
                   Sqlerrm;
        Raise v_Base_Exception;
    End;
    --获取仓库编码信息
    Begin
      Select Ii.Inventory_Code
        Into v_Inventory_Code
        From t_Inv_Inventories Ii
       Where Ii.Entity_Id = p_Entity_Id
         And Ii.Inventory_Id = p_Inventory_Id;
    Exception
      When Others Then
        v_Value := '获取仓库编码失败，仓库ID：' || To_Char(p_Inventory_Id) || v_Nl ||
                   Sqlerrm;
        Raise v_Base_Exception;
    End;
    If v_Red_Order_Flag = v_False Then
      --获取商品库存现有量数据
      Pkg_Inv_Pub.p_Get_Item_Inv_Qoh(p_Entity_Id      => p_Entity_Id,
                                     p_Inventory_Id   => p_Inventory_Id,
                                     p_Item_Id        => p_Item_Id,
                                     p_User_Code      => p_User_Code,
                                     p_Qoh_Qty        => v_Qoh_Qty,
                                     p_Usable_Qoh_Qty => v_Usable_Qoh_Qty,
                                     p_Occupy_Qty     => v_Occupy_Qty,
                                     p_Result         => v_Value);
      If v_Value <> v_Success Then
        v_Value := v_Value || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
      End If;
      --add by lizhen 2015-03-31 采购退货先做特殊占用，再处理库存事务
      --其它类型单据先做库存事务，再处理特殊占用,在现有量函数的可用量里面已扣减发货确认数量
      pkg_bd.F_ADD_ERROR_LOG('p_Execute_Special_Occupy', '0','计划订单特殊占用,仓库ID='||p_Inventory_Id||',可用量='||v_Usable_Qoh_Qty||',占用类型='||p_Special_type);
      --做破损调拨单特殊占用之前，做产品的库存事务。
      If Nvl(v_Usable_Qoh_Qty, 0) >= 0 Then
        --正数或者0，表示库存可用量满足，不需释放库存占用量
        Return;
      End If;
      --负数可用量，转换成正数，释放库存占用
      v_Need_Release_Occ_Qty := Least(Abs(Nvl(v_Usable_Qoh_Qty, 0)), v_Execute_Qty);
      pkg_bd.F_ADD_ERROR_LOG('p_Execute_Special_Occupy', '0','计划订单特殊占用,仓库ID='||p_Inventory_Id||',释放数量='||v_Need_Release_Occ_Qty||',占用类型='||p_Special_type);
	  --modi by jiangwei29 20-04-08 增加是否允许负库存
      If v_nega_flag != 'Y' and (v_Need_Release_Occ_Qty > nvl(v_Occupy_Qty, 0)) Then
        v_Value := '特殊占用处理失败，需特殊占用数量' || To_Char(v_Need_Release_Occ_Qty) ||
                     '> 库存占用数量(' || To_Char(v_Usable_Qoh_Qty) || ')' || v_Nl ||
                     '产品编码：' || v_Item_Code || v_Nl || '仓库编码：' ||
                     v_Inventory_Code;
        Raise v_Base_Exception;
      End If;
      --查找产品对应最近入库日期的订单
      Open c_Pln_Order;
      Loop
        Fetch c_Pln_Order
          Into r_Pln_Order;
        Exit When c_Pln_Order%Notfound;
        v_Special_Occupy_Qty := 0;
        --库存占用量 - 已下达未开单数量（非库存评审） - 已分配未开单（库存评审）
        If (r_Pln_Order.Inv_Affirm_Flag In (1, 2) And nvl(r_Pln_Order.item_Occupy_Qty, 0) - nvl(r_Pln_Order.Not_So_Order_Qty, 0) -
          nvl(r_Pln_Order.affirm_Share_Qty, 0) > 0) Or (r_Pln_Order.Inv_Affirm_Flag = 3
          And Nvl(r_Pln_Order.Can_Unlock_Affirm_Qty, 0) > 0) Then
          Open c_Order_Single(r_Pln_Order.Order_Line_Id);
          Loop
            Fetch c_Order_Single
              Into r_Order_Single;
            Exit When c_Order_Single%Notfound;
			--modi by jiangwei29 20-04-08 增加是否允许负库存
            For i In 1..3 Loop
              --取最小数量，为本次特殊占用数量
              If r_Order_Single.Inv_Affirm_Flag = 1 Then
                --释放中转入库单数量
                v_Special_Occupy_Qty := Least(v_Need_Release_Occ_Qty,
                                             Nvl(r_Order_Single.Item_Occupy_Qty,0) -
                                             Nvl(r_Order_Single.Not_So_Order_Qty, 0) -
                                             Nvl(r_Order_Single.Affirm_Share_Qty, 0));
                v_Inv_Affirm_Flag := 'N';
              Elsif r_Order_Single.Inv_Affirm_Flag = 2 Then
                If i = 1 Then
                  v_Special_Occupy_Qty := Least(v_Need_Release_Occ_Qty,
                                             Nvl(r_Order_Single.Item_Occupy_Qty,0) -
                                             Nvl(r_Order_Single.Not_So_Order_Qty, 0) -
                                             Nvl(r_Order_Single.Affirm_Share_Qty, 0));
                  v_Inv_Affirm_Flag := 'N';
                Else
                  --释放库存评审数量
                  v_Special_Occupy_Qty := Least(v_Need_Release_Occ_Qty,
                                             Nvl(r_Order_Single.Can_Unlock_Affirm_Qty, 0));
                  v_Inv_Affirm_Flag := 'Y';
                End If;
              Elsif r_Order_Single.Inv_Affirm_Flag = 3  Then
                --释放库存评审数量
                v_Special_Occupy_Qty := Least(v_Need_Release_Occ_Qty,
                                           Nvl(r_Order_Single.Can_Unlock_Affirm_Qty, 0));
                v_Inv_Affirm_Flag := 'Y';
              Else
                v_Value := '获取待释放库存的订单失败，未找到可用于释放库存的订单明细行。' || v_Nl ||
                           '产品编码：' || v_Item_Code || v_Nl || '仓库编码：' || v_Inventory_Code;
                Raise v_Base_Exception;
              End If;
              If v_Special_Occupy_Qty > 0 Then
                --41:破损调拨、42:盘盈亏、43:采购退货
                If p_Special_type = '41' Then --破损调拨
                  Pkg_Pln_Inv_Occupy.p_Torn_Transfer_Occupy_Stocks(p_Inventory_Id      => p_Inventory_Id,
                                                                   p_Item_Id           => p_Item_Id,
                                                                   p_Occupy_Qty        => v_Special_Occupy_Qty,
                                                                   p_Match_Pln_To_Wip  => v_Pln_Wip_Ord_Match,
                                                                   p_Action_Desc       => '破损调拨特殊占用数量增加',
                                                                   p_Entity_Id         => p_Entity_Id,
                                                                   p_Origin_Type       => '破损调拨',
                                                                   p_Origin_Head_Id    => r_Order_Single.Order_Head_id,
                                                                   p_Origin_Number     => r_Order_Single.Order_Number,
                                                                   p_Origin_Line_Id    => r_Order_Single.Order_Line_id,
                                                                   p_Source_Order_Type => p_Special_Order_Type_Name,
                                                                   p_Source_Head_Id    => p_Special_Order_Head_id,
                                                                   p_Source_Number     => p_Special_Order_Number,
                                                                   p_Source_Line_Id    => p_Special_Order_Line_id,
                                                                   p_User_Code         => p_User_Code,
                                                                   p_Result            => v_Err_Num,
                                                                   p_Err_Msg           => v_Value);
                Elsif p_Special_type = '42' Then --盘盈亏
                  Pkg_Pln_Inv_Occupy.p_Makeinvof_Occupy_Stocks(p_Inventory_Id      => p_Inventory_Id,
                                                               p_Item_Id           => p_Item_Id,
                                                               p_Occupy_Qty        => v_Special_Occupy_Qty,
                                                               p_Match_Pln_To_Wip  => v_Pln_Wip_Ord_Match,
                                                               p_Action_Desc       => '盘盈亏特殊占用数量增加',
                                                               p_Entity_Id         => p_Entity_Id,
                                                               p_Origin_Type       => '盘盈亏',
                                                               p_Origin_Head_Id    => r_Order_Single.Order_Head_id,
                                                               p_Origin_Number     => r_Order_Single.Order_Number,
                                                               p_Origin_Line_Id    => r_Order_Single.Order_Line_id,
                                                               p_Source_Order_Type => p_Special_Order_Type_Name,
                                                               p_Source_Head_Id    => p_Special_Order_Head_id,
                                                               p_Source_Number     => p_Special_Order_Number,
                                                               p_Source_Line_Id    => p_Special_Order_Line_id,
                                                               p_User_Code         => p_User_Code,
                                                               p_Result            => v_Err_Num,
                                                               p_Err_Msg           => v_Value);
                Elsif p_Special_type = '43' Then --采购退货
                  Pkg_Pln_Inv_Occupy.p_Procure_Return_Occupy_Stocks(p_Inventory_Id      => p_Inventory_Id,
                                                                    p_Item_Id           => p_Item_Id,
                                                                    p_Occupy_Qty        => v_Special_Occupy_Qty,
                                                                    p_Match_Pln_To_Wip  => v_Pln_Wip_Ord_Match,
                                                                    p_Action_Desc       => '采购退货特殊占用数量增加',
                                                                    p_Entity_Id         => p_Entity_Id,
                                                                    p_Origin_Type       => '采购退货',
                                                                    p_Origin_Head_Id    => r_Order_Single.Order_Head_id,
                                                                    p_Origin_Number     => r_Order_Single.Order_Number,
                                                                    p_Origin_Line_Id    => r_Order_Single.Order_Line_id,
                                                                    p_Source_Order_Type => p_Special_Order_Type_Name,
                                                                    p_Source_Head_Id    => p_Special_Order_Head_id,
                                                                    p_Source_Number     => p_Special_Order_Number,
                                                                    p_Source_Line_Id    => p_Special_Order_Line_id,
                                                                    p_User_Code         => p_User_Code,
                                                                    p_Result            => v_Err_Num,
                                                                    p_Err_Msg           => v_Value);
                Elsif p_Special_type = '44' Then --其它
                  Pkg_Pln_Inv_Occupy.p_Others_Occupy_Stocks(p_Inventory_Id      => p_Inventory_Id,
                                                            p_Item_Id           => p_Item_Id,
                                                            p_Occupy_Qty        => v_Special_Occupy_Qty,
                                                            p_Match_Pln_To_Wip  => v_Pln_Wip_Ord_Match,
                                                            p_Action_Desc       => '其它特殊占用数量增加',
                                                            p_Entity_Id         => p_Entity_Id,
                                                            p_Origin_Type       => '其它',
                                                            p_Origin_Head_Id    => r_Order_Single.Order_Head_id,
                                                            p_Origin_Number     => r_Order_Single.Order_Number,
                                                            p_Origin_Line_Id    => r_Order_Single.Order_Line_id,
                                                            p_Source_Order_Type => p_Special_Order_Type_Name,
                                                            p_Source_Head_Id    => p_Special_Order_Head_id,
                                                            p_Source_Number     => p_Special_Order_Number,
                                                            p_Source_Line_Id    => p_Special_Order_Line_id,
                                                            p_User_Code         => p_User_Code,
                                                            p_Result            => v_Err_Num,
                                                            p_Err_Msg           => v_Value);
                End If;
                If v_Value <> v_Success Then
                  v_Value := '特殊库存占用失败，' || v_Value;
                  Raise v_Base_Exception;
                End If;
                If v_Special_Occupy_Qty > 0 Then
                  p_Auto_Create_Share(p_Pln_Order_Line_Id => r_Order_Single.Order_Line_Id,
                                      p_Inventory_Id      => p_Inventory_Id,
                                      p_Trans_Sign_Flag   => -1,
                                      p_Trans_Share_Qty   => v_Special_Occupy_Qty,
                                      p_Entity_Id         => p_Entity_Id,
                                      p_Pln_Wip_Ord_Match => v_Pln_Wip_Ord_Match,
                                      p_User_Code         => p_User_Code,
                                      p_Result            => v_Value,
                                      p_Inv_Affirm_Flag   => v_Inv_Affirm_Flag, --库存评审标志
                                      p_Sub_Item_id       => p_Item_Id
                                      );
                End If;
                If v_Value <> v_Success Then
                  v_Value := '取消分配数量失败，' || v_Value;
                  Raise v_Base_Exception;
                End If;
                Pkg_Pln_Inv_Occupy.p_Dispose_Special_Occupy(p_Inventory_Id         => p_Inventory_Id,
                                                            p_Item_Id              => p_Item_Id,
                                                            p_Trans_Date           => Trunc(Sysdate),
                                                            p_Sign_Type            => 1, --1：占用  -1：释放
                                                            p_Trans_Qty            => v_Special_Occupy_Qty,
                                                            p_Special_Type         => p_Special_type,
                                                            p_Entity_Id            => p_Entity_Id,
                                                            p_Origin_Order_Type_Id => r_Order_Single.Order_Type_Id,
                                                            p_Origin_Head_Id       => r_Order_Single.Order_Head_id,
                                                            p_Origin_Order_Number  => r_Order_Single.Order_Number,
                                                            p_Origin_Line_Id       => r_Order_Single.Order_Line_id,
                                                            p_Source_Order_Type    => p_Special_Order_Type_Name,
                                                            p_Source_Head_Id       => p_Special_Order_Head_id,
                                                            p_Source_Order_Number  => p_Special_Order_Number,
                                                            p_Source_Line_Id       => p_Special_Order_Line_id,
                                                            p_User_Code            => p_User_Code,
                                                            p_Result               => v_Value);
                If v_Value <> v_Success Then
                  v_Value := '特殊占用信息表占用失败，' || v_Value;
                  Raise v_Base_Exception;
                End If;
              End If;
              --剩余未特殊占用数量，循环可占用订单，看到特殊占用数量 = 0
              v_Need_Release_Occ_Qty := v_Need_Release_Occ_Qty - Nvl(v_Special_Occupy_Qty, 0);
              Exit When v_Need_Release_Occ_Qty = 0 Or r_Order_Single.Inv_Affirm_Flag <> 2;
            End Loop;
            Exit When v_Need_Release_Occ_Qty = 0;
          End Loop;
          Close c_Order_Single;
        End If;
        Exit When v_Need_Release_Occ_Qty = 0;
        --剩余未特殊占用数量，循环可占用订单，看到特殊占用数量 = 0
        --v_Need_Release_Occ_Qty := v_Need_Release_Occ_Qty - Nvl(v_Special_Occupy_Qty, 0);
      End Loop;
	  --modi by jiangwei29 20-04-08 增加是否允许负库存
      If v_nega_flag != 'Y' and v_Need_Release_Occ_Qty <> 0 Then
        v_Value := '特殊占用执行失败，需特殊占用数量未匹配完，剩余【' ||
                To_Char(v_Need_Release_Occ_Qty) || '】未找到订单单明细行数据释放库存占用致特殊占用。'
                || v_Nl || '产品编码：' || v_Item_Code || v_Nl || '仓库编码：' || v_Inventory_Code;
        Raise v_Base_Exception;
      End If;
      Close c_Pln_Order;
    Else
      --释放特殊占用数量，
      For r_Red_Special In (Select Sum(Soh.Transaction_Qty) -
                                   Nvl((Select Sum(Oh.Transaction_Qty)
                                         From t_Inv_Po_Lines Ipl, t_Pln_Inv_Special_Occupy_His Oh
                                        Where Ipl.Po_Line_Id_Old = Soh.Source_Line_Id
                                          And Oh.Source_Line_Id = Ipl.Po_Line_Id
                                          And Oh.Source_Head_Id = Ipl.Po_Id
                                          And Oh.Origin_Line_Id = Soh.Origin_Line_Id
                                          And Oh.Origin_Head_Id = Soh.Origin_Head_Id
                                          And Oh.Transaction_Date = Soh.Transaction_Date),
                                       0) - (Select Sum(Nvl(Iso.Release_Qty, 0))
                                           From Cims.t_Pln_Inv_Special_Occupy Iso
                                          Where Iso.Transaction_Date = Soh.Transaction_Date
                                            And Iso.Origin_Head_Id = Soh.Origin_Head_Id
                                            And Iso.Origin_Line_Id = Soh.Origin_Line_Id
                                            And Iso.Origin_Order_Type_Id = Soh.Origin_Order_Type_Id
                                            And Iso.Inventory_Id = Soh.Inventory_Id
                                            And Iso.Item_Id = Soh.Item_Id) Transaction_Qty,
                                   Soh.Entity_Id,
                                   Soh.Transaction_Type,
                                   Soh.Transaction_Date,
                                   Soh.Origin_Order_Type_Id,
                                   Soh.Origin_Head_Id,
                                   Soh.Origin_Order_Number,
                                   Soh.Origin_Line_Id,
                                   Soh.Source_Line_Id,
                                   Soh.Source_Order_Number,
                                   Soh.Source_Head_Id,
                                   Soh.Source_Order_Type
                              From t_Pln_Inv_Special_Occupy_His Soh
                             Where Soh.Transaction_Type = '占用'
                               And Soh.Inventory_Id = p_Inventory_Id
                               And Soh.Item_Id = p_Item_Id
                               And Soh.Source_Head_Id = v_Red_Head_id
                               And Soh.Source_Line_Id = v_Red_LIne_id
                             Group By Soh.Entity_Id,
                                      Soh.Inventory_Id,
                                      Soh.Item_Id,
                                      Soh.Transaction_Type,
                                      Soh.Transaction_Date,
                                      Soh.Origin_Order_Type_Id,
                                      Soh.Origin_Head_Id,
                                      Soh.Origin_Order_Number,
                                      Soh.Origin_Line_Id,
                                      Soh.Source_Line_Id,
                                      Soh.Source_Order_Number,
                                      Soh.Source_Head_Id,
                                      Soh.Source_Order_Type) Loop
        v_Special_Occupy_Qty := Least(v_Execute_Qty, Nvl(r_red_special.Transaction_Qty, 0));
        If v_Special_Occupy_Qty > 0 Then
          --41:破损调拨、42:盘盈亏、43:采购退货
          If p_Special_type = '41' Then --破损调拨
            Pkg_Pln_Inv_Occupy.p_Torn_Tf_Unoccupy_Stocks(p_Inventory_Id      => p_Inventory_Id,
                                                         p_Item_Id           => p_Item_Id,
                                                         p_Occupy_Qty        => v_Special_Occupy_Qty,
                                                         p_Match_Pln_To_Wip  => v_Pln_Wip_Ord_Match,
                                                         p_Action_Desc       => '破损调拨红冲特殊占用释放数量减少',
                                                         p_Entity_Id         => p_Entity_Id,
                                                         p_Origin_Type       => '破损调拨',
                                                         p_Origin_Head_Id    => r_red_special.origin_head_id,
                                                         p_Origin_Number     => r_red_special.origin_order_number,
                                                         p_Origin_Line_Id    => r_red_special.origin_line_id,
                                                         p_Source_Order_Type => p_Special_Order_Type_Name,
                                                         p_Source_Head_Id    => p_Special_Order_Head_id,
                                                         p_Source_Number     => p_Special_Order_Number,
                                                         p_Source_Line_Id    => p_Special_Order_Line_id,
                                                         p_User_Code         => p_User_Code,
                                                         p_Allow_No_Occupy   => 'N',
                                                         p_Result            => v_Err_Num,
                                                         p_Err_Msg           => v_Value);
          Elsif p_Special_type = '42' Then --盘盈亏
            Pkg_Pln_Inv_Occupy.p_Makeinvof_Unoccupy_Stocks(p_Inventory_Id      => p_Inventory_Id,
                                                           p_Item_Id           => p_Item_Id,
                                                           p_Occupy_Qty        => v_Special_Occupy_Qty,
                                                           p_Match_Pln_To_Wip  => v_Pln_Wip_Ord_Match,
                                                           p_Action_Desc       => '盘盈亏红冲特殊占用释放数量减少',
                                                           p_Entity_Id         => p_Entity_Id,
                                                           p_Origin_Type       => '盘盈亏',
                                                           p_Origin_Head_Id    => r_red_special.origin_head_id,
                                                           p_Origin_Number     => r_red_special.origin_order_Number,
                                                           p_Origin_Line_Id    => r_red_special.origin_line_id,
                                                           p_Source_Order_Type => p_Special_Order_Type_Name,
                                                           p_Source_Head_Id    => p_Special_Order_Head_id,
                                                           p_Source_Number     => p_Special_Order_Number,
                                                           p_Source_Line_Id    => p_Special_Order_Line_id,
                                                           p_User_Code         => p_User_Code,
                                                           p_Allow_No_Occupy   => 'N',
                                                           p_Result            => v_Err_Num,
                                                           p_Err_Msg           => v_Value);
          Elsif p_Special_type = '43' Then --采购退货
            Pkg_Pln_Inv_Occupy.p_Procreturn_Unoccupy_Stocks(p_Inventory_Id     => p_Inventory_Id,
                                                            p_Item_Id          => p_Item_Id,
                                                            p_Occupy_Qty       => v_Special_Occupy_Qty,
                                                            p_Match_Pln_To_Wip => v_Pln_Wip_Ord_Match,
                                                            p_Action_Desc      => '采购退货红冲特殊占用释放数量减少',
                                                            p_Entity_Id        => p_Entity_Id,
                                                            p_Origin_Type      => '采购退货红冲',
                                                            p_Origin_Head_Id   => r_red_special.origin_head_id,
                                                            p_Origin_Number    => r_red_special.origin_order_Number,
                                                            p_Origin_Line_Id   => r_red_special.origin_line_id,
                                                            p_Source_Order_Type => p_Special_Order_Type_Name,
                                                            p_Source_Head_Id    => p_Special_Order_Head_id,
                                                            p_Source_Number     => p_Special_Order_Number,
                                                            p_Source_Line_Id    => p_Special_Order_Line_id,
                                                            p_User_Code         => p_User_Code,
                                                            p_Allow_No_Occupy   => 'N',
                                                            p_Result            => v_Err_Num,
                                                            p_Err_Msg           => v_Value);
          Elsif p_Special_type = '44' Then --其它
            Pkg_Pln_Inv_Occupy.p_Others_Unoccupy_Stocks(p_Inventory_Id      => p_Inventory_Id,
                                                        p_Item_Id           => p_Item_Id,
                                                        p_Occupy_Qty        => v_Special_Occupy_Qty,
                                                        p_Match_Pln_To_Wip  => v_Pln_Wip_Ord_Match,
                                                        p_Action_Desc       => '其它特殊占用数量增加',
                                                        p_Entity_Id         => p_Entity_Id,
                                                        p_Origin_Type       => '其它',
                                                        p_Origin_Head_Id    => r_red_special.origin_head_id,
                                                        p_Origin_Number     => r_red_special.origin_order_Number,
                                                        p_Origin_Line_Id    => r_red_special.origin_line_id,
                                                        p_Source_Order_Type => p_Special_Order_Type_Name,
                                                        p_Source_Head_Id    => p_Special_Order_Head_id,
                                                        p_Source_Number     => p_Special_Order_Number,
                                                        p_Source_Line_Id    => p_Special_Order_Line_id,
                                                        p_User_Code         => p_User_Code,
                                                        p_Allow_No_Occupy   => 'N',
                                                        p_Result            => v_Err_Num,
                                                        p_Err_Msg           => v_Value);
          End If;
          If v_Value <> v_Success Then
            v_Value := '特殊库存占用释放失败，' || v_Value;
            Raise v_Base_Exception;
          End If;
          Pkg_Pln_Inv_Occupy.p_Dispose_Special_Occupy(p_Inventory_Id         => p_Inventory_Id,
                                                      p_Item_Id              => p_Item_Id,
                                                      p_Trans_Date           => r_Red_Special.Transaction_Date,
                                                      p_Sign_Type            => -1, --1：占用  -1：释放
                                                      p_Trans_Qty            => v_Special_Occupy_Qty,
                                                      p_Special_Type         => p_Special_type,
                                                      p_Entity_Id            => p_Entity_Id,
                                                      p_Origin_Order_Type_Id => r_red_special.origin_Order_Type_Id,
                                                      p_Origin_Head_Id       => r_red_special.origin_head_id,
                                                      p_Origin_Order_Number  => r_red_special.origin_order_Number,
                                                      p_Origin_Line_Id       => r_red_special.origin_line_id,
                                                      p_Source_Order_Type    => p_Special_Order_Type_Name,
                                                      p_Source_Head_Id       => p_Special_Order_Head_id,
                                                      p_Source_Order_Number  => p_Special_Order_Number,
                                                      p_Source_Line_Id       => p_Special_Order_Line_id,
                                                      p_User_Code            => p_User_Code,
                                                      p_Result               => v_Value);
          If v_Value <> v_Success Then
            v_Value := '特殊占用信息表占用失败，' || v_Value;
            Raise v_Base_Exception;
          End If;
          --优先释放订单库存评审的特殊订单占用
          --ADD BY LIZHEN 2015-01-13
          For r_Inv_View In (Select *
                               From (Select /*(Nvl(Oir.Affirm_Qty, 0) -
                                            Nvl(Oir.Cancel_Qty, 0)) *
                                            Pkg_Pln_Pub.f_Get_Item_Assembly_Base(Pol.Item_Id,
                                                                                 Oio.Item_Id) Inv_Affirm_Qty,*/
                                            Nvl((Select Sum(Nvl(Oss.Share_Qty,
                                                               0) *
                                                           Pkg_Pln_Pub.f_Get_Item_Assembly_Base(Pol.Item_Id,
                                                                                                Oio.Item_Id))
                                                  From t_Pln_Order_Share_Shipment Oss
                                                 Where Oss.Origin_Head_Id = Poh.Order_Head_Id
                                                   And Oss.Origin_Line_Id = Pol.Order_Line_Id
                                                   And Oss.Inventory_From_Id = Oio.inventory_id
                                                   --And Oss.Source_Order_Share_Id Is Null
                                                   And Nvl(Oss.Inv_Share_Flag, 'N') = 'Y'),
                                                0) Can_Lock_Affirm_Qty,
                                            Oio.Stock_Affirm_Qty -
                                             --调拨单审核数量
                                             Nvl((Select Sum(Nvl(Told.Billed_Qty, 0) *
                                                            Decode(Ibt.Cancel_Flag,
                                                                   'Y',
                                                                   Decode(Ito.Trsf_Order_Status, 13, -1, 0),
                                                                   1))
                                                   From t_Inv_Trsf_Order             Ito,
                                                        t_Inv_Trsf_Order_Line        Tol,
                                                        t_Inv_Trsf_Order_Line_Detail Told,
                                                        t_Inv_Bill_Types             Ibt,
                                                        t_Pln_Order_Share_Shipment   Oss
                                                  Where Ito.Trsf_Order_Id = Tol.Trsf_Order_Id
                                                    And Told.Trsf_Order_Line_Id = Tol.Trsf_Order_Line_Id
                                                    And Told.Trsf_Order_Id = Ito.Trsf_Order_Id
                                                    And Tol.Order_Line_Id_Orig = Oio.Origin_Line_Id
                                                    And Told.Item_Id = Oio.Item_Id
                                                    And Ito.Ship_Inv_Id = Oio.Inventory_Id
                                                    And Ibt.Bill_Type_Id = Ito.Bill_Type_Id
                                                    And Ito.Trsf_Order_Status <> '10'
                                                    And Ibt.Transaction_Type_Id = 17
                                                    And Oss.Order_Share_Id = Tol.Origin_Ship_Plan_Id
                                                    And Oss.Origin_Line_Id = Oio.Origin_Line_Id
                                                    And Oss.Inventory_From_Id = Oio.Inventory_Id
                                                    And Nvl(Oss.Inv_Share_Flag, 'N') = 'Y'),
                                                 0) -
                                              --取消订单数量
                                              Nvl((Select Sum(Nvl(Osh.Quantity, 0) * Nvl(Pkg_Pln_Pub.f_Get_Item_Assembly_Base(Osh.Item_Id,
                                                                                                                             Oio.Item_Id),
                                                                                        0))
                                                    From t_Pln_Order_Share_History Osh, t_Pln_Order_Share_Shipment Oss
                                                   Where Osh.Inventory_From_Id = Oio.Inventory_Id
                                                     And Osh.Order_Line_Id = Oio.Origin_Line_Id
                                                     And Osh.Option_Type = '取消订单数量'
                                                     And Oss.Order_Share_Id = Osh.Order_Share_Id
                                                     And Nvl(Oss.Inv_Share_Flag, 'Y') = 'Y'),
                                                  0) Inv_Affirm_Qty,
                                            Pol.Order_Line_Id,
                                            Poh.Order_Head_Id,
                                            Oio.Item_Id,
                                            oio.Inventory_Id
                                       From t_Pln_Order_Head       Poh,
                                            t_Pln_Order_Line       Pol,
                                            t_Pln_Order_Inv_Occupy Oio
                                      Where Poh.Order_Head_Id = Pol.Order_Head_Id
                                        And Pol.Order_Line_Id = Oio.Origin_Line_Id
                                        And Poh.Order_Head_Id = Oio.Origin_Head_Id
                                        --And Oir.Order_Line_Id = Pol.Order_Line_Id
                                        And Oio.Inventory_Id = p_Inventory_Id
                                        --And Oir.Inventory_Id =  Oio.Inventory_Id
                                        And Oio.Item_Id = p_Item_Id
                                        And Oio.Origin_Line_Id = r_Red_Special.Origin_Line_Id)
                              Where Inv_Affirm_Qty - Can_Lock_Affirm_Qty > 0) Loop
            v_Inv_Affirm_Special_Qty := Least(v_Special_Occupy_Qty,
                                              Nvl(r_Inv_View.Inv_Affirm_Qty,0) -
                                              Nvl(r_Inv_View.Can_Lock_Affirm_Qty, 0));
            If Nvl(v_Inv_Affirm_Special_Qty, 0) > 0 Then
              p_Auto_Create_Share(p_Pln_Order_Line_Id => r_Red_Special.Origin_Line_Id,
                                  p_Inventory_Id      => p_Inventory_Id,
                                  p_Trans_Sign_Flag   => 1,
                                  p_Trans_Share_Qty   => v_Inv_Affirm_Special_Qty,
                                  p_Entity_Id         => p_Entity_Id,
                                  p_Pln_Wip_Ord_Match => v_Pln_Wip_Ord_Match,
                                  p_User_Code         => p_User_Code,
                                  p_Result            => v_Value,
                                  p_Inv_Affirm_Flag   => 'Y');
              If v_Value <> v_Success Then
                v_Value := '订单库存评库，特殊占用更新发货计划行分配数量失败。' || v_Nl || v_Value;
                Raise v_Base_Exception;
              End If;
              v_Special_Occupy_Qty := v_Special_Occupy_Qty -
                                      Nvl(v_Inv_Affirm_Special_Qty, 0);
              v_Execute_Qty := v_Execute_Qty - Nvl(v_Inv_Affirm_Special_Qty, 0);
            Elsif  Nvl(v_Inv_Affirm_Special_Qty, 0) < 0 Then
              v_Value := '订单库存评库，特殊占用更新发货计划行分配数量失败，' ||
                '本次释放特殊占用数量为负数【' || To_Char(v_Inv_Affirm_Special_Qty) || '】。' || v_Nl ||
                '产品编码：' || v_Item_Code || v_Nl || '仓库编码：' || v_Inventory_Code;
              Raise v_Base_Exception;
            End If;
          End Loop;
          If v_Special_Occupy_Qty > 0 Then
            p_Auto_Create_Share(p_Pln_Order_Line_Id => r_red_special.origin_line_id,
                                p_Inventory_Id      => p_Inventory_Id,
                                p_Trans_Sign_Flag   => 1,
                                p_Trans_Share_Qty   => v_Special_Occupy_Qty,
                                p_Entity_Id         => p_Entity_Id,
                                p_Pln_Wip_Ord_Match => v_Pln_Wip_Ord_Match,
                                p_User_Code         => p_User_Code,
                                p_Result            => v_Value);
            If v_Value <> v_Success Then
              v_Value := '中转入库，特殊占用更新发货计划行分配数量失败。' || v_Nl || v_Value;
              Raise v_Base_Exception;
            End If;
            v_Execute_Qty := v_Execute_Qty - v_Special_Occupy_Qty;
          End If;
        End If;
        If v_Execute_Qty < 0 Then
          v_Value := '特殊占用释放失败，本次占用释放后为负数。' ;
          Raise v_Base_Exception;
        End If;
      End Loop;
    End If;
  Exception
    When v_Base_Exception Then
      p_Result := '执行特殊占用释放库存失败：' || v_Nl || v_Value;
      Rollback;
    When Others Then
       p_Result := '执行特殊占用释放库存失败：' || v_Nl || v_Value || Sqlerrm;
      Rollback;
  End;

  -----------------------------------------------------------------------------------------
  --Author: Nicro.Li
  --Purpose: 计划订单特殊占用释放库存  特殊占用含：破损调拨、采购退货、库存盘点
  --处理特殊占用功能必须放在库存事务处理后，否则会占用失败
  -----------------------------------------------------------------------------------------
  Procedure p_Order_Special_Occupy(p_Entity_Id     In Number,
                                   p_Order_Head_Id In Number,
                                   p_Bill_Type_Id  In Number,
                                   p_User_Code     In Varchar2,
                                   p_Result        Out Varchar2) Is

  Begin
    p_Result := v_Success;
    pkg_bd.F_ADD_ERROR_LOG('p_Order_Special_Occupy', '0','特殊占用释放库存开始,单据ID='||p_Order_Head_Id)
    For r_Order In (Select '41' Special_Type, --破损调拨
                           Ito.Entity_Id,
                           Ito.Trsf_Order_Id Order_Head_Id,
                           Ito.Trsf_Order_Num Order_Number,
                           Tol.Trsf_Order_Line_Id Order_Line_Id,
                           Ito.Ship_Inv_Id Inventory_Id,
                           Ii.Inventory_Code,
                           Ii.Inventory_Name,
                           Ito.Bill_Type_Id,
                           Ibt.Bill_Type_Code,
                           Ibt.Bill_Type_Name,
                           Told.Item_Id,
                           Tbi.Item_Code,
                           Tbi.Item_Name,
                           Nvl(Told.Billed_Qty, 0) Executed_Qty
                      From t_Inv_Trsf_Order             Ito,
                           t_Inv_Trsf_Order_Line        Tol,
                           t_Inv_Trsf_Order_Line_Detail Told,
                           t_Bd_Item                    Tbi,
                           t_Inv_Inventories            Ii,
                           t_Inv_Bill_Types             Ibt
                     Where Ito.Trsf_Order_Id = Tol.Trsf_Order_Id
                       And Ito.Trsf_Order_Id = Told.Trsf_Order_Id
                       And Tol.Trsf_Order_Line_Id = Told.Trsf_Order_Line_Id
                       And Told.Item_Id = Tbi.Item_Id
                       And Ii.Inventory_Id = Ito.Ship_Inv_Id
                       And Ito.Trsf_Order_Id = p_Order_Head_Id
                       And Ito.Bill_Type_Id = p_Bill_Type_Id
                       And Ito.Entity_Id = p_Entity_Id
                       And Ibt.Bill_Type_Id = Ito.Bill_Type_Id
                       And Nvl(Ibt.Special_Occupy_Flag, v_False) = v_True
                       and told.billed_qty > 0
                    Union All
                    Select '42' Special_Type, --库存盘点单
                           Ico.Entity_Id,
                           Ico.Check_Order_Id Order_Head_Id,
                           Ico.Check_Order_Num Order_Number,
                           Col.Check_Order_Line_Id Order_Line_Id,
                           Ico.Inv_Id Inventory_Id,
                           Ii.Inventory_Code,
                           Ii.Inventory_Name,
                           Bt.Bill_Type_Id,
                           Bt.Bill_Type_Code,
                           Bt.Bill_Type_Name,
                           Col.Item_Id,
                           Tbi.Item_Code,
                           Tbi.Item_Name,
                           Nvl(Col.Exec_Qty, Col.Billed_Qty) Executed_Qty
                      From t_Inv_Check_Orders      Ico,
                           t_Inv_Check_Order_Lines Col,
                           t_Inv_Inventories       Ii,
                           t_Bd_Item               Tbi,
                           t_Inv_Bill_Types        Bt
                     Where Ico.Check_Order_Id = Col.Check_Order_Id
                       And Ii.Inventory_Id = Ico.Inv_Id
                       And Tbi.Item_Id = Col.Item_Id
                       And Ico.Check_Order_Id = p_Order_Head_Id
                       And Ico.Check_Order_Type_Id = p_Bill_Type_Id
                       And Ico.Entity_Id = p_Entity_Id
                       And Bt.Bill_Type_Id = Ico.Check_Order_Type_Id
                       And Nvl(Bt.Special_Occupy_Flag, v_False) = v_True
                    Union All
                    Select '43' Special_Type, --采购退货
                           Iph.Entity_Id,
                           Iph.Po_Id Order_Head_Id,
                           Iph.Po_Num Order_Number,
                           Ipl.Po_Line_Id Order_Line_Id,
                           Iph.Inv_Finance_Id Inventory_Id,
                           Ii.Inventory_Code,
                           Ii.Inventory_Name,
                           Bt.Bill_Type_Id,
                           Bt.Bill_Type_Code,
                           Bt.Bill_Type_Name,
                           Ipl.Item_Id,
                           Tbi.Item_Code,
                           Tbi.Item_Name,
                           Nvl(Ipl.Shipped_Qty, Ipl.Billed_Qty) Executed_Qty
                      From t_Inv_Po_Headers  Iph,
                           t_Inv_Po_Lines    Ipl,
                           t_Inv_Inventories Ii,
                           t_Bd_Item         Tbi,
                           t_Inv_Bill_Types  Bt
                     Where Iph.Po_Id = Ipl.Po_Id
                       And Ii.Inventory_Id = Iph.Inv_Finance_Id
                       And Tbi.Item_Id = Ipl.Item_Id
                       And Iph.Po_Id = p_Order_Head_Id
                       And Iph.Po_Type_Id = p_Bill_Type_Id
                       And Iph.Entity_Id = p_Entity_Id
                       --modi by lizhen 2015-03-30 采购退货特珠占用放在发货确认时处理
                       --原来为执行执行状态“14”
                       And Iph.Po_Status = '21' --add by lizhen 2015-03-24
                       And Nvl(Bt.Special_Occupy_Flag, v_False) = v_True
                       And Bt.Bill_Type_Id = Iph.Po_Type_Id) Loop
      pkg_bd.F_ADD_ERROR_LOG('p_Order_Special_Occupy', '1','特殊占用释放库存,单据ID='||p_Order_Head_Id||',数量='||r_Order.Executed_Qty);
      If Nvl(r_Order.Executed_Qty, 0) > 0 Then
        p_Execute_Special_Occupy(p_Entity_Id               => p_Entity_Id, --主体ID,
                                 p_Item_Id                 => r_Order.Item_Id, --产品ID
                                 p_Inventory_Id            => r_Order.Inventory_Id, --仓库ID
                                 p_Execute_Qty             => r_Order.Executed_Qty, --特殊占用执行数量
                                 p_Special_Type            => r_Order.Special_Type, --类型: 41:破损调拨、42:盘盈亏、43:采购退货
                                 p_Special_Order_Type_Name => r_Order.Bill_Type_Name, --单据类型名称
                                 p_Special_Order_Head_Id   => r_Order.Order_Head_Id, --单据头ID
                                 p_Special_Order_Number    => r_Order.Order_Number, --单据单号
                                 p_Special_Order_Line_Id   => r_Order.Order_Line_Id, --单据行ID
                                 p_User_Code               => p_User_Code, --用户编码
                                 p_Result                  => p_Result --成功返回“SUCCESS”
                                 );
        If p_Result <> v_Success Then
          Raise v_Base_Exception;
        End If;
      Else
        p_Result := '特殊占用处理失败，单据数量错误。单据数量：' ||
                    To_Char(r_Order.Executed_Qty) || '，单据头ID：' ||
                    To_Char(p_Order_Head_Id) || '，单据类型ID：' ||
                    To_Char(p_Bill_Type_Id);
        Raise v_Base_Exception;
      End If;
    End Loop;
  Exception
    When v_Base_Exception Then
      Rollback;
      p_Result := p_Result;
    When Others Then
      Rollback;
      p_Result := p_Result || v_Nl || Sqlerrm;
  End;

  -----------------------------------------------------------------------------------------
  --Author: Nicro.Li
  --Purpose: 计划订单特殊占用释放特殊占用数据  特殊占用含：破损调拨、采购退货、库存盘点
  -----------------------------------------------------------------------------------------
  Procedure p_Release_Special_Occ_Single(p_Entity_Id            In Number, --主体ID,
                                         p_Item_Id              In Number, --产品ID
                                         p_Inventory_Id         In Number, --仓库ID
                                         p_Trans_Date           In Date, --特殊占用事务日期
                                         p_Origin_Order_Type_Id In Number, --单据类型ID
                                         p_Origin_Order_Line_Id In Number, --单据行ID
                                         p_User_Code            In Varchar2, --用户编码
                                         p_Result               In Out Varchar2 --成功返回“SUCCESS”
                                         ) Is
    v_Item_Usable_Qoh_Qty    Number;
    v_Item_Release_Qty       Number;
    v_Pln_Wip_Ord_Match      Varchar2(3);
    v_Err_Num                Number;
    v_Sum_Special_Occupy_Qty Number;
    v_Inv_Affirm_Special_Qty Number;
    r_Special                t_Pln_Inv_Special_Occupy%Rowtype;
  Begin
    p_Result := v_Success;
    Begin
      --获取工单与订单是否完全匹配参数
      v_Pln_Wip_Ord_Match := Pkg_Bd.f_Get_Parameter_Value('PLN_WIP_ORD_MATCH',
                                                          p_Entity_Id);
    Exception
      When Others Then
        p_Result := '获取主体参数PLN_WIP_ORD_MATCH失败。' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;
    Begin
      Select *
        Into r_Special
        From t_Pln_Inv_Special_Occupy Iso
       Where Iso.Transaction_Date = p_Trans_Date
         And Iso.Item_Id = p_Item_Id
         And Iso.Inventory_Id = p_Inventory_Id
         And Iso.Origin_Line_Id = p_Origin_Order_Line_Id
         And Iso.Origin_Order_Type_Id = p_Origin_Order_Type_Id
         And Iso.Entity_Id = p_Entity_Id
         For Update Nowait;
    Exception
      When Others Then
        p_Result := '锁定t_Pln_Inv_Special_Occupy表数据失败！' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;
    v_Item_Usable_Qoh_Qty := Pkg_Inv_Pub.f_Get_Item_Inv_Qoh(p_Entity_Id    => p_Entity_Id,
                                                            p_Inventory_Id => p_Inventory_Id,
                                                            p_Item_Id      => p_Item_Id,
                                                            p_User_Code    => p_User_Code,
                                                            p_Get_Qoh_Type => 2);
    v_Sum_Special_Occupy_Qty    := Least(Nvl(v_Item_Usable_Qoh_Qty, 0),
                                   Nvl(r_Special.Occupy_Qty, 0) -
                                   Nvl(r_Special.Release_Qty, 0));
    v_Item_Release_Qty := 0;
    --暂时未做历史表与特殊占用表数量是否一致检查
    For r_His In (Select Soh.Inventory_Id,
                         Soh.Item_Id,
                         Soh.Special_Type,
                         Sum(Soh.Transaction_Qty *
                             Decode(Soh.Transaction_Type, '占用', 1, '释放', -1, 0))
                          Transaction_Qty
                    From t_Pln_Inv_Special_Occupy_His Soh
                   Where Soh.Transaction_Date = p_Trans_Date
                     And soh.Item_Id = p_Item_Id
                     And soh.Inventory_Id = p_Inventory_Id
                     And soh.origin_line_id = p_Origin_Order_Line_Id
                     And soh.origin_order_type_id = p_Origin_Order_Type_Id
                     And soh.entity_id = p_Entity_Id
                   Group By Soh.Inventory_Id, Soh.Item_Id, Soh.Special_Type) Loop

      v_Item_Release_Qty := Least(Nvl(r_His.Transaction_Qty, 0), Nvl(v_Sum_Special_Occupy_Qty, 0));
      If Nvl(v_Item_Release_Qty, 0) > 0 Then
        Pkg_Pln_Inv_Occupy.p_Dispose_Special_Occupy(p_Inventory_Id         => p_Inventory_Id,
                                                    p_Item_Id              => p_Item_Id,
                                                    p_Trans_Date           => p_Trans_Date,
                                                    p_Sign_Type            => -1,
                                                    p_Trans_Qty            => Nvl(v_Item_Release_Qty,
                                                                                  0),
                                                    p_Special_Type         => r_His.Special_Type,
                                                    p_Entity_Id            => p_Entity_Id,
                                                    p_Origin_Order_Type_Id => p_Origin_Order_Type_Id,
                                                    p_Origin_Head_Id       => r_Special.Origin_Head_Id,
                                                    p_Origin_Order_Number  => r_Special.Origin_Order_Number,
                                                    p_Origin_Line_Id       => r_Special.Origin_Line_Id,
                                                    p_Source_Order_Type    => r_Special.Origin_Order_Type_Name,
                                                    p_Source_Head_Id       => r_Special.Origin_Head_Id,
                                                    p_Source_Order_Number  => r_Special.Origin_Order_Number,
                                                    p_Source_Line_Id       => r_Special.Origin_Line_Id,
                                                    p_User_Code            => p_User_Code,
                                                    p_Result               => p_Result);
        If p_Result <> v_Success Then
          Raise v_Base_Exception;
        End If;
        --释放特殊库存占用数量
        --41:破损调拨、42:盘盈亏、43:采购退货
        If r_His.Special_Type = '41' Then
          --破损调拨
          Pkg_Pln_Inv_Occupy.p_Torn_Tf_Unoccupy_Stocks(p_Inventory_Id      => p_Inventory_Id,
                                                       p_Item_Id           => p_Item_Id,
                                                       p_Occupy_Qty        => Nvl(v_Item_Release_Qty,
                                                                                  0),
                                                       p_Match_Pln_To_Wip  => v_Pln_Wip_Ord_Match,
                                                       p_Action_Desc       => '特殊占用库存，释放特殊占用数量',
                                                       p_Entity_Id         => p_Entity_Id,
                                                       p_Origin_Type       => r_Special.Origin_Order_Type_Name,
                                                       p_Origin_Head_Id    => r_Special.Origin_Head_Id,
                                                       p_Origin_Number     => r_Special.Origin_Order_Number,
                                                       p_Origin_Line_Id    => r_Special.Origin_Line_Id,
                                                       p_Source_Order_Type => r_Special.Origin_Order_Type_Name,
                                                       p_Source_Head_Id    => r_Special.Origin_Head_Id,
                                                       p_Source_Number     => r_Special.Origin_Order_Number,
                                                       p_Source_Line_Id    => r_Special.Origin_Line_Id,
                                                       p_User_Code         => p_User_Code,
                                                       p_Allow_No_Occupy   => 'N',
                                                       p_Result            => v_Err_Num,
                                                       p_Err_Msg           => p_Result);
        Elsif r_His.Special_Type = '42' Then
          --盘盈亏
          Pkg_Pln_Inv_Occupy.p_Makeinvof_Unoccupy_Stocks(p_Inventory_Id      => p_Inventory_Id,
                                                         p_Item_Id           => p_Item_Id,
                                                         p_Occupy_Qty        => Nvl(v_Item_Release_Qty,
                                                                                    0),
                                                         p_Match_Pln_To_Wip  => v_Pln_Wip_Ord_Match,
                                                         p_Action_Desc       => '特殊占用库存，释放特殊占用数量',
                                                         p_Entity_Id         => p_Entity_Id,
                                                         p_Origin_Type       => r_Special.Origin_Order_Type_Name,
                                                         p_Origin_Head_Id    => r_Special.Origin_Head_Id,
                                                         p_Origin_Number     => r_Special.Origin_Order_Number,
                                                         p_Origin_Line_Id    => r_Special.Origin_Line_Id,
                                                         p_Source_Order_Type => r_Special.Origin_Order_Type_Name,
                                                         p_Source_Head_Id    => r_Special.Origin_Head_Id,
                                                         p_Source_Number     => r_Special.Origin_Order_Number,
                                                         p_Source_Line_Id    => r_Special.Origin_Line_Id,
                                                         p_User_Code         => p_User_Code,
                                                         p_Allow_No_Occupy   => 'N',
                                                         p_Result            => v_Err_Num,
                                                         p_Err_Msg           => p_Result);
        Elsif r_His.Special_Type = '43' Then
          --采购退货
          Pkg_Pln_Inv_Occupy.p_Procreturn_Unoccupy_Stocks(p_Inventory_Id      => p_Inventory_Id,
                                                          p_Item_Id           => p_Item_Id,
                                                          p_Occupy_Qty        => Nvl(v_Item_Release_Qty,
                                                                                     0),
                                                          p_Match_Pln_To_Wip  => v_Pln_Wip_Ord_Match,
                                                          p_Action_Desc       => '特殊占用库存，释放特殊占用数量',
                                                          p_Entity_Id         => p_Entity_Id,
                                                          p_Origin_Type       => r_Special.Origin_Order_Type_Name,
                                                          p_Origin_Head_Id    => r_Special.Origin_Head_Id,
                                                          p_Origin_Number     => r_Special.Origin_Order_Number,
                                                          p_Origin_Line_Id    => r_Special.Origin_Line_Id,
                                                          p_Source_Order_Type => r_Special.Origin_Order_Type_Name,
                                                          p_Source_Head_Id    => r_Special.Origin_Head_Id,
                                                          p_Source_Number     => r_Special.Origin_Order_Number,
                                                          p_Source_Line_Id    => r_Special.Origin_Line_Id,
                                                          p_User_Code         => p_User_Code,
                                                          p_Allow_No_Occupy   => 'N',
                                                          p_Result            => v_Err_Num,
                                                          p_Err_Msg           => p_Result);
        Elsif r_His.Special_Type = '44' Then
          --其它
          Pkg_Pln_Inv_Occupy.p_Others_Unoccupy_Stocks(p_Inventory_Id      => p_Inventory_Id,
                                                      p_Item_Id           => p_Item_Id,
                                                      p_Occupy_Qty        => Nvl(v_Item_Release_Qty,
                                                                                 0),
                                                      p_Match_Pln_To_Wip  => v_Pln_Wip_Ord_Match,
                                                      p_Action_Desc       => '特殊占用库存，释放特殊占用数量',
                                                      p_Entity_Id         => p_Entity_Id,
                                                      p_Origin_Type       => r_Special.Origin_Order_Type_Name,
                                                      p_Origin_Head_Id    => r_Special.Origin_Head_Id,
                                                      p_Origin_Number     => r_Special.Origin_Order_Number,
                                                      p_Origin_Line_Id    => r_Special.Origin_Line_Id,
                                                      p_Source_Order_Type => r_Special.Origin_Order_Type_Name,
                                                      p_Source_Head_Id    => r_Special.Origin_Head_Id,
                                                      p_Source_Number     => r_Special.Origin_Order_Number,
                                                      p_Source_Line_Id    => r_Special.Origin_Line_Id,
                                                      p_User_Code         => p_User_Code,
                                                      p_Allow_No_Occupy   => 'N',
                                                      p_Result            => v_Err_Num,
                                                      p_Err_Msg           => p_Result);
        End If;
        If p_Result <> v_Success Then
          p_Result := '特殊库存占用释放占用数量失败，' || p_Result;
          Raise v_Base_Exception;
        End If;
        --优先释放订单库存评审的特殊订单占用
        --ADD BY LIZHEN 2015-01-13
        For r_Inv_View In (Select *
                             From (Select /*(Nvl(Oir.Affirm_Qty, 0) -
                                            Nvl(Oir.Cancel_Qty, 0)) *
                                            Pkg_Pln_Pub.f_Get_Item_Assembly_Base(Pol.Item_Id,
                                                                                 Oio.Item_Id) Inv_Affirm_Qty,*/
                                            Nvl((Select Sum(Nvl(Oss.Share_Qty,
                                                               0) *
                                                           Pkg_Pln_Pub.f_Get_Item_Assembly_Base(Pol.Item_Id,
                                                                                                Oio.Item_Id))
                                                  From t_Pln_Order_Share_Shipment Oss
                                                 Where Oss.Origin_Head_Id = Poh.Order_Head_Id
                                                   And Oss.Origin_Line_Id = Pol.Order_Line_Id
                                                   And Oss.Inventory_From_Id = Oio.inventory_id
                                                   --And Oss.Source_Order_Share_Id Is Null
                                                   And Nvl(Oss.Inv_Share_Flag, 'N') = 'Y'),
                                                0) Can_Lock_Affirm_Qty,
                                            Oio.Stock_Affirm_Qty -
                                             --调拨单审核数量
                                             Nvl((Select Sum(--Nvl(Told.Rcv_Qty, 0) * --20160310 使用单据数量计算
                                                             nvl(told.billed_qty, 0) *
                                                            Decode(Ibt.Cancel_Flag,
                                                                   'Y',
                                                                   Decode(Ito.Trsf_Order_Status, 13, -1, 0),
                                                                   1))
                                                   From t_Inv_Trsf_Order             Ito,
                                                        t_Inv_Trsf_Order_Line        Tol,
                                                        t_Inv_Trsf_Order_Line_Detail Told,
                                                        t_Inv_Bill_Types             Ibt,
                                                        t_Pln_Order_Share_Shipment   Oss,
                                                        t_inv_transaction_types      itt
                                                  Where Ito.Trsf_Order_Id = Tol.Trsf_Order_Id
                                                    And Told.Trsf_Order_Line_Id = Tol.Trsf_Order_Line_Id
                                                    And Told.Trsf_Order_Id = Ito.Trsf_Order_Id
                                                    And Tol.Order_Line_Id_Orig = Oio.Origin_Line_Id
                                                    And Told.Item_Id = Oio.Item_Id
                                                    And Ito.Consignee_Inv_Id = Oio.Inventory_Id
                                                    And Ibt.Bill_Type_Id = Ito.Bill_Type_Id
                                                    And Ito.Trsf_Order_Status = '13'
                                                    --And Ibt.Transaction_Type_Id = 17
                                                    AND ibt.transaction_type_id = itt.transaction_type_id
                                                    AND itt.transaction_type_code = '1017' --改用编码
                                                    And Nvl(Ibt.Special_Occupy_Flag, 'N') = 'N'
                                                    And ((Oss.Source_Order_Share_Id = Tol.Origin_Ship_Plan_Id And Nvl(Oss.Inv_Share_Flag, 'N') = 'N')
                                                      Or (Oss.Order_Share_Id = Tol.Origin_Ship_Plan_Id And Nvl(Oss.Inv_Share_Flag, 'N') = 'Y'))
                                                    And Oss.Origin_Line_Id = Oio.Origin_Line_Id
                                                    And Oss.Inventory_From_Id = Oio.Inventory_Id
                                                    --And Nvl(Oss.Inv_Share_Flag, 'N') = 'Y' --modi by lizhen 2015-03-16
                                                    ),
                                                 0) -
                                              --取消订单数量
                                              Nvl((Select Sum(Nvl(Osh.Quantity, 0) * Nvl(Pkg_Pln_Pub.f_Get_Item_Assembly_Base(Osh.Item_Id,
                                                                                                                             Oio.Item_Id),
                                                                                        0))
                                                    From t_Pln_Order_Share_History Osh, t_Pln_Order_Share_Shipment Oss
                                                   Where Osh.Inventory_From_Id = Oio.Inventory_Id
                                                     And Osh.Order_Line_Id = Oio.Origin_Line_Id
                                                     And Osh.Option_Type = '取消订单数量'
                                                     And Oss.Order_Share_Id = Osh.Order_Share_Id
                                                     --And Nvl(Oss.Inv_Share_Flag, 'Y') = 'Y'  --modi by lizhen-2015-03-16
                                                     ),
                                                  0) Inv_Affirm_Qty,
                                            Pol.Order_Line_Id,
                                            Poh.Order_Head_Id,
                                            Oio.Item_Id,
                                            Oio.Inventory_Id
                                       From t_Pln_Order_Head       Poh,
                                            t_Pln_Order_Line       Pol,
                                            t_Pln_Order_Inv_Occupy Oio/*,
                                            t_Pln_Order_Inv_Review Oir*/
                                      Where Poh.Order_Head_Id = Pol.Order_Head_Id
                                        And Pol.Order_Line_Id = Oio.Origin_Line_Id
                                        And Poh.Order_Head_Id = Oio.Origin_Head_Id
                                        --And Oir.Order_Line_Id = Pol.Order_Line_Id
                                        And Oio.Inventory_Id = p_Inventory_Id
                                        --And Oir.Inventory_Id =  Oio.Inventory_Id
                                        And Oio.Item_Id = p_Item_Id
                                        And Oio.Origin_Line_Id = r_Special.Origin_Line_Id
                                        )
                              Where Inv_Affirm_Qty - Can_Lock_Affirm_Qty > 0) Loop
          v_Inv_Affirm_Special_Qty := Least(v_Item_Release_Qty,
                                            Nvl(r_Inv_View.Inv_Affirm_Qty,0) -
                                            Nvl(r_Inv_View.Can_Lock_Affirm_Qty, 0));
          If Nvl(v_Inv_Affirm_Special_Qty, 0) > 0 Then
            p_Auto_Create_Share(p_Pln_Order_Line_Id => r_Special.Origin_Line_Id,
                                p_Inventory_Id      => p_Inventory_Id,
                                p_Trans_Sign_Flag   => 1,
                                p_Trans_Share_Qty   => v_Inv_Affirm_Special_Qty,
                                p_Entity_Id         => p_Entity_Id,
                                p_Pln_Wip_Ord_Match => v_Pln_Wip_Ord_Match,
                                p_User_Code         => p_User_Code,
                                p_Result            => p_Result,
                                p_Inv_Affirm_Flag   => v_True);
            If p_Result <> v_Success Then
              p_Result := '订单库存评库，特殊占用更新发货计划行分配数量失败。' || v_Nl || p_Result;
              Raise v_Base_Exception;
            End If;
            v_Item_Release_Qty := v_Item_Release_Qty -
                                    Nvl(v_Inv_Affirm_Special_Qty, 0);
            v_Sum_Special_Occupy_Qty := Nvl(v_Sum_Special_Occupy_Qty, 0) - Nvl(v_Inv_Affirm_Special_Qty, 0);
          Elsif  Nvl(v_Inv_Affirm_Special_Qty, 0) < 0 Then
            p_Result := '订单库存评库，特殊占用更新发货计划行分配数量失败，' ||
              '本次释放特殊占用数量为负数【' || To_Char(v_Inv_Affirm_Special_Qty) || '】。';
            Raise v_Base_Exception;
          End If;
        End Loop;
        If v_Item_Release_Qty > 0 Then
          p_Auto_Create_Share(p_Pln_Order_Line_Id => r_Special.Origin_Line_Id,
                              p_Inventory_Id      => p_Inventory_Id,
                              p_Trans_Sign_Flag   => 1,
                              p_Trans_Share_Qty   => Nvl(v_Item_Release_Qty, 0),
                              p_Entity_Id         => p_Entity_Id,
                              p_Pln_Wip_Ord_Match => v_Pln_Wip_Ord_Match,
                              p_User_Code         => p_User_Code,
                              p_Result            => p_Result);

          If p_Result <> v_Success Then
            p_Result := '中转入库，特殊占用更新发货计划行分配数量失败。' || v_Nl || p_Result;
            Raise v_Base_Exception;
          End If;
          v_Sum_Special_Occupy_Qty := Nvl(v_Sum_Special_Occupy_Qty, 0) - Nvl(v_Item_Release_Qty, 0);
        End If;
      End If;
      If v_Sum_Special_Occupy_Qty < 0 Then
        p_Result := '特殊占用释放失败，本次占用释放后为负数。' ;
        Raise v_Base_Exception;
      End If;
    End Loop;
  Exception
    When v_Base_Exception Then
      Rollback;
      p_Result := p_Result;
    When Others Then
      Rollback;
      p_Result := p_Result || v_Nl || Sqlerrm;
  End;

  -----------------------------------------------------------------------------------------
  --Author: Nicro.Li
  --Purpose: 计划订单特殊占用释放特殊占用数据,每日晚上JOB自动执行
  -----------------------------------------------------------------------------------------
  Procedure p_Release_Special_Occ_All(p_Entity_Id In Number) Is
    v_Value Varchar2(2000);
  Begin
    For r_Special In (Select *
                        From t_Pln_Inv_Special_Occupy Iso
                       Where Nvl(Iso.Occupy_Qty, 0) -
                             Nvl(Iso.Release_Qty, 0) > 0
                         And Iso.Entity_Id = p_Entity_Id) Loop
      p_Release_Special_Occ_Single(p_Entity_Id            => p_Entity_Id,
                                   p_Item_Id              => r_Special.Item_Id,
                                   p_Inventory_Id         => r_Special.Inventory_Id,
                                   p_Trans_Date           => r_Special.Transaction_Date,
                                   p_Origin_Order_Type_Id => r_Special.Origin_Order_Type_Id,
                                   p_Origin_Order_Line_Id => r_Special.Origin_Line_Id,
                                   p_User_Code            => 'p_Release_Special_Occ_All',
                                   p_Result               => v_Value);
      If v_Value != v_Success Then
        Rollback;
        Pkg_Pln_Pub.p_Write_Job_Log(p_Module_Code          => 'PLN',
                                    p_Procedure_Name       => 'p_Release_Special_Occ_All',
                                    p_Error_Msg            => '每晚检查是否有库存可用量，释放特殊占用。' || v_Nl ||
                                                              v_Value,
                                    p_Source_Order_Head_Id => r_Special.Origin_Head_Id,
                                    p_Source_Order_Line_Id => r_Special.Origin_Line_Id,
                                    p_Item_Id              => r_Special.Item_Id,
                                    p_Inventory_Id         => r_Special.Inventory_Id,
                                    p_Quantity             => Nvl(r_Special.Occupy_Qty, 0) -
                                                              Nvl(r_Special.Release_Qty, 0));
      End If;
      Commit;
    End Loop;
  Exception
    When Others Then
      Null;
  End;

  -----------------------------------------------------------------------------------------
  --Author: Nicro.Li
  --Purpose: 计划订单特殊占用释放特殊占用数据,每日晚上JOB
  -----------------------------------------------------------------------------------------
  Procedure p_Release_Special_Occ_Job Is
  Begin
    --家用空调
    Begin
      p_Release_Special_Occ_All(10);
    Exception
      When Others Then
        Null;
    End;

    --家用空调
    Begin
      p_Release_Special_Occ_All(14);
    Exception
      When Others Then
        Null;
    End;
  Exception
    When Others Then
      Null;
  End;

  -----------------------------------------------------------------------------------------
  --Author: Nicro.Li
  --Purpose: 重计订单发货计划已分配数量与库存占用量数量不一致数据
  --         每日晚上JOB，占用量JOB处理完后，处理该功能
  -----------------------------------------------------------------------------------------
  Procedure p_Recalculation_Share_Ship(p_Entity_Id Number) Is
    v_Pln_Wip_Ord_Match    Varchar2(10);
    v_Usable_Share_Qty     Number;
    v_Inv_Share_Flag       Varchar2(3);
    v_Value                Varchar2(2000);
    r_Order_Share          t_Pln_Order_Share_Shipment%Rowtype;
  Begin
    --获取工单与订单是否完全匹配参数
    v_Pln_Wip_Ord_Match := Pkg_Bd.f_Get_Parameter_Value('PLN_WIP_ORD_MATCH',
                                                        p_Entity_Id);
    For r_Order In (Select Pln.*
                      From (Select Poh.Order_Head_Id,
                                   Op.Period_Code,
                                   Poh.Order_Number,
                                   Poh.Order_Type_Id,
                                   Ot.Order_Type_Name,
                                   Poh.Form_State,
                                   Pol.Item_Id,
                                   Pol.Item_Code,
                                   Pol.Item_Desc,
                                   Poh.Sales_Center_Code,
                                   Poh.Sales_Center_Name,
                                   Poh.Customer_Code,
                                   Poh.Customer_Name,
                                   Poh.Refer_Date,
                                   Ot.Is_Lock_Inv_Flag,
                                   Pol.Apply_Qty,
                                   Pol.Can_Produce_Qty,
                                   Pol.Inv_Affirm_Qty,
                                   Pol.Check_Qty,
                                   Pol.Cancel_Inv_In_Qty,
                                   Pol.Cancel_Inv_Check_Qty,
                                   Ppa.Producing_Area_Name,
                                   Pol.Supply_Qty,
                                   Pol.Share_Qty,
                                   Pkg_Pln_Inv_Occupy.f_Item_Ass_Occupy_Qty(p_Inventory_Id     => Poss.Inventory_From_Id,
                                                                            p_Item_Id          => Pol.Item_Id,
                                                                            p_Match_Pln_To_Wip => v_Pln_Wip_Ord_Match,
                                                                            p_Entity_Id        => Pol.Entity_Id,
                                                                            p_Origin_Line_Id   => Pol.Order_Line_Id,
                                                                            p_Origin_Type      => '_') Item_Occupy_Qty,
                                   Nvl(Poss.Sum_Share_Qty, 0) -
                                   Nvl(Poss.Sum_So_Order_Qty, 0) No_So_Order_Qty,
                                   Poss.Sum_Share_Qty,
                                   Poss.Sum_So_Order_Qty,
                                   Pol.Order_Line_Id,
                                   Poss.Inventory_From_Id
                              From Cims.t_Pln_Order_Line Pol,
                                   Cims.t_Pln_Order_Head Poh,
                                   Cims.t_Pln_Order_Period Op,
                                   Cims.t_Pln_Order_Type Ot,
                                   Cims.t_Pln_Producing_Area Ppa,
                                   (Select Oss.Inventory_From_Id,
                                           Oss.Origin_Type,
                                           Oss.Origin_Head_Id,
                                           Oss.Origin_Head_Code,
                                           Oss.Origin_Line_Id,
                                           Oss.Entity_Id,
                                           Sum(Oss.Share_Qty) Sum_Share_Qty,
                                           Sum(Nvl(Oss.So_Order_Qty, 0)) Sum_So_Order_Qty
                                      From Cims.t_Pln_Order_Share_Shipment Oss
                                     Where Oss.Entity_Id = p_Entity_Id
                                     Group By Oss.Inventory_From_Id,
                                              Oss.Origin_Type,
                                              Oss.Origin_Head_Id,
                                              Oss.Origin_Head_Code,
                                              Oss.Origin_Line_Id,
                                              Oss.Entity_Id) Poss
                             Where Pol.Order_Head_Id = Poh.Order_Head_Id
                               And Poh.Period_Id = Op.Period_Id
                               And Pol.Order_Line_Id = Poss.Origin_Line_Id(+)
                               And Ot.Source_Order_Type_Id <> 2
                               And Pol.Entity_Id = p_Entity_Id
                               And Poh.Order_Type_Id = Ot.Order_Type_Id
                               And Ppa.Producing_Area_Id = Pol.Producing_Area_Id) Pln
                     Where Pln.Item_Occupy_Qty <> Pln.No_So_Order_Qty
                       And Nvl(Pln.Inv_Affirm_Qty, 0) +
                           Nvl(Pln.Can_Produce_Qty, 0) > Nvl(Pln.Share_Qty, 0)) Loop
      v_Usable_Share_Qty := Nvl(r_Order.Item_Occupy_Qty, 0) - Nvl(r_Order.No_So_Order_Qty, 0);
      If Nvl(v_Usable_Share_Qty, 0) > 0 Then
        Begin
          Select *
            Into r_Order_Share
            From t_Pln_Order_Share_Shipment Oss
           Where Oss.Origin_Line_Id = r_Order.Order_Line_Id
             And Oss.Origin_Head_Id = r_Order.Order_Head_Id
             And Oss.Inventory_From_Id = r_Order.Inventory_From_Id
             And Rownum <= 1;
        Exception
          When Others Then
            v_Value := '获取订单发货计划行失败，未找到需要处理的数据行。' || v_Nl ||
              '订单头ID：' || To_Char(r_Order.Order_Head_Id) || v_Nl ||
              '订单行ID：' || To_Char(r_Order.Order_Line_Id) || v_Nl ||
              '仓库ID：' || To_Char(r_Order.Inventory_From_Id) || v_Nl || Sqlerrm;
            Raise v_Base_Exception;
        End;
        p_Auto_Create_Share(p_Pln_Order_Line_Id => r_Order.Order_Line_Id,
                            p_Inventory_Id      => r_Order.Inventory_From_Id,
                            p_Trans_Sign_Flag   => 1,
                            p_Trans_Share_Qty   => v_Usable_Share_Qty,
                            p_Entity_Id         => p_Entity_Id,
                            p_Pln_Wip_Ord_Match => v_Pln_Wip_Ord_Match,
                            p_User_Code         => 'admin',
                            p_Result            => v_Value,
                            p_Inv_Affirm_Flag   => r_Order_Share.Inv_Share_Flag);
        If v_Value <> v_Success Then
          Rollback;
          pkg_pln_pub.p_Write_Job_Log(p_Module_Code          => 'PLN',
                                      p_Procedure_Name       => 'p_Recalculation_Share_Ship',
                                      p_Error_Msg            => v_Value,
                                      p_Source_Order_Head_Id => r_Order.Order_Head_Id,
                                      p_Source_Order_Line_Id => r_Order.Order_Line_Id,
                                      p_Item_Id              => -1,
                                      p_Inventory_Id         => r_Order.Inventory_From_Id,
                                      p_Quantity             => 0
                                      );
        End If;
      End If;
      Commit;
    End Loop;
  Exception
    When v_Base_Exception Then
      Rollback;
      pkg_pln_pub.p_Write_Job_Log(p_Module_Code          => 'PLN',
                                  p_Procedure_Name       => 'p_Recalculation_Share_Ship',
                                  p_Error_Msg            => v_Value,
                                  p_Source_Order_Head_Id => -1,
                                  p_Source_Order_Line_Id => -1,
                                  p_Item_Id              => -1,
                                  p_Inventory_Id         => -1,
                                  p_Quantity             => 0
                                  );
      Commit;
    When Others Then
      Rollback;
      pkg_pln_pub.p_Write_Job_Log(p_Module_Code          => 'PLN',
                                  p_Procedure_Name       => 'p_Recalculation_Share_Ship',
                                  p_Error_Msg            => v_Value,
                                  p_Source_Order_Head_Id => -1,
                                  p_Source_Order_Line_Id => -1,
                                  p_Item_Id              => -1,
                                  p_Inventory_Id         => -1,
                                  p_Quantity             => 0
                                  );
      Commit;
  End;

  -----------------------------------------------------------------------------------------
  --Author: Nicro.Li
  --Purpose: 重计订单发货计划已分配数量与库存占用量数量不一致数据
  --         每日晚上JOB，占用量JOB处理完后，处理该功能
  -----------------------------------------------------------------------------------------
  Procedure p_Recalculation_Share_Ship_Job Is
  Begin
    --家用空调发货计划重计
    p_Recalculation_Share_Ship(10);

    --厨房电器发货计划重计
    p_Recalculation_Share_Ship(14);
  Exception
    When Others Then
      Null;
  End;

End Pkg_Pln_Shares;
/

