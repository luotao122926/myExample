create PACKAGE BODY      PKG_PLN_ORDER_ITEM_CHECK AS

  -- 最近30天产品属性检查（判断是否有产品，判断属性是否正确、是否有成本）
Procedure p_Item_Cost_Check(p_Result Out Varchar2 -- 失败时返回异常消息，成功时返回 SUCCESS
                            ) Is
  v_Record_Count Number;
  v_Item_Cost    Number;
Begin
  Execute Immediate 'TRUNCATE TABLE CIMS.T_PLN_ORDER_ITEM_CHECK';
  -- 查找最近30天的订单
  For Cur_Pln In ( /*SELECT DISTINCT POD.ENTITY_ID,
                                              POD.ITEM_ID,
                                              POD.ITEM_CODE,
                                              POD.ITEM_NAME,
                                              POD.PRODUCING_AREA_ID,
                                              POD.PRODUCING_AREA_CODE,
                                              POD.PRODUCING_AREA_NAME,
                                              OP.MRP_ORG_ID,
                                              OP.MRP_ORG_CODE
                                FROM CIMS.T_PLN_ORDER_HEAD POH,
                                     CIMS.T_PLN_ORDER_DETAIL POD,
                                     CIMS.T_PLN_PRODUCING_AREA OP
                               WHERE POH.ORDER_HEAD_ID = POD.ORDER_HEAD_ID
                                 AND POD.PRODUCING_AREA_ID = OP.PRODUCING_AREA_ID
                                 AND POH.REFER_DATE BETWEEN TRUNC(SYSDATE - 30, 'DD') AND TRUNC(SYSDATE, 'DD')*/
                  Select Distinct Pod.Entity_Id,
                                   Pod.Item_Id,
                                   Pod.Item_Code,
                                   Pod.Item_Name,
                                   Nvl(Pol.Synt_Producing_Area_Id,
                                       Pod.Producing_Area_Id) Producing_Area_Id,
                                   Nvl(Sop.Producing_Area_Code,
                                       Pod.Producing_Area_Code) Producing_Area_Code,
                                   Nvl(Sop.Producing_Area_Name,
                                       Pod.Producing_Area_Name) Producing_Area_Name,
                                   Nvl(Sop.Mrp_Org_Id, Op.Mrp_Org_Id) Mrp_Org_Id,
                                   Nvl(Sop.Mrp_Org_Code, Op.Mrp_Org_Code) Mrp_Org_Code
                    From Cims.t_Pln_Order_Head     Poh,
                          Cims.t_Pln_Order_Line     Pol,
                          Cims.t_Pln_Order_Detail   Pod,
                          Cims.t_Pln_Producing_Area Op,
                          Cims.t_Pln_Producing_Area Sop
                   Where Poh.Order_Head_Id = Pod.Order_Head_Id
                     And Poh.Order_Head_Id = Pol.Order_Head_Id
                     And Pol.Order_Line_Id = Pod.Order_Line_Id
                     And Pod.Producing_Area_Id = Op.Producing_Area_Id
                     And Pol.Synt_Producing_Area_Id =
                         Sop.Producing_Area_Id(+)
                     And Poh.Refer_Date Between Trunc(Sysdate - 30, 'DD') And
                         Trunc(Sysdate, 'DD')) Loop
    Begin
      --判断是否有产品
      Select Count(1)
        Into v_Record_Count
        From Apps.Mtl_System_Items@Mdims2mderp Msi
       Where Msi.Segment1 = Cur_Pln.Item_Code --产品编码
         And Msi.Organization_Id = Cur_Pln.Mrp_Org_Id;
      If v_Record_Count <= 0 Then
        --          DBMS_OUTPUT.put_line('主体：'||CUR_PLN.ENTITY_ID||'、产品：'||CUR_PLN.ITEM_CODE||'、产地编码：'||CUR_PLN.PRODUCING_AREA_CODE||'在ERP组织'||CUR_PLN.MRP_ORG_CODE||'('||CUR_PLN.MRP_ORG_ID||')没有该产品');
        Insert Into t_Pln_Order_Item_Check
          (Order_Item_Check_Id, -- 主键ID
           Entity_Id, -- 主体ID
           Item_Id, -- 产品ID（散件）
           Item_Code, -- 产品编码（散件）
           Item_Name, -- 产品名称（散件）
           Producing_Area_Id, -- 产地ID
           Producing_Area_Code, -- 产地编码
           Producing_Area_Name, -- 产地名称
           Mrp_Org_Id, -- MRP组织ID（库存组织）
           Mrp_Org_Code, -- MRP组织编码（库存组织）
           Check_Type, -- 检查类型
           Check_Message, -- 检查错误信息
           Create_Date -- 检查日期
           )
        Values
          (Seq_Pln_Order_Item_Check.Nextval,
           Cur_Pln.Entity_Id,
           Cur_Pln.Item_Id,
           Cur_Pln.Item_Code,
           Cur_Pln.Item_Name,
           Cur_Pln.Producing_Area_Id,
           Cur_Pln.Producing_Area_Code,
           Cur_Pln.Producing_Area_Name,
           Cur_Pln.Mrp_Org_Id,
           Cur_Pln.Mrp_Org_Code,
           Pkg_Pln_Order_Item_Check.v_No_Item,
           'ERP组织中没有该产品',
           Sysdate);
        Commit;
        Continue;
      End If;
      --判断属性是否正确、是否有成本
      Select Count(1)
        Into v_Item_Cost
        From Apps.Cst_Item_Costs@Mdims2mderp   Cst,
             Apps.Mtl_System_Items@Mdims2mderp Msi
       Where Msi.Segment1 = Cur_Pln.Item_Code --产品编码
         And Msi.Organization_Id = Cur_Pln.Mrp_Org_Id --组织ID
         And Cst.Inventory_Item_Id = Msi.Inventory_Item_Id
         And Cst.Organization_Id = Msi.Organization_Id
         And Cst.Cost_Type_Id = 1
         And Nvl(Msi.Customer_Order_Enabled_Flag, 'N') = 'Y'
         And Nvl(Msi.Customer_Order_Flag, 'N') = 'Y'
         And Nvl(Msi.Shippable_Item_Flag, 'N') = 'Y'
         And Nvl(Msi.So_Transactions_Flag, 'N') = 'Y'
         And Nvl(Msi.Returnable_Flag, 'N') = 'Y'
         And Msi.Atp_Components_Flag = 'N'
         And Msi.Atp_Flag = 'N'
         And Msi.Inventory_Item_Status_Code != 'Inactive'
         And Cst.Item_Cost <> 0 --20170608 hejy3 增加标准成本不为空的检查
      ;
      If v_Item_Cost <= 0 Then
        --          DBMS_OUTPUT.put_line('主体：'||CUR_PLN.ENTITY_ID||'、产品：'||CUR_PLN.ITEM_CODE||'、产地编码：'||CUR_PLN.PRODUCING_AREA_CODE||'在ERP组织'||CUR_PLN.MRP_ORG_CODE||'('||CUR_PLN.MRP_ORG_ID||')没有定义成本');
        Insert Into t_Pln_Order_Item_Check
          (Order_Item_Check_Id, -- 主键ID
           Entity_Id, -- 主体ID
           Item_Id, -- 产品ID（散件）
           Item_Code, -- 产品编码（散件）
           Item_Name, -- 产品名称（散件）
           Producing_Area_Id, -- 产地ID
           Producing_Area_Code, -- 产地编码
           Producing_Area_Name, -- 产地名称
           Mrp_Org_Id, -- MRP组织ID（库存组织）
           Mrp_Org_Code, -- MRP组织编码（库存组织）
           Check_Type, -- 检查类型
           Check_Message, -- 检查错误信息
           Create_Date -- 检查日期
           )
        Values
          (Seq_Pln_Order_Item_Check.Nextval,
           Cur_Pln.Entity_Id,
           Cur_Pln.Item_Id,
           Cur_Pln.Item_Code,
           Cur_Pln.Item_Name,
           Cur_Pln.Producing_Area_Id,
           Cur_Pln.Producing_Area_Code,
           Cur_Pln.Producing_Area_Name,
           Cur_Pln.Mrp_Org_Id,
           Cur_Pln.Mrp_Org_Code,
           Pkg_Pln_Order_Item_Check.v_No_Cost,
           'ERP组织中该产品无成本或成本为0',
           Sysdate);
        Commit;
        Continue;
      End If;
    
      --2017-06-08 hejy3 增加事业部采购价检查
      --根据订单行的产地从产地表(T_PLN_PRODUCING_AREA)获取生产组织
      --根据生产组织从供应商与组织关系表(T_INV_VENDOR_ORGANIZATION)获取供应商
      --根据供应商从供应商价格列表(T_BD_VENDOR_PRICELIST)获取价格列表
      --检查产品在价格列表是否有维护有效价格
      For r_Vendor In (Select *
                         From t_Inv_Vendor_Organization Vo
                        Where Vo.Entity_Id = Cur_Pln.Entity_Id
                          And Vo.Organization_Id = Cur_Pln.Mrp_Org_Id) Loop
        --获取供应商价格列表
        For r_Price_List In (Select *
                               From t_Bd_Vendor_Pricelist p
                              Where p.Entity_Id = Cur_Pln.Entity_Id
                                And p.Vendor_Id = r_Vendor.Vendor_Id
                                And p.Type_Code = 'TRANSIT_TYPE'
                                And Sysdate Between p.Begin_Date And
                                    Nvl(p.End_Date + 1, Sysdate + 1)) Loop
          Select Count(Pl.List_Price)
            Into v_Record_Count
            From t_Bd_Price_Line Pl
           Where Pl.Price_List_Id = r_Price_List.Price_List_Id
             And Pl.Item_Code = Cur_Pln.Item_Code
             And Trunc(Sysdate) Between
                 Nvl(Pl.Begin_Date, Trunc(Sysdate) - 1) And
                 Nvl(Pl.End_Date, Trunc(Sysdate) + 1)
             And Pl.Active_Flag = 'Y';
        
          If v_Record_Count <= 0 Then
            Insert Into t_Pln_Order_Item_Check
              (Order_Item_Check_Id, -- 主键ID
               Entity_Id, -- 主体ID
               Item_Id, -- 产品ID（散件）
               Item_Code, -- 产品编码（散件）
               Item_Name, -- 产品名称（散件）
               Producing_Area_Id, -- 产地ID
               Producing_Area_Code, -- 产地编码
               Producing_Area_Name, -- 产地名称
               Mrp_Org_Id, -- MRP组织ID（库存组织）
               Mrp_Org_Code, -- MRP组织编码（库存组织）
               Check_Type, -- 检查类型
               Check_Message, -- 检查错误信息
               Create_Date -- 检查日期
               )
            Values
              (Seq_Pln_Order_Item_Check.Nextval,
               Cur_Pln.Entity_Id,
               Cur_Pln.Item_Id,
               Cur_Pln.Item_Code,
               Cur_Pln.Item_Name,
               Cur_Pln.Producing_Area_Id,
               Cur_Pln.Producing_Area_Code,
               Cur_Pln.Producing_Area_Name,
               Cur_Pln.Mrp_Org_Id,
               Cur_Pln.Mrp_Org_Code,
               Pkg_Pln_Order_Item_Check.v_No_Pur_Price,
               'CIMS中该产品未定义事业部采购价,价格列表:' || r_Price_List.Price_List_Name,
               Sysdate);
            Commit;
            Continue;
          End If;
        End Loop;
      End Loop;
    Exception
      When Others Then
        Rollback;
        p_Result := Pkg_Bd.f_Add_Error_Log('PKG_PLN_ORDER_ITEM_CHECK.PKG_PLN_ORDER_ITEM_CHECK',
                                           Sqlcode,
                                           'ENTITY_ID：' || Cur_Pln.Entity_Id ||
                                           '、ITEM_CODE：' ||
                                           Cur_Pln.Item_Code ||
                                           '、PRODUCING_AREA_CODE：' ||
                                           Cur_Pln.Producing_Area_Code ||
                                           '、MRP_ORG_CODE：' ||
                                           Cur_Pln.Mrp_Org_Code ||
                                           '产品属性检查出错！错误消息：' ||
                                           Substr(Dbms_Utility.Format_Error_Backtrace,
                                                  1,
                                                  100) || Sqlerrm);
    End;
  End Loop;

  --检查编码在该主体的营销组织，是否存在、是否维护了冻结成本 lilh6 2018-8-15
  For Cur_Pln In (Select Distinct Pod.Entity_Id,
                                  Pod.Item_Id,
                                  Pod.Item_Code,
                                  Pod.Item_Name,
                                  Tt.Organization_Id,
                                  Tt.Organization_Code
                    From Cims.t_Pln_Order_Head   Poh,
                         Cims.t_Pln_Order_Line   Pol,
                         Cims.t_Pln_Order_Detail Pod,
                         Cims.t_Inv_Organization Tt
                   Where Poh.Order_Head_Id = Pod.Order_Head_Id
                     And Poh.Order_Head_Id = Pol.Order_Head_Id
                     And Pol.Order_Line_Id = Pod.Order_Line_Id
                     And Tt.Entity_Id = Poh.Entity_Id
                     And Tt.Operating_Unit In
                         (Select e.Code_Value
                            From Cims.Up_Codelist        u,
                                 Cims.Up_Codelist_Entity e
                           Where u.Id = e.Codelist_Id
                             And u.Codetype = 'SO_OU_ID'
                             And e.Entity_Id = Tt.Entity_Id)
                     And Poh.Refer_Date Between Trunc(Sysdate - 30, 'DD') And
                         Trunc(Sysdate, 'DD')) Loop
    Begin
      --判断是否有产品
      Select Count(1)
        Into v_Record_Count
        From Apps.Mtl_System_Items@Mdims2mderp Msi
       Where Msi.Segment1 = Cur_Pln.Item_Code --产品编码
         And Msi.Organization_Id = Cur_Pln.Organization_Id;
      If v_Record_Count <= 0 Then
        --          DBMS_OUTPUT.put_line('主体：'||CUR_PLN.ENTITY_ID||'、产品：'||CUR_PLN.ITEM_CODE||'、产地编码：'||CUR_PLN.PRODUCING_AREA_CODE||'在ERP组织'||CUR_PLN.MRP_ORG_CODE||'('||CUR_PLN.MRP_ORG_ID||')没有该产品');
        Insert Into t_Pln_Order_Item_Check
          (Order_Item_Check_Id, -- 主键ID
           Entity_Id, -- 主体ID
           Item_Id, -- 产品ID（散件）
           Item_Code, -- 产品编码（散件）
           Item_Name, -- 产品名称（散件）
           Producing_Area_Id, -- 产地ID
           Producing_Area_Code, -- 产地编码
           Producing_Area_Name, -- 产地名称
           Mrp_Org_Id, -- MRP组织ID（库存组织）
           Mrp_Org_Code, -- MRP组织编码（库存组织）
           Check_Type, -- 检查类型
           Check_Message, -- 检查错误信息
           Create_Date -- 检查日期
           )
        Values
          (Seq_Pln_Order_Item_Check.Nextval,
           Cur_Pln.Entity_Id,
           Cur_Pln.Item_Id,
           Cur_Pln.Item_Code,
           Cur_Pln.Item_Name,
           Null,
           Null,
           Null,
           Cur_Pln.Organization_Id,
           Cur_Pln.Organization_Code,
           Pkg_Pln_Order_Item_Check.v_No_Item,
           'ERP的营销组织中没有该产品',
           Sysdate);
        Commit;
        Continue;
      End If;
      --判断属性是否正确、是否有成本
      Select Count(1)
        Into v_Item_Cost
        From Apps.Cst_Item_Costs@Mdims2mderp   Cst,
             Apps.Mtl_System_Items@Mdims2mderp Msi
       Where Msi.Segment1 = Cur_Pln.Item_Code --产品编码
         And Msi.Organization_Id = Cur_Pln.Organization_Id --组织ID
         And Cst.Inventory_Item_Id = Msi.Inventory_Item_Id
         And Cst.Organization_Id = Msi.Organization_Id
         And Cst.Cost_Type_Id = 1
         And Nvl(Msi.Customer_Order_Enabled_Flag, 'N') = 'Y'
         And Nvl(Msi.Customer_Order_Flag, 'N') = 'Y'
         And Nvl(Msi.Shippable_Item_Flag, 'N') = 'Y'
         And Nvl(Msi.So_Transactions_Flag, 'N') = 'Y'
         And Nvl(Msi.Returnable_Flag, 'N') = 'Y'
         And Msi.Atp_Components_Flag = 'N'
         And Msi.Atp_Flag = 'N'
         And Msi.Inventory_Item_Status_Code != 'Inactive'
         And Cst.Item_Cost <> 0 --20170608 hejy3 增加标准成本不为空的检查
      ;
      If v_Item_Cost <= 0 Then
        --          DBMS_OUTPUT.put_line('主体：'||CUR_PLN.ENTITY_ID||'、产品：'||CUR_PLN.ITEM_CODE||'、产地编码：'||CUR_PLN.PRODUCING_AREA_CODE||'在ERP组织'||CUR_PLN.MRP_ORG_CODE||'('||CUR_PLN.MRP_ORG_ID||')没有定义成本');
        Insert Into t_Pln_Order_Item_Check
          (Order_Item_Check_Id, -- 主键ID
           Entity_Id, -- 主体ID
           Item_Id, -- 产品ID（散件）
           Item_Code, -- 产品编码（散件）
           Item_Name, -- 产品名称（散件）
           Producing_Area_Id, -- 产地ID
           Producing_Area_Code, -- 产地编码
           Producing_Area_Name, -- 产地名称
           Mrp_Org_Id, -- MRP组织ID（库存组织）
           Mrp_Org_Code, -- MRP组织编码（库存组织）
           Check_Type, -- 检查类型
           Check_Message, -- 检查错误信息
           Create_Date -- 检查日期
           )
        Values
          (Seq_Pln_Order_Item_Check.Nextval,
           Cur_Pln.Entity_Id,
           Cur_Pln.Item_Id,
           Cur_Pln.Item_Code,
           Cur_Pln.Item_Name,
           Null,
           Null,
           Null,
           Cur_Pln.Organization_Id,
           Cur_Pln.Organization_Code,
           Pkg_Pln_Order_Item_Check.v_No_Cost,
           'ERP的营销组织中该产品无成本或成本为0',
           Sysdate);
        Commit;
        Continue;
      End If;
    
    Exception
      When Others Then
        Rollback;
        p_Result := Pkg_Bd.f_Add_Error_Log('PKG_PLN_ORDER_ITEM_CHECK.PKG_PLN_ORDER_ITEM_CHECK',
                                           Sqlcode,
                                           'ENTITY_ID：' || Cur_Pln.Entity_Id ||
                                           '、ITEM_CODE：' ||
                                           Cur_Pln.Item_Code ||
                                           '、MRP_ORG_CODE：' ||
                                           Cur_Pln.Organization_Code ||
                                           '产品属性检查出错！错误消息：' ||
                                           Substr(Dbms_Utility.Format_Error_Backtrace,
                                                  1,
                                                  100) || Sqlerrm);
    End;
  End Loop;

  p_Result := Pkg_Pln_Order_Item_Check.v_Success;
Exception
  When Others Then
    p_Result := Pkg_Bd.f_Add_Error_Log('PKG_PLN_ORDER_ITEM_CHECK.PKG_PLN_ORDER_ITEM_CHECK',
                                       Sqlcode,
                                       '当月产品属性检查出错！错误消息：' ||
                                       Substr(Dbms_Utility.Format_Error_Backtrace,
                                              1,
                                              100) || Sqlerrm);
End;

END PKG_PLN_ORDER_ITEM_CHECK;
/

