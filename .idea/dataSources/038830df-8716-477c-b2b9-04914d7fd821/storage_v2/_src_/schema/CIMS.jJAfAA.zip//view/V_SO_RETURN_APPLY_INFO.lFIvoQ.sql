create view V_SO_RETURN_APPLY_INFO as
SELECT RH.APPLY_HEADER_ID,
       RH.ENTITY_ID,
       RH.BILL_TYPE_ID,
       RH.BILL_TYPE_CODE,
       RH.BILL_TYPE_NAME,
       RH.BILL_NUM,
       RH.BILL_STATUS,
       RH.BILL_DATE,
       RH.SALES_MAIN_TYPE,
       RH.SALES_MAIN_TYPE_NAME,
       RH.CUSTOMER_ID,
       RH.CUSTOMER_CODE,
       RH.CUSTOMER_NAME,
       RH.ACCOUNT_ID,
       RH.ACCOUNT_CODE,
       RH.ACCOUNT_NAME,
       RH.SALES_CENTER_ID,
       RH.SALES_CENTER_CODE,
       RH.SALES_CENTER_NAME,
       RH.RETURN_TYPE,
       RH.RETURN_TOTAL_AMOUNT,
       RH.DISCOUNT_PROVE_FLAG,
       RH.RECEIVED_DISCOUNT_PROVE_FLAG,
       RH.REMARK,
       RH.CANCEL_FLAG,
       RH.GEN_SO_FLAG,
       RH.GEN_SO_DATE,
       RH.MIP_URL,
       RH.CREATED_BY,
       RH.CREATION_DATE,
       RH.LAST_UPDATED_BY,
       RH.LAST_UPDATE_DATE,
       RL.APPLY_LINE_ID,
       RL.APPLIED_PRICE,
       RL.APPLIED_QTY,
       RL.RETURN_AMOUNT,
       RL.RETURN_REASON,
       NVL(RL.DISCOUNT_RATE,0) AS DISCOUNT_RATE,
       NVL(RL.MONTH_DISCOUNT_RATE,0) AS MONTH_DISCOUNT_RATE,
       NVL(RL.DISCOUNT_AMOUNT,0) AS DISCOUNT_AMOUNT,
       NVL(RL.MONTH_DISCOUNT_AMOUNT,0) AS MONTH_DISCOUNT_AMOUNT,
       RH.RECEIVE_INV_ID,
       RH.RECEIVE_INV_CODE,
       RH.RECEIVE_INV_NAME,
       RL.REMARK AS LINE_REMARK,
       RL.SETTLE_TYPE_CODE,
       RL.SETTLE_TYPE_NAME,
       RL.PROJECT_LINE_ID,
       RL.PROJECT_ID,
       RL.PROJECT_NUM,
       RL.PROJECT_PRICE,
       RL.PROJECT_TYPE_CODE,
       RL.TAX_CODE,
       RL.TAX_RATE,
       RL.Price_List_Id,
       RL.Price_Line_Id,
       RL.Big_Panel,
       RL.Project_Type,
       RL.So_Item_Identify,
       RD.APPLY_LINE_DETAIL_ID,
       RD.ITEM_ID,
       RD.ITEM_CODE,
       RD.ITEM_NAME,
       NVL(RL.SALES_MAIN_TYPE,RH.SALES_MAIN_TYPE) LINE_SALES_MAIN_TYPE,
       NVL(RL.SALES_MAIN_TYPE_NAME,RH.SALES_MAIN_TYPE_NAME) LINE_SALES_MAIN_TYPE_NAME,
       NVL(RL.RECEIVE_INV_ID,RH.RECEIVE_INV_ID) LINE_RECEIVE_INV_ID,
       NVL(RL.RECEIVE_INV_CODE,RH.RECEIVE_INV_CODE) LINE_RECEIVE_INV_CODE,
       NVL(RL.RECEIVE_INV_NAME,RH.RECEIVE_INV_NAME) LINE_RECEIVE_INV_NAME,
       RD.ITEM_QTY,
       RD.ITEM_UOM,
       RD.ITEM_PRICE,
       RD.ITEM_STATUS,
       RD.COMPONENT_ID,
       RD.COMPONENT_CODE,
       RD.COMPONENT_NAME,
       RD.COMPONENT_QTY,
       RD.COMPONENT_UOM,
       RD.COMPONENT_PRICE,
       RD.RECEIVED_QTY,
       RD.TO_SO_RETURN_QTY,
       RD.REMARK AS DETAIL_REMARK
  FROM T_SO_RETURN_APPLY_HEADER      RH,
       T_SO_RETURN_APPLY_LINE        RL,
       T_SO_RETURN_APPLY_LINE_DETAIL RD
 WHERE RH.APPLY_HEADER_ID = RL.APPLY_HEADER_ID
   AND RL.APPLY_LINE_ID = RD.APPLY_LINE_ID
   ORDER BY RD.ITEM_ID,RD.COMPONENT_ID
with read only
/

comment on column V_SO_RETURN_APPLY_INFO.APPLY_HEADER_ID is '退货申请头ID'
/

comment on column V_SO_RETURN_APPLY_INFO.ENTITY_ID is '主体ID'
/

comment on column V_SO_RETURN_APPLY_INFO.BILL_TYPE_ID is '业务单据类型：从库存模块的业务单据类型表获取，包括对应的ERP订单类型（8种）。'
/

comment on column V_SO_RETURN_APPLY_INFO.BILL_TYPE_CODE is '业务单据类型编码'
/

comment on column V_SO_RETURN_APPLY_INFO.BILL_TYPE_NAME is '业务单据类型名称'
/

comment on column V_SO_RETURN_APPLY_INFO.BILL_NUM is '单据号'
/

comment on column V_SO_RETURN_APPLY_INFO.BILL_STATUS is '单据状态：10制单 11已提交 12已审批'
/

comment on column V_SO_RETURN_APPLY_INFO.BILL_DATE is '单据日期'
/

comment on column V_SO_RETURN_APPLY_INFO.SALES_MAIN_TYPE is '营销大类编码'
/

comment on column V_SO_RETURN_APPLY_INFO.SALES_MAIN_TYPE_NAME is '营销大类名称'
/

comment on column V_SO_RETURN_APPLY_INFO.CUSTOMER_ID is '客户ID'
/

comment on column V_SO_RETURN_APPLY_INFO.CUSTOMER_CODE is '客户编码'
/

comment on column V_SO_RETURN_APPLY_INFO.CUSTOMER_NAME is '客户名称'
/

comment on column V_SO_RETURN_APPLY_INFO.ACCOUNT_ID is '帐户ID'
/

comment on column V_SO_RETURN_APPLY_INFO.ACCOUNT_CODE is '帐户编码'
/

comment on column V_SO_RETURN_APPLY_INFO.ACCOUNT_NAME is '帐户名称'
/

comment on column V_SO_RETURN_APPLY_INFO.SALES_CENTER_ID is '营销中心ID'
/

comment on column V_SO_RETURN_APPLY_INFO.SALES_CENTER_CODE is '营销中心编码'
/

comment on column V_SO_RETURN_APPLY_INFO.SALES_CENTER_NAME is '营销中心名称'
/

comment on column V_SO_RETURN_APPLY_INFO.RETURN_TYPE is '退货类型：完好、破损、残次'
/

comment on column V_SO_RETURN_APPLY_INFO.RETURN_TOTAL_AMOUNT is '退货总金额'
/

comment on column V_SO_RETURN_APPLY_INFO.DISCOUNT_PROVE_FLAG is '是否开折让证明'
/

comment on column V_SO_RETURN_APPLY_INFO.RECEIVED_DISCOUNT_PROVE_FLAG is '是否收到折让证明'
/

comment on column V_SO_RETURN_APPLY_INFO.REMARK is '备注'
/

comment on column V_SO_RETURN_APPLY_INFO.CANCEL_FLAG is '作废标识：0否，1-是。'
/

comment on column V_SO_RETURN_APPLY_INFO.GEN_SO_FLAG is '生成退货单标识：0-否，1-是'
/

comment on column V_SO_RETURN_APPLY_INFO.GEN_SO_DATE is '生成退货单日期'
/

comment on column V_SO_RETURN_APPLY_INFO.MIP_URL is 'MIP流程链接：在MIP中对应的退货申请链接地址'
/

comment on column V_SO_RETURN_APPLY_INFO.CREATED_BY is '创建人ID'
/

comment on column V_SO_RETURN_APPLY_INFO.CREATION_DATE is '创建日期'
/

comment on column V_SO_RETURN_APPLY_INFO.LAST_UPDATED_BY is '最后更新人'
/

comment on column V_SO_RETURN_APPLY_INFO.LAST_UPDATE_DATE is '最后更新日期'
/

comment on column V_SO_RETURN_APPLY_INFO.APPLY_LINE_ID is '退货申请行ID'
/

comment on column V_SO_RETURN_APPLY_INFO.APPLIED_PRICE is '申请价格'
/

comment on column V_SO_RETURN_APPLY_INFO.APPLIED_QTY is '申请数量'
/

comment on column V_SO_RETURN_APPLY_INFO.RETURN_AMOUNT is '退货金额'
/

comment on column V_SO_RETURN_APPLY_INFO.RETURN_REASON is '退货原因'
/

comment on column V_SO_RETURN_APPLY_INFO.DISCOUNT_RATE is '折扣率'
/

comment on column V_SO_RETURN_APPLY_INFO.MONTH_DISCOUNT_RATE is '月返'
/

comment on column V_SO_RETURN_APPLY_INFO.DISCOUNT_AMOUNT is '扣率折让金额'
/

comment on column V_SO_RETURN_APPLY_INFO.MONTH_DISCOUNT_AMOUNT is '月返金额'
/

comment on column V_SO_RETURN_APPLY_INFO.RECEIVE_INV_ID is '收货仓库ID'
/

comment on column V_SO_RETURN_APPLY_INFO.RECEIVE_INV_CODE is '收货仓库编码'
/

comment on column V_SO_RETURN_APPLY_INFO.RECEIVE_INV_NAME is '收货仓库名称'
/

comment on column V_SO_RETURN_APPLY_INFO.LINE_REMARK is '备注'
/

comment on column V_SO_RETURN_APPLY_INFO.TAX_CODE is '税码'
/

comment on column V_SO_RETURN_APPLY_INFO.TAX_RATE is '税率'
/

comment on column V_SO_RETURN_APPLY_INFO.PRICE_LIST_ID is '工程类型'
/

comment on column V_SO_RETURN_APPLY_INFO.PRICE_LINE_ID is '大盘简称'
/

comment on column V_SO_RETURN_APPLY_INFO.BIG_PANEL is '价格列表头ID'
/

comment on column V_SO_RETURN_APPLY_INFO.PROJECT_TYPE is '价格列表行ID'
/

comment on column V_SO_RETURN_APPLY_INFO.SO_ITEM_IDENTIFY is '物流鉴定结果'
/

comment on column V_SO_RETURN_APPLY_INFO.APPLY_LINE_DETAIL_ID is '退货申请行明细ID'
/

comment on column V_SO_RETURN_APPLY_INFO.ITEM_ID is '产品ID'
/

comment on column V_SO_RETURN_APPLY_INFO.ITEM_CODE is '产品编码'
/

comment on column V_SO_RETURN_APPLY_INFO.ITEM_NAME is '产品名称'
/

comment on column V_SO_RETURN_APPLY_INFO.ITEM_QTY is '产品数量'
/

comment on column V_SO_RETURN_APPLY_INFO.ITEM_UOM is '产品单位'
/

comment on column V_SO_RETURN_APPLY_INFO.ITEM_PRICE is '产品价格'
/

comment on column V_SO_RETURN_APPLY_INFO.ITEM_STATUS is '产品状态（物料状态）：完好、破损、残次'
/

comment on column V_SO_RETURN_APPLY_INFO.COMPONENT_ID is '散件产品ID'
/

comment on column V_SO_RETURN_APPLY_INFO.COMPONENT_CODE is '散件产品编码'
/

comment on column V_SO_RETURN_APPLY_INFO.COMPONENT_NAME is '散件产品名称'
/

comment on column V_SO_RETURN_APPLY_INFO.COMPONENT_QTY is '散件产品数量'
/

comment on column V_SO_RETURN_APPLY_INFO.COMPONENT_UOM is '散件产品单位'
/

comment on column V_SO_RETURN_APPLY_INFO.COMPONENT_PRICE is '散件产品价格'
/

comment on column V_SO_RETURN_APPLY_INFO.RECEIVED_QTY is '实际签收数量：退货签收数量'
/

comment on column V_SO_RETURN_APPLY_INFO.TO_SO_RETURN_QTY is '已转退货单数量：即已用于开退货单的数量'
/

comment on column V_SO_RETURN_APPLY_INFO.DETAIL_REMARK is '备注'
/

