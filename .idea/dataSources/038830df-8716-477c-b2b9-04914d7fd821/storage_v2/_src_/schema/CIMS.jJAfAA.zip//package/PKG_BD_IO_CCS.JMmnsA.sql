create PACKAGE PKG_BD_IO_CCS 
AS
  
  --取客户对应的价格列表ID,返回0表示找不到
  FUNCTION F_GET_PRICE_LIST_ID
  (
    IN_ENTITY_ID          NUMBER    --主体ID
    ,IS_SALES_CENTER_CODE VARCHAR2  --营销中心编码
    ,IS_CUSTOMER_CODE     VARCHAR2  --客户编码
    ,ID_DATA_DATE         DATE     DEFAULT TRUNC(SYSDATE)   --取数据日期
  )
  RETURN NUMBER;

END PKG_BD_IO_CCS;
/

