create view V_CUSTOMER_HEADER as
select CUSTOMER_ID,
       CUSTOMER_CODE,
       CUSTOMER_NAME,
       CUSTOMER_SHORT_NAME,
       CUSTOMER_PHONES,
       CUSTOMER_FAX,
       CUSTOMER_MAIL,
       CUSTOMER_POSTAL_CODE,
       CUSTOMER_REGIST_ADDRESS,
       CUSTOMER_BUSINESS_LICENSE,
       CUSTOMER_ORGANIZATION_CODE,
       CUSTOMER_REGISTRATION_CODE,
       CUSTOMER_ENTERPRISE_NATURE,
       CUSTOMER_REGISTERED_FUNDS,
       CUSTOMER_REGISTRATION,
       CUSTOMER_LEGAL_PERSON,
       CUSTOMER_REGISTRATION_TYPE,
       CUSTOMER_FOUNDED_DATE,
       CUSTOMER_STATUS,
       CUSTOMER_COMMENTS,
       CUSTOMER_IS_TOP,
       CUSTOMER_IS_VENDOR,
       CUSTOMER_VENDOR_CODE,
       CUSTOMER_IS_INTERNAL,
       CUSTOMER_IS_AFTERSALES,
       CUSTOMER_PROP_COUNT,
       CUSTOMER_REGIST_COUNTRY,
       CUSTOMER_REGIST_PROVINCE,
       CUSTOMER_REGIST_CITY,
       CUSTOMER_REGIST_AREA,
       CUSTOMER_REGIST_TOWNS,
       CUSTOMER_REGADDRESS_COMMENTS,
       CUSTOMER_URL,
       CREATED_BY,
       CREATION_DATE,
       LAST_UPDATE_DATE,
       LAST_UPDATE_BY,
       LAST_INTERFACE_DATE,
       CUSTOMER_SYSTEM_NAME,
       CUSTOMER_FATHER_CODE,
       CUSTOMER_MANAGER,
       CUSTOMER_MANAGER_PHONES,
       CUSTOMER_OFFICE_ADDRESS,
       SIEBEL_CUSTOMER_ID,
       IS_VIRTUAL_CUSTOMER,
       ACTIVE_FLAG,
       PRE_FIELD_01,
       PRE_FIELD_02,
       PRE_FIELD_03,
       PRE_FIELD_04,
       PRE_FIELD_05,
       PRE_FIELD_06,
       CUSTOMER_USCC
  from T_CUSTOMER_HEADER with read only
/

comment on column V_CUSTOMER_HEADER.CUSTOMER_ID is '客户ID'
/

comment on column V_CUSTOMER_HEADER.CUSTOMER_CODE is '客户编码'
/

comment on column V_CUSTOMER_HEADER.CUSTOMER_NAME is '客户名称'
/

comment on column V_CUSTOMER_HEADER.CUSTOMER_SHORT_NAME is '客户简称'
/

comment on column V_CUSTOMER_HEADER.CUSTOMER_PHONES is '客户电话'
/

comment on column V_CUSTOMER_HEADER.CUSTOMER_FAX is '传真'
/

comment on column V_CUSTOMER_HEADER.CUSTOMER_MAIL is '电子邮箱'
/

comment on column V_CUSTOMER_HEADER.CUSTOMER_POSTAL_CODE is '邮政编码'
/

comment on column V_CUSTOMER_HEADER.CUSTOMER_REGIST_ADDRESS is '注册地址'
/

comment on column V_CUSTOMER_HEADER.CUSTOMER_BUSINESS_LICENSE is '企业营业执照注册号'
/

comment on column V_CUSTOMER_HEADER.CUSTOMER_ORGANIZATION_CODE is '组织机构代码'
/

comment on column V_CUSTOMER_HEADER.CUSTOMER_REGISTRATION_CODE is '纳税登记编号'
/

comment on column V_CUSTOMER_HEADER.CUSTOMER_ENTERPRISE_NATURE is '企业性质'
/

comment on column V_CUSTOMER_HEADER.CUSTOMER_REGISTERED_FUNDS is '注册资金'
/

comment on column V_CUSTOMER_HEADER.CUSTOMER_REGISTRATION is '纳税登记人'
/

comment on column V_CUSTOMER_HEADER.CUSTOMER_LEGAL_PERSON is '法人代表'
/

comment on column V_CUSTOMER_HEADER.CUSTOMER_REGISTRATION_TYPE is '纳税人类型'
/

comment on column V_CUSTOMER_HEADER.CUSTOMER_FOUNDED_DATE is '成立时间'
/

comment on column V_CUSTOMER_HEADER.CUSTOMER_STATUS is '客户状态'
/

comment on column V_CUSTOMER_HEADER.CUSTOMER_COMMENTS is '备注'
/

comment on column V_CUSTOMER_HEADER.CUSTOMER_IS_TOP is '是否TOP客户(Y/N)'
/

comment on column V_CUSTOMER_HEADER.CUSTOMER_IS_VENDOR is '是否供应商(Y/N)'
/

comment on column V_CUSTOMER_HEADER.CUSTOMER_VENDOR_CODE is '供应商编码'
/

comment on column V_CUSTOMER_HEADER.CUSTOMER_IS_INTERNAL is '是否集团内客户(Y/N)'
/

comment on column V_CUSTOMER_HEADER.CUSTOMER_IS_AFTERSALES is '是否有售后资质(Y/N)'
/

comment on column V_CUSTOMER_HEADER.CUSTOMER_PROP_COUNT is '自营店数'
/

comment on column V_CUSTOMER_HEADER.CUSTOMER_REGIST_COUNTRY is '注册区域-国家'
/

comment on column V_CUSTOMER_HEADER.CUSTOMER_REGIST_PROVINCE is '注册区域-省份'
/

comment on column V_CUSTOMER_HEADER.CUSTOMER_REGIST_CITY is '注册区域-地级市'
/

comment on column V_CUSTOMER_HEADER.CUSTOMER_REGIST_AREA is '注册区域-县区'
/

comment on column V_CUSTOMER_HEADER.CUSTOMER_REGIST_TOWNS is '注册区域-乡镇'
/

comment on column V_CUSTOMER_HEADER.CUSTOMER_REGADDRESS_COMMENTS is '注册区域-地址备注'
/

comment on column V_CUSTOMER_HEADER.CUSTOMER_URL is 'URL'
/

comment on column V_CUSTOMER_HEADER.CREATED_BY is '创建人'
/

comment on column V_CUSTOMER_HEADER.CREATION_DATE is '创建日期'
/

comment on column V_CUSTOMER_HEADER.LAST_UPDATE_DATE is '最后修改时间'
/

comment on column V_CUSTOMER_HEADER.LAST_UPDATE_BY is '最后修改人'
/

comment on column V_CUSTOMER_HEADER.LAST_INTERFACE_DATE is '最后同步时间'
/

comment on column V_CUSTOMER_HEADER.CUSTOMER_SYSTEM_NAME is '客户系名称'
/

comment on column V_CUSTOMER_HEADER.CUSTOMER_FATHER_CODE is '父客户编码'
/

comment on column V_CUSTOMER_HEADER.CUSTOMER_MANAGER is '负责人'
/

comment on column V_CUSTOMER_HEADER.CUSTOMER_MANAGER_PHONES is '负责人电话'
/

comment on column V_CUSTOMER_HEADER.CUSTOMER_OFFICE_ADDRESS is '办公地址'
/

comment on column V_CUSTOMER_HEADER.SIEBEL_CUSTOMER_ID is '主数据客户ID'
/

comment on column V_CUSTOMER_HEADER.IS_VIRTUAL_CUSTOMER is '是否虚拟客户'
/

comment on column V_CUSTOMER_HEADER.ACTIVE_FLAG is '是否有效(Y/N)'
/

comment on column V_CUSTOMER_HEADER.PRE_FIELD_01 is '客户类型（销售客户/虚拟客户/工厂客户）'
/

comment on column V_CUSTOMER_HEADER.PRE_FIELD_02 is '预留字段2'
/

comment on column V_CUSTOMER_HEADER.PRE_FIELD_03 is '预留字段3'
/

comment on column V_CUSTOMER_HEADER.PRE_FIELD_04 is '预留字段4'
/

comment on column V_CUSTOMER_HEADER.PRE_FIELD_05 is '预留字段5'
/

comment on column V_CUSTOMER_HEADER.PRE_FIELD_06 is '预留字段6'
/

comment on column V_CUSTOMER_HEADER.CUSTOMER_USCC is '统一社会信用代码'
/

