create view V_CUSTOMER_ACCOUNT as
select A.ACCOUNT_ID,
       A.ENTITY_ID,
       A.ACCOUNT_CODE,
       A.ACCOUNT_NAME,
       A.ACCOUNT_STATUS,
       A.CUSTOMER_ID,
       A.CUSTOMER_CODE,
       A.APPROVE_STATUS,
       A.APPROVE_OPINION,
       A.LAST_APPROVE_TIME,
       A.CREATED_BY,
       A.CREATION_DATE,
       A.LAST_UPDATE_BY,
       A.LAST_UPDATE_DATE,
       A.ACTIVE_FLAG,
       A.PRE_FIELD_01,
       A.PRE_FIELD_02,
       A.PRE_FIELD_03,
       A.PRE_FIELD_04,
       A.PRE_FIELD_05,
       A.PRE_FIELD_06,
       U.UNIT_TYPE
  from T_CUSTOMER_ACCOUNT A,
       UP_ORG_UNIT U
 where A.SALES_CENTER_CODE = U.CODE(+)
with read only
/

comment on column V_CUSTOMER_ACCOUNT.ACCOUNT_ID is '账户ID'
/

comment on column V_CUSTOMER_ACCOUNT.ENTITY_ID is '主体ID'
/

comment on column V_CUSTOMER_ACCOUNT.ACCOUNT_CODE is '账户编码'
/

comment on column V_CUSTOMER_ACCOUNT.ACCOUNT_NAME is '账户名称'
/

comment on column V_CUSTOMER_ACCOUNT.ACCOUNT_STATUS is '账户状态(正常/失效)'
/

comment on column V_CUSTOMER_ACCOUNT.CUSTOMER_ID is '客户ID'
/

comment on column V_CUSTOMER_ACCOUNT.CUSTOMER_CODE is '客户编码'
/

comment on column V_CUSTOMER_ACCOUNT.APPROVE_STATUS is '审核状态'
/

comment on column V_CUSTOMER_ACCOUNT.APPROVE_OPINION is '审核意见'
/

comment on column V_CUSTOMER_ACCOUNT.LAST_APPROVE_TIME is '最终审核时间'
/

comment on column V_CUSTOMER_ACCOUNT.CREATED_BY is '创建人'
/

comment on column V_CUSTOMER_ACCOUNT.CREATION_DATE is '创建日期'
/

comment on column V_CUSTOMER_ACCOUNT.LAST_UPDATE_BY is '最后修改人'
/

comment on column V_CUSTOMER_ACCOUNT.LAST_UPDATE_DATE is '最后修改日期'
/

comment on column V_CUSTOMER_ACCOUNT.ACTIVE_FLAG is '是否有效(Y/N)'
/

comment on column V_CUSTOMER_ACCOUNT.PRE_FIELD_01 is '预留字段1'
/

comment on column V_CUSTOMER_ACCOUNT.PRE_FIELD_02 is '预留字段2'
/

comment on column V_CUSTOMER_ACCOUNT.PRE_FIELD_03 is '预留字段3'
/

comment on column V_CUSTOMER_ACCOUNT.PRE_FIELD_04 is '预留字段4'
/

comment on column V_CUSTOMER_ACCOUNT.PRE_FIELD_05 is '预留字段5'
/

comment on column V_CUSTOMER_ACCOUNT.PRE_FIELD_06 is '预留字段6'
/

comment on column V_CUSTOMER_ACCOUNT.UNIT_TYPE is '中心类型'
/

