create PACKAGE Body      PKG_BD_UTIL  AS

   function STR_SPLIT(P_LIST IN VARCHAR2,P_SEP IN VARCHAR2)
     RETURN T_VARRAY IS
      L_IDX PLS_INTEGER;
      V_LIST VARCHAR2(4000) := P_LIST;
      RES VARCHAR2(4000);
      J NUMBER(4):=1;
      CSTR T_VARRAY := T_VARRAY(); --声明集合
      BEGIN
        LOOP
            L_IDX := INSTR(V_LIST, P_SEP);
            IF L_IDX > 0 THEN
              RES := SUBSTR(V_LIST, 1, L_IDX - 1);
              CSTR.EXTEND(1);
              CSTR(J) := RES;
              V_LIST := SUBSTR(V_LIST, L_IDX + LENGTH(P_SEP));
            ELSE
              RES := V_LIST;
              CSTR.EXTEND(1);
              CSTR(J) := RES;
              EXIT;
            END IF;

            J :=J+1;

        END LOOP;
      RETURN CSTR;
    END;

   --防重校验
   /*
     p_request_id      交易号值
     p_check_table     校验表
     p_request_id_col  校验表交易号字段
     返回：重复Y，不重复N
   */
   FUNCTION F_BD_CHECK_REPEAT(p_request_id IN VARCHAR2
                             ,p_check_table IN VARCHAR2
                             ,p_request_id_col VARCHAR2 default 'trx_no'
                             )
    RETURN VARCHAR2 IS
    v_sql    VARCHAR2(400);
    v_cnt    NUMBER;
    v_output VARCHAR2(240) := 'Y';
  BEGIN
    IF p_request_id IS NOT NULL AND p_check_table IS NOT NULL THEN
      v_sql := 'select 1 from ' || p_check_table || ' where ' ||
               p_request_id_col || '= ' || chr(39) || p_request_id ||
               chr(39) || ' and rownum < 2 ';
      EXECUTE IMMEDIATE v_sql
        INTO v_cnt;
      IF nvl(v_cnt, 999) = 1 THEN
        v_output := 'Y';
      ELSE
        v_output := 'N';
      END IF;
    END IF;
    IF p_request_id IS NULL THEN
      v_output := '传入交易号(单据与)为空.';
    END IF;
    IF p_check_table IS NULL THEN
      v_output := '传入表名为空.';
    END IF;
    RETURN v_output;
  EXCEPTION
    WHEN no_data_found THEN
      RETURN 'N';
    WHEN OTHERS THEN
      RETURN substrb(SQLERRM, 1, 240);
  END ;

  --校验字符是否为数字
  --如果字段的值是数字，返回Y，否则返回N
  FUNCTION F_ISNUMERIC(P_STR IN VARCHAR2) RETURN VARCHAR2 IS
    V_FLOAT FLOAT;
  BEGIN
    IF P_STR IS NULL THEN
      RETURN 'N';
    ELSE
      BEGIN
        SELECT TO_NUMBER(P_STR) INTO V_FLOAT FROM DUAL;
      EXCEPTION
        WHEN INVALID_NUMBER THEN
          RETURN 'N';
      END;
      RETURN 'Y';
    END IF;
  END;

END PKG_BD_UTIL;
/

