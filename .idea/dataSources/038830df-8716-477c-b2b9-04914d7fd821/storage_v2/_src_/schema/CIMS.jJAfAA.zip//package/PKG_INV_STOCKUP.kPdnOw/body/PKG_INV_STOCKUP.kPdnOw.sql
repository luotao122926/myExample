create package body PKG_INV_STOCKUP is

  --**********************************************
  -- AUTHOR: 顾金兴
  -- LAST_UPDATE：2015-3-17
  -- PURPOSE:备货申请审核通过后插入运力接口表
  --**********************************************


 Procedure PLN_LG(p_headId        in number,
                  p_entity_id       in number, 
                  v_exception     out varchar2,
                  v_batch_num     out number
                        )  is
  
 
   v_info_date                  date;
    v_max_id                     number(22);
    v_cursor_row_item_code       varchar2(100);
    v_cursor_row_item_name       varchar2(100);
    v_cursor_row_transaction_uom varchar2(100);
    v_sql                        varchar2(2000);
    v_sql_nomonthsum             varchar2(2000);
    v_Lg_Ship_Pln_Id            number;
    v_is_data                    number;
    
    v_Sales_Main_Type            varchar2(240);
    v_Item_Uom                   varchar2(240);
    v_Is_Rounding                 varchar2(240);
    v_Rounding_Count              number;
    p_Result                      varchar2(240);
    v_Message                     varchar2(240);
    v_Ship_Doc_id                 number;
    v_Lg_Plan_Batch_num           number;
    
 
    
    Cursor c_lg_order_Line Is
    select * from t_pln_lg_order_head t where t.order_head_id= p_headId;
   
        r_lg_order_Line c_lg_order_Line%Rowtype;
    
    
    Cursor c_lg_order_Line_Line Is 
    select * from  t_pln_lg_order_line t1 where   t1.order_head_id = p_headId;
    r_lg_order_Line_Line c_lg_order_Line_Line%Rowtype;
    
    
    
 begin
   
     --select 1 into v_max_id from dual;
     Select s_Intf_Lg_Batch_Num.Nextval Into v_Lg_Plan_Batch_num From Dual;
     Select s_Intf_Lg_Ship_Plan.Nextval
              Into v_Lg_Ship_Pln_Id
              From Dual;
     for row_one in (select * from t_pln_lg_order_line t where t.order_head_id=p_headId ) loop
        Select Bi.Sales_Main_Type,
               Bi.Defaultunit,
               Bi.Is_Rounding, --add by lizhen 2015-03-12 
               Bi.Rounding_Cnt --add by lizhen 2015-03-12 
          Into v_Sales_Main_Type,
               v_Item_Uom,
               v_Is_Rounding,
               v_Rounding_Count
          From t_Bd_Item Bi
         Where Bi.Entity_Id = p_Entity_Id
           And Bi.Item_Id = row_one.Item_Id;
       
           Open c_lg_order_Line;   
       loop    
           Fetch c_lg_order_Line
            Into r_lg_order_Line;
           Exit When c_lg_order_Line%Notfound;
          
         Insert Into Intf_Lg_Ship_Plan
              (Ship_Plan_Id, --发货计划号
               Entity_Id, --主体ID
               Sales_Main_Type, --营销大类
               Item_Code, --产品编码
               Item_Desc, --产品描述
               Item_Uom, --产品单位
               Item_Qty, --拆分后
               Item_Price, --产品价格
               Customer_Id, --客户ID
               Customer_Code, --客户编码
               Customer_Name, --客户名称
               Account_Code, --账户编码
               Customer_Contacts, --客户联系人
               Customer_Contacts_Phones, --客户联系人电话
               Origin_Origin_Type, --上级来源类型
               Origin_Origin_Order_Code, --上级来源编码
               Origin_Origin_Head_Id, --上级来源单据头ID
               Origin_Origin_Line_Id, --上级来源单据行ID
               Origin_Type, --01：计划订单 02：提货订单 03 ：调拨订单 04：促销品
               Origin_Order_Num, --来源单据号
               Origin_Order_Id, --来源单据头ID
               Origin_Line_Id, --来源单据行ID
               Origin_Ship_Plan_Id, --来源计划ID
               Ship_Way, --运输方式 01：汽运 02：海运 03：铁运 04:空运 05:快递 06 其他
               Ship_Type, --00 工厂发货 01省内发货 02异地调拨 03直发超市
               Load_Vehicle_Type, --装车类型 00整车 01零担
               Ship_Inventory_Id, --通过发货仓库ID
               Consignee_Inventory_Id, --收货仓库ID
               Sales_Order_Type_Id, --销售单据类型ID
               Settlement_Type, --00一般结算、01特批结算、02工程买断结算。
               Consignee_Location_Code, --收货地点编码
               Consignee_Addr, --收货地址
               Consignee_Company_Id, --收货单位ID
               Consignee_Company_Code, --收货单位编码
               Consignee_Company_Name, --收货单位名称
               Consignee_Company_Addr, --收货单位地址
               Consignee_Company_Contact_Id, --收货单位联系人ID
               Consignee_Company_Contract, --收货单位联系人
               Consignee_Company_Tel, --收货单位联系电话
               Sales_Center_Id, --所在营销中心ID
               Sales_Center_Code, --营销中心编码
               Sales_Center_Name, --所在营销中心名称
               Ship_Info_Date, --生成发货通知单日期
               Require_Ship_Date, --要求发货日期
               Require_Arrive_Date, --要求到货日期
               Pick_Flag, --自提标识 Y：是  N：否
               Is_Cusg_Flag, --是否直发标志
               Transfer_Customer_Id, --直发客户ID
               Transfer_Customer_Code, --直发客户编码
               Transfer_Customer_Name, --直发客户名称
               Base_Allot_Flag, --基地间调拨
               Status, --状态 00：未同步 01：已同步
               Month_Discount_Rate, --月返
               Discount_Rate, --扣率
               Materials_Flag, --是否有物料
               Remark, --备注
               Created_By, --创建人
               Creation_Date, --创建日期
               Last_Updated_By, --最后更新人
               Last_Update_Date, --最后更新时间
               Customer_Order_Number, --客户单号
               BATCH_DEAL_NUM --批量处理编号
               ) 
               Select s_Intf_Lg_Ship_Plan.Nextval, --发货计划号ID
                     r_lg_order_Line.Entity_Id, --主体ID
                     r_lg_order_Line.Sales_Main_Type,--营销大类
                      
                     row_one.Item_Code, --产品编码

                     row_one.Item_Name, --产品描述
                     v_Item_Uom, --产品单位
                     row_one.Affirm_Quantity, --拆分后
                    row_one.List_Price,--产品价格
                     r_lg_order_Line.Customer_Id, --客户ID
                     r_lg_order_Line.Customer_Code, --客户编码
                     r_lg_order_Line.Customer_Name, --客户名称
                     r_lg_order_Line.Account_Code, --账户编码
                     r_lg_order_Line.Invoice_Contract, --客户联系人
                     r_lg_order_Line.Invoice_Tel, --客户联系人电话
                     Null, --Origin_Origin_Type, --上级来源类型
                     Null, --Origin_Origin_Order_Code, --上级来源编码
                     Null, --Origin_Origin_Head_Id, --上级来源单据头ID
                     Null, --Origin_Origin_Line_Id, --上级来源单据行ID
                     '05', --Origin_Type, --01：计划订单 02：提货订单 03 ：调拨订单 04：促销品
                     r_lg_order_Line.Order_Number, --Origin_Order_Num, --来源单据号
                     r_lg_order_Line.Order_Head_Id, --Origin_Order_Id, --来源单据头ID
                     row_one.Order_Line_Id, --Origin_Line_Id, --来源单据行ID
                     Null, --Origin_Ship_Plan_Id, --来源计划ID
                     r_lg_order_Line.Ship_Mode, --Ship_Way, --运输方式 01：汽运 02：海运 03：铁运 04:空运 05:快递 06 其他
                     '01', --Ship_Type, --01 工厂发货 02省内发货 03异地调拨 04直发超市
                     '01', --Load_Vehicle_Type, --装车类型 01整车 02零担
                     row_one.Inv_Id, --Ship_Inventory_Id, --通过发货仓库ID
                     r_lg_order_Line.Inventory_To_Id,--Consignee_Inventory_Id, --收货仓库ID
                     row_one.Sales_Order_Type_Id, --销售单据类型ID
                     '00', --Settlement_Type, --00一般结算、01特批结算、02工程买断结算。
                     r_lg_order_Line.Consignee_Addr_Code, --Consignee_Location_Code, --收货地点编码          
                     r_lg_order_Line.Consignee_Addr_Name, -- Consignee_Addr, --收货地址
                     r_lg_order_Line.Consignee_Id, --Consignee_Company_Id, --收货单位ID
                     r_lg_order_Line.Consignee_Code, --Consignee_Company_Code, --收货单位编码
                     r_lg_order_Line.Consignee_Name, --Consignee_Company_Name, --收货单位名称
                     r_lg_order_Line.Consignee_Addr_Name, --Consignee_Company_Addr, --收货单位地址
                     r_lg_order_Line.Consignee_Contact_Id, --Consignee_Company_Contact_Id, --收货单位联系人ID
                     r_lg_order_Line.Consignee_Contract, --Consignee_Company_Contract, --收货单位联系人
                     r_lg_order_Line.Consignee_Tel, --Consignee_Company_Tel, --收货单位联系电话
                     r_lg_order_Line.Sales_Center_Id, --所在营销中心ID
                     r_lg_order_Line.Sales_Center_Code, --营销中心编码
                     r_lg_order_Line.Sales_Center_Name, --所在营销中心名称
                     Trunc(Sysdate), --Ship_Info_Date, --生成发货通知单日期
                     Trunc(Sysdate), --Require_Ship_Date, --要求发货日期
                     Trunc(Sysdate), --Require_Arrive_Date, --要求到货日期
                     'N', --自提标识 Y：是  N：否
                     Nvl(r_lg_order_Line.Direct_Send_Flag, 'N'), --是否直发标志
                     null, --直发客户ID
                     null, --直发客户编码
                     null, --直发客户名称
                     Null, --Base_Allot_Flag, --基地间调拨
                     '00', --Status, --状态 00：未同步 01：已同步
                     null, --Month_Discount_Rate, --月返
                     null, --扣率
                     Null, --Materials_Flag, --是否有物料
                     row_one.Remark, --备注
                     r_lg_order_Line.Created_By, --Created_By, --创建人
                     Sysdate, --Creation_Date, --创建日期
                     row_one.last_updated_by, --Last_Updated_By, --最后更新人
                     Sysdate, --Last_Update_Date
                     r_lg_order_Line.Customer_Order_Number,  --客户单号
                     v_Lg_Plan_Batch_num --批量处理编号
                From Dual;  
            end loop;  
            close c_lg_order_Line;
         /* Pkg_Lg_Ship.p_Lg_Generation_Ship_Plan(v_Lg_Ship_Pln_Id, --接口表ID                                   
                                                  r_lg_order_Line.Created_By, --用户编码
                                                  v_exception,
                                                  v_Message,
                                                  v_Ship_Doc_id);
          if v_exception <> '1' then
            rollback;
            v_exception := '生成运力任务计划失败，' || v_Message ||Sqlerrm;
            return;
          end if;
          */
     end loop;
     v_exception :='seuccess';
     v_batch_num :=v_Lg_Plan_Batch_num;
     Exception
     When Others Then
              rollback;
              v_exception :='插入运力任务接口表失败。'||Sqlerrm;
              v_batch_num := -1;
             return;
     
   end;
   
  --***************************************************************
  -- AUTHOR: 顾金兴
  -- LAST_UPDATE：2015-3-18
  -- PURPOSE:备货申请通过或驳回后对当前可用额度进行加减
  --***************************************************************
   
   
   Procedure COUNT_QUOTA(p_headId  in number,
                         p_custCode in varchar2,
                         p_salesMainType in varchar2,
                         p_isCheckOrBack in varchar2,
                         v_exception out varchar2
                          ) is
       temp              number;
       quota_curr        number;
       
    begin
          
            begin
              temp:=0;
                         for one_object in (select l.quantity * l.list_price count_price from t_pln_lg_order_line l where l.order_head_id = p_headId) loop
                            temp:=temp+one_object.count_price;
                  
                         end loop;
            end;
            begin
                         select l.stockup_quota_curr into quota_curr
                   from t_inv_stockup_quota_line l
                  where l.stockup_quota_id =
                        (select a.stockup_quota_id
                           from t_inv_stockup_quota a
                          where a.cust_code = p_custCode
                            and a.stockup_quota_type = '0'
                            and a.status = '23')
                       
                    and l.sales_main_type = p_salesMainType;
            exception
            when others then
              rollback;
              v_exception:='查询该客户当前大类额度失败'||sqlerrm;
              return;
            end;
            
            if p_isCheckOrBack ='toCheck' then
                    begin
                          update t_inv_stockup_quota_line tl
                             set tl.stockup_quota_curr = quota_curr-temp
                          
                           where tl.stockup_quota_id =
                                 (select a.stockup_quota_id
                                    from t_inv_stockup_quota a
                                   where a.cust_code = p_custCode
                                     and a.stockup_quota_type = '0'
                                     and a.status = '23')
                             and tl.sales_main_type = p_salesMainType;
                    exception
                    when others then 
                    rollback;  
                    v_exception:='计算额度后，更新字段有误'||sqlerrm;
                    return;
                    end;
          else
            begin
                          update t_inv_stockup_quota_line tl
                             set tl.stockup_quota_curr = quota_curr+temp
                          
                           where tl.stockup_quota_id =
                                 (select a.stockup_quota_id
                                    from t_inv_stockup_quota a
                                   where a.cust_code = p_custCode
                                     and a.stockup_quota_type = '0'
                                     and a.status = '23')
                             and tl.sales_main_type = p_salesMainType;
            exception
            when others then 
              rollback;  
              v_exception:='计算额度后，更新字段有误'||sqlerrm;
              return;
            end;
          end if;
            
            
            
      v_exception:='seuccess';      
    end;       
    Procedure p_Upd_Lgorder_Affirm_Qty(p_Lgorder_Line_Id   In Number, --行ID     
                                     p_Send_Inventory_Id In Number, --发货仓库ID                                                                                                
                                     p_Trans_Order_Qty   In Number, --运力任务取消数量 
                                     p_Entity_Id         In Number, --主体ID
                                     p_User_Code         In Varchar2, --用户编码
                                     p_Result            Out Varchar2 --成功返回'SUCCESS' 否则返回错误信息
                                     ) is
      v_Affirmed_Qty number;  
      v_cancel_qty   number;
      one_row_line t_Pln_Lg_Order_Line%rowtype;
                                   
    begin
         begin
                 select * into one_row_line from t_Pln_Lg_Order_Line l where l.order_line_id=p_Lgorder_Line_Id;
         exception
           when others then
             rollback;
             p_Result :='根据入参行ID找不到指定的行。';
             return;
         end;
         if p_Trans_Order_Qty<=0 then
           rollback;
           p_Result :='取消的数量不能为负数或者是0。';
           return;
         end if;
      
         begin
                      --更新行表的已评审数量
              Update t_Pln_Lg_Order_Line Lol
                 Set Lol.CANCEL_QTY = Nvl(Lol.CANCEL_QTY, 0) +
                                             p_Trans_Order_Qty,
                     Lol.Last_Update_Date  = Sysdate,
                     Lol.Last_Updated_By   = p_User_Code,
                     Lol.Version = Nvl(Lol.Version, 0) + 1
               Where Lol.Order_Line_Id = p_Lgorder_Line_Id
               Returning Lol.CANCEL_QTY Into v_cancel_qty;
               
              
              If Nvl(v_cancel_qty, 0) < 0 Then
                rollback;
                p_Result := '更新失败，备货申请单行表更新后的取消数量为负数！' || '更新后的取消数量：' || To_Char(v_Affirmed_Qty);
                return;
              End If;
              if nvl(v_cancel_qty,0) > one_row_line.affirm_quantity then
                rollback;
                p_Result :='更新失败，备货申请单行表更新后的评审数量为负数！' || '原因：本张单总共取消的数量大于已评审的数量。已评审的数量为：' || one_row_line.affirm_quantity|| '，而总共取消的数量为：'||nvl(v_cancel_qty,0)||'，请了解！';
                return;
              end if;  
        exception
          when others then
            rollback;
            p_Result :='更新失败，相关代码'||sqlerrm;
            return;
        end;
         p_Result :='seuccess';
    end;
               
end PKG_INV_STOCKUP;
/

