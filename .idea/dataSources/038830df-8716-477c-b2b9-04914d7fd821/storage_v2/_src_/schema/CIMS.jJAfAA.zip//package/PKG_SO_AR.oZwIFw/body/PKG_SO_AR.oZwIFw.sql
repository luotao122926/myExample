create PACKAGE BODY      PKG_SO_AR IS
  /*----------------------------------------------------------------
  *         包：PKG_SO_AR
  *   创建日期：2014-08-16
  *     创建者：廖丽章
  *   功能说明：1、销售单据结算触发相关业务处理。
  *
  *   过程成功：P_RESULT = 0
  *             P_ERR_MSG = 'SUCCESS';
  *
  *   过程失败：P_RESULT < -20000;
  *             P_ERR_MSG = 过程异常失败的提示信息
  *
  */ ----------------------------------------------------------------

  V_CURR_USER_CODE VARCHAR2(200) := ''; --当前操作用户编码
  V_DATA_FORMAT CONSTANT VARCHAR2(10) := 'YYYY-MM-DD'; --日期格式

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-08-16
  *     创建者：廖丽章
  *   功能说明：财务单据结算
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_SETTLE(P_INVOICE_APPLY_ID IN NUMBER, --开票申请ID
                        P_USER_CODE        IN VARCHAR2, --操作用户编码
                        P_RESULT           OUT NUMBER, --返回错误ID
                        P_ERR_MSG          OUT VARCHAR2 --返回错误信息
                        ) IS
    --开票申请ID（临时变量，用于进行并发控制）
    TMP_INVOICE_APPLY_ID NUMBER; 
   
    --开票申请单
    CURSOR C_INVOICE_APPLY IS
      SELECT *
        FROM T_AR_INVOICE_APPLY_HEADER
       WHERE INVOICE_APPLY_ID = P_INVOICE_APPLY_ID;
    --开票申请单记录
    R_INVOICE_APPLY C_INVOICE_APPLY%ROWTYPE;
  
    --销售单据
    CURSOR C_SO_HEADER IS
      SELECT *
        FROM T_SO_HEADER
       WHERE INVOICE_APPLY_ID = P_INVOICE_APPLY_ID
       ORDER BY BILL_TYPE_CODE;
    --销售单据记录集
    R_SO_HEADER C_SO_HEADER%ROWTYPE;
  
    --当前时间
    V_CURR_DATE DATE;
  
  BEGIN
    --初始返回值
    P_RESULT  := PKG_SO_PUB.V_RESULT;
    P_ERR_MSG := PKG_SO_PUB.V_SUCCESS;
  
    --当前操作用户编码
    V_CURR_USER_CODE := P_USER_CODE;
    V_CURR_DATE      := SYSDATE;
  
    OPEN C_INVOICE_APPLY;
    FETCH C_INVOICE_APPLY
      INTO R_INVOICE_APPLY;
    CLOSE C_INVOICE_APPLY;
    
    --并发控制
    BEGIN
      SELECT INVOICE_APPLY_ID
        INTO TMP_INVOICE_APPLY_ID 
        FROM T_AR_INVOICE_APPLY_HEADER
       WHERE INVOICE_APPLY_ID = P_INVOICE_APPLY_ID
         FOR UPDATE NOWAIT;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        P_RESULT  := -28000;
        P_ERR_MSG := '当前开票申请[ID：' || P_INVOICE_APPLY_ID || ']不存在，请检查！';
      WHEN OTHERS THEN
        P_RESULT  := -28000;
        P_ERR_MSG := '当前开票申请[ID：' || P_INVOICE_APPLY_ID ||
                     ']正被其他用户使用，请稍后再试 ！';
    END;
    
    IF P_RESULT < 0 THEN
      RETURN;
    END IF;
    --并发控制结束    
  
    --未审批通过的开票申请单，不能进行结算
    IF R_INVOICE_APPLY.INVOICE_APPLY_STATUS != '11' THEN
      P_ERR_MSG := '未审批通过的开票申请单，不能进行结算。';
      RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
    END IF;
  
    FOR R_SO_HEADER IN C_SO_HEADER LOOP
      IF P_USER_CODE = 'SYS' THEN  --如果是自动结算
        BEGIN
          SAVEPOINT SUCCESS_FLAG;
          --如果财务单还没有审核通过，则不能进行结算
          IF R_SO_HEADER.SO_STATUS = PKG_SO_PUB.V_CREATED THEN
            P_ERR_MSG := '财务单[单据号：' || R_SO_HEADER.SO_NUM || ']未审核，不能进行结算。';
            RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
          ELSIF R_SO_HEADER.SO_STATUS = PKG_SO_PUB.V_SETTLED THEN
            P_ERR_MSG := '财务单[单据号：' || R_SO_HEADER.SO_NUM || ']已结算，不能重复结算。';
            RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
          ELSIF R_SO_HEADER.SO_STATUS != PKG_SO_PUB.V_AUDITED THEN
            P_ERR_MSG := '财务单[单据号：' || R_SO_HEADER.SO_NUM ||
                         ']的状态不正确（单据只有三种状态：10制单、11已审核、12已结算）。';
            RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
          END IF;

          --对财务单进行结算处理
          P_SO_SETTLE_PROCESS(R_SO_HEADER, P_RESULT, P_ERR_MSG);
          --根据P_RESULT判断是否抛出异常
          PKG_SO_PUB.P_EXCEPTION_THROWS(P_RESULT);
        EXCEPTION
          WHEN PKG_SO_PUB.V_BIZ_EXCEPTION THEN
            ROLLBACK TO SUCCESS_FLAG;
            UPDATE T_SO_HEADER T
               SET T.INVOICE_APPLY_ID = NULL, T.SETTLE_DATE = NULL
             WHERE T.SO_HEADER_ID = R_SO_HEADER.SO_HEADER_ID;
            P_ERR_MSG := PKG_BD.F_ADD_ERROR_LOG('PKG_SO_AR.P_SO_SETTLE',
                                                SQLCODE,
                                                '销售单' ||
                                                R_SO_HEADER.SO_HEADER_ID ||
                                                '结算失败：' || P_ERR_MSG);
          
            GOTO HEADER;
        END;
      ELSE   --手动结算
          --如果财务单还没有审核通过，则不能进行结算
          IF R_SO_HEADER.SO_STATUS = PKG_SO_PUB.V_CREATED THEN
            P_ERR_MSG := '财务单[单据号：' || R_SO_HEADER.SO_NUM || ']未审核，不能进行结算。';
            RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
          ELSIF R_SO_HEADER.SO_STATUS = PKG_SO_PUB.V_SETTLED THEN
            P_ERR_MSG := '财务单[单据号：' || R_SO_HEADER.SO_NUM || ']已结算，不能重复结算。';
            RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
          ELSIF R_SO_HEADER.SO_STATUS != PKG_SO_PUB.V_AUDITED THEN
            P_ERR_MSG := '财务单[单据号：' || R_SO_HEADER.SO_NUM ||
                         ']的状态不正确（单据只有三种状态：10制单、11已审核、12已结算）。';
            RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
          END IF;
        
          --对财务单进行结算处理
          P_SO_SETTLE_PROCESS(R_SO_HEADER, P_RESULT, P_ERR_MSG);
          --根据P_RESULT判断是否抛出异常
          PKG_SO_PUB.P_EXCEPTION_THROWS(P_RESULT);      
      END IF;
      --红蓝完全对冲处理（红冲单结算时执行）
      IF (R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE IN
         (PKG_SO_PUB.V_BIZ_SRC_BILL_SO_RED,
           PKG_SO_PUB.V_BIZ_SRC_BILL_RETURN_RED,
           PKG_SO_PUB.V_BIZ_SRC_BILL_SO_DISCOUNT_RED,
           PKG_SO_PUB.V_BIZ_SRC_BILL_DISCOUNT_RED)) THEN
        --红蓝完全对冲的时候，将蓝单及其对应的全部红冲单发票号置成0000
        P_SO_WHOLE_REVERSAL(R_SO_HEADER, P_RESULT, P_ERR_MSG);
        --根据P_RESULT判断是否抛出异常
        PKG_SO_PUB.P_EXCEPTION_THROWS(P_RESULT);
      END IF;
      <<HEADER>>
      NULL;
    END LOOP;
  
    --更新开票申请为已结算状态
    UPDATE T_AR_INVOICE_APPLY_HEADER
       SET INVOICE_APPLY_STATUS = '12',
           IS_SETTLE            = PKG_SO_PUB.V_YES,
           SETTLE_BY            = V_CURR_USER_CODE,
           SETTLE_DATE          = V_CURR_DATE
     WHERE INVOICE_APPLY_ID = P_INVOICE_APPLY_ID;
  
  EXCEPTION
    WHEN PKG_SO_PUB.V_BIZ_EXCEPTION THEN
      P_RESULT  := -28206;
      P_ERR_MSG := '对开票申请的财务单据结算[开票申请ID：' || P_INVOICE_APPLY_ID || ']出错：' ||
                   P_ERR_MSG;
    WHEN OTHERS THEN
      P_RESULT  := -28206;
      P_ERR_MSG := '对开票申请的财务单据结算[开票申请ID：' || P_INVOICE_APPLY_ID || ']发生异常！' ||
                   SQLERRM;
  END;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-08-16
  *     创建者：廖丽章
  *   功能说明：财务单据结算处理
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_SETTLE_PROCESS(P_SO_HEADER IN T_SO_HEADER%ROWTYPE, --销售单据头记录
                                P_RESULT    OUT NUMBER, --返回错误ID
                                P_ERR_MSG   OUT VARCHAR2 --返回错误信息
                                ) IS
    --主体ID
    V_ENTITY_ID NUMBER;
    --销售单据头ID
    V_SO_HEADER_ID NUMBER;
    --销售单据源类型编码
    V_BIZ_SRC_TYPE T_SO_SRC_TYPE.SRC_TYPE_CODE%TYPE;
  
    --财务单行信息
    CURSOR C_SO_LINE_INFO IS
      SELECT SL.*,
             SC.DISCOUNT_RATE       AS DISCOUNT_RATE_NEW,
             SC.MONTH_DISCOUNT_RATE AS MONTH_DISCOUNT_RATE_NEW
        FROM T_SO_LINE SL
        LEFT JOIN T_AR_SO_CHANGE SC
          ON SC.SO_HEADER_ID = SL.SO_HEADER_ID
         AND SC.SO_LINE_ID = SL.SO_LINE_ID
       WHERE SL.SO_HEADER_ID = P_SO_HEADER.SO_HEADER_ID
         AND SC.INVOICE_APPLY_ID = P_SO_HEADER.INVOICE_APPLY_ID;
    --财务单行信息记录集
    R_SO_LINE_INFO C_SO_LINE_INFO%ROWTYPE;
  
    --业务单据类型扩展属性，这行扩展属性可用于控制一些业务逻辑。
    CURSOR C_SO_BILL_TYPE_EXTEND IS
      SELECT *
        FROM V_SO_BILL_TYPE_EXTEND
       WHERE BILL_TYPE_ID = P_SO_HEADER.BILL_TYPE_ID
         AND ENTITY_ID = P_SO_HEADER.ENTITY_ID
         AND (TRUNC(SYSDATE) BETWEEN BEGIN_DATE AND NVL(END_DATE, SYSDATE));
    --业务单据类型扩展属性记录
    R_SO_BILL_TYPE_EXTEND C_SO_BILL_TYPE_EXTEND%ROWTYPE;
  
    --产品价格、结算价格、结算总金额、折扣总金额、月返总金额、批文总金额
    V_ITEM_QTY                   NUMBER;
    V_ITEM_PRICE                 NUMBER;
    V_ITEM_SETTLE_PRICE          NUMBER;
    V_ITEM_SETTLE_AMOUNT         NUMBER;
    V_ITEM_DISCOUNT_AMOUNT       NUMBER;
    V_ITEM_MONTH_DISCOUNT_AMOUNT NUMBER;
  
    --财务单结算前结算总金额、折扣总金额
    V_SETTLE_AMOUNT_OLD   NUMBER;
    V_DISCOUNT_AMOUNT_OLD NUMBER;
    --财务单结算后结算总金额、折扣总金额
    V_SETTLE_AMOUNT_NEW   NUMBER;
    V_DISCOUNT_AMOUNT_NEW NUMBER;
    --财务单结算前后差额
    V_SETTLE_AMOUNT_DIFF   NUMBER;
    V_DISCOUNT_AMOUNT_DIFF NUMBER;
  
    --批文信息
    V_PROJECT_ID    NUMBER;
    V_PROJECT_PRICE NUMBER;
  
    --修改前的折扣率和月返
    V_DISCOUNT_RATE_OLD       NUMBER := 0;
    V_MONTH_DISCOUNT_RATE_OLD NUMBER := 0;
  
    --修改后的折扣率和月返
    V_DISCOUNT_RATE_NEW       NUMBER := 0;
    V_MONTH_DISCOUNT_RATE_NEW NUMBER := 0;
  
    --跟踪表行
    R_SO_TRACE      T_SO_TRACE%ROWTYPE;
    V_IS_SAVE_TRACE CHAR(1) := PKG_SO_PUB.V_NO;
  
    --当前时间
    V_CURR_TIME DATE := SYSDATE;
  
    --结算日期
    V_SETTLE_DATE DATE;
    --当前日期
    V_CURR_DATE DATE;
    --月末日期
    V_LAST_DAY DATE;
  
    --应收发票配置记录
    V_AR_CONFIG PKG_SO_PUB.AR_CONFIG;
  
    --是否修改了财务单的标识
    V_MODIFY_SO CHAR(1) := PKG_SO_PUB.V_NO;
  
    V_COUNT NUMBER; --查询记录条数
  
    V_PUSH_OR_PULL CHAR(30);
  
    V_PULL_MODE NUMBER;
    V_ENTITY_CUST_FLAG T_SO_HEADER.ENTITY_CUST_FLAG%TYPE;  --是否事业部客户
  BEGIN
    P_RESULT  := PKG_SO_PUB.V_RESULT;
    P_ERR_MSG := PKG_SO_PUB.V_SUCCESS;
    
    IF V_CURR_USER_CODE IS NULL THEN
      V_CURR_USER_CODE := 'SYS';
    END IF;
  
    --根据信用管理中的配置，如果客户需要校验应收，且存在应收的情况则不允许结算对应的财务单。
    P_SO_SETTLE_CHECK(P_SO_HEADER,P_RESULT,P_ERR_MSG);
    PKG_SO_PUB.P_EXCEPTION_THROWS(P_RESULT);
    OPEN C_SO_BILL_TYPE_EXTEND;
    FETCH C_SO_BILL_TYPE_EXTEND
      INTO R_SO_BILL_TYPE_EXTEND;
    CLOSE C_SO_BILL_TYPE_EXTEND;
  
    --主体ID
    V_ENTITY_ID := P_SO_HEADER.ENTITY_ID;
    --单据头ID
    V_SO_HEADER_ID := P_SO_HEADER.SO_HEADER_ID;
    --销售单据源类型
    V_BIZ_SRC_TYPE := P_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE;
  
    --财务单结算前结算总金额、折扣总金额
    SELECT ROUND(SUM(NVL(ITEM_SETTLE_AMOUNT, 0)),2), ROUND(SUM(NVL(DISCOUNT_AMOUNT, 0)),2)
      INTO V_SETTLE_AMOUNT_OLD, V_DISCOUNT_AMOUNT_OLD
      FROM T_SO_LINE
     WHERE SO_HEADER_ID = V_SO_HEADER_ID;
  
    --拉式时发往关联交易时需要取不含税价格，本过程针对拉式产品是否都配置了不含税价格
    --如果有产品没有设置不含税价格，则抛异常，需要配置不含税价格后再生成销售单
    --add by chen.wj 20150213
    pkg_so_pub.P_CHECK_NOT_REVENUE_PRICE(P_SO_HEADER.SO_HEADER_ID,P_RESULT,
                        P_ERR_MSG);
    PKG_SO_PUB.P_EXCEPTION_THROWS(P_RESULT);
  
    FOR R_SO_LINE_INFO IN C_SO_LINE_INFO LOOP
      V_IS_SAVE_TRACE := PKG_SO_PUB.V_NO;
    
      V_ITEM_QTY      := R_SO_LINE_INFO.ITEM_QTY;
      V_ITEM_PRICE    := R_SO_LINE_INFO.ITEM_PRICE;
      V_PROJECT_ID    := R_SO_LINE_INFO.PROJECT_ID;
      V_PROJECT_PRICE := R_SO_LINE_INFO.PROJECT_PRICE;
    
      --修改前的折扣率和月返
      V_DISCOUNT_RATE_OLD       := NVL(R_SO_LINE_INFO.DISCOUNT_RATE, 0);
      V_MONTH_DISCOUNT_RATE_OLD := NVL(R_SO_LINE_INFO.MONTH_DISCOUNT_RATE,
                                       0);
      --修改后的折扣率和月返
      V_DISCOUNT_RATE_NEW       := R_SO_LINE_INFO.DISCOUNT_RATE_NEW;
      V_MONTH_DISCOUNT_RATE_NEW := R_SO_LINE_INFO.MONTH_DISCOUNT_RATE_NEW;
      IF (NVL(V_DISCOUNT_RATE_NEW,0) < 0 OR NVL(V_DISCOUNT_RATE_NEW,0) > 100) THEN
        P_ERR_MSG := '销售单据结算，行产品[' || R_SO_LINE_INFO.ITEM_CODE || ',' || R_SO_LINE_INFO.ITEM_NAME || ']折扣[' || NVL(V_DISCOUNT_RATE_NEW,0) || ']不合理!';
        RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      END IF;
      IF (NVL(V_MONTH_DISCOUNT_RATE_NEW,0) < 0 OR NVL(V_MONTH_DISCOUNT_RATE_NEW,0) > 100) THEN
        P_ERR_MSG := '销售单据结算，行产品[' || R_SO_LINE_INFO.ITEM_CODE || ',' || R_SO_LINE_INFO.ITEM_NAME || ']月返[' || NVL(V_MONTH_DISCOUNT_RATE_NEW,0) || ']不合理!';
        RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      END IF;
      IF (NVL(V_DISCOUNT_RATE_NEW,0) + NVL(V_MONTH_DISCOUNT_RATE_NEW,0) > 100) THEN
        P_ERR_MSG := '销售单据结算，行产品[' || R_SO_LINE_INFO.ITEM_CODE || ',' || R_SO_LINE_INFO.ITEM_NAME || ']折扣[' || NVL(V_DISCOUNT_RATE_NEW,0) || '],月返[' || NVL(V_MONTH_DISCOUNT_RATE_NEW,0) || ']之和不能大于100,请核实!';
        RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      END IF;
      
      IF (NVL(P_SO_HEADER.ENTITY_CUST_FLAG,PKG_SO_PUB.V_NO) = PKG_SO_PUB.V_YES
         AND (V_MONTH_DISCOUNT_RATE_NEW IS NOT NULL OR V_DISCOUNT_RATE_NEW IS NOT NULL)) THEN
        P_ERR_MSG := '内部关联交易客户[' || P_SO_HEADER.CUSTOMER_CODE || ',' || P_SO_HEADER.CUSTOMER_NAME || ']对应单据结算时不可修改结算价格、折扣、月返!';
        RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      END IF;
    
      --如果结算时对财务单进行了折扣或月返的修改，则需要修改财务单的结算金额、记录修改记录到跟踪表
      IF (V_DISCOUNT_RATE_NEW IS NOT NULL) AND
         (V_MONTH_DISCOUNT_RATE_NEW IS NOT NULL) THEN
        IF (V_PROJECT_PRICE IS NOT NULL) THEN
          V_ITEM_SETTLE_PRICE := ROUND(V_PROJECT_PRICE *
                                 (100 - V_DISCOUNT_RATE_NEW -
                                 V_MONTH_DISCOUNT_RATE_NEW) / 100,PKG_SO_PUB.V_DEFAULT_PRECISE_SCALE);
        
          --折扣金额、月返金额
          V_ITEM_DISCOUNT_AMOUNT       := ROUND(V_ITEM_QTY * V_PROJECT_PRICE *
                                          V_DISCOUNT_RATE_NEW / 100,2);
          V_ITEM_MONTH_DISCOUNT_AMOUNT := ROUND(V_ITEM_QTY * V_PROJECT_PRICE *
                                          V_MONTH_DISCOUNT_RATE_NEW / 100,2);
        ELSE
          V_ITEM_SETTLE_PRICE := ROUND(V_ITEM_PRICE * (100 - V_DISCOUNT_RATE_NEW -
                                 V_MONTH_DISCOUNT_RATE_NEW) / 100,PKG_SO_PUB.V_DEFAULT_PRECISE_SCALE);
        
          V_ITEM_DISCOUNT_AMOUNT       := ROUND(V_ITEM_QTY * V_ITEM_PRICE *
                                          V_DISCOUNT_RATE_NEW / 100,2);
          V_ITEM_MONTH_DISCOUNT_AMOUNT := ROUND(V_ITEM_QTY * V_ITEM_PRICE *
                                          V_MONTH_DISCOUNT_RATE_NEW / 100,2);
        END IF;
      
        --结算金额
        V_ITEM_SETTLE_AMOUNT := ROUND(V_ITEM_QTY * V_ITEM_SETTLE_PRICE,2);
      
        --更新单据行的折扣率、月返、结算价格、结算金额、折扣金额、月返金额
        UPDATE T_SO_LINE
           SET DISCOUNT_RATE         = V_DISCOUNT_RATE_NEW,
               MONTH_DISCOUNT_RATE   = V_MONTH_DISCOUNT_RATE_NEW,
               ITEM_SETTLE_PRICE     = V_ITEM_SETTLE_PRICE,
               ITEM_SETTLE_AMOUNT    = V_ITEM_SETTLE_AMOUNT,
               DISCOUNT_AMOUNT       = V_ITEM_DISCOUNT_AMOUNT,
               MONTH_DISCOUNT_AMOUNT = V_ITEM_MONTH_DISCOUNT_AMOUNT,
               LAST_UPDATED_BY       = V_CURR_USER_CODE,
               LAST_UPDATE_DATE      = V_CURR_TIME
         WHERE SO_LINE_ID = R_SO_LINE_INFO.SO_LINE_ID;
      
        --更新单据行明细的产品结算价格、散件结算价格
        PKG_SO_AR.P_UPDATE_SO_LINE_DETAIL(R_SO_LINE_INFO.SO_LINE_ID,
                                          R_SO_LINE_INFO.ITEM_ID,
                                          R_SO_LINE_INFO.ITEM_CODE,
                                          V_ITEM_SETTLE_PRICE,
                                          V_ENTITY_ID,
                                          P_RESULT,
                                          P_ERR_MSG);
        --根据P_RESULT判断是否抛出异常
        PKG_SO_PUB.P_EXCEPTION_THROWS(P_RESULT);
      
        --赋值跟踪表记录
        V_IS_SAVE_TRACE                    := PKG_SO_PUB.V_YES;
        R_SO_TRACE.NEW_ITEM_SETTLE_PRICE   := V_ITEM_SETTLE_PRICE;
        R_SO_TRACE.NEW_ITEM_SETTLE_AMOUNT  := V_ITEM_SETTLE_AMOUNT;
        R_SO_TRACE.NEW_DISCOUNT_RATE       := V_DISCOUNT_RATE_NEW;
        R_SO_TRACE.NEW_DISCOUNT_AMOUNT     := V_ITEM_DISCOUNT_AMOUNT;
        R_SO_TRACE.NEW_MONTH_DISCOUNT_RATE := V_MONTH_DISCOUNT_RATE_NEW;
      
        --设置是否修改了财务单的标识为Y
        IF (V_MODIFY_SO = PKG_SO_PUB.V_NO) THEN
          V_MODIFY_SO := PKG_SO_PUB.V_YES;
        END IF;
      ELSIF (V_DISCOUNT_RATE_NEW IS NOT NULL) AND
            (V_MONTH_DISCOUNT_RATE_NEW IS NULL) THEN
        IF (V_PROJECT_PRICE IS NOT NULL) THEN
          V_ITEM_SETTLE_PRICE    := ROUND(V_PROJECT_PRICE *
                                    (100 - V_DISCOUNT_RATE_NEW -
                                    V_MONTH_DISCOUNT_RATE_OLD) / 100,PKG_SO_PUB.V_DEFAULT_PRECISE_SCALE);
          V_ITEM_DISCOUNT_AMOUNT := ROUND(V_ITEM_QTY * V_PROJECT_PRICE *
                                    V_DISCOUNT_RATE_NEW / 100,2);
        ELSE
          V_ITEM_SETTLE_PRICE    := ROUND(V_ITEM_PRICE *
                                    (100 - V_DISCOUNT_RATE_NEW -
                                    V_MONTH_DISCOUNT_RATE_OLD) / 100,PKG_SO_PUB.V_DEFAULT_PRECISE_SCALE);
          V_ITEM_DISCOUNT_AMOUNT := ROUND(V_ITEM_QTY * V_ITEM_PRICE *
                                    V_DISCOUNT_RATE_NEW / 100,2);
        END IF;
      
        --结算金额
        V_ITEM_SETTLE_AMOUNT := ROUND(V_ITEM_QTY * V_ITEM_SETTLE_PRICE,2);
      
        --更新单据行的折扣率、月返、结算价格、结算金额、折扣金额、月返金额
        UPDATE T_SO_LINE
           SET DISCOUNT_RATE      = V_DISCOUNT_RATE_NEW,
               ITEM_SETTLE_PRICE  = V_ITEM_SETTLE_PRICE,
               ITEM_SETTLE_AMOUNT = V_ITEM_SETTLE_AMOUNT,
               DISCOUNT_AMOUNT    = V_ITEM_DISCOUNT_AMOUNT,
               LAST_UPDATED_BY    = V_CURR_USER_CODE,
               LAST_UPDATE_DATE   = V_CURR_TIME
         WHERE SO_LINE_ID = R_SO_LINE_INFO.SO_LINE_ID;
      
        --更新单据行明细的产品结算价格、散件结算价格
        PKG_SO_AR.P_UPDATE_SO_LINE_DETAIL(R_SO_LINE_INFO.SO_LINE_ID,
                                          R_SO_LINE_INFO.ITEM_ID,
                                          R_SO_LINE_INFO.ITEM_CODE,
                                          V_ITEM_SETTLE_PRICE,
                                          V_ENTITY_ID,
                                          P_RESULT,
                                          P_ERR_MSG);
        --根据P_RESULT判断是否抛出异常
        PKG_SO_PUB.P_EXCEPTION_THROWS(P_RESULT);
      
        --赋值跟踪表记录
        V_IS_SAVE_TRACE                    := PKG_SO_PUB.V_YES;
        R_SO_TRACE.NEW_ITEM_SETTLE_PRICE   := V_ITEM_SETTLE_PRICE;
        R_SO_TRACE.NEW_ITEM_SETTLE_AMOUNT  := V_ITEM_SETTLE_AMOUNT;
        R_SO_TRACE.NEW_DISCOUNT_RATE       := V_DISCOUNT_RATE_NEW;
        R_SO_TRACE.NEW_DISCOUNT_AMOUNT     := V_ITEM_DISCOUNT_AMOUNT;
        R_SO_TRACE.NEW_MONTH_DISCOUNT_RATE := R_SO_LINE_INFO.MONTH_DISCOUNT_RATE;
      
        --设置是否修改了财务单的标识为Y
        IF (V_MODIFY_SO = PKG_SO_PUB.V_NO) THEN
          V_MODIFY_SO := PKG_SO_PUB.V_YES;
        END IF;
      ELSIF (V_DISCOUNT_RATE_NEW IS NULL) AND
            (V_MONTH_DISCOUNT_RATE_NEW IS NOT NULL) THEN
        IF (V_PROJECT_PRICE IS NOT NULL) THEN
          V_ITEM_SETTLE_PRICE          := ROUND(V_PROJECT_PRICE *
                                          (100 - V_DISCOUNT_RATE_OLD -
                                          V_MONTH_DISCOUNT_RATE_NEW) / 100,PKG_SO_PUB.V_DEFAULT_PRECISE_SCALE);
          V_ITEM_MONTH_DISCOUNT_AMOUNT := ROUND(V_ITEM_QTY * V_PROJECT_PRICE *
                                          V_MONTH_DISCOUNT_RATE_NEW / 100,2);
        ELSE
          V_ITEM_SETTLE_PRICE          := ROUND(V_ITEM_PRICE *
                                          (100 - V_DISCOUNT_RATE_OLD -
                                          V_MONTH_DISCOUNT_RATE_NEW) / 100,PKG_SO_PUB.V_DEFAULT_PRECISE_SCALE);
          V_ITEM_MONTH_DISCOUNT_AMOUNT := ROUND(V_ITEM_QTY * V_ITEM_PRICE *
                                          V_MONTH_DISCOUNT_RATE_NEW / 100,2);
        END IF;
      
        --结算金额
        V_ITEM_SETTLE_AMOUNT := ROUND(V_ITEM_QTY * V_ITEM_SETTLE_PRICE,2);
      
        --更新单据行的折扣率、月返、结算价格、结算金额、折扣金额、月返金额
        UPDATE T_SO_LINE
           SET MONTH_DISCOUNT_RATE   = V_MONTH_DISCOUNT_RATE_NEW,
               ITEM_SETTLE_PRICE     = V_ITEM_SETTLE_PRICE,
               ITEM_SETTLE_AMOUNT    = V_ITEM_SETTLE_AMOUNT,
               MONTH_DISCOUNT_AMOUNT = V_ITEM_MONTH_DISCOUNT_AMOUNT,
               LAST_UPDATED_BY       = V_CURR_USER_CODE,
               LAST_UPDATE_DATE      = V_CURR_TIME
         WHERE SO_LINE_ID = R_SO_LINE_INFO.SO_LINE_ID;
      
        --更新单据行明细的产品结算价格、散件结算价格
        PKG_SO_AR.P_UPDATE_SO_LINE_DETAIL(R_SO_LINE_INFO.SO_LINE_ID,
                                          R_SO_LINE_INFO.ITEM_ID,
                                          R_SO_LINE_INFO.ITEM_CODE,
                                          V_ITEM_SETTLE_PRICE,
                                          V_ENTITY_ID,
                                          P_RESULT,
                                          P_ERR_MSG);
        --根据P_RESULT判断是否抛出异常
        PKG_SO_PUB.P_EXCEPTION_THROWS(P_RESULT);
      
        --赋值跟踪表记录
        V_IS_SAVE_TRACE                    := PKG_SO_PUB.V_YES;
        R_SO_TRACE.NEW_ITEM_SETTLE_PRICE   := V_ITEM_SETTLE_PRICE;
        R_SO_TRACE.NEW_ITEM_SETTLE_AMOUNT  := V_ITEM_SETTLE_AMOUNT;
        R_SO_TRACE.NEW_DISCOUNT_RATE       := R_SO_LINE_INFO.DISCOUNT_RATE;
        R_SO_TRACE.NEW_DISCOUNT_AMOUNT     := R_SO_LINE_INFO.DISCOUNT_AMOUNT;
        R_SO_TRACE.NEW_MONTH_DISCOUNT_RATE := V_MONTH_DISCOUNT_RATE_NEW;
      
        --设置是否修改了财务单的标识为Y
        IF (V_MODIFY_SO = PKG_SO_PUB.V_NO) THEN
          V_MODIFY_SO := PKG_SO_PUB.V_YES;
        END IF;
      END IF;
    
      IF V_IS_SAVE_TRACE = PKG_SO_PUB.V_YES THEN
        --保存修改信息到跟踪表
        R_SO_TRACE.SO_HEADER_ID             := R_SO_LINE_INFO.SO_HEADER_ID;
        R_SO_TRACE.SO_LINE_ID               := R_SO_LINE_INFO.SO_LINE_ID;
        R_SO_TRACE.ENTITY_ID                := R_SO_LINE_INFO.ENTITY_ID;
        R_SO_TRACE.OPERATION                := 'SETTLE';
        R_SO_TRACE.ORIG_ITEM_ID             := R_SO_LINE_INFO.ITEM_ID;
        R_SO_TRACE.ORIG_ITEM_QTY            := R_SO_LINE_INFO.ITEM_QTY;
        R_SO_TRACE.ORIG_ITEM_PRICE          := R_SO_LINE_INFO.ITEM_PRICE;
        R_SO_TRACE.ORIG_ITEM_SETTLE_PRICE   := R_SO_LINE_INFO.ITEM_SETTLE_PRICE;
        R_SO_TRACE.ORIG_ITEM_SETTLE_AMOUNT  := R_SO_LINE_INFO.ITEM_SETTLE_AMOUNT;
        R_SO_TRACE.ORIG_DISCOUNT_RATE       := R_SO_LINE_INFO.DISCOUNT_RATE;
        R_SO_TRACE.ORIG_DISCOUNT_AMOUNT     := R_SO_LINE_INFO.DISCOUNT_AMOUNT;
        R_SO_TRACE.ORIG_MONTH_DISCOUNT_RATE := R_SO_LINE_INFO.MONTH_DISCOUNT_RATE;
        R_SO_TRACE.ORIG_PROJECT_TYPE_CODE   := R_SO_LINE_INFO.PROJECT_TYPE_CODE;
        R_SO_TRACE.ORIG_PROJECT_ID          := R_SO_LINE_INFO.PROJECT_ID;
        R_SO_TRACE.ORIG_PROJECT_NUM         := R_SO_LINE_INFO.PROJECT_NUM;
        R_SO_TRACE.ORIG_PROJECT_PRICE       := R_SO_LINE_INFO.PROJECT_PRICE;
        R_SO_TRACE.NEW_ITEM_ID              := R_SO_LINE_INFO.ITEM_ID;
        R_SO_TRACE.NEW_ITEM_QTY             := R_SO_LINE_INFO.ITEM_QTY;
        R_SO_TRACE.NEW_ITEM_PRICE           := R_SO_LINE_INFO.ITEM_PRICE;
        R_SO_TRACE.NEW_PROJECT_TYPE_CODE    := R_SO_LINE_INFO.PROJECT_TYPE_CODE;
        R_SO_TRACE.NEW_PROJECT_ID           := R_SO_LINE_INFO.PROJECT_ID;
        R_SO_TRACE.NEW_PROJECT_NUM          := R_SO_LINE_INFO.PROJECT_NUM;
        R_SO_TRACE.NEW_PROJECT_PRICE        := R_SO_LINE_INFO.PROJECT_PRICE;
        R_SO_TRACE.CREATED_BY               := V_CURR_USER_CODE;
        R_SO_TRACE.CREATION_DATE            := V_CURR_TIME;
        R_SO_TRACE.LAST_UPDATED_BY          := V_CURR_USER_CODE;
        R_SO_TRACE.LAST_UPDATE_DATE         := V_CURR_TIME;
      
        --保存跟踪表
        PKG_SO_PUB.P_SAVE_SO_TRACE(R_SO_TRACE, P_RESULT, P_ERR_MSG);
        --根据P_RESULT判断是否抛出异常
        PKG_SO_PUB.P_EXCEPTION_THROWS(P_RESULT);
      END IF;
    END LOOP;
  
    --当前日期
    V_CURR_DATE := TO_DATE(TO_CHAR(V_CURR_TIME, V_DATA_FORMAT),
                           V_DATA_FORMAT);
    --结算日期（默认取当前日期）
    V_SETTLE_DATE := V_CURR_DATE;
    --月末日期
    V_LAST_DAY := TO_DATE(TO_CHAR(LAST_DAY(V_CURR_TIME), V_DATA_FORMAT),
                          V_DATA_FORMAT);
  
    --获取应收发票配置
    V_AR_CONFIG := PKG_SO_PUB.F_GET_AR_CONFIG(P_SO_HEADER.CUSTOMER_ID,
                                              P_SO_HEADER.SALES_CENTER_ID,
                                              P_SO_HEADER.ENTITY_ID,
                                              P_SO_HEADER.ERP_OU_ID);
  
    --如果配置了月末结算到下月一号，则即使在月末这一天结算完成结算日期也记在下月初。
    IF (V_AR_CONFIG.SETTLE_NEXT_MONTH_FLAG IS NOT NULL) AND
       (V_AR_CONFIG.SETTLE_NEXT_MONTH_FLAG = 'Y') AND
       (TO_NUMBER(V_LAST_DAY - V_CURR_DATE) = 0) THEN
      V_SETTLE_DATE := TO_DATE(TO_CHAR(ADD_MONTHS(V_LAST_DAY + 1, 0),
                                       V_DATA_FORMAT),
                               V_DATA_FORMAT);
    END IF;
    
    -- 自动结算：结算日期已经在JOB程序中指定。（自动结算job每天凌晨处理前一天的财务单，而且结算日志设置为前一天的日期)  例如3月17日凌晨15分运行自动结算功能，处理的财务单结算日期设置为3月16日）
    IF(P_SO_HEADER.SETTLE_DATE IS NOT NULL) THEN
        V_SETTLE_DATE := P_SO_HEADER.SETTLE_DATE;
    END IF;
  
    --更新财务单状态为已结算以及结算总金额等
    UPDATE T_SO_HEADER
       SET (SO_STATUS,
            SETTLE_FLAG,
            SETTLED_BY,
            SETTLE_DATE,
            LAST_UPDATED_BY,
            LAST_UPDATE_DATE,
            LIST_AMOUNT,
            SETTLE_AMOUNT,
            DISCOUNT_AMOUNT,
            MONTH_DISCOUNT_AMOUNT,
            PROJECT_AMOUNT) =
           (SELECT PKG_SO_PUB.V_SETTLED,
                   PKG_SO_PUB.V_YES,
                   V_CURR_USER_CODE,
                   V_SETTLE_DATE,
                   V_CURR_USER_CODE,
                   V_CURR_TIME,
                   SUM(NVL(A.ITEM_LIST_AMOUNT, 0)),
                   SUM(NVL(A.ITEM_SETTLE_AMOUNT, 0)),
                   SUM(NVL(A.DISCOUNT_AMOUNT, 0)),
                   SUM(NVL(A.MONTH_DISCOUNT_AMOUNT, 0)),
                   SUM(NVL(A.PROJECT_AMOUNT, 0))
              FROM T_SO_LINE A
             WHERE SO_HEADER_ID = V_SO_HEADER_ID)
     WHERE SO_HEADER_ID = V_SO_HEADER_ID;
     
    UPDATE T_SO_HEADER H
       SET H.VERSION = NVL(H.VERSION, 0) + 1, H.LAST_UPDATE_DATE = SYSDATE
     WHERE H.SO_HEADER_ID = V_SO_HEADER_ID;
  
    --结算金额变更了且APPLIED_FLAG（核销标识）是全部核销或是部分核销的时候
    --财务单号插入到T_AR_SETTLED_WRITE_OFF这张表中。
    --核销标记：0-全部核销，1-部分核销，2-未核销
    /* edit by chen.wj 20150116 注释一下往 CIMS.T_AR_SETTLED_WRITE_OFF插数据。
    小安最终决定我这边不用向CIMS.T_AR_SETTLED_WRITE_OFF插数据。
    */
    /*    IF (V_MODIFY_SO = PKG_SO_PUB.V_YES)\* AND
       (P_SO_HEADER.APPLIED_FLAG IN ('0', '1'))*\ THEN
       \*
       add by chen.wj 20150115 根据小安要求，
       插入数据是要判断销售是否存在，不存在才插入记录，已存在不新插入！！
       *\
     SELECT COUNT(*)
       INTO V_COUNT
       FROM CIMS.T_AR_SETTLED_WRITE_OFF A
      WHERE A.ORDER_CODE = P_SO_HEADER.SO_NUM;
      
      if V_COUNT=0 then
        INSERT INTO T_AR_SETTLED_WRITE_OFF
          (SETTLED_ID, ORDER_CODE, ORDER_TYPE, ENTITY_ID)
        VALUES
          (S_AR_SETTLED_WRITE_OFF.NEXTVAL,
           P_SO_HEADER.SO_NUM,
           P_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE,
           P_SO_HEADER.ENTITY_ID);
      end if;
    
    END IF;*/
  
    --财务单结算后结算总金额、折扣总金额
    SELECT ROUND(SUM(NVL(ITEM_SETTLE_AMOUNT, 0)),2), ROUND(SUM(NVL(DISCOUNT_AMOUNT, 0)),2)
      INTO V_SETTLE_AMOUNT_NEW, V_DISCOUNT_AMOUNT_NEW
      FROM T_SO_LINE
     WHERE SO_HEADER_ID = V_SO_HEADER_ID;
  
    --结算前后差额 
    V_SETTLE_AMOUNT_DIFF   := V_SETTLE_AMOUNT_NEW - V_SETTLE_AMOUNT_OLD;
    V_DISCOUNT_AMOUNT_DIFF := V_DISCOUNT_AMOUNT_NEW - V_DISCOUNT_AMOUNT_OLD;
  
    --信用控制
    IF (V_SETTLE_AMOUNT_DIFF != 0 OR V_DISCOUNT_AMOUNT_DIFF != 0) THEN
      PKG_SO_BIZ.P_SO_CREDIT_CONTROL(V_SO_HEADER_ID, --销售单据头ID
                                     V_SETTLE_AMOUNT_DIFF, --结算金额差额
                                     V_DISCOUNT_AMOUNT_DIFF, --折扣金额差额
                                     '30', --edit by chen.wj 20150109 P_SO_HEADER.CREATED_MODE, --开单方式--正式销售单的制单方式改为30-自动制单
                                     P_RESULT, --返回错误ID
                                     P_ERR_MSG --返回错误信息
                                     );
      PKG_SO_PUB.P_EXCEPTION_THROWS(P_RESULT);
    END IF;
  
    --库存事务处理
    IF R_SO_BILL_TYPE_EXTEND.INV_TRANSACTION_FLAG = PKG_SO_PUB.V_YES THEN
      PKG_INV_TRANSACTION.INV_TRANSACTION_TOTAL_DEAL(V_ENTITY_ID,
                                                     P_SO_HEADER.BILL_TYPE_ID,
                                                     PKG_SO_PUB.V_SETTLED,
                                                     V_SETTLE_DATE, /*P_SO_HEADER.SO_DATE, --edti by chen.wj 20150101 单据日期 改成 结算日期*/
                                                     V_SO_HEADER_ID,
                                                     0,
                                                     PKG_SO_PUB.V_TYPE_FLAG_SO,
                                                     P_RESULT,
                                                     P_ERR_MSG);
      IF P_RESULT < 0 THEN
        P_ERR_MSG := '调用库存事务出错！' || P_ERR_MSG;
      END IF;
      PKG_SO_PUB.P_EXCEPTION_THROWS(P_RESULT);
    END IF;
    ---1错误,0非拉式,1销售,2红冲,3源单退回,4反向销售,5拉式其他单据类型
    V_PULL_MODE := PKG_SO_PUB.F_PULL_MODE_BY_HEADERID(P_SO_HEADER.SO_HEADER_ID);
    V_ENTITY_CUST_FLAG := NVL(P_SO_HEADER.ENTITY_CUST_FLAG,'N');
    BEGIN
      V_PUSH_OR_PULL :=P_SO_HEADER.TRX_MODE;
      IF V_PUSH_OR_PULL IS NULL THEN    
        PKG_BD.P_GET_PARAMETER_VALUE(PKG_SO_PUB.V_ARG_SO_AR_PUSH_OR_PULL,
                                     V_ENTITY_ID,
                                     NULL,
                                     NULL,
                                     V_PUSH_OR_PULL);
      END IF;                                   
    EXCEPTION
      WHEN OTHERS THEN
        P_ERR_MSG := 'SO_AR_PUSH_OR_PULL主体参数,主体id:' || V_ENTITY_ID ||
                     '的参数设置异常，请检查。' || SQLERRM;
        RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
    END;    
    
    
    IF V_PULL_MODE IN (0,6) THEN--16514
      --财务单引入ERP
      --触发SO变更接口（BOOK登记通过SO变更一起发给ERP，故不需再调用BOOK登记接口）
      PKG_SO_BIZ.P_SO_TO_ERP(V_SO_HEADER_ID,
                             PKG_SO_PUB.V_ERP_TRXCODE_CHANGE,
                             P_RESULT,
                             P_ERR_MSG);
      PKG_SO_PUB.P_EXCEPTION_THROWS(P_RESULT);
      
      IF (V_BIZ_SRC_TYPE = PKG_SO_PUB.V_BIZ_SRC_BILL_SO_RED) OR
         (V_BIZ_SRC_TYPE = PKG_SO_PUB.V_BIZ_SRC_BILL_RETURN) THEN
        --销售单红冲单、退货单结算后触发ERP RMA接收
        PKG_SO_BIZ.P_SO_TO_ERP(V_SO_HEADER_ID,
                               PKG_SO_PUB.V_ERP_TRXCODE_RMA_RECV,
                               P_RESULT,
                               P_ERR_MSG);
        PKG_SO_PUB.P_EXCEPTION_THROWS(P_RESULT);
      END IF;
    ELSIF V_PULL_MODE IN ( 1, 5) THEN
      --销售，调关联订单和物流订单
      PKG_SO_RT.P_MAIN(P_SO_HEADER.SO_HEADER_ID, P_RESULT, P_ERR_MSG);
      PKG_SO_PUB.P_EXCEPTION_THROWS(P_RESULT);
    ELSIF V_PULL_MODE IN (2, 3, 4) THEN
      --红冲、源单退回、反向销售，调用RMA接收
      PKG_SO_BIZ.P_SO_TO_ERP(V_SO_HEADER_ID,
                             --PKG_SO_PUB.V_ERP_TRXCODE_RMA_RECV,
                             PKG_SO_PUB.V_ERP_TRXCODE_CHANGE, --edit by chen.wj RMA接收前，需要SO变更
                             P_RESULT,
                             P_ERR_MSG);
      PKG_SO_PUB.P_EXCEPTION_THROWS(P_RESULT);
    ELSE
      P_RESULT  := -1;
      P_ERR_MSG := 'V_PULL_MODE[' || V_PULL_MODE || ']获取推拉模式错误';
      PKG_SO_PUB.P_EXCEPTION_THROWS(P_RESULT);
    END IF;
    
    --转采购单据：更新对应PO单价格以及接口表状态
    PKG_SO_TO_POX.P_SO_SETTLE_PO_UPDATE(V_SO_HEADER_ID,
                                        P_RESULT,
                                        P_ERR_MSG);
    PKG_SO_PUB.P_EXCEPTION_THROWS(P_RESULT);
      
    /**
    20160924 zhoujg3 注释原因：1、内部客户关联交易调整为单边模式，单据审核是完成。2、内、外部客户都需要做SO BOOK,反向都有RMA。
    IF V_ENTITY_CUST_FLAG ='Y' THEN
    --如果是内部事业部客户
        IF (V_PUSH_OR_PULL = 'PULL') THEN
          PKG_SO_RT.P_MAIN(P_SO_HEADER.SO_HEADER_ID, P_RESULT, P_ERR_MSG);
          PKG_SO_PUB.P_EXCEPTION_THROWS(P_RESULT);        
        END IF;          
        
        --内部客户关联交易在单据审核时调用 zhoujg3 2016-09-23
        --调事业部关联订单和物流订单
        PKG_SO_RT.P_MAIN_ENTITY(P_SO_HEADER.SO_HEADER_ID, P_RESULT, P_ERR_MSG);
        PKG_SO_PUB.P_EXCEPTION_THROWS(P_RESULT);
    ELSE
    --如果是外部客户
      IF V_PULL_MODE IN (0,6) THEN--16514
        --财务单引入ERP
        --触发SO变更接口（BOOK登记通过SO变更一起发给ERP，故不需再调用BOOK登记接口）
        PKG_SO_BIZ.P_SO_TO_ERP(V_SO_HEADER_ID,
                               PKG_SO_PUB.V_ERP_TRXCODE_CHANGE,
                               P_RESULT,
                               P_ERR_MSG);
        PKG_SO_PUB.P_EXCEPTION_THROWS(P_RESULT);
      
        IF (V_BIZ_SRC_TYPE = PKG_SO_PUB.V_BIZ_SRC_BILL_SO_RED) OR
           (V_BIZ_SRC_TYPE = PKG_SO_PUB.V_BIZ_SRC_BILL_RETURN) THEN
          --销售单红冲单、退货单结算后触发ERP RMA接收
          PKG_SO_BIZ.P_SO_TO_ERP(V_SO_HEADER_ID,
                                 PKG_SO_PUB.V_ERP_TRXCODE_RMA_RECV,
                                 P_RESULT,
                                 P_ERR_MSG);
          PKG_SO_PUB.P_EXCEPTION_THROWS(P_RESULT);
        END IF;
      ELSIF V_PULL_MODE IN ( 1, 5) THEN
        --销售，调关联订单和物流订单
        PKG_SO_RT.P_MAIN(P_SO_HEADER.SO_HEADER_ID, P_RESULT, P_ERR_MSG);
        PKG_SO_PUB.P_EXCEPTION_THROWS(P_RESULT);
      ELSIF V_PULL_MODE IN (2, 3, 4) THEN
        --红冲、源单退回、反向销售，调用RMA接收
        PKG_SO_BIZ.P_SO_TO_ERP(V_SO_HEADER_ID,
                               --PKG_SO_PUB.V_ERP_TRXCODE_RMA_RECV,
                               PKG_SO_PUB.V_ERP_TRXCODE_CHANGE, --edit by chen.wj RMA接收前，需要SO变更
                               P_RESULT,
                               P_ERR_MSG);
        PKG_SO_PUB.P_EXCEPTION_THROWS(P_RESULT);
      ELSE
        P_RESULT  := -1;
        P_ERR_MSG := 'V_PULL_MODE[' || V_PULL_MODE || ']获取推拉模式错误';
        PKG_SO_PUB.P_EXCEPTION_THROWS(P_RESULT);
      END IF;
    
    END IF;
    */
    
    /*--20150131 chen.wj 注释原因：暂时不启动关联交易
    \*add by shengy 20150120*\
    BEGIN
      PKG_BD.P_GET_PARAMETER_VALUE(PKG_SO_PUB.V_ARG_SO_AR_PUSH_OR_PULL,
                                   V_ENTITY_ID,
                                   NULL,
                                   NULL,
                                   V_PUSH_OR_PULL);
    EXCEPTION
      WHEN OTHERS THEN
        P_ERR_MSG := 'SO_AR_PUSH_OR_PULL主体参数,主体id:' || V_ENTITY_ID ||
                     '的参数设置异常，请检查。' || SQLERRM;
        RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
    END;
    
    IF (V_PUSH_OR_PULL = 'PULL') THEN
      --拉式关联交易（厨房电器）
      IF (V_BIZ_SRC_TYPE = PKG_SO_PUB.V_BIZ_SRC_BILL_SO) THEN
        --拉式销售单触发关联交易订单，同时关联交易PO接收后触发客户SO挑库、发运确认（待实现......）
        --P_ERR_MSG := 'HELLOOOOOOOOOOOOOOO';
        PKG_SO_RT.P_SO_TO_RT_ORDER(P_SO_HEADER.SO_HEADER_ID,
                                   P_RESULT,
                                   P_ERR_MSG);
        PKG_SO_PUB.P_EXCEPTION_THROWS(P_RESULT);
        PKG_SO_RT.P_SO_TO_LG_ORDER(P_SO_HEADER.SO_HEADER_ID,
                                   P_RESULT,
                                   P_ERR_MSG);
        PKG_SO_PUB.P_EXCEPTION_THROWS(P_RESULT);
        \*ELSIF (V_BIZ_SRC_TYPE = PKG_SO_PUB.V_BIZ_SRC_BILL_RETURN) THEN*\
      ELSIF V_BIZ_SRC_TYPE IN
            (PKG_SO_PUB.V_BIZ_SRC_BILL_RETURN,
             PKG_SO_PUB.V_BIZ_SRC_BILL_SO_RED) THEN
        --退货方式：1-推式，2-拉式源单退回，3-拉式反向销售
        IF NVL(P_SO_HEADER.RETURN_MODE, '1') = '2' THEN
          PKG_SO_RT.P_SO_TO_LG_ORDER(P_SO_HEADER.SO_HEADER_ID,
                                     P_RESULT,
                                     P_ERR_MSG);
          PKG_SO_PUB.P_EXCEPTION_THROWS(P_RESULT);
        ELSIF NVL(P_SO_HEADER.RETURN_MODE, '1') = '3' THEN
          PKG_SO_RT.P_SO_TO_RT_ORDER(P_SO_HEADER.SO_HEADER_ID,
                                     P_RESULT,
                                     P_ERR_MSG);
          PKG_SO_PUB.P_EXCEPTION_THROWS(P_RESULT);
          PKG_SO_RT.P_SO_TO_LG_ORDER(P_SO_HEADER.SO_HEADER_ID,
                                     P_RESULT,
                                     P_ERR_MSG);
          PKG_SO_PUB.P_EXCEPTION_THROWS(P_RESULT);
        END IF;
      END IF;
      --ELSE IF V_PUSH_OR_PULL = 'PULL' THEN  
    END IF;*/
  
    /*mark by shengy 20150120
    IF V_ENTITY_ID = PKG_SO_PUB.V_ENTITY_ID_MDC THEN
      --拉式关联交易（厨房电器）
      IF (V_BIZ_SRC_TYPE = PKG_SO_PUB.V_BIZ_SRC_BILL_SO) THEN
        --拉式销售单触发关联交易订单，同时关联交易PO接收后触发客户SO挑库、发运确认（待实现......）
        P_ERR_MSG := 'HELLOOOOOOOOOOOOOOO';
      ELSIF (V_BIZ_SRC_TYPE = PKG_SO_PUB.V_BIZ_SRC_BILL_RETURN) THEN
        --根据退货单是否有源单分：拉式源单退回和拉式反向销售（待实现......）
        P_ERR_MSG := 'KITYYYYYYYYYYYYYYYY';
      END IF;
    END IF;*/
  
    --财务单引入ERP完成
  EXCEPTION
    WHEN PKG_SO_PUB.V_BIZ_EXCEPTION THEN
      P_RESULT  := -28207;
      P_ERR_MSG := '财务单据[单据号：' || P_SO_HEADER.SO_NUM || ']结算出错：' ||
                   P_ERR_MSG;
    WHEN OTHERS THEN
      P_RESULT  := -28207;
      P_ERR_MSG := '财务单据[单据号：' || P_SO_HEADER.SO_NUM || ']结算发生异常：' ||
                   SQLERRM;
  END;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-08-16
  *     创建者：廖丽章
  *   功能说明：更新财务单据行明细
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_UPDATE_SO_LINE_DETAIL(P_LINE_ID           IN NUMBER, --销售单据行ID
                                    P_ITEM_ID           IN NUMBER, --产品ID
                                    P_ITEM_CODE         T_BD_ITEM.ITEM_CODE%TYPE, --产品编码
                                    P_ITEM_SETTLE_PRICE IN NUMBER, --行产品结算价格
                                    P_ENTITY_ID         IN NUMBER, --add by chen.wj 20150128
                                    P_RESULT            OUT NUMBER, --返回错误ID
                                    P_ERR_MSG           OUT VARCHAR2 --返回错误信息
                                    ) IS
  
    --获取产品的散件
    CURSOR C_COMPONENT_ITEM IS
      SELECT SUB_ITEM_ID, --散件ID
             SUB_ITEM_CODE, --散件编码
             SUB_ITEM_NAME, --散件名称
             SUB_ITEM_UOM, --散件单位
             VALUE_SCALE --价格比例
        FROM V_BD_ITEM_ASSEMBLIES_SUB
       WHERE ENTITY_ID = P_ENTITY_ID --add by chen.wj 20150128
         AND ITEM_ID = P_ITEM_ID;
    --产品的散件信息
    R_COMPONENT_ITEM C_COMPONENT_ITEM%ROWTYPE;
  
    --是否套件：Y-是，N-否
    V_IS_SET CHAR(1) := 'N';
  
  BEGIN
    P_RESULT  := PKG_SO_PUB.V_RESULT;
    P_ERR_MSG := PKG_SO_PUB.V_SUCCESS;
  
    V_IS_SET := PKG_SO_PUB.F_ITEM_IS_SET(P_ENTITY_ID, P_ITEM_CODE);
    IF V_IS_SET = 'Y' THEN
      OPEN C_COMPONENT_ITEM;
      LOOP
        FETCH C_COMPONENT_ITEM
          INTO R_COMPONENT_ITEM;
        EXIT WHEN C_COMPONENT_ITEM%NOTFOUND;
      
        --更新散件上的产品结算价格和散件产品结算价格
        UPDATE T_SO_LINE_DETAIL
           SET ITEM_SETTLE_PRICE = P_ITEM_SETTLE_PRICE,
               --COMPONENT_SETTLE_PRICE = (P_ITEM_SETTLE_PRICE * R_COMPONENT_ITEM.VALUE_SCALE/100),
               COMPONENT_SETTLE_PRICE = 0, --套件中的散件价格为0
               LAST_UPDATED_BY        = V_CURR_USER_CODE,
               LAST_UPDATE_DATE       = SYSDATE
         WHERE SO_LINE_ID = P_LINE_ID
           AND COMPONENT_ID = R_COMPONENT_ITEM.SUB_ITEM_ID;
      END LOOP;
      CLOSE C_COMPONENT_ITEM;
    ELSE
      --更新散件上的产品结算价格和散件产品结算价格
      UPDATE T_SO_LINE_DETAIL
         SET ITEM_SETTLE_PRICE      = P_ITEM_SETTLE_PRICE,
             COMPONENT_SETTLE_PRICE = P_ITEM_SETTLE_PRICE,
             LAST_UPDATED_BY        = V_CURR_USER_CODE,
             LAST_UPDATE_DATE       = SYSDATE
       WHERE SO_LINE_ID = P_LINE_ID
         AND COMPONENT_ID = P_ITEM_ID;
    END IF;
  
  EXCEPTION
    WHEN OTHERS THEN
      P_RESULT  := -28208;
      P_ERR_MSG := '更新财务单据行明细[行ID：' || P_LINE_ID || ']发生异常：' || SQLERRM;
  END;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-08-16
  *     创建者：廖丽章
  *   功能说明：红蓝完全对冲的时候，将蓝单及其对应的全部红冲单发票号置成0000
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_WHOLE_REVERSAL(P_SO_HEADER_RED IN T_SO_HEADER%ROWTYPE, --销售单据头记录（红冲单）
                                P_RESULT        OUT NUMBER, --返回错误ID
                                P_ERR_MSG       OUT VARCHAR2 --返回错误信息
                                ) IS
    --原单号（红冲单对应的蓝单据号）
    V_ORIG_NUM T_SO_HEADER.ORIG_SO_NUM%TYPE;
    --蓝单结算总金额
    V_SETTLE_AMOUNT_B NUMBER;
    --红冲单结算总金额
    V_SETTLE_AMOUNT_R NUMBER;
  
    --发票号
    V_INVOICE_NUM VARCHAR2(10) := '0000';
  
    --当前时间
    V_CURR_DATE DATE := SYSDATE;
  
  BEGIN
    --初始返回值
    P_RESULT  := PKG_SO_PUB.V_RESULT;
    P_ERR_MSG := PKG_SO_PUB.V_SUCCESS;
  
    --原单号（红冲单对应的蓝单据号，反向销售折让单、反向折让证明单可能没有原单）
    V_ORIG_NUM := P_SO_HEADER_RED.ORIG_SO_NUM;
    IF (V_ORIG_NUM IS NOT NULL) THEN
      --获取蓝单的结算总金额
      SELECT SUM(NVL(SL.ITEM_SETTLE_AMOUNT, 0))
        INTO V_SETTLE_AMOUNT_B
        FROM T_SO_HEADER SH, T_SO_LINE SL
       WHERE SH.SO_HEADER_ID = SL.SO_HEADER_ID
         AND SH.SO_NUM = V_ORIG_NUM;
    
      --获取蓝单对应的红单结算总金额
      SELECT SUM(NVL(SL.ITEM_SETTLE_AMOUNT, 0))
        INTO V_SETTLE_AMOUNT_R
        FROM T_SO_HEADER SH, T_SO_LINE SL
       WHERE SH.SO_HEADER_ID = SL.SO_HEADER_ID
         AND SH.ORIG_SO_NUM = V_ORIG_NUM;
    
      --金额相等则表明红蓝完全对冲
      IF (V_SETTLE_AMOUNT_B = V_SETTLE_AMOUNT_R) THEN
        --把蓝单发票号置成0000
        UPDATE T_SO_HEADER
           SET INVOICE_NUM_LIST = V_INVOICE_NUM, INVOICE_DATE = V_CURR_DATE,LAST_UPDATE_DATE = SYSDATE
         WHERE SO_NUM = V_ORIG_NUM
           AND (INVOICE_NUM_LIST IS NULL);
        --WHERE SO_NUM = V_ORIG_NUM AND (INVOICE_NUM_LIST IS NULL OR INVOICE_NUM_LIST != V_INVOICE_NUM);
      
        --把蓝单对应的全部红冲单发票号置成0000
        UPDATE T_SO_HEADER
           SET INVOICE_NUM_LIST = V_INVOICE_NUM, INVOICE_DATE = V_CURR_DATE,LAST_UPDATE_DATE = SYSDATE
         WHERE ORIG_SO_NUM = V_ORIG_NUM
           AND (INVOICE_NUM_LIST IS NULL);
        --WHERE ORIG_SO_NUM = V_ORIG_NUM AND (INVOICE_NUM_LIST IS NULL OR INVOICE_NUM_LIST != V_INVOICE_NUM);
      END IF;
    END IF;
  
  EXCEPTION
    WHEN OTHERS THEN
      P_RESULT  := -28209;
      P_ERR_MSG := '红蓝完全对冲处理[单据号：' || P_SO_HEADER_RED.SO_NUM || ']发生异常：' ||
                   SQLERRM;
  END;
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-12-31
  *     创建者：陈武杰
  *   功能说明：更新财务单据，单独结算修改销售单时，增加信用校验
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_SETTLE_UPDATE(P_SO_HEADER_ID IN T_SO_HEADER.SO_HEADER_ID%TYPE, --销售单据头ID
                               P_USER_CODE    IN VARCHAR2, --操作用户编码
                               P_RESULT       OUT NUMBER, --返回错误ID
                               P_ERR_MSG      OUT VARCHAR2 --返回错误信息
                               ) AS
    --主体ID
    V_ENTITY_ID NUMBER;
    --销售单据头ID
    V_SO_HEADER_ID NUMBER;
    --销售单据源类型编码
    V_BIZ_SRC_TYPE T_SO_SRC_TYPE.SRC_TYPE_CODE%TYPE;
    --查询记录条数
    V_RECORD_COUNT NUMBER;
    --销售单据
    CURSOR C_SO_HEADER IS
      SELECT * FROM T_SO_HEADER WHERE SO_HEADER_ID = P_SO_HEADER_ID;
    --销售单据记录集
    P_SO_HEADER C_SO_HEADER%ROWTYPE;
  
    --财务单行信息
    CURSOR C_SO_LINE_INFO IS
      SELECT SL.*,
             SC.DISCOUNT_RATE       AS DISCOUNT_RATE_NEW,
             SC.MONTH_DISCOUNT_RATE AS MONTH_DISCOUNT_RATE_NEW
        FROM T_SO_LINE SL
        LEFT JOIN T_AR_SO_CHANGE SC
          ON SC.SO_HEADER_ID = SL.SO_HEADER_ID
         AND SC.SO_LINE_ID = SL.SO_LINE_ID
       WHERE SL.SO_HEADER_ID = P_SO_HEADER.SO_HEADER_ID;
    --AND SC.INVOICE_APPLY_ID = P_SO_HEADER.INVOICE_APPLY_ID;
    --财务单行信息记录集
    R_SO_LINE_INFO C_SO_LINE_INFO%ROWTYPE;
  
    --业务单据类型扩展属性，这行扩展属性可用于控制一些业务逻辑。
    CURSOR C_SO_BILL_TYPE_EXTEND IS
      SELECT *
        FROM V_SO_BILL_TYPE_EXTEND
       WHERE BILL_TYPE_ID = P_SO_HEADER.BILL_TYPE_ID
         AND ENTITY_ID = P_SO_HEADER.ENTITY_ID
         AND (TRUNC(SYSDATE) BETWEEN BEGIN_DATE AND NVL(END_DATE, SYSDATE));
    --业务单据类型扩展属性记录
    R_SO_BILL_TYPE_EXTEND C_SO_BILL_TYPE_EXTEND%ROWTYPE;
  
    --产品价格、结算价格、结算总金额、折扣总金额、月返总金额、批文总金额
    V_ITEM_QTY                   NUMBER;
    V_ITEM_PRICE                 NUMBER;
    V_ITEM_SETTLE_PRICE          NUMBER;
    V_ITEM_SETTLE_AMOUNT         NUMBER;
    V_ITEM_DISCOUNT_AMOUNT       NUMBER;
    V_ITEM_MONTH_DISCOUNT_AMOUNT NUMBER;
  
    --财务单结算前结算总金额、折扣总金额
    V_SETTLE_AMOUNT_OLD   NUMBER;
    V_DISCOUNT_AMOUNT_OLD NUMBER;
    --财务单结算后结算总金额、折扣总金额
    V_SETTLE_AMOUNT_NEW   NUMBER;
    V_DISCOUNT_AMOUNT_NEW NUMBER;
    --财务单结算前后差额
    V_SETTLE_AMOUNT_DIFF   NUMBER;
    V_DISCOUNT_AMOUNT_DIFF NUMBER;
  
    --批文信息
    V_PROJECT_ID    NUMBER;
    V_PROJECT_PRICE NUMBER;
  
    --修改前的折扣率和月返
    V_DISCOUNT_RATE_OLD       NUMBER := 0;
    V_MONTH_DISCOUNT_RATE_OLD NUMBER := 0;
  
    --修改后的折扣率和月返
    V_DISCOUNT_RATE_NEW       NUMBER := 0;
    V_MONTH_DISCOUNT_RATE_NEW NUMBER := 0;
  
    --跟踪表行
    R_SO_TRACE      T_SO_TRACE%ROWTYPE;
    V_IS_SAVE_TRACE CHAR(1) := PKG_SO_PUB.V_NO;
  
    --当前时间
    V_CURR_TIME DATE := SYSDATE;
  
    --结算日期
    V_SETTLE_DATE DATE;
    --当前日期
    V_CURR_DATE DATE;
    --月末日期
    V_LAST_DAY DATE;
  
    --应收发票配置记录
    V_AR_CONFIG PKG_SO_PUB.AR_CONFIG;
  
    --是否修改了财务单的标识
    V_MODIFY_SO CHAR(1) := PKG_SO_PUB.V_NO;
  
  BEGIN
    P_RESULT  := PKG_SO_PUB.V_RESULT;
    P_ERR_MSG := PKG_SO_PUB.V_SUCCESS;
  
    --当前操作用户编码
    V_CURR_USER_CODE := P_USER_CODE;
  
    OPEN C_SO_HEADER;
    FETCH C_SO_HEADER
      INTO P_SO_HEADER;
    CLOSE C_SO_HEADER;
    --根据销售单据头ID，查询销售单据头表是否有记录
    IF P_SO_HEADER.SO_HEADER_ID IS NULL THEN
      P_ERR_MSG := '销售单据头ID为[' || TO_CHAR(P_SO_HEADER_ID) ||
                   ']，查询不到销售单据头记录！';
      RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
    END IF;
    --判断销售单状态
    IF P_SO_HEADER.SO_STATUS != PKG_SO_PUB.V_AUDITED THEN
      P_ERR_MSG := '财务单[单据号：' || P_SO_HEADER.SO_NUM ||
                   ']的状态不正确，只有[11已审核]状态才允许修改。';
      RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
    END IF;
    --查询财务单行，记录条数
    SELECT COUNT(*)
      INTO V_RECORD_COUNT
      FROM T_SO_LINE SL
      LEFT JOIN T_AR_SO_CHANGE SC
        ON SC.SO_HEADER_ID = SL.SO_HEADER_ID
       AND SC.SO_LINE_ID = SL.SO_LINE_ID
     WHERE SL.SO_HEADER_ID = P_SO_HEADER.SO_HEADER_ID;
    --如果财务单行记录条数小于1，则不做任何操作
    IF V_RECORD_COUNT = 0 THEN
      RETURN;
    END IF;
  
    /*OPEN C_SO_BILL_TYPE_EXTEND;
    FETCH C_SO_BILL_TYPE_EXTEND
      INTO R_SO_BILL_TYPE_EXTEND;
    CLOSE C_SO_BILL_TYPE_EXTEND;*/
  
    --主体ID
    V_ENTITY_ID := P_SO_HEADER.ENTITY_ID;
    --单据头ID
    V_SO_HEADER_ID := P_SO_HEADER.SO_HEADER_ID;
    --销售单据源类型
    V_BIZ_SRC_TYPE := P_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE;
  
    --财务单结算前结算总金额、折扣总金额
    SELECT SUM(NVL(ITEM_SETTLE_AMOUNT, 0)), SUM(NVL(DISCOUNT_AMOUNT, 0))
      INTO V_SETTLE_AMOUNT_OLD, V_DISCOUNT_AMOUNT_OLD
      FROM T_SO_LINE
     WHERE SO_HEADER_ID = V_SO_HEADER_ID;
  
    FOR R_SO_LINE_INFO IN C_SO_LINE_INFO LOOP
      V_IS_SAVE_TRACE := PKG_SO_PUB.V_NO;
    
      V_ITEM_QTY      := R_SO_LINE_INFO.ITEM_QTY;
      V_ITEM_PRICE    := R_SO_LINE_INFO.ITEM_PRICE;
      V_PROJECT_ID    := R_SO_LINE_INFO.PROJECT_ID;
      V_PROJECT_PRICE := R_SO_LINE_INFO.PROJECT_PRICE;
    
      --修改前的折扣率和月返
      V_DISCOUNT_RATE_OLD       := NVL(R_SO_LINE_INFO.DISCOUNT_RATE, 0);
      V_MONTH_DISCOUNT_RATE_OLD := NVL(R_SO_LINE_INFO.MONTH_DISCOUNT_RATE,
                                       0);
      --修改后的折扣率和月返
      V_DISCOUNT_RATE_NEW       := R_SO_LINE_INFO.DISCOUNT_RATE_NEW;
      V_MONTH_DISCOUNT_RATE_NEW := R_SO_LINE_INFO.MONTH_DISCOUNT_RATE_NEW;
    
      --如果结算时对财务单进行了折扣或月返的修改，则需要修改财务单的结算金额、记录修改记录到跟踪表
      IF (V_DISCOUNT_RATE_NEW IS NOT NULL) AND
         (V_MONTH_DISCOUNT_RATE_NEW IS NOT NULL) THEN
        IF (V_PROJECT_PRICE IS NOT NULL) THEN
          V_ITEM_SETTLE_PRICE := ROUND(V_PROJECT_PRICE *
                                 (100 - V_DISCOUNT_RATE_NEW -
                                 V_MONTH_DISCOUNT_RATE_NEW) / 100,PKG_SO_PUB.V_DEFAULT_PRECISE_SCALE);
        
          --折扣金额、月返金额
          V_ITEM_DISCOUNT_AMOUNT       := V_ITEM_QTY * V_PROJECT_PRICE *
                                          V_DISCOUNT_RATE_NEW / 100;
          V_ITEM_MONTH_DISCOUNT_AMOUNT := V_ITEM_QTY * V_PROJECT_PRICE *
                                          V_MONTH_DISCOUNT_RATE_NEW / 100;
        ELSE
          V_ITEM_SETTLE_PRICE := ROUND(V_ITEM_PRICE * (100 - V_DISCOUNT_RATE_NEW -
                                 V_MONTH_DISCOUNT_RATE_NEW) / 100,PKG_SO_PUB.V_DEFAULT_PRECISE_SCALE);
        
          V_ITEM_DISCOUNT_AMOUNT       := V_ITEM_QTY * V_ITEM_PRICE *
                                          V_DISCOUNT_RATE_NEW / 100;
          V_ITEM_MONTH_DISCOUNT_AMOUNT := V_ITEM_QTY * V_ITEM_PRICE *
                                          V_MONTH_DISCOUNT_RATE_NEW / 100;
        END IF;
      
        --结算金额
        V_ITEM_SETTLE_AMOUNT := ROUND(V_ITEM_QTY * V_ITEM_SETTLE_PRICE,2);
      
        --更新单据行的折扣率、月返、结算价格、结算金额、折扣金额、月返金额
        UPDATE T_SO_LINE
           SET DISCOUNT_RATE         = V_DISCOUNT_RATE_NEW,
               MONTH_DISCOUNT_RATE   = V_MONTH_DISCOUNT_RATE_NEW,
               ITEM_SETTLE_PRICE     = V_ITEM_SETTLE_PRICE,
               ITEM_SETTLE_AMOUNT    = V_ITEM_SETTLE_AMOUNT,
               DISCOUNT_AMOUNT       = V_ITEM_DISCOUNT_AMOUNT,
               MONTH_DISCOUNT_AMOUNT = V_ITEM_MONTH_DISCOUNT_AMOUNT,
               LAST_UPDATED_BY       = V_CURR_USER_CODE,
               LAST_UPDATE_DATE      = V_CURR_TIME
         WHERE SO_LINE_ID = R_SO_LINE_INFO.SO_LINE_ID;
      
        --更新单据行明细的产品结算价格、散件结算价格
        PKG_SO_AR.P_UPDATE_SO_LINE_DETAIL(R_SO_LINE_INFO.SO_LINE_ID,
                                          R_SO_LINE_INFO.ITEM_ID,
                                          R_SO_LINE_INFO.ITEM_CODE,
                                          V_ITEM_SETTLE_PRICE,
                                          V_ENTITY_ID,
                                          P_RESULT,
                                          P_ERR_MSG);
        --根据P_RESULT判断是否抛出异常
        PKG_SO_PUB.P_EXCEPTION_THROWS(P_RESULT);
      
        --赋值跟踪表记录
        V_IS_SAVE_TRACE                    := PKG_SO_PUB.V_YES;
        R_SO_TRACE.NEW_ITEM_SETTLE_PRICE   := V_ITEM_SETTLE_PRICE;
        R_SO_TRACE.NEW_ITEM_SETTLE_AMOUNT  := V_ITEM_SETTLE_AMOUNT;
        R_SO_TRACE.NEW_DISCOUNT_RATE       := V_DISCOUNT_RATE_NEW;
        R_SO_TRACE.NEW_DISCOUNT_AMOUNT     := V_ITEM_DISCOUNT_AMOUNT;
        R_SO_TRACE.NEW_MONTH_DISCOUNT_RATE := V_MONTH_DISCOUNT_RATE_NEW;
      
        --设置是否修改了财务单的标识为Y
        IF (V_MODIFY_SO = PKG_SO_PUB.V_NO) THEN
          V_MODIFY_SO := PKG_SO_PUB.V_YES;
        END IF;
      ELSIF (V_DISCOUNT_RATE_NEW IS NOT NULL) AND
            (V_MONTH_DISCOUNT_RATE_NEW IS NULL) THEN
        IF (V_PROJECT_PRICE IS NOT NULL) THEN
          V_ITEM_SETTLE_PRICE    := ROUND(V_PROJECT_PRICE *
                                    (100 - V_DISCOUNT_RATE_NEW -
                                    V_MONTH_DISCOUNT_RATE_OLD) / 100,PKG_SO_PUB.V_DEFAULT_PRECISE_SCALE);
          V_ITEM_DISCOUNT_AMOUNT := V_ITEM_QTY * V_PROJECT_PRICE *
                                    V_DISCOUNT_RATE_NEW / 100;
        ELSE
          V_ITEM_SETTLE_PRICE    := ROUND(V_ITEM_PRICE *
                                    (100 - V_DISCOUNT_RATE_NEW -
                                    V_MONTH_DISCOUNT_RATE_OLD) / 100,PKG_SO_PUB.V_DEFAULT_PRECISE_SCALE);
          V_ITEM_DISCOUNT_AMOUNT := V_ITEM_QTY * V_ITEM_PRICE *
                                    V_DISCOUNT_RATE_NEW / 100;
        END IF;
      
        --结算金额
        V_ITEM_SETTLE_AMOUNT := ROUND(V_ITEM_QTY * V_ITEM_SETTLE_PRICE,2);
      
        --更新单据行的折扣率、月返、结算价格、结算金额、折扣金额、月返金额
        UPDATE T_SO_LINE
           SET DISCOUNT_RATE      = V_DISCOUNT_RATE_NEW,
               ITEM_SETTLE_PRICE  = V_ITEM_SETTLE_PRICE,
               ITEM_SETTLE_AMOUNT = V_ITEM_SETTLE_AMOUNT,
               DISCOUNT_AMOUNT    = V_ITEM_DISCOUNT_AMOUNT,
               LAST_UPDATED_BY    = V_CURR_USER_CODE,
               LAST_UPDATE_DATE   = V_CURR_TIME
         WHERE SO_LINE_ID = R_SO_LINE_INFO.SO_LINE_ID;
      
        --更新单据行明细的产品结算价格、散件结算价格
        PKG_SO_AR.P_UPDATE_SO_LINE_DETAIL(R_SO_LINE_INFO.SO_LINE_ID,
                                          R_SO_LINE_INFO.ITEM_ID,
                                          R_SO_LINE_INFO.ITEM_CODE,
                                          V_ITEM_SETTLE_PRICE,
                                          V_ENTITY_ID,
                                          P_RESULT,
                                          P_ERR_MSG);
        --根据P_RESULT判断是否抛出异常
        PKG_SO_PUB.P_EXCEPTION_THROWS(P_RESULT);
      
        --赋值跟踪表记录
        V_IS_SAVE_TRACE                    := PKG_SO_PUB.V_YES;
        R_SO_TRACE.NEW_ITEM_SETTLE_PRICE   := V_ITEM_SETTLE_PRICE;
        R_SO_TRACE.NEW_ITEM_SETTLE_AMOUNT  := V_ITEM_SETTLE_AMOUNT;
        R_SO_TRACE.NEW_DISCOUNT_RATE       := V_DISCOUNT_RATE_NEW;
        R_SO_TRACE.NEW_DISCOUNT_AMOUNT     := V_ITEM_DISCOUNT_AMOUNT;
        R_SO_TRACE.NEW_MONTH_DISCOUNT_RATE := R_SO_LINE_INFO.MONTH_DISCOUNT_RATE;
      
        --设置是否修改了财务单的标识为Y
        IF (V_MODIFY_SO = PKG_SO_PUB.V_NO) THEN
          V_MODIFY_SO := PKG_SO_PUB.V_YES;
        END IF;
      ELSIF (V_DISCOUNT_RATE_NEW IS NULL) AND
            (V_MONTH_DISCOUNT_RATE_NEW IS NOT NULL) THEN
        IF (V_PROJECT_PRICE IS NOT NULL) THEN
          V_ITEM_SETTLE_PRICE          := ROUND(V_PROJECT_PRICE *
                                          (100 - V_DISCOUNT_RATE_OLD -
                                          V_MONTH_DISCOUNT_RATE_NEW) / 100,PKG_SO_PUB.V_DEFAULT_PRECISE_SCALE);
          V_ITEM_MONTH_DISCOUNT_AMOUNT := V_ITEM_QTY * V_PROJECT_PRICE *
                                          V_MONTH_DISCOUNT_RATE_NEW / 100;
        ELSE
          V_ITEM_SETTLE_PRICE          := ROUND(V_ITEM_PRICE *
                                          (100 - V_DISCOUNT_RATE_OLD -
                                          V_MONTH_DISCOUNT_RATE_NEW) / 100,PKG_SO_PUB.V_DEFAULT_PRECISE_SCALE);
          V_ITEM_MONTH_DISCOUNT_AMOUNT := V_ITEM_QTY * V_ITEM_PRICE *
                                          V_MONTH_DISCOUNT_RATE_NEW / 100;
        END IF;
      
        --结算金额
        V_ITEM_SETTLE_AMOUNT := ROUND(V_ITEM_QTY * V_ITEM_SETTLE_PRICE,2);
      
        --更新单据行的折扣率、月返、结算价格、结算金额、折扣金额、月返金额
        UPDATE T_SO_LINE
           SET MONTH_DISCOUNT_RATE   = V_MONTH_DISCOUNT_RATE_NEW,
               ITEM_SETTLE_PRICE     = V_ITEM_SETTLE_PRICE,
               ITEM_SETTLE_AMOUNT    = V_ITEM_SETTLE_AMOUNT,
               MONTH_DISCOUNT_AMOUNT = V_ITEM_MONTH_DISCOUNT_AMOUNT,
               LAST_UPDATED_BY       = V_CURR_USER_CODE,
               LAST_UPDATE_DATE      = V_CURR_TIME
         WHERE SO_LINE_ID = R_SO_LINE_INFO.SO_LINE_ID;
      
        --更新单据行明细的产品结算价格、散件结算价格
        PKG_SO_AR.P_UPDATE_SO_LINE_DETAIL(R_SO_LINE_INFO.SO_LINE_ID,
                                          R_SO_LINE_INFO.ITEM_ID,
                                          R_SO_LINE_INFO.ITEM_CODE,
                                          V_ITEM_SETTLE_PRICE,
                                          V_ENTITY_ID,
                                          P_RESULT,
                                          P_ERR_MSG);
        --根据P_RESULT判断是否抛出异常
        PKG_SO_PUB.P_EXCEPTION_THROWS(P_RESULT);
      
        --赋值跟踪表记录
        V_IS_SAVE_TRACE                    := PKG_SO_PUB.V_YES;
        R_SO_TRACE.NEW_ITEM_SETTLE_PRICE   := V_ITEM_SETTLE_PRICE;
        R_SO_TRACE.NEW_ITEM_SETTLE_AMOUNT  := V_ITEM_SETTLE_AMOUNT;
        R_SO_TRACE.NEW_DISCOUNT_RATE       := R_SO_LINE_INFO.DISCOUNT_RATE;
        R_SO_TRACE.NEW_DISCOUNT_AMOUNT     := R_SO_LINE_INFO.DISCOUNT_AMOUNT;
        R_SO_TRACE.NEW_MONTH_DISCOUNT_RATE := V_MONTH_DISCOUNT_RATE_NEW;
      
        --设置是否修改了财务单的标识为Y
        IF (V_MODIFY_SO = PKG_SO_PUB.V_NO) THEN
          V_MODIFY_SO := PKG_SO_PUB.V_YES;
        END IF;
      END IF;
    
      IF V_IS_SAVE_TRACE = PKG_SO_PUB.V_YES THEN
        --保存修改信息到跟踪表
        R_SO_TRACE.SO_HEADER_ID             := R_SO_LINE_INFO.SO_HEADER_ID;
        R_SO_TRACE.SO_LINE_ID               := R_SO_LINE_INFO.SO_LINE_ID;
        R_SO_TRACE.ENTITY_ID                := R_SO_LINE_INFO.ENTITY_ID;
        R_SO_TRACE.OPERATION                := 'SETTLE';
        R_SO_TRACE.ORIG_ITEM_ID             := R_SO_LINE_INFO.ITEM_ID;
        R_SO_TRACE.ORIG_ITEM_QTY            := R_SO_LINE_INFO.ITEM_QTY;
        R_SO_TRACE.ORIG_ITEM_PRICE          := R_SO_LINE_INFO.ITEM_PRICE;
        R_SO_TRACE.ORIG_ITEM_SETTLE_PRICE   := R_SO_LINE_INFO.ITEM_SETTLE_PRICE;
        R_SO_TRACE.ORIG_ITEM_SETTLE_AMOUNT  := R_SO_LINE_INFO.ITEM_SETTLE_AMOUNT;
        R_SO_TRACE.ORIG_DISCOUNT_RATE       := R_SO_LINE_INFO.DISCOUNT_RATE;
        R_SO_TRACE.ORIG_DISCOUNT_AMOUNT     := R_SO_LINE_INFO.DISCOUNT_AMOUNT;
        R_SO_TRACE.ORIG_MONTH_DISCOUNT_RATE := R_SO_LINE_INFO.MONTH_DISCOUNT_RATE;
        R_SO_TRACE.ORIG_PROJECT_TYPE_CODE   := R_SO_LINE_INFO.PROJECT_TYPE_CODE;
        R_SO_TRACE.ORIG_PROJECT_ID          := R_SO_LINE_INFO.PROJECT_ID;
        R_SO_TRACE.ORIG_PROJECT_NUM         := R_SO_LINE_INFO.PROJECT_NUM;
        R_SO_TRACE.ORIG_PROJECT_PRICE       := R_SO_LINE_INFO.PROJECT_PRICE;
        R_SO_TRACE.NEW_ITEM_ID              := R_SO_LINE_INFO.ITEM_ID;
        R_SO_TRACE.NEW_ITEM_QTY             := R_SO_LINE_INFO.ITEM_QTY;
        R_SO_TRACE.NEW_ITEM_PRICE           := R_SO_LINE_INFO.ITEM_PRICE;
        R_SO_TRACE.NEW_PROJECT_TYPE_CODE    := R_SO_LINE_INFO.PROJECT_TYPE_CODE;
        R_SO_TRACE.NEW_PROJECT_ID           := R_SO_LINE_INFO.PROJECT_ID;
        R_SO_TRACE.NEW_PROJECT_NUM          := R_SO_LINE_INFO.PROJECT_NUM;
        R_SO_TRACE.NEW_PROJECT_PRICE        := R_SO_LINE_INFO.PROJECT_PRICE;
        R_SO_TRACE.CREATED_BY               := V_CURR_USER_CODE;
        R_SO_TRACE.CREATION_DATE            := V_CURR_TIME;
        R_SO_TRACE.LAST_UPDATED_BY          := V_CURR_USER_CODE;
        R_SO_TRACE.LAST_UPDATE_DATE         := V_CURR_TIME;
      
        --保存跟踪表
        PKG_SO_PUB.P_SAVE_SO_TRACE(R_SO_TRACE, P_RESULT, P_ERR_MSG);
        --根据P_RESULT判断是否抛出异常
        PKG_SO_PUB.P_EXCEPTION_THROWS(P_RESULT);
      END IF;
    END LOOP;
  
    --当前日期
    /*V_CURR_DATE := TO_DATE(TO_CHAR(V_CURR_TIME, V_DATA_FORMAT),
    V_DATA_FORMAT);*/
    --结算日期（默认取当前日期）
    /*V_SETTLE_DATE := V_CURR_DATE;*/
    --月末日期
    /*V_LAST_DAY := TO_DATE(TO_CHAR(LAST_DAY(V_CURR_TIME), V_DATA_FORMAT),
    V_DATA_FORMAT);*/
  
    --获取应收发票配置
    /*V_AR_CONFIG := PKG_SO_PUB.F_GET_AR_CONFIG(P_SO_HEADER.CUSTOMER_ID,
    P_SO_HEADER.SALES_CENTER_ID,
    P_SO_HEADER.ENTITY_ID,
    P_SO_HEADER.ERP_OU_ID);*/
  
    --如果配置了月末结算到下月一号，则即使在月末这一天结算完成结算日期也记在下月初。
    /*IF (V_AR_CONFIG.SETTLE_NEXT_MONTH_FLAG IS NOT NULL) AND
       (V_AR_CONFIG.SETTLE_NEXT_MONTH_FLAG = 'Y') AND
       (TO_NUMBER(V_LAST_DAY - V_CURR_DATE) = 0) THEN
      V_SETTLE_DATE := TO_DATE(TO_CHAR(ADD_MONTHS(V_LAST_DAY + 1, 0),
                                       V_DATA_FORMAT),
                               V_DATA_FORMAT);
    END IF;*/
  
    --更新财务单结算总金额等
    UPDATE T_SO_HEADER
       SET ( --SO_STATUS,
            --SETTLE_FLAG,
            --SETTLED_BY,
            --SETTLE_DATE,
            LAST_UPDATED_BY,
            LAST_UPDATE_DATE,
            LIST_AMOUNT,
            SETTLE_AMOUNT,
            DISCOUNT_AMOUNT,
            MONTH_DISCOUNT_AMOUNT,
            PROJECT_AMOUNT) =
           (SELECT --PKG_SO_PUB.V_SETTLED,
            --PKG_SO_PUB.V_YES,
            --V_CURR_USER_CODE,
            --V_SETTLE_DATE,
             V_CURR_USER_CODE,
             V_CURR_TIME,
             SUM(NVL(A.ITEM_LIST_AMOUNT, 0)),
             SUM(NVL(A.ITEM_SETTLE_AMOUNT, 0)),
             SUM(NVL(A.DISCOUNT_AMOUNT, 0)),
             SUM(NVL(A.MONTH_DISCOUNT_AMOUNT, 0)),
             SUM(NVL(A.PROJECT_AMOUNT, 0))
              FROM T_SO_LINE A
             WHERE SO_HEADER_ID = V_SO_HEADER_ID)
     WHERE SO_HEADER_ID = V_SO_HEADER_ID;
  
    --结算金额变更了且APPLIED_FLAG（核销标识）是全部核销或是部分核销的时候
    --财务单号插入到T_AR_SETTLED_WRITE_OFF这张表中。
    --核销标记：0-全部核销，1-部分核销，2-未核销
    /*IF (V_MODIFY_SO = PKG_SO_PUB.V_YES) AND
       (P_SO_HEADER.APPLIED_FLAG IN ('0', '1')) THEN
      INSERT INTO T_AR_SETTLED_WRITE_OFF
        (SETTLED_ID, ORDER_CODE, ORDER_TYPE, ENTITY_ID)
      VALUES
        (S_AR_SETTLED_WRITE_OFF.NEXTVAL,
         P_SO_HEADER.SO_NUM,
         P_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE,
         P_SO_HEADER.ENTITY_ID);
    END IF;*/
  
    --财务单结算后结算总金额、折扣总金额
    SELECT SUM(NVL(ITEM_SETTLE_AMOUNT, 0)), SUM(NVL(DISCOUNT_AMOUNT, 0))
      INTO V_SETTLE_AMOUNT_NEW, V_DISCOUNT_AMOUNT_NEW
      FROM T_SO_LINE
     WHERE SO_HEADER_ID = V_SO_HEADER_ID;
  
    --结算前后差额
    V_SETTLE_AMOUNT_DIFF   := V_SETTLE_AMOUNT_NEW - V_SETTLE_AMOUNT_OLD;
    V_DISCOUNT_AMOUNT_DIFF := V_DISCOUNT_AMOUNT_NEW - V_DISCOUNT_AMOUNT_OLD;
  
    --信用控制
    IF (V_SETTLE_AMOUNT_DIFF != 0 OR V_DISCOUNT_AMOUNT_DIFF != 0) THEN
      PKG_SO_BIZ.P_SO_CREDIT_CONTROL(V_SO_HEADER_ID, --销售单据头ID
                                     V_SETTLE_AMOUNT_DIFF, --结算金额差额
                                     V_DISCOUNT_AMOUNT_DIFF, --折扣金额差额
                                     '30', --edit by chen.wj 20150109 P_SO_HEADER.CREATED_MODE, --开单方式--正式销售单的制单方式改为30-自动制单
                                     P_RESULT, --返回错误ID
                                     P_ERR_MSG, --返回错误信息
                                     '12'   --表示结算状态
                                     );
      PKG_SO_PUB.P_EXCEPTION_THROWS(P_RESULT);
    END IF;
  
    --库存事务处理
    /*IF R_SO_BILL_TYPE_EXTEND.INV_TRANSACTION_FLAG = PKG_SO_PUB.V_YES THEN
      PKG_INV_TRANSACTION.INV_TRANSACTION_TOTAL_DEAL(V_ENTITY_ID,
                                                     P_SO_HEADER.BILL_TYPE_ID,
                                                     PKG_SO_PUB.V_SETTLED,
                                                     P_SO_HEADER.SO_DATE,
                                                     V_SO_HEADER_ID,
                                                     0,
                                                     PKG_SO_PUB.V_TYPE_FLAG_SO,
                                                     P_RESULT,
                                                     P_ERR_MSG);
      PKG_SO_PUB.P_EXCEPTION_THROWS(P_RESULT);
    END IF;*/
  
    --财务单引入ERP
    --触发SO变更接口（BOOK登记通过SO变更一起发给ERP，故不需再调用BOOK登记接口）
    /*PKG_SO_BIZ.P_SO_TO_ERP(V_SO_HEADER_ID,
                           PKG_SO_PUB.V_ERP_TRXCODE_CHANGE,
                           P_RESULT,
                           P_ERR_MSG);
    PKG_SO_PUB.P_EXCEPTION_THROWS(P_RESULT);
    
    IF (V_BIZ_SRC_TYPE = PKG_SO_PUB.V_BIZ_SRC_BILL_SO_RED) OR
       (V_BIZ_SRC_TYPE = PKG_SO_PUB.V_BIZ_SRC_BILL_RETURN) THEN
      --销售单红冲单、退货单结算后触发ERP RMA接收
      PKG_SO_BIZ.P_SO_TO_ERP(V_SO_HEADER_ID,
                             PKG_SO_PUB.V_ERP_TRXCODE_RMA_RECV,
                             P_RESULT,
                             P_ERR_MSG);
      PKG_SO_PUB.P_EXCEPTION_THROWS(P_RESULT);
    END IF;*/
  
    /*IF V_ENTITY_ID = PKG_SO_PUB.V_ENTITY_ID_MDC THEN
      --拉式关联交易（厨房电器）
      IF (V_BIZ_SRC_TYPE = PKG_SO_PUB.V_BIZ_SRC_BILL_SO) THEN
        --拉式销售单触发关联交易订单，同时关联交易PO接收后触发客户SO挑库、发运确认（待实现......）
        P_ERR_MSG := 'HELLOOOOOOOOOOOOOOO';
      ELSIF (V_BIZ_SRC_TYPE = PKG_SO_PUB.V_BIZ_SRC_BILL_RETURN) THEN
        --根据退货单是否有源单分：拉式源单退回和拉式反向销售（待实现......）
        P_ERR_MSG := 'KITYYYYYYYYYYYYYYYY';
      END IF;
    END IF;*/
    --财务单引入ERP完成
  EXCEPTION
    WHEN PKG_SO_PUB.V_BIZ_EXCEPTION THEN
      P_RESULT  := -28207;
      P_ERR_MSG := '财务单据[单据号：' || P_SO_HEADER.SO_NUM || ']更新出错：' || substr(dbms_utility.format_error_backtrace,
                                                   1,
                                                   100)||
                   P_ERR_MSG;
    WHEN OTHERS THEN
      P_RESULT  := -28207;
      P_ERR_MSG := '财务单据[单据号：' || P_SO_HEADER.SO_NUM || ']更新发生异常：' || substr(dbms_utility.format_error_backtrace,
                                                   1,
                                                   100)||
                   SQLERRM;
  END P_SO_SETTLE_UPDATE;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2016-08-03
  *     创建者：周建刚
  *   功能说明：财务单据结算前校验客户应收。
                1、如果存在应收，就不能结算单据
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_SETTLE_CHECK(P_SO_HEADER IN  T_SO_HEADER%ROWTYPE, --销售单据头记录
                              P_RESULT    OUT NUMBER, --返回错误ID
                              P_ERR_MSG   OUT VARCHAR2 --返回错误信息
                                ) IS
    V_AMOUNT_LEFT            NUMBER := -1;
    V_GREDIT_GROUP_ID        NUMBER;
    CUR_SALES_ACCOUNT_AMOUNT T_SALES_ACCOUNT_AMOUNT%ROWTYPE;
    
    V_PRICE_LIST_ID          VARCHAR2(100); --价格列表id
    V_VENDOR_CODE            VARCHAR2(100); --供应商编码
    V_PRICE                  NUMBER; --不含税价格
    V_CURR_DATE              DATE;    --当前日期 
    V_DATA_FORMAT            VARCHAR2(10) := 'YYYY-MM-DD';    --日期格式 
    V_SALES_RETURN_FLAG T_INV_INVENTORIES.SALES_FLAG%TYPE;
    
  BEGIN
    --初始返回值
    P_RESULT  := PKG_SO_PUB.V_RESULT;
    P_ERR_MSG := PKG_SO_PUB.V_SUCCESS;
    V_GREDIT_GROUP_ID := FUN_GET_CREDITGROUPID(P_SO_HEADER.ENTITY_ID,
                                               P_SO_HEADER.CUSTOMER_ID,
                                               P_SO_HEADER.SALES_MAIN_TYPE,
                                               P_SO_HEADER.ACCOUNT_ID);
     --add增加仓库有效性校验2019-5-15
      --如果是销售单和销售红冲，则取发货仓库的销售标识
      IF P_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE = '1001' OR P_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE = '1002' THEN
        SELECT T.SALES_FLAG INTO V_SALES_RETURN_FLAG
          FROM CIMS.T_INV_INVENTORIES T
          WHERE T.ENTITY_ID= P_SO_HEADER.ENTITY_ID  --增加主体判断
            and T.INVENTORY_CODE = P_SO_HEADER.SHIP_INV_CODE;
        IF 'Y' != V_SALES_RETURN_FLAG THEN
          P_ERR_MSG := '财务单[单据号：' || P_SO_HEADER.SO_NUM || ']的收货仓可销售标记为' || V_SALES_RETURN_FLAG || '，不能结算。';
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
        END IF;
      --如果是退货单和退货红冲，则取收货仓库的退货标识
      ELSIF P_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE = '1003' OR P_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE = '1004' THEN
        SELECT T.RETURN_FLAG INTO V_SALES_RETURN_FLAG
          FROM CIMS.T_INV_INVENTORIES T
          WHERE T.ENTITY_ID= P_SO_HEADER.ENTITY_ID  --增加主体判断
            AND T.INVENTORY_CODE = P_SO_HEADER.CONSIGNEE_INV_CODE;
        IF 'Y' != V_SALES_RETURN_FLAG THEN
          P_ERR_MSG := '财务单[单据号：' || P_SO_HEADER.SO_NUM || ']的收货仓可退货标记为' || V_SALES_RETURN_FLAG || '，不能结算。';
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
        END IF;
      END IF;
      --end 2019-5-15
    
    --内部关联交易客户必须完成关联物流对应的PO接收后才可结算
    IF (NVL(P_SO_HEADER.ENTITY_CUST_FLAG,PKG_SO_PUB.V_NO) = PKG_SO_PUB.V_YES AND (P_SO_HEADER.ERP_LOGIST_RECEIVE_FLAG = PKG_SO_PUB.V_NO OR P_SO_HEADER.ERP_LOGIST_RECEIVE_DATE IS NULL)) THEN
       P_RESULT  := -28207;
       P_ERR_MSG := P_SO_HEADER.BIZ_SRC_BILL_TYPE_NAME || '[' || P_SO_HEADER.SO_NUM || ']还没有完成内部关联交易的PO签收，不可以结算！';
       RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
    END IF;

    BEGIN                                      
      SELECT T.*
        INTO CUR_SALES_ACCOUNT_AMOUNT
        FROM T_SALES_ACCOUNT_AMOUNT T
       WHERE T.ENTITY_ID = P_SO_HEADER.ENTITY_ID
         AND T.CUSTOMER_ID = P_SO_HEADER.CUSTOMER_ID
         AND T.ACCOUNT_ID = P_SO_HEADER.ACCOUNT_ID
         AND T.CREDIT_GROUP_ID = V_GREDIT_GROUP_ID;
      --应收 = 到款金额 - 销售金额
      V_AMOUNT_LEFT := NVL(CUR_SALES_ACCOUNT_AMOUNT.RECEIVED_AMOUNT,0) -
                       NVL(CUR_SALES_ACCOUNT_AMOUNT.SALES_AMOUNT,0);
    EXCEPTION
      WHEN OTHERS THEN
      P_RESULT  := -28209;
      P_ERR_MSG := '查询客户款项时报错！单据[' || P_SO_HEADER.SO_NUM || '],客户[' || P_SO_HEADER.CUSTOMER_ID || ',' || P_SO_HEADER.CUSTOMER_CODE || '],账户[' || P_SO_HEADER.ACCOUNT_ID || ',' || P_SO_HEADER.ACCOUNT_CODE || '],额度组[' || V_GREDIT_GROUP_ID || '],发生异常：' ||
                   SQLERRM;
      RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
    END;
                     
    --单据结算前检查是否需要校验客户应收，如果需要且存在应收，就不能结算单据。
    IF (CUR_SALES_ACCOUNT_AMOUNT.RECEIVABLE_CRTL_FLAG = '0' AND V_AMOUNT_LEFT < 0) THEN
       P_RESULT  := -28207;
       P_ERR_MSG := '客户[' || P_SO_HEADER.CUSTOMER_CODE || '],账户[' || P_SO_HEADER.ACCOUNT_CODE || '],存在应收[' || V_AMOUNT_LEFT || '],不可以结算！';
    END IF;
    
    --拉式模式单据(销售单、退货红冲单、无源退货单[反向销售单])结算时统一做‘事业部底价是否存在对应的价格’校验
    IF (NVL(P_SO_HEADER.TRX_MODE,'') = PKG_SO_PUB.V_TRADE_MODE_PULL 
      AND NVL(P_SO_HEADER.IS_MATERIAL,PKG_SO_PUB.V_NO) = PKG_SO_PUB.V_NO
      AND (P_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE IN ('1001','1004') 
         OR (P_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE = '1003' AND P_SO_HEADER.RETURN_MODE = '3'))) THEN
      BEGIN
        --供应商信息
        SELECT A.VENDOR_CODE --供应商编码
          INTO V_VENDOR_CODE
          FROM V_INV_VENDOR_VIEW A
         WHERE A.ENTITY_ID = P_SO_HEADER.ENTITY_ID --实体ID
           AND A.OPERATING_UNIT = P_SO_HEADER.FACTORY_OU_ID --供方OU ID --供方OU ID --20150427 chen.wj 查询供应商信息，只用工厂OU查询。啊甘、欧阳讨论决定
           AND ROWNUM = 1;
      EXCEPTION
        WHEN OTHERS THEN
          P_ERR_MSG := 'T_INV_VENDOR_ORGANIZATION表查询供应商信息异常：' || SQLERRM ||
                       ',主体ID[' || P_SO_HEADER.ENTITY_ID || '],工厂OU_ID[' ||
                       P_SO_HEADER.FACTORY_OU_ID || ']';
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      END;
    
      BEGIN
        --供应商价格列表
        SELECT A.PRICE_LIST_ID --价格列表ID
          INTO V_PRICE_LIST_ID
          FROM T_BD_VENDOR_PRICELIST A
         WHERE A.ENTITY_ID = P_SO_HEADER.ENTITY_ID
           AND A.TYPE_CODE = 'TRANSIT_TYPE' --add by chen.wj 20150326 增加 中转采购 类别
           AND A.VENDOR_CODE = V_VENDOR_CODE --供应商编码
              --add by chen.wj 20150403 增加有效日期条件
           AND TRUNC(P_SO_HEADER.SO_DATE) >= A.BEGIN_DATE
           AND TRUNC(P_SO_HEADER.SO_DATE) <= NVL(A.END_DATE, SYSDATE);
      EXCEPTION
        WHEN OTHERS THEN
          P_ERR_MSG := 'T_BD_VENDOR_PRICELIST表查询不到记录,供应商编码[' || V_VENDOR_CODE || ']';
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      END;
    
      FOR REC IN (SELECT A.ITEM_CODE        AS SUPPLIER_ITEM_NUM
                  FROM T_SO_LINE A
                 WHERE A.SO_HEADER_ID = P_SO_HEADER.SO_HEADER_ID
                 ORDER BY A.SO_LINE_NUM) LOOP
        --取当前日期
        V_CURR_DATE := TO_DATE(TO_CHAR(SYSDATE, V_DATA_FORMAT),
                               V_DATA_FORMAT);

        BEGIN
          V_PRICE := PKG_BD_PRICE.F_GET_PRICE(P_SO_HEADER.ACCOUNT_ID, --账户ID
                                              REC.SUPPLIER_ITEM_NUM, --产品编码\
                                              TO_CHAR(V_CURR_DATE,
                                                      'yyyymmdd'), --单据日期 update by wangc 2015-6-23
                                             -- TO_CHAR(R_SO_HEADER.SO_DATE,
                                             --         'yyyymmdd'), --单据日期
                                              V_PRICE_LIST_ID, --价格列表ID
                                              P_SO_HEADER.ENTITY_ID); --业务主体ID
          IF V_PRICE IS NULL THEN
            P_ERR_MSG := '账号[' || P_SO_HEADER.ACCOUNT_CODE || ',' || P_SO_HEADER.ACCOUNT_ID || '],产品编码[' ||
                         REC.SUPPLIER_ITEM_NUM || '],价格列表ID[' ||
                         V_PRICE_LIST_ID || '],主体ID[' || P_SO_HEADER.ENTITY_ID ||
                         ']，获取不到不含税价格，请检查产品不含税价格配置！';
            RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
          END IF;
        EXCEPTION
          WHEN OTHERS THEN
            P_ERR_MSG := 'PKG_BD_PRICE.F_GET_PRICE 获取产品[' || REC.SUPPLIER_ITEM_NUM || ']不含税价格发生异常。单据[' ||
                         P_SO_HEADER.SO_NUM || '],账户[' || P_SO_HEADER.ACCOUNT_CODE || ',' || P_SO_HEADER.ACCOUNT_ID || '],日期[' || 
                         TO_CHAR(V_CURR_DATE,'yyyymmdd') || '],价格列表[' || V_PRICE_LIST_ID || '],主体ID[' ||
                         P_SO_HEADER.ENTITY_ID || ']';
            RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
        END;
      
      END LOOP;
    END IF;
    
  EXCEPTION
    WHEN PKG_SO_PUB.V_BIZ_EXCEPTION THEN
      P_RESULT  := -28207;
      P_ERR_MSG := '结算校验出错！' || P_ERR_MSG;
    WHEN OTHERS THEN
      P_RESULT  := -28209;
      P_ERR_MSG := '结算时校验客户是否存在应收时出错。单据号[' || P_SO_HEADER.SO_NUM || '],客户[' || P_SO_HEADER.CUSTOMER_CODE || '],账户[' || P_SO_HEADER.ACCOUNT_CODE || '],发生异常：' ||
                   SQLERRM;
  END;
/*  
  PROCEDURE P_TEST(P_RESULT    OUT NUMBER, --返回错误ID
                   P_ERR_MSG   OUT VARCHAR2 --返回错误信息
                                ) IS 
  V_PUSH_OR_PULL varchar2(100);                              
  begin
    PKG_BD.P_GET_PARAMETER_VALUE('SO_AR_PUSH_OR_PULL_1',10,null,null,V_PUSH_OR_PULL);
  EXCEPTION
    WHEN OTHERS THEN
      P_RESULT  := -55555;
      P_ERR_MSG := 'SO_AR_PUSH_OR_PULL主体参数设置异常，请检查。' ||
                   SQLERRM;    
  end;   */
  
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2019-6-5
  *     创建者：hejy3
  *   功能说明：财务单结算
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_SETTLE_BY_SO_ID(IN_SO_HEADER_ID IN T_SO_HEADER.SO_HEADER_ID%TYPE, --销售单据头ID
                                 IN_USER_CODE    IN VARCHAR2, --操作用户编码
                                 OUT_RESULT       OUT NUMBER, --返回错误ID
                                 OUT_ERR_MSG      OUT VARCHAR2 --返回错误信息
                                 )
  IS
    R_SO_HEADER T_SO_HEADER%ROWTYPE;
  BEGIN
    SAVEPOINT SUCCESS_FLAG;
    SELECT H.*
      INTO R_SO_HEADER
      FROM T_SO_HEADER H
     WHERE H.SO_HEADER_ID = IN_SO_HEADER_ID;
    
    PKG_SO_AR.P_SO_SETTLE_PROCESS(P_SO_HEADER => R_SO_HEADER,
                                  P_RESULT    => OUT_RESULT,
                                  P_ERR_MSG   => OUT_ERR_MSG);
    --根据P_RESULT判断是否抛出异常
    PKG_SO_PUB.P_EXCEPTION_THROWS(OUT_RESULT);
  EXCEPTION
    WHEN PKG_SO_PUB.V_BIZ_EXCEPTION THEN
      ROLLBACK TO SUCCESS_FLAG;
      OUT_RESULT  := -28207;
      OUT_ERR_MSG := '财务单据[单据ID：' || IN_SO_HEADER_ID || ']结算出错：' ||
                   OUT_ERR_MSG;
      OUT_ERR_MSG := PKG_BD.F_ADD_ERROR_LOG('PKG_SO_AR.P_SO_SETTLE',
                                          SQLCODE,
                                          '销售单' || IN_SO_HEADER_ID ||
                                          '结算失败：' || OUT_ERR_MSG);
    WHEN OTHERS THEN
      ROLLBACK TO SUCCESS_FLAG;
      OUT_RESULT  := -28207;
      OUT_ERR_MSG := '财务单据[单据ID：' || IN_SO_HEADER_ID || ']结算发生异常：' ||
                   SQLERRM;
      OUT_ERR_MSG := PKG_BD.F_ADD_ERROR_LOG('PKG_SO_AR.P_SO_SETTLE',
                                          SQLCODE,
                                          '销售单' || IN_SO_HEADER_ID ||
                                          '结算失败：' || OUT_ERR_MSG);
  END P_SO_SETTLE_BY_SO_ID;
END PKG_SO_AR;
/

