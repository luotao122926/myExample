create type        SYS_PLSQL_109638_111_1 as table of "CIMS"."SYS_PLSQL_109638_9_1";
/

