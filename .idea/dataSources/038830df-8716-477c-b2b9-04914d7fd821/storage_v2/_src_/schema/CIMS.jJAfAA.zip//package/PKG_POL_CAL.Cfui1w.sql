create PACKAGE PKG_POL_CAL AS
  ------------------------------------------------------------------------------------------------
  --                                                                                            --
  --  政策后台包                                                                                --
  --                                                                                            --
  --                                                                                            --
  ------------------------------------------------------------------------------------------------
  /*
  2014-10-5 梁学荣
  参考原系统，创建政策计算后台包。
  2015-7-13 梁学荣
  P_POLICY_CAL_SUM：采用账户获取上次计算结果中的调整金额
  2016-1-16 梁学荣
  补充缺少的程序P_PUB_SEND_EMAIL、P_AUTO_SEND_EMAIL
  2016-2-23 梁学荣
  修改SAVEPOINT的处理，采用不同的名称，以避免出错处理不成功导致报错。
  2016-3-2 梁学荣
  修改P_PUB_SEND_EMAIL，对于IS_MAIL_LIST为“AUTO”则根据，模板中配置的收件人SQL获取
  2016-8-31 梁学荣
  1、增加对5个分类字段、50个项目值字段的支持，修改程序包括：
  PKG_POL_CAL.P_GET_SQL_VALUE
  PKG_POL_CAL.P_GET_OUT_DATA_VALUE
  PKG_POL_CAL.P_GET_ADJUST_VALUE
  PKG_POL_CAL.P_GET_FUN_VALUE
  PKG_POL_CAL.P_POLICY_CAL_SUM
  2、PKG_POL_CAL.P_AFFIRM_RESULT：按客户账户汇总写Y单行
  3、PKG_POL_CAL.P_DEFINE_TRANC：优化EXCEL转数据库表达式的处理
  2016-12-7 梁学荣
  将数组STRING_ARRAY定义改为VARCHAR2(1000)，避免超长
  2016-12-12 梁学荣
  修改P_POLICY_CAL_SUM：金额字段采用四舍五入取两位小数写T_POL_POLICY_RESULT
  修改P_GET_FUN_VALUE：对于应用到公式中的数值为负数，则采用括号包起来，避免两个“-”认为是注释
  2016-12-17 梁学荣
  修改P_GET_SQL_VALUE：对于预处理获取动态条件，则以约定的[P_CONDITION_SQL]替换SQL
  2017-2-9 梁学荣
  修改F_GET_DB_EXPRESSION：作为统一入口调用递归处理程序，调用前处理公式。
  修改P_DEFINE_TRANC：直接使用原公式带入，统一由公式转换过程中处理空格等。
  2017-8-31 梁学荣
  修改P_DEFINE_CHECK：增加检查：是否有客户分类；语义检查是否有对应的商品分类；检查公式是否正确
  修改P_POLICY_CALCULATE：对于正常计算而无计算结果则更新出错信息为“无数据”
  2017-9-28 梁学荣
  修改F_GET_DB_EXPRESSION：修正只有最后一项有效的问题
  增加P_POLICY_CAL_ITEM_DETAIL：生成产品明细计算结果
  修改P_AFFIRM_RESULT：将政策分组信息带入返利单行中，并更新产品计算结果明细中的调整值
  2017-12-11 梁学荣
  修改P_AFFIRM_RESULT：将返利结果审批中的F单备注信息带到Y单行中
  修改P_SET_RPT_DEFINE：将数值格式“#,###.##”改为“#,###”
  修改P_DEFINE_CHECK：对于没有定义返利取值字段，则报错
  修改P_SET_RPT_DEFINE：报表标题取消政策名称
  2017-12-12 梁学荣
  修改F_SPLIT_ORDER：拆单后的Y单行带上原单的算法分组等信息
  2018-1-12 梁学荣
  修改P_AFFIRM_RESULT：支持20个金额字段拆分生成Y单行
  2018-1-25 梁学荣
  修改P_AFFIRM_RESULT：支持一个政策多Y单时，按算法指定的Y单生成Y单行
  修改计算结果已返利金额(REBATE_AMOUNT)处理，于转返利时不更新，保持初始的已转返利金额
  修改程序包括：P_GET_POLICY_STATUS、P_POLICY_CAL_SUM
  修改P_DEFINE_CHECK：增加对应计返利项目正确性检查
  修改P_POLICY_CALCULATE：运算前先检查政策定义
  2018-3-22 梁学荣
  修改P_TO_ITEM_DETAIL：改为取已返利计算结果对应的明细更新到新的计算结果明细中
  修改P_SET_ITEM_DETAIL_SPLIT_ADJUST：转返利后将后面生成计算结果内容都更新产品明细中的已转返利金额
  */

  -----------------------------------------------------------------------------
  --      获取主体语义                                                       --
  -----------------------------------------------------------------------------
  PROCEDURE P_GET_ENTITY_SEMANTIC(IN_SEMANTIC_CODE          IN VARCHAR2 --语义编码
                                 ,IN_ENTITY_ID              IN NUMBER   --主体ID
                                 ,OS_SEMANTIC_TYPE         OUT VARCHAR2 --语义类型：SQL取值、计算公式
                                 ,OS_SEMANTIC_VAL          OUT VARCHAR2 --取值SQL
                                 ,OS_PRE_PROC_SQL          OUT VARCHAR2 --预处理SQL
                                 ,OS_QUERY_CODE            OUT VARCHAR2 --查询条件编码
                                 ,OS_FREEZE_QUERY_CODE     OUT VARCHAR2 --冻结明细查询条件编码
                                 ,OS_MESSAGE               OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
                                 );

  -----------------------------------------------------------------------------
  --  政策算法定义检查过程：                                                   --
  -----------------------------------------------------------------------------
  PROCEDURE P_DEFINE_CHECK(IN_POLICY_ID          IN NUMBER     --政策ID
                          ,OS_MESSAGE           OUT VARCHAR2   --成功则返回“OK”，否则返回出错信息
                           );

  -----------------------------------------------------------------------------
  --  根据台阶兑现标准生成计算公式：                                                   --
  -----------------------------------------------------------------------------
  PROCEDURE P_CREATE_DEF_STD_EXP(IN_DEFINE_ID          IN NUMBER     --算法定义ID
                                ,IS_STD_STEP_FLAG      IN VARCHAR2   --是否区分台阶
                                ,OS_CAL_EXP           OUT VARCHAR2   --计算公式
                                ,OS_MESSAGE           OUT VARCHAR2   --成功则返回“OK”，否则返回出错信息
                                );

  -----------------------------------------------------------------------------
  --  将EXCEL表达式转换成数据库表达式  
  -----------------------------------------------------------------------------
  FUNCTION F_GET_DB_EXPRESSION
  (
    IS_EXPRESSION       IN  VARCHAR2     --EXCEL表达式
  )
  RETURN VARCHAR2;

  -----------------------------------------------------------------------------
  --  政策算法定义(计算公式)转换过程：                                                   --
  -----------------------------------------------------------------------------
  PROCEDURE P_DEFINE_TRANC(IN_POLICY_ID          IN NUMBER     --政策ID
                          ,IS_USER_ID            IN VARCHAR2   --用户账号
                          ,OS_MESSAGE           OUT VARCHAR2   --成功则返回“OK”，否则返回出错信息
                          );

  -----------------------------------------------------------------------------
  --  政策状态                                                               --
  -----------------------------------------------------------------------------
  PROCEDURE P_GET_POLICY_STATUS(IN_POLICY_ID              IN NUMBER   --政策ID
                               ,OS_STATUS                OUT VARCHAR2 --返回状态
                               ,OS_MESSAGE               OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
                               );

  -----------------------------------------------------------------------------
  --  来源SQL计算明细结果                                                    --
  -----------------------------------------------------------------------------
  PROCEDURE P_GET_SQL_VALUE(IN_DEFINE_ID              IN NUMBER   --政策算法定义ID
                           ,ID_RESULT_DATE            IN DATE     --报表日期
                           ,IS_USER_ID                IN VARCHAR2 --用户账号
                           ,IS_PRE_CALC               IN VARCHAR2 --试算标识（Y/N）
                           ,OS_MESSAGE               OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
                           );

  -----------------------------------------------------------------------------
  --  按公式取值的函数                                                               --
  -----------------------------------------------------------------------------
  PROCEDURE P_GET_FUN_VALUE(IN_DEFINE_ID              IN NUMBER   --政策算法定义ID
                           ,ID_RESULT_DATE            IN DATE     --报表日期
                           ,IS_USER_ID                IN VARCHAR2 --用户账号
                           ,OS_MESSAGE               OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
                           );

  -----------------------------------------------------------------------------
  --  按调整项取值                                                     --
  -----------------------------------------------------------------------------
  PROCEDURE P_GET_OUT_DATA_VALUE(IN_DEFINE_ID              IN NUMBER   --政策算法定义ID
                                ,ID_RESULT_DATE            IN DATE     --报表日期
                                ,IS_USER_ID                IN VARCHAR2 --用户账号
                                ,OS_MESSAGE               OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
                                ) ;

  -----------------------------------------------------------------------------
  --  政策结果明细计算过程                                                   --
  -----------------------------------------------------------------------------
  PROCEDURE P_POLICY_CAL_DETAIL(IN_POLICY_ID              IN NUMBER   --政策ID
                               ,ID_RESULT_DATE            IN DATE     --报表日期
                               ,IS_USER_ID                IN VARCHAR2 --用户账号
                               ,IS_PRE_CALC               IN VARCHAR2 --试算标识（Y/N）
                               ,OS_MESSAGE               OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
                               );

  -----------------------------------------------------------------------------
  --  生成产品明细计算结果                                                   --
  -----------------------------------------------------------------------------
  PROCEDURE P_POLICY_CAL_ITEM_DETAIL(
    IN_POLICY_ID               IN  NUMBER   --政策ID
    ,ID_RESULT_DATE            IN  DATE     --报表日期
    ,IN_ENTITY_ID              IN  NUMBER   --主体ID
    ,IS_USER_ID                IN  VARCHAR2 --用户账号
    ,OS_MESSAGE                OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  );

  -----------------------------------------------------------------------------
  --  政策结果汇总计算过程                                                   --
  -----------------------------------------------------------------------------
  PROCEDURE P_POLICY_CAL_SUM(IN_POLICY_ID              IN NUMBER   --政策ID
                            ,ID_RESULT_DATE            IN DATE     --报表日期
                            ,IS_RESULT_DEFINE_CODE     IN VARCHAR2 --报表日期
                            ,IS_USER_ID                IN VARCHAR2 --用户账号
                            ,OS_REPORT_ERR_MSG        OUT VARCHAR2 --报表出错信息，没有出错则为NULL
                            ,OS_MESSAGE               OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
                            );

  -----------------------------------------------------------------------------
  --  政策结果计算过程                                                       --
  -----------------------------------------------------------------------------
  PROCEDURE P_POLICY_CALCULATE(IN_POLICY_ID              IN NUMBER   --政策ID
                              ,ID_RESULT_DATE            IN DATE     --报表日期
                              ,IS_USER_ID                IN VARCHAR2 --用户账号
                              ,IS_PRE_CALC               IN VARCHAR2 --试算标识（Y/N）
                              ,ON_PRE_CALC_AMOUNT       OUT NUMBER   --试算结果金额
                              ,OS_MESSAGE               OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
                              );

  -----------------------------------------------------------------------------
  --  政策申请金额计算过程                                                   --
  -----------------------------------------------------------------------------
  PROCEDURE P_POL_AMOUNT_CAL(IS_SEMANTIC_CODE          IN VARCHAR2 --语义编码
                            ,IS_CONDITION_SQL          IN VARCHAR2 --限制条件
                            ,IN_POLICY_ID              IN NUMBER --政策ID
                            ,IN_ENTITY_ID              IN NUMBER --主体ID
                            ,ON_AMOUNT                OUT NUMBER   --计算金额
                            ,OS_MESSAGE               OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
                            );

  -----------------------------------------------------------------------------
  --      确认报表结果－全部                                                 --
  -----------------------------------------------------------------------------
  PROCEDURE P_AFFIRM_RESULT(IN_POLICY_CHK_ID          IN NUMBER   --政策报表ID
                           ,IS_USER_ID                IN VARCHAR2 --用户账号
                           ,OS_MESSAGE               OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
                           );

  -----------------------------------------------------------------------------
  --  政策邮件通知过程                                                       --
  -----------------------------------------------------------------------------
  PROCEDURE P_POLICY_MAIL(IN_POLICY_ID              IN NUMBER   --政策ID
                         ,OS_MESSAGE               OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
                         );

  -----------------------------------------------------------------------------
  --  政策发邮件过程，成功则返回OK，否则返回出错信息                         --
  -----------------------------------------------------------------------------
  FUNCTION F_POLICY_SEND_EMAIL
  (
     IS_POLICY_ID    IN VARCHAR2  --政策ID
     ,ID_REPORT_DATE IN DATE      --报表日期
     ,IS_ACCOUNT_ID  IN VARCHAR2  --帐户ID
  )
  RETURN VARCHAR2;

  -----------------------------------------------------------------------------
  --  政策发邮件过程，成功则返回OK，否则返回出错信息                         --
  -----------------------------------------------------------------------------
  PROCEDURE P_POLICY_SEND_EMAIL
  (
     IS_POLICY_ID    IN VARCHAR2  --政策ID
     ,ID_REPORT_DATE IN DATE      --报表日期
     ,IS_ACCOUNT_ID  IN VARCHAR2  --帐户ID
     ,OS_MESSAGE     OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  );

  -----------------------------------------------------------------------------
  --  根据参数处理发邮件过程，由前台JOB调用                                       --
  -----------------------------------------------------------------------------
  PROCEDURE P_PUB_SEND_EMAIL
  (
    IS_TEMPLET_NAME     IN  VARCHAR2    --发邮件模板名称
    ,IS_MAIL_LIST       IN  VARCHAR2    --收件人邮箱清单，用“;”作为分隔符
  );

  -----------------------------------------------------------------------------
  --  自动根据SQL发邮件过程，由JOB调用                                       --
  -----------------------------------------------------------------------------
  PROCEDURE P_AUTO_SEND_EMAIL;

  -----------------------------------------------------------------------------
  --  政策计算调用过程，完成后调用邮件通知                                   --
  -----------------------------------------------------------------------------
  PROCEDURE P_POLICY_CAL_JOB_D(IN_ENTITY_ID              IN NUMBER   --主体ID
                            ,ID_RESULT_DATE            IN DATE     --报表日期
                        );

  -----------------------------------------------------------------------------
  --  政策计算调用过程，完成后调用邮件通知，指定日期为昨天                   --
  -----------------------------------------------------------------------------
  PROCEDURE P_POLICY_CAL_JOB(IN_ENTITY_ID              IN NUMBER   --主体ID
                        );

  -----------------------------------------------------------------------------
  --  政策计算调用过程：马上重算。不执行邮件通知                             --
  -----------------------------------------------------------------------------
  PROCEDURE P_POLICY_CAL_JOB_NOW_D(IN_ENTITY_ID              IN NUMBER   --主体ID
                                ,ID_RESULT_DATE            IN DATE     --报表日期
                                );

  -----------------------------------------------------------------------------
  --  政策计算调用过程：马上重算。不执行邮件通知，指定日期为昨天             --
  -----------------------------------------------------------------------------
  PROCEDURE P_POLICY_CAL_JOB_NOW(IN_ENTITY_ID              IN NUMBER   --主体ID
                                );

 -----------------------------------------------------------------------------
  --  政策申请，计算工程机申请金额及返利金额           --
  -----------------------------------------------------------------------------
  PROCEDURE P_POLICY_CAL_PG(P_ENTITY_ID              IN NUMBER   --主体ID
                            ,P_POLICY_ID          IN NUMBER     --政策ID
                            ,P_CAL_TYPE           IN VARCHAR2  --计算类型，APPLY/DISCOUNT   
                            ,P_CONDITION_SQL      IN VARCHAR2 DEFAULT NULL--条件脚本   
                            ,P_APPLY_AMOUNT      OUT NUMBER    --申请金额
                            ,P_USER_ID            IN VARCHAR2   --用户账号
                            ,P_MESSAGE           OUT VARCHAR2   --成功则返回“OK”，否则返回出错信息
                            );
  

  -----------------------------------------------------------------------------
  --  政策申请金额，计算工程机申请金额及返利金额， 前台语义使用           --
  -----------------------------------------------------------------------------
  FUNCTION F_POLICY_CAL_PG(P_ENTITY_ID              IN NUMBER   --主体ID
                            ,P_POLICY_ID          IN NUMBER     --政策ID
                            ,P_CAL_TYPE           IN VARCHAR2  --计算类型，APPLY/DISCOUNT 
                            ,P_CONDITION_SQL      IN VARCHAR2 DEFAULT NULL--条件脚本                     
                            )RETURN VARCHAR2;
    
  -----------------------------------------------------------------------------
  --  统计SQL取值函数                                                        --
  -----------------------------------------------------------------------------
  FUNCTION F_GET_SQL_VALUE(P_SQL                    VARCHAR2 --SQL脚本
                          ,
                           P_POLICY_ID               NUMBER --单据ID
                          ,
                           P_ENTITY_ID               NUMBER --主体ID
                          ,
                           P_RESULT                 OUT VARCHAR2 --返回信息:1.SUCCESS：正确执行；2.其他：执行失败
                           ) RETURN NUMBER; 
                           
   -----Y转F拆单（手工转返利）
   PROCEDURE P_Y2F_SPLIT(P_LIMIT   IN NUMBER
                        ,P_LINE_ID  IN NUMBER
                        ,P_MESSAGE   OUT VARCHAR2
                        ,P_LINE_ID_NEW OUT NUMBER
                         );
                         
   -----------------------------------------------------------------------------
   --  厨电拆单（自动计算转返利）                                                               --
   -----------------------------------------------------------------------------
   FUNCTION F_SPLIT_ORDER(P_POLICY_CHK_ID    NUMBER   --政策审批ID
                          ,P_POLICY_ORDER_ID    IN NUMBER  --返利申请ID
                          ,P_POLICY_ID          IN NUMBER  --政策ID
                          ,P_ENTITY_ID          IN NUMBER  --主体ID
                          ,P_USER               IN VARCHAR2  --用户
                         ) RETURN VARCHAR2;
                         
   ----检查客户、账户及营销大类的关系
   PROCEDURE P_CHECK_CUST_ACCT_SALE(P_POLICY_CHK_ID  IN NUMBER
                                   ,P_ENTITY_ID      IN NUMBER
                                   ,P_MESSAGE      OUT VARCHAR2
                                     );
  
  -----------------------------------------------------------------------------
  --  政策申请，计算工程机申请金额                                           --
  -----------------------------------------------------------------------------
  PROCEDURE P_POLICY_CAL_PG_APPLY(P_ENTITY_ID     IN NUMBER --主体ID
                           ,P_POLICY_ID     IN NUMBER --政策ID
                           ,P_USER_ID       IN VARCHAR2 --用户账号
                           ,P_APPLY_AMOUNT  OUT NUMBER --申请金额
                           ,P_MESSAGE       OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
                            );

  -----------------------------------------------------------------------------
  --  政策申请，计算中央空调运费                                          --
  -----------------------------------------------------------------------------
  PROCEDURE P_POLICY_CAL_TRANS_FEE(P_ENTITY_ID IN NUMBER, --主体ID
                                   P_POLICY_ID IN NUMBER, --政策ID
                                   P_DEFINE_ID IN NUMBER, --算法定义ID
                                   P_USER_ID   IN VARCHAR2, --用户账号
                                   P_MESSAGE   OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
                                   );
  ----------------------------------------------------------------------
  --  拆分字符串为数组
  ----------------------------------------------------------------------
  FUNCTION F_SPLIT_STR(AS_STR IN VARCHAR2, AS_SPLIT_STR IN VARCHAR2)
    RETURN TYPE_SPLIT;
 PROCEDURE P_TO_POL_ORDER_LINE
  (
    IN_POLICY_CHK_ID      IN NUMBER   --政策计算结果审批ID
    ,IN_POLICY_ORDER_ID   IN NUMBER   --政策申请ID
    ,IS_DISCOUNT_METHOD   IN VARCHAR2 --折让方式
    ,IS_REF_MODEL         IN VARCHAR2 --涉及机型
    ,IS_SALES_MAIN_TYPE   IN VARCHAR2 --营销大类
    ,IN_ENTITY_ID         IN NUMBER   --主体ID
    ,IS_USER_ID           IN VARCHAR2 --用户账号
    ,OS_MESSAGE           OUT VARCHAR2   --成功则返回“OK”，否则返回出错信息
  ) ;
END PKG_POL_CAL;
/

