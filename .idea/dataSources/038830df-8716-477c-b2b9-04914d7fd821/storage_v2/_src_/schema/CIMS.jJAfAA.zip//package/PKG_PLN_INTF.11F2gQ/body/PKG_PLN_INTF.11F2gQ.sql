create Package Body Pkg_Pln_Intf Is

  v_Nl    Constant Varchar2(2) := Chr(13) || Chr(10); --换行
  v_True  Constant Varchar2(2) := 'Y';
  v_False Constant Varchar2(2) := 'N';
  --V_RESULT         CONSTANT NUMBER := 0; --成功返回
  v_Success Constant Varchar2(10) := 'SUCCESS';

  v_Entity_Type    Constant Varchar2(2) := 'BU';
  v_Sales_Cen_Type Constant Varchar2(2) := 'SC';
  v_Base_Exception Exception; --自定义异常
  ITEM_LIFECYCLE_SALE CONSTANT VARCHAR2(100) := 'SALE';
  
  ----------------------------------------------------------------------
  -- Author  : NICRO.LI
  -- Created : 2014-07-23 08:55:53
  -- Purpose : 外部系统调用接口过程，检查数据是否正确
  ----------------------------------------------------------------------
  Procedure p_Chk_Cus_Order(p_Intf_Id In Number, p_Result Out Varchar2) Is
    PRAGMA AUTONOMOUS_TRANSACTION;
    r_Cust_Order_Head Intf_Cust_Order_Head%Rowtype;
    v_Value           Varchar2(1000);
    v_Count           Number;
    v_Item_Code       Varchar2(3000);
    v_action_flag     Varchar2(10);
  Begin
    p_Result := v_Success;
    Begin
      v_Value := '锁定客户订单接口头表失败！';
      Select *
        Into r_Cust_Order_Head
        From Intf_Cust_Order_Head h
       Where h.Intf_Id = p_Intf_Id
         And h.Intf_Status = '01'
         For Update Nowait;
    Exception
      When Others Then
        p_Result := v_Value || v_Nl || Sqlerrm;
        Goto Errlable;
    End;
    --检查单据类型
    Begin
      v_Value := '单据类型检查：';
      Select Count(1)
        Into v_Count
        From t_Pln_Order_Type Ot
       Where Ot.Order_Type_Id = r_Cust_Order_Head.Order_Type_Id
         And Trunc(r_Cust_Order_Head.Intf_Date) Between Ot.Begin_Date And
             Trunc(Nvl(Ot.End_Date, Sysdate));
      If v_Count <= 0 Then
        p_Result := v_Value || '单据类型ID：' ||
                    To_Char(r_Cust_Order_Head.Order_Type_Id) ||
                    '不存在或者单据类型已失效。';
        Goto Errlable;
      End If;
    Exception
      When Others Then
        p_Result := v_Value || '单据类型ID：' ||
                    To_Char(r_Cust_Order_Head.Order_Type_Id) ||
                    '不存在或者单据类型失效。';
        Goto Errlable;
    End;
    --检查营销中心
    Begin
      v_Value := '营销中心检查：';
      Select Count(1)
        Into v_Count
        From Up_Org_Unit u
       Where u.Unit_Id = r_Cust_Order_Head.Sales_Center_Id
         And u.active_flag = 'T';
      If v_Count <= 0 Then
        p_Result := v_Value || '营销中心ID：' ||
                    To_Char(r_Cust_Order_Head.Sales_Center_Id) ||
                    '不存在或者中心已失效。';
        Goto Errlable;
      End If;
    Exception
      When Others Then
        p_Result := v_Value || '营销中心ID：' ||
                    To_Char(r_Cust_Order_Head.Sales_Center_Id) ||
                    '不存在或者中心已失效。';
        Goto Errlable;
    End;
    Begin
      v_Value := '客户账户检查：';
      Select ca.active_flag
        Into v_action_flag
        From t_Customer_Account Ca
       Where Ca.Account_Id = r_Cust_Order_Head.Account_Id;
      If Nvl(v_action_flag, v_false) <> v_true Then
        p_Result := v_Value || '账户ID：' ||
                    To_Char(r_Cust_Order_Head.Account_Id) || '账户未激活。';
        Goto Errlable;
      End If;
    Exception
      When Others Then
        p_Result := v_Value || '账户ID：' ||
                    To_Char(r_Cust_Order_Head.Account_Id) || '账户不存在。' || v_Nl ||
                    Sqlerrm;
        Goto Errlable;
    End;
    For r_Line In (Select *
                     From Intf_Cust_Order_Line Ol
                    Where Ol.Intf_Id = p_Intf_Id) Loop
      Begin
        v_Value := '产品编码检查：';
        Select Count(1)
          Into v_Count
          From t_Bd_Item Bi
         Where Bi.Item_Code = r_Line.Item_Code
           And Bi.Entity_Id = r_Cust_Order_Head.Entity_Id;
        If v_Count <= 0 Then
          Update Intf_Cust_Order_Line Ol
             Set Ol.Intf_Status  = '03',
                 Ol.Intf_Err_Msg = '商品编码：【' || r_Line.Item_Code ||
                                   '】，不存在或者产品已失效。'
           Where Ol.Intf_Line_Id = r_Line.Intf_Line_Id;
          If v_Item_Code Is Null Then
            v_Item_Code := r_Line.Item_Code;
          Else
            v_Item_Code := v_Item_Code || ',' || r_Line.Item_Code;
          End If;
        End If;
      Exception
        When Others Then
          p_Result := v_Value || '失败。';
      End;
    End Loop;
    If Nvl(v_Item_Code, '_') <> '_' Then
      p_Result := v_Value || '商品编码：【' || v_Item_Code || '】，不存在或者产品已失效。';
      Goto Errlable;
    End If;
    If p_Result = v_Success Then
      Update Intf_Cust_Order_Head Oh
         Set Oh.Intf_Status = '02'
       Where Oh.Intf_Id = r_Cust_Order_Head.Intf_Id;

      Update Intf_Cust_Order_Line Ol
         Set Ol.Intf_Status = '02'
       Where Ol.Intf_Id = r_Cust_Order_Head.Intf_Id;
      Commit;
      /*p_Create_Cus_Order(p_Intf_Id, p_Result);
      If p_Result <> v_Success Then
       Update Intf_Cust_Order_Head Oh
          Set Oh.Intf_Status = '03', Oh.Intf_Err_Msg = p_Result
        Where Oh.Intf_Id = r_Cust_Order_Head.Intf_Id;
      End If;*/
    End If;
    <<errlable>>
    If p_Result <> v_Success Then
      Update Intf_Cust_Order_Head Oh
         Set Oh.Intf_Status = '03', Oh.Intf_Err_Msg = p_Result
       Where Oh.Intf_Id = r_Cust_Order_Head.Intf_Id;
      Commit;
    End If;
  Exception
    When v_Base_Exception Then
      p_Result := p_Result;
    When Others Then
      p_Result := p_Result;
  End;

  ----------------------------------------------------------------------
  -- Author  : NICRO.LI
  -- Created : 2014-07-23 08:55:53
  -- Purpose : 生成客户订单数据
  ----------------------------------------------------------------------
  Procedure p_Create_Cus_Order(p_Intf_Id In Number, p_Result Out Varchar2) Is
    Pragma Autonomous_Transaction;
    r_Cust_Order_Head Intf_Cust_Order_Head%Rowtype;
    Cursor c_Cus_Order_Line Is
      Select *
        From Intf_Cust_Order_Line Ol
       Where Ol.Intf_Id = p_Intf_Id
         And Ol.Intf_Status = '02';
    r_Cus_Order_Line  c_Cus_Order_Line%Rowtype;
    v_Value           Varchar2(1000);
    v_Count           Number;
    v_Item_Id         Number;
    v_Item_Desc       Varchar2(240);
    v_Item_Uom        Varchar2(32);
    v_Order_Type_Code Varchar2(40);
    v_Order_Type_Name Varchar2(100);
    v_Send_By_Type    Varchar2(100);
  
    v_Sales_Center_Code Varchar2(100);
    v_Sales_Center_Name Varchar2(240);
  
    v_Customer_Code Varchar2(100);
    v_Customer_Name Varchar2(240);
  
    v_Account_Code         Varchar2(100);
    v_Account_Name         Varchar2(240);
    v_Advance_Period_Week  Number;
    v_Period_Id            Number;
    v_Period_Code t_Pln_Order_Period.Period_Code%Type;
    v_Period_Week t_Pln_Order_Period.Statistic_Week%Type;
  
    v_Producing_Area_Id    Number;
    v_Producing_Area_Code  Varchar2(100);
    v_Producing_Area_Name  Varchar2(240);
    v_Item_Price           Number;
    v_Discount             Number;
    v_Month_Discount       Number;
    v_Cx_Flag              Varchar2(10);
    v_Invoice_Contract_Id  Number; --开票单位联系人ID
    v_Invoice_Contract     Varchar2(100); --开票单位联系人名称
    v_Invoice_Tel          Varchar2(100); --开票单位联系人电话
    v_Consignee_Id         Number; --收货单位ID
    v_Consignee_Code       Varchar2(240); --收货单位编码
    v_Consignee_Name       Varchar2(240); --收货单位名称
    v_Consignee_Addr       Varchar2(240); --收货地址
    v_Consignment_Addr_Id  Number; --收货地点ID
    v_Consignee_Addr_Code  Varchar2(240); --收货地址编码
    v_Consignee_Contact_Id Number; --收货联系人ID
    v_Consignee_Contract   Varchar2(240); --收货联系人
    v_Consignee_Tel        Varchar2(240); --收货联系电话
  
    v_Order_Head_Id        Number;
    v_Order_Number         Varchar2(60);
    v_Batch_Id             Number;
  Begin
    p_Result := v_Success;
    Begin
      v_Value := '锁定客户订单接口头表失败！';
      Select *
        Into r_Cust_Order_Head
        From Intf_Cust_Order_Head h
       Where h.Intf_Id = p_Intf_Id
         And h.Intf_Status = '02'
         For Update Nowait;
    Exception
      When Others Then
        p_Result := v_Value || v_Nl || Sqlerrm;
    End;
    If p_Result = v_Success Then
      --检查单据类型
      Begin
        v_Value := '单据类型检查：';
        Select Ot.Order_Type_Code,
               Ot.Order_Type_Name,
               Ot.Period_Week,
               Ot.Send_By_Type
          Into v_Order_Type_Code,
               v_Order_Type_Name,
               v_Advance_Period_Week,
               v_Send_By_Type
          From t_Pln_Order_Type Ot
         Where Ot.Order_Type_Id = r_Cust_Order_Head.Order_Type_Id
           And Trunc(r_Cust_Order_Head.Intf_Date) Between Ot.Begin_Date And
               Trunc(Nvl(Ot.End_Date, Sysdate));
      Exception
        When Others Then
          p_Result := v_Value || '单据类型ID：' ||
                      To_Char(r_Cust_Order_Head.Sales_Center_Id) ||
                      '不存在或者单据类型已失效。';
      End;
    End If;
    If p_Result = v_Success Then
      --检查营销中心
      Begin
        v_Value := '营销中心检查：';
        Select u.Code, u.Name
          Into v_Sales_Center_Code, v_Sales_Center_Name
          From Up_Org_Unit u
         Where u.Unit_Id = r_Cust_Order_Head.Sales_Center_Id
           And u.Active_Flag = 'T';
      Exception
        When Others Then
          p_Result := v_Value || '营销中心ID：' ||
                      To_Char(r_Cust_Order_Head.Sales_Center_Id) ||
                      '不存在或者中心已失效。';
      End;
    End If;
    If p_Result = v_Success Then
      Begin
        v_Value := '客户账户检查：';
        Select Ca.Account_Code, Ca.Account_Name
          Into v_Account_Code, v_Account_Name
          From t_Customer_Account Ca
         Where Ca.Account_Id = r_Cust_Order_Head.Account_Id
           And Ca.Active_Flag = v_True;
      Exception
        When Others Then
          p_Result := v_Value || '账户ID：' ||
                      To_Char(r_Cust_Order_Head.Sales_Center_Id) ||
                      '不存在或者账户未激活。';
      End;
    End If;
  
    If p_Result = v_Success Then
      Begin
        v_Value := '客户账户检查：';
        Select Ch.Customer_Code, Ch.Customer_Name
          Into v_Customer_Code, v_Customer_Name
          From t_Customer_Header Ch
         Where Ch.Customer_Id = r_Cust_Order_Head.Customer_Id;
      Exception
        When Others Then
          Null;
          /*p_Result := v_Value || '账户ID：' ||
          To_Char(r_Cust_Order_Head.Sales_Center_Id) ||
          '不存在或者账户未激活。';*/
      End;
    End If;
  
    If p_Result = v_Success Then
      Begin
        v_Value := '获取周期信息';
        Select Op.Period_Id, Op.Period_Code, Op.Statistic_Week
          Into v_Period_Id, v_Period_Code, v_Period_Week
          From t_Pln_Order_Period Op
         Where Op.Entity_Id = r_Cust_Order_Head.Entity_Id
           And Op.Period_Id =
               Pkg_Pln_Pub.f_Get_Default_Period(r_Cust_Order_Head.Order_Type_Id,
                                                r_Cust_Order_Head.Entity_Id);
      Exception
        When Others Then
          p_Result := v_Value || '失败。' || v_Nl || Sqlerrm;
      End;
    End If;
    If p_Result = v_Success Then
      Begin
        Select Tca.Contacts_Id, Tca.Contacts_Name, Tca.Contacts_Phones
          Into v_Invoice_Contract_Id, v_Invoice_Contract, v_Invoice_Tel
          From t_Customer_Account_Address Ca, t_Customer_Address Tca
         Where Ca.Account_Id = r_Cust_Order_Head.Account_Id
           And Tca.Address_Id = Ca.Address_Id
           And Tca.Address_Type = 'BillTo'
           And Rownum <= 1;
      Exception
        When Others Then
          Null;
      End;
    End If;
  
    If p_Result = v_Success Then
      Begin
        Select Tca.Address_Id,
               Tca.Area,
               Tca.Address,
               Tca.Contacts_Id,
               Tca.Contacts_Name,
               Tca.Contacts_Phones
          Into v_Consignee_Id,
               v_Consignee_Addr_Code,
               v_Consignee_Addr,
               v_Consignee_Contact_Id,
               v_Consignee_Contract,
               v_Consignee_Tel
          From t_Customer_Account_Address Ca, t_Customer_Address Tca
         Where Ca.Account_Id = r_Cust_Order_Head.Account_Id
           And Tca.Address_Id = Ca.Address_Id
           And Tca.Address_Type = 'ShipTo'
           And Rownum <= 1;
      Exception
        When Others Then
          Null;
      End;
      Begin
        Select Bd.Row_Id
          Into v_Consignment_Addr_Id
          From t_Bd_District Bd
         Where Bd.District_Code = v_Consignee_Addr_Code;
      Exception
        When Others Then
          Null;
      End;
    End If;
  
    If p_Result = v_Success Then
      Begin
        v_Value             := '获取中心最优产地';
        v_Producing_Area_Id := Pkg_Pln_Pub.f_Get_Cen_Prod_Area_Priority(p_Sales_Center_Id => r_Cust_Order_Head.Sales_Center_Id,
                                                                        p_Item_Id         => 0,
                                                                        p_Entity_Id       => r_Cust_Order_Head.Entity_Id,
                                                                        p_User_Code       => 'admin');
        Select Pa.Producing_Area_Code, Pa.Producing_Area_Name
          Into v_Producing_Area_Code, v_Producing_Area_Name
          From t_Pln_Producing_Area Pa
         Where Pa.Producing_Area_Id = v_Producing_Area_Id
           And Trunc(Sysdate) Between Pa.Begin_Date And
               Trunc(Nvl(Pa.End_Date, Sysdate));
      Exception
        When Others Then
          p_Result := v_Value || '失败，中心ID：' ||
                      To_Char(r_Cust_Order_Head.Sales_Center_Id) || v_Nl ||
                      Sqlerrm;
      End;
    End If;
  
    Begin
      Pkg_Pln_Pub.p_Create_Order_Number(p_Order_Number_Type => 'plnCustOrderNumber', --单据编码规则
                                        p_Period_Id         => v_Period_Id,
                                        p_Sales_Center_Id   => r_Cust_Order_Head.Sales_Center_Id,
                                        p_Entity_Id         => r_Cust_Order_Head.Entity_Id,
                                        p_Order_Number      => v_Order_Number);
      /*v_Order_Number := SubStr(v_Sales_Center_Name, 1, 1) || substr(v_Order_Number, 1, 4)
      || v_period_week || Substr(v_Order_Number, 5, 4);*/
    
      If Nvl(v_Order_Number, '_') = '_' Then
        p_Result := '获取客户订单单号失败，单号编码规则：CUS_ORDER_CODE。';
      End If;
    Exception
      When Others Then
        p_Result := '获取客户订单单号失败，单号编码规则：CUS_ORDER_CODE。';
    End;
    /*
    0 按周报送  plnSendByType
    1 按月报送  plnSendByType
    2 按月多次报送  plnSendByType
    3 按年报送  plnSendByType
    4 按周多次报送  plnSendByType
    */
    If v_Send_By_Type In (2, 4) Then
      Begin
        Select Count(1) + 1
          Into v_Batch_Id
          From t_Pln_Order_Collect_Head Och
         Where Och.Order_Type_Id = r_Cust_Order_Head.Order_Type_Id
           And Och.Period_Id = v_Period_Id;
      Exception
        When Others Then
          v_Batch_Id := 1;
      End;
    Else
      v_Batch_Id := 1;
    End If;
    If p_Result = v_Success Then
      Select s_Pln_Order_Head.Nextval Into v_Order_Head_Id From Dual;
      Begin
        v_Value := '开始插入客户订单头表资料';
        Insert Into t_Pln_Order_Head
          (Entity_Id, --主体ID
           Order_Head_Id, --头ID
           Order_Number, --单号
           Order_Type_Id, --单据类型ID
           Order_Type_Code, --单据类型编码
           Order_Type_Name, --单据类型名称
           Sales_Year_Id, --销售年度ID
           Period_Id, --周期ID
           Period_Code, --周期编码
           Order_Head_State, --
           Form_State, --单据状态
           Old_Order_Number, --原单据号
           Sales_Center_Id, --营销中心ID
           Sales_Center_Code, --营销中心编码
           Sales_Center_Name, --营销中心名称
           Customer_Id, --客户ID
           Customer_Code, --客户编码
           Customer_Name, --客户名称
           Account_Id, --账户ID
           Account_Code, --账户编码
           Account_Name, --账户名称
           Producing_Area_Id, --产地ID
           Producing_Area_Code, --产地编码
           Producing_Area_Name, --产地名称
           Invoice_Customer_Id, --开票单位
           Invoice_Customer_Code, --开票单位编码
           Invoice_Customer_Name, --开票单位名称
           Invoice_Contract_Id, --开票单位联系人ID
           Invoice_Contract, --开票单位联系人名称
           Invoice_Tel, --开票联系人电话
           Consignee_Id, --收货单位ID
           Consignee_Code, --收货单位编码
           Consignee_Name, --收货单位名称
           Consignee_Addr, --收货地址
           Consignment_Addr_Id, --收货地点ID
           Consignee_Addr_Code, --收货地址编码
           Consignee_Contact_Id, --收货联系人ID
           Consignee_Contract, --收货联系人
           Consignee_Tel, --收货联系电话
           Locked_Proportion, --锁款比率
           Sys_Source, --来源系统
           Source_Type, --来源类型
           Source_Order_Number, --来源单号
           Origin_System_Code,  --上级来源系统
           Created_By, --
           Creation_Date, --
           Last_Updated_By, --
           Last_Update_Date, --
           Remark, --备注
           Program_Updated_By, --程序修改来源
           Program_Update_Date, --修改时间
           Version, --版本号（乐观锁） 
           Batch_id,  --批次ID
           Source_Order_Head_Id --来源单据头ID
           )
        Values
          (r_Cust_Order_Head.Entity_Id, --ENTITY_ID --主体ID
           v_Order_Head_Id, --ORDER_HEAD_ID --头ID
           v_Order_Number, --ORDER_NUMBER --单号
           r_Cust_Order_Head.Order_Type_Id, --ORDER_TYPE_ID --单据类型ID
           v_Order_Type_Code, --ORDER_TYPE_CODE --单据类型编码
           v_Order_Type_Name, --ORDER_TYPE_NAME --单据类型名称
           Null, --SALES_YEAR_ID --销售年度ID
           v_Period_Id, --PERIOD_ID --周期ID
           v_Period_Code, --PERIOD_CODE --周期编码
           Null, --ORDER_HEAD_STATE --
           '19', --FORM_STATE --单据状态 ‘制单’ 
           Null, --OLD_ORDER_NUMBER --原单据号
           r_Cust_Order_Head.Sales_Center_Id, --SALES_CENTER_ID --营销中心ID
           v_Sales_Center_Code, --SALES_CENTER_CODE --营销中心编码
           v_Sales_Center_Name, --SALES_CENTER_NAME --营销中心名称
           r_Cust_Order_Head.Customer_Id, --CUSTOMER_ID --客户ID
           v_Customer_Code, --CUSTOMER_CODE --客户编码
           v_Customer_Name, --CUSTOMER_NAME --客户名称
           r_Cust_Order_Head.Account_Id, --ACCOUNT_ID --账户ID
           v_Account_Code, --ACCOUNT_CODE --账户编码
           v_Account_Name, --ACCOUNT_NAME --账户名称
           v_Producing_Area_Id, --PRODUCING_AREA_ID --产地ID
           v_Producing_Area_Code, --PRODUCING_AREA_CODE --产地编码
           v_Producing_Area_Name, --PRODUCING_AREA_NAME --产地名称
           r_Cust_Order_Head.Customer_Id, --开票单位
           v_Customer_Code, --开票单位编码
           v_Customer_Name, --开票单位名称
           v_Invoice_Contract_Id, --INVOICE_CONTRACT_ID --
           v_Invoice_Contract, --INVOICE_CONTRACT --开票联系人名称
           v_Invoice_Tel, --INVOICE_TEL --开票联系人电话
           v_Consignee_Id, --CONSIGNEE_ID --收货单位ID
           v_Customer_Code, --CONSIGNEE_CODE --收货单位编码
           v_Customer_Name, --CONSIGNEE_NAME --收货单位名称
           v_Consignee_Addr, --CONSIGNEE_ADDR --收货地址
           v_Consignment_Addr_Id, --CONSIGNMENT_ADDR_ID --收货地点ID
           v_Consignee_Addr_Code, --CONSIGNEE_ADDR_CODE --收货地址编码
           v_Consignee_Contact_Id, --CONSIGNEE_CONTACT_ID --收货联系人ID
           v_Consignee_Contract, --CONSIGNEE_CONTRACT --收货联系人
           v_Consignee_Tel, --CONSIGNEE_TEL --收货联系电话
           Null, --LOCKED_PROPORTION --锁款比率
           r_Cust_Order_Head.Source_System_Code, --SYS_SOURCE --来源系统
           r_Cust_Order_Head.Source_Order_Type, --SOURCE_TYPE --来源类型
           r_Cust_Order_Head.Source_Order_Number, --SOURCE_ORDER_NUMBER --来源单号
           r_Cust_Order_Head.Origin_System_Code, --origin_system_code
           '-1', --CREATED_BY --
           Sysdate, --CREATION_DATE --
           '-1', --LAST_UPDATED_BY --
           Sysdate, --LAST_UPDATE_DATE --
           r_Cust_Order_Head.Remark, --REMARK --备注
           'PKG_PLN_INTF', --程序修改来源
           Sysdate, --修改时间
           1, --版本号（乐观锁） 
           v_Batch_Id,  --批次ID
           r_Cust_Order_Head.Source_Order_Head_Id  --来源单据头ID
           );
      Exception
        When Others Then
          p_Result := v_Value || '，失败。' || v_Nl || Sqlerrm;
      End;
    End If;
  
    --开始插入订单行商品
    If p_Result = v_Success Then
      Open c_Cus_Order_Line;
      Loop
        Fetch c_Cus_Order_Line
          Into r_Cus_Order_Line;
        Exit When c_Cus_Order_Line%Notfound Or p_Result <> v_Success;
        Begin
          v_Value := '产品编码检查：';
          Select Bi.Item_Id, Bi.Defaultunit, Bi.Item_Name
            Into v_Item_Id, v_Item_Uom, v_Item_Desc
            From t_Bd_Item Bi
           Where Bi.Item_Code = r_Cus_Order_Line.Item_Code
             And Bi.Entity_Id = r_Cust_Order_Head.Entity_Id;
        Exception
          When Others Then
            p_Result := v_Value || '，产品编码：' || r_Cus_Order_Line.Item_Code ||
                        '不存在或者产品已失效';
            --RAISE V_BASE_EXCEPTION;
        End;
        If p_Result = v_Success Then
          Begin
            --v_Value := '获取产品单价：';
            Pkg_Bd_Price.p_Get_Price(p_Acc_Id         => r_Cust_Order_Head.Account_Id,
                                     p_Item_Code      => r_Cus_Order_Line.Item_Code,
                                     p_Bill_Date      => To_Char(Sysdate,
                                                                 'yyyymmdd'),
                                     p_Price_List_Id  => Null,
                                     p_Entity_Id      => r_Cust_Order_Head.Entity_Id,
                                     p_Price          => v_Item_Price,
                                     p_Discount       => v_Discount,
                                     p_Month_Discount => v_Month_Discount,
                                     p_Cx_Flag        => v_Cx_Flag);
          Exception
            When Others Then
              v_Item_Price     := Null;
              v_Discount       := 0;
              v_Month_Discount := 0;
              v_Cx_Flag        := 'N';
          End;
        End If;
        If p_Result = v_Success Then
          Begin
            v_Value := '开始插入订单行表数据';
            Insert Into t_Pln_Order_Line
              (Entity_Id, --主体ID
               Order_Line_Id, --行ID
               Order_Head_Id, --头ID
               Order_Line_State, --单据行状态
               Producing_Area_Id, --产地ID
               Producing_Area_Code, --产地编码
               Producing_Area_Name, --产地名称
               Item_Id, --产品ID
               Item_Code, --产品编码
               Item_Desc, --产品描述
               Item_Uom, --产品单拉
               Item_Price, --产品单价
               Discount_Rate, --折扣率
               Amount, --金额
               --INCLUDE_LINK_PIPE, --是否含连接管
               Apply_Qty, --申请数量
               Check_Qty, --评审数量
               Can_Produce_Qty, --排产数量
               Supply_Qty, --已入库数量
               Created_By, --
               Creation_Date, --
               Last_Updated_By, --
               Last_Update_Date, --
               Remark, --备注
               Source_Line_Id, --备注
               Program_Updated_By, --程序修改来源
               Program_Update_Date, --修改时间
               Version --版本号（乐观锁） 
               )
            Values
              (r_Cust_Order_Head.Entity_Id, --ENTITY_ID --主体ID
               s_Pln_Order_Line.Nextval, --ORDER_LINE_ID --行ID
               v_Order_Head_Id, --ORDER_HEAD_ID --头ID
               '19', --ORDER_LINE_STATE --单据行状态
               v_Producing_Area_Id, --PRODUCING_AREA_ID --产地ID
               v_Producing_Area_Code, --PRODUCING_AREA_CODE --产地编码
               v_Producing_Area_Name, --PRODUCING_AREA_NAME --产地名称
               v_Item_Id, --ITEM_ID --产品ID
               r_Cus_Order_Line.Item_Code, --ITEM_CODE --产品编码
               v_Item_Desc, --ITEM_DESC --产品描述
               v_Item_Uom, --ITEM_UOM --产品单拉
               v_Item_Price, --ITEM_PRICE --产品单价
               v_Discount, --折扣率
               r_Cus_Order_Line.Apply_Qty * v_Item_Price *
               (100 - v_Discount) / 100, --金额
               --NULL, --INCLUDE_LINK_PIPE --是否含连接管
               r_Cus_Order_Line.Apply_Qty, --APPLY_QTY --申请数量
               0, --CHECK_QTY --评审数量
               0, --CAN_PRODUCE_QTY --排产数量
               Null, --SUPPLY_QTY --已入库数量
               '-1', --CREATED_BY --
               Sysdate, --CREATION_DATE --
               '-1', --LAST_UPDATED_BY --
               Sysdate, --LAST_UPDATE_DATE --
               r_Cus_Order_Line.Remark, --REMARK --备注
               r_Cus_Order_Line.Source_Order_Line_Id,
               'PKG_PLN_INTF', --程序修改来源
               Sysdate, --修改时间
               1 --版本号（乐观锁） 
               );
          Exception
            When Others Then
              p_Result := v_Value || '失败。' || v_Nl || Sqlerrm;
          End;
        End If;
        If p_Result <> v_Success Then
          Rollback;
          Update Intf_Cust_Order_Line Ol
             Set Ol.Intf_Err_Msg = p_Result, Ol.Intf_Status = '03'
           Where Ol.Intf_Line_Id = r_Cus_Order_Line.Intf_Line_Id;
        
          Update Intf_Cust_Order_Head Oh
             Set Oh.Intf_Status = '03', Oh.Intf_Err_Msg = p_Result
           Where Oh.Intf_Id = r_Cust_Order_Head.Intf_Id;
          Commit;
        End If;
      End Loop;
    End If;
    If p_Result = v_Success Then
      pkg_pln_order.p_Order_Operate(p_Order_Head_Id    => v_Order_Head_Id,
                                    p_Order_Type_Id    => r_Cust_Order_Head.Order_Type_Id,
                                    p_Operation_Action => '送审',
                                    p_User_Code        => 'admin',
                                    p_Result           => p_Result);
    End If;
    If p_Result <> v_Success Then
      Rollback;
      Update Intf_Cust_Order_Head Oh
         Set Oh.Intf_Status = '03', Oh.Intf_Err_Msg = p_Result
       Where Oh.Intf_Id = r_Cust_Order_Head.Intf_Id;
      Commit;
    Else
      Update Intf_Cust_Order_Head Oh
         Set Oh.Intf_Status  = '04',
             Oh.Intf_Err_Msg = Null,
             Oh.Pre_Field_01 = v_Order_Head_Id
       Where Oh.Intf_Id = r_Cust_Order_Head.Intf_Id;
    
      Update Intf_Cust_Order_Line Ol
         Set Ol.Intf_Status = '04', Ol.Intf_Err_Msg = Null
       Where Ol.Intf_Id = r_Cust_Order_Head.Intf_Id;
      Commit;
    End If;
  Exception
    When Others Then
      Rollback;
      p_Result := '失败：' || p_Result || v_Nl || Sqlerrm;
  End;
  
  ----------------------------------------------------------------------
  -- Author  : NICRO.LI
  -- Created : 2015-01-20 08:55:53
  -- Purpose : 更新产品产地信息
  ----------------------------------------------------------------------
  Procedure p_Create_Item_Producing(p_Intf_Id In Number, --接口ID
                                    p_Result  Out Varchar2) Is
  
    Cursor c_Pln_Item_Producing Is
      Select *
        From Intf_Pln_Item_Producing Ip
       Where Ip.Intf_Id = p_Intf_Id
         For Update Nowait;
    r_Pln_Item_Producing c_Pln_Item_Producing%Rowtype;
    v_Item_Id   Number;
    v_Item_Code   t_bd_item.item_code%Type;
    v_item_name   t_bd_item.item_name%Type;
    v_Update_Flag Boolean;
  Begin
    p_Result := v_Success;
    v_Update_Flag := False;
    Open c_Pln_Item_Producing;
    Fetch c_Pln_Item_Producing
      Into r_Pln_Item_Producing;     
    For r_Producing_Area In (Select *
                               From t_Pln_Producing_Area Pa
                              Where Pa.Mrp_Org_Id = r_Pln_Item_Producing.Organization_Id
                               --add by lizhen 2015-10-13增加主体字段
                               And Pa.Entity_Id = Nvl(r_Pln_Item_Producing.Entity_Id, 0)) Loop
      v_Update_Flag := True;
      Begin
        Select Bi.Item_Id, Bi.Item_Code, Bi.Item_Name
          Into v_Item_Id, v_Item_Code,v_Item_Name
          From t_Bd_Item Bi
         Where Bi.Item_Code = r_Pln_Item_Producing.Item_Code
           And Bi.Entity_Id = r_Producing_Area.Entity_Id;
      Exception
        When No_Data_Found Then
          Return;
        When Others Then
          p_Result := '检查产品失败，' || Sqlerrm;
          Raise v_Base_Exception;
      End;
      --更新产品产地优先级
      Update t_Pln_Item_Producing_Area Pa
         Set Pa.State            = r_Pln_Item_Producing.Saleunit_Stat,
             Pa.Remark           = 'PLM推送更新生命周期',
             Pa.Last_Updated_By  = 'GPLM',
             Pa.Last_Update_Date = Sysdate,
             Pa.Version          = Nvl(Pa.Version, 0) + 1
             --20171206 hejy3 更新成在销售状态时清空终止日期
             ,pa.end_date         = decode(r_Pln_Item_Producing.Saleunit_Stat,
                                           ITEM_LIFECYCLE_SALE,
                                           NULL,
                                           pa.end_date)
       Where Pa.Entity_Id = r_Producing_Area.Entity_Id
         And Pa.Producing_Area_Id = r_Producing_Area.Producing_Area_Id
         And Pa.Item_Id = v_Item_Id;
      If Sql%Notfound Then
        Begin
        Insert Into t_Pln_Item_Producing_Area
          (Entity_Id, --主体ID
           Item_Area_Id,
           Item_Id, --产品ID
           Item_Code, --产品编码
           Item_Name, --产品描述
           Producing_Area_Id, --产地ID
           Producing_Area_Code, --产地编码
           Producing_Area_Name, --产地名称
           Producing_Area_Priority, --优先级
           Begin_Date, --开始日期
           End_Date, --结束日期
           Description, --描述
           Created_By, --创建人
           Creation_Date, --创建日期
           Last_Updated_By, --最后更新人
           Last_Update_Date, --最后更新日期
           Remark, --备注
           Pre_Field_01,
           Pre_Field_02,
           Pre_Field_03,
           Pre_Field_04,
           Pre_Field_05,
           Pre_Field_06,
           Program_Updated_By,
           Program_Update_Date,
           Version,
           State)
        Values
          (r_Producing_Area.Entity_Id, --主体ID
           s_Pln_Item_Producing_Area.Nextval, --Item_Area_Id,  
           v_Item_Id, --Item_Id,    --产品ID
           v_Item_Code, --Item_Code,  --产品编码
           v_Item_Name, --Item_Name,   --产品描述
           r_Producing_Area.Producing_Area_Id, --Producing_Area_Id,  --产地ID
           r_Producing_Area.Producing_Area_Code, --Producing_Area_Code,  --产地编码
           r_Producing_Area.Producing_Area_Name, --Producing_Area_Name,  --产地名称
           Nvl((Select Max(Pa.Producing_Area_Priority) + 1
              From t_Pln_Item_Producing_Area Pa
             Where Pa.Entity_Id = r_Producing_Area.Entity_Id
                    And Pa.Item_Id = v_Item_Id),
                 1), --Producing_Area_Priority, --优先级
           Trunc(Sysdate - 1), --Begin_Date,  --开始日期
             Decode((Select 'Y'
                      From Up_Codelist c, Up_Codelist_Entity e
                     Where c.Id = e.Codelist_Id
                       And c.Codetype = 'PLN_ORDER_ITEM_INTF'
                       And e.Entity_Id = r_Producing_Area.Entity_Id
                       And Rownum = 1),
                    'Y',
                    Trunc(Sysdate - 1),
                    Null), --End_Date, --结束日期 modi by lizhen 2015-09-01 默认为终止用户手工维护生效
           Null, --Description,  --描述
           'GPLM', --Created_By,   --创建人
           Sysdate, --Creation_Date,  --创建日期
           'GPLM', --Last_Updated_By,  --最后更新人
           Sysdate, --Last_Update_Date,  --最后更新日期
           'PLM推送数据', --Remark,            --备注
           Null, --Pre_Field_01,
           Null, --Pre_Field_02,
           Null, --Pre_Field_03,
           Null, --Pre_Field_04,
           Null, --Pre_Field_05,
           Null, --Pre_Field_06,
           'p_Create_Item_Producing', --Program_Updated_By,
           Sysdate, --Program_Update_Date,
           1, --Version,
           r_Pln_Item_Producing.Saleunit_Stat --State
           );
        Exception
          When Others Then
            p_Result := '插入产品产地优先级表失败，' || Sqlerrm;
            Raise v_Base_Exception;
        End;
      End If;
      
      --更新接口表
      UPDATE INTF_BD_PRICE_LINE L
         SET L.INTF_STATUS = 'N'
       WHERE L.ENTITY_ID = r_Pln_Item_Producing.Entity_Id
         AND L.ITEM_CODE = r_Pln_Item_Producing.Item_Code
         AND L.INTF_STATUS IS NULL
         --存在询价单
         AND EXISTS (SELECT 1 FROM T_PG_QUERY_PRICE P
                      WHERE P.ENTITY_ID = L.ENTITY_ID
                        AND P.ITEM_CODE = L.ITEM_CODE);
    End Loop;
    Close c_Pln_Item_Producing;
    If v_Update_Flag Then
      Update Intf_Pln_Item_Producing Ip
         Set Ip.Intf_State = 'U', Ip.Last_Update_Date = Sysdate
       Where Ip.Intf_Id = p_Intf_Id
         And Ip.Intf_State = 'I';
    End If;
    Commit;
  Exception
    When v_Base_Exception Then
      Rollback;
      Update Intf_Pln_Item_Producing Ip
         Set Ip.Intf_State       = 'E',
             Ip.Last_Update_Date = Sysdate,
             Ip.Intf_Err_Msg     = p_Result
       Where Ip.Intf_Id = p_Intf_Id
         And Ip.Intf_State = 'I';
      Commit;
    When Others Then
      Rollback;
      p_Result := p_Result || '     ' || Sqlerrm;
      Update Intf_Pln_Item_Producing Ip
         Set Ip.Intf_State       = 'E',
             Ip.Last_Update_Date = Sysdate, 
             Ip.Intf_Err_Msg     = p_Result
       Where Ip.Intf_Id = p_Intf_Id
         And Ip.Intf_State = 'I';
      Commit;
  End;
  
  ----------------------------------------------------------------------
  -- Author  : NICRO.LI
  -- Created : 2015-01-20 08:55:53
  -- Purpose : JOB更新产品产地信息
  ----------------------------------------------------------------------
  Procedure p_Create_Item_Producing_Job Is
    v_Value Varchar2(2000);
    v_Pln_Item_Life_Cycle_Flag  Varchar2(100);
    v_Entity_Id                 Number;
  Begin
    For r_Item_Producing In (Select *
                               From Intf_Pln_Item_Producing Ip
                              Where Ip.Intf_State = 'I'
                              Order By Ip.Intf_Id) Loop
      Begin
        Select Count(1)
          Into v_Entity_Id
          From t_Inv_Organization o
         Where o.Organization_Id = r_Item_Producing.Organization_Id;
      Exception
        When Others Then
          v_Entity_Id := Null;
      End;
      If v_Entity_Id Is Not Null Then                      
        p_Create_Item_Producing(r_Item_Producing.Intf_Id, v_Value);
      End If;
    End Loop;
  Exception
    When Others Then
      Null;
  End;

  ----------------------------------------------------------------------
  -- Author  : NICRO.LI
  -- Created : 2014-07-29 08:55:53
  -- Purpose : 工单与订单匹配关系接口数据写入正式表
  ----------------------------------------------------------------------
  Procedure p_Create_Wip_Order_Relation(p_Entity_Id       In Number, --主体ID
                                        p_Organization_Id In Number, --组织ID
                                        p_User_Code       In Varchar2,
                                        p_Result          Out Varchar2) Is
    Cursor c_Wip_Order_Intf Is
      Select *
        From Intf_Pln_Wip_Order_Relation Wor
       Where Wor.Intf_Status = 'I'
         And Wor.Organization_Id = p_Organization_Id;

    r_Wip_Order_Intf c_Wip_Order_Intf%Rowtype;
    v_Item_Id        Number;
    v_Item_Name      Varchar2(240);
    v_Order_Line_Id  Number;
    v_Order_Head_Id  Number;
  Begin
    p_Result := v_Success;
    Open c_Wip_Order_Intf;
    Loop
      Fetch c_Wip_Order_Intf
        Into r_Wip_Order_Intf;
      Exit When c_Wip_Order_Intf%Notfound Or p_Result <> v_Success;
      Begin
        --获取产品ID
        Select Bi.Item_Id, Bi.Item_Name
          Into v_Item_Id, v_Item_Name
          From t_Bd_Item Bi
         Where Bi.Entity_Id = p_Entity_Id
           And Bi.Item_Code = r_Wip_Order_Intf.Item_Code;
      Exception
        When Others Then
          p_Result := '获取产品ID失败，产品编码：' || r_Wip_Order_Intf.Item_Code || v_Nl ||
                      Sqlerrm;
          Rollback;
          Update Intf_Pln_Wip_Order_Relation r
             Set r.Intf_Status      = 'E',
                 r.Intf_Err_Msg     = p_Result,
                 r.Last_Updated_By  = p_User_Code,
                 r.Last_Update_Date = Sysdate
           Where r.Intf_Id = r_Wip_Order_Intf.Intf_Id;
          Return;
      End;
      Begin
        --订单行ID,订单头ID，检查订单是否存在
        Select Oh.Order_Head_Id, Ol.Order_Line_Id
          Into v_Order_Head_Id, v_Order_Line_Id
          From t_Pln_Order_Head   Oh,
               t_Pln_Order_Line   Ol,
               t_Pln_Order_Detail Od
         Where Oh.Entity_Id = p_Entity_Id
           And Oh.Order_Head_Id = Ol.Order_Head_Id
           And Ol.Order_Line_Id = Od.Order_Line_Id
           And Od.Order_Detail_Id = r_Wip_Order_Intf.Order_Detail_Id;
      Exception
        When Others Then
          p_Result := '获取订单信息失败，订单明细行ID：' ||
                      To_Char(r_Wip_Order_Intf.Order_Detail_Id) || v_Nl ||
                      Sqlerrm;
          Rollback;
          Update Intf_Pln_Wip_Order_Relation r
             Set r.Intf_Status      = 'E',
                 r.Intf_Err_Msg     = p_Result,
                 r.Last_Updated_By  = p_User_Code,
                 r.Last_Update_Date = Sysdate
           Where r.Intf_Id = r_Wip_Order_Intf.Intf_Id;
          Return;
      End;
      Begin
        --先更新工单与订单关系表信息
        Update t_Pln_Wip_Order_Relation Wor
           Set Wor.Date_Released    = r_Wip_Order_Intf.Date_Released,
               Wor.Date_Closed      = r_Wip_Order_Intf.Date_Closed,
               Wor.Wip_Done_Qty     = r_Wip_Order_Intf.Wip_Done_Qty,
               Wor.Last_Updated_By  = p_User_Code,
               Wor.Last_Update_Date = Sysdate
         Where Wor.Organization_Id = r_Wip_Order_Intf.Organization_Id
           And Wor.Wip_Entity_Id = r_Wip_Order_Intf.Wip_Entity_Id
           And Wor.Order_Detail_Id = r_Wip_Order_Intf.Order_Detail_Id;
        If Sql%Notfound Then
          Insert Into t_Pln_Wip_Order_Relation
            (Wip_Order_Id,
             Entity_Id,
             Organization_Id,
             Wip_Entity_Id,
             Wip_Entity_Code,
             Wip_Entity_Desc,
             Item_Id,
             Item_Code,
             Item_Name,
             Wip_Schedule_Qty,
             Pln_Request_Qty,
             In_Inv_Qty,
             Wait_Execute_Qty,
             Order_Detail_Id,
             Order_Line_Id,
             Order_Head_Id,
             Wip_Request_Qty,
             Wip_Done_Qty,
             Scheduled_Start_Date,
             Scheduled_Completed_Date,
             Date_Released,
             Date_Closed,
             Source_Type,
             Created_By,
             Creation_Date,
             Last_Updated_By,
             Last_Update_Date,
             Reamrk,
             Pre_Field_01,
             Pre_Field_02,
             Pre_Field_03,
             Pre_Field_04,
             Pre_Field_05,
             Pre_Field_06)
          Values
            (s_Pln_Wip_Order_Relation.Nextval,
             p_Entity_Id,
             r_Wip_Order_Intf.Organization_Id, -- ORGANIZATION_ID,
             r_Wip_Order_Intf.Wip_Entity_Id, --WIP_ENTITY_ID,
             r_Wip_Order_Intf.Wip_Entity_Code, --WIP_ENTITY_CODE,
             r_Wip_Order_Intf.Wip_Entity_Desc, --WIP_ENTITY_DESC,
             v_Item_Id, --ITEM_ID,
             r_Wip_Order_Intf.Item_Code, --ITEM_CODE,
             v_Item_Name, --ITEM_NAME,
             r_Wip_Order_Intf.Wip_Schedule_Qty, --WIP_SCHEDULE_QTY,
             r_Wip_Order_Intf.Pln_Request_Qty, --PLN_REQUEST_QTY,
             0, --IN_INV_QTY,
             0, --WAIT_EXECUTE_QTY,
             r_Wip_Order_Intf.Order_Detail_Id, --ORDER_DETAIL_ID,
             v_Order_Line_Id, --ORDER_LINE_ID,
             v_Order_Head_Id, --ORDER_HEAD_ID,
             r_Wip_Order_Intf.Wip_Request_Qty, --WIP_REQUEST_QTY,
             r_Wip_Order_Intf.Wip_Done_Qty, --WIP_DONE_QTY,
             to_date(r_Wip_Order_Intf.Scheduled_Start_Date, 'yyyy-mm-dd hh24:mi:ss'), --SCHEDULED_START_DATE,
             to_date(r_Wip_Order_Intf.Scheduled_Completed_Date, 'yyyy-mm-dd hh24:mi:ss'), --SCHEDULED_COMPLETED_DATE,
             to_date(r_Wip_Order_Intf.Date_Released, 'yyyy-mm-dd hh24:mi:ss'), --DATE_RELEASED,
             to_date(r_Wip_Order_Intf.Date_Closed, 'yyyy-mm-dd hh24:mi:ss'), --DATE_CLOSED,
             r_Wip_Order_Intf.Source_Type, --SOURCE_TYPE,
             p_User_Code, --CREATED_BY,
             Sysdate, --CREATION_DATE,
             p_User_Code, --LAST_UPDATED_BY,
             Sysdate, --LAST_UPDATE_DATE,
             r_Wip_Order_Intf.Reamrk,
             r_Wip_Order_Intf.Pre_Field_01,
             r_Wip_Order_Intf.Pre_Field_02,
             r_Wip_Order_Intf.Pre_Field_03,
             r_Wip_Order_Intf.Pre_Field_04,
             r_Wip_Order_Intf.Pre_Field_05,
             r_Wip_Order_Intf.Pre_Field_06);
        End If;
      Exception
        When Others Then
          p_Result := '插入工单与订单关系表失败。' || v_Nl || '失败信息：' || Sqlerrm;
          Rollback;
          Update Intf_Pln_Wip_Order_Relation r
             Set r.Intf_Status      = 'E',
                 r.Intf_Err_Msg     = p_Result,
                 r.Last_Updated_By  = p_User_Code,
                 r.Last_Update_Date = Sysdate
           Where r.Intf_Id = r_Wip_Order_Intf.Intf_Id;
          Return;
      End;

      --更新接口状态
      Update Intf_Pln_Wip_Order_Relation r
         Set r.Intf_Status      = 'U',
             r.Intf_Err_Msg     = '插入数据成功',
             r.Last_Updated_By  = p_User_Code,
             r.Last_Update_Date = Sysdate
       Where r.Intf_Id = r_Wip_Order_Intf.Intf_Id;
    End Loop;
  Exception
    When Others Then
      Rollback;
  End;

  ----------------------------------------------------------------------
  -- Author  : fenggq
  -- Created : 2014-08-28 17:55:00
  -- Purpose : 月计划业务表写入接口表
  ----------------------------------------------------------------------
  PROCEDURE P_CREATE_INTF_DOMESTIC_FORCAST(P_HEAD_ID   IN NUMBER, --月计划表头
                                           P_USER_CODE IN VARCHAR2, --登录用户名
                                           P_RESULT    OUT VARCHAR2) IS

    VN_ENTITY_ID         INTF_STP_DOMESTIC_FORCAST.ENTITY_ID%TYPE;
    VS_SALES_CENTER_CODE INTF_STP_DOMESTIC_FORCAST.SALES_CENTER_CODE%TYPE;
    VD_DEMAND_DATE       INTF_STP_DOMESTIC_FORCAST.DEMAND_DATE%TYPE;
    VS_ENTITY_CODE       VARCHAR2(100);
    VN_COUNT             NUMBER;
    V_IS_MORE            T_PLN_ORDER_TYPE.IS_MORE%TYPE; --是否增补预测
    V_ORDER_TYPE_CODE    T_PLN_ORDER_TYPE.ORDER_TYPE_CODE%TYPE;
    --add by huanghb12
    VS_ITEM_LIFE_CYCLE   VARCHAR2(10);
    VS_CHECK_RESULT      VARCHAR2(4000);
    VS_Producing_Area_Id NUMBER;
    R_LINES              T_STP_MONTH_PLAN_LINES%ROWTYPE;
    v_is_producing_area  varchar2(32);
    
    CURSOR C_LINES IS
      SELECT LINES.*
        FROM T_STP_MONTH_PLAN_LINES LINES
       WHERE LINES.MONTH_PLAN_HEAD_ID = P_HEAD_ID;
    --huanghb12
  BEGIN
    P_RESULT := V_SUCCESS;

    SELECT HEAD.ENTITY_ID, HEAD.SALES_CENTER_CODE, T.IS_MORE, T.ORDER_TYPE_CODE
      INTO VN_ENTITY_ID, VS_SALES_CENTER_CODE, V_IS_MORE, V_ORDER_TYPE_CODE
      FROM T_STP_MONTH_PLAN_HEAD HEAD, T_PLN_ORDER_TYPE T
     WHERE HEAD.MONTH_PLAN_HEAD_ID = P_HEAD_ID
       AND HEAD.PLAN_TYPE = TO_CHAR(T.ORDER_TYPE_ID);

   SELECT PERIOD.END_DATE
      INTO VD_DEMAND_DATE
      FROM T_STP_MONTH_PLAN_HEAD HEAD, T_PLN_ORDER_PERIOD PERIOD
     WHERE HEAD.MONTH_PLAN_HEAD_ID = P_HEAD_ID
       AND HEAD.PLAN_PERIOD = PERIOD.PERIOD_ID;
     -- add by ccz 2015-09-24
     begin
       select ue.entity_code_name--, ve.entity_id
         into VS_ENTITY_CODE--, Vn_Entity_Id
         from up_codelist up, up_codelist_entity ue, v_bd_entity ve
        where up.codetype = 'PlnEntityToMainEntity'
          and up.id = ue.codelist_id
          and ue.entity_id = Vn_Entity_Id
          and ve.entity_code = ue.entity_code_name;
     exception
       when no_data_found then
         begin
           Select Entity.Entity_Code--, entity.entity_id
             Into VS_ENTITY_CODE--, Vn_Entity_Id
             From v_Bd_Entity Entity
            Where Entity.Entity_Id = VN_ENTITY_ID;
         exception
           when others then
             p_Result := '获取主体失败' || sqlerrm;
             raise v_Base_Exception;
         end;
       when others then
         p_Result := '获取主体失败,主体快码PlnEntityToMainEntity' || sqlerrm;
         raise v_Base_Exception;
     end;
     --获取行产地是否为空参数 lilh6 2019-7-9
      BEGIN
        v_is_producing_area := PKG_BD.F_GET_PARAMETER_VALUE('PLN_STP_MONTH_PRODUCE',
                                                           VN_ENTITY_ID);
      EXCEPTION
        WHEN OTHERS THEN
          P_RESULT := '获取PLN_STP_MONTH_PRODUCE参数失败。' || V_NL || SQLERRM;
          RAISE V_BASE_EXCEPTION;
      END;
      --add by huanghb12  校验产品生命周期
      BEGIN
        VS_ITEM_LIFE_CYCLE := PKG_BD.F_GET_PARAMETER_VALUE('PLN_ITEM_LIFE_CYCLE', VN_ENTITY_ID);
      EXCEPTION
        WHEN OTHERS THEN
          P_RESULT := '获取PLN_ITEM_LIFE_CYCLE参数失败。' || V_NL || SQLERRM;
          RAISE V_BASE_EXCEPTION;
      END;

      --是否校验产品生命周期
      IF VS_ITEM_LIFE_CYCLE != 'N' And v_is_producing_area = 'Y'THEN
       --使用游标保存多行，根据id查询未处理的核销行信息
        open C_LINES;
          loop
            fetch C_LINES into R_LINES;
            exit when C_LINES%notfound or p_Result <> v_Success;
            
            
              begin
                Select Pa.Producing_Area_Id
                  into VS_Producing_Area_Id
                  From t_Pln_Producing_Area Pa
                 WHERE PA.Producing_Area_Code = R_LINES.Producing_Area_Code
                 AND   PA.ENTITY_ID = R_LINES.ENTITY_ID;
                --调用函数，校验产品的生命周期
                VS_CHECK_RESULT := NULL;
                VS_CHECK_RESULT := PKG_PLN_PUB.P_CHK_ITEM_PRDC_LIFE_CYCLE( R_LINES.ENTITY_ID, 
                                                                           R_LINES.ITEM_ID,
                                                                           VS_Producing_Area_Id, 
                                                                           --检查是否允许引入APS
                                                                           PKG_PLN_PUB.v_Phase_Intf_Aps,
                                                                           --增加一个参数：月预测计划订单类型
                                                                           'MONTH_PLAN');
                IF VS_CHECK_RESULT != 'Y' THEN
                  --如果检测不通过则，抛出异常
                  RAISE V_BASE_EXCEPTION;
                END IF;   
              EXCEPTION
              WHEN OTHERS THEN
                 P_RESULT := VS_CHECK_RESULT||'，按生命周期控制，不允许报送！'|| SQLERRM;
                 RAISE V_BASE_EXCEPTION;
              end;
           
          end loop;  
      END IF;
    --end huanghb12
    
    IF V_IS_MORE = 'Y' THEN --月增补预测引接口
      Insert Into Intf_Pln_Month_Plan
        (Month_Plan_Id,
         Entity_Id,
         Demand_Date,
         Sales_Center_Code,
         Item_Code,
         Check_Qty,
         Amount,
         Mrp_Org_Code,
         Order_Type,
         Productform_Code,
         Productform_Name,
         Entity_Code,
         Send_Status,
         Created_By,
         Creation_Date,
         Last_Updated_By,
         Last_Update_Date,
         Intf_Status,
         Customer_Code,
         Pre_Field_01,
         Pre_Field_02,
         Pre_Field_03)
        SELECT s_Intf_Pln_Month_Plan.Nextval,
               VN_ENTITY_ID,
               VD_DEMAND_DATE,
               VS_SALES_CENTER_CODE,
               LINES.ITEM_CODE,
               LINES.MONTH_PLAN_QTY,
               0,
               Nvl((Select Io.Organization_Code
                      From t_Inv_Producting_Item Ipi,
                           t_Pln_Producing_Area  Ppa,
                           t_Inv_Organization    Io
                     Where Ppa.Producing_Area_Id = Ipi.Po_Area_Id
                       And Ppa.Entity_Id = Io.Entity_Id
                       And Ppa.Mrp_Org_Id = Io.Organization_Id
                       And ipi.item_code = Item.Item_Code
                       And ipi.entity_id = lines.entity_id
                       And ipi.po_area_id =PRODUCINGAREA.producing_area_id),
                    Producingarea.Mrp_Org_Code),
               '月增补预测',--V_ORDER_TYPE_CODE,
               ITEM.PRODUCTFORM,
               CODELIST.CODE_NAME,
               VS_ENTITY_CODE,
               '300', --月增补预测
               P_USER_CODE,
               SYSDATE,
               P_USER_CODE,
               SYSDATE,
               'N',
               VS_SALES_CENTER_CODE,
               to_char(P_HEAD_ID),
               to_char(lines.month_plan_line_id),
               LINES.Pre_Field_03  --增加产品是否为全新品属性   jiangwei29 2019-6-28
          FROM T_STP_MONTH_PLAN_LINES LINES,
               T_PLN_PRODUCING_AREA   PRODUCINGAREA,
               T_BD_ITEM              ITEM,
               V_UP_CODELIST          CODELIST
         WHERE LINES.MONTH_PLAN_HEAD_ID = P_HEAD_ID
           AND LINES.PRODUCING_AREA_CODE = PRODUCINGAREA.PRODUCING_AREA_CODE(+)
           and PRODUCINGAREA.ENTITY_ID(+)=Lines.Entity_Id
           and Lines.Entity_Id=item.entity_id
           AND LINES.ITEM_CODE = ITEM.ITEM_CODE
           AND ITEM.PRODUCTFORM = CODELIST.CODE_VALUE
           AND CODELIST.CODETYPE = 'GE_MPL_PRODUCT_FORM';
    ELSE
     
      INSERT INTO INTF_STP_DOMESTIC_FORCAST
        (DOMESTIC_FORCAST_ID,
         ENTITY_ID,
         DEMAND_DATE,
         SALES_CENTER_CODE,
         ITEM_CODE,
         MONTH_PLAN_QTY,
         MRP_ORG_CODE,
         PRODUCTFORM_CODE,
         PRODUCTFORM_NAME,
         ENTITY_CODE,
         CREATED_BY,
         CREATION_DATE,
         LAST_UPDATED_BY,
         LAST_UPDATE_DATE,
         INTF_STATUS,
         PRE_FIELD_01,
         PRE_FIELD_02,
         Pre_Field_03)
        SELECT S_INTF_STP_DOMESTIC_FORCAST.NEXTVAL,
               VN_ENTITY_ID,
               VD_DEMAND_DATE,
               VS_SALES_CENTER_CODE,
               LINES.ITEM_CODE,
               LINES.MONTH_PLAN_QTY,
               -- Producingarea.Mrp_Org_Code,
              --add by 2015-09-25
               Nvl((Select Io.Organization_Code
              From t_Inv_Producting_Item Ipi,
                   t_Pln_Producing_Area  Ppa,
                   t_Inv_Organization    Io
             Where Ppa.Producing_Area_Id = Ipi.Po_Area_Id
               And Ppa.Entity_Id = Io.Entity_Id
               And Ppa.Mrp_Org_Id = Io.Organization_Id
               And ipi.item_code = Item.Item_Code --itemCode
               And ipi.entity_id =lines.entity_id --entityId
               And ipi.po_area_id =PRODUCINGAREA.producing_area_id ),Producingarea.Mrp_Org_Code),
               ITEM.PRODUCTFORM,
               CODELIST.CODE_NAME,
               VS_ENTITY_CODE,
               P_USER_CODE,
               SYSDATE,
               P_USER_CODE,
               SYSDATE,
               'N',
               to_char(LINES.MONTH_PLAN_HEAD_ID),
               to_char(LINES.Month_Plan_Line_Id),
               LINES.Pre_Field_03  --增加产品是否为全新品属性   jiangwei29 2019-6-28
          FROM T_STP_MONTH_PLAN_LINES LINES,
               T_PLN_PRODUCING_AREA   PRODUCINGAREA,
               T_BD_ITEM              ITEM,
               V_UP_CODELIST          CODELIST
         WHERE LINES.MONTH_PLAN_HEAD_ID = P_HEAD_ID
           AND LINES.PRODUCING_AREA_CODE = PRODUCINGAREA.PRODUCING_AREA_CODE(+)
           and PRODUCINGAREA.ENTITY_ID(+)=Lines.Entity_Id  --add by zhangcc 2015-10-26
           and Lines.Entity_Id=item.entity_id --add by zhangcc 2015-10-26
           AND LINES.ITEM_CODE = ITEM.ITEM_CODE
           AND ITEM.PRODUCTFORM = CODELIST.CODE_VALUE
          -- AND CODELIST.ENTITY_ID = VN_ENTITY_ID
           AND CODELIST.CODETYPE = 'GE_MPL_PRODUCT_FORM';

      SELECT COUNT(*)
        INTO VN_COUNT
        FROM T_STP_MONTH_PLAN_LINES LINES,
             T_PLN_PRODUCING_AREA   PRODUCINGAREA,
             T_BD_ITEM              ITEM,
             V_UP_CODELIST          CODELIST
       WHERE LINES.MONTH_PLAN_HEAD_ID = P_HEAD_ID
         AND LINES.PRODUCING_AREA_CODE = PRODUCINGAREA.PRODUCING_AREA_CODE(+)
         AND LINES.ITEM_CODE = ITEM.ITEM_CODE
         and PRODUCINGAREA.ENTITY_ID(+)=Lines.Entity_Id  --add by zhangcc 2015-10-26
         and Lines.Entity_Id=item.entity_id  --add by zhangcc 2015-10-26
         AND ITEM.PRODUCTFORM = CODELIST.CODE_VALUE
        -- AND CODELIST.ENTITY_ID = VN_ENTITY_ID
         AND CODELIST.CODETYPE = 'GE_MPL_PRODUCT_FORM';

      IF VN_COUNT <= 0 THEN
        P_RESULT := '生成接口表失败。';
        Rollback;
      /*Else
        Commit;*/
      END IF;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      P_RESULT := '插入机型预测接口表失败。' || V_NL || '失败信息：'|| P_RESULT  || V_NL ||'系统提示：'|| SQLERRM;
      ROLLBACK;
  END;
 ----------------------------------------------------------------------
  -- Author  : fenggq
  -- Created : 2014-08-28 17:55:00
  -- Purpose : 月计划业务表写入接口表
  ----------------------------------------------------------------------
  PROCEDURE P_CREATE_INTF_DOMESTIC_FOR_NEW(P_HEAD_ID   IN NUMBER, --月计划表头
                                           P_USER_CODE IN VARCHAR2, --登录用户名
                                           P_RESULT    OUT VARCHAR2) IS
  
    VN_ENTITY_ID         INTF_STP_DOMESTIC_FORCAST.ENTITY_ID%TYPE;
    VS_SALES_CENTER_CODE INTF_STP_DOMESTIC_FORCAST.SALES_CENTER_CODE%TYPE;
    VD_DEMAND_DATE       INTF_STP_DOMESTIC_FORCAST.DEMAND_DATE%TYPE;
    VS_ENTITY_CODE       VARCHAR2(100);
    VN_COUNT             NUMBER;
    V_IS_MORE            T_PLN_ORDER_TYPE.IS_MORE%TYPE; --是否增补预测
    V_ORDER_TYPE_CODE    T_PLN_ORDER_TYPE.ORDER_TYPE_CODE%TYPE;
    --add by huanghb12
    VS_ITEM_LIFE_CYCLE   VARCHAR2(10);
    VS_CHECK_RESULT      VARCHAR2(4000);
    VS_PRODUCING_AREA_ID NUMBER;
    R_LINES              T_STP_MONTH_PLAN_LINES%ROWTYPE;
    v_is_producing_area  varchar2(32);
  
    CURSOR C_LINES IS
      SELECT LINES.*
        FROM T_STP_MONTH_PLAN_LINES LINES
       WHERE LINES.MONTH_PLAN_HEAD_ID = P_HEAD_ID;
  BEGIN
    P_RESULT := V_SUCCESS;
  
    SELECT HEAD.ENTITY_ID,
           HEAD.SALES_CENTER_CODE,
           T.IS_MORE,
           T.ORDER_TYPE_CODE
      INTO VN_ENTITY_ID, VS_SALES_CENTER_CODE, V_IS_MORE, V_ORDER_TYPE_CODE
      FROM T_STP_MONTH_PLAN_HEAD HEAD, T_PLN_ORDER_TYPE T
     WHERE HEAD.MONTH_PLAN_HEAD_ID = P_HEAD_ID
       AND HEAD.PLAN_TYPE = TO_CHAR(T.ORDER_TYPE_ID);
  
    SELECT PERIOD.END_DATE
      INTO VD_DEMAND_DATE
      FROM T_STP_MONTH_PLAN_HEAD HEAD, T_PLN_ORDER_PERIOD PERIOD
     WHERE HEAD.MONTH_PLAN_HEAD_ID = P_HEAD_ID
       AND HEAD.PLAN_PERIOD = PERIOD.PERIOD_ID;

    BEGIN
      SELECT UE.ENTITY_CODE_NAME 
        INTO VS_ENTITY_CODE 
        FROM UP_CODELIST UP, UP_CODELIST_ENTITY UE, V_BD_ENTITY VE
       WHERE UP.CODETYPE = 'PlnEntityToMainEntity'
         AND UP.ID = UE.CODELIST_ID
         AND UE.ENTITY_ID = VN_ENTITY_ID
         AND VE.ENTITY_CODE = UE.ENTITY_CODE_NAME;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        BEGIN
          SELECT ENTITY.ENTITY_CODE
            INTO VS_ENTITY_CODE
            FROM V_BD_ENTITY ENTITY
           WHERE ENTITY.ENTITY_ID = VN_ENTITY_ID;
        EXCEPTION
          WHEN OTHERS THEN
            P_RESULT := '获取主体失败' || SQLERRM;
            RAISE V_BASE_EXCEPTION;
        END;
      WHEN OTHERS THEN
        P_RESULT := '获取主体失败,主体快码PlnEntityToMainEntity' || SQLERRM;
        RAISE V_BASE_EXCEPTION;
    END;
    --获取行产地是否为空参数 lilh6 2019-7-9
    BEGIN
      v_is_producing_area := PKG_BD.F_GET_PARAMETER_VALUE('PLN_STP_MONTH_PRODUCE',
                                                         VN_ENTITY_ID);
    EXCEPTION
      WHEN OTHERS THEN
        P_RESULT := '获取PLN_STP_MONTH_PRODUCE参数失败。' || V_NL || SQLERRM;
        RAISE V_BASE_EXCEPTION;
    END;
    --add by huanghb12  校验产品生命周期
    BEGIN
      VS_ITEM_LIFE_CYCLE := PKG_BD.F_GET_PARAMETER_VALUE('PLN_ITEM_LIFE_CYCLE',
                                                         VN_ENTITY_ID);
    EXCEPTION
      WHEN OTHERS THEN
        P_RESULT := '获取PLN_ITEM_LIFE_CYCLE参数失败。' || V_NL || SQLERRM;
        RAISE V_BASE_EXCEPTION;
    END; 
    --是否校验产品生命周期
    IF VS_ITEM_LIFE_CYCLE != 'N' And v_is_producing_area = 'Y' THEN
      --使用游标保存多行，根据id查询未处理的核销行信息
      OPEN C_LINES;
      LOOP
        FETCH C_LINES
          INTO R_LINES;
        EXIT WHEN C_LINES%NOTFOUND OR P_RESULT <> V_SUCCESS;
      
        BEGIN
          SELECT PA.PRODUCING_AREA_ID
            INTO VS_PRODUCING_AREA_ID
            FROM T_PLN_PRODUCING_AREA PA
           WHERE PA.PRODUCING_AREA_CODE = R_LINES.PRODUCING_AREA_CODE
             AND PA.ENTITY_ID = R_LINES.ENTITY_ID;
          --调用函数，校验产品的生命周期
          VS_CHECK_RESULT := NULL;
          VS_CHECK_RESULT := PKG_PLN_PUB.P_CHK_ITEM_PRDC_LIFE_CYCLE(R_LINES.ENTITY_ID,
                                                                    R_LINES.ITEM_ID,
                                                                    VS_PRODUCING_AREA_ID,
                                                                    --检查是否允许引入APS
                                                                    PKG_PLN_PUB.V_PHASE_INTF_APS,
                                                                    --增加一个参数：月预测计划订单类型
                                                                    'MONTH_PLAN');
          IF VS_CHECK_RESULT != 'Y' THEN
            --如果检测不通过则，抛出异常
            RAISE V_BASE_EXCEPTION;
          END IF;
        EXCEPTION
          WHEN OTHERS THEN
            P_RESULT := VS_CHECK_RESULT || '，按生命周期控制，不允许报送！' || SQLERRM;
            RAISE V_BASE_EXCEPTION;
        END;
      
      END LOOP;
    END IF;
    --end huanghb12  
    IF V_IS_MORE = 'Y' THEN
      --月增补预测引接口
      INSERT INTO INTF_PLN_MONTH_PLAN
        (MONTH_PLAN_ID,
         ENTITY_ID,
         DEMAND_DATE,
         SALES_CENTER_CODE,
         ITEM_CODE,
         CHECK_QTY,
         AMOUNT,
         MRP_ORG_CODE,
         ORDER_TYPE,
         PRODUCTFORM_CODE,
         PRODUCTFORM_NAME,
         ENTITY_CODE,
         SEND_STATUS,
         CREATED_BY,
         CREATION_DATE,
         LAST_UPDATED_BY,
         LAST_UPDATE_DATE,
         INTF_STATUS,
         CUSTOMER_CODE,
         PRE_FIELD_01,
         PRE_FIELD_02,
		 PRE_FIELD_03)
        SELECT S_INTF_PLN_MONTH_PLAN.NEXTVAL,
               VN_ENTITY_ID,
               VD_DEMAND_DATE,
               VS_SALES_CENTER_CODE,
               LINES.ITEM_CODE,
               LINES.MONTH_PLAN_QTY,
               0,
               NVL((SELECT IO.ORGANIZATION_CODE
                     FROM T_INV_PRODUCTING_ITEM IPI,
                          T_PLN_PRODUCING_AREA  PPA,
                          T_INV_ORGANIZATION    IO
                    WHERE PPA.PRODUCING_AREA_ID = IPI.PO_AREA_ID
                      AND PPA.ENTITY_ID = IO.ENTITY_ID
                      AND PPA.MRP_ORG_ID = IO.ORGANIZATION_ID
                      AND IPI.ITEM_CODE = ITEM.ITEM_CODE
                      AND IPI.ENTITY_ID = LINES.ENTITY_ID
                      AND IPI.PO_AREA_ID = PRODUCINGAREA.PRODUCING_AREA_ID),
                   PRODUCINGAREA.MRP_ORG_CODE),
               '月增补预测', --V_ORDER_TYPE_CODE,
               ITEM.PRODUCTFORM,
               CODELIST.CODE_NAME,
               VS_ENTITY_CODE,
               '300', --月增补预测
               P_USER_CODE,
               SYSDATE,
               P_USER_CODE,
               SYSDATE,
               'N',
               VS_SALES_CENTER_CODE,
               TO_CHAR(P_HEAD_ID),
               TO_CHAR(LINES.MONTH_PLAN_LINE_ID),
			   LINES.Pre_Field_03  --增加产品是否为全新品属性   jiangwei29 2019-6-28
          FROM T_STP_MONTH_PLAN_LINES LINES,
               T_PLN_PRODUCING_AREA   PRODUCINGAREA,
               T_BD_ITEM              ITEM,
               V_UP_CODELIST          CODELIST
         WHERE LINES.MONTH_PLAN_HEAD_ID = P_HEAD_ID
           AND LINES.PRODUCING_AREA_CODE =
               PRODUCINGAREA.PRODUCING_AREA_CODE(+)
           AND PRODUCINGAREA.ENTITY_ID(+) = LINES.ENTITY_ID
           AND LINES.ENTITY_ID = ITEM.ENTITY_ID
           AND LINES.ITEM_CODE = ITEM.ITEM_CODE
           AND ITEM.PRODUCTFORM = CODELIST.CODE_VALUE
           AND CODELIST.CODETYPE = 'GE_MPL_PRODUCT_FORM';
    ELSE   
      INSERT INTO INTF_STP_DOMESTIC_FORCAST
        (DOMESTIC_FORCAST_ID,
         ENTITY_ID,
         DEMAND_DATE,
         SALES_CENTER_CODE,
         ITEM_CODE, --这里放老品的编码
         MONTH_PLAN_QTY,
         MRP_ORG_CODE,
         PRODUCTFORM_CODE,
         PRODUCTFORM_NAME,
         ENTITY_CODE,
         CREATED_BY,
         CREATION_DATE,
         LAST_UPDATED_BY,
         LAST_UPDATE_DATE,
         INTF_STATUS,
         PRE_FIELD_01,
         PRE_FIELD_02,
		 PRE_FIELD_03,
         SALES_MAIN_TYPE,
         SALES_SUB_TYPE,
         M2_MONTH_PLAN_QTY,
         M3_MONTH_PLAN_QTY,
         NEW_ITEM_CODE,
         NEW_ITEM_NAME,
         CURRENT_STOCK,
         PRICE,
         UNDELIVERED_QTY,
         UNSATISFIED_QTY,
         MONTHLY_AVERAGE_SALES)
        SELECT S_INTF_STP_DOMESTIC_FORCAST.NEXTVAL,
               VN_ENTITY_ID,
               VD_DEMAND_DATE,
               VS_SALES_CENTER_CODE,
               NVL(ITEM.SOURCE_ITEM_CODE, ITEM.ITEM_CODE), --存放老品编码
               LINES.MONTH_PLAN_QTY,
               NVL((SELECT IO.ORGANIZATION_CODE
                     FROM T_INV_PRODUCTING_ITEM IPI,
                          T_PLN_PRODUCING_AREA  PPA,
                          T_INV_ORGANIZATION    IO
                    WHERE PPA.PRODUCING_AREA_ID = IPI.PO_AREA_ID
                      AND PPA.ENTITY_ID = IO.ENTITY_ID
                      AND PPA.MRP_ORG_ID = IO.ORGANIZATION_ID
                      AND IPI.ITEM_CODE = ITEM.ITEM_CODE 
                      AND IPI.ENTITY_ID = LINES.ENTITY_ID
                      AND IPI.PO_AREA_ID = PRODUCINGAREA.PRODUCING_AREA_ID),
                   PRODUCINGAREA.MRP_ORG_CODE),
               item_old.PRODUCTFORM,
               CODELIST.CODE_NAME,
               VS_ENTITY_CODE,
               P_USER_CODE,
               SYSDATE,
               P_USER_CODE,
               SYSDATE,
               'N',
               TO_CHAR(LINES.MONTH_PLAN_HEAD_ID),
               TO_CHAR(LINES.MONTH_PLAN_LINE_ID),
			   LINES.Pre_Field_03,  --增加产品是否为全新品属性   jiangwei29 2019-6-28
               (SELECT IC.CLASS_NAME
                  FROM T_BD_ITEM_CLASS IC
                 WHERE IC.CLASS_TYPE = 'M'
                   AND CLASS_CODE = LINES.SALES_MAIN_TYPE
                   AND ENTITY_ID = LINES.ENTITY_ID
                   AND ROWNUM = 1), --APS要中文
               (SELECT IC.CLASS_NAME
                  FROM T_BD_ITEM_CLASS IC
                 WHERE IC.CLASS_TYPE = 'S'
                   AND CLASS_CODE = LINES.SALES_SUB_TYPE
                   AND ENTITY_ID = LINES.ENTITY_ID
                   AND ROWNUM = 1),
               LINES.M2_MONTH_PLAN_QTY,
               LINES.M3_MONTH_PLAN_QTY,
               DECODE(ITEM.SOURCE_ITEM_CODE, '', '', ITEM.ITEM_CODE), --新品编码
               DECODE(ITEM.SOURCE_ITEM_CODE, '', '', ITEM.ITEM_NAME),
               LINES.CURRENT_STOCK_CIMS,
               LINES.TO_APS_PRICE,
               LINES.UNDELIVERED_QTY,
               LINES.UNSATISFIED_QTY,
               LINES.MONTHLY_AVERAGE_SALES
          FROM T_STP_MONTH_PLAN_LINES LINES,
               T_PLN_PRODUCING_AREA   PRODUCINGAREA,
               T_BD_ITEM              ITEM,
               T_BD_ITEM              ITEM_OLD,
               V_UP_CODELIST          CODELIST
         WHERE LINES.MONTH_PLAN_HEAD_ID = P_HEAD_ID
           AND LINES.PRODUCING_AREA_CODE =
               PRODUCINGAREA.PRODUCING_AREA_CODE(+)
           AND PRODUCINGAREA.ENTITY_ID (+)= LINES.ENTITY_ID 
           AND LINES.ENTITY_ID = ITEM.ENTITY_ID 
           AND LINES.ITEM_CODE = ITEM.ITEM_CODE
           AND item_old.item_code=nvl(item.source_item_code,item.item_code) --新品要取老品的字段
           AND item_old.entity_id=item.entity_id
           AND item_old.PRODUCTFORM = CODELIST.CODE_VALUE
           AND CODELIST.CODETYPE = 'GE_MPL_PRODUCT_FORM' 
           ;
 --合并产品编码和产地相同的数据
 --合并数量    
 MERGE INTO INTF_STP_DOMESTIC_FORCAST A
 USING (SELECT A.ITEM_CODE,
               A.MRP_ORG_CODE,
               A.PRE_FIELD_01,
               a.new_item_code,
               COUNT(1),
               SUM(A.MONTH_PLAN_QTY) AS MONTH_PLAN_QTY,
               SUM(A.M2_MONTH_PLAN_QTY) AS M2_MONTH_PLAN_QTY,
               SUM(A.M3_MONTH_PLAN_QTY) AS M3_MONTH_PLAN_QTY,
			   sum(a.monthly_average_sales) as monthly_average_sales
          FROM INTF_STP_DOMESTIC_FORCAST A
         WHERE A.PRE_FIELD_01 = P_HEAD_ID --某个头id的
           AND A.INTF_STATUS = 'N'
         GROUP BY A.ITEM_CODE, A.MRP_ORG_CODE, A.PRE_FIELD_01,a.new_item_code
        HAVING COUNT(1) > 1) FORC
 ON (FORC.PRE_FIELD_01 = A.PRE_FIELD_01 AND A.ITEM_CODE = FORC.ITEM_CODE AND nvl(A.MRP_ORG_CODE,'_') = nvl(FORC.MRP_ORG_CODE,'_') and nvl(a.new_item_code,'-')= nvl(forc.new_item_code,'-'))
 WHEN MATCHED THEN
   UPDATE
      SET A.MONTH_PLAN_QTY    = FORC.MONTH_PLAN_QTY,
          A.M2_MONTH_PLAN_QTY = FORC.M2_MONTH_PLAN_QTY,
          A.M3_MONTH_PLAN_QTY = FORC.M3_MONTH_PLAN_QTY,
		  a.monthly_average_sales=forc.monthly_average_sales
		  ;
 --删除重复数据
 DELETE FROM INTF_STP_DOMESTIC_FORCAST M
  WHERE (M.ITEM_CODE, nvl(M.MRP_ORG_CODE,'_'), M.PRE_FIELD_01,nvl(m.new_item_code,'-')) IN
        (SELECT A.ITEM_CODE, nvl(A.MRP_ORG_CODE,'_'), A.PRE_FIELD_01,nvl(a.new_item_code,'-')
           FROM INTF_STP_DOMESTIC_FORCAST A
          WHERE A.PRE_FIELD_01 = P_HEAD_ID
            AND A.INTF_STATUS = 'N'
          GROUP BY A.ITEM_CODE, nvl(A.MRP_ORG_CODE,'_'), A.PRE_FIELD_01,nvl(a.new_item_code,'-')
         HAVING COUNT(1) > 1)
    AND M.DOMESTIC_FORCAST_ID NOT IN
        (SELECT MIN(A.DOMESTIC_FORCAST_ID)
           FROM INTF_STP_DOMESTIC_FORCAST A
          WHERE A.PRE_FIELD_01 = P_HEAD_ID
            AND A.INTF_STATUS = 'N'
          GROUP BY A.ITEM_CODE, nvl(A.MRP_ORG_CODE,'_'), A.PRE_FIELD_01,nvl(a.new_item_code,'-')
         HAVING COUNT(1) > 1);
              
      SELECT COUNT(*)
        INTO VN_COUNT
        FROM T_STP_MONTH_PLAN_LINES LINES,
             T_PLN_PRODUCING_AREA   PRODUCINGAREA,
             T_BD_ITEM              ITEM,
             V_UP_CODELIST          CODELIST
       WHERE LINES.MONTH_PLAN_HEAD_ID = P_HEAD_ID
         AND LINES.PRODUCING_AREA_CODE = PRODUCINGAREA.PRODUCING_AREA_CODE(+)
         AND LINES.ITEM_CODE = ITEM.ITEM_CODE
         AND PRODUCINGAREA.ENTITY_ID (+)= LINES.ENTITY_ID
         AND LINES.ENTITY_ID = ITEM.ENTITY_ID 
         AND ITEM.PRODUCTFORM = CODELIST.CODE_VALUE
         AND CODELIST.CODETYPE = 'GE_MPL_PRODUCT_FORM';   
      IF VN_COUNT <= 0 THEN
        P_RESULT := '生成接口表失败。';
        ROLLBACK;
      END IF;
      
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      P_RESULT := '插入机型预测接口表失败。' || V_NL || '失败信息：' || P_RESULT || V_NL ||
                  '系统提示：' || SQLERRM || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
      ROLLBACK;
  END;
-----------------------------------------------------------------------------

  ----------------------------------------------------------------------
  -- Author  : fenggq
  -- Created : 2014-08-30 13:51:00
  -- Purpose : 月计划订单业务表写入接口表
  ----------------------------------------------------------------------
  Procedure p_Create_Intf_Month_Plan(p_Head_Id     In Number, --月计划订单表头
                                     p_User_Code   In Varchar2, --登录用户名
                                     p_Send_Status In Varchar2, --引APS状态
                                     p_Result      Out Varchar2) Is
  
    Vn_Entity_Id         Intf_Pln_Month_Plan.Entity_Id%Type;
    Vs_Sales_Center_Code Intf_Pln_Month_Plan.Sales_Center_Code%Type;
    Vs_Order_Type        Intf_Pln_Month_Plan.Order_Type%Type;
    Vs_Entity_Code       Varchar2(100);
    Vn_Count             Number;
    Vs_Customer_Code     Intf_Pln_Month_Plan.Customer_Code%Type;
    
    --add by fenggq 2015-03-11 校验产品生命周期
    V_MESSAGE VARCHAR2(3000);
    VS_ITEM_LIFE_CYCLE VARCHAR2(10);
    VS_CHECK_RESULT VARCHAR2(4000);
    --end by fenggq
  Begin
    p_Result := v_Success;
    For r_Line In (Select *
                     From t_Pln_Order_Line l
                    Where l.Order_Head_Id = p_Head_Id) Loop
      Select Count(1)
        Into Vn_Count
        From Intf_Pln_Month_Plan Pmp
       Where Pmp.Pre_Field_01 = To_Char(p_Head_Id)
         And Pmp.Pre_Field_02 = To_Char(r_Line.Order_Line_Id)
         And Pmp.Send_Status = p_Send_Status
         And Pmp.Intf_Status In ('W', 'S');
      If Vn_Count > 0 Then
        p_Result := '生成月订单接口数据失败, 订单行数据已引APS接口成功，不允许重新引入。' || '订单行ID：' ||
                    To_Char(r_Line.Order_Line_Id) || '，产品编码：' ||
                    r_Line.Item_Code;
        Raise v_Base_Exception;
      End If;
    End Loop;
  
    Select Head.Entity_Id, Head.Sales_Center_Code, Head.Customer_Code
      Into Vn_Entity_Id, Vs_Sales_Center_Code, Vs_Customer_Code
      From t_Pln_Order_Head Head
     Where Head.Order_Head_Id = p_Head_Id;
    
    --add by fenggq 2015-03-11 校验产品生命周期
    BEGIN
      VS_ITEM_LIFE_CYCLE := PKG_BD.F_GET_PARAMETER_VALUE('PLN_ITEM_LIFE_CYCLE', VN_ENTITY_ID);
    EXCEPTION
      WHEN OTHERS THEN
        P_RESULT := '获取PLN_ITEM_LIFE_CYCLE参数失败。' || V_NL || SQLERRM;
        RAISE V_BASE_EXCEPTION;
    END;
    
    --是否校验产品生命周期
    IF VS_ITEM_LIFE_CYCLE != 'N' THEN
      V_MESSAGE := NULL;
      --按月送审
      FOR C_PLN_ITEM_LIFE_CYCLE IN
        (SELECT OL.ENTITY_ID,
                OL.ITEM_ID,
                OL.PRODUCING_AREA_ID
           FROM T_PLN_ORDER_HEAD          OH,
                T_PLN_ORDER_LINE          OL
          WHERE OH.ORDER_HEAD_ID = P_HEAD_ID
            AND OH.ORDER_HEAD_ID = OL.ORDER_HEAD_ID
            AND OL.CAN_PRODUCE_QTY > 0) LOOP
        VS_CHECK_RESULT := NULL;
        VS_CHECK_RESULT := PKG_PLN_PUB.P_CHK_ITEM_PRDC_LIFE_CYCLE(C_PLN_ITEM_LIFE_CYCLE.ENTITY_ID, C_PLN_ITEM_LIFE_CYCLE.ITEM_ID,
                                    C_PLN_ITEM_LIFE_CYCLE.PRODUCING_AREA_ID, PKG_PLN_PUB.V_PHASE_INTF_APS);
        IF VS_CHECK_RESULT != 'Y' THEN
          V_MESSAGE := V_MESSAGE || VS_CHECK_RESULT || V_NL;
        END IF;
      END LOOP;
      
      IF V_MESSAGE IS NOT NULL THEN
        P_RESULT :=  '以下产品在所属生命周期内不能引APS。' || V_NL || V_MESSAGE;
        RAISE V_BASE_EXCEPTION;
      END IF;
    END IF;
    --end by fenggq
  
    If p_Send_Status = '200' Then
      Vs_Order_Type := '月增补';
    Else
      Vs_Order_Type := '月订单';
    End If;
    -- add by ccz 2015-09-24
     begin
       select ue.entity_code_name
         into Vs_Entity_Code
         from up_codelist up, up_codelist_entity ue
        where up.codetype = 'PlnEntityToMainEntity'
          and up.id = ue.codelist_id
          and ue.entity_id =Vn_Entity_Id;
     exception
       when no_data_found then
         begin
           Select Entity.Entity_Code
             Into Vs_Entity_Code
             From v_Bd_Entity Entity
            Where Entity.Entity_Id = Vn_Entity_Id;
         exception
           when others then
             p_Result := '获取主体失败' || sqlerrm;
             raise v_Base_Exception;
         end;
       when others then
         p_Result := '获取主体失败,主体快码PlnEntityToMainEntity' || sqlerrm;
         raise v_Base_Exception;
     end;
    Insert Into Intf_Pln_Month_Plan
      (Month_Plan_Id,
       Entity_Id,
       Demand_Date,
       Sales_Center_Code,
       Item_Code,
       Check_Qty,
       Amount,
       Mrp_Org_Code,
       Order_Type,
       Productform_Code,
       Productform_Name,
       Entity_Code,
       Send_Status,
       Created_By,
       Creation_Date,
       Last_Updated_By,
       Last_Update_Date,
       Intf_Status,
       Customer_Code,
       Pre_Field_01,
       Pre_Field_02)
      Select s_Intf_Pln_Month_Plan.Nextval,
             Vn_Entity_Id,
             Lines.End_Supply_Date,
             Vs_Sales_Center_Code,
             Lines.Item_Code,
             Nvl(Lines.Can_Produce_Qty, 0) - Nvl(Lines.Supply_Qty, 0),
             (Nvl(Lines.Can_Produce_Qty, 0) - Nvl(Lines.Supply_Qty, 0)) *
             Nvl(Lines.Item_Price, 0) * (100 - Nvl(Lines.Discount_Rate, 0)) / 100,
            -- Producingarea.Mrp_Org_Code,
            --add by 2015-09-25
             Nvl((Select Io.Organization_Code
            From t_Inv_Producting_Item Ipi,
                 t_Pln_Producing_Area  Ppa,
                 t_Inv_Organization    Io
           Where Ppa.Producing_Area_Id = Ipi.Po_Area_Id
             And Ppa.Entity_Id = Io.Entity_Id
             And Ppa.Mrp_Org_Id = Io.Organization_Id
             And ipi.item_code = Item.Item_Code --itemCode
             And ipi.entity_id =lines.entity_id --entityId
             And ipi.po_area_id =lines.producing_area_id ),Producingarea.Mrp_Org_Code),
             Vs_Order_Type,
             Item.Productform,
             Codelist.Code_Name,
             Vs_Entity_Code,
             p_Send_Status,
             p_User_Code,
             Sysdate,
             p_User_Code,
             Sysdate,
             'N',
             Vs_Customer_Code,
             To_Char(p_Head_Id),
             To_Char(Lines.Order_Line_Id)
        From t_Pln_Order_Line     Lines,
             t_Pln_Producing_Area Producingarea,
             t_Bd_Item            Item,
             v_Up_Codelist        Codelist
       Where Lines.Order_Head_Id = p_Head_Id
         And Lines.Producing_Area_Id = Producingarea.Producing_Area_Id
         And Lines.Item_Code = Item.Item_Code
         And Item.Productform = Codelist.Code_Value
         -- add by ex_zhangcc 
         And item.entity_id=Lines.entity_id
         And Nvl(Lines.Can_Produce_Qty, 0) - Nvl(Lines.Supply_Qty, 0) > 0
            --AND CODELIST.ENTITY_ID = VN_ENTITY_ID
         And Codelist.Codetype = 'GE_MPL_PRODUCT_FORM';
  Exception
    When v_Base_Exception Then
      p_Result := '异常过程：Pkg_Pln_intf.p_Create_Intf_Month_Plan' || v_Nl ||
                  p_Result;
      Rollback;
    When Others Then
      p_Result := '插入月计划订单接口表失败。' || v_Nl || '失败信息：' || Sqlerrm;
      Rollback;
  End;
  
  ----------------------------------------------------------------------
  -- Author  : fenggq
  -- Created : 2014-09-01 21:37:00
  -- Purpose : 周排产订单业务表写入接口表
  ----------------------------------------------------------------------
  Procedure p_Create_Intf_Week_Order(p_Head_Id       In Number, --周排产订单表头
                                     p_Order_Type_Id In Number, --周排产类型ID
                                     p_User_Code     In Varchar2, --登录用户名
                                     p_Result        Out Varchar2
                                     ) Is
  
    Vn_Entity_Id         Intf_Pln_Week_Order.Entity_Id%Type;
    Vs_Order_Number      Intf_Pln_Week_Order.Order_Number%Type;
    Vs_Order_Type        Intf_Pln_Week_Order.Order_Type%Type;
    Vs_Customer_Code     Intf_Pln_Week_Order.Customer_Code%Type;
	 vs_consignee_addr 	   Intf_Pln_Week_Order.consignee_addr%Type;
    Vs_Entity_Code       Varchar2(100);
    Vn_Count             Number;
    Vs_Sales_Center_Code Intf_Pln_Week_Order.Sales_Center_Code%Type;
    
    --add by fenggq 2015-03-11 校验产品生命周期
    V_MESSAGE VARCHAR2(3000);
    VS_ITEM_LIFE_CYCLE VARCHAR2(10);
    VS_CHECK_RESULT VARCHAR2(4000);
    v_Direct_Order_Flag  Varchar2(50);
    v_Source_Type        Varchar2(32);
    v_Source_Order_Number Varchar2(64);
    v_Carload_Meet_Num    Varchar2(32);
    v_Week_Order_Demand_Date  Varchar2(32);
    --end by fenggq
    v_assemble_line t_pln_order_head.assemble_line%type;
  Begin
    p_Result := v_Success;
    For r_Detail In (Select *
                       From t_Pln_Order_Detail d
                      Where d.Order_Head_Id = p_Head_Id) Loop
      Select Count(1)
        Into Vn_Count
        From Intf_Pln_Week_Order Pwo
       Where Pwo.Order_Detail_Id = r_Detail.Order_Detail_Id
         And Pwo.Intf_Status In ('W', 'S');
      If Vn_Count > 0 Then
        p_Result := '生成周订单接口数据失败, 订单明细数据已引APS接口成功，不允许重新引入。' || v_Nl ||
                    '订单明细ID：' || To_Char(r_Detail.Order_Detail_Id) ||
                    '，产品编码：' || r_Detail.Item_Code;
        Raise v_Base_Exception;
      End If;
    End Loop;
    
    Select Head.Entity_Id,
           Head.Order_Number,
           Nvl(Head.Customer_Code, Head.Sales_Center_Code),
           Head.Sales_Center_Code, 
           Head.Out_Line_Flag, --add by lizhen 2016-01-14
           Head.Source_Type, --add by lizhen 2016-07-14
           Head.Source_Order_Number, --add by lizhen 2016-07-14
           Head.Carload_Meet_Num  --add by lizhen 2016-07-14
           ,head.assemble_line
		   ,head.consignee_addr
      Into Vn_Entity_Id,
           Vs_Order_Number,
           Vs_Customer_Code,
           Vs_Sales_Center_Code,
           v_Direct_Order_Flag,
           v_Source_Type,   --add by lizhen 2016-07-14
           v_Source_Order_Number,  --add by lizhen 2016-07-14
           v_Carload_Meet_Num     --add by lizhen 2016-07-14
           ,v_assemble_line
		   ,vs_consignee_addr
      From t_Pln_Order_Head Head
     Where Head.Order_Head_Id = p_Head_Id;
    
    --add by fenggq 2015-03-11 校验产品生命周期
    BEGIN
      VS_ITEM_LIFE_CYCLE := PKG_BD.F_GET_PARAMETER_VALUE('PLN_ITEM_LIFE_CYCLE',
                                                              VN_ENTITY_ID);
    EXCEPTION
      WHEN OTHERS THEN
        P_RESULT := '获取PLN_ITEM_LIFE_CYCLE参数失败。' || V_NL || SQLERRM;
        RAISE V_BASE_EXCEPTION;
    END;
    
    --add by fenggq 2015-03-11 校验产品生命周期
    BEGIN
      v_Week_Order_Demand_Date := PKG_BD.F_GET_PARAMETER_VALUE('PLN_WEEK_ORDER_DEMAND_DATE',
                                                              VN_ENTITY_ID);
    EXCEPTION
      WHEN OTHERS THEN
        P_RESULT := '获取PLN_WEEK_ORDER_DEMAND_DATE参数失败。' || V_NL || SQLERRM;
        RAISE V_BASE_EXCEPTION;
    END;
    
    --是否校验产品生命周期
    IF VS_ITEM_LIFE_CYCLE != 'N' THEN
      V_MESSAGE := NULL;
      --按周送审
      FOR C_PLN_ITEM_LIFE_CYCLE IN
        (SELECT OL.ENTITY_ID,
                OL.ITEM_ID,
                OL.PRODUCING_AREA_ID
           FROM T_PLN_ORDER_HEAD          OH,
                T_PLN_ORDER_LINE          OL
          WHERE OH.ORDER_HEAD_ID = P_HEAD_ID
            AND OH.ORDER_HEAD_ID = OL.ORDER_HEAD_ID
            AND OL.CAN_PRODUCE_QTY > 0) LOOP
        VS_CHECK_RESULT := NULL;
        VS_CHECK_RESULT := PKG_PLN_PUB.P_CHK_ITEM_PRDC_LIFE_CYCLE(C_PLN_ITEM_LIFE_CYCLE.ENTITY_ID, C_PLN_ITEM_LIFE_CYCLE.ITEM_ID,
                                    C_PLN_ITEM_LIFE_CYCLE.PRODUCING_AREA_ID, PKG_PLN_PUB.V_PHASE_INTF_APS);
        IF VS_CHECK_RESULT != 'Y' THEN
          V_MESSAGE := V_MESSAGE || VS_CHECK_RESULT || V_NL;
        END IF;
      END LOOP;
      
      IF V_MESSAGE IS NOT NULL THEN
        P_RESULT := '以下产品在所属生命周期内不能引APS。' || V_NL || V_MESSAGE;
        RAISE V_BASE_EXCEPTION;
      END IF;
    END IF;
    --end by fenggq
  
    --VS_ORDER_TYPE := TO_CHAR(P_ORDER_TYPE_ID);
    Select Ordertype.Order_Type_Code
      Into Vs_Order_Type
      From t_Pln_Order_Type Ordertype
     Where Ordertype.Order_Type_Id = p_Order_Type_Id;
  
      -- add by ccz 2015-09-24
     begin
       select ue.entity_code_name
         into Vs_Entity_Code
         from up_codelist up,up_codelist_entity ue 
        where up.codetype = 'PlnEntityToMainEntity'
          and up.id = ue.codelist_id
          and ue.entity_id =Vn_Entity_Id;
     exception
       when no_data_found then
         begin
           Select Entity.Entity_Code
             Into Vs_Entity_Code
             From v_Bd_Entity Entity
            Where Entity.Entity_Id = Vn_Entity_Id;
         exception
           when others then
             p_Result := '获取主体失败' || sqlerrm;
             raise v_Base_Exception;
         end;
       when others then
         p_Result := '获取主体失败,主体快码PlnEntityToMainEntity' || sqlerrm;
         raise v_Base_Exception;
     end;
     Insert Into Intf_Pln_Week_Order
       (Week_Order_Id,
        Entity_Id,
        Order_Detail_Id,
        Item_Code,
        Can_Produce_Qty,
        Mrp_Org_Id,
        Mrp_Org_Code,
        Order_Number,
        Order_Type,
        Customer_Code,
        Order_Line_Id,
        Ass_Item_Code,
        Request_Date,
        Demand_Date,
        Promise_Date,
        Order_Remark,
        Entity_Name,
        Domestic_Oversea,
        Demand_Status,
        Created_By,
        Creation_Date,
        Last_Updated_By,
        Last_Update_Date,
        Intf_Status,
        Line_Num,
        Sales_Center_Code,
        Pre_Field_01,
        Direct_Order,
        Synt_Order_Flag,
        Expect_Date, --add by lizhen 2016-07-25
        Lg_Collect_Number, --add by lizhen 2016-07-25
        Carload_Meet_Num --add by lizhen 2016-07-25
        ,RISK_FLAG --hejy3 风险产品标识
        ,CAN_PRODUCE_FLAG --hejy3 可排产标识
        ,assemble_line
        ,union_flag
		,consignee_addr
        )
       Select s_Intf_Pln_Week_Order.Nextval,
              Vn_Entity_Id,
              Detail.Order_Detail_Id,
              Detail.Item_Code,
              Nvl(Detail.Can_Produce_Qty, 0) - Nvl(Detail.Supply_Qty, 0),
              Nvl((Select Io.Organization_Id
                    From t_Inv_Producting_Item Ipi,
                         t_Pln_Producing_Area  Ppa,
                         t_Inv_Organization    Io
                   Where Ppa.Producing_Area_Id = Ipi.Po_Area_Id
                     And Ppa.Entity_Id = Io.Entity_Id
                     And Ppa.Mrp_Org_Id = Io.Organization_Id
                     And Ipi.Item_Code = Detail.Item_Code --itemCode
                     And Ipi.Entity_Id = Detail.Entity_Id --entityId
                     And Ipi.Po_Area_Id = Detail.Producing_Area_Id),
                  Producingarea.Mrp_Org_Id),
              --Producingarea.Mrp_Org_Id,
              --Producingarea.Mrp_Org_Code,
              Nvl((Select Io.Organization_Code
                    From t_Inv_Producting_Item Ipi,
                         t_Pln_Producing_Area  Ppa,
                         t_Inv_Organization    Io
                   Where Ppa.Producing_Area_Id = Ipi.Po_Area_Id
                     And Ppa.Entity_Id = Io.Entity_Id
                     And Ppa.Mrp_Org_Id = Io.Organization_Id
                     And Ipi.Item_Code = Detail.Item_Code --itemCode
                     And Ipi.Entity_Id = Detail.Entity_Id --entityId
                     And Ipi.Po_Area_Id = Detail.Producing_Area_Id),
                  Producingarea.Mrp_Org_Code),
              Vs_Order_Number,
              Vs_Order_Type,
              Vs_Customer_Code,
              Lines.Order_Line_Id,
              Lines.Item_Code,
              Lines.End_Supply_Date,
              Decode(v_Week_Order_Demand_Date,  --ADD BY LIZHEN 2016-09-28 
                     'Y',
                     Nvl(Lines.Aps_Promise_Time, Lines.End_Supply_Date),
              Least(Nvl(Lines.Aps_Promise_Time, Lines.End_Supply_Date),
                    Lines.End_Supply_Date)), --modi by lizhen 2016-04-12 使用 --Lines.End_Supply_Date,
              --modi by lizhen 2016-08-29 Promise_Date清尾日期不为空的，取清尾日期数据 -Lines.End_Supply_Date,
              Decode(Lines.Promise_Date_By_Mantissa,
                     Null,
                     Lines.End_Supply_Date,
                     Lines.Promise_Date_By_Mantissa),
              Lines.Remark,
              Vs_Entity_Code,
              '内销',
              --Demand_Status:NEW:新增  UPDATED：修改  CANCELLED：取消（内销暂不用该状态，整行取消时使用UPDATED数量传0） 
              'NEW',
              p_User_Code,
              Sysdate,
              p_User_Code,
              Sysdate,
              'N',
              Rownum,
              Vs_Sales_Center_Code,
              To_Char(p_Head_Id),
              v_Direct_Order_Flag,
              Decode(Lines.Synt_Order_Flag,
                     'Y',
                     Nvl((Select 'Y'
                           From Up_Codelist Uc
                          Where Uc.Codetype = 'PLN_SYNT_PRODUCING_WIP_COPY'
                            And Uc.Enabled = 0
                            And Uc.Code_Value = Producingarea.Mrp_Org_Code
                            And Rownum = 1),
                         'N'),
                     'N'), --add by lizhen 2016-01-14
              Lines.Expect_Date, --add by lizhen 2016-07-25
              Decode(v_Source_Type, '提货订单', v_Source_Order_Number, Null), --add by lizhen 2016-07-25
              v_Carload_Meet_Num --add by lizhen 2016-07-25
              ,nvl(lines.risk_flag,'N') --hejy3 风险产品标识
              ,decode(nvl(lines.risk_flag,'N'),'Y','N','Y') --hejy3 可排产标识
              ,v_assemble_line
              ,lines.union_flag
			  ,vs_consignee_addr
         From t_Pln_Order_Detail   Detail,
              t_Pln_Producing_Area Producingarea,
              t_Pln_Order_Line     Lines
        Where Detail.Order_Head_Id = p_Head_Id
          And Detail.Producing_Area_Id = Producingarea.Producing_Area_Id
          And Detail.Order_Line_Id = Lines.Order_Line_Id
          And Nvl(Detail.Can_Produce_Qty, 0) - Nvl(Detail.Supply_Qty, 0) > 0;
  Exception
    When v_Base_Exception Then
      p_Result := '异常过程：Pkg_Pln_intf.p_Create_Intf_Week_Order' || v_Nl ||
                  p_Result;
      Rollback;
    When Others Then
      p_Result := '插入周排产订单接口表失败。' || v_Nl || '失败信息：' || Sqlerrm;
      Rollback;
  End;
  
  ----------------------------------------------------------------------
  -- Author  : Nicro.Li
  -- Created : 2016-09-05 21:37:00
  -- Purpose : 订单调整单写入APS周订单接口表
  ----------------------------------------------------------------------
  Procedure p_Create_Adjust_Week_Order(p_Adjust_Haed_Id       In Number, --订单调整表
                                       p_Order_Type_Id In Number, --周排产类型ID
                                       p_User_Code     In Varchar2, --登录用户名
                                       p_Result        Out Varchar2
                                       ) Is
  
    Vn_Entity_Id         Intf_Pln_Week_Order.Entity_Id%Type;
    Vs_Order_Number      Intf_Pln_Week_Order.Order_Number%Type;
    Vs_Order_Type        Intf_Pln_Week_Order.Order_Type%Type;
    Vs_Customer_Code     Intf_Pln_Week_Order.Customer_Code%Type;
    Vs_Entity_Code       Varchar2(100);
    Vn_Count             Number;
    Vs_Sales_Center_Code Intf_Pln_Week_Order.Sales_Center_Code%Type;
    
    --add by fenggq 2015-03-11 校验产品生命周期
    V_MESSAGE VARCHAR2(3000);
    VS_ITEM_LIFE_CYCLE VARCHAR2(10);
    VS_CHECK_RESULT VARCHAR2(4000);
    v_Direct_Order_Flag  Varchar2(50);
    v_Source_Type        Varchar2(32);
    v_Source_Order_Number Varchar2(64);
    v_Carload_Meet_Num    Varchar2(32);
    v_Order_Head_Id       Number;
    v_Is_Aps_Need         Varchar2(32);
    --end by fenggq
  Begin
    p_Result := v_Success;
    Begin
      Select Oah.Order_Head_Id
        Into v_Order_Head_Id
        From t_Pln_Order_Adjust_Head Oah
       Where Oah.Order_Adjust_Head_Id = p_Adjust_Haed_Id
         For Update Nowait;
    Exception
      When Others Then
        p_Result := '引订单APS接口失败，未找到对应的订单调整头数据。' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;
    For r_Detail In (Select Pod.Order_Detail_Id,
                            Pod.Can_Produce_Qty,
                            Pod.Cancel_Qty,
                            Pod.Item_Code
                       From t_Pln_Order_Detail      Pod,
                            t_Pln_Order_Adjust_Line Oal
                      Where Oal.Order_Line_Id = Pod.Order_Line_Id
                        And Oal.Order_Head_Id = Pod.Order_Head_Id
                        And Oal.Order_Adjust_Head_Id = p_Adjust_Haed_Id) Loop
      --add by lizhen 2016-08-31 检查行表剩余排产数量是否存在负数情况
      If Nvl(r_Detail.Can_Produce_Qty, 0) - Nvl(r_Detail.Cancel_Qty, 0) < 0 Then
        p_Result := '生成周订单接口数据失败, 订单明细行存在剩余排产数量为负数数据，不允许引入APS。' || v_Nl ||
                    '订单明细ID：' || To_Char(r_Detail.Order_Detail_Id) ||
                   '，产品编码：' || r_Detail.Item_Code;
        Raise v_Base_Exception;
      End If;
    End Loop;
    
    Select Head.Entity_Id,
           Head.Order_Number,
           Nvl(Head.Customer_Code, Head.Sales_Center_Code),
           Head.Sales_Center_Code, 
           Head.Out_Line_Flag, --add by lizhen 2016-01-14
           Head.Source_Type, --add by lizhen 2016-07-14
           Head.Source_Order_Number, --add by lizhen 2016-07-14
           Head.Carload_Meet_Num  --add by lizhen 2016-07-14
      Into Vn_Entity_Id,
           Vs_Order_Number,
           Vs_Customer_Code,
           Vs_Sales_Center_Code,
           v_Direct_Order_Flag,
           v_Source_Type,   --add by lizhen 2016-07-14
           v_Source_Order_Number,  --add by lizhen 2016-07-14
           v_Carload_Meet_Num     --add by lizhen 2016-07-14
      From t_Pln_Order_Head Head
     Where Head.Order_Head_Id = v_Order_Head_Id;
    
    --add by fenggq 2015-03-11 校验产品生命周期
    BEGIN
      VS_ITEM_LIFE_CYCLE := PKG_BD.F_GET_PARAMETER_VALUE('PLN_ITEM_LIFE_CYCLE',
                                                              VN_ENTITY_ID);
    EXCEPTION
      WHEN OTHERS THEN
        P_RESULT := '获取PLN_ITEM_LIFE_CYCLE参数失败。' || V_NL || SQLERRM;
        RAISE V_BASE_EXCEPTION;
    END;
    
    --是否校验产品生命周期
    IF VS_ITEM_LIFE_CYCLE != 'N' THEN
      V_MESSAGE := NULL;
      --按周送审
      FOR C_PLN_ITEM_LIFE_CYCLE IN
        (SELECT OL.ENTITY_ID,
                OL.ITEM_ID,
                OL.PRODUCING_AREA_ID
           FROM T_PLN_ORDER_HEAD          OH,
                T_PLN_ORDER_LINE          OL,
                T_PLN_ORDER_ADJUST_LINE   OAL
          WHERE OH.ORDER_HEAD_ID = v_Order_Head_Id
            AND OH.ORDER_HEAD_ID = OL.ORDER_HEAD_ID
            And OAL.ORDER_LINE_ID = OL.ORDER_LINE_ID
            And OAL.ORDER_HEAD_ID = OL.ORDER_HEAD_ID
            And OAL.ORDER_ADJUST_HEAD_ID = p_Adjust_Haed_Id
            AND OL.CAN_PRODUCE_QTY > 0) LOOP
        VS_CHECK_RESULT := NULL;
        VS_CHECK_RESULT := PKG_PLN_PUB.P_CHK_ITEM_PRDC_LIFE_CYCLE(C_PLN_ITEM_LIFE_CYCLE.ENTITY_ID, C_PLN_ITEM_LIFE_CYCLE.ITEM_ID,
                                    C_PLN_ITEM_LIFE_CYCLE.PRODUCING_AREA_ID, PKG_PLN_PUB.V_PHASE_INTF_APS);
        IF VS_CHECK_RESULT != 'Y' THEN
          V_MESSAGE := V_MESSAGE || VS_CHECK_RESULT || V_NL;
        END IF;
      END LOOP;
      
      IF V_MESSAGE IS NOT NULL THEN
        P_RESULT := '以下产品在所属生命周期内不能引APS。' || V_NL || V_MESSAGE;
        RAISE V_BASE_EXCEPTION;
      END IF;
    END IF;
    --end by fenggq
  
    --VS_ORDER_TYPE := TO_CHAR(P_ORDER_TYPE_ID);
    Select Ordertype.Order_Type_Code, Ordertype.Is_Aps_Need
      Into Vs_Order_Type, v_Is_Aps_Need
      From t_Pln_Order_Type Ordertype
     Where Ordertype.Order_Type_Id = p_Order_Type_Id;
     
    --add by lizhen 2016-10-27不引入APS系统单据直接返回
    If Nvl(v_Is_Aps_Need, 'N') = 'N' Then
      Return;
    End If;   
  
      -- add by ccz 2015-09-24
     begin
       select ue.entity_code_name
         into Vs_Entity_Code
         from up_codelist up,up_codelist_entity ue 
        where up.codetype = 'PlnEntityToMainEntity'
          and up.id = ue.codelist_id
          and ue.entity_id =Vn_Entity_Id;
     exception
       when no_data_found then
         begin
           Select Entity.Entity_Code
             Into Vs_Entity_Code
             From v_Bd_Entity Entity
            Where Entity.Entity_Id = Vn_Entity_Id;
         exception
           when others then
             p_Result := '获取主体失败' || sqlerrm;
             raise v_Base_Exception;
         end;
       when others then
         p_Result := '获取主体失败,主体快码PlnEntityToMainEntity' || sqlerrm;
         raise v_Base_Exception;
     end;
     Insert Into Intf_Pln_Week_Order
       (Week_Order_Id,
        Entity_Id,
        Order_Detail_Id,
        Item_Code,
        Can_Produce_Qty,
        Mrp_Org_Id,
        Mrp_Org_Code,
        Order_Number,
        Order_Type,
        Customer_Code,
        Order_Line_Id,
        Ass_Item_Code,
        Request_Date,
        Demand_Date,
        Promise_Date,
        Order_Remark,
        Entity_Name,
        Domestic_Oversea,
        Demand_Status,
        Created_By,
        Creation_Date,
        Last_Updated_By,
        Last_Update_Date,
        Intf_Status,
        Line_Num,
        Sales_Center_Code,
        Pre_Field_01,
        Direct_Order,
        Synt_Order_Flag,
        Expect_Date, --add by lizhen 2016-07-25
        Lg_Collect_Number, --add by lizhen 2016-07-25
        Carload_Meet_Num --add by lizhen 2016-07-25
        ,RISK_FLAG --hejy3 风险产品标识
        ,CAN_PRODUCE_FLAG --hejy3 可排产标识
        )
       Select s_Intf_Pln_Week_Order.Nextval,
              Vn_Entity_Id,
              Detail.Order_Detail_Id,
              Detail.Item_Code,
              Nvl(Detail.Can_Produce_Qty, 0) - Nvl(Detail.Cancel_Qty, 0),
              Nvl((Select Io.Organization_Id
                    From t_Inv_Producting_Item Ipi,
                         t_Pln_Producing_Area  Ppa,
                         t_Inv_Organization    Io
                   Where Ppa.Producing_Area_Id = Ipi.Po_Area_Id
                     And Ppa.Entity_Id = Io.Entity_Id
                     And Ppa.Mrp_Org_Id = Io.Organization_Id
                     And Ipi.Item_Code = Detail.Item_Code --itemCode
                     And Ipi.Entity_Id = Detail.Entity_Id --entityId
                     And Ipi.Po_Area_Id = Detail.Producing_Area_Id),
                  Producingarea.Mrp_Org_Id),
              --Producingarea.Mrp_Org_Id,
              --Producingarea.Mrp_Org_Code,
              Nvl((Select Io.Organization_Code
                    From t_Inv_Producting_Item Ipi,
                         t_Pln_Producing_Area  Ppa,
                         t_Inv_Organization    Io
                   Where Ppa.Producing_Area_Id = Ipi.Po_Area_Id
                     And Ppa.Entity_Id = Io.Entity_Id
                     And Ppa.Mrp_Org_Id = Io.Organization_Id
                     And Ipi.Item_Code = Detail.Item_Code --itemCode
                     And Ipi.Entity_Id = Detail.Entity_Id --entityId
                     And Ipi.Po_Area_Id = Detail.Producing_Area_Id),
                  Producingarea.Mrp_Org_Code),
              Vs_Order_Number,
              Vs_Order_Type,
              Vs_Customer_Code,
              Lines.Order_Line_Id,
              Lines.Item_Code,
              Lines.End_Supply_Date,
              Least(Nvl(Lines.Aps_Promise_Time, Lines.End_Supply_Date),
                    Lines.End_Supply_Date), --modi by lizhen 2016-04-12 使用 --Lines.End_Supply_Date,
              --modi by lizhen 2016-08-29 Promise_Date清尾日期不为空的，取清尾日期数据 -Lines.End_Supply_Date,
              Decode(Lines.Promise_Date_By_Mantissa,
                     Null,
                     Lines.End_Supply_Date,
                     Lines.Promise_Date_By_Mantissa),
              Lines.Remark,
              Vs_Entity_Code,
              '内销',
              --Demand_Status:NEW:新增  UPDATED：修改  CANCELLED：取消（内销暂不用该状态，整行取消时使用UPDATED数量传0） 
              'UPDATED',
              p_User_Code,
              Sysdate,
              p_User_Code,
              Sysdate,
              'N',
              --modi by lizhen 2017-03-27 line_num 保持每次引入时都一致
              Nvl((Select Min(Pwo.Line_Num)
                    From Intf_Pln_Week_Order Pwo
                   Where Pwo.Order_Detail_Id = Detail.Order_Detail_Id),
              Rownum),  --line_num
              Vs_Sales_Center_Code,
              To_Char(v_Order_Head_Id),
              v_Direct_Order_Flag,
              Decode(Lines.Synt_Order_Flag,
                     'Y',
                     Nvl((Select 'Y'
                           From Up_Codelist Uc
                          Where Uc.Codetype = 'PLN_SYNT_PRODUCING_WIP_COPY'
                            And Uc.Enabled = 0
                            And Uc.Code_Value = Producingarea.Mrp_Org_Code
                            And Rownum = 1),
                         'N'),
                     'N'), --add by lizhen 2016-01-14
              Lines.Expect_Date, --add by lizhen 2016-07-25
              Decode(v_Source_Type, '提货订单', v_Source_Order_Number, Null), --add by lizhen 2016-07-25
              v_Carload_Meet_Num --add by lizhen 2016-07-25  
              ,nvl(lines.risk_flag,'N') --hejy3 风险产品标识
              ,decode(nvl(lines.risk_flag,'N'),'Y','N','Y') --hejy3 可排产标识   
         From t_Pln_Order_Detail   Detail,
              t_Pln_Producing_Area Producingarea,
              t_Pln_Order_Line     Lines,
              t_Pln_Order_Adjust_Line  Oal
        Where Detail.Order_Head_Id = v_Order_Head_Id
          And Detail.Producing_Area_Id = Producingarea.Producing_Area_Id
          And Detail.Order_Line_Id = Lines.Order_Line_Id
          And Detail.Order_Line_Id = Oal.Order_Line_Id
          And Detail.Order_Head_Id = Oal.Order_Head_Id
          And Oal.Order_Adjust_Head_Id = p_Adjust_Haed_Id
          And Nvl(Detail.Can_Produce_Qty, 0) - Nvl(Detail.Supply_Qty, 0) > 0;
  Exception
    When v_Base_Exception Then
      p_Result := '异常过程：Pkg_Pln_intf.p_Create_Intf_Week_Order' || v_Nl ||
                  p_Result;
      Rollback;
    When Others Then
      p_Result := '插入周排产订单接口表失败。' || v_Nl || '失败信息：' || Sqlerrm;
      Rollback;
  End;
  
  ----------------------------------------------------------------------
  -- Author  : fenggq
  -- Created : 2014-12-03 16:12:00
  -- Purpose : 更新产销平衡信息
  ----------------------------------------------------------------------
  PROCEDURE P_UPDATE_PROD_SALES_BALANCE(P_COLL_ORD_HEAD_ID IN NUMBER,   --订单汇总头ID
                                        P_PERIOD_ID        IN NUMBER,   --订单周期ID
                                        P_ENTITY_ID        IN NUMBER,   --主体ID
                                        P_RESULT           OUT VARCHAR2) IS
                                        
    /*VN_COLL_ORD_HEAD_ID T_PLN_ORDER_COLLECT_HEAD.COLL_ORD_HEAD_ID%TYPE;*/
    VN_MAX_BATCH_ID T_PLN_ORDER_COLLECT_SHOW.BATCH_ID%TYPE;
    
    VS_PRODUCING_AREA1  VARCHAR2(10);
    VS_PRODUCING_AREA2  VARCHAR2(10);
    VS_PRODUCING_AREA3  VARCHAR2(10);
    VS_PRODUCING_AREA4  VARCHAR2(10);
    VS_PRODUCING_AREA5  VARCHAR2(10);
    VS_PRODUCING_AREA6  VARCHAR2(10);
    VS_PRODUCING_AREA7  VARCHAR2(10);
    
    VS_NAME             VARCHAR2(20);
    UPDATESQL           VARCHAR2(2000);
    
  BEGIN
    P_RESULT := V_SUCCESS;
    
    VS_PRODUCING_AREA1 := 'A0001';
    VS_PRODUCING_AREA2 := 'A0002';
    VS_PRODUCING_AREA3 := 'A0003';
    VS_PRODUCING_AREA4 := 'A0004';
    VS_PRODUCING_AREA5 := 'A0005';
    VS_PRODUCING_AREA6 := 'A0006';
    VS_PRODUCING_AREA7 := 'A0007';
    
/*    SELECT COLL_ORD_HEAD_ID
      INTO VN_COLL_ORD_HEAD_ID
      FROM T_PLN_ORDER_COLLECT_HEAD
     WHERE ORDER_TYPE_ID = P_ORDER_TYPE_ID
       AND PERIOD_ID = P_PERIOD_ID
       AND ENTITY_ID = P_ENTITY_ID;*/
       
    SELECT MAX(BATCH_ID)
      INTO VN_MAX_BATCH_ID
      FROM T_PLN_ORDER_COLLECT_SHOW
     WHERE ORDER_COLLECT_HEAD_ID = P_COLL_ORD_HEAD_ID;
       
    FOR C_PLN_PROD_SALES_BALANCE IN (SELECT A.MRP_ORG_CODE, A.ITEM_CODE, A.DEMAND_DATE, C.PRODUCING_AREA_CODE, A.MEET_QTY
                                       FROM INTF_PLN_PROD_SALES_BALANCE A,
                                            T_PLN_ORDER_PERIOD          B,
                                            T_PLN_PRODUCING_AREA        C
                                      WHERE A.SYNC_STATUS = '00'
                                        --AND A.RESPONSETYPE = 'N'
                                        AND B.PERIOD_ID = P_PERIOD_ID
                                        AND B.BEGIN_DATE <= A.DEMAND_DATE
                                        AND B.END_DATE >= A.DEMAND_DATE
                                        AND B.ENTITY_ID = P_ENTITY_ID
                                        AND C.MRP_ORG_CODE = A.MRP_ORG_CODE
                                        AND C.ENTITY_ID = P_ENTITY_ID) LOOP
                                        
      IF C_PLN_PROD_SALES_BALANCE.PRODUCING_AREA_CODE = VS_PRODUCING_AREA1 THEN
        VS_NAME := 'QTY17';
      ELSIF C_PLN_PROD_SALES_BALANCE.PRODUCING_AREA_CODE = VS_PRODUCING_AREA2 THEN
        VS_NAME := 'QTY15';
      ELSIF C_PLN_PROD_SALES_BALANCE.PRODUCING_AREA_CODE = VS_PRODUCING_AREA3 THEN
        VS_NAME := 'QTY16';
      ELSIF C_PLN_PROD_SALES_BALANCE.PRODUCING_AREA_CODE = VS_PRODUCING_AREA4 THEN
        VS_NAME := 'QTY20';
      ELSIF C_PLN_PROD_SALES_BALANCE.PRODUCING_AREA_CODE = VS_PRODUCING_AREA5 THEN
        VS_NAME := 'QTY19';
      ELSIF C_PLN_PROD_SALES_BALANCE.PRODUCING_AREA_CODE = VS_PRODUCING_AREA6 THEN
        VS_NAME := 'QTY18';
      ELSIF C_PLN_PROD_SALES_BALANCE.PRODUCING_AREA_CODE = VS_PRODUCING_AREA7 THEN
        VS_NAME := 'QTY21';
      END IF;
      
      UPDATESQL := ' UPDATE T_PLN_ORDER_COLLECT_SHOW SET ' || VS_NAME || ' = ' || C_PLN_PROD_SALES_BALANCE.MEET_QTY
        || ' WHERE ORDER_COLLECT_HEAD_ID =  ' || P_COLL_ORD_HEAD_ID
        || ' AND   ITEM_CODE =              ' || '''' || C_PLN_PROD_SALES_BALANCE.ITEM_CODE || ''''
        || ' AND   BATCH_ID =               ' || VN_MAX_BATCH_ID
        || ' AND   ENTITY_ID =              ' || P_ENTITY_ID;
      EXECUTE IMMEDIATE UPDATESQL;
      
      UPDATE INTF_PLN_PROD_SALES_BALANCE
         SET SYNC_STATUS = '01'
       WHERE SYNC_STATUS = '00'
         --AND RESPONSETYPE = 'N'
         AND MRP_ORG_CODE = C_PLN_PROD_SALES_BALANCE.MRP_ORG_CODE
         AND ITEM_CODE = C_PLN_PROD_SALES_BALANCE.ITEM_CODE
         AND DEMAND_DATE = C_PLN_PROD_SALES_BALANCE.DEMAND_DATE;
         
    END LOOP;
    
  EXCEPTION
    WHEN OTHERS THEN
      P_RESULT := '更新产销平衡信息失败。' || V_NL || '失败信息：' || SQLERRM;
      ROLLBACK;
  END;
  
  ----------------------------------------------------------------------
  -- Author  : fenggq
  -- Created : 2014-01-14 15:14:00
  -- Purpose : 销售预测接口表写入业务表
  ----------------------------------------------------------------------
  PROCEDURE P_CREATE_SALES_FORECAST(P_TRX_NO IN VARCHAR2, --流水号
                                    P_RESULT OUT VARCHAR2) IS
                                    
    VS_MESSAGE           VARCHAR2(1024);
    VN_PERIOD_COUNT      NUMBER;
    VN_CUSTOMER_SC_COUNT NUMBER;
    VN_COUNT             NUMBER;
    V_entity_id          number;
  BEGIN
    P_RESULT := V_SUCCESS;
    VS_MESSAGE := V_SUCCESS;
    
    SELECT COUNT(*),sf.entity_id -- add by ccz 2015-09-24
      INTO VN_PERIOD_COUNT,V_entity_id
      FROM INTF_STP_SALES_FORECAST SF,
           T_PLN_ORDER_PERIOD OP
     WHERE SF.SYNC_STATUS = '00'
       AND SF.RESPONSETYPE IS NULL
       AND SF.TRX_NO = P_TRX_NO
       AND OP.BEGIN_DATE <= SF.FORECAST_DATE
       AND OP.END_DATE > = SF.FORECAST_DATE
       AND OP.PERIOD_TYPE = '月'
       group by sf.entity_id; -- add by ccz 2015-09-24
 
    IF VN_PERIOD_COUNT = 0 THEN
      P_RESULT := '订单周期未开，预测日期错误，请检查数据。';
      RETURN;
    END IF;
    
    SELECT COUNT(*)
      INTO VN_CUSTOMER_SC_COUNT
      FROM INTF_STP_SALES_FORECAST SF,
           V_CUSTOMER_ACCOUNT_SALECENTER CAS
     WHERE SF.SYNC_STATUS = '00'
       AND SF.RESPONSETYPE IS NULL
       AND SF.TRX_NO = P_TRX_NO
       AND CAS.CUSTOMER_CODE = SF.CUSTOMER_CODE
       AND CAS.SALES_CENTER_CODE = SF.SALES_CENTER_CODE
       AND CAS.ACTIVE_FLAG = 'Active'
       AND CAS.ENTITY_ID = SF.ENTITY_ID;
       
    IF VN_CUSTOMER_SC_COUNT = 0 THEN
      P_RESULT := '客户与营销中心对应关系错误，请检查数据。';
      RETURN;
    END IF;
   /*-- add by ccz 2015-09-24
     begin
       select ve.entity_id
         into V_Entity_Id
         from up_codelist up, up_codelist_entity ue, v_bd_entity ve
        where up.codetype = 'PlnEntityToMainEntity'
          and up.id = ue.codelist_id
          and ue.entity_id = V_Entity_Id
          and ve.entity_code = ue.entity_code_name;
     exception
       when no_data_found then
         begin
           Select  entity.entity_id
             Into  V_Entity_Id
             From v_Bd_Entity Entity
            Where Entity.Entity_Id = V_Entity_Id;
         exception
           when others then
             p_Result := '获取主体失败' || sqlerrm;
             raise v_Base_Exception;
         end;
       when others then
         p_Result := '获取主体失败,主体快码PlnEntityToMainEntity' || sqlerrm;
         raise v_Base_Exception;
     end;*/
    INSERT INTO T_STP_SALES_FORECAST
      (SALES_FORECAST_ID,
       ENTITY_ID,
       FORECAST_PERIOD,
       SALES_CENTER_CODE,
       SALES_CENTER_NAME,
       ACCOUNT_CODE,
       CUSTOMER_CODE,
       CUSTOMER_NAME,
       SALES_MAIN_TYPE,
       SALES_SUB_TYPE,
       ITEM_CODE,
       ITEM_NAME,
       MONTH_FORECAST_QTY,
       FORECAST_DATE,
       CREATED_BY,
       CREATION_DATE,
       LAST_UPDATED_BY,
       LAST_UPDATE_DATE)
      SELECT S_STP_SALES_FORECAST.NEXTVAL,
             V_Entity_Id,
             OP.PERIOD_ID,
             SF.SALES_CENTER_CODE,
             BSC.SALES_CENTER_NAME,
             CAS.ACCOUNT_CODE,
             SF.CUSTOMER_CODE,
             CH.CUSTOMER_NAME,
             BI.SALES_MAIN_TYPE,
             BI.SALES_SUB_TYPE,
             SF.ITEM_CODE,
             BI.ITEM_NAME,
             SF.MONTH_FORECAST_QTY,
             SF.FORECAST_DATE,
             SF.CREATED_BY,
             SF.CREATION_DATE,
             SF.LAST_UPDATED_BY,
             SF.LAST_UPDATE_DATE
        FROM INTF_STP_SALES_FORECAST SF,
             T_PLN_ORDER_PERIOD OP,
             V_BD_SALES_CENTER BSC,
             V_CUSTOMER_ACCOUNT_SALECENTER CAS,
             T_CUSTOMER_HEADER CH,
             T_CUSTOMER_DEPT CD,
             T_BD_ITEM BI
       WHERE SF.SYNC_STATUS = '00'
         AND SF.RESPONSETYPE IS NULL
         AND SF.TRX_NO = P_TRX_NO
         AND OP.BEGIN_DATE <= SF.FORECAST_DATE
         AND OP.END_DATE > = SF.FORECAST_DATE
         AND OP.PERIOD_TYPE = '月'
         AND BSC.SALES_CENTER_CODE = SF.SALES_CENTER_CODE
         AND BSC.ENTITY_ID = SF.ENTITY_ID
         AND CAS.CUSTOMER_CODE = SF.CUSTOMER_CODE
         AND CAS.SALES_CENTER_CODE = SF.SALES_CENTER_CODE
         AND CAS.ACTIVE_FLAG = 'Active'
         AND CAS.ENTITY_ID = SF.ENTITY_ID
         AND CH.CUSTOMER_CODE = SF.CUSTOMER_CODE
         AND CH.ACTIVE_FLAG = 'Active'
         AND CD.CUSTOMER_CODE = CH.CUSTOMER_CODE
         AND CD.DEPT_ID = SF.ENTITY_ID
         AND BI.ITEM_CODE = SF.ITEM_CODE
         AND BI.ACTIVE_FLAG = 'Y'
         AND BI.ENTITY_ID = SF.ENTITY_ID;
         
    SELECT COUNT(*)
      INTO VN_COUNT
      FROM INTF_STP_SALES_FORECAST SF,
           T_PLN_ORDER_PERIOD OP,
           V_BD_SALES_CENTER BSC,
           V_CUSTOMER_ACCOUNT_SALECENTER CAS,
           T_CUSTOMER_HEADER CH,
           T_CUSTOMER_DEPT CD,
           T_BD_ITEM BI
     WHERE SF.SYNC_STATUS = '00'
       AND SF.RESPONSETYPE IS NULL
       AND SF.TRX_NO = P_TRX_NO
       AND OP.BEGIN_DATE <= SF.FORECAST_DATE
       AND OP.END_DATE > = SF.FORECAST_DATE
       AND OP.PERIOD_TYPE = '月'
       AND BSC.SALES_CENTER_CODE = SF.SALES_CENTER_CODE
       AND BSC.ENTITY_ID = SF.ENTITY_ID
       AND CAS.CUSTOMER_CODE = SF.CUSTOMER_CODE
       AND CAS.SALES_CENTER_CODE = SF.SALES_CENTER_CODE
       AND CAS.ACTIVE_FLAG = 'Active'
       AND CAS.ENTITY_ID = SF.ENTITY_ID
       AND CH.CUSTOMER_CODE = SF.CUSTOMER_CODE
       AND CH.ACTIVE_FLAG = 'Active'
       AND CD.CUSTOMER_CODE = CH.CUSTOMER_CODE
       AND CD.DEPT_ID = SF.ENTITY_ID
       AND BI.ITEM_CODE = SF.ITEM_CODE
       AND BI.ACTIVE_FLAG = 'Y'
       AND BI.ENTITY_ID = SF.ENTITY_ID;
       
    IF VN_COUNT = 0 THEN
      P_RESULT := '关联客户或营销中心失败，请检查数据。';
      ROLLBACK;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      --P_RESULT := '插入销售预测业务表失败。' || V_NL || '失败信息：' || SQLERRM;
    --  VS_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_PLN_INTF.P_CREATE_SALES_FORECAST', SQLCODE, '插入销售预测业务表失败。失败信息：' || SQLERRM);
      P_RESULT :='插入销售预测业务表失败 ' || SUBSTR(SQLERRM(SQLCODE), 1, 256) || substr(dbms_utility.format_error_backtrace, 1, 100);
      ROLLBACK;
  END;
  
  ----------------------------------------------------------------------
  -- Author  : fenggq
  -- Created : 2014-01-17 16:18:00
  -- Purpose : 按周送审订单业务表写入申请订单承诺接口表
  ----------------------------------------------------------------------
  PROCEDURE P_CREATE_APPLY_PROMISED(P_ORDER_FLAG     IN NUMBER, --订单标识
                                    P_ORDER_HEAD_ID  IN NUMBER, --订单头ID
                                    P_PROMISED_MODEL IN VARCHAR2, --承诺模式（120：首次承诺或再次承诺；130：完成承诺时把未引入承诺的订单行均引入承诺）
                                    P_USER_CODE      IN VARCHAR2, --登录用户名
                                    P_RESULT         OUT VARCHAR2) IS
                                    
    VN_ENTITY_COUNT   NUMBER;
    VN_MRP_ID_COUNT   NUMBER;
    VN_MRP_CODE_COUNT NUMBER;
    
    --add by fenggq 2015-03-11 校验产品生命周期
    --VN_ITEM_COUNT NUMBER; --生命周期内不能送审产品的数量
    VS_ITEM_LIFE_CYCLE VARCHAR2(10);
    VN_ENTITY_ID INTF_PLN_MONTH_PLAN.ENTITY_ID%TYPE;
    VS_CHECK_RESULT VARCHAR2(4000);
    --end by fenggq
    
    --add by fenggq 2015-03-14 校验临时订单产品在产地是否生产
    VN_ITEM_PA_COUNT NUMBER; --产品产地对应关系数量
    --end by fenggq
    -- add by ccz 
    v_entity_id      number ;
    v_entity_code    varchar2(100);
  BEGIN
    P_RESULT := V_SUCCESS;
    
    Begin
      IF P_ORDER_FLAG = 0 THEN
        Select Oh.Entity_Id
          Into Vn_Entity_Id
          From t_Pln_Order_Head Oh
         Where Oh.Order_Head_Id = p_Order_Head_Id;
      
        --是否校验产品生命周期
        IF VS_ITEM_LIFE_CYCLE != 'N' THEN
          FOR C_PLN_ITEM_LIFE_CYCLE IN (SELECT OL.ENTITY_ID,
                                               OL.ITEM_ID,
                                               OL.PRODUCING_AREA_ID
                                          FROM T_PLN_ORDER_HEAD OH,
                                               T_PLN_ORDER_LINE OL
                                         WHERE OH.ORDER_HEAD_ID =
                                               P_ORDER_HEAD_ID
                                           AND OH.ORDER_HEAD_ID =
                                               OL.ORDER_HEAD_ID
                                           AND OL.CAN_PRODUCE_QTY > 0) LOOP
            VS_CHECK_RESULT := NULL;
            VS_CHECK_RESULT := PKG_PLN_PUB.P_CHK_ITEM_PRDC_LIFE_CYCLE(C_PLN_ITEM_LIFE_CYCLE.ENTITY_ID,
                                                                      C_PLN_ITEM_LIFE_CYCLE.ITEM_ID,
                                                                      C_PLN_ITEM_LIFE_CYCLE.PRODUCING_AREA_ID,
                                                                      PKG_PLN_PUB.V_PHASE_INTF_APS);
            IF VS_CHECK_RESULT != 'Y' THEN
              P_RESULT := P_RESULT || VS_CHECK_RESULT || V_NL;
            END IF;
          END LOOP;
          IF P_RESULT != V_SUCCESS THEN
            P_RESULT := '以下产品在所属生命周期内不能引APS。' || V_NL ||
                        SUBSTR(P_RESULT, 8, LENGTH(P_RESULT) - 8);
            RETURN;
          END IF;
        END IF;
      else
        Select Ch.Entity_Id
          Into Vn_Entity_Id
          From t_Pln_Order_Collect_Head Ch
         Where Ch.Coll_Ord_Head_Id = p_Order_Head_Id;
        --是否校验产品生命周期
        IF VS_ITEM_LIFE_CYCLE != 'N' THEN
          FOR C_PLN_ITEM_LIFE_CYCLE IN (SELECT OL.ENTITY_ID,
                                               OL.ITEM_ID,
                                               OL.PRODUCING_AREA_ID
                                          FROM T_PLN_ORDER_HEAD OH,
                                               T_PLN_ORDER_LINE OL
                                         WHERE OH.ORDER_HEAD_ID =
                                               P_ORDER_HEAD_ID
                                           AND OH.ORDER_HEAD_ID =
                                               OL.ORDER_HEAD_ID
                                           AND OL.CAN_PRODUCE_QTY > 0) LOOP
            VS_CHECK_RESULT := NULL;
            VS_CHECK_RESULT := PKG_PLN_PUB.P_CHK_ITEM_PRDC_LIFE_CYCLE(C_PLN_ITEM_LIFE_CYCLE.ENTITY_ID,
                                                                      C_PLN_ITEM_LIFE_CYCLE.ITEM_ID,
                                                                      C_PLN_ITEM_LIFE_CYCLE.PRODUCING_AREA_ID,
                                                                      PKG_PLN_PUB.V_PHASE_INTF_APS);
            IF VS_CHECK_RESULT != 'Y' THEN
              P_RESULT := P_RESULT || VS_CHECK_RESULT || V_NL;
            END IF;
          END LOOP;
        
          IF P_RESULT != V_SUCCESS THEN
            P_RESULT := '以下产品在所属生命周期内不能引APS。' || V_NL ||
                        SUBSTR(P_RESULT, 8, LENGTH(P_RESULT) - 8);
            RETURN;
          END IF;
        END IF;
      end if;
    End;
    --add by fenggq 2015-03-11 校验产品生命周期
    BEGIN
      VS_ITEM_LIFE_CYCLE := PKG_BD.F_GET_PARAMETER_VALUE('PLN_ITEM_LIFE_CYCLE', VN_ENTITY_ID);
    EXCEPTION
      WHEN OTHERS THEN
        P_RESULT := '获取PLN_ITEM_LIFE_CYCLE参数失败。' || V_NL || SQLERRM;
        RAISE V_BASE_EXCEPTION;
    END;
   
    --end by fenggq
     -- add by ccz 2015-09-24
       begin
         select ue.entity_code_name,ve.entity_id
           into v_entity_code,v_entity_id
           from up_codelist up, up_codelist_entity ue,v_bd_entity ve
          where up.codetype = 'PlnEntityToMainEntity'
            and up.id = ue.codelist_id
            and ue.entity_id = Vn_Entity_Id
            and ve.entity_code=ue.entity_code_name;
       exception
         when no_data_found then
           begin
             Select Entity.Entity_Code,entity.entity_id
               Into v_entity_code,v_entity_id
               From v_Bd_Entity Entity
              Where Entity.Entity_Id =VN_ENTITY_ID;
           exception
             when others then
               p_Result := '获取主体失败' || sqlerrm;
               raise v_Base_Exception;
           end;
         when others then
           p_Result := '获取主体失败,主体快码PlnEntityToMainEntity' || sqlerrm;
           raise v_Base_Exception;
       end;
    --计划订单
    IF P_ORDER_FLAG = 0 THEN
      SELECT COUNT(ENTITY.ENTITY_CODE)
        INTO VN_ENTITY_COUNT
        FROM T_PLN_ORDER_HEAD OH,
             V_BD_ENTITY ENTITY
       WHERE OH.ORDER_HEAD_ID = P_ORDER_HEAD_ID
         AND OH.ENTITY_ID = ENTITY.ENTITY_ID;
         
      IF VN_ENTITY_COUNT = 0 THEN
        P_RESULT := '主体编码不存在，请检查基础数据。';
        RETURN;
      END IF;
      
      FOR C_PLN_ORDER_LINE IN
        (SELECT DISTINCT OL.PRODUCING_AREA_ID
           FROM T_PLN_ORDER_HEAD OH,
                T_PLN_ORDER_LINE OL
          WHERE OH.ORDER_HEAD_ID = P_ORDER_HEAD_ID
            AND OH.ORDER_HEAD_ID = OL.ORDER_HEAD_ID) LOOP
            
        SELECT COUNT(MRP_ORG_ID)
          INTO VN_MRP_ID_COUNT
          FROM T_PLN_PRODUCING_AREA
         WHERE PRODUCING_AREA_ID = C_PLN_ORDER_LINE.PRODUCING_AREA_ID;
         
        IF VN_MRP_ID_COUNT = 0 THEN
          P_RESULT := '库存组织ID不存在，请检查基础数据。';
          RETURN;
        END IF;
        
        SELECT COUNT(MRP_ORG_CODE)
          INTO VN_MRP_CODE_COUNT
          FROM T_PLN_PRODUCING_AREA
         WHERE PRODUCING_AREA_ID = C_PLN_ORDER_LINE.PRODUCING_AREA_ID;
         
        IF VN_MRP_CODE_COUNT = 0 THEN
          P_RESULT := '库存组织编码不存在，请检查基础数据。';
          RETURN;
        END IF;
        
      END LOOP;
      
      --add by fenggq 2015-03-14 校验临时订单产品在产地是否生产
      FOR C_PLN_TEMP_ORDER IN
        (SELECT OH.ENTITY_ID, OL.ITEM_CODE, OL.PRODUCING_AREA_CODE
           FROM T_PLN_ORDER_HEAD OH,
                T_PLN_ORDER_LINE OL
          WHERE OH.ORDER_HEAD_ID = P_ORDER_HEAD_ID
            AND OH.ORDER_HEAD_ID = OL.ORDER_HEAD_ID) LOOP
            
        SELECT COUNT(*)
          INTO VN_ITEM_PA_COUNT
          FROM T_PLN_ITEM_PRODUCING_AREA IPA
         WHERE IPA.ENTITY_ID = C_PLN_TEMP_ORDER.ENTITY_ID
           AND IPA.ITEM_CODE = C_PLN_TEMP_ORDER.ITEM_CODE
           AND IPA.PRODUCING_AREA_CODE = C_PLN_TEMP_ORDER.PRODUCING_AREA_CODE;
        
        IF VN_ITEM_PA_COUNT = 0 THEN
          P_RESULT := '产品：' || C_PLN_TEMP_ORDER.ITEM_CODE || '与产地：' || C_PLN_TEMP_ORDER.PRODUCING_AREA_CODE || '对应关系不存在。';
          RETURN;
        END IF;
      END LOOP;
      --end by fenggq 
      INSERT INTO INTF_PLN_APPLY_PROMISED
        (APPLY_PROMISED_ID,
         ENTITY_ID,
         ENTITY_CODE,
         MRP_ORG_ID,
         MRP_ORG_CODE,
         ITEM_CODE,
         ITEM_UOM,
         ORDER_NUMBER,
         ORDER_TYPE,
         ORDER_HEAD_ID,
         ORDER_LINE_ID,
         ORDER_DETAIL_ID,
         PROMISED_MODEL,
         REQUIRED_DELIVER_DATE,
         PRODUCING_QTY,
         ORDER_CREATION_DATE,
         CUSTOMER_CODE,
         LCL_SHIPMENT_SET,
         CREATED_BY,
         CREATION_DATE,
         LAST_UPDATED_BY,
         LAST_UPDATE_DATE,
         INTF_STATUS)
        SELECT S_INTF_PLN_APPLY_PROMISED.NEXTVAL,
               --OH.ENTITY_ID,
               --ENTITY.ENTITY_CODE,
               -- add by ccz 2015-09-25
               v_entity_id,
               v_entity_code,
               Nvl((Select Io.Organization_ID
                From t_Inv_Producting_Item Ipi,
                     t_Pln_Producing_Area  Ppa,
                     t_Inv_Organization    Io
               Where Ppa.Producing_Area_Id = Ipi.Po_Area_Id
                 And Ppa.Entity_Id = Io.Entity_Id
                 And Ppa.Mrp_Org_Id = Io.Organization_Id
                 And ipi.item_code =Ol.Item_Code --itemCode
                 And ipi.entity_id =Ol.entity_id --entityId
                 And ipi.po_area_id =Ol.producing_area_id ),PA.Mrp_Org_ID),
                 Nvl((Select Io.Organization_Code
                From t_Inv_Producting_Item Ipi,
                     t_Pln_Producing_Area  Ppa,
                     t_Inv_Organization    Io
               Where Ppa.Producing_Area_Id = Ipi.Po_Area_Id
                 And Ppa.Entity_Id = Io.Entity_Id
                 And Ppa.Mrp_Org_Id = Io.Organization_Id
                 And ipi.item_code =Ol.Item_Code --itemCode
                 And ipi.entity_id =Ol.entity_id --entityId
                 And ipi.po_area_id =Ol.producing_area_id ),PA.Mrp_Org_Code),
             --  PA.MRP_ORG_ID,
            --   PA.MRP_ORG_CODE,
               OL.ITEM_CODE,
               OL.ITEM_UOM,
               OH.ORDER_NUMBER,
               OH.ORDER_TYPE_CODE,
               OH.ORDER_HEAD_ID,
               OL.ORDER_LINE_ID,
               0,
               DECODE(OL.APS_FLAG, 'N', '110', 'R', '120'),
               OL.CAN_SUPPLY_DATE, --?
               OL.CAN_PRODUCE_QTY,
               OL.CREATION_DATE,
               OH.CUSTOMER_CODE,
               OL.ORDER_LINE_ID,
               P_USER_CODE,
               SYSDATE,
               P_USER_CODE,
               SYSDATE,
               'N'
          FROM T_PLN_ORDER_HEAD OH,
               T_PLN_ORDER_LINE OL,
            --   V_BD_ENTITY ENTITY,
               T_PLN_PRODUCING_AREA PA
         WHERE OH.ORDER_HEAD_ID = P_ORDER_HEAD_ID
           AND OH.ORDER_HEAD_ID = OL.ORDER_HEAD_ID
       --    AND OH.ENTITY_ID = ENTITY.ENTITY_ID
           --20170715 hejy3 完成承诺时把未引入的订单行都做引入
           --AND OL.APS_FLAG IN ('N', 'R')
           AND ((P_PROMISED_MODEL = '130' AND OL.APS_FLAG = 'N') OR (NVL(P_PROMISED_MODEL, '120') <> '130' AND OL.APS_FLAG IN ('N', 'R')))
           AND OL.PRODUCING_AREA_ID = PA.PRODUCING_AREA_ID
           AND OL.CAN_PRODUCE_QTY > 0;
           
      UPDATE T_PLN_ORDER_LINE
         SET APS_FLAG = 'P'
       WHERE ORDER_LINE_ID IN
             (SELECT OL.ORDER_LINE_ID
                FROM T_PLN_ORDER_HEAD OH, T_PLN_ORDER_LINE OL
               WHERE OH.ORDER_HEAD_ID = P_ORDER_HEAD_ID
                 AND OH.ORDER_HEAD_ID = OL.ORDER_HEAD_ID)
         AND APS_FLAG IN ('N', 'R');
    --汇总订单
    ELSE
      FOR C_PLN_ORDER_LINE_INFO IN
        (SELECT OCR.ORDER_LINE_ID, OL.ENTITY_ID, OL.PRODUCING_AREA_ID
           FROM T_PLN_ORDER_COLLECT_RELATION OCR,
                T_PLN_ORDER_LINE OL
          WHERE OCR.ORDER_COLLECT_HEAD_ID = P_ORDER_HEAD_ID
            AND OCR.ORDER_LINE_ID = OL.ORDER_LINE_ID) LOOP
          
        SELECT COUNT(ENTITY_CODE)
          INTO VN_ENTITY_COUNT
          FROM V_BD_ENTITY
         WHERE ENTITY_ID = C_PLN_ORDER_LINE_INFO.ENTITY_ID;
         
        IF VN_ENTITY_COUNT = 0 THEN
          P_RESULT := '订单行号：' || C_PLN_ORDER_LINE_INFO.ORDER_LINE_ID || '，主体编码不存在，请检查基础数据。';
          RETURN;
        END IF;
        
        SELECT COUNT(MRP_ORG_ID)
          INTO VN_MRP_ID_COUNT
          FROM T_PLN_PRODUCING_AREA
         WHERE PRODUCING_AREA_ID = C_PLN_ORDER_LINE_INFO.PRODUCING_AREA_ID;
         
        IF VN_MRP_ID_COUNT = 0 THEN
          P_RESULT := '订单行号：' || C_PLN_ORDER_LINE_INFO.ORDER_LINE_ID || '，库存组织ID不存在，请检查基础数据。';
          RETURN;
        END IF;
        
        SELECT COUNT(MRP_ORG_CODE)
          INTO VN_MRP_CODE_COUNT
          FROM T_PLN_PRODUCING_AREA
         WHERE PRODUCING_AREA_ID = C_PLN_ORDER_LINE_INFO.PRODUCING_AREA_ID;
         
        IF VN_MRP_CODE_COUNT = 0 THEN
          P_RESULT := '订单行号：' || C_PLN_ORDER_LINE_INFO.ORDER_LINE_ID || '，库存组织编码不存在，请检查基础数据。';
          RETURN;
        END IF;
        INSERT INTO INTF_PLN_APPLY_PROMISED
          (APPLY_PROMISED_ID,
           ENTITY_ID,
           ENTITY_CODE,
           MRP_ORG_ID,
           MRP_ORG_CODE,
           ITEM_CODE,
           ITEM_UOM,
           ORDER_NUMBER,
           ORDER_TYPE,
           ORDER_HEAD_ID,
           ORDER_LINE_ID,
           ORDER_DETAIL_ID,
           PROMISED_MODEL,
           REQUIRED_DELIVER_DATE,
           PRODUCING_QTY,
           ORDER_CREATION_DATE,
           CUSTOMER_CODE,
           LCL_SHIPMENT_SET,
           CREATED_BY,
           CREATION_DATE,
           LAST_UPDATED_BY,
           LAST_UPDATE_DATE,
           INTF_STATUS)
          SELECT S_INTF_PLN_APPLY_PROMISED.NEXTVAL,
                -- OH.ENTITY_ID,
                -- ENTITY.ENTITY_CODE,
                 v_entity_id,
                 v_entity_code,
                 PA.MRP_ORG_ID,
                 PA.MRP_ORG_CODE,
                 OL.ITEM_CODE,
                 OL.ITEM_UOM,
                 OH.ORDER_NUMBER,
                 OH.ORDER_TYPE_CODE,
                 OH.ORDER_HEAD_ID,
                 OL.ORDER_LINE_ID,
                 0,
                 DECODE(OL.APS_FLAG, 'N', '110', 'R', '120'),
                 OL.CAN_SUPPLY_DATE, --?
                 OL.CAN_PRODUCE_QTY,
                 OL.CREATION_DATE,
                 OH.CUSTOMER_CODE,
                 OL.ORDER_LINE_ID,
                 P_USER_CODE,
                 SYSDATE,
                 P_USER_CODE,
                 SYSDATE,
                 'N'
            FROM T_PLN_ORDER_HEAD OH,
                 T_PLN_ORDER_LINE OL,
              --   V_BD_ENTITY ENTITY,
                 T_PLN_PRODUCING_AREA PA
           WHERE OL.ORDER_LINE_ID = C_PLN_ORDER_LINE_INFO.ORDER_LINE_ID
             AND OH.ORDER_HEAD_ID = OL.ORDER_HEAD_ID
          --   AND OL.ENTITY_ID = ENTITY.ENTITY_ID
             --20170715 hejy3 完成承诺时把未引入的订单行都做引入
             --AND OL.APS_FLAG IN ('N', 'R')
             AND ((P_PROMISED_MODEL = '130' AND OL.APS_FLAG = 'N') OR (NVL(P_PROMISED_MODEL, '120') <> '130' AND OL.APS_FLAG IN ('N', 'R')))
             AND OL.PRODUCING_AREA_ID = PA.PRODUCING_AREA_ID
             AND OL.CAN_PRODUCE_QTY > 0;
             
        UPDATE T_PLN_ORDER_LINE
           SET APS_FLAG = 'P'
         WHERE ORDER_LINE_ID = C_PLN_ORDER_LINE_INFO.ORDER_LINE_ID
           AND APS_FLAG IN ('N', 'R');
      END LOOP;
    END IF;
    
  EXCEPTION
    WHEN V_BASE_EXCEPTION THEN
      P_RESULT := '异常过程：PKG_PLN_INTF.P_CREATE_APPLY_PROMISED' || V_NL || P_RESULT;
      ROLLBACK;
    WHEN OTHERS THEN
      P_RESULT := '插入申请订单承诺接口表失败。' || V_NL || '失败信息：' || SQLERRM;
      ROLLBACK;
  END;
  
  ----------------------------------------------------------------------
  -- Author  : fenggq
  -- Created : 2014-01-22 20:24:00
  -- Purpose : 订单承诺更新订单行
  ----------------------------------------------------------------------
  PROCEDURE P_UPDATE_ORDER_LINE(P_PROMISED_ID IN NUMBER, --申请订单承诺ID
                                P_RESULT      OUT VARCHAR2) IS
                                
    VN_ORDER_LINE_ID      INTF_PLN_ORDER_PROMISED.ORDER_LINE_ID%TYPE;
    VN_PRODUCING_QTY      INTF_PLN_ORDER_PROMISED.PRODUCING_QTY%TYPE;
    VS_A_RESPONSE_TYPE    INTF_PLN_ORDER_PROMISED.A_RESPONSE_TYPE%TYPE;
    VS_A_RESPNOSE_CODE    INTF_PLN_ORDER_PROMISED.A_RESPNOSE_CODE%TYPE;
    VS_A_RESPONSE_MESSAGE INTF_PLN_ORDER_PROMISED.A_RESPONSE_MESSAGE%TYPE;
    VN_A_PRODUCING_QTY    INTF_PLN_APPLY_PROMISED.PRODUCING_QTY%TYPE;
    --新增订单承诺时间写到行上2015/5/27
    V_PROMISE_TIME        Intf_Pln_Order_Promised.Required_Deliver_Date%TYPE;
    --hejy3 增加订单承诺日期（带清尾）
    V_PROMISE_TIME_BY_MANTISSA INTF_PLN_ORDER_PROMISED.PROMISE_DATE_BY_MANTISSA%TYPE;
    
  BEGIN
    P_RESULT := V_SUCCESS;
    
    SELECT ORDER_LINE_ID,
           PRODUCING_QTY,
           A_RESPONSE_TYPE,
           A_RESPNOSE_CODE,
           A_RESPONSE_MESSAGE,
           Required_Deliver_Date,
           PROMISE_DATE_BY_MANTISSA --hejy3 增加订单承诺日期（带清尾）
      INTO VN_ORDER_LINE_ID,
           VN_PRODUCING_QTY,
           VS_A_RESPONSE_TYPE,
           VS_A_RESPNOSE_CODE,
           VS_A_RESPONSE_MESSAGE,
           V_PROMISE_TIME,
           V_PROMISE_TIME_BY_MANTISSA --hejy3 增加订单承诺日期（带清尾）
      FROM INTF_PLN_ORDER_PROMISED
     WHERE PROMISED_ID = P_PROMISED_ID
       AND SYNC_STATUS = '00'
       AND RESPONSETYPE IS NULL;
       
    SELECT PRODUCING_QTY
      INTO VN_A_PRODUCING_QTY
      FROM INTF_PLN_APPLY_PROMISED
     WHERE APPLY_PROMISED_ID = P_PROMISED_ID;
     
    IF VS_A_RESPONSE_TYPE = 'N' THEN
      IF VN_A_PRODUCING_QTY < VN_PRODUCING_QTY THEN
        UPDATE T_PLN_ORDER_LINE 
           SET APS_BACK_QTY = VN_PRODUCING_QTY,
               APS_FLAG = 'R',
               APS_PROMISE_TIME=V_PROMISE_TIME,
               PROMISE_DATE_BY_MANTISSA = V_PROMISE_TIME_BY_MANTISSA --hejy3 增加订单承诺日期（带清尾）
         WHERE ORDER_LINE_ID = VN_ORDER_LINE_ID
           AND APS_FLAG = 'P';
      ELSE
        UPDATE T_PLN_ORDER_LINE
           SET APS_BACK_QTY = VN_PRODUCING_QTY,
               APS_FLAG = 'S',
               APS_PROMISE_TIME=V_PROMISE_TIME,
               PROMISE_DATE_BY_MANTISSA = V_PROMISE_TIME_BY_MANTISSA --hejy3 增加订单承诺日期（带清尾）
         WHERE ORDER_LINE_ID = VN_ORDER_LINE_ID
           AND APS_FLAG = 'P';
      END IF;
    ELSE
      UPDATE INTF_PLN_APPLY_PROMISED
         SET INTF_STATUS = VS_A_RESPONSE_TYPE,
             ERROR_FLAG = VS_A_RESPNOSE_CODE,
             ERROR_MSG = VS_A_RESPONSE_MESSAGE
       WHERE ORDER_LINE_ID = VN_ORDER_LINE_ID
         AND APPLY_PROMISED_ID = P_PROMISED_ID;
    END IF;
    
  EXCEPTION
    WHEN OTHERS THEN
      P_RESULT := '更新订单行失败。' || V_NL || '失败信息：' || SQLERRM;
      ROLLBACK;
  END;
  
  ----------------------------------------------------------------------
  -- Author  : fenggq
  -- Created : 2015-03-20 15:15:00
  -- Purpose : 销售任务横表转换纵表
  ----------------------------------------------------------------------
  PROCEDURE P_ST_CHANGE_ST_STATISTICS(P_ORDER_TYPE_ID     IN NUMBER,   --订单类型ID
                                      P_PERIOD_ID         IN NUMBER,   --订单周期
                                      P_SALES_MAIN_TYPE   IN VARCHAR2, --营销大类
                                      P_ENTITY_ID         IN NUMBER,   --主体ID
                                      P_CREATED_BY        IN VARCHAR2, --创建人
                                      P_RESULT            OUT VARCHAR2) IS

    VS_PERIOD_CODE VARCHAR2(20);

  BEGIN
    P_RESULT := V_SUCCESS;
    DELETE FROM T_STP_ST_STATISTICS_INTF
     WHERE TASK_NAME = P_ORDER_TYPE_ID
       AND SALES_MAIN_TYPE = P_SALES_MAIN_TYPE;
    
    SELECT PERIOD_CODE
      INTO VS_PERIOD_CODE
      FROM T_PLN_ORDER_PERIOD
     WHERE PERIOD_ID = P_PERIOD_ID;
    VS_PERIOD_CODE := SUBSTR(VS_PERIOD_CODE, 1, 4);
    
    FOR C_STP_ST_STATISTICS IN (SELECT STL.SALES_CENTER_CODE,
                                       STL.SALES_CENTER_NAME,
                                       STL.JAN_TASK_QTY,
                                       STL.JAN_TASK_AMOUNT,
                                       STL.FEB_TASK_QTY,
                                       STL.FEB_TASK_AMOUNT,
                                       STL.MAR_TASK_QTY,
                                       STL.MAR_TASK_AMOUNT,
                                       STL.APR_TASK_QTY,
                                       STL.APR_TASK_AMOUNT,
                                       STL.MAY_TASK_QTY,
                                       STL.MAY_TASK_AMOUNT,
                                       STL.JUN_TASK_QTY,
                                       STL.JUN_TASK_AMOUNT,
                                       STL.JUL_TASK_QTY,
                                       STL.JUL_TASK_AMOUNT,
                                       STL.AUG_TASK_QTY,
                                       STL.AUG_TASK_AMOUNT,
                                       STL.SEP_TASK_QTY,
                                       STL.SEP_TASK_AMOUNT,
                                       STL.OCT_TASK_QTY,
                                       STL.OCT_TASK_AMOUNT,
                                       STL.NOV_TASK_QTY,
                                       STL.NOV_TASK_AMOUNT,
                                       STL.DEC_TASK_QTY,
                                       STL.DEC_TASK_AMOUNT
                                  FROM T_STP_YEAR_SALES_TASK_HEAD STH,
                                       T_STP_YEAR_SALES_TASK_LINES STL
                                 WHERE STH.TASK_NAME = P_ORDER_TYPE_ID
                                   AND STH.TASK_PERIOD = P_PERIOD_ID
                                   AND STH.TASK_STATUS = '04'
                                   AND STH.VER_SEQUENCE =
                                       (SELECT MAX(STH.VER_SEQUENCE)
                                          FROM T_STP_YEAR_SALES_TASK_HEAD STH,
                                               T_STP_YEAR_SALES_TASK_LINES STL
                                         WHERE STH.TASK_NAME = P_ORDER_TYPE_ID
                                           AND STH.TASK_PERIOD = P_PERIOD_ID
                                           AND STH.TASK_STATUS = '04'
                                           AND STH.SALES_MAIN_TYPE = P_SALES_MAIN_TYPE
                                           AND STH.YEAR_SALES_TASK_HEAD_ID = STL.YEAR_SALES_TASK_HEAD_ID)
                                   AND STH.SALES_MAIN_TYPE = P_SALES_MAIN_TYPE
                                   AND STH.YEAR_SALES_TASK_HEAD_ID = STL.YEAR_SALES_TASK_HEAD_ID) LOOP
      --1月
      INSERT INTO T_STP_ST_STATISTICS_INTF
        (ST_STATISTICS_INTF_ID,
         ENTITY_ID,
         TASK_NAME,
         TASK_DATE,
         SALES_MAIN_TYPE,
         SALES_CENTER_CODE,
         SALES_CENTER_NAME,
         TASK_QTY,
         TASK_AMOUNT,
         CREATED_BY,
         CREATION_DATE,
         LAST_UPDATED_BY,
         LAST_UPDATE_DATE)
        VALUES(S_STP_ST_STATISTICS_INTF.NEXTVAL,
               P_ENTITY_ID,
               P_ORDER_TYPE_ID,
               TO_DATE(VS_PERIOD_CODE || '0131', 'YYYY/MM/DD'),
               P_SALES_MAIN_TYPE,
               C_STP_ST_STATISTICS.SALES_CENTER_CODE,
               C_STP_ST_STATISTICS.SALES_CENTER_NAME,
               NVL(C_STP_ST_STATISTICS.JAN_TASK_QTY, 0),
               NVL(C_STP_ST_STATISTICS.JAN_TASK_AMOUNT, 0),
               P_CREATED_BY,
               SYSDATE,
               P_CREATED_BY,
               SYSDATE);
      --2月
      INSERT INTO T_STP_ST_STATISTICS_INTF
        (ST_STATISTICS_INTF_ID,
         ENTITY_ID,
         TASK_NAME,
         TASK_DATE,
         SALES_MAIN_TYPE,
         SALES_CENTER_CODE,
         SALES_CENTER_NAME,
         TASK_QTY,
         TASK_AMOUNT,
         CREATED_BY,
         CREATION_DATE,
         LAST_UPDATED_BY,
         LAST_UPDATE_DATE)
        VALUES(S_STP_ST_STATISTICS_INTF.NEXTVAL,
               P_ENTITY_ID,
               P_ORDER_TYPE_ID,
               TO_DATE(VS_PERIOD_CODE || '0228', 'YYYY/MM/DD'),
               P_SALES_MAIN_TYPE,
               C_STP_ST_STATISTICS.SALES_CENTER_CODE,
               C_STP_ST_STATISTICS.SALES_CENTER_NAME,
               NVL(C_STP_ST_STATISTICS.FEB_TASK_QTY, 0),
               NVL(C_STP_ST_STATISTICS.FEB_TASK_AMOUNT, 0),
               P_CREATED_BY,
               SYSDATE,
               P_CREATED_BY,
               SYSDATE);
      --3月
      INSERT INTO T_STP_ST_STATISTICS_INTF
        (ST_STATISTICS_INTF_ID,
         ENTITY_ID,
         TASK_NAME,
         TASK_DATE,
         SALES_MAIN_TYPE,
         SALES_CENTER_CODE,
         SALES_CENTER_NAME,
         TASK_QTY,
         TASK_AMOUNT,
         CREATED_BY,
         CREATION_DATE,
         LAST_UPDATED_BY,
         LAST_UPDATE_DATE)
        VALUES(S_STP_ST_STATISTICS_INTF.NEXTVAL,
               P_ENTITY_ID,
               P_ORDER_TYPE_ID,
               TO_DATE(VS_PERIOD_CODE || '0331', 'YYYY/MM/DD'),
               P_SALES_MAIN_TYPE,
               C_STP_ST_STATISTICS.SALES_CENTER_CODE,
               C_STP_ST_STATISTICS.SALES_CENTER_NAME,
               NVL(C_STP_ST_STATISTICS.MAR_TASK_QTY, 0),
               NVL(C_STP_ST_STATISTICS.MAR_TASK_AMOUNT, 0),
               P_CREATED_BY,
               SYSDATE,
               P_CREATED_BY,
               SYSDATE);
      --4月
      INSERT INTO T_STP_ST_STATISTICS_INTF
        (ST_STATISTICS_INTF_ID,
         ENTITY_ID,
         TASK_NAME,
         TASK_DATE,
         SALES_MAIN_TYPE,
         SALES_CENTER_CODE,
         SALES_CENTER_NAME,
         TASK_QTY,
         TASK_AMOUNT,
         CREATED_BY,
         CREATION_DATE,
         LAST_UPDATED_BY,
         LAST_UPDATE_DATE)
        VALUES(S_STP_ST_STATISTICS_INTF.NEXTVAL,
               P_ENTITY_ID,
               P_ORDER_TYPE_ID,
               TO_DATE(VS_PERIOD_CODE || '0430', 'YYYY/MM/DD'),
               P_SALES_MAIN_TYPE,
               C_STP_ST_STATISTICS.SALES_CENTER_CODE,
               C_STP_ST_STATISTICS.SALES_CENTER_NAME,
               NVL(C_STP_ST_STATISTICS.APR_TASK_QTY, 0),
               NVL(C_STP_ST_STATISTICS.APR_TASK_AMOUNT, 0),
               P_CREATED_BY,
               SYSDATE,
               P_CREATED_BY,
               SYSDATE);
      --5月
      INSERT INTO T_STP_ST_STATISTICS_INTF
        (ST_STATISTICS_INTF_ID,
         ENTITY_ID,
         TASK_NAME,
         TASK_DATE,
         SALES_MAIN_TYPE,
         SALES_CENTER_CODE,
         SALES_CENTER_NAME,
         TASK_QTY,
         TASK_AMOUNT,
         CREATED_BY,
         CREATION_DATE,
         LAST_UPDATED_BY,
         LAST_UPDATE_DATE)
        VALUES(S_STP_ST_STATISTICS_INTF.NEXTVAL,
               P_ENTITY_ID,
               P_ORDER_TYPE_ID,
               TO_DATE(VS_PERIOD_CODE || '0531', 'YYYY/MM/DD'),
               P_SALES_MAIN_TYPE,
               C_STP_ST_STATISTICS.SALES_CENTER_CODE,
               C_STP_ST_STATISTICS.SALES_CENTER_NAME,
               NVL(C_STP_ST_STATISTICS.MAY_TASK_QTY, 0),
               NVL(C_STP_ST_STATISTICS.MAY_TASK_AMOUNT, 0),
               P_CREATED_BY,
               SYSDATE,
               P_CREATED_BY,
               SYSDATE);
      --6月
      INSERT INTO T_STP_ST_STATISTICS_INTF
        (ST_STATISTICS_INTF_ID,
         ENTITY_ID,
         TASK_NAME,
         TASK_DATE,
         SALES_MAIN_TYPE,
         SALES_CENTER_CODE,
         SALES_CENTER_NAME,
         TASK_QTY,
         TASK_AMOUNT,
         CREATED_BY,
         CREATION_DATE,
         LAST_UPDATED_BY,
         LAST_UPDATE_DATE)
        VALUES(S_STP_ST_STATISTICS_INTF.NEXTVAL,
               P_ENTITY_ID,
               P_ORDER_TYPE_ID,
               TO_DATE(VS_PERIOD_CODE || '0630', 'YYYY/MM/DD'),
               P_SALES_MAIN_TYPE,
               C_STP_ST_STATISTICS.SALES_CENTER_CODE,
               C_STP_ST_STATISTICS.SALES_CENTER_NAME,
               NVL(C_STP_ST_STATISTICS.JUN_TASK_QTY, 0),
               NVL(C_STP_ST_STATISTICS.JUN_TASK_AMOUNT, 0),
               P_CREATED_BY,
               SYSDATE,
               P_CREATED_BY,
               SYSDATE);
      --7月
      INSERT INTO T_STP_ST_STATISTICS_INTF
        (ST_STATISTICS_INTF_ID,
         ENTITY_ID,
         TASK_NAME,
         TASK_DATE,
         SALES_MAIN_TYPE,
         SALES_CENTER_CODE,
         SALES_CENTER_NAME,
         TASK_QTY,
         TASK_AMOUNT,
         CREATED_BY,
         CREATION_DATE,
         LAST_UPDATED_BY,
         LAST_UPDATE_DATE)
        VALUES(S_STP_ST_STATISTICS_INTF.NEXTVAL,
               P_ENTITY_ID,
               P_ORDER_TYPE_ID,
               TO_DATE(VS_PERIOD_CODE || '0731', 'YYYY/MM/DD'),
               P_SALES_MAIN_TYPE,
               C_STP_ST_STATISTICS.SALES_CENTER_CODE,
               C_STP_ST_STATISTICS.SALES_CENTER_NAME,
               NVL(C_STP_ST_STATISTICS.JUL_TASK_QTY, 0),
               NVL(C_STP_ST_STATISTICS.JUL_TASK_AMOUNT, 0),
               P_CREATED_BY,
               SYSDATE,
               P_CREATED_BY,
               SYSDATE);
      --8月
      INSERT INTO T_STP_ST_STATISTICS_INTF
        (ST_STATISTICS_INTF_ID,
         ENTITY_ID,
         TASK_NAME,
         TASK_DATE,
         SALES_MAIN_TYPE,
         SALES_CENTER_CODE,
         SALES_CENTER_NAME,
         TASK_QTY,
         TASK_AMOUNT,
         CREATED_BY,
         CREATION_DATE,
         LAST_UPDATED_BY,
         LAST_UPDATE_DATE)
        VALUES(S_STP_ST_STATISTICS_INTF.NEXTVAL,
               P_ENTITY_ID,
               P_ORDER_TYPE_ID,
               TO_DATE(VS_PERIOD_CODE || '0831', 'YYYY/MM/DD'),
               P_SALES_MAIN_TYPE,
               C_STP_ST_STATISTICS.SALES_CENTER_CODE,
               C_STP_ST_STATISTICS.SALES_CENTER_NAME,
               NVL(C_STP_ST_STATISTICS.AUG_TASK_QTY, 0),
               NVL(C_STP_ST_STATISTICS.AUG_TASK_AMOUNT, 0),
               P_CREATED_BY,
               SYSDATE,
               P_CREATED_BY,
               SYSDATE);
      --9月
      INSERT INTO T_STP_ST_STATISTICS_INTF
        (ST_STATISTICS_INTF_ID,
         ENTITY_ID,
         TASK_NAME,
         TASK_DATE,
         SALES_MAIN_TYPE,
         SALES_CENTER_CODE,
         SALES_CENTER_NAME,
         TASK_QTY,
         TASK_AMOUNT,
         CREATED_BY,
         CREATION_DATE,
         LAST_UPDATED_BY,
         LAST_UPDATE_DATE)
        VALUES(S_STP_ST_STATISTICS_INTF.NEXTVAL,
               P_ENTITY_ID,
               P_ORDER_TYPE_ID,
               TO_DATE(VS_PERIOD_CODE || '0930', 'YYYY/MM/DD'),
               P_SALES_MAIN_TYPE,
               C_STP_ST_STATISTICS.SALES_CENTER_CODE,
               C_STP_ST_STATISTICS.SALES_CENTER_NAME,
               NVL(C_STP_ST_STATISTICS.SEP_TASK_QTY, 0),
               NVL(C_STP_ST_STATISTICS.SEP_TASK_AMOUNT, 0),
               P_CREATED_BY,
               SYSDATE,
               P_CREATED_BY,
               SYSDATE);
      --10月
      INSERT INTO T_STP_ST_STATISTICS_INTF
        (ST_STATISTICS_INTF_ID,
         ENTITY_ID,
         TASK_NAME,
         TASK_DATE,
         SALES_MAIN_TYPE,
         SALES_CENTER_CODE,
         SALES_CENTER_NAME,
         TASK_QTY,
         TASK_AMOUNT,
         CREATED_BY,
         CREATION_DATE,
         LAST_UPDATED_BY,
         LAST_UPDATE_DATE)
        VALUES(S_STP_ST_STATISTICS_INTF.NEXTVAL,
               P_ENTITY_ID,
               P_ORDER_TYPE_ID,
               TO_DATE(VS_PERIOD_CODE || '1031', 'YYYY/MM/DD'),
               P_SALES_MAIN_TYPE,
               C_STP_ST_STATISTICS.SALES_CENTER_CODE,
               C_STP_ST_STATISTICS.SALES_CENTER_NAME,
               NVL(C_STP_ST_STATISTICS.OCT_TASK_QTY, 0),
               NVL(C_STP_ST_STATISTICS.OCT_TASK_AMOUNT, 0),
               P_CREATED_BY,
               SYSDATE,
               P_CREATED_BY,
               SYSDATE);
      --11月
      INSERT INTO T_STP_ST_STATISTICS_INTF
        (ST_STATISTICS_INTF_ID,
         ENTITY_ID,
         TASK_NAME,
         TASK_DATE,
         SALES_MAIN_TYPE,
         SALES_CENTER_CODE,
         SALES_CENTER_NAME,
         TASK_QTY,
         TASK_AMOUNT,
         CREATED_BY,
         CREATION_DATE,
         LAST_UPDATED_BY,
         LAST_UPDATE_DATE)
        VALUES(S_STP_ST_STATISTICS_INTF.NEXTVAL,
               P_ENTITY_ID,
               P_ORDER_TYPE_ID,
               TO_DATE(VS_PERIOD_CODE || '1130', 'YYYY/MM/DD'),
               P_SALES_MAIN_TYPE,
               C_STP_ST_STATISTICS.SALES_CENTER_CODE,
               C_STP_ST_STATISTICS.SALES_CENTER_NAME,
               NVL(C_STP_ST_STATISTICS.NOV_TASK_QTY, 0),
               NVL(C_STP_ST_STATISTICS.NOV_TASK_AMOUNT, 0),
               P_CREATED_BY,
               SYSDATE,
               P_CREATED_BY,
               SYSDATE);
      --12月
      INSERT INTO T_STP_ST_STATISTICS_INTF
        (ST_STATISTICS_INTF_ID,
         ENTITY_ID,
         TASK_NAME,
         TASK_DATE,
         SALES_MAIN_TYPE,
         SALES_CENTER_CODE,
         SALES_CENTER_NAME,
         TASK_QTY,
         TASK_AMOUNT,
         CREATED_BY,
         CREATION_DATE,
         LAST_UPDATED_BY,
         LAST_UPDATE_DATE)
        VALUES(S_STP_ST_STATISTICS_INTF.NEXTVAL,
               P_ENTITY_ID,
               P_ORDER_TYPE_ID,
               TO_DATE(VS_PERIOD_CODE || '1231', 'YYYY/MM/DD'),
               P_SALES_MAIN_TYPE,
               C_STP_ST_STATISTICS.SALES_CENTER_CODE,
               C_STP_ST_STATISTICS.SALES_CENTER_NAME,
               NVL(C_STP_ST_STATISTICS.DEC_TASK_QTY, 0),
               NVL(C_STP_ST_STATISTICS.DEC_TASK_AMOUNT, 0),
               P_CREATED_BY,
               SYSDATE,
               P_CREATED_BY,
               SYSDATE);
    END LOOP;

  EXCEPTION
    WHEN OTHERS THEN
      P_RESULT := '销售任务横表转换纵表失败。' || V_NL || '失败信息：' || SQLERRM;
      ROLLBACK;
  END;
  
  ----------------------------------------------------------------------
  -- Author  : fenggq
  -- Created : 2014-04-10 09:58:00
  -- Purpose : 校验订单承诺产品生命周期
  ----------------------------------------------------------------------
  PROCEDURE P_CHECK_ITEM_LIFE_CYCLE(P_ORDER_FLAG     IN NUMBER, --订单标识
                                    P_ORDER_HEAD_ID  IN NUMBER, --订单头ID
                                    P_ENTITY_ID      IN NUMBER, --主体ID
                                    P_RESULT         OUT VARCHAR2) IS
                                    
    VN_ITEM_COUNT NUMBER; --生命周期内不能送审产品的数量
    VS_ITEM_LIFE_CYCLE VARCHAR2(10);
    
    --add by fenggq 2015-03-14 校验临时订单产品在产地是否生产
    --VN_ITEM_PA_COUNT NUMBER; --产品产地对应关系数量
    VS_CHECK_RESULT VARCHAR2(4000);
    --end by fenggq
    
  BEGIN
    P_RESULT := V_SUCCESS;
    
    BEGIN
      VS_ITEM_LIFE_CYCLE := PKG_BD.F_GET_PARAMETER_VALUE('PLN_ITEM_LIFE_CYCLE', P_ENTITY_ID);
    EXCEPTION
      WHEN OTHERS THEN
        P_RESULT := '获取PLN_ITEM_LIFE_CYCLE参数失败。' || V_NL || SQLERRM;
        RAISE V_BASE_EXCEPTION;
    END;
    
    VN_ITEM_COUNT := 0;
    
    --是否校验产品生命周期
    IF VS_ITEM_LIFE_CYCLE != 'N' THEN
      --计划订单
      IF P_ORDER_FLAG = 0 THEN
        FOR C_PLN_ITEM_LIFE_CYCLE IN
          (SELECT OL.ENTITY_ID,
                  OL.ITEM_ID,
                  OL.PRODUCING_AREA_ID
             FROM T_PLN_ORDER_HEAD          OH,
                  T_PLN_ORDER_LINE          OL
            WHERE OH.ORDER_HEAD_ID = P_ORDER_HEAD_ID
              AND OH.ORDER_HEAD_ID = OL.ORDER_HEAD_ID
              AND OL.CAN_PRODUCE_QTY > 0) LOOP
          VS_CHECK_RESULT := NULL;
          VS_CHECK_RESULT := PKG_PLN_PUB.P_CHK_ITEM_PRDC_LIFE_CYCLE(C_PLN_ITEM_LIFE_CYCLE.ENTITY_ID, C_PLN_ITEM_LIFE_CYCLE.ITEM_ID,
                                      C_PLN_ITEM_LIFE_CYCLE.PRODUCING_AREA_ID, PKG_PLN_PUB.V_PHASE_INTF_APS);
          IF VS_CHECK_RESULT != 'Y' THEN
            P_RESULT := P_RESULT || VS_CHECK_RESULT || V_NL;
          END IF;
        END LOOP;
        
        IF P_RESULT != V_SUCCESS THEN
          P_RESULT := '以下产品在所属生命周期内不能引APS。' || V_NL || SUBSTR(P_RESULT, 8, LENGTH(P_RESULT) - 8);
          RETURN;
        END IF;
      --汇总订单
      ELSE
        FOR C_PLN_ITEM_LIFE_CYCLE IN
          (SELECT OL.ENTITY_ID,
                  OL.ITEM_ID,
                  OL.PRODUCING_AREA_ID
             FROM T_PLN_ORDER_COLLECT_RELATION ORE,
                  T_PLN_ORDER_LINE             OL
            WHERE ORE.ORDER_COLLECT_HEAD_ID = P_ORDER_HEAD_ID
              AND ORE.ORDER_LINE_ID = OL.ORDER_LINE_ID
              AND OL.CAN_PRODUCE_QTY > 0) LOOP
          VS_CHECK_RESULT := NULL;
          VS_CHECK_RESULT := PKG_PLN_PUB.P_CHK_ITEM_PRDC_LIFE_CYCLE(C_PLN_ITEM_LIFE_CYCLE.ENTITY_ID, C_PLN_ITEM_LIFE_CYCLE.ITEM_ID,
                                      C_PLN_ITEM_LIFE_CYCLE.PRODUCING_AREA_ID, PKG_PLN_PUB.V_PHASE_INTF_APS);
          IF VS_CHECK_RESULT != 'Y' THEN
            P_RESULT := P_RESULT || VS_CHECK_RESULT || V_NL;
          END IF;
        END LOOP;
        
        IF P_RESULT != V_SUCCESS THEN
          P_RESULT := '以下产品在所属生命周期内不能引APS。' || V_NL || SUBSTR(P_RESULT, 8, LENGTH(P_RESULT) - 8);
          RETURN;
        END IF;
      END IF;
    END IF;
    
  EXCEPTION
    WHEN OTHERS THEN
      P_RESULT := '校验订单承诺产品生命周期失败。' || V_NL || '失败信息：' || SQLERRM;
      ROLLBACK;
  END;
  
  ----------------------------------------------------------------------
  -- Author  : hejy3
  -- Created : 2016-5-23 
  -- Purpose : 获取预计交付期间
  ----------------------------------------------------------------------
  FUNCTION f_get_consignment_stage(p_Walkthrough_Date          IN DATE,
                                   p_Estimate_Consignment_Date IN DATE)
    RETURN VARCHAR2 IS
    v_stage t_pln_lg_order_line.estimate_consignment_stage%TYPE;
  BEGIN
    IF p_Walkthrough_Date <= p_Estimate_Consignment_Date THEN
      v_stage := TO_CHAR(p_Estimate_Consignment_Date, 'MM') || '月' ||
                 TO_CHAR(p_Estimate_Consignment_Date, 'DD') || '日前可交付';
    ELSIF p_Estimate_Consignment_Date < p_Walkthrough_Date AND 
          p_Walkthrough_Date <= last_day(p_Estimate_Consignment_Date) THEN
      v_stage := TO_CHAR(p_Estimate_Consignment_Date, 'MM') || '月' ||
                 TO_CHAR(last_day(p_Estimate_Consignment_Date), 'DD') || '日前可交付';
    ELSE
      v_stage := '本月不可交付';
    END IF;
  
    RETURN v_stage;
  EXCEPTION
    WHEN OTHERS THEN
      NULL;
  END f_get_consignment_stage;
  
  ----------------------------------------------------------------------
  -- Author  : ex_zhangcc
  -- Created : 2015-12-14 
  -- Purpose : T+3预排更新订单行表
  ----------------------------------------------------------------------
   Procedure p_T3_Uporder_Line(p_Walkthrough_Batch In Varchar2, --预排批次
                               p_User_Code         In Varchar2, --用户
                               p_Result            Out Varchar2 --返回结果
                               ) IS
     v_Estimate_Consignment_Date DATE; --预计交付日期
   Begin
     p_Result := v_Success;
     Update t_Pln_Order_Line l
        Set (l.Aps_Back_Qty,
             l.Walkthrough_Batch,
             l.Aps_Promise_Time,
             l.Is_Line_Walkthrough,
             l.Is_Order_Walkthrough,
             l.Last_Updated_By,
             l.Last_Update_Date,
             l.Aps_Flag,
             l.Is_Fixed) =
            (Select w.Walkthrough_Qty,
                    w.Walkthrough_Batch,
                    w.Walkthrough_Date,
                    w.Is_Line_Walkthrough,
                    w.Is_Order_Walkthrough,
                    p_User_Code Last_Updated_By,
                    Sysdate Last_Update_Date,
                    'R' Aps_Flag,
                    w.Is_Line_Walkthrough
               From Intf_Pln_Order_Walkthrough_Rec w, t_pln_order_head h --增加单号关联
              Where w.Walkthrough_Batch = p_Walkthrough_Batch
                AND w.order_number = h.order_number --增加单号关联
                And w.Order_Line_Id = l.Order_Line_Id)
      Where Exists (Select (0)
               From Intf_Pln_Order_Walkthrough_Rec r, t_pln_order_head oh --增加单号关联
              Where r.Order_Line_Id = l.Order_Line_Id
                AND r.order_number = oh.order_number
                And r.Walkthrough_Batch = p_Walkthrough_Batch);
     
     --更新订单头的下线直发标志
     Update t_Pln_Order_Head Poh
        Set Poh.Out_Line_Flag =
            (Select Max(Owr.Is_Out_Line_Send)
               From Intf_Pln_Order_Walkthrough_Rec Owr, t_Pln_Order_Line Pol
              Where Owr.Order_Line_Id = Pol.Order_Line_Id
                And Pol.Order_Head_Id = Poh.Order_Head_Id
                AND owr.order_number = poh.order_number --增加单号关联
                And Owr.Walkthrough_Batch = p_Walkthrough_Batch)
      Where Exists
      (Select 1
               From Intf_Pln_Order_Walkthrough_Rec Owr, t_Pln_Order_Line Pol
              Where Owr.Order_Line_Id = Pol.Order_Line_Id
                And Pol.Order_Head_Id = Poh.Order_Head_Id
                AND owr.order_number = poh.order_number --增加单号关联
                And Owr.Walkthrough_Batch = p_Walkthrough_Batch);
     
     --更新提货订单预计交货日期(N+1)
     /*UPDATE T_PLN_LG_ORDER_LINE loL
        SET lol.estimate_consignment_stage =
            TO_CHAR((Select MAX(pol.aps_promise_time)
               From Intf_Pln_Order_Walkthrough_Rec Owr, t_Pln_Order_Line Pol,
                    t_pln_lg_relation lr, t_pln_order_head h --增加单号关联
              Where Owr.Order_Line_Id = Pol.Order_Line_Id
                AND pol.order_line_id = lr.order_line_id
                And lr.lg_order_line_id = lol.order_line_id
                AND owr.order_number = h.order_number
                And Owr.Walkthrough_Batch = p_Walkthrough_Batch), 'YYYY-MM-DD') || '可交付'
      WHERE EXISTS (Select 1
               From Intf_Pln_Order_Walkthrough_Rec Owr, t_Pln_Order_Line Pol,
                    t_pln_lg_relation lr, t_pln_order_head oh --增加单号关联
              Where Owr.Order_Line_Id = Pol.Order_Line_Id
                AND pol.order_line_id = lr.order_line_id
                And lr.lg_order_line_id = lol.order_line_id
                AND owr.order_number = oh.order_number --增加单号关联
                And Owr.Walkthrough_Batch = p_Walkthrough_Batch);*/
     
     --获取提货订单预计交付天数参数
     /*Begin
       SELECT trunc(SYSDATE) + to_number(Pkg_Bd.f_Get_Parameter_Value('PLN_LG_ESTIMATE_CONSIGNMENT_DAY',
                                         p_Entity_Id))
         INTO v_Estimate_Consignment_Date
         FROM dual;
     Exception
       When Others Then
         p_Result := '获取提货订单预计交付日期参数【PLN_LG_ESTIMATE_CONSIGNMENT_DAY】失败' || v_Nl || Sqlerrm;
         Raise v_Base_Exception;
     End;*/
     
     --更新提货订单预计交货日期(N+2)
     UPDATE T_PLN_LG_ORDER_LINE loL
        SET lol.workthrough_flag = 'R'/*,
            lol.estimate_consignment_stage = 
            (Select --max(pkg_pln_intf.f_get_consignment_stage(
                    to_char((owr.walkthrough_date + 3),'yyyy-mm-dd')--,
                        --trunc(SYSDATE) + to_number(Pkg_Bd.f_Get_Parameter_Value('PLN_LG_ESTIMATE_CONSIGNMENT_DAY', ch.entity_id))))
               From Intf_Pln_Order_Walkthrough_Rec Owr, t_pln_lg_wt_collect_h ch,
                    t_pln_LG_COLLECT_R cr
              Where --Owr.Order_Line_Id = lol.Order_Line_Id
                    owr.order_line_id = cr.collect_line_id
                AND ch.collect_head_id = cr.collect_head_id
                AND cr.lg_order_line_id = lol.order_line_id
                AND owr.order_number = ch.collect_number
                And Owr.Walkthrough_Batch = p_Walkthrough_Batch)*/
      WHERE EXISTS (Select 1
               From Intf_Pln_Order_Walkthrough_Rec Owr, t_pln_lg_wt_collect_h ch,
                    t_pln_LG_COLLECT_R cr
              Where --Owr.Order_Line_Id = lol.Order_Line_Id
                    owr.order_line_id = cr.collect_line_id
                AND ch.collect_head_id = cr.collect_head_id
                And nvl(ch.pre_field_20,'_') <> '计划订单'
                AND cr.lg_order_line_id = lol.order_line_id
                AND owr.order_number = ch.collect_number
                And Owr.Walkthrough_Batch = p_Walkthrough_Batch);
                
     --ADD BY LIZHEN 2016-08-19
     --汇总预排数据回写
     Update t_Pln_Lg_Collect_Line_Wt Clw
        Set (Clw.Walkthrough_Rec_Qty,
             Clw.Walkthrough_Rec_Date,
             Clw.Walkthrough_State,
             Clw.Last_Updated_By,
             Clw.Last_Update_Date,
             Clw.Is_Line_Walkthrough,
             Clw.Is_Order_Walkthrough,
             Clw.Is_Out_Line_Send, --add by lizhen 2017-04-18潜在直发标志
             Clw.Is_Fixed) =
            (Select w.Walkthrough_Qty,
                    w.Walkthrough_Date,
                    'R' Walkthrough_State,
                    p_User_Code Last_Updated_By,
                    Sysdate Last_Update_Date,
                    w.is_line_walkthrough,
                    w.is_order_walkthrough,
                    w.is_out_line_send, --add by lizhen 2017-04-18潜在直发标志
                    w.is_line_walkthrough
               From Intf_Pln_Order_Walkthrough_Rec w,
                    t_Pln_Lg_Collect_Head          h --增加单号关联
              Where w.Walkthrough_Batch = p_Walkthrough_Batch
                And w.Order_Number = h.collect_number --增加单号关联
                And h.Collect_Head_Id = Clw.Collect_Head_Id
                And w.Order_Line_Id = Clw.Line_Wt_Id)
      Where Exists (Select (0)
               From Intf_Pln_Order_Walkthrough_Rec r,
                    t_Pln_Lg_Collect_Head          Lch --增加单号关联
              Where r.Order_Line_Id = Clw.Line_Wt_Id
                And r.Order_Number = Lch.Collect_Number
                And Lch.Collect_Head_Id = Clw.Collect_Head_Id
                And r.Walkthrough_Batch = p_Walkthrough_Batch);
                
     --更新提货订单汇总预排后订单行预计交货日期(N+1)
     /*Update t_Pln_Lg_Order_Line Lol
       Set Lol.Estimate_Consignment_Stage = 
       To_Char((Select Max(Owr.Walkthrough_Date)
                  From Intf_Pln_Order_Walkthrough_Rec Owr,
                       t_Pln_Lg_Collect_Head          Lch,
                       t_Pln_Lg_Collect_Line_Wt       Clw,
                       t_Pln_Lg_Collect_Line          Lcl
                 Where Owr.Order_Line_Id = Clw.Line_Wt_Id
                   And Clw.Collect_Head_Id = Lch.Collect_Head_Id
                   And Owr.Order_Number = Lch.Collect_Number --增加单号关联
                   And Lcl.Item_Id = Clw.Item_Id
                   And Lcl.Item_Code = Clw.Item_Code
                   And Lcl.Mrp_Org_Code = Clw.Mrp_Org_Code
                   And Lcl.Collect_Head_Id = Clw.Collect_Head_Id
                   And Lcl.Order_Line_Id =  Lol.Order_Line_Id
                   And Owr.Walkthrough_Batch = p_Walkthrough_Batch),
                'yyyy-mm-dd') || '可交付'
     Where Exists (Select 1
              From Intf_Pln_Order_Walkthrough_Rec Owr,
                   t_Pln_Lg_Collect_Head          Lch,
                   t_Pln_Lg_Collect_Line_Wt       Clw,
                   t_Pln_Lg_Collect_Line          Lcl
             Where Owr.Order_Line_Id = Clw.Line_Wt_Id
               And Clw.Collect_Head_Id = Lch.Collect_Head_Id
               And Owr.Order_Number = Lch.Collect_Number --增加单号关联
               And Lcl.Item_Id = Clw.Item_Id
               And Lcl.Item_Code = Clw.Item_Code
               And Lcl.Mrp_Org_Code = Clw.Mrp_Org_Code
               And Lcl.Collect_Head_Id = Clw.Collect_Head_Id
               And Lcl.Order_Line_Id = Lol.Order_Line_Id
               And Owr.Walkthrough_Batch = p_Walkthrough_Batch);*/
    
    --更新提货订单上预排预警信息    add by huanghb12 2018-9-19      
    pkg_pln_pub.p_upd_lg_consignment_single(p_walkthrough_batch => p_Walkthrough_Batch,
                                            p_opertation_action => '预排',
                                            p_user_code => p_user_code,
                                            p_result => p_result);
   Exception
     When Others Then
       p_Result := '更新订单行失败!' || Sqlerrm;
   End;
   
  ----------------------------------------------------------------------
  -- Author  : ex_zhangcc
  -- Created : 2015-12-30
  -- Purpose : T+3预排发送写入接口表
  ----------------------------------------------------------------------
  Procedure p_Insert_Order_Walkthrg_Send(p_Period_Code       In Varchar2, --周期ID
                                         p_Sales_Main_Type   In Varchar2, --大类
                                         p_Batch_Id          In Number, --批次
                                         p_User_Code         In Varchar2, --用户
                                         p_Entity_Id         In Number, --主体ID
                                         p_Walkthrouth_Batch Out Varchar2, --预排批次
                                         p_Result            Out Varchar2 --返回结果
                                         ) Is
    v_Sales_Main_Para Varchar2(10);
    v_Count           Number;
    v_week            Number;
    v_week_period     varchar2(20);
    Vs_Entity_Code    Varchar2(20);
    v_Pln_Walkthrough_Enabled_Flag  Varchar2(32);
  Begin
    p_Result := v_Success;
    If p_Period_Code Is Null Or p_Batch_Id Is Null Then
      p_Result := '传参失败，部份参数不允许为空。' || v_Nl || 
        '周期编码：' || p_Period_Code || v_Nl ||
        '批次ID：' || p_Batch_Id;
      Raise v_Base_Exception;
    End If;
    Begin
      Select Count(1) Into v_Count
        From t_Pln_Order_Collect_Head Och
       Where Exists (Select 1
                From Up_Codelist Cl, Up_Codelist_Entity Cle
               Where Cl.Codetype = 'plnMergeEntity'
                 And Cl.Id = Cle.Codelist_Id
                 And Cl.Code_Value = p_Entity_Id
                 And Cle.Entity_Id = Och.Entity_Id)
         And Och.Coll_Ord_Number = p_Batch_Id
         And Nvl(Och.Sales_Main_Type, '_') =
             Decode(Pkg_Bd.f_Get_Parameter_Value('ITEM_SALES_MAIN_TYPE_FILTER',
                                                 Och.Entity_Id),
                    'Y',
                     p_Sales_Main_Type,
                    '_')
         And Exists (Select 1
                From t_Pln_Order_Period Op
               Where Op.Period_Id = Och.Period_Id
                 And Op.Period_Code = p_Period_Code
                 And Op.Entity_Id = Och.Entity_Id)
         And Exists
       (Select 1
                From t_Pln_Order_Collect_Relation Ocr, t_Pln_Lg_Relation Lr
               Where Ocr.Order_Collect_Head_Id = Och.Coll_Ord_Head_Id
                 And Lr.Order_Line_Id = Ocr.Order_Line_Id)
       And Och.Form_State != '21';
    Exception
      When Others Then
        v_Count := 0;
    End;
    If Nvl(v_Count, 0) > 0 Then
      p_Result := '计划订单汇总头存在状态不是“已总部评审”的数据。' || v_Nl || 
        '周期编码：' || p_Period_Code || v_Nl ||
        '批次ID：' || p_Batch_Id;
      Raise v_Base_Exception;
    End If;
    
    Begin
      v_Pln_Walkthrough_Enabled_Flag := Pkg_Bd.f_Get_Parameter_Value('PLN_WALKTHROUGH_ENABLED_FLAG',
                                                                     p_Entity_Id);
    Exception
      When Others Then
        p_Result := '获取PLN_WALKTHROUGH_ENABLED_FLAG参数失败' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;
    --add by ex_zhangcc 2016-2-24
    --检查是否还存在为P状态的不允许重复引入
    If v_Pln_Walkthrough_Enabled_Flag = 'SC' Then
      Begin
        Select Count(1)
          Into v_Count
          From t_Pln_Order_Collect_Head Och
         Where Exists (Select 1
                  From Up_Codelist Cl, Up_Codelist_Entity Cle
                 Where Cl.Codetype = 'plnMergeEntity'
                   And Cl.Id = Cle.Codelist_Id
                   And Cl.Code_Value = p_Entity_Id
                   And Cle.Entity_Id = Och.Entity_Id)
           And Och.Coll_Ord_Number = p_Batch_Id
           And Nvl(Och.Sales_Main_Type, '_') =
               Decode(Pkg_Bd.f_Get_Parameter_Value('ITEM_SALES_MAIN_TYPE_FILTER',
                                                   Och.Entity_Id),
                      'Y',
                      p_Sales_Main_Type,
                      '_')
           And Exists (Select 1
                  From t_Pln_Order_Period Op
                 Where Op.Period_Id = Och.Period_Id
                   And Op.Period_Code = p_Period_Code
                   And Op.Entity_Id = Och.Entity_Id)
           And Exists
         (Select 1
                  From t_Pln_Order_Collect_Relation Ocr,
                       t_Pln_Lg_Relation            Lr,
                       t_Pln_Order_Line             l
                 Where Ocr.Order_Collect_Head_Id = Och.Coll_Ord_Head_Id
                   And Lr.Order_Line_Id = Ocr.Order_Line_Id
                   And l.Order_Line_Id = Ocr.Order_Line_Id
                   And l.Order_Line_Id = Lr.Order_Line_Id
                   And l.Aps_Flag = 'P')
           And Och.Form_State = '21';
        If Nvl(v_Count, 0) > 0 Then
          p_Result := '计划订单行存在为P状态的数据!不允许引APS!';
          Raise v_Base_Exception;
        End If;
      End;
    End If;
    Begin
      v_Sales_Main_Para := Pkg_Bd.f_Get_Parameter_Value('ITEM_SALES_MAIN_TYPE_FILTER',
                                                                    p_entity_id);
    Exception
      When Others Then
        p_Result := '获取ITEM_SALES_MAIN_TYPE_FILTER参数失败' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;
    Begin
      p_Walkthrouth_Batch := Pkg_Bd.f_Get_Bill_No('PlnWalkthroughBatch',
                                                  Null,
                                                  p_Entity_Id,
                                                  Null);
    Exception
      When Others Then
        p_Result := '生成预排发送接口批次编码失败, 未生成接口批次编码!' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;
    If p_Walkthrouth_Batch Is Null Then
      p_Result := '生成预排发送接口批次编码失败,未生成接口批次编码!';
      Raise v_Base_Exception;
    End If;
    
    Begin
    Select p.Statistic_Week
      Into v_Week
      From t_Pln_Order_Period p
       Where p.Entity_Id = p_Entity_Id
             And p.Period_Code = p_Period_Code
             And p.Period_Type = 'T+3周期';
    If v_Week Is Null Then
      p_Result := '获取自然周期失败!';
      Raise v_Base_Exception;
    Else
      v_Week_Period := '第' || v_Week || '周';
    End If;
    End;
    
    Begin
     Select Ue.Entity_Code_Name
       Into Vs_Entity_Code
       From Up_Codelist Up, Up_Codelist_Entity Ue
      Where Up.Codetype = 'PlnEntityToMainEntity'
        And Up.Id = Ue.Codelist_Id
        And Ue.Entity_Id = p_Entity_Id;
     Exception 
       When No_Data_Found Then
         Begin
          Select Entity.Entity_Code
             Into Vs_Entity_Code
            From v_Bd_Entity Entity
           Where Entity.Entity_Id = p_Entity_Id;
         Exception
           When Others Then
             p_Result := '获取主体失败' || Sqlerrm;
             raise v_Base_Exception;
         End;
       When Others Then
        p_Result := '获取主体失败,主体快码PlnEntityToMainEntity' || Sqlerrm;
         raise v_Base_Exception;
     End;
     
    Begin
      Insert Into Intf_Pln_Walkthrough_Send
        (Entity_Code,
         Intf_Pln_Send_Id,
         Organization_Code,
         Organization_Id,
         Order_Number,
         Order_Line_Id,
         Batch_Number,
         Request_Period,
         Request_Date,
         item_id,
         Item_Number,
         Priority,
         Order_Type_Name,
         Customer_Name,
         Request_Qty,
         Is_Fixed,
         Order_Creation_Date,
         Pre_Field_01,
         Pre_Field_02,
         Pre_Field_03,
         Created_By,
         Creation_Date,
         Last_Updated_By,
         Last_Update_Date,
         intf_status,
         line_number,
         Expect_Date, --add by lizhen 2016-07-25
         Lg_Collect_Number,--add by lizhen 2016-07-25
         Carload_Meet_Num --add by lizhen 2016-07-25
         )
        Select Vs_Entity_Code,
               Seq_Walkthrough_Send.Nextval,
               Ppa.Mrp_Org_Code,
               Ppa.Mrp_Org_Id,
               Poh.Order_Number,
               Pol.Order_Line_Id,
               p_Walkthrouth_Batch,
               v_Week_Period,
               Pop.End_Date,
               pol.item_id,
               Pol.Item_Code,
               Lch.Priority_Sort,  --Priority优先级
               Poh.Order_Type_Name,
               Poh.Customer_Name,
               Pol.Check_Qty,
               Nvl(Pol.Is_Fixed, 'N'),
               Trunc(Sysdate),
               Null,
               Null,
               Null,
               p_User_Code,
               Sysdate,
               p_User_Code,
               Sysdate,
               'N' ,    --intf_status
               Rownum,
               Pol.Expect_Date, --expect_date --add by lizhen 2016-07-25
               Poh.Source_Order_Number, --Lg_Collect_number  --add by lizhen 2016-07-25  
               Poh.Carload_Meet_Num  --add by lizhen 2016-07-25
          From t_Pln_Lg_Collect_Head     Lch,
               Cims.t_Pln_Order_Head     Poh,
               Cims.t_Pln_Order_Line     Pol,
               Cims.t_Pln_Producing_Area Ppa,
               Cims.t_Pln_Order_Period   Pop,
               v_Bd_Entity               Vbe
         Where Poh.Order_Head_Id = Pol.Order_Head_Id
           And Poh.Source_Type = '提货订单'
           And Poh.Source_Order_Head_Id = Lch.Collect_Head_Id
           And Ppa.Producing_Area_Id = Pol.Producing_Area_Id
           And Pop.Period_Id = Poh.Period_Id
           And Pop.Entity_Id = Poh.Entity_Id
           And Vbe.Entity_Id = Poh.Entity_Id
           And Poh.Form_State = '25'
           And Poh.Batch_Id = p_Batch_Id
           And Nvl(Pol.Can_Produce_Qty, 0) > 0
           And (v_Pln_Walkthrough_Enabled_Flag <> 'SC' Or 
           (v_Pln_Walkthrough_Enabled_Flag = 'SC' And Pol.Aps_Flag <> 'P'))
           And Exists (Select 1
                  From Up_Codelist Cl, Up_Codelist_Entity Cle
                 Where Cl.Codetype = 'plnMergeEntity'
                   And Cl.Id = Cle.Codelist_Id
                   And Cl.Code_Value = p_Entity_Id
                   And Cle.Entity_Id = Lch.Entity_Id)
           And Pop.Period_Code = p_Period_Code
           And Nvl(Poh.Sales_Main_Type, '_') =
             Decode(Pkg_Bd.f_Get_Parameter_Value('ITEM_SALES_MAIN_TYPE_FILTER',
                                                 Poh.Entity_Id),
                    'Y',
                     p_Sales_Main_Type,
                    '_');
    Exception
      When Others Then
        p_Result := '插入预排产发送接口表失败!' || Sqlerrm;
        -- subStr(Sqlerrm,200) || V_NL|| subStr(dbms_utility.format_error_backtrace,200);
        Raise v_Base_Exception;
    End;
    
    --更新订单行引预排接口标志
    Update t_Pln_Order_Line Pol
       Set Pol.Aps_Flag         = 'P',
           Pol.Aps_Import_Date  = Sysdate,
           Pol.Intf_Type        = 'WALKTHROUGH',
           Pol.Last_Updated_By  = p_User_Code,
           Pol.Last_Update_Date = Sysdate
     Where Pol.Order_Line_Id In
           (Select Ws.Order_Line_Id
              From Intf_Pln_Walkthrough_Send Ws
             Where Ws.Intf_Status = 'N');
  Exception
    When v_Base_Exception Then
      Rollback;
    When Others Then
      p_Result := p_Result;
  End;
 
  -----------------------------------------------------------------------------
  -- AUTHOR  : hejy3
  -- CREATED : 2016-4-12
  -- PURPOSE : 预排汇总数据引入预排接口
  -----------------------------------------------------------------------------
  PROCEDURE p_Wt_Collect_Into_Wt_Intf(p_Entity_Id         IN NUMBER, --主体ID
                                      p_Period_Code       IN VARCHAR2, --周期编码
                                      p_User_Code         IN VARCHAR2, --用户
                                      p_Walkthrouth_Batch IN Out Varchar2, --预排批次
                                      p_Result            Out Varchar2 --返回结果
                                      ) IS
    V_COUNT NUMBER;
    v_Week NUMBER;
    v_Week_Period VARCHAR2(100);
    Vs_Entity_Code VARCHAR2(100);
    v_Period_End_Date DATE;
    v_Estimate_Consignment_Date DATE;
    v_In_Walkthrouth_Batch varchar2(50);
  BEGIN
    p_Result := v_Success;
    v_In_Walkthrouth_Batch := p_Walkthrouth_Batch;
    --检查传入参数
    IF p_Entity_Id IS NULL OR p_Period_Code IS NULL THEN
      p_Result := '部份参数不允许为空。' || v_Nl || 
        '周期编码：' || p_Period_Code || v_Nl ||
        '主体ID：' || p_Entity_Id;
      Raise v_Base_Exception;
    END IF;
    
    --获取是否有未引预排的汇总数据
    BEGIN
      SELECT COUNT(1) INTO V_COUNT
        FROM T_PLN_LG_WT_COLLECT_H H
       WHERE H.PERIOD_CODE = p_Period_Code
         AND Exists (Select 1
                From Up_Codelist Cl, Up_Codelist_Entity Cle
               Where Cl.Codetype = 'plnMergeEntity'
                 And Cl.Id = Cle.Codelist_Id
                 And Cl.Code_Value = TO_CHAR(p_Entity_Id)
                 And Cle.Entity_Id = H.Entity_Id)
         AND NVL(H.TO_WORKTHROUGH_FLAG, 'N') = 'N';
    END;
    
    IF V_COUNT = 0 THEN
      p_Result := '当前周期【' || p_Period_Code || '】没有需要引入预排的数据';
      RAISE v_Base_Exception;
    END IF;
    
    --获取周
    Begin
      Select p.Statistic_Week, p.End_Date
        Into v_Week, v_Period_End_Date
        From t_Pln_Order_Period p
       Where p.Entity_Id = p_Entity_Id
         And p.Period_Code = p_Period_Code
         And p.Period_Type = 'T+3周期';
      If v_Week Is Null Then
        p_Result := '获取自然周期失败!';
        Raise v_Base_Exception;
      Else
        v_Week_Period := '第' || v_Week || '周';
      End If;
    End;
    
    --获取事业部编码
    Begin
     Select Ue.Entity_Code_Name
       Into Vs_Entity_Code
       From Up_Codelist Up, Up_Codelist_Entity Ue
      Where Up.Codetype = 'PlnEntityToMainEntity'
        And Up.Id = Ue.Codelist_Id
        And Ue.Entity_Id = p_Entity_Id;
    Exception 
      When No_Data_Found Then 
        p_Result := '获取主体编码失败,快码PlnEntityToMainEntity!';
        raise v_Base_Exception;
    End;
    
    --获取预排批次
    if p_Walkthrouth_Batch is null then
      Begin
        p_Walkthrouth_Batch := Pkg_Bd.f_Get_Bill_No('PlnWalkthroughBatch',
                                                    Null,
                                                    p_Entity_Id,
                                                    Null);
      Exception
        When Others Then
          p_Result := '生成预排发送接口批次编码失败, 未生成接口批次编码!' || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
      End;
    end if;
    If p_Walkthrouth_Batch Is Null Then
      p_Result := '生成预排发送接口批次编码失败,未生成接口批次编码!';
      Raise v_Base_Exception;
    End If;
    
    --插入预排发送接口
    Begin
      Insert Into Intf_Pln_Walkthrough_Send
        (Entity_Code,
         Intf_Pln_Send_Id,
         Organization_Code,
         Organization_Id,
         Order_Number,
         Order_Line_Id,
         Batch_Number,
         Request_Period,
         Request_Date,
         item_id,
         Item_Number,
         Priority,
         Order_Type_Name,
         Customer_Name,
         Request_Qty,
         Is_Fixed,
         Order_Creation_Date,
         Pre_Field_01,
         Pre_Field_02,
         Pre_Field_03,
         Created_By,
         Creation_Date,
         Last_Updated_By,
         Last_Update_Date,
         intf_status,
         line_number)
        Select Vs_Entity_Code,
               Seq_Walkthrough_Send.Nextval,
               Mrp_Org_Code,
               Mrp_Org_Id,
               Collect_Number,
               Collect_Line_Id,
               p_Walkthrouth_Batch,
               Week_Period,
               End_Date,
               Item_Id,
               Item_Code,
               nvl(priority_sort, 1), --Priority优先级
               Order_Type_Name,
               Customer_Name,
               To_Workthrough_Qty,
               'N',
               Trunc(Sysdate),
               Null,
               Null,
               Null,
               p_User_Code,
               Sysdate,
               p_User_Code,
               Sysdate,
               'N', --intf_status
               Rownum
          From (Select Ppa.Mrp_Org_Code,
                       Ppa.Mrp_Org_Id,
                       Wh.Collect_Number,
                       Wl.Collect_Line_Id,
                       v_Week_Period Week_Period,
                       Pop.End_Date,
                       Wl.Item_Id,
                       Wl.Item_Code,
                       '提货订单' Order_Type_Name,
                       '汇总订单客户' Customer_Name,
                       Wl.To_Workthrough_Qty,
                       wh.priority_sort
                  From t_Pln_Lg_Wt_Collect_h     Wh,
                       t_Pln_Lg_Wt_Collect_l     Wl,
                       Cims.t_Pln_Producing_Area Ppa,
                       Cims.t_Pln_Order_Period   Pop
                 Where Wh.Collect_Head_Id = Wl.Collect_Head_Id
                   And Ppa.Producing_Area_Id = Wl.Producing_Area_Id
                   And Pop.Period_Code = Wh.Period_Code
                   And Pop.Entity_Id = Wl.Entity_Id
                   And Nvl(Wh.Pre_Field_20, '_') <> '计划订单'
                   And Nvl(Wh.To_Workthrough_Flag, 'N') <> 'Y'
                   And Wl.To_Workthrough_Qty > 0
                   and (wh.pre_field_17 = p_Walkthrouth_Batch or v_In_Walkthrouth_Batch is null)
                   And Exists
                 (Select 1
                          From Up_Codelist Cl, Up_Codelist_Entity Cle
                         Where Cl.Codetype = 'plnMergeEntity'
                           And Cl.Id = Cle.Codelist_Id
                           And Cl.Code_Value = To_Char(p_Entity_Id)
                           And Cle.Entity_Id = Wl.Entity_Id)
                   And Pop.Period_Code = p_Period_Code
           --hejy3 T+3优化 不参与预排不引入
           and not exists (select 1 from t_pln_item_property p
                        where p.Entity_Id = wh.entity_id
                          and p.item_id = wl.item_id
                          and p.item_code = wl.item_code
                          and p.cannot_walkthrough_flag = 'Y')
                Union All
                Select Distinct Ppa.Mrp_Org_Code,
                       Ppa.Mrp_Org_Id,
                       Wh.Collect_Number,
                       Wl.Collect_Line_Id,
                       v_Week_Period Week_Period,
                       /*'第' || (Select p.Statistic_Week
                                 From t_Pln_Order_Period p
                                Where p.Entity_Id = h.Entity_Id
                                  And p.Period_Code = h.Period_Code
                                  And p.Period_Type = 'T+3周期') || '周' Week_Period,*/
                       Pop.End_Date,
                       Wl.Item_Id,
                       Wl.Item_Code,
                       '计划订单' Order_Type_Name,
                       '汇总订单客户' Customer_Name,
                       Wl.To_Workthrough_Qty,
                       wh.priority_sort
                  From t_Pln_Lg_Wt_Collect_h     Wh,
                       t_Pln_Lg_Wt_Collect_l     Wl,
                       t_Pln_Lg_Collect_r        r,
                       t_Pln_Order_Head          h,
                       Cims.t_Pln_Producing_Area Ppa,
                       Cims.t_Pln_Order_Period   Pop
                 Where Wh.Collect_Head_Id = Wl.Collect_Head_Id
                   And r.Collect_Line_Id = Wl.Collect_Line_Id
                   And r.Collect_Head_Id = Wh.Collect_Head_Id
                   And r.Lg_Order_Head_Id = h.Order_Head_Id
                   And Ppa.Producing_Area_Id = Wl.Producing_Area_Id
                   And Pop.Period_Code = h.Period_Code
                   And Pop.Entity_Id = h.Entity_Id
                   And Nvl(Wh.Pre_Field_20, '_') = '计划订单'
                   And nvl(wh.to_workthrough_flag,'N') <> 'Y'
                   And Wl.To_Workthrough_Qty > 0
                   and (wh.pre_field_17 = p_Walkthrouth_Batch or v_In_Walkthrouth_Batch is null)
                   And Exists
                 (Select 1
                          From Up_Codelist Cl, Up_Codelist_Entity Cle
                         Where Cl.Codetype = 'plnMergeEntity'
                           And Cl.Id = Cle.Codelist_Id
                           And Cl.Code_Value = To_Char(p_Entity_Id)
                           And Cle.Entity_Id = Wl.Entity_Id)
                   And Wh.Period_Code = p_Period_Code
           --hejy3 T+3优化 不参与预排不引入
           and not exists (select 1 from t_pln_item_property p
                        where p.Entity_Id = wh.entity_id
                          and p.item_id = wl.item_id
                          and p.item_code = wl.item_code
                          and p.cannot_walkthrough_flag = 'Y')
);
    Exception
      When Others Then
        p_Result := '插入预排产发送接口表失败!' || Sqlerrm;
        -- subStr(Sqlerrm,200) || V_NL|| subStr(dbms_utility.format_error_backtrace,200);
        Raise v_Base_Exception;
    End;
    
    --获取提货订单预计交付天数参数
    Begin
      SELECT trunc(SYSDATE) + to_number(Pkg_Bd.f_Get_Parameter_Value('PLN_LG_ESTIMATE_CONSIGNMENT_DAY',
                                        p_Entity_Id))
        INTO v_Estimate_Consignment_Date
        FROM dual;
    Exception
      When Others Then
        p_Result := '获取提货订单预计交付日期参数【PLN_LG_ESTIMATE_CONSIGNMENT_DAY】失败' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;

    --更新全部库存满足的提货订单行的预计交货日期
    UPDATE T_PLN_LG_ORDER_LINE L
       SET L.ESTIMATE_CONSIGNMENT_STAGE = v_Period_End_Date,
           --pkg_pln_intf.f_get_consignment_stage(v_Period_End_Date, v_Estimate_Consignment_Date),
           L.WORKTHROUGH_FLAG = 'N'
     WHERE EXISTS (SELECT 1 FROM T_PLN_LG_WT_COLLECT_L WL, T_PLN_LG_WT_COLLECT_H WH, T_PLN_LG_COLLECT_R CR
                    WHERE WL.COLLECT_HEAD_ID = WH.COLLECT_HEAD_ID
                      AND CR.COLLECT_LINE_ID = WL.COLLECT_LINE_ID
                      AND CR.LG_ORDER_LINE_ID = L.ORDER_LINE_ID
                      AND WH.PERIOD_CODE = p_Period_Code
                      AND NVL(WH.TO_WORKTHROUGH_FLAG, 'N') = 'N'
                      And nvl(wh.pre_field_20,'_') <> '计划订单'  --不取计划订单的数据 lilh6 2018-9-30
                      and (wh.pre_field_17 = p_Walkthrouth_Batch or v_In_Walkthrouth_Batch is null)
                      AND EXISTS (Select 1
                                    From Up_Codelist Cl, Up_Codelist_Entity Cle
                                   Where Cl.Codetype = 'plnMergeEntity'
                                     And Cl.Id = Cle.Codelist_Id
                                     And Cl.Code_Value = to_char(p_Entity_Id)
                                     AND cle.entity_id = wh.entity_id)
                      AND WL.TO_WORKTHROUGH_QTY = 0);
    
    --更新引预排接口的提货订单行状态
    UPDATE T_PLN_LG_ORDER_LINE L
       SET L.WORKTHROUGH_FLAG = 'P', L.ESTIMATE_CONSIGNMENT_STAGE = NULL
     WHERE EXISTS (SELECT 1 FROM T_PLN_LG_WT_COLLECT_L WL, T_PLN_LG_WT_COLLECT_H WH, T_PLN_LG_COLLECT_R CR
                    WHERE WL.COLLECT_HEAD_ID = WH.COLLECT_HEAD_ID
                      AND CR.COLLECT_LINE_ID = WL.COLLECT_LINE_ID
                      AND CR.LG_ORDER_LINE_ID = L.ORDER_LINE_ID
                      AND WH.PERIOD_CODE = p_Period_Code
                      AND NVL(WH.TO_WORKTHROUGH_FLAG, 'N') = 'N'
                      And nvl(wh.pre_field_20,'_') <> '计划订单'  --不取计划订单的数据 lilh6 2018-9-30
                      and (wh.pre_field_17 = p_Walkthrouth_Batch or v_In_Walkthrouth_Batch is null)
                      AND EXISTS (Select 1
                                    From Up_Codelist Cl, Up_Codelist_Entity Cle
                                   Where Cl.Codetype = 'plnMergeEntity'
                                     And Cl.Id = Cle.Codelist_Id
                                     And Cl.Code_Value = to_char(p_Entity_Id)
                                     AND cle.entity_id = wh.entity_id)
                      AND WL.TO_WORKTHROUGH_QTY > 0)
       AND NOT EXISTS (SELECT 1 FROM T_PLN_ITEM_PROPERTY P
                    WHERE P.ITEM_ID = L.ITEM_ID
                      AND P.CANNOT_SUBMIT_FLAG = 'Y');
    
    --更新引预排接口的提货订单行状态
    UPDATE T_PLN_LG_ORDER_LINE L
       SET L.WORKTHROUGH_FLAG = 'A', L.ESTIMATE_CONSIGNMENT_STAGE = NULL
     WHERE EXISTS (SELECT 1 FROM T_PLN_LG_WT_COLLECT_L WL, T_PLN_LG_WT_COLLECT_H WH, T_PLN_LG_COLLECT_R CR
                    WHERE WL.COLLECT_HEAD_ID = WH.COLLECT_HEAD_ID
                      AND CR.COLLECT_LINE_ID = WL.COLLECT_LINE_ID
                      AND CR.LG_ORDER_LINE_ID = L.ORDER_LINE_ID
                      AND WH.PERIOD_CODE = p_Period_Code
                      AND NVL(WH.TO_WORKTHROUGH_FLAG, 'N') = 'N'
                      And nvl(wh.pre_field_20,'_') <> '计划订单'  --不取计划订单的数据 lilh6 2018-9-30
                      and (wh.pre_field_17 = p_Walkthrouth_Batch or v_In_Walkthrouth_Batch is null)
                      AND EXISTS (Select 1
                                    From Up_Codelist Cl, Up_Codelist_Entity Cle
                                   Where Cl.Codetype = 'plnMergeEntity'
                                     And Cl.Id = Cle.Codelist_Id
                                     And Cl.Code_Value = to_char(p_Entity_Id)
                                     AND cle.entity_id = wh.entity_id)
                      AND WL.TO_WORKTHROUGH_QTY > 0)
       AND EXISTS (SELECT 1 FROM T_PLN_ITEM_PROPERTY P
                    WHERE P.ITEM_ID = L.ITEM_ID
                      AND P.CANNOT_SUBMIT_FLAG = 'Y');
    
    UPDATE T_PLN_LG_WT_COLLECT_L WL
       SET WL.NO_NEED_WALKTHROUGH = 'Y'
     WHERE EXISTS (SELECT 1 FROM T_PLN_LG_WT_COLLECT_H WH
                    WHERE WL.COLLECT_HEAD_ID = WH.COLLECT_HEAD_ID
                      AND WH.PERIOD_CODE = p_Period_Code
                      AND NVL(WH.TO_WORKTHROUGH_FLAG, 'N') = 'N'
                      And nvl(wh.pre_field_20,'_') <> '计划订单'  --不取计划订单的数据 lilh6 2018-9-30
                      and (wh.pre_field_17 = p_Walkthrouth_Batch or v_In_Walkthrouth_Batch is null)
                      AND EXISTS (Select 1
                                    From Up_Codelist Cl, Up_Codelist_Entity Cle
                                   Where Cl.Codetype = 'plnMergeEntity'
                                     And Cl.Id = Cle.Codelist_Id
                                     And Cl.Code_Value = to_char(p_Entity_Id)
                                     AND cle.entity_id = wh.entity_id))
       AND EXISTS (SELECT 1 FROM T_PLN_ITEM_PROPERTY P
                    WHERE P.ITEM_ID = wL.ITEM_ID
                      AND P.CANNOT_SUBMIT_FLAG = 'Y');
    
    --更新汇总头引预排标志
    UPDATE T_PLN_LG_WT_COLLECT_H H
       SET H.TO_WORKTHROUGH_FLAG = 'Y', H.TO_WORKTHROUGH_DATE = SYSDATE, H.PRE_FIELD_17 = p_Walkthrouth_Batch
     WHERE H.PERIOD_CODE = p_Period_Code
       AND NVL(H.TO_WORKTHROUGH_FLAG, 'N') = 'N'
       and (h.pre_field_17 = p_Walkthrouth_Batch or v_In_Walkthrouth_Batch is null)
       AND EXISTS (Select 1
                  From Up_Codelist Cl, Up_Codelist_Entity Cle
                 Where Cl.Codetype = 'plnMergeEntity'
                   And Cl.Id = Cle.Codelist_Id
                   And Cl.Code_Value = to_char(p_Entity_Id)
                   AND cle.entity_id = h.entity_id);
  Exception
    When v_Base_Exception Then
      Rollback;
    When Others Then
      p_Result := p_Result;
  END;
  
  ----------------------------------------------------------------------
  -- Author  : Nicro.Li
  -- Created : 2016-08-13
  -- Purpose : 提货订单汇总写入APS预排接口
  ----------------------------------------------------------------------
  Procedure p_LgCollect_Walkthrg_Send(p_Batch_Code       In Varchar2, --提货订单汇总头ID
                                      p_Entity_Id        In Number, --主体ID
                                      p_Period_Code      In Varchar2, --周期编码
                                      p_User_Code        In Varchar2, --用户
                                      p_Result           Out Varchar2 --返回结果
                                      ) Is
    v_Sales_Main_Para Varchar2(10);
    v_Count           Number;
    v_week            Number;
    v_week_period     varchar2(20);
    Vs_Entity_Code    Varchar2(20);
    v_Pln_Walkthrough_Enabled_Flag  Varchar2(32);
    v_Walkthrouth_Batch             Varchar2(32);
    r_Collect_Head     t_pln_lg_collect_head%Rowtype;
  Begin
    p_Result := v_Success;
    If p_Batch_Code Is Null Or p_Entity_Id Is Null Or p_Period_Code Is Null Then
      p_Result := '传参失败，部份参数不允许为空。' || v_Nl || 
        '提货订单汇总预排批次编码：' || p_Batch_Code || v_Nl ||
        '主体ID：' || p_Entity_Id || v_Nl ||
        '周期编码：' || p_Period_Code;
      Raise v_Base_Exception;
    End If;
        
    Begin
      v_Pln_Walkthrough_Enabled_Flag := Pkg_Bd.f_Get_Parameter_Value('PLN_WALKTHROUGH_ENABLED_FLAG',
                                                                     p_Entity_Id);
    Exception
      When Others Then
        p_Result := '获取PLN_WALKTHROUGH_ENABLED_FLAG参数失败' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;
    --add by ex_zhangcc 2016-2-24
    --检查是否还存在为P状态的不允许重复引入
    If v_Pln_Walkthrough_Enabled_Flag = 'SC' Then
      Begin
        Select Count(1)
          Into v_Count
          From t_Pln_Lg_Collect_Head Lch,
               t_Pln_Lg_Collect_Line_Wt Lclw
         Where Exists (Select 1
                  From Up_Codelist Cl, Up_Codelist_Entity Cle
                 Where Cl.Codetype = 'plnMergeEntity'
                   And Cl.Id = Cle.Codelist_Id
                   And Cl.Code_Value = p_Entity_Id
                   And Cle.Entity_Id = Lch.Entity_Id)
           And Lch.Batch_Code = p_Batch_Code
           And Lclw.Walkthrough_State = 'P'
           And Lclw.Collect_Head_Id = Lch.collect_head_id;
        If Nvl(v_Count, 0) > 0 Then
          p_Result := '提货订单汇总预排行存在为P状态的数据!不允许引APS!';
          Raise v_Base_Exception;
        End If;
      End;
    End If;
    
    Begin
      v_Walkthrouth_Batch := Pkg_Bd.f_Get_Bill_No('PlnWalkthroughBatch',
                                                  Null,
                                                  p_Entity_Id,
                                                  Null);
    Exception
      When Others Then
        p_Result := '生成预排发送接口批次编码失败, 未生成接口批次编码!' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;
    If v_Walkthrouth_Batch Is Null Then
      p_Result := '生成预排发送接口批次编码失败,未生成接口批次编码!';
      Raise v_Base_Exception;
    End If;
    --add by ex_zhangcc 2016-2-17
    Begin
      Select p.Statistic_Week
        Into v_Week
        From t_Pln_Order_Period p
       Where p.Entity_Id = p_Entity_Id
         And p.Period_Code = p_Period_Code
         And p.Period_Type = 'T+3周期';
      If v_Week Is Null Then
        p_Result := '获取自然周期失败!';
        Raise v_Base_Exception;
      Else
        v_Week_Period := '第' || v_Week || '周';
      End If;
    End;
    --add by ex_zhangcc 2016-2-17 
    Begin
      Select Ue.Entity_Code_Name
        Into Vs_Entity_Code
        From Up_Codelist Up, Up_Codelist_Entity Ue
       Where Up.Codetype = 'PlnEntityToMainEntity'
         And Up.Id = Ue.Codelist_Id
         And Ue.Entity_Id = p_Entity_Id;
    Exception
      When No_Data_Found Then
        Begin
          Select Be.Entity_Code
            Into Vs_Entity_Code
            From v_Bd_Entity Be
           Where Be.Entity_Id = p_Entity_Id;
        Exception
          When Others Then
            p_Result := '获取主体失败' || Sqlerrm;
            Raise v_Base_Exception;
        End;
      When Others Then
        p_Result := '获取主体编码失败,快码PlnEntityToMainEntity!' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;
    Declare
      v_Item_Cycle_Msg      Varchar2(4000) := Null;
    Begin      
      For r_Collect_Ling In (Select Lcl.Item_Code
                               From t_Pln_Lg_Collect_Head Lch,
                                    t_Pln_Order_Period    Pop,
                                    t_Pln_Lg_Collect_Line Lcl
                              Where Pop.Entity_Id = Lch.Entity_Id
                                And Pop.Period_Type = 'T+3周期'
                                And Pop.Period_Code = Lch.Period_Code
                                And Lch.Batch_Code = p_Batch_Code
                                And Lcl.Collect_Head_Id = Lch.Collect_Head_Id
                                And Nvl(Lch.Walkthrough_Confirm_Flag, 'N') <> 'Y'
                                --hejy3 T+3优化 过滤不参与预排产品
                                and not exists (select 1 from t_pln_item_property p
                                                 where p.item_id = lcl.item_id
                                                   and p.item_code = lcl.item_code
                                                   and p.entity_id = lch.entity_id
                                                   and p.cannot_walkthrough_flag = 'Y')
                                And Pkg_Pln_Pub.p_Chk_Item_Prdc_Life_Cycle(p_Entity_Id         => Lcl.Entity_Id,
                                                                           p_Item_Id           => Lcl.Item_Id,
                                                                           p_Producing_Area_Id => Lcl.Producing_Area_Id,
                                                                           p_Order_Phase       => 'INTF_APS') <> 'Y') Loop
        If v_Item_Cycle_Msg Is Null Then
          v_Item_Cycle_Msg := r_Collect_Ling.Item_Code;
        Else
          v_Item_Cycle_Msg := v_Item_Cycle_Msg || ',' || r_Collect_Ling.Item_Code;
        End If;                                                                   
      End Loop;
      If v_Item_Cycle_Msg Is Not Null Then
        p_Result := '产品编码：' || v_Item_Cycle_Msg || '生命周期不允许引入APS系统!';
        Raise v_Base_Exception;
      End If;
    End;
     
    Begin
      Insert Into Intf_Pln_Walkthrough_Send
        (Entity_Code,
         Intf_Pln_Send_Id,
         Organization_Code,
         Organization_Id,
         Order_Number,
         Order_Line_Id,
         Batch_Number,
         Request_Period,
         Request_Date,
         Item_Id,
         Item_Number,
         Priority,
         Order_Type_Name,
         Customer_Name,
         Request_Qty,
         Is_Fixed,
         Order_Creation_Date,
         Pre_Field_01,
         Pre_Field_02,
         Pre_Field_03,
         Created_By,
         Creation_Date,
         Last_Updated_By,
         Last_Update_Date,
         Intf_Status,
         Line_Number,
         Carload_Meet_Num, --ADD BY LIZHEN 2016-08-13
         Lg_Collect_Number, --ADD BY LIZHEN 2016-08-13
         Expect_Date --ADD BY LIZHEN 2016-08-13
         )
        Select Vs_Entity_Code,
               Seq_Walkthrough_Send.Nextval,
               Lclw.Mrp_Org_Code,
               Lclw.Mrp_Org_Id,
               Lch.Collect_Number Order_Number,
               Lclw.Line_Wt_Id Order_Line_Id,
               Lch.Batch_Code,
               v_Week_Period,
               Pop.End_Date,
               Lclw.Item_Id,
               Lclw.Item_Code,
               Lch.Priority_Sort, --Priority优先级
               '提货订单汇总' Order_Type_Name,
               (Select Max(Loh.Customer_Name)
                  From t_Pln_Lg_Collect_Line Lcl, t_Pln_Lg_Order_Head Loh
                 Where Lcl.Order_Head_Id = Loh.Order_Head_Id
                   And Lcl.Collect_Head_Id = Lch.Collect_Head_Id) Customer_Name,
               Lclw.To_Plnorder_Qty,
               Nvl(Lclw.Is_Fixed, 'N'), -- Is_Fixed
               Trunc(Sysdate),
               Null,
               Null,
               Null,
               p_User_Code,
               Sysdate,
               p_User_Code,
               Sysdate,
               'N', --intf_status
               Rownum,
               Pkg_Pln_Pub.f_Get_T3ordpara_Collect_Value(p_Entity_Id          => p_Entity_Id,
                                                         p_Lg_Collect_Head_Id => Lch.Collect_Head_Id,
                                                         p_Table_Alias        => 'LOH',
                                                         p_Column_Code        => 'CARLOAD_MEET_NUM') Carload_Meet_Num,
               Lch.Collect_Number,
               (Select Min(Loh.Consignment_Date)
                  From t_Pln_Lg_Collect_Line Lcl, t_Pln_Lg_Order_Head Loh
                 Where Lcl.Order_Head_Id = Loh.Order_Head_Id
                   And Lcl.Collect_Head_Id = Lch.Collect_Head_Id) Expect_Date
          From t_Pln_Lg_Collect_Head    Lch,
               t_Pln_Lg_Collect_Line_Wt Lclw,
               t_Pln_Order_Period       Pop
         Where Lch.Collect_Head_Id = Lclw.Collect_Head_Id
           And Pop.Entity_Id = Lch.Entity_Id
           And Pop.Period_Type = 'T+3周期'
           And Pop.Period_Code = Lch.Period_Code
           And Lch.Batch_Code = p_Batch_Code
           And Nvl(Lch.Walkthrough_Confirm_Flag, 'N') <> 'Y'
           --hejy3 T+3优化 过滤不参与预排产品
           and not exists (select 1 from t_pln_item_property p
                           where p.item_id = lclw.item_id
                             and p.item_code = lclw.item_code
                             and p.entity_id = lch.entity_id
                             and p.cannot_walkthrough_flag = 'Y');
    Exception
      When Others Then
        p_Result := '插入预排产发送接口表失败!' || Sqlerrm;
        Raise v_Base_Exception;
    End;
    /*If Sql%Notfound Then
      p_Result := '提货订单汇总预排行无数据，插入预排接口失败!' || v_Nl ||
       '提货汇总编码：' || r_Collect_Head.Collect_Number;
        Raise v_Base_Exception;
    End If;*/
    
    --hejy3 T+3优化 更新不参与预排标志
    Update t_Pln_Lg_Collect_Line_Wt Lclw
       Set Lclw.Last_Updated_By         = p_User_Code,
           Lclw.Last_Update_Date        = Sysdate,
           Lclw.Version                 = Nvl(Lclw.Version, 0) + 1,
           lclw.walkthrough_state = 'A',
           lclw.no_need_walkthrough = 'Y'
     Where Lclw.Collect_Head_Id In
           (Select Lch.Collect_Head_Id
              From t_Pln_Lg_Collect_Head Lch
             Where Lch.Batch_Code = p_Batch_Code)
       and exists (select 1 from t_pln_item_property p
                    where p.item_id = lclw.item_id
                      and p.item_code = lclw.item_code
                      and p.cannot_walkthrough_flag = 'Y');
    
    --更新订单行引预排接口标志
    Update t_Pln_Lg_Collect_Line_Wt Lclw
       Set Lclw.Walkthrough_State       = 'P',
           Lclw.To_Aps_Wt_Qty           = Lclw.To_Plnorder_Qty,
           Lclw.Walkthrough_Import_Date = Sysdate,
           Lclw.Last_Updated_By         = p_User_Code,
           Lclw.Last_Update_Date        = Sysdate,
           Lclw.Version                 = Nvl(Lclw.Version, 0) + 1
     Where NVL(lclw.no_need_walkthrough, 'N') <> 'Y' --hejy3 T+3优化 只更新参与预排的明细
       and Lclw.Collect_Head_Id In
           (Select Lch.Collect_Head_Id
              From t_Pln_Lg_Collect_Head Lch
             Where Lch.Batch_Code = p_Batch_Code);
  Exception
    When v_Base_Exception Then
      p_Result := p_Result;
      Rollback;
    When Others Then
      p_Result := p_Result || v_Nl || Sqlerrm;
      Rollback;
  End;
  ----------------------------------------------------------------------
  -- Author  : ex_dengjh
  -- Created : 2017-04-10
  -- Purpose : 更新未处理的接口数据版本
  ----------------------------------------------------------------------                                     
 Procedure P_UPD_INTF_CAPA_DATA_VERSION(IN_DATA_VERSION in varchar2) is
 begin
   UPDATE INTF_PLN_MONTH_REMAIN_CAPACITY C
      SET C.DATA_VERSION     = IN_DATA_VERSION,
          C.LAST_UPDATED_BY  = 'admin',
          C.LAST_UPDATE_DATE = SYSDATE
    WHERE C.INTF_STATE = 'N';
 end;
 
 ----------------------------------------------------------------------
  -- Author  : ex_dengjh
  -- Created : 2017-04-10
  -- Purpose : 更新接口数据到月剩余产能接口表
  ----------------------------------------------------------------------                                     
  Procedure P_INTF_CREATE_REMAIN_CAPACITY(IN_DATA_VERSION in varchar2) is
    r_pln_month_cap T_PLN_MONTH_REMAIN_CAPACIT%rowtype;
    v_Err_Msg       varchar2(400);
    v_action        varchar2(100);
  begin
    for r_org in (select distinct c.mrp_org_code
                    from INTF_PLN_MONTH_REMAIN_CAPACITY c
                   where c.data_version = IN_DATA_VERSION
                     AND C.INTF_STATE = 'N') loop
      begin
        --将正式表数据插入到历史表中
        insert into T_PLN_MONTH_REMAIN_CAPACIT_HIS
          SELECT * FROM T_PLN_MONTH_REMAIN_CAPACIT T where t.mrp_org_code = r_org.mrp_org_code;
        --删除正式表数据
        delete T_PLN_MONTH_REMAIN_CAPACIT T where 1 = 1 and t.mrp_org_code = r_org.mrp_org_code;
      exception
        when others then
          raise v_Base_Exception;
      end;
      for r_cap in (select *
                      from INTF_PLN_MONTH_REMAIN_CAPACITY c
                     where c.data_version = IN_DATA_VERSION
                       and c.mrp_org_code = r_org.mrp_org_code
                       AND C.INTF_STATE = 'N') loop
        v_Err_Msg := null;
        begin
          v_action := '1.获取主体ID';
          select e.entity_id
            into r_pln_month_cap.entity_id
            from v_bd_entity e
           where e.entity_code = r_cap.entity_code;
          v_action := '2.获取库存组织ID和名称';
          select io.organization_id, io.organization_name, io.organization_code
            into r_pln_month_cap.mrp_org_id, r_pln_month_cap.mrp_org_name, r_pln_month_cap.mrp_org_code
            from t_Inv_Organization io
           where io.organization_code = r_cap.mrp_org_code
             AND io.entity_id = r_pln_month_cap.entity_id;
          v_action := '3.获取产品名称';
          select i.item_name, i.item_code
            into r_pln_month_cap.item_name, r_pln_month_cap.item_code
            from t_bd_item i
           where i.item_code = r_cap.item_code
             and i.entity_id = r_pln_month_cap.entity_id;
          v_action := '4.获取月度编码和起始日期';
          PKG_PLN_PUB.p_Get_CurrentPeriodDate(p_entity_id                 => r_pln_month_cap.entity_id,
                                              in_cal_date                 => to_date(r_cap.period_date ||
                                                                                     '-01',
                                                                                     'YYYY-MM-DD'),
                                              p_current_period_begin_date => r_pln_month_cap.begin_date,
                                              p_current_period_end_date   => r_pln_month_cap.end_date);
          r_pln_month_cap.begin_date        := add_months(r_pln_month_cap.end_date,
                                                         -1) + 1;
          v_action                          := '5.复制借口数据到正式表';
          r_pln_month_cap.remain_capacit_id := s_PLN_MONTH_REMAIN_CAPACIT.Nextval;
          r_pln_month_cap.period_code       := r_cap.period_date;
          r_pln_month_cap.capacity_qty      := r_cap.capacity_qty;
          r_pln_month_cap.occupy_qty        := 0;
          r_pln_month_cap.pre_field_01      := r_cap.pre_field_01;
          r_pln_month_cap.pre_field_02      := r_cap.pre_field_02;
          r_pln_month_cap.pre_field_03      := r_cap.pre_field_03;
          r_pln_month_cap.pre_field_04      := r_cap.pre_field_04;
          r_pln_month_cap.pre_field_05      := r_cap.pre_field_05;
          r_pln_month_cap.pre_field_06      := r_cap.pre_field_06;
          r_pln_month_cap.remark            := r_cap.remark;
          r_pln_month_cap.created_by        := r_cap.created_by;
          r_pln_month_cap.creation_date     := sysdate;
          r_pln_month_cap.last_updated_by   := r_cap.last_updated_by;
          r_pln_month_cap.last_update_date  := sysdate;
          insert into T_PLN_MONTH_REMAIN_CAPACIT values r_pln_month_cap;
        
          update INTF_PLN_MONTH_REMAIN_CAPACITY mrc
             set mrc.intf_date = sysdate, mrc.intf_state = 'Y'
           where mrc.intf_id = r_cap.intf_id;
        exception
          when others then
            v_Err_Msg := v_action || '失败！' || v_Nl || sqlerrm;
            update INTF_PLN_MONTH_REMAIN_CAPACITY mrc
               set mrc.intf_date    = sysdate,
                   mrc.intf_state   = 'F',
                   mrc.intf_err_msg = v_Err_Msg
             where mrc.intf_id = r_cap.intf_id;
        end;
      end loop;
    end loop;
  exception
    When v_Base_Exception Then
      rollback;
    when others then
      null;
  end;
  ----------------------------------------------------------------------
  -- Author  : lilh6
  -- Created : 2017-09-14 
  -- Purpose : 定制订单明细写接口表
  ----------------------------------------------------------------------
  PROCEDURE P_CREATE_INTF_LG_ORDER_TO_OCM(P_ENTITY_ID IN NUMBER, --主体ID
                                          P_RESULT    OUT VARCHAR2) IS
    --返回结果
    V_INTF_ID NUMBER; --接口头id
  
  BEGIN
    P_RESULT := V_SUCCESS;
    --获取定制订单信息明细
    FOR R_PLN_LG_ORDER_TO_OCM IN (SELECT H.ENTITY_ID,
                                         L.ORDER_HEAD_ID,
                                         L.ORDER_LINE_ID,
                                         H.ORDER_NUMBER,
                                         H.ORDER_TYPE_CODE,
                                         H.ORDER_TYPE_NAME,
                                         H.ORDER_DATE,
                                         L.ITEM_CODE,
                                         L.ITEM_NAME,
                                         L.QUANTITY,
                                         A.MRP_ORG_ID
                                    FROM T_PLN_LG_ORDER_HEAD  H,
                                         T_PLN_LG_ORDER_LINE  L,
                                         T_PLN_PRODUCING_AREA A,
                                         T_PLN_ORDER_TYPE     OT
                                   WHERE H.ORDER_HEAD_ID = L.ORDER_HEAD_ID
                                     AND H.ORDER_TYPE_ID = OT.ORDER_TYPE_ID
                                     AND H.ENTITY_ID = P_ENTITY_ID
                                     AND OT.CUSTOMIZATION_FLAG = 'Y'
                                     AND OT.SOURCE_ORDER_TYPE_ID = 1
                                     AND A.PRODUCING_AREA_ID =
                                         L.PRODUCING_AREA_ID
                                     AND NOT EXISTS
                                   (SELECT 1
                                            FROM INTF_PLN_LG_ORDER_TO_OCM OCM
                                           WHERE OCM.INTF_STATUS IN
                                                 ('N', 'P', 'S')
                                             AND OCM.ORDER_NUMBER =
                                                 H.ORDER_NUMBER
                                             AND OCM.ITEM_CODE = L.ITEM_CODE))
    
     LOOP
      --生成接口头ID
      SELECT S_INTF_PLN_LG_ORDER_TO_OCM.NEXTVAL INTO V_INTF_ID FROM DUAL;
      --插入订单信息到接口头表
      INSERT INTO INTF_PLN_LG_ORDER_TO_OCM
        (INTF_ID,
         ENTITY_ID,
         INTF_STATUS,
         INTF_DATE,
         ORDER_NUMBER,
         ORDER_TYPE_CODE,
         ORDER_TYPE_NAME,
         ORDER_DATE,
         ITEM_CODE,
         ITEM_NAME,
         QUANTITY,
         CREATED_BY,
         CREATION_DATE,
         LAST_UPDATED_BY,
         LAST_UPDATE_DATE,
         INV_ORG_ID)
      VALUES
        (V_INTF_ID,
         R_PLN_LG_ORDER_TO_OCM.ENTITY_ID,
         'N',
         SYSDATE,
         R_PLN_LG_ORDER_TO_OCM.ORDER_NUMBER,
         R_PLN_LG_ORDER_TO_OCM.ORDER_TYPE_CODE,
         R_PLN_LG_ORDER_TO_OCM.ORDER_TYPE_NAME,
         R_PLN_LG_ORDER_TO_OCM.ORDER_DATE,
         R_PLN_LG_ORDER_TO_OCM.ITEM_CODE,
         R_PLN_LG_ORDER_TO_OCM.ITEM_NAME,
         R_PLN_LG_ORDER_TO_OCM.QUANTITY,
         'admin',
         SYSDATE,
         'admin',
         SYSDATE,
         R_PLN_LG_ORDER_TO_OCM.MRP_ORG_ID);
    
      --插入选配信息到接口行表
      INSERT INTO INTF_PLN_LG_MATCH_TO_OCM
        (INTF_ID,
         INTF_LINE_ID,
         ENTITY_ID,
         INTF_STATUS,
         INTF_DATE,
         ITEM_MATC_ID,
         ITEM_MATC_NAME,
         ITEM_OPTION_ID,
         ITEM_OPTION_NAME,
         CREATED_BY,
         CREATION_DATE,
         LAST_UPDATED_BY,
         LAST_UPDATE_DATE,
         PRE_FIELD_01)
        SELECT V_INTF_ID,
               S_INTF_PLN_LG_MATCH_TO_OCM.NEXTVAL,
               OTM.ENTITY_ID,
               'N',
               SYSDATE,
               OTM.ITEM_MATC_ID,
               OTM.ITEM_MATC_NAME,
               OTM.ITEM_OPTION_ID,
               OTM.ITEM_OPTION_NAME,
               'ADMIN',
               SYSDATE,
               'ADMIN',
               SYSDATE,
               OTM.PRE_FIELD_01
          FROM T_PLN_LG_ORDER_ITEM_MATCH OTM
         WHERE OTM.ORDER_HEAD_ID = R_PLN_LG_ORDER_TO_OCM.ORDER_HEAD_ID
           AND OTM.ORDER_LINE_ID = R_PLN_LG_ORDER_TO_OCM.ORDER_LINE_ID;
    END LOOP;
  EXCEPTION
    WHEN OTHERS THEN
      P_RESULT := '定制订单信息写入接口表失败：' || V_NL || '失败信息：' || SQLERRM;
      ROLLBACK;
  END;
  ----------------------------------------------------------------------
  -- Author  : lilh6
  -- Created : 2018-1-24 
  -- Purpose : 定制订单信息写推送LMS接口表
  ----------------------------------------------------------------------
  PROCEDURE P_CREATE_INTF_LG_ORDER_TO_LMS(P_ENTITY_ID IN NUMBER, --主体ID
                                          P_RESULT    OUT VARCHAR2) IS
  BEGIN
    P_RESULT := V_SUCCESS;
    INSERT INTO INTF_PLN_LG_ORDER_TO_LMS
      (INTF_ID,
       ENTITY_ID,
       ORIGIN_NUMBER,
       ORIG_SYSTEM_ORDER_NUMBER,
       ORDER_DATE,
       FORM_STATUS,
       ADDR_NAME,
       CONSIGNEE_CONTRACT,
       CONSIGNEE_TEL,
       CUSTOMER_CODE,
       CUSTOMER_NAME,
       ITEM_CODE,
       ITEM_NAME,
       UOM_CODE,
       PACKINGSIZE,
       QUANTITY,
       TO_PLN_QUANTITY,
       CREATED_BY,
       CREATION_DATE,
       LAST_UPDATED_BY,
       LAST_UPDATE_DATE,
       INTF_STATUS,
       INTF_DATE)
      SELECT S_INTF_PLN_LG_ORDER_TO_LMS.NEXTVAL,
             P_ENTITY_ID,
             H.ORDER_NUMBER,
             H.SOURCE_ORDER_NUMBER,
             H.ORDER_DATE,
             H.ORDER_HEAD_STATE,
             H.CONSIGNEE_ADDR_NAME,
             H.CONSIGNEE_CONTRACT,
             H.CONSIGNEE_TEL,
             H.CUSTOMER_CODE,
             H.CUSTOMER_NAME,
             L.ITEM_CODE,
             L.ITEM_NAME,
             L.DEFAULT_UNIT,
             L.UNIT_VOLUME,
             L.QUANTITY,
             L.TO_PLN_QTY,
             'admin',
             SYSDATE,
             'admin',
             SYSDATE,
             'N',
             SYSDATE
        FROM T_PLN_LG_ORDER_HEAD H,
             T_PLN_LG_ORDER_LINE L,
             T_PLN_ORDER_TYPE    T
       WHERE H.ORDER_HEAD_ID = L.ORDER_HEAD_ID
         AND H.ORDER_TYPE_ID = T.ORDER_TYPE_ID
         AND T.CUSTOMIZATION_FLAG = 'Y'
         AND T.SOURCE_ORDER_TYPE_ID = 1
         AND H.ENTITY_ID = P_ENTITY_ID
         AND NOT EXISTS
       (SELECT 1
                FROM INTF_PLN_LG_ORDER_TO_LMS OTL
               WHERE OTL.INTF_STATUS IN ('N', 'P', 'S')
                 AND OTL.ORIGIN_NUMBER = H.ORDER_NUMBER);
	COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      P_RESULT := '定制订单信息写入推送LMS接口表失败：' || V_NL || '失败信息：' || SQLERRM;
      ROLLBACK;
  END P_CREATE_INTF_LG_ORDER_TO_LMS;
  ----------------------------------------------------------------------
  -- Author  : lilh6
  -- Created : 2018-1-31
  -- Purpose : 超期订单信息写接口表
  ----------------------------------------------------------------------
  PROCEDURE P_CREATE_INTF_LG_OVERDUE_ORDER(P_ENTITY_ID IN NUMBER, --主体ID
                                           --P_FLAG      IN VARCHAR2, --线上线下标志
                                           P_RESULT    OUT VARCHAR2) IS
    V_LIMIT_DAYS     NUMBER; --限制天数
  BEGIN
    P_RESULT := V_SUCCESS;
    --获取限制天数，没有配置码表，默认没有限制天数
    BEGIN
      SELECT TO_NUMBER(UC.CODE_VALUE)
        INTO V_LIMIT_DAYS
        FROM UP_CODELIST UC, UP_CODELIST_ENTITY UCE
       WHERE UC.ID = UCE.CODELIST_ID
         AND UC.CODETYPE = 'pln_order_limit_days'
         AND UCE.ENTITY_ID = P_ENTITY_ID
         AND UCE.ENABLED = 0
         AND UC.ENABLED = 0;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        V_LIMIT_DAYS := 999999;
      WHEN OTHERS THEN
        V_LIMIT_DAYS := 999999;
    END;
    BEGIN
      INSERT INTO INTF_PLN_LG_OVERDUE_ORDER
        (INTF_ID,
         ENTITY_ID,
         intf_status,
         ORIGIN_NUMBER, --CIMS系统的单据号
         ORIG_SYSTEM_ORDER_NUMBER, --源系统的单据号
         ORDER_DATE, --订单日期
         LIMIT_DAYS, --限制天数
         EXCEED_DAYS, --超期天数
         REMIND_MESSAGE, --超期信息提示
         BUSINESS_CONTROL, --业务类型：区分线上还是线下订单
         CREATED_BY,
         CREATION_DATE,
         LAST_UPDATED_BY,
         LAST_UPDATE_DATE)
        SELECT S_INTF_PLN_LG_OVERDUE_ORDER.NEXTVAL,
               P_ENTITY_ID,
               'I',
               LOH.ORDER_NUMBER,
               LOH.ORIGIN_ORDER_NUMBER,
               LOH.ORDER_DATE,
               V_LIMIT_DAYS,
               TRUNC(SYSDATE) - TRUNC(OH.CREATION_DATE) - V_LIMIT_DAYS,
               '该订单超总部设定的最迟中转入库日期' || to_char(TRUNC(SYSDATE) -
               TRUNC(OH.CREATION_DATE) - V_LIMIT_DAYS) || '天',
               T.IS_BUSINESS_CONTROL,
               'CIMS',
               SYSDATE,
               'CIMS',
               SYSDATE
          FROM T_PLN_LG_ORDER_HEAD LOH,
               T_PLN_LG_RELATION   R,
               T_PLN_ORDER_TYPE    T,
               T_PLN_ORDER_HEAD    OH
         WHERE LOH.ORDER_HEAD_ID = R.LG_ORDER_HEAD_ID
           AND OH.ORDER_HEAD_ID = R.ORDER_HEAD_ID
           AND LOH.ORDER_TYPE_ID = T.ORDER_TYPE_ID
           AND LOH.ENTITY_ID = P_ENTITY_ID
           --AND T.IS_BUSINESS_CONTROL = P_FLAG
           AND t.customization_flag = 'Y'
           AND loh.order_date >= TRUNC(SYSDATE) - 60
           AND TRUNC(SYSDATE) - TRUNC(OH.CREATION_DATE) - V_LIMIT_DAYS > 0
           AND EXISTS (SELECT 1
                  FROM T_PLN_ORDER_LINE L
                 WHERE L.ORDER_HEAD_ID = OH.ORDER_HEAD_ID
                 GROUP BY L.ORDER_HEAD_ID
                HAVING SUM(NVL(L.SUPPLY_QTY, 0)) = 0);
      COMMIT;
    EXCEPTION
      WHEN OTHERS THEN
        RAISE V_BASE_EXCEPTION;
    END;
  EXCEPTION
    WHEN V_BASE_EXCEPTION THEN
      P_RESULT := '超期订单信息写入接口表失败：' || V_NL || '失败信息：' || SQLERRM;
      ROLLBACK;
    WHEN OTHERS THEN
      P_RESULT := '超期订单信息写入接口表失败：' || V_NL || '失败信息：' || SQLERRM;
      ROLLBACK;
  END P_CREATE_INTF_LG_OVERDUE_ORDER;
  ----------------------------------------------------------------------
  -- Author  : lilh6
  -- Created : 2018-4-10
  -- Purpose : 写入产品选配信息
  ----------------------------------------------------------------------
  Procedure p_Create_Item_Match_Relation(p_Result Out Varchar2) Is
    v_Count Number; --计数
  Begin
    p_Result := v_Success;
    For r_Relation In (Select Distinct r.Entity_Id,
                                       r.Item_Code,
                                       r.Item_Name,
                                       r.Item_Match_Code,
                                       r.Item_Match_Name,
                                       r.Item_Option_Code,
                                       r.Item_Option_Name,
                                       r.Active_Flag,
                                       r.Created_By,
                                       r.Last_Updated_By
                         From Intf_Item_Match_Relation r
                        Where r.Intf_Status = 'I') Loop
    
      Select Count(*)
        Into v_Count
        From t_Item_Match_Relation Mr
       Where Mr.Item_Code = r_Relation.Item_Code
         And Mr.Item_Match_Code = r_Relation.Item_Match_Code
         And Mr.Item_Option_Code = r_Relation.Item_Option_Code
         And Mr.Entity_Id = r_Relation.Entity_Id;
      If v_Count > 0 Then
        --有数据，则更新有效标示
        Update t_Item_Match_Relation Mr
           Set Mr.Active_Flag      = r_Relation.Active_Flag,
               Mr.Last_Updated_By  = 'CMS',
               Mr.Last_Update_Date = Sysdate
         Where Mr.Item_Code = r_Relation.Item_Code
           And Mr.Item_Match_Code = r_Relation.Item_Match_Code
           And Mr.Item_Option_Code = r_Relation.Item_Option_Code
           And Mr.Entity_Id = r_Relation.Entity_Id;
      Else
        --没有数据则插入新的选配项信息
        Insert Into t_Item_Match_Relation
          (Id,
           Entity_Id,
           Item_Code,
           Item_Name,
           Item_Match_Code,
           Item_Match_Name,
           Item_Option_Code,
           Item_Option_Name,
           Active_Flag,
           Created_By,
           Creation_Date,
           Last_Updated_By,
           Last_Update_Date)
        Values
          (s_Item_Match_Relation.Nextval,
           r_Relation.Entity_Id,
           r_Relation.Item_Code,
           r_Relation.Item_Name,
           r_Relation.Item_Match_Code,
           r_Relation.Item_Match_Name,
           r_Relation.Item_Option_Code,
           r_Relation.Item_Option_Name,
           r_Relation.Active_Flag,
           r_Relation.Created_By,
           Sysdate,
           r_Relation.Last_Updated_By,
           Sysdate);
      End If;
    End Loop;
    --更新选配项与定制机关系表
    --先删除
    Delete From t_Pln_Option_Item_Match m
     Where 1 = 1
       And Exists
     (Select 1
              From t_Item_Match_Relation r, Intf_Item_Match_Relation Rr
             Where r.Item_Code = Rr.Item_Code
               And r.Item_Match_Code = Rr.Item_Match_Code
               And r.Item_Option_Code = Rr.Item_Option_Code
               And r.Entity_Id = Rr.Entity_Id
               And Rr.Intf_Status = 'I'
               And r.Id = m.Item_Match_Relation_Id
               And r.Entity_Id = m.Entity_Id);
    --重新插入选配项与定制机关系
    Insert Into t_Pln_Option_Item_Match
      (Id,
       Entity_Id,
       Item_Match_Relation_Id,
       Custom_Made_Item_Code,
       Created_By,
       Creation_Date,
       Last_Updated_By,
       Last_Update_Date)
      Select s_Pln_Option_Item_Match.Nextval,
             r.Entity_Id,
             r.Id,
             Rr.Custom_Made_Item_Code,
             'CIMS',
             Sysdate,
             'CIMS',
             Sysdate
        From t_Item_Match_Relation r, Intf_Item_Match_Relation Rr
       Where r.Item_Code = Rr.Item_Code
         And r.Item_Match_Code = Rr.Item_Match_Code
         And r.Item_Option_Code = Rr.Item_Option_Code
         And r.Entity_Id = Rr.Entity_Id
         And Rr.Custom_Made_Item_Code Is Not Null
         And Rr.Intf_Status = 'I';
    --处理完成更新接口状态
    Update Intf_Item_Match_Relation r
       Set r.Intf_Status      = 'S',
           r.Last_Updated_By  = 'CIMS',
           r.Last_Update_Date = Sysdate
     Where r.Intf_Status = 'I';
  Exception
    When Others Then
      p_Result := '选配信息写入正式表失败失败：' || v_Nl || '错误信息：' || Sqlerrm ||
                  Substr(Dbms_Utility.Format_Error_Backtrace, 1, 200);
  End p_Create_Item_Match_Relation;
  
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2018-07-04
  *     创建者：周建刚
  *   功能说明：批量处理预约信息。
  *             按照中心+客户+地址+预约日期+客户预约单号维度汇总生成IMS预约单号
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_BOOK_INFO_TO_BATCH(P_BATCH_ID         IN NUMBER,   --批处理ID
                                 P_USER_CODE        IN VARCHAR2, --操作用户编码
                                 P_BOOK_NUM_RESULT  OUT VARCHAR2, --该批次生成的预约单号
                                 P_RESULT           OUT NUMBER,  --返回错误ID
                                 P_ERR_MSG          OUT VARCHAR2 --返回错误信息
                                 ) IS
    --是否需要预约单据头
    V_NEED_CREATE_HEADER Varchar2(2) := v_True;
    V_HEADER_ID NUMBER := 0;
               
    --预约单据号
    V_BOOK_NUM          VARCHAR2(32);
    V_BOOK_TYPE_TMALL   VARCHAR2(32) := 'TMALL';
    V_BOOK_TYPE_JD      VARCHAR2(32) := 'JD';
    
    --外部预约单号
    V_OUT_BOOK_NUM      VARCHAR2(32); 
    
    --行政区划（省级、市级、县区编码、乡镇）
    V_PROVINCE_CODE VARCHAR2(100);
    V_CITY_CODE     VARCHAR2(100);
    V_DIST_CODE     VARCHAR2(100);
    V_TOWN_CODE     VARCHAR2(100);
    
    V_PROVINCE_NAME VARCHAR2(100);
    V_CITY_NAME     VARCHAR2(100);
    V_DIST_NAME     VARCHAR2(100);
    V_TOWN_NAME     VARCHAR2(100);
    
    --该批次生成的预约单号
    V_BOOK_NUM_RESULT   VARCHAR2(4000) := '预约单号：';
    V_BOOK_STATUS             T_PLN_BOOK_HEADER.BOOK_STATUS%TYPE;
    R_LG_SHIP_DOC             T_LG_SHIP_DOC%ROWTYPE;
    V_PLN_LG_ORDER_LINE_COUNT NUMBER;
    
    V_ITEM_IS_SET             VARCHAR2(2);
    
    V_ORDER_NUMBER            VARCHAR2(32);
    
    R_BD_ITEM T_BD_ITEM%ROWTYPE;
    
    V_BOOK_INFO_SPLIT_KEY VARCHAR2(4000) := ''; --预约单拆分标识
    V_BOOK_INFO_SPLIT_KEY_TEMP VARCHAR2(4000) := '';
    
    R_INTF_PLN_BOOK_HEADER INTF_PLN_BOOK_HEADER%ROWTYPE;
    
    V_BOOK_SPLIT_BY_ORDER_FLAG VARCHAR2(32) := 'N';
    
    R_PLN_BOOK_LINE T_PLN_BOOK_LINE%ROWTYPE;
    V_ITEM_CODE         CIMS.T_PLN_BOOK_LINE.ITEM_CODE%TYPE := '';
    V_ITEM_CODE_COUNT   NUMBER := 0;
    V_TO_OUT_SYS_BATCH_NUM_FLAG VARCHAR2(1000);--合并预约标识
    V_TO_OUT_SYS_BATCH_NUM_TMP  VARCHAR2(1000) := '';--合并预约标识，临时变量
  BEGIN
    P_RESULT  := 0;
    P_ERR_MSG := V_SUCCESS;

    SELECT IH.* INTO R_INTF_PLN_BOOK_HEADER FROM CIMS.INTF_PLN_BOOK_HEADER IH WHERE IH.BATCH_ID = P_BATCH_ID AND ROWNUM = 1;

    P_BOOK_INFO_CHECK(P_BATCH_ID,P_USER_CODE,P_RESULT,P_ERR_MSG);
    
    IF P_RESULT <> 0 THEN
       RAISE V_BASE_EXCEPTION;
    END IF;
    
    --预约单是否根据提货订单拆分标识
    BEGIN
      PKG_BD.P_GET_PARAMETER_VALUE('BOOK_SPLIT_BY_ORDER_FLAG',
                                   R_INTF_PLN_BOOK_HEADER.ENTITY_ID,
                                   NULL,
                                   NULL,
                                   V_BOOK_SPLIT_BY_ORDER_FLAG);
    EXCEPTION
      WHEN OTHERS THEN
        P_RESULT  := -58001;
        P_ERR_MSG := '主体参数[BOOK_SPLIT_BY_ORDER_FLAG],主体id:' ||
                     R_INTF_PLN_BOOK_HEADER.ENTITY_ID || '的参数设置异常，请检查！' || SQLERRM;
        RAISE V_BASE_EXCEPTION;
    END;
    
    FOR LINE IN(
                SELECT I.*
                  FROM INTF_PLN_BOOK_HEADER I
                 WHERE I.BATCH_ID = P_BATCH_ID
                   AND I.PROCESS_FLAG = 'N'
                 ORDER BY I.ENTITY_ID,NVL(I.OUT_BOOK_NUM,'-'),I.CUSTOMER_CODE,I.SALES_CENTER_CODE,I.CONSIGNEE_ADDR_NAME,
                              NVL(I.BOOK_DATE,TRUNC(SYSDATE)),NVL(I.RCV_INV_CODE,'-'),
                              NVL(I.RESERVATION_COLLECT_BOOK_FLAG,'N'),
                              NVL(I.COLLAGE_ORDER_NUM,'-'),
                              NVL(I.PRODUCING_DISTRICT_CODE,NVL(I.PRODUCING_AREA_CODE,'-')),NVL(I.OUT_ORDER_NUM,'-'),NVL(I.SRC_BILL_NUM,'-'),IS_MATERIAL
               ) LOOP
       
       IF (R_INTF_PLN_BOOK_HEADER.BOOK_TYPE = 'JD') THEN
         
         V_BOOK_INFO_SPLIT_KEY_TEMP := LINE.ENTITY_ID || LINE.CUSTOMER_CODE || LINE.SALES_CENTER_CODE || LINE.CONSIGNEE_ADDR_NAME
           || NVL(LINE.BOOK_DATE,TRUNC(SYSDATE)) || NVL(LINE.OUT_BOOK_NUM,'-') || NVL(LINE.RCV_INV_CODE,'-')
           || NVL(LINE.RESERVATION_COLLECT_BOOK_FLAG,'N') || NVL(LINE.COLLAGE_ORDER_NUM,'-') || NVL(LINE.PRODUCING_DISTRICT_CODE,NVL(LINE.PRODUCING_AREA_CODE,'-')) || LINE.OUT_ORDER_NUM || LINE.IS_MATERIAL;
           
       ELSIF (R_INTF_PLN_BOOK_HEADER.BOOK_TYPE = 'TMALL') THEN
         
         V_BOOK_INFO_SPLIT_KEY_TEMP := LINE.ENTITY_ID || LINE.CUSTOMER_CODE || LINE.SALES_CENTER_CODE || LINE.CONSIGNEE_ADDR_NAME
           || NVL(LINE.BOOK_DATE,TRUNC(SYSDATE)) || NVL(LINE.OUT_BOOK_NUM,'-') || NVL(LINE.RCV_INV_CODE,'-')
           || NVL(LINE.RESERVATION_COLLECT_BOOK_FLAG,'N') || NVL(LINE.COLLAGE_ORDER_NUM,'-') || NVL(LINE.PRODUCING_DISTRICT_CODE,NVL(LINE.PRODUCING_AREA_CODE,'-')) || LINE.IS_MATERIAL;
       
       ELSE
         
         V_BOOK_INFO_SPLIT_KEY_TEMP := LINE.ENTITY_ID || LINE.CUSTOMER_CODE || LINE.SALES_CENTER_CODE || LINE.CONSIGNEE_ADDR_NAME
           || NVL(LINE.BOOK_DATE,TRUNC(SYSDATE)) || NVL(LINE.OUT_BOOK_NUM,'-') || NVL(LINE.RCV_INV_CODE,'-')
           || NVL(LINE.RESERVATION_COLLECT_BOOK_FLAG,'N') || NVL(LINE.COLLAGE_ORDER_NUM,'-') || LINE.IS_MATERIAL;
       
       END IF;
       
       IF (V_BOOK_SPLIT_BY_ORDER_FLAG = 'Y') THEN
         V_BOOK_INFO_SPLIT_KEY_TEMP := V_BOOK_INFO_SPLIT_KEY_TEMP || '-' || NVL(LINE.OUT_ORDER_NUM,'-');
       END IF;

       --初始化
       IF (V_BOOK_INFO_SPLIT_KEY = '') THEN
         V_BOOK_INFO_SPLIT_KEY := V_BOOK_INFO_SPLIT_KEY_TEMP;
         V_NEED_CREATE_HEADER  := v_True;
       ELSE
         IF (V_BOOK_INFO_SPLIT_KEY = V_BOOK_INFO_SPLIT_KEY_TEMP) THEN
           V_NEED_CREATE_HEADER  := v_False;
         ELSE
           V_BOOK_INFO_SPLIT_KEY := V_BOOK_INFO_SPLIT_KEY_TEMP;
           V_NEED_CREATE_HEADER  := v_True;
         END IF;
       END IF;
                   
       /**
       防重校验：
       1、Z单按照整单预约，同一Z单只能出现在一张有效的预约单中
       2、提货订单明细预约：校验预约数量是否满足
       */
       IF (LINE.SRC_TYPE = 'SHIP_DOC') THEN
         SELECT H.*
           INTO R_LG_SHIP_DOC
           FROM T_LG_SHIP_DOC H
          WHERE H.SHIP_DOC_CODE = LINE.SRC_BILL_NUM
            AND ROWNUM = 1;
                     
         IF (V_NEED_CREATE_HEADER = v_True AND R_LG_SHIP_DOC.BOOK_NUM_CIMS IS NOT NULL) THEN
           P_ERR_MSG := '发货通知单[' || LINE.SRC_BILL_NUM || ']已经预约，对应预约单[' || R_LG_SHIP_DOC.BOOK_NUM_CIMS || ']，请勿重复预约！';
           RAISE V_BASE_EXCEPTION;
         END IF;
       ELSIF (LINE.SRC_TYPE = 'PLN_LG_ORDER') THEN
         
         IF (R_INTF_PLN_BOOK_HEADER.BOOK_TYPE <> 'JD') THEN
           SELECT COUNT(1)
             INTO V_PLN_LG_ORDER_LINE_COUNT
             FROM T_PLN_LG_ORDER_HEAD H, T_PLN_LG_ORDER_LINE L
            WHERE H.ORDER_HEAD_ID = L.ORDER_HEAD_ID
              AND (L.CENTER_AFFIRM_QUANTITY - NVL(L.AFFIRMED_QUANTITY, 0) -
                  NVL(L.CANCEL_QTY, 0) - (NVL(L.BOOK_TOTAL_QTY, 0) -
                      NVL(L.BOOK_AFFIRMED_QTY, 0))) < LINE.ITEM_QTY
              AND L.ORDER_HEAD_ID = LINE.SRC_HEADER_ID
              AND L.ORDER_LINE_ID = LINE.SRC_LINE_ID
              AND ROWNUM = 1;
                       
           IF (V_PLN_LG_ORDER_LINE_COUNT > 0) THEN
             P_ERR_MSG := '订单[' || LINE.SRC_BILL_NUM || ']中的产品[' || LINE.ITEM_CODE || ',' || LINE.ITEM_NAME || ']可预约数量不足，请核实！';
             RAISE V_BASE_EXCEPTION;
           END IF;
         END IF;

       END IF;
                                  
           IF ((LINE.BOOK_TYPE = V_BOOK_TYPE_TMALL OR LINE.BOOK_TYPE = V_BOOK_TYPE_JD)
              AND LINE.OUT_ORDER_NUM IS NULL) THEN
               P_ERR_MSG := '预约类型为‘天猫’或‘京东’的单据，对应的外部系统备货单号不能为空，请核实！单据号[' || LINE.SRC_BILL_NUM || ']';
           RAISE V_BASE_EXCEPTION;
       END IF;

       IF (LINE.PRODUCING_AREA_CODE IS NULL) THEN
           P_ERR_MSG := '产品[' || LINE.ITEM_CODE || ',' || LINE.ITEM_NAME || ']对应产地(基地)为空，请核实！单据号[' || LINE.SRC_BILL_NUM || ']';
           RAISE V_BASE_EXCEPTION;
       END IF;
    
       IF (V_NEED_CREATE_HEADER = v_True) THEN
                       
           --单据号前缀（用于单据号生成，取事业部2位编码）：用主体ID
           V_BOOK_NUM := PKG_BD.F_GET_BILL_NO('PLN_BOOK_NUM',
                                         LINE.ENTITY_ID,
                                         LINE.ENTITY_ID,
                                         NULL);
                       
           V_BOOK_NUM_RESULT := V_BOOK_NUM_RESULT || V_BOOK_NUM || ',';
                       
           V_HEADER_ID := S_PLN_BOOK_HEADER.NEXTVAL;
                       
           BEGIN
             --1-大区，2-省，自治区，3-市，4-县，5-乡镇
             V_PROVINCE_CODE := PKG_SO_PUB.F_GET_DISTRICT(LINE.CONSIGNEE_ADDR_CODE,2); 
             V_CITY_CODE := PKG_SO_PUB.F_GET_DISTRICT(LINE.CONSIGNEE_ADDR_CODE,3);
             V_DIST_CODE := PKG_SO_PUB.F_GET_DISTRICT(LINE.CONSIGNEE_ADDR_CODE,4);
             V_TOWN_CODE := PKG_SO_PUB.F_GET_DISTRICT(LINE.CONSIGNEE_ADDR_CODE,5);
                         
             SELECT D.DISTRICT_NAME INTO V_PROVINCE_NAME FROM CIMS.T_BD_DISTRICT D WHERE D.DISTRICT_CODE = V_PROVINCE_CODE AND ROWNUM = 1;
             SELECT D.DISTRICT_NAME INTO V_CITY_NAME FROM CIMS.T_BD_DISTRICT D WHERE D.DISTRICT_CODE = V_CITY_CODE AND ROWNUM = 1;
             SELECT D.DISTRICT_NAME INTO V_DIST_NAME FROM CIMS.T_BD_DISTRICT D WHERE D.DISTRICT_CODE = V_DIST_CODE AND ROWNUM = 1;
             SELECT D.DISTRICT_NAME INTO V_TOWN_NAME FROM CIMS.T_BD_DISTRICT D WHERE D.DISTRICT_CODE = V_TOWN_CODE AND ROWNUM = 1;
           EXCEPTION
             WHEN OTHERS THEN
               NULL;
           END;
                       
           --'00', '已审核';'01', '已确认';'02', '已取消';'03', '已关闭'
           V_BOOK_STATUS := '00';
           /**
           IF (LINE.BOOK_TYPE = 'COMMON') THEN
             V_BOOK_STATUS := '01';
           END IF;
           */
                       
           --预约结转类型单据
           IF (NVL(LINE.RESERVATION_COLLECT_BOOK_FLAG,'N') = v_True) THEN
             V_OUT_BOOK_NUM := V_BOOK_NUM;
           ELSE
             V_OUT_BOOK_NUM := LINE.OUT_BOOK_NUM;
           END IF;
                       
           INSERT INTO T_PLN_BOOK_HEADER(
              HEADER_ID         ,
              BOOK_NUM          ,
              OUT_BOOK_NUM      ,
              BOOK_TYPE         ,
              BOOK_STATUS       ,
              BOOK_DATE         ,
              SALES_CENTER_ID   ,
              SALES_CENTER_CODE ,
              SALES_CENTER_NAME ,
              CUSTOMER_ID       ,
              CUSTOMER_CODE     ,
              CUSTOMER_NAME     ,
              CONSIGNEE_ADDR_ID ,
              CONSIGNEE_ADDR    ,
              REMARK            ,
              CREATED_BY        ,
              CREATION_DATE     ,
              LAST_UPDATED_BY   ,
              LAST_UPDATE_DATE  ,
              VERSION           ,
              ENTITY_ID,
              TO_ECSCM_INTF_FLAG,
              CONSIGNEE_ADDR_CODE,   
              CONSIGNEE_PROVINCE_CODE,
              CONSIGNEE_CITY_CODE,
              CONSIGNEE_DISTRICT_CODE,
              CONSIGNEE_TOWN_CODE,
              CONSIGNEE_PROVINCE_NAME,
              CONSIGNEE_CITY_NAME,
              CONSIGNEE_DISTRICT_NAME,
              CONSIGNEE_TOWN_NAME,
              RCV_INV_CODE,
              RCV_INV_NAME,
              CONSIGNEE_CONTRACT,
              CONSIGNEE_TEL,
              RESERVATION_COLLECT_BOOK_FLAG,
              BATCH_ID,
              DELAY_BOOK_DATE_DAYS,
              OUT_SYS_BOOK_FLAG,
              IS_MATERIAL
           )
           VALUES
           (
           V_HEADER_ID,
           V_BOOK_NUM,
           V_OUT_BOOK_NUM,
           LINE.BOOK_TYPE,
           V_BOOK_STATUS,
           LINE.BOOK_DATE,
           LINE.SALES_CENTER_ID,
           LINE.SALES_CENTER_CODE,
           LINE.SALES_CENTER_NAME,
           LINE.CUSTOMER_ID,
           LINE.CUSTOMER_CODE,
           LINE.CUSTOMER_NAME,
           LINE.CONSIGNEE_ADDR_ID,
           LINE.CONSIGNEE_ADDR_NAME,
           LINE.REMARK,
           LINE.CREATED_BY,
           LINE.CREATION_DATE,
           LINE.LAST_UPDATED_BY,
           LINE.LAST_UPDATE_DATE,
           1,
           LINE.ENTITY_ID,
           v_False,
           LINE.CONSIGNEE_ADDR_CODE,
           V_PROVINCE_CODE,
           V_CITY_CODE,
           V_DIST_CODE,
           V_TOWN_CODE,
           V_PROVINCE_NAME,
           V_CITY_NAME,
           V_DIST_NAME,
           V_TOWN_NAME,
           LINE.RCV_INV_CODE,
           LINE.RCV_INV_NAME,
           LINE.CONSIGNEE_CONTRACT,
           LINE.CONSIGNEE_TEL,
           LINE.RESERVATION_COLLECT_BOOK_FLAG,
           LINE.BATCH_ID,
           LINE.DELAY_BOOK_DATE_DAYS,
           LINE.OUT_SYS_BOOK_FLAG,
           LINE.IS_MATERIAL
           );
           
       END IF;
                   
      SELECT I.*
        INTO R_BD_ITEM
        FROM CIMS.T_BD_ITEM I
       WHERE I.ENTITY_ID = LINE.ENTITY_ID
         AND I.ITEM_CODE = LINE.ITEM_CODE 
         AND ROWNUM = 1;
      
      IF (R_BD_ITEM.PRODUCTFORM = 'SET_PRODUCT') THEN
        V_ITEM_IS_SET := 'Y';
      ELSE
        V_ITEM_IS_SET := 'N';
      END IF;
                
       INSERT INTO T_PLN_BOOK_LINE(
          LINE_ID          ,
          HEADER_ID        ,
          SRC_TYPE         ,
          SRC_BILL_NUM     ,
          SRC_HEADER_ID    ,
          SRC_LINE_ID      ,
          OUT_ORDER_NUM    ,
          OUT_ORDER_SYS_SOURCE,
          ITEM_ID          ,
          ITEM_CODE        ,
          ITEM_NAME        ,
          ITEM_QTY         ,
          AFFIRMED_QUANTITY,
          REMARK           ,
          CREATED_BY       ,
          CREATION_DATE    ,
          LAST_UPDATED_BY  ,
          LAST_UPDATE_DATE ,
          VERSION          ,
          ENTITY_ID,
          PRODUCING_AREA_ID,
          PRODUCING_AREA_CODE,
          PRODUCING_AREA_NAME,
          UNIT_VOLUME,
          TOTAL_VOLUME,
          SHIP_INV_ID,
          SHIP_INV_CODE,
          SHIP_INV_NAME,
          PRODUCING_DISTRICT_ID,
          PRODUCING_DISTRICT_CODE,
          PRODUCING_DISTRICT_FULL_NAME,
          ITEM_IS_SET,
          SHIP_COLLAGE_ID,
          COLLAGE_ORDER_NUM,
          ITEM_BOX_QTY,
          PLN_LG_ORDER_NUMBER,
          DISTRIBUTION_CENTER_NAME,
          DISTRIBUTION_CENTER_CODE,
          DISTRIBUTION_WAREHOUSE_CODE,
          DISTRIBUTION_WAREHOUSE_NAME,
          ORIGIN_VERNDOR_CODE,
          ORIGIN_VERNDOR_NAME,
          ORIGIN_SALES_TYPE_CODE,
          ORIGIN_SALES_TYPE_NAME
       )
       VALUES
       (
       S_PLN_BOOK_LINE.NEXTVAL,
       V_HEADER_ID,
       LINE.SRC_TYPE,
       LINE.SRC_BILL_NUM,
       LINE.SRC_HEADER_ID,
       LINE.SRC_LINE_ID,
       LINE.OUT_ORDER_NUM,
       LINE.OUT_ORDER_SYS_SOURCE,
       LINE.ITEM_ID,
       LINE.ITEM_CODE,
       LINE.ITEM_NAME,
       LINE.ITEM_QTY,
       (DECODE(LINE.SRC_TYPE,'SHIP_DOC',LINE.ITEM_QTY,0)),
       NULL,
       LINE.CREATED_BY,
       LINE.CREATION_DATE,
       LINE.LAST_UPDATED_BY,
       LINE.LAST_UPDATE_DATE,
       1,
       LINE.ENTITY_ID,
       LINE.PRODUCING_AREA_ID,
       LINE.PRODUCING_AREA_CODE,
       LINE.PRODUCING_AREA_NAME,
       LINE.UNIT_VOLUME,
       NVL(LINE.UNIT_VOLUME,0) * LINE.ITEM_QTY,
       LINE.SHIP_INV_ID,
       LINE.SHIP_INV_CODE,
       LINE.SHIP_INV_NAME,
       LINE.PRODUCING_DISTRICT_ID,
       LINE.PRODUCING_DISTRICT_CODE,
       LINE.PRODUCING_DISTRICT_FULL_NAME,
       V_ITEM_IS_SET,
       LINE.SHIP_COLLAGE_ID,
       LINE.COLLAGE_ORDER_NUM,
       CEIL(LINE.ITEM_QTY/NVL(R_BD_ITEM.ROUNDING_CNT,1)),
       LINE.PLN_LG_ORDER_NUMBER,
       LINE.DISTRIBUTION_CENTER_NAME,
       LINE.DISTRIBUTION_CENTER_CODE,
       LINE.DISTRIBUTION_WAREHOUSE_CODE,
       LINE.DISTRIBUTION_WAREHOUSE_NAME,
       LINE.ORIGIN_VERNDOR_CODE,
       LINE.ORIGIN_VERNDOR_NAME,
       LINE.ORIGIN_SALES_TYPE_CODE,
       LINE.ORIGIN_SALES_TYPE_NAME
       );
                  
      --来源类型：SHIP_DOC 发货通知单；PLN_LG_ORDER 提货订单
      IF (LINE.SRC_TYPE = 'PLN_LG_ORDER') THEN
        UPDATE T_PLN_LG_ORDER_LINE L
           SET L.BOOK_TOTAL_QTY   = NVL(L.BOOK_TOTAL_QTY, 0) + LINE.ITEM_QTY,
               L.BOOK_NUM_CIMS    = V_BOOK_NUM,
               L.BOOK_REQUEST     = LINE.OUT_BOOK_NUM,
               L.LAST_UPDATED_BY  = P_USER_CODE,
               L.LAST_UPDATE_DATE = SYSDATE,
               L.VERSION          = NVL(L.VERSION, 0) + 1
         WHERE L.ORDER_LINE_ID = LINE.SRC_LINE_ID;
      ELSIF (LINE.SRC_TYPE = 'SHIP_DOC') THEN
        UPDATE T_LG_SHIP_DOC H
           SET H.BOOK_ORDER_NUM           = LINE.OUT_BOOK_NUM,
               H.BOOK_NUM_CIMS            = V_BOOK_NUM,
               H.BOOK_RECEIPT_DATE        = NVL(H.BOOK_RECEIPT_DATE,LINE.BOOK_DATE),
               H.LAST_UPDATED_BY          = P_USER_CODE,
               H.LAST_UPDATE_DATE         = SYSDATE
         WHERE H.SHIP_DOC_CODE = LINE.SRC_BILL_NUM;
                    
        UPDATE T_LG_SHIP_DOC_LINE L
           SET L.BOOK_ORDER_NUM   = LINE.OUT_BOOK_NUM,
               L.BOOK_TOTAL_QTY   = NVL(L.BOOK_TOTAL_QTY,0) + LINE.ITEM_QTY,
               L.LAST_UPDATED_BY  = P_USER_CODE,
               L.LAST_UPDATE_DATE = SYSDATE
         WHERE L.SHIP_DOC_LINE_ID = LINE.SRC_LINE_ID;

      END IF;
                
    END LOOP;
    
    UPDATE T_PLN_BOOK_HEADER H
       SET H.TOTAL_VOLUME    =
           (SELECT SUM(NVL(L.TOTAL_VOLUME, 0))
              FROM T_PLN_BOOK_LINE L
             WHERE L.HEADER_ID = H.HEADER_ID),
           H.TOTAL_ITEM_QTY  = (SELECT SUM(NVL(L.ITEM_QTY, 0))
              FROM T_PLN_BOOK_LINE L
             WHERE L.HEADER_ID = H.HEADER_ID),
           H.TOTAL_ITEM_BOX_QTY  = (SELECT SUM(NVL(L.ITEM_BOX_QTY, 0))
              FROM T_PLN_BOOK_LINE L
             WHERE L.HEADER_ID = H.HEADER_ID),
           H.LAST_UPDATE_DATE = SYSDATE
     WHERE H.BATCH_ID = P_BATCH_ID;
    
    UPDATE INTF_PLN_BOOK_HEADER I
       SET I.PROCESS_FLAG = v_True, I.LAST_UPDATE_DATE = SYSDATE
     WHERE I.BATCH_ID = P_BATCH_ID
       AND I.PROCESS_FLAG = v_False;

    --京东预约类型，合并预约标识
    P_BOOK_UPDATE_OUT_BATCH_NUM(R_INTF_PLN_BOOK_HEADER.ENTITY_ID,
                                P_BATCH_ID,
                                P_USER_CODE,
                                P_RESULT,
                                P_ERR_MSG);
    
    IF P_RESULT <> 0 THEN
       RAISE V_BASE_EXCEPTION;
    END IF;
    
    --预约单据引入ECSCM接口表     
    P_BOOK_INFO_2_ECSCM(P_BATCH_ID,
                        P_RESULT,
                        P_ERR_MSG);
    
    IF P_RESULT <> 0 THEN
       RAISE V_BASE_EXCEPTION;
    END IF;
    
    P_BOOK_NUM_RESULT := SUBSTR(V_BOOK_NUM_RESULT,0,LENGTH(V_BOOK_NUM_RESULT) - 1);
    
    --常规预约类型，自动确认
    FOR BOOK_HEADER_REC IN (SELECT H.*
                  FROM T_PLN_BOOK_HEADER H
                 WHERE H.BOOK_TYPE = 'COMMON'
                  AND H.BATCH_ID = P_BATCH_ID
                ) LOOP
                
        P_BOOK_RESULT_HANDLE('confirm',
                             BOOK_HEADER_REC.BOOK_NUM,
                             BOOK_HEADER_REC.OUT_BOOK_NUM,
                             TO_CHAR(BOOK_HEADER_REC.BOOK_DATE,'yyyy-MM-dd'),
                             NULL,
                             NVL(P_USER_CODE,'CIMS'),
                             P_RESULT,
                             P_ERR_MSG);

        IF P_RESULT <> 0 THEN
           RAISE V_BASE_EXCEPTION;
        END IF;
		
    END LOOP;
    
    --京东预约类型，只有提货订单整单预约一种操作方式。预约单创建时更新对应发货计划、发货通知单：预约日期、YY单号。
    FOR REC IN (SELECT H.ENTITY_ID,L.SRC_TYPE,L.ITEM_CODE,L.ITEM_QTY, L.SRC_BILL_NUM, H.BOOK_NUM, H.BOOK_DATE
                            FROM CIMS.T_PLN_BOOK_LINE L, CIMS.T_PLN_BOOK_HEADER H
                           WHERE H.HEADER_ID = L.HEADER_ID
                             AND H.BOOK_TYPE = 'JD'
                             AND H.BATCH_ID = P_BATCH_ID
                             AND L.SRC_TYPE = 'PLN_LG_ORDER'
                          ) LOOP
        
        /*UPDATE T_PLN_LG_ORDER_LINE L
           SET L.BOOK_TOTAL_QTY   = L.QUANTITY - NVL(L.CANCEL_QTY,0),
               L.BOOK_RECEIPT_DATE = REC.BOOK_DATE,
               L.LAST_UPDATED_BY  = NVL(P_USER_CODE,'CIMS'),
               L.LAST_UPDATE_DATE = SYSDATE,
               L.VERSION          = NVL(L.VERSION, 0) + 1
         WHERE EXISTS (SELECT 1 FROM CIMS.T_PLN_LG_ORDER_HEAD H
           WHERE H.ORDER_HEAD_ID = L.ORDER_HEAD_ID AND H.ORDER_NUMBER = REC.SRC_BILL_NUM);*/
        
        UPDATE T_LG_SHIP_DOC_LINE L
           SET L.BOOK_TOTAL_QTY   = L.ITEM_QTY,
               L.LAST_UPDATED_BY  = NVL(P_USER_CODE,'CIMS'),
               L.LAST_UPDATE_DATE = SYSDATE
         WHERE EXISTS
         (SELECT 1
                  FROM CIMS.T_LG_SHIP_DOC H
                 WHERE L.SHIP_DOC_ID = H.SHIP_DOC_ID
                   AND ((H.ORIGIN_ORIGIN_TYPE = '02' AND
                       H.ORIGIN_ORIGIN_ORDER_CODE = REC.SRC_BILL_NUM) OR
                       (H.ORIGIN_TYPE = '02' AND
                       H.ORIGIN_ORDER_NUM = REC.SRC_BILL_NUM))
                   AND L.ITEM_CODE = REC.ITEM_CODE);
                
        UPDATE T_LG_SHIP_DOC H
           SET H.BOOK_RECEIPT_DATE = REC.BOOK_DATE,
               H.BOOK_NUM_CIMS     = REC.BOOK_NUM,
               H.LAST_UPDATED_BY   = NVL(P_USER_CODE,'CIMS'),
               H.LAST_UPDATE_DATE  = SYSDATE
         WHERE ((H.ORIGIN_ORIGIN_TYPE = '02' AND H.ORIGIN_ORIGIN_ORDER_CODE = REC.SRC_BILL_NUM)
                 OR (H.ORIGIN_TYPE = '02' AND H.ORIGIN_ORDER_NUM = REC.SRC_BILL_NUM))
           AND H.ENTITY_ID = REC.ENTITY_ID;
                
        UPDATE T_LG_SHIP_PLAN P
           SET P.BOOK_NUM_CIMS    = REC.BOOK_NUM,
               P.BOOK_RECEIPT_DATE = REC.BOOK_DATE,
               P.LAST_UPDATED_BY = NVL(P_USER_CODE,'CIMS'),
               P.LAST_UPDATE_DATE = SYSDATE
         WHERE ((P.ORIGIN_ORIGIN_TYPE = '02' AND P.ORIGIN_ORIGIN_ORDER_CODE = REC.SRC_BILL_NUM) 
                 OR (P.ORIGIN_TYPE = '02' AND P.ORIGIN_ORDER_NUM = REC.SRC_BILL_NUM))
           AND P.ENTITY_ID = REC.ENTITY_ID;
        
    END LOOP;
    
  EXCEPTION
    WHEN V_BASE_EXCEPTION THEN
      P_RESULT  := -27001;
      P_ERR_MSG := '处理预约信息出错：' || P_ERR_MSG;
    WHEN OTHERS THEN
      P_RESULT  := -27001;
      P_ERR_MSG := '处理预约信息，发生异常：' || NVL(P_ERR_MSG,' ') || SQLERRM;
  END P_BOOK_INFO_TO_BATCH;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2019-04-12
  *     创建者：周建刚
  *   功能说明：预约单信息自动补全和校验。
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_BOOK_INFO_CHECK(P_BATCH_ID         IN NUMBER,   --批处理ID
                              P_USER_CODE        IN VARCHAR2, --操作用户编码
                              P_RESULT           OUT NUMBER,  --返回错误ID
                              P_ERR_MSG          OUT VARCHAR2 --返回错误信息
                              ) IS 
    V_BOOK_TYPE_TMALL                VARCHAR2(32) := 'TMALL';
    V_BOOK_TYPE_JD                   VARCHAR2(32) := 'JD';
    V_BOOK_TYPE_COMMON               VARCHAR2(32) := 'COMMON';
    V_ORIGIN_ORDER_STATUS_DELETE     VARCHAR2(32) := 'DELETE';
    
    V_BOOK_TYPE_TOTAL   NUMBER := 0;
    
    R_PLN_LG_ORDER_HEAD T_PLN_LG_ORDER_HEAD%ROWTYPE;
    R_LG_SHIP_DOC       T_LG_SHIP_DOC%ROWTYPE;
    V_PLN_LG_ORDER_NUMBER T_PLN_LG_ORDER_HEAD.ORDER_NUMBER%TYPE;
    V_BOOK_NUM_TOTAL      VARCHAR2(3000) := '';
    V_BL_ITEM_QTY_TOTAL   NUMBER         := 0;
    V_OL_ITEM_QTY_TOTAL   NUMBER         := 0;
  BEGIN
    P_RESULT  := 0;
    P_ERR_MSG := V_SUCCESS;

    SELECT COUNT(1) INTO V_BOOK_TYPE_TOTAL
      FROM (SELECT DISTINCT IH.BOOK_TYPE
              FROM CIMS.INTF_PLN_BOOK_HEADER IH
             WHERE IH.BATCH_ID = P_BATCH_ID);
    
    IF (V_BOOK_TYPE_TOTAL > 1) THEN
       P_ERR_MSG := '存在预约类型不同的单据（提货订单/发货通知单）请核实！';
       RAISE V_BASE_EXCEPTION;
    END IF;
    
    BEGIN

      UPDATE CIMS.INTF_PLN_BOOK_HEADER IH
         SET (IH.PRODUCING_DISTRICT_ID,
              IH.PRODUCING_DISTRICT_CODE,
              IH.PRODUCING_DISTRICT_FULL_NAME) =
             (SELECT PA.DISTRICT_ID, PA.DISTRICT_CODE, PA.DISTRICT_FULL_NAME
                FROM CIMS.T_PLN_PRODUCING_AREA PA
               WHERE IH.ENTITY_ID = PA.ENTITY_ID
                 AND IH.PRODUCING_AREA_CODE = PA.PRODUCING_AREA_CODE
                 AND ROWNUM = 1)
       WHERE IH.BATCH_ID = P_BATCH_ID;

      UPDATE CIMS.INTF_PLN_BOOK_HEADER IH
         SET (IH.PRODUCING_AREA_ID,
              IH.PRODUCING_AREA_CODE,
              IH.PRODUCING_AREA_NAME,
              IH.PRODUCING_DISTRICT_ID,
              IH.PRODUCING_DISTRICT_CODE,
              IH.PRODUCING_DISTRICT_FULL_NAME,
              IH.IS_MATERIAL) =
             (SELECT PA.PRODUCING_AREA_ID,
                     PA.PRODUCING_AREA_CODE,
                     PA.PRODUCING_AREA_NAME,
                     PA.DISTRICT_ID,
                     PA.DISTRICT_CODE,
                     PA.DISTRICT_FULL_NAME,
                     'Y'
                FROM CIMS.T_PLN_BOOK_PRODUCING_AREA PA
               WHERE IH.ENTITY_ID = PA.ENTITY_ID
                 AND PA.PRODUCING_AREA_CODE LIKE 'S%'
                 AND ROWNUM = 1)
       WHERE IH.PRODUCING_DISTRICT_CODE IS NULL
         AND IH.BATCH_ID = P_BATCH_ID
         AND EXISTS (SELECT 1
                FROM CIMS.T_BD_ITEM BI
               WHERE NVL(BI.IS_MATERIAL, 'N') = 'Y'
                 AND IH.ENTITY_ID = BI.ENTITY_ID
                 AND IH.ITEM_CODE = BI.ITEM_CODE);

      --自动补全供应商、配送中心、配送仓库
      UPDATE CIMS.INTF_PLN_BOOK_HEADER IH
         SET (IH.ORIGIN_VERNDOR_CODE,
              IH.ORIGIN_VERNDOR_NAME,
              IH.DISTRIBUTION_CENTER_NAME,
              IH.DISTRIBUTION_CENTER_CODE,
              IH.DISTRIBUTION_WAREHOUSE_CODE,
              IH.DISTRIBUTION_WAREHOUSE_NAME,
              IH.ORIGIN_SALES_TYPE_CODE,
              IH.ORIGIN_SALES_TYPE_NAME) =
             (SELECT H.ORIGIN_VERNDOR_CODE,
                     H.ORIGIN_VERNDOR_NAME,
                     H.DISTRIBUTION_CENTER_NAME,
                     H.DISTRIBUTION_CENTER_CODE,
                     H.DISTRIBUTION_WAREHOUSE_CODE,
                     H.DISTRIBUTION_WAREHOUSE_NAME,
                     H.ORIGIN_SALES_TYPE_CODE,
                     H.ORIGIN_SALES_TYPE_NAME
                FROM CIMS.T_PLN_LG_ORDER_HEAD H
               WHERE H.ORIGIN_ORDER_NUMBER = IH.OUT_ORDER_NUM
                 AND ROWNUM = 1)
       WHERE IH.BATCH_ID = P_BATCH_ID;
      
      --自动补全提货订单号(提货订单方式预约)
      UPDATE CIMS.INTF_PLN_BOOK_HEADER IH
         SET IH.PLN_LG_ORDER_NUMBER = IH.SRC_BILL_NUM
       WHERE IH.SRC_TYPE = 'PLN_LG_ORDER' AND IH.BATCH_ID = P_BATCH_ID;

      FOR REC IN (
                  SELECT I.*
                    FROM INTF_PLN_BOOK_HEADER I
                   WHERE I.BATCH_ID = P_BATCH_ID
                     AND I.PLN_LG_ORDER_NUMBER IS NULL
                  ) LOOP
                  
        --通知单自动补全提货订单号信息
        IF (REC.SRC_TYPE = 'SHIP_DOC') THEN
          SELECT D.*
            INTO R_LG_SHIP_DOC
            FROM CIMS.T_LG_SHIP_DOC D
           WHERE D.SHIP_DOC_CODE = REC.SRC_BILL_NUM;
          
          IF (R_LG_SHIP_DOC.ORIGIN_ORIGIN_TYPE = '02') THEN
            V_PLN_LG_ORDER_NUMBER := R_LG_SHIP_DOC.ORIGIN_ORIGIN_ORDER_CODE;
          END IF;
          
          IF (V_PLN_LG_ORDER_NUMBER IS NULL AND R_LG_SHIP_DOC.ORIGIN_TYPE = '02') THEN
            V_PLN_LG_ORDER_NUMBER := R_LG_SHIP_DOC.ORIGIN_ORDER_NUM;
          END IF;
          
          IF (V_PLN_LG_ORDER_NUMBER IS NOT NULL) THEN
            UPDATE INTF_PLN_BOOK_HEADER I
               SET I.PLN_LG_ORDER_NUMBER = V_PLN_LG_ORDER_NUMBER
             WHERE I.BATCH_ID = P_BATCH_ID
               AND I.INTF_HEADER_ID = REC.INTF_HEADER_ID;
          END IF;
          
          V_PLN_LG_ORDER_NUMBER := NULL;
        END IF;
      END LOOP;
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;
    
    FOR REC IN (
                SELECT I.*
                  FROM INTF_PLN_BOOK_HEADER I
                 WHERE I.BATCH_ID = P_BATCH_ID
                ) LOOP
                
      --校验外部预约单号、预约类型
      IF (REC.BOOK_TYPE = V_BOOK_TYPE_TMALL OR REC.BOOK_TYPE = V_BOOK_TYPE_JD) THEN
        IF (REC.OUT_BOOK_NUM IS NOT NULL) THEN
          P_ERR_MSG := '预约类型为‘天猫’或‘京东’的单据，无需填写外部系统预约单号！';
          RAISE V_BASE_EXCEPTION;
        END IF;
      ELSIF (REC.BOOK_TYPE = V_BOOK_TYPE_COMMON) THEN
        IF (REC.OUT_BOOK_NUM IS NULL) THEN
          P_ERR_MSG := '普通预约类型的单据，外部系统预约单号为必填项。请填写外部系统预约单号！';
          RAISE V_BASE_EXCEPTION;
        END IF;
      END IF;
      
      IF (REC.PLN_LG_ORDER_NUMBER IS NOT NULL) THEN
        SELECT H.* INTO R_PLN_LG_ORDER_HEAD
         FROM CIMS.T_PLN_LG_ORDER_HEAD H
         WHERE H.ORDER_NUMBER = REC.PLN_LG_ORDER_NUMBER;
          
        IF (R_PLN_LG_ORDER_HEAD.ORIGIN_ORDER_STATUS = V_ORIGIN_ORDER_STATUS_DELETE) THEN
            P_ERR_MSG := '订单[' || R_PLN_LG_ORDER_HEAD.ORDER_NUMBER || ']对应的来自外部系统[' || R_PLN_LG_ORDER_HEAD.ORI_SYS_SOURCE || ']的单据[' || R_PLN_LG_ORDER_HEAD.ORIGIN_ORDER_NUMBER || ']已经被删除，不能发起预约！';
            RAISE V_BASE_EXCEPTION;
        END IF;
        
        SELECT SUM(OL.QUANTITY) INTO V_OL_ITEM_QTY_TOTAL
          FROM CIMS.T_PLN_LG_ORDER_LINE OL, CIMS.T_PLN_LG_ORDER_HEAD OH
         WHERE OL.ORDER_HEAD_ID = OH.ORDER_HEAD_ID
           AND OH.ORDER_NUMBER = REC.PLN_LG_ORDER_NUMBER;
        
        V_BOOK_NUM_TOTAL := '';
        V_BL_ITEM_QTY_TOTAL := 0;
        FOR BH_REC IN (
                      SELECT BH.BOOK_NUM || '(' || CL.CODE_NAME || ')' AS BOOK_NUM,BL.ITEM_QTY
                        FROM CIMS.T_PLN_BOOK_HEADER BH,
                             CIMS.T_PLN_BOOK_LINE   BL,
                             CIMS.UP_CODELIST       CL
                       WHERE BH.HEADER_ID = BL.HEADER_ID
                         AND BH.BOOK_TYPE IN ('JD', 'TMALL')
                         AND BH.BOOK_STATUS IN ('00', '01')
                         AND CL.CODETYPE = 'BOOK_STATUS_ORDER'
                         AND CL.CODE_VALUE = BH.BOOK_STATUS
                         AND BL.PLN_LG_ORDER_NUMBER = REC.PLN_LG_ORDER_NUMBER
                       ) LOOP
          V_BOOK_NUM_TOTAL := V_BOOK_NUM_TOTAL || BH_REC.BOOK_NUM || ',';
          V_BL_ITEM_QTY_TOTAL := V_BL_ITEM_QTY_TOTAL + BH_REC.ITEM_QTY;
           
        END LOOP;
        
        IF (V_OL_ITEM_QTY_TOTAL <= NVL(V_BL_ITEM_QTY_TOTAL,0)) THEN
          P_ERR_MSG := '订单[' || R_PLN_LG_ORDER_HEAD.ORDER_NUMBER || ']已经存在对应的预约单请勿重复预约，如果确定需要重新预约请先取消预约单。该订单对应的预约单有：' || V_BOOK_NUM_TOTAL;
          RAISE V_BASE_EXCEPTION;
        END IF;
      END IF;

    END LOOP;
  EXCEPTION
    WHEN V_BASE_EXCEPTION THEN
      P_RESULT  := -27001;
      P_ERR_MSG := '预约单信息校验出错：' || P_ERR_MSG;
    WHEN OTHERS THEN
      P_RESULT  := -27001;
      P_ERR_MSG := '预约单信息校验，发生异常：' || NVL(P_ERR_MSG,' ') || SQLERRM;
  END P_BOOK_INFO_CHECK;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2018-07-18
  *     创建者：周建刚
  *   功能说明：处理电商反馈的预约结果。
  */
  -------------------------------------------------------------------------------   
  PROCEDURE P_BOOK_RESULT_HANDLE(P_BOOK_TYPE      IN VARCHAR2, --操作类型：操作类型： confirm 预约成功反馈IMS;cancel 取消预约
                                 P_BOOK_NUM       IN VARCHAR2, --IMS预约单号
                                 P_OUT_BOOK_NUM   IN VARCHAR2, --客户预约单号（例如：天猫LBX单号）
                                 P_OUT_BOOK_DATE  IN VARCHAR2, --预约日期（天猫可能修改预约日期，以天猫反馈的预约日期为准）
                                 P_BOOK_RESULT    IN VARCHAR2, --预约结果提示信息
                                 P_USER_CODE      IN VARCHAR2, --操作用户编码
                                 P_RESULT         OUT NUMBER,  --返回错误ID
                                 P_ERR_MSG        OUT VARCHAR2 --返回错误信息
                                 ) IS
    R_PLN_BOOK_HEADER T_PLN_BOOK_HEADER%ROWTYPE;
    
    R_LG_SHIP_DOC_TEMP T_LG_SHIP_DOC%ROWTYPE;
    
    V_OUT_BOOK_DATE DATE;
    V_SYS_SOURCE VARCHAR2(32) := 'ECSCM';
    V_ORDER_NUMBER VARCHAR2(32);
  BEGIN
    P_RESULT  := 0;
    P_ERR_MSG := V_SUCCESS;
    
    IF (P_USER_CODE IS NOT NULL) THEN
      V_SYS_SOURCE := P_USER_CODE;
    END IF;
    
    BEGIN
      SELECT T.* INTO R_PLN_BOOK_HEADER
       FROM T_PLN_BOOK_HEADER T
       WHERE T.BOOK_NUM = P_BOOK_NUM
         FOR UPDATE NOWAIT;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        P_ERR_MSG := '预约单不存在，请检查！';
        RAISE V_BASE_EXCEPTION;
      WHEN OTHERS THEN
        P_ERR_MSG := '预约单正被其他用户使用，请稍后再试 ！';
        RAISE V_BASE_EXCEPTION;
    END;
    
    --操作类型：操作类型： confirm 预约结果反馈 IMS; cancel 取消预约
    IF (P_BOOK_TYPE = 'confirm') THEN
      IF (R_PLN_BOOK_HEADER.BOOK_STATUS <> '00' AND R_PLN_BOOK_HEADER.TEMP_CONFIRM_FLAG <> 'Y') THEN
        P_ERR_MSG := '预约单已经确认过，请勿重复操作 ！';
        RAISE V_BASE_EXCEPTION;
      END IF;
      
      IF (P_OUT_BOOK_DATE IS NULL) THEN
        P_ERR_MSG := '请填写预约日期 ！';
        RAISE V_BASE_EXCEPTION;
      END IF;
    
      V_OUT_BOOK_DATE := TO_DATE(P_OUT_BOOK_DATE,'yyyy-MM-dd');
      
      IF (V_OUT_BOOK_DATE < TRUNC(SYSDATE)) THEN
        P_ERR_MSG := '预约日期[' || P_OUT_BOOK_DATE || ']不能早于当前日期，请确认 ！';
        RAISE V_BASE_EXCEPTION;
      END IF;

      UPDATE T_PLN_BOOK_HEADER H
         SET H.OUT_BOOK_NUM = P_OUT_BOOK_NUM,
             H.BOOK_STATUS = '01',           --00 已审核;01 已确认;02 已取消;03 已关闭
             H.BOOK_DATE = V_OUT_BOOK_DATE,
             H.ECSCM_MSG = NULL,
             H.LAST_UPDATED_BY = V_SYS_SOURCE,
             H.VERSION          = NVL(H.VERSION, 0) + 1,
             H.LAST_UPDATE_DATE = SYSDATE
       WHERE H.BOOK_NUM = P_BOOK_NUM;

      FOR REC IN (SELECT L.*
                    FROM T_PLN_BOOK_LINE L
                   WHERE L.HEADER_ID = R_PLN_BOOK_HEADER.HEADER_ID
                  ) LOOP
        --来源类型：SHIP_DOC 发货通知单；PLN_LG_ORDER 提货订单
        IF (REC.SRC_TYPE = 'SHIP_DOC') THEN
            UPDATE T_LG_SHIP_DOC H
               SET H.BOOK_RECEIPT_DATE = V_OUT_BOOK_DATE,
                   H.BOOK_ORDER_NUM = P_OUT_BOOK_NUM,
                   H.LAST_UPDATED_BY = V_SYS_SOURCE,
                   H.LAST_UPDATE_DATE = SYSDATE
              WHERE H.BOOK_NUM_CIMS = P_BOOK_NUM
                AND H.SHIP_DOC_CODE = REC.SRC_BILL_NUM;
            
            UPDATE T_LG_SHIP_DOC_LINE L
               SET L.BOOK_ORDER_NUM = P_OUT_BOOK_NUM,
                   L.LAST_UPDATED_BY = V_SYS_SOURCE,
                   L.LAST_UPDATE_DATE = SYSDATE
               WHERE L.SHIP_DOC_ID = REC.SRC_HEADER_ID 
                 AND L.SHIP_DOC_LINE_ID = REC.SRC_LINE_ID;
                 
          --add by huanghb12 20181204 刷新集拼单及发货通知单的要求发货日期
            IF REC.COLLAGE_ORDER_NUM IS NOT NULL THEN
              P_REVISE_REQUIRE_SHIP_DATE(REC.COLLAGE_ORDER_NUM,--集拼单号
                                         V_SYS_SOURCE, --操作用户编码
                                         P_RESULT,  --返回错误ID
                                         P_ERR_MSG --返回错误信息
                                         );
            END IF;
          --end by huanghb12
        
        ELSIF (REC.SRC_TYPE = 'PLN_LG_ORDER') THEN
          
            UPDATE T_PLN_LG_ORDER_LINE L
               SET L.BOOK_REQUEST      = P_OUT_BOOK_NUM,
                   L.BOOK_RECEIPT_DATE = V_OUT_BOOK_DATE,
                   L.LAST_UPDATED_BY   = V_SYS_SOURCE,
                   L.LAST_UPDATE_DATE  = SYSDATE
             WHERE L.ORDER_HEAD_ID = REC.SRC_HEADER_ID
               AND L.ORDER_LINE_ID = REC.SRC_LINE_ID;
            
            --京东只有一种预约方式，预约确认时更新对应发货计划、发货通知单：预约日期、YY单号、外部预约单号。
            IF (R_PLN_BOOK_HEADER.BOOK_TYPE = 'JD') THEN
                UPDATE T_LG_SHIP_DOC_LINE L
                   SET L.BOOK_ORDER_NUM   = P_OUT_BOOK_NUM,
                       L.BOOK_TOTAL_QTY   = L.ITEM_QTY,
                       L.LAST_UPDATED_BY  = V_SYS_SOURCE,
                       L.LAST_UPDATE_DATE = SYSDATE
                 WHERE EXISTS
                 (SELECT 1
                          FROM CIMS.T_LG_SHIP_DOC H
                         WHERE L.SHIP_DOC_ID = H.SHIP_DOC_ID
                           AND ((H.ORIGIN_ORIGIN_TYPE = '02' AND
                               H.ORIGIN_ORIGIN_ORDER_CODE = REC.SRC_BILL_NUM) OR
                               (H.ORIGIN_TYPE = '02' AND
                               H.ORIGIN_ORDER_NUM = REC.SRC_BILL_NUM))
                           AND H.BOOK_NUM_CIMS = P_BOOK_NUM);
                
                UPDATE T_LG_SHIP_DOC H
                   SET H.BOOK_RECEIPT_DATE = V_OUT_BOOK_DATE,
                       H.BOOK_ORDER_NUM    = P_OUT_BOOK_NUM,
                       H.LAST_UPDATED_BY   = V_SYS_SOURCE,
                       H.LAST_UPDATE_DATE  = SYSDATE
                 WHERE ((H.ORIGIN_ORIGIN_TYPE = '02' AND H.ORIGIN_ORIGIN_ORDER_CODE = REC.SRC_BILL_NUM)
                         OR (H.ORIGIN_TYPE = '02' AND H.ORIGIN_ORDER_NUM = REC.SRC_BILL_NUM))
                   AND H.BOOK_NUM_CIMS = P_BOOK_NUM;
                
                UPDATE T_LG_SHIP_PLAN P
                   SET P.BOOK_RECEIPT_DATE = V_OUT_BOOK_DATE,
                       P.BOOK_ORDER_NUM   = P_OUT_BOOK_NUM,
                       P.LAST_UPDATE_DATE = SYSDATE
                 WHERE ((P.ORIGIN_ORIGIN_TYPE = '02' AND P.ORIGIN_ORIGIN_ORDER_CODE = REC.SRC_BILL_NUM) 
                         OR (P.ORIGIN_TYPE = '02' AND P.ORIGIN_ORDER_NUM = REC.SRC_BILL_NUM))
                   AND P.ENTITY_ID = R_PLN_BOOK_HEADER.ENTITY_ID
                   AND P.BOOK_NUM_CIMS = P_BOOK_NUM;
                
            END IF;
          
        END IF;

      END LOOP;

      --更新接口表状态
      UPDATE INTF_ECSCM_PLN_BOOK_HEADER H
         SET H.INTF_STATUS      = 'S',
             H.LAST_UPDATED_BY  = V_SYS_SOURCE,
             H.VERSION          = NVL(H.VERSION, 0) + 1,
             H.INTF_MSG         = 'SUCCESS',
             H.INTF_RETURN_DATE = SYSDATE,
             H.LAST_UPDATE_DATE = SYSDATE
       WHERE H.BOOK_NUM = P_BOOK_NUM;
      
      --临时预约
      IF (INSTR(NVL(P_OUT_BOOK_NUM,'-'),'CIMS-LBX') = 1) THEN
        UPDATE T_PLN_BOOK_HEADER H
           SET H.TEMP_CONFIRM_FLAG = 'Y',
               H.TEMP_OUT_BOOK_NUM = P_OUT_BOOK_NUM,
               H.LAST_UPDATE_DATE  = SYSDATE
         WHERE H.BOOK_NUM = P_BOOK_NUM;
      END IF;
      
      P_BOOK_INFO_2_LOMS('confirm',--操作类型：操作类型： confirm 预约成功反馈IMS;cancel 取消预约;close 关闭预约单
                         P_BOOK_NUM, --IMS预约单号
                         V_SYS_SOURCE, --操作用户编码
                         P_RESULT,  --返回错误ID
                         P_ERR_MSG --返回错误信息
                         );
			 
      IF P_RESULT <> 0 THEN
         RAISE V_BASE_EXCEPTION;
      END IF;
      
      --更新对应的通知单、调拨单中的LBX单号(临时确认)
      IF (R_PLN_BOOK_HEADER.TEMP_CONFIRM_FLAG = 'Y') THEN
        UPDATE T_LG_SHIP_DOC H
           SET H.BOOK_RECEIPT_DATE = V_OUT_BOOK_DATE,
               H.BOOK_ORDER_NUM    = P_OUT_BOOK_NUM,
               H.LAST_UPDATED_BY   = V_SYS_SOURCE,
               H.LAST_UPDATE_DATE  = SYSDATE
         WHERE H.BOOK_NUM_CIMS = P_BOOK_NUM;
        
        UPDATE CIMS.T_LG_SHIP_DOC_LINE L
           SET L.BOOK_ORDER_NUM   = P_OUT_BOOK_NUM,
               L.LAST_UPDATE_DATE = SYSDATE
         WHERE EXISTS (SELECT 1
                  FROM CIMS.T_LG_SHIP_DOC H
                 WHERE H.SHIP_DOC_ID = L.SHIP_DOC_ID
                   AND H.BOOK_NUM_CIMS = P_BOOK_NUM);
        
        UPDATE T_INV_TRSF_ORDER H
           SET H.BOOK_ORDER_NUM    = P_OUT_BOOK_NUM,
               H.BOOK_NUM_CIMS     = P_BOOK_NUM,
               H.BOOK_TYPE         = P_OUT_BOOK_DATE,
               H.LAST_UPDATED_BY   = V_SYS_SOURCE,
               H.LAST_UPDATE_DATE  = SYSDATE
         WHERE EXISTS (SELECT 1 FROM T_LG_SHIP_DOC SH
            WHERE H.SHIP_DOC_CODE = SH.SHIP_DOC_CODE AND SH.BOOK_NUM_CIMS = P_BOOK_NUM);
      END IF;
      
    ELSIF (P_BOOK_TYPE = 'cancel') THEN

      IF (R_PLN_BOOK_HEADER.BOOK_STATUS = '02') THEN
        P_RESULT  := 0;
        P_ERR_MSG := V_SUCCESS;
        
        RETURN;
      END IF;
      
      UPDATE T_PLN_BOOK_HEADER H
         SET H.BOOK_STATUS = '02',           --00 已审核;01 已确认;02 已取消;03 已关闭
             H.ECSCM_MSG   = NULL,
             H.VERSION          = NVL(H.VERSION, 0) + 1,
             H.LAST_UPDATED_BY = V_SYS_SOURCE,
             H.LAST_UPDATE_DATE = SYSDATE
       WHERE H.BOOK_NUM = P_BOOK_NUM;
      
      FOR REC IN (SELECT L.*
                    FROM T_PLN_BOOK_LINE L
                   WHERE L.HEADER_ID = R_PLN_BOOK_HEADER.HEADER_ID
                  ) LOOP
        --来源类型：SHIP_DOC 发货通知单；PLN_LG_ORDER 提货订单
        IF (REC.SRC_TYPE = 'SHIP_DOC') THEN

            UPDATE T_LG_SHIP_DOC H
               SET H.BOOK_RECEIPT_DATE = NULL,
                   H.BOOK_ORDER_NUM = NULL,
                   H.BOOK_NUM_CIMS = NULL,
                   H.LAST_UPDATED_BY = V_SYS_SOURCE,
                   H.LAST_UPDATE_DATE = SYSDATE
              WHERE H.BOOK_NUM_CIMS = P_BOOK_NUM
                AND H.SHIP_DOC_CODE = REC.SRC_BILL_NUM;
            
            UPDATE T_LG_SHIP_DOC_LINE L
               SET L.BOOK_ORDER_NUM = NULL,
                   L.BOOK_TOTAL_QTY = 0,
                   L.LAST_UPDATED_BY = V_SYS_SOURCE,
                   L.LAST_UPDATE_DATE = SYSDATE
               WHERE L.SHIP_DOC_ID = REC.SRC_HEADER_ID 
                 AND L.SHIP_DOC_LINE_ID = REC.SRC_LINE_ID;
        
        ELSIF (REC.SRC_TYPE = 'PLN_LG_ORDER') THEN
            /**
            提货订单，预约取消：
            1、清空发货通知单上的预约单信息，以便通过发货通知单的方式再次发起预约。
            2、扣减提货订单上预约总数量： 货订单上预约总数量 = 货订单上预约总数量 - （预约单中的预约数量 - 预约单实际已经评审的数量）
            */
            UPDATE T_LG_SHIP_DOC_LINE L
               SET L.BOOK_ORDER_NUM   = NULL,
                   L.BOOK_TOTAL_QTY   = 0,
                   L.LAST_UPDATED_BY  = V_SYS_SOURCE,
                   L.LAST_UPDATE_DATE = SYSDATE
             WHERE EXISTS
             (SELECT 1
                      FROM CIMS.T_LG_SHIP_DOC H
                     WHERE L.SHIP_DOC_ID = H.SHIP_DOC_ID
                       AND ((H.ORIGIN_ORIGIN_TYPE = '02' AND
                           H.ORIGIN_ORIGIN_ORDER_CODE = REC.SRC_BILL_NUM) OR
                           (H.ORIGIN_TYPE = '02' AND
                           H.ORIGIN_ORDER_NUM = REC.SRC_BILL_NUM))
                       AND H.BOOK_NUM_CIMS = P_BOOK_NUM);
            
            UPDATE T_LG_SHIP_DOC H
               SET H.BOOK_RECEIPT_DATE = NULL,
                   H.BOOK_ORDER_NUM    = NULL,
                   H.BOOK_NUM_CIMS     = NULL,
                   H.LAST_UPDATED_BY   = V_SYS_SOURCE,
                   H.LAST_UPDATE_DATE  = SYSDATE
             WHERE ((H.ORIGIN_ORIGIN_TYPE = '02' AND H.ORIGIN_ORIGIN_ORDER_CODE = REC.SRC_BILL_NUM)
                     OR (H.ORIGIN_TYPE = '02' AND H.ORIGIN_ORDER_NUM = REC.SRC_BILL_NUM))
               AND H.BOOK_NUM_CIMS = P_BOOK_NUM;
            
            UPDATE T_LG_SHIP_PLAN P
               SET P.BOOK_NUM_CIMS    = NULL,
                   P.BOOK_RECEIPT_DATE = NULL,
                   P.BOOK_ORDER_NUM   = NULL,
                   P.LAST_UPDATE_DATE = SYSDATE
             WHERE ((P.ORIGIN_ORIGIN_TYPE = '02' AND P.ORIGIN_ORIGIN_ORDER_CODE = REC.SRC_BILL_NUM) 
                     OR (P.ORIGIN_TYPE = '02' AND P.ORIGIN_ORDER_NUM = REC.SRC_BILL_NUM))
               AND P.ENTITY_ID = R_PLN_BOOK_HEADER.ENTITY_ID
               AND P.BOOK_NUM_CIMS = P_BOOK_NUM;
            
            UPDATE T_PLN_LG_ORDER_LINE L
               SET L.BOOK_REQUEST      = NULL,
                   L.BOOK_RECEIPT_DATE = NULL,
                   L.BOOK_NUM_CIMS     = NULL,
                   L.BOOK_TOTAL_QTY    = NVL(L.BOOK_TOTAL_QTY,0) - (NVL(REC.ITEM_QTY,0)),
                   L.BOOK_AFFIRMED_QTY = NVL(L.BOOK_AFFIRMED_QTY,0) - NVL(REC.AFFIRMED_QUANTITY,0),
                   L.LAST_UPDATED_BY   = V_SYS_SOURCE,
                   L.LAST_UPDATE_DATE  = SYSDATE
             WHERE L.ORDER_HEAD_ID = REC.SRC_HEADER_ID
               AND L.ORDER_LINE_ID = REC.SRC_LINE_ID;

	    END IF;
          --add by huanghb12 20181204 刷新集拼单及发货通知单的要求发货日期
          IF REC.COLLAGE_ORDER_NUM IS NOT NULL THEN
            P_REVISE_REQUIRE_SHIP_DATE(REC.COLLAGE_ORDER_NUM,--集拼单号
                                       V_SYS_SOURCE, --操作用户编码
                                       P_RESULT,  --返回错误ID
                                       P_ERR_MSG --返回错误信息
                                       );
          END IF;
          --end by huanghb12
      END LOOP;
      
      P_BOOK_INFO_2_LOMS('cancel',--操作类型：操作类型： confirm 预约成功反馈IMS;cancel 取消预约;close 关闭预约单
                         P_BOOK_NUM, --IMS预约单号
                         V_SYS_SOURCE, --操作用户编码
                         P_RESULT,  --返回错误ID
                         P_ERR_MSG --返回错误信息
                         );   
			 
      IF P_RESULT <> 0 THEN
         RAISE V_BASE_EXCEPTION;
      END IF;
      
    ELSIF (P_BOOK_TYPE = 'warn') THEN
      UPDATE CIMS.T_PLN_BOOK_HEADER H
         SET H.ECSCM_MSG        = P_BOOK_RESULT,
             H.LAST_UPDATED_BY  = V_SYS_SOURCE,
             H.CANCELLABLE_FLAG = 'Y',
             H.VERSION          = NVL(H.VERSION, 0) + 1,
             H.LAST_UPDATE_DATE = SYSDATE
       WHERE H.BOOK_NUM = P_BOOK_NUM;
      
      --更新接口表状态
      UPDATE INTF_ECSCM_PLN_BOOK_HEADER H
         SET H.INTF_STATUS      = 'W',
             H.INTF_MSG         = P_BOOK_RESULT,
             H.VERSION          = NVL(H.VERSION, 0) + 1,
             H.LAST_UPDATED_BY  = V_SYS_SOURCE,
             H.INTF_RETURN_DATE = SYSDATE,
             H.LAST_UPDATE_DATE = SYSDATE
       WHERE H.BOOK_NUM = P_BOOK_NUM;
      
    END IF;

  EXCEPTION
    WHEN V_BASE_EXCEPTION THEN
      P_RESULT  := -27001;
      P_ERR_MSG := '处理预约单[' || P_BOOK_NUM || ']的确认结果，出错：' || P_ERR_MSG;
    WHEN OTHERS THEN
      P_RESULT  := -27001;
      P_ERR_MSG := '处理预约单[' || P_BOOK_NUM || ']的确认结果，发生异常：' || SQLERRM;
  END P_BOOK_RESULT_HANDLE;
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2018-08-01
  *     创建者：周建刚
  *   功能说明：关闭预约信息。
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_BOOK_INFO_CLOSE(P_HEADER_ID      IN NUMBER,   --预约单头ID
                              P_USER_CODE      IN VARCHAR2, --操作用户编码
                              P_RESULT         OUT NUMBER,  --返回错误ID
                              P_ERR_MSG        OUT VARCHAR2 --返回错误信息
                              ) IS 
    
    R_PLN_BOOK_HEADER T_PLN_BOOK_HEADER%ROWTYPE;
    
  BEGIN
    P_RESULT  := 0;
    P_ERR_MSG := V_SUCCESS;
    
    SELECT H.*
      INTO R_PLN_BOOK_HEADER
      FROM T_PLN_BOOK_HEADER H
     WHERE H.HEADER_ID = P_HEADER_ID;
    
    --'00', '已审核';'01', '已确认';'02', '已取消';'03', '已关闭'
    IF (R_PLN_BOOK_HEADER.BOOK_STATUS <> '01') THEN
        P_ERR_MSG := '预约单[' || R_PLN_BOOK_HEADER.BOOK_NUM || ']当前状态不支持关闭，请核实！';
        RAISE V_BASE_EXCEPTION;
    END IF;

    FOR REC IN (SELECT L.*
                  FROM T_PLN_BOOK_LINE L
                 WHERE L.HEADER_ID = R_PLN_BOOK_HEADER.HEADER_ID
                ) LOOP
        
        --来源类型：SHIP_DOC 发货通知单；PLN_LG_ORDER 提货订单
        IF (REC.SRC_TYPE = 'PLN_LG_ORDER') THEN
            --提货行预约总量 = 提货行预约总量 - (预约单行的预约数量 - 预约单行的已下达数量(已评审数量))
            UPDATE T_PLN_LG_ORDER_LINE L
               SET L.BOOK_REQUEST      = NULL,
                   L.BOOK_RECEIPT_DATE = NULL,
                   L.BOOK_TOTAL_QTY    = NVL(L.BOOK_TOTAL_QTY, 0) - (NVL(REC.ITEM_QTY, 0) - NVL(REC.AFFIRMED_QUANTITY, 0)),
                   L.LAST_UPDATED_BY   = P_USER_CODE,
                   L.LAST_UPDATE_DATE  = SYSDATE
             WHERE L.ORDER_HEAD_ID = REC.SRC_HEADER_ID
               AND L.ORDER_LINE_ID = REC.SRC_LINE_ID;
            
        END IF;
        
        --来源类型：SHIP_DOC 发货通知单；PLN_LG_ORDER 提货订单
        IF (REC.SRC_TYPE = 'SHIP_DOC') THEN
            UPDATE T_LG_SHIP_DOC H
               SET H.BOOK_RECEIPT_DATE = NULL,
                   H.BOOK_ORDER_NUM = NULL,
                   H.BOOK_NUM_CIMS = NULL,
                   H.LAST_UPDATED_BY = P_USER_CODE,
                   H.LAST_UPDATE_DATE = SYSDATE
              WHERE H.BOOK_NUM_CIMS = R_PLN_BOOK_HEADER.BOOK_NUM
                AND H.SHIP_DOC_CODE = REC.SRC_BILL_NUM;
            
            UPDATE T_LG_SHIP_DOC_LINE L
               SET L.BOOK_ORDER_NUM = NULL,
                   L.BOOK_TOTAL_QTY = 0,
                   L.LAST_UPDATED_BY = P_USER_CODE,
                   L.LAST_UPDATE_DATE = SYSDATE
               WHERE L.SHIP_DOC_ID = REC.SRC_HEADER_ID 
                 AND L.SHIP_DOC_LINE_ID = REC.SRC_LINE_ID;
            
        END IF;
        
    END LOOP;

    --'00', '已审核';'01', '已确认';'02', '已取消';'03', '已关闭'
    UPDATE T_PLN_BOOK_HEADER H
       SET H.BOOK_STATUS      = '03',
           H.LAST_UPDATED_BY  = P_USER_CODE,
           H.LAST_UPDATE_DATE = SYSDATE
     WHERE H.HEADER_ID = P_HEADER_ID;
  
  EXCEPTION
    WHEN V_BASE_EXCEPTION THEN
      P_RESULT  := -27001;
      P_ERR_MSG := '关闭预约单出错：' || P_ERR_MSG;
    WHEN OTHERS THEN
      P_RESULT  := -27001;
      P_ERR_MSG := '关闭预约单[' || P_HEADER_ID || ']，发生异常：' || SQLERRM;
  END P_BOOK_INFO_CLOSE;
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2018-11-01
  *     创建者：周建刚
  *   功能说明：预约信息推送LOMS，安得业务简单化项目的预约发货计划功能。
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_BOOK_INFO_2_LOMS(P_BOOK_TYPE      IN VARCHAR2, --操作类型：操作类型： confirm 预约成功反馈IMS;cancel 取消预约;close 关闭预约单
                               P_BOOK_NUM       IN VARCHAR2, --IMS预约单号
                               P_USER_CODE      IN VARCHAR2, --操作用户编码
                               P_RESULT         OUT NUMBER,  --返回错误ID
                               P_ERR_MSG        OUT VARCHAR2 --返回错误信息
                               ) IS 
    
    V_HEADER_ID NUMBER := 0;
    R_PLN_BOOK_HEADER         T_PLN_BOOK_HEADER%ROWTYPE;
    R_LG_SHIP_DOC             T_LG_SHIP_DOC%ROWTYPE;
    V_SHIP_DOC_CODE           VARCHAR2(32);
    V_ORDER_NUMBER            VARCHAR2(32);
    V_OPER_TYPE               VARCHAR2(32);
    
    V_OPERATING_UNIT          VARCHAR2(100);
    V_OPERATING_UNIT_NAME     T_INV_ORGANIZATION.OPERATING_UNIT_NAME%TYPE;
  BEGIN
    P_RESULT  := 0;
    P_ERR_MSG := V_SUCCESS;
    
    --OPER_TYPE --ADD:新增  CANCEL:取消 CLOSE：关闭 
    IF (P_BOOK_TYPE = 'confirm') THEN
      V_OPER_TYPE := 'ADD';
    ELSIF (P_BOOK_TYPE = 'cancel') THEN
      V_OPER_TYPE := 'CANCEL';
    ELSIF (P_BOOK_TYPE = 'close') THEN
      V_OPER_TYPE := 'CLOSE';
    END IF;
    
    SELECT H.*
      INTO R_PLN_BOOK_HEADER
      FROM T_PLN_BOOK_HEADER H
     WHERE H.BOOK_NUM = P_BOOK_NUM;
     
    V_HEADER_ID := S_INTF_LOMS_PLN_BOOK_HEADER.NEXTVAL;

    INSERT INTO INTF_LOMS_PLN_BOOK_HEADER
      (HEADER_ID,
       BOOK_NUM,
       BOOK_DATE,
       OUT_BOOK_NUM,
       SALES_CENTER_ID,
       SALES_CENTER_CODE,
       SALES_CENTER_NAME,
       CUSTOMER_ID,
       CUSTOMER_CODE,
       CUSTOMER_NAME,
       CONSIGNEE_ADDR_ID,
       CONSIGNEE_ADDR,
       REMARK,
       CREATED_BY,
       CREATION_DATE,
       LAST_UPDATED_BY,
       LAST_UPDATE_DATE,
       VERSION,
       ENTITY_ID,
       INTF_STATUS,
       CONSIGNEE_ADDR_CODE,
       CONSIGNEE_PROVINCE_CODE,
       CONSIGNEE_CITY_CODE,
       CONSIGNEE_DIST_CODE,
       CONSIGNEE_TOWN_CODE,
       CONSIGNEE_PROVINCE_NAME,
       CONSIGNEE_CITY_NAME,
       CONSIGNEE_DISTRICT_NAME,
       CONSIGNEE_TOWN_NAME,
       CONSIGNEE_CONTRACT,
       CONSIGNEE_TEL,
       REQUIRE_SHIP_DATE,
       OPER_TYPE --ADD:新增  CANCEL:取消 CLOSE：关闭 
       )
    VALUES
      (V_HEADER_ID,
       R_PLN_BOOK_HEADER.BOOK_NUM,
       R_PLN_BOOK_HEADER.BOOK_DATE,
       R_PLN_BOOK_HEADER.OUT_BOOK_NUM,
       R_PLN_BOOK_HEADER.SALES_CENTER_ID,
       R_PLN_BOOK_HEADER.SALES_CENTER_CODE,
       R_PLN_BOOK_HEADER.SALES_CENTER_NAME,
       R_PLN_BOOK_HEADER.CUSTOMER_ID,
       R_PLN_BOOK_HEADER.CUSTOMER_CODE,
       R_PLN_BOOK_HEADER.CUSTOMER_NAME,
       R_PLN_BOOK_HEADER.CONSIGNEE_ADDR_ID,
       R_PLN_BOOK_HEADER.CONSIGNEE_ADDR,
       R_PLN_BOOK_HEADER.REMARK,
       P_USER_CODE,
       SYSDATE,
       P_USER_CODE,
       SYSDATE,
       1,
       R_PLN_BOOK_HEADER.ENTITY_ID,
       v_False,
       R_PLN_BOOK_HEADER.CONSIGNEE_ADDR_CODE,
       R_PLN_BOOK_HEADER.CONSIGNEE_PROVINCE_CODE,
       R_PLN_BOOK_HEADER.CONSIGNEE_CITY_CODE,
       R_PLN_BOOK_HEADER.CONSIGNEE_DISTRICT_CODE,
       R_PLN_BOOK_HEADER.CONSIGNEE_TOWN_CODE,
       R_PLN_BOOK_HEADER.CONSIGNEE_PROVINCE_NAME,
       R_PLN_BOOK_HEADER.CONSIGNEE_CITY_NAME,
       R_PLN_BOOK_HEADER.CONSIGNEE_DISTRICT_NAME,
       R_PLN_BOOK_HEADER.CONSIGNEE_TOWN_NAME,
       R_PLN_BOOK_HEADER.CONSIGNEE_CONTRACT,
       R_PLN_BOOK_HEADER.CONSIGNEE_TEL,
       NULL,
       V_OPER_TYPE);

    FOR REC IN (SELECT L.*
                  FROM T_PLN_BOOK_LINE L
                 WHERE EXISTS (SELECT 1 FROM CIMS.T_PLN_BOOK_HEADER H
                  WHERE H.HEADER_ID = L.HEADER_ID AND H.BOOK_NUM = P_BOOK_NUM)
                ) LOOP
      V_SHIP_DOC_CODE := '';
      V_ORDER_NUMBER  := '';
      --来源类型： SHIP_DOC 发货通知单；PLN_LG_ORDER 提货订单
      IF (REC.SRC_TYPE = 'SHIP_DOC') THEN
        V_SHIP_DOC_CODE := REC.SRC_BILL_NUM;
        
        SELECT D.* INTO R_LG_SHIP_DOC FROM T_LG_SHIP_DOC D
         WHERE D.SHIP_DOC_CODE = REC.SRC_BILL_NUM;
        
        IF (R_LG_SHIP_DOC.ORIGIN_ORIGIN_TYPE = '02') THEN
          V_ORDER_NUMBER := R_LG_SHIP_DOC.ORIGIN_ORIGIN_ORDER_CODE;
        END IF;
        
        IF (V_ORDER_NUMBER IS NULL AND R_LG_SHIP_DOC.ORIGIN_TYPE = '02') THEN
          V_ORDER_NUMBER := R_LG_SHIP_DOC.ORIGIN_ORDER_NUM;
        END IF;
        
      ELSIF (REC.SRC_TYPE = 'PLN_LG_ORDER') THEN
        V_ORDER_NUMBER := REC.SRC_BILL_NUM;
      END IF;
      
      
      --获取仓库OU
      IF (REC.SHIP_INV_CODE IS NOT NULL) THEN
        SELECT IO.OPERATING_UNIT || '', IO.OPERATING_UNIT_NAME
          INTO V_OPERATING_UNIT, V_OPERATING_UNIT_NAME
          FROM CIMS.T_INV_ORGANIZATION IO, CIMS.T_INV_INVENTORIES INV
         WHERE IO.ENTITY_ID = INV.ENTITY_ID
           AND INV.ORGANIZATION_CODE = IO.ORGANIZATION_CODE
           AND INV.INVENTORY_CODE = REC.SHIP_INV_CODE;
      END IF;
      
      INSERT INTO INTF_LOMS_PLN_BOOK_LINE
        (ENTITY_ID,
         LINE_ID,
         HEADER_ID,
         ITEM_ID,
         ITEM_CODE,
         ITEM_NAME,
         ITEM_QTY,
         SHIP_INV_ID,
         SHIP_INV_CODE,
         SHIP_INV_NAME,
         SHIP_DOC_CODE,
         ORDER_NUMBER,
         REMARK,
         CREATED_BY,
         CREATION_DATE,
         LAST_UPDATED_BY,
         LAST_UPDATE_DATE,
         EXTENT1,
         EXTENT2,
         EXTENT3,
         VERSION)
      VALUES
        (REC.ENTITY_ID,
         S_INTF_LOMS_PLN_BOOK_LINE.NEXTVAL,
         V_HEADER_ID,
         REC.ITEM_ID,
         REC.ITEM_CODE,
         REC.ITEM_NAME,
         REC.ITEM_QTY,
         REC.SHIP_INV_ID,
         REC.SHIP_INV_CODE,
         REC.SHIP_INV_NAME,
         V_SHIP_DOC_CODE,
         V_ORDER_NUMBER,
         NULL,
         P_USER_CODE,
         SYSDATE,
         P_USER_CODE,
         SYSDATE,
         V_OPERATING_UNIT,
         V_OPERATING_UNIT_NAME,
         REC.ITEM_IS_SET,
         1);

    END LOOP;

  EXCEPTION
    WHEN V_BASE_EXCEPTION THEN
      P_RESULT  := -27001;
      P_ERR_MSG := '预约单[' || P_BOOK_NUM || ']写入LOMS预约发货计划接口表出错：' || P_ERR_MSG;
    WHEN OTHERS THEN
      P_RESULT  := -27001;
      P_ERR_MSG := '预约单[' || P_BOOK_NUM || ']写入LOMS预约发货计划接口发生异常：' || SQLERRM;
  END P_BOOK_INFO_2_LOMS;
  -------------------------------------------------------------------------------
                               
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2018-12-06
  *     创建者：周建刚
  *   功能说明：预约信息推送ECSCM，通过ECSCM系统传递到天猫。
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_BOOK_INFO_2_ECSCM(P_BATCH_ID         IN NUMBER,   --批处理ID
                                P_RESULT           OUT NUMBER,  --返回错误ID
                                P_ERR_MSG          OUT VARCHAR2 --返回错误信息
                                ) IS
    V_HEADER_ID NUMBER := 0;
    
    V_PRODUCING_AREA_ID       NUMBER;
    V_PRODUCING_AREA_CODE     VARCHAR2(32);
    V_PRODUCING_AREA_NAME     VARCHAR2(100);
    V_PRODUCING_DISTRICT_ID   NUMBER;
    V_PRODUCING_DISTRICT_CODE VARCHAR2(32);
    V_PRODUCING_DISTRICT_FULL_NAME VARCHAR2(100);
    
    V_INTF_STATUS      INTF_ECSCM_PLN_BOOK_HEADER.INTF_STATUS%TYPE := 'N';
    V_INTF_SERIAL_NUM  INTF_ECSCM_PLN_BOOK_HEADER.INTF_SERIAL_NUM%TYPE := '';

  BEGIN
    P_RESULT  := 0;
    P_ERR_MSG := V_SUCCESS;
    
    FOR REC IN (SELECT H.*
                  FROM T_PLN_BOOK_HEADER H
                 WHERE H.BOOK_TYPE IN ('TMALL','JD')
                  AND H.TO_ECSCM_INTF_FLAG = 'N'
                  AND H.BATCH_ID = P_BATCH_ID) LOOP
           V_HEADER_ID := S_INTF_ECSCM_PLN_BOOK_HEADER.NEXTVAL;
           
           IF (REC.OUT_SYS_BOOK_FLAG = 'Y') THEN
             V_INTF_STATUS      := 'Y';
             V_INTF_SERIAL_NUM  := '紧急预约生成的YY单，无需推送京东等电商系统。';
           END IF;
           
           INSERT INTO INTF_ECSCM_PLN_BOOK_HEADER(
              HEADER_ID         ,
              BOOK_NUM          ,
              BOOK_DATE         ,
              OUT_BOOK_NUM      ,
              SALES_CENTER_ID   ,
              SALES_CENTER_CODE ,
              SALES_CENTER_NAME ,
              CUSTOMER_ID       ,
              CUSTOMER_CODE     ,
              CUSTOMER_NAME     ,
              CONSIGNEE_ADDR_ID ,
              CONSIGNEE_ADDR    ,
              REMARK            ,
              CREATED_BY        ,
              CREATION_DATE     ,
              LAST_UPDATED_BY   ,
              LAST_UPDATE_DATE  ,
              VERSION           ,
              ENTITY_ID,
              INTF_STATUS,
              INTF_SERIAL_NUM,
              CONSIGNEE_ADDR_CODE,
              CONSIGNEE_PROVINCE_CODE,
              CONSIGNEE_CITY_CODE,
              CONSIGNEE_DIST_CODE,
              CONSIGNEE_TOWN_CODE,
              RCV_INV_CODE,
              RCV_INV_NAME,
              CONSIGNEE_CONTRACT,
              CONSIGNEE_TEL,
              DELAY_BOOK_DATE_DAYS,
              TOTAL_ITEM_QTY,
              TOTAL_ITEM_BOX_QTY,
              BOOK_TYPE,
              BATCH_ID,
              TO_OUT_SYS_BATCH_NUM
           )
           VALUES
           (
           V_HEADER_ID,
           REC.BOOK_NUM,
           REC.BOOK_DATE,
           REC.OUT_BOOK_NUM,
           REC.SALES_CENTER_ID,
           REC.SALES_CENTER_CODE,
           REC.SALES_CENTER_NAME,
           REC.CUSTOMER_ID,
           REC.CUSTOMER_CODE,
           REC.CUSTOMER_NAME,
           REC.CONSIGNEE_ADDR_ID,
           REC.CONSIGNEE_ADDR,
           NULL,
           REC.CREATED_BY,
           REC.CREATION_DATE,
           REC.LAST_UPDATED_BY,
           REC.LAST_UPDATE_DATE,
           1,
           REC.ENTITY_ID,
           V_INTF_STATUS,
           V_INTF_SERIAL_NUM,
           REC.CONSIGNEE_ADDR_CODE,
           REC.CONSIGNEE_PROVINCE_CODE,
           REC.CONSIGNEE_CITY_CODE,
           REC.CONSIGNEE_DISTRICT_CODE,
           REC.CONSIGNEE_TOWN_CODE,
           REC.RCV_INV_CODE,
           REC.RCV_INV_NAME,
           REC.CONSIGNEE_CONTRACT,
           REC.CONSIGNEE_TEL,
           REC.DELAY_BOOK_DATE_DAYS,
           REC.TOTAL_ITEM_QTY,
           REC.TOTAL_ITEM_BOX_QTY,
           REC.BOOK_TYPE,
           REC.BATCH_ID,
           REC.TO_OUT_SYS_BATCH_NUM
           );
        
        FOR LINE_REC IN (SELECT L.*
                           FROM T_PLN_BOOK_LINE L
                          WHERE L.HEADER_ID = REC.HEADER_ID
                         ) LOOP
           
           V_PRODUCING_AREA_ID       := LINE_REC.PRODUCING_AREA_ID;
           V_PRODUCING_AREA_CODE     := LINE_REC.PRODUCING_AREA_CODE;
           V_PRODUCING_AREA_NAME     := LINE_REC.PRODUCING_AREA_NAME;
           V_PRODUCING_DISTRICT_ID   := LINE_REC.PRODUCING_DISTRICT_ID;
           V_PRODUCING_DISTRICT_CODE := LINE_REC.PRODUCING_DISTRICT_CODE;
           V_PRODUCING_DISTRICT_FULL_NAME := LINE_REC.PRODUCING_DISTRICT_FULL_NAME;
           
           INSERT INTO INTF_ECSCM_PLN_BOOK_DETAIL(
              LINE_ID          ,
              HEADER_ID        ,
              SRC_TYPE         ,
              SRC_BILL_NUM     ,
              OUT_ORDER_NUM    ,
              ITEM_ID          ,
              ITEM_CODE        ,
              ITEM_NAME        ,
              ITEM_QTY         ,
              REMARK           ,
              CREATED_BY       ,
              CREATION_DATE    ,
              LAST_UPDATED_BY  ,
              LAST_UPDATE_DATE ,
              VERSION          ,
              ENTITY_ID,
              PRODUCING_AREA_ID,
              PRODUCING_AREA_CODE,
              PRODUCING_AREA_NAME,
              PRODUCING_DISTRICT_ID,
              PRODUCING_DISTRICT_CODE,
              PRODUCING_DISTRICT_FULL_NAME,
              ITEM_BOX_QTY,
              PLN_LG_ORDER_NUMBER,
              DISTRIBUTION_CENTER_NAME,
              DISTRIBUTION_CENTER_CODE,
              DISTRIBUTION_WAREHOUSE_CODE,
              DISTRIBUTION_WAREHOUSE_NAME,
              ORIGIN_VERNDOR_CODE,
              ORIGIN_VERNDOR_NAME
           )
           VALUES
           (
           S_INTF_ECSCM_PLN_BOOK_DETAIL.NEXTVAL,
           V_HEADER_ID,
           LINE_REC.SRC_TYPE,
           LINE_REC.SRC_BILL_NUM,
           LINE_REC.OUT_ORDER_NUM,
           LINE_REC.ITEM_ID,
           LINE_REC.ITEM_CODE,
           LINE_REC.ITEM_NAME,
           LINE_REC.ITEM_QTY,
           NULL,
           LINE_REC.CREATED_BY,
           LINE_REC.CREATION_DATE,
           LINE_REC.LAST_UPDATED_BY,
           LINE_REC.LAST_UPDATE_DATE,
           1,
           LINE_REC.ENTITY_ID,
           LINE_REC.PRODUCING_AREA_ID,
           LINE_REC.PRODUCING_AREA_CODE,
           LINE_REC.PRODUCING_AREA_NAME,
           V_PRODUCING_DISTRICT_ID,
           V_PRODUCING_DISTRICT_CODE,
           V_PRODUCING_DISTRICT_FULL_NAME,
           LINE_REC.ITEM_BOX_QTY,
           LINE_REC.PLN_LG_ORDER_NUMBER,
           LINE_REC.DISTRIBUTION_CENTER_NAME,
           LINE_REC.DISTRIBUTION_CENTER_CODE,
           LINE_REC.DISTRIBUTION_WAREHOUSE_CODE,
           LINE_REC.DISTRIBUTION_WAREHOUSE_NAME,
           LINE_REC.ORIGIN_VERNDOR_CODE,
           LINE_REC.ORIGIN_VERNDOR_NAME
           );
           
        END LOOP;
        
        --按照天猫接口要求根据天猫备货单汇总
        FOR INTF_LINE_REC IN (SELECT L.ENTITY_ID,
                                 L.HEADER_ID,
                                 L.OUT_ORDER_NUM,
                                 SUM(L.ITEM_QTY) ITEM_QTY,
                                 SUM(NVL(L.ITEM_BOX_QTY,0)) ITEM_BOX_QTY
                            FROM T_PLN_BOOK_LINE L
                           WHERE L.HEADER_ID = REC.HEADER_ID
                           GROUP BY L.ENTITY_ID,
                                    L.HEADER_ID,
                                    L.OUT_ORDER_NUM
                         ) LOOP
           
           BEGIN
             
             SELECT L.PRODUCING_AREA_ID, L.PRODUCING_AREA_CODE,L.PRODUCING_AREA_NAME
               INTO V_PRODUCING_AREA_ID, V_PRODUCING_AREA_CODE,V_PRODUCING_AREA_NAME
               FROM T_PLN_BOOK_LINE L
              WHERE L.HEADER_ID = INTF_LINE_REC.HEADER_ID
                AND L.OUT_ORDER_NUM = INTF_LINE_REC.OUT_ORDER_NUM
                AND ROWNUM = 1;
              
            EXCEPTION
              WHEN OTHERS THEN
                NULL;
            END;
           
           INSERT INTO INTF_ECSCM_PLN_BOOK_LINE(
              LINE_ID          ,
              HEADER_ID        ,
              OUT_ORDER_NUM    ,
              ITEM_QTY         ,
              REMARK           ,
              CREATED_BY       ,
              CREATION_DATE    ,
              LAST_UPDATED_BY  ,
              LAST_UPDATE_DATE ,
              VERSION          ,
              ENTITY_ID,
              PRODUCING_AREA_ID,
              PRODUCING_AREA_CODE,
              PRODUCING_AREA_NAME,
              PRODUCING_DISTRICT_ID,
              PRODUCING_DISTRICT_CODE,
              PRODUCING_DISTRICT_FULL_NAME,
              ITEM_BOX_QTY
           )
           VALUES
           (
           S_INTF_ECSCM_PLN_BOOK_LINE.NEXTVAL,
           V_HEADER_ID,
           INTF_LINE_REC.OUT_ORDER_NUM,
           INTF_LINE_REC.ITEM_QTY,
           NULL,
           REC.CREATED_BY,
           SYSDATE,
           REC.LAST_UPDATED_BY,
           SYSDATE,
           1,
           INTF_LINE_REC.ENTITY_ID,
           V_PRODUCING_AREA_ID,
           V_PRODUCING_AREA_CODE,
           V_PRODUCING_AREA_NAME,
           V_PRODUCING_DISTRICT_ID,
           V_PRODUCING_DISTRICT_CODE,
           V_PRODUCING_DISTRICT_FULL_NAME,
           INTF_LINE_REC.ITEM_BOX_QTY
           );
           
        END LOOP;
        
        UPDATE T_PLN_BOOK_HEADER H
           SET H.TO_ECSCM_INTF_FLAG = v_True, H.LAST_UPDATE_DATE = SYSDATE
         WHERE H.HEADER_ID = REC.HEADER_ID;
    END LOOP;
                                
  EXCEPTION
    WHEN V_BASE_EXCEPTION THEN
      P_RESULT  := -27001;
      P_ERR_MSG := '预约单写入ECSCM接口表出错：' || P_ERR_MSG;
    WHEN OTHERS THEN
      P_RESULT  := -27001;
      P_ERR_MSG := '预约单写入ECSCM接口表发生异常：' || SQLERRM;
  END P_BOOK_INFO_2_ECSCM;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2018-07-04
  *     创建者：周建刚
  *   功能说明：更新合并预约批次编码
  *   同一开单批次，合并预约规则：
  *   1、中心、仓库不同不可合并预约
  *   2、中心、仓库相同
  *   2.1、产品相同不可合并预约
  *   2.2、产品不同可合并预约
  *   示例： 
  *   1、北京中心、大件运营中心仓，上海中心、大件运营中心仓。中心不同，不可合并预约。
  *   2、北京中心、大件运营中心仓、产品1，北京中心、大件运营中心仓、产品2。中心、仓库相同，产品不同，可合并预约。
  *   3、北京中心、大件运营中心仓、产品1；北京中心、大件运营中心仓、产品1。中心、仓库相同，产品相同，不可合并预约。
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_BOOK_UPDATE_OUT_BATCH_NUM(P_ENTITY_ID IN NUMBER, --主体ID
                                       P_BATCH_ID         IN NUMBER,   --批处理ID
                                       P_USER_CODE        IN VARCHAR2, --操作用户编码
                                       P_RESULT           OUT NUMBER,  --返回错误ID
                                       P_ERR_MSG          OUT VARCHAR2 --返回错误信息
                                       ) IS
    
    R_PLN_BOOK_LINE                  T_PLN_BOOK_LINE%ROWTYPE;
    V_ITEM_CODE                      CIMS.T_PLN_BOOK_LINE.ITEM_CODE%TYPE := '';
    V_ITEM_CODE_COUNT                NUMBER := 0;
    V_TO_OUT_SYS_BATCH_NUM_FLAG      VARCHAR2(1000);--合并预约标识
    V_TO_OUT_SYS_BATCH_NUM_TMP       VARCHAR2(1000) := '';--合并预约标识，临时变量
    V_TO_OUT_SYS_BATCH_NUM_POSTFIX   VARCHAR2(1000) := '';--批次后缀标识
    V_TO_OUT_SYS_BATCH_NUM_CHECK     VARCHAR2(1000);--采购单超过10张的合并预约标识。
    V_PLN_BOOK_BATCH_FLAG            VARCHAR2(32);--是否启用合并预约。
  BEGIN
    P_RESULT  := 0;
    P_ERR_MSG := V_SUCCESS;
    
    --预约单是否合并预约
    BEGIN
      PKG_BD.P_GET_PARAMETER_VALUE('PLN_BOOK_BATCH_FLAG',
                                   P_ENTITY_ID,
                                   NULL,
                                   NULL,
                                   V_PLN_BOOK_BATCH_FLAG);
    EXCEPTION
      WHEN OTHERS THEN
        P_RESULT  := -58001;
        P_ERR_MSG := '主体参数[PLN_BOOK_BATCH_FLAG],主体id[' ||
                     P_ENTITY_ID || ']的参数设置异常，请检查！' || SQLERRM;
        RAISE V_BASE_EXCEPTION;
    END;
    
    IF (V_PLN_BOOK_BATCH_FLAG = 'N') THEN
      UPDATE CIMS.T_PLN_BOOK_HEADER H
         SET H.TO_OUT_SYS_BATCH_NUM = H.BOOK_NUM,H.LAST_UPDATE_DATE = SYSDATE
       WHERE H.BATCH_ID = P_BATCH_ID;
       
       RETURN;
    END IF;

    --京东预约类型，合并预约标识（京东拆单规则：配送中心、配送仓库、不同产品可合并预约，否则京东自动拆分预约）
    FOR REC IN (SELECT H.ENTITY_ID,
                       H.BOOK_NUM,
                       H.BATCH_ID,
                       L.DISTRIBUTION_CENTER_NAME,
                       L.DISTRIBUTION_CENTER_CODE,
                       L.DISTRIBUTION_WAREHOUSE_CODE,
                       L.DISTRIBUTION_WAREHOUSE_NAME,
                       L.ITEM_CODE,
                       L.ITEM_NAME,
                       L.SRC_BILL_NUM,
                       L.OUT_ORDER_NUM
                  FROM CIMS.T_PLN_BOOK_LINE L, CIMS.T_PLN_BOOK_HEADER H
                 WHERE H.HEADER_ID = L.HEADER_ID
                   AND H.BOOK_TYPE = 'JD'
                   AND H.BATCH_ID = P_BATCH_ID
                 ORDER BY H.BATCH_ID,L.DISTRIBUTION_CENTER_CODE,L.DISTRIBUTION_WAREHOUSE_CODE,H.BOOK_NUM,L.ITEM_CODE
                ) LOOP
      
      V_TO_OUT_SYS_BATCH_NUM_TMP := REC.BATCH_ID || '-' ||
                                    REC.DISTRIBUTION_CENTER_CODE || '-' ||
                                    REC.DISTRIBUTION_WAREHOUSE_CODE;
                                       
      IF (V_TO_OUT_SYS_BATCH_NUM_FLAG IS NULL) THEN
        V_TO_OUT_SYS_BATCH_NUM_FLAG := V_TO_OUT_SYS_BATCH_NUM_TMP;
        V_ITEM_CODE                 := REC.ITEM_CODE;
        V_ITEM_CODE_COUNT           := 0;
      ELSE
        IF (V_TO_OUT_SYS_BATCH_NUM_FLAG = V_TO_OUT_SYS_BATCH_NUM_TMP) THEN
          IF (REC.ITEM_CODE = V_ITEM_CODE) THEN
            V_ITEM_CODE_COUNT := V_ITEM_CODE_COUNT + 1;
            V_TO_OUT_SYS_BATCH_NUM_POSTFIX :=  '-' || REC.ITEM_CODE || '-' || V_ITEM_CODE_COUNT;
          ELSE
            V_ITEM_CODE_COUNT := 0;
            V_ITEM_CODE := REC.ITEM_CODE;
          END IF;
        ELSE
          V_TO_OUT_SYS_BATCH_NUM_FLAG := V_TO_OUT_SYS_BATCH_NUM_TMP;
          V_ITEM_CODE_COUNT := 0;
          V_ITEM_CODE := REC.ITEM_CODE;
        END IF;
      END IF;
      
      UPDATE CIMS.T_PLN_BOOK_HEADER BH
         SET BH.TO_OUT_SYS_BATCH_NUM = V_TO_OUT_SYS_BATCH_NUM_FLAG || V_TO_OUT_SYS_BATCH_NUM_POSTFIX,
             BH.LAST_UPDATED_BY = P_USER_CODE,
             BH.LAST_UPDATE_DATE     = SYSDATE
       WHERE BH.BOOK_NUM = REC.BOOK_NUM;
      
      V_TO_OUT_SYS_BATCH_NUM_POSTFIX := '';
    END LOOP;
    
    BEGIN
      --校验合并批次中的预约单不能超过10张采购单
      SELECT T.TO_OUT_SYS_BATCH_NUM INTO V_TO_OUT_SYS_BATCH_NUM_CHECK FROM 
      (SELECT H.TO_OUT_SYS_BATCH_NUM
        FROM CIMS.T_PLN_BOOK_HEADER H
       WHERE H.BOOK_TYPE = 'JD'
         AND H.BATCH_ID = P_BATCH_ID
       GROUP BY H.TO_OUT_SYS_BATCH_NUM
      HAVING COUNT(1) > 10) T WHERE ROWNUM = 1;
      
      IF (V_TO_OUT_SYS_BATCH_NUM_CHECK IS NOT NULL) THEN
        P_ERR_MSG := '受外部(京东)电商平台预约规则限制，相同配送中心、仓库，合并预约的数量不能超过10张采购单，请确认 ！';
        RAISE V_BASE_EXCEPTION;
      END IF;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        NULL;
      WHEN OTHERS THEN
        P_RESULT  := -58001;
        P_ERR_MSG := P_ERR_MSG;
        RAISE V_BASE_EXCEPTION;
    END;
    
  EXCEPTION
    WHEN V_BASE_EXCEPTION THEN
      P_RESULT  := -27001;
      P_ERR_MSG := '更新合并预约批次编码出错：' || P_ERR_MSG;
    WHEN OTHERS THEN
      P_RESULT  := -27001;
      P_ERR_MSG := '更新合并预约批次编码，发生异常：' || NVL(P_ERR_MSG,' ') || SQLERRM;
  END P_BOOK_UPDATE_OUT_BATCH_NUM;
  
  -------------------------------------------------------------------------------                 
  /*
  *   创建日期：2018-12-07
  *     创建者：huanghb12
  *   功能说明：预约单取消或者确认的时候后，刷新集拼单下的要求发货日期，预约确认后：将预约日期写到了发货通知单上，取消后：发货通知单上抹去了预约信息，修改集拼单及发货通知单的要求发货日期。
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_REVISE_REQUIRE_SHIP_DATE(P_COLLAGE_ORDER_NUM IN VARCHAR2,--集拼单号
                                       P_USER_CODE      IN VARCHAR2, --操作用户编码
                                       P_RESULT         OUT NUMBER,  --返回错误ID
                                       P_ERR_MSG        OUT VARCHAR2 --返回错误信息
                                       ) IS 

    R_LG_SHIP_COLLAGE T_LG_SHIP_COLLAGE%ROWTYPE; --ADD BY huanghb12
    
    V_COUNT NUMBER;               --计数 DD BY huanghb12
    V_MIN_REQUIRE_SHIP_DATE DATE;      --ADD BY huanghb12
    V_SYS_SOURCE VARCHAR2(32) := 'CIMS';
    
  BEGIN
    P_RESULT  := 0;
    P_ERR_MSG := V_SUCCESS;
    
    IF (P_USER_CODE IS NOT NULL) THEN
      V_SYS_SOURCE := P_USER_CODE;
    END IF;
    --add by huanghb12 20181204 检查回写的预约确认日期，批量修改集拼单的预约收货日期
      SELECT COUNT(1) INTO V_COUNT
          FROM CIMS.T_LG_SHIP_COLLAGE SC
          WHERE SC.COLLAGE_ORDER_NUM = P_COLLAGE_ORDER_NUM
          AND SC.COLLAGE_ORDER_STATUS IN ('collageOrderStatus01','collageOrderStatus02');
      IF V_COUNT > 0 THEN
        --获取集拼单
        BEGIN
          SELECT SC.* INTO R_LG_SHIP_COLLAGE
            FROM CIMS.T_LG_SHIP_COLLAGE SC
            WHERE SC.COLLAGE_ORDER_NUM = P_COLLAGE_ORDER_NUM
            AND SC.COLLAGE_ORDER_STATUS IN ('collageOrderStatus01','collageOrderStatus02')
            FOR UPDATE NOWAIT;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            P_ERR_MSG := '集拼单不存在或者已取消，请检查！';
            RAISE V_BASE_EXCEPTION;
          WHEN OTHERS THEN
            P_ERR_MSG := '集拼单正被其他用户使用，请稍后再试 ！';
            RAISE V_BASE_EXCEPTION;
        END;
        
        --检查集拼单是否存在下线直发的单据,存在下线直发的单据则不更新集拼单的要求发货日期
        SELECT COUNT(1) INTO V_COUNT
          FROM CIMS.T_LG_SHIP_DOC SD
          WHERE SD.COLLAGE_ORDER_NUM = P_COLLAGE_ORDER_NUM
          AND SD.DIRECT_TRANSPORT_FALG = 'Y';
          
      ELSIF (V_COUNT = 0) THEN
        V_COUNT := -1;
      END IF; 
      
        IF V_COUNT > 0 THEN
           V_COUNT := -1;
        ELSIF (V_COUNT = 0) THEN
          --检查本单是否是集拼单中是否存在已经确认的预约信息,
          SELECT COUNT(1) INTO V_COUNT
            FROM CIMS.T_LG_SHIP_DOC SD,
                 CIMS.T_PLN_BOOK_HEADER BH
            WHERE SD.BOOK_NUM_CIMS = BH.BOOK_NUM
            AND SD.COLLAGE_ORDER_NUM = P_COLLAGE_ORDER_NUM
            AND sd.direct_transport_falg = 'N'  --非下线直发                                                  
            AND BH.BOOK_STATUS = '01';
        END IF;   
             
        --如果存在已确认的预约单则对比已有要求发货日期
        IF V_COUNT > 0 THEN
          --获取整个集拼单的最早的要求发货日期
          SELECT MIN(SD.BOOK_RECEIPT_DATE - NVL(SD.PRE_LIMITE,0)) INTO V_MIN_REQUIRE_SHIP_DATE
            FROM CIMS.T_LG_SHIP_DOC SD,
                 CIMS.T_PLN_BOOK_HEADER BH
            WHERE SD.BOOK_NUM_CIMS = BH.BOOK_NUM
            AND SD.COLLAGE_ORDER_NUM = P_COLLAGE_ORDER_NUM
            AND sd.direct_transport_falg = 'N'  --非下线直发                                                  
            AND BH.BOOK_STATUS = '01'; 
        
          --如果集拼单上的要求发货日期与集拼单下所有发货通知单的最小要求发货日期 则更新
           IF R_LG_SHIP_COLLAGE.Require_Ship_Date != V_MIN_REQUIRE_SHIP_DATE THEN
              UPDATE CIMS.T_LG_SHIP_COLLAGE SC
               SET SC.REQUIRE_SHIP_DATE = V_MIN_REQUIRE_SHIP_DATE,
                   SC.LAST_UPDATED_BY   = V_SYS_SOURCE,
                   SC.LAST_UPDATE_DATE  = SYSDATE,
                   SC.VERSION           = NVL(SC.VERSION,0) + 1
               WHERE SC.COLLAGE_ORDER_NUM = P_COLLAGE_ORDER_NUM;
             UPDATE CIMS.T_LG_SHIP_DOC SD
               SET SD.REQUIRE_SHIP_DATE = V_MIN_REQUIRE_SHIP_DATE,
                   SD.LAST_UPDATED_BY   = V_SYS_SOURCE,
                   SD.LAST_UPDATE_DATE  = SYSDATE
               WHERE SD.COLLAGE_ORDER_NUM = P_COLLAGE_ORDER_NUM;  
           END IF;   
        END IF;    
  END P_REVISE_REQUIRE_SHIP_DATE;
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2019-3-27
  *     创建者：lilh6
  *   功能说明：下线直发库存校验,安得装车前调用
  */
  -------------------------------------------------------------------------------
  Procedure p_Pln_Direct_Inv_Check(p_Esb_Num    In Varchar2, --ESB流水号
                                  p_Check_Type In Varchar2, --校验类型：CHECK  CANCEL
                                  p_Result     Out Varchar2 --返回错误信息
                                  ) Is
   v_Value               Varchar2(4000);
   v_Qty                 Number;
   v_Check_Qty           Number;
   v_Ship_Inventory_Id   Number;
   v_Ship_Inventory_Code Varchar2(100);
   v_Ship_Inventory_Name Varchar2(100);
   v_Entity_Id           Number;
   v_Ship_Doc_Line_Id    Number;
   v_Order_Number        Varchar2(32);
   v_Order_Line_Id       Number;
   v_Item_Id             Number;
   v_Check_Qty_last      Number;
   v_Order_Line_Id_n     Number;
  Begin
   p_Result := v_Success;
   Savepoint sp1;
   v_Value := '下线直发库存校验失败！';
   v_Order_Line_Id_n := 0;
   v_Check_Qty_last := 0;
   For r_Info In (Select *
                    From Intf_Pln_Lg_Ship_Check c
                   Where c.Esb_Num = p_Esb_Num
                   Order By c.item_code) Loop
     --查找发货通知单信息
     Begin
       Select d.Ship_Inventory_Id,
              d.Ship_Inventory_Code,
              d.Ship_Inventory_Name,
              d.Entity_Id,
              l.Ship_Doc_Line_Id,
              l.Origin_Order_Num,
              l.Origin_Line_Id,
              i.Item_Id
         Into v_Ship_Inventory_Id,
              v_Ship_Inventory_Code,
              v_Ship_Inventory_Name,
              v_Entity_Id,
              v_Ship_Doc_Line_Id,
              v_Order_Number,
              v_Order_Line_Id,
              v_Item_Id
         From t_Lg_Ship_Doc d, t_Lg_Ship_Doc_Line l, t_Bd_Item i
        Where d.Ship_Doc_Id = l.Ship_Doc_Id
          And d.Entity_Id = i.Entity_Id
          And l.Item_Code = i.Item_Code
          And d.Ship_Doc_Code = r_Info.Ship_Doc_Code
          And l.Item_Code = r_Info.Item_Code;
     Exception
       When Others Then
         p_Result := '查找不到发货通知单信息！发货通知单号：' || r_Info.Ship_Doc_Code ||
                     '，产品编码：' || r_Info.Item_Code;
         v_Value := p_Result;
         Raise v_Base_Exception;
     End;
     
     --不管什么模式，先更新发货通知单行的下线直发库存校验锁定数量
     Update t_Lg_Ship_Doc_Line l
        Set l.Direct_Inv_Check_Qty = Nvl(r_Info.Item_Qty, 0) +
                                     Nvl(r_Info.Divided_Item_Qty, 0),
            l.direct_inv_cancel_qty = l.cancel_qty,
            l.Last_Update_Date     = Sysdate
      Where l.Ship_Doc_Line_Id = v_Ship_Doc_Line_Id;
     --CHECK模式的才校验库存
     If p_Check_Type = 'CHECK' Then
       --开始检验库存
       --获取当前锁定可用库存
       Begin
         Select Sum(Nvl(o.Stock_Affirm_Qty, 0) + Nvl(o.Supply_Qty, 0) -
                    Nvl(o.Sundry_Qty, 0) - Nvl(o.So_Order_Qty, 0))
           Into v_Qty
           From t_Pln_Order_Inv_Occupy o
          Where o.Origin_Number = v_Order_Number
            And o.Origin_Line_Id = v_Order_Line_Id
            And o.Inventory_Id = v_Ship_Inventory_Id
            And o.Item_Id = v_Item_Id;
       Exception
         When Others Then
           v_Qty := 0;
       End;
       --获取待校验的库存数,已经校验过的有校验锁定数量的也要统计上
       Select Sum(greatest(Nvl(l.Direct_Inv_Check_Qty, 0) - Nvl(l.Fact_Ship_Qty, 0) - (nvl(l.cancel_qty,0) - nvl(l.direct_inv_cancel_qty,0)),0))
         Into v_Check_Qty
         From Cims.t_Lg_Ship_Doc d, Cims.t_Lg_Ship_Doc_Line l
        Where d.Ship_Doc_Id = l.Ship_Doc_Id
          And l.Origin_Line_Id = v_Order_Line_Id
          And d.Entity_Id = v_Entity_Id
          And l.Direct_Inv_Check_Qty Is Not Null;
       
       If v_Order_Line_Id_n <> v_Order_Line_Id Then
         --计划订单不一样
         v_Order_Line_Id_n := v_Order_Line_Id;
         v_Check_Qty_last := 0;
       End If;
       
       If v_Check_Qty - v_Check_Qty_last > Nvl(v_Qty, 0) Then
         p_Result := '发货通知单号：' || r_Info.Ship_Doc_Code ||
                     '，对应的计划订单号：' || v_Order_Number || '，产品编码：' ||
                     r_Info.Item_Code || '的入库数量不足，不满足数量：[' ||
                     to_char(v_Check_Qty - v_Check_Qty_last - Nvl(v_Qty, 0)) || ']' || v_Nl;
         v_Value := v_Value || p_Result;
         v_Check_Qty_last := v_Check_Qty - Nvl(v_Qty, 0);
       End If;
     End If;
   End Loop;
   
   If p_Result = v_Success Then
     --更新接口表状态，信息
     Update Intf_Pln_Lg_Ship_Check c
        Set c.Intf_Status      = 'S',
            c.Intf_Msg         = 'SUCCESS',
            c.Last_Updated_By  = 'CIMS',
            c.Last_Update_Date = Sysdate
      Where c.Esb_Num = p_Esb_Num;
   Else
     v_Value := v_value || '请联系中转人员先操作中转入库。';
     Raise v_Base_Exception;
   End If;
   
  Exception
   When v_Base_Exception Then
     Rollback To sp1;
     p_Result := '异常过程：PKG_PLN_INTF.p_Pln_Direct_Inv_Check' || v_Nl ||
                 v_Value;
     Update Intf_Pln_Lg_Ship_Check c
        Set c.Intf_Status      = 'E',
            c.Intf_Msg         = v_Value,
            c.Last_Updated_By  = 'CIMS',
            c.Last_Update_Date = Sysdate
      Where c.Esb_Num = p_Esb_Num;
   When Others Then
     Rollback To sp1;
     p_Result := '下线直发订单库存校验失败。' || v_Nl || '失败信息：' || Sqlerrm;
     Update Intf_Pln_Lg_Ship_Check c
        Set c.Intf_Status      = 'E',
            c.Intf_Msg         = p_Result,
            c.Last_Updated_By  = 'CIMS',
            c.Last_Update_Date = Sysdate
      Where c.Esb_Num = p_Esb_Num;
  End p_Pln_Direct_Inv_Check;
End Pkg_Pln_Intf;
/

