create PACKAGE BODY      PKG_AR_RPT IS
  PROCEDURE P_DAILY_RECEIPT_REPORT(P_REPORT_DATE IN DATE) IS
    V_COUNT   NUMBER;
    V_ERR_MSG T_PUB_ERROR_TRACE.ERROR_MESS%TYPE;

  BEGIN
    --家用内销销售回款日报表

    INSERT INTO T_PUB_ERROR_TRACE
      (ERROR_ID, TITLE_NAME, ERROR_MESS, CREATION_DATE)
    VALUES
      (S_PUB_ERROR_TRACE.NEXTVAL,
       UPPER('P_DAILY_RECEIPT_REPORT'),
       '准备运行P_DAILY_RECEIPT_REPORT',
       SYSDATE);

    --先检查是否存在统计日期的数据，存在则先删除
    SELECT COUNT(1)
      INTO V_COUNT
      FROM T_DAILY_RECEIPT_ALL A
     WHERE TRUNC(A.REPORT_DATE) = TRUNC(P_REPORT_DATE);

    IF V_COUNT > 0 THEN
      DELETE FROM T_DAILY_RECEIPT_ALL A
       WHERE TRUNC(A.REPORT_DATE) = TRUNC(P_REPORT_DATE);
    END IF;

    BEGIN
      --写入销售回款记录表
      INSERT INTO T_DAILY_RECEIPT_ALL
        (REPORT_DATE, --统计日期
         ATTRIBUTE1, --收款方法ID
         ATTRIBUTE2, --收款方法名称
         ATTRIBUTE3, --收款类型（承兑、现汇）
         ATTRIBUTE4, --收款类型名称
         ATTRIBUTE5, --业务分类（收款、转款、退款、费用转到款、其他转到款）
         ATTRIBUTE6, --业务分类名称
         ATTRIBUTE10, --报表分类
         ATTRIBUTE11, --本日数
         ATTRIBUTE12, --本月累计
         ATTRIBUTE13, --本年累计
         ATTRIBUTE31, --回款类型
         ATTRIBUTE22) --主体
        SELECT P.REPORT_DATE,
               P.receipt_method_id,
               P.receipt_method_name,
               P.receipt_type,
               P.receipt_type_name,
               P.business_type,
               P.business_type_name,
               P.report_type,
               NVL(SUM(P.DAILY_AMOUNT), 0) / 10000 DAILY_AMOUNT,
               NVL(SUM(P.MONTH_AMOUNT), 0) / 10000 MONTH_AMOUNT,
               NVL(SUM(P.YEAR_AMOUNT), 0) / 10000 YEAR_AMOUNT,
               '非安装',
               P.Entity_Id

          FROM (SELECT TRUNC(P_REPORT_DATE) REPORT_DATE,
                       methods.receipt_method_id receipt_method_id,
                       methods.receipt_method_name receipt_method_name,
                       methods.receipt_type receipt_type,
                       receipt_type.code_name receipt_type_name,
                       methods.business_type business_type,
                       bussines_type.code_name business_type_name,
                       '家用内销销售回款日报表' report_type,
--                       (SELECT DISTINCT v.entity_name FROM cims.V_BD_ENTITY v WHERE v.entity_id = headers.entity_id)||'内销销售回款日报表' report_type,
                       --统计日期当天
                       DECODE(TRUNC(headers.REVIEWED_DATE),-- 改为确认日期
                              TRUNC(P_REPORT_DATE),
                              headers.AMOUNT,
                              0) DAILY_AMOUNT,
                       --统计日期当月
                       DECODE(TRUNC(headers.REVIEWED_DATE, 'MM'),-- 改为确认日期
                              TRUNC(P_REPORT_DATE, 'MM'),
                              headers.AMOUNT,
                              0) MONTH_AMOUNT,
                       --统计日期当年
                       DECODE(TRUNC(headers.REVIEWED_DATE, 'YYYY'),-- 改为确认日期
                              TRUNC(P_REPORT_DATE, 'YYYY'),
                              headers.AMOUNT,
                              0) YEAR_AMOUNT,
                       methods.Entity_Id Entity_Id

                  FROM T_AR_RECEIPT_METHODS methods,
                       (select ar.*
		                  from cims.T_AR_CASH_RECEIPT_HEADERS AR
		                 where 1 = 1
		                   	and not exists (select 1 from cims.up_org_unit unit where 1=1
		                   		and unit.entity_id = ar.entity_id
                          and AR.SALES_CENTER_ID = unit.unit_id
		                   		and unit.code in
		                              (select conf.center_code
		                                 from cims.t_ar_mount_center_conf conf
		                                where conf.entity_id = ar.entity_id))
                         	and receipt_status_id NOT IN (1, 2, 12,10,19)
                         and TRUNC(REVIEWED_DATE)<= TRUNC(P_REPORT_DATE)) headers,-- 改为确认日期
                       (SELECT *
                          FROM UP_CODELIST
                         WHERE CODETYPE = 'ar_method_receipt') receipt_type,
                       (SELECT *
                          FROM UP_CODELIST
                         WHERE CODETYPE = 'ar_method_business') bussines_type
                 WHERE methods.receipt_method_id =
                       headers.Receipt_Method_Id(+)
                   AND methods.Receipt_Type = receipt_type.code_value(+)
                   AND methods.business_type = bussines_type.code_value(+)
                   AND methods.entity_id = headers.entity_id(+)) P
         GROUP BY P.REPORT_DATE,
                  P.receipt_method_id,
                  P.receipt_method_name,
                  P.receipt_type,
                  P.receipt_type_name,
                  P.business_type,
                  P.business_type_name,
                  P.report_type,
                  P.Entity_Id;

      --写入安装回款记录表
      INSERT INTO T_DAILY_RECEIPT_ALL
        (REPORT_DATE, --统计日期
         ATTRIBUTE1, --收款方法ID
         ATTRIBUTE2, --收款方法名称
         ATTRIBUTE3, --收款类型（承兑、现汇）
         ATTRIBUTE4, --收款类型名称
         ATTRIBUTE5, --业务分类（收款、转款、退款、费用转到款、其他转到款）
         ATTRIBUTE6, --业务分类名称
         ATTRIBUTE10, --报表分类
         ATTRIBUTE11, --本日数
         ATTRIBUTE12, --本月累计
         ATTRIBUTE13, --本年累计
         ATTRIBUTE31, --回款类型
         ATTRIBUTE22) --主体
        SELECT P.REPORT_DATE,
               P.receipt_method_id,
               P.receipt_method_name,
               P.receipt_type,
               P.receipt_type_name,
               P.business_type,
               P.business_type_name,
               P.report_type,
               NVL(SUM(P.DAILY_AMOUNT), 0) / 10000 DAILY_AMOUNT,
               NVL(SUM(P.MONTH_AMOUNT), 0) / 10000 MONTH_AMOUNT,
               NVL(SUM(P.YEAR_AMOUNT), 0) / 10000 YEAR_AMOUNT,
               '安装',
               P.Entity_Id

          FROM (SELECT TRUNC(P_REPORT_DATE) REPORT_DATE,
                       methods.receipt_method_id receipt_method_id,
                       methods.receipt_method_name receipt_method_name,
                       methods.receipt_type receipt_type,
                       receipt_type.code_name receipt_type_name,
                       methods.business_type business_type,
                       bussines_type.code_name business_type_name,
                       '家用内销销售回款日报表' report_type,
--                       (SELECT DISTINCT v.entity_name FROM cims.V_BD_ENTITY v WHERE v.entity_id = headers.entity_id)||'内销销售回款日报表' report_type,
                       --统计日期当天
                       DECODE(TRUNC(headers.REVIEWED_DATE),-- 改为确认日期
                              TRUNC(P_REPORT_DATE),
                              headers.AMOUNT,
                              0) DAILY_AMOUNT,
                       --统计日期当月
                       DECODE(TRUNC(headers.REVIEWED_DATE, 'MM'),-- 改为确认日期
                              TRUNC(P_REPORT_DATE, 'MM'),
                              headers.AMOUNT,
                              0) MONTH_AMOUNT,
                       --统计日期当年
                       DECODE(TRUNC(headers.REVIEWED_DATE, 'YYYY'),-- 改为确认日期
                              TRUNC(P_REPORT_DATE, 'YYYY'),
                              headers.AMOUNT,
                              0) YEAR_AMOUNT,
                       methods.Entity_Id Entity_Id

                  FROM T_AR_RECEIPT_METHODS methods,
                       (select ar.*
		                  from cims.T_AR_CASH_RECEIPT_HEADERS AR
		                 where 1 = 1
		                   	and exists (select 1 from cims.up_org_unit unit where 1=1
		                   		and unit.entity_id = ar.entity_id
                          and AR.SALES_CENTER_ID = unit.unit_id
		                   		and unit.code in
		                              (select conf.center_code
		                                 from cims.t_ar_mount_center_conf conf
		                                where conf.entity_id = ar.entity_id))
                         	and receipt_status_id NOT IN (1, 2, 12,10,19)
                         and TRUNC(REVIEWED_DATE)<= TRUNC(P_REPORT_DATE)) headers,-- 改为确认日期
                       (SELECT *
                          FROM UP_CODELIST
                         WHERE CODETYPE = 'ar_method_receipt') receipt_type,
                       (SELECT *
                          FROM UP_CODELIST
                         WHERE CODETYPE = 'ar_method_business') bussines_type
                 WHERE methods.receipt_method_id =
                       headers.Receipt_Method_Id(+)
                   AND methods.Receipt_Type = receipt_type.code_value(+)
                   AND methods.business_type = bussines_type.code_value(+)
                   AND methods.entity_id = headers.entity_id(+)) P
         GROUP BY P.REPORT_DATE,
                  P.receipt_method_id,
                  P.receipt_method_name,
                  P.receipt_type,
                  P.receipt_type_name,
                  P.business_type,
                  P.business_type_name,
                  P.report_type,
                  P.Entity_Id;
      COMMIT;
    EXCEPTION
      WHEN OTHERS THEN
        V_ERR_MSG := SUBSTRB(SQLERRM, 1, 500);
        INSERT INTO T_PUB_ERROR_TRACE
          (ERROR_ID, TITLE_NAME, ERROR_MESS, CREATION_DATE)
        VALUES
          (S_PUB_ERROR_TRACE.NEXTVAL,
           UPPER('P_DAILY_RECEIPT_REPORT'),
           V_ERR_MSG,
           SYSDATE);
        COMMIT;
    END;

    --家用内销回款在途日报表
    BEGIN
      INSERT INTO T_DAILY_RECEIPT_ALL
        (REPORT_DATE, --统计日期
         ATTRIBUTE1, --收款方法ID
         ATTRIBUTE2, --收款方法名称
         ATTRIBUTE7, --营销大类编码
         ATTRIBUTE8, --营销大类名称
         ATTRIBUTE10, --报表分类
         ATTRIBUTE11, --国内营销在途待审核1-2
         ATTRIBUTE12, --国内营销在途待审核3-4
         ATTRIBUTE13, --国内营销在途待审核5-6
         ATTRIBUTE14, --国内营销在途待审核7-8
         ATTRIBUTE15, --国内营销在途待审核8天以上
         ATTRIBUTE16, --事业部资金管理待核销1-2
         ATTRIBUTE17, --事业部资金管理待核销3-4
         ATTRIBUTE18, --事业部资金管理待核销5-6
         ATTRIBUTE19, --事业部资金管理待核销7-8
         ATTRIBUTE20, --事业部资金管理待核销8天以上
         ATTRIBUTE22 --主体
         )
        select H.REPORT_DATE,
               H.receipt_method_id,
               H.receipt_method_name,
               H.SALES_MAIN_TYPE_CODE,
               H.SALES_MAIN_TYPE_NAME,
               H.report_type,
               SUM(DECODE(H.GTMS_REGIS_TIME,--登记时间=null,当前时间-单据日期
                          NULL,
                          DECODE(H.STATUS_ID,6,0,
                          DECODE((TRUNC(P_REPORT_DATE) -
                                 TRUNC(H.CASH_RECEIPT_DATE)),
                                 1, --国内营销1天
                                 H.AMOUNT,
                                 2, --国内营销2天
                                 H.AMOUNT,
                                 0)),
                          0))/10000,
               SUM(DECODE(H.GTMS_REGIS_TIME,--登记时间=null,当前时间-单据日期
                          NULL,
                          DECODE(H.STATUS_ID,6,0,
                          DECODE((TRUNC(P_REPORT_DATE) -
                                 TRUNC(H.CASH_RECEIPT_DATE)),
                                 3, --国内营销3天
                                 H.AMOUNT,
                                 4, --国内营销4天
                                 H.AMOUNT,
                                 0)),
                          0))/10000,
               SUM(DECODE(H.GTMS_REGIS_TIME,--登记时间=null,当前时间-单据日期
                          NULL,
                          DECODE(H.STATUS_ID,6,0,
                          DECODE((TRUNC(P_REPORT_DATE) -
                                 TRUNC(H.CASH_RECEIPT_DATE)),
                                 5, --国内营销5天
                                 H.AMOUNT,
                                 6, --国内营销6天
                                 H.AMOUNT,
                                 0)),
                          0))/10000,
               SUM(DECODE(H.GTMS_REGIS_TIME,--登记时间=null,当前时间-单据日期
                          NULL,
                          DECODE(H.STATUS_ID,6,0,
                          DECODE((TRUNC(P_REPORT_DATE) -
                                 TRUNC(H.CASH_RECEIPT_DATE)),
                                 7, --国内营销7天
                                 H.AMOUNT,
                                 8, --国内营销8天
                                 H.AMOUNT,
                                 0)),
                          0))/10000,
               SUM(DECODE(H.GTMS_REGIS_TIME,--登记时间=null,当前时间-单据日期
                          NULL,
                          DECODE(H.STATUS_ID,6,0,
                          DECODE(SIGN((TRUNC(P_REPORT_DATE) -
                                      TRUNC(H.CASH_RECEIPT_DATE) - 8)),
                                 1, --国内营销超8天
                                 H.AMOUNT,
                                 0)),
                          0))/10000,
               SUM(DECODE(to_char(H.GTMS_REGIS_TIME,'yyyy-mm-dd')||to_char(H.GTMS_SIGN_TIME,'yyyy-mm-dd'),--登记时间<>null and 入库时间=null
                          to_char(H.GTMS_REGIS_TIME,'yyyy-mm-dd'),
                          DECODE((TRUNC(P_REPORT_DATE) -
                                 TRUNC(H.GTMS_REGIS_TIME)),
                                 1, --事业部1天
                                 H.AMOUNT,
                                 2, --事业部2天
                                 H.AMOUNT,
                                 0),
                          0))/10000,
               SUM(DECODE(to_char(H.GTMS_REGIS_TIME,'yyyy-mm-dd')||to_char(H.GTMS_SIGN_TIME,'yyyy-mm-dd'),--登记时间<>null and 入库时间=null
                          to_char(H.GTMS_REGIS_TIME,'yyyy-mm-dd'),
                          DECODE((TRUNC(P_REPORT_DATE) -
                                 TRUNC(H.GTMS_REGIS_TIME)),
                                 1, --事业部3天
                                 H.AMOUNT,
                                 2, --事业部4天
                                 H.AMOUNT,
                                 0),
                          0))/10000,
               SUM(DECODE(to_char(H.GTMS_REGIS_TIME,'yyyy-mm-dd')||to_char(H.GTMS_SIGN_TIME,'yyyy-mm-dd'),--登记时间<>null and 入库时间=null
                          to_char(H.GTMS_REGIS_TIME,'yyyy-mm-dd'),
                          DECODE((TRUNC(P_REPORT_DATE) -
                                 TRUNC(H.GTMS_REGIS_TIME)),
                                 1, --事业部5天
                                 H.AMOUNT,
                                 2, --事业部6天
                                 H.AMOUNT,
                                 0),
                          0))/10000,
               SUM(DECODE(to_char(H.GTMS_REGIS_TIME,'yyyy-mm-dd')||to_char(H.GTMS_SIGN_TIME,'yyyy-mm-dd'),--登记时间<>null and 入库时间=null
                          to_char(H.GTMS_REGIS_TIME,'yyyy-mm-dd'),
                          DECODE((TRUNC(P_REPORT_DATE) -
                                 TRUNC(H.GTMS_REGIS_TIME)),
                                 1, --事业部7天
                                 H.AMOUNT,
                                 2, --事业部8天
                                 H.AMOUNT,
                                 0),
                          0))/10000,
               SUM(DECODE(to_char(H.GTMS_REGIS_TIME,'yyyy-mm-dd')||to_char(H.GTMS_SIGN_TIME,'yyyy-mm-dd'),--登记时间<>null and 入库时间=null
                          to_char(H.GTMS_REGIS_TIME,'yyyy-mm-dd'),
                          DECODE(SIGN((TRUNC(P_REPORT_DATE) -
                                 TRUNC(H.GTMS_REGIS_TIME)-8)),
                                 1, --事业部超8天
                                 H.AMOUNT,
                                 0),
                          0))/10000,
               H.ENTITY_ID
          from (select TRUNC(P_REPORT_DATE) REPORT_DATE,
                       methods.receipt_method_id receipt_method_id,
                       methods.receipt_method_name receipt_method_name,
                       cash.SALES_MAIN_TYPE_CODE SALES_MAIN_TYPE_CODE,
                       cash.SALES_MAIN_TYPE_NAME SALES_MAIN_TYPE_NAME,
                       '家用内销回款在途日报表' report_type,
--                       (SELECT DISTINCT v.entity_name FROM cims.V_BD_ENTITY v WHERE v.entity_id = cash.entity_id)||'内销回款在途日报表' report_type,
                       TRUNC(cash.CASH_RECEIPT_DATE) CASH_RECEIPT_DATE,
                       TRUNC(cash.GTMS_REGIS_TIME) GTMS_REGIS_TIME,
                       TRUNC(cash.gtms_sign_time) gtms_sign_time,
                       cash.RECEIPT_STATUS_ID RECEIPT_STATUS_ID,
                       cash.AMOUNT AMOUNT,
                       cash.ENTITY_ID ENTITY_ID,
                       cash.RECEIPT_STATUS_ID  STATUS_ID
                  from v_ar_cash_receipt_header_lines cash,
                       T_AR_RECEIPT_METHODS           methods
                 where methods.receipt_method_id = cash.RECEIPT_METHOD_ID(+)
                   and methods.receipt_method_name in
                       ('纸质三方承兑汇票', '纸质银行承兑汇票')
                   and cash.RECEIPT_STATUS_ID not in (1, 2,16)
                   and cash.WRITEOFF_RECEIPT_CODE is null
                   and TRUNC(cash.cash_receipt_date) <= TRUNC(P_REPORT_DATE)) H
         GROUP BY H.REPORT_DATE,
                  H.receipt_method_id,
                  H.receipt_method_name,
                  H.SALES_MAIN_TYPE_CODE,
                  H.SALES_MAIN_TYPE_NAME,
                  H.report_type,
                  H.ENTITY_ID;
      COMMIT;
    EXCEPTION
      WHEN OTHERS THEN
        V_ERR_MSG := SUBSTRB(SQLERRM, 1, 500);
        INSERT INTO T_PUB_ERROR_TRACE
          (ERROR_ID, TITLE_NAME, ERROR_MESS, CREATION_DATE)
        VALUES
          (S_PUB_ERROR_TRACE.NEXTVAL,
           UPPER('P_DAILY_RECEIPT_REPORT'),
           V_ERR_MSG,
           SYSDATE);
        COMMIT;
    END;

    INSERT INTO T_PUB_ERROR_TRACE

      (ERROR_ID, TITLE_NAME, ERROR_MESS, CREATION_DATE)
    VALUES
      (S_PUB_ERROR_TRACE.NEXTVAL,
       UPPER('P_DAILY_RECEIPT_REPORT'),
       '结束运行P_DAILY_RECEIPT_REPORT',
       SYSDATE);
    COMMIT;
  END;

END PKG_AR_RPT;
/

