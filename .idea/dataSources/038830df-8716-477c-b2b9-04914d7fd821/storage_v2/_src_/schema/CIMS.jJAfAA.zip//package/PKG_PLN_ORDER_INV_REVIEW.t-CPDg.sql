create Package      Pkg_Pln_Order_Inv_Review Is

  --------------------------------------------------------------------------------------------
  -- Author  : 李振
  -- Created : 2014-07-02 11:05:52
  -- Purpose : 计划订单管理 订单汇总功能处理过程
  --------------------------------------------------------------------------------------------

  --------------------------------------------------------------------------------------------
  -- Author  : 李振
  -- Created : 2014-07-02 11:05:52
  -- Purpose : 计划订单管理 订单汇总功能库存评审自动库存评审
  -- Return:  R_RESULT返回值： 0：无错误    -21000：程序错误中断处理
  --          R_ERR_MSG: SUCCESS:无错误     其它（信息）：程序错误信息说明
  --------------------------------------------------------------------------------------------
  Procedure p_Auto_Inv_Review(p_Collect_Head_Id In Number, --汇总订单头ID
                              p_Inv_Review_Type In Number, --库存评审类型：1：汇总库存评审 2：计划订单库存评审
                              p_Entity_Id       In Number, --主体ID
                              p_User_Code       In Varchar2, --用户ID
                              p_Result          Out Number, --错误返回值
                              p_Err_Msg         Out Varchar2); --错误信息

  --------------------------------------------------------------------------------------------
  -- Author  : 李振
  -- Created : 2014-07-02 11:05:52
  -- Purpose : 计划订单管理 订单汇总功能单行库存评审自动库存评审
  -- Return:  R_RESULT返回值： 0：无错误    -21000：程序错误中断处理
  --          R_ERR_MSG: SUCCESS:无错误     其它（信息）：程序错误信息说明
  --------------------------------------------------------------------------------------------
  Procedure p_Single_Auto_Inv_Review(p_Collect_Head_Id In Number, --汇总订单头ID
                                     p_Coolect_Line_Id In Number, --汇总订行头ID
                                     p_Inv_Review_Type In Number, --库存评审类型：1：汇总库存评审 2：计划订单库存评审
                                     p_Entity_Id       In Number, --主体ID
                                     p_User_Code       In Varchar2,
                                     p_Result          Out Number,
                                     p_Err_Msg         Out Varchar2); --错误信息

  --------------------------------------------------------------------------------------------
  -- Author  : 李振
  -- Created : 2014-07-08 11:05:52
  -- Purpose : 计划订单管理 计划订单库存评审库存锁定检查现有量
  -- Return:  R_RESULT返回值： 0：无错误    -21000：程序错误中断处理
  --          R_ERR_MSG: SUCCESS:无错误     其它（信息）：程序错误信息说明
  --------------------------------------------------------------------------------------------
  Procedure p_Item_Usable_Onhand_Check(p_Head_Id         In Number, --汇总订单头ID
                                       p_Line_Id         In Number, --汇总订行头ID
                                       p_Inv_Review_Type In Number, --库存评审类型：1：汇总库存评审 2：计划订单库存评审
                                       p_Entity_Id       In Number, --主体ID
                                       p_Result          Out Varchar2);

  --------------------------------------------------------------------------------------------
  -- Author  : 李振
  -- Created : 2014-07-08 11:05:52
  -- Purpose : 计划订单管理 计划订单库存评审库存锁定处理
  -- Return:  R_RESULT返回值： 0：无错误    -21000：程序错误中断处理
  --          R_ERR_MSG: SUCCESS:无错误     其它（信息）：程序错误信息说明
  --------------------------------------------------------------------------------------------
  Procedure p_Inv_Review_Lock(p_Head_Id         In Number, --汇总订单头ID
                              p_Line_Id         In Number, --汇总订行头ID
                              p_Inv_Review_Type In Number, --库存评审类型：1：汇总库存评审 2：计划订单库存评审
                              p_Entity_Id       In Number, --主体ID
                              p_User_Code       In Varchar2,
                              p_Result          Out Number,
                              p_Err_Msg         Out Varchar2); --错误信息

  --------------------------------------------------------------------------------------------
  -- Author  : 李振
  -- Created : 2017-02-08 11:05:52
  -- Purpose : 计划订单管理 计划订单库存评审库存锁定处理
  --           T+3计划订单删除提货订单行信息时，解锁订单的库存占用数量
  -- Return:  R_RESULT返回值： 0：无错误    -21000：程序错误中断处理
  --          R_ERR_MSG: SUCCESS:无错误     其它（信息）：程序错误信息说明
  --------------------------------------------------------------------------------------------
  Procedure p_Inv_Review_Del_UnLock(p_Head_Id         In Number, --汇总订单头ID
                                    p_Line_Id         In Number, --汇总订行头ID
                                    p_Inv_Review_Type In Number, --库存评审类型：1：汇总库存评审 2：计划订单库存评审
                                    p_Entity_Id       In Number, --主体ID
                                    p_User_Code       In Varchar2,
                                    p_Result          Out Number,
                                    p_Err_Msg         Out Varchar2);
End Pkg_Pln_Order_Inv_Review;
/

