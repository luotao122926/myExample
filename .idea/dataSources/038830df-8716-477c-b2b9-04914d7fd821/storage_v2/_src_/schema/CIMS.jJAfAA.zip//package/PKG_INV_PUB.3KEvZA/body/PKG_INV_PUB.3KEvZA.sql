create Package Body      Pkg_Inv_Pub Is

  v_Nl      Constant Varchar2(2) := Chr(13) || Chr(10); --换行
  v_Null    Constant Varchar2(4) := 'NULL'; --空值
  v_Success Constant Varchar2(10) := 'SUCCESS'; --成功返回
  v_Base_Exception Exception; --自定义异常
  
  Con_Center_Filter_Entity Constant Number := 32;--需要用中心来过滤的仓库列表的主体
  
  Con_Ipx_Ifcurrclose    Constant Number := 0; --关闭
  Con_Ipx_Ifcurropen     Constant Number := 1; --打开
  Con_Ipx_Ifcurrcheckout Constant Number := 2; --结账

  -----------------------------------------------------------------------------
  -- Author: NICRO.LI
  --Purpose: 取得库存周期                                                    --
  -----------------------------------------------------------------------------
  Function f_Get_Inv_Period(p_Entity_Id In Number, --主体ID
                            p_Date      In Date, --日期
                            p_Condition In Number --周期状态
                            ) Return Number Is
    Cursor c_Get_Inv_Period Is
      Select Period_Id
        From t_Inv_Inventory_Periods
       Where Entity_Id = p_Entity_Id
         And p_Date Between Begin_Date And End_Date
         And ((p_Condition = Con_Ipx_Ifcurropen And Status = '01' And
             Close_Date Is Null Or p_Condition != Con_Ipx_Ifcurropen) And
             (p_Condition = Con_Ipx_Ifcurrclose And Status = '00' And
             Close_Date Is Not Null Or p_Condition != Con_Ipx_Ifcurrclose));
    Recinv_Period c_Get_Inv_Period%Rowtype;
    v_Result      Number;
  Begin
    v_Result := -1;
    Open c_Get_Inv_Period;
    Fetch c_Get_Inv_Period
      Into Recinv_Period;
    If (c_Get_Inv_Period%Notfound) Then
      v_Result := -1;
    Else
      v_Result := Recinv_Period.Period_Id;
    End If;
    Close c_Get_Inv_Period;
    Return(v_Result);
  End;

  -----------------------------------------------------------------------------
  --  取得库存周期                                                           --
  --  库存周期四个日期BEGIN_DATE,END_DATE,STATUS, CLOSE_DATE之间的取值       --
  --  P_CONDITION：0：关闭   1：打开    2：结账
  -----------------------------------------------------------------------------
  Procedure p_Get_Inv_Period(p_Entity_Id     In Number, --主体ID
                             p_Date          In Date, --日期
                             p_Condition     In Number, --周期状态
                             p_Inv_Period_Id Out Number,
                             p_Result        Out Varchar2) Is
  Begin
    p_Result        := v_Success;
    p_Inv_Period_Id := -1;
    --查询指定日期的库存周期
    If (p_Result = v_Success) Then
      p_Inv_Period_Id := f_Get_Inv_Period(p_Entity_Id,
                                          Trunc(p_Date),
                                          p_Condition);
      If ((p_Condition = Con_Ipx_Ifcurrcheckout) And (p_Inv_Period_Id = -1)) Then
        p_Result := '获取库存周期失败，未找到结账周期。';
      Elsif ((p_Condition = Con_Ipx_Ifcurropen) And (p_Inv_Period_Id = -1)) Then
        p_Result := '获取库存周期失败，未找已打开的周期。';
      Elsif ((p_Condition = Con_Ipx_Ifcurrclose) And (p_Inv_Period_Id = -1)) Then
        p_Result := '获取库存周期失败，未找到已关闭的周期。';
      End If;
    End If;
    If (p_Result != v_Success) Then
      p_Inv_Period_Id := -1;
    End If;
  Exception
    When Others Then
      p_Result := '获取库存周期失败，未知错误！' || v_Nl || Sqlerrm;
  End;

  --------------------------------------------------------------------------
  --Anthor: Nicro.Li
  --Purpose:获取某产品指定仓库的库存情况
  --参数说明：p_get_qoh_type
  --  1：库存在手量
  --  2：库存可用量
  --  3：库存占用量
  --------------------------------------------------------------------------
  Function f_Get_Item_Inv_Qoh(p_Entity_Id         In Number, --主体ID
                              p_Inventory_Id      In Number, --指定仓库
                              p_Item_Id           In Number, --指定产品
                              p_User_Code         In Varchar2, --用户ID
                              p_Get_Qoh_Type      In Number, --参数说明：1: 库存在手量   2：库存可用量  3：库存占用量 4:非中转采购未执行 5:中转入库红冲未执行
                              p_Count_Occoup_Flag In Varchar2 Default v_True --可用量是否计算库存占用，Y：计算，N：不计算
                              ) Return Number Is

    --套件打散
    Cursor c_Qty_Onhand Is
      Select Nvl(Sum(Qoh_Qty), 0) Qoh_Qty,
             Nvl(Sum(Inv_Qoh_Qth), 0) Inv_Qoh_Qth,  --非工单入库（采购出库未执行）
             Nvl(Sum(Usable_Qoh_Qty), 0) Usable_Qoh_Qty,
             Nvl(Sum(Occupyqty_Qty), 0) Occupy_Qty,
             Nvl(Sum(Read_Po_Wip_Qty), 0)  Read_Po_Wip_Qty
        From (Select Sum(Nvl(Qoh1, 0)) Qoh_Qty,
                     Sum(Nvl(Qoh2, 0)) Inv_Qoh_Qth, --非工单入库（采购出库未执行）
                     Sum(Nvl(Qoh1, 0) - Nvl(Qoh2, 0) - Nvl(Occupyqty, 0) - Nvl(NoLOck_Read_Po_Wip_Qty, 0)) Usable_Qoh_Qty,
                     Sum(Occupyqty) Occupyqty_Qty,
                     Sum(Read_Po_Wip_Qty) Read_Po_Wip_Qty
                From (Select Tio.Item_Id,
                             Sum(Tio.Quantity) Qoh1,
                             0 Qoh2,
                             0 Occupyqty,
                             0 NoLOck_Read_Po_Wip_Qty, --add by lizhen 2015-09-12
                             0 Read_Po_Wip_Qty
                        From t_Inv_Onhand Tio
                       Where Tio.Item_Id = p_Item_Id
                         And Tio.Inventory_Id = p_Inventory_Id
                         And Tio.Entity_Id = p_Entity_Id
                       Group By Tio.Item_Id
                       Union All
                      Select l.Item_Id,
                             0 Qoh1,
                             Sum(BILLED_QTY) Qoh2,
                             0 Occupyqty,
                             0 NoLOck_Read_Po_Wip_Qty, 
                             0 Read_Po_Wip_Qty
                        From cims.t_inv_check_orders      o,
                             cims.t_inv_check_order_lines l,
                             cims.t_Inv_Bill_Types        t,
                             cims.t_Inv_Inventories       i,
                             cims.t_Inv_Transaction_Types Itt
                       Where t.Bill_Type_Id = o.check_order_type_id
                         And t.Entity_Id = o.Entity_Id
                         And l.check_order_id = o.check_order_id
                         And i.Inventory_Id = o.inv_id
                         And i.Entity_Id = o.Entity_Id
                         And o.doc_date >= Sysdate - 30
                         And o.po_status = '11' --制单审核
                         --and o.process_status is not null
                         And Nvl(o.Close_Flag, 'N') != 'Y'
                         And o.Entity_Id = p_Entity_Id
                         And i.Inventory_Id = p_Inventory_Id
                         And l.Item_Id = p_Item_Id
                         And t.Transaction_Type_Id = Itt.Transaction_Type_Id
                         And Itt.Action_Type = '02'
                       Group By l.Item_Id
                       union all
                       Select l.Item_Id,
                             0 Qoh1,
                             Sum(BILLED_QTY) Qoh2,
                             0 Occupyqty,
                             0 NoLOck_Read_Po_Wip_Qty, --add by lizhen 2015-09-12
                             0 Read_Po_Wip_Qty
                        From cims.t_inv_trsf_order      o,
                             cims.t_inv_trsf_order_line_detail l,
                             cims.t_Inv_Inventories       i
                       Where 1=1
                         And l.trsf_order_id = o.trsf_order_id
                         And i.Inventory_Id = o.ship_inv_id
                         And i.Entity_Id = o.Entity_Id
                         And o.billed_date >= Sysdate - 30
                         And o.trsf_order_status = '11' --制单审核
                         --and o.process_status is not null
                         And Nvl(o.Close_Flag, 'N') != 'Y'
                         And o.Entity_Id = p_Entity_Id
                         And i.Inventory_Id = p_Inventory_Id
                         And l.Item_Id = p_Item_Id
                         and o.bill_type = '1055'
                       Group By l.Item_Id
                      Union All
                      Select l.Item_Id,
                             0 Qoh1,
                             Sum(Decode(o.Po_Status,
                                        10,
                                        Nvl(l.Billed_Qty, 0),
                                        Nvl(l.Shipped_Qty, 0))) Qoh2,
                             0 Occupyqty,
                             0 NoLOck_Read_Po_Wip_Qty, --add by lizhen 2015-09-12
                             0 Read_Po_Wip_Qty
                        From t_Inv_Po_Headers  o,
                             t_Inv_Po_Lines    l,
                             t_Inv_Bill_Types  t,
                             t_Inv_Inventories i,
                             t_Inv_Bill_Types        Ibt,
                             t_Inv_Transaction_Types Itt
                       Where t.Bill_Type_Id = o.Po_Type_Id
                         And t.Entity_Id = o.Entity_Id
                         And l.Po_Id = o.Po_Id
                         And Nvl(o.Source_Type, '_') != '工单入库'  --add by lizhen 2015-03-24
                         And i.Inventory_Id = o.Inv_Finance_Id
                         And i.Entity_Id = o.Entity_Id
                         And o.Billed_Date >= Sysdate - 30
                         And o.Po_Status <> '14' --执行
                         And Nvl(o.Close_Flag, 'N') != 'Y' --add by lizhen 2015-03-26
                         And o.Entity_Id = p_Entity_Id
                         And i.Inventory_Id = p_Inventory_Id
                         And l.Item_Id = p_Item_Id
                         --采购单红冲出库的单据才纳入现有量计算
                         And Ibt.Transaction_Type_Id = Itt.Transaction_Type_Id
                         And Itt.Action_Type = '02'
                         And Ibt.Bill_Type_Id = o.Po_Type_Id
                       Group By l.Item_Id
                      Union All
                      Select Oio.Item_Id,
                             0 Qoh1,
                             0 Qoh2,
                             Sum(Nvl(Oio.Stock_Affirm_Qty, 0) +
                                 Nvl(Oio.Supply_Qty, 0) -
                                 Nvl(Oio.So_Order_Qty, 0) -
                                 Nvl(Oio.Sundry_Qty, 0)) Occupyqty,
                             0 NoLOck_Read_Po_Wip_Qty, --add by lizhen 2015-09-12
                             0 Read_Po_Wip_Qty
                        From t_Pln_Order_Inv_Occupy Oio
                       Where Oio.Inventory_Id = p_Inventory_Id
                         And Oio.Entity_Id = p_Entity_Id
                         And Oio.Item_Id = p_Item_Id
                         And 'Y' = p_Count_Occoup_Flag --是否计
                       Group By Oio.Item_Id
                   Union All  --增加新锁定 2019-02-23 guibr
                      Select Oio.Item_Id,
                             0 Qoh1,
                             0 Qoh2,
                             Sum(Nvl(Oio.QUANTITY, 0)) Occupyqty,
                             0 NoLOck_Read_Po_Wip_Qty, --add by lizhen 2015-09-12
                             0 Read_Po_Wip_Qty
                        From T_INV_LOCKIN Oio
                       Where Oio.Inventory_Id = p_Inventory_Id
                         And Oio.Entity_Id = p_Entity_Id
                         And Oio.Item_Id = p_Item_Id
                         AND Oio.LOCK_LEVEL=0
                       Group By Oio.Item_Id           
                      Union All
                      Select l.Item_Id,
                             0 Qoh1,
                             0 Qoh2,
                             0 Occupyqty,
                             --add by lizhen 2015-09-12 中转工单入库但不锁库存的红冲数量
                             Decode(p_Get_Qoh_Type, 
                               2, 
                               Nvl(sum(Nvl(pld.shipped_qty, 0)), 0),
                               0) NoLOck_Read_Po_Wip_Qty,
                             Decode(p_Get_Qoh_Type, 
                               3, 
                               Nvl(sum(Nvl(pld.shipped_qty, 0)), 0),
                               5, 
                               Nvl(sum(Nvl(pld.shipped_qty, 0)), 0),
                               0) Read_Po_Wip_Qty
                             /*Sum(Decode(o.Po_Status,
                                        10,
                                        Nvl(l.Billed_Qty, 0),
                                        Nvl(l.Shipped_Qty, 0))) Read_Po_Wip_Qty*/
                        From t_Inv_Po_Headers  o,
                             t_Inv_Po_Lines    l,
                             t_Inv_Bill_Types  t,
                             t_Inv_Inventories i,
                             t_Inv_Bill_Types        Ibt,
                             t_Inv_Transaction_Types Itt,
                             t_inv_po_lines_detail   Pld,
                             t_pln_order_head        Poh,
                             t_pln_order_type        Ot
                       Where t.Bill_Type_Id = o.Po_Type_Id
                         And t.Entity_Id = o.Entity_Id
                         And l.Po_Id = o.Po_Id
                         And Nvl(o.Source_Type, '_') = '工单入库' --modi by lizhen 2015-03-24
                         And i.Inventory_Id = o.Inv_Finance_Id
                         And i.Entity_Id = o.Entity_Id
                         And Nvl(o.Close_Flag, 'N') != 'Y' --add by lizhen 2015-03-26
                         And o.Billed_Date >= Sysdate - 60
                         And o.Po_Status = '21' --已发货确认
                         And o.Entity_Id = p_Entity_Id
                         And i.Inventory_Id = p_Inventory_Id
                         And l.Item_Id = p_Item_Id
                         --采购单红冲出库的单据才纳入现有量计算
                         And (((p_Get_Qoh_Type = 3 Or p_Get_Qoh_Type = 5)  --add by lizhen 2015-06-02 提高运算效率
                           And Nvl(Ot.Is_Lock_Inv_Flag, 'N') = 'Y') Or 
                           (p_Get_Qoh_Type = 2 And Nvl(Ot.Is_Lock_Inv_Flag, 'N')= 'N')) 
                         And Ibt.Transaction_Type_Id = Itt.Transaction_Type_Id
                         And Itt.Action_Type = '02'
                         And Ibt.Bill_Type_Id = o.Po_Type_Id
                         And Ibt.Entity_Id = o.Entity_Id
                         And Pld.Po_Head_Id = o.Po_Id
                         And Pld.Po_Line_Id = l.Po_Line_Id
                         And Poh.Order_Head_Id = Pld.Order_Header_Id
                         And Poh.Order_Type_Id = Ot.Order_Type_Id
                       Group By l.Item_Id)
              Union All
              Select Min(Qoh_Qty) Qoh_Qty,
                     Max(Inv_Qoh_Qth) Inv_Qoh_Qth, --modi by lizhen 2015-06-02
                     --Min(Inv_Qoh_Qth) Inv_Qoh_Qth,
                     Min(Usable_Qoh_Qty) Usable_Qoh_Qty,
                     Min(Occupyqty_Qty),
                     Max(Read_Po_Wip_Qty) Read_Po_Wip_Qty
                From (Select Item_Id,
                             Sum(Nvl(Qoh1, 0)) Qoh_Qty,
                             Sum(nvl(Qoh2, 0)) Inv_Qoh_Qth,--非工单入库（采购出库未执行）
                             Sum(Nvl(Qoh1, 0) - Nvl(Qoh2, 0) - Nvl(Occupyqty, 0) - Nvl(NoLOck_Read_Po_Wip_Qty, 0)) Usable_Qoh_Qty,
                             Sum(Nvl(Occupyqty, 0)) Occupyqty_Qty,
                             Sum(Nvl(Read_Po_Wip_Qty, 0)) Read_Po_Wip_Qty
                        From (
                              --保证套件库存准备，增加
                              Select Bias.Item_Id, 0 Qoh1, 0 Qoh2, 0 Occupyqty,
                                0 NoLOck_Read_Po_Wip_Qty, --add by lizhen 2015-09-12
                                0 Read_Po_Wip_Qty
                                From t_Bd_Item_Assemblies     Tbia,
                                      t_Bd_Item_Assemblies_Sub Bias
                               Where Tbia.Item_Id = p_Item_Id
                                 And Tbia.Entity_Id = p_Entity_Id
                                 And Bias.Item_Assembly_Id =
                                     Tbia.Item_Assembly_Id
                                 --And Nvl(Bias.Fittings_Flag, 'N') = 'N'
                                 And Trunc(Sysdate) Between Tbia.Begin_Date And
                                     Trunc(Nvl(Tbia.End_Date, Sysdate))
                                 And Trunc(Sysdate) Between Bias.Begin_Date And
                                     Trunc(Nvl(Bias.End_Date, Sysdate))
                               Group By Bias.Item_Id, Nvl(Bias.Quantity, 1)
                              Union All
                              Select Bias.Item_Id,
                                      Trunc(Sum(Nvl(Tio.Quantity, 0)) /
                                            Nvl(Bias.Quantity, 1)) Qoh1,
                                      0 Qoh2,
                                      0 Occupyqty,
                                      0 NoLOck_Read_Po_Wip_Qty, --add by lizhen 2015-09-12
                                      0 Read_Po_Wip_Qty
                                From t_Inv_Onhand             Tio,
                                      t_Bd_Item_Assemblies     Tbia,
                                      t_Bd_Item_Assemblies_Sub Bias
                               Where Tbia.Item_Id = p_Item_Id
                                 And Tbia.Entity_Id = p_Entity_Id
                                 And Bias.Item_Assembly_Id =
                                     Tbia.Item_Assembly_Id
                                 --And Nvl(Bias.Fittings_Flag, 'N') = 'N'
                                 And Trunc(Sysdate) Between Tbia.Begin_Date And
                                     Trunc(Nvl(Tbia.End_Date, Sysdate))
                                 And Trunc(Sysdate) Between Bias.Begin_Date And
                                     Trunc(Nvl(Bias.End_Date, Sysdate))
                                 And Tio.Item_Id(+) = Bias.Item_Id
                                 And Tio.Inventory_Id(+) = p_Inventory_Id
                                 And Tio.Entity_Id(+) = p_Entity_Id
                               Group By Bias.Item_Id, Nvl(Bias.Quantity, 1)
                                Union All
                                Select Bias.Item_Id,
                                       0 Qoh1,
                                       Trunc(Sum(Nvl(l.BILLED_QTY, 0)) /
                                            Nvl(Bias.Quantity, 1)) Qoh2,
                                       0 Occupyqty,
                                       0 NoLOck_Read_Po_Wip_Qty, 
                                       0 Read_Po_Wip_Qty
                                  From cims.t_inv_check_orders      o,
                                       cims.t_inv_check_order_lines l,
                                       cims.t_Inv_Bill_Types        t,
                                       cims.t_Inv_Inventories       i,
                                       cims.t_Inv_Transaction_Types Itt,
                                       cims.t_Bd_Item_Assemblies     Tbia,
                                       cims.t_Bd_Item_Assemblies_Sub Bias
                                 Where 1=1 
                                   and Tbia.Item_Id = p_Item_Id
                                   And Tbia.Entity_Id = p_Entity_Id
                                   And Bias.Item_Assembly_Id =
                                       Tbia.Item_Assembly_Id
                                   And Trunc(Sysdate) Between Tbia.Begin_Date And
                                       Trunc(Nvl(Tbia.End_Date, Sysdate))
                                   And Trunc(Sysdate) Between Bias.Begin_Date And
                                       Trunc(Nvl(Bias.End_Date, Sysdate))
                                   And l.Item_Id(+) = Bias.Item_Id
                                   and t.Bill_Type_Id = o.check_order_type_id
                                   And t.Entity_Id = o.Entity_Id
                                   And l.check_order_id = o.check_order_id
                                   And i.Inventory_Id = o.inv_id
                                   And i.Entity_Id = o.Entity_Id
                                   And o.doc_date >= Sysdate - 30
                                   And o.po_status = '11' --制单审核
                                   --and o.process_status is not null
                                   And Nvl(o.Close_Flag, 'N') != 'Y'
                                   And o.Entity_Id = p_Entity_Id
                                   And i.Inventory_Id = p_Inventory_Id
                                   And l.Item_Id = p_Item_Id
                                   And t.Transaction_Type_Id = Itt.Transaction_Type_Id
                                   And Itt.Action_Type = '02'
                                 Group By Bias.Item_Id, Nvl(Bias.Quantity, 1)
                                 union all
                                 Select Bias.Item_Id,
                                       0 Qoh1,
                                       Trunc(Sum(Nvl(l.BILLED_QTY, 0)) /
                                            Nvl(Bias.Quantity, 1)) Qoh2,
                                       0 Occupyqty,
                                       0 NoLOck_Read_Po_Wip_Qty, --add by lizhen 2015-09-12
                                       0 Read_Po_Wip_Qty
                                  From cims.t_inv_trsf_order      o,
                                       cims.t_inv_trsf_order_line_detail l,
                                       cims.t_Inv_Inventories       i,
                                       cims.t_Bd_Item_Assemblies     Tbia,
                                       cims.t_Bd_Item_Assemblies_Sub Bias
                                 Where 1=1
                                   and Tbia.Item_Id = p_Item_Id
                                   And Tbia.Entity_Id = p_Entity_Id
                                   And Bias.Item_Assembly_Id =
                                       Tbia.Item_Assembly_Id
                                   And Trunc(Sysdate) Between Tbia.Begin_Date And
                                       Trunc(Nvl(Tbia.End_Date, Sysdate))
                                   And Trunc(Sysdate) Between Bias.Begin_Date And
                                       Trunc(Nvl(Bias.End_Date, Sysdate))
                                   And l.Item_Id(+) = Bias.Item_Id
                                   And l.trsf_order_id = o.trsf_order_id
                                   And i.Inventory_Id = o.ship_inv_id
                                   And i.Entity_Id = o.Entity_Id
                                   And o.billed_date >= Sysdate - 30
                                   And o.trsf_order_status = '11' --制单审核
                                   --and o.process_status is not null
                                   And Nvl(o.Close_Flag, 'N') != 'Y'
                                   And o.Entity_Id = p_Entity_Id
                                   And i.Inventory_Id = p_Inventory_Id
                                   And l.Item_Id = p_Item_Id
                                   and o.bill_type = '1055'
                                 Group By Bias.Item_Id, Nvl(Bias.Quantity, 1)
                              Union All
                              Select Bias.Item_Id,
                                      0 Qoh1,
                                      Trunc(Sum(Decode(o.Po_Status,
                                                       10,
                                                       Nvl(l.Billed_Qty, 0),
                                                       Nvl(l.Shipped_Qty, 0))) /
                                            Nvl(Bias.Quantity, 1)) Qoh2,
                                      0 Occupyqty,
                                      0 NoLOck_Read_Po_Wip_Qty, --add by lizhen 2015-09-12
                                      0 Read_Po_Wip_Qty
                                From t_Inv_Po_Headers         o,
                                      t_Inv_Po_Lines           l,
                                      t_Inv_Bill_Types         t,
                                      t_Inv_Inventories        i,
                                      t_Bd_Item_Assemblies     Tbia,
                                      t_Bd_Item_Assemblies_Sub Bias,
                                      t_Inv_Bill_Types        Ibt,
                                      t_Inv_Transaction_Types Itt
                               Where Tbia.Item_Id = p_Item_Id
                                 And Tbia.Entity_Id = p_Entity_Id
                                 And Bias.Item_Assembly_Id =
                                     Tbia.Item_Assembly_Id
                                 --And Nvl(Bias.Fittings_Flag, 'N') = 'N'
                                 And Trunc(Sysdate) Between Tbia.Begin_Date And
                                     Trunc(Nvl(Tbia.End_Date, Sysdate))
                                 And Trunc(Sysdate) Between Bias.Begin_Date And
                                     Trunc(Nvl(Bias.End_Date, Sysdate))
                                 And t.Bill_Type_Id = o.Po_Type_Id
                                 And t.Entity_Id = o.Entity_Id
                                 And l.Po_Id = o.Po_Id
                                 And Nvl(o.Source_Type, '_') != '工单入库' --modi by lizhen 2015-03-24
                                 And Nvl(o.Close_Flag, 'N') != 'Y' --add by lizhen 2015-03-26
                                 And i.Inventory_Id = o.Inv_Finance_Id
                                 And i.Entity_Id = o.Entity_Id
                                 And o.Billed_Date >= Sysdate - 30
                                 And o.Po_Status <> '14' --执行
                                 And o.Entity_Id = p_Entity_Id
                                 And i.Inventory_Id = p_Inventory_Id
                                 And l.Item_Id = Bias.Item_Id
                                 --采购单红冲出库的单据才纳入现有量计算
                                 And Ibt.Transaction_Type_Id = Itt.Transaction_Type_Id
                                 And Itt.Action_Type = '02'
                                 And Ibt.Bill_Type_Id = o.Po_Type_Id
                               Group By Bias.Item_Id, Nvl(Bias.Quantity, 1)
                              Union All
                              Select Bias.Item_Id,
                                      0 Qoh1,
                                      0 Qoh2,
                                      Trunc(Sum(Nvl(Oio.Stock_Affirm_Qty, 0) +
                                                Nvl(Oio.Supply_Qty, 0) -
                                                Nvl(Oio.So_Order_Qty, 0) -
                                                Nvl(Oio.Sundry_Qty, 0)) /
                                            Nvl(Bias.Quantity, 1)) Occupyqty,
                                     0 NoLOck_Read_Po_Wip_Qty, --add by lizhen 2015-09-12
                                     0 Read_Po_Wip_Qty
                                From t_Pln_Order_Inv_Occupy   Oio,
                                      t_Bd_Item_Assemblies     Tbia,
                                      t_Bd_Item_Assemblies_Sub Bias
                               Where Tbia.Item_Id = p_Item_Id
                                 And Tbia.Entity_Id = p_Entity_Id
                                 And Oio.Inventory_Id = p_Inventory_Id
                                 And Bias.Item_Id = Oio.Item_Id
                                 And Bias.Entity_Id = Oio.Entity_Id
                                 And Tbia.Entity_Id = Oio.Entity_Id
                                 And Bias.Item_Assembly_Id =
                                     Tbia.Item_Assembly_Id
                                 --And Nvl(Bias.Fittings_Flag, 'N') = 'N'
                                 And Trunc(Sysdate) Between Tbia.Begin_Date And
                                     Trunc(Nvl(Tbia.End_Date, Sysdate))
                                 And Trunc(Sysdate) Between Bias.Begin_Date And
                                     Trunc(Nvl(Bias.End_Date, Sysdate))
                                 And 'Y' = p_Count_Occoup_Flag --是否计
                               Group By Bias.Item_Id, Nvl(Bias.Quantity, 1)
                              --网批锁定
                              Union All
                              Select Bias.Item_Id,
                                      0 Qoh1,
                                      0 Qoh2,
                                      Trunc(Sum(Nvl(IL.QUANTITY, 0)) /
                                            Nvl(Bias.Quantity, 1)) Occupyqty,
                                     0 NoLOck_Read_Po_Wip_Qty, --add by lizhen 2015-09-12
                                     0 Read_Po_Wip_Qty
                                From T_INV_LOCKIN   IL,
                                      t_Bd_Item_Assemblies     Tbia,
                                      t_Bd_Item_Assemblies_Sub Bias
                               Where Tbia.Item_Id = p_Item_Id
                                 And Tbia.Entity_Id = p_Entity_Id
                                 And IL.Inventory_Id = p_Inventory_Id
                                 And Bias.Item_Id = IL.Item_Id
                                 And Bias.Entity_Id = IL.Entity_Id
                                 And Tbia.Entity_Id = IL.Entity_Id
                                 And Bias.Item_Assembly_Id = Tbia.Item_Assembly_Id
                                 --And Nvl(Bias.Fittings_Flag, 'N') = 'N'
                                 And Trunc(Sysdate) Between Tbia.Begin_Date And
                                     Trunc(Nvl(Tbia.End_Date, Sysdate))
                                 And Trunc(Sysdate) Between Bias.Begin_Date And
                                     Trunc(Nvl(Bias.End_Date, Sysdate))
                                 And 'Y' = p_Count_Occoup_Flag --是否计
                               Group By Bias.Item_Id, Nvl(Bias.Quantity, 1)
                              Union All
                              Select Bias.Item_Id,
                                      0 Qoh1,
                                      0 Qoh2,
                                      0 Occupyqty,
                                      --add by lizhen 2015-09-12 中转工单入库但不锁库存的红冲数量
                                      Decode(p_Get_Qoh_Type, 
                                        2, 
                                        Nvl(sum(Nvl(pld.shipped_qty, 0)), 0),
                                        0) NoLOck_Read_Po_Wip_Qty,
                                      Decode(p_Get_Qoh_Type, 
                                        3, 
                                        Nvl(sum(Nvl(pld.shipped_qty, 0)), 0),
                                        5, 
                                        Nvl(sum(Nvl(pld.shipped_qty, 0)), 0),
                                        0) Read_Po_Wip_Qty
                                      /*Trunc(Sum(Decode(o.Po_Status,
                                                       10,
                                                       Nvl(l.Billed_Qty, 0),
                                                       Nvl(l.Shipped_Qty, 0))) /
                                            Nvl(Bias.Quantity, 1)) Read_Po_Wip_Qty*/
                                From t_Inv_Po_Headers         o,
                                      t_Inv_Po_Lines           l,
                                      t_Inv_Bill_Types         t,
                                      t_Inv_Inventories        i,
                                      t_Bd_Item_Assemblies     Tbia,
                                      t_Bd_Item_Assemblies_Sub Bias,
                                      t_Inv_Bill_Types        Ibt,
                                      t_Inv_Transaction_Types Itt,
                                      t_inv_po_lines_detail   Pld,
                                      t_pln_order_head        Poh,
                                      t_pln_order_type        Ot
                               Where Tbia.Item_Id = p_Item_Id
                                 And Tbia.Entity_Id = p_Entity_Id
                                 And Bias.Item_Assembly_Id =
                                     Tbia.Item_Assembly_Id
                                 --And Nvl(Bias.Fittings_Flag, 'N') = 'N'
                                 And Trunc(Sysdate) Between Tbia.Begin_Date And
                                     Trunc(Nvl(Tbia.End_Date, Sysdate))
                                 And Trunc(Sysdate) Between Bias.Begin_Date And
                                     Trunc(Nvl(Bias.End_Date, Sysdate))
                                 And t.Bill_Type_Id = o.Po_Type_Id
                                 And t.Entity_Id = o.Entity_Id
                                 And l.Po_Id = o.Po_Id
                                 And Nvl(o.Source_Type, '_') = '工单入库' --modi by lizhen 2015-03-24
                                 And Nvl(o.Close_Flag, 'N') != 'Y' --add by lizhen 2015-03-26
                                 And i.Inventory_Id = o.Inv_Finance_Id
                                 And i.Entity_Id = o.Entity_Id
                                 And o.Billed_Date >= Sysdate - 30
                                 And o.Po_Status = '21' --已发货确认
                                 And o.Entity_Id = p_Entity_Id
                                 And i.Inventory_Id = p_Inventory_Id                                 
                                 And (((p_Get_Qoh_Type = 3 Or p_Get_Qoh_Type = 5)  --add by lizhen 2015-06-02 提高运算效率
                                  And Nvl(Ot.Is_Lock_Inv_Flag, 'N') = 'Y') Or 
                                  (p_Get_Qoh_Type = 2 And Nvl(Ot.Is_Lock_Inv_Flag, 'N')= 'N')) 
                                 And l.Item_Id = Bias.Item_Id
                                 --采购单红冲出库的单据才纳入现有量计算
                                 And Ibt.Transaction_Type_Id = Itt.Transaction_Type_Id
                                 And Itt.Action_Type = '02'
                                 And Ibt.Bill_Type_Id = o.Po_Type_Id
                                 And Ibt.Entity_Id = o.Entity_Id
                                 And Pld.Po_Head_Id = o.Po_Id
                                 And Pld.Po_Line_Id = l.Po_Line_Id
                                 And Poh.Order_Head_Id = Pld.Order_Header_Id
                                 And Poh.Order_Type_Id = Ot.Order_Type_Id
                               Group By Bias.Item_Id, Nvl(Bias.Quantity, 1))
                       Group By Item_Id)
              );

    r_Qty_Onhand c_Qty_Onhand%Rowtype;

    v_Result Number;
  Begin
    v_Result := 0;

    Open c_Qty_Onhand;
    Fetch c_Qty_Onhand
      Into r_Qty_Onhand;
    If (c_Qty_Onhand%Notfound) Then
      v_Result := 0;
    Else
      --1: 库存在手量   2：库存可用量  3：库存占用量  4:采购中转红冲未执行数量
      If p_Get_Qoh_Type = 1 Then
        v_Result := Nvl(r_Qty_Onhand.Qoh_Qty, 0);
      Elsif p_Get_Qoh_Type = 2 Then
        v_Result := Nvl(r_Qty_Onhand.Usable_Qoh_Qty, 0);
      Elsif p_Get_Qoh_Type = 3 Then
        v_Result := Nvl(r_Qty_Onhand.Occupy_Qty, 0) - Nvl(r_Qty_Onhand.Read_Po_Wip_Qty, 0);
      Elsif p_Get_Qoh_Type = 4 Then
        v_Result := Nvl(r_Qty_Onhand.Inv_Qoh_Qth, 0);
      Elsif p_Get_Qoh_Type = 5 Then
        v_Result := Nvl(r_Qty_Onhand.Read_Po_Wip_Qty, 0);
      Else
        v_Result := 0;
      End If;
    End If;
    Close c_Qty_Onhand;
    Return v_Result;
  Exception
    When Others Then
      dbms_output.put_line('error:' || Sqlerrm);
      Return Null;
  End;

  --------------------------------------------------------------------------
  --Anthor: Nicro.Li
  --Purpose:获取某产品指定仓库的 库存在手量：p_Qoh_Qty
  --                             库存可用量：p_Usable_Qoh_Qty
  --                             库存占用量：p_Occupy_Qty
  -- modi by lizhen 2015-03-09 增加中转入库红冲单未执行数据处理，
  --2015-03-09  计算库存可用量时，未执红冲单据扣减库存现有量
  --------------------------------------------------------------------------
  Procedure p_Get_Item_Inv_Qoh(p_Entity_Id         In Number, --主体ID
                               p_Inventory_Id      In Number, --指定仓库
                               p_Item_Id           In Number, --指定产品
                               p_User_Code         In Varchar2, --用户ID
                               p_Qoh_Qty           Out Number, --返回的库存在手量，出错返回NULL
                               p_Usable_Qoh_Qty    Out Number, --返回库存可用量，出错返回NULL
                               p_Occupy_Qty        Out Number, --返回库存占用量，出错返回NULL
                               p_Result            Out Varchar2, --返回值
                               p_Count_Occoup_Flag In Varchar2 Default 'Y' --可用量是否计算库存占用，Y：计算，N：不计算
                               ) Is

    --套件打散
    Cursor c_Qty_Onhand Is
      Select Nvl(Sum(Qoh_Qty), 0) Qoh_Qty,
             Nvl(Sum(Usable_Qoh_Qty), 0) Usable_Qoh_Qty,
             Nvl(Sum(Occupyqty_Qty), 0) Occupy_Qty,
             Nvl(Sum(Read_Po_Wip_Qty), 0) Read_Po_Wip_Qty  --add by lizhen 2015-03-09
        From (Select Sum(Qoh1) Qoh_Qty,
                     Sum(Qoh1 - Qoh2 - Occupyqty - Nvl(NoLOck_Read_Po_Wip_Qty, 0)) Usable_Qoh_Qty,
                     Sum(Occupyqty) Occupyqty_Qty,
                     Sum(Read_Po_Wip_Qty) Read_Po_Wip_Qty
                From (Select Tio.Item_Id,
                             Sum(Tio.Quantity) Qoh1,
                             0 Qoh2,
                             0 Occupyqty,
                             0 NoLOck_Read_Po_Wip_Qty, --add by lizhen 2015-09-12
                             0 Read_Po_Wip_Qty  --add by lizhen 2015-03-09
                        From t_Inv_Onhand Tio
                       Where Tio.Item_Id = p_Item_Id
                         And Tio.Inventory_Id = p_Inventory_Id
                         And Tio.Entity_Id = p_Entity_Id
                       Group By Tio.Item_Id
                       Union All
                      Select l.Item_Id,
                             0 Qoh1,
                             Sum(BILLED_QTY) Qoh2,
                             0 Occupyqty,
                             0 NoLOck_Read_Po_Wip_Qty, 
                             0 Read_Po_Wip_Qty
                        From cims.t_inv_check_orders      o,
                             cims.t_inv_check_order_lines l,
                             cims.t_Inv_Bill_Types        t,
                             cims.t_Inv_Inventories       i,
                             cims.t_Inv_Transaction_Types Itt
                       Where t.Bill_Type_Id = o.check_order_type_id
                         And t.Entity_Id = o.Entity_Id
                         And l.check_order_id = o.check_order_id
                         And i.Inventory_Id = o.inv_id
                         And i.Entity_Id = o.Entity_Id
                         And o.doc_date >= Sysdate - 30
                         And o.po_status = '11' --制单审核
                         --and o.process_status is not null
                         And Nvl(o.Close_Flag, 'N') != 'Y'
                         And o.Entity_Id = p_Entity_Id
                         And i.Inventory_Id = p_Inventory_Id
                         And l.Item_Id = p_Item_Id
                         And t.Transaction_Type_Id = Itt.Transaction_Type_Id
                         And Itt.Action_Type = '02'
                       Group By l.Item_Id
                       union all
                       Select l.Item_Id,
                             0 Qoh1,
                             Sum(BILLED_QTY) Qoh2,
                             0 Occupyqty,
                             0 NoLOck_Read_Po_Wip_Qty, --add by lizhen 2015-09-12
                             0 Read_Po_Wip_Qty
                        From cims.t_inv_trsf_order      o,
                             cims.t_inv_trsf_order_line_detail l,
                             cims.t_Inv_Inventories       i
                       Where 1=1
                         And l.trsf_order_id = o.trsf_order_id
                         And i.Inventory_Id = o.ship_inv_id
                         And i.Entity_Id = o.Entity_Id
                         And o.billed_date >= Sysdate - 30
                         And o.trsf_order_status = '11' --制单审核
                         --and o.process_status is not null
                         And Nvl(o.Close_Flag, 'N') != 'Y'
                         And o.Entity_Id = p_Entity_Id
                         And i.Inventory_Id = p_Inventory_Id
                         And l.Item_Id = p_Item_Id
                         and o.bill_type = '1055'
                       Group By l.Item_Id
                      Union All
                      Select l.Item_Id,
                             0 Qoh1,
                             Sum(Decode(o.Po_Status,
                                        10,
                                        Nvl(l.Billed_Qty, 0),
                                        Nvl(l.Shipped_Qty, 0))) Qoh2,
                             0 Occupyqty,
                             0 NoLOck_Read_Po_Wip_Qty, --add by lizhen 2015-09-12
                             0 Read_Po_Wip_Qty  --add by lizhen 2015-03-09
                        From t_Inv_Po_Headers  o,
                             t_Inv_Po_Lines    l,
                             t_Inv_Bill_Types  t,
                             t_Inv_Inventories i,
                             t_Inv_Bill_Types        Ibt,
                             t_Inv_Transaction_Types Itt
                       Where t.Bill_Type_Id = o.Po_Type_Id
                         And t.Entity_Id = o.Entity_Id
                         And l.Po_Id = o.Po_Id
                         And i.Inventory_Id = o.Inv_Finance_Id
                         And i.Entity_Id = o.Entity_Id
                         And o.Billed_Date >= Sysdate - 30
                         And Nvl(o.Source_Type, '_') != '工单入库' --modi by lizhen 2015-03-24
                         And Nvl(o.Close_Flag, 'N') != 'Y' --add by lizhen 2015-03-26
                         And o.Po_Status <> '14' --执行
                         And o.Entity_Id = p_Entity_Id
                         And i.Inventory_Id = p_Inventory_Id
                         And l.Item_Id = p_Item_Id
                         --采购单红冲出库的单据才纳入现有量计算
                         And Ibt.Transaction_Type_Id = Itt.Transaction_Type_Id
                         And Itt.Action_Type = '02'
                         And Ibt.Bill_Type_Id = o.Po_Type_Id
                       Group By l.Item_Id
                      Union All
                      Select Oio.Item_Id,
                             0 Qoh1,
                             0 Qoh2,
                             Sum(Nvl(Oio.Stock_Affirm_Qty, 0) +
                                 Nvl(Oio.Supply_Qty, 0) -
                                 Nvl(Oio.So_Order_Qty, 0) -
                                 Nvl(Oio.Sundry_Qty, 0)) Occupyqty,
                             0 NoLOck_Read_Po_Wip_Qty, --add by lizhen 2015-09-12
                             0 Read_Po_Wip_Qty   --add by lizhen 2015-03-09
                        From t_Pln_Order_Inv_Occupy Oio
                       Where Oio.Inventory_Id = p_Inventory_Id
                         And Oio.Entity_Id = p_Entity_Id
                         And Oio.Item_Id = p_Item_Id
                         And 'Y' = p_Count_Occoup_Flag --是否计
                       Group By Oio.Item_Id
                   UNION ALL      --增加新锁定 2019-02-23 guibr
                     Select Oio.Item_Id,
                             0 Qoh1,
                             0 Qoh2,
                             Sum(Nvl(Oio.QUANTITY, 0)) Occupyqty,
                             0 NoLOck_Read_Po_Wip_Qty, --add by lizhen 2015-09-12
                             0 Read_Po_Wip_Qty
                        From T_INV_LOCKIN Oio
                       Where Oio.Inventory_Id = p_Inventory_Id
                         And Oio.Entity_Id = p_Entity_Id
                         And Oio.Item_Id = p_Item_Id
                         AND Oio.LOCK_LEVEL=0
                       Group By Oio.Item_Id   
                       
                      Union All
                     --add by lizhen 2015-03-09 以下代码新增
                      Select l.Item_Id,
                             0 Qoh1,
                             0 Qoh2,
                             0 Occupyqty,
                             --add by lizhen 2015-09-12 中转工单入库但不锁库存的红冲数量
                             Nvl(Sum(Decode(Nvl(Ot.Is_Lock_Inv_Flag, 'N'), 
                                'N', Nvl(pld.shipped_qty, 0), 0)), 0)  NoLOck_Read_Po_Wip_Qty,
                             Nvl(Sum(Decode(Nvl(Ot.Is_Lock_Inv_Flag, 'N'), 
                                'Y', Nvl(pld.shipped_qty, 0), 0)), 0) Read_Po_Wip_Qty
                             /*Sum(Decode(o.Po_Status,
                                        10,
                                        Nvl(l.Billed_Qty, 0),
                                        Nvl(l.Shipped_Qty, 0))) Read_Po_Wip_Qty*/
                        From t_Inv_Po_Headers  o,
                             t_Inv_Po_Lines    l,
                             t_Inv_Bill_Types  t,
                             t_Inv_Inventories i,
                             t_Inv_Bill_Types        Ibt,
                             t_Inv_Transaction_Types Itt,
                             t_inv_po_lines_detail   Pld,
                             t_pln_order_head        Poh,
                             t_pln_order_type        Ot
                       Where t.Bill_Type_Id = o.Po_Type_Id
                         And t.Entity_Id = o.Entity_Id
                         And l.Po_Id = o.Po_Id
                         And Nvl(o.Source_Type, '_') = '工单入库' --modi by lizhen 2015-03-24
                         And i.Inventory_Id = o.Inv_Finance_Id
                         And i.Entity_Id = o.Entity_Id
                         And Nvl(o.Close_Flag, 'N') != 'Y' --add by lizhen 2015-03-26
                         And o.Billed_Date >= Sysdate - 60
                         And o.Po_Status = '21' --已发货确认
                         And o.Entity_Id = p_Entity_Id
                         And i.Inventory_Id = p_Inventory_Id
                         And l.Item_Id = p_Item_Id
                         --采购单红冲出库的单据才纳入现有量计算
                         And Ibt.Transaction_Type_Id = Itt.Transaction_Type_Id
                         And Itt.Action_Type = '02'
                         And Ibt.Bill_Type_Id = o.Po_Type_Id
                         And Ibt.Entity_Id = o.Entity_Id
                         And Pld.Po_Head_Id = o.Po_Id
                         And Pld.Po_Line_Id = l.Po_Line_Id
                         And Poh.Order_Head_Id = Pld.Order_Header_Id
                         And Poh.Order_Type_Id = Ot.Order_Type_Id
                       Group By l.Item_Id )
              Union All
              Select Min(Qoh_Qty) Qoh_Qty,
                     Min(Usable_Qoh_Qty) Usable_Qoh_Qty,
                     Min(Occupyqty_Qty),
                     Max(Read_Po_Wip_Qty) Read_Po_Wip_Qty
                From (Select Item_Id,
                             Sum(Qoh1) Qoh_Qty,
                             Sum(Qoh1 - Qoh2 - Occupyqty - Nvl(NoLOck_Read_Po_Wip_Qty, 0)) Usable_Qoh_Qty,
                             Sum(Occupyqty) Occupyqty_Qty,
                             Sum(Read_Po_Wip_Qty) Read_Po_Wip_Qty
                        From (
                              --保证套件库存准备，增加
                              Select Bias.Item_Id, 0 Qoh1, 0 Qoh2, 0 Occupyqty, 
                                0 NoLOck_Read_Po_Wip_Qty, --add by lizhen 2015-09-12
                                0 Read_Po_Wip_Qty
                                From t_Bd_Item_Assemblies     Tbia,
                                      t_Bd_Item_Assemblies_Sub Bias
                               Where Tbia.Item_Id = p_Item_Id
                                 And Tbia.Entity_Id = p_Entity_Id
                                 And Bias.Item_Assembly_Id =
                                     Tbia.Item_Assembly_Id
                                 --And Nvl(Bias.Fittings_Flag, 'N') = 'N'
                                 And Trunc(Sysdate) Between Tbia.Begin_Date And
                                     Trunc(Nvl(Tbia.End_Date, Sysdate))
                                 And Trunc(Sysdate) Between Bias.Begin_Date And
                                     Trunc(Nvl(Bias.End_Date, Sysdate))
                               Group By Bias.Item_Id, Nvl(Bias.Quantity, 1)
                              Union All
                              Select Bias.Item_Id,
                                      Trunc(Sum(Nvl(Tio.Quantity, 0)) /
                                            Nvl(Bias.Quantity, 1)) Qoh1,
                                      0 Qoh2,
                                      0 Occupyqty,
                                      0 NoLOck_Read_Po_Wip_Qty, --add by lizhen 2015-09-12
                                      0 Read_Po_Wip_Qty
                                From t_Inv_Onhand             Tio,
                                      t_Bd_Item_Assemblies     Tbia,
                                      t_Bd_Item_Assemblies_Sub Bias
                               Where Tbia.Item_Id = p_Item_Id
                                 And Tbia.Entity_Id = p_Entity_Id
                                 And Bias.Item_Assembly_Id =
                                     Tbia.Item_Assembly_Id
                                 --And Nvl(Bias.Fittings_Flag, 'N') = 'N'
                                 And Trunc(Sysdate) Between Tbia.Begin_Date And
                                     Trunc(Nvl(Tbia.End_Date, Sysdate))
                                 And Trunc(Sysdate) Between Bias.Begin_Date And
                                     Trunc(Nvl(Bias.End_Date, Sysdate))
                                 And Tio.Item_Id(+) = Bias.Item_Id
                                 And Tio.Inventory_Id(+) = p_Inventory_Id
                                 And Tio.Entity_Id(+) = p_Entity_Id
                               Group By Bias.Item_Id, Nvl(Bias.Quantity, 1)
                               Union All
                                Select Bias.Item_Id,
                                       0 Qoh1,
                                       Trunc(Sum(Nvl(l.BILLED_QTY, 0)) /
                                            Nvl(Bias.Quantity, 1)) Qoh2,
                                       0 Occupyqty,
                                       0 NoLOck_Read_Po_Wip_Qty, 
                                       0 Read_Po_Wip_Qty
                                  From cims.t_inv_check_orders      o,
                                       cims.t_inv_check_order_lines l,
                                       cims.t_Inv_Bill_Types        t,
                                       cims.t_Inv_Inventories       i,
                                       cims.t_Inv_Transaction_Types Itt,
                                       cims.t_Bd_Item_Assemblies     Tbia,
                                       cims.t_Bd_Item_Assemblies_Sub Bias
                                 Where 1=1 
                                   and Tbia.Item_Id = p_Item_Id
                                   And Tbia.Entity_Id = p_Entity_Id
                                   And Bias.Item_Assembly_Id =
                                       Tbia.Item_Assembly_Id
                                   And Trunc(Sysdate) Between Tbia.Begin_Date And
                                       Trunc(Nvl(Tbia.End_Date, Sysdate))
                                   And Trunc(Sysdate) Between Bias.Begin_Date And
                                       Trunc(Nvl(Bias.End_Date, Sysdate))
                                   And l.Item_Id(+) = Bias.Item_Id
                                   and t.Bill_Type_Id = o.check_order_type_id
                                   And t.Entity_Id = o.Entity_Id
                                   And l.check_order_id = o.check_order_id
                                   And i.Inventory_Id = o.inv_id
                                   And i.Entity_Id = o.Entity_Id
                                   And o.doc_date >= Sysdate - 30
                                   And o.po_status = '11' --制单审核
                                   --and o.process_status is not null
                                   And Nvl(o.Close_Flag, 'N') != 'Y'
                                   And o.Entity_Id = p_Entity_Id
                                   And i.Inventory_Id = p_Inventory_Id
                                   And l.Item_Id = p_Item_Id
                                   And t.Transaction_Type_Id = Itt.Transaction_Type_Id
                                   And Itt.Action_Type = '02'
                                 Group By Bias.Item_Id, Nvl(Bias.Quantity, 1)
                                 union all
                                 Select Bias.Item_Id,
                                       0 Qoh1,
                                       Trunc(Sum(Nvl(l.BILLED_QTY, 0)) /
                                            Nvl(Bias.Quantity, 1)) Qoh2,
                                       0 Occupyqty,
                                       0 NoLOck_Read_Po_Wip_Qty, --add by lizhen 2015-09-12
                                       0 Read_Po_Wip_Qty
                                  From cims.t_inv_trsf_order      o,
                                       cims.t_inv_trsf_order_line_detail l,
                                       cims.t_Inv_Inventories       i,
                                       cims.t_Bd_Item_Assemblies     Tbia,
                                       cims.t_Bd_Item_Assemblies_Sub Bias
                                 Where 1=1
                                   and Tbia.Item_Id = p_Item_Id
                                   And Tbia.Entity_Id = p_Entity_Id
                                   And Bias.Item_Assembly_Id =
                                       Tbia.Item_Assembly_Id
                                   And Trunc(Sysdate) Between Tbia.Begin_Date And
                                       Trunc(Nvl(Tbia.End_Date, Sysdate))
                                   And Trunc(Sysdate) Between Bias.Begin_Date And
                                       Trunc(Nvl(Bias.End_Date, Sysdate))
                                   And l.Item_Id(+) = Bias.Item_Id
                                   And l.trsf_order_id = o.trsf_order_id
                                   And i.Inventory_Id = o.ship_inv_id
                                   And i.Entity_Id = o.Entity_Id
                                   And o.billed_date >= Sysdate - 30
                                   And o.trsf_order_status = '11' --制单审核
                                   --and o.process_status is not null
                                   And Nvl(o.Close_Flag, 'N') != 'Y'
                                   And o.Entity_Id = p_Entity_Id
                                   And i.Inventory_Id = p_Inventory_Id
                                   And l.Item_Id = p_Item_Id
                                   and o.bill_type = '1055'
                                 Group By Bias.Item_Id, Nvl(Bias.Quantity, 1)
                              Union All
                              Select Bias.Item_Id,
                                      0 Qoh1,
                                      Trunc(Sum(Decode(o.Po_Status,
                                                       10,
                                                       Nvl(l.Billed_Qty, 0),
                                                       Nvl(l.Shipped_Qty, 0))) /
                                            Nvl(Bias.Quantity, 1)) Qoh2,
                                      0 Occupyqty,
                                      0 NoLOck_Read_Po_Wip_Qty, --add by lizhen 2015-09-12
                                      0 Read_Po_Wip_Qty
                                From t_Inv_Po_Headers         o,
                                      t_Inv_Po_Lines           l,
                                      t_Inv_Bill_Types         t,
                                      t_Inv_Inventories        i,
                                      t_Bd_Item_Assemblies     Tbia,
                                      t_Bd_Item_Assemblies_Sub Bias,
                                      t_Inv_Bill_Types        Ibt,
                                      t_Inv_Transaction_Types Itt
                               Where Tbia.Item_Id = p_Item_Id
                                 And Tbia.Entity_Id = p_Entity_Id
                                 And Bias.Item_Assembly_Id =
                                     Tbia.Item_Assembly_Id
                                 --And Nvl(Bias.Fittings_Flag, 'N') = 'N'
                                 And Trunc(Sysdate) Between Tbia.Begin_Date And
                                     Trunc(Nvl(Tbia.End_Date, Sysdate))
                                 And Trunc(Sysdate) Between Bias.Begin_Date And
                                     Trunc(Nvl(Bias.End_Date, Sysdate))
                                 And t.Bill_Type_Id = o.Po_Type_Id
                                 And t.Entity_Id = o.Entity_Id
                                 And l.Po_Id = o.Po_Id
                                 And Nvl(o.Source_Type, '_') != '工单入库' --modi by lizhen 2015-03-24
                                 And Nvl(o.Close_Flag, 'N') != 'Y' --add by lizhen 2015-03-26
                                 And i.Inventory_Id = o.Inv_Finance_Id
                                 And i.Entity_Id = o.Entity_Id
                                 And o.Billed_Date >= Sysdate - 30
                                 And o.Po_Status <> '14' --执行
                                 And o.Entity_Id = p_Entity_Id
                                 And i.Inventory_Id = p_Inventory_Id
                                 And l.Item_Id = Bias.Item_Id
                                 --采购单红冲出库的单据才纳入现有量计算
                                 And Ibt.Transaction_Type_Id = Itt.Transaction_Type_Id
                                 And Itt.Action_Type = '02'
                                 And Ibt.Bill_Type_Id = o.Po_Type_Id
                               Group By Bias.Item_Id, Nvl(Bias.Quantity, 1)
                              Union All
                              Select Bias.Item_Id,
                                      0 Qoh1,
                                      0 Qoh2,
                                      Trunc(Sum(Nvl(Oio.Stock_Affirm_Qty, 0) +
                                                Nvl(Oio.Supply_Qty, 0) -
                                                Nvl(Oio.So_Order_Qty, 0) -
                                                Nvl(Oio.Sundry_Qty, 0)) /
                                            Nvl(Bias.Quantity, 1)) Occupyqty,
                                      0 NoLOck_Read_Po_Wip_Qty, --add by lizhen 2015-09-12
                                      0 Read_Po_Wip_Qty
                                From t_Pln_Order_Inv_Occupy   Oio,
                                      t_Bd_Item_Assemblies     Tbia,
                                      t_Bd_Item_Assemblies_Sub Bias
                               Where Tbia.Item_Id = p_Item_Id
                                 And Tbia.Entity_Id = p_Entity_Id
                                 And Oio.Inventory_Id = p_Inventory_Id
                                 And Bias.Item_Id = Oio.Item_Id
                                 And Bias.Entity_Id = Oio.Entity_Id
                                 And Tbia.Entity_Id = Oio.Entity_Id
                                 And Bias.Item_Assembly_Id =
                                     Tbia.Item_Assembly_Id
                                 --And Nvl(Bias.Fittings_Flag, 'N') = 'N'
                                 And Trunc(Sysdate) Between Tbia.Begin_Date And
                                     Trunc(Nvl(Tbia.End_Date, Sysdate))
                                 And Trunc(Sysdate) Between Bias.Begin_Date And
                                     Trunc(Nvl(Bias.End_Date, Sysdate))
                                 And 'Y' = p_Count_Occoup_Flag --是否计
                               Group By Bias.Item_Id, Nvl(Bias.Quantity, 1)
                              --网批锁定
                              Union All
                              Select Bias.Item_Id,
                                      0 Qoh1,
                                      0 Qoh2,
                                      Trunc(Sum(Nvl(il.quantity, 0)) /
                                            Nvl(Bias.Quantity, 1)) Occupyqty,
                                      0 NoLOck_Read_Po_Wip_Qty, --add by lizhen 2015-09-12
                                      0 Read_Po_Wip_Qty
                                From t_inv_lockin   il,
                                      t_Bd_Item_Assemblies     Tbia,
                                      t_Bd_Item_Assemblies_Sub Bias
                               Where Tbia.Item_Id = p_Item_Id
                                 And Tbia.Entity_Id = p_Entity_Id
                                 And il.Inventory_Id = p_Inventory_Id
                                 And Bias.Item_Id = il.Item_Id
                                 And Bias.Entity_Id = il.Entity_Id
                                 And Tbia.Entity_Id = il.Entity_Id
                                 And Bias.Item_Assembly_Id = Tbia.Item_Assembly_Id
                                 --And Nvl(Bias.Fittings_Flag, 'N') = 'N'
                                 And Trunc(Sysdate) Between Tbia.Begin_Date And
                                     Trunc(Nvl(Tbia.End_Date, Sysdate))
                                 And Trunc(Sysdate) Between Bias.Begin_Date And
                                     Trunc(Nvl(Bias.End_Date, Sysdate))
                                 And 'Y' = p_Count_Occoup_Flag --是否计
                               Group By Bias.Item_Id, Nvl(Bias.Quantity, 1)
                              Union All
                              --modi by lizhe 2015-09-12 修正中转工单入库订单不锁定时，只做确认不做执行的数量不需计入可用量
                              Select Bias.Item_Id,
                                      0 Qoh1,
                                      0 Qoh2,
                                      0 Occupyqty,
                                      --add by lizhen 2015-09-12 中转工单入库但不锁库存的红冲数量
                                      Nvl(Sum(Decode(Nvl(Ot.Is_Lock_Inv_Flag, 'N'), 
                                         'N', Nvl(pld.shipped_qty, 0), 0)), 0) NoLOck_Read_Po_Wip_Qty,
                                      Nvl(Sum(Decode(Nvl(Ot.Is_Lock_Inv_Flag, 'N'), 
                                         'Y', Nvl(pld.shipped_qty, 0), 0)), 0) Read_Po_Wip_Qty
                                      /*Trunc(Sum(Decode(o.Po_Status,
                                                       10,
                                                       Nvl(l.Billed_Qty, 0),
                                                       Nvl(l.Shipped_Qty, 0))) /
                                            Nvl(Bias.Quantity, 1)) Read_Po_Wip_Qty*/
                                From t_Inv_Po_Headers         o,
                                      t_Inv_Po_Lines           l,
                                      t_Inv_Bill_Types         t,
                                      t_Inv_Inventories        i,
                                      t_Bd_Item_Assemblies     Tbia,
                                      t_Bd_Item_Assemblies_Sub Bias,
                                      t_Inv_Bill_Types        Ibt,
                                      t_Inv_Transaction_Types Itt,
                                      t_inv_po_lines_detail   Pld,
                                      t_pln_order_head        Poh,
                                      t_pln_order_type        Ot
                               Where Tbia.Item_Id = p_Item_Id
                                 And Tbia.Entity_Id = p_Entity_Id
                                 And Bias.Item_Assembly_Id =
                                     Tbia.Item_Assembly_Id
                                 --And Nvl(Bias.Fittings_Flag, 'N') = 'N'
                                 And Trunc(Sysdate) Between Tbia.Begin_Date And
                                     Trunc(Nvl(Tbia.End_Date, Sysdate))
                                 And Trunc(Sysdate) Between Bias.Begin_Date And
                                     Trunc(Nvl(Bias.End_Date, Sysdate))
                                 And t.Bill_Type_Id = o.Po_Type_Id
                                 And t.Entity_Id = o.Entity_Id
                                 And l.Po_Id = o.Po_Id
                                 And Nvl(o.Source_Type, '_') = '工单入库' --modi by lizhen 2015-03-24
                                 And Nvl(o.Close_Flag, 'N') != 'Y' --add by lizhen 2015-03-26
                                 And i.Inventory_Id = o.Inv_Finance_Id
                                 And i.Entity_Id = o.Entity_Id
                                 And o.Billed_Date >= Sysdate - 30
                                 And o.Po_Status = '21' --已发货确认
                                 And o.Entity_Id = p_Entity_Id
                                 And i.Inventory_Id = p_Inventory_Id
                                 And l.Item_Id = Bias.Item_Id
                                 --采购单红冲出库的单据才纳入现有量计算
                                 And Ibt.Transaction_Type_Id = Itt.Transaction_Type_Id
                                 And Itt.Action_Type = '02'
                                 And Ibt.Bill_Type_Id = o.Po_Type_Id
                                 And Ibt.Entity_Id = o.Entity_Id
                                 And Pld.Po_Head_Id = o.Po_Id
                                 And Pld.Po_Line_Id = l.Po_Line_Id
                                 And Poh.Order_Head_Id = Pld.Order_Header_Id
                                 And Poh.Order_Type_Id = Ot.Order_Type_Id
                               Group By Bias.Item_Id, Nvl(Bias.Quantity, 1))
                       Group By Item_Id)

              );

    r_Qty_Onhand c_Qty_Onhand%Rowtype;

    Ntemp Number := 0;
  Begin
    p_Qoh_Qty        := 0;
    p_Usable_Qoh_Qty := 0;
    p_Occupy_Qty     := 0;
    p_Result         := v_Success;

    Open c_Qty_Onhand;
    Fetch c_Qty_Onhand
      Into r_Qty_Onhand;
    If (c_Qty_Onhand%Notfound) Then
      p_Qoh_Qty        := Null;
      p_Usable_Qoh_Qty := Null;
      p_Occupy_Qty     := Null;
    Else
      p_Qoh_Qty        := r_Qty_Onhand.Qoh_Qty;
      p_Usable_Qoh_Qty := r_Qty_Onhand.Usable_Qoh_Qty;
      p_Occupy_Qty     := r_Qty_Onhand.Occupy_Qty - Nvl(r_Qty_Onhand.Read_Po_Wip_Qty, 0);
    End If;
    Close c_Qty_Onhand;
  Exception
    When Others Then
      p_Qoh_Qty        := Null;
      p_Usable_Qoh_Qty := Null;
      p_Occupy_Qty     := Null;
      p_Result         := '失败' || v_Nl || Sqlerrm;
  End;
  
  --------------------------------------------------------------------------
  --Anthor: Nicro.Li
  --Created: 2017-06-21
  --Purpose:参数库存组织ID是否为客户所属OU对应的库存组织
  --返回值说明：Y: 表示客户允许评审组织对应的仓库    N: 表示不允许评审，无权限  
  --------------------------------------------------------------------------
  Function f_Get_Custimer_Inv_Org(In_Entity_Id       In Number, --主体ID
                                  In_Customer_Id     In Number, --客户ID
                                  In_Organization_Id In Number --组织ID
                                  ) Return Varchar2 Is
    v_Chk_Cusomer_Inf_Org Varchar2(32);
    v_Count               Number;
    v_Result              Varchar2(32);
  Begin
    --获取参数是否需要检查客户OU库存组织与仓库库存组织关系参数，N:表示不需要检查
    Begin
      v_Chk_Cusomer_Inf_Org := Pkg_Bd.f_Get_Parameter_Value(p_Config_Code => 'CHK_CUSTOMER_INV_ORG',
                                                            p_Entity_Id   => In_Entity_Id);
    Exception
      When Others Then
        v_Chk_Cusomer_Inf_Org := 'N';
    End;
    If v_Chk_Cusomer_Inf_Org = 'N' Then
      Return 'Y';
    End If;
    Begin
      --查询客户OU库存组织信息 大于1行数据则返回Y
      Select Count(1)
        Into v_Count
        From Cims.t_Customer_Ou               Tcou,
             Cims.t_Customer_Header           Tch,
             Cims.t_Customer_Org              Tcsc,
             Cims.t_Customer_Acc_Org_Relation Caor,
             Cims.t_Inv_Organization          Tio
       Where Tcou.Customer_Id = Tch.Customer_Id
         And Tcou.Active_Flag = 'Active'
         And Tcou.Erpou = Tio.Operating_Unit
         And Tch.Customer_Id = Tcsc.Customer_Id
         And Tcsc.Active_Flag = 'Active'
         And Caor.Customer_Org_Id = Tcsc.Customer_Org_Id
         And Tcsc.Entity_Id = Tio.Entity_Id
         And Tcou.Customer_Id = In_Customer_Id
         And Tio.Organization_Id = In_Organization_Id
         And Tcsc.Entity_Id = In_Entity_Id;
    Exception
      When Others Then
        v_Result := 'N';
    End;
    If Nvl(v_Count, 0) > 0 Then
      v_Result := 'Y';
    End If;
    Return v_Result;
  Exception
    When Others Then
      Return 'N';
  End;
  
  
  -----------------------------------------------------------------------------
  -- Author: guibr
  --Purpose: 取得大类所在的主体                                                  --
  -----------------------------------------------------------------------------
  Function f_Get_Entity_Classcode(P_SALES_MAIN_TYPE In VARCHAR2 --营销大类编码
                            ) Return Number
  Is
    V_ENTITY_ID NUMBER;
  Begin
     Begin
         /*SELECT 
           HQ_ENTITY_ID 
         INTO 
           V_ENTITY_ID 
         FROM 
            CIMS.T_BD_ITEM_CLASS_RELATION 
         WHERE SC_ITEM_CLASS_CODE=P_SALES_MAIN_TYPE
         AND SALE_TYPE='M' 
         AND ROWNUM=1 ;*/
       SELECT 
          ENTITY_ID 
       INTO 
          V_ENTITY_ID 
       FROM 
          CIMS.T_BD_ITEM_CLASS 
       WHERE CLASS_CODE= P_SALES_MAIN_TYPE
       AND CLASS_TYPE='M' 
       AND ACTIVE_FLAG = 'Y'
       AND ROWNUM=1 ;
     EXCEPTION
              WHEN NO_DATA_FOUND THEN
                 Begin
                    /*SELECT 
                      ENTITY_ID 
                   INTO 
                      V_ENTITY_ID 
                   FROM 
                      CIMS.T_BD_ITEM_CLASS 
                   WHERE CLASS_CODE= P_SALES_MAIN_TYPE
                   AND CLASS_TYPE='M' 
                   AND ACTIVE_FLAG = 'Y'
                   AND ROWNUM=1 ;*/
                   SELECT 
                     HQ_ENTITY_ID 
                   INTO 
                     V_ENTITY_ID 
                   FROM 
                      CIMS.T_BD_ITEM_CLASS_RELATION 
                   WHERE SC_ITEM_CLASS_CODE=P_SALES_MAIN_TYPE
                   AND SALE_TYPE='M' 
                   AND ROWNUM=1 ;  
                 EXCEPTION
                     WHEN NO_DATA_FOUND THEN  
                       V_ENTITY_ID:=0;
                  END;   
     END;     
     RETURN V_ENTITY_ID;
 
    End;
     
     
    ------------------------------------------------------------
  /*    根据主体和区域编码，找到覆盖该区域(本节点 + 父节点)所有的仓库,32主体下，如果传入的中心不为空，则只展示该中心下的仓库                 */
  -- add by huanghb12 2019-2-20
  ------------------------------------------------------------
  FUNCTION F_GET_AREA_INV_LIST(P_ENTITY_ID     IN NUMBER,
                               P_DISTRICT_CODE IN VARCHAR2,
                               P_SALES_CENTER_CODE IN VARCHAR2 Default null)
    RETURN TBL_INV_INVENTORY 
    PIPELINED IS
    R_INV_INVENTORY OBJ_INV_INVENTORY;
    
    v_nc_org_id varchar2(100);
  BEGIN
    
    if P_SALES_CENTER_CODE is not null and P_ENTITY_ID = Con_Center_Filter_Entity then
      select distinct ol.nc_org_id into v_nc_org_id from cims.t_ar_ou_relation ol 
        where ol.entity_id =P_ENTITY_ID 
        and ol.sales_center_code=P_SALES_CENTER_CODE;
    end if;
         
    FOR R_INV IN (                  
                  WITH ALL_INV AS
                   (SELECT R.INVENTORY_ID, R.INVENTORY_CODE
                      FROM CIMS.T_INV_AREA_INVENTORY_RELATION R
                     WHERE R.DISTRICT_ID IN
                           (SELECT T1.ROW_ID
                              FROM T_BD_DISTRICT T1
                             START WITH T1.DISTRICT_CODE = P_DISTRICT_CODE
                            CONNECT BY PRIOR T1.PAR_ROW_ID = T1.ROW_ID)
                       AND R.ENTITY_ID = P_ENTITY_ID
                       AND R.IS_ACTIVE = 'Y'
                     ORDER BY R.DISTRICT_ID DESC)
                  SELECT ALL_INV.*,T.DISTRICT_ID,D.DISTRICT_CODE
                    FROM ALL_INV, CIMS.T_INV_INVENTORIES T, CIMS.T_BD_DISTRICT D,cims.t_ar_ou_relation ol
                   WHERE ALL_INV.INVENTORY_CODE = T.INVENTORY_CODE
                     AND T.DISTRICT_ID = D.ROW_ID
                     --增加32主体下，销售中心的过滤 add by huanghb12 2019-09-16
                     --AND T.SALES_CENTER_CODE = DECODE(P_ENTITY_ID,Con_Center_Filter_Entity,NVL(P_SALES_CENTER_CODE,T.SALES_CENTER_CODE),T.SALES_CENTER_CODE)
                     and t.entity_id = ol.entity_id(+)
                     and t.sales_center_code = ol.sales_center_code(+)
                     and nvl(v_nc_org_id,'_') = decode(P_ENTITY_ID,Con_Center_Filter_Entity,nvl(ol.nc_org_id,'_'),'_')
                     AND D.DISTRICT_CODE = P_DISTRICT_CODE
                  UNION ALL
                  SELECT ALL_INV.*,T.DISTRICT_ID,D.DISTRICT_CODE
                    FROM ALL_INV, CIMS.T_INV_INVENTORIES T, CIMS.T_BD_DISTRICT D,cims.t_ar_ou_relation ol
                   WHERE ALL_INV.INVENTORY_CODE = T.INVENTORY_CODE
                     AND T.DISTRICT_ID = D.ROW_ID
                     --增加32主体下，销售中心的过滤 add by huanghb12 2019-09-16
                     --AND T.SALES_CENTER_CODE = DECODE(P_ENTITY_ID,Con_Center_Filter_Entity,NVL(P_SALES_CENTER_CODE,T.SALES_CENTER_CODE),T.SALES_CENTER_CODE)
                     and t.entity_id = ol.entity_id(+)
                     and t.sales_center_code = ol.sales_center_code(+)
                     and nvl(v_nc_org_id,'_') = decode(P_ENTITY_ID,Con_Center_Filter_Entity,nvl(ol.nc_org_id,'_'),'_')
                     AND D.DISTRICT_CODE <> P_DISTRICT_CODE
                  ) LOOP
      R_INV_INVENTORY := OBJ_INV_INVENTORY(R_INV.INVENTORY_ID,
                                           R_INV.INVENTORY_CODE,
                                           R_INV.DISTRICT_ID,
                                           R_INV.DISTRICT_CODE
                                           );
      PIPE ROW(R_INV_INVENTORY);
    END LOOP;
    RETURN;
  EXCEPTION
    WHEN OTHERS THEN
      NULL;
  END;

End Pkg_Inv_Pub;
/

