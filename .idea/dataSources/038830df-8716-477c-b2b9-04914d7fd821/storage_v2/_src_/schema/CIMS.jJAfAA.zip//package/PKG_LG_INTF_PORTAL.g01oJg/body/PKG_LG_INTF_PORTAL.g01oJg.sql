create PACKAGE BODY PKG_LG_INTF_PORTAL IS
  LG_PORTAL_STATUS_NULL CONSTANT VARCHAR2(50) := 'CIMS_NULL'; --未处理
  LG_PORTAL_STATUS_01   CONSTANT VARCHAR2(50) := '01'; --已中心评审
  LG_PORTAL_STATUS_02   CONSTANT VARCHAR2(50) := '02'; --部分评审
  LG_PORTAL_STATUS_03   CONSTANT VARCHAR2(50) := '03'; --评审完毕
  LG_PORTAL_STATUS_04   CONSTANT VARCHAR2(50) := '04'; --总部驳回
  LG_PORTAL_STATUS_05   CONSTANT VARCHAR2(50) := '05'; --总部关闭
  LG_PORTAL_STATUS_06   CONSTANT VARCHAR2(50) := '06'; --中心驳回
  LG_PORTAL_STATUS_07   CONSTANT VARCHAR2(50) := '07'; --中心关闭
  LG_PORTAL_STATUS_08   CONSTANT VARCHAR2(50) := 'CIMSPLN_01'; --结转排产
  LG_PORTAL_STATUS_09   CONSTANT VARCHAR2(50) := 'CIMSCLS_01'; --关闭状态

  -- Function and procedure implementations
  PROCEDURE P_LG_PORTAL_STATUS_JOB IS
    V_BATCH_ID NUMBER;
  BEGIN
    SELECT S_INTF_LG_PORTAL_BATCH.NEXTVAL INTO V_BATCH_ID FROM DUAL;
    P_LG_PORTAL_STATUS_INTF(V_BATCH_ID);
    P_LG_PORTAL_STATUS_REMOTE(V_BATCH_ID);
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      NULL;
  END P_LG_PORTAL_STATUS_JOB;

  --同步本地接口
  PROCEDURE P_LG_PORTAL_STATUS_INTF(P_BATCH_ID IN NUMBER) IS
    V_LAST_SEND_TIME        DATE; --最后同步时间
    V_CURRENT_TIME          DATE; --本次推送时间
    R_INTF_LG_ORDER_PORTAL1 INTF_LG_ORDER_PORTAL%ROWTYPE;
    R_INTF_LG_ORDER_PORTAL2 INTF_LG_ORDER_PORTAL%ROWTYPE;
    R_INTF_LG_ORDER_PORTAL3 INTF_LG_ORDER_PORTAL%ROWTYPE;
    R_INTF_LG_ORDER_PORTAL4 INTF_LG_ORDER_PORTAL%ROWTYPE;
    R_INTF_LG_ORDER_PORTAL5 INTF_LG_ORDER_PORTAL%ROWTYPE;
    R_INTF_LG_ORDER_PORTAL8 INTF_LG_ORDER_PORTAL%ROWTYPE;
    R_INTF_LG_ORDER_PORTAL9 INTF_LG_ORDER_PORTAL%ROWTYPE;
    V_CEN_CHK_QTY           NUMBER; --中心评审数量
    V_AFFIRM_QTY            NUMBER; --总部评审数量
    V_QUANTITY              NUMBER; --订单数量
    V_LAST_PORTAL_STATUS    VARCHAR2(50); --最后推送门户状态
    V_LG_ORDER_QTY          NUMBER; --最后推送门户数量
    V_INSERT_01             VARCHAR2(50);
    V_INSERT_02             VARCHAR2(50);
    V_INSERT_03             VARCHAR2(50);
    V_INSERT_04             VARCHAR2(50);
    V_INSERT_05             VARCHAR2(50);
    V_INSERT_08             VARCHAR2(50);
    V_INSERT_09             VARCHAR2(50);
    V_SUM_TO_PLN_QTY        NUMBER; --结转T+3数量
    V_LAST_TO_PLN_QTY       NUMBER; --上次推送的转T+3数量
    V_MSG                   VARCHAR2(4000);
    V_SOURCE_ORDER_ID       NUMBER;
    V_LG_ORDER_AFFIRM_QTY   NUMBER; --最后推送门户的库评数量
    V_LG_CLOSE_QTY          NUMBER; --单据关闭数量
    V_LAST_CLOSE_QTY        NUMBER; --最后推送门户的关闭数量
    V_CLOSE_BY_CEN          BOOLEAN := FALSE; --是否中心关闭
  BEGIN
    V_CURRENT_TIME := SYSDATE;
    --取最后同步时间
    BEGIN
      SELECT TO_DATE(pkg_bd.F_GET_PARAMETER_VALUE('LG_PORTAL_LAST_SEND_TIME',
                                                  NULL,
                                                  NULL,
                                                  NULL),
                     'YYYY-MM-DD HH24:MI:SS')
        INTO V_LAST_SEND_TIME
        FROM dual;
    EXCEPTION
      WHEN OTHERS THEN
        V_LAST_SEND_TIME := V_LAST_SEND_TIME - 1 / 24;
    END;
    
    --处理代理商提货订单数据
    --按评审历史明细
    --1、库存评审
    INSERT INTO INTF_LG_ORDER_PORTAL
      (LG_PORTAL_INTF_ID,
       BATCH_ID,
       ENTITY_ID,
       LG_ORDER_ID,
       LG_ORDER_NUMBER,
       LG_ORDER_STATUS_ID,
       LG_ORDER_STATUS,
       LG_PORTAL_STATUS,
       LG_ORDER_QTY,
       LG_ORDER_REMARK,
       STATUS_BY,
       STATUS_DATE,
       CREATION_DATE,
       PRE_FIELD_01,
       PRE_FIELD_02)
      SELECT S_INTF_LG_PORTAL.NEXTVAL,
             P_BATCH_ID,
             ENTITY_ID,
             ORDER_HEAD_ID,
             SRC_ORDER_NUMBER ORDER_NUMBER,
             ORDER_HEAD_STATE,
             ORDER_HEAD_STATE_DESC,
             '02',
             AFFIRM_QTY,
             REMARK,
             CREATED_BY,
             CREATION_DATE,
             SYSDATE,
             ORDER_NUMBER SRC_ORDER_NUMBER,
             'LG_' || TO_CHAR(LOT_NUM) || '-' || TO_CHAR(CREATION_DATE, 'YYMMDDHH24MISS')
        FROM (SELECT OH.ENTITY_ID,
                     OH.ORDER_HEAD_ID,
                     RI.LOT_NUM,
                     OH.ORDER_NUMBER,
                     OH.ORDER_HEAD_STATE,
                     S.STATUS_CODE ORDER_HEAD_STATE_DESC,
                     MAX(RI.CREATION_DATE) CREATION_DATE,
                     RI.CREATED_BY,
                     SUM(RI.AFFIRM_QTY) AFFIRM_QTY,
                     OH.REMARK,
                     NVL(OH.ORIGIN_ORDER_NUMBER, OH.SOURCE_ORDER_NUMBER) SRC_ORDER_NUMBER
                FROM CIMS.T_PLN_ORDER_REVIEW_INFO RI,
                     CIMS.T_PLN_LG_ORDER_HEAD     OH,
                     CIMS.T_PLN_FLOW_TYPE_STATUS S
               WHERE RI.ORIGIN_ORDER_HEAD_ID = OH.ORDER_HEAD_ID
                 AND OH.ORDER_HEAD_STATE = S.STATUS_ID
                 AND OH.SYS_SOURCE = 'IMS'
                 AND RI.CREATION_DATE >= V_LAST_SEND_TIME
               GROUP BY OH.ENTITY_ID,
                        OH.ORDER_HEAD_ID,
                        RI.LOT_NUM,
                        OH.ORDER_NUMBER,
                        OH.ORDER_HEAD_STATE,
                        S.STATUS_CODE,
                        RI.CREATED_BY,
                        OH.REMARK,
                        NVL(OH.ORIGIN_ORDER_NUMBER, OH.SOURCE_ORDER_NUMBER)
               ORDER BY OH.ORDER_HEAD_ID, RI.LOT_NUM);
  
    --循环最后更新日期>=最后同步日期的提货订单
    --处理非代理商提货订单数据
    FOR R_LG IN (SELECT H.ENTITY_ID,
                        H.ORDER_HEAD_ID,
                        H.ORDER_NUMBER,
                        H.ORDER_HEAD_STATE,
                        S.STATUS_CODE STATUS_DESC,
                        H.CENTER_CHECKUP_BY_NAME,
                        H.CENTER_CHECKUP_DATE,
                        H.CHECKUP_BY_NAME,
                        H.CHECKUP_DATE,
                        H.LAST_UPDATED_BY,
                        H.LAST_UPDATE_DATE,
                        NVL(H.SYS_SOURCE, 'CIMS') SYS_SOURCE,
                        NVL(H.ORIGIN_ORDER_NUMBER, H.SOURCE_ORDER_NUMBER) SRC_ORDER_NUMBER
                   FROM T_PLN_LG_ORDER_HEAD H, T_PLN_FLOW_TYPE_STATUS S
                  WHERE H.LAST_UPDATE_DATE >= V_LAST_SEND_TIME
                    AND H.ORDER_HEAD_STATE = S.STATUS_ID
                       --AND H.ORDER_NUMBER LIKE 'T穗1515100219%'
                    AND H.ORDER_HEAD_STATE IN (679, 381, 23, 415, 304) --已中心评审，部分评审，评审完毕，已驳回，已关闭
                    --AND NVL(H.SYS_SOURCE, 'CIMS') <> 'IMS' --只处理非IMS来源单据
                  ORDER BY H.ORDER_HEAD_ID DESC) LOOP
      V_SOURCE_ORDER_ID := R_LG.ORDER_HEAD_ID;
      V_CLOSE_BY_CEN := FALSE;
      V_INSERT_01 := NULL;
      V_INSERT_02 := NULL;
      V_INSERT_03 := NULL;
      V_INSERT_04 := NULL;
      V_INSERT_05 := NULL;
      V_INSERT_08 := NULL;
      V_INSERT_09 := NULL;
    
      --取订单评审数量
      SELECT SUM(L.QUANTITY),
             SUM(L.CENTER_AFFIRM_QUANTITY),
             --SUM(L.AFFIRMED_QUANTITY),
             SUM(NVL(L.CENTER_AFFIRMED_QTY, 0) + NVL(L.HQ_AFFIRMED_QTY, 0)),
             --SUM(DECODE(L.MAKE_ORDER_LINE_FLAG, 'Y', NVL(L.TO_PLN_QTY, 0), 0)),
             SUM(DECODE(L.ORDER_LINE_STATE, 'CLOSED', NVL(L.PLN_AFFIRMED_QTY, 0), DECODE(L.MAKE_ORDER_LINE_FLAG, 'Y', NVL(L.TO_PLN_QTY, 0), 0))),
             SUM(DECODE(L.ORDER_LINE_STATE, 'CLOSED', NVL(L.CENTER_AFFIRM_QUANTITY, 0) - NVL(L.AFFIRMED_QUANTITY, 0), 0))
        INTO V_QUANTITY, V_CEN_CHK_QTY, V_AFFIRM_QTY, V_SUM_TO_PLN_QTY, V_LG_CLOSE_QTY
        FROM T_PLN_LG_ORDER_LINE L
       WHERE L.ORDER_HEAD_ID = R_LG.ORDER_HEAD_ID;
    
      --取订单最后推送状态
      BEGIN
        SELECT LG_PORTAL_STATUS, LG_ORDER_QTY
          INTO V_LAST_PORTAL_STATUS, V_LG_ORDER_QTY
          FROM (SELECT P.LG_PORTAL_STATUS, P.LG_ORDER_QTY
                  FROM INTF_LG_ORDER_PORTAL P
                 WHERE P.ENTITY_ID = R_LG.ENTITY_ID
                   AND P.LG_ORDER_NUMBER = R_LG.ORDER_NUMBER
                   AND P.LG_PORTAL_STATUS NOT IN (LG_PORTAL_STATUS_08, LG_PORTAL_STATUS_09) --结转排产
                 ORDER BY P.LG_PORTAL_INTF_ID DESC)
         WHERE ROWNUM = 1;
      EXCEPTION
        WHEN OTHERS THEN
          V_LAST_PORTAL_STATUS := LG_PORTAL_STATUS_NULL;
          V_LG_ORDER_QTY       := 0;
      END;
      
      --取订单最后推送的库评数量
      BEGIN
        SELECT LG_ORDER_QTY
          INTO V_LG_ORDER_AFFIRM_QTY
          FROM (SELECT P.LG_PORTAL_STATUS, P.LG_ORDER_QTY
                  FROM INTF_LG_ORDER_PORTAL P
                 WHERE P.ENTITY_ID = R_LG.ENTITY_ID
                   AND P.LG_ORDER_NUMBER = R_LG.ORDER_NUMBER
                   AND P.LG_PORTAL_STATUS IN (LG_PORTAL_STATUS_02, LG_PORTAL_STATUS_03) --部分评审、评审完毕
                 ORDER BY P.LG_PORTAL_INTF_ID DESC)
         WHERE ROWNUM = 1;
      EXCEPTION
        WHEN OTHERS THEN
          V_LG_ORDER_AFFIRM_QTY       := 0;
      END;
      
      --取订单最后推送关闭数量
      BEGIN
        SELECT LG_ORDER_QTY
          INTO V_LAST_CLOSE_QTY
          FROM (SELECT P.LG_PORTAL_STATUS, P.LG_ORDER_QTY
                  FROM INTF_LG_ORDER_PORTAL P
                 WHERE P.ENTITY_ID = R_LG.ENTITY_ID
                   AND P.LG_ORDER_NUMBER = DECODE(R_LG.SYS_SOURCE, 'IMS', R_LG.SRC_ORDER_NUMBER, R_LG.ORDER_NUMBER)
                   AND P.LG_PORTAL_STATUS = LG_PORTAL_STATUS_09 --关闭
                 ORDER BY P.LG_PORTAL_INTF_ID DESC)
         WHERE ROWNUM = 1;
      EXCEPTION
        WHEN OTHERS THEN
          V_LAST_CLOSE_QTY       := 0;
      END;
      
      --检查是否有推送过结转排产状态
      BEGIN
        SELECT LG_ORDER_QTY
          INTO V_LAST_TO_PLN_QTY
          FROM (SELECT P.LG_PORTAL_STATUS, P.LG_ORDER_QTY
                  FROM INTF_LG_ORDER_PORTAL P
                 WHERE P.ENTITY_ID = R_LG.ENTITY_ID
                   AND P.LG_ORDER_NUMBER = DECODE(R_LG.SYS_SOURCE, 'IMS', R_LG.SRC_ORDER_NUMBER, R_LG.ORDER_NUMBER)
                   AND P.LG_PORTAL_STATUS = LG_PORTAL_STATUS_08 --结转排产
                 ORDER BY P.LG_PORTAL_INTF_ID DESC)
         WHERE ROWNUM = 1;
      EXCEPTION
        WHEN OTHERS THEN
          V_LAST_TO_PLN_QTY := 0;
      END;
      
      IF R_LG.SYS_SOURCE <> 'IMS' THEN
        IF R_LG.ORDER_HEAD_STATE = 679 THEN
          --中心评审
          IF V_LAST_PORTAL_STATUS IN
             (LG_PORTAL_STATUS_NULL, LG_PORTAL_STATUS_04, LG_PORTAL_STATUS_06) THEN
            V_INSERT_01                             := LG_PORTAL_STATUS_01;
            R_INTF_LG_ORDER_PORTAL1.lg_order_qty    := V_CEN_CHK_QTY;
            R_INTF_LG_ORDER_PORTAL1.lg_order_remark := NULL;
            R_INTF_LG_ORDER_PORTAL1.status_by       := R_LG.CENTER_CHECKUP_BY_NAME;
            R_INTF_LG_ORDER_PORTAL1.status_date     := R_LG.CENTER_CHECKUP_DATE;
          ELSIF V_LAST_PORTAL_STATUS IN (LG_PORTAL_STATUS_01) AND
                V_CEN_CHK_QTY <> V_LG_ORDER_QTY THEN
            V_INSERT_01                             := LG_PORTAL_STATUS_01;
            R_INTF_LG_ORDER_PORTAL1.lg_order_qty    := V_CEN_CHK_QTY;
            R_INTF_LG_ORDER_PORTAL1.lg_order_remark := NULL;
            R_INTF_LG_ORDER_PORTAL1.status_by       := R_LG.CENTER_CHECKUP_BY_NAME;
            R_INTF_LG_ORDER_PORTAL1.status_date     := R_LG.CENTER_CHECKUP_DATE;
          END IF;
          IF V_INSERT_01 IS NOT NULL AND V_AFFIRM_QTY > 0 THEN
            --部分评审
            IF V_AFFIRM_QTY = V_CEN_CHK_QTY THEN
              V_INSERT_02 := LG_PORTAL_STATUS_03;
            ELSE
              V_INSERT_02 := LG_PORTAL_STATUS_02;
            END IF;
            R_INTF_LG_ORDER_PORTAL2.lg_order_qty    := V_AFFIRM_QTY;
            R_INTF_LG_ORDER_PORTAL2.lg_order_remark := NULL;
            R_INTF_LG_ORDER_PORTAL2.status_by       := R_LG.CENTER_CHECKUP_BY_NAME;
            R_INTF_LG_ORDER_PORTAL2.status_date     := R_LG.CENTER_CHECKUP_DATE;
          END IF;
        ELSIF R_LG.ORDER_HEAD_STATE = 381 THEN
          --部分评审
          IF V_LAST_PORTAL_STATUS IN
             (LG_PORTAL_STATUS_NULL, LG_PORTAL_STATUS_04, LG_PORTAL_STATUS_06) THEN
            --中心评审
            V_INSERT_01                             := LG_PORTAL_STATUS_01;
            R_INTF_LG_ORDER_PORTAL1.lg_order_qty    := V_CEN_CHK_QTY;
            R_INTF_LG_ORDER_PORTAL1.lg_order_remark := NULL;
            R_INTF_LG_ORDER_PORTAL1.status_by       := R_LG.CENTER_CHECKUP_BY_NAME;
            R_INTF_LG_ORDER_PORTAL1.status_date     := R_LG.CENTER_CHECKUP_DATE;
            IF V_AFFIRM_QTY > 0 THEN
              --部分评审
              V_INSERT_02                             := LG_PORTAL_STATUS_02;
              R_INTF_LG_ORDER_PORTAL2.lg_order_qty    := V_AFFIRM_QTY;
              R_INTF_LG_ORDER_PORTAL2.lg_order_remark := NULL;
              R_INTF_LG_ORDER_PORTAL2.status_by       := R_LG.CHECKUP_BY_NAME;
              R_INTF_LG_ORDER_PORTAL2.status_date     := R_LG.CHECKUP_DATE;
            END IF;
          /*ELSIF V_LAST_PORTAL_STATUS IN (LG_PORTAL_STATUS_01, LG_PORTAL_STATUS_03)
             OR (V_LAST_PORTAL_STATUS IN (LG_PORTAL_STATUS_02) AND V_AFFIRM_QTY <> V_LG_ORDER_QTY) THEN*/
          ELSIF (V_LAST_PORTAL_STATUS = LG_PORTAL_STATUS_01 AND V_AFFIRM_QTY > 0) OR
            (V_LAST_PORTAL_STATUS IN (LG_PORTAL_STATUS_02, LG_PORTAL_STATUS_03) AND V_AFFIRM_QTY <> V_LG_ORDER_AFFIRM_QTY) 
          THEN
            --部分评审
            V_INSERT_01                             := LG_PORTAL_STATUS_02;
            R_INTF_LG_ORDER_PORTAL1.lg_order_qty    := V_AFFIRM_QTY;
            R_INTF_LG_ORDER_PORTAL1.lg_order_remark := NULL;
            R_INTF_LG_ORDER_PORTAL1.status_by       := R_LG.CHECKUP_BY_NAME;
            R_INTF_LG_ORDER_PORTAL1.status_date     := R_LG.CHECKUP_DATE;
          END IF;
        ELSIF R_LG.ORDER_HEAD_STATE = 23 THEN
          --评审完毕
          IF V_LAST_PORTAL_STATUS IN
             (LG_PORTAL_STATUS_NULL, LG_PORTAL_STATUS_04, LG_PORTAL_STATUS_06) THEN
            --中心评审
            V_INSERT_01                             := LG_PORTAL_STATUS_01;
            R_INTF_LG_ORDER_PORTAL1.lg_order_qty    := V_CEN_CHK_QTY;
            R_INTF_LG_ORDER_PORTAL1.lg_order_remark := NULL;
            R_INTF_LG_ORDER_PORTAL1.status_by       := R_LG.CENTER_CHECKUP_BY_NAME;
            R_INTF_LG_ORDER_PORTAL1.status_date     := R_LG.CENTER_CHECKUP_DATE;
            IF V_AFFIRM_QTY > 0 THEN
              --评审完毕
              V_INSERT_02                             := LG_PORTAL_STATUS_03;
              R_INTF_LG_ORDER_PORTAL2.lg_order_qty    := V_AFFIRM_QTY;
              R_INTF_LG_ORDER_PORTAL2.lg_order_remark := NULL;
              R_INTF_LG_ORDER_PORTAL2.status_by       := R_LG.CHECKUP_BY_NAME;
              R_INTF_LG_ORDER_PORTAL2.status_date     := R_LG.CHECKUP_DATE;
            END IF;
          ELSIF (V_LAST_PORTAL_STATUS = LG_PORTAL_STATUS_01 AND V_AFFIRM_QTY > 0) OR
            (V_LAST_PORTAL_STATUS = LG_PORTAL_STATUS_02 AND V_AFFIRM_QTY <> V_LG_ORDER_AFFIRM_QTY)
          THEN
            --评审完毕
            V_INSERT_01                             := LG_PORTAL_STATUS_03;
            R_INTF_LG_ORDER_PORTAL1.lg_order_qty    := V_AFFIRM_QTY;
            R_INTF_LG_ORDER_PORTAL1.lg_order_remark := NULL;
            R_INTF_LG_ORDER_PORTAL1.status_by       := R_LG.CHECKUP_BY_NAME;
            R_INTF_LG_ORDER_PORTAL1.status_date     := R_LG.CHECKUP_DATE;
          END IF;
        ELSIF R_LG.ORDER_HEAD_STATE = 415 THEN
          --驳回
          IF V_LAST_PORTAL_STATUS IN (LG_PORTAL_STATUS_NULL) AND
             R_LG.CENTER_CHECKUP_DATE IS NULL THEN
            --中心驳回
            V_INSERT_01                             := LG_PORTAL_STATUS_06;
            R_INTF_LG_ORDER_PORTAL1.lg_order_qty    := V_CEN_CHK_QTY;
            R_INTF_LG_ORDER_PORTAL1.lg_order_remark := TO_CHAR(SYSDATE, 'MM') || '月' ||
                                                       TO_CHAR(SYSDATE, 'DD') ||
                                                       '日被中心驳回';
            R_INTF_LG_ORDER_PORTAL1.status_by       := R_LG.LAST_UPDATED_BY;
            R_INTF_LG_ORDER_PORTAL1.status_date     := R_LG.LAST_UPDATE_DATE;
          ELSIF V_LAST_PORTAL_STATUS IN (LG_PORTAL_STATUS_NULL) AND
                R_LG.CENTER_CHECKUP_DATE IS NOT NULL THEN
            --中心评审
            V_INSERT_01                             := LG_PORTAL_STATUS_01;
            R_INTF_LG_ORDER_PORTAL1.lg_order_qty    := V_CEN_CHK_QTY;
            R_INTF_LG_ORDER_PORTAL1.lg_order_remark := NULL;
            R_INTF_LG_ORDER_PORTAL1.status_by       := R_LG.CENTER_CHECKUP_BY_NAME;
            R_INTF_LG_ORDER_PORTAL1.status_date     := R_LG.CENTER_CHECKUP_DATE;
            --总部驳回
            V_INSERT_02                             := LG_PORTAL_STATUS_04;
            R_INTF_LG_ORDER_PORTAL2.lg_order_qty    := V_AFFIRM_QTY;
            R_INTF_LG_ORDER_PORTAL2.lg_order_remark := TO_CHAR(SYSDATE, 'MM') || '月' ||
                                                       TO_CHAR(SYSDATE, 'DD') ||
                                                       '日被总部驳回';
            R_INTF_LG_ORDER_PORTAL2.status_by       := R_LG.LAST_UPDATED_BY;
            R_INTF_LG_ORDER_PORTAL2.status_date     := R_LG.LAST_UPDATE_DATE;
          ELSIF V_LAST_PORTAL_STATUS IN (LG_PORTAL_STATUS_01) THEN
            V_INSERT_01                             := LG_PORTAL_STATUS_04;
            R_INTF_LG_ORDER_PORTAL1.lg_order_qty    := V_AFFIRM_QTY;
            R_INTF_LG_ORDER_PORTAL1.lg_order_remark := TO_CHAR(SYSDATE, 'MM') || '月' ||
                                                       TO_CHAR(SYSDATE, 'DD') ||
                                                       '日被总部驳回';
            R_INTF_LG_ORDER_PORTAL1.status_by       := R_LG.LAST_UPDATED_BY;
            R_INTF_LG_ORDER_PORTAL1.status_date     := R_LG.LAST_UPDATE_DATE;
          END IF;
        ELSIF R_LG.ORDER_HEAD_STATE = 304 THEN
          --关闭
          IF V_LAST_PORTAL_STATUS IN (LG_PORTAL_STATUS_NULL) AND
             R_LG.CENTER_CHECKUP_DATE IS NULL THEN
            --中心关闭
            V_INSERT_01                             := LG_PORTAL_STATUS_07;
            R_INTF_LG_ORDER_PORTAL1.lg_order_qty    := V_CEN_CHK_QTY;
            R_INTF_LG_ORDER_PORTAL1.lg_order_remark := TO_CHAR(SYSDATE, 'MM') || '月' ||
                                                       TO_CHAR(SYSDATE, 'DD') ||
                                                       '日被中心关闭';
            R_INTF_LG_ORDER_PORTAL1.status_by       := R_LG.LAST_UPDATED_BY;
            R_INTF_LG_ORDER_PORTAL1.status_date     := R_LG.LAST_UPDATE_DATE;
            V_CLOSE_BY_CEN := TRUE;
          ELSIF V_LAST_PORTAL_STATUS IN (LG_PORTAL_STATUS_NULL) AND
                R_LG.CENTER_CHECKUP_DATE IS NOT NULL THEN
            --中心评审
            V_INSERT_01                             := LG_PORTAL_STATUS_01;
            R_INTF_LG_ORDER_PORTAL1.lg_order_qty    := V_CEN_CHK_QTY;
            R_INTF_LG_ORDER_PORTAL1.lg_order_remark := NULL;
            R_INTF_LG_ORDER_PORTAL1.status_by       := R_LG.CENTER_CHECKUP_BY_NAME;
            R_INTF_LG_ORDER_PORTAL1.status_date     := R_LG.CENTER_CHECKUP_DATE;
            IF (V_AFFIRM_QTY > 0) THEN
              --部分评审
              V_INSERT_02                             := LG_PORTAL_STATUS_02;
              R_INTF_LG_ORDER_PORTAL2.lg_order_qty    := V_AFFIRM_QTY;
              R_INTF_LG_ORDER_PORTAL2.lg_order_remark := NULL;
              R_INTF_LG_ORDER_PORTAL2.status_by       := R_LG.CHECKUP_BY_NAME;
              R_INTF_LG_ORDER_PORTAL2.status_date     := R_LG.CHECKUP_DATE;
            END IF;
            --总部关闭
            /*V_INSERT_03                             := LG_PORTAL_STATUS_05;
            R_INTF_LG_ORDER_PORTAL3.lg_order_qty    := V_AFFIRM_QTY;
            R_INTF_LG_ORDER_PORTAL3.lg_order_remark := TO_CHAR(SYSDATE, 'MM') || '月' ||
                                                       TO_CHAR(SYSDATE, 'DD') ||
                                                       '日被总部关闭';
            R_INTF_LG_ORDER_PORTAL3.status_by       := R_LG.LAST_UPDATED_BY;
            R_INTF_LG_ORDER_PORTAL3.status_date     := R_LG.LAST_UPDATE_DATE;*/
          ELSIF V_LAST_PORTAL_STATUS IN
                (LG_PORTAL_STATUS_01,
                 LG_PORTAL_STATUS_02,
                 LG_PORTAL_STATUS_03) THEN
            IF (V_AFFIRM_QTY > 0 AND
               V_LAST_PORTAL_STATUS = LG_PORTAL_STATUS_01) OR
               (V_AFFIRM_QTY <> V_LG_ORDER_AFFIRM_QTY AND
               V_LAST_PORTAL_STATUS /*= LG_PORTAL_STATUS_02*/IN (LG_PORTAL_STATUS_02, LG_PORTAL_STATUS_03)/* OR
               (V_LAST_PORTAL_STATUS = LG_PORTAL_STATUS_03*/) THEN
              --部分评审
              V_INSERT_01                             := LG_PORTAL_STATUS_02;
              R_INTF_LG_ORDER_PORTAL1.lg_order_qty    := V_AFFIRM_QTY;
              R_INTF_LG_ORDER_PORTAL1.lg_order_remark := NULL;
              R_INTF_LG_ORDER_PORTAL1.status_by       := R_LG.CHECKUP_BY_NAME;
              R_INTF_LG_ORDER_PORTAL1.status_date     := R_LG.CHECKUP_DATE;
            END IF;
            --已关闭
            /*V_INSERT_02                             := LG_PORTAL_STATUS_05;
            R_INTF_LG_ORDER_PORTAL2.lg_order_qty    := V_AFFIRM_QTY;
            R_INTF_LG_ORDER_PORTAL2.lg_order_remark := TO_CHAR(SYSDATE, 'MM') || '月' ||
                                                       TO_CHAR(SYSDATE, 'DD') ||
                                                       '日被总部关闭';
            R_INTF_LG_ORDER_PORTAL2.status_by       := R_LG.LAST_UPDATED_BY;
            R_INTF_LG_ORDER_PORTAL2.status_date     := R_LG.LAST_UPDATE_DATE;*/
          END IF;
        END IF;
      END IF;
      
      --当前转T+3数量不等于上次推送的数量
      IF V_LAST_TO_PLN_QTY <> V_SUM_TO_PLN_QTY THEN
        V_INSERT_08 := LG_PORTAL_STATUS_08;
        R_INTF_LG_ORDER_PORTAL8.LG_ORDER_QTY := V_SUM_TO_PLN_QTY;
        R_INTF_LG_ORDER_PORTAL8.LG_ORDER_REMARK := NULL;
        R_INTF_LG_ORDER_PORTAL8.STATUS_BY := R_LG.LAST_UPDATED_BY;
        R_INTF_LG_ORDER_PORTAL8.STATUS_DATE := R_LG.LAST_UPDATE_DATE;
      END IF;
      
      --当前关闭数量不等于上次推送数量
      IF V_LAST_CLOSE_QTY <> V_LG_CLOSE_QTY AND NOT V_CLOSE_BY_CEN THEN
        V_INSERT_09 := LG_PORTAL_STATUS_09;
        R_INTF_LG_ORDER_PORTAL9.LG_ORDER_QTY := V_LG_CLOSE_QTY;
        R_INTF_LG_ORDER_PORTAL9.LG_ORDER_REMARK := NULL;
        R_INTF_LG_ORDER_PORTAL9.STATUS_BY := R_LG.LAST_UPDATED_BY;
        R_INTF_LG_ORDER_PORTAL9.STATUS_DATE := R_LG.LAST_UPDATE_DATE;
      END IF;
    
      IF V_INSERT_01 IS NOT NULL THEN
        R_INTF_LG_ORDER_PORTAL1.batch_id           := P_BATCH_ID;
        R_INTF_LG_ORDER_PORTAL1.entity_id          := R_LG.ENTITY_ID;
        R_INTF_LG_ORDER_PORTAL1.lg_order_id        := R_LG.ORDER_HEAD_ID;
        R_INTF_LG_ORDER_PORTAL1.lg_order_number    := R_LG.ORDER_NUMBER;
        R_INTF_LG_ORDER_PORTAL1.lg_order_status_id := R_LG.ORDER_HEAD_STATE;
        R_INTF_LG_ORDER_PORTAL1.lg_order_status    := R_LG.STATUS_DESC;
        R_INTF_LG_ORDER_PORTAL1.lg_portal_status   := V_INSERT_01;
        R_INTF_LG_ORDER_PORTAL1.creation_date      := SYSDATE;
        SELECT S_INTF_LG_PORTAL.NEXTVAL
          INTO R_INTF_LG_ORDER_PORTAL1.lg_portal_intf_id
          FROM DUAL;
        INSERT INTO INTF_LG_ORDER_PORTAL VALUES R_INTF_LG_ORDER_PORTAL1;
      END IF;
      IF V_INSERT_02 IS NOT NULL THEN
        R_INTF_LG_ORDER_PORTAL2.batch_id           := P_BATCH_ID;
        R_INTF_LG_ORDER_PORTAL2.entity_id          := R_LG.ENTITY_ID;
        R_INTF_LG_ORDER_PORTAL2.lg_order_id        := R_LG.ORDER_HEAD_ID;
        R_INTF_LG_ORDER_PORTAL2.lg_order_number    := R_LG.ORDER_NUMBER;
        R_INTF_LG_ORDER_PORTAL2.lg_order_status_id := R_LG.ORDER_HEAD_STATE;
        R_INTF_LG_ORDER_PORTAL2.lg_order_status    := R_LG.STATUS_DESC;
        R_INTF_LG_ORDER_PORTAL2.lg_portal_status   := V_INSERT_02;
        R_INTF_LG_ORDER_PORTAL2.creation_date      := SYSDATE;
        SELECT S_INTF_LG_PORTAL.NEXTVAL
          INTO R_INTF_LG_ORDER_PORTAL2.lg_portal_intf_id
          FROM DUAL;
        INSERT INTO INTF_LG_ORDER_PORTAL VALUES R_INTF_LG_ORDER_PORTAL2;
      END IF;
      IF V_INSERT_03 IS NOT NULL THEN
        R_INTF_LG_ORDER_PORTAL3.batch_id           := P_BATCH_ID;
        R_INTF_LG_ORDER_PORTAL3.entity_id          := R_LG.ENTITY_ID;
        R_INTF_LG_ORDER_PORTAL3.lg_order_id        := R_LG.ORDER_HEAD_ID;
        R_INTF_LG_ORDER_PORTAL3.lg_order_number    := R_LG.ORDER_NUMBER;
        R_INTF_LG_ORDER_PORTAL3.lg_order_status_id := R_LG.ORDER_HEAD_STATE;
        R_INTF_LG_ORDER_PORTAL3.lg_order_status    := R_LG.STATUS_DESC;
        R_INTF_LG_ORDER_PORTAL3.lg_portal_status   := V_INSERT_03;
        R_INTF_LG_ORDER_PORTAL3.creation_date      := SYSDATE;
        SELECT S_INTF_LG_PORTAL.NEXTVAL
          INTO R_INTF_LG_ORDER_PORTAL3.lg_portal_intf_id
          FROM DUAL;
        INSERT INTO INTF_LG_ORDER_PORTAL VALUES R_INTF_LG_ORDER_PORTAL3;
      END IF;
      IF V_INSERT_04 IS NOT NULL THEN
        R_INTF_LG_ORDER_PORTAL4.batch_id           := P_BATCH_ID;
        R_INTF_LG_ORDER_PORTAL4.entity_id          := R_LG.ENTITY_ID;
        R_INTF_LG_ORDER_PORTAL4.lg_order_id        := R_LG.ORDER_HEAD_ID;
        R_INTF_LG_ORDER_PORTAL4.lg_order_number    := R_LG.ORDER_NUMBER;
        R_INTF_LG_ORDER_PORTAL4.lg_order_status_id := R_LG.ORDER_HEAD_STATE;
        R_INTF_LG_ORDER_PORTAL4.lg_order_status    := R_LG.STATUS_DESC;
        R_INTF_LG_ORDER_PORTAL4.lg_portal_status   := V_INSERT_04;
        R_INTF_LG_ORDER_PORTAL4.creation_date      := SYSDATE;
        SELECT S_INTF_LG_PORTAL.NEXTVAL
          INTO R_INTF_LG_ORDER_PORTAL4.lg_portal_intf_id
          FROM DUAL;
        INSERT INTO INTF_LG_ORDER_PORTAL VALUES R_INTF_LG_ORDER_PORTAL4;
      END IF;
      IF V_INSERT_05 IS NOT NULL THEN
        R_INTF_LG_ORDER_PORTAL5.batch_id           := P_BATCH_ID;
        R_INTF_LG_ORDER_PORTAL5.entity_id          := R_LG.ENTITY_ID;
        R_INTF_LG_ORDER_PORTAL5.lg_order_id        := R_LG.ORDER_HEAD_ID;
        R_INTF_LG_ORDER_PORTAL5.lg_order_number    := R_LG.ORDER_NUMBER;
        R_INTF_LG_ORDER_PORTAL5.lg_order_status_id := R_LG.ORDER_HEAD_STATE;
        R_INTF_LG_ORDER_PORTAL5.lg_order_status    := R_LG.STATUS_DESC;
        R_INTF_LG_ORDER_PORTAL5.lg_portal_status   := V_INSERT_05;
        R_INTF_LG_ORDER_PORTAL5.creation_date      := SYSDATE;
        SELECT S_INTF_LG_PORTAL.NEXTVAL
          INTO R_INTF_LG_ORDER_PORTAL5.lg_portal_intf_id
          FROM DUAL;
        INSERT INTO INTF_LG_ORDER_PORTAL VALUES R_INTF_LG_ORDER_PORTAL5;
      END IF;
      IF V_INSERT_08 IS NOT NULL THEN
        R_INTF_LG_ORDER_PORTAL8.BATCH_ID := P_BATCH_ID;
        R_INTF_LG_ORDER_PORTAL8.ENTITY_ID := R_LG.ENTITY_ID;
        R_INTF_LG_ORDER_PORTAL8.LG_ORDER_ID := R_LG.ORDER_HEAD_ID;
        IF R_LG.SYS_SOURCE = 'IMS' THEN
          R_INTF_LG_ORDER_PORTAL8.Lg_Order_Number := r_lg.src_order_number;
          R_INTF_LG_ORDER_PORTAL8.Pre_Field_01 := R_LG.ORDER_NUMBER;
        ELSE
          R_INTF_LG_ORDER_PORTAL8.LG_ORDER_NUMBER := R_LG.ORDER_NUMBER;
        END IF;
        R_INTF_LG_ORDER_PORTAL8.LG_ORDER_STATUS_ID := R_LG.ORDER_HEAD_STATE;
        R_INTF_LG_ORDER_PORTAL8.LG_ORDER_STATUS := R_LG.STATUS_DESC;
        R_INTF_LG_ORDER_PORTAL8.LG_PORTAL_STATUS := V_INSERT_08;
        R_INTF_LG_ORDER_PORTAL8.CREATION_DATE := SYSDATE;
        SELECT S_INTF_LG_PORTAL.NEXTVAL
          INTO R_INTF_LG_ORDER_PORTAL8.lg_portal_intf_id
          FROM DUAL;
        INSERT INTO INTF_LG_ORDER_PORTAL VALUES R_INTF_LG_ORDER_PORTAL8;
      END IF;
      IF V_INSERT_09 IS NOT NULL THEN
        R_INTF_LG_ORDER_PORTAL9.BATCH_ID := P_BATCH_ID;
        R_INTF_LG_ORDER_PORTAL9.ENTITY_ID := R_LG.ENTITY_ID;
        R_INTF_LG_ORDER_PORTAL9.LG_ORDER_ID := R_LG.ORDER_HEAD_ID;
        IF R_LG.SYS_SOURCE = 'IMS' THEN
          R_INTF_LG_ORDER_PORTAL9.Lg_Order_Number := r_lg.src_order_number;
          R_INTF_LG_ORDER_PORTAL9.Pre_Field_01 := R_LG.ORDER_NUMBER;
        ELSE
          R_INTF_LG_ORDER_PORTAL9.LG_ORDER_NUMBER := R_LG.ORDER_NUMBER;
        END IF;
        R_INTF_LG_ORDER_PORTAL9.LG_ORDER_STATUS_ID := R_LG.ORDER_HEAD_STATE;
        R_INTF_LG_ORDER_PORTAL9.LG_ORDER_STATUS := R_LG.STATUS_DESC;
        R_INTF_LG_ORDER_PORTAL9.LG_PORTAL_STATUS := V_INSERT_09;
        R_INTF_LG_ORDER_PORTAL9.CREATION_DATE := SYSDATE;
        SELECT S_INTF_LG_PORTAL.NEXTVAL
          INTO R_INTF_LG_ORDER_PORTAL9.lg_portal_intf_id
          FROM DUAL;
        INSERT INTO INTF_LG_ORDER_PORTAL VALUES R_INTF_LG_ORDER_PORTAL9;
      END IF;
    END LOOP;

    --处理代理商提货订单数据
    --按评审历史明细
    --1、库存评审
    /*INSERT INTO INTF_LG_ORDER_PORTAL
      (LG_PORTAL_INTF_ID,
       BATCH_ID,
       ENTITY_ID,
       LG_ORDER_ID,
       LG_ORDER_NUMBER,
       LG_ORDER_STATUS_ID,
       LG_ORDER_STATUS,
       LG_PORTAL_STATUS,
       LG_ORDER_QTY,
       LG_ORDER_REMARK,
       STATUS_BY,
       STATUS_DATE,
       CREATION_DATE,
       PRE_FIELD_01,
       PRE_FIELD_02)
      SELECT S_INTF_LG_PORTAL.NEXTVAL,
             P_BATCH_ID,
             ENTITY_ID,
             ORDER_HEAD_ID,
             SRC_ORDER_NUMBER ORDER_NUMBER,
             ORDER_HEAD_STATE,
             ORDER_HEAD_STATE,
             '02',
             AFFIRM_QTY,
             REMARK,
             CREATED_BY,
             CREATION_DATE,
             SYSDATE,
             ORDER_NUMBER SRC_ORDER_NUMBER,
             'LG_' || TO_CHAR(LOT_NUM)
        FROM (SELECT OH.ENTITY_ID,
                     OH.ORDER_HEAD_ID,
                     RI.LOT_NUM,
                     OH.ORDER_NUMBER,
                     OH.ORDER_HEAD_STATE,
                     MAX(RI.CREATION_DATE) CREATION_DATE,
                     RI.CREATED_BY,
                     SUM(RI.AFFIRM_QTY) AFFIRM_QTY,
                     OH.REMARK,
                     NVL(OH.ORIGIN_ORDER_NUMBER, OH.SOURCE_ORDER_NUMBER) SRC_ORDER_NUMBER
                FROM CIMS.T_PLN_ORDER_REVIEW_INFO RI,
                     CIMS.T_PLN_LG_ORDER_HEAD     OH
               WHERE RI.ORIGIN_ORDER_HEAD_ID = OH.ORDER_HEAD_ID
                 AND OH.SYS_SOURCE = 'IMS'
                 AND RI.CREATION_DATE >= V_LAST_SEND_TIME
               GROUP BY OH.ENTITY_ID,
                        OH.ORDER_HEAD_ID,
                        RI.LOT_NUM,
                        OH.ORDER_NUMBER,
                        OH.ORDER_HEAD_STATE,
                        RI.CREATED_BY,
                        OH.REMARK,
                        NVL(OH.ORIGIN_ORDER_NUMBER, OH.SOURCE_ORDER_NUMBER)
               ORDER BY OH.ORDER_HEAD_ID, RI.LOT_NUM);*/
    
    --2、计划评审
    /*INSERT INTO INTF_LG_ORDER_PORTAL
      (LG_PORTAL_INTF_ID,
       BATCH_ID,
       ENTITY_ID,
       LG_ORDER_ID,
       LG_ORDER_NUMBER,
       LG_ORDER_STATUS_ID,
       LG_ORDER_STATUS,
       LG_PORTAL_STATUS,
       LG_ORDER_QTY,
       LG_ORDER_REMARK,
       STATUS_BY,
       STATUS_DATE,
       CREATION_DATE,
       PRE_FIELD_01,
       PRE_FIELD_02)
      SELECT S_INTF_LG_PORTAL.NEXTVAL,
             P_BATCH_ID,
             ENTITY_ID,
             ORDER_HEAD_ID,
             SRC_ORDER_NUMBER ORDER_NUMBER,
             ORDER_HEAD_STATE,
             ORDER_HEAD_STATE,
             '02',
             AFFIRM_QTY,
             REMARK,
             CREATED_BY,
             CREATION_DATE,
             SYSDATE,
             ORDER_NUMBER SRC_ORDER_NUMBER,
             'LGPLN_' || TO_CHAR(REVIEW_BATCH_ID)
        FROM (SELECT OH.ENTITY_ID,
                     OH.ORDER_HEAD_ID,
                     SR.REVIEW_BATCH_ID,
                     OH.ORDER_NUMBER,
                     OH.ORDER_HEAD_STATE,
                     MAX(SR.CREATION_DATE) CREATION_DATE,
                     SR.CREATED_BY,
                     SUM(SR.REVIEW_QTY) AFFIRM_QTY,
                     OH.REMARK,
                     NVL(OH.ORIGIN_ORDER_NUMBER, OH.SOURCE_ORDER_NUMBER) SRC_ORDER_NUMBER
                FROM CIMS.T_PLN_LG_ORDER_SHIP_REVIEW SR, CIMS.T_PLN_LG_ORDER_HEAD OH
               WHERE SR.REVIEW_TYPE = 'PLN_SHARE_SHIP'
                 AND SR.ORDER_HEAD_ID = OH.ORDER_HEAD_ID
                 AND OH.SYS_SOURCE = 'IMS'
                 AND SR.CREATION_DATE >= V_LAST_SEND_TIME
               GROUP BY OH.ENTITY_ID,
                        OH.ORDER_HEAD_ID,
                        SR.REVIEW_BATCH_ID,
                        OH.ORDER_NUMBER,
                        OH.ORDER_HEAD_STATE,
                        SR.CREATED_BY,
                        OH.REMARK,
                        NVL(OH.ORIGIN_ORDER_NUMBER, OH.SOURCE_ORDER_NUMBER)
               ORDER BY OH.ORDER_HEAD_ID, SR.REVIEW_BATCH_ID);*/
    
    UPDATE T_BD_PARAM_LIST L
       SET L.DEFAULT_VALUE = TO_CHAR(V_CURRENT_TIME, 'YYYY-MM-DD HH24:MI:SS')
     WHERE L.PARAM_CODE = 'LG_PORTAL_LAST_SEND_TIME';
  EXCEPTION
    WHEN OTHERS THEN
      --NULL;
      ROLLBACK;
      V_MSG := SQLERRM;
      Pkg_Pln_Pub.p_Write_Job_Log(p_Module_Code          => 'PLN',
                                  p_Procedure_Name       => 'P_LG_PORTAL_STATUS_INTF',
                                  p_Error_Msg            => V_MSG,
                                  p_Source_Order_Head_Id => V_SOURCE_ORDER_ID,
                                  p_Source_Order_Line_Id => Null,
                                  p_Item_Id              => Null,
                                  p_Inventory_Id         => Null,
                                  p_Quantity             => Null);
      COMMIT;
  END P_LG_PORTAL_STATUS_INTF;

  --同步门户接口
  PROCEDURE P_LG_PORTAL_STATUS_REMOTE(P_BATCH_ID IN NUMBER) IS
    V_MSG VARCHAR2(4000);
  BEGIN
    --NULL;
    --插入门户接口表
    INSERT INTO PORTAL_INTF_LG_ORDER_HEAD
      (FD_ID,
       DOC_SUBJECT,
       DOC_CREATETIME,
       DOC_CREATOR,
       FD_SEQNO,
       FD_TEMPLATE_FLAG,
       FD_STATUS,
       FD_NUM,
       FD_REMARK,
       FD_PRO_FLAG,
       FD_EXTEN_PARAM1)
      SELECT S_PORTAL_INTF_LG_ORDER.NEXTVAL,
             DOC_SUBJECT,
             DOC_CREATETIME,
             DOC_CREATOR,
             FD_SEQNO,
             FD_TEMPLATE_FLAG,
             FD_STATUS,
             FD_NUM,
             FD_REMARK,
             FD_PRO_FLAG,
             FD_EXTEN_PARAM1
        FROM (SELECT P.LG_ORDER_NUMBER AS DOC_SUBJECT,
                     P.STATUS_DATE AS DOC_CREATETIME,
                     P.STATUS_BY AS DOC_CREATOR,
                     P.LG_ORDER_NUMBER AS FD_SEQNO,
                     'orderflow' AS FD_TEMPLATE_FLAG,
                     P.LG_PORTAL_STATUS AS FD_STATUS,
                     P.LG_ORDER_QTY AS FD_NUM,
                     P.LG_ORDER_REMARK AS FD_REMARK,
                     0 AS FD_PRO_FLAG,
                     P.PRE_FIELD_01 || P.PRE_FIELD_02 AS FD_EXTEN_PARAM1
                FROM INTF_LG_ORDER_PORTAL P
               WHERE P.BATCH_ID = P_BATCH_ID
               ORDER BY P.LG_PORTAL_INTF_ID);
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      V_MSG := SQLERRM;
      Pkg_Pln_Pub.p_Write_Job_Log(p_Module_Code          => 'PLN',
                                  p_Procedure_Name       => 'P_LG_PORTAL_STATUS_REMOTE',
                                  p_Error_Msg            => V_MSG,
                                  p_Source_Order_Head_Id => NULL,
                                  p_Source_Order_Line_Id => Null,
                                  p_Item_Id              => Null,
                                  p_Inventory_Id         => Null,
                                  p_Quantity             => Null);
      COMMIT;
  END P_LG_PORTAL_STATUS_REMOTE;

END PKG_LG_INTF_PORTAL;
/

