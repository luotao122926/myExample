create package body PKG_PG is

   v_Nl    Constant Varchar2(2) := Chr(13) || Chr(10); --换行
   v_True  Constant Varchar2(2) := 'Y';
   v_False Constant Varchar2(2) := 'N';
   v_Success Constant Varchar2(10) := 'SUCCESS';
   v_District_level constant number := 4;

   V_PG_EXCEPTION exception;
   v_Error_UnitId Constant number := -1;

  -- Function and procedure implementations
   PROCEDURE init_pg_area_org(
                             P_ENTITY_ID in number,
                             P_USER_CODE in varchar2,
                             P_DISTRICT_LEVEL in number,
                             P_RESULT out varchar2
                             ) is
    v_Value           Varchar2(1000);
    v_MESSAGE         Varchar2(2000);
    v_Entity_Name     Varchar2(100);
    v_Count           number;
  begin
    v_MESSAGE:=v_Success;
    begin
      v_Value:='检查主体ID';
      select be.ENTITY_NAME
        into v_Entity_Name
      from v_bd_entity be
      where be.entity_id=P_ENTITY_ID;
    exception
      when others then
        v_MESSAGE:=v_Value||'异常，当前主体ID：'||P_ENTITY_ID||'不存在或无效';
        raise V_PG_EXCEPTION;
    end;

    begin
      v_Value:='主体地市信息初始化检测';
      select count(*)
      into v_Count
      from t_pg_area_org ao
      where ao.entity_id=P_ENTITY_ID;

      if v_Count>0 then
        raise V_PG_EXCEPTION;
      end if;
    exception
      when others then
        v_MESSAGE:=v_Value||'异常，当前主体：'||P_ENTITY_ID||'已完成初始，请勿重复初始化。';
        raise V_PG_EXCEPTION;
    end;

    begin
      v_Value:='初始化地市中心关系表';
      insert into t_pg_area_org(
                                id,
                                entity_id,
                                district_id,
                                district_code,
                                district_name,
                                par_row_id,
                                district_type,
                                seq_num,
                                level_seq,
                                level_num,
                                full_name,
                                created_by,
                                created_date,
                                last_upd_by,
                                last_upd_date,
                                org_code,
                                org_name,
                                unit_id)
                         select S_PG_AREA_ORG.Nextval,
                                P_ENTITY_ID,
                                bd.row_id,
                                bd.district_code,
                                bd.district_name,
                                bd.par_row_id,
                                bd.district_type,
                                bd.seq_num,
                                bd.level_seq,
                                bd.level_num,
                                bd.full_name,
                                nvl(P_USER_CODE,'-1'),
                                sysdate,
                                nvl(P_USER_CODE,'-1'),
                                sysdate,
                                null,
                                null,
                                null
                           from t_bd_district bd
                           where bd.level_seq<nvl(P_DISTRICT_LEVEL,v_District_level);
     exception
       when others then
        v_MESSAGE:=v_Value||'异常，当前主体：'||P_ENTITY_ID||'初始失败。';
        raise V_PG_EXCEPTION;
     end;
     P_RESULT:=v_MESSAGE;
  exception
     when others then
        P_RESULT:=v_MESSAGE;
  end;



  PROCEDURE get_distree_org( P_ENTITY_ID in number,
                             P_DISTRICT_CODE in varchar2,
                             P_UNIT_ID out number,
                             P_CENTER_CODE out varchar2,
                             P_CNETER_NAME out varchar2,
                             P_ERR_MESSAGE out varchar2
                             ) is

    v_Value           Varchar2(1000);
    v_MESSAGE         Varchar2(2000);
    v_Entity_Name     Varchar2(100);
    v_Count           number;

    Cursor c_District_Org is
          select ao.* from
                 (select bd.* from t_bd_district bd
                         start with bd.district_code=P_DISTRICT_CODE
                         connect by prior bd.par_row_id=bd.row_id
                  ) distree,t_pg_area_org ao
                  where distree.row_id=ao.district_id
                    and ao.entity_id=P_ENTITY_ID
                  order by ao.level_seq desc;
    r_District_Org   c_District_Org%rowtype;

  Begin
    P_ERR_MESSAGE:=v_Success;
    Begin
      v_Value:='检查主体ID';
      select be.ENTITY_NAME
        into v_Entity_Name
      from v_bd_entity be
      where be.entity_id=P_ENTITY_ID;
    Exception
      when others then
        v_MESSAGE:=v_Value||'异常，当前主体ID：'||P_ENTITY_ID||'不存在或无效';
        raise V_PG_EXCEPTION;
    End;

    Begin
      v_Value:='遍历区域中心对应关系';
      P_UNIT_ID:=null;
      Open c_District_Org;
      Loop
         Fetch c_District_Org
            Into r_District_Org;
      Exit When P_UNIT_ID <> -1 or c_District_Org%notfound;
           P_UNIT_ID:=nvl(r_District_Org.Unit_Id,-1);
      End loop;
      If nvl(P_UNIT_ID,-1) = -1  Then
         P_UNIT_ID :=v_Error_UnitId;
         P_ERR_MESSAGE:='未设置地市中心关系';
      End if;
    Exception
      when others then
        v_MESSAGE:=v_Value||'异常，当前地点编码：'||P_DISTRICT_CODE||'异常';
        raise V_PG_EXCEPTION;
    End;

    Begin
      v_Value:='获取中心名称';
      If nvl(P_UNIT_ID,-1) !=-1 Then
         select u.code,u.name
           into  P_CENTER_CODE ,P_CNETER_NAME
           from up_org_unit u where u.unit_id=P_UNIT_ID;
      End if;
    Exception
      when others then
        v_MESSAGE:=v_Value||'异常，中心ID：'||P_UNIT_ID;
        raise V_PG_EXCEPTION;
    End;

   Exception
      when others then
        P_UNIT_ID:=v_Error_UnitId;
        P_ERR_MESSAGE:=v_MESSAGE;
   End;
   
  ----------------------------------------------------------------------
  -- Author  : WANGCONG
  -- Created : 2017/09/26
  -- Purpose : 每日更新工程机占比
  ----------------------------------------------------------------------
  
  Procedure P_PG_APPLY_AMOUNT_SCALE(P_MESSAGE OUT VARCHAR2) IS
    
    V_VALUE               VARCHAR2(1024);
    
    V_BEGIN_DATE          VARCHAR2(32);--统计开始日期
    V_BEGIN_TIME          DATE;
    V_END_DATE            DATE;--统计结束日期
    V_TMP_COUNT           NUMBER;--执行sql语句返回受影响行数
    V_ENTITY_ID           NUMBER;--当前统计的主体
    
    V_APPLY_AMOUNT        NUMBER;--已审核工程机金额
    V_SETTLE_AMOUNT       NUMBER;--结算金额
    V_APPLY_SCALE         NUMBER;--工程机占比
    V_SALES_CENTER_ID     NUMBER;--营销中心ID
    V_SALES_CENTER_CODE   T_PG_PRICE_APPLY_AMOUNT.SALES_CENTER_CODE%TYPE;
    V_SALES_CENTER_NAME   T_PG_PRICE_APPLY_AMOUNT.SALES_CENTER_NAME%TYPE;
    
    
    
    CURSOR C_ENTITY_LIST IS
      SELECT * FROM UP_CODELIST UC WHERE UC.CODETYPE = 'tpgPriceApplyCount';
    
    R_ENTITY_LIST     UP_CODELIST%ROWTYPE;
      
    BEGIN
      P_MESSAGE := v_Success;
      V_TMP_COUNT := 0;
      V_END_DATE := SYSDATE;
      
      BEGIN
        V_VALUE := '遍历主体统计数据：';
        OPEN C_ENTITY_LIST;
          LOOP
            FETCH C_ENTITY_LIST INTO R_ENTITY_LIST; 
          EXIT WHEN C_ENTITY_LIST%NOTFOUND OR P_MESSAGE <> v_Success;
            
            BEGIN
              V_VALUE := '取统计开始日期：';
              PKG_BD.P_GET_PARAMETER_VALUE('PG_COUNT_BEGIN_DATE',
                                         R_ENTITY_LIST.CODE_VALUE,
                                         Null,
                                         Null,
                                         V_BEGIN_DATE);
            EXCEPTION
               WHEN OTHERS THEN
                 P_MESSAGE := V_VALUE || '失败。' || v_Nl || SQLERRM;
            END;
            
            IF P_MESSAGE = v_Success THEN
              V_BEGIN_TIME := TO_DATE(V_BEGIN_DATE,'yyyy-MM-dd');
              BEGIN
                V_VALUE := '向冻结表写数据：';
                FOR C_TMP_COUNT_INFO IN (SELECT *
                                          FROM (SELECT D.CENTER_ID,
                                                       D.CENTER_CODE,
                                                       D.CENTER_NAME,
                                                       SUM(D.APPLY_PRICE * D.APPLY_CNT) APPLY_AMOUNT
                                                FROM CIMS.T_BD_PRICE_APPLY_DETAIL D
                                                WHERE D.PRICE_APPLY_ID IN
                                                      (SELECT A.PRICE_APPLY_ID
                                                           FROM CIMS.T_BD_PRICE_APPLY A
                                                       WHERE A.APPLY_TYPE = 'PG'
                                                         AND A.ENTITY_ID = R_ENTITY_LIST.CODE_VALUE
                                                         AND A.APPLY_DATE >= V_BEGIN_TIME
                                                         AND A.APPLY_DATE < trunc(SYSDATE))
                                                       GROUP BY D.CENTER_ID, D.CENTER_CODE, D.CENTER_NAME) X
                                                FULL JOIN (SELECT V.SALES_CENTER_ID,
                                                                  V.SALES_CENTER_CODE,
                                                                  V.SALES_CENTER_NAME,
                                                                  SUM(V.ITEM_SETTLE_AMOUNT) SETTLE_AMOUNT
                                                           FROM CIMS.V_SO_CUSTOMER_SALES_DETAIL V
                                                           WHERE V.ENTITY_ID = R_ENTITY_LIST.CODE_VALUE
                                                             AND V.SO_DATE >= V_BEGIN_TIME
                                                             AND V.SO_DATE < trunc(SYSDATE)
                                                             AND V.COOPERATION_MODEL <> '销售公司/直营分部'
                                                             AND V.SETTLE_FLAG = 'Y'
                                                           GROUP BY V.SALES_CENTER_ID,
                                                                    V.SALES_CENTER_CODE,
                                                                    V.SALES_CENTER_NAME) Y
                                                 ON X.CENTER_CODE = Y.SALES_CENTER_CODE) LOOP
                  
                  --营销中心ID
                  IF C_TMP_COUNT_INFO.CENTER_ID IS NOT NULL THEN
                    V_SALES_CENTER_ID := C_TMP_COUNT_INFO.CENTER_ID;
                  ELSE
                    V_SALES_CENTER_ID := C_TMP_COUNT_INFO.SALES_CENTER_ID;
                  END IF;
                  
                  --营销中心编码
                  IF C_TMP_COUNT_INFO.CENTER_CODE IS NOT NULL THEN
                    V_SALES_CENTER_CODE := C_TMP_COUNT_INFO.CENTER_CODE;
                  ELSE
                    V_SALES_CENTER_CODE := C_TMP_COUNT_INFO.SALES_CENTER_CODE;
                  END IF;
                  
                  --营销中心名称
                  IF C_TMP_COUNT_INFO.CENTER_NAME IS NOT NULL THEN
                    V_SALES_CENTER_NAME := C_TMP_COUNT_INFO.CENTER_NAME;
                  ELSE
                    V_SALES_CENTER_NAME := C_TMP_COUNT_INFO.SALES_CENTER_NAME;
                  END IF;
                  
                  --已审核工程机金额
                  V_APPLY_AMOUNT := C_TMP_COUNT_INFO.APPLY_AMOUNT;
                  
                  --结算金额
                  V_SETTLE_AMOUNT := C_TMP_COUNT_INFO.SETTLE_AMOUNT;
                  
                  IF V_APPLY_AMOUNT IS NULL THEN
                    V_APPLY_SCALE := 0;
                  ELSIF V_APPLY_AMOUNT IS NOT NULL AND V_SETTLE_AMOUNT IS NULL THEN
                    V_APPLY_SCALE := 100;
                  ELSIF V_APPLY_AMOUNT IS NOT NULL AND V_SETTLE_AMOUNT IS NOT NULL THEN
                    V_APPLY_SCALE := ROUND(V_APPLY_AMOUNT/V_SETTLE_AMOUNT * 100,2);
                  END IF;
                  
                  --向冻结表写数据
                  INSERT INTO T_PG_PRICE_APPLY_AMOUNT
                    (CONFIG_ID,
                     ENTITY_ID,
                     SALES_CENTER_ID,
                     SALES_CENTER_CODE,
                     SALES_CENTER_NAME,
                     BEGIN_DATE,
                     END_DATE,
                     PG_APPLY_AMOUNT,
                     SETTLE_AMOUNT,
                     PG_SCALE,
                     CREATED_BY,
                     CREATION_DATE,
                     LAST_UPDATED_BY,
                     LAST_UPDATE_DATE,
                     VERSION)
                  VALUES
                    (S_PROJECT_APPLY_AMOUNT_CONFIG.NEXTVAL,
                     R_ENTITY_LIST.CODE_VALUE,
                     V_SALES_CENTER_ID,
                     V_SALES_CENTER_CODE,
                     V_SALES_CENTER_NAME,
                     V_BEGIN_TIME,
                     TRUNC(SYSDATE - 1, 'DD'),
                     V_APPLY_AMOUNT,
                     V_SETTLE_AMOUNT,
                     V_APPLY_SCALE,
                     'ADMIN',
                     SYSDATE,
                     NULL,
                     NULL,
                     1);                                  
                END LOOP;
              EXCEPTION
               WHEN OTHERS THEN
                 P_MESSAGE := V_VALUE || '失败。' || v_Nl || SQLERRM;
              END;  
            END IF; 
          END LOOP;
         CLOSE C_ENTITY_LIST;
       END;  
    END;
    
   ----------------------------------------------------------------------
  -- Author  : WANGCONG
  -- Created : 2017/11/08
  -- Purpose : 自动冻结工程机批文
  ----------------------------------------------------------------------
  Procedure P_PG_APPLY_PRICE_FREEZE(P_MESSAGE OUT VARCHAR2) IS
    
    V_VALUE               VARCHAR2(1024);
    
    V_TMP_COUNT           NUMBER;--执行sql语句返回受影响行数
    V_ENTITY_ID           NUMBER;--当前统计的主体
    V_CURRENT_DATE        DATE;--当前时间
    V_FREEZE_CONFIG_DATE  NUMBER;--自动冻结天数
    V_AUDIT_DATE          DATE;--批文审批时间
    V_FREEZE_DATE         DATE;--批文应锁定时间
    V_SALES_CENTER_ID     NUMBER;--营销中心ID
    V_SALES_CENTER_CODE   T_BD_PRICE_APPLY_FREEZE.SALES_CENTER_CODE%TYPE;
    V_SALES_CENTER_NAME   T_BD_PRICE_APPLY_FREEZE.SALES_CENTER_NAME%TYPE;
    
    
    
    CURSOR C_ENTITY_LIST IS
      SELECT * FROM UP_CODELIST UC WHERE UC.CODETYPE = 'tpgPriceApplyFreeze';
    
    R_ENTITY_LIST     UP_CODELIST%ROWTYPE;
    
    TYPE C_BD_APPLY_FREEZE_CONFIG IS REF CURSOR ;--当前冻结主体的配置
    V_BD_APPLY_FREEZE_CONFIG C_BD_APPLY_FREEZE_CONFIG;
    V_BD_TMP_APPLY_FREEZE_CONFIG  T_BD_PRICE_APPLY_FREEZE%ROWTYPE;
    
    TYPE C_BD_FREEZE_APPLY_INFO IS REF CURSOR ;--需要锁定的批文
    V_BD_FREEZE_APPLY_INFO C_BD_FREEZE_APPLY_INFO;
    V_BD_TMP_FREEZE_APPLY_INFO  T_BD_PRICE_APPLY%ROWTYPE;
      
    BEGIN
      P_MESSAGE := v_Success;
      V_TMP_COUNT := 0;
      V_CURRENT_DATE := SYSDATE;
      
      BEGIN
        V_VALUE := '遍历主体统计数据：';
        OPEN C_ENTITY_LIST;
          LOOP
            FETCH C_ENTITY_LIST INTO R_ENTITY_LIST; 
          EXIT WHEN C_ENTITY_LIST%NOTFOUND OR P_MESSAGE <> v_Success;
          
            V_ENTITY_ID := R_ENTITY_LIST.CODE_VALUE;
            --取当前主体的配置
            OPEN V_BD_APPLY_FREEZE_CONFIG FOR 
                        'SELECT * FROM T_BD_PRICE_APPLY_FREEZE L WHERE L.ENTITY_ID = '|| V_ENTITY_ID;
            LOOP
              FETCH V_BD_APPLY_FREEZE_CONFIG 
              INTO V_BD_TMP_APPLY_FREEZE_CONFIG;
            EXIT WHEN V_BD_APPLY_FREEZE_CONFIG%NOTFOUND;
            
                 V_SALES_CENTER_CODE := V_BD_TMP_APPLY_FREEZE_CONFIG.SALES_CENTER_CODE;
                 V_FREEZE_CONFIG_DATE := V_BD_TMP_APPLY_FREEZE_CONFIG.FREEZE_DATE;
                 
                 IF V_FREEZE_CONFIG_DATE IS NOT NULL THEN
                   BEGIN
                     V_VALUE := '锁定批文：';
                   UPDATE T_BD_PRICE_APPLY A
                      SET A.LOCK_FLAG = 'Y',
                          A.LOCK_REMARK = '系统自动锁定：到期自动锁定',
                          A.LOCKED_BY = 'system',
                          A.LOCKED_DATE = SYSDATE
                    WHERE (EXTRACT(DAY FROM(TRUNC(SYSDATE) - A.APPLY_DATE) DAY(3) TO SECOND)) >= V_FREEZE_CONFIG_DATE
                      AND A.APPLY_TYPE = 'PG'
                      AND A.LOCK_FLAG = 'N'
                      AND A.ENTITY_ID = V_ENTITY_ID
                      AND A.PRICE_APPLY_ID IN
                          (SELECT D.PRICE_APPLY_ID
                             FROM T_BD_PRICE_APPLY_DETAIL D
                            WHERE D.CENTER_CODE = V_SALES_CENTER_CODE);
                    EXCEPTION
                      WHEN OTHERS THEN
                         P_MESSAGE := V_VALUE || '失败。' || v_Nl || SQLERRM;
                    END;
                 END IF;
            
            END LOOP;
          END LOOP;
      EXCEPTION
        WHEN OTHERS THEN
          P_MESSAGE := V_VALUE || '失败。' || v_Nl || SQLERRM;
      END ;
      
    END;

end PKG_PG;
/

