create PACKAGE      PKG_BD_ITEM_INVALID  AS

  -----------------------------------------------------------------------------
  --处理产品物料失效校验主过程
  -----------------------------------------------------------------------------
  PROCEDURE P_SYC_ITEM_INVALID_MAIN
  (
    P_ESB_SERIAL_NUM       IN VARCHAR2,--ESB流水号
    P_RESULT         IN OUT NUMBER, --返回错误ID
    P_ERR_MSG        IN OUT VARCHAR2 --返回错误信息
  );

  -----------------------------------------------------------------------------
  --处理产品物料失效校验
  -----------------------------------------------------------------------------
  PROCEDURE P_SYC_ITEM_INVALID
  (
    P_INTF_BD_ITEM_INVALID IN OUT INTF_BD_ITEM_INVALID%ROWTYPE,
    P_RESULT         IN OUT NUMBER, --返回错误ID
    P_ERR_MSG        IN OUT VARCHAR2 --返回错误信息
  );

END PKG_BD_ITEM_INVALID;
/

