create PACKAGE PKG_PMT_PUB IS

  PMT_EXCEPTION EXCEPTION; --自定义异常

  V_RESULT VARCHAR2(20) := '1'; --成功标记

  V_RESULT_MSG VARCHAR2(1000) := 'success'; --成功返回信息

  PROCEDURE P_UNOCCUPY_INV_TRANSACTION_OLD(IN_ENTITYID     IN NUMBER,
                                           IN_SEND_HEAD_ID IN NUMBER,
                                           FLAG            OUT VARCHAR2,
                                           FLAGMESSAGE     OUT VARCHAR2);
  PROCEDURE P_UNOCCUPY_INV_TRANSACTION(IN_ENTITYID     IN NUMBER,
                                       IN_CURRUSER     IN VARCHAR2,
                                       IN_SEND_HEAD_ID IN NUMBER,
                                       IN_SEND_LINE_ID IN NUMBER,
                                       REC_QTY         IN NUMBER,
                                       FLAG            OUT VARCHAR2,
                                       FLAGMESSAGE     OUT VARCHAR2);
  PROCEDURE P_PMT_COLLAR_SEND_UNOCCUPY_INV(IN_ENTITYID IN NUMBER,
                                           IN_HEADID   IN NUMBER,
                                           IN_LINEI    IN NUMBER,
                                           FLAG        OUT VARCHAR2,
                                           FLAGMESSAGE OUT VARCHAR2);
  /**
    触发库存事务
  */
  PROCEDURE P_PMT_INV_TRANSACTION(IN_ENTITYID IN NUMBER,
                                  IN_HEADID   IN NUMBER,
                                  FLAG        OUT VARCHAR2,
                                  FLAGMESSAGE OUT VARCHAR2);
  /*
  *   创建日期：2015-07-10
  *     创建者：吴林
  *   功能说明：发货确认触发生成发放通知单入口
  *
  */
  -------------------------------------------------------------------------------

  PROCEDURE P_PMT_ENTRY_SHIP(P_SHIP_INFO_ID IN NUMBER, --实际发货信息ID
                             P_USER_CODE    IN VARCHAR2, --操作用户编码
                             P_ORDER_TYPE   IN VARCHAR2, --单据类型
                             P_SEND_HEAD_ID OUT NUMBER, --生成发放单的头表ID
                             P_RESULT       OUT NUMBER, --返回错误ID
                             P_ERR_MSG      OUT VARCHAR2 --返回错误信息
                             );
  /**
     作者 吴林
     创建日期 2015-08-06
     功能描述 推广物料信用控制
  */
  PROCEDURE P_PMT_CREDIT_CONTROL(P_SEND_HEADER_ID IN NUMBER, --销售单据头ID
                                 P_RESULT         OUT NUMBER, --返回错误ID
                                 P_ERR_MSG        OUT VARCHAR2 --返回错误信息
                                 );

  /**
     作者 吴林
     创建日期 2015-12-09
     功能描述 推广物料回写单号到物流运输合同
  */
  PROCEDURE P_PMT_RETURN_WRIT_NUM(P_SEND_HEADER_ID IN NUMBER, --销售单据头ID
                                  P_RESULT         OUT NUMBER, --返回错误ID
                                  P_ERR_MSG        OUT VARCHAR2 --返回错误信息
                                  );

  PROCEDURE P_UNOCCUPY_INV_TRANSACTION_NEW(IN_ENTITYID     IN NUMBER,
                                           IN_SEND_HEAD_ID IN NUMBER,
                                           FLAG            OUT VARCHAR2,
                                           FLAGMESSAGE     OUT VARCHAR2);

  PROCEDURE P_PMT_COLLAR_SEND_OCCUPY_INV(IN_ENTITYID IN NUMBER,
                                         IN_HEADID   IN NUMBER,
                                         FLAG        OUT VARCHAR2,
                                         FLAGMESSAGE OUT VARCHAR2);

  PROCEDURE P_PMT_UNOCCUPY_INV_NEW(IN_ENTITYID IN NUMBER,
                                   IN_HEADID   IN NUMBER,
                                   FLAG        OUT VARCHAR2,
                                   FLAGMESSAGE OUT VARCHAR2);
  /**
     释放发放单剩余库存
  */
  PROCEDURE P_PMT_UNOCCUPY_REMAIN_INV(IN_ENTITYID IN NUMBER,
                                      IN_HEADID   IN NUMBER,
                                      IN_LINEI    IN NUMBER,
                                      FLAG        OUT VARCHAR2,
                                      FLAGMESSAGE OUT VARCHAR2);

  /**
  *检查推广物料采购单预算
  */
  PROCEDURE P_PMT_CHECK_BUDGET(P_ORDER_HEAD_ID         IN NUMBER,
                               P_BUDGET_AMOUNT         OUT NUMBER, --占用预算
                               P_BUDGET_AMOUNT_CAN_USE OUT NUMBER, --可用预算
                               P_BUDGET_AMOUNT_USING1  OUT NUMBER, --同节点制单占用预算
                               P_BUDGET_AMOUNT_USING2  OUT NUMBER, --同节点送审占用预算
                               P_MESSAGE               OUT VARCHAR2);

  PROCEDURE P_PMT_OCCUPY_BUDGET(IN_ENTITYID IN NUMBER,
                                IN_HEADID   IN NUMBER,
                                FLAG        OUT VARCHAR2,
                                FLAGMESSAGE OUT VARCHAR2);

  PROCEDURE P_PMT_OCCUPY_BUDGET_INV(IN_ENTITYID IN NUMBER,
                                    IN_HEADID   IN NUMBER,
                                    FLAG        OUT VARCHAR2,
                                    FLAGMESSAGE OUT VARCHAR2);

  PROCEDURE P_PMT_UNOCCUPY_BUDGET(IN_ENTITYID IN NUMBER,
                                  IN_HEADID   IN NUMBER,
                                  IN_LINEID   IN NUMBER,
                                  FEE_NUM     IN NUMBER,
                                  FLAG        OUT VARCHAR2,
                                  FLAGMESSAGE OUT VARCHAR2);
  /**
    触发库存事务
  */
  PROCEDURE P_PMT_INV_TRANSACTION_NEW(IN_ENTITYID IN NUMBER,
                                      IN_HEADID   IN NUMBER,
                                      FLAG        OUT VARCHAR2,
                                      FLAGMESSAGE OUT VARCHAR2);
  /**
    取消发货
  */
  PROCEDURE P_PMT_CANCEL_SEND_QTY(IN_LINE_ID       IN NUMBER,
                                  IN_PMT_ORDER_NUM IN VARCHAR2,
                                  IN_CANCEL_QTY    IN NUMBER,
                                  FLAG             OUT VARCHAR2,
                                  FLAG_MESSAGE     OUT VARCHAR2);
  /**
    重置账户别名发送异常的状态
  */
  PROCEDURE P_SEND_AGAIN_ALIAS(FLAG         OUT VARCHAR2,
                               FLAG_MESSAGE OUT VARCHAR2);
  /*
  *推广物料结算批保存后更新数量
  */
  PROCEDURE P_ACCOUNT_AMOUNT_UPDATE(HEADER_ID IN T_PMT_ACCOUNT_LINE.ACCOUNT_HEAD_ID%TYPE, --头表ID
                                    FLAG      OUT VARCHAR2, --返回值
                                    FLAG_MSG  OUT VARCHAR2 --返回信息
                                    );

  /*
  * 采购单占用预算
  */
  PROCEDURE P_ORDER_OCCUPY_BUDGET(HEADER_ID IN T_PMT_ORDER_HEADER.ORDER_HEAD_ID%TYPE, --头表ID
                                  USER_ID   IN NUMBER, --用户ID
                                  FLAG      OUT VARCHAR2, --返回值
                                  FLAG_MSG  OUT VARCHAR2 --返回信息
                                  );
  /**
  *  采购单红冲时释放预算
  */
  PROCEDURE P_ORDER_UNOCCUPY_BUDGET(HEADER_ID IN T_PMT_ORDER_HEADER.ORDER_HEAD_ID%TYPE, --头表ID
                                    USER_ID   IN NUMBER, --用户ID
                                    FLAG      OUT VARCHAR2, --返回值
                                    FLAG_MSG  OUT VARCHAR2 --返回信息
                                    );
  /**
  * 中转单A3回写实际数量
  **/
  PROCEDURE P_ORDER_WRITEBACK_AMOUNT(PO_NUMBER IN T_INV_PO_HEADERS.PO_NUM%TYPE, --中转单单号
                                     ENTITY_ID IN NUMBER, --实体ID
                                     FLAG      OUT VARCHAR2, --返回值
                                     FLAG_MSG  OUT VARCHAR2 --返回信息
                                     );
  /**
  * 校验生成发放单的数量是否正确
  **/
  PROCEDURE P_CHECK_SEND_QTY(in_head_id   IN T_PMT_COLLAR_SEND_HEAD.COLLAR_SEND_HEAD_ID%TYPE, --头ID
                             O_S_FLAG     OUT VARCHAR2, --返回值
                             O_S_FLAG_MSG OUT VARCHAR2 --返回信息
                             );

  /**
  *检查推广物料采购单预算
  */
  PROCEDURE P_PMT_CHECK_BUDGET(P_ORDER_HEAD_ID         IN NUMBER,
                               I_BUDGET_AMOUNT         IN NUMBER, --预算
                               P_BUDGET_AMOUNT         OUT NUMBER, --占用预算
                               P_BUDGET_AMOUNT_CAN_USE OUT NUMBER, --可用预算
                               P_BUDGET_AMOUNT_USING1  OUT NUMBER, --同节点制单占用预算
                               P_BUDGET_AMOUNT_USING2  OUT NUMBER, --同节点送审占用预算
                               P_MESSAGE               OUT VARCHAR2);

  /*
  * 采购单占用预算
  */
  PROCEDURE P_ORDER_OCCUPY_BUDGET(HEADER_ID       IN T_PMT_ORDER_HEADER.ORDER_HEAD_ID%TYPE, --头表ID
                                  USER_ID         IN NUMBER, --用户ID
                                  I_BUDGET_AMOUNT IN NUMBER, --预算
                                  FLAG            OUT VARCHAR2, --返回值
                                  FLAG_MSG        OUT VARCHAR2 --返回信息
                                  );


  /*
  * 推广物料采购单生成实际发货信息
  */
  PROCEDURE P_PMT_CREATE_ACTUAL_SHIP(P_SHIP_BATCH_ID IN NUMBER, --批次ID
                                     USER_CODE IN VARCHAR2,--用户ID
                                     RETURN_MSG OUT VARCHAR2 --返回信息
    );


END PKG_PMT_PUB;
/

