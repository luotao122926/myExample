create procedure P_GRANT_PRIVS_TO_SELECTUSER AS
begin
  for z in (select 'grant select on ' || a.owner || '.' || a.object_name || ' to SELECT_USER' as grant_sql,CREATED
              from all_objects a
             where a.owner = 'CIMS' AND a.object_type in ('TABLE','VIEW')
               and (a.owner,a.object_name) not in
                   (select table_schema,table_name from all_tab_privs where table_schema = 'CIMS' and grantee = 'SELECT_USER')
             union all
            select 'grant debug on ' || a.owner || '.' || a.object_name || ' to SELECT_USER' as grant_sql,CREATED
              from all_objects a
             where a.owner = 'CIMS' AND a.object_type in ('PACKAGE','PROCEDURE')
               and (a.owner,a.object_name) not in
                   (select table_schema,table_name from all_tab_privs where table_schema = 'CIMS' and grantee = 'SELECT_USER'))
  loop
    dbms_output.put_line(z.grant_sql);
    execute immediate z.grant_sql;
  end loop;
end P_GRANT_PRIVS_TO_SELECTUSER;
/

