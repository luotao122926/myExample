create PACKAGE PKG_LG_CHARGES IS

  ----------------------------------------------------------------------
  -- AUTHOR  : XUQF
  -- CREATED : 2014-09-02
  -- PURPOSE : 运费/保险费结算支付（EMS）
  ----------------------------------------------------------------------
  PROCEDURE P_CHARGES_PAYMENT_OLD(I_FREIGHT_BATCH_ID IN NUMBER, --运费/保险费结算批ID
                                  I_ACCOUNT          IN VARCHAR2, --登录账号
                                  O_RESULT           OUT VARCHAR2, --返回错误码
                                  O_RESULT_MSG       OUT VARCHAR2 --返回错误信息
                                  );
  ----------------------------------------------------------------------
  -- AUTHOR  : XUQF
  -- CREATED : 2014-09-12
  -- PURPOSE : 运费/保险费结算支付（EMS）
  ----------------------------------------------------------------------
  PROCEDURE P_CHARGES_PAYMENT(I_FREIGHT_BATCH_ID IN NUMBER, --运费/保险费结算批ID
                              I_ACCOUNT          IN VARCHAR2, --登录账号
                              O_RESULT           OUT VARCHAR2, --返回错误码
                              O_RESULT_MSG       OUT VARCHAR2 --返回错误信息
                              );

  ----------------------------------------------------------------------
  -- AUTHOR  : XUQF
  -- CREATED : 2014-09-03
  -- PURPOSE : 中转装卸费结算支付（EMS）
  ----------------------------------------------------------------------
  PROCEDURE P_INTMED_LOAD_PAYMENT_OLD(I_INTMED_LOAD_BATCH_ID IN NUMBER, --中转装卸费结算批ID
                                      I_ACCOUNT              IN VARCHAR2, --登录账号
                                      O_RESULT               OUT VARCHAR2, --返回错误码
                                      O_RESULT_MSG           OUT VARCHAR2 --返回错误信息
                                      );

  ----------------------------------------------------------------------
  -- AUTHOR  : XUQF
  -- CREATED : 2014-09-13
  -- PURPOSE : 中转装卸费结算支付（EMS）
  ----------------------------------------------------------------------
  PROCEDURE P_INTMED_LOAD_PAYMENT(I_INTMED_LOAD_BATCH_ID IN NUMBER, --中转装卸费结算批ID
                                  I_ACCOUNT              IN VARCHAR2, --登录账号
                                  O_RESULT               OUT VARCHAR2, --返回错误码
                                  O_RESULT_MSG           OUT VARCHAR2 --返回错误信息
                                  );

  ----------------------------------------------------------------------
  -- AUTHOR  : XUQF
  -- CREATED : 2014-09-04
  -- PURPOSE : 仓储费结算支付（EMS）
  ----------------------------------------------------------------------
  PROCEDURE P_INV_ACCOUNT_PAYMENT_OLD(I_INV_ACCOUNT_ID IN NUMBER, --仓储费结算批ID
                                      I_ACCOUNT        IN VARCHAR2, --登录账号
                                      O_RESULT         OUT VARCHAR2, --返回错误码
                                      O_RESULT_MSG     OUT VARCHAR2 --返回错误信息
                                      );

  ----------------------------------------------------------------------
  -- AUTHOR  : XUQF
  -- CREATED : 2014-09-13
  -- PURPOSE : 仓储费结算支付（EMS）
  ----------------------------------------------------------------------
  PROCEDURE P_INV_ACCOUNT_PAYMENT(I_INV_ACCOUNT_ID IN NUMBER, --仓储费结算批ID
                                  I_ACCOUNT        IN VARCHAR2, --登录账号
                                  O_RESULT         OUT VARCHAR2, --返回错误码
                                  O_RESULT_MSG     OUT VARCHAR2 --返回错误信息
                                  );

  ----------------------------------------------------------------------
  -- AUTHOR  : XUQF
  -- CREATED : 2014-11-04
  -- PURPOSE : 获取运费/保险费EMS接口处理结果
  ----------------------------------------------------------------------
  PROCEDURE P_CHARGES_STATUS(O_RESULT     OUT VARCHAR2, --返回错误码
                             O_RESULT_MSG OUT VARCHAR2 --返回错误信息
                             );

  ----------------------------------------------------------------------
  -- AUTHOR  : XUQF
  -- CREATED : 2014-11-04
  -- PURPOSE : 获取运费/保险费结算批支付结果
  ----------------------------------------------------------------------
  PROCEDURE P_CHARGES_PAYMENT_RESULT(O_RESULT     OUT VARCHAR2, --返回错误码
                                     O_RESULT_MSG OUT VARCHAR2 --返回错误信息
                                     );

  ----------------------------------------------------------------------
  -- AUTHOR  : XUQF
  -- CREATED : 2015-03-14
  -- PURPOSE : 获取运费转到款结果（不包括保险费）
  ----------------------------------------------------------------------
  PROCEDURE P_CHARGES_BUCKLES_RESULT(O_RESULT     OUT VARCHAR2, --返回错误码
                                     O_RESULT_MSG OUT VARCHAR2 --返回错误信息
                                     );

  ----------------------------------------------------------------------
  -- AUTHOR  : XUQF
  -- CREATED : 2014-11-05
  -- PURPOSE : 获取中转费费EMS接口处理结果
  ----------------------------------------------------------------------
  PROCEDURE P_INTMED_LOAD_STATUS(O_RESULT     OUT VARCHAR2, --返回错误码
                                 O_RESULT_MSG OUT VARCHAR2 --返回错误信息
                                 );

  ----------------------------------------------------------------------
  -- AUTHOR  : XUQF
  -- CREATED : 2014-11-05
  -- PURPOSE : 获取中转费结算批支付结果
  ----------------------------------------------------------------------
  PROCEDURE P_INTMED_LOAD_PAYMENT_RESULT(O_RESULT     OUT VARCHAR2, --返回错误码
                                         O_RESULT_MSG OUT VARCHAR2 --返回错误信息
                                         );

  ----------------------------------------------------------------------
  -- AUTHOR  : XUQF
  -- CREATED : 2014-11-24
  -- PURPOSE : 获取中转费转到款结果
  ----------------------------------------------------------------------
  PROCEDURE P_TRANSIT_BUCKLES_RESULT(O_RESULT     OUT VARCHAR2, --返回错误码
                                     O_RESULT_MSG OUT VARCHAR2 --返回错误信息
                                     );

  ----------------------------------------------------------------------
  -- AUTHOR  : XUQF
  -- CREATED : 2014-11-04
  -- PURPOSE : 获取仓储费EMS接口处理结果
  ----------------------------------------------------------------------
  PROCEDURE P_INV_ACCOUNT_STATUS(O_RESULT     OUT VARCHAR2, --返回错误码
                                 O_RESULT_MSG OUT VARCHAR2 --返回错误信息
                                 );

  ----------------------------------------------------------------------
  -- AUTHOR  : XUQF
  -- CREATED : 2014-11-04
  -- PURPOSE : 获取仓储费结算批支付结果
  ----------------------------------------------------------------------
  PROCEDURE P_INV_ACCOUNT_PAYMENT_RESULT(O_RESULT     OUT VARCHAR2, --返回错误码
                                         O_RESULT_MSG OUT VARCHAR2 --返回错误信息
                                         );

  ----------------------------------------------------------------------
  -- AUTHOR  : XUQF
  -- CREATED : 2014-11-24
  -- PURPOSE : 获取仓储费转到款结果
  ----------------------------------------------------------------------
  PROCEDURE P_INV_ACCOUNT_BUCKLES_RESULT(O_RESULT     OUT VARCHAR2, --返回错误码
                                         O_RESULT_MSG OUT VARCHAR2 --返回错误信息
                                         );

  ----------------------------------------------------------------------
  -- AUTHOR  : XUQF
  -- CREATED : 2014-09-20
  -- PURPOSE : 计算中转费
  ----------------------------------------------------------------------
  PROCEDURE P_CALCULATE_INTMED_LOAD_OLD(I_PO_ID             IN NUMBER, --采购单据ID
                                        I_CHARGES_TYPE_CODE IN VARCHAR2, --费用类型编码
                                        I_OPER_NAME         IN VARCHAR2, --登录账号
                                        I_ENTITY_ID         IN NUMBER, --主体
                                        O_RESULT            OUT VARCHAR2,
                                        O_RESULT_MSG        OUT VARCHAR2);

  ----------------------------------------------------------------------
  -- AUTHOR  : XUQF
  -- CREATED : 2014-10-22
  -- PURPOSE : 计算中转费
  ----------------------------------------------------------------------
  PROCEDURE P_CALCULATE_INTMED_LOAD(I_BATCH_NUM  IN VARCHAR2, --批号（中转费、下线装卸费、出入库装卸费）
                                    I_OPER_NAME  IN VARCHAR2, --登录账号
                                    I_ENTITY_ID  IN NUMBER, --主体
                                    O_RESULT     OUT VARCHAR2,
                                    O_RESULT_MSG OUT VARCHAR2);

END PKG_LG_CHARGES;
/

