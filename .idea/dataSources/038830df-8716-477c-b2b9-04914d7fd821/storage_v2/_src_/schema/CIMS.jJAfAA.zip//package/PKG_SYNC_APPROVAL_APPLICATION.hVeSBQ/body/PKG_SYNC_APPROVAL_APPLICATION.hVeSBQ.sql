create PACKAGE BODY PKG_SYNC_APPROVAL_APPLICATION IS

  PROCEDURE P_SYNC_APPLICATION(P_DISCOUNT_ID IN NUMBER,    --返利单ID
                               P_USER_ID     IN NUMBER,    --用户ID
                               P_MESSAGE     OUT VARCHAR2  --成功返回OK
  ) IS
    V_SOURCE_ORDER_URL              VARCHAR2(200);         --来源URL
    L_APPLY_LADP_CODE               VARCHAR2(128);         --申请人LDAP编码

    FEE_APPLY_CODE                  VARCHAR2(128);         --正式批文单号（F单）
    V_ENTITY_ID                     NUMBER;                --主体ID
    L_SOURCE_ORDER_CODE             VARCHAR2(200);         --来源单据编码
    L_SOURCE_ORDER_TYPE             VARCHAR2(128);         --来源单据类型
    L_SOURCE_ORDER_LINE_ID          VARCHAR2(64);          --来源单据行ID
    L_APPLY_AMOUNT                  NUMBER;                --申请金额
    
    DISCOUNT_METHOD                 VARCHAR2(128);         --折让方式
    L_ATTRIBUTE11                   VARCHAR2(2);           --是否转到款
    V_TAX_RATE                      NUMBER;                --费用转到款税率
    L_VENDOR_ID                     NUMBER;                --供应商ID
    L_VENDOR_SITE_ID                NUMBER;                --供应商地点ID
    L_COMPANY_ID                    NUMBER;                --公司ID
    P_BUDGET_NODE_ID                NUMBER;                --预算单元ID
    P_BUDGET_TREE_ID                NUMBER;                --预算树ID
    BUSIORGID                       NUMBER;                --预算组织ID
    L_REASON_DESC                   VARCHAR2(800);         --申请事由
    
    --APPLY_CREATED_FLAG            VARCHAR2(2);           --是否已生成EMS正式单据
    --FEE_ADVANCE_DATE              DATE;                  --预计发生时间
    
    FEE_TYPE_ID                     NUMBER;                --费用类型ID
    EMS_IO_EA_APPLY_H_ID            NUMBER;                --EA单主表ID
    
    V_POL_DISCOUNT_ORDER T_POL_DISCOUNT_ORDER%ROWTYPE;
    V_POL_DISCOUNT_LINE T_POL_DISCOUNT_LINES%ROWTYPE;
  BEGIN  
    P_MESSAGE := 'OK';
    
    --来源URL
    BEGIN
      PKG_BD.P_GET_PARAMETER_VALUE('CIMS_SOURCE_URL',
                                   V_ENTITY_ID,
                                   NULL,
                                   NULL,
                                   V_SOURCE_ORDER_URL);
    EXCEPTION
      WHEN OTHERS THEN
        P_MESSAGE := '获取来源URL失败！';
    END;
      
    --取LDAP编码
    BEGIN
      SELECT TSU.ACCOUNT
        INTO L_APPLY_LADP_CODE
        FROM UP_ORG_USER TSU
       WHERE TSU.USER_ID = P_USER_ID;
    EXCEPTION
      WHEN OTHERS THEN
        P_MESSAGE := '获取LDAP账号失败！';
    END;  
  
    --获取返利单头
    BEGIN
      SELECT *
        INTO V_POL_DISCOUNT_ORDER
        FROM T_POL_DISCOUNT_ORDER T
       WHERE T.DISCOUNT_ORDER_ID = P_DISCOUNT_ID;
    EXCEPTION
      WHEN OTHERS THEN
        P_MESSAGE := '获取返利单信息失败！';
    END;
    
    --申请金额，来源单据行ID
    BEGIN
      SELECT NVL(DI.AMOUNT, 0), DI.LINE_ID
        INTO L_APPLY_AMOUNT, L_SOURCE_ORDER_LINE_ID
        FROM T_POL_DISCOUNT_LINES DI
       WHERE DI.DISCOUNT_ORDER_ID = P_DISCOUNT_ID;
    EXCEPTION
      WHEN OTHERS THEN
        P_MESSAGE := '获取返利行明细失败！';
    END;
    
    IF P_MESSAGE = 'OK' THEN
      --正式批文单号
      FEE_APPLY_CODE := V_POL_DISCOUNT_ORDER.DISCOUNT_ORDER_NUMBER;
      V_ENTITY_ID := V_POL_DISCOUNT_ORDER.ENTITY_ID;
      
      V_SOURCE_ORDER_URL := V_SOURCE_ORDER_URL || FEE_APPLY_CODE;
      
      --来源类型
      L_SOURCE_ORDER_TYPE := V_POL_DISCOUNT_ORDER.ORDER_TYPE_ID;
      L_SOURCE_ORDER_CODE := V_POL_DISCOUNT_ORDER.DISCOUNT_ORDER_NUMBER;
      
      --是否转到款
      DISCOUNT_METHOD := V_POL_DISCOUNT_ORDER.DISCOUNT_METHOD;
      L_ATTRIBUTE11 := V_POL_DISCOUNT_ORDER.ATTRIBUT11;
      IF ('2' = DISCOUNT_METHOD AND 'Y' = L_ATTRIBUTE11) THEN
        L_VENDOR_ID := V_POL_DISCOUNT_ORDER.VENDOR_ID;
        L_VENDOR_SITE_ID := V_POL_DISCOUNT_ORDER.VENDOR_SITE_ID;
        L_COMPANY_ID := V_POL_DISCOUNT_ORDER.COMPANY_ID;
      END IF;
     
      --申请事由
      IF V_POL_DISCOUNT_ORDER.REMARK IS NULL OR V_POL_DISCOUNT_ORDER.REMARK = '' THEN
        L_REASON_DESC := '政策转费用';
      ELSE
        SELECT '政策转费用：' || SUBSTR(V_POL_DISCOUNT_ORDER.REMARK, 0, 260)
          INTO L_REASON_DESC
          FROM DUAL;
      END IF;
      
      --税率，EA单申请金额
      V_TAX_RATE := V_POL_DISCOUNT_ORDER.TAX_RATE;
      IF V_TAX_RATE IS NULL THEN
        V_TAX_RATE := 0;
      END IF;
      IF V_TAX_RATE <= 0 THEN
        P_MESSAGE := '税额不能为0或者负数！';
      ELSE
        L_APPLY_AMOUNT := ROUND(L_APPLY_AMOUNT / V_TAX_RATE, 2);
      END IF;
       
      --主表ID、序列
      SELECT EMS_IO_EA_APPLY_H_S.NEXTVAL INTO EMS_IO_EA_APPLY_H_ID FROM DUAL;
    END IF;
          
    --插入EMS接口表 EMS_IO_EA_APPLY_H
    IF P_MESSAGE = 'OK' THEN
      INSERT INTO EMS_IO_EA_APPLY_H(
        IO_EA_APPLY_H_ID,
        FEE_APPLY_ID,
        FEE_APPLY_CODE,
        APPLY_LDAP_CODE,   
        APPLY_DATE,               
        APPLY_AMOUNT,            
        CURRENCY_CODE,
        REASON_DESC,              
        ORDER_TYPE,
        APPLY_CREATED_FLAG,     
        DISABLED_FLAG,
        CREATED_LDAP_CODE,
        LAST_UPDATED_LDAP_CODE,
        CREATION_DATE,
        LAST_UPDATE_DATE,
        SOURCE_SYSTEM,
        SOURCE_ORDER_TYPE,
        SOURCE_ORDER_ID,
        SOURCE_ORDER_CODE,
        ATTRIBUTE11,
        VENDOR_ID,
        VENDOR_SITE_ID,
        COMPANY_ID,
        SOURCE_ORDER_URL)
      VALUES(
        EMS_IO_EA_APPLY_H_ID,
        NULL,
        FEE_APPLY_CODE,              --正式批文单号
        L_APPLY_LADP_CODE,           --申请人LDAP编码
        SYSDATE,                     --申请日期
        L_APPLY_AMOUNT,              --申请金额
        'CNY',                       --币种
        L_REASON_DESC,               --事由
        'TY',                        --单据类型
        'N',                         --是否已生成EMS正式单据
        'N',                         --是否已作废
        L_APPLY_LADP_CODE,           --创建人LDAP编码
        L_APPLY_LADP_CODE,           --最后更新人LDAP编码
        SYSDATE,                     --创建日期
        SYSDATE,                     --最后更新日期
        'CIMS',                      --来源系统
        L_SOURCE_ORDER_TYPE,         --来源类型
        P_DISCOUNT_ID,               --来源单据ID
        L_SOURCE_ORDER_CODE,         --来源单据编码
        L_ATTRIBUTE11,               --是否转到款
        L_VENDOR_ID,                 --供应商ID
        L_VENDOR_SITE_ID,            --供应商地点ID
        L_COMPANY_ID,                --公司ID
        V_SOURCE_ORDER_URL           --来源URL
      );    
    END IF;
    
    --预算单元ID
    IF P_MESSAGE = 'OK' THEN
      P_QUERY_BUDGET_NODE_ID(P_DISCOUNT_ID, 
                             P_BUDGET_NODE_ID,
                             P_BUDGET_TREE_ID,
                             P_MESSAGE);
    END IF;                             

/*      
    --是否税金
    SELECT A.IS_TAX
      INTO IS_TAX
      FROM EMS_CIMS_FEE_TYPE_V A
     WHERE A.FEE_TYPE_ID = FEE_TYPE_ID;
       
    --是税金不写预算单元ID，不是税金不写费用类型、预算组织
    IF (IS_TAX = 'Y') THEN
      P_BUDGET_NODE_ID := NULL;
    ELSE
      FEE_TYPE_ID := NULL;
      BUSIORGID := NULL;
    END IF;                            
*/

    --插入EMS批文接口行表
    IF P_MESSAGE = 'OK' THEN
      INSERT INTO EMS_IO_EA_APPLY_L(
        IO_EA_APPLY_L_ID,
        IO_EA_APPLY_H_ID,
        CURRENCY_CODE,
        CONVERSION_RATE,
        FEE_TYPE_ID,
        BUSIORGID,
        BUDGET_AMOUNT,
        REASON_DESC,
        BUDGET_HEADERS_ID,
        BUDGET_NODE_ID,
        CREATED_LDAP_CODE,
        CREATION_DATE,
        LAST_UPDATED_LDAP_CODE,
        LAST_UPDATE_DATE,
        FEE_ADVANCE_DATE,
        SOURCE_SYSTEM,            
        SOURCE_ORDER_TYPE,       
        SOURCE_ORDER_ID,         
        SOURCE_ORDER_LINE_ID,
        SOURCE_ORDER_CODE        
      )VALUES(
        EMS_IO_EA_APPLY_L_S.NEXTVAL,        --接口批文行ID
        EMS_IO_EA_APPLY_H_ID,               --接口批文头ID
        'CNY',                              --币种
        '1',                                --汇率
        FEE_TYPE_ID,                        --费用类型ID
        BUSIORGID,                          --预算部门ID
        L_APPLY_AMOUNT,                     --申请金额
        L_REASON_DESC,                      --行事由
        P_BUDGET_TREE_ID,                   --预算树ID
        P_BUDGET_NODE_ID,                   --预算单元ID
        L_APPLY_LADP_CODE,                  --创建人LDAP编码
        SYSDATE,                            --创建时间
        L_APPLY_LADP_CODE,                  --最后更新人LDAP
        SYSDATE,                            --最后更新时间
        SYSDATE,                            --预计发生日期
        'CIMS',                             --来源系统
        L_SOURCE_ORDER_TYPE,                --来源类型
        P_DISCOUNT_ID,                      --来源单据ID
        L_SOURCE_ORDER_LINE_ID,             --来源单据行ID
        L_SOURCE_ORDER_CODE                 --来源单据编码
      );
    END IF;
       
  EXCEPTION
    WHEN OTHERS THEN
      BEGIN
        ROLLBACK;
        P_MESSAGE := SQLCODE || '     ' || SQLERRM;
        --记录出错信息
        P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_SYNC_APPROVAL_APPLICATION.P_SYNC_APPLICATION',
                                            SQLCODE,
                                            '批文申请同步失败：' || SQLERRM);
        COMMIT;
      END;
  END;
    
  --获取预算单元ID
  PROCEDURE P_QUERY_BUDGET_NODE_ID(P_DISCOUNT_ID    IN NUMBER,  --返利单ID
                                   P_BUDGET_NODE_ID OUT NUMBER, --预算单元ID
                                   P_BUDGET_TREE_ID OUT NUMBER, --预算树ID
                                   P_MESSAGE        OUT VARCHAR2  
  ) IS
      V_FEE_MAIN_TYPE_ID            NUMBER;  --费用大类ID
      V_FEE_DETAIL_TYPE_ID          NUMBER;  --费用小类ID
      V_BUSIORGID                   NUMBER;  --预算组织ID
      V_ENTITY_ID                   NUMBER;  --主体ID
      V_SALES_CENTER_ID             NUMBER;  --营销中心ID
      V_SALES_ENTITY_FLAG           VARCHAR2(2);   --是否销司主体标识
      V_EMS_DATA_FLOW_ID            VARCHAR2(100);  --EMS预算ID                                     
  BEGIN
    P_MESSAGE := 'OK';    
           
    SELECT A.FEE_MAIN_TYPE
          ,A.FEE_DETAIL_TYPE
          ,A.BUSIORGID
          ,A.ENTITY_ID
          ,A.SALES_CENTER_ID
      INTO V_FEE_MAIN_TYPE_ID
          ,V_FEE_DETAIL_TYPE_ID
          ,V_BUSIORGID
          ,V_ENTITY_ID
          ,V_SALES_CENTER_ID
      FROM T_POL_DISCOUNT_ORDER A
     WHERE A.DISCOUNT_ORDER_ID = P_DISCOUNT_ID;
    
    --获取是否销司主体系统参数 
    PKG_BD.P_GET_PARAMETER_VALUE('sales_entity_flag',
                                 V_ENTITY_ID,
                                 NULL,
                                 NULL,
                                 V_SALES_ENTITY_FLAG);
    
    IF (V_SALES_ENTITY_FLAG = 'Y') THEN
      PKG_BD.P_GET_PARAMETER_VALUE('DISCOUNT_MAIN_TYPE',
                                   V_ENTITY_ID,
                                   V_SALES_CENTER_ID,
                                   NULL,
                                   V_EMS_DATA_FLOW_ID);
    ELSE
      PKG_BD.P_GET_PARAMETER_VALUE('DISCOUNT_MAIN_TYPE',
                                   V_ENTITY_ID,
                                   NULL,
                                   NULL,
                                   V_EMS_DATA_FLOW_ID);
    END IF;
            
    SELECT A.BUDGET_HEADERS_ID, A.BUDGET_NODE_ID
      INTO P_BUDGET_TREE_ID, P_BUDGET_NODE_ID
      FROM EMS_CIMS_BUDGET_NODE_V A
     WHERE A.FEE_MAN_TYPE_ID = V_FEE_MAIN_TYPE_ID
       AND A.FEE_DETAIL_TYPE_ID = V_FEE_DETAIL_TYPE_ID
       AND (A.FEE_TYPE_SMALL_ID = V_FEE_MAIN_TYPE_ID OR
           A.FEE_TYPE_SMALL_ID = -1)
       AND A.BUSIORGID = V_BUSIORGID
       AND A.BUDGET_HEADERS_ID = TO_NUMBER(V_EMS_DATA_FLOW_ID)
       AND ROWNUM = 1;
  EXCEPTION
    WHEN OTHERS THEN
      P_MESSAGE := SQLCODE || '   ' || SQLERRM ;
  END;
       
  --EMS正式单据写财务接口
  PROCEDURE P_GET_EMS_ORDERINFO(P_MESSAGE OUT VARCHAR2) IS
    P_RECEIPT_METHOD_ID  NUMBER; --收款方法ID
    P_ACCOUNT_ID  NUMBER; --账户ID
    P_REIM_AMOUNT NUMBER; --报销金额
    P_REMAEK VARCHAR2(100); --备注
    P_ENTITY_ID NUMBER; --主体ID
    P_FEE_REIM_ID VARCHAR2(30); --费用ID
    P_FEE_APPLY_ID VARCHAR2(30); --批文ID，取EMS视图FEE_APPLY_ID
    P_SALES_MAIN_TYPE_CODE_LINES VARCHAR2(30); --营销大类编码
    P_REIM_AMOUNT_LINES VARCHAR2(30); --报销金额
    P_CUSTOMER_CODE  VARCHAR2(100); --客户编码
    P_SALES_CENTER_CODE VARCHAR2(100); --营销中心编码
    
    N_DAYS NUMBER; --间隔天数
               
    CURSOR F_ORDER_NUMBER_LIST IS
      SELECT *
        FROM CIMS.T_POL_DISCOUNT_ORDER T
       WHERE T.ATTRIBUT11 = 'Y' --转到款
         AND T.EMS_FLAG = 'N' --未同步过EMS
         AND T.STATUS = '9' --已确认状态
         AND T.ORDERED_DATE >= (TRUNC(SYSDATE) - N_DAYS) --取最近 N_DAYS 天的数据
      ;
                      
    ORDER_INFO F_ORDER_NUMBER_LIST%ROWTYPE;                                              
  BEGIN
    P_MESSAGE := 'OK';
    
    BEGIN
      SELECT NVL(PL.DEFAULT_VALUE, 90)
        INTO N_DAYS
        FROM T_BD_PARAM_LIST PL
       WHERE PL.PARAM_CODE = 'EMS_TO_CASH_INTERVAL_DAYS'
         AND PL.ACTIVE_FLAG = 'Y'
         AND NVL(PL.ENTITY_FLAG, 'N') = 'N';
    EXCEPTION
      WHEN OTHERS THEN
        N_DAYS := 90;
    END;
               
    OPEN F_ORDER_NUMBER_LIST;
    LOOP                 
      FETCH F_ORDER_NUMBER_LIST 
       INTO ORDER_INFO;
      
      EXIT WHEN F_ORDER_NUMBER_LIST%NOTFOUND;
                   
      P_ENTITY_ID :=  ORDER_INFO.ENTITY_ID;
      P_CUSTOMER_CODE := ORDER_INFO.CUSTOMER_CODE;
      P_SALES_CENTER_CODE := ORDER_INFO.SALES_CENTER_CODE;
                   
      --营销大类编码
      P_SALES_MAIN_TYPE_CODE_LINES := ORDER_INFO.SALES_MAIN_TYPE;                             
                   
      --收款方法
      SELECT T.RECEIPT_METHOD_ID
        INTO P_RECEIPT_METHOD_ID
        FROM T_AR_RECEIPT_METHODS T
       WHERE T.RECEIPT_METHOD_NAME LIKE '%返利转到款%'
         AND T.ENTITY_ID = P_ENTITY_ID;
                       
      --账户
      BEGIN
        SELECT DISTINCT (T.ACCOUNT_ID)
          INTO P_ACCOUNT_ID
          FROM V_CUST_ACCOUNT T
         WHERE T.CUSTOMER_CODE = P_CUSTOMER_CODE
           AND T.SALES_CENTER_CODE = P_SALES_CENTER_CODE
           AND ROWNUM = 1;
      EXCEPTION
        WHEN OTHERS THEN
          BEGIN
            --记录出错信息
            P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_SYNC_APPROVAL_APPLICATION.P_GET_EMS_ORDERINFO',
                                                SQLCODE,
                                                '根据客户[' || P_CUSTOMER_CODE ||']+中心[' || P_SALES_CENTER_CODE ||']获取账户信息异常：' || SQLERRM);
            COMMIT;
            GOTO HEADER;
          END;
      END;
                                    
      --批文ID
      BEGIN
        SELECT T.FEE_APPLY_ID, T.APPLY_AMOUNT
          INTO P_FEE_APPLY_ID, P_REIM_AMOUNT_LINES
          FROM EMS_CIMS_EA_APPLY_H_V T
         WHERE T.SOURCE_SYSTEM = 'CIMS'
           AND T.SOURCE_ORDER_ID = ORDER_INFO.DISCOUNT_ORDER_ID
           AND T.ORDER_STATUS = 'AUDITED'
           AND T.BIZ_STATUS = 'PAIED';
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          GOTO HEADER;
      END;
                   
      P_REIM_AMOUNT := P_REIM_AMOUNT_LINES;
                   
      --写费用信息
      PKG_AR.P_FEETURNFEE_LG_POL(P_RECEIPT_METHOD_ID,       --收款方法
                                 P_ACCOUNT_ID,              --账户ID
                                 P_REIM_AMOUNT,             --报销金额
                                 P_REMAEK,                  --备注
                                 P_ENTITY_ID,               --主体ID
                                 P_FEE_REIM_ID,             --报销ID
                                 P_FEE_APPLY_ID,            --批文ID
                                 ORDER_INFO.DISCOUNT_ORDER_ID,  --来源ID
                                 P_SALES_MAIN_TYPE_CODE_LINES,  --营销大类编码
                                 P_REIM_AMOUNT_LINES,           --报销金额
                                 P_MESSAGE);     
                                              
      --更新返利单表，写费用状态更新为Y
      UPDATE T_POL_DISCOUNT_ORDER T
         SET T.EMS_FLAG     = 'Y'
            ,T.EMS_APPLY_ID = P_FEE_APPLY_ID
            ,T.VERSION      = NVL(T.VERSION, 0) + 1
       WHERE T.DISCOUNT_ORDER_ID = ORDER_INFO.DISCOUNT_ORDER_ID;
                   
      <<HEADER>>
      NULL;
    END LOOP;
    CLOSE F_ORDER_NUMBER_LIST;
  
    
    --推广物料验收单费用转到款 
    P_GET_EMS_ACCOUNT_ORDERINFO(P_MESSAGE);

    --价差(费用)兑现转到款
    P_GET_EMS_MID_FEE_ORDERINFO(P_MESSAGE);                             
  END;        
  
  --推广物料验收单费用转到款
  -- AUTHOR  : tangjz2
  -- CREATED : 2019/9/23
  PROCEDURE P_GET_EMS_ACCOUNT_ORDERINFO(P_MESSAGE OUT VARCHAR2) IS
    P_RECEIPT_METHOD_ID  NUMBER; --收款方法ID
    P_ACCOUNT_ID  NUMBER; --账户ID
    P_REIM_AMOUNT NUMBER; --报销金额
    P_REMAEK VARCHAR2(100); --备注
    P_ENTITY_ID NUMBER; --主体ID
    P_FEE_REIM_ID VARCHAR2(30); --费用ID
    P_FEE_APPLY_ID VARCHAR2(30); --批文ID，取EMS视图FEE_APPLY_ID
    P_SALES_MAIN_TYPE_CODE_LINES VARCHAR2(30); --营销大类编码
    P_REIM_AMOUNT_LINES VARCHAR2(30); --报销金额
    P_CUSTOMER_CODE  VARCHAR2(100); --客户编码
    P_SALES_CENTER_CODE VARCHAR2(100); --营销中心编码
    p_ec_pay_count number;--EC单是否支付
    
    N_DAYS NUMBER; --间隔天数
               
    CURSOR F_ORDER_NUMBER_LIST IS
      SELECT *
        FROM T_PMT_ACCOUNT_HEAD T
       WHERE T.Is_Transfer_Amount = 'Y' --需要转到款
         AND nvl(T.IS_TRANSFER_FINISHED,'N') = 'N' --未完成转到款
         AND T.STATUS = '07' --已结算状态
        -- AND T.Last_Updated_Date >= (TRUNC(SYSDATE) - N_DAYS) --取最近 N_DAYS 天的数据
      ;
                      
    ORDER_INFO F_ORDER_NUMBER_LIST%ROWTYPE;                                              
  BEGIN
    P_MESSAGE := 'OK';
    
    BEGIN
      SELECT NVL(PL.DEFAULT_VALUE, 90)
        INTO N_DAYS
        FROM T_BD_PARAM_LIST PL
       WHERE PL.PARAM_CODE = 'EMS_TO_CASH_INTERVAL_DAYS'
         AND PL.ACTIVE_FLAG = 'Y'
         AND NVL(PL.ENTITY_FLAG, 'N') = 'N';
    EXCEPTION
      WHEN OTHERS THEN
        N_DAYS := 90;
    END;
               
    OPEN F_ORDER_NUMBER_LIST;
    LOOP                 
      FETCH F_ORDER_NUMBER_LIST 
       INTO ORDER_INFO;
      
      EXIT WHEN F_ORDER_NUMBER_LIST%NOTFOUND;

      SELECT count(*) into p_ec_pay_count FROM EMS_CIMS_EC_FEE_REIM T WHERE T.SOURCE_ORDER_CODE = ORDER_INFO.ACCOUNT_NUM 
                                 AND T.SOURCE_ORDER_ID = ORDER_INFO.ACCOUNT_HEAD_ID
                                 AND T.SOURCE_SYSTEM = 'CIMS' and T.BIZ_STATUS = 'PAID' and T.ORDER_STATUS = 'AUDITED'
                                 AND T.SOURCE_ORDER_TYPE in ('10', '20');
      
      
      if p_ec_pay_count = 0 then
        goto HEADER;
      end if;
      
      SELECT T.FEE_REIM_ID into P_FEE_REIM_ID FROM EMS_CIMS_EC_FEE_REIM T WHERE T.SOURCE_ORDER_CODE = ORDER_INFO.ACCOUNT_NUM
                                 AND T.SOURCE_ORDER_ID = ORDER_INFO.ACCOUNT_HEAD_ID
                                 AND T.SOURCE_SYSTEM = 'CIMS' and T.BIZ_STATUS = 'PAID' and T.ORDER_STATUS = 'AUDITED'
                                 AND T.SOURCE_ORDER_TYPE in ('10', '20') and rownum = 1;
      
     
                   
      P_ENTITY_ID :=  ORDER_INFO.ENTITY_ID;
      P_CUSTOMER_CODE := ORDER_INFO.CUSTOMER_CODE;
      P_SALES_CENTER_CODE := ORDER_INFO.SALES_CENTER_CODE;
                   
      --营销大类编码
      P_SALES_MAIN_TYPE_CODE_LINES := ORDER_INFO.SALES_MAIN_TYPE;                             
                   
      --收款方法
      SELECT T.RECEIPT_METHOD_ID
        INTO P_RECEIPT_METHOD_ID
        FROM T_AR_RECEIPT_METHODS T
       WHERE T.RECEIPT_METHOD_NAME LIKE '%推广费用转到款%'
         AND T.ENTITY_ID = P_ENTITY_ID;
                       
      --账户
      BEGIN
        SELECT DISTINCT (T.ACCOUNT_ID)
          INTO P_ACCOUNT_ID
          FROM V_CUST_ACCOUNT T
         WHERE T.CUSTOMER_CODE = P_CUSTOMER_CODE
           AND T.SALES_CENTER_CODE = P_SALES_CENTER_CODE
           AND ROWNUM = 1;
      EXCEPTION
        WHEN OTHERS THEN
          BEGIN
            --记录出错信息
            P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_SYNC_APPROVAL_APPLICATION.P_GET_EMS_ACCOUNT_ORDERINFO',
                                                SQLCODE,
                                                '根据客户[' || P_CUSTOMER_CODE ||']+中心[' || P_SALES_CENTER_CODE ||']获取账户信息异常：' || SQLERRM);
            COMMIT;
            GOTO HEADER;
          END;
      END;
                                    
      --批文ID
     /* BEGIN
        SELECT T.FEE_APPLY_ID, T.APPLY_AMOUNT
          INTO P_FEE_APPLY_ID, P_REIM_AMOUNT_LINES
          FROM EMS_CIMS_EA_APPLY_H_V T
         WHERE T.SOURCE_SYSTEM = 'CIMS'
           AND T.SOURCE_ORDER_ID = ORDER_INFO.DISCOUNT_ORDER_ID
           AND T.ORDER_STATUS = 'AUDITED'
           AND T.BIZ_STATUS = 'PAIED';
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          GOTO HEADER;
      END;*/
      P_REIM_AMOUNT_LINES := ORDER_INFO.ACCOUNT_AMOUNT;
      P_REIM_AMOUNT := P_REIM_AMOUNT_LINES;
                   
      --写费用信息
      PKG_AR.P_FEETURNFEE_LG_POL(P_RECEIPT_METHOD_ID,       --收款方法
                                 P_ACCOUNT_ID,              --账户ID
                                 P_REIM_AMOUNT,             --报销金额
                                 P_REMAEK,                  --备注
                                 P_ENTITY_ID,               --主体ID
                                 P_FEE_REIM_ID,             --报销ID
                                 P_FEE_APPLY_ID,            --批文ID
                                 ORDER_INFO.ACCOUNT_HEAD_ID,  --来源ID
                                 P_SALES_MAIN_TYPE_CODE_LINES,  --营销大类编码
                                 P_REIM_AMOUNT_LINES,           --报销金额
                                 P_MESSAGE);     
                                              
      --更新验收单表，写已完成费用状态更新为Y
      UPDATE T_PMT_ACCOUNT_HEAD T
         SET T.IS_TRANSFER_FINISHED     = 'Y'
          --  ,T.EMS_APPLY_ID = P_FEE_APPLY_ID
          --  ,T.VERSION      = NVL(T.VERSION, 0) + 1
       WHERE T.ACCOUNT_HEAD_ID = ORDER_INFO.ACCOUNT_HEAD_ID;
                   
      <<HEADER>>
      NULL;
    END LOOP;
    CLOSE F_ORDER_NUMBER_LIST;
                                    
  END;

  --价差(费用)兑现转到款
  PROCEDURE P_GET_EMS_MID_FEE_ORDERINFO(P_MESSAGE OUT VARCHAR2) IS
    P_FEE_APPLY_ID VARCHAR2(30); --EA单ID
    P_FEE_REIM_ID VARCHAR2(30); --EC单ID
    P_REIM_AMOUNT NUMBER; --报销金额
    P_REIM_AMOUNT_LINES VARCHAR2(30); --报销金额
    P_ENTITY_ID NUMBER; --主体ID
    P_CUSTOMER_CODE  VARCHAR2(100); --客户编码
    P_SALES_CENTER_CODE VARCHAR2(100); --营销中心编码
    P_SALES_MAIN_TYPE_CODE VARCHAR2(30); --营销大类编码
    P_ACCOUNT_ID  NUMBER; --账户ID
    P_RECEIPT_METHOD_ID  NUMBER; --收款方法ID
    P_REMAEK VARCHAR2(100); --备注
    P_EC_PAY_COUNT NUMBER; --EC单是否支付
    
    N_DAYS NUMBER; --间隔天数
               
    CURSOR F_ORDER_NUMBER_LIST IS
      SELECT *
        FROM T_POL_PG_MID_FEE_PAY T
       WHERE T.ATTRIBUT11 = 'Y' --需要转到款
         AND nvl(T.IS_TRANSFER_PAY_FINISHED,'N') = 'N' --未完成转到款
         AND T.STATUS = '07' --已结算状态
         AND T.ORDER_DATE >= (TRUNC(SYSDATE) - N_DAYS) --取最近 N_DAYS 天的数据
    ;
                      
    ORDER_INFO F_ORDER_NUMBER_LIST%ROWTYPE;                                              
  BEGIN
    P_MESSAGE := 'OK';
    
    BEGIN
      SELECT NVL(PL.DEFAULT_VALUE, 90)
        INTO N_DAYS
        FROM T_BD_PARAM_LIST PL
       WHERE PL.PARAM_CODE = 'EMS_TO_CASH_INTERVAL_DAYS'
         AND PL.ACTIVE_FLAG = 'Y'
         AND NVL(PL.ENTITY_FLAG, 'N') = 'N';
    EXCEPTION
      WHEN OTHERS THEN
        N_DAYS := 90;
    END;
               
    OPEN F_ORDER_NUMBER_LIST;
    LOOP                 
      FETCH F_ORDER_NUMBER_LIST 
       INTO ORDER_INFO;
      EXIT WHEN F_ORDER_NUMBER_LIST%NOTFOUND;

      SELECT COUNT(*)
        INTO P_EC_PAY_COUNT
        FROM EMS_CIMS_EC_FEE_REIM T
       WHERE T.SOURCE_SYSTEM = 'CIMS'
         AND T.SOURCE_ORDER_TYPE IN ('MID_FEE_PAY')
         AND T.SOURCE_ORDER_ID = ORDER_INFO.FEE_PAY_ID
         AND T.SOURCE_ORDER_CODE = ORDER_INFO.FEE_PAY_NUMBER
         AND T.BIZ_STATUS = 'PAID'
         AND T.ORDER_STATUS = 'AUDITED';
      
      IF P_EC_PAY_COUNT = 0 THEN
        GOTO HEADER;
      END IF;

      --EC单ID
      SELECT T.FEE_REIM_ID
        INTO P_FEE_REIM_ID
        FROM EMS_CIMS_EC_FEE_REIM T
       WHERE T.SOURCE_SYSTEM = 'CIMS'
         AND T.SOURCE_ORDER_TYPE IN ('MID_FEE_PAY')
         AND T.SOURCE_ORDER_ID = ORDER_INFO.FEE_PAY_ID
         AND T.SOURCE_ORDER_CODE = ORDER_INFO.FEE_PAY_NUMBER
         AND T.BIZ_STATUS = 'PAID'
         AND T.ORDER_STATUS = 'AUDITED'
         AND ROWNUM = 1
       ORDER BY T.FEE_REIM_ID DESC;
      
      P_REIM_AMOUNT := ORDER_INFO.PAY_AMOUNT;                          
      P_REIM_AMOUNT_LINES := P_REIM_AMOUNT;       
      P_ENTITY_ID :=  ORDER_INFO.ENTITY_ID;
      P_CUSTOMER_CODE := ORDER_INFO.CUSTOMER_CODE;
      P_SALES_CENTER_CODE := ORDER_INFO.SALES_CENTER_CODE;
      P_SALES_MAIN_TYPE_CODE := ORDER_INFO.SALES_MAIN_TYPE_CODE;
                       
      --账户
      BEGIN
        SELECT DISTINCT (T.ACCOUNT_ID)
          INTO P_ACCOUNT_ID
          FROM V_CUST_ACCOUNT T
         WHERE T.CUSTOMER_CODE = P_CUSTOMER_CODE
           AND T.SALES_CENTER_CODE = P_SALES_CENTER_CODE
           AND ROWNUM = 1;
      EXCEPTION
        WHEN OTHERS THEN
          BEGIN
            --记录出错信息
            P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_SYNC_APPROVAL_APPLICATION.P_GET_EMS_MID_FEE_ORDERINFO',
                                                SQLCODE,
                                                '根据客户[' || P_CUSTOMER_CODE ||']+中心[' || P_SALES_CENTER_CODE ||']获取账户信息异常：' || SQLERRM);
            COMMIT;
            GOTO HEADER;
          END;
      END;
      
      --收款方法
      SELECT T.RECEIPT_METHOD_ID
        INTO P_RECEIPT_METHOD_ID
        FROM T_AR_RECEIPT_METHODS T
       WHERE T.RECEIPT_METHOD_NAME LIKE '%安装维修费转到款%'
         AND T.ENTITY_ID = P_ENTITY_ID;
                   
      --写费用信息
      PKG_AR.P_FEETURNFEE_LG_POL(P_RECEIPT_METHOD_ID,    --收款方法
                                 P_ACCOUNT_ID,           --账户ID
                                 P_REIM_AMOUNT,          --报销金额
                                 P_REMAEK,               --备注
                                 P_ENTITY_ID,            --主体ID
                                 P_FEE_REIM_ID,          --报销ID
                                 P_FEE_APPLY_ID,         --批文ID
                                 ORDER_INFO.FEE_PAY_ID,  --来源ID
                                 P_SALES_MAIN_TYPE_CODE, --营销大类编码
                                 P_REIM_AMOUNT_LINES,    --报销金额
                                 P_MESSAGE);     
                                              
      --更新价差(费用)兑现单，是否完成转到款改为Y
      UPDATE T_POL_PG_MID_FEE_PAY T
         SET T.IS_TRANSFER_PAY_FINISHED = 'Y'
            ,T.VERSION                  = NVL(T.VERSION, 0) + 1
       WHERE T.FEE_PAY_ID = ORDER_INFO.FEE_PAY_ID;
                   
      <<HEADER>>
      NULL;
    END LOOP;
    CLOSE F_ORDER_NUMBER_LIST;
  END P_GET_EMS_MID_FEE_ORDERINFO;
    
END PKG_SYNC_APPROVAL_APPLICATION;
/

