create package PKG_CREDIT_SETTING is

  -- Author  : LIANGYM2
  -- Created : 2016/8/18 11:56:49
  -- Purpose :

  --------------------------------------------------------------------------------
  /*
  *   创建日期：2016-08-18
  *     创建者：梁颜明
  *   功能说明：信用额度初始化
  *   返回结果：1：成功，2：失败
  *
  */
  -------------------------------------------------------------------------------

  V_SUCCESS_MSG VARCHAR2(1000) := 'SUCCESS'; --成功返回信息

  /**
  * 信用额度初始化
  **/
  PROCEDURE P_CREDIT_AMOUNT_INIT(I_ENTITY_ID     IN NUMBER, --实体ID
                                 I_CHANGE_REASON IN VARCHAR2, --1:信用额度调整申请2:客户组变更3:信用额度初始化
                                 I_USER_ID       IN VARCHAR2, --操作人
                                 I_FLAG          IN VARCHAR2, -- 0 月初始化
                                 O_MSG           OUT VARCHAR2
                                 );

  /**
  *信用额度计算规则
  *以后考虑加这几个参数：I_CHANGE_REASON I_USER_ID I_FLAG I_COMMIT
  **/
  PROCEDURE P_CREDIT_AMOUNT_DESC(I_ENTITY_ID                    IN NUMBER, --实体ID
                                 I_CUSTOMER_ID                  IN NUMBER, --客户ID
                                 IN_ACCOUNT_ID                  IN NUMBER, --账户ID
                                 I_SALES_MAIN_TYPE_CODE         IN VARCHAR2, --营销大类编码
                                 O_MSG                          OUT VARCHAR2, --返回信息
                                 OS_CUSTOMER_ACTIVE_DATE        OUT VARCHAR2,--客户事业部合作生效日期
                                 ON_COOPERATE_DAYS              OUT NUMBER,--客户事业部合作天数
                                 OS_CREDIT_LEVEL_MSG            OUT VARCHAR2,--信用等级说明
                                 ON_TWELVE_AMOUNT               OUT NUMBER,--前十二个月销售收入
                                 ON_CREDIT_CALC_PERCENT         OUT NUMBER,--信用等级额度计算比例
                                 OS_CUS_CREDIT_LINE_MSG         OUT VARCHAR2,--信用等级额度计算说明
                                 ON_LAST_YEAR_PROPORTION        OUT NUMBER,--上年月均销售铺底比例
                                 ON_THIS_YEAR_PROPORTION        OUT NUMBER,--本年月均销售铺底比例
                                 OS_THIS_YEAR_PROP_MSG          OUT VARCHAR2,--本年月均销售铺底比例特殊情况说明
                                 ON_LAST_YEAR_CUST_AMOUNT       OUT NUMBER,--上年度销售收入
                                 ON_THIS_YEAR_MONTH_CUST_AMOUNT OUT NUMBER,--本年度销售收入
                                 OS_LAST_YEAR_CREDIT_LINE_MSG   OUT VARCHAR2,--上年度信用额度说明
                                 OS_THIS_YEAR_CREDIT_LINE_MSG   OUT VARCHAR2,--本年度信用额度说明
                                 ON_LAST_YEAR_CUST_AMOUNT_AVG   OUT NUMBER, --客户上一年度月均提货金额
                                 ON_THIS_YEAR_MM_AMOUNT_AVG     OUT NUMBER, --本年月月均销售金额
                                 ON_THIS_MONTH_DELAY_AMOUNT_AVG OUT NUMBER, --本年月均铺底
                                 --OS_TWELVE_AMOUNT_MSG           OUT VARCHAR2,--前十二个月
                                 OS_CAN_USE_AMOUNT_MSG          OUT VARCHAR2--可用额度说明
                                 );

  /**
  * 信用额度初始化
  **/
  PROCEDURE P_CREDIT_AMOUNT_INIT(I_ENTITY_ID            IN NUMBER, --实体ID
                                 I_CUSTOMER_ID          IN NUMBER, --客户ID
                                 I_SALES_MAIN_TYPE_CODE IN VARCHAR2, --营销大类编码
                                 I_CHANGE_REASON        IN VARCHAR2, --1:信用额度调整申请2:客户组变更3:信用额度初始化
                                 I_USER_ID              IN VARCHAR2, --操作人
                                 I_FLAG                 IN VARCHAR2, --
                                 I_COMMIT               IN NUMBER, --1、成功时数据库事务提交
                                 O_MSG                  OUT VARCHAR2, --返回信息
                                 IN_ACCOUNT_ID          IN NUMBER DEFAULT NULL --2017-5-2 增加账户ID参数，默认为空
                                 );

  /**
  * 信用额度初始化
  **/
  PROCEDURE P_CREDIT_AMOUNT_INIT(I_CREDIT_TERMS  IN V_CREDIT_TERMS%ROWTYPE, --客户信用额度记录
                                 I_CHANGE_REASON IN VARCHAR2, --1:信用额度调整申请2:客户组变更3:信用额度初始化
                                 I_USER_ID       IN VARCHAR2, --操作人
                                 I_FLAG          IN VARCHAR2, --
                                 I_COMMIT        IN NUMBER, --1、成功时数据库事务提交
                                 O_MSG           OUT VARCHAR2 --返回信息
                                 );

  /**
  * 信用额度客户信息初始化，重载，不传入营销大类，2017=04-24
  **/
  PROCEDURE P_CREDIT_CUSTOMER_INIT(IN_ENTITY_ID   IN NUMBER, --主体
                                   IN_CUSTOMER_ID IN NUMBER, --客户
                                   IN_ACCOUNT_ID  IN NUMBER, --账户
                                   OS_MSG         OUT VARCHAR2 --返回信息，初始化成功返回 V_SUCCESS_MSG
                                   );

  /**
  * 信用额度客户信息初始化，2017=04-24
  **/
  PROCEDURE P_CREDIT_CUSTOMER_INIT(IN_ENTITY_ID            IN NUMBER, --主体
                                   IN_CUSTOMER_ID          IN NUMBER, --客户
                                   IS_SALES_MAIN_TYPE_CODE IN VARCHAR2, --营销大类
                                   IN_ACCOUNT_ID           IN NUMBER, --账户
                                   OS_MSG                  OUT VARCHAR2 --返回信息，初始化成功返回 V_SUCCESS_MSG
                                   );

end PKG_CREDIT_SETTING;
/

