create Package Pkg_Pln_Capacity Is

  -- Author  : NICRO.LI
  -- Created : 2016-12-08 13:57:33
  -- Purpose : 订单管理

  -------------------------------------------------------------------------
  -- Author  : NICRO.LI
  -- Created : 2016-12-08 13:57:33
  -- Purpose : 获取提货订单对应订单周期所属月的周期ID
  -------------------------------------------------------------------------
  Function f_Get_Parameter_Month_Period(p_Entity_Id   In Number,
                                        p_Period_Type In Varchar2, --周期类型 W:周 M:月
                                        p_Date        In Date --日期
                                        ) Return Number;

  -----------------------------------------------------------------------------
  -- AUTHOR  : Nicro.Li
  -- CREATED : 2017-04-21
  -- PURPOSE : 根据产品、产地、周期获取提货订单本周期已占用数量
  -----------------------------------------------------------------------------
  Function f_Get_Lgorder_Occupy_Qty(p_Producing_Area_Id In Number, ----主体ID
                                    p_Item_Code         In Varchar2, --产品编码
                                    p_Entity_Id         In Number, --主体ID
                                    p_Period_Id         In Number --周期ID
                                    ) Return Number;

  -----------------------------------------------------------------------------
  -- AUTHOR  : Nicro.Li
  -- CREATED : 2017-04-21
  -- PURPOSE : 根据产品、产地、周期获取提货订单本周期已占用数量
  -----------------------------------------------------------------------------
  Function f_Get_Plnorder_Occupy_Qty(p_Producing_Area_Id In Number, ----主体ID
                                     p_Item_Code         In Varchar2, --产品编码
                                     p_Entity_Id         In Number, --主体ID
                                     p_Period_Id         In Number --周期ID
                                     ) Return Number;

  -----------------------------------------------------------------------------
  -- AUTHOR  : Nicro.Li
  -- CREATED : 2017-02-07
  -- PURPOSE : 根据产品、产地、周期获取CIMS剩余产能
  --            周期传入为空白时，根据日期取提货订单的提前周期参数
  -----------------------------------------------------------------------------
  Function f_Get_Item_Capacity_Qty(p_Producing_Area_Id In Number, ----主体ID
                                   p_Item_Code         In Varchar2, --产品编码
                                   p_Date              In Date, --提货订单日期
                                   p_Entity_Id         In Number, --主体ID
                                   p_Period_Id         In Number --周期ID
                                   ) Return Number;

  -----------------------------------------------------------------------------
  -- AUTHOR  : Nicro.Li
  -- CREATED : 2017-04-10
  -- PURPOSE : 根据产品、产地、周期获取CIMS剩余产能
  --            周期传入为空白时，根据日期取提货订单的提前周期参数
  -- RETURN : 返回数据时，表示计算正常，返回NULL表示程序出现异常
  -----------------------------------------------------------------------------
  Function f_Get_Item_Capacity_Qty_New(p_Producing_Area_Id In Number, ----主体ID
                                       p_Item_Code         In Varchar2, --产品编码
                                       p_Date              In Date, --提货订单日期
                                       p_Entity_Id         In Number, --主体ID
                                       p_Period_Id         In Number --周期ID
                                       ) Return Number;

  -------------------------------------------------------------------------
  -- Author  : NICRO.LI
  -- Created : 2016-12-08 13:57:33
  -- Purpose : 订单产能可视串行处理队列表数据插入
  -------------------------------------------------------------------------
  /*Procedure p_Create_Cs_Process(p_Order_Head_Id In Number, --传入提货订单头ID，计划订单头ID
                                p_Order_Type_Id In Number, --单据类型ID
                                p_User_Code     In Varchar2 --用户编码
                                );
  -------------------------------------------------------------------------
  -- Author  : NICRO.LI
  -- Created : 2016-12-16 13:57:33
  -- Purpose : 订单产能可视串行处理队列表数据插入
  -------------------------------------------------------------------------
  Procedure p_Update_Cs_Process(p_Order_Head_Id In Number, --传入提货订单头ID，计划订单头ID
                                p_Order_Type_Id In Number, --单据类型ID
                                p_Process_State In Varchar2,
                                p_User_Code     In Varchar2 --用户编码
                                );
                                */
  ------------------------------------------------------------------------------------------
  ---- AUTHOR  : Nicro.Li
  -- CREATED : 2016-12-13
  -- PURPOSE : 提货订单产能可视检查、产能不足时方法默认返回成功，但会同时返回产可视异常信息
  -- p_result返回说明：SUCCESS:成功，产能满足   
  ---                  FAILURE:失败，产能检查失败，不允许续继提交单据
  --                   WARNING:警告，产能检查失败，提示错误信息确认后允许续继提交订单
  ------------------------------------------------------------------------------------------
  Procedure p_Chk_Item_Capacity(p_Entity_Id        In Number, --主体ID
                                p_Order_Head_Id    In Number, --订单头ID
                                p_Order_Type_Id    In Number, --单据类型ID
                                p_Order_Check_Date In Date, --检查日期
                                p_User_Code        In Varchar2, ----用户ID
                                p_Result           In Out Varchar2, --成功则反回 SUCCESS 失败则返回失败原因
                                p_Chk_Msg          In Out Varchar2 --产能检查不通过时返回错误信息
                                );

  -------------------------------------------------------------------------
  -- Author  : NICRO.LI
  -- Created : 2017-04-21 13:57:33
  -- Purpose : 订单产能可视串行占用产能数据
  --           产能类型：W:按T+3周期计算产能且实时对比  M:按月计算剩余产能
  -------------------------------------------------------------------------
  Procedure p_Capacity_Occupy_New(p_Order_Head_Id    In Number, --传入提货订单头ID，计划订单头ID
                                  p_Order_Type_Id    In Number, --单据类型ID
                                  p_Order_Check_Date In Date, --订单送审日期
                                  p_Capacity_Sign    In Number, --占用标志：1：占用  -1：释放
                                  p_Capacity_Type    In Varchar2, --产能类型：W:按周  M:按月  
                                  p_User_Code        In Varchar2, --用户编码
                                  p_Result           Out Varchar2 --返回信息 SUCCESS:正常
                                  );

  -------------------------------------------------------------------------
  -- Author  : NICRO.LI
  -- Created : 2016-12-08 13:57:33
  -- Purpose : 订单产能可视串行占用产能数据
  -------------------------------------------------------------------------
  Procedure p_Capacity_Occupy(p_Order_Head_Id    In Number, --传入提货订单头ID，计划订单头ID
                              p_Order_Type_Id    In Number, --单据类型ID
                              p_Order_Check_Date In Date, --订单送审日期
                              p_Capacity_Sign    In Number, --占用标志：1：占用  -1：释放
                              p_User_Code        In Varchar2, --用户编码
                              p_Result           Out Varchar2 --返回信息 SUCCESS:正常
                              );

  -------------------------------------------------------------------------
  -- Author  : NICRO.LI
  -- Created : 2016-12-08 13:57:33
  -- Purpose : 订单产能可视每晚重算
  -------------------------------------------------------------------------
  Procedure p_Cpacity_Recompute(p_Entity_Id       In Number,
                                p_Recomputer_Date In Date --重算日期
                                );

End Pkg_Pln_Capacity;
/

