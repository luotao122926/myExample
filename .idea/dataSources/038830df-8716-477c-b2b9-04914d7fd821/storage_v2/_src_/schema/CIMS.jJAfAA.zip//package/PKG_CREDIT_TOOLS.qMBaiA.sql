create package      PKG_CREDIT_TOOLS is

  -- Author  : SUDONGYUAN
  -- Created : 2014/7/31 2:13:49
  -- Purpose :

  --------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-30
  *     创建者：苏冬渊
  *   功能说明：检查额度组保存时候，营销大类是否重复的校验
  *   返回结果：1：成功，2：失败
  *
  */
  -------------------------------------------------------------------------------
  --TYPE STR_LIST IS TABLE OF VARCHAR2(100) INDEX BY BINARY_INTEGER;
  TYPE STR_LIST IS TABLE OF VARCHAR2(255);
  --FUNCTION FUN_SPLIT(P_STRING IN VARCHAR2, P_FLAG IN VARCHAR2) RETURN STR_LIST  ;
  TYPE CUR_SALES_ACCOUNT_AMOUNT IS TABLE OF T_SALES_ACCOUNT_AMOUNT%ROWTYPE INDEX BY BINARY_INTEGER;
  FUNCTION FUN_SPLIT(P_STR IN VARCHAR2, P_DELIMITER IN VARCHAR2)
    RETURN STR_LIST;
  FUNCTION FUN_GET_CREDITGROUPID(P_ENTITY_ID       Number,
                                 P_CUSTOMER_ID     NUMBER,
                                 P_SALES_MAIN_TYPE varchar2,
                                 IN_ACCOUNT_ID     NUMBER DEFAULT NULL --2017-4-20 增加账户ID参数，默认为空
                                 ) RETURN NUMBER;
  FUNCTION FUN_GET_AMOUNT(P_ENTITY_ID       NUMBER,
                          P_CUSTOMER_ID     NUMBER,
                          P_ACCOUNT_ID      NUMBER,
                          P_SALES_MAIN_TYPE VARCHAR2,
                          P_FLAG            NUMBER, --1 可用提货余额；2 可用折让余额；3 可提货额度；4 到款余额
                          IS_DISCOUNT_TYPE     VARCHAR2 DEFAULT 'ALL'--ALL代表常规、折让合并 空或COMMON代表常规 其他代表折让到款
                          ) RETURN NUMBER;
  FUNCTION FUN_GET_CODELIST(P_CODE_ID   VARCHAR2,
                            P_CODE_TYPE VARCHAR2,
                            P_FLAG      NUMBER) RETURN VARCHAR2;
  FUNCTION FUN_GET_SALES_AMOUNT(P_ENTITY_ID NUMBER,
                                P_CUSTOMER_ID NUMBER,
                                P_SALES_MAIN_TYPE VARCHAR2,
                                IN_ACCOUNT_ID     NUMBER DEFAULT NULL --2017-5-5 增加账户ID参数，默认为空
                                ) RETURN NUMBER ;

  FUNCTION FUN_GET_ADJ_AMOUNT(P_ENTITY_ID NUMBER,
                                P_CUSTOMER_ID NUMBER,
                                P_SALES_MAIN_TYPE VARCHAR2,
                                IN_ACCOUNT_ID     NUMBER DEFAULT NULL --2017-4-25 增加账户ID参数，默认为空
                                ) RETURN NUMBER ;
  FUNCTION FUN_GET_THREEDELAY_AMOUNT(P_ENTITY_ID       NUMBER,
                                    P_CUSTOMER_ID     NUMBER,
                                    P_SALES_MAIN_TYPE VARCHAR2,
                                    IN_ACCOUNT_ID     NUMBER DEFAULT NULL --2017-4-25 增加账户ID参数，默认为空
                                )
    RETURN NUMBER;
  FUNCTION FUN_GET_USE_DELAY(P_ENTITY_ID NUMBER,
                             P_CUSTOMER_ID NUMBER,
                             P_SALES_MAIN_TYPE VARCHAR2,
                             IN_ACCOUNT_ID     NUMBER DEFAULT NULL --2017-4-25 增加账户ID参数，默认为空
                             ) RETURN Number ;
  FUNCTION FUN_GET_DELAY_CU_AMOUNT(P_ENTITY_ID NUMBER,
                                   P_CUSTOMER_ID NUMBER,
                                   P_SALES_MAIN_TYPE VARCHAR2,
                                   IN_ACCOUNT_ID     NUMBER DEFAULT NULL --2017-5-5 增加账户ID参数，默认为空
                                   ) RETURN NUMBER ;
  FUNCTION FUN_GET_THREE_AMOUNT(P_CASH_RECEIPT_ID NUMBER,
                                        P_SALES_MAIN_TYPE VARCHAR2,
                                        P_FLAG NUMBER,
                                        IS_DISCOUNT_TYPE    IN VARCHAR2 DEFAULT NULL--折让方式
                                        ) RETURN NUMBER ;
  FUNCTION FUN_GET_CONFIG_INFO(P_ENTITY_ID NUMBER,
                               P_BILL_TYPE_ID Number,
                               P_DELAYPAY_TYPE Number,
                               P_FLAG NUMBER) RETURN Number ;
                               
  --add by wangcong 2016-5-4 
  --传入起止日期，计算起止日期时间内的销售金额  日期格式 yyyyMMdd                          
  FUNCTION FUN_GET_SALES_AMOUNT_BY_DATE(P_ENTITY_ID NUMBER,
                                P_CUSTOMER_ID NUMBER,
                                P_BEGIN_DATE VARCHAR2,
                                P_END_DATE VARCHAR2,
                                P_SALES_MAIN_TYPE VARCHAR2,
                                IN_ACCOUNT_ID     NUMBER DEFAULT NULL --2017-5-2 增加账户ID参数，默认为空
                                ) RETURN NUMBER;
                                
  --add by wangcong 2016-5-16
  --计算可用额度                            
  FUNCTION FUN_GET_CAN_USE_AMOUNT(P_ENTITY_ID NUMBER,
                                P_CUSTOMER_ID NUMBER,
                                P_CUSTOMER_CREDIT NUMBER,
                                P_LAST_YEAR_AMOUNT NUMBER,
                                P_THIS_YEAR_AMOUNT NUMBER,
                                P_COOPER_DATE NUMBER,
                                P_TWELVE_AMOUNT NUMBER,
                                P_SALES_MAIN_TYPE VARCHAR2,
                                IN_ACCOUNT_ID     NUMBER DEFAULT NULL --2017-4-25 增加账户ID参数，默认为空
                                ) RETURN NUMBER ;

  --add by xiaoxu 2016-6-6
  --获取客户的调整额度
  FUNCTION FUN_GET_CUST_ADJ_AMOUNT
  (
    P_ENTITY_ID   NUMBER,
    P_CUSTOMER_ID NUMBER,
    IN_ACCOUNT_ID NUMBER DEFAULT NULL --2017-5-5 增加账户ID参数，默认为空
  ) RETURN NUMBER;

	--add by xiaoxu 2016-6-7
  --获取客户已使用的铺底额度（生效、制单、送审）
  FUNCTION FUN_GET_CUST_USE_DELAY
  (
    P_ENTITY_ID   NUMBER,
    P_CUSTOMER_ID NUMBER,
    IN_ACCOUNT_ID NUMBER DEFAULT NULL --2017-5-5 增加账户ID参数，默认为空
  ) RETURN NUMBER;
  
  --add by xiaoxu 2016-6-7
  --获取客户已使用的三方铺底额度（生效、制单、送审）
  FUNCTION FUN_GET_CUST_THREEDELAY_AMOUNT
  (
    P_ENTITY_ID   NUMBER,
    P_CUSTOMER_ID NUMBER,
    IN_ACCOUNT_ID NUMBER DEFAULT NULL --2017-5-5 增加账户ID参数，默认为空
  ) RETURN NUMBER;
  
  --add by tianmzh 2016-6-7
  --传入起止日期，计算起止日期时间内的实际铺底金额  日期格式 yyyyMMdd                          
  FUNCTION FUN_GET_DELAY_AMOUNT_BY_DATE(P_ENTITY_ID            NUMBER,
                                        P_CUSTOMER_ID          NUMBER,
                                        P_SALES_MAIN_TYPE_CODE VARCHAR2,
                                        P_BEGIN_DATE           VARCHAR2,
                                        P_END_DATE             VARCHAR2,
                                        IN_ACCOUNT_ID     NUMBER DEFAULT NULL --2017-5-2 增加账户ID参数，默认为空
                                        )
    RETURN NUMBER;

  --------------------------------------------------------------------------------
  /*
  *   创建日期：2016-8-23
  *   创建者：liangym2
  *   功能说明：获取起止日期内实际铺底金额
  */
  --------------------------------------------------------------------------------
  FUNCTION FUN_GET_DELAY_AMOUNT_BY_DATE(P_ENTITY_ID            NUMBER,
                                        P_CUSTOMER_ID          NUMBER,
                                        P_SALES_MAIN_TYPE_CODE VARCHAR2,
                                        P_BEGIN_DATE           DATE,
                                        P_END_DATE             DATE,
                                        IN_ACCOUNT_ID     NUMBER DEFAULT NULL --2017-5-2 增加账户ID参数，默认为空
                                        )
    RETURN NUMBER;
    
  /*add by LIANGYM2
  *传入起止日期，计算起止时间内的销售金额
  *用于信用额度计算
  *
  */
  FUNCTION FUN_GET_SALES_AMOUNT_BY_DATE(P_ENTITY_ID       NUMBER,
                                        P_CUSTOMER_ID     NUMBER,
                                        P_BEGIN_DATE      DATE,
                                        P_END_DATE        DATE,
                                        P_SALES_MAIN_TYPE VARCHAR2,
                                        IN_ACCOUNT_ID     NUMBER DEFAULT NULL --2017-5-2 增加账户ID参数，默认为空
                                        )
    RETURN NUMBER;
  
  --add by tianmzh 2016-8-3
  --账户维度
  --传入起止日期，计算起止日期时间内的销售金额  日期格式 yyyyMMdd           
  FUNCTION FUN_GET_SALES_AMOUNT_BY_ACC(P_ENTITY_ID   NUMBER,
                                       P_CUSTOMER_ID NUMBER,
                                       P_BEGIN_DATE  VARCHAR2,
                                       P_END_DATE    VARCHAR2,
                                       P_ACCOUNT_ID  NUMBER) RETURN NUMBER;
  
  --------------------------------------------------------------------------------
  /*
  *   创建日期：2017-6-7
  *     创建者：梁颜明
  *   功能说明：根据客户ID，营销大类编码，系统参数值，获取所对应的额度组
  * CREDIT_USE_DEFAULT_GROUP:
  * A 按之前额度组关系获取额度组 如果是销司 配置成A 只会默认额度组
  * Y 只会获取到默认额度组
  * N 只会获取到非默认额度组
  *   返回结果：额度组ID
  *
  */
  -------------------------------------------------------------------------------
  FUNCTION F_GET_CREDITGROUPID_BY_PARAM(IN_ENTITY_ID       Number,
                                 IN_CUSTOMER_ID     NUMBER,
                                 IS_SALES_MAIN_TYPE varchar2,
                                 IS_PARAM_VALUE    VARCHAR2
                                 ) RETURN NUMBER;

  --取系统参数值(按范围取旧值表)
  function F_GET_OLD_PARAM_VALUE
  (
   P_CONFIG_CODE    t_bd_param_list.param_code%type,  --参数配置编码
   P_ENTITY_ID      up_org_unit.ENTITY_ID%type, --业务主体ID
   P_UNIT_ID        up_org_unit.Unit_Id%type default null, --中心ID
   P_CUSTOMER_ID    t_customer_header.customer_id%type default null, --客户ID, --中心ID
   IN_SCOPE         number default 0 --取旧值表范围，0取中心、客户旧值表
   )--
   return varchar2;
  
  --取系统参数值(找不到就返回主体系统参数)
  function F_GET_PARAM_VALUE_ENTITY_PRIOR
  (
   P_CONFIG_CODE    t_bd_param_list.param_code%type,  --参数配置编码
   P_ENTITY_ID      up_org_unit.ENTITY_ID%type, --业务主体ID
   P_UNIT_ID        up_org_unit.Unit_Id%type default null, --中心ID
   P_CUSTOMER_ID    t_customer_header.customer_id%type default null --客户ID
   ) --
   return varchar2;
  
  --
  FUNCTION F_GET_SALES_ACCOUNT_AMOUNT(IN_ENTITY_ID       NUMBER,
                                      IN_CUSTOMER_ID     NUMBER,
                                      IN_ACCOUNT_ID      NUMBER,
                                      IN_CREDIT_GROUP_ID NUMBER,
                                      IS_SALES_MAIN_TYPE   VARCHAR2,
                                      IS_DISCOUNT_TYPE   VARCHAR2) --
    RETURN TAB_SALES_DIS_AMOUNT_FREEZE PIPELINED;
    
  ----------------------------------------------------------------------
  -- Author  : liangym2
  -- Created : 2018-11-16
  -- Purpose : 查询客户款项可提货金额、可用到款金额、到款余额、折让余额、可用折让余额
  ----------------------------------------------------------------------
  FUNCTION F_GET_AMOUNT(IN_ENTITY_ID       NUMBER, --主体ID，不能为空
                        IN_CUSTOMER_ID     NUMBER, --客户ID，不能为空
                        IN_ACCOUNT_ID      NUMBER, --账户ID，可以为空
                        IS_SALES_MAIN_TYPE VARCHAR2, --营销大类，可以为空
                        IN_CREDIT_GROUP_ID NUMBER, --额度组ID，可以为空,
                        IN_FLAG            NUMBER, --1 可用到款金额；2 可用折让金额；3 可提货额度；4 到款余额
                        IS_DISCOUNT_TYPE   VARCHAR2 DEFAULT 'ALL' --ALL代表常规、折让合并 空或COMMON代表常规 其他代表折让到款
                        )
   RETURN NUMBER;
    
  ----------------------------------------------------------------------
  -- Author  : liangym2
  -- Created : 2018-09-18
  -- Purpose : 查询客户款项可提货金额、可用到款金额、到款余额、折让余额、可用折让余额
  ----------------------------------------------------------------------
  PROCEDURE P_GET_AMOUNT(IN_ENTITY_ID               IN NUMBER, --主体ID，不能为空
                         IN_CUSTOMER_ID             IN NUMBER, --客户ID，不能为空
                         IN_ACCOUNT_ID              IN NUMBER, --账户ID，可以为空
                         IS_SALES_MAIN_TYPE         IN VARCHAR2, --营销大类，可以为空
                         IN_CREDIT_GROUP_ID         NUMBER, --额度组ID，可以为空
                         ON_PICKUP_AMOUNT           IN OUT NUMBER, --返回可提货金额
                         ON_AVL_RCV_AMOUNT          IN OUT NUMBER, --返回可用到款金额
                         ON_RCV_BALANCE_AMOUNT      IN OUT NUMBER, --返回到款余额
                         ON_AVL_DISCOUNT_AMOUNT     IN OUT NUMBER, --返回可用折让余额
                         ON_DISCOUNT_BALANCE_AMOUNT IN OUT NUMBER, --返回折让余额
                         IS_DISCOUNT_TYPE           IN VARCHAR2 DEFAULT 'ALL' --ALL代表常规、折让合并 空或COMMON代表常规 其他代表折让到款
                         );
  
end PKG_CREDIT_TOOLS;
/

