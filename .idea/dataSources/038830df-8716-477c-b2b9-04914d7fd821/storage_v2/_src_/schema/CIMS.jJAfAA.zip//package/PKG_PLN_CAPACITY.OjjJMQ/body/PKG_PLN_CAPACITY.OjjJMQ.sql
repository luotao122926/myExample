create Package Body Pkg_Pln_Capacity Is

  -- Author  : NICRO.LI
  -- Created : 2016-12-08 13:57:33
  -- Purpose : 订单管理
  v_Nl      Constant Varchar2(2) := Chr(13) || Chr(10); --换行
  v_Null    Constant Varchar2(4) := Null; --空值
  v_True    Constant Varchar2(2) := 'Y';
  v_False   Constant Varchar2(2) := 'N';
  v_Result  Constant Number := 0; --成功返回
  v_Success Constant Varchar2(10) := 'SUCCESS';
  v_Failure Constant Varchar2(10) := 'FAILURE';
  v_Warning Constant Varchar2(10) := 'WARNING';
  v_Base_Exception Exception; --自定义异常
  
  -------------------------------------------------------------------------
  -- Author  : NICRO.LI
  -- Created : 2016-12-08 13:57:33
  -- Purpose : 获取提货订单对应订单周期所属月的周期ID
  -------------------------------------------------------------------------
  Function f_Get_Parameter_Month_Period(p_Entity_Id In Number,
                                        p_Period_Type In Varchar2, --周期类型 W:周 M:月
                                        p_Date        In Date  --日期
                                        )
    Return Number Is
    v_Period_Id                   Number;
    v_Count                       Number := 0;
    v_Pln_Capacity_Advance_Period Number;
  Begin
    --add by lizhen 2016-12-14
    --获取系统参数产能可视订单周期提前期设置
    Begin
      v_Pln_Capacity_Advance_Period := Pkg_Bd.f_Get_Parameter_Value('PLN_CAPACITY_ADVANCE_PERIOD',
                                                                    p_Entity_Id);
    Exception
      When Others Then
        Raise v_Base_Exception;
    End;
    --获取默设计的订单周期
    v_Count := 0;
    Begin
      For r_Period In (Select Pop.Parent_Period_Id,
                              Pop.Period_Id,
                              To_Char(Pop.Begin_Date, 'DD') Bday,
                              Pop.Begin_Date
                         From t_Pln_Order_Period Pop
                        Where Pop.End_Date >= p_Date
                          And Pop.Period_Type = 'T+3周期'
                          And Pop.Entity_Id = p_Entity_Id
                        Order By Pop.Period_Code) Loop
        If v_Count = v_Pln_Capacity_Advance_Period Then
          If p_Period_Type = 'M' Then
            Select Pop.Period_Id
              Into v_Period_Id
              From t_Pln_Order_Period Pop
             Where Pop.Period_Id = r_Period.Parent_Period_Id;
          Else
             v_Period_Id := r_Period.Period_Id;
          End If;
          Exit;
        End If;
        v_Count := v_Count + 1;
      End Loop;
    Exception
      When Others Then
        Raise v_Base_Exception;
    End;
    Return v_Period_Id;
  Exception
    When v_Base_Exception Then
      Return Null;
    When Others Then
      Return Null;
  End;
  
  -----------------------------------------------------------------------------
  -- AUTHOR  : Nicro.Li
  -- CREATED : 2017-04-21
  -- PURPOSE : 根据产品、产地、周期获取提货订单本周期已占用数量
  -----------------------------------------------------------------------------
  Function f_Get_Lgorder_Occupy_Qty(p_Producing_Area_Id In Number, ----主体ID
                                    p_Item_Code         In Varchar2, --产品编码
                                    p_Entity_Id         In Number, --主体ID
                                    p_Period_Id         In Number --周期ID
                                    ) Return Number Is
    v_Lgorder_Occupy_Qty Number;
    v_Month_Period_Id    Number;
  Begin
    Begin
      Select Op.Parent_Period_Id
        Into v_Month_Period_Id
        From t_Pln_Order_Period Op
       Where Op.Period_Id = p_Period_Id
         And Op.Entity_Id = p_Entity_Id;
    Exception
      When Others Then
        Return 999999;
    End;
    
    Begin
      Select Nvl(Sum(Case
                       When Loh.Order_Head_State = '304' Then
                        Nvl(Lol.Pln_Affirmed_Qty, 0)
                       Else
                        Decode(Lol.Order_Line_State,
                               'CLOSED',
                               Nvl(Lol.Pln_Affirmed_Qty, 0),
                               Nvl(Lol.To_Aps_Capacity_Qty, 0))
                     End),
                 0)
        Into v_Lgorder_Occupy_Qty
        From t_Pln_Lg_Order_Head Loh,
             t_Pln_Lg_Order_Line Lol,
             t_Pln_Order_Type    Pot
       Where Loh.Order_Head_Id = Lol.Order_Head_Id
         And Pot.Order_Type_Id = Loh.Order_Type_Id
         And Pot.Lg_Order_Submit_Type = 'HQ_TYPE'
         And p_Period_Id =
             f_Get_Parameter_Month_Period(p_Entity_Id   => Loh.Entity_Id,
                                          p_Period_Type => 'W',
                                          p_Date        => Trunc(Loh.To_Checkup_Date))
         And Not Exists
       (Select 1
                From t_Pln_Lg_Relation Plr
               Where Plr.Relation_Type = 'T3_ORDER_TYPE'
                 And Plr.Lg_Order_Line_Id = Lol.Order_Line_Id)
         And Loh.Order_Head_State Not In ('19', '303', '415')
         And Loh.Entity_Id = p_Entity_Id
         --And Lol.Item_Code = p_Item_Code
         And Lol.Producing_Area_Id = p_Producing_Area_Id
         And Exists
         (Select 1
                  From v_Pln_Item_Capacity Vpic
                 Where Exists
                 (Select 1
                          From v_Pln_Item_Capacity Pic
                         Where Pic.Item_Code = p_Item_Code
                           And Pic.Producing_Area_Id = p_Producing_Area_Id
                           And Pic.Period_Id = v_Month_Period_Id
                           And Vpic.Capacity_Type = Pic.Capacity_Type
                           And Vpic.Capacity_Class_Code = Pic.Capacity_Class_Code)
                   And Vpic.Period_Id = v_Month_Period_Id
                   And Vpic.Producing_Area_Id = p_Producing_Area_Id
                   And Vpic.Item_Id = Lol.Item_Id);
    Exception
      When Others Then
        Return 999999;
    End;
    Return Nvl(v_Lgorder_Occupy_Qty, 0);
  Exception
    When Others Then
      Return 999999;
  End;
  
  -----------------------------------------------------------------------------
  -- AUTHOR  : Nicro.Li
  -- CREATED : 2017-04-21
  -- PURPOSE : 根据产品、产地、周期获取提货订单本周期已占用数量
  -----------------------------------------------------------------------------
  Function f_Get_Plnorder_Occupy_Qty(p_Producing_Area_Id In Number, ----主体ID
                                     p_Item_Code         In Varchar2, --产品编码
                                     p_Entity_Id         In Number, --主体ID
                                     p_Period_Id         In Number --周期ID
                                     ) Return Number Is
    v_Plnorder_Occupy_Qty Number;
    v_Month_Period_Id    Number;
  Begin
    Begin
      Select Op.Parent_Period_Id
        Into v_Month_Period_Id
        From t_Pln_Order_Period Op
       Where Op.Period_Id = p_Period_Id
         And Op.Entity_Id = p_Entity_Id;
    Exception
      When Others Then
        Return 999999;
    End;
    
    Begin
      Select Nvl(Sum(Decode(Poh.Form_State,
                            '32',
                            Nvl(Pol.Can_Produce_Qty, 0),
                            Nvl(Pol.Check_Qty, Pol.Apply_Qty))),
                 0) Capacity_Quantity
        Into v_Plnorder_Occupy_Qty
        From t_Pln_Order_Head Poh,
             t_Pln_Order_Line Pol,
             t_Pln_Order_Type Pot
       Where Poh.Order_Head_Id = Pol.Order_Head_Id
         And Poh.Order_Type_Id = Pot.Order_Type_Id
         And (Pot.Is_Pln_Capacity = 'Y' Or Exists
              (Select 1
                 From t_Pln_Lg_Relation   Plr,
                      t_Pln_Lg_Order_Head Loh,
                      t_Pln_Order_Type    Pot
                Where Loh.Order_Head_Id = Plr.Lg_Order_Head_Id
                  And Loh.Order_Type_Id = Pot.Order_Type_Id
                  And Pot.Lg_Order_Submit_Type = 'HQ_TYPE'
                  And Plr.Order_Line_Id = Pol.Order_Line_Id
                  And Plr.Order_Head_Id = Pol.Order_Head_Id
                  And Plr.Relation_Type = 'T3_ORDER_TYPE'))
         And Poh.Form_State Not In ('19', '303', '304', '305')
         And Poh.Entity_Id = p_Entity_Id
         And Pol.Item_Code = p_Item_Code
         And Pol.Producing_Area_Id = p_Producing_Area_Id
         And Poh.Period_Id = p_Period_Id
         And Exists
         (Select 1
                  From v_Pln_Item_Capacity Vpic
                 Where Exists
                 (Select 1
                          From v_Pln_Item_Capacity Pic
                         Where Pic.Item_Code = p_Item_Code
                           And Pic.Producing_Area_Id = p_Producing_Area_Id
                           And Pic.Period_Id = v_Month_Period_Id
                           And Vpic.Capacity_Type = Pic.Capacity_Type
                           And Vpic.Capacity_Class_Code = Pic.Capacity_Class_Code)
                   And Vpic.Period_Id = v_Month_Period_Id
                   And Vpic.Producing_Area_Id = p_Producing_Area_Id
                   And Vpic.Item_Id = Pol.Item_Id);
    Exception
      When Others Then
        Return 999999;
    End;
    Return Nvl(v_Plnorder_Occupy_Qty, 0);
  Exception
    When Others Then
      Return 999999;
  End;
  
  -----------------------------------------------------------------------------
  -- AUTHOR  : Nicro.Li
  -- CREATED : 2017-04-21
  -- PURPOSE : 根据产品、产地、周期获取产能周期占用数量，多个产能类型时，取最大数
  -----------------------------------------------------------------------------
  Function f_Get_Period_Occupy_Qty(In_Producing_Area_Id In Number, ----主体ID
                                   In_Item_Code         In Varchar2, --产品编码
                                   In_Entity_Id         In Number, --主体ID
                                   In_Period_Id         In Number --周期ID
                                   ) Return Number Is
    v_Capacity_Occupy_Qty Number := 0;
    v_Month_Period_Id    Number;
  Begin
    Begin
      Select Op.Parent_Period_Id
        Into v_Month_Period_Id
        From t_Pln_Order_Period Op
       Where Op.Period_Id = In_Period_Id
         And Op.Entity_Id = In_Entity_Id;
    Exception
      When Others Then
        Return 999999;
    End;
    Select Max(Cpo.Occupy_Qty)
      Into v_Capacity_Occupy_Qty
      From v_Pln_Item_Capacity Pic, t_Pln_Capacity_Period_Occupy Cpo
     Where Pic.Assenbly_Capacity_Id = Cpo.Assenbly_Capacity_Id
       And Pic.Producing_Area_Id = Cpo.Producing_Area_Id
       And Cpo.Period_Id = In_Period_Id
       And Pic.Period_Id = v_Month_Period_Id
       And Pic.Item_Code = In_Item_Code
       And Pic.Entity_Id = In_Entity_Id
       And Pic.Producing_Area_Id = In_Producing_Area_Id;
    Return Nvl(v_Capacity_Occupy_Qty, 0);
  Exception
    When Others Then
      Return 0;
  End;
  
  -----------------------------------------------------------------------------
  -- AUTHOR  : Nicro.Li
  -- CREATED : 2017-02-07
  -- PURPOSE : 根据产品、产地、周期获取CIMS剩余产能
  --            周期传入为空白时，根据日期取提货订单的提前周期参数
  -----------------------------------------------------------------------------
  Function f_Get_Item_Capacity_Qty(p_Producing_Area_Id In Number, ----主体ID
                                   p_Item_Code         In Varchar2, --产品编码
                                   p_Date              In Date, --提货订单日期
                                   p_Entity_Id         In Number, --主体ID
                                   p_Period_Id         In Number --周期ID
                                   ) Return Number Is
  
    v_Item_Capacity_Qty Number;
    v_Period_Id         Number;
  Begin
    If p_Period_Id Is Null Then
      v_Period_Id := f_Get_Parameter_Month_Period(p_Entity_Id   => p_Entity_Id,
                                                  p_Period_Type => 'M',
                                                  p_Date        => p_Date);
    Else
      v_Period_Id := p_Period_Id;
    End If;
   
    Return v_Item_Capacity_Qty;
  Exception 
    When Others Then
      Return 0;
  End;

  -----------------------------------------------------------------------------
  -- AUTHOR  : Nicro.Li
  -- CREATED : 2017-04-10
  -- PURPOSE : 根据产品、产地、周期获取CIMS剩余产能
  --            周期传入为空白时，根据日期取提货订单的提前周期参数
  -- RETURN : 返回数据时，表示计算正常，返回NULL表示程序出现异常
  -----------------------------------------------------------------------------
  Function f_Get_Item_Capacity_Qty_New(p_Producing_Area_Id In Number, ----产地ID
                                       p_Item_Code         In Varchar2, --产品编码
                                       p_Date              In Date, --提货订单日期
                                       p_Entity_Id         In Number, --主体ID
                                       p_Period_Id         In Number --周期ID
                                       ) Return Number Is
  
    v_Currend_Period_Id     Number;
    v_Month_Period_Id       Number;
    v_Pln_Capacity_Model    Varchar2(32);
    v_Begin_Date            Date;
    v_End_Date              Date;
    v_Begin_Day             Number;
    v_End_Day               Number;
    v_Sql                   Varchar2(4000);
    v_Item_Curr_Capacity_Qty   Number := 0;
    v_Item_Period_Capacity_Qty Number := 0;
    v_Period_Type           Varchar2(3) := 'M';
    v_Capacity_Span_Period  Number;
    v_Curr_Begin_Date       Date;
    v_Wee_Begin_Date        Date;
  Begin
    --add by lizhen 2017-08-08
    --获取系统参数产能可视周期类型参数
    Begin
      v_Period_Type := Pkg_Bd.f_Get_Parameter_Value('PLN_CAPACITY_PERIOD_TYPE',
                                                           p_Entity_Id);
    Exception
      When Others Then
        Return Null;
    End;
    
    If p_Period_Id Is Null Then
      v_Currend_Period_Id := f_Get_Parameter_Month_Period(p_Entity_Id   => p_Entity_Id,
                                                          p_Period_Type => 'W',
                                                          p_Date        => p_Date);
    Else
      v_Currend_Period_Id := p_Period_Id;
    End If;
    
    --add by lizhen 2017-04-10
    --获取系统参数产能可视模式参数
    Begin
      v_Pln_Capacity_Model := Pkg_Bd.f_Get_Parameter_Value('PLN_CAPACITY_MODEL',
                                                           p_Entity_Id);
    Exception
      When Others Then
        Return Null;
    End;
    
    --add by lizhen 2017-04-10
    --获取系统参数产能允许跨周期数(只有月周期时，才使用这个设置）
    Begin
      v_Capacity_Span_Period := Pkg_Bd.f_Get_Parameter_Value('PLN_CAPACITY_SPAN_PERIOD',
                                                           p_Entity_Id);
    Exception
      When Others Then
        Return Null;
    End;
    
    --获取期的开始、结束日期
    Begin
      Select To_Number(To_Char(Op.Begin_Date, 'DD')),
             To_Number(To_Char(Op.End_Date, 'DD')),
             Op.Parent_Period_Id,
             Op.Begin_Date,
             Op.End_Date
        Into v_Begin_Day,
             v_End_Day,
             v_Month_Period_Id,
             v_Wee_Begin_Date,
             v_End_Date
        From t_Pln_Order_Period Op
       Where Op.Period_Id = v_Currend_Period_Id;
    Exception
      When Others Then
        Return Null;
    End;
    
    --add by lizhen 2017-08-28按月，且取从产能设置表取出最小日期
    If v_Period_Type = 'M' Then
      Begin
        Select Min(Pac.Begin_Date), Min(Pac.Period_Id)
          Into v_Curr_Begin_Date, v_Currend_Period_Id
          From t_Pln_Assenbly_Capacity Pac
         Where Pac.Entity_Id = p_Entity_Id
           And v_Wee_Begin_Date Between Pac.Begin_Date And Pac.End_Date;
      Exception
        When Others Then
          Return Null;
      End;
    
      Begin
        Select Min(Pac.Begin_Date) Into v_Begin_Date
          From t_Pln_Assenbly_Capacity Pac
         Where Pac.Entity_Id = p_Entity_Id
           And v_Wee_Begin_Date Between Pac.Begin_Date And Pac.End_Date;
      Exception
        When Others Then
          Return Null;
      End;
    End If;
    

    --add by lizhen 2017-07-07产能计算逻辑更改为：
    --周期日产能汇总 - 周期各项目产能占用，取最小值为本周期产能
    For periodNum In 0 .. v_Capacity_Span_Period Loop
      If v_Period_Type = 'M' Then
        Begin
         Select To_Number(To_Char(Op.End_Date, 'DD')),
                Op.Begin_Date,
                Op.End_Date
           Into v_End_Day,
                v_Begin_Date,
                v_End_Date
           From t_Pln_Order_Period Op
          Where Op.Period_Type = '月'
            And Op.Entity_Id = p_Entity_Id
            And Op.Period_Code = Replace(To_Char(Add_Months(v_Wee_Begin_Date, periodNum), 'YYYY-MM') || '月', '-', '年');
        Exception
          When Others Then
            Return Null;
        End;        
      End If;
      --如果周期开始日期，小于系统当前日期，开始日期则从当前日期+1开始计算产能
      If Trunc(Sysdate) >= v_Wee_Begin_Date Then
        Select To_Char(Trunc(Sysdate + 1), 'DD')
          Into v_Begin_Day
          From Dual;
      End If;
    
      For i In v_Begin_Day .. v_End_Day Loop
        If v_Sql Is Null Then
           v_Sql := 'Nvl(Pic.Day_Capacity_' || Trim(To_Char(i, '00')) || ', 0)';
        Else
          v_Sql := v_Sql || ' + Nvl(Pic.Day_Capacity_' || Trim(To_Char(i, '00')) || ', 0)';
        End If;
      End Loop;
      v_Sql := 'Select Min((' || v_Sql || ') -
                       Nvl((Select Nvl(Cpo.Occupy_Qty, 0) - Nvl(Cpo.overdue_occupy_qty, 0) + Nvl(Cpo.Front_Occupy_Qty, 0)
                             From t_Pln_Capacity_Period_Occupy Cpo
                            Where Cpo.Assenbly_Capacity_Id = Pic.Assenbly_Capacity_Id
                              And Cpo.Period_Id = :1
                              And Cpo.Producing_Area_Id = Cpo.Producing_Area_Id),
                           0)) item_Capcity_Qty
                  From v_Pln_Item_Capacity Pic, t_Pln_Item_Producing_Area Ipa
                 Where Pic.Item_Code = :2
                   And Pic.Period_Id = :3
                   And Pic.Producing_Area_Id = :4
                   And Pic.Item_Id = Ipa.Item_Id
                   And Pic.Producing_Area_Id = Ipa.Producing_Area_Id
                   And Trunc(Sysdate) Between Ipa.Begin_Date And Nvl(Ipa.End_Date, Trunc(Sysdate))';
      Begin
        Execute Immediate v_Sql
          Into v_Item_Period_Capacity_Qty
          Using v_Currend_Period_Id, p_Item_Code, v_Month_Period_Id, p_Producing_Area_Id;
          --在产品产能视图里面无数据的则表示产品不受产能控制，这里会是null，要赋值999999999 lilh6 2017-11-3
          IF v_Item_Period_Capacity_Qty IS NULL THEN
            v_Item_Period_Capacity_Qty := 999999999;
          END IF;
      Exception
        When No_Data_Found Then
          Return 999999999;
        When Others Then
          --在产品产能视图里面无数据的则表示产品不受产能控制，返回999999999
          Return 999999999;
      End;
      v_Item_Curr_Capacity_Qty := v_Item_Curr_Capacity_Qty + Nvl(v_Item_Period_Capacity_Qty, 0);
    End Loop;
    --获取产能数据
    Return Nvl(v_Item_Curr_Capacity_Qty, 0);
  Exception 
    When Others Then
      Return 0;
  End;

  ------------------------------------------------------------------------------------------
  ---- AUTHOR  : Nicro.Li
  -- CREATED : 2016-12-13
  -- PURPOSE : 提货订单产能可视检查、产能不足时方法默认返回成功，但会同时返回产可视异常信息
  -- p_result返回说明：SUCCESS:成功，产能满足   
  ---                  FAILURE:失败，产能检查失败，不允许续继提交单据
  --                   WARNING:警告，产能检查失败，提示错误信息确认后允许续继提交订单
  ------------------------------------------------------------------------------------------
  Procedure p_Chk_Item_Capacity(p_Entity_Id        In Number, --主体ID
                                p_Order_Head_Id    In Number, --订单头ID
                                p_Order_Type_Id    In Number, --单据类型ID
                                p_Order_Check_Date In Date, --检查日期
                                p_User_Code        In Varchar2, ----用户ID
                                p_Result           In Out Varchar2, --成功则反回 SUCCESS 失败则返回失败原因
                                p_Chk_Msg          In Out Varchar2 --产能检查不通过时返回错误信息
                                ) Is
    r_Lg_Header                   t_Pln_Lg_Order_Head%Rowtype;
    v_Inv_Can_Used                Number := 0; --库存可用量
    v_Meet_An_Order_Qty           Number := 0; --备货订单数量 
    v_Residual_Capacity           Number := 0; --剩余产能
    v_Organization_Id             Number := 0;
    v_Err_Msg                     Varchar2(4000);
    v_Pln_Capacity_Aps            Varchar2(32);
    v_Lg_Order_Submit_Type        t_Pln_Order_Type.Lg_Order_Submit_Type%Type;
    v_Pln_Capacity_Modle          Varchar2(32);
    v_Pln_Capacity_Advance_Period Number;
    v_Period_Id                   Number;
    v_Count                       Number;
    
    v_Source_Order_Type_Id        Number;
    v_Is_Pln_Capacity             t_Pln_Order_Type.Is_Pln_Capacity%Type;
    v_Period_Type           Varchar2(3) := 'M';
    v_Capacity_Strict_Control     t_bd_param_entity.entity_value%Type;
    v_Item_Assign                 Number := 0;
  Begin
    p_Result  := v_Success;
    p_Chk_Msg := Null;
    
    Begin
      Select Pot.Source_Order_Type_Id, Pot.Is_Pln_Capacity
        Into v_Source_Order_Type_Id, v_Is_Pln_Capacity
        From t_Pln_Order_Type Pot
       Where Pot.Order_Type_Id = p_Order_Type_Id;
    Exception
      When Others Then
        p_Result := '获取订单单据类型信息失败!' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;
  
    If v_Source_Order_Type_Id Not In (0, 1) Then
      p_Result := '检查源订单单据类型失败，系统只支持提货订单、计划订单产能可视!';
      Raise v_Base_Exception;
    End If;
    
    --add by lizhen 2016-12-05 
    --获取系统参数是否启用产能可视
    Begin
      v_Pln_Capacity_Aps := Pkg_Bd.f_Get_Parameter_Value('PLN_CAPACITY_APS',
                                                         p_Entity_Id);
    Exception
      When Others Then
        p_Result := '获取是否使用APS产能可视参数PLN_CAPACITY_APS参数失败！' || v_Nl ||
                    Sqlerrm;
        Raise v_Base_Exception;
    End;
    If Nvl(v_Pln_Capacity_Aps, 'N') != 'Y' Then
      Return;
    End If;
    --add by lizhen 2017-08-30 计划订单单据类型不需要做产能可视的返回 success
    If v_Source_Order_Type_Id = 0 And Nvl(v_Is_Pln_Capacity, '_') != 'Y' Then
      Return;
    End If;
    
    --add by lizhen 2016-12-07
    --获取系统参数产能可视模式参数
    Begin
      v_Pln_Capacity_Modle := Pkg_Bd.f_Get_Parameter_Value('PLN_CAPACITY_MODEL',
                                                           p_Entity_Id);
    Exception
      When Others Then
        p_Result := '获取产能可视模式参数PLN_CAPACITY_MODEL参数失败！' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;
    
    --add by lizhen 2017-08-08
    --获取系统参数产能可视周期类型参数
    Begin
      v_Period_Type := Pkg_Bd.f_Get_Parameter_Value('PLN_CAPACITY_PERIOD_TYPE',
                                                           p_Entity_Id);
    Exception
      When Others Then
        p_Result := '获取产能可周期类型PLN_CAPACITY_PERIOD_TYPE参数失败！' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;
    
    --add by lizhen 2017-8-28
    --获取产能可视检查是否严格标志参数
    Begin
      v_Capacity_Strict_Control := Pkg_Bd.f_Get_Parameter_Value('PLN_CAPACITY_STRICT_FLAG',
                                                           p_Entity_Id);
    Exception
      When Others Then
        p_Result := '获取产能可视检查是否严格标志参数PLN_CAPACITY_STRICT_CONTROL参数失败！' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;
    
    --获取提货订单头
    Begin
      Select Order_Head_Id,
             Order_Head_State,
             Sales_Center_Id,
             Aps_Capacity_State,
             Period_Id,
             Customer_Id  --add by lizhen 2017-09-06
        Into r_Lg_Header.Order_Head_Id,
             r_Lg_Header.Order_Head_State,
             r_Lg_Header.Sales_Center_Id,
             r_Lg_Header.Aps_Capacity_State,
             v_Period_Id,
             r_Lg_Header.Customer_Id  --add by lizhen 2017-09-06
        From (Select Loh.Order_Head_Id,
                     Loh.Order_Head_State,
                     Loh.Sales_Center_Id,
                     Loh.Aps_Capacity_State,
                     Null Period_Id,
                     Loh.Customer_Id  --add by lizhen 2017-09-06
                From t_Pln_Lg_Order_Head Loh
               Where Loh.Order_Head_Id = p_Order_Head_Id
                 And v_Source_Order_Type_Id = 1
              Union All
              Select Poh.Order_Head_Id,
                     Poh.Form_State,
                     Poh.Sales_Center_Id,
                     Poh.Aps_Capacity_State,
                     Poh.Period_Id,
                     Poh.Customer_Id  --add by lizhen 2017-09-06
                From t_Pln_Order_Head Poh
               Where Poh.Order_Head_Id = p_Order_Head_Id
                 And v_Source_Order_Type_Id = 0);
    Exception
      When Others Then
        p_Result := '找不到提货订单，提货订单头ID：' || To_Char(p_Order_Head_Id) || v_Nl ||
                    Sqlerrm;
        Raise v_Base_Exception;
    End;
    --校验提货订单申请量是否大于库存可用量加上APS剩余产能
    v_Err_Msg := Null;
    If v_Pln_Capacity_Modle = 'CIMS' And v_Is_Pln_Capacity = 'Y' Then
      For Line_Info In (Select Tl.Producing_Area_Id,
                             Tl.Producing_Area_Name,
                             Tl.Item_Code,
                             Tl.Item_Id,
                             Tl.Quantity,
                             Tl.Aps_Capacity_Rec_Qty,
                             Tl.Order_Line_Id
                        From t_Pln_Lg_Order_Line Tl
                       Where Tl.Order_Head_Id = p_Order_Head_Id
                         And v_Source_Order_Type_Id = 1
                      Union All
                      Select Pol.Producing_Area_Id,
                             Pol.Producing_Area_Name,
                             Pol.Item_Code,
                             Pol.Item_Id,
                             Pol.Apply_Qty,
                             Pol.Aps_Capacity_Rec_Qty,
                             Pol.Order_Line_Id
                        From t_Pln_Order_Line Pol
                       Where Pol.Order_Head_Id = p_Order_Head_Id
                         And v_Source_Order_Type_Id = 0) Loop
        -- 获取月度分配量
        v_Item_Assign := PKG_PLN_PUB.F_GET_ITEM_MONTH_ASSIGN_QTY(IN_ENTITY_ID       => p_Entity_Id,
                                                                 IN_SALES_CENTER_ID => r_Lg_Header.Sales_Center_Id,
                                                                 IN_CUSTOMER_ID     => r_Lg_Header.Customer_Id,
                                                                 IN_ITEM_ID         => Line_Info.Item_Id);
        if Line_Info.Quantity > v_Item_Assign then
          If v_Err_Msg Is Null Then
            v_Err_Msg := '产品编码为【' || Line_Info.Item_Code || '】的申请数量【' ||
                         Line_Info.Quantity || '】> 月度剩余分配量【' ||
                         v_Item_Assign || '】';
          Else
            v_Err_Msg := v_Err_Msg || v_Nl || '产品编码为【' ||
                         Line_Info.Item_Code || '】的申请数量【' ||
                         Line_Info.Quantity || '】> 月度剩余分配量【' ||
                         v_Item_Assign || '】';
          End If;
        end if;                 
      End Loop;
    End If;
    --月分配量不满足时，报异常信息
    If v_Err_Msg Is Not Null Then
      p_Result := v_Err_Msg;
      Raise v_Base_Exception;
    End If;
    --modi by lizhen 2017-04-21
    --获取默设置的订单周期
    If v_Period_Id Is Null Then
      v_Period_Id := f_Get_Parameter_Month_Period(p_Entity_Id   => p_Entity_Id,
                                                  p_Period_Type => 'W',
                                                  p_Date        => p_Order_Check_Date);
    End If;
    --add by lizhen 2017-08-08根据周周期获取月周期信息
    If v_Period_Type = 'M' Then
      Begin
        Select Min(Pac.Period_Id)
          Into v_Period_Id
          From t_Pln_Assenbly_Capacity Pac
         Where Pac.Entity_Id = p_Entity_Id
           And (Select Op.Begin_Date
                  From t_Pln_Order_Period Op
                 Where Op.Period_Id = v_Period_Id) Between Pac.Begin_Date And
               Pac.End_Date;
        /*Select Op.Parent_Period_Id
          Into v_Period_Id
          From t_Pln_Order_Period Op
         Where Op.Period_Id = v_Period_Id;*/
      Exception
        When Others Then
          p_Result := '根据周周期获取月周期数据失败，周周期ID：' || To_Char(v_Period_Id) || v_Nl ||
                    Sqlerrm;
        Raise v_Base_Exception;
      End;
    End If;
    For Line_Info In (Select Tl.Producing_Area_Id,
                             Tl.Producing_Area_Name,
                             Tl.Item_Code,
                             Tl.Item_Id,
                             Tl.Quantity,
                             Tl.Aps_Capacity_Rec_Qty,
                             Tl.Order_Line_Id
                        From t_Pln_Lg_Order_Line Tl
                       Where Tl.Order_Head_Id = p_Order_Head_Id
                         And v_Source_Order_Type_Id = 1
                      Union All
                      Select Pol.Producing_Area_Id,
                             Pol.Producing_Area_Name,
                             Pol.Item_Code,
                             Pol.Item_Id,
                             Pol.Apply_Qty,
                             Pol.Aps_Capacity_Rec_Qty,
                             Pol.Order_Line_Id
                        From t_Pln_Order_Line Pol
                       Where Pol.Order_Head_Id = p_Order_Head_Id
                         And v_Source_Order_Type_Id = 0) Loop
    
      --获取组织ID
      Begin
        Select Tpa.Mrp_Org_Id
          Into v_Organization_Id
          From t_Pln_Producing_Area Tpa
         Where Tpa.Producing_Area_Id = Line_Info.Producing_Area_Id;
      Exception
        When Others Then
          p_Result := '获取组织ID失败,提货订单行ID:' ||
                      To_Char(Line_Info.Order_Line_Id) || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
      End;
    
      --获取库存可用量
      --add by lizhen 2016-12-07增加产能可视模式检查
      If v_Pln_Capacity_Modle = 'APS' Then
        v_Inv_Can_Used := Pkg_Pln_Pub.f_Get_Item_Usable_Qty(p_Entity_Id         => p_Entity_Id,
                                                            p_Item_Id           => Line_Info.Item_Id,
                                                            p_Order_Submit_Type => v_Lg_Order_Submit_Type,
                                                            p_Sales_Center_Id   => r_Lg_Header.Sales_Center_Id,
                                                            p_Lg_Order_Noship   => 'Y',
                                                            p_User_Code         => p_User_Code);
        --获取APS剩余产能                                                            
        v_Residual_Capacity := Pkg_Pln_Intf_Aps.f_Get_Item_Capacity_Qty(p_Organization_Id => v_Organization_Id,
                                                                            p_Item_Code       => Line_Info.Item_Code);
      Else
        v_Inv_Can_Used := 0;
        Begin
          Select Ipc.Item_Curr_Capacity_Qty
            Into v_Residual_Capacity
            From v_Pln_Item_Period_Capacity Ipc
           Where Ipc.Item_Id = Line_Info.Item_Id
             And Ipc.Producing_Area_Id = Line_Info.Producing_Area_Id
             And Ipc.Period_Id = v_Period_Id
             And Ipc.Entity_Id = p_Entity_Id;
        Exception
          When No_Data_Found Then
            --未查找到产能设置，表示该产品不做产能检查，把数据设置成特别大
            v_Residual_Capacity := 9999999999;
          When Others Then
            p_Result := '获取产品剩余产能失败！' || v_Nl || '产品编码：' ||
                        Line_Info.Item_Code || v_Nl || Sqlerrm;
            Raise v_Base_Exception;
        End;
      End If;
      If Line_Info.Quantity > v_Inv_Can_Used Then
        If Line_Info.Quantity - v_Inv_Can_Used > v_Residual_Capacity And
           r_Lg_Header.Order_Head_State != '2225' Then
          If v_Err_Msg Is Null Then
            v_Err_Msg :=  '产品编码为【' || Line_Info.Item_Code || '】的申请数量【' ||
                         Line_Info.Quantity || '】> 产品可用量【' ||
                         v_Inv_Can_Used || '】+' || v_Pln_Capacity_Modle ||
                         '剩余产能【' || v_Residual_Capacity || '】';
          Else
            v_Err_Msg := v_Err_Msg || v_Nl || '产品编码为【' ||
                         Line_Info.Item_Code || '】的申请数量【' ||
                         Line_Info.Quantity || '】> 产品可用量【' ||
                         v_Inv_Can_Used || '】+' || v_Pln_Capacity_Modle ||
                         '剩余产能【' || v_Residual_Capacity || '】';
          End If;
          v_Err_Msg := v_Err_Msg || '产地：' || Line_Info.Producing_Area_Name || '  ';
        Elsif Line_Info.Quantity - v_Inv_Can_Used > v_Residual_Capacity And
              r_Lg_Header.Order_Head_State = '2225' And
              r_Lg_Header.Aps_Capacity_State In ('S', 'Q') Then
          --ADD BY LIZHEN 2016-05-17 已引入APS产能可视且处理完成的数据，进行2次送审时，不检查单一机型数量
          If Line_Info.Quantity - v_Inv_Can_Used >
             Nvl(Line_Info.Aps_Capacity_Rec_Qty, 0) Then
            If v_Err_Msg Is Null Then
              v_Err_Msg := '产品编码为【' || Line_Info.Item_Code || '】的申请数量【' ||
                           Line_Info.Quantity || '】> 产品可用量【' ||
                           v_Inv_Can_Used || '】+' || v_Pln_Capacity_Modle ||
                           '反馈产能【' || Line_Info.Aps_Capacity_Rec_Qty || '】';
            Else
              v_Err_Msg := v_Err_Msg || v_Nl || '产品编码为【' ||
                           Line_Info.Item_Code || '】的申请数量【' ||
                           Line_Info.Quantity || '】> 产品可用量【' ||
                           v_Inv_Can_Used || '】+' || v_Pln_Capacity_Modle ||
                           '反馈产能【' || Line_Info.Aps_Capacity_Rec_Qty || '】';
            End If;
            v_Err_Msg := v_Err_Msg || '产地：' || Line_Info.Producing_Area_Name || '  ';
          End If;
        End If;
      End If;
    End Loop;
    If v_Err_Msg Is Not Null Then
       p_Chk_Msg := '检查产品产能存在异常，异常原因：' || v_Nl || v_Err_Msg;
      --add by lizhen 2017-08-28非严控时返回警告标志
      If v_Capacity_Strict_Control = 'STRICT' Then
        p_Result := v_Failure;
      Else
        p_Result := v_Warning;
        p_Chk_Msg := p_Chk_Msg || v_Nl || '总部周期产能用完，本周期难以满足，是否续继提交？';
      End If;
      
    End If;
  Exception
    When v_Base_Exception Then
      p_Chk_Msg := p_Result;
      p_Result := v_Failure;
      Rollback;
    When Others Then
      p_Chk_Msg := p_Result || v_Nl || Sqlerrm;
      p_Result := v_Failure;
      Rollback;
  End;
  
  ------------------------------------------------------------------------------------------
  ---- AUTHOR  : ex_dengjh
  -- CREATED : 2017-04-07
  -- PURPOSE : 根据订单行ID，占用分配量
  ------------------------------------------------------------------------------------------
  Procedure p_Pln_Assign_Occupy(In_Entity_Id     In Number, --主体ID
                                In_Order_Head_Id In Number, --订单头ID
                                In_Order_Line_Id In Number, --订单行ID
                                In_Source_Type   In Number, --单据源类型  0：计划订单  1：提货订单
                                In_Assign_Qty    In Number, --占用数量
                                In_Assign_Sign   In Number, --占用标志，1：占用，-1：释放
                                In_User_Code     In Varchar2, --用户
                                Out_Result       Out Varchar2 --返回结果，成功返回SUCCESS，否则返回错误信息
                                ) Is
    v_Sales_Center_Id Number;
    v_Item_Id         Number;
    v_Item_Code       t_Pln_Lg_Order_Line.Item_Code%Type;
    v_Assign_Qty      Number;
    v_Customer_Id     Number;
  Begin
    Out_Result := v_Success;
    --查询订单头信息
    Begin
      Select Sales_Center_Id, Customer_Id, Item_Id, Item_Code
        Into v_Sales_Center_Id, v_Customer_Id, v_Item_Id, v_Item_Code
        From (Select Loh.Order_Head_Id,
                     Loh.Entity_Id,
                     Loh.Sales_Center_Id,
                     Loh.Customer_Id,
                     Lol.Item_Id,
                     Lol.Item_Code
                From t_Pln_Lg_Order_Head Loh, t_Pln_Lg_Order_Line Lol
               Where Loh.Order_Head_Id = In_Order_Head_Id
                 And Loh.Order_Head_Id = Lol.Order_Head_Id
                 And Lol.Order_Line_Id = In_Order_Line_Id
                 And In_Source_Type = 1
              Union All
              Select Poh.Order_Head_Id,
                     Poh.Entity_Id,
                     Poh.Sales_Center_Id,
                     Poh.Customer_Id,
                     Pol.Item_Id,
                     Pol.Item_Code
                From t_Pln_Order_Head Poh, t_Pln_Order_Line Pol
               Where Poh.Order_Head_Id = In_Order_Head_Id
                 And Poh.Order_Head_Id = Pol.Order_Head_Id
                 And Pol.Order_Line_Id = In_Order_Line_Id
                 And In_Source_Type = 0);
    Exception
      When Others Then
        Out_Result := '获取订单头信息失败！' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;
   
    If In_Assign_Sign = 1 Then
      --获取剩余分配量
      v_Assign_Qty := Pkg_Pln_Pub.f_Get_Item_Month_Assign_Qty(In_Entity_Id       => In_Entity_Id,
                                                              In_Sales_Center_Id => v_Sales_Center_Id,
                                                              In_Customer_Id     => v_Customer_Id,
                                                              In_Item_Id         => v_Item_Id);
      If In_Assign_Qty > v_Assign_Qty Then
        Out_Result := '剩余分配量不足，产品=' || v_Item_Code || '当前剩余分配量=' ||
                      To_Char(v_Assign_Qty);
        Raise v_Base_Exception;
      End If;
    End If;
    If In_Assign_Sign = 1 And v_Assign_Qty = 9999999999 Then
      --9999999999表示没维护分配量，不需处理
      Out_Result := v_Success;
    Else
      If Out_Result = v_Success Then
        --更新占用分配量
        Update t_Pln_Hq_Month_Assign Hma
           Set Hma.Occupy_Qty       = Hma.Occupy_Qty +
                                      (In_Assign_Sign * In_Assign_Qty),
               Hma.Last_Updated_By  = In_User_Code,
               Hma.Last_Update_Date = Sysdate
         Where Hma.Entity_Id = In_Entity_Id
           And Hma.Sales_Center_Id = v_Sales_Center_Id
           And Hma.Customer_Id = v_Customer_Id
           And Hma.Item_Id = v_Item_Id
           and hma.period_begin_date <= to_date(to_char(sysdate, 'yyyy/mm/dd'), 'yyyy/mm/dd') -- 张开安 2018-05-09 添加
           and hma.period_end_date >= to_date(to_char(sysdate, 'yyyy/mm/dd'), 'yyyy/mm/dd');
        
        -- 张开安 2018-05-07 添加小类分配更新，根据itemId找salesSubType
        update t_pln_hq_month_assign hma
           set hma.occupy_qty       = hma.occupy_qty +
                                      (IN_ASSIGN_SIGN * IN_ASSIGN_QTY),
               hma.last_updated_by  = IN_USER_CODE,
               hma.last_update_date = sysdate
         where hma.entity_id = IN_ENTITY_ID
           and hma.sales_center_id = v_sales_center_id
           and hma.customer_id = v_Customer_Id
           and hma.item_id is null
           and exists (select 1
                  from t_bd_item bi
                 where bi.active_flag = 'Y'
                   and bi.entity_id = hma.entity_id
                   and bi.sales_main_type = hma.sales_main_type
                   and bi.sales_sub_type = hma.sales_sub_type
                   and bi.item_id = v_item_id
                   and bi.entity_id = IN_ENTITY_ID)
           and hma.period_begin_date <= to_date(to_char(sysdate, 'yyyy/mm/dd'), 'yyyy/mm/dd')
           and hma.period_end_date >= to_date(to_char(sysdate, 'yyyy/mm/dd'), 'yyyy/mm/dd');
        
        -- 张开安 2018-05-07 添加大类分配更新，根据itemId找salesMainType
        update t_pln_hq_month_assign hma
           set hma.occupy_qty       = hma.occupy_qty +
                                      (IN_ASSIGN_SIGN * IN_ASSIGN_QTY),
               hma.last_updated_by  = IN_USER_CODE,
               hma.last_update_date = sysdate
         where hma.entity_id = IN_ENTITY_ID
           and hma.sales_center_id = v_sales_center_id
           and hma.customer_id = v_Customer_Id
           and hma.item_id is null
           and hma.sales_sub_type is null
           and exists (select 1
                  from t_bd_item bi
                 where bi.active_flag = 'Y'
                   and bi.entity_id = hma.entity_id
                   and bi.sales_main_type = hma.sales_main_type
                   and bi.item_id = v_item_id
                   and bi.entity_id = IN_ENTITY_ID)
           and hma.period_begin_date <= to_date(to_char(sysdate, 'yyyy/mm/dd'), 'yyyy/mm/dd')
           and hma.period_end_date >= to_date(to_char(sysdate, 'yyyy/mm/dd'), 'yyyy/mm/dd');
      
        Update t_Pln_Hq_Month_Assign Hma
           Set Hma.Occupy_Qty = 0
         Where Hma.Entity_Id = In_Entity_Id
           And Hma.Sales_Center_Id = v_Sales_Center_Id
           And Hma.Customer_Id = v_Customer_Id
           /* 张开安 2018-05-07 注：增加大小类，产品可以为空
           And Hma.Item_Id = v_Item_Id
           */
           And Hma.Occupy_Qty < 0;
      
        If In_Source_Type = 1 Then
          --更新提货订单行表数量
          Update t_Pln_Lg_Order_Line l
             Set l.Occupy_Assign_Qty = l.Occupy_Assign_Qty +
                                       (In_Assign_Sign * In_Assign_Qty)
           Where l.Order_Line_Id = In_Order_Line_Id;
        Elsif In_Source_Type = 0 Then
          --更新提货订单行表数量
          Update t_Pln_Order_Line l
             Set l.Occupy_Assign_Qty = l.Occupy_Assign_Qty +
                                       (In_Assign_Sign * In_Assign_Qty)
           Where l.Order_Line_Id = In_Order_Line_Id;
        End If;
      End If;
    End If;
  Exception
    When v_Base_Exception Then
      Out_Result := Out_Result || v_Nl ||
                    'Pkg_Pln_Lg_Order.p_pln_assign_occupy过程失败。';
    When Others Then
      Out_Result := Out_Result || v_Nl ||
                    'Pkg_Pln_Lg_Order.p_pln_assign_occupy过程失败。';
  End;


  -------------------------------------------------------------------------
  -- Author  : NICRO.LI
  -- Created : 2016-12-08 13:57:33
  -- Purpose : 订单产能可视串行占用产能数据
  -------------------------------------------------------------------------
  Procedure p_Capacity_Occupy(p_Order_Head_Id    In Number, --传入提货订单头ID，计划订单头ID
                              p_Order_Type_Id    In Number, --单据类型ID
                              p_Order_Check_Date In Date, --订单送审日期
                              p_Capacity_Sign    In Number, --占用标志：1：占用  -1：释放
                              p_User_Code        In Varchar2, --用户编码
                              p_Result           Out Varchar2 --返回信息 SUCCESS:正常
                              ) Is
    v_Source_Order_Type_Id        Number;
    v_Entity_Id                   Number;
    v_Pln_Capacity_Advance_Period Number;
    v_Period_Id                   Number;
    v_Count                       Number := 0;
    v_Day                         Number;
    v_Month_Max_Day               Number;
    v_Period_Begin_Date           Date;
    v_Fmt_Sql                     Varchar2(4000);
    v_Upd_Sql                     Varchar2(4000);
    v_Surplus_Capacity_Qty        Number := 0;
    v_Occupy_Capacity_Qty         Number := 0;
    v_Line_Capacity_Qty           Number := 0;
    v_Assenbly_Capacity_List      Varchar2(4000);
  
    Type c_Get_Capacity Is Ref Cursor; --声明动态游标
    v_Get_Capacity c_Get_Capacity;
    r_Get_Capacity t_Pln_Assenbly_Capacity%Rowtype;
  
    v_Line_Capacity_Date   Date; --产能接单日期
    v_date                 Date;
    v_date1                Date;
    v_Day_Capacity_Sum_Qty Number := 0; --日产能合计
  Begin
    p_Result := v_Success;
    If p_Capacity_Sign Not In (1, -1) Then
      p_Result := '检查产能占用标志，函数不接受非占用(1)、释放(-1)以外的参数！';
      Raise v_Base_Exception;
    End If;
  
    Begin
      Select Pot.Source_Order_Type_Id
        Into v_Source_Order_Type_Id
        From t_Pln_Order_Type Pot
       Where Pot.Order_Type_Id = p_Order_Type_Id;
    Exception
      When Others Then
        p_Result := '获取订单单据类型信息失败!' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;
  
    If v_Source_Order_Type_Id Not In (0, 1) Then
      p_Result := '检查源订单单据类型失败，系统只支持提货订单、计划订单产能可视!';
      Raise v_Base_Exception;
    End If;
  
    --查询订单头信息
    Begin
      Select Entity_Id, Period_Id
        Into v_Entity_Id, v_Period_Id
        From (Select Loh.Order_Head_Id, Loh.Entity_Id, Null Period_Id
                From t_Pln_Lg_Order_Head Loh
               Where Loh.Order_Head_Id = p_Order_Head_Id
                 And v_Source_Order_Type_Id = 1
              Union All
              Select Poh.Order_Head_Id, Poh.Entity_Id, Poh.Period_Id
                From t_Pln_Order_Head Poh
               Where Poh.Order_Head_Id = p_Order_Head_Id
                 And v_Source_Order_Type_Id = 0);
    Exception
      When Others Then
        p_Result := '获取订单头信息失败！' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;
  
    If v_Source_Order_Type_Id = 1 Then
      --add by lizhen 2016-12-14
      --获取系统参数产能可视订单周期提前期设置
      Begin
        v_Pln_Capacity_Advance_Period := Pkg_Bd.f_Get_Parameter_Value('PLN_CAPACITY_ADVANCE_PERIOD',
                                                                      v_Entity_Id);
      Exception
        When Others Then
          p_Result := '获取产能可视订单周期提前期参数PLN_CAPACITY_ADVANCE_PERIOD参数失败！' || v_Nl ||
                      Sqlerrm;
          Raise v_Base_Exception;
      End;
      --获取默设计的订单周期
      v_Count := 0;
      Begin
        For r_Period In (Select Pop.Parent_Period_Id,
                                Pop.Period_Id,
                                To_Char(Pop.Begin_Date, 'DD') Bday,
                                Pop.Begin_Date
                           From t_Pln_Order_Period Pop
                          Where Pop.End_Date >= p_Order_Check_Date
                            And Pop.Period_Type = 'T+3周期'
                            And Pop.Entity_Id = v_Entity_Id
                          Order By Pop.Period_Code) Loop
          If v_Count = v_Pln_Capacity_Advance_Period Then
            Select Pop.Period_Id,
                   To_Number(To_Char(Pop.End_Date, 'DD'))
              Into v_Period_Id, v_Month_Max_Day
              From t_Pln_Order_Period Pop
             Where Pop.Period_Id = r_Period.Parent_Period_Id;
            v_Day := To_Number(r_Period.Bday);
            v_Period_Begin_Date := r_Period.Begin_Date;
            Exit;
          End If;
          v_Count := v_Count + 1;
        End Loop;
      Exception
        When Others Then
          p_Result := '提货订单获取默认订单周期失败！' || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
      End;
    Else
      Begin
        Select Pop.Period_Id, To_Char(Pop.Begin_Date, 'DD'), Pop.Begin_Date
          Into v_Period_Id, v_Day, v_Period_Begin_Date
          From t_Pln_Order_Period Pop
         Where Pop.Period_Id = v_Period_Id;
      
        Select To_Number(To_Char(Op.End_Date, 'DD')), Op.Period_Id
          Into v_Month_Max_Day, v_Period_Id
          From t_Pln_Order_Period Op
         Where Op.Period_Id =
               (Select Pop.Parent_Period_Id
                  From t_Pln_Order_Period Pop
                 Where Pop.Period_Id = v_Period_Id);
      Exception
        When Others Then
          p_Result := '提货订单获取默认订单周期失败！' || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
      End;
    End If;
  
    If v_Period_Begin_Date <= Trunc(Sysdate) Then
      p_Result := '检查周期所属日期范围，周期开始日期不可小于服务器当前日期！';
      Raise v_Base_Exception;
    End If;
  
    --开始循环处理行产品占用
    For r_Line In (Select Lol.Quantity,
                          Lol.Producing_Area_Id,
                          Lol.Item_Id,
                          Lol.Item_Code,
                          Lol.Item_Name,
                          Lol.Order_Line_Id,
                          Lol.Aps_Capacity_Rec_Qty,
                          Lol.To_Aps_Capacity_Qty,
                          Lol.Occupy_Assign_Qty
                     From t_Pln_Lg_Order_Line Lol
                    Where Lol.Order_Head_Id = p_Order_Head_Id
                      And v_Source_Order_Type_Id = 1
                   Union All
                   Select Pol.Apply_Qty,
                          Pol.Producing_Area_Id,
                          Pol.Item_Id,
                          Pol.Item_Code,
                          Pol.Item_Desc Item_Name,
                          Pol.Order_Line_Id,
                          Pol.Aps_Capacity_Rec_Qty,
                          Pol.To_Aps_Capacity_Qty,
                          Pol.Occupy_Assign_Qty
                     From t_Pln_Order_Line Pol
                    Where Pol.Order_Head_Id = p_Order_Head_Id
                      And v_Source_Order_Type_Id = 0) Loop
      --add by lizhen 2017-09-07月分配数量占用
      p_Pln_Assign_Occupy(In_Entity_Id     => v_Entity_Id, --主体ID
                          In_Order_Head_Id => p_Order_Head_Id, --订单头ID
                          In_Order_Line_Id => r_Line.Order_Line_Id, --订单行ID
                          In_Source_Type   => v_Source_Order_Type_Id, --单据源类型  0：计划订单  1：提货订单
                          In_Assign_Qty    => r_Line.Quantity, --占用数量
                          In_Assign_Sign   => p_Capacity_Sign, --占用标志，1：占用，-1：释放
                          In_User_Code     => p_User_Code, --用户
                          Out_Result       => p_Result --返回结果，成功返回SUCCESS，否则返回错误信息
                          );
      If p_Result != v_Success Then
        Raise v_Base_Exception;
      End If;
      v_Fmt_Sql := Null;
      For i In v_Day .. v_Month_Max_Day Loop
        If v_Fmt_Sql Is Null Then
          v_Fmt_Sql := 'Pac.DAY_CAPACITY_' || Trim(To_Char(i, '00'));
        Else
          v_Fmt_Sql := v_Fmt_Sql || ' + Pac.DAY_CAPACITY_' ||
                       Trim(To_Char(i, '00'));
        End If;
      End Loop;
      --获取当月剩余产能
      Begin
        v_Fmt_Sql := 'Select ' || Chr(10) ||
                     '       Listagg(Assenbly_Capacity_Id, '','') Within Group(Order By Assenbly_Capacity_Id) Assenbly_Capacity_Id,' || Chr(10) || 
                     '       Min(Case' || Chr(10) ||
                     '             When Surplus_Capacity < 0 Then' || Chr(10) || 
                     '              0' || Chr(10) ||
                     '             Else' || Chr(10) ||
                     '              Surplus_Capacity' || Chr(10) ||
                     '           End) Surplus_Capacity' || Chr(10) ||
                     '  From (Select Tbi.Item_Id,' || Chr(10) ||
                     '               Tbi.Item_Code,' || Chr(10) ||
                     '               Tbi.Item_Name,' || Chr(10) ||
                     '               Pac.Assenbly_Capacity_Id,' || Chr(10) ||
                     '               Icr.Capacity_Type,' || Chr(10) ||
                     '               Pac.Capacity_Class_Code,' || Chr(10) ||
                     '               Pac.Producing_Area_Id,' || Chr(10) ||
                     '               Pac.Producing_Area_Code,' || Chr(10) ||
                     '               Pac.Producing_Area_Name,' || Chr(10) || --v_Fmt_Sql ||
                     '   Nvl(Pac.Remain_Capacity, 0) - Nvl(Pac.Occupy_Capacity, 0) Surplus_Capacity,' || Chr(10) || 
                     '               Pac.Period_Id,' || Chr(10) ||
                     '               Pac.Period_Code,' || Chr(10) ||
                     '               Pac.Entity_Id' || Chr(10) ||
                     '          From t_Pln_Assenbly_Capacity      Pac,' ||Chr(10) ||
                     '               t_Pln_Item_Capacity_Relation Icr,' || Chr(10) ||
                     '               t_Bd_Item                    Tbi' || Chr(10) ||
                     '         Where Pac.Capacity_Type = Icr.Capacity_Type' || Chr(10) ||
                     '           And Pac.Capacity_Class_Code = Icr.Capacity_Class_Code' || Chr(10) ||
                     '           And Pac.Entity_Id = Icr.Entity_Id' ||Chr(10) || 
                     '           And Icr.Capacity_Type = ''ZZ''' || Chr(10) ||
                     '           And Icr.Item_Or_Class_Code = Tbi.Sales_Sub_Type' || Chr(10) ||
                     '           And Icr.Entity_Id = Tbi.Entity_Id' || Chr(10) ||
                     '           And Trunc(Sysdate) Between Icr.Begin_Date And' || Chr(10) || 
                     '               Nvl(Icr.End_Date, Sysdate)' || Chr(10) || 
                     '        Union All' || Chr(10) ||
                     '        Select Tbi.Item_Id,' || Chr(10) ||
                     '               Tbi.Item_Code,' || Chr(10) ||
                     '               Tbi.Item_Name,' || Chr(10) ||
                     '               Pac.Assenbly_Capacity_Id,' || Chr(10) ||
                     '               Icr.Capacity_Type,' || Chr(10) ||
                     '               Pac.Capacity_Class_Code,' || Chr(10) ||
                     '               Pac.Producing_Area_Id,' || Chr(10) ||
                     '               Pac.Producing_Area_Code,' || Chr(10) ||
                     '               Pac.Producing_Area_Name,' || Chr(10) || --v_Fmt_Sql ||
                     '               Nvl(Pac.Remain_Capacity, 0) - Nvl(Pac.Occupy_Capacity, 0) Surplus_Capacity,' || Chr(10) || 
                     '               Pac.Period_Id,' || Chr(10) ||
                     '               Pac.Period_Code,' || Chr(10) ||
                     '               Pac.Entity_Id' || Chr(10) ||
                     '          From t_Pln_Assenbly_Capacity      Pac,' || Chr(10) ||
                     '               t_Pln_Item_Capacity_Relation Icr,' || Chr(10) ||
                     '               t_Bd_Item                    Tbi' || Chr(10) ||
                     '         Where Pac.Capacity_Type = Icr.Capacity_Type' || Chr(10) ||
                     '           And Pac.Capacity_Class_Code = Icr.Capacity_Class_Code' || Chr(10) ||
                     '           And Pac.Entity_Id = Icr.Entity_Id' || Chr(10) || 
                     '           And Icr.Capacity_Type = ''MJ''' || Chr(10) ||
                     '           And Icr.Item_Or_Class_Id = Tbi.Item_Id' || Chr(10) ||
                     '           And Trunc(Sysdate) Between Icr.Begin_Date And' || Chr(10) ||
                     '               Nvl(Icr.End_Date, Sysdate))' || Chr(10) || 
                     ' Where Producing_Area_Id = :1' || Chr(10) ||
                     '   And Period_Id = :2' || Chr(10) ||
                     '   And Item_Code = :3' || Chr(10) ||
                     ' Group By Item_Id, Item_Code, Producing_Area_Id, Period_Id, Entity_Id ';
      
        Execute Immediate v_Fmt_Sql
          Into v_Assenbly_Capacity_List, v_Surplus_Capacity_Qty
          Using r_Line.Producing_Area_Id, v_Period_Id, r_Line.Item_Code;
        --dbms_output.put_line(v_Fmt_Sql);
      Exception
        When Others Then
          p_Result := '获取产能信息失败！' || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
      End;
    
      If p_Capacity_Sign = 1 Then
        --获取剩余产能数量,允许部份占用
        v_Line_Capacity_Qty := Least(Nvl(r_Line.Quantity, 0) - Nvl(r_Line.Aps_Capacity_Rec_Qty, 0),
                                     Nvl(v_Surplus_Capacity_Qty, 0));
        v_Fmt_Sql           := 'Select * From t_Pln_Assenbly_Capacity Pac ' ||
                               ' Where Pac.Assenbly_Capacity_Id In (' ||
                               v_Assenbly_Capacity_List || ') for update nowait';
        --打开产能设置游标
        Begin
          Open v_Get_Capacity For v_Fmt_Sql;
        Exception
          When Others Then
            p_Result := '打开产能设置数据失败！' || v_Nl || '产能设置ID:' ||
                        v_Assenbly_Capacity_List || v_Nl || Sqlerrm;
            Raise v_Base_Exception;
        End;
        v_Line_Capacity_Date := To_Date('2016-01-01', 'YYYY-MM-DD');
        Loop
          Fetch v_Get_Capacity
            Into r_Get_Capacity;
          Exit When v_Get_Capacity%Notfound;
          v_Day_Capacity_Sum_Qty := 0;
          For i In v_Day .. v_Month_Max_Day Loop
            If i = 1 Then
              v_Day_Capacity_Sum_Qty := v_Day_Capacity_Sum_Qty +
                                        r_Get_Capacity.Day_Capacity_01;
            Elsif i = 2 Then
              v_Day_Capacity_Sum_Qty := v_Day_Capacity_Sum_Qty +
                                        r_Get_Capacity.Day_Capacity_02;
            Elsif i = 3 Then
              v_Day_Capacity_Sum_Qty := v_Day_Capacity_Sum_Qty +
                                        r_Get_Capacity.Day_Capacity_03;
            Elsif i = 4 Then
              v_Day_Capacity_Sum_Qty := v_Day_Capacity_Sum_Qty +
                                        r_Get_Capacity.Day_Capacity_04;
            Elsif i = 5 Then
              v_Day_Capacity_Sum_Qty := v_Day_Capacity_Sum_Qty +
                                        r_Get_Capacity.Day_Capacity_05;
            Elsif i = 6 Then
              v_Day_Capacity_Sum_Qty := v_Day_Capacity_Sum_Qty +
                                        r_Get_Capacity.Day_Capacity_06;
            Elsif i = 7 Then
              v_Day_Capacity_Sum_Qty := v_Day_Capacity_Sum_Qty +
                                        r_Get_Capacity.Day_Capacity_07;
            Elsif i = 8 Then
              v_Day_Capacity_Sum_Qty := v_Day_Capacity_Sum_Qty +
                                        r_Get_Capacity.Day_Capacity_08;
            Elsif i = 9 Then
              v_Day_Capacity_Sum_Qty := v_Day_Capacity_Sum_Qty +
                                        r_Get_Capacity.Day_Capacity_09;
            Elsif i = 10 Then
              v_Day_Capacity_Sum_Qty := v_Day_Capacity_Sum_Qty +
                                        r_Get_Capacity.Day_Capacity_10;
            Elsif i = 11 Then
              v_Day_Capacity_Sum_Qty := v_Day_Capacity_Sum_Qty +
                                        r_Get_Capacity.Day_Capacity_11;
            Elsif i = 12 Then
              v_Day_Capacity_Sum_Qty := v_Day_Capacity_Sum_Qty +
                                        r_Get_Capacity.Day_Capacity_12;
            Elsif i = 13 Then
              v_Day_Capacity_Sum_Qty := v_Day_Capacity_Sum_Qty +
                                        r_Get_Capacity.Day_Capacity_13;
            Elsif i = 14 Then
              v_Day_Capacity_Sum_Qty := v_Day_Capacity_Sum_Qty +
                                        r_Get_Capacity.Day_Capacity_14;
            Elsif i = 15 Then
              v_Day_Capacity_Sum_Qty := v_Day_Capacity_Sum_Qty +
                                        r_Get_Capacity.Day_Capacity_15;
            Elsif i = 16 Then
              v_Day_Capacity_Sum_Qty := v_Day_Capacity_Sum_Qty +
                                        r_Get_Capacity.Day_Capacity_16;
            Elsif i = 17 Then
              v_Day_Capacity_Sum_Qty := v_Day_Capacity_Sum_Qty +
                                        r_Get_Capacity.Day_Capacity_17;
            Elsif i = 18 Then
              v_Day_Capacity_Sum_Qty := v_Day_Capacity_Sum_Qty +
                                        r_Get_Capacity.Day_Capacity_18;
            Elsif i = 19 Then
              v_Day_Capacity_Sum_Qty := v_Day_Capacity_Sum_Qty +
                                        r_Get_Capacity.Day_Capacity_19;
            Elsif i = 20 Then
              v_Day_Capacity_Sum_Qty := v_Day_Capacity_Sum_Qty +
                                        r_Get_Capacity.Day_Capacity_20;
            Elsif i = 21 Then
              v_Day_Capacity_Sum_Qty := v_Day_Capacity_Sum_Qty +
                                        r_Get_Capacity.Day_Capacity_21;
            Elsif i = 22 Then
              v_Day_Capacity_Sum_Qty := v_Day_Capacity_Sum_Qty +
                                        r_Get_Capacity.Day_Capacity_22;
            Elsif i = 23 Then
              v_Day_Capacity_Sum_Qty := v_Day_Capacity_Sum_Qty +
                                        r_Get_Capacity.Day_Capacity_23;
            Elsif i = 24 Then
              v_Day_Capacity_Sum_Qty := v_Day_Capacity_Sum_Qty +
                                        r_Get_Capacity.Day_Capacity_24;
            Elsif i = 25 Then
              v_Day_Capacity_Sum_Qty := v_Day_Capacity_Sum_Qty +
                                        r_Get_Capacity.Day_Capacity_25;
            Elsif i = 26 Then
              v_Day_Capacity_Sum_Qty := v_Day_Capacity_Sum_Qty +
                                        r_Get_Capacity.Day_Capacity_26;
            Elsif i = 27 Then
              v_Day_Capacity_Sum_Qty := v_Day_Capacity_Sum_Qty +
                                        r_Get_Capacity.Day_Capacity_27;
            Elsif i = 28 Then
              v_Day_Capacity_Sum_Qty := v_Day_Capacity_Sum_Qty +
                                        r_Get_Capacity.Day_Capacity_28;
            Elsif i = 29 Then
              v_Day_Capacity_Sum_Qty := v_Day_Capacity_Sum_Qty +
                                        r_Get_Capacity.Day_Capacity_29;
            Elsif i = 30 Then
              v_Day_Capacity_Sum_Qty := v_Day_Capacity_Sum_Qty +
                                        r_Get_Capacity.Day_Capacity_30;
            Elsif i = 31 Then
              v_Day_Capacity_Sum_Qty := v_Day_Capacity_Sum_Qty +
                                        r_Get_Capacity.Day_Capacity_31;
            End If;
            If v_Day_Capacity_Sum_Qty >= Nvl(r_Get_Capacity.Occupy_Capacity, 0) + v_Line_Capacity_Qty Then
              v_Line_Capacity_Date := Greatest(v_Line_Capacity_Date,
                                               To_Date(To_Char(v_Period_Begin_Date, 'YYYY-MM') || '-' ||
                                                       Trim(To_Char(i, '00')),
                                                       'YYYY-MM-DD'));
              Exit;
            End If;
          End Loop;
          --根据日产能无法计算出产能日期时取周期月份最后一天
          If v_Line_Capacity_Date Is Null Then
            v_Line_Capacity_Date := To_Date(To_Char(v_Period_Begin_Date, 'YYYY-MM') || '-' ||
                                            Trim(To_Char(v_Month_Max_Day, '00')),
                                            'YYYY-MM-DD');
          End If;
        End Loop;
      Else
        --释放产能 获取剩余产能数量,允许部份占用
        v_Line_Capacity_Qty := Nvl(r_Line.Aps_Capacity_Rec_Qty, 0);
      End If;
      Begin
        v_Upd_Sql := 'Update t_Pln_Assenbly_Capacity Pac ' ||
                     ' Set Pac.Current_Remain_Capacity = Nvl(Pac.Current_Remain_Capacity, 0) + ' || -1 * v_Line_Capacity_Qty * p_Capacity_Sign || ',' ||
                     ' Pac.Occupy_Capacity  = Nvl(Pac.Occupy_Capacity, 0) + ' || v_Line_Capacity_Qty * p_Capacity_Sign || ',' ||
                     ' Pac.Last_Updated_By = ''' || p_User_Code || ''',' ||
                     ' Pac.Last_Update_Date = Sysdate ' ||
                     ' Where Pac.Assenbly_Capacity_Id In (' ||
                     v_Assenbly_Capacity_List || ')';
        Execute Immediate v_Upd_Sql;
      Exception
        When Others Then
          p_Result := '更新月产能信息失败！' || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
      End;
      --产能占用更新订单行表
      If p_Capacity_Sign = 1 Then
        If v_Source_Order_Type_Id = 1 Then
          Update t_Pln_Lg_Order_Head Loh
             Set Loh.Aps_Capacity_State      = 'S',
                 Loh.Aps_Capacity_Begin_Date = Nvl(Loh.Aps_Capacity_Begin_Date,
                                                   Sysdate),
                 Loh.Aps_Capacity_End_Date   = Sysdate,
                 Loh.Aps_Capacity_By         = p_User_Code
           Where Loh.Order_Head_Id = p_Order_Head_Id;
        
          Update t_Pln_Lg_Order_Line Lol
             Set Lol.Aps_Capacity_Rec_Qty  = v_Line_Capacity_Qty,
                 Lol.Aps_Capacity_Rec_Date = v_Line_Capacity_Date,
                 Lol.To_Aps_Capacity_Qty   = Nvl(r_Line.Quantity, 0),
                 Lol.Last_Updated_By       = p_User_Code,
                 Lol.Last_Update_Date      = Sysdate
           Where Lol.Order_Line_Id = r_Line.Order_Line_Id;
        Elsif v_Source_Order_Type_Id = 0 Then
          Update t_Pln_Order_Head Poh
             Set Poh.Aps_Capacity_State      = 'S',
                 Poh.Aps_Capacity_Begin_Date = Nvl(Poh.Aps_Capacity_Begin_Date,
                                                   Sysdate),
                 Poh.Aps_Capacity_End_Date   = Sysdate,
                 Poh.Aps_Capacity_By         = p_User_Code
           Where Poh.Order_Head_Id = p_Order_Head_Id;
           
          Update t_Pln_Order_Line Pol
             Set Pol.Aps_Capacity_Rec_Qty  = v_Line_Capacity_Qty,
                 Pol.Aps_Capacity_Rec_Date = v_Line_Capacity_Date,
                 Pol.To_Aps_Capacity_Qty = Nvl(Pol.Apply_Qty, 0),
                 Pol.Last_Updated_By       = p_User_Code,
                 Pol.Last_Update_Date      = Sysdate
           Where Pol.Order_Line_Id = r_Line.Order_Line_Id;
        End If;
      End If;
      --插入CIMS产能占用历史记录表
      Begin
        Insert Into t_Pln_Capacity_Occupy_His
          (Occupy_His_Id,
           Entity_Id,
           Order_Head_Id,
           Order_Type_Id,
           Period_Id,
           Producing_Area_Id,
           Item_Id,
           Occupy_Sign_Flag,
           Occupy_Qty,
           Capacity_Assenply_Id,
           Created_By,
           Creation_Date,
           Last_Updated_By,
           Last_Update_Date,
           Remark,
           Version)
        Values
          (s_Pln_Capacity_Occupy_His.Nextval,
           v_Entity_Id,
           p_Order_Head_Id,
           p_Order_Type_Id,
           v_Period_Id,
           r_Line.Producing_Area_Id,
           r_Line.Item_Id,
           p_Capacity_Sign,
           v_Line_Capacity_Qty,
           v_Assenbly_Capacity_List,
           p_User_Code,
           Sysdate,
           p_User_Code,
           Sysdate,
           Null,
           1);
      Exception
        When Others Then
          p_Result := '插入t_Pln_Capacity_Occupy_His表数据失败！' || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
      End;
    End Loop;
  Exception
    When v_Base_Exception Then
      p_Result := '产能可视产能占用失败!' || v_Nl || p_Result;
    When Others Then
      p_Result := '产能可视产能占用失败!' || p_Result || v_Nl || Sqlerrm;
  End;
  
  -------------------------------------------------------------------------
  -- Author  : NICRO.LI
  -- Created : 2016-12-08 13:57:33
  -- Purpose : 订单产能可视串行占用产能数据
  --           产能类型：W:按T+3周期计算产能且实时对比  M:按月计算剩余产能
  -------------------------------------------------------------------------
  Procedure p_Capacity_Occupy_New(p_Order_Head_Id    In Number, --传入提货订单头ID，计划订单头ID
                                  p_Order_Type_Id    In Number, --单据类型ID
                                  p_Order_Check_Date In Date, --订单送审日期
                                  p_Capacity_Sign    In Number, --占用标志：1：占用  -1：释放
                                  p_Capacity_Type    In Varchar2, --产能类型：W:按周  M:按月  
                                  p_User_Code        In Varchar2, --用户编码
                                  p_Result           Out Varchar2 --返回信息 SUCCESS:正常
                                  ) Is
    v_Source_Order_Type_Id        Number;
    v_Entity_Id                   Number;
    v_Month_Period_Id             Number;
    v_Curr_Period_Id              Number;
    v_Err_Msg                     Varchar2(4000);
    v_Begin_Day        Number;
    v_End_Day          Number;
    v_Month                 Varchar2(12);
    v_Sql_Field             Varchar2(2000);
    v_Sql                   Varchar2(2000);
    v_Lgorder_Occupy_Qty    Number;
    v_Plnorder_Occupy_Qty   Number;
    v_Item_Day_Capacity_Qty Number;
    v_Line_Capacity_Date    Date;
    v_Item_Capacity_Qty     Number;
    v_Capacity_Occupy_Qty   Number := 0;
    v_Capacity_Period_Occupy_Qty  Number := 0;
    v_Capacity_Insufficient_Flag    Varchar2(3) := 'N';
  Begin
    p_Result := v_Success;
    If p_Capacity_Sign Not In (1, -1) Then
      p_Result := '检查产能占用标志，函数不接受非占用(1)、释放(-1)以外的参数！';
      Raise v_Base_Exception;
    End If;
    
    If p_Capacity_Type Not In ('W', 'M') Then
      p_Result := '检查产能占用类型，函数不接受按周(W)、按月(M)以外的参数！';
      Raise v_Base_Exception;
    End If;
  
    Begin
      Select Pot.Source_Order_Type_Id
        Into v_Source_Order_Type_Id
        From t_Pln_Order_Type Pot
       Where Pot.Order_Type_Id = p_Order_Type_Id;
    Exception
      When Others Then
        p_Result := '获取订单单据类型信息失败!' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;
  
    If v_Source_Order_Type_Id Not In (0, 1) Then
      p_Result := '检查源订单单据类型失败，系统只支持提货订单、计划订单产能可视!';
      Raise v_Base_Exception;
    End If;
  
    --查询订单头信息
    Begin
      Select Entity_Id, Period_Id
        Into v_Entity_Id, v_Curr_Period_Id
        From (Select Loh.Order_Head_Id,
                     Loh.Entity_Id,
                     f_Get_Parameter_Month_Period(p_Entity_Id   => Loh.Entity_Id,
                                                  p_Period_Type => 'W',
                                                  p_Date        => p_Order_Check_Date) Period_Id
                From t_Pln_Lg_Order_Head Loh
               Where Loh.Order_Head_Id = p_Order_Head_Id
                 And v_Source_Order_Type_Id = 1
              Union All
              Select Poh.Order_Head_Id, Poh.Entity_Id, Poh.Period_Id
                From t_Pln_Order_Head Poh
               Where Poh.Order_Head_Id = p_Order_Head_Id 
                 And v_Source_Order_Type_Id = 0);
    Exception
      When Others Then
        p_Result := '获取订单头信息失败！' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;
    
    --检查产能数据
    p_Chk_Item_Capacity(p_Entity_Id        => v_Entity_Id,
                        p_Order_Head_Id    => p_Order_Head_Id,
                        p_Order_Type_Id    => p_Order_Type_Id,
                        p_Order_Check_Date => p_Order_Check_Date,
                        p_User_Code        => p_User_Code,
                        p_Result           => p_Result,
                        p_Chk_Msg          => v_Err_Msg);
    --警各时，后台不进行错误数据提示
    If p_Result = v_Failure Then
      p_Result := v_Err_Msg;
      Raise v_Base_Exception;
    Else
      p_Result := v_Success;
    End If;
      
    --获取周周期的开始、结束日期
    Begin
      Select To_Number(To_Char(Op.Begin_Date, 'DD')),
             To_Number(To_Char(Op.End_Date, 'DD')),
             To_Char(Op.Begin_Date, 'YYYY-MM'),
             Op.Parent_Period_Id
        Into v_Begin_Day, v_End_Day, v_Month, v_Month_Period_Id
        From t_Pln_Order_Period Op
       Where Op.Period_Id = v_Curr_Period_Id;
    Exception
      When Others Then
        p_Result := '获取订单周期信息失败！' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;
    --add by lizhen 2017-08-08根据周周期ID获取月周期信息
    If p_Capacity_Type = 'M' Then
      --获取月周期的开始、结束日期
      Begin
        Select To_Number(To_Char(Op.End_Date, 'DD')),
               To_Char(Op.Begin_Date, 'YYYY-MM'),
               Op.Period_Id
          Into v_End_Day, v_Month, v_Curr_Period_Id
          From t_Pln_Order_Period Op
         Where Op.Period_Id = v_Month_Period_Id;
      Exception
        When Others Then
          p_Result := '获取订单月周期信息失败！' || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
      End;
    End If;
    
    --产能占用更新订单行表
    --开始循环处理行产品占用
    For r_Line In (Select Lol.Quantity,
                          Lol.Producing_Area_Id,
                          Lol.Item_Id,
                          Lol.Item_Code,
                          Lol.Item_Name,
                          Lol.Order_Line_Id,
                          Lol.Aps_Capacity_Rec_Qty,
                          Lol.To_Aps_Capacity_Qty,
                          Lol.Pln_Affirmed_Qty,  --add by lizhen
                          Lol.Occupy_Assign_Qty --add by lizhen 2017-09-07
                     From t_Pln_Lg_Order_Line Lol
                    Where Lol.Order_Head_Id = p_Order_Head_Id
                      And v_Source_Order_Type_Id = 1
                   Union All
                   Select Pol.Apply_Qty,
                          Pol.Producing_Area_Id,
                          Pol.Item_Id,
                          Pol.Item_Code,
                          Pol.Item_Desc Item_Name,
                          Pol.Order_Line_Id,
                          Pol.Aps_Capacity_Rec_Qty,
                          Pol.To_Aps_Capacity_Qty,
                          Pol.Supply_Qty,   --add by lizhen
                          Pol.Occupy_Assign_Qty  --add by lizhen 2-017-09-07
                     From t_Pln_Order_Line Pol
                    Where Pol.Order_Head_Id = p_Order_Head_Id
                      And v_Source_Order_Type_Id = 0) Loop
      If p_Capacity_Sign = 1 Then
        --add by lizhen 2017-09-07月分配数量占用
        p_Pln_Assign_Occupy(In_Entity_Id     => v_Entity_Id, --主体ID
                            In_Order_Head_Id => p_Order_Head_Id, --订单头ID
                            In_Order_Line_Id => r_Line.Order_Line_Id, --订单行ID
                            In_Source_Type   => v_Source_Order_Type_Id, --单据源类型  0：计划订单  1：提货订单
                            In_Assign_Qty    => r_Line.Quantity, --占用数量
                            In_Assign_Sign   => p_Capacity_Sign, --占用标志，1：占用，-1：释放
                            In_User_Code     => p_User_Code, --用户
                            Out_Result       => p_Result --返回结果，成功返回SUCCESS，否则返回错误信息
                            );
        If p_Result != v_Success Then
          Raise v_Base_Exception;
        End If;
      
        v_Line_Capacity_Date := Null;
        
        --获取产品产能对应日期的产能
        v_Sql_Field := Null;
        For i In v_Begin_Day .. v_End_Day Loop
          If v_Sql_Field Is Null Then
             v_Sql_Field := 'Nvl(Pic.Day_Capacity_' || Trim(To_Char(i, '00')) || ', 0)';
          Else
            v_Sql_Field := v_Sql_Field || ' + Nvl(Pic.Day_Capacity_' || Trim(To_Char(i, '00')) || ', 0)';
          End If;
          v_Sql := 'Select Min(' || v_Sql_Field || '- Nvl((Select Nvl(Cpo.Occupy_Qty, 0) - Nvl(Cpo.overdue_occupy_qty, 0) + Nvl(Cpo.Front_Occupy_Qty, 0)
                           From t_Pln_Capacity_Period_Occupy Cpo
                          Where Cpo.Assenbly_Capacity_Id = Pic.Assenbly_Capacity_Id
                            And Cpo.Period_Id = :1
                            And Cpo.Producing_Area_Id = Cpo.Producing_Area_Id),
                         0)) From v_Pln_Item_Capacity Pic
            Where Pic.Item_Code = :2
              And Pic.Period_Id = :3
              And Pic.Producing_Area_Id = :4';
          Begin    
            Execute Immediate v_Sql
              Into v_Item_Day_Capacity_Qty
              Using v_Curr_Period_Id, r_Line.Item_Code, v_Month_Period_Id, r_Line.Producing_Area_Id;
          Exception
            When No_Data_Found Then
              --在产品产能视图里面无数据的则表示产品不受产能控制，返回999999999
              v_Item_Day_Capacity_Qty := 999999999999;
            When Others Then
              p_Result := '获取产品天产能失败！' || v_Nl || Sqlerrm;
              Raise v_Base_Exception;
          End;    

          --产能满足数量 = 本周期产能总数量 - 本次需占用数量 - 产能已反馈数量     
          v_Item_Capacity_Qty := Nvl(v_Item_Day_Capacity_Qty, 0) - Nvl(r_Line.To_Aps_Capacity_Qty, r_Line.Quantity) 
            - Nvl(r_Line.Aps_Capacity_Rec_Qty, 0) /*- v_Capacity_Period_Occupy_Qty - Nvl(v_Item_Capacity_Qty, 0) * -1*/;
           
          If v_Item_Capacity_Qty >= 0 Then
            v_Line_Capacity_Date := To_Date(v_Month || '-' || Trim(To_Char(i, '00')), 'YYYY-MM-DD');
            v_Capacity_Insufficient_Flag := 'N';
            Exit;
          Else
            v_Capacity_Insufficient_Flag := 'Y';
          End If;
        End Loop;
     
        If v_Source_Order_Type_Id = 1 Then
          Update t_Pln_Lg_Order_Line Lol
             Set Lol.Aps_Capacity_Rec_Qty  =  Nvl(Lol.Quantity, 0),
                 Lol.Aps_Capacity_Rec_Date = v_Line_Capacity_Date,
                 Lol.To_Aps_Capacity_Qty   = Nvl(Lol.Quantity, 0),
                 Lol.Capacity_Insufficient_Flag = v_Capacity_Insufficient_Flag, 
                 Lol.Last_Updated_By       = p_User_Code,
                 Lol.Last_Update_Date      = Sysdate
           Where Lol.Order_Line_Id = r_Line.Order_Line_Id;
        Elsif v_Source_Order_Type_Id = 0 Then
          Update t_Pln_Order_Line Pol
             Set Pol.Aps_Capacity_Rec_Qty  = Nvl(Pol.Apply_Qty, 0),
                 Pol.Aps_Capacity_Rec_Date = v_Line_Capacity_Date,
                 Pol.To_Aps_Capacity_Qty = Nvl(Pol.Apply_Qty, 0),
                 Pol.Capacity_Insufficient_Flag = v_Capacity_Insufficient_Flag,
                 Pol.Last_Updated_By       = p_User_Code,
                 Pol.Last_Update_Date      = Sysdate
           Where Pol.Order_Line_Id = r_Line.Order_Line_Id;
        End If; 
        
        v_Capacity_Occupy_Qty := Nvl(r_Line.To_Aps_Capacity_Qty, r_Line.Quantity) - - Nvl(r_Line.Aps_Capacity_Rec_Qty, 0);
      Elsif p_Capacity_Sign = -1 Then
        --add by lizhen 2017-09-07月分配数量占用
        p_Pln_Assign_Occupy(In_Entity_Id     => v_Entity_Id, --主体ID
                            In_Order_Head_Id => p_Order_Head_Id, --订单头ID
                            In_Order_Line_Id => r_Line.Order_Line_Id, --订单行ID
                            In_Source_Type   => v_Source_Order_Type_Id, --单据源类型  0：计划订单  1：提货订单
                            In_Assign_Qty    => r_Line.Occupy_Assign_Qty, --占用数量
                            In_Assign_Sign   => p_Capacity_Sign, --占用标志，1：占用，-1：释放
                            In_User_Code     => p_User_Code, --用户
                            Out_Result       => p_Result --返回结果，成功返回SUCCESS，否则返回错误信息
                            );
        If p_Result != v_Success Then
          Raise v_Base_Exception;
        End If;
        --计算取消数量产能占用数量,负数时取0
         v_Capacity_Occupy_Qty := Greatest(Nvl(r_Line.Aps_Capacity_Rec_Qty, 0) - Nvl(r_Line.Pln_Affirmed_Qty, 0), 0);
      End If;
      
      --更新周期占用用数量
      For r_Capacity In (Select Pic.Assenbly_Capacity_Id
                           From v_Pln_Item_Capacity Pic
                          Where Pic.Period_Id = v_Month_Period_Id
                            And Pic.Item_Id = r_Line.Item_Id
                            And Pic.Producing_Area_Id = r_Line.Producing_Area_Id
                          Group By Pic.Assenbly_Capacity_Id) Loop
        --更新占用表数据
        Update t_Pln_Capacity_Period_Occupy Cpo
           Set Cpo.Occupy_Qty = Nvl(Cpo.Occupy_Qty, 0) +
                                v_Capacity_Occupy_Qty * p_Capacity_Sign
         Where Cpo.Assenbly_Capacity_Id = r_Capacity.Assenbly_Capacity_Id
           And Cpo.Period_Id = Decode(p_Capacity_Type,
                                      'W',
                                      v_Curr_Period_Id,
                                      'M',
                                      v_Month_Period_Id)
           And Cpo.Producing_Area_Id = r_Line.Producing_Area_Id;
        If Sql%Notfound Then
          Begin
            Insert Into t_Pln_Capacity_Period_Occupy
              (Period_Occupy_Id,
               Assenbly_Capacity_Id,
               Period_Id,
               Producing_Area_Id,
               Occupy_Qty,
               Created_By,
               Creation_Date,
               Last_Updated_By,
               Last_Update_Date,
               Remark,
               Version)
            Values
              (s_Pln_Capacity_Period_Occupy.Nextval,
               r_Capacity.Assenbly_Capacity_Id,
               Decode(p_Capacity_Type,
                      'W',
                      v_Curr_Period_Id,
                      'M',
                      v_Month_Period_Id),
               r_Line.Producing_Area_Id,
               v_Capacity_Occupy_Qty,
               p_User_Code,
               Sysdate,
               p_User_Code,
               Sysdate,
               Null,
               1);
          Exception
            When Others Then
              p_Result := '插入t_Pln_Capacity_Period_Occupy表数据失败！' || v_Nl ||
                          Sqlerrm;
              Raise v_Base_Exception;
          End;
        End If;
      End Loop;
      
      --插入CIMS产能占用历史记录表
      Begin
        Insert Into t_Pln_Capacity_Occupy_His
          (Occupy_His_Id,
           Entity_Id,
           Order_Head_Id,
           Order_Type_Id,
           Period_Id,
           Producing_Area_Id,
           Item_Id,
           Occupy_Sign_Flag,
           Occupy_Qty,
           Capacity_Assenply_Id,
           Created_By,
           Creation_Date,
           Last_Updated_By,
           Last_Update_Date,
           Remark,
           Version)
        Values
          (s_Pln_Capacity_Occupy_His.Nextval,
           v_Entity_Id,
           p_Order_Head_Id,
           p_Order_Type_Id,
           v_Curr_Period_Id,
           r_Line.Producing_Area_Id,
           r_Line.Item_Id,
           p_Capacity_Sign,
           r_Line.Quantity,
           Null,
           p_User_Code,
           Sysdate,
           p_User_Code,
           Sysdate,
           Null,
           1);
      Exception
        When Others Then
          p_Result := '插入t_Pln_Capacity_Occupy_His表数据失败！' || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
      End;            
    End Loop;
    If p_Capacity_Sign = 1 Then
      If v_Source_Order_Type_Id = 1 Then
        Update t_Pln_Lg_Order_Head Loh
           Set Loh.Aps_Capacity_State      = 'S',
               Loh.Aps_Capacity_Begin_Date = Nvl(Loh.Aps_Capacity_Begin_Date,
                                                 Sysdate),
               Loh.Aps_Capacity_End_Date   = Sysdate,
               Loh.Aps_Capacity_By         = p_User_Code
         Where Loh.Order_Head_Id = p_Order_Head_Id;
      Elsif v_Source_Order_Type_Id = 0 Then
        Update t_Pln_Order_Head Poh
           Set Poh.Aps_Capacity_State      = 'S',
               Poh.Aps_Capacity_Begin_Date = Nvl(Poh.Aps_Capacity_Begin_Date,
                                                 Sysdate),
               Poh.Aps_Capacity_End_Date   = Sysdate,
               Poh.Aps_Capacity_By         = p_User_Code
         Where Poh.Order_Head_Id = p_Order_Head_Id;
      End If;
    End If;      
  Exception
    When v_Base_Exception Then
      Rollback;
      p_Result := '产能可视产能占用失败!' || v_Nl || p_Result;
    When Others Then
      Rollback;
      p_Result := '产能可视产能占用失败!' || p_Result || v_Nl || Sqlerrm;
  End;
  
  -------------------------------------------------------------------------
  -- Author  : NICRO.LI
  -- Created : 2016-12-08 13:57:33
  -- Purpose : 订单产能可视每晚重算
  --           家用新产能使用按周实时计算所以不需要进行重算
  -------------------------------------------------------------------------
  Procedure p_Cpacity_Recompute(p_Entity_Id       In Number,
                                p_Recomputer_Date In Date  --重算日期
                                ) Is
    v_Period_Type                 Varchar2(10);
    v_Wee_Begin_Date              Date;
    v_Curr_Begin_Date             Date;
    v_Begin_Day                   Number;
    v_End_Day                     Number;
    v_Currend_Period_Id           Number;
    v_Begin_Date                  Date;
    v_End_Date                    Date; 
    v_Month_Period_Id             Number;
    v_Result                      Varchar2(4000);
    v_Fmt_Sql                     Varchar2(3000);
    v_Assenbly_Capacity_List      Varchar2(4000);
    v_Upd_Sql                     Varchar2(4000);
    v_Capacity_Span_Period        Number;
  Begin
    --获取系统参数产能可视周期类型参数
    Begin
      v_Period_Type := Pkg_Bd.f_Get_Parameter_Value('PLN_CAPACITY_PERIOD_TYPE',
                                                           p_Entity_Id);
    Exception
      When Others Then
        v_Result := '获取产能可视周期类型数参数PLN_CAPACITY_PERIOD_TYPE失改。' || Sqlerrm;
        Raise v_Base_Exception;
    End;
    --不按月产能可视的不进行产能重算
    If v_Period_Type != 'M' Then
      Return;
    End If;
      
      --取订单T+3周期开始日期
    Select Pop.Begin_Date
      Into v_Wee_Begin_Date
      From t_Pln_Order_Period Pop
     Where Pop.Period_Id =
           Pkg_Pln_Capacity.f_Get_Parameter_Month_Period(p_Entity_Id   => p_Entity_Id,
                                                         p_Period_Type => 'W',
                                                         p_Date        => p_Recomputer_Date);
    
    Begin
      Select Min(Pac.Begin_Date), Min(Pac.Period_Id)
        Into v_Curr_Begin_Date, v_Currend_Period_Id
        From t_Pln_Assenbly_Capacity Pac
       Where Pac.Entity_Id = p_Entity_Id
         And v_Wee_Begin_Date Between Pac.Begin_Date And Pac.End_Date;
    Exception
      When Others Then
        v_Result := '获取产能设置最小周期日期失改。' || Sqlerrm;
        Raise v_Base_Exception;
    End;
        
    --add by lizhen 2017-04-10
    --获取系统参数产能允许跨周期数(只有月周期时，才使用这个设置）
    Begin
      v_Capacity_Span_Period := Pkg_Bd.f_Get_Parameter_Value('PLN_CAPACITY_SPAN_PERIOD',
                                                           p_Entity_Id);
    Exception
      When Others Then
        v_Result := '获取主体允许跨周期数参数PLN_CAPACITY_SPAN_PERIOD失改。' || Sqlerrm;
        Raise v_Base_Exception;
    End;
    --重算产能之前把产能占用数量清0
    Update t_Pln_Capacity_Period_Occupy Cpo
       Set Cpo.Occupy_Qty         = 0,
           Cpo.Overdue_Occupy_Qty = 0,
           Cpo.Front_Occupy_Qty   = 0
     Where Cpo.Period_Id = v_Currend_Period_Id;
    For periodNum In 0..v_Capacity_Span_Period Loop 
      --获取期的开始、结束日期
      Begin
        Select To_Number(To_Char(Op.Begin_Date, 'DD')),
               To_Number(To_Char(Op.End_Date, 'DD')),
               Op.Period_Id,
               Op.Begin_Date,
               Op.End_Date
          Into v_Begin_Day,
               v_End_Day,
               v_Month_Period_Id,
               v_Begin_Date,
               v_End_Date
          From t_Pln_Order_Period Op
         Where Op.Period_Type = '月'
           And Op.Entity_Id = p_Entity_Id
           And Op.Period_Code = Replace(To_Char(Add_Months(v_Curr_Begin_Date, Periodnum),
                               'YYYY-MM') || '月', '-', '年');
      Exception
        When Others Then
          v_Result := '获取月周期信息失败。' || Sqlerrm;
           Raise v_Base_Exception;
      End;
         
      For r_Item In (Select Sum(Case When v_Begin_Date > To_Checkup_Date Then
                                    Capacity_Quantity
                                   Else
                                    0
                                 End) Front_Occupy_Qty,
                            Sum(Case When To_Checkup_Date Between v_Wee_Begin_Date And v_End_Date Then
                                    Capacity_Quantity
                                   Else
                                    0
                                 End) Occupy_Qty,
                             Sum(Case When To_Checkup_Date Between v_Begin_Date And v_Wee_Begin_Date - 1 Then
                                    Capacity_Quantity
                                   Else
                                    0
                                 End) Overdue_Occupy_Qty,
                            Item_Id,
                            Item_Code,
                            Producing_Area_Id,
                            Producing_Area_Code
                       From (Select (Case
                                      When Loh.Order_Head_State = '20' Then
                                       Nvl(Lol.Quantity, 0)
                                      When Loh.Order_Head_State = '2225' Then
                                       Nvl(Lol.To_Aps_Capacity_Qty, 0)
                                      When Loh.Order_Head_State = '1455' Then
                                       Nvl(Lol.Quantity, 0) - Nvl(Lol.Affirmed_Quantity, 0)
                                      When Loh.Order_Head_State In ('679', '381') Then
                                       Decode(Nvl(lol.make_order_line_flag, 'N'), 'Y', Nvl(Lol.To_Pln_Qty, 0), Nvl(Lol.To_Aps_Capacity_Qty, 0))
                                      Else
                                       0
                                    End) Capacity_Quantity,
                                    (Select Pop.Begin_Date
                                      From t_Pln_Order_Period Pop
                                     Where Pop.Period_Id =
                                           Pkg_Pln_Capacity.f_Get_Parameter_Month_Period(p_Entity_Id   => Loh.Entity_Id,
                                                                                         p_Period_Type => 'W',
                                                                                         p_Date        => Trunc(Loh.To_Checkup_Date))) To_Checkup_Date,
                                    Lol.Item_Id,
                                    Lol.Item_Code,
                                    Lol.Producing_Area_Id,
                                    Lol.Producing_Area_Code
                               From t_Pln_Lg_Order_Head Loh,
                                    t_Pln_Lg_Order_Line Lol,
                                    t_Pln_Order_Type    Pot
                              Where Loh.Order_Head_Id = Lol.Order_Head_Id
                                And Pot.Order_Type_Id = Loh.Order_Type_Id
                                And Pot.Lg_Order_Submit_Type = 'HQ_TYPE'
                                And Lol.Order_Line_State <> 'CLOSEED'
                                And Nvl(Lol.Make_Order_Line_Flag, 'N') != 'Y'
                                And Loh.Order_Head_State In ('20', '2225', '1455', '679', '381')
                                And Loh.Entity_Id = p_Entity_Id
                                And Loh.To_Checkup_Date >= Trunc(Sysdate - v_Capacity_Span_Period * 30 - 60)
                     Union All
                     Select Decode(Poh.Form_State,
                                   '32',
                                   Nvl(Pol.Can_Produce_Qty, 0) - Nvl(Pol.Supply_Qty, 0),                   
                                   Nvl(Pol.Check_Qty, Pol.Apply_Qty)) Capacity_Quantity,
                            Trunc(Pop.Begin_Date) To_Checkup_Date,
                            Pol.Item_Id,
                            Pol.Item_Code,
                            Pol.Producing_Area_Id,
                            Pol.Producing_Area_Code
                       From t_Pln_Order_Head Poh, t_Pln_Order_Line Pol, t_Pln_Order_Type Pot,
                            t_Pln_Order_Period Pop
                      Where Poh.Order_Head_Id = Pol.Order_Head_Id
                        And Poh.Order_Type_Id = Pot.Order_Type_Id
                        And Pop.Period_Id = Poh.Period_Id
                        And Poh.Entity_Id = p_Entity_Id
                        And (Pot.Is_Pln_Capacity = 'Y' Or 
                          Exists(Select 1
                                  From t_Pln_Lg_Relation Plr, 
                                       t_Pln_Lg_Order_Head Loh, 
                                       t_Pln_Order_Type Pot
                                 Where Loh.Order_Head_Id = Plr.Lg_Order_Head_Id
                                   And Loh.Order_Type_Id = Pot.Order_Type_Id
                                   And Pot.Lg_Order_Submit_Type = 'HQ_TYPE'
                                   And Plr.Order_Line_Id = Pol.Order_Line_Id
                                   And Plr.Order_Head_Id = Pol.Order_Head_Id))
                        And Poh.Creation_Date > Sysdate - v_Capacity_Span_Period * 30 - 60
                        And Poh.Form_State Not In ('19', '303', '304', '305')) Ca
                     Where Exists(Select 1 From v_Pln_Item_Capacity Pic Where Pic.Item_Id = Ca.Item_Id 
                       And Pic.Producing_Area_Id = Ca.Producing_Area_Id 
                       And Pic.Period_Id = v_Currend_Period_Id)
                      Group By Item_Id,
                               Item_Code,
                               Producing_Area_Id,
                               Producing_Area_Code) Loop
                               
        Select Listagg(Assenbly_Capacity_Id, ',') Within Group(Order By Assenbly_Capacity_Id) Assenbly_Capacity_Id
          Into v_Assenbly_Capacity_List
          From v_Pln_Item_Capacity Pic
         Where Pic.Producing_Area_Id = r_Item.Producing_Area_Id
           And Pic.Period_Id = v_Currend_Period_Id
           And Pic.Item_Code = r_Item.Item_Code
           And Pic.Entity_Id = p_Entity_Id
         Group By Item_Id, Item_Code, Producing_Area_Id, Period_Id, Entity_Id;
         
        --更新产能占用数据 
        --Update t_Pln_Capacity_Period_Occupy Cpo Set Cpo.Front_Occupy_Qty
        Begin
          v_Upd_Sql := 'Update t_Pln_Capacity_Period_Occupy CPo ' ||
                       ' Set Cpo.Occupy_Qty  = Nvl(Cpo.Occupy_Qty, 0) + ' || r_Item.Occupy_Qty || ',' ||
                       --' Cpo.Overdue_Occupy_Qty = Nvl(Cpo.Overdue_Occupy_Qty, 0) + ' || r_Item.Overdue_Occupy_Qty || ',' ||
                       ' Cpo.Front_Occupy_Qty = Nvl(Cpo.Front_Occupy_Qty, 0) + ' || r_Item.Front_Occupy_Qty + r_Item.Overdue_Occupy_Qty || ',' ||
                       ' Cpo.Last_Update_Date = Sysdate ' ||
                       ' Where Cpo.Assenbly_Capacity_Id In (' ||
                       v_Assenbly_Capacity_List || ')' ||
                       ' And Cpo.Producing_Area_Id = :1 ' ||
                       ' And Cpo.Period_Id = :2';
          Execute Immediate v_Upd_Sql Using r_Item.Producing_Area_Id, v_Currend_Period_Id;
        Exception
          When Others Then
            Raise v_Base_Exception;
        End;
        
        --插入CIMS产能占用历史记录表
        Begin
          Insert Into t_Pln_Capacity_Occupy_His
            (Occupy_His_Id,
             Entity_Id,
             Order_Head_Id,
             Order_Type_Id,
             Period_Id,
             Producing_Area_Id,
             Item_Id,
             Occupy_Sign_Flag,
             Occupy_Qty,
             Capacity_Assenply_Id,
             Created_By,
             Creation_Date,
             Last_Updated_By,
             Last_Update_Date,
             Remark,
             Version)
          Values
            (s_Pln_Capacity_Occupy_His.Nextval,
             p_Entity_Id,
             -1,
             -1,
             v_Month_Period_Id,
             r_Item.Producing_Area_Id,
             r_Item.Item_Id,
             1,
             r_Item.Occupy_Qty,
             v_Assenbly_Capacity_List,
             'admin',
             Sysdate,
             'admin',
             Sysdate,
             '每晚产能占用重算',
             1);
        Exception
          When Others Then
            Raise v_Base_Exception;
        End;
      End Loop;
    End Loop;
  Exception
    When v_Base_Exception Then
      Rollback;
      Pkg_Pln_Pub.p_Write_Job_Log(p_Module_Code          => 'PLN',
                                      p_Procedure_Name       => 'Pkg_Pln_Capacity.p_Capacity_Recompute',
                                      p_Error_Msg            => '产能可视每晚乘余产能重算，系统后台处理！' ||
                                                                v_Result,
                                      p_Source_Order_Head_Id => -1,
                                      p_Source_Order_Line_Id => Null,
                                      p_Item_Id              => Null,
                                      p_Inventory_Id         => Null,
                                      p_Quantity             => Null);
       Commit;
    When Others Then
      Rollback;
      Pkg_Pln_Pub.p_Write_Job_Log(p_Module_Code          => 'PLN',
                                  p_Procedure_Name       => 'Pkg_Pln_Capacity.p_Capacity_Recompute',
                                  p_Error_Msg            => '产能可视每晚乘余产能重算，系统后台处理！' ||
                                                                v_Result || Sqlerrm,
                                  p_Source_Order_Head_Id => -1,
                                  p_Source_Order_Line_Id => Null,
                                  p_Item_Id              => Null,
                                  p_Inventory_Id         => Null,
                                  p_Quantity             => Null);
      Commit;
  End;

End Pkg_Pln_Capacity;
/

