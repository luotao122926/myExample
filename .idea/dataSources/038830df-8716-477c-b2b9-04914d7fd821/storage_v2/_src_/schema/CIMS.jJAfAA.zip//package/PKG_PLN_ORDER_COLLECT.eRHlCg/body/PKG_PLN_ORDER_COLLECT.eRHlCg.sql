create Package Body Pkg_Pln_Order_Collect Is

  v_Nl      Constant Varchar2(2) := Chr(13) || Chr(10); --换行
  v_Null    Constant Varchar2(4) := 'NULL'; --空值
  v_True    Constant Varchar2(2) := 'Y';
  v_False   Constant Varchar2(2) := 'N';
  v_Result  Constant Number := 0; --成功返回
  v_Success Constant Varchar2(10) := 'SUCCESS';
  v_Base_Exception Exception; --自定义异常

  v_Month_Edition    Number Not Null := -1; --本月版本号
  v_Month_Begin_Date Date; --月起始日期
  v_Month_End_Date   Date; --月终止日期
  v_Week_Edition     Number Not Null := -1; --本周版本号
  v_Week_Begin_Date  Date; --周起始日期
  v_Week_End_Date    Date; --周起始日期

  v_Review_Complete_State Varchar2(100) := '评审完毕';
  v_Hq_Affirm_State       Varchar2(100) := '汇总评审完成';

  v_Action_Submit          Varchar2(100) := '送审';
  v_Action_Collect_Affirm  Varchar2(100) := '汇总确认';
  v_Action_Inv_Review      Varchar2(100) := '库存评审';
  v_Action_Hq_Review       Varchar2(100) := '总部评审';
  v_Action_Resolve_Affirm  Varchar2(100) := '分解确认';
  v_Action_Resolve_First   Varchar2(100) := '初次分解';
  v_Action_Resolve_Second  Varchar2(100) := '二次分解';
  v_Action_Resolve_Third   Varchar2(100) := '三次分解';
  v_Action_Check_Complete  Varchar2(100) := '审核通过';
  v_Action_Factory_Review  Varchar2(100) := '工厂评审';
  v_Action_Aps_Interactive Varchar2(100) := 'APS交互';
  v_Action_Aps_Walkthrough Varchar2(100) := 'APS预排产';
  v_Action_Aps_Promise     Varchar2(100) := 'APS订单承诺';
  v_Action_Center_Confirm  Varchar2(100) := '中心确认';
  v_Action_Hq_Confirm      Varchar2(100) := '总部确认';
  v_Action_Into_Aps_Intf   Varchar2(100) := '引APS接口';
  v_Action_Ord_Auto_Prdc   Varchar2(100) := '订单自动排产';
  v_Action_Review_Complete Varchar2(100) := '评审完毕';
  v_Action_Back            Varchar2(100) := '退回';
  v_Action_Rebut           Varchar2(100) := '驳回';


  -----------------------------------------------------------------------------
  ---- AUTHOR  : 李振
  -- CREATED : 2014-07-16 11:05:52
  -- PURPOSE : 评审完毕生成生订单明细行
  -----------------------------------------------------------------------------
  Procedure p_Create_Order_Detail(p_Collect_Head_Id In Number, ----订单ID
                                  p_User_Code       In Varchar2, ----用户ID
                                  p_Result          In Out Varchar2 --返回结果：成功返回"SUCCESS"，失败返回原因
                                  ) Is

    v_Cur_Nd_Smtl Integer Not Null := 0; --计数变量
    v_Entity_Id   Number;
    v_Count       Number;
    v_Item_Product_Form        Varchar2(100);
    v_Assemblies_Value_Scale   Number;
    Cursor c_s_Item(p_Item_Id Number, p_Entity_Id Number) Is
      Select c.Item_Id Sub_Item_Id,
             Trunc(Nvl(c.Quantity, 0)) Sub_Qty,
             d.Item_Code Sub_Item_Code,
             d.Item_Name Sub_Item_Desc,
             d.Defaultunit Sub_Item_Uom
        From t_Bd_Item                a,
             t_Bd_Item_Assemblies     b,
             t_Bd_Item_Assemblies_Sub c,
             t_Bd_Item                d
       Where a.Item_Id = Nvl(p_Item_Id, -1)
         And a.Entity_Id = Nvl(p_Entity_Id, -1)
         And a.Item_Id = b.Item_Id
         And b.Entity_Id = Nvl(p_Entity_Id, -1)
         And Trunc(Sysdate) Between Trunc(Nvl(b.Begin_Date, Sysdate + 1)) And
             Trunc(Nvl(b.End_Date, Sysdate + 1))
         And b.Item_Assembly_Id = c.Item_Assembly_Id
         And c.Entity_Id = Nvl(p_Entity_Id, -1)
         And Trunc(Sysdate) Between Trunc(Nvl(c.Begin_Date, Sysdate + 1)) And
             Trunc(Nvl(c.End_Date, Sysdate + 1))
         And Trunc(Nvl(c.Quantity, 0)) >= 1
         And c.Item_Id = d.Item_Id
         And d.Entity_Id = Nvl(p_Entity_Id, -1)
      Union All
      Select a.Item_Id     Sub_Item_Id,
             1             Sub_Qty,
             a.Item_Code   Sub_Item_Code,
             a.Item_Name   Sub_Item_Desc,
             a.Defaultunit Sub_Item_Uom
        From t_Bd_Item a
       Where a.Item_Id = Nvl(p_Item_Id, -1)
         And a.Entity_Id = Nvl(p_Entity_Id, -1)
         And Not Exists
       (Select 1
                From t_Bd_Item_Assemblies Ia
               Where Ia.Item_Id = a.Item_Id
                 And Ia.Entity_Id = p_Entity_Id
                 And Trunc(Sysdate) Between
                     Trunc(Nvl(Ia.Begin_Date, Sysdate + 1)) And
                     Trunc(Nvl(Ia.End_Date, Sysdate + 1)));
    r_s_Item c_s_Item%Rowtype;
  Begin
    Select Oh.Entity_Id
      Into v_Entity_Id
      From t_Pln_Order_Collect_Head Oh
     Where Oh.Coll_Ord_Head_Id = p_Collect_Head_Id;

    --删除订单散件明细
    Delete From t_Pln_Order_Detail
     Where Order_Head_Id In
           (Select l.Order_Head_Id
              From t_Pln_Order_Line             l,
                   t_Pln_Order_Collect_Relation Ocr,
                   t_Pln_Order_Collect_Head     Och,
                   t_Pln_Order_Collect_Line     Ocl
             Where Och.Coll_Ord_Head_Id = p_Collect_Head_Id
               And Ocl.Coll_Ord_Head_Id = Och.Coll_Ord_Head_Id
               And Ocl.Coll_Ord_Line_Id = Ocr.Coll_Ord_Line_Id
               And Ocr.Order_Line_Id = l.Order_Line_Id
               And l.Entity_Id = v_Entity_Id);
    --add by lizhen 2015-01-20
    --增加检查订单汇总行关系表，同一订单行只允许存在一行数据
    Select Count(1)
      Into v_Count
      From (Select Count(l.Order_Line_Id) Row_Count
              From t_Pln_Order_Head             h,
                   t_Pln_Order_Line             l,
                   t_Pln_Order_Collect_Relation Ocr,
                   t_Pln_Order_Collect_Head     Och,
                   t_Pln_Order_Collect_Line     Ocl
             Where Och.Coll_Ord_Head_Id = p_Collect_Head_Id
               And Ocl.Coll_Ord_Head_Id = Och.Coll_Ord_Head_Id
               And Ocl.Coll_Ord_Line_Id = Ocr.Coll_Ord_Line_Id
               And Ocr.Order_Line_Id = l.Order_Line_Id
               And h.Order_Head_Id = l.Order_Head_Id
               And l.Entity_Id = v_Entity_Id Having
             Count(l.Order_Line_Id) > 1
             Group By l.Order_Line_Id);
    If v_Count > 0 Then
      p_Result := '同一订单行在汇总行与订单行关系表存在多行数据，评审失败。' || v_Nl ||
        '汇总订单头ID：' || p_Collect_Head_Id;
      Return;
    End If;
    --循环订单商品明细
    For r_Line In (Select l.Entity_Id,
                          l.Order_Head_Id,
                          l.Order_Line_Id,
                          l.Item_Id,
                          l.item_code,
                          h.Customer_Id,
                          l.Producing_Area_Id,
                          l.Producing_Area_Code,
                          l.Producing_Area_Name,
                          Nvl(l.Can_Produce_Qty, 0) Usable_Produce_Qty,
                          l.begin_supply_date,
                          l.end_supply_date
                     From t_Pln_Order_Head             h,
                          t_Pln_Order_Line             l,
                          t_Pln_Order_Collect_Relation Ocr,
                          t_Pln_Order_Collect_Head     Och,
                          t_Pln_Order_Collect_Line     Ocl
                    Where Och.Coll_Ord_Head_Id = p_Collect_Head_Id
                      And Ocl.Coll_Ord_Head_Id = Och.Coll_Ord_Head_Id
                      And Ocl.Coll_Ord_Line_Id = Ocr.Coll_Ord_Line_Id
                      And Ocr.Order_Line_Id = l.Order_Line_Id
                      And h.Order_Head_Id = l.Order_Head_Id
                      And l.Entity_Id = v_Entity_Id
                      And Nvl(l.Can_Produce_Qty, 0) > 0) Loop
      --ADD BY LIZHEN 2015-01-15 判断套件产品是否存在套散件关系，无套散件关系则提示异常
      Begin
        Select Bi.Productform
          Into v_Item_Product_Form
          From t_Bd_Item Bi
         Where Bi.Item_Code = r_Line.Item_Code
           And Bi.Item_Id = r_Line.Item_id
           And Bi.Entity_Id = r_Line.Entity_Id;
      Exception
        When Others Then
          p_Result := '获取产品套散件属性失败！' || v_Nl || '产品编码：' ||
                      r_Line.Item_Code || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
      End;
      --add by lizhen 2015-01-31 判断套件产品是否存在套散件关系，无套散件关系则提示异常
      --产品属性说明
      /*SET_PRODUCT       套机
        INDOOR_PRODUCT    室内机
        OUTDOOR_PRODUCT   室外机
        WHOLE_PRODUCT     整体机
        SAMPLE_PRODUCT    样机
        PARTS_PRODUCT     散件
        ACCESSORIES_PRODUCT 独立销售模块*/
      If v_Item_Product_Form = 'SET_PRODUCT' Then
        Select Sum(Ias.Value_Scale)
          Into v_Assemblies_Value_Scale
          From t_Bd_Item_Assemblies Bia, t_Bd_Item_Assemblies_Sub Ias
         Where Bia.Item_Assembly_Id = Ias.Item_Assembly_Id
           And Nvl(Bia.Active_Flag, 'N') = 'Y'
           And Nvl(Ias.Active_Flag, 'N') = 'Y'
           And Bia.Entity_Id = r_Line.Entity_Id
           And Bia.Item_Id = r_Line.Item_Id;
        If Nvl(v_Assemblies_Value_Scale, 0) < 100 Then
          p_Result := '检查套件产品套散件关系失败。' || v_Nl ||
            '原因：1、不存在套散件关系；' || v_Nl ||
            ' 2、套散件关系已失效；' || v_Nl ||
            ' 3、散件价值比率小于100，散件产品价值比率合计：' || To_Char(Nvl(v_Assemblies_Value_Scale, 0)) || '；' || v_Nl ||
            '套件产品编码：' || r_Line.Item_Code;
          Raise v_Base_Exception;
        End If;
      End If;
      --循环商品的散件
      For r_s_Item In c_s_Item(r_Line.Item_Id, v_Entity_Id) Loop
        v_Cur_Nd_Smtl := Nvl(r_Line.Usable_Produce_Qty, 0) *
                         Nvl(r_s_Item.Sub_Qty, 0);
        --生成订单散件行
        Insert Into t_Pln_Order_Detail
          (Order_Detail_Id,
           Order_Head_Id,
           Order_Line_Id,
           Item_Id,
           Item_Code,
           Item_Name,
           Item_Uom,
           Can_Produce_Qty,
           Entity_Id,
           Created_By,
           Creation_Date,
           Last_Updated_By,
           Last_Update_Date,
           Producing_Area_Id,
           Producing_Area_Code,
           Producing_Area_Name,
           Begin_Supply_Date,
           End_Supply_Date)
        Values
          (s_Pln_Order_Detail.Nextval,
           r_Line.Order_Head_Id,
           r_Line.Order_Line_Id,
           r_s_Item.Sub_Item_Id,
           r_s_Item.Sub_Item_Code,
           r_s_Item.Sub_Item_Desc,
           r_s_Item.Sub_Item_Uom,
           v_Cur_Nd_Smtl,
           v_Entity_Id,
           p_User_Code,
           Sysdate,
           p_User_Code,
           Sysdate,
           r_Line.Producing_Area_Id,
           r_Line.Producing_Area_Code,
           r_Line.Producing_Area_Name,
           Null,
           Null);
      End Loop;
    End Loop;

    /*Select Count(1)
      Into v_Count
      From t_Pln_Order_Line             l,
           t_Pln_Order_Collect_Relation Ocr,
           t_Pln_Order_Collect_Head     Och,
           t_Pln_Order_Collect_Line     Ocl
     Where Och.Coll_Ord_Head_Id = p_Collect_Head_Id
       And Ocl.Coll_Ord_Head_Id = Och.Coll_Ord_Head_Id
       And Ocl.Coll_Ord_Line_Id = Ocr.Coll_Ord_Line_Id
       And Ocr.Order_Line_Id = l.Order_Line_Id
       And l.Entity_Id = v_Entity_Id
       And (Select Count(1)
              From t_Pln_Order_Detail Pod
             Where Pod.Order_Line_Id = l.Order_Line_Id) = 0;
    If v_Count > 0 Then
      p_Result := '订单行存在无法生成明细行的数据，共有：' || To_Char(v_Count) || '行数据。';
      Return;
    End If;*/

    --成功返回
    p_Result := v_Success;
  Exception
    When v_Base_Exception Then
      Rollback;
      p_Result := p_Result;
    When Others Then
      Rollback;
      p_Result := '生成订单明细行失败，未知错误。' || v_Nl ||
        p_Result || v_Nl || Sqlerrm;
  End;

  -----------------------------------------------------------------------------
  ---- AUTHOR  : 李振
  -- CREATED : 2014-07-16 11:05:52
  -- PURPOSE : 执行订单操作
  -----------------------------------------------------------------------------
  Procedure p_Check_Next_State_Complete(p_Collect_Head_Id  In Number, ----订单ID
                                        p_Operation_Action In Varchar2, --当前单据动作
                                        p_Next_State       In Varchar2, --下一状态值
                                        p_User_Code        In Varchar2, ----用户ID
                                        p_Result           In Out Varchar2 --返回结果：成功返回"SUCCESS"，失败返回原因
                                        ) Is
    v_Next_State_Code   Varchar2(100);
    v_Pln_Wip_Ord_Match Varchar2(100);
    v_Entity_Id         Number;
  Begin
    p_Result := v_Success;
    Begin
      Select s.Status_Code
        Into v_Next_State_Code
        From t_Pln_Flow_Type_Status s
       Where s.Status_Id = p_Next_State;
    Exception
      When Others Then
        p_Result := '检查下一状态编码失败' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;
    Begin
      Select Ch.Entity_Id
        Into v_Entity_Id
        From t_Pln_Order_Collect_Head Ch
       Where Ch.Coll_Ord_Head_Id = p_Collect_Head_Id;
    Exception
      When Others Then
        p_Result := '打开订单汇总表失败！' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;
    --获取工单与订单是否完全匹配参数
    Begin
      v_Pln_Wip_Ord_Match := Pkg_Bd.f_Get_Parameter_Value('PLN_WIP_ORD_MATCH',
                                                          v_Entity_Id);
    Exception
      When Others Then
        p_Result := '获取参数PLN_WIP_ORD_MATCH失败！' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;
    If p_Result = v_Success And v_Next_State_Code = v_Hq_Affirm_State Then

      --add by xuhongjiu 2015-12-8
      For r_order_Head In (
         Select Distinct h.Order_Head_Id
           From Cims.t_Pln_Order_Collect_Head     Ch,
                Cims.t_Pln_Order_Collect_Relation Cr,
                Cims.t_Pln_Order_Line             l,
                Cims.t_Pln_Order_Head             h
          Where Ch.Coll_Ord_Head_Id = Cr.Order_Collect_Head_Id
            And Cr.Order_Line_Id = l.Order_Line_Id
            And h.Order_Head_Id = l.Order_Head_Id
            And ch.coll_ord_head_id = p_Collect_Head_Id) Loop

            Declare
            v_customer_id Number;
            v_account_id Number;
            v_order_number Varchar(50);
            v_order_type t_pln_order_type%Rowtype;
            v_Count Number;
            v_Sys_Source Varchar2(50);
            v_source_type Varchar2(60);

            Begin

              Begin
                Select Poh.Customer_Id,
                       Poh.Account_Id,
                       Poh.Order_Number,
                       Poh.Sys_Source,
                       Poh.Source_Type
                  Into v_Customer_Id,
                       v_Account_Id,
                       v_Order_Number,
                       v_Sys_Source,
                       v_Source_Type
                  From Cims.t_Pln_Order_Head Poh
                 Where Poh.Order_Head_Id = r_Order_Head.Order_Head_Id;
              Exception
                When Others Then
                p_Result := '查询订单号为：' || v_order_number || '的客户ID或账户ID失败。' || v_Nl || Sqlerrm;
                Raise v_Base_Exception;
              End;

              Begin
                Select ot.*
                  Into v_order_type
                  From Cims.t_Pln_Order_Head Poh,
                       cims.t_pln_order_type ot
                 Where poh.order_type_id = ot.order_type_id
                   And poh.entity_id = ot.entity_id
                   And Poh.Order_Head_Id = r_Order_Head.Order_Head_Id;
              Exception
                When Others Then
                p_Result := '查询订单号为：' || v_order_number || '的订单类型失败。' || v_Nl || Sqlerrm;
                Raise v_Base_Exception;
              End;

              If nvl(v_Sys_Source,'_') <> 'CIMS' And nvl(v_source_type,'_') <> '提货订单' Then
                --只有送审锁款时才锁款
                --add by xuhongjiu 2015-12-9 金额=（单价*数量*（100-折扣率-月返））/100
                If p_Result = v_Success And nvl(v_order_type.Chk_Cusg_Amount_Flag,'_') = 'S' Then
                  For r_Check_Amount In (Select Bi.Sales_Main_Type,
                                                /*锁款金额 = 申请金额 - 评审金额 - 库评金额*/
                                                (Round(Sum(nvl(pol.item_price,0) * nvl(pol.apply_qty,0) *
                                                   (100 - nvl(pol.discount_rate,0) - nvl(pol.ordered_discount_rate,0))/100) -
                                                Sum(nvl(pol.item_price,0) * nvl(pol.can_produce_qty,0) *
                                                   (100 - nvl(pol.discount_rate,0) - nvl(pol.ordered_discount_rate,0))/100) -
                                                Sum(nvl(pol.item_price,0) * nvl(pol.inv_affirm_qty,0) *
                                                   (100 - nvl(pol.discount_rate,0) - nvl(pol.ordered_discount_rate,0))/100))) apply_Amount,
                                                /*锁款扣率金额 = 申请扣率金额 - 评审扣率金额 - 库评扣率金额*/
                                                (Round(Sum(nvl(pol.item_price,0) * nvl(pol.apply_qty,0) * nvl(pol.discount_rate,0)/100) -
                                                Sum(nvl(pol.item_price,0) * nvl(pol.can_produce_qty,0) * nvl(pol.discount_rate,0)/100) -
                                                Sum(nvl(pol.item_price,0) * nvl(pol.inv_affirm_qty,0) * nvl(pol.discount_rate,0)/100))) Discount_Amount
                                           From t_Pln_Order_Line pol, t_Bd_Item Bi
                                          Where pol.Item_Id = Bi.Item_Id
                                            And Bi.Entity_Id = pol.Entity_Id
                                            And pol.Order_Head_Id = r_order_Head.Order_Head_Id
                                            And pol.Entity_Id = v_Entity_Id
                                          Group By Bi.Sales_Main_Type) Loop
                    If r_check_amount.sales_main_type Is Null Then
                       p_Result := '订单号为：' || v_order_number ||'的订单里存在产品没有营销大类。' || v_Nl || p_Result;
                       Raise v_Base_Exception;
                    End If;
                    --如果评审数量（可生产数量）大于申请数量，则要增加锁款
                    If Nvl(r_Check_Amount.apply_Amount, 0) < 0 Then
                      --检查并锁定资金
                      Pkg_Credit_Account_Control.Prc_Credit_Order_Bill(p_Entity_Id       => v_Entity_Id,
                                                                       p_Action_Type     => 1,
                                                                       p_Settlement_Sum  => Nvl(r_Check_Amount.apply_Amount,
                                                                                                0),
                                                                       p_Discount_Sum    => Nvl(r_Check_Amount.Discount_Amount,
                                                                                                0),
                                                                       p_Sales_Main_Type => r_Check_Amount.Sales_Main_Type,
                                                                       p_Account_Id      => v_account_id,
                                                                       p_Customer_Id     => v_Customer_Id,
                                                                       p_Proj_Number     => Null,
                                                                       p_Order_Id        => r_order_Head.Order_Head_Id,
                                                                       p_Order_Type      => v_order_type.Order_Type_Name,
                                                                       p_Username        => p_User_Code,
                                                                       p_Result          => v_Count,
                                                                       p_Err_Msg         => p_Result);
                      If p_Result <> v_Success Then
                        p_Result := '检查并锁定资金失败，产品大类：' || r_Check_Amount.Sales_Main_Type || v_Nl ||
                                    p_Result;
                        Raise v_Base_Exception;
                      End If;
                    --如果评审数量（可生产数量）小于申请数量，则要释放锁款
                    Elsif Nvl(r_Check_Amount.apply_Amount, 0) > 0 Then
                      Pkg_Credit_Account_Control.Prc_Credit_Order_Bill(p_Entity_Id       => v_Entity_Id,
                                                                       p_Action_Type     => 2, --释放到款
                                                                       p_Settlement_Sum  => Nvl(r_Check_Amount.Apply_Amount,
                                                                                                0),
                                                                       p_Discount_Sum    => Nvl(r_Check_Amount.Discount_Amount,
                                                                                                0),
                                                                       p_Sales_Main_Type => r_Check_Amount.Sales_Main_Type,
                                                                       p_Account_Id      => v_account_id,
                                                                       p_Customer_Id     => v_Customer_Id,
                                                                       p_Proj_Number     => Null,
                                                                       p_Order_Id        => r_order_Head.Order_Head_Id,
                                                                       p_Order_Type      => v_order_type.Order_Type_Name,
                                                                       p_Username        => p_User_Code,
                                                                       p_Result          => v_Count,
                                                                       p_Err_Msg         => p_Result);
                      If p_Result <> v_Success Then
                        p_Result := '检查并释放资金失败，产品大类：' ||
                                    r_Check_Amount.Sales_Main_Type || v_Nl ||
                                    p_Result;
                        Raise v_Base_Exception;
                      End If;
                    End If;
                  End Loop;
                End If;
              End If;
           End;
         End Loop;


      p_Create_Order_Detail(p_Collect_Head_Id => p_Collect_Head_Id, ----订单ID
                            p_User_Code       => p_User_Code, ----用户ID
                            p_Result          => p_Result --返回结果：成功返回"SUCCESS"，失败返回原因
                            );
      If p_Result = v_Success Then
        --更新计划订单
        Update t_Pln_Order_Head Oh
           Set Oh.Form_State       = '23', --更新计划订单状态为“评审完毕”
               Oh.Last_Updated_By  = p_User_Code,
               Oh.Last_Update_Date = Sysdate
         Where Oh.Order_Head_Id In
               (Select l.Order_Head_Id
                  From t_Pln_Order_Line             l,
                       t_Pln_Order_Collect_Relation Ocr,
                       t_Pln_Order_Collect_Head     Och,
                       t_Pln_Order_Collect_Line     Ocl
                 Where Och.Coll_Ord_Head_Id = p_Collect_Head_Id
                   And Ocl.Coll_Ord_Head_Id = Och.Coll_Ord_Head_Id
                   And Ocl.Coll_Ord_Line_Id = Ocr.Coll_Ord_Line_Id
                   And Ocr.Order_Line_Id = l.Order_Line_Id)
           And Oh.Form_State = '25' --订单必须为‘已汇总状态’
        ;
        If Sql%Notfound Then
          p_Result := '汇总订单评审完成，更新计划订单失败，未找到可更新的计划订单头。汇总订单头ID：' ||
                      p_Collect_Head_Id || v_Nl ||
                      '处理失败过程名称：Pkg_Pln_Order_Collect.p_Check_Next_State_Complete';
        End If;
      Else
        Raise v_Base_Exception;
      End If;
    End If;

    For r_Inv_Affirm In (Select Oh.Order_Head_Id,
                                Oh.Order_Number,
                                Ol.Order_Line_Id,
                                Ol.Item_Id,
                                Ir.Affirm_Qty,
                                Ir.Inventory_Id,
                                Oh.Entity_Id
                           From t_Pln_Order_Head       Oh,
                                t_Pln_Order_Line       Ol,
                                t_Pln_Order_Inv_Review Ir,
                                t_Pln_Order_Type       Ot
                          Where Oh.Order_Head_Id = Ol.Order_Head_Id
                            And Ir.Order_Head_Id = Ol.Order_Head_Id
                            And Ir.Order_Line_Id = Ol.Order_Line_Id
                            And Ir.Item_Id = Ol.Item_Id
                            And Ot.Order_Type_Id = Oh.Order_Type_Id
                            And Nvl(Ot.Inv_Chk_Auto_Share, v_False) = v_True
                            And Oh.Form_State In ('23') --评审完毕
                            And Ir.Affirm_Qty > 0
                            And Ol.Order_Head_Id In
                                (Select l.Order_Head_Id
                                   From t_Pln_Order_Line             l,
                                        t_Pln_Order_Collect_Relation Ocr,
                                        t_Pln_Order_Collect_Head     Och,
                                        t_Pln_Order_Collect_Line     Ocl
                                  Where Och.Coll_Ord_Head_Id =
                                        p_Collect_Head_Id
                                    And Ocl.Coll_Ord_Head_Id =
                                        Och.Coll_Ord_Head_Id
                                    And Ocl.Coll_Ord_Line_Id =
                                        Ocr.Coll_Ord_Line_Id
                                    And Ocr.Order_Line_Id = l.Order_Line_Id)
                            And Oh.Form_State = '23') Loop
      Pkg_Pln_Shares.p_Auto_Create_Share(p_Pln_Order_Line_Id => r_Inv_Affirm.Order_Line_Id, --订单行ID
                                         p_Inventory_Id      => r_Inv_Affirm.Inventory_Id, --仓库ID(财务仓)
                                         p_Trans_Sign_Flag   => 1, --生成发货计划方向，1：生成发货计划  -1：取消发货计划
                                         p_Trans_Share_Qty   => r_Inv_Affirm.Affirm_Qty, --分配数量（只传正数）
                                         p_Entity_Id         => r_Inv_Affirm.Entity_Id, --主体ID
                                         p_Pln_Wip_Ord_Match => v_Pln_Wip_Ord_Match, --工单与订单新匹配模式
                                         p_User_Code         => p_User_Code,
                                         p_Result            => p_Result,
                                         p_Inv_Affirm_Flag   => 'Y');
      If p_Result <> v_Success Then
        Raise v_Base_Exception;
      End If;
    End Loop;

    --add by  lizhen 2016-01-14 检查产品是否为虚拟生产,在订单评审完毕后再更新一次虚拟生产标志
    Update t_Pln_Order_Line Pol
       Set Pol.Synt_Producing_Area_Id =
           (Select Pi.Po_Area_Id
              From v_inv_producting_item_list Pi
             Where Pi.Entity_Id = Pol.Entity_Id
               And Pi.Item_Id = Pol.Item_Id
               And Trunc(Sysdate) Between Pi.Begin_Date And
                   Trunc(Nvl(Pi.End_Date, Sysdate))),
           Pol.Synt_Order_Flag        = Nvl((Select 'Y'
                                              From v_inv_producting_item_list Pi
                                             Where Pi.Entity_Id =
                                                   Pol.Entity_Id
                                               And Pi.Item_Id = Pol.Item_Id
                                               And Trunc(Sysdate) Between
                                                   Pi.Begin_Date And
                                                   Trunc(Nvl(Pi.End_Date,
                                                             Sysdate))),
                                            'N')
     Where Exists (Select 1
              From Cims.t_Pln_Order_Collect_Head     Ch,
                   Cims.t_Pln_Order_Collect_Relation Cr,
                   Cims.t_Pln_Order_Line             l,
                   Cims.t_Pln_Order_Head             h
             Where Ch.Coll_Ord_Head_Id = Cr.Order_Collect_Head_Id
               And Cr.Order_Line_Id = l.Order_Line_Id
               And h.Order_Head_Id = l.Order_Head_Id
               And h.Order_Head_Id = Pol.Order_Head_Id
               And Ch.Coll_Ord_Head_Id = p_Collect_Head_Id);
  Exception
    When v_Base_Exception Then
      Rollback;
      p_Result := p_Result;
    When Others Then
      Rollback;
      p_Result := p_Result || v_NL || Sqlerrm;
  End;

  -----------------------------------------------------------------------------
  ---- AUTHOR  : 李振
  -- CREATED : 201409-06
  -- PURPOSE : 汇总总部确认
  -----------------------------------------------------------------------------
  Procedure p_Hq_Confirm_Order(p_Collect_Head_Id  In Number, ----订单ID
                               p_Operation_Action In Varchar2, --当前单据动作
                               p_User_Code        In Varchar2, ----用户ID
                               p_Result           Out Varchar2 --返回结果：成功返回"SUCCESS"，失败返回原因
                               ) Is

    v_Tmp_Flag         Varchar2(1); --临时标识，01位长
    v_Entity_Id        Number;
    v_Order_Type_Id    Number;
    v_Order_Type_Name  Varchar2(50); --订单类型
    v_Customer_Id      Number;
    v_Period_Id        Number;
    v_Order_State      Varchar2(100);
    v_Next_Excute_Step Number;
    v_Next_Action      Varchar2(100);
    v_Nextauto_Excute  Varchar2(100);
    v_Next_State       Varchar2(100);
    v_Period_Type      Varchar2(100);

    v_Err_Number Number;
    v_Status     Varchar2(50); --辅助状态
    v_String     Varchar2(500); --辅助信息

    v_Defer_Supply_Days    Varchar2(200);
    n_Productng_Area_Count Number;
    p_Order_Number_l       Varchar2(100);
    v_Value                Varchar2(2000);
    r_Collect_Head         t_Pln_Order_Collect_Head%Rowtype;
    r_order_type           t_pln_order_type%RowType;
    v_main_param           varchar2(32);
    V_PLN_CHK_TYPE         T_BD_PARAM_LIST.DEFAULT_VALUE%TYPE; --提货订单计划评审处理类型
    V_DEAL_MONEY_CIMS      VARCHAR2(100);
    V_DEAL_MONEY_IMS       VARCHAR2(100);
  Begin
    p_Result := v_Success;
    If p_Collect_Head_Id Is Null Or p_User_Code Is Null Then
      p_Result := '部分参数为空或错误';
      Raise v_Base_Exception;
    End If;

    v_Status := Substrb((v_Nl || '检查订单状态，并读锁定' || '：'), 1, 50);
    Begin
      Select *
        Into r_Collect_Head
        From t_Pln_Order_Collect_Head h
       Where Coll_Ord_Head_Id = p_Collect_Head_Id
      --And (Form_State In ('21', '30') Or Order_Type_Name = '工厂增补')
         For Update Nowait;

      v_Entity_Id     := r_Collect_Head.Entity_Id;
      v_Period_Id     := r_Collect_Head.Period_Id;
      v_Order_Type_Id := r_Collect_Head.Order_Type_Id;
      v_Order_State   := r_Collect_Head.Form_State;
    Exception
      When Others Then
        p_Result := '检查失败，请检查订单状态;当前单据可能已被退回。' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;

    Begin
      Select p.Period_Type
        Into v_Period_Type
        From t_Pln_Order_Period p
       Where p.Entity_Id = v_Entity_Id
         And p.Period_Id = v_Period_Id;
    Exception
      When Others Then
        p_Result := '获取周期类型失败,周期ID：' || v_Period_Id || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;
    Begin
      select * into r_order_type
      From t_pln_order_type ty
      where ty.order_type_id=r_Collect_Head.Order_Type_Id
       And  ty.entity_id=r_Collect_Head.Entity_Id;
    Exception
      when others then
        p_Result :='获取单据类型失败,单据ID:'||r_Collect_Head.Order_Type_Id ||Sqlerrm;
        Raise v_Base_Exception;
    end;
    if r_order_type.is_count='Y' then
       begin
      for  r_result in (
      select  l.item_id ,l.can_produce_qty,l.entity_id  from  t_pln_order_line l,
                       t_pln_order_collect_relation r
                       where r.order_collect_head_id=p_Collect_Head_Id
                             and l.order_line_id=r.order_line_id) loop
          Pkg_Pln_Pub.p_Check_Item_Rounding(r_result.entity_id,
                                            r_result.item_id,
                                            r_result.can_produce_qty,
                                            p_result);
             if  p_result != v_Success  then
               v_Value :=v_Value||p_result || v_Nl;
               end if ;
         end loop;
       end ;
    end if ;
    If  v_Value is not null Then
                  p_result :=v_Value;
                  Raise v_Base_Exception;
    End If;
    Begin
      --'获取当单据据类型的下一单据状态';
      Pkg_Pln_Pub.p_Get_Order_Next_Status(p_Order_Type_Id    => v_Order_Type_Id,
                                          p_Curr_State       => v_Order_State,
                                          p_Curr_Action      => p_Operation_Action,
                                          p_Can_Option_Flag  => 'N',
                                          p_Next_Excute_Step => v_Next_Excute_Step,
                                          p_Nextauto_Excute  => v_Nextauto_Excute,
                                          p_Next_State       => v_Next_State,
                                          p_Next_Action      => v_Next_Action,
                                          p_Result           => p_Result);
      If p_Result <> v_Success Then
        p_Result := '获取订单下一状态失败！当前订单状态：' || v_Order_State || v_Nl ||
                    p_Result;
        Raise v_Base_Exception;
      End If;
    Exception
      When Others Then
        p_Result := p_Result;
        Raise v_Base_Exception;
    End;
    --T+3订单检查齐套率
    --add by zcc 2015-7-29
    begin
        v_main_param := pkg_bd.F_GET_PARAMETER_VALUE('PLN_IS_MERGE_LG_ORDER',
                                                   r_Collect_Head.Entity_Id);
    exception
      when others then
        p_Result := '获取提货转计划汇总参数失败' || v_nl || sqlerrm;
        raise v_Base_Exception;
    end;
    begin
      if v_main_param = 'TN_SUM' then
        for r_order_head in (select distinct h.order_head_id
                               from t_pln_order_head             h,
                                    t_pln_order_collect_relation r,
                                     t_pln_order_line l
                              where h.order_head_id = l.order_head_id
                                and l.order_line_id = r.order_line_id
                                and r.order_collect_head_id =
                                    r_Collect_Head.Coll_Ord_Head_Id
                                and r.entity_id = r_Collect_Head.Entity_Id) loop
          pkg_pln_pub.p_Count_Order_Neat_Set_Rate(r_order_head.order_head_id,
                                                  r_Collect_Head.Entity_Id,
                                                  p_User_Code,
                                                  p_Result);
          if p_result <> v_Success then
            raise v_Base_Exception;
          end if;
        end loop;
      end if;
    end;

    --回写关联T+3订单的提货订单数量
    BEGIN
      V_PLN_CHK_TYPE := PKG_BD.F_GET_PARAMETER_VALUE('PLN_LG_PLNNOCHK_CANCEL', r_Collect_Head.Entity_Id);
    EXCEPTION
      when others then
        p_Result := '获取按产品分解时调整提货订单方式【PLN_LG_PLNNOCHK_CANCEL】参数失败' || v_nl || sqlerrm;
        raise v_Base_Exception;
    END;

    BEGIN
      IF V_PLN_CHK_TYPE = 'CANCEL_ORDER' THEN
        for r_lg_line in (SELECT OH.LOCK_AMOUNT_FLAG CIMS_LOCK_AMOUNT_FLAG,
                                 Pkg_Pln_Intf_Ims.f_get_Ims_Lg_Lock_flag(OH.ORDER_HEAD_ID, OH.ENTITY_ID) IMS_LOCK_AMOUNT_FLAG,
                                 OL.*
                            FROM T_PLN_LG_ORDER_LINE OL, T_PLN_LG_ORDER_HEAD OH
                           WHERE OL.ORDER_HEAD_ID = OH.ORDER_HEAD_ID
                             AND EXISTS (SELECT 1
                                    FROM T_PLN_LG_RELATION            LR,
                                         T_PLN_ORDER_LINE             L,
                                         T_PLN_ORDER_COLLECT_RELATION R
                                   WHERE LR.ORDER_LINE_ID = L.ORDER_LINE_ID
                                     AND L.ORDER_LINE_ID = R.ORDER_LINE_ID
                                     AND LR.LG_ORDER_LINE_ID = OL.ORDER_LINE_ID
                                     AND R.ORDER_COLLECT_HEAD_ID = r_Collect_Head.Coll_Ord_Head_Id
                                     AND R.ENTITY_ID = r_Collect_Head.Entity_Id)) loop
          --回写计划评审操作
          pkg_pln_pub.P_WriteBack_Opt_Intf(p_Lg_Order_Head_Id => r_lg_line.order_head_id, --提货订单头ID
                                           p_Lg_Order_Line_Id => r_lg_line.order_line_id, --提货订单行ID
                                           p_Entity_Id        => r_Collect_Head.Entity_Id, --主体ID
                                           p_Opt_Type         => '计划评审', --操作类型
                                           p_Transaction_Qty  => r_lg_line.TO_PLN_QTY, --数量
                                           p_Deal_Money_Cims  => '不处理款项', --CIMS款项处理标志
                                           p_Deal_Money_Ims   => '不处理款项', --IMS款项处理标志
                                           p_User_Code        => p_User_Code, --操作用户
                                           p_Result           => p_Result);
          if p_result <> v_Success then
            raise v_Base_Exception;
          end if;

          --回写计划评审取消数量
          IF r_lg_line.TO_PLN_QTY > NVL(r_lg_line.PLN_CHK_QTY, 0) THEN
            IF r_lg_line.CIMS_LOCK_AMOUNT_FLAG IN ('S', 'TS') THEN
              V_DEAL_MONEY_CIMS := '解锁款项';
            ELSE
              V_DEAL_MONEY_CIMS := '不处理款项';
            END IF;

            IF r_lg_line.IMS_LOCK_AMOUNT_FLAG IN ('T') THEN
              V_DEAL_MONEY_IMS := '解锁款项';
            ELSE
              V_DEAL_MONEY_IMS := '不处理款项';
            END IF;

            --更新提货订单行转T+3数量和取消数量
            UPDATE T_PLN_LG_ORDER_LINE L
               SET L.TO_PLN_QTY = NVL(r_lg_line.PLN_CHK_QTY, 0),
                   L.CANCEL_QTY = NVL(L.CANCEL_QTY, 0) + r_lg_line.TO_PLN_QTY - NVL(r_lg_line.PLN_CHK_QTY, 0),
                   L.LAST_UPDATED_BY = p_User_Code,
                   L.LAST_UPDATE_DATE = SYSDATE,
                   L.VERSION = NVL(L.VERSION,0)+1
             WHERE L.ORDER_LINE_ID = r_lg_line.order_line_id;
            
            --hejy3 更新提货订单头
            UPDATE T_PLN_LG_ORDER_HEAD H
               SET H.LAST_UPDATED_BY = p_User_Code,
                   H.LAST_UPDATE_DATE = SYSDATE,
                   H.VERSION = NVL(H.VERSION, 0) + 1
             WHERE H.ORDER_HEAD_ID = r_lg_line.Order_Head_Id;

            --回写计划评审操作
            pkg_pln_pub.P_WriteBack_Opt_Intf(p_Lg_Order_Head_Id => r_lg_line.order_head_id, --提货订单头ID
                                             p_Lg_Order_Line_Id => r_lg_line.order_line_id, --提货订单行ID
                                             p_Entity_Id        => r_Collect_Head.Entity_Id, --主体ID
                                             p_Opt_Type         => '计划评审取消', --操作类型
                                             p_Transaction_Qty  => NVL(r_lg_line.PLN_CHK_QTY, 0) - r_lg_line.TO_PLN_QTY, --数量
                                             p_Deal_Money_Cims  => V_DEAL_MONEY_CIMS, --CIMS款项处理标志
                                             p_Deal_Money_Ims   => V_DEAL_MONEY_IMS, --IMS款项处理标志
                                             p_User_Code        => p_User_Code, --操作用户
                                             p_Result           => p_Result);
          END IF;
        end loop;
      END IF;
    END;
    
    --hejy3 T+3优化
    PKG_PLN_PUB.P_UPD_LG_CONSIGNMENT_SINGLE(p_Walkthrough_Batch => TO_CHAR(p_Collect_Head_Id),
                                            p_Opertation_Action => '排产',
                                            p_User_Code         => p_User_Code,
                                            p_Result            => p_Result);

    --将订单状态改为“评审完毕”
    Update t_Pln_Order_Collect_Head Ch
       Set Form_State       = v_Next_State,
           Last_Updated_By  = p_User_Code,
           Last_Update_Date = Sysdate
     Where Ch.Coll_Ord_Head_Id = p_Collect_Head_Id;

    p_Result := v_Success;
  Exception
    When v_Base_Exception Then
      p_Result := '失败原因：' || p_Result || v_Nl || Sqlerrm;
      Rollback;
    When Others Then
      p_Result := Substrb(('未知错误：' || v_Result || v_Status || v_Nl
                          || p_result || v_nl|| Sqlerrm ),
                          1,
                          2000);
      Rollback;
  End;

  -----------------------------------------------------------------------------
  ---- AUTHOR  : 李振
  -- CREATED : 201409-06
  -- PURPOSE : 汇总 汇总确认
  -----------------------------------------------------------------------------
  Procedure p_Collect_Confirm_Order(p_Collect_Head_Id  In Number, ----订单ID
                                    p_Operation_Action In Varchar2, --当前单据动作
                                    p_User_Code        In Varchar2, ----用户ID
                                    p_Result           Out Varchar2 --返回结果：成功返回"SUCCESS"，失败返回原因
                                    ) Is

    v_Tmp_Flag         Varchar2(1); --临时标识，01位长
    v_Entity_Id        Number;
    v_Order_Type_Id    Number;
    v_Order_Type_Name  Varchar2(50); --订单类型
    v_Customer_Id      Number;
    v_Period_Id        Number;
    v_Order_State      Varchar2(100);
    v_Next_Excute_Step Number;
    v_Next_Action      Varchar2(100);
    v_Nextauto_Excute  Varchar2(100);
    v_Next_State       Varchar2(100);
    v_Period_Type      Varchar2(100);

    r_Collect_Head t_Pln_Order_Collect_Head%Rowtype;
  Begin
    p_Result := v_Success;
    If p_Collect_Head_Id Is Null Or p_User_Code Is Null Then
      p_Result := '部分参数为空或错误';
      Raise v_Base_Exception;
    End If;

    Begin
      Select *
        Into r_Collect_Head
        From t_Pln_Order_Collect_Head h
       Where Coll_Ord_Head_Id = p_Collect_Head_Id
         --And Form_State In ('24') --汇总订单状态“初始”
         For Update Nowait;

      v_Entity_Id     := r_Collect_Head.Entity_Id;
      v_Period_Id     := r_Collect_Head.Period_Id;
      v_Order_Type_Id := r_Collect_Head.Order_Type_Id;
      v_Order_State   := r_Collect_Head.Form_State;
    Exception
      When Others Then
        p_Result := '锁定汇总订单失败，请检查订单状态;当前单据可能已被退回。' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;

    Begin
      Select p.Period_Type
        Into v_Period_Type
        From t_Pln_Order_Period p
       Where p.Entity_Id = v_Entity_Id
         And p.Period_Id = v_Period_Id;
    Exception
      When Others Then
        p_Result := '获取周期类型失败,周期ID：' || v_Period_Id || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;
    --检查周期是否打开、关闭
    Pkg_Pln_Pub.p_Check_Period(v_Period_Id,
                               v_Period_Type,
                               v_True,
                               v_False,
                               'O',
                               p_Result);
    If Nvl(p_Result, v_Null) <> v_Success Then
      Raise v_Base_Exception;
    End If;

    Begin
      --'获取当单据据类型的下一单据状态';
      Pkg_Pln_Pub.p_Get_Order_Next_Status(p_Order_Type_Id    => v_Order_Type_Id,
                                          p_Curr_State       => v_Order_State,
                                          p_Curr_Action      => p_Operation_Action,
                                          p_Can_Option_Flag  => 'N',
                                          p_Next_Excute_Step => v_Next_Excute_Step,
                                          p_Nextauto_Excute  => v_Nextauto_Excute,
                                          p_Next_State       => v_Next_State,
                                          p_Next_Action      => v_Next_Action,
                                          p_Result           => p_Result);
      If p_Result <> v_Success Then
        p_Result := '获取订单下一状态失败！当前订单状态：' || v_Order_State || v_Nl ||
                    p_Result;
        Raise v_Base_Exception;
      End If;
    Exception
      When Others Then
        p_Result := p_Result;
        Raise v_Base_Exception;
    End;

    /*
    0 按周报送  plnSendByType
    1 按月报送  plnSendByType
    2 按月多次报送  plnSendByType
    3 按年报送  plnSendByType
    4 按周多次报送  plnSendByType
    6 按T+3报送
    7 按T+3多次报送
    --多次报送时，不终止单据类型
    */
    Update t_Pln_Order_Type Ot
       Set Ot.End_Date = Trunc(Sysdate)
     Where Ot.Entity_Id = v_Entity_Id
       And Ot.Send_By_Type Not In ('2', '4', '7')
       And Ot.Order_Type_Id = r_Collect_Head.Order_Type_Id;

    --更新汇总订单状态
    Update t_Pln_Order_Collect_Head Ch
       Set Form_State       = v_Next_State,
           Last_Updated_By  = p_User_Code,
           Last_Update_Date = Sysdate
     Where Ch.Coll_Ord_Head_Id = p_Collect_Head_Id;

    --更新计划订单状态为“已汇总”
    Update t_Pln_Order_Head Oh
       Set Oh.Form_State       = '25', --更新计划订单状态为“已汇”
           Oh.Last_Updated_By  = p_User_Code,
           Oh.Last_Update_Date = Sysdate
     Where Oh.Order_Head_Id In
           (Select l.Order_Head_Id
              From t_Pln_Order_Line             l,
                   t_Pln_Order_Collect_Relation Ocr,
                   t_Pln_Order_Collect_Head     Och,
                   t_Pln_Order_Collect_Line     Ocl
             Where Och.Coll_Ord_Head_Id = p_Collect_Head_Id
               And Ocl.Coll_Ord_Head_Id = Och.Coll_Ord_Head_Id
               And Ocl.Coll_Ord_Line_Id = Ocr.Coll_Ord_Line_Id
               And Ocr.Order_Line_Id = l.Order_Line_Id);

    p_Result := v_Success;
  Exception
    When v_Base_Exception Then
      p_Result := '失败原因：' || p_Result || v_Nl || Sqlerrm;
      Rollback;
    When Others Then
      p_Result := '未知错误：' || v_Result || v_Nl || Sqlerrm;
      Rollback;
  End;

  -----------------------------------------------------------------------------
  ---- AUTHOR  : 李振
  -- CREATED : 201409-06
  -- PURPOSE : 汇总 库存评审
  -----------------------------------------------------------------------------
  Procedure p_Inv_Review_Order(p_Collect_Head_Id  In Number, ----订单ID
                               p_Operation_Action In Varchar2, --当前单据动作
                               p_User_Code        In Varchar2, ----用户ID
                               p_Result           Out Varchar2 --返回结果：成功返回"SUCCESS"，失败返回原因
                               ) Is

    v_Tmp_Flag         Varchar2(1); --临时标识，01位长
    v_Entity_Id        Number;
    v_Order_Type_Id    Number;
    v_Order_Type_Name  Varchar2(50); --订单类型
    v_Customer_Id      Number;
    v_Period_Id        Number;
    v_Order_State      Varchar2(100);
    v_Next_Excute_Step Number;
    v_Next_Action      Varchar2(100);
    v_Nextauto_Excute  Varchar2(100);
    v_Next_State       Varchar2(100);
    v_Period_Type      Varchar2(100);
    v_Value        Varchar2(2000);
    v_batch_id      number;
    r_Collect_Head t_Pln_Order_Collect_Head%Rowtype;
  Begin
    p_Result := v_Success;
    If p_Collect_Head_Id Is Null Or p_User_Code Is Null Then
      p_Result := '部分参数为空或错误';
      Raise v_Base_Exception;
    End If;

    Begin
      Select *
        Into r_Collect_Head
        From t_Pln_Order_Collect_Head h
       Where Coll_Ord_Head_Id = p_Collect_Head_Id
         --And Form_State In ('25') --汇总订单状态“已汇总”
         For Update Nowait;

      v_Entity_Id     := r_Collect_Head.Entity_Id;
      v_Period_Id     := r_Collect_Head.Period_Id;
      v_Order_Type_Id := r_Collect_Head.Order_Type_Id;
      v_Order_State   := r_Collect_Head.Form_State;
      v_batch_id      :=to_number(r_Collect_Head.Coll_Ord_Number);
    Exception
      When Others Then
        p_Result := '锁定汇总订单失败，请检查订单状态;当前单据可能已被退回。' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;

    Begin
      Select p.Period_Type
        Into v_Period_Type
        From t_Pln_Order_Period p
       Where p.Entity_Id = v_Entity_Id
         And p.Period_Id = v_Period_Id;
    Exception
      When Others Then
        p_Result := '获取周期类型失败,周期ID：' || v_Period_Id || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;
    --检查周期是否打开、关闭
    Pkg_Pln_Pub.p_Check_Period(v_Period_Id,
                               v_Period_Type,
                               v_True,
                               v_False,
                               'O',
                               p_Result);
    If Nvl(p_Result, v_Null) <> v_Success Then
      Raise v_Base_Exception;
    End If;

    Begin
      --'获取当单据据类型的下一单据状态';
      Pkg_Pln_Pub.p_Get_Order_Next_Status(p_Order_Type_Id    => v_Order_Type_Id,
                                          p_Curr_State       => v_Order_State,
                                          p_Curr_Action      => p_Operation_Action,
                                          p_Can_Option_Flag  => 'Y', --库存评审为"可选流程"
                                          p_Next_Excute_Step => v_Next_Excute_Step,
                                          p_Nextauto_Excute  => v_Nextauto_Excute,
                                          p_Next_State       => v_Next_State,
                                          p_Next_Action      => v_Next_Action,
                                          p_Result           => p_Result);
      If p_Result <> v_Success Then
        p_Result := '获取订单下一状态失败！当前订单状态：' || v_Order_State || v_Nl ||
                    p_Result;
        Raise v_Base_Exception;
      End If;
    Exception
      When Others Then
        p_Result := p_Result;
        Raise v_Base_Exception;
    End;

    --将订单状态改为“评审完毕”
    Update t_Pln_Order_Collect_Head Ch
       Set Form_State       = v_Next_State,
           Pre_Field_02     = Decode(v_Order_Type_Id, 220, Null, '282'),
           Last_Updated_By  = p_User_Code,
           Last_Update_Date = Sysdate
     Where Ch.Coll_Ord_Head_Id = p_Collect_Head_Id;

    /*--更新计划订单状态为“已汇总”
    Update t_Pln_Order_Head Oh
       Set Oh.Form_State       = '25', --更新计划订单状态为“已汇总”
           Oh.Last_Updated_By  = p_User_Code,
           Oh.Last_Update_Date = Sysdate
     Where Oh.Order_Head_Id In
           (Select l.Order_Head_Id
              From t_Pln_Order_Line             l,
                   t_Pln_Order_Collect_Relation Ocr,
                   t_Pln_Order_Collect_Head     Och,
                   t_Pln_Order_Collect_Line     Ocl
             Where Och.Coll_Ord_Head_Id = p_Collect_Head_Id
               And Ocl.Coll_Ord_Head_Id = Och.Coll_Ord_Head_Id
               And Ocl.Coll_Ord_Line_Id = Ocr.Coll_Ord_Line_Id
               And Ocr.Order_Line_Id = l.Order_Line_Id);*/
    p_Result := v_Success;
  Exception
    When v_Base_Exception Then
      p_Result := '失败原因：' || p_Result;
      Rollback;
    When Others Then
      p_Result := '未知错误：' || v_Result || v_Nl || Sqlerrm;
      Rollback;
  End;

  -----------------------------------------------------------------------------
  ---- AUTHOR  : 李振
  -- CREATED : 201409-06
  -- PURPOSE : 汇总 总部评审
  -----------------------------------------------------------------------------
  Procedure p_Hq_Review_Order(p_Collect_Head_Id  In Number, ----订单ID
                              p_Operation_Action In Varchar2, --当前单据动作
                              p_User_Code        In Varchar2, ----用户ID
                              p_Result           Out Varchar2 --返回结果：成功返回"SUCCESS"，失败返回原因
                              ) Is

    v_Tmp_Flag         Varchar2(1); --临时标识，01位长
    v_Entity_Id        Number;
    v_Order_Type_Id    Number;
    v_Order_Type_Name  Varchar2(50); --订单类型
    v_Customer_Id      Number;
    v_Period_Id        Number;
    v_Order_State      Varchar2(100);
    v_Next_Excute_Step Number;
    v_Next_Action      Varchar2(100);
    v_Nextauto_Excute  Varchar2(100);
    v_Next_State       Varchar2(100);
    v_Period_Type      Varchar2(100);
    v_batch_id         number ;

    v_Value        Varchar2(2000);
    r_Collect_Head t_Pln_Order_Collect_Head%Rowtype;
  Begin
    p_Result := v_Success;
    If p_Collect_Head_Id Is Null Or p_User_Code Is Null Then
      p_Result := '部分参数为空或错误';
      Raise v_Base_Exception;
    End If;

    Begin
      Select *
        Into r_Collect_Head
        From t_Pln_Order_Collect_Head h
       Where Coll_Ord_Head_Id = p_Collect_Head_Id
         --And Form_State In ('25', '26') --汇总订单状态“已汇总”, "库存评审"
         For Update Nowait;

      v_Entity_Id     := r_Collect_Head.Entity_Id;
      v_Period_Id     := r_Collect_Head.Period_Id;
      v_Order_Type_Id := r_Collect_Head.Order_Type_Id;
      v_Order_State   := r_Collect_Head.Form_State;
      v_batch_id      :=to_number(r_Collect_Head.Coll_Ord_Number);
    Exception
      When Others Then
        p_Result := '锁定汇总订单失败，请检查订单状态;当前单据可能已被退回。' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;

    Begin
      Select p.Period_Type
        Into v_Period_Type
        From t_Pln_Order_Period p
       Where p.Entity_Id = v_Entity_Id
         And p.Period_Id = v_Period_Id;
    Exception
      When Others Then
        p_Result := '获取周期类型失败,周期ID：' || v_Period_Id || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;
    --检查周期是否打开、关闭
    Pkg_Pln_Pub.p_Check_Period(v_Period_Id,
                               v_Period_Type,
                               v_True,
                               v_False,
                               'O',
                               p_Result);
    If Nvl(p_Result, v_Null) <> v_Success Then
      Raise v_Base_Exception;
    End If;

    Begin
      --'获取当单据据类型的下一单据状态';
      Pkg_Pln_Pub.p_Get_Order_Next_Status(p_Order_Type_Id    => v_Order_Type_Id,
                                          p_Curr_State       => v_Order_State,
                                          p_Curr_Action      => p_Operation_Action,
                                          p_Can_Option_Flag  => v_False,
                                          p_Next_Excute_Step => v_Next_Excute_Step,
                                          p_Nextauto_Excute  => v_Nextauto_Excute,
                                          p_Next_State       => v_Next_State,
                                          p_Next_Action      => v_Next_Action,
                                          p_Result           => p_Result);
      If p_Result <> v_Success Then
        p_Result := '获取订单下一状态失败！当前订单状态：' || v_Order_State || v_Nl ||
                    p_Result;
        Raise v_Base_Exception;
      End If;
    Exception
      When Others Then
        p_Result := p_Result;
        Raise v_Base_Exception;
    End;

    --将订单状态改为“评审完毕”
    Update t_Pln_Order_Collect_Head Ch
       Set Form_State       = v_Next_State,
           Last_Updated_By  = p_User_Code,
           Last_Update_Date = Sysdate
     Where Ch.Coll_Ord_Head_Id = p_Collect_Head_Id;
     --更新计划订单头
     update t_pln_order_head h
     set h.hq_check_date=sysdate,
         h.last_updated_by=p_user_code,
         h.last_update_date=sysdate,
         h.hq_check_user=p_User_Code
      where h.batch_id=v_batch_id
         and h.order_type_id=v_Order_Type_Id
         and h.period_id=v_Period_Id
         and h.form_state='25';
    p_Result := v_Success;
  Exception
    When v_Base_Exception Then
      p_Result := '失败原因：' || p_Result || v_Nl || Sqlerrm;
      Rollback;
    When Others Then
      p_Result := Substrb(('未知错误：' || v_Result || v_Nl || Sqlerrm),
                          1,
                          2000);
      Rollback;
  End;

  -----------------------------------------------------------------------------
  ---- AUTHOR  : 李振
  -- CREATED : 201409-06
  -- PURPOSE : 汇总 分解确认
  -----------------------------------------------------------------------------
  Procedure p_Resolve_Confirm_Order(p_Collect_Head_Id  In Number, ----订单ID
                                    p_Operation_Action In Varchar2, --当前单据动作
                                    p_User_Code        In Varchar2, ----用户ID
                                    p_Result           Out Varchar2 --返回结果：成功返回"SUCCESS"，失败返回原因
                                    ) Is

    v_Tmp_Flag         Varchar2(1); --临时标识，01位长
    v_Entity_Id        Number;
    v_Order_Type_Id    Number;
    v_Order_Type_Name  Varchar2(50); --订单类型
    v_Customer_Id      Number;
    v_Period_Id        Number;
    v_Order_State      Varchar2(100);
    v_Next_Excute_Step Number;
    v_Next_Action      Varchar2(100);
    v_Nextauto_Excute  Varchar2(100);
    v_Next_State       Varchar2(100);
    v_Period_Type      Varchar2(100);

    v_Value        Varchar2(2000);
    r_Collect_Head t_Pln_Order_Collect_Head%Rowtype;
  Begin
    p_Result := v_Success;
    If p_Collect_Head_Id Is Null Or p_User_Code Is Null Then
      p_Result := '部分参数为空或错误';
      Raise v_Base_Exception;
    End If;

    Begin
      Select *
        Into r_Collect_Head
        From t_Pln_Order_Collect_Head h
       Where Coll_Ord_Head_Id = p_Collect_Head_Id
         --And Form_State In ('21') --汇总订单状态“已总部评审”
         For Update Nowait;

      v_Entity_Id     := r_Collect_Head.Entity_Id;
      v_Period_Id     := r_Collect_Head.Period_Id;
      v_Order_Type_Id := r_Collect_Head.Order_Type_Id;
      v_Order_State   := r_Collect_Head.Pre_Field_02;
    Exception
      When Others Then
        p_Result := '锁定汇总订单失败，请检查订单状态;当前单据可能已被退回。' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;

    Begin
      Select p.Period_Type
        Into v_Period_Type
        From t_Pln_Order_Period p
       Where p.Entity_Id = v_Entity_Id
         And p.Period_Id = v_Period_Id;
    Exception
      When Others Then
        p_Result := '获取周期类型失败,周期ID：' || v_Period_Id || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;
    --检查周期是否打开、关闭
    Pkg_Pln_Pub.p_Check_Period(v_Period_Id,
                               v_Period_Type,
                               v_True,
                               v_False,
                               'O',
                               p_Result);
    If Nvl(p_Result, v_Null) <> v_Success Then
      Raise v_Base_Exception;
    End If;

    Begin
      --'获取当单据据类型的下一单据状态';
      Pkg_Pln_Pub.p_Get_Flow_Next_Status(p_Flow_Id           => 576,
                                          p_Curr_State       => v_Order_State,
                                          p_Curr_Action      => p_Operation_Action,
                                          p_Can_Option_Flag  => v_False,
                                          p_Next_Excute_Step => v_Next_Excute_Step,
                                          p_Nextauto_Excute  => v_Nextauto_Excute,
                                          p_Next_State       => v_Next_State,
                                          p_Next_Action      => v_Next_Action,
                                          p_Result           => p_Result);
      If p_Result <> v_Success Then
        p_Result := '获取订单下一状态失败！当前订单状态：' || v_Order_State || v_Nl ||
                    p_Result;
        Raise v_Base_Exception;
      End If;
    Exception
      When Others Then
        p_Result := p_Result;
        Raise v_Base_Exception;
    End;

    --将订单状态改为“评审完毕”
    Update t_Pln_Order_Collect_Head Ch
       Set Pre_Field_02     = v_Next_State,
           Last_Updated_By  = p_User_Code,
           Last_Update_Date = Sysdate
     Where Ch.Coll_Ord_Head_Id = p_Collect_Head_Id;

    p_Result := v_Success;
  Exception
    When v_Base_Exception Then
      p_Result := '失败原因：' || p_Result;
      Rollback;
    When Others Then
      p_Result := '未知错误：' || v_Result || v_Nl || Sqlerrm;
      Rollback;
  End;

  -----------------------------------------------------------------------------
  ---- AUTHOR  : 李振
  -- CREATED : 201409-06
  -- PURPOSE : 汇总 工厂评审
  -----------------------------------------------------------------------------
  Procedure p_Factory_Review_Order(p_Collect_Head_Id  In Number, ----订单ID
                                   p_Operation_Action In Varchar2, --当前单据动作
                                   p_User_Code        In Varchar2, ----用户ID
                                   p_Result           Out Varchar2 --返回结果：成功返回"SUCCESS"，失败返回原因
                                   ) Is

    v_Tmp_Flag         Varchar2(1); --临时标识，01位长
    v_Entity_Id        Number;
    v_Order_Type_Id    Number;
    v_Order_Type_Name  Varchar2(50); --订单类型
    v_Customer_Id      Number;
    v_Period_Id        Number;
    v_Order_State      Varchar2(100);
    v_Next_Excute_Step Number;
    v_Next_Action      Varchar2(100);
    v_Nextauto_Excute  Varchar2(100);
    v_Next_State       Varchar2(100);
    v_Period_Type      Varchar2(100);
    v_batch_id         number ;

    v_Value        Varchar2(2000);
    r_Collect_Head t_Pln_Order_Collect_Head%Rowtype;
  Begin
    p_Result := v_Success;
    If p_Collect_Head_Id Is Null Or p_User_Code Is Null Then
      p_Result := '部分参数为空或错误';
      Raise v_Base_Exception;
    End If;

    Begin
      Select *
        Into r_Collect_Head
        From t_Pln_Order_Collect_Head h
       Where Coll_Ord_Head_Id = p_Collect_Head_Id
         --And Form_State In ('330') --汇总订单状态“已分解确认”
         For Update Nowait;

      v_Entity_Id     := r_Collect_Head.Entity_Id;
      v_Period_Id     := r_Collect_Head.Period_Id;
      v_Order_Type_Id := r_Collect_Head.Order_Type_Id;
      v_Order_State   := r_Collect_Head.Form_State;
      v_batch_id      := to_number(r_Collect_Head.Coll_Ord_Number);
    Exception
      When Others Then
        p_Result := '锁定汇总订单失败，请检查订单状态;当前单据可能已被退回。' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;

    Begin
      Select p.Period_Type
        Into v_Period_Type
        From t_Pln_Order_Period p
       Where p.Entity_Id = v_Entity_Id
         And p.Period_Id = v_Period_Id;
    Exception
      When Others Then
        p_Result := '获取周期类型失败,周期ID：' || v_Period_Id || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;
    --检查周期是否打开、关闭
    Pkg_Pln_Pub.p_Check_Period(v_Period_Id,
                               v_Period_Type,
                               v_True,
                               v_False,
                               'O',
                               p_Result);
    If Nvl(p_Result, v_Null) <> v_Success Then
      Raise v_Base_Exception;
    End If;

    Begin
      --'获取当单据据类型的下一单据状态';
      Pkg_Pln_Pub.p_Get_Order_Next_Status(p_Order_Type_Id    => v_Order_Type_Id,
                                          p_Curr_State       => v_Order_State,
                                          p_Curr_Action      => p_Operation_Action,
                                          p_Can_Option_Flag  => v_False,
                                          p_Next_Excute_Step => v_Next_Excute_Step,
                                          p_Nextauto_Excute  => v_Nextauto_Excute,
                                          p_Next_State       => v_Next_State,
                                          p_Next_Action      => v_Next_Action,
                                          p_Result           => p_Result);
      If p_Result <> v_Success Then
        p_Result := '获取订单下一状态失败！当前订单状态：' || v_Order_State || v_Nl ||
                    p_Result;
        Raise v_Base_Exception;
      End If;
    Exception
      When Others Then
        p_Result := p_Result;
        Raise v_Base_Exception;
    End;

    --将订单状态改为“评审完毕”
    Update t_Pln_Order_Collect_Head Ch
       Set Form_State       = v_Next_State,
           Last_Updated_By  = p_User_Code,
           Last_Update_Date = Sysdate
     Where Ch.Coll_Ord_Head_Id = p_Collect_Head_Id;
     --更新计划订单头
     update t_pln_order_head h
     set h.fc_check_date=sysdate,
         h.last_updated_by=p_user_code,
         h.last_update_date=sysdate,
         h.fc_check_user=p_User_Code
      where h.batch_id=v_batch_id
         and h.order_type_id=v_Order_Type_Id
         and h.period_id=v_Period_Id
         and h.form_state='25';
    p_Result := v_Success;
  Exception
    When v_Base_Exception Then
      p_Result := '失败原因：' || p_Result;
      Rollback;
    When Others Then
      p_Result := '未知错误：' || v_Result || v_Nl || Sqlerrm;
      Rollback;
  End;

  -----------------------------------------------------------------------------
  ---- AUTHOR  : 李振
  -- CREATED : 201409-06
  -- PURPOSE : 汇总 APS交互、APS产能校验
  -----------------------------------------------------------------------------
  Procedure p_Aps_Interactive_Order(p_Collect_Head_Id  In Number, ----订单ID
                                    p_Operation_Action In Varchar2, --当前单据动作
                                    p_User_Code        In Varchar2, ----用户ID
                                    p_Result           Out Varchar2 --返回结果：成功返回"SUCCESS"，失败返回原因
                                    ) Is

    v_Tmp_Flag         Varchar2(1); --临时标识，01位长
    v_Entity_Id        Number;
    v_Order_Type_Id    Number;
    v_Order_Type_Name  Varchar2(50); --订单类型
    v_Customer_Id      Number;
    v_Period_Id        Number;
    v_Order_State      Varchar2(100);
    v_Next_Excute_Step Number;
    v_Next_Action      Varchar2(100);
    v_Nextauto_Excute  Varchar2(100);
    v_Next_State       Varchar2(100);
    v_Period_Type      Varchar2(100);

    v_Value        Varchar2(2000);
    r_Collect_Head t_Pln_Order_Collect_Head%Rowtype;
  Begin
    p_Result := v_Success;
    If p_Collect_Head_Id Is Null Or p_User_Code Is Null Then
      p_Result := '部分参数为空或错误';
      Raise v_Base_Exception;
    End If;

    Begin
      Select *
        Into r_Collect_Head
        From t_Pln_Order_Collect_Head h
       Where Coll_Ord_Head_Id = p_Collect_Head_Id
         --And Form_State In ('22') --汇总订单状态“已工厂评审”
         For Update Nowait;

      v_Entity_Id     := r_Collect_Head.Entity_Id;
      v_Period_Id     := r_Collect_Head.Period_Id;
      v_Order_Type_Id := r_Collect_Head.Order_Type_Id;
      v_Order_State   := r_Collect_Head.Form_State;
    Exception
      When Others Then
        p_Result := '锁定汇总订单失败，请检查订单状态;当前单据可能已被退回。' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;

    Begin
      Select p.Period_Type
        Into v_Period_Type
        From t_Pln_Order_Period p
       Where p.Entity_Id = v_Entity_Id
         And p.Period_Id = v_Period_Id;
    Exception
      When Others Then
        p_Result := '获取周期类型失败,周期ID：' || v_Period_Id || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;
    --检查周期是否打开、关闭
    Pkg_Pln_Pub.p_Check_Period(v_Period_Id,
                               v_Period_Type,
                               v_True,
                               v_False,
                               'O',
                               p_Result);
    If Nvl(p_Result, v_Null) <> v_Success Then
      Raise v_Base_Exception;
    End If;

    Begin
      --'获取当单据据类型的下一单据状态';
      Pkg_Pln_Pub.p_Get_Order_Next_Status(p_Order_Type_Id    => v_Order_Type_Id,
                                          p_Curr_State       => v_Order_State,
                                          p_Curr_Action      => p_Operation_Action,
                                          p_Can_Option_Flag  => v_False,
                                          p_Next_Excute_Step => v_Next_Excute_Step,
                                          p_Nextauto_Excute  => v_Nextauto_Excute,
                                          p_Next_State       => v_Next_State,
                                          p_Next_Action      => v_Next_Action,
                                          p_Result           => p_Result);
      If p_Result <> v_Success Then
        p_Result := '获取订单下一状态失败！当前订单状态：' || v_Order_State || v_Nl ||
                    p_Result;
        Raise v_Base_Exception;
      End If;
    Exception
      When Others Then
        p_Result := p_Result;
        Raise v_Base_Exception;
    End;

    --将订单状态改为“评审完毕”
    Update t_Pln_Order_Collect_Head Ch
       Set Form_State       = v_Next_State,
           Last_Updated_By  = p_User_Code,
           Last_Update_Date = Sysdate
     Where Ch.Coll_Ord_Head_Id = p_Collect_Head_Id;

    p_Result := v_Success;
  Exception
    When v_Base_Exception Then
      p_Result := '失败原因：' || p_Result;
      Rollback;
    When Others Then
      p_Result := '未知错误：' || v_Result || v_Nl || Sqlerrm;
      Rollback;
  End;

  -----------------------------------------------------------------------------
  ---- AUTHOR  : 李振
  -- CREATED : 2016-01-29
  -- PURPOSE : 汇总 APS预排产确认
  -----------------------------------------------------------------------------
  Procedure p_Aps_Walkthrough_Order(p_Collect_Head_Id  In Number, ----订单ID
                                    p_Operation_Action In Varchar2, --当前单据动作
                                    p_User_Code        In Varchar2, ----用户ID
                                    p_Result           Out Varchar2 --返回结果：成功返回"SUCCESS"，失败返回原因
                                    ) Is

    v_Tmp_Flag         Varchar2(1); --临时标识，01位长
    v_Entity_Id        Number;
    v_Order_Type_Id    Number;
    v_Order_Type_Name  Varchar2(50); --订单类型
    v_Customer_Id      Number;
    v_Period_Id        Number;
    v_Order_State      Varchar2(100);
    v_Next_Excute_Step Number;
    v_Next_Action      Varchar2(100);
    v_Nextauto_Excute  Varchar2(100);
    v_Next_State       Varchar2(100);
    v_Period_Type      Varchar2(100);

    v_Value        Varchar2(2000);
    r_Collect_Head t_Pln_Order_Collect_Head%Rowtype;
    v_Walkthrough_Enabled_Flag   Varchar2(32);
    v_Count           Number  := 0;
    v_Line_Count      Number  := 0;

  Begin
    p_Result := v_Success;
    If p_Collect_Head_Id Is Null Or p_User_Code Is Null Then
      p_Result := '部分参数为空或错误';
      Raise v_Base_Exception;
    End If;

    Begin
      Select *
        Into r_Collect_Head
        From t_Pln_Order_Collect_Head h
       Where Coll_Ord_Head_Id = p_Collect_Head_Id
         --And Form_State In ('22') --汇总订单状态“已工厂评审”
         For Update Nowait;

      v_Entity_Id     := r_Collect_Head.Entity_Id;
      v_Period_Id     := r_Collect_Head.Period_Id;
      v_Order_Type_Id := r_Collect_Head.Order_Type_Id;
      v_Order_State   := r_Collect_Head.Form_State;
    Exception
      When Others Then
        p_Result := '锁定汇总订单失败，请检查订单状态;当前单据可能已被退回。' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;

    Begin
      v_Walkthrough_Enabled_Flag := Pkg_Bd.f_Get_Parameter_Value('PLN_WALKTHROUGH_ENABLED_FLAG',
                                                              v_Entity_Id);
    Exception
      When Others Then
        p_Result := '获取PLN_WALKTHROUGH_ENABLED_FLAG参数失败！' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;
    --严控预排管理
    If v_Walkthrough_Enabled_Flag = 'SC' Then
      Select Count(1)
        Into v_Count
        From t_Pln_Order_Collect_Head     Och,
             t_Pln_Order_Collect_Line     Ocl,
             t_Pln_Order_Collect_Relation Ocr,
             t_Pln_Order_Head             Poh,
             t_Pln_Order_Line             Pol
       Where Och.Coll_Ord_Head_Id = Ocl.Coll_Ord_Head_Id
         And Ocr.Order_Collect_Head_Id = Och.Coll_Ord_Head_Id
         And Ocr.Coll_Ord_Line_Id = Ocl.Coll_Ord_Line_Id
         And Ocr.Order_Line_Id = Pol.Order_Line_Id
         And Poh.Order_Head_Id = Pol.Order_Head_Id
         And Nvl(Pol.Can_Produce_Qty, 0) > Nvl(Pol.Aps_Back_Qty, 0)
         And Och.Entity_Id = v_Entity_Id
         And Och.Coll_Ord_Head_Id = p_Collect_Head_Id;
      If v_Count > 0 Then
        p_Result := '预排管理进行严控，T+3订单存在预排未满足本周期订单数据，预排确认失败！';
        Raise v_Base_Exception;
      End If;

      Select Count(1)
        Into v_Line_Count
        From t_Pln_Order_Collect_Head     Och,
             t_Pln_Order_Collect_Line     Ocl,
             t_Pln_Order_Collect_Relation Ocr,
             t_Pln_Order_Head             Poh,
             t_Pln_Order_Line             Pol
       Where Och.Coll_Ord_Head_Id = Ocl.Coll_Ord_Head_Id
         And Ocr.Order_Collect_Head_Id = Och.Coll_Ord_Head_Id
         And Ocr.Coll_Ord_Line_Id = Ocl.Coll_Ord_Line_Id
         And Ocr.Order_Line_Id = Pol.Order_Line_Id
         And Poh.Order_Head_Id = Pol.Order_Head_Id
         And Nvl(Pol.Inv_Affirm_Qty, 0) + Nvl(Pol.Can_Produce_Qty, 0) > 0
         And Och.Entity_Id = v_Entity_Id
         And Och.Coll_Ord_Head_Id = p_Collect_Head_Id;

      Select Count(1)
        Into v_Count
        From t_Pln_Order_Collect_Head     Och,
             t_Pln_Order_Collect_Line     Ocl,
             t_Pln_Order_Collect_Relation Ocr,
             t_Pln_Order_Head             Poh,
             t_Pln_Order_Line             Pol
       Where Och.Coll_Ord_Head_Id = Ocl.Coll_Ord_Head_Id
         And Ocr.Order_Collect_Head_Id = Och.Coll_Ord_Head_Id
         And Ocr.Coll_Ord_Line_Id = Ocl.Coll_Ord_Line_Id
         And Ocr.Order_Line_Id = Pol.Order_Line_Id
         And Poh.Order_Head_Id = Pol.Order_Head_Id
         And Nvl(Pol.Inv_Affirm_Qty, 0) + Nvl(Pol.Can_Produce_Qty, 0) > 0
         And Pol.Aps_Flag = 'S'
         And Och.Entity_Id = v_Entity_Id
         And Och.Coll_Ord_Head_Id = p_Collect_Head_Id;
      If v_Count > v_Line_Count Then
        p_Result := '预排管理进行严控，T+3订单存在未回写预排结果的数据，预排确认失败！';
        Raise v_Base_Exception;
      End If;
    End If;

    Begin
      Select p.Period_Type
        Into v_Period_Type
        From t_Pln_Order_Period p
       Where p.Entity_Id = v_Entity_Id
         And p.Period_Id = v_Period_Id;
    Exception
      When Others Then
        p_Result := '获取周期类型失败,周期ID：' || v_Period_Id || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;
    --检查周期是否打开、关闭
    Pkg_Pln_Pub.p_Check_Period(v_Period_Id,
                               v_Period_Type,
                               v_True,
                               v_False,
                               'O',
                               p_Result);
    If Nvl(p_Result, v_Null) <> v_Success Then
      Raise v_Base_Exception;
    End If;

    Begin
      --'获取当单据据类型的下一单据状态';
      Pkg_Pln_Pub.p_Get_Order_Next_Status(p_Order_Type_Id    => v_Order_Type_Id,
                                          p_Curr_State       => v_Order_State,
                                          p_Curr_Action      => p_Operation_Action,
                                          p_Can_Option_Flag  => v_False,
                                          p_Next_Excute_Step => v_Next_Excute_Step,
                                          p_Nextauto_Excute  => v_Nextauto_Excute,
                                          p_Next_State       => v_Next_State,
                                          p_Next_Action      => v_Next_Action,
                                          p_Result           => p_Result);
      If p_Result <> v_Success Then
        p_Result := '获取订单下一状态失败！当前订单状态：' || v_Order_State || v_Nl ||
                    p_Result;
        Raise v_Base_Exception;
      End If;
    Exception
      When Others Then
        p_Result := p_Result;
        Raise v_Base_Exception;
    End;

    --将订单状态改为“评审完毕”
    Update t_Pln_Order_Collect_Head Ch
       Set Form_State       = v_Next_State,
           Last_Updated_By  = p_User_Code,
           Last_Update_Date = Sysdate
     Where Ch.Coll_Ord_Head_Id = p_Collect_Head_Id;

    p_Result := v_Success;
  Exception
    When v_Base_Exception Then
      p_Result := '失败原因：' || p_Result;
      Rollback;
    When Others Then
      p_Result := '未知错误：' || v_Result || v_Nl || Sqlerrm;
      Rollback;
  End;

  -----------------------------------------------------------------------------
  ---- AUTHOR  : 李振
  -- CREATED : 201409-06
  -- PURPOSE : 汇总订单中心确认
  -----------------------------------------------------------------------------
  Procedure p_Center_Confirm_Order(p_Collect_Head_Id  In Number, ----订单ID
                                   p_Operation_Action In Varchar2, --当前单据动作
                                   p_User_Code        In Varchar2, ----用户ID
                                   p_Result           Out Varchar2 --返回结果：成功返回"SUCCESS"，失败返回原因
                                   ) Is

    v_Tmp_Flag         Varchar2(1); --临时标识，01位长
    v_Entity_Id        Number;
    v_Order_Type_Id    Number;
    v_Order_Type_Name  Varchar2(50); --订单类型
    v_Customer_Id      Number;
    v_Period_Id        Number;
    v_Order_State      Varchar2(100);
    v_Next_Excute_Step Number;
    v_Next_Action      Varchar2(100);
    v_Nextauto_Excute  Varchar2(100);
    v_Next_State       Varchar2(100);
    v_Period_Type      Varchar2(100);

    v_Value        Varchar2(2000);
    r_Collect_Head t_Pln_Order_Collect_Head%Rowtype;
  Begin
    p_Result := v_Success;
    If p_Collect_Head_Id Is Null Or p_User_Code Is Null Then
      p_Result := '部分参数为空或错误';
      Raise v_Base_Exception;
    End If;

    Begin
      Select *
        Into r_Collect_Head
        From t_Pln_Order_Collect_Head h
       Where Coll_Ord_Head_Id = p_Collect_Head_Id
         --And Form_State In ('29') --汇总订单状态“已APS交互”
         For Update Nowait;

      v_Entity_Id     := r_Collect_Head.Entity_Id;
      v_Period_Id     := r_Collect_Head.Period_Id;
      v_Order_Type_Id := r_Collect_Head.Order_Type_Id;
      v_Order_State   := r_Collect_Head.Form_State;
    Exception
      When Others Then
        p_Result := '锁定汇总订单失败，请检查订单状态;当前单据可能已被退回。' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;

    Begin
      Select p.Period_Type
        Into v_Period_Type
        From t_Pln_Order_Period p
       Where p.Entity_Id = v_Entity_Id
         And p.Period_Id = v_Period_Id;
    Exception
      When Others Then
        p_Result := '获取周期类型失败,周期ID：' || v_Period_Id || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;
    --检查周期是否打开、关闭
    Pkg_Pln_Pub.p_Check_Period(v_Period_Id,
                               v_Period_Type,
                               v_True,
                               v_False,
                               'O',
                               p_Result);
    If Nvl(p_Result, v_Null) <> v_Success Then
      Raise v_Base_Exception;
    End If;

    Begin
      --'获取当单据据类型的下一单据状态';
      Pkg_Pln_Pub.p_Get_Order_Next_Status(p_Order_Type_Id    => v_Order_Type_Id,
                                          p_Curr_State       => v_Order_State,
                                          p_Curr_Action      => p_Operation_Action,
                                          p_Can_Option_Flag  => v_False,
                                          p_Next_Excute_Step => v_Next_Excute_Step,
                                          p_Nextauto_Excute  => v_Nextauto_Excute,
                                          p_Next_State       => v_Next_State,
                                          p_Next_Action      => v_Next_Action,
                                          p_Result           => p_Result);
      If p_Result <> v_Success Then
        p_Result := '获取订单下一状态失败！当前订单状态：' || v_Order_State || v_Nl ||
                    p_Result;
        Raise v_Base_Exception;
      End If;
    Exception
      When Others Then
        p_Result := p_Result;
        Raise v_Base_Exception;
    End;

    --将订单状态改为“评审完毕”
    Update t_Pln_Order_Collect_Head Ch
       Set Form_State       = v_Next_State,
           Last_Updated_By  = p_User_Code,
           Last_Update_Date = Sysdate
     Where Ch.Coll_Ord_Head_Id = p_Collect_Head_Id;

    p_Result := v_Success;
  Exception
    When v_Base_Exception Then
      p_Result := '失败原因：' || p_Result;
      Rollback;
    When Others Then
      p_Result := '未知错误：' || v_Result || v_Nl || Sqlerrm;
      Rollback;
  End;

  -----------------------------------------------------------------------------
  ---- AUTHOR  : 李振
  -- CREATED : 201409-06
  -- PURPOSE : 汇总订单 APS订单承诺
  -----------------------------------------------------------------------------
  Procedure p_Aps_Order_Promise(p_Collect_Head_Id  In Number, ----订单ID
                                p_Operation_Action In Varchar2, --当前单据动作
                                p_User_Code        In Varchar2, ----用户ID
                                p_Result           Out Varchar2 --返回结果：成功返回"SUCCESS"，失败返回原因
                                ) Is
    v_Tmp_Flag         Varchar2(1); --临时标识，01位长
    v_Entity_Id        Number;
    v_Order_Type_Id    Number;
    v_Order_Type_Name  Varchar2(50); --订单类型
    v_Customer_Id      Number;
    v_Period_Id        Number;
    v_Order_State      Varchar2(100);
    v_Next_Excute_Step Number;
    v_Next_Action      Varchar2(100);
    v_Nextauto_Excute  Varchar2(100);
    v_Next_State       Varchar2(100);
    v_Period_Type      Varchar2(100);


    v_Value        Varchar2(2000);
    r_Collect_Head t_Pln_Order_Collect_Head%Rowtype;
  Begin
    p_Result := v_Success;
    If p_Collect_Head_Id Is Null Or p_User_Code Is Null Then
      p_Result := '部分参数为空或错误';
      Raise v_Base_Exception;
    End If;

    Begin
      Select *
        Into r_Collect_Head
        From t_Pln_Order_Collect_Head h
       Where Coll_Ord_Head_Id = p_Collect_Head_Id
         --And Form_State In ('22') --汇总订单状态“已工厂评审”
         For Update Nowait;

      v_Entity_Id     := r_Collect_Head.Entity_Id;
      v_Period_Id     := r_Collect_Head.Period_Id;
      v_Order_Type_Id := r_Collect_Head.Order_Type_Id;
      v_Order_State   := r_Collect_Head.Form_State;
    Exception
      When Others Then
        p_Result := '锁定汇总订单失败，请检查订单状态;当前单据可能已被退回。' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;

    Begin
      Select p.Period_Type
        Into v_Period_Type
        From t_Pln_Order_Period p
       Where p.Entity_Id = v_Entity_Id
         And p.Period_Id = v_Period_Id;
    Exception
      When Others Then
        p_Result := '获取周期类型失败,周期ID：' || v_Period_Id || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;
    --检查周期是否打开、关闭
    Pkg_Pln_Pub.p_Check_Period(v_Period_Id,
                               v_Period_Type,
                               v_True,
                               v_False,
                               'O',
                               p_Result);
    If Nvl(p_Result, v_Null) <> v_Success Then
      Raise v_Base_Exception;
    End If;
    
    --hejy3 更新承诺日期
    pkg_pln_order_collect.p_Upd_Pln_Lg_Promise_Date(p_Order_Collect_Id => r_Collect_Head.Coll_Ord_Head_Id,
                                                    p_Entity_Id        => r_Collect_Head.Entity_Id,
                                                    p_User_Code        => p_User_Code,
                                                    p_Result           => p_Result);
    If Nvl(p_Result, v_Null) <> v_Success Then
      Raise v_Base_Exception;
    End If;

    Begin
      --'获取当单据据类型的下一单据状态';
      Pkg_Pln_Pub.p_Get_Order_Next_Status(p_Order_Type_Id    => v_Order_Type_Id,
                                          p_Curr_State       => v_Order_State,
                                          p_Curr_Action      => p_Operation_Action,
                                          p_Can_Option_Flag  => v_False,
                                          p_Next_Excute_Step => v_Next_Excute_Step,
                                          p_Nextauto_Excute  => v_Nextauto_Excute,
                                          p_Next_State       => v_Next_State,
                                          p_Next_Action      => v_Next_Action,
                                          p_Result           => p_Result);
      If p_Result <> v_Success Then
        p_Result := '获取订单下一状态失败！当前订单状态：' || v_Order_State || v_Nl ||
                    p_Result;
        Raise v_Base_Exception;
      End If;
    Exception
      When Others Then
        p_Result := p_Result;
        Raise v_Base_Exception;
    End;

    --将订单状态改为“评审完毕”
    Update t_Pln_Order_Collect_Head Ch
       Set Form_State       = v_Next_State,
           Last_Updated_By  = p_User_Code,
           Last_Update_Date = Sysdate
     Where Ch.Coll_Ord_Head_Id = p_Collect_Head_Id
       --And Ch.Form_State In ('22')
       ; --汇总订单状态“已工厂评审”;

    p_Result := v_Success;
  Exception
    When v_Base_Exception Then
      p_Result := '失败原因：' || p_Result;
      Rollback;
    When Others Then
      p_Result := '未知错误：' || v_Result || v_Nl || Sqlerrm;
      Rollback;
  End;
  -----------------------------------------------------------------------------
  ---- AUTHOR  : 李振
  -- CREATED : 201409-06
  -- PURPOSE : 汇总订单  引APS接口
  -----------------------------------------------------------------------------
  Procedure p_Into_Aps_Intf(p_Collect_Head_Id  In Number, ----订单ID
                            p_Operation_Action In Varchar2, --当前单据动作
                            p_User_Code        In Varchar2, ----用户ID
                            p_Result           Out Varchar2 --返回结果：成功返回"SUCCESS"，失败返回原因
                            ) Is

    v_Tmp_Flag          Varchar2(1); --临时标识，01位长
    v_Entity_Id         Number;
    v_Order_Type_Id     Number;
    v_Order_Type_Name   Varchar2(50); --订单类型
    v_Customer_Id       Number;
    v_Period_Id         Number;
    v_Order_State       Varchar2(100);
    v_Next_Excute_Step  Number;
    v_Next_Action       Varchar2(100);
    v_Nextauto_Excute   Varchar2(100);
    v_Next_State        Varchar2(100);
    v_Period_Type       Varchar2(100);
    v_Pln_Wip_Ord_Match Varchar2(10);
    v_Value             Varchar2(2000);
    r_Collect_Head      t_Pln_Order_Collect_Head%Rowtype;
  Begin
    p_Result := v_Success;
    If p_Collect_Head_Id Is Null Or p_User_Code Is Null Then
      p_Result := '部分参数为空或错误';
      Raise v_Base_Exception;
    End If;

    Begin
      Select *
        Into r_Collect_Head
        From t_Pln_Order_Collect_Head h
       Where Coll_Ord_Head_Id = p_Collect_Head_Id
         And Form_State In ('31') --汇总订单状态“已汇总完成”
         For Update Nowait;

      v_Entity_Id     := r_Collect_Head.Entity_Id;
      v_Period_Id     := r_Collect_Head.Period_Id;
      v_Order_Type_Id := r_Collect_Head.Order_Type_Id;
      v_Order_State   := r_Collect_Head.Form_State;
    Exception
      When Others Then
        p_Result := '锁定汇总订单失败，请检查订单状态;当前单据可能已被退回。' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;

    --获取工单与订单是否完全匹配参数
    Begin
      v_Pln_Wip_Ord_Match := Pkg_Bd.f_Get_Parameter_Value('PLN_WIP_ORD_MATCH',
                                                          v_Entity_Id);
    Exception
      When Others Then
        p_Result := '获取参数PLN_WIP_ORD_MATCH失败！' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;

    Begin
      Select p.Period_Type
        Into v_Period_Type
        From t_Pln_Order_Period p
       Where p.Entity_Id = v_Entity_Id
         And p.Period_Id = v_Period_Id;
    Exception
      When Others Then
        p_Result := '获取周期类型失败,周期ID：' || v_Period_Id || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;
    --检查周期是否打开、关闭
    Pkg_Pln_Pub.p_Check_Period(v_Period_Id,
                               v_Period_Type,
                               v_True,
                               v_False,
                               'O',
                               p_Result);
    If Nvl(p_Result, v_Null) <> v_Success Then
      Raise v_Base_Exception;
    End If;

    Begin
      --'获取当单据据类型的下一单据状态';
      Pkg_Pln_Pub.p_Get_Order_Next_Status(p_Order_Type_Id    => v_Order_Type_Id,
                                          p_Curr_State       => v_Order_State,
                                          p_Curr_Action      => p_Operation_Action,
                                          p_Can_Option_Flag  => v_False,
                                          p_Next_Excute_Step => v_Next_Excute_Step,
                                          p_Nextauto_Excute  => v_Nextauto_Excute,
                                          p_Next_State       => v_Next_State,
                                          p_Next_Action      => v_Next_Action,
                                          p_Result           => p_Result);
      If p_Result <> v_Success Then
        p_Result := '获取订单下一状态失败！当前订单状态：' || v_Order_State || v_Nl ||
                    p_Result;
        Raise v_Base_Exception;
      End If;
    Exception
      When Others Then
        p_Result := p_Result;
        Raise v_Base_Exception;
    End;

    --更新计划订单状态为“已排产”
    Update t_Pln_Order_Line Ol
       Set Ol.Status           = v_Next_State, --更新计划订单状态为“已排产”
           Ol.Last_Updated_By  = p_User_Code,
           Ol.Last_Update_Date = Sysdate
     Where Ol.Order_Line_Id In
           (Select l.Order_Line_Id
              From t_Pln_Order_Line             l,
                   t_Pln_Order_Head             h,
                   t_Pln_Order_Collect_Relation Ocr,
                   t_Pln_Order_Collect_Head     Och,
                   t_Pln_Order_Collect_Line     Ocl
             Where Och.Coll_Ord_Head_Id = p_Collect_Head_Id
               And Ocl.Coll_Ord_Head_Id = Och.Coll_Ord_Head_Id
               And Ocl.Coll_Ord_Line_Id = Ocr.Coll_Ord_Line_Id
               And h.Order_Head_Id = l.Order_Head_Id
               And h.Form_State = '23' --计划订单必须是“评审完毕”
               And Ocr.Order_Line_Id = l.Order_Line_Id);
    If Sql%Notfound Then
      p_Result := '更新计划订单行失败，无可更新的订单数据';
      Raise v_Base_Exception;
    End If;

    --更新计划订单状态为“已排产”
    Update t_Pln_Order_Head Oh
       Set Oh.Form_State       = v_Next_State, --更新计划订单状态为“已排产”
           Oh.Last_Updated_By  = p_User_Code,
           Oh.Last_Update_Date = Sysdate
     Where Oh.Order_Head_Id In
           (Select l.Order_Head_Id
              From t_Pln_Order_Line             l,
                   t_Pln_Order_Collect_Relation Ocr,
                   t_Pln_Order_Collect_Head     Och,
                   t_Pln_Order_Collect_Line     Ocl
             Where Och.Coll_Ord_Head_Id = p_Collect_Head_Id
               And Ocl.Coll_Ord_Head_Id = Och.Coll_Ord_Head_Id
               And Ocl.Coll_Ord_Line_Id = Ocr.Coll_Ord_Line_Id
               And Ocr.Order_Line_Id = l.Order_Line_Id)
       And Oh.Form_State = '23' --计划订单必须是“评审完毕”
    ;
    If Sql%Notfound Then
      p_Result := '更新计划订单头失败，无可更新的订单数据';
      Raise v_Base_Exception;
    End If;
    p_Result := v_Success;
  Exception
    When v_Base_Exception Then
      p_Result := '失败原因：' || p_Result;
      Rollback;
    When Others Then
      p_Result := '未知错误：' || v_Result || v_Nl || Sqlerrm;
      Rollback;
  End;

  -----------------------------------------------------------------------------
  ---- AUTHOR  : 李振
  -- CREATED : 2014-07-16 11:05:52
  -- PURPOSE : 执行订单操作
  -----------------------------------------------------------------------------
  Procedure p_Execute_Order_Operate(p_Collect_Head_Id  In Number, ----订单ID
                                    p_Operation_Action In Varchar2, --当前单据动作
                                    p_Next_State       In Varchar2, --下一状态值
                                    p_User_Code        In Varchar2, ----用户ID
                                    p_Result           In Out Varchar2 --返回结果：成功返回"SUCCESS"，失败返回原因
                                    ) Is
    v_Order_Status  Varchar2(100);
    v_Is_Inv_Review Varchar2(3);
    v_Count         Number;
    v_Flow_Id       Number;
    v_Operation_Action Varchar2(100);
  Begin
    If p_Operation_Action = v_Action_Collect_Affirm Then
      --汇总确认
      p_Collect_Confirm_Order(p_Collect_Head_Id  => p_Collect_Head_Id, ----订单ID
                              p_Operation_Action => p_Operation_Action, --当前单据动作
                              p_User_Code        => p_User_Code, ----用户ID
                              p_Result           => p_Result);
    Elsif p_Operation_Action = v_Action_Inv_Review Then
      --库存评审
      p_Inv_Review_Order(p_Collect_Head_Id  => p_Collect_Head_Id, ----订单ID
                         p_Operation_Action => p_Operation_Action, --当前单据动作
                         p_User_Code        => p_User_Code, ----用户ID
                         p_Result           => p_Result);
    Elsif p_Operation_Action = v_Action_Hq_Review Then
      --总部评审
      p_Hq_Review_Order(p_Collect_Head_Id  => p_Collect_Head_Id, ----订单ID
                        p_Operation_Action => p_Operation_Action, --当前单据动作
                        p_User_Code        => p_User_Code, ----用户ID
                        p_Result           => p_Result --返回结果：成功返回"SUCCESS"，失败返回原因
                        );

    Elsif p_Operation_Action In (v_Action_Resolve_Affirm, v_Action_Resolve_First,
         v_Action_Resolve_Second, v_Action_Resolve_Third)  Then
      --分解确认、初次分解、二次分解、三次分解   更新状态过和
      p_Resolve_Confirm_Order(p_Collect_Head_Id  => p_Collect_Head_Id, ----订单ID
                              p_Operation_Action => p_Operation_Action, --当前单据动作
                              p_User_Code        => p_User_Code, ----用户ID
                              p_Result           => p_Result);

    Elsif p_Operation_Action = v_Action_Factory_Review Then
      --工厂评审
      p_Factory_Review_Order(p_Collect_Head_Id  => p_Collect_Head_Id, ----订单ID
                             p_Operation_Action => p_Operation_Action, --当前单据动作
                             p_User_Code        => p_User_Code, ----用户ID
                             p_Result           => p_Result);
    Elsif p_Operation_Action = v_Action_Aps_Interactive Then
      --APS交互
      p_Aps_Interactive_Order(p_Collect_Head_Id  => p_Collect_Head_Id, ----订单ID
                              p_Operation_Action => p_Operation_Action, --当前单据动作
                              p_User_Code        => p_User_Code, ----用户ID
                              p_Result           => p_Result --返回结果：成功返回"SUCCESS"，失败返回原因
                              );
    Elsif p_Operation_Action = v_Action_Aps_Walkthrough Then
      --add by lizhen 2016-01-29
      --APS预排产
      p_Aps_Walkthrough_Order(p_Collect_Head_Id  => p_Collect_Head_Id, ----订单ID
                              p_Operation_Action => p_Operation_Action, --当前单据动作
                              p_User_Code        => p_User_Code, ----用户ID
                              p_Result           => p_Result --返回结果：成功返回"SUCCESS"，失败返回原因
                              );
    Elsif p_Operation_Action = v_Action_Aps_Promise Then
      --APS订单承诺
      p_Aps_Order_Promise(p_Collect_Head_Id  => p_Collect_Head_Id, ----订单ID
                          p_Operation_Action => p_Operation_Action, --当前单据动作
                          p_User_Code        => p_User_Code, ----用户ID
                          p_Result           => p_Result --返回结果：成功返回"SUCCESS"，失败返回原因
                          );
    Elsif p_Operation_Action = v_Action_Center_Confirm Then
      --中心确认
      p_Center_Confirm_Order(p_Collect_Head_Id  => p_Collect_Head_Id, ----订单ID
                             p_Operation_Action => p_Operation_Action, --当前单据动作
                             p_User_Code        => p_User_Code, ----用户ID
                             p_Result           => p_Result --返回结果：成功返回"SUCCESS"，失败返回原因
                             );
    Elsif p_Operation_Action = v_Action_Hq_Confirm Then
      --总部确认
      p_Hq_Confirm_Order(p_Collect_Head_Id  => p_Collect_Head_Id, ----订单ID
                         p_Operation_Action => p_Operation_Action, --当前单据动作
                         p_User_Code        => p_User_Code, ----用户ID
                         p_Result           => p_Result --返回结果：成功返回"SUCCESS"，失败返回原因
                         );
    Elsif p_Operation_Action = v_Action_Into_Aps_Intf Then
      --引APS接口
      p_Into_Aps_Intf(p_Collect_Head_Id  => p_Collect_Head_Id, ----订单ID
                      p_Operation_Action => p_Operation_Action, --当前单据动作
                      p_User_Code        => p_User_Code, ----用户ID
                      p_Result           => p_Result --返回结果：成功返回"SUCCESS"，失败返回原因
                      );
    End If;
    If p_Result <> v_Success Then
      Raise v_Base_Exception;
    Elsif p_Operation_Action Not In (v_Action_Into_Aps_Intf) Then
      Begin
        Select Ch.Form_State
          Into v_Order_Status
          From t_Pln_Order_Collect_Head Ch
         Where Ch.Coll_Ord_Head_Id = p_Collect_Head_Id;
      Exception
        When Others Then
          p_Result := '获取汇总订单头状态失败，订单汇总头ID:' || p_Collect_Head_Id;
          Raise v_Base_Exception;
      End;
      p_Check_Next_State_Complete(p_Collect_Head_Id  => p_Collect_Head_Id, ----订单ID
                                  p_Operation_Action => p_Operation_Action, --当前单据动作
                                  p_Next_State       => v_Order_Status, --下一状态
                                  p_User_Code        => p_User_Code, ----用户ID
                                  p_Result           => p_Result --返回结果：成功返回"SUCCESS"，失败返回原因
                                  );
      If p_Result <> v_Success Then
        Raise v_Base_Exception;
      End If;
    End If;
    --检查单据类型是否不需库存评审，是则系统自动更新状态
    If p_Result = v_Success Then
      Begin
        Select Ot.Is_Inv_Affirm_Flag, ot.flow_id
          Into v_Is_Inv_Review, v_Flow_Id
          From t_Pln_Order_Collect_Head Oc, t_Pln_Order_Type Ot
         Where Oc.Order_Type_Id = Ot.Order_Type_Id
           And Oc.Entity_Id = Ot.Entity_Id
           And Oc.Coll_Ord_Head_Id = p_Collect_Head_Id;
      Exception
        When Others Then
          p_Result := '获取汇总单据类型是否库存评审失败，汇总单据头ID：' || To_Char(p_Collect_Head_Id);
          Raise v_Base_Exception;
      End;
      --检查下一状态是否为库存评审
      Begin
        Select Fs.Action_Code
          Into v_Operation_Action
          From t_Pln_Flow_Status Fs
         Where Fs.Curr_Status_Id = p_Next_State
           And Fs.Next_Status_Id = 26
           And Fs.Action_Id Not In (8, 9, 365, 501) --'退回','关闭',驳回、撤回
           And Fs.Flow_Id = v_Flow_Id;
      Exception
        When Others Then
          v_Operation_Action := Null;
      End;
      --库存评审
      If nvl(v_Is_Inv_Review, v_False) = v_False And v_Operation_Action Is Not Null Then
        p_Inv_Review_Order(p_Collect_Head_Id  => p_Collect_Head_Id, ----订单ID
                           p_Operation_Action => v_Operation_Action, --当前单据动作
                           p_User_Code        => p_User_Code, ----用户ID
                           p_Result           => p_Result);
        If p_Result != v_Success Then
          Raise v_Base_Exception;
        End If;
      End If;
    End If;
    p_Result := v_Success;
  Exception
    When v_Base_Exception Then
      Rollback;
      p_Result := p_Result;
    When Others Then
      Rollback;
      p_Result := '汇总订单处理失败。' || v_Nl || Sqlerrm;
  End;
  -----------------模具产能占用
  Procedure p_Occupy_Mode_Productivity(p_Order_Type_Id In Number, --订单类型Id
                                       p_Period_Id     In Number, -- 周期Id
                                       p_user_code     varchar2,
                                       p_Entity_Id     In Number --主体Id
                                       ) Is
    Cursor c_Item_Producing Is
     select ip.plastic_id,
       line.producing_area_id,
       sum(nvl(line.check_qty, 0)) check_qty
  from t_pln_order_line line,
       t_pln_item_plastic ip
 where line.order_head_id in
       (select h.order_head_id
          from t_pln_order_head h
         where h.order_type_id =p_Order_Type_Id
           and h.period_id = p_Period_Id
           and h.form_state = 23
           and h.entity_id=p_Entity_Id)
   and ip.item_id = line.item_id
   and ip.entity_id=p_Entity_Id
   group by plastic_id, producing_area_id;
    r_Item_Producing c_Item_Producing%Rowtype;
  Begin
    Open c_Item_Producing;
    Loop
      Fetch c_Item_Producing Into r_Item_Producing;
      Exit When c_Item_Producing%Notfound;
      update t_pln_mould_productivity_area  pa
      set pa.surplus_productivity=nvl(pa.surplus_productivity,0)+r_Item_Producing.Check_Qty,
      pa.last_updated_by=p_user_code ,pa.last_update_date=sysdate
       where pa.producing_area_id=r_Item_Producing.Producing_Area_Id
             and pa.plastic_id=r_Item_Producing.Plastic_Id
             and pa.entity_id=p_Entity_Id
             and pa.period_id=p_Period_Id
             and pa.entity_id=p_Entity_Id;
    End Loop;
    Close c_Item_Producing;
  End;
  -----------总装产能占用-----------------
  Procedure p_Occupy_Total_Productivity(p_Order_Type_Id In Number, --订单类型Id
                                        p_Period_Id     In Number, -- 周期Id
                                        p_user_code     varchar2 ,--操作用户code
                                        p_Entity_Id     In Number --主体Id
                                        ) Is
    V_TOTAL_CHECK_QTY         Number;
    Cursor c_Totalmode Is
 select line.producing_area_id, sum(nvl(line.check_qty, 0)) check_qty
   from t_pln_order_line line
  where line.order_head_id in
        (select h.order_head_id
           from t_pln_order_head h
          where h.order_type_id = p_Order_Type_Id
            and h.period_id = p_Period_Id
            and h.form_state = 23
            and h.entity_id = p_Entity_Id)
    and line.producing_area_id in
        (select ta.producing_area_id
           from t_pln_total_productivity_area ta
          where ta.period_id = p_Period_Id
            and ta.entity_id = p_Entity_Id)
  group by line.producing_area_id;
    r_Totalmode c_Totalmode%Rowtype;
  Begin
    Open c_Totalmode;
    Loop
      Fetch c_Totalmode
        Into r_Totalmode;
      Exit When c_Totalmode%Notfound;

          SELECT ROUND(r_Totalmode.CHECK_QTY/
              (SELECT COUNT(*)
                 FROM T_PLN_TOTAL_PRODUCTIVITY_AREA
                WHERE PRODUCING_AREA_ID = r_Totalmode.PRODUCING_AREA_ID
                  AND PERIOD_ID = p_Period_Id
                  AND ENTITY_ID = p_Entity_Id), 0)
              INTO V_TOTAL_CHECK_QTY
              FROM DUAL;
            UPDATE T_PLN_TOTAL_PRODUCTIVITY_AREA
               SET SURPLUS_PRODUCTIVITY = NVL(SURPLUS_PRODUCTIVITY, 0) + V_TOTAL_CHECK_QTY,
                   LAST_UPDATED_BY = p_user_code,
                   LAST_UPDATE_DATE = SYSDATE
             WHERE PRODUCING_AREA_ID = r_Totalmode.PRODUCING_AREA_ID
               AND PERIOD_ID = P_PERIOD_ID
               AND ENTITY_ID = P_ENTITY_ID;
    End Loop;
    Close c_Totalmode;
  End;
  ----订单汇总退回---------------
  Procedure p_return_order_collect(     p_Order_Type_Id In Number, --订单类型Id
                                        p_Period_Id     In Number, -- 周期Id
                                        p_batch_id      In number,--批次
                                        p_main_type     varchar2,-- 营销大类
                                        p_sub_type      varchar2,--营销小类
                                        p_main_type_sys varchar2,--营销大类参数
                                        p_sub_type_sys  varchar2,--营销小类参数
                                        p_user_code     varchar2,   --操作用户
                                        p_Entity_Id     In Number --主体Id
                                        ) is
    v_main_param varchar2(2);
    v_sub_param  varchar2(2);
    v_next_status_id varchar2(10);
    Cursor c_order_head is
    select th.order_head_id  from t_Pln_order_head th
    where
    th.order_type_id=p_order_type_id
    and th.period_id=p_Period_Id
    and th.entity_id=p_Entity_Id
    and th.batch_id=p_batch_id
    and ('N'=p_main_type_sys or ('Y'=p_main_type_sys and th.sales_main_type=p_main_type))
    and ('N'=p_sub_type_sys or ('Y'=p_sub_type_sys and th.sales_sub_type=p_sub_type))
    and th.form_state=25;
    r_order_head c_order_head%Rowtype;

    begin
      begin
      select ts.next_status_id into v_next_status_id
    from t_pln_order_type ty, t_pln_flow_status ts
    where ty.flow_id = ts.flow_id
   and ts.action_code = '退回'
   and ts.curr_status = '初始'
   and ty.order_type_id=p_Order_Type_Id
   and ty.entity_id=p_Entity_Id;
    end;
      open c_order_head ;
      Loop
        fetch c_order_head into
        r_order_head ;
       exit when c_order_head%notFound;
       update
       t_pln_order_head h set h.form_state=v_next_status_id,
                              h.hq_check_user=p_user_code,
                              h.hq_check_date=sysdate,
                              h.last_updated_by=p_user_code,
                              h.last_update_date=sysdate
                              where h.order_head_id=r_order_head.order_head_id;
       update
       t_pln_order_line line set line.check_qty=line.apply_qty,
                                 line.can_produce_qty=line.apply_qty,
                                 line.adjust_qty=0,
                                 line.last_updated_by=p_user_code,
                                 line.last_update_date=sysdate
                               where line.order_head_id=r_order_head.order_head_id;
        end loop;
      close c_order_head;
    end ;

  ----------------------------------------------------------------------------------------
  --AUTHOR :张楚材
  --create :2015-01-07
  -- 订单汇总
  ----------------------------------------------------------------------------------------
  Procedure p_Order_Colldet(p_Order_Type_Id   In Number, --订单类型Id
                            p_Period_Id       In Number, --周期Id
                            p_Batch_Id        In Number, --批次
                            p_Sales_Main_Type In Varchar2, -- 营销大类
                            p_Sales_Sub_Type  In Varchar2, --营销小类
                            p_User_Code       In Varchar2, --操作用户
                            p_Entity_Id       In Number, --主体Id
                            p_Form_State      In Varchar2, -- 汇总订单状态
                            p_Result          Out Varchar2 -- 返回结果
                            ) Is
    v_Is_Inv_Check    Varchar2(10);
    v_Collect_Head_Id Number;
    v_Collect_Line_Id Number;
    v_Base_Inv_Qty    Number; --基地仓库存
    v_Total_Inv_Qty   Number; --全国库存
    v_Center_Inv_Qty  Number; -- 中心仓库存
    v_main_param      varchar2(10); --营销小类
    v_sub_param       varchar2(20); --营销小类
    v_Qty1            Number;
    v_Qty2            Number;
    v_Qty3            Number;
    v_Qty4            Number;
    v_Qty5            Number;
    v_Qty6            Number;
    v_Qty7            Number;
    v_qty8            number;
    v_qty9            number;
    v_qty10           number;
    v_Qty11           Number;
    v_Qty12           Number;
    v_Qty13           Number;
    v_Qty14           Number;
    v_Qty15           Number;
    v_Qty16           Number;
    v_Qty17           Number;
    v_qty18           number;
    v_qty19           number;
    v_qty20           number;
    v_qty21           number;
    v_Qty22           number;
    v_Qty23           number;
    v_qty24           number;
    v_qty25           number;
    v_qty26           number;
    v_qty27           number;
    v_qty28           number;
    v_qty29           number;
    v_qty30           number;
    v_qty31           number;
    v_qty32           number;
    v_qty33           number;
    v_qty34           number;
    v_qty35           number;
    v_qty36           number;
    v_qty37           number;
    v_qty38           number;
    v_qty39           number;
    v_qty40           number;
    v_Count           Number;
    v_pro_sort        number;
    v_Next_Excute_Step Varchar2(100);
    v_Nextauto_Excute  Varchar2(100);
    v_Next_State       Varchar2(100);
    v_Next_Action      Varchar2(100);
    v_Current_Status   Varchar2(100);
    v_is_week          varchar2(2);
    v_static           number;
    v_is_send          varchar2(2);

  Begin
    p_Result := v_Success;
    begin
      v_main_param := pkg_bd.F_GET_PARAMETER_VALUE('ITEM_SALES_MAIN_TYPE_FILTER',
                                                   p_Entity_Id);
    exception
      when others then
        p_Result := '获取营销大类参数失败' || v_nl || sqlerrm;
        raise v_Base_Exception;
    end;
     begin
      v_is_send := pkg_bd.F_GET_PARAMETER_VALUE('PLN_SEND_SYS',
                                                   p_Entity_Id);
    exception
      when others then
        p_Result := '获取周排产汇总控制参数PLN_SEND_SYS失败' || v_nl || sqlerrm;
        raise v_Base_Exception;
    end;
    begin
      v_sub_param := pkg_bd.F_GET_PARAMETER_VALUE('ITEM_SALES_SUB_TYPE_FILTER',
                                                  p_Entity_Id);
    exception
      when others then
        p_Result := '获取营销小类参数失败' || v_nl || sqlerrm;
        raise v_Base_Exception;
    end;
    -- 检查计划订单头 不用锁定计划订单头 汇总订单头(周期,订单类型,批次。做了唯一索引)
    begin
      select count(0), Min(h.form_state)
        into v_count, v_Current_Status
        From t_Pln_Order_Head h, t_pln_order_type ty, t_pln_flow_status ts
       Where h.Order_Type_Id = ty.order_type_id
         and ty.flow_id = ts.flow_id
         and h.order_type_id = p_Order_Type_Id
         And h.Batch_Id = p_Batch_Id
         And h.Period_Id = p_Period_Id
         And h.Entity_Id = p_Entity_Id
         and ts.action_code = '初始'
         and h.form_state = ts.curr_status_id
         and ('N' = v_main_param or ('Y' = v_main_param And h.sales_main_type = p_Sales_Main_Type)) --增加营销大类
         and ('N' = v_sub_param or ('Y' = v_sub_param And h.sales_sub_type = p_Sales_Sub_Type)); --增加小类
      If v_Count = 0 Then
        p_Result := '获取计划订单信息失败,计划订单头状态:'|| v_Current_Status;
        Raise v_Base_Exception;
      End If;
    End;

    --'获取当单据据类型的下一单据状态';
    Pkg_Pln_Pub.p_Get_Order_Next_Status(p_Order_Type_Id    => p_Order_Type_Id,
                                        p_Curr_State       => v_Current_Status,
                                        p_Curr_Action      => '初始',
                                        p_Can_Option_Flag  => 'N',
                                        p_Next_Excute_Step => v_Next_Excute_Step,
                                        p_Nextauto_Excute  => v_Nextauto_Excute,
                                        p_Next_State       => v_Next_State,
                                        p_Next_Action      => v_Next_Action,
                                        p_Result           => p_Result);
    If p_Result <> v_Success Then
      p_Result := '获取订单下一状态失败！当前订单状态：' || v_Next_State || v_Nl ||
                p_Result;
      Raise v_Base_Exception;
    End If;

    Begin
      v_Collect_Head_Id := s_Pln_Order_Collect_Line.Nextval;
      -- 是否是要查询库存
      Select Ty.Is_Inv_Affirm_Flag
        Into v_Is_Inv_Check
        From t_Pln_Order_Type Ty
       Where Ty.Order_Type_Id = p_Order_Type_Id
         And Ty.Entity_Id = p_Entity_Id;
      Insert Into t_Pln_Order_Collect_Head -- 生成汇总订单头
        (Entity_Id,
         Coll_Ord_Head_Id,
         Coll_Ord_Number,
         Order_Date,
         Order_Head_State,
         Form_State,
         Order_Type_Id,
         Period_Id,
         Pre_Field_02,
         Created_By,
         Last_Updated_By,
         Creation_Date,
         Last_Update_Date,
         sales_main_type,
         sales_sub_type)
      Values
        (p_Entity_Id,
         v_Collect_Head_Id,
         p_Batch_Id,
         Sysdate,
         v_Next_State,
         v_Next_State,
         p_Order_Type_Id,
         p_Period_Id,
         v_Next_State,
         p_User_Code,
         p_User_Code,
         Sysdate,
         Sysdate,
         p_Sales_Main_Type,
         p_Sales_Sub_Type);
    Exception
      When Others Then
        p_Result := '生成汇总订单头失败!' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;

    For r_Item_Collect In ( -- 按产品汇总
                           Select Bi.Item_Id,
                                   Bi.Item_Code,
                                   Bi.Item_Name Item_Desc,
                                   Bi.Defaultunit Item_Uom,
                                   Sum(Nvl(Apply_Qty, 0)) As Apply_Qty,
                                   sum(Nvl(check_qty,0))  as check_qty,
                                   Sum(Nvl(l.Inv_Affirm_Qty, 0)) As Inv_Affirm_Qty
                             From t_Pln_Order_Line l, t_Bd_Item Bi
                            Where l.Order_Head_Id In
                                  (select h.order_head_id
                                     From t_Pln_Order_Head  h,
                                          t_pln_order_type  ty,
                                          t_pln_flow_status ts
                                    Where h.Order_Type_Id = ty.order_type_id
                                      and ty.flow_id = ts.flow_id
                                      and h.order_type_id = p_Order_Type_Id
                                      And h.Batch_Id = p_Batch_Id
                                      And h.Period_Id = p_Period_Id
                                      And h.Entity_Id = p_Entity_Id
                                      and ts.action_code = '初始'
                                      and h.form_state = ts.curr_status_id
                                    and ('N' = v_main_param or ('Y' = v_main_param And h.sales_main_type = p_Sales_Main_Type)) --增加营销大类
                                    and ('N' =v_sub_param or ('Y' = v_sub_param And h.sales_sub_type = p_Sales_Sub_Type))
                                   )
                              And Bi.Item_Id = l.Item_Id
                            Group By Bi.Item_Id,
                                      Bi.Item_Code,
                                      Bi.Defaultunit,
                                      Bi.Item_Name) Loop
      Begin
        v_Collect_Line_Id := s_Pln_Collect_Order_Line.Nextval;
        Insert Into t_Pln_Order_Collect_Line
          ( -- 生成汇总订单行
           Entity_Id,
           Coll_Ord_Head_Id,
           Coll_Ord_Line_Id,
           Order_Line_State,
           Item_Id,
           Item_Code,
           Item_Name,
           Item_Uom,
           Total_Apply_Qty,
           Total_Inv_Affirm_Qty,
           Creation_Date,
           Last_Update_Date,
           Created_By,
           Last_Updated_By,
           is_inv_chk)
        Values
          (p_Entity_Id,
           v_Collect_Head_Id,
           v_Collect_Line_Id,
           p_Form_State,
           r_Item_Collect.Item_Id,
           r_Item_Collect.Item_Code,
           r_Item_Collect.Item_Desc,
           r_Item_Collect.Item_Uom,
           r_Item_Collect.Apply_Qty,
           r_Item_Collect.Inv_Affirm_Qty,
           Sysdate,
           Sysdate,
           p_User_Code,
           p_User_Code,
           'Y');
      Exception
        When Others Then
          p_Result := '生成汇总订单行失败' || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
      End;
      For r_Item_Detail_Collect In ( -- 按产品产地汇总
                                    Select l.Item_Id,
                                            l.Producing_Area_Id,
                                            Sum(Nvl(l.Apply_Qty, 0)) As Apply_Qty,
                                            Sum(Nvl(l.Check_Qty, 0)) As Check_Qty
                                      From t_Pln_Order_Line l
                                     Where l.Order_Head_Id In
                                           (select h.order_head_id
                                              From t_Pln_Order_Head  h,
                                                   t_pln_order_type  ty,
                                                   t_pln_flow_status ts
                                             Where h.Order_Type_Id =
                                                   ty.order_type_id
                                               and ty.flow_id = ts.flow_id
                                               and h.order_type_id =
                                                   p_Order_Type_Id
                                               And h.Batch_Id = p_Batch_Id
                                               And h.Period_Id = p_Period_Id
                                               And h.Entity_Id = p_Entity_Id
                                               and ts.action_code = '初始'
                                               and h.form_state =
                                                   ts.curr_status_id)
                                       And l.Item_Id = r_Item_Collect.Item_Id
                                     Group By Item_Id, l.Producing_Area_Id) Loop
        Begin
          --生成汇总明细表


          Insert Into t_Pln_Order_Collect_Detail
            (Entity_Id,
             Coll_Ord_Detail_Id,
             Coll_Ord_Head_Id,
             Coll_Ord_Line_Id,
             Producing_Area_Id,
             Item_Id,
             Quantity,
             Created_By,
             Creation_Date,
             Last_Updated_By,
             Last_Update_Date,
             Check_Qty)
          Values
            (p_Entity_Id,
             s_Pln_Order_Collect_Detail.Nextval,
             v_Collect_Head_Id,
             v_Collect_Line_Id,
             r_Item_Detail_Collect.Producing_Area_Id,
             r_Item_Detail_Collect.Item_Id,
             r_Item_Detail_Collect.Apply_Qty,
             p_User_Code,
             Sysdate,
             p_User_Code,
             Sysdate,
             r_Item_Detail_Collect.Check_Qty);
          --查询产地排序顺序
          select tp.pro_sort
            into v_pro_sort
            from t_pln_producing_area tp
           where tp.entity_id = p_Entity_Id
             and tp.producing_area_id =
                 r_Item_Detail_Collect.Producing_Area_Id;
           --最大支持20个产地 如果有更多需要更改表结构
          If v_pro_sort = 1 Then
            v_Qty1 := r_Item_Detail_Collect.apply_Qty;
            v_Qty11 := r_Item_Detail_Collect.check_qty;

          Elsif v_pro_sort = 2 Then
            v_Qty2 := r_Item_Detail_Collect.apply_Qty;
            v_Qty12 := r_Item_Detail_Collect.check_qty;

          Elsif v_pro_sort = 3 Then
            v_Qty3 := r_Item_Detail_Collect.apply_Qty;
            v_Qty13 := r_Item_Detail_Collect.check_qty;

          Elsif v_pro_sort = 4 Then
            v_Qty4 := r_Item_Detail_Collect.apply_Qty;
            v_Qty14 := r_Item_Detail_Collect.check_qty;

          Elsif v_pro_sort = 5 Then
            v_Qty5 := r_Item_Detail_Collect.apply_Qty;
            v_Qty15 := r_Item_Detail_Collect.check_qty;

          Elsif v_pro_sort = 6 Then
            v_Qty6 := r_Item_Detail_Collect.apply_Qty;
            v_Qty16 := r_Item_Detail_Collect.check_qty;
          Elsif v_pro_sort = 7 Then
            v_Qty7 := r_Item_Detail_Collect.apply_Qty;
            v_Qty17 := r_Item_Detail_Collect.check_qty;
          Elsif v_pro_sort = 8 Then
            --未知产地
            v_Qty8 := r_Item_Detail_Collect.apply_Qty;
            v_Qty18 := r_Item_Detail_Collect.check_qty;

          Elsif v_pro_sort = 9 Then
            --未知产地
            v_Qty9 := r_Item_Detail_Collect.apply_Qty;
            v_Qty19 := r_Item_Detail_Collect.check_qty;

          Elsif v_pro_sort = 10 Then
            --未知产地
            v_Qty10 := r_Item_Detail_Collect.apply_Qty;
            v_Qty20 := r_Item_Detail_Collect.check_qty;
         --add 2015-5-2
          Elsif v_pro_sort = 11 Then
            --未知产地
            v_Qty21 := r_Item_Detail_Collect.apply_Qty;
            v_Qty31 := r_Item_Detail_Collect.check_qty;

          Elsif v_pro_sort = 12 Then
            --未知产地
            v_Qty22 := r_Item_Detail_Collect.apply_Qty;
            v_Qty32 := r_Item_Detail_Collect.check_qty;

          Elsif v_pro_sort = 13 Then
            --未知产地
            v_Qty23 := r_Item_Detail_Collect.apply_Qty;
            v_Qty33 := r_Item_Detail_Collect.check_qty;

          Elsif v_pro_sort = 14 Then
            --未知产地
            v_Qty24 := r_Item_Detail_Collect.apply_Qty;
            v_Qty34 := r_Item_Detail_Collect.check_qty;

          Elsif v_pro_sort = 15 Then
            --未知产地
            v_Qty25 := r_Item_Detail_Collect.apply_Qty;
            v_Qty35 := r_Item_Detail_Collect.check_qty;

          Elsif v_pro_sort = 16 Then
            --未知产地
            v_Qty26 := r_Item_Detail_Collect.apply_Qty;
            v_Qty36 := r_Item_Detail_Collect.check_qty;

          Elsif v_pro_sort = 17 Then
            --未知产地
            v_Qty27 := r_Item_Detail_Collect.apply_Qty;
            v_Qty37 := r_Item_Detail_Collect.check_qty;

          Elsif v_pro_sort = 18 Then
            --未知产地
            v_Qty28 := r_Item_Detail_Collect.apply_Qty;
            v_Qty38 := r_Item_Detail_Collect.check_qty;

          Elsif v_pro_sort = 19 Then
            --未知产地
            v_Qty29 := r_Item_Detail_Collect.apply_Qty;
            v_Qty39 := r_Item_Detail_Collect.check_qty;

          Elsif v_pro_sort = 20 Then
            --未知产地
            v_Qty30 := r_Item_Detail_Collect.apply_Qty;
            v_Qty40 := r_Item_Detail_Collect.check_qty;

          End If;
        Exception
          When Others Then
            p_Result := '生成汇总订单明细失败' || v_Nl || Sqlerrm;
            Raise v_Base_Exception;
        End;
      End Loop;
      For r_Relation In ( -- 循环汇总订单行和计划订单行对应关系
                         Select l.Order_Line_Id
                           From t_Pln_Order_Line l
                          Where l.Order_Head_Id In
                                (select h.order_head_id
                                   From t_Pln_Order_Head  h,
                                        t_pln_order_type  ty,
                                        t_pln_flow_status ts
                                  Where h.Order_Type_Id = ty.order_type_id
                                    and ty.flow_id = ts.flow_id
                                    and h.order_type_id = p_Order_Type_Id
                                    And h.Batch_Id = p_Batch_Id
                                    And h.Period_Id = p_Period_Id
                                    And h.Entity_Id = p_Entity_Id
                                    and ts.action_code = '初始'
                                    and h.form_state = ts.curr_status_id
                                    and ('N' = v_main_param or ('Y' = v_main_param And h.sales_main_type = p_Sales_Main_Type)) --增加营销大类
                                    and ('N' = v_sub_param or ('Y' = v_sub_param And h.sales_sub_type = p_Sales_Sub_Type))--增加小类
                                 )
                            And l.Item_Id = r_Item_Collect.Item_Id
                          Group By l.Order_Line_Id) Loop
        Begin
          Insert Into t_Pln_Order_Collect_Relation
            (Entity_Id,
             Relation_Id,
             Order_Line_Id,
             Coll_Ord_Line_Id,
             Created_By,
             Creation_Date,
             Last_Updated_By,
             Last_Update_Date,
             order_collect_head_id)
          Values
            (p_Entity_Id,
             s_Pln_Order_Collect_Relation.Nextval,
             r_Relation.Order_Line_Id,
             v_Collect_Line_Id,
             p_User_Code,
             Sysdate,
             p_User_Code,
             Sysdate,
             v_Collect_Head_Id);
          /* when  others then
          p_result :='汇总订单行和计划订单行关系失败' || v_nl || sqlerrm ;
          raise v_Base_Exception;*/
        End;
      End Loop;
      --查询库存现有量
      /* if v_is_inv_check='Y' then  -- 如果为Y需要查询库存现有量
        Select Sum(Decode(Sales_Center_Flag, 'Y', Inv_Usable_Qty, 0)) Sales_Center_Qoh_Qty,
            Sum(Decode(Base_Flag, 'Y', Inv_Usable_Qty, 0)) Base_Qoh_Qty,
            Sum(Inv_Usable_Qty) Qoh_Qty
       into v_center_inv_qty, v_base_inv_qty, v_total_inv_qty
       From (Select Nvl(Ii.Sales_Center_Flag, 'N') Sales_Center_Flag,
                    Nvl(Ii.Base_Flag, 'N') Base_Flag,
                    Pkg_Inv_Pub.f_Get_Item_Inv_Qoh(p_Entity_Id    => Ii.Entity_Id,
                                                   p_Inventory_Id => Ii.Inventory_Id,
                                                   p_Item_Id      => r_item_collect.item_id,
                                                   p_User_Code    => p_user_code,
                                                   p_Get_Qoh_Type => 2) Inv_Usable_Qty
               From t_Inv_Inventories Ii
              Where Ii.Inventory_Type = '01'
                And Ii.Entity_Id = P_entity_id) Inv,
            t_Bd_Item Bi
      Where Bi.Item_Id = r_item_collect.item_id
        And Bi.Entity_Id = p_entity_id
      Group By Bi.Item_Id, Bi.Item_Code, Bi.Item_Name, Bi.Defaultunit;
      end if;*/
      --生成show表
      Begin
        Insert Into t_Pln_Order_Collect_Show
          (Entity_Id,
           Order_Collect_Show_Id,
           Batch_Id,
           Order_Collect_Head_Id,
           Order_Collect_Line_Id,
           Item_Id,
           Item_Code,
           Item_Name,
           Item_Uom,
           Apply_Qty, --申请数量
           Total_Inv_Affirm_Qty, --库存评审数量
           Total_Check_Qty, --评审数量
           Base_Inv_Qty, --基地仓库存
           All_Inv_Qty, --全国仓库存
           Qty1,
           Qty2,
           Qty3,
           Qty4,
           Qty5,
           Qty6,
           Qty7,
           Qty8,
           Qty9,
           Qty10,
           Qty11,
           Qty12,
           Qty13,
           Qty14,
           Qty15,
           Qty16,
           Qty17,
           Qty18,
           Qty19,
           Qty20,
           QTY21,
           QTY22,
           QTY23,
           QTY24,
           QTY25,
           QTY26,
           QTY27,
           QTY28,
           QTY29,
           QTY30,
           QTY31,
           QTY32,
           QTY33,
           QTY34,
           QTY35,
           QTY36,
           QTY37,
           QTY38,
           QTY39,
           QTY40,
           Created_By,
           Creation_Date,
           Last_Updated_By,
           Last_Update_Date)
        Values
          (p_Entity_Id,
           s_Pln_Order_Collect_Show.Nextval,
           1,
           v_Collect_Head_Id,
           v_Collect_Line_Id,
           r_Item_Collect.Item_Id,
           r_Item_Collect.Item_Code,
           r_Item_Collect.Item_Desc,
           r_Item_Collect.Item_Uom,
           r_Item_Collect.Apply_Qty,
           r_Item_Collect.Inv_Affirm_Qty,
           r_Item_Collect.check_qty,
           v_Base_Inv_Qty,
           v_Total_Inv_Qty,
           v_Qty1,
           v_Qty11,
           v_Qty2,
           v_Qty12,
           v_Qty3,
           v_Qty13,
           v_Qty4,
           v_Qty14,
           v_Qty5,
           v_Qty15,
           v_Qty6,
           v_Qty16,
           v_Qty7,
           v_Qty17,
           v_Qty8,
           v_Qty18,
           v_Qty9,
           v_Qty19,
           v_Qty10,
           v_Qty20,
           v_Qty21,
           v_Qty31,
           v_Qty22,
           v_Qty32,
           v_Qty23,
           v_Qty33,
           v_Qty24,
           v_Qty34,
           v_Qty25,
           v_Qty35,
           v_Qty26,
           v_Qty36,
           v_Qty27,
           v_Qty37,
           v_Qty28,
           v_Qty38,
           v_Qty29,
           v_Qty39,
           v_Qty30,
           v_Qty40,
           p_User_Code,
           Sysdate,
           p_User_Code,
           Sysdate);
        /*when  others then
        p_result :='汇总订单行和计划订单行关系失败' || v_nl || sqlerrm ;
        raise v_Base_Exception;*/
        v_Qty1  := Null;
        v_Qty2  := Null;
        v_Qty3  := Null;
        v_Qty4  := Null;
        v_Qty5  := Null;
        v_Qty6  := Null;
        v_Qty7  := Null;
        v_Qty8  := Null;
        v_Qty9  := Null;
        v_Qty10 := Null;
        v_Qty11  := Null;
        v_Qty12  := Null;
        v_Qty13  := Null;
        v_Qty14  := Null;
        v_Qty15  := Null;
        v_Qty16  := Null;
        v_Qty17  := Null;
        v_Qty18  := Null;
        v_Qty19  := Null;
        v_Qty20  := Null;
        v_qty21  := Null;
        v_Qty22  := Null;
        v_Qty23  := Null;
        v_qty24  := Null;
        v_qty25  := Null;
        v_qty26  := Null;
        v_qty27  := Null;
        v_qty28  := Null;
        v_qty29  := Null;
        v_qty30  := Null;
        v_qty31  := Null;
        v_qty32  := Null;
        v_qty33  := Null;
        v_qty34  := Null;
        v_qty35  := Null;
        v_qty36  := Null;
        v_qty37  := Null;
        v_qty38  := Null;
        v_qty39  := Null;
        v_qty40  := Null;
      End;
    End Loop;
    Begin
      ---跟新计划订单头
      Update t_Pln_Order_Head th
         Set th.Form_State = '25'
       Where th.order_head_id in
             (select h.order_head_id
                From t_Pln_Order_Head  h,
                     t_pln_order_type  ty,
                     t_pln_flow_status ts
               Where h.Order_Type_Id = ty.order_type_id
                 and ty.flow_id = ts.flow_id
                 and h.order_type_id = p_Order_Type_Id
                 And h.Batch_Id = p_Batch_Id
                 And h.Period_Id = p_Period_Id
                 And h.Entity_Id = p_Entity_Id
                 and ts.action_code = '初始'
                 and h.form_state = ts.curr_status_id
                 and ('N' = v_main_param or ('Y' = v_main_param And h.sales_main_type = p_Sales_Main_Type)) --增加营销大类
                 and ('N' = v_sub_param or ('Y' = v_sub_param And h.sales_sub_type = p_Sales_Sub_Type)) --增加小类
              );
      If Sql%Notfound Then
        p_Result := '更新计划订单头失败' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
      End If;
    End;
    if v_is_send='Y' then
    begin
      select ty.is_week into v_is_week from t_pln_order_type ty where ty.order_type_id=p_Order_Type_Id;
      select p.statistic_week into v_static from t_pln_order_period p where p.period_id=p_period_id;
      if v_is_week='Y' and v_static=4 then
        update t_pln_order_collect_head h set h.form_state='22' where h.coll_ord_head_id=v_Collect_Head_Id;
      end if ;
    end ;
    end if;
  Exception
    When v_Base_Exception Then
      Rollback;
      p_Result := p_Result;
    When Others Then
      Rollback;
      p_Result := '汇总失败' || v_Nl || Sqlerrm;
  End;
  -----------------------------------------------------------------------------
  --AUTHOR :张楚材
  --create :2015-01-07
  -- 汇总订单库存评审更新show 表
  Procedure p_up_inv_collect_show(p_order_collect_head_id in number, --汇总订单头id
                                  p_order_collect_show_id in number, --show Id
                                  p_item_id               in number, -- 产品Id
                                  p_entity_id             in number, --主体Id
                                  p_user_code             in varchar2, --操作用户
                                  p_result                out varchar2 -- 返回结果
                                  ) is
    v_show_id         number;
    v_order_type_id   number;
    v_period_id       number;
    v_batch_id        number;
    v_check_qty       number;
    v_inv_qty         number;
    v_qty1            number;
    v_qty2            number;
    v_qty3            number;
    v_qty4            number;
    v_qty5            number;
    v_qty6            number;
    v_qty7            number;
    v_qty8            number;
    v_qty9            number;
    v_qty10           number;
    v_Qty11           Number;
    v_Qty12           Number;
    v_Qty13           Number;
    v_Qty14           Number;
    v_Qty15           Number;
    v_Qty16           Number;
    v_Qty17           Number;
    v_qty18           number;
    v_qty19           number;
    v_qty20           number;
    v_pro_sort        number;
    v_item_id         number;
    v_sales_main_type varchar2(10);
    v_sales_sub_type  varchar2(20);
    v_main_param      varchar2(10);
    v_sub_param       varchar2(20);
  begin
    p_result := v_success;
    begin
      v_main_param := pkg_bd.F_GET_PARAMETER_VALUE('ITEM_SALES_MAIN_TYPE_FILTER',
                                                   p_Entity_Id);
    exception
      when others then
        p_Result := '获取营销大类参数失败' || v_nl || sqlerrm;
        raise v_Base_Exception;
    end;
    begin
      v_sub_param := pkg_bd.F_GET_PARAMETER_VALUE('ITEM_SALES_SUB_TYPE_FILTER',
                                                  p_Entity_Id);
    exception
      when others then
        p_Result := '获取营销小类参数失败' || v_nl || sqlerrm;
        raise v_Base_Exception;
    end;
    begin
      select ch.order_type_id,
             ch.period_id,
             ch.coll_ord_number,
             ch.sales_main_type,
             ch.sales_sub_type
        into v_order_type_id,
             v_period_id,
             v_batch_id,
             v_sales_main_type,
             v_sales_sub_type
        from t_pln_order_collect_head ch
       where ch.coll_ord_head_id = p_order_collect_head_id;
      select show.order_collect_show_id
        into v_show_id
        from t_pln_order_collect_show show
       where show.order_collect_show_id = p_order_collect_show_id
         for update nowait;
    Exception
      when others then
        p_result := '锁定汇总show表失败' || v_nl || sqlerrm;
        raise v_Base_Exception;
    end;
    begin
      select l.item_id,
             sum(nvl(check_qty, 0)) as check_qty,
             sum(nvl(l.INV_AFFIRM_QTY, 0)) as INV_AFFIRM_QTY
        into v_item_id, v_check_qty, v_inv_qty -- 查询评审数量, 库存评审数量
        from t_pln_order_line l
       where l.order_head_id in
             (select h.order_head_id
                from t_pln_order_head h
               where h.order_type_id = v_order_type_id
                 and h.period_id = v_period_id
                 and h.form_state = 25
                 and h.entity_id = p_entity_id
                 and h.batch_Id = v_batch_id)
         and l.item_id = p_item_id
       group by l.item_id;
      for r_item in (select l.item_id, -- 查询产品产地 -- 评审数量
                            l.producing_area_id,
                            sum(nvl(l.check_qty, 0)) as check_qty
                       from t_pln_order_line l
                      where l.order_head_id in
                            (select h.order_head_id
                               from t_pln_order_head h
                              where h.order_type_id = v_order_type_id
                                and h.period_id = v_period_id
                                and h.form_state = '25'
                                and h.entity_id = p_entity_id
                                and h.batch_id = v_batch_id
                               and ('N' = v_main_param or ('Y' = v_main_param And h.sales_main_type = v_sales_main_type)) --增加营销大类
                               and ('N' = v_sub_param or ('Y' = v_sub_param And h.sales_sub_type = v_sales_sub_type)) --增加小类
                             )
                        and l.item_id = p_item_id
                      group by l.item_id, l.producing_area_id) loop
        --查询产地排序顺序
        select tp.pro_sort
          into v_pro_sort
          from t_pln_producing_area tp
         where tp.entity_id = p_Entity_Id
           and tp.producing_area_id = r_item.Producing_Area_Id;
        if v_pro_sort = 1 then
          --芜湖
          v_qty1 := r_item.check_qty;
        elsif v_pro_sort = 2 -- 武汉
         then
          v_qty2 := r_item.check_qty;
        elsif v_pro_sort = 3 --南沙
         then
          v_qty3 := r_item.check_qty;
        elsif v_pro_sort = 4 -- 邯郸
         then
          v_qty4 := r_item.check_qty;
        elsif v_pro_sort = 5 --重庆
         then
          v_qty5 := r_item.check_qty;
        elsif v_pro_sort = 6 --顺德
         then
          v_qty6 := r_item.check_qty;
        elsif v_pro_sort = 7 --芜湖整体机
         then
          v_qty7 := r_item.check_qty;
        elsif v_pro_sort = 8   then
          v_qty8 := r_item.check_qty;
        elsif v_pro_sort = 9   then
          v_qty9 := r_item.check_qty;
        elsif v_pro_sort = 10  then
          v_qty10 := r_item.check_qty;
        elsif v_pro_sort = 11  then
          v_qty11 := r_item.check_qty;
        elsif v_pro_sort = 12  then
          v_qty12 := r_item.check_qty;
        elsif v_pro_sort = 13  then
          v_qty13 := r_item.check_qty;
        elsif v_pro_sort = 14  then
          v_qty14 := r_item.check_qty;
        elsif v_pro_sort = 15  then
          v_qty15 := r_item.check_qty;
        elsif v_pro_sort = 16  then
          v_qty16 := r_item.check_qty;
        elsif v_pro_sort = 17  then
          v_qty17 := r_item.check_qty;
        elsif v_pro_sort = 18  then
          v_qty18 := r_item.check_qty;
        elsif v_pro_sort = 19  then
          v_qty19 := r_item.check_qty;
        elsif v_pro_sort = 20  then
          v_qty20 := r_item.check_qty;
        end if;
      end loop;
      update t_pln_order_collect_show sh
         set sh.total_check_qty      = v_check_qty, -- 评审数量
             sh.total_inv_affirm_qty = v_inv_qty, --库存评审数量
             sh.qty2                 = v_qty1,
             sh.qty4                 = v_qty2,
             sh.qty6                 = v_qty3,
             sh.qty8                 = v_qty4,
             sh.qty10                = v_qty5,
             sh.qty12                = v_qty6,
             sh.qty14                = v_qty7,
             sh.qty16                = v_qty8,
             sh.qty18                = v_qty9,
             sh.qty20                = v_qty10,
             sh.qty22                = v_qty11,
             sh.qty24                = v_qty12,
             sh.qty26                = v_qty13,
             sh.qty28                = v_qty14,
             sh.qty30                = v_qty15,
             sh.qty32                = v_qty16,
             sh.qty34                = v_qty17,
             sh.qty36                = v_qty18,
             sh.qty38                = v_qty19,
             sh.qty40                = v_qty20,
             sh.last_updated_by      = p_user_code,
             sh.last_update_date     = sysdate
       where sh.order_collect_show_id = p_order_collect_show_id;
    end;
  Exception
    When v_Base_Exception Then
      Rollback;
      p_Result := p_Result;
    When Others Then
      Rollback;
      p_Result := '更新汇总数据失败' || v_Nl || Sqlerrm;
  end;
  -----------------------------------------------------------------------------
  --AUTHOR :张楚材
  --create :2015-01-07
  -- 汇总订单总装产能更新show 表
  Procedure p_up_total_collect_show(p_order_collect_head_id in number, --汇总订单头id
                                    p_order_collect_show_id in number, --show Id
                                    p_item_id               in number, -- 产品Id
                                    p_entity_id             in number, --主体Id
                                    p_user_code             in varchar2, --操作用户
                                    p_result                out varchar2 -- 返回结果
                                    ) is
    v_order_type_id         number;
    v_order_collect_line_id number;
    v_period_id             number;
    v_batch_id              number;
    v_check_qty             number;
    v_inv_qty               number;
    v_qty1                  number;
    v_qty2                  number;
    v_qty3                  number;
    v_qty4                  number;
    v_qty5                  number;
    v_qty6                  number;
    v_qty7                  number;
    v_qty8                  number;
    v_qty9                  number;
    v_qty10                 number;
    v_Qty11                 Number;
    v_Qty12                 Number;
    v_Qty13                 Number;
    v_Qty14                 Number;
    v_Qty15                 Number;
    v_Qty16                 Number;
    v_Qty17                 Number;
    v_qty18                 number;
    v_qty19                 number;
    v_qty20                 number;
    v_apply_qty1                  number;
    v_apply_qty2                  number;
    v_apply_qty3                  number;
    v_apply_qty4                  number;
    v_apply_qty5                  number;
    v_apply_qty6                  number;
    v_apply_qty7                  number;
    v_apply_qty8                  number;
    v_apply_qty9                  number;
    v_apply_qty10                 number;
    v_apply_qty11                 Number;
    v_apply_qty12                 Number;
    v_apply_qty13                 Number;
    v_apply_qty14                 Number;
    v_apply_qty15                 Number;
    v_apply_qty16                 Number;
    v_apply_qty17                 Number;
    v_apply_qty18                 number;
    v_apply_qty19                 number;
    v_apply_qty20                 number;
    v_pro_sort              number;
    v_sales_main_type       varchar2(10);
    v_sales_sub_type        varchar2(20);
    v_main_param            varchar2(10);
    v_sub_param             varchar2(20);
    v_qtyn1                 number;
    v_qtyn2                 number;
    v_qtyn3                 number;
    v_qtyn4                 number;
    v_qtyn5                 number;
    v_qtyn6                 number;
    v_qtyn7                 number;
    v_qtyn8                 number;
    v_qtyn9                 number;
    v_qtyn10                number;
    v_qtyn11                number;
    v_qtyn12                number;
    v_qtyn13                number;
    v_qtyn14                number;
    v_qtyn15                number;
    v_qtyn16                number;
    v_qtyn17                number;
    v_qtyn18                number;
    v_qtyn19                number;
    v_qtyn20                number;
    v_aps_back_qty          number;
  begin
    p_result := v_success;

    begin
      v_main_param := pkg_bd.F_GET_PARAMETER_VALUE('ITEM_SALES_MAIN_TYPE_FILTER',
                                                   p_Entity_Id);
    exception
      when others then
        p_Result := '获取营销大类参数失败' || v_nl || sqlerrm;
        raise v_Base_Exception;
    end;
    begin
      v_sub_param := pkg_bd.F_GET_PARAMETER_VALUE('ITEM_SALES_SUB_TYPE_FILTER',
                                                  p_Entity_Id);
    exception
      when others then
        p_Result := '获取营销小类参数失败' || v_nl || sqlerrm;
        raise v_Base_Exception;
    end;
    begin
      select ch.order_type_id,
             ch.period_id,
             ch.coll_ord_number,
             ch.sales_main_type,
             ch.sales_sub_type
        into v_order_type_id,
             v_period_id,
             v_batch_id,
             v_sales_main_type,
             v_sales_sub_type
        from t_pln_order_collect_head ch
       where ch.coll_ord_head_id = p_order_collect_head_id
         for update nowait;
    Exception
      when others then
        p_result := '锁定汇总订单头表失败' || v_nl || sqlerrm;
        raise v_Base_Exception;
    end;
    begin
      for r_item_collect in ( -- 按产品汇总
                             select l.item_id,
                                    Sum(nvl(l.apply_qty, 0)) As apply_qty, --add by lizhen 2016-10-26
                                     sum(nvl(l.check_qty, 0)) check_qty,
                                     sum(nvl(l.inv_affirm_qty, 0)) inv_qty,
                                     sum(nvl(l.aps_back_qty,0)) aps_back_qty
                               from t_pln_order_line l
                              where l.order_head_id in
                                    (select h.order_head_id
                                       from t_pln_order_head h
                                      where h.order_type_id = v_order_type_id
                                        and h.period_id = v_period_id
                                        and h.form_state = '25'
                                        and h.entity_id = p_entity_id
                                        and h.batch_Id = v_batch_id
                                        and ('N' = v_main_param or ('Y' = v_main_param And h.sales_main_type = v_sales_main_type)) --增加营销大类
                                        and ('N' = v_sub_param or ('Y' = v_sub_param And h.sales_sub_type = v_sales_sub_type)) --增加小类
                                     )
                              group by l.item_id) loop
        v_check_qty := r_item_collect.check_qty; -- 评审量
        v_inv_qty   := r_item_collect.inv_qty; --库存评审数量
        v_aps_back_qty :=r_item_collect.aps_back_qty;
        /*select cLine.Coll_Ord_Line_Id  -- 查询汇总订单行
        into v_order_collect_line_id
        from t_pln_order_collect_line cLIne
        where
        cLine.Coll_Ord_Head_Id=p_order_collect_head_id
        and cLine.Item_Id=r_item_collect.item_id;*/
        for r_item in (select l.item_id, -- 查询产品产地 -- 评审数量
                              l.producing_area_id,
                              Sum(nvl(l.apply_qty, 0)) As apply_qty, --add by lizhen 2016-10-26
                              sum(nvl(l.check_qty, 0)) as check_qty,
                              sum(nvl(l.aps_back_qty,0)) aps_back_qty
                         from t_pln_order_line l
                        where l.order_head_id in
                              (select h.order_head_id
                                 from t_pln_order_head h
                                where h.order_type_id = v_order_type_id
                                  and h.period_id = v_period_id
                                  and h.form_state = '25'
                                  and h.entity_id = p_entity_id
                                  and h.batch_id = v_batch_id
                                  and ('N' = v_main_param or ('Y' = v_main_param And h.sales_main_type = v_sales_main_type)) --增加营销大类
                                  and ('N' = v_sub_param or ('Y' = v_sub_param And h.sales_sub_type = v_sales_sub_type)) --增加小类
                               )
                          and l.item_id = r_item_collect.item_id
                        group by l.item_id, l.producing_area_id) loop
          select tp.pro_sort
            into v_pro_sort
            from t_pln_producing_area tp
           where tp.entity_id = p_Entity_Id
             and tp.producing_area_id = r_item.Producing_Area_Id;
          if v_pro_sort = 1 then
            --芜湖
            v_qty1 := r_item.check_qty;
            v_qtyn1 :=r_item.aps_back_qty;
            v_apply_qty1 := r_item.apply_qty; --add by lizhen 2016-10-27
          elsif v_pro_sort = 2 -- 武汉
           then
            v_qty2 := r_item.check_qty;
            v_qtyn2 :=r_item.aps_back_qty;
            v_apply_qty2 := r_item.apply_qty; --add by lizhen 2016-10-27
          elsif v_pro_sort = 3 --南沙
           then
            v_qty3 := r_item.check_qty;
            v_qtyn3 :=r_item.aps_back_qty;
            v_apply_qty3 := r_item.apply_qty; --add by lizhen 2016-10-27
          elsif v_pro_sort = 4 -- 邯郸
           then
            v_qty4 := r_item.check_qty;
            v_qtyn4 :=r_item.aps_back_qty;
            v_apply_qty4 := r_item.apply_qty; --add by lizhen 2016-10-27
          elsif v_pro_sort = 5 --重庆
           then
            v_qty5 := r_item.check_qty;
            v_qtyn5 :=r_item.aps_back_qty;
            v_apply_qty5 := r_item.apply_qty; --add by lizhen 2016-10-27
          elsif v_pro_sort = 6 --顺德
           then
            v_qty6 := r_item.check_qty;
            v_qtyn6 :=r_item.aps_back_qty;
            v_apply_qty6 := r_item.apply_qty; --add by lizhen 2016-10-27
          elsif v_pro_sort = 7 --芜湖整体机
           then
            v_qty7 := r_item.check_qty;
            v_qtyn7 :=r_item.aps_back_qty;
            v_apply_qty7 := r_item.apply_qty; --add by lizhen 2016-10-27
          elsif v_pro_sort = 8 --
           then
            v_qty8 := r_item.check_qty;
            v_qtyn8 :=r_item.aps_back_qty;
            v_apply_qty8 := r_item.apply_qty; --add by lizhen 2016-10-27
          elsif v_pro_sort = 9 --
           then
            v_qty9 := r_item.check_qty;
            v_qtyn9 :=r_item.aps_back_qty;
            v_apply_qty9 := r_item.apply_qty; --add by lizhen 2016-10-27
          elsif v_pro_sort = 10 --
           then
            v_qty10 := r_item.check_qty;
            v_qtyn10 :=r_item.aps_back_qty;
            v_apply_qty10 := r_item.apply_qty; --add by lizhen 2016-10-27
          elsif v_pro_sort = 11 --
           then
            v_qty11 := r_item.check_qty;
            v_qtyn11 :=r_item.aps_back_qty;
            v_apply_qty11 := r_item.apply_qty; --add by lizhen 2016-10-27
          elsif v_pro_sort = 12 --
           then
            v_qty12 := r_item.check_qty;
            v_qtyn12 :=r_item.aps_back_qty;
            v_apply_qty12 := r_item.apply_qty; --add by lizhen 2016-10-27
          elsif v_pro_sort = 13 --
           then
            v_qty13 := r_item.check_qty;
            v_qtyn13 :=r_item.aps_back_qty;
            v_apply_qty13 := r_item.apply_qty; --add by lizhen 2016-10-27
          elsif v_pro_sort = 14 --
           then
            v_qty14 := r_item.check_qty;
            v_qtyn14 :=r_item.aps_back_qty;
            v_apply_qty14 := r_item.apply_qty; --add by lizhen 2016-10-27
          elsif v_pro_sort = 15 --
           then
            v_qty15 := r_item.check_qty;
            v_qtyn15 :=r_item.aps_back_qty;
            v_apply_qty15 := r_item.apply_qty; --add by lizhen 2016-10-27
          elsif v_pro_sort = 16 --
           then
            v_qty16 := r_item.check_qty;
            v_qtyn16 :=r_item.aps_back_qty;
            v_apply_qty16 := r_item.apply_qty; --add by lizhen 2016-10-27
          elsif v_pro_sort = 17 --
           then
            v_qty17 := r_item.check_qty;
            v_qtyn17 :=r_item.aps_back_qty;
            v_apply_qty17 := r_item.apply_qty; --add by lizhen 2016-10-27
          elsif v_pro_sort = 18 --
           then
            v_qty18 := r_item.check_qty;
            v_qtyn18 :=r_item.aps_back_qty;
            v_apply_qty18 := r_item.apply_qty; --add by lizhen 2016-10-27
          elsif v_pro_sort = 19 --
           then
            v_qty19 := r_item.check_qty;
            v_qtyn19 :=r_item.aps_back_qty;
            v_apply_qty19 := r_item.apply_qty; --add by lizhen 2016-10-27
          elsif v_pro_sort = 20 --
           then
            v_qty20 := r_item.check_qty;
            v_qtyn20 :=r_item.aps_back_qty;
            v_apply_qty20 := r_item.apply_qty; --add by lizhen 2016-10-27
          end if;
        end loop;
        update t_pln_order_collect_show sh
           set sh.total_inv_affirm_qty = v_inv_qty,
               sh.total_check_qty      = v_check_qty,
               sh.apply_qty            = r_item_collect.apply_qty, --add by lizhen 2016-10-27
               sh.qty2                 = v_qty1,
               sh.qty4                 = v_qty2,
               sh.qty6                 = v_qty3,
               sh.qty8                 = v_qty4,
               sh.qty10                = v_qty5,
               sh.qty12                = v_qty6,
               sh.qty14                = v_qty7,
               sh.qty16                = v_qty8,
               sh.qty18                = v_qty9,
               sh.qty20                = v_qty10,
               sh.qty22                = v_qty11,
               sh.qty24                = v_qty12,
               sh.qty26                = v_qty13,
               sh.qty28                = v_qty14,
               sh.qty30                = v_qty15,
               sh.qty32                = v_qty16,
               sh.qty34                = v_qty17,
               sh.qty36                = v_qty18,
               sh.qty38                = v_qty19,
               sh.qty40                = v_qty20,
               sh.qty1                 = v_apply_qty1,
               sh.qty3                 = v_apply_qty2,
               sh.qty5                 = v_apply_qty3,
               sh.qty7                 = v_apply_qty4,
               sh.qty9                 = v_apply_qty5,
               sh.qty11                = v_apply_qty6,
               sh.qty13                = v_apply_qty7,
               sh.qty15                = v_apply_qty8,
               sh.qty17                = v_apply_qty9,
               sh.qty19                = v_apply_qty10,
               sh.qty21                = v_apply_qty11,
               sh.qty23                = v_apply_qty12,
               sh.qty25                = v_apply_qty13,
               sh.qty27                = v_apply_qty14,
               sh.qty29                = v_apply_qty15,
               sh.qty31                = v_apply_qty16,
               sh.qty33                = v_apply_qty17,
               sh.qty35                = v_apply_qty18,
               sh.qty37                = v_apply_qty19,
               sh.qty39                = v_apply_qty20,
               sh.aps_back_qty         = v_aps_back_qty,
               sh.qtyn1                = v_qtyn1,
               sh.qtyn2                = v_qtyn2,
               sh.qtyn3                = v_qtyn3,
               sh.qtyn4                = v_qtyn4,
               sh.qtyn5                = v_qtyn5,
               sh.qtyn6                = v_qtyn6,
               sh.qtyn7                = v_qtyn7,
               sh.qtyn8                = v_qtyn8,
               sh.qtyn9                = v_qtyn9,
               sh.qtyn10               = v_qtyn10,
               sh.qtyn11               = v_qtyn11,
               sh.qtyn12               = v_qtyn12,
               sh.qtyn13               = v_qtyn13,
               sh.qtyn14               = v_qtyn14,
               sh.qtyn15               = v_qtyn15,
               sh.qtyn16               = v_qtyn16,
               sh.qtyn17               = v_qtyn17,
               sh.qtyn18               = v_qtyn18,
               sh.qtyn19               = v_qtyn19,
               sh.qtyn20               = v_qtyn20,
               sh.last_updated_by      = p_user_code,
               sh.last_update_date     = sysdate
         where sh.item_id = r_item_collect.item_id
           and sh.order_collect_head_id = p_order_collect_head_id
           and sh.batch_id =
               (select max(sh1.batch_id)
                  from t_pln_order_collect_show sh1
                 where sh1.order_collect_head_id = p_order_collect_head_id);
        v_qty1      := null;
        v_qty2      := null;
        v_qty3      := null;
        v_qty4      := null;
        v_qty5      := null;
        v_qty6      := null;
        v_qty7      := null;
        v_qty8      := null;
        v_qty9      := null;
        v_qty10     := null;
        v_qty11     := null;
        v_qty12     := null;
        v_qty13     := null;
        v_qty14     := null;
        v_qty15     := null;
        v_qty16     := null;
        v_qty17     := null;
        v_qty18     := null;
        v_qty19     := null;
        v_qty20     := null;
        v_qtyn1     :=null;
        v_qtyn2     :=null;
        v_qtyn3     :=null;
        v_qtyn4     :=null;
        v_qtyn5     :=null;
        v_qtyn6     :=null;
        v_qtyn7     :=null;
        v_qtyn8     :=null;
        v_qtyn9     :=null;
        v_qtyn10    :=null;
        v_qtyn11    :=null;
        v_qtyn12    :=null;
        v_qtyn13    :=null;
        v_qtyn14    :=null;
        v_qtyn15    :=null;
        v_qtyn16    :=null;
        v_qtyn17    :=null;
        v_qtyn18    :=null;
        v_qtyn19    :=null;
        v_qtyn20    :=null;
        v_apply_qty1 :=null;
        v_apply_qty2 :=null;
        v_apply_qty3 :=null;
        v_apply_qty4 :=null;
        v_apply_qty5 :=null;
        v_apply_qty6 :=null;
        v_apply_qty7 :=null;
        v_apply_qty8 :=null;
        v_apply_qty9 :=null;
        v_apply_qty10 :=null;
        v_apply_qty11 :=null;
        v_apply_qty12 :=null;
        v_apply_qty13 :=null;
        v_apply_qty14 :=null;
        v_apply_qty15 :=null;
        v_apply_qty16 :=null;
        v_apply_qty17 :=null;
        v_apply_qty18 :=null;
        v_apply_qty19 :=null;
        v_apply_qty20 :=null;
        v_aps_back_qty  :=null;
      end loop;
    end;
  Exception
    When v_Base_Exception Then
      Rollback;
      p_Result := p_Result;
    When Others Then
      Rollback;
      p_Result := '更新汇总数据失败' || v_Nl || Sqlerrm;
  end;
  -----------------------------------------------------------------------------
  --AUTHOR :张楚材
  --create :2015-01-07
  -- 汇总订单模具产能更新show 表
  Procedure p_up_mould_collect_show(p_order_collect_id in number, -- 订单汇总头Id
                                    p_mould_id         in number, -- 模具Id
                                    p_entity_id        in number, --主体Id
                                    p_sales_main_type  in varchar2, --营销大类
                                    p_sales_sub_type   in varchar2, --营销小类
                                    p_user_code        in varchar2, --操作用户
                                    p_result           out varchar2 -- 返回结果
                                    ) is
    v_order_type_id         number;
    v_order_collect_line_id number;
    v_period_id             number;
    v_batch_id              number;
    v_check_qty             number;
    v_qty1                  number;
    v_qty2                  number;
    v_qty3                  number;
    v_qty4                  number;
    v_qty5                  number;
    v_qty6                  number;
    v_qty7                  number;
    v_qty8                  number;
    v_qty9                  number;
    v_qty10                 number;
    v_qty11                 number;
    v_qty12                 number;
    v_qty13                 number;
    v_qty14                 number;
    v_qty15                 number;
    v_qty16                 number;
    v_qty17                 number;
    v_qty18                 number;
    v_qty19                 number;
    v_qty20                 number;
    v_pro_sort              number;
    v_main_param varchar2(10);
    v_sub_param  varchar2(20);
    v_check      number; -- 控制是否更新show表
  begin
    p_result := v_success;
    begin
      v_main_param := pkg_bd.F_GET_PARAMETER_VALUE('ITEM_SALES_MAIN_TYPE_FILTER',
                                                   p_Entity_Id);
    exception
      when others then
        p_Result := '获取营销大类参数失败' || v_nl || sqlerrm;
        raise v_Base_Exception;
    end;
    begin
      v_sub_param := pkg_bd.F_GET_PARAMETER_VALUE('ITEM_SALES_SUB_TYPE_FILTER',
                                                  p_Entity_Id);
    exception
      when others then
        p_Result := '获取营销小类参数失败' || v_nl || sqlerrm;
        raise v_Base_Exception;
    end;
    begin
      select ch.order_type_id, ch.coll_ord_number, ch.period_id
        into v_order_type_id, v_batch_id, v_period_id
        from t_pln_order_collect_head ch
       where ch.coll_ord_head_id = p_order_collect_id
         for update nowait;
    exception
      when others then
        p_result := '锁定汇总订单头失败' || v_nl || sqlerrm;
        raise v_Base_Exception;
    end;
    begin
      for r_mould_item in (select tp.item_id
                             from t_pln_item_plastic tp --查询模具对应产品
                            where tp.plastic_id = p_mould_id
                              and tp.entity_id = p_entity_id) loop
        for r_item in (select l.item_id, -- 查询产品产地 -- 评审数量
                              l.producing_area_id,
                              sum(nvl(l.check_qty, 0)) as check_qty
                         from t_pln_order_line l
                        where l.order_head_id in
                              (select h.order_head_id
                                 from t_pln_order_head h
                                where h.order_type_id = v_order_type_id
                                  and h.period_id = v_period_id
                                  and h.form_state = '25'
                                  and h.entity_id = p_entity_id
                                  and h.batch_id = v_batch_id
                                  and ('N' = v_main_param or ('Y' = v_main_param And h.sales_main_type = p_Sales_Main_Type)) --增加营销大类
                                  and ('N' = v_sub_param or ('Y' = v_sub_param And h.sales_sub_type = p_Sales_Sub_Type)) --增加小类
                               )
                          and l.item_id = r_mould_item.item_id
                        group by l.item_id, l.producing_area_id) loop
          select tp.pro_sort
            into v_pro_sort
            from t_pln_producing_area tp
           where tp.entity_id = p_Entity_Id
             and tp.producing_area_id = r_item.Producing_Area_Id;
          if v_pro_sort = 1 then
            v_qty1 := r_item.check_qty;
          elsif v_pro_sort = 2 -- 武汉
            then
            v_qty2 := r_item.check_qty;
          elsif v_pro_sort = 3 --南沙
            then
            v_qty3 := r_item.check_qty;
          elsif v_pro_sort = 4 -- 邯郸
            then
            v_qty4 := r_item.check_qty;
          elsif v_pro_sort = 5 --重庆
            then
            v_qty5 := r_item.check_qty;
          elsif v_pro_sort = 6 --顺德
            then
            v_qty6 := r_item.check_qty;
          elsif v_pro_sort = 7 --芜湖整体机
            then
            v_qty7 := r_item.check_qty;
          elsif v_pro_sort = 8 --
            then
            v_qty8 := r_item.check_qty;
          elsif v_pro_sort = 9 --
            then
            v_qty9 := r_item.check_qty;
          elsif v_pro_sort = 10 --
            then
            v_qty10 := r_item.check_qty;

          elsif v_pro_sort = 11 --
            then
            v_qty11 := r_item.check_qty;
          elsif v_pro_sort = 12 --
            then
            v_qty12 := r_item.check_qty;

          elsif v_pro_sort = 13 --
            then
            v_qty13 := r_item.check_qty;

          elsif v_pro_sort = 14 --
            then
            v_qty14 := r_item.check_qty;

          elsif v_pro_sort = 15 --
            then
            v_qty15 := r_item.check_qty;

          elsif v_pro_sort = 16 --
            then
            v_qty16 := r_item.check_qty;

          elsif v_pro_sort = 17 --
            then
            v_qty17 := r_item.check_qty;

          elsif v_pro_sort = 18 --
            then
            v_qty18 := r_item.check_qty;

          elsif v_pro_sort = 19 --
            then
            v_qty19 := r_item.check_qty;

          elsif v_pro_sort = 20 --
            then
            v_qty20 := r_item.check_qty;
          end if;
          v_check_qty := nvl(v_check_qty, 0) + r_item.check_qty;
          v_check     := 1;
        end loop;
        if v_check = 1 then
          update t_pln_order_collect_show sh
             set sh.total_check_qty  = v_check_qty,
                 sh.qty2             = v_qty1,
                 sh.qty4             = v_qty2,
                 sh.qty6             = v_qty3,
                 sh.qty8             = v_qty4,
                 sh.qty10            = v_qty5,
                 sh.qty12            = v_qty6,
                 sh.qty14            = v_qty7,
                 sh.qty16            = v_qty8,
                 sh.qty18            = v_qty9,
                 sh.qty20            = v_qty10,
                 sh.qty22            = v_qty11,
                 sh.qty24            = v_qty12,
                 sh.qty26            = v_qty13,
                 sh.qty28            = v_qty14,
                 sh.qty30            = v_qty15,
                 sh.qty32            = v_qty16,
                 sh.qty34            = v_qty17,
                 sh.qty36            = v_qty18,
                 sh.qty38            = v_qty19,
                 sh.qty40            = v_qty20,
                 sh.last_updated_by  = p_user_code,
                 sh.last_update_date = sysdate
           where sh.item_id = r_mould_item.item_id
             and sh.order_collect_head_id = p_order_collect_id
             and sh.batch_id =
                 (select max(sh1.batch_id)
                    from t_pln_order_collect_show sh1
                   where sh1.order_collect_head_id = p_order_collect_id);
          v_check_qty := null; -- 保存总得评审数量
          v_qty1      := null;
          v_qty2      := null;
          v_qty3      := null;
          v_qty4      := null;
          v_qty5      := null;
          v_qty6      := null;
          v_qty7      := null;
          v_qty8      := null;
          v_qty9      := null;
          v_qty10     := null;
          v_qty11     := null;
          v_qty12     := null;
          v_qty13     := null;
          v_qty14     := null;
          v_qty15     := null;
          v_qty16     := null;
          v_qty17     := null;
          v_qty18     := null;
          v_qty19     := null;
          v_qty20     := null;
          v_check     := null;
        end if;
      end loop;
    end;
  Exception
    When v_Base_Exception Then
      Rollback;
      p_Result := p_Result;
    When Others Then
      Rollback;
      p_Result := '更新汇总数据失败' || v_Nl || Sqlerrm;
  end;
  -----------------------------------------------------------------------------
  --AUTHOR :张楚材
  --create :2015-01-07
  -- 汇总订单模具产能更新show 表
  Procedure Check_Item_Cyc_Life(p_Order_Collect_Head_Id In Number, --汇总订单头Id
                                p_Entity_Id             In Number,
                                p_User_Code             In Varchar2,
                                p_Result                Out Varchar2) Is
    Vs_Item_Life_Cycle Varchar2(2);
  Begin
    p_Result := Null;
    Begin
      Vs_Item_Life_Cycle := Pkg_Bd.f_Get_Parameter_Value('PLN_ITEM_LIFE_CYCLE',
                                                         p_Entity_Id);
    Exception
      When Others Then
        p_Result := '获取PLN_ITEM_LIFE_CYCLE参数失败' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;
    --是否校验产品生命周期
    If Vs_Item_Life_Cycle != 'N' Then
      For c_Pln_Item_Life_Cycle In (Select Ol.Item_Code
                                      From t_Pln_Order_Collect_Relation Re,
                                           t_Pln_Order_Line             Ol,
                                           t_Pln_Item_Producing_Area    Ipa
                                     Where Re.Order_Line_Id =
                                           Ol.Order_Line_Id
                                       And Re.Order_Collect_Head_Id = p_Order_Collect_Head_Id
                                       And Ol.Item_Id = Ipa.Item_Id
                                       And Ol.Producing_Area_Id = Ipa.Producing_Area_Id
                                       And Ol.Can_Produce_Qty > 0
                                       And Not Exists
                                     (Select 1
                                              From t_Pln_Item_Life_Cycle Ilc
                                             Where Ol.Entity_Id = Ilc.Entity_Id
                                               And Ilc.Is_Aps_Flag = 'Y'
                                               And Nvl(Ipa.State, '_') = Ilc.System_Status)
                                    --MODI BY LIZHEN 2015-04-23 产品生命周期不为Y的都表示不允许引入
                                    /*and not exists
                                    (SELECT 1
                                            FROM T_PLN_ITEM_LIFE_CYCLE ILC
                                           WHERE ol.ENTITY_ID = ILC.ENTITY_ID
                                             AND ILC.IS_APS_FLAG = 'Y'
                                             AND NVL(IPA.STATE, '_') = ILC.SYSTEM_STATUS
                                             AND NOT EXISTS --预退市套件不能引APS
                                           (SELECT 1
                                                    FROM T_PLN_ITEM_LIFE_CYCLE ILC, T_BD_ITEM BI
                                                   WHERE ILC.IS_APS_FLAG = 'Y'
                                                     AND NVL(IPA.STATE, '_') = ILC.SYSTEM_STATUS
                                                     AND ILC.SYSTEM_STATUS = 'PRE_DELIST'
                                                     AND BI.PRODUCTFORM = 'SET_PRODUCT'
                                                     AND OL.ENTITY_ID = BI.ENTITY_ID
                                                     AND OL.ITEM_ID = BI.ITEM_ID))*/
                                    ) Loop
        p_Result := p_Result || c_Pln_Item_Life_Cycle.Item_Code || ',';
      End Loop;
    End If;
    If p_Result Is Null Then
      p_Result := v_Result;
    End If;
  Exception
    When v_Base_Exception Then
      p_Result := p_Result;
  End;

  ----------------------------------------------------------------------------------
  --Author: Nicro.Li
  --CreateDate: 2015-04-20
  --Purpose: 汇总订单库存评审更新汇总行库存可用量
  ----------------------------------------------------------------------------------
  Procedure p_Upd_Inv_Qoh_Coolect_Show(p_Order_Collect_Id In Number,
                                       p_Entity_Id        In Number,
                                       p_User_Code        In Varchar2,
                                       p_Result           Out Varchar2) Is
    r_Collect_Head t_Pln_Order_Collect_Head%Rowtype;
  Begin
    p_Result := v_Success;
    Begin
      Select *
        Into r_Collect_Head
        From t_Pln_Order_Collect_Head Ch
       Where Ch.Coll_Ord_Head_Id = p_Order_Collect_Id
         And Ch.Entity_Id = p_Entity_Id
         For Update Nowait ;
    Exception
      When Others Then
        p_Result := '锁定汇总订单头表失败。' || v_Nl || '汇总头ID：' ||
                    To_Char(p_Order_Collect_Id) || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;

    For r_Collect_Line In (Select *
                             From t_Pln_Order_Collect_Line Cl
                            Where Cl.Coll_Ord_Head_Id = p_Order_Collect_Id) Loop
      --更新基地仓库存
      Update t_Pln_Order_Collect_Show Ocs
         Set Ocs.Last_Updated_By = p_User_Code,
             Ocs.Last_Update_Date = Sysdate,
             Ocs.Base_Inv_Qty =
             (Nvl((Select Sum(Tio.Quantity) Qoh1
                  From t_Inv_Onhand Tio, t_Inv_Inventories Tii
                 Where Tio.Item_Id = r_Collect_Line.Item_Id
                   And Tio.Inventory_Id = Tii.Inventory_Id
                   And Tii.Inventory_Type = '01'
                   And Tii.Base_Flag = 'Y'
                   And Tio.Entity_Id = p_Entity_Id
                 Group By Tio.Item_Id),
                0) -
           --散件库存占用量
           Nvl((Select Sum(Nvl(Oio.Stock_Affirm_Qty, 0) +
                           Nvl(Oio.Supply_Qty, 0) -
                           Nvl(Oio.So_Order_Qty, 0) -
                           Nvl(Oio.Sundry_Qty, 0)) Occupyqty
                  From t_Pln_Order_Inv_Occupy Oio, t_Inv_Inventories Tii
                 Where Oio.Entity_Id = p_Entity_Id
                   And Oio.Item_Id = r_Collect_Line.Item_Id
                   And Tii.Inventory_Id = Oio.Inventory_Id
                   And Tii.Inventory_Type = '01'
                   And Tii.Base_Flag = 'Y'
                 Group By Oio.Item_Id),
                0) -
           --散件采购退货
           Nvl((Select Sum(Decode(o.Po_Status,
                                  p_Entity_Id,
                                  Nvl(l.Billed_Qty, 0),
                                  Nvl(l.Shipped_Qty, 0))) Po_Qty
                  From t_Inv_Po_Headers        o,
                       t_Inv_Po_Lines          l,
                       t_Inv_Bill_Types        t,
                       t_Inv_Inventories       i,
                       t_Inv_Bill_Types        Ibt,
                       t_Inv_Transaction_Types Itt
                 Where t.Bill_Type_Id = o.Po_Type_Id
                   And t.Entity_Id = o.Entity_Id
                   And l.Po_Id = o.Po_Id
                   And Nvl(o.Source_Type, '_') != '工单入库'
                   And i.Inventory_Id = o.Inv_Finance_Id
                   And i.Entity_Id = o.Entity_Id
                   And Trunc(o.Billed_Date) >= Trunc(Sysdate - 30)
                   And o.Po_Status <> '14' --执行
                   And Nvl(o.Close_Flag, 'N') != 'Y'
                   And o.Entity_Id = p_Entity_Id
                   And i.Base_Flag = 'Y'
                   And i.Inventory_Type = '01'
                   And l.Item_Id = r_Collect_Line.Item_Id
                      --采购单红冲出库的单据才纳入现有量计算
                   And Ibt.Transaction_Type_Id = Itt.Transaction_Type_Id
                   And Itt.Action_Type = '02'
                   And Ibt.Bill_Type_Id = o.Po_Type_Id
                 Group By l.Item_Id),
                0) +
           --套件可用量
           Nvl((Select Sum(Qoh1) Qoh1
                  From (Select Inventory_Id, Min(Qoh1) Qoh1
                          From (Select Qoh1.Inventory_Id,
                                       Qoh1.Item_Id,
                                       Sum(Nvl(Qoh1, 0) - Nvl(Occupy_Qty, 0) -
                                           Nvl(Po_Qty, 0)) Qoh1
                                  From (Select Bias.Item_Id,
                                               Tii.Inventory_Id,
                                               0                Qoh1,
                                               0                Occupy_Qty,
                                               0                Po_Qty
                                          From t_Bd_Item_Assemblies     Tbia,
                                               t_Bd_Item_Assemblies_Sub Bias,
                                               t_Inv_Inventories        Tii
                                         Where Tbia.Item_Id = r_Collect_Line.Item_Id
                                           And Tbia.Entity_Id = p_Entity_Id
                                           And Tii.Inventory_Type = '01'
                                           And Tii.Entity_Id = p_Entity_Id
                                           And Tii.Base_Flag = 'Y'
                                           And Bias.Item_Assembly_Id = Tbia.Item_Assembly_Id
                                           And Trunc(Sysdate) Between Tbia.Begin_Date And
                                               Trunc(Nvl(Tbia.End_Date, Sysdate))
                                           And Trunc(Sysdate) Between Bias.Begin_Date And
                                               Trunc(Nvl(Bias.End_Date, Sysdate))
                                         Group By Bias.Item_Id,
                                                  Tii.Inventory_Id,
                                                  Nvl(Bias.Quantity, 1)
                                        Union All
                                        --套件现有库存量
                                        Select Bias.Item_Id,
                                               Tii.Inventory_Id,
                                               Trunc(Sum(Nvl(Tio.Quantity, 0)) /
                                                     Nvl(Bias.Quantity, 1)) Qoh1,
                                               0 Occupy_Qty,
                                               0 Po_Qty
                                          From t_Inv_Onhand             Tio,
                                               t_Bd_Item_Assemblies     Tbia,
                                               t_Bd_Item_Assemblies_Sub Bias,
                                               t_Inv_Inventories        Tii
                                         Where Tbia.Item_Id = r_Collect_Line.Item_Id
                                           And Tbia.Entity_Id = p_Entity_Id
                                           And Bias.Item_Assembly_Id = Tbia.Item_Assembly_Id
                                           And Trunc(Sysdate) Between Tbia.Begin_Date And
                                               Trunc(Nvl(Tbia.End_Date, Sysdate))
                                           And Trunc(Sysdate) Between Bias.Begin_Date And
                                               Trunc(Nvl(Bias.End_Date, Sysdate))
                                           And Tio.Item_Id = Bias.Item_Id
                                           And Tio.Entity_Id = p_Entity_Id
                                           And Tii.Inventory_Id = Tio.Inventory_Id
                                           And Tii.Inventory_Type = '01'
                                           And Tii.Base_Flag = 'Y'
                                         Group By Bias.Item_Id,
                                                  Tii.Inventory_Id,
                                                  Nvl(Bias.Quantity, 1)
                                        Union All
                                        --套件现占用量
                                        Select Bias.Item_Id,
                                               Tii.Inventory_Id,
                                               0 Qoh1,
                                               Trunc(Sum(Nvl(Oio.Stock_Affirm_Qty, 0) +
                                                         Nvl(Oio.Supply_Qty, 0) -
                                                         Nvl(Oio.So_Order_Qty, 0) -
                                                         Nvl(Oio.Sundry_Qty, 0)) /
                                                     Nvl(Bias.Quantity, 1)) Occupy_Qty,
                                               0 Po_Qty
                                          From t_Pln_Order_Inv_Occupy   Oio,
                                               t_Bd_Item_Assemblies     Tbia,
                                               t_Bd_Item_Assemblies_Sub Bias,
                                               t_Inv_Inventories        Tii
                                         Where Tbia.Item_Id = r_Collect_Line.Item_Id
                                           And Tbia.Entity_Id = p_Entity_Id
                                           And Bias.Item_Id = Oio.Item_Id
                                           And Bias.Entity_Id = Oio.Entity_Id
                                           And Tbia.Entity_Id = Oio.Entity_Id
                                           And Bias.Item_Assembly_Id = Tbia.Item_Assembly_Id
                                           And Trunc(Sysdate) Between Tbia.Begin_Date And
                                               Trunc(Nvl(Tbia.End_Date, Sysdate))
                                           And Trunc(Sysdate) Between Bias.Begin_Date And
                                               Trunc(Nvl(Bias.End_Date, Sysdate))
                                           And Oio.Entity_Id = p_Entity_Id
                                           And Tii.Inventory_Id = Oio.Inventory_Id
                                           And Tii.Inventory_Type = '01'
                                           And Tii.Base_Flag = 'Y'
                                         Group By Bias.Item_Id,
                                                  Tii.Inventory_Id,
                                                  Nvl(Bias.Quantity, 1)
                                        Union All
                                        --套件采购退货
                                        Select Bias.Item_Id,
                                               i.Inventory_Id,
                                               0 Qoh1,
                                               0 Occupy_Qty,
                                               Trunc(Sum(Decode(o.Po_Status,
                                                                p_Entity_Id,
                                                                Nvl(l.Billed_Qty, 0),
                                                                Nvl(l.Shipped_Qty, 0))) /
                                                     Nvl(Bias.Quantity, 1)) Po_Qty
                                          From t_Inv_Po_Headers         o,
                                               t_Inv_Po_Lines           l,
                                               t_Inv_Bill_Types         t,
                                               t_Inv_Inventories        i,
                                               t_Bd_Item_Assemblies     Tbia,
                                               t_Bd_Item_Assemblies_Sub Bias,
                                               t_Inv_Bill_Types         Ibt,
                                               t_Inv_Transaction_Types  Itt
                                         Where Tbia.Item_Id = r_Collect_Line.Item_Id
                                           And Tbia.Entity_Id = p_Entity_Id
                                           And Bias.Item_Assembly_Id = Tbia.Item_Assembly_Id
                                           And Trunc(Sysdate) Between Tbia.Begin_Date And
                                               Trunc(Nvl(Tbia.End_Date, Sysdate))
                                           And Trunc(Sysdate) Between Bias.Begin_Date And
                                               Trunc(Nvl(Bias.End_Date, Sysdate))
                                           And t.Bill_Type_Id = o.Po_Type_Id
                                           And t.Entity_Id = o.Entity_Id
                                           And l.Po_Id = o.Po_Id
                                           And Nvl(o.Source_Type, '_') != '工单入库'
                                           And Nvl(o.Close_Flag, 'N') != 'Y'
                                           And i.Inventory_Id = o.Inv_Finance_Id
                                           And i.Entity_Id = o.Entity_Id
                                           And Trunc(o.Billed_Date) >= Trunc(Sysdate - 30)
                                           And o.Po_Status <> '14' --执行
                                           And o.Entity_Id = p_Entity_Id
                                           And l.Item_Id = Bias.Item_Id
                                          --采购单红冲出库的单据才纳入现有量计算
                                           And Ibt.Transaction_Type_Id = Itt.Transaction_Type_Id
                                           And Itt.Action_Type = '02'
                                           And Ibt.Bill_Type_Id = o.Po_Type_Id
                                           And i.Inventory_Type = '01'
                                           And i.Base_Flag = 'Y'
                                         Group By Bias.Item_Id,
                                                  i.Inventory_Id,
                                                  Nvl(Bias.Quantity, 1)) Qoh1
                                 Group By Qoh1.Inventory_Id, Qoh1.Item_Id)
                         Group By Inventory_Id)),
                0))
       Where Ocs.Order_Collect_Head_Id = p_Order_Collect_Id
         And Ocs.Order_Collect_Line_Id = r_Collect_Line.Coll_Ord_Line_Id;

      --更新中心仓库存
      Update t_Pln_Order_Collect_Show Ocs
         Set Ocs.Last_Updated_By = p_User_Code,
             Ocs.Last_Update_Date = Sysdate,
             Ocs.All_Inv_Qty =
             (Nvl((Select Sum(Tio.Quantity) Qoh1
                  From t_Inv_Onhand Tio, t_Inv_Inventories Tii
                 Where Tio.Item_Id = r_Collect_Line.Item_Id
                   And Tio.Inventory_Id = Tii.Inventory_Id
                   And Tii.Inventory_Type = '01'
                   And (Tii.Sales_Center_Flag = 'Y' Or
                        Tii.Base_Flag = 'Y')
                   And Tio.Entity_Id = p_Entity_Id
                 Group By Tio.Item_Id),
                0) -
           --散件库存占用量
           Nvl((Select Sum(Nvl(Oio.Stock_Affirm_Qty, 0) +
                           Nvl(Oio.Supply_Qty, 0) -
                           Nvl(Oio.So_Order_Qty, 0) -
                           Nvl(Oio.Sundry_Qty, 0)) Occupyqty
                  From t_Pln_Order_Inv_Occupy Oio, t_Inv_Inventories Tii
                 Where Oio.Entity_Id = p_Entity_Id
                   And Oio.Item_Id = r_Collect_Line.Item_Id
                   And Tii.Inventory_Id = Oio.Inventory_Id
                   And Tii.Inventory_Type = '01'
                   And (Tii.Sales_Center_Flag = 'Y' Or
                        Tii.Base_Flag = 'Y')
                 Group By Oio.Item_Id),
                0) -
           --散件采购退货
           Nvl((Select Sum(Decode(o.Po_Status,
                                  p_Entity_Id,
                                  Nvl(l.Billed_Qty, 0),
                                  Nvl(l.Shipped_Qty, 0))) Po_Qty
                  From t_Inv_Po_Headers        o,
                       t_Inv_Po_Lines          l,
                       t_Inv_Bill_Types        t,
                       t_Inv_Inventories       i,
                       t_Inv_Bill_Types        Ibt,
                       t_Inv_Transaction_Types Itt
                 Where t.Bill_Type_Id = o.Po_Type_Id
                   And t.Entity_Id = o.Entity_Id
                   And l.Po_Id = o.Po_Id
                   And Nvl(o.Source_Type, '_') != '工单入库'
                   And i.Inventory_Id = o.Inv_Finance_Id
                   And i.Entity_Id = o.Entity_Id
                   And Trunc(o.Billed_Date) >= Trunc(Sysdate - 30)
                   And o.Po_Status <> '14' --执行
                   And Nvl(o.Close_Flag, 'N') != 'Y'
                   And o.Entity_Id = p_Entity_Id
                   And (i.Sales_Center_Flag = 'Y' Or
                        i.Base_Flag = 'Y')
                   And i.Inventory_Type = '01'
                   And l.Item_Id = r_Collect_Line.Item_Id
                      --采购单红冲出库的单据才纳入现有量计算
                   And Ibt.Transaction_Type_Id = Itt.Transaction_Type_Id
                   And Itt.Action_Type = '02'
                   And Ibt.Bill_Type_Id = o.Po_Type_Id
                 Group By l.Item_Id),
                0) +
           --套件可用量
           Nvl((Select Sum(Qoh1) Qoh1
                  From (Select Inventory_Id, Min(Qoh1) Qoh1
                          From (Select Qoh1.Inventory_Id,
                                       Qoh1.Item_Id,
                                       Sum(Nvl(Qoh1, 0) - Nvl(Occupy_Qty, 0) -
                                           Nvl(Po_Qty, 0)) Qoh1
                                  From (Select Bias.Item_Id,
                                               Tii.Inventory_Id,
                                               0                Qoh1,
                                               0                Occupy_Qty,
                                               0                Po_Qty
                                          From t_Bd_Item_Assemblies     Tbia,
                                               t_Bd_Item_Assemblies_Sub Bias,
                                               t_Inv_Inventories        Tii
                                         Where Tbia.Item_Id = r_Collect_Line.Item_Id
                                           And Tbia.Entity_Id = p_Entity_Id
                                           And Tii.Inventory_Type = '01'
                                           And Tii.Entity_Id = p_Entity_Id
                                           And (Tii.Sales_Center_Flag = 'Y' Or
                                                Tii.Base_Flag = 'Y')
                                           And Bias.Item_Assembly_Id = Tbia.Item_Assembly_Id
                                           And Trunc(Sysdate) Between Tbia.Begin_Date And
                                               Trunc(Nvl(Tbia.End_Date, Sysdate))
                                           And Trunc(Sysdate) Between Bias.Begin_Date And
                                               Trunc(Nvl(Bias.End_Date, Sysdate))
                                         Group By Bias.Item_Id,
                                                  Tii.Inventory_Id,
                                                  Nvl(Bias.Quantity, 1)
                                        Union All
                                        --套件现有库存量
                                        Select Bias.Item_Id,
                                               Tii.Inventory_Id,
                                               Trunc(Sum(Nvl(Tio.Quantity, 0)) /
                                                     Nvl(Bias.Quantity, 1)) Qoh1,
                                               0 Occupy_Qty,
                                               0 Po_Qty
                                          From t_Inv_Onhand             Tio,
                                               t_Bd_Item_Assemblies     Tbia,
                                               t_Bd_Item_Assemblies_Sub Bias,
                                               t_Inv_Inventories        Tii
                                         Where Tbia.Item_Id = r_Collect_Line.Item_Id
                                           And Tbia.Entity_Id = p_Entity_Id
                                           And Bias.Item_Assembly_Id = Tbia.Item_Assembly_Id
                                           And Trunc(Sysdate) Between Tbia.Begin_Date And
                                               Trunc(Nvl(Tbia.End_Date, Sysdate))
                                           And Trunc(Sysdate) Between Bias.Begin_Date And
                                               Trunc(Nvl(Bias.End_Date, Sysdate))
                                           And Tio.Item_Id = Bias.Item_Id
                                           And Tio.Entity_Id = p_Entity_Id
                                           And Tii.Inventory_Id = Tio.Inventory_Id
                                           And Tii.Inventory_Type = '01'
                                           And (Tii.Sales_Center_Flag = 'Y' Or
                                                Tii.Base_Flag = 'Y')
                                         Group By Bias.Item_Id,
                                                  Tii.Inventory_Id,
                                                  Nvl(Bias.Quantity, 1)
                                        Union All
                                        --套件现占用量
                                        Select Bias.Item_Id,
                                               Tii.Inventory_Id,
                                               0 Qoh1,
                                               Trunc(Sum(Nvl(Oio.Stock_Affirm_Qty, 0) +
                                                         Nvl(Oio.Supply_Qty, 0) -
                                                         Nvl(Oio.So_Order_Qty, 0) -
                                                         Nvl(Oio.Sundry_Qty, 0)) /
                                                     Nvl(Bias.Quantity, 1)) Occupy_Qty,
                                               0 Po_Qty
                                          From t_Pln_Order_Inv_Occupy   Oio,
                                               t_Bd_Item_Assemblies     Tbia,
                                               t_Bd_Item_Assemblies_Sub Bias,
                                               t_Inv_Inventories        Tii
                                         Where Tbia.Item_Id = r_Collect_Line.Item_Id
                                           And Tbia.Entity_Id = p_Entity_Id
                                           And Bias.Item_Id = Oio.Item_Id
                                           And Bias.Entity_Id = Oio.Entity_Id
                                           And Tbia.Entity_Id = Oio.Entity_Id
                                           And Bias.Item_Assembly_Id = Tbia.Item_Assembly_Id
                                           And Trunc(Sysdate) Between Tbia.Begin_Date And
                                               Trunc(Nvl(Tbia.End_Date, Sysdate))
                                           And Trunc(Sysdate) Between Bias.Begin_Date And
                                               Trunc(Nvl(Bias.End_Date, Sysdate))
                                           And Oio.Entity_Id = p_Entity_Id
                                           And Tii.Inventory_Id = Oio.Inventory_Id
                                           And Tii.Inventory_Type = '01'
                                           And (Tii.Sales_Center_Flag = 'Y' Or
                                                Tii.Base_Flag = 'Y')
                                         Group By Bias.Item_Id,
                                                  Tii.Inventory_Id,
                                                  Nvl(Bias.Quantity, 1)
                                        Union All
                                        --套件采购退货
                                        Select Bias.Item_Id,
                                               i.Inventory_Id,
                                               0 Qoh1,
                                               0 Occupy_Qty,
                                               Trunc(Sum(Decode(o.Po_Status,
                                                                p_Entity_Id,
                                                                Nvl(l.Billed_Qty, 0),
                                                                Nvl(l.Shipped_Qty, 0))) /
                                                     Nvl(Bias.Quantity, 1)) Po_Qty
                                          From t_Inv_Po_Headers         o,
                                               t_Inv_Po_Lines           l,
                                               t_Inv_Bill_Types         t,
                                               t_Inv_Inventories        i,
                                               t_Bd_Item_Assemblies     Tbia,
                                               t_Bd_Item_Assemblies_Sub Bias,
                                               t_Inv_Bill_Types         Ibt,
                                               t_Inv_Transaction_Types  Itt
                                         Where Tbia.Item_Id = r_Collect_Line.Item_Id
                                           And Tbia.Entity_Id = p_Entity_Id
                                           And Bias.Item_Assembly_Id = Tbia.Item_Assembly_Id
                                           And Trunc(Sysdate) Between Tbia.Begin_Date And
                                               Trunc(Nvl(Tbia.End_Date, Sysdate))
                                           And Trunc(Sysdate) Between Bias.Begin_Date And
                                               Trunc(Nvl(Bias.End_Date, Sysdate))
                                           And t.Bill_Type_Id = o.Po_Type_Id
                                           And t.Entity_Id = o.Entity_Id
                                           And l.Po_Id = o.Po_Id
                                           And Nvl(o.Source_Type, '_') != '工单入库'
                                           And Nvl(o.Close_Flag, 'N') != 'Y'
                                           And i.Inventory_Id = o.Inv_Finance_Id
                                           And i.Entity_Id = o.Entity_Id
                                           And Trunc(o.Billed_Date) >= Trunc(Sysdate - 30)
                                           And o.Po_Status <> '14' --执行
                                           And o.Entity_Id = p_Entity_Id
                                           And l.Item_Id = Bias.Item_Id
                                          --采购单红冲出库的单据才纳入现有量计算
                                           And Ibt.Transaction_Type_Id = Itt.Transaction_Type_Id
                                           And Itt.Action_Type = '02'
                                           And Ibt.Bill_Type_Id = o.Po_Type_Id
                                           And i.Inventory_Type = '01'
                                           And (i.Sales_Center_Flag = 'Y' Or
                                                i.Base_Flag = 'Y')
                                         Group By Bias.Item_Id,
                                                  i.Inventory_Id,
                                                  Nvl(Bias.Quantity, 1)) Qoh1
                                 Group By Qoh1.Inventory_Id, Qoh1.Item_Id)
                         Group By Inventory_Id)),
                0))
       Where Ocs.Order_Collect_Head_Id = p_Order_Collect_Id
         And Ocs.Order_Collect_Line_Id = r_Collect_Line.Coll_Ord_Line_Id;
    End Loop;

  Exception
    When v_Base_Exception Then
      p_Result := p_Result;
      Rollback;
    When Others Then
      p_Result := '更新失败：' || Sqlerrm;
      Rollback;
  End;
  
  ----------------------------------------------------------------------------------
  --Author: hejy3
  --CreateDate: 2016-08-27
  --Purpose: 汇总订单完成订单承诺更新承诺日期
  ----------------------------------------------------------------------------------
  Procedure p_Upd_Pln_Lg_Promise_Date(p_Order_Collect_Id In Number,
                                      p_Entity_Id        In Number,
                                      p_User_Code        In Varchar2,
                                      p_Result           Out Varchar2)
  IS
    r_Collect_Head t_pln_order_collect_head%ROWTYPE;
    V_PERIOD_END_DATE DATE; --20160914 hejy3 周期最后一天
  BEGIN
    p_Result := v_Success;
    
    --锁定汇总订单头
    Begin
      Select *
        Into r_Collect_Head
        From t_Pln_Order_Collect_Head Ch
       Where Ch.Coll_Ord_Head_Id = p_Order_Collect_Id
         And Ch.Entity_Id = p_Entity_Id
         For Update Nowait ;
    Exception
      When Others Then
        p_Result := '锁定汇总订单头表失败。' || v_Nl || '汇总头ID：' ||
                    To_Char(p_Order_Collect_Id) || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;
    
    --20160914 hejy3 获取周期最后一天
    SELECT P.END_DATE INTO V_PERIOD_END_DATE
      FROM T_PLN_ORDER_PERIOD P
     WHERE P.PERIOD_ID = r_Collect_Head.Period_Id;
    
    --更新全部库存评审订单行订单承诺日期和承诺日期（带清尾）
    UPDATE T_PLN_ORDER_LINE L
       SET (L.APS_PROMISE_TIME, L.PROMISE_DATE_BY_MANTISSA) =
           (SELECT P.END_DATE, P.END_DATE
              FROM T_PLN_ORDER_PERIOD P
             WHERE P.PERIOD_ID = R_COLLECT_HEAD.PERIOD_ID)
     WHERE L.CAN_PRODUCE_QTY = 0
       AND EXISTS
     (SELECT 1
              FROM T_PLN_ORDER_COLLECT_RELATION R
             WHERE R.ORDER_COLLECT_HEAD_ID = R_COLLECT_HEAD.COLL_ORD_HEAD_ID
               AND R.ORDER_LINE_ID = L.ORDER_LINE_ID);
    
    --更新提货订单行承诺日期（带清尾）
    UPDATE T_PLN_LG_ORDER_LINE L
       SET L.PROMISE_DATE_BY_MANTISSA =
           (SELECT OL.PROMISE_DATE_BY_MANTISSA
              FROM T_PLN_LG_RELATION LR, T_PLN_ORDER_LINE OL
             WHERE LR.ORDER_LINE_ID = OL.ORDER_LINE_ID
               AND LR.LG_ORDER_LINE_ID = L.ORDER_LINE_ID
               AND OL.Producing_Area_Id = L.PRODUCING_AREA_ID),
           --20160914 hejy3 更新提货订单行承诺日期，为空则取周期最后一天
           L.APS_PROMISE_DATE =
           (SELECT NVL(OL.PROMISE_DATE_BY_MANTISSA, V_PERIOD_END_DATE+1)
              FROM T_PLN_LG_RELATION LR, T_PLN_ORDER_LINE OL
             WHERE LR.ORDER_LINE_ID = OL.ORDER_LINE_ID
               AND LR.LG_ORDER_LINE_ID = L.ORDER_LINE_ID
               AND OL.PRODUCING_AREA_ID = L.PRODUCING_AREA_ID),
           L.LAST_UPDATED_BY = p_User_Code,
           L.LAST_UPDATE_DATE = SYSDATE,
           L.VERSION = NVL(L.VERSION, 0) + 1
     WHERE EXISTS
     (SELECT 1
              FROM T_PLN_LG_RELATION R, T_PLN_ORDER_COLLECT_RELATION CR
             WHERE R.LG_ORDER_LINE_ID = L.ORDER_LINE_ID
               AND R.ORDER_LINE_ID = CR.ORDER_LINE_ID
               AND CR.ORDER_COLLECT_HEAD_ID =
                   R_COLLECT_HEAD.COLL_ORD_HEAD_ID
               AND CR.ENTITY_ID = R_COLLECT_HEAD.ENTITY_ID);
  Exception
    When v_Base_Exception Then
      p_Result := p_Result;
      Rollback;
    When Others Then
      p_Result := '更新失败：' || Sqlerrm;
      Rollback;
  END p_Upd_Pln_Lg_Promise_Date;
End Pkg_Pln_Order_Collect;
/

