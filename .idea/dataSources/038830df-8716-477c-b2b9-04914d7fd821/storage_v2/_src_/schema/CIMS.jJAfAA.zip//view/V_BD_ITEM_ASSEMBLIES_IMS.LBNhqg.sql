create view V_BD_ITEM_ASSEMBLIES_IMS as
select a.item_code        product_assembly_code,
       a.item_name        product_assembly_name,
       a.priority         priority,
       b.item_code        product_sub_code,
       b.item_name        product_sub_name,
       b.value_scale,
       b.fittings_flag,
       b.quantity,
       a.ENTITY_ID,
       a.begin_date,
       a.end_date,
       a.created_by,
       a.creation_date,
       a.last_updated_by,
       a.last_update_date,
       b.begin_date       begin_date_sub,
       b.end_date         end_date_sub,
       b.created_by       created_by_sub,
       b.creation_date    creation_date_sub,
       b.last_updated_by  last_updated_by_sub,
       b.last_update_date last_update_date_sub
  from T_BD_ITEM_ASSEMBLIES a, t_Bd_Item_Assemblies_Sub b
 where a.item_assembly_id = b.item_assembly_id
/

