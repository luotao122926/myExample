create PACKAGE BODY PKG_PMT_PLAN_CCS IS

  ----------------------------------------------------------------------
  -- Author  : liyuanji
  -- Created : 2015-08-01
  -- Purpose : 推广物料月需求计划接口（CCS）
  --1、C-IMS对CCS同步过来的月计划订单进行校验，有一行失败则整张订单都失败。
  --2、C-IMS将校验结果记录接口状态，同时记录错误信息。CCS根据接口状态进行后续处理，如校验失败CCS可根据错误信息修正后重新写接口表。
  ----------------------------------------------------------------------
    PROCEDURE P_INTF_PMT_PLAN( I_PLAN_HEAD_ID         IN NUMBER, --接口头ID
                               O_RESULT               OUT Varchar2, --返回错误码
                               O_RESULT_MSG           OUT Varchar2 --成功则返回“SUCCESS”，否则返回出错信息
                               ) Is
    V_PMT_PLAN_HEAD_SEQ      NUMBER; --计划头表序列
    V_PMT_PLAN_LINE_SEQ      NUMBER; --计划行表序列

  --  V_ENTITY_ID              Number; --主体
    V_SALES_CENTER_CODE      VARCHAR2(100);--营销中心编码
    V_SALES_CENTER_NAME      VARCHAR2(240);--营销中心名称
    V_CUSTOMER_CODE          VARCHAR2(100);--客户编码
    V_CUSTOMER_NAME          VARCHAR2(100);--客户名称

    V_PLAN_NUM               VARCHAR2(32);--客户名称
    V_PMT_CODE               VARCHAR2(100);--
    V_PMT_NAME               VARCHAR2(100);--


  --  V_LINES_COUNT            NUMBER; --接口行表记录数
    V_HEAD_COUNT             NUMBER; --接口头表信息
    V_LINE_COUNT             NUMBER; --接口行表信息
    V_BIZ_EXCEPTION          EXCEPTION; --自定义业务异常


   --查询计划接口头表信息
   CURSOR C_INTF_PMT_PLAN_HEAD IS
      SELECT *
        From INTF_PMT_PLAN_HEAD H
       WHERE H.INTF_STATS = '01'
       And H.INTF_PLAN_HEAD_ID= I_PLAN_HEAD_ID;

   HEAD_ROW  C_INTF_PMT_PLAN_HEAD%ROWTYPE; --接口表收款头游标行数据

    --计划接口行表信息
    CURSOR C_INTF_PMT_PLAN_LINES  IS
      SELECT *
        FROM INTF_PMT_PLAN_LINES L
       Where L.INTF_PLAN_HEAD_ID = I_PLAN_HEAD_ID ;--HEAD_ROW.INTF_PLAN_HEAD_ID ;

   LINE_ROW  C_INTF_PMT_PLAN_LINES%ROWTYPE; --接口表行游标行数据

 BEGIN
    O_RESULT     := '1';
    O_RESULT_MSG := 'SUCCESS';


   --获取头表信息

    SELECT COUNT(*)
      INTO V_HEAD_COUNT
      FROM INTF_PMT_PLAN_HEAD H
      WHERE H.INTF_STATS = '01';

     IF(V_HEAD_COUNT>0) THEN

      FOR HEAD_ROW IN  C_INTF_PMT_PLAN_HEAD Loop

        --校验收款单接口数据:必填项
        IF HEAD_ROW.INTF_PLAN_HEAD_ID IS NULL THEN
          O_RESULT_MSG := '接口头ID为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.SALES_CENTER_ID IS NULL THEN
          O_RESULT_MSG := '营销中心ID为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.SALES_CENTER_CODE IS NULL THEN
          O_RESULT_MSG := '营销中心编码为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.SALES_CENTER_NAME IS NULL THEN
          O_RESULT_MSG := '营销中心名称为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.CUSTOMER_ID IS NULL THEN
          O_RESULT_MSG := '客户ID为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.CUSTOMER_CODE IS NULL THEN
          O_RESULT_MSG := '客户编码为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.CUSTOMER_NAME IS NULL THEN
          O_RESULT_MSG := '客户名称为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.STATUS IS NULL THEN
          O_RESULT_MSG := '单据状态为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.ENTITY_ID IS NULL THEN
          O_RESULT_MSG := '主体ID为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.CREATED_BY IS NULL THEN
          O_RESULT_MSG := '创建人为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.CREATION_DATE IS NULL THEN
          O_RESULT_MSG := '创建日期为空';
          RAISE V_BIZ_EXCEPTION;
   --     ELSIF HEAD_ROW.SALES_MAIN_TYPE IS NULL THEN
    --      O_RESULT_MSG := '营销大类为空';
    --      RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.YEAR IS NULL THEN
          O_RESULT_MSG := '年度为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.MONTH IS NULL THEN
          O_RESULT_MSG := '月份为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.SOURCE_CCS_ID IS NULL THEN
          O_RESULT_MSG := 'CCS单据id为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.SOURCE_CCS_NUM IS NULL THEN
          O_RESULT_MSG := 'CCS单据号为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.INTF_STATS IS NULL THEN
          O_RESULT_MSG := '接口状态为空';
          RAISE V_BIZ_EXCEPTION;
        END IF;

    --检测营销中心编码
     BEGIN
       SELECT U.CODE, U.NAME
          INTO V_SALES_CENTER_CODE, V_SALES_CENTER_NAME
          FROM UP_ORG_UNIT U
         WHERE U.UNIT_ID = HEAD_ROW.SALES_CENTER_ID
           AND U.ACTIVE_FLAG = 'T';
    EXCEPTION
      WHEN OTHERS THEN
        O_RESULT_MSG := '[营销中心ID：' || HEAD_ROW.SALES_CENTER_ID || ']不存在，请检查！';
        RAISE V_BIZ_EXCEPTION;
      END;

     --检查客户信息
     BEGIN
        SELECT CUSTOMER_CODE,CUSTOMER_NAME
          INTO V_CUSTOMER_CODE,V_CUSTOMER_NAME
        FROM T_CUSTOMER_HEADER CH
        WHERE CH.CUSTOMER_ID= HEAD_ROW.CUSTOMER_ID
        AND   CH.ACTIVE_FLAG='Active';  ---测试暂时注释掉
      EXCEPTION
        WHEN OTHERS THEN
        O_RESULT_MSG := '[客户ID：' || HEAD_ROW.CUSTOMER_ID || ']已失效，请检查！';
        RAISE V_BIZ_EXCEPTION;
      END;

      --单据号

         V_PLAN_NUM  :=  'P'|| PKG_BD.F_GET_BILL_NO(P_BILL_TYPE  => 'PMTPLANNUM',
                                   P_PREFIX_ADD => NULL,
                                   P_ENTITY_ID  => HEAD_ROW.ENTITY_ID,
                                   P_USER_ID    => NULL);

   --  接口头表数据插入正式表

         --获取序列
            SELECT S_PMT_PLAN_HEAD.NEXTVAL
              INTO V_PMT_PLAN_HEAD_SEQ
              FROM DUAL;
       BEGIN
        INSERT INTO T_PMT_PLAN_HEAD(
        PLAN_HEAD_ID,
        SALES_CENTER_ID,
        SALES_CENTER_CODE,
        SALES_CENTER_NAME,
        CUSTOMER_ID,
        CUSTOMER_CODE,
        CUSTOMER_NAME,
        STATUS,
        ENTITY_ID,
        CREATED_BY,
        CREATION_DATE,
        LAST_UPDATED_BY,
        LAST_UPDATED_DATE,
        SALES_MAIN_TYPE,
        YEAR,
        MONTH,
        PLAN_NUM,
        SOURCE_CCS_NUM
        )
    VALUES(
        V_PMT_PLAN_HEAD_SEQ,
        HEAD_ROW.SALES_CENTER_ID, --营销中心ID
        V_SALES_CENTER_CODE,
        V_SALES_CENTER_NAME,
       -- HEAD_ROW.SALES_CENTER_CODE, --营销中心编码
       -- HEAD_ROW.SALES_CENTER_NAME,
        HEAD_ROW.CUSTOMER_ID,
        V_CUSTOMER_CODE,
        V_CUSTOMER_NAME,
       -- HEAD_ROW.CUSTOMER_CODE,
       -- HEAD_ROW.CUSTOMER_NAME,
        '00',--制单状态为00
        HEAD_ROW.ENTITY_ID,
        'PKG_PMT_PLAN_CCS',
        Sysdate,
        'PKG_PMT_PLAN_CCS',
        Sysdate,
        HEAD_ROW.SALES_MAIN_TYPE,
        HEAD_ROW.YEAR,
        HEAD_ROW.MONTH,
        V_PLAN_NUM,
        HEAD_ROW.SOURCE_CCS_NUM
    );
      EXCEPTION
          WHEN OTHERS THEN
            O_RESULT_MSG := PKG_BD.F_ADD_ERROR_LOG('PKG_PMT_PLAN_CCS.P_INTF_PMT_PLAN',
                                                SQLCODE,
                                                'CCS月需求计划录入，接口表头数据插入业务表失败！：' ||
                                                SQLERRM || SUBSTR(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, 1, 100));
            RAISE V_BIZ_EXCEPTION;
        END;

        --检查行表是否有数据
         SELECT COUNT(*)
            INTO V_LINE_COUNT
            FROM INTF_PMT_PLAN_LINES L
           WHERE L.INTF_PLAN_HEAD_ID = I_PLAN_HEAD_ID;

       --遍历接口表行数据，插入收款行表
        IF V_LINE_COUNT > 0 THEN
          FOR LINE_ROW IN C_INTF_PMT_PLAN_LINES Loop

                  --校验收款单接口数据:必填项
        IF LINE_ROW.PMT_ID IS NULL THEN
          O_RESULT_MSG := '推广物料ID为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF LINE_ROW.PMT_CODE IS NULL THEN
          O_RESULT_MSG := '推广物料CODE为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF LINE_ROW.PMT_NAME IS NULL THEN
          O_RESULT_MSG := '推广物料名称为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF LINE_ROW.UNIT IS NULL THEN
          O_RESULT_MSG := '推广物料单位为空';
          RAISE V_BIZ_EXCEPTION;
      --  ELSIF LINE_ROW.PMT_PRICE IS NULL Then
      --    O_RESULT_MSG := '推广物料单价为空';
      --    RAISE V_BIZ_EXCEPTION;
        ELSIF LINE_ROW.APPLY_QTY IS NULL THEN
          O_RESULT_MSG := '申请数量为空';
          RAISE V_BIZ_EXCEPTION;
        END IF;

    --检查是否为推广物料
     BEGIN
        SELECT ITEM_CODE,ITEM_NAME
          INTO V_PMT_CODE,V_PMT_NAME
         FROM T_BD_ITEM T
         WHERE T.ITEM_CODE = LINE_ROW.PMT_CODE
         And T.IS_MATERIAL='Y'
         AND T.ACTIVE_FLAG ='Y';
      EXCEPTION
        WHEN OTHERS THEN
        O_RESULT_MSG := '[推广物料：' || LINE_ROW.PMT_CODE || ']不存在，请检查！';
        RAISE V_BIZ_EXCEPTION;
      END;

        --获取行序列
        SELECT S_PMT_PLAN_LINE.NEXTVAL
          INTO V_PMT_PLAN_LINE_SEQ
          FROM DUAL;

            BEGIN
              INSERT INTO T_PMT_PLAN_LINES
                (PLAN_LINE_ID,
                 PLAN_HEAD_ID,
                 PMT_ID,
                 PMT_CODE,
                 PMT_NAME,
                 UNIT,
                 PMT_PRICE,
                 APPLY_QTY)
              VALUES
                (V_PMT_PLAN_LINE_SEQ,
                 V_PMT_PLAN_HEAD_SEQ,
                 LINE_ROW.PMT_ID,
                 V_PMT_CODE,
                 V_PMT_NAME,
                 LINE_ROW.UNIT,
                 LINE_ROW.PMT_PRICE,
                 LINE_ROW.APPLY_QTY);
            EXCEPTION
              WHEN OTHERS THEN
                O_RESULT_MSG := PKG_BD.F_ADD_ERROR_LOG('PKG_PMT_PLAN_CCS.P_INTF_PMT_PLAN',
                                                        SQLCODE,
                                                       'CCS月需求计划录入，接口表行数据插入业务表失败！：' ||
                                                        SQLERRM || SUBSTR(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, 1, 100));
                RAISE V_BIZ_EXCEPTION;
            END;
          END LOOP;
        END IF;

         --插入业务表成功，回写接口表数据
        BEGIN
          UPDATE INTF_PMT_PLAN_HEAD H
             SET H.INTF_STATS = '02',--'02'校验通过（由C-IMS更新）
                 H.ERROR_MESSAGE = 'SUCCESS',
                 H.LAST_UPDATED_BY = 'CIMS',
                 H.PLAN_NUM = V_PLAN_NUM,
                 H.LAST_UPDATED_DATE = Sysdate
           WHERE H.INTF_PLAN_HEAD_ID= I_PLAN_HEAD_ID;
          O_RESULT_MSG := 'SUCCESS';
        EXCEPTION
          WHEN OTHERS THEN
            O_RESULT_MSG := PKG_BD.F_ADD_ERROR_LOG('PKG_PMT_PLAN_CCS.P_INTF_PMT_PLAN',
                                                    SQLCODE,
                                                   'CCS月需求计划录入，回写数据异常，更新接口表失败！：' ||
                                                    SQLERRM || SUBSTR(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, 1, 100));
            RAISE V_BIZ_EXCEPTION;
        END;
      END LOOP;

     ELSE
       O_RESULT_MSG := 'CCS录入接口表：INTF_PMT_PLAN_HEAD，查询不到数据！';
       RAISE V_BIZ_EXCEPTION;
     END IF;
  EXCEPTION
    WHEN OTHERS THEN
       --ROLLBACK;
      BEGIN
        UPDATE INTF_PMT_PLAN_HEAD C
           SET C.INTF_STATS       = '03',
               C.ERROR_MESSAGE   = O_RESULT_MSG,
               C.LAST_UPDATED_BY   = 'CIMS',
               C.PLAN_NUM = V_PLAN_NUM,
               C.LAST_UPDATED_DATE = Sysdate
         WHERE C.INTF_PLAN_HEAD_ID= I_PLAN_HEAD_ID;
        --COMMIT;
        O_RESULT_MSG := PKG_BD.F_ADD_ERROR_LOG('PKG_PMT_PLAN_CCS.P_INTF_PMT_PLAN',
                                                SQLCODE,
                                                O_RESULT_MSG || SQLERRM || SUBSTR(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, 1, 100));
      END;
 END;
END PKG_PMT_PLAN_CCS;
/

