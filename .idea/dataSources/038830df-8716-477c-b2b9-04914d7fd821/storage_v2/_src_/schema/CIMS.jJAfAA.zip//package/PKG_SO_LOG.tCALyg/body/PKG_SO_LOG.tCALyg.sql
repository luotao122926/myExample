create PACKAGE BODY PKG_SO_LOG IS
  PROCEDURE P_ACTION_LOG(P_TABLE_NAME     VARCHAR2, --操作表名称
                         P_ACTION_REMARKS VARCHAR2, --操作说明
                         P_PK             VARCHAR2, --关键主键
                         P_ISERR          NUMBER, --是否出错，1出错，0未出错
                         P_ERR_LINE       VARCHAR2, --错误跑出行数
                         P_MSG            VARCHAR2 --错误信息
                         ) AS
    PRAGMA AUTONOMOUS_TRANSACTION; --自治事务
  BEGIN
    INSERT INTO T_SO_TABLE_ACTION_LOG
      (ID,
       TABLE_NAME,
       ACTION_REMARKS,
       PK_NUM,
       ISERR,
       MSG,
       CREATED,
       ERR_LINE)
    VALUES
      (SYS_GUID(),
       P_TABLE_NAME,
       P_ACTION_REMARKS,
       P_PK,
       P_ISERR,
       P_MSG,
       SYSDATE,
       P_ERR_LINE);
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      NULL;
  END;
END PKG_SO_LOG;
/

