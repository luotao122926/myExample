create PACKAGE BODY      PKG_SO_INFT_CCS IS

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-06-11
  *     创建者：周建刚
  *   功能说明：引入退货申请单到CIMS (目前用在CCS 、电商)
      退货申请引入步骤：（1）直接写CIMS的接口表；（2）然后调用该储存过程的方法，在CIMS生成退货申请单。
  */  
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_GEN_RETURN_APPLY_ENTRY(
                                    P_APPLY_HEADER_ID         IN  NUMBER, --退货申请单接口表头ID
                                    P_SYS_SOURCE              IN VARCHAR2,--系统编码
                                    P_RESULT                  OUT NUMBER,
                                    P_ERR_MSG                 OUT VARCHAR2
                               ) IS
    
    CURSOR C_INTF_SO_RETURN_APPLY_LINE IS
      SELECT *
        FROM INTF_SO_RETURN_APPLY_LINE L
       WHERE L.APPLY_HEADER_ID = P_APPLY_HEADER_ID;
    R_INTF_SO_RETURN_APPLY_LINE C_INTF_SO_RETURN_APPLY_LINE%ROWTYPE;
    
    R_INTF_SO_RETURN_APPLY_HEADER INTF_SO_RETURN_APPLY_HEADER%ROWTYPE;
    R_SO_RETURN_APPLY_HEADER T_SO_RETURN_APPLY_HEADER%ROWTYPE;              --退货申请头记录
    P_RETURN_TOTAL_AMOUNT    NUMBER := 0; --行退货金额
    V_RETURN_TOTAL_AMOUNT    NUMBER := 0; --头退货总金额
  BEGIN
    P_RESULT  := PKG_SO_PUB.V_RESULT;
    P_ERR_MSG := PKG_SO_PUB.V_SUCCESS;
    
    --锁定接口头表
    BEGIN
      SELECT *
        INTO R_INTF_SO_RETURN_APPLY_HEADER
        FROM INTF_SO_RETURN_APPLY_HEADER H
       WHERE H.APPLY_HEADER_ID = P_APPLY_HEADER_ID
         AND H.INTF_STATUS = V_STATUS_INIT
         AND H.SYS_SOURCE = P_SYS_SOURCE
         FOR UPDATE NOWAIT;
    EXCEPTION
      WHEN OTHERS THEN
        P_RESULT  := -58001;
        P_ERR_MSG := '锁定退货申请接口头表失败！' || SQLERRM;
    END;
    PKG_SO_PUB.P_EXCEPTION_THROWS(P_RESULT);
    
    --单据头ID
    SELECT S_SO_RETURN_APPLY_HEADER.NEXTVAL INTO R_SO_RETURN_APPLY_HEADER.APPLY_HEADER_ID FROM DUAL;
    --附件ID
    SELECT S_AR_RP_APPENDIX.NEXTVAL INTO R_SO_RETURN_APPLY_HEADER.APPENDIX_ID FROM DUAL;
    
    PKG_SO_INFT_CCS_HANDLE.P_SO_CREATE_APPLY_HEADER(R_INTF_SO_RETURN_APPLY_HEADER,R_SO_RETURN_APPLY_HEADER,P_RESULT,P_ERR_MSG);
    PKG_SO_PUB.P_EXCEPTION_THROWS(P_RESULT);
    
    --生成单据行记录
    OPEN C_INTF_SO_RETURN_APPLY_LINE;
    LOOP
      FETCH C_INTF_SO_RETURN_APPLY_LINE
        INTO R_INTF_SO_RETURN_APPLY_LINE;
      EXIT WHEN C_INTF_SO_RETURN_APPLY_LINE%NOTFOUND;
      
      P_RETURN_TOTAL_AMOUNT := 0;
      PKG_SO_INFT_CCS_HANDLE.P_SO_CREATE_APPLY_LINE(R_SO_RETURN_APPLY_HEADER,R_INTF_SO_RETURN_APPLY_LINE,P_RETURN_TOTAL_AMOUNT,P_RESULT,P_ERR_MSG);
      PKG_SO_PUB.P_EXCEPTION_THROWS(P_RESULT);
      --汇总每个产品行的退货金额
      V_RETURN_TOTAL_AMOUNT := V_RETURN_TOTAL_AMOUNT + P_RETURN_TOTAL_AMOUNT;
    END LOOP;
    
    --更新退货申请头表中的退货总金额
    UPDATE T_SO_RETURN_APPLY_HEADER H SET H.RETURN_TOTAL_AMOUNT = ROUND(V_RETURN_TOTAL_AMOUNT,2) WHERE H.APPLY_HEADER_ID = R_SO_RETURN_APPLY_HEADER.APPLY_HEADER_ID;
    
    --处理附件接口表信息
    PKG_SO_INFT_CCS_HANDLE.P_SO_RETURNAPPLY_APPENDIX(R_INTF_SO_RETURN_APPLY_HEADER,R_SO_RETURN_APPLY_HEADER,P_RESULT,P_ERR_MSG);
    PKG_SO_PUB.P_EXCEPTION_THROWS(P_RESULT);
    
    --将接口头表数据处理状态更新为‘已成功处理’
    UPDATE INTF_SO_RETURN_APPLY_HEADER H SET H.INTF_STATUS = V_STATUS_SUCESS,H.BILL_NUM = R_SO_RETURN_APPLY_HEADER.BILL_NUM WHERE H.APPLY_HEADER_ID = P_APPLY_HEADER_ID;
    
  EXCEPTION
    WHEN PKG_SO_PUB.V_BIZ_EXCEPTION THEN
      --将接口头表数据处理状态更新为‘处理处理失败’
      UPDATE INTF_SO_RETURN_APPLY_HEADER H SET H.INTF_STATUS = V_STATUS_FAIL WHERE H.APPLY_HEADER_ID = P_APPLY_HEADER_ID;

      P_RESULT  := -58001;
      P_ERR_MSG := '根据退货申请单接口头表[ID：' || P_APPLY_HEADER_ID ||
                   ']生成退货申请单出错！' || P_ERR_MSG;
      PKG_SO_LOG.P_ACTION_LOG(P_TABLE_NAME     => 'INTF_SO_RETURN_APPLY_HEADER',
                              P_ACTION_REMARKS => '退货申请单生成',
                              P_PK             => P_APPLY_HEADER_ID,
                              P_ISERR          => 1,
                              P_ERR_LINE       => DBMS_UTILITY.FORMAT_ERROR_BACKTRACE,
                              P_MSG            => P_ERR_MSG);
    WHEN OTHERS THEN
      --将接口头表数据处理状态更新为‘处理处理失败’
      UPDATE INTF_SO_RETURN_APPLY_HEADER H SET H.INTF_STATUS = V_STATUS_FAIL WHERE H.APPLY_HEADER_ID = P_APPLY_HEADER_ID;

      P_RESULT  := -58001;
      P_ERR_MSG := '生成退货申请单出错！' || SQLERRM;
      PKG_SO_LOG.P_ACTION_LOG(P_TABLE_NAME     => 'INTF_SO_RETURN_APPLY_HEADER',
                              P_ACTION_REMARKS => '退货申请单生成',
                              P_PK             => P_APPLY_HEADER_ID,
                              P_ISERR          => 1,
                              P_ERR_LINE       => DBMS_UTILITY.FORMAT_ERROR_BACKTRACE,
                              P_MSG            => P_ERR_MSG);
  END;
                           
END;
/

