create view LOGISTICS_DISPOSE_LINE_VIEW as
SELECT ROWNUM row_id, a.logistics_line_id, a.logistics_dispose_id,
          a.ship_inv_id, a.ship_inv_code, a.ship_inv_name, a.consignee_inv_id,
          a.consignee_inv_code, a.consignee_inv_name, a.source_status,
          a.target_status, b.item_id, a.item_code, a.item_name, a.uom,
          a.item_qty, a.created_by, a.creation_date, a.last_updated_by,
          a.last_update_date, c.class_code, c.class_name, d.unit_id, d.code,
          d.NAME
     FROM t_inv_logistics_dispose_line a,
          t_bd_item b,
          t_bd_item_class c,
          up_org_unit d,
          t_inv_inventories e
    WHERE a.item_code = b.item_code
      AND b.sales_main_type = c.class_code
      AND d.unit_id = e.unit_id
      AND e.inventory_id = a.ship_inv_id
/

