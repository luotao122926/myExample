create PACKAGE BODY PKG_INV_JOB IS

  v_Nl      Constant Varchar2(2) := Chr(13) || Chr(10); --换行
  v_Null    Constant Varchar2(4) := 'NULL'; --空值
  v_True    Constant Varchar2(2) := 'Y';
  v_False   Constant Varchar2(2) := 'N';
  v_Result  Constant Number := 0; --成功返回
  v_Success Constant Varchar2(10) := 'SUCCESS';
  v_Failure Constant Varchar2(10) := 'FAILURE';
  v_Base_Exception Exception; --自定义异常
  ------------------------------------------------------------------------------------------------
  -- Author  : 张开安 2018-10-25
  -- Purpose : 冻结产品库存现有量报表，每天凌晨执行一次。
  ------------------------------------------------------------------------------------------------
  PROCEDURE P_INV_FREEZE_ITEM_ONHAND(P_ENTITY_ID IN NUMBER,
                                     P_RESULT    OUT VARCHAR2) IS
  BEGIN
    P_RESULT := 'SUCCESS';
    INSERT INTO T_INV_ITEM_ONHAND_FREEZE F
      (F.FREEZE_ID,
       F.ENTITY_ID,
       F.INVENTORY_ID,
       F.INVENTORY_CODE,
       F.INVENTORY_NAME,
       F.INVENTORY_TYPE,
       F.SALES_CENTER_CODE,
       F.SALES_CENTER_NAME,
       F.ITEM_ID,
       F.ITEM_CODE,
       F.ITEM_NAME,
       F.UOM,
       F.PRODUCTFORM,
       F.ENERGYEFFRATIING,
       F.PRODUCTPHASE,
       F.BRAND,
       F.SALES_CHANNEL_TYPE,
       F.SALES_MAIN_TYPE,
       F.SALES_MAIN_TYPE_NAME,
       F.SALES_SUB_TYPE,
       F.SALES_SUB_TYPE_NAME,
       F.ON_HAND_QTY,
       F.RETENTION_QTY,
       F.USABLE_QTY,
       F.FREEZE_DATE)
      SELECT S_INV_ITEM_ONHAND_FREEZE.NEXTVAL,
             V.ENTITY_ID,
             V.INVENTORY_ID,
             V.INVENTORY_CODE,
             V.INVENTORY_NAME,
             V.INVENTORY_TYPE,
             V.CENTER_CODE,
             V.CENTER_NAME,
             V.ITEM_ID,
             V.ITEM_CODE,
             V.ITEM_NAME,
             V.UOM,
             V.PRODUCTFORM,
             V.ENERGYEFFRATIING,
             V.PRODUCTPHASE,
             V.BRAND,
             V.SALES_CHANNEL_TYPE,
             V.SALES_MAIN_NAME,
             V.SALES_MAIN_NAME,
             V.SALES_SUB_NAME,
             V.SALES_SUB_NAME,
             V.NUM1,
             V.NUM2,
             V.NUM3,
             SYSDATE
        FROM V_INV_REPORT_ITEM_ONHAND V
       WHERE V.ENTITY_ID = P_ENTITY_ID;
  EXCEPTION
    WHEN OTHERS THEN
      P_RESULT := '产品库存现有量报表冻结失败：' || SQLERRM;
  END;

------------------------------------------------------------------------------------------------
  -- Author  : huanghb12 2019-06-12
  -- Purpose : 处理同步仓库关系数据到ccs接口表。
  ------------------------------------------------------------------------------------------------
  PROCEDURE P_Handle_Syn_Area_Inv_Relation(P_ENTITY_ID IN NUMBER,              
                                           P_RESULT    OUT VARCHAR2) is
   v_Count                    Number;
   
  BEGIN
     p_Result        := v_Success;
     
   BEGIN
     
       --1、查询四级地址
     FOR DISTRICT_SET in(
          select distinct  t.row_id,t.district_code
            from t_bd_district t
           WHERE t.active_flag = 'Y'
           and t.level_seq = 5
           start with t.district_code in(
                 select distinct tr.district_code
                    from cims.intf_ccs_syn_area_inv_relation tr
                   WHERE tr.intf_status in ('N','E')
                   and tr.last_update_date > sysdate - 2
                   and tr.entity_id = P_ENTITY_ID
           )
          CONNECT BY prior t.ROW_ID = t.PAR_ROW_ID
        )Loop
          
        --插入及更新仓库列表id及code
          merge into cims.intf_ccs_syn_area_inv_detail ta
          using(
            SELECT p_entity_id entity_id,
               wmsys.wm_concat(inventory_id) inventory_id_list,
               wmsys.wm_concat(inventory_code) inventory_code_list,
               DISTRICT_SET.ROW_ID DISTRICT_ID,
               DISTRICT_SET.District_Code District_Code
              FROM (SELECT distinct r.inventory_id,
                                    r.inventory_code
                      FROM CIMS.T_INV_AREA_INVENTORY_RELATION R
                     WHERE R.DISTRICT_ID IN
                           (SELECT T1.ROW_ID
                              FROM T_BD_DISTRICT T1
                             START WITH T1.ROW_ID = DISTRICT_SET.ROW_ID
                            CONNECT BY PRIOR T1.PAR_ROW_ID = T1.ROW_ID)
                       AND R.ENTITY_ID = P_ENTITY_ID
                       AND R.IS_ACTIVE = 'Y')
            )tb on(ta.district_code = tb.district_code and ta.entity_id = tb.entity_id)
            WHEN MATCHED THEN
              update 
              set ta.intf_status = 'N'
              ,ta.inventory_id_list = tb.inventory_id_list
              ,ta.inventory_code_list = tb.inventory_code_list
              ,ta.error_flag = 'N'
              ,ta.error_msg = ''
              ,ta.last_updated_by = 'admin'
              ,ta.last_update_date = sysdate
             when not matched then
               INSERT
                (ta.INTF_ID,
                ta.INTF_STATUS ,
                ta.ENTITY_ID,
                ta.Inventory_Id_List ,
                ta.Inventory_Code_List ,
                ta.DISTRICT_ID ,
                ta.DISTRICT_CODE,
                ta.BATCH_CODE,
                ta.CREATED_BY,
                ta.LAST_UPDATED_BY)
              VALUES
                (S_INTF_CCS_SYN_AREA_INV_DETAIL.Nextval,
                 'N',
                 p_entity_id,
                 tb.inventory_id_list,
                 tb.inventory_code_list,
                 tb.DISTRICT_ID,
                 tb.DISTRICT_CODE,
                 null,
                 'admin',
                 'admin')
              ;
        END Loop;

     
     --3、更新接口表
      update cims.intf_ccs_syn_area_inv_relation tr
        set tr.intf_status = 'S'
        ,tr.error_flag = 'N'
        ,tr.error_msg = ''
        ,tr.last_updated_by = 'admin_job'
        ,tr.last_update_date = sysdate
        WHERE tr.intf_status in ('N','E')
         and tr.entity_id = P_ENTITY_ID
         and tr.last_update_date > sysdate - 2;
    
    Exception
       When Others Then
         p_Result := '仓库与区域关系数据处理失败' || v_Nl ||Sqlerrm;
         Raise v_Base_Exception;
    End;
    
    --把当前主体下intf_ccs_syn_area_inv_detail，推送失败的重新查询一遍最新的仓库，更新为N状态，等待推送
    BEGIN
      FOR DISTRICT_SET in(
        select distinct  tr.district_id ROW_ID,tr.district_code,tr.entity_id
          from cims.intf_ccs_syn_area_inv_detail tr
         WHERE tr.intf_status ='E'
         and tr.last_update_date > sysdate - 1
         and tr.entity_id = P_ENTITY_ID
      )Loop
      --插入及更新仓库列表id及code
        merge into cims.intf_ccs_syn_area_inv_detail ta
        using(
          SELECT p_entity_id entity_id,
             wmsys.wm_concat(inventory_id) inventory_id_list,
             wmsys.wm_concat(inventory_code) inventory_code_list,
             DISTRICT_SET.ROW_ID DISTRICT_ID,
             DISTRICT_SET.District_Code District_Code
            FROM (SELECT distinct r.inventory_id,
                                  r.inventory_code
                    FROM CIMS.T_INV_AREA_INVENTORY_RELATION R
                   WHERE R.DISTRICT_ID IN
                         (SELECT T1.ROW_ID
                            FROM T_BD_DISTRICT T1
                           START WITH T1.ROW_ID = DISTRICT_SET.ROW_ID
                          CONNECT BY PRIOR T1.PAR_ROW_ID = T1.ROW_ID)
                     AND R.ENTITY_ID = P_ENTITY_ID
                     AND R.IS_ACTIVE = 'Y')
          )tb on(ta.district_code = tb.district_code and ta.entity_id = tb.entity_id)
          WHEN MATCHED THEN
            update 
            set ta.intf_status = 'N'
            ,ta.inventory_id_list = tb.inventory_id_list
            ,ta.inventory_code_list = tb.inventory_code_list
            ,ta.error_flag = 'N'
            ,ta.error_msg = ''
            ,ta.last_updated_by = 'admin'
            ,ta.last_update_date = sysdate
            ;
      END Loop;
    Exception
       When Others Then
         p_Result := '仓库与区域关系数据处理失败' || v_Nl ||Sqlerrm;
         Raise v_Base_Exception;
    End;   
  Exception
    When Others Then
        p_Result := '仓库与区域关系数据处理失败' || v_Nl ||Sqlerrm;
        --3、更新接口表
        update cims.intf_ccs_syn_area_inv_relation tr
          set tr.intf_status = 'E'
          ,tr.error_flag = 'Y'
          ,tr.error_msg = p_Result
          ,tr.last_updated_by = 'admin_job'
          ,tr.last_update_date = sysdate
          WHERE tr.intf_status in ('N','E')
           and tr.entity_id = P_ENTITY_ID
           and tr.last_update_date > sysdate - 2;
  End;
  
------------------------------------------------------------------------------------------------
  -- Author  : huanghb12 2019-06-12
  -- Purpose : 全量推送所有四级地址对应的仓库列表。
  --P_ENTITY_ID IN NUMBER,
  --P_Rem       in number, --线程总数数
  --p_mod       in number, --每个线程的取模值
  ------------------------------------------------------------------------------------------------
  PROCEDURE P_Syn_All_Area_Inv_Relation(P_ENTITY_ID IN NUMBER,
                                        P_Rem       in number, --线程数
                                        p_mod       in number, --取模值
                                        P_RESULT    OUT VARCHAR2) is
   v_Count                    Number;
  begin
     p_Result        := v_Success;
    
    --1、拿到所有的四级地址
   FOR DISTRICT_SET in(
      select distinct  t.row_id,t.district_code
        from t_bd_district t
       WHERE t.active_flag = 'Y'
       and t.level_seq = 5
       and mod(t.row_id,P_Rem) = p_mod
       start with t.district_code in(select distinct tr.district_code
          from cims.T_INV_AREA_INVENTORY_RELATION tr
         WHERE tr.entity_id = P_ENTITY_ID)
       CONNECT BY prior t.ROW_ID = t.PAR_ROW_ID
    )Loop
    
      --插入及更新仓库列表id及code
      merge into cims.intf_ccs_syn_area_inv_detail ta
      using(
        SELECT p_entity_id entity_id,
             wmsys.wm_concat(inventory_id) inventory_id_list,
             wmsys.wm_concat(inventory_code) inventory_code_list,
             DISTRICT_SET.ROW_ID DISTRICT_ID,
             DISTRICT_SET.District_Code District_Code
            FROM (SELECT distinct r.inventory_id,
                                  r.inventory_code
                    FROM CIMS.T_INV_AREA_INVENTORY_RELATION R
                   WHERE R.DISTRICT_ID IN
                         (SELECT T1.ROW_ID
                            FROM T_BD_DISTRICT T1
                           START WITH T1.ROW_ID = DISTRICT_SET.ROW_ID
                          CONNECT BY PRIOR T1.PAR_ROW_ID = T1.ROW_ID)
                     AND R.ENTITY_ID = P_ENTITY_ID
                     AND R.IS_ACTIVE = 'Y')
        )tb on(ta.district_code = tb.district_code and ta.entity_id = tb.entity_id)
        WHEN MATCHED THEN
          update 
          set ta.intf_status = 'N'
          ,ta.inventory_id_list = tb.inventory_id_list
          ,ta.inventory_code_list = tb.inventory_code_list
          ,ta.error_flag = 'N'
          ,ta.error_msg = ''
          ,ta.last_updated_by = 'admin'
          ,ta.last_update_date = sysdate
         when not matched then
           INSERT
            (ta.INTF_ID,
            ta.INTF_STATUS ,
            ta.ENTITY_ID,
            ta.Inventory_Id_List ,
            ta.Inventory_Code_List ,
            ta.DISTRICT_ID ,
            ta.DISTRICT_CODE,
            ta.BATCH_CODE,
            ta.CREATED_BY,
            ta.LAST_UPDATED_BY)
          VALUES
            (S_INTF_CCS_SYN_AREA_INV_DETAIL.Nextval,
             'N',
             p_entity_id,
             tb.inventory_id_list,
             tb.inventory_code_list,
             tb.DISTRICT_ID,
             tb.DISTRICT_CODE,
             null,
             'admin',
             'admin')
          ;
    END Loop;
    
  Exception
    When Others Then
        p_Result := '全量获取推送仓库与区域关系数据失败' || v_Nl ||Sqlerrm;
        Raise v_Base_Exception;
  End;

END PKG_INV_JOB;
/

