create view V_SO_CUSTOMER_CONTACT_DETAIL as
SELECT NVL(ROUND(DECODE(SO.BIZ_SRC_BILL_TYPE_CODE,
                    '1009',
                    SO.DISCOUNT_AMOUNT,
                    '1010',
                    SO.DISCOUNT_AMOUNT,
                    0),
             2)，0) AS DISCOUNT_DISCOUNT_AMOUNT,
       NVL(ROUND(DECODE(SO.BIZ_SRC_BILL_TYPE_CODE,
                    '1001',
                    SO.DISCOUNT_AMOUNT,
                    '1002',
                    SO.DISCOUNT_AMOUNT,
                    '1003',
                    SO.DISCOUNT_AMOUNT,
                    '1004',
                    SO.DISCOUNT_AMOUNT,
                    '1005',
                    SO.DISCOUNT_AMOUNT,
                    '1006',
                    SO.DISCOUNT_AMOUNT,
                    '1007',
                    SO.DISCOUNT_AMOUNT,
                    '1008',
                    SO.DISCOUNT_AMOUNT,
                    0),
             2),0) AS SALES_DISCOUNT_AMOUNT,
       '' AS "COMMON_NAME",
       '' AS "COMMON_CODE",
       '' AS STATISTICS_TYPE,
       DECODE("BUSINESS_ID", 'so', 'CIMS-SO', 'ar', 'CIMS-AR') AS "BUSINESS_ID",
       "BILL_ID",
       "BILL_NUM",
       "BILL_DATE",
       "BILL_DATE" AS BEGIN_DATE,
       "BILL_DATE" AS END_DATE,
       ("BUSINESS_ID" || '-' || SO.BILL_STATUS) AS BILL_STATUS,
       (SO_STATUS_CODE.CODE_NAME || '-[销售]') AS "BILL_STATUS_NAME",
       "BILL_TYPE_ID",
       "BILL_TYPE_NAME",
       "SETTLE_DATE",
       "ACCOUNT_DATE",
       "CHECKED_ACCOUNT_DATE",
       SO."CUSTOMER_ID",
       SO."CUSTOMER_CODE",
       SO.CUSTOMER_NAME,
       SO.CUSTOMER_CODE AS CUSTOMER_CODE_P,
       SO.CUSTOMER_NAME AS CUSTOMER_NAME_P,
       SO."ACCOUNT_ID",
       SO."ACCOUNT_CODE",
       SO."ACCOUNT_NAME",
       "CUSTOMER_TYPE",
       SO.ENTITY_ID,
	     SO.ENTITY_NAME,
       SO."SALES_CENTER_ID",
       SO."SALES_CENTER_CODE",
       SO."SALES_CENTER_NAME",
       CO.SALES_CENTER_ID AS NEW_SALES_CENTER_ID,
       CO.SALES_CENTER_CODE AS NEW_SALES_CENTER_CODE,
       CO.SALES_CENTER_NAME AS NEW_SALES_CENTER_NAME,
       SO."SALES_REGION_ID",
       SO."SALES_REGION_NAME",
       "BRAND_CODE",
       "BRAND_NAME",
       "SALES_MAIN_TYPE",
       "SALES_MAIN_TYPE_NAME",
       "PROJECT_NUM",
       "PROJECT_NAME",
       "CASH_CODE",
       "CASH_DATE",
       "DUE_DATE",
       "INVOICE_NUM_LIST",
       "INVOICE_DATE",
       "SALES_YEAR_ID",
       "SALES_YEAR",
       "SRC_TYPE",
       "SRC_TYPE_NAME",
       "SRC_BILL_NUM",
       "DISCOUNT_TYPE_ID",
       "DISCOUNT_TYPE_NAME",
       "DISCOUNT_ITEM",
       "DISCOUNT_MODE",
       "SETTLE_FLAG",
       NVL(ROUND(DECODE(SO.BIZ_SRC_BILL_TYPE_CODE,
                    '1009',
                    0,
                    '1010',
                    0,
                    "LIST_AMOUNT"),
             2),0) AS "LIST_AMOUNT",
       NVL(ROUND("DISCOUNT_AMOUNT", 2),0) AS DISCOUNT_AMOUNT,
       NVL(ROUND(DECODE(SO.BIZ_SRC_BILL_TYPE_CODE,
                    '1009',
                    0,
                    '1010',
                    0,
                    "SETTLE_AMOUNT"),
             2),0) AS "SETTLE_AMOUNT",
       SO.DELAYPAY_AMOUNT,
       0 AS "RECEIVED_AMOUNT",
       NVL(ROUND("SOLUTION_PAY_AMOUNT", 2),0) AS SOLUTION_PAY_AMOUNT,
       SO."REMARK",
       SO.CREATED_BY,
       SO."CREATION_DATE",
       "SALES_RECEIPT",
       "CNT",
       "FUND_CTRL_MODE",
       "DRAFT_FLAG",
       "AUDIT_FLAG",
       "IMPORT_ERP",
       NULL AS USER_ID,
       ' ' AS USER_CODE,
       ' ' AS USER_NAME,
       SO.ERP_OU_ID,
       SO.ERP_OU_NAME,
       SO.ORIGIN_ORIGIN_TYPE,
       SO.ORIGIN_ORIGIN_HEAD_ID,
       SO.ORIGIN_ORIGIN_ORDER_CODE,
       SO.PROJECT_FLAG,
       SO.ENTITY_CUST_FLAG,
       SO.DISCOUNT_TYPE --折扣类型 add by xiaoxu
  FROM V_CREDIT_CONTACT_AMOUNT_SO SO,t_customer_account CO,  --   T_CUSTOMER_ACC_ORG_RELATION ACCO, T_CUSTOMER_ORG CO,
   UP_CODELIST SO_STATUS_CODE
 WHERE SO.BILL_STATUS = SO_STATUS_CODE.CODE_VALUE
   AND SO_STATUS_CODE.CODETYPE = 'SO_STATUS'
   AND CO.ACCOUNT_ID = SO.ACCOUNT_ID
UNION ALL
SELECT 0 AS DISCOUNT_DISCOUNT_AMOUNT,
       0 AS SALES_DISCOUNT_AMOUNT,
       '' AS "COMMON_NAME",
       '' AS "COMMON_CODE",
       '' AS STATISTICS_TYPE,
       DECODE("BUSINESS_ID", 'so', 'CIMS-SO', 'ar', 'CIMS-AR') AS "BUSINESS_ID",
       "BILL_ID",
       "BILL_NUM",
       "BILL_DATE",
       "BILL_DATE" AS BEGIN_DATE,
       "BILL_DATE" AS END_DATE,
       ("BUSINESS_ID" || '-' || AR.BILL_STATUS) AS BILL_STATUS,
       (SO_STATUS_CODE.CODE_NAME || '-[收款]') AS "BILL_STATUS_NAME",
       "BILL_TYPE_ID",
       "BILL_TYPE_NAME",
       "SETTLE_DATE",
       "ACCOUNT_DATE",
       "CHECKED_ACCOUNT_DATE",
       AR."CUSTOMER_ID",
       AR."CUSTOMER_CODE",
       AR.CUSTOMER_NAME,
       AR.CUSTOMER_CODE AS CUSTOMER_CODE_P,
       AR.CUSTOMER_NAME AS CUSTOMER_NAME_P,
       AR."ACCOUNT_ID",
       AR."ACCOUNT_CODE",
       AR."ACCOUNT_NAME",
       "CUSTOMER_TYPE",
       AR.ENTITY_ID,
       AR.ENTITY_NAME,
       AR."SALES_CENTER_ID",
       AR."SALES_CENTER_CODE",
       AR."SALES_CENTER_NAME",
       CO.SALES_CENTER_ID AS NEW_SALES_CENTER_ID,
       CO.SALES_CENTER_CODE AS NEW_SALES_CENTER_CODE,
       CO.SALES_CENTER_NAME AS NEW_SALES_CENTER_NAME,
       AR."SALES_REGION_ID",
       AR."SALES_REGION_NAME",
       "BRAND_CODE",
       "BRAND_NAME",
       "SALES_MAIN_TYPE",
       "SALES_MAIN_TYPE_NAME",
       "PROJECT_NUM",
       "PROJECT_NAME",
       "CASH_CODE",
       "CASH_DATE",
       "DUE_DATE",
       "INVOICE_NUM_LIST",
       "INVOICE_DATE",
       "SALES_YEAR_ID",
       "SALES_YEAR",
       "SRC_TYPE",
       "SRC_TYPE_NAME",
       "SRC_BILL_NUM",
       "DISCOUNT_TYPE_ID",
       "DISCOUNT_TYPE_NAME",
       "DISCOUNT_ITEM",
       "DISCOUNT_MODE",
       "SETTLE_FLAG",
       0 AS "LIST_AMOUNT",
       0 AS "DISCOUNT_AMOUNT",
       0 AS "SETTLE_AMOUNT",
       AR.DELAYPAY_AMOUNT,
       NVL(ROUND("SETTLE_AMOUNT", 2),0) AS "RECEIVED_AMOUNT",
       NVL(ROUND("SOLUTION_PAY_AMOUNT", 2),0) AS SOLUTION_PAY_AMOUNT,
       AR."REMARK",
       AR.CREATED_BY,
       AR."CREATION_DATE",
       "SALES_RECEIPT",
       "CNT",
       "FUND_CTRL_MODE",
       "DRAFT_FLAG",
       "AUDIT_FLAG",
       "IMPORT_ERP",
       NULL AS USER_ID,
       ' ' AS USER_CODE,
       ' ' AS USER_NAME,
       AR.ERP_OU_ID,
       AR.ERP_OU_NAME,
       NULL AS ORIGIN_ORIGIN_TYPE,
       NULL AS ORIGIN_ORIGIN_HEAD_ID,
       NULL AS ORIGIN_ORIGIN_ORDER_CODE,
       AR.PROJECT_FLAG,
       AR.ENTITY_CUST_FLAG,
       ar.DISCOUNT_TYPE AS DISCOUNT_TYPE  --折扣类型 add by xiaoxu
  FROM V_CREDIT_CONTACT_AMOUNT_AR AR, cims.t_customer_account CO, UP_CODELIST SO_STATUS_CODE
 WHERE AR.SETTLE_FLAG = 'Y'
   AND AR.BILL_STATUS = SO_STATUS_CODE.CODE_VALUE
   AND CO.ACCOUNT_ID = AR.ACCOUNT_ID
   AND SO_STATUS_CODE.CODETYPE = 'ar_reciept_status'
   --AND (AR.BILL_STATUS != '1' AND AR.BILL_STATUS != '2' AND
   --    AR.BILL_STATUS != '10' AND AR.BILL_STATUS != '12' AND
    --   AR.BILL_STATUS != '19')
  with read only
/

comment on column V_SO_CUSTOMER_CONTACT_DETAIL.DISCOUNT_DISCOUNT_AMOUNT is '扣率折让金额'
/

comment on column V_SO_CUSTOMER_CONTACT_DETAIL.SALES_DISCOUNT_AMOUNT is '核销扣率折让金额'
/

comment on column V_SO_CUSTOMER_CONTACT_DETAIL.COMMON_NAME is '名称'
/

comment on column V_SO_CUSTOMER_CONTACT_DETAIL.COMMON_CODE is '编码'
/

comment on column V_SO_CUSTOMER_CONTACT_DETAIL.STATISTICS_TYPE is '汇总方式'
/

comment on column V_SO_CUSTOMER_CONTACT_DETAIL.BUSINESS_ID is '业务类型'
/

comment on column V_SO_CUSTOMER_CONTACT_DETAIL.BILL_ID is '单据ID'
/

comment on column V_SO_CUSTOMER_CONTACT_DETAIL.BILL_NUM is '单据号'
/

comment on column V_SO_CUSTOMER_CONTACT_DETAIL.BILL_DATE is '单据日期'
/

comment on column V_SO_CUSTOMER_CONTACT_DETAIL.BILL_STATUS is '单据状态'
/

comment on column V_SO_CUSTOMER_CONTACT_DETAIL.BILL_TYPE_ID is '单据类型ID'
/

comment on column V_SO_CUSTOMER_CONTACT_DETAIL.BILL_TYPE_NAME is '单据类型名称'
/

comment on column V_SO_CUSTOMER_CONTACT_DETAIL.SETTLE_DATE is '结算日期'
/

comment on column V_SO_CUSTOMER_CONTACT_DETAIL.ACCOUNT_DATE is '客户对帐日期'
/

comment on column V_SO_CUSTOMER_CONTACT_DETAIL.CHECKED_ACCOUNT_DATE is '财务对帐日期'
/

comment on column V_SO_CUSTOMER_CONTACT_DETAIL.CUSTOMER_ID is '客户ID'
/

comment on column V_SO_CUSTOMER_CONTACT_DETAIL.CUSTOMER_CODE is '客户编码'
/

comment on column V_SO_CUSTOMER_CONTACT_DETAIL.CUSTOMER_NAME is '客户名称'
/

comment on column V_SO_CUSTOMER_CONTACT_DETAIL.CUSTOMER_CODE_P is '关联客户编码'
/

comment on column V_SO_CUSTOMER_CONTACT_DETAIL.CUSTOMER_NAME_P is '关联客户名称'
/

comment on column V_SO_CUSTOMER_CONTACT_DETAIL.ACCOUNT_ID is '账户ID'
/

comment on column V_SO_CUSTOMER_CONTACT_DETAIL.ACCOUNT_CODE is '账户编码'
/

comment on column V_SO_CUSTOMER_CONTACT_DETAIL.ACCOUNT_NAME is '账户名称'
/

comment on column V_SO_CUSTOMER_CONTACT_DETAIL.CUSTOMER_TYPE is '客户类型'
/

comment on column V_SO_CUSTOMER_CONTACT_DETAIL.ENTITY_ID is '主体ID'
/

comment on column V_SO_CUSTOMER_CONTACT_DETAIL.ENTITY_NAME is '主体名称'
/

comment on column V_SO_CUSTOMER_CONTACT_DETAIL.SALES_CENTER_ID is '营销中心ID'
/

comment on column V_SO_CUSTOMER_CONTACT_DETAIL.SALES_CENTER_CODE is '营销中心编码(客户群编码)'
/

comment on column V_SO_CUSTOMER_CONTACT_DETAIL.SALES_CENTER_NAME is '营销中心名称(客户群名称)'
/

comment on column V_SO_CUSTOMER_CONTACT_DETAIL.NEW_SALES_CENTER_ID is '新中心ID'
/

comment on column V_SO_CUSTOMER_CONTACT_DETAIL.NEW_SALES_CENTER_CODE is '新中心编码'
/

comment on column V_SO_CUSTOMER_CONTACT_DETAIL.NEW_SALES_CENTER_NAME is '新中心名称'
/

comment on column V_SO_CUSTOMER_CONTACT_DETAIL.SALES_REGION_ID is '销售区域ID'
/

comment on column V_SO_CUSTOMER_CONTACT_DETAIL.SALES_REGION_NAME is '销售区域名称'
/

comment on column V_SO_CUSTOMER_CONTACT_DETAIL.BRAND_CODE is '品牌编码'
/

comment on column V_SO_CUSTOMER_CONTACT_DETAIL.BRAND_NAME is '品牌名称'
/

comment on column V_SO_CUSTOMER_CONTACT_DETAIL.SALES_MAIN_TYPE is '营销大类编码'
/

comment on column V_SO_CUSTOMER_CONTACT_DETAIL.SALES_MAIN_TYPE_NAME is '营销大类名称'
/

comment on column V_SO_CUSTOMER_CONTACT_DETAIL.PROJECT_NUM is '批文编码'
/

comment on column V_SO_CUSTOMER_CONTACT_DETAIL.PROJECT_NAME is '批文名称'
/

comment on column V_SO_CUSTOMER_CONTACT_DETAIL.CASH_CODE is '票据号'
/

comment on column V_SO_CUSTOMER_CONTACT_DETAIL.CASH_DATE is '票据日期'
/

comment on column V_SO_CUSTOMER_CONTACT_DETAIL.DUE_DATE is '到期日期'
/

comment on column V_SO_CUSTOMER_CONTACT_DETAIL.INVOICE_NUM_LIST is '发票号串（税控发票）'
/

comment on column V_SO_CUSTOMER_CONTACT_DETAIL.INVOICE_DATE is '发票日期（税控日期）'
/

comment on column V_SO_CUSTOMER_CONTACT_DETAIL.SALES_YEAR_ID is '销售年度ID'
/

comment on column V_SO_CUSTOMER_CONTACT_DETAIL.SALES_YEAR is '销售年度'
/

comment on column V_SO_CUSTOMER_CONTACT_DETAIL.SRC_TYPE is '来源类型'
/

comment on column V_SO_CUSTOMER_CONTACT_DETAIL.SRC_TYPE_NAME is '来源类型名称'
/

comment on column V_SO_CUSTOMER_CONTACT_DETAIL.SRC_BILL_NUM is '来源单号'
/

comment on column V_SO_CUSTOMER_CONTACT_DETAIL.DISCOUNT_TYPE_ID is '折扣ID'
/

comment on column V_SO_CUSTOMER_CONTACT_DETAIL.DISCOUNT_TYPE_NAME is '折扣名称'
/

comment on column V_SO_CUSTOMER_CONTACT_DETAIL.DISCOUNT_ITEM is '折让项目'
/

comment on column V_SO_CUSTOMER_CONTACT_DETAIL.DISCOUNT_MODE is '折让方式'
/

comment on column V_SO_CUSTOMER_CONTACT_DETAIL.SETTLE_FLAG is '结算标识'
/

comment on column V_SO_CUSTOMER_CONTACT_DETAIL.LIST_AMOUNT is '列表金额'
/

comment on column V_SO_CUSTOMER_CONTACT_DETAIL.DISCOUNT_AMOUNT is '折让金额'
/

comment on column V_SO_CUSTOMER_CONTACT_DETAIL.SETTLE_AMOUNT is '结算金额'
/

comment on column V_SO_CUSTOMER_CONTACT_DETAIL.DELAYPAY_AMOUNT is '使用铺底额度'
/

comment on column V_SO_CUSTOMER_CONTACT_DETAIL.RECEIVED_AMOUNT is '到款金额'
/

comment on column V_SO_CUSTOMER_CONTACT_DETAIL.SOLUTION_PAY_AMOUNT is '三方承兑解付金额'
/

comment on column V_SO_CUSTOMER_CONTACT_DETAIL.REMARK is '备注'
/

comment on column V_SO_CUSTOMER_CONTACT_DETAIL.CREATION_DATE is '录入日期'
/

comment on column V_SO_CUSTOMER_CONTACT_DETAIL.FUND_CTRL_MODE is '控制方式'
/

comment on column V_SO_CUSTOMER_CONTACT_DETAIL.DRAFT_FLAG is '是否为承兑'
/

comment on column V_SO_CUSTOMER_CONTACT_DETAIL.AUDIT_FLAG is '审核标识'
/

comment on column V_SO_CUSTOMER_CONTACT_DETAIL.IMPORT_ERP is '引入标识'
/

comment on column V_SO_CUSTOMER_CONTACT_DETAIL.USER_ID is '权限控制：用户ID'
/

comment on column V_SO_CUSTOMER_CONTACT_DETAIL.USER_CODE is '权限控制：用户编码'
/

comment on column V_SO_CUSTOMER_CONTACT_DETAIL.USER_NAME is '权限控制：用户名称'
/

comment on column V_SO_CUSTOMER_CONTACT_DETAIL.ERP_OU_ID is 'ERP OU ID'
/

comment on column V_SO_CUSTOMER_CONTACT_DETAIL.ERP_OU_NAME is 'ERP OU 名称'
/

comment on column V_SO_CUSTOMER_CONTACT_DETAIL.ORIGIN_ORIGIN_TYPE is '上级来源类型：01：计划订单 02：提货订单'
/

comment on column V_SO_CUSTOMER_CONTACT_DETAIL.ORIGIN_ORIGIN_HEAD_ID is '上级来源头ID'
/

comment on column V_SO_CUSTOMER_CONTACT_DETAIL.ORIGIN_ORIGIN_ORDER_CODE is '上级来源单号'
/

comment on column V_SO_CUSTOMER_CONTACT_DETAIL.PROJECT_FLAG is '工程机标识：N 否；Y 是'
/

comment on column V_SO_CUSTOMER_CONTACT_DETAIL.ENTITY_CUST_FLAG is '事业部客户标识'
/

comment on column V_SO_CUSTOMER_CONTACT_DETAIL.DISCOUNT_TYPE is '折扣类型'
/

