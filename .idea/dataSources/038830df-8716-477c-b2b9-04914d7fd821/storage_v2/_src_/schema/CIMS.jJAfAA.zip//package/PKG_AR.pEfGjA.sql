create PACKAGE PKG_AR IS

  -- AUTHOR  : ANHT
  -- CREATED : 2014/8/12 9:56:03
  PROCEDURE P_FEETURNFEE_LG_POL(P_RECEIPT_METHOD_ID          IN NUMBER, --收款方法ID,物流费-转到款和返利-转到款对应的收款方法ID，根据主题区分
                                P_ACCOUNT_ID                 IN NUMBER, --账户ID
                                P_REIM_AMOUNT                IN NUMBER, --报销金额
                                P_REMAEK                     IN VARCHAR2, --备注
                                P_ENTITY_ID                  IN NUMBER, --主体ID
                                P_FEE_REIM_ID                IN VARCHAR2, --报销ID，物流费转到款时传入，与引入EMS的批文ID一致
                                P_FEE_APPLY_ID               IN VARCHAR2, --批文ID，返利转到款时传入，与引入EMS的批文ID一致
                                P_SOURCE_ID                  IN NUMBER, --来源ID，来源表中的主键
                                P_SALES_MAIN_TYPE_CODE_LINES IN VARCHAR2, --营销大类编码，多个营销大类时用逗号分隔
                                P_REIM_AMOUNT_LINES          IN VARCHAR2, --报销金额，若多个营销大类的情况则用逗号分隔
                                P_MESSAGE                    OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
                                );

END PKG_AR;
/

