create PACKAGE PKG_INV_JOB IS

  ------------------------------------------------------------------------------------------------
  -- Author  : 张开安 2018-10-25
  -- Purpose : 冻结产品库存现有量报表，每天凌晨执行一次。
  ------------------------------------------------------------------------------------------------
  PROCEDURE P_INV_FREEZE_ITEM_ONHAND(P_ENTITY_ID IN NUMBER,
                                     P_RESULT    OUT VARCHAR2);
                                     
  ------------------------------------------------------------------------------------------------
  -- Author  : huanghb12 2019-06-12
  -- Purpose : 处理同步仓库关系数据到ccs接口表。
  ------------------------------------------------------------------------------------------------
  PROCEDURE P_Handle_Syn_Area_Inv_Relation(P_ENTITY_ID IN NUMBER,
                                           P_RESULT    OUT VARCHAR2);
  ------------------------------------------------------------------------------------------------
  -- Author  : huanghb12 2019-06-12
  -- Purpose : 全量推送所有四级地址对应的仓库列表。
  --P_ENTITY_ID IN NUMBER,
  --P_Rem       in number, --线程总数数
  --p_mod       in number, --每个线程的取模值
  ------------------------------------------------------------------------------------------------
  PROCEDURE P_Syn_All_Area_Inv_Relation(P_ENTITY_ID IN NUMBER,
                                        P_Rem       in number, --线程数
                                        p_mod       in number, --取模值
                                        P_RESULT    OUT VARCHAR2);
                                           
END PKG_INV_JOB;
/

