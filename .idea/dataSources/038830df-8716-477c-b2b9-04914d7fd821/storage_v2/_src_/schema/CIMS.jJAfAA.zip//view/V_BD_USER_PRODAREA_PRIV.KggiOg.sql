create view V_BD_USER_PRODAREA_PRIV as
select distinct p."USER_ID",p."USER_CODE",p."USER_NAME",p."PRODUCING_AREA_ID",p."PRODUCING_AREA_CODE",p."PRODUCING_AREA_NAME",p."ENTITY_ID"
  from (/*select uu.user_id, --用户ID
               uu.account user_code, --用户编码
               uu.name user_name, --用户名称
               ic.producing_area_id, --产地ID
               ic.producing_area_code, --产地编码
               ic.producing_area_name, --产地名称
               et.entity_id --主体id
          from up_org_user uu,
               (select * from t_pln_producing_area) ic,
               (select u.unit_id entity_id,
                       u.code    entity_code,
                       u.name    entity_name
                  from up_org_unit u
                 where u.type_code = 'BU'
                   and u.active_flag = 'T') et
         where ic.entity_id = et.entity_id
        minus  */
        --用户独立授权的限制访问的产地
        select dpp.user_id,
               uu.account user_code,
               uu.name user_name,
               ppa.producing_area_id, --产地ID
               ppa.producing_area_code, --产地编码
               ppa.producing_area_name, --产地名称
               dpp.entity_id
          from t_bd_datapriv_producing dpp,
               t_pln_producing_area    ppa,
               up_org_user             uu
         where dpp.producing_area_id = ppa.producing_area_id
           and dpp.user_id = uu.user_id
           and dpp.active_flag = 'Y' --有效记录
        --and ppa.active_flag='Y'
        ) p
/

