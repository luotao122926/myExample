create procedure P_INV_SO_TRANSACTION(I_ENTITY_ID IN INTEGER) IS
  /**
  销售单对账逻辑：
  1、将销售单库存事务、ERP对应销售的库存事务一次性写入接口表，然后校验差异
  2、获取CIMS单据应该产生库存事务，但未产生库存事务的单据信息
  */
  /** v1.1
    1、纠正对销售单、销售退货单未产生库存事务的判断，如电商销售单有接收仓编码问题；
    2、将so01调整为so生成，so02调整为so变更
    3、纠正销售单在ERP库存事务来源重复问题，增加and inv_erp.attribute13 is null
  */
  /** v1.2
  1、纠正销售单结算状态判断问题，循环校验开始时，将状态更新为空。
  */
  /** v1.3
     1、优化库存事务查询-一次写入库存事务情况，然后分析差异
     2、取消重复查询ERP库存事务
     3、支持关联交易：OU+业务类型扩展(是否推广物料)
     4、关联交易：RMA接收事务待补充
  */
  /** v1.4
      -- 20150813
      1、取消拉式销售发货仓一致的条件
      2、增加查询规则： /*+ DRIVING_SITE(inv_erp) * /
      3、SO生成，限制库存组织ID从SO中获取
      4、将查询ERP的条件进行排序
      5、关联交易判断，增加MIXED类型，以及单据中的库存组织
  */
  -- 主体
  v_entity_id integer;

  -- OU_ID
  i_org_id integer;

  -- 纠正状态时查询出的实际库存事务数量
  i_qty_updated number;

  -- 备注长度，1000个字(数字、字母、汉字均按照1个字计算)
  i_remark_length number := 1000;

  -- 库存事务记录数
  i_bill_count integer;
  --接口错误信息
  str_intf_err varchar2(4000);
  -- 临时查询的记录数量
  i_qty_temp number;

  -- 查询的临时结果
  str_temp varchar2(50);
  --单据状态名称
  str_status_meaning varchar2(20);
  --单据信息
  str_msg varchar2(4000);
  -- SO最终状态-结算
  str_status_end varchar2(20);
  -- 单据状态 00成功，01失败
  str_status varchar2(20);
  --  生成/变更
  str_status_msg varchar2(40);
  -- 库存事务开始日期，大于等于改日期
  str_start_date varchar2(200);
  -- 库存事务结束日期，小于该日期
  str_end_date varchar2(200);

  -- 执行SQL后是否及时提交事务
  b_immediate_commit boolean;

  --对账程序开始时间-用于纠正更新
  str_start_time varchar2(200);
  --对账程序结束时间-用于纠正更新
  str_end_time varchar2(200);

  -- SO生成子库转移
  str_insert_sql1 varchar2(30000);
  -- SO结算销售发出或RMA接收
  str_insert_sql2 varchar2(30000);

  -- 数量更新字段
  str_qty_field_updated varchar2(500);
  -- 数量更新字段
  str_status_field_updated varchar2(500);
  -- 查询
  str_select_sql varchar2(4000);
  -- SO数量、状态更新
  str_update_sql varchar2(30000);
  --删除报错单据
  str_delete_sql varchar2(4000);
  -- 插入对照表SQL
  str_insert_sql varchar2(4000);

  str_organization_ids varchar2(1000);

  i_transaction_type number; -- 库存事务类型
  STATIC_ICP_TYPE    number := 3; -- 关联交易
  STATIC_BILL_TYPE   number := 2; -- 销售
  STATIC_INTF_TYPE   number := 1; -- 库存事务接口
  STATIC_NOT_TYPE    number := 0; -- 未定义库存事务类型

  cursor c_get_organization_ids(in_entity_id in number) is
    select distinct to_char(so.erp_subinv_id) organization_id
      from cims.t_so_header so
     where nvl(so.erp_subinv_id, 0) > 0
       and so.entity_id = in_entity_id;

  -- SO生成
  cursor c_reconciliation_diff11(in_entity_id in number, in_start_time in varchar2, in_end_time in varchar2) is
    select distinct rec.business_num bill_no
    --rec.inv_code,
    --rec.item_code,
    --rec.cims_qty,
    --rec.gerp_qty
      from cims.t_inv_taction_reconciliation rec
     where rec.entity_id = in_entity_id
          --and rec.cims_qty <> rec.gerp_qty
       and rec.creation_date >=
           to_date(in_start_time, 'yyyy-mm-dd hh24:mi:ss') - 1 / (24 * 60)
       and rec.creation_date <=
           to_date(in_end_time, 'yyyy-mm-dd hh24:mi:ss') + 1 / (24 * 60)
       and rec.reconciliation_type = 'SO01'
       and rec.status = '01'
       and exists (select 1
              from cims.t_so_header so
             where rec.business_num = so.so_num
               and so.entity_id = in_entity_id);

  -- SO结算,SO必须存在
  cursor c_reconciliation_diff12(in_entity_id in number, in_start_time in varchar2, in_end_time in varchar2) is
    select rec.business_num bill_no,
           rec.inv_code,
           rec.item_code,
           rec.cims_qty,
           rec.gerp_qty,
           so.erp_ou_id org_id,
           so.erp_subinv_code erp_organization_code,
           bill_ext.promotion_flay in_erp_trancation
      from cims.t_inv_taction_reconciliation rec,
           cims.t_so_type_extend             bill_ext,
           cims.t_so_header                  so
     where rec.entity_id = in_entity_id
       and rec.creation_date >
           to_date(in_start_time, 'yyyy-mm-dd hh24:mi:ss') - 1 / (24 * 60)
       and rec.creation_date <
           to_date(in_end_time, 'yyyy-mm-dd hh24:mi:ss') + 1 / (24 * 60)
       and rec.reconciliation_type = 'SO02'
       and rec.status = '01'
       and rec.business_num = so.so_num
       and bill_ext.bill_type_id = so.bill_type_id
       and bill_ext.entity_id = in_entity_id
       and so.entity_id = in_entity_id;

  -- SO结算-反向销售或源单退回
  cursor c_reconciliation_return_diff12(in_entity_id in number, in_start_time in varchar2, in_end_time in varchar2) is
    select rec.business_num bill_no,
           rec.inv_code,
           rec.item_code,
           rec.cims_qty,
           rec.gerp_qty,
           so.erp_ou_id org_id,
           bill_ext.promotion_flay in_erp_trancation,
           so.return_mode
      from cims.t_inv_taction_reconciliation rec,
           cims.t_so_type_extend             bill_ext,
           cims.t_so_header                  so
     where rec.entity_id = in_entity_id
       and rec.creation_date >
           to_date(in_start_time, 'yyyy-mm-dd hh24:mi:ss') - 1 / (24 * 60)
       and rec.creation_date <
           to_date(in_end_time, 'yyyy-mm-dd hh24:mi:ss') + 1 / (24 * 60)
       and rec.reconciliation_type = 'SO02'
       and rec.status = '01'
       and so.biz_src_bill_type_id in (2, 3)
       and rec.business_num = so.so_num
       and bill_ext.bill_type_id = so.bill_type_id
       and bill_ext.entity_id = in_entity_id
       and so.entity_id = in_entity_id;

  -- 单据周期
  cursor bill_period(in_period_head_id in number) is
    select inv_period_l.bill_status_code status
      from cims.t_inv_bill_period_line inv_period_l
     where inv_period_l.transaction_flag = 'Y'
       and inv_period_l.bill_period_head_id = in_period_head_id;

  -- SO单未产生库存事务，与单据周期关联
  cursor so_inv_cims_nexists(in_entity_id in number, in_status_end in varchar2) is
    select bill_no, inv_code, item_code, bill_type, status, sum(qty) qty
      from (select so.so_num                 bill_no,
                   so.ship_inv_code          inv_code,
                   so_d.component_code       item_code,
                   bill_type.bill_type_name  bill_type,
                   period_l.bill_status_code status,
                   so_d.item_qty             qty
              from cims.t_so_header            so,
                   cims.t_so_line_detail       so_d,
                   cims.t_inv_bill_types       bill_type,
                   cims.t_inv_bill_period_line period_l
             where so.bill_type_id = bill_type.bill_type_id
               and bill_type.bill_period_head_id =
                   period_l.bill_period_head_id
               and so.so_header_id = so_d.so_header_id
               and so.biz_src_bill_type_id in (1, 2)
                  --and so.so_num = '100000081'
               and bill_type.entity_id = in_entity_id
               and period_l.transaction_flag = 'Y'
               and period_l.bill_status_code <> in_status_end
               and so.so_status >= period_l.bill_status_code
               and not exists
             (select 1
                      from cims.t_inv_transaction_history invh
                     where invh.business_num = so.so_num
                       and so.ship_inv_code = invh.inventory_code
                       and invh.item_code = so_d.component_code
                       and invh.business_state = period_l.bill_status_code)
            
            union all
            
            select so.so_num                 bill_no,
                   so.consignee_inv_code     inv_code,
                   so_d.component_code       item_code,
                   bill_type.bill_type_name  bill_type,
                   period_l.bill_status_code status,
                   so_d.item_qty             qty
              from cims.t_so_header            so,
                   cims.t_so_line_detail       so_d,
                   cims.t_inv_bill_types       bill_type,
                   cims.t_inv_bill_period_line period_l
             where so.bill_type_id = bill_type.bill_type_id
               and bill_type.bill_period_head_id =
                   period_l.bill_period_head_id
               and so.so_header_id = so_d.so_header_id
               and so.biz_src_bill_type_id in (3, 4)
                  --and so.so_num = '100000081'
               and bill_type.entity_id = in_entity_id
               and period_l.transaction_flag = 'Y'
               and period_l.bill_status_code <> in_status_end
               and so.so_status >= period_l.bill_status_code
               and not exists
             (select 1
                      from cims.t_inv_transaction_history invh
                     where invh.business_num = so.so_num
                       and so.consignee_inv_code = invh.inventory_code
                       and invh.item_code = so_d.component_code
                       and invh.business_state = period_l.bill_status_code)
            
            union all
            
            select so.so_num                 bill_no,
                   so.middle_inv_code        inv_code,
                   so_d.component_code       item_code,
                   bill_type.bill_type_name  bill_type,
                   period_l.bill_status_code status,
                   so_d.item_qty             qty
              from cims.t_so_header            so,
                   cims.t_so_line_detail       so_d,
                   cims.t_inv_bill_types       bill_type,
                   cims.t_inv_bill_period_line period_l
             where so.bill_type_id = bill_type.bill_type_id
               and bill_type.bill_period_head_id =
                   period_l.bill_period_head_id
               and so.so_header_id = so_d.so_header_id
                  --and so.so_num = '100000081'
               and bill_type.entity_id = in_entity_id
               and period_l.transaction_flag = 'Y'
               and period_l.bill_status_code = in_status_end
               and so.so_status >= period_l.bill_status_code
               and not exists
             (select 1
                      from cims.t_inv_transaction_history invh
                     where invh.business_num = so.so_num
                       and so.middle_inv_code = invh.inventory_code
                       and invh.item_code = so_d.component_code
                       and invh.business_state = period_l.bill_status_code))
     group by bill_no, inv_code, item_code, bill_type, status;

  -- 返回关联交易类型
  function f_get_transaction_type(in_entity_id_f         in number,
                                  in_organization_code_f in varchar2)
    return number is
    return_type        number;
    str_entity_value_f varchar2(50);
  begin
    return_type := STATIC_BILL_TYPE; -- 单据类型
  
    -- PULL 拉式;PUSH 推式
    select nvl(pe.entity_value, pl.default_value)
      into str_entity_value_f
      from cims.t_bd_param_list pl, cims.t_bd_param_entity pe
     where pl.param_code = 'SO_AR_PUSH_OR_PULL'
       and pe.param_list_id(+) = pl.param_list_id
       and pe.entity_id(+) = in_entity_id_f
       and rownum < 2;
  
    if (str_entity_value_f = 'PULL') then
      return_type := STATIC_ICP_TYPE;
    end if;
  
    if (str_entity_value_f = 'MIXED') then
      if (in_organization_code_f is not null) and
         (substr(in_organization_code_f, 1, 1) = 'S') then
        return_type := STATIC_BILL_TYPE;
      else
        return_type := STATIC_ICP_TYPE;
      end if;
    end if;
  
    return return_type;
  end;

  -- 获取库存事务接口错误原因
  function f_get_intf_result(in_entity_id_f in number,
                             in_bill_no_f   in varchar2) return varchar2 is
    return_msg varchar2(2000);
    i_count_f  number;
  begin
    select count(*)
      into i_count_f
      from cims.intf_inv_transaction_head invh
     where invh.order_num = in_bill_no_f
       and nvl(invh.entity_id, in_entity_id_f) = in_entity_id_f;
  
    if i_count_f = 0 then
      return_msg := '库存事务接口表没有记录';
    end if;
  
    if i_count_f > 0 then
      select decode(nvl(invh.error_flag, 'N'),
                    'Y',
                    decode(invh.error_msg,
                           null,
                           invh.response_message,
                           invh.error_msg),
                    decode(nvl(invh.response_type, 'N'),
                           'E',
                           invh.response_message,
                           decode(invh.status,
                                  'S',
                                  'GERP异步回调正常，原因待人工进一步处理',
                                  '等待GERP异步回调处理结果')))
        into return_msg
        from cims.intf_inv_transaction_head invh
       where invh.order_num = in_bill_no_f
         and nvl(invh.entity_id, in_entity_id_f) = in_entity_id_f
         and rownum < 2;
    end if;
  
    return return_msg;
  end;

  -- 获取关联交易原因
  function f_get_icp_result(in_entity_id_f in number,
                            in_bill_no_f   in varchar2) return varchar2 is
    return_msg_f varchar2(2000);
    i_bill_num_f number;
  
    str_status_f         varchar2(10);
    str_bill_line_msg_f  varchar2(2000);
    str_bill_line_msg2_f varchar2(2000);
  begin
    return_msg_f := '关联交易信息';
  
    -- 查找原因
    -- 异步物流
    select count(1)
      into i_bill_num_f
      from cims.intf_cux_icp_logist_req_header icp_po
     where icp_po.requirement_order_num = in_bill_no_f
       and icp_po.entity_id = in_entity_id_f;
  
    -- 异步物流接口 if-2
    if i_bill_num_f = 0 then
      begin
        -- 物流订单
        select count(1)
          into i_bill_num_f
          from cims.intf_cux_icp_order_req_headers icp_order
         where icp_order.source_orders = in_bill_no_f;
      
        -- 物流订单接口 if-3
        if i_bill_num_f > 0 then
          select decode(nvl(icp_order.error_msg, '1'),
                        '1',
                        decode(nvl(icp_order.responsemessage, '1'),
                               '1',
                               null,
                               icp_order.responsemessage),
                        icp_order.error_msg)
            into str_bill_line_msg_f
            from cims.intf_cux_icp_order_req_headers icp_order
           where icp_order.source_orders = in_bill_no_f;
        
          if str_bill_line_msg_f is null then
            str_bill_line_msg_f := '同步物流接口无数据,物流订单接口正常,原因需进一步验证1';
          end if;
        end if; -- if-3-01 end 物流订单接口
      end; ----end 异步物流接口 if i_bill_num = 0 then begin
    else
      begin
        select decode(nvl(icp_po.error_msg_rev, '1'),
                      '1',
                      decode(nvl(icp_po.responsetype_2, 'N'),
                             'N',
                             decode(nvl(icp_po.error_msg_send, '1'),
                                    '1',
                                    decode(nvl(icp_po.Responsetype_1, 'N'),
                                           'N',
                                           decode(nvl(icp_po.status, 'N'),
                                                  'N',
                                                  '同步物流接口,待推送单据至GERP',
                                                  decode(icp_po.status_receive,
                                                         'P',
                                                         '同步物流接口正常,等待GERP异步回调')),
                                           icp_po.responsemessage_1),
                                    icp_po.error_msg_send),
                             icp_po.responsemessage_2),
                      icp_po.error_msg_rev)
          into str_bill_line_msg_f
          from cims.intf_cux_icp_logist_req_header icp_po
         where icp_po.requirement_order_num = in_bill_no_f
           and icp_po.entity_id = in_entity_id_f;
      
        --同步物流接口错误信息
        if (str_bill_line_msg_f is null) or
           ((str_bill_line_msg_f is not null) and
           (str_bill_line_msg_f = '同步物流接口正常,等待GERP异步回调' or
           str_bill_line_msg_f = '同步物流接口,待推送单据至GERP')) then
          -- 物流订单
          select count(1)
            into i_bill_num_f
            from cims.intf_cux_icp_order_req_headers icp_order
           where icp_order.source_orders = in_bill_no_f;
        
          --主体ID无值and icp_order.entity_id = v_entity_id;
        
          -- 存在物流订单
          if i_bill_num_f > 0 then
            select decode(nvl(icp_order.error_flag, 'N'),
                          'N',
                          decode(nvl(icp_order.responsetype, 'N'),
                                 'W',
                                 icp_order.responsemessage,
                                 decode(nvl(icp_order.status, 'N'),
                                        'N',
                                        '同步物流接口正常,物流订单待推送至GERP',
                                        'S',
                                        '同步物流接口正常,物流订单已推送至GERP,且GERP异步返回成功')),
                          icp_order.error_msg)
              into str_bill_line_msg2_f
              from cims.intf_cux_icp_order_req_headers icp_order
             where icp_order.source_orders = in_bill_no_f;
          
            if str_bill_line_msg2_f is not null then
              str_bill_line_msg_f := str_bill_line_msg2_f; --'同步物流接口正常,原因需进一步验证2';
            else
              begin
                select count(1)
                  into i_bill_num_f
                  from apps.cux_icp_logist_req_headers_v@mdims2mderp po_icp_erp
                 where po_icp_erp.requirement_order_num = in_bill_no_f
                   and po_icp_erp.esb_data_source = 'CIMS'
                   and rownum < 2;
              
                if i_bill_num_f > 0 then
                  select status, status_name
                    into str_status_f, str_bill_line_msg2_f
                    from apps.cux_icp_logist_req_headers_v@mdims2mderp po_icp_erp
                   where po_icp_erp.requirement_order_num = in_bill_no_f
                     and po_icp_erp.esb_data_source = 'CIMS'
                     and rownum < 2;
                
                  if (str_status_f is not null) and (str_status_f <> '5') then
                    str_bill_line_msg_f := str_bill_line_msg2_f;
                  end if;
                
                end if;
              end;
            end if;
          
            --dbms_output.put_line('03-3--' || str_bill_line_msg);
          end if; -- end 存在物流订单 if i_bill_num > 0
        
        end if; -- end 同步物流接口 if str_bill_line_msg is null                  
      end;
    end if; -- if-2-01 end 同步物流接口 if i_bill_num = 0     
  
    if str_bill_line_msg_f is null then
      str_bill_line_msg_f := '同步物流接口正常,物流订单接口正常,原因需进一步验证3';
    end if;
  
    return_msg_f := str_bill_line_msg_f;
  
    return return_msg_f;
  end;

  -- 获取单据接口错误原因-update_sql-单据成功才有库存事务
  function f_get_bill_result(in_entity_id_f             in number,
                             in_bill_no_f               in varchar2,
                             in_org_id_f                in number,
                             in_erp_organization_code_f in varchar2)
    return varchar2 is
    return_msg           varchar2(4000);
    str_msg_f            varchar2(4000);
    str_temp_f           varchar2(100);
    i_transaction_type_f number;
    i_count_f            number;
  begin
    return_msg := null;
  
    -- SO变更是否成功->是否关联交易及是否成功
    select count(1)
      into i_count_f
      from apps.oe_order_headers_all@mdims2mderp order_erp
     where order_erp.order_number = in_bill_no_f
       and order_erp.org_id = in_org_id_f;
  
    -- 单据已引入GERP
    if i_count_f > 0 then
      begin
        --03  --03                
        select order_erp.flow_status_code
          into str_temp_f
          from apps.oe_order_headers_all@mdims2mderp order_erp
         where order_erp.order_number = in_bill_no_f
           and order_erp.org_id = in_org_id_f
           and rownum < 2;
      
        if (str_temp_f is not null) and (str_temp_f = 'CLOSED') then
          begin
            str_msg := '单据在GERP已结算完成，未产生库存事务，需GERP进一步查找原因';
          end;
        else
          begin
            -- 继续查找结算问题                  
            str_msg := null;
            select decode(nvl(intf_order.update_trx_status, 'N'),
                          'S',
                          'CIMS结算成功，且GERP未完成结算，需重点关注',
                          'N',
                          '未向GERP发送SO结算',
                          'E',
                          intf_order.error_msg,
                          '未知状态')
              into str_msg
              from cims.intf_oe_headers_iface_all intf_order
             where intf_order.order_number = in_bill_no_f
               and rownum < 2;
          
            i_transaction_type_f := f_get_transaction_type(in_entity_id_f,
                                                           in_erp_organization_code_f);
            -- 需判断是否关联交易，如果是关联交易需继续校验
            if (i_transaction_type_f = STATIC_ICP_TYPE) and
               (str_msg = 'CIMS结算成功，且GERP未完成结算，需重点关注') then
              str_msg := f_get_icp_result(v_entity_id, in_bill_no_f);
            end if;
          
            if str_msg = '未向GERP发送SO结算' then
              str_msg := 'SO结算-差异正常,' || str_msg;
            else
              str_msg := 'SO结算有差异,' || str_msg;
            end if;
          
          end;
        end if;
      end; -- 03 --03   -- end if i_bill_count > 0 单据已引入GERP
    else
      begin
        str_msg := 'SO结算有差异-此差异不正常，单据尚未引入GERP';
      end;
    end if; -- 03  -- 02
  
    return_msg := str_msg;
  
    if return_msg is null then
      return_msg := 'SO单接口没有错误，原因待进一步核实';
    end if;
  
    return return_msg;
  end;

  -- 返回库存事务对账SQL-SO生成
  function f_get_so01_sql(in_entity_id_f  in number,
                          in_status_end_f in varchar2,
                          in_start_date_f in varchar2,
                          in_end_date_f   in varchar2) return varchar2 is
    return_result_sql varchar2(30000);
  begin
    return_result_sql := 'insert into cims.t_inv_taction_reconciliation ' ||
                         '  (entity_id, ' || '   business_type, ' ||
                         '   business_num, ' || '   reconciliation_time, ' ||
                         '   reconciliation_flag, ' || '   status, ' ||
                         '   inv_code, ' || '   item_code, ' ||
                         '   cims_qty, ' || '   gerp_qty, ' ||
                         '   remark, ' || '   created_by, ' ||
                         '   creation_date, ' || '   last_updated_by, ' ||
                         '   last_update_date, ' ||
                         '   reconciliation_type) ' || '  select ' ||
                         in_entity_id_f || ' entity_id, ' ||
                         '         nvl((select so.bill_type_name ' ||
                         '               from cims.t_so_header so ' ||
                         '              where so.so_num = bill_no ' ||
                         '                and rownum < 2), ' ||
                         '             ''SO未知类型'') business_type, ' ||
                         '         bill_no business_num, ' ||
                         '         sysdate reconciliation_time, ' ||
                         '         ''00'' reconciliation_flag, ' ||
                         '         decode(sign(cims_qty - gerp_qty), 0, ''00'', ''01'') status, ' ||
                         '         inv_code, ' || '         item_code, ' ||
                         '         cims_qty, ' || '         gerp_qty, ' ||
                         '         decode(sign(nvl(cims_qty, 0) - nvl(gerp_qty, 0)), ' ||
                         '                -1, ' ||
                         '                ''SO生成有差异-待确认'', ' ||
                         '                0, ' ||
                         '                ''SO生成无差异'', ' ||
                         '                1, ' ||
                         '                ''SO生成有差异-待确认'') remark, ' ||
                         '         ''SYS'' created_by, ' ||
                         '         sysdate creation_date, ' ||
                         '         ''SYS'' last_updated_by, ' ||
                         '         sysdate last_update_date, ' ||
                         '         ''SO01'' reconciliation_type ' ||
                         '    from (select bill_no, ' ||
                         '                 inv_code, ' ||
                         '                 item_code, ' ||
                         '                 sum(cims_qty) cims_qty, ' ||
                         '                 sum(gerp_qty) gerp_qty ' ||
                         '            from (select /*+ DRIVING_SITE(inv_erp) */ ''GERP'' sys_name, ' ||
                         '                         inv_erp.transaction_reference bill_no, ' ||
                         '                         inv_erp.subinventory_code inv_code, ' ||
                         '                         mtl.segment1 item_code, ' ||
                         '                         inv_erp.transaction_quantity gerp_qty, ' ||
                         '                         0 cims_qty ' ||
                         '                    from apps.mtl_material_transactions@mdims2mderp inv_erp, ' ||
                         '                         apps.mtl_system_items_b@mdims2mderp        mtl ' ||
                         '                   where 1 = 1 ' ||
                         '                     and inv_erp.inventory_item_id = mtl.inventory_item_id ' ||
                         '                     and inv_erp.organization_id = mtl.organization_id ' ||
                         '                     and inv_erp.transaction_date > ' ||
                         '                         to_date(''' ||
                         in_start_date_f || ''', ''yyyy-mm-dd'') ' ||
                         '                     and inv_erp.transaction_date < ' ||
                         '                         to_date(''' ||
                         in_end_date_f || ''', ''yyyy-mm-dd'') ' ||
                         '  and inv_erp.organization_id in (' ||
                         str_organization_ids || ')' ||
                        /*'                     and exists(select 1 from cims.t_inv_organization p where p.entity_id=' ||
                                                                                                                                                                         in_entity_id_f ||
                                                                                                                                                                         ' and p.organization_id=inv_erp.organization_id) ' ||*/
                         '                     and exists ' ||
                         '                   (select 1 ' ||
                         '                            from cims.t_so_header order_cims ' ||
                         '                           where order_cims.so_num = ' ||
                         '                                 inv_erp.transaction_reference ' ||
                         '                             and inv_erp.organization_id = ' ||
                         '                                 order_cims.erp_subinv_id ' ||
                         '                             and order_cims.entity_id=' ||
                         in_entity_id_f ||
                         '                             and not exists ' ||
                         '                           (select 1 ' ||
                         '                                    from cims.t_inv_taction_reconciliation recc ' ||
                         '                                   where recc.entity_id = ' ||
                         in_entity_id_f ||
                         '                                     and recc.business_num = order_cims.so_num ' ||
                         '                                     and recc.reconciliation_type = ''SO01'') ' ||
                         '                             and order_cims.entity_id = ' ||
                         in_entity_id_f || ') ' ||
                         '                     and inv_erp.attribute13 is null ' ||
                         '                     and inv_erp.source_code=''CIMS'' ' ||
                         '                  union all ' ||
                         '                  select ''CIMS'' sys_name, ' ||
                         '                         invh.business_num bill_no, ' ||
                         '                         invh.inventory_code inv_code, ' ||
                         '                         invh.item_code, ' ||
                         '                         0 gerp_qty, ' ||
                         '                         invh.transaction_quantity cims_qty ' ||
                         '                    from cims.t_inv_transaction_history invh ' ||
                         '                   where 1 = 1 ' ||
                         '                     and invh.transaction_date > ' ||
                         '                         to_date(''' ||
                         in_start_date_f || ''', ''yyyy-mm-dd'') ' ||
                         '                     and invh.transaction_date < ' ||
                         '                         to_date(''' ||
                         in_end_date_f || ''', ''yyyy-mm-dd'') ' ||
                         '                     and invh.entity_id=' ||
                         in_entity_id_f ||
                         '                     and exists ' ||
                         '                   (select period_l.bill_status_code, so.so_num ' ||
                         '                            from cims.t_so_header            so, ' ||
                         '                                 cims.t_inv_bill_types       bill_type, ' ||
                         '                                 cims.t_inv_bill_period_line period_l ' ||
                         '                           where so.bill_type_id = bill_type.bill_type_id ' ||
                         '                             and bill_type.bill_period_head_id = ' ||
                         '                                 period_l.bill_period_head_id ' ||
                         '                             and so.entity_id = ' ||
                         in_entity_id_f ||
                         '                             and bill_type.entity_id = ' ||
                         in_entity_id_f ||
                         '                             and period_l.bill_status_code <> ''' ||
                         in_status_end_f || '''        and not exists ' ||
                         '                           (select 1 ' ||
                         '                                    from cims.t_inv_taction_reconciliation recc ' ||
                         '                                   where recc.entity_id = ' ||
                         in_entity_id_f || ' ' ||
                         '                                     and recc.business_num = so.so_num ' ||
                         '                                     and recc.reconciliation_type = ''SO01'') ' ||
                         '                             and period_l.transaction_flag = ''Y'' ' ||
                         '                             and so.so_num=invh.business_num ' ||
                         '                             and period_l.bill_status_code = ' ||
                         '                                 invh.business_state)) ' ||
                         '           group by bill_no, inv_code, item_code) bill_all ' ||
                         '   where 1 = 1 ' ||
                         '        and not exists(select 1 from cims.t_inv_taction_reconciliation rec ' ||
                         '          where rec.business_num=bill_all.bill_no and rec.reconciliation_type=''SO01'' and rec.entity_id=' ||
                         in_entity_id_f || ')';
  
    return return_result_sql;
  end;

  -- 返回库存事务对账SQL-SO生成
  function f_get_so02_sql(in_entity_id_f  in number,
                          in_status_end_f in varchar2,
                          in_start_date_f in varchar2,
                          in_end_date_f   in varchar2) return varchar2 is
    return_result_sql varchar2(30000);
  begin
    return_result_sql := 'insert into cims.t_inv_taction_reconciliation ' ||
                         '  (entity_id, ' || '   business_type, ' ||
                         '   business_num, ' || '   reconciliation_time, ' ||
                         '   reconciliation_flag, ' || '   status, ' ||
                         '   inv_code, ' || '   item_code, ' ||
                         '   cims_qty, ' || '   gerp_qty, ' ||
                         '   remark, ' || '   created_by, ' ||
                         '   creation_date, ' || '   last_updated_by, ' ||
                         '   last_update_date, ' ||
                         '   reconciliation_type) ' || '  select ' ||
                         in_entity_id_f || ' entity_id, ' ||
                         '         (select so.bill_type_name ' ||
                         '               from cims.t_so_header so ' ||
                         '              where so.so_num = bill_no) ' ||
                         '              business_type, ' ||
                         '         bill_no business_num, ' ||
                         '         sysdate reconciliation_time, ' ||
                         '         ''00'' reconciliation_flag, ' ||
                         '         decode(sign(cims_qty - gerp_qty), 0, ''00'', ''01'') status, ' ||
                         '         inv_code, ' || '         item_code, ' ||
                         '         cims_qty, ' || '         gerp_qty, ' ||
                         '         decode(sign(nvl(cims_qty, 0) - nvl(gerp_qty, 0)), ' ||
                         '                -1, ' ||
                         '                ''SO结算有差异-待确认'', ' ||
                         '                0, ' ||
                         '                ''SO结算无差异'', ' ||
                         '                1, ' ||
                         '                ''SO结算有差异-待确认'') remark, ' ||
                         '         ''SYS'' created_by, ' ||
                         '         sysdate creation_date, ' ||
                         '         ''SYS'' last_updated_by, ' ||
                         '         sysdate last_update_date, ' ||
                         '         ''SO02'' reconciliation_type ' ||
                         '    from (select bill_no, ' || -----销售发出(非关联交易)
                         '                 inv_code, ' ||
                         '                 item_code, ' ||
                         '                 sum(cims_qty) cims_qty, ' ||
                         '                 sum(gerp_qty) gerp_qty ' ||
                         '            from (select /*+ DRIVING_SITE(inv_erp) */ ''GERP'' sys_name, ' ||
                         '                         so.so_num bill_no, ' ||
                         '                         inv_erp.subinventory_code inv_code, ' ||
                         '                         mtl.segment1 item_code, ' ||
                         '                         inv_erp.transaction_quantity gerp_qty, ' ||
                         '                         0 cims_qty ' ||
                         '                    from apps.mtl_material_transactions@mdims2mderp inv_erp, ' ||
                         '                         apps.mtl_system_items_b@mdims2mderp        mtl, ' ||
                         '                         cims.t_so_header                           so ' ||
                         '                   where 1 = 1 ' ||
                         '                     and inv_erp.inventory_item_id = mtl.inventory_item_id ' ||
                         '                     and inv_erp.organization_id = mtl.organization_id ' ||
                         '                     and inv_erp.transaction_reference = ' ||
                         '                         to_char(so.erp_so_id) ' ||
                         '                     and inv_erp.subinventory_code=so.middle_inv_code  ' ||
                         '                     and inv_erp.source_code = ''ORDER ENTRY'' ' ||
                         '                     and inv_erp.transaction_date > ' ||
                         '                         to_date(''' ||
                         in_start_date_f || ''', ''yyyy-mm-dd'') ' ||
                         '                     and inv_erp.transaction_date < ' ||
                         '                         to_date(''' ||
                         in_end_date_f || ''', ''yyyy-mm-dd'') ' ||
                         '                     and so.entity_id=' ||
                         in_entity_id_f ||
                        
                        -----'                     and exists(select 1 from cims.t_inv_organization p where p.entity_id='||in_entity_id_f||' and p.organization_id=inv_erp.organization_id) '||
                         '                     and inv_erp.organization_id in (select p.organization_id from cims.t_inv_organization p where p.entity_id=' ||
                         in_entity_id_f || ') ' ||
                        --'                     and exists '||
                        --'                         (select 1 from cims.t_inv_inventories inv  where inv.inventory_code = inv_erp.subinventory_code '||
                        --'                          and inv.organization_id = inv_erp.organization_id and inv.entity_id = '||in_entity_id_f||') '||
                         '                     and exists (select 1 from cims.t_so_line_detail sd where sd.so_header_id = so.so_header_id and sd.erp_so_line_id = inv_erp.trx_source_line_id) ' ||
                         '                     and exists ' ||
                         '                   (select period_l.bill_status_code, so.so_num ' ||
                         '                            from cims.t_inv_bill_types       bill_type, ' ||
                         '                                 cims.t_inv_bill_period_line period_l ' ||
                         '                           where so.bill_type_id = bill_type.bill_type_id ' ||
                         '                             and bill_type.bill_period_head_id = ' ||
                         '                                 period_l.bill_period_head_id ' ||
                         '                             and so.entity_id = ' ||
                         in_entity_id_f ||
                         '                             and bill_type.entity_id = ' ||
                         in_entity_id_f ||
                         '                             and period_l.bill_status_code = ''' ||
                         in_status_end_f || ''' ' ||
                         '                             and period_l.transaction_flag = ''Y'' ' ||
                         '                             and so.entity_id = ' ||
                         in_entity_id_f || ') ' ||
                         '                     and not exists ' ||
                         '                   (select 1 ' ||
                         '                            from cims.t_inv_taction_reconciliation recc ' ||
                         '                           where recc.entity_id = ' ||
                         in_entity_id_f ||
                         '                             and recc.business_num = so.so_num ' ||
                         '                             and recc.reconciliation_type = ''SO02'') ' ||
                         '                        and exists ' ||
                         '                        (select nvl(pe.entity_value, pl.default_value) ' ||
                         '                            from cims.t_bd_param_list pl, cims.t_bd_param_entity pe ' ||
                         '                          where pl.param_code = ''SO_AR_PUSH_OR_PULL'' ' ||
                         '                           and pe.param_list_id(+) = pl.param_list_id ' ||
                         '                           and pe.entity_id(+) = so.entity_id ' ||
                         '                           and (nvl(pe.entity_value, pl.default_value) = ''PUSH'' or ' ||
                         '                            (nvl(pe.entity_value, pl.default_value) = ''MIXED'' and  ' ||
                         '                            so.erp_subinv_code like ''S%'')))  ' ||
                         '   union all   ' ||
                         '            select ''GERP'' sys_name, ' ||
                         '                         so.so_num bill_no, ' ||
                        --'                         inv_erp.subinventory_code inv_code, ' ||
                         '                         so.middle_inv_code  inv_code, ' ||
                         '                         mtl.segment1 item_code, ' ||
                         '                         inv_erp.transaction_quantity gerp_qty, ' ||
                         '                         0 cims_qty ' ||
                         '                    from apps.mtl_material_transactions@mdims2mderp inv_erp, ' ||
                         '                         apps.mtl_system_items_b@mdims2mderp        mtl, ' ||
                         '                         apps.oe_order_headers_all@mdims2mderp oe,   ' ||
                         '                         cims.t_so_header                           so ' ||
                         '                   where 1 = 1 ' ||
                         '                     and inv_erp.inventory_item_id = mtl.inventory_item_id ' ||
                         '                     and inv_erp.organization_id = mtl.organization_id ' ||
                         '                    and inv_erp.transaction_reference = ' ||
                         '                         to_char(oe.header_id) ' ||
                         '                     and inv_erp.source_code = ''ORDER ENTRY'' ' ||
                         '                     and oe.attribute13 = so.so_num ' ||
                         '                     and oe.attribute11=''CIMS'' ' ||
                         '                     and inv_erp.transaction_date > ' ||
                         '                         to_date(''' ||
                         in_start_date_f || ''', ''yyyy-mm-dd'') ' ||
                         '                     and inv_erp.transaction_date < ' ||
                         '                         to_date(''' ||
                         in_end_date_f || ''', ''yyyy-mm-dd'') ' ||
                         '                      and so.entity_id=' ||
                         in_entity_id_f ||
                        --'                      and inv_erp.subinventory_code=so.middle_inv_code  ' || --by zxs 取消子库校验 2015-0920
                        --'                     and exists '||
                        --'                         (select 1 from cims.t_inv_inventories inv  where inv.inventory_code = so.middle_inv_code '||
                        --'                          and inv.organization_id = inv_erp.organization_id and inv.entity_id = '||in_entity_id_f||') '||
                        --'                     and exists (select 1 from cims.t_so_line_detail sd where sd.so_header_id = so.so_header_id and sd.erp_so_line_id = inv_erp.trx_source_line_id) '||
                        -----'                     and exists(select 1 from cims.t_inv_organization p where p.entity_id='||in_entity_id_f||' and p.organization_id=inv_erp.organization_id) '||
                         '                     and inv_erp.organization_id in (select p.organization_id from cims.t_inv_organization p where p.entity_id=' ||
                         in_entity_id_f || ') ' ||
                         '                     and exists ' ||
                         '                   (select period_l.bill_status_code, so.so_num ' ||
                         '                            from cims.t_inv_bill_types       bill_type, ' ||
                         '                                 cims.t_inv_bill_period_line period_l ' ||
                         '                           where so.bill_type_id = bill_type.bill_type_id ' ||
                         '                             and bill_type.bill_period_head_id = ' ||
                         '                                 period_l.bill_period_head_id ' ||
                         '                             and so.entity_id = ' ||
                         in_entity_id_f ||
                         '                             and bill_type.entity_id = ' ||
                         in_entity_id_f ||
                         '                             and period_l.bill_status_code = ''' ||
                         in_status_end_f || ''' ' ||
                         '                             and period_l.transaction_flag = ''Y'' ' ||
                         '                             and so.entity_id = ' ||
                         in_entity_id_f || ') ' ||
                         '                     and not exists ' ||
                         '                   (select 1 ' ||
                         '                            from cims.t_inv_taction_reconciliation recc ' ||
                         '                           where recc.entity_id = ' ||
                         in_entity_id_f ||
                         '                             and recc.business_num = so.so_num ' ||
                         '                             and recc.reconciliation_type = ''SO02'') ' ||
                         '                     and exists ' ||
                         '                        (select nvl(pe.entity_value, pl.default_value) ' ||
                         '                            from cims.t_bd_param_list pl, cims.t_bd_param_entity pe ' ||
                         '                          where pl.param_code = ''SO_AR_PUSH_OR_PULL'' ' ||
                         '                           and pe.param_list_id(+) = pl.param_list_id ' ||
                         '                           and pe.entity_id(+) = so.entity_id ' ||
                         '                           and (nvl(pe.entity_value, pl.default_value) = ''PULL'' or ' ||
                         '                            (nvl(pe.entity_value, pl.default_value) = ''MIXED'' and  ' ||
                         '                            so.erp_subinv_code not like ''S%'' )))  ' ||
                         '                  union all ' ||
                         '                  select ''GERP'' sys_name, ' ||
                         '                         so.so_num bill_no, ' ||
                         '                         inv_erp.subinventory_code inv_code, ' ||
                         '                         mtl.segment1 item_code, ' ||
                         '                         inv_erp.transaction_quantity gerp_qty, ' ||
                         '                         0 cims_qty ' ||
                         '                    from apps.mtl_material_transactions@mdims2mderp inv_erp, ' ||
                         '                         apps.mtl_system_items_b@mdims2mderp        mtl, ' ||
                         '                         cims.t_so_header                           so ' ||
                         '                   where 1 = 1 ' ||
                         '                     and inv_erp.source_code = ''RCV'' ' ||
                         '                     and inv_erp.inventory_item_id = mtl.inventory_item_id ' ||
                         '                     and inv_erp.organization_id = mtl.organization_id ' ||
                         '                     and inv_erp.transaction_date > ' ||
                         '                         to_date(''' ||
                         in_start_date_f || ''', ''yyyy-mm-dd'') ' ||
                         '                     and inv_erp.transaction_date < ' ||
                         '                         to_date(''' ||
                         in_end_date_f || ''', ''yyyy-mm-dd'') ' ||
                         '                     and so.entity_id = ' ||
                         in_entity_id_f ||
                         '                     and inv_erp.subinventory_code=so.middle_inv_code  ' ||
                        -----  '                     and exists(select 1 from cims.t_inv_organization p where p.entity_id='||in_entity_id_f||' and p.organization_id=inv_erp.organization_id) '||
                         '                     and inv_erp.organization_id in (select p.organization_id from cims.t_inv_organization p where p.entity_id=' ||
                         in_entity_id_f || ') ' ||
                        --'                     and exists '||
                        --'                         (select 1 from cims.t_inv_inventories inv  where inv.inventory_code = inv_erp.subinventory_code '||
                        --'                          and inv.organization_id = inv_erp.organization_id and inv.entity_id = '||in_entity_id_f||') '||
                         '                     and exists (select 1 from cims.t_so_line_detail sd where sd.so_header_id = so.so_header_id and sd.erp_so_line_id = inv_erp.trx_source_line_id) ' ||
                         '                     and exists ' ||
                         '                   (select period_l.bill_status_code, so.so_num ' ||
                         '                            from cims.t_inv_bill_types       bill_type, ' ||
                         '                                 cims.t_inv_bill_period_line period_l ' ||
                         '                           where so.bill_type_id = bill_type.bill_type_id ' ||
                         '                             and bill_type.bill_period_head_id = ' ||
                         '                                 period_l.bill_period_head_id ' ||
                         '                             and so.entity_id = ' ||
                         in_entity_id_f ||
                         '                             and bill_type.entity_id = ' ||
                         in_entity_id_f ||
                         '                             and period_l.bill_status_code = ''' ||
                         in_status_end_f ||
                         '''                   and period_l.transaction_flag = ''Y'') ' ||
                         '                     and not exists ' ||
                         '                   (select 1 ' ||
                         '                            from cims.t_inv_taction_reconciliation recc ' ||
                         '                           where recc.entity_id = ' ||
                         in_entity_id_f ||
                         '                             and recc.business_num = so.so_num ' ||
                         '                             and recc.reconciliation_type = ''SO02'') ' ||
                         '                    and exists ' ||
                         '                        (select nvl(pe.entity_value, pl.default_value) ' ||
                         '                            from cims.t_bd_param_list pl, cims.t_bd_param_entity pe ' ||
                         '                          where pl.param_code = ''SO_AR_PUSH_OR_PULL'' ' ||
                         '                           and pe.param_list_id(+) = pl.param_list_id ' ||
                         '                           and pe.entity_id(+) = so.entity_id ' ||
                         '                           and (nvl(pe.entity_value, pl.default_value) = ''PUSH'' or ' ||
                         '                            (nvl(pe.entity_value, pl.default_value) = ''MIXED'' and ' ||
                         '                            so.erp_subinv_code like ''S%'' )))  ' ||
                         '                  union all ' ||
                         '                  select ''CIMS'' sys_name, ' ||
                         '                         invh.business_num bill_no, ' ||
                         '                         invh.inventory_code inv_code, ' ||
                         '                         invh.item_code, ' ||
                         '                         0 gerp_qty, ' ||
                         '                         invh.transaction_quantity cims_qty ' ||
                         '                    from cims.t_inv_transaction_history invh ' ||
                         '                   where invh.business_state = ''' ||
                         in_status_end_f || ''' ' ||
                         '                     and invh.transaction_date >= ' ||
                         '                         to_date(''' ||
                         in_start_date_f || ''', ''yyyy-mm-dd'') ' ||
                         '                     and invh.transaction_date < ' ||
                         '                         to_date(''' ||
                         in_end_date_f || ''', ''yyyy-mm-dd'') ' ||
                         '                     and invh.entity_id =  ' ||
                         in_entity_id_f ||
                         '                     and exists ' ||
                         '                   (select period_l.bill_status_code, so.so_num ' ||
                         '                            from cims.t_so_header            so, ' ||
                         '                                 cims.t_inv_bill_types       bill_type, ' ||
                         '                                 cims.t_inv_bill_period_line period_l ' ||
                         '                           where so.bill_type_id = bill_type.bill_type_id ' ||
                         '                             and bill_type.bill_period_head_id = ' ||
                         '                                 period_l.bill_period_head_id ' ||
                         '                             and so.entity_id = ' ||
                         in_entity_id_f ||
                         '                             and bill_type.entity_id = ' ||
                         in_entity_id_f ||
                         '                             and period_l.bill_status_code = ''' ||
                         in_status_end_f || ''' ' ||
                         '                             and not exists ' ||
                         '                           (select 1 ' ||
                         '                                    from cims.t_inv_taction_reconciliation recc ' ||
                         '                                   where recc.entity_id =' ||
                         in_entity_id_f ||
                         '                                     and recc.business_num = so.so_num ' ||
                         '                                     and recc.reconciliation_type = ''SO02'') ' ||
                         '                             and period_l.transaction_flag = ''Y'' ' ||
                         '                             and so.so_num = invh.business_num ' ||
                         '                             and so.entity_id = ' ||
                         in_entity_id_f || ')) ' ||
                         '           group by bill_no, inv_code, item_code) bill_all ' ||
                         '   where 1 = 1 ';
  
    return return_result_sql;
  end;

  -- 返回库存事务对账SQL-SO生成
  function f_get_not_inv_sql(in_entity_id_f in number,
                             in_bill_no_f   in varchar2,
                             in_inv_code_f  in varchar2,
                             in_item_code_f in varchar2,
                             in_status_f    in varchar2,
                             in_qty_f       in number,
                             in_bill_type_f in varchar2) return varchar2 is
    return_result_sql varchar2(4000);
  
    str_select_sql_f varchar2(2000);
  
    str_status_meaning_f varchar2(100);
    str_msg_f            varchar2(2000);
    str_status_f         varchar2(100);
    i_qty_temp_f         number;
  begin
    return_result_sql := null;
  
    select codelist.code_name
      into str_status_meaning_f
      from cims.up_codelist codelist
     where codelist.codetype = 'SO_STATUS'
       and codelist.code_value = in_status_f
       and rownum < 2;
  
    if in_status_f = str_status_end then
      str_status_f         := '02';
      str_status_meaning_f := '结算';
    else
      str_status_f         := '01';
      str_status_meaning_f := '生成';
    end if;
  
    str_msg_f := 'SO' || str_status_meaning_f || '有差异，单据在' ||
                 str_status_meaning || '时CIMS未产生库存事务,数量' ||
                 in_qty_f;
  
    select nvl(sum(inv_erp.transaction_quantity), 0) qty
      into i_qty_temp_f
      from apps.mtl_material_transactions@mdims2mderp inv_erp,
           apps.mtl_system_items_b@mdims2mderp        mtl
     where 1 = 1
       and inv_erp.transaction_reference = in_bill_no_f
       and mtl.segment1 = in_item_code_f
       and inv_erp.subinventory_code = in_inv_code_f
       and inv_erp.inventory_item_id = mtl.inventory_item_id
       and inv_erp.organization_id = mtl.organization_id;
  
    str_select_sql_f := ' select ''' || in_bill_no_f || ''' bill_no ,''' ||
                        in_inv_code_f || ''' inv_code,''' || in_item_code_f ||
                        ''' item_code,''' || in_bill_type_f ||
                        ''' bill_type,0 cims_qty,' || i_qty_temp_f ||
                        ' gerp_qty,substr(''' || str_msg_f || ''',1,' ||
                        i_remark_length || ') remark ' || ' from dual ';
  
    str_insert_sql := ' insert into cims.t_inv_taction_reconciliation ' ||
                      '  (entity_id, ' || '   business_type, ' ||
                      '   business_num, ' || '   reconciliation_time, ' ||
                      '   reconciliation_flag, ' || '   status, ' ||
                      '   inv_code, ' || '   item_code, ' ||
                      '   cims_qty, ' || '   gerp_qty, ' || '   remark, ' ||
                      '   created_by, ' || '   creation_date, ' ||
                      '   last_updated_by, ' ||
                      '   last_update_date,reconciliation_type) ' ||
                      ' select ' || in_entity_id_f ||
                      ' entity_id, bill_type  business_type, ''' ||
                      in_bill_no_f || '''   business_num, ' ||
                      ' sysdate  reconciliation_time, ' ||
                      ' ''00''  reconciliation_flag, ' ||
                      ' ''01''  status, ' || '   inv_code, ' ||
                      '   item_code, ' || '   cims_qty, ' ||
                      '   gerp_qty, ' || '   remark, ' ||
                      ' ''SYS''  created_by, ' ||
                      ' sysdate  creation_date, ' ||
                      ' ''SYS''  last_updated_by, ' ||
                      ' sysdate  last_update_date,''SO' || str_status_f ||
                      ''' reconciliation_type from (' || str_select_sql_f ||
                      ') bill_all ' || '  where 1=1 ' ||
                      '  and not exists(select 1 from cims.t_inv_taction_reconciliation recc' ||
                      '  where recc.entity_id=' || in_entity_id_f ||
                      ' and recc.business_num=bill_all.bill_no ' ||
                      ' and recc.inv_code=bill_all.inv_code ' ||
                      ' and recc.reconciliation_type = ''SO' ||
                      str_status_f ||
                      ''' and recc.item_code=bill_all.item_code)';
  
    return return_result_sql;
  end;

  -- 返回库存事务数量-反向销售
  function f_get_qty_bysale(in_entity_id_f       in number,
                            in_bill_no_f         in varchar2,
                            in_inv_code_f        in varchar2,
                            in_item_code_f       in varchar2,
                            in_organization_id_f number) return number is
    return_qty      number;
    return_sql      varchar2(4000);
    return_segment1 varchar2(50);
    return_temp     number;
  begin
    return_qty      := 0;
    return_temp     := 0;
    return_segment1 := null;
  
    select count(segment1)
      into return_temp
      from apps.po_headers_all@mdims2mderp
     where attribute13 = in_bill_no_f;
  
    if return_temp > 0 then
      select segment1
        into return_segment1
        from apps.po_headers_all@mdims2mderp
       where attribute13 = in_bill_no_f;
    end if;
  
    if return_segment1 is not null then
      return_sql := 'select nvl(sum(inv_erp.transaction_quantity),0) ' ||
                    '  from apps.po_headers_all@mdims2mderp            po_erp, ' ||
                    '       apps.rcv_transactions@mdims2mderp          po_rcv, ' ||
                    '       apps.mtl_material_transactions@mdims2mderp inv_erp, ' ||
                    '       apps.mtl_system_items_b@mdims2mderp        mtl ' ||
                    ' where po_erp.po_header_id = po_rcv.po_header_id ' ||
                    '   and inv_erp.transaction_source_id = po_rcv.po_header_id ' ||
                    '   and inv_erp.source_line_id = po_rcv.transaction_id ' ||
                    '   and inv_erp.rcv_transaction_id = po_rcv.transaction_id ' ||
                    '   and inv_erp.inventory_item_id = mtl.inventory_item_id ' ||
                    '   and inv_erp.organization_id = mtl.organization_id ' ||
                    '   and po_rcv.transaction_type = ''DELIVER'' ' ||
                    '   and po_erp.segment1 = ''' || in_item_code_f ||
                    '''   and inv_erp.subinventory_code = ''' ||
                    in_inv_code_f || '''   and mtl.segment1 = ''' ||
                    return_segment1 || ''' ';
    
      execute immediate return_sql
        into return_qty;
    end if;
  
    return return_qty;
  end;

  -- 返回库存事务数量-源单退回
  function f_get_qty_byreturn(in_entity_id_f       in number,
                              in_bill_no_f         in varchar2,
                              in_inv_code_f        in varchar2,
                              in_item_code_f       in varchar2,
                              in_organization_id_f number) return number is
    return_qty                number;
    return_sql                varchar2(4000);
    return_segment1           varchar2(50);
    return_rcv_transaction_id number;
    return_req_line_id        number;
  begin
    return_qty := 0;
  
    /*select count(rcv_transaction_id)
     into return_rcv_transaction_id
     from apps.cux_icp_logist_req_lines_v@mdims2mderp po_icp_erp
    where po_icp_erp.source_header = in_bill_no_f
      and supplier_item_num = in_item_code_f
      and supplier_sorce_subinv = in_inv_code_f;*/
    select count(po_icp_erp_l.req_line_id)
      into return_req_line_id
      from apps.cux_icp_logist_req_lines_v@mdims2mderp po_icp_erp_l
     where 1 = 1
       and supplier_item_num = in_item_code_f
       and po_icp_erp_l.source_header = in_bill_no_f;
  
    if return_req_line_id > 0 then
      select req_line_id
        into return_req_line_id
        from apps.cux_icp_logist_req_lines_v@mdims2mderp po_icp_erp
       where po_icp_erp.source_header = in_bill_no_f
         and supplier_item_num = in_item_code_f
         and rownum < 2;
    
      if return_req_line_id > 0 then
        return_sql := ' select nvl(sum(inv_erp.transaction_quantity),0) ' ||
                      ' from apps.mtl_material_transactions@mdims2mderp inv_erp, apps.mtl_system_items_b@mdims2mderp mtl ' ||
                      ' where 1 = 1 ' ||
                      '  and inv_erp.attribute11=''CIMS'' ' ||
                      '  and inv_erp.transaction_reference = ''' ||
                      return_req_line_id ||
                      '''  and inv_erp.inventory_item_id = mtl.inventory_item_id ' ||
                      '  and inv_erp.organization_id = mtl.organization_id ' ||
                      '  and inv_erp.subinventory_code=''' || in_inv_code_f ||
                      '''  and mtl.segment1=''' || in_item_code_f || ''' ';
      
        execute immediate return_sql
          into return_qty;
      
      end if;
    
    end if;
  
    if (in_bill_no_f = '140017008') and (in_item_code_f = '12874000000267') then
      dbms_output.put_line('return_qty:' || return_qty);
    end if;
  
    return return_qty;
  end;
begin
  -- Test statements here

  --v_entity_id := 10;
  v_entity_id := I_ENTITY_ID;
  ----- 需核对厨电销售单据，时间先提前，全部核对一次；后续版本改为90天
  str_start_date := to_char(sysdate - 180, 'yyyy-mm-dd');
  --str_end_date   := '2015-01-22';
  str_end_date := to_char(sysdate + 1, 'yyyy-mm-dd');

  b_immediate_commit := true; -- 全过程处理一次完成

  str_status := '00';

  str_status_end := '12'; --settle status

  str_organization_ids := null;
  -- 获取SO上的库存组织
  for c_get_organization_id01 in c_get_organization_ids(v_entity_id) loop
    if str_organization_ids is null then
      str_organization_ids := c_get_organization_id01.organization_id;
    else
      str_organization_ids := str_organization_ids || ',' ||
                              c_get_organization_id01.organization_id;
    end if;
  end loop;

  -- 无库存组织ID，则不会核对
  if str_organization_ids is null then
    return;
  end if;

  -- 处理对账失败单据
  str_delete_sql := ' delete cims.t_inv_taction_reconciliation rec ' ||
                    '  where rec.entity_id = ' || v_entity_id ||
                    '   and rec.reconciliation_type like ''SO%''' ||
                    '   and exists (select 1 ' ||
                    '          from cims.t_inv_taction_reconciliation rec2 ' ||
                    '         where rec.business_num = rec2.business_num ' ||
                    '           and rec2.entity_id = ' || v_entity_id ||
                    '           and rec2.status = ''01''' ||
                    '           and rec2.reconciliation_type=rec.reconciliation_type' ||
                    '           and rec2.reconciliation_type like ''SO%'')  ';

  execute immediate str_delete_sql;
  if b_immediate_commit then
    commit;
  end if;

  --记录开始时间,用于限定更新范围
  select to_char(sysdate, 'yyyy-mm-dd hh24:mi:ss')
    into str_start_time
    from dual;

  -- 获取SO生成
  str_insert_sql1 := f_get_so01_sql(v_entity_id,
                                    str_status_end,
                                    str_start_date,
                                    str_end_date);

  -- SO生成
  --dbms_output.put_line(str_select_sql);
  dbms_output.put_line(to_char(sysdate, 'yyyy-mm-dd hh24:mi:ss'));
  --execute immediate str_select_sql;
  if str_insert_sql1 is not null then
    execute immediate str_insert_sql1;
    if b_immediate_commit then
      commit;
    end if;
  end if;
  dbms_output.put_line(to_char(sysdate, 'yyyy-mm-dd hh24:mi:ss'));

  -- 获取SO变更
  str_insert_sql2 := f_get_so02_sql(v_entity_id,
                                    str_status_end,
                                    str_start_date,
                                    str_end_date);

  -- SO结算    
  --dbms_output.put_line('Test01');  
  --dbms_output.put_line(str_insert_sql2);   
  if str_insert_sql2 is not null then
    execute immediate str_insert_sql2;
    if b_immediate_commit then
      commit;
    end if;
  end if;

  --dbms_output.put_line('Test02');
  --记录结束时间
  select to_char(sysdate, 'yyyy-mm-dd hh24:mi:ss')
    into str_end_time
    from dual;

  dbms_output.put_line(str_start_time);
  dbms_output.put_line(str_end_time);

  for reconciliation_return_diff01 in c_reconciliation_return_diff12(v_entity_id,
                                                                     str_start_time,
                                                                     str_end_time) loop
  
    i_qty_temp := 0;
  
    -- 更新反向销售数量
    if reconciliation_return_diff01.return_mode = 2 then
      i_qty_temp := f_get_qty_byreturn(v_entity_id,
                                       reconciliation_return_diff01.bill_no,
                                       reconciliation_return_diff01.inv_code,
                                       reconciliation_return_diff01.item_code,
                                       0);
    end if;
  
    if reconciliation_return_diff01.return_mode = 3 then
      -- 更新源单退回数量
      i_qty_temp := f_get_qty_bysale(v_entity_id,
                                     reconciliation_return_diff01.bill_no,
                                     reconciliation_return_diff01.inv_code,
                                     reconciliation_return_diff01.item_code,
                                     0);
    
    end if;
  
    if i_qty_temp > 0 then
      str_update_sql := ' update cims.t_inv_taction_reconciliation rec ' ||
                        ' set remark=''重新获取数量'',rec.last_update_date=sysdate+1/(60*24) ' ||
                        ' ,rec.gerp_qty=' || i_qty_temp ||
                        ' where rec.business_num=''' ||
                        reconciliation_return_diff01.bill_no ||
                        '''  and rec.status=''01'' ' ||
                        '    and reconciliation_type = ''SO02''' ||
                        '    and rec.inv_code=''' ||
                        reconciliation_return_diff01.inv_code ||
                        '''    and rec.item_code=''' ||
                        reconciliation_return_diff01.item_code || ''' ';
      -- 没有差异
      if i_qty_temp = reconciliation_return_diff01.cims_qty then
        str_update_sql := ' update cims.t_inv_taction_reconciliation rec ' ||
                          ' set remark=''单据结算，没有差异'',rec.last_update_date=sysdate+1/(60*24) ' ||
                          ' ,rec.status=''00'',rec.gerp_qty=' || i_qty_temp ||
                          ' where rec.business_num=''' ||
                          reconciliation_return_diff01.bill_no ||
                          '''  and reconciliation_type = ''SO02''' ||
                          '    and rec.inv_code=''' ||
                          reconciliation_return_diff01.inv_code ||
                          '''    and rec.item_code=''' ||
                          reconciliation_return_diff01.item_code || ''' ';
      end if;
    
      execute immediate str_update_sql;
      if b_immediate_commit then
        commit;
      end if;
    end if;
  end loop;

  --更新SO生成错误状态
  for reconciliation_diff11_01 in c_reconciliation_diff11(v_entity_id,
                                                          str_start_time,
                                                          str_end_time) loop
  
    --dbms_output.put_line('ok');
  
    str_msg                  := null;
    str_qty_field_updated    := null;
    str_intf_err             := null;
    str_status_field_updated := null;
    i_qty_updated            := 0;
  
    -- CIMS有库存事务，GERP没有库存事务，通常日期不同，重新计算      
    -- if (reconciliation_diff11_01.cims_qty <> 0) and
    --  (reconciliation_diff11_01.gerp_qty = 0) then
  
    --dbms_output.put_line(reconciliation_diff11_01.bill_no);
    ----获取SO生成库存事务不成功原因-子库存转移
    str_msg := f_get_intf_result(v_entity_id,
                                 reconciliation_diff11_01.bill_no);
    -------------- 
    -- end if; -- end CIMS有库存事务 if (reconciliation_diff11_01.cims_qty <> 0)
  
    if (str_msg is not null) then
      str_update_sql := ' update cims.t_inv_taction_reconciliation rec ' ||
                        ' set remark=substr(''' || str_msg || ''',1,' ||
                        i_remark_length ||
                        '),rec.last_update_date=sysdate ' ||
                        ' where rec.business_num=''' ||
                        reconciliation_diff11_01.bill_no ||
                        '''  and rec.status=''01'' ' ||
                        '    and reconciliation_type = ''SO01''';
    
      --dbms_output.put_line(str_update_sql);
    
      execute immediate str_update_sql;
      if b_immediate_commit then
        commit;
      end if;
    end if;
  
  -- reconciliation_diff11_01
  --dbms_output.put_line(reconciliation_diff11_01.bill_no);
  
  end loop; -- end 更新SO生成错误状态 for reconciliation_diff11_01

  --更新SO结算错误状态
  for reconciliation_diff12_01 in c_reconciliation_diff12(v_entity_id,
                                                          str_start_time,
                                                          str_end_time) loop
  
    str_msg                  := null;
    str_qty_field_updated    := null;
    str_status_field_updated := null;
    i_qty_updated            := 0;
  
    --dbms_output.put_line('bill_no:' || reconciliation_diff12_01.bill_no);
  
    -- CIMS有库存事务，GERP没有库存事务，通常日期不同，重新计算      
    -- 无库存事务，单据未结算，核对单据是否已引入   
    str_msg := f_get_bill_result(v_entity_id,
                                 reconciliation_diff12_01.bill_no,
                                 reconciliation_diff12_01.org_id,
                                 reconciliation_diff12_01.erp_organization_code);
  
    if (str_msg is not null) then
      str_update_sql := ' update cims.t_inv_taction_reconciliation rec ' ||
                        ' set rec.remark=substr(''' || str_msg || ''',1,' ||
                        i_remark_length ||
                        '),rec.last_update_date=sysdate ' ||
                        ' where rec.business_num=''' ||
                        reconciliation_diff12_01.bill_no ||
                        ''' and reconciliation_type = ''SO02'' ' ||
                        '   and status=''01'' ';
    
      execute immediate str_update_sql;
      if b_immediate_commit then
        commit;
      end if;
    end if;
  
  -- reconciliation_diff12_01
  --dbms_output.put_line(reconciliation_diff11_01.bill_no);
  
  end loop; -- end 更新SO错误状态 for reconciliation_diff11_01

  -- CIMS无库存事务
  str_select_sql := null;
  for so_inv_cims_nexists_01 in so_inv_cims_nexists(v_entity_id,
                                                    str_status_end) loop
  
    -- str_status_meaning
  
    ---- 返回执行的SQL
    str_insert_sql := f_get_not_inv_sql(v_entity_id,
                                        so_inv_cims_nexists_01.bill_no,
                                        so_inv_cims_nexists_01.inv_code,
                                        so_inv_cims_nexists_01.item_code,
                                        so_inv_cims_nexists_01.status,
                                        so_inv_cims_nexists_01.qty,
                                        so_inv_cims_nexists_01.bill_type);
  
    --dbms_output.put_line(str_insert_sql);
  
    if str_insert_sql is not null then
      execute immediate str_insert_sql;
    
      if b_immediate_commit then
        commit;
      end if;
    end if;
  
  end loop;

  commit;

end P_INV_SO_TRANSACTION;
/

