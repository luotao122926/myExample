create PACKAGE      PKG_SO_PUB IS
  /*----------------------------------------------------------------
  *         包：PKG_SO_PUB
  *   创建日期：2014-07-05
  *     创建者：廖丽章
  *   功能说明：销售管理公用存储过程和函数包。
  *
  *   过程成功：P_RESULT = 0
  *             P_ERR_MSG = 'SUCCESS';
  *
  *   过程失败：P_RESULT < -20000;
  *             P_ERR_MSG = 过程异常失败的提示信息
  *
  */ ----------------------------------------------------------------

  /*****以下为常量定义*****/
  V_NL      CONSTANT VARCHAR2(2) := CHR(13) || CHR(10); --换行
  V_RESULT  CONSTANT NUMBER := 0; --成功返回
  V_SUCCESS CONSTANT VARCHAR2(10) := 'SUCCESS';
  V_ERR_MSG CONSTANT VARCHAR2(10) := '';
  V_BIZ_EXCEPTION EXCEPTION; --自定义业务异常
  V_YES CONSTANT CHAR(1) := 'Y';
  V_NO  CONSTANT CHAR(1) := 'N';
  
  --性能优化，默认处理最近有更新的单据
  V_SO_PERFORMANCE_OPT_RANGE CONSTANT NUMBER := 35;
  
  --销售单据价格（结算）默认有效精度 
  V_DEFAULT_PRECISE_SCALE    CONSTANT NUMBER := 6;

  /*mark by shengy 20150120  */

  --V_TRADE_MODE     CONSTANT VARCHAR2(10) := ''; --交易模式：推式或拉式
  V_TRADE_MODE_PUSH CONSTANT VARCHAR2(10) := 'PUSH'; --交易模式：推式（家用空调）
  V_TRADE_MODE_PULL CONSTANT VARCHAR2(10) := 'PULL'; --交易模式：拉式（厨房电器）
  V_TRADE_MODE_MIXED CONSTANT VARCHAR2(10) := 'MIXED'; --交易模式：推拉结合（中央空调、热水器等）
  V_CREATED_BY_SYS       VARCHAR2(32) := 'SYS'; --默认创建人
  V_CREATED_BY_SYS_NANME VARCHAR2(100) := 'CIMS系统'; --默认创建人

  V_CREATED CHAR(2) := '10'; --财务单状态：10制单，11已审核，12已结算
  V_AUDITED CHAR(2) := '11'; --财务单状态：10制单，11已审核，12已结算
  V_SETTLED CHAR(2) := '12'; --财务单状态：10制单，11已审核，12已结算


  --销售单据源类型编码
  V_BIZ_SRC_BILL_SO              CONSTANT CHAR(4) := '1001'; --销售单
  V_BIZ_SRC_BILL_SO_RED          CONSTANT CHAR(4) := '1002'; --销售红冲单
  V_BIZ_SRC_BILL_RETURN          CONSTANT CHAR(4) := '1003'; --退货单
  V_BIZ_SRC_BILL_RETURN_RED      CONSTANT CHAR(4) := '1004'; --退货红冲单
  V_BIZ_SRC_BILL_SO_DISCOUNT     CONSTANT CHAR(4) := '1005'; --销售折让单
  V_BIZ_SRC_BILL_SO_DISCOUNT_RED CONSTANT CHAR(4) := '1006'; --销售折让红冲单
  V_BIZ_SRC_BILL_DISCOUNT        CONSTANT CHAR(4) := '1007'; --折让证明单
  V_BIZ_SRC_BILL_DISCOUNT_RED    CONSTANT CHAR(4) := '1008'; --折让证明红冲单
  V_BIZ_SRC_BILL_RATE            CONSTANT CHAR(4) := '1009'; --扣率折让单
  V_BIZ_SRC_BILL_RATE_RED        CONSTANT CHAR(4) := '1010'; --扣率折让红冲单
  V_BIZ_SRC_BILL_RETURN_APPLY    CONSTANT CHAR(4) := '1011'; --退货申请
  V_BIZ_SRC_BILL_AD_PRICE        CONSTANT CHAR(4) := '1012'; --价格调账申请单
  V_BIZ_SRC_BILL_AD_SPLIT        CONSTANT CHAR(4) := '1013'; --拆单调账申请单
  V_BIZ_SRC_BILL_AD_SO_RED       CONSTANT CHAR(4) := '1014'; --销售红冲申请单
  V_BIZ_SRC_BILL_AD_RT_RED       CONSTANT CHAR(4) := '1015'; --退货红冲申请单

  --来源类型，01计划订单 02提货订单 03调拨订单 04促销品 09采购单据 10调拨单据 11备货单据 12财务单据 13退货申请 14F单
  V_SRC_TYPE_01 CONSTANT CHAR(2) := '01'; --计划订单
  V_SRC_TYPE_02 CONSTANT CHAR(2) := '02'; --提货订单
  V_SRC_TYPE_03 CONSTANT CHAR(2) := '03'; --调拨订单
  V_SRC_TYPE_04 CONSTANT CHAR(2) := '04'; --促销品
  V_SRC_TYPE_09 CONSTANT CHAR(2) := '09'; --采购单据
  V_SRC_TYPE_10 CONSTANT CHAR(2) := '10'; --调拨单据
  V_SRC_TYPE_11 CONSTANT CHAR(2) := '11'; --备货单据
  V_SRC_TYPE_12 CONSTANT CHAR(2) := '12'; --财务单据
  V_SRC_TYPE_13 CONSTANT CHAR(2) := '13'; --退货申请单
  V_SRC_TYPE_14 CONSTANT CHAR(2) := '14'; --F单
  V_SRC_TYPE_15 CONSTANT CHAR(2) := '15'; --电商
  V_SRC_TYPE_16 CONSTANT CHAR(7) := 'SL_BILL'; --库位单
  V_SRC_TYPE_18 CONSTANT CHAR(2) := '18'; --价格调账申请单
  V_SRC_TYPE_19 CONSTANT CHAR(2) := '19'; --拆单调账申请单
  V_SRC_TYPE_21 CONSTANT CHAR(2) := '21'; --退货红冲申请单
  V_SRC_TYPE_31 CONSTANT CHAR(2) := '31'; --财务单据（销售转采购，涉及库存解锁）

  --类型标识：B1（采购中转）、B2（仓库调拨）、B3（仓库盘点）、B4（销售）、B5（推广物料）、B6（备货转销售）
  V_TYPE_FLAG_PO      CONSTANT CHAR(2) := 'B1';
  V_TYPE_FLAG_TRSF    CONSTANT CHAR(2) := 'B2';
  V_TYPE_FLAG_CHECK   CONSTANT CHAR(2) := 'B3';
  V_TYPE_FLAG_SO      CONSTANT CHAR(2) := 'B4';
  V_TYPE_FLAG_PMT     CONSTANT CHAR(2) := 'B5';
  V_TYPE_FLAG_STOCKUP CONSTANT CHAR(2) := 'B6';

  --调用ERP接口的编码
  V_ERP_TRXCODE_GEN      CONSTANT VARCHAR2(10) := 'GEN'; --GEN(SO生成)
  V_ERP_TRXCODE_INV      CONSTANT VARCHAR2(10) := 'INV'; --INV(SO挑库)
  V_ERP_TRXCODE_SHIP     CONSTANT VARCHAR2(10) := 'SHIP'; --SHIP(SO发运确认)
  V_ERP_TRXCODE_CHANGE   CONSTANT VARCHAR2(10) := 'CHANGE'; --CHANGE(SO变更)
  V_ERP_TRXCODE_RMA_RECV CONSTANT VARCHAR2(10) := 'RMA_RECV'; --RMA_RECV(RMA接收)
  V_ERP_TRXCODE_BOOK     CONSTANT VARCHAR2(10) := 'BOOK'; --BOOK(折让单登记)

  --关联交易模式
  V_SO_TRX_MODE_001 CONSTANT VARCHAR2(10) := 'TRX001'; --推式成品销售
  V_SO_TRX_MODE_002 CONSTANT VARCHAR2(10) := 'TRX002'; --推式销售结算
  V_SO_TRX_MODE_003 CONSTANT VARCHAR2(10) := 'TRX003'; --拉式成品销售
  V_SO_TRX_MODE_004 CONSTANT VARCHAR2(10) := 'TRX004'; --拉式源单退回
  V_SO_TRX_MODE_005 CONSTANT VARCHAR2(10) := 'TRX005'; --拉式反向销售

  --销售系统参数常量
  V_SO_BILL_TYPE_CONFIG_CHECK CONSTANT VARCHAR2(32) := 'SO_BILL_TYPE_CONFIG_CHECK';--检查销售单据类型配置是否完整。
  V_INTF_SYSTEM_TYPE          CONSTANT VARCHAR2(32) := 'PUB_FIN_SYS';--系统参数.财务接口对接系统标识 ERP：美的现有ERP系统；NC：用友NC财务系统。
  V_INTF_SYSTEM_TYPE_ERP      CONSTANT VARCHAR2(32) := 'ERP';--财务接口对接系统 ERP：美的现有ERP系统；
  V_INTF_SYSTEM_TYPE_NC       CONSTANT VARCHAR2(32) := 'NC';--财务接口对接系统标识 NC：用友NC财务系统。
  V_ARG_SO_AR_PUSH_OR_PULL    CONSTANT VARCHAR2(32) := 'SO_AR_PUSH_OR_PULL'; --营销方式是推式or拉式
  V_ARG_SO_BILLAGE_BEGIN_DATE CONSTANT VARCHAR2(32) := 'SO_BILLAGE_BEGIN_DATE'; --账龄起始日期
  V_SO_SERVICE_DIS_BILL_TYPE  CONSTANT VARCHAR2(32) := 'SO_SERVICE_DISCOUNT_BILL_TYPE';--服务类销售单折让单:服务类销售单折让单（特殊类型的销售折让单：需要增加或减少客户销售金额、却没有库存事务，而且不能在折让单管理中维护的单据。例如：暖通安装工程销售单、照明KA销售单等）
  /*****以下为自定义变量*****/
  --定义一个整型临时表类型（相当于一个整型数组）
  TYPE TYPE_ARRAY IS TABLE OF NUMBER INDEX BY BINARY_INTEGER;

  --定义异常公共信息记录集
  TYPE EXCEPTION_COMMON_INFO IS RECORD(
    BIZ_TABLE_NAME    T_SO_EXCEPTION.BIZ_TABLE_NAME%TYPE, --业务所在表
    BIZ_TABLE_NAME_CN T_SO_EXCEPTION.BIZ_TABLE_NAME_CN%TYPE, --业务所在表中文名
    BIZ_KEY_ID        T_SO_EXCEPTION.BIZ_KEY_ID%TYPE, --业务数据主键ID
    CREATED_BY        T_SO_EXCEPTION.CREATED_BY%TYPE,
    CREATION_DATE     T_SO_EXCEPTION.CREATION_DATE%TYPE,
    LAST_UPDATED_BY   T_SO_EXCEPTION.LAST_UPDATED_BY%TYPE,
    LAST_UPDATE_DATE  T_SO_EXCEPTION.LAST_UPDATE_DATE%TYPE);

  --定义异常信息记录集
  TYPE EXCEPTION_INFO IS RECORD(
    BIZ_OPER_CODE    T_SO_EXCEPTION.BIZ_OPER_CODE%TYPE, --业务操作代码：从快码表取，例如：SO_GEN销售单据生成
    BIZ_OPER_NAME    T_SO_EXCEPTION.BIZ_OPER_NAME%TYPE, --业务操作名称，例如：销售单据生成
    EXCEPTION_CODE   T_SO_EXCEPTION.EXCEPTION_CODE%TYPE, --业务异常代码
    EXCEPTION_NAME   T_SO_EXCEPTION.EXCEPTION_NAME%TYPE, --业务异常名称
    EXCEPTION_REMARK T_SO_EXCEPTION.EXCEPTION_REMARK%TYPE --业务异常描述
    );

  --定义异常记录临时表类型
  TYPE TYPE_EXCEPTION_ARRAY IS TABLE OF EXCEPTION_INFO INDEX BY BINARY_INTEGER;

  --异常信息数组
  V_ARR_EXPT_INFO TYPE_EXCEPTION_ARRAY;

  --应收发票配置记录
  TYPE AR_CONFIG IS RECORD(
    AR_CONF_ID             T_AR_CONF.AR_CONF_ID%TYPE,
    SETTLE_NEXT_MONTH_FLAG T_AR_CONF.SETTLE_NEXT_MONTH_FLAG%TYPE, --月末是否结算到下个月一号
    AR_CONF_INITIAL        T_AR_CONF.AR_CONF_INITIAL%TYPE, --应收配置始点
    AUTO_SETTLE_FLAG       T_AR_CONF.AUTO_SETTLE_FLAG%TYPE, --自动结算标志
    APPLY_FLAG             T_AR_CONF.APPLY_FLAG%TYPE, --开票申请标志
    APPROVAL_FLAG          T_AR_CONF.APPROVAL_FLAG%TYPE --开票审核标志
    );

  --定义开票申请信息记录集
  TYPE INVOICE_APPLY_INFO IS RECORD(
    INVOICE_APPLY_ID  T_AR_INVOICE_APPLY_HEADER.INVOICE_APPLY_ID%TYPE, --开票申请ID
    ENTITY_ID         T_AR_INVOICE_APPLY_HEADER.ENTITY_ID%TYPE, --主体ID
    CUSTOMER_ID       T_CUSTOMER_HEADER.CUSTOMER_ID%TYPE, --客户ID
    CUSTOMER_CODE     T_CUSTOMER_HEADER.CUSTOMER_CODE%TYPE, --客户代码
    CUSTOMER_NAME     T_CUSTOMER_HEADER.CUSTOMER_NAME%TYPE, --客户名称
    SALES_CENTER_ID   T_CUSTOMER_ORG.SALES_CENTER_ID%TYPE, --销售中心ID
    SALES_CENTER_CODE T_CUSTOMER_ORG.SALES_CENTER_CODE%TYPE, --销售中心编码
    SALES_CENTER_NAME T_CUSTOMER_ORG.SALES_CENTER_NAME%TYPE, --销售中心名称
    AUTO_SETTLE_FLAG  T_AR_CONF.AUTO_SETTLE_FLAG%TYPE --自动结算标志
    );

  --定义开票申请信息记录集数组
  TYPE ARRAY_INVOICE_APPLY_INFO IS TABLE OF INVOICE_APPLY_INFO INDEX BY BINARY_INTEGER;

  --仓库信息记录
  TYPE INV_INFO IS RECORD(
    INVENTORY_ID           T_INV_INVENTORIES.INVENTORY_ID%TYPE, --仓库ID
    INVENTORY_CODE         T_INV_INVENTORIES.INVENTORY_CODE%TYPE, --仓库编码
    INVENTORY_NAME         T_INV_INVENTORIES.INVENTORY_NAME%TYPE, --仓库名称
    NOSETTLED_INVENTORY_ID T_INV_INVENTORIES.NOSETTLED_INVENTORY_ID%TYPE, --未结算仓ID
    ONWAY_INVENTORY_ID     T_INV_INVENTORIES.ONWAY_INVENTORY_ID%TYPE, --在途仓ID
    RETURN_INVENTORY_ID    T_INV_INVENTORIES.RETURN_INVENTORY_ID%TYPE, --退货未结算仓ID，关联的退货未结算仓。
    ORGANIZATION_ID        T_INV_INVENTORIES.ORGANIZATION_ID%TYPE --库存组织ID
    );

  --库存单据类型信息记录
  TYPE INV_BILL_TYPE_INFO IS RECORD(
    BILL_TYPE_ID   T_INV_BILL_TYPES.BILL_TYPE_ID%TYPE,
    BILL_TYPE_CODE T_INV_BILL_TYPES.BILL_TYPE_CODE%TYPE,
    BILL_TYPE_NAME T_INV_BILL_TYPES.BILL_TYPE_NAME%TYPE);

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-05
  *     创建者：廖丽章
  *   功能说明：校验业务单据类型是否存在及扩展配置是否已设置
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_CHECK_BILLTYPE(P_ENTITY_ID    IN NUMBER, --主体ID
                             P_BILL_TYPE_ID IN NUMBER, --业务单据类型ID
                             P_RESULT       IN OUT NUMBER, --返回错误ID
                             P_ERR_MSG      IN OUT VARCHAR2 --返回错误信息
                             );

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-05
  *     创建者：廖丽章
  *   功能说明：红冲单原单（蓝单）校验
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_CHECK_BLUEBILL(P_ENTITY_ID        IN NUMBER, --主体ID
                             P_RED_BILL_TYPE_ID IN NUMBER, --红冲单据类型ID
                             P_BLUE_BILL_NUM    IN NUMBER, --原单（蓝单）号
                             P_RESULT           IN OUT NUMBER, --返回错误ID
                             P_ERR_MSG          IN OUT VARCHAR2 --返回错误信息
                             );

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-05
  *     创建者：廖丽章
  *   功能说明：校验营销中心是否有效
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_CHECK_SALESCENTER(P_ENTITY_ID       IN NUMBER, --主体ID
                                P_SALES_CENTER_ID IN NUMBER, --营销中心ID
                                P_RESULT          IN OUT NUMBER, --返回错误ID
                                P_ERR_MSG         IN OUT VARCHAR2 --返回错误信息
                                );

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-08-19
  *     创建者：周建刚
  *   功能说明：校验产品所属营销大类跟单据营销大类是否一致
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_CHECK_ITEM_SALES_MAIN_TYPE(P_ENTITY_ID       IN NUMBER, --主体ID
                                         P_ITEM_CODE       IN VARCHAR2,--产品编码
                                         P_SALES_MAIN_TYPE IN VARCHAR2, --营销营销大类
                                         P_RESULT          IN OUT NUMBER, --返回错误ID
                                         P_ERR_MSG         IN OUT VARCHAR2 --返回错误信息
                                );
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-05
  *     创建者：廖丽章
  *   功能说明：校验客户是否有效
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_CHECK_CUSTOMER(P_ENTITY_ID       IN NUMBER, --主体ID
                             P_SALES_CENTER_ID IN NUMBER, --营销中心ID
                             P_CUSTOMER_ID     IN NUMBER, --客户ID
                             P_RESULT          IN OUT NUMBER, --返回错误ID
                             P_ERR_MSG         IN OUT VARCHAR2 --返回错误信息
                             );

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-05
  *     创建者：廖丽章
  *   功能说明：校验仓库是否有效
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_CHECK_INVENTORY(P_INVENTORY_ID         IN NUMBER, --仓库ID
                              P_CHECK_ONWAY_FLAG     VARCHAR2, --是否校验在途仓
                              P_CHECK_NOSETTLED_FLAG VARCHAR2, --是否校验未结算仓
                              P_CHECK_RETURN_FLAG    VARCHAR2, --是否校验退货仓
                              P_RESULT               IN OUT NUMBER, --返回错误ID
                              P_ERR_MSG              IN OUT VARCHAR2 --返回错误信息
                              );

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-01-03
  *     创建者：陈武杰
  *   功能说明：判断产品数据量是否大于发货单数量
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_CHECK_QUANTITY(P_SHIP_INFO_ID IN NUMBER, --实际发货信息ID
                             P_RESULT       IN OUT NUMBER, --返回错误ID
                             P_ERR_MSG      IN OUT VARCHAR2 --返回错误信息
                             );

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-01-04
  *     创建者：廖丽章
  *   功能说明：发货确认触发生成销售单，发货通知单的产品数量与已生成的销售单产品数量进行校验，
                如果一张发货通知累计已生成的销售单产品数量大于发货通知单产品数量，
                则不允许生成销售单，直接返回提示信息。
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_CHECK_SHIP_QTY(P_SHIP_INFO_ID IN NUMBER, --实际发货信息ID
                             P_RESULT       IN OUT NUMBER, --返回错误ID
                             P_ERR_MSG      IN OUT VARCHAR2 --返回错误信息
                             );

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-05
  *     创建者：廖丽章
  *   功能说明：保存对销售单据的操作历史
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SAVE_SO_TRACE(P_SO_TRACE IN T_SO_TRACE%ROWTYPE, --仓库ID
                            P_RESULT   IN OUT NUMBER, --返回错误ID
                            P_ERR_MSG  IN OUT VARCHAR2 --返回错误信息
                            );

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-05
  *     创建者：廖丽章
  *   功能说明：判断产品是否套件，Y-是，N-否
  */
  -------------------------------------------------------------------------------
  /*   marrk by shengy20150131
    PROCEDURE P_ITEM_IS_SET(P_ITEM_CODE IN VARCHAR2, --产品编码
                            P_IS_SET    OUT VARCHAR2, --是否套件标识：Y-是，N-否
                            P_RESULT    OUT NUMBER, --返回错误ID
                            P_ERR_MSG   OUT VARCHAR2 --返回错误信息
                            );
  */

  PROCEDURE P_ITEM_IS_SET(P_ENTITY_ID IN NUMBER, --主体ID
                          P_ITEM_CODE IN VARCHAR2, --产品编码
                          P_IS_SET    OUT VARCHAR2, --是否套件标识：Y-是，N-否
                          P_RESULT    OUT NUMBER, --返回错误ID
                          P_ERR_MSG   OUT VARCHAR2 --返回错误信息
                          );

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-08-16
  *     创建者：廖丽章
  *   功能说明：获取负库存标识：根据单据类型ID和仓库ID取
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_GET_NEGATIVE_INV_FLAG(P_ENTITY_ID         IN NUMBER, --主体ID add by chen.wj 20150214
                                    P_BILL_TYPE_ID      IN NUMBER, --客户ID
                                    P_INV_ID            IN NUMBER, --仓库ID
                                    P_NEGATIVE_INV_FLAG OUT VARCHAR2, --是否允许负库存，是  Y，否 N，默认为 是 Y。
                                    P_RESULT            OUT NUMBER, --返回错误ID
                                    P_ERR_MSG           OUT VARCHAR2 --返回错误信息
                                    );

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-25
  *     创建者：廖丽章
  *   功能说明：判断销售单据是否可红冲
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_ALLOW_REVERSAL(P_SO_HEADER_ID   IN NUMBER, --销售单据头ID
                                P_ALLOW_REVERSAL OUT VARCHAR2, --是否可红冲：Y-是，N-否
                                P_RESULT         OUT NUMBER, --返回错误ID
                                P_ERR_MSG        OUT VARCHAR2 --返回错误信息
                                );

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-25
  *     创建者：廖丽章
  *   功能说明：更新销售单据的红冲标识
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_UPDATE_REVERSAL_FLAG(P_SO_HEADER_ID IN NUMBER, --销售单据头ID（蓝单）
                                      P_USER_CODE    IN VARCHAR2, --操作用户编码
                                      P_RESULT       OUT NUMBER, --返回错误ID
                                      P_ERR_MSG      OUT VARCHAR2 --返回错误信息
                                      );

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-25
  *     创建者：廖丽章
  *   功能说明：获取仓库信息
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_GET_INV_INFO(P_INV_ID   IN NUMBER, --仓库ID
                           P_INV_INFO OUT INV_INFO, --仓库信息记录
                           P_RESULT   OUT NUMBER, --返回错误ID
                           P_ERR_MSG  OUT VARCHAR2 --返回错误信息
                           );

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-25
  *     创建者：廖丽章
  *   功能说明：往整型数组里加数据
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_ARRAY_PUT(P_ARRAY IN OUT TYPE_ARRAY, --数据的整型数组
                        P_VALUE IN NUMBER --整型数据
                        );

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-25
  *     创建者：廖丽章
  *   功能说明：保存异常信息到销售业务异常表
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SAVE_EXPT_INFO(P_EXPT_COMMON_INFO IN EXCEPTION_COMMON_INFO, --异常公共信息记录集
                             P_EXPT_ARRAY       IN TYPE_EXCEPTION_ARRAY --异常信息数组
                             );

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-25
  *     创建者：廖丽章
  *   功能说明：往异常信息记录集数组里加数据
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_EXCEPTION_ARRAY_PUT(P_EXPT_ARRAY IN OUT TYPE_EXCEPTION_ARRAY, --异常信息记录集数组
                                  P_EXPT       IN EXCEPTION_INFO --异常信息记录集
                                  );

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-25
  *     创建者：廖丽章
  *   功能说明：是否抛出异常
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_EXCEPTION_THROWS(P_EXPT_CODE IN NUMBER);

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-01-21
  *     创建者：申广延
  *   功能说明：根据源单据类型取对应主体的业务单据类型(前提：只能取一对一关系)
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_GET_BILL_TYPE_BY_SRC_TYPE(P_ENTITY_ID      IN NUMBER, --主体ID
                                        P_SRC_TYPE_CODE  IN VARCHAR2, --源单类型代码
                                        P_BILL_TYPE_CODE OUT VARCHAR2, --单据类型代码
                                        P_RESULT         OUT NUMBER, --返回错误ID
                                        P_ERR_MSG        OUT VARCHAR2 --返回错误信息
                                        );

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-05
  *     创建者：廖丽章
  *   功能说明：根据行政区划编码，获取上级区划编码
  */
  -------------------------------------------------------------------------------
  FUNCTION F_GET_PARENT_DISTRICT_CODE(P_DISTRICT_CODE IN VARCHAR2)
    RETURN VARCHAR2;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-05
  *     创建者：廖丽章
  *   功能说明：判断产品是否套件，Y-是，N-否
  */
  -------------------------------------------------------------------------------
  --FUNCTION F_ITEM_IS_SET(P_ITEM_CODE IN VARCHAR2) RETURN VARCHAR2; mark by shengy20150131

  FUNCTION F_ITEM_IS_SET(P_ENTITY_ID IN NUMBER, --主体ID
                         P_ITEM_CODE IN VARCHAR2) RETURN VARCHAR2;
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-08-16
  *     创建者：廖丽章
  *   功能说明：获取月末是否结算到下个月一号的标识
  */
  -------------------------------------------------------------------------------
  FUNCTION F_GET_AR_CONFIG(P_CUSTOMER_ID     IN NUMBER, --客户ID
                           P_SALES_CENTER_ID IN NUMBER, --营销中心ID
                           P_ENTITY_ID       IN NUMBER, --主体ID
                           P_ERP_OU_ID       IN NUMBER --ERP经营单位ID
                           ) RETURN AR_CONFIG;
                           
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2017-08-10
  *     创建者：周建刚
  *   功能说明：获取应收发票配置ID标识
  */
  -------------------------------------------------------------------------------
  FUNCTION F_GET_AR_CONFIG_ID(P_CUSTOMER_ID     IN NUMBER, --客户ID
                             P_SALES_CENTER_ID IN NUMBER, --营销中心ID
                             P_ENTITY_ID       IN NUMBER, --主体ID
                             P_ERP_OU_ID       IN NUMBER --ERP经营单位ID
                             ) RETURN NUMBER;                           

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-08-16
  *     创建者：廖丽章
  *   功能说明：获取单据类型信息（T_INV_BILL_TYPES）
  */
  -------------------------------------------------------------------------------
  FUNCTION F_GET_INV_BILL_TYPE_INFO(P_BILL_TYPE_ID IN NUMBER)
    RETURN INV_BILL_TYPE_INFO;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-01-06
  *     创建者：陈武杰
  *   功能说明：根据当前行政区划编码和返回类型，获得行政区划编码
  */
  -------------------------------------------------------------------------------
  FUNCTION F_GET_DISTRICT(P_DISTRICT_CODE IN VARCHAR2, --地区编码
                          P_RETURN_TYPE   NUMBER --P_RETURN_TYPE对应LEVEL_SEQ,1-大区，2-省，自治区，3-市，4-县，5-乡镇
                          ) RETURN VARCHAR2;
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-02-04
  *     创建者：陈武杰
  *   功能说明：交易单据行产品上面的不含税价格获取是否正常
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_CHECK_NOT_REVENUE_PRICE(P_SO_HEADER_ID IN NUMBER, --销售单据头ID
                                      P_RESULT       IN OUT NUMBER, --返回错误ID
                                      P_ERR_MSG      IN OUT VARCHAR2 --返回错误信息
                                      );
  -------------------------------------------------------------------------------
  /*
    *   创建日期：2015-02-04
    *     创建者：陈武杰
    *   功能说明：交易单据行产品上面的不含税价格获取是否正常
        返回值：-1错误,0非拉式,1销售,2红冲,3源单退回,4反向销售,5源单退货红冲，6拉式其他单据类型

  */
  -------------------------------------------------------------------------------
  FUNCTION F_PULL_MODE(P_SO_NUM IN VARCHAR2) RETURN NUMBER;
  -------------------------------------------------------------------------------
  /*
    *   创建日期：2015-02-04
    *     创建者：陈武杰
    *   功能说明：交易单据行产品上面的不含税价格获取是否正常
        返回值：-1错误,0非拉式,1销售,2红冲,3源单退回,4反向销售,5源单退货红冲，6拉式其他单据类型

  */
  -------------------------------------------------------------------------------
  FUNCTION F_PULL_MODE_BY_HEADERID(P_SO_HEADER_ID IN NUMBER) RETURN NUMBER;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-08-04
  *     创建者：xiongpl
  *   功能说明：判断客户是否事业部客户，Y-是，N-否
  */
  -------------------------------------------------------------------------------
  FUNCTION F_IS_ENTITY_CUST(P_CUST_ID IN NUMBER) RETURN VARCHAR2;

PROCEDURE P_推广物料;
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-03-17
  *     创建者：申广延
  *   功能说明：判断仓库是否推广物料仓库，Y-是，N-否
  */
  -------------------------------------------------------------------------------
  FUNCTION F_INVENTORY_IS_MATERIAL(P_INV_ID IN VARCHAR2) RETURN VARCHAR2;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-03-17
  *     创建者：申广延
  *   功能说明：判断仓库是否推广物料仓库，Y-是，N-否
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_INVENTORY_IS_MATERIAL(P_INV_ID IN VARCHAR2, --仓库ID
                          P_IS_MATERIAL    OUT VARCHAR2, --是否套件标识：Y-是，N-否
                          P_RESULT    OUT NUMBER, --返回错误ID
                          P_ERR_MSG   OUT VARCHAR2 --返回错误信息
                          );
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-03-17
  *     创建者：申广延
  *   功能说明：判断产品是否推广物料，Y-是，N-否
  */
  -------------------------------------------------------------------------------
  FUNCTION F_ITEM_IS_MATERIAL(P_ENTITY_ID IN NUMBER, --主体ID
                         P_ITEM_CODE IN VARCHAR2) RETURN VARCHAR2;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-03-17
  *     创建者：申广延
  *   功能说明：判断产品是否推广物料，Y-是，N-否
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_ITEM_IS_MATERIAL(P_ENTITY_ID IN NUMBER, --主体ID
                          P_ITEM_CODE IN VARCHAR2, --产品编码
                          P_IS_MATERIAL    OUT VARCHAR2, --是否套件标识：Y-是，N-否
                          P_RESULT    OUT NUMBER, --返回错误ID
                          P_ERR_MSG   OUT VARCHAR2 --返回错误信息
                          );

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-03-17
  *     创建者：申广延
  *   功能说明：判断销售单是否推广物料，Y-是，N-否
  */
  -------------------------------------------------------------------------------
  FUNCTION F_SOHEADER_IS_MATERIAL(P_SO_HEADER_ID IN NUMBER) RETURN VARCHAR2;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-03-17
  *     创建者：申广延
  *   功能说明：判断销售单是否推广物料，Y-是，N-否
  */
  -------------------------------------------------------------------------------
  FUNCTION F_INTFHEADER_IS_MATERIAL(P_SO_HEADER_INTERFACE_ID IN NUMBER) RETURN VARCHAR2;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-03-17
  *     创建者：申广延
  *   功能说明：判断销售单明细推广物料标志是否一致，Y-是，N-否
  */
  -------------------------------------------------------------------------------
  FUNCTION F_INTFHEADER_CHECK_MATERIAL(P_SO_HEADER_INTERFACE_ID IN NUMBER) RETURN VARCHAR2;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-09-17
  *     创建者：周建刚
  *   功能说明：设置财务单据营销方式【TRX_MODE】
  *             根据主体、主体参数【SO_AR_PUSH_OR_PULL】、库存组织编码规则，
  *             设置单据的营销方式（推式:TRX_MODE=PUSH、拉式:TRX_MODE=PULL）。
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_SET_TRX_MODE(P_SO_HEADER IN OUT T_SO_HEADER%ROWTYPE, --销售单据头记录
                              P_RESULT    IN OUT NUMBER,              --返回错误ID
                              P_ERR_MSG   IN OUT VARCHAR2             --返回错误信息
                               );   
  
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2016-06-12
  *     创建者：周建刚
  *   功能说明：根据主体ID、客户ID、账户ID、营销大类编码，获取客户到款余额
  *   计算公式  到款余额 = 到款金额 - 销售金额
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_GET_RECEIVED_AMOUNT_LEFT(P_ENTITY_ID       IN  NUMBER,    --主体ID
                                       P_CUSTOMER_ID     IN  NUMBER,    --客户ID
                                       P_CUSTOMER_CODE   IN  VARCHAR2,  --客户编码
                                       P_ACCOUNT_ID      IN  NUMBER,    --账户ID
                                       P_ACCOUNT_CODE    IN  VARCHAR2,   --账户编码
                                       P_SALES_MAIN_TYPE IN  VARCHAR2,  --营销大类编码
                                       P_AMOUNT_LEFT     OUT NUMBER,    --到款余额
                                       P_RESULT          OUT NUMBER,    --返回错误ID
                                       P_ERR_MSG         OUT VARCHAR2   --返回错误信息
                               );
                               
  -------------------------------------------------------------------------------
  /*
  * 创建日期：2016-06-13
  * 创建者：周建刚  zhoujg3
  * 功能说明：销售单/销售红冲单记录使用的铺底额度
	* 单据保存时记录使用的铺底额度 
	* 1、	销售单制单（包括系统自动开单、人工制单）时获取客户到款余额；
	* 2、	计算铺底使用额度情形一：如果客户到款余额 < 0 ,则 DEPLAY_AMOUNT = 销售单结算金额（SETTLE_AMOUNT）;
	* 3、	计算铺底使用额度情形二：如果客户到款余额 - 销售单结算金额 > 0 ，则 DEPLAY_AMOUNT = 0；
	* 4、	计算铺底使用额度情形三：如果客户到款余额 - 销售单结算金额 < 0，则DEPLAY_AMOUNT = 绝对值(客户到款余额 - 销售单结算金额)。
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_UPDATE_SO_DELAYPAY_AMOUNT(P_SO_HEADER_ID IN  T_SO_HEADER.SO_HEADER_ID%TYPE, --销售单据头记录
                                        P_RESULT    IN OUT NUMBER,              --返回错误ID
                                        P_ERR_MSG   IN OUT VARCHAR2             --返回错误信息
                               );
                               
  -------------------------------------------------------------------------------
  /*
  * 创建日期：2018-04-10
  * 创建者：周建刚  zhoujg3
  * 功能说明：销售开单记录税率、税码
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_GET_TAX_RATE(P_ENTITY_ID           IN NUMBER,
                           P_SALES_CENTER_ID     IN NUMBER,
                           P_CUSTOMER_ID         IN NUMBER,
                           P_ERP_OU_ID           IN NUMBER,
                           P_TAX_RATE            OUT NUMBER,
                           P_TAX_CODE            OUT VARCHAR2,
                           P_RESULT              IN OUT NUMBER,   --返回错误ID
                           P_ERR_MSG             IN OUT VARCHAR2  --返回错误信息
                          );
  -------------------------------------------------------------------------------
END PKG_SO_PUB;
/

