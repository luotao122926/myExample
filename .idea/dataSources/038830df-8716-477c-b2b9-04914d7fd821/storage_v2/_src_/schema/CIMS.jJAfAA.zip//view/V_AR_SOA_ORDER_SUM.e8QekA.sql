create view V_AR_SOA_ORDER_SUM as
select h.header_id,
       h.ORDER_NUMBER,
       h.ENTITY_ID,
       h.CUSTOMER_ID,
       h.customer_code,
       h.customer_name,
       h.SALES_CENTER_ID,
       h.ACCOUNT_ID,
       h.ACCOUNT_CODE,
       h.ACCOUNT_NAME,
       h.PERIOD_DATE,
       h.ORDER_TYPE,
       h.SOA_BEGIN_DATE,
       h.SOA_END_DATE,
       h.CONFIRM_FLAG,
       h.PRINT_FLAG,
       h.CLOSE_FLAG,
       h.RECEIPT_AMOUNT,
       h.DISCOUNT_AMOUNT,
       h.COMMENT_INFO,
       h.EXECUTE_MODE,
       h.ORDER_STATE,
       h.SEND_STATE,
       h.SEND_CCS_FLAG,
       h.CALLBACK_FLAG,
       rl.rl_CURRENT_AMOUNT,
       rl.rl_CUS_RECEIVABLE_AMOUNT,
       dl.dl_CURRENT_AMOUNT,
       dl.dl_CUS_DISCOUNT_AMOUNT,
       nvl(rl.rl_DIFFERENACE_AMOUNT,0) rl_DIFFERENACE_AMOUNT,
       nvl(dl.dl_DIFFERENACE_AMOUNT,0) dl_DIFFERENACE_AMOUNT,
       nvl(od.od_DEFFERENCE_AMOUNT,0) od_DEFFERENCE_AMOUNT,
       nvl(od.od_DEFFERENCE_AMOUNT,0) isRecDisDifferenace,
       decode(sign(od.od_DEFFERENCE_AMOUNT-0),-1,'N',0,'N',1,'Y') isdifferenace,
       h.UN_SOLUTION_AMOUNT,
       h.CENTER_CHECK_FLAG,
       h.DIFF_CHECK_FLAG
     --  h.CENTER_CHECK_BY,
      -- h.CENTER_CHECK_DATE
  from T_AR_SOA_ORDER_HEADS h
  left join (select sol.header_id header_id,
                    nvl(sum(sol.CURRENT_AMOUNT),0) rl_CURRENT_AMOUNT,
                    nvl(sum(sol.CUS_RECEIVABLE_AMOUNT),0) rl_CUS_RECEIVABLE_AMOUNT,
                    nvl(sum(sol.DIFFERENACE_AMOUNT),0) rl_DIFFERENACE_AMOUNT
               from T_AR_SOA_ORDER_RECEIPT_LINES sol
              group by sol.header_id) rl
    on h.header_id = rl.header_id
  left join (select odl.header_id header_id,
                    nvl(sum(odl.CURRENT_AMOUNT),0) dl_CURRENT_AMOUNT,
                    nvl(sum(odl.CUS_DISCOUNT_AMOUNT),0) dl_CUS_DISCOUNT_AMOUNT,
                    nvl(sum(odl.DIFFERENACE_AMOUNT),0) dl_DIFFERENACE_AMOUNT
               from T_AR_SOA_ORDER_DIS_LINES odl
              group by odl.header_id) dl
    on h.header_id = dl.header_id
 left join (select sod.header_id header_id,
                    nvl(sum(sod.DEFFERENCE_AMOUNT),0) od_DEFFERENCE_AMOUNT
               from T_AR_SOA_ORDER_DIFFERENCES sod
              group by sod.header_id) od
    on h.header_id = od.header_id
/

comment on column V_AR_SOA_ORDER_SUM.HEADER_ID is '账单ID'
/

comment on column V_AR_SOA_ORDER_SUM.ORDER_NUMBER is '账单编号'
/

comment on column V_AR_SOA_ORDER_SUM.ENTITY_ID is '主体ID'
/

comment on column V_AR_SOA_ORDER_SUM.CUSTOMER_ID is '客户ID'
/

comment on column V_AR_SOA_ORDER_SUM.CUSTOMER_CODE is '客户编码'
/

comment on column V_AR_SOA_ORDER_SUM.CUSTOMER_NAME is '客户名称'
/

comment on column V_AR_SOA_ORDER_SUM.SALES_CENTER_ID is '营销中心ID'
/

comment on column V_AR_SOA_ORDER_SUM.ACCOUNT_ID is '账户ID'
/

comment on column V_AR_SOA_ORDER_SUM.ACCOUNT_CODE is '账户编码'
/

comment on column V_AR_SOA_ORDER_SUM.ACCOUNT_NAME is '账户名称'
/

comment on column V_AR_SOA_ORDER_SUM.PERIOD_DATE is '账期'
/

comment on column V_AR_SOA_ORDER_SUM.ORDER_TYPE is '账单类型'
/

comment on column V_AR_SOA_ORDER_SUM.SOA_BEGIN_DATE is '对账开始日期'
/

comment on column V_AR_SOA_ORDER_SUM.SOA_END_DATE is '对账结束日期'
/

comment on column V_AR_SOA_ORDER_SUM.CONFIRM_FLAG is '客户确认标志'
/

comment on column V_AR_SOA_ORDER_SUM.PRINT_FLAG is '打印标志'
/

comment on column V_AR_SOA_ORDER_SUM.CLOSE_FLAG is '对账单关闭标志，客户对账单关闭后，该客户可重新生成本期的对账单'
/

comment on column V_AR_SOA_ORDER_SUM.RECEIPT_AMOUNT is '本期到款余额'
/

comment on column V_AR_SOA_ORDER_SUM.COMMENT_INFO is '备注'
/

comment on column V_AR_SOA_ORDER_SUM.EXECUTE_MODE is '往来对账单数据生成方式'
/

comment on column V_AR_SOA_ORDER_SUM.ORDER_STATE is '对账状态'
/

comment on column V_AR_SOA_ORDER_SUM.SEND_STATE is '发送状态'
/

comment on column V_AR_SOA_ORDER_SUM.SEND_CCS_FLAG is '推送CCS标识'
/

comment on column V_AR_SOA_ORDER_SUM.CALLBACK_FLAG is '收回标识'
/

comment on column V_AR_SOA_ORDER_SUM.RL_CURRENT_AMOUNT is '本期对账单到款余额汇总'
/

comment on column V_AR_SOA_ORDER_SUM.RL_CUS_RECEIVABLE_AMOUNT is '客户到款余额汇总'
/

comment on column V_AR_SOA_ORDER_SUM.DL_CURRENT_AMOUNT is '本期对账单折让余额汇总'
/

comment on column V_AR_SOA_ORDER_SUM.DL_CUS_DISCOUNT_AMOUNT is '客户确认折让余额汇总'
/

comment on column V_AR_SOA_ORDER_SUM.RL_DIFFERENACE_AMOUNT is '到款差异金额汇总'
/

comment on column V_AR_SOA_ORDER_SUM.DL_DIFFERENACE_AMOUNT is '折让差异金额汇总'
/

comment on column V_AR_SOA_ORDER_SUM.OD_DEFFERENCE_AMOUNT is '差异金额汇总'
/

comment on column V_AR_SOA_ORDER_SUM.ISRECDISDIFFERENACE is '到款和折让(是否有差异)'
/

comment on column V_AR_SOA_ORDER_SUM.ISDIFFERENACE is '差异反馈(是否有差异)'
/

comment on column V_AR_SOA_ORDER_SUM.UN_SOLUTION_AMOUNT is '三方承兑未解付汇总'
/

comment on column V_AR_SOA_ORDER_SUM.CENTER_CHECK_FLAG is '中心审核标志'
/

comment on column V_AR_SOA_ORDER_SUM.DIFF_CHECK_FLAG is '客户差异确认标志'
/

