create view V_BD_USER_CUST_PRIV as
select distinct c."USER_ID",c."USER_CODE",c."USER_NAME",c."SALES_CENTER_ID",c."CUSTOMER_ID",c."CUSTOMER_CODE",c."CUSTOMER_NAME",c."ACTIVE_FLAG",c."ENTITY_ID"
  from (
    --用户默认的客户权限
    select *
      from v_bd_user_cust_priv_default
    union all
    --用户独立授权的客户
    select *
      from v_bd_user_cust_priv_add
    union all
    --根据独立授权账户推算出的客户
    select * from v_bd_user_cust_priv_addbyacc
        ) c

/

