create view V_BD_USER_MARKETMODE_PRIV as
select distinct m."USER_ID",m."USER_CODE",m."USER_NAME",m."CODE_ID",m."CODE_VALUE",m."CODE_NAME",m."ENTITY_ID"
  from (select dpm.user_id,
               uu.account user_code,
               uu.name user_name,
               uc.code_id, --营销模式ID
               uc.code_value, --营销模式编码
               uc.code_name, --营销模式名称
               dpm.entity_id
          from t_bd_datapriv_marketmode dpm,
               (select codetype,
                       codetype_name,
                       id code_id,
                       code_value,
                       code_name
                  from up_codelist
                 where codetype = 'MIDEA_MARKET_MODE') uc,
               up_org_user uu
         where dpm.cust_market_mode = uc.code_value
           and dpm.user_id = uu.user_id
           and dpm.active_flag = 'Y' --有效记录
        ) m
/

