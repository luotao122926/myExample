create PACKAGE PKG_BD_PRICE_IO  AS
  /*取价函数,授权给外部调用*/
  function F_GET_PRICE
  (
   P_ACC_ID    t_customer_account.account_id%type,  --账户ID
   P_ITEM_CODE   t_bd_item.item_code%type,           --产品编码
   P_BILL_DATE  VARCHAR2,        --单据日期
   P_PRICE_LIST_ID  t_bd_price_list.price_list_id%type,    --价格列表ID
   P_ENTITY_ID    up_org_unit.ENTITY_ID%type     --业务主体ID
   ) --
   return NUMBER;

  /*取价过程,入口过程，正品，，，,授权给外部调用*/
  procedure P_GET_PRICE
  (
   P_ACC_ID       IN t_customer_account.account_id%type,  --账户ID
   P_ITEM_CODE      IN t_bd_item.item_code%type, --产品编码
   P_BILL_DATE    IN VARCHAR2,        --单据日期 YYYYMMDD
   P_PRICE_LIST_ID IN t_bd_price_list.price_list_id%type,--价格列表ID
   P_ENTITY_ID    IN up_org_unit.ENTITY_ID%type, --业务主体ID
   P_PRICE        out NUMBER, --返回价格
   P_DISCOUNT     out NUMBER, --返回折扣率
   P_MONTH_DISCOUNT      out NUMBER, --返回月返
   P_CX_FLAG      out VARCHAR2 --返回是否促销机
   );
  /*取价过程,入口过程，优惠品，，,授权给外部调用*/
  procedure P_GET_PRICE_YH
  (
   P_ACC_ID       IN t_customer_account.account_id%type,  --账户ID
   P_ITEM_CODE      IN t_bd_item.item_code%type, --产品编码
   P_BILL_DATE    IN VARCHAR2,        --单据日期 YYYYMMDD
   P_PRICE_LIST_ID IN t_bd_price_list.price_list_id%type,--价格列表ID
   P_ENTITY_ID    IN up_org_unit.ENTITY_ID%type, --业务主体ID
   P_PRICE        out NUMBER, --返回价格
   P_DISCOUNT     out NUMBER, --返回折扣率
   P_MONTH_DISCOUNT      out NUMBER, --返回月返
   P_CX_FLAG      out VARCHAR2 --返回是否促销机
   );

END PKG_BD_PRICE_IO;

/

