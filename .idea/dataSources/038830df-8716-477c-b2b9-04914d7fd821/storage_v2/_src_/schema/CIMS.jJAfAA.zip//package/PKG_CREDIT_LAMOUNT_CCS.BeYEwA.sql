create package PKG_CREDIT_LAMOUNT_CCS is

  /*FUNCTION F_GET_LOCK_AMOUNT(IN_ENTITY_ID       NUMBER, --主体ID 不能为空
  IN_CUSTOMER_ID     NUMBER, --客户ID 可以为空
  IN_ACCOUNT_ID      NUMBER, --账户ID 可以为空
  IN_ACCOUNT_CODE    VARCHAR2, --账户编码 可以为空
  IN_CREDIT_GROUP_ID NUMBER, --额度组ID 可以为空
  IN_SALES_CENTER_ID VARCHAR2, --营销中心ID 可以为空
  IN_DISCOUNT_TYPE   VARCHAR2, --折让方式 可以为空
  IN_USER_ACC        VARCHAR2 --用户账号 不能为空
  ) RETURN TAB_CREDIT_LOCK_AMOUNT PIPELINED;*/
  
  -- Author  : 
  -- Created : 2017// 8:42:27
  -- Purpose : 

  PROCEDURE P_GET_LOCK_AMOUNT(IN_ENTITY_ID       IN NUMBER, --主体ID 不能为空
                              IN_CUSTOMER_ID     IN NUMBER, --客户ID 可以为空
                              IN_ACCOUNT_ID      IN NUMBER, --账户ID 可以为空
                              IS_ACCOUNT_CODE    IN VARCHAR2, --账户编码 可以为空
                              IN_CREDIT_GROUP_ID IN NUMBER, --额度组ID 可以为空
                              IN_SALES_CENTER_ID IN VARCHAR2, --营销中心ID 可以为空
                              IS_DISCOUNT_TYPE   IN VARCHAR2, --折让方式 可以为空
                              OS_MESSAGE         OUT VARCHAR2, --成功返回“SUCCESS”；失败返回出错信息
                              OS_DIS_TYPE_ENABLE OUT VARCHAR2--是否启用折扣类型
                              );

end PKG_CREDIT_LAMOUNT_CCS;
/

