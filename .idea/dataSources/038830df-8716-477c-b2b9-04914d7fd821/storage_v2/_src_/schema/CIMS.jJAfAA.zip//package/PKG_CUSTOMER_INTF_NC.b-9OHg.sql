create PACKAGE      PKG_CUSTOMER_INTF_NC IS

  PROCEDURE P_CUSTOMER_INTF_NC_PROC(IN_PAGE_SIZE IN NUMBER, --
                                    OS_MESSAGE   OUT VARCHAR2 --成功则返回“SUCCESS”，否则返回出错信息
                                    );

  PROCEDURE P_CUSTOMER_INTF_NC_PROC(IN_ENTITY_ID        IN NUMBER, --主体ID，相应主体系统参数PUB_FIN_SYS为NC
                                    IN_INTF_CUSTOMER_ID IN NUMBER, --客户头接口表ID
                                    IN_CUSTOMER_ID      IN VARCHAR2, --客户头正式表ID
                                    OS_MESSAGE          OUT VARCHAR2 --成功则返回“SUCCESS”，否则返回出错信息
                                    );

END PKG_CUSTOMER_INTF_NC;
/

