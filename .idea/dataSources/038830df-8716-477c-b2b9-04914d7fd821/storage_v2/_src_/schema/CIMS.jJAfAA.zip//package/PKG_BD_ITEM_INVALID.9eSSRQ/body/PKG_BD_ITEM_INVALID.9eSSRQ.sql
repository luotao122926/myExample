create Package Body      PKG_BD_ITEM_INVALID AS
  -----------------------------------------------------------------------------
  --处理产品物料失效校验
  -----------------------------------------------------------------------------
  PROCEDURE P_SYC_ITEM_INVALID
  (
    P_INTF_BD_ITEM_INVALID IN OUT INTF_BD_ITEM_INVALID%ROWTYPE,
    P_RESULT         IN OUT NUMBER, --返回错误ID
    P_ERR_MSG        IN OUT VARCHAR2 --返回错误信息
  ) IS
  V_CNT NUMBER;
  V_IS_PASS NUMBER;--是否通过校验，0：通过，其他不通过

  BEGIN
  V_IS_PASS := 0;
  SELECT COUNT(*) C INTO V_CNT FROM CIMS.T_BD_ITEM I WHERE I.ITEM_CODE = P_INTF_BD_ITEM_INVALID.ITEM_CODE AND I.ACTIVE_FLAG = 'Y';
  IF V_CNT = 0 THEN--不存在产品或已经失效直接跳过
    GOTO DOEND;
  END IF;
  SELECT COUNT(*) C INTO V_CNT FROM CIMS.T_INV_ONHAND OH WHERE OH.ITEM_ID IN 
  (SELECT I.ITEM_ID FROM CIMS.T_BD_ITEM I WHERE I.ITEM_CODE = P_INTF_BD_ITEM_INVALID.ITEM_CODE AND I.ENTITY_ID IN 
    (SELECT ORG.ENTITY_ID FROM CIMS.T_INV_ORGANIZATION ORG WHERE ORG.ORGANIZATION_ID = P_INTF_BD_ITEM_INVALID.ORGANIZATION_ID 
      AND ORG.ENTITY_ID IS NOT NULL
    )
  )
  AND OH.QUANTITY <> 0;
  IF V_CNT > 0 THEN--有库存，进行多产地校验
    /*SELECT COUNT(*) C INTO V_CNT FROM CIMS.T_PLN_ITEM_PRODUCING_AREA T WHERE T.ITEM_CODE = P_INTF_BD_ITEM_INVALID.ITEM_CODE 
      AND T.STATE NOT IN ('DISCARD','DELIST') --排除已经退市和废弃的产地
	    AND T.ENTITY_ID IN 
	    (SELECT ORG.ENTITY_ID FROM CIMS.T_INV_ORGANIZATION ORG WHERE ORG.ORGANIZATION_ID = P_INTF_BD_ITEM_INVALID.ORGANIZATION_ID 
	      AND ORG.ENTITY_ID IS NOT NULL
	    );*/

      SELECT COUNT(*) INTO V_CNT 
        FROM (
              --产品产地正式表和接口表同时存在，取接口表生命周期状态
              SELECT T.ENTITY_ID,
                      T.ITEM_CODE,
                      T.PRODUCING_AREA_NAME,
                      IP.SALEUNIT_STAT STATE
                FROM CIMS.T_PLN_ITEM_PRODUCING_AREA T,
                      CIMS.INTF_PLN_ITEM_PRODUCING   IP,
                      CIMS.T_PLN_PRODUCING_AREA      PA
               WHERE T.ITEM_CODE = P_INTF_BD_ITEM_INVALID.ITEM_CODE
                 AND IP.SALEUNIT_STAT NOT IN ('DISCARD', 'DELIST') --排除已经退市和废弃的产地
                 AND T.ITEM_CODE = IP.ITEM_CODE
                 AND T.PRODUCING_AREA_ID = PA.PRODUCING_AREA_ID
                 AND PA.MRP_ORG_ID = IP.ORGANIZATION_ID
                 AND T.ENTITY_ID = IP.ENTITY_ID
                 AND T.ENTITY_ID = PA.ENTITY_ID
                 AND IP.INTF_ID IN 
                    (SELECT MAX(P.INTF_ID) INTF_ID FROM CIMS.INTF_PLN_ITEM_PRODUCING P WHERE P.INTF_STATE<>'P' 
                      AND P.ENTITY_ID = T.ENTITY_ID GROUP BY P.ITEM_CODE,P.ORGANIZATION_ID)
                 AND T.ENTITY_ID IN
                     (SELECT ORG.ENTITY_ID
                        FROM CIMS.T_INV_ORGANIZATION ORG
                       WHERE 1 = 1
                         AND ORG.ORGANIZATION_ID = P_INTF_BD_ITEM_INVALID.ORGANIZATION_ID
                         AND ORG.ENTITY_ID IS NOT NULL)
              UNION
              --正式表存在但接口表不存在，取正式表生命周期状态
              SELECT T.ENTITY_ID, T.ITEM_CODE, T.PRODUCING_AREA_NAME, T.STATE
                FROM CIMS.T_PLN_ITEM_PRODUCING_AREA T
               WHERE T.ITEM_CODE = P_INTF_BD_ITEM_INVALID.ITEM_CODE
                 AND NOT EXISTS
               (SELECT 1
                        FROM CIMS.INTF_PLN_ITEM_PRODUCING IP,
                             CIMS.T_PLN_PRODUCING_AREA    PA
                       WHERE 1 = 1
                         AND T.ITEM_CODE = IP.ITEM_CODE
                         AND T.PRODUCING_AREA_ID = PA.PRODUCING_AREA_ID
                         AND PA.MRP_ORG_ID = IP.ORGANIZATION_ID
                         AND T.ENTITY_ID = IP.ENTITY_ID
                         AND T.ENTITY_ID = PA.ENTITY_ID
                         )
                 AND T.STATE NOT IN ('DISCARD', 'DELIST') --排除已经退市和废弃的产地
                 AND T.ENTITY_ID IN
                     (SELECT ORG.ENTITY_ID
                        FROM CIMS.T_INV_ORGANIZATION ORG
                       WHERE 1 = 1
                         AND ORG.ORGANIZATION_ID = P_INTF_BD_ITEM_INVALID.ORGANIZATION_ID
                         AND ORG.ENTITY_ID IS NOT NULL));


    IF V_CNT > 1 THEN--多产地产品，只校验最后一个产地
      V_IS_PASS := 0;
    ELSE
      P_ERR_MSG := '失败，产品物料失效校验不通过，该产品还有库存！';
      V_IS_PASS := V_IS_PASS + 1;
      GOTO DOEND;
    END IF;
  ELSE --无库存，进行其他校验（退货申请等）

    --退货申请散件
    SELECT COUNT(*) INTO V_CNT FROM CIMS.T_SO_RETURN_APPLY_HEADER H,CIMS.T_SO_RETURN_APPLY_LINE L,CIMS.T_SO_RETURN_APPLY_LINE_DETAIL D
      WHERE H.BILL_STATUS IN ('10','11','12') AND H.CANCEL_FLAG = 'N'
        AND D.COMPONENT_CODE = P_INTF_BD_ITEM_INVALID.ITEM_CODE AND H.APPLY_HEADER_ID = L.APPLY_HEADER_ID AND L.APPLY_LINE_ID = D.APPLY_LINE_ID;

    IF V_CNT > 0 THEN
      P_ERR_MSG := '失败，产品物料失效校验不通过，该产品还有退货申请未入库！';
      V_IS_PASS := V_IS_PASS + 1;
      GOTO DOEND;
    END IF;

    --退货申请套机
    SELECT COUNT(*) INTO V_CNT FROM CIMS.T_SO_RETURN_APPLY_HEADER H,CIMS.T_SO_RETURN_APPLY_LINE L
      WHERE H.BILL_STATUS IN ('10','11','12') AND H.CANCEL_FLAG = 'N'
        AND L.ITEM_CODE = P_INTF_BD_ITEM_INVALID.ITEM_CODE AND H.APPLY_HEADER_ID = L.APPLY_HEADER_ID;
    IF V_CNT > 0 THEN
      P_ERR_MSG := '失败，产品物料失效校验不通过，该产品还有退货申请未入库！';
      V_IS_PASS := V_IS_PASS + 1;
      GOTO DOEND;
    END IF;

    --订单锁定校验
    SELECT COUNT(*) INTO V_CNT FROM CIMS.T_PLN_ORDER_INV_OCCUPY O WHERE 1=1 
      AND EXISTS (SELECT 1 FROM CIMS.T_BD_ITEM I WHERE O.ITEM_ID = I.ITEM_ID AND I.ITEM_CODE = P_INTF_BD_ITEM_INVALID.ITEM_CODE)
      AND NVL(O.STOCK_AFFIRM_QTY, 0) + NVL(O.SUPPLY_QTY, 0) - NVL(O.SO_ORDER_QTY, 0) - NVL(O.SUNDRY_QTY, 0) > 0;

    IF V_CNT > 0 THEN
      P_ERR_MSG := '失败，产品物料失效校验不通过，该产品还有在途订单锁定！';
      V_IS_PASS := V_IS_PASS + 1;
      GOTO DOEND;
    END IF;
    
    --计划订单在途校验
    Select COUNT(*) INTO V_CNT 
      From t_Pln_Order_Detail d,
           t_Pln_Order_Head   h,
           t_Pln_Order_Line   l,
           t_Pln_Order_Type   t
     Where d.Order_Head_Id = h.Order_Head_Id
       And d.Entity_Id = h.Entity_Id
       And d.Order_Line_Id = l.Order_Line_Id
       And d.Order_Head_Id = h.Order_Head_Id
       And d.Can_Produce_Qty - Nvl(d.Supply_Qty, 0) - Nvl(d.Cancel_Qty, 0) > 0
       And EXISTS (SELECT 1 FROM CIMS.T_BD_ITEM I WHERE D.ITEM_ID = I.ITEM_ID AND I.ITEM_CODE = P_INTF_BD_ITEM_INVALID.ITEM_CODE)
       And Nvl(d.Close_Flag, 'N') = 'N'
       And h.Order_Type_Id = t.Order_Type_Id
       And h.Entity_Id = t.Entity_Id
       And h.Form_State In ('32', '306') --('已排产', '已完成')
       And Trunc(Nvl(l.can_supply_date, Sysdate) + Nvl(t.Defer_Supply_Days, 0)) >= Trunc(Sysdate)
       and h.creation_date > sysdate - 360;
       --修改为根据周期的开始日期和主体参数控制
      /* And Exists (Select 1
              From t_Pln_Order_Period p
             Where p.Period_Id = h.Period_Id
               And p.Entity_Id = h.Entity_Id
                  --增加匹配当月订单控制
               And p.Begin_Date <= Trunc(Sysdate - to_Number(Nvl(Pkg_Bd.f_Get_Parameter_Value('ORDER_ADVANCE_SUPPLY_DAYS',
                                                                           10), '0'))));*/

    IF V_CNT > 0 THEN
      P_ERR_MSG := '失败，产品物料失效校验不通过，该产品还有在途计划订单！';
      V_IS_PASS := V_IS_PASS + 1;
      GOTO DOEND;
    END IF;

  END IF;

  <<DOEND>>
  IF V_IS_PASS > 0 THEN
    UPDATE INTF_BD_ITEM_INVALID T SET T.RESPONSETYPE = 'W', T.RESPONSECODE = '000011',
        T.RESPONSEMESSAGE = P_ERR_MSG, T.RETURN_DATE = SYSDATE 
        WHERE T.INVALID_ID = P_INTF_BD_ITEM_INVALID.INVALID_ID;
  ELSE
    UPDATE INTF_BD_ITEM_INVALID T SET T.RESPONSETYPE = 'N',T.RESPONSECODE = '000000',
      T.RESPONSEMESSAGE='成功，校验通过', T.RETURN_DATE = SYSDATE 
      WHERE T.INVALID_ID = P_INTF_BD_ITEM_INVALID.INVALID_ID;
  END IF;

  EXCEPTION
    WHEN OTHERS THEN
      P_RESULT  := -1;
      P_ERR_MSG := '产品物料失效校验出错：' || SUBSTR(SQLERRM,1,100);
      UPDATE INTF_BD_ITEM_INVALID T SET T.RESPONSETYPE = 'E',T.RESPONSECODE = '000012',
        T.RESPONSEMESSAGE = P_ERR_MSG, T.RETURN_DATE = SYSDATE 
      WHERE T.INVALID_ID = P_INTF_BD_ITEM_INVALID.INVALID_ID;
  END;

  -----------------------------------------------------------------------------
  --处理产品物料失效校验主过程
  -----------------------------------------------------------------------------
  PROCEDURE P_SYC_ITEM_INVALID_MAIN
  (
    P_ESB_SERIAL_NUM       IN VARCHAR2,--ESB流水号
    P_RESULT         IN OUT NUMBER, --返回错误ID
    P_ERR_MSG        IN OUT VARCHAR2 --返回错误信息
  ) IS
  CURSOR ITEMINVALIDCUR IS
  SELECT T.* FROM CIMS.INTF_BD_ITEM_INVALID T WHERE T.ESB_SERIAL_NUM = P_ESB_SERIAL_NUM;
  ITEMINVALIDROW ITEMINVALIDCUR%ROWTYPE;
  BEGIN
    P_RESULT  := 0;
    P_ERR_MSG := 'SUCCESS';
    OPEN ITEMINVALIDCUR;
  LOOP
    FETCH ITEMINVALIDCUR INTO ITEMINVALIDROW;
    EXIT WHEN ITEMINVALIDCUR%NOTFOUND;
    IF ITEMINVALIDROW.ORGANIZATION_ID IS NULL OR ITEMINVALIDROW.ITEM_CODE IS NULL THEN
    UPDATE INTF_BD_ITEM_INVALID T SET T.RESPONSETYPE = 'W', T.RESPONSECODE = '000011',
      T.RESPONSEMESSAGE = '失败，产品或组织为空', T.RETURN_DATE = SYSDATE 
      WHERE T.INVALID_ID = ITEMINVALIDROW.INVALID_ID;
    GOTO LOOPEND;
    END IF;
    P_SYC_ITEM_INVALID(ITEMINVALIDROW,P_RESULT,P_ERR_MSG);  --单个产品校验
  <<LOOPEND>>
  COMMIT;
  END LOOP;
  CLOSE ITEMINVALIDCUR;
  EXCEPTION
    WHEN OTHERS THEN
      P_RESULT  := -1;
      P_ERR_MSG := '产品物料失效校验出错：' || SQLERRM;
  END;
END PKG_BD_ITEM_INVALID;
/

