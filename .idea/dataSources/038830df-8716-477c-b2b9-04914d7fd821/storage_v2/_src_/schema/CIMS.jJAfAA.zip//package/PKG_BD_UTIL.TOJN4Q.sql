create PACKAGE      PKG_BD_UTIL  AS

   --定义一个字符串临时表类型（相当于一个字符串数组）
   TYPE T_VARRAY IS TABLE OF VARCHAR2(200);

   FUNCTION STR_SPLIT(P_LIST IN VARCHAR2,P_SEP IN VARCHAR2) RETURN T_VARRAY;
   --防重校验
   FUNCTION F_BD_CHECK_REPEAT(p_request_id IN VARCHAR2
                             ,p_check_table IN VARCHAR2
                             ,p_request_id_col VARCHAR2 default 'trx_no'
                             ) RETURN VARCHAR2;
   --校验字符是否为数字
   FUNCTION F_ISNUMERIC(P_STR IN VARCHAR2)  RETURN VARCHAR2;

END PKG_BD_UTIL;
/

