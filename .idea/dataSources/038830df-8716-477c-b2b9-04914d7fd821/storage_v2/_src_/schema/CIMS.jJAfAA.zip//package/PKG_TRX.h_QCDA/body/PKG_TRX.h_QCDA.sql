create Package Body      Pkg_Trx Is

  v_Base_Exception Exception; --自定义异常


  /*
  过程描述：用于检查发票状态是否可进行相关操作
  参数说明：
  P_TRX_ID   发票头ID
  CHECK_TYPE 检查类型（此检查用于什么操作）
  P_RESULT 反回参数，如果返回值不为 ERR_OK 则表示检查失败
  */
  Procedure p_Check_Status(p_Trx_Id   In Number,
                           Check_Type In Varchar2,
                           p_Result   In Out Varchar2) Is
    Vtrxrow   t_So_Trx_Headers%Rowtype;
    Vrowcount Number;
  Begin
    --用于取消合并操作前的状态检查
    If Check_Type = 'CANCEL_TRX_SPLIT' Then
      Select Count(1)
        Into Vrowcount
        From t_So_Trx_Headers         Sth,
             t_So_Trx_Header_Relation Sthr,
             t_So_Trx_Header_Relation Sthr1
       Where (Sth.Trx_Code Is Not Null Or
             Sth.State Not In (Ts_Not_Printed, Ts_In_Queue, Ts_Unknow)) -- 陈伟锋 20110718 增加未引入瑞智系统状态的发票的判断
         And Sth.Idtrx_Id = Sthr.Idtrx_Id
         And Sthr.So_Head_Id = Sthr1.So_Head_Id
         And Sthr1.Idtrx_Id = p_Trx_Id;
      If Vrowcount <= 0 Then
        Begin
          Select *
            Into Vtrxrow
            From t_So_Trx_Headers Sth
           Where Sth.Idtrx_Id = p_Trx_Id
             For Update; --锁定
        Exception
          When No_Data_Found Then
            p_Result := Err_Trx_No_Found;
        End;
      Else
        p_Result := '已拆分单据已引入瑞智 或 ' || Err_Trx_Printed;
      End If; --TS_NOT_PRINTED,TS_IN_QUEUE,TS_UNKNOW代表未开票，发票可以失效/禁止打印
      If p_Result = Err_Ok And Nvl(Vtrxrow.State, Ts_Unknow) Not In
         (Ts_Not_Printed, Ts_In_Queue, Ts_Unknow) Then
        p_Result := Err_Trx_Cannt_Disable; --判断能不能失效/禁止打印
      End If;
    Elsif Check_Type = 'CANCEL_SO_TRX' Then
      ----用于作废操作前的状态检查
      Select Count(1)
        Into Vrowcount
        From t_So_Trx_Headers Sth
       Where Sth.Idtrx_Id = p_Trx_Id;
      If Vrowcount <= 0 Then
        p_Result := Err_Trx_No_Found; --发票ID不存在
      End If;
    Else
      p_Result := '未定义' || Check_Type || '操作的状态检查！';
    End If;
  End;

  --得到发票折扣率
  Function Get_Trx_Discount_Amount(p_Trx_Id t_So_Trx_Headers.Idtrx_Id%Type --发票ID
                                   ) Return Number As
    Vsummtldiscountamount Number;
    Vsumotheramount       Number;
    Vmtllinecount         Number;
    Votherlinecount       Number;
    Vdiscountamount       Number := 0;

  Begin
    Select -1 * Sum(Round(Case
                            When Tl.Item_Id < 0 Or Tl.Discount = 0 Then
                             0
                            Else
                             Tl.Price * Tl.Quantity -
                             Round(Tl.Price * Tl.Quantity * (100 - Nvl(Tl.Discount, 0)) / 100,
                                   2)
                          End,
                          2)),
           Sum(Round(Decode(Sign(Tl.Item_Id),
                            -1,
                            Tl.Price * (100 - Nvl(Tl.Discount, 0)) / 100 *
                            Tl.Quantity,
                            0),
                     2)),
           Count(Decode(Sign(Tl.Item_Id), -1, Null, 1)),
           Count(Decode(Sign(Tl.Item_Id), -1, 1, Null))

      Into Vsummtldiscountamount,
           Vsumotheramount,
           Vmtllinecount,
           Votherlinecount
      From t_So_Trx_Lines Tl
     Where Tl.Idtrx_Id = p_Trx_Id
       And Tl.Discount <> 100
       And Tl.Quantity <> 0
       And Tl.Price <> 0;
    If (Vmtllinecount > 0) Then
      --有普通商品折扣
      Vdiscountamount := Vsummtldiscountamount + Vsumotheramount;
    Elsif (Vmtllinecount = 0 And Votherlinecount <> 0) Then
      --没有普通商品，只有普通的补差单或一批虚拟商品（虚拟折扣折让行不可能在一批商品的情况下存在)
      Select -1 * Sum(Round(Tl.Price * Tl.Quantity -
                            Round(Tl.Price * Tl.Quantity *
                                  (100 - Nvl(Tl.Discount, 0)) / 100,
                                  2),
                            2))
        Into Vdiscountamount
        From t_So_Trx_Lines Tl
       Where Tl.Idtrx_Id = p_Trx_Id;
    End If;
    Return Vdiscountamount;
  End;

  --发票作废和（针对一个发票池头进行作废）
  Procedure Cancel_So_Trx(p_Trx_Id  In t_So_Trx_Headers.Idtrx_Id%Type --作废的发票号码
                         ,
                          p_User_Id In t_So_Trx_Headers.Created_By%Type
                          --用户ID
                         ,
                          p_Result Out Varchar2
                          --返回值
                          ) Is
    Vstate   t_So_Trx_Headers.State%Type;
    Vtrxcode t_So_Trx_Headers.Trx_Code%Type;

    Vcount Number;
  Begin
    p_Result := Err_Ok;
    Savepoint Procstart;

    --检查状态（发票号是否存在）
    p_Check_Status(p_Trx_Id, 'CANCEL_SO_TRX', p_Result);

    --更新发票池对应数据
    If p_Result = Err_Ok Then
      Begin
        Select Sth.State, Sth.Trx_Code
          Into Vstate, Vtrxcode
          From t_So_Trx_Headers Sth
         Where Sth.Idtrx_Id = p_Trx_Id
           For Update;

        If Vstate = Pkg_Trx.Ts_Printed Then
          --更新销售表中对应的发票号
          Update t_So_Header Soh
             Set Soh.Invoice_Num_List = Trim(Substr(Soh.Invoice_Num_List,
                                                    1,
                                                    Instr(Soh.Invoice_Num_List,
                                                          Vtrxcode) - 1)) ||
                                        Trim(Substr(Soh.Invoice_Num_List,
                                                    Instr(Soh.Invoice_Num_List,
                                                          Vtrxcode) +
                                                    Length(Vtrxcode) + 1,
                                                    10000)),
                 Soh.Last_Update_Date = Sysdate,
                 Soh.Last_Updated_By  = p_User_Id
           Where Instr(Soh.Invoice_Num_List, Vtrxcode) > 0
             And Soh.So_Header_Id In
                 (Select Sthr.So_Head_Id
                    From t_So_Trx_Header_Relation Sthr, t_So_Trx_Headers Sth
                   Where Sthr.Idtrx_Id = Sth.Idtrx_Id
                     And Sth.Idtrx_Id = p_Trx_Id);
                     
           Update t_So_Header Soh
             Set Soh.Invoice_Date = null,
                 Soh.Last_Update_Date = Sysdate,
                 Soh.Last_Updated_By  = p_User_Id
           Where Soh.Invoice_Num_List IS NULL
             And Soh.So_Header_Id In
                 (Select Sthr.So_Head_Id
                    From t_So_Trx_Header_Relation Sthr, t_So_Trx_Headers Sth
                   Where Sthr.Idtrx_Id = Sth.Idtrx_Id
                     And Sth.Idtrx_Id = p_Trx_Id);          
                     
                     
          --更新发票池

          Update t_So_Trx_Headers Sth
             Set Sth.Trx_Code         = Null,
                 Sth.Trx_Date         = Null,
                 Sth.Have_Signin_Flag = 'N'
                 --作废发票时将重置巳建回执标志
                ,
                 Sth.State            = Pkg_Trx.Ts_In_Queue,
                 Sth.Last_Updated_By  = p_User_Id,
                 Sth.Last_Update_Date = Sysdate,
                 --add by tangjz 2016-4-6  发票红冲，开票易回调时，增加清除信息：
                 --回执号、EMS号信息、回执号、回执状态、中心签收状态、中心签收日期、客户签收状态、客户签收日期。
                 Sth.center_sign_flag   = 'N',
                 Sth.customer_sign_flag = 'N',
                 Sth.center_sign_date   = null,
                 Sth.customer_sign_date = null,
                 Sth.ems_code           = null,
                 Sth.signin_code        = null

           Where Sth.Idtrx_Id = p_Trx_Id;

          --更新回执单据行为巳作废
          Update t_So_Trx_Signin_Lines Tsl
             Set Tsl.Have_Cancelled_Flag = 'Y'
           Where Tsl.Trx_Id = p_Trx_Id
             And Nvl(Tsl.Have_Cancelled_Flag, 'N') = 'N';

        Else
          --其它状态的发票无法作废
          p_Result := Err_Trx_Not_Cancelable;
        End If;
      Exception
        When No_Data_Found Then
          p_Result := Err_Trx_No_Found;
      End;
    End If;

    If p_Result = Err_Ok Then
      Commit;
    Else
      Rollback To Savepoint Procstart;
    End If;
  Exception
    When Others Then
      Rollback To Savepoint Procstart;
      p_Result := Err_Unknow || Sqlerrm;
  End;

--把发票池接口表的数据转换成正式发票池数据


End Pkg_Trx;
/

