create package      PKG_CREDIT_DIS is
  V_BIZ_EXCEPTION EXCEPTION; --自定义业务异常

  -- Author  : LIANGYM2
  -- Created : 2017/4/10 13:53:03
  -- Purpose :

  --------------------------------------------------------------------------------
  /*
  *   创建日期：2017-04-10
  *     创建者：梁颜明
  *   功能说明：信用管理折扣类型处理
  *
  */
  -------------------------------------------------------------------------------

  V_SUCCESS_MSG VARCHAR2(1000) := 'SUCCESS'; --成功返回信息

  V_NL CONSTANT VARCHAR2(2) := CHR(13) || CHR(10); --换行
  LG_LINE_STATE_NORMAL CONSTANT VARCHAR2(10) := 'NORMAL';
  LG_LINE_STATE_CLOSED CONSTANT VARCHAR2(10) := 'CLOSED';

  /**
  * 折扣类型余款更新历史
  **/
  PROCEDURE P_ADD_DIS_AMOUNT_HIS(IN_ACTION_TYPE     IN NUMBER, --操作类型 非信用控制(销售)写负1，其他（订单、返利）与信用控制动作标识一致 PKG_CREDIT_ACCOUNT_CONTROL PRC_CREDIT_VERIFICATION
                                 IS_ACTION_DESC     IN VARCHAR2, --操作描述 比如销售单新增 销售单更新
                                 IN_ENTITY_ID       IN NUMBER, --主体ID
                                 IN_ACCOUNT_ID      IN NUMBER, --客户账户ID
                                 IN_CREDIT_GROUP_ID IN NUMBER, --额度组ID
                                 IS_SALES_MAIN_TYPE IN VARCHAR2, --营销大类
                                 IS_DISCOUNT_TYPE   IN VARCHAR2, --折扣类型 订单、销售单头上的折扣金额
                                 IN_RECEIPT_AMOUNT  IN NUMBER, --上账金额 只有销售折让、折让证明取结算金额，其他传入0
                                 IN_SALES_AMOUNT    IN NUMBER, --销售金额 只有非销售折让、非折让证明取结算金额，其他传入0
                                 IN_LOCK_AMOUNT     IN NUMBER, --金额 只有锁款、解锁传入结算金额，其他传入0
                                 IN_CASH_AMOUNT     IN NUMBER,--
                                 IS_SOURCE_TYPE     IN VARCHAR2, --来源类型 取码表SO_SRC_TYPE
                                 IN_SOURCE_BILL_ID  IN VARCHAR2, --来源单据ID
                                 IS_USER_NAME       IN VARCHAR2 --操作人
                                 );

  /**
  * 折扣类型余款检查 调用私有过程
  */
  PROCEDURE P_CHECK_DISOUNT_AMOUNT(IN_ENTITY_ID       IN NUMBER, --主体ID
                                   IN_ACCOUNT_ID      IN NUMBER, --客户账户ID
                                   IN_CREDIT_GROUP_ID IN NUMBER, --额度组ID
                                   --IS_SALES_MAIN_TYPE IN VARCHAR2, --营销大类
                                   --IS_DISCOUNT_TYPE   IN VARCHAR2, --折扣类型 取行上的折扣类型
                                   IN_AMOUNT     IN NUMBER, --金额
                                   IN_CHECK_TYPE IN NUMBER, --检查类型 
                                   --1锁款减少
                                   --2锁款增加
                                   --3销售金额减少（手工开退货单、红冲单、结算销售金额减少）
                                   --4销售金额增加锁款减少（锁款自动开单）
                                   --5销售金额增加锁款不变（手工开单、退货红冲单、结算销售金额增加、或无锁款自动开单）
                                   --6上账金额减少（销售折让红冲单、折让证明红冲单、结算上账金额减少）
                                   --7释放全款锁定、增加订金锁定 IN_AMOUNT IN_DOWN_PAY_AMOUNT 都不能为空
                                   --8释放订金、增加全款锁定 IN_AMOUNT IN_DOWN_PAY_AMOUNT 都不能为空
                                   ON_RESULT          OUT NUMBER, --成功则返回0，否则返回对应的出错代码
                                   OS_MESSAGE         OUT VARCHAR2, --成功返回“SUCCESS”；失败返回出错信息
                                   IN_DOWN_PAY_AMOUNT IN NUMBER DEFAULT NULL, --订金金额
                                   IN_DOWN_PAY_SCALE  IN NUMBER DEFAULT NULL --订金比例
                                   ,IN_ORDER_DP_AMOUNT IN NUMBER DEFAULT NULL --订单订金
                                   --,IN_ORDER_DIS_DP_AMOUNT IN NUMBER DEFAULT NULL --订单折扣订金
                                   );

  /**
  * 折扣类型余款检查 入口
  *   1：订单评审
      2：订单取消
      3：开单（销售单，自动开单）
      36 开单（销售单，手工开单）
      4：开单（销售红冲单）
      5：开单（退货单）
      6：开单（退货红冲单）
      7：开单（折让证明单）
      8：开单（折让证明红冲单）
      9：开单（销售折让单）
      10：开单（销售折让红冲单）
      11：开单、结算（扣率折让单）
      12：开单、结算（扣率折让红冲单）
      13 结算[折让证明单,折让证明红冲单,销售折让单,销售折让红冲单]（上账金额，增加IN_AMOUNT传正数，减少IN_AMOUNT传负数）
      14 结算[销售单,销售红冲单,退货单,退货红冲单]（销售金额，增加IN_AMOUNT传正数，减少IN_AMOUNT传负数）
      15：收款确认（不包括三方承兑）（不使用，直接返回成功 ）
      16：收款冲销（不使用，直接返回成功 ）
      17：三方承兑到款（不使用，直接返回成功 ）
      18：三方承兑冲销（不使用，直接返回成功 ）
      19：三方承兑解付（不使用，直接返回成功 ）
      20：三方承兑解付冲销（不使用，直接返回成功 ）
      21：退款（不使用，直接返回成功 ）
      22：铺底审批（铺底）（不使用，直接返回成功 ）
      23：铺底审批（临时铺底）（不使用，直接返回成功 ）
      24：铺底审批（冻结折让）（不使用，直接返回成功 ）
      25：铺底到期（铺底）（不使用，直接返回成功 ）
      26：铺底到期（临时铺底）（不使用，直接返回成功 ）
      27：铺底到期（冻结折让）（不使用，直接返回成功 ）
      28: 解锁订金（不使用，直接返回成功 ）
      29: 锁订金（不使用，直接返回成功 ）
  *             按资源提货（不使用，直接返回成功 ）
                30：资源返利单（不使用，直接返回成功 ）
                31：资源返利红冲单（不使用，直接返回成功 ）
                32：资源提货订单（不使用，直接返回成功 ）
                33：资源提货订单取消（不使用，直接返回成功 ）
                34：资源发放单（不使用，直接返回成功 ）
                40：领用（不使用，直接返回成功 ）
                35:返利调整单
  **/
  PROCEDURE P_CHECK_DIS_AMOUNT(IN_ACTION_TYPE IN NUMBER, --操作类型
                               --与信用控制动作标识一致 PKG_CREDIT_ACCOUNT_CONTROL PRC_CREDIT_VERIFICATION
                               IN_ENTITY_ID       IN NUMBER, --主体ID
                               IN_ACCOUNT_ID      IN NUMBER, --客户账户ID
                               IS_SOURCE_TYPE     IN VARCHAR2, --来源类型 取码表SO_SRC_TYPE
                               IN_SOURCE_BILL_ID  IN NUMBER, --来源单据ID 取相应的单据头ID
                               IS_SALES_MAIN_TYPE IN VARCHAR2, --营销大类
                               IS_DISCOUNT_TYPE   IN VARCHAR2, --折扣类型 取行上的折扣类型
                               IN_AMOUNT          IN NUMBER, --金额
                               IS_USER_NAME       IN VARCHAR2, --操作人
                               IS_ATTRIB01        IN VARCHAR2, --预留输入参数01
                               IS_ATTRIB02        IN VARCHAR2, --预留输入参数02
                               ON_RESULT          OUT NUMBER, --成功则返回0，否则返回对应的出错代码
                               OS_MESSAGE         OUT VARCHAR2, --成功返回“SUCCESS”；失败返回出错信息
                               OS_ATTRIB01        OUT VARCHAR2, --预留输出参数01
                               OS_ATTRIB02        OUT VARCHAR2 --预留输出参数02
                               );

  /**
  * 折扣类型余款更新 调用私有过程
  **/
  PROCEDURE P_UPDATE_DISCOUNT_AMOUNT(IN_ENTITY_ID       IN NUMBER, --主体ID
                                     IN_ACCOUNT_ID      IN NUMBER, --客户账户ID
                                     IS_SALES_MAIN_TYPE IN VARCHAR2, --营销大类
                                     IS_DISCOUNT_TYPE   IN VARCHAR2, --折扣类型 订单、销售单头上的折扣金额
                                     IN_RECEIPT_AMOUNT  IN NUMBER, --上账金额 只有销售折让、折让证明取结算金额，其他传入0
                                     IN_SALES_AMOUNT    IN NUMBER, --销售金额 只有非销售折让、非折让证明取结算金额，其他传入0
                                     IN_LOCK_AMOUNT     IN NUMBER, --金额 只有锁款、解锁传入结算金额，其他传入0
                                     IN_CASH_AMOUNT     IN NUMBER,--收款单据到款金额
                                     IS_USER_NAME       IN VARCHAR2, --操作人
                                     ON_RESULT          OUT NUMBER, --成功则返回0，否则返回对应的出错代码
                                     OS_MESSAGE         OUT VARCHAR2 --成功返回“SUCCESS”；失败返回出错信息
                                     );

  /**
  * 折扣类型余款更新
  **/
  PROCEDURE P_UPDATE_DIS_AMOUNT(IN_ACTION_TYPE IN NUMBER, --操作类型 非信用控制写负1
                                --与信用控制动作标识一致 PKG_CREDIT_ACCOUNT_CONTROL PRC_CREDIT_VERIFICATION
                                IS_ACTION_DESC     IN VARCHAR2, --操作描述 比如销售单新增 销售单更新
                                IN_ENTITY_ID       IN NUMBER, --主体ID
                                IN_ACCOUNT_ID      IN NUMBER, --客户账户ID
                                IS_SALES_MAIN_TYPE IN VARCHAR2, --营销大类
                                IS_DISCOUNT_TYPE   IN VARCHAR2, --折扣类型 订单、销售单头上的折扣金额
                                IN_RECEIPT_AMOUNT  IN NUMBER, --上账金额 只有销售折让、折让证明取结算金额，其他传入0
                                IN_SALES_AMOUNT    IN NUMBER, --销售金额 只有非销售折让、非折让证明取结算金额，其他传入0
                                IN_LOCK_AMOUNT     IN NUMBER, --金额 只有锁款、解锁传入结算金额，其他传入0
                                IN_CASH_AMOUNT     IN NUMBER,--收款单据到款金额
                                IS_SOURCE_TYPE     IN VARCHAR2, --来源类型 取码表SO_SRC_TYPE
                                IN_SOURCE_BILL_ID  IN VARCHAR2, --来源单据ID
                                IS_USER_NAME       IN VARCHAR2, --操作人
                                ON_RESULT          OUT NUMBER, --成功则返回0，否则返回对应的出错代码
                                OS_MESSAGE         OUT VARCHAR2 --成功返回“SUCCESS”；失败返回出错信息
                                );

  /*
  *折扣类型款项冻结
  */
  PROCEDURE P_DIS_AMOUNT_FREEZE(IN_ENTITY_ID       IN NUMBER,
                                IS_CRE_DIS_TYPE_EN IN VARCHAR2 DEFAULT NULL,
    IN_CUSTOMER_ID IN  NUMBER DEFAULT NULL,--客户ID，可以为空
    IN_ACCOUNT_ID  IN  NUMBER DEFAULT NULL,--账户ID，可以为空
    IS_USER_CODE   IN  VARCHAR2 DEFAULT NULL,--更新人，可以为空
    IS_REASON      IN  VARCHAR2 DEFAULT NULL,--更新原因，可以为空
    IS_PRE_ARG     IN  VARCHAR2 DEFAULT 'FREEZE',--预留参数，FREEZE 重算后进行冻结，可以为空（空暂定默认为FREEZE）
    IS_FREEZE_DATE IN  VARCHAR2 DEFAULT NULL--冻结日期 格式YYYYMMDD
                                --,OS_MESSAGE         OUT VARCHAR2 --成功返回“SUCCESS”；失败返回出错信息
                                );

  FUNCTION F_GET_LOCK_AMOUNT(IN_ENTITY_ID       NUMBER, --主体ID 不能为空
                             IN_CUSTOMER_ID     NUMBER, --客户ID 可以为空
                             IN_ACCOUNT_ID      NUMBER, --账户ID 可以为空
                             IN_ACCOUNT_CODE    VARCHAR2, --账户编码 可以为空
                             IN_CREDIT_GROUP_ID NUMBER, --额度组ID 可以为空
                             IN_SALES_CENTER_ID VARCHAR2, --营销中心ID 可以为空
                             IN_DISCOUNT_TYPE   VARCHAR2, --折让方式 可以为空
                             IN_USER_ACC        VARCHAR2 --用户账号 不能为空
                             ) RETURN TAB_CREDIT_LOCK_AMOUNT PIPELINED;

  FUNCTION F_GET_CUSTOMER_AMOUNT(IN_ENTITY_ID         NUMBER, --主体ID 不能为空
                                 IS_CUSTOMER_CODE     VARCHAR2, --客户ID 可以为空
                                 IS_SALES_CENTER_CODE VARCHAR2, --营销中心 可以为空
                                 IS_ACCOUNT_STATUS    VARCHAR2, --
                                 IS_DISCOUNT_TYPE     VARCHAR2, --折让方式 可以为空
                                 IS_FREEZE_DATE       VARCHAR2, --不能为空
                                 IS_USER_ACC          VARCHAR2, --用户账号 不能为空
                                 IS_ACCOUNT_CODE      VARCHAR2 DEFAULT NULL
                                 ) RETURN TAB_SALES_DIS_AMOUNT_FREEZE PIPELINED;

end PKG_CREDIT_DIS;
/

