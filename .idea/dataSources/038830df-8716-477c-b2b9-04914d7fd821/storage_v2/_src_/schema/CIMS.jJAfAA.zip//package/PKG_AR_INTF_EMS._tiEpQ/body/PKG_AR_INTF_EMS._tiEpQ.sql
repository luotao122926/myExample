create PACKAGE BODY PKG_AR_INTF_EMS IS

  -- 费用转到款（安维费、返利费、物流费）接口表数据插入业务表
  PROCEDURE P_FEETURNFEE1_EMS(P_MESSAGE out varchar2 --成功则返回“SUCCESS”，否则返回出错信息
                              ) is
    --PRAGMA AUTONOMOUS_TRANSACTION;
    P_FEE_REIM_ID      varchar2(32); --定义FEE_REIM_ID取值变量
    P_FEE_APPLY_ID     varchar2(32); --定义FEE_APPLY_ID取值变量
    P_CASH_RECEIPT_ID  number; --INTF_AR_CASH_RECEIPT_HEADERS表收款单据ID
    P_CASH_RECEIPT_ID0 number; --EMS_CUX_IMS_RECV_HEADERS表收款单据ID
    --通过收款方法ID以游标方式获取表CUX_IMS_RECV_HEADERS待处理的数据
    CURSOR C_FEETURNFEE1 IS
      SELECT * FROM EMS_CUX_IMS_RECV_HEADERS t WHERE t.FLAG = '0';

    --通过P_FEE_REIM_ID以游标方式获取表INTF_AR_CASH_RECEIPT_HEADERS匹配的数据
    CURSOR C_RECEIPT_HEADERS_REIM IS
      SELECT *
        FROM INTF_AR_CASH_RECEIPT_HEADERS
       WHERE INTF_AR_CASH_RECEIPT_HEADERS.FEE_REIM_ID = P_FEE_REIM_ID;

    --通过P_FEE_APPLY_ID以游标方式获取表INTF_AR_CASH_RECEIPT_HEADERS匹配的数据
    CURSOR C_RECEIPT_HEADERS_APPLY IS
      SELECT *
        FROM INTF_AR_CASH_RECEIPT_HEADERS
       WHERE INTF_AR_CASH_RECEIPT_HEADERS.FEE_APPLY_ID = P_FEE_APPLY_ID;

    --通过P_CASH_RECEIPT_ID以游标方式获取表INTF_AR_CASH_RECEIPT_LINES数据
    CURSOR C_RECEIPT_LINES IS
      SELECT *
        FROM INTF_AR_CASH_RECEIPT_LINES
       WHERE INTF_AR_CASH_RECEIPT_LINES.CASH_RECEIPT_ID = P_CASH_RECEIPT_ID;

    --通过P_CASH_RECEIPT_ID0以游标方式获取表EMS_CUX_IMS_RECV_LINES数据
    CURSOR C_CUX_LINES IS
      SELECT *
        FROM EMS_CUX_IMS_RECV_LINES t
       WHERE t.CASH_RECEIPT_ID = P_CASH_RECEIPT_ID0;

    FEETURNFEE1_ROW          C_FEETURNFEE1%ROWTYPE; --CUX_IMS_RECV_HEADERS表游标行数据
    REIM_ROW                 C_RECEIPT_HEADERS_REIM%ROWTYPE; --表INTF_AR_CASH_RECEIPT_HEADERS匹配的物流费转到款数据
    APPLY_ROW                C_RECEIPT_HEADERS_APPLY%ROWTYPE; --表INTF_AR_CASH_RECEIPT_HEADERS匹配的返利转到款数据
    LINES_ROW                C_RECEIPT_LINES%ROWTYPE; --表INTF_AR_CASH_RECEIPT_HEADERS匹配的返利转到款数据
    CUXLINES_ROW             C_CUX_LINES%ROWTYPE; --EMS_CUX_IMS_RECV_LINES表游标行数据
    AR_RECEIPT_METHODS_ROW   V_AR_RECEIPT_METHODS%ROWTYPE; --收款方法
    DATACOUNT                number; --接口表EMS_CUX_IMS_RECV_HEADERS待处理数据总量
    DATACOUNT1               number; --判断接口表数据是否匹配数量：DATACOUNT1 = 0 不匹配，DATACOUNT1 > 0 匹配
    DATACOUNT2               number; --接口行表INTF_AR_CASH_RECEIPT_LINES数据数量
    DATACOUNT3               number; --接口行表EMS_CUX_IMS_RECV_LINES数据数量
    DATACOUNT8               number; --用于校验ACCOUNT_ID、CUSTOMER_ID、ENTITY_ID是否存在
    DATACOUNT9               number; --用于校验RECEIPT_METHOD_ID
    DATACOUNT10               number; --用于校验收款明细的营销大类
    DATACOUNT4               number; --用于校验EMS单据号是否重复
    V_CASH_RECEIPT_ID        number; --接口表收款单据ID
    V_CASH_RECEIPT_LINES_ID  number; --接口表收款单据行ID
    V_CASH_RECEIPT_ID2       number; --业务表收款单据ID
    V_CASH_RECEIPT_LINES_ID2 number; --业务表收款单据行ID
    V_CASH_RECEIPT_CODE      varchar2(32); --业务表收款单据号
    V_CODE_NAME              number; --校验OU是否存在
    V_BIZ_EXCEPTION EXCEPTION; --自定义业务异常
    V_DISCOUNT_AMOUNT        NUMBER; --返利单金额
    V_DISCOUNT_REMARK        VARCHAR2(4000);
    V_PUB_FIN_SYS            varchar2(32);
    V_AR_AUTO_CONFIRM_CASH   varchar2(32);--是否自动确认主体标记 Y-自动确认  N-手动确认
    V_ERP_OU_ID              number;

  BEGIN
    P_MESSAGE := '执行处理';
    --获取接口表数据数量
    SELECT count(*)
      INTO DATACOUNT
      FROM EMS_CUX_IMS_RECV_HEADERS t
     WHERE t.FLAG = '0';

    if (DATACOUNT > 0) THEN
      BEGIN
        --FOR I IN 1 .. DATACOUNT LOOP
        FOR FEETURNFEE1_ROW IN C_FEETURNFEE1 LOOP
          
          IF FEETURNFEE1_ROW.ENTITY_ID IS NOT NULL THEN
                V_PUB_FIN_SYS:= PKG_BD.F_GET_PARAMETER_VALUE('PUB_FIN_SYS', FEETURNFEE1_ROW.ENTITY_ID , NULL, NULL);      
          ELSE
                V_PUB_FIN_SYS:='ERP';
          END IF;
          
          --AR_AUTO_CONFIRM_CASH 获取自动确认主体参数
          IF FEETURNFEE1_ROW.ENTITY_ID IS NOT NULL THEN
                V_AR_AUTO_CONFIRM_CASH:= PKG_BD.F_GET_PARAMETER_VALUE('AR_AUTO_CONFIRM_CASH', FEETURNFEE1_ROW.ENTITY_ID , NULL, NULL);      
          ELSE
                V_AR_AUTO_CONFIRM_CASH:='0';
          END IF;
               
          IF V_PUB_FIN_SYS='NC' THEN 
               SELECT CODE_VALUE
                 INTO V_ERP_OU_ID
                 FROM V_UP_CODELIST
                WHERE CODETYPE = 'ar_ou_id'
                 AND ENTITY_ID = FEETURNFEE1_ROW.ENTITY_ID;  
          ELSE       
                V_ERP_OU_ID:= FEETURNFEE1_ROW.Ou_Id;
          END IF;
        
        
        
          --校验OU_ID是否为空
          if (V_ERP_OU_ID is null) THEN
            --更新接口表状态为03：校验失败
            P_MESSAGE := '校验失败,OU_ID为空！';
            UPDATE EMS_CUX_IMS_RECV_HEADERS
               SET STATUS = '03', ERROR_INFO = P_MESSAGE, FLAG = '1'
             WHERE CASH_RECEIPT_ID = FEETURNFEE1_ROW.CASH_RECEIPT_ID;
          else
            select count(*)
              into V_CODE_NAME
              from cims.up_codelist
             where codetype = 'ar_ou_id'
               and code_value = V_ERP_OU_ID;

            if (V_CODE_NAME = 0) THEN
              --更新接口表状态为03：校验失败
              P_MESSAGE := '校验失败,OU_ID无效！';
              UPDATE EMS_CUX_IMS_RECV_HEADERS
                 SET STATUS = '03', ERROR_INFO = P_MESSAGE, FLAG = '1'
               WHERE CASH_RECEIPT_ID = FEETURNFEE1_ROW.CASH_RECEIPT_ID;
            else
              --根据TRANS_CODE判断数据是否已处理  2015-10-16 guibr关联交易取EC单号
              if (FEETURNFEE1_ROW.TRANS_CODE is null) THEN
                DATACOUNT4 := 0;
              else
                --获取Source_Code数量
                SELECT count(*)
                  INTO DATACOUNT4
                  FROM T_AR_CASH_RECEIPT_HEADERS t
                 WHERE t.attribute4 = FEETURNFEE1_ROW.TRANS_CODE;
              end if;
              --DATACOUNT4 = 0，表示数据没有处理过，DATACOUNT4>0表示数据之前处理过
              if (DATACOUNT4 = 0) THEN
                if (FEETURNFEE1_ROW.Source_System = 'CIMS') THEN
                  --判断是返利转到款
                  if (FEETURNFEE1_ROW.FEE_REIM_ID is null) THEN

                    select count(*)
                      INTO DATACOUNT1
                      FROM INTF_AR_CASH_RECEIPT_HEADERS
                     WHERE INTF_AR_CASH_RECEIPT_HEADERS.FEE_APPLY_ID =
                           FEETURNFEE1_ROW.FEE_APPLY_ID
                       AND INTF_AR_CASH_RECEIPT_HEADERS.FEE_REIM_ID is null;

                    --判断该笔返利转到款数据是否在INTF_AR_CASH_RECEIPT_HEADERS表内，DATACOUNT1 = 0 不匹配，DATACOUNT1 > 0 匹配,只处理匹配项

                    if (DATACOUNT1 > 0) THEN
                      --给P_FEE_APPLY_ID赋值
                      P_FEE_APPLY_ID := FEETURNFEE1_ROW.FEE_APPLY_ID;
                      
                      BEGIN
                        SELECT PL.DISCOUNT_AMOUNT, PD.REMARK
                          INTO V_DISCOUNT_AMOUNT, V_DISCOUNT_REMARK
                          FROM CIMS.T_POL_DISCOUNT_ORDER PD,
                               CIMS.T_POL_DISCOUNT_LINES PL
                               WHERE PD.EMS_APPLY_ID = P_FEE_APPLY_ID
                                 AND PD.DISCOUNT_ORDER_ID = PL.DISCOUNT_ORDER_ID;
                        EXCEPTION 
                          WHEN OTHERS THEN
                            V_DISCOUNT_AMOUNT := 0;
                      END;
                      
                      --FEETURNFEE1_ROW.REIM_AMOUNT  EMS返回的金额
                      
                      --OPEN C_RECEIPT_HEADERS_APPLY;
                      FOR APPLY_ROW IN C_RECEIPT_HEADERS_APPLY LOOP
                        --if (APPLY_ROW.Reim_Amount =
                        IF (V_DISCOUNT_AMOUNT >=
                           FEETURNFEE1_ROW.REIM_AMOUNT) THEN
                          --给P_CASH_RECEIPT_ID赋值
                          select CASH_RECEIPT_ID
                            INTO P_CASH_RECEIPT_ID
                            from INTF_AR_CASH_RECEIPT_HEADERS
                           where INTF_AR_CASH_RECEIPT_HEADERS.FEE_APPLY_ID =
                                 FEETURNFEE1_ROW.FEE_APPLY_ID;

                          --收款单据号
                          BEGIN
                            V_CASH_RECEIPT_CODE := PKG_BD.F_GET_BILL_NO('ARARCODE',
                                                                        null,
                                                                        APPLY_ROW.Entity_Id,
                                                                        null);
                          EXCEPTION
                            WHEN OTHERS THEN
                              P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_INTF_EMS.P_FEETURNFEE1_EMS',
                                                                  SQLCODE,
                                                                  '返利费转到款取收款单据号失败：' ||
                                                                  SQLERRM);
                              --RAISE V_BIZ_EXCEPTION;
                          END;

                          --获取业务表收款单据ID
                          SELECT S_AR_CASH_RECEIPT_HEADERS.NEXTVAL
                            INTO V_CASH_RECEIPT_ID2
                            FROM DUAL;

                          BEGIN
                            --插入收款头表
                            INSERT INTO T_AR_CASH_RECEIPT_HEADERS
                              (CASH_RECEIPT_ID,
                               RECEIPT_METHOD_ID,
                               RECEIPT_STATUS_ID,
                               ACCOUNT_ID,
                               CUSTOMER_ID,
                               CUSTOMER_CODE,
                               CASH_RECEIPT_CODE,
                               CASH_RECEIPT_DATE,
                               GL_DATE,
                               AMOUNT,
                               CURRENCY_CODE,
                               CASH_CODE,
                               CASH_DATE,
                               DUE_DATE,
                               DRAWER,
                               DRAWER_BANK_ACCOUNT,
                               DRAWER_BANK,
                               BACK_WRITE_NAME,
                               FIRST_RECEIPT_NAME,
                               FIRST_RECEIPT_BANK_ACCOUNT,
                               FIRST_RECEIPT_BANK,
                               ACCEPTANCE_BANK_NAME,
                               BUDGET_ITEM_NAME,
                               CREATED_BY,
                               CREATION_DATE,
                               REMAEK,
                               ENTITY_ID,
                               ATTRIBUTE3,
                               SOURCE_TYPE,
                               CUSTOMER_NAME,
                               ACCOUNT_CODE,
                               ACCOUNT_NAME,
                               SALES_CENTER_ID,
                               ERP_OU_ID,
                               ERP_OU_NAME,
                               ATTRIBUTE4)

                            VALUES
                              (V_CASH_RECEIPT_ID2,
                               APPLY_ROW.RECEIPT_METHOD_ID,
                               '1', --制单状态
                               APPLY_ROW.ACCOUNT_ID,
                               APPLY_ROW.CUSTOMER_ID,
                               (select distinct w.CUSTOMER_CODE
                                  from v_cust_account w
                                 where w.account_id = APPLY_ROW.ACCOUNT_ID
                                   and w.ENTITY_ID = APPLY_ROW.ENTITY_ID
                                   and w.CUSTOMER_ID = APPLY_ROW.CUSTOMER_ID),
                               V_CASH_RECEIPT_CODE,
                               NVL(APPLY_ROW.CASH_RECEIPT_DATE, SYSDATE),
                               NVL(APPLY_ROW.GL_DATE, SYSDATE),
                               --NVL(APPLY_ROW.AMOUNT, APPLY_ROW.APPLY_AMOUNT),
                               --APPLY_ROW.Reim_Amount,
                               FEETURNFEE1_ROW.REIM_AMOUNT,
                               APPLY_ROW.CURRENCY_CODE,
                               APPLY_ROW.CASH_CODE,
                               APPLY_ROW.CASH_DATE,
                               APPLY_ROW.DUE_DATE,
                               APPLY_ROW.DRAWER,
                               APPLY_ROW.DRAWER_BANK_ACCOUNT,
                               APPLY_ROW.DRAWER_BANK,
                               APPLY_ROW.BACK_WRITE_NAME,
                               APPLY_ROW.FIRST_RECEIPT_NAME,
                               APPLY_ROW.FIRST_RECEIPT_BANK_ACCOUNT,
                               APPLY_ROW.FIRST_RECEIPT_BANK,
                               APPLY_ROW.ACCEPTANCE_BANK_NAME,
                               (select t.budgetitemcode
                                  from intf_gtsp_budget_project t
                                 where t.attribute1 = 'Y'),
                               APPLY_ROW.CREATED_BY,
                               APPLY_ROW.CREATION_DATE,
                               V_DISCOUNT_REMARK,--记录返利单备注
                               APPLY_ROW.ENTITY_ID,
                               'EMS',
                               APPLY_ROW.SOURCE_TYPE,
                               (select distinct w.CUSTOMER_NAME
                                  from v_cust_account w
                                 where w.account_id = APPLY_ROW.ACCOUNT_ID
                                   and w.ENTITY_ID = APPLY_ROW.ENTITY_ID
                                   and w.CUSTOMER_ID = APPLY_ROW.CUSTOMER_ID),
                               (select distinct w.ACCOUNT_CODE
                                  from v_cust_account w
                                 where w.account_id = APPLY_ROW.ACCOUNT_ID
                                   and w.ENTITY_ID = APPLY_ROW.ENTITY_ID),
                               (select distinct w.ACCOUNT_NAME
                                  from v_cust_account w
                                 where w.account_id = APPLY_ROW.ACCOUNT_ID
                                   and w.ENTITY_ID = APPLY_ROW.ENTITY_ID),
                               (select distinct w.SALES_CENTER_ID
                                  from v_cust_account w
                                 where w.account_id = APPLY_ROW.ACCOUNT_ID
                                   and w.ENTITY_ID = APPLY_ROW.ENTITY_ID
                                   and w.CUSTOMER_ID = APPLY_ROW.CUSTOMER_ID),
                               /*(select distinct t.erp_ou_id
                                from T_AR_OU_RELATION t
                               where t.entity_id = APPLY_ROW.ENTITY_ID
                                 and t.sales_center_id =
                                     (select distinct w.SALES_CENTER_ID
                                        from v_cust_account w
                                       where w.account_id =
                                             APPLY_ROW.ACCOUNT_ID
                                         and w.ENTITY_ID = APPLY_ROW.ENTITY_ID
                                         and w.CUSTOMER_ID =
                                             APPLY_ROW.CUSTOMER_ID)),*/
                               V_ERP_OU_ID,
                               /*(select distinct t.erp_ou_name
                                from T_AR_OU_RELATION t
                               where t.entity_id = APPLY_ROW.ENTITY_ID
                                 and t.sales_center_id =
                                     (select distinct w.SALES_CENTER_ID
                                        from v_cust_account w
                                       where w.account_id =
                                             APPLY_ROW.ACCOUNT_ID
                                         and w.ENTITY_ID = APPLY_ROW.ENTITY_ID
                                         and w.CUSTOMER_ID =
                                             APPLY_ROW.CUSTOMER_ID)),*/
                               (select code_name
                                  from cims.up_codelist
                                 where codetype = 'ar_ou_id'
                                   and code_value = V_ERP_OU_ID),
                               FEETURNFEE1_ROW.TRANS_CODE);
                          EXCEPTION
                            WHEN OTHERS THEN

                              P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_INTF_EMS.P_FEETURNFEE1_EMS',
                                                                  SQLCODE,
                                                                  '返利费转到款插入收款头表失败：' ||
                                                                  SQLERRM);
                              --RAISE V_BIZ_EXCEPTION;
                          END;

                          --获取接口行表INTF_AR_CASH_RECEIPT_LINES数据数量
                          SELECT count(*)
                            INTO DATACOUNT2
                            FROM INTF_AR_CASH_RECEIPT_LINES
                           WHERE INTF_AR_CASH_RECEIPT_LINES.CASH_RECEIPT_ID =
                                 P_CASH_RECEIPT_ID;

                          if (DATACOUNT2 > 0) THEN
                            FOR LINES_ROW IN C_RECEIPT_LINES LOOP

                              --获取业务表收款单据行ID
                              SELECT S_AR_CASH_RECEIPT_LINES.NEXTVAL
                                INTO V_CASH_RECEIPT_LINES_ID2
                                FROM DUAL;
                              
                              --add 校验营销大类是否是该客户的经营范围 add by huanghb12
                              select count(*)
                                into DATACOUNT10
                                from cims.t_customer_sales_main_type u
                                where u.custom_id = APPLY_ROW.CUSTOMER_ID
                                and u.entity_id = APPLY_ROW.ENTITY_ID
                                and u.sales_main_type_code = LINES_ROW.Sales_Main_Type_Code;
                              --如果用户指定的营销大类不准确，则随机获取一个
                              if DATACOUNT10 <=0 then
                                select u.sales_main_type_code
                                into LINES_ROW.Sales_Main_Type_Code
                                from cims.t_customer_sales_main_type u
                                where u.custom_id = APPLY_ROW.CUSTOMER_ID
                                and u.entity_id = APPLY_ROW.ENTITY_ID
                                and rownum = 1;
                              end if;
                              --end 校验营销大类

                              BEGIN
                                --插入收款行表
                                INSERT INTO T_AR_CASH_RECEIPT_LINES
                                  (CASH_RECEIPT_LINES_ID,
                                   CASH_RECEIPT_ID,
                                   AMOUNT,
                                   REMARK,
                                   SALES_MAIN_TYPE_ID,
                                   SALES_MAIN_TYPE_CODE,
                                   SALES_MAIN_TYPE_NAME,
                                   BRAND_CODE,
                                   ENTITY_ID)
                                VALUES
                                  (V_CASH_RECEIPT_LINES_ID2,
                                   V_CASH_RECEIPT_ID2,
                                   --LINES_ROW.REIM_AMOUNT,
                                   FEETURNFEE1_ROW.REIM_AMOUNT,
                                   V_DISCOUNT_REMARK, --LINES_ROW.REMARK,--记录返利单备注
                                   (select t.item_class_id
                                      from t_bd_item_class t
                                     where t.CLASS_CODE =
                                           LINES_ROW.Sales_Main_Type_Code and t.entity_id= APPLY_ROW.ENTITY_ID ),
                                   LINES_ROW.Sales_Main_Type_Code,
                                   (select t.class_name
                                      from t_bd_item_class t
                                     where t.CLASS_CODE =
                                           LINES_ROW.Sales_Main_Type_Code and t.entity_id= APPLY_ROW.ENTITY_ID),
                                   '',
                                   APPLY_ROW.ENTITY_ID);
                              EXCEPTION
                                WHEN OTHERS THEN

                                  P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_INTF_EMS.P_FEETURNFEE1_EMS',
                                                                      SQLCODE,
                                                                      '返利费转到款插入收款行表失败：' ||
                                                                      SQLERRM);
                                  --RAISE V_BIZ_EXCEPTION;
                              END;
                            END LOOP;
                          end if;

                          P_MESSAGE := 'SUCCESS';
                          --更新收款接口头表INTF_AR_CASH_RECEIPT_HEADERS,STATUS状态为0：成功,FLAG:1 已处理
                          UPDATE INTF_AR_CASH_RECEIPT_HEADERS
                             SET CASH_RECEIPT_CODE = V_CASH_RECEIPT_CODE,
                                 STATUS            = '04',
                                 ERROR_INFO        = P_MESSAGE
                           WHERE CASH_RECEIPT_ID =
                                 APPLY_ROW.CASH_RECEIPT_ID;

                          --更新收款接口行表INTF_AR_CASH_RECEIPT_LINES,STATUS状态为0：成功,FLAG:1 已处理
                          UPDATE INTF_AR_CASH_RECEIPT_LINES
                             SET STATUS = '04', ERROR_INFO = P_MESSAGE
                           WHERE CASH_RECEIPT_ID =
                                 APPLY_ROW.CASH_RECEIPT_ID;

                          --更新表CUX_IMS_RECV_HEADERS,STATUS状态为0：成功,FLAG:1 已处理
                          UPDATE EMS_CUX_IMS_RECV_HEADERS
                             SET CASH_RECEIPT_CODE = V_CASH_RECEIPT_CODE,
                                 STATUS            = '04',
                                 ERROR_INFO        = P_MESSAGE,
                                 FLAG              = '1'
                           WHERE CASH_RECEIPT_ID =
                                 FEETURNFEE1_ROW.CASH_RECEIPT_ID;

                        else
                          P_MESSAGE := FEETURNFEE1_ROW.CASH_RECEIPT_ID ||
                                       --'EMS接口表金额与CIMS接口表金额不一致！';
                                       'EMS接口表金额大于Cims返利单金额！';
                          UPDATE EMS_CUX_IMS_RECV_HEADERS
                             SET STATUS     = '03',
                                 ERROR_INFO = P_MESSAGE,
                                 FLAG       = '1'
                           WHERE CASH_RECEIPT_ID =
                                 FEETURNFEE1_ROW.CASH_RECEIPT_ID;

                        end if;

                      END LOOP;
                      --CLOSE C_RECEIPT_HEADERS_APPLY;
                    else
                      --更新接口表EMS_CUX_IMS_RECV_HEADERS状态为03：失败
                      P_MESSAGE := FEETURNFEE1_ROW.Source_Code ||
                                   '数据在收款接口表中不存在。';
                      /*UPDATE EMS_CUX_IMS_RECV_HEADERS
                        SET STATUS = '03', ERROR_INFO = P_MESSAGE, FLAG = '1'
                      WHERE CASH_RECEIPT_ID = FEETURNFEE1_ROW.CASH_RECEIPT_ID;*/

                    end if;
                    --判断是物流费转到款
                  elsif (FEETURNFEE1_ROW.Fee_Apply_Id is null) THEN

                    --elsif (FEETURNFEE1_ROW.RECEIPT_METHOD_ID in ('10', '430')) THEN
                    select count(*)
                      INTO DATACOUNT1
                      FROM INTF_AR_CASH_RECEIPT_HEADERS
                     WHERE INTF_AR_CASH_RECEIPT_HEADERS.FEE_REIM_ID =
                           FEETURNFEE1_ROW.FEE_REIM_ID
                       AND INTF_AR_CASH_RECEIPT_HEADERS.Fee_Apply_Id is null;

                    --判断该笔物流费转到款数据是否在INTF_AR_CASH_RECEIPT_HEADERS表内，DATACOUNT1 = 0 不匹配，DATACOUNT1 > 0 匹配,只处理匹配项
                    if (DATACOUNT1 > 0) THEN
                      --给P_FEE_APPLY_ID赋值
                      P_FEE_REIM_ID := FEETURNFEE1_ROW.FEE_REIM_ID;
                      --OPEN C_RECEIPT_HEADERS_REIM;
                      FOR REIM_ROW IN C_RECEIPT_HEADERS_REIM LOOP
                        if (REIM_ROW.Reim_Amount =
                           FEETURNFEE1_ROW.Reim_Amount) THEN

                          --给P_CASH_RECEIPT_ID赋值
                          select CASH_RECEIPT_ID
                            INTO P_CASH_RECEIPT_ID
                            from INTF_AR_CASH_RECEIPT_HEADERS
                           where INTF_AR_CASH_RECEIPT_HEADERS.FEE_REIM_ID =
                                 FEETURNFEE1_ROW.FEE_REIM_ID;

                          --收款单据号
                          BEGIN
                            V_CASH_RECEIPT_CODE := PKG_BD.F_GET_BILL_NO('ARARCODE',
                                                                        null,
                                                                        REIM_ROW.Entity_Id,
                                                                        null);
                          EXCEPTION
                            WHEN OTHERS THEN

                              P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_INTF_EMS.P_FEETURNFEE1_EMS',
                                                                  SQLCODE,
                                                                  '物流费转到款取收款单据号失败：' ||
                                                                  SQLERRM);
                              --RAISE V_BIZ_EXCEPTION;
                          END;

                          --获取业务表收款单据ID
                          SELECT S_AR_CASH_RECEIPT_HEADERS.NEXTVAL
                            INTO V_CASH_RECEIPT_ID2
                            FROM DUAL;

                          BEGIN
                            --插入收款头表
                            INSERT INTO T_AR_CASH_RECEIPT_HEADERS
                              (CASH_RECEIPT_ID,
                               RECEIPT_METHOD_ID,
                               RECEIPT_STATUS_ID,
                               ACCOUNT_ID,
                               CUSTOMER_ID,
                               CUSTOMER_CODE,
                               CASH_RECEIPT_CODE,
                               CASH_RECEIPT_DATE,
                               GL_DATE,
                               AMOUNT,
                               CURRENCY_CODE,
                               CASH_CODE,
                               CASH_DATE,
                               DUE_DATE,
                               DRAWER,
                               DRAWER_BANK_ACCOUNT,
                               DRAWER_BANK,
                               BACK_WRITE_NAME,
                               FIRST_RECEIPT_NAME,
                               FIRST_RECEIPT_BANK_ACCOUNT,
                               FIRST_RECEIPT_BANK,
                               ACCEPTANCE_BANK_NAME,
                               BUDGET_ITEM_NAME,
                               CREATED_BY,
                               CREATION_DATE,
                               REMAEK,
                               ENTITY_ID,
                               ATTRIBUTE3,
                               SOURCE_TYPE,
                               CUSTOMER_NAME,
                               ACCOUNT_CODE,
                               ACCOUNT_NAME,
                               SALES_CENTER_ID,
                               ERP_OU_ID,
                               ERP_OU_NAME,
                               ATTRIBUTE4)

                            VALUES
                              (V_CASH_RECEIPT_ID2,
                               REIM_ROW.RECEIPT_METHOD_ID,
                               '1', --制单状态
                               REIM_ROW.ACCOUNT_ID,
                               REIM_ROW.CUSTOMER_ID,
                               (select distinct w.CUSTOMER_CODE
                                  from v_cust_account w
                                 where w.account_id = REIM_ROW.ACCOUNT_ID
                                   and w.ENTITY_ID = REIM_ROW.ENTITY_ID
                                   and w.CUSTOMER_ID = REIM_ROW.CUSTOMER_ID),
                               V_CASH_RECEIPT_CODE,
                               NVL(REIM_ROW.CASH_RECEIPT_DATE, SYSDATE),
                               NVL(REIM_ROW.GL_DATE, SYSDATE),
                               --NVL(REIM_ROW.AMOUNT, REIM_ROW.REIM_AMOUNT),
                               REIM_ROW.REIM_AMOUNT,
                               REIM_ROW.CURRENCY_CODE,
                               REIM_ROW.CASH_CODE,
                               REIM_ROW.CASH_DATE,
                               REIM_ROW.DUE_DATE,
                               REIM_ROW.DRAWER,
                               REIM_ROW.DRAWER_BANK_ACCOUNT,
                               REIM_ROW.DRAWER_BANK,
                               REIM_ROW.BACK_WRITE_NAME,
                               REIM_ROW.FIRST_RECEIPT_NAME,
                               REIM_ROW.FIRST_RECEIPT_BANK_ACCOUNT,
                               REIM_ROW.FIRST_RECEIPT_BANK,
                               REIM_ROW.ACCEPTANCE_BANK_NAME,
                               (select t.budgetitemcode
                                  from intf_gtsp_budget_project t
                                 where t.attribute1 = 'Y'),
                               REIM_ROW.CREATED_BY,
                               REIM_ROW.CREATION_DATE,
                               REIM_ROW.REMAEK,
                               REIM_ROW.ENTITY_ID,
                               'EMS',
                               REIM_ROW.SOURCE_TYPE,
                               (select distinct w.CUSTOMER_NAME
                                  from v_cust_account w
                                 where w.account_id = REIM_ROW.ACCOUNT_ID
                                   and w.ENTITY_ID = REIM_ROW.ENTITY_ID),
                               (select distinct w.ACCOUNT_CODE
                                  from v_cust_account w
                                 where w.account_id = REIM_ROW.ACCOUNT_ID
                                   and w.ENTITY_ID = REIM_ROW.ENTITY_ID),
                               (select distinct w.ACCOUNT_NAME
                                  from v_cust_account w
                                 where w.account_id = REIM_ROW.ACCOUNT_ID
                                   and w.ENTITY_ID = REIM_ROW.ENTITY_ID),
                               (select distinct w.SALES_CENTER_ID
                                  from v_cust_account w
                                 where w.account_id = REIM_ROW.ACCOUNT_ID
                                   and w.ENTITY_ID = REIM_ROW.ENTITY_ID
                                   and w.CUSTOMER_ID = REIM_ROW.CUSTOMER_ID),
                               /*(select distinct t.erp_ou_id
                                  from T_AR_OU_RELATION t
                                 where t.entity_id = REIM_ROW.ENTITY_ID
                                   and t.sales_center_id =
                                       (select distinct w.SALES_CENTER_ID
                                          from v_cust_account w
                                         where w.account_id = REIM_ROW.ACCOUNT_ID
                                           and w.ENTITY_ID = REIM_ROW.ENTITY_ID
                                           and w.CUSTOMER_ID =
                                               REIM_ROW.CUSTOMER_ID)),
                               (select distinct t.erp_ou_name
                                  from T_AR_OU_RELATION t
                                 where t.entity_id = REIM_ROW.ENTITY_ID
                                   and t.sales_center_id =
                                       (select distinct w.SALES_CENTER_ID
                                          from v_cust_account w
                                         where w.account_id = REIM_ROW.ACCOUNT_ID
                                           and w.ENTITY_ID = REIM_ROW.ENTITY_ID
                                           and w.CUSTOMER_ID =
                                               REIM_ROW.CUSTOMER_ID)),*/
                               V_ERP_OU_ID,
                               (select code_name
                                  from cims.up_codelist
                                 where codetype = 'ar_ou_id'
                                   and code_value = V_ERP_OU_ID),
                               FEETURNFEE1_ROW.TRANS_CODE);
                          EXCEPTION
                            WHEN OTHERS THEN

                              P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_INTF_EMS.P_FEETURNFEE1_EMS',
                                                                  SQLCODE,
                                                                  '物流费转到款插入收款头表失败：' ||
                                                                  SQLERRM);
                              --RAISE V_BIZ_EXCEPTION;
                          END;

                          --获取接口行表INTF_AR_CASH_RECEIPT_HEADERS数据数量
                          SELECT count(*)
                            INTO DATACOUNT2
                            FROM INTF_AR_CASH_RECEIPT_LINES
                           WHERE INTF_AR_CASH_RECEIPT_LINES.CASH_RECEIPT_ID =
                                 P_CASH_RECEIPT_ID;

                          if (DATACOUNT2 > 0) THEN
                            FOR LINES_ROW IN C_RECEIPT_LINES LOOP

                              --获取业务表收款单据行ID
                              SELECT S_AR_CASH_RECEIPT_LINES.NEXTVAL
                                INTO V_CASH_RECEIPT_LINES_ID2
                                FROM DUAL;
                              
                              --add 校验营销大类是否是该客户的经营范围 add by huanghb12
                              select count(*)
                                into DATACOUNT10
                                from cims.t_customer_sales_main_type u
                                where u.custom_id = REIM_ROW.CUSTOMER_ID
                                and u.entity_id = REIM_ROW.ENTITY_ID
                                and u.sales_main_type_code = LINES_ROW.Sales_Main_Type_Code;
                              --如果用户指定的营销大类不准确，则随机获取一个
                              if DATACOUNT10 <=0 then
                                select u.sales_main_type_code
                                into LINES_ROW.Sales_Main_Type_Code
                                from cims.t_customer_sales_main_type u
                                where u.custom_id = REIM_ROW.CUSTOMER_ID
                                and u.entity_id = REIM_ROW.ENTITY_ID
                                and rownum = 1;
                              end if;
                              --end 校验营销大类

                              BEGIN
                                --插入收款行表
                                INSERT INTO T_AR_CASH_RECEIPT_LINES
                                  (CASH_RECEIPT_LINES_ID,
                                   CASH_RECEIPT_ID,
                                   AMOUNT,
                                   REMARK,
                                   SALES_MAIN_TYPE_ID,
                                   SALES_MAIN_TYPE_CODE,
                                   SALES_MAIN_TYPE_NAME,
                                   BRAND_CODE,
                                   ENTITY_ID)
                                VALUES
                                  (V_CASH_RECEIPT_LINES_ID2,
                                   V_CASH_RECEIPT_ID2,
                                   LINES_ROW.REIM_AMOUNT,
                                   LINES_ROW.REMARK,
                                   (select t.item_class_id
                                      from t_bd_item_class t
                                     where t.CLASS_CODE =
                                           LINES_ROW.Sales_Main_Type_Code and t.entity_id= REIM_ROW.ENTITY_ID),
                                   LINES_ROW.Sales_Main_Type_Code,
                                   (select t.class_name
                                      from t_bd_item_class t
                                     where t.CLASS_CODE =
                                           LINES_ROW.Sales_Main_Type_Code and t.entity_id= REIM_ROW.ENTITY_ID),
                                   '',
                                   REIM_ROW.ENTITY_ID);
                              EXCEPTION
                                WHEN OTHERS THEN

                                  P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_INTF_EMS.P_FEETURNFEE1_EMS',
                                                                      SQLCODE,
                                                                      '物流费转到款插入收款行表失败：' ||
                                                                      SQLERRM);
                                  --RAISE V_BIZ_EXCEPTION;
                              END;

                            END LOOP;
                          end if;

                          P_MESSAGE := 'SUCCESS';
                          --更新收款接口头表INTF_AR_CASH_RECEIPT_HEADERS,STATUS状态为0：成功,FLAG:1 已处理
                          UPDATE INTF_AR_CASH_RECEIPT_HEADERS
                             SET CASH_RECEIPT_CODE = V_CASH_RECEIPT_CODE,
                                 STATUS            = '04',
                                 ERROR_INFO        = P_MESSAGE
                           WHERE CASH_RECEIPT_ID = REIM_ROW.CASH_RECEIPT_ID;

                          --更新收款接口行表INTF_AR_CASH_RECEIPT_LINES,STATUS状态为0：成功
                          UPDATE INTF_AR_CASH_RECEIPT_LINES
                             SET STATUS = '04', ERROR_INFO = P_MESSAGE
                           WHERE CASH_RECEIPT_ID = REIM_ROW.CASH_RECEIPT_ID;

                          --更新表CUX_IMS_RECV_HEADERS,STATUS状态为0：成功,FLAG:1 已处理
                          UPDATE EMS_CUX_IMS_RECV_HEADERS
                             SET CASH_RECEIPT_CODE = V_CASH_RECEIPT_CODE,
                                 STATUS            = '04',
                                 ERROR_INFO        = P_MESSAGE,
                                 FLAG              = '1'
                           WHERE CASH_RECEIPT_ID =
                                 FEETURNFEE1_ROW.CASH_RECEIPT_ID;

                        else
                          P_MESSAGE := FEETURNFEE1_ROW.CASH_RECEIPT_ID ||
                                       'EMS接口表金额与CIMS接口表金额不一致！';
                          UPDATE EMS_CUX_IMS_RECV_HEADERS
                             SET STATUS     = '03',
                                 ERROR_INFO = P_MESSAGE,
                                 FLAG       = '1'
                           WHERE CASH_RECEIPT_ID =
                                 FEETURNFEE1_ROW.CASH_RECEIPT_ID;

                        end if;

                      END LOOP;
                      --CLOSE C_RECEIPT_HEADERS_REIM;
                    else
                      --更新接口表EMS_CUX_IMS_RECV_HEADERS状态为03：失败
                      P_MESSAGE := FEETURNFEE1_ROW.Source_Code ||
                                   '数据在收款接口表中不存在。';
                      /*UPDATE EMS_CUX_IMS_RECV_HEADERS
                        SET STATUS = '03', ERROR_INFO = P_MESSAGE, FLAG = '1'
                      WHERE CASH_RECEIPT_ID = FEETURNFEE1_ROW.CASH_RECEIPT_ID;*/

                    end if;

                  end if;
                 --判断是安维转到款或其他转到款
                else
                  
                  --校验AMOUNT是否是负数
                  if (FEETURNFEE1_ROW.Amount < 0) THEN

                    --更新接口表状态为03：校验失败
                    P_MESSAGE := '校验失败,AMOUNT是负数！';
                    UPDATE EMS_CUX_IMS_RECV_HEADERS
                       SET STATUS     = '03',
                           ERROR_INFO = P_MESSAGE,
                           FLAG       = '1'
                     WHERE CASH_RECEIPT_ID =
                           FEETURNFEE1_ROW.CASH_RECEIPT_ID;
                  else
                    --校验ACCOUNT_ID、CUSTOMER_ID、ENTITY_ID是否存在
                    select count(*)
                      INTO DATACOUNT8
                      from V_CUST_ACCOUNT t
                     where t.account_id = FEETURNFEE1_ROW.Account_Id
                       and t.customer_id = FEETURNFEE1_ROW.Customer_Id
                       and t.entity_id = FEETURNFEE1_ROW.Entity_Id;

                    if (DATACOUNT8 = 0) THEN
                      --更新接口表EMS_CUX_IMS_RECV_HEADERS状态为03：失败
                      P_MESSAGE := '校验失败,ACCOUNT_ID、CUSTOMER_ID、ENTITY_ID值错误！';
                      UPDATE EMS_CUX_IMS_RECV_HEADERS
                         SET STATUS     = '03',
                             ERROR_INFO = P_MESSAGE,
                             FLAG       = '1'
                       WHERE CASH_RECEIPT_ID =
                             FEETURNFEE1_ROW.CASH_RECEIPT_ID;
                    else
                      --校验RECEIPT_METHOD_ID
                      select count(*)
                        INTO DATACOUNT9
                        from V_AR_RECEIPT_METHODS t
                       where t.receipt_method_id =
                             FEETURNFEE1_ROW.RECEIPT_METHOD_ID
                         and t.entity_id = FEETURNFEE1_ROW.Entity_Id;

                      if (DATACOUNT9 = 0) THEN
                        --更新接口表EMS_CUX_IMS_RECV_HEADERS状态为03：失败
                        P_MESSAGE := '校验失败,RECEIPT_METHOD_ID值错误！';
                        UPDATE EMS_CUX_IMS_RECV_HEADERS
                           SET STATUS     = '03',
                               ERROR_INFO = P_MESSAGE,
                               FLAG       = '1'
                         WHERE CASH_RECEIPT_ID =
                               FEETURNFEE1_ROW.CASH_RECEIPT_ID;

                      else

                        --elsif (FEETURNFEE1_ROW.RECEIPT_METHOD_ID in ('12', '431')) THEN

                        --给P_CASH_RECEIPT_ID0赋值
                        P_CASH_RECEIPT_ID0 := FEETURNFEE1_ROW.CASH_RECEIPT_ID;

                        --收款单据号
                        BEGIN
                          V_CASH_RECEIPT_CODE := PKG_BD.F_GET_BILL_NO('ARARCODE',
                                                                      null,
                                                                      FEETURNFEE1_ROW.Entity_Id,
                                                                      null);
                        EXCEPTION
                          WHEN OTHERS THEN

                            P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_INTF_EMS.P_FEETURNFEE1_EMS',
                                                                SQLCODE,
                                                                '安维转到款或其他转到款取收款单据号失败：' ||
                                                                SQLERRM);
                            --RAISE V_BIZ_EXCEPTION;
                        END;

                        --获取接口表收款单据ID
                        SELECT S_INTF_AR_CASH_RECEIPT_HEADERS.NEXTVAL
                          INTO V_CASH_RECEIPT_ID
                          FROM DUAL;

                        --获取业务表收款单据ID
                        SELECT S_AR_CASH_RECEIPT_HEADERS.NEXTVAL
                          INTO V_CASH_RECEIPT_ID2
                          FROM DUAL;

                        BEGIN
                          --插入收款接口头表
                          INSERT INTO INTF_AR_CASH_RECEIPT_HEADERS
                            (CASH_RECEIPT_ID,
                             RECEIPT_METHOD_ID,
                             ACCOUNT_ID,
                             CUSTOMER_ID,
                             CUSTOMER_CODE,
                             CASH_RECEIPT_CODE,
                             CASH_RECEIPT_DATE,
                             GL_DATE,
                             AMOUNT,
                             APPLY_AMOUNT,
                             REIM_AMOUNT,
                             CURRENCY_CODE,
                             CASH_CODE,
                             CASH_DATE,
                             DUE_DATE,
                             DRAWER,
                             DRAWER_BANK_ACCOUNT,
                             DRAWER_BANK,
                             BACK_WRITE_NAME,
                             FIRST_RECEIPT_NAME,
                             FIRST_RECEIPT_BANK_ACCOUNT,
                             FIRST_RECEIPT_BANK,
                             ACCEPTANCE_BANK_NAME,
                             CREATED_BY,
                             CREATION_DATE,
                             REMAEK,
                             ENTITY_ID,
                             SOURCE_TYPE,
                             SOURCE_ID,
                             SOURCE_CODE,
                             SOURCE_SYSTEM,
                             REFUND_APPLY_ID,
                             FEE_REIM_ID,
                             FEE_APPLY_ID,
                             STATUS,
                             ERROR_INFO)
                          VALUES
                            (V_CASH_RECEIPT_ID,
                             FEETURNFEE1_ROW.RECEIPT_METHOD_ID,
                             FEETURNFEE1_ROW.ACCOUNT_ID,
                             FEETURNFEE1_ROW.CUSTOMER_ID,
                             FEETURNFEE1_ROW.CUSTOMER_CODE,
                             FEETURNFEE1_ROW.CASH_RECEIPT_CODE,
                             NVL(FEETURNFEE1_ROW.CASH_RECEIPT_DATE, SYSDATE),
                             NVL(FEETURNFEE1_ROW.GL_DATE, SYSDATE),
                             FEETURNFEE1_ROW.AMOUNT,
                             FEETURNFEE1_ROW.APPLY_AMOUNT,
                             FEETURNFEE1_ROW.REIM_AMOUNT,
                             FEETURNFEE1_ROW.CURRENCY_CODE,
                             FEETURNFEE1_ROW.CASH_CODE,
                             FEETURNFEE1_ROW.CASH_DATE,
                             FEETURNFEE1_ROW.DUE_DATE,
                             FEETURNFEE1_ROW.DRAWER,
                             FEETURNFEE1_ROW.DRAWER_BANK_ACCOUNT,
                             FEETURNFEE1_ROW.DRAWER_BANK,
                             FEETURNFEE1_ROW.BACK_WRITE_NAME,
                             FEETURNFEE1_ROW.FIRST_RECEIPT_NAME,
                             FEETURNFEE1_ROW.FIRST_RECEIPT_BANK_ACCOUNT,
                             FEETURNFEE1_ROW.FIRST_RECEIPT_BANK,
                             FEETURNFEE1_ROW.ACCEPTANCE_BANK_NAME,
                             FEETURNFEE1_ROW.CREATED_BY,
                             FEETURNFEE1_ROW.CREATION_DATE,
                             FEETURNFEE1_ROW.REMAEK,
                             FEETURNFEE1_ROW.ENTITY_ID,
                             FEETURNFEE1_ROW.SOURCE_TYPE,
                             FEETURNFEE1_ROW.SOURCE_ID,
                             FEETURNFEE1_ROW.TRANS_CODE,
                             FEETURNFEE1_ROW.SOURCE_SYSTEM,
                             FEETURNFEE1_ROW.REFUND_APPLY_ID,
                             FEETURNFEE1_ROW.FEE_REIM_ID,
                             FEETURNFEE1_ROW.FEE_APPLY_ID,
                             '04',
                             'SUCCESS');
                        EXCEPTION
                          WHEN OTHERS THEN

                            P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_INTF_EMS.P_FEETURNFEE1_EMS',
                                                                SQLCODE,
                                                                '安维转到款或其他转到款插入收款接口头表失败：' ||
                                                                SQLERRM);
                            --RAISE V_BIZ_EXCEPTION;
                        END;

                        BEGIN
                          --插入收款头表
                          INSERT INTO T_AR_CASH_RECEIPT_HEADERS
                            (CASH_RECEIPT_ID,
                             RECEIPT_METHOD_ID,
                             RECEIPT_STATUS_ID,
                             ACCOUNT_ID,
                             CUSTOMER_ID,
                             CUSTOMER_CODE,
                             CASH_RECEIPT_CODE,
                             CASH_RECEIPT_DATE,
                             GL_DATE,
                             AMOUNT,
                             CURRENCY_CODE,
                             CASH_CODE,
                             CASH_DATE,
                             DUE_DATE,
                             DRAWER,
                             DRAWER_BANK_ACCOUNT,
                             DRAWER_BANK,
                             BACK_WRITE_NAME,
                             FIRST_RECEIPT_NAME,
                             FIRST_RECEIPT_BANK_ACCOUNT,
                             FIRST_RECEIPT_BANK,
                             ACCEPTANCE_BANK_NAME,
                             BUDGET_ITEM_NAME,
                             CREATED_BY,
                             CREATION_DATE,
                             REMAEK,
                             ENTITY_ID,
                             ATTRIBUTE3,
                             SOURCE_TYPE,
                             CUSTOMER_NAME,
                             ACCOUNT_CODE,
                             ACCOUNT_NAME,
                             SALES_CENTER_ID,
                             ERP_OU_ID,
                             ERP_OU_NAME,
                             ATTRIBUTE4)

                          VALUES
                            (V_CASH_RECEIPT_ID2,
                             FEETURNFEE1_ROW.RECEIPT_METHOD_ID,
                             '1', --制单状态
                             FEETURNFEE1_ROW.ACCOUNT_ID,
                             FEETURNFEE1_ROW.CUSTOMER_ID,
                             (select distinct w.CUSTOMER_CODE
                                from v_cust_account w
                               where w.account_id =
                                     FEETURNFEE1_ROW.ACCOUNT_ID
                                 and w.ENTITY_ID = FEETURNFEE1_ROW.ENTITY_ID
                                 and w.CUSTOMER_ID =
                                     FEETURNFEE1_ROW.CUSTOMER_ID),
                             V_CASH_RECEIPT_CODE,
                             NVL(FEETURNFEE1_ROW.CASH_RECEIPT_DATE, SYSDATE),
                             NVL(FEETURNFEE1_ROW.GL_DATE, SYSDATE),
                             FEETURNFEE1_ROW.AMOUNT,
                             FEETURNFEE1_ROW.CURRENCY_CODE,
                             FEETURNFEE1_ROW.CASH_CODE,
                             FEETURNFEE1_ROW.CASH_DATE,
                             FEETURNFEE1_ROW.DUE_DATE,
                             FEETURNFEE1_ROW.DRAWER,
                             FEETURNFEE1_ROW.DRAWER_BANK_ACCOUNT,
                             FEETURNFEE1_ROW.DRAWER_BANK,
                             FEETURNFEE1_ROW.BACK_WRITE_NAME,
                             FEETURNFEE1_ROW.FIRST_RECEIPT_NAME,
                             FEETURNFEE1_ROW.FIRST_RECEIPT_BANK_ACCOUNT,
                             FEETURNFEE1_ROW.FIRST_RECEIPT_BANK,
                             FEETURNFEE1_ROW.ACCEPTANCE_BANK_NAME,
                             (select t.budgetitemcode
                                from intf_gtsp_budget_project t
                               where t.attribute1 = 'Y'),
                             FEETURNFEE1_ROW.CREATED_BY,
                             FEETURNFEE1_ROW.CREATION_DATE,
                             FEETURNFEE1_ROW.REMAEK,
                             FEETURNFEE1_ROW.ENTITY_ID,
                             'EMS',
                             FEETURNFEE1_ROW.SOURCE_TYPE,
                             (select distinct w.CUSTOMER_NAME
                                from v_cust_account w
                               where w.account_id =
                                     FEETURNFEE1_ROW.ACCOUNT_ID
                                 and w.ENTITY_ID = FEETURNFEE1_ROW.ENTITY_ID),
                             (select distinct w.ACCOUNT_CODE
                                from v_cust_account w
                               where w.account_id =
                                     FEETURNFEE1_ROW.ACCOUNT_ID
                                 and w.ENTITY_ID = FEETURNFEE1_ROW.ENTITY_ID),
                             (select distinct w.ACCOUNT_NAME
                                from v_cust_account w
                               where w.account_id =
                                     FEETURNFEE1_ROW.ACCOUNT_ID
                                 and w.ENTITY_ID = FEETURNFEE1_ROW.ENTITY_ID),
                             (select distinct w.SALES_CENTER_ID
                                from v_cust_account w
                               where w.account_id =
                                     FEETURNFEE1_ROW.ACCOUNT_ID
                                 and w.ENTITY_ID = FEETURNFEE1_ROW.ENTITY_ID
                                 and w.CUSTOMER_ID =
                                     FEETURNFEE1_ROW.CUSTOMER_ID),
                             /*(select distinct t.erp_ou_id
                                from T_AR_OU_RELATION t
                               where t.entity_id = FEETURNFEE1_ROW.ENTITY_ID
                                 and t.sales_center_id =
                                     (select distinct w.SALES_CENTER_ID
                                        from v_cust_account w
                                       where w.account_id =
                                             FEETURNFEE1_ROW.ACCOUNT_ID
                                         and w.ENTITY_ID = FEETURNFEE1_ROW.ENTITY_ID
                                         and w.CUSTOMER_ID =
                                             FEETURNFEE1_ROW.CUSTOMER_ID)),
                             (select distinct t.erp_ou_name
                                from T_AR_OU_RELATION t
                               where t.entity_id = FEETURNFEE1_ROW.ENTITY_ID
                                 and t.sales_center_id =
                                     (select distinct w.SALES_CENTER_ID
                                        from v_cust_account w
                                       where w.account_id =
                                             FEETURNFEE1_ROW.ACCOUNT_ID
                                         and w.ENTITY_ID = FEETURNFEE1_ROW.ENTITY_ID
                                         and w.CUSTOMER_ID =
                                             FEETURNFEE1_ROW.CUSTOMER_ID)),*/
                             V_ERP_OU_ID,
                             (select code_name
                                from cims.up_codelist
                               where codetype = 'ar_ou_id'
                                 and code_value = V_ERP_OU_ID),
                             FEETURNFEE1_ROW.TRANS_CODE);
                        EXCEPTION
                          WHEN OTHERS THEN

                            P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_INTF_EMS.P_FEETURNFEE1_EMS',
                                                                SQLCODE,
                                                                '安维转到款或其他转到款插入收款头表失败：' ||
                                                                SQLERRM);
                            --RAISE V_BIZ_EXCEPTION;
                        END;

                        --获取接口行表EMS_CUX_IMS_RECV_LINES数据数量
                        SELECT count(*)
                          INTO DATACOUNT3
                          FROM EMS_CUX_IMS_RECV_LINES t
                         WHERE t.CASH_RECEIPT_ID = P_CASH_RECEIPT_ID0;

                        if (DATACOUNT3 > 0) THEN
                          FOR CUXLINES_ROW IN C_CUX_LINES LOOP

                            --获取接口表收款单据行ID
                            SELECT S_INTF_AR_CASH_RECEIPT_LINES.NEXTVAL
                              INTO V_CASH_RECEIPT_LINES_ID
                              FROM DUAL;

                            --获取业务表收款单据行ID
                            SELECT S_AR_CASH_RECEIPT_LINES.NEXTVAL
                              INTO V_CASH_RECEIPT_LINES_ID2
                              FROM DUAL;

                            BEGIN
                              --插入收款接口行表
                              INSERT INTO INTF_AR_CASH_RECEIPT_LINES
                                (CASH_RECEIPT_LINES_ID,
                                 CASH_RECEIPT_ID,
                                 AMOUNT,
                                 APPLY_AMOUNT,
                                 REIM_AMOUNT,
                                 REMARK,
                                 SALES_MAIN_TYPE_ID,
                                 SALES_MAIN_TYPE_CODE,
                                 SALES_MAIN_TYPE_NAME,
                                 SOURCE_TYPE,
                                 SOURCE_ID,
                                 SOURCE_CODE,
                                 SOURCE_SYSTEM,
                                 STATUS,
                                 ERROR_INFO)
                              VALUES
                                (V_CASH_RECEIPT_LINES_ID,
                                 V_CASH_RECEIPT_ID,
                                 CUXLINES_ROW.AMOUNT,
                                 CUXLINES_ROW.APPLY_AMOUNT,
                                 CUXLINES_ROW.REIM_AMOUNT,
                                 CUXLINES_ROW.REMARK,
                                 CUXLINES_ROW.SALES_MAIN_TYPE_ID,
                                 CUXLINES_ROW.SALES_MAIN_TYPE_CODE,
                                 CUXLINES_ROW.SALES_MAIN_TYPE_NAME,
                                 CUXLINES_ROW.SOURCE_TYPE,
                                 CUXLINES_ROW.SOURCE_ID,
                                 CUXLINES_ROW.SOURCE_CODE,
                                 CUXLINES_ROW.SOURCE_SYSTEM,
                                 '04',
                                 'SUCCESS');
                            EXCEPTION
                              WHEN OTHERS THEN

                                P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_INTF_EMS.P_FEETURNFEE1_EMS',
                                                                    SQLCODE,
                                                                    '安维转到款或其他转到款插入收款接口行表失败：' ||
                                                                    SQLERRM);
                                --RAISE V_BIZ_EXCEPTION;
                            END;
                            --add 校验营销大类是否是该客户的经营范围 add by huanghb
                            select count(*)
                              into DATACOUNT10
                              from cims.t_customer_sales_main_type u
                              where u.custom_id = FEETURNFEE1_ROW.Customer_id
                              and u.entity_id = FEETURNFEE1_ROW.ENTITY_ID
                              and u.sales_main_type_code = (select t.class_code
                                                              from t_bd_item_class t
                                                             where t.item_class_id =
                                                                   CUXLINES_ROW.SALES_MAIN_TYPE_ID);
                            --如果用户指定的营销大类不准确，则随机获取一个
                            if DATACOUNT10 <=0 then
                              select t.item_class_id
                              into CUXLINES_ROW.SALES_MAIN_TYPE_ID
                              from cims.t_customer_sales_main_type u
                              ,cims.t_bd_item_class t
                              where u.sales_main_type_code = t.class_code
                              and u.entity_id = t.entity_id
                              and u.custom_id = FEETURNFEE1_ROW.Customer_id
                              and u.entity_id = FEETURNFEE1_ROW.ENTITY_ID
                              and rownum = 1;
                            end if;
                            --end 校验营销大类
                            BEGIN
                              --插入收款业务行表
                              INSERT INTO T_AR_CASH_RECEIPT_LINES
                                (CASH_RECEIPT_LINES_ID,
                                 CASH_RECEIPT_ID,
                                 AMOUNT,
                                 REMARK,
                                 SALES_MAIN_TYPE_ID,
                                 SALES_MAIN_TYPE_CODE,
                                 SALES_MAIN_TYPE_NAME,
                                 BRAND_CODE,
                                 ENTITY_ID)
                              VALUES
                                (V_CASH_RECEIPT_LINES_ID2,
                                 V_CASH_RECEIPT_ID2,
                                 CUXLINES_ROW.REIM_AMOUNT,
                                 CUXLINES_ROW.REMARK,
                                 CUXLINES_ROW.SALES_MAIN_TYPE_ID,
                                 (select t.class_code
                                    from t_bd_item_class t
                                   where t.item_class_id =
                                         CUXLINES_ROW.SALES_MAIN_TYPE_ID),
                                 (select t.class_name
                                    from t_bd_item_class t
                                   where t.item_class_id =
                                         CUXLINES_ROW.SALES_MAIN_TYPE_ID),
                                 '',
                                 FEETURNFEE1_ROW.ENTITY_ID);
                            EXCEPTION
                              WHEN OTHERS THEN

                                P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_INTF_EMS.P_FEETURNFEE1_EMS',
                                                                    SQLCODE,
                                                                    '安维转到款或其他转到款插入收款业务行表失败：' ||
                                                                    SQLERRM);
                                --RAISE V_BIZ_EXCEPTION;
                            END;

                          END LOOP;
                        end if;

                        P_MESSAGE := 'SUCCESS';

                        --更新表CUX_IMS_RECV_HEADERS,STATUS状态为04：成功,FLAG:1 已处理
                        UPDATE EMS_CUX_IMS_RECV_HEADERS
                           SET CASH_RECEIPT_CODE = V_CASH_RECEIPT_CODE,
                               STATUS            = '04',
                               ERROR_INFO        = P_MESSAGE,
                               FLAG              = '1'
                         WHERE CASH_RECEIPT_ID =
                               FEETURNFEE1_ROW.CASH_RECEIPT_ID;

                      end if;

                    end if;
                  end if;
                    --add 费用转到款自动确认2019-7-22
                    --收款方法为推广费用转到款的时候，如果主体参数配置自动确认或者收款方法本身就是自动确认，那么这笔款会自动确认     
                    if P_MESSAGE = 'SUCCESS' AND TO_NUMBER(V_AR_AUTO_CONFIRM_CASH) > 0 THEN
                      if  TO_NUMBER(to_char(sysdate,'dd')) >= TO_NUMBER(V_AR_AUTO_CONFIRM_CASH) AND V_CASH_RECEIPT_ID2 IS NOT NULL THEN
                        --调用确认接口
                      PKG_AR_BOND.P_RECEIPT_HEAD_CONFIRM(
                                                          V_CASH_RECEIPT_ID2, --收款头ID
                                                          'admin', --用户账户
                                                          P_MESSAGE, --成功则返回“SUCCESS”，否则返回出错信息
                                                          V_CASH_RECEIPT_CODE --成功则返回收款单号
                                                         );
                      end if;
                    END IF;
                    --end 费用转到款自动确认2019-7-22
                end if;

              else
                --更新接口表EMS_CUX_IMS_RECV_HEADERS状态为03：失败
                P_MESSAGE := FEETURNFEE1_ROW.Source_Code ||
                             '数据已处理，EMS接口表存在重复数据。';
                UPDATE EMS_CUX_IMS_RECV_HEADERS
                   SET STATUS = '03', ERROR_INFO = P_MESSAGE, FLAG = '1'
                 WHERE CASH_RECEIPT_ID = FEETURNFEE1_ROW.CASH_RECEIPT_ID;
              end if;

            end if;
          end if;

        END LOOP;
        --异常处理
      EXCEPTION
        WHEN OTHERS THEN

          ROLLBACK;
          --记录出错信息
          P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_INTF_EMS.P_FEETURNFEE1_EMS',
                                              SQLCODE,
                                              '：' || SQLERRM);

          --更新接口表EMS_CUX_IMS_RECV_HEADERS状态为1：失败
          UPDATE EMS_CUX_IMS_RECV_HEADERS
             SET STATUS = '03', ERROR_INFO = P_MESSAGE, FLAG = '1'
           WHERE CASH_RECEIPT_ID = FEETURNFEE1_ROW.CASH_RECEIPT_ID;

          --更新接口表INTF_AR_CASH_RECEIPT_HEADERS状态为1：失败
          UPDATE INTF_AR_CASH_RECEIPT_HEADERS
             SET STATUS = '1', ERROR_INFO = P_MESSAGE
           WHERE CASH_RECEIPT_ID = P_CASH_RECEIPT_ID;

          --更新接口表INTF_AR_CASH_RECEIPT_LINES状态为1：失败
          UPDATE INTF_AR_CASH_RECEIPT_LINES
             SET STATUS = '1', ERROR_INFO = P_MESSAGE
           WHERE CASH_RECEIPT_ID = P_CASH_RECEIPT_ID;

        --RAISE V_BIZ_EXCEPTION;
      END;

      COMMIT;

    end if;
  EXCEPTION
    WHEN OTHERS THEN
      --dbms_output.put_line(SQLERRM);
      --记录出错信息
      P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_INTF_EMS.P_FEETURNFEE1_EMS',
                                          SQLCODE,
                                          '：' || SQLERRM);
      COMMIT;

  END;

END PKG_AR_INTF_EMS;
/

