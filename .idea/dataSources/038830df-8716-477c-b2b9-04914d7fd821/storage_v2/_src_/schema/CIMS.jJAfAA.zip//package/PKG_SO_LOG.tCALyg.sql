create PACKAGE PKG_SO_LOG IS
  PROCEDURE P_ACTION_LOG(P_TABLE_NAME     VARCHAR2, --操作表名称
                         P_ACTION_REMARKS VARCHAR2, --操作说明
                         P_PK             VARCHAR2, --关键主键
                         P_ISERR          NUMBER, --是否出错，1出错，0未出错
                         P_ERR_LINE       VARCHAR2, --错误跑出行数
                         P_MSG            VARCHAR2 --错误信息
                         );
END PKG_SO_LOG;
/

