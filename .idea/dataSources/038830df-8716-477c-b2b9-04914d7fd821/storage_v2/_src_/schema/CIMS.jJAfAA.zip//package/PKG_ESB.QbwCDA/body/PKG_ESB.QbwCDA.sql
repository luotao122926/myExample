create Package Body PKG_ESB Is

  --操作编码
  V_OPER_CODE_INSERT CONSTANT VARCHAR2(10) := 'INSERT';
  V_OPER_CODE_UPDATE CONSTANT VARCHAR2(10) := 'UPDATE';

  --时间格式
  V_DT_FORMAT CONSTANT VARCHAR2(22) := 'yyyy-mm-dd hh24:mi:ss';

  --ERP返回状态：COMPLETED（处理成功）
  V_ERP_COMPLETED CONSTANT VARCHAR2(10) := 'COMPLETED';

  --返回编码,成功：success，失败：failed
  V_RETURN_CODE CONSTANT VARCHAR2(100) := 'success';
  V_RETURN_MSG  CONSTANT VARCHAR2(100) := '执行成功';

  procedure P_ESB_RESULT_BATCH_DEAL
  (
     P_MOD         IN  NUMBER,
     P_MOD_REM     IN  NUMBER,
     P_RETURN_CODE out varchar2, --返回编码
     P_RETURN_MSG  out varchar2  --返回信息
   )is

  begin
   FOR ESB_RESULT_BATCH_ROW IN (
         SELECT
          RB.DATA_SOURCE
         ,RB.REQUEST_ID
         ,RB.RESULT_BACK_ID
        FROM
           T_BD_ESB_RESULT_BACK RB
          ,T_BD_ESB_RESULT_PRC PRC
        WHERE PRC.DATA_SOURCE = RB.DATA_SOURCE
        AND   NVL(RB.HAS_DEALED,'N')='N'   --未处理的数据
        AND   PRC.ACTIVE_FLAG='Y'          --需要处理的接口
        AND   RB.BACK_DATE>=TO_DATE('2015-10-12','YYYY-MM-DD') --过滤之前未处理的数据，防止重复处理
        AND   MOD(RB.RESULT_BACK_ID,P_MOD) = P_MOD_REM
        AND   ROWNUM<1000  ---一次处理一千条
       -- FOR UPDATE NOWAIT
   )LOOP
           BEGIN
            --  SAVEPOINT SP;
              FOR ESB_RESULT_BATCH_ROW_DETAIL IN (
                   SELECT
                     DISTINCT BD.SOURCE_ID1
                   FROM
                     T_BD_ESB_RESULT_BACK_DETAIL BD
                    WHERE
                     BD.RESULT_BACK_ID = ESB_RESULT_BATCH_ROW.RESULT_BACK_ID
              )LOOP
                   BEGIN
                      P_ESB_RESULT_DEAL(
                              ESB_RESULT_BATCH_ROW.REQUEST_ID
                             ,ESB_RESULT_BATCH_ROW_DETAIL.SOURCE_ID1
                             ,ESB_RESULT_BATCH_ROW.DATA_SOURCE
                             ,P_RETURN_CODE
                             ,P_RETURN_MSG);
                      IF P_RETURN_CODE = 'failed' THEN
                          RAISE_APPLICATION_ERROR(-20001,P_RETURN_MSG);
                      END IF;
                   END;
               END LOOP;
               --设置ESB异步回调已处理
               UPDATE T_BD_ESB_RESULT_BACK SET HAS_DEALED = 'Y',LAST_UPDATE_DATE = SYSDATE WHERE REQUEST_ID = ESB_RESULT_BATCH_ROW.REQUEST_ID;
               commit;
            EXCEPTION
                 WHEN OTHERS THEN
                     ROLLBACK;
                     --设置ESB异步回调处理错误
                     UPDATE T_BD_ESB_RESULT_BACK SET HAS_DEALED = 'E',LAST_UPDATE_DATE = SYSDATE WHERE REQUEST_ID = ESB_RESULT_BATCH_ROW.REQUEST_ID;
                     P_RETURN_CODE := 'failed';
                     P_RETURN_MSG  := PKG_BD.F_ADD_ERROR_LOG('PKG_ESB.P_ESB_RESULT_DEAL_'
                                                        ||ESB_RESULT_BATCH_ROW.REQUEST_ID,
                                                         sqlcode,
                                                        '步回回调失败：'||sqlerrm);
            END;
    END LOOP;

  exception
    when others then
       P_RETURN_CODE := 'failed';
       P_RETURN_MSG  := PKG_BD.F_ADD_ERROR_LOG('PKG_ESB.P_ESB_RESULT_BATCH_DEAL',
                                                         sqlcode,
                                                         '步回回调失败：'||sqlerrm);
  end;


  procedure P_ESB_RESULT_DEAL
  (
   P_REQUEST_ID  in  varchar2, --请求ID（交易流水与）
   P_SOURCE_ID1  in  varchar2, --单据来源ID或编码
   P_DATA_SOURCE  in  varchar2, --数据来源（接口编码）
   P_RETURN_CODE out varchar2, --返回编码,成功：success，失败：failed
   P_RETURN_MSG  out varchar2  --返回信息，成功：执行成功，失败：具体失败信息
   )
   is
   LS_PRC_NAME t_bd_esb_result_prc.prc_name%type;
   LS_SQL_STR          VARCHAR2(320); --动态执行SQL语句

  begin
      /**
        ERP-IMS-001  订单接口  ERP销售SO订单生成
        ERP-IMS-002  挑库接口  ERP销售SO订单挑库
        ERP-IMS-003  订单接口  ERP销售SO订单日期变更、价格调整
        ERP-IMS-004  发运接口  ERP销售SO订单发运确认
        ERP-IMS-005            ERP销售SO挑库、发运确认（拉式）
        ERP-IMS-006  订单接口  ERP RMA生成
        ERP-IMS-007  接收  ERP RMA接收
        ERP-IMS-008  订单接口  ERP销售折让订单生成、折让证明订单生成
        ERP-IMS-009  订单接口  ERP销售折让订单登记、折让证明订单登记
        ERP-IMS-010  订单接口  ERP销售折让红冲单登记、折让证明红冲单登记
        ERP-IMS-013  收款      收款
        ERP-IMS-015  收款冲销  收款冲销
        ERP-IMS-017  应收发票  应收发票
        ERP-IMS-022  库存事务处理接口  账户别名处理
        ERP-IMS-023  库存事务处理接口  子库存转移
        ERP-IMS-024  库存事务处理接口  组织间转移
        ERP-IMS-025  物料      推广物料信息
        ERP-IMS-026  成本接口  推广物料成本接口
        ERP-IMS-027  采购订单接收入库  采购订单接收入库(推广物料)
        ERP-IMS-028  采购订单接收入库  采购订单退货(推广物料)
        ERP-IMS-060  AR接口    纸票在途核销
        ERP-IMS-061  核销关系  核销关系(收款核销发票)
        ERP-IMS-063  采购订单  采购订单
        ERP-IMS-074  核销关系  核销关系(正负发票核销)
        CIMS         关联交易  订单和物流
    **/

      --根据接口编码找到对应的处理过程
      SELECT prc_name into LS_PRC_NAME from t_bd_esb_result_prc where data_source = P_DATA_SOURCE and active_flag='Y';

      --liaolz 2014-11-07
      if (LS_PRC_NAME = 'PKG_ESB.P_ESB_RESULT_DEAL_1') then
        --订单接口  ERP销售SO订单生成
        P_ESB_RESULT_DEAL_1(P_REQUEST_ID,P_SOURCE_ID1,P_RETURN_CODE, P_RETURN_MSG);
      elsif (LS_PRC_NAME = 'PKG_ESB.P_ESB_RESULT_DEAL_2') then
        --挑库接口  ERP销售SO订单挑库
        P_ESB_RESULT_DEAL_2(P_REQUEST_ID,P_SOURCE_ID1, P_RETURN_CODE, P_RETURN_MSG);
      elsif (LS_PRC_NAME = 'PKG_ESB.P_ESB_RESULT_DEAL_3') then
        --订单接口  ERP销售SO订单日期变更、价格调整
        P_ESB_RESULT_DEAL_3(P_REQUEST_ID,P_SOURCE_ID1, P_RETURN_CODE, P_RETURN_MSG);
      elsif (LS_PRC_NAME = 'PKG_ESB.P_ESB_RESULT_DEAL_4') then
        --发运接口  ERP销售SO订单发运确认
        P_ESB_RESULT_DEAL_4(P_REQUEST_ID,P_SOURCE_ID1, P_RETURN_CODE, P_RETURN_MSG);
      elsif (LS_PRC_NAME = 'PKG_ESB.P_ESB_RESULT_DEAL_5') then
        --ERP销售SO挑库、发运确认（拉式）
        P_ESB_RESULT_DEAL_5(P_REQUEST_ID,P_SOURCE_ID1, P_RETURN_CODE, P_RETURN_MSG);
      elsif (LS_PRC_NAME = 'PKG_ESB.P_ESB_RESULT_DEAL_6') then
        --订单接口  ERP RMA生成
        P_ESB_RESULT_DEAL_6(P_REQUEST_ID,P_SOURCE_ID1, P_RETURN_CODE, P_RETURN_MSG);
      elsif (LS_PRC_NAME = 'PKG_ESB.P_ESB_RESULT_DEAL_7') then
        --接收  ERP RMA接收
        P_ESB_RESULT_DEAL_7(P_REQUEST_ID,P_SOURCE_ID1, P_RETURN_CODE, P_RETURN_MSG);
      elsif (LS_PRC_NAME = 'PKG_ESB.P_ESB_RESULT_DEAL_8') then
        --订单接口  ERP销售折让订单生成、折让证明订单生成
        P_ESB_RESULT_DEAL_8(P_REQUEST_ID,P_SOURCE_ID1, P_RETURN_CODE, P_RETURN_MSG);
      elsif (LS_PRC_NAME = 'PKG_ESB.P_ESB_RESULT_DEAL_9') then
        --订单接口  ERP销售折让订单登记、折让证明订单登记
        P_ESB_RESULT_DEAL_9(P_REQUEST_ID,P_SOURCE_ID1, P_RETURN_CODE, P_RETURN_MSG);
      elsif (LS_PRC_NAME = 'PKG_ESB.P_ESB_RESULT_DEAL_10') then
        --订单接口  ERP销售折让红冲单登记、折让证明红冲单登记
        P_ESB_RESULT_DEAL_10(P_REQUEST_ID,P_SOURCE_ID1, P_RETURN_CODE, P_RETURN_MSG);
      elsif (LS_PRC_NAME = 'PKG_ESB.P_ESB_RESULT_DEAL_61') then
        --核销接口 兼容新老接口
        if instr(P_SOURCE_ID1,'Cims')=0 then
           P_ESB_RESULT_DEAL_61_1(P_REQUEST_ID,P_SOURCE_ID1, P_RETURN_CODE, P_RETURN_MSG);
        else
           P_ESB_RESULT_DEAL_61(P_REQUEST_ID,P_SOURCE_ID1, P_RETURN_CODE, P_RETURN_MSG);
        end if;
      elsif (LS_PRC_NAME = 'PKG_ESB.P_ESB_RESULT_DEAL_74') then
        --核销接口 兼容新老接口
        if instr(P_SOURCE_ID1,'Cims')=0 then
           P_ESB_RESULT_DEAL_74_1(P_REQUEST_ID,P_SOURCE_ID1, P_RETURN_CODE, P_RETURN_MSG);
        else
           P_ESB_RESULT_DEAL_74(P_REQUEST_ID,P_SOURCE_ID1, P_RETURN_CODE, P_RETURN_MSG);
        end if;
      elsif (LS_PRC_NAME = 'PKG_ESB.P_ESB_RESULT_DEAL_87') then
        --异步推送产品编码至ERP接口成功回调 huanghb12
        P_ESB_RESULT_DEAL_87(P_REQUEST_ID,P_SOURCE_ID1, P_RETURN_CODE, P_RETURN_MSG);
      Elsif (LS_PRC_NAME = 'PKG_ESB.P_ESB_RESULT_DEAL_88') Then
        --OEM产品触发SCP送货通知接口异步回调 lilh6
        P_ESB_RESULT_DEAL_88(P_REQUEST_ID,P_SOURCE_ID1, P_RETURN_CODE, P_RETURN_MSG);
      else
        --动态生成需要执行存储过程的SQL语句
        LS_SQL_STR := 'BEGIN ' || LS_PRC_NAME || '(:V1,:V2,:V3,:V4); END;';
        --执行该SQL语句
        EXECUTE IMMEDIATE LS_SQL_STR
            USING IN P_REQUEST_ID,IN P_SOURCE_ID1, OUT P_RETURN_CODE, OUT P_RETURN_MSG; --参数类型和传递顺序与存储过程中的保持一致
        --输出返回值
      --  Dbms_Output.Put_Line(P_RETURN_CODE || P_RETURN_MSG);
      end if;

      /*liaolz 2014-11-07 注释
      --动态生成需要执行存储过程的SQL语句
      LS_SQL_STR := 'BEGIN ' || LS_PRC_NAME || '(:V1,:V2,:V3); END;';
      --执行该SQL语句
      EXECUTE IMMEDIATE LS_SQL_STR
          USING IN P_REQUEST_ID, OUT P_RETURN_CODE, OUT P_RETURN_MSG; --参数类型和传递顺序与存储过程中的保持一致
      --输出返回值
      Dbms_Output.Put_Line(P_RETURN_CODE || P_RETURN_MSG);
      */
  exception
    when others then
       P_RETURN_CODE := 'failed';
       P_RETURN_MSG  := PKG_BD.F_ADD_ERROR_LOG('PKG_ESB.'||LS_PRC_NAME||P_DATA_SOURCE,
                                                         sqlcode,
                                                         '步回回调失败：'||sqlerrm);

  end;


  --ERP销售SO订单生成回调处理过程
  PROCEDURE P_ESB_RESULT_DEAL_1(P_REQUEST_ID  in  varchar2, --请求ID（交易流水号）
                                P_SOURCE_ID1  in  varchar2, --单据来源ID或编码
                                P_RETURN_CODE out varchar2, --返回编码,成功：success，失败：failed
                                P_RETURN_MSG  out varchar2  --返回信息，成功：执行成功，失败：具体失败信息
                               ) IS
    --接口返回结果游标
    CURSOR C_RESULT_BACK IS
      SELECT RB.REQUEST_ID, RB.DATA_SOURCE, RB.BACK_DATE,
             RD.SOURCE_ID1, RD.SOURCE_ID2, RD.SOURCE_ID3, RD.STATUS,
             RD.ERROR_CODE, RD.ERROR_MESSAGE, RD.TARGET_ID1, RD.TARGET_ID2, RD.TARGET_ID3
      FROM T_BD_ESB_RESULT_BACK RB, T_BD_ESB_RESULT_BACK_DETAIL RD
      WHERE RB.RESULT_BACK_ID = RD.RESULT_BACK_ID
        AND RB.REQUEST_ID = P_REQUEST_ID
        AND RD.SOURCE_ID1 = P_SOURCE_ID1
        AND (RB.HAS_DEALED IS NULL OR RB.HAS_DEALED != 'Y');
    --接口返回结果记录集
    R_RESULT_BACK C_RESULT_BACK%ROWTYPE;

    --CIMS的销售单据头ID
    V_SO_HEADER_ID  T_BD_ESB_RESULT_BACK_DETAIL.SOURCE_ID1%TYPE;
    --ERP的销售订单头ID
    V_ERP_SO_HEADER_ID  T_BD_ESB_RESULT_BACK_DETAIL.TARGET_ID1%TYPE;

    V_SOURCE_ID2 T_BD_ESB_RESULT_BACK_DETAIL.SOURCE_ID2%TYPE;
    V_SOURCE_ID3 T_BD_ESB_RESULT_BACK_DETAIL.SOURCE_ID3%TYPE;
    V_TARGET_ID2 T_BD_ESB_RESULT_BACK_DETAIL.TARGET_ID2%TYPE;
    V_TARGET_ID3 T_BD_ESB_RESULT_BACK_DETAIL.TARGET_ID3%TYPE;

    --ERP错误标识
    V_ERP_ERROR_FLAG CHAR(1) := 'N';
    --循环计数器
    V_CNT NUMBER := 0;
    --ERP返回的时间
    V_BACK_DATE DATE := SYSDATE;
    --错误信息
    V_ERROR_MSG VARCHAR2(30000);

    --执行更新接口头跟踪信息
    V_UPDATE_MSG VARCHAR2(128) := '';
    V_STATUS     VARCHAR2(10) := '';
    V_ITEM_CODE VARCHAR2(300);

    --临时变量
    TMP_OE_HEADER_ID NUMBER;
    
    V_TRX_STATUS VARCHAR2(128);

  BEGIN
    P_RETURN_CODE := V_RETURN_CODE;
    P_RETURN_MSG  := V_RETURN_MSG;
    
     BEGIN  
       SELECT 
             OE.GEN_TRX_STATUS 
            INTO 
              V_TRX_STATUS
          FROM 
            INTF_OE_HEADERS_IFACE_ALL OE 
          WHERE OE.ORIG_SYS_DOCUMENT_REF=P_SOURCE_ID1;
          
         IF  V_TRX_STATUS='S' THEN
            RETURN;
         END IF;
      EXCEPTION
           when others then
             P_RETURN_MSG  := PKG_BD.F_ADD_ERROR_LOG('PKG_ESB.01',
                                                               sqlcode,
                                                               '步回回调失败：'||sqlerrm);
             P_RETURN_MSG  := V_RETURN_MSG;
      END;     
         

    --循环读取返回结果记录集
    FOR R_RESULT_BACK IN C_RESULT_BACK LOOP
       --Dbms_Output.Put_Line(R_RESULT_BACK.ERROR_CODE || R_RESULT_BACK.ERROR_MESSAGE);

       IF V_CNT = 0 THEN
         --CIMS销售单据头ID，R_RESULT_BACK.SOURCE_ID1是销售单据头ID
         V_SO_HEADER_ID := R_RESULT_BACK.SOURCE_ID1;
         --ERP销售订单头ID
         V_ERP_SO_HEADER_ID := R_RESULT_BACK.TARGET_ID1;
         --ERP返回的时间
         V_BACK_DATE := R_RESULT_BACK.BACK_DATE;
       END IF;

       V_SOURCE_ID2 := R_RESULT_BACK.SOURCE_ID2;
       V_SOURCE_ID3 := R_RESULT_BACK.SOURCE_ID3;
       V_TARGET_ID2 := R_RESULT_BACK.TARGET_ID2;
       V_TARGET_ID3 := R_RESULT_BACK.TARGET_ID3;

       IF (R_RESULT_BACK.STATUS = V_ERP_COMPLETED) THEN
         --ERP处理成功
         IF (V_TARGET_ID3 IS NULL) THEN
           --V_TARGET_ID3为空则表明ERP返回的对应CIMS销售单据行
           --回写ERP销售单订单行ID到CIMS的销售单据行
           UPDATE T_SO_LINE
              SET ERP_SO_LINE_ID = V_TARGET_ID2,
                  --REMARK = '回写ERP销售订单行ID到CIMS的销售单据行成功，处理时间：'||TO_CHAR(R_RESULT_BACK.BACK_DATE, V_DT_FORMAT),
                  LAST_UPDATED_BY  = 'ERP',
                  LAST_UPDATE_DATE = R_RESULT_BACK.BACK_DATE
           WHERE SO_LINE_ID = TO_NUMBER(V_SOURCE_ID2);

           --更新销售订单接口行表的行记录（套件）
           UPDATE INTF_OE_LINES_IFACE_ALL
              SET STATUS     = 'S',
                  ERROR_FLAG = 'N',
                  LINE_ID    = V_TARGET_ID2
           WHERE ORIG_SYS_LINE_REF = V_SOURCE_ID2
             AND ORIG_SYS_DOCUMENT_REF = V_SO_HEADER_ID
             AND OPERATION_CODE = V_OPER_CODE_INSERT
             AND ITEM_TYPE_CODE = 'MODEL';
         ELSE
           --回写ERP销售订单行ID到CIMS的销售单据行明细
           UPDATE T_SO_LINE_DETAIL
             SET ERP_SO_LINE_ID = V_TARGET_ID3,
                 --REMARK = '回写ERP销售订单行ID到CIMS的销售单据行明细成功，处理时间：'||TO_CHAR(R_RESULT_BACK.BACK_DATE, V_DT_FORMAT),
                 LAST_UPDATED_BY = 'ERP',
                 LAST_UPDATE_DATE = R_RESULT_BACK.BACK_DATE
           WHERE SO_LINE_DETAIL_ID = TO_NUMBER(V_SOURCE_ID3);

           --更新销售订单接口行表的明细记录（散件）
           UPDATE INTF_OE_LINES_IFACE_ALL
              SET STATUS     = 'S',
                  ERROR_FLAG = 'N',
                  LINE_ID    = V_TARGET_ID3
           WHERE ORIG_SYS_SHIPMENT_REF = V_SOURCE_ID3
             AND ORIG_SYS_DOCUMENT_REF = V_SO_HEADER_ID
             AND OPERATION_CODE = V_OPER_CODE_INSERT
             AND (ITEM_TYPE_CODE IS NULL OR ITEM_TYPE_CODE ='' OR ITEM_TYPE_CODE = 'OPTION');
         END IF;
         
         UPDATE T_SO_HEADER H SET H.LAST_UPDATE_DATE = SYSDATE
          WHERE H.SO_HEADER_ID = TO_NUMBER(V_SO_HEADER_ID);
         
       ELSE
         --ERP处理失败
         V_ERP_ERROR_FLAG := 'Y'; 

         IF (V_TARGET_ID3 IS NULL) THEN
           --更新销售订单接口行表的行记录（套件）
           UPDATE INTF_OE_LINES_IFACE_ALL
              SET STATUS = 'E',
                  ERROR_FLAG = 'Y',
                  LINE_ID    = NULL
           WHERE ORIG_SYS_LINE_REF = V_SOURCE_ID2
             AND ORIG_SYS_DOCUMENT_REF = V_SO_HEADER_ID
             AND OPERATION_CODE = V_OPER_CODE_INSERT
             AND ITEM_TYPE_CODE = 'MODEL'
             AND STATUS != 'S';
             
              BEGIN
                SELECT ITEM_CODE INTO V_ITEM_CODE FROM CIMS.T_SO_LINE WHERE SO_LINE_ID= TO_NUMBER(V_SOURCE_ID2);
              EXCEPTION
                WHEN OTHERS THEN
                   NULL;
              END;  
              
         ELSE
           --更新销售订单接口行表的明细记录（散件）
           UPDATE INTF_OE_LINES_IFACE_ALL
              SET STATUS = 'E',
                  ERROR_FLAG = 'Y',
                  LINE_ID    = NULL
           WHERE ORIG_SYS_SHIPMENT_REF = V_SOURCE_ID3
             AND ORIG_SYS_DOCUMENT_REF = V_SO_HEADER_ID
             AND OPERATION_CODE = V_OPER_CODE_INSERT
             AND (ITEM_TYPE_CODE IS NULL OR ITEM_TYPE_CODE ='' OR ITEM_TYPE_CODE = 'OPTION')
             AND STATUS != 'S';
             
              BEGIN
                SELECT COMPONENT_CODE INTO V_ITEM_CODE FROM T_SO_LINE_DETAIL WHERE SO_LINE_DETAIL_ID= TO_NUMBER(V_SOURCE_ID3);
              EXCEPTION
                WHEN OTHERS THEN
                    NULL;
              END;  
              
         END IF;
         IF V_ERROR_MSG IS NULL THEN
            V_ERROR_MSG :=V_ITEM_CODE||R_RESULT_BACK.ERROR_MESSAGE;
         ELSIF lengthb(V_ERROR_MSG)<3000 THEN
            V_ERROR_MSG := V_ERROR_MSG||V_ITEM_CODE||R_RESULT_BACK.ERROR_MESSAGE;
         END IF;  
         
       END IF;

       V_CNT := V_CNT + 1;
    END LOOP;

    /**
    --更新销售单据头的ERP销售订单ID（ERP_SO_ID）字段
    UPDATE T_SO_HEADER SH
       SET SH.ERP_SO_ID   = V_ERP_SO_HEADER_ID,
           SH.ERP_SO_CODE = SH.SO_NUM
    WHERE SH.SO_HEADER_ID = TO_NUMBER(V_SO_HEADER_ID);
      --AND (SH.ERP_SO_ID IS NULL OR SH.ERP_SO_ID = '');
    */

    --更新销售订单接口头表
    IF V_ERP_ERROR_FLAG = 'Y' THEN
      --ERP返回结果为失败
      UPDATE INTF_OE_HEADERS_IFACE_ALL
         SET STATUS = 'E', --错误
             ERROR_FLAG  = 'Y', --设置错误标识为Y
             HEADER_ID   = NULL, --销售订单头ID
             ERROR_MSG   = substr(V_ERROR_MSG,0,3000),
             RETURN_DATE = V_BACK_DATE,
             GEN_TRX_STATUS = 'E',
             GEN_TRX_DATE = V_BACK_DATE
      WHERE ORIG_SYS_DOCUMENT_REF = V_SO_HEADER_ID
        AND OPERATION_CODE = V_OPER_CODE_INSERT
        AND (GEN_TRX_STATUS IS NULL OR GEN_TRX_STATUS != 'S');

      /*
      IF SQL%NOTFOUND THEN
        V_UPDATE_MSG := V_UPDATE_MSG || '更新语句未执行：' || sqlerrm;
      ELSE
        V_UPDATE_MSG := V_UPDATE_MSG || '更新状态完成！';
      END IF;
      */
    ELSE
      --成功时更新销售单据头的ERP销售订单ID（ERP_SO_ID）字段（用最新的覆盖）
      UPDATE T_SO_HEADER SH
         SET SH.ERP_SO_ID   = V_ERP_SO_HEADER_ID,
             SH.ERP_SO_CODE = SH.SO_NUM
      WHERE SH.SO_HEADER_ID = TO_NUMBER(V_SO_HEADER_ID);
        --AND (SH.ERP_SO_ID IS NULL OR SH.ERP_SO_ID = '');

      --ERP返回结果为成功
      UPDATE INTF_OE_HEADERS_IFACE_ALL
         SET STATUS = 'S', --成功
             ERROR_FLAG  = 'N', --设置错误标识为N
             ERROR_MSG   = '',
             HEADER_ID   = TO_NUMBER(V_ERP_SO_HEADER_ID), --销售订单头ID
             RETURN_DATE = V_BACK_DATE,
             GEN_TRX_STATUS = 'S',
             GEN_TRX_DATE = V_BACK_DATE
      WHERE ORIG_SYS_DOCUMENT_REF = V_SO_HEADER_ID
        AND OPERATION_CODE = V_OPER_CODE_INSERT;

      /*
      IF SQL%NOTFOUND THEN
        V_UPDATE_MSG := '。GEN_TRX_STATUS='||V_UPDATE_MSG || '测试是否正常！-2' || sqlerrm;
      ELSE
        V_UPDATE_MSG := '。GEN_TRX_STATUS='||V_UPDATE_MSG || '更新状态完成！-2';
      END IF;
      */

    END IF;

    --设置ESB异步回调已处理
   -- UPDATE T_BD_ESB_RESULT_BACK SET HAS_DEALED = 'Y' WHERE REQUEST_ID = P_REQUEST_ID;

    --显式提交数据
    --COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      P_RETURN_CODE := 'failed';
      P_RETURN_MSG  := 'ERP销售SO订单生成回调处理过程发生异常：'||SQLERRM;
  END;


  --ERP销售SO订单挑库回调处理过程
  PROCEDURE P_ESB_RESULT_DEAL_2(P_REQUEST_ID  in  varchar2, --请求ID（交易流水号）
                                P_SOURCE_ID1  in  varchar2, --单据来源ID或编码
                                P_RETURN_CODE out varchar2, --返回编码,成功：success，失败：failed
                                P_RETURN_MSG  out varchar2  --返回信息，成功：执行成功，失败：具体失败信息
                               ) IS
    --接口返回结果游标
    CURSOR C_RESULT_BACK IS
      SELECT RB.REQUEST_ID, RB.DATA_SOURCE, RB.BACK_DATE,
             RD.SOURCE_ID1, RD.SOURCE_ID2, RD.SOURCE_ID3, RD.STATUS,
             RD.ERROR_CODE, RD.ERROR_MESSAGE, RD.TARGET_ID1, RD.TARGET_ID2, RD.TARGET_ID3
      FROM T_BD_ESB_RESULT_BACK RB, T_BD_ESB_RESULT_BACK_DETAIL RD
      WHERE RB.RESULT_BACK_ID = RD.RESULT_BACK_ID
        AND RB.REQUEST_ID = P_REQUEST_ID
        AND RD.SOURCE_ID1 = P_SOURCE_ID1
        AND (RB.HAS_DEALED IS NULL OR RB.HAS_DEALED != 'Y');
    --接口返回结果记录集
    R_RESULT_BACK C_RESULT_BACK%ROWTYPE;

    --CIMS的销售单据头ID
    V_SO_HEADER_ID  T_BD_ESB_RESULT_BACK_DETAIL.SOURCE_ID1%TYPE;
    --ERP的销售订单头ID
    V_ERP_SO_HEADER_ID  T_BD_ESB_RESULT_BACK_DETAIL.TARGET_ID1%TYPE;

    --ERP错误标识
    V_ERP_ERROR_FLAG CHAR(1) := 'N';
    --循环计数器
    V_CNT NUMBER := 0;
    --ERP返回的时间
    V_BACK_DATE DATE := SYSDATE;
    --错误信息
    V_ERROR_MSG T_BD_ESB_RESULT_BACK_DETAIL.ERROR_MESSAGE%TYPE;

  BEGIN
    P_RETURN_CODE := V_RETURN_CODE;
    P_RETURN_MSG  := V_RETURN_MSG;

    --循环读取返回结果记录集
    FOR R_RESULT_BACK IN C_RESULT_BACK LOOP
      -- Dbms_Output.Put_Line(R_RESULT_BACK.ERROR_CODE || R_RESULT_BACK.ERROR_MESSAGE);

       IF V_CNT = 0 THEN
         --CIMS销售单据头ID，R_RESULT_BACK.SOURCE_ID1是销售单据头ID
         V_SO_HEADER_ID := R_RESULT_BACK.SOURCE_ID1;
         --ERP销售订单头ID
         V_ERP_SO_HEADER_ID := R_RESULT_BACK.TARGET_ID1;
         --ERP返回的时间
         V_BACK_DATE := R_RESULT_BACK.BACK_DATE;
       END IF;

       IF R_RESULT_BACK.STATUS != V_ERP_COMPLETED THEN
         V_ERP_ERROR_FLAG := 'Y';
         V_ERROR_MSG := R_RESULT_BACK.ERROR_MESSAGE;
       END IF;

       V_CNT := V_CNT + 1;
    END LOOP;

    --更新销售单据头的ERP挑库标识字段
    IF V_ERP_ERROR_FLAG != 'Y' THEN
      UPDATE T_SO_HEADER SET ERP_PICK_FLAG = 'Y' WHERE SO_HEADER_ID = TO_NUMBER(V_SO_HEADER_ID);
    END IF;

    --更新销售订单接口头表
    IF V_ERP_ERROR_FLAG = 'Y' THEN
      --ERP返回结果为失败
      UPDATE INTF_OE_HEADERS_IFACE_ALL
         SET STATUS = 'E', --错误
             ERROR_FLAG = 'Y', --设置错误标识为Y
             ERROR_MSG = V_ERROR_MSG,
             RETURN_DATE = V_BACK_DATE,
             INV_TRX_STATUS = 'E',
             INV_TRX_DATE = V_BACK_DATE
      WHERE ORIG_SYS_DOCUMENT_REF = V_SO_HEADER_ID
        AND OPERATION_CODE = V_OPER_CODE_INSERT
        AND (INV_TRX_STATUS IS NULL OR INV_TRX_STATUS != 'S');
    ELSE
      --ERP返回结果为成功
      UPDATE INTF_OE_HEADERS_IFACE_ALL
         SET STATUS = 'S', --成功
             ERROR_FLAG = 'N', --设置错误标识为N
             ERROR_MSG = '',
             RETURN_DATE = V_BACK_DATE,
             INV_TRX_STATUS = 'S',
             INV_TRX_DATE = V_BACK_DATE
      WHERE ORIG_SYS_DOCUMENT_REF = V_SO_HEADER_ID
        AND OPERATION_CODE = V_OPER_CODE_INSERT;
        
      UPDATE T_SO_HEADER H SET H.LAST_UPDATE_DATE = SYSDATE
       WHERE H.SO_HEADER_ID = TO_NUMBER(V_SO_HEADER_ID);
       
    END IF;

    --设置ESB异步回调已处理
  --  UPDATE T_BD_ESB_RESULT_BACK SET HAS_DEALED = 'Y' WHERE REQUEST_ID = P_REQUEST_ID;

  EXCEPTION
    WHEN OTHERS THEN
      P_RETURN_CODE := 'failed';
      P_RETURN_MSG  := 'ERP销售SO订单挑库回调处理过程发生异常：'||SQLERRM;
  END;


  -- ERP销售SO订单日期变更、价格调整回调处理过程
  PROCEDURE P_ESB_RESULT_DEAL_3(P_REQUEST_ID  in  varchar2, --请求ID（交易流水号）
                                P_SOURCE_ID1  in  varchar2, --单据来源ID或编码
                                P_RETURN_CODE out varchar2, --返回编码,成功：success，失败：failed
                                P_RETURN_MSG  out varchar2  --返回信息，成功：执行成功，失败：具体失败信息
                               ) IS
    --接口返回结果游标
    CURSOR C_RESULT_BACK IS
      SELECT RB.REQUEST_ID, RB.DATA_SOURCE, RB.BACK_DATE,
             RD.SOURCE_ID1, RD.SOURCE_ID2, RD.SOURCE_ID3, RD.STATUS,
             RD.ERROR_CODE, RD.ERROR_MESSAGE, RD.TARGET_ID1, RD.TARGET_ID2, RD.TARGET_ID3
      FROM T_BD_ESB_RESULT_BACK RB, T_BD_ESB_RESULT_BACK_DETAIL RD
      WHERE RB.RESULT_BACK_ID = RD.RESULT_BACK_ID
        AND RB.REQUEST_ID = P_REQUEST_ID
        AND RD.SOURCE_ID1 = P_SOURCE_ID1
        AND (RB.HAS_DEALED IS NULL OR RB.HAS_DEALED != 'Y');
    --接口返回结果记录集
    R_RESULT_BACK C_RESULT_BACK%ROWTYPE;

    --CIMS的销售单据头ID
    V_SO_HEADER_ID  T_BD_ESB_RESULT_BACK_DETAIL.SOURCE_ID1%TYPE;

    --ERP错误标识
    V_ERP_ERROR_FLAG CHAR(1) := 'N';
    --循环计数器
    V_CNT NUMBER := 0;
    --ERP返回的时间
    V_BACK_DATE DATE := SYSDATE;
    --错误信息
    V_ERROR_MSG T_BD_ESB_RESULT_BACK_DETAIL.ERROR_MESSAGE%TYPE;

    --执行更新接口头跟踪信息
    V_UPDATE_MSG VARCHAR2(256) := '';
    
    V_TRX_STATUS VARCHAR2(128);

  BEGIN
    P_RETURN_CODE := V_RETURN_CODE;
    P_RETURN_MSG  := V_RETURN_MSG;
    
     BEGIN  
       SELECT 
             OE.UPDATE_TRX_STATUS 
            INTO 
              V_TRX_STATUS
          FROM 
            INTF_OE_HEADERS_IFACE_ALL OE 
          WHERE OE.ORIG_SYS_DOCUMENT_REF=P_SOURCE_ID1;
          
         IF  V_TRX_STATUS='S' THEN
            RETURN;
         END IF;
      EXCEPTION
           when others then
             P_RETURN_MSG  := PKG_BD.F_ADD_ERROR_LOG('PKG_ESB.03',
                                                               sqlcode,
                                                               '步回回调失败：'||sqlerrm);
             P_RETURN_MSG  := V_RETURN_MSG;
      END;     

    --循环读取返回结果记录集
    FOR R_RESULT_BACK IN C_RESULT_BACK LOOP
      -- Dbms_Output.Put_Line(R_RESULT_BACK.ERROR_CODE || R_RESULT_BACK.ERROR_MESSAGE);

       IF V_CNT = 0 THEN
         --CIMS销售单据头ID，R_RESULT_BACK.SOURCE_ID1是销售单据头ID
         V_SO_HEADER_ID := R_RESULT_BACK.SOURCE_ID1;
         --ERP返回的时间
         V_BACK_DATE := R_RESULT_BACK.BACK_DATE;
       END IF;

       IF R_RESULT_BACK.STATUS != V_ERP_COMPLETED THEN
         V_ERP_ERROR_FLAG := 'Y';
         V_ERROR_MSG := R_RESULT_BACK.ERROR_MESSAGE;
       END IF;

       V_CNT := V_CNT + 1;
    END LOOP;

    --更新销售订单接口头表
    IF V_ERP_ERROR_FLAG = 'Y' THEN
      --ERP返回结果为失败
      UPDATE INTF_OE_HEADERS_IFACE_ALL
         SET STATUS = 'E', --错误
             ERROR_FLAG = 'Y', --设置错误标识为Y
             ERROR_MSG = V_ERROR_MSG,
             RETURN_DATE = V_BACK_DATE,
             UPDATE_TRX_STATUS = 'E',
             UPDATE_TRX_DATE = V_BACK_DATE
      WHERE ORIG_SYS_DOCUMENT_REF = V_SO_HEADER_ID
        AND OPERATION_CODE = V_OPER_CODE_INSERT
        AND (UPDATE_TRX_STATUS IS NULL OR UPDATE_TRX_STATUS != 'S');
    ELSE
      --ERP返回结果为成功
      UPDATE INTF_OE_HEADERS_IFACE_ALL
         SET STATUS = 'S', --成功
             ERROR_FLAG = 'N', --设置错误标识为N
             ERROR_MSG = V_ERROR_MSG,
             RETURN_DATE = V_BACK_DATE,
             UPDATE_TRX_STATUS = 'S',
             UPDATE_TRX_DATE = V_BACK_DATE
      WHERE ORIG_SYS_DOCUMENT_REF = V_SO_HEADER_ID
        AND OPERATION_CODE = V_OPER_CODE_INSERT;

        --SO变更成功回调，如果是拉式销售，销售红冲、源单退回、反向销售时需要继续调用RMA接收
        pkg_so_rt.P_SOCHANGE_WRITE_BACK(V_SO_HEADER_ID);

      --更新销售单头表的ERP登记标记：Y-是，N-否
      UPDATE T_SO_HEADER SET ERP_BOOKED_FLAG = 'Y',LAST_UPDATE_DATE = SYSDATE
       WHERE SO_HEADER_ID = TO_NUMBER(V_SO_HEADER_ID);
    END IF;

    --设置ESB异步回调已处理
   -- UPDATE T_BD_ESB_RESULT_BACK SET HAS_DEALED = 'Y' WHERE REQUEST_ID = P_REQUEST_ID;

    --显式提交数据
  --  COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      P_RETURN_CODE := 'failed';
      P_RETURN_MSG  := 'ERP销售SO订单日期变更、价格调整回调处理过程发生异常：'||SQLERRM;
  END;


  -- ERP销售SO订单发运确认回调处理过程
  PROCEDURE P_ESB_RESULT_DEAL_4(P_REQUEST_ID  in  varchar2, --请求ID（交易流水号）
                                P_SOURCE_ID1  in  varchar2, --单据来源ID或编码
                                P_RETURN_CODE out varchar2, --返回编码,成功：success，失败：failed
                                P_RETURN_MSG  out varchar2  --返回信息，成功：执行成功，失败：具体失败信息
                               ) IS
    --接口返回结果游标
    CURSOR C_RESULT_BACK IS
      SELECT RB.REQUEST_ID, RB.DATA_SOURCE, RB.BACK_DATE,
             RD.SOURCE_ID1, RD.SOURCE_ID2, RD.SOURCE_ID3, RD.STATUS,
             RD.ERROR_CODE, RD.ERROR_MESSAGE, RD.TARGET_ID1, RD.TARGET_ID2, RD.TARGET_ID3
      FROM T_BD_ESB_RESULT_BACK RB, T_BD_ESB_RESULT_BACK_DETAIL RD
      WHERE RB.RESULT_BACK_ID = RD.RESULT_BACK_ID
        AND RB.REQUEST_ID = P_REQUEST_ID
        AND RD.SOURCE_ID1 = P_SOURCE_ID1
        AND (RB.HAS_DEALED IS NULL OR RB.HAS_DEALED != 'Y');
    --接口返回结果记录集
    R_RESULT_BACK C_RESULT_BACK%ROWTYPE;

    --CIMS的销售单据头ID
    V_SO_HEADER_ID  T_BD_ESB_RESULT_BACK_DETAIL.SOURCE_ID1%TYPE;

    --ERP错误标识
    V_ERP_ERROR_FLAG CHAR(1) := 'N';
    --循环计数器
    V_CNT NUMBER := 0;
    --ERP返回的时间
    V_BACK_DATE DATE := SYSDATE;
    --错误信息
    V_ERROR_MSG T_BD_ESB_RESULT_BACK_DETAIL.ERROR_MESSAGE%TYPE;

  BEGIN
    P_RETURN_CODE := V_RETURN_CODE;
    P_RETURN_MSG  := V_RETURN_MSG;

    --循环读取返回结果记录集
    FOR R_RESULT_BACK IN C_RESULT_BACK LOOP
       --Dbms_Output.Put_Line(R_RESULT_BACK.ERROR_CODE || R_RESULT_BACK.ERROR_MESSAGE);

       IF V_CNT = 0 THEN
         --CIMS销售单据头ID，R_RESULT_BACK.SOURCE_ID1是销售单据头ID
         V_SO_HEADER_ID := R_RESULT_BACK.SOURCE_ID1;
         --ERP返回的时间
         V_BACK_DATE := R_RESULT_BACK.BACK_DATE;
       END IF;

       IF R_RESULT_BACK.STATUS != V_ERP_COMPLETED THEN
         V_ERP_ERROR_FLAG := 'Y';
         V_ERROR_MSG := R_RESULT_BACK.ERROR_MESSAGE;
       END IF;

       V_CNT := V_CNT + 1;
    END LOOP;

    --更新销售单据头的ERP发运标记字段
    IF V_ERP_ERROR_FLAG != 'Y' THEN
      UPDATE T_SO_HEADER SET ERP_SHIP_FLAG = 'Y' WHERE SO_HEADER_ID = TO_NUMBER(V_SO_HEADER_ID);
    END IF;

    --更新销售订单接口头表
    IF V_ERP_ERROR_FLAG = 'Y' THEN
      --ERP返回结果为失败
      UPDATE INTF_OE_HEADERS_IFACE_ALL
         SET STATUS = 'E', --错误
             ERROR_FLAG = 'Y', --设置错误标识为Y
             ERROR_MSG = V_ERROR_MSG,
             RETURN_DATE = V_BACK_DATE,
             SHIP_TRX_STATUS = 'E',
             SHIP_TRX_DATE = V_BACK_DATE
      WHERE ORIG_SYS_DOCUMENT_REF = V_SO_HEADER_ID
        AND OPERATION_CODE = V_OPER_CODE_INSERT
        AND (SHIP_TRX_STATUS IS NULL OR SHIP_TRX_STATUS != 'S');
    ELSE
      --ERP返回结果为成功
      UPDATE INTF_OE_HEADERS_IFACE_ALL
         SET STATUS = 'S', --成功
             ERROR_FLAG = 'N', --设置错误标识为N
             ERROR_MSG = V_ERROR_MSG,
             RETURN_DATE = V_BACK_DATE,
             SHIP_TRX_STATUS = 'S',
             SHIP_TRX_DATE = V_BACK_DATE
      WHERE ORIG_SYS_DOCUMENT_REF = V_SO_HEADER_ID
        AND OPERATION_CODE = V_OPER_CODE_INSERT;
        
      UPDATE T_SO_HEADER H SET H.LAST_UPDATE_DATE = SYSDATE
       WHERE H.SO_HEADER_ID = TO_NUMBER(V_SO_HEADER_ID);
      
    END IF;

    --设置ESB异步回调已处理
 --   UPDATE T_BD_ESB_RESULT_BACK SET HAS_DEALED = 'Y' WHERE REQUEST_ID = P_REQUEST_ID;

  EXCEPTION
    WHEN OTHERS THEN
      P_RETURN_CODE := 'failed';
      P_RETURN_MSG  := 'ERP销售SO订单日期变更、价格调整回调处理过程发生异常：'||SQLERRM;
  END;


  -- ERP销售SO挑库、发运确认（拉式）回调处理过程
  PROCEDURE P_ESB_RESULT_DEAL_5(P_REQUEST_ID  in  varchar2, --请求ID（交易流水号）
                                P_SOURCE_ID1  in  varchar2, --单据来源ID或编码
                                P_RETURN_CODE out varchar2, --返回编码,成功：success，失败：failed
                                P_RETURN_MSG  out varchar2  --返回信息，成功：执行成功，失败：具体失败信息
                               ) IS
    --接口返回结果游标
    CURSOR C_RESULT_BACK IS
      SELECT RB.REQUEST_ID, RB.DATA_SOURCE, RB.BACK_DATE,
             RD.SOURCE_ID1, RD.SOURCE_ID2, RD.SOURCE_ID3, RD.STATUS,
             RD.ERROR_CODE, RD.ERROR_MESSAGE, RD.TARGET_ID1, RD.TARGET_ID2, RD.TARGET_ID3
      FROM T_BD_ESB_RESULT_BACK RB, T_BD_ESB_RESULT_BACK_DETAIL RD
      WHERE RB.RESULT_BACK_ID = RD.RESULT_BACK_ID
        AND RB.REQUEST_ID = P_REQUEST_ID
        AND RD.SOURCE_ID1 = P_SOURCE_ID1
        AND (RB.HAS_DEALED IS NULL OR RB.HAS_DEALED != 'Y');
    --接口返回结果记录集
    R_RESULT_BACK C_RESULT_BACK%ROWTYPE;

    --CIMS的销售单据头ID
    V_SO_HEADER_ID  T_BD_ESB_RESULT_BACK_DETAIL.SOURCE_ID1%TYPE;

    --ERP错误标识
    V_ERP_ERROR_FLAG CHAR(1) := 'N';
    --循环计数器
    V_CNT NUMBER := 0;
    --ERP返回的时间
    V_BACK_DATE DATE := SYSDATE;
    --错误信息
    V_ERROR_MSG T_BD_ESB_RESULT_BACK_DETAIL.ERROR_MESSAGE%TYPE;

  BEGIN
    P_RETURN_CODE := V_RETURN_CODE;
    P_RETURN_MSG  := V_RETURN_MSG;

    --处理逻辑待实现（。。。。。。。。。。。。。。。。。。）


  EXCEPTION
    WHEN OTHERS THEN
      P_RETURN_CODE := 'failed';
      P_RETURN_MSG  := 'ERP销售SO订单日期变更、价格调整回调处理过程发生异常：'||SQLERRM;
  END;

  --ERP RMA生成回调处理过程
  PROCEDURE P_ESB_RESULT_DEAL_6(P_REQUEST_ID  in  varchar2, --请求ID（交易流水号）
                                P_SOURCE_ID1  in  varchar2, --单据来源ID或编码
                                P_RETURN_CODE out varchar2, --返回编码,成功：success，失败：failed
                                P_RETURN_MSG  out varchar2  --返回信息，成功：执行成功，失败：具体失败信息
                               ) IS
    --接口返回结果游标
    CURSOR C_RESULT_BACK IS
      SELECT RB.REQUEST_ID, RB.DATA_SOURCE, RB.BACK_DATE,
             RD.SOURCE_ID1, RD.SOURCE_ID2, RD.SOURCE_ID3, RD.STATUS,
             RD.ERROR_CODE, RD.ERROR_MESSAGE, RD.TARGET_ID1, RD.TARGET_ID2, RD.TARGET_ID3
      FROM T_BD_ESB_RESULT_BACK RB, T_BD_ESB_RESULT_BACK_DETAIL RD
      WHERE RB.RESULT_BACK_ID = RD.RESULT_BACK_ID
        AND RB.REQUEST_ID = P_REQUEST_ID
        AND RD.SOURCE_ID1 = P_SOURCE_ID1
        AND (RB.HAS_DEALED IS NULL OR RB.HAS_DEALED != 'Y');
    --接口返回结果记录集
    R_RESULT_BACK C_RESULT_BACK%ROWTYPE;

    --CIMS的销售单据头ID
    V_SO_HEADER_ID  T_BD_ESB_RESULT_BACK_DETAIL.SOURCE_ID1%TYPE;
    --ERP的销售订单头ID
    V_ERP_SO_HEADER_ID  T_BD_ESB_RESULT_BACK_DETAIL.TARGET_ID1%TYPE;

    V_SOURCE_ID2 T_BD_ESB_RESULT_BACK_DETAIL.SOURCE_ID2%TYPE;
    V_SOURCE_ID3 T_BD_ESB_RESULT_BACK_DETAIL.SOURCE_ID3%TYPE;
    V_TARGET_ID2 T_BD_ESB_RESULT_BACK_DETAIL.TARGET_ID2%TYPE;
    V_TARGET_ID3 T_BD_ESB_RESULT_BACK_DETAIL.TARGET_ID3%TYPE;

    --ERP错误标识
    V_ERP_ERROR_FLAG CHAR(1) := 'N';
    --循环计数器
    V_CNT NUMBER := 0;
    --ERP返回的时间
    V_BACK_DATE DATE := SYSDATE;
    --错误信息
    V_ERROR_MSG T_BD_ESB_RESULT_BACK_DETAIL.ERROR_MESSAGE%TYPE;

    --执行更新接口头跟踪信息
    V_UPDATE_MSG VARCHAR2(256) := '';

     V_TRX_STATUS VARCHAR2(128);
  BEGIN
    P_RETURN_CODE := V_RETURN_CODE;
    P_RETURN_MSG  := V_RETURN_MSG;
    
    BEGIN  
       SELECT 
             OE.Gen_Trx_Status 
            INTO 
              V_TRX_STATUS
          FROM 
            INTF_OE_HEADERS_IFACE_ALL OE 
          WHERE OE.ORIG_SYS_DOCUMENT_REF=P_SOURCE_ID1;
          
         IF  V_TRX_STATUS='S' THEN
            RETURN;
         END IF;
      EXCEPTION
           when others then
             P_RETURN_MSG  := PKG_BD.F_ADD_ERROR_LOG('PKG_ESB.06',
                                                               sqlcode,
                                                               '步回回调失败：'||sqlerrm);
             P_RETURN_MSG  := V_RETURN_MSG;
      END;     

    --循环读取返回结果记录集
    FOR R_RESULT_BACK IN C_RESULT_BACK LOOP
       --Dbms_Output.Put_Line(R_RESULT_BACK.ERROR_CODE || R_RESULT_BACK.ERROR_MESSAGE);

       IF V_CNT = 0 THEN
         --CIMS销售单据头ID，R_RESULT_BACK.SOURCE_ID1是销售单据头ID
         V_SO_HEADER_ID := R_RESULT_BACK.SOURCE_ID1;
         --ERP销售订单头ID
         V_ERP_SO_HEADER_ID := R_RESULT_BACK.TARGET_ID1;
         --ERP返回的时间
         V_BACK_DATE := R_RESULT_BACK.BACK_DATE;
       END IF;

       V_SOURCE_ID2 := R_RESULT_BACK.SOURCE_ID2;
       V_SOURCE_ID3 := R_RESULT_BACK.SOURCE_ID3;
       V_TARGET_ID2 := R_RESULT_BACK.TARGET_ID2;
       V_TARGET_ID3 := R_RESULT_BACK.TARGET_ID3;

       IF (R_RESULT_BACK.STATUS = V_ERP_COMPLETED) THEN
         --ERP处理成功
         IF (V_TARGET_ID3 IS NULL) THEN
           --V_TARGET_ID3为空则表明ERP返回的对应CIMS销售单据行
           --回写ERP销售单订单行ID到CIMS的销售单据行
           UPDATE T_SO_LINE
              SET ERP_SO_LINE_ID = V_TARGET_ID2,
                  --REMARK = '回写ERP销售订单行ID到CIMS的销售单据行成功，处理时间：'||TO_CHAR(R_RESULT_BACK.BACK_DATE, V_DT_FORMAT),
                  LAST_UPDATED_BY  = 'ERP',
                  LAST_UPDATE_DATE = R_RESULT_BACK.BACK_DATE
           WHERE SO_LINE_ID = TO_NUMBER(V_SOURCE_ID2);

           --更新销售订单接口行表的行记录（套件）
           UPDATE INTF_OE_LINES_IFACE_ALL
              SET STATUS     = 'S',
                  ERROR_FLAG = 'N',
                  LINE_ID    = V_TARGET_ID2
           WHERE ORIG_SYS_LINE_REF = V_SOURCE_ID2
             AND ORIG_SYS_DOCUMENT_REF = V_SO_HEADER_ID
             AND OPERATION_CODE = V_OPER_CODE_INSERT
             AND ITEM_TYPE_CODE = 'MODEL';
         ELSE
           --回写ERP销售订单行ID到CIMS的销售单据行明细
           UPDATE T_SO_LINE_DETAIL
             SET ERP_SO_LINE_ID = V_TARGET_ID3,
                 --REMARK = '回写ERP销售订单行ID到CIMS的销售单据行明细成功，处理时间：'||TO_CHAR(R_RESULT_BACK.BACK_DATE, V_DT_FORMAT),
                 LAST_UPDATED_BY = 'ERP',
                 LAST_UPDATE_DATE = R_RESULT_BACK.BACK_DATE
           WHERE SO_LINE_DETAIL_ID = TO_NUMBER(V_SOURCE_ID3);

           --更新销售订单接口行表的明细记录（散件）
           UPDATE INTF_OE_LINES_IFACE_ALL
              SET STATUS     = 'S',
                  ERROR_FLAG = 'N',
                  LINE_ID    = V_TARGET_ID3
           WHERE ORIG_SYS_SHIPMENT_REF = V_SOURCE_ID3
             AND ORIG_SYS_DOCUMENT_REF = V_SO_HEADER_ID
             AND OPERATION_CODE = V_OPER_CODE_INSERT
             AND (ITEM_TYPE_CODE IS NULL OR ITEM_TYPE_CODE ='' OR ITEM_TYPE_CODE = 'OPTION');
         END IF;

       ELSE
         --ERP处理失败
         V_ERP_ERROR_FLAG := 'Y';
         V_ERROR_MSG := R_RESULT_BACK.ERROR_MESSAGE;

         IF (V_TARGET_ID3 IS NULL) THEN
           --更新销售订单接口行表的行记录（套件）
           UPDATE INTF_OE_LINES_IFACE_ALL
              SET STATUS = 'E',
                  ERROR_FLAG = 'Y',
                  LINE_ID    = NULL
           WHERE ORIG_SYS_LINE_REF = V_SOURCE_ID2
             AND ORIG_SYS_DOCUMENT_REF = V_SO_HEADER_ID
             AND OPERATION_CODE = V_OPER_CODE_INSERT
             AND ITEM_TYPE_CODE = 'MODEL'
             AND STATUS != 'S';
         ELSE
           --更新销售订单接口行表的明细记录（散件）
           UPDATE INTF_OE_LINES_IFACE_ALL
              SET STATUS = 'E',
                  ERROR_FLAG = 'Y',
                  LINE_ID    = NULL
           WHERE ORIG_SYS_SHIPMENT_REF = V_SOURCE_ID3
             AND ORIG_SYS_DOCUMENT_REF = V_SO_HEADER_ID
             AND OPERATION_CODE = V_OPER_CODE_INSERT
             AND (ITEM_TYPE_CODE IS NULL OR ITEM_TYPE_CODE ='' OR ITEM_TYPE_CODE = 'OPTION')
             AND STATUS != 'S';
         END IF;
       END IF;

       V_CNT := V_CNT + 1;
    END LOOP;

    /**
    --更新销售单据头的ERP销售订单ID（ERP_SO_ID）字段
    UPDATE T_SO_HEADER SH
       SET SH.ERP_SO_ID   = V_ERP_SO_HEADER_ID,
           SH.ERP_SO_CODE = SH.SO_NUM,
           SH.ERP_RMA_ID  = V_ERP_SO_HEADER_ID,
           SH.ERP_RMA_NUM = SH.SO_NUM
    WHERE SH.SO_HEADER_ID = TO_NUMBER(V_SO_HEADER_ID);
    */

    --更新销售订单接口头表
    IF V_ERP_ERROR_FLAG = 'Y' THEN
      --ERP返回结果为失败
      UPDATE INTF_OE_HEADERS_IFACE_ALL A
         SET STATUS      = 'E', --错误
             ERROR_FLAG  = 'Y', --设置错误标识为Y
             ERROR_MSG   = V_ERROR_MSG,
             RETURN_DATE = V_BACK_DATE,
             GEN_TRX_STATUS = 'E',
             GEN_TRX_DATE   = V_BACK_DATE
      WHERE ORIG_SYS_DOCUMENT_REF = V_SO_HEADER_ID
        AND OPERATION_CODE = V_OPER_CODE_INSERT
        AND (GEN_TRX_STATUS IS NULL OR GEN_TRX_STATUS != 'S');
    ELSE
      --更新销售单据头的ERP销售订单ID（ERP_SO_ID）字段
      UPDATE T_SO_HEADER SH
         SET SH.ERP_SO_ID   = V_ERP_SO_HEADER_ID,
             SH.ERP_SO_CODE = SH.SO_NUM,
             SH.ERP_RMA_ID  = V_ERP_SO_HEADER_ID,
             SH.ERP_RMA_NUM = SH.SO_NUM,
             SH.LAST_UPDATE_DATE = SYSDATE
      WHERE SH.SO_HEADER_ID = TO_NUMBER(V_SO_HEADER_ID);

      --ERP返回结果为成功
      UPDATE INTF_OE_HEADERS_IFACE_ALL
         SET STATUS      = 'S', --成功
             ERROR_FLAG  = 'N', --设置错误标识为N
             ERROR_MSG   = '',
             RETURN_DATE = V_BACK_DATE,
             GEN_TRX_STATUS = 'S',
             GEN_TRX_DATE   = V_BACK_DATE
      WHERE ORIG_SYS_DOCUMENT_REF = V_SO_HEADER_ID
        AND OPERATION_CODE = V_OPER_CODE_INSERT;
    END IF;

    --设置ESB异步回调已处理
   -- UPDATE T_BD_ESB_RESULT_BACK SET HAS_DEALED = 'Y' WHERE REQUEST_ID = P_REQUEST_ID;

    --显式提交数据
   -- COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      P_RETURN_CODE := 'failed';
      P_RETURN_MSG  := 'RMA生成回调处理过程发生异常：'||SQLERRM;
  END;


  --ERP RMA接收回调处理过程
  PROCEDURE P_ESB_RESULT_DEAL_7(P_REQUEST_ID  in  varchar2, --请求ID（交易流水号）
                                P_SOURCE_ID1  in  varchar2, --单据来源ID或编码
                                P_RETURN_CODE out varchar2, --返回编码,成功：success，失败：failed
                                P_RETURN_MSG  out varchar2  --返回信息，成功：执行成功，失败：具体失败信息
                               ) IS
    --接口返回结果游标
    CURSOR C_RESULT_BACK IS
      SELECT RB.REQUEST_ID, RB.DATA_SOURCE, RB.BACK_DATE,
             RD.SOURCE_ID1, RD.SOURCE_ID2, RD.SOURCE_ID3, RD.STATUS,
             RD.ERROR_CODE, RD.ERROR_MESSAGE, RD.TARGET_ID1, RD.TARGET_ID2, RD.TARGET_ID3
      FROM T_BD_ESB_RESULT_BACK RB, T_BD_ESB_RESULT_BACK_DETAIL RD
      WHERE RB.RESULT_BACK_ID = RD.RESULT_BACK_ID
        AND RB.REQUEST_ID = P_REQUEST_ID
        AND RD.SOURCE_ID1 = P_SOURCE_ID1
        AND (RB.HAS_DEALED IS NULL OR RB.HAS_DEALED != 'Y');
    --接口返回结果记录集
    R_RESULT_BACK C_RESULT_BACK%ROWTYPE;

    --CIMS的销售单据头ID
    V_SO_HEADER_ID  T_BD_ESB_RESULT_BACK_DETAIL.SOURCE_ID1%TYPE;

    --ERP错误标识
    V_ERP_ERROR_FLAG CHAR(1) := 'N';
    --循环计数器
    V_CNT NUMBER := 0;
    --ERP返回的时间
    V_BACK_DATE DATE := SYSDATE;
    --错误信息
    V_ERROR_MSG T_BD_ESB_RESULT_BACK_DETAIL.ERROR_MESSAGE%TYPE;

    --执行更新接口头跟踪信息
    V_UPDATE_MSG VARCHAR2(256) := '';

    V_TRX_STATUS VARCHAR2(128);
  BEGIN
    P_RETURN_CODE := V_RETURN_CODE;
    P_RETURN_MSG  := V_RETURN_MSG;
    
     BEGIN  
       SELECT 
             OE.Rma_Receive_Trx_Status 
            INTO 
              V_TRX_STATUS
          FROM 
            INTF_OE_HEADERS_IFACE_ALL OE 
          WHERE OE.ORIG_SYS_DOCUMENT_REF=P_SOURCE_ID1;
          
         IF  V_TRX_STATUS='S' THEN
            RETURN;
         END IF;
      EXCEPTION
           when others then
             P_RETURN_MSG  := PKG_BD.F_ADD_ERROR_LOG('PKG_ESB.06',
                                                               sqlcode,
                                                               '步回回调失败：'||sqlerrm);
             P_RETURN_MSG  := V_RETURN_MSG;
      END;

    --循环读取返回结果记录集
    FOR R_RESULT_BACK IN C_RESULT_BACK LOOP
       --Dbms_Output.Put_Line(R_RESULT_BACK.ERROR_CODE || R_RESULT_BACK.ERROR_MESSAGE);

       IF V_CNT = 0 THEN
         --CIMS销售单据头ID，R_RESULT_BACK.SOURCE_ID1是销售单据头ID
         V_SO_HEADER_ID := R_RESULT_BACK.SOURCE_ID1;
         --ERP返回的时间
         V_BACK_DATE := R_RESULT_BACK.BACK_DATE;
       END IF;

       IF R_RESULT_BACK.STATUS != V_ERP_COMPLETED THEN
         V_ERP_ERROR_FLAG := 'Y';
         V_ERROR_MSG := R_RESULT_BACK.ERROR_MESSAGE;
       END IF;

       V_CNT := V_CNT + 1;
    END LOOP;

    --更新销售订单接口头表
    IF V_ERP_ERROR_FLAG = 'Y' THEN
      --ERP返回结果为失败
      UPDATE INTF_OE_HEADERS_IFACE_ALL
         SET STATUS      = 'E', --错误
             ERROR_FLAG  = 'Y', --设置错误标识为Y
             ERROR_MSG   = V_ERROR_MSG,
             RETURN_DATE = V_BACK_DATE,
             RMA_RECEIVE_TRX_STATUS = 'E',
             RMA_RECEIVE_TRX_DATE   = V_BACK_DATE
      WHERE ORIG_SYS_DOCUMENT_REF = V_SO_HEADER_ID
        AND OPERATION_CODE = V_OPER_CODE_INSERT
        AND (RMA_RECEIVE_TRX_STATUS IS NULL OR RMA_RECEIVE_TRX_STATUS != 'S');
    ELSE
      UPDATE T_SO_HEADER H SET H.LAST_UPDATE_DATE = SYSDATE
       WHERE H.SO_HEADER_ID = TO_NUMBER(V_SO_HEADER_ID);
      
      --ERP返回结果为成功
      UPDATE INTF_OE_HEADERS_IFACE_ALL
         SET STATUS      = 'S', --成功
             ERROR_FLAG  = 'N', --设置错误标识为N
             ERROR_MSG   = '',
             RETURN_DATE = V_BACK_DATE,
             RMA_RECEIVE_TRX_STATUS = 'S',
             RMA_RECEIVE_TRX_DATE   = V_BACK_DATE
      WHERE ORIG_SYS_DOCUMENT_REF = V_SO_HEADER_ID
        AND OPERATION_CODE = V_OPER_CODE_INSERT;
      --add by chen.wj 20150205 RMA接收成功，回调
      pkg_so_rt.P_RMA_WRITE_BACK(V_SO_HEADER_ID);
    END IF;

    --设置ESB异步回调已处理
  --  UPDATE T_BD_ESB_RESULT_BACK SET HAS_DEALED = 'Y' WHERE REQUEST_ID = P_REQUEST_ID;

    --显式提交数据
   -- COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      P_RETURN_CODE := 'failed';
      P_RETURN_MSG  := 'ERP RMA接收回调处理过程发生异常：'||SQLERRM;
  END;

  --ERP销售折让订单生成、折让证明订单生成回调处理过程
  PROCEDURE P_ESB_RESULT_DEAL_8(P_REQUEST_ID  in  varchar2, --请求ID（交易流水号）
                                P_SOURCE_ID1  in  varchar2, --单据来源ID或编码
                                P_RETURN_CODE out varchar2, --返回编码,成功：success，失败：failed
                                P_RETURN_MSG  out varchar2  --返回信息，成功：执行成功，失败：具体失败信息
                               ) IS
    --接口返回结果游标
    CURSOR C_RESULT_BACK IS
      SELECT RB.REQUEST_ID, RB.DATA_SOURCE, RB.BACK_DATE,
             RD.SOURCE_ID1, RD.SOURCE_ID2, RD.SOURCE_ID3, RD.STATUS,
             RD.ERROR_CODE, RD.ERROR_MESSAGE, RD.TARGET_ID1, RD.TARGET_ID2, RD.TARGET_ID3
      FROM T_BD_ESB_RESULT_BACK RB, T_BD_ESB_RESULT_BACK_DETAIL RD
      WHERE RB.RESULT_BACK_ID = RD.RESULT_BACK_ID
        AND RB.REQUEST_ID = P_REQUEST_ID
        AND RD.SOURCE_ID1 = P_SOURCE_ID1
        AND (RB.HAS_DEALED IS NULL OR RB.HAS_DEALED != 'Y');
    --接口返回结果记录集
    R_RESULT_BACK C_RESULT_BACK%ROWTYPE;

    --CIMS的销售单据头ID
    V_SO_HEADER_ID  T_BD_ESB_RESULT_BACK_DETAIL.SOURCE_ID1%TYPE;
    --ERP的销售订单头ID
    V_ERP_SO_HEADER_ID  T_BD_ESB_RESULT_BACK_DETAIL.TARGET_ID1%TYPE;

    V_SOURCE_ID2 T_BD_ESB_RESULT_BACK_DETAIL.SOURCE_ID2%TYPE;
    V_SOURCE_ID3 T_BD_ESB_RESULT_BACK_DETAIL.SOURCE_ID3%TYPE;
    V_TARGET_ID2 T_BD_ESB_RESULT_BACK_DETAIL.TARGET_ID2%TYPE;
    V_TARGET_ID3 T_BD_ESB_RESULT_BACK_DETAIL.TARGET_ID3%TYPE;

    --ERP错误标识
    V_ERP_ERROR_FLAG CHAR(1) := 'N';
    --循环计数器
    V_CNT NUMBER := 0;
    --ERP返回的时间
    V_BACK_DATE DATE := SYSDATE;
    --错误信息
    V_ERROR_MSG T_BD_ESB_RESULT_BACK_DETAIL.ERROR_MESSAGE%TYPE;

    --执行更新接口头跟踪信息
    V_UPDATE_MSG VARCHAR2(256) := '';
    
    V_TRX_STATUS VARCHAR2(128);
  BEGIN
    P_RETURN_CODE := V_RETURN_CODE;
    P_RETURN_MSG  := V_RETURN_MSG;
    
    BEGIN  
       SELECT 
             OE.Gen_Trx_Status 
            INTO 
              V_TRX_STATUS
          FROM 
            INTF_OE_HEADERS_IFACE_ALL OE 
          WHERE OE.ORIG_SYS_DOCUMENT_REF=P_SOURCE_ID1;
          
         IF  V_TRX_STATUS='S' THEN
            RETURN;
         END IF;
      EXCEPTION
           when others then
             P_RETURN_MSG  := PKG_BD.F_ADD_ERROR_LOG('PKG_ESB.08',
                                                               sqlcode,
                                                               '步回回调失败：'||sqlerrm);
             P_RETURN_MSG  := V_RETURN_MSG;
      END;

    --循环读取返回结果记录集
    FOR R_RESULT_BACK IN C_RESULT_BACK LOOP
       --Dbms_Output.Put_Line(R_RESULT_BACK.ERROR_CODE || R_RESULT_BACK.ERROR_MESSAGE);

       IF V_CNT = 0 THEN
         --CIMS销售单据头ID，R_RESULT_BACK.SOURCE_ID1是销售单据头ID
         V_SO_HEADER_ID := R_RESULT_BACK.SOURCE_ID1;
         --ERP销售订单头ID
         V_ERP_SO_HEADER_ID := R_RESULT_BACK.TARGET_ID1;
         --ERP返回的时间
         V_BACK_DATE := R_RESULT_BACK.BACK_DATE;
       END IF;

       V_SOURCE_ID2 := R_RESULT_BACK.SOURCE_ID2;
       V_SOURCE_ID3 := R_RESULT_BACK.SOURCE_ID3;
       V_TARGET_ID2 := R_RESULT_BACK.TARGET_ID2;
       V_TARGET_ID3 := R_RESULT_BACK.TARGET_ID3;

       IF (R_RESULT_BACK.STATUS = V_ERP_COMPLETED) THEN
         --ERP处理成功
         IF (V_TARGET_ID3 IS NULL) THEN
           --V_TARGET_ID3为空则表明ERP返回的对应CIMS销售单据行
           --回写ERP销售单订单行ID到CIMS的销售单据行
           UPDATE T_SO_LINE
              SET ERP_SO_LINE_ID = V_TARGET_ID2,
                  --REMARK = '回写ERP销售订单行ID到CIMS的销售单据行成功，处理时间：'||TO_CHAR(R_RESULT_BACK.BACK_DATE, V_DT_FORMAT),
                  LAST_UPDATED_BY  = 'ERP',
                  LAST_UPDATE_DATE = R_RESULT_BACK.BACK_DATE
           WHERE SO_LINE_ID = TO_NUMBER(V_SOURCE_ID2);

           --更新销售订单接口行表的行记录（套件）
           UPDATE INTF_OE_LINES_IFACE_ALL
              SET STATUS     = 'S',
                  ERROR_FLAG = 'N',
                  LINE_ID    = V_TARGET_ID2
           WHERE ORIG_SYS_LINE_REF = V_SOURCE_ID2
             AND ORIG_SYS_DOCUMENT_REF = V_SO_HEADER_ID
             AND OPERATION_CODE = V_OPER_CODE_INSERT
             AND ITEM_TYPE_CODE = 'MODEL';
         ELSE
           --回写ERP销售订单行ID到CIMS的销售单据行明细
           UPDATE T_SO_LINE_DETAIL
             SET ERP_SO_LINE_ID = V_TARGET_ID3,
                 --REMARK = '回写ERP销售订单行ID到CIMS的销售单据行明细成功，处理时间：'||TO_CHAR(R_RESULT_BACK.BACK_DATE, V_DT_FORMAT),
                 LAST_UPDATED_BY = 'ERP',
                 LAST_UPDATE_DATE = R_RESULT_BACK.BACK_DATE
           WHERE SO_LINE_DETAIL_ID = TO_NUMBER(V_SOURCE_ID3);

           --更新销售订单接口行表的明细记录（散件）
           UPDATE INTF_OE_LINES_IFACE_ALL
              SET STATUS     = 'S',
                  ERROR_FLAG = 'N',
                  LINE_ID    = V_TARGET_ID3
           WHERE ORIG_SYS_SHIPMENT_REF = V_SOURCE_ID3
             AND ORIG_SYS_DOCUMENT_REF = V_SO_HEADER_ID
             AND OPERATION_CODE = V_OPER_CODE_INSERT
             AND (ITEM_TYPE_CODE IS NULL OR ITEM_TYPE_CODE ='' OR ITEM_TYPE_CODE = 'OPTION');
         END IF;

       ELSE
         --ERP处理失败
         V_ERP_ERROR_FLAG := 'Y';
         V_ERROR_MSG := R_RESULT_BACK.ERROR_MESSAGE;

         IF (V_TARGET_ID3 IS NULL) THEN
           --更新销售订单接口行表的行记录（套件）
           UPDATE INTF_OE_LINES_IFACE_ALL
              SET STATUS = 'E',
                  ERROR_FLAG = 'Y',
                  LINE_ID    = NULL
           WHERE ORIG_SYS_LINE_REF = V_SOURCE_ID2
             AND ORIG_SYS_DOCUMENT_REF = V_SO_HEADER_ID
             AND OPERATION_CODE = V_OPER_CODE_INSERT
             AND ITEM_TYPE_CODE = 'MODEL'
             AND STATUS != 'S';
         ELSE
           --更新销售订单接口行表的明细记录（散件）
           UPDATE INTF_OE_LINES_IFACE_ALL
              SET STATUS = 'E',
                  ERROR_FLAG = 'Y',
                  LINE_ID    = NULL
           WHERE ORIG_SYS_SHIPMENT_REF = V_SOURCE_ID3
             AND ORIG_SYS_DOCUMENT_REF = V_SO_HEADER_ID
             AND OPERATION_CODE = V_OPER_CODE_INSERT
             AND (ITEM_TYPE_CODE IS NULL OR ITEM_TYPE_CODE ='' OR ITEM_TYPE_CODE = 'OPTION')
             AND STATUS != 'S';
         END IF;
       END IF;

       V_CNT := V_CNT + 1;
    END LOOP;

    /**
    --更新销售单据头的ERP销售订单ID（ERP_SO_ID）字段
    UPDATE T_SO_HEADER SH
       SET SH.ERP_SO_ID   = V_ERP_SO_HEADER_ID,
           SH.ERP_SO_CODE = SH.SO_NUM
    WHERE SH.SO_HEADER_ID = TO_NUMBER(V_SO_HEADER_ID);
    */

    --更新销售订单接口头表
    IF V_ERP_ERROR_FLAG = 'Y' THEN
      --ERP返回结果为失败
      UPDATE INTF_OE_HEADERS_IFACE_ALL A
         SET STATUS      = 'E', --错误
             ERROR_FLAG  = 'Y', --设置错误标识为Y
             ERROR_MSG   = V_ERROR_MSG,
             RETURN_DATE = V_BACK_DATE,
             GEN_TRX_STATUS = 'E',
             GEN_TRX_DATE   = V_BACK_DATE
      WHERE ORIG_SYS_DOCUMENT_REF = V_SO_HEADER_ID
        AND OPERATION_CODE = V_OPER_CODE_INSERT
        AND (GEN_TRX_STATUS IS NULL OR GEN_TRX_STATUS != 'S');
    ELSE
      --更新销售单据头的ERP销售订单ID（ERP_SO_ID）字段
      UPDATE T_SO_HEADER SH
         SET SH.ERP_SO_ID   = V_ERP_SO_HEADER_ID,
             SH.ERP_SO_CODE = SH.SO_NUM,
             SH.LAST_UPDATE_DATE = SYSDATE
      WHERE SH.SO_HEADER_ID = TO_NUMBER(V_SO_HEADER_ID);

      --ERP返回结果为成功
      UPDATE INTF_OE_HEADERS_IFACE_ALL
         SET STATUS      = 'S', --成功
             ERROR_FLAG  = 'N', --设置错误标识为N
             ERROR_MSG   = '',
             RETURN_DATE = V_BACK_DATE,
             GEN_TRX_STATUS = 'S',
             GEN_TRX_DATE   = V_BACK_DATE
      WHERE ORIG_SYS_DOCUMENT_REF = V_SO_HEADER_ID
        AND OPERATION_CODE = V_OPER_CODE_INSERT;
    END IF;

    --设置ESB异步回调已处理
  --  UPDATE T_BD_ESB_RESULT_BACK SET HAS_DEALED = 'Y' WHERE REQUEST_ID = P_REQUEST_ID;

    --显式提交数据
 --   COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      P_RETURN_CODE := 'failed';
      P_RETURN_MSG  := 'ERP销售折让订单生成、折让证明订单生成过程发生异常：'||SQLERRM;
  END;


  --ERP销售折让订单登记、折让证明订单登记回调处理过程
  PROCEDURE P_ESB_RESULT_DEAL_9(P_REQUEST_ID  in  varchar2, --请求ID（交易流水号）
                                P_SOURCE_ID1  in  varchar2, --单据来源ID或编码
                                P_RETURN_CODE out varchar2, --返回编码,成功：success，失败：failed
                                P_RETURN_MSG  out varchar2  --返回信息，成功：执行成功，失败：具体失败信息
                               ) IS
    --接口返回结果游标
    CURSOR C_RESULT_BACK IS
      SELECT RB.REQUEST_ID, RB.DATA_SOURCE, RB.BACK_DATE,
             RD.SOURCE_ID1, RD.SOURCE_ID2, RD.SOURCE_ID3, RD.STATUS,
             RD.ERROR_CODE, RD.ERROR_MESSAGE, RD.TARGET_ID1, RD.TARGET_ID2, RD.TARGET_ID3
      FROM T_BD_ESB_RESULT_BACK RB, T_BD_ESB_RESULT_BACK_DETAIL RD
      WHERE RB.RESULT_BACK_ID = RD.RESULT_BACK_ID
        AND RB.REQUEST_ID = P_REQUEST_ID
        AND RD.SOURCE_ID1 = P_SOURCE_ID1
        AND (RB.HAS_DEALED IS NULL OR RB.HAS_DEALED != 'Y');
    --接口返回结果记录集
    R_RESULT_BACK C_RESULT_BACK%ROWTYPE;

    --CIMS的销售单据头ID
    V_SO_HEADER_ID  T_BD_ESB_RESULT_BACK_DETAIL.SOURCE_ID1%TYPE;

    --ERP错误标识
    V_ERP_ERROR_FLAG CHAR(1) := 'N';
    --循环计数器
    V_CNT NUMBER := 0;
    --ERP返回的时间
    V_BACK_DATE DATE := SYSDATE;
    --错误信息
    V_ERROR_MSG T_BD_ESB_RESULT_BACK_DETAIL.ERROR_MESSAGE%TYPE;

    --执行更新接口头跟踪信息
    V_UPDATE_MSG VARCHAR2(256) := '';

  BEGIN
    P_RETURN_CODE := V_RETURN_CODE;
    P_RETURN_MSG  := V_RETURN_MSG;

    --循环读取返回结果记录集
    FOR R_RESULT_BACK IN C_RESULT_BACK LOOP
       --Dbms_Output.Put_Line(R_RESULT_BACK.ERROR_CODE || R_RESULT_BACK.ERROR_MESSAGE);

       IF V_CNT = 0 THEN
         --CIMS销售单据头ID，R_RESULT_BACK.SOURCE_ID1是销售单据头ID
         V_SO_HEADER_ID := R_RESULT_BACK.SOURCE_ID1;
         --ERP返回的时间
         V_BACK_DATE := R_RESULT_BACK.BACK_DATE;
       END IF;

       IF R_RESULT_BACK.STATUS != V_ERP_COMPLETED THEN
         V_ERP_ERROR_FLAG := 'Y';
         V_ERROR_MSG := R_RESULT_BACK.ERROR_MESSAGE;
       END IF;

       V_CNT := V_CNT + 1;
    END LOOP;

    --更新销售订单接口头表
    IF V_ERP_ERROR_FLAG = 'Y' THEN
      --ERP返回结果为失败
      UPDATE INTF_OE_HEADERS_IFACE_ALL
         SET STATUS      = 'E', --错误
             ERROR_FLAG  = 'Y', --设置错误标识为Y
             ERROR_MSG   = V_ERROR_MSG,
             RETURN_DATE = V_BACK_DATE,
             BOOK_TRX_STATUS = 'E',
             BOOK_TRX_DATE   = V_BACK_DATE
      WHERE ORIG_SYS_DOCUMENT_REF = V_SO_HEADER_ID
        AND OPERATION_CODE = V_OPER_CODE_INSERT
        AND (BOOK_TRX_STATUS IS NULL OR BOOK_TRX_STATUS != 'S');
    ELSE
      --ERP返回结果为成功
      UPDATE INTF_OE_HEADERS_IFACE_ALL
         SET STATUS      = 'S', --成功
             ERROR_FLAG  = 'N', --设置错误标识为N
             ERROR_MSG   = '',
             RETURN_DATE = V_BACK_DATE,
             BOOK_TRX_STATUS = 'S',
             BOOK_TRX_DATE   = V_BACK_DATE
      WHERE ORIG_SYS_DOCUMENT_REF = V_SO_HEADER_ID
        AND OPERATION_CODE = V_OPER_CODE_INSERT;

      --更新销售单头表的ERP登记标记：Y-是，N-否
      UPDATE T_SO_HEADER SET ERP_BOOKED_FLAG = 'Y',LAST_UPDATE_DATE = SYSDATE
       WHERE SO_HEADER_ID = TO_NUMBER(V_SO_HEADER_ID);
    END IF;

    --设置ESB异步回调已处理
   -- UPDATE T_BD_ESB_RESULT_BACK SET HAS_DEALED = 'Y' WHERE REQUEST_ID = P_REQUEST_ID;

    --显式提交数据
    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      P_RETURN_CODE := 'failed';
      P_RETURN_MSG  := 'ERP销售折让单、销售折让红冲单、折让证明单、折让证明红冲单登记回调处理过程发生异常：'||SQLERRM;
  END;


  --ERP销售折让红冲单登记、折让证明红冲单登记回调处理过程
  PROCEDURE P_ESB_RESULT_DEAL_10(P_REQUEST_ID  in  varchar2, --请求ID（交易流水号）
                                 P_SOURCE_ID1  in  varchar2, --单据来源ID或编码
                                 P_RETURN_CODE out varchar2, --返回编码,成功：success，失败：failed
                                 P_RETURN_MSG  out varchar2  --返回信息，成功：执行成功，失败：具体失败信息
                                ) IS
  BEGIN
    P_ESB_RESULT_DEAL_9(P_REQUEST_ID,P_SOURCE_ID1, P_RETURN_CODE, P_RETURN_MSG);
  EXCEPTION
    WHEN OTHERS THEN
      P_RETURN_CODE := 'failed';
      P_RETURN_MSG  := 'ERP销售折让红冲单登记、折让证明红冲单登记回调处理过程发生异常：'||SQLERRM;
  END;


  --收款
  procedure P_ESB_RESULT_DEAL_13
  (
   P_REQUEST_ID  in  varchar2, --请求ID（交易流水号）
   P_SOURCE_ID1  in  varchar2, --单据来源ID或编码
   P_RETURN_CODE out varchar2, --返回编码,成功：success，失败：failed
   P_RETURN_MSG  out varchar2  --返回信息，成功：执行成功，失败：具体失败信息
   ) is
    --返回结果列表游标
    cursor resultBackCur is
      select rb.back_date,bd.back_detail_id,
             bd.source_id1,bd.source_id2,bd.source_id3,
             bd.status,bd.error_code,bd.error_message,
             bd.target_id1,bd.target_id2,bd.target_id3
        from t_bd_esb_result_back rb ,t_bd_esb_result_back_detail bd
       where rb.result_back_id=bd.result_back_id
          and rb.request_id = P_REQUEST_ID
          AND bd.SOURCE_ID1 = P_SOURCE_ID1;
    resultBack resultBackCur%ROWTYPE ;

   V_TRX_STATUS VARCHAR2(128);
  begin
    
    P_RETURN_CODE := V_RETURN_CODE;
     BEGIN  
       SELECT 
             cr.intf_status
            INTO 
              V_TRX_STATUS
          FROM 
            intf_ar_cash_receipt cr 
          WHERE cr.receipt_number=P_SOURCE_ID1;
          
         IF  V_TRX_STATUS='S' THEN
            RETURN;
         END IF;
      EXCEPTION
           when others then
             P_RETURN_MSG  := PKG_BD.F_ADD_ERROR_LOG('PKG_ESB.13',
                                                               sqlcode,
                                                               '步回回调失败：'||sqlerrm);
             P_RETURN_MSG  := V_RETURN_MSG;
      END;

    --LOOP循环
    OPEN resultBackCur;
     LOOP
       FETCH resultBackCur INTO resultBack;
       EXIT WHEN resultBackCur%NOTFOUND;
       --Dbms_Output.Put_Line(resultBack.error_code || resultBack.error_message);

       --todo,更新接口表处理状态
       if (resultBack.Status='COMPLETED') THEN
           --如果成功，置接口状态为‘S’，返回时间
           update intf_ar_cash_receipt im
              set im.intf_status = 'S',
                  im.return_date = resultBack.Back_Date
            where
            -- im.trx_no = P_REQUEST_ID and
            --  im.source_num = P_SOURCE_ID1 and
             im.receipt_number = resultBack.Source_Id1;
            --where im.RECEIPT_NUMBER =resultBack.;
            --更新业务表收款单ID
            update T_AR_CASH_RECEIPT_HEADERS ia
            set ia.ar_receipt_code = resultBack.Target_Id1
            where ia.cash_receipt_code = resultBack.Source_Id1;

       else
           --如果失败，置接口状态为‘E’，出错标志为‘Y’，出错信息为error_message，返回时间
           update intf_ar_cash_receipt im
              set im.intf_status = 'E',im.error_flag='Y',
                  im.error_msg=resultBack.Error_Message,
                  im.return_date = resultBack.Back_Date
            where
           -- im.trx_no = P_REQUEST_ID and im.source_num = P_SOURCE_ID1 and
            im.receipt_number = resultBack.Source_Id1;

       END IF;

     END LOOP;
     CLOSE resultBackCur;
     --置请求为已处理
 --    update t_bd_esb_result_back rb set rb.has_dealed='Y' where rb.request_id=P_REQUEST_ID;
   --  commit;

     exception
        when others then
          P_RETURN_CODE := 'failed';
          P_RETURN_MSG := '回调失败！'||SQLERRM;
  end;

  --收款冲销
  procedure P_ESB_RESULT_DEAL_15
  (
   P_REQUEST_ID  in  varchar2, --请求ID（交易流水号）
   P_SOURCE_ID1  in  varchar2, --单据来源ID或编码
   P_RETURN_CODE out varchar2, --返回编码,成功：success，失败：failed
   P_RETURN_MSG  out varchar2  --返回信息，成功：执行成功，失败：具体失败信息
   ) is
    --返回结果列表游标
    cursor resultBackCur is
      select rb.back_date,bd.back_detail_id,
             bd.source_id1,bd.source_id2,bd.source_id3,
             bd.status,bd.error_code,bd.error_message,
             bd.target_id1,bd.target_id2,bd.target_id3
        from t_bd_esb_result_back rb ,t_bd_esb_result_back_detail bd
       where rb.result_back_id=bd.result_back_id
          and rb.request_id = P_REQUEST_ID
          AND bd.SOURCE_ID1 = P_SOURCE_ID1;
    resultBack resultBackCur%ROWTYPE ;

  begin

    --LOOP循环
    OPEN resultBackCur;
     LOOP
       FETCH resultBackCur INTO resultBack;
       EXIT WHEN resultBackCur%NOTFOUND;
       --Dbms_Output.Put_Line(resultBack.error_code || resultBack.error_message);

       --todo,更新接口表处理状态
       if (resultBack.Status='COMPLETED') THEN
           --如果成功，置接口状态为‘S’，返回时间
           update intf_ar_receipt_reverse im
              set im.intf_status = 'S',
                  im.return_date = resultBack.Back_Date
            where im.trx_no = P_REQUEST_ID
             and im.source_num = P_SOURCE_ID1;
            --where im.RECEIPT_NUMBER =resultBack.;
       else
           --如果失败，置接口状态为‘E’，出错标志为‘Y’，出错信息为error_message，返回时间
           update intf_ar_receipt_reverse im
              set im.intf_status = 'E',im.error_flag='Y',
                  im.error_msg=resultBack.Error_Message,
                  im.return_date = resultBack.Back_Date
            where im.trx_no = P_REQUEST_ID
              and im.source_num = P_SOURCE_ID1;

       END IF;

     END LOOP;
     CLOSE resultBackCur;
     --置请求为已处理
  --   update t_bd_esb_result_back rb set rb.has_dealed='Y' where rb.request_id=P_REQUEST_ID;
    -- commit;

     exception
        when others then
          P_RETURN_CODE := 'failed';
          P_RETURN_MSG := '回调失败！'||SQLERRM;
  end;

  --应收发票
  procedure P_ESB_RESULT_DEAL_17
  (
   P_REQUEST_ID  in  varchar2, --请求ID（交易流水号）
   P_SOURCE_ID1  in  varchar2, --单据来源ID或编码
   P_RETURN_CODE out varchar2, --返回编码,成功：success，失败：failed
   P_RETURN_MSG  out varchar2  --返回信息，成功：执行成功，失败：具体失败信息
   ) is
    --返回结果列表游标
    cursor resultBackCur is
      select rb.back_date,bd.back_detail_id,
             bd.source_id1,bd.source_id2,bd.source_id3,
             bd.status,bd.error_code,bd.error_message,
             bd.target_id1,bd.target_id2,bd.target_id3
        from t_bd_esb_result_back rb ,t_bd_esb_result_back_detail bd
       where rb.result_back_id=bd.result_back_id
          and rb.request_id = P_REQUEST_ID
          AND bd.SOURCE_ID1 = P_SOURCE_ID1;
    resultBack resultBackCur%ROWTYPE ;
   V_TRX_STATUS VARCHAR2(128);
  begin
      P_RETURN_CODE := V_RETURN_CODE;
  
        BEGIN  
           SELECT 
                 cr.intf_status
                INTO 
                  V_TRX_STATUS
              FROM 
                intf_ar_invoice cr 
              WHERE cr.trx_number=P_SOURCE_ID1;
              
             IF  V_TRX_STATUS='S' THEN
                RETURN;
             END IF;
          EXCEPTION
               when others then
                 P_RETURN_MSG  := PKG_BD.F_ADD_ERROR_LOG('PKG_ESB.13',
                                                                   sqlcode,
                                                                   '步回回调失败：'||sqlerrm);
                 P_RETURN_MSG  := V_RETURN_MSG;
          END;

    --LOOP循环
    OPEN resultBackCur;
     LOOP
       FETCH resultBackCur INTO resultBack;
       EXIT WHEN resultBackCur%NOTFOUND;
       --Dbms_Output.Put_Line(resultBack.error_code || resultBack.error_message);

       --todo,更新接口表处理状态
       if (resultBack.Status='COMPLETED') THEN
           --如果成功，置接口状态为‘S’，返回时间
           update intf_ar_invoice im
              set im.intf_status = 'S',
                  im.return_date = resultBack.Back_Date
            where
           -- im.trx_no = P_REQUEST_ID and
            im.trx_number = resultBack.Source_Id1;
            --where im.RECEIPT_NUMBER =resultBack.;

            --更新收款头表t_ar_cash_receipt_headers，发票头ID：INVOICE_HEADER_ID、发票行ID：INVOICE_LINE_ID
            update t_ar_cash_receipt_headers ia
              set ia.invoice_header_id = resultBack.Target_Id1,
                  ia.invoice_line_id = resultBack.Target_Id2
            where ia.cash_receipt_code = resultBack.Source_Id1 ;
       else
           --如果失败，置接口状态为‘E’，出错标志为‘Y’，出错信息为error_message，返回时间
           update intf_ar_invoice im
              set im.intf_status = 'E',im.error_flag='Y',
                  im.error_msg=resultBack.Error_Message,
                  im.return_date = resultBack.Back_Date
            where
            --im.trx_no = P_REQUEST_ID and
            im.trx_number = resultBack.Source_Id1;

       END IF;

     END LOOP;
     CLOSE resultBackCur;
     --置请求为已处理
   --  update t_bd_esb_result_back rb set rb.has_dealed='Y' where rb.request_id=P_REQUEST_ID;
  --   commit;

     exception
        when others then
          P_RETURN_CODE := 'failed';
          P_RETURN_MSG := '回调失败！'||SQLERRM;
  end;

  --账户别名处理
  procedure P_ESB_RESULT_DEAL_22
  (
   P_REQUEST_ID  in  varchar2, --请求ID（交易流水号）
   P_SOURCE_ID1  in  varchar2, --单据来源ID或编码
   P_RETURN_CODE out varchar2, --返回编码,成功：success，失败：failed
   P_RETURN_MSG  out varchar2  --返回信息，成功：执行成功，失败：具体失败信息
   ) is
    --返回结果列表游标
    cursor resultBackCur is
      select rb.back_date,bd.back_detail_id,
             bd.source_id1,bd.source_id2,bd.source_id3,
             bd.status,bd.error_code,bd.error_message,
             bd.target_id1,bd.target_id2,bd.target_id3
        from t_bd_esb_result_back rb ,t_bd_esb_result_back_detail bd
       where rb.result_back_id = bd.result_back_id
          and rb.request_id = P_REQUEST_ID
          and bd.source_id1 = P_SOURCE_ID1 and rownum=1;--update by guibr
    resultBack resultBackCur%ROWTYPE ;
    N_HEADER_ID  number;
    N_COUNT  number;
    S_STATUS     varchar2(100);
    S_ERROR_MESSAGE     varchar2(4000);
    S_ERROR_MESSAGE_TEM     varchar2(4000);
  begin

    --LOOP循环
    OPEN resultBackCur;
     LOOP
       FETCH resultBackCur INTO resultBack;
       EXIT WHEN resultBackCur%NOTFOUND;
       --Dbms_Output.Put_Line(resultBack.error_code || resultBack.error_message);
       select
         HEADER_ID
       into
         N_HEADER_ID
       from
          INTF_INV_TRANSACTION
       where
         ID = resultBack.Source_Id1;

       select
          STATUS
       into
          S_STATUS
       from
          INTF_INV_TRANSACTION_HEAD
       where
         ID = N_HEADER_ID;

        IF S_STATUS <> 'S' THEN
               --todo,更新接口表处理状态
               if (resultBack.Status='COMPLETED') THEN
                   --如果成功，置接口状态为‘S’，返回时间
                   update INTF_INV_TRANSACTION_HEAD iith
                      set iith.STATUS = 'S',
                          iith.RETURN_DATE = resultBack.Back_Date
                    where iith.ESB_SERIAL_NUM = P_REQUEST_ID
                    and iith.id=N_HEADER_ID;
                   --更新业务表
                   update T_INV_CHECK_ORDERS tico
                      set tico.EBS_DEAL_FLAG = 'Y',
                          tico.EBS_DEAL_TIME = resultBack.Back_Date
                    where tico.CHECK_ORDER_NUM = (select ORDER_NUM from INTF_INV_TRANSACTION_HEAD where ID = N_HEADER_ID);
               else
                   --如果失败，置接口状态为‘E’，出错标志为‘Y’，出错信息为error_message，返回时间
                S_ERROR_MESSAGE :='提示';
                N_COUNT :=0;
                FOR ESB_ROW_DETAIL IN(
                   select
                      ERROR_MESSAGE
                   from
                      t_bd_esb_result_back_detail
                   where
                       request_id= P_REQUEST_ID
                   and source_id1 in(
                       select id||'' from INTF_INV_TRANSACTION where HEADER_ID = N_HEADER_ID )
                   )LOOP
                      BEGIN
                          N_COUNT := N_COUNT+1;
                          IF ESB_ROW_DETAIL.ERROR_MESSAGE not like '%批次中其他记录校验不通过%' THEN
                             S_ERROR_MESSAGE := S_ERROR_MESSAGE||';'||ESB_ROW_DETAIL.ERROR_MESSAGE;
                          END IF;
                          IF N_COUNT = 1 then
                             S_ERROR_MESSAGE_TEM := ESB_ROW_DETAIL.ERROR_MESSAGE;
                          END IF;
                      END;
                   END LOOP;

                   IF  S_ERROR_MESSAGE = '提示' and N_COUNT>0 then
                       S_ERROR_MESSAGE := S_ERROR_MESSAGE_TEM;
                   END IF;
                   S_ERROR_MESSAGE := SUBSTR(S_ERROR_MESSAGE, 1, 1000);

                   update INTF_INV_TRANSACTION_HEAD iith
                      set iith.STATUS = 'E',
                          iith.ERROR_FLAG = 'Y',
                          iith.ERROR_MSG = S_ERROR_MESSAGE,
                          iith.RETURN_DATE = resultBack.Back_Date
                    where iith.ESB_SERIAL_NUM = P_REQUEST_ID
                    and   iith.id=N_HEADER_ID;

               END IF;
           END IF;
     END LOOP;
     CLOSE resultBackCur;
     --置请求为已处理
    -- update t_bd_esb_result_back rb set rb.has_dealed='Y' where rb.request_id=P_REQUEST_ID;
   --  commit;

     exception
        when others then
          P_RETURN_CODE := 'failed';
          P_RETURN_MSG := '回调失败！'||SQLERRM;
  end;

  --子库存转移
  procedure P_ESB_RESULT_DEAL_23
  (
   P_REQUEST_ID  in  varchar2, --请求ID（交易流水号）
   P_SOURCE_ID1  in  varchar2, --单据来源ID或编码
   P_RETURN_CODE out varchar2, --返回编码,成功：success，失败：failed
   P_RETURN_MSG  out varchar2  --返回信息，成功：执行成功，失败：具体失败信息
   ) is
    --返回结果列表游标
    cursor resultBackCur is
      select rb.back_date,bd.back_detail_id,
             bd.source_id1,bd.source_id2,bd.source_id3,
             bd.status,bd.error_code,bd.error_message,
             bd.target_id1,bd.target_id2,bd.target_id3
        from t_bd_esb_result_back rb ,t_bd_esb_result_back_detail bd
       where rb.result_back_id = bd.result_back_id
          and rb.request_id = P_REQUEST_ID
          and bd.source_id1 = P_SOURCE_ID1 and rownum=1;--update by guibr
    resultBack resultBackCur%ROWTYPE ;
    N_HEADER_ID  number;
    N_COUNT  number;
    S_STATUS     varchar2(100);
    S_ERROR_MESSAGE     varchar2(4000);
    S_ERROR_MESSAGE_TEM     varchar2(4000);
    N_SO_EXIST  number;
    S_ORDER_NUM  varchar2(200);
  begin

    --LOOP循环
    OPEN resultBackCur;
     LOOP
       FETCH resultBackCur INTO resultBack;
       EXIT WHEN resultBackCur%NOTFOUND;
       --Dbms_Output.Put_Line(resultBack.error_code || resultBack.error_message);

       select
         HEADER_ID
       into
         N_HEADER_ID
       from
          INTF_INV_TRANSACTION
       where
         ID = resultBack.Source_Id1;

      select
          STATUS
          ,ORDER_NUM
       into
          S_STATUS
          ,S_ORDER_NUM
       from
          INTF_INV_TRANSACTION_HEAD
       where
         ID = N_HEADER_ID;

      IF S_STATUS <> 'S' THEN
             --todo,更新接口表处理状态
             if (resultBack.Status='COMPLETED') THEN
                 --如果成功，置接口状态为‘S’，返回时间
                 update INTF_INV_TRANSACTION_HEAD iith
                    set iith.STATUS = 'S',
                        iith.RETURN_DATE = resultBack.Back_Date
                  where iith.ESB_SERIAL_NUM = P_REQUEST_ID
                    and iith.id=N_HEADER_ID;
                  --update by guibr 20151219 销售子库转移回调
                  select
                     count(1)
                   into
                      N_SO_EXIST
                  from cims.t_so_header
                  where so_num = S_ORDER_NUM;
                  if N_SO_EXIST>0 then
                      begin
                        pkg_so_intf.P_SO_INV_TRANSFER_WIRTE_BACK(N_HEADER_ID);--resultBack.Source_Id1
                      exception
                           when others then
                              P_RETURN_MSG  := PKG_BD.F_ADD_ERROR_LOG('pkg_so_intf.P_SO_INV_TRANSFER_WIRTE_BACK',
                                                         sqlcode,
                                                         '销售子库回调失败：'||sqlerrm);
                       end;
                  else
                      --更新业务表
                      update T_INV_TRSF_ORDER tito
                        set tito.EBS_DEAL_FLAG = 'Y',
                            tito.EBS_DEAL_TIME = resultBack.Back_Date
                       where tito.TRSF_ORDER_NUM = S_ORDER_NUM;
                  end if;
             else
                 --如果失败，置接口状态为‘E’，出错标志为‘Y’，出错信息为error_message，返回时间
                 S_ERROR_MESSAGE :='提示';
                N_COUNT :=0;
                FOR ESB_ROW_DETAIL IN(
                   select
                      ERROR_MESSAGE
                   from
                      t_bd_esb_result_back_detail
                   where
                       request_id= P_REQUEST_ID
                   and source_id1 in(
                       select id||'' from INTF_INV_TRANSACTION where HEADER_ID = N_HEADER_ID )
                   )LOOP
                      BEGIN
                          N_COUNT := N_COUNT+1;
                          IF ESB_ROW_DETAIL.ERROR_MESSAGE not like '%批次中其他记录校验不通过%' THEN
                             S_ERROR_MESSAGE := S_ERROR_MESSAGE||';'||ESB_ROW_DETAIL.ERROR_MESSAGE;
                          END IF;
                          IF N_COUNT = 1 then
                             S_ERROR_MESSAGE_TEM := ESB_ROW_DETAIL.ERROR_MESSAGE;
                          END IF;
                      END;
                   END LOOP;

                   IF  S_ERROR_MESSAGE = '提示' and N_COUNT>0 then
                       S_ERROR_MESSAGE := S_ERROR_MESSAGE_TEM;
                   END IF;
                   S_ERROR_MESSAGE := SUBSTR(S_ERROR_MESSAGE, 1, 1000);



               update INTF_INV_TRANSACTION_HEAD iith
                    set iith.STATUS = 'E',
                        iith.ERROR_FLAG = 'Y',
                        iith.ERROR_MSG = S_ERROR_MESSAGE,
                        iith.RETURN_DATE = resultBack.Back_Date
                  where iith.ESB_SERIAL_NUM = P_REQUEST_ID
                   and iith.id=N_HEADER_ID;

             END IF;
         END IF;

       END LOOP;
     CLOSE resultBackCur;
     --置请求为已处理
   --  update t_bd_esb_result_back rb set rb.has_dealed='Y' where rb.request_id=P_REQUEST_ID;
     --commit;

     exception
        when others then
          P_RETURN_CODE := 'failed';
          P_RETURN_MSG := '回调失败！'||SQLERRM;
  end;

  --组织间转移
  procedure P_ESB_RESULT_DEAL_24
  (
   P_REQUEST_ID  in  varchar2, --请求ID（交易流水号）
   P_SOURCE_ID1  in  varchar2, --单据来源ID或编码
   P_RETURN_CODE out varchar2, --返回编码,成功：success，失败：failed
   P_RETURN_MSG  out varchar2  --返回信息，成功：执行成功，失败：具体失败信息
   ) is
    --返回结果列表游标
    cursor resultBackCur is
      select rb.back_date,bd.back_detail_id,
             bd.source_id1,bd.source_id2,bd.source_id3,
             bd.status,bd.error_code,bd.error_message,
             bd.target_id1,bd.target_id2,bd.target_id3
        from t_bd_esb_result_back rb ,t_bd_esb_result_back_detail bd
       where rb.result_back_id = bd.result_back_id
          and rb.request_id = P_REQUEST_ID
          and bd.source_id1 = P_SOURCE_ID1 and rownum=1;--update by guibr
    resultBack resultBackCur%ROWTYPE ;
    N_HEADER_ID  number;
    N_COUNT  number;
    S_STATUS     varchar2(100);
    S_ERROR_MESSAGE     varchar2(4000);
    S_ERROR_MESSAGE_TEM     varchar2(4000);
  begin

    --LOOP循环
    OPEN resultBackCur;
     LOOP
       FETCH resultBackCur INTO resultBack;
       EXIT WHEN resultBackCur%NOTFOUND;
       --Dbms_Output.Put_Line(resultBack.error_code || resultBack.error_message);

       select
         HEADER_ID
       into
         N_HEADER_ID
       from
          INTF_INV_TRANSACTION
       where
         ID = resultBack.Source_Id1;

       select
          STATUS
       into
          S_STATUS
       from
          INTF_INV_TRANSACTION_HEAD
       where
         ID = N_HEADER_ID;

    IF S_STATUS <> 'S' THEN
         --todo,更新接口表处理状态
         if (resultBack.Status='COMPLETED') THEN
             --如果成功，置接口状态为‘S’，返回时间
             update INTF_INV_TRANSACTION_HEAD iith
                set iith.STATUS = 'S',
                    iith.RETURN_DATE = resultBack.Back_Date
              where iith.ESB_SERIAL_NUM = P_REQUEST_ID
               and iith.id=N_HEADER_ID;
             --更新业务表

         else
             --如果失败，置接口状态为‘E’，出错标志为‘Y’，出错信息为error_message，返回时间
              S_ERROR_MESSAGE :='提示';
                N_COUNT :=0;
                FOR ESB_ROW_DETAIL IN(
                   select
                      ERROR_MESSAGE
                   from
                      t_bd_esb_result_back_detail
                   where
                       request_id= P_REQUEST_ID
                   and source_id1 in(
                       select id||'' from INTF_INV_TRANSACTION where HEADER_ID = N_HEADER_ID )
                   )LOOP
                      BEGIN
                          N_COUNT := N_COUNT+1;
                          IF ESB_ROW_DETAIL.ERROR_MESSAGE not like '%批次中其他记录校验不通过%' THEN
                             S_ERROR_MESSAGE := S_ERROR_MESSAGE||';'||ESB_ROW_DETAIL.ERROR_MESSAGE;
                          END IF;
                          IF N_COUNT = 1 then
                             S_ERROR_MESSAGE_TEM := ESB_ROW_DETAIL.ERROR_MESSAGE;
                          END IF;
                      END;
                   END LOOP;

                   IF  S_ERROR_MESSAGE = '提示' and N_COUNT>0 then
                       S_ERROR_MESSAGE := S_ERROR_MESSAGE_TEM;
                   END IF;
                   S_ERROR_MESSAGE := SUBSTR(S_ERROR_MESSAGE, 1, 1000);


             update INTF_INV_TRANSACTION_HEAD iith
                set iith.STATUS = 'E',
                    iith.ERROR_FLAG = 'Y',
                    iith.ERROR_MSG = S_ERROR_MESSAGE,
                    iith.RETURN_DATE = resultBack.Back_Date
              where iith.ESB_SERIAL_NUM = P_REQUEST_ID
               and iith.id=N_HEADER_ID;

         END IF;
       END IF;
     END LOOP;
     CLOSE resultBackCur;
     --置请求为已处理
  --   update t_bd_esb_result_back rb set rb.has_dealed='Y' where rb.request_id=P_REQUEST_ID;
   --  commit;

     exception
        when others then
          P_RETURN_CODE := 'failed';
          P_RETURN_MSG := '回调失败！'||SQLERRM;
  end;
  --推广物料
  procedure P_ESB_RESULT_DEAL_25
  (
   P_REQUEST_ID  in  varchar2, --请求ID（交易流水号）
   P_SOURCE_ID1  in  varchar2, --单据来源ID或编码
   P_RETURN_CODE out varchar2, --返回编码,成功：success，失败：failed
   P_RETURN_MSG  out varchar2  --返回信息，成功：执行成功，失败：具体失败信息
   )
   is

    --返回结果列表游标
    cursor resultBackCur is
      select rb.back_date,bd.back_detail_id,
             bd.source_id1,bd.source_id2,bd.source_id3,
             bd.status,bd.error_code,bd.error_message,
             bd.target_id1,bd.target_id2,bd.target_id3
        from t_bd_esb_result_back rb ,t_bd_esb_result_back_detail bd
       where rb.result_back_id=bd.result_back_id
          and rb.request_id = P_REQUEST_ID
          and bd.source_id1 = P_SOURCE_ID1;
    resultBack resultBackCur%ROWTYPE ;

  begin

    --LOOP循环
    OPEN resultBackCur;
     LOOP
       FETCH resultBackCur INTO resultBack;
       EXIT WHEN resultBackCur%NOTFOUND;
       --Dbms_Output.Put_Line(resultBack.error_code || resultBack.error_message);
       --todo,更新接口表处理状态
       if (resultBack.Status='COMPLETED') THEN
           --如果成功，置接口状态为‘S’，返回时间
           update intf_bd_item_mtl im
              set im.intf_status = 'S',
                  im.return_date = resultBack.Back_Date
            where im.trx_no = P_REQUEST_ID
              and im.ITEM_CODE= P_SOURCE_ID1;
       else
           --如果失败，置接口状态为‘E’，出错标志为‘Y’，出错信息为error_message，返回时间
           update intf_bd_item_mtl im
              set im.intf_status = 'E',im.error_flag='Y',
                  im.error_msg=resultBack.Error_Message,
                  im.return_date = resultBack.Back_Date
            where im.trx_no = P_REQUEST_ID
              and im.ITEM_CODE= P_SOURCE_ID1;
       END IF;

     END LOOP;
     CLOSE resultBackCur;
     --置请求为已处理
   --  update t_bd_esb_result_back rb set rb.has_dealed='Y' where rb.request_id=P_REQUEST_ID;


     exception
        when others then
          P_RETURN_CODE := 'failed';
          P_RETURN_MSG := '回调失败！'||SQLERRM;
  end;
  --物料成本
  procedure P_ESB_RESULT_DEAL_26
  (
   P_REQUEST_ID  in  varchar2, --请求ID（交易流水号）
   P_SOURCE_ID1  in  varchar2, --单据来源ID或编码
   P_RETURN_CODE out varchar2, --返回编码,成功：success，失败：failed
   P_RETURN_MSG  out varchar2  --返回信息，成功：执行成功，失败：具体失败信息
   )
   is

    --返回结果列表游标
    cursor resultBackCur is
      select rb.back_date,bd.back_detail_id,
             bd.source_id1,bd.source_id2,bd.source_id3,
             bd.status,bd.error_code,bd.error_message,
             bd.target_id1,bd.target_id2,bd.target_id3
        from t_bd_esb_result_back rb ,t_bd_esb_result_back_detail bd
       where rb.result_back_id=bd.result_back_id
          and rb.request_id = P_REQUEST_ID
	  and bd.source_id1 = P_SOURCE_ID1;
    resultBack resultBackCur%ROWTYPE ;
    ld_back_date resultBack.Back_Date%type;

  begin

    --LOOP循环
    OPEN resultBackCur;
     LOOP
       FETCH resultBackCur INTO resultBack;
       EXIT WHEN resultBackCur%NOTFOUND;
       --Dbms_Output.Put_Line(resultBack.error_code || resultBack.error_message);
       ld_back_date := resultBack.Back_Date;
       --todo,更新接口表处理状态
       if (resultBack.Status='COMPLETED') THEN
           if (nvl(resultBack.Source_Id1,'NULL')='NULL') then
             update intf_bd_price_line im
                set im.intf_status = 'S',
                    im.return_date = resultBack.Back_Date
              where im.trx_no = P_REQUEST_ID;
              exit;
           end if;
           --如果成功，置接口状态为‘S’，返回时间
           update intf_bd_price_line im
              set im.intf_status = 'S',
                  im.return_date = resultBack.Back_Date
            where im.trx_no = P_REQUEST_ID
                 and im.price_line_id = resultBack.Source_Id1;
       else
           --如果失败，置接口状态为‘E’，出错标志为‘Y’，出错信息为error_message，返回时间
           update intf_bd_price_line im
              set im.intf_status = 'E',im.error_flag='Y',
                  im.error_msg=resultBack.Error_Message,
                  im.return_date = resultBack.Back_Date
            where im.trx_no = P_REQUEST_ID
                and im.price_line_id = resultBack.Source_Id1;
       END IF;

     END LOOP;
     CLOSE resultBackCur;
     --更新除失败与成功的记录，均成成功    ? 去掉 update by guibr 20160425
     --update intf_bd_price_line im
     --         set im.intf_status = 'S',
     --            im.return_date = ld_back_date
     --       where im.trx_no = P_REQUEST_ID
     --           and im.intf_status not in ('E','S');
     --置请求为已处理
 --    update t_bd_esb_result_back rb set rb.has_dealed='Y' where rb.request_id=P_REQUEST_ID;


     exception
        when others then
          P_RETURN_CODE := 'failed';
          P_RETURN_MSG := '回调失败！'||SQLERRM;
  end;

    --采购订单接收
  procedure P_ESB_RESULT_DEAL_27
  (
   P_REQUEST_ID  in  varchar2, --请求ID（交易流水号）
   P_SOURCE_ID1  in  varchar2, --单据来源ID或编码
   P_RETURN_CODE out varchar2, --返回编码,成功：success，失败：failed
   P_RETURN_MSG  out varchar2  --返回信息，成功：执行成功，失败：具体失败信息
   ) is
    --定义变量
    PMT_COUNT NUMBER;--是否推广物料用
    --返回结果列表游标
    cursor resultBackCur is
      select rb.back_date,bd.back_detail_id,
             bd.source_id1,bd.source_id2,bd.source_id3,
             bd.status,bd.error_code,bd.error_message,
             bd.target_id1,bd.target_id2,bd.target_id3
        from t_bd_esb_result_back rb ,t_bd_esb_result_back_detail bd
       where rb.result_back_id = bd.result_back_id
          and rb.request_id = P_REQUEST_ID ;
    resultBack resultBackCur%ROWTYPE ;

  begin

    --LOOP循环
    OPEN resultBackCur;
     LOOP
       FETCH resultBackCur INTO resultBack;
       EXIT WHEN resultBackCur%NOTFOUND;
       --Dbms_Output.Put_Line(resultBack.error_code || resultBack.error_message);

       --todo,更新接口表处理状态
       if (resultBack.Status='COMPLETED') THEN
            --判断是否是推广物料用的单据
            SELECT COUNT(*)
            INTO PMT_COUNT
            FROM T_PMT_ORDER_INV_DETAIL pd
            WHERE pd.po_num = resultBack.Source_Id1;

            IF(PMT_COUNT<>0) THEN
               --是推广物料的单据则需要回写数据
                UPDATE T_PMT_ORDER_INV_DETAIL pd
                 SET pd.po_received_header_num = resultBack.Target_Id1,
                     pd.po_received_lines_num = resultBack.Target_Id2
                WHERE pd.po_num = resultBack.Source_Id1
                      AND pd.pmt_code in (
                          SELECT cpo.item_code
                          FROM INTF_CUX_PO_ORDER cpo
                          WHERE cpo.po_number = resultBack.Source_Id1
                                AND cpo.source_num = resultBack.Source_Id2
                      );
               --
               IF 0 = SQL%ROWCOUNT THEN
                 P_RETURN_CODE := 'failed';
                 P_RETURN_MSG  := '回调不成功：无法回写T_PMT_ORDER_INV_DETAIL的po_received_header_num、po_received_lines_num字段';
                 update INTF_CUX_PO_ORDER icpo
                  set icpo.STATUS_RAV = 'E',
                      icpo.ERROR_FLAG = 'Y',
                      icpo.ERROR_MSG = P_RETURN_MSG,
                      icpo.RETURN_DATE = resultBack.Back_Date
                where icpo.ESB_SERIAL_NUM = P_REQUEST_ID;
               ELSE
                 --如果成功，置接口状态为‘S’，返回时间
                 update INTF_CUX_PO_ORDER icpo
                    set icpo.STATUS_RAV = 'S',
                        icpo.RETURN_DATE = resultBack.Back_Date
                  where icpo.ESB_SERIAL_NUM = P_REQUEST_ID;
                  --更新业务表
                 update T_INV_PO_HEADERS tiph
                    set tiph.EBS_DEAL_FLAG_RECEIVE = 'Y',
                        tiph.EBS_DEAL_TIME_RECEIVE = resultBack.Back_Date
                  where tiph.PO_NUM = resultBack.Source_Id1;
               END IF;
            ELSE
              --成品采购，非推广物料
               update INTF_CUX_PO_ORDER icpo
                    set icpo.STATUS_RAV = 'S',
                        icpo.RETURN_DATE = resultBack.Back_Date
                  where icpo.ESB_SERIAL_NUM = P_REQUEST_ID;
                --更新业务表
               update T_INV_PO_HEADERS tiph
                  set tiph.EBS_DEAL_FLAG_RECEIVE = 'Y',
                      tiph.EBS_DEAL_TIME_RECEIVE = resultBack.Back_Date
                where tiph.PO_NUM = resultBack.Source_Id1;  
                  
            END IF;
       else
           --如果失败，置接口状态为‘E’，出错标志为‘Y’，出错信息为error_message，返回时间
           update INTF_CUX_PO_ORDER icpo
              set icpo.STATUS_RAV = 'E',
                  icpo.ERROR_FLAG = 'Y',
                  icpo.ERROR_MSG = resultBack.Error_Message,
                  icpo.RETURN_DATE = resultBack.Back_Date
            where icpo.ESB_SERIAL_NUM = P_REQUEST_ID;

       END IF;

     END LOOP;
     CLOSE resultBackCur;
     --置请求为已处理
   --  update t_bd_esb_result_back rb set rb.has_dealed='Y' where rb.request_id=P_REQUEST_ID;
   --  commit;

     exception
        when others then
          P_RETURN_CODE := 'failed';
          P_RETURN_MSG := '回调失败！'||SQLERRM;
  end;

  --采购订单退订
  procedure P_ESB_RESULT_DEAL_28
  (
   P_REQUEST_ID  in  varchar2, --请求ID（交易流水号）
   P_SOURCE_ID1  in  varchar2, --单据来源ID或编码
   P_RETURN_CODE out varchar2, --返回编码,成功：success，失败：failed
   P_RETURN_MSG  out varchar2  --返回信息，成功：执行成功，失败：具体失败信息
   ) is
    --返回结果列表游标
    cursor resultBackCur is
      select rb.back_date,bd.back_detail_id,
             bd.source_id1,bd.source_id2,bd.source_id3,
             bd.status,bd.error_code,bd.error_message,
             bd.target_id1,bd.target_id2,bd.target_id3
        from t_bd_esb_result_back rb ,t_bd_esb_result_back_detail bd
       where rb.result_back_id = bd.result_back_id
          and rb.request_id = P_REQUEST_ID ;
    resultBack resultBackCur%ROWTYPE ;

  begin

    --LOOP循环
    OPEN resultBackCur;
     LOOP
       FETCH resultBackCur INTO resultBack;
       EXIT WHEN resultBackCur%NOTFOUND;
       --Dbms_Output.Put_Line(resultBack.error_code || resultBack.error_message);

       --todo,更新接口表处理状态
       if (resultBack.Status='COMPLETED') THEN
           --如果成功，置接口状态为‘S’，返回时间
           update INTF_CUX_PO_ORDER icpo
              set icpo.STATUS_RETURN = 'S',
                  icpo.RETURN_DATE = resultBack.Back_Date
            where icpo.ESB_SERIAL_NUM = P_REQUEST_ID;
            --更新业务表
           update T_INV_PO_HEADERS tiph
              set tiph.EBS_DEAL_FLAG_RETURN = 'Y',
                  tiph.EBS_DEAL_TIME_RETURN = resultBack.Back_Date
            where tiph.PO_NUM = resultBack.Source_Id1;
       else
           --如果失败，置接口状态为‘E’，出错标志为‘Y’，出错信息为error_message，返回时间
           update INTF_CUX_PO_ORDER icpo
              set icpo.STATUS_RETURN = 'E',
                  icpo.ERROR_FLAG = 'Y',
                  icpo.ERROR_MSG = resultBack.Error_Message,
                  icpo.RETURN_DATE = resultBack.Back_Date
            where icpo.ESB_SERIAL_NUM = P_REQUEST_ID;

       END IF;

     END LOOP;
     CLOSE resultBackCur;
     --置请求为已处理
    -- update t_bd_esb_result_back rb set rb.has_dealed='Y' where rb.request_id=P_REQUEST_ID;
    -- commit;

     exception
        when others then
          P_RETURN_CODE := 'failed';
          P_RETURN_MSG := '回调失败！'||SQLERRM;
  end;
  
  --关联物流订单回调
  PROCEDURE P_ESB_RESULT_DEAL_51(P_REQUEST_ID  in  varchar2, --请求ID（交易流水号）
                                P_SOURCE_ID1  in  varchar2, --单据来源ID或编码
                                P_RETURN_CODE out varchar2, --返回编码,成功：success，失败：failed
                                P_RETURN_MSG  out varchar2  --返回信息，成功：执行成功，失败：具体失败信息
                               ) IS
    --接口返回结果游标
    CURSOR resultBackCur IS
      SELECT RB.REQUEST_ID, RB.DATA_SOURCE, RB.BACK_DATE,
             RD.SOURCE_ID1, RD.SOURCE_ID2, RD.SOURCE_ID3, RD.STATUS,
             RD.ERROR_CODE, RD.ERROR_MESSAGE, RD.TARGET_ID1, RD.TARGET_ID2, RD.TARGET_ID3
      FROM T_BD_ESB_RESULT_BACK RB, T_BD_ESB_RESULT_BACK_DETAIL RD
      WHERE RB.RESULT_BACK_ID = RD.RESULT_BACK_ID
        AND RB.REQUEST_ID = P_REQUEST_ID
        AND RD.SOURCE_ID1 = P_SOURCE_ID1
        AND (RB.HAS_DEALED IS NULL OR RB.HAS_DEALED != 'Y');
     resultBack resultBackCur%ROWTYPE ;
     S_ORDERS_TYPE VARCHAR(100);
     S_GROUP_CODE  VARCHAR(100);
     N_REQ_HEADER_ID NUMBER;
     S_STATUS_SUPPLIER  VARCHAR(100);
     S_STATUS_RECEIVE  VARCHAR(100);
     S_STATUS_SOURCE   VARCHAR(100);
  BEGIN
    P_RETURN_CODE := V_RETURN_CODE;
    P_RETURN_MSG  := V_RETURN_MSG;
     --LOOP循环
    OPEN resultBackCur;
     LOOP
       FETCH resultBackCur INTO resultBack;
       EXIT WHEN resultBackCur%NOTFOUND;
       SELECT LH.REQUIREMENT_ORDER_TYPE,LH.GROUP_CODE,ID,STATUS_SUPPLIER,STATUS_RECEIVE,STATUS_SOURCE
       INTO S_ORDERS_TYPE,S_GROUP_CODE,N_REQ_HEADER_ID,S_STATUS_SUPPLIER,S_STATUS_RECEIVE,S_STATUS_SOURCE 
       FROM INTF_CUX_ICP_LOGIST_REQ_HEADER LH WHERE LH.REQUIREMENT_ORDER_NUM = RESULTBACK.SOURCE_ID2;  
       
       IF S_ORDERS_TYPE = '02' THEN
          IF S_STATUS_SOURCE='S' THEN
              exit;
          END IF;
       ELSIF S_ORDERS_TYPE IN('01','03') THEN
          IF S_STATUS_SUPPLIER='S' AND S_STATUS_RECEIVE='S'  THEN
              exit;
          END IF;
       ELSE   
           NULL;
       END IF;

       --TODO,更新接口表处理状态
       IF (RESULTBACK.STATUS='COMPLETED') THEN
             IF S_ORDERS_TYPE = '02' THEN
                UPDATE INTF_CUX_ICP_LOGIST_REQ_HEADER set STATUS_SOURCE='S',RESPONSETYPE_1='N',X_ICP_SEQ_ID=RESULTBACK.TARGET_ID1,RETURN_DATE_SEND= resultBack.Back_Date where REQUIREMENT_ORDER_NUM = RESULTBACK.SOURCE_ID2;    
                UPDATE T_SO_HEADER SH SET SH.ERP_LOGIST_HEADER_ID = RESULTBACK.TARGET_ID1,SH.LAST_UPDATE_DATE=SYSDATE WHERE SH.SO_HEADER_ID = TO_NUMBER(RESULTBACK.SOURCE_ID1);
             ELSIF S_ORDERS_TYPE = '01' THEN
                IF S_STATUS_SUPPLIER='S' THEN
                   IF S_STATUS_RECEIVE ='P' THEN
                      update INTF_CUX_ICP_LOGIST_REQ_HEADER set STATUS_RECEIVE = 'S',RESPONSETYPE_2='N' ,RETURN_DATE_REV= resultBack.Back_Date where REQUIREMENT_ORDER_NUM = RESULTBACK.SOURCE_ID2;
                   END IF;
                ELSE
                    update INTF_CUX_ICP_LOGIST_REQ_HEADER set STATUS_SUPPLIER = 'S',RESPONSETYPE_1='N', REQ_HEADER_ID = RESULTBACK.TARGET_ID1, X_ICP_SEQ_ID = RESULTBACK.TARGET_ID1, RETURN_DATE_SEND= resultBack.Back_Date where REQUIREMENT_ORDER_NUM = RESULTBACK.SOURCE_ID2; 
                    update INTF_CUX_ICP_LOGIST_REQ_LINES set LOGIST_HEADER_ID = RESULTBACK.TARGET_ID1 where HEADERS_ID = N_REQ_HEADER_ID;
                    UPDATE T_INV_PO_HEADERS PH SET PH.ERP_LOGIST_HEADER_ID = RESULTBACK.TARGET_ID1,PH.LAST_UPDATE_DATE=SYSDATE  WHERE PH.PO_ID = TO_NUMBER(RESULTBACK.SOURCE_ID1);
                END IF;    
             ELSIF S_ORDERS_TYPE = '03' THEN
                IF S_STATUS_SUPPLIER='S' THEN
                   IF S_STATUS_RECEIVE ='P' THEN
                      update INTF_CUX_ICP_LOGIST_REQ_HEADER set STATUS_RECEIVE = 'S',RESPONSETYPE_2='N', RETURN_DATE_REV= resultBack.Back_Date where REQUIREMENT_ORDER_NUM = RESULTBACK.SOURCE_ID2;  
                   END IF;
                ELSE
                   update INTF_CUX_ICP_LOGIST_REQ_HEADER set STATUS_SUPPLIER = 'S',RESPONSETYPE_1='N',REQ_HEADER_ID = RESULTBACK.TARGET_ID1, X_ICP_SEQ_ID = RESULTBACK.TARGET_ID1, RETURN_DATE_SEND= resultBack.Back_Date where REQUIREMENT_ORDER_NUM = RESULTBACK.SOURCE_ID2; 
                   update INTF_CUX_ICP_LOGIST_REQ_LINES set LOGIST_HEADER_ID = RESULTBACK.TARGET_ID1 where HEADERS_ID = N_REQ_HEADER_ID;
                   UPDATE T_SO_HEADER SH SET SH.ERP_LOGIST_HEADER_ID2 = RESULTBACK.TARGET_ID1,SH.LAST_UPDATE_DATE=SYSDATE WHERE SH.SO_HEADER_ID = TO_NUMBER(RESULTBACK.SOURCE_ID1);
                END IF;    
             END IF;   
       ELSE
            IF S_ORDERS_TYPE = '02' THEN
                UPDATE INTF_CUX_ICP_LOGIST_REQ_HEADER set STATUS_SOURCE='E',RESPONSETYPE_1='E',RESPONSEMESSAGE_1=RESULTBACK.ERROR_MESSAGE,RETURN_DATE_SEND= resultBack.Back_Date where REQUIREMENT_ORDER_NUM = RESULTBACK.SOURCE_ID2 AND STATUS_SOURCE<>'S';    
            ELSIF S_ORDERS_TYPE = '01' THEN
                IF S_STATUS_SUPPLIER='S' THEN
                   IF S_STATUS_RECEIVE ='P' THEN
                      update INTF_CUX_ICP_LOGIST_REQ_HEADER set STATUS_RECEIVE = 'E',RESPONSETYPE_2='E',RESPONSEMESSAGE_2=RESULTBACK.ERROR_MESSAGE,RETURN_DATE_REV= resultBack.Back_Date where REQUIREMENT_ORDER_NUM = RESULTBACK.SOURCE_ID2 and STATUS_RECEIVE <> 'S';  
                   END IF;
                ELSE
                   update INTF_CUX_ICP_LOGIST_REQ_HEADER set STATUS_SUPPLIER = 'E',RESPONSETYPE_1='E',RESPONSEMESSAGE_1=RESULTBACK.ERROR_MESSAGE,RETURN_DATE_SEND= resultBack.Back_Date where REQUIREMENT_ORDER_NUM = RESULTBACK.SOURCE_ID2 and STATUS_SUPPLIER <> 'S';
                END IF;    
             ELSIF S_ORDERS_TYPE = '03' THEN
                 IF S_STATUS_SUPPLIER='S' THEN
                    IF S_GROUP_CODE = 'B09' AND RESULTBACK.ERROR_MESSAGE like '%状态已完成%' THEN
                       update INTF_CUX_ICP_LOGIST_REQ_HEADER set STATUS_RECEIVE = 'S',RESPONSETYPE_2='N',RESPONSEMESSAGE_2=RESULTBACK.ERROR_MESSAGE,RETURN_DATE_REV= resultBack.Back_Date where REQUIREMENT_ORDER_NUM = RESULTBACK.SOURCE_ID2 and STATUS_RECEIVE <> 'S'; 
                    ELSE
                        IF S_STATUS_RECEIVE ='P' THEN
                          update INTF_CUX_ICP_LOGIST_REQ_HEADER set STATUS_RECEIVE = 'E',RESPONSETYPE_2='E',RESPONSEMESSAGE_2=RESULTBACK.ERROR_MESSAGE,RETURN_DATE_REV= resultBack.Back_Date where REQUIREMENT_ORDER_NUM = RESULTBACK.SOURCE_ID2 and STATUS_RECEIVE <> 'S'; 
                        END IF;
                  END IF;  
                 ELSE
                    update INTF_CUX_ICP_LOGIST_REQ_HEADER set STATUS_SUPPLIER = 'E',RESPONSETYPE_1='E',RESPONSEMESSAGE_1=RESULTBACK.ERROR_MESSAGE,RETURN_DATE_SEND= resultBack.Back_Date where REQUIREMENT_ORDER_NUM = RESULTBACK.SOURCE_ID2 and STATUS_SUPPLIER <> 'S';
                 END IF;
             END IF;  
       END IF;

     END LOOP;
     CLOSE resultBackCur;
     exception
        when others then
          P_RETURN_CODE := 'failed';
          P_RETURN_MSG := '回调失败！'||SQLERRM;
    

  END;

  
  
  --关联订单回调
  PROCEDURE P_ESB_RESULT_DEAL_58(P_REQUEST_ID  in  varchar2, --请求ID（交易流水号）
                                P_SOURCE_ID1  in  varchar2, --单据来源ID或编码
                                P_RETURN_CODE out varchar2, --返回编码,成功：success，失败：failed
                                P_RETURN_MSG  out varchar2  --返回信息，成功：执行成功，失败：具体失败信息
                               ) IS
    --接口返回结果游标
    CURSOR resultBackCur IS
      SELECT RB.REQUEST_ID, RB.DATA_SOURCE, RB.BACK_DATE,
             RD.SOURCE_ID1, RD.SOURCE_ID2, RD.SOURCE_ID3, RD.STATUS,
             RD.ERROR_CODE, RD.ERROR_MESSAGE, RD.TARGET_ID1, RD.TARGET_ID2, RD.TARGET_ID3
      FROM T_BD_ESB_RESULT_BACK RB, T_BD_ESB_RESULT_BACK_DETAIL RD
      WHERE RB.RESULT_BACK_ID = RD.RESULT_BACK_ID
        AND RB.REQUEST_ID = P_REQUEST_ID
        AND RD.SOURCE_ID1 = P_SOURCE_ID1
        AND (RB.HAS_DEALED IS NULL OR RB.HAS_DEALED != 'Y');

     resultBack resultBackCur%ROWTYPE ;
     S_ORDERS_TYPE VARCHAR(100);
     V_TRX_STATUS VARCHAR2(128);
  BEGIN
    P_RETURN_CODE := V_RETURN_CODE;
    P_RETURN_MSG  := V_RETURN_MSG;
   
     --LOOP循环
    OPEN resultBackCur;
     LOOP
       FETCH resultBackCur INTO resultBack;
       EXIT WHEN resultBackCur%NOTFOUND;
       
        BEGIN  
           SELECT 
                 cr.STATUS
                INTO 
                  V_TRX_STATUS
              FROM 
                INTF_CUX_ICP_ORDER_REQ_HEADERS cr 
              WHERE cr.source_orders=RESULTBACK.SOURCE_ID2;
              
             IF  V_TRX_STATUS='S' THEN
               exit;
             END IF;
         EXCEPTION
               when others then
                 P_RETURN_MSG  := PKG_BD.F_ADD_ERROR_LOG('PKG_ESB.58',
                                                                   sqlcode,
                                                                   '步回回调失败：'||sqlerrm);
                 P_RETURN_MSG  := V_RETURN_MSG;
         END;
       
       --TODO,更新接口表处理状态
       IF (RESULTBACK.STATUS='COMPLETED') THEN
             --如果成功，置接口状态为‘S’，返回时间
              UPDATE INTF_CUX_ICP_ORDER_REQ_HEADERS IM
                SET IM.STATUS = 'S',
                    IM.RETURN_DATE = RESULTBACK.BACK_DATE,
                    IM.X_ICP_SEQ_ID = RESULTBACK.TARGET_ID1
              WHERE IM.SOURCE_ORDERS = RESULTBACK.SOURCE_ID2;
              
              SELECT SOURCE_ORDERS_TYPE INTO S_ORDERS_TYPE FROM INTF_CUX_ICP_ORDER_REQ_HEADERS WHERE SOURCE_ORDERS=  RESULTBACK.SOURCE_ID2;  
              UPDATE INTF_CUX_ICP_LOGIST_REQ_LINES RL SET RL.ORDER_HEADER_ID= RESULTBACK.TARGET_ID1,RL.X_ICP_SEQ_ID = RESULTBACK.TARGET_ID1 WHERE RL.SOURCE_HEADER= RESULTBACK.SOURCE_ID2;       
              IF S_ORDERS_TYPE = '01' THEN
                   UPDATE T_INV_PO_HEADERS PH SET PH.ERP_ORDER_HEADER_ID = RESULTBACK.TARGET_ID1,PH.LAST_UPDATE_DATE=SYSDATE  WHERE PH.PO_ID = TO_NUMBER(RESULTBACK.SOURCE_ID1);
                   UPDATE INTF_CUX_ICP_LOGIST_REQ_HEADER RH SET RH.STATUS='P',RH.STATUS_SUPPLIER='N' WHERE RH.REQUIREMENT_ORDER_NUM=RESULTBACK.SOURCE_ID2 AND (RH.STATUS_SUPPLIER IS NULL OR RH.STATUS_SUPPLIER<>'S'); 
              ELSIF  S_ORDERS_TYPE = '02' THEN
                   UPDATE T_SO_HEADER SH SET SH.ERP_ORDER_HEADER_ID = RESULTBACK.TARGET_ID1,SH.LAST_UPDATE_DATE=SYSDATE WHERE SH.SO_HEADER_ID = TO_NUMBER(RESULTBACK.SOURCE_ID1);
                   UPDATE INTF_CUX_ICP_LOGIST_REQ_HEADER RH SET RH.STATUS_SOURCE='N' WHERE RH.REQUIREMENT_ORDER_NUM=RESULTBACK.SOURCE_ID2 AND (RH.STATUS_SOURCE IS NULL OR RH.STATUS_SOURCE<>'S'); 
              ELSIF  S_ORDERS_TYPE = '03' THEN 
                   UPDATE T_SO_HEADER SH SET SH.ERP_ORDER_HEADER_ID2 = RESULTBACK.TARGET_ID1,SH.LAST_UPDATE_DATE=SYSDATE WHERE SH.SO_HEADER_ID = TO_NUMBER(RESULTBACK.SOURCE_ID1);
                   UPDATE INTF_CUX_ICP_LOGIST_REQ_HEADER RH SET RH.STATUS='P',RH.STATUS_SUPPLIER='N' WHERE RH.REQUIREMENT_ORDER_NUM=RESULTBACK.SOURCE_ID2 AND (RH.STATUS_SUPPLIER IS NULL OR RH.STATUS_SUPPLIER<>'S' ); 
              ELSE
                  NULL;   
              END IF;
       ELSE
             --如果失败，置接口状态为‘E’，出错标志为‘Y’，出错信息为ERROR_MESSAGE，返回时间
             UPDATE INTF_CUX_ICP_ORDER_REQ_HEADERS IM
                SET IM.STATUS = 'E',IM.ERROR_FLAG='Y',
                    IM.ERROR_MSG=RESULTBACK.ERROR_MESSAGE,
                    IM.RETURN_DATE = RESULTBACK.BACK_DATE,
                    IM.RESPONSETYPE = 'E',
                    IM.RESPONSEMESSAGE = RESULTBACK.ERROR_MESSAGE
              WHERE IM.SOURCE_ORDERS = RESULTBACK.SOURCE_ID2
                 AND IM.STATUS<>'S';
       END IF;

     END LOOP;
     CLOSE resultBackCur;
     exception
        when others then
          P_RETURN_CODE := 'failed';
          P_RETURN_MSG := '回调失败！'||SQLERRM;
  END;

  --在途资金确认（纸票在途核销）
  procedure P_ESB_RESULT_DEAL_60
  (
   P_REQUEST_ID  in  varchar2, --请求ID（交易流水号）
   P_SOURCE_ID1  in  varchar2, --单据来源ID或编码
   P_RETURN_CODE out varchar2, --返回编码,成功：success，失败：failed
   P_RETURN_MSG  out varchar2  --返回信息，成功：执行成功，失败：具体失败信息
   ) is
    --返回结果列表游标
    cursor resultBackCur is
      select rb.back_date,bd.back_detail_id,
             bd.source_id1,bd.source_id2,bd.source_id3,
             bd.status,bd.error_code,bd.error_message,
             bd.target_id1,bd.target_id2,bd.target_id3
        from t_bd_esb_result_back rb ,t_bd_esb_result_back_detail bd
       where rb.result_back_id=bd.result_back_id
          and rb.request_id = P_REQUEST_ID   ;
    resultBack resultBackCur%ROWTYPE ;

  begin

    --LOOP循环
    OPEN resultBackCur;
     LOOP
       FETCH resultBackCur INTO resultBack;
       EXIT WHEN resultBackCur%NOTFOUND;
       --Dbms_Output.Put_Line(resultBack.error_code || resultBack.error_message);

       --todo,更新接口表处理状态
       if (resultBack.Status='COMPLETED') THEN
           --如果成功，置接口状态为‘S’，返回时间
           update INTF_AR_CASH_INTRANSIT_CONFIRM im
              set im.intf_status = 'S',
                  im.return_date = resultBack.Back_Date
            where im.trx_no = P_REQUEST_ID;
            --where im.RECEIPT_NUMBER =resultBack.;
       else
           --如果失败，置接口状态为‘E’，出错标志为‘Y’，出错信息为error_message，返回时间
           update INTF_AR_CASH_INTRANSIT_CONFIRM im
              set im.intf_status = 'E',im.error_flag='Y',
                  im.error_msg=resultBack.Error_Message,
                  im.return_date = resultBack.Back_Date
            where im.trx_no = P_REQUEST_ID;

       END IF;

     END LOOP;
     CLOSE resultBackCur;
     --置请求为已处理
    -- update t_bd_esb_result_back rb set rb.has_dealed='Y' where rb.request_id=P_REQUEST_ID;
   --  commit;

     exception
        when others then
          P_RETURN_CODE := 'failed';
          P_RETURN_MSG := '回调失败！'||SQLERRM;
  end;


  --核销关系（到款-发票）
  procedure P_ESB_RESULT_DEAL_61
  (
   P_REQUEST_ID  in  varchar2, --请求ID（交易流水号）
   P_SOURCE_ID1  in  varchar2, --单据来源ID或编码
   P_RETURN_CODE out varchar2, --返回编码,成功：success，失败：failed
   P_RETURN_MSG  out varchar2  --返回信息，成功：执行成功，失败：具体失败信息
   ) is
    --返回结果列表游标
    cursor resultBackCur is
      select rb.back_date,bd.back_detail_id,
             bd.source_id1,bd.source_id2,bd.source_id3,
             bd.status,bd.error_code,bd.error_message,
             bd.target_id1,bd.target_id2,bd.target_id3
        from t_bd_esb_result_back rb ,t_bd_esb_result_back_detail bd
       where rb.result_back_id=bd.result_back_id
          and rb.request_id = P_REQUEST_ID;
    resultBack resultBackCur%ROWTYPE ;

  begin

    --LOOP循环
    OPEN resultBackCur;
     LOOP
       FETCH resultBackCur INTO resultBack;
       EXIT WHEN resultBackCur%NOTFOUND;
       --Dbms_Output.Put_Line(resultBack.error_code || resultBack.error_message);

       --todo,更新接口表处理状态
       if (resultBack.Status='COMPLETED') THEN
           --如果成功，置接口状态为‘S’，返回时间
           update intf_ar_writeoff im
              set im.intf_status = 'S',
                  im.return_date = resultBack.Back_Date
            where im.trx_no = P_REQUEST_ID;
            --where im.trx_no = P_REQUEST_ID and im.receipt_number = resultBack.Source_Id1;
            --where im.RECEIPT_NUMBER =resultBack.;
       else
           --如果失败，置接口状态为‘E’，出错标志为‘Y’，出错信息为error_message，返回时间
           update intf_ar_writeoff im
              set im.intf_status = 'E',im.error_flag='Y',
                  im.err_message = resultBack.Error_Message,
                  im.return_date = resultBack.Back_Date
              where im.trx_no = P_REQUEST_ID;
            --where im.trx_no = P_REQUEST_ID and im.receipt_number = resultBack.Source_Id1;

       END IF;

     END LOOP;
     CLOSE resultBackCur;
     --置请求为已处理
    -- update t_bd_esb_result_back rb set rb.has_dealed='Y' where rb.request_id=P_REQUEST_ID;
     --commit;

     exception
        when others then
          P_RETURN_CODE := 'failed';
          P_RETURN_MSG := '回调失败！'||SQLERRM;
  end;


   --核销关系（到款-发票）
  procedure P_ESB_RESULT_DEAL_61_1
  (
   P_REQUEST_ID  in  varchar2, --请求ID（交易流水号）
   P_SOURCE_ID1  in  varchar2, --单据来源ID或编码
   P_RETURN_CODE out varchar2, --返回编码,成功：success，失败：failed
   P_RETURN_MSG  out varchar2  --返回信息，成功：执行成功，失败：具体失败信息
   ) is
    --返回结果列表游标
    cursor resultBackCur is
      select rb.back_date,bd.back_detail_id,
             bd.source_id1,bd.source_id2,bd.source_id3,
             bd.status,bd.error_code,bd.error_message,
             bd.target_id1,bd.target_id2,bd.target_id3
        from t_bd_esb_result_back rb ,t_bd_esb_result_back_detail bd
       where rb.result_back_id=bd.result_back_id
          and rb.request_id = P_REQUEST_ID
          and bd.source_id1 = P_SOURCE_ID1;
    resultBack resultBackCur%ROWTYPE ;

  begin

    --LOOP循环
    OPEN resultBackCur;
     LOOP
       FETCH resultBackCur INTO resultBack;
       EXIT WHEN resultBackCur%NOTFOUND;
       --Dbms_Output.Put_Line(resultBack.error_code || resultBack.error_message);

       --todo,更新接口表处理状态
       if (resultBack.Status='COMPLETED') THEN
           --如果成功，置接口状态为‘S’，返回时间
           update intf_ar_writeoff im
              set im.intf_status = 'S',
                  im.return_date = resultBack.Back_Date
            where
            --im.trx_no = P_REQUEST_ID and
            im.trx_id = P_SOURCE_ID1;
            --where im.trx_no = P_REQUEST_ID and im.receipt_number = resultBack.Source_Id1;
            --where im.RECEIPT_NUMBER =resultBack.;
       else
           --如果失败，置接口状态为‘E’，出错标志为‘Y’，出错信息为error_message，返回时间
           update intf_ar_writeoff im
              set im.intf_status = 'E',im.error_flag='Y',
                  im.err_message = resultBack.Error_Message,
                  im.return_date = resultBack.Back_Date
              where
             --  im.trx_no = P_REQUEST_ID and
               im.trx_id = P_SOURCE_ID1;
            --where im.trx_no = P_REQUEST_ID and im.receipt_number = resultBack.Source_Id1;

       END IF;

     END LOOP;
     CLOSE resultBackCur;
     --置请求为已处理
    -- update t_bd_esb_result_back rb set rb.has_dealed='Y' where rb.request_id=P_REQUEST_ID;
    -- commit;

     exception
        when others then
          P_RETURN_CODE := 'failed';
          P_RETURN_MSG := '回调失败！'||SQLERRM;
  end;

   --采购订单生成
  procedure P_ESB_RESULT_DEAL_63
  (
   P_REQUEST_ID  in  varchar2, --请求ID（交易流水号）
   P_SOURCE_ID1  in  varchar2, --单据来源ID或编码
   P_RETURN_CODE out varchar2, --返回编码,成功：success，失败：failed
   P_RETURN_MSG  out varchar2  --返回信息，成功：执行成功，失败：具体失败信息
   ) is
    --定义变量
    PMT_COUNT NUMBER;--是否推广物料用
    --返回结果列表游标
    cursor resultBackCur is
      select rb.back_date,bd.back_detail_id,
             bd.source_id1,bd.source_id2,bd.source_id3,
             bd.status,bd.error_code,bd.error_message,
             bd.target_id1,bd.target_id2,bd.target_id3
        from t_bd_esb_result_back rb ,t_bd_esb_result_back_detail bd
       where rb.result_back_id = bd.result_back_id
          and rb.request_id = P_REQUEST_ID ;
    resultBack resultBackCur%ROWTYPE ;

  begin

    --LOOP循环
    OPEN resultBackCur;
     LOOP
       FETCH resultBackCur INTO resultBack;
       EXIT WHEN resultBackCur%NOTFOUND;
       --Dbms_Output.Put_Line(resultBack.error_code || resultBack.error_message);

       --todo,更新接口表处理状态
       if (resultBack.Status='COMPLETE') THEN
            --判断是否是推广物料所用单据
            SELECT COUNT(*)
            INTO PMT_COUNT
            FROM T_PMT_ORDER_INV_DETAIL pd
            WHERE pd.po_num = resultBack.Source_Id1;
      
            IF (NVL(PMT_COUNT, 0) = 0) THEN
              --20160906 梁颜明 有时ESB回调比Java后台还快，T_PMT_ORDER_INV_DETAIL的PO单号为空
              SELECT COUNT(0)
                INTO PMT_COUNT
                FROM T_INV_PO_HEADERS PH
               INNER JOIN T_PMT_ORDER_HEADER OH
                  ON (OH.ORDER_HEAD_ID = PH.ORDER_HEADER_ID AND
                     OH.ORDER_NUM = PH.SCHED_ORDER_NUM)
               WHERE PH.PO_NUM = resultBack.Source_Id1;
              IF 0 < PMT_COUNT THEN
                P_RETURN_CODE := 'failed';
                P_RETURN_MSG  := '回调不成功：PO单来源于推广物料采购单，但是发货明细T_PMT_ORDER_INV_DETAIL的PO号字段为空';
                
               --如果失败，置接口状态为‘E’，出错标志为‘Y’，返回时间
                 update INTF_CUX_PO_ORDER icpo
                    set icpo.STATUS_STANDARD = 'E',
                        icpo.ERROR_FLAG = 'Y',
                        icpo.ERROR_MSG = P_RETURN_MSG,
                        icpo.RETURN_DATE = resultBack.Back_Date
                  where icpo.ESB_SERIAL_NUM = P_REQUEST_ID;
                GOTO CLSEND;
              ELSE 
                --成品采购，非推广物料
               update INTF_CUX_PO_ORDER icpo
                  set icpo.STATUS_STANDARD = 'S',
                      icpo.RESPONSE_TYPE = 'N',
                      icpo.RETURN_DATE = resultBack.Back_Date
                where icpo.ESB_SERIAL_NUM = P_REQUEST_ID;
                --更新业务表
               update T_INV_PO_HEADERS tiph
                  set tiph.EBS_DEAL_FLAG_STANDARD = 'Y',
                      tiph.EBS_DEAL_TIME_STANDARD = resultBack.Back_Date
                where tiph.PO_NUM = resultBack.Source_Id1;   
                GOTO CLSEND;  
              END IF;
            END IF;

            IF(PMT_COUNT<>0) THEN
               --是推广物料的单据则需要回写数据
               UPDATE T_PMT_ORDER_INV_DETAIL pd
                 SET pd.Po_Header_Num = resultBack.Target_Id1,
                     pd.Po_Lines_Num = resultBack.Target_Id2
               WHERE pd.Po_Num = resultBack.Source_Id1
                     AND pd.Pmt_Code in (
                         SELECT pol.item
                         FROM INTF_CUX_PO_ORDER_LINES pol
                         WHERE pol.line_num = resultBack.Target_Id2
                               AND pol.header_id in (
                                  SELECT cpo.id
                                  FROM INTF_CUX_PO_ORDER cpo
                                  WHERE cpo.po_number = resultBack.Source_Id1
                               )
                         );
             IF 0 = SQL%ROWCOUNT THEN
                P_RETURN_CODE := 'failed';
                P_RETURN_MSG  := '回调不成功：无法回写T_PMT_ORDER_INV_DETAIL的Po_Header_Num、Po_Lines_Num字段';
                --如果失败，置接口状态为‘E’，出错标志为‘Y’，出错信息为error_message，返回时间
               update INTF_CUX_PO_ORDER icpo
                  set icpo.STATUS_STANDARD = 'E',
                      icpo.ERROR_FLAG = 'Y',
                      icpo.ERROR_MSG = P_RETURN_MSG,
                      icpo.RETURN_DATE = resultBack.Back_Date
                where icpo.ESB_SERIAL_NUM = P_REQUEST_ID;
             ELSE
               --检查完毕才更新
               --如果成功，置接口状态为‘S’，返回时间
               update INTF_CUX_PO_ORDER icpo
                  set icpo.STATUS_STANDARD = 'S',
                      icpo.RESPONSE_TYPE = 'N',
                      icpo.RETURN_DATE = resultBack.Back_Date
                where icpo.ESB_SERIAL_NUM = P_REQUEST_ID;
                --更新业务表
               update T_INV_PO_HEADERS tiph
                  set tiph.EBS_DEAL_FLAG_STANDARD = 'Y',
                      tiph.EBS_DEAL_TIME_STANDARD = resultBack.Back_Date
                where tiph.PO_NUM = resultBack.Source_Id1;
             END IF;
            ELSE
              P_RETURN_CODE := 'failed';
              P_RETURN_MSG  := '回调不成功：发货明细T_PMT_ORDER_INV_DETAIL找不到记录';
              --如果失败，置接口状态为‘E’，出错标志为‘Y’，出错信息为error_message，返回时间
             update INTF_CUX_PO_ORDER icpo
                set icpo.STATUS_STANDARD = 'E',
                    icpo.ERROR_FLAG = 'Y',
                    icpo.ERROR_MSG = P_RETURN_MSG,
                    icpo.RETURN_DATE = resultBack.Back_Date
              where icpo.ESB_SERIAL_NUM = P_REQUEST_ID;
            END IF;
            
           
       else
           --如果失败，置接口状态为‘E’，出错标志为‘Y’，出错信息为error_message，返回时间
           update INTF_CUX_PO_ORDER icpo
              set icpo.STATUS_STANDARD = 'E',
                  icpo.ERROR_FLAG = 'Y',
                  icpo.ERROR_MSG = resultBack.Error_Message,
                  icpo.RETURN_DATE = resultBack.Back_Date
            where icpo.ESB_SERIAL_NUM = P_REQUEST_ID;

       END IF;

     END LOOP;
     <<CLSEND>>
     CLOSE resultBackCur;
     --置请求为已处理
   --  update t_bd_esb_result_back rb set rb.has_dealed='Y' where rb.request_id=P_REQUEST_ID;
   --  commit;

     exception
        when others then
          P_RETURN_CODE := 'failed';
          P_RETURN_MSG := '回调失败！'||SQLERRM;
  end;

  --核销关系（正负发票核销）
  procedure P_ESB_RESULT_DEAL_74
  (
   P_REQUEST_ID  in  varchar2, --请求ID（交易流水号）
   P_SOURCE_ID1  in  varchar2, --单据来源ID或编码
   P_RETURN_CODE out varchar2, --返回编码,成功：success，失败：failed
   P_RETURN_MSG  out varchar2  --返回信息，成功：执行成功，失败：具体失败信息
   ) is
    --返回结果列表游标
    cursor resultBackCur is
      select rb.back_date,bd.back_detail_id,
             bd.source_id1,bd.source_id2,bd.source_id3,
             bd.status,bd.error_code,bd.error_message,
             bd.target_id1,bd.target_id2,bd.target_id3
        from t_bd_esb_result_back rb ,t_bd_esb_result_back_detail bd
       where rb.result_back_id=bd.result_back_id
          and rb.request_id = P_REQUEST_ID;
    resultBack resultBackCur%ROWTYPE ;

  begin

    --LOOP循环
    OPEN resultBackCur;
     LOOP
       FETCH resultBackCur INTO resultBack;
       EXIT WHEN resultBackCur%NOTFOUND;
       --Dbms_Output.Put_Line(resultBack.error_code || resultBack.error_message);

       --todo,更新接口表处理状态
       if (resultBack.Status='COMPLETED') THEN
           --如果成功，置接口状态为‘S’，返回时间
           update intf_ar_writeoff_inv im
              set im.intf_status = 'S',
                  im.return_date = resultBack.Back_Date
            where im.trx_no = P_REQUEST_ID;
            --where im.trx_no = P_REQUEST_ID and im.receipt_number = resultBack.Source_Id1;
            --where im.RECEIPT_NUMBER =resultBack.;
       else
           --如果失败，置接口状态为‘E’，出错标志为‘Y’，出错信息为error_message，返回时间
           update intf_ar_writeoff_inv im
              set im.intf_status = 'E',im.error_flag='Y',
                  im.err_message = resultBack.Error_Message,
                  im.return_date = resultBack.Back_Date
              where im.trx_no = P_REQUEST_ID;
            --where im.trx_no = P_REQUEST_ID and im.receipt_number = resultBack.Source_Id1;

       END IF;

     END LOOP;
     CLOSE resultBackCur;
     --置请求为已处理
    -- update t_bd_esb_result_back rb set rb.has_dealed='Y' where rb.request_id=P_REQUEST_ID;
    -- commit;

     exception
        when others then
          P_RETURN_CODE := 'failed';
          P_RETURN_MSG := '回调失败！'||SQLERRM;
  end;

  --核销关系（正负发票核销）
  procedure P_ESB_RESULT_DEAL_74_1
  (
   P_REQUEST_ID  in  varchar2, --请求ID（交易流水号）
   P_SOURCE_ID1  in  varchar2, --单据来源ID或编码
   P_RETURN_CODE out varchar2, --返回编码,成功：success，失败：failed
   P_RETURN_MSG  out varchar2  --返回信息，成功：执行成功，失败：具体失败信息
   ) is
    --返回结果列表游标
    cursor resultBackCur is
      select rb.back_date,bd.back_detail_id,
             bd.source_id1,bd.source_id2,bd.source_id3,
             bd.status,bd.error_code,bd.error_message,
             bd.target_id1,bd.target_id2,bd.target_id3
        from t_bd_esb_result_back rb ,t_bd_esb_result_back_detail bd
       where rb.result_back_id=bd.result_back_id
          and rb.request_id = P_REQUEST_ID
          and bd.source_id1 = P_SOURCE_ID1;
    resultBack resultBackCur%ROWTYPE ;

  begin

    --LOOP循环
    OPEN resultBackCur;
     LOOP
       FETCH resultBackCur INTO resultBack;
       EXIT WHEN resultBackCur%NOTFOUND;
       --Dbms_Output.Put_Line(resultBack.error_code || resultBack.error_message);

       --todo,更新接口表处理状态
       if (resultBack.Status='COMPLETED') THEN
           --如果成功，置接口状态为‘S’，返回时间
           update intf_ar_writeoff_inv im
              set im.intf_status = 'S',
                  im.return_date = resultBack.Back_Date
            where
            -- im.trx_no = P_REQUEST_ID and
             im.trx_id = P_SOURCE_ID1;
            --where im.trx_no = P_REQUEST_ID and im.receipt_number = resultBack.Source_Id1;
            --where im.RECEIPT_NUMBER =resultBack.;
       else
           --如果失败，置接口状态为‘E’，出错标志为‘Y’，出错信息为error_message，返回时间
           update intf_ar_writeoff_inv im
              set im.intf_status = 'E',im.error_flag='Y',
                  im.err_message = resultBack.Error_Message,
                  im.return_date = resultBack.Back_Date
              where
               --im.trx_no = P_REQUEST_ID and
               im.trx_id = P_SOURCE_ID1;
            --where im.trx_no = P_REQUEST_ID and im.receipt_number = resultBack.Source_Id1;

       END IF;

     END LOOP;
     CLOSE resultBackCur;
     --置请求为已处理
   --  update t_bd_esb_result_back rb set rb.has_dealed='Y' where rb.request_id=P_REQUEST_ID;
    -- commit;

     exception
        when others then
          P_RETURN_CODE := 'failed';
          P_RETURN_MSG := '回调失败！'||SQLERRM;
  end;



  --核销关系（收款发票核销 冲销  ）
  procedure P_ESB_RESULT_DEAL_75
  (
   P_REQUEST_ID  in  varchar2, --请求ID（交易流水号）
   P_SOURCE_ID1  in  varchar2, --单据来源ID或编码
   P_RETURN_CODE out varchar2, --返回编码,成功：success，失败：failed
   P_RETURN_MSG  out varchar2  --返回信息，成功：执行成功，失败：具体失败信息
   ) is
    --返回结果列表游标
    cursor resultBackCur is
      select rb.back_date,bd.back_detail_id,
             bd.source_id1,bd.source_id2,bd.source_id3,
             bd.status,bd.error_code,bd.error_message,
             bd.target_id1,bd.target_id2,bd.target_id3
        from t_bd_esb_result_back rb ,t_bd_esb_result_back_detail bd
       where rb.result_back_id=bd.result_back_id
          and rb.request_id = P_REQUEST_ID
          and bd.source_id1 = P_SOURCE_ID1;
    resultBack resultBackCur%ROWTYPE ;
   N_ORIGINAL_TRX_ID number;
   N_COUNT number;
   N_ORG_ID           number;
   S_RECEIPT_NUMBER       varchar2(30);
   S_TRX_NUMBER    varchar2(30);
  begin

    --LOOP循环
    OPEN resultBackCur;
     LOOP
       FETCH resultBackCur INTO resultBack;
       EXIT WHEN resultBackCur%NOTFOUND;
       --todo,更新接口表处理状态
       if (resultBack.Status='COMPLETED') THEN
           --如果成功，置接口状态为‘S’，返回时间
           update intf_ar_writeoff_un im
              set im.intf_status = 'S',
                  im.return_date = resultBack.Back_Date
            where
             im.trx_id = P_SOURCE_ID1;

          select
             ORIGINAL_TRX_ID
             ,ORG_ID
             ,RECEIPT_NUMBER
             ,TRX_NUMBER
          into
              N_ORIGINAL_TRX_ID
              ,N_ORG_ID
              ,S_RECEIPT_NUMBER
              ,S_TRX_NUMBER
          from  intf_ar_writeoff_un
          where trx_id = P_SOURCE_ID1;

          select
             count(1)
          into
             N_COUNT
          from
            intf_ar_writeoff_un
          where
               intf_status <> 'S'
           and ORG_ID = N_ORG_ID
           and RECEIPT_NUMBER = S_RECEIPT_NUMBER
           and TRX_NUMBER = S_TRX_NUMBER;

           if N_COUNT =0 then
                update
                   intf_ar_writeoff im
                set
                    im.INTF_STATUS='N'
                where
                    im.INTF_STATUS ='Q'
                  and im.org_id = N_ORG_ID
                  and im.TRX_NUMBER= S_TRX_NUMBER
                  and im.receipt_number =  S_RECEIPT_NUMBER ;
           end if;

       else

           if instr(resultBack.error_message,'不存在应付发票')>0 
             or instr(resultBack.error_message,'不存在应收发票')>0 
             then
                      update intf_ar_writeoff_un im
                      set im.intf_status = 'S',im.error_flag='Y',
                          im.err_message = resultBack.Error_Message,
                          im.return_date = resultBack.Back_Date
                      where
                         im.trx_id = P_SOURCE_ID1;

              select
                 ORIGINAL_TRX_ID
                 ,ORG_ID
                 ,RECEIPT_NUMBER
                 ,TRX_NUMBER
              into
                  N_ORIGINAL_TRX_ID
                  ,N_ORG_ID
                  ,S_RECEIPT_NUMBER
                  ,S_TRX_NUMBER
              from  intf_ar_writeoff_un
              where trx_id = P_SOURCE_ID1;

                update
                   intf_ar_writeoff im
                set
                    im.INTF_STATUS='N'
                where
                    im.INTF_STATUS ='Q'
                  and im.org_id = N_ORG_ID
                  and im.TRX_NUMBER= S_TRX_NUMBER
                  and im.receipt_number =  S_RECEIPT_NUMBER ;

                  else
                     update intf_ar_writeoff_un im
                      set im.intf_status = 'E',im.error_flag='Y',
                          im.err_message = resultBack.Error_Message,
                          im.return_date = resultBack.Back_Date
                      where
                         im.trx_id = P_SOURCE_ID1;
                end IF;
       END IF;

     END LOOP;
     CLOSE resultBackCur;

     exception
        when others then
          P_RETURN_CODE := 'failed';
          P_RETURN_MSG := '回调失败！'||SQLERRM;
  end;



  --核销关系（正负 发票核销 冲销  ）
  procedure P_ESB_RESULT_DEAL_76
  (
   P_REQUEST_ID  in  varchar2, --请求ID（交易流水号）
   P_SOURCE_ID1  in  varchar2, --单据来源ID或编码
   P_RETURN_CODE out varchar2, --返回编码,成功：success，失败：failed
   P_RETURN_MSG  out varchar2  --返回信息，成功：执行成功，失败：具体失败信息
   ) is
    --返回结果列表游标
    cursor resultBackCur is
      select rb.back_date,bd.back_detail_id,
             bd.source_id1,bd.source_id2,bd.source_id3,
             bd.status,bd.error_code,bd.error_message,
             bd.target_id1,bd.target_id2,bd.target_id3
        from t_bd_esb_result_back rb ,t_bd_esb_result_back_detail bd
       where rb.result_back_id=bd.result_back_id
          and rb.request_id = P_REQUEST_ID
          and bd.source_id1 = P_SOURCE_ID1;
   resultBack resultBackCur%ROWTYPE ;
   N_ORIGINAL_TRX_ID  number;
   N_COUNT            number;
   N_ORG_ID           number;
   S_INVOICE_TRX_NUMBER       varchar2(30);
   S_CM_TRX_NUMBER    varchar2(30);
  begin

    --LOOP循环
    OPEN resultBackCur;
     LOOP
       FETCH resultBackCur INTO resultBack;
       EXIT WHEN resultBackCur%NOTFOUND;
       --todo,更新接口表处理状态
       if (resultBack.Status='COMPLETED') THEN
           --如果成功，置接口状态为‘S’，返回时间
           update intf_ar_writeoff_inv_un im
           set im.intf_status = 'S',
               im.return_date = resultBack.Back_Date
           where
             im.trx_id = P_SOURCE_ID1;

          select
             ORIGINAL_TRX_ID
             ,TRX_NUMBER
             ,CM_TRX_NUMBER
             ,ORG_ID
          into
              N_ORIGINAL_TRX_ID
              ,S_INVOICE_TRX_NUMBER
              ,S_CM_TRX_NUMBER
              ,N_ORG_ID
          from  intf_ar_writeoff_inv_un
          where trx_id = P_SOURCE_ID1;

          select
             count(1)
          into
             N_COUNT
          from
            intf_ar_writeoff_inv_un
          where
               intf_status <> 'S'
           and ORG_ID = N_ORG_ID
           and TRX_NUMBER = S_INVOICE_TRX_NUMBER
           and CM_TRX_NUMBER = S_CM_TRX_NUMBER;

           if N_COUNT =0 then
              update
                 intf_ar_writeoff_inv im
              set
                 im.INTF_STATUS='N'
              where
                im.intf_status ='Q'
               and im.ORG_ID = N_ORG_ID
               and im.INVOICE_TRX_NUMBER = S_INVOICE_TRX_NUMBER
               and im.CM_TRX_NUMBER = S_CM_TRX_NUMBER;
           end if;

       else

           if  instr(resultBack.error_message,'核销不存在')>0  then

             --如果失败，置接口状态为‘E’，出错标志为‘Y’，出错信息为error_message，返回时间
             update intf_ar_writeoff_inv_un im
              set im.intf_status = 'S',im.error_flag='Y',
                  im.err_message = resultBack.Error_Message,
                  im.return_date = resultBack.Back_Date
              where
               im.trx_id = P_SOURCE_ID1;

             select
               ORIGINAL_TRX_ID
               ,TRX_NUMBER
               ,CM_TRX_NUMBER
               ,ORG_ID
            into
                N_ORIGINAL_TRX_ID
                ,S_INVOICE_TRX_NUMBER
                ,S_CM_TRX_NUMBER
                ,N_ORG_ID
            from  intf_ar_writeoff_inv_un
            where trx_id = P_SOURCE_ID1;

              update
                 intf_ar_writeoff_inv im
              set
                 im.INTF_STATUS='N'
              where
                im.intf_status ='Q'
               and im.ORG_ID = N_ORG_ID
               and im.INVOICE_TRX_NUMBER = S_INVOICE_TRX_NUMBER
               and im.CM_TRX_NUMBER = S_CM_TRX_NUMBER;
           else
              update intf_ar_writeoff_inv_un im
              set im.intf_status = 'E',im.error_flag='Y',
                  im.err_message = resultBack.Error_Message,
                  im.return_date = resultBack.Back_Date
              where
               im.trx_id = P_SOURCE_ID1;
          end IF;

       END IF;

     END LOOP;
     CLOSE resultBackCur;

     exception
        when others then
          P_RETURN_CODE := 'failed';
          P_RETURN_MSG := '回调失败！'||SQLERRM;
  end;
  
  
  
  
   --关联交易开票的接口
  procedure P_ESB_RESULT_DEAL_77
  (
   P_REQUEST_ID  in  varchar2, --请求ID（交易流水号）
   P_SOURCE_ID1  in  varchar2, --单据来源ID或编码
   P_RETURN_CODE out varchar2, --返回编码,成功：success，失败：failed
   P_RETURN_MSG  out varchar2  --返回信息，成功：执行成功，失败：具体失败信息
   ) is
    --返回结果列表游标
    cursor resultBackCur is
      select rb.back_date,bd.back_detail_id,
             bd.source_id1,bd.source_id2,bd.source_id3,
             bd.status,bd.error_code,bd.error_message,
             bd.target_id1,bd.target_id2,bd.target_id3
        from t_bd_esb_result_back rb ,t_bd_esb_result_back_detail bd
       where rb.result_back_id=bd.result_back_id
          and rb.request_id = P_REQUEST_ID
          and bd.source_id1 = P_SOURCE_ID1;
    resultBack resultBackCur%ROWTYPE ;

  begin

    --LOOP循环
    OPEN resultBackCur;
     LOOP
       FETCH resultBackCur INTO resultBack;
       EXIT WHEN resultBackCur%NOTFOUND;
       --更新接口表处理状态
       if (resultBack.Status='COMPLETED') THEN
           --如果成功，置接口状态为‘S’，返回时间
           update INTF_CUX_ICP_INVOICE_REQ_HEAD im
              set im.intf_status = 'S',
                  im.return_date = resultBack.Back_Date,
                  im.REQ_HEADER_ID = resultBack.Target_Id1
            where
             im.SOURCE_NUM = P_SOURCE_ID1;
             
           UPDATE T_SO_TRX_HEADERS 
           SET  REQ_HEADER_ID = RESULTBACK.TARGET_ID1
           WHERE TRX_HEADER_CODE = P_SOURCE_ID1;
             
       else
           --如果失败，置接口状态为‘E’，出错标志为‘Y’，出错信息为error_message，返回时间
           update INTF_CUX_ICP_INVOICE_REQ_HEAD im
              set im.intf_status = 'E',im.error_flag='Y',
                  im.ERROR_MSG = substr(resultBack.Error_Message,1,100),
                  im.return_date = resultBack.Back_Date
              where
               im.SOURCE_NUM = P_SOURCE_ID1;
       END IF;

     END LOOP;
     CLOSE resultBackCur;

     exception
        when others then
          P_RETURN_CODE := 'failed';
          P_RETURN_MSG := '回调失败！'||SQLERRM;
  end;
  
  
  
  
  --关联交易开票  税控的接口
  procedure P_ESB_RESULT_DEAL_78
  (
   P_REQUEST_ID  in  varchar2, --请求ID（交易流水号）
   P_SOURCE_ID1  in  varchar2, --单据来源ID或编码
   P_RETURN_CODE out varchar2, --返回编码,成功：success，失败：failed
   P_RETURN_MSG  out varchar2  --返回信息，成功：执行成功，失败：具体失败信息
   ) is
    --返回结果列表游标
    cursor resultBackCur is
      select rb.back_date,bd.back_detail_id,
             bd.source_id1,bd.source_id2,bd.source_id3,
             bd.status,bd.error_code,bd.error_message,
             bd.target_id1,bd.target_id2,bd.target_id3
        from t_bd_esb_result_back rb ,t_bd_esb_result_back_detail bd
       where rb.result_back_id=bd.result_back_id
          and rb.request_id = P_REQUEST_ID
          and bd.source_id1 = P_SOURCE_ID1;
    resultBack resultBackCur%ROWTYPE ;

  begin

    --LOOP循环
    OPEN resultBackCur;
     LOOP
       FETCH resultBackCur INTO resultBack;
       EXIT WHEN resultBackCur%NOTFOUND;
       --更新接口表处理状态
       if (resultBack.Status='COMPLETED') THEN
           --如果成功，置接口状态为‘S’，返回时间
           update INTF_CUX_ICP_INVOICE_TAX_CONTR im
              set im.intf_status = 'S',
                  im.return_date = resultBack.Back_Date
            where
             im.TRX_ID = P_SOURCE_ID1;
       else
           --如果失败，置接口状态为‘E’，出错标志为‘Y’，出错信息为error_message，返回时间
           update INTF_CUX_ICP_INVOICE_TAX_CONTR im
              set im.intf_status = 'E',im.error_flag='Y',
                  im.ERROR_MSG = substr(resultBack.Error_Message,1,100),
                  im.return_date = resultBack.Back_Date
              where
               im.TRX_ID = P_SOURCE_ID1;
       END IF;

     END LOOP;
     CLOSE resultBackCur;

     exception
        when others then
          P_RETURN_CODE := 'failed';
          P_RETURN_MSG := '回调失败！'||SQLERRM;
  end;
  
  
  
  --关联交易弹性域更新AR的接口
  procedure P_ESB_RESULT_DEAL_79
  (
   P_REQUEST_ID  in  varchar2, --请求ID（交易流水号）
   P_SOURCE_ID1  in  varchar2, --单据来源ID或编码
   P_RETURN_CODE out varchar2, --返回编码,成功：success，失败：failed
   P_RETURN_MSG  out varchar2  --返回信息，成功：执行成功，失败：具体失败信息
   ) is
    --返回结果列表游标
    cursor resultBackCur is
      select rb.back_date,bd.back_detail_id,
             bd.source_id1,bd.source_id2,bd.source_id3,
             bd.status,bd.error_code,bd.error_message,
             bd.target_id1,bd.target_id2,bd.target_id3
        from t_bd_esb_result_back rb ,t_bd_esb_result_back_detail bd
       where rb.result_back_id=bd.result_back_id
          and rb.request_id = P_REQUEST_ID
          and bd.source_id1 = P_SOURCE_ID1;
    resultBack resultBackCur%ROWTYPE ;

  begin

    --LOOP循环
    OPEN resultBackCur;
     LOOP
       FETCH resultBackCur INTO resultBack;
       EXIT WHEN resultBackCur%NOTFOUND;
       --更新接口表处理状态
       if (resultBack.Status='COMPLETED') THEN
           --如果成功，置接口状态为‘S’，返回时间
           update INTF_AR_INVOICE_TRAN_NUM im
              set im.intf_status = 'S',
                  im.return_date = resultBack.Back_Date
            where
             im.TRX_ID = P_SOURCE_ID1;
       else
           --如果失败，置接口状态为‘E’，出错标志为‘Y’，出错信息为error_message，返回时间
           update INTF_AR_INVOICE_TRAN_NUM im
              set im.intf_status = 'E',im.error_flag='Y',
                  im.ERROR_MSG = substr(resultBack.Error_Message,1,100),
                  im.return_date = resultBack.Back_Date
              where
               im.TRX_ID = P_SOURCE_ID1;
       END IF;

     END LOOP;
     CLOSE resultBackCur;

     exception
        when others then
          P_RETURN_CODE := 'failed';
          P_RETURN_MSG := '回调失败！'||SQLERRM;
  end;
  
  
   --关联交易弹性域更新MMT的接口
  procedure P_ESB_RESULT_DEAL_80
  (
   P_REQUEST_ID  in  varchar2, --请求ID（交易流水号）
   P_SOURCE_ID1  in  varchar2, --单据来源ID或编码
   P_RETURN_CODE out varchar2, --返回编码,成功：success，失败：failed
   P_RETURN_MSG  out varchar2  --返回信息，成功：执行成功，失败：具体失败信息
   ) is
    --返回结果列表游标
    cursor resultBackCur is
      select rb.back_date,bd.back_detail_id,
             bd.source_id1,bd.source_id2,bd.source_id3,
             bd.status,bd.error_code,bd.error_message,
             bd.target_id1,bd.target_id2,bd.target_id3
        from t_bd_esb_result_back rb ,t_bd_esb_result_back_detail bd
       where rb.result_back_id=bd.result_back_id
          and rb.request_id = P_REQUEST_ID
          and bd.source_id1 = P_SOURCE_ID1;
    resultBack resultBackCur%ROWTYPE ;

  begin

    --LOOP循环
    OPEN resultBackCur;
     LOOP
       FETCH resultBackCur INTO resultBack;
       EXIT WHEN resultBackCur%NOTFOUND;
       --更新接口表处理状态
       if (resultBack.Status='COMPLETED') THEN
           --如果成功，置接口状态为‘S’，返回时间
           update INTF_INV_TRANSACTION_TRAN_NUM im
              set im.intf_status = 'S',
                  im.return_date = resultBack.Back_Date
            where
             im.TRX_ID = P_SOURCE_ID1;
       else
           --如果失败，置接口状态为‘E’，出错标志为‘Y’，出错信息为error_message，返回时间
           update INTF_INV_TRANSACTION_TRAN_NUM im
              set im.intf_status = 'E',im.error_flag='Y',
                  im.ERROR_MSG = substr(resultBack.Error_Message,1,100),
                  im.return_date = resultBack.Back_Date
              where
               im.TRX_ID = P_SOURCE_ID1;
       END IF;

     END LOOP;
     CLOSE resultBackCur;

     exception
        when others then
          P_RETURN_CODE := 'failed';
          P_RETURN_MSG := '回调失败！'||SQLERRM;
  end;
 
    --NC采购单、盘点单回调接口处理
  procedure P_ESB_RESULT_DEAL_81
  (
   P_REQUEST_ID  in  varchar2, --请求ID（交易流水号）
   P_SOURCE_ID1  in  varchar2, --单据来源ID或编码
   P_RETURN_CODE out varchar2, --返回编码,成功：success，失败：failed
   P_RETURN_MSG  out varchar2  --返回信息，成功：执行成功，失败：具体失败信息
   ) is
    --返回结果列表游标
    cursor resultBackCur is
      select rb.back_date,bd.back_detail_id,
             bd.source_id1,bd.source_id2,bd.source_id3,
             bd.status,bd.error_code,bd.error_message,
             bd.target_id1,bd.target_id2,bd.target_id3
        from t_bd_esb_result_back rb ,t_bd_esb_result_back_detail bd
       where rb.result_back_id=bd.result_back_id
          and rb.request_id = P_REQUEST_ID
          and bd.source_id1 = P_SOURCE_ID1;
    resultBack resultBackCur%ROWTYPE ;

  begin

    --LOOP循环
    OPEN resultBackCur;
     LOOP
       FETCH resultBackCur INTO resultBack;
       EXIT WHEN resultBackCur%NOTFOUND;
       --更新接口表处理状态
       if (resultBack.Status='COMPLETED') THEN
           --如果成功，置接口状态为‘S’，返回时间
           update INTF_NC_INV_HEADER NH
              set NH.intf_status = 'S',
                  NH.return_date = resultBack.Back_Date
            where
             NH.ORDER_NUM = P_SOURCE_ID1;
       else
           --如果失败，置接口状态为‘E’，出错标志为‘Y’，出错信息为error_message，返回时间
           update INTF_NC_INV_HEADER NH
              set NH.intf_status = 'E',NH.error_flag='Y',
                  NH.ERROR_MSG = substr(resultBack.Error_Message,1,100),
                  NH.return_date = resultBack.Back_Date
              where
               NH.ORDER_NUM = P_SOURCE_ID1;
       END IF;

     END LOOP;
     CLOSE resultBackCur;

     exception
        when others then
          P_RETURN_CODE := 'failed';
          P_RETURN_MSG := '回调失败！'||SQLERRM;
  end;
  
  ------------------------------------------------------------------------------- 
  /*
  *   创建日期：2017-04-25
  *     创建者：周建刚
  *   功能说明：销售成本NC接口,异步回调结果处理
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_ESB_RESULT_DEAL_82
  (
   P_REQUEST_ID  IN  VARCHAR2, --请求ID（交易流水号）
   P_SOURCE_ID1  IN  VARCHAR2, --单据来源ID或编码
   P_RETURN_CODE OUT VARCHAR2, --返回编码,成功：SUCCESS，失败：FAILED
   P_RETURN_MSG  OUT VARCHAR2  --返回信息，成功：执行成功，失败：具体失败信息
   ) IS
    --返回结果列表游标
    CURSOR RESULTBACKCUR IS
      SELECT RB.BACK_DATE,BD.BACK_DETAIL_ID,
             BD.SOURCE_ID1,BD.SOURCE_ID2,BD.SOURCE_ID3,
             BD.STATUS,BD.ERROR_CODE,BD.ERROR_MESSAGE,
             BD.TARGET_ID1,BD.TARGET_ID2,BD.TARGET_ID3
        FROM T_BD_ESB_RESULT_BACK RB ,T_BD_ESB_RESULT_BACK_DETAIL BD
       WHERE RB.RESULT_BACK_ID=BD.RESULT_BACK_ID
          AND RB.REQUEST_ID = P_REQUEST_ID
          AND BD.SOURCE_ID1 = P_SOURCE_ID1;
    RESULTBACK RESULTBACKCUR%ROWTYPE ;

  BEGIN

    --LOOP循环
    OPEN RESULTBACKCUR;
     LOOP
       FETCH RESULTBACKCUR INTO RESULTBACK;
       EXIT WHEN RESULTBACKCUR%NOTFOUND;
       --更新接口表处理状态
       IF (RESULTBACK.STATUS='COMPLETED') THEN
           --如果成功，置接口状态为‘S’，返回时间
           UPDATE INTF_NC_SO_HEADER H
              SET H.INTF_SALE_COST_STATUS       = 'S',
                  H.INTF_SALE_COST_RETURN_DATE  = RESULTBACK.BACK_DATE,
                  H.INTF_SALE_COST_MSG          = 'SUCCESS',
                  H.INTF_SALE_COST_NC_BILL_NUM  = RESULTBACK.TARGET_ID1,
                  H.INTF_SALE_COST_POST_TIMES   = NVL(H.INTF_SALE_COST_POST_TIMES,0) + 1,
                  H.LAST_UPDATE_DATE            = SYSDATE,
                  H.LAST_UPDATED_BY             = 'NC'
            WHERE H.SO_NUM = P_SOURCE_ID1;
       ELSE
           --如果失败，置接口状态为‘E’，出错标志为‘Y’，出错信息为ERROR_MESSAGE，返回时间
           UPDATE INTF_NC_SO_HEADER H
              SET H.INTF_SALE_COST_STATUS       = 'E',
                  H.INTF_SALE_COST_RETURN_DATE  = RESULTBACK.BACK_DATE,
                  H.INTF_SALE_COST_MSG          = SUBSTR(RESULTBACK.ERROR_MESSAGE,1,100),
                  H.INTF_SALE_COST_POST_TIMES   = NVL(H.INTF_SALE_COST_POST_TIMES,0) + 1,
                  H.LAST_UPDATE_DATE            = SYSDATE,
                  H.LAST_UPDATED_BY             = 'NC'
            WHERE H.SO_NUM = P_SOURCE_ID1;
       END IF;

     END LOOP;
     CLOSE RESULTBACKCUR;

  EXCEPTION
    WHEN OTHERS THEN
      P_RETURN_CODE := 'failed';
      P_RETURN_MSG := '回调失败！流水[' || P_REQUEST_ID || '],P_SOURCE_ID1[' || P_SOURCE_ID1 || ']' ||SQLERRM;
  END;
  -------------------------------------------------------------------------------
  
  ------------------------------------------------------------------------------- 
  /*
  *   创建日期：2017-04-25
  *     创建者：周建刚
  *   功能说明：销售收入凭证NC接口,异步回调结果处理
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_ESB_RESULT_DEAL_83
  (
   P_REQUEST_ID  IN  VARCHAR2, --请求ID（交易流水号）
   P_SOURCE_ID1  IN  VARCHAR2, --单据来源ID或编码
   P_RETURN_CODE OUT VARCHAR2, --返回编码,成功：SUCCESS，失败：FAILED
   P_RETURN_MSG  OUT VARCHAR2  --返回信息，成功：执行成功，失败：具体失败信息
   ) IS
    --返回结果列表游标
    CURSOR RESULTBACKCUR IS
      SELECT RB.BACK_DATE,BD.BACK_DETAIL_ID,
             BD.SOURCE_ID1,BD.SOURCE_ID2,BD.SOURCE_ID3,
             BD.STATUS,BD.ERROR_CODE,BD.ERROR_MESSAGE,
             BD.TARGET_ID1,BD.TARGET_ID2,BD.TARGET_ID3
        FROM T_BD_ESB_RESULT_BACK RB ,T_BD_ESB_RESULT_BACK_DETAIL BD
       WHERE RB.RESULT_BACK_ID=BD.RESULT_BACK_ID
          AND RB.REQUEST_ID = P_REQUEST_ID
          AND BD.SOURCE_ID1 = P_SOURCE_ID1;
    RESULTBACK RESULTBACKCUR%ROWTYPE ;

  BEGIN

    --LOOP循环
    OPEN RESULTBACKCUR;
     LOOP
       FETCH RESULTBACKCUR INTO RESULTBACK;
       EXIT WHEN RESULTBACKCUR%NOTFOUND;
       --更新接口表处理状态
       IF (RESULTBACK.STATUS='COMPLETED') THEN
           --如果成功，置接口状态为‘S’，返回时间
           UPDATE INTF_NC_SO_HEADER H
              SET H.INTF_SALE_INCOME_STATUS      = 'S',
                  H.INTF_SALE_INCOME_RETURN_DATE = RESULTBACK.BACK_DATE,
                  H.INTF_SALE_INCOME_MSG         = 'SUCCESS',
                  H.INTF_SALE_INCOME_NC_BILL_NUM = RESULTBACK.TARGET_ID1,
                  H.INTF_SALE_INCOME_POST_TIMES  = NVL(H.INTF_SALE_INCOME_POST_TIMES,0) + 1,
                  H.LAST_UPDATE_DATE             = SYSDATE,
                  H.LAST_UPDATED_BY              = 'NC'
            WHERE H.SO_NUM = P_SOURCE_ID1;
       ELSE
           --如果失败，置接口状态为‘E’，出错标志为‘Y’，出错信息为ERROR_MESSAGE，返回时间
           UPDATE INTF_NC_SO_HEADER H
              SET H.INTF_SALE_INCOME_STATUS      = 'E',
                  H.INTF_SALE_INCOME_RETURN_DATE = RESULTBACK.BACK_DATE,
                  H.INTF_SALE_INCOME_MSG         = SUBSTR(RESULTBACK.ERROR_MESSAGE,1,100),
                  H.INTF_SALE_INCOME_POST_TIMES  = NVL(H.INTF_SALE_INCOME_POST_TIMES,0) + 1,
                  H.LAST_UPDATE_DATE             = SYSDATE,
                  H.LAST_UPDATED_BY              = 'NC'
            WHERE H.SO_NUM = P_SOURCE_ID1;
       END IF;

     END LOOP;
     CLOSE RESULTBACKCUR;

  EXCEPTION
    WHEN OTHERS THEN
      P_RETURN_CODE := 'failed';
      P_RETURN_MSG := '回调失败！流水[' || P_REQUEST_ID || '],P_SOURCE_ID1[' || P_SOURCE_ID1 || ']' ||SQLERRM;
  END;
  -------------------------------------------------------------------------------

  --关联交易订单、关联交易物流
  procedure P_ESB_RESULT_DEAL_CIMS
  (
   P_REQUEST_ID  in  varchar2, --请求ID（交易流水号）
   P_SOURCE_ID1  in  varchar2, --单据来源ID或编码
   P_RETURN_CODE out varchar2, --返回编码,成功：success，失败：failed
   P_RETURN_MSG  out varchar2  --返回信息，成功：执行成功，失败：具体失败信息
   ) is
    --返回结果列表游标
    cursor resultBackCur is
      select rb.back_date,bd.back_detail_id,
             bd.source_id1,bd.source_id2,bd.source_id3,
             bd.status,bd.error_code,bd.error_message,
             bd.target_id1,bd.target_id2,bd.target_id3
        from t_bd_esb_result_back rb ,t_bd_esb_result_back_detail bd
       where rb.result_back_id = bd.result_back_id
          and rb.request_id = P_REQUEST_ID ;
    resultBack resultBackCur%ROWTYPE ;
    --关联交易订单、关联交易物流判断标志
    o_amount NUMBER;
    l_amount NUMBER;
  begin
    select count(*) into o_amount from INTF_CUX_ICP_ORDER_REQ_HEADERS where ESB_SERIAL_NUM = P_REQUEST_ID;
    select count(*) into l_amount from INTF_CUX_ICP_LOGIST_REQ_HEADER where ESB_SERIAL_NUM_SEND = P_REQUEST_ID;
    --LOOP循环
    OPEN resultBackCur;
     LOOP
       FETCH resultBackCur INTO resultBack;
       EXIT WHEN resultBackCur%NOTFOUND;
       --Dbms_Output.Put_Line(resultBack.error_code || resultBack.error_message);

       --todo,更新接口表处理状态
       if (resultBack.Status='COMPLETED') THEN
         --如果成功，置接口状态为‘S’，返回时间
	       begin
	       	if(o_amount > 0) THEN
	        	update INTF_CUX_ICP_ORDER_REQ_HEADERS o
	            set o.STATUS = 'S',
	                o.RETURN_DATE = resultBack.Back_Date
	          where o.ESB_SERIAL_NUM = P_REQUEST_ID;
            --更新业务表
            update T_INV_PO_HEADERS tiph
              set tiph.ERP_TRANS_FLAG = 'Y',
                  tiph.ERP_TRANS_TIME = resultBack.Back_Date
            where tiph.PO_NUM = resultBack.Source_Id1;

            --add by chen.wj 20150205 关联订单成功就触发回调
            pkg_so_rt.P_ORDER_WRITE_BACK(resultBack.Source_Id1);

	        elsif(l_amount > 0) THEN
        		update INTF_CUX_ICP_LOGIST_REQ_HEADER l
              set l.STATUS = 'S',
                  l.RETURN_DATE_SEND = resultBack.Back_Date
          	where l.ESB_SERIAL_NUM_SEND = P_REQUEST_ID;
            --更新业务表
            update T_INV_PO_HEADERS tiph
              set tiph.EBS_DEAL_FLAG = 'Y',
                  tiph.EBS_DEAL_TIME = resultBack.Back_Date
            where tiph.PO_NUM = resultBack.Source_Id1;

            --add by chen.wj 20150205 不管有没有关联订单，只要物流订单成功就触发回调
            pkg_so_rt.P_LOGIST_WRITE_BACK(resultBack.Source_Id1);
          ELSE
            update INTF_CUX_ICP_LOGIST_REQ_HEADER l
              set l.STATUS = 'S',
                  l.RETURN_DATE_REV = resultBack.Back_Date
          	where l.ESB_SERIAL_NUM_REV = P_REQUEST_ID;
            --更新业务表
            update T_INV_PO_HEADERS tiph
              set tiph.EBS_DEAL_FLAG_REV = 'Y',
                  tiph.EBS_DEAL_TIME_REV = resultBack.Back_Date
            where tiph.PO_NUM = resultBack.Source_Id1;
        	end if;
      	 end;
       elsif(o_amount > 0) THEN
          --如果失败，置接口状态为‘E’，出错标志为‘Y’，出错信息为error_message，返回时间
	      	update INTF_CUX_ICP_ORDER_REQ_HEADERS o
		        set o.STATUS = 'E',
		            o.ERROR_FLAG = 'Y',
		            o.ERROR_MSG = resultBack.Error_Message,
		            o.RETURN_DATE = resultBack.Back_Date
	        where o.ESB_SERIAL_NUM = P_REQUEST_ID;
		      elsif(l_amount > 0) THEN
	      		update INTF_CUX_ICP_LOGIST_REQ_HEADER l
	            set l.STATUS = 'E',
	                l.ERROR_FLAG_SEND = 'Y',
	                l.ERROR_MSG_SEND = resultBack.Error_Message,
	                l.RETURN_DATE_SEND = resultBack.Back_Date
	        	where l.ESB_SERIAL_NUM_SEND = P_REQUEST_ID;
	        else
		        update INTF_CUX_ICP_LOGIST_REQ_HEADER l
		          set l.STATUS = 'E',
		              l.ERROR_FLAG_REV = 'Y',
		              l.ERROR_MSG_REV = resultBack.Error_Message,
		              l.RETURN_DATE_REV = resultBack.Back_Date
		      	where l.ESB_SERIAL_NUM_REV = P_REQUEST_ID;
	     end if;
     END LOOP;
     CLOSE resultBackCur;
     --置请求为已处理
     --update t_bd_esb_result_back rb set rb.has_dealed='Y' where rb.request_id=P_REQUEST_ID;
    -- commit;

     exception
        when others then
          P_RETURN_CODE := 'failed';
          P_RETURN_MSG := '回调失败！'||SQLERRM;
  end;
     
  ------------------------------------------------------------------------------- 
  /*
  *   创建日期：2017-05-09
  *     创建者：tianmzh
  *   功能说明：财务转款凭证NC接口,异步回调结果处理
  */
  -------------------------------------------------------------------------------
   PROCEDURE P_ESB_RESULT_DEAL_84
  (
   P_REQUEST_ID  IN  VARCHAR2, --请求ID（交易流水号）
   P_SOURCE_ID1  IN  VARCHAR2, --单据来源ID或编码
   P_RETURN_CODE OUT VARCHAR2, --返回编码,成功：SUCCESS，失败：FAILED
   P_RETURN_MSG  OUT VARCHAR2  --返回信息，成功：执行成功，失败：具体失败信息
   ) IS
    --返回结果列表游标
    CURSOR RESULTBACKCUR IS
      SELECT RB.BACK_DATE,BD.BACK_DETAIL_ID,RB.DATA_SOURCE,
             BD.SOURCE_ID1,BD.SOURCE_ID2,BD.SOURCE_ID3,
             BD.STATUS,BD.ERROR_CODE,BD.ERROR_MESSAGE,
             BD.TARGET_ID1,BD.TARGET_ID2,BD.TARGET_ID3
        FROM T_BD_ESB_RESULT_BACK RB ,T_BD_ESB_RESULT_BACK_DETAIL BD
       WHERE RB.RESULT_BACK_ID=BD.RESULT_BACK_ID
          AND RB.REQUEST_ID = P_REQUEST_ID
          AND BD.SOURCE_ID1 = P_SOURCE_ID1;
    RESULTBACK RESULTBACKCUR%ROWTYPE ;

  BEGIN

    --LOOP循环
    OPEN RESULTBACKCUR;
     LOOP
       FETCH RESULTBACKCUR INTO RESULTBACK;
       EXIT WHEN RESULTBACKCUR%NOTFOUND;
       --更新接口表处理状态
       IF (RESULTBACK.STATUS='COMPLETED') THEN
           --如果成功，置接口状态为‘S’，返回时间
           
           UPDATE CIMS.INTF_NC_CASH_RECEIPT H
              SET H.INTF_STATUS      = 'S',
                  H.RETURN_DATE = RESULTBACK.BACK_DATE,
                  H.RESPONSE_MESSAGE         = 'SUCCESS',
                  --2017-08-16 TIANMZH ADD
                  H.NC_RECEIPT_CODE = RESULTBACK.TARGET_ID1
            WHERE H.DEF1 = P_SOURCE_ID1;
            
          IF RESULTBACK.DATA_SOURCE = 'CIMS-NC-014'   THEN
               UPDATE T_AR_CASH_RECEIPT_HEADERS 
                  SET INTO_GTMS_STATUS=0
                     ,INTO_GTMS_DATE = SYSDATE
                     ,GTMS_RECEIPT_CODE = RESULTBACK.TARGET_ID1
                 WHERE CASH_TURNFEE_ID IN(
                    SELECT 
                       CASH_TURNFEE_ID
                     FROM 
                        T_AR_CASH_TURNFEE_HEADER 
                    WHERE
                      CASH_TURNFEE_CODE = P_SOURCE_ID1
                 );
          ELSE
              UPDATE T_AR_CASH_RECEIPT_HEADERS 
                  SET INTO_GTMS_STATUS=0
                     ,INTO_GTMS_DATE = SYSDATE
                     ,GTMS_RECEIPT_CODE = RESULTBACK.TARGET_ID1
                WHERE CASH_RECEIPT_CODE = P_SOURCE_ID1;
                         
          END IF; 
      
       ELSE
           --如果失败，置接口状态为‘E’，出错标志为‘Y’，出错信息为ERROR_MESSAGE，返回时间
           UPDATE INTF_NC_CASH_RECEIPT H
              SET H.INTF_STATUS      = 'E',
                  H.RETURN_DATE = RESULTBACK.BACK_DATE,
                  H.RESPONSE_MESSAGE         = SUBSTR(RESULTBACK.ERROR_MESSAGE,1,100)
            WHERE H.DEF1 = P_SOURCE_ID1;
            
         IF RESULTBACK.DATA_SOURCE = 'CIMS-NC-014'   THEN
               UPDATE T_AR_CASH_RECEIPT_HEADERS 
                  SET INTO_GTMS_STATUS=1
                     ,INTO_GTMS_DATE = SYSDATE
                     ,INTO_GTMS_ERROR = SUBSTR(RESULTBACK.ERROR_MESSAGE,1,100)
                 WHERE CASH_TURNFEE_ID IN(
                    SELECT 
                       CASH_TURNFEE_ID
                     FROM 
                        T_AR_CASH_TURNFEE_HEADER 
                    WHERE
                      CASH_TURNFEE_CODE = P_SOURCE_ID1
                 );
          ELSE
              UPDATE T_AR_CASH_RECEIPT_HEADERS 
                  SET INTO_GTMS_STATUS=0
                     ,INTO_GTMS_DATE = SYSDATE
                     ,INTO_GTMS_ERROR = SUBSTR(RESULTBACK.ERROR_MESSAGE,1,100)
                WHERE CASH_RECEIPT_CODE = P_SOURCE_ID1;
                         
          END IF; 
            
       END IF;

     END LOOP;
     CLOSE RESULTBACKCUR;

  EXCEPTION
    WHEN OTHERS THEN
      P_RETURN_CODE := 'failed';
      P_RETURN_MSG := '回调失败！流水[' || P_REQUEST_ID || '],P_SOURCE_ID1[' || P_SOURCE_ID1 || ']' ||SQLERRM;
  END;
  
  
     
  ------------------------------------------------------------------------------- 
  /*
  *   创建日期：2017-06-08
  *     创建者：guibr
  *   功能说明：NC退款申请状态更新
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_ESB_RESULT_DEAL_85
  (
     P_REQUEST_ID  IN  VARCHAR2, --请求ID（交易流水号）
     P_SOURCE_ID1  IN  VARCHAR2, --单据来源ID或编码
     P_RETURN_CODE OUT VARCHAR2, --返回编码,成功：SUCCESS，失败：FAILED
     P_RETURN_MSG  OUT VARCHAR2  --返回信息，成功：执行成功，失败：具体失败信息
   )is
    --返回结果列表游标
    cursor resultBackCur is
      select rb.back_date,bd.back_detail_id,
             bd.source_id1,bd.source_id2,bd.source_id3,
             bd.status,bd.error_code,bd.error_message,
             bd.target_id1,bd.target_id2,bd.target_id3
        from t_bd_esb_result_back rb ,t_bd_esb_result_back_detail bd
       where rb.result_back_id=bd.result_back_id
          and rb.request_id = P_REQUEST_ID
          and bd.source_id1 = P_SOURCE_ID1;
    resultBack resultBackCur%ROWTYPE ;

    R_AR_REFUND_APPLY_HEADERS T_AR_REFUND_APPLY_HEADERS%ROWTYPE;

  begin

    --LOOP循环
    OPEN resultBackCur;
     LOOP
       FETCH resultBackCur INTO resultBack;
       EXIT WHEN resultBackCur%NOTFOUND;
       --更新接口表处理状态
       if (resultBack.Status='COMPLETED') THEN
            UPDATE T_AR_REFUND_APPLY_HEADERS 
             SET  INTO_NC_STATUS = RESULTBACK.TARGET_ID2
                 ,INTO_NC_CODE = RESULTBACK.TARGET_ID1
                 ,INTO_GTMS_STATUS =  RESULTBACK.TARGET_ID2
                 ,GTMS_RECEIPT_CODE =  RESULTBACK.TARGET_ID1
                 ,OUT_GTMS_DATE = SYSDATE
                 ,UPDATED_DATE = SYSDATE
             WHERE REFUND_APPLY_CODE = P_SOURCE_ID1;   
             
             UPDATE T_AR_CASH_RECEIPT_HEADERS 
             SET GTMS_RECEIPT_CODE =   RESULTBACK.TARGET_ID1
                , INTO_GTMS_STATUS =RESULTBACK.TARGET_ID2 
             WHERE REFUND_APPLY_ID IN (SELECT REFUND_APPLY_ID
                  FROM 
                    T_AR_REFUND_APPLY_HEADERS 
                  WHERE  REFUND_APPLY_CODE=  P_SOURCE_ID1
             );
             --当推送成功的时候，对于网批项目的退款单，当NC退款成功INTO_NC_STATUS-ar_into_erp 24退款成功,更新推送ccs接口 add by huanghb12
             IF('24' = RESULTBACK.TARGET_ID2) THEN
                SELECT H.*
                   INTO R_AR_REFUND_APPLY_HEADERS
                  FROM CIMS.T_AR_REFUND_APPLY_HEADERS H
                  WHERE H.REFUND_APPLY_CODE=  P_SOURCE_ID1;
                --如果是‘15’-网批项目的退款
                IF('15' = R_AR_REFUND_APPLY_HEADERS.ATTRIBUTE5)THEN
                   UPDATE INTF_CCS_SO_HEADER IH
                     SET IH.INTF_STATUS = 'N'
                         ,IH.AR_REFUND_AMOUNT = ABS(R_AR_REFUND_APPLY_HEADERS.AMOUNT)
                         ,IH.AR_RECEIPT_BANK_ACCOUNT = R_AR_REFUND_APPLY_HEADERS.RECEIPT_BANK_ACCOUNT
                         ,IH.AR_OUT_GTMS_DATE = R_AR_REFUND_APPLY_HEADERS.OUT_GTMS_DATE
                         ,IH.LAST_UPDATED_BY = 'NC'
                         ,IH.LAST_UPDATE_DATE = SYSDATE
                     WHERE IH.SO_NUM = R_AR_REFUND_APPLY_HEADERS.ATTRIBUTE4
                       AND IH.INTF_STATUS = 'WAIT';
                END IF;
             END IF; 
             --end by huanghb12   
               
       else
            UPDATE T_AR_REFUND_APPLY_HEADERS 
             SET  INTO_NC_STATUS = RESULTBACK.TARGET_ID2
                 ,INTO_NC_CODE = RESULTBACK.TARGET_ID1
                 ,INTO_GTMS_STATUS =  RESULTBACK.TARGET_ID2
                 ,GTMS_RECEIPT_CODE =  RESULTBACK.TARGET_ID1
             WHERE REFUND_APPLY_CODE = P_SOURCE_ID1;
             
             UPDATE T_AR_CASH_RECEIPT_HEADERS 
             SET GTMS_RECEIPT_CODE =   RESULTBACK.TARGET_ID1
                 ,INTO_GTMS_STATUS =RESULTBACK.TARGET_ID2 
             WHERE REFUND_APPLY_ID IN (SELECT 
                     REFUND_APPLY_ID
                  FROM 
                    T_AR_REFUND_APPLY_HEADERS 
                  WHERE  REFUND_APPLY_CODE=  P_SOURCE_ID1
             );     
       END IF;

     END LOOP;
     CLOSE resultBackCur;

     exception
        when others then
          P_RETURN_CODE := 'failed';
          P_RETURN_MSG := '回调失败！'||SQLERRM;
  end;
  
  
  
   
  ------------------------------------------------------------------------------- 
  /*
  *   创建日期：2017-06-18
  *     创建者：guibr
  *   功能说明：NC收款状态更新
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_ESB_RESULT_DEAL_86
  (
     P_REQUEST_ID  IN  VARCHAR2, --请求ID（交易流水号）
     P_SOURCE_ID1  IN  VARCHAR2, --单据来源ID或编码
     P_RETURN_CODE OUT VARCHAR2, --返回编码,成功：SUCCESS，失败：FAILED
     P_RETURN_MSG  OUT VARCHAR2  --返回信息，成功：执行成功，失败：具体失败信息
   )is
    --返回结果列表游标
    cursor resultBackCur is
      select rb.back_date,bd.back_detail_id,
             bd.source_id1,bd.source_id2,bd.source_id3,
             bd.status,bd.error_code,bd.error_message,
             bd.target_id1,bd.target_id2,bd.target_id3
        from t_bd_esb_result_back rb ,t_bd_esb_result_back_detail bd
       where rb.result_back_id=bd.result_back_id
          and rb.request_id = P_REQUEST_ID
          and bd.source_id1 = P_SOURCE_ID1;
    resultBack resultBackCur%ROWTYPE ;

  begin

    --LOOP循环
    OPEN resultBackCur;
     LOOP
       FETCH resultBackCur INTO resultBack;
       EXIT WHEN resultBackCur%NOTFOUND;
       --更新接口表处理状态
       if (resultBack.Status='COMPLETED') THEN
             UPDATE T_AR_CASH_RECEIPT_HEADERS T
              SET T.UPDATED_DATE = SYSDATE
                 ,T.GTMS_SIGN_TIME = to_date(to_char(sysdate,'yyyy-mm-dd'),'yyyy-mm-dd')
                 ,T.RECEIPT_STATUS_ID = 6
             WHERE   T.RECEIPT_STATUS_ID<>16
                AND  T.CASH_RECEIPT_CODE =  P_SOURCE_ID1    ;
       else
            UPDATE T_AR_CASH_RECEIPT_HEADERS T
              SET T.UPDATED_DATE = SYSDATE
                 ,T.GTMS_SIGN_TIME = to_date(to_char(sysdate,'yyyy-mm-dd'),'yyyy-mm-dd')
                 ,T.RECEIPT_STATUS_ID = 6
            WHERE  T.RECEIPT_STATUS_ID<>16
                AND  T.CASH_RECEIPT_CODE =  P_SOURCE_ID1  ;
       END IF;

     END LOOP;
     CLOSE resultBackCur;

     exception
        when others then
          P_RETURN_CODE := 'failed';
          P_RETURN_MSG := '回调失败！'||SQLERRM;
  end;
  
  
  ------------------------------------------------------------------------------- 
  /*
  *   创建日期：2018-05-25
  *   创建者：huanghb12
  *   功能说明：异步推送产品编码至ERP接口成功回调
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_ESB_RESULT_DEAL_87
  (
     P_REQUEST_ID  IN  VARCHAR2, --请求ID（交易流水号）
     P_SOURCE_ID1  IN  VARCHAR2, --单据来源ID或编码
     P_RETURN_CODE OUT VARCHAR2, --返回编码,成功：SUCCESS，失败：FAILED
     P_RETURN_MSG  OUT VARCHAR2  --返回信息，成功：执行成功，失败：具体失败信息
   )is

  begin
    MERGE INTO CIMS.INTF_ITEM_TO_ERP TL
    USING (
           --查询本批次代码，一条一条数据去处理
           SELECT T1.REQUEST_ID,T1.SOURCE_ID1,T1.STATUS,T1.ERROR_CODE,T1.ERROR_MESSAGE
            FROM CIMS.T_BD_ESB_RESULT_BACK_DETAIL T1
            INNER JOIN CIMS.T_BD_ESB_RESULT_BACK T2
            ON T1.RESULT_BACK_ID = T2.RESULT_BACK_ID
            WHERE T2.REQUEST_ID = P_REQUEST_ID
            AND T1.SOURCE_ID1 = P_SOURCE_ID1
            ) UT
    ON (TL.TRX_NO = UT.REQUEST_ID AND TL.ITEM_ID = UT.SOURCE_ID1)
    WHEN MATCHED THEN
      UPDATE --推送产品编码成功之后，将接口状态改为'P'表示已经推送成功但是不确定插入是否成功的数据；
         SET TL.INTF_STATUS = DECODE(UT.STATUS,'COMPLETED','S','ERROR','E'),
             --TL.ERROR_FLAG = UT.ERROR_CODE,
             TL.ERROR_MSG = UT.ERROR_MESSAGE
         WHERE TL.INTF_STATUS = 'P';
  exception
    when others then
      P_RETURN_CODE := 'failed';
      P_RETURN_MSG := '回调失败！'||SQLERRM;
  end; 
  
  ------------------------------------------------------------------------------- 
  /*
  *   创建日期：2019-05-25
  *   创建者：LILH6
  *   功能说明：提货订单OEM产品触发送货通知接口成功回调
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_ESB_RESULT_DEAL_88
  (
     P_REQUEST_ID  IN  VARCHAR2, --请求ID（交易流水号）
     P_SOURCE_ID1  IN  VARCHAR2, --单据来源ID或编码
     P_RETURN_CODE OUT VARCHAR2, --返回编码,成功：SUCCESS，失败：FAILED
     P_RETURN_MSG  OUT VARCHAR2  --返回信息，成功：执行成功，失败：具体失败信息
   )Is
   v_status          VARCHAR2(32); --处理状态
   v_error_message   varchar2(4000); --错误信息

  Begin
    If P_SOURCE_ID1 Is Null Then
      --P_SOURCE_ID1为空，表示数据全部处理成功
      --更新触发送货通知接口的异常信息
          Update Intf_Pln_Scp_Data_Import i
             Set i.Intf_Msg         = 'COMPLETED',
                 i.Last_Updated_By  = 'P_ESB_RESULT_DEAL_88',
                 i.Last_Update_Date = Sysdate
           Where i.Intf_Serial_Num = p_Request_Id;
    Else
      --P_SOURCE_ID1不为空，则表示数据有错误
      Begin
        Select d.Status,d.error_message
          Into v_Status,v_error_message
          From t_Bd_Esb_Result_Back_Detail d
         Where d.Source_Id1 = p_Source_Id1
           And d.Request_Id = p_Request_Id;
        If nvl(v_Status,'_') <> 'COMPLETED' Then
          --更新触发送货通知接口的异常信息
          Update Intf_Pln_Scp_Data_Import i
             Set i.Intf_Status      = 'W',
                 i.Intf_Msg         = v_Error_Message,
                 i.Last_Updated_By  = 'P_ESB_RESULT_DEAL_88',
                 i.Last_Update_Date = Sysdate
           Where i.Identifying_Code = p_Source_Id1
             And i.Intf_Serial_Num = p_Request_Id;
        End If;
      Exception
        When Others Then
          Null;  
      End;
    End If;
  exception
    when others then
      P_RETURN_CODE := 'failed';
      P_RETURN_MSG := '回调失败！'||SQLERRM;
  end;
 
End PKG_ESB;
/

