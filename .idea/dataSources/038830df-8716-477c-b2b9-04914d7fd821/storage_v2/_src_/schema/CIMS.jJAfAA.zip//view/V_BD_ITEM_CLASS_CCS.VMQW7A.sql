create view V_BD_ITEM_CLASS_CCS as
select BIC.ITEM_CLASS_ID,
       BIC.CLASS_CODE,
       BIC.CLASS_NAME,
       BIC.CLASS_TYPE,
       BIC.PARENTC_LASS_ID PARENT_CLASS_ID,
       BIC.CODE_ORDER,
       DECODE(BIC.ENTITY_ID,
              28,
              DECODE(BIC.CLASS_TYPE,
                     'M',
                     DECODE(BIC.CLASS_CODE, 'KT_TG', 10, BIC.ENTITY_ID),
                     'S',
                     DECODE((SELECT IC.CLASS_CODE FROM T_BD_ITEM_CLASS IC WHERE IC.ITEM_CLASS_ID = BIC.PARENTC_LASS_ID),
                            'KT_TG',
                            10,
                            BIC.ENTITY_ID)),
              29,
              DECODE(BIC.CLASS_TYPE,
                     'M',
                     DECODE(BIC.CLASS_CODE, 'BX_TG', 12, BIC.ENTITY_ID),
                     'S',
                     DECODE((SELECT IC.CLASS_CODE FROM T_BD_ITEM_CLASS IC WHERE IC.ITEM_CLASS_ID = BIC.PARENTC_LASS_ID),
                            'BX_TG',
                            12,
                            BIC.ENTITY_ID)),
              BIC.ENTITY_ID) ENTITY_ID,
       BIC.created_by,
       BIC.creation_date,
       BIC.last_updated_by,
       BIC.last_update_date,
       BIC.ACTIVE_FLAG
  from T_BD_ITEM_CLASS BIC
/

comment on column V_BD_ITEM_CLASS_CCS.ITEM_CLASS_ID is '主键ID'
/

comment on column V_BD_ITEM_CLASS_CCS.CLASS_CODE is '分类编码'
/

comment on column V_BD_ITEM_CLASS_CCS.CLASS_NAME is '分类名称'
/

comment on column V_BD_ITEM_CLASS_CCS.CLASS_TYPE is '分类类型'
/

comment on column V_BD_ITEM_CLASS_CCS.PARENT_CLASS_ID is '上级ID'
/

comment on column V_BD_ITEM_CLASS_CCS.CODE_ORDER is '排序'
/

comment on column V_BD_ITEM_CLASS_CCS.ENTITY_ID is '业务主体ID'
/

comment on column V_BD_ITEM_CLASS_CCS.ACTIVE_FLAG is 'Y有效，N无效'
/

