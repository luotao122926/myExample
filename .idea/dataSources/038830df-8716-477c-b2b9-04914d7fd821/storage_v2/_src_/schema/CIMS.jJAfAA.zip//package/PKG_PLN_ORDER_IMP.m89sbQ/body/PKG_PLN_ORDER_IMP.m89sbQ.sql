create PACKAGE BODY PKG_PLN_ORDER_IMP AS

  -----------------------------------------------------------------------------
  --      匹配订单发货计划                                             --
  -----------------------------------------------------------------------------
  PROCEDURE P_MATCH_ORDER_SHIP(
    IN_BATCH_ID               IN  NUMBER   --批次ID
    ,IN_ENTITY_ID             IN  NUMBER   --主体ID
    ,IS_USER_ACCOUNT          IN  VARCHAR2 --用户账号
    ,OS_MESSAGE               OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  )
  IS
    S_STEP             VARCHAR2(40);
    N_REQUEST_QTY      NUMBER;
    N_MATCH_QTY        NUMBER;
    N_MATCH_CNT        NUMBER := 0;
    N_CNT              NUMBER;
    S_CHK_MSG          VARCHAR2(240);
    B_HAVE_PLN         BOOLEAN := FALSE;
  BEGIN
    OS_MESSAGE := 'OK';
    SAVEPOINT SP;
    
    --检查是否存在对应的批次信息
    SELECT
      COUNT(*)
    INTO
      N_CNT
    FROM
      T_PLN_ORDER_SHIP_IMP_BAT
    WHERE
      BATCH_ID = IN_BATCH_ID;
    
    --不存在批次表则新增
    IF N_CNT = 0 THEN
      S_STEP := '新增批次信息';
      INSERT INTO T_PLN_ORDER_SHIP_IMP_BAT
      (
        BATCH_ID
        ,STATUS
        ,CREATED_BY
        ,CREATION_DATE
        ,LAST_UPDATED_BY
        ,LAST_UPDATE_DATE
      )
      VALUES
      (
        IN_BATCH_ID  --BATCH_ID
        ,'CREATED'  --STATUS
        ,IS_USER_ACCOUNT  --CREATED_BY
        ,SYSDATE  --CREATION_DATE
        ,IS_USER_ACCOUNT  --LAST_UPDATED_BY
        ,SYSDATE  --LAST_UPDATE_DATE
      );
    ELSE
      --存在批次表则清空匹配信息
      S_STEP := '清空匹配信息' || TO_CHAR(IN_BATCH_ID);
      UPDATE
        T_PLN_ORDER_SHIP_IMPORT
      SET
        MATCH_QTY = 0
      WHERE
        BATCH_ID = IN_BATCH_ID;
      
      DELETE FROM
        T_PLN_ORDER_SHIP_MATCH M
      WHERE
        EXISTS(
          SELECT
            1
          FROM
            T_PLN_ORDER_SHIP_IMPORT I
          WHERE
            I.SHIP_IMPORT_ID = M.SHIP_IMPORT_ID
        );
    END IF;
    
    --循环批次，按发货仓库、营销中心、产品找对应的发货计划可发货信息
    FOR R_IMP IN
    (
      SELECT
        SHIP_IMPORT_ID
        ,INVENTORY_ID
        ,SALES_CENTER_ID
        ,ITEM_ID
        ,REQUEST_QTY
        ,LG_ORDER_HEAD_ID
      FROM
        T_PLN_ORDER_SHIP_IMPORT
      WHERE
        BATCH_ID = IN_BATCH_ID
        AND CHK_MSG IS NULL
    )
    LOOP
      B_HAVE_PLN := FALSE;
      N_REQUEST_QTY := R_IMP.REQUEST_QTY;
      
      --取出符合条件的发货计划，如何设置条件，只取未分配的发货计划?
      --匹配优先级：创建日期
      --未下达数量 = 已分配数量-已下达数量 -其它发货计划已匹配数量
      S_STEP := '导入ID' || TO_CHAR(R_IMP.SHIP_IMPORT_ID);
      FOR R_PLN IN
      (
        SELECT
          S.ORDER_SHARE_ID
          ,S.ORIGIN_TYPE SOURCE_TYPE
          ,S.ORIGIN_HEAD_CODE SOURCE_BILL_NUM
          ,S.SHARE_QTY-NVL(S.CARRY_QTY,0)-NVL(M.MATCH_QTY,0) CAN_MATCH_QTY
        FROM
          T_PLN_ORDER_SHARE_SHIPMENT S
          ,(
            SELECT
              OSM.ORDER_SHARE_ID
              ,SUM(OSM.MATCH_QTY) MATCH_QTY
            FROM
              T_PLN_ORDER_SHIP_IMPORT OSI
              ,T_PLN_ORDER_SHIP_MATCH OSM
            WHERE
              OSI.SHIP_IMPORT_ID = OSM.SHIP_IMPORT_ID
              AND OSI.BATCH_ID = IN_BATCH_ID
            GROUP BY
              OSM.ORDER_SHARE_ID
          ) M
        WHERE
          S.SALES_CENTER_ID = R_IMP.SALES_CENTER_ID
          AND S.INVENTORY_FROM_ID = R_IMP.INVENTORY_ID
          AND S.ITEM_ID = R_IMP.ITEM_ID
          AND S.ENTITY_ID = IN_ENTITY_ID
          AND S.ORDER_SHARE_ID = M.ORDER_SHARE_ID(+)
          AND S.SHARE_QTY > NVL(CARRY_QTY,0)+NVL(M.MATCH_QTY,0)
          --20180724 hejy3 不匹配T+3订单 
          AND NOT EXISTS (SELECT 1 FROM T_PLN_LG_RELATION R
                           WHERE R.ORDER_LINE_ID = S.ORIGIN_LINE_ID)
          AND (R_IMP.LG_ORDER_HEAD_ID IS NULL
              OR
              (R_IMP.LG_ORDER_HEAD_ID IS NOT NULL
               AND EXISTS (SELECT 1
                             FROM T_PLN_LG_ORDER_HEAD H,
                                  T_PLN_LG_ORDER_TYPE_MATCH TM,
                                  T_PLN_ORDER_HEAD OH
                            WHERE H.ORDER_HEAD_ID = R_IMP.LG_ORDER_HEAD_ID
                              AND H.ORDER_TYPE_ID = TM.LG_ORDER_TYPE_ID
                              AND TM.ORDER_TYPE_ID = OH.ORDER_TYPE_ID
                              AND OH.ORDER_HEAD_ID = S.ORIGIN_HEAD_ID)))
        ORDER BY
          CREATION_DATE
      )
      LOOP
        B_HAVE_PLN := TRUE;
        N_MATCH_QTY := LEAST(N_REQUEST_QTY,R_PLN.CAN_MATCH_QTY);
        --记录匹配信息
        INSERT INTO T_PLN_ORDER_SHIP_MATCH
        (
          SHIP_MATCH_ID
          ,SHIP_IMPORT_ID
          ,ORDER_SHARE_ID
          ,SOURCE_TYPE
          ,SOURCE_BILL_NUM
          ,MATCH_QTY
          ,CREATED_BY
          ,CREATION_DATE
          ,LAST_UPDATED_BY
          ,LAST_UPDATE_DATE
        )
        SELECT
          S_PLN_ORDER_SHIP_MATCH.NEXTVAL SHIP_MATCH_ID
          ,R_IMP.SHIP_IMPORT_ID
          ,R_PLN.ORDER_SHARE_ID
          ,R_PLN.SOURCE_TYPE
          ,R_PLN.SOURCE_BILL_NUM
          ,N_MATCH_QTY MATCH_QTY
          ,IS_USER_ACCOUNT CREATED_BY
          ,SYSDATE CREATION_DATE
          ,IS_USER_ACCOUNT LAST_UPDATED_BY
          ,SYSDATE LAST_UPDATE_DATE
        FROM
          DUAL;
        
        --匹配完则跳出循环
        N_REQUEST_QTY := N_REQUEST_QTY - N_MATCH_QTY;
        IF N_REQUEST_QTY = 0 THEN
          EXIT;
        END IF;
      END LOOP;
    
      --更新匹配数量，对于不能满足需求数量，则记录检查信息
      IF (R_IMP.REQUEST_QTY <> N_REQUEST_QTY) OR (NOT B_HAVE_PLN) THEN
        IF N_REQUEST_QTY <> 0 THEN
          S_CHK_MSG := '匹配数量小于需求数量';
        ELSE
          S_CHK_MSG := '';
        END IF;
        UPDATE
          T_PLN_ORDER_SHIP_IMPORT
        SET
          MATCH_QTY = R_IMP.REQUEST_QTY - N_REQUEST_QTY
          ,CHK_MSG = S_CHK_MSG
          ,LAST_UPDATED_BY = IS_USER_ACCOUNT
          ,LAST_UPDATE_DATE = SYSDATE
        WHERE
          SHIP_IMPORT_ID = R_IMP.SHIP_IMPORT_ID;
        N_MATCH_CNT := 1;
      END IF;
      
    END LOOP;
    
    --20171208 hejy3 更新完全匹配的订单
    UPDATE t_Pln_Order_Ship_Import i
       set i.pre_field_01 = to_char(IN_BATCH_ID)
     where i.batch_id = IN_BATCH_ID
       and i.lg_order_head_id in
           (SELECT I.LG_ORDER_HEAD_ID
              FROM t_Pln_Order_Ship_Import i
             WHERE I.BATCH_ID = IN_BATCH_ID
             GROUP BY I.LG_ORDER_HEAD_ID
            HAVING SUM(NVL(I.MATCH_QTY, 0)) >= (SELECT SUM(NVL(L.CENTER_AFFIRM_QUANTITY, L.QUANTITY) -
                                                          NVL(L.AFFIRMED_QUANTITY, 0) -
                                                          NVL(L.CANCEL_QTY, 0))
                                                 FROM T_PLN_LG_ORDER_LINE L
                                                WHERE L.ORDER_HEAD_ID = I.LG_ORDER_HEAD_ID
                                                  AND NVL(L.ORDER_LINE_STATE, 'NORMAL') <> 'CLOSED'));
    
    IF OS_MESSAGE = 'OK' THEN
      IF N_MATCH_CNT = 0 THEN
        OS_MESSAGE := '当前导入内容没有可匹配的发货计划！';
      ELSE
        --更新批次状态为已匹配
        S_STEP := '更新批次状态';
        UPDATE
          T_PLN_ORDER_SHIP_IMP_BAT
        SET
          STATUS = 'MATCHED'
        WHERE
          BATCH_ID = IN_BATCH_ID;
      END IF;
    END IF;
    
    IF OS_MESSAGE <> 'OK' THEN
      ROLLBACK TO SAVEPOINT SP;
    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK TO SAVEPOINT SP;
      OS_MESSAGE := '匹配发货计划-'|| S_STEP || ':' || SQLERRM;
  END P_MATCH_ORDER_SHIP;

  -----------------------------------------------------------------------------
  --  确认发货计划                                                     --
  --  更新发货计划内容，并通过调用发货计划下达过程，生成T_LG_SHIP_PLAN对应内容
  -----------------------------------------------------------------------------
  PROCEDURE P_AFFIRM_ORDER_SHIP(
    IN_BATCH_ID               IN  NUMBER   --批次ID
    ,IN_ENTITY_ID             IN  NUMBER   --主体ID
    ,IS_USER_ACCOUNT          IN  VARCHAR2 --用户账号
    ,OI_BATCH_ID              OUT NUMBER   --输出批次ID
    ,OS_MESSAGE               OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  )
  IS
    TYPE TAB_PLN_ORDER_SHARE IS TABLE OF T_PLN_ORDER_SHARE_SHIPMENT.CARRY_QTY%TYPE INDEX BY BINARY_INTEGER;
    R_PLN_ORDER_SHARE TAB_PLN_ORDER_SHARE; 
    S_STEP             VARCHAR2(40);
    S_RESULT           VARCHAR2(4000);
    S_MSG              VARCHAR2(4000);
    N_CNT              NUMBER;
  BEGIN
    OS_MESSAGE := 'OK';
    SAVEPOINT SP;
    
    --检查批次是否已确认
    SELECT
      COUNT(*)
    INTO
      N_CNT
    FROM
      T_PLN_ORDER_SHIP_IMP_BAT
    WHERE
      BATCH_ID = IN_BATCH_ID
      AND STATUS = 'AFFIRMED';
    IF N_CNT <> 0 THEN
      OS_MESSAGE := '当前导入内容已下达，不能重复下达！';
    END IF;
    
    --锁定发货计划中对应的内容
    IF OS_MESSAGE = 'OK' THEN
      S_STEP := '锁定发货计划';
      BEGIN
        SELECT
          S.CARRY_QTY
        BULK COLLECT INTO
          R_PLN_ORDER_SHARE
        FROM
          T_PLN_ORDER_SHARE_SHIPMENT S
        WHERE
          EXISTS(
            SELECT
              1
            FROM
              T_PLN_ORDER_SHIP_IMPORT I
              ,T_PLN_ORDER_SHIP_MATCH M
            WHERE
              I.SHIP_IMPORT_ID = M.SHIP_IMPORT_ID
              AND M.ORDER_SHARE_ID = S.ORDER_SHARE_ID
              AND I.BATCH_ID = IN_BATCH_ID
          )
        FOR UPDATE NOWAIT;
      EXCEPTION
        WHEN TIMEOUT_ON_RESOURCE THEN
          OS_MESSAGE := '锁定发货计划不成功！请稍后再试。';
      END;
    END IF;
    
    --检查是否有足够的可下达数量
    IF OS_MESSAGE = 'OK' THEN
      S_STEP := '检查可下达数量';
      BEGIN
        SELECT
          '发货计划已发生改变，不能按匹配信息下达(来源类型：' || S.ORIGIN_TYPE || '，来源单号：' || S.ORIGIN_HEAD_CODE || ')，请重新处理匹配！'
        INTO
          OS_MESSAGE
        FROM
          T_PLN_ORDER_SHARE_SHIPMENT S
          ,(
            SELECT
              M.ORDER_SHARE_ID
              ,SUM(M.MATCH_QTY) MATCH_QTY
            FROM
              T_PLN_ORDER_SHIP_IMPORT I
              ,T_PLN_ORDER_SHIP_MATCH M
            WHERE
              I.SHIP_IMPORT_ID = M.SHIP_IMPORT_ID
              AND I.BATCH_ID = IN_BATCH_ID
            GROUP BY
              M.ORDER_SHARE_ID
          ) I
        WHERE
          S.ORDER_SHARE_ID = I.ORDER_SHARE_ID
          AND S.SHARE_QTY-NVL(S.CARRY_QTY,0) < I.MATCH_QTY
          AND ROWNUM = 1;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          OS_MESSAGE := 'OK';
      END;
    END IF;
    
    --循环批次对应的匹配记录，更新发货计划
    IF OS_MESSAGE = 'OK' THEN
      S_STEP := '下达发货计划';
      --取输出批次ID
      SELECT
        S_INTF_LG_BATCH_NUM.NEXTVAL
      INTO
        OI_BATCH_ID
      FROM
        DUAL;
          
      OS_MESSAGE := '没有已匹配的下达数量，不能下达！';
      FOR R_MATCH IN
      (
        SELECT
          M.ORDER_SHARE_ID
          ,M.MATCH_QTY
          ,I.PLAN_SEND_DATE
          ,I.SALES_ORDER_TYPE_ID
          ,I.RCV_INV_ID
          ,I.RCV_INV_CODE
          ,I.RCV_INV_NAME
          ,I.SALES_CENTER_ID
          ,I.SALES_CENTER_CODE
          ,I.SALES_CENTER_NAME
          ,I.CUSTOMER_ID
          ,I.CUSTOMER_CODE
          ,I.CUSTOMER_NAME
          ,I.ACCOUNT_ID
          ,I.ACCOUNT_CODE
          ,I.CONSIGNEE_ID
          ,I.CONSIGNEE_CODE
          ,I.CONSIGNEE_NAME
          ,I.CONSIGNEE_ADDRESS
          ,I.INCEPT_DISTRICT_ID
          ,I.INCEPT_DISTRICT_CODE
          ,I.CONSIGNEE_CONTACT_ID
          ,I.CONSIGNEE_CONTACT
          ,I.CONSIGNEE_CONTACT_TEL
          ,I.IS_PICK_FLAG
          ,I.IS_CUSG_FLAG
          ,I.TRANSFER_CUST_ID
          ,I.TRANSFER_CUST_CODE
          ,I.TRANSFER_CUST_NAME
          ,I.IS_BASE_FLAG
          ,I.REMARK
          ,M.SOURCE_TYPE
          ,M.SOURCE_BILL_NUM
          ,ST.SOURCE_TYPE_CODE
          ,I.DISCOUNT_RATE
          ,I.CUSTOMER_ORDER_NUMBER
          ,I.CUSTOMER_ORDER_DATE
          ,I.PRESCRIPTION
          ,I.PRESCRIPTION_NAME
          ,I.EXPECTED_DATE
          ,I.EFFECTIVE_DATE
          ,I.IS_COLLAGE
          ,I.MIN_QUANTITY
          ,I.MAX_QUANTITY
          ,I.TIME_LIMITATION
          ,I.PRESCRIPTION_DISCOUNT
          ,I.PREAPPOINT_FLAG --add by houhs 增加预约标识 20190430
        FROM
          T_PLN_ORDER_SHIP_IMPORT I
          ,T_PLN_ORDER_SHIP_MATCH M
          ,T_INV_BILL_TYPES BT
          ,T_INV_SOURCE_TYPES ST
        WHERE
          I.SHIP_IMPORT_ID = M.SHIP_IMPORT_ID
          AND I.BATCH_ID = IN_BATCH_ID
          AND I.SALES_ORDER_TYPE_ID = BT.BILL_TYPE_ID
          AND BT.SOURCE_TYPE_ID = ST.SOURCE_TYPE_ID
          AND I.LG_ORDER_HEAD_ID IS NULL
      )
      LOOP
        --更新发货计划
        UPDATE
          T_PLN_ORDER_SHARE_SHIPMENT
        SET
          PLAN_SEND_DATE         = R_MATCH.PLAN_SEND_DATE        
          ,SALES_ORDER_TYPE_ID   = R_MATCH.SALES_ORDER_TYPE_ID  
          ,INVENTORY_TO_ID       = R_MATCH.RCV_INV_ID           
          ,RCV_INV_CODE          = R_MATCH.RCV_INV_CODE         
          ,RCV_INV_NAME          = R_MATCH.RCV_INV_NAME         
          ,CUSTOMER_ID           = NVL(R_MATCH.CUSTOMER_ID,CUSTOMER_ID)          
          ,CUSTOMER_CODE         = NVL(R_MATCH.CUSTOMER_CODE,CUSTOMER_CODE)        
          ,CUSTOMER_NAME         = NVL(R_MATCH.CUSTOMER_NAME,CUSTOMER_NAME)        
          ,ACCOUNT_ID            = NVL(R_MATCH.ACCOUNT_ID,ACCOUNT_ID)  
          ,ACCOUNT_CODE          = NVL(R_MATCH.ACCOUNT_CODE,ACCOUNT_CODE)         
          ,CONSIGNEE_ID          = R_MATCH.CONSIGNEE_ID         
          ,CONSIGNEE_CODE        = R_MATCH.CONSIGNEE_CODE       
          ,CONSIGNEE_NAME        = R_MATCH.CONSIGNEE_NAME 
          ,CONSIGNEE_ADDRESS_NAME= R_MATCH.CONSIGNEE_ADDRESS      
          ,INCEPT_ADDRESS_ID     = R_MATCH.INCEPT_DISTRICT_ID   
          ,CONSIGNEE_ADDRESS_CODE= R_MATCH.INCEPT_DISTRICT_CODE 
          ,CONSIGNEE_CONTACT_ID  = R_MATCH.CONSIGNEE_CONTACT_ID 
          ,CONSIGNEE_CONTRACT    = R_MATCH.CONSIGNEE_CONTACT    
          ,CONSIGNEE_TEL         = R_MATCH.CONSIGNEE_CONTACT_TEL
          ,IS_PICK_FLAG          = R_MATCH.IS_PICK_FLAG         
          ,IS_CUSG_FLAG          = R_MATCH.IS_CUSG_FLAG         
          ,TRANSFER_CUST_ID      = R_MATCH.TRANSFER_CUST_ID     
          ,TRANSFER_CUST_CODE    = R_MATCH.TRANSFER_CUST_CODE   
          ,TRANSFER_CUST_NAME    = R_MATCH.TRANSFER_CUST_NAME   
          ,IS_BASE_FLAG          = R_MATCH.IS_BASE_FLAG         
          ,CARRYING_QTY          = R_MATCH.MATCH_QTY 
          ,REMARK                = R_MATCH.REMARK
          ,DISCOUNT_RATE         = R_MATCH.DISCOUNT_RATE
          ,CUSTOMER_ORDER_NUMBER = R_MATCH.CUSTOMER_ORDER_NUMBER
          ,CUSTOMER_ORDER_DATE   = R_MATCH.CUSTOMER_ORDER_DATE
          ,LAST_UPDATED_BY       = IS_USER_ACCOUNT
          ,LAST_UPDATE_DATE      = SYSDATE
          ,PRESCRIPTION        = R_MATCH.PRESCRIPTION
          ,PRESCRIPTION_NAME   = R_MATCH.PRESCRIPTION_NAME
          ,EXPECTED_DATE       = R_MATCH.EXPECTED_DATE
          ,EFFECTIVE_DATE      = R_MATCH.EFFECTIVE_DATE
          ,IS_COLLAGE          = R_MATCH.IS_COLLAGE
          ,MIN_QUANTITY        = R_MATCH.MIN_QUANTITY
          ,MAX_QUANTITY        = R_MATCH.MAX_QUANTITY
          ,TIME_LIMITATION     = R_MATCH.TIME_LIMITATION
          ,PRESCRIPTION_DISCOUNT = R_MATCH.PRESCRIPTION_DISCOUNT
          ,PREAPPOINT_FLAG     = R_MATCH.PREAPPOINT_FLAG --add by houhs 增加预约标识 20190430
        WHERE
          ORDER_SHARE_ID = R_MATCH.ORDER_SHARE_ID;

        --执行下达发货计划
        PKG_PLN_SHARES.P_SHARE_TO_LGSHIPPLAN(IN_ENTITY_ID, R_MATCH.ORDER_SHARE_ID, R_MATCH.SOURCE_TYPE_CODE, IS_USER_ACCOUNT, OI_BATCH_ID, S_RESULT, S_MSG);
        
        IF S_RESULT <> 'SUCCESS' THEN
          OS_MESSAGE := '(来源类型：' || R_MATCH.SOURCE_TYPE || '，来源单号：' || R_MATCH.SOURCE_BILL_NUM || ')' || S_MSG || S_RESULT;
          EXIT;
        ELSE
          OS_MESSAGE := 'OK';
        END IF;
        
      END LOOP;
    END IF;
    
    --成功下达，则更新批次状态
    IF OS_MESSAGE = 'OK' THEN
      --更新批次状态为已确认下达
      S_STEP := '更新批次状态';
      UPDATE
        T_PLN_ORDER_SHIP_IMP_BAT
      SET
        STATUS = 'AFFIRMED'
      WHERE
        BATCH_ID = IN_BATCH_ID;
    ELSE
      --由于计划模块有“ROLLBACK”，故对于ROLLBACK TO SAVEPOINT 异常则不处理
      BEGIN
        ROLLBACK TO SAVEPOINT SP;
      EXCEPTION
        WHEN OTHERS THEN
          NULL;
      END;
    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK TO SAVEPOINT SP;
      IF SUBSTRB(SQLERRM,1,9) = 'ORA-00054' THEN
        OS_MESSAGE := '锁定发货计划不成功！请稍后再试。';
      ELSE
        OS_MESSAGE := '确认发货计划-'|| S_STEP || ':' || SQLERRM;
      END IF;
  END P_AFFIRM_ORDER_SHIP;

  -----------------------------------------------------------------------------
  --  清理导入批次信息，每天调用，删除7天前的批次信息                        --
  -----------------------------------------------------------------------------
  PROCEDURE P_CLEAR_PLN_SHIP_BATCH
  IS
  BEGIN
    --删除7天前的导入信息
    DELETE FROM
      T_PLN_ORDER_SHIP_IMPORT
    WHERE
      CREATION_DATE < TRUNC(SYSDATE)-7;
      
    --删除7天前的批次匹配信息
    DELETE FROM
      T_PLN_ORDER_SHIP_MATCH
    WHERE
      CREATION_DATE < TRUNC(SYSDATE)-7;
    
    --删除7天前的批次信息
    DELETE FROM
      T_PLN_ORDER_SHIP_IMP_BAT
    WHERE
      CREATION_DATE < TRUNC(SYSDATE)-7;
    
    COMMIT;
      
  END P_CLEAR_PLN_SHIP_BATCH;

END PKG_PLN_ORDER_IMP;
/

