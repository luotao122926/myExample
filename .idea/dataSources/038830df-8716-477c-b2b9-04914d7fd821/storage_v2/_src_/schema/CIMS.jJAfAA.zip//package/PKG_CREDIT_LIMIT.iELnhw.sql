create package PKG_CREDIT_LIMIT is

  -- Author  : TIANMENGZHU
  -- Created : 2016/8/29 10:14:58
  -- Purpose : 

  V_ERROR_INFO VARCHAR2(1000); --异常错误信息
  V_BIZ_EXCEPTION EXCEPTION; --自定义业务异常

  --获取订金比例、提货金额上限
  PROCEDURE P_GET_DOWN_PAY_CFG(IN_ENTITY_ID        NUMBER, --主体ID
                               IN_CUSTOMER_ID      NUMBER, --客户ID
                               IN_ACCOUNT_ID       NUMBER, --账户ID
                               ON_DOWN_PAY_AMOUNT  OUT NUMBER, --订金比例
                               ON_ORDER_TOP_AMOUNT OUT NUMBER, --订单提货金额上限
                               OS_MESSAGE          OUT VARCHAR2 --成功返回“SUCCESS”；失败返回出错信息。
                               );

  --获取订单可提货金额
  FUNCTION FUN_GET_ORDER_AMOUNT(IN_ENTITY_ID   NUMBER, --主体ID
                                IN_CUSTOMER_ID NUMBER, --客户ID
                                IN_ACCOUNT_ID  NUMBER --账户ID
                                ) RETURN NUMBER;

  --更新客户账户额度表字段：订金比例、订单提货金额（订金-账户配置）
  PROCEDURE P_SET_ORDER_LIMIT_AMOUNT_ACC(IN_ENTITY_ID   NUMBER, --主体ID
                                         IN_CUSTOMER_ID NUMBER, --客户ID
                                         IN_ACCOUNT_ID  NUMBER, --账户ID
                                         IN_UPDATED_BY  VARCHAR2, --修改人
                                         OS_MESSAGE     OUT VARCHAR2 --成功返回“SUCCESS”；失败返回出错信息。
                                         );

  --更新客户账户额度表：订金比例、订单提货金额（订金-信用等级配置）
  PROCEDURE P_SET_ORDER_LIMIT_AMOUNT_CUS(IN_ENTITY_ID    NUMBER, --主体ID
                                         IN_CREDIT_LEVEL NUMBER, --客户信用等级
                                         IN_UPDATED_BY   VARCHAR2, --修改人
                                         OS_MESSAGE      OUT VARCHAR2 --成功返回“SUCCESS”；失败返回出错信息。
                                         );

  --更新客户账户额度表：订金比例、订单提货金额（订金-系统参数配置）
  PROCEDURE P_SET_ORDER_LIMIT_AMOUNT_ENT(IN_ENTITY_ID  NUMBER, --主体ID
                                         IN_UPDATED_BY VARCHAR2, --修改人
                                         OS_MESSAGE    OUT VARCHAR2 --成功返回“SUCCESS”；失败返回出错信息。
                                         );

  --更新客户账户额度表：订金比例、订单提货金额（订金-账户、信用等级、系统参数配置，补充更新）
  PROCEDURE P_SET_ORDER_LIMIT_AMOUNT_ALL(P_ENTITY_ID  NUMBER, --主体ID
                                         P_UPDATED_BY VARCHAR2, --修改人
                                         P_MESSAGE    OUT VARCHAR2 --成功返回“SUCCESS”；失败返回出错信息。
                                         );

end PKG_CREDIT_LIMIT;
/

