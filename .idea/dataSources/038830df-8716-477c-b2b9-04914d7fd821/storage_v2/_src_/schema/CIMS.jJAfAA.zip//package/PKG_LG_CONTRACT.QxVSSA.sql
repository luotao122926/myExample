create PACKAGE      PKG_LG_CONTRACT IS

  ----------------------------------------------------------------------
  -- AUTHOR  : XUQF
  -- CREATED : 2014-08-04
  -- PURPOSE : 生成实际发货信息 按照客户、地点、地址、发货仓库分组
  ----------------------------------------------------------------------
  PROCEDURE P_LG_GENE_ACTUAL_SHIP_OLD(I_VEHICLE_NUM IN VARCHAR2,
                                      O_RESULT      OUT VARCHAR2,
                                      O_RESULT_MSG  OUT VARCHAR2);

  ----------------------------------------------------------------------
  -- AUTHOR  : XUQF
  -- CREATED : 2014-08-04
  -- PURPOSE : 生成实际发货信息 按照发货通知单分组
  ----------------------------------------------------------------------
  PROCEDURE P_LG_GENERATION_ACTUAL_SHIP(I_VEHICLE_NUM IN VARCHAR2,
                                        O_RESULT      OUT VARCHAR2,
                                        O_RESULT_MSG  OUT VARCHAR2);

  ----------------------------------------------------------------------
  -- AUTHOR  : XUQF
  -- CREATED : 2014-08-07
  -- PURPOSE : 生成运输合同
  ----------------------------------------------------------------------
  PROCEDURE P_LG_GENERATION_CONTRACT(I_VEHICLE_NUM IN VARCHAR2,
                                     O_RESULT      OUT VARCHAR2,
                                     O_RESULT_MSG  OUT VARCHAR2);

  ----------------------------------------------------------------------
  -- AUTHOR  : XUQF
  -- CREATED : 2014-07-29
  -- PURPOSE : 重新计算体积、重量
  ----------------------------------------------------------------------
  PROCEDURE P_RECOUNT_VOLUME_WEIGHT(I_CONTRACT_ID   IN NUMBER,
                                    I_ACCOUNT       IN VARCHAR2, --登录账号
                                    O_AMOUNT_WEIGHT OUT NUMBER,
                                    O_AMOUNT_VOLUME OUT NUMBER,
                                    O_RESULT        OUT VARCHAR2,
                                    O_RESULT_MSG    OUT VARCHAR2);

  ----------------------------------------------------------------------
  -- AUTHOR  : XUQF
  -- CREATED : 2014-07-29
  -- PURPOSE : 重新计算运费
  ----------------------------------------------------------------------
  PROCEDURE P_RECOUNT_FREIGHT(I_CONTRACT_ID    IN NUMBER,
                              I_ACCOUNT        IN VARCHAR2, --登录账号
                              O_AMOUNT_FREIGHT OUT NUMBER,
                              O_PRICE_UNIT     OUT VARCHAR2,
                              O_RESULT         OUT VARCHAR2,
                              O_RESULT_MSG     OUT VARCHAR2);

  ----------------------------------------------------------------------
  -- AUTHOR  : XUQF
  -- CREATED : 2014-07-29
  -- PURPOSE : 重新计算保险费
  ----------------------------------------------------------------------
  PROCEDURE P_RECOUNT_INSURANCE(I_CONTRACT_ID      IN NUMBER,
                                I_ACCOUNT          IN VARCHAR2, --登录账号
                                O_AMOUNT_INSURANCE OUT NUMBER,
                                O_RESULT           OUT VARCHAR2,
                                O_RESULT_MSG       OUT VARCHAR2);

  ----------------------------------------------------------------------
  -- AUTHOR  : XUQF
  -- CREATED : 2014-10-23
  -- PURPOSE : 重新计算包装破损费
  ----------------------------------------------------------------------
  PROCEDURE P_RECOUNT_DAMAGE_FEE(I_CONTRACT_ID       IN NUMBER, --运输合同ID
                                 I_ACCOUNT           IN VARCHAR2, --登录账号
                                 O_DAMAGE_FEE        OUT NUMBER, --包装破损索赔金额
                                 O_CLAIM_VENDOR_CODE OUT VARCHAR2, --索赔单位编码
                                 O_CLAIM_VENDOR_NAME OUT VARCHAR2, --索赔单位名称
                                 O_RESULT            OUT VARCHAR2, --返回错误码
                                 O_RESULT_MSG        OUT VARCHAR2 --返回错误信息
                                 );

  ----------------------------------------------------------------------
  -- AUTHOR  : XUQF
  -- CREATED : 2014-09-16
  -- PURPOSE : 到货签收
  ----------------------------------------------------------------------
  PROCEDURE P_DELIVERY_RECEIPT(I_CONTRACT_CODE  IN VARCHAR2, --合同号
                               I_ENTITY_ID      IN NUMBER, --主体ID
                               I_RECEIPT_STATUS IN VARCHAR2, --合同签收状态
                               O_RESULT         OUT VARCHAR2,
                               O_RESULT_MSG     OUT VARCHAR2);

  ----------------------------------------------------------------------
  -- AUTHOR  : XUQF
  -- CREATED : 2015-01-30
  -- PURPOSE : 批量计算体积
  ----------------------------------------------------------------------
  PROCEDURE P_BATCH_COUNT_VOLLUME(I_BEGIN_DATE IN VARCHAR2, --开始时间
                                  I_END_DATE   IN VARCHAR2, --结束时间
                                  I_ENTITY_ID  IN NUMBER, --主体ID
                                  I_ACCOUNT    IN VARCHAR2, --登录账号
                                  O_RESULT     OUT VARCHAR2,
                                  O_RESULT_MSG OUT VARCHAR2);

  ----------------------------------------------------------------------
  -- AUTHOR  : XUQF
  -- CREATED : 2015-01-30
  -- PURPOSE : 批量计算运费
  ----------------------------------------------------------------------
  PROCEDURE P_BATCH_COUNT_FREIGHT(I_BEGIN_DATE IN VARCHAR2, --开始时间
                                  I_END_DATE   IN VARCHAR2, --结束时间
                                  I_ENTITY_ID  IN NUMBER, --主体ID
                                  I_ACCOUNT    IN VARCHAR2, --登录账号
                                  O_RESULT     OUT VARCHAR2,
                                  O_RESULT_MSG OUT VARCHAR2);

  ----------------------------------------------------------------------
  -- AUTHOR  : XUQF
  -- CREATED : 2014-12-12
  -- PURPOSE : 批量计算保费
  ----------------------------------------------------------------------
  PROCEDURE P_BATCH_COUNT_INSURANCE(I_BEGIN_DATE IN VARCHAR2, --开始时间
                                    I_END_DATE   IN VARCHAR2, --结束时间
                                    I_ENTITY_ID  IN NUMBER, --主体ID
                                    I_ACCOUNT    IN VARCHAR2, --登录账号
                                    O_RESULT     OUT VARCHAR2,
                                    O_RESULT_MSG OUT VARCHAR2);

  ----------------------------------------------------------------------
  -- AUTHOR  : XUQF
  -- CREATED : 2015-01-07
  -- PURPOSE : 发货确认（仓库由CIMS维护的情况）
  ----------------------------------------------------------------------
  PROCEDURE P_SHIP_CONFIRM(I_ACTUAL_SHIP_ID IN VARCHAR2, --实际发货信息ID
                           I_ACCOUNT        IN VARCHAR2, --登录账号
                           O_RESULT         OUT VARCHAR2,
                           O_RESULT_MSG     OUT VARCHAR2);

  ----------------------------------------------------------------------
  -- AUTHOR  : XUQF
  -- CREATED : 2015-01-19
  -- PURPOSE : 汇总客户订单号
  ----------------------------------------------------------------------
  FUNCTION F_COLLECT_CUST_ORDER_NUM(I_CONTRACT_ID VARCHAR2) RETURN VARCHAR2;

END PKG_LG_CONTRACT;
/

