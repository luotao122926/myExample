create PACKAGE BODY PKG_INV_TRANSACTION_wl
AS
--定义全局变量
pkgn_source_type_id                T_INV_BILL_TYPES.source_type_id%TYPE;--单据源类型ID
pkgn_head_id                    t_inv_bill_types.bill_period_head_id%TYPE;--单据周期头ID
pkgs_transaction_flag            t_inv_bill_period_line.transaction_flag%TYPE;--是否有物料事务
pkgn_transaction_type_id        t_inv_bill_period_line.transaction_type_id%TYPE;--物料事务类型ID
pkgn_if_his                        number:=1;--是否已有物料事物历史记录    0否，1是
pkgn_entity_id                    T_INV_TRANSACTION_HISTORY.entity_id%TYPE;--经营主体ID
pkgn_period_id                    T_INV_INVENTORY_PERIODS.period_id%TYPE;--期间ID
pkgs_business_state                T_INV_TRANSACTION_HISTORY.business_state%TYPE;--业务单据状态
pkgn_business_header_id            T_INV_TRANSACTION_HISTORY.business_header_id%TYPE;--业务单据头ID
pkgs_business_num                T_INV_TRANSACTION_HISTORY.BUSINESS_NUM%TYPE;--业务单据号
pkgd_transaction_date            T_INV_TRANSACTION_HISTORY.transaction_date%TYPE;--业务日期
pkgs_period_name                T_INV_TRANSACTION_HISTORY.period_name%TYPE;--期间名称
pkgs_action_type                T_INV_TRANSACTION_HISTORY.action_type%TYPE;--活动类型
pkgs_same_str                    varchar2(1000):='';--前后两次相同的历史ID串
pkgs_new_str                    varchar2(1000):='';--本次insert的历史ID串
pkgn_bill_type_id                T_INV_BILL_TYPES.bill_type_id%TYPE;--单据类型ID
pkgn_created_by                    T_INV_TRANSACTION_HISTORY.created_by%TYPE;--操作人
pkgd_sysdate                    date;--物料事物的处理时间保持一致
pkgn_if_null                    NUMBER;
pkgn_error_code                    NUMBER;
pkgs_bill_type_flag                t_inv_bill_types.negative_inventory_flag%TYPE;--是否允许负库存，是  Y，否 N，默认为 是 Y

--存储业务单据的信息
TYPE ty_bill_rec IS RECORD(
    header_id                T_INV_TRANSACTION_HISTORY.BUSINESS_HEADER_ID%TYPE,--业务单据头ID
    business_num                T_INV_TRANSACTION_HISTORY.BUSINESS_NUM%TYPE, --业务单据号
    line_id                    T_INV_TRANSACTION_HISTORY.BUSINESS_LINE_ID%TYPE,--业务单据行ID
    line_detail_id            T_INV_TRANSACTION_HISTORY.BUSINESS_LINE_DETAIL_ID%TYPE,--业务单据行明细ID
    item_id                    T_INV_TRANSACTION_HISTORY.ITEM_ID%TYPE,--产品ID
    item_code                T_INV_TRANSACTION_HISTORY.ITEM_CODE%TYPE,--产品编码
    item_name                T_INV_TRANSACTION_HISTORY.ITEM_NAME%TYPE,--产品名称
    transaction_uom            T_INV_TRANSACTION_HISTORY.TRANSACTION_UOM%TYPE,--单位
    inventory_id            T_INV_TRANSACTION_HISTORY.INVENTORY_ID%TYPE,--仓库ID
    inventory_code            T_INV_TRANSACTION_HISTORY.INVENTORY_CODE%TYPE,--仓库编码
    inventory_name            T_INV_TRANSACTION_HISTORY.INVENTORY_NAME%TYPE,--仓库名称
    transaction_quantity    T_INV_TRANSACTION_HISTORY.TRANSACTION_QUANTITY%TYPE,--数量
    created_by                T_INV_TRANSACTION_HISTORY.CREATED_BY%TYPE,--操作人
    from_inventory_id        T_INV_TRANSACTION_HISTORY.FROM_INVENTORY_ID%TYPE,--源仓库ID
    from_inventory_code        T_INV_TRANSACTION_HISTORY.FROM_INVENTORY_CODE%TYPE,--源仓库编码
    from_inventory_name        T_INV_TRANSACTION_HISTORY.FROM_INVENTORY_NAME%TYPE,--源仓库名称
    to_inventory_id            T_INV_TRANSACTION_HISTORY.TO_INVENTORY_ID%TYPE,--目的仓库ID
    to_inventory_code        T_INV_TRANSACTION_HISTORY.TO_INVENTORY_CODE%TYPE,--目的仓库编码
    to_inventory_name        T_INV_TRANSACTION_HISTORY.TO_INVENTORY_NAME%TYPE--目的仓库名称
);
TYPE ty_bill_tab IS TABLE OF  ty_bill_rec INDEX BY BINARY_INTEGER;
ty_bill    ty_bill_tab;

--对前台录入参数的为空校验
PROCEDURE check_is_null(
    in_entity_id            IN    T_INV_TRANSACTION_HISTORY.entity_id%TYPE,--经营主体ID
    in_bill_type_id            IN    T_INV_BILL_TYPES.bill_type_id%TYPE,--单据类型ID
    is_business_state        IN    T_INV_TRANSACTION_HISTORY.business_state%TYPE,--单据状态
    id_transaction_date        IN    T_INV_TRANSACTION_HISTORY.transaction_date%TYPE,--业务日期
    in_business_header_id    IN    T_INV_TRANSACTION_HISTORY.business_header_id%TYPE,--业务单据头ID
    in_if_null                IN    NUMBER,--是否是空的业务单据，0否，1是
    on_flag                    OUT    NUMBER,
    os_prompt                OUT    VARCHAR2
)AS
BEGIN
    if in_entity_id is null then
        on_flag   := -1;
        os_prompt := '经营主体ID传入为空！';
        return;
    elsif in_bill_type_id is null then
        on_flag   := -1;
        os_prompt := '单据类型ID传入为空！';
        return;
    elsif is_business_state is null then
        on_flag   := -1;
        os_prompt := '单据状态传入为空！';
        return;
    elsif id_transaction_date is null then
        on_flag   := -1;
        os_prompt := '业务日期传入为空！';
        return;
    elsif in_business_header_id is null then
        on_flag   := -1;
        os_prompt := '业务单据头ID传入为空！';
        return;
    elsif in_if_null is null then
        on_flag   := -1;
        os_prompt := '是否为空业务单据传入为空！';
        return;
    end if;

END check_is_null;

--检测是否调用物料事务
PROCEDURE check_transaction_yesOrNo_p(
    in_entity_id            IN    T_INV_TRANSACTION_HISTORY.entity_id%TYPE,--经营主体ID
    in_bill_type_id            IN    T_INV_BILL_TYPES.bill_type_id%TYPE,--单据类型ID
    is_business_state        IN    T_INV_TRANSACTION_HISTORY.business_state%TYPE,--单据状态
    os_transaction_flag        OUT    VARCHAR2,--是否调用物料事物 是（Y）、否（N）
    on_flag                    OUT    NUMBER,
    os_prompt                OUT    VARCHAR2
)AS
    vn_types_count            number;
    vn_line_count            number;
BEGIN
    on_flag   := 0;

    os_prompt := '单据类型';
    select bill_period_head_id,source_type_id,negative_inventory_flag
    into pkgn_head_id,pkgn_source_type_id,pkgs_bill_type_flag
    from t_inv_bill_types
    where entity_id = in_entity_id and bill_type_id = in_bill_type_id and begin_date <=pkgd_transaction_date and (end_date >= pkgd_transaction_date or end_date is null);

    os_prompt := '单据周期行';
    select transaction_flag
    into pkgs_transaction_flag
    from t_inv_bill_period_line
    where bill_period_head_id = pkgn_head_id and bill_status_code = is_business_state;
    os_transaction_flag:=pkgs_transaction_flag;

    if pkgs_transaction_flag ='N' then
        os_prompt := '不需要调用物料事务';
        return;
    else
        select transaction_type_id
        into pkgn_transaction_type_id
        from t_inv_bill_period_line
        where bill_period_head_id = pkgn_head_id and bill_status_code = is_business_state;

        pkgn_entity_id := in_entity_id;
        pkgs_business_state := is_business_state;

        os_prompt := '物料事务类型';
        select action_type into pkgs_action_type
        from t_inv_transaction_types
        where entity_id = pkgn_entity_id and transaction_type_id = pkgn_transaction_type_id and begin_date <=pkgd_transaction_date and (end_date >= pkgd_transaction_date or end_date is null);

        pkgn_bill_type_id:=in_bill_type_id;
    end if;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        on_flag:=0;--未找到配置数据，默认不需要调用物料事务，返回0
        os_transaction_flag:='N';
        os_prompt:='未找到配置数据:'||os_prompt;
        --rollback;        在java里检查on_flag，来判断是否进行事务回滚（通过抛出异常方式进行回滚）或提交
        return;
    WHEN OTHERS THEN
        on_flag := -1;
        os_transaction_flag:='N';
        os_prompt := '调用check_transaction_yesOrNo_p时发生异常！';
        --rollback;
        return;
END check_transaction_yesOrNo_p;

PROCEDURE init_p(
    in_business_header_id    IN    T_INV_TRANSACTION_HISTORY.business_header_id%TYPE,--业务单据头ID
    is_bill_kind                IN        VARCHAR2,--B1（采购中转）、B2（仓库调拨）、B3（仓库盘点）、B4（销售）、B5（推广物料）
    is_business_state        IN    T_INV_TRANSACTION_HISTORY.business_state%TYPE,--单据状态
    on_flag                    OUT    NUMBER,
    os_prompt                OUT    VARCHAR2
)AS
    vn_transaction_quantity        T_INV_TRANSACTION_HISTORY.TRANSACTION_QUANTITY%TYPE;
    so_data PKG_SO_BIZ.BILL_DATA_INV_ARRAY;
    a                                NUMBER:=0;
BEGIN
    on_flag   := 0;
    os_prompt := '';
    --调业务单据的过程，返回业务单据信息
    PKG_SO_BIZ.P_BILL_DATA_FOR_INV(is_bill_kind,is_business_state,in_business_header_id,so_data,on_flag,os_prompt);
    if on_flag<0 then
        os_prompt := '调用业务单据接口失败，原因：'||os_prompt;
        --rollback;
        return;
    else
        if so_data.count = 0 then
            on_flag := -1;
            os_prompt := '调用业务单据接口,返回业务单据信息为空';
            --rollback;
            return;
        end if;
    end if;

    FOR i IN 1..so_data.count LOOP
        a:=a+1;
        ty_bill(a).header_id := so_data(i).bill_id;--头ID
        ty_bill(a).line_id := so_data(i).line_id;--行ID
        ty_bill(a).line_detail_id := so_data(i).line_detail_id;--行明细ID
        ty_bill(a).item_id := so_data(i).item_id;
        ty_bill(a).item_code := so_data(i).item_code;--产品ID
        ty_bill(a).item_name := so_data(i).item_name;--产品编码
        ty_bill(a).transaction_uom := so_data(i).item_uom;--单位
        ty_bill(a).inventory_id := so_data(i).src_inv_id;--仓库ID
        --01 入库 ,02 出库 ,03 转移(第一条是出库，第二条是入库）
        select decode(pkgs_action_type,'01',so_data(i).item_qty,'02',-so_data(i).item_qty,'03',-so_data(i).item_qty)
        into vn_transaction_quantity
        from dual;
        ty_bill(a).transaction_quantity := vn_transaction_quantity;--数量
        ty_bill(a).created_by := so_data(i).created_by;--操作人
        ty_bill(a).to_inventory_id := so_data(i).target_inv_id;--目的仓库ID

        --转移时，需要多生成一条目的仓库的业务单据信息
        if so_data(i).target_inv_id is not null then
            a:=a+1;
            ty_bill(a).header_id := so_data(i).bill_id;--头ID
            ty_bill(a).line_id := so_data(i).line_id;--行ID
            ty_bill(a).line_detail_id := so_data(i).line_detail_id;--行明细ID
            ty_bill(a).item_id := so_data(i).item_id;--产品ID
            ty_bill(a).item_code := so_data(i).item_code;--产品编码
            ty_bill(a).item_name := so_data(i).item_name;--产品名称
            ty_bill(a).transaction_uom := so_data(i).item_uom;--单位
            ty_bill(a).inventory_id := so_data(i).target_inv_id;--仓库ID
            ty_bill(a).transaction_quantity := -vn_transaction_quantity;--数量,目的仓库的数量转为正数
            ty_bill(a).created_by := so_data(i).created_by;--操作人
            ty_bill(a).from_inventory_id := so_data(i).src_inv_id;--源仓库ID
        end if;

    END LOOP;
    pkgn_business_header_id := in_business_header_id;
    pkgn_created_by:=ty_bill(1).created_by;
    pkgd_sysdate:=sysdate;
    pkgs_business_num := so_data(1).bill_num;
EXCEPTION
    WHEN OTHERS THEN
        on_flag   := -1;
        os_prompt := '调用init_p时发生异常！'|| SUBSTR(SQLERRM, 1, 200);
        --rollback;
        return;
END init_p;

PROCEDURE check_bill_info(
    in_entity_id            IN    T_INV_TRANSACTION_HISTORY.entity_id%TYPE,--经营主体ID
    is_business_state        IN    T_INV_TRANSACTION_HISTORY.business_state%TYPE,--单据状态
    id_transaction_date        IN    T_INV_TRANSACTION_HISTORY.transaction_date%TYPE,--业务日期
    in_source_type_id        IN    T_INV_BILL_TYPES.source_type_id%TYPE,--单据源类型ID
    in_transaction_type_id    IN    T_INV_BILL_PERIOD_LINE.transaction_type_id%TYPE,--物料事务类型ID
    in_if_null                IN    NUMBER,--是否是空的业务单据，0否，1是
    on_flag                    OUT    NUMBER,
    os_prompt                OUT    VARCHAR2
)AS
    vn_count1                number;
    vn_count2                number;
    vn_count3                number;
    vn_count4                number;
    vn_count5                number;
    vn_count6                number;
    vn_count7                number;
    vn_count8                number;
    vs_status                T_INV_INVENTORY_PERIODS.status%TYPE;
BEGIN
    on_flag   := 0;
    os_prompt := '';

    --1、单据源类型是否存在、有效
    select count(*) into vn_count1
    from t_inv_source_types
    where entity_id = in_entity_id and source_type_id = in_source_type_id and begin_date <=id_transaction_date
    and (end_date >= id_transaction_date or end_date is null);
    if vn_count1=0 then
        on_flag:=-1;
        os_prompt:='单据源类型：'||in_source_type_id||'缺少有效的配置信息！';
        --rollback;
        return;
    end if;

    --2、物料事务类型是否存在、有效
    select count(*) into vn_count2
    from t_inv_transaction_types
    where entity_id = in_entity_id and transaction_type_id = in_transaction_type_id and begin_date <=id_transaction_date
    and (end_date >= id_transaction_date or end_date is null);
    if vn_count2=0 then
        on_flag:=-1;
        os_prompt:='物料事务类型：'||in_transaction_type_id||'缺少有效的配置信息！';
        --rollback;
        return;
    end if;

    --3、业务日期是否落在一个存货会计期间，会计期间是否打开
    BEGIN
        select period_id,status,period_name
        into pkgn_period_id,vs_status,pkgs_period_name
        from t_inv_inventory_periods
        where entity_id = pkgn_entity_id  and begin_date <=id_transaction_date and (end_date >= id_transaction_date or end_date is null);
        if vs_status='00' then
            on_flag:=-1;
            os_prompt:= '业务日期：'||pkgn_entity_id||'所在的会计期间：'||pkgn_period_id||'状态关闭！';
            --rollback;
            return;
        end if;
    EXCEPTION
    WHEN NO_DATA_FOUND THEN
        on_flag:=-1;
        os_prompt:= '业务日期：'||pkgn_entity_id||'未找到对应的会计期间';
        --rollback;
        return;
    END;

    --4、单据周期是否存在、有效
    select count(*) into vn_count5
    from t_inv_bill_period_head
    where entity_id = pkgn_entity_id and bill_period_head_id = pkgn_head_id and begin_date <=id_transaction_date
    and (end_date >= id_transaction_date or end_date is null);
    if vn_count5=0 then
        on_flag:=-1;
        os_prompt:='单据周期维护头表，ID：'||pkgn_head_id||'缺少有效的配置信息！';
        --rollback;
        return;
    end if;

    if in_if_null = 0 then--不是空业务单据时才检测产品、仓库
        --循环校验每条业务单据信息中的产品和仓库
        FOR i IN 1..ty_bill.count LOOP
            --5、产品ID是否存在、有效
            select count(*) into vn_count3
            from t_bd_item where item_id = ty_bill(i).item_id and active_flag = 'Y';
            if vn_count3 = 0 then
                on_flag:=-1;
                os_prompt:= '产品：'||ty_bill(i).item_id||'缺少有效的配置信息！';
                --rollback;
                return;
            end if;
            --6、仓库ID是否存在、有效，转移的情况下，来源仓、目的仓都要校验
            select count(*) into vn_count4
            from t_inv_inventories where inventory_id = ty_bill(i).inventory_id and begin_date <=id_transaction_date
            and (end_date >= id_transaction_date or end_date is null);
            if vn_count4 = 0 then
                on_flag:=-1;
                os_prompt:= '1仓库：'||ty_bill(i).inventory_id||'缺少有效的配置信息！';
                --rollback;
                return;
            else
                select inventory_code,inventory_name
                into ty_bill(i).inventory_code,ty_bill(i).inventory_name
                from t_inv_inventories where inventory_id = ty_bill(i).inventory_id and begin_date <=id_transaction_date
                and (end_date >= id_transaction_date or end_date is null);
                if ty_bill(i).to_inventory_id is not null then
                    select count(*) into vn_count7
                    from t_inv_inventories where inventory_id = ty_bill(i).to_inventory_id and begin_date <=id_transaction_date
                    and (end_date >= id_transaction_date or end_date is null);
                    if vn_count7 = 0 then
                        on_flag:=-1;
                        os_prompt:= '2仓库：'||ty_bill(i).to_inventory_id||'缺少有效的配置信息！';
                        --rollback;
                        return;
                    else
                        select inventory_code,inventory_name
                        into ty_bill(i).to_inventory_code,ty_bill(i).to_inventory_name
                        from t_inv_inventories where inventory_id = ty_bill(i).to_inventory_id and begin_date <=id_transaction_date
                        and (end_date >= id_transaction_date or end_date is null);
                    end if;

                elsif ty_bill(i).from_inventory_id is not null then
                    select count(*) into vn_count8
                    from t_inv_inventories where inventory_id = ty_bill(i).from_inventory_id and begin_date <=id_transaction_date
                    and (end_date >= id_transaction_date or end_date is null);
                    if vn_count8 = 0 then
                        on_flag:=-1;
                        os_prompt:= '3仓库：'||ty_bill(i).from_inventory_id||'缺少有效的配置信息！';
                        --rollback;
                        return;
                    else
                        select inventory_code,inventory_name
                        into ty_bill(i).from_inventory_code,ty_bill(i).from_inventory_name
                        from t_inv_inventories where inventory_id = ty_bill(i).from_inventory_id and begin_date <=id_transaction_date
                        and (end_date >= id_transaction_date or end_date is null);
                    end if;

                end if;
            end if;

        END LOOP;
    END IF;

EXCEPTION
    WHEN OTHERS THEN
        on_flag   := -1;
        os_prompt := '调用check_bill_info时发生异常！'|| SUBSTR(SQLERRM, 1, 200);
        --rollback;
        return;
END check_bill_info;

--写物料事务历史
PROCEDURE inv_transaction_deal(
    in_if_null                IN    NUMBER,--是否是空的业务单据，0否，1是
    on_flag                    OUT    NUMBER,
    os_prompt                OUT    VARCHAR2
)AS
    vn_count1                    number;
    vn_count2                    number;
    vn_transaction_quantity        number;
    vn_history_id                number;
    vn_quantity                    number;
    vn_bill_inventory_id        number;
    vn_bill_item_id                number;
    vs_same                        varchar2(1000);
    vs_new                        varchar2(1000);

    CURSOR get_transaction_history IS--上次业务单据有值，本次业务单据为空
        select ITEM_ID,INVENTORY_ID,sum(transaction_quantity) transaction_quantity
        from t_inv_transaction_history
        where entity_id = pkgn_entity_id and business_state = pkgs_business_state and bill_type_id = pkgn_bill_type_id and business_header_id = pkgn_business_header_id
        group by item_id,inventory_id having sum(transaction_quantity)<>0;
    c_get_history        get_transaction_history%ROWTYPE;

    CURSOR get_transaction_same IS
        select *
        from t_inv_transaction_history
        where entity_id = pkgn_entity_id and business_state = pkgs_business_state and bill_type_id = pkgn_bill_type_id
        and business_header_id = pkgn_business_header_id
        and inventory_id = vn_bill_inventory_id and item_id = vn_bill_item_id;
    c_get_same        get_transaction_same%ROWTYPE;

    type mycur is ref cursor;
    v_cur                        mycur;
    v_sql varchar2(2000);
    v_business_header_id            t_inv_transaction_history.business_header_id%TYPE;
    v_business_line_id                t_inv_transaction_history.business_line_id%TYPE;
    v_business_line_detail_id        t_inv_transaction_history.business_line_detail_id%TYPE;
    v_item_id                        t_inv_transaction_history.item_id%TYPE;
    v_item_code                        t_inv_transaction_history.item_code%TYPE;
    v_item_name                        t_inv_transaction_history.item_name%TYPE;
    v_transaction_uom                t_inv_transaction_history.transaction_uom%TYPE;
    v_inventory_id                    t_inv_transaction_history.inventory_id%TYPE;
    v_inventory_code                t_inv_transaction_history.inventory_code%TYPE;
    v_inventory_name                t_inv_transaction_history.inventory_name%TYPE;
    v_to_inventory_id                t_inv_transaction_history.to_inventory_id%TYPE;
    v_to_inventory_code                t_inv_transaction_history.to_inventory_code%TYPE;
    v_to_inventory_name                t_inv_transaction_history.to_inventory_name%TYPE;
    v_from_inventory_id                t_inv_transaction_history.from_inventory_id%TYPE;
    v_from_inventory_code            t_inv_transaction_history.from_inventory_code%TYPE;
    v_from_inventory_name            t_inv_transaction_history.from_inventory_name%TYPE;
    v_transaction_quantity            t_inv_transaction_history.transaction_quantity%TYPE;
    v_created_by                    t_inv_transaction_history.created_by%TYPE;
    vn_detail_id                    t_inv_transaction_history.business_line_detail_id%TYPE;

BEGIN
    on_flag   := 0;
    os_prompt := '';

    if pkgn_if_his = 0 then --第一次调物料事物 或者 上次调物料事物处理时业务单据为空
        --in_if_null = 1是，上次和本次业务单据为空，不做处理
        if in_if_null = 0 then --上次业务单据为空，本次不为空，做insert操作
            FOR i IN 1..ty_bill.count LOOP
                vn_history_id := s_inv_transaction_history.nextval;
                insert into t_inv_transaction_history(ENTITY_ID,TRANSACTION_ID,TRANSACTION_DATE,PERIOD_ID,PERIOD_NAME,
                                                    SOURCE_TYPE_ID,BUSINESS_STATE,TRANSACTION_TYPE_ID,ACTION_TYPE,BUSINESS_HEADER_ID,
                                                    BUSINESS_LINE_ID,BUSINESS_LINE_DETAIL_ID,ITEM_ID,ITEM_CODE,ITEM_NAME,
                                                    TRANSACTION_UOM,INVENTORY_ID,INVENTORY_CODE,INVENTORY_NAME,TO_INVENTORY_ID,
                                                    TO_INVENTORY_CODE,TO_INVENTORY_NAME,FROM_INVENTORY_ID,FROM_INVENTORY_CODE,FROM_INVENTORY_NAME,
                                                    TRANSACTION_QUANTITY,CREATED_BY,CREATION_DATE,LAST_UPDATED_BY,LAST_UPDATE_DATE,
                                                    REMARK,BILL_TYPE_ID,BUSINESS_NUM)
                values(pkgn_entity_id,vn_history_id,pkgd_transaction_date,pkgn_period_id,pkgs_period_name,
                        pkgn_source_type_id,pkgs_business_state,pkgn_transaction_type_id,pkgs_action_type,ty_bill(i).header_id,
                        ty_bill(i).line_id,ty_bill(i).line_detail_id,ty_bill(i).item_id,ty_bill(i).item_code,ty_bill(i).item_name,
                        ty_bill(i).transaction_uom,ty_bill(i).inventory_id,ty_bill(i).inventory_code,ty_bill(i).inventory_name,ty_bill(i).to_inventory_id,
                        ty_bill(i).to_inventory_code,ty_bill(i).to_inventory_name,ty_bill(i).from_inventory_id,ty_bill(i).from_inventory_code,ty_bill(i).from_inventory_name,
                        ty_bill(i).transaction_quantity,ty_bill(i).created_by,pkgd_sysdate,null,null,
                        null,pkgn_bill_type_id,pkgs_business_num);

                select to_char(vn_history_id) into vs_new from dual;
                if pkgs_new_str is null then
                    pkgs_new_str := vs_new;
                else
                    pkgs_new_str := vs_new||','||pkgs_new_str;
                end if;

            END LOOP;
        end if;

    elsif pkgn_if_his = 1 then --上次调物料事物处理时业务单据有值
        if in_if_null = 1 then --本次业务单据为空
            for c_get_history in get_transaction_history loop
                vn_history_id := s_inv_transaction_history.nextval;
                --取当前最近的行明细ID
                select max(business_line_detail_id) into vn_detail_id
                from t_inv_transaction_history
                where entity_id = pkgn_entity_id and business_state = pkgs_business_state and bill_type_id = pkgn_bill_type_id and business_header_id = pkgn_business_header_id
                and item_id = c_get_history.item_id and inventory_id = c_get_history.inventory_id;

                insert into t_inv_transaction_history(ENTITY_ID,TRANSACTION_ID,TRANSACTION_DATE,PERIOD_ID,PERIOD_NAME,
                                                    SOURCE_TYPE_ID,BUSINESS_STATE,TRANSACTION_TYPE_ID,ACTION_TYPE,BUSINESS_HEADER_ID,
                                                    BUSINESS_LINE_ID,BUSINESS_LINE_DETAIL_ID,ITEM_ID,ITEM_CODE,ITEM_NAME,
                                                    TRANSACTION_UOM,INVENTORY_ID,INVENTORY_CODE,INVENTORY_NAME,TO_INVENTORY_ID,
                                                    TO_INVENTORY_CODE,TO_INVENTORY_NAME,FROM_INVENTORY_ID,FROM_INVENTORY_CODE,FROM_INVENTORY_NAME,
                                                    TRANSACTION_QUANTITY,CREATED_BY,CREATION_DATE,LAST_UPDATED_BY,LAST_UPDATE_DATE,
                                                    REMARK,BILL_TYPE_ID,BUSINESS_NUM)
                select pkgn_entity_id,vn_history_id,transaction_date,period_id,period_name,
                        source_type_id,pkgs_business_state,transaction_type_id,action_type,business_header_id,
                        business_line_id,business_line_detail_id,item_id,item_code,item_name,
                        transaction_uom,inventory_id,inventory_code,inventory_name,to_inventory_id,
                        to_inventory_code,to_inventory_name,from_inventory_id,from_inventory_code,from_inventory_name,
                        c_get_history.transaction_quantity*(-1),created_by,pkgd_sysdate,null,null,
                        null,pkgn_bill_type_id,pkgs_business_num
                from t_inv_transaction_history
                where entity_id = pkgn_entity_id and business_state = pkgs_business_state and bill_type_id = pkgn_bill_type_id and business_header_id = pkgn_business_header_id
                and business_line_detail_id = vn_detail_id
                and item_id = c_get_history.item_id and inventory_id = c_get_history.inventory_id;

                select to_char(vn_history_id) into vs_new from dual;
                if pkgs_new_str is null then
                    pkgs_new_str := vs_new;
                else
                    pkgs_new_str := vs_new||','||pkgs_new_str;

                end if;
            end loop;
        elsif in_if_null = 0 then --本次业务单据有值
            FOR i IN 1..ty_bill.count LOOP--用本次和上次的单据比较，得到三种数据：1）都有且有差额2）都有且相同3）本次有上次没有
                select count(*) into vn_count1
                from t_inv_transaction_history
                where entity_id = pkgn_entity_id and business_state = pkgs_business_state and bill_type_id = pkgn_bill_type_id
                and business_header_id = pkgn_business_header_id
                and inventory_id = ty_bill(i).inventory_id
                and item_id = ty_bill(i).item_id;
                if vn_count1 >0 then --两次都有的单据
                    select sum(transaction_quantity) into vn_quantity
                    from t_inv_transaction_history
                    where entity_id = pkgn_entity_id and business_state = pkgs_business_state and bill_type_id = pkgn_bill_type_id
                    and business_header_id = pkgn_business_header_id
                    and inventory_id = ty_bill(i).inventory_id
                    and item_id = ty_bill(i).item_id;
                    if vn_quantity !=  ty_bill(i).transaction_quantity then--1) 两次都有，有差额的
                        vn_history_id := s_inv_transaction_history.nextval;
                        insert into t_inv_transaction_history(ENTITY_ID,TRANSACTION_ID,TRANSACTION_DATE,PERIOD_ID,PERIOD_NAME,
                                                            SOURCE_TYPE_ID,BUSINESS_STATE,TRANSACTION_TYPE_ID,ACTION_TYPE,BUSINESS_HEADER_ID,
                                                            BUSINESS_LINE_ID,BUSINESS_LINE_DETAIL_ID,ITEM_ID,ITEM_CODE,ITEM_NAME,
                                                            TRANSACTION_UOM,INVENTORY_ID,INVENTORY_CODE,INVENTORY_NAME,TO_INVENTORY_ID,
                                                            TO_INVENTORY_CODE,TO_INVENTORY_NAME,FROM_INVENTORY_ID,FROM_INVENTORY_CODE,FROM_INVENTORY_NAME,
                                                            TRANSACTION_QUANTITY,CREATED_BY,CREATION_DATE,LAST_UPDATED_BY,LAST_UPDATE_DATE,
                                                            REMARK,BILL_TYPE_ID,BUSINESS_NUM)
                        values(pkgn_entity_id,vn_history_id,pkgd_transaction_date,pkgn_period_id,pkgs_period_name,
                                pkgn_source_type_id,pkgs_business_state,pkgn_transaction_type_id,pkgs_action_type,ty_bill(i).header_id,
                                ty_bill(i).line_id,ty_bill(i).line_detail_id,ty_bill(i).item_id,ty_bill(i).item_code,ty_bill(i).item_name,
                                ty_bill(i).transaction_uom,ty_bill(i).inventory_id,ty_bill(i).inventory_code,ty_bill(i).inventory_name,ty_bill(i).to_inventory_id,
                                ty_bill(i).to_inventory_code,ty_bill(i).to_inventory_name,ty_bill(i).from_inventory_id,ty_bill(i).from_inventory_code,ty_bill(i).from_inventory_name,
                                ty_bill(i).transaction_quantity-vn_quantity,ty_bill(i).created_by,pkgd_sysdate,null,null,
                                null,pkgn_bill_type_id,pkgs_business_num);

                        select to_char(vn_history_id) into vs_new from dual;
                        if pkgs_new_str is null then
                            pkgs_new_str := vs_new;
                        else
                            pkgs_new_str := vs_new||','||pkgs_new_str;
                        end if;
                    else--2）两次都有且全相同的
                        vn_bill_inventory_id:=ty_bill(i).inventory_id;
                        vn_bill_item_id:=ty_bill(i).item_id;
                        for c_get_same in get_transaction_same loop
                            select to_char(c_get_same.transaction_id) into vs_same from dual;
                            if pkgs_same_str is null then
                                pkgs_same_str := vs_same;
                            else
                                pkgs_same_str := vs_same||','||pkgs_same_str;
                            end if;
                        end loop;

                    end if;
                elsif vn_count1 =0 then --上次没有，本次有的单据
                    vn_history_id := s_inv_transaction_history.nextval;
                    insert into t_inv_transaction_history(ENTITY_ID,TRANSACTION_ID,TRANSACTION_DATE,PERIOD_ID,PERIOD_NAME,
                                                        SOURCE_TYPE_ID,BUSINESS_STATE,TRANSACTION_TYPE_ID,ACTION_TYPE,BUSINESS_HEADER_ID,
                                                        BUSINESS_LINE_ID,BUSINESS_LINE_DETAIL_ID,ITEM_ID,ITEM_CODE,ITEM_NAME,
                                                        TRANSACTION_UOM,INVENTORY_ID,INVENTORY_CODE,INVENTORY_NAME,TO_INVENTORY_ID,
                                                        TO_INVENTORY_CODE,TO_INVENTORY_NAME,FROM_INVENTORY_ID,FROM_INVENTORY_CODE,FROM_INVENTORY_NAME,
                                                        TRANSACTION_QUANTITY,CREATED_BY,CREATION_DATE,LAST_UPDATED_BY,LAST_UPDATE_DATE,
                                                        REMARK,BILL_TYPE_ID,BUSINESS_NUM)
                    values(pkgn_entity_id,vn_history_id,pkgd_transaction_date,pkgn_period_id,pkgs_period_name,
                            pkgn_source_type_id,pkgs_business_state,pkgn_transaction_type_id,pkgs_action_type,ty_bill(i).header_id,
                            ty_bill(i).line_id,ty_bill(i).line_detail_id,ty_bill(i).item_id,ty_bill(i).item_code,ty_bill(i).item_name,
                            ty_bill(i).transaction_uom,ty_bill(i).inventory_id,ty_bill(i).inventory_code,ty_bill(i).inventory_name,ty_bill(i).to_inventory_id,
                            ty_bill(i).to_inventory_code,ty_bill(i).to_inventory_name,ty_bill(i).from_inventory_id,ty_bill(i).from_inventory_code,ty_bill(i).from_inventory_name,
                            ty_bill(i).transaction_quantity,ty_bill(i).created_by,pkgd_sysdate,null,null,
                            null,pkgn_bill_type_id,pkgs_business_num);

                    select to_char(vn_history_id) into vs_new from dual;
                    if pkgs_new_str is null then
                        pkgs_new_str := vs_new;
                    else
                        pkgs_new_str := vs_new||','||pkgs_new_str;
                    end if;
                end if;
            END LOOP;

            --上次有本次没有的
            if pkgs_new_str is null then
                pkgs_new_str := '0';

            end if;
            if pkgs_same_str is null then
                pkgs_same_str := '0';
            end if;
            v_sql := 'select business_header_id,
                            business_line_id,business_line_detail_id,item_id,item_code,item_name,
                            transaction_uom,inventory_id,inventory_code,inventory_name,to_inventory_id,
                            to_inventory_code,to_inventory_name,from_inventory_id,from_inventory_code,from_inventory_name,
                            transaction_quantity,created_by
                    from t_inv_transaction_history
                    where entity_id = '||pkgn_entity_id||' and business_state = '||pkgs_business_state||' and bill_type_id = '||pkgn_bill_type_id||' and business_header_id = '||pkgn_business_header_id||'
                    and transaction_id not in ('||pkgs_new_str||') and transaction_id not in ('||pkgs_same_str||')';
            open v_cur for v_sql;
            loop
            fetch v_cur into v_business_header_id,
                            v_business_line_id,v_business_line_detail_id,v_item_id,v_item_code,v_item_name,
                            v_transaction_uom,v_inventory_id,v_inventory_code,v_inventory_name,v_to_inventory_id,
                            v_to_inventory_code,v_to_inventory_name,v_from_inventory_id,v_from_inventory_code,v_from_inventory_name,
                            v_transaction_quantity,v_created_by;
            exit when v_cur%notfound;
                vn_history_id := s_inv_transaction_history.nextval;
                insert into t_inv_transaction_history(ENTITY_ID,TRANSACTION_ID,TRANSACTION_DATE,PERIOD_ID,PERIOD_NAME,
                                                    SOURCE_TYPE_ID,BUSINESS_STATE,TRANSACTION_TYPE_ID,ACTION_TYPE,BUSINESS_HEADER_ID,
                                                    BUSINESS_LINE_ID,BUSINESS_LINE_DETAIL_ID,ITEM_ID,ITEM_CODE,ITEM_NAME,
                                                    TRANSACTION_UOM,INVENTORY_ID,INVENTORY_CODE,INVENTORY_NAME,TO_INVENTORY_ID,
                                                    TO_INVENTORY_CODE,TO_INVENTORY_NAME,FROM_INVENTORY_ID,FROM_INVENTORY_CODE,FROM_INVENTORY_NAME,
                                                    TRANSACTION_QUANTITY,CREATED_BY,CREATION_DATE,LAST_UPDATED_BY,LAST_UPDATE_DATE,
                                                    REMARK,BILL_TYPE_ID,BUSINESS_NUM)
                values(pkgn_entity_id,vn_history_id,pkgd_transaction_date,pkgn_period_id,pkgs_period_name,
                        pkgn_source_type_id,pkgs_business_state,pkgn_transaction_type_id,pkgs_action_type,v_business_header_id,
                        v_business_line_id,v_business_line_detail_id,v_item_id,v_item_code,v_item_name,
                        v_transaction_uom,v_inventory_id,v_inventory_code,v_inventory_name,v_to_inventory_id,
                        v_to_inventory_code,v_to_inventory_name,v_from_inventory_id,v_from_inventory_code,v_from_inventory_name,
                        v_transaction_quantity*(-1),v_created_by,pkgd_sysdate,null,null,
                        null,pkgn_bill_type_id,pkgs_business_num);

                select to_char(vn_history_id) into vs_new from dual;
                if pkgs_new_str is null then
                    pkgs_new_str := vs_new;
                else
                    pkgs_new_str := vs_new||','||pkgs_new_str;
                end if;
            end loop;
            close v_cur;
        end if;
    end if;
EXCEPTION
    WHEN OTHERS THEN
        on_flag   := -1;
        os_prompt := '调用inv_transaction_deal时发生异常！'|| SUBSTR(SQLERRM, 1, 200);
        --rollback;
        return;
END inv_transaction_deal;

PROCEDURE inv_bill_history_check(
    on_flag                    OUT    NUMBER,
    os_prompt                OUT    VARCHAR2,
    on_if_dif                OUT    NUMBER--0不同;1相同

)AS
    vn_quantity_his                number;
    vn_history_id                t_inv_transaction_history.transaction_id%TYPE;
    vs_id                        varchar2(1000);
    vs_new                        varchar2(1000);
    vs_transaction_id                varchar2(2000);
    vs_line_id                        varchar2(1000);
    type mycur is ref cursor;
    v_cur                        mycur;
    v_sql varchar2(2000);
    v_business_header_id            t_inv_transaction_history.business_header_id%TYPE;
    v_business_line_id                t_inv_transaction_history.business_line_id%TYPE;
    v_business_line_detail_id        t_inv_transaction_history.business_line_detail_id%TYPE;
    v_inventory_id                    t_inv_transaction_history.inventory_id%TYPE;
    v_item_id                        t_inv_transaction_history.item_id%TYPE;
    v_transaction_quantity            t_inv_transaction_history.transaction_quantity%TYPE;
    vn_bill_inventory_id        number;
    vn_bill_item_id                number;
    vn_detail_id                    t_inv_transaction_history.business_line_detail_id%TYPE;
    CURSOR get_transaction_id IS
        select *
        from t_inv_transaction_history
        where entity_id = pkgn_entity_id and business_state = pkgs_business_state and bill_type_id = pkgn_bill_type_id
        and business_header_id = pkgn_business_header_id
        and inventory_id = vn_bill_inventory_id and item_id = vn_bill_item_id;
    c_get_id        get_transaction_id%ROWTYPE;

BEGIN
    on_flag   := 0;
    os_prompt := '';
    vs_transaction_id:='';
    on_if_dif:=1;--默认比对结果相同
    --用业务单据和物料事务历史信息比对
    FOR i IN 1..ty_bill.count LOOP
        select sum(transaction_quantity) into vn_quantity_his
        from t_inv_transaction_history
        where entity_id = pkgn_entity_id and business_state = pkgs_business_state and bill_type_id = pkgn_bill_type_id and business_header_id = pkgn_business_header_id
        and inventory_id = ty_bill(i).inventory_id and item_id = ty_bill(i).item_id;
        if ty_bill(i).transaction_quantity <> vn_quantity_his then
            vn_history_id := s_inv_transaction_history.nextval;
            --如果不同，增加一条差额的历史记录
            insert into t_inv_transaction_history(ENTITY_ID,TRANSACTION_ID,TRANSACTION_DATE,PERIOD_ID,PERIOD_NAME,
                                                SOURCE_TYPE_ID,BUSINESS_STATE,TRANSACTION_TYPE_ID,ACTION_TYPE,BUSINESS_HEADER_ID,
                                                BUSINESS_LINE_ID,BUSINESS_LINE_DETAIL_ID,ITEM_ID,ITEM_CODE,ITEM_NAME,
                                                TRANSACTION_UOM,INVENTORY_ID,INVENTORY_CODE,INVENTORY_NAME,TO_INVENTORY_ID,
                                                TO_INVENTORY_CODE,TO_INVENTORY_NAME,FROM_INVENTORY_ID,FROM_INVENTORY_CODE,FROM_INVENTORY_NAME,
                                                TRANSACTION_QUANTITY,CREATED_BY,CREATION_DATE,LAST_UPDATED_BY,LAST_UPDATE_DATE,
                                                REMARK,BILL_TYPE_ID,BUSINESS_NUM)
            values(pkgn_entity_id,vn_history_id,pkgd_transaction_date,pkgn_period_id,pkgs_period_name,
                    pkgn_source_type_id,pkgs_business_state,pkgn_transaction_type_id,pkgs_action_type,ty_bill(i).header_id,
                    ty_bill(i).line_id,ty_bill(i).line_detail_id,ty_bill(i).item_id,ty_bill(i).item_code,ty_bill(i).item_name,
                    ty_bill(i).transaction_uom,ty_bill(i).inventory_id,ty_bill(i).inventory_code,ty_bill(i).inventory_name,ty_bill(i).to_inventory_id,
                    ty_bill(i).to_inventory_code,ty_bill(i).to_inventory_name,ty_bill(i).from_inventory_id,ty_bill(i).from_inventory_code,ty_bill(i).from_inventory_name,
                    ty_bill(i).transaction_quantity-vn_quantity_his,ty_bill(i).created_by,pkgd_sysdate,null,null,
                    null,pkgn_bill_type_id,pkgs_business_num);

            select to_char(vn_history_id) into vs_new from dual;
            if pkgs_new_str is null then
                pkgs_new_str := vs_new;
            else
                pkgs_new_str := vs_new||','||pkgs_new_str;
            end if;
            on_if_dif:=0;
        end if;
        vn_bill_inventory_id:=ty_bill(i).inventory_id;
        vn_bill_item_id:=ty_bill(i).item_id;
        for c_get_id in get_transaction_id loop
            select to_char(c_get_id.transaction_id) into vs_id from dual;
            if vs_transaction_id is null then
                vs_transaction_id := vs_id;
            else
                vs_transaction_id := vs_id||','||vs_transaction_id;
            end if;
        end loop;
    END LOOP;

    if vs_transaction_id is null then
        vs_transaction_id:='0';
    end if;
    --物料事务历史中有的，本次业务单据中没有的；并且，物料历史中的sum数量不等于0的
    v_sql := 'select inventory_id,item_id,sum(transaction_quantity) transaction_quantity
        from t_inv_transaction_history
        where entity_id = '||pkgn_entity_id||' and business_state = '''||pkgs_business_state||''' and bill_type_id = '||pkgn_bill_type_id||' and business_header_id = '||pkgn_business_header_id||
        'and transaction_id not in ('||vs_transaction_id||') group by inventory_id,item_id having sum(transaction_quantity) <> 0';
    open v_cur for v_sql;
    loop
    fetch v_cur into v_inventory_id,v_item_id,v_transaction_quantity;
    exit when v_cur%notfound;
        --增加差额红冲记录
        vn_history_id := s_inv_transaction_history.nextval;

        --取当前最近的行明细ID
        select max(business_line_detail_id) into vn_detail_id
        from t_inv_transaction_history
        where entity_id = pkgn_entity_id and business_state = pkgs_business_state and bill_type_id = pkgn_bill_type_id and business_header_id = pkgn_business_header_id
        and item_id = v_item_id and inventory_id = v_inventory_id;

        insert into t_inv_transaction_history(ENTITY_ID,TRANSACTION_ID,TRANSACTION_DATE,PERIOD_ID,PERIOD_NAME,
                                            SOURCE_TYPE_ID,BUSINESS_STATE,TRANSACTION_TYPE_ID,ACTION_TYPE,BUSINESS_HEADER_ID,
                                            BUSINESS_LINE_ID,BUSINESS_LINE_DETAIL_ID,ITEM_ID,ITEM_CODE,ITEM_NAME,
                                            TRANSACTION_UOM,INVENTORY_ID,INVENTORY_CODE,INVENTORY_NAME,TO_INVENTORY_ID,
                                            TO_INVENTORY_CODE,TO_INVENTORY_NAME,FROM_INVENTORY_ID,FROM_INVENTORY_CODE,FROM_INVENTORY_NAME,
                                            TRANSACTION_QUANTITY,CREATED_BY,CREATION_DATE,LAST_UPDATED_BY,LAST_UPDATE_DATE,
                                            REMARK,BILL_TYPE_ID,BUSINESS_NUM)
        select pkgn_entity_id,vn_history_id,transaction_date,period_id,period_name,
                source_type_id,pkgs_business_state,transaction_type_id,action_type,business_header_id,
                business_line_id,business_line_detail_id,item_id,item_code,item_name,
                transaction_uom,inventory_id,inventory_code,inventory_name,to_inventory_id,
                to_inventory_code,to_inventory_name,from_inventory_id,from_inventory_code,from_inventory_name,
                v_transaction_quantity*(-1),created_by,pkgd_sysdate,null,null,
                null,pkgn_bill_type_id,pkgs_business_num
        from t_inv_transaction_history
        where entity_id = pkgn_entity_id and business_state = pkgs_business_state and bill_type_id = pkgn_bill_type_id and business_header_id = pkgn_business_header_id
        and business_line_detail_id = vn_detail_id
        and item_id = v_item_id and inventory_id = v_inventory_id;

        select to_char(vn_history_id) into vs_new from dual;
        if pkgs_new_str is null then
            pkgs_new_str := vs_new;
        else
            pkgs_new_str := vs_new||','||pkgs_new_str;
        end if;

        on_if_dif:=0;
    end loop;
    close v_cur;
EXCEPTION
    WHEN OTHERS THEN
        on_flag   := -1;
        os_prompt := '调用inv_bill_history_check时发生异常！'|| SUBSTR(SQLERRM, 1, 200);
        --rollback;
        return;
END inv_bill_history_check;

PROCEDURE inv_update_onhand(
    id_transaction_date        IN    T_INV_TRANSACTION_HISTORY.transaction_date%TYPE,--业务日期
    on_flag                    OUT    NUMBER,
    os_prompt                OUT    VARCHAR2
)AS
    vn_quantity                t_inv_transaction_history.transaction_quantity%TYPE;
    vn_count                    NUMBER;
    type mycur is ref cursor;
    v_cur                        mycur;
    v_sql varchar2(2000);
    v_quantity                    t_inv_transaction_history.transaction_quantity%TYPE;
    v_inventory_id                t_inv_transaction_history.inventory_id%TYPE;
    v_item_id                    t_inv_transaction_history.item_id%TYPE;
    v_transaction_uom            t_inv_transaction_history.transaction_uom%TYPE;
    v_transaction_id            t_inv_transaction_history.transaction_id%TYPE;
    v_last_updated_by            t_inv_transaction_history.last_updated_by%TYPE;
    v_created_by                t_inv_transaction_history.created_by%TYPE;
    vs_inv_flag                    t_inv_inventories.negative_inventory_flag%TYPE;
BEGIN
    on_flag   := 0;
    os_prompt := '';
    if pkgs_new_str is not null then--只有在产生差额时更新现有量表
        v_sql := 'select transaction_quantity quantity,inventory_id,item_id,transaction_uom,transaction_id,last_updated_by,created_by
            from t_inv_transaction_history
            where entity_id = '||pkgn_entity_id||' and business_state = '''||pkgs_business_state||''' and bill_type_id = '||pkgn_bill_type_id||' and business_header_id = '||pkgn_business_header_id||
            'and transaction_id in ('||pkgs_new_str||')';
        open v_cur for v_sql;
        loop
        fetch v_cur into v_quantity,v_inventory_id,v_item_id,v_transaction_uom,v_transaction_id,v_last_updated_by,v_created_by;
        exit when v_cur%notfound;
            select count(*) into vn_count
            from t_inv_onhand
            where entity_id = pkgn_entity_id and inventory_id = v_inventory_id and item_id = v_item_id;

            select negative_inventory_flag
            into vs_inv_flag
            from t_inv_inventories where inventory_id = v_inventory_id and begin_date <=id_transaction_date
            and (end_date >= id_transaction_date or end_date is null);

            if vn_count=0 then
                --判断现有量是否可以小于零
                if pkgs_bill_type_flag = 'N' and vs_inv_flag = 'N' and v_quantity < 0 then
                    on_flag   := -1;
                    os_prompt := '更新现有量表异常！经营主体:'||pkgn_entity_id||';仓库:'||v_inventory_id||';产品:'||v_item_id
                            ||'的现有量不可以小于零';
                    return;
                end if;
                insert into t_inv_onhand(CREATED_BY,CREATION_DATE,DATE_RECEIVED,ENTITY_ID,INVENTORY_ID,
                                        INV_ID,ITEM_ID,LAST_TRANSACTION_ID,LAST_UPDATED_BY,LAST_UPDATE_DATE,
                                        QUANTITY,REMARK,TRANSACTION_UOM)
                values(v_created_by,pkgd_sysdate,pkgd_sysdate,pkgn_entity_id,v_inventory_id,
                        s_inv_current_inventory.nextval,v_item_id,v_transaction_id,null,null,
                        v_quantity,null,v_transaction_uom);
            else
                select quantity into vn_quantity
                from t_inv_onhand
                where entity_id = pkgn_entity_id and inventory_id = v_inventory_id and item_id = v_item_id;

                vn_quantity := vn_quantity+v_quantity;
                --判断现有量是否可以小于零
                if pkgs_bill_type_flag = 'N' and vs_inv_flag = 'N' and v_quantity < 0 then
                    on_flag   := -1;
                    os_prompt := '更新现有量表异常！经营主体:'||pkgn_entity_id||';仓库:'||v_inventory_id||';产品:'||v_item_id
                            ||'的现有量不可以小于零';
                    return;
                end if;

                update t_inv_onhand
                set quantity = vn_quantity,
                    last_updated_by = v_last_updated_by,
                    last_update_date = pkgd_sysdate
                where entity_id = pkgn_entity_id and inventory_id = v_inventory_id and item_id = v_item_id;
            end if;

        end loop;
        close v_cur;
    end if;

EXCEPTION
    WHEN OTHERS THEN
        on_flag   := -1;
        os_prompt := '调用inv_update_onhand时发生异常！'|| SUBSTR(SQLERRM, 1, 200);
        --rollback;
        return;
END inv_update_onhand;

PROCEDURE inv_update_reconciliation(
    in_if_null                IN    NUMBER,--是否是空的业务单据，0否，1是
    on_flag                    OUT    NUMBER,
    os_prompt                OUT    VARCHAR2
)AS

BEGIN
--不做特殊处理，每次都只记录本次业务单据的信息
    on_flag   := 0;
    os_prompt := '';

    delete from t_inv_reconciliation
    where entity_id = pkgn_entity_id and business_header_id = pkgn_business_header_id;

    if in_if_null = 0 then --本次业务单据不为空，才记录对帐表
        insert into t_inv_reconciliation(ENTITY_ID,RECONCILIATION_ID,BUSINESS_HEADER_ID,BUSINESS_STATE,BILL_TYPE_ID,
                                        SOURCE_TYPE_ID,TRANSACTION_TYPE_ID,ACTION_TYPE,STATUS,CREATED_BY,
                                        CREATION_DATE,LAST_UPDATED_BY,LAST_UPDATE_DATE,REMARK)
        values(pkgn_entity_id,s_inv_reconciliation.nextval,pkgn_business_header_id,pkgs_business_state,pkgn_bill_type_id,
        pkgn_source_type_id,pkgn_transaction_type_id,pkgs_action_type,'01',pkgn_created_by,
        pkgd_sysdate,null,null,null);
    end if;
EXCEPTION
    WHEN OTHERS THEN
        on_flag   := -1;
        os_prompt := '调用inv_update_reconciliation时发生异常！'|| SUBSTR(SQLERRM, 1, 200);
        --rollback;
        return;
END inv_update_reconciliation;

--重算时的特殊处理
PROCEDURE recount_transaction_deal_p(
    in_entity_id            IN    T_INV_TRANSACTION_HISTORY.entity_id%TYPE,--经营主体ID
    in_business_header_id    IN    T_INV_TRANSACTION_HISTORY.business_header_id%TYPE,--业务单据头ID
    in_bill_type_id            IN    T_INV_BILL_TYPES.bill_type_id%TYPE,--单据类型ID
    on_flag                    OUT    NUMBER,
    os_prompt                OUT    VARCHAR2
)AS
     CURSOR get_transaction_history IS
        select business_state,business_header_id,business_line_id,business_line_detail_id,inventory_id,item_id,sum(transaction_quantity) transaction_quantity
        from t_inv_transaction_history
        where entity_id = in_entity_id and business_header_id = in_business_header_id and bill_type_id = in_bill_type_id
        group by business_state,business_header_id,business_line_id,business_line_detail_id,inventory_id,item_id
        having sum(transaction_quantity) <> 0;
    c_get_history        get_transaction_history%ROWTYPE;
    vn_history_id            t_inv_transaction_history.transaction_id%TYPE;

BEGIN
    on_flag   := 0;
    os_prompt := '';
    --重算时的特殊处理：业务单据空，物料历史有数据的情况。全部做差额红冲处理。
    for c_get_history in get_transaction_history loop
        vn_history_id := s_inv_transaction_history.nextval;
        insert into t_inv_transaction_history(ENTITY_ID,TRANSACTION_ID,TRANSACTION_DATE,PERIOD_ID,PERIOD_NAME,
                                            SOURCE_TYPE_ID,BUSINESS_STATE,TRANSACTION_TYPE_ID,ACTION_TYPE,BUSINESS_HEADER_ID,
                                            BUSINESS_LINE_ID,BUSINESS_LINE_DETAIL_ID,ITEM_ID,ITEM_CODE,ITEM_NAME,
                                            TRANSACTION_UOM,INVENTORY_ID,INVENTORY_CODE,INVENTORY_NAME,TO_INVENTORY_ID,
                                            TO_INVENTORY_CODE,TO_INVENTORY_NAME,FROM_INVENTORY_ID,FROM_INVENTORY_CODE,FROM_INVENTORY_NAME,
                                            TRANSACTION_QUANTITY,CREATED_BY,CREATION_DATE,LAST_UPDATED_BY,LAST_UPDATE_DATE,
                                            REMARK,BILL_TYPE_ID,BUSINESS_NUM)
        select entity_id,vn_history_id,transaction_date,period_id,period_name,
                source_type_id,business_state,transaction_type_id,action_type,business_header_id,
                business_line_id,business_line_detail_id,item_id,item_code,item_name,
                transaction_uom,inventory_id,inventory_code,inventory_name,to_inventory_id,
                to_inventory_code,to_inventory_name,from_inventory_id,from_inventory_code,from_inventory_name,
                c_get_history.transaction_quantity*(-1),created_by,creation_date,last_updated_by,last_update_date,
                remark,bill_type_id,business_num
        from t_inv_transaction_history
        where entity_id = in_entity_id and business_header_id = in_business_header_id
        and business_state = c_get_history.business_state
        and bill_type_id = in_bill_type_id
        and business_header_id = c_get_history.business_header_id
        and business_line_id = c_get_history.business_line_id
        and nvl(business_line_detail_id,-1) = nvl(c_get_history.business_line_detail_id,-1)
        and inventory_id = c_get_history.inventory_id
        and item_id = c_get_history.item_id
        and rownum = 1;

    end loop;

EXCEPTION
    WHEN OTHERS THEN
        on_flag   := -1;
        os_prompt := '调用recount_transaction_deal_p时发生异常！'|| SUBSTR(SQLERRM, 1, 200);
        --rollback;
        return;
END recount_transaction_deal_p;

--物料事务处理总过程
PROCEDURE inv_transaction_total_deal(
    in_entity_id            IN    T_INV_TRANSACTION_HISTORY.entity_id%TYPE,--经营主体ID
    in_bill_type_id            IN    T_INV_BILL_TYPES.bill_type_id%TYPE,--单据类型ID
    is_business_state        IN    T_INV_TRANSACTION_HISTORY.business_state%TYPE,--单据状态
    id_transaction_date        IN    T_INV_TRANSACTION_HISTORY.transaction_date%TYPE,--业务日期
    in_business_header_id    IN    T_INV_TRANSACTION_HISTORY.business_header_id%TYPE,--业务单据头ID
    in_if_null                IN    NUMBER,--是否是空的业务单据，0否，1是
    is_bill_kind                IN        VARCHAR2,--B1（采购中转）、B2（仓库调拨）、B3（仓库盘点）、B4（销售）、B5（推广物料）、ISNULL（业务单空物料历史有数据）
    on_flag                    OUT    NUMBER,
    os_prompt                OUT    VARCHAR2
)AS
    vn_count1                NUMBER;
    vn_if_dif                NUMBER;--业务单据和物料事务历史信息比对，不同0，相同1
    vs_transaction_flag        t_inv_bill_period_line.transaction_flag%TYPE;
BEGIN
    on_flag   := 0;
    os_prompt := '';
    pkgs_same_str :='';--前后两次相同的历史ID串
    pkgs_new_str :='';--本次insert的历史ID串
    if is_bill_kind = 'ISNULL' then
        --重算时的特殊处理：业务单据空，物料历史有数据的情况
        recount_transaction_deal_p(in_entity_id,in_business_header_id,in_bill_type_id,on_flag,os_prompt);
        RETURN;
    end if;

    --对前台录入参数的为空校验
    check_is_null(in_entity_id,in_bill_type_id,is_business_state,id_transaction_date,in_business_header_id,in_if_null,on_flag,os_prompt);
    IF on_flag < 0 THEN
        RETURN;
    END IF;

    pkgd_transaction_date:=id_transaction_date;
    pkgn_bill_type_id:=in_bill_type_id;
    pkgn_if_null:=in_if_null;

    --校验是否已生成物料事务历史
    select count(*) into vn_count1
    from t_inv_transaction_history
    where entity_id = in_entity_id and business_state = is_business_state and bill_type_id = in_bill_type_id and business_header_id = in_business_header_id;
    if vn_count1 = 0 then
        pkgn_if_his := 0;--是否已有物料事物历史记录
        if in_if_null = 1 then--前后两次业务单据都为空时，不做物料事物处理
            on_flag   := 0;
            os_prompt := '空的业务单据不做物料事务处理！';
            return;
        end if;
    else
        pkgn_if_his := 1;
    end if;

    --检测是否调用物料事务
    check_transaction_yesOrNo_p(in_entity_id,in_bill_type_id,is_business_state,vs_transaction_flag,on_flag,os_prompt);
    IF on_flag < 0 or vs_transaction_flag = 'N' THEN
        RETURN;
    END IF;

    --数据准备
    init_p(in_business_header_id,is_bill_kind,is_business_state,on_flag,os_prompt);
    IF on_flag < 0 THEN
        RETURN;
    END IF;

    --基本信息校验(可以单独使用)
    check_bill_info(in_entity_id,is_business_state,id_transaction_date,pkgn_source_type_id,pkgn_transaction_type_id,in_if_null,on_flag,os_prompt);
    IF on_flag < 0 THEN
        RETURN;
    END IF;

    --写物料事务历史
    inv_transaction_deal(in_if_null,on_flag,os_prompt);
    IF on_flag < 0 THEN
        RETURN;
    END IF;

    --比对业务单据和历史表的数据是否一致
    inv_bill_history_check(on_flag,os_prompt,vn_if_dif);
    IF on_flag < 0 THEN
        RETURN;
    else
        if vn_if_dif=0 then--如果比对结果不平，重新比对更新历史到相等为止
            inv_bill_history_check(on_flag,os_prompt,vn_if_dif);
        end if;
    END IF;

    --更新现有量表
    inv_update_onhand(id_transaction_date,on_flag,os_prompt);
    IF on_flag < 0 THEN
        RETURN;
    END IF;

    --更新对账信息表
    inv_update_reconciliation(in_if_null,on_flag,os_prompt);
    IF on_flag < 0 THEN
        RETURN;
    END IF;

EXCEPTION
    WHEN OTHERS THEN
        on_flag   := -1;
        os_prompt := '调用inv_transaction_total_deal时发生异常！'||os_prompt|| SUBSTR(SQLERRM, 1, 200);
        --rollback;
        return;
END inv_transaction_total_deal;

END PKG_INV_TRANSACTION_wl;
/

