create package      PKG_AR_TRX is
--循环发票签收过程
  Procedure p_Trx_CUSTOMER_SIGN_Cycle;
--发票签收接口程序，处理INTF_SO_TRX_HEADERS的客户签收信息
 Procedure p_Update_Trx_CUSTOMER_SIGN(p_Oi_Header_Id In INTF_SO_TRX_HEADERS.ID%Type, --处理用的接口ID
                            p_Result           Out Varchar2 --返回值
                            );
--循环开票申请单接口头表
  Procedure p_Invoice_Apply_Create_Cycle;
--开票申请单接口程序 ，新增申请单
  Procedure p_Invoice_Apply_Create(p_Oi_Header_Id In INTF_AR_INVOICE_APPLY_HEADER.OI_HEADER_ID%Type, --处理用的接口ID
                            p_Result           Out Varchar2 --返回值
                            );
--检验申请单下的销售单检验，红单与蓝单的关系，退货单与销售单的关系
  Procedure p_Apply_So_Inspect(p_Invoice_Apply_Id In T_AR_INVOICE_APPLY_HEADER.Invoice_Apply_Id%Type, --申请单ID
                            p_Result           Out Varchar2 --返回值 
                            );

--开票申请单接口程序 ，新增申请单
  Procedure p_Invoice_Apply_Create_ECM(
                            p_Oi_Header_Id In INTF_AR_INVOICE_APPLY_HEADER.OI_HEADER_ID%Type, --处理用的接口ID
                            P_INVOICE_APPLY_STATUS IN T_AR_INVOICE_APPLY_HEADER.INVOICE_APPLY_STATUS%TYPE,--开票申请单单据状态
                            p_Result           Out Varchar2 --返回值
                            );
end PKG_AR_TRX;
/

