create PACKAGE BODY      pkg_inv_reconciliation
IS
/******************************************************************************
   NAME:        cims.pkg_inv_reconciliation

   PURPOSE:     通过ERP提供的dblink到ERP进行查询，并将查询结果与内销系统进行对比。

   DEPEND ON:

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        2014/10/21  lingyy          1. Created this package.
******************************************************************************/
   PROCEDURE p_inv_init
   IS
   BEGIN
      err_success                      := 0;                                                 --成功
      g_ret_code                       := err_success;                                     --错误码
      g_ret_desc                       := '';                                            --错误描述
      g_bill_status_audit              := '11';                                            --已审核
      g_bill_status_recv               := '13';                                            --已接收
      g_reconciliation_flag_success    := '01';                                    --对账结果：成功
      g_reconciliation_flag_fail       := '00';                                    --对账结果：失败
      g_reconciliation_status_open     := '01';                                    --对账状态：打开
      g_reconciliation_status_close    := '00';                                    --对账状态：关闭
      g_so                             := '1020';                                         --:销售单
      g_so_red                         := '1021';                                     --:销售红冲单
      g_so_return                      := '1031';                                     --:销售退货单
      g_so_return_red                  := '1032';                                 --:销售退货红冲单
      g_po_transit                     := '1001';                                     --:采购中转单
      g_po_transit_red                 := '1002';                                 --:采购中转红冲单
      g_po_transit_return              := '1003';                                 --:采购中转退货单
      g_po_transit_return_red          := '1004';                             --:采购中转退货红冲单
      g_po_transit_repair              := '1005';                             --:采购中转返修入库单
      g_po_transit_repair_red          := '1006';                         --:采购中转返修入库红冲单
      g_po_factory_tran                := '1007';                                     --:工厂中转单
      g_po_factory_tran_red            := '1008';                                 --:工厂中转红冲单
      g_po_factory_tran_return         := '1009';                                 --:工厂中转退货单
      g_po_factory_tran_return_red     := '1010';                             --:工厂中转退货红冲单
      g_po                             := '1011';                                         --:采购单
      g_po_red                         := '1012';                                     --:采购红冲单
      g_po_preferential                := '1013';                                   --:优惠品采购单
      g_po_preferential_red            := '1014';                               --:优惠品采购红冲单
      g_po_material                    := '1015';                                     --:物料采购单
      g_po_material_red                := '1016';                                 --:物料采购红冲单
      g_po_material_return             := '1017';                                 --:物料采购退货单
      g_po_material_return_red         := '1018';                             --:物料采购退货红冲单
      g_trsf                           := '1033';                                     --:正常调拨单
      g_trsf_red                       := '1034';                                 --:正常调拨红冲单
      g_trsf_status                    := '1035';                                 --:状态调整调拨单
      g_check_profit                   := '1036';                                     --:盘盈入库单
      g_check_loss                     := '1037';                                     --:盘亏出库单
      g_check_gift                     := '1038';                                     --:赠送发出单
      g_check_gift_red                 := '1039';                                 --:赠送发出红冲单
      g_stockup                        := '1019';                                         --:备货单
      g_send                           := '1040';                                 --:推广物料发放单
   END;

   --对账入口过程。
   PROCEDURE p_inv_reconciliation_main (
      in_entity_id   IN       NUMBER,                                                   --经营主体ID
      on_ret_code    OUT      NUMBER,                                               --对账结果错误码
      on_ret_desc    OUT      VARCHAR2                                            --对账结果错误描述
   )
   IS
      --子库转移(调拨单)
      --正常调拨单1033/正常调拨红冲单1034 状态为已审核（11）时，调出子库为发货仓库(ship_inv_code)
      --状态为已接收(13)时，调出子库为在途仓库(traveling_inv_code)
      --状态调整调拨单1035 状态为已接收（13）时，调出子库为发货仓库（ship_inv_code)
      CURSOR c_trsf
      IS
         SELECT e.reconciliation_id, e.business_header_id, e.trsf_order_num, e.ship_inv_code,
                f.organization_code, e.period_name, e.business_state, e.bill_type_code
           FROM (SELECT b.trsf_order_num, d.period_name, a.reconciliation_id, a.business_state,
                        a.business_header_id,
                        DECODE (a.business_state,
                                g_bill_status_audit, b.ship_inv_code,
                                g_bill_status_recv, DECODE (c.bill_type_code,
                                                            g_trsf_status, b.ship_inv_code,
                                                            b.traveling_inv_code
                                                           ),
                                NULL
                               ) ship_inv_code,
                        c.bill_type_code
                   FROM t_inv_reconciliation a,
                        t_inv_trsf_order b,
                        t_inv_bill_types c,
                        t_inv_inventory_periods d
                  WHERE a.status = g_reconciliation_status_open
                    AND (   a.reconciliation_flag = g_reconciliation_flag_fail
                         OR a.reconciliation_flag IS NULL
                        )
                    AND a.bill_type_id = c.bill_type_id
                    AND c.bill_type_code IN (g_trsf, g_trsf_red, g_trsf_status)
                    AND a.business_header_id = b.trsf_order_id
                    AND (a.transaction_date BETWEEN d.begin_date AND d.end_date)
                    AND a.entity_id = in_entity_id
                    AND b.entity_id = in_entity_id
                    AND c.entity_id = in_entity_id
                    AND d.entity_id = in_entity_id) e,
                t_inv_inventories f
          WHERE f.inventory_code = e.ship_inv_code AND f.entity_id = in_entity_id;

      --账户别名(盘点单)
      CURSOR c_check
      IS
         SELECT e.reconciliation_id, e.business_header_id, e.check_order_num,
                e.erp_disposition_name, ship_inv_code, f.organization_code, e.period_name,
                e.business_state
           FROM (SELECT b.check_order_num, b.erp_disposition_name, d.period_name,
                        a.reconciliation_id, a.business_state, a.business_header_id,
                        inv_code ship_inv_code
                   FROM t_inv_reconciliation a,
                        t_inv_check_orders b,
                        t_inv_bill_types c,
                        t_inv_inventory_periods d
                  WHERE a.status = g_reconciliation_status_open
                    AND (   a.reconciliation_flag = g_reconciliation_flag_fail
                         OR a.reconciliation_flag IS NULL
                        )
                    AND a.bill_type_id = c.bill_type_id
                    AND c.bill_type_code IN
                                     (g_check_profit, g_check_loss, g_check_gift, g_check_gift_red)
                    AND a.business_header_id = b.check_order_id
                    AND (a.transaction_date BETWEEN d.begin_date AND d.end_date)
                    AND a.entity_id = in_entity_id
                    AND b.entity_id = in_entity_id
                    AND c.entity_id = in_entity_id
                    AND d.entity_id = in_entity_id) e,
                t_inv_inventories f
          WHERE f.inventory_code = e.ship_inv_code AND f.entity_id = in_entity_id;

      --采购单/采购红冲单、采购中转单/采购中转红冲单、采购中转返修入库单/采购中转返修入库红冲单
      --优惠品采购单/优惠品采购红冲单、采购中转退货红冲单
      CURSOR c_po
      IS
         SELECT po_num, NVL (erp_order_header_id, -1) erp_order_header_id, vendor_id,
                finance_operating_id, po_type
           FROM t_inv_po_headers
          WHERE entity_id = in_entity_id
            AND po_num IN (
                   SELECT DISTINCT DECODE (b.po_type,
                                           g_po, b.po_num,
                                           g_po_transit, b.po_num,
                                           g_po_transit_repair, b.po_num,
                                           g_po_preferential, b.po_num,
                                           g_po_transit_return_red, b.po_num,
                                           g_po_red, b.old_po_num,
                                           g_po_transit_red, b.old_po_num,
                                           g_po_transit_repair_red, b.old_po_num,
                                           g_po_preferential_red, b.old_po_num
                                          ) po_num
                              FROM t_inv_reconciliation a, t_inv_po_headers b
                             WHERE po_type IN
                                      (g_po,
                                       g_po_red,
                                       g_po_transit,
                                       g_po_transit_red,
                                       g_po_transit_repair,
                                       g_po_transit_repair_red,
                                       g_po_preferential,
                                       g_po_preferential_red,
                                       g_po_transit_return_red
                                      )
                               AND a.entity_id = in_entity_id
                               AND b.entity_id = in_entity_id
                               AND a.business_header_id = b.po_id
                               AND a.status = g_reconciliation_status_open
                               AND (   a.reconciliation_flag = g_reconciliation_flag_fail
                                    OR a.reconciliation_flag IS NULL
                                   ));

      --采购中转退货单
      CURSOR c_po_transit_return
      IS
         SELECT   g.po_return_id, g.bill_type_id,
                  DECODE (MIN (DECODE (f.reconciliation_flag,
                                       g_reconciliation_flag_success, '1',
                                       '0'
                                      )
                              ),
                          '0', '0',
                          '1'
                         ) RESULT
             FROM t_inv_reconciliation f,
                  (SELECT e.po_id po_return_id, e.po_type_id bill_type_id, d.po_id
                     FROM t_inv_po_headers d,
                          (SELECT DISTINCT c.po_id, b.po_type_id, c.erp_order_header_id
                                      FROM t_inv_reconciliation a,
                                           t_inv_po_headers b,
                                           t_inv_po_lines c
                                     WHERE a.business_header_id = b.po_id
                                       AND b.po_id = c.po_id
                                       AND b.po_type = g_po_transit_return
                                       AND b.find_order_flag = 'Y'
                                       AND a.entity_id = in_entity_id
                                       AND b.entity_id = in_entity_id
                                       AND a.status = g_reconciliation_status_open
                                       AND (   a.reconciliation_flag = g_reconciliation_flag_fail
                                            OR a.reconciliation_flag IS NULL
                                           )) e
                    WHERE d.erp_order_header_id = e.erp_order_header_id
                      AND d.entity_id = in_entity_id) g,
                  t_inv_bill_types h
            WHERE g.po_id = f.business_header_id
              AND f.entity_id = in_entity_id
              AND f.bill_type_id = h.bill_type_id
              AND h.bill_type_code = g_po_transit
         GROUP BY g.po_return_id, g.bill_type_id;

--反向销售单
      CURSOR c_po_so
      IS
         SELECT a.reconciliation_id, a.business_header_id, b.po_num, b.finance_operating_id,
                b.erp_order_header_id, c.vendor_main_type
           FROM t_inv_reconciliation a, t_inv_po_headers b, cims.t_lg_vendor_info_head c
          WHERE a.business_header_id = b.po_id
            AND a.entity_id = in_entity_id
            AND b.entity_id = in_entity_id
            AND c.entity_id = in_entity_id
            AND b.po_type = g_po_transit_return
            AND b.find_order_flag = 'N'
            AND b.vendor_id = c.vendor_id
            AND a.bill_type_id = b.po_type_id
            AND a.status = g_reconciliation_status_open
            AND (a.reconciliation_flag = g_reconciliation_flag_fail OR a.reconciliation_flag IS NULL
                );

      c_trsf_row                    c_trsf%ROWTYPE;
      c_check_row                   c_check%ROWTYPE;
      c_po_row                      c_po%ROWTYPE;
      c_po_transit_return_row       c_po_transit_return%ROWTYPE;
      c_po_so_row                   c_po_so%ROWTYPE;
      vn_cnt_line_erp               NUMBER;
      vn_sum_qty_erp                NUMBER;
      vn_total_qty_erp              NUMBER;
      vn_cnt_line_cims              NUMBER;
      vn_total_qty_cims             NUMBER;
      vn_cims_billed_qty            NUMBER;
      vn_cims_executed_qty          NUMBER;
      vn_cims_cancel_qty            NUMBER;
      vn_cims_billed_amount         NUMBER;
      vn_cims_executed_amount       NUMBER;
      vn_cims_cancel_amount         NUMBER;
      vn_erp_segment1               VARCHAR2 (240);
      vn_erp_quantity_ordered       NUMBER;
      vn_erp_quantity_cancelled     NUMBER;
      vn_erp_quantity_delivered     NUMBER;
      vn_erp_amount_ordered         NUMBER;
      vn_erp_amount_cancelled       NUMBER;
      vn_erp_amount_delivered       NUMBER;
      vn_erp_quantity_billed        NUMBER;
      vn_erp_billed_amount          NUMBER;
      vn_erp_billed_qty             NUMBER;
      vn_erp_po_num                 VARCHAR2 (64);
      vn_erp_so_num                 VARCHAR2 (64);
      vn_erp_rel_header_id          NUMBER;
      vs_erp_rel_status             VARCHAR2 (240);
      vn_erp_rel_ordered_quantity   NUMBER;
      vn_erp_rel_amount             NUMBER;
      vn_cims_rel_billed_qty        NUMBER;
      vn_cims_rel_billed_amount     NUMBER;
      vn_cims_rel_billed_rate       NUMBER;
      vn_erp_cnt                    NUMBER;
   BEGIN
      --初始化数据
      p_inv_init ();

      FOR c_trsf_row IN c_trsf
      LOOP
         vn_cnt_line_erp      := 0;
         vn_sum_qty_erp       := 0;
         vn_total_qty_erp     := 0;

         SELECT COUNT (0) / 2 count_line,                                         --大于等于CIMS行数
                                         SUM (mmt.transaction_quantity) sum_qty,         --一定返回0
                ABS (SUM (DECODE (mmt.subinventory_code,
                                  c_trsf_row.ship_inv_code, DECODE (SIGN (mmt.transaction_quantity),
                                                                    1, 0,
                                                                    mmt.transaction_quantity
                                                                   ),
                                  0
                                 )
                         )
                    ) total_qty                                                --参数：FGI是调出子库
           INTO vn_cnt_line_erp, vn_sum_qty_erp,
                vn_total_qty_erp
           FROM apps.mtl_material_transactions@mdims2mderp mmt,
                apps.org_organization_definitions@mdims2mderp ood
          WHERE mmt.organization_id = ood.organization_id
            AND transaction_type_id = 2                           --固定值，事务处理类型：子库存转移
            AND transaction_source_type_id = 13                             --固定值，来源类型：库存
            --AND TO_CHAR (mmt.transaction_date, 'YYYY-MM') = c_trsf_row.period_name
            --参数：事物处理日期范围，CIMS和ERP的交易要发生在同一个期间
            AND (mmt.logical_transaction = 2 OR mmt.logical_transaction IS NULL)            --固定值
            AND mmt.transaction_reference = c_trsf_row.trsf_order_num
            --参数：CIMS单据号
            AND organization_code = c_trsf_row.organization_code;                             --参数

         --S02: INV-S02-广东美的制冷国内营销库存组织
         --S03: OU_101002_广东美的集团芜湖制冷设备有限公司-芜湖营销
         IF vn_sum_qty_erp != 0
         THEN
            UPDATE t_inv_reconciliation
               SET reconciliation_time = SYSDATE,
                   reconciliation_flag = g_reconciliation_flag_fail,
                   last_updated_by = 'PKG_INV_RECONCILIATION',
                   last_update_date = SYSDATE,
                   remark = 'ERP物料处理总数量和(' || vn_sum_qty_erp || ')不为0，对账失败！'
             WHERE reconciliation_id = c_trsf_row.reconciliation_id AND entity_id = in_entity_id;

            COMMIT;
            CONTINUE;
         END IF;

         vn_cnt_line_cims     := 0;
         vn_total_qty_cims    := 0;

         SELECT COUNT (0), SUM (b.billed_qty)
           INTO vn_cnt_line_cims, vn_total_qty_cims
           FROM t_inv_trsf_order_line a, t_inv_trsf_order_line_detail b
          WHERE a.trsf_order_id = c_trsf_row.business_header_id
            AND a.trsf_order_line_id = b.trsf_order_line_id
            AND a.entity_id = in_entity_id
            AND b.entity_id = in_entity_id;

         IF vn_total_qty_cims != vn_total_qty_erp
         THEN
            UPDATE t_inv_reconciliation
               SET reconciliation_time = SYSDATE,
                   reconciliation_flag = g_reconciliation_flag_fail,
                   last_updated_by = 'PKG_INV_RECONCILIATION',
                   last_update_date = SYSDATE,
                   remark =
                         '调出子库(仓库编码:'
                      || c_trsf_row.ship_inv_code
                      || ')的物料数量不相等，ERP数量：'
                      || vn_total_qty_erp
                      || '，CIMS数量：'
                      || vn_total_qty_cims
                      || '，对账失败！'
             WHERE reconciliation_id = c_trsf_row.reconciliation_id AND entity_id = in_entity_id;

            CONTINUE;
         END IF;

         IF     c_trsf_row.business_state = g_bill_status_recv
            AND (c_trsf_row.bill_type_code = g_trsf OR c_trsf_row.bill_type_code = g_trsf_red)
         THEN
            --状态为接收并且单据类型为正常调拨单或正常调拨红冲单时。
            vn_cnt_line_cims    := vn_cnt_line_cims * 2;
         END IF;

         IF vn_cnt_line_cims > vn_cnt_line_erp
         THEN
            UPDATE t_inv_reconciliation
               SET reconciliation_time = SYSDATE,
                   reconciliation_flag = g_reconciliation_flag_fail,
                   last_updated_by = 'PKG_INV_RECONCILIATION',
                   last_update_date = SYSDATE,
                   remark =
                         'CIMS物料事物处理记录数('
                      || vn_cnt_line_cims
                      || ')不能大于ERP物料事物处理记录数('
                      || vn_cnt_line_erp
                      || ')，对账失败！'
             WHERE reconciliation_id = c_trsf_row.reconciliation_id AND entity_id = in_entity_id;

            CONTINUE;
         END IF;

         UPDATE t_inv_reconciliation
            SET reconciliation_time = SYSDATE,
                reconciliation_flag = g_reconciliation_flag_success,
                status = g_reconciliation_status_close,
                last_updated_by = 'PKG_INV_RECONCILIATION',
                last_update_date = SYSDATE,
                remark = '对账成功！'
          WHERE reconciliation_id = c_trsf_row.reconciliation_id AND entity_id = in_entity_id;
      END LOOP;

      FOR c_check_row IN c_check
      LOOP
         vn_cnt_line_erp      := 0;
         vn_total_qty_erp     := 0;

         SELECT COUNT (0) count_line,                                             --大于等于CIMS行数
                                     ABS (SUM (mmt.transaction_quantity)) total_qty
           --跟CIMS总数量一致
         INTO   vn_cnt_line_erp, vn_total_qty_erp
           FROM apps.mtl_material_transactions@mdims2mderp mmt,
                apps.org_organization_definitions@mdims2mderp ood,
                apps.mtl_generic_dispositions@mdims2mderp mgd
          WHERE mmt.organization_id = ood.organization_id
            AND mmt.transaction_source_id = mgd.disposition_id
            AND transaction_source_type_id = 6                          --固定值，来源类型：帐户别名
            AND TO_CHAR (mmt.transaction_date, 'YYYY-MM') = c_check_row.period_name
            --参数：事物处理日期范围，CIMS和ERP的交易要发生在同一个期间
            AND (mmt.logical_transaction = 2 OR mmt.logical_transaction IS NULL)            --固定值
            AND mmt.transaction_reference = c_check_row.check_order_num
            --参数：CIMS单据号
            AND mgd.segment1 = c_check_row.erp_disposition_name
            --参数:帐户别名名称
            AND mmt.subinventory_code = c_check_row.ship_inv_code                       --参数：子库
            AND ood.organization_code = c_check_row.organization_code;

                                                                    --参数：库存组织
         --S02: INV-S02-广东美的制冷国内营销库存组织
         --S03: OU_101002_广东美的集团芜湖制冷设备有限公司-芜湖营销
         vn_cnt_line_cims     := 0;
         vn_total_qty_cims    := 0;

         SELECT COUNT (0), SUM (billed_qty)
           INTO vn_cnt_line_cims, vn_total_qty_cims
           FROM t_inv_check_order_lines
          WHERE check_order_id = c_check_row.business_header_id AND entity_id = in_entity_id;

         IF vn_total_qty_cims != vn_total_qty_erp
         THEN
            UPDATE t_inv_reconciliation
               SET reconciliation_time = SYSDATE,
                   reconciliation_flag = g_reconciliation_flag_fail,
                   last_updated_by = 'PKG_INV_RECONCILIATION',
                   last_update_date = SYSDATE,
                   remark =
                         '调出子库(仓库编码:'
                      || c_check_row.ship_inv_code
                      || ')的物料数量不相等，ERP数量：'
                      || vn_total_qty_erp
                      || '，CIMS数量：'
                      || vn_total_qty_cims
                      || '，对账失败！'
             WHERE reconciliation_id = c_check_row.reconciliation_id AND entity_id = in_entity_id;

            CONTINUE;
         END IF;

         IF vn_cnt_line_cims > vn_cnt_line_erp
         THEN
            UPDATE t_inv_reconciliation
               SET reconciliation_time = SYSDATE,
                   reconciliation_flag = g_reconciliation_flag_fail,
                   last_updated_by = 'PKG_INV_RECONCILIATION',
                   last_update_date = SYSDATE,
                   remark =
                         'CIMS物料事物处理记录数('
                      || vn_cnt_line_cims
                      || ')不能大于ERP物料事物处理记录数('
                      || vn_cnt_line_erp
                      || ')，对账失败！'
             WHERE reconciliation_id = c_check_row.reconciliation_id AND entity_id = in_entity_id;

            CONTINUE;
         END IF;

         UPDATE t_inv_reconciliation
            SET reconciliation_time = SYSDATE,
                reconciliation_flag = g_reconciliation_flag_success,
                status = g_reconciliation_status_close,
                last_updated_by = 'PKG_INV_RECONCILIATION',
                last_update_date = SYSDATE,
                remark = '对账成功！'
          WHERE reconciliation_id = c_check_row.reconciliation_id AND entity_id = in_entity_id;
      END LOOP;

      FOR c_po_row IN c_po
      LOOP
         vn_cims_billed_qty         := 0;
         vn_cims_executed_qty       := 0;
         vn_cims_cancel_qty         := 0;
         vn_cims_billed_amount      := 0;
         vn_cims_executed_amount    := 0;
         vn_cims_cancel_amount      := 0;

         --原单开单数量、开单金额
         SELECT SUM (b.billed_qty), SUM (b.billed_qty * b.item_price)
           INTO vn_cims_billed_qty, vn_cims_billed_amount
           FROM t_inv_po_headers a, t_inv_po_lines b
          WHERE a.po_id = b.po_id AND a.po_num = c_po_row.po_num AND a.entity_id = in_entity_id;

         vn_erp_po_num              := NULL;

         IF c_po_row.erp_order_header_id = -1
         THEN
            IF c_po_row.po_type = g_po                                                    -- 采购单
            THEN
               vn_erp_po_num    := c_po_row.po_num;

               --对应红冲单开数量、开单金额
               SELECT SUM (b.billed_qty), SUM (b.billed_qty * b.item_price)
                 INTO vn_cims_cancel_qty, vn_cims_cancel_amount
                 FROM t_inv_po_headers a, t_inv_po_lines b
                WHERE a.entity_id = in_entity_id
                  AND a.old_po_num = vn_erp_po_num
                  AND b.po_id = a.po_id
                  AND a.po_status IN ('21', '14');
            ELSE
               UPDATE t_inv_reconciliation
                  SET reconciliation_time = SYSDATE,
                      reconciliation_flag =
                         DECODE (reconciliation_flag,
                                 g_reconciliation_flag_success, g_reconciliation_flag_success,
                                 g_reconciliation_flag_fail
                                ),
                      last_updated_by = 'PKG_INV_RECONCILIATION',
                      last_update_date = SYSDATE,
                      remark = '关联交易号为空，对账失败！'
                WHERE reconciliation_id IN (
                         SELECT a.reconciliation_id
                           FROM t_inv_reconciliation a, t_inv_po_headers b
                          WHERE a.business_num = b.po_num
                            AND (b.po_num = c_po_row.po_num OR b.old_po_num = c_po_row.po_num)
                            AND a.entity_id = in_entity_id
                            AND a.bill_type_id = b.po_type_id
                            AND b.po_type != g_po_transit_return)
                  AND entity_id = in_entity_id;

               CONTINUE;
            END IF;
         ELSE
            BEGIN
               SELECT DISTINCT crl.po_number                                            --采购订单号
                          INTO vn_erp_po_num
                          FROM apps.cux_icp_order_req_lines_v@mdims2mderp crl
                         WHERE crl.req_header_id = c_po_row.erp_order_header_id;
            --参数：关联交易号
            EXCEPTION
               WHEN NO_DATA_FOUND
               THEN
                  UPDATE t_inv_reconciliation
                     SET reconciliation_time = SYSDATE,
                         reconciliation_flag =
                            DECODE (reconciliation_flag,
                                    g_reconciliation_flag_success, g_reconciliation_flag_success,
                                    g_reconciliation_flag_fail
                                   ),
                         last_updated_by = 'PKG_INV_RECONCILIATION',
                         last_update_date = SYSDATE,
                         remark =
                               '根据关联交易号：'
                            || c_po_row.erp_order_header_id
                            || '找不到对应的采购订单号，对账失败！'
                   WHERE reconciliation_id IN (
                            SELECT a.reconciliation_id
                              FROM t_inv_reconciliation a, t_inv_po_headers b
                             WHERE a.business_num = b.po_num
                               AND (b.po_num = c_po_row.po_num OR b.old_po_num = c_po_row.po_num)
                               AND a.entity_id = in_entity_id
                               AND a.bill_type_id = b.po_type_id
                               AND b.po_type != g_po_transit_return)
                     AND entity_id = in_entity_id;

                  CONTINUE;
               WHEN TOO_MANY_ROWS
               THEN
                  UPDATE t_inv_reconciliation
                     SET reconciliation_time = SYSDATE,
                         reconciliation_flag =
                            DECODE (reconciliation_flag,
                                    g_reconciliation_flag_success, g_reconciliation_flag_success,
                                    g_reconciliation_flag_fail
                                   ),
                         last_updated_by = 'PKG_INV_RECONCILIATION',
                         last_update_date = SYSDATE,
                         remark =
                               '根据关联交易号：'
                            || c_po_row.erp_order_header_id
                            || '找到多条对应的采购订单号，对账失败！'
                   WHERE reconciliation_id IN (
                            SELECT a.reconciliation_id
                              FROM t_inv_reconciliation a, t_inv_po_headers b
                             WHERE a.business_num = b.po_num
                               AND (b.po_num = c_po_row.po_num OR b.old_po_num = c_po_row.po_num)
                               AND a.entity_id = in_entity_id
                               AND a.bill_type_id = b.po_type_id
                               AND b.po_type != g_po_transit_return)
                     AND entity_id = in_entity_id;

                  CONTINUE;
            END;

            --对应红冲单、退货单的开单数量、开单金额
            SELECT SUM (b.billed_qty), SUM (b.billed_qty * b.item_price)
              INTO vn_cims_cancel_qty, vn_cims_cancel_amount
              FROM t_inv_po_headers a, t_inv_po_lines b
             WHERE a.entity_id = in_entity_id
               AND b.erp_order_header_id = c_po_row.erp_order_header_id
               AND b.po_id = a.po_id
               AND a.po_type != g_po_transit_return_red
               AND a.po_status IN ('21', '14');
         END IF;

         --执行数量、执行金额
         vn_cims_executed_qty       := vn_cims_billed_qty - vn_cims_cancel_qty;
         vn_cims_executed_amount    := vn_cims_billed_amount - vn_cims_cancel_amount;

         BEGIN
            --关联交易号对账
            vn_erp_segment1              := 0;
            vn_erp_quantity_ordered      := 0;
            vn_erp_quantity_cancelled    := 0;
            vn_erp_quantity_delivered    := 0;
            vn_erp_amount_ordered        := 0;
            vn_erp_amount_cancelled      := 0;
            vn_erp_amount_delivered      := 0;
            vn_erp_quantity_billed       := 0;

            SELECT   poh.segment1, SUM (pod.quantity_ordered) quantity_ordered,
                     --订购数量
                     SUM (pod.quantity_cancelled) quantity_cancelled,
                     --取消数量
                     SUM (pod.quantity_delivered) quantity_delivered,
                     --入库数量
                     SUM (pod.quantity_ordered * pol.unit_price) amount_ordered,
                     --订购金额
                     SUM (pod.quantity_cancelled * pol.unit_price) amount_cancelled,
                     --取消金额
                     SUM (pod.quantity_delivered * pol.unit_price) amount_delivered,
                     --入库金额
                     SUM (pod.quantity_billed) quantity_billed                                --备用
                INTO vn_erp_segment1, vn_erp_quantity_ordered,
                     vn_erp_quantity_cancelled,
                     vn_erp_quantity_delivered,
                     vn_erp_amount_ordered,
                     vn_erp_amount_cancelled,
                     vn_erp_amount_delivered,
                     vn_erp_quantity_billed
                FROM apps.po_headers_all@mdims2mderp poh,
                     apps.po_lines_all@mdims2mderp pol,
                     --       PO_LINE_LOCATIONS_ALL PLL, --备用
                     apps.po_distributions_all@mdims2mderp pod
               WHERE poh.po_header_id = pol.po_header_id
                 AND pol.po_line_id = pod.po_line_id
                 AND poh.org_id = c_po_row.finance_operating_id                        --参数：OU ID
                 --85 100910: OU_100910_广东美的制冷设备有限公司-国内营销
                 --102 101002: OU_101002_广东美的集团芜湖制冷设备-芜湖营销
                 AND poh.segment1 = vn_erp_po_num                                   --参数：采购单号
            --AND poh.vendor_id = c_po_row.vendor_id                             --参数：供应商ID
            GROUP BY poh.segment1;

            --单据号对账
            vn_erp_cnt                   := 0;

            SELECT COUNT (poh.attribute13)
              INTO vn_erp_cnt
              FROM apps.po_headers_all@mdims2mderp poh
             WHERE poh.attribute13 = c_po_row.po_num AND poh.attribute11 = 'CIMS';
         EXCEPTION
            WHEN NO_DATA_FOUND
            THEN
               UPDATE t_inv_reconciliation
                  SET reconciliation_time = SYSDATE,
                      reconciliation_flag =
                         DECODE (reconciliation_flag,
                                 g_reconciliation_flag_success, g_reconciliation_flag_success,
                                 g_reconciliation_flag_fail
                                ),
                      last_updated_by = 'PKG_INV_RECONCILIATION',
                      last_update_date = SYSDATE,
                      remark =
                            'ERP侧未找到对应的对账记录！OU ID：'
                         || c_po_row.finance_operating_id
                         || ' 采购单号：'
                         || vn_erp_po_num
                         || '，对账失败！'
                WHERE reconciliation_id IN (
                         SELECT a.reconciliation_id
                           FROM t_inv_reconciliation a, t_inv_po_headers b
                          WHERE a.business_num = b.po_num
                            AND (b.po_num = c_po_row.po_num OR b.old_po_num = c_po_row.po_num)
                            AND a.entity_id = in_entity_id
                            AND a.bill_type_id = b.po_type_id
                            AND b.po_type != g_po_transit_return)
                  AND entity_id = in_entity_id;

               CONTINUE;
         END;

         --vn_erp_billed_qty          := vn_erp_quantity_ordered - vn_erp_quantity_cancelled;
         IF vn_cims_billed_qty != vn_erp_quantity_ordered
         THEN
            UPDATE t_inv_reconciliation
               SET reconciliation_time = SYSDATE,
                   reconciliation_flag =
                      DECODE (reconciliation_flag,
                              g_reconciliation_flag_success, g_reconciliation_flag_success,
                              g_reconciliation_flag_fail
                             ),
                   last_updated_by = 'PKG_INV_RECONCILIATION',
                   last_update_date = SYSDATE,
                   remark =
                         '开单数量不相等，ERP数量：'
                      || vn_erp_quantity_ordered
                      || ' CIMS数量：'
                      || vn_cims_billed_qty
                      || '，对账失败！'
             WHERE reconciliation_id IN (
                      SELECT a.reconciliation_id
                        FROM t_inv_reconciliation a, t_inv_po_headers b
                       WHERE a.business_num = b.po_num
                         AND (b.po_num = c_po_row.po_num OR b.old_po_num = c_po_row.po_num)
                         AND a.entity_id = in_entity_id
                         AND a.bill_type_id = b.po_type_id
                         AND b.po_type != g_po_transit_return)
               AND entity_id = in_entity_id;

            CONTINUE;
         END IF;

         IF vn_cims_executed_qty != vn_erp_quantity_delivered
         THEN
            UPDATE t_inv_reconciliation
               SET reconciliation_time = SYSDATE,
                   reconciliation_flag =
                      DECODE (reconciliation_flag,
                              g_reconciliation_flag_success, g_reconciliation_flag_success,
                              g_reconciliation_flag_fail
                             ),
                   last_updated_by = 'PKG_INV_RECONCILIATION',
                   last_update_date = SYSDATE,
                   remark =
                         '执行数量不相等，ERP数量：'
                      || vn_erp_quantity_delivered
                      || ' CIMS数量：'
                      || vn_cims_executed_qty
                      || '，对账失败！'
             WHERE reconciliation_id IN (
                      SELECT a.reconciliation_id
                        FROM t_inv_reconciliation a, t_inv_po_headers b
                       WHERE a.business_num = b.po_num
                         AND (b.po_num = c_po_row.po_num OR b.old_po_num = c_po_row.po_num)
                         AND a.entity_id = in_entity_id
                         AND a.bill_type_id = b.po_type_id
                         AND b.po_type != g_po_transit_return)
               AND entity_id = in_entity_id;

            CONTINUE;
         END IF;

         --vn_erp_billed_amount       := vn_erp_amount_ordered - vn_erp_amount_cancelled;
         IF vn_cims_billed_amount != vn_erp_amount_ordered
         THEN
            UPDATE t_inv_reconciliation
               SET reconciliation_time = SYSDATE,
                   reconciliation_flag =
                      DECODE (reconciliation_flag,
                              g_reconciliation_flag_success, g_reconciliation_flag_success,
                              g_reconciliation_flag_fail
                             ),
                   last_updated_by = 'PKG_INV_RECONCILIATION',
                   last_update_date = SYSDATE,
                   remark =
                         '开单金额不相等，ERP金额：'
                      || vn_erp_amount_ordered
                      || ' CIMS金额：'
                      || vn_cims_billed_amount
                      || '，对账失败！'
             WHERE reconciliation_id IN (
                      SELECT a.reconciliation_id
                        FROM t_inv_reconciliation a, t_inv_po_headers b
                       WHERE a.business_num = b.po_num
                         AND (b.po_num = c_po_row.po_num OR b.old_po_num = c_po_row.po_num)
                         AND a.entity_id = in_entity_id
                         AND a.bill_type_id = b.po_type_id
                         AND b.po_type != g_po_transit_return)
               AND entity_id = in_entity_id;

            CONTINUE;
         END IF;

         IF vn_cims_executed_amount != vn_erp_amount_delivered
         THEN
            UPDATE t_inv_reconciliation
               SET reconciliation_time = SYSDATE,
                   reconciliation_flag =
                      DECODE (reconciliation_flag,
                              g_reconciliation_flag_success, g_reconciliation_flag_success,
                              g_reconciliation_flag_fail
                             ),
                   last_updated_by = 'PKG_INV_RECONCILIATION',
                   last_update_date = SYSDATE,
                   remark =
                         '执行金额不相等，ERP金额：'
                      || vn_erp_amount_delivered
                      || ' CIMS金额：'
                      || vn_cims_executed_amount
                      || '，对账失败！'
             WHERE reconciliation_id IN (
                      SELECT a.reconciliation_id
                        FROM t_inv_reconciliation a, t_inv_po_headers b
                       WHERE a.business_num = b.po_num
                         AND (b.po_num = c_po_row.po_num OR b.old_po_num = c_po_row.po_num)
                         AND a.entity_id = in_entity_id
                         AND a.bill_type_id = b.po_type_id
                         AND b.po_type != g_po_transit_return)
               AND entity_id = in_entity_id;

            CONTINUE;
         END IF;

         IF vn_erp_cnt != 1
         THEN
            UPDATE t_inv_reconciliation
               SET reconciliation_time = SYSDATE,
                   reconciliation_flag =
                      DECODE (reconciliation_flag,
                              g_reconciliation_flag_success, g_reconciliation_flag_success,
                              g_reconciliation_flag_fail
                             ),
                   last_updated_by = 'PKG_INV_RECONCILIATION',
                   last_update_date = SYSDATE,
                   remark = 'ERP侧存在：' || vn_erp_cnt || '条单据记录，对账失败！'
             WHERE reconciliation_id IN (
                      SELECT a.reconciliation_id
                        FROM t_inv_reconciliation a, t_inv_po_headers b
                       WHERE a.business_num = b.po_num
                         AND (b.po_num = c_po_row.po_num OR b.old_po_num = c_po_row.po_num)
                         AND a.entity_id = in_entity_id
                         AND a.bill_type_id = b.po_type_id
                         AND b.po_type != g_po_transit_return)
               AND entity_id = in_entity_id;

            CONTINUE;
         END IF;

         UPDATE t_inv_reconciliation
            SET reconciliation_time = SYSDATE,
                reconciliation_flag = g_reconciliation_flag_success,
                status = g_reconciliation_status_close,
                last_updated_by = 'PKG_INV_RECONCILIATION',
                last_update_date = SYSDATE,
                remark = '对账成功！'
          WHERE reconciliation_id IN (
                   SELECT a.reconciliation_id
                     FROM t_inv_reconciliation a, t_inv_po_headers b
                    WHERE a.business_num = b.po_num
                      AND (b.po_num = c_po_row.po_num OR b.old_po_num = c_po_row.po_num)
                      AND a.entity_id = in_entity_id
                      AND a.bill_type_id = b.po_type_id
                      AND b.po_type != g_po_transit_return)
            AND entity_id = in_entity_id;
      END LOOP;

      FOR c_po_transit_return_row IN c_po_transit_return
      LOOP
         IF c_po_transit_return_row.RESULT = '1'
         THEN
            UPDATE t_inv_reconciliation
               SET reconciliation_time = SYSDATE,
                   reconciliation_flag = g_reconciliation_flag_success,
                   status = g_reconciliation_status_close,
                   last_updated_by = 'PKG_INV_RECONCILIATION',
                   last_update_date = SYSDATE,
                   remark = '对账成功！'
             WHERE entity_id = in_entity_id
               AND business_header_id = c_po_transit_return_row.po_return_id
               AND bill_type_id = c_po_transit_return_row.bill_type_id;
         ELSE
            UPDATE t_inv_reconciliation
               SET reconciliation_time = SYSDATE,
                   reconciliation_flag = g_reconciliation_flag_fail,
                   last_updated_by = 'PKG_INV_RECONCILIATION',
                   last_update_date = SYSDATE,
                   remark = '有未对账或对账失败的采购中转单，对账失败！'
             WHERE entity_id = in_entity_id
               AND business_header_id = c_po_transit_return_row.po_return_id
               AND bill_type_id = c_po_transit_return_row.bill_type_id;
         END IF;
      END LOOP;

      FOR c_po_so_row IN c_po_so
      LOOP
         IF c_po_so_row.erp_order_header_id IS NULL
         THEN
            UPDATE t_inv_reconciliation
               SET reconciliation_time = SYSDATE,
                   reconciliation_flag = g_reconciliation_flag_fail,
                   last_updated_by = 'PKG_INV_RECONCILIATION',
                   last_update_date = SYSDATE,
                   remark = '关联交易号为空，对账失败！'
             WHERE entity_id = in_entity_id AND reconciliation_id = c_po_so_row.reconciliation_id;

            CONTINUE;
         END IF;

         vn_erp_so_num                  := NULL;

         BEGIN
            SELECT DISTINCT crl.order_number                                            --采购销售号
                       INTO vn_erp_so_num
                       FROM apps.cux_icp_order_req_lines_v@mdims2mderp crl
                      WHERE crl.req_header_id = c_po_so_row.erp_order_header_id;
         EXCEPTION
            WHEN NO_DATA_FOUND
            THEN
               UPDATE t_inv_reconciliation
                  SET reconciliation_time = SYSDATE,
                      reconciliation_flag = g_reconciliation_flag_fail,
                      last_updated_by = 'PKG_INV_RECONCILIATION',
                      last_update_date = SYSDATE,
                      remark =
                            '根据关联交易号：'
                         || c_po_so_row.erp_order_header_id
                         || '找不到对应的销售订单号，对账失败！'
                WHERE reconciliation_id = c_po_so_row.reconciliation_id AND entity_id = in_entity_id;

               CONTINUE;
            WHEN TOO_MANY_ROWS
            THEN
               UPDATE t_inv_reconciliation
                  SET reconciliation_time = SYSDATE,
                      reconciliation_flag = g_reconciliation_flag_fail,
                      last_updated_by = 'PKG_INV_RECONCILIATION',
                      last_update_date = SYSDATE,
                      remark =
                            '根据关联交易号：'
                         || c_po_so_row.erp_order_header_id
                         || '找到多条对应的销售订单号，对账失败！'
                WHERE reconciliation_id = c_po_so_row.reconciliation_id AND entity_id = in_entity_id;

               CONTINUE;
         END;

         vn_erp_rel_header_id           := NULL;
         vs_erp_rel_status              := NULL;
         vn_erp_rel_ordered_quantity    := NULL;
         vn_erp_rel_amount              := NULL;

         BEGIN
            SELECT   oel.header_id, oel.flow_status_code,
                     SUM (oel.ordered_quantity) ordered_quantity,
                     SUM (oel.ordered_quantity * oel.unit_selling_price) amount
                INTO vn_erp_rel_header_id, vs_erp_rel_status,
                     vn_erp_rel_ordered_quantity,
                     vn_erp_rel_amount
                FROM apps.oe_order_lines_all@mdims2mderp oel,
                     apps.oe_order_headers_all@mdims2mderp oeh
               WHERE oeh.header_id = oel.header_id
                 AND oeh.order_number = vn_erp_so_num                                       --参数：
                 AND oeh.org_id = c_po_so_row.finance_operating_id
            --：参数OU ID
            GROUP BY oel.header_id, oel.flow_status_code;
         EXCEPTION
            WHEN NO_DATA_FOUND
            THEN
               UPDATE t_inv_reconciliation
                  SET reconciliation_time = SYSDATE,
                      reconciliation_flag = g_reconciliation_flag_fail,
                      last_updated_by = 'PKG_INV_RECONCILIATION',
                      last_update_date = SYSDATE,
                      remark =
                            'ERP侧未找到对应的对账记录！销售订单号：'
                         || vn_erp_so_num
                         || ' OU ID：'
                         || c_po_so_row.finance_operating_id
                         || '，对账失败！'
                WHERE reconciliation_id = c_po_so_row.reconciliation_id AND entity_id = in_entity_id;

               CONTINUE;
         END;

         IF vs_erp_rel_status != 'CLOSED'
         THEN
            UPDATE t_inv_reconciliation
               SET reconciliation_time = SYSDATE,
                   reconciliation_flag = g_reconciliation_flag_fail,
                   last_updated_by = 'PKG_INV_RECONCILIATION',
                   last_update_date = SYSDATE,
                   remark =
                         'ERP侧行状态meaning('
                      || vs_erp_rel_status
                      || ')不为Fulfilled或Closed，对账失败！'
             WHERE entity_id = in_entity_id AND reconciliation_id = c_po_so_row.reconciliation_id;

            CONTINUE;
         END IF;

         vn_cims_rel_billed_qty         := NULL;
         vn_cims_rel_billed_amount      := NULL;

         SELECT SUM (b.billed_qty) billed_qty, SUM (b.billed_qty * b.item_price) billed_amount
           INTO vn_cims_rel_billed_qty, vn_cims_rel_billed_amount
           FROM t_inv_po_headers a, t_inv_po_lines b
          WHERE a.po_id = b.po_id AND a.po_num = c_po_so_row.po_num AND a.entity_id = in_entity_id;

         IF vn_cims_rel_billed_qty != vn_erp_rel_ordered_quantity
         THEN
            UPDATE t_inv_reconciliation
               SET reconciliation_time = SYSDATE,
                   reconciliation_flag = g_reconciliation_flag_fail,
                   last_updated_by = 'PKG_INV_RECONCILIATION',
                   last_update_date = SYSDATE,
                   remark =
                         '开单数量不相等，ERP数量：'
                      || vn_erp_rel_ordered_quantity
                      || ' CIMS数量：'
                      || vn_cims_rel_billed_qty
                      || '，对账失败！'
             WHERE entity_id = in_entity_id AND reconciliation_id = c_po_so_row.reconciliation_id;

            CONTINUE;
         END IF;

         vn_cims_rel_billed_rate        := NULL;

         IF c_po_so_row.vendor_main_type = '01'
         THEN
            vn_cims_rel_billed_rate    := 1.17;
         ELSE
            vn_cims_rel_billed_rate    := 1;
         END IF;

         IF (vn_cims_rel_billed_amount * vn_cims_rel_billed_rate) != vn_erp_rel_amount
         THEN
            UPDATE t_inv_reconciliation
               SET reconciliation_time = SYSDATE,
                   reconciliation_flag = g_reconciliation_flag_fail,
                   last_updated_by = 'PKG_INV_RECONCILIATION',
                   last_update_date = SYSDATE,
                   remark =
                         '开单金额不相等，ERP金额：'
                      || vn_erp_rel_amount
                      || ' CIMS金额+金额*税率：'
                      || vn_cims_rel_billed_amount * vn_cims_rel_billed_rate
                      || '，对账失败！'
             WHERE entity_id = in_entity_id AND reconciliation_id = c_po_so_row.reconciliation_id;

            CONTINUE;
         END IF;

         UPDATE t_inv_reconciliation
            SET reconciliation_time = SYSDATE,
                reconciliation_flag = g_reconciliation_flag_success,
                status = g_reconciliation_status_close,
                last_updated_by = 'PKG_INV_RECONCILIATION',
                last_update_date = SYSDATE,
                remark = '对账成功！'
          WHERE entity_id = in_entity_id AND reconciliation_id = c_po_so_row.reconciliation_id;
      END LOOP;
   EXCEPTION
      WHEN OTHERS
      THEN
         on_ret_code    := SQLCODE;
         on_ret_desc    := SQLCODE || ' ' || SQLERRM;
   END;
END pkg_inv_reconciliation;
/

