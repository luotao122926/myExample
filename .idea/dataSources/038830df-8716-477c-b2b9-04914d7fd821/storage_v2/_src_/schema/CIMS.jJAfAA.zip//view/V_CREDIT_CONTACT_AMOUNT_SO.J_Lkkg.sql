create view V_CREDIT_CONTACT_AMOUNT_SO as
SELECT 'so' Business_ID ,  --业务类型
       so_header.biz_src_bill_type_code, -- 业务单据源类型编码
       so_header.biz_src_bill_type_name, -- 业务单据源类型名称
       so_header.SO_HEADER_ID BILL_ID, --单据id
       so_header.so_num BILL_NUM, --单据编号
       so_header.so_date BILL_DATE, --单据日期
       so_header.so_status BILL_STATUS, --单据状态
       so_header.bill_type_id, --单据类型id
       so_header.bill_type_code, --单据类型编码
       so_header.bill_type_name, --单据类型名称
       so_header.settle_date settle_date, --单据结算日期
       so_header.so_date account_date, --客户对帐日期
       so_header.checked_account_date, --财务对帐日期
       so_header.customer_id, --客户id
       so_header.customer_code, --客户编码
       cus_header.customer_name, --客户名称
       so_header.account_id , --账户ID
       so_header.account_code , --账户编码
       so_header.account_name , --账户名称
       CPH.CUSTOMER_CODE AS CUSTOMER_CODE_P,
       CPH.CUSTOMER_NAME AS CUSTOMER_NAME_P,
       PKG_CREDIT_TOOLS.FUN_GET_CODELIST(cus_main_type.cooperation_model_id,
                                         'MIDEA_MARKET_MODE',
                                         2) customer_type,
       --客户类型
       --NVL (precus.customer_id, cih.customer_id)     pre_customer_id,    --上级单位ID
       --NVL (precus.customer_code, cih.customer_code) pre_customer_code,  --上级单位编码
       --NVL (precus.customer_name, cih.customer_name) pre_customer_name,  --上级单位名称
       --soh.finance_main_entity_id,              --主主体
       so_header.entity_id, --主体
       CL.Name entity_NAME,--主体名称
       so_header.sales_center_id, --营销中心id
       so_header.Sales_Center_Code, --营销中心编码(客户群编码)
       so_header.Sales_Center_Name, --营销中心名称(客户群名称)
       cur_org.sales_region_id, --销售区域ID
       --v_region.sales_region_name, --销售区域名称
       cur_org.sales_region_name, --销售区域名称
       so_header.brand_code, --品牌编码
       so_header.brand_name, --品牌名称
       so_header.sales_main_type, --营销大类编码
       so_header.sales_main_type_name, --营销大类名称
       --soh.small_category,                   --营销小类
       so_header.project_num, --批文编码
       so_header.project_num project_name, --批文名称
       NULL cash_code, --票据号
       NULL cash_date, --票据日期
       NULL due_date, --到期日期
       so_header.invoice_num_list, --发票号串（税控发票）
       so_header.invoice_date, --发票日期（税控日期）
       so_header.sales_year_id, --销售年度ID
       so_header.sales_year_id sales_year, --销售年度
       so_header.src_type, --来源类型
       decode(so_header.src_type,
              '01',
              '计划订单',
              '02',
              '提货订单',
              '03',
              '调拨订单',
              '04',
              '促销品',
              '09',
              '采购单据',
              '10',
              '调拨单据',
              '11',
              '备货单据',
              '12',
              '财务单据',
              '13',
              '退货申请单',
              '14',
              'F单',
              '15',
              '电商',
              '18',
              '价格调账申请单',
              '19',
              '拆单调账申请单',
              '21',
              '退货红冲申请单',
              '31',
              '财务单据',
              'SL_BILL',
              '库位单') src_type_name,--来源类型名称
       so_header.src_bill_num, --来源号
       NULL discount_type_id,                   --折扣id
       NULL discount_type_name,            --折扣名称
       --so_header.discount_item, --折让项目
       --so_header.discount_mode, --折让方式
       PDI.CODE_NAME AS discount_item, --折让项目
       PDM.CODE_NAME AS discount_mode, --折让方式
       --soh.check_flag,                     --是否校验
       --so_header.settle_flag,
       'Y' settle_flag , --是否结算(标记是否调用过信用，销售头表单据都需要调用款项变更)
       bill_type.PLUS_MINUS_FLAG * so_header.list_amount list_amount, --列表金额
       bill_type.PLUS_MINUS_FLAG * so_header.discount_amount discount_amount, --折让金额
       bill_type.PLUS_MINUS_FLAG * so_header.settle_amount settle_amount, --结算金额
       bill_type.PLUS_MINUS_FLAG * so_header.delaypay_amount as delaypay_amount, --使用铺底额度
       0 SOLUTION_PAY_AMOUNT, --三方承兑解付金额
       /*DECODE (itt.transaction_source_type_id, 1, -1, 2, 1, 0)
       * DECODE (DECODE (soh.presales_flag, 'N', 0, 1)* DECODE (soh.account_flag, 'Y', 0, 1),
                 0,
                 soh.instant_dis_amount,
                 1,
                 0) instant_dis_amount,           --即返额 */
       so_header.Remark, --备注
       so_header.CREATED_BY,
       so_header.creation_date, --录入日期
       1  sales_receipt,
       --soh.patch_amount,                         --补息（去掉）
       --0 paste_amount,                           --贴息（去掉）
       --sy.item_type,                             --产品类型
       --NVL (soh.ora_intooiflag_c, 'N') intooiflag, --是否引入财务
       1 cnt,
       so_header.fund_ctrl_mode, --控制方式
       so_header.created_mode,   --制单方式（10：自动，20：手动，30：全赔，不减少锁款）
       'N' draft_flag, --是否为承兑
       so_header.audit_flag,
       decode(so_header.erp_so_id,null,'N','Y') import_erp,--引入
       bill_type.SRC_TYPE_ID, --源单据ID
       bill_type.SRC_TYPE_CODE, --源单据编码
       so_header.erp_ou_id,
       so_header.erp_ou_name,
       so_header.origin_origin_type,--上级来源类型：01：计划订单 02：提货订单
       so_header.origin_origin_head_id,--上级来源头ID
       so_header.origin_origin_order_code,--上级来源单号
       NVL(so_header.project_flag,'N') project_flag, --工程机标识：N 否；Y 是
       so_header.entity_cust_flag,  --事业部客户标识
       so_header.discount_type  --折扣类型 add by xiaoxu
--SOH.NC_OI_FLAG,                               --引入NC接口标示
--cih.FINANCIAL_STATISTICAL_TYPE                --财务统计属性 <客户属性控制>
  FROM cims.T_SO_HEADER                so_header, --销售单头表
       cims.t_customer_header          cus_header, --客户头表
       cims.T_CUSTOMER_HEADER CPH  ,--父客户
       cims.T_CUSTOMER_SALES_MAIN_TYPE cus_main_type, --客户营销大类关系表
       /*cims.T_CUSTOMER_ORG             cur_org, --客户组织信息
       cims.v_bd_sales_region          v_region, --营销区域视图*/
       (select a.entity_id,a.customer_id,
               a.customer_code,
               a.sales_center_id,
               a.sales_center_code,
               a.sales_region_id,b.sales_region_code,b.sales_region_name
       from cims.T_CUSTOMER_ORG a , cims.v_bd_sales_region b
       where a.sales_region_id = b.sales_region_id(+)
       and nvl(a.active_flag,'Active') = 'Active') cur_org ,
       cims.v_so_bill_type_extend      bill_type, --单据类型信息视图
       (SELECT DISTINCT PDM_T.ENTITY_ID,PDM_T.CODE_VALUE,PDM_T.CODE_NAME FROM CIMS.V_UP_CODELIST PDM_T WHERE PDM_T.CODETYPE = 'POL_DISCOUNT_METHOD') PDM,
       (SELECT DISTINCT PDI_T.ENTITY_ID,PDI_T.CODE_VALUE,PDI_T.CODE_NAME FROM CIMS.V_UP_CODELIST PDI_T WHERE PDI_T.CODETYPE = 'POL_DISCOUNT_ITEM') PDI,
        UP_ORG_UNIT CL
 WHERE so_header.customer_id = cus_header.customer_id
   AND cus_header.customer_id = cus_main_type.custom_id
   AND so_header.sales_main_type = cus_main_type.sales_main_type_code
   AND so_header.entity_id = cus_main_type.entity_id
   AND NVL(cus_header.CUSTOMER_FATHER_CODE,' ') = CPH.CUSTOMER_CODE(+)
   AND so_header.customer_id = cur_org.customer_id(+)
   and so_header.sales_center_id = cur_org.sales_center_id(+)
   and so_header.entity_id = cur_org.entity_id(+)
   --AND cur_org.sales_region_id = v_region.sales_region_id(+)
   AND so_header.BILL_TYPE_ID = BILL_TYPE.BILL_TYPE_ID(+)
   AND so_header.entity_id = PDM.ENTITY_ID(+)
   AND so_header.Discount_Mode = PDM.CODE_VALUE(+)
   AND so_header.Entity_Id = PDI.ENTITY_ID(+)
   AND so_header.Discount_Item = PDI.CODE_VALUE(+)
   AND so_header.entity_id = cl.unit_id
/

