create view V_MES_INV_PO_HEADER as
select
       t.CLEARED_INV_CODE,
       t.BILLED_DATE,
       t.PO_STATUS,
       t.WORKSHOP_INV_CODE,
       t.PRINT_TIME,
       t.VENDOR_NAME,
       t.VENDOR_CODE,
       t.VENDOR_ID,
       t.PO_ID,
       t.PO_NUM,
       t.CREATED_BY,
       u.name as CREATED_BY_NAME,
       t.VENDOR_ORGANIZATION_ID,
       t.INV_FINANCE_CODE,
       t.PO_TYPE,
       t.Last_Update_Date
from t_inv_po_headers t
left join up_org_user u on u.account = t.created_by
with read only
/

