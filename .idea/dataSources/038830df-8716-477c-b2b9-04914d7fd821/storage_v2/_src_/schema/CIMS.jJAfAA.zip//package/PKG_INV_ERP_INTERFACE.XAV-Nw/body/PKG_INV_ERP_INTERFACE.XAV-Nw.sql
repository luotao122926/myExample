create PACKAGE BODY PKG_INV_ERP_INTERFACE
IS
/******************************************************************************
   NAME:        CIMS.PKG_INV_ERP_INTERFACE

   PURPOSE:     实现用户账户别名/库存组织/子库查询/订单类型等ERP接口的实体ID更新

   DEPEND ON:

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        2014/8/29   lingyy          1. Created this package.
******************************************************************************/


   PROCEDURE P_INV_UPDATE_ORG_ENTITY
   IS
   Cursor c_codelist  IS select a.code_value,b.entity_id from up_codelist a,up_codelist_entity b where a.codetype ='INV_OU_ID' and a.id=b.codelist_id(+);
   c_codelist_row   c_codelist%ROWTYPE;

   BEGIN


      FOR c_codelist_row IN c_codelist
      LOOP
        -- update t_inv_organization set entity_id=c_codelist_row.entity_id where operating_unit=c_codelist_row.code_value;
      insert into t_inv_organization(INV_ID,ENTITY_ID,BUSINESS_GROUP_ID,OPERATING_UNIT,OPERATING_UNIT_CODE,OPERATING_UNIT_NAME,LEGAL_ENTITY,LEGAL_ENTITY_NAME,ORGANIZATION_ID,ORGANIZATION_CODE,ORGANIZATION_NAME,SET_OF_BOOKS_ID,SET_OF_BOOKS_NAME,CHART_OF_ACCOUNTS_ID,INVENTORY_ENABLED_FLAG,USER_DEFINITION_ENABLE_DATE,DISABLE_DATE,REMARK,CREATED_BY,CREATION_DATE,LAST_UPDATED_BY,LAST_UPDATE_DATE)
       select                         S_INV_ORGANIZATION.Nextval,c_codelist_row.entity_id,BUSINESS_GROUP_ID,OPERATING_UNIT,OPERATING_UNIT_CODE,OPERATING_UNIT_NAME,LEGAL_ENTITY,LEGAL_ENTITY_NAME,ORGANIZATION_ID,ORGANIZATION_CODE,ORGANIZATION_NAME,SET_OF_BOOKS_ID,SET_OF_BOOKS_NAME,CHART_OF_ACCOUNTS_ID,INVENTORY_ENABLED_FLAG,USER_DEFINITION_ENABLE_DATE,DISABLE_DATE,REMARK,CREATED_BY,CREATION_DATE,LAST_UPDATED_BY,LAST_UPDATE_DATE
       from t_inv_organization where
       operating_unit=c_codelist_row.code_value
       and entity_id is null
       and ORGANIZATION_ID not in(
         select ORGANIZATION_ID from t_inv_organization where entity_id=c_codelist_row.entity_id and operating_unit=c_codelist_row.code_value
       ); --update by guibr

      END LOOP;
   END;

    PROCEDURE P_INV_UPDATE_BILLCONFIG_ENTITY
   IS
   Cursor c_codelist  IS select a.code_value,b.entity_id from up_codelist a,up_codelist_entity b where a.codetype ='INV_OU_ID' and a.id=b.codelist_id(+);
   c_codelist_row   c_codelist%ROWTYPE;

   BEGIN


      FOR c_codelist_row IN c_codelist
      LOOP
         update T_INV_BILL_CONFIG set entity_id=c_codelist_row.entity_id where org_id=c_codelist_row.code_value and entity_id is  null;
      END LOOP;
   END;


   /******************************************************************************
   NAME:        CIMS.PKG_INV_ERP_INTERFACE
   PURPOSE:     提供中转产品 从产品正式表引进中转产品表，中间要验证一下是否存在
                有效的产品财务分类信息，如果有，则从产品表引进，否则，不处理
   DEPEND ON:
   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        2015/11/18   sudy
   ******************************************************************************/

   PROCEDURE P_BD_INV_PRODUCTFINANCIALCLS(P_ITEM_ID In T_BD_ITEM.ITEM_ID%Type,
                                          P_RESULT In Out Number ,
                                          P_ERR_MSG In Out Varchar2) Is

      V_SEC_RESULT     CONSTANT NUMBER := 0; --成功返回
      V_ERR_RESULT     CONSTANT NUMBER := -1; --失败
      V_SUCCESS        CONSTANT VARCHAR2(10) := 'SUCCESS';
      R_ITEM T_BD_ITEM%Rowtype ;
      R_FINANC_TYPE T_BD_INV_FINANC_TYPE%Rowtype ;

      V_Count Number := 0 ;
   BEGIN

      P_RESULT  := V_SEC_RESULT;
      P_ERR_MSG := V_SUCCESS ;

      --从产品正式表获取产品信息
      Begin
        Select T.* Into R_ITEM From CIMS.T_BD_ITEM T Where T.ITEM_ID = P_ITEM_ID ;
      Exception When Others Then
        P_RESULT := V_ERR_RESULT ;
        P_ERR_MSG := '根据产品ID获取产品信息出错！'||Sqlcode || Sqlerrm ;
        Goto HERE ;
      End ;
      --检查是否存在对应财务分类信息
      Begin
        Select T.*
          Into R_Financ_Type
          From Cims.T_Bd_Inv_Financ_Type t
         Where T.Entity_Id = R_Item.Entity_Id
           And R_Item.Productfinancialcls =
               Nvl((Select A.Code_Name
                     From Up_Codelist a
                    Where A.Code_Value = T.Productfinancialcls
                      And A.Codetype = 'bd_inv_productfinancialcls'
                      And Rownum = 1),
                   T.Productfinancialcls)
           And Sysdate Between T.Begin_Date And Nvl(T.End_Date, Sysdate)
           And Rownum = 1;
      Exception When Others Then
        P_RESULT := V_ERR_RESULT ;
        P_ERR_MSG := '检查是否存在产品对应财务属性分类出错！'||Sqlcode || Sqlerrm ;
        Goto HERE ;
      End ;
      --如果存在有效分类,则将产品信息引入到中转产品信息表

      Begin
        Select Count(1)
          Into V_Count
          From Cims.T_Inv_Producting_Item t
         Where T.Entity_Id = R_Item.Entity_Id
           And T.Item_Code = R_Item.Item_Code
           And T.Po_Area_Code = 'M64';
      Exception When Others Then
         P_RESULT := V_ERR_RESULT ;
         P_ERR_MSG := '检查是否已经引入到中转产品表出错！'||Sqlcode || Sqlerrm ;
         Goto HERE ;
      End ;
      --判断该产品是否已经引入过，如果已经引入，则更新。否则插入
      If V_Count = 0 Then
          Begin
            Insert Into T_INV_PRODUCTING_ITEM(
                product_area_item_id,
                entity_id,
                producing_area_id,
                producing_area_code,
                producing_area_name,
                po_area_id,
                po_area_code,
                po_area_name,
                item_id,
                item_code,
                item_desc,
                begin_date,
                end_date,
                created_by,
                creation_date,
                last_updated_by,
                last_update_date,
                remark
            )Values(
               S_INV_PRODUCING_ITEM.NEXTVAL ,
               R_ITEM.Entity_Id,
               Null, --产地ID
               Null, --产地编码
               Null, --产地名称
               R_FINANC_TYPE.PO_AREA_ID,  --中转产地ID
               R_FINANC_TYPE.PO_AREA_CODE,   --中转产地编码
               R_FINANC_TYPE.PO_AREA_NAME,   --中转产地名称
               R_ITEM.ITEM_ID , --产品ID
               R_ITEM.Item_Code, --产地编码
               R_ITEM.Item_Name, --产地名称
               R_FINANC_TYPE.Begin_Date, --开始日期
               R_FINANC_TYPE.End_Date,   --终止日期
               '产品引入',
               Sysdate ,
               '产品引入',
               Sysdate ,
               Null --备注
            ) ;
          Exception When Others Then
            P_RESULT := V_ERR_RESULT ;
            P_ERR_MSG := '从产品正式表引入到中转产品表出错！'||Sqlcode || Sqlerrm ;
            Goto HERE ;
          End ;
      Elsif V_Count > 0 Then
          Begin
            Update Cims.T_Inv_Producting_Item t
               Set T.Po_Area_Id       = R_Financ_Type.Po_Area_Id,
                   T.Po_Area_Name     = R_Financ_Type.Po_Area_Name,
                   T.Item_Id          = R_Item.Item_Id,
                   T.Item_Desc        = R_Item.Item_Name,
                   T.Begin_Date       = R_Financ_Type.Begin_Date,
                   T.End_Date         = R_Financ_Type.End_Date,
                   T.Last_Update_Date = Sysdate,
                   T.Remark           = '上次引入时间：' ||
                                        To_Char(T.Last_Update_Date,
                                                'yyyy-mm-dd')
             Where T.Entity_Id = R_Item.Entity_Id
               And T.Item_Code = R_Item.Item_Code
               And T.Po_Area_Code = R_Financ_Type.Po_Area_Code;
          Exception When Others Then
            P_RESULT := V_ERR_RESULT ;
            P_ERR_MSG := '从产品正式表重新引入中转产品表出错！'||Sqlcode || Sqlerrm ;
            Goto HERE ;
          End ;
      End If ;

      <<HERE>>
      Null ;
   End ;

END PKG_INV_ERP_INTERFACE;
/

