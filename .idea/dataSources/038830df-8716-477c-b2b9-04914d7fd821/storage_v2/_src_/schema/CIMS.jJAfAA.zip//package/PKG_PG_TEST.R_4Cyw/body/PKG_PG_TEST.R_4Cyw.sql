create package body      pkg_pg_test is


procedure pg_udcodelist(
          codeType in varchar2,--编码类型
          codeValue in varchar2,--编码值
          codeName out varchar2, --输出信息
          p_Message out varchar2 --输出信息
  ) is

cursor clist is select u.* from up_codelist u where u.codetype=codeType and u.code_value=codeValue;
v_code clist%rowtype;
v_codecount number;
biz_exception exception;
begin
  p_Message:='SUCCESS';

  select count(u.id) into v_codecount from up_codelist u where u.code_value=codeValue and u.codetype=codeType;
          dbms_output.put_line('结果集行数:'||v_codecount);

  if not clist%isopen then
    open clist;
    dbms_output.put_line('打开游标');
  end if;
  fetch clist into v_code;
    --loop
        if clist%notfound then
          codeName:=codeValue;
          p_Message:='没找到此码表';
          dbms_output.put_line('没找到此码表');
          raise biz_exception;
        end if;
        codeName:=v_code.code_name;
        dbms_output.put_line('码表值:'||v_code.code_name);
    --end loop;


  if clist%isopen then
    close clist;
    dbms_output.put_line('关闭游标');
  end if;


  exception
    when others then
      dbms_output.put_line('错误:'||sqlerrm);
  end;


end pkg_pg_test;

/

