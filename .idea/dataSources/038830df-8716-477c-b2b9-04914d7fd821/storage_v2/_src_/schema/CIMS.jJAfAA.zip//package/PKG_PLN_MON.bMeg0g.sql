create PACKAGE PKG_PLN_MON IS

  -----------------------------------------------------------------------------
  -- AUTHOR  : 唐家智
  -- CREATED : 2015-07-10 10:06:52
  -- PURPOSE : 月计划汇总 
  -----------------------------------------------------------------------------
  PROCEDURE P_COLLECT_MONTHPLAN(P_SALES_CENTER_CODE IN VARCHAR2, --计划订单行、提货订单行 关系表主键id列表
                                P_PLAN_TYPE         IN VARCHAR2, --月计划类型
                                P_PLAN_PERIOD       IN VARCHAR2, --月计划周期
                                --p_hqIsCustomer In Varchar2,--总部是否根据客户汇总  Y 是  N否
                                P_SALES_MAIN_TYPE IN VARCHAR2, --营销大类
                                P_USER_CODE       IN VARCHAR2, --用户编码
                                P_ENTITY_ID       IN NUMBER, --主体Id
                                P_RESULT          IN OUT VARCHAR2, --返回结果：成功返回"SUCCESS"，失败返回原因
                                P_MPLN_HEAD_SEQUENCE IN OUT Varchar2 --返回汇总生成的单号，失败时为空
                                );
  -----------------------------------------------------------------------------
  -- AUTHOR  : ex_zhangcc
  -- CREATED : 2015-12-19
  -- PURPOSE : 月计划汇总退回
  -----------------------------------------------------------------------------
  PROCEDURE P_BACK_MONTHPLAN(P_MONTH_HEAD_ID IN NUMBER, --头ID
                             P_USER_CODE     IN VARCHAR2, -- 用户编码
                             P_RESULT        OUT VARCHAR2 --返回结果
                             );
  -----------------------------------------------------------------------------
  -- AUTHOR  : lilh6
  -- CREATED : 2017-4-10
  -- PURPOSE : 月计划跨主体结转                          
  ------------------------------------------------------------------------------------                              
  PROCEDURE P_CREATE_DOMESTIC_FORCAST(P_MONTH_HEAD_ID IN NUMBER, --头ID
                                      P_USER_CODE     IN VARCHAR2, -- 用户编码
                                      P_RESULT        OUT VARCHAR2 --返回结果
                                      );
    -----------------------------------------------------------------------------
 
  -----------------------------------------------------------------------------
  -- AUTHOR  : lilh6
  -- CREATED : 2018-9-27
  -- PURPOSE : 计算单价，库存，未满足量，开单未提量                          
  ------------------------------------------------------------------------------------                              
  Procedure p_Calculate_Monthplan(p_Month_Head_Id In Number, --头ID
                                  p_Result        Out Varchar2 --返回结果
                                  );
  -----------------------------------------------------------------------------
  -- AUTHOR  : lilh6
  -- CREATED : 2018-10-18
  -- PURPOSE : 月预测产品生命周期检查                        
  ------------------------------------------------------------------------------------                              
  Procedure p_Mon_Chk_Item_Prdc_Life_Cycle(p_Month_Head_Id In Number, --头ID
                                           p_Order_Phase   In Varchar2, --订单检查阶段
                                           p_Result        Out Varchar2 --返回结果
                                           );
  -----------------------------------------------------------------------------
  -- AUTHOR  : lilh6
  -- CREATED : 2018-11-29
  -- PURPOSE : 没有客户的中心、总部预测取价                  
  ------------------------------------------------------------------------------------                              
  Procedure p_Get_Center_Item_Price(p_Sales_Center_Code In Varchar2, --中心编码
                                    p_Item_Code         In Varchar2, --产品编码
                                    p_Entity_Id         In Number, --主体id
                                    p_Price             Out Number, --返回价格
                                    p_Result            Out Varchar2 --返回结果
                                    );
END PKG_PLN_MON;
/

