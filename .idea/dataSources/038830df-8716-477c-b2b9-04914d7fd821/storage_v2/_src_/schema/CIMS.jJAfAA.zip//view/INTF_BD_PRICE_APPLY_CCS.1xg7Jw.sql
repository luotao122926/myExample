create view INTF_BD_PRICE_APPLY_CCS as
select a.apply_code,
       a.apply_date,
       a.apply_type,
       a.apply_status,
       b.center_code sales_center_code,
       a.customer_code,
       --item_main_type,
       a.entity_id
  from T_BD_PRICE_APPLY a, t_bd_price_apply_detail b
 where a.price_apply_id = b.price_apply_id
/

