create package PKG_CREDIT_INTF_DUE is
  /*----------------------------------------------------------------
  *         包：PKG_CREDIT_INTF_DUE
  *   创建日期：2014-07-24
  *     创建者：苏冬渊
  *   功能说明：处理接口同步功能
  *
  *   过程成功：P_RESULT = 0
  *             P_ERR_MSG = 'SUCCESS';
  *
  *   过程失败：P_RESULT < -20000;
  *             P_ERR_MSG = 过程异常失败的提示信息
  *
  */ ----------------------------------------------------------------
  --定义主体、铺底单据类型、铺底类型的记录类型
  TYPE R_ENTITY_DELAYPAY_TYPE IS RECORD(
    ENTITY_ID          t_credit_delaypay.entity_id%TYPE, --主体ID
    DELAYPAY_BILL_CODE UP_CODELIST.CODE_VALUE%TYPE,
    DELAYPAY_BILL_NAME UP_CODELIST.CODE_NAME%Type,
    DELAYPAY_CODE      UP_CODELIST.CODE_VALUE%TYPE,
    DELAYPAY_NAME      UP_CODELIST.CODE_NAME%Type);
  TYPE C_ENTITY_DELAYPAY_TYPE IS TABLE OF R_ENTITY_DELAYPAY_TYPE /*INDEX BY BINARY_INTEGER*/
  ;

  --------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-24
  *     创建者：苏冬渊
  *   功能说明：处理小电铺底单据从接口表同步到业务表
  *
  *
  */
  -------------------------------------------------------------------------------
  PROCEDURE PRC_INTF_CREDIT_DELAYPAY(P_RESULT  IN OUT NUMBER, --返回错误ID
                                     P_ERR_MSG IN OUT VARCHAR2 --返回错误信息
                                     );

  --------------------------------------------------------------------------------
  /*
  *   创建日期：2015-08-01
  *     创建者：梁颜明
  *   功能说明：CSS调用小电铺底单据从接口表同步到业务表的处理
  *
  *
  */
  -------------------------------------------------------------------------------
  PROCEDURE PRC_INTF_CREDIT_DELAYPAY_BILL(P_SRC_BILL_ID IN NUMBER, --接口铺底单据ID
                                          P_BILL_ID     OUT NUMBER, --铺底单据ID
                                          P_RESULT      IN OUT NUMBER, --返回错误ID
                                          P_ERR_MSG     IN OUT VARCHAR2 --返回错误信息
                                          );

  --------------------------------------------------------------------------------
  /*
  *   创建日期：2015-03-27
  *     创建者：苏冬渊
  *   功能说明：处理小电铺底单据从接口表同步到业务表
  *
  *
  */
  -------------------------------------------------------------------------------
  /*PROCEDURE PRC_INTF_CREDIT_DELAYPAY(P_SOURCE_BILL_ID  In Number , --单据ID
    P_RESULT             IN OUT NUMBER, --返回错误ID
    P_ERR_MSG            IN OUT VARCHAR2 --返回错误信息
  ) ;*/

  FUNCTION FUN_GET_SALES_CENTER_INTO(P_ENTITY_ID   NUMBER,
                                     P_CUSTOMER_ID NUMBER,
                                     p_ACCOUNT_ID  NUMBER,
                                     P_FLAG        NUMBER) RETURN VARCHAR2;

  FUNCTION FUN_GET_ENTITY_DELAYPAY RETURN C_ENTITY_DELAYPAY_TYPE
    PIPELINED;

end PKG_CREDIT_INTF_DUE;
/

