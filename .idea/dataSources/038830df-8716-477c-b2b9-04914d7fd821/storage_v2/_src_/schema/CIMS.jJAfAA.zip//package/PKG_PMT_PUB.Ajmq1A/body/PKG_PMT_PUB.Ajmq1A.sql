create PACKAGE BODY PKG_PMT_PUB IS
  /**
     作者 ：吴林
     描述 ：推广物料老版本领用发货确认后释放库存占用 以及促发库存事务 回写单据号给运输合同
     日期：2015-12-10
  */
  PROCEDURE P_UNOCCUPY_INV_TRANSACTION_OLD(IN_ENTITYID     IN NUMBER,
                                           IN_SEND_HEAD_ID IN NUMBER,
                                           FLAG            OUT VARCHAR2,
                                           FLAGMESSAGE     OUT VARCHAR2) AS
  
  BEGIN
    FOR PMT_LINE_INFO IN (SELECT *
                            FROM T_PMT_COLLAR_SEND_LINE
                           WHERE COLLAR_SEND_HEAD_ID = IN_SEND_HEAD_ID
                             AND ENTITY_ID = IN_ENTITYID) LOOP
      P_PMT_COLLAR_SEND_UNOCCUPY_INV(IN_ENTITYID,
                                     PMT_LINE_INFO.COLLAR_SEND_HEAD_ID,
                                     PMT_LINE_INFO.COLLAR_SEND_LINE_ID,
                                     FLAG,
                                     FLAGMESSAGE);
      IF FLAG <> 0 THEN
        RAISE PKG_PMT_PUB.PMT_EXCEPTION;
      END IF;
    END LOOP;
    IF FLAG = 0 THEN
      P_PMT_INV_TRANSACTION(IN_ENTITYID => IN_ENTITYID,
                            IN_HEADID   => IN_SEND_HEAD_ID,
                            FLAG        => FLAG,
                            FLAGMESSAGE => FLAGMESSAGE);
    END IF;
    /*-- 回写发放单号给物流运输合同
    IF FLAG >= 0 THEN
      P_PMT_RETURN_WRIT_NUM(P_SEND_HEADER_ID =>IN_SEND_HEAD_ID,
                            P_RESULT => FLAG,
                            P_ERR_MSG => FLAGMESSAGE);
    END IF;*/
    IF FLAG >= 0 THEN
      FLAG        := PKG_PMT_PUB.V_RESULT;
      FLAGMESSAGE := PKG_PMT_PUB.V_RESULT_MSG;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      FLAG        := -1;
      FLAGMESSAGE := '调用P_UNOCCUPY_INV_TRANSACTION_OLD失败';
  END P_UNOCCUPY_INV_TRANSACTION_OLD;
  /**
   *  物料模块回调回写实际发货数量(老版本)
  */
  PROCEDURE P_UNOCCUPY_INV_TRANSACTION(IN_ENTITYID     IN NUMBER,
                                       IN_CURRUSER     IN VARCHAR2,
                                       IN_SEND_HEAD_ID IN NUMBER,
                                       IN_SEND_LINE_ID IN NUMBER,
                                       REC_QTY         IN NUMBER,
                                       FLAG            OUT VARCHAR2,
                                       FLAGMESSAGE     OUT VARCHAR2) AS
    V_REC_QTY     NUMBER := 0;
    V_COUNT       NUMBER := 0;
    V_REC_QTY_ALL NUMBER := 0;
    V_IS_FREE     NUMBER := 0;
  BEGIN
    FLAG        := 1;
    FLAGMESSAGE := 'ok';
    IF IN_SEND_HEAD_ID IS NULL THEN
      FLAG        := -1;
      FLAGMESSAGE := '发放单头表为空';
      RETURN;
    END IF;
    IF IN_SEND_LINE_ID IS NULL THEN
      FLAG        := -1;
      FLAGMESSAGE := '发放单行表表为空';
      RETURN;
    END IF;
  
    SELECT COUNT(*)
      INTO V_COUNT
      FROM T_PMT_COLLAR_SEND_HEAD T
     WHERE T.COLLAR_SEND_HEAD_ID = IN_SEND_HEAD_ID;
  
    IF V_COUNT = 0 THEN
      FLAG        := -1;
      FLAGMESSAGE := '找不到发放单头表信息';
      RETURN;
    END IF;
  
    V_COUNT := 0;
    SELECT COUNT(*)
      INTO V_COUNT
      FROM T_PMT_COLLAR_SEND_LINE T
     WHERE T.COLLAR_SEND_LINE_ID = IN_SEND_LINE_ID;
    IF V_COUNT = 0 THEN
      FLAG        := -1;
      FLAGMESSAGE := '找不到发放单行表信息';
      RETURN;
    END IF;
  
    P_PMT_COLLAR_SEND_UNOCCUPY_INV(IN_ENTITYID,
                                   IN_SEND_HEAD_ID,
                                   IN_SEND_LINE_ID,
                                   FLAG,
                                   FLAGMESSAGE);
    IF FLAG = 0 THEN
      P_PMT_INV_TRANSACTION(IN_ENTITYID => IN_ENTITYID,
                            IN_HEADID   => IN_SEND_HEAD_ID,
                            FLAG        => FLAG,
                            FLAGMESSAGE => FLAGMESSAGE);
    END IF;
    IF FLAG = 1 THEN
      FLAG        := 1;
      FLAGMESSAGE := 'ok';
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      FLAG        := -1;
      FLAGMESSAGE := '调用pmt_collar_send_setRecQty时发生异常！' ||
                     SUBSTR(SQLERRM, 1, 200);
      RETURN;
    
  END P_UNOCCUPY_INV_TRANSACTION;
  /**
     减少库存占用（老版本）
  */
  PROCEDURE P_PMT_COLLAR_SEND_UNOCCUPY_INV(IN_ENTITYID IN NUMBER,
                                           IN_HEADID   IN NUMBER,
                                           IN_LINEI    IN NUMBER,
                                           FLAG        OUT VARCHAR2,
                                           FLAGMESSAGE OUT VARCHAR2) AS
    CURSOR SEND_HEAD_INFO IS
      SELECT *
        FROM T_PMT_COLLAR_SEND_HEAD T
       WHERE T.COLLAR_SEND_HEAD_ID = IN_HEADID
         AND T.ENTITY_ID = IN_ENTITYID;
    CURSOR SEND_LINE_INFO IS
      SELECT *
        FROM T_PMT_COLLAR_SEND_LINE T
       WHERE T.COLLAR_SEND_LINE_ID = IN_LINEI
         AND T.ENTITY_ID = IN_ENTITYID;
    R_SEND_HEAD_INFO SEND_HEAD_INFO%ROWTYPE;
    R_SEND_LINE_INFO SEND_LINE_INFO%ROWTYPE;
    V_BILL_TYPE_NAME VARCHAR2(32);
    V_PMT_ORDER_NUM  VARCHAR2(32);
  
    CURSOR REQUIS_HEAD_INFO IS
      SELECT *
        FROM T_PMT_COLLAR_REQUIS_HEAD T
       WHERE T.PMT_ORDER_NUM = R_SEND_HEAD_INFO.PMT_ORDER_NUM;
    R_REQUIS_HEAD_INFO REQUIS_HEAD_INFO%ROWTYPE;
  
  BEGIN
  
    OPEN SEND_HEAD_INFO;
    LOOP
      FETCH SEND_HEAD_INFO
        INTO R_SEND_HEAD_INFO;
      EXIT WHEN SEND_HEAD_INFO%NOTFOUND;
    END LOOP;
    CLOSE SEND_HEAD_INFO;
  
    OPEN SEND_LINE_INFO;
    LOOP
      FETCH SEND_LINE_INFO
        INTO R_SEND_LINE_INFO;
      EXIT WHEN SEND_LINE_INFO%NOTFOUND;
    END LOOP;
    CLOSE SEND_LINE_INFO;
  
    OPEN REQUIS_HEAD_INFO;
    LOOP
      FETCH REQUIS_HEAD_INFO
        INTO R_REQUIS_HEAD_INFO;
      EXIT WHEN REQUIS_HEAD_INFO%NOTFOUND;
    END LOOP;
    CLOSE REQUIS_HEAD_INFO;
  
    BEGIN
      SELECT BILL_TYPE_NAME
        INTO V_BILL_TYPE_NAME
        FROM T_INV_BILL_TYPES
       WHERE SOURCE_TYPE_ID =
             (SELECT SOURCE_TYPE_ID
                FROM T_INV_SOURCE_TYPES
               WHERE SOURCE_TYPE_CODE = '1009'
                 AND ENTITY_ID = IN_ENTITYID
                 AND SYSDATE >= BEGIN_DATE
                 AND (END_DATE IS NULL OR SYSDATE <= END_DATE))
         AND SYSDATE >= BEGIN_DATE
         AND (END_DATE IS NULL OR SYSDATE <= END_DATE)
         AND ERP_TRANCATION = '10'
         AND ENTITY_ID = IN_ENTITYID;
    
    EXCEPTION
      WHEN OTHERS THEN
        FLAG        := '-1';
        FLAGMESSAGE := '单据不存在';
    END;
  
    FOR RESUIS_LINE_ID IN (SELECT *
                             FROM T_PMT_COLLAR_REQUIS_LINE T
                            WHERE T.COLLAR_REQUIS_HEAD_ID =
                                  R_REQUIS_HEAD_INFO.COLLAR_REQUIS_HEAD_ID) LOOP
      BEGIN
        IF RESUIS_LINE_ID.PMT_ID = R_SEND_LINE_INFO.PMT_ID THEN
          PKG_PLN_INV_OCCUPY.P_SOORDER_UNOCCUPY_STOCKS(R_REQUIS_HEAD_INFO.SHIP_INVENTORY_ID,
                                                       RESUIS_LINE_ID.PMT_ID,
                                                       R_SEND_LINE_INFO.RCV_QTY,
                                                       'A',
                                                       '推广物料占用',
                                                       R_REQUIS_HEAD_INFO.ENTITY_ID,
                                                       V_BILL_TYPE_NAME,
                                                       R_REQUIS_HEAD_INFO.COLLAR_REQUIS_HEAD_ID,
                                                       R_REQUIS_HEAD_INFO.PMT_ORDER_NUM,
                                                       RESUIS_LINE_ID.COLLAR_REQUIS_LINE_ID,
                                                       V_BILL_TYPE_NAME,
                                                       R_REQUIS_HEAD_INFO.COLLAR_REQUIS_HEAD_ID,
                                                       R_REQUIS_HEAD_INFO.PMT_ORDER_NUM,
                                                       RESUIS_LINE_ID.COLLAR_REQUIS_LINE_ID,
                                                       RESUIS_LINE_ID.CREATED_BY,
                                                       'Y',
                                                       FLAG,
                                                       FLAGMESSAGE);
        END IF;
      END;
    END LOOP;
  
  END P_PMT_COLLAR_SEND_UNOCCUPY_INV;
  /**
    触发库存事务（老版本）
  */
  PROCEDURE P_PMT_INV_TRANSACTION(IN_ENTITYID IN NUMBER,
                                  IN_HEADID   IN NUMBER,
                                  FLAG        OUT VARCHAR2,
                                  FLAGMESSAGE OUT VARCHAR2) AS
    CURSOR HEAD_INFO IS
      SELECT *
        FROM T_PMT_COLLAR_SEND_HEAD T
       WHERE T.COLLAR_SEND_HEAD_ID = IN_HEADID
         AND T.ENTITY_ID = IN_ENTITYID;
    R_HEAD_INFO    HEAD_INFO%ROWTYPE;
    V_BILL_TYPE_ID T_INV_BILL_TYPES.BILL_TYPE_ID%TYPE;
    V_STATUS       T_PMT_COLLAR_REQUIS_HEAD.STATUS%TYPE;
  BEGIN
    OPEN HEAD_INFO;
    LOOP
      FETCH HEAD_INFO
        INTO R_HEAD_INFO;
      EXIT WHEN HEAD_INFO%NOTFOUND;
    END LOOP;
    CLOSE HEAD_INFO;
    V_STATUS := R_HEAD_INFO.STATUS;
    IF V_STATUS = '23' THEN
      BEGIN
        SELECT BILL_TYPE_ID
          INTO V_BILL_TYPE_ID
          FROM T_INV_BILL_TYPES
         WHERE SOURCE_TYPE_ID =
               (SELECT SOURCE_TYPE_ID
                  FROM T_INV_SOURCE_TYPES
                 WHERE SOURCE_TYPE_CODE = '1009'
                   AND ENTITY_ID = IN_ENTITYID
                   AND SYSDATE >= BEGIN_DATE
                   AND (END_DATE IS NULL OR SYSDATE <= END_DATE))
           AND SYSDATE >= BEGIN_DATE
           AND (END_DATE IS NULL OR SYSDATE <= END_DATE)
           AND ERP_TRANCATION = '10'
           AND ENTITY_ID = IN_ENTITYID;
      EXCEPTION
        WHEN OTHERS THEN
          FLAG        := '-1';
          FLAGMESSAGE := '单据信息不存在';
          RETURN;
      END;
      PKG_INV_TRANSACTION.INV_TRANSACTION_TOTAL_DEAL(IN_ENTITY_ID          => IN_ENTITYID,
                                                     IN_BILL_TYPE_ID       => V_BILL_TYPE_ID,
                                                     IS_BUSINESS_STATE     => V_STATUS,
                                                     ID_TRANSACTION_DATE   => R_HEAD_INFO.SEND_DATE,
                                                     IN_BUSINESS_HEADER_ID => IN_HEADID,
                                                     IN_IF_NULL            => 0,
                                                     IS_BILL_KIND          => 'B5',
                                                     ON_FLAG               => FLAG,
                                                     OS_PROMPT             => FLAGMESSAGE);
    
    ELSE
      FLAG        := '-1';
      FLAGMESSAGE := '单据状态不为已发放状态';
      RETURN;
    END IF;
    IF FLAG = 0 THEN
      FLAG        := '1';
      FLAGMESSAGE := 'ok';
    END IF;
  END P_PMT_INV_TRANSACTION;
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-07-10
  *     创建者：吴林
  *   功能说明：发货确认触发生成发放通知单入口
  *
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_PMT_ENTRY_SHIP(P_SHIP_INFO_ID IN NUMBER, --实际发货信息ID
                             P_USER_CODE    IN VARCHAR2, --操作用户编码
                             P_ORDER_TYPE   IN VARCHAR2, --单据类型
                             P_SEND_HEAD_ID OUT NUMBER, --生成发放单的头表ID
                             P_RESULT       OUT NUMBER, --返回错误ID
                             P_ERR_MSG      OUT VARCHAR2 --返回错误信息
                             ) IS
    --发货信息ID（临时变量，用于进行并发控制）
    TMP_SHIP_INFO_ID NUMBER;
  
    TMP_SO_INTF_COUNT NUMBER;
  
    --发货信息游标
    CURSOR C_SHIP_INFO IS
      SELECT * FROM T_LG_ACTUAL_SHIP WHERE ACTUAL_SHIP_ID = P_SHIP_INFO_ID;
    --发货信息记录
    R_SHIP_INFO C_SHIP_INFO%ROWTYPE;
  
    --发货信息行游标
    CURSOR C_SHIP_INFO_LINE IS
      SELECT *
        FROM T_LG_ACTUAL_SHIP_LINE
       WHERE SHIP_INFO_ID = P_SHIP_INFO_ID;
    --发货信息行记录
    R_SHIP_INFO_LINE C_SHIP_INFO_LINE%ROWTYPE;
  
    --产品数量
    V_ITEM_QTY NUMBER := 0;
    --产品价格
    V_ITEM_PRICE NUMBER := 0;
    --产品编码
    V_ITEM_CODE VARCHAR2(50) := '';
    --主体
    V_ENTITY_ID T_BD_ITEM.ENTITY_ID%TYPE;
    --总金额
    V_TOTAL_AMOUNT NUMBER := 0;
    --总体积
    V_TOTAL_V NUMBER := 0;
    --总重量
    V_TOTAL_W NUMBER := 0;
  
    CURSOR C_ITEM_INFO IS
      SELECT *
        FROM T_BD_ITEM
       WHERE ITEM_CODE = V_ITEM_CODE
         AND ENTITY_ID = V_ENTITY_ID;
    --产品信息记录
    R_ITEM_INFO C_ITEM_INFO%ROWTYPE;
  
    --发放单头记录
    R_PMT_COLLAR_SEND_HEAD T_PMT_COLLAR_SEND_HEAD%ROWTYPE;
    --发放单据行记录
    R_PMT_COLLAR_SEND_LINE T_PMT_COLLAR_SEND_LINE%ROWTYPE;
  
    --来源类型：
    V_ORIGIN_TYPE VARCHAR2(32);
  
    --发货通知单ID、发货通知单行ID、自提标记、直发标记
    V_SHIP_DOC_ID      T_LG_SHIP_DOC.SHIP_DOC_ID%TYPE;
    V_SELF_PICK_FLAG   T_LG_SHIP_DOC.PICK_FLAG%TYPE := 'N';
    V_DIRECT_SHIP_FLAG T_LG_SHIP_DOC.IS_CUSG_FLAG%TYPE := 'N';
  
    --发货通知单头信息：发放单的大部分信息从发货通知单头取
    CURSOR C_LG_SHIP_DOC IS
      SELECT * FROM T_LG_SHIP_DOC WHERE SHIP_DOC_ID = V_SHIP_DOC_ID;
    --发货通知单头记录信息
    R_LG_SHIP_DOC C_LG_SHIP_DOC%ROWTYPE;
  
    --营销中心信息
  
    V_SALES_CENTER_ID   T_PMT_COLLAR_SEND_HEAD.SALES_CENTER_ID%TYPE;
    V_SALES_CENTER_CODE T_PMT_COLLAR_SEND_HEAD.SALES_CENTER_CODE%TYPE;
    V_SALES_CENTER_NAME T_PMT_COLLAR_SEND_HEAD.SALES_CENTER_NAME%TYPE;
  
    --操作用户编码
    V_USER_CODE VARCHAR2(32);
  
    V_SHIP_LINE T_LG_SHIP_DOC_LINE%ROWTYPE;
    --单据类型
    VR_INV_BILL_TYPE    T_INV_BILL_TYPES%ROWTYPE;
  BEGIN
    --初始返回值
    P_RESULT  := PKG_PMT_PUB.V_RESULT;
    P_ERR_MSG := PKG_PMT_PUB.V_RESULT_MSG;
  
    --并发控制
    BEGIN
      SELECT ACTUAL_SHIP_ID
        INTO TMP_SHIP_INFO_ID
        FROM T_LG_ACTUAL_SHIP
       WHERE ACTUAL_SHIP_ID = P_SHIP_INFO_ID
         FOR UPDATE WAIT 2;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        P_RESULT  := -10001;
        P_ERR_MSG := '当前实际发货信息[ID：' || P_SHIP_INFO_ID || ']不存在，请检查！';
        RAISE PKG_PMT_PUB.PMT_EXCEPTION;
      WHEN OTHERS THEN
        P_RESULT  := -10002;
        P_ERR_MSG := '当前实际发货信息[ID：' || P_SHIP_INFO_ID ||
                     ']正被其他用户使用，请稍后再试 ！';
        RAISE PKG_PMT_PUB.PMT_EXCEPTION;
    END;
  
    IF P_RESULT < 0 THEN
      RETURN;
    END IF;
    --并发控制结束
  
    --校验单据类型是不是为空
    IF P_ORDER_TYPE IS NULL THEN
      P_RESULT  := -10021;
      P_ERR_MSG := '单据类型不能为空';
      RAISE PKG_PMT_PUB.PMT_EXCEPTION;
    END IF;
  
    --获取发货信息记录
    OPEN C_SHIP_INFO;
    FETCH C_SHIP_INFO
      INTO R_SHIP_INFO;
    CLOSE C_SHIP_INFO;
  
    --如果传入的为空，则取创建人的编码
    IF (P_USER_CODE IS NULL) THEN
      V_USER_CODE := R_SHIP_INFO.CREATED_BY;
    ELSE
      V_USER_CODE := P_USER_CODE;
    END IF;
  
    --来源类型
    V_ORIGIN_TYPE := R_SHIP_INFO.ORIGIN_TYPE;
  
    IF (R_SHIP_INFO.CUSTOMER_ID IS NULL) OR
       (R_SHIP_INFO.CUSTOMER_CODE IS NULL) THEN
      P_RESULT  := -10003;
      P_ERR_MSG := '当前实际发货信息[ID：' || P_SHIP_INFO_ID || '] 的客户ID或客户编码为空！';
      RAISE PKG_PMT_PUB.PMT_EXCEPTION;
    END IF;
  
    IF (R_SHIP_INFO.ACCOUNT_CODE IS NULL) THEN
      P_RESULT  := -10004;
      P_ERR_MSG := '当前实际发货信息[ID：' || P_SHIP_INFO_ID || '] 的账户编码为空！';
      RAISE PKG_PMT_PUB.PMT_EXCEPTION;
    END IF;
  
    --获取账户ID、名称等信息
    BEGIN
      SELECT ACCOUNT_ID, ACCOUNT_NAME
        INTO R_PMT_COLLAR_SEND_HEAD.ACCOUNT_ID,
             R_PMT_COLLAR_SEND_HEAD.ACCOUNT_NAME
        FROM V_CUST_ACCOUNT
       WHERE CUSTOMER_CODE = R_SHIP_INFO.CUSTOMER_CODE
         AND ACCOUNT_CODE = R_SHIP_INFO.ACCOUNT_CODE
         AND ENTITY_ID = R_SHIP_INFO.ENTITY_ID
         AND ROWNUM = 1;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        P_RESULT  := -10005;
        P_ERR_MSG := '客户编码[' || R_SHIP_INFO.CUSTOMER_CODE || ']、账户编码[' ||
                     R_SHIP_INFO.ACCOUNT_CODE || ']、主体[' ||
                     R_SHIP_INFO.ENTITY_ID ||
                     ']信息不在视图(V_CUST_ACCOUNT)里或已经失效。';
        RAISE PKG_PMT_PUB.PMT_EXCEPTION;
      WHEN OTHERS THEN
        P_RESULT  := -10006;
        P_ERR_MSG := '根据客户编码[' || R_SHIP_INFO.CUSTOMER_CODE || ']、账户编码[' ||
                     R_SHIP_INFO.ACCOUNT_CODE || ']获取账户信息发生异常：' || SQLERRM;
        RAISE PKG_PMT_PUB.PMT_EXCEPTION;
    END;
  
    --从发货通知单上取自提标记、直发标记
    BEGIN
      --获取发货通知单ID
      SELECT B.SHIP_DOC_ID
        INTO V_SHIP_DOC_ID
        FROM T_LG_ACTUAL_SHIP_LINE A, T_LG_SHIP_DOC_LINE B
       WHERE A.SHIP_DOC_LINE_ID = B.SHIP_DOC_LINE_ID
         AND A.SHIP_INFO_ID = P_SHIP_INFO_ID
         AND ROWNUM = 1;
    
      --获取发货通知单信息
      OPEN C_LG_SHIP_DOC;
      FETCH C_LG_SHIP_DOC
        INTO R_LG_SHIP_DOC;
      CLOSE C_LG_SHIP_DOC;
    
      IF (R_LG_SHIP_DOC.SHIP_DOC_ID IS NULL) THEN
        P_RESULT  := -10007;
        P_ERR_MSG := '发货通知单[ID：' || V_SHIP_DOC_ID || ']不存在。';
        RAISE PKG_PMT_PUB.PMT_EXCEPTION;
      END IF;
    
      --自提标识和直发标识
      V_SELF_PICK_FLAG   := R_LG_SHIP_DOC.PICK_FLAG;
      V_DIRECT_SHIP_FLAG := R_LG_SHIP_DOC.IS_CUSG_FLAG;
    
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        P_RESULT  := -10008;
        P_ERR_MSG := '根据实际发货信息[ID：' || P_SHIP_INFO_ID || ']找不到对应的发货通知单ID。';
        RAISE PKG_PMT_PUB.PMT_EXCEPTION;
      WHEN PKG_SO_PUB.V_BIZ_EXCEPTION THEN
        RAISE PKG_PMT_PUB.PMT_EXCEPTION;
      WHEN OTHERS THEN
        P_RESULT  := -10009;
        P_ERR_MSG := '获取发货通知单[ID：' || V_SHIP_DOC_ID || ']信息出错：' || SQLERRM;
        RAISE PKG_PMT_PUB.PMT_EXCEPTION;
    END;
  
    --获取营销中心信息
    BEGIN
      SELECT SALES_CENTER_ID, SALES_CENTER_CODE, SALES_CENTER_NAME
        INTO V_SALES_CENTER_ID, V_SALES_CENTER_CODE, V_SALES_CENTER_NAME
        FROM V_BD_SALES_CENTER
       WHERE SALES_CENTER_ID = R_LG_SHIP_DOC.SALES_CENTER_ID
         AND ENTITY_ID = R_SHIP_INFO.ENTITY_ID
         AND ROWNUM = 1;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        P_RESULT  := -10010;
        P_ERR_MSG := '营销中心[ID：' || R_LG_SHIP_DOC.SALES_CENTER_ID ||
                     ']在V_BD_SALES_CENTER视图里不存在。';
        RAISE PKG_PMT_PUB.PMT_EXCEPTION;
      WHEN OTHERS THEN
        P_RESULT  := -10011;
        P_ERR_MSG := '获取营销中心[ID：' || V_SHIP_DOC_ID || ']发生异常：' || SQLERRM;
        RAISE PKG_PMT_PUB.PMT_EXCEPTION;
    END;
    
    --VR_INV_BILL_TYPE
    IF R_SHIP_INFO.SALES_ORDER_TYPE_ID IS NULL OR 0 >= R_SHIP_INFO.SALES_ORDER_TYPE_ID THEN
      SELECT BT.* INTO VR_INV_BILL_TYPE FROM T_INV_BILL_TYPES BT
      INNER JOIN T_INV_TRANSACTION_TYPES TT
      ON (TT.TRANSACTION_TYPE_ID = BT.TRANSACTION_TYPE_ID)
      WHERE BT.ENTITY_ID = R_SHIP_INFO.ENTITY_ID
      AND SYSDATE >= BT.BEGIN_DATE
      AND (BT.END_DATE IS NULL OR SYSDATE <= BT.END_DATE)
      AND TT.ACTION_TYPE = '02'--03
      ;
    ELSE
      SELECT BT.* INTO VR_INV_BILL_TYPE FROM T_INV_BILL_TYPES BT
      WHERE BT.BILL_TYPE_ID = R_SHIP_INFO.SALES_ORDER_TYPE_ID
      AND BT.ENTITY_ID = R_SHIP_INFO.ENTITY_ID
      ;
    END IF;
    R_PMT_COLLAR_SEND_HEAD.BILL_TYPE_ID := VR_INV_BILL_TYPE.BILL_TYPE_ID;
    R_PMT_COLLAR_SEND_HEAD.BILL_TYPE_CODE  := VR_INV_BILL_TYPE.BILL_TYPE_CODE;
    R_PMT_COLLAR_SEND_HEAD.BILL_TYPE_NAME  := VR_INV_BILL_TYPE.BILL_TYPE_NAME;
  
    --对发放单据头记录赋值
    R_PMT_COLLAR_SEND_HEAD.ENTITY_ID                    := R_SHIP_INFO.ENTITY_ID; --主体ID
    R_PMT_COLLAR_SEND_HEAD.DOC_TYPE                     := R_SHIP_INFO.SALES_ORDER_TYPE_ID; --销售单据类型ID
    R_PMT_COLLAR_SEND_HEAD.REQUIS_DATE                  := TO_DATE(NVL(R_SHIP_INFO.SHIP_DATE,
                                                                       SYSDATE));
    R_PMT_COLLAR_SEND_HEAD.SALES_CENTER_ID              := V_SALES_CENTER_ID; --营销中心ID
    R_PMT_COLLAR_SEND_HEAD.SALES_CENTER_CODE            := V_SALES_CENTER_CODE; --营销中心编码
    R_PMT_COLLAR_SEND_HEAD.SALES_CENTER_NAME            := V_SALES_CENTER_NAME; --营销中心名称
    R_PMT_COLLAR_SEND_HEAD.STATUS                       := '23';
    R_PMT_COLLAR_SEND_HEAD.VERSION                      := 0;
    R_PMT_COLLAR_SEND_HEAD.REQUESTOR                    := V_USER_CODE;
    R_PMT_COLLAR_SEND_HEAD.SHIP_INVENTORY_ID            := R_LG_SHIP_DOC.SHIP_INVENTORY_ID;
    R_PMT_COLLAR_SEND_HEAD.SHIP_INVENTORY_CODE          := R_LG_SHIP_DOC.SHIP_INVENTORY_CODE;
    R_PMT_COLLAR_SEND_HEAD.SHIP_INVENTORY_NAME          := R_LG_SHIP_DOC.SHIP_INVENTORY_NAME;
    R_PMT_COLLAR_SEND_HEAD.SALES_MAIN_TYPE              := R_SHIP_INFO.SALES_MAIN_TYPE;
    R_PMT_COLLAR_SEND_HEAD.CUSTOMER_ID                  := R_SHIP_INFO.CUSTOMER_ID; --客户ID
    R_PMT_COLLAR_SEND_HEAD.CUSTOMER_CODE                := R_SHIP_INFO.CUSTOMER_CODE; --客户编码
    R_PMT_COLLAR_SEND_HEAD.CUSTOMER_NAME                := R_SHIP_INFO.CUSTOMER_NAME; --客户名称
    R_PMT_COLLAR_SEND_HEAD.ACCOUNT_CODE                 := R_SHIP_INFO.ACCOUNT_CODE; --客户账户编码
    R_PMT_COLLAR_SEND_HEAD.IN_INVENTORY_ID              := R_SHIP_INFO.CONSIGNEE_INVENTORY_ID;
    R_PMT_COLLAR_SEND_HEAD.IN_INVENTORY_CODE            := R_LG_SHIP_DOC.CONSIGNEE_INVENTORY_CODE;
    R_PMT_COLLAR_SEND_HEAD.IN_INVENTORY_NAME            := R_LG_SHIP_DOC.CONSIGNEE_INVENTORY_NAME;
    R_PMT_COLLAR_SEND_HEAD.CONSIGNEE_LINKMAN            := R_LG_SHIP_DOC.CUSTOMER_CONTACTS;
    R_PMT_COLLAR_SEND_HEAD.CONSIGNEE_TE                 := R_LG_SHIP_DOC.CUSTOMER_CONTACTS_PHONES;
    R_PMT_COLLAR_SEND_HEAD.CONSIGNEE_ARE                := R_LG_SHIP_DOC.CONSIGNEE_LOCATION;
    R_PMT_COLLAR_SEND_HEAD.CONSIGNEE_ADD                := R_LG_SHIP_DOC.CONSIGNEE_ADDR;
    R_PMT_COLLAR_SEND_HEAD.PMT_ORDER_NUM                := R_SHIP_INFO.ORIGIN_ORDER_NUM;
    R_PMT_COLLAR_SEND_HEAD.CONSIGNEE_COMPANY_CONTACT_ID := R_LG_SHIP_DOC.CONSIGNEE_COMPANY_CONTACT_ID;
    R_PMT_COLLAR_SEND_HEAD.CONSIGNEE_COMPANY_CONTRACT   := R_LG_SHIP_DOC.CONSIGNEE_COMPANY_CONTRACT;
    R_PMT_COLLAR_SEND_HEAD.CONSIGNEE_COMPANY_TEL        := R_LG_SHIP_DOC.CONSIGNEE_COMPANY_TEL;
    R_PMT_COLLAR_SEND_HEAD.SEND_DATE                    := TRUNC(SYSDATE);
    R_PMT_COLLAR_SEND_HEAD.SOURCE_SYSTEM                := 'CIMS';
    R_PMT_COLLAR_SEND_HEAD.ORDER_TYPE                   := P_ORDER_TYPE;
    IF P_ORDER_TYPE = '02' OR P_ORDER_TYPE = '03' THEN
      R_PMT_COLLAR_SEND_HEAD.SOURCE_TYPE := '01';
    END IF;
    IF P_ORDER_TYPE = '04' THEN
      R_PMT_COLLAR_SEND_HEAD.SOURCE_TYPE := '02';
    END IF;
    R_PMT_COLLAR_SEND_HEAD.CREATED_BY        := R_LG_SHIP_DOC.CREATED_BY;
    R_PMT_COLLAR_SEND_HEAD.CREATION_DATE     := SYSDATE;
    R_PMT_COLLAR_SEND_HEAD.LAST_UPDATED_BY   := R_LG_SHIP_DOC.CREATED_BY;
    R_PMT_COLLAR_SEND_HEAD.LAST_UPDATED_DATE := SYSDATE;
    R_PMT_COLLAR_SEND_HEAD.SHIP_DOC_CODE     := R_LG_SHIP_DOC.SHIP_DOC_CODE;
    --设置发放单单据号
    R_PMT_COLLAR_SEND_HEAD.PMT_SEND_NUM := 'SEND' ||
                                           PKG_BD.F_GET_BILL_NO(P_BILL_TYPE  => 'SENDNUMBERAPP',
                                                                P_PREFIX_ADD => 'SEND',
                                                                P_ENTITY_ID  => R_SHIP_INFO.ENTITY_ID,
                                                                P_USER_ID    => NULL);
    --设置发放单头表ID
    BEGIN
      SELECT S_PMT_COLLAR_SEND_HEAD.NEXTVAL
        INTO R_PMT_COLLAR_SEND_HEAD.COLLAR_SEND_HEAD_ID
        FROM DUAL;
    EXCEPTION
    
      WHEN NO_DATA_FOUND THEN
        P_RESULT  := -10012;
        P_ERR_MSG := '获取发放单头表ID序列失败!';
        RAISE PKG_PMT_PUB.PMT_EXCEPTION;
    END;
    --设置发放单是否自提
    IF (V_SELF_PICK_FLAG = 'Y') THEN
      R_PMT_COLLAR_SEND_HEAD.RELEASE_TYPE := '01';
    ELSE
      R_PMT_COLLAR_SEND_HEAD.RELEASE_TYPE := '02';
    END IF;
  
    -- 保存发放单头表
    BEGIN
      INSERT INTO T_PMT_COLLAR_SEND_HEAD VALUES R_PMT_COLLAR_SEND_HEAD;
    EXCEPTION
    
      WHEN NO_DATA_FOUND THEN
        P_RESULT  := -10013;
        P_ERR_MSG := '保存发放单头表失败!';
        RAISE PKG_PMT_PUB.PMT_EXCEPTION;
    END;
  
    --生成发放单据行记录
    OPEN C_SHIP_INFO_LINE;
    LOOP
      FETCH C_SHIP_INFO_LINE
        INTO R_SHIP_INFO_LINE;
      EXIT WHEN C_SHIP_INFO_LINE%NOTFOUND;
    
      --产品数量
      V_ITEM_QTY := NVL(R_SHIP_INFO_LINE.ITEM_QTY, 0);
    
      R_PMT_COLLAR_SEND_LINE.COLLAR_SEND_HEAD_ID := R_PMT_COLLAR_SEND_HEAD.COLLAR_SEND_HEAD_ID;
      R_PMT_COLLAR_SEND_LINE.ENTITY_ID           := R_SHIP_INFO.ENTITY_ID; --主体ID
      R_PMT_COLLAR_SEND_LINE.ORIGIN_ORDER_ID     := R_SHIP_INFO.ORIGIN_ORDER_ID; --来源单据ID
      R_PMT_COLLAR_SEND_LINE.ORIGIN_LINE_ID      := R_SHIP_INFO_LINE.ORIGIN_LINE_ID; --来源单据行ID
      R_PMT_COLLAR_SEND_LINE.VERSION             := 0;
      R_PMT_COLLAR_SEND_LINE.PMT_CODE            := R_SHIP_INFO_LINE.ITEM_CODE; --产品编码
    
      R_PMT_COLLAR_SEND_LINE.RCV_QTY := V_ITEM_QTY; --产品数量
    
      R_PMT_COLLAR_SEND_LINE.SHIP_DOC_LINE_ID := R_SHIP_INFO_LINE.SHIP_DOC_LINE_ID; --发货通知单行ID
    
      --产品编码
      V_ITEM_CODE := R_SHIP_INFO_LINE.ITEM_CODE;
      V_ENTITY_ID := R_PMT_COLLAR_SEND_HEAD.ENTITY_ID;
    
      OPEN C_ITEM_INFO;
      FETCH C_ITEM_INFO
        INTO R_ITEM_INFO;
      CLOSE C_ITEM_INFO;
      --add by zhangcc 2016-06-25
      SELECT *
        INTO V_SHIP_LINE
        FROM T_LG_SHIP_DOC_LINE L
       WHERE L.SHIP_DOC_LINE_ID = R_SHIP_INFO_LINE.SHIP_DOC_LINE_ID;
    
      --取最新的物料名称
      R_PMT_COLLAR_SEND_LINE.PMT_NAME := R_ITEM_INFO.ITEM_NAME; --产品名称
    
      R_PMT_COLLAR_SEND_LINE.PMT_ID            := R_ITEM_INFO.ITEM_ID; --产品ID
      R_PMT_COLLAR_SEND_LINE.UNIT              := R_ITEM_INFO.DEFAULTUNIT; --产品单位
      R_PMT_COLLAR_SEND_LINE.VOLUME_UOM        := R_ITEM_INFO.PACKINGSIZE; --产品外包装体积
      R_PMT_COLLAR_SEND_LINE.WEIGHT_UOM        := R_ITEM_INFO.GROSSWEIGHT; --产品毛重
      R_PMT_COLLAR_SEND_LINE.VOLUME_TOTAL      := R_ITEM_INFO.PACKINGSIZE *
                                                  V_ITEM_QTY;
      R_PMT_COLLAR_SEND_LINE.WEIGHT_TOTAL      := R_ITEM_INFO.GROSSWEIGHT *
                                                  V_ITEM_QTY;
      R_PMT_COLLAR_SEND_LINE.CREATED_BY        := R_PMT_COLLAR_SEND_HEAD.CREATED_BY;
      R_PMT_COLLAR_SEND_LINE.CREATION_DATE     := R_PMT_COLLAR_SEND_HEAD.CREATION_DATE;
      R_PMT_COLLAR_SEND_LINE.LAST_UPDATED_BY   := R_PMT_COLLAR_SEND_HEAD.LAST_UPDATED_BY;
      R_PMT_COLLAR_SEND_LINE.LAST_UPDATED_DATE := R_PMT_COLLAR_SEND_HEAD.LAST_UPDATED_DATE;
      R_PMT_COLLAR_SEND_LINE.PRICE             := NVL(V_SHIP_LINE.ITEM_PRICE,
                                                      0);
      R_PMT_COLLAR_SEND_LINE.AMOUNT            := NVL(V_SHIP_LINE.ITEM_PRICE,
                                                      0) * V_ITEM_QTY;
      R_PMT_COLLAR_SEND_LINE.CREATED_BY        := R_LG_SHIP_DOC.CREATED_BY;
      R_PMT_COLLAR_SEND_LINE.CREATION_DATE     := SYSDATE;
      R_PMT_COLLAR_SEND_LINE.LAST_UPDATED_BY   := R_LG_SHIP_DOC.CREATED_BY;
      R_PMT_COLLAR_SEND_LINE.LAST_UPDATED_DATE := SYSDATE;
      --设置发放单头表ID
      BEGIN
        SELECT S_PMT_COLLAR_SEND_LINE.NEXTVAL
          INTO R_PMT_COLLAR_SEND_LINE.COLLAR_SEND_LINE_ID
          FROM DUAL;
      EXCEPTION
      
        WHEN NO_DATA_FOUND THEN
          P_RESULT  := -10014;
          P_ERR_MSG := '获取发放单行表表ID序列失败!';
          RAISE PKG_PMT_PUB.PMT_EXCEPTION;
      END;
      -- 保存发放单头表
      BEGIN
        INSERT INTO T_PMT_COLLAR_SEND_LINE VALUES R_PMT_COLLAR_SEND_LINE;
      EXCEPTION
      
        WHEN NO_DATA_FOUND THEN
          P_RESULT  := -10015;
          P_ERR_MSG := '保存发放单行表表失败!';
          RAISE PKG_PMT_PUB.PMT_EXCEPTION;
      END;
    
    END LOOP;
    CLOSE C_SHIP_INFO_LINE;
    --汇总产品的重量，体积 ，金额
    BEGIN
      SELECT NVL(SUM(T.AMOUNT), 0),
             NVL(SUM(T.VOLUME_TOTAL), 0),
             NVL(SUM(T.WEIGHT_UOM), 0)
        INTO V_TOTAL_AMOUNT, V_TOTAL_V, V_TOTAL_W
        FROM T_PMT_COLLAR_SEND_LINE T
       WHERE T.COLLAR_SEND_HEAD_ID =
             R_PMT_COLLAR_SEND_HEAD.COLLAR_SEND_HEAD_ID;
    EXCEPTION
      WHEN OTHERS THEN
        P_RESULT  := -10016;
        P_ERR_MSG := '汇总产品信息失败！';
        RAISE PKG_PMT_PUB.PMT_EXCEPTION;
    END;
    --更新发放单头表的总重量，总体积，总金额
    BEGIN
      UPDATE T_PMT_COLLAR_SEND_HEAD T
         SET T.REQUIS_AMOUNT_TOTAL   = V_TOTAL_AMOUNT,
             T.APPROVAL_AMOUNT_TOTAL = V_TOTAL_AMOUNT,
             T.VOLUME_TOTAL          = V_TOTAL_V,
             T.WEIGHT_TOTAL          = V_TOTAL_W
       WHERE T.COLLAR_SEND_HEAD_ID =
             R_PMT_COLLAR_SEND_HEAD.COLLAR_SEND_HEAD_ID;
    EXCEPTION
      WHEN OTHERS THEN
        P_RESULT  := -10017;
        P_ERR_MSG := '更新发放单头表的总重量 总体积，总金额失败！' || SQLERRM;
        RAISE PKG_PMT_PUB.PMT_EXCEPTION;
    END;
    -- 从提货订单过来
    IF P_ORDER_TYPE = '02' OR P_ORDER_TYPE = '03' THEN
      --   生成发放单后 做库存事务以及 取消库存占用  信用控制等后续操作
      PKG_PMT_PUB.P_UNOCCUPY_INV_TRANSACTION_NEW(IN_ENTITYID     => R_PMT_COLLAR_SEND_HEAD.ENTITY_ID,
                                                 IN_SEND_HEAD_ID => R_PMT_COLLAR_SEND_HEAD.COLLAR_SEND_HEAD_ID,
                                                 FLAG            => P_RESULT,
                                                 FLAGMESSAGE     => P_ERR_MSG);
    END IF;
    --从推广物料领用过来
    IF P_ORDER_TYPE = '04' THEN
      P_CHECK_SEND_QTY(IN_HEAD_ID   => R_PMT_COLLAR_SEND_HEAD.COLLAR_SEND_HEAD_ID,
                       O_S_FLAG     => P_RESULT,
                       O_S_FLAG_MSG => P_ERR_MSG);
      IF P_RESULT > 0 THEN
        PKG_PMT_PUB.P_UNOCCUPY_INV_TRANSACTION_OLD(IN_ENTITYID     => R_PMT_COLLAR_SEND_HEAD.ENTITY_ID,
                                                   IN_SEND_HEAD_ID => R_PMT_COLLAR_SEND_HEAD.COLLAR_SEND_HEAD_ID,
                                                   FLAG            => P_RESULT,
                                                   FLAGMESSAGE     => P_ERR_MSG);
      END IF;
    
    END IF;
    P_SEND_HEAD_ID := R_PMT_COLLAR_SEND_HEAD.COLLAR_SEND_HEAD_ID;
  EXCEPTION
    WHEN PKG_PMT_PUB.PMT_EXCEPTION THEN
      P_ERR_MSG := '发货确认[发货信息ID：' || P_SHIP_INFO_ID || ']触发生成推广物料发放单据出错：' ||
                   P_ERR_MSG;
    WHEN OTHERS THEN
      P_RESULT  := -10000;
      P_ERR_MSG := '发货确认[发货信息ID：' || P_SHIP_INFO_ID || ']触发生成推广物料发放单据发生异常：' ||
                   SQLERRM;
  END P_PMT_ENTRY_SHIP;

  /**
     作者 吴林
     创建日期 2015-08-06
     功能描述 推广物料信用控制
  */
  PROCEDURE P_PMT_CREDIT_CONTROL(P_SEND_HEADER_ID IN NUMBER, --销售单据头ID
                                 P_RESULT         OUT NUMBER, --返回错误ID
                                 P_ERR_MSG        OUT VARCHAR2 --返回错误信息
                                 ) IS
    P_CREATED_MODE VARCHAR2(10) := '10'; --开单方式 自动开单
    --发放单据头游标
    CURSOR C_PMT_HEAD_INFO IS
      SELECT *
        FROM T_PMT_COLLAR_SEND_HEAD T
       WHERE T.COLLAR_SEND_HEAD_ID = P_SEND_HEADER_ID;
  
    --发放单头信息记录
    R_PMT_HEAD_INFO C_PMT_HEAD_INFO%ROWTYPE;
  
    P_SETTLE_AMOUNT_DIFF NUMBER := 0; --结算金额
  
    P_DISCOUNT_AMOUNT_DIFF NUMBER := 0; --折扣金额
  
    V_ACTION_TYPE NUMBER := 0;
  
    AMOUNT NUMBER := 0;
  
  BEGIN
  
    P_RESULT  := PKG_PMT_PUB.V_RESULT;
    P_ERR_MSG := PKG_PMT_PUB.V_RESULT_MSG;
  
    OPEN C_PMT_HEAD_INFO;
    FETCH C_PMT_HEAD_INFO
      INTO R_PMT_HEAD_INFO;
    CLOSE C_PMT_HEAD_INFO;
  
    --校验头表信息是否存在
    IF R_PMT_HEAD_INFO.COLLAR_SEND_HEAD_ID = NULL THEN
      P_RESULT  := -1;
      P_ERR_MSG := '未找到单据';
      RAISE PKG_PMT_PUB.PMT_EXCEPTION;
    END IF;
    --统计发放金额
    BEGIN
    
      SELECT ROUND(SUM(ROUND(T.RCV_QTY * T.PRICE, 2)), 2)
        INTO P_SETTLE_AMOUNT_DIFF
        FROM T_PMT_COLLAR_SEND_LINE T
       WHERE T.COLLAR_SEND_HEAD_ID = P_SEND_HEADER_ID;
    
    EXCEPTION
      WHEN OTHERS THEN
        P_RESULT  := -1;
        P_ERR_MSG := '统计结算金额出错';
        RAISE PKG_PMT_PUB.PMT_EXCEPTION;
    END;
  
    --判断单据类型  01为 领用单 02为政策资源单
    IF R_PMT_HEAD_INFO.ORDER_TYPE = '02' THEN
      V_ACTION_TYPE := 40;
    ELSIF R_PMT_HEAD_INFO.ORDER_TYPE = '03' THEN
      V_ACTION_TYPE := 34;
    ELSE
      P_RESULT  := -1;
      P_ERR_MSG := '单据类型不正确';
      RAISE PKG_PMT_PUB.PMT_EXCEPTION;
    END IF;
  
    --调用政策模块的信用控制存储过程
    PKG_CREDIT_CONTROL_PMT.PRC_CREDIT_CONTROL_PMT(R_PMT_HEAD_INFO.ENTITY_ID,
                                                  V_ACTION_TYPE,
                                                  P_SETTLE_AMOUNT_DIFF,
                                                  P_DISCOUNT_AMOUNT_DIFF,
                                                  R_PMT_HEAD_INFO.SALES_MAIN_TYPE,
                                                  R_PMT_HEAD_INFO.COLLAR_SEND_HEAD_ID,
                                                  R_PMT_HEAD_INFO.ACCOUNT_ID,
                                                  R_PMT_HEAD_INFO.CUSTOMER_ID,
                                                  NULL,
                                                  P_CREATED_MODE, --R_SO_HEADER.CREATED_MODE,
                                                  R_PMT_HEAD_INFO.DOC_TYPE,
                                                  R_PMT_HEAD_INFO.CREATED_BY,
                                                  P_RESULT,
                                                  P_ERR_MSG);
  
    IF P_RESULT < 0 THEN
      P_ERR_MSG := '调用信用控制处理出错：' || P_ERR_MSG;
      RAISE PKG_PMT_PUB.PMT_EXCEPTION;
    END IF;
  
  EXCEPTION
    WHEN PKG_PMT_PUB.PMT_EXCEPTION THEN
      RETURN;
    WHEN OTHERS THEN
      P_RESULT  := -1;
      P_ERR_MSG := '处理信用控制失败' || SQLERRM;
  END P_PMT_CREDIT_CONTROL;
  /**
     作者 吴林
     创建日期 2015-12-09
     功能描述 推广物料回写单号到物流运输合同
  */
  PROCEDURE P_PMT_RETURN_WRIT_NUM(P_SEND_HEADER_ID IN NUMBER, --销售单据头ID
                                  P_RESULT         OUT NUMBER, --返回错误ID
                                  P_ERR_MSG        OUT VARCHAR2 --返回错误信息
                                  ) AS
    V_SO_ORDER_NUM T_LG_CONTRACT_LINE.SO_DOC_NUM%TYPE;
  BEGIN
    --遍历发放单以及行信息
    FOR R_PMT_INFO IN (SELECT TPH.COLLAR_SEND_HEAD_ID,
                              TPH.PMT_SEND_NUM,
                              T.SHIP_DOC_LINE_ID,
                              T.ORIGIN_ORDER_ID,
                              T.ORIGIN_LINE_ID,
                              T.PMT_CODE
                         FROM CIMS.T_PMT_COLLAR_SEND_LINE T,
                              CIMS.T_PMT_COLLAR_SEND_HEAD TPH
                        WHERE T.COLLAR_SEND_HEAD_ID =
                              TPH.COLLAR_SEND_HEAD_ID
                          AND TPH.COLLAR_SEND_HEAD_ID = P_SEND_HEADER_ID
                          AND EXISTS
                        (SELECT 1
                                 FROM CIMS.T_LG_SHIP_DOC      T1,
                                      CIMS.T_LG_SHIP_DOC_LINE T2
                                WHERE T2.SHIP_DOC_ID = T1.SHIP_DOC_ID
                                  AND T1.SHIP_DOC_CODE = TPH.SHIP_DOC_CODE
                                  AND T2.ITEM_CODE = T.PMT_CODE
                                  AND T2.ORIGIN_ORDER_ID = T.ORIGIN_ORDER_ID
                                  AND T2.ORIGIN_LINE_ID = T.ORIGIN_LINE_ID
                                  AND T2.SHIP_DOC_LINE_ID =
                                      T.SHIP_DOC_LINE_ID)) LOOP
      IF R_PMT_INFO.PMT_SEND_NUM IS NULL THEN
        P_RESULT  := -1;
        P_ERR_MSG := '获取不到发放单';
        RAISE PKG_PMT_PUB.PMT_EXCEPTION;
      END IF;
      --获取运输合同行上的财务单号
      SELECT SO_DOC_NUM
        INTO V_SO_ORDER_NUM
        FROM T_LG_CONTRACT_LINE T
       WHERE T.SHIP_DOC_LINE_ID = R_PMT_INFO.SHIP_DOC_LINE_ID
         AND T.ORIGIN_ORDER_ID = R_PMT_INFO.ORIGIN_ORDER_ID
         AND T.ORIGIN_LINE_ID = R_PMT_INFO.ORIGIN_LINE_ID
         AND T.ITEM_CODE = R_PMT_INFO.PMT_CODE;
      --判断运输合同是否已经回写过财务单号
      IF V_SO_ORDER_NUM IS NULL THEN
        UPDATE T_LG_CONTRACT_LINE T
           SET T.SO_DOC_NUM = R_PMT_INFO.PMT_SEND_NUM,
               T.SO_DOC_ID  = R_PMT_INFO.COLLAR_SEND_HEAD_ID
         WHERE T.SHIP_DOC_LINE_ID = R_PMT_INFO.SHIP_DOC_LINE_ID
           AND T.ORIGIN_ORDER_ID = R_PMT_INFO.ORIGIN_ORDER_ID
           AND T.ORIGIN_LINE_ID = R_PMT_INFO.ORIGIN_LINE_ID
           AND T.ITEM_CODE = R_PMT_INFO.PMT_CODE;
      END IF;
    END LOOP;
  
    P_RESULT  := PKG_PMT_PUB.V_RESULT;
    P_ERR_MSG := PKG_PMT_PUB.V_RESULT_MSG;
  EXCEPTION
    WHEN PKG_PMT_PUB.PMT_EXCEPTION THEN
      RETURN;
    WHEN OTHERS THEN
      P_RESULT  := -1;
      P_ERR_MSG := '调用P_PMT_RETURN_WRIT_NUM 回写物流运输合同发放单号时发生异常！' ||
                   SUBSTR(SQLERRM, 1, 200);
  END P_PMT_RETURN_WRIT_NUM;
  /**
   *  功能描述：释放库存释放，促发库存事务，信用控制 回写单号到物流运输合同行
  */
  PROCEDURE P_UNOCCUPY_INV_TRANSACTION_NEW(IN_ENTITYID     IN NUMBER,
                                           IN_SEND_HEAD_ID IN NUMBER,
                                           FLAG            OUT VARCHAR2,
                                           FLAGMESSAGE     OUT VARCHAR2) AS
    V_REC_QTY     NUMBER := 0;
    V_COUNT       NUMBER := 0;
    V_REC_QTY_ALL NUMBER := 0;
    V_IS_FREE     NUMBER := 0;
  BEGIN
    FLAG        := PKG_PMT_PUB.V_RESULT;
    FLAGMESSAGE := PKG_PMT_PUB.V_RESULT_MSG;
    IF IN_SEND_HEAD_ID IS NULL THEN
      FLAG        := -1;
      FLAGMESSAGE := '发放单头表为空';
      RAISE PKG_PMT_PUB.PMT_EXCEPTION;
    END IF;
  
    SELECT COUNT(*)
      INTO V_COUNT
      FROM T_PMT_COLLAR_SEND_HEAD T
     WHERE T.COLLAR_SEND_HEAD_ID = IN_SEND_HEAD_ID;
  
    IF V_COUNT = 0 THEN
      FLAG        := -1;
      FLAGMESSAGE := '找不到发放单头表信息';
      RAISE PKG_PMT_PUB.PMT_EXCEPTION;
    END IF;
    --释放库存占用
    P_PMT_UNOCCUPY_INV_NEW(IN_ENTITYID, IN_SEND_HEAD_ID, FLAG, FLAGMESSAGE);
    IF FLAG = 1 THEN
      --促发库存事务
      P_PMT_INV_TRANSACTION_NEW(IN_ENTITYID => IN_ENTITYID,
                                IN_HEADID   => IN_SEND_HEAD_ID,
                                FLAG        => FLAG,
                                FLAGMESSAGE => FLAGMESSAGE);
    END IF;
    IF FLAG = 1 THEN
      --信用控制
      P_PMT_CREDIT_CONTROL(P_SEND_HEADER_ID => IN_SEND_HEAD_ID,
                           P_RESULT         => FLAG,
                           P_ERR_MSG        => FLAGMESSAGE);
    END IF;
    /*-- 回写发放单号给物流运输合同
    IF FLAG >= 0 THEN
      P_PMT_RETURN_WRIT_NUM(P_SEND_HEADER_ID =>IN_SEND_HEAD_ID,
                            P_RESULT => FLAG,
                            P_ERR_MSG => FLAGMESSAGE);
    END IF;*/
  
    IF FLAG >= 0 THEN
      FLAG        := PKG_PMT_PUB.V_RESULT;
      FLAGMESSAGE := PKG_PMT_PUB.V_RESULT_MSG;
    END IF;
  
  EXCEPTION
    WHEN PKG_PMT_PUB.PMT_EXCEPTION THEN
      RETURN;
    WHEN OTHERS THEN
      FLAG        := -1;
      FLAGMESSAGE := '调用pmt_collar_send_setRecQty时发生异常！' ||
                     SUBSTR(SQLERRM, 1, 200);
  END P_UNOCCUPY_INV_TRANSACTION_NEW;
  /**
  * 领用申请审批通过后占用库存
  */
  PROCEDURE P_PMT_COLLAR_SEND_OCCUPY_INV(IN_ENTITYID IN NUMBER,
                                         IN_HEADID   IN NUMBER,
                                         FLAG        OUT VARCHAR2,
                                         FLAGMESSAGE OUT VARCHAR2) AS
    CURSOR HEAD_INFO IS
      SELECT *
        FROM T_PMT_COLLAR_REQUIS_HEAD T
       WHERE T.COLLAR_REQUIS_HEAD_ID = IN_HEADID
         AND T.ENTITY_ID = IN_ENTITYID;
    CURSOR LINE_INFO IS
      SELECT *
        FROM T_PMT_COLLAR_REQUIS_LINE T
       WHERE T.COLLAR_REQUIS_HEAD_ID = IN_HEADID
         AND T.ENTITY_ID = IN_ENTITYID;
    R_HEAD_INFO      HEAD_INFO%ROWTYPE;
    R_LINE_INFO      LINE_INFO%ROWTYPE;
    V_BILL_TYPE_NAME VARCHAR2(32);
  
  BEGIN
    OPEN HEAD_INFO;
    LOOP
      FETCH HEAD_INFO
        INTO R_HEAD_INFO;
      EXIT WHEN HEAD_INFO%NOTFOUND;
    END LOOP;
    CLOSE HEAD_INFO;
    BEGIN
      SELECT BILL_TYPE_NAME
        INTO V_BILL_TYPE_NAME
        FROM T_INV_BILL_TYPES
       WHERE SOURCE_TYPE_ID =
             (SELECT SOURCE_TYPE_ID
                FROM T_INV_SOURCE_TYPES
               WHERE SOURCE_TYPE_CODE = '1009'
                 AND ENTITY_ID = IN_ENTITYID
                 AND SYSDATE >= BEGIN_DATE
                 AND (END_DATE IS NULL OR SYSDATE <= END_DATE))
         AND SYSDATE >= BEGIN_DATE
         AND (END_DATE IS NULL OR SYSDATE <= END_DATE)
         AND ERP_TRANCATION = '10'
         AND ENTITY_ID = IN_ENTITYID;
    EXCEPTION
      WHEN OTHERS THEN
        FLAG        := '-1';
        FLAGMESSAGE := '单据不存在';
    END;
    OPEN LINE_INFO;
    LOOP
      FETCH LINE_INFO
        INTO R_LINE_INFO;
      EXIT WHEN LINE_INFO%NOTFOUND;
      PKG_PLN_INV_OCCUPY.P_AFFIRM_OCCUPY_STOCKS(R_HEAD_INFO.SHIP_INVENTORY_ID,
                                                R_LINE_INFO.PMT_ID,
                                                R_LINE_INFO.AUDIT_QTY,
                                                'A',
                                                '推广物料占用',
                                                R_HEAD_INFO.ENTITY_ID,
                                                V_BILL_TYPE_NAME,
                                                R_HEAD_INFO.COLLAR_REQUIS_HEAD_ID,
                                                R_HEAD_INFO.PMT_ORDER_NUM,
                                                R_LINE_INFO.COLLAR_REQUIS_LINE_ID,
                                                V_BILL_TYPE_NAME,
                                                R_HEAD_INFO.COLLAR_REQUIS_HEAD_ID,
                                                R_HEAD_INFO.PMT_ORDER_NUM,
                                                R_LINE_INFO.COLLAR_REQUIS_LINE_ID,
                                                R_HEAD_INFO.CREATED_BY,
                                                FLAG,
                                                FLAGMESSAGE);
    
    END LOOP;
    CLOSE LINE_INFO;
    IF FLAG = 0 THEN
    
      FLAG        := '1';
      FLAGMESSAGE := 'ok';
    END IF;
  EXCEPTION
  
    WHEN OTHERS THEN
      FLAG        := '-1';
      FLAGMESSAGE := '调用p_pmt_collar_send_occupy_inv时发生异常！' ||
                     SUBSTR(SQLERRM, 1, 200);
  END P_PMT_COLLAR_SEND_OCCUPY_INV;
  /**
     减少库存占用
     吴林 2015-07-13 修改  原始单据从推广物料领用单修改到提货订单
  */
  PROCEDURE P_PMT_UNOCCUPY_INV_NEW(IN_ENTITYID IN NUMBER,
                                   IN_HEADID   IN NUMBER,
                                   FLAG        OUT VARCHAR2,
                                   FLAGMESSAGE OUT VARCHAR2) AS
    CURSOR SEND_HEAD_INFO IS
      SELECT *
        FROM T_PMT_COLLAR_SEND_HEAD T
       WHERE T.COLLAR_SEND_HEAD_ID = IN_HEADID
         AND T.ENTITY_ID = IN_ENTITYID;
    R_SEND_HEAD_INFO     SEND_HEAD_INFO%ROWTYPE;
    V_BILL_TYPE_NAME     VARCHAR2(32);
    V_PMT_ORDER_NUM      VARCHAR2(32);
    V_LG_ORDER_TYPE_NAME VARCHAR2(100);
  BEGIN
  
    OPEN SEND_HEAD_INFO;
    LOOP
      FETCH SEND_HEAD_INFO
        INTO R_SEND_HEAD_INFO;
      EXIT WHEN SEND_HEAD_INFO%NOTFOUND;
    END LOOP;
    CLOSE SEND_HEAD_INFO;
  
    BEGIN
      SELECT BILL_TYPE_NAME
        INTO V_BILL_TYPE_NAME
        FROM T_INV_BILL_TYPES
       WHERE SOURCE_TYPE_ID =
             (SELECT SOURCE_TYPE_ID
                FROM T_INV_SOURCE_TYPES
               WHERE SOURCE_TYPE_CODE = '1009'
                 AND ENTITY_ID = IN_ENTITYID
                 AND SYSDATE >= BEGIN_DATE
                 AND (END_DATE IS NULL OR SYSDATE <= END_DATE))
         AND SYSDATE >= BEGIN_DATE
         AND (END_DATE IS NULL OR SYSDATE <= END_DATE)
         AND ERP_TRANCATION = '10'
         AND ENTITY_ID = IN_ENTITYID
         AND BILL_TYPE_ID = R_SEND_HEAD_INFO.DOC_TYPE;
    
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        BEGIN
          SELECT BILL_TYPE_NAME
            INTO V_BILL_TYPE_NAME
            FROM T_INV_BILL_TYPES
           WHERE SOURCE_TYPE_ID =
                 (SELECT SOURCE_TYPE_ID
                    FROM T_INV_SOURCE_TYPES
                   WHERE SOURCE_TYPE_CODE = '1009'
                     AND ENTITY_ID = IN_ENTITYID
                     AND SYSDATE >= BEGIN_DATE
                     AND (END_DATE IS NULL OR SYSDATE <= END_DATE))
             AND SYSDATE >= BEGIN_DATE
             AND (END_DATE IS NULL OR SYSDATE <= END_DATE)
             AND ERP_TRANCATION = '10'
             AND ENTITY_ID = IN_ENTITYID;
        EXCEPTION
          WHEN OTHERS THEN
            FLAG        := '-10018';
            FLAGMESSAGE := '单据类型不存在';
            RAISE PKG_PMT_PUB.PMT_EXCEPTION;
        END;
      WHEN OTHERS THEN
        FLAG        := '-10018';
        FLAGMESSAGE := '单据类型不存在';
        RAISE PKG_PMT_PUB.PMT_EXCEPTION;
    END;
  
    FOR ORDER_LINE_ID IN (SELECT *
                            FROM T_PMT_COLLAR_SEND_LINE T
                           WHERE T.COLLAR_SEND_HEAD_ID = IN_HEADID) LOOP
      BEGIN
        --获取提货订单 单据类型名称
        BEGIN
        
          SELECT ORDER_TYPE_NAME
            INTO V_LG_ORDER_TYPE_NAME
            FROM T_PLN_LG_ORDER_HEAD
           WHERE ORDER_HEAD_ID = ORDER_LINE_ID.ORIGIN_ORDER_ID
             AND ENTITY_ID = ORDER_LINE_ID.ENTITY_ID;
        
        EXCEPTION
          WHEN OTHERS THEN
            FLAG        := '-10018';
            FLAGMESSAGE := '获取提货订单单据类型失败！';
            RAISE PKG_PMT_PUB.PMT_EXCEPTION;
        END;
      
        PKG_PLN_INV_OCCUPY.P_SOORDER_UNOCCUPY_STOCKS(R_SEND_HEAD_INFO.SHIP_INVENTORY_ID,
                                                     ORDER_LINE_ID.PMT_ID,
                                                     ORDER_LINE_ID.RCV_QTY,
                                                     'A',
                                                     V_LG_ORDER_TYPE_NAME ||
                                                     '生成推广物料发放单',
                                                     R_SEND_HEAD_INFO.ENTITY_ID,
                                                     V_LG_ORDER_TYPE_NAME,
                                                     ORDER_LINE_ID.ORIGIN_ORDER_ID,
                                                     R_SEND_HEAD_INFO.PMT_ORDER_NUM,
                                                     ORDER_LINE_ID.ORIGIN_LINE_ID,
                                                     V_BILL_TYPE_NAME,
                                                     ORDER_LINE_ID.COLLAR_SEND_HEAD_ID,
                                                     R_SEND_HEAD_INFO.PMT_SEND_NUM,
                                                     ORDER_LINE_ID.COLLAR_SEND_LINE_ID,
                                                     ORDER_LINE_ID.CREATED_BY,
                                                     'N',
                                                     FLAG,
                                                     FLAGMESSAGE);
      
      END;
    END LOOP;
    IF FLAG = 0 THEN
    
      FLAG        := PKG_PMT_PUB.V_RESULT;
      FLAGMESSAGE := PKG_PMT_PUB.V_RESULT_MSG;
    ELSE
      FLAG := -1;
    END IF;
  EXCEPTION
    WHEN PKG_PMT_PUB.PMT_EXCEPTION THEN
      RETURN;
    WHEN OTHERS THEN
      FLAG        := -1;
      FLAGMESSAGE := '释放库存占用失败' || SQLERRM;
    
  END P_PMT_UNOCCUPY_INV_NEW;
  /**
    触发库存事务
  */
  PROCEDURE P_PMT_INV_TRANSACTION_NEW(IN_ENTITYID IN NUMBER,
                                      IN_HEADID   IN NUMBER,
                                      FLAG        OUT VARCHAR2,
                                      FLAGMESSAGE OUT VARCHAR2) AS
    CURSOR HEAD_INFO IS
      SELECT *
        FROM T_PMT_COLLAR_SEND_HEAD T
       WHERE T.COLLAR_SEND_HEAD_ID = IN_HEADID
         AND T.ENTITY_ID = IN_ENTITYID;
    R_HEAD_INFO    HEAD_INFO%ROWTYPE;
    V_BILL_TYPE_ID T_INV_BILL_TYPES.BILL_TYPE_ID%TYPE;
    V_STATUS       T_PMT_COLLAR_REQUIS_HEAD.STATUS%TYPE;
    VN_FLAG        NUMBER;
  BEGIN
    OPEN HEAD_INFO;
    LOOP
      FETCH HEAD_INFO
        INTO R_HEAD_INFO;
      EXIT WHEN HEAD_INFO%NOTFOUND;
    END LOOP;
    CLOSE HEAD_INFO;
    V_STATUS := R_HEAD_INFO.STATUS;
    IF V_STATUS = '23' THEN
      BEGIN
        SELECT BT.BILL_TYPE_ID INTO V_BILL_TYPE_ID FROM T_INV_BILL_TYPES BT
        /*INNER JOIN T_INV_TRANSACTION_TYPES TT
        ON (BT.TRANSACTION_TYPE_ID = TT.TRANSACTION_TYPE_ID)*/
        WHERE BT.BILL_TYPE_ID = R_HEAD_INFO.BILL_TYPE_ID
        AND BT.ENTITY_ID = IN_ENTITYID
        AND SYSDATE >= BT.BEGIN_DATE
        AND (BT.END_DATE IS NULL OR SYSDATE <= BT.END_DATE)
        ;
        /*SELECT BILL_TYPE_ID
          INTO V_BILL_TYPE_ID
          FROM T_INV_BILL_TYPES
         WHERE SOURCE_TYPE_ID =
               (SELECT SOURCE_TYPE_ID
                  FROM T_INV_SOURCE_TYPES
                 WHERE SOURCE_TYPE_CODE = '1009'
                   AND ENTITY_ID = IN_ENTITYID
                   AND SYSDATE >= BEGIN_DATE
                   AND (END_DATE IS NULL OR SYSDATE <= END_DATE))
           AND SYSDATE >= BEGIN_DATE
           AND (END_DATE IS NULL OR SYSDATE <= END_DATE)
           --AND ERP_TRANCATION = '10'
           AND ENTITY_ID = IN_ENTITYID;*/
      EXCEPTION
        WHEN OTHERS THEN
          FLAG        := '-10018';
          FLAGMESSAGE := '单据类型不存在或已失效';
          RAISE PKG_PMT_PUB.PMT_EXCEPTION;
      END;
      PKG_INV_TRANSACTION.INV_TRANSACTION_TOTAL_DEAL(IN_ENTITY_ID          => IN_ENTITYID,
                                                     IN_BILL_TYPE_ID       => V_BILL_TYPE_ID,
                                                     IS_BUSINESS_STATE     => V_STATUS,
                                                     ID_TRANSACTION_DATE   => R_HEAD_INFO.SEND_DATE,
                                                     IN_BUSINESS_HEADER_ID => IN_HEADID,
                                                     IN_IF_NULL            => 0,
                                                     IS_BILL_KIND          => 'B5',
                                                     ON_FLAG               => VN_FLAG,
                                                     OS_PROMPT             => FLAGMESSAGE);
      IF VN_FLAG = 0 THEN
        FLAG        := PKG_PMT_PUB.V_RESULT;
        FLAGMESSAGE := PKG_PMT_PUB.V_RESULT_MSG;
      ELSIF VN_FLAG = 1 THEN
        FLAG        := '-10018';
      ELSE
        FLAG        := TO_CHAR(VN_FLAG);
      END IF;
    
    ELSE
      FLAG        := '-10019';
      FLAGMESSAGE := '单据状态不为已发放状态';
      RETURN;
    END IF;
  END P_PMT_INV_TRANSACTION_NEW;
  /**
     释放发放单剩余库存
  */
  PROCEDURE P_PMT_UNOCCUPY_REMAIN_INV(IN_ENTITYID IN NUMBER,
                                      IN_HEADID   IN NUMBER,
                                      IN_LINEI    IN NUMBER,
                                      FLAG        OUT VARCHAR2,
                                      FLAGMESSAGE OUT VARCHAR2) AS
    CURSOR REQUIS_HEAD_INFO IS
      SELECT *
        FROM T_PMT_COLLAR_REQUIS_HEAD T
       WHERE T.COLLAR_REQUIS_HEAD_ID = IN_HEADID
         AND T.ENTITY_ID = IN_ENTITYID;
  
    CURSOR REQUIS_LINE_INFO IS
      SELECT *
        FROM T_PMT_COLLAR_REQUIS_LINE T
       WHERE T.COLLAR_REQUIS_LINE_ID = IN_LINEI
         AND T.ENTITY_ID = IN_ENTITYID;
  
    R_REQUIS_HEAD_INFO REQUIS_HEAD_INFO%ROWTYPE;
    R_REQUIS_LINE_INFO REQUIS_LINE_INFO%ROWTYPE;
    V_BILL_TYPE_NAME   VARCHAR2(32);
    V_PMT_ORDER_NUM    VARCHAR2(32);
    V_HAS_SEND_QTY     NUMBER;
    V_FEE_QTY          NUMBER;
  
  BEGIN
    --获取领用单头表信息
    OPEN REQUIS_HEAD_INFO;
    LOOP
      FETCH REQUIS_HEAD_INFO
        INTO R_REQUIS_HEAD_INFO;
      EXIT WHEN REQUIS_HEAD_INFO%NOTFOUND;
    END LOOP;
    CLOSE REQUIS_HEAD_INFO;
    --获取领用单行表信息
    OPEN REQUIS_LINE_INFO;
    LOOP
      FETCH REQUIS_LINE_INFO
        INTO R_REQUIS_LINE_INFO;
      EXIT WHEN REQUIS_LINE_INFO%NOTFOUND;
    END LOOP;
    CLOSE REQUIS_LINE_INFO;
    --获取单据下实际发货数量
    BEGIN
      SELECT SUM(T.RCV_QTY)
        INTO V_HAS_SEND_QTY
        FROM T_PMT_COLLAR_SEND_LINE T
       WHERE T.COLLAR_SEND_HEAD_ID IN
             (SELECT T1.COLLAR_SEND_HEAD_ID
                FROM T_PMT_COLLAR_SEND_HEAD T1
               WHERE T1.PMT_ORDER_NUM = R_REQUIS_HEAD_INFO.PMT_ORDER_NUM)
         AND T.PMT_ID = R_REQUIS_LINE_INFO.PMT_ID;
    EXCEPTION
      WHEN OTHERS THEN
        V_HAS_SEND_QTY := 0;
    END;
  
    IF V_HAS_SEND_QTY IS NULL THEN
      V_HAS_SEND_QTY := 0;
    END IF;
  
    V_FEE_QTY := R_REQUIS_LINE_INFO.AUDIT_QTY - V_HAS_SEND_QTY;
    BEGIN
      SELECT BILL_TYPE_NAME
        INTO V_BILL_TYPE_NAME
        FROM T_INV_BILL_TYPES
       WHERE SOURCE_TYPE_ID =
             (SELECT SOURCE_TYPE_ID
                FROM T_INV_SOURCE_TYPES
               WHERE SOURCE_TYPE_CODE = '1009'
                 AND ENTITY_ID = IN_ENTITYID
                 AND SYSDATE >= BEGIN_DATE
                 AND (END_DATE IS NULL OR SYSDATE <= END_DATE))
         AND SYSDATE >= BEGIN_DATE
         AND (END_DATE IS NULL OR SYSDATE <= END_DATE)
         AND ERP_TRANCATION = '10'
         AND ENTITY_ID = IN_ENTITYID;
    EXCEPTION
      WHEN OTHERS THEN
        FLAG := '-1';
        FLAG := '单据不存在';
    END;
  
    PKG_PLN_INV_OCCUPY.P_SOORDER_UNOCCUPY_STOCKS(R_REQUIS_HEAD_INFO.SHIP_INVENTORY_ID,
                                                 R_REQUIS_LINE_INFO.PMT_ID,
                                                 V_FEE_QTY,
                                                 'A',
                                                 '推广物料占用',
                                                 R_REQUIS_HEAD_INFO.ENTITY_ID,
                                                 V_BILL_TYPE_NAME,
                                                 R_REQUIS_HEAD_INFO.COLLAR_REQUIS_HEAD_ID,
                                                 R_REQUIS_HEAD_INFO.PMT_ORDER_NUM,
                                                 R_REQUIS_LINE_INFO.COLLAR_REQUIS_LINE_ID,
                                                 V_BILL_TYPE_NAME,
                                                 R_REQUIS_HEAD_INFO.COLLAR_REQUIS_HEAD_ID,
                                                 R_REQUIS_HEAD_INFO.PMT_ORDER_NUM,
                                                 R_REQUIS_LINE_INFO.COLLAR_REQUIS_LINE_ID,
                                                 R_REQUIS_LINE_INFO.CREATED_BY,
                                                 'Y',
                                                 FLAG,
                                                 FLAGMESSAGE);
    IF FLAG = 0 THEN
    
      FLAG        := '1';
      FLAGMESSAGE := 'ok';
    
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      FLAG        := '-1';
      FLAGMESSAGE := '调用p_pmt_unoccupy_remain_inv时发生异常！' ||
                     SUBSTR(SQLERRM, 1, 200);
    
  END P_PMT_UNOCCUPY_REMAIN_INV;

  /**
  *检查推广物料采购单预算
  */
  PROCEDURE P_PMT_CHECK_BUDGET(P_ORDER_HEAD_ID         IN NUMBER,
                               P_BUDGET_AMOUNT         OUT NUMBER, --占用预算
                               P_BUDGET_AMOUNT_CAN_USE OUT NUMBER, --可用预算
                               P_BUDGET_AMOUNT_USING1  OUT NUMBER, --同节点制单占用预算
                               P_BUDGET_AMOUNT_USING2  OUT NUMBER, --同节点送审占用预算
                               P_MESSAGE               OUT VARCHAR2) AS
    V_CNT NUMBER;
    CURSOR C_PMT_ORDER_BUDGET_LINE IS
      SELECT H.ORDER_NUM     AS POLICY_NUMBER,
             BT.Data_Flow_Id AS DATA_FLOW_ID,
             --H.DATE_FLOW_ID         AS H_DATA_FLOW_ID,
             BT.BUDGET_TREE_ID      AS BUDGET_TREE_ID,
             H.BUDGET_TREE_ID       AS H_BUDGET_TREE_ID,
             H.BUDGET_SEGMENT_01_ID,
             H.BUDGET_SEGMENT_02_ID,
             H.BUDGET_SEGMENT_03_ID,
             H.BUDGET_SEGMENT_04_ID,
             H.BUDGET_SEGMENT_05_ID,
             H.BUDGET_SEGMENT_06_ID,
             H.BUDGET_AMOUNT,
             H.ORDER_HEAD_ID        AS DETAIL_ID,
             H.ENTITY_ID,
             --H.CREATED_BY,
             NVL((SELECT T.USER_ID
                   FROM UP_ORG_USER T
                  WHERE T.ACCOUNT = H.CREATED_BY
                    AND 'T' = T.ACCOUNT_ENABLED
                    AND 'T' = T.ACTIVE_FLAG
                    AND 1 = ROWNUM),
                 0) AS CREATED_BY
        FROM T_PMT_ORDER_HEADER H, T_POL_BUDGET_TREE BT
       WHERE H.DATE_FLOW_ID = BT.DATA_FLOW_ID
         AND NVL(H.BUDGET_SEGMENT_01_ID, -1) =
             NVL(BT.BUDGET_SEGMENT_01_ID, -1)
         AND NVL(H.BUDGET_SEGMENT_02_ID, -1) =
             NVL(BT.BUDGET_SEGMENT_02_ID, -1)
         AND NVL(H.BUDGET_SEGMENT_03_ID, -1) =
             NVL(BT.BUDGET_SEGMENT_03_ID, -1)
         AND NVL(H.BUDGET_SEGMENT_04_ID, -1) =
             NVL(BT.BUDGET_SEGMENT_04_ID, -1)
         AND NVL(H.BUDGET_SEGMENT_05_ID, -1) =
             NVL(BT.BUDGET_SEGMENT_05_ID, -1)
         AND NVL(H.BUDGET_SEGMENT_06_ID, -1) =
             NVL(BT.BUDGET_SEGMENT_06_ID, -1)
         AND H.ORDER_HEAD_ID = P_ORDER_HEAD_ID;
  
    R_PMT_ORDER_BUDGET_LINE C_PMT_ORDER_BUDGET_LINE%ROWTYPE;
  BEGIN
    V_CNT     := 0;
    P_MESSAGE := 'SUCCESS';
    OPEN C_PMT_ORDER_BUDGET_LINE;
    LOOP
      BEGIN
        FETCH C_PMT_ORDER_BUDGET_LINE
          INTO R_PMT_ORDER_BUDGET_LINE;
      
        EXIT WHEN C_PMT_ORDER_BUDGET_LINE%NOTFOUND;
        IF 0 <> V_CNT THEN
          P_MESSAGE := '该推广物料采购单的预算节点存在重复数据';
          EXIT;
        END IF;
        V_CNT := (1 + V_CNT);
        /*IF R_PMT_ORDER_BUDGET_LINE.BUDGET_TREE_ID <>
           NVL(R_PMT_ORDER_BUDGET_LINE.H_BUDGET_TREE_ID, 0) THEN
          --SAVEPOINT SP1;
          UPDATE T_PMT_ORDER_HEADER H
             SET H.BUDGET_TREE_ID = R_PMT_ORDER_BUDGET_LINE.BUDGET_TREE_ID
           WHERE H.ORDER_HEAD_ID = P_ORDER_HEAD_ID;
          --COMMIT;
        END IF;*/
        PKG_BUDGET.p_Check_Fee(R_PMT_ORDER_BUDGET_LINE.DATA_FLOW_ID,
                               R_PMT_ORDER_BUDGET_LINE.ENTITY_ID,
                               R_PMT_ORDER_BUDGET_LINE.BUDGET_TREE_ID,
                               '推广物料',
                               R_PMT_ORDER_BUDGET_LINE.DETAIL_ID,
                               R_PMT_ORDER_BUDGET_LINE.POLICY_NUMBER,
                               NULL,
                               NULL,
                               NULL,
                               NULL,
                               NULL,
                               NULL,
                               NULL,
                               NULL,
                               NULL,
                               NULL,
                               R_PMT_ORDER_BUDGET_LINE.BUDGET_AMOUNT,
                               R_PMT_ORDER_BUDGET_LINE.CREATED_BY,
                               P_MESSAGE);
        /*PKG_BUDGET.p_Check_Fee(R_PMT_ORDER_BUDGET_LINE.DATA_FLOW_ID,
        R_PMT_ORDER_BUDGET_LINE.ENTITY_ID,
        NVL(R_PMT_ORDER_BUDGET_LINE.BUDGET_SEGMENT_01_ID,
            -1),
        NVL(R_PMT_ORDER_BUDGET_LINE.BUDGET_SEGMENT_02_ID,
            -1),
        NVL(R_PMT_ORDER_BUDGET_LINE.BUDGET_SEGMENT_03_ID,
            -1),
        NVL(R_PMT_ORDER_BUDGET_LINE.BUDGET_SEGMENT_04_ID,
            -1),
        NVL(R_PMT_ORDER_BUDGET_LINE.BUDGET_SEGMENT_05_ID,
            -1),
        NVL(R_PMT_ORDER_BUDGET_LINE.BUDGET_SEGMENT_06_ID,
            -1),
        '推广物料', --费用类型
        R_PMT_ORDER_BUDGET_LINE.DETAIL_ID,
        R_PMT_ORDER_BUDGET_LINE.POLICY_NUMBER,
        NULL,
        NULL,
        R_PMT_ORDER_BUDGET_LINE.BUDGET_AMOUNT,
        --P_USER_ID,
        R_PMT_ORDER_BUDGET_LINE.CREATED_BY, -- 1 admin
        P_MESSAGE);*/
      EXCEPTION
        WHEN OTHERS THEN
          P_MESSAGE := '检查推广物料预算发生异常：' || SQLCODE || SQLERRM;
      END;
    END LOOP;
    CLOSE C_PMT_ORDER_BUDGET_LINE;
    IF 0 = V_CNT THEN
      P_MESSAGE := '该推广物料采购单或者采购单的预算节点不存在，请检查';
    END IF;
  END P_PMT_CHECK_BUDGET;

  /**
     占用政策预算
  */
  PROCEDURE P_PMT_OCCUPY_BUDGET(IN_ENTITYID IN NUMBER,
                                IN_HEADID   IN NUMBER,
                                FLAG        OUT VARCHAR2,
                                FLAGMESSAGE OUT VARCHAR2) AS
    V_USER_ID NUMBER;
    CURSOR REQUIS_HEAD_INFO IS
      SELECT *
        FROM T_PMT_COLLAR_REQUIS_HEAD T
       WHERE T.COLLAR_REQUIS_HEAD_ID = IN_HEADID
         AND T.ENTITY_ID = IN_ENTITYID;
    R_REQUIS_HEAD_INFO REQUIS_HEAD_INFO%ROWTYPE;
  BEGIN
  
    OPEN REQUIS_HEAD_INFO;
    LOOP
      FETCH REQUIS_HEAD_INFO
        INTO R_REQUIS_HEAD_INFO;
      EXIT WHEN REQUIS_HEAD_INFO%NOTFOUND;
    END LOOP;
    CLOSE REQUIS_HEAD_INFO;
  
    SELECT T.USER_ID
      INTO V_USER_ID
      FROM UP_ORG_USER T
     WHERE T.ACCOUNT = R_REQUIS_HEAD_INFO.LAST_UPDATED_BY;
  
    FOR REQUIS_LINE_INFO IN (SELECT *
                               FROM T_PMT_COLLAR_REQUIS_LINE T
                              WHERE T.COLLAR_REQUIS_HEAD_ID = IN_HEADID
                                AND T.ENTITY_ID = IN_ENTITYID) LOOP
      BEGIN
        PKG_BUDGET.P_WRITE_FEE(R_REQUIS_HEAD_INFO.BUDGET_TREE_ID,
                               IN_ENTITYID,
                               R_REQUIS_HEAD_INFO.BUDGET_YEAR,
                               R_REQUIS_HEAD_INFO.ORGANIZATION_CODE,
                               R_REQUIS_HEAD_INFO.CHARGES_MAIN_TYPE_NAME,
                               R_REQUIS_HEAD_INFO.CHARGES_SUB_TYPE_NAME,
                               '-1',
                               '-1',
                               '推广物料',
                               REQUIS_LINE_INFO.COLLAR_REQUIS_LINE_ID,
                               R_REQUIS_HEAD_INFO.PMT_ORDER_NUM,
                               NULL,
                               NULL,
                               REQUIS_LINE_INFO.AMOUNT,
                               V_USER_ID,
                               FLAGMESSAGE);
      END;
    END LOOP;
    FLAG        := '1';
    FLAGMESSAGE := 'ok';
  EXCEPTION
    WHEN OTHERS THEN
      FLAG        := '-1';
      FLAGMESSAGE := '调用p_pmt_occupy_budget时发生异常！' ||
                     SUBSTR(SQLERRM, 1, 200);
  END P_PMT_OCCUPY_BUDGET;
  /**
     占用库存以及政策预算
  */
  PROCEDURE P_PMT_OCCUPY_BUDGET_INV(IN_ENTITYID IN NUMBER,
                                    IN_HEADID   IN NUMBER,
                                    FLAG        OUT VARCHAR2,
                                    FLAGMESSAGE OUT VARCHAR2) AS
  BEGIN
    P_PMT_COLLAR_SEND_OCCUPY_INV(IN_ENTITYID, IN_HEADID, FLAG, FLAGMESSAGE);
    -- p_pmt_occupy_budget(in_entityId, in_headId, flag, flagMessage);
    FLAG        := '1';
    FLAGMESSAGE := '掉用成功';
  EXCEPTION
    WHEN OTHERS THEN
      FLAG        := '-1';
      FLAGMESSAGE := '掉用失败';
  END P_PMT_OCCUPY_BUDGET_INV;
  /**
    释放政策预算  2015/2/3 wulin
  */
  PROCEDURE P_PMT_UNOCCUPY_BUDGET(IN_ENTITYID IN NUMBER,
                                  IN_HEADID   IN NUMBER,
                                  IN_LINEID   IN NUMBER,
                                  FEE_NUM     IN NUMBER,
                                  FLAG        OUT VARCHAR2,
                                  FLAGMESSAGE OUT VARCHAR2) AS
    /* v_user_id number;
      CURSOR REQUIS_HEAD_INFO IS
        SELECT *
          FROM T_PMT_COLLAR_REQUIS_HEAD T
         WHERE T.COLLAR_REQUIS_HEAD_ID = in_headId
           AND T.ENTITY_ID = in_entityId;
      R_REQUIS_HEAD_INFO REQUIS_HEAD_INFO%Rowtype;
    begin
      OPEN REQUIS_HEAD_INFO;
      LOOP
        FETCH REQUIS_HEAD_INFO
          INTO R_REQUIS_HEAD_INFO;
        EXIT WHEN REQUIS_HEAD_INFO%NOTFOUND;
      END LOOP;
      CLOSE REQUIS_HEAD_INFO;
    
      select t.user_id
        into v_user_id
        from up_org_user t
       where t.account = R_REQUIS_HEAD_INFO.Last_Updated_By;
    
      Pkg_Budget.p_Write_Fee(R_REQUIS_HEAD_INFO.BUDGET_TREE_ID,
                             in_entityId,
                             R_REQUIS_HEAD_INFO.BUDGET_YEAR,
                             R_REQUIS_HEAD_INFO.ORGANIZATION_CODE,
                             R_REQUIS_HEAD_INFO.CHARGES_MAIN_TYPE_NAME,
                             R_REQUIS_HEAD_INFO.CHARGES_SUB_TYPE_NAME,
                             '-1',
                             '-1',
                             '推广物料',
                             in_lineId,
                             R_REQUIS_HEAD_INFO.PMT_ORDER_NUM,
                             null,
                             null,
                             '-' || fee_num,
                             v_user_id,
                             flagMessage);*/
    V_USER_ID NUMBER := 0;
  
    V_PMT_ID NUMBER := 0;
  
    V_PMT_ORDER_HEADER_ID NUMBER := 0;
  
    CURSOR ORDER_HEAD_INFO IS
      SELECT T.BUDGET_TREE_ID,
             T.BUDGET_YEAR_ID,
             T.ORGANIZATION_ID,
             T.CHARGES_MAIN_TYPE_ID,
             T.CHARGES_SUB_TYPE_ID
        FROM T_PMT_ORDER_HEADER T
       WHERE T.ORDER_HEAD_ID = V_PMT_ORDER_HEADER_ID
         AND T.ENTITY_ID = IN_ENTITYID;
  
    R_ORDER_HEAD_INFO ORDER_HEAD_INFO%ROWTYPE;
  
    CURSOR REQUIS_HEAD_INFO IS
      SELECT *
        FROM T_PMT_COLLAR_REQUIS_HEAD T
       WHERE T.COLLAR_REQUIS_HEAD_ID = IN_HEADID
         AND T.ENTITY_ID = IN_ENTITYID;
  
    R_REQUIS_HEAD_INFO REQUIS_HEAD_INFO%ROWTYPE;
  BEGIN
  
    OPEN REQUIS_HEAD_INFO;
    LOOP
      FETCH REQUIS_HEAD_INFO
        INTO R_REQUIS_HEAD_INFO;
      EXIT WHEN REQUIS_HEAD_INFO%NOTFOUND;
    END LOOP;
    CLOSE REQUIS_HEAD_INFO;
  
    SELECT T.USER_ID
      INTO V_USER_ID
      FROM UP_ORG_USER T
     WHERE T.ACCOUNT = R_REQUIS_HEAD_INFO.LAST_UPDATED_BY;
  
    SELECT T.PMT_ID
      INTO V_PMT_ID
      FROM T_PMT_COLLAR_REQUIS_LINE T
     WHERE T.COLLAR_REQUIS_LINE_ID = IN_LINEID
       AND T.ENTITY_ID = IN_ENTITYID;
  
    SELECT MAX(T.ORDER_HEAD_ID)
      INTO V_PMT_ORDER_HEADER_ID
      FROM T_PMT_ORDER_LINES T
     WHERE T.PMT_ID = V_PMT_ID;
  
    OPEN ORDER_HEAD_INFO;
    LOOP
      FETCH ORDER_HEAD_INFO
        INTO R_ORDER_HEAD_INFO;
      EXIT WHEN ORDER_HEAD_INFO%NOTFOUND;
    END LOOP;
    CLOSE ORDER_HEAD_INFO;
  
    PKG_BUDGET.P_WRITE_FEE(R_ORDER_HEAD_INFO.BUDGET_TREE_ID,
                           IN_ENTITYID,
                           R_ORDER_HEAD_INFO.BUDGET_YEAR_ID,
                           R_ORDER_HEAD_INFO.ORGANIZATION_ID,
                           R_ORDER_HEAD_INFO.CHARGES_MAIN_TYPE_ID,
                           R_ORDER_HEAD_INFO.CHARGES_SUB_TYPE_ID,
                           '-1',
                           '-1',
                           '推广物料',
                           IN_LINEID,
                           R_REQUIS_HEAD_INFO.PMT_ORDER_NUM,
                           NULL,
                           NULL,
                           '-' || FEE_NUM,
                           V_USER_ID,
                           FLAGMESSAGE);
    P_PMT_UNOCCUPY_REMAIN_INV(IN_ENTITYID,
                              IN_HEADID,
                              IN_LINEID,
                              FLAG,
                              FLAGMESSAGE);
    FLAG        := '1';
    FLAGMESSAGE := '调用成功!';
  EXCEPTION
    WHEN OTHERS THEN
      FLAG        := '-1';
      FLAGMESSAGE := '调用pmt_collar_send_setRecQty时发生异常！' ||
                     SUBSTR(SQLERRM, 1, 200);
    
  END P_PMT_UNOCCUPY_BUDGET;

  /**
    取消发货
  */
  PROCEDURE P_PMT_CANCEL_SEND_QTY(IN_LINE_ID       IN NUMBER,
                                  IN_PMT_ORDER_NUM IN VARCHAR2,
                                  IN_CANCEL_QTY    IN NUMBER,
                                  FLAG             OUT VARCHAR2,
                                  FLAG_MESSAGE     OUT VARCHAR2) IS
    V_COUNT        NUMBER := 0;
    V_SEND_QTY     NUMBER := 0;
    V_RE_QTY       NUMBER := 0;
    V_ALL_SEND_QTY NUMBER := 0;
    V_ISSUED_NUM   NUMBER := 0;
  BEGIN
    FLAG         := '1';
    FLAG_MESSAGE := 'OK';
    --校验行表ID
    IF IN_LINE_ID IS NULL THEN
      FLAG         := -1;
      FLAG_MESSAGE := '行表Id为空，请检查';
      RETURN;
    END IF;
    --校验发放单单据号
    IF IN_PMT_ORDER_NUM IS NULL THEN
      FLAG         := -1;
      FLAG_MESSAGE := '单据号为空， 请检查';
      RETURN;
    END IF;
    --校验发放单头表是否存在
    SELECT COUNT(*)
      INTO V_COUNT
      FROM T_PMT_COLLAR_REQUIS_HEAD T
     WHERE T.PMT_ORDER_NUM = IN_PMT_ORDER_NUM;
    IF V_COUNT < 1 THEN
      FLAG         := -1;
      FLAG_MESSAGE := '找不到头表信息，请检查单据号是否正确！';
      RETURN;
    END IF;
    --校验发放单行表信息是否存在
    V_COUNT := 0;
    SELECT COUNT(*)
      INTO V_COUNT
      FROM T_PMT_COLLAR_REQUIS_LINE T
     WHERE T.COLLAR_REQUIS_LINE_ID = IN_LINE_ID
       AND T.COLLAR_REQUIS_HEAD_ID =
           (SELECT T1.COLLAR_REQUIS_HEAD_ID
              FROM T_PMT_COLLAR_REQUIS_HEAD T1
             WHERE T1.PMT_ORDER_NUM = IN_PMT_ORDER_NUM);
    IF V_COUNT < 1 THEN
      FLAG         := -1;
      FLAG_MESSAGE := '没有找到对应的发放单行表信息 请检查！';
      RETURN;
    END IF;
    --校验取消数量是否大于可取消数量
    BEGIN
    
      SELECT NVL(SUM(T2.RCV_QTY), 0)
        INTO V_ALL_SEND_QTY
        FROM T_PMT_COLLAR_SEND_LINE T2
       WHERE T2.COLLAR_SEND_HEAD_ID IN
             (SELECT T.COLLAR_SEND_HEAD_ID
                FROM T_PMT_COLLAR_SEND_HEAD T
               WHERE T.PMT_ORDER_NUM = IN_PMT_ORDER_NUM)
         AND T2.PMT_ID =
             (SELECT PMT_ID
                FROM T_PMT_COLLAR_REQUIS_LINE
               WHERE COLLAR_REQUIS_LINE_ID = IN_LINE_ID)
       GROUP BY T2.PMT_ID;
    EXCEPTION
      WHEN OTHERS THEN
        V_ALL_SEND_QTY := 0;
    END;
    BEGIN
    
      SELECT T.ISSUED_NUM
        INTO V_ISSUED_NUM
        FROM T_PMT_COLLAR_REQUIS_LINE T
       WHERE T.COLLAR_REQUIS_LINE_ID = IN_LINE_ID;
      IF IN_CANCEL_QTY < 0 THEN
        FLAG := '-1';
        FLAG := '取消数量不能小于0';
        RETURN;
      END IF;
      IF IN_CANCEL_QTY > V_ISSUED_NUM - V_ALL_SEND_QTY THEN
        FLAG         := -1;
        FLAG_MESSAGE := '  取消数量大于已下达数量减去实际发货数量，不能取消！';
        RETURN;
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        FLAG         := '-1';
        FLAG_MESSAGE := '！';
        RETURN;
    END;
  
    UPDATE T_PMT_COLLAR_REQUIS_LINE T
       SET T.ISSUED_NUM = T.ISSUED_NUM - IN_CANCEL_QTY
     WHERE T.COLLAR_REQUIS_LINE_ID = IN_LINE_ID
       AND T.COLLAR_REQUIS_HEAD_ID =
           (SELECT T1.COLLAR_REQUIS_HEAD_ID
              FROM T_PMT_COLLAR_REQUIS_HEAD T1
             WHERE T1.PMT_ORDER_NUM = IN_PMT_ORDER_NUM);
  EXCEPTION
    WHEN OTHERS THEN
      FLAG         := '-1';
      FLAG_MESSAGE := '调用P_PMT_CANCEL_SEND_QTY时抛出异常 异常为' ||
                      SUBSTR(SQLERRM, 1, 200);
      RETURN;
    
  END P_PMT_CANCEL_SEND_QTY;
  /**
    重置账户别名发送异常的状态
  */
  PROCEDURE P_SEND_AGAIN_ALIAS(FLAG         OUT VARCHAR2,
                               FLAG_MESSAGE OUT VARCHAR2) IS
    V_STATUS  VARCHAR2(2) := 'N';
    ERR_MSG   VARCHAR2(4000) := '';
    RE_NUMBER NUMBER := 0;
  BEGIN
    FLAG         := '1';
    FLAG_MESSAGE := 'OK';
    FOR INTF_INFO IN (SELECT * 　
                        FROM INTF_INV_TRANSACTION_HEAD
                       WHERE SOURCE_ORDER_TYPE = '推广物料别名'
                         AND STATUS = 'E') LOOP
      BEGIN
        IF INTF_INFO.RETRANSMISSION_NUMBER < 4 OR
           INTF_INFO.RETRANSMISSION_NUMBER IS NULL THEN
           --liangym2 2018-5-11 对字符串按规定长度进行截断
          SELECT T.STATUS, SUBSTRB(T.ERROR_MSG,1,4000), T.RETRANSMISSION_NUMBER
            INTO V_STATUS, ERR_MSG, RE_NUMBER
            FROM INTF_INV_TRANSACTION_HEAD T
           WHERE T.ID = INTF_INFO.ID
             FOR UPDATE;
          IF RE_NUMBER IS NULL THEN
            RE_NUMBER := 0;
          END IF;
          UPDATE INTF_INV_TRANSACTION_HEAD
             SET STATUS                = 'N',
                 ERROR_MSG             = '',
                 RETRANSMISSION_NUMBER = RE_NUMBER + 1
           WHERE ID = INTF_INFO.ID;
        END IF;
      END;
    END LOOP;
  END P_SEND_AGAIN_ALIAS;
  /*
  *推广物料结算批保存后更新数量
  */
  PROCEDURE P_ACCOUNT_AMOUNT_UPDATE(HEADER_ID IN T_PMT_ACCOUNT_LINE.ACCOUNT_HEAD_ID%TYPE, --头表ID
                                    
                                    FLAG     OUT VARCHAR2, --返回值
                                    FLAG_MSG OUT VARCHAR2 --返回信息
                                    ) IS
    V_ACCOUNT_LINE_INFO T_PMT_ACCOUNT_LINE%ROWTYPE; --结算批行信息
    /*         V_ORDER_INV_DETAIL      T_PMT_ORDER_INV_DETAIL%ROWTYPE;                      --订单入库执行信息
    V_ORDER_LINE_INFO       T_PMT_ORDER_LINES%ROWTYPE;                           --订单行信息
    V_DETAIL_ID             T_PMT_ORDER_INV_DETAIL.PMT_INV_DETAIL_ID%TYPE;       --入库执行ID
    */
    V_ORDER_LINE_ID T_PMT_ORDER_LINES.ORDER_LINE_ID%TYPE; --订单行ID
    CURSOR C_ACCOUNT_LINE_INFO IS
      SELECT * FROM T_PMT_ACCOUNT_LINE WHERE ACCOUNT_HEAD_ID = HEADER_ID;
  
    R_ACCOUNT_LINE_INFO C_ACCOUNT_LINE_INFO%ROWTYPE;
  
    CURSOR C_ORDER_LINE_INFO IS
      SELECT *
        FROM T_PMT_ORDER_LINES
       WHERE ORDER_LINE_ID = V_ORDER_LINE_ID;
  
    R_ORDER_LINE_INFO C_ORDER_LINE_INFO%ROWTYPE;
  
  BEGIN
  
    FLAG     := '01';
    FLAG_MSG := '更新数量成功';
  
    BEGIN
      SELECT *
        INTO V_ACCOUNT_LINE_INFO
        FROM T_PMT_ACCOUNT_LINE
       WHERE ACCOUNT_HEAD_ID = HEADER_ID;
    
    EXCEPTION
      WHEN OTHERS THEN
        FLAG     := '02';
        FLAG_MSG := '结算批信息不存在';
        RETURN;
    END;
  
    OPEN C_ACCOUNT_LINE_INFO;
    LOOP
      FETCH C_ACCOUNT_LINE_INFO
        INTO R_ACCOUNT_LINE_INFO;
    
      EXIT WHEN C_ACCOUNT_LINE_INFO%NOTFOUND;
    
      IF (R_ACCOUNT_LINE_INFO.INV_DETAIL IS NOT NULL) THEN
      
        V_ORDER_LINE_ID := R_ACCOUNT_LINE_INFO.ACCOUNT_LINE_ID;
        ---更新入库执行明细数量
        UPDATE T_PMT_ORDER_INV_DETAIL IT
           SET IT.ACCOUNTED_QTY = NVL(IT.ACCOUNTED_QTY, 0) +
                                  R_ACCOUNT_LINE_INFO.ACCOUNTED_QTY
         WHERE IT.PMT_INV_DETAIL_ID = R_ACCOUNT_LINE_INFO.INV_DETAIL;
      
        OPEN C_ORDER_LINE_INFO;
        LOOP
          FETCH C_ORDER_LINE_INFO
            INTO R_ORDER_LINE_INFO;
          EXIT WHEN C_ORDER_LINE_INFO%NOTFOUND;
          ---更新采购单行表数量
          UPDATE T_PMT_ORDER_LINES OT
             SET OT.END_QTY = NVL(OT.END_QTY, 0) +
                              R_ACCOUNT_LINE_INFO.ACCOUNTED_QTY
           WHERE OT.ORDER_LINE_ID = R_ORDER_LINE_INFO.ORDER_LINE_ID;
        END LOOP;
        CLOSE C_ORDER_LINE_INFO;
      END IF;
    END LOOP;
    CLOSE C_ACCOUNT_LINE_INFO;
    COMMIT;
  EXCEPTION
  
    WHEN OTHERS THEN
      ROLLBACK;
      FLAG     := '03';
      FLAG_MSG := '更新数量失败';
      RETURN;
  END P_ACCOUNT_AMOUNT_UPDATE;

  /*
  *采购单占用预算
  */
  PROCEDURE P_ORDER_OCCUPY_BUDGET(HEADER_ID IN T_PMT_ORDER_HEADER.ORDER_HEAD_ID%TYPE, --头表ID
                                  USER_ID   IN NUMBER, --用户ID
                                  FLAG      OUT VARCHAR2, --返回值
                                  FLAG_MSG  OUT VARCHAR2 --返回信息
                                  ) IS
  
    V_DATE_FLOW_ID         T_PMT_ORDER_HEADER.DATE_FLOW_ID%TYPE; --预算流ID
    V_ENTITY_ID            T_PMT_ORDER_HEADER.ENTITY_ID%TYPE; --主体ID
    V_BUDGET_AMOUNT        T_PMT_ORDER_HEADER.BUDGET_AMOUNT%TYPE; --占用金额
    V_ORDER_HEADER_INFO    T_PMT_ORDER_HEADER%ROWTYPE; --采购单头表信息
    V_RETURN_MESSAGE       VARCHAR2(4000); --返回信息
    V_BUDGET_SEGMENT_01_ID T_PMT_ORDER_HEADER.BUDGET_SEGMENT_01_ID%TYPE; --预算树第一层
    V_BUDGET_SEGMENT_02_ID T_PMT_ORDER_HEADER.BUDGET_SEGMENT_02_ID%TYPE; --预算树第二层
    V_BUDGET_SEGMENT_03_ID T_PMT_ORDER_HEADER.BUDGET_SEGMENT_03_ID%TYPE; --预算树第三层
    V_BUDGET_SEGMENT_04_ID T_PMT_ORDER_HEADER.BUDGET_SEGMENT_04_ID%TYPE; --预算树第四层
    V_BUDGET_SEGMENT_05_ID T_PMT_ORDER_HEADER.BUDGET_SEGMENT_05_ID%TYPE; --预算树第五层
    V_BUDGET_SEGMENT_06_ID T_PMT_ORDER_HEADER.BUDGET_SEGMENT_06_ID%TYPE; --预算树第六层
    -- V_MAIN_TYPE         T_PMT_ORDER_HEADER.CHARGES_MAIN_TYPE_ID%TYPE; --大类
    -- V_SUB_TYPE          T_PMT_ORDER_HEADER.CHARGES_SUB_TYPE_ID%TYPE; --小类
  
  BEGIN
    FLAG     := '01';
    FLAG_MSG := '占用预算成功';
  
    BEGIN
      SELECT *
        INTO V_ORDER_HEADER_INFO
        FROM T_PMT_ORDER_HEADER
       WHERE ORDER_HEAD_ID = HEADER_ID
       FOR UPDATE WAIT 2;
    EXCEPTION
      WHEN OTHERS THEN
        FLAG     := '02';
        FLAG_MSG := '采购订单不存在';
        RETURN;
    END;
    
    IF 'Y' = NVL(V_ORDER_HEADER_INFO.BUDGET_FLAG,'N') THEN
       FLAG     := '02';
       FLAG_MSG := '采购订单已占用预算';
       RETURN;
    END IF;
  
    V_DATE_FLOW_ID         := V_ORDER_HEADER_INFO.DATE_FLOW_ID;
    V_ENTITY_ID            := V_ORDER_HEADER_INFO.ENTITY_ID;
    V_BUDGET_AMOUNT        := V_ORDER_HEADER_INFO.BUDGET_AMOUNT;
    V_BUDGET_SEGMENT_01_ID := V_ORDER_HEADER_INFO.BUDGET_SEGMENT_01_ID;
    V_BUDGET_SEGMENT_02_ID := V_ORDER_HEADER_INFO.BUDGET_SEGMENT_02_ID;
    V_BUDGET_SEGMENT_03_ID := V_ORDER_HEADER_INFO.BUDGET_SEGMENT_03_ID;
    V_BUDGET_SEGMENT_04_ID := V_ORDER_HEADER_INFO.BUDGET_SEGMENT_04_ID;
    V_BUDGET_SEGMENT_05_ID := V_ORDER_HEADER_INFO.BUDGET_SEGMENT_05_ID;
    V_BUDGET_SEGMENT_06_ID := V_ORDER_HEADER_INFO.BUDGET_SEGMENT_06_ID;
    /* V_ORGANIZATION_ID := V_ORDER_HEADER_INFO.ORGANIZATION_ID;
    V_MAIN_TYPE       := V_ORDER_HEADER_INFO.CHARGES_MAIN_TYPE_ID;
    V_SUB_TYPE        := V_ORDER_HEADER_INFO.CHARGES_SUB_TYPE_ID;*/
  
    IF (V_DATE_FLOW_ID IS NULL) THEN
      FLAG     := '03';
      FLAG_MSG := '预算流ID为空';
      RETURN;
    END IF;
  
    IF (V_ENTITY_ID IS NULL) THEN
      FLAG     := '04';
      FLAG_MSG := '主体ID为空';
      RETURN;
    END IF;
  
    IF (V_BUDGET_AMOUNT IS NULL) THEN
      FLAG     := '05';
      FLAG_MSG := '占用金额为0';
      RETURN;
    END IF;
    IF (V_BUDGET_SEGMENT_01_ID IS NULL) THEN
      V_BUDGET_SEGMENT_01_ID := -1;
    END IF;
    IF (V_BUDGET_SEGMENT_02_ID IS NULL) THEN
      V_BUDGET_SEGMENT_02_ID := -1;
    END IF;
    IF (V_BUDGET_SEGMENT_03_ID IS NULL) THEN
      V_BUDGET_SEGMENT_03_ID := -1;
    END IF;
    IF (V_BUDGET_SEGMENT_04_ID IS NULL) THEN
      V_BUDGET_SEGMENT_04_ID := -1;
    END IF;
    IF (V_BUDGET_SEGMENT_05_ID IS NULL) THEN
      V_BUDGET_SEGMENT_05_ID := -1;
    END IF;
    IF (V_BUDGET_SEGMENT_06_ID IS NULL) THEN
      V_BUDGET_SEGMENT_06_ID := -1;
    END IF;
    /*IF (V_ORGANIZATION_ID IS NULL) THEN
      V_ORGANIZATION_ID := -1;
    END IF;
    
    IF (V_MAIN_TYPE IS NULL) THEN
      V_MAIN_TYPE := -1;
    END IF;
    
    IF (V_SUB_TYPE IS NULL) THEN
      V_SUB_TYPE := -1;
    END IF;*/
    BEGIN
      PKG_BUDGET.P_WRITE_FEE(V_DATE_FLOW_ID,
                             V_ENTITY_ID,
                             V_BUDGET_SEGMENT_01_ID,
                             V_BUDGET_SEGMENT_02_ID,
                             V_BUDGET_SEGMENT_03_ID,
                             V_BUDGET_SEGMENT_04_ID,
                             V_BUDGET_SEGMENT_05_ID,
                             V_BUDGET_SEGMENT_06_ID,
                             '推广物料',
                             HEADER_ID,
                             V_ORDER_HEADER_INFO.ORDER_NUM,
                             NULL,
                             NULL,
                             V_BUDGET_AMOUNT,
                             USER_ID,
                             V_RETURN_MESSAGE);
      IF 'SUCCESS' <> V_RETURN_MESSAGE THEN
        FLAG     := '06';
        FLAG_MSG := '预算占用调用不成功：' || V_RETURN_MESSAGE;
        RETURN;
      END IF;
      UPDATE T_PMT_ORDER_HEADER T SET T.BUDGET_FLAG = 'Y'
      WHERE ORDER_HEAD_ID = HEADER_ID;
    EXCEPTION
      WHEN OTHERS THEN
        FLAG     := '07';
        FLAG_MSG := '占用预算异常';
        RETURN;
        --RAISE PKG_PMT_PUB.PMT_EXCEPTION;
    END;
  
    /*  FLAG:='06';
    FLAG_MSG:=V_RETURN_MESSAGE;*/
  END P_ORDER_OCCUPY_BUDGET;

  /**
  * 采购单红冲时释放预算
  */
  PROCEDURE P_ORDER_UNOCCUPY_BUDGET(HEADER_ID IN T_PMT_ORDER_HEADER.ORDER_HEAD_ID%TYPE, --头表ID
                                    USER_ID   IN NUMBER, --用户ID
                                    FLAG      OUT VARCHAR2, --返回值
                                    FLAG_MSG  OUT VARCHAR2 --返回信息
                                    ) IS
  
    V_DATE_FLOW_ID      T_PMT_ORDER_HEADER.DATE_FLOW_ID%TYPE; --预算流ID
    V_ENTITY_ID         T_PMT_ORDER_HEADER.ENTITY_ID%TYPE; --主体ID
    V_BUDGET_AMOUNT     T_PMT_ORDER_HEADER.BUDGET_AMOUNT%TYPE; --占用金额
    V_ORDER_HEADER_INFO T_PMT_ORDER_HEADER%ROWTYPE; --采购单头表信息
    V_RETURN_MESSAGE    VARCHAR2(4000); --返回信息
    /* V_ORGANIZATION_ID   T_PMT_ORDER_HEADER.ORGANIZATION_ID%TYPE; --组织机构
    V_MAIN_TYPE         T_PMT_ORDER_HEADER.CHARGES_MAIN_TYPE_ID%TYPE; --大类
    V_SUB_TYPE          T_PMT_ORDER_HEADER.CHARGES_SUB_TYPE_ID%TYPE; --小类*/
    V_BUDGET_SEGMENT_01_ID T_PMT_ORDER_HEADER.BUDGET_SEGMENT_01_ID%TYPE; --预算树第一层
    V_BUDGET_SEGMENT_02_ID T_PMT_ORDER_HEADER.BUDGET_SEGMENT_02_ID%TYPE; --预算树第二层
    V_BUDGET_SEGMENT_03_ID T_PMT_ORDER_HEADER.BUDGET_SEGMENT_03_ID%TYPE; --预算树第三层
    V_BUDGET_SEGMENT_04_ID T_PMT_ORDER_HEADER.BUDGET_SEGMENT_04_ID%TYPE; --预算树第四层
    V_BUDGET_SEGMENT_05_ID T_PMT_ORDER_HEADER.BUDGET_SEGMENT_05_ID%TYPE; --预算树第五层
    V_BUDGET_SEGMENT_06_ID T_PMT_ORDER_HEADER.BUDGET_SEGMENT_06_ID%TYPE; --预算树第六层
    V_BUDGET_TREE_ID       T_PMT_ORDER_HEADER.BUDGET_TREE_ID%TYPE; --预算树ID
  
  BEGIN
    FLAG     := '1';
    FLAG_MSG := '释放预算成功';
  
    BEGIN
      SELECT *
        INTO V_ORDER_HEADER_INFO
        FROM T_PMT_ORDER_HEADER
       WHERE ORDER_HEAD_ID = HEADER_ID
       FOR UPDATE WAIT 2;
    EXCEPTION
      WHEN OTHERS THEN
        FLAG     := '02';
        FLAG_MSG := '采购订单不存在';
        RETURN;
    END;
    
    IF 'N' = NVL(V_ORDER_HEADER_INFO.BUDGET_FLAG,'N') THEN
       FLAG     := '02';
       FLAG_MSG := '采购订单已释放预算';
       RETURN;
    END IF;
  
    V_ENTITY_ID     := V_ORDER_HEADER_INFO.ENTITY_ID;
    V_BUDGET_AMOUNT := V_ORDER_HEADER_INFO.BUDGET_AMOUNT;
    /*  V_ORGANIZATION_ID := V_ORDER_HEADER_INFO.ORGANIZATION_ID;
    V_MAIN_TYPE       := V_ORDER_HEADER_INFO.CHARGES_MAIN_TYPE_ID;
    V_SUB_TYPE        := V_ORDER_HEADER_INFO.CHARGES_SUB_TYPE_ID;*/
    V_BUDGET_SEGMENT_01_ID := V_ORDER_HEADER_INFO.BUDGET_SEGMENT_01_ID;
    V_BUDGET_SEGMENT_02_ID := V_ORDER_HEADER_INFO.BUDGET_SEGMENT_02_ID;
    V_BUDGET_SEGMENT_03_ID := V_ORDER_HEADER_INFO.BUDGET_SEGMENT_03_ID;
    V_BUDGET_SEGMENT_04_ID := V_ORDER_HEADER_INFO.BUDGET_SEGMENT_04_ID;
    V_BUDGET_SEGMENT_05_ID := V_ORDER_HEADER_INFO.BUDGET_SEGMENT_05_ID;
    V_BUDGET_SEGMENT_06_ID := V_ORDER_HEADER_INFO.BUDGET_SEGMENT_06_ID;
    V_BUDGET_TREE_ID       := V_ORDER_HEADER_INFO.BUDGET_TREE_ID;
  
    IF (V_BUDGET_TREE_ID IS NULL) THEN
      FLAG     := '03';
      FLAG_MSG := '预算树ID为空';
      RETURN;
    END IF;
  
    IF (V_ENTITY_ID IS NULL) THEN
      FLAG     := '04';
      FLAG_MSG := '主体ID为空';
      RETURN;
    END IF;
  
    IF (V_BUDGET_AMOUNT IS NULL OR 0 = V_BUDGET_AMOUNT) THEN
      FLAG     := '05';
      FLAG_MSG := '占用金额为0';
      RETURN;
    END IF;
  
    /*IF (V_ORGANIZATION_ID IS NULL) THEN
      V_ORGANIZATION_ID := -1;
    END IF;
    
    IF (V_MAIN_TYPE IS NULL) THEN
      V_MAIN_TYPE := -1;
    END IF;
    
    IF (V_SUB_TYPE IS NULL) THEN
      V_SUB_TYPE := -1;
    END IF;*/
    IF (V_BUDGET_SEGMENT_01_ID IS NULL) THEN
      V_BUDGET_SEGMENT_01_ID := -1;
    END IF;
    IF (V_BUDGET_SEGMENT_02_ID IS NULL) THEN
      V_BUDGET_SEGMENT_02_ID := -1;
    END IF;
    IF (V_BUDGET_SEGMENT_03_ID IS NULL) THEN
      V_BUDGET_SEGMENT_03_ID := -1;
    END IF;
    IF (V_BUDGET_SEGMENT_04_ID IS NULL) THEN
      V_BUDGET_SEGMENT_04_ID := -1;
    END IF;
    IF (V_BUDGET_SEGMENT_05_ID IS NULL) THEN
      V_BUDGET_SEGMENT_05_ID := -1;
    END IF;
    IF (V_BUDGET_SEGMENT_06_ID IS NULL) THEN
      V_BUDGET_SEGMENT_06_ID := -1;
    END IF;
  
    PKG_BUDGET.P_WRITE_FEE(V_BUDGET_TREE_ID,
                           V_ENTITY_ID,
                           V_BUDGET_SEGMENT_01_ID,
                           V_BUDGET_SEGMENT_02_ID,
                           V_BUDGET_SEGMENT_03_ID,
                           V_BUDGET_SEGMENT_04_ID,
                           V_BUDGET_SEGMENT_05_ID,
                           V_BUDGET_SEGMENT_06_ID,
                           '推广物料',
                           HEADER_ID,
                           V_ORDER_HEADER_INFO.ORDER_NUM,
                           NULL,
                           NULL,
                           '-' || V_BUDGET_AMOUNT,
                           USER_ID,
                           FLAG_MSG);
  
    IF 'SUCCESS' <> FLAG_MSG THEN
      FLAG     := -1;
      FLAG_MSG := '调用PKG_BUDGET.P_WRITE_FEE不成功:' || FLAG_MSG;
      RETURN;
    END IF;
    UPDATE T_PMT_ORDER_HEADER T SET T.BUDGET_FLAG = 'N'
    WHERE ORDER_HEAD_ID = HEADER_ID;
  END P_ORDER_UNOCCUPY_BUDGET;

  /**
  * 中转单A3回写实际数量
  **/
  PROCEDURE P_ORDER_WRITEBACK_AMOUNT(PO_NUMBER IN T_INV_PO_HEADERS.PO_NUM%TYPE, --中转单单号
                                     ENTITY_ID IN NUMBER, --实体ID
                                     FLAG      OUT VARCHAR2, --返回值
                                     FLAG_MSG  OUT VARCHAR2 --返回信息
                                     ) IS
  
    V_INV_PO_HEADER_INFO     T_INV_PO_HEADERS%ROWTYPE; --中转单头信息
    V_INV_PO_LINES_INFO      T_INV_PO_LINES%ROWTYPE; --中转单行信息
    V_PMT_INV_DETAIL_INFO    T_PMT_ORDER_INV_DETAIL%ROWTYPE; --推广物料采购单入库执行信息
    V_RECEIVED_QTY           T_INV_PO_LINES.RECEIVED_QTY%TYPE; --A3实际接收数量
    V_PMT_INV_DETAIL_LINE_ID T_PMT_ORDER_INV_DETAIL.ORDER_LINE_ID%TYPE; --入库执行行号
    V_PMT_OLD_AMOUNT         T_PMT_ORDER_INV_DETAIL.STORAGED_QTY%TYPE; --原数量
    V_PMT_CANCEL_AMOUNT      T_PMT_ORDER_INV_DETAIL.CANCEL_QTY%TYPE; --红冲数量
    V_CANCEL_AMOUNT          NUMBER := 0;
  
    V_CANCEL_AMOUNT_TOTAL NUMBER := 0;
    V_PMT_ORDER_NUM       T_PMT_ORDER_HEADER.ORDER_NUM%TYPE; --采购订单号;
    CURSOR C_INV_PO_LINE_INFO IS
      SELECT L.*
        FROM T_INV_PO_LINES L
       WHERE L.PO_ID =
             (SELECT H.PO_ID FROM T_INV_PO_HEADERS H WHERE H.PO_NUM = PO_NUMBER);
    R_INV_PO_LINE_INFO C_INV_PO_LINE_INFO%ROWTYPE;
  
    CURSOR C_PMT_INV_DETAIL_INFO IS
      SELECT OD.* FROM T_PMT_ORDER_INV_DETAIL OD
      INNER JOIN T_PMT_ORDER_LINES L ON (L.ORDER_LINE_ID = OD.ORDER_LINE_ID)
      WHERE OD.PO_NUM = PO_NUMBER
      FOR UPDATE OF OD.PMT_INV_DETAIL_ID,L.ORDER_LINE_ID WAIT 3;
    R_PMT_INV_DETAIL_INFO C_PMT_INV_DETAIL_INFO%ROWTYPE;
  
  BEGIN
    FLAG     := V_RESULT;
    FLAG_MSG := '更新数量成功';--V_RESULT_MSG
    --FLAG_MSG := V_RESULT_MSG;
  
    OPEN C_INV_PO_LINE_INFO;
    LOOP
      FETCH C_INV_PO_LINE_INFO
        INTO R_INV_PO_LINE_INFO;
    
      EXIT WHEN C_INV_PO_LINE_INFO%NOTFOUND;
    
      V_RECEIVED_QTY := R_INV_PO_LINE_INFO.RECEIVED_QTY;
    
      OPEN C_PMT_INV_DETAIL_INFO;
      LOOP
        FETCH C_PMT_INV_DETAIL_INFO
          INTO R_PMT_INV_DETAIL_INFO;
      
        EXIT WHEN C_PMT_INV_DETAIL_INFO%NOTFOUND;
        IF (R_PMT_INV_DETAIL_INFO.PMT_CODE = R_INV_PO_LINE_INFO.ITEM_CODE)
          AND (R_PMT_INV_DETAIL_INFO.ACTUAL_QTY IS NULL OR R_PMT_INV_DETAIL_INFO.CANCEL_QTY IS NULL
          OR R_PMT_INV_DETAIL_INFO.STORAGE_NOW_QTY > NVL(R_PMT_INV_DETAIL_INFO.ACTUAL_QTY,0)
          /*(NVL(R_PMT_INV_DETAIL_INFO.ACTUAL_QTY,0)
           + NVL(R_PMT_INV_DETAIL_INFO.CANCEL_QTY,0))*/ ) THEN
          --更新数量
          V_PMT_INV_DETAIL_LINE_ID := R_PMT_INV_DETAIL_INFO.ORDER_LINE_ID;
          V_PMT_OLD_AMOUNT         := R_PMT_INV_DETAIL_INFO.STORAGED_QTY;
          V_PMT_CANCEL_AMOUNT      := R_PMT_INV_DETAIL_INFO.STORAGE_NOW_QTY - V_RECEIVED_QTY;
        
          UPDATE T_PMT_ORDER_INV_DETAIL OI
             SET OI.STORAGED_QTY =
                 (V_PMT_OLD_AMOUNT - V_PMT_CANCEL_AMOUNT)
           WHERE OI.PMT_CODE = R_INV_PO_LINE_INFO.ITEM_CODE
             --AND OI.PO_NUM = PO_NUMBER
             AND OI.ORDER_LINE_ID = R_PMT_INV_DETAIL_INFO.ORDER_LINE_ID
             --AND OI.ENTITY_ID = ??
             ;
        
          UPDATE T_PMT_ORDER_INV_DETAIL PI
             SET PI.STORAGE_NOW_QTY = V_RECEIVED_QTY,
                 PI.CANCEL_QTY      = NVL(PI.CANCEL_QTY,0) + V_PMT_CANCEL_AMOUNT,
                 PI.ACTUAL_QTY      = NVL(PI.ACTUAL_QTY,0) + V_RECEIVED_QTY
           WHERE /*PI.PMT_CODE = R_INV_PO_LINE_INFO.ITEM_CODE
             AND PI.PO_NUM = PO_NUMBER*/
             PI.PMT_INV_DETAIL_ID = R_PMT_INV_DETAIL_INFO.PMT_INV_DETAIL_ID
             ;
        
          UPDATE T_PMT_ORDER_LINES L
             SET L.STORAGED_QTY = L.STORAGED_QTY - V_PMT_CANCEL_AMOUNT
           WHERE L.ORDER_LINE_ID = R_PMT_INV_DETAIL_INFO.ORDER_LINE_ID;
          V_CANCEL_AMOUNT       := NVL(V_PMT_CANCEL_AMOUNT, 0) *
                                   R_PMT_INV_DETAIL_INFO.PMT_PRICE;
          V_CANCEL_AMOUNT_TOTAL := NVL(V_CANCEL_AMOUNT_TOTAL, 0) +
                                   NVL(V_CANCEL_AMOUNT, 0);
          V_PMT_ORDER_NUM       := R_PMT_INV_DETAIL_INFO.ORDER_HEAD_NUM;
        END IF;
      
      END LOOP;
      CLOSE C_PMT_INV_DETAIL_INFO;
    END LOOP;
    CLOSE C_INV_PO_LINE_INFO;
  
    /**
      如果采购订单为关闭状态则红冲部分释放预算
    */
    IF (V_PMT_ORDER_NUM IS NOT NULL) AND V_CANCEL_AMOUNT_TOTAL <> 0 THEN
    
      FOR PMT_ORDER_NUM IN (SELECT *
                              FROM T_PMT_ORDER_HEADER T
                             WHERE T.ORDER_NUM = V_PMT_ORDER_NUM) LOOP
        IF PMT_ORDER_NUM.ORDER_STATUS = PKG_PMT_OPERATION.V_CLOSE_STATUS THEN
          PKG_PMT_OPERATION.P_UNOCCUPY_BUDGET(I_ORDER_ID   => PMT_ORDER_NUM.ORDER_HEAD_ID,
                                              I_FEE_AMOUNT => V_CANCEL_AMOUNT_TOTAL,
                                              I_ENTITY_ID  => PMT_ORDER_NUM.ENTITY_ID,
                                              O_FLAG       => FLAG,
                                              O_FLAG_MSG   => FLAG_MSG);
          IF FLAG <> PKG_PMT_OPERATION.V_RESULT THEN
            ROLLBACK;
            FLAG := '-1';
            IF FLAG_MSG = PKG_PMT_OPERATION.V_RESULT_MSG THEN
              FLAG_MSG := '释放推广物料采购合同预算不成功：';
            END IF;
            RETURN ;
          ELSE
            FLAG := V_RESULT;
            FLAG_MSG := '更新数量成功';--V_RESULT_MSG
          END IF;
        END IF;
      END LOOP;
    END IF;
  
  EXCEPTION
    WHEN PKG_PMT_OPERATION.PMT_EXCEPTION THEN
      ROLLBACK;
      FLAG := '-1';
      IF FLAG_MSG IS NULL THEN
        FLAG_MSG :=  '释放推广物料采购合同预算不成功：' || SQLERRM;
      END IF;
    WHEN OTHERS THEN
      ROLLBACK;
      FLAG := '-2';
      IF SQLCODE = -30006 OR SQLCODE = -54 THEN
        FLAG := '-3';
        FLAG_MSG := '中转单A3回写实际数量发生异常，同时存在其他操作：' || SQLERRM;
      ELSE
        FLAG_MSG := '中转单A3回写实际数量发生异常：[SQLCODE：' || SQLCODE || '，MSG：' ||
                      SQLERRM || ']';
      END IF;
  END P_ORDER_WRITEBACK_AMOUNT;
  /**
  * 校验生成发放单的数量是否正常
  **/
  PROCEDURE P_CHECK_SEND_QTY(IN_HEAD_ID   IN T_PMT_COLLAR_SEND_HEAD.COLLAR_SEND_HEAD_ID%TYPE, --头ID
                             O_S_FLAG     OUT VARCHAR2, --返回值
                             O_S_FLAG_MSG OUT VARCHAR2 --返回信息
                             ) AS
    V_PMT_ORDER_NUM T_PMT_COLLAR_REQUIS_HEAD.PMT_ORDER_NUM%TYPE;
    V_REC_QTY       NUMBER;
    V_ISSUED_NUM    T_PMT_COLLAR_REQUIS_LINE.ISSUED_NUM%TYPE;
  BEGIN
    --查找原单据号
    BEGIN
      SELECT T.PMT_ORDER_NUM
        INTO V_PMT_ORDER_NUM
        FROM T_PMT_COLLAR_SEND_HEAD T
       WHERE T.COLLAR_SEND_HEAD_ID = IN_HEAD_ID;
    EXCEPTION
      WHEN OTHERS THEN
        O_S_FLAG     := -1;
        O_S_FLAG_MSG := '查找原单据号失败';
        RAISE PKG_PMT_PUB.PMT_EXCEPTION;
    END;
  
    FOR LINE_INFO IN (SELECT *
                        FROM T_PMT_COLLAR_SEND_LINE TL
                       WHERE TL.COLLAR_SEND_HEAD_ID = IN_HEAD_ID) LOOP
      --获取历史接收数据
      SELECT SUM(T2.RCV_QTY)
        INTO V_REC_QTY
        FROM T_PMT_COLLAR_SEND_LINE T2
       WHERE T2.COLLAR_SEND_HEAD_ID IN
             (SELECT T.COLLAR_SEND_HEAD_ID
                FROM T_PMT_COLLAR_SEND_HEAD T
               WHERE T.PMT_ORDER_NUM = V_PMT_ORDER_NUM
                 AND T.COLLAR_SEND_HEAD_ID <> IN_HEAD_ID)
         AND T2.PMT_ID = LINE_INFO.PMT_ID;
      --获取原单据下达数量
      SELECT T.ISSUED_NUM
        INTO V_ISSUED_NUM
        FROM T_PMT_COLLAR_REQUIS_LINE T
       WHERE T.COLLAR_REQUIS_HEAD_ID = LINE_INFO.ORIGIN_ORDER_ID
         AND T.COLLAR_REQUIS_LINE_ID = LINE_INFO.ORIGIN_LINE_ID;
      IF V_REC_QTY + LINE_INFO.RCV_QTY > V_ISSUED_NUM THEN
        O_S_FLAG     := -1;
        O_S_FLAG_MSG := '原单据[' || V_PMT_ORDER_NUM || ']中的产品[' ||
                        LINE_INFO.PMT_CODE || ']累计回写数量超过已下达数量';
        RAISE PKG_PMT_PUB.PMT_EXCEPTION;
      END IF;
    END LOOP;
    O_S_FLAG     := PKG_PMT_PUB.V_RESULT;
    O_S_FLAG_MSG := PKG_PMT_PUB.V_RESULT_MSG;
  EXCEPTION
    WHEN PKG_PMT_PUB.PMT_EXCEPTION THEN
      RETURN;
    WHEN OTHERS THEN
      O_S_FLAG     := -1;
      O_S_FLAG_MSG := '调用P_CHECK_SEND_QTY失败' || SUBSTR(SQLERRM, 1, 200);
  END P_CHECK_SEND_QTY;

  /**
  *检查推广物料采购单预算
  */
  PROCEDURE P_PMT_CHECK_BUDGET(P_ORDER_HEAD_ID         IN NUMBER,
                               I_BUDGET_AMOUNT         IN NUMBER, --预算
                               P_BUDGET_AMOUNT         OUT NUMBER, --占用预算
                               P_BUDGET_AMOUNT_CAN_USE OUT NUMBER, --可用预算
                               P_BUDGET_AMOUNT_USING1  OUT NUMBER, --同节点制单占用预算
                               P_BUDGET_AMOUNT_USING2  OUT NUMBER, --同节点送审占用预算
                               P_MESSAGE               OUT VARCHAR2) AS
  BEGIN
    UPDATE T_PMT_ORDER_HEADER T
       SET T.BUDGET_AMOUNT = I_BUDGET_AMOUNT
     WHERE T.ORDER_HEAD_ID = P_ORDER_HEAD_ID;
    P_PMT_CHECK_BUDGET(P_ORDER_HEAD_ID,
                       P_BUDGET_AMOUNT,
                       P_BUDGET_AMOUNT,
                       P_BUDGET_AMOUNT_USING1,
                       P_BUDGET_AMOUNT_USING2,
                       P_MESSAGE);
  END P_PMT_CHECK_BUDGET;
  
  /*
        * 采购单占用预算
        */
  PROCEDURE P_ORDER_OCCUPY_BUDGET(HEADER_ID       IN T_PMT_ORDER_HEADER.ORDER_HEAD_ID%TYPE, --头表ID
                                  USER_ID         IN NUMBER, --用户ID
                                  I_BUDGET_AMOUNT IN NUMBER, --预算
                                  FLAG            OUT VARCHAR2, --返回值
                                  FLAG_MSG        OUT VARCHAR2 --返回信息
                                  ) AS
  BEGIN
    UPDATE T_PMT_ORDER_HEADER T
       SET T.BUDGET_AMOUNT = I_BUDGET_AMOUNT
     WHERE T.ORDER_HEAD_ID = HEADER_ID AND 'N' = NVL(T.BUDGET_FLAG,'N');
    IF 0 = SQL%ROWCOUNT THEN
      FLAG     := '02';
      FLAG_MSG := '采购订单不存在或已占用预算';
      RETURN;
    END IF;
    P_ORDER_OCCUPY_BUDGET(HEADER_ID, USER_ID, FLAG, FLAG_MSG);
  END P_ORDER_OCCUPY_BUDGET;
  
    /*
  * 推广物料采购单生成实际发货信息
  */
  PROCEDURE P_PMT_CREATE_ACTUAL_SHIP(P_SHIP_BATCH_ID IN NUMBER, --批次ID
                                     USER_CODE     IN VARCHAR2, --用户ID
                                     RETURN_MSG    OUT VARCHAR2 --返回信息
                                     ) AS
    N_ACTUAL_SHIP_ID NUMBER;
    S_STEP             VARCHAR2(40);
    P_SHIP_DOC_ID      NUMBER;
    P_VEHICLE_NUM      VARCHAR2(100);
    S_SHIP_STATUS      VARCHAR2(32);
    
  BEGIN
    RETURN_MSG := 'OK';
    SAVEPOINT SP;
  
    --取出对应的发货通知单ID
    S_STEP := '取发货通知单';
    SELECT
      SHIP_DOC_ID
    INTO
      P_SHIP_DOC_ID
    FROM
      T_LG_SHIP_DOC_SHIP_LINE
    WHERE
      SHIP_BATCH_ID = P_SHIP_BATCH_ID
      AND ROWNUM = 1;

    --获取排车编号
    S_STEP := '取排车编号';
    SELECT
      VEHICLE_NUM
    INTO
      P_VEHICLE_NUM
    FROM
      T_LG_SHIP_DOC_SHIP_BATCH
    WHERE
      SHIP_BATCH_ID = P_SHIP_BATCH_ID;

    --锁定发货通知单表
    S_STEP := '锁定发货通知单';
    BEGIN
      SELECT
        SHIP_STATUS
      INTO
        S_SHIP_STATUS
      FROM
        T_LG_SHIP_DOC
      WHERE
        SHIP_DOC_ID = P_SHIP_DOC_ID
      FOR UPDATE WAIT 2;
      IF S_SHIP_STATUS <> 'NEED_SHIP' THEN
        RETURN_MSG := '只有需发货状态的发货通知单才能写实际发货信息。';
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        IF SQLCODE IN (-51,-54,-30006) THEN
           RETURN_MSG := '锁定发货通知单不成功！请稍后再试。';
        END IF;
    END;

    --检查发货数量是否大于可发货数量
    IF RETURN_MSG = 'OK' THEN
      S_STEP := '检查是否大于可发货数';
      BEGIN
        SELECT
          '发货数量(' || TO_CHAR(SDSL.QUANTITY) || ')不能大于可发货数量('
            || TO_CHAR(SDL.ITEM_QTY) || '-' || TO_CHAR(NVL(SDL.FACT_SHIP_QTY,0)) || '-'
            || NVL(SDL.CANCEL_QTY,0) || '),来源单号：' || SDL.ORIGIN_ORDER_NUM
        INTO
          RETURN_MSG
        FROM
          T_LG_SHIP_DOC_LINE SDL
          ,T_LG_SHIP_DOC_SHIP_LINE SDSL
        WHERE
          SDL.SHIP_DOC_LINE_ID = SDSL.SHIP_DOC_LINE_ID
          AND SDSL.SHIP_BATCH_ID = P_SHIP_BATCH_ID
          AND SDSL.QUANTITY > SDL.ITEM_QTY - NVL(SDL.FACT_SHIP_QTY,0) - NVL(SDL.CANCEL_QTY,0)
          AND ROWNUM = 1;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          NULL;
      END;
    END IF;
    
    --写发货信息
    IF RETURN_MSG = 'OK' THEN
      --按发货通知单对应的来源单据号分组，循环生成发货信息
      FOR R_BILL IN (SELECT DISTINCT SDL.SALES_MAIN_TYPE,
                                     SDL.ORIGIN_TYPE,
                                     SDL.ORIGIN_ORDER_NUM,
                                     SDL.ORIGIN_ORDER_ID,
                                     SDL.SALES_ORDER_TYPE_ID
                       FROM T_LG_SHIP_DOC_SHIP_LINE SDSL,
                            T_LG_SHIP_DOC_LINE      SDL
                      WHERE SDSL.SHIP_DOC_LINE_ID = SDL.SHIP_DOC_LINE_ID
                        AND SDSL.SHIP_BATCH_ID = P_SHIP_BATCH_ID) LOOP
        --获取发货信息头ID
        SELECT S_LG_ACTUAL_SHIP.NEXTVAL INTO N_ACTUAL_SHIP_ID FROM DUAL;
      
        --写发货信息头表
        INSERT INTO T_LG_ACTUAL_SHIP
          (ACTUAL_SHIP_ID,
           ENTITY_ID,
           SALES_MAIN_TYPE,
           VEHICLE_NUM,
           SALES_ORDER_TYPE_ID,
           VENDOR_ID,
           VENDOR_CODE,
           VENDOR_NAME,
           SHIP_INVENTORY_ID,
           CONSIGNEE_INVENTORY_ID,
           CONSIGNEE_LOCATION_CODE,
           CONSIGNEE_ADDR,
           SHIP_WAY,
           ORIGIN_TYPE,
           ORIGIN_ORDER_NUM,
           ORIGIN_ORDER_ID,
           CUSTOMER_ID,
           CUSTOMER_CODE,
           CUSTOMER_NAME,
           ACCOUNT_CODE,
           SHIP_DATE,
           SOURCE_TYPE,
           SOURCE_BILL_ID,
           SOURCE_BILL_NUM,
           CREATED_BY,
           CREATION_DATE,
           LAST_UPDATED_BY,
           LAST_UPDATE_DATE,
           SHIP_TERMINAL_ENTITY_ID,
           SHIP_TERMINAL_CODE,
           SHIP_TERMINAL_NAME,
           CONSIGNEE_TERMINAL_ENTITY_ID,
           CONSIGNEE_TERMINAL_CODE,
           CONSIGNEE_TERMINAL_NAME,
           WHETHER_A3)
          SELECT N_ACTUAL_SHIP_ID ACTUAL_SHIP_ID,
                 SD.ENTITY_ID,
                 R_BILL.SALES_MAIN_TYPE,
                 P_VEHICLE_NUM VEHICLE_NUM,
                 R_BILL.SALES_ORDER_TYPE_ID,
                 SD.VENDOR_ID,
                 SD.VENDOR_CODE,
                 SD.VENDOR_NAME,
                 SD.SHIP_INVENTORY_ID,
                 SD.CONSIGNEE_INVENTORY_ID,
                 SD.CONSIGNEE_LOCATION_CODE,
                 SD.CONSIGNEE_ADDR,
                 SD.SHIP_WAY,
                 R_BILL.ORIGIN_TYPE,
                 R_BILL.ORIGIN_ORDER_NUM,
                 R_BILL.ORIGIN_ORDER_ID,
                 SD.CUSTOMER_ID,
                 SD.CUSTOMER_CODE,
                 SD.CUSTOMER_NAME,
                 SD.ACCOUNT_CODE,
                 TRUNC(SYSDATE) SHIP_DATE,
                 NULL SOURCE_TYPE --'SHIP_BATCH' SOURCE_TYPE  由于销售模块将非空的来源均认为是库位单，故暂时先用空值
                ,
                 P_SHIP_BATCH_ID SOURCE_BILL_ID,
                 TO_CHAR(P_SHIP_BATCH_ID) SOURCE_BILL_NUM,
                 USER_CODE CREATED_BY,
                 SYSDATE CREATION_DATE,
                 USER_CODE LAST_UPDATED_BY,
                 SYSDATE LAST_UPDATE_DATE,
                 SD.SHIP_TERMINAL_ENTITY_ID,
                 SD.SHIP_TERMINAL_CODE,
                 SD.SHIP_TERMINAL_NAME,
                 SD.CONSIGNEE_TERMINAL_ENTITY_ID,
                 SD.CONSIGNEE_TERMINAL_CODE,
                 SD.CONSIGNEE_TERMINAL_NAME,
                 SD.WHETHER_A3
            FROM T_LG_SHIP_DOC SD
           WHERE SD.SHIP_DOC_ID = P_SHIP_DOC_ID;
      
        --写发货信息行表(将最小的库位单行ID带到发货信息表中)，为了简化逻辑，暂不处理配套关系
        INSERT INTO T_LG_ACTUAL_SHIP_LINE
          (SOURCE_BILL_LINE_ID,
           ORIGIN_SHIP_PLAN_ID,
           ACTUAL_SHIP_LINE_ID,
           SHIP_INFO_ID,
           SHIP_DOC_LINE_ID,
           ORIGIN_LINE_ID,
           ITEM_CODE,
           ITEM_NAME,
           ITEM_QTY,
           CREATED_BY,
           CREATION_DATE,
           LAST_UPDATED_BY,
           LAST_UPDATE_DATE)
          SELECT SDL.SHIP_DOC_LINE_ID          SOURCE_BILL_LINE_ID,
                 SDL.ORIGIN_SHIP_PLAN_ID,
                 S_LG_ACTUAL_SHIP_LINE.NEXTVAL ACTUAL_SHIP_LINE_ID,
                 N_ACTUAL_SHIP_ID              SHIP_INFO_ID,
                 SDL.SHIP_DOC_LINE_ID,
                 SDL.ORIGIN_LINE_ID,
                 SDL.ITEM_CODE,
                 SDL.ITEM_DESC                 ITEM_NAME,
                 SDSL.QUANTITY                 ITEM_QTY,
                 USER_CODE                    CREATED_BY,
                 SYSDATE                       CREATION_DATE,
                 USER_CODE                    LAST_UPDATED_BY,
                 SYSDATE                       LAST_UPDATE_DATE
            FROM T_LG_SHIP_DOC_SHIP_LINE SDSL, T_LG_SHIP_DOC_LINE SDL
           WHERE SDSL.SHIP_DOC_LINE_ID = SDL.SHIP_DOC_LINE_ID
             AND SDSL.SHIP_BATCH_ID = P_SHIP_BATCH_ID
             AND SDL.ORIGIN_TYPE = R_BILL.ORIGIN_TYPE
             AND SDL.ORIGIN_ORDER_ID = R_BILL.ORIGIN_ORDER_ID
             AND SDL.SALES_MAIN_TYPE = R_BILL.SALES_MAIN_TYPE
             AND SDL.SALES_ORDER_TYPE_ID = R_BILL.SALES_ORDER_TYPE_ID
             AND SDL.ORIGIN_ORDER_NUM = R_BILL.ORIGIN_ORDER_NUM;
      
      END LOOP;
    END IF;
  
    IF RETURN_MSG <> 'OK' THEN
      ROLLBACK TO SAVEPOINT SP;
    END IF;
  
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK TO SAVEPOINT SP;
      RETURN_MSG := '写实际发货信息(批次ID:' || TO_CHAR(P_SHIP_BATCH_ID) || '):' ||
                    SQLERRM;
  END P_PMT_CREATE_ACTUAL_SHIP;
END PKG_PMT_PUB;
/

