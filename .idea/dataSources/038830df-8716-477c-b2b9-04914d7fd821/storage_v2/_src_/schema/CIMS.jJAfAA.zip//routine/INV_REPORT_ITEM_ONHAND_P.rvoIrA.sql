create PROCEDURE inv_report_item_onhand_p(
    in_currUser             IN    VARCHAR2,
    in_entity_id            IN    NUMBER,
    is_sales_main_type        IN    VARCHAR2,--营销大类
    in_sales_sub_type        IN    VARCHAR2,--营销小类
    is_item_code            IN    VARCHAR2,--产品编码
    is_item_name            IN    VARCHAR2,--产品名称
    is_uom                    IN    VARCHAR2, --单位
    is_inventory_type       IN    VARCHAR2,--仓库类型
    is_center_code            IN    VARCHAR2,--营销中心编码
    is_inventory_code        IN    VARCHAR2,--仓库编码
    is_inventory_name        IN    VARCHAR2,--仓库名称
    in_num                    IN    NUMBER,--数量，查询现有量等于该值的
    in_ifZero                IN    NUMBER,--是否显示0库存   0不显示1显示
    on_flag                 OUT   NUMBER,
    os_prompt               OUT   VARCHAR2,
    on_id                    OUT   NUMBER
)
AS
    vs_sql1                VARCHAR2 (1000);--t_bd_item
    vs_sql2                VARCHAR2 (1000);--T_INV_INVENTORIES_SALES_CENTER
    vs_sql3                VARCHAR2 (1000);--T_INV_INVENTORIES
    vs_sql4                VARCHAR2 (1000);--T_INV_ONHAND
    vs_sql_inventory    VARCHAR2 (1000);--查询仓库ID的sql
    vs_sql_sales_center    VARCHAR2 (1000);--查询营销中心对应的仓库的sql
    vs_sql_item            VARCHAR2 (1000);--查询产品ID的sql    
    v_inventory_id        T_INV_ONHAND.inventory_id%TYPE;
        
    v_item_id            T_INV_ONHAND.item_id%TYPE;
    v_transaction_uom    T_INV_ONHAND.transaction_uom%TYPE;
    v_quantity            T_INV_ONHAND.quantity%TYPE;
    vn_id                number;
    vs_sql                VARCHAR2 (1000);
    vs_inventory_code    t_inv_inventories.inventory_code%TYPE;
    vs_inventory_name    t_inv_inventories.inventory_name%TYPE;
    vs_inventory_type    t_inv_inventories.inventory_type%TYPE;
    vs_item_code        t_bd_item.item_code%TYPE;
    vs_item_name        t_bd_item.item_name%TYPE;
    vs_sales_main_name    t_bd_item_class.class_name%TYPE;
    vs_sales_sub_name    t_bd_item_class.class_name%TYPE;
    vs_brand            t_bd_item.brand%TYPE;
    vs_productform        t_bd_item.productform%TYPE;
    vs_frequencytype    t_bd_item.frequencytype%TYPE;
    vs_energyeffratiing    t_bd_item.energyeffratiing%TYPE;
    vs_unit_code        t_inv_inventories_sales_center.unit_code%TYPE;
    vs_unit_name        t_inv_inventories_sales_center.unit_name%TYPE;
    vs_sql_onhand       VARCHAR2 (2000);
    vn_num2                number;
    vn_num3                number;
    vn_num4                number;--出库占用量
    vn_num5                number;--在单量
    vs_sales_sub_type    VARCHAR2 (32);
    CURSOR get_report_info IS
        select rowid onhand_id,item_onhand_id,inventory_id,item_id,uom,num1
        from t_inv_report_item_onhand 
        where item_onhand_id = vn_id;
    c_report        get_report_info%ROWTYPE;
BEGIN
    on_flag:=0;
    os_prompt:='';
    on_id:=0;
    vs_sql:='';
    vs_sql1:='';
    vs_sql2:='';
    vs_sql3:='';

    vs_sql4:='';
    vs_sql_inventory:='';
    vs_sql_sales_center:='';
    vs_sql_item:='';
    vs_sql_onhand:='';
    
 

    --所有查询条件都不是必填项  营销大类 vs_sql1
    if is_sales_main_type is not null then
        vs_sql1:=vs_sql1||' and sales_main_type = '''||is_sales_main_type||'''';
    end if;
    --营销小类，转换一下 vs_sql1
    if in_sales_sub_type is not null then
     
        select class_code into vs_sales_sub_type 
        from v_bd_item_subclass 
        where entity_id = in_entity_id and class_code = in_sales_sub_type;
        
        vs_sql1:=vs_sql1||' and sales_sub_type = '''||vs_sales_sub_type||'''';  
    end if;
    
    
     --产品编码vs_sql1
    if is_item_code is not null then
        vs_sql1:=vs_sql1||' and item_code like ''%'||is_item_code||'%''';
    end if;
    --产品名称vs_sql1
    if is_item_name is not null then
        vs_sql1:=vs_sql1||' and item_name like ''%'||is_item_name||'%''';
    end if;
    --仓库类型vs_sql3
    if is_inventory_type is not null then
        vs_sql3:=vs_sql3||' and tiv1.inventory_type = '''||is_inventory_type||'''';
    end if;
    --营销中心编码vs_sql2
    if is_center_code is not null then
        vs_sql2:=vs_sql2||' and unit_code = '''||is_center_code||'''';
    end if;
    --仓库编码vs_sql3
    if is_inventory_code is not null then
        vs_sql3:=vs_sql3||' and tiv1.inventory_code like ''%'||is_inventory_code||'%''';
    end if;
    --仓库名称vs_sql3
    if is_inventory_name is not null then
        vs_sql3:=vs_sql3||' and tiv1.inventory_name like ''%'||is_inventory_name||'%''';
    end if;
    --现有量 vs_sql4
    if in_num is not null then
        vs_sql4:=vs_sql4||' and QUANTITY = '''||in_num||'''';
    end if;
    -- 单位 vs_sql4
    if is_uom is not null then
        vs_sql4:=vs_sql4||' and TRANSACTION_UOM = '''||is_uom||'''';
    end if;
    
    /**如果参数都不为空的话
    vs_sql1: and sales_main_type = ? 
             and sales_sub_type =?  
             and item_code like '%?%' 
             and item_name like '%?%'
    vs_sql2: and unit_code =?
    vs_sql3: and inventory_type =? 
             and inventory_code like ?
             and inventory_name like ?
    vs_sql4: and QUANTITY = ?
             and TRANSACTION_UOM = ? 
    */
    
    
    --查询仓库ID inventory_id 
    /** 最终字符串拼成如下：
        'select inventory_id from t_inv_inventories where entity_id = '||in_entity_id||' and begin_date <=sysdate
                            and (end_date >= sysdate or end_date is null)' ||vs_sql3 
                            and inventory_id in
                            (select inventory_id from t_inv_inventories_sales_center where entity_id = '||in_entity_id||' and begin_date <=sysdate
                                    and (end_date >= sysdate or end_date is null)' ||vs_sql2)
       或者
       select inventory_id from t_inv_inventories_sales_center where entity_id = '||in_entity_id||' and begin_date <=sysdate
                                    and (end_date >= sysdate or end_date is null)' ||vs_sql2
    
    */
    vs_sql_inventory:='select inventory_id from v_Bd_User_Inv_Priv where user_code='''||in_currUser||''' and entity_id = '||in_entity_id;
    if vs_sql3 is not null then
       vs_sql_inventory := 'select tiv2.inventory_id from  t_inv_inventories tiv1 ,v_Bd_User_Inv_Priv tiv2 where tiv1.entity_id='||in_entity_id||' '||vs_sql3 ||
			                    '  and tiv1.inventory_id=tiv2.inventory_id and user_code='''||in_currUser||'''';
    --查询 
        if vs_sql2 is not null then
            vs_sql_sales_center:='select inventory_id from t_inv_inventories_sales_center where entity_id = '||in_entity_id||' and begin_date <=sysdate
                                    and (end_date >= sysdate or end_date is null)' ||vs_sql2 ;                  
            vs_sql_inventory:=vs_sql_inventory||' and tiv1.inventory_id in ('||vs_sql_sales_center||')';
        end if;
    else
        if vs_sql2 is not null then
            vs_sql_sales_center:='select inventory_id from t_inv_inventories_sales_center where entity_id = '||in_entity_id||' and begin_date <=sysdate
                                    and (end_date >= sysdate or end_date is null)' ||vs_sql2 ;
            vs_sql_inventory:=vs_sql_inventory||'and inventory_id in ('||vs_sql_sales_center||')';
        end if;
    end if;
    
    if vs_sql1 is not null then--查询产品ID
        vs_sql_item:='select item_id from t_bd_item where entity_id = '||in_entity_id||' and active_flag = ''Y'''||vs_sql1;
    end if;
    



    select S_INV_REPORT_ITEM_ONHAND.nextval into vn_id from dual;
  
    --查询现有量表
    vs_sql_onhand:='select '||vn_id||',
                           inventory_id,
                           item_id,
                           (select code_name
                               from v_up_codelist
                            where codetype =''BD_UOM''
                            and code_value = transaction_uom)transaction_uom,
                           quantity,
                           S_INV_REPORT_ONHAND_ID.nextval 
                   from t_inv_onhand
                   where entity_id = '||in_entity_id||vs_sql4;
    if vs_sql_inventory is not null then
        vs_sql_onhand:=vs_sql_onhand||' and inventory_id in ('||vs_sql_inventory||')';
    end if;
     DBMS_OUTPUT.put_line(vs_sql_inventory);
      DBMS_OUTPUT.put_line(vs_sql_onhand);
    if vs_sql_item is not null then
        vs_sql_onhand:=vs_sql_onhand||' and item_id in ('||vs_sql_item||')';
    
    end if;
    if in_ifZero is null or in_ifZero = 0 then
        vs_sql_onhand:=vs_sql_onhand||' and quantity<>0';
    end if;
   
   --插入到临时表
    execute immediate 'insert into t_inv_report_item_onhand(item_onhand_id,inventory_id,item_id,uom,num1,onhand_id)'||vs_sql_onhand;

    --打开游标
    for c_report in get_report_info loop
        --查询仓库的相关信息
        select nvl(max(inventory_code),-1),nvl(max(inventory_name),-1),nvl(max(inventory_type),-1)
        into vs_inventory_code,vs_inventory_name,vs_inventory_type
        from t_inv_inventories
        where entity_id = in_entity_id and inventory_id = c_report.inventory_id;
        --查询产品的相关信息
        select nvl(max(item_code),-1),nvl(max(item_name),-1),
            nvl(max((select class_name from t_bd_item_class where class_code = sales_main_type)),-1) sales_main_name,
            nvl(max((select class_name from t_bd_item_class where class_code = sales_sub_type and rownum=1)),-1) sales_sub_name,
            nvl(max(brand),-1),nvl(max(productform),-1),nvl(max(frequencytype),-1),nvl(max(energyeffratiing),-1)
        into vs_item_code,vs_item_name,vs_sales_main_name,vs_sales_sub_name,vs_brand,vs_productform,vs_frequencytype,vs_energyeffratiing
        from t_bd_item
        where entity_id = in_entity_id and item_id = c_report.item_id;
        --查询仓库对应的营销中心
        select  nvl(max(unit_code),-1), nvl(max(unit_name),-1) 
        into vs_unit_code,vs_unit_name 
        from t_inv_inventories_sales_center where entity_id = in_entity_id and inventory_id = c_report.inventory_id;
        --计算保留量、可用量(可用量=现有量-保留量)
        vn_num3:=pkg_inv_pub.f_Get_Item_Inv_Qoh(in_entity_id,c_report.inventory_id,c_report.item_id,null,2,'Y');
        if vn_num3 is null then
            vn_num3:=0;
        end if;
        
        
        --计算出库占用量
         vn_num4:=pkg_inv_pub.f_Get_Item_Inv_Qoh(in_entity_id,c_report.inventory_id,c_report.item_id,null,4,'Y');
          if vn_num4 is null then
            vn_num4:=0;
        end if;
        vn_num2:=c_report.num1-vn_num3-vn_num4;
        --在单量
        vn_num5:=0;
        
        select nvl(max(code_name),-1) into vs_inventory_type
        from up_codelist where codetype = 'INV_INVENTORY_TYPE' and code_value = vs_inventory_type;
        
        update t_inv_report_item_onhand
        set inventory_code=vs_inventory_code,
            inventory_name=vs_inventory_name,
            inventory_type=vs_inventory_type,
            item_code=vs_item_code,
            item_name=vs_item_name,
            sales_main_name=vs_sales_main_name,
            sales_sub_name=vs_sales_sub_name,
            brand=(select code_name 
                         from v_up_codelist 
                         where codetype='GE_MPL_BRAND'
                           and  code_value=vs_brand),
            productform=(select code_name 
                         from v_up_codelist 
                         where codetype='GE_MPL_PRODUCT_FORM'
                           and  code_value=vs_productform),
            frequencytype=(select code_name 
                         from v_up_codelist 
                         where codetype='GE_MPL_FREQUENCY_TYPE'
                           and  code_value=vs_frequencytype),
            energyeffratiing=vs_energyeffratiing,
            center_code=vs_unit_code,
            center_name=vs_unit_name,
            num3=vn_num3,
            num2=vn_num2,
            num4=vn_num4,
            num5=vn_num5
        where rowid = c_report.onhand_id;    
    end loop;
    on_id:=vn_id;
    commit;
EXCEPTION
    WHEN OTHERS THEN
        on_flag   := -1;
        os_prompt := '调用inv_report_item_onhand_p时发生异常！'|| SUBSTR(SQLERRM, 1, 200);
        rollback;
        return;    
END inv_report_item_onhand_p;
/

