create PACKAGE BODY      PKG_POL_POLICY IS

  -----------------------------------------------------------------------------
  -- 确认政策                                                           --
  -----------------------------------------------------------------------------
  PROCEDURE P_AFFIRM_POLICY(P_POLICY_ID    IN NUMBER   --政策ID
                           ,P_USER_ID      IN NUMBER   --用户ID
                           ,P_MESSAGE      OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
                           ,P_ORDER_NUMBER OUT VARCHAR2) IS
    V_POLICY_STATUS          VARCHAR2(40);   --政策状态
    N_FINANCE_ENTITY_ID      NUMBER;         --主体ID
    N_SALES_CENTER_ID        NUMBER;         --中心ID
    VT_CREATE_BY             T_POL_POLICY.CREATED_BY%TYPE;
    VT_CREATE_BY_IN          T_POL_POLICY.CREATED_BY%TYPE;

  BEGIN
    P_MESSAGE := 'OK';
    /*
    程序逻辑：
    1、 需将政策中的EXCEL格式的公式，转换成SQL适用的公式，转换方法：
        将EXCEL的函数定义对应的ORACLE的函数，解释公式时，通过对应的函数处理，
        并将每一个计算过程生成一行（越往内嵌套的表达式，优先级越高），以便于直接使用SQL取值；
    2   生成对应的Y单及行表；
    3、 记录确认人、确认时间，更新状态为“已确认”
    */
        
    --锁定记录，防止一条记录被多次操作。
    /* 
    IF PKG_PUB.F_PUB_LOCK_RECORD('T_POL_POLICY',
                             'POLICY_ID=' || TO_CHAR(P_POLICY_ID)) != 1 THEN
       P_MESSAGE := '锁定政策不成功！请稍后再试。';
    END IF;
    */

    SAVEPOINT SP;
         
    --锁定记录，防止一条记录被多次操作。
    BEGIN
      SELECT STATUS, CREATED_BY
        INTO V_POLICY_STATUS, VT_CREATE_BY
        FROM T_POL_POLICY
       WHERE POLICY_ID = P_POLICY_ID
         FOR UPDATE WAIT 1;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        ROLLBACK TO SAVEPOINT SP;
        P_MESSAGE := '锁定政策不成功，请稍后再试！';
    END;

    --检查政策申请CREATED_BY如果是中文，并且UP_ORG_USER存在姓名跟政策申请CREATED_BY相同的记录
    SELECT (SELECT U.ACCOUNT
              FROM UP_ORG_USER U
             WHERE U.USER_ID = P_USER_ID
               AND LENGTH(VT_CREATE_BY) <> LENGTHB(VT_CREATE_BY) --政策申请CREATED_BY如果是中文
               AND U.NAME = VT_CREATE_BY)
      INTO VT_CREATE_BY_IN
      FROM DUAL;
    IF VT_CREATE_BY_IN IS NOT NULL THEN
      UPDATE T_POL_POLICY
         SET CREATED_BY = VT_CREATE_BY_IN
       WHERE POLICY_ID = P_POLICY_ID;
    END IF;
        
    --获取政策信息
    IF (P_MESSAGE = 'OK') THEN
      BEGIN
        SELECT SP.STATUS, SP.ENTITY_ID, SP.SALES_CENTER_ID
          INTO V_POLICY_STATUS, N_FINANCE_ENTITY_ID, N_SALES_CENTER_ID
          FROM T_POL_POLICY SP
         WHERE SP.POLICY_ID = P_POLICY_ID;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          V_POLICY_STATUS     := NULL;
          N_FINANCE_ENTITY_ID := NULL;
          N_SALES_CENTER_ID   := NULL;
      END;
    END IF;

    --校验政策信息
    /*IF (P_MESSAGE = 'OK') AND (V_POLICY_STATUS <> '已审核') AND (V_POLICY_STATUS <> '重新确认') THEN
      P_MESSAGE := '政策状态不为已审核或重新确认，不能确认政策！';
    END IF;*/

    /*IF (P_MESSAGE = 'OK') THEN
      SELECT COUNT(1)
        INTO N_COUNT
        FROM T_POL_POLICY_RPT_DEF_H H
       WHERE H.POLICY_ID = P_POLICY_ID;
      IF (N_COUNT = 0) THEN
        P_MESSAGE := '政策未设置算法，不能确认政策！';
      END IF;
    END IF;*/

    --生成Y单信息
    IF(P_MESSAGE = 'OK')THEN
      P_CREATE_ORDER_HEADERS(P_POLICY_ID  --政策ID
                            ,P_USER_ID  --用户ID
                            ,N_FINANCE_ENTITY_ID  --主体ID
                            ,P_MESSAGE  --成功则返回“OK”，否则返回出错信息
                            ,P_ORDER_NUMBER);
    END IF;
      
    --2017-3-7 梁颜明 更新政策申请状态为审核通过 并更新政策申请的Y单号 调用了此存储过程就统一在此处理，尽量不要同时是Java后台、存储过程都被调用了
    IF (P_MESSAGE = 'OK') THEN
       UPDATE T_POL_POLICY
          SET STATUS              = '6'
             ,POLICY_ORDER_NUMBER = P_ORDER_NUMBER
             ,VERSION             = 1 + NVL(VERSION, 0)
             ,LAST_UPDATE_DATE    = SYSDATE
        WHERE POLICY_ID = P_POLICY_ID;
    END IF;
      
  EXCEPTION
    WHEN OTHERS THEN
      P_MESSAGE := SQLERRM;
      ROLLBACK TO SP;
      RETURN;
  END P_AFFIRM_POLICY;


  --------------------------------------------------------------------------
  -- 生成Y单头表
  ---------------------------------------------------------------------------
  PROCEDURE P_CREATE_ORDER_HEADERS(P_POLICY_ID    IN NUMBER     ---政策ID
                                  ,P_USER_ID      IN NUMBER     ---用户ID
                                  ,P_ENTITY_ID    IN NUMBER     --主体ID
                                  ,P_MESSAGE      OUT VARCHAR2  ---成功则返回“OK”，否则返回出错信息
                                  ,P_ORDER_NUMBER OUT VARCHAR2) IS
    P_USER_ACCOUNT              VARCHAR2(32);
    P_ORDER_NUMBER_TEMP         VARCHAR2(4000);
    V_POLICY_AMOUNT             NUMBER;
    S_POL_HEADERS               NUMBER;
    V_RETURN_MESSAGE            VARCHAR2(4000);
    V_CUST_SOURCE_FLAG          VARCHAR2(100);  --政策资源标识
    V_DETAIL_ID                 NUMBER;  --预算行Id
    V_CUST_SOURCE_COUNT         NUMBER;

    C_POL_POLICY T_POL_POLICY%ROWTYPE ;

    CURSOR C_POLICY_LINE IS
      SELECT PL.*, PY.DATA_FLOW_ID, PY.POLICY_NUMBER, PY.BUDGET_FLAG
        FROM T_POL_POLICY PY, T_POL_POLICY_LINE PL
       WHERE PY.POLICY_ID = P_POLICY_ID
         AND PY.POLICY_ID = PL.POLICY_ID(+);
    R_POLICY_LINE C_POLICY_LINE%ROWTYPE;

    CURSOR C_POLICY_CUST IS
      SELECT PS.*
        FROM T_POL_POLICY PC, T_POL_POLICY_SOURCE PS
       WHERE PC.POLICY_ID = P_POLICY_ID
         AND PC.POLICY_ID = PS.POLICY_ID(+);
    R_POLICY_CUST C_POLICY_CUST%ROWTYPE;
    
  BEGIN
    P_MESSAGE := 'OK';
    SAVEPOINT SP_ORDER_HEADERS;
    --V_RETURN_MESSAGE := V_SUCCESS;

    --查询政策信息
    SELECT *
      INTO C_POL_POLICY
      FROM T_POL_POLICY A
     WHERE A.POLICY_ID = P_POLICY_ID;

    --查询用户ID
    SELECT T.ACCOUNT
      INTO P_USER_ACCOUNT
      FROM UP_ORG_USER T
     WHERE T.USER_ID = P_USER_ID;

    SELECT NVL(PT.CUST_SOURCE_FLAG, 'N')
      INTO V_CUST_SOURCE_FLAG
      FROM T_POL_TYPE PT
     WHERE PT.APPLY_TYPE_ID = C_POL_POLICY.POLICY_TYPE_ID;

    OPEN C_POLICY_LINE;
    LOOP
      FETCH C_POLICY_LINE
       INTO R_POLICY_LINE;

      EXIT WHEN C_POLICY_LINE%NOTFOUND;

      --占用预算
      IF (R_POLICY_LINE.DATA_FLOW_ID IS NOT NULL) THEN
        IF (P_MESSAGE = 'OK' AND NVL(R_POLICY_LINE.BUDGET_FLAG, 'N') <> 'Y') THEN
             PKG_BUDGET.P_WRITE_FEE(R_POLICY_LINE.DATA_FLOW_ID,
                                    R_POLICY_LINE.ENTITY_ID,
                                    NVL(R_POLICY_LINE.BUDGET_SEGMENT_01_ID, -1),
                                    NVL(R_POLICY_LINE.BUDGET_SEGMENT_02_ID, -1),
                                    NVL(R_POLICY_LINE.BUDGET_SEGMENT_03_ID, -1),
                                    NVL(R_POLICY_LINE.BUDGET_SEGMENT_04_ID, -1),
                                    NVL(R_POLICY_LINE.BUDGET_SEGMENT_05_ID, -1),
                                    NVL(R_POLICY_LINE.BUDGET_SEGMENT_06_ID, -1),
                                    '政策申请',  --费用类型
                                    R_POLICY_LINE.DETAIL_ID,
                                    R_POLICY_LINE.POLICY_NUMBER,
                                    NULL,
                                    NULL,
                                    R_POLICY_LINE.POL_AMOUNT ,
                                    P_USER_ID,
                                    V_RETURN_MESSAGE);
        END IF;
      END IF;

      IF V_RETURN_MESSAGE = 'SUCCESS' THEN
        P_MESSAGE := 'OK';
      ELSIF V_RETURN_MESSAGE IS NOT NULL THEN
        P_MESSAGE := V_RETURN_MESSAGE;
      END IF;

      SELECT COUNT(*)
        INTO V_CUST_SOURCE_COUNT
        FROM T_POL_POLICY_SOURCE PS
       WHERE PS.POLICY_ID = P_POLICY_ID;

      IF V_CUST_SOURCE_COUNT = 0 THEN
        V_CUST_SOURCE_FLAG := 'N';
      END IF;

      IF (P_MESSAGE = 'OK' ) THEN
        IF V_CUST_SOURCE_FLAG = 'N' THEN --非客户资源
          S_POL_HEADERS := S_POLICY_Y_HEADERS.NEXTVAL;

          --梁颜明 2017-5-2 获取Y单号增加超时2秒
          PKG_BD.P_GET_BILL_NO('POLYORDERNUMBER',NULL,P_ENTITY_ID,NULL,P_ORDER_NUMBER,2);

          IF(P_ORDER_NUMBER_TEMP IS NULL)THEN
            P_ORDER_NUMBER_TEMP := P_ORDER_NUMBER;
          ELSE
            P_ORDER_NUMBER_TEMP := P_ORDER_NUMBER_TEMP ||','|| P_ORDER_NUMBER;
          END IF;

          IF (R_POLICY_LINE.DATA_FLOW_ID IS NOT NULL) THEN
            V_POLICY_AMOUNT := R_POLICY_LINE.POL_AMOUNT;
          ELSE
            V_POLICY_AMOUNT := C_POL_POLICY.DOC_LAND_AMOUNT;
          END IF;

          INSERT INTO T_POL_ORDER_HEADERS
          (POLICY_ORDER_ID,                   --政策Y单ID
           ENTITY_ID,                         --主体ID
           POLICY_ORDER_NUMBER,               --单据编号
           ORDER_DATE,                        --单据日期
           STAUTS,                            --状态
           POLICY_ID,                         --政策ID
           POLICY_NUMBER,                     --政策编码
           POLICY_NAME,                       --政策批文标题
           SALES_CENTER_ID,                   --营销中心ID
           SALES_CENTER_CODE,                 --营销中心编码
           SALES_CENTER_NAME,                 --营销中心名称
           POLICY_AMOUNT,                     --政策批文金额
           CLOSED_ESTIMATE_AMOUNT,            --预计来源回收金额
           CUSTOMER_ID,                       --客户ID
           CUSTOMER_CODE,                     --客户编码
           CUSTOMER_NAME,                     --客户名称
           ACCOUNT_ID,                        --账户ID
           ACCOUNT_CODE,                      --账户编码
           DISCOUNT_PAY_DEPT,                 --支付来源
           DISCOUNT_METHOD,                   --折让方式
           DISCOUNT_ITEM,                     --折让项目
           CATALOG_TYPES,                     --涉及机型
           CHECK_END_DATE,                    --审批结束日期
           ACTION_END_DATE,                   --活动结束日期
           INTEND_CASH_DATE,                  --预计兑现日期
           NOT_CASH_REASON,                   --超期未兑现原因
           HAD_CASH_AMOUNT,                   --已转返利金额
           CLOSED_CALLBACK_AMOUNT,            --关闭回收金额
           CLOSE_FLAG,                        --批文关闭标志
           CLOSE_DATE,                        --关闭日期
           CLOSED_BY,                         --关闭人
           CLOSED_BY_NAME,                    --关闭人姓名
           CHECKED_BY,                        --审核状态
           CHECKED_BY_NAME,                   --审核人
           CREATED_BY,                        --创建人
           CREATED_BY_NAME,                   --创建人姓名
           CREATION_DATE,                     --创建时间
           LAST_UPDATED_BY,                   --最后修改人
           LAST_UPDATE_DATE,                  --最后修改时间
           EXECUTED_INV_AMOUNT,               --采购入库金额
           REMARK,                            --备注
           SOURCE_ID,                         --来源ID（政策的预算行ID）
           CONTROL_METHOD,                    --控制方式
           BIZ_SOURCE_TYPE,                   --来源类型
           BIZ_SOURCE_NUMBER,                 --来源号
           ACTION_BEGIN_DATE,                 --活动开始时间
           MATERIAL_BRAND,                    --品牌
           MATERIAL_CATEGORY,                 --品类
           SALES_MAIN_TYPE,                   --营销大类
           ESTIMATE_AMOUNT,                   --预计来源收入
           REMAINING_AMOUNT,                  --剩余金额
           VERSION,                           --乐观锁版本号
           REF_MODEL                          --涉及机型
           ,origin_policy_amount
          )
          VALUES
          (S_POL_HEADERS,
           C_POL_POLICY.ENTITY_ID,
           P_ORDER_NUMBER,
           TRUNC(SYSDATE),
           '5',
           P_POLICY_ID,
           C_POL_POLICY.POLICY_NUMBER,
           C_POL_POLICY.POLICY_NAME,
           C_POL_POLICY.SALES_CENTER_ID,   --营销中心
           C_POL_POLICY.SALES_CENTER_CODE,
           C_POL_POLICY.SALES_CENTER_NAME,
           V_POLICY_AMOUNT,                --申请金额
           0,                              --预计来源回收金额
           C_POL_POLICY.CUSTOMER_ID,       --客户
           C_POL_POLICY.CUSTOMER_CODE,
           C_POL_POLICY.CUSTOMER_NAME,
           C_POL_POLICY.ACCOUNT_ID,
           C_POL_POLICY.ACCOUNT_CODE,
           C_POL_POLICY.DISCOUNT_PAY_DEPT,  --支付来源
           C_POL_POLICY.DISCOUNT_METHOD,    --折让方式
           C_POL_POLICY.DISCOUNT_ITEM,      --折让项目
           '',                              --涉及机型
           TRUNC(C_POL_POLICY.LAST_UPDATE_DATE), --审批结束日期
           C_POL_POLICY.END_DATE,                --活动结束日期
           NULL,                                 --预计兑现日期
           '',                                   --超期未兑现原因
           0,                                    --已转返利金额
           0,                                    --关闭回收金额
           'N',                                  --批文关闭标志
           NULL,                                 --关闭日期
           NULL,                                 --关闭人
           NULL,                                 --关闭人姓名
           P_USER_ACCOUNT,  --审核人
           '',              --审核人名称
           P_USER_ACCOUNT,  --创建人
           '',              --创建人姓名
           SYSDATE,
           P_USER_ACCOUNT,  --最后修改人
           SYSDATE,         --最后修改时间
           0,
           C_POL_POLICY.COMMENTS,         --说明，备注
           R_POLICY_LINE.DETAIL_ID,       --来源ID（政策的预算行ID）
           NULL,                          --控制方式
           NULL,                          --来源类型
           C_POL_POLICY.POLICY_NUMBER,    --来源号（政策编码）
           C_POL_POLICY.BEGIN_DATE,       --开始日期
           C_POL_POLICY.BRAND_NAME,       --品牌
           NULL,                          --品类
           C_POL_POLICY.SALES_MAIN_TYPE,  --营销大类
           NULL,                          --预计来源收入
           V_POLICY_AMOUNT,               --剩余金额
           1,
           C_POL_POLICY.REF_MODEL         --涉及机型
           ,V_POLICY_AMOUNT --原始申请金额
          );
        END IF;
      END IF;
    END LOOP;
    CLOSE C_POLICY_LINE;

    IF (V_CUST_SOURCE_FLAG = 'Y') AND (P_MESSAGE = 'OK') THEN
      --获取预算行Id，预算行只允许有一行
      SELECT PL.DETAIL_ID
        INTO V_DETAIL_ID
        FROM T_POL_POLICY_LINE PL
       WHERE PL.POLICY_ID = P_POLICY_ID;

      OPEN C_POLICY_CUST;
      LOOP
        FETCH C_POLICY_CUST
         INTO R_POLICY_CUST;
        EXIT WHEN C_POLICY_CUST%NOTFOUND;

        --梁颜明 2017-5-2 获取Y单号增加超时2秒
        PKG_BD.P_GET_BILL_NO('POLYORDERNUMBER',NULL,P_ENTITY_ID,NULL,P_ORDER_NUMBER,2);
        --产生返利申请
        INSERT INTO T_POL_ORDER_HEADERS
        (POLICY_ORDER_ID,                   -----政策Y单ID
         ENTITY_ID,                         -----主体ID
         POLICY_ORDER_NUMBER,               -----单据编号
         ORDER_DATE,                        -----单据日期
         STAUTS,                            -----状态
         POLICY_ID,                         -----政策ID
         POLICY_NUMBER,                     -----政策编码
         POLICY_NAME,                       -----政策批文标题
         SALES_CENTER_ID,                   -----营销中心ID
         SALES_CENTER_CODE,                 -----营销中心编码
         SALES_CENTER_NAME,                 -----营销中心名称
         POLICY_AMOUNT,                     -----政策批文金额
         CLOSED_ESTIMATE_AMOUNT,            -----预计来源回收金额
         CUSTOMER_ID,                       -----客户ID
         CUSTOMER_CODE,                     -----客户编码
         CUSTOMER_NAME,                     -----客户名称
         ACCOUNT_ID,                        -----账户ID
         ACCOUNT_CODE,                      -----账户编码
         DISCOUNT_PAY_DEPT,                 -----支付来源
         DISCOUNT_METHOD,                   -----折让方式
         DISCOUNT_ITEM,                     -----折让项目
         CATALOG_TYPES,                     -----涉及机型
         CHECK_END_DATE,                    -----审批结束日期
         ACTION_END_DATE,                   -----活动结束日期
         INTEND_CASH_DATE,                  -----预计兑现日期
         NOT_CASH_REASON,                   -----超期未兑现原因
         HAD_CASH_AMOUNT,                   -----已转返利金额
         CLOSED_CALLBACK_AMOUNT,            -----关闭回收金额
         CLOSE_FLAG,                        -----批文关闭标志
         CLOSE_DATE,                        -----关闭日期
         CLOSED_BY,                         -----关闭人
         CLOSED_BY_NAME,                    -----关闭人姓名
         CHECKED_BY,                        -----审核状态
         CHECKED_BY_NAME,                   -----审核人
         CREATED_BY,                        -----创建人
         CREATED_BY_NAME,                   -----创建人姓名
         CREATION_DATE,                     -----创建时间
         LAST_UPDATED_BY,                   -----最后修改人
         LAST_UPDATE_DATE,                  -----最后修改时间
         EXECUTED_INV_AMOUNT,               -----采购入库金额
         REMARK,                            -----备注
         SOURCE_ID,                         -----来源ID（政策的预算行ID）
         CONTROL_METHOD,                    -----控制方式
         BIZ_SOURCE_TYPE,                   -----来源类型
         BIZ_SOURCE_NUMBER,                 -----来源号
         ACTION_BEGIN_DATE,                 -----活动开始时间
         MATERIAL_BRAND,                    -----品牌
         MATERIAL_CATEGORY,                 -----品类
         SALES_MAIN_TYPE,                   -----营销大类
         ESTIMATE_AMOUNT,                   -----预计来源收入
         REMAINING_AMOUNT,                  -----剩余金额
         VERSION,                           -----乐观锁版本号
         POLICY_SOURCE_ID                   -----政策资源ID
          ,origin_policy_amount
        )
        VALUES
        (S_POLICY_Y_HEADERS.NEXTVAL,
         C_POL_POLICY.ENTITY_ID,
         P_ORDER_NUMBER,
         TRUNC(SYSDATE),
         '5',
         P_POLICY_ID,
         C_POL_POLICY.POLICY_NUMBER,
         C_POL_POLICY.POLICY_NAME,
         R_POLICY_CUST.SALES_CENTER_ID,   --营销中心
         R_POLICY_CUST.SALES_CENTER_CODE,
         R_POLICY_CUST.SALES_CENTER_NAME,
         R_POLICY_CUST.AMOUNT,            --申请金额
         0,                               --预计来源回收金额
         R_POLICY_CUST.CUSTOMER_ID,       --客户
         R_POLICY_CUST.CUSTOMER_CODE,
         R_POLICY_CUST.CUSTOMER_NAME,
         R_POLICY_CUST.ACCOUNT_ID,
         R_POLICY_CUST.ACCOUNT_CODE,
         R_POLICY_CUST.DISCOUNT_PAY_DEPT,      --支付来源
         R_POLICY_CUST.DISCOUNT_METHOD,        --折让方式
         R_POLICY_CUST.DISCOUNT_ITEM,          --折让项目
         '',                                   --涉及机型
         TRUNC(C_POL_POLICY.LAST_UPDATE_DATE), --审批结束日期
         C_POL_POLICY.END_DATE,                --活动结束日期,
         NULL,                                 --预计兑现日期
         '',                                   --超期未兑现原因
         0,                                    --已转返利金额
         0,                                    --关闭回收金额
         'N',                                  --批文关闭标志
         NULL,                                 --关闭日期
         NULL,                                 --关闭人
         NULL,                                 --关闭人姓名
         P_USER_ACCOUNT,                       --审核人
         '',                                   --审核人名称
         P_USER_ACCOUNT,                       --创建人
         '',                                   --创建人姓名
         SYSDATE,
         P_USER_ACCOUNT,                       --最后修改人
         SYSDATE,                              --最后修改时间
         0,
         C_POL_POLICY.COMMENTS,                --说明，备注
         V_DETAIL_ID,                          --来源ID（政策的预算行ID）
         NULL,                                 --控制方式
         NULL,                                 --来源类型
         C_POL_POLICY.POLICY_NUMBER,           --来源号（政策编码）
         C_POL_POLICY.BEGIN_DATE,              --开始日期
         C_POL_POLICY.BRAND_NAME,              --品牌
         NULL,                                 --品类
         R_POLICY_CUST.SALES_MAIN_TYPE,        --营销大类
         NULL,                                 --预计来源收入
         R_POLICY_CUST.AMOUNT,                 --剩余金额
         1,
         R_POLICY_CUST.POLICY_SOURCE_ID        --政策资源ID
         ,R_POLICY_CUST.AMOUNT   --原始申请金额
        );

        --产生返利申请后，更新客户明细行Y单号
        UPDATE T_POL_POLICY_SOURCE PS
           SET PS.POLICY_ORDER_NUMBER = P_ORDER_NUMBER,
               PS.LAST_UPDATED_BY = P_USER_ACCOUNT,
               PS.LAST_UPDATE_DATE = SYSDATE,
               PS.VERSION = NVL(PS.VERSION, 0) + 1
         WHERE PS.POLICY_SOURCE_ID = R_POLICY_CUST.POLICY_SOURCE_ID;
      END LOOP;
      CLOSE C_POLICY_CUST;

      P_ORDER_NUMBER_TEMP := NULL; --客户资源回传为空
    END IF;

    P_ORDER_NUMBER := P_ORDER_NUMBER_TEMP;
  EXCEPTION
    WHEN OTHERS THEN
      P_MESSAGE := SQLERRM;
      ROLLBACK TO SP_ORDER_HEADERS;
      RETURN;
  END P_CREATE_ORDER_HEADERS;


  --------------------------------------------------------------------------------
  /*
  *   创建日期：2014-10-23
  *     创建者：苏冬渊
  *   功能说明：处理政策模块中的Y单生成F单的过程，该过程是自动计算。
                对没有生成F单的Y单轮循执行，最终生成F单头表以及行表
  *    T_POL_ORDER_HEADERS  --  Y单头表
       T_POL_ORDER_LINES  --   行表

       T_POL_DISCOUNT_ORDER --F单头表
       T_POL_DISCOUNT_LINES --行表
      参数说明：
          P_Y_LINE_ID Y单行ID
          P_USER_ID   用户ID
          P_MESSAGE   错误信息返回接收值，成功返回"SUCCESS"，失败返回原因
  *
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_POLICY_Y_TO_F (   P_POLICY_CHK_ID          IN NUMBER, --政策审批ID
                                P_POLICY_ID              IN NUMBER, --政策ID
                                P_Y_LINE_ID              IN NUMBER, --Y单行ID
                                P_ENTITY_ID              IN NUMBER, --主体ID
                                P_USER_ID                IN VARCHAR2, --用户ID
                                P_MESSAGE                IN OUT VARCHAR2 --返回结果：成功返回"SUCCESS"，失败返回原因
                             ) IS

    P_POLICY_NUMBER  VARCHAR2(40);
    --P_REF_MODEL  VARCHAR2(500);
    V_DISCOUNT_ORDER_ID  T_POL_DISCOUNT_ORDER.DISCOUNT_ORDER_ID%TYPE ;
    V_DISCOUNT_ORDER_NUMBER  T_POL_DISCOUNT_ORDER.DISCOUNT_ORDER_NUMBER%TYPE ;
    V_COUNT  NUMBER := 0 ; --计数器
    V_NL  CONSTANT VARCHAR2(2) := CHR(13) || CHR(10); --换行
    --自动生成F单的Y单行记录
    CURSOR C_POL_ORDER_LINES IS
      SELECT A.ENTITY_ID,
             A.POLICY_ORDER_ID,
             B.DISCOUNT_METHOD,   --折让方式
             A.DISCOUNT_PAY_DEPT, --支付来源
             A.DISCOUNT_ITEM,     --折让项目
             A.CONTROL_METHOD,
             A.MATERIAL_BRAND,
             B.SALES_MAIN_TYPE,   --取行上营销大类 2017-11-19
             /*A.SALES_CENTER_ID,
             A.SALES_CENTER_CODE,
             A.SALES_CENTER_NAME,*/
             B.SALES_CENTER_ID,   --取行上营销中心 2017-11-19
             B.SALES_CENTER_CODE,
             B.SALES_CENTER_NAME,
             A.INTEND_CASH_DATE,
             B.CUSTOMER_ID,
             B.CUSTOMER_CODE,
             B.CUSTOMER_NAME,
             B.ACCOUNT_ID,
             --B.ACCOUNT_CODE,
             A.ROWID A_ROWID,
             B.LINE_AMOUNT,
             B.ROWID B_ROWID,
             B.LINE_ID, --Y单行ID
             B.ITEM_ID, --商品ID
             B.ITEM_CODE, --商品编码
             B.ITEM_NAME, --商品名称
             B.UOM_CODE,  --单位
             B.QUANTITY,  --数量
             B.LIST_PRICE, --价格
             B.OU_ID,
             CA.ACCOUNT_CODE,
             PC.POLICY_NAME REMARK,
             B.REF_MODEL,
             A.POLICY_ORDER_NUMBER,
             A.POLICY_NUMBER, --取Y单头的政策编码
             B.POLICY_ID, --取Y单行的政策ID
             B.CALCULATE_GROUP_NAME,
             B.CALCULATE_GROUP_TYPE,
             B.DISCOUNT_PERIOD,
             B.REMARK AS NOTE
        FROM T_POL_ORDER_HEADERS A,
             T_POL_ORDER_LINES B,
             T_CUSTOMER_ACCOUNT CA,
             T_POL_POLICY PC
       WHERE A.POLICY_ORDER_ID = B.POLICY_ORDER_ID
         AND NVL(B.CHANGED_CASH_FLAG,'N') = 'N'
         AND NVL(B.SPLIT_ORDER,'N') = 'N'
         AND B.LINE_ID = P_Y_LINE_ID
         AND B.ACCOUNT_ID = CA.ACCOUNT_ID(+)
         AND A.POLICY_ID = PC.POLICY_ID(+);
         
    V_DISCOUNT_REMARK VARCHAR2(4000);
    V_POLICY_NAME     VARCHAR2(240);
    V_POLICY_Standard_id number;
    V_DISCOUNT_PAY_DEPT VARCHAR2(32); --支付来源（取计算结果审批表中的）
    V_DISCOUNT_ITEM     VARCHAR2(32); --折让项目（取计算结果审批表中的）
  BEGIN
    --设置返回信息
    P_MESSAGE := 'OK' ;
    --获取返利单ID
    SELECT S_POL_DISCOUNT_ORDER.NEXTVAL INTO V_DISCOUNT_ORDER_ID FROM DUAL ;
    --获取返利单据号
    V_DISCOUNT_ORDER_NUMBER := PKG_BD.F_GET_BILL_NO('POLDISCOUNT',NULL,P_ENTITY_ID,NULL) ;

    SELECT a.POLICY_NUMBER, a.POLICY_NAME,(select b.policy_standard_id from t_pol_policy_standard b where a.policy_id=b.policy_id)
      INTO P_POLICY_NUMBER, V_POLICY_NAME,V_POLICY_Standard_id
      FROM T_POL_POLICY a
     WHERE POLICY_ID = P_POLICY_ID;
     
    begin
      if V_POLICY_Standard_id is null then 
      SELECT NVL(PR.DISCOUNT_REMARK, 'NULL')
            ,DISCOUNT_PAY_DEPT
            ,DISCOUNT_ITEM
        INTO V_DISCOUNT_REMARK, V_DISCOUNT_PAY_DEPT, V_DISCOUNT_ITEM
        FROM CIMS.T_POL_POLICY_RESULT_CHK PR
       WHERE PR.RESULT_CHK_ID = P_POLICY_CHK_ID;
           else 
        SELECT 'NULL'
            ,PR.DISCOUNT_PAY_DEPT
            ,PR.DISCOUNT_ITEM
        INTO V_DISCOUNT_REMARK, V_DISCOUNT_PAY_DEPT, V_DISCOUNT_ITEM
        FROM CIMS.t_pol_cash_batch PR
       WHERE PR.Cash_Batch_Id = P_POLICY_CHK_ID;
       
       end if;   
      EXCEPTION 
        WHEN OTHERS THEN
          V_DISCOUNT_REMARK := '';
   
    END;
    IF NVL(V_DISCOUNT_REMARK, 'NULL') = 'NULL' THEN
      V_DISCOUNT_REMARK := V_POLICY_NAME;
    END IF;

    SAVEPOINT ROLLBACK_HERE ;
    --根据Y单循环生成F单信息
    FOR I IN C_POL_ORDER_LINES LOOP
    --根据Y单行记录生成F单头表
    BEGIN
         INSERT INTO T_POL_DISCOUNT_ORDER(
            DISCOUNT_ORDER_ID,
            ENTITY_ID,
            POLICY_ID,
            POLICY_NUMBER,
            DISCOUNT_ORDER_NUMBER,
            OLD_DISCOUNT_ID,
            OLD_DISCOUNT_NUMBER,
            POLICY_ORDER_ID,
            ORDERED_DATE,
            ORDER_TYPE_ID,
            LINK_PIPE_FLAG,
            DISCOUNT_TYPE_ID,
            DISCOUNT_METHOD,
            DISCOUNT_PAY_DEPT,
            DISCOUNT_ITEM,
            PROJECT_CODE,
            PROJECT_DATE,
            PROJECT_FLAG,
            CONTROL_METHOD,
            BRAND_NAME,
            SALES_MAIN_TYPE,
            SALES_CENTER_ID,
            SALES_CENTER_CODE,
            SALES_CENTER_NAME,
            PRINT_FLAG,
            INTEND_CASH_DATE,
            CUSTOMER_ID,
            CUSTOMER_CODE,
            CUSTOMER_NAME,
            ACCOUNT_ID,
            ACCOUNT_CODE,
            OU_ID,
            STATUS,
            SALES_NUMBER,
            EMS_FLAG,
            EMS_APPLY_ID,
            VENDOR_SITE_ID,
            VENDOR_ID,
            COMPANY_ID,
            FEE_TYPE_ID,
            BUSIORGID,
            FEE_DETAIL_TYPE,
            FEE_MAIN_TYPE,
            REMARK,
            CREATED_BY,
            CREATION_DATE,
            LAST_UPDATED_BY,
            LAST_UPDATE_DATE,
            REF_MODEL,
            FROM_LINE_ID, --增加来源行ID
            CALCULATE_GROUP_NAME,
            CALCULATE_GROUP_TYPE,
            DISCOUNT_PERIOD,
            ITEM_SOURCE_TYPE) 
         SELECT
            V_DISCOUNT_ORDER_ID DISCOUNT_ORDER_ID,
            I.ENTITY_ID ENTITY_ID,
            I.POLICY_ID,
            I.POLICY_NUMBER,
            V_DISCOUNT_ORDER_NUMBER DISCOUNT_ORDER_NUMBER,
            NULL OLD_DISCOUNT_ID,
            NULL OLD_DISCOUNT_NUMBER,
            I.POLICY_ORDER_ID POLICY_ORDER_ID,
            TRUNC(SYSDATE) ORDERED_DATE,  --单据日期，需要确认
            1 ORDER_TYPE_ID, --单据类型(1:正向，2：反向)
            NULL LINK_PIPE_FLAG,  --是否含配件
            NULL DISCOUNT_TYPE_ID,  --折扣类型
            I.DISCOUNT_METHOD DISCOUNT_METHOD,  --折让方式
            NVL(V_DISCOUNT_PAY_DEPT, I.DISCOUNT_PAY_DEPT) DISCOUNT_PAY_DEPT, --支付来源
            NVL(V_DISCOUNT_ITEM, I.DISCOUNT_ITEM) DISCOUNT_ITEM, --折让项目
            NULL PROJECT_CODE,  --工程机登录号
            NULL PROJECT_DATE,  --工程机登录时间
            NULL PROJECT_FLAG,  --是否收到工程机资料
            I.CONTROL_METHOD CONTROL_METHOD,
            I.MATERIAL_BRAND BRAND_NAME,
            I.SALES_MAIN_TYPE SALES_MAIN_TYPE,
            I.SALES_CENTER_ID SALES_CENTER_ID,
            I.SALES_CENTER_CODE SALES_CENTER_CODE,
            I.SALES_CENTER_NAME SALES_CENTER_NAME,
            NULL PRINT_FLAG,  --是否打印
            I.INTEND_CASH_DATE INTEND_CASH_DATE,
            I.CUSTOMER_ID CUSTOMER_ID,
            I.CUSTOMER_CODE CUSTOMER_CODE,
            I.CUSTOMER_NAME CUSTOMER_NAME,
            I.ACCOUNT_ID ACCOUNT_ID,
            I.ACCOUNT_CODE ACCOUNT_CODE,
            I.OU_ID OU_ID,--经营单位ID
            --NULL OU_ID, --经营单位ID
            5 STATUS, --状态(5：已录入)
            NULL SALES_NUMBER, --销售单号
            'N' EMS_FLAG,   --是否已同步过EMS  Y\N\ NULL
            NULL EMS_APPLY_ID,  --EMS同步过来的批文ID
            NULL VENDOR_SITE_ID, --供应商地点ID
            NULL VENDOR_ID,    --供应商ID
            NULL COMPANY_ID,   --公司ID
            NULL FEE_TYPE_ID,  --费用类型ID
            NULL BUSIORGID,    --预算组织ID
            NULL FEE_DETAIL_TYPE,  --费用小类ID
            NULL FEE_MAIN_TYPE,    --费用大类ID            
            NVL(I.NOTE,V_DISCOUNT_REMARK)||'/'||I.POLICY_NUMBER||'/'||I.POLICY_ORDER_NUMBER||'/'||V_DISCOUNT_ORDER_NUMBER,
            P_USER_ID,--'自动计算' CREATED_BY,
            SYSDATE CREATION_DATE,
            P_USER_ID,--'自动计算' LAST_UPDATED_BY,
            SYSDATE LAST_UPDATE_DATE,
            I.REF_MODEL,
            I.LINE_ID,
            I.CALCULATE_GROUP_NAME,
            I.CALCULATE_GROUP_TYPE,
            I.DISCOUNT_PERIOD,
            '00' --产品明细来源类型（政策计算）
	    FROM DUAL  ;
        EXCEPTION WHEN OTHERS THEN
          ROLLBACK TO ROLLBACK_HERE ;
          P_MESSAGE := '保存返利单表报错，错误代码：' || SQLCODE || V_NL || '错误信息：' || SQLERRM ;
          RETURN ;
        END ;

        --根据Y单行记录生成F单行表
        BEGIN
         INSERT INTO T_POL_DISCOUNT_LINES(
            LINE_ID,
            DISCOUNT_ORDER_ID,
            AMOUNT,
            DISCOUNT_AMOUNT,
            REWARDED_AMOUNT,
            CONT_LINE_ID,
            ITEM_ID,
            ITEM_CODE,
            ITEM_NAME,
            QUANTITY,
            ITEM_PRICE,
            BANK_CODE,
            BANK_NAME,
            ACCOUNT,
            BRANCH_ACCOUNT,
            CREATED_BY,
            CREATION_DATE,
            LAST_UPDATED_BY,
            LAST_UPDATE_DATE)
         SELECT
            S_POL_DISCOUNT_LINES.NEXTVAL LINE_ID,
            V_DISCOUNT_ORDER_ID DISCOUNT_ORDER_ID,
            I.LINE_AMOUNT AMOUNT ,
            I.LINE_AMOUNT DISCOUNT_AMOUNT, --折让金额
            0 REWARDED_AMOUNT, --红冲金额
            NULL CONT_LINE_ID, --来源行ID（记录Y单行ID）
            I.ITEM_ID ITEM_ID,      --产品ID
            I.ITEM_CODE ITEM_CODE,    --产品编码
            I.ITEM_NAME ITEM_NAME,    --产品名称
            I.QUANTITY QUANTITY,     --产品数量
            I.LIST_PRICE ITEM_PRICE,   --产品价格
            NULL BANK_CODE,    --银行编码
            NULL BANK_NAME,    --银行名称
            NULL ACCOUNT,      --银行账号
            NULL BRANCH_ACCOUNT,    --分行账号
            P_USER_ID,--'自动计算' CREATED_BY,
            SYSDATE CREATION_DATE,
            P_USER_ID,--'自动计算' LAST_UPDATED_BY,
            SYSDATE LAST_UPDATE_DATE
          FROM DUAL  ;
        EXCEPTION WHEN OTHERS THEN
          ROLLBACK TO ROLLBACK_HERE;
          P_MESSAGE := '保存返利单行表出错，错误代码：' || SQLCODE || V_NL || '错误信息：' || SQLERRM ;
          RETURN ;
        END ;

         --生成F单头、行表之后，在Y单上回置状态
        BEGIN
          --Y单头表置 已转返利金额  字段
          UPDATE T_POL_ORDER_HEADERS T
             SET T.HAD_CASH_AMOUNT  = NVL(T.HAD_CASH_AMOUNT, 0) +
                                      I.LINE_AMOUNT,
                 T.LAST_UPDATED_BY  = P_USER_ID,--'自动计算',
                 T.LAST_UPDATE_DATE = SYSDATE
           WHERE T.ROWID = I.A_ROWID;
          --Y单行表置 返利单据号 字段
          UPDATE T_POL_ORDER_LINES T
             SET T.DISCOUNT_ORDER_NUMBER = V_DISCOUNT_ORDER_NUMBER,
                 T.LAST_UPDATED_BY       = P_USER_ID,--'自动计算',
                 T.CHANGED_CASH_FLAG     = 'Y',
                 T.LAST_UPDATE_DATE      = SYSDATE
           WHERE T.ROWID = I.B_ROWID;

        EXCEPTION WHEN OTHERS THEN
          ROLLBACK TO ROLLBACK_HERE;
          P_MESSAGE := '错误代码：' || SQLCODE || V_NL || '错误信息：' || SQLERRM ;
          RETURN ;
        END ;
        --修改计数器
        V_COUNT := V_COUNT + 1 ;
    END LOOP ;

    IF V_COUNT <= 0 THEN
       ROLLBACK TO ROLLBACK_HERE;
       P_MESSAGE :=  '错误信息：根据Y单行ID查不到相应的的Y单信息，请检查！' ;
       RETURN ;
    ELSIF V_COUNT > 1 THEN
       ROLLBACK TO ROLLBACK_HERE;
       P_MESSAGE :=  '错误信息：根据Y单行ID查到多于一条的Y单信息，请检查！' ;
       RETURN ;
    END IF;
    --COMMIT ;
  END P_POLICY_Y_TO_F ;


  -----------------------------------------------------------------------------
  -- 释放预算(关闭Y单)&占用预算(取消关闭Y单)                             --
  -----------------------------------------------------------------------------
  PROCEDURE P_CLOSE_BUDGET(P_POLICY_ORDER_ID        IN NUMBER   --返利申请ID
                          ,P_USER_ID                IN NUMBER   --用户ID
                          ,P_ISCLOSE                IN VARCHAR2 --是否关闭
                          ,P_MESSAGE               OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
                          ) IS
    V_AMOUNT_TEMP         NUMBER;
    --V_POLICY_ORDER_NUMBER  VARCHAR2(100);
    --V_CLOSE_FLAG  VARCHAR2(10);
    V_HAD_CASH_AMOUNT NUMBER;
    V_LINE_CASH_AMOUNT NUMBER;
    V_OPERATION_TYPE   VARCHAR2(30);
    --C_POL_POLICY T_POL_POLICY%ROWTYPE ;
    V_RESULT      VARCHAR2(1000); --反馈信息
    V_POLICY_ID       NUMBER;
    V_USER_ACCOUNT VARCHAR2(32);

    CURSOR C_POLICY_LINE IS
      SELECT PH.HAD_CASH_AMOUNT
            ,PH.POLICY_AMOUNT
            ,PH.ENTITY_ID
            ,PC.DATA_FLOW_ID
            ,PC.POLICY_NUMBER
            ,PL.BUDGET_SEGMENT_01_ID
            ,PL.BUDGET_SEGMENT_02_ID
            ,PL.BUDGET_SEGMENT_03_ID
            ,PL.BUDGET_SEGMENT_04_ID
            ,PL.BUDGET_SEGMENT_05_ID
            ,PL.BUDGET_SEGMENT_06_ID
            ,PH.SOURCE_ID DETAIL_ID
        FROM T_POL_ORDER_HEADERS PH, T_POL_POLICY PC, T_POL_POLICY_LINE PL
       WHERE PH.POLICY_ORDER_ID = P_POLICY_ORDER_ID
         AND PH.POLICY_ID = PC.POLICY_ID
         AND PC.POLICY_ID = PL.POLICY_ID
         AND PH.SOURCE_ID = PL.DETAIL_ID;
    R_POLICY_LINE C_POLICY_LINE%ROWTYPE;

  BEGIN
    P_MESSAGE := 'SUCCESS';
    V_RESULT  := 'SUCCESS';

    SAVEPOINT SP_CLOSE_BUDGET;
    BEGIN
      SELECT NVL(HAD_CASH_AMOUNT, 0), POLICY_ID
        INTO V_HAD_CASH_AMOUNT, V_POLICY_ID
        FROM T_POL_ORDER_HEADERS
       WHERE POLICY_ORDER_ID = P_POLICY_ORDER_ID
         FOR UPDATE NOWAIT;
    EXCEPTION
      WHEN OTHERS THEN
        V_RESULT  := '其它用户在操作该单据,不能进行操作!' || SQLERRM;
        P_MESSAGE := V_RESULT;
    END;

/*
    IF (V_RESULT = 'SUCCESS') THEN
      SELECT COUNT(PH.POLICY_ORDER_ID)
        INTO V_COUNT
        FROM T_POL_ORDER_HEADERS PH
       WHERE PH.POLICY_ORDER_ID = P_POLICY_ORDER_ID
         AND PH.CLOSE_FLAG = P_ISCLOSE;
    
      IF V_COUNT > 0 THEN
        IF P_ISCLOSE = 'Y' THEN
          V_RESULT := '该批文已经关闭,不能再进行操作！' || SQLERRM;
        ELSIF P_ISCLOSE = 'N' THEN
          V_RESULT := '该批文已经撤销关闭,不能再进行操作！' || SQLERRM;
        END IF;
        P_MESSAGE := V_RESULT;
      END IF;
    END IF;
*/

    IF (V_RESULT = 'SUCCESS') THEN
      BEGIN
        SELECT SUM(NVL(PL.LINE_AMOUNT, 0))
          INTO V_LINE_CASH_AMOUNT
          FROM T_POL_ORDER_LINES PL
         WHERE PL.POLICY_ORDER_ID = P_POLICY_ORDER_ID
           AND NVL(PL.SPLIT_ORDER, 'N') = 'N'
           AND NVL(PL.CHANGED_CASH_FLAG, 'N') = 'Y';
      EXCEPTION
        WHEN OTHERS THEN
          V_LINE_CASH_AMOUNT := 0;
      END;

      IF NVL(V_LINE_CASH_AMOUNT,0) <> NVL(V_HAD_CASH_AMOUNT,0) THEN
        V_RESULT := '返利申请头上的已转返利金额与行上返利标识为‘是’的兑现金额之和不一致，请先保存一下Y单！';
        P_MESSAGE := V_RESULT;
      END IF;
    END IF;

    IF (V_RESULT = 'SUCCESS') THEN
      OPEN C_POLICY_LINE;
      LOOP
        FETCH C_POLICY_LINE
         INTO R_POLICY_LINE;

        EXIT WHEN C_POLICY_LINE%NOTFOUND;

        IF R_POLICY_LINE.DATA_FLOW_ID <> 0 THEN
          IF (P_ISCLOSE = 'Y') THEN
            V_AMOUNT_TEMP := -(R_POLICY_LINE.POLICY_AMOUNT-NVL(R_POLICY_LINE.HAD_CASH_AMOUNT, 0));
            V_OPERATION_TYPE := '关闭Y单';
          ELSIF (P_ISCLOSE = 'N')  THEN
            V_AMOUNT_TEMP := R_POLICY_LINE.POLICY_AMOUNT-NVL(R_POLICY_LINE.HAD_CASH_AMOUNT, 0);
            V_OPERATION_TYPE := '取消关闭Y单';
          END IF;

          -----调用预算的过程
          --释放预算
          IF(P_MESSAGE = 'SUCCESS' )THEN
             PKG_BUDGET.P_WRITE_FEE(R_POLICY_LINE.DATA_FLOW_ID,
                                    R_POLICY_LINE.ENTITY_ID,
                                    NVL(R_POLICY_LINE.BUDGET_SEGMENT_01_ID, -1),
                                    NVL(R_POLICY_LINE.BUDGET_SEGMENT_02_ID, -1),
                                    NVL(R_POLICY_LINE.BUDGET_SEGMENT_03_ID, -1),
                                    NVL(R_POLICY_LINE.BUDGET_SEGMENT_04_ID, -1),
                                    NVL(R_POLICY_LINE.BUDGET_SEGMENT_05_ID, -1),
                                    NVL(R_POLICY_LINE.BUDGET_SEGMENT_06_ID, -1),
                                    V_OPERATION_TYPE,  --费用类型
                                    R_POLICY_LINE.DETAIL_ID,
                                    R_POLICY_LINE.POLICY_NUMBER,
                                    NULL,
                                    NULL,
                                    V_AMOUNT_TEMP ,
                                    P_USER_ID,
                                    P_MESSAGE);
          END IF;
        END IF;
      END LOOP;
    END IF;

    IF (P_MESSAGE = 'SUCCESS') THEN
      BEGIN
        SELECT T.ACCOUNT
          INTO V_USER_ACCOUNT
          FROM CIMS.UP_ORG_USER T
         WHERE T.USER_ID = P_USER_ID;
      EXCEPTION
        WHEN OTHERS THEN
          V_USER_ACCOUNT := NULL;   
      END;
      
      UPDATE T_POL_POLICY PC
        SET PC.CLOSE_DATE = SYSDATE,
            PC.CLOSED_BY = NVL(V_USER_ACCOUNT, P_USER_ID),
            PC.LAST_UPDATED_BY = NVL(V_USER_ACCOUNT, P_USER_ID),
            PC.LAST_UPDATE_DATE = SYSDATE,
            PC.VERSION = PC.VERSION + 1
      WHERE PC.POLICY_ID = V_POLICY_ID;
    END IF;

  EXCEPTION
      WHEN OTHERS THEN
        P_MESSAGE := SQLERRM;
        ROLLBACK TO SP_CLOSE_BUDGET;
        RETURN;
  END P_CLOSE_BUDGET;


  --计算政策返利报表数据,写入报表临时表(T_POL_DISCOUNT_DIGEST_REPORT)
  PROCEDURE P_AUTO_CAL_DISCOUNT_REPORT(P_MESSAGE OUT VARCHAR2) IS
    ITEM_CODE           VARCHAR2(30);   --项目名称
    LAST_MONTH_DISCOUNT_SALES NUMBER;   --上月销售折让
    LAST_YEAR_DISCOUNT_SALES NUMBER;    --年初余额(销售折让)
    EARLY_BANLANCE  NUMBER;             --月初余额
    LAST_MONTH_EARLY_BANLANCE NUMBER;   --上个月未结算的金额
    LAST_MONTH_DEDUCTION_DISCOUNT NUMBER;  --上月扣率折让
    DIGESTION_PERIOD NUMBER;               --本期消化
    CURRENT_ACCOUNT NUMBER;                --本期上账
    END_BALANCE NUMBER;                    --月末余额
    CUMULATIVE_DIGEST  NUMBER;             --累计消化
    CUMULATIVE_ACCOUNT NUMBER;             --累计上账
    CUMULATIVE_BALANCE NUMBER;             --累计余额

    LAST_YEAR_DEDUCTION_DISCOUNT NUMBER; --年初余额(扣率折让)
    LAST_YEAR_FREEZE_AMOUNT NUMBER;      --客户冻结余额
    LAST_MONTH_FREEZE_AMOUNT NUMBER;     --上个月最后一天折让金额
    UNSETTLED_DEDUCTION_AMOUNT NUMBER;   --未结算的金额

    STATISTICS_TIME VARCHAR2(30);        --统计时间

    CURSOR C_SO_HEADER IS
      SELECT PA.*, PB.AMOUNT
        FROM T_SO_HEADER PA
            ,(SELECT MIN(PL.SO_HEADER_ID) AS SO_HEADER_ID
                    ,MIN(PL.BIZ_SRC_BILL_TYPE_CODE) AS BIZ_SRC_BILL_TYPE_CODE
                    ,SUM(PL.DISCOUNT_AMOUNT) AS AMOUNT
                    ,PL.ACCOUNT_ID
                FROM T_SO_HEADER PL
               GROUP BY PL.ACCOUNT_ID, PL.BIZ_SRC_BILL_TYPE_CODE) PB
       WHERE PA.SO_HEADER_ID = PB.SO_HEADER_ID
         AND PA.SO_DATE BETWEEN
             (SELECT ADD_MONTHS(LAST_DAY(ADD_MONTHS(SYSDATE, -1)) + 1, -1)
                FROM DUAL) AND
             (SELECT LAST_DAY(ADD_MONTHS(SYSDATE, -1)) FROM DUAL);

    R_SO_HEADER C_SO_HEADER%ROWTYPE;

  BEGIN
       P_MESSAGE := 'OK';

       BEGIN
       SELECT TO_CHAR(SYSDATE,'YYYY-MM')
         INTO STATISTICS_TIME
         FROM DUAL;
       END;

       BEGIN
         DELETE FROM T_POL_DISCOUNT_DIGEST_REPORT PL WHERE PL.STATISTICS_TIME = STATISTICS_TIME;
       END;

      OPEN C_SO_HEADER;
      LOOP
        FETCH C_SO_HEADER
         INTO R_SO_HEADER;
        EXIT WHEN C_SO_HEADER%NOTFOUND;


        ---------------------------------------------------------------
        --销售折让
        ---------------------------------------------------------------
        IF(R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE = '1005' OR
           R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE = '1006')THEN

           ITEM_CODE := '销售折让';

            ----年初余额(销售折让)
            SELECT NVL(SUM(SA.SETTLE_AMOUNT), 0)
              INTO LAST_MONTH_DISCOUNT_SALES
              FROM T_SO_HEADER SA
             WHERE SA.ACCOUNT_ID = R_SO_HEADER.ACCOUNT_ID
               AND SA.BIZ_SRC_BILL_TYPE_CODE IN ('1005','1006')
               AND SA.SETTLE_FLAG = 'N'
               AND SA.SO_DATE BETWEEN (SELECT ADD_MONTHS(TRUNC(SYSDATE,'YYYY'),-12) FROM DUAL)
               AND (SELECT LAST_DAY(ADD_MONTHS(TRUNC(SYSDATE, 'YYYY'), -1)) FROM DUAL);

            --月初余额
             --上个年度
             BEGIN
             SELECT NVL(SUM(PL.DISCOUNT_AMOUNT), 0)
               INTO EARLY_BANLANCE
               FROM T_SO_HEADER PL
              WHERE PL.ACCOUNT_ID = R_SO_HEADER.ACCOUNT_ID
                AND PL.BIZ_SRC_BILL_TYPE_CODE IN ('1005','1006')
                AND PL.SO_DATE BETWEEN (SELECT ADD_MONTHS(TRUNC(SYSDATE,'YYYY'),-12) FROM DUAL)
                AND (SELECT LAST_DAY(ADD_MONTHS(TRUNC(SYSDATE, 'YYYY'), -1)) FROM DUAL);
                END;

              BEGIN
                SELECT NVL(SUM(PL.DISCOUNT_AMOUNT), 0)
                  INTO LAST_MONTH_EARLY_BANLANCE
                  FROM T_SO_HEADER PL
                 WHERE PL.BIZ_SRC_BILL_TYPE_CODE IN ('1005','1006')
                   AND PL.SO_DATE BETWEEN (SELECT ADD_MONTHS(LAST_DAY(ADD_MONTHS(SYSDATE,-1))+1,-1) FROM DUAL)
                   AND (SELECT LAST_DAY(ADD_MONTHS(SYSDATE,-1)) FROM DUAL);
              END;

              EARLY_BANLANCE := EARLY_BANLANCE + LAST_MONTH_EARLY_BANLANCE;

              --本期上账
              CURRENT_ACCOUNT := NULL;

              --本期消化
              BEGIN
              SELECT NVL(SUM(PL.DISCOUNT_AMOUNT), 0)
                INTO DIGESTION_PERIOD
                FROM T_SO_HEADER PL
               WHERE PL.ACCOUNT_ID = R_SO_HEADER.ACCOUNT_ID
                 AND PL.BIZ_SRC_BILL_TYPE_CODE IN ('1005','1006')
                 AND PL.SETTLE_DATE BETWEEN (SELECT ADD_MONTHS(TRUNC(SYSDATE,'YYYY'),-1) FROM DUAL)
                 AND SYSDATE;
                END;

              --月末余额
              END_BALANCE := EARLY_BANLANCE + CURRENT_ACCOUNT - DIGESTION_PERIOD;

              --累计上账
              CUMULATIVE_ACCOUNT := NULL;

              --累计消化
              CUMULATIVE_DIGEST := NULL;

              --累计余额
              CUMULATIVE_BALANCE := NULL;
          END IF;


        ---------------------------------------------------------------
        ----扣率折让
        ---------------------------------------------------------------
        IF(R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE = '1009' OR
           R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE = '1010')THEN

           ITEM_CODE := '扣率折让';

             --冻结
            SELECT NVL(SUM(T.DISCOUNT_AMOUNT), 0)
            INTO  LAST_YEAR_FREEZE_AMOUNT
              FROM T_SALES_AMOUNT_FREEZE T
             WHERE T.ACCOUNT_ID = R_SO_HEADER.ACCOUNT_ID
               AND T.FREEZE_DATE =
                   (SELECT LAST_DAY(ADD_MONTHS(TRUNC(SYSDATE, 'YYYY'), -1)) FROM DUAL);

              --未结算的扣率折让
             SELECT NVL(SUM(SA.DISCOUNT_AMOUNT), 0)
             INTO UNSETTLED_DEDUCTION_AMOUNT
             FROM T_SO_HEADER SA
             WHERE SA.BIZ_SRC_BILL_TYPE_CODE IN ('1009','1010')
               AND SA.SETTLE_FLAG = 'N'
               AND SA.ACCOUNT_ID = R_SO_HEADER.ACCOUNT_ID;

             --年初余额(扣率折让)  冻结+未结算的扣率折让
             LAST_MONTH_DISCOUNT_SALES := LAST_YEAR_FREEZE_AMOUNT + UNSETTLED_DEDUCTION_AMOUNT;

             --月初余额
             BEGIN
               SELECT NVL(SUM(PL.DISCOUNT_AMOUNT), 0)
                 INTO LAST_MONTH_FREEZE_AMOUNT
                 FROM T_SALES_AMOUNT_FREEZE PL
                WHERE PL.ACCOUNT_ID = R_SO_HEADER.ACCOUNT_ID
                  AND PL.FREEZE_DATE =
                      (SELECT LAST_DAY(ADD_MONTHS(SYSDATE,-1)) FROM DUAL);
             END;

             BEGIN
               SELECT NVL(SUM(PL.DISCOUNT_AMOUNT), 0)
                 INTO UNSETTLED_DEDUCTION_AMOUNT
                 FROM T_SO_HEADER PL
                WHERE PL.BIZ_SRC_BILL_TYPE_CODE IN ('1009','1010')
                  AND PL.SETTLE_FLAG = 'N';
             END;

             EARLY_BANLANCE := LAST_MONTH_FREEZE_AMOUNT + UNSETTLED_DEDUCTION_AMOUNT;


             --本期上账
             BEGIN
               SELECT NVL(SUM(PB.DISCOUNT_AMOUNT), 0)
                 INTO CURRENT_ACCOUNT
                 FROM T_POL_DISCOUNT_ORDER PA,
                      T_POL_DISCOUNT_LINES PB
                WHERE PA.DISCOUNT_ORDER_ID = PB.DISCOUNT_ORDER_ID
                  AND PA.DISCOUNT_METHOD = '1'
                  AND PA.ORDERED_DATE BETWEEN (SELECT ADD_MONTHS(TRUNC(SYSDATE,'YYYY'),-1) FROM DUAL)
                  AND SYSDATE;
             END;

             --本期消化
             BEGIN
               SELECT NVL(SUM(PL.DISCOUNT_AMOUNT), 0)
                 INTO DIGESTION_PERIOD
                 FROM T_SO_HEADER PL
                WHERE PL.BIZ_SRC_BILL_TYPE_CODE IN ('1009','1010')
                  AND PL.SETTLE_FLAG = 'Y'
                  AND PL.SETTLE_DATE BETWEEN (SELECT ADD_MONTHS(TRUNC(SYSDATE,'YYYY'),-1) FROM DUAL)
                  AND SYSDATE;
             END;

             --月末余额
             END_BALANCE := EARLY_BANLANCE + CURRENT_ACCOUNT - DIGESTION_PERIOD;

             --累计上账
             BEGIN
               SELECT NVL(SUM(PB.DISCOUNT_AMOUNT), 0)
                 INTO CUMULATIVE_ACCOUNT
                 FROM T_POL_DISCOUNT_ORDER PA,
                      T_POL_DISCOUNT_LINES PB
                WHERE PA.DISCOUNT_ORDER_ID = PB.DISCOUNT_ORDER_ID
                  AND PA.DISCOUNT_METHOD = '1';
             END;

             --累计消化
             BEGIN
                SELECT NVL(SUM(PL.DISCOUNT_AMOUNT), 0)
                  INTO CUMULATIVE_DIGEST
                  FROM T_SO_HEADER PL
                 WHERE PL.ACCOUNT_ID = R_SO_HEADER.ACCOUNT_ID
                   AND PL.BIZ_SRC_BILL_TYPE_CODE IN ('1009','1010');
             END;

             --累计余额
             CUMULATIVE_BALANCE := CUMULATIVE_ACCOUNT - CUMULATIVE_DIGEST;
         END IF;



         ---------------------------------------------------------------
         -----折让证明
         ---------------------------------------------------------------
        IF(R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE = '1007' OR
           R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE = '1008')THEN

           ITEM_CODE := '折让证明';

           --年初余额(折让证明)
           SELECT NVL(SUM(SA.SETTLE_AMOUNT), 0)
            INTO  LAST_MONTH_DISCOUNT_SALES
            FROM  T_SO_HEADER SA
            WHERE SA.ACCOUNT_ID = R_SO_HEADER.ACCOUNT_ID
              AND SA.BIZ_SRC_BILL_TYPE_CODE IN ('1007','1008')
              AND SA.SETTLE_FLAG = 'N'
              AND SA.SO_DATE BETWEEN (SELECT ADD_MONTHS(TRUNC(SYSDATE,'YYYY'),-12) FROM DUAL)
              AND (SELECT LAST_DAY(ADD_MONTHS(TRUNC(SYSDATE, 'YYYY'), -1)) FROM DUAL);

            --月初余额
            --上个年度
             BEGIN
             SELECT NVL(SUM(PL.DISCOUNT_AMOUNT), 0)
               INTO EARLY_BANLANCE
               FROM T_SO_HEADER PL
              WHERE PL.ACCOUNT_ID = R_SO_HEADER.ACCOUNT_ID
                AND PL.BIZ_SRC_BILL_TYPE_CODE IN ('1007','1008')
                AND PL.SO_DATE BETWEEN (SELECT ADD_MONTHS(TRUNC(SYSDATE,'YYYY'),-12) FROM DUAL)
                AND (SELECT LAST_DAY(ADD_MONTHS(TRUNC(SYSDATE, 'YYYY'), -1)) FROM DUAL);
                END;

              BEGIN
                SELECT NVL(SUM(PL.DISCOUNT_AMOUNT), 0)
                  INTO LAST_MONTH_EARLY_BANLANCE
                  FROM T_SO_HEADER PL
                 WHERE PL.BIZ_SRC_BILL_TYPE_CODE IN ('1007','1008')
                   AND PL.SO_DATE BETWEEN (SELECT ADD_MONTHS(LAST_DAY(ADD_MONTHS(SYSDATE,-1))+1,-1) FROM DUAL)
                   AND (SELECT LAST_DAY(ADD_MONTHS(SYSDATE,-1)) FROM DUAL);
              END;

              EARLY_BANLANCE := EARLY_BANLANCE + LAST_MONTH_EARLY_BANLANCE;

            --本期上账
           CURRENT_ACCOUNT := NULL;

           --本期消化
           BEGIN
               SELECT NVL(SUM(PL.DISCOUNT_AMOUNT), 0)
                 INTO DIGESTION_PERIOD
                 FROM T_SO_HEADER PL
                WHERE PL.BIZ_SRC_BILL_TYPE_CODE IN ('1007','1008')
                  AND PL.SETTLE_FLAG = 'Y'
                  AND PL.SETTLE_DATE BETWEEN (SELECT ADD_MONTHS(TRUNC(SYSDATE,'YYYY'),-1) FROM DUAL)
                  AND SYSDATE;
             END;

           --月末余额
           END_BALANCE := EARLY_BANLANCE + CURRENT_ACCOUNT - DIGESTION_PERIOD;

           --累计上账
           CUMULATIVE_ACCOUNT := NULL;

           --累计上账
           CUMULATIVE_ACCOUNT := NULL;

           --累计消化
           CUMULATIVE_DIGEST := NULL;

           --累计余额
           CUMULATIVE_BALANCE := NULL;


         END IF;


          INSERT INTO T_POL_DISCOUNT_DIGEST_REPORT
          (
                REPORT_ID,
                ITEM_NAME,                   --项目
                BEGIN_BALANCE,               --年初余额
                EARLY_BALANCE,               --月初余额
                CURRENT_ACCOUNT,             --本期上账
                CURRENT_DIGEST,              --本期消化
                END_BALANCE,                 --月末余额
                CUMULATIVE_ACCOUNT,          --累计上账
                CUMULATIVE_DIGEST,           --累计消化
                CUMULATIVE_BALANCE,          --累计余额
                STATISTICS_TIME,             --统计时间
                CUSTOMER_ID,                 --客户id
                CUSTOMER_CODE,               --客户编码
                CUSTOMER_NAME,               --客户名称
                SALES_CENTER_ID,             --营销中心id
                SALES_CENTER_CODE,           --营销中心编码
                SALES_CENTER_NAME            --营销中心名称
          )VALUES(
                S_POL_DISCOUNT_DIGEST_REPORT.NEXTVAL,
                ITEM_CODE,                       --项目
                LAST_MONTH_DISCOUNT_SALES,       --年初余额
                EARLY_BANLANCE,                  --月初余额
                CURRENT_ACCOUNT,                 --本期上账
                DIGESTION_PERIOD,                --本期消化
                END_BALANCE,                     --月末余额
                CUMULATIVE_ACCOUNT,              --累计上账
                CUMULATIVE_DIGEST,               --累计消化
                CUMULATIVE_BALANCE,              --累计余额
                STATISTICS_TIME,                 --统计时间
                R_SO_HEADER.CUSTOMER_ID,         --客户id
                R_SO_HEADER.CUSTOMER_CODE,       --客户编码
                R_SO_HEADER.CUSTOMER_NAME,       --客户名称
                R_SO_HEADER.SALES_CENTER_ID,     --营销中心id
                R_SO_HEADER.SALES_CENTER_CODE,   --营销中心编码
                R_SO_HEADER.SALES_CENTER_NAME    --营销中心名称
          );

        END LOOP;
  END;


  --检查预算节点是否存在
  PROCEDURE P_CHECK_BUDGET_NODE(P_DATA_FLOW_ID  IN NUMBER
                               ,P_ENTITY_ID     IN NUMBER
                               ,P_BUDGET_SEGMENT_1_ID IN NUMBER
                               ,P_BUDGET_SEGMENT_2_ID IN NUMBER
                               ,P_BUDGET_SEGMENT_3_ID IN NUMBER
                               ,P_BUDGET_SEGMENT_4_ID IN NUMBER
                               ,P_BUDGET_SEGMENT_5_ID IN NUMBER
                               ,P_BUDGET_SEGMENT_6_ID IN NUMBER
                               ,P_MESSAGE  OUT VARCHAR2) IS
    V_SELECT_TABLE  VARCHAR2(4000);
    V_SELECT_WHERE VARCHAR2(4000);
    V_SQL VARCHAR2(4000);
    V_COUNT NUMBER;
  BEGIN
    P_MESSAGE := 'INIT';

    V_SELECT_TABLE := 'SELECT COUNT(*) FROM CIMS.T_POL_BUDGET_TREE T WHERE T.DATA_FLOW_ID = ' || P_DATA_FLOW_ID
                     || ' AND T.ENTITY_ID = ' || P_ENTITY_ID
                     || ' AND T.BUDGET_SEGMENT_01_ID = ' || P_BUDGET_SEGMENT_1_ID;

    IF P_BUDGET_SEGMENT_2_ID IS NOT NULL THEN
      V_SELECT_WHERE :=  ' AND T.BUDGET_SEGMENT_02_ID =' || P_BUDGET_SEGMENT_2_ID;
    END IF;

    IF P_BUDGET_SEGMENT_3_ID IS NOT NULL THEN
      V_SELECT_WHERE := V_SELECT_WHERE || 'AND T.BUDGET_SEGMENT_03_ID = ' || P_BUDGET_SEGMENT_3_ID;
    END IF;

     IF P_BUDGET_SEGMENT_4_ID IS NOT NULL THEN
      V_SELECT_WHERE := V_SELECT_WHERE || 'AND T.BUDGET_SEGMENT_04_ID = ' || P_BUDGET_SEGMENT_4_ID;
    END IF;

     IF P_BUDGET_SEGMENT_5_ID IS NOT NULL THEN
      V_SELECT_WHERE := V_SELECT_WHERE || 'AND T.BUDGET_SEGMENT_05_ID = ' || P_BUDGET_SEGMENT_5_ID;
    END IF;

     IF P_BUDGET_SEGMENT_6_ID IS NOT NULL THEN
      V_SELECT_WHERE := V_SELECT_WHERE || 'AND T.BUDGET_SEGMENT_06_ID = ' || P_BUDGET_SEGMENT_6_ID;
    END IF;

    V_SQL :=  V_SELECT_TABLE || V_SELECT_WHERE;

    BEGIN
      EXECUTE IMMEDIATE V_SQL INTO V_COUNT;
      IF V_COUNT > 0 THEN
        P_MESSAGE := 'OK';
      END IF;
    END;

  END P_CHECK_BUDGET_NODE;


  --更新F单行上的产品信息
  PROCEDURE P_UPDATE_DIS_LINE_FOR_ITEM(P_LINE_ID          IN NUMBER
                                      ,P_ITEM_ID          IN NUMBER
                                      ,P_ITEM_CODE        IN VARCHAR2
                                      ,P_ITEM_NAME        IN VARCHAR2
                                      ,P_LAST_UPDATE_BY   IN VARCHAR2
                                      ,P_LAST_UPDATE_DATE IN DATE
                                      ,P_MESSAGE          OUT VARCHAR2) IS
  BEGIN
    P_MESSAGE := 'OK';
  
    UPDATE T_POL_DISCOUNT_LINES T
       SET T.ITEM_ID          = P_ITEM_ID
          ,T.ITEM_CODE        = P_ITEM_CODE
          ,T.ITEM_NAME        = P_ITEM_NAME
          ,T.LAST_UPDATED_BY  = P_LAST_UPDATE_BY
          ,T.LAST_UPDATE_DATE = P_LAST_UPDATE_DATE
     WHERE T.LINE_ID = P_LINE_ID;
  
  END P_UPDATE_DIS_LINE_FOR_ITEM;


  --梁颜明，20161226增加的存储过程：作废或关闭政策
  PROCEDURE P_DISCARD_POLICY(IN_POLICY_ID  IN NUMBER
                            ,IS_DISCARD_BY IN VARCHAR2
                            ,IS_ACTION     IN VARCHAR2  --R驳回（旧的工作流回调）、D作废、C关闭政策使用
                            ,OS_MESSAGE   OUT VARCHAR2) IS
    V_SRC_BILL_TYPE T_POL_POLICY.SRC_BILL_TYPE%TYPE; --来源单据类型
  BEGIN
    IF 'R' = IS_ACTION THEN--驳回也使用
/*      
      UPDATE T_POL_POLICY T
         SET T.STATUS           = '3'
            ,T.LAST_UPDATED_BY  = IS_DISCARD_BY
            ,T.LAST_UPDATE_DATE = SYSDATE
       WHERE T.POLICY_ID = IN_POLICY_ID;
*/
      P_OCCUPY_BUDGET(P_POLICY_ID => IN_POLICY_ID,
                      P_DIRECTION => 'N',
                      P_FLAG => 'Y',
                      P_MESSAGE => OS_MESSAGE);
      --P_MESSAGE返回OK，则更新状态为驳回（3）
      IF 'OK' = OS_MESSAGE THEN
        UPDATE T_POL_POLICY T
           SET T.STATUS = '3'
            --,T.LAST_UPDATED_BY = IS_DISCARD_BY
            --,T.LAST_UPDATE_DATE = SYSDATE
              ,T.VERSION = T.VERSION + 1
        WHERE T.POLICY_ID = IN_POLICY_ID;
      END IF;
    ELSE
      P_OCCUPY_BUDGET(P_POLICY_ID => IN_POLICY_ID,
                      P_DIRECTION => 'N',
                      P_FLAG => 'Y',
                      P_MESSAGE => OS_MESSAGE);
      --P_MESSAGE返回OK，则更新状态为作废（2）、更新作废人、作废时间
      IF 'OK' = OS_MESSAGE THEN
        IF IS_ACTION IS NULL OR 'D' = IS_ACTION THEN
          UPDATE T_POL_POLICY T
             SET T.STATUS       = '2'
                ,T.DISCARD_BY   = IS_DISCARD_BY
                ,T.DISCARD_DATE = SYSDATE
                ,T.VERSION      = T.VERSION + 1
           WHERE T.POLICY_ID = IN_POLICY_ID;
          --补亏政策和价差返利政策:
          --删除工程机批文合并关系，清空工程机批文上的政策ID和政策编码
          SELECT T.SRC_BILL_TYPE
            INTO V_SRC_BILL_TYPE
            FROM T_POL_POLICY T
           WHERE T.POLICY_ID = IN_POLICY_ID;
          IF V_SRC_BILL_TYPE = 'LOSS_POL' THEN
            DELETE FROM T_BD_PRICE_APPLY_MERGE_RELA R
             WHERE R.TAR_BILL_ID = IN_POLICY_ID
               AND R.TAR_BILL_TYPE = 'LOSS_POL';
            UPDATE T_BD_PRICE_APPLY A
               SET A.POLICY_ID = NULL, A.POLICY_NUMBER = NULL
             WHERE A.POLICY_NUMBER =
                   (SELECT T.POLICY_NUMBER
                      FROM T_POL_POLICY T
                     WHERE T.POLICY_ID = IN_POLICY_ID);
          ELSIF V_SRC_BILL_TYPE = 'MID_DIS_POL' THEN
            DELETE FROM T_BD_PRICE_APPLY_MERGE_RELA R
             WHERE R.TAR_BILL_ID = IN_POLICY_ID
               AND R.TAR_BILL_TYPE = 'MID_DIS_POL';
            UPDATE T_BD_PRICE_APPLY A
               SET A.POLICY_ID_02 = NULL, A.POLICY_NUMBER_02 = NULL
             WHERE A.POLICY_NUMBER_02 =
                   (SELECT T.POLICY_NUMBER
                      FROM T_POL_POLICY T
                     WHERE T.POLICY_ID = IN_POLICY_ID); 
          END IF;
        ELSIF 'C' = IS_ACTION THEN --暂时不使用
          UPDATE T_POL_POLICY T
             SET T.STATUS       = '7'
                ,T.DISCARD_BY   = IS_DISCARD_BY
                ,T.DISCARD_DATE = SYSDATE
                ,T.VERSION      = T.VERSION + 1
           WHERE T.POLICY_ID = IN_POLICY_ID;
        END IF;
      END IF;
    END IF;
  END P_DISCARD_POLICY;
  
  
  --政策提交时占用预算
  PROCEDURE P_OCCUPY_BUDGET(P_POLICY_ID IN NUMBER
                           ,P_DIRECTION IN VARCHAR2  --占用、释放预算标识：Y/N
                           ,P_FLAG      IN  VARCHAR2 --是否不校验政策状态标识：标识为“Y”，则不校验；标识不为“Y”，则政策状态为“已录入”和“已驳回”写预算，其它状态不写预算
                           ,P_MESSAGE  OUT VARCHAR2) IS
    P_USER_ID    NUMBER;
    V_RETURN_MESSAGE VARCHAR2(4000);
    P_AMOUNT NUMBER;
    P_STATUS VARCHAR2(32);
    V_CREATED_BY VARCHAR2(50);

    CURSOR C_POLICY_LINE IS
    --梁颜明，20161226，游标使用UNION ALL，前面两个UNION ALL是增加的（用于检查预算节点发生变化或者删除预算节点）
    --原来的由SQL关联条件改为LEFT JOIN ON的方式，并且由PL.*改为具体的字段，并且增加FEE_AMOUNT字段，
    --如果政策申请提交（正向）时，行的预算节点发生变化，需要释放原节点的预算
      --1.预算节点发生变化，需要释放原节点的预算
      SELECT PY.ENTITY_ID, PY.DATA_FLOW_ID, PY.POLICY_NUMBER, PL.DETAIL_ID,
             BT.BUDGET_SEGMENT_01_ID, BT.BUDGET_SEGMENT_02_ID, BT.BUDGET_SEGMENT_03_ID,
             BT.BUDGET_SEGMENT_04_ID, BT.BUDGET_SEGMENT_05_ID, BT.BUDGET_SEGMENT_06_ID,
             --预算节点发生变化，等同于申请预算为0
             0 AS POL_AMOUNT, SUM(BF.FEE_DETAIL_AMOUNT) AS FEE_AMOUNT
        FROM T_POL_POLICY PY
       INNER JOIN T_POL_POLICY_LINE PL
          ON (PY.POLICY_ID = PL.POLICY_ID)
       INNER JOIN T_POL_BUDGET_FEE_DETAIL BF
          ON (BF.ENTITY_ID = PY.ENTITY_ID AND BF.FEE_TYPE = '政策申请' AND
             BF.FEE_ID = PL.DETAIL_ID AND BF.FEE_CODE = PY.POLICY_NUMBER)
       INNER JOIN T_POL_BUDGET_TREE BT
          ON (BT.BUDGET_TREE_ID = BF.BUDGET_TREE_ID)
       --AND P_DIRECTION = 'Y'
       WHERE PY.POLICY_ID = P_POLICY_ID AND (PY.STATUS = '3' OR PY.STATUS = '5')
         AND (BT.BUDGET_SEGMENT_01_ID <> NVL(PL.BUDGET_SEGMENT_01_ID, -1)
          OR BT.BUDGET_SEGMENT_02_ID <> NVL(PL.BUDGET_SEGMENT_02_ID, -1)
          OR BT.BUDGET_SEGMENT_03_ID <> NVL(PL.BUDGET_SEGMENT_03_ID, -1)
          OR BT.BUDGET_SEGMENT_04_ID <> NVL(PL.BUDGET_SEGMENT_04_ID, -1)
          OR BT.BUDGET_SEGMENT_05_ID <> NVL(PL.BUDGET_SEGMENT_05_ID, -1)
          OR BT.BUDGET_SEGMENT_06_ID <> NVL(PL.BUDGET_SEGMENT_06_ID, -1))
       GROUP BY PY.ENTITY_ID,PY.DATA_FLOW_ID,PY.POLICY_NUMBER,PL.DETAIL_ID,
                BT.BUDGET_SEGMENT_01_ID,BT.BUDGET_SEGMENT_02_ID,BT.BUDGET_SEGMENT_03_ID,
                BT.BUDGET_SEGMENT_04_ID,BT.BUDGET_SEGMENT_05_ID,BT.BUDGET_SEGMENT_06_ID
      HAVING SUM(BF.FEE_DETAIL_AMOUNT) > 0
      
      --2.如果删除了预算行，也要释放被占有的预算
      UNION ALL
      SELECT PY.ENTITY_ID, PY.DATA_FLOW_ID, PY.POLICY_NUMBER, BF.FEE_ID AS DETAIL_ID,
             BT.BUDGET_SEGMENT_01_ID, BT.BUDGET_SEGMENT_02_ID, BT.BUDGET_SEGMENT_03_ID,
             BT.BUDGET_SEGMENT_04_ID, BT.BUDGET_SEGMENT_05_ID, BT.BUDGET_SEGMENT_06_ID,
             --删除了行，等同于申请预算为0
             0 AS POL_AMOUNT, SUM(BF.FEE_DETAIL_AMOUNT) AS FEE_AMOUNT
        FROM T_POL_POLICY PY
       INNER JOIN T_POL_BUDGET_FEE_DETAIL BF
          ON (BF.ENTITY_ID = PY.ENTITY_ID AND BF.FEE_TYPE = '政策申请' AND
             BF.FEE_CODE = PY.POLICY_NUMBER)
       INNER JOIN T_POL_BUDGET_TREE BT
          ON (BT.BUDGET_TREE_ID = BF.BUDGET_TREE_ID)
       WHERE PY.POLICY_ID = P_POLICY_ID AND (PY.STATUS = '3' OR PY.STATUS = '5')
         AND NOT EXISTS (SELECT 1
                FROM T_POL_POLICY_LINE PL
               WHERE PL.ENTITY_ID = PY.ENTITY_ID
                 AND PL.POLICY_ID = PY.POLICY_ID
                 AND PL.DETAIL_ID = BF.FEE_ID)
       GROUP BY PY.ENTITY_ID,PY.DATA_FLOW_ID,PY.POLICY_NUMBER,BF.FEE_ID,BT.BUDGET_SEGMENT_01_ID,
                BT.BUDGET_SEGMENT_02_ID,BT.BUDGET_SEGMENT_03_ID,BT.BUDGET_SEGMENT_04_ID,
                BT.BUDGET_SEGMENT_05_ID,BT.BUDGET_SEGMENT_06_ID
      HAVING SUM(BF.FEE_DETAIL_AMOUNT) > 0
      
      --3.仅修改预算金额，也要释放占用的预算
      UNION ALL
      SELECT PL.ENTITY_ID, PY.DATA_FLOW_ID, PY.POLICY_NUMBER, PL.DETAIL_ID, PL.BUDGET_SEGMENT_01_ID,
             PL.BUDGET_SEGMENT_02_ID, PL.BUDGET_SEGMENT_03_ID, PL.BUDGET_SEGMENT_04_ID,
             PL.BUDGET_SEGMENT_05_ID, PL.BUDGET_SEGMENT_06_ID, PL.POL_AMOUNT,
             SUM(
               (SELECT (
                   --如果更改了预算节点，并且要释放预算，相当于占有预算为0
                   CASE WHEN (BT.BUDGET_SEGMENT_01_ID <> NVL(PL.BUDGET_SEGMENT_01_ID, -1)
                              OR BT.BUDGET_SEGMENT_02_ID <> NVL(PL.BUDGET_SEGMENT_02_ID, -1)
                              OR BT.BUDGET_SEGMENT_03_ID <> NVL(PL.BUDGET_SEGMENT_03_ID, -1)
                              OR BT.BUDGET_SEGMENT_04_ID <> NVL(PL.BUDGET_SEGMENT_04_ID, -1)
                              OR BT.BUDGET_SEGMENT_05_ID <> NVL(PL.BUDGET_SEGMENT_05_ID, -1)
                              OR BT.BUDGET_SEGMENT_06_ID <> NVL(PL.BUDGET_SEGMENT_06_ID, -1))
                   THEN
                     0
                   ELSE
                     BF.FEE_DETAIL_AMOUNT
                   END
                 )
                FROM T_POL_BUDGET_TREE BT
               WHERE BT.BUDGET_TREE_ID = BF.BUDGET_TREE_ID
                 AND BT.ENTITY_ID = PY.ENTITY_ID
               )
             ) AS FEE_AMOUNT
        FROM T_POL_POLICY PY
        LEFT JOIN T_POL_POLICY_LINE PL
          ON (PY.POLICY_ID = PL.POLICY_ID)
        LEFT JOIN T_POL_BUDGET_FEE_DETAIL BF
          ON (BF.ENTITY_ID = PY.ENTITY_ID AND BF.FEE_TYPE = '政策申请' AND
             BF.FEE_ID = PL.DETAIL_ID AND BF.FEE_CODE = PY.POLICY_NUMBER)
       WHERE PY.POLICY_ID = P_POLICY_ID
       GROUP BY PL.ENTITY_ID,PY.DATA_FLOW_ID,PY.POLICY_NUMBER,PL.BUDGET_SEGMENT_01_ID,
                PL.BUDGET_SEGMENT_02_ID, PL.BUDGET_SEGMENT_03_ID,PL.BUDGET_SEGMENT_04_ID,
                PL.BUDGET_SEGMENT_05_ID,PL.BUDGET_SEGMENT_06_ID,PL.DETAIL_ID,PL.POL_AMOUNT;

    R_POLICY_LINE C_POLICY_LINE%ROWTYPE;

  BEGIN
    P_MESSAGE := 'OK';

    SELECT PP.STATUS, PP.CREATED_BY
      INTO P_STATUS, V_CREATED_BY
      FROM T_POL_POLICY PP
     WHERE PP.POLICY_ID = P_POLICY_ID;

    IF V_CREATED_BY IS NOT NULL THEN
      SELECT X.USER_ID
        INTO P_USER_ID
        FROM CIMS.UP_ORG_USER X
       WHERE X.ACCOUNT = V_CREATED_BY; --R_POLICY_LINE.CREATED_BY
    END IF;

    IF P_FLAG = 'Y' THEN
      GOTO TAO;
    END IF;

    --政策状态为“已录入”和“已驳回”写预算，其它状态不写预算
    IF P_STATUS <> 5 AND P_STATUS <> 3 THEN
      GOTO BREAK;
    END IF;

    <<TAO>>
    NULL;

    OPEN C_POLICY_LINE;
    LOOP
      --20161226，梁颜明 增加LP_HERE位置，预算没有变化时跳到此处
      <<LP_HERE>>
      FETCH C_POLICY_LINE
       INTO R_POLICY_LINE;

      EXIT WHEN C_POLICY_LINE%NOTFOUND;

      --20161226，梁颜明 START
      IF (P_DIRECTION = 'N') THEN
        IF R_POLICY_LINE.FEE_AMOUNT IS NULL OR 0 = R_POLICY_LINE.FEE_AMOUNT THEN --20161226，梁颜明 
          GOTO LP_HERE; --没有占用预算 --20161226，梁颜明 
        END IF; --20161226，梁颜明 
        P_AMOUNT := -R_POLICY_LINE.FEE_AMOUNT; --20161226，梁颜明
      ELSIF R_POLICY_LINE.FEE_AMOUNT IS NULL THEN --20161226，梁颜明 
        P_AMOUNT := R_POLICY_LINE.POL_AMOUNT; --20161226，梁颜明 
      ELSE
        P_AMOUNT := R_POLICY_LINE.POL_AMOUNT - R_POLICY_LINE.FEE_AMOUNT; --20161226，梁颜明 
        IF 0 = P_AMOUNT THEN --20161226，梁颜明 
          GOTO LP_HERE; --预算没有变化 20161226，梁颜明 
        END IF; --20161226，梁颜明 
      END IF;
      --20161226，梁颜明 END

      --占用预算
      IF(R_POLICY_LINE.DATA_FLOW_ID IS NOT NULL)THEN
         PKG_BUDGET.P_WRITE_FEE(R_POLICY_LINE.DATA_FLOW_ID,
                                R_POLICY_LINE.ENTITY_ID,
                                NVL(R_POLICY_LINE.BUDGET_SEGMENT_01_ID, -1),
                                NVL(R_POLICY_LINE.BUDGET_SEGMENT_02_ID, -1),
                                NVL(R_POLICY_LINE.BUDGET_SEGMENT_03_ID, -1),
                                NVL(R_POLICY_LINE.BUDGET_SEGMENT_04_ID, -1),
                                NVL(R_POLICY_LINE.BUDGET_SEGMENT_05_ID, -1),
                                NVL(R_POLICY_LINE.BUDGET_SEGMENT_06_ID, -1),
                                '政策申请', --费用类型
                                R_POLICY_LINE.DETAIL_ID,
                                R_POLICY_LINE.POLICY_NUMBER,
                                NULL,
                                NULL,
                                P_AMOUNT,
                                P_USER_ID,
                                V_RETURN_MESSAGE);

          IF V_RETURN_MESSAGE = 'SUCCESS' THEN
             P_MESSAGE := 'OK';
          ELSIF V_RETURN_MESSAGE IS NOT NULL THEN
             P_MESSAGE := V_RETURN_MESSAGE;
          END IF;
      END IF;

    END LOOP;
    CLOSE C_POLICY_LINE;
    
    --P_MESSAGE返回OK，才更新
    IF 'OK' = P_MESSAGE THEN
      --根据传进来的正向或反向标识，更新政策表占用预算标识
      IF (P_DIRECTION = 'N') THEN
        UPDATE T_POL_POLICY TA
           SET TA.BUDGET_FLAG   = 'N'
              ,VERSION          = 1 + NVL(VERSION, 0)
              ,LAST_UPDATE_DATE = SYSDATE
         WHERE TA.POLICY_ID = P_POLICY_ID;
      ELSE
       UPDATE T_POL_POLICY TA
          SET TA.BUDGET_FLAG   = 'Y'
             ,VERSION          = 1 + NVL(VERSION, 0)
             ,LAST_UPDATE_DATE = SYSDATE
        WHERE TA.POLICY_ID = P_POLICY_ID;
      END IF;
    END IF;

    <<BREAK>>
    NULL;
  END P_OCCUPY_BUDGET;


  --政策提交时检查预算
  PROCEDURE P_CHECK_BUDGET(P_POLICY_ID  IN NUMBER
                          ,P_MESSAGE   OUT VARCHAR2) IS
    --P_USER_ID  NUMBER;

    CURSOR C_POLICY_LINE(V_CTRL_BUDGET_FLAG_IN VARCHAR2) IS
    --梁颜明，20161226，原来的由SQL关联条件改为LEFT JOIN ON的方式，并且由PL.*改为具体的字段，并且增加FEE_AMOUNT字段
      WITH TT AS (
        SELECT * FROM (
          SELECT ENTITY_ID, DATA_FLOW_ID, POLICY_NUMBER, BUDGET_FLAG
            ,BUDGET_SEGMENT_01_ID, BUDGET_SEGMENT_02_ID
            ,BUDGET_SEGMENT_03_ID, BUDGET_SEGMENT_04_ID
            ,BUDGET_SEGMENT_05_ID, BUDGET_SEGMENT_06_ID
            ,DETAIL_ID, POL_AMOUNT
            ,SUM(FEE_DETAIL_AMOUNT) OVER (PARTITION BY ENTITY_ID,DATA_FLOW_ID,POLICY_NUMBER,BUDGET_FLAG
              ,BUDGET_SEGMENT_01_ID,BUDGET_SEGMENT_02_ID
              ,BUDGET_SEGMENT_03_ID,BUDGET_SEGMENT_04_ID
              ,BUDGET_SEGMENT_05_ID,BUDGET_SEGMENT_06_ID) AS FEE_AMOUNT
            ,ROW_NUMBER() OVER (PARTITION BY ENTITY_ID,DATA_FLOW_ID,POLICY_NUMBER,BUDGET_FLAG
              ,BUDGET_SEGMENT_01_ID,BUDGET_SEGMENT_02_ID
              ,BUDGET_SEGMENT_03_ID,BUDGET_SEGMENT_04_ID
              ,BUDGET_SEGMENT_05_ID,BUDGET_SEGMENT_06_ID ORDER BY DETAIL_ID DESC) AS RN
          FROM (
            SELECT PY.ENTITY_ID, PY.DATA_FLOW_ID, PY.POLICY_NUMBER, PY.BUDGET_FLAG
              ,PL.BUDGET_SEGMENT_01_ID, PL.BUDGET_SEGMENT_02_ID
              ,PL.BUDGET_SEGMENT_03_ID, PL.BUDGET_SEGMENT_04_ID
              ,PL.BUDGET_SEGMENT_05_ID, PL.BUDGET_SEGMENT_06_ID
              ,PL.DETAIL_ID, PL.POL_AMOUNT
              ,DECODE(BT.BUDGET_TREE_ID, NULL, 0, NVL(BF.FEE_DETAIL_AMOUNT, 0)) AS FEE_DETAIL_AMOUNT
              --,BF.FEE_DETAIL_AMOUNT
              --,BT.BUDGET_TREE_ID
              /*,(CASE WHEN (BT.BUDGET_SEGMENT_01_ID <> NVL(PL.BUDGET_SEGMENT_01_ID, -1) OR
                            BT.BUDGET_SEGMENT_02_ID <> NVL(PL.BUDGET_SEGMENT_02_ID, -1) OR
                            BT.BUDGET_SEGMENT_03_ID <> NVL(PL.BUDGET_SEGMENT_03_ID, -1) OR
                            BT.BUDGET_SEGMENT_04_ID <> NVL(PL.BUDGET_SEGMENT_04_ID, -1) OR
                            BT.BUDGET_SEGMENT_05_ID <> NVL(PL.BUDGET_SEGMENT_05_ID, -1) OR
                            BT.BUDGET_SEGMENT_06_ID <> NVL(PL.BUDGET_SEGMENT_06_ID, -1)) THEN 0 ELSE 1 END)
                            --是否是对应节点
                            AS EQ_FLAG*/
              --,MAX(PL.DETAIL_ID) AS DETAIL_ID, 
              --梁颜明 2018-3-28 由SUM(PL.POL_AMOUNT)改为
              /*SUM(NVL(( --如果更改了预算节点，并且要释放预算，相当于占有预算为0
                     CASE
                       WHEN (BT.BUDGET_SEGMENT_01_ID <> NVL(PL.BUDGET_SEGMENT_01_ID, -1) OR
                            BT.BUDGET_SEGMENT_02_ID <> NVL(PL.BUDGET_SEGMENT_02_ID, -1) OR
                            BT.BUDGET_SEGMENT_03_ID <> NVL(PL.BUDGET_SEGMENT_03_ID, -1) OR
                            BT.BUDGET_SEGMENT_04_ID <> NVL(PL.BUDGET_SEGMENT_04_ID, -1) OR
                            BT.BUDGET_SEGMENT_05_ID <> NVL(PL.BUDGET_SEGMENT_05_ID, -1) OR
                            BT.BUDGET_SEGMENT_06_ID <> NVL(PL.BUDGET_SEGMENT_06_ID, -1)) THEN
                        0
                       ELSE
                        PL.POL_AMOUNT
                     END),
                     0)) AS POL_AMOUNT
              ,SUM(NVL(( --如果更改了预算节点，并且要释放预算，相当于占有预算为0
                     CASE
                       WHEN (BT.BUDGET_SEGMENT_01_ID <> NVL(PL.BUDGET_SEGMENT_01_ID, -1) OR
                            BT.BUDGET_SEGMENT_02_ID <> NVL(PL.BUDGET_SEGMENT_02_ID, -1) OR
                            BT.BUDGET_SEGMENT_03_ID <> NVL(PL.BUDGET_SEGMENT_03_ID, -1) OR
                            BT.BUDGET_SEGMENT_04_ID <> NVL(PL.BUDGET_SEGMENT_04_ID, -1) OR
                            BT.BUDGET_SEGMENT_05_ID <> NVL(PL.BUDGET_SEGMENT_05_ID, -1) OR
                            BT.BUDGET_SEGMENT_06_ID <> NVL(PL.BUDGET_SEGMENT_06_ID, -1)) THEN
                        0
                       ELSE
                        BF.FEE_DETAIL_AMOUNT
                     END),
                     0)) AS FEE_AMOUNT*/
            FROM T_POL_POLICY PY
              INNER JOIN T_POL_POLICY_LINE PL ON (PY.POLICY_ID = PL.POLICY_ID)
              LEFT JOIN T_POL_BUDGET_FEE_DETAIL BF ON (BF.ENTITY_ID = PY.ENTITY_ID
                AND BF.FEE_TYPE = '政策申请' AND BF.FEE_ID = PL.DETAIL_ID
                AND BF.FEE_CODE = PY.POLICY_NUMBER)
              LEFT JOIN T_POL_BUDGET_TREE BT ON (BT.BUDGET_TREE_ID = BF.BUDGET_TREE_ID
                AND BT.ENTITY_ID = PY.ENTITY_ID
                AND NOT (BT.BUDGET_SEGMENT_01_ID <> NVL(PL.BUDGET_SEGMENT_01_ID, -1) OR
                         BT.BUDGET_SEGMENT_02_ID <> NVL(PL.BUDGET_SEGMENT_02_ID, -1) OR
                         BT.BUDGET_SEGMENT_03_ID <> NVL(PL.BUDGET_SEGMENT_03_ID, -1) OR
                         BT.BUDGET_SEGMENT_04_ID <> NVL(PL.BUDGET_SEGMENT_04_ID, -1) OR
                         BT.BUDGET_SEGMENT_05_ID <> NVL(PL.BUDGET_SEGMENT_05_ID, -1) OR
                         BT.BUDGET_SEGMENT_06_ID <> NVL(PL.BUDGET_SEGMENT_06_ID, -1))
              )
            WHERE PY.POLICY_ID = P_POLICY_ID
            --AND V_CTRL_BUDGET_FLAG_IN = 'N'
            /*GROUP BY PY.ENTITY_ID,PY.DATA_FLOW_ID,PY.POLICY_NUMBER,PY.BUDGET_FLAG
            ,PL.BUDGET_SEGMENT_01_ID,PL.BUDGET_SEGMENT_02_ID
            ,PL.BUDGET_SEGMENT_03_ID,PL.BUDGET_SEGMENT_04_ID
            ,PL.BUDGET_SEGMENT_05_ID,PL.BUDGET_SEGMENT_06_ID
            --,PL.DETAIL_ID,PL.POL_AMOUNT;*/
          )
        ) WHERE 1 = RN
      )
      SELECT TT.DATA_FLOW_ID, TT.POLICY_NUMBER, TT.ENTITY_ID, TT.BUDGET_FLAG
        ,NVL(TT.BUDGET_SEGMENT_01_ID, -1) BUDGET_SEGMENT_01_ID
        ,NVL(TT.BUDGET_SEGMENT_02_ID, -1) BUDGET_SEGMENT_02_ID
        ,NVL(TT.BUDGET_SEGMENT_03_ID, -1) BUDGET_SEGMENT_03_ID
        ,NVL(TT.BUDGET_SEGMENT_04_ID, -1) BUDGET_SEGMENT_04_ID
        ,NVL(TT.BUDGET_SEGMENT_05_ID, -1) BUDGET_SEGMENT_05_ID
        ,NVL(TT.BUDGET_SEGMENT_06_ID, -1) BUDGET_SEGMENT_06_ID
        ,TT.DETAIL_ID, TT.POL_AMOUNT, TT.FEE_AMOUNT
        FROM TT;
      /* 在PKG_BUDGET.P_CHECK_FEE方法中已经校验当前层到顶层的金额，故此处不用重复校验 xiaoxu 2019-07-22
      UNION --启用预算进度控制，从底层到顶层都要判断
      SELECT TT.DATA_FLOW_ID, TT.POLICY_NUMBER, TT.ENTITY_ID, TT.BUDGET_FLAG,
             TT.BUDGET_SEGMENT_01_ID,
             NVL(TT.BUDGET_SEGMENT_02_ID, -1) BUDGET_SEGMENT_02_ID,
             NVL(TT.BUDGET_SEGMENT_03_ID, -1) BUDGET_SEGMENT_03_ID,
             NVL(TT.BUDGET_SEGMENT_04_ID, -1) BUDGET_SEGMENT_04_ID,
             NVL(TT.BUDGET_SEGMENT_05_ID, -1) BUDGET_SEGMENT_05_ID,
             -1 BUDGET_SEGMENT_06_ID,
             TT.DETAIL_ID, TT.POL_AMOUNT, TT.FEE_AMOUNT
        FROM TT WHERE V_CTRL_BUDGET_FLAG_IN = 'Y'
      UNION
      SELECT TT.DATA_FLOW_ID, TT.POLICY_NUMBER, TT.ENTITY_ID, TT.BUDGET_FLAG,
             TT.BUDGET_SEGMENT_01_ID,
             NVL(TT.BUDGET_SEGMENT_02_ID,-1) BUDGET_SEGMENT_02_ID,
             NVL(TT.BUDGET_SEGMENT_03_ID,-1) BUDGET_SEGMENT_03_ID,
             NVL(TT.BUDGET_SEGMENT_04_ID,-1) BUDGET_SEGMENT_04_ID,
             -1 BUDGET_SEGMENT_05_ID,
             -1 BUDGET_SEGMENT_06_ID,
             TT.DETAIL_ID, TT.POL_AMOUNT, TT.FEE_AMOUNT    
        FROM TT WHERE V_CTRL_BUDGET_FLAG_IN = 'Y'
      UNION
      SELECT TT.DATA_FLOW_ID, TT.POLICY_NUMBER, TT.ENTITY_ID, TT.BUDGET_FLAG,
             TT.BUDGET_SEGMENT_01_ID,
             NVL(TT.BUDGET_SEGMENT_02_ID,-1) BUDGET_SEGMENT_02_ID,
             NVL(TT.BUDGET_SEGMENT_03_ID,-1) BUDGET_SEGMENT_03_ID,
             -1 BUDGET_SEGMENT_04_ID,
             -1 BUDGET_SEGMENT_05_ID,
             -1 BUDGET_SEGMENT_06_ID,
             TT.DETAIL_ID, TT.POL_AMOUNT, TT.FEE_AMOUNT         
        FROM TT WHERE V_CTRL_BUDGET_FLAG_IN = 'Y'
      UNION
      SELECT TT.DATA_FLOW_ID, TT.POLICY_NUMBER, TT.ENTITY_ID, TT.BUDGET_FLAG,
             TT.BUDGET_SEGMENT_01_ID,
             NVL(TT.BUDGET_SEGMENT_02_ID,-1) BUDGET_SEGMENT_02_ID,
             -1 BUDGET_SEGMENT_03_ID,
             -1 BUDGET_SEGMENT_04_ID,
             -1 BUDGET_SEGMENT_05_ID,
             -1 BUDGET_SEGMENT_06_ID,
             TT.DETAIL_ID,TT.POL_AMOUNT,TT.FEE_AMOUNT         
        FROM TT WHERE V_CTRL_BUDGET_FLAG_IN = 'Y'
      UNION
      SELECT TT.DATA_FLOW_ID, TT.POLICY_NUMBER, TT.ENTITY_ID, TT.BUDGET_FLAG,
             TT.BUDGET_SEGMENT_01_ID,
             -1 BUDGET_SEGMENT_02_ID,
             -1 BUDGET_SEGMENT_03_ID,
             -1 BUDGET_SEGMENT_04_ID,
             -1 BUDGET_SEGMENT_05_ID,
             -1 BUDGET_SEGMENT_06_ID,
             TT.DETAIL_ID, TT.POL_AMOUNT, TT.FEE_AMOUNT       
        FROM TT WHERE V_CTRL_BUDGET_FLAG_IN = 'Y';*/

    R_POLICY_LINE C_POLICY_LINE%ROWTYPE;

    V_LINE_SUM_AMOUNT   NUMBER;  --增加行汇总金额
    V_DATA_FLOW_ID      NUMBER;
    V_DOC_LAND_AMOUNT   NUMBER;
    V_CUST_SOURCE_FLAG  VARCHAR2(10);
    V_CUST_SUM_AMOUNT   NUMBER;
    V_TOTAL_BUDGET      NUMBER;
    V_ENTITY_ID         NUMBER;
    V_CTRL_BUDGET_FLAG  VARCHAR2(10);  --获取预算控制进度主体参数 20161213
    V_ITEM_DETAIL_APPLICATION_FLAG VARCHAR(10);
  BEGIN
    P_MESSAGE := 'SUCCESS';

    --有预算申请，获取头行表金额进行核对。
    BEGIN
      SELECT PC.DATA_FLOW_ID
            ,PC.DOC_LAND_AMOUNT
            ,NVL(PC.CUST_SOURCE_FLAG, 'N')
            ,PC.ENTITY_ID
	    ,NVL(PT.ITEM_DETAIL_APPLICATION_FLAG, 'N')
        INTO V_DATA_FLOW_ID
            ,V_DOC_LAND_AMOUNT
            ,V_CUST_SOURCE_FLAG
            ,V_ENTITY_ID
            ,V_ITEM_DETAIL_APPLICATION_FLAG
        FROM T_POL_POLICY PC, T_POL_TYPE PT
       WHERE PC.POLICY_ID = P_POLICY_ID
         AND PC.POLICY_TYPE_ID = PT.APPLY_TYPE_ID(+);
    EXCEPTION
      WHEN OTHERS THEN
        V_DATA_FLOW_ID := 0;
    END;

    IF V_DATA_FLOW_ID <> 0 THEN
      --获取是否控制预算进度的参数 20161213
      BEGIN
        PKG_BD.P_GET_PARAMETER_VALUE('CTRL_BUDGET_SCHE_FLAG', V_ENTITY_ID, NULL, NULL, V_CTRL_BUDGET_FLAG);
      EXCEPTION
        WHEN OTHERS THEN
          P_MESSAGE := '获取启用预算进度参数失败！';
      END;
      BEGIN
        SELECT SUM(NVL(PL.POL_AMOUNT, 0))
          INTO V_LINE_SUM_AMOUNT
          FROM T_POL_POLICY_LINE PL
         WHERE PL.POLICY_ID = P_POLICY_ID;
      EXCEPTION
        WHEN OTHERS THEN
          V_LINE_SUM_AMOUNT := 0;
      END;

      IF V_LINE_SUM_AMOUNT <> V_DOC_LAND_AMOUNT THEN
        P_MESSAGE := '有预算的政策申请，预算行汇总金额与头表金额不一致，请刷新数据核对！';
      END IF;
    END IF;

    IF (P_MESSAGE = 'SUCCESS') AND (V_CUST_SOURCE_FLAG = 'Y') THEN
      BEGIN
        SELECT NVL(SUM(PS.AMOUNT), 0)
          INTO V_CUST_SUM_AMOUNT
          FROM T_POL_POLICY_SOURCE PS
         WHERE PS.POLICY_ID = P_POLICY_ID;
      EXCEPTION
        WHEN OTHERS THEN
          V_CUST_SUM_AMOUNT := 0;
      END;

      IF V_DATA_FLOW_ID <> 0 THEN
        IF V_CUST_SUM_AMOUNT <> V_LINE_SUM_AMOUNT THEN
          P_MESSAGE := '客户资源申请，客户资源汇总金额与预算行金额不一致，请刷新数据核对！';
        END IF;
      ELSIF V_CUST_SUM_AMOUNT <> V_DOC_LAND_AMOUNT THEN
        P_MESSAGE := '无预算的政策申请，预算行汇总金额与头表金额不一致，请刷新数据核对！';
      END IF;
    END IF;
    
    IF(P_MESSAGE = 'SUCCESS') AND (V_ITEM_DETAIL_APPLICATION_FLAG = 'Y') THEN
      BEGIN
        SELECT NVL(SUM(PI.TOTAL_BUDGET), 0)
          INTO V_TOTAL_BUDGET
          FROM T_POL_ITEM_INFO PI
        WHERE PI.POLICY_ID = P_POLICY_ID;
      EXCEPTION
        WHEN OTHERS THEN
          V_TOTAL_BUDGET := 0; 
      END;
      
      IF V_DATA_FLOW_ID <> 0 THEN
        IF V_TOTAL_BUDGET <> V_LINE_SUM_AMOUNT THEN
          P_MESSAGE := '产品信息申请，产品信息申请汇总金额与预算行金额不一致，请刷新数据核对！';
        END IF;
      ELSIF V_TOTAL_BUDGET <> V_DOC_LAND_AMOUNT THEN
        P_MESSAGE := '无预算的政策申请，预算行汇总金额与头表金额不一致，请刷新数据核对！';
      END IF;
    END IF;
      

    OPEN C_POLICY_LINE(V_CTRL_BUDGET_FLAG);
    LOOP
      FETCH C_POLICY_LINE
       INTO R_POLICY_LINE;

      EXIT WHEN C_POLICY_LINE%NOTFOUND;

/*    IF R_POLICY_LINE.CREATED_BY IS NOT NULL THEN
         SELECT X.USER_ID
           INTO P_USER_ID
           FROM CIMS.UP_ORG_USER X
          WHERE X.ACCOUNT = R_POLICY_LINE.CREATED_BY;
      END IF;   */

      --检查预算
      IF (R_POLICY_LINE.DATA_FLOW_ID IS NOT NULL) THEN
        IF (P_MESSAGE = 'SUCCESS'
            --梁颜明，20161226，预算没有占用或者预算增多的才检查
            AND 0 < (R_POLICY_LINE.POL_AMOUNT - R_POLICY_LINE.FEE_AMOUNT))
        THEN
          PKG_BUDGET.P_CHECK_FEE(R_POLICY_LINE.DATA_FLOW_ID,
                                R_POLICY_LINE.ENTITY_ID,
                                NVL(R_POLICY_LINE.BUDGET_SEGMENT_01_ID, -1),
                                NVL(R_POLICY_LINE.BUDGET_SEGMENT_02_ID, -1),
                                NVL(R_POLICY_LINE.BUDGET_SEGMENT_03_ID, -1),
                                NVL(R_POLICY_LINE.BUDGET_SEGMENT_04_ID, -1),
                                NVL(R_POLICY_LINE.BUDGET_SEGMENT_05_ID, -1),
                                NVL(R_POLICY_LINE.BUDGET_SEGMENT_06_ID, -1),
                                '政策申请', --费用类型
                                R_POLICY_LINE.DETAIL_ID,
                                R_POLICY_LINE.POLICY_NUMBER,
                                NULL,
                                NULL,
                                --梁颜明，20161226，预算没有占用的部分或者预算增多的部分
                                R_POLICY_LINE.POL_AMOUNT - R_POLICY_LINE.FEE_AMOUNT,
                                --P_USER_ID,
                                1, --admin
                                P_MESSAGE);
        END IF;
      END IF;
    END LOOP;
    CLOSE C_POLICY_LINE;

  END P_CHECK_BUDGET;


  --Y转F工作流结束生成F单
  PROCEDURE P_CREATE_DISCOUNT_ORDER(P_POLICY_ORDER_ID  IN NUMBER
                                   ,P_APP_CODE         IN VARCHAR2
                                   ,P_MESSAGE  OUT VARCHAR2) IS
    P_USER_ID  NUMBER;
    V_DISCOUNT_ORDER_ID  T_POL_DISCOUNT_ORDER.DISCOUNT_ORDER_ID%TYPE ;
    V_DISCOUNT_ORDER_NUMBER  T_POL_DISCOUNT_ORDER.DISCOUNT_ORDER_NUMBER%TYPE ;
    V_NL             CONSTANT VARCHAR2(2) := CHR(13) || CHR(10); --换行
    S_ITEM_ID                 NUMBER;
    S_ITEM_CODE               VARCHAR2(100);
    S_ITEM_NAME               VARCHAR2(240);

    CURSOR C_POL_ORDER_LINES IS
      SELECT A.ENTITY_ID,
             A.POLICY_ORDER_ID,
             B.DISCOUNT_METHOD,   --折让方式
             A.DISCOUNT_PAY_DEPT, --折让支付来源
             A.DISCOUNT_ITEM,     --折让项目
             A.CONTROL_METHOD,
             A.MATERIAL_BRAND,
             B.SALES_MAIN_TYPE,   --取行上营销大类 2017-10-27
             /*A.SALES_CENTER_ID,
             A.SALES_CENTER_CODE,
             A.SALES_CENTER_NAME,*/
             B.SALES_CENTER_ID,
             B.SALES_CENTER_CODE,
             B.SALES_CENTER_NAME,
             A.INTEND_CASH_DATE,
             B.CUSTOMER_ID,
             B.CUSTOMER_CODE,
             B.CUSTOMER_NAME,
             B.ACCOUNT_ID,
             B.ACCOUNT_CODE,
             A.ROWID A_ROWID,
             B.LINE_AMOUNT,
             B.ROWID B_ROWID,
             B.LINE_ID,    --Y单行ID
             B.ITEM_ID,    --商品ID
             B.ITEM_CODE,  --商品编码
             B.ITEM_NAME,  --商品名称
             B.UOM_CODE,   --单位
             B.QUANTITY,   --数量
             B.LIST_PRICE, --价格
             B.CREATED_BY,
             A.POLICY_NUMBER,
             A.POLICY_ID,
             B.OU_ID,
             B.CALCULATE_GROUP_NAME,
             B.CALCULATE_GROUP_TYPE,
             B.DISCOUNT_PERIOD,
             B.REF_MODEL,
             B.TERMINAL_ID,
             B.TERMINAL_CODE,
             B.TERMINAL_NAME,
             B.IS_CREATED_BY_ITEM
        FROM T_POL_ORDER_HEADERS A, T_POL_ORDER_LINES B
       WHERE A.POLICY_ORDER_ID = B.POLICY_ORDER_ID
         AND B.APP_FLAG  = 'Y'
         AND B.APP_NUM = P_APP_CODE
         AND NVL(B.CHANGED_CASH_FLAG,'N') = 'N' --增加判断是否已转返利
         AND NVL(B.SPLIT_ORDER,'N') = 'N' --增加判断是否拆单
         AND B.LIST_PRICE <> 0 --兑现金额不能为零
         AND B.POLICY_ORDER_ID = P_POLICY_ORDER_ID;

    TYPE C_ITEM_INFO IS REF CURSOR;

  BEGIN
    P_MESSAGE := 'SUCCESS';
    SAVEPOINT ROLLBACK_HERE;

    FOR I IN C_POL_ORDER_LINES LOOP
      BEGIN
        --获取返利单ID
        SELECT S_POL_DISCOUNT_ORDER.NEXTVAL INTO V_DISCOUNT_ORDER_ID FROM DUAL ;
        --获取返利单据号
        V_DISCOUNT_ORDER_NUMBER := PKG_BD.F_GET_BILL_NO('POLDISCOUNT',NULL,I.ENTITY_ID,NULL) ;

        ----ADD BY HUTAO 2015-11-26 BEGIN
        BEGIN
          FOR C_ITEM_INFO IN (SELECT * FROM T_BD_ITEM T WHERE T.ENTITY_ID = I.ENTITY_ID AND T.IS_VIRTUAL = 'Y')
          LOOP
             IF C_ITEM_INFO.ITEM_CODE = 'Z0000000000001'
               AND (I.DISCOUNT_METHOD = 4 OR I.DISCOUNT_METHOD = 5)
             THEN
               S_ITEM_ID := C_ITEM_INFO.ITEM_ID;
               S_ITEM_CODE := C_ITEM_INFO.ITEM_CODE;
               S_ITEM_NAME := C_ITEM_INFO.ITEM_NAME;
             END IF;
                       
             IF C_ITEM_INFO.ITEM_CODE = 'Z0000000000002'
               AND (I.DISCOUNT_METHOD = 1 OR I.DISCOUNT_METHOD = 2 OR I.DISCOUNT_METHOD = 3 OR I.DISCOUNT_METHOD = 6 OR I.DISCOUNT_METHOD = 7)
             THEN
               S_ITEM_ID := C_ITEM_INFO.ITEM_ID;
               S_ITEM_CODE := C_ITEM_INFO.ITEM_CODE;
               S_ITEM_NAME := C_ITEM_INFO.ITEM_NAME;
             END IF;
          END LOOP;
        END;
        ----ADD BY HUTAO END

        INSERT INTO T_POL_DISCOUNT_ORDER(
          DISCOUNT_ORDER_ID,
          ENTITY_ID,
          POLICY_ID,
          POLICY_NUMBER,
          DISCOUNT_ORDER_NUMBER,
          OLD_DISCOUNT_ID,
          OLD_DISCOUNT_NUMBER,
          POLICY_ORDER_ID,
          ORDERED_DATE,
          ORDER_TYPE_ID,
          LINK_PIPE_FLAG,
          DISCOUNT_TYPE_ID,
          DISCOUNT_METHOD,
          DISCOUNT_PAY_DEPT,
          DISCOUNT_ITEM,
          PROJECT_CODE,
          PROJECT_DATE,
          PROJECT_FLAG,
          CONTROL_METHOD,
          BRAND_NAME,
          SALES_MAIN_TYPE,
          SALES_CENTER_ID,
          SALES_CENTER_CODE,
          SALES_CENTER_NAME,
          PRINT_FLAG,
          INTEND_CASH_DATE,
          CUSTOMER_ID,
          CUSTOMER_CODE,
          CUSTOMER_NAME,
          ACCOUNT_ID,
          ACCOUNT_CODE,
          OU_ID,
          STATUS,
          SALES_NUMBER,
          EMS_FLAG,
          EMS_APPLY_ID,
          VENDOR_SITE_ID,
          VENDOR_ID,
          COMPANY_ID,
          FEE_TYPE_ID,
          BUSIORGID,
          FEE_DETAIL_TYPE,
          FEE_MAIN_TYPE,
          REMARK,
          CREATED_BY,
          CREATION_DATE,
          LAST_UPDATED_BY,
          LAST_UPDATE_DATE,
          FROM_LINE_ID,
          CALCULATE_GROUP_NAME,
          CALCULATE_GROUP_TYPE,
          DISCOUNT_PERIOD,
          REF_MODEL,
          TERMINAL_ID,
          TERMINAL_CODE,
          TERMINAL_NAME,
          ITEM_SOURCE_TYPE)
        SELECT
          V_DISCOUNT_ORDER_ID DISCOUNT_ORDER_ID,
          I.ENTITY_ID ENTITY_ID,
          I.POLICY_ID,
          I.POLICY_NUMBER,
          V_DISCOUNT_ORDER_NUMBER DISCOUNT_ORDER_NUMBER,
          NULL OLD_DISCOUNT_ID,
          NULL OLD_DISCOUNT_NUMBER,
          I.POLICY_ORDER_ID POLICY_ORDER_ID,
          TRUNC(SYSDATE) ORDERED_DATE,  --单据日期，需要确认
          1 ORDER_TYPE_ID, --单据类型(1:正向，2：反向)
          NULL LINK_PIPE_FLAG,  --是否含配件
          NULL DISCOUNT_TYPE_ID,  --折扣类型
          I.DISCOUNT_METHOD DISCOUNT_METHOD,  --折让方式
          I.DISCOUNT_PAY_DEPT DISCOUNT_PAY_DEPT,  --折让支付来源
          I.DISCOUNT_ITEM DISCOUNT_ITEM,  --折让项目
          NULL PROJECT_CODE,  --工程机登录号
          NULL PROJECT_DATE,  --工程机登录时间
          NULL PROJECT_FLAG,  --是否收到工程机资料
          I.CONTROL_METHOD CONTROL_METHOD,
          I.MATERIAL_BRAND BRAND_NAME,
          I.SALES_MAIN_TYPE SALES_MAIN_TYPE,
          I.SALES_CENTER_ID SALES_CENTER_ID,
          I.SALES_CENTER_CODE SALES_CENTER_CODE,
          I.SALES_CENTER_NAME SALES_CENTER_NAME,
          NULL PRINT_FLAG,  --是否打印
          I.INTEND_CASH_DATE INTEND_CASH_DATE,
          I.CUSTOMER_ID CUSTOMER_ID,
          I.CUSTOMER_CODE CUSTOMER_CODE,
          I.CUSTOMER_NAME CUSTOMER_NAME,
          I.ACCOUNT_ID ACCOUNT_ID,
          I.ACCOUNT_CODE ACCOUNT_CODE,
          I.OU_ID OU_ID, --经营单位ID
          5 STATUS, --状态(5：已录入)
          NULL SALES_NUMBER, --销售单号
          NULL EMS_FLAG,   --是否已同步过EMS  Y\N\ NULL
          NULL EMS_APPLY_ID,  --EMS同步过来的批文ID
          NULL VENDOR_SITE_ID, --供应商地点ID
          NULL VENDOR_ID,    --供应商ID
          NULL COMPANY_ID,   --公司ID
          NULL FEE_TYPE_ID,  --费用类型ID
          NULL BUSIORGID,    --预算组织ID
          NULL FEE_DETAIL_TYPE,  --费用小类ID
          NULL FEE_MAIN_TYPE,    --费用大类ID
          NULL REMARK,
          I.CREATED_BY CREATED_BY,
          SYSDATE CREATION_DATE,
          I.CREATED_BY LAST_UPDATED_BY,
          SYSDATE LAST_UPDATE_DATE,
          I.LINE_ID,
          I.CALCULATE_GROUP_NAME,
          I.CALCULATE_GROUP_TYPE,
          I.DISCOUNT_PERIOD,
          I.REF_MODEL,
          I.TERMINAL_ID,
          I.TERMINAL_CODE,
          I.TERMINAL_NAME,
          DECODE(I.IS_CREATED_BY_ITEM, 'Y', '01', NULL)
        FROM DUAL;

        BEGIN
          INSERT INTO T_POL_DISCOUNT_LINES(
            LINE_ID,
            DISCOUNT_ORDER_ID,
            AMOUNT,
            DISCOUNT_AMOUNT,
            REWARDED_AMOUNT,
            CONT_LINE_ID,
            ITEM_ID,
            ITEM_CODE,
            ITEM_NAME,
            QUANTITY,
            ITEM_PRICE,
            BANK_CODE,
            BANK_NAME,
            ACCOUNT,
            BRANCH_ACCOUNT,
            CREATED_BY,
            CREATION_DATE,
            LAST_UPDATED_BY,
            LAST_UPDATE_DATE)
          SELECT
            S_POL_DISCOUNT_LINES.NEXTVAL LINE_ID,
            V_DISCOUNT_ORDER_ID DISCOUNT_ORDER_ID,
            I.LINE_AMOUNT AMOUNT ,
            I.LINE_AMOUNT DISCOUNT_AMOUNT, --折让金额
            0 REWARDED_AMOUNT, --红冲金额
            NULL CONT_LINE_ID, --来源行ID（记录Y单行ID）
            S_ITEM_ID ITEM_ID,        --产品ID
            S_ITEM_CODE ITEM_CODE,    --产品编码
            S_ITEM_NAME ITEM_NAME,    --产品名称
            I.QUANTITY QUANTITY,      --产品数量
            I.LIST_PRICE ITEM_PRICE,  --产品价格
            NULL BANK_CODE,    --银行编码
            NULL BANK_NAME,    --银行名称
            NULL ACCOUNT,      --银行账号
            NULL BRANCH_ACCOUNT,    --分行账号
            I.CREATED_BY CREATED_BY,
            SYSDATE CREATION_DATE,
            I.CREATED_BY LAST_UPDATED_BY,
            SYSDATE LAST_UPDATE_DATE
          FROM DUAL;
        EXCEPTION WHEN OTHERS THEN
          ROLLBACK TO ROLLBACK_HERE;
          P_MESSAGE := '保存返利单行表出错，错误代码：' || SQLCODE || V_NL || '错误信息：' || SQLERRM ;
          RETURN;
        END;

        --更新Y单行，回写返利单号
        --生成F单头、行表之后，在Y单上回置状态
        BEGIN
          /* Y单行保存时会设置已转返利金额，这里不用再次设置 2017-07-27 add by xiaoxu
          --Y单头表置 已转返利金额 字段
          UPDATE T_POL_ORDER_HEADERS T
             SET T.HAD_CASH_AMOUNT  = NVL(T.HAD_CASH_AMOUNT, 0) +
                                      I.LINE_AMOUNT,
                 T.LAST_UPDATED_BY  = I.CREATED_BY,
                 T.LAST_UPDATE_DATE = SYSDATE
           WHERE T.ROWID = I.A_ROWID;
           */
          --Y单行表置 返利单据号 字段
          UPDATE T_POL_ORDER_LINES T
             SET T.DISCOUNT_ORDER_NUMBER = V_DISCOUNT_ORDER_NUMBER,
                 T.LAST_UPDATED_BY       = I.CREATED_BY,
                 T.CHANGED_CASH_FLAG     = 'Y',
                 T.LAST_UPDATE_DATE      = SYSDATE,
                 T.VERSION               = T.VERSION + 1
           WHERE T.ROWID = I.B_ROWID;

        EXCEPTION WHEN OTHERS THEN
          ROLLBACK TO ROLLBACK_HERE;
          P_MESSAGE := '返利申请行表更新返利单号出错，错误代码：' || SQLCODE || V_NL || '错误信息：' || SQLERRM ;
          RETURN;
        END;
      END;
    END LOOP;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK TO ROLLBACK_HERE;
      P_MESSAGE := '调用Y转F工作流结束生成F单过程出错，错误代码：' || SQLCODE || V_NL || '错误信息：' || SQLERRM ;
  END P_CREATE_DISCOUNT_ORDER;


  PROCEDURE P_GET_CONTACT_REMARK(P_POLICY_ORDER_ID  IN NUMBER,
                                P_POLICY_NAME      OUT VARCHAR2,
                                P_POLICY_MAIN_TYPE OUT VARCHAR2,
                                P_POLICY_NUMBER    OUT VARCHAR2) IS
  BEGIN
    SELECT PA.POLICY_NAME, PB.SALES_MAIN_TYPE, PA.POLICY_NUMBER
      INTO P_POLICY_NAME, P_POLICY_MAIN_TYPE, P_POLICY_NUMBER
      FROM T_POL_POLICY PA, T_POL_ORDER_HEADERS PB
     WHERE PA.POLICY_NUMBER = PB.POLICY_NUMBER
       AND PB.POLICY_ORDER_ID = P_POLICY_ORDER_ID;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN;
  END P_GET_CONTACT_REMARK;


  --销售折让获取备注
  FUNCTION F_GET_REMARK(P_DIS_ORDER_ID IN NUMBER --返利兑现ID
                        ) RETURN VARCHAR2 IS
    N_RESULT         VARCHAR2(4000);
    /*F_POLICY_NAME  VARCHAR2(240);
    F_POLICY_NUM     VARCHAR2(40);
    F_SALE_MAIN_TYPE VARCHAR2(32);
    F_ORDER_NUM      VARCHAR2(100);
    F_DIS_NUM        VARCHAR(32);*/

  BEGIN
      SELECT NVL(PD.REMARK, '')
        INTO N_RESULT
        FROM T_POL_DISCOUNT_ORDER PD
       WHERE PD.DISCOUNT_ORDER_ID = P_DIS_ORDER_ID;
/*  SELECT PA.POLICY_NAME,
           PA.POLICY_NUMBER,
           PD.CLASS_NAME,
           PB.POLICY_ORDER_NUMBER,
           PC.DISCOUNT_ORDER_NUMBER
      INTO F_POLICY_NAME,
           F_POLICY_NUM,
           F_SALE_MAIN_TYPE,
           F_ORDER_NUM,
           F_DIS_NUM
      FROM T_POL_POLICY         PA,
           T_POL_ORDER_HEADERS  PB,
           T_POL_DISCOUNT_ORDER PC,
           T_BD_ITEM_CLASS      PD
     WHERE PA.POLICY_ORDER_NUMBER(+) = PB.POLICY_ORDER_NUMBER
       AND PB.POLICY_ORDER_ID(+) = PC.POLICY_ORDER_ID
       AND PC.SALES_MAIN_TYPE = PD.CLASS_CODE
       AND PC.ENTITY_ID = PD.ENTITY_ID
       AND PC.DISCOUNT_ORDER_ID = P_DIS_ORDER_ID;

    IF F_POLICY_NAME IS NOT NULL THEN
      N_RESULT := F_POLICY_NAME || '/';
    END IF;

    N_RESULT := N_RESULT || F_SALE_MAIN_TYPE || '/';

    IF F_POLICY_NUM IS NOT NULL THEN
      N_RESULT := N_RESULT || F_POLICY_NUM || '/';
    END IF;

    IF F_ORDER_NUM IS NOT NULL THEN
      N_RESULT := N_RESULT || F_ORDER_NUM || '/';
    END IF;

    N_RESULT := N_RESULT || F_DIS_NUM;*/

    RETURN N_RESULT;
  EXCEPTION
    WHEN OTHERS THEN
      N_RESULT := '获取备注出错，错误代码：' || SQLCODE || SQLERRM;
      RETURN N_RESULT;
  END F_GET_REMARK;


  --根据工程机登录号查询可用资源
  PROCEDURE P_QUERY_RESOURCE(P_PROJECT_CODE    IN VARCHAR2,
                             P_DISCOUNT_METHOD IN VARCHAR2,
                             P_AMOUNT          OUT NUMBER,
                             P_MESSAGE         OUT VARCHAR2) IS
    P_RECORD        NUMBER;
    P_USABLE_AMOUNT NUMBER;

  BEGIN
    P_MESSAGE := 'SUCCESS';
    P_AMOUNT  := 0;

    --转费用  折让方式为政策转费用
    BEGIN
      IF P_DISCOUNT_METHOD = '2' THEN
        SELECT NVL(SUM(PB.MIDDLE_AMOUNT), 0), COUNT(*)
          INTO P_AMOUNT, P_RECORD
          FROM CIMS.T_BD_PRICE_APPLY        PA,
               CIMS.T_BD_PRICE_APPLY_DETAIL PB
         WHERE PA.PRICE_APPLY_ID = PB.PRICE_APPLY_ID
           AND PA.PROJECT_CODE = P_PROJECT_CODE
           AND PB.MIDDLE_AMOUNT <> 0;
        IF P_RECORD = 0 THEN
          P_MESSAGE := '至少应该有一个工程机批文设置中间费用！';
        END IF;

        --除去已申请、已送审、已审核、已驳回的金额，才是可用金额
        SELECT NVL(SUM(PX.DOC_LAND_AMOUNT), 0)
          INTO P_USABLE_AMOUNT
          FROM CIMS.T_POL_POLICY PX
         WHERE PX.PROJECT_CODE = P_PROJECT_CODE
           AND PX.STATUS IN ('3', '5', '6', '8');

        P_AMOUNT := P_AMOUNT - P_USABLE_AMOUNT;

      END IF;
    END;

    --材料入库   折让方式为价差转到款
    BEGIN
      IF P_DISCOUNT_METHOD = '6' THEN
        SELECT COUNT(*)
          INTO P_RECORD
          FROM CIMS.T_BD_PRICE_APPLY        PA,
               CIMS.T_BD_PRICE_APPLY_DETAIL PB
         WHERE PA.PRICE_APPLY_ID = PB.PRICE_APPLY_ID
           AND PA.PROJECT_CODE = P_PROJECT_CODE
           AND PB.MIDDLE_AMOUNT = 0;

        IF P_RECORD = 0 THEN
          P_MESSAGE := '至少应该有一个工程机批文不设置中间费用！';
        END IF;
      END IF;
    END;
  END P_QUERY_RESOURCE;


  --------------------------------------------------------------------------------
  /*
  *   创建日期：2015-07-23
  *     创建者：胡涛
  *   功能说明：财务接口  财务模块调用生成Y单、F单
  *    T_POL_ORDER_HEADERS  --Y单头表
       T_POL_ORDER_LINES    --Y单行表

       T_POL_DISCOUNT_ORDER --F单头表
       T_POL_DISCOUNT_LINES --行表
      参数说明：
          P_INTF_ID   接口ID
          P_ENTITY_ID 主体ID
          P_ORDER_NUMBER Y单编码
          P_DISCOUNT_NUMBER F单编码
          P_MESSAGE   错误信息返回接收值，成功返回"SUCCESS"，失败返回原因
  *
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_FINANCE_INTERFACE(P_INTF_ID   IN NUMBER,
                                P_ENTITY_ID IN NUMBER,
                                P_ORDER_NUMBER OUT VARCHAR2,
                                P_DISCOUNT_NUMBER OUT VARCHAR2,
                                P_MESSAGE   OUT VARCHAR2) IS
    --P_ORDER_NUMBER       VARCHAR2(100);  --Y单编码
    SEQ_POLICY_Y_HEADERS   NUMBER;         --Y单头ID
    SEQ_POLICY_Y_LINES     NUMBER;         --Y单行ID
    SEQ_POL_DISCOUNT_ORDER NUMBER;         --F单头ID
    SEQ_POL_DISCOUNT_LINES NUMBER;         --F单行ID
    --P_DISCOUNT_NUMBER    VARCHAR2(100);  --F单编码
    P_AMOUNT               NUMBER;         --申请金额
    P_CREATED_BY           VARCHAR2(32);   --创建人
    P_ITEM_ID              NUMBER;         --商品ID
    P_ITEM_CODE            VARCHAR2(100);  --商品编码
    P_ITEM_NAME            VARCHAR2(240);  --商品名称
    P_DISCOUNT_METHOD      VARCHAR2(32);   --折让方式

    --商品列表
    CURSOR C_POL_ITEMS IS
      SELECT A.ITEM_ID, A.ITEM_CODE, A.ITEM_NAME
        FROM T_BD_ITEM A
       WHERE A.ENTITY_ID = P_ENTITY_ID
         AND IS_VIRTUAL = 'Y';

  BEGIN
    --设置返回信息
    P_MESSAGE := 'SUCCESS';

    BEGIN
      SELECT A.POLICY_AMOUNT, A.CREATED_BY, A.DISCOUNT_METHOD
        INTO P_AMOUNT, P_CREATED_BY, P_DISCOUNT_METHOD
        FROM INTF_POLICY_DISCOUNT A
       WHERE A.INTF_ID = P_INTF_ID;
    END;

    SAVEPOINT ROLLBACK_HERE;

    --获取Y单编码
    P_ORDER_NUMBER := PKG_BD.F_GET_BILL_NO('POLYORDERNUMBER',
                                           NULL,
                                           P_ENTITY_ID,
                                           NULL);
    
    --插入Y单头表
    SELECT S_POLICY_Y_HEADERS.NEXTVAL INTO SEQ_POLICY_Y_HEADERS FROM DUAL;
    BEGIN 
      INSERT INTO T_POL_ORDER_HEADERS
         (POLICY_ORDER_ID,
          ENTITY_ID,
          POLICY_ORDER_NUMBER,
          ORDER_DATE,
          STAUTS,
          SALES_CENTER_ID,
          SALES_CENTER_CODE,
          SALES_CENTER_NAME,
          POLICY_AMOUNT,
          CUSTOMER_ID,
          CUSTOMER_CODE,
          CUSTOMER_NAME,
          ACCOUNT_ID,
          ACCOUNT_CODE,
          DISCOUNT_PAY_DEPT,
          DISCOUNT_ITEM,
          DISCOUNT_METHOD,
          SALES_MAIN_TYPE,
          CREATED_BY,
          CREATION_DATE,
          LAST_UPDATED_BY,
          LAST_UPDATE_DATE,
          VERSION,
          CUSTOMER_TYPE,
          DRAW_ID)
         SELECT SEQ_POLICY_Y_HEADERS, --Y单头ID
                PA.ENTITY_ID, --主体
                P_ORDER_NUMBER, --Y单编码
                SYSDATE, --单据日期
                '5', --状态
                PA.SALES_CENTER_ID, --营销中心ID
                PA.SALES_CENTER_CODE, --营销中心编码
                PA.SALES_CENTER_NAME, --营销中心名称
                PA.POLICY_AMOUNT, --申请金额
                PA.CUSTOMER_ID, --客户ID
                PA.CUSTOMER_CODE, --客户编码
                PA.CUSTOMER_NAME, --客户名称
                PA.ACCOUNT_ID, --账户ID
                PA.ACCOUNT_CODE, --账户编码
                PA.DISCOUNT_PAY_DEPT, --支付来源
                PA.DISCOUNT_ITEM, --折让项目
                PA.DISCOUNT_METHOD, --折让方式
                PA.SALES_MAIN_TYPE, --营销大类
                PA.CREATED_BY, --创建人
                SYSDATE, --创建时间
                PA.CREATED_BY, --最后修改人
                SYSDATE,  --最后修改时间
                '1', --版本号
                PA.CUSTOMER_TYPE, --客户类型
                PA.DRAW_ID --保函开立ID
           FROM INTF_POLICY_DISCOUNT PA
          WHERE PA.INTF_ID = P_INTF_ID;
    EXCEPTION
      WHEN OTHERS THEN
        ROLLBACK TO ROLLBACK_HERE;
        P_MESSAGE := '保存Y单头表报错，错误代码：' || SQLCODE || '错误信息：' || SQLERRM;
        ---将错误信息写入接口表
        UPDATE INTF_POLICY_DISCOUNT
           SET RESULT = P_MESSAGE
         WHERE INTF_ID = P_INTF_ID;
        RETURN;
    END;

    --插入Y单行表
    SELECT S_POLICY_Y_LINES.NEXTVAL INTO SEQ_POLICY_Y_LINES FROM DUAL;
    BEGIN
       INSERT INTO T_POL_ORDER_LINES
         (LINE_ID,
          POLICY_ORDER_ID,
          LINE_AMOUNT,
          CHANGED_CASH_FLAG,
          UOM_CODE,
          QUANTITY,
          LIST_PRICE,
          CUSTOMER_ID,
          CUSTOMER_CODE,
          CUSTOMER_NAME,
          ACCOUNT_ID,
          ACCOUNT_CODE,
          DISCOUNT_METHOD,
          CREATED_BY,
          CREATION_DATE,
          LAST_UPDATED_BY,
          LAST_UPDATE_DATE,
          SALES_CENTER_ID,
          SALES_CENTER_CODE,
          SALES_CENTER_NAME,
          VERSION,
          OU_ID,
          CUSTOMER_TYPE)
         SELECT SEQ_POLICY_Y_LINES, --Y单行ID
                SEQ_POLICY_Y_HEADERS, --Y单ID
                PB.POLICY_AMOUNT, --申请金额
                'N', --已转返利标识
                'CNY', --单位
                '1', --数量
                PB.POLICY_AMOUNT, --价格
                PB.CUSTOMER_ID, --客户ID
                PB.CUSTOMER_CODE, --客户编码
                PB.CUSTOMER_NAME, --客户名称
                PB.ACCOUNT_ID, --账户ID
                PB.ACCOUNT_CODE, --账户编码
                PB.DISCOUNT_METHOD, --折让方式
                PB.CREATED_BY, --创建人
                SYSDATE, --创建时间
                PB.CREATED_BY, --最后修改人
                SYSDATE, --最后修改时间
                PB.SALES_CENTER_ID, --营销中心ID
                PB.SALES_CENTER_CODE, --营销中心编码
                PB.SALES_CENTER_NAME, --营销中心名称
                '1', --版本号
                PB.OU_ID, --经营单位
                PB.CUSTOMER_TYPE --客户类型
           FROM INTF_POLICY_DISCOUNT PB
          WHERE PB.INTF_ID = P_INTF_ID;
    EXCEPTION
      WHEN OTHERS THEN
        ROLLBACK TO ROLLBACK_HERE;
        P_MESSAGE := '保存Y单行表报错，错误代码：' || SQLCODE || '错误信息：' || SQLERRM;
        ---将错误信息写入接口表
        UPDATE INTF_POLICY_DISCOUNT
           SET RESULT = P_MESSAGE
         WHERE INTF_ID = P_INTF_ID;
        RETURN;
    END;

    --插入F单头、行表
    SELECT S_POL_DISCOUNT_ORDER.NEXTVAL
      INTO SEQ_POL_DISCOUNT_ORDER
      FROM DUAL;

    SELECT S_POL_DISCOUNT_LINES.NEXTVAL
      INTO SEQ_POL_DISCOUNT_LINES
      FROM DUAL;

    --插入F单头表
    P_DISCOUNT_NUMBER := PKG_BD.F_GET_BILL_NO('POLDISCOUNT',
                                              NULL,
                                              P_ENTITY_ID,
                                              NULL);
    BEGIN
       INSERT INTO T_POL_DISCOUNT_ORDER
         (DISCOUNT_ORDER_ID,
          ENTITY_ID,
          DISCOUNT_ORDER_NUMBER,
          ORDERED_DATE,
          ORDER_TYPE_ID,
          DISCOUNT_METHOD,
          DISCOUNT_PAY_DEPT,
          DISCOUNT_ITEM,
          SALES_MAIN_TYPE,
          SALES_CENTER_ID,
          SALES_CENTER_CODE,
          SALES_CENTER_NAME,
          CUSTOMER_TYPE,
          CUSTOMER_ID,
          CUSTOMER_CODE,
          CUSTOMER_NAME,
          ACCOUNT_ID,
          ACCOUNT_CODE,
          OU_ID,
          STATUS,
          CREATED_BY,
          CREATION_DATE,
          LAST_UPDATED_BY,
          LAST_UPDATE_DATE,
          VERSION,
          DRAW_ID)
         SELECT SEQ_POL_DISCOUNT_ORDER, --F单ID
                P_ENTITY_ID, --主体
                P_DISCOUNT_NUMBER, --F单编码
                SYSDATE, --单据日期
                '1', --单据类型
                PC.DISCOUNT_METHOD, --折让方式
                PC.DISCOUNT_PAY_DEPT, --支付来源
                PC.DISCOUNT_ITEM, --折让项目
                PC.SALES_MAIN_TYPE, --营销大类
                PC.SALES_CENTER_ID, --营销中心ID
                PC.SALES_CENTER_CODE, --营销中心编码
                PC.SALES_CENTER_NAME, --营销中心名称
                PC.CUSTOMER_TYPE, --客户类型
                PC.CUSTOMER_ID, --客户ID
                PC.CUSTOMER_CODE, --客户编码
                PC.CUSTOMER_NAME, --客户名称
                PC.ACCOUNT_ID, --账户ID
                PC.ACCOUNT_CODE, --账户编码
                PC.OU_ID, --经营单位
                '5',
                PC.CREATED_BY, --创建人
                SYSDATE, --创建时间
                PC.CREATED_BY, --最后修改人
                SYSDATE, --最后修改时间
                '1',
                PC.DRAW_ID --保函开立ID
           FROM INTF_POLICY_DISCOUNT PC
          WHERE PC.INTF_ID = P_INTF_ID;
    EXCEPTION
      WHEN OTHERS THEN
        ROLLBACK TO ROLLBACK_HERE;
        P_MESSAGE := '保存F单头表报错，错误代码：' || SQLCODE || '错误信息：' || SQLERRM;
        ---将错误信息写入接口表
        UPDATE INTF_POLICY_DISCOUNT
           SET RESULT = P_MESSAGE
         WHERE INTF_ID = P_INTF_ID;
        RETURN;
    END;

    --获取默认商品
    FOR XI IN C_POL_ITEMS LOOP
       IF P_DISCOUNT_METHOD = 4 OR P_DISCOUNT_METHOD = 5 THEN
         IF XI.ITEM_CODE = 'Z0000000000001' THEN
           P_ITEM_ID   := XI.ITEM_ID;
           P_ITEM_CODE := XI.ITEM_CODE;
           P_ITEM_NAME := XI.ITEM_NAME;
         END IF;
       END IF;

       IF P_DISCOUNT_METHOD = 1 OR P_DISCOUNT_METHOD = 2 OR
          P_DISCOUNT_METHOD = 3 OR P_DISCOUNT_METHOD = 6 THEN
         IF XI.ITEM_CODE = 'Z0000000000002' THEN
           P_ITEM_ID   := XI.ITEM_ID;
           P_ITEM_CODE := XI.ITEM_CODE;
           P_ITEM_NAME := XI.ITEM_NAME;
         END IF;
       END IF;
    END LOOP;

    --插入F单行表
    BEGIN
      INSERT INTO T_POL_DISCOUNT_LINES
         (LINE_ID,
          DISCOUNT_ORDER_ID,
          AMOUNT,
          DISCOUNT_AMOUNT,
          ITEM_ID,
          ITEM_CODE,
          ITEM_NAME,
          CREATED_BY,
          CREATION_DATE)
         SELECT SEQ_POL_DISCOUNT_LINES, --F单行ID
                SEQ_POL_DISCOUNT_ORDER, --F单头ID
                PD.POLICY_AMOUNT, --金额
                PD.POLICY_AMOUNT, --金额
                P_ITEM_ID, --商品ID
                P_ITEM_CODE, --商品编码
                P_ITEM_NAME, --商品名称
                PD.CREATED_BY, --创建人
                SYSDATE --创建时间
           FROM INTF_POLICY_DISCOUNT PD
          WHERE PD.INTF_ID = P_INTF_ID;
    EXCEPTION
      WHEN OTHERS THEN
        ROLLBACK TO ROLLBACK_HERE;
        P_MESSAGE := '保存F单头表报错，错误代码：' || SQLCODE || '错误信息：' || SQLERRM;
        ---将错误信息写入接口表
        UPDATE INTF_POLICY_DISCOUNT
           SET RESULT = P_MESSAGE
         WHERE INTF_ID = P_INTF_ID;
        RETURN;
    END;

    --更新Y单头表字段（已转返利金额、剩余金额、最后更新人、时间）
    --行字段（已转返利标识、返利单号、最后更新人、时间）
    BEGIN
       UPDATE T_POL_ORDER_HEADERS
          SET HAD_CASH_AMOUNT  = P_AMOUNT,
              REMAINING_AMOUNT = 0,
              LAST_UPDATED_BY  = P_CREATED_BY,
              LAST_UPDATE_DATE = SYSDATE
        WHERE POLICY_ORDER_ID = SEQ_POLICY_Y_HEADERS;

       UPDATE T_POL_ORDER_LINES
          SET CHANGED_CASH_FLAG     = 'Y',
              DISCOUNT_ORDER_NUMBER = P_DISCOUNT_NUMBER,
              LAST_UPDATED_BY       = P_CREATED_BY,
              LAST_UPDATE_DATE      = SYSDATE
        WHERE LINE_ID = SEQ_POLICY_Y_LINES;
    EXCEPTION
       WHEN OTHERS THEN
         ROLLBACK TO ROLLBACK_HERE;
         P_MESSAGE := '回写Y单信息失败，错误代码：' || SQLCODE || '错误信息：' || SQLERRM;
         ---将错误信息写入接口表
         UPDATE INTF_POLICY_DISCOUNT
            SET RESULT = P_MESSAGE
          WHERE INTF_ID = P_INTF_ID;
         RETURN;
    END;

    --回写Y、F单据编码及处理结果
    BEGIN
       UPDATE INTF_POLICY_DISCOUNT
          SET RESULT                = P_MESSAGE,
              POLICY_ORDER_NUMBER   = P_ORDER_NUMBER,
              DISCOUNT_ORDER_NUMBER = P_DISCOUNT_NUMBER
        WHERE INTF_ID = P_INTF_ID;
    EXCEPTION
       WHEN OTHERS THEN
         ROLLBACK TO ROLLBACK_HERE;
         P_MESSAGE := '回写接口信息失败，错误代码：' || SQLCODE || '错误信息：' || SQLERRM;
         ---将错误信息写入接口表
         UPDATE INTF_POLICY_DISCOUNT
            SET RESULT = P_MESSAGE
          WHERE INTF_ID = P_INTF_ID;
         RETURN;
    END;
  END P_FINANCE_INTERFACE;


  --查询政策申请金额
  PROCEDURE P_QUERY_POLICY_AMOUNT(P_POLICY_ID IN NUMBER
                                 ,P_AMOUNT    OUT NUMBER
                                 ,P_MESSAGE   OUT VARCHAR2) IS
    R_RESULT_NUM NUMBER; 
  BEGIN
    P_MESSAGE := 'SUCCESS';
  
    SELECT PA.DOC_LAND_AMOUNT
      INTO P_AMOUNT
      FROM CIMS.T_POL_POLICY PA
     WHERE PA.POLICY_ID = P_POLICY_ID;
  END P_QUERY_POLICY_AMOUNT;


  --返利单作废
  PROCEDURE P_CANCEL_DISCOUNT(P_DISCOUNT_NUMBER IN VARCHAR2
                             ,P_USER_ACCOUNT    IN VARCHAR2
                             ,P_ENTITY_ID       IN NUMBER
                             ,P_MESSAGE         OUT VARCHAR2) IS
    R_RESULT_NUM         NUMBER;
    R_STATUS             VARCHAR2(10);
    R_POLICY_ORDER_ID    NUMBER;
    R_DISCOUNT_ID_TEMP   NUMBER;
    R_DISCOUNT_NO_TEMP   VARCHAR2(100);
    R_DISCOUNT_OLD_COUNT NUMBER;
    R_DISCOUNT_PERIOD    VARCHAR2(32); --Y单行归属返利周期
    S_CUR_DIS_PERIOD     VARCHAR2(32); --当前日期倒推10天
    S_POL_SRC_BILL_TYPE  VARCHAR2(30); --政策申请来源单据类型
      
    CURSOR C_DISCOUNT_INFO IS
      SELECT PY.*
            ,PL.AMOUNT
            ,PL.DISCOUNT_AMOUNT
            ,PL.REWARDED_AMOUNT
            ,PL.OLD_DISCOUNT_AMOUNT
        FROM T_POL_DISCOUNT_ORDER PY, T_POL_DISCOUNT_LINES PL
       WHERE PY.DISCOUNT_ORDER_ID = PL.DISCOUNT_ORDER_ID
         AND PY.DISCOUNT_ORDER_NUMBER = P_DISCOUNT_NUMBER
         AND PY.SOURCE_ORDER_ID IS NULL; --来源其它系统的返利单不允许作废
      
  BEGIN
    P_MESSAGE := 'SUCCESS';
      
    FOR I IN C_DISCOUNT_INFO LOOP
      --查看F单状态是否允许作废
      SELECT COUNT(*)
        INTO R_RESULT_NUM
        FROM CIMS.UP_CODELIST PA, CIMS.UP_CODELIST_ENTITY PB
       WHERE PA.ID = PB.CODELIST_ID
         AND PA.CODETYPE = 'CANCEL_DISCOUNT_STATUS'
         AND PB.CODE_VALUE = I.STATUS
         AND PB.ENTITY_ID = P_ENTITY_ID;
        
      IF R_RESULT_NUM = 0 THEN
        P_MESSAGE := '该返利单【' || P_DISCOUNT_NUMBER || '】的状态不能允许作废操作!';
        RETURN;
      END IF;
        
      --查看Y单状态是否关闭
      BEGIN
        SELECT Q.STAUTS, Q.POLICY_ORDER_ID
          INTO R_STATUS, R_POLICY_ORDER_ID
          FROM CIMS.T_POL_ORDER_HEADERS Q, CIMS.T_POL_ORDER_LINES E
         WHERE Q.POLICY_ORDER_ID = E.POLICY_ORDER_ID
           AND E.DISCOUNT_ORDER_NUMBER = P_DISCOUNT_NUMBER;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          GOTO HERE;
      END;
        
      IF R_STATUS IS NOT NULL AND R_STATUS = 7 THEN
        P_MESSAGE := '该返利单【' || P_DISCOUNT_NUMBER || '】关联的返利申请单已关闭, 请先取消关闭返利申请单再作废返利单!';
        RETURN;
      END IF;
        
      <<HERE>>
        
      --作废蓝单之前需要先作废红单
      IF I.ORDER_TYPE_ID = 1 AND I.AMOUNT = 0 THEN
        SELECT COUNT(*)
          INTO R_DISCOUNT_OLD_COUNT
          FROM CIMS.T_POL_DISCOUNT_ORDER LX
         WHERE LX.OLD_DISCOUNT_NUMBER = P_DISCOUNT_NUMBER;
          
        IF R_DISCOUNT_OLD_COUNT <> 0 AND I.STATUS <> 2 THEN
          P_MESSAGE := '该返利单【' || P_DISCOUNT_NUMBER || '】关联的红冲单已审核或已确认,请先作废红冲单!';
          RETURN;
        END IF;
      END IF;
        
      --更新F单头,行
      UPDATE T_POL_DISCOUNT_ORDER PX
         SET PX.STATUS           = '2'
            ,PX.LAST_UPDATE_DATE = SYSDATE
            ,PX.LAST_UPDATED_BY  = P_USER_ACCOUNT
            ,PX.VERSION          = (PX.VERSION + 1)
       WHERE PX.DISCOUNT_ORDER_NUMBER = P_DISCOUNT_NUMBER;
        
      UPDATE T_POL_DISCOUNT_LINES PD
         SET PD.DISCOUNT_AMOUNT     = 0
            ,PD.REWARDED_AMOUNT     = 0
            ,PD.AMOUNT              = 0
            ,PD.OLD_DISCOUNT_AMOUNT = 0
            ,PD.LAST_UPDATE_DATE    = SYSDATE
            ,PD.LAST_UPDATED_BY     = P_USER_ACCOUNT
       WHERE PD.DISCOUNT_ORDER_ID = I.DISCOUNT_ORDER_ID;
        
      --如果是红单且状态不为已录入,需要更新蓝单金额
      IF I.ORDER_TYPE_ID = 2 AND I.STATUS <> 5 THEN
        --已作废直接跳过
        IF I.STATUS = 2 THEN
          GOTO THERE;
        END IF;
        SELECT PQ.OLD_DISCOUNT_ID, PQ.OLD_DISCOUNT_NUMBER
          INTO R_DISCOUNT_ID_TEMP, R_DISCOUNT_NO_TEMP
          FROM CIMS.T_POL_DISCOUNT_ORDER PQ
         WHERE PQ.DISCOUNT_ORDER_NUMBER = P_DISCOUNT_NUMBER;
          
        UPDATE CIMS.T_POL_DISCOUNT_LINES PW
           SET PW.REWARDED_AMOUNT  = 0
              ,PW.AMOUNT           = PW.DISCOUNT_AMOUNT
              ,PW.LAST_UPDATED_BY  = P_USER_ACCOUNT
              ,PW.LAST_UPDATE_DATE = SYSDATE
              ,PW.VERSION          = (PW.VERSION + 1)
         WHERE PW.DISCOUNT_ORDER_ID = R_DISCOUNT_ID_TEMP;
      END IF;
        
      <<THERE>>
   
      --有来源Y单  蓝单
      IF R_POLICY_ORDER_ID IS NOT NULL AND I.ORDER_TYPE_ID = 1 THEN
        UPDATE CIMS.T_POL_ORDER_HEADERS PR
           SET PR.HAD_CASH_AMOUNT  = PR.HAD_CASH_AMOUNT - I.DISCOUNT_AMOUNT
              ,PR.REMAINING_AMOUNT = PR.REMAINING_AMOUNT + I.DISCOUNT_AMOUNT
              ,PR.LAST_UPDATED_BY  = P_USER_ACCOUNT
              ,PR.LAST_UPDATE_DATE = SYSDATE
              ,PR.VERSION          = (PR.VERSION + 1)
         WHERE PR.POLICY_ORDER_ID = R_POLICY_ORDER_ID;
          
        UPDATE CIMS.T_POL_ORDER_LINES PT
           SET PT.LINE_AMOUNT      = 0
              ,PT.LIST_PRICE       = 0
              ,PT.LAST_UPDATED_BY  = P_USER_ACCOUNT
              ,PT.LAST_UPDATE_DATE = SYSDATE
              ,PT.VERSION          = (PT.VERSION + 1)
         WHERE PT.POLICY_ORDER_ID = R_POLICY_ORDER_ID
           AND PT.DISCOUNT_ORDER_NUMBER = I.DISCOUNT_ORDER_NUMBER;
      END IF;
        
      --红单需要查询蓝单关联的Y单ID
      IF R_DISCOUNT_NO_TEMP IS NOT NULL THEN
        BEGIN
          SELECT PA.POLICY_ORDER_ID
            INTO R_POLICY_ORDER_ID
            FROM CIMS.T_POL_ORDER_HEADERS PA, CIMS.T_POL_ORDER_LINES PB
           WHERE PA.POLICY_ORDER_ID = PB.POLICY_ORDER_ID
             AND PB.DISCOUNT_ORDER_NUMBER = R_DISCOUNT_NO_TEMP;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            GOTO MD;
        END;
      END IF;
        
      --有来源Y单  红单
      IF R_POLICY_ORDER_ID IS NOT NULL AND I.ORDER_TYPE_ID = 2 THEN
        --根据状态 已录入和已作废不操作Y单  审核  确认才更新Y单
        IF I.STATUS <> 5 AND I.STATUS <> 2 THEN
          UPDATE CIMS.T_POL_ORDER_HEADERS PO
             SET PO.HAD_CASH_AMOUNT  = PO.HAD_CASH_AMOUNT + (0 - I.DISCOUNT_AMOUNT)
                ,PO.REMAINING_AMOUNT = PO.REMAINING_AMOUNT - (0 - I.DISCOUNT_AMOUNT)
                ,PO.LAST_UPDATED_BY  = P_USER_ACCOUNT
                ,PO.LAST_UPDATE_DATE = SYSDATE
                ,PO.VERSION          = (PO.VERSION + 1)
           WHERE PO.POLICY_ORDER_ID = R_POLICY_ORDER_ID;
            
          UPDATE CIMS.T_POL_ORDER_LINES PT
             SET PT.LINE_AMOUNT      = (0 - I.DISCOUNT_AMOUNT)
                ,PT.LIST_PRICE       = (0 - I.DISCOUNT_AMOUNT)
                ,PT.LAST_UPDATED_BY  = P_USER_ACCOUNT
                ,PT.LAST_UPDATE_DATE = SYSDATE
                ,PT.VERSION          = (PT.VERSION + 1)
           WHERE PT.POLICY_ORDER_ID = R_POLICY_ORDER_ID
             AND PT.DISCOUNT_ORDER_NUMBER = R_DISCOUNT_NO_TEMP;
        END IF;
      END IF;

      <<MD>>
        
      IF R_POLICY_ORDER_ID IS NOT NULL THEN
        BEGIN
          --获取Y单行归属返利周期
          SELECT PB.DISCOUNT_PERIOD, TO_CHAR(SYSDATE - 10, 'YYYY-MM')
            INTO R_DISCOUNT_PERIOD, S_CUR_DIS_PERIOD
            FROM CIMS.T_POL_ORDER_HEADERS PA, CIMS.T_POL_ORDER_LINES PB
           WHERE PA.POLICY_ORDER_ID = PB.POLICY_ORDER_ID
             AND PB.POLICY_ORDER_ID = R_POLICY_ORDER_ID
             AND PB.DISCOUNT_ORDER_NUMBER = NVL(R_DISCOUNT_NO_TEMP, P_DISCOUNT_NUMBER)
             AND (PA.UNUSE_AMOUNT_1_11 IS NOT NULL OR
                 PA.UNUSE_AMOUNT_12 IS NOT NULL OR
                 PA.UNUSE_AMOUNT_1_CUR IS NOT NULL OR
                 PA.UNUSE_AMOUNT_NEXT IS NOT NULL);
           --更新4项未返利金额
          IF R_DISCOUNT_PERIOD IS NOT NULL THEN
            P_UPDATE_Y_UNUSED_AMOUNT(S_CUR_DIS_PERIOD, R_DISCOUNT_PERIOD, R_POLICY_ORDER_ID, I.DISCOUNT_AMOUNT);
          END IF;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            NULL;
        END;
        --补亏政策、价差(返利)政策：
        --删除工程机批文销售明细与返利单的对应关系
        BEGIN
          IF I.POLICY_ID IS NOT NULL THEN
            BEGIN
              SELECT P.SRC_BILL_TYPE
                INTO S_POL_SRC_BILL_TYPE
                FROM CIMS.T_POL_POLICY P
               WHERE P.POLICY_ID = I.POLICY_ID;
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                NULL;
            END;
            IF (S_POL_SRC_BILL_TYPE IN ('LOSS_POL', 'MID_DIS_POL')) THEN
              DELETE FROM T_BD_PRICE_APPLY_SO_DIS_RELA R
               WHERE R.BILL_TYPE = S_POL_SRC_BILL_TYPE
                 AND R.POLICY_ORDER_LINE_ID = I.FROM_LINE_ID;
            END IF;
          END IF;
        END;
      END IF;

    END LOOP;
  END P_CANCEL_DISCOUNT;


  PROCEDURE P_GET_LINE_AMOUNT(P_DISCOUNT_LINE_ID IN NUMBER
                             ,P_AMOUNT           OUT VARCHAR2) IS
  BEGIN
    SELECT PA.AMOUNT
      INTO P_AMOUNT
      FROM CIMS.T_POL_DISCOUNT_LINES PA
     WHERE PA.LINE_ID = P_DISCOUNT_LINE_ID;
  END P_GET_LINE_AMOUNT;


  PROCEDURE P_UPDATE_Y_UNUSED_AMOUNT(S_CUR_DIS_PERIOD  IN VARCHAR2
                                    ,R_DISCOUNT_PERIOD IN VARCHAR2
                                    ,R_POLICY_ORDER_ID IN NUMBER
                                    ,AMOUNT IN NUMBER) IS
    S_CUR_1_DIS_PERIOD  VARCHAR2(32);
    S_PRE_12_DIS_PERIOD VARCHAR2(32);
  BEGIN
    S_CUR_1_DIS_PERIOD := SUBSTR(S_CUR_DIS_PERIOD, 1, 5) || '01';
    S_PRE_12_DIS_PERIOD := TO_CHAR(TO_NUMBER(SUBSTR(S_CUR_DIS_PERIOD, 1, 4)) - 1) || '-12';
    --对于已录入4个未返利金额字段，则按归属返利周期处理更新
    IF R_DISCOUNT_PERIOD >= S_CUR_1_DIS_PERIOD AND R_DISCOUNT_PERIOD <= S_CUR_DIS_PERIOD THEN
      --同一周期，则更新当前金额
      UPDATE
        T_POL_ORDER_HEADERS
      SET
        UNUSE_AMOUNT_1_CUR = NVL(UNUSE_AMOUNT_1_CUR,0) + AMOUNT
       ,VERSION = VERSION + 1
      WHERE
        POLICY_ORDER_ID = R_POLICY_ORDER_ID;
    ELSIF R_DISCOUNT_PERIOD = S_PRE_12_DIS_PERIOD THEN
      --上年12月周期
      UPDATE
        T_POL_ORDER_HEADERS
      SET
        UNUSE_AMOUNT_12 = NVL(UNUSE_AMOUNT_12,0) + AMOUNT
       ,VERSION = VERSION + 1
      WHERE
        POLICY_ORDER_ID = R_POLICY_ORDER_ID;
    ELSIF R_DISCOUNT_PERIOD < S_PRE_12_DIS_PERIOD THEN
      --上年11月前周期
      UPDATE
        T_POL_ORDER_HEADERS
      SET
        UNUSE_AMOUNT_1_11 = NVL(UNUSE_AMOUNT_1_11,0) + AMOUNT
       ,VERSION = VERSION + 1
      WHERE
        POLICY_ORDER_ID = R_POLICY_ORDER_ID;
    ELSE
      --后面周期
      UPDATE
        T_POL_ORDER_HEADERS
      SET
        UNUSE_AMOUNT_NEXT = NVL(UNUSE_AMOUNT_NEXT,0) + AMOUNT
       ,VERSION = VERSION + 1
      WHERE
        POLICY_ORDER_ID = R_POLICY_ORDER_ID;
    END IF;
  END P_UPDATE_Y_UNUSED_AMOUNT;

 
  PROCEDURE P_IMPORT_CUS_MTL_TYPE(IN_SRC_POLICY_ID  IN NUMBER
                                 ,IN_TRGT_POLICY_ID IN NUMBER
                                 ,IS_USER_ID        IN VARCHAR2
                                 ,OS_MESSAGE        OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
                                 ) IS
    N_TRGT_PAR_POLICY_ID NUMBER;             --目标政策对应的主政策
    N_SRC_PAR_POLICY_ID  NUMBER;             --模板政策对应的主政策
    S_SRC_PARENT_FLAG    VARCHAR2(2) := 'N'; --模板政策是否主政策标识(Y/N)
    N_INSERT_ROWCOUNT    NUMBER := 0;        --记录每次插入的记录数
    S_STEP               VARCHAR2(200);
  BEGIN
    OS_MESSAGE := 'OK';
    
    S_STEP := '获取目标政策的主政策';
    SELECT NVL(T.PARENT_POLICY_ID, IN_TRGT_POLICY_ID)
      INTO N_TRGT_PAR_POLICY_ID
      FROM T_POL_POLICY T
     WHERE T.POLICY_ID = IN_TRGT_POLICY_ID;
    --目标政策不是主政策，不执行引入操作
    IF IN_TRGT_POLICY_ID <> N_TRGT_PAR_POLICY_ID THEN
      RETURN;
    END IF;
  
    S_STEP := '获取模板政策的主政策';
    SELECT NVL(T.PARENT_POLICY_ID, IN_SRC_POLICY_ID)
      INTO N_SRC_PAR_POLICY_ID
      FROM T_POL_POLICY T
     WHERE T.POLICY_ID = IN_SRC_POLICY_ID;
    IF IN_SRC_POLICY_ID = N_SRC_PAR_POLICY_ID THEN
      S_SRC_PARENT_FLAG := 'Y';
    END IF;
  
    --1.1优先取模板政策对应的客户分类
    S_STEP := '从模板政策获取客户分类';
    DELETE FROM T_POL_POLICY_CUS_TYPE T
     WHERE T.POLICY_ID = IN_TRGT_POLICY_ID;
    INSERT INTO T_POL_POLICY_CUS_TYPE
      SELECT S_POL_POLICY_CUS_TYPE.NEXTVAL
            ,IN_TRGT_POLICY_ID
            ,SALES_MAIN_TYPE
            ,CUSTOMER_ID
            ,CUSTOMER_CODE
            ,CUSTOMER_NAME
            ,CUSTOMER_TYPE
            ,ACCOUNT_ID
            ,ACCOUNT_CODE
            ,SALES_CENTER_ID
            ,TAR_CUSTOMER_ID
            ,TAR_CUSTOMER_CODE
            ,TAR_CUSTOMER_NAME
            ,TAR_ACCOUNT_ID
            ,TAR_ACCOUNT_CODE
            ,IS_USER_ID
            ,SYSDATE
            ,IS_USER_ID
            ,SYSDATE
            ,SALES_CENTER_CODE
            ,SALES_CENTER_NAME
            ,TAR_SALES_CENTER_ID
            ,TAR_SALES_CENTER_CODE
            ,TAR_SALES_CENTER_NAME
            ,null,null
        FROM T_POL_POLICY_CUS_TYPE T
       WHERE T.POLICY_ID = IN_SRC_POLICY_ID
         /*AND NOT EXISTS (SELECT 1
                FROM CIMS.T_POL_POLICY_CUS_TYPE
               WHERE POLICY_ID = IN_TRGT_POLICY_ID
                 AND ROWNUM = 1)*/;
    --1.2模板政策没有客户分类，则取其主政策对应的客户分类
    N_INSERT_ROWCOUNT := SQL%ROWCOUNT;
    IF S_SRC_PARENT_FLAG = 'N' AND N_INSERT_ROWCOUNT = 0 THEN
      S_STEP := '从模板政策的主政策获取客户分类';
      INSERT INTO T_POL_POLICY_CUS_TYPE
        SELECT S_POL_POLICY_CUS_TYPE.NEXTVAL
              ,IN_TRGT_POLICY_ID
              ,SALES_MAIN_TYPE
              ,CUSTOMER_ID
              ,CUSTOMER_CODE
              ,CUSTOMER_NAME
              ,CUSTOMER_TYPE
              ,ACCOUNT_ID
              ,ACCOUNT_CODE
              ,SALES_CENTER_ID
              ,TAR_CUSTOMER_ID
              ,TAR_CUSTOMER_CODE
              ,TAR_CUSTOMER_NAME
              ,TAR_ACCOUNT_ID
              ,TAR_ACCOUNT_CODE
              ,IS_USER_ID
              ,SYSDATE
              ,IS_USER_ID
              ,SYSDATE
              ,SALES_CENTER_CODE
              ,SALES_CENTER_NAME
              ,TAR_SALES_CENTER_ID
              ,TAR_SALES_CENTER_CODE
              ,TAR_SALES_CENTER_NAME
              ,null,null
          FROM T_POL_POLICY_CUS_TYPE T
         WHERE T.POLICY_ID = N_SRC_PAR_POLICY_ID
           /*AND NOT EXISTS (SELECT 1
                  FROM CIMS.T_POL_POLICY_CUS_TYPE
                 WHERE POLICY_ID = IN_TRGT_POLICY_ID
                   AND ROWNUM = 1)*/;
    END IF;
    
    --2.1优先取模板政策对应的商品分类
    N_INSERT_ROWCOUNT := 0;
    S_STEP := '从模板政策获取商品分类';
    DELETE FROM T_POL_POLICY_MTL_TYPE T
     WHERE T.POLICY_ID = IN_TRGT_POLICY_ID;
    INSERT INTO T_POL_POLICY_MTL_TYPE
      SELECT S_POL_POLICY_MTL_TYPE.NEXTVAL
            ,IN_TRGT_POLICY_ID
            ,ITEM_ID
            ,ITEM_CODE
            ,ITEM_DESC
            ,ITEM_TYPE
            ,ITEM_STD
            ,CREATED_BY
            ,CREATION_DATE
            ,LAST_UPDATED_BY
            ,LAST_UPDATE_DATE
            ,SALES_CENTER_ID
            ,SALES_CENTER_CODE
            ,SALES_CENTER_NAME
            ,CUSTOMER_ID
            ,CUSTOMER_CODE
            ,CUSTOMER_NAME
            ,ACCOUNT_ID
            ,ACTUAL_QUANTITY
            ,ESTIMATED_QUANTITY
            ,ESTIMATED_ITEM_STD
        FROM T_POL_POLICY_MTL_TYPE T
       WHERE T.POLICY_ID = IN_SRC_POLICY_ID
         /*AND NOT EXISTS (SELECT 1
                FROM CIMS.T_POL_POLICY_MTL_TYPE
               WHERE POLICY_ID = IN_TRGT_POLICY_ID
                 AND ROWNUM = 1)*/;
    --2.2模板政策没有商品分类，则取其主政策对应的商品分类
    N_INSERT_ROWCOUNT := SQL%ROWCOUNT;
    IF S_SRC_PARENT_FLAG = 'N' AND N_INSERT_ROWCOUNT = 0 THEN
      S_STEP := '从模板政策的主政策获取商品分类';
      INSERT INTO T_POL_POLICY_MTL_TYPE
        SELECT S_POL_POLICY_MTL_TYPE.NEXTVAL
              ,IN_TRGT_POLICY_ID
              ,ITEM_ID
              ,ITEM_CODE
              ,ITEM_DESC
              ,ITEM_TYPE
              ,ITEM_STD
              ,CREATED_BY
              ,CREATION_DATE
              ,LAST_UPDATED_BY
              ,LAST_UPDATE_DATE
              ,SALES_CENTER_ID
              ,SALES_CENTER_CODE
              ,SALES_CENTER_NAME
              ,CUSTOMER_ID
              ,CUSTOMER_CODE
              ,CUSTOMER_NAME
              ,ACCOUNT_ID
              ,ACTUAL_QUANTITY
              ,ESTIMATED_QUANTITY
              ,ESTIMATED_ITEM_STD
          FROM T_POL_POLICY_MTL_TYPE T
         WHERE T.POLICY_ID = N_SRC_PAR_POLICY_ID
           /*AND NOT EXISTS (SELECT 1
                  FROM CIMS.T_POL_POLICY_MTL_TYPE
                 WHERE POLICY_ID = IN_TRGT_POLICY_ID
                   AND ROWNUM = 1)*/;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      OS_MESSAGE := '调用客户分类&商品分类导入过程-' || S_STEP ||'：' || SQLERRM;
  END P_IMPORT_CUS_MTL_TYPE;
  

  --根据EMS接口表数据生成返利单
  PROCEDURE P_EMS_INTF_TO_DISCOUNT_ORDER(IS_ORDER_DATE IN VARCHAR2
                                        ,OS_MESSAGE    OUT VARCHAR2) IS
    S_STEP VARCHAR2(100); --记录操作步骤
    S_FLAG VARCHAR2(20); --记录操作是否成功
    S_ERROR_INFO VARCHAR2(4000); --记录操作错误信息 
    N_INTF_ID NUMBER; --接口ID
    N_ORDER_TYPE NUMBER; --单据类型（1蓝单、2红单）

    V_SALES_CENTER_ID NUMBER;
    V_SALES_CENTER_NAME VARCHAR2(100);
    V_CUSTOMER_ID NUMBER;
    V_CUSTOMER_NAME VARCHAR2(300);
    V_ACCOUNT_ID NUMBER;
    V_ACCOUNT_CODE VARCHAR2(100);
    V_OU_ID VARCHAR2(32);
    
    V_DISCOUNT_METHOD VARCHAR2(32); --折让方式
    V_DISCOUNT_PATDEPT VARCHAR2(32); --支付来源
    V_DISCOUNT_ITEM  VARCHAR2(32); --折让项目
    
    V_ITEM_ID NUMBER; --虚拟产品ID
    V_ITEM_CODE VARCHAR2(100); --虚拟产品编码
    V_ITEM_NAME VARCHAR2(240); --虚拟产品名称
    V_AMOUNT NUMBER; --金额
    
    V_CK_CUSTOMER_ID NUMBER;
    V_CK_ACCOUNT_ID NUMBER;
    V_CK_SALES_MAIN_TYPE VARCHAR2(32);
    
    V_DISCOUNT_ORDER_ID T_POL_DISCOUNT_ORDER.DISCOUNT_ORDER_ID%TYPE;
    V_DISCOUNT_ORDER_NUMBER T_POL_DISCOUNT_ORDER.DISCOUNT_ORDER_NUMBER%TYPE;
    
    V_DISCOUNT_ORDER T_POL_DISCOUNT_ORDER%ROWTYPE;
    V_DISCOUNT_LINES T_POL_DISCOUNT_LINES%ROWTYPE;
    
    CURSOR C_INTF_DISCOUNT_ORDER IS
      SELECT *
        FROM EMS_INTF_POL_DISCOUNT_ORDER IP
       WHERE IP.ORDERED_DATE >= TO_DATE(IS_ORDER_DATE, 'YYYY-MM-DD')
         AND IP.PROCESS_STATUS = 'N';
  BEGIN
    OS_MESSAGE := 'SUCCESS';
    
    FOR C_ORDER IN C_INTF_DISCOUNT_ORDER LOOP
      S_FLAG := 'OK';
      S_ERROR_INFO := '';
      
      N_INTF_ID := C_ORDER.INTF_ID;
      N_ORDER_TYPE := C_ORDER.ORDER_TYPE_ID;
      
      S_STEP := '获取默认折让方式、支付来源&折让项目';
      BEGIN
        SELECT VU.CODE_VALUE
          INTO V_DISCOUNT_METHOD
          FROM CIMS.V_UP_CODELIST VU
         WHERE VU.ENTITY_ID = C_ORDER.ENTITY_ID
           AND VU.CODETYPE = 'EXPENSE_TO_POL_DISCOUNT_METHOD';
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          S_FLAG := 'CIMS_ERROR';
          S_ERROR_INFO := S_ERROR_INFO || 'CIMS未配置默认的折让方式;';
        WHEN TOO_MANY_ROWS THEN
          S_FLAG := 'CIMS_ERROR';
          S_ERROR_INFO := S_ERROR_INFO || 'CIMS码表[EXPENSE_TO_POL_DISCOUNT_METHOD]存在多个默认的折让方式;';
      END;
      BEGIN
        SELECT VU.CODE_VALUE
          INTO V_DISCOUNT_PATDEPT
          FROM CIMS.V_UP_CODELIST VU
         WHERE VU.ENTITY_ID = C_ORDER.ENTITY_ID
           AND VU.CODETYPE = 'EXPENSE_TO_POL_DISCOUNT_PATDEPT';
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          S_FLAG := 'CIMS_ERROR';
          S_ERROR_INFO := S_ERROR_INFO || 'CIMS未配置默认的支付来源;';
        WHEN TOO_MANY_ROWS THEN
          S_FLAG := 'CIMS_ERROR';
          S_ERROR_INFO := S_ERROR_INFO || 'CIMS码表[EXPENSE_TO_POL_DISCOUNT_PATDEPT]存在多个默认的支付来源;';
      END;
      BEGIN
        SELECT VU.CODE_VALUE
          INTO V_DISCOUNT_ITEM
          FROM CIMS.V_UP_CODELIST VU
         WHERE VU.ENTITY_ID = C_ORDER.ENTITY_ID
           AND VU.CODETYPE = 'EXPENSE_TO_POL_DISCOUNT_ITEM';
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          S_FLAG := 'CIMS_ERROR';
          S_ERROR_INFO := S_ERROR_INFO || 'CIMS未配置默认的折让项目;';
        WHEN TOO_MANY_ROWS THEN
          S_FLAG := 'CIMS_ERROR';
          S_ERROR_INFO := S_ERROR_INFO || 'CIMS码表[EXPENSE_TO_POL_DISCOUNT_ITEM]存在多个默认的折让项目;';
      END;
        
      S_STEP := '接口表数据非空校验';
      IF S_FLAG = 'OK' AND N_ORDER_TYPE = 1 THEN --正向单据
        IF C_ORDER.SALES_CENTER_CODE IS NULL THEN
          S_FLAG := 'SRC_ERROR';
          S_ERROR_INFO := S_ERROR_INFO || '营销中心不可为空;';
        END IF;
        IF C_ORDER.CUSTOMER_CODE IS NULL THEN
          S_FLAG := 'SRC_ERROR';
          S_ERROR_INFO := S_ERROR_INFO || '客户不可为空;';
        END IF;
        IF C_ORDER.ERP_OU_FLAG IS NULL THEN
          S_FLAG := 'SRC_ERROR';
          S_ERROR_INFO := S_ERROR_INFO || 'ERP_OU_FLAG不可为空;';
        ELSIF C_ORDER.ERP_OU_FLAG NOT IN ('Y', 'N') THEN
          S_FLAG := 'SRC_ERROR';
          S_ERROR_INFO := S_ERROR_INFO || 'ERP_OU_FLAG只能取值Y或N;';
        END IF;
        IF C_ORDER.OU_ID IS NULL THEN
          S_FLAG := 'SRC_ERROR';
          S_ERROR_INFO := S_ERROR_INFO || 'OU_ID不可为空;';
        END IF;
        IF C_ORDER.SALES_MAIN_TYPE IS NULL THEN
          S_FLAG := 'SRC_ERROR';
          S_ERROR_INFO := S_ERROR_INFO || '营销大类不可为空;';
        ELSE
          V_CK_SALES_MAIN_TYPE := C_ORDER.SALES_MAIN_TYPE;
        END IF;
        IF C_ORDER.AMOUNT IS NULL THEN
          S_FLAG := 'SRC_ERROR';
          S_ERROR_INFO := S_ERROR_INFO || '含税金额不可为空;';
        ELSIF C_ORDER.AMOUNT = 0 THEN
          S_FLAG := 'SRC_ERROR';
          S_ERROR_INFO := S_ERROR_INFO || '含税金额不可为零;';
        END IF;
        IF C_ORDER.TAX_RATE IS NULL THEN
          S_FLAG := 'SRC_ERROR';
          S_ERROR_INFO := S_ERROR_INFO || '税率不可为空;';
        ELSIF C_ORDER.TAX_RATE = 0 THEN
          S_FLAG := 'SRC_ERROR';
          S_ERROR_INFO := S_ERROR_INFO || '税率不可为零;';
        END IF;
      ELSIF S_FLAG = 'OK' AND N_ORDER_TYPE = 2 THEN --负向单据
        IF C_ORDER.OLD_SOURCE_ORDER_ID IS NULL THEN
          S_FLAG := 'SRC_ERROR';
          S_ERROR_INFO := S_ERROR_INFO || '原单据ID不可为空;';
        END IF;
        IF C_ORDER.OLD_SOURCE_ORDER_CODE IS NULL THEN
          S_FLAG := 'SRC_ERROR';
          S_ERROR_INFO := S_ERROR_INFO || '原单据号不可为空;';
        END IF;
      END IF;
      
      IF S_FLAG = 'OK' AND N_ORDER_TYPE = 1 THEN
        S_STEP := '正向单据获取有效账户信息';
        BEGIN
          SELECT V.SALES_CENTER_ID
                ,V.SALES_CENTER_NAME
                ,V.CUSTOMER_ID
                ,V.CUSTOMER_NAME
                ,V.ACCOUNT_ID
                ,V.ACCOUNT_CODE
            INTO V_SALES_CENTER_ID
                ,V_SALES_CENTER_NAME
                ,V_CUSTOMER_ID
                ,V_CUSTOMER_NAME
                ,V_ACCOUNT_ID
                ,V_ACCOUNT_CODE
            FROM V_CUSTOMER_ACCOUNT_SALECENTER V
           WHERE V.ENTITY_ID = C_ORDER.ENTITY_ID
             AND V.CUSTOMER_CODE = C_ORDER.CUSTOMER_CODE
             AND V.SALES_CENTER_CODE = C_ORDER.SALES_CENTER_CODE
             AND V.ACCOUNT_STATUS = '1' --取有效账户
          ;
          V_CK_CUSTOMER_ID := V_CUSTOMER_ID;
          V_CK_ACCOUNT_ID := V_ACCOUNT_ID;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            S_FLAG := 'CIMS_ERROR';
            S_ERROR_INFO := S_ERROR_INFO || '根据客户编码、中心编码获取有效账户失败：请在CIMS检查客户编码、中心编码是否正确或对应的账户是否有效;';
        END;
      END IF;
      
      IF S_FLAG = 'OK' AND N_ORDER_TYPE = 1 THEN
        IF C_ORDER.ERP_OU_FLAG = 'Y' THEN
          S_STEP := '正向单据校验ERP OU_ID';
          BEGIN
            SELECT DISTINCT V.CODE_VALUE
              INTO V_OU_ID
              FROM V_UP_CODELIST V
             WHERE V.CODETYPE = 'ar_ou_id'
               AND V.CODE_VALUE = C_ORDER.OU_ID
               AND V.ENTITY_ID = C_ORDER.ENTITY_ID
               AND V.ENABLED = '0';
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              S_FLAG := 'SRC_ERROR';
              S_ERROR_INFO := S_ERROR_INFO || 'OU_ID[' || C_ORDER.OU_ID || ']在CIMS不存在;';
            WHEN TOO_MANY_ROWS THEN
              S_FLAG := 'CIMS_ERROR';
              S_ERROR_INFO := S_ERROR_INFO || 'CIMS码表[ar_ou_id]存在多个相同OU_ID;';
          END;
        ELSIF C_ORDER.ERP_OU_FLAG = 'N' THEN
          S_STEP := '正向单据转换成ERP OU_ID';
          BEGIN
            SELECT DISTINCT T.ERP_OU_ID
              INTO V_OU_ID
              FROM CIMS.T_AR_OU_RELATION T
             WHERE T.NC_ORG_CODE = C_ORDER.OU_ID;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              IF (C_ORDER.OU_ID = C_ORDER.SALES_CENTER_CODE) THEN
                S_FLAG := 'SRC_ERROR';
              ELSE
                S_FLAG := 'CIMS_ERROR';
              END IF;
              S_ERROR_INFO := S_ERROR_INFO || '在CIMS根据组织单元[' || C_ORDER.OU_ID || ']未找到对应的ERP OU_ID;';
            WHEN TOO_MANY_ROWS THEN
              S_FLAG := 'CIMS_ERROR';
              S_ERROR_INFO := S_ERROR_INFO || '在CIMS根据组织单元[' || C_ORDER.OU_ID || ']找到多个对应的ERP OU_ID;';
          END;
        END IF;
      END IF;
      
      IF S_FLAG = 'OK' AND N_ORDER_TYPE = 2 THEN
        S_STEP := '负向单据校验是否可以生成红单';
        BEGIN
          SELECT DO.*
            INTO V_DISCOUNT_ORDER
            FROM T_POL_DISCOUNT_ORDER DO
           WHERE DO.SOURCE_ORDER_CODE = C_ORDER.OLD_SOURCE_ORDER_CODE
             AND DO.SOURCE_ORDER_ID = C_ORDER.OLD_SOURCE_ORDER_ID
             AND DO.SOURCE_SYSTEM = C_ORDER.SOURCE_SYSTEM;
          
          V_DISCOUNT_METHOD := V_DISCOUNT_ORDER.DISCOUNT_METHOD;
          V_CK_CUSTOMER_ID := V_DISCOUNT_ORDER.CUSTOMER_ID;
          V_CK_ACCOUNT_ID := V_DISCOUNT_ORDER.ACCOUNT_ID;
          V_CK_SALES_MAIN_TYPE := V_DISCOUNT_ORDER.SALES_MAIN_TYPE;
           
          IF V_DISCOUNT_ORDER.ORDER_TYPE_ID = 1 THEN
            SELECT L.*
              INTO V_DISCOUNT_LINES
              FROM T_POL_DISCOUNT_LINES L
             WHERE L.DISCOUNT_ORDER_ID = V_DISCOUNT_ORDER.DISCOUNT_ORDER_ID;

            IF V_DISCOUNT_LINES.REWARDED_AMOUNT IS NOT NULL
              AND V_DISCOUNT_LINES.REWARDED_AMOUNT != 0 THEN
              S_FLAG := 'SRC_ERROR';
              S_ERROR_INFO := S_ERROR_INFO || '原返利单已被红冲，不允许再次红冲;';
            END IF;
          ELSIF V_DISCOUNT_ORDER.ORDER_TYPE_ID = 2 THEN
            S_FLAG := 'SRC_ERROR';
            S_ERROR_INFO := S_ERROR_INFO || '原返利单就是红冲单，不允许对其红冲;';
          END IF;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            S_FLAG := 'SRC_ERROR';
            S_ERROR_INFO := S_ERROR_INFO || '原返利单不存在;';
        END;
      END IF;
      
      IF S_FLAG = 'OK' THEN
        S_STEP := '校验客户、账户、营销大类关系';
        PKG_CUST_CHECK.PKG_CUST_ACC_CHECK(C_ORDER.ENTITY_ID,
                                          V_CK_CUSTOMER_ID,
                                          V_CK_ACCOUNT_ID,
                                          V_CK_SALES_MAIN_TYPE,
                                          OS_MESSAGE);
        IF OS_MESSAGE != 'SUCCESS' THEN
          S_FLAG := 'SRC_ERROR';
          S_ERROR_INFO := S_ERROR_INFO || '在CIMS校验客户、账户、营销大类关系失败：' || OS_MESSAGE || ';';
        END IF;
        OS_MESSAGE := 'SUCCESS';
      END IF;
      
      IF S_FLAG = 'OK' THEN
        S_STEP := '获取虚拟产品信息';
        FOR C_ITEM_INFO IN (SELECT *
                              FROM T_BD_ITEM T
                             WHERE T.ENTITY_ID = C_ORDER.ENTITY_ID
                               AND T.IS_VIRTUAL = 'Y') LOOP
          IF C_ITEM_INFO.ITEM_CODE = 'Z0000000000001' AND
             V_DISCOUNT_METHOD IN ('4', '5') THEN
            V_ITEM_ID   := C_ITEM_INFO.ITEM_ID;
            V_ITEM_CODE := C_ITEM_INFO.ITEM_CODE;
            V_ITEM_NAME := C_ITEM_INFO.ITEM_NAME;
          END IF;
        
          IF C_ITEM_INFO.ITEM_CODE = 'Z0000000000002' AND
             V_DISCOUNT_METHOD IN ('1', '2', '3', '6', '7') THEN
            V_ITEM_ID   := C_ITEM_INFO.ITEM_ID;
            V_ITEM_CODE := C_ITEM_INFO.ITEM_CODE;
            V_ITEM_NAME := C_ITEM_INFO.ITEM_NAME;
          END IF;
        END LOOP;
        IF V_ITEM_ID IS NULL THEN
          S_FLAG := 'CIMS_ERROR';
          S_ERROR_INFO := S_ERROR_INFO || '获取虚拟产品信息失败：请检查CIMS虚拟产品;';
        END IF;
      END IF;
      
      /*
      1.savepoint名字保持唯一
      2.如果后面新设置的一个savepoint的名字和前面的一个savepoint名字重复，前一个savepoint将被取消
      3.设置savepoint后，事务可以继续commit，全部回退或者回退到具体一个savepoint
      (Savepoint names must be distinct within a given transaction.
      If you create a second savepoint with the same identifier as an earlier savepoint, then the earlier savepoint is erased.
      After a savepoint has been created, you can either continue processing, commit your work, roll back the entire transaction, or roll back to the savepoint.) 
      4.撤销的处理必须是在没有发出commit命令的前提下才能有效
      */
      SAVEPOINT SP;
      --写入正式表
      IF S_FLAG = 'OK' THEN
        SELECT S_POL_DISCOUNT_ORDER.NEXTVAL
          INTO V_DISCOUNT_ORDER_ID
          FROM DUAL;

        S_STEP := '生成返利单编码';
        V_DISCOUNT_ORDER_NUMBER := PKG_BD.F_GET_BILL_NO('POLDISCOUNT',
                                                        NULL,
                                                        C_ORDER.ENTITY_ID,
                                                        NULL);
                                                               
        S_STEP := '生成返利单';
        IF N_ORDER_TYPE = 1 THEN --正向单据根据接口数据生成
          --写入头表
          INSERT INTO T_POL_DISCOUNT_ORDER
            (DISCOUNT_ORDER_ID
            ,DISCOUNT_ORDER_NUMBER
            ,ENTITY_ID
            ,ORDERED_DATE
            ,ORDER_TYPE_ID
            ,DISCOUNT_METHOD
            ,DISCOUNT_PAY_DEPT
            ,DISCOUNT_ITEM
            ,SALES_MAIN_TYPE
            ,SALES_CENTER_ID
            ,SALES_CENTER_CODE
            ,SALES_CENTER_NAME
            ,CUSTOMER_ID
            ,CUSTOMER_CODE
            ,CUSTOMER_NAME
            ,ACCOUNT_ID
            ,ACCOUNT_CODE
            ,OU_ID
            ,STATUS
            ,REMARK
            ,CREATED_BY
            ,CREATION_DATE
            ,LAST_UPDATED_BY
            ,LAST_UPDATE_DATE
            ,CHECKED_BY
            ,CHECKED_DATE
            ,SOURCE_SYSTEM
            ,SOURCE_ORDER_ID
            ,SOURCE_ORDER_CODE)
          VALUES
            (V_DISCOUNT_ORDER_ID
            ,V_DISCOUNT_ORDER_NUMBER
            ,C_ORDER.ENTITY_ID
            ,TRUNC(C_ORDER.ORDERED_DATE)
            ,C_ORDER.ORDER_TYPE_ID
            ,V_DISCOUNT_METHOD
            ,V_DISCOUNT_PATDEPT
            ,V_DISCOUNT_ITEM
            ,C_ORDER.SALES_MAIN_TYPE
            ,V_SALES_CENTER_ID
            ,C_ORDER.SALES_CENTER_CODE
            ,V_SALES_CENTER_NAME
            ,V_CUSTOMER_ID
            ,C_ORDER.CUSTOMER_CODE
            ,V_CUSTOMER_NAME
            ,V_ACCOUNT_ID
            ,V_ACCOUNT_CODE
            ,V_OU_ID
            ,'6' --已审核
            ,C_ORDER.REMARK
            ,C_ORDER.CREATED_BY
            ,SYSDATE
            ,C_ORDER.CREATED_BY
            ,SYSDATE
            ,C_ORDER.CREATED_BY
            ,SYSDATE
            ,C_ORDER.SOURCE_SYSTEM
            ,C_ORDER.SOURCE_ORDER_ID
            ,C_ORDER.SOURCE_ORDER_CODE);
          
          --写入行表
          /*V_AMOUNT := ROUND(C_ORDER.AMOUNT / C_ORDER.TAX_RATE, 2);*/
          V_AMOUNT := C_ORDER.AMOUNT;
          INSERT INTO T_POL_DISCOUNT_LINES
            (LINE_ID
            ,DISCOUNT_ORDER_ID
            ,AMOUNT
            ,DISCOUNT_AMOUNT
            ,REWARDED_AMOUNT
            ,ITEM_ID
            ,ITEM_CODE
            ,ITEM_NAME
            ,CREATED_BY
            ,CREATION_DATE
            ,LAST_UPDATED_BY
            ,LAST_UPDATE_DATE)
          VALUES
            (S_POL_DISCOUNT_LINES.NEXTVAL
            ,V_DISCOUNT_ORDER_ID
            ,V_AMOUNT
            ,V_AMOUNT
            ,0
            ,V_ITEM_ID
            ,V_ITEM_CODE
            ,V_ITEM_NAME
            ,C_ORDER.CREATED_BY
            ,SYSDATE
            ,C_ORDER.CREATED_BY
            ,SYSDATE);
        ELSIF N_ORDER_TYPE = 2 THEN --负向单据根据原返利单生成
          --写入头表
          INSERT INTO T_POL_DISCOUNT_ORDER
            (DISCOUNT_ORDER_ID
            ,DISCOUNT_ORDER_NUMBER
            ,OLD_DISCOUNT_ID
            ,OLD_DISCOUNT_NUMBER
            ,ENTITY_ID
            ,ORDERED_DATE
            ,ORDER_TYPE_ID
            ,DISCOUNT_METHOD
            ,DISCOUNT_PAY_DEPT
            ,DISCOUNT_ITEM
            ,SALES_MAIN_TYPE
            ,SALES_CENTER_ID
            ,SALES_CENTER_CODE
            ,SALES_CENTER_NAME
            ,CUSTOMER_ID
            ,CUSTOMER_CODE
            ,CUSTOMER_NAME
            ,ACCOUNT_ID
            ,ACCOUNT_CODE
            ,OU_ID
            ,STATUS
            ,REMARK
            ,CREATED_BY
            ,CREATION_DATE
            ,LAST_UPDATED_BY
            ,LAST_UPDATE_DATE
            ,CHECKED_BY
            ,CHECKED_DATE
            ,SOURCE_SYSTEM
            ,SOURCE_ORDER_ID
            ,SOURCE_ORDER_CODE)
          VALUES
            (V_DISCOUNT_ORDER_ID 
            ,V_DISCOUNT_ORDER_NUMBER
            ,V_DISCOUNT_ORDER.DISCOUNT_ORDER_ID
            ,V_DISCOUNT_ORDER.DISCOUNT_ORDER_NUMBER
            ,C_ORDER.ENTITY_ID
            ,TRUNC(C_ORDER.ORDERED_DATE)
            ,C_ORDER.ORDER_TYPE_ID
            ,V_DISCOUNT_METHOD
            ,V_DISCOUNT_PATDEPT
            ,V_DISCOUNT_ITEM
            ,V_DISCOUNT_ORDER.SALES_MAIN_TYPE
            ,V_DISCOUNT_ORDER.SALES_CENTER_ID
            ,V_DISCOUNT_ORDER.SALES_CENTER_CODE
            ,V_DISCOUNT_ORDER.SALES_CENTER_NAME
            ,V_DISCOUNT_ORDER.CUSTOMER_ID
            ,V_DISCOUNT_ORDER.CUSTOMER_CODE
            ,V_DISCOUNT_ORDER.CUSTOMER_NAME
            ,V_DISCOUNT_ORDER.ACCOUNT_ID
            ,V_DISCOUNT_ORDER.ACCOUNT_CODE
            ,V_DISCOUNT_ORDER.OU_ID
            ,'6' --已审核
            ,C_ORDER.REMARK
            ,C_ORDER.CREATED_BY
            ,SYSDATE
            ,C_ORDER.CREATED_BY
            ,SYSDATE
            ,C_ORDER.CREATED_BY
            ,SYSDATE
            ,C_ORDER.SOURCE_SYSTEM
            ,C_ORDER.SOURCE_ORDER_ID
            ,C_ORDER.SOURCE_ORDER_CODE);
          
          --写入行表
          INSERT INTO T_POL_DISCOUNT_LINES
            (LINE_ID
            ,DISCOUNT_ORDER_ID
            ,AMOUNT
            ,DISCOUNT_AMOUNT
            ,REWARDED_AMOUNT
            ,OLD_DISCOUNT_AMOUNT
            ,ITEM_ID
            ,ITEM_CODE
            ,ITEM_NAME
            ,CREATED_BY
            ,CREATION_DATE
            ,LAST_UPDATED_BY
            ,LAST_UPDATE_DATE)
          VALUES
            (S_POL_DISCOUNT_LINES.NEXTVAL
            ,V_DISCOUNT_ORDER_ID
            ,0
            ,(0 - V_DISCOUNT_LINES.DISCOUNT_AMOUNT)
            ,(0 - V_DISCOUNT_LINES.DISCOUNT_AMOUNT)
            ,V_DISCOUNT_LINES.DISCOUNT_AMOUNT
            ,V_ITEM_ID
            ,V_ITEM_CODE
            ,V_ITEM_NAME
            ,C_ORDER.CREATED_BY
            ,SYSDATE
            ,C_ORDER.CREATED_BY
            ,SYSDATE);
          
          --更新原单
          UPDATE T_POL_DISCOUNT_LINES L
             SET L.AMOUNT          = 0
                ,L.REWARDED_AMOUNT = (0 - V_DISCOUNT_LINES.DISCOUNT_AMOUNT)
                ,L.VERSION = L.VERSION + 1
                ,L.LAST_UPDATE_DATE = SYSDATE
                ,L.LAST_UPDATED_BY = 'DISCOUNT_JOB'
           WHERE L.DISCOUNT_ORDER_ID = V_DISCOUNT_ORDER.DISCOUNT_ORDER_ID;
           
           /*BEGIN
             SYS.DBMS_OUTPUT.PUT_LINE(1 / 0);
           END;*/
        END IF;
      END IF;
        
      --更新接口表状态
      UPDATE EMS_INTF_POL_DISCOUNT_ORDER T
         SET T.PROCESS_STATUS = DECODE(S_FLAG, 'OK', 'S', 'E')
            ,T.PROCESS_MESSAGE = DECODE(S_FLAG, 'OK', 'SUCCESS', S_ERROR_INFO)
            ,T.LAST_UPDATE_DATE = SYSDATE
            ,T.LAST_UPDATED_BY = 'CIMS'
       WHERE T.INTF_ID = N_INTF_ID;
    END LOOP;
  EXCEPTION
    WHEN OTHERS THEN
      OS_MESSAGE := '生成返利单接口-' || S_STEP || '出错，错误代码：' || SQLCODE || '，错误信息：' || SQLERRM;
      ROLLBACK TO SP;
      
      --更新接口状态
      UPDATE EMS_INTF_POL_DISCOUNT_ORDER T
         SET T.PROCESS_STATUS = 'E'
            ,T.PROCESS_MESSAGE = OS_MESSAGE
            ,T.LAST_UPDATE_DATE = SYSDATE
            ,T.LAST_UPDATED_BY = 'CIMS'
       WHERE T.INTF_ID = N_INTF_ID;
  END P_EMS_INTF_TO_DISCOUNT_ORDER;

   --数据割接
    /*PROCEDURE P_DATA_CUTOVER(P_DATA_FLOW_ID IN NUMBER
                            ,P_ENTITY_ID    IN NUMBER
                            ,P_MESSAGE OUT VARCHAR2)IS
      P_DISCOUNT_METHOD NUMBER;   --折让方式
      P_DISCOUNT_PATDEPT NUMBER;  --支付来源
      P_DISCOUNT_ITEM NUMBER;     --折让项目
      P_POLICY_ID  NUMBER;        --政策ID
      P_SALES_CENTER_ID NUMBER;   --营销中心ID
      P_CUSTOMER_ID  NUMBER;      --客户ID
      P_ACCOUNT_ID  NUMBER;       --账户ID
      P_POL_TYPE_ID     NUMBER;      --政策类型ID
      POL_POLICY_LINE_ID NUMBER;   --政策行表ID
      P_BUDGET_SEGMENT_01_ID NUMBER;
      P_BUDGET_SEGMENT_01_NAME VARCHAR2(100);
      P_BUDGET_SEGMENT_02_ID NUMBER;
      P_BUDGET_SEGMENT_02_NAME VARCHAR2(100);
      P_BUDGET_SEGMENT_03_ID  NUMBER;
      P_BUDGET_SEGMENT_03_NAME VARCHAR2(100);
      P_BUDGET_SEGMENT_04_ID NUMBER;
      P_BUDGET_SEGMENT_04_NAME VARCHAR2(100);
      P_BUDGET_SEGMENT_05_ID NUMBER;
      P_BUDGET_SEGMENT_05_NAME VARCHAR2(100);
      P_BUDGET_SEGMENT_06_ID  NUMBER;
      P_POL_ORDER_HEADERS_SEQUENCE NUMBER;


       CURSOR C_POL_DATA_TEMP IS
        SELECT *
        FROM T_POL_DATA_TEMP PL;
             R_POL_DATA_TEMP C_POL_DATA_TEMP%ROWTYPE;

      BEGIN
        P_MESSAGE := 'OK';

         OPEN C_POL_DATA_TEMP;
          LOOP
          FETCH C_POL_DATA_TEMP
           INTO R_POL_DATA_TEMP;

           EXIT WHEN C_POL_DATA_TEMP%NOTFOUND;

           --折让方式
           BEGIN
           SELECT PE.CODE_VALUE--PA.CODE_VALUE
             INTO P_DISCOUNT_METHOD
             FROM UP_CODELIST PA,
                  UP_CODELIST_ENTITY PE
            WHERE PA.CODETYPE = 'POL_DISCOUNT_METHOD'
              AND PA.CODE_NAME = R_POL_DATA_TEMP.DISCOUNT_METHOD
              AND PA.ID = PE.CODELIST_ID
              AND PE.ENTITY_ID = P_ENTITY_ID;
              END;

           --支付来源
           BEGIN
            SELECT PE.CODE_VALUE
              INTO P_DISCOUNT_PATDEPT
              FROM UP_CODELIST PA,
                  UP_CODELIST_ENTITY PE
             WHERE PA.CODETYPE = 'POL_DISCOUNT_PATDEPT'
               AND PA.CODE_NAME = R_POL_DATA_TEMP.DISCOUNT_PAY_DEPT
               AND PA.ID = PE.CODELIST_ID
                AND PE.ENTITY_ID = P_ENTITY_ID;
               END;

           --折让项目
           BEGIN
             SELECT PE.CODE_VALUE
              INTO P_DISCOUNT_ITEM
              FROM UP_CODELIST PA,
                  UP_CODELIST_ENTITY PE
             WHERE PA.CODETYPE = 'POL_DISCOUNT_ITEM'
               AND PA.CODE_NAME = R_POL_DATA_TEMP.DISCOUNT_ITEM
               AND PA.ID = PE.CODELIST_ID
               AND PE.ENTITY_ID = P_ENTITY_ID
               AND ROWNUM = 1;
               END;

          --政策ID
          BEGIN
          SELECT S_POL_POLICY.NEXTVAL
            INTO P_POLICY_ID
            FROM DUAL;
            END;

          --营销中心ID
          BEGIN
          SELECT PB.SALES_CENTER_ID
            INTO P_SALES_CENTER_ID
            FROM T_CUSTOMER_ORG PB
           WHERE PB.SALES_CENTER_CODE = R_POL_DATA_TEMP.SALES_CENTER_CODE
             AND PB.ENTITY_ID = P_ENTITY_ID
             AND ROWNUM = 1;
             END;

         --客户ID
         BEGIN
          SELECT PB.CUSTOMER_ID
            INTO P_CUSTOMER_ID
            FROM T_CUSTOMER_ORG PB
           WHERE PB.CUSTOMER_CODE = R_POL_DATA_TEMP.CUSTOMER_CODE
             AND PB.ENTITY_ID = P_ENTITY_ID
             AND ROWNUM = 1;
             END;

         --账户ID
          BEGIN
            SELECT DISTINCT(T.ACCOUNT_ID)
                  INTO P_ACCOUNT_ID
                  FROM V_CUST_ACCOUNT T
                 WHERE T.CUSTOMER_CODE = R_POL_DATA_TEMP.CUSTOMER_CODE
                   AND T.SALES_CENTER_CODE = R_POL_DATA_TEMP.SALES_CENTER_CODE
                   AND T.entity_id = P_ENTITY_ID
                   AND ROWNUM = 1;
              EXCEPTION
                  WHEN OTHERS THEN
                    BEGIN
                       --记录出错信息
                       P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_SYNC_APPROVAL_APPLICATION.P_GET_EMS_ORDERINFO',
                                                                                   sqlcode,
                                                                                   '账户信息异常：'||sqlerrm);
                       COMMIT;
                  GOTO HEADER;
             END;
           END;

           --政策类型ID
           BEGIN
           SELECT PQ.APPLY_TYPE_ID
             INTO P_POL_TYPE_ID
             FROM T_POL_TYPE PQ
            WHERE PQ.APPLY_TYPE_NAME = R_POL_DATA_TEMP.POLICY_TYPE
              and PQ.ENTITY_ID = P_ENTITY_ID;
            END;


            --插入政策申请表
            INSERT INTO T_POL_POLICY
             (
               POLICY_ID
              ,POLICY_NUMBER
              ,POLICY_NAME
              ,COMMENTS
              ,POLICY_ORDER_NUMBER
              ,STATUS
              ,SALES_CENTER_ID
              ,SALES_CENTER_CODE
              ,SALES_CENTER_NAME
              ,BEGIN_DATE
              ,REQUIS_DEPT_CODE
              ,REQUIS_DEPT_NAME
              ,CUSTOMER_ID
              ,CUSTOMER_CODE
              ,CUSTOMER_NAME
              ,ACCOUNT_ID
              ,DISCOUNT_PAY_DEPT
              ,DISCOUNT_METHOD
              ,DISCOUNT_ITEM
              ,STD_STEP_FLAG
              ,DOC_LAND_AMOUNT
              ,ENTITY_ID
              ,POLICY_TYPE_ID
              ,CREATED_BY
              ,CREATION_DATE
              ,ORDER_DATE
              ,SALES_MAIN_TYPE
              ,AUTO_FLAG
              ,DATA_FLOW_ID
             )VALUES(
               P_POLICY_ID
              ,R_POL_DATA_TEMP.Policy_Number
              ,R_POL_DATA_TEMP.Policy_Name
              ,R_POL_DATA_TEMP.Comments
              ,R_POL_DATA_TEMP.Policy_Order_Number
              ,'6'
              ,P_SALES_CENTER_ID
              ,R_POL_DATA_TEMP.Sales_Center_Code
              ,R_POL_DATA_TEMP.Sales_Center_Name
              ,R_POL_DATA_TEMP.Order_Date
              ,R_POL_DATA_TEMP.Customer_Code
              ,R_POL_DATA_TEMP.Customer_Name
              ,P_CUSTOMER_ID
              ,R_POL_DATA_TEMP.Customer_Code
              ,R_POL_DATA_TEMP.Customer_Name
              ,P_ACCOUNT_ID
              ,P_DISCOUNT_PATDEPT
              ,P_DISCOUNT_METHOD
              ,P_DISCOUNT_ITEM
              ,'Y'
              ,R_POL_DATA_TEMP.DOC_LAND_AMOUNT
              ,P_ENTITY_ID
              ,P_POL_TYPE_ID
              ,'ADMIN'
              ,SYSDATE
              ,R_POL_DATA_TEMP.ORDER_DATE
              ,R_POL_DATA_TEMP.SALES_MAIN_TYPE
              ,'N'
              ,P_DATA_FLOW_ID
             );

             --政策申请单行表ID
             SELECT S_POL_POLICY_LINE.NEXTVAL
               INTO POL_POLICY_LINE_ID
               FROM DUAL;

             --预算第一层ID\名称
             SELECT P1.BUDGET_YEAR_ID,
                    P1.BUDGET_YEAR_NAME
               INTO P_BUDGET_SEGMENT_01_ID,
                    P_BUDGET_SEGMENT_01_NAME
               FROM T_POL_BUDGET_YEAR P1
              WHERE P1.BUDGET_YEAR_CODE = R_POL_DATA_TEMP.SALES_YEAR
                AND P1.ENTITY_ID = P_ENTITY_ID;


              --预算第二层
              SELECT P2.UNIT_ID,
                     P2.NAME
                INTO P_BUDGET_SEGMENT_02_ID,
                     P_BUDGET_SEGMENT_02_NAME
                FROM UP_ORG_UNIT P2
               WHERE P2.CODE = R_POL_DATA_TEMP.ORGANIZATIONS
                 AND P2.ENTITY_ID = P_ENTITY_ID;

             --预算第三层
             SELECT P3.ITEM_CLASS_ID,
                    P3.CLASS_NAME
               INTO P_BUDGET_SEGMENT_03_ID,
                    P_BUDGET_SEGMENT_03_NAME
               FROM T_BD_ITEM_CLASS P3
              WHERE P3.CLASS_TYPE = 'M'
                AND P3.PARENTC_LASS_ID = '0'
                AND P3.CLASS_CODE = R_POL_DATA_TEMP.SALES_MAIN_TYPE
                AND P3.ENTITY_ID = P_ENTITY_ID;

              --预算第四层
              SELECT P4.POLICY_TYPE_ID,
                     P4.POLICY_TYPE_NAME
                INTO P_BUDGET_SEGMENT_04_ID,
                     P_BUDGET_SEGMENT_04_NAME
                FROM T_POL_POLICY_TYPE P4
               WHERE P4.POLICY_TYPE_CODE = R_POL_DATA_TEMP.POLICY_MAIN_TYPE
                 AND P4.ENTITY_ID = P_ENTITY_ID;

              --预算第五层
              SELECT P5.POLICY_SECTION_ID,
                     P5.POLICY_SECTION_NAME
                INTO P_BUDGET_SEGMENT_05_ID,
                     P_BUDGET_SEGMENT_05_NAME
                FROM T_POL_POLICY_SECTION P5
               WHERE P5.POLICY_SECTION_CODE = R_POL_DATA_TEMP.POLICY_DETAIL_TYPE
                 AND P5.ENTITY_ID = P_ENTITY_ID;

             --政策申请行表
             INSERT INTO T_POL_POLICY_LINE
             (
               detail_id
              ,entity_id
              ,policy_id
              ,pol_amount
              ,budget_segment_01_id
              ,budget_segment_01_code
              ,budget_segment_01_name
              ,budget_segment_02_id
              ,budget_segment_02_code
              ,budget_segment_02_name
              ,budget_segment_03_id
              ,budget_segment_03_code
              ,budget_segment_03_name
              ,budget_segment_04_id
              ,budget_segment_04_code
              ,budget_segment_04_name
              ,budget_segment_05_id
              ,budget_segment_05_code
              ,budget_segment_05_name
              ,created_by
              ,creation_date
             )VALUES(
               POL_POLICY_LINE_ID
              ,P_ENTITY_ID
              ,P_POLICY_ID
              ,R_POL_DATA_TEMP.DOC_LAND_AMOUNT
              ,P_BUDGET_SEGMENT_01_ID
              ,R_POL_DATA_TEMP.SALES_YEAR
              ,P_BUDGET_SEGMENT_01_NAME
              ,P_BUDGET_SEGMENT_02_ID
              ,R_POL_DATA_TEMP.ORGANIZATIONS
              ,P_BUDGET_SEGMENT_02_NAME
              ,P_BUDGET_SEGMENT_03_ID
              ,R_POL_DATA_TEMP.SALES_MAIN_TYPE
              ,P_BUDGET_SEGMENT_03_NAME
              ,P_BUDGET_SEGMENT_04_ID
              ,R_POL_DATA_TEMP.POLICY_MAIN_TYPE
              ,P_BUDGET_SEGMENT_04_NAME
              ,P_BUDGET_SEGMENT_05_ID
              ,R_POL_DATA_TEMP.POLICY_DETAIL_TYPE
              ,P_BUDGET_SEGMENT_05_NAME
              ,'ADMIN'
              ,SYSDATE
             );

             --占用预算
              PKG_BUDGET.P_WRITE_FEE(P_DATA_FLOW_ID,
                                  P_ENTITY_ID,
                                  NVL(P_BUDGET_SEGMENT_01_ID, -1),
                                  NVL(P_BUDGET_SEGMENT_02_ID, -1),
                                  NVL(P_BUDGET_SEGMENT_03_ID, -1),
                                  NVL(P_BUDGET_SEGMENT_04_ID, -1),
                                  NVL(P_BUDGET_SEGMENT_05_ID, -1),
                                  NVL(P_BUDGET_SEGMENT_06_ID, -1),
                                  '政策申请',                                  --费用类型
                                  POL_POLICY_LINE_ID,
                                  R_POL_DATA_TEMP.POLICY_NUMBER,
                                  NULL,
                                  NULL,
                                  R_POL_DATA_TEMP.DOC_LAND_AMOUNT ,
                                  1,
                                  P_MESSAGE);

             --Y单

             --Y单头表序列
             SELECT S_POLICY_Y_HEADERS.NEXTVAL
               INTO P_POL_ORDER_HEADERS_SEQUENCE
               FROM DUAL;

             INSERT INTO T_POL_ORDER_HEADERS
             (
                 policy_order_id
                ,entity_id
                ,policy_order_number
                ,order_date
                ,stauts
                ,policy_id
                ,policy_name
                ,sales_center_id
                ,sales_center_code
                ,sales_center_name
                ,policy_amount
                ,customer_id
                ,customer_code
                ,customer_name
                ,account_id
                ,discount_pay_dept
                ,discount_method
                ,discount_item
                ,created_by
                ,creation_date
                ,POLICY_NUMBER
                ,last_updated_by
                ,last_update_date
                ,source_id
             )VALUES(
                P_POL_ORDER_HEADERS_SEQUENCE
               ,P_ENTITY_ID
               ,R_POL_DATA_TEMP.POLICY_ORDER_NUMBER
               ,R_POL_DATA_TEMP.ORDER_DATE
               ,'5'
               ,P_POLICY_ID
               ,R_POL_DATA_TEMP.POLICY_NAME
               ,P_SALES_CENTER_ID
               ,R_POL_DATA_TEMP.SALES_CENTER_CODE
               ,R_POL_DATA_TEMP.SALES_CENTER_NAME
               ,R_POL_DATA_TEMP.DOC_LAND_AMOUNT
               ,P_CUSTOMER_ID
               ,R_POL_DATA_TEMP.CUSTOMER_CODE
               ,R_POL_DATA_TEMP.CUSTOMER_NAME
               ,P_ACCOUNT_ID
               ,P_DISCOUNT_PATDEPT
               ,P_DISCOUNT_METHOD
               ,P_DISCOUNT_ITEM
               ,'ADMIN'
               ,SYSDATE
               ,R_POL_DATA_TEMP.POLICY_NUMBER
               ,'ADMIN'
               ,sysdate
               ,POL_POLICY_LINE_ID
             );

              <<HEADER>>
              NULL;
              END LOOP;
             CLOSE C_POL_DATA_TEMP;
          END;  */

END PKG_POL_POLICY;
/

