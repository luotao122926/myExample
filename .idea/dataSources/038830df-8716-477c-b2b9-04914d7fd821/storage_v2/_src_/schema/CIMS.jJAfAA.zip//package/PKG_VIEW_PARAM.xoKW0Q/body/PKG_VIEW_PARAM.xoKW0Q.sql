create package body pkg_view_param IS
  v_Entity_Id NUMBER;
  v_Customer_Code varchar2(4000);
  v_Sales_Center_Code varchar2(4000);
  v_Item_Code VARCHAR2(100);

  function set_Entity_Id(p_Entity_Id number) return NUMBER IS
  BEGIN
    v_Entity_Id := p_Entity_Id;
    RETURN p_Entity_Id;
  END;
  function get_Entity_Id return NUMBER IS
  BEGIN
    RETURN v_Entity_Id;
  END;
  
  function set_Customer_Code(p_Customer_Code varchar2) return VARCHAR2 IS
  BEGIN
    v_Customer_Code := p_Customer_Code;
    RETURN p_Customer_Code;
  END; 
  function get_Customer_Code return VARCHAR2 IS
  BEGIN
    RETURN v_Customer_Code;
  END;
  
  function set_Sales_Center_Code(p_Sales_Center_Code varchar2) return VARCHAR2 IS
  BEGIN
    v_Sales_Center_Code := p_Sales_Center_Code;
    RETURN p_Sales_Center_Code;
  END; 
  function get_Sales_Center_Code return VARCHAR2 IS
  BEGIN
    RETURN v_Sales_Center_Code;
  END;
  
  function set_Item_Code(p_Item_code varchar2) return VARCHAR2 IS
  BEGIN
    v_Item_Code := p_Item_code;
    RETURN p_Item_Code;
  END; 
  function get_Item_Code return VARCHAR2 IS
  BEGIN
    RETURN v_Item_Code;
  END;
end pkg_view_param;
/

