create type        SYS_PLSQL_103003_57_1 as table of "CIMS"."SYS_PLSQL_103003_9_1";
/

