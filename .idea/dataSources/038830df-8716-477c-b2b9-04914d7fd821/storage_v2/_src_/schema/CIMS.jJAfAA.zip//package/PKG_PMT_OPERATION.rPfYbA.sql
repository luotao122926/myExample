create PACKAGE PKG_PMT_OPERATION IS

  PMT_EXCEPTION EXCEPTION; --自定义异常

  V_RESULT VARCHAR2(20) := '1'; --成功标记

  V_RESULT_MSG VARCHAR2(1000) := 'success'; --成功返回信息

  V_CLOSE_STATUS VARCHAR2(30) := '06'; --订单关闭状态

  V_CREATE_STATUS VARCHAR2(30) := '00'; --订单制单状态

  V_CRIDIT_STATUS VARCHAR2(30) := '02'; --订单审核通过状态

  V_ZX_STATUS VARCHAR2(30) := '03'; --订单已执行状态

  /**
  * 中转单红冲回写数量
  **/
  PROCEDURE P_ORDER_WRITEBACK_AMOUNT_RED(I_PO_NUMBER IN T_INV_PO_HEADERS.PO_NUM%TYPE, --中转单单号
                                         I_ENTITY_ID IN NUMBER, --实体ID
                                         O_FLAG      OUT VARCHAR2, --返回值
                                         O_FLAG_MSG  OUT VARCHAR2 --返回信息
                                         );
  /**
  * 关闭推广物料采购申请单
  **/
  PROCEDURE P_CLOSE_PMT_ORDER(I_ORDER_ID  IN T_PMT_ORDER_HEADER.ORDER_HEAD_ID%TYPE, --采购头表ID
                              I_OPER_TYPE IN VARCHAR2,
                              I_ENTITY_ID IN NUMBER, --实体ID
                              O_FLAG      OUT VARCHAR2, --返回值
                              O_FLAG_MSG  OUT VARCHAR2 --返回信息
                              );
  /**
    释放政策预算费用
  */
  PROCEDURE P_UNOCCUPY_BUDGET(I_ORDER_ID   IN T_PMT_ORDER_HEADER.ORDER_HEAD_ID%TYPE, --采购头表ID
                              I_FEE_AMOUNT IN NUMBER,
                              I_ENTITY_ID  IN NUMBER, --实体ID
                              O_FLAG       OUT VARCHAR2, --返回值
                              O_FLAG_MSG   OUT VARCHAR2 --返回信息
                              );
  /**
    重算采购单占用预算金额
  */
  PROCEDURE P_RESET_OCCUPY_BUDGET(I_ORDER_ID IN T_PMT_ORDER_HEADER.ORDER_HEAD_ID%TYPE,
                                  O_FLAG     OUT VARCHAR2, --返回值
                                  O_FLAG_MSG OUT VARCHAR2 --返回信息
                                  );
END PKG_PMT_OPERATION;
/

