create PACKAGE BODY PKG_INV_IO_ERP AS

  -----------------------------------------------------------------------------
  --      将引接口出错的内容重新引ERP  
  -- 不区分主体，全部处理                                       
  -- 通过参数将出错信息返回给调用程序，用于非系统自动执行的调用。
  -- 考虑两个数据库的表关联会影响性能，故使用循环检查处理
  -----------------------------------------------------------------------------
  PROCEDURE P_ICP_ORDER_REDO
  (
    OS_MESSAGE OUT VARCHAR2         --返回信息，成功则返回“OK”，否则返回出错信息
  )
  IS
    S_STEP             VARCHAR2(50);
    N_CNT              NUMBER;
  BEGIN
    SAVEPOINT SP;
    OS_MESSAGE := 'OK';
    
    --取出有问题的接口内容，并锁表
    --现SOURCE_CODE为空，故不能使用作为判断
    FOR R_ICP_ORDER IN
    (
      SELECT
        ID
        ,SOURCE_ORDERS
      FROM
        INTF_CUX_ICP_ORDER_REQ_HEADERS
      WHERE
        RESPONSETYPE IN ('W','E')
        AND STATUS = 'P'
      FOR UPDATE NOWAIT
    )
    LOOP
      --检查是否存在对应的单据
      S_STEP := '检查是否存在单据(ID=' || TO_CHAR(R_ICP_ORDER.ID) || ')';
      SELECT
        COUNT(*)
      INTO
        N_CNT
      FROM
        CUX_ICP_ORDER_REQ_HEADERS_V
      WHERE
        SOURCE_CODE = 'CIMS'
        AND SOURCE_ORDERS = R_ICP_ORDER.SOURCE_ORDERS;
      
      --不存在对应单据则更新状态
      IF N_CNT = 0 THEN
        S_STEP := '更新状态(ID=' || TO_CHAR(R_ICP_ORDER.ID) || ')';
        UPDATE
          INTF_CUX_ICP_ORDER_REQ_HEADERS
        SET
          STATUS = 'N' 
        WHERE
          ID = R_ICP_ORDER.ID
          AND RESPONSETYPE IN ('W','E');           
      ELSE
        --已存在则更新状态为S
        S_STEP := '更新状态(ID=' || TO_CHAR(R_ICP_ORDER.ID) || ')';
        UPDATE
          INTF_CUX_ICP_ORDER_REQ_HEADERS
        SET
          STATUS = 'S' 
        WHERE
          ID = R_ICP_ORDER.ID
          AND RESPONSETYPE IN ('W','E');           
      END IF;
    END LOOP;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK TO SAVEPOINT SP;
      IF SUBSTRB(SQLERRM,1,9) = 'ORA-00054' THEN
        OS_MESSAGE := '单据重引锁定接口不成功！请稍后再试。';
      ELSE
        OS_MESSAGE := '单据重引接口-'|| S_STEP || ':' || SQLERRM;
      END IF;
  END P_ICP_ORDER_REDO;

  -----------------------------------------------------------------------------
  --      将物流引接口出错的内容重新引ERP  
  -- 不区分主体，全部处理                                       
  -- 通过参数将出错信息返回给调用程序，用于非系统自动执行的调用。
  -- 考虑两个数据库的表关联会影响性能，故使用循环检查处理
  -- 物流发货、接收是同一条记录，都放到INTF_CUX_ICP_LOGIST_REQ_HEADER
  -- STATUS_SUPPLIER、STATUS_RECEIVE：N待发送；P已发送
  -- STATUS: STATUS_SUPPLIER = 'P'表示已完成发货处理，该状态为接收使用的状态（P/S）；否则为发货使用（N/P/S）
  -- RESPONSECODE_1:'00000'表示ERP已成功处理发货
  -- RESPONSECODE_2:'00000'表示ERP已成功处理接收
  -----------------------------------------------------------------------------
  PROCEDURE P_ICP_LOGIST_REDO
  (
    OS_MESSAGE OUT VARCHAR2         --返回信息，成功则返回“OK”，否则返回出错信息
  )
  IS
    S_STEP             VARCHAR2(50);
    N_CNT              NUMBER;
  BEGIN
    SAVEPOINT SP;
    OS_MESSAGE := 'OK';
    
    --取出有问题的接口内容，并锁表
    --RESPONSETYPE_1:发货确认返回状态：N成功; E失败; W警告
    --REQUIREMENT_SYSTEM为空，不能作为判断条件
    FOR R_ICP_LOGIST IN
    (
      SELECT
        ID
        ,REQUIREMENT_ORDER_NUM
        ,STATUS_SUPPLIER
        ,STATUS_RECEIVE
        ,REQUIREMENT_ORDER_TYPE REQ_ORDER_TYPE
        ,DECODE(RESPONSETYPE_1,'N','CIMS-RECEIVE','CIMS-SEND') REQUIREMENT_ORDER_TYPE  --发货成功，表示接收出错
      FROM
        INTF_CUX_ICP_LOGIST_REQ_HEADER
      WHERE
        RESPONSETYPE_1 IN ('E','W')
        OR RESPONSETYPE_2 IN ('E','W')
      FOR UPDATE NOWAIT
    )
    LOOP
        
      IF R_ICP_LOGIST.REQUIREMENT_ORDER_TYPE = 'CIMS-SEND' THEN
        --物流发货处理
        --检查是否存在对应的单据
        S_STEP := '检查是否存在发货物流(ID=' || TO_CHAR(R_ICP_LOGIST.ID) || ')';
        SELECT
          COUNT(*)
        INTO
          N_CNT
        FROM
          CUX_ICP_LOGIST_REQ_HEADERS_V
        WHERE
          REQUIREMENT_ORDER_NUM = R_ICP_LOGIST.REQUIREMENT_ORDER_NUM
          AND REQUIREMENT_ORDER_TYPE = 'CIMS-SEND';
          
        --01:异步物流
        IF R_ICP_LOGIST.REQ_ORDER_TYPE = '01' THEN
          --不存在对应单据则更新状态
          IF N_CNT = 0 THEN
            S_STEP := '发货更新状态(ID=' || TO_CHAR(R_ICP_LOGIST.ID) || ')';
            UPDATE
              INTF_CUX_ICP_LOGIST_REQ_HEADER
            SET
              STATUS = 'P'
              ,STATUS_SUPPLIER = 'N' 
            WHERE
              ID = R_ICP_LOGIST.ID
              AND REQUIREMENT_ORDER_NUM = R_ICP_LOGIST.REQUIREMENT_ORDER_NUM;           
          ELSE
            --存在则更新为已成功引入
            UPDATE
              INTF_CUX_ICP_LOGIST_REQ_HEADER
            SET
              STATUS = 'S'
              ,STATUS_SUPPLIER = 'P' 
              ,RESPONSETYPE_1 = 'N'
            WHERE
              ID = R_ICP_LOGIST.ID
              AND REQUIREMENT_ORDER_NUM = R_ICP_LOGIST.REQUIREMENT_ORDER_NUM;           
          END IF;
        ELSIF R_ICP_LOGIST.REQ_ORDER_TYPE = '02' THEN
          --02:同步物流
          IF N_CNT = 0 THEN
            --不存在对应单据则更新状态
            S_STEP := '发货更新状态(ID=' || TO_CHAR(R_ICP_LOGIST.ID) || ')';
            UPDATE
              INTF_CUX_ICP_LOGIST_REQ_HEADER
            SET
              STATUS = NULL
              ,STATUS_SOURCE = 'N' 
            WHERE
              ID = R_ICP_LOGIST.ID
              AND REQUIREMENT_ORDER_NUM = R_ICP_LOGIST.REQUIREMENT_ORDER_NUM;           
          ELSE
            --存在则更新为已成功引入
            UPDATE
              INTF_CUX_ICP_LOGIST_REQ_HEADER
            SET
              STATUS = 'S'
              ,STATUS_SOURCE = 'P' 
              ,RESPONSETYPE_1 = 'N'
            WHERE
              ID = R_ICP_LOGIST.ID
              AND REQUIREMENT_ORDER_NUM = R_ICP_LOGIST.REQUIREMENT_ORDER_NUM;           
          END IF;
        END IF;
      ELSE  --R_ICP_LOGIST.REQUIREMENT_ORDER_TYPE = 'CIMS-RECEIVE'
        --物流接收处理
        --检查是否存在对应的单据
        S_STEP := '检查是否存在物流接收(ID=' || TO_CHAR(R_ICP_LOGIST.ID) || ')';
        SELECT
          COUNT(*)
        INTO
          N_CNT
        FROM
          CUX_ICP_LOGIST_REQ_HEADERS_V
        WHERE
          REQUIREMENT_ORDER_NUM = R_ICP_LOGIST.REQUIREMENT_ORDER_NUM
          AND REQUIREMENT_ORDER_TYPE = 'CIMS-RECEIVE';
          
        --不存在对应单据则更新状态
        IF N_CNT = 0 THEN
          S_STEP := '接收更新状态(ID=' || TO_CHAR(R_ICP_LOGIST.ID) || ')';
          UPDATE
            INTF_CUX_ICP_LOGIST_REQ_HEADER
          SET
            STATUS = 'P'
            ,STATUS_RECEIVE = 'N' 
          WHERE
            ID = R_ICP_LOGIST.ID
            AND REQUIREMENT_ORDER_NUM = R_ICP_LOGIST.REQUIREMENT_ORDER_NUM
            AND RESPONSETYPE_1 = 'N'
            AND STATUS_SUPPLIER = 'P';           
        ELSE
          --存在则更新为已成功引入
          UPDATE
            INTF_CUX_ICP_LOGIST_REQ_HEADER
          SET
            RESPONSETYPE_2 = 'N'
          WHERE
            ID = R_ICP_LOGIST.ID
            AND REQUIREMENT_ORDER_NUM = R_ICP_LOGIST.REQUIREMENT_ORDER_NUM;           
        END IF;
      END IF;
    END LOOP;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK TO SAVEPOINT SP;
      IF SUBSTRB(SQLERRM,1,9) = 'ORA-00054' THEN
        OS_MESSAGE := '物流重引锁定接口不成功！请稍后再试。';
      ELSE
        OS_MESSAGE := '物流重引接口-'|| S_STEP || ':' || SQLERRM;
      END IF;
  END P_ICP_LOGIST_REDO;

  -----------------------------------------------------------------------------
  --      将引接口出错的内容重新引ERP(包含单据、物流重引接口)  
  -- 不区分主体，全部处理                                       
  -- 通过跟踪表记录出错信息，用于系统自动执行的调用。
  -----------------------------------------------------------------------------
  PROCEDURE P_AUTO_ICP_ORDER_REDO
  IS
    S_MESSAGE VARCHAR2(1000);
    S_MSG     VARCHAR2(1000);
  BEGIN
    --调用单据重新引接口
    P_ICP_ORDER_REDO(S_MESSAGE);
    --将出错信息抛出异常
    IF S_MESSAGE <> 'OK' THEN
      ROLLBACK;
      S_MSG := PKG_BD.F_ADD_ERROR_LOG('PKG_INV_IO_ERP.P_AUTO_ICP_ORDER_REDO', NULL, S_MESSAGE);
    ELSE
      COMMIT;
    END IF;

    --调用物流重新引接口
    P_ICP_LOGIST_REDO(S_MESSAGE);
    --将出错信息抛出异常
    IF S_MESSAGE <> 'OK' THEN
      ROLLBACK;
      S_MSG := PKG_BD.F_ADD_ERROR_LOG('PKG_INV_IO_ERP.P_AUTO_ICP_ORDER_REDO', NULL, S_MESSAGE);
    ELSE
      COMMIT;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      S_MSG := PKG_BD.F_ADD_ERROR_LOG('PKG_INV_IO_ERP.P_AUTO_ICP_ORDER_REDO', NULL, SQLERRM);
  END P_AUTO_ICP_ORDER_REDO;

END PKG_INV_IO_ERP;
/

