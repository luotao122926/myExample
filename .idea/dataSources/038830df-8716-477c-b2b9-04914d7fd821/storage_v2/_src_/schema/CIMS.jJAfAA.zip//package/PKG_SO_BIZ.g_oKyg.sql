create PACKAGE PKG_SO_BIZ IS
  /*----------------------------------------------------------------
  *         包：PKG_SO_BIZ
  *   创建日期：2014-07-05
  *     创建者：廖丽章
  *   功能说明：1、根据发货确认、差异签收、备货转销售等生成销售单据数据到接口表；
  *             2、根据销售单据头接口表与销售单据行接口表数据，生成各种类型销售单据（财务单）。
  *
  *   过程成功：P_RESULT = 0
  *             P_ERR_MSG = 'SUCCESS';
  *
  *   过程失败：P_RESULT < -20000;
  *             P_ERR_MSG = 过程异常失败的提示信息
  *
  */ ----------------------------------------------------------------

  --定义REF CURSOR类型
  --TYPE REFCURSOR_SO_DATA IS REF CURSOR;

  --定义销售单据类型记录集
  TYPE SO_BILL_TYPE IS RECORD(
    BILL_TYPE_ID     V_SO_BILL_TYPE.BILL_TYPE_ID%TYPE, --单据类型ID
    BILL_TYPE_CODE   V_SO_BILL_TYPE.BILL_TYPE_CODE%TYPE, --单据类型编码
    BILL_TYPE_NAME   V_SO_BILL_TYPE.BILL_TYPE_NAME%TYPE, --单据类型名称
    SRC_TYPE_ID      V_SO_BILL_TYPE.SRC_TYPE_ID%TYPE, --业务单据源类型ID
    SRC_TYPE_CODE    V_SO_BILL_TYPE.SRC_TYPE_CODE%TYPE, --业务单据源类型编码
    SRC_TYPE_NAME    V_SO_BILL_TYPE.SRC_TYPE_NAME%TYPE, --业务单据源类型名称
    SETTLE_TYPE_CODE V_SO_BILL_TYPE.SETTLE_TYPE_CODE%TYPE, --结算类型编码
    SETTLE_TYPE_NAME V_SO_BILL_TYPE.SETTLE_TYPE_NAME%TYPE --结算类型名称
    );

  --定义客户、账户信息记录集
  TYPE ACCOUNT_INFO IS RECORD(
    ACCOUNT_ID        T_CUSTOMER_ACCOUNT.ACCOUNT_ID%TYPE, --账户ID
    ACCOUNT_CODE      T_CUSTOMER_ACCOUNT.ACCOUNT_CODE%TYPE, --账户编码
    ACCOUNT_NAME      T_CUSTOMER_ACCOUNT.ACCOUNT_NAME%TYPE, --账户名称
    CUSTOMER_ID       T_CUSTOMER_HEADER.CUSTOMER_ID%TYPE, --客户ID
    CUSTOMER_CODE     T_CUSTOMER_HEADER.CUSTOMER_CODE%TYPE, --客户代码
    CUSTOMER_NAME     T_CUSTOMER_HEADER.CUSTOMER_NAME%TYPE, --客户名称
    SALES_CENTER_ID   T_CUSTOMER_ORG.SALES_CENTER_ID%TYPE, --销售中心ID
    SALES_CENTER_CODE T_CUSTOMER_ORG.SALES_CENTER_CODE%TYPE, --销售中心编码
    SALES_CENTER_NAME T_CUSTOMER_ORG.SALES_CENTER_NAME%TYPE, --销售中心名称
    ADDRESS_ID        T_CUSTOMER_ADDRESS.ADDRESS_ID%TYPE, --客户账户地址ID
    ADDRESS           T_CUSTOMER_ADDRESS.ADDRESS%TYPE, --客户账户地址
    PROVINCE          T_CUSTOMER_ADDRESS.PROVINCE%TYPE, --行政区域省份(省份代码)
    CITY              T_CUSTOMER_ADDRESS.CITY%TYPE, --行政区域地级市(地级市代码)
    AREA              T_CUSTOMER_ADDRESS.AREA%TYPE, --行政区域县区(县级市代码)
    TOWNS             T_CUSTOMER_ADDRESS.TOWNS%TYPE --行政区域镇(乡)编码
    );

  --库存处理（库存校验、库存解锁等）所需参数记录集
  TYPE INV_PROC_PARAMS IS RECORD(
    ENTITY_ID          NUMBER, --销售单据头
    INV_ID             NUMBER, --销售单据行
    SRC_TYPE           VARCHAR2(6), --来源类型：01计划订单 02提货订单 03调拨订单 04促销品 09采购单据 10调拨单据 11备货单据
    SRC_BILL_TYPE_ID   NUMBER, --来源单据类型ID（计划订单、提货订单等单据类型）
    SRC_BILL_TYPE_NAME VARCHAR2(200), --来源单据类型名称
    SRC_BILL_ID        NUMBER, --来源单据ID
    SRC_BILL_LINE_ID   NUMBER, --来源行ID（计划订单、提货订单等单据行ID）
    ITEM_ID            T_BD_ITEM.ITEM_ID%TYPE, --产品ID
    ITEM_CODE          T_BD_ITEM.ITEM_CODE%TYPE, --产品编码
    ITEM_NAME          T_BD_ITEM.ITEM_NAME%TYPE, --产品名称
    ITEM_QTY           T_SO_LINE.ITEM_QTY%TYPE --产品数量
    );

  --定义给库存事务的单据数据记录集
  TYPE BILL_DATA_INV IS RECORD(
    BILL_ID        NUMBER, --业务单据头ID
    BILL_NUM       VARCHAR2(100), --业务单据号
    LINE_ID        NUMBER, --业务单据行ID
    LINE_DETAIL_ID NUMBER, --业务单据行明细ID
    ITEM_ID        T_BD_ITEM.ITEM_ID%TYPE, --产品ID
    ITEM_CODE      T_BD_ITEM.ITEM_CODE%TYPE, --产品编码
    ITEM_NAME      T_BD_ITEM.ITEM_NAME%TYPE, --产品名称
    ITEM_UOM       T_BD_ITEM.DEFAULTUNIT%TYPE, --产品单位
    SRC_INV_ID     T_INV_INVENTORIES.INVENTORY_ID%TYPE, --仓库ID（来源仓库）
    ITEM_QTY       NUMBER, --数量
    CREATED_BY     VARCHAR2(32), --操作人
    TARGET_INV_ID  T_INV_INVENTORIES.INVENTORY_ID%TYPE, --目的仓库ID

    SRC_TERMINAL_ENTITY_ID  T_PRO_TERMINAL_ENTITY.TERMINAL_ENTITY_ID%TYPE, --来源门店主体ID add by  GUIBR20150723 样机
    SRC_TERMINAL_CODE       T_PRO_TERMINAL.TERMINAL_CODE%TYPE, --来源门店编码 add by  GUIBR20150723 样机
    SRC_TERMINAL_NAME       T_PRO_TERMINAL.TERMINAL_NAME%TYPE, --来源门店名称 add by  GUIBR20150723 样机
    TARGET_TERMINAL_ENTITY_ID  T_PRO_TERMINAL_ENTITY.TERMINAL_ENTITY_ID%TYPE, --目的门店主体ID add by  GUIBR20150723 样机
    TARGET_TERMINAL_CODE       T_PRO_TERMINAL.TERMINAL_CODE%TYPE, --目的门店编码GUIBR20150723 add by  GUIBR20150723 样机
    TARGET_TERMINAL_NAME       T_PRO_TERMINAL.TERMINAL_NAME%TYPE, --目的门店名称GUIBR20150723 add by  GUIBR20150723 样机
    REMARK                     VARCHAR2(4000),
    ORIGINAL_BILL_NUM          VARCHAR2(100)

    );

  --定义保存给库存事务的单据数据记录集的数组
  TYPE BILL_DATA_INV_ARRAY IS TABLE OF BILL_DATA_INV INDEX BY BINARY_INTEGER;
  
  V_ITEM_COMPETITE_ATTR_CODELIST CONSTANT VARCHAR2(32) := 'BD_PRICE_COMPETE_ATTR'; --产品竞争属性

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-05
  *     创建者：廖丽章
  *   功能说明：发货确认触发生成销售单据入口
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_ENTRY_SHIP(P_SHIP_INFO_ID IN NUMBER, --发货信息ID
                            P_USER_CODE    IN VARCHAR2, --操作用户编码
                            P_RESULT       OUT NUMBER, --返回错误ID
                            P_ERR_MSG      OUT VARCHAR2 --返回错误信息
                            );

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-05
  *     创建者：廖丽章
  *   功能说明：中转执行全赔单审核确认后，自动触发生成销售单入口
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_ENTRY_PO(P_PO_ID       IN NUMBER, --采购单据ID
                          P_CUSTOMER_ID IN NUMBER, --客户ID
                          P_ACCOUNT_ID  IN NUMBER, --账户ID
                          P_USER_CODE   IN VARCHAR2, --操作用户编码
                          P_RESULT      OUT NUMBER, --返回错误ID
                          P_ERR_MSG     OUT VARCHAR2 --返回错误信息
                          );

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-05
  *     创建者：廖丽章
  *   功能说明：调拨接收全赔单审核确认后，自动触发生成销售单
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_ENTRY_TRSF(P_TRSF_ORDER_ID IN NUMBER, --调拨单据ID
                            P_CUSTOMER_ID   IN NUMBER, --客户ID
                            P_ACCOUNT_ID    IN NUMBER, --账户ID
                            P_USER_CODE     IN VARCHAR2, --操作用户编码
                            P_RESULT        OUT NUMBER, --返回错误ID
                            P_ERR_MSG       OUT VARCHAR2 --返回错误信息
                            );

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-05
  *     创建者：廖丽章
  *   功能说明：备货转销售，触发生成销售单入口
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_ENTRY_STOCKUP(P_STOCKUP_ORDER_ID IN NUMBER, --备货单ID
                               P_USER_CODE        IN VARCHAR2, --操作用户编码
                               P_RESULT           OUT NUMBER, --返回错误ID
                               P_ERR_MSG          OUT VARCHAR2 --返回错误信息
                               );
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-11-25
  *     创建者：xiongpl
  *   功能说明：F单生成折让单时校验入口
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_ENTRY_DISCOUNT_CHECK(P_DISCOUNT_ORDER_ID IN NUMBER, --Y单(返利单)ID
                                P_RESULT            OUT NUMBER, --返回错误ID
                                P_ERR_MSG           OUT VARCHAR2 --返回错误信息
                                );
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-05
  *     创建者：廖丽章
  *   功能说明：F单审核确认后，触发生成折让单入口
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_ENTRY_DISCOUNT(P_DISCOUNT_ORDER_ID IN NUMBER, --Y单(返利单)ID
                                P_USER_CODE         IN VARCHAR2, --操作用户编码
                                P_SO_NUM            OUT T_SO_HEADER.SO_NUM%TYPE, --折让单号
                                P_RESULT            OUT NUMBER, --返回错误ID
                                P_ERR_MSG           OUT VARCHAR2 --返回错误信息
                                );
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2017-05-05
  *     创建者：周建刚
  *   功能说明：
  *           1、从接口表获取数据(电商异步开单)，写入同一的销售开单接口表。
  *           2、触发生成折让单入口
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_ENTRY_DISCOUNT_ECM(P_SO_INTF_ID IN NUMBER,   --电商异步开单接口表ID
                                    P_USER_CODE  IN VARCHAR2, --操作用户编码
                                    P_SO_NUM     OUT T_SO_HEADER.SO_NUM%TYPE, --折让单号
                                    P_RESULT     OUT NUMBER,  --返回错误ID
                                    P_ERR_MSG    OUT VARCHAR2 --返回错误信息
                                    );

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-05
  *     创建者：廖丽章
  *   功能说明：生成销售单据接口头记录
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_CREATE_INTF_HEADER(P_SO_INTF_HEADER IN OUT T_SO_HEADER_INTERFACE%ROWTYPE, --销售单据接口头信息
                                    P_USER_CODE      IN VARCHAR2, --操作用户编码
                                    P_RESULT         IN OUT NUMBER, --返回错误ID
                                    P_ERR_MSG        IN OUT VARCHAR2 --返回错误信息
                                    );

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-05
  *     创建者：廖丽章
  *   功能说明：生成销售单据接口行记录
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_CREATE_INTF_LINE(P_SO_INTF_LINE IN OUT T_SO_LINE_INTERFACE%ROWTYPE, --销售单据接口行信息
                                  P_USER_CODE    IN VARCHAR2, --操作用户编码
                                  P_RESULT       IN OUT NUMBER, --返回错误ID
                                  P_ERR_MSG      IN OUT VARCHAR2 --返回错误信息
                                  );
  -------------------------------------------------------------------------------
  /*
   *  创建日期：2014-07-05
  *     创建者：廖丽章
  *   功能说明：生成销售单据入口过程（生成销售单及销售红冲单）
  入口
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_GENERATE(P_SO_HEADER_INTERFACE_ID IN NUMBER, --销售单据头接口ID
                            P_USER_CODE              IN VARCHAR2, --操作用户编码
                            P_RESULT                 IN OUT NUMBER, --返回错误ID
                            P_ERR_MSG                IN OUT VARCHAR2 --返回错误信息
                            );
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-05
  *     创建者：廖丽章
  *   功能说明：生成折让单及其折让红单过程
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_DISCOUNT_GENERATE(P_SO_HEADER_INTERFACE_ID IN NUMBER, --销售单据头接口ID
                                   P_USER_CODE              IN VARCHAR2, --操作用户编码
                                   P_SO_NUM                 OUT T_SO_HEADER.SO_NUM%TYPE, --折让单号
                                   P_RESULT                 IN OUT NUMBER, --返回错误ID
                                   P_ERR_MSG                IN OUT VARCHAR2 --返回错误信息
                                   );

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-05
  *     创建者：廖丽章
  *   功能说明：生成退货单过程
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_RETURN_GENERATE(P_SO_HEADER_INTERFACE_ID IN NUMBER, --销售单据头接口ID
                                 P_USER_CODE              IN VARCHAR2, --操作用户编码
                                 P_RESULT                 IN OUT NUMBER, --返回错误ID
                                 P_ERR_MSG                IN OUT VARCHAR2 --返回错误信息
                                 );
  -------------------------------------------------------------------------------
  /*
   *  创建日期：2017-08-08
  *     创建者：周建刚
  *   功能说明：续租提货订单开对应0价格的退货单
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_RENEW_RETURN_GENERATE(P_SO_HEADER_INTERFACE_ID IN NUMBER, --销售单据头接口ID
                                       P_USER_CODE              IN VARCHAR2, --操作用户编码
                                       P_RESULT                 IN OUT NUMBER, --返回错误ID
                                       P_ERR_MSG                IN OUT VARCHAR2 --返回错误信息
                                       );
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2017-04-26
  *     创建者：周建刚
  *   功能说明：根据蓝单号生成对应红冲单的过程，适用于整单红冲场景
  *             主要步骤(1)写销售单接口表,(2)调用P_SO_GENERATE开红冲单
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_RED_GEN_BY_BLUE_NUM(P_SO_NUM                IN VARCHAR2,     --原单号
                                     P_USER_CODE             IN VARCHAR2,   --操作用户编码
                                     V_RAW_SRC_TYPE          IN VARCHAR2,   --原始来原单类型(如果是销售/退货直接红冲可不传,默认为财务单)。01计划订单 02提货订单 03调拨订单 04促销品 09采购单据 10调拨单据 11备货单据 18 价格调账申请单 19 拆单调账申请单 21 退货红冲申请单
                                     V_RAW_SRC_BILL_NUM      IN VARCHAR2,   --原始来原单号
                                     P_CREDIT_CONTROL_FLAG   IN VARCHAR2,   --是否实时触发信用控制
                                     P_SO_NUM_RED            OUT VARCHAR2, --新开红冲单号
                                     P_RESULT                IN OUT NUMBER, --返回错误ID
                                     P_ERR_MSG               IN OUT VARCHAR2--返回错误信息
                                     );
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2017-05-08
  *     创建者：周建刚
  *   功能说明：生成单据头过程
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_CREATE_HEADER(P_SO_HEADER_INTF IN OUT T_SO_HEADER_INTERFACE%ROWTYPE, --销售单据接口头记录
                                 P_SO_HEADER_ID   IN OUT NUMBER, --销售单据头ID
                                 P_SO_NUM         IN OUT VARCHAR2, --销售单据号
                                 P_DIFF           IN VARCHAR2, --是否差异签收：Y是，N否
                                 P_RESULT         IN OUT NUMBER, --返回错误ID
                                 P_ERR_MSG        IN OUT VARCHAR2 --返回错误信息
                                 );

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-05
  *     创建者：廖丽章
  *   功能说明：新建销售单据行
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_CREATE_LINE(P_SO_LINE      IN T_SO_LINE%ROWTYPE, --销售单据接口行记录
                             P_SO_HEADER_ID IN NUMBER, --销售单据头ID
                             P_IS_DISCOUNT  IN CHAR, --是否折让单：Y是，N否
                             P_ENTITY_ID    IN NUMBER, --主体ID add by chen.wj 20150128
                             P_RESULT       IN OUT NUMBER, --返回错误ID
                             P_ERR_MSG      IN OUT VARCHAR2 --返回错误信息
                             );

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-05
  *     创建者：廖丽章
  *   功能说明：新建销售单据行明细
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_CREATE_LINE_DETAIL(P_SO_LINE_DETAIL IN T_SO_LINE_DETAIL%ROWTYPE, --销售单据行明细记录
                                    P_RESULT         IN OUT NUMBER, --返回错误ID
                                    P_ERR_MSG        IN OUT VARCHAR2 --返回错误信息
                                    );

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-05
  *     创建者：廖丽章
  *   功能说明：把行接口记录数据赋值给行记录
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_LINE_ASSIGN(P_SO_LINE_INTF IN T_SO_LINE_INTERFACE%ROWTYPE, --销售单据行接口记录
                             P_SO_LINE      IN OUT T_SO_LINE%ROWTYPE, --销售单据行记录
                             P_RESULT       IN OUT NUMBER, --返回错误ID
                             P_ERR_MSG      IN OUT VARCHAR2 --返回错误信息
                             );

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-21
  *     创建者：廖丽章
  *   功能说明：销售单据审核
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_AUDIT(P_SO_HEADER_ID IN VARCHAR2, --销售单据头ID
                       P_AUDIT_BY     IN VARCHAR2, --审核人
                       P_RESULT       IN OUT NUMBER, --返回错误ID
                       P_ERR_MSG      IN OUT VARCHAR2 --返回错误信息
                       );

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-21
  *     创建者：廖丽章
  *   功能说明：销售单据批量审核
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_AUDIT_BATCH(P_ARR_SO_HEADER_ID IN PKG_SO_PUB.TYPE_ARRAY, --销售单据头ID数组
                             P_AUDIT_BY         IN VARCHAR2, --审核人
                             P_RESULT           IN OUT NUMBER, --返回错误ID
                             P_ERR_MSG          IN OUT VARCHAR2 --返回错误信息
                             );
  ------------------------------------------------------------------------------- 
  /*
  *   创建日期：2019-02-27
  *     创建者：周建刚
  *   功能说明：网批销售红冲单或退货单生成对应的退款申请单
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_TO_AR_REFUND_APPLY(P_SO_HEADER_ID       IN NUMBER,     --销售单据头ID
                                    P_USER_CODE          IN VARCHAR2,   --操作用户编码
                                    P_RESULT             OUT NUMBER,    --返回错误ID
                                    P_ERR_MSG            OUT VARCHAR2   --返回错误信息
                                    );
  ------------------------------------------------------------------------------- 
  /*
  *   创建日期：2018-08-20
  *     创建者：周建刚
  *   功能说明：财务单(销售/销售红冲/退货/退货红冲)引入到CCS接口表
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_TO_CCS(P_ENTITY_ID          IN NUMBER,   --主体ID
                        P_USER_CODE          IN VARCHAR2, --操作用户编码
                        P_RESULT             OUT NUMBER,  --返回错误ID
                        P_ERR_MSG            OUT VARCHAR2 --返回错误信息
                       );

  -------------------------------------------------------------------------------  
  /*
  *   创建日期：2018-08-20
  *     创建者：周建刚
  *   功能说明：财务单(销售/销售红冲/退货/退货红冲)引入到CCS接口表
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_TO_CCS_CREATE(P_SO_HEADER_ID       IN NUMBER,     --销售单据头ID
                               P_USER_CODE          IN VARCHAR2,   --操作用户编码
                               P_RESULT             OUT NUMBER,    --返回错误ID
                               P_ERR_MSG            OUT VARCHAR2   --返回错误信息
                               );

  -------------------------------------------------------------------------------  
  /*
  *   创建日期：2018-08-22
  *     创建者：周建刚
  *   功能说明：退货申请变更（审核通过、关闭、开退货单、安得处理失败等）推送CCS系统
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_RETURN_APPLY_TO_CCS(P_BILL_NUM     IN VARCHAR2,   --退货申请单据号
                                     P_PROCESS_TYPE IN VARCHAR2,   --操作类型
                                     P_PROCESS_MSG  IN VARCHAR2,   --操作结果提示
                                     P_RESULT       OUT NUMBER,    --返回错误ID
                                     P_ERR_MSG      OUT VARCHAR2   --返回错误信息
                                     );
  ------------------------------------------------------------------------------- 
  /*
  *   创建日期：2017-04-21
  *     创建者：周建刚
  *   功能说明：已经开票的财务单(销售/销售红冲/退货/退货红冲)引入到NC接口表
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_TO_NC(
                       P_ENTITY_ID          IN NUMBER,   --主体ID
                       P_USER_CODE          IN VARCHAR2, --操作用户编码
                       P_RESULT             OUT NUMBER,  --返回错误ID
                       P_ERR_MSG            OUT VARCHAR2 --返回错误信息
                      );
  -------------------------------------------------------------------------------   
  /*
  *   创建日期：2017-04-21
  *     创建者：周建刚
  *   功能说明：根据财务单信息引入到NC接口表
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_TO_NC_CREATE(P_SO_HEADER_ID       IN NUMBER,   --销售单据头ID
                              P_USER_CODE          IN VARCHAR2, --操作用户编码
                              P_RESULT             OUT NUMBER,  --返回错误ID
                              P_ERR_MSG            OUT VARCHAR2 --返回错误信息
                              );
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-21
  *     创建者：廖丽章
  *   功能说明：把销售单据添加到与ERP系统对接的接口表，并配置调用的接口。
  *   参数说明：P_ERP_TRX_CODE 调用ERP接口代码：GEN(生成)
  *                                             INV(挑库)
  *                                             SHIP(发运)
  *                                             CHANGE(变更)
  *                                             RMA_RECV(RMA接收)
  *                                             BOOK(登记)
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_TO_ERP(P_SO_HEADER_ID IN VARCHAR2, --销售单据头ID
                        P_ERP_TRX_CODE IN VARCHAR2, --调用ERP接口代码
                        P_RESULT       IN OUT NUMBER, --返回错误ID
                        P_ERR_MSG      IN OUT VARCHAR2 --返回错误信息
                        );

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-23
  *     创建者：廖丽章
  *   功能说明：在与ERP系统对接接口头表和行表添加记录
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_TO_ERP_CREATE(P_SO_HEADER  IN T_SO_HEADER%ROWTYPE, --销售单头
                               R_OE_HEADERS IN OUT INTF_OE_HEADERS_IFACE_ALL%ROWTYPE,
                               P_TRX_STATUS IN VARCHAR2, --交易状态
                               P_RESULT     IN OUT NUMBER, --返回错误ID
                               P_ERR_MSG    IN OUT VARCHAR2 --返回错误信息
                               );

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-23
  *     创建者：廖丽章
  *   功能说明：提供库存处理所需单据数据
                类型标识：B1（采购中转）、B2（仓库调拨）、B3（仓库盘点）、B4（销售）、B5（推广物料）、B6（备货转销售）
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_BILL_DATA_FOR_INV(P_TYPE_FLAG       IN VARCHAR2, --类型标识
                                P_STATUS          IN VARCHAR2, --单据状态
                                P_BILL_ID         IN NUMBER, --单据(头)ID
                                P_BILL_DATA_ARRAY OUT BILL_DATA_INV_ARRAY, --单据数据结果集数组
                                P_RESULT          OUT NUMBER, --返回错误ID
                                P_ERR_MSG         OUT VARCHAR2 --返回错误信息
                                );

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-23
  *     创建者：廖丽章
  *   功能说明：提供库存处理所需销售单据数据
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_DATA_FOR_INV(P_SO_HEADER_ID    IN NUMBER, --销售单头ID
                              P_SO_STATUS       IN VARCHAR2, --单据状态
                              P_BILL_DATA_ARRAY OUT BILL_DATA_INV_ARRAY, --单据数据结果集数组
                              P_RESULT          OUT NUMBER, --返回错误ID
                              P_ERR_MSG         OUT VARCHAR2 --返回错误信息
                              );

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-23
  *     创建者：廖丽章
  *   功能说明：提供库存处理所需采购中转单数据
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_PO_DATA_FOR_INV(P_HEADER_ID       IN NUMBER, --单据头ID
                              P_STATUS          IN VARCHAR2, --单据状态
                              P_BILL_DATA_ARRAY OUT BILL_DATA_INV_ARRAY, --单据数据结果集数组
                              P_RESULT          OUT NUMBER, --返回错误ID
                              P_ERR_MSG         OUT VARCHAR2 --返回错误信息
                              );

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-23
  *     创建者：廖丽章
  *   功能说明：提供库存处理所需仓库调拨单数据
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_TRSF_DATA_FOR_INV(P_HEADER_ID       IN NUMBER, --单据头ID
                                P_STATUS          IN VARCHAR2, --单据状态
                                P_BILL_DATA_ARRAY OUT BILL_DATA_INV_ARRAY, --单据数据结果集数组
                                P_RESULT          OUT NUMBER, --返回错误ID
                                P_ERR_MSG         OUT VARCHAR2 --返回错误信息
                                );

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-23
  *     创建者：廖丽章
  *   功能说明：提供库存处理所需仓库盘点单数据
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_INVCHECK_DATA_FOR_INV(P_HEADER_ID       IN NUMBER, --单据头ID
                                    P_STATUS          IN VARCHAR2, --单据状态
                                    P_BILL_DATA_ARRAY OUT BILL_DATA_INV_ARRAY, --单据数据结果集数组
                                    P_RESULT          OUT NUMBER, --返回错误ID
                                    P_ERR_MSG         OUT VARCHAR2 --返回错误信息
                                    );

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-23
  *     创建者：廖丽章
  *   功能说明：提供库存处理所需推广物料单数据
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_PMT_DATA_FOR_INV(P_HEADER_ID       IN NUMBER, --单据头ID
                               P_STATUS          IN VARCHAR2, --单据状态
                               P_BILL_DATA_ARRAY OUT BILL_DATA_INV_ARRAY, --单据数据结果集数组
                               P_RESULT          OUT NUMBER, --返回错误ID
                               P_ERR_MSG         OUT VARCHAR2 --返回错误信息
                               );

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-23
  *     创建者：廖丽章
  *   功能说明：提供库存处理所需备货转销售单数据
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_STOCKUP_DATA_FOR_INV(P_HEADER_ID       IN NUMBER, --单据头ID
                                   P_STATUS          IN VARCHAR2, --单据状态
                                   P_BILL_DATA_ARRAY OUT BILL_DATA_INV_ARRAY, --单据数据结果集数组
                                   P_RESULT          OUT NUMBER, --返回错误ID
                                   P_ERR_MSG         OUT VARCHAR2 --返回错误信息
                                   );

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2017-04-20
  *     创建者：周建刚
  *   功能说明：销售单据折让到款更新
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_CREDIT_DISCOUNT_CONTROL(P_SO_HEADER_ID         IN NUMBER,   --销售单据头ID
                                         P_SETTLE_AMOUNT_DIFF   IN NUMBER,   --结算金额差额
                                         P_CREATED_MODE         IN VARCHAR2, --开单方式
                                         P_SO_STATUS            IN  VARCHAR2 DEFAULT NULL,  --用于区分是否结算
                                         P_RESULT               OUT NUMBER,  --返回错误ID
                                         P_ERR_MSG              OUT VARCHAR2 --返回错误信息
                                         );
  -------------------------------------------------------------------------------
  
  /*
  *   创建日期：2014-07-23
  *     创建者：廖丽章
  *   功能说明：销售单据信用控制
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_CREDIT_CONTROL(P_SO_HEADER_ID         IN NUMBER, --销售单据头ID
                                P_SETTLE_AMOUNT_DIFF   IN NUMBER, --结算金额差额
                                P_DISCOUNT_AMOUNT_DIFF IN NUMBER, --折扣金额差额
                                P_CREATED_MODE         IN VARCHAR2, --开单方式
                                P_RESULT               OUT NUMBER, --返回错误ID
                                P_ERR_MSG              OUT VARCHAR2, --返回错误信息
                                P_SO_STATUS            IN  VARCHAR2 DEFAULT NULL  --用于区分是否结算
                                );
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2017-08-28
  *     创建者：周建刚
  *   功能说明：销售单据批量触发信用控制（开单不触发、定时批量触发信用控制）
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_CREDIT_CONTROL_BATCH(P_ENTITY_ID   IN NUMBER, --主体ID
                                      P_RESULT      OUT NUMBER, --返回错误ID
                                      P_ERR_MSG     OUT VARCHAR2 --返回错误信息
                                      );
                                      
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-23
  *     创建者：廖丽章
  *   功能说明：产品库存校验
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_ITEM_INV_CHECK(P_PARAMS    IN INV_PROC_PARAMS, --库存处理所需参数记录集
                                P_USER_CODE IN VARCHAR2, --操作用户编码
                                P_RESULT    OUT NUMBER, --返回错误ID
                                P_ERR_MSG   OUT VARCHAR2 --返回错误信息
                                );

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-23
  *     创建者：廖丽章
  *   功能说明：库存占用量解锁（释放）
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_ITEM_INV_RELEASE(P_SO_HEADER_ID IN NUMBER, --销售单据头
                                  P_USER_CODE    IN VARCHAR2, --操作用户编码
                                  P_RESULT       OUT NUMBER, --返回错误ID
                                  P_ERR_MSG      OUT VARCHAR2 --返回错误信息
                                  );

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-23
  *     创建者：廖丽章
  *   功能说明：库存占用量上锁（锁定），用于销售红冲单。
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_ITEM_INV_LOCK(P_SO_HEADER_ID IN NUMBER, --销售单据头（红冲单）
                               P_USER_CODE    IN VARCHAR2, --操作用户编码
                               P_RESULT       OUT NUMBER, --返回错误ID
                               P_ERR_MSG      OUT VARCHAR2 --返回错误信息
                               );

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-23
  *     创建者：廖丽章
  *   功能说明：回写其他模块
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_WRITE_BACK(P_SO_HEADER_ID IN NUMBER, --销售单据头ID
                            P_USER_CODE    IN VARCHAR2, --操作用户编码
                            P_RESULT       OUT NUMBER, --返回错误ID
                            P_ERR_MSG      OUT VARCHAR2 --返回错误信息
                            );

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-25
  *     创建者：廖丽章
  *   功能说明：处理批文使用量
  *   修改日期：2017-11-03
  *     修改者：周建刚
  *   修改点：
  *   1、该方法为销售/退货单据更新价格批文数量的统一接口。
  *   2、单据审核时处理批文开单量、锁定量更新。
  *   3、根据单据类型判定数量正负。
  *   4、根据开单方式(自动、人工)决定是否需要解除锁定数量。
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_PROJECT_PROCESS(P_SO_HEADER_ID IN NUMBER, --销售单据头ID
                                  P_RESULT       OUT NUMBER, --返回错误ID
                                  P_ERR_MSG      OUT VARCHAR2 --返回错误信息
                                  );
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2017-11-06
  *     创建者：周建刚
  *   功能说明：校验批文可用量
  *   修改点：
  *   1、退货、销售、退货申请[审核]、退货红冲申请制单时校验开单量是否足够
  *   2、[制单]销售单、退货红冲单、退货红冲申请,增加‘已提货数量’;校验逻辑： 本次开单量 + 已提货数量 + 锁定量 <= 批文申请数量
  *   3、[制单]销售红冲单、退货单、退货申请,减少‘已提货数量’;校验逻辑： 已提货数量 => 本次开单量
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_PROJECT_CHECK(P_APPLY_CODE       IN VARCHAR2, --批文申请单号
                                P_APPLY_DETAIL_ID IN NUMBER,   --批文行ID
                                P_BILL_TYPE_CODE  IN VARCHAR2, --1001 销售单;1002 销售红冲单;1003 退货单;1004 退货红冲单;1015 退货红冲申请单;1011 退货申请
                                P_ITEM_CODE       IN VARCHAR2, --产品编码
                                P_ITEM_QTY        IN NUMBER,   --产品数量
                                P_SO_NUM          IN VARCHAR2, --当前财务单号(制单状态单据修改保存)
                                P_CUSTOMER_ID     IN NUMBER,   --客户ID
                                P_SALES_CENTER_ID IN NUMBER,   --中心ID
                                P_ENTITY_ID       IN NUMBER,   --主体ID
                                P_RESULT          OUT NUMBER,  --返回错误ID
                                P_ERR_MSG         OUT VARCHAR2 --返回错误信息
                                );
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-25
  *     创建者：廖丽章
  *   功能说明：保存销售单据接口头记录与正式销售单据的关系
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SAVE_SO_RELATION(P_SO_HEADER_INTF IN T_SO_HEADER_INTERFACE%ROWTYPE, --接口头信息
                               P_SO_HEADER_ID   IN NUMBER --销售单据头ID
                               );

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2017-08-02
  *     创建者：周建刚
  *   功能说明：客户OU一致性校验
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_CUST_OU_CHECK(P_CUSTOMER_CODE IN VARCHAR2, --客户编码
                               P_ERP_OU_ID     IN T_SO_HEADER.ERP_OU_ID%TYPE, --客户OU
                               P_RESULT        OUT NUMBER, --返回错误ID
                               P_ERR_MSG       OUT VARCHAR2 --返回错误信息
                               );
                               
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2017-12-01
  *     创建者：周建刚
  *   功能说明：校验组织、仓库关系是否存在(销售、退货)
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_ORG_ITEM_CHECK_SO(
                               P_HEADER_ID               IN NUMBER,   --单据头ID
                               P_RESULT                  OUT NUMBER,  --返回错误ID
                               P_ERR_MSG                 OUT VARCHAR2 --返回错误信息
                               );
                                         
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2017-12-01
  *     创建者：周建刚
  *   功能说明：校验组织、仓库关系是否存在(退货申请)
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_ORG_ITEM_CHECK_RETURN_APPLY(
                                         P_HEADER_ID               IN NUMBER,   --单据头ID
                                         P_RESULT                  OUT NUMBER,  --返回错误ID
                                         P_ERR_MSG                 OUT VARCHAR2 --返回错误信息
                                         );
                                         
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2017-12-01
  *     创建者：周建刚
  *   功能说明：校验组织、仓库关系是否存在(公共校验逻辑)
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_ORG_ITEM_CHECK_COMMON(
                                   P_HEADER_ID               IN NUMBER,   --单据头ID
                                   P_BIZ_SRC_BILL_TYPE_CODE  IN VARCHAR2, --单据源类型
                                   P_RESULT                  OUT NUMBER,  --返回错误ID
                                   P_ERR_MSG                 OUT VARCHAR2 --返回错误信息
                                   );
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2018-01-09
  *     创建者：周建刚
  *   功能说明：运输合同差异签收，更新对应财务单据的备注。
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_CONTRACT_DIFFER_REMARK(
                                       P_SO_HEADER_INTF IN T_SO_HEADER_INTERFACE%ROWTYPE, --销售单据接口头记录
                                       P_SO_HEADER_ID   IN NUMBER, --销售单据
                                       P_RESULT         OUT NUMBER,  --返回错误ID
                                       P_ERR_MSG        OUT VARCHAR2 --返回错误信息
                                       );
                                       
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2018-04-10
  *     创建者：周建刚
  *   功能说明：更新销售单据的税率、税码。
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_UPDATE_TAX_RATE(P_SO_HEADER_ID   IN NUMBER, --销售单据
                                 P_RESULT         OUT NUMBER,  --返回错误ID
                                 P_ERR_MSG        OUT VARCHAR2 --返回错误信息
                                 );
                                 
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2018-05-08
  *     创建者：周建刚
  *   功能说明：EXCEL导入，批量更新未结算销售(历史)单据的税率、税码。
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_UPDATE_TAX_RATE_BATCH(P_BATCH_ID       IN NUMBER,   --批处理ID
                                       P_USER_CODE      IN VARCHAR2, --操作用户编码
                                       P_RESULT         OUT NUMBER,  --返回错误ID
                                       P_ERR_MSG        OUT VARCHAR2 --返回错误信息
                                       );
                                 
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2018-05-21
  *     创建者：周建刚
  *   功能说明：EXCEL导入，批量更新划拨信息。
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_UPDATE_BELONG_TO_BATCH(P_BATCH_ID       IN NUMBER,   --批处理ID
                                        P_USER_CODE      IN VARCHAR2, --操作用户编码
                                        P_RESULT         OUT NUMBER,  --返回错误ID
                                        P_ERR_MSG        OUT VARCHAR2 --返回错误信息
                                        );
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-25
  *     创建者：廖丽章
  *   功能说明：判断来源单据是否已生成销售单据
  */
  -------------------------------------------------------------------------------
  FUNCTION F_SO_CREATED(P_SRC_BILL_ID      IN NUMBER, --来源单据ID
                        P_SRC_TYPE         IN VARCHAR2, --来源类型
                        P_SRC_BILL_TYPE_ID IN NUMBER --来源单据类型ID
                        ) RETURN NUMBER;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-25
  *     创建者：廖丽章
  *   功能说明：根据主体及业务单据类型编码，获取业务单据类型信息
  */
  -------------------------------------------------------------------------------
  FUNCTION F_GET_BILL_TYPE(P_BILL_TYPE_CODE IN VARCHAR2, --业务单据类型编码
                           P_ENTITY_ID      IN NUMBER --主体ID
                           ) RETURN SO_BILL_TYPE;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-25
  *     创建者：廖丽章
  *   功能说明：根据账户ID获取客户、账户信息
  */
  -------------------------------------------------------------------------------
  FUNCTION F_GET_ACCOUNT_INFO(P_ACCOUNT_ID IN VARCHAR2, --业务单据类型编码
                              P_ENTITY_ID  IN NUMBER --主体ID
                              ) RETURN ACCOUNT_INFO;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-25
  *     创建者：廖丽章
  *   功能说明：根据单据头ID，获取单据号
  */
  -------------------------------------------------------------------------------
  FUNCTION F_GET_SO_NUM(P_SO_HEADER_ID IN NUMBER) RETURN VARCHAR2;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-25
  *     创建者：廖丽章
  *   功能说明：根据来源标识（直接来源）和来源单号（直接来源），获取单据号
  *     返回值：财务单号，多张单号用英文逗号分隔：1000001913,1000001915
  */
  -------------------------------------------------------------------------------
  FUNCTION F_GET_SO_NUM_BY_SRCTYPE(P_SRC_TYPE     IN VARCHAR2,
                                   P_SRC_BILL_NUM IN VARCHAR2)
    RETURN VARCHAR2;
    
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2017-07-30
  *     创建者：周建刚
  *   功能说明：根据码表类型和码值获取对应的码值名称
  *     返回值：码值名称
  */
  -------------------------------------------------------------------------------
  FUNCTION F_GET_CODENAME(P_CODETYPE     IN VARCHAR2,
                          P_CODE_VALUE   IN VARCHAR2)
    RETURN VARCHAR2;
  -------------------------------------------------------------------------------
/*
  *   创建日期：2015-01-06
  *     创建者：陈武杰
  *   功能说明：根据账户ID获取客户、账户信息和地区编码选择账户中的行政区划
  */
-------------------------------------------------------------------------------
/*FUNCTION F_GET_DISTRICT(P_DISTRICT_CODE IN VARCHAR2, --地区编码
                          P_ACCOUNT_ID    IN VARCHAR2, --业务单据类型编码
                          P_ENTITY_ID     IN NUMBER --主体ID
                          ) RETURN ACCOUNT_INFO;*/
  -------------------------------------------------------------------------------   
  /*
  *   创建日期：
  *     创建者：周建刚
  *   功能说明：小天鹅切换临时开发批量处理功能接口表
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_OU_SWITCH_INTF(P_ENTITY_ID          IN NUMBER,     --主体ID
                                P_USER_CODE          IN VARCHAR2,   --操作用户编码
                                P_RESULT             OUT NUMBER,    --返回错误ID
                                P_ERR_MSG            OUT VARCHAR2   --返回错误信息
                                );
  -------------------------------------------------------------------------------
  /*
  *   创建日期：
  *     创建者：周建刚
  *   功能说明：小天鹅切换临时开发批量处理功能接口表
                步骤1/4、红冲旧仓库单据
                步骤2/4、盘亏旧仓库库存
                步骤3/4、盘盈新仓库库存
                步骤4/4、新仓库开单
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_OU_SWITCH_HANDLE(P_ENTITY_ID          IN NUMBER,     --主体ID
                                  P_USER_CODE          IN VARCHAR2,   --操作用户编码
                                  P_RESULT             OUT NUMBER,    --返回错误ID
                                  P_ERR_MSG            OUT VARCHAR2   --返回错误信息
                                  );
  -------------------------------------------------------------------------------
  /*
  *   创建日期：
  *     创建者：周建刚
  *   功能说明：小天鹅切换临时开发批量处理功能接口表
                步骤1/4、红冲旧仓库单据
                步骤2/4、盘亏旧仓库库存
                步骤3/4、盘盈新仓库库存
                步骤4/4、新仓库开单
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_OU_SWITCH_SINGLE(P_SO_HEADER_SWITCH   IN T_SO_HEADER_SWITCH%ROWTYPE,--仓库切换记录表
                                  P_USER_CODE          IN VARCHAR2,   --操作用户编码
                                  P_RESULT             OUT NUMBER,    --返回错误ID
                                  P_ERR_MSG            OUT VARCHAR2   --返回错误信息
                                  );

  -------------------------------------------------------------------------------
  /*
  *   创建日期：
  *     创建者：周建刚
  *   功能说明：小天鹅切换盘点开单
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_OU_SWITCH_INV_CHECK(P_SO_HEADER_SWITCH   IN T_SO_HEADER_SWITCH%ROWTYPE,--仓库切换记录表
                                     P_INV_FLAG           IN VARCHAR2,
                                     P_USER_CODE          IN VARCHAR2,   --操作用户编码
                                     P_RESULT             OUT NUMBER,    --返回错误ID
                                     P_ERR_MSG            OUT VARCHAR2   --返回错误信息
                                    );
  -------------------------------------------------------------------------------
  
END PKG_SO_BIZ;
/

