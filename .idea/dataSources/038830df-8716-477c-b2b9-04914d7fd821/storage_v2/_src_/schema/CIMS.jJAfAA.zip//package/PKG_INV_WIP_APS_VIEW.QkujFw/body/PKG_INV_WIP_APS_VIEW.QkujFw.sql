create PACKAGE BODY      PKG_INV_WIP_APS_VIEW AS
 

  -----------------------------------------------------------------------------
  --处理MES视图更新扫码信息主过程
  -----------------------------------------------------------------------------
  PROCEDURE P_INV_WIP_MES_MAIN(P_ORGANIZATION_ID IN INTF_INV_WIP_IN_INFO_MES.ORGANIZATION_ID%TYPE, --组织ID
                               P_MES_BATCH_ID    IN INTF_INV_WIP_IN_INFO_MES.MES_BATCH_ID%TYPE, --扫码批次号
                               P_RESULT          IN OUT NUMBER, --返回错误ID
                               P_ERR_MSG         IN OUT VARCHAR2 --返回错误信息
                               ) IS
  
    V_LAST_UPDATE_DATE      DATE; --接口表最新时间
    V_LAST_ONE_HOUR_DATE    DATE; --当前时间前一小时
    V_CNT                   NUMBER;
    R_CUX_WIP_IMS_MAPPING_V MESPRO.IMS_IF_MES_WIS_INTERFACE@MDIMS2SMES%ROWTYPE;
  
  BEGIN
    P_RESULT  := 0;
    P_ERR_MSG := 'SUCCESS';
  
    --处理单个扫码批次
    IF P_MES_BATCH_ID IS NOT NULL AND P_ORGANIZATION_ID IS NOT NULL THEN
      FOR R_WIP IN (SELECT *
                      FROM MESPRO.IMS_IF_MES_WIS_INTERFACE@MDIMS2SMES mw
                     WHERE mw.ORGANIZATION_ID = P_ORGANIZATION_ID
                          --AND mw.LAST_UPDATE_DATE > SYSDATE - 92
                       AND mw.MES_BATCH_ID = P_MES_BATCH_ID) LOOP
        P_INSERT_INTF_WIP_MES(R_WIP, P_RESULT, P_ERR_MSG);
      END LOOP;
      RETURN;
    END IF;
  
    SELECT MAX(E.MES_LAST_UPDATE_DATE)
      INTO V_LAST_UPDATE_DATE
      FROM INTF_INV_WIP_IN_INFO_MES E
     WHERE 1 = 1
       AND E.LAST_UPDATE_DATE > SYSDATE - 10;
  
    SELECT (SYSDATE - 60 / 24 / 60) INTO V_LAST_ONE_HOUR_DATE FROM DUAL;
  
    --如果接口表最新更新时间在一个小时前，那么取最新更新时间查APS工单
    IF V_LAST_ONE_HOUR_DATE > V_LAST_UPDATE_DATE THEN
      V_LAST_ONE_HOUR_DATE := V_LAST_UPDATE_DATE;
    END IF;
    FOR R_ORGANIZATION IN (SELECT T.MRP_ORG_ID AS ORGANIZATION_ID
                             FROM T_PLN_PRODUCING_AREA T) LOOP
      BEGIN
        FOR R_WIP IN (SELECT *
                        FROM MESPRO.IMS_IF_MES_WIS_INTERFACE@MDIMS2SMES mw
                       WHERE mw.ORGANIZATION_ID =
                             R_ORGANIZATION.ORGANIZATION_ID
                         AND mw.LAST_UPDATE_DATE > V_LAST_ONE_HOUR_DATE) LOOP
          BEGIN
            P_INSERT_INTF_WIP_MES(R_WIP, P_RESULT, P_ERR_MSG);
          EXCEPTION
            WHEN OTHERS THEN
              null;
          END;
        END LOOP;
      EXCEPTION
        WHEN OTHERS THEN
          null;
      END;
    END LOOP;
  EXCEPTION
    WHEN OTHERS THEN
      P_RESULT  := -1;
      P_ERR_MSG := '处理MES扫码信息出错：' || SUBSTR(SQLERRM, 1, 200);
  END;

  -----------------------------------------------------------------------------
  --插入扫码接口表
  -----------------------------------------------------------------------------
  PROCEDURE P_INSERT_INTF_WIP_MES(P_IMS_IF_MES_WIS_INTERFACE IN MESPRO.IMS_IF_MES_WIS_INTERFACE@MDIMS2SMES%ROWTYPE,
                                  P_RESULT                   IN OUT NUMBER, --返回错误ID
                                  P_ERR_MSG                  IN OUT VARCHAR2 --返回错误信息
                                  ) IS
    V_CNT NUMBER;
  BEGIN
    SELECT COUNT(*)
      INTO V_CNT
      FROM INTF_INV_WIP_IN_INFO_MES IM
     WHERE IM.MES_BATCH_ID = P_IMS_IF_MES_WIS_INTERFACE.MES_BATCH_ID
       AND IM.WIP_ENTITY_ID = P_IMS_IF_MES_WIS_INTERFACE.WIP_ENTITY_ID;
    IF V_CNT > 0 THEN
      RETURN;
    END IF;
  
    INSERT INTO INTF_INV_WIP_IN_INFO_MES
      (INTF_ID,
       MES_BATCH_ID,
       ORGANIZATION_ID,
       ORGANIZATION_CODE,
       ORGANIZATION_NAME,
       WIP_ENTITY_ID,
       WIP_ENTITY_NUM,
       WIP_ENTITY_DESC,
       ITEM_CODE,
       ITEM_NAME,
       MES_QTY,
       LAST_UPDATE_DATE,
       LAST_UPDATED_BY,
       MES_LAST_UPDATE_DATE,
       MES_LAST_UPDATED_BY)
    values
      (S_INTF_INV_WIP_IN_INFO_MES.NEXTVAL, --序列ID
       P_IMS_IF_MES_WIS_INTERFACE.MES_BATCH_ID, --MES扫码批次号
       P_IMS_IF_MES_WIS_INTERFACE.ORGANIZATION_ID, --组织ID
       P_IMS_IF_MES_WIS_INTERFACE.ORGANIZATION_CODE, --组织编码
       P_IMS_IF_MES_WIS_INTERFACE.ORGANIZATION_NAME, --组织名称
       P_IMS_IF_MES_WIS_INTERFACE.WIP_ENTITY_ID, --工单ID
       P_IMS_IF_MES_WIS_INTERFACE.WIP_ENTITY_NUM, --工单编码
       P_IMS_IF_MES_WIS_INTERFACE.WIP_ENTITY_DESC, --工单描述
       P_IMS_IF_MES_WIS_INTERFACE.ITEM_CODE, --产品编码
       P_IMS_IF_MES_WIS_INTERFACE.ITEM_NAME, --产品描述（名称）
       P_IMS_IF_MES_WIS_INTERFACE.MES_QTY, --产品数量
       sysdate,
       'MES',
       P_IMS_IF_MES_WIS_INTERFACE.LAST_UPDATE_DATE, --MES更新时间
       P_IMS_IF_MES_WIS_INTERFACE.LAST_UPDATED_BY --MES更新人
       );
  EXCEPTION
    WHEN OTHERS THEN
      P_RESULT  := -1;
      P_ERR_MSG := '添加接口表出错,扫码批次号：' ||
                   P_IMS_IF_MES_WIS_INTERFACE.MES_BATCH_ID || ',出错原因：' ||
                   SUBSTR(SQLERRM, 1, 200);
  END;
  ----------------------------------------------------------------------------------------
  --按组织同步ERP工单信息主过程，原视图拆分的新视图：
  --工单信息：apps.CUX_WIP_IMSMAPPING_V@mdims2mderp
  --订单关系：apps.CUX_ASCP_SOMAPPING_V@mdims2mdaps
  ----------------------------------------------------------------------------------------
  PROCEDURE P_INV_WIP_SYN(P_ORGANIZATION_ID IN INTF_INV_WIP_IN_INFO_ERP.ORGANIZATION_ID%TYPE, --组织ID
                          P_WIP_DELAY_HOURS IN NUMBER, --工单增量时间，单位：小时
                          P_RESULT          IN OUT NUMBER, --返回错误ID
                          P_ERR_MSG         IN OUT VARCHAR2 --返回错误信息
                          ) IS
  
    V_WIP_DELAY_HOURS NUMBER; --工单增量时间
    V_CNT             NUMBER;
    V_SOURCE_TYPE     VARCHAR2(100); --更新来源
  
  BEGIN
    V_SOURCE_TYPE     := 'THREAD_JOB_NEW';
    V_WIP_DELAY_HOURS := 1; --默认一小时
  
    --同步工单信息
    BEGIN
      P_RESULT  := 0;
      P_ERR_MSG := 'SUCCESS';
    
      IF P_WIP_DELAY_HOURS IS NOT NULL THEN
        V_WIP_DELAY_HOURS := P_WIP_DELAY_HOURS;
      END IF;
    
      --新视图：CUX_WIP_IMSMAPPING_V
      FOR R_ERP_WIP IN (SELECT *
                          FROM APPS.CUX_WIP_IMSMAPPING_V@MDIMS2MDERP CW
                         WHERE 1 = 1
                           AND CW.ORGANIZATION_ID = P_ORGANIZATION_ID
                           AND CW.LAST_UPDATE_DATE >
                               SYSDATE - V_WIP_DELAY_HOURS / 24) LOOP
        --插入工单表
        BEGIN
          INSERT INTO CIMS.INTF_INV_WIP_IN_INFO_ERP
            (ORGANIZATION_ID,
             WIP_ENTITY_ID,
             WIP_ENTITY_NAME,
             STATUS_TYPE,
             PRIMARY_ITEM_ID,
             PRIMARY_ITEM_NAME,
             PRIMARY_ITEM_DESC,
             JOB_TYPE,
             CLASS_CODE,
             COMPLETION_SUBINVENTORY,
             COMPLETION_LOCATOR_ID,
             DESCRIPTION,
             START_QUANTITY,
             QUANTITY_SCRAPPED,
             QUANTITY_COMPLETED,
             SCHEDULED_COMPLETION_DATE,
             SCHEDULED_START_DATE,
             SCHEDULE_GROUP_ID,
             SCHEDULE_GROUP_NAME,
             SOURCE_CODE,
             ATTRIBUTE1,
             ATTRIBUTE2,
             ATTRIBUTE3,
             ATTRIBUTE5,
             ATTRIBUTE12,
             ATTRIBUTE8,
             ATTRIBUTE9,
             LAST_UPDATE_DATE,
             UNIT_CODE,
             SEIBANID,
             SEIBANNUMBER,
             WIP_ENTITY_CODE,
             INTF_STATE,
             LAST_UPDATED_BY,
             INTF_ID,
             INTF_ERR_MSG,
             ENTI_END_DATE)
          VALUES
            (R_ERP_WIP.ORGANIZATION_ID, --组织ID
             R_ERP_WIP.WIP_ENTITY_ID, --工单ID
             R_ERP_WIP.WIP_ENTITY_NAME, --工单编码
             R_ERP_WIP.STATUS_TYPE, --工单状态
             NULL, --APS产品ID，IMS不需要
             R_ERP_WIP.SALES_ITEM_NUMBER, --产品编码
             R_ERP_WIP.ITEM_DESCRIPTION, --产品描述（名称）
             NULL, --JOB_TYPE,新的视图没有
             NULL, --CLASS_CODE,新的视图没有
             R_ERP_WIP.COMPLETION_SUBINVENTORY, --工单完工子库
             NULL, --工单完工货位ID,新的视图没有
             R_ERP_WIP.DESCRIPTION, --工单说明
             R_ERP_WIP.START_QUANTITY, --起始数量   
             NULL, --报废数量,新的视图没有
             R_ERP_WIP.QUANTITY_COMPLETED, --完工数量
             R_ERP_WIP.SCHEDULED_COMPLETION_DATE, --计划完成日期
             R_ERP_WIP.SCHEDULED_START_DATE, --计划开始日期
             NULL, --计划组ID,新的视图没有
             R_ERP_WIP.SCHEDULE_GROUP_NAME, --计划组
             V_SOURCE_TYPE, --SOURCE_CODE来源系统,新的视图没有
             NULL, --ATTRIBUTE1,新的视图没有
             NULL, --ATTRIBUTE2,新的视图没有
             NULL, --ATTRIBUTE3,新的视图没有
             NULL, --ATTRIBUTE5,新的视图没有
             NULL, --ATTRIBUTE12,新的视图没有
             NULL, --ATTRIBUTE8,新的视图没有
             NULL, --ATTRIBUTE9,新的视图没有
             NULL, --LAST_UPDATE_DATE,按照ESB接口，JAVA代码没存值，调用李振的存储过程更新该字段
             NULL, --单位代码,新的视图没有
             TO_CHAR(R_ERP_WIP.SEIBAN_ID), --SEIBANID
             NULL, --SEIBANNUMBER,新的视图没有
             NULL, --WIP_ENTITY_CODE,新的视图没有
             'I', --接口状态，新增，表示没处理
             V_SOURCE_TYPE, --LAST_UPDATED_BY
             S_INTF_INV_WIP_IN_INFO_ERP.NEXTVAL, --序列ID
             NULL, --接口错误信息
             R_ERP_WIP.REALITY_COMPLETE_DATE --实际完工日期
             );
        EXCEPTION
          WHEN OTHERS THEN
            P_RESULT  := -1;
            P_ERR_MSG := '处理ERP工单同步出错(行)：' || SUBSTR(SQLERRM, 1, 500);
            PKG_PLN_PUB.P_WRITE_JOB_LOG(P_MODULE_CODE          => 'INV',
                                        P_PROCEDURE_NAME       => 'P_INV_WIP_ERP_SYN',
                                        P_ERROR_MSG            => 'PROJECT_ID:' ||
                                                                  R_ERP_WIP.SEIBAN_ID ||
                                                                  ',工单ID:' ||
                                                                  R_ERP_WIP.WIP_ENTITY_ID ||
                                                                  ',组织ID：' ||
                                                                  P_ORGANIZATION_ID ||
                                                                  P_ERR_MSG,
                                        P_SOURCE_ORDER_HEAD_ID => NULL,
                                        P_SOURCE_ORDER_LINE_ID => NULL,
                                        P_ITEM_ID              => NULL,
                                        P_INVENTORY_ID         => NULL,
                                        P_QUANTITY             => NULL);
          
        END;
      
        --处理订单关系表
        BEGIN
          --如果本地没有，查询一遍视图数据
          SELECT COUNT(1)
            INTO V_CNT
            FROM INTF_PLN_WIP_RELATION_APS IR
           WHERE IR.PROJECT_ID = R_ERP_WIP.SEIBAN_ID
             AND IR.ORGANIZATION_ID = P_ORGANIZATION_ID;
          IF V_CNT = 0 THEN
            BEGIN
              FOR R_ERP_WIP_ORDER IN (SELECT *
                                        FROM APPS.CUX_ASCP_SOMAPPING_V@MDIMS2MDAPS SO
                                       WHERE 1 = 1
                                         AND SO.ORGANIZATION_ID =
                                             P_ORGANIZATION_ID
                                         AND SO.PROJECT_ID =
                                             R_ERP_WIP.SEIBAN_ID) LOOP
              
                INSERT INTO INTF_PLN_WIP_RELATION_APS
                  (INTF_ID,
                   PROJECT_ID,
                   ORGANIZATION_ID,
                   ITEM_CODE,
                   PLN_REQUEST_QTY,
                   ORDER_DETAIL_ID,
                   CREATED_BY,
                   CREATION_DATE,
                   LAST_UPDATED_BY,
                   LAST_UPDATE_DATE,
                   APS_LAST_UPDATE_DATE,
                   INTF_STATUS)
                VALUES
                  (S_INTF_PLN_WIP_ORDER_RELATION.NEXTVAL, --序列ID
                   R_ERP_WIP_ORDER.PROJECT_ID, --APS 塞班ID
                   R_ERP_WIP_ORDER.ORGANIZATION_ID, --组织ID
                   R_ERP_WIP_ORDER.SERIES_CODE, --物料编码
                   R_ERP_WIP_ORDER.REQ_QTY, --匹配数量
                   R_ERP_WIP_ORDER.DEMAND_ID, --订单明细ID
                   V_SOURCE_TYPE,
                   SYSDATE,
                   V_SOURCE_TYPE,
                   SYSDATE,
                   R_ERP_WIP_ORDER.LAST_UPDATE_DATE,
                   'I');
              
              END LOOP;
            EXCEPTION
              WHEN OTHERS THEN
                P_RESULT  := -1;
                P_ERR_MSG := '处理订单关系同步出错(行)：' || SUBSTR(SQLERRM, 1, 500);
                PKG_PLN_PUB.P_WRITE_JOB_LOG(P_MODULE_CODE          => 'INV',
                                            P_PROCEDURE_NAME       => 'P_INV_WIP_ERP_SYN',
                                            P_ERROR_MSG            => 'PROJECT_ID:' ||
                                                                      R_ERP_WIP.SEIBAN_ID ||
                                                                      ',组织ID：' ||
                                                                      P_ORGANIZATION_ID ||
                                                                      P_ERR_MSG,
                                            P_SOURCE_ORDER_HEAD_ID => NULL,
                                            P_SOURCE_ORDER_LINE_ID => NULL,
                                            P_ITEM_ID              => NULL,
                                            P_INVENTORY_ID         => NULL,
                                            P_QUANTITY             => NULL);
              
            END;
          END IF;
        
          --新旧接口表数据转换，方便调用原来处理过程处理
          FOR R_ERP_WIP_ORDER_DETAIL IN (SELECT *
                                           FROM INTF_PLN_WIP_RELATION_APS IR
                                          WHERE 1 = 1
                                            AND IR.ORGANIZATION_ID =
                                                P_ORGANIZATION_ID
                                            AND IR.PROJECT_ID =
                                                R_ERP_WIP.SEIBAN_ID) LOOP
            INSERT INTO CIMS.INTF_PLN_WIP_ORDER_RELATION
              (INTF_ID,
               ORGANIZATION_ID, --组织ID（ERP库存组织ID）
               WIP_ENTITY_ID, --工单ID
               WIP_ENTITY_CODE, --工单号
               WIP_ENTITY_DESC, --工单描述
               ITEM_CODE, --产品编码（散件，销售码）
               ITEM_NAME, --产品描述
               WIP_SCHEDULE_QTY, --工单数量
               PLN_REQUEST_QTY, --订单匹配数量
               ORDER_DETAIL_ID, --计划订单明细行ID
               WIP_REQUEST_QTY, --工单完工数量
               SCHEDULED_START_DATE, --计划启动日期（工单）
               SCHEDULED_COMPLETED_DATE, --计划完成日期
               CREATED_BY,
               CREATION_DATE,
               LAST_UPDATED_BY,
               LAST_UPDATE_DATE,
               REAMRK,
               INTF_STATUS, --接口数据状态：I：ERP插入 U：已更新正式表 D：接口数据作废  E:引入正式表错误
               INTF_ERR_MSG,
               WORKSHOP_INV_CODE--完工子库，车间仓
               )
            VALUES
              (S_INTF_PLN_WIP_ORDER_RELATION.NEXTVAL, --序列ID
               R_ERP_WIP_ORDER_DETAIL.ORGANIZATION_ID, --组织ID
               R_ERP_WIP.WIP_ENTITY_ID, --工单ID
               R_ERP_WIP.WIP_ENTITY_NAME, --工单编码
               R_ERP_WIP.DESCRIPTION, --工单描述
               R_ERP_WIP.SALES_ITEM_NUMBER, --产品编码
               R_ERP_WIP.ITEM_DESCRIPTION, --产品描述（名称）
               R_ERP_WIP.START_QUANTITY, --工单数量
               R_ERP_WIP_ORDER_DETAIL.PLN_REQUEST_QTY, --订单匹配数量
               R_ERP_WIP_ORDER_DETAIL.ORDER_DETAIL_ID, --计划订单明细行ID
               R_ERP_WIP.QUANTITY_COMPLETED, --工单完工数量
               TO_CHAR(R_ERP_WIP.SCHEDULED_START_DATE,
                       'YYYY-MM-DD HH24:MI:SS'), --计划启动日期（工单）
               TO_CHAR(R_ERP_WIP.SCHEDULED_COMPLETION_DATE,
                       'YYYY-MM-DD HH24:MI:SS'), --计划完成日期
               V_SOURCE_TYPE,
               SYSDATE,
               V_SOURCE_TYPE,
               SYSDATE,
               '新接口',
               'I', --接口状态，新增，表示没处理
               NULL, --接口错误信息
               R_ERP_WIP.COMPLETION_SUBINVENTORY --完工子库，车间仓
               );
          END LOOP;
        EXCEPTION
          WHEN OTHERS THEN
            P_RESULT  := -1;
            P_ERR_MSG := '处理ERP工单同步及匹配关系出错(行)：' || SUBSTR(SQLERRM, 1, 500);
            PKG_PLN_PUB.P_WRITE_JOB_LOG(P_MODULE_CODE          => 'INV',
                                        P_PROCEDURE_NAME       => 'P_INV_WIP_ERP_SYN',
                                        P_ERROR_MSG            => 'PROJECT_ID:' ||
                                                                  R_ERP_WIP.SEIBAN_ID ||
                                                                  ',工单ID:' ||
                                                                  R_ERP_WIP.WIP_ENTITY_ID ||
                                                                  ',组织ID：' ||
                                                                  P_ORGANIZATION_ID ||
                                                                  P_ERR_MSG,
                                        P_SOURCE_ORDER_HEAD_ID => NULL,
                                        P_SOURCE_ORDER_LINE_ID => NULL,
                                        P_ITEM_ID              => NULL,
                                        P_INVENTORY_ID         => NULL,
                                        P_QUANTITY             => NULL);
          
        END;
        COMMIT; --按单条工单记录提交
      END LOOP;
    
    EXCEPTION
      WHEN OTHERS THEN
        P_RESULT  := -1;
        P_ERR_MSG := '处理ERP工单同步出错：' || SUBSTR(SQLERRM, 1, 500);
        PKG_PLN_PUB.P_WRITE_JOB_LOG(P_MODULE_CODE          => 'INV',
                                    P_PROCEDURE_NAME       => 'P_INV_WIP_ERP_SYN',
                                    P_ERROR_MSG            => '组织ID：' ||
                                                              P_ORGANIZATION_ID ||
                                                              P_ERR_MSG,
                                    P_SOURCE_ORDER_HEAD_ID => NULL,
                                    P_SOURCE_ORDER_LINE_ID => NULL,
                                    P_ITEM_ID              => NULL,
                                    P_INVENTORY_ID         => NULL,
                                    P_QUANTITY             => NULL);
    END;
  
    --调用原过程处理
    PKG_INV_WIP.P_INV_WIP_ERP(P_ORGANIZATION_ID, V_SOURCE_TYPE, P_ERR_MSG);
  
  EXCEPTION
    WHEN OTHERS THEN
    
      P_RESULT  := -1;
      P_ERR_MSG := '处理工单信息出错：' || SUBSTR(SQLERRM, 1, 500);
      PKG_PLN_PUB.P_WRITE_JOB_LOG(P_MODULE_CODE          => 'INV',
                                  P_PROCEDURE_NAME       => 'P_INV_WIP_APS_SYN',
                                  P_ERROR_MSG            => '组织ID：' ||
                                                            P_ORGANIZATION_ID ||
                                                            P_ERR_MSG,
                                  P_SOURCE_ORDER_HEAD_ID => NULL,
                                  P_SOURCE_ORDER_LINE_ID => NULL,
                                  P_ITEM_ID              => NULL,
                                  P_INVENTORY_ID         => NULL,
                                  P_QUANTITY             => NULL);
  END;

  ----------------------------------------------------------------------------------------
  --按组织同步APS工单与订单关系信息主过程，原视图拆分的新视图：
  --工单信息：apps.CUX_WIP_IMSMAPPING_V@mdims2mderp
  --订单关系：apps.CUX_ASCP_SOMAPPING_V@mdims2mdaps
  ----------------------------------------------------------------------------------------
  PROCEDURE P_INV_WIP_ORDER_SYN(P_ORGANIZATION_ID       IN INTF_INV_WIP_IN_INFO_ERP.ORGANIZATION_ID%TYPE, --组织ID
                                P_WIP_ORDER_DELAY_HOURS IN NUMBER, --订单关系增量时间，单位：小时
                                P_RESULT                IN OUT NUMBER, --返回错误ID
                                P_ERR_MSG               IN OUT VARCHAR2 --返回错误信息
                                ) IS
    V_WIP_ORDER_DELAY_HOURS NUMBER; --订单关系增量时间
    V_CNT                   NUMBER;
    V_SOURCE_TYPE           VARCHAR2(100);
  
    --同步订单关系
  BEGIN
    V_SOURCE_TYPE := 'THREAD_JOB_NEW';
    --默认一小时
    V_WIP_ORDER_DELAY_HOURS := 1;
    P_RESULT                := 0;
    P_ERR_MSG               := 'SUCCESS';
  
    IF P_WIP_ORDER_DELAY_HOURS IS NOT NULL THEN
      V_WIP_ORDER_DELAY_HOURS := P_WIP_ORDER_DELAY_HOURS;
    END IF;
  
    FOR R_ERP_WIP_ORDER IN (SELECT *
                              FROM APPS.CUX_ASCP_SOMAPPING_V@MDIMS2MDAPS CW
                             WHERE 1 = 1
                               AND CW.ORGANIZATION_ID = P_ORGANIZATION_ID
                               AND CW.LAST_UPDATE_DATE >
                                   SYSDATE - V_WIP_ORDER_DELAY_HOURS / 24) LOOP
      BEGIN
        SELECT COUNT(*)
          INTO V_CNT
          FROM CIMS.INTF_PLN_WIP_RELATION_APS I
         WHERE I.PROJECT_ID = R_ERP_WIP_ORDER.PROJECT_ID
           AND I.ORDER_DETAIL_ID = R_ERP_WIP_ORDER.DEMAND_ID;
      
        IF V_CNT = 0 THEN
          --新增
          INSERT INTO INTF_PLN_WIP_RELATION_APS
            (INTF_ID,
             PROJECT_ID,
             ORGANIZATION_ID,
             ITEM_CODE,
             PLN_REQUEST_QTY,
             ORDER_DETAIL_ID,
             CREATED_BY,
             CREATION_DATE,
             LAST_UPDATED_BY,
             LAST_UPDATE_DATE,
             APS_LAST_UPDATE_DATE,
             INTF_STATUS)
          VALUES
            (S_INTF_PLN_WIP_ORDER_RELATION.NEXTVAL, --序列ID
             R_ERP_WIP_ORDER.PROJECT_ID, --APS 塞班ID
             R_ERP_WIP_ORDER.ORGANIZATION_ID, --组织ID
             R_ERP_WIP_ORDER.SERIES_CODE, --物料编码
             R_ERP_WIP_ORDER.REQ_QTY, --匹配数量
             R_ERP_WIP_ORDER.DEMAND_ID, --订单明细ID
             V_SOURCE_TYPE,
             SYSDATE,
             V_SOURCE_TYPE,
             SYSDATE,
             R_ERP_WIP_ORDER.LAST_UPDATE_DATE,
             'I');
        END IF;
      EXCEPTION
        WHEN OTHERS THEN
          P_RESULT  := -1;
          P_ERR_MSG := '处理订单关系同步出错(行)：' || SUBSTR(SQLERRM, 1, 500);
          PKG_PLN_PUB.P_WRITE_JOB_LOG(P_MODULE_CODE          => 'INV',
                                      P_PROCEDURE_NAME       => 'P_INV_WIP_ERP_SYN',
                                      P_ERROR_MSG            => 'PROJECT_ID:' ||
                                                                R_ERP_WIP_ORDER.PROJECT_ID ||
                                                                ',订单ID:' ||
                                                                R_ERP_WIP_ORDER.DEMAND_ID ||
                                                                ',组织ID：' ||
                                                                P_ORGANIZATION_ID ||
                                                                P_ERR_MSG,
                                      P_SOURCE_ORDER_HEAD_ID => NULL,
                                      P_SOURCE_ORDER_LINE_ID => NULL,
                                      P_ITEM_ID              => NULL,
                                      P_INVENTORY_ID         => NULL,
                                      P_QUANTITY             => NULL);
        
      END;
      COMMIT; --按单条订单关系记录提交
    END LOOP;
  
  EXCEPTION
    WHEN OTHERS THEN
      P_RESULT  := -1;
      P_ERR_MSG := '处理订单关系同步出错：' || SUBSTR(SQLERRM, 1, 500);
      PKG_PLN_PUB.P_WRITE_JOB_LOG(P_MODULE_CODE          => 'INV',
                                  P_PROCEDURE_NAME       => 'P_INV_WIP_ERP_SYN',
                                  P_ERROR_MSG            => '组织ID：' ||
                                                            P_ORGANIZATION_ID ||
                                                            P_ERR_MSG,
                                  P_SOURCE_ORDER_HEAD_ID => NULL,
                                  P_SOURCE_ORDER_LINE_ID => NULL,
                                  P_ITEM_ID              => NULL,
                                  P_INVENTORY_ID         => NULL,
                                  P_QUANTITY             => NULL);
  END;

  ----------------------------------------------------------------------------------------
  --检漏工单同步，原视图拆分的新视图：
  --工单信息：apps.CUX_WIP_IMSMAPPING_V@mdims2mderp
  --订单关系：apps.CUX_ASCP_SOMAPPING_V@mdims2mdaps
  ----------------------------------------------------------------------------------------
  PROCEDURE P_INV_WIP_CHECK_SYN(P_ORGANIZATION_ID IN INTF_INV_WIP_IN_INFO_ERP.ORGANIZATION_ID%TYPE, --组织ID
                                P_WIP_DELAY_HOURS IN NUMBER, --工单增量时间，单位：小时
                                P_RESULT          IN OUT NUMBER, --返回错误ID
                                P_ERR_MSG         IN OUT VARCHAR2 --返回错误信息
                                ) IS
  
    V_WIP_DELAY_HOURS NUMBER; --工单增量时间
    V_CNT             NUMBER;
    V_SOURCE_TYPE     VARCHAR2(100); --更新来源
  
  BEGIN
    V_SOURCE_TYPE     := 'THREAD_JOB_NEW_CHECK';
    V_WIP_DELAY_HOURS := 1; --默认一小时
  
    --同步工单信息
    BEGIN
      P_RESULT  := 0;
      P_ERR_MSG := 'SUCCESS';
    
      IF P_WIP_DELAY_HOURS IS NOT NULL THEN
        V_WIP_DELAY_HOURS := P_WIP_DELAY_HOURS;
      END IF;
    
      --新视图：CUX_WIP_IMSMAPPING_V
      FOR R_ERP_WIP IN (SELECT /*+ DRIVING_SITE */
                         *
                          FROM APPS.CUX_WIP_IMSMAPPING_V@MDIMS2MDERP CW
                         WHERE 1 = 1
                           AND CW.ORGANIZATION_ID = P_ORGANIZATION_ID
                           and not exists
                         (select 1
                                  from cims.t_inv_wip_in_info ii
                                 where ii.wip_entity_id = cw.wip_entity_id
                                   and CW.ORGANIZATION_ID =
                                       ii.ORGANIZATION_ID
                                   and ii.last_update_date > sysdate - 30)
                           AND CW.LAST_UPDATE_DATE >
                               SYSDATE - V_WIP_DELAY_HOURS / 24) LOOP
        --插入工单表
        BEGIN
          INSERT INTO CIMS.INTF_INV_WIP_IN_INFO_ERP
            (ORGANIZATION_ID,
             WIP_ENTITY_ID,
             WIP_ENTITY_NAME,
             STATUS_TYPE,
             PRIMARY_ITEM_ID,
             PRIMARY_ITEM_NAME,
             PRIMARY_ITEM_DESC,
             JOB_TYPE,
             CLASS_CODE,
             COMPLETION_SUBINVENTORY,
             COMPLETION_LOCATOR_ID,
             DESCRIPTION,
             START_QUANTITY,
             QUANTITY_SCRAPPED,
             QUANTITY_COMPLETED,
             SCHEDULED_COMPLETION_DATE,
             SCHEDULED_START_DATE,
             SCHEDULE_GROUP_ID,
             SCHEDULE_GROUP_NAME,
             SOURCE_CODE,
             ATTRIBUTE1,
             ATTRIBUTE2,
             ATTRIBUTE3,
             ATTRIBUTE5,
             ATTRIBUTE12,
             ATTRIBUTE8,
             ATTRIBUTE9,
             LAST_UPDATE_DATE,
             UNIT_CODE,
             SEIBANID,
             SEIBANNUMBER,
             WIP_ENTITY_CODE,
             INTF_STATE,
             LAST_UPDATED_BY,
             INTF_ID,
             INTF_ERR_MSG,
             ENTI_END_DATE)
          VALUES
            (R_ERP_WIP.ORGANIZATION_ID, --组织ID
             R_ERP_WIP.WIP_ENTITY_ID, --工单ID
             R_ERP_WIP.WIP_ENTITY_NAME, --工单编码
             R_ERP_WIP.STATUS_TYPE, --工单状态
             NULL, --APS产品ID，IMS不需要
             R_ERP_WIP.SALES_ITEM_NUMBER, --产品编码
             R_ERP_WIP.ITEM_DESCRIPTION, --产品描述（名称）
             NULL, --JOB_TYPE,新的视图没有
             NULL, --CLASS_CODE,新的视图没有
             R_ERP_WIP.COMPLETION_SUBINVENTORY, --工单完工子库
             NULL, --工单完工货位ID,新的视图没有
             R_ERP_WIP.DESCRIPTION, --工单说明
             R_ERP_WIP.START_QUANTITY, --起始数量   
             NULL, --报废数量,新的视图没有
             R_ERP_WIP.QUANTITY_COMPLETED, --完工数量
             R_ERP_WIP.SCHEDULED_COMPLETION_DATE, --计划完成日期
             R_ERP_WIP.SCHEDULED_START_DATE, --计划开始日期
             NULL, --计划组ID,新的视图没有
             R_ERP_WIP.SCHEDULE_GROUP_NAME, --计划组
             V_SOURCE_TYPE, --SOURCE_CODE来源系统,新的视图没有
             NULL, --ATTRIBUTE1,新的视图没有
             NULL, --ATTRIBUTE2,新的视图没有
             NULL, --ATTRIBUTE3,新的视图没有
             NULL, --ATTRIBUTE5,新的视图没有
             NULL, --ATTRIBUTE12,新的视图没有
             NULL, --ATTRIBUTE8,新的视图没有
             NULL, --ATTRIBUTE9,新的视图没有
             NULL, --LAST_UPDATE_DATE,按照ESB接口，JAVA代码没存值，调用李振的存储过程更新该字段
             NULL, --单位代码,新的视图没有
             TO_CHAR(R_ERP_WIP.SEIBAN_ID), --SEIBANID
             NULL, --SEIBANNUMBER,新的视图没有
             NULL, --WIP_ENTITY_CODE,新的视图没有
             'I', --接口状态，新增，表示没处理
             V_SOURCE_TYPE, --LAST_UPDATED_BY
             S_INTF_INV_WIP_IN_INFO_ERP.NEXTVAL, --序列ID
             NULL, --接口错误信息
             R_ERP_WIP.REALITY_COMPLETE_DATE --实际完工日期
             );
        EXCEPTION
          WHEN OTHERS THEN
            P_RESULT  := -1;
            P_ERR_MSG := '处理ERP工单同步出错(行)：' || SUBSTR(SQLERRM, 1, 500);
            PKG_PLN_PUB.P_WRITE_JOB_LOG(P_MODULE_CODE          => 'INV',
                                        P_PROCEDURE_NAME       => 'P_INV_WIP_ERP_SYN',
                                        P_ERROR_MSG            => 'PROJECT_ID:' ||
                                                                  R_ERP_WIP.SEIBAN_ID ||
                                                                  ',工单ID:' ||
                                                                  R_ERP_WIP.WIP_ENTITY_ID ||
                                                                  ',组织ID：' ||
                                                                  P_ORGANIZATION_ID ||
                                                                  P_ERR_MSG,
                                        P_SOURCE_ORDER_HEAD_ID => NULL,
                                        P_SOURCE_ORDER_LINE_ID => NULL,
                                        P_ITEM_ID              => NULL,
                                        P_INVENTORY_ID         => NULL,
                                        P_QUANTITY             => NULL);
          
        END;
      
        --处理订单关系表
        BEGIN
          --如果本地没有，查询一遍视图数据
          SELECT COUNT(1)
            INTO V_CNT
            FROM INTF_PLN_WIP_RELATION_APS IR
           WHERE IR.PROJECT_ID = R_ERP_WIP.SEIBAN_ID
             AND IR.ORGANIZATION_ID = P_ORGANIZATION_ID;
          --判断是否CIMS的产品编码，否则不查询APS
          IF V_CNT = 0 THEN
             SELECT COUNT(1) INTO V_CNT FROM CIMS.T_BD_ITEM T WHERE T.ITEM_CODE = R_ERP_WIP.SALES_ITEM_NUMBER;
             IF V_CNT > 0 THEN
                V_CNT := 0;
             END IF;
          END IF;
          
          IF V_CNT = 0 THEN
            BEGIN
              FOR R_ERP_WIP_ORDER IN (SELECT *
                                        FROM APPS.CUX_ASCP_SOMAPPING_V@MDIMS2MDAPS SO
                                       WHERE 1 = 1
                                         AND SO.ORGANIZATION_ID =
                                             P_ORGANIZATION_ID
                                         AND SO.PROJECT_ID =
                                             R_ERP_WIP.SEIBAN_ID) LOOP
              
                INSERT INTO INTF_PLN_WIP_RELATION_APS
                  (INTF_ID,
                   PROJECT_ID,
                   ORGANIZATION_ID,
                   ITEM_CODE,
                   PLN_REQUEST_QTY,
                   ORDER_DETAIL_ID,
                   CREATED_BY,
                   CREATION_DATE,
                   LAST_UPDATED_BY,
                   LAST_UPDATE_DATE,
                   APS_LAST_UPDATE_DATE,
                   INTF_STATUS)
                VALUES
                  (S_INTF_PLN_WIP_ORDER_RELATION.NEXTVAL, --序列ID
                   R_ERP_WIP_ORDER.PROJECT_ID, --APS 塞班ID
                   R_ERP_WIP_ORDER.ORGANIZATION_ID, --组织ID
                   R_ERP_WIP_ORDER.SERIES_CODE, --物料编码
                   R_ERP_WIP_ORDER.REQ_QTY, --匹配数量
                   R_ERP_WIP_ORDER.DEMAND_ID, --订单明细ID
                   V_SOURCE_TYPE,
                   SYSDATE,
                   V_SOURCE_TYPE,
                   SYSDATE,
                   R_ERP_WIP_ORDER.LAST_UPDATE_DATE,
                   'I');
              
              END LOOP;
            EXCEPTION
              WHEN OTHERS THEN
                P_RESULT  := -1;
                P_ERR_MSG := '处理订单关系同步出错(行)：' || SUBSTR(SQLERRM, 1, 500);
                PKG_PLN_PUB.P_WRITE_JOB_LOG(P_MODULE_CODE          => 'INV',
                                            P_PROCEDURE_NAME       => 'P_INV_WIP_ERP_SYN',
                                            P_ERROR_MSG            => 'PROJECT_ID:' ||
                                                                      R_ERP_WIP.SEIBAN_ID ||
                                                                      ',组织ID：' ||
                                                                      P_ORGANIZATION_ID ||
                                                                      P_ERR_MSG,
                                            P_SOURCE_ORDER_HEAD_ID => NULL,
                                            P_SOURCE_ORDER_LINE_ID => NULL,
                                            P_ITEM_ID              => NULL,
                                            P_INVENTORY_ID         => NULL,
                                            P_QUANTITY             => NULL);
              
            END;
          END IF;
        
          --新旧接口表数据转换，方便调用原来处理过程处理
          FOR R_ERP_WIP_ORDER_DETAIL IN (SELECT *
                                           FROM INTF_PLN_WIP_RELATION_APS IR
                                          WHERE 1 = 1
                                            AND IR.ORGANIZATION_ID =
                                                P_ORGANIZATION_ID
                                            AND IR.PROJECT_ID =
                                                R_ERP_WIP.SEIBAN_ID) LOOP
            INSERT INTO CIMS.INTF_PLN_WIP_ORDER_RELATION
              (INTF_ID,
               ORGANIZATION_ID, --组织ID（ERP库存组织ID）
               WIP_ENTITY_ID, --工单ID
               WIP_ENTITY_CODE, --工单号
               WIP_ENTITY_DESC, --工单描述
               ITEM_CODE, --产品编码（散件，销售码）
               ITEM_NAME, --产品描述
               WIP_SCHEDULE_QTY, --工单数量
               PLN_REQUEST_QTY, --订单匹配数量
               ORDER_DETAIL_ID, --计划订单明细行ID
               WIP_REQUEST_QTY, --工单完工数量
               SCHEDULED_START_DATE, --计划启动日期（工单）
               SCHEDULED_COMPLETED_DATE, --计划完成日期
               CREATED_BY,
               CREATION_DATE,
               LAST_UPDATED_BY,
               LAST_UPDATE_DATE,
               REAMRK,
               INTF_STATUS, --接口数据状态：I：ERP插入 U：已更新正式表 D：接口数据作废  E:引入正式表错误
               INTF_ERR_MSG,
               WORKSHOP_INV_CODE--完工子库，车间仓
               )
            VALUES
              (S_INTF_PLN_WIP_ORDER_RELATION.NEXTVAL, --序列ID
               R_ERP_WIP_ORDER_DETAIL.ORGANIZATION_ID, --组织ID
               R_ERP_WIP.WIP_ENTITY_ID, --工单ID
               R_ERP_WIP.WIP_ENTITY_NAME, --工单编码
               R_ERP_WIP.DESCRIPTION, --工单描述
               R_ERP_WIP.SALES_ITEM_NUMBER, --产品编码
               R_ERP_WIP.ITEM_DESCRIPTION, --产品描述（名称）
               R_ERP_WIP.START_QUANTITY, --工单数量
               R_ERP_WIP_ORDER_DETAIL.PLN_REQUEST_QTY, --订单匹配数量
               R_ERP_WIP_ORDER_DETAIL.ORDER_DETAIL_ID, --计划订单明细行ID
               R_ERP_WIP.QUANTITY_COMPLETED, --工单完工数量
               TO_CHAR(R_ERP_WIP.SCHEDULED_START_DATE,
                       'YYYY-MM-DD HH24:MI:SS'), --计划启动日期（工单）
               TO_CHAR(R_ERP_WIP.SCHEDULED_COMPLETION_DATE,
                       'YYYY-MM-DD HH24:MI:SS'), --计划完成日期
               V_SOURCE_TYPE,
               SYSDATE,
               V_SOURCE_TYPE,
               SYSDATE,
               '新接口',
               'I', --接口状态，新增，表示没处理
               NULL, --接口错误信息
               R_ERP_WIP.Completion_Subinventory --完工子库，车间仓
               );
          END LOOP;
        EXCEPTION
          WHEN OTHERS THEN
            P_RESULT  := -1;
            P_ERR_MSG := '处理ERP工单同步及匹配关系出错(行)：' || SUBSTR(SQLERRM, 1, 500);
            PKG_PLN_PUB.P_WRITE_JOB_LOG(P_MODULE_CODE          => 'INV',
                                        P_PROCEDURE_NAME       => 'P_INV_WIP_ERP_SYN',
                                        P_ERROR_MSG            => 'PROJECT_ID:' ||
                                                                  R_ERP_WIP.SEIBAN_ID ||
                                                                  ',工单ID:' ||
                                                                  R_ERP_WIP.WIP_ENTITY_ID ||
                                                                  ',组织ID：' ||
                                                                  P_ORGANIZATION_ID ||
                                                                  P_ERR_MSG,
                                        P_SOURCE_ORDER_HEAD_ID => NULL,
                                        P_SOURCE_ORDER_LINE_ID => NULL,
                                        P_ITEM_ID              => NULL,
                                        P_INVENTORY_ID         => NULL,
                                        P_QUANTITY             => NULL);
          
        END;
        COMMIT; --按单条工单记录提交
      END LOOP;
    
    EXCEPTION
      WHEN OTHERS THEN
        P_RESULT  := -1;
        P_ERR_MSG := '处理ERP工单同步出错：' || SUBSTR(SQLERRM, 1, 500);
        PKG_PLN_PUB.P_WRITE_JOB_LOG(P_MODULE_CODE          => 'INV',
                                    P_PROCEDURE_NAME       => 'P_INV_WIP_ERP_SYN',
                                    P_ERROR_MSG            => '组织ID：' ||
                                                              P_ORGANIZATION_ID ||
                                                              P_ERR_MSG,
                                    P_SOURCE_ORDER_HEAD_ID => NULL,
                                    P_SOURCE_ORDER_LINE_ID => NULL,
                                    P_ITEM_ID              => NULL,
                                    P_INVENTORY_ID         => NULL,
                                    P_QUANTITY             => NULL);
    END;
  
    --调用原过程处理
    PKG_INV_WIP.P_INV_WIP_ERP(P_ORGANIZATION_ID, V_SOURCE_TYPE, P_ERR_MSG);
  
  EXCEPTION
    WHEN OTHERS THEN
    
      P_RESULT  := -1;
      P_ERR_MSG := '处理工单信息出错：' || SUBSTR(SQLERRM, 1, 500);
      PKG_PLN_PUB.P_WRITE_JOB_LOG(P_MODULE_CODE          => 'INV',
                                  P_PROCEDURE_NAME       => 'P_INV_WIP_APS_SYN',
                                  P_ERROR_MSG            => '组织ID：' ||
                                                            P_ORGANIZATION_ID ||
                                                            P_ERR_MSG,
                                  P_SOURCE_ORDER_HEAD_ID => NULL,
                                  P_SOURCE_ORDER_LINE_ID => NULL,
                                  P_ITEM_ID              => NULL,
                                  P_INVENTORY_ID         => NULL,
                                  P_QUANTITY             => NULL);
  END;
  
  ----------------------------------------------------------------------------------------
  --单个工单同步引入
  ----------------------------------------------------------------------------------------
  PROCEDURE P_INV_WIP_CHECK_SYN_SINGLE(P_ORGANIZATION_ID IN INTF_INV_WIP_IN_INFO_ERP.ORGANIZATION_ID%TYPE, --组织ID
                                       P_WIP_DELAY_DAYS  IN NUMBER, --工单增量时间，单位：天
                                       P_USER_ACCOUNT    IN VARCHAR2, --用户账号
                                       P_WIP_ENTITY_NAME IN VARCHAR2, --工单号
                                       P_RESULT          IN OUT NUMBER, --返回错误ID
                                       P_ERR_MSG         IN OUT VARCHAR2 --返回错误信息
                                       ) IS
  
    V_WIP_DELAY_DAYS NUMBER; --工单时间范围
    V_CNT             NUMBER;
    V_SOURCE_TYPE     VARCHAR2(100); --更新来源
  
  BEGIN
    V_SOURCE_TYPE    := P_USER_ACCOUNT;
    V_WIP_DELAY_DAYS := 30; --默认30天
  
    --同步工单信息
    BEGIN
      P_RESULT  := 0;
      P_ERR_MSG := 'SUCCESS';
    
      IF P_WIP_DELAY_DAYS IS NOT NULL THEN
        V_WIP_DELAY_DAYS := P_WIP_DELAY_DAYS;
      END IF;
    
      --新视图：CUX_WIP_IMSMAPPING_V
      FOR R_ERP_WIP IN (SELECT /*+ DRIVING_SITE */
                         *
                          FROM APPS.CUX_WIP_IMSMAPPING_V@MDIMS2MDERP CW
                         WHERE 1 = 1
                           AND CW.ORGANIZATION_ID = P_ORGANIZATION_ID
                           AND CW.WIP_ENTITY_NAME = nvl(P_WIP_ENTITY_NAME, CW.WIP_ENTITY_NAME)
                           AND CW.LAST_UPDATE_DATE >
                               SYSDATE - V_WIP_DELAY_DAYS) LOOP
        --插入工单表
        BEGIN
          INSERT INTO CIMS.INTF_INV_WIP_IN_INFO_ERP
            (ORGANIZATION_ID,
             WIP_ENTITY_ID,
             WIP_ENTITY_NAME,
             STATUS_TYPE,
             PRIMARY_ITEM_ID,
             PRIMARY_ITEM_NAME,
             PRIMARY_ITEM_DESC,
             JOB_TYPE,
             CLASS_CODE,
             COMPLETION_SUBINVENTORY,
             COMPLETION_LOCATOR_ID,
             DESCRIPTION,
             START_QUANTITY,
             QUANTITY_SCRAPPED,
             QUANTITY_COMPLETED,
             SCHEDULED_COMPLETION_DATE,
             SCHEDULED_START_DATE,
             SCHEDULE_GROUP_ID,
             SCHEDULE_GROUP_NAME,
             SOURCE_CODE,
             ATTRIBUTE1,
             ATTRIBUTE2,
             ATTRIBUTE3,
             ATTRIBUTE5,
             ATTRIBUTE12,
             ATTRIBUTE8,
             ATTRIBUTE9,
             LAST_UPDATE_DATE,
             UNIT_CODE,
             SEIBANID,
             SEIBANNUMBER,
             WIP_ENTITY_CODE,
             INTF_STATE,
             LAST_UPDATED_BY,
             INTF_ID,
             INTF_ERR_MSG,
             ENTI_END_DATE
             )
          VALUES
            (R_ERP_WIP.ORGANIZATION_ID, --组织ID
             R_ERP_WIP.WIP_ENTITY_ID, --工单ID
             R_ERP_WIP.WIP_ENTITY_NAME, --工单编码
             R_ERP_WIP.STATUS_TYPE, --工单状态
             NULL, --APS产品ID，IMS不需要
             R_ERP_WIP.SALES_ITEM_NUMBER, --产品编码
             R_ERP_WIP.ITEM_DESCRIPTION, --产品描述（名称）
             NULL, --JOB_TYPE,新的视图没有
             NULL, --CLASS_CODE,新的视图没有
             R_ERP_WIP.COMPLETION_SUBINVENTORY, --工单完工子库
             NULL, --工单完工货位ID,新的视图没有
             R_ERP_WIP.DESCRIPTION, --工单说明
             R_ERP_WIP.START_QUANTITY, --起始数量   
             NULL, --报废数量,新的视图没有
             R_ERP_WIP.QUANTITY_COMPLETED, --完工数量
             R_ERP_WIP.SCHEDULED_COMPLETION_DATE, --计划完成日期
             R_ERP_WIP.SCHEDULED_START_DATE, --计划开始日期
             NULL, --计划组ID,新的视图没有
             R_ERP_WIP.SCHEDULE_GROUP_NAME, --计划组
             V_SOURCE_TYPE, --SOURCE_CODE来源系统,新的视图没有
             NULL, --ATTRIBUTE1,新的视图没有
             NULL, --ATTRIBUTE2,新的视图没有
             NULL, --ATTRIBUTE3,新的视图没有
             NULL, --ATTRIBUTE5,新的视图没有
             NULL, --ATTRIBUTE12,新的视图没有
             NULL, --ATTRIBUTE8,新的视图没有
             NULL, --ATTRIBUTE9,新的视图没有
             NULL, --LAST_UPDATE_DATE,按照ESB接口，JAVA代码没存值，调用李振的存储过程更新该字段
             NULL, --单位代码,新的视图没有
             TO_CHAR(R_ERP_WIP.SEIBAN_ID), --SEIBANID
             NULL, --SEIBANNUMBER,新的视图没有
             NULL, --WIP_ENTITY_CODE,新的视图没有
             'I', --接口状态，新增，表示没处理
             V_SOURCE_TYPE, --LAST_UPDATED_BY
             S_INTF_INV_WIP_IN_INFO_ERP.NEXTVAL, --序列ID
             NULL, --接口错误信息
             R_ERP_WIP.REALITY_COMPLETE_DATE --实际完工日期
             );
        EXCEPTION
          WHEN OTHERS THEN
            P_RESULT  := -1;
            P_ERR_MSG := '单个处理ERP工单同步出错(行)：' || SUBSTR(SQLERRM, 1, 500);
            PKG_PLN_PUB.P_WRITE_JOB_LOG(P_MODULE_CODE          => 'INV',
                                        P_PROCEDURE_NAME       => 'P_INV_WIP_ERP_SYN',
                                        P_ERROR_MSG            => 'PROJECT_ID:' ||
                                                                  R_ERP_WIP.SEIBAN_ID ||
                                                                  ',工单ID:' ||
                                                                  R_ERP_WIP.WIP_ENTITY_ID ||
                                                                  ',组织ID：' ||
                                                                  P_ORGANIZATION_ID ||
                                                                  P_ERR_MSG,
                                        P_SOURCE_ORDER_HEAD_ID => NULL,
                                        P_SOURCE_ORDER_LINE_ID => NULL,
                                        P_ITEM_ID              => NULL,
                                        P_INVENTORY_ID         => NULL,
                                        P_QUANTITY             => NULL);
          
        END;
      
        BEGIN
          --处理订单关系表
          P_INV_WIP_ORDER_SYN_SINGLE(P_ORGANIZATION_ID => P_ORGANIZATION_ID, --组织ID
                                               P_PROJECT_ID      => R_ERP_WIP.SEIBAN_ID, --PROJECT_ID,ERP视图跟APS视图关联字段
                                               P_USER_ACCOUNT    => P_USER_ACCOUNT, --用户账号
                                               P_RESULT          => P_RESULT, --返回错误ID
                                               P_ERR_MSG         => P_ERR_MSG --返回错误信息
                                               );
          --新旧接口表数据转换，方便调用原来处理过程处理
          FOR R_ERP_WIP_ORDER_DETAIL IN (SELECT *
                                           FROM INTF_PLN_WIP_RELATION_APS IR
                                          WHERE 1 = 1
                                            AND IR.ORGANIZATION_ID =
                                                P_ORGANIZATION_ID
                                            AND IR.PROJECT_ID =
                                                R_ERP_WIP.SEIBAN_ID) LOOP
            INSERT INTO CIMS.INTF_PLN_WIP_ORDER_RELATION
              (INTF_ID,
               ORGANIZATION_ID, --组织ID（ERP库存组织ID）
               WIP_ENTITY_ID, --工单ID
               WIP_ENTITY_CODE, --工单号
               WIP_ENTITY_DESC, --工单描述
               ITEM_CODE, --产品编码（散件，销售码）
               ITEM_NAME, --产品描述
               WIP_SCHEDULE_QTY, --工单数量
               PLN_REQUEST_QTY, --订单匹配数量
               ORDER_DETAIL_ID, --计划订单明细行ID
               WIP_REQUEST_QTY, --工单完工数量
               SCHEDULED_START_DATE, --计划启动日期（工单）
               SCHEDULED_COMPLETED_DATE, --计划完成日期
               CREATED_BY,
               CREATION_DATE,
               LAST_UPDATED_BY,
               LAST_UPDATE_DATE,
               REAMRK,
               INTF_STATUS, --接口数据状态：I：ERP插入 U：已更新正式表 D：接口数据作废  E:引入正式表错误
               INTF_ERR_MSG,
               WORKSHOP_INV_CODE --完工子库，车间仓
               )
            VALUES
              (S_INTF_PLN_WIP_ORDER_RELATION.NEXTVAL, --序列ID
               R_ERP_WIP_ORDER_DETAIL.ORGANIZATION_ID, --组织ID
               R_ERP_WIP.WIP_ENTITY_ID, --工单ID
               R_ERP_WIP.WIP_ENTITY_NAME, --工单编码
               R_ERP_WIP.DESCRIPTION, --工单描述
               R_ERP_WIP.SALES_ITEM_NUMBER, --产品编码
               R_ERP_WIP.ITEM_DESCRIPTION, --产品描述（名称）
               R_ERP_WIP.START_QUANTITY, --工单数量
               R_ERP_WIP_ORDER_DETAIL.PLN_REQUEST_QTY, --订单匹配数量
               R_ERP_WIP_ORDER_DETAIL.ORDER_DETAIL_ID, --计划订单明细行ID
               R_ERP_WIP.QUANTITY_COMPLETED, --工单完工数量
               TO_CHAR(R_ERP_WIP.SCHEDULED_START_DATE,
                       'YYYY-MM-DD HH24:MI:SS'), --计划启动日期（工单）
               TO_CHAR(R_ERP_WIP.SCHEDULED_COMPLETION_DATE,
                       'YYYY-MM-DD HH24:MI:SS'), --计划完成日期
               V_SOURCE_TYPE,
               SYSDATE,
               V_SOURCE_TYPE,
               SYSDATE,
               '新接口',
               'I', --接口状态，新增，表示没处理
               NULL, --接口错误信息
               R_ERP_WIP.Completion_Subinventory --完工子库，车间仓
               );
          END LOOP;
        EXCEPTION
          WHEN OTHERS THEN
            P_RESULT  := -1;
            P_ERR_MSG := '单个处理ERP工单同步及匹配关系出错(行)：' || SUBSTR(SQLERRM, 1, 500);
            PKG_PLN_PUB.P_WRITE_JOB_LOG(P_MODULE_CODE          => 'INV',
                                        P_PROCEDURE_NAME       => 'P_INV_WIP_ERP_SYN',
                                        P_ERROR_MSG            => 'PROJECT_ID:' ||
                                                                  R_ERP_WIP.SEIBAN_ID ||
                                                                  ',工单ID:' ||
                                                                  R_ERP_WIP.WIP_ENTITY_ID ||
                                                                  ',组织ID：' ||
                                                                  P_ORGANIZATION_ID ||
                                                                  P_ERR_MSG,
                                        P_SOURCE_ORDER_HEAD_ID => NULL,
                                        P_SOURCE_ORDER_LINE_ID => NULL,
                                        P_ITEM_ID              => NULL,
                                        P_INVENTORY_ID         => NULL,
                                        P_QUANTITY             => NULL);
          
        END;
        
      END LOOP;
    
    EXCEPTION
      WHEN OTHERS THEN
        P_RESULT  := -1;
        P_ERR_MSG := '单个处理ERP工单同步出错：' || SUBSTR(SQLERRM, 1, 500);
        PKG_PLN_PUB.P_WRITE_JOB_LOG(P_MODULE_CODE          => 'INV',
                                    P_PROCEDURE_NAME       => 'P_INV_WIP_ERP_SYN',
                                    P_ERROR_MSG            => '组织ID：' ||
                                                              P_ORGANIZATION_ID ||
                                                              P_ERR_MSG,
                                    P_SOURCE_ORDER_HEAD_ID => NULL,
                                    P_SOURCE_ORDER_LINE_ID => NULL,
                                    P_ITEM_ID              => NULL,
                                    P_INVENTORY_ID         => NULL,
                                    P_QUANTITY             => NULL);
    END;
  
    --调用原过程处理
    PKG_INV_WIP.P_INV_WIP_ERP(P_ORGANIZATION_ID, V_SOURCE_TYPE, P_ERR_MSG);
  
  EXCEPTION
    WHEN OTHERS THEN
    
      P_RESULT  := -1;
      P_ERR_MSG := '单个处理工单信息出错：' || SUBSTR(SQLERRM, 1, 500);
      PKG_PLN_PUB.P_WRITE_JOB_LOG(P_MODULE_CODE          => 'INV',
                                  P_PROCEDURE_NAME       => 'P_INV_WIP_APS_SYN',
                                  P_ERROR_MSG            => '组织ID：' ||
                                                            P_ORGANIZATION_ID ||
                                                            P_ERR_MSG,
                                  P_SOURCE_ORDER_HEAD_ID => NULL,
                                  P_SOURCE_ORDER_LINE_ID => NULL,
                                  P_ITEM_ID              => NULL,
                                  P_INVENTORY_ID         => NULL,
                                  P_QUANTITY             => NULL);
  END;
  
  ----------------------------------------------------------------------------------------
  --按projectID引入工单与订单关系
  ----------------------------------------------------------------------------------------
  PROCEDURE P_INV_WIP_ORDER_SYN_SINGLE(P_ORGANIZATION_ID IN INTF_INV_WIP_IN_INFO_ERP.ORGANIZATION_ID%TYPE, --组织ID
                                       P_PROJECT_ID      IN INTF_PLN_WIP_RELATION_APS.PROJECT_ID%TYPE, --PROJECT_ID,ERP视图跟APS视图关联字段
                                       P_USER_ACCOUNT    IN VARCHAR2, --用户账号
                                       P_RESULT          IN OUT NUMBER, --返回错误ID
                                       P_ERR_MSG         IN OUT VARCHAR2 --返回错误信息
                                       ) IS
    V_CNT             NUMBER;
    V_SOURCE_TYPE     VARCHAR2(100); --更新来源
  
  BEGIN
    V_SOURCE_TYPE    := P_USER_ACCOUNT;
    P_RESULT         := 0;
    P_ERR_MSG        := 'SUCCESS';
  
    /*--处理订单关系表，如果本地没有，查询一遍视图数据
    SELECT COUNT(1)
      INTO V_CNT
      FROM INTF_PLN_WIP_RELATION_APS IR
     WHERE IR.PROJECT_ID = P_PROJECT_ID
       AND IR.ORGANIZATION_ID = P_ORGANIZATION_ID;*/
    --IF V_CNT = 0 THEN
      BEGIN
       DELETE FROM INTF_PLN_WIP_RELATION_APS IR
        WHERE IR.PROJECT_ID = P_PROJECT_ID
          AND IR.ORGANIZATION_ID = P_ORGANIZATION_ID;
       
        FOR R_ERP_WIP_ORDER IN (SELECT *
                                  FROM APPS.CUX_ASCP_SOMAPPING_V@MDIMS2MDAPS SO
                                 WHERE 1 = 1
                                   AND SO.ORGANIZATION_ID =
                                       P_ORGANIZATION_ID
                                   AND SO.PROJECT_ID = P_PROJECT_ID) LOOP
        
          INSERT INTO INTF_PLN_WIP_RELATION_APS
            (INTF_ID,
             PROJECT_ID,
             ORGANIZATION_ID,
             ITEM_CODE,
             PLN_REQUEST_QTY,
             ORDER_DETAIL_ID,
             CREATED_BY,
             CREATION_DATE,
             LAST_UPDATED_BY,
             LAST_UPDATE_DATE,
             APS_LAST_UPDATE_DATE,
             INTF_STATUS)
          VALUES
            (S_INTF_PLN_WIP_ORDER_RELATION.NEXTVAL, --序列ID
             R_ERP_WIP_ORDER.PROJECT_ID, --APS 塞班ID
             R_ERP_WIP_ORDER.ORGANIZATION_ID, --组织ID
             R_ERP_WIP_ORDER.SERIES_CODE, --物料编码
             R_ERP_WIP_ORDER.REQ_QTY, --匹配数量
             R_ERP_WIP_ORDER.DEMAND_ID, --订单明细ID
             V_SOURCE_TYPE,
             SYSDATE,
             V_SOURCE_TYPE,
             SYSDATE,
             R_ERP_WIP_ORDER.LAST_UPDATE_DATE,
             'I');
        
        END LOOP;
      EXCEPTION
        WHEN OTHERS THEN
          P_RESULT  := -1;
          P_ERR_MSG := '单个处理订单关系同步出错(行)：' || SUBSTR(SQLERRM, 1, 500);
          PKG_PLN_PUB.P_WRITE_JOB_LOG(P_MODULE_CODE          => 'INV',
                                      P_PROCEDURE_NAME       => 'P_INV_WIP_ERP_SYN',
                                      P_ERROR_MSG            => 'PROJECT_ID:' ||
                                                                P_PROJECT_ID ||
                                                                ',组织ID：' ||
                                                                P_ORGANIZATION_ID ||
                                                                P_ERR_MSG,
                                      P_SOURCE_ORDER_HEAD_ID => NULL,
                                      P_SOURCE_ORDER_LINE_ID => NULL,
                                      P_ITEM_ID              => NULL,
                                      P_INVENTORY_ID         => NULL,
                                      P_QUANTITY             => NULL);
        
      END;
    --END IF;
  
  EXCEPTION
    WHEN OTHERS THEN
    
      P_RESULT  := -1;
      P_ERR_MSG := '处理工单信息出错：' || SUBSTR(SQLERRM, 1, 500);
      PKG_PLN_PUB.P_WRITE_JOB_LOG(P_MODULE_CODE          => 'INV',
                                  P_PROCEDURE_NAME       => 'P_INV_WIP_APS_SYN',
                                  P_ERROR_MSG            => '组织ID：' ||
                                                            P_ORGANIZATION_ID ||
                                                            P_ERR_MSG,
                                  P_SOURCE_ORDER_HEAD_ID => NULL,
                                  P_SOURCE_ORDER_LINE_ID => NULL,
                                  P_ITEM_ID              => NULL,
                                  P_INVENTORY_ID         => NULL,
                                  P_QUANTITY             => NULL);
  END;

END PKG_INV_WIP_APS_VIEW;
/

