create package body      PKG_INV_INVENTORY as

  -------------------------------------------------------------------------------

  --***********************************
  -- AUTHOR: 顾金兴
  -- LAST_UPDATE_BY:顾金兴
  -- LAST_UPDATE：2015-3-30
  -- PURPOSE:盘存报表引入账面数
  --***********************************


  procedure INVENTORY_QTY(p_entityId       in number,
                          invertory_id     in number,

                          info_date        in date,
                          v_exception      out varchar2
                          --v_qty_lm        out number
                          ) is

    v_info_date                  date;
    v_max_id                     number(22);
    v_cursor_row_item_code       varchar2(100);
    v_cursor_row_item_name       varchar2(100);
    v_cursor_row_transaction_uom varchar2(100);
    v_sql                        varchar2(4000);
    v_sql_nomonthsum             varchar2(2000);
    v_ismonthsum_date            number;
    v_is_data                    number;
    v_ishistory_date             number;
     n_info_date                 number;
     v_isperiod_name             varchar(240);
     v_isperiod_name_value       varchar(240);
     v_is_data_statistic_inventory number;
    v_check_separate_or_combine varchar2(10); -- by sushu 2017-03-16
    v_statistic_inventory_code varchar2(100); --by sushu 2017-03-20
    v_sql_statistic            varchar2(2000); --by sushu 2017-03-20

    v_one_temporyory t_inv_inventories%rowtype;
    type c_cursor is ref cursor;
    v_get c_cursor;
    v_get_nomonthsum c_cursor;
    v_get_statistic c_Cursor; --by sushu 2017-03-20
         cursor c_get_nomonthsum is
             select b.qty_sum sum_qty_blnc,
                    bi.item_code,
                    bi.item_name,
                    bi.defaultunit,
                    b.qty_sum,
                    b.item_id b_item_id
             from
                  (select sum(tith.transaction_quantity) qty_sum,
                          tith.item_id,
                          tith.inventory_id
                   from t_inv_transaction_history tith
                   where tith.inventory_id = invertory_id
                   and tith.creation_date >= trunc(info_date, 'mm')
                   and tith.creation_date <= trunc(info_date)
                   and tith.period_name =to_char(info_date, 'yyyy-mm')
                   group by tith.item_id, tith.inventory_id ) b,t_bd_item  bi
             where b.item_id = bi.item_id;

    cursor c_get is
               select nvl(a.qty_blnc, 0) + nvl(b.qty_sum, 0) sum_qty_blnc,
     bi.item_code,
     bi.item_name,
     bi.defaultunit,
      a.qty_blnc,
      a.item_id a_item_id,
      a.inventory_id a_inventory_id,
      b.qty_sum,
      b.item_id b_item_id,
      b.inventory_id b_inventory_id
  from (select m.qty_blnc, m.item_id, m.inventory_id
               from (select tim.ENDSUM qty_blnc,
               tim.item_id,
               tim.period_name,
               tim.inventory_id,
               tim.period_id
          from T_INV_TRANSMIT_RECEIVE tim
         where tim.inventory_id = invertory_id) m

         where m.period_name = v_isperiod_name_value) a,

       (select sum(tith.transaction_quantity) qty_sum,
               tith.item_id,
              tith.inventory_id
          from t_inv_transaction_history tith
         where tith.inventory_id = invertory_id
           and tith.creation_date >= add_months(to_date(v_isperiod_name_value,'yyyy-mm'),1)
           and tith.creation_date <= trunc(info_date)

         group by tith.item_id, tith.inventory_id ) b,
         t_bd_item  bi
 where a.item_id(+) = b.item_id
      and a.inventory_id(+) = b.inventory_id
      and b.item_id = bi.item_id;
    r_get c_get%rowtype;
    r_get_nomonthsum  c_get_nomonthsum%rowtype;

    v_qty_in  number;
    v_qty_out number;
    cursor statistic_cur is select * from t_inv_statistic_inventories t where t.statistic_inventory_id=invertory_id order by 1 desc;
    row_statistic_cur t_inv_statistic_inventories% rowtype;


  begin
      delete from T_INV_CHECK_INFO_TEMPORYORY where 1 = 1;
      
        
      --根据系统参数判断盘存报表是否按照仓库合并：Y合并，N拆分 by sushu 2017-03-16
      Begin
        v_check_separate_or_combine := Pkg_Bd.f_Get_Parameter_Value('inv_check_separate_or_combine',
                                                               p_entityId);
      Exception
        When Others Then
          Rollback;
          v_exception := '获取系统参数inv_check_separate_or_combine的值失败';
          Return;
      End;
      
      --v_check_separate_or_combine为Y，只查当前统计仓库，为N，查询对应配套其他类型的统计仓库 by sushu 2017-03-20
      If(v_check_separate_or_combine = 'Y') Then
        --open statistic_cur;
        Select Count(*)
          Into v_Is_Data_Statistic_Inventory
          From t_Inv_Statistic_Inventories t
         Where t.Statistic_Inventory_Id = Invertory_Id;
        If v_Is_Data_Statistic_Inventory = 0 Then
          Rollback;
          v_Exception := '请先定义该仓库的报表统计仓库设置!';
          Return;
        End If;
        
        For Row_One In (Select *
                          From t_Inv_Statistic_Inventories t
                         Where t.Statistic_Inventory_Id = Invertory_Id) Loop
          Select *
            Into v_One_Temporyory
            From t_Inv_Inventories T2
           Where T2.Inventory_Id = Row_One.Inventory_Id;
          --fetch statistic_cur into row_statistic_cur;
          --exit when statistic_cur%notfound;
          --dbms_output.put_line(row_statistic_cur.inventory_id);
        
          Select Count(1)
            Into v_Isperiod_Name
            From t_Inv_Inventory_Periods p
           Where Info_Date Between p.Begin_Date And p.End_Date
             And p.Checkout_Flag = '01'
             And p.Entity_Id = p_Entityid;
        
          If v_Isperiod_Name = 0 Then
            Select To_Char(Max(P1.End_Date), 'yyyy-mm') End_Date
              Into v_Isperiod_Name_Value
              From t_Inv_Inventory_Periods P1
             Where P1.End_Date < Info_Date
               And P1.Checkout_Flag = '01'
               And P1.Entity_Id = p_Entityid;
          
            --              v_isperiod_name_value:=v_isperiod_name;
          Else
            Select p.Period_Name
              Into v_Isperiod_Name_Value
              From t_Inv_Inventory_Periods p
             Where Info_Date Between p.Begin_Date And p.End_Date
               And p.Checkout_Flag = '01'
               And p.Entity_Id = p_Entityid;
          
          End If;
          
          
    v_sql_nomonthsum :='select b.qty_sum sum_qty_blnc,
                   bi.item_code,
                   bi.item_name,
                   bi.defaultunit,
                   b.qty_sum,
                   b.item_id b_item_id

                   from

                   (select sum(tith.transaction_quantity) qty_sum,
                            tith.item_id,
                             tith.inventory_id
                              from t_inv_transaction_history tith
                              where tith.inventory_id =  '||invertory_id||'
                              and tith.creation_date >= '''|| to_date(v_isperiod_name_value, 'yyyy-mm')|| '''
                               and tith.creation_date <= '''|| trunc(info_date)|| '''

                               group by tith.item_id, tith.inventory_id ) b,
                   t_bd_item  bi
                   where b.item_id = bi.item_id';
    v_sql := 'select tab.sum_qty_blnc,
     bi.item_code,
     bi.item_name,
     bi.defaultunit,
     tab.qty_blnc,
        tab.a_item_id,
         tab.a_inventory_id,
          tab.qty_sum,
         tab.b_item_id,
        tab.b_inventory_id

           from (
                  select nvl(a.qty_blnc, 0) + nvl(b.qty_sum, 0) sum_qty_blnc,

                        a.qty_blnc,
                        a.item_id a_item_id,
                        a.inventory_id a_inventory_id,
                        b.qty_sum,
                        b.item_id b_item_id,
                        b.inventory_id b_inventory_id
                    from (select m.qty_blnc, m.item_id, m.inventory_id
                                 from (select tim.ENDSUM qty_blnc,
                                 tim.item_id,
                                 tim.period_name,
                                 tim.inventory_id,
                                 tim.period_id
                            from cims.T_INV_TRANSMIT_RECEIVE tim
                           where tim.inventory_id ='||row_one.inventory_id||'

                            and  tim.entity_id='||p_entityId||') m

                           where m.period_name =  '''||v_isperiod_name_value||''') a
                           full join

                         (select sum(tith.transaction_quantity) qty_sum,
                                 tith.item_id,
                                tith.inventory_id
                            from cims.t_inv_transaction_history tith
                           where tith.inventory_id = '||row_one.inventory_id||'
                             and tith.entity_id='||p_entityId||'
                             and trunc(tith.transaction_date) >= '''||trunc(add_months(to_date(v_isperiod_name_value,'yyyy-mm'),1))||'''
                             and trunc(tith.transaction_date) <= '''||trunc(info_date)||'''

                           group by tith.item_id, tith.inventory_id ) b
                        on a.item_id = b.item_id
                        and a.inventory_id = b.inventory_id
      ) tab ,cims.t_bd_item  bi

      where nvl(tab.a_item_id,tab.b_item_id)=bi.item_id';
          
        
          Select Info_Date - Trunc(Sysdate) Into n_Info_Date From Dual;
          If n_Info_Date < 0 Then
          
            Begin
              Open v_Get For v_Sql;
            Exception
              --when no_data_found then
              --  null;
              --  rollback;
              When Others Then
                Rollback;
                v_Exception := '结存日期为：' || Info_Date || '，取IMS结存数量时，游标出错!' ||
                               Sqlerrm;
                Return;
            End;
          
            Loop
            
              Fetch v_Get
                Into r_Get;
              -- If v_get%Rowcount = 0 Then
              --     rollback;
              --       v_exception :='根据录入的盘存日期和财务仓，IMS系统找不到对应的产品!';
              --       return;
              --End If;
            
              Exit When v_Get%Notfound;
              /*  dbms_output.put_line(' 编码为： ' || r_get.item_code || ' 名称为： ' ||
              r_get.item_name || ' 单位：' ||
              r_get.defaultunit || ' 结存：' ||
              r_get.sum_qty_blnc);
              */
              Begin
                Insert Into t_Inv_Check_Info_Temporyory
                  (Check_Info_Line_Id,
                   Item_Code,
                   Item_Desc,
                   Uom,
                   Book_Qty,
                   Inv_Id,
                   Inv_Code,
                   Inv_Name)
                Values
                  (s_t_Inv_Check_Info_Temporary.Nextval,
                   r_Get.Item_Code,
                   r_Get.Item_Name,
                   r_Get.Defaultunit,
                   r_Get.Sum_Qty_Blnc,
                   Row_One.Statistic_Inventory_Id, --by sushu 2017-03-20
                   Row_One.Statistic_Inventory_Code, --by sushu 2017-03-20
                   Row_One.Statistic_Inventory_Name); --by sushu 2017-03-20
              
              Exception
                When Others Then
                  Rollback;
                  v_Exception := '结存日期为：' || Info_Date ||
                                 '，取IMS结存数量后，插入T_INV_CHECK_INFO_TEMPORYORY有误!' ||
                                 Sqlerrm;
                  Return;
              End;
              
            End Loop;
            Close v_Get;
          
            --truncate table t_inv_check_info_temporary;
          
            Else
            
              Begin
                Insert Into t_Inv_Check_Info_Temporyory
                  (Check_Info_Line_Id,
                   Item_Id,
                   Item_Code,
                   Item_Desc,
                   Uom,
                   Book_Qty,
                   Inv_Id, --by sushu 2017-03-16
                   Inv_Code, --by sushu 2017-03-16
                   Inv_Name) --by sushu 2017-03-16
                  Select s_t_Inv_Check_Info_Temporary.Nextval,
                         A2.*,
                         Row_One.Statistic_Inventory_Id, --by sushu 2017-03-16
                         Row_One.Statistic_Inventory_Code, --by sushu 2017-03-16
                         Row_One.Statistic_Inventory_Name --by sushu 2017-03-16
                    From (Select T1.Item_Id,
                                 T2.Item_Code,
                                 T2.Item_Name,
                                 T2.Defaultunit,
                                 Sum(T1.Quantity)
                            From t_Inv_Onhand T1, t_Bd_Item T2
                           Where T1.Item_Id = T2.Item_Id
                             And T1.Inventory_Id = Row_One.Inventory_Id
                             And T1.Entity_Id = p_Entityid
                           Group By T1.Item_Id,
                                    T2.Item_Code,
                                    T2.Item_Name,
                                    T2.Defaultunit) A2;
              Exception
                When Others Then
                  Rollback;
                  v_Exception := '结存日期为：' || Info_Date ||
                                 '，取IMS库存现有量，插入T_INV_CHECK_INFO_TEMPORYORY有误!' ||
                                 Sqlerrm;
                  Return;
              End;
            
            End If;
          End Loop;
          --close statistic_cur;
      Elsif(v_check_separate_or_combine = 'N') Then
          --open statistic_cur;
          Begin
           Select Distinct t.Statistic_Inventory_Code
             Into v_Statistic_Inventory_Code
             From t_Inv_Statistic_Inventories t
            Where t.Statistic_Inventory_Id = Invertory_Id;
          Exception
            When Others Then
              Rollback;
              v_Exception := '查询报表统计仓库设置信息失败!';
              Return;
          End;
          
          Select substr(v_Statistic_Inventory_Code,1,length(v_Statistic_Inventory_Code)-1) Into v_Statistic_Inventory_Code From dual;
          Begin
            Execute Immediate '         
            Select Count(*)
              From t_Inv_Statistic_Inventories t
             Where t.Statistic_Inventory_Code Like ''' ||
                              v_Statistic_Inventory_Code || '%'' ' ||
                              '  And t.Entity_Id = :1'
              Into v_Is_Data_Statistic_Inventory
              Using p_Entityid;
          Exception
            When Others Then
              Rollback;
              v_Exception := '查询报表统计仓库设置信息失败!';
              Return;
          End;
          if v_is_data_statistic_inventory=0 then
                rollback;
                v_exception :='请先定义该仓库的报表统计仓库设置!';
                return;
          end if;

          v_sql_statistic := 'select * from t_inv_statistic_inventories t where t.Statistic_Inventory_Code Like '''
                             ||v_Statistic_Inventory_Code||'%'' ' 
                             ||'And t.Entity_Id ='|| p_Entityid;
                             
           Begin
              Open v_get_statistic For v_sql_statistic;
           Exception
              When Others Then
                Rollback;
                v_Exception := '取统计仓库信息时，游标出错!' || Sqlerrm;
                Return;
           End;

          Loop
            Fetch v_get_statistic Into row_statistic_cur;
            Exit When v_get_statistic%Notfound;
              select * into v_one_temporyory from t_inv_inventories t2 where t2.inventory_id=row_statistic_cur.inventory_id;
            --fetch statistic_cur into row_statistic_cur;
            --exit when statistic_cur%notfound;
            --dbms_output.put_line(row_statistic_cur.inventory_id);


          select count(1) into v_isperiod_name from t_inv_inventory_periods p where info_date between p.begin_date and p.end_date and p.checkout_flag='01' and p.entity_id=p_entityId;

                 if v_isperiod_name =0 then
                   select to_char(max(p1.end_date), 'yyyy-mm') end_date into v_isperiod_name_value
                                               from t_inv_inventory_periods p1
                                               where p1.end_date < info_date
                                               and p1.checkout_flag = '01'
                                               and p1.entity_id=p_entityId;

      --              v_isperiod_name_value:=v_isperiod_name;
                 else
          select p.period_name into v_isperiod_name_value from t_inv_inventory_periods p where info_date between p.begin_date and p.end_date and p.checkout_flag='01' and p.entity_id=p_entityId;

                 end if;
                 

                v_sql_nomonthsum :='select b.qty_sum sum_qty_blnc,
                               bi.item_code,
                               bi.item_name,
                               bi.defaultunit,
                               b.qty_sum,
                               b.item_id b_item_id

                               from

                               (select sum(tith.transaction_quantity) qty_sum,
                                        tith.item_id,
                                         tith.inventory_id
                                          from t_inv_transaction_history tith
                                          where tith.inventory_id =  '||invertory_id||'
                                          and tith.creation_date >= '''|| to_date(v_isperiod_name_value, 'yyyy-mm')|| '''
                                           and tith.creation_date <= '''|| trunc(info_date)|| '''

                                           group by tith.item_id, tith.inventory_id ) b,
                               t_bd_item  bi
                               where b.item_id = bi.item_id';
    v_sql := 'select tab.sum_qty_blnc,
     bi.item_code,
     bi.item_name,
     bi.defaultunit,
     tab.qty_blnc,
        tab.a_item_id,
         tab.a_inventory_id,
          tab.qty_sum,
         tab.b_item_id,
        tab.b_inventory_id

           from (
                  select nvl(a.qty_blnc, 0) + nvl(b.qty_sum, 0) sum_qty_blnc,

                        a.qty_blnc,
                        a.item_id a_item_id,
                        a.inventory_id a_inventory_id,
                        b.qty_sum,
                        b.item_id b_item_id,
                        b.inventory_id b_inventory_id
                    from (select m.qty_blnc, m.item_id, m.inventory_id
                                 from (select tim.ENDSUM qty_blnc,
                                 tim.item_id,
                                 tim.period_name,
                                 tim.inventory_id,
                                 tim.period_id
                            from cims.T_INV_TRANSMIT_RECEIVE tim
                           where tim.inventory_id ='||row_statistic_cur.inventory_id||'

                            and  tim.entity_id='||p_entityId||') m

                           where m.period_name =  '''||v_isperiod_name_value||''') a
                           full join

                         (select sum(tith.transaction_quantity) qty_sum,
                                 tith.item_id,
                                tith.inventory_id
                            from cims.t_inv_transaction_history tith
                           where tith.inventory_id = '||row_statistic_cur.inventory_id||'
                             and tith.entity_id='||p_entityId||'
                             and trunc(tith.transaction_date) >= '''||trunc(add_months(to_date(v_isperiod_name_value,'yyyy-mm'),1))||'''
                             and trunc(tith.transaction_date) <= '''||trunc(info_date)||'''

                           group by tith.item_id, tith.inventory_id ) b
                        on a.item_id = b.item_id
                        and a.inventory_id = b.inventory_id
      ) tab ,cims.t_bd_item  bi

      where nvl(tab.a_item_id,tab.b_item_id)=bi.item_id';


           select info_date - trunc(sysdate) into n_info_date from dual;
           if n_info_date < 0 then


                       begin
                              open v_get for v_sql;
                       exception
                               --when no_data_found then
                             --  null;
                             --  rollback;
                       when others then
                               rollback;
                                v_exception :='结存日期为：'||info_date||'，取IMS结存数量时，游标出错!'||SQLERRM;
                               return;
                       end;

                     loop

                              fetch v_get
                               into r_get;
                              -- If v_get%Rowcount = 0 Then
                               --     rollback;
                              --       v_exception :='根据录入的盘存日期和财务仓，IMS系统找不到对应的产品!';
                               --       return;
                               --End If;

                               exit when v_get%notfound;
                                  /*  dbms_output.put_line(' 编码为： ' || r_get.item_code || ' 名称为： ' ||
                                     r_get.item_name || ' 单位：' ||
                                     r_get.defaultunit || ' 结存：' ||
                                     r_get.sum_qty_blnc);
                                     */
                        begin
                                     insert into T_INV_CHECK_INFO_TEMPORYORY
                                     (CHECK_INFO_LINE_ID, ITEM_CODE, ITEM_DESC, UOM, BOOK_QTY,inv_id,inv_code,inv_name)
                                     values
                                      (s_t_inv_check_info_temporary.nextval,
                                       r_get.item_code,
                                       r_get.item_name,
                                       r_get.defaultunit,
                                       r_get.sum_qty_blnc,
                                       row_statistic_cur.statistic_inventory_id,
                                       row_statistic_cur.statistic_inventory_code,
                                       row_statistic_cur.statistic_inventory_name);

                        exception
                        when others then
                             rollback;
                             v_exception :='结存日期为：'||info_date||'，取IMS结存数量后，插入T_INV_CHECK_INFO_TEMPORYORY有误!'||sqlerrm;
                             return;
                        end;
                        
                    end loop;
                    close v_get;

          --truncate table t_inv_check_info_temporary;


        else

          begin
             Insert Into t_Inv_Check_Info_Temporyory
               (Check_Info_Line_Id,
                Item_Id,
                Item_Code,
                Item_Desc,
                Uom,
                Book_Qty,
                Inv_Id, --by sushu 2017-03-16
                Inv_Code, --by sushu 2017-03-16
                Inv_Name) --by sushu 2017-03-16
               Select s_t_Inv_Check_Info_Temporary.Nextval,
                      A2.*,
                      row_statistic_cur.statistic_inventory_id, --by sushu 2017-03-16
                      row_statistic_cur.statistic_inventory_code, --by sushu 2017-03-16
                      row_statistic_cur.statistic_inventory_name --by sushu 2017-03-16
                 From (Select T1.Item_Id,
                              T2.Item_Code,
                              T2.Item_Name,
                              T2.Defaultunit,
                              Sum(T1.Quantity)
                         From t_Inv_Onhand T1, t_Bd_Item T2
                        Where T1.Item_Id = T2.Item_Id
                          And T1.Inventory_Id = row_statistic_cur.Inventory_Id
                          And T1.Entity_Id = p_Entityid
                        Group By T1.Item_Id,
                                 T2.Item_Code,
                                 T2.Item_Name,
                                 T2.Defaultunit) A2;
           exception
             when others then
                rollback;
               v_exception :='结存日期为：'||info_date||'，取IMS库存现有量，插入T_INV_CHECK_INFO_TEMPORYORY有误!'||sqlerrm;
               return;
            end;





         end if;
        end loop;
        Close v_get_statistic;
        --close statistic_cur;
      End If;


   begin
       select count(1) into v_is_data from T_INV_CHECK_INFO_TEMPORYORY;
       if v_is_data=0 then
          rollback;
          v_exception :='根据录入的盘存日期和财务仓，IMS系统找不到对应的产品!';
          return;
       end if;
    end;

    Begin
      --根据系统参数判断盘存报表是否按照仓库合并 by sushu 2017-03-16
      If(v_check_separate_or_combine = 'Y') Then
        for row_temp_one in (select t.item_code,
                       t.item_desc,
                       t.uom,
                       sum(t.book_qty) book_qty,
                       t.inv_id,--显示仓库信息  by sushu 2017-05-04
                       t.inv_code,--显示仓库信息  by sushu 2017-05-04
                       t.inv_name--显示仓库信息  by sushu 2017-05-04
                  from T_INV_CHECK_INFO_TEMPORYORY t
                 group by t.item_code, t.item_desc, t.uom,t.inv_id,t.inv_code,t.inv_name ) loop
        delete from T_INV_CHECK_INFO_TEMPORYORY t1
         where t1.item_code = row_temp_one.item_code;
        insert into T_INV_CHECK_INFO_TEMPORYORY
          (CHECK_INFO_LINE_ID, ITEM_CODE, ITEM_DESC, UOM, BOOK_QTY, inv_id, inv_code, inv_name)
        values
          (s_t_inv_check_info_temporary.nextval,
           row_temp_one.item_code,
           row_temp_one.item_desc,
           row_temp_one.uom,
           row_temp_one.book_qty,
           row_temp_one.inv_id,--显示仓库信息  by sushu 2017-05-04
           row_temp_one.inv_code,--显示仓库信息  by sushu 2017-05-04
           row_temp_one.inv_name);--显示仓库信息  by sushu 2017-05-04
         end loop;
      Elsif(v_check_separate_or_combine = 'N') Then
        for row_temp_one in (select t.item_code,
                       t.item_desc,
                       t.uom,
                       t.inv_id,
                       t.inv_code,
                       t.inv_name,
                       sum(t.book_qty) book_qty
                  from T_INV_CHECK_INFO_TEMPORYORY t
                 group by t.item_code, t.item_desc, t.uom,t.inv_id,t.inv_code,t.inv_name ) loop
          delete from T_INV_CHECK_INFO_TEMPORYORY t1
           where t1.item_code = row_temp_one.item_code And t1.inv_code = row_temp_one.inv_code;
          insert into T_INV_CHECK_INFO_TEMPORYORY
          (CHECK_INFO_LINE_ID, ITEM_CODE, ITEM_DESC, UOM, BOOK_QTY, inv_id,inv_code,inv_name)
            values
          (s_t_inv_check_info_temporary.nextval,
           row_temp_one.item_code,
           row_temp_one.item_desc,
           row_temp_one.uom,
           row_temp_one.book_qty,
           row_temp_one.inv_id,
           row_temp_one.inv_code,
           row_temp_one.inv_name );
        end loop;
      End If;

      delete from T_INV_CHECK_INFO_TEMPORYORY t where t.book_qty=0;
    end;

      v_exception :='seuccess';

  end;


  --***********************************
  -- AUTHOR: 顾金兴
  -- LAST_UPDATE_BY:顾金兴
  -- LAST_UPDATE：2015-3-20
  -- PURPOSE:盘存报表引入盘点数
  --***********************************


   Procedure INVENTORY_QTY_CHECK(inv_code        in varchar2,
                                  info_date      in Date,
                                  v_exception    out varchar2,
                                  p_entity_id      in number,
                                  p_user_code      in varchar2) is

    n_info_date number;
    v_is_data   number;
    v_is_a3_cims varchar(32);
    v_period_id number;
    v_begin_date date;
    v_check_separate_or_combine varchar2(10); -- by sushu 2017-03-16
    v_is_data_statistic_inventory Number; -- by sushu 2017-03-16
    v_Statistic_Inventory_Code varchar2(100); -- by sushu 2017-03-21
    v_sql_statistic            varchar2(2000); --by sushu 2017-03-21
    Type c_cursor Is Ref Cursor; --by sushu 2017-03-21
    v_get_statistic c_cursor; --by sushu 2017-03-21
    row_statistic_cur t_inv_statistic_inventories% rowtype; --by sushu 2017-03-21
    v_inv_inventory t_inv_inventories%Rowtype;

    Cursor c_end_qty is
      select * from T_INV_CHECK_INFO_LINETEMP where CREATED_BY = p_user_code;
    c_end_qty_row c_end_qty%rowtype;



  Begin
    
    --根据系统参数判断盘存报表是否按照仓库合并；Y合并，N拆分 by sushu 2017-03-16
    Begin
      v_Check_Separate_Or_Combine := Pkg_Bd.f_Get_Parameter_Value('inv_check_separate_or_combine',
                                                                  p_Entity_Id);
    Exception
      When Others Then
        Rollback;
        v_Exception := '获取系统参数inv_check_separate_or_combine的值失败';
        Return;
    End;
    
    if(v_Check_Separate_Or_Combine = 'Y') Then
        Begin
      
        select t.docking_system into v_is_a3_cims  from t_inv_inventories t where t.inventory_code=inv_code;
        if v_is_a3_cims='A3'then
                 --   delete T_INV_CHECK_INFO_LINETEMP where 1 = 1;
                    select info_date - trunc(sysdate) into n_info_date from dual;
                    if n_info_date < 0 then

                  begin
                     insert into T_INV_CHECK_INFO_LINETEMP
                        (CHECK_INFO_LINE_ID,
                         ITEM_CODE,
                         ITEM_DESC,
                         UOM,
                         LOGISTICS_QTY,
                         REAL_QTY,
                         KL_QTY_1M,
                         KL_QTY_2M,
                         KL_QTY_3M,
                         KL_QTY_4M,
                         KL_QTY_5M,
                         KL_QTY_6M,
                         KL_QTY_7M,
                         KL_QTY_8M,
                         KL_QTY_9M,
                         KL_QTY_10M,
                         KL_QTY_11M,
                         KL_QTY_12M,
                         KL_QTY_1Y_TO_2Y,
                         KL_QTY_2Y_TO_3Y,
                         KL_QTY_3Y_OVER,
                         CREATED_BY,
                         CREATION_DATE
                         )
                         select S_T_INV_CHECK_INFOLINESTEMP.NEXTVAL,
                                b1.item_code,
                                b1.item_name,
                                b1.defaultunit,
                                b1.sum_qty,
                                b1.real_qty,
                                b1.month_01,
                                b1.month_02,
                                b1.month_03,
                                b1.month_04,
                                b1.month_05,
                                b1.month_06,
                                b1.month_07,
                                b1.month_08,
                                b1. month_09,
                                b1.month_10,
                                b1.month_11,
                                b1.month_12,
                                b1.month_13,
                                b1.month_14,
                                b1.month_15,
                                p_user_code,
                                sysdate

                          from (select a1.item_code,tbi.item_name,tbi.defaultunit,

                       sum(nvl(month_01, 0) + nvl(month_02, 0) + nvl(month_03, 0) +
                           nvl(month_04, 0) + nvl(month_07, 0) + nvl(month_05, 0) +
                           nvl(month_06, 0) + nvl(month_08, 0) + nvl(month_09, 0) +
                           nvl(month_10, 0) + nvl(month_11, 0) + nvl(month_12, 0) +
                           nvl(month_13, 0) + nvl(month_14, 0) + nvl(month_15, 0)) sum_qty,
                       sum(nvl(month_01, 0) + nvl(month_02, 0) + nvl(month_03, 0) +
                           nvl(month_04, 0) + nvl(month_07, 0) + nvl(month_05, 0) +
                           nvl(month_06, 0) + nvl(month_08, 0) + nvl(month_09, 0) +
                           nvl(month_10, 0) + nvl(month_11, 0) + nvl(month_12, 0) +
                           nvl(month_13, 0) + nvl(month_14, 0) + nvl(month_15, 0)) real_qty,
                       sum(month_01) month_01,
                       sum(month_02) month_02,
                       sum(month_03) month_03,
                       sum(month_04) month_04,
                       sum(month_05) month_05,
                       sum(month_06) month_06,
                       sum(month_07) month_07,
                       sum(month_08) month_08,
                       sum(month_09) month_09,
                       sum(month_10) month_10,
                       sum(month_11) month_11,
                       sum(month_12) month_12,
                       sum(month_13) month_13,
                       sum(month_14) month_14,
                       sum(month_15) month_15
                  from (select ceil(months_between(trunc(info_date),
                                                   to_date('20' || t.item_batch, 'yyyy-mm'))),
                               t.item_code,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      1,
                                      t.real_qty,
                                      null) month_01,

                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      2,
                                      t.real_qty,
                                      null) month_02,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      3,
                                      t.real_qty,
                                      null) month_03,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      4,
                                      t.real_qty,
                                      null) month_04,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      5,
                                      t.real_qty,
                                      null) month_05,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      6,
                                      t.real_qty,
                                      null) month_06,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      7,
                                      t.real_qty,
                                      null) month_07,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      8,
                                      t.real_qty,
                                      null) month_08,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      9,
                                      t.real_qty,
                                      null) month_09,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      10,
                                      t.real_qty,
                                      null) month_10,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      11,
                                      t.real_qty,
                                      null) month_11,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      12,
                                      t.real_qty,
                                      null) month_12,
                               case
                                 when ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))) > 12 and
                                      ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))) <= 24 then
                                  t.real_qty
                                 else
                                  null
                               end month_13,
                               case
                                 when ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))) > 24 and
                                      ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))) <= 36 then
                                  t.real_qty
                                 else
                                  null
                               end month_14,
                               case
                                 when ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))) > 36 then
                                  t.real_qty
                                 else
                                  null
                               end month_15
                          from A3_INV_STOCK_DAILY t where
                          t.sub_inv_code = inv_code
                           and t.finance_entity_id=to_char(p_entity_id)
                           and t.stock_date = info_date
                           ) a1 ,t_bd_item tbi where a1.item_code=tbi.item_code and tbi.entity_id = p_entity_id group by a1.item_code,tbi.item_name,tbi.defaultunit) b1;

                    exception
                      when others then
                         rollback;
                         v_exception :='结存日期为：'||info_date||'，取A3结存数量有误!'||sqlerrm;
                         return;
                    end;

                    begin
                      select count(1) into v_is_data from T_INV_CHECK_INFO_LINETEMP where CREATED_BY = p_user_code;
                      if v_is_data=0 then
                         rollback;
                          v_exception :='根据录入的盘存日期和财务仓，在A3提供的数据中找不到对应的产品!';
                          return;
                      end if;
                    end;

                      for c_end_qty_row in c_end_qty loop


                        update T_INV_CHECK_INFO_TEMPORYORY
                           set item_code = c_end_qty_row.item_code,
                               item_desc = c_end_qty_row.item_desc,
                               uom       = c_end_qty_row.uom
                         where item_code = c_end_qty_row.item_code;

                        if sql%notfound then
                          insert into T_INV_CHECK_INFO_TEMPORYORY
                            (CHECK_INFO_LINE_ID,
                             ITEM_CODE,
                             ITEM_DESC,
                             UOM,
                             LOGISTICS_QTY,
                             REAL_QTY,
                             KL_QTY_1M,
                             KL_QTY_2M,
                             KL_QTY_3M,
                             KL_QTY_4M,
                             KL_QTY_5M,
                             KL_QTY_6M,
                             KL_QTY_7M,
                             KL_QTY_8M,
                             KL_QTY_9M,
                             KL_QTY_10M,
                             KL_QTY_11M,
                             KL_QTY_12M,
                             KL_QTY_1Y_TO_2Y,
                             KL_QTY_2Y_TO_3Y,
                             KL_QTY_3Y_OVER)
                          values

                            (s_t_inv_check_info_temporary.nextval,
                             nvl(c_end_qty_row.item_code, 0),
                             nvl(c_end_qty_row.item_desc, 0),
                             nvl(c_end_qty_row.uom, 0),
                             nvl(c_end_qty_row.logistics_qty, 0),
                             nvl(c_end_qty_row.real_qty, 0),
                             nvl(c_end_qty_row.kl_qty_1m, 0),
                             nvl(c_end_qty_row.kl_qty_2m, 0),
                             nvl(c_end_qty_row.kl_qty_3m, 0),
                             nvl(c_end_qty_row.kl_qty_4m, 0),
                             nvl(c_end_qty_row.kl_qty_5m, 0),
                             nvl(c_end_qty_row.kl_qty_6m, 0),
                             nvl(c_end_qty_row.kl_qty_7m, 0),
                             nvl(c_end_qty_row.kl_qty_8m, 0),
                             nvl(c_end_qty_row.kl_qty_9m, 0),
                             nvl(c_end_qty_row.kl_qty_10m, 0),
                             nvl(c_end_qty_row.kl_qty_11m, 0),
                             nvl(c_end_qty_row.kl_qty_12m, 0),
                             nvl(c_end_qty_row.kl_qty_1y_to_2y, 0),
                             nvl(c_end_qty_row.kl_qty_2y_to_3y, 0),
                             nvl(c_end_qty_row.kl_qty_3y_over, 0));

                        else
                          update T_INV_CHECK_INFO_TEMPORYORY
                             set LOGISTICS_QTY   = c_end_qty_row.logistics_qty,
                                 REAL_QTY        = c_end_qty_row.real_qty,
                                 KL_QTY_1M       = c_end_qty_row.kl_qty_1m,
                                 KL_QTY_2M       = c_end_qty_row.kl_qty_2m,
                                 KL_QTY_3M       = c_end_qty_row.kl_qty_3m,
                                 KL_QTY_4M       = c_end_qty_row.kl_qty_4m,
                                 KL_QTY_5M       = c_end_qty_row.kl_qty_5m,
                                 KL_QTY_6M       = c_end_qty_row.kl_qty_6m,
                                 KL_QTY_7M       = c_end_qty_row.kl_qty_7m,
                                 KL_QTY_8M       = c_end_qty_row.kl_qty_8m,
                                 KL_QTY_9M       = c_end_qty_row.kl_qty_9m,
                                 KL_QTY_10M      = c_end_qty_row.kl_qty_10m,
                                 KL_QTY_11M      = c_end_qty_row.kl_qty_11m,
                                 KL_QTY_12M      = c_end_qty_row.kl_qty_12m,
                                 KL_QTY_1Y_TO_2Y = c_end_qty_row.kl_qty_1y_to_2y,
                                 KL_QTY_2Y_TO_3Y = c_end_qty_row.kl_qty_2y_to_3y,
                                 KL_QTY_3Y_OVER  = c_end_qty_row.kl_qty_3y_over
                           where item_code = c_end_qty_row.item_code;

                        end if;
                      end loop;
                      update T_INV_CHECK_INFO_TEMPORYORY ticit set ticit.book_differences_qty=nvl(ticit.book_qty,0)-nvl(ticit.logistics_qty,0);
                      update T_INV_CHECK_INFO_TEMPORYORY ticit set ticit.book_real_differences_qty=nvl(ticit.book_qty,0)-nvl(ticit.real_qty,0);
                      update  T_INV_CHECK_INFO_TEMPORYORY ticit set ticit.book_qty=nvl(ticit.book_qty,0),
                                                              ticit.logistics_qty=nvl(ticit.logistics_qty,0),
                                                              ticit.real_qty=nvl(ticit.real_qty,0),
                                                              ticit.kl_qty_1m=nvl(ticit.kl_qty_1m,0),
                                                              ticit.kl_qty_2m=nvl(ticit.kl_qty_2m,0),
                                                              ticit.kl_qty_3m=nvl(ticit.kl_qty_3m,0),
                                                              ticit.kl_qty_4m=nvl(ticit.kl_qty_4m,0),
                                                              ticit.kl_qty_5m=nvl(ticit.kl_qty_5m,0),
                                                              ticit.kl_qty_6m=nvl(ticit.kl_qty_6m,0),
                                                              ticit.kl_qty_7m=nvl(ticit.kl_qty_7m,0),
                                                              ticit.kl_qty_8m=nvl(ticit.kl_qty_8m,0),
                                                              ticit.kl_qty_9m=nvl(ticit.kl_qty_9m,0),
                                                              ticit.kl_qty_10m=nvl(ticit.kl_qty_10m,0),
                                                              ticit.kl_qty_11m=nvl(ticit.kl_qty_11m,0),
                                                              ticit.kl_qty_12m=nvl(ticit.kl_qty_12m,0),
                                                              ticit.kl_qty_1y_to_2y=nvl(ticit.kl_qty_1y_to_2y,0),
                                                              ticit.kl_qty_2y_to_3y=nvl(ticit.kl_qty_2y_to_3y,0),
                                                              ticit.kl_qty_3y_over=nvl(ticit.kl_qty_3y_over,0),
                                                              ticit.book_differences_qty=nvl(ticit.book_differences_qty,0),
                                                              ticit.book_real_differences_qty=nvl(ticit.book_real_differences_qty,0);
                    else

                      begin
                        insert into T_INV_CHECK_INFO_LINETEMP
                        (CHECK_INFO_LINE_ID,
                         ITEM_CODE,
                         ITEM_DESC,
                         UOM,
                         LOGISTICS_QTY,
                         REAL_QTY,
                         KL_QTY_1M,
                         KL_QTY_2M,
                         KL_QTY_3M,
                         KL_QTY_4M,
                         KL_QTY_5M,
                         KL_QTY_6M,
                         KL_QTY_7M,
                         KL_QTY_8M,
                         KL_QTY_9M,
                         KL_QTY_10M,
                         KL_QTY_11M,
                         KL_QTY_12M,
                         KL_QTY_1Y_TO_2Y,
                         KL_QTY_2Y_TO_3Y,
                         KL_QTY_3Y_OVER,
                         CREATED_BY,
                         CREATION_DATE)
                         select S_T_INV_CHECK_INFOLINESTEMP.NEXTVAL,
                                b1.item_code,
                                b1.item_name,
                                b1.defaultunit,
                                b1.sum_qty,
                                b1.real_qty,
                                b1.month_01,
                                b1.month_02,
                                b1.month_03,
                                b1.month_04,
                                b1.month_05,
                                b1.month_06,
                                b1.month_07,
                                b1.month_08,
                                b1. month_09,
                                b1.month_10,
                                b1.month_11,
                                b1.month_12,
                                b1.month_13,
                                b1.month_14,
                                b1.month_15,
                                p_user_code,
                                sysdate

                          from (select a1.item_code,tbi.item_name,tbi.defaultunit,

                       sum(nvl(month_01, 0) + nvl(month_02, 0) + nvl(month_03, 0) +
                           nvl(month_04, 0) + nvl(month_07, 0) + nvl(month_05, 0) +
                           nvl(month_06, 0) + nvl(month_08, 0) + nvl(month_09, 0) +
                           nvl(month_10, 0) + nvl(month_11, 0) + nvl(month_12, 0) +
                           nvl(month_13, 0) + nvl(month_14, 0) + nvl(month_15, 0)) sum_qty,
                       sum(nvl(month_01, 0) + nvl(month_02, 0) + nvl(month_03, 0) +
                           nvl(month_04, 0) + nvl(month_07, 0) + nvl(month_05, 0) +
                           nvl(month_06, 0) + nvl(month_08, 0) + nvl(month_09, 0) +
                           nvl(month_10, 0) + nvl(month_11, 0) + nvl(month_12, 0) +
                           nvl(month_13, 0) + nvl(month_14, 0) + nvl(month_15, 0)) real_qty,
                       sum(month_01) month_01,
                       sum(month_02) month_02,
                       sum(month_03) month_03,
                       sum(month_04) month_04,
                       sum(month_05) month_05,
                       sum(month_06) month_06,
                       sum(month_07) month_07,
                       sum(month_08) month_08,
                       sum(month_09) month_09,
                       sum(month_10) month_10,
                       sum(month_11) month_11,
                       sum(month_12) month_12,
                       sum(month_13) month_13,
                       sum(month_14) month_14,
                       sum(month_15) month_15
                  from (select ceil(months_between(trunc(info_date),
                                                   to_date('20' || t.item_batch, 'yyyy-mm'))),
                               t.item_code,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      1,
                                      t.real_qty,
                                      null) month_01,

                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      2,
                                      t.real_qty,
                                      null) month_02,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      3,
                                      t.real_qty,
                                      null) month_03,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      4,
                                      t.real_qty,
                                      null) month_04,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      5,
                                      t.real_qty,
                                      null) month_05,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      6,
                                      t.real_qty,
                                      null) month_06,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      7,
                                      t.real_qty,
                                      null) month_07,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      8,
                                      t.real_qty,
                                      null) month_08,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      9,
                                      t.real_qty,
                                      null) month_09,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      10,
                                      t.real_qty,
                                      null) month_10,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      11,
                                      t.real_qty,
                                      null) month_11,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      12,
                                      t.real_qty,
                                      null) month_12,
                               case
                                 when ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))) > 12 and
                                      ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))) <= 24 then
                                  t.real_qty
                                 else
                                  null
                               end month_13,
                               case
                                 when ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))) > 24 and
                                      ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))) <= 36 then
                                  t.real_qty
                                 else
                                  null
                               end month_14,
                               case
                                 when ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))) > 36 then
                                  t.real_qty
                                 else
                                  null
                               end month_15
                          from A3_INV_STOCK t where
                           t.finance_entity_id=to_char(p_entity_id)
                          and t.sub_inv_code = inv_code
                           ) a1 ,t_bd_item tbi where a1.item_code=tbi.item_code and tbi.entity_id = p_entity_id group by a1.item_code,tbi.item_name,tbi.defaultunit) b1;
                      exception
                      when others then
                         rollback;
                         v_exception :='取A3实时数据后，插入T_INV_CHECK_INFO_LINETEMP有误!'||sqlerrm;
                         return;
                      end;

                      begin
                        select count(1) into v_is_data from T_INV_CHECK_INFO_LINETEMP where CREATED_BY = p_user_code;
                         if v_is_data=0 then
                           rollback;
                           v_exception :='根据录入的盘存日期和财务仓，在A3提供的数据中找不到对应的产品!';
                           return;
                         end if;
                      end;



                      for c_end_qty_row in c_end_qty loop
                        update T_INV_CHECK_INFO_TEMPORYORY
                           set item_code = c_end_qty_row.item_code
                         where item_code = c_end_qty_row.item_code;

                        if sql%notfound then
                          insert into T_INV_CHECK_INFO_TEMPORYORY
                            (CHECK_INFO_LINE_ID,
                             ITEM_CODE,
                             ITEM_DESC,
                             UOM,
                             LOGISTICS_QTY,
                             REAL_QTY,
                             KL_QTY_1M,
                             KL_QTY_2M,
                             KL_QTY_3M,
                             KL_QTY_4M,
                             KL_QTY_5M,
                             KL_QTY_6M,
                             KL_QTY_7M,
                             KL_QTY_8M,
                             KL_QTY_9M,
                             KL_QTY_10M,
                             KL_QTY_11M,
                             KL_QTY_12M,
                             KL_QTY_1Y_TO_2Y,
                             KL_QTY_2Y_TO_3Y,
                             KL_QTY_3Y_OVER)
                          values

                            (s_t_inv_check_info_temporary.nextval,
                             nvl(c_end_qty_row.item_code, 0),
                             nvl(c_end_qty_row.Item_Desc, 0),
                             nvl(c_end_qty_row.Uom, 0),
                             nvl(c_end_qty_row.Logistics_Qty, 0),
                             nvl(c_end_qty_row.real_qty, 0),
                             nvl(c_end_qty_row.kl_qty_1m, 0),
                             nvl(c_end_qty_row.kl_qty_2m, 0),
                             nvl(c_end_qty_row.kl_qty_3m, 0),
                             nvl(c_end_qty_row.kl_qty_4m, 0),
                             nvl(c_end_qty_row.kl_qty_5m, 0),
                             nvl(c_end_qty_row.kl_qty_6m, 0),
                             nvl(c_end_qty_row.kl_qty_7m, 0),
                             nvl(c_end_qty_row.kl_qty_8m, 0),
                             nvl(c_end_qty_row.kl_qty_9m, 0),
                             nvl(c_end_qty_row.kl_qty_10m, 0),
                             nvl(c_end_qty_row.kl_qty_11m, 0),
                             nvl(c_end_qty_row.kl_qty_12m, 0),
                             nvl(c_end_qty_row.kl_qty_1y_to_2y, 0),
                             nvl(c_end_qty_row.kl_qty_2y_to_3y, 0),
                             nvl(c_end_qty_row.kl_qty_3y_over, 0));

                        else
                          update T_INV_CHECK_INFO_TEMPORYORY
                             set
                                 LOGISTICS_QTY   = c_end_qty_row.Logistics_Qty,
                                 REAL_QTY        = c_end_qty_row.real_qty,
                                 KL_QTY_1M       = c_end_qty_row.kl_qty_1m,
                                 KL_QTY_2M       = c_end_qty_row.kl_qty_2m,
                                 KL_QTY_3M       = c_end_qty_row.kl_qty_3m,
                                 KL_QTY_4M       = c_end_qty_row.kl_qty_4m,
                                 KL_QTY_5M       = c_end_qty_row.kl_qty_5m,
                                 KL_QTY_6M       = c_end_qty_row.kl_qty_6m,
                                 KL_QTY_7M       = c_end_qty_row.kl_qty_7m,
                                 KL_QTY_8M       = c_end_qty_row.kl_qty_8m,
                                 KL_QTY_9M       = c_end_qty_row.kl_qty_9m,
                                 KL_QTY_10M      = c_end_qty_row.kl_qty_10m,
                                 KL_QTY_11M      = c_end_qty_row.kl_qty_11m,
                                 KL_QTY_12M      = c_end_qty_row.kl_qty_12m,
                                 KL_QTY_1Y_TO_2Y = c_end_qty_row.kl_qty_1y_to_2y,
                                 KL_QTY_2Y_TO_3Y = c_end_qty_row.kl_qty_2y_to_3y,
                                 KL_QTY_3Y_OVER  = c_end_qty_row.kl_qty_3y_over

                           where item_code = c_end_qty_row.item_code;

                        end if;

                      end loop;

                      update T_INV_CHECK_INFO_TEMPORYORY ticit set ticit.book_differences_qty=nvl(ticit.book_qty,0)-nvl(ticit.logistics_qty,0);
                      update T_INV_CHECK_INFO_TEMPORYORY ticit set ticit.book_real_differences_qty=nvl(ticit.book_qty,0)-nvl(ticit.real_qty,0);
                      update  T_INV_CHECK_INFO_TEMPORYORY ticit set ticit.book_qty=nvl(ticit.book_qty,0),
                                                              ticit.logistics_qty=nvl(ticit.logistics_qty,0),
                                                              ticit.real_qty=nvl(ticit.real_qty,0),
                                                              ticit.kl_qty_1m=nvl(ticit.kl_qty_1m,0),
                                                              ticit.kl_qty_2m=nvl(ticit.kl_qty_2m,0),
                                                              ticit.kl_qty_3m=nvl(ticit.kl_qty_3m,0),
                                                              ticit.kl_qty_4m=nvl(ticit.kl_qty_4m,0),
                                                              ticit.kl_qty_5m=nvl(ticit.kl_qty_5m,0),
                                                              ticit.kl_qty_6m=nvl(ticit.kl_qty_6m,0),
                                                              ticit.kl_qty_7m=nvl(ticit.kl_qty_7m,0),
                                                              ticit.kl_qty_8m=nvl(ticit.kl_qty_8m,0),
                                                              ticit.kl_qty_9m=nvl(ticit.kl_qty_9m,0),
                                                              ticit.kl_qty_10m=nvl(ticit.kl_qty_10m,0),
                                                              ticit.kl_qty_11m=nvl(ticit.kl_qty_11m,0),
                                                              ticit.kl_qty_12m=nvl(ticit.kl_qty_12m,0),
                                                              ticit.kl_qty_1y_to_2y=nvl(ticit.kl_qty_1y_to_2y,0),
                                                              ticit.kl_qty_2y_to_3y=nvl(ticit.kl_qty_2y_to_3y,0),
                                                              ticit.kl_qty_3y_over=nvl(ticit.kl_qty_3y_over,0),
                                                              ticit.book_differences_qty=nvl(ticit.book_differences_qty,0),
                                                              ticit.book_real_differences_qty=nvl(ticit.book_real_differences_qty,0);

                    end if;

                        v_exception :='seuccess';
               --zhangwm 增加删除临时行数据信息。2015-12-31
               delete T_INV_CHECK_INFO_LINETEMP where CREATED_BY = p_user_code;
         else
         --  delete T_INV_CHECK_INFO_LINETEMP where 1 = 1;
                    select info_date - trunc(sysdate) into n_info_date from dual;
                    if n_info_date < 0 then

                  begin
                      SELECT PERIOD_ID, END_DATE + 1 BEGIN_DATE into v_period_id,v_begin_date
                        FROM CIMS.T_INV_INVENTORY_PERIODS ip
                       WHERE ip.ENTITY_ID = p_entity_id
                         AND BEGIN_DATE =
                             (SELECT MAX(P.BEGIN_DATE) BEGIN_DATE
                                FROM CIMS.T_INV_INVENTORY_PERIODS P, CIMS.T_SL_SFC_FREEZE F
                               WHERE P.PERIOD_ID = F.PERIOD_ID AND P.ENTITY_ID = p_entity_id
                                 AND P.END_DATE < info_date);
                     insert into T_INV_CHECK_INFO_LINETEMP
                        (CHECK_INFO_LINE_ID,
                         ITEM_CODE,
                         ITEM_DESC,
                         UOM,
                         LOGISTICS_QTY,
                         REAL_QTY,
                         KL_QTY_1M,
                         KL_QTY_2M,
                         KL_QTY_3M,
                         KL_QTY_4M,
                         KL_QTY_5M,
                         KL_QTY_6M,
                         KL_QTY_7M,
                         KL_QTY_8M,
                         KL_QTY_9M,
                         KL_QTY_10M,
                         KL_QTY_11M,
                         KL_QTY_12M,
                         KL_QTY_1Y_TO_2Y,
                         KL_QTY_2Y_TO_3Y,
                         KL_QTY_3Y_OVER,
                         CREATED_BY,
                         CREATION_DATE )
                         select S_T_INV_CHECK_INFOLINESTEMP.NEXTVAL,
                                b1.item_code,
                                b1.item_name,
                                b1.defaultunit,
                                b1.sum_qty,
                                b1.real_qty,
                                b1.month_01,
                                b1.month_02,
                                b1.month_03,
                                b1.month_04,
                                b1.month_05,
                                b1.month_06,
                                b1.month_07,
                                b1.month_08,
                                b1. month_09,
                                b1.month_10,
                                b1.month_11,
                                b1.month_12,
                                b1.month_13,
                                b1.month_14,
                                b1.month_15,
                                p_user_code,
                                sysdate

                          from (select a1.item_code,tbi.item_name,tbi.defaultunit,

                       sum(nvl(month_01, 0) + nvl(month_02, 0) + nvl(month_03, 0) +
                           nvl(month_04, 0) + nvl(month_07, 0) + nvl(month_05, 0) +
                           nvl(month_06, 0) + nvl(month_08, 0) + nvl(month_09, 0) +
                           nvl(month_10, 0) + nvl(month_11, 0) + nvl(month_12, 0) +
                           nvl(month_13, 0) + nvl(month_14, 0) + nvl(month_15, 0)) sum_qty,
                       sum(nvl(month_01, 0) + nvl(month_02, 0) + nvl(month_03, 0) +
                           nvl(month_04, 0) + nvl(month_07, 0) + nvl(month_05, 0) +
                           nvl(month_06, 0) + nvl(month_08, 0) + nvl(month_09, 0) +
                           nvl(month_10, 0) + nvl(month_11, 0) + nvl(month_12, 0) +
                           nvl(month_13, 0) + nvl(month_14, 0) + nvl(month_15, 0)) real_qty,
                       sum(month_01) month_01,
                       sum(month_02) month_02,
                       sum(month_03) month_03,
                       sum(month_04) month_04,
                       sum(month_05) month_05,
                       sum(month_06) month_06,
                       sum(month_07) month_07,
                       sum(month_08) month_08,
                       sum(month_09) month_09,
                       sum(month_10) month_10,
                       sum(month_11) month_11,
                       sum(month_12) month_12,
                       sum(month_13) month_13,
                       sum(month_14) month_14,
                       sum(month_15) month_15
                  from (select ceil(months_between(trunc(info_date),
                                                   to_date('20' || t.item_batch, 'yyyy-mm'))),
                               t.item_code,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      1,
                                      t.real_qty,
                                      null) month_01,

                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      2,
                                      t.real_qty,
                                      null) month_02,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      3,
                                      t.real_qty,
                                      null) month_03,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      4,
                                      t.real_qty,
                                      null) month_04,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      5,
                                      t.real_qty,
                                      null) month_05,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      6,
                                      t.real_qty,
                                      null) month_06,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      7,
                                      t.real_qty,
                                      null) month_07,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      8,
                                      t.real_qty,
                                      null) month_08,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      9,
                                      t.real_qty,
                                      null) month_09,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      10,
                                      t.real_qty,
                                      null) month_10,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      11,
                                      t.real_qty,
                                      null) month_11,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      12,
                                      t.real_qty,
                                      null) month_12,
                               case
                                 when ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))) > 12 and
                                      ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))) <= 24 then
                                  t.real_qty
                                 else
                                  null
                               end month_13,
                               case
                                 when ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))) > 24 and
                                      ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))) <= 36 then
                                  t.real_qty
                                 else
                                  null
                               end month_14,
                               case
                                 when ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))) > 36 then
                                  t.real_qty
                                 else
                                  null
                               end month_15
                          from (SELECT
                                    II.INVENTORY_CODE sub_inv_code
                                    ,BI.ITEM_CODE
                                    ,O.ITEM_BATCH
                                    ,SUM(O.QUANTITY) real_qty
                                  FROM
                                    (
                                      SELECT
                                        INVENTORY_ID
                                        ,ITEM_ID
                                        ,ITEM_BATCH
                                        ,SUM(END_QTY) QUANTITY
                                      FROM
                                        CIMS.T_SL_SFC_FREEZE F
                                      WHERE
                                        F.PERIOD_ID = v_period_id
                                        AND F.STORE_TYPE = 'F'
                                      GROUP BY
                                        INVENTORY_ID
                                        ,ITEM_ID
                                        ,ITEM_BATCH
                                      UNION ALL
                                      SELECT
                                        BH.INVENTORY_ID
                                        ,BL.ITEM_ID
                                        ,DECODE(BH.SEND_INV_ID,NULL,BL.REV_ITEM_BATCH,BL.SEND_ITEM_BATCH) ITEM_BATCH
                                        ,SUM(BL.QUANTITY*DECODE(BH.SEND_INV_ID,NULL,BH.REV_INV_SIGN,BH.SEND_INV_SIGN)) QUANTITY
                                      FROM
                                        CIMS.T_SL_BILL_HEADER BH
                                        ,CIMS.T_SL_BILL_LINE BL
                                      WHERE
                                        BH.BILL_HEADER_ID = BL.BILL_HEADER_ID
                                        AND BH.BUSINESS_TYPE <> '33'
                                        AND BH.AFFIRM_DATE BETWEEN v_begin_date AND info_date
                                      GROUP BY
                                        BH.INVENTORY_ID
                                        ,BL.ITEM_ID
                                        ,DECODE(BH.SEND_INV_ID,NULL,BL.REV_ITEM_BATCH,BL.SEND_ITEM_BATCH)
                                    ) O
                                    ,T_INV_INVENTORIES II
                                    ,T_BD_ITEM BI
                                  WHERE
                                    O.INVENTORY_ID = II.INVENTORY_ID
                                    AND O.ITEM_ID = BI.ITEM_ID
                                  GROUP BY
                                    II.INVENTORY_CODE
                                    ,BI.ITEM_CODE
                                    ,O.ITEM_BATCH) t where
                                                        t.sub_inv_code = inv_code

                           ) a1 ,t_bd_item tbi where a1.item_code=tbi.item_code and tbi.entity_id = p_entity_id group by a1.item_code,tbi.item_name,tbi.defaultunit) b1;

                    exception
                      when others then
                         rollback;
                         v_exception :='结存日期为：'||info_date||'，取库位结存数量有误!'||sqlerrm;
                         return;
                    end;

                    begin
                      select count(1) into v_is_data from T_INV_CHECK_INFO_LINETEMP where CREATED_BY = p_user_code;
                      if v_is_data=0 then
                         rollback;
                          v_exception :='根据录入的盘存日期和财务仓，在库位模块提供的数据中找不到对应的产品!';
                          return;
                      end if;
                    end;

                      for c_end_qty_row in c_end_qty loop


                        update T_INV_CHECK_INFO_TEMPORYORY
                           set item_code = c_end_qty_row.item_code,
                               item_desc = c_end_qty_row.item_desc,
                               uom       = c_end_qty_row.uom
                         where item_code = c_end_qty_row.item_code;

                        if sql%notfound then
                          insert into T_INV_CHECK_INFO_TEMPORYORY
                            (CHECK_INFO_LINE_ID,
                             ITEM_CODE,
                             ITEM_DESC,
                             UOM,
                             LOGISTICS_QTY,
                             REAL_QTY,
                             KL_QTY_1M,
                             KL_QTY_2M,
                             KL_QTY_3M,
                             KL_QTY_4M,
                             KL_QTY_5M,
                             KL_QTY_6M,
                             KL_QTY_7M,
                             KL_QTY_8M,
                             KL_QTY_9M,
                             KL_QTY_10M,
                             KL_QTY_11M,
                             KL_QTY_12M,
                             KL_QTY_1Y_TO_2Y,
                             KL_QTY_2Y_TO_3Y,
                             KL_QTY_3Y_OVER)
                          values

                            (s_t_inv_check_info_temporary.nextval,
                             nvl(c_end_qty_row.item_code, 0),
                             nvl(c_end_qty_row.item_desc, 0),
                             nvl(c_end_qty_row.uom, 0),
                             nvl(c_end_qty_row.logistics_qty, 0),
                             nvl(c_end_qty_row.real_qty, 0),
                             nvl(c_end_qty_row.kl_qty_1m, 0),
                             nvl(c_end_qty_row.kl_qty_2m, 0),
                             nvl(c_end_qty_row.kl_qty_3m, 0),
                             nvl(c_end_qty_row.kl_qty_4m, 0),
                             nvl(c_end_qty_row.kl_qty_5m, 0),
                             nvl(c_end_qty_row.kl_qty_6m, 0),
                             nvl(c_end_qty_row.kl_qty_7m, 0),
                             nvl(c_end_qty_row.kl_qty_8m, 0),
                             nvl(c_end_qty_row.kl_qty_9m, 0),
                             nvl(c_end_qty_row.kl_qty_10m, 0),
                             nvl(c_end_qty_row.kl_qty_11m, 0),
                             nvl(c_end_qty_row.kl_qty_12m, 0),
                             nvl(c_end_qty_row.kl_qty_1y_to_2y, 0),
                             nvl(c_end_qty_row.kl_qty_2y_to_3y, 0),
                             nvl(c_end_qty_row.kl_qty_3y_over, 0));

                        else
                          update T_INV_CHECK_INFO_TEMPORYORY
                             set LOGISTICS_QTY   = c_end_qty_row.logistics_qty,
                                 REAL_QTY        = c_end_qty_row.real_qty,
                                 KL_QTY_1M       = c_end_qty_row.kl_qty_1m,
                                 KL_QTY_2M       = c_end_qty_row.kl_qty_2m,
                                 KL_QTY_3M       = c_end_qty_row.kl_qty_3m,
                                 KL_QTY_4M       = c_end_qty_row.kl_qty_4m,
                                 KL_QTY_5M       = c_end_qty_row.kl_qty_5m,
                                 KL_QTY_6M       = c_end_qty_row.kl_qty_6m,
                                 KL_QTY_7M       = c_end_qty_row.kl_qty_7m,
                                 KL_QTY_8M       = c_end_qty_row.kl_qty_8m,
                                 KL_QTY_9M       = c_end_qty_row.kl_qty_9m,
                                 KL_QTY_10M      = c_end_qty_row.kl_qty_10m,
                                 KL_QTY_11M      = c_end_qty_row.kl_qty_11m,
                                 KL_QTY_12M      = c_end_qty_row.kl_qty_12m,
                                 KL_QTY_1Y_TO_2Y = c_end_qty_row.kl_qty_1y_to_2y,
                                 KL_QTY_2Y_TO_3Y = c_end_qty_row.kl_qty_2y_to_3y,
                                 KL_QTY_3Y_OVER  = c_end_qty_row.kl_qty_3y_over
                           where item_code = c_end_qty_row.item_code;

                        end if;
                      end loop;
                      update T_INV_CHECK_INFO_TEMPORYORY ticit set ticit.book_differences_qty=nvl(ticit.book_qty,0)-nvl(ticit.logistics_qty,0);
                      update T_INV_CHECK_INFO_TEMPORYORY ticit set ticit.book_real_differences_qty=nvl(ticit.book_qty,0)-nvl(ticit.real_qty,0);
                      update  T_INV_CHECK_INFO_TEMPORYORY ticit set ticit.book_qty=nvl(ticit.book_qty,0),
                                                              ticit.logistics_qty=nvl(ticit.logistics_qty,0),
                                                              ticit.real_qty=nvl(ticit.real_qty,0),
                                                              ticit.kl_qty_1m=nvl(ticit.kl_qty_1m,0),
                                                              ticit.kl_qty_2m=nvl(ticit.kl_qty_2m,0),
                                                              ticit.kl_qty_3m=nvl(ticit.kl_qty_3m,0),
                                                              ticit.kl_qty_4m=nvl(ticit.kl_qty_4m,0),
                                                              ticit.kl_qty_5m=nvl(ticit.kl_qty_5m,0),
                                                              ticit.kl_qty_6m=nvl(ticit.kl_qty_6m,0),
                                                              ticit.kl_qty_7m=nvl(ticit.kl_qty_7m,0),
                                                              ticit.kl_qty_8m=nvl(ticit.kl_qty_8m,0),
                                                              ticit.kl_qty_9m=nvl(ticit.kl_qty_9m,0),
                                                              ticit.kl_qty_10m=nvl(ticit.kl_qty_10m,0),
                                                              ticit.kl_qty_11m=nvl(ticit.kl_qty_11m,0),
                                                              ticit.kl_qty_12m=nvl(ticit.kl_qty_12m,0),
                                                              ticit.kl_qty_1y_to_2y=nvl(ticit.kl_qty_1y_to_2y,0),
                                                              ticit.kl_qty_2y_to_3y=nvl(ticit.kl_qty_2y_to_3y,0),
                                                              ticit.kl_qty_3y_over=nvl(ticit.kl_qty_3y_over,0),
                                                              ticit.book_differences_qty=nvl(ticit.book_differences_qty,0),
                                                              ticit.book_real_differences_qty=nvl(ticit.book_real_differences_qty,0);
                    else

                      begin
                        insert into T_INV_CHECK_INFO_LINETEMP
                        (CHECK_INFO_LINE_ID,
                         ITEM_CODE,
                         ITEM_DESC,
                         UOM,
                         LOGISTICS_QTY,
                         REAL_QTY,
                         KL_QTY_1M,
                         KL_QTY_2M,
                         KL_QTY_3M,
                         KL_QTY_4M,
                         KL_QTY_5M,
                         KL_QTY_6M,
                         KL_QTY_7M,
                         KL_QTY_8M,
                         KL_QTY_9M,
                         KL_QTY_10M,
                         KL_QTY_11M,
                         KL_QTY_12M,
                         KL_QTY_1Y_TO_2Y,
                         KL_QTY_2Y_TO_3Y,
                         KL_QTY_3Y_OVER,
                         CREATED_BY,
                         CREATION_DATE
                         )
                         select S_T_INV_CHECK_INFOLINESTEMP.NEXTVAL,
                                b1.item_code,
                                b1.item_name,
                                b1.defaultunit,
                                b1.sum_qty,
                                b1.real_qty,
                                b1.month_01,
                                b1.month_02,
                                b1.month_03,
                                b1.month_04,
                                b1.month_05,
                                b1.month_06,
                                b1.month_07,
                                b1.month_08,
                                b1. month_09,
                                b1.month_10,
                                b1.month_11,
                                b1.month_12,
                                b1.month_13,
                                b1.month_14,
                                b1.month_15,
                                p_user_code,
                                sysdate

                          from (select a1.item_code,tbi.item_name,tbi.defaultunit,

                       sum(nvl(month_01, 0) + nvl(month_02, 0) + nvl(month_03, 0) +
                           nvl(month_04, 0) + nvl(month_07, 0) + nvl(month_05, 0) +
                           nvl(month_06, 0) + nvl(month_08, 0) + nvl(month_09, 0) +
                           nvl(month_10, 0) + nvl(month_11, 0) + nvl(month_12, 0) +
                           nvl(month_13, 0) + nvl(month_14, 0) + nvl(month_15, 0)) sum_qty,
                       sum(nvl(month_01, 0) + nvl(month_02, 0) + nvl(month_03, 0) +
                           nvl(month_04, 0) + nvl(month_07, 0) + nvl(month_05, 0) +
                           nvl(month_06, 0) + nvl(month_08, 0) + nvl(month_09, 0) +
                           nvl(month_10, 0) + nvl(month_11, 0) + nvl(month_12, 0) +
                           nvl(month_13, 0) + nvl(month_14, 0) + nvl(month_15, 0)) real_qty,
                       sum(month_01) month_01,
                       sum(month_02) month_02,
                       sum(month_03) month_03,
                       sum(month_04) month_04,
                       sum(month_05) month_05,
                       sum(month_06) month_06,
                       sum(month_07) month_07,
                       sum(month_08) month_08,
                       sum(month_09) month_09,
                       sum(month_10) month_10,
                       sum(month_11) month_11,
                       sum(month_12) month_12,
                       sum(month_13) month_13,
                       sum(month_14) month_14,
                       sum(month_15) month_15
                  from (select ceil(months_between(trunc(info_date),
                                                   to_date('20' || t.item_batch, 'yyyy-mm'))),
                               t.item_code,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      1,
                                      t.real_qty,
                                      null) month_01,

                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      2,
                                      t.real_qty,
                                      null) month_02,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      3,
                                      t.real_qty,
                                      null) month_03,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      4,
                                      t.real_qty,
                                      null) month_04,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      5,
                                      t.real_qty,
                                      null) month_05,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      6,
                                      t.real_qty,
                                      null) month_06,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      7,
                                      t.real_qty,
                                      null) month_07,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      8,
                                      t.real_qty,
                                      null) month_08,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      9,
                                      t.real_qty,
                                      null) month_09,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      10,
                                      t.real_qty,
                                      null) month_10,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      11,
                                      t.real_qty,
                                      null) month_11,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      12,
                                      t.real_qty,
                                      null) month_12,
                               case
                                 when ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))) > 12 and
                                      ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))) <= 24 then
                                  t.real_qty
                                 else
                                  null
                               end month_13,
                               case
                                 when ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))) > 24 and
                                      ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))) <= 36 then
                                  t.real_qty
                                 else
                                  null
                               end month_14,
                               case
                                 when ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))) > 36 then
                                  t.real_qty
                                 else
                                  null
                               end month_15
                          from V_SL_INV_SL_ONHAND t where
                          t.sub_inv_code = inv_code
                          and t.ENTITY_ID=p_entity_id
                           ) a1 ,t_bd_item tbi where a1.item_code=tbi.item_code and tbi.entity_id = p_entity_id  group by a1.item_code,tbi.item_name,tbi.defaultunit) b1;
                      exception
                      when others then
                         rollback;
                         v_exception :='取库位实时数据后，插入T_INV_CHECK_INFO_LINETEMP有误!'||sqlerrm;
                         return;
                      end;

                      begin
                        select count(1) into v_is_data from T_INV_CHECK_INFO_LINETEMP where  CREATED_BY = p_user_code;
                         if v_is_data=0 then
                           rollback;
                           v_exception :='根据录入的盘存日期和财务仓，在库位模块提供的数据中找不到对应的产品!';
                           return;
                         end if;
                      end;



                      for c_end_qty_row in c_end_qty loop
                        update T_INV_CHECK_INFO_TEMPORYORY
                           set item_code = c_end_qty_row.item_code
                         where item_code = c_end_qty_row.item_code;

                        if sql%notfound then
                          insert into T_INV_CHECK_INFO_TEMPORYORY
                            (CHECK_INFO_LINE_ID,
                             ITEM_CODE,
                             ITEM_DESC,
                             UOM,
                             LOGISTICS_QTY,
                             REAL_QTY,
                             KL_QTY_1M,
                             KL_QTY_2M,
                             KL_QTY_3M,
                             KL_QTY_4M,
                             KL_QTY_5M,
                             KL_QTY_6M,
                             KL_QTY_7M,
                             KL_QTY_8M,
                             KL_QTY_9M,
                             KL_QTY_10M,
                             KL_QTY_11M,
                             KL_QTY_12M,
                             KL_QTY_1Y_TO_2Y,
                             KL_QTY_2Y_TO_3Y,
                             KL_QTY_3Y_OVER)
                          values

                            (s_t_inv_check_info_temporary.nextval,
                             nvl(c_end_qty_row.item_code, 0),
                             nvl(c_end_qty_row.Item_Desc, 0),
                             nvl(c_end_qty_row.Uom, 0),
                             nvl(c_end_qty_row.Logistics_Qty, 0),
                             nvl(c_end_qty_row.real_qty, 0),
                             nvl(c_end_qty_row.kl_qty_1m, 0),
                             nvl(c_end_qty_row.kl_qty_2m, 0),
                             nvl(c_end_qty_row.kl_qty_3m, 0),
                             nvl(c_end_qty_row.kl_qty_4m, 0),
                             nvl(c_end_qty_row.kl_qty_5m, 0),
                             nvl(c_end_qty_row.kl_qty_6m, 0),
                             nvl(c_end_qty_row.kl_qty_7m, 0),
                             nvl(c_end_qty_row.kl_qty_8m, 0),
                             nvl(c_end_qty_row.kl_qty_9m, 0),
                             nvl(c_end_qty_row.kl_qty_10m, 0),
                             nvl(c_end_qty_row.kl_qty_11m, 0),
                             nvl(c_end_qty_row.kl_qty_12m, 0),
                             nvl(c_end_qty_row.kl_qty_1y_to_2y, 0),
                             nvl(c_end_qty_row.kl_qty_2y_to_3y, 0),
                             nvl(c_end_qty_row.kl_qty_3y_over, 0));

                        else
                          update T_INV_CHECK_INFO_TEMPORYORY
                             set
                                 LOGISTICS_QTY   = c_end_qty_row.Logistics_Qty,
                                 REAL_QTY        = c_end_qty_row.real_qty,
                                 KL_QTY_1M       = c_end_qty_row.kl_qty_1m,
                                 KL_QTY_2M       = c_end_qty_row.kl_qty_2m,
                                 KL_QTY_3M       = c_end_qty_row.kl_qty_3m,
                                 KL_QTY_4M       = c_end_qty_row.kl_qty_4m,
                                 KL_QTY_5M       = c_end_qty_row.kl_qty_5m,
                                 KL_QTY_6M       = c_end_qty_row.kl_qty_6m,
                                 KL_QTY_7M       = c_end_qty_row.kl_qty_7m,
                                 KL_QTY_8M       = c_end_qty_row.kl_qty_8m,
                                 KL_QTY_9M       = c_end_qty_row.kl_qty_9m,
                                 KL_QTY_10M      = c_end_qty_row.kl_qty_10m,
                                 KL_QTY_11M      = c_end_qty_row.kl_qty_11m,
                                 KL_QTY_12M      = c_end_qty_row.kl_qty_12m,
                                 KL_QTY_1Y_TO_2Y = c_end_qty_row.kl_qty_1y_to_2y,
                                 KL_QTY_2Y_TO_3Y = c_end_qty_row.kl_qty_2y_to_3y,
                                 KL_QTY_3Y_OVER  = c_end_qty_row.kl_qty_3y_over

                           where item_code = c_end_qty_row.item_code;

                        end if;

                      end loop;

                      update T_INV_CHECK_INFO_TEMPORYORY ticit set ticit.book_differences_qty=nvl(ticit.book_qty,0)-nvl(ticit.logistics_qty,0);
                      update T_INV_CHECK_INFO_TEMPORYORY ticit set ticit.book_real_differences_qty=nvl(ticit.book_qty,0)-nvl(ticit.real_qty,0);
                      update  T_INV_CHECK_INFO_TEMPORYORY ticit set ticit.book_qty=nvl(ticit.book_qty,0),
                                                              ticit.logistics_qty=nvl(ticit.logistics_qty,0),
                                                              ticit.real_qty=nvl(ticit.real_qty,0),
                                                              ticit.kl_qty_1m=nvl(ticit.kl_qty_1m,0),
                                                              ticit.kl_qty_2m=nvl(ticit.kl_qty_2m,0),
                                                              ticit.kl_qty_3m=nvl(ticit.kl_qty_3m,0),
                                                              ticit.kl_qty_4m=nvl(ticit.kl_qty_4m,0),
                                                              ticit.kl_qty_5m=nvl(ticit.kl_qty_5m,0),
                                                              ticit.kl_qty_6m=nvl(ticit.kl_qty_6m,0),
                                                              ticit.kl_qty_7m=nvl(ticit.kl_qty_7m,0),
                                                              ticit.kl_qty_8m=nvl(ticit.kl_qty_8m,0),
                                                              ticit.kl_qty_9m=nvl(ticit.kl_qty_9m,0),
                                                              ticit.kl_qty_10m=nvl(ticit.kl_qty_10m,0),
                                                              ticit.kl_qty_11m=nvl(ticit.kl_qty_11m,0),
                                                              ticit.kl_qty_12m=nvl(ticit.kl_qty_12m,0),
                                                              ticit.kl_qty_1y_to_2y=nvl(ticit.kl_qty_1y_to_2y,0),
                                                              ticit.kl_qty_2y_to_3y=nvl(ticit.kl_qty_2y_to_3y,0),
                                                              ticit.kl_qty_3y_over=nvl(ticit.kl_qty_3y_over,0),
                                                              ticit.book_differences_qty=nvl(ticit.book_differences_qty,0),
                                                              ticit.book_real_differences_qty=nvl(ticit.book_real_differences_qty,0);

                    end if;

                        v_exception :='seuccess';
              --zhangwm 增加删除临时行数据信息。2015-12-31
               delete T_INV_CHECK_INFO_LINETEMP where CREATED_BY = p_user_code;

         end if;
        end;
    Elsif(v_Check_Separate_Or_Combine = 'N') Then
      --判断是否定义统计仓库 by sushu 2017-03-16     
      Select substr(Inv_Code,1,length(Inv_Code)-1) Into v_Statistic_Inventory_Code From dual;
      Begin
        Execute Immediate '         
        Select Count(*)
          From t_Inv_Statistic_Inventories t
         Where t.Statistic_Inventory_Code Like ''' ||
                          v_Statistic_Inventory_Code || '%'' ' ||
                          '  And t.Entity_Id = :1'
          Into v_Is_Data_Statistic_Inventory
          Using p_entity_id;
      Exception
        When Others Then
          Rollback;
          v_Exception := '查询报表统计仓库设置信息失败!';
          Return;
      End;
      if v_is_data_statistic_inventory=0 then
            rollback;
            v_exception :='请先定义该仓库的报表统计仓库设置!';
            return;
      end if;

      v_sql_statistic := 'select * from t_inv_statistic_inventories t where t.Statistic_Inventory_Code Like '''
                         ||v_Statistic_Inventory_Code||'%'' ' 
                         ||'And t.Entity_Id ='|| p_entity_id;
                             
       Begin
          Open v_get_statistic For v_sql_statistic;
       Exception
          When Others Then
            Rollback;
            v_Exception := '取统计仓库信息时，游标出错!' || Sqlerrm;
            Return;
       End;
      
      
      Loop 
        Fetch v_get_statistic Into row_statistic_cur;
        Exit When v_get_statistic%Notfound;
/*        Select *
          Into v_Inv_Inventory
          From t_Inv_Inventories t
         Where t.Inventory_Id = row_statistic_cur.Inventory_Id;*/
        
        
        Begin
      
        select t.docking_system into v_is_a3_cims  from t_inv_inventories t where t.inventory_id = row_statistic_cur.inventory_id;
        if v_is_a3_cims='A3'then
                 --   delete T_INV_CHECK_INFO_LINETEMP where 1 = 1;
                    select info_date - trunc(sysdate) into n_info_date from dual;
                    if n_info_date < 0 then

                  begin
                     insert into T_INV_CHECK_INFO_LINETEMP
                        (CHECK_INFO_LINE_ID,
                         ITEM_CODE,
                         ITEM_DESC,
                         UOM,
                         LOGISTICS_QTY,
                         REAL_QTY,
                         KL_QTY_1M,
                         KL_QTY_2M,
                         KL_QTY_3M,
                         KL_QTY_4M,
                         KL_QTY_5M,
                         KL_QTY_6M,
                         KL_QTY_7M,
                         KL_QTY_8M,
                         KL_QTY_9M,
                         KL_QTY_10M,
                         KL_QTY_11M,
                         KL_QTY_12M,
                         KL_QTY_1Y_TO_2Y,
                         KL_QTY_2Y_TO_3Y,
                         KL_QTY_3Y_OVER,
                         CREATED_BY,
                         CREATION_DATE,
                         inv_id,
                         inv_code,
                         inv_name
                         )
                         select S_T_INV_CHECK_INFOLINESTEMP.NEXTVAL,
                                b1.item_code,
                                b1.item_name,
                                b1.defaultunit,
                                b1.sum_qty,
                                b1.real_qty,
                                b1.month_01,
                                b1.month_02,
                                b1.month_03,
                                b1.month_04,
                                b1.month_05,
                                b1.month_06,
                                b1.month_07,
                                b1.month_08,
                                b1. month_09,
                                b1.month_10,
                                b1.month_11,
                                b1.month_12,
                                b1.month_13,
                                b1.month_14,
                                b1.month_15,
                                p_user_code,
                                sysdate,
                                row_statistic_cur.STATISTIC_INVENTORY_ID,
                                row_statistic_cur.STATISTIC_INVENTORY_Code,
                                row_statistic_cur.STATISTIC_INVENTORY_Name

                          from (select a1.item_code,tbi.item_name,tbi.defaultunit,

                       sum(nvl(month_01, 0) + nvl(month_02, 0) + nvl(month_03, 0) +
                           nvl(month_04, 0) + nvl(month_07, 0) + nvl(month_05, 0) +
                           nvl(month_06, 0) + nvl(month_08, 0) + nvl(month_09, 0) +
                           nvl(month_10, 0) + nvl(month_11, 0) + nvl(month_12, 0) +
                           nvl(month_13, 0) + nvl(month_14, 0) + nvl(month_15, 0)) sum_qty,
                       sum(nvl(month_01, 0) + nvl(month_02, 0) + nvl(month_03, 0) +
                           nvl(month_04, 0) + nvl(month_07, 0) + nvl(month_05, 0) +
                           nvl(month_06, 0) + nvl(month_08, 0) + nvl(month_09, 0) +
                           nvl(month_10, 0) + nvl(month_11, 0) + nvl(month_12, 0) +
                           nvl(month_13, 0) + nvl(month_14, 0) + nvl(month_15, 0)) real_qty,
                       sum(month_01) month_01,
                       sum(month_02) month_02,
                       sum(month_03) month_03,
                       sum(month_04) month_04,
                       sum(month_05) month_05,
                       sum(month_06) month_06,
                       sum(month_07) month_07,
                       sum(month_08) month_08,
                       sum(month_09) month_09,
                       sum(month_10) month_10,
                       sum(month_11) month_11,
                       sum(month_12) month_12,
                       sum(month_13) month_13,
                       sum(month_14) month_14,
                       sum(month_15) month_15
                  from (select ceil(months_between(trunc(info_date),
                                                   to_date('20' || t.item_batch, 'yyyy-mm'))),
                               t.item_code,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      1,
                                      t.real_qty,
                                      null) month_01,

                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      2,
                                      t.real_qty,
                                      null) month_02,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      3,
                                      t.real_qty,
                                      null) month_03,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      4,
                                      t.real_qty,
                                      null) month_04,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      5,
                                      t.real_qty,
                                      null) month_05,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      6,
                                      t.real_qty,
                                      null) month_06,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      7,
                                      t.real_qty,
                                      null) month_07,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      8,
                                      t.real_qty,
                                      null) month_08,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      9,
                                      t.real_qty,
                                      null) month_09,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      10,
                                      t.real_qty,
                                      null) month_10,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      11,
                                      t.real_qty,
                                      null) month_11,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      12,
                                      t.real_qty,
                                      null) month_12,
                               case
                                 when ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))) > 12 and
                                      ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))) <= 24 then
                                  t.real_qty
                                 else
                                  null
                               end month_13,
                               case
                                 when ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))) > 24 and
                                      ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))) <= 36 then
                                  t.real_qty
                                 else
                                  null
                               end month_14,
                               case
                                 when ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))) > 36 then
                                  t.real_qty
                                 else
                                  null
                               end month_15
                          from A3_INV_STOCK_DAILY t where
                          t.sub_inv_code = row_statistic_cur.STATISTIC_INVENTORY_Code
                           and t.finance_entity_id=to_char(p_entity_id)
                           and t.stock_date = info_date
                           ) a1 ,t_bd_item tbi where a1.item_code=tbi.item_code and tbi.entity_id = p_entity_id group by a1.item_code,tbi.item_name,tbi.defaultunit) b1;

                    exception
                      when others then
                         rollback;
                         v_exception :='结存日期为：'||info_date||'，取A3结存数量有误!'||sqlerrm;
                         return;
                    end;

/*                    begin
                      select count(1) into v_is_data from T_INV_CHECK_INFO_LINETEMP where CREATED_BY = p_user_code;
                      if v_is_data=0 then
                         rollback;
                          v_exception :='根据录入的盘存日期和财务仓，在A3提供的数据中找不到对应的产品!';
                          return;
                      end if;
                    end;*/

                      for c_end_qty_row in c_end_qty loop


                        update T_INV_CHECK_INFO_TEMPORYORY
                           set item_code = c_end_qty_row.item_code,
                               item_desc = c_end_qty_row.item_desc,
                               uom       = c_end_qty_row.uom
                         where item_code = c_end_qty_row.item_code And inv_code = c_end_qty_row.inv_code;

                        if sql%notfound then
                          insert into T_INV_CHECK_INFO_TEMPORYORY
                            (CHECK_INFO_LINE_ID,
                             ITEM_CODE,
                             ITEM_DESC,
                             UOM,
                             LOGISTICS_QTY,
                             REAL_QTY,
                             KL_QTY_1M,
                             KL_QTY_2M,
                             KL_QTY_3M,
                             KL_QTY_4M,
                             KL_QTY_5M,
                             KL_QTY_6M,
                             KL_QTY_7M,
                             KL_QTY_8M,
                             KL_QTY_9M,
                             KL_QTY_10M,
                             KL_QTY_11M,
                             KL_QTY_12M,
                             KL_QTY_1Y_TO_2Y,
                             KL_QTY_2Y_TO_3Y,
                             KL_QTY_3Y_OVER,
                             inv_id,
                             inv_code,
                             inv_name)
                          values

                            (s_t_inv_check_info_temporary.nextval,
                             nvl(c_end_qty_row.item_code, 0),
                             nvl(c_end_qty_row.item_desc, 0),
                             nvl(c_end_qty_row.uom, 0),
                             nvl(c_end_qty_row.logistics_qty, 0),
                             nvl(c_end_qty_row.real_qty, 0),
                             nvl(c_end_qty_row.kl_qty_1m, 0),
                             nvl(c_end_qty_row.kl_qty_2m, 0),
                             nvl(c_end_qty_row.kl_qty_3m, 0),
                             nvl(c_end_qty_row.kl_qty_4m, 0),
                             nvl(c_end_qty_row.kl_qty_5m, 0),
                             nvl(c_end_qty_row.kl_qty_6m, 0),
                             nvl(c_end_qty_row.kl_qty_7m, 0),
                             nvl(c_end_qty_row.kl_qty_8m, 0),
                             nvl(c_end_qty_row.kl_qty_9m, 0),
                             nvl(c_end_qty_row.kl_qty_10m, 0),
                             nvl(c_end_qty_row.kl_qty_11m, 0),
                             nvl(c_end_qty_row.kl_qty_12m, 0),
                             nvl(c_end_qty_row.kl_qty_1y_to_2y, 0),
                             nvl(c_end_qty_row.kl_qty_2y_to_3y, 0),
                             nvl(c_end_qty_row.kl_qty_3y_over, 0),
                             row_statistic_cur.STATISTIC_INVENTORY_ID,
                             row_statistic_cur.STATISTIC_INVENTORY_Code,
                             row_statistic_cur.STATISTIC_INVENTORY_Name);

                        else
                          update T_INV_CHECK_INFO_TEMPORYORY
                             set LOGISTICS_QTY   = c_end_qty_row.logistics_qty,
                                 REAL_QTY        = c_end_qty_row.real_qty,
                                 KL_QTY_1M       = c_end_qty_row.kl_qty_1m,
                                 KL_QTY_2M       = c_end_qty_row.kl_qty_2m,
                                 KL_QTY_3M       = c_end_qty_row.kl_qty_3m,
                                 KL_QTY_4M       = c_end_qty_row.kl_qty_4m,
                                 KL_QTY_5M       = c_end_qty_row.kl_qty_5m,
                                 KL_QTY_6M       = c_end_qty_row.kl_qty_6m,
                                 KL_QTY_7M       = c_end_qty_row.kl_qty_7m,
                                 KL_QTY_8M       = c_end_qty_row.kl_qty_8m,
                                 KL_QTY_9M       = c_end_qty_row.kl_qty_9m,
                                 KL_QTY_10M      = c_end_qty_row.kl_qty_10m,
                                 KL_QTY_11M      = c_end_qty_row.kl_qty_11m,
                                 KL_QTY_12M      = c_end_qty_row.kl_qty_12m,
                                 KL_QTY_1Y_TO_2Y = c_end_qty_row.kl_qty_1y_to_2y,
                                 KL_QTY_2Y_TO_3Y = c_end_qty_row.kl_qty_2y_to_3y,
                                 KL_QTY_3Y_OVER  = c_end_qty_row.kl_qty_3y_over
                           where item_code = c_end_qty_row.item_code And inv_code = c_end_qty_row.inv_code;

                        end if;
                      end loop;
                      update T_INV_CHECK_INFO_TEMPORYORY ticit set ticit.book_differences_qty=nvl(ticit.book_qty,0)-nvl(ticit.logistics_qty,0);
                      update T_INV_CHECK_INFO_TEMPORYORY ticit set ticit.book_real_differences_qty=nvl(ticit.book_qty,0)-nvl(ticit.real_qty,0);
                      update  T_INV_CHECK_INFO_TEMPORYORY ticit set ticit.book_qty=nvl(ticit.book_qty,0),
                                                              ticit.logistics_qty=nvl(ticit.logistics_qty,0),
                                                              ticit.real_qty=nvl(ticit.real_qty,0),
                                                              ticit.kl_qty_1m=nvl(ticit.kl_qty_1m,0),
                                                              ticit.kl_qty_2m=nvl(ticit.kl_qty_2m,0),
                                                              ticit.kl_qty_3m=nvl(ticit.kl_qty_3m,0),
                                                              ticit.kl_qty_4m=nvl(ticit.kl_qty_4m,0),
                                                              ticit.kl_qty_5m=nvl(ticit.kl_qty_5m,0),
                                                              ticit.kl_qty_6m=nvl(ticit.kl_qty_6m,0),
                                                              ticit.kl_qty_7m=nvl(ticit.kl_qty_7m,0),
                                                              ticit.kl_qty_8m=nvl(ticit.kl_qty_8m,0),
                                                              ticit.kl_qty_9m=nvl(ticit.kl_qty_9m,0),
                                                              ticit.kl_qty_10m=nvl(ticit.kl_qty_10m,0),
                                                              ticit.kl_qty_11m=nvl(ticit.kl_qty_11m,0),
                                                              ticit.kl_qty_12m=nvl(ticit.kl_qty_12m,0),
                                                              ticit.kl_qty_1y_to_2y=nvl(ticit.kl_qty_1y_to_2y,0),
                                                              ticit.kl_qty_2y_to_3y=nvl(ticit.kl_qty_2y_to_3y,0),
                                                              ticit.kl_qty_3y_over=nvl(ticit.kl_qty_3y_over,0),
                                                              ticit.book_differences_qty=nvl(ticit.book_differences_qty,0),
                                                              ticit.book_real_differences_qty=nvl(ticit.book_real_differences_qty,0);
                    else

                      begin
                        insert into T_INV_CHECK_INFO_LINETEMP
                        (CHECK_INFO_LINE_ID,
                         ITEM_CODE,
                         ITEM_DESC,
                         UOM,
                         LOGISTICS_QTY,
                         REAL_QTY,
                         KL_QTY_1M,
                         KL_QTY_2M,
                         KL_QTY_3M,
                         KL_QTY_4M,
                         KL_QTY_5M,
                         KL_QTY_6M,
                         KL_QTY_7M,
                         KL_QTY_8M,
                         KL_QTY_9M,
                         KL_QTY_10M,
                         KL_QTY_11M,
                         KL_QTY_12M,
                         KL_QTY_1Y_TO_2Y,
                         KL_QTY_2Y_TO_3Y,
                         KL_QTY_3Y_OVER,
                         CREATED_BY,
                         CREATION_DATE,
                         inv_id,
                         inv_code,
                         inv_name)
                         select S_T_INV_CHECK_INFOLINESTEMP.NEXTVAL,
                                b1.item_code,
                                b1.item_name,
                                b1.defaultunit,
                                b1.sum_qty,
                                b1.real_qty,
                                b1.month_01,
                                b1.month_02,
                                b1.month_03,
                                b1.month_04,
                                b1.month_05,
                                b1.month_06,
                                b1.month_07,
                                b1.month_08,
                                b1. month_09,
                                b1.month_10,
                                b1.month_11,
                                b1.month_12,
                                b1.month_13,
                                b1.month_14,
                                b1.month_15,
                                p_user_code,
                                sysdate,
                                row_statistic_cur.STATISTIC_INVENTORY_ID,
                                row_statistic_cur.STATISTIC_INVENTORY_Code,
                                row_statistic_cur.STATISTIC_INVENTORY_Name

                          from (select a1.item_code,tbi.item_name,tbi.defaultunit,

                       sum(nvl(month_01, 0) + nvl(month_02, 0) + nvl(month_03, 0) +
                           nvl(month_04, 0) + nvl(month_07, 0) + nvl(month_05, 0) +
                           nvl(month_06, 0) + nvl(month_08, 0) + nvl(month_09, 0) +
                           nvl(month_10, 0) + nvl(month_11, 0) + nvl(month_12, 0) +
                           nvl(month_13, 0) + nvl(month_14, 0) + nvl(month_15, 0)) sum_qty,
                       sum(nvl(month_01, 0) + nvl(month_02, 0) + nvl(month_03, 0) +
                           nvl(month_04, 0) + nvl(month_07, 0) + nvl(month_05, 0) +
                           nvl(month_06, 0) + nvl(month_08, 0) + nvl(month_09, 0) +
                           nvl(month_10, 0) + nvl(month_11, 0) + nvl(month_12, 0) +
                           nvl(month_13, 0) + nvl(month_14, 0) + nvl(month_15, 0)) real_qty,
                       sum(month_01) month_01,
                       sum(month_02) month_02,
                       sum(month_03) month_03,
                       sum(month_04) month_04,
                       sum(month_05) month_05,
                       sum(month_06) month_06,
                       sum(month_07) month_07,
                       sum(month_08) month_08,
                       sum(month_09) month_09,
                       sum(month_10) month_10,
                       sum(month_11) month_11,
                       sum(month_12) month_12,
                       sum(month_13) month_13,
                       sum(month_14) month_14,
                       sum(month_15) month_15
                  from (select ceil(months_between(trunc(info_date),
                                                   to_date('20' || t.item_batch, 'yyyy-mm'))),
                               t.item_code,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      1,
                                      t.real_qty,
                                      null) month_01,

                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      2,
                                      t.real_qty,
                                      null) month_02,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      3,
                                      t.real_qty,
                                      null) month_03,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      4,
                                      t.real_qty,
                                      null) month_04,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      5,
                                      t.real_qty,
                                      null) month_05,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      6,
                                      t.real_qty,
                                      null) month_06,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      7,
                                      t.real_qty,
                                      null) month_07,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      8,
                                      t.real_qty,
                                      null) month_08,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      9,
                                      t.real_qty,
                                      null) month_09,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      10,
                                      t.real_qty,
                                      null) month_10,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      11,
                                      t.real_qty,
                                      null) month_11,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      12,
                                      t.real_qty,
                                      null) month_12,
                               case
                                 when ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))) > 12 and
                                      ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))) <= 24 then
                                  t.real_qty
                                 else
                                  null
                               end month_13,
                               case
                                 when ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))) > 24 and
                                      ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))) <= 36 then
                                  t.real_qty
                                 else
                                  null
                               end month_14,
                               case
                                 when ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))) > 36 then
                                  t.real_qty
                                 else
                                  null
                               end month_15
                          from A3_INV_STOCK t where
                           t.finance_entity_id=to_char(p_entity_id)
                          and t.sub_inv_code = row_statistic_cur.STATISTIC_INVENTORY_Code
                           ) a1 ,t_bd_item tbi where a1.item_code=tbi.item_code and tbi.entity_id = p_entity_id group by a1.item_code,tbi.item_name,tbi.defaultunit) b1;
                      exception
                      when others then
                         rollback;
                         v_exception :='取A3实时数据后，插入T_INV_CHECK_INFO_LINETEMP有误!'||sqlerrm;
                         return;
                      end;

/*                      begin
                        select count(1) into v_is_data from T_INV_CHECK_INFO_LINETEMP where CREATED_BY = p_user_code;
                         if v_is_data=0 then
                           rollback;
                           v_exception :='根据录入的盘存日期和财务仓，在A3提供的数据中找不到对应的产品!';
                           return;
                         end if;
                      end;*/



                      for c_end_qty_row in c_end_qty loop
                        update T_INV_CHECK_INFO_TEMPORYORY
                           set item_code = c_end_qty_row.item_code
                         where item_code = c_end_qty_row.item_code And inv_code = row_statistic_cur.STATISTIC_INVENTORY_Code;

                        if sql%notfound then
                          insert into T_INV_CHECK_INFO_TEMPORYORY
                            (CHECK_INFO_LINE_ID,
                             ITEM_CODE,
                             ITEM_DESC,
                             UOM,
                             LOGISTICS_QTY,
                             REAL_QTY,
                             KL_QTY_1M,
                             KL_QTY_2M,
                             KL_QTY_3M,
                             KL_QTY_4M,
                             KL_QTY_5M,
                             KL_QTY_6M,
                             KL_QTY_7M,
                             KL_QTY_8M,
                             KL_QTY_9M,
                             KL_QTY_10M,
                             KL_QTY_11M,
                             KL_QTY_12M,
                             KL_QTY_1Y_TO_2Y,
                             KL_QTY_2Y_TO_3Y,
                             KL_QTY_3Y_OVER,
                             inv_id,
                             inv_code,
                             inv_name)
                          values

                            (s_t_inv_check_info_temporary.nextval,
                             nvl(c_end_qty_row.item_code, 0),
                             nvl(c_end_qty_row.Item_Desc, 0),
                             nvl(c_end_qty_row.Uom, 0),
                             nvl(c_end_qty_row.Logistics_Qty, 0),
                             nvl(c_end_qty_row.real_qty, 0),
                             nvl(c_end_qty_row.kl_qty_1m, 0),
                             nvl(c_end_qty_row.kl_qty_2m, 0),
                             nvl(c_end_qty_row.kl_qty_3m, 0),
                             nvl(c_end_qty_row.kl_qty_4m, 0),
                             nvl(c_end_qty_row.kl_qty_5m, 0),
                             nvl(c_end_qty_row.kl_qty_6m, 0),
                             nvl(c_end_qty_row.kl_qty_7m, 0),
                             nvl(c_end_qty_row.kl_qty_8m, 0),
                             nvl(c_end_qty_row.kl_qty_9m, 0),
                             nvl(c_end_qty_row.kl_qty_10m, 0),
                             nvl(c_end_qty_row.kl_qty_11m, 0),
                             nvl(c_end_qty_row.kl_qty_12m, 0),
                             nvl(c_end_qty_row.kl_qty_1y_to_2y, 0),
                             nvl(c_end_qty_row.kl_qty_2y_to_3y, 0),
                             nvl(c_end_qty_row.kl_qty_3y_over, 0),
                             row_statistic_cur.STATISTIC_INVENTORY_ID,
                             row_statistic_cur.STATISTIC_INVENTORY_Code,
                             row_statistic_cur.STATISTIC_INVENTORY_Name);

                        else
                          update T_INV_CHECK_INFO_TEMPORYORY
                             set
                                 LOGISTICS_QTY   = c_end_qty_row.Logistics_Qty,
                                 REAL_QTY        = c_end_qty_row.real_qty,
                                 KL_QTY_1M       = c_end_qty_row.kl_qty_1m,
                                 KL_QTY_2M       = c_end_qty_row.kl_qty_2m,
                                 KL_QTY_3M       = c_end_qty_row.kl_qty_3m,
                                 KL_QTY_4M       = c_end_qty_row.kl_qty_4m,
                                 KL_QTY_5M       = c_end_qty_row.kl_qty_5m,
                                 KL_QTY_6M       = c_end_qty_row.kl_qty_6m,
                                 KL_QTY_7M       = c_end_qty_row.kl_qty_7m,
                                 KL_QTY_8M       = c_end_qty_row.kl_qty_8m,
                                 KL_QTY_9M       = c_end_qty_row.kl_qty_9m,
                                 KL_QTY_10M      = c_end_qty_row.kl_qty_10m,
                                 KL_QTY_11M      = c_end_qty_row.kl_qty_11m,
                                 KL_QTY_12M      = c_end_qty_row.kl_qty_12m,
                                 KL_QTY_1Y_TO_2Y = c_end_qty_row.kl_qty_1y_to_2y,
                                 KL_QTY_2Y_TO_3Y = c_end_qty_row.kl_qty_2y_to_3y,
                                 KL_QTY_3Y_OVER  = c_end_qty_row.kl_qty_3y_over

                           where item_code = c_end_qty_row.item_code And inv_code = row_statistic_cur.STATISTIC_INVENTORY_Code;

                        end if;

                      end loop;

                      update T_INV_CHECK_INFO_TEMPORYORY ticit set ticit.book_differences_qty=nvl(ticit.book_qty,0)-nvl(ticit.logistics_qty,0);
                      update T_INV_CHECK_INFO_TEMPORYORY ticit set ticit.book_real_differences_qty=nvl(ticit.book_qty,0)-nvl(ticit.real_qty,0);
                      update  T_INV_CHECK_INFO_TEMPORYORY ticit set ticit.book_qty=nvl(ticit.book_qty,0),
                                                              ticit.logistics_qty=nvl(ticit.logistics_qty,0),
                                                              ticit.real_qty=nvl(ticit.real_qty,0),
                                                              ticit.kl_qty_1m=nvl(ticit.kl_qty_1m,0),
                                                              ticit.kl_qty_2m=nvl(ticit.kl_qty_2m,0),
                                                              ticit.kl_qty_3m=nvl(ticit.kl_qty_3m,0),
                                                              ticit.kl_qty_4m=nvl(ticit.kl_qty_4m,0),
                                                              ticit.kl_qty_5m=nvl(ticit.kl_qty_5m,0),
                                                              ticit.kl_qty_6m=nvl(ticit.kl_qty_6m,0),
                                                              ticit.kl_qty_7m=nvl(ticit.kl_qty_7m,0),
                                                              ticit.kl_qty_8m=nvl(ticit.kl_qty_8m,0),
                                                              ticit.kl_qty_9m=nvl(ticit.kl_qty_9m,0),
                                                              ticit.kl_qty_10m=nvl(ticit.kl_qty_10m,0),
                                                              ticit.kl_qty_11m=nvl(ticit.kl_qty_11m,0),
                                                              ticit.kl_qty_12m=nvl(ticit.kl_qty_12m,0),
                                                              ticit.kl_qty_1y_to_2y=nvl(ticit.kl_qty_1y_to_2y,0),
                                                              ticit.kl_qty_2y_to_3y=nvl(ticit.kl_qty_2y_to_3y,0),
                                                              ticit.kl_qty_3y_over=nvl(ticit.kl_qty_3y_over,0),
                                                              ticit.book_differences_qty=nvl(ticit.book_differences_qty,0),
                                                              ticit.book_real_differences_qty=nvl(ticit.book_real_differences_qty,0);

                    end if;

                        v_exception :='seuccess';
               --zhangwm 增加删除临时行数据信息。2015-12-31
               delete T_INV_CHECK_INFO_LINETEMP where CREATED_BY = p_user_code;
         else
         --  delete T_INV_CHECK_INFO_LINETEMP where 1 = 1;
                    select info_date - trunc(sysdate) into n_info_date from dual;
                    if n_info_date < 0 then

                  begin
                      SELECT PERIOD_ID, END_DATE + 1 BEGIN_DATE into v_period_id,v_begin_date
                        FROM CIMS.T_INV_INVENTORY_PERIODS ip
                       WHERE ip.ENTITY_ID = p_entity_id
                         AND BEGIN_DATE =
                             (SELECT MAX(P.BEGIN_DATE) BEGIN_DATE
                                FROM CIMS.T_INV_INVENTORY_PERIODS P, CIMS.T_SL_SFC_FREEZE F
                               WHERE P.PERIOD_ID = F.PERIOD_ID AND P.ENTITY_ID = p_entity_id
                                 AND P.END_DATE < info_date);
                     insert into T_INV_CHECK_INFO_LINETEMP
                        (CHECK_INFO_LINE_ID,
                         ITEM_CODE,
                         ITEM_DESC,
                         UOM,
                         LOGISTICS_QTY,
                         REAL_QTY,
                         KL_QTY_1M,
                         KL_QTY_2M,
                         KL_QTY_3M,
                         KL_QTY_4M,
                         KL_QTY_5M,
                         KL_QTY_6M,
                         KL_QTY_7M,
                         KL_QTY_8M,
                         KL_QTY_9M,
                         KL_QTY_10M,
                         KL_QTY_11M,
                         KL_QTY_12M,
                         KL_QTY_1Y_TO_2Y,
                         KL_QTY_2Y_TO_3Y,
                         KL_QTY_3Y_OVER,
                         CREATED_BY,
                         CREATION_DATE,
                         inv_id,
                         inv_code,
                         inv_name )
                         select S_T_INV_CHECK_INFOLINESTEMP.NEXTVAL,
                                b1.item_code,
                                b1.item_name,
                                b1.defaultunit,
                                b1.sum_qty,
                                b1.real_qty,
                                b1.month_01,
                                b1.month_02,
                                b1.month_03,
                                b1.month_04,
                                b1.month_05,
                                b1.month_06,
                                b1.month_07,
                                b1.month_08,
                                b1. month_09,
                                b1.month_10,
                                b1.month_11,
                                b1.month_12,
                                b1.month_13,
                                b1.month_14,
                                b1.month_15,
                                p_user_code,
                                sysdate,
                                row_statistic_cur.STATISTIC_INVENTORY_ID,
                                row_statistic_cur.STATISTIC_INVENTORY_Code,
                                row_statistic_cur.STATISTIC_INVENTORY_Name

                          from (select a1.item_code,tbi.item_name,tbi.defaultunit,

                       sum(nvl(month_01, 0) + nvl(month_02, 0) + nvl(month_03, 0) +
                           nvl(month_04, 0) + nvl(month_07, 0) + nvl(month_05, 0) +
                           nvl(month_06, 0) + nvl(month_08, 0) + nvl(month_09, 0) +
                           nvl(month_10, 0) + nvl(month_11, 0) + nvl(month_12, 0) +
                           nvl(month_13, 0) + nvl(month_14, 0) + nvl(month_15, 0)) sum_qty,
                       sum(nvl(month_01, 0) + nvl(month_02, 0) + nvl(month_03, 0) +
                           nvl(month_04, 0) + nvl(month_07, 0) + nvl(month_05, 0) +
                           nvl(month_06, 0) + nvl(month_08, 0) + nvl(month_09, 0) +
                           nvl(month_10, 0) + nvl(month_11, 0) + nvl(month_12, 0) +
                           nvl(month_13, 0) + nvl(month_14, 0) + nvl(month_15, 0)) real_qty,
                       sum(month_01) month_01,
                       sum(month_02) month_02,
                       sum(month_03) month_03,
                       sum(month_04) month_04,
                       sum(month_05) month_05,
                       sum(month_06) month_06,
                       sum(month_07) month_07,
                       sum(month_08) month_08,
                       sum(month_09) month_09,
                       sum(month_10) month_10,
                       sum(month_11) month_11,
                       sum(month_12) month_12,
                       sum(month_13) month_13,
                       sum(month_14) month_14,
                       sum(month_15) month_15
                  from (select ceil(months_between(trunc(info_date),
                                                   to_date('20' || t.item_batch, 'yyyy-mm'))),
                               t.item_code,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      1,
                                      t.real_qty,
                                      null) month_01,

                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      2,
                                      t.real_qty,
                                      null) month_02,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      3,
                                      t.real_qty,
                                      null) month_03,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      4,
                                      t.real_qty,
                                      null) month_04,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      5,
                                      t.real_qty,
                                      null) month_05,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      6,
                                      t.real_qty,
                                      null) month_06,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      7,
                                      t.real_qty,
                                      null) month_07,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      8,
                                      t.real_qty,
                                      null) month_08,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      9,
                                      t.real_qty,
                                      null) month_09,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      10,
                                      t.real_qty,
                                      null) month_10,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      11,
                                      t.real_qty,
                                      null) month_11,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      12,
                                      t.real_qty,
                                      null) month_12,
                               case
                                 when ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))) > 12 and
                                      ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))) <= 24 then
                                  t.real_qty
                                 else
                                  null
                               end month_13,
                               case
                                 when ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))) > 24 and
                                      ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))) <= 36 then
                                  t.real_qty
                                 else
                                  null
                               end month_14,
                               case
                                 when ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))) > 36 then
                                  t.real_qty
                                 else
                                  null
                               end month_15
                          from (SELECT
                                    II.INVENTORY_CODE sub_inv_code
                                    ,BI.ITEM_CODE
                                    ,O.ITEM_BATCH
                                    ,SUM(O.QUANTITY) real_qty
                                  FROM
                                    (
                                      SELECT
                                        INVENTORY_ID
                                        ,ITEM_ID
                                        ,ITEM_BATCH
                                        ,SUM(END_QTY) QUANTITY
                                      FROM
                                        CIMS.T_SL_SFC_FREEZE F
                                      WHERE
                                        F.PERIOD_ID = v_period_id
                                        AND F.STORE_TYPE = 'F'
                                      GROUP BY
                                        INVENTORY_ID
                                        ,ITEM_ID
                                        ,ITEM_BATCH
                                      UNION ALL
                                      SELECT
                                        BH.INVENTORY_ID
                                        ,BL.ITEM_ID
                                        ,DECODE(BH.SEND_INV_ID,NULL,BL.REV_ITEM_BATCH,BL.SEND_ITEM_BATCH) ITEM_BATCH
                                        ,SUM(BL.QUANTITY*DECODE(BH.SEND_INV_ID,NULL,BH.REV_INV_SIGN,BH.SEND_INV_SIGN)) QUANTITY
                                      FROM
                                        CIMS.T_SL_BILL_HEADER BH
                                        ,CIMS.T_SL_BILL_LINE BL
                                      WHERE
                                        BH.BILL_HEADER_ID = BL.BILL_HEADER_ID
                                        AND BH.BUSINESS_TYPE <> '33'
                                        AND BH.AFFIRM_DATE BETWEEN v_begin_date AND info_date
                                      GROUP BY
                                        BH.INVENTORY_ID
                                        ,BL.ITEM_ID
                                        ,DECODE(BH.SEND_INV_ID,NULL,BL.REV_ITEM_BATCH,BL.SEND_ITEM_BATCH)
                                    ) O
                                    ,T_INV_INVENTORIES II
                                    ,T_BD_ITEM BI
                                  WHERE
                                    O.INVENTORY_ID = II.INVENTORY_ID
                                    AND O.ITEM_ID = BI.ITEM_ID
                                  GROUP BY
                                    II.INVENTORY_CODE
                                    ,BI.ITEM_CODE
                                    ,O.ITEM_BATCH) t where
                                                        t.sub_inv_code = row_statistic_cur.STATISTIC_INVENTORY_Code

                           ) a1 ,t_bd_item tbi where a1.item_code=tbi.item_code and tbi.entity_id = p_entity_id group by a1.item_code,tbi.item_name,tbi.defaultunit) b1;

                    exception
                      when others then
                         rollback;
                         v_exception :='结存日期为：'||info_date||'，取库位结存数量有误!'||sqlerrm;
                         return;
                    end;

/*                    begin
                      select count(1) into v_is_data from T_INV_CHECK_INFO_LINETEMP where CREATED_BY = p_user_code;
                      if v_is_data=0 then
                         rollback;
                          v_exception :='根据录入的盘存日期和财务仓，在库位模块提供的数据中找不到对应的产品!';
                          return;
                      end if;
                    end;*/

                      for c_end_qty_row in c_end_qty loop


                        update T_INV_CHECK_INFO_TEMPORYORY
                           set item_code = c_end_qty_row.item_code,
                               item_desc = c_end_qty_row.item_desc,
                               uom       = c_end_qty_row.uom
                         where item_code = c_end_qty_row.item_code And inv_code = row_statistic_cur.STATISTIC_INVENTORY_Code;

                        if sql%notfound then
                          insert into T_INV_CHECK_INFO_TEMPORYORY
                            (CHECK_INFO_LINE_ID,
                             ITEM_CODE,
                             ITEM_DESC,
                             UOM,
                             LOGISTICS_QTY,
                             REAL_QTY,
                             KL_QTY_1M,
                             KL_QTY_2M,
                             KL_QTY_3M,
                             KL_QTY_4M,
                             KL_QTY_5M,
                             KL_QTY_6M,
                             KL_QTY_7M,
                             KL_QTY_8M,
                             KL_QTY_9M,
                             KL_QTY_10M,
                             KL_QTY_11M,
                             KL_QTY_12M,
                             KL_QTY_1Y_TO_2Y,
                             KL_QTY_2Y_TO_3Y,
                             KL_QTY_3Y_OVER,
                             inv_id,
                             inv_code,
                             inv_name)
                          values

                            (s_t_inv_check_info_temporary.nextval,
                             nvl(c_end_qty_row.item_code, 0),
                             nvl(c_end_qty_row.item_desc, 0),
                             nvl(c_end_qty_row.uom, 0),
                             nvl(c_end_qty_row.logistics_qty, 0),
                             nvl(c_end_qty_row.real_qty, 0),
                             nvl(c_end_qty_row.kl_qty_1m, 0),
                             nvl(c_end_qty_row.kl_qty_2m, 0),
                             nvl(c_end_qty_row.kl_qty_3m, 0),
                             nvl(c_end_qty_row.kl_qty_4m, 0),
                             nvl(c_end_qty_row.kl_qty_5m, 0),
                             nvl(c_end_qty_row.kl_qty_6m, 0),
                             nvl(c_end_qty_row.kl_qty_7m, 0),
                             nvl(c_end_qty_row.kl_qty_8m, 0),
                             nvl(c_end_qty_row.kl_qty_9m, 0),
                             nvl(c_end_qty_row.kl_qty_10m, 0),
                             nvl(c_end_qty_row.kl_qty_11m, 0),
                             nvl(c_end_qty_row.kl_qty_12m, 0),
                             nvl(c_end_qty_row.kl_qty_1y_to_2y, 0),
                             nvl(c_end_qty_row.kl_qty_2y_to_3y, 0),
                             nvl(c_end_qty_row.kl_qty_3y_over, 0),
                             row_statistic_cur.STATISTIC_INVENTORY_ID,
                             row_statistic_cur.STATISTIC_INVENTORY_Code,
                             row_statistic_cur.STATISTIC_INVENTORY_Name);

                        else
                          update T_INV_CHECK_INFO_TEMPORYORY
                             set LOGISTICS_QTY   = c_end_qty_row.logistics_qty,
                                 REAL_QTY        = c_end_qty_row.real_qty,
                                 KL_QTY_1M       = c_end_qty_row.kl_qty_1m,
                                 KL_QTY_2M       = c_end_qty_row.kl_qty_2m,
                                 KL_QTY_3M       = c_end_qty_row.kl_qty_3m,
                                 KL_QTY_4M       = c_end_qty_row.kl_qty_4m,
                                 KL_QTY_5M       = c_end_qty_row.kl_qty_5m,
                                 KL_QTY_6M       = c_end_qty_row.kl_qty_6m,
                                 KL_QTY_7M       = c_end_qty_row.kl_qty_7m,
                                 KL_QTY_8M       = c_end_qty_row.kl_qty_8m,
                                 KL_QTY_9M       = c_end_qty_row.kl_qty_9m,
                                 KL_QTY_10M      = c_end_qty_row.kl_qty_10m,
                                 KL_QTY_11M      = c_end_qty_row.kl_qty_11m,
                                 KL_QTY_12M      = c_end_qty_row.kl_qty_12m,
                                 KL_QTY_1Y_TO_2Y = c_end_qty_row.kl_qty_1y_to_2y,
                                 KL_QTY_2Y_TO_3Y = c_end_qty_row.kl_qty_2y_to_3y,
                                 KL_QTY_3Y_OVER  = c_end_qty_row.kl_qty_3y_over
                           where item_code = c_end_qty_row.item_code And inv_code = row_statistic_cur.STATISTIC_INVENTORY_Code;

                        end if;
                      end loop;
                      update T_INV_CHECK_INFO_TEMPORYORY ticit set ticit.book_differences_qty=nvl(ticit.book_qty,0)-nvl(ticit.logistics_qty,0);
                      update T_INV_CHECK_INFO_TEMPORYORY ticit set ticit.book_real_differences_qty=nvl(ticit.book_qty,0)-nvl(ticit.real_qty,0);
                      update  T_INV_CHECK_INFO_TEMPORYORY ticit set ticit.book_qty=nvl(ticit.book_qty,0),
                                                              ticit.logistics_qty=nvl(ticit.logistics_qty,0),
                                                              ticit.real_qty=nvl(ticit.real_qty,0),
                                                              ticit.kl_qty_1m=nvl(ticit.kl_qty_1m,0),
                                                              ticit.kl_qty_2m=nvl(ticit.kl_qty_2m,0),
                                                              ticit.kl_qty_3m=nvl(ticit.kl_qty_3m,0),
                                                              ticit.kl_qty_4m=nvl(ticit.kl_qty_4m,0),
                                                              ticit.kl_qty_5m=nvl(ticit.kl_qty_5m,0),
                                                              ticit.kl_qty_6m=nvl(ticit.kl_qty_6m,0),
                                                              ticit.kl_qty_7m=nvl(ticit.kl_qty_7m,0),
                                                              ticit.kl_qty_8m=nvl(ticit.kl_qty_8m,0),
                                                              ticit.kl_qty_9m=nvl(ticit.kl_qty_9m,0),
                                                              ticit.kl_qty_10m=nvl(ticit.kl_qty_10m,0),
                                                              ticit.kl_qty_11m=nvl(ticit.kl_qty_11m,0),
                                                              ticit.kl_qty_12m=nvl(ticit.kl_qty_12m,0),
                                                              ticit.kl_qty_1y_to_2y=nvl(ticit.kl_qty_1y_to_2y,0),
                                                              ticit.kl_qty_2y_to_3y=nvl(ticit.kl_qty_2y_to_3y,0),
                                                              ticit.kl_qty_3y_over=nvl(ticit.kl_qty_3y_over,0),
                                                              ticit.book_differences_qty=nvl(ticit.book_differences_qty,0),
                                                              ticit.book_real_differences_qty=nvl(ticit.book_real_differences_qty,0);
                    else

                      begin
                        insert into T_INV_CHECK_INFO_LINETEMP
                        (CHECK_INFO_LINE_ID,
                         ITEM_CODE,
                         ITEM_DESC,
                         UOM,
                         LOGISTICS_QTY,
                         REAL_QTY,
                         KL_QTY_1M,
                         KL_QTY_2M,
                         KL_QTY_3M,
                         KL_QTY_4M,
                         KL_QTY_5M,
                         KL_QTY_6M,
                         KL_QTY_7M,
                         KL_QTY_8M,
                         KL_QTY_9M,
                         KL_QTY_10M,
                         KL_QTY_11M,
                         KL_QTY_12M,
                         KL_QTY_1Y_TO_2Y,
                         KL_QTY_2Y_TO_3Y,
                         KL_QTY_3Y_OVER,
                         CREATED_BY,
                         CREATION_DATE,
                         inv_id,
                         inv_code,
                         inv_name
                         )
                         select S_T_INV_CHECK_INFOLINESTEMP.NEXTVAL,
                                b1.item_code,
                                b1.item_name,
                                b1.defaultunit,
                                b1.sum_qty,
                                b1.real_qty,
                                b1.month_01,
                                b1.month_02,
                                b1.month_03,
                                b1.month_04,
                                b1.month_05,
                                b1.month_06,
                                b1.month_07,
                                b1.month_08,
                                b1. month_09,
                                b1.month_10,
                                b1.month_11,
                                b1.month_12,
                                b1.month_13,
                                b1.month_14,
                                b1.month_15,
                                p_user_code,
                                sysdate,
                                row_statistic_cur.STATISTIC_INVENTORY_ID,
                                row_statistic_cur.STATISTIC_INVENTORY_Code,
                                row_statistic_cur.STATISTIC_INVENTORY_Name

                          from (select a1.item_code,tbi.item_name,tbi.defaultunit,

                       sum(nvl(month_01, 0) + nvl(month_02, 0) + nvl(month_03, 0) +
                           nvl(month_04, 0) + nvl(month_07, 0) + nvl(month_05, 0) +
                           nvl(month_06, 0) + nvl(month_08, 0) + nvl(month_09, 0) +
                           nvl(month_10, 0) + nvl(month_11, 0) + nvl(month_12, 0) +
                           nvl(month_13, 0) + nvl(month_14, 0) + nvl(month_15, 0)) sum_qty,
                       sum(nvl(month_01, 0) + nvl(month_02, 0) + nvl(month_03, 0) +
                           nvl(month_04, 0) + nvl(month_07, 0) + nvl(month_05, 0) +
                           nvl(month_06, 0) + nvl(month_08, 0) + nvl(month_09, 0) +
                           nvl(month_10, 0) + nvl(month_11, 0) + nvl(month_12, 0) +
                           nvl(month_13, 0) + nvl(month_14, 0) + nvl(month_15, 0)) real_qty,
                       sum(month_01) month_01,
                       sum(month_02) month_02,
                       sum(month_03) month_03,
                       sum(month_04) month_04,
                       sum(month_05) month_05,
                       sum(month_06) month_06,
                       sum(month_07) month_07,
                       sum(month_08) month_08,
                       sum(month_09) month_09,
                       sum(month_10) month_10,
                       sum(month_11) month_11,
                       sum(month_12) month_12,
                       sum(month_13) month_13,
                       sum(month_14) month_14,
                       sum(month_15) month_15
                  from (select ceil(months_between(trunc(info_date),
                                                   to_date('20' || t.item_batch, 'yyyy-mm'))),
                               t.item_code,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      1,
                                      t.real_qty,
                                      null) month_01,

                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      2,
                                      t.real_qty,
                                      null) month_02,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      3,
                                      t.real_qty,
                                      null) month_03,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      4,
                                      t.real_qty,
                                      null) month_04,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      5,
                                      t.real_qty,
                                      null) month_05,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      6,
                                      t.real_qty,
                                      null) month_06,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      7,
                                      t.real_qty,
                                      null) month_07,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      8,
                                      t.real_qty,
                                      null) month_08,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      9,
                                      t.real_qty,
                                      null) month_09,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      10,
                                      t.real_qty,
                                      null) month_10,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      11,
                                      t.real_qty,
                                      null) month_11,
                               decode(ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))),
                                      12,
                                      t.real_qty,
                                      null) month_12,
                               case
                                 when ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))) > 12 and
                                      ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))) <= 24 then
                                  t.real_qty
                                 else
                                  null
                               end month_13,
                               case
                                 when ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))) > 24 and
                                      ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))) <= 36 then
                                  t.real_qty
                                 else
                                  null
                               end month_14,
                               case
                                 when ceil(months_between(trunc(info_date),
                                                          to_date('20' || t.item_batch,
                                                                  'yyyy-mm'))) > 36 then
                                  t.real_qty
                                 else
                                  null
                               end month_15
                          from V_SL_INV_SL_ONHAND t where
                          t.sub_inv_code = row_statistic_cur.STATISTIC_INVENTORY_Code
                          and t.ENTITY_ID=p_entity_id
                           ) a1 ,t_bd_item tbi where a1.item_code=tbi.item_code and tbi.entity_id = p_entity_id  group by a1.item_code,tbi.item_name,tbi.defaultunit) b1;
                      exception
                      when others then
                         rollback;
                         v_exception :='取库位实时数据后，插入T_INV_CHECK_INFO_LINETEMP有误!'||sqlerrm;
                         return;
                      end;

/*                      begin
                        select count(1) into v_is_data from T_INV_CHECK_INFO_LINETEMP where  CREATED_BY = p_user_code;
                         if v_is_data=0 then
                           rollback;
                           v_exception :='根据录入的盘存日期和财务仓，在库位模块提供的数据中找不到对应的产品!';
                           return;
                         end if;
                      end;*/



                      for c_end_qty_row in c_end_qty loop
                        update T_INV_CHECK_INFO_TEMPORYORY
                           set item_code = c_end_qty_row.item_code
                         where item_code = c_end_qty_row.item_code And inv_code = row_statistic_cur.STATISTIC_INVENTORY_Code;

                        if sql%notfound then
                          insert into T_INV_CHECK_INFO_TEMPORYORY
                            (CHECK_INFO_LINE_ID,
                             ITEM_CODE,
                             ITEM_DESC,
                             UOM,
                             LOGISTICS_QTY,
                             REAL_QTY,
                             KL_QTY_1M,
                             KL_QTY_2M,
                             KL_QTY_3M,
                             KL_QTY_4M,
                             KL_QTY_5M,
                             KL_QTY_6M,
                             KL_QTY_7M,
                             KL_QTY_8M,
                             KL_QTY_9M,
                             KL_QTY_10M,
                             KL_QTY_11M,
                             KL_QTY_12M,
                             KL_QTY_1Y_TO_2Y,
                             KL_QTY_2Y_TO_3Y,
                             KL_QTY_3Y_OVER,
                             inv_id,
                             inv_code,
                             inv_name)
                          values

                            (s_t_inv_check_info_temporary.nextval,
                             nvl(c_end_qty_row.item_code, 0),
                             nvl(c_end_qty_row.Item_Desc, 0),
                             nvl(c_end_qty_row.Uom, 0),
                             nvl(c_end_qty_row.Logistics_Qty, 0),
                             nvl(c_end_qty_row.real_qty, 0),
                             nvl(c_end_qty_row.kl_qty_1m, 0),
                             nvl(c_end_qty_row.kl_qty_2m, 0),
                             nvl(c_end_qty_row.kl_qty_3m, 0),
                             nvl(c_end_qty_row.kl_qty_4m, 0),
                             nvl(c_end_qty_row.kl_qty_5m, 0),
                             nvl(c_end_qty_row.kl_qty_6m, 0),
                             nvl(c_end_qty_row.kl_qty_7m, 0),
                             nvl(c_end_qty_row.kl_qty_8m, 0),
                             nvl(c_end_qty_row.kl_qty_9m, 0),
                             nvl(c_end_qty_row.kl_qty_10m, 0),
                             nvl(c_end_qty_row.kl_qty_11m, 0),
                             nvl(c_end_qty_row.kl_qty_12m, 0),
                             nvl(c_end_qty_row.kl_qty_1y_to_2y, 0),
                             nvl(c_end_qty_row.kl_qty_2y_to_3y, 0),
                             nvl(c_end_qty_row.kl_qty_3y_over, 0),
                             row_statistic_cur.STATISTIC_INVENTORY_id,
                             row_statistic_cur.STATISTIC_INVENTORY_Code,
                             row_statistic_cur.STATISTIC_INVENTORY_name);

                        else
                          update T_INV_CHECK_INFO_TEMPORYORY
                             set
                                 LOGISTICS_QTY   = c_end_qty_row.Logistics_Qty,
                                 REAL_QTY        = c_end_qty_row.real_qty,
                                 KL_QTY_1M       = c_end_qty_row.kl_qty_1m,
                                 KL_QTY_2M       = c_end_qty_row.kl_qty_2m,
                                 KL_QTY_3M       = c_end_qty_row.kl_qty_3m,
                                 KL_QTY_4M       = c_end_qty_row.kl_qty_4m,
                                 KL_QTY_5M       = c_end_qty_row.kl_qty_5m,
                                 KL_QTY_6M       = c_end_qty_row.kl_qty_6m,
                                 KL_QTY_7M       = c_end_qty_row.kl_qty_7m,
                                 KL_QTY_8M       = c_end_qty_row.kl_qty_8m,
                                 KL_QTY_9M       = c_end_qty_row.kl_qty_9m,
                                 KL_QTY_10M      = c_end_qty_row.kl_qty_10m,
                                 KL_QTY_11M      = c_end_qty_row.kl_qty_11m,
                                 KL_QTY_12M      = c_end_qty_row.kl_qty_12m,
                                 KL_QTY_1Y_TO_2Y = c_end_qty_row.kl_qty_1y_to_2y,
                                 KL_QTY_2Y_TO_3Y = c_end_qty_row.kl_qty_2y_to_3y,
                                 KL_QTY_3Y_OVER  = c_end_qty_row.kl_qty_3y_over

                           where item_code = c_end_qty_row.item_code And inv_code = row_statistic_cur.STATISTIC_INVENTORY_Code;

                        end if;

                      end loop;

                      update T_INV_CHECK_INFO_TEMPORYORY ticit set ticit.book_differences_qty=nvl(ticit.book_qty,0)-nvl(ticit.logistics_qty,0);
                      update T_INV_CHECK_INFO_TEMPORYORY ticit set ticit.book_real_differences_qty=nvl(ticit.book_qty,0)-nvl(ticit.real_qty,0);
                      update  T_INV_CHECK_INFO_TEMPORYORY ticit set ticit.book_qty=nvl(ticit.book_qty,0),
                                                              ticit.logistics_qty=nvl(ticit.logistics_qty,0),
                                                              ticit.real_qty=nvl(ticit.real_qty,0),
                                                              ticit.kl_qty_1m=nvl(ticit.kl_qty_1m,0),
                                                              ticit.kl_qty_2m=nvl(ticit.kl_qty_2m,0),
                                                              ticit.kl_qty_3m=nvl(ticit.kl_qty_3m,0),
                                                              ticit.kl_qty_4m=nvl(ticit.kl_qty_4m,0),
                                                              ticit.kl_qty_5m=nvl(ticit.kl_qty_5m,0),
                                                              ticit.kl_qty_6m=nvl(ticit.kl_qty_6m,0),
                                                              ticit.kl_qty_7m=nvl(ticit.kl_qty_7m,0),
                                                              ticit.kl_qty_8m=nvl(ticit.kl_qty_8m,0),
                                                              ticit.kl_qty_9m=nvl(ticit.kl_qty_9m,0),
                                                              ticit.kl_qty_10m=nvl(ticit.kl_qty_10m,0),
                                                              ticit.kl_qty_11m=nvl(ticit.kl_qty_11m,0),
                                                              ticit.kl_qty_12m=nvl(ticit.kl_qty_12m,0),
                                                              ticit.kl_qty_1y_to_2y=nvl(ticit.kl_qty_1y_to_2y,0),
                                                              ticit.kl_qty_2y_to_3y=nvl(ticit.kl_qty_2y_to_3y,0),
                                                              ticit.kl_qty_3y_over=nvl(ticit.kl_qty_3y_over,0),
                                                              ticit.book_differences_qty=nvl(ticit.book_differences_qty,0),
                                                              ticit.book_real_differences_qty=nvl(ticit.book_real_differences_qty,0);

                    end if;

                        v_exception :='seuccess';
              --zhangwm 增加删除临时行数据信息。2015-12-31
               delete T_INV_CHECK_INFO_LINETEMP where CREATED_BY = p_user_code;

         end if;
        end;
        
        
      End Loop;
      Close v_get_statistic;

    End If;
    
    
    


  end;

  --***********************************
  -- AUTHOR: 顾金兴
  -- LAST_UPDATE_BY:顾金兴
  -- LAST_UPDATE：2015-3-30
  -- PURPOSE:盘存报表拆分
  --***********************************

   Procedure INVENTORY_REPORT_SPLIT(    p_user         in varchar2,
                                        p_report_num   in varchar2,
                                        p_entity_id  in number,
                                        p_exception  out varchar
                                        ) is
     v_a  number;
     info_date date;
     v_isperiod_name_value       varchar(240);
     invertory_id number;
     v_isperiod_name             varchar(240);
     v_sql                        varchar2(5800);
     v_item_count_book_qty         number;
     v_item_curr_book_qty          number;
     v_s_inv_check_info            number;
     one_row_line     t_inv_check_split_BOOKTEMP%rowtype;
     one_row_line_split t_inv_check_info_lines%rowtype;
     one_row_unit up_org_unit%rowtype;
     one_inventory    t_inv_inventories%rowtype;
     v_one_temporyory t_inv_inventories%rowtype;
     v_sum_temp_1                    number;
     v_sum_temp_2                    number;
     v_sum_temp_3                    number;
     v_sum_temp_4                    number;
     v_sum_temp_5                    number;
     v_sum_temp_6                    number;
     v_sum_temp_7                    number;
     v_sum_temp_8                    number;
     v_sum_temp_9                    number;
     v_sum_temp_10                    number;
     v_sum_temp_11                    number;
     v_sum_temp_12                    number;
     v_sum_temp_1_2                    number;
     v_sum_temp_2_3                   number;
     v_sum_temp_3OVER                 number;
     v_inv_qty                        number;
     v_count_temp                     number;
     v_report_count                   number;
     type c_cursor is ref cursor;
     v_get c_cursor;
         cursor c_get is
               select nvl(a.qty_blnc, 0) + nvl(b.qty_sum, 0) sum_qty_blnc,
     bi.item_code,
     bi.item_name,
     bi.defaultunit,
      a.qty_blnc,
      a.item_id a_item_id,
      a.inventory_id a_inventory_id,
      b.qty_sum,
      b.item_id b_item_id,
      b.inventory_id b_inventory_id
  from (select m.qty_blnc, m.item_id, m.inventory_id
               from (select tim.ENDSUM qty_blnc,
               tim.item_id,
               tim.period_name,
               tim.inventory_id,
               tim.period_id
          from T_INV_TRANSMIT_RECEIVE tim
         where tim.inventory_id = invertory_id) m

         where m.period_name = v_isperiod_name_value) a,

       (select sum(tith.transaction_quantity) qty_sum,
               tith.item_id,
              tith.inventory_id
          from t_inv_transaction_history tith
         where tith.inventory_id = invertory_id
           and tith.creation_date >= add_months(to_date(v_isperiod_name_value,'yyyy-mm'),1)
           and tith.creation_date <= trunc(info_date)

         group by tith.item_id, tith.inventory_id ) b,
         t_bd_item  bi
 where a.item_id(+) = b.item_id
      and a.inventory_id(+) = b.inventory_id
      and b.item_id = bi.item_id;
    r_get c_get%rowtype;
     inv_code   varchar2(240);
   begin
     --delete from t_inv_check_info_temporyory;
     --delete from t_inv_check_info_linetemp;
     --delete from t_inv_check_split_linetemp;
     delete from T_INV_CHECK_INFO_LINETEMP;
     delete from t_inv_check_split_linetemp;
    -- delete from t_inv_check_split_BOOKTEMP;
         v_count_temp:=0;
         v_sum_temp_1:=0;
         v_sum_temp_2:=0;
         v_sum_temp_3:=0;
         v_sum_temp_4:=0;
         v_sum_temp_5:=0;
         v_sum_temp_6:=0;
         v_sum_temp_7:=0;
         v_sum_temp_8:=0;
         v_sum_temp_9:=0;
         v_sum_temp_10:=0;
         v_sum_temp_11:=0;
         v_sum_temp_12:=0;
         v_sum_temp_1_2:=0;
         v_sum_temp_2_3:=0;
         v_sum_temp_3OVER:=0;
         select t.inv_finance_code,t.info_date into inv_code,info_date from t_inv_check_info t where t.check_info_num=p_report_num;--根据报表编码查询该盘存仓库
         select count(*) into v_inv_qty from t_inv_statistic_inventories t where t.statistic_inventory_code=inv_code;--根据盘存仓库获取该仓库下挂了多少个仓库，用来计数
       for one_line in (select * from t_inv_statistic_inventories t where t.statistic_inventory_code=inv_code order by t.inventory_code ) loop --按统计仓库下挂了多少个子仓库进行循环
             select * into v_one_temporyory from t_inv_inventories t2 where t2.inventory_id=one_line.inventory_id;
       
           v_count_temp:=v_count_temp+1;--计数开始
           if v_count_temp=v_inv_qty then
                        select 1 into v_a from dual;

                        for one_check_split_temp in (select sum(t.kl_qty_1m) kl_qty_1m,
                                                           sum(t.kl_qty_2m) kl_qty_2m,
                                                           sum(t.kl_qty_3m) kl_qty_3m,
                                                           sum(t.kl_qty_4m) kl_qty_4m,
                                                           sum(t.kl_qty_5m) kl_qty_5m,
                                                           sum(t.kl_qty_6m) kl_qty_6m,
                                                           sum(t.kl_qty_7m) kl_qty_7m,
                                                           sum(t.kl_qty_8m) kl_qty_8m,
                                                           sum(t.kl_qty_9m) kl_qty_9m,
                                                           sum(t.kl_qty_10m) kl_qty_10m,
                                                           sum(t.kl_qty_11m) kl_qty_11m,
                                                           sum(t.kl_qty_12m) kl_qty_12m,
                                                           sum(t.kl_qty_1y_to_2y) kl_qty_1y_to_2y,
                                                           sum(t.kl_qty_2y_to_3y) kl_qty_2y_to_3y,
                                                           sum(t.kl_qty_3y_over) kl_qty_3y_over,
                                                          -- t.inv_id,
                                                         --  t.inv_name,
                                                         --  t.inv_code,
                                                           t.item_code,
                                                           t.item_desc,
                                                           t.uom


                                                      from t_inv_check_split_linetemp t
                                                     group by t.item_code, t.item_desc,t.uom) loop --从临时表里取数据汇总
                                              select * into one_row_line_split  --取现有报表该产品的行
                                                from t_inv_check_info_lines tl
                                                where tl.check_info_id =
                                                      (select t.check_info_id
                                                         from t_inv_check_info t
                                                         where t.check_info_num = p_report_num)
                                                      and tl.item_code=one_check_split_temp.item_code;
                                                  --    dbms_output.put_line(one_check_split_temp.item_code);
                                                      -------------------------
                                       insert into T_INV_CHECK_INFO_LINETEMP
                                                              (CHECK_INFO_LINE_ID,
                                                               ITEM_CODE,
                                                               ITEM_DESC,
                                                               UOM,
                                                               LOGISTICS_QTY,
                                                               REAL_QTY,
                                                               KL_QTY_1M,
                                                               KL_QTY_2M,
                                                               KL_QTY_3M,
                                                               KL_QTY_4M,
                                                               KL_QTY_5M,
                                                               KL_QTY_6M,
                                                               KL_QTY_7M,
                                                               KL_QTY_8M,
                                                               KL_QTY_9M,
                                                               KL_QTY_10M,
                                                               KL_QTY_11M,
                                                               KL_QTY_12M,
                                                               KL_QTY_1Y_TO_2Y,
                                                               KL_QTY_2Y_TO_3Y,
                                                               KL_QTY_3Y_OVER,
                                                               inv_id,
                                                               inv_code,
                                                               inv_name)
                                        select S_T_INV_CHECK_INFOLINESTEMP.NEXTVAL,
                                                       one_check_split_temp.item_code,
                                                       one_check_split_temp.item_desc,
                                                       one_check_split_temp.uom,
                                                       --总数减去其他仓库的汇总数插入最后临时表
                                                       (one_row_line_split.kl_qty_1m-one_check_split_temp.kl_qty_1m)+--物流盘存
                                                       (one_row_line_split.kl_qty_2m-one_check_split_temp.kl_qty_2m)+
                                                       (one_row_line_split.kl_qty_3m-one_check_split_temp.kl_qty_3m)+
                                                       (one_row_line_split.kl_qty_4m-one_check_split_temp.kl_qty_4m)+
                                                       (one_row_line_split.kl_qty_5m-one_check_split_temp.kl_qty_5m)+
                                                       (one_row_line_split.kl_qty_6m-one_check_split_temp.kl_qty_6m)+
                                                       (one_row_line_split.kl_qty_7m-one_check_split_temp.kl_qty_7m)+
                                                       (one_row_line_split.kl_qty_8m-one_check_split_temp.kl_qty_8m)+
                                                       (one_row_line_split.kl_qty_9m-one_check_split_temp.kl_qty_9m)+
                                                       (one_row_line_split.kl_qty_10m-one_check_split_temp.kl_qty_10m)+
                                                       (one_row_line_split.kl_qty_11m-one_check_split_temp.kl_qty_11m)+
                                                       (one_row_line_split.kl_qty_12m-one_check_split_temp.kl_qty_12m)+
                                                       (one_row_line_split.kl_qty_1y_to_2y-one_check_split_temp.kl_qty_1y_to_2y)+
                                                       (one_row_line_split.kl_qty_2y_to_3y-one_check_split_temp.kl_qty_2y_to_3y)+
                                                       (one_row_line_split.kl_qty_3y_over-one_check_split_temp.kl_qty_3y_over),
                                                       (one_row_line_split.kl_qty_1m-one_check_split_temp.kl_qty_1m)+--实盘
                                                       (one_row_line_split.kl_qty_2m-one_check_split_temp.kl_qty_2m)+
                                                       (one_row_line_split.kl_qty_3m-one_check_split_temp.kl_qty_3m)+
                                                       (one_row_line_split.kl_qty_4m-one_check_split_temp.kl_qty_4m)+
                                                       (one_row_line_split.kl_qty_5m-one_check_split_temp.kl_qty_5m)+
                                                       (one_row_line_split.kl_qty_6m-one_check_split_temp.kl_qty_6m)+
                                                       (one_row_line_split.kl_qty_7m-one_check_split_temp.kl_qty_7m)+
                                                       (one_row_line_split.kl_qty_8m-one_check_split_temp.kl_qty_8m)+
                                                       (one_row_line_split.kl_qty_9m-one_check_split_temp.kl_qty_9m)+
                                                       (one_row_line_split.kl_qty_10m-one_check_split_temp.kl_qty_10m)+
                                                       (one_row_line_split.kl_qty_11m-one_check_split_temp.kl_qty_11m)+
                                                       (one_row_line_split.kl_qty_12m-one_check_split_temp.kl_qty_12m)+
                                                       (one_row_line_split.kl_qty_1y_to_2y-one_check_split_temp.kl_qty_1y_to_2y)+
                                                       (one_row_line_split.kl_qty_2y_to_3y-one_check_split_temp.kl_qty_2y_to_3y)+
                                                       (one_row_line_split.kl_qty_3y_over-one_check_split_temp.kl_qty_3y_over),
                                                       one_row_line_split.kl_qty_1m-one_check_split_temp.kl_qty_1m,--各库龄
                                                       one_row_line_split.kl_qty_2m-one_check_split_temp.kl_qty_2m,
                                                       one_row_line_split.kl_qty_3m-one_check_split_temp.kl_qty_3m,
                                                       one_row_line_split.kl_qty_4m-one_check_split_temp.kl_qty_4m,
                                                       one_row_line_split.kl_qty_5m-one_check_split_temp.kl_qty_5m,
                                                       one_row_line_split.kl_qty_6m-one_check_split_temp.kl_qty_6m,
                                                       one_row_line_split.kl_qty_7m-one_check_split_temp.kl_qty_7m,
                                                       one_row_line_split.kl_qty_8m-one_check_split_temp.kl_qty_8m,
                                                       one_row_line_split.kl_qty_9m-one_check_split_temp.kl_qty_9m,
                                                       one_row_line_split.kl_qty_10m-one_check_split_temp.kl_qty_10m,
                                                       one_row_line_split.kl_qty_11m-one_check_split_temp.kl_qty_11m,
                                                       one_row_line_split.kl_qty_12m-one_check_split_temp.kl_qty_12m,
                                                       one_row_line_split.kl_qty_1y_to_2y-one_check_split_temp.kl_qty_1y_to_2y,
                                                       one_row_line_split.kl_qty_2y_to_3y-one_check_split_temp.kl_qty_2y_to_3y,
                                                       one_row_line_split.kl_qty_3y_over-one_check_split_temp.kl_qty_3y_over,
                                                       one_line.inventory_id,--最后一条仓库，所以此处仓库从仓库游标里取
                                                       one_line.inventory_code,
                                                       one_line.inventory_name
                                        from dual;




                        end loop;


           else
                                for one_check_line in (select * from t_inv_check_info_lines l
                                                                 where l.check_info_id in
                                                                       (select t.check_info_id
                                                                          from t_inv_check_info t
                                                                         where t.check_info_num = p_report_num)) loop
                                             begin

                                               select *
                                                 into one_row_line
                                                 from t_inv_check_split_BOOKTEMP tl
                                                where tl.check_num =p_report_num
                                                  and tl.item_code = one_check_line.item_code
                                                  and tl.inv_code=v_one_temporyory.inventory_code;--加仓库过滤，保证一条结果集
                                              exception
                                               when others then
                                                one_row_line.book_qty:=0;
                                                one_check_line.book_qty:=1;
                                                -- dbms_output.put_line('仓库：'||one_line.inventory_id||',编码：'||r_get.item_code);
                                               end;

                                               --
                                               if one_check_line.book_qty=0 /*and one_check_line.logistics_qty=0 and one_check_line.real_qty=0*/ then
                                                  one_check_line.book_qty:=1;--如果one_check_line.book_qty等于零，分两种情况，第一，在t_inv_check_split_BOOKTEMP
                                                  --里找不到数据，抛出异常，把one_row_line.book_qty赋值为零（分子），分母为1，第二，在t_inv_check_split_BOOKTEMP里能找到数据，因为本身账面数
                                                  --就为零，所以分子为零，把one_check_line.book_qty赋值为1（分母）
                                               end if;
                                               -- 如果行表里的数据账面数和物流盘存数和实盘数都为零，需要做判断，除数不能为零

                                                    insert into T_INV_CHECK_INFO_LINETEMP
                                                              (CHECK_INFO_LINE_ID,
                                                               ITEM_CODE,
                                                               ITEM_DESC,
                                                               UOM,
                                                               LOGISTICS_QTY,
                                                               REAL_QTY,
                                                               KL_QTY_1M,
                                                               KL_QTY_2M,
                                                               KL_QTY_3M,
                                                               KL_QTY_4M,
                                                               KL_QTY_5M,
                                                               KL_QTY_6M,
                                                               KL_QTY_7M,
                                                               KL_QTY_8M,
                                                               KL_QTY_9M,
                                                               KL_QTY_10M,
                                                               KL_QTY_11M,
                                                               KL_QTY_12M,
                                                               KL_QTY_1Y_TO_2Y,
                                                               KL_QTY_2Y_TO_3Y,
                                                               KL_QTY_3Y_OVER,
                                                               inv_id,
                                                               inv_code,
                                                               inv_name)
                                                select S_T_INV_CHECK_INFOLINESTEMP.NEXTVAL,
                                                       one_check_line.item_code,
                                                       one_check_line.item_desc,
                                                       one_check_line.uom,
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.kl_qty_1m,0) +--物流盘存
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.kl_qty_2m,0) +
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.kl_qty_3m,0) +
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.kl_qty_4m,0) +
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.kl_qty_5m,0) +
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.kl_qty_6m,0) +
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.kl_qty_7m,0) +
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.kl_qty_8m,0) +
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.kl_qty_9m,0) +
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.kl_qty_10m,0) +
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.kl_qty_11m,0) +
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.kl_qty_12m,0) +
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.KL_QTY_1Y_TO_2Y,0) +
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.KL_QTY_2Y_TO_3Y,0) +
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.KL_QTY_3Y_OVER,0),
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.kl_qty_1m,0) + --实盘
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.kl_qty_2m,0) +
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.kl_qty_3m,0) +
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.kl_qty_4m,0) +
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.kl_qty_5m,0) +
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.kl_qty_6m,0) +
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.kl_qty_7m,0) +
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.kl_qty_8m,0) +
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.kl_qty_9m,0) +
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.kl_qty_10m,0) +
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.kl_qty_11m,0) +
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.kl_qty_12m,0) +
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.KL_QTY_1Y_TO_2Y,0) +
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.KL_QTY_2Y_TO_3Y,0) +
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.KL_QTY_3Y_OVER,0),
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.kl_qty_1m,0) ,--各库龄
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.kl_qty_2m,0) ,
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.kl_qty_3m,0) ,
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.kl_qty_4m,0) ,
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.kl_qty_5m,0) ,
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.kl_qty_6m,0) ,
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.kl_qty_7m,0) ,
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.kl_qty_8m,0) ,
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.kl_qty_9m,0) ,
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.kl_qty_10m,0) ,
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.kl_qty_11m,0) ,
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.kl_qty_12m,0) ,
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.KL_QTY_1Y_TO_2Y,0) ,
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.KL_QTY_2Y_TO_3Y,0) ,
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.KL_QTY_3Y_OVER,0) ,
                                                       one_line.inventory_id,
                                                       one_line.inventory_code,
                                                       one_line.inventory_name
                                                 from dual;
                                                -- commit;

                                                 insert into t_inv_check_split_linetemp --汇总用
                                                              (CHECK_INFO_LINE_ID,
                                                               ITEM_CODE,
                                                               ITEM_DESC,
                                                               UOM,
                                                               LOGISTICS_QTY,
                                                               REAL_QTY,
                                                               KL_QTY_1M,
                                                               KL_QTY_2M,
                                                               KL_QTY_3M,
                                                               KL_QTY_4M,
                                                               KL_QTY_5M,
                                                               KL_QTY_6M,
                                                               KL_QTY_7M,
                                                               KL_QTY_8M,
                                                               KL_QTY_9M,
                                                               KL_QTY_10M,
                                                               KL_QTY_11M,
                                                               KL_QTY_12M,
                                                               KL_QTY_1Y_TO_2Y,
                                                               KL_QTY_2Y_TO_3Y,
                                                               KL_QTY_3Y_OVER,
                                                               inv_id,
                                                               inv_code,
                                                               inv_name)
                                                select s_inv_check_split_linetemp.NEXTVAL,
                                                       one_check_line.item_code,
                                                       one_check_line.item_desc,
                                                       one_check_line.uom,
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.kl_qty_1m,0) +--物流盘存
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.kl_qty_2m,0) +
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.kl_qty_3m,0) +
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.kl_qty_4m,0) +
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.kl_qty_5m,0) +
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.kl_qty_6m,0) +
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.kl_qty_7m,0) +
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.kl_qty_8m,0) +
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.kl_qty_9m,0) +
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.kl_qty_10m,0) +
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.kl_qty_11m,0) +
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.kl_qty_12m,0) +
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.KL_QTY_1Y_TO_2Y,0) +
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.KL_QTY_2Y_TO_3Y,0) +
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.KL_QTY_3Y_OVER,0),
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.kl_qty_1m,0) + --实盘
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.kl_qty_2m,0) +
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.kl_qty_3m,0) +
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.kl_qty_4m,0) +
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.kl_qty_5m,0) +
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.kl_qty_6m,0) +
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.kl_qty_7m,0) +
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.kl_qty_8m,0) +
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.kl_qty_9m,0) +
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.kl_qty_10m,0) +
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.kl_qty_11m,0) +
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.kl_qty_12m,0) +
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.KL_QTY_1Y_TO_2Y,0) +
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.KL_QTY_2Y_TO_3Y,0) +
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.KL_QTY_3Y_OVER,0),
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.kl_qty_1m,0) ,--各库龄
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.kl_qty_2m,0) ,
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.kl_qty_3m,0) ,
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.kl_qty_4m,0) ,
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.kl_qty_5m,0) ,
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.kl_qty_6m,0) ,
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.kl_qty_7m,0) ,
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.kl_qty_8m,0) ,
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.kl_qty_9m,0) ,
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.kl_qty_10m,0) ,
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.kl_qty_11m,0) ,
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.kl_qty_12m,0) ,
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.KL_QTY_1Y_TO_2Y,0) ,
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.KL_QTY_2Y_TO_3Y,0) ,
                                                       round(one_row_line.book_qty/one_check_line.book_qty*one_check_line.KL_QTY_3Y_OVER,0) ,
                                                       one_line.inventory_id,
                                                       one_line.inventory_code,
                                                       one_line.inventory_name
                                                 from dual;
                                    end loop;





           end if;


        end loop;


       --拆分头行表
         v_report_count:=0;
         for one_row_split_temp_inv in (select distinct t.inv_id, t.inv_code, t.inv_name --账面数和实盘数表合并（游标使用，计算仓库个数）
                                         from (select nvl(ory.inv_id, tem.inv_id) inv_id,
                                               nvl(ory.inv_code, tem.inv_code) inv_code,
                                               nvl(ory.inv_name, tem.inv_name) inv_name,
                                               nvl(ory.item_code, tem.item_code) item_code,
                                               nvl(ory.item_desc, tem.item_desc) item_desc,
                                               nvl(ory.uom, tem.uom) uom,
                                               nvl(ory.book_qty, 0) book_qty,
                                               nvl(tem.logistics_qty, 0) logistics_qty,
                                               nvl(tem.real_qty, 0) real_qty,
                                               nvl(tem.kl_qty_1m, 0) kl_qty_1m,
                                               nvl(tem.kl_qty_2m, 0) kl_qty_2m,
                                               nvl(tem.kl_qty_3m, 0) kl_qty_3m,
                                               nvl(tem.kl_qty_4m, 0) kl_qty_4m,
                                               nvl(tem.kl_qty_5m, 0) kl_qty_5m,
                                               nvl(tem.kl_qty_6m, 0) kl_qty_6m,
                                               nvl(tem.kl_qty_7m, 0) kl_qty_7m,
                                               nvl(tem.kl_qty_8m, 0) kl_qty_8m,
                                               nvl(tem.kl_qty_9m, 0) kl_qty_9m,
                                               nvl(tem.kl_qty_10m, 0) kl_qty_10m,
                                               nvl(tem.kl_qty_11m, 0) kl_qty_11m,
                                               nvl(tem.kl_qty_12m, 0) kl_qty_12m,
                                               nvl(tem.kl_qty_1y_to_2y, 0) kl_qty_1y_to_2y,
                                               nvl(tem.kl_qty_2y_to_3y, 0) kl_qty_2y_to_3y,
                                               nvl(tem.kl_qty_3y_over, 0) kl_qty_3y_over
                                          from (select * from t_inv_check_split_BOOKTEMP t where t.check_num=p_report_num) ory
                                          full join t_inv_check_info_linetemp tem
                                            on ory.item_code = tem.item_code
                                           and ory.inv_id = tem.inv_id
                                           and ory.inv_code = tem.inv_code
                                           and ory.inv_name = tem.inv_name) t order by t.inv_code) loop
           v_report_count:=v_report_count+1;
           select S_INV_CHECK_INFO.Nextval into v_s_inv_check_info from dual;
             select * into one_row_unit from up_org_unit u where u.unit_id=(select t.unit_id from t_inv_inventories t where t.inventory_code=one_row_split_temp_inv.inv_code);
             insert into t_inv_check_info
                             (CHECK_INFO_ID,
                              ENTITY_ID,
                              CHECK_INFO_NUM,
                              SALES_CENTER_ID,
                              INV_FINANCE_ID,
                              INV_FINANCE_CODE,
                              INV_FINANCE_NAME,
                              INFO_DATE,
                              REMARK,
                              CREATED_BY,
                              CREATION_DATE,
                              LAST_UPDATED_BY,
                              LAST_UPDATE_DATE,
                              SALES_CENTER_CODE,
                              SALES_CENTER_NAME
                              )
                              values
                              (v_s_inv_check_info,
                               p_entity_id,
                               p_report_num||'-'||v_report_count,
                               one_row_unit.unit_id,
                               one_row_split_temp_inv.inv_id,
                               one_row_split_temp_inv.inv_code,
                               one_row_split_temp_inv.inv_name,
                               info_date,
                               '',
                               p_user,
                               sysdate,
                               p_user,
                               sysdate,
                               one_row_unit.code,
                               one_row_unit.name);
                    for one_row_split_temp_item in ( select *
                                                    from (select nvl(ory.inv_id, tem.inv_id) inv_id,   --账面数和实盘数表合并（游标使用，计算产品个数）
                                                                 nvl(ory.inv_code, tem.inv_code) inv_code,
                                                                 nvl(ory.inv_name, tem.inv_name) inv_name,
                                                                 nvl(ory.item_code, tem.item_code) item_code,
                                                                 nvl(ory.item_desc, tem.item_desc) item_desc,
                                                                 nvl(ory.uom, tem.uom) uom,
                                                                 nvl(ory.book_qty, 0) book_qty,
                                                                 nvl(tem.logistics_qty, 0) logistics_qty,
                                                                 nvl(tem.real_qty, 0) real_qty,
                                                                 nvl(tem.kl_qty_1m, 0) kl_qty_1m,
                                                                 nvl(tem.kl_qty_2m, 0) kl_qty_2m,
                                                                 nvl(tem.kl_qty_3m, 0) kl_qty_3m,
                                                                 nvl(tem.kl_qty_4m, 0) kl_qty_4m,
                                                                 nvl(tem.kl_qty_5m, 0) kl_qty_5m,
                                                                 nvl(tem.kl_qty_6m, 0) kl_qty_6m,
                                                                 nvl(tem.kl_qty_7m, 0) kl_qty_7m,
                                                                 nvl(tem.kl_qty_8m, 0) kl_qty_8m,
                                                                 nvl(tem.kl_qty_9m, 0) kl_qty_9m,
                                                                 nvl(tem.kl_qty_10m, 0) kl_qty_10m,
                                                                 nvl(tem.kl_qty_11m, 0) kl_qty_11m,
                                                                 nvl(tem.kl_qty_12m, 0) kl_qty_12m,
                                                                 nvl(tem.kl_qty_1y_to_2y, 0) kl_qty_1y_to_2y,
                                                                 nvl(tem.kl_qty_2y_to_3y, 0) kl_qty_2y_to_3y,
                                                                 nvl(tem.kl_qty_3y_over, 0) kl_qty_3y_over
                                                            from (select * from t_inv_check_split_BOOKTEMP t where t.check_num=p_report_num) ory
                                                            full join t_inv_check_info_linetemp tem
                                                              on ory.item_code = tem.item_code
                                                             and ory.inv_id = tem.inv_id
                                                             and ory.inv_code = tem.inv_code
                                                             and ory.inv_name = tem.inv_name) t
                                                   where t.inv_code = one_row_split_temp_inv.inv_code) loop
                        insert into t_inv_check_info_lines
                                    (CHECK_INFO_LINE_ID,
                                     CHECK_INFO_ID,
                                     ENTITY_ID,
                                     ITEM_CODE,
                                     ITEM_DESC,
                                     UOM,
                                     BOOK_QTY,
                                     LOGISTICS_QTY,
                                     REAL_QTY,
                                     REV_NO_QTY,
                                     KL_QTY_1M,
                                     KL_QTY_2M,
                                     KL_QTY_3M,
                                     KL_QTY_4M,
                                     KL_QTY_5M,
                                     KL_QTY_6M,
                                     KL_QTY_7M,
                                     KL_QTY_8M,
                                     KL_QTY_9M,
                                     KL_QTY_10M,
                                     KL_QTY_11M,
                                     KL_QTY_12M,
                                     KL_QTY_1Y_TO_2Y,
                                     KL_QTY_2Y_TO_3Y,
                                     KL_QTY_3Y_OVER,
                                     CREATED_BY,
                                     CREATION_DATE,
                                     LAST_UPDATED_BY,
                                     LAST_UPDATE_DATE
                                    ) values
                                           (S_INV_CHECK_INFO_LINES.NEXTVAL,
                                            v_s_inv_check_info,
                                            p_entity_id,
                                            one_row_split_temp_item.item_code,
                                            one_row_split_temp_item.item_desc,
                                            one_row_split_temp_item.uom,
                                            one_row_split_temp_item.book_qty,
                                            one_row_split_temp_item.logistics_qty,
                                            one_row_split_temp_item.real_qty,
                                            0,
                                            one_row_split_temp_item.kl_qty_1m,
                                            one_row_split_temp_item.kl_qty_2m,
                                            one_row_split_temp_item.kl_qty_3m,
                                            one_row_split_temp_item.kl_qty_4m,
                                            one_row_split_temp_item.kl_qty_5m,
                                            one_row_split_temp_item.kl_qty_6m,
                                            one_row_split_temp_item.kl_qty_7m,
                                            one_row_split_temp_item.kl_qty_8m,
                                            one_row_split_temp_item.kl_qty_9m,
                                            one_row_split_temp_item.kl_qty_10m,
                                            one_row_split_temp_item.kl_qty_11m,
                                            one_row_split_temp_item.kl_qty_12m,
                                            one_row_split_temp_item.kl_qty_1y_to_2y,
                                            one_row_split_temp_item.kl_qty_2y_to_3y,
                                            one_row_split_temp_item.kl_qty_3y_over,
                                            p_user,
                                            trunc(sysdate),
                                            p_user,
                                            trunc(sysdate)
                                           );
                    end loop;
         end loop;
         begin
           loop
             if v_report_count>0 then
                delete from t_inv_check_info_lines t1
                 where t1.check_info_id =
                       (select t.check_info_id
                          from t_inv_check_info t
                         where t.check_info_num =
                               p_report_num || '-' || v_report_count)
                   and t1.book_qty = 0
                   and t1.logistics_qty = 0
                   and t1.real_qty = 0;

                  update t_inv_check_info_lines ticil
                     set ticil.book_differences_qty = nvl(ticil.book_qty, 0) -
                                                      nvl(ticil.logistics_qty,0)
                   where ticil.check_info_id =
                         (select t.check_info_id
                            from t_inv_check_info t
                           where t.check_info_num =
                                 p_report_num || '-' || v_report_count);
                  update t_inv_check_info_lines ticil
                     set ticil.book_real_differences_qty = nvl(ticil.book_qty,
                                                               0) -
                                                           nvl(ticil.real_qty,0)
                   where ticil.check_info_id =
                         (select t.check_info_id
                            from t_inv_check_info t
                           where t.check_info_num =
                                 p_report_num || '-' || v_report_count);

                   v_report_count:=v_report_count-1;
             else
             exit;
             end if;
           end loop;
         end;

         begin
                    PKG_INV_INVENTORY.INVENTORY_CHANGE_DIFF(p_report_num);
         exception
           when others then
             rollback;
             p_exception :='自动调整差异算法出错，相关代码：'||sqlerrm;
             return;
         end;

         p_exception:='seuccess';

   end;



  --***********************************
  -- AUTHOR: 顾金兴
  -- LAST_UPDATE_BY:顾金兴
  -- LAST_UPDATE：2015-5-2
  -- PURPOSE:盘存报表把账面数插入临时表做拆分使用
  --***********************************



    Procedure INVENTORY_SPLIT_INSERT_TEMP(   p_entityId     in number,
                                             p_report_num   in varchar2,
                                             P_INVENTORY_ID IN NUMBER,
                                             P_INFO_DATE    IN DATE,
                                             P_exception    OUT VARCHAR2
                                             ) IS
      v_one_temporyory     t_inv_inventories%ROWTYPE;
      v_isperiod_name             varchar(240);
      v_isperiod_name_value       varchar(240);
      v_sql                       varchar(4000);
      n_info_date                 NUMBER;
       type c_cursor is ref cursor;
       v_get c_cursor;
        cursor c_get is
               select nvl(a.qty_blnc, 0) + nvl(b.qty_sum, 0) sum_qty_blnc,
     bi.item_code,
     bi.item_name,
     bi.defaultunit,
      a.qty_blnc,
      a.item_id a_item_id,
      a.inventory_id a_inventory_id,
      b.qty_sum,
      b.item_id b_item_id,
      b.inventory_id b_inventory_id
  from (select m.qty_blnc, m.item_id, m.inventory_id
               from (select tim.ENDSUM qty_blnc,
               tim.item_id,
               tim.period_name,
               tim.inventory_id,
               tim.period_id
          from T_INV_TRANSMIT_RECEIVE tim
         where tim.inventory_id = P_INVENTORY_ID) m

         where m.period_name = v_isperiod_name_value) a,

       (select sum(tith.transaction_quantity) qty_sum,
               tith.item_id,
              tith.inventory_id
          from t_inv_transaction_history tith
         where tith.inventory_id = P_INVENTORY_ID
           and tith.creation_date >= add_months(to_date(v_isperiod_name_value,'yyyy-mm'),1)
           and tith.creation_date <= trunc(P_INFO_DATE)

         group by tith.item_id, tith.inventory_id ) b,
         t_bd_item  bi
 where a.item_id(+) = b.item_id
      and a.inventory_id(+) = b.inventory_id
      and b.item_id = bi.item_id;
      r_get c_get%rowtype;
    BEGIN
       for row_one in (select * from t_inv_statistic_inventories t where t.statistic_inventory_id=P_INVENTORY_ID ) loop
        select * into v_one_temporyory from t_inv_inventories t2 where t2.inventory_id=row_one.inventory_id;
            select count(1) into v_isperiod_name from t_inv_inventory_periods p where P_INFO_DATE between p.begin_date and p.end_date and p.checkout_flag='01' and p.entity_id=p_entityId;--5月2日修改（增加主体过滤条件）

           if v_isperiod_name =0 then
             select to_char(max(p1.end_date), 'yyyy-mm') end_date into v_isperiod_name_value
                                         from t_inv_inventory_periods p1
                                         where p1.end_date < P_INFO_DATE
                                         and p1.checkout_flag = '01'
                                         and p1.entity_id=p_entityId;--5月2日修改（增加主体过滤条件）

--              v_isperiod_name_value:=v_isperiod_name;
           else
    select p.period_name into v_isperiod_name_value from t_inv_inventory_periods p where P_INFO_DATE between p.begin_date and p.end_date and p.checkout_flag='01' and p.entity_id=p_entityId;--5月2日修改（增加主体过滤条件）

           end if;

    v_sql := 'select tab.sum_qty_blnc,
     bi.item_code,
     bi.item_name,
     bi.defaultunit,
     tab.qty_blnc,
        tab.a_item_id,
         tab.a_inventory_id,
          tab.qty_sum,
         tab.b_item_id,
        tab.b_inventory_id

           from (
                  select nvl(a.qty_blnc, 0) + nvl(b.qty_sum, 0) sum_qty_blnc,

                        a.qty_blnc,
                        a.item_id a_item_id,
                        a.inventory_id a_inventory_id,
                        b.qty_sum,
                        b.item_id b_item_id,
                        b.inventory_id b_inventory_id
                    from (select m.qty_blnc, m.item_id, m.inventory_id
                                 from (select tim.ENDSUM qty_blnc,
                                 tim.item_id,
                                 tim.period_name,
                                 tim.inventory_id,
                                 tim.period_id
                            from cims.T_INV_TRANSMIT_RECEIVE tim
                           where tim.inventory_id ='||row_one.inventory_id||'
                            and  tim.entity_id='||p_entityId||') m

                           where m.period_name =  '''||v_isperiod_name_value||''') a
                           full join

                         (select sum(tith.transaction_quantity) qty_sum,
                                 tith.item_id,
                                tith.inventory_id
                            from cims.t_inv_transaction_history tith
                           where tith.inventory_id = '||row_one.inventory_id||'
                             and tith.entity_id='||p_entityId||'
                             and trunc(tith.transaction_date) >= '''||trunc(add_months(to_date(v_isperiod_name_value,'yyyy-mm'),1))||'''
                             and trunc(tith.transaction_date) <= '''||trunc(P_INFO_DATE)||'''

                           group by tith.item_id, tith.inventory_id ) b
                        on a.item_id = b.item_id
                        and a.inventory_id = b.inventory_id
      ) tab ,cims.t_bd_item  bi

      where nvl(tab.a_item_id,tab.b_item_id)=bi.item_id';


      select P_INFO_DATE - trunc(sysdate) into n_info_date from dual;
                     if n_info_date < 0 then

                                 begin
                                        open v_get for v_sql;
                                 exception
                                         --when no_data_found then
                                       --  null;
                                       --  rollback;
                                 when others then
                                         rollback;
                                          P_exception :='结存日期为：'||P_INFO_DATE||'，取IMS结存数量时，游标出错!'||sqlerrm;
                                         return;
                                 end;

                               loop

                                        fetch v_get
                                         into r_get;
                                        -- If v_get%Rowcount = 0 Then
                                         --     rollback;
                                        --       v_exception :='根据录入的盘存日期和财务仓，IMS系统找不到对应的产品!';
                                         --       return;
                                         --End If;

                                         exit when v_get%notfound;
                                            /*  dbms_output.put_line(' 编码为： ' || r_get.item_code || ' 名称为： ' ||
                                               r_get.item_name || ' 单位：' ||
                                               r_get.defaultunit || ' 结存：' ||
                                               r_get.sum_qty_blnc);
                                               */


                                  begin
                                                  insert into t_inv_check_split_BOOKTEMP
                                                                       (CHECK_INFO_LINE_ID, ITEM_CODE, ITEM_DESC,UOM,BOOK_QTY,inv_id,inv_code,inv_name,check_num)
                                                                       values
                                                                        (S_INV_CHECK_INFO_BOOKTEMP.nextval,
                                                                         r_get.item_code,
                                                                         r_get.item_name,
                                                                         r_get.defaultunit,
                                                                         r_get.sum_qty_blnc,
                                                                         v_one_temporyory.inventory_id,
                                                                         v_one_temporyory.inventory_code,
                                                                         v_one_temporyory.inventory_name,
                                                                         p_report_num);
                                    exception
                                      when others then
                                       rollback;
                                       P_exception :='结存日期为：'||P_INFO_DATE||'，取IMS结存数量，插入t_inv_check_split_BOOKTEMP有误!'||sqlerrm;
                                       return;
                                  end;


                              end loop;
                              close v_get;
                     ELSE
                                               begin
                                                 insert into t_inv_check_split_BOOKTEMP
                                                   (CHECK_INFO_LINE_ID,
                                                    ITEM_ID,
                                                    ITEM_CODE,
                                                    ITEM_DESC,
                                                    UOM,
                                                    BOOK_QTY,
                                                    INV_ID,
                                                    INV_CODE,
                                                    INV_NAME,
                                                    CHECK_NUM)
                                                   select s_t_inv_check_info_temporary.nextval,
                                                          a2.*,
                                                          v_one_temporyory.inventory_id,
                                                          v_one_temporyory.inventory_code,
                                                          v_one_temporyory.inventory_name,
                                                          p_report_num
                                                     from (select t1.item_id,
                                                                  t2.item_code,
                                                                  t2.item_name,
                                                                  t2.defaultunit,
                                                                  sum(t1.quantity)
                                                             from t_inv_onhand t1, t_bd_item t2
                                                            where t1.item_id = t2.item_id
                                                              and t1.inventory_id = row_one.inventory_id
                                                            group by t1.item_id,
                                                                     t2.item_code,
                                                                     t2.item_name,
                                                                     t2.defaultunit) a2;
                                               exception
                                                 when others then
                                                   rollback;
                                                   P_exception := '结存日期为：' || P_INFO_DATE ||
                                                                  '，取IMS库存现有量，插入T_INV_CHECK_INFO_TEMPORYORY有误!'||sqlerrm;
                                                   return;
                                               end;


                     END IF;
       END LOOP;
       P_exception:='seuccess';
    END;

Procedure INVENTORY_CHANGE_DIFF(S_CHECK_INFO_NUM_SUM IN VARCHAR2) is
  N_CNT NUMBER;
  N_INDEX NUMBER;
  N_QTY NUMBER;
  N_MAX_QTY NUMBER;
  N_MAX_INDEX NUMBER;
  N_DIFF_QTY NUMBER;
  N_LAST_DIFF_QTY NUMBER;
  BEGIN
  --检查汇总报表的财务仓与物流仓总数是否一致
  SELECT
    COUNT(*)
  INTO
    N_CNT
  FROM
    T_INV_CHECK_INFO I
    ,T_INV_CHECK_INFO_LINES L
  WHERE
    I.CHECK_INFO_ID = L.CHECK_INFO_ID
    AND I.CHECK_INFO_NUM = S_CHECK_INFO_NUM_SUM
    AND NVL(L.BOOK_QTY,0) <> NVL(L.LOGISTICS_QTY,0);
 
  --数量一致，则检查拆分报表的财务仓与物流仓总数是否一致
  IF N_CNT = 0 THEN
    SELECT
      COUNT(*)
    INTO
      N_CNT
    FROM
      T_INV_CHECK_INFO I
      ,T_INV_CHECK_INFO_LINES L
    WHERE
      I.CHECK_INFO_ID = L.CHECK_INFO_ID
      AND I.CHECK_INFO_NUM LIKE S_CHECK_INFO_NUM_SUM || '-%'
      AND NVL(L.BOOK_QTY,0) <> NVL(L.LOGISTICS_QTY,0);

    --存在差异，则循环物流仓多的内容
    IF N_CNT > 0 THEN
      FOR R_MORE IN
      (
        SELECT
          L.CHECK_INFO_LINE_ID
          ,L.ITEM_CODE
          ,NVL(L.LOGISTICS_QTY,0)-NVL(L.BOOK_QTY,0) DIFF_QTY
          ,L.KL_QTY_1M
          ,L.KL_QTY_2M
          ,L.KL_QTY_3M
          ,L.KL_QTY_4M
          ,L.KL_QTY_5M
          ,L.KL_QTY_6M
          ,L.KL_QTY_7M
          ,L.KL_QTY_8M
          ,L.KL_QTY_9M
          ,L.KL_QTY_10M
          ,L.KL_QTY_11M
          ,L.KL_QTY_12M
        FROM
          T_INV_CHECK_INFO I
          ,T_INV_CHECK_INFO_LINES L
        WHERE
          I.CHECK_INFO_ID = L.CHECK_INFO_ID
          AND I.CHECK_INFO_NUM LIKE S_CHECK_INFO_NUM_SUM || '-%'
          AND NVL(L.BOOK_QTY,0) < NVL(L.LOGISTICS_QTY,0)
      )
      LOOP
        --找库龄段最大的值、字段
        N_MAX_QTY := 0;
        FOR I IN 1..12 LOOP
          SELECT
            CASE
              WHEN I = 1 THEN R_MORE.KL_QTY_1M
              WHEN I = 2 THEN R_MORE.KL_QTY_2M
              WHEN I = 3 THEN R_MORE.KL_QTY_3M
              WHEN I = 4 THEN R_MORE.KL_QTY_4M
              WHEN I = 5 THEN R_MORE.KL_QTY_5M
              WHEN I = 6 THEN R_MORE.KL_QTY_6M
              WHEN I = 7 THEN R_MORE.KL_QTY_7M
              WHEN I = 8 THEN R_MORE.KL_QTY_8M
              WHEN I = 9 THEN R_MORE.KL_QTY_9M
              WHEN I = 10 THEN R_MORE.KL_QTY_10M
              WHEN I = 11 THEN R_MORE.KL_QTY_11M
              ELSE R_MORE.KL_QTY_12M
            END
          INTO
            N_QTY
          FROM
            DUAL;
          IF N_QTY > N_MAX_QTY THEN
            N_MAX_QTY := N_QTY;
            N_MAX_INDEX := I;
          END IF;
        END LOOP;
        N_LAST_DIFF_QTY := R_MORE.DIFF_QTY;
        --找对应差异为正数的内容
        FOR R_LESS IN
        (
          SELECT
            L.CHECK_INFO_LINE_ID
            ,NVL(L.BOOK_QTY,0)-NVL(L.LOGISTICS_QTY,0) DIFF_QTY
          FROM
            T_INV_CHECK_INFO I
            ,T_INV_CHECK_INFO_LINES L
          WHERE
            I.CHECK_INFO_ID = L.CHECK_INFO_ID
            AND L.ITEM_CODE = R_MORE.ITEM_CODE
            AND I.CHECK_INFO_NUM LIKE S_CHECK_INFO_NUM_SUM || '-%'
            AND NVL(L.BOOK_QTY,0) > NVL(L.LOGISTICS_QTY,0)
        )
        LOOP
          --取要更新的差异数量
          IF R_LESS.DIFF_QTY > N_LAST_DIFF_QTY THEN
            N_DIFF_QTY := N_LAST_DIFF_QTY;
          ELSE
            N_DIFF_QTY := R_LESS.DIFF_QTY;
          END IF;
          --更新差异(物流仓少)
          IF N_MAX_INDEX = 1 THEN
            UPDATE T_INV_CHECK_INFO_LINES
            SET KL_QTY_1M = KL_QTY_1M + N_DIFF_QTY
            WHERE CHECK_INFO_LINE_ID = R_LESS.CHECK_INFO_LINE_ID;
          ELSIF N_MAX_INDEX = 2 THEN
            UPDATE T_INV_CHECK_INFO_LINES
            SET KL_QTY_2M = KL_QTY_2M + N_DIFF_QTY
            WHERE CHECK_INFO_LINE_ID = R_LESS.CHECK_INFO_LINE_ID;
          ELSIF N_MAX_INDEX = 3 THEN
            UPDATE T_INV_CHECK_INFO_LINES
            SET KL_QTY_3M = KL_QTY_3M + N_DIFF_QTY
            WHERE CHECK_INFO_LINE_ID = R_LESS.CHECK_INFO_LINE_ID;
          ELSIF N_MAX_INDEX = 4 THEN
            UPDATE T_INV_CHECK_INFO_LINES
            SET KL_QTY_4M = KL_QTY_4M + N_DIFF_QTY
            WHERE CHECK_INFO_LINE_ID = R_LESS.CHECK_INFO_LINE_ID;
          ELSIF N_MAX_INDEX = 5 THEN
            UPDATE T_INV_CHECK_INFO_LINES
            SET KL_QTY_5M = KL_QTY_5M + N_DIFF_QTY
            WHERE CHECK_INFO_LINE_ID = R_LESS.CHECK_INFO_LINE_ID;
          ELSIF N_MAX_INDEX = 6 THEN
            UPDATE T_INV_CHECK_INFO_LINES
            SET KL_QTY_6M = KL_QTY_6M + N_DIFF_QTY
            WHERE CHECK_INFO_LINE_ID = R_LESS.CHECK_INFO_LINE_ID;
          ELSIF N_MAX_INDEX = 7 THEN
            UPDATE T_INV_CHECK_INFO_LINES
            SET KL_QTY_7M = KL_QTY_7M + N_DIFF_QTY
            WHERE CHECK_INFO_LINE_ID = R_LESS.CHECK_INFO_LINE_ID;
          ELSIF N_MAX_INDEX = 8 THEN
            UPDATE T_INV_CHECK_INFO_LINES
            SET KL_QTY_8M = KL_QTY_8M + N_DIFF_QTY
            WHERE CHECK_INFO_LINE_ID = R_LESS.CHECK_INFO_LINE_ID;
          ELSIF N_MAX_INDEX = 9 THEN
            UPDATE T_INV_CHECK_INFO_LINES
            SET KL_QTY_9M = KL_QTY_9M + N_DIFF_QTY
            WHERE CHECK_INFO_LINE_ID = R_LESS.CHECK_INFO_LINE_ID;
          ELSIF N_MAX_INDEX = 10 THEN
            UPDATE T_INV_CHECK_INFO_LINES
            SET KL_QTY_10M = KL_QTY_10M + N_DIFF_QTY
            WHERE CHECK_INFO_LINE_ID = R_LESS.CHECK_INFO_LINE_ID;
          ELSIF N_MAX_INDEX = 11 THEN
            UPDATE T_INV_CHECK_INFO_LINES
            SET KL_QTY_11M = KL_QTY_11M + N_DIFF_QTY
            WHERE CHECK_INFO_LINE_ID = R_LESS.CHECK_INFO_LINE_ID;
          ELSE
            UPDATE T_INV_CHECK_INFO_LINES
            SET KL_QTY_12M = KL_QTY_12M + N_DIFF_QTY
            WHERE CHECK_INFO_LINE_ID = R_LESS.CHECK_INFO_LINE_ID;
          END IF;
          --更新物流仓总数等
          UPDATE
            T_INV_CHECK_INFO_LINES
          SET
            LOGISTICS_QTY = LOGISTICS_QTY + N_DIFF_QTY
            ,REAL_QTY = REAL_QTY + N_DIFF_QTY
            ,BOOK_DIFFERENCES_QTY = BOOK_DIFFERENCES_QTY - N_DIFF_QTY
            ,BOOK_REAL_DIFFERENCES_QTY = BOOK_REAL_DIFFERENCES_QTY - N_DIFF_QTY
          WHERE
            CHECK_INFO_LINE_ID = R_LESS.CHECK_INFO_LINE_ID;
          --处理完则退出循环
          N_LAST_DIFF_QTY := N_LAST_DIFF_QTY - N_DIFF_QTY;
          IF N_LAST_DIFF_QTY = 0 THEN
            EXIT;
          END IF;
        END LOOP;
        --更新差异（物流仓多）
        IF N_MAX_INDEX = 1 THEN
          UPDATE T_INV_CHECK_INFO_LINES
          SET KL_QTY_1M = KL_QTY_1M - R_MORE.DIFF_QTY
          WHERE CHECK_INFO_LINE_ID = R_MORE.CHECK_INFO_LINE_ID;
        ELSIF N_MAX_INDEX = 2 THEN
          UPDATE T_INV_CHECK_INFO_LINES
          SET KL_QTY_2M = KL_QTY_2M - R_MORE.DIFF_QTY
          WHERE CHECK_INFO_LINE_ID = R_MORE.CHECK_INFO_LINE_ID;
        ELSIF N_MAX_INDEX = 3 THEN
          UPDATE T_INV_CHECK_INFO_LINES
          SET KL_QTY_3M = KL_QTY_3M - R_MORE.DIFF_QTY
          WHERE CHECK_INFO_LINE_ID = R_MORE.CHECK_INFO_LINE_ID;
        ELSIF N_MAX_INDEX = 4 THEN
          UPDATE T_INV_CHECK_INFO_LINES
          SET KL_QTY_4M = KL_QTY_4M - R_MORE.DIFF_QTY
          WHERE CHECK_INFO_LINE_ID = R_MORE.CHECK_INFO_LINE_ID;
        ELSIF N_MAX_INDEX = 5 THEN
          UPDATE T_INV_CHECK_INFO_LINES
          SET KL_QTY_5M = KL_QTY_5M - R_MORE.DIFF_QTY
          WHERE CHECK_INFO_LINE_ID = R_MORE.CHECK_INFO_LINE_ID;
        ELSIF N_MAX_INDEX = 6 THEN
          UPDATE T_INV_CHECK_INFO_LINES
          SET KL_QTY_6M = KL_QTY_6M - R_MORE.DIFF_QTY
          WHERE CHECK_INFO_LINE_ID = R_MORE.CHECK_INFO_LINE_ID;
        ELSIF N_MAX_INDEX = 7 THEN
          UPDATE T_INV_CHECK_INFO_LINES
          SET KL_QTY_7M = KL_QTY_7M - R_MORE.DIFF_QTY
          WHERE CHECK_INFO_LINE_ID = R_MORE.CHECK_INFO_LINE_ID;
        ELSIF N_MAX_INDEX = 8 THEN
          UPDATE T_INV_CHECK_INFO_LINES
          SET KL_QTY_8M = KL_QTY_8M - R_MORE.DIFF_QTY
          WHERE CHECK_INFO_LINE_ID = R_MORE.CHECK_INFO_LINE_ID;
        ELSIF N_MAX_INDEX = 9 THEN
          UPDATE T_INV_CHECK_INFO_LINES
          SET KL_QTY_9M = KL_QTY_9M - R_MORE.DIFF_QTY
          WHERE CHECK_INFO_LINE_ID = R_MORE.CHECK_INFO_LINE_ID;
        ELSIF N_MAX_INDEX = 10 THEN
          UPDATE T_INV_CHECK_INFO_LINES
          SET KL_QTY_10M = KL_QTY_10M - R_MORE.DIFF_QTY
          WHERE CHECK_INFO_LINE_ID = R_MORE.CHECK_INFO_LINE_ID;
        ELSIF N_MAX_INDEX = 11 THEN
          UPDATE T_INV_CHECK_INFO_LINES
          SET KL_QTY_11M = KL_QTY_11M - R_MORE.DIFF_QTY
          WHERE CHECK_INFO_LINE_ID = R_MORE.CHECK_INFO_LINE_ID;
        ELSE
          UPDATE T_INV_CHECK_INFO_LINES
          SET KL_QTY_12M = KL_QTY_12M - R_MORE.DIFF_QTY
          WHERE CHECK_INFO_LINE_ID = R_MORE.CHECK_INFO_LINE_ID;
        END IF;
        --更新物流仓总数等
        UPDATE
          T_INV_CHECK_INFO_LINES
        SET
          LOGISTICS_QTY = LOGISTICS_QTY - R_MORE.DIFF_QTY
          ,REAL_QTY = REAL_QTY - R_MORE.DIFF_QTY
          ,BOOK_DIFFERENCES_QTY = BOOK_DIFFERENCES_QTY + R_MORE.DIFF_QTY
          ,BOOK_REAL_DIFFERENCES_QTY = BOOK_REAL_DIFFERENCES_QTY + R_MORE.DIFF_QTY
        WHERE
          CHECK_INFO_LINE_ID = R_MORE.CHECK_INFO_LINE_ID;
      END LOOP;
    END IF;
  END IF;
END;
end PKG_INV_INVENTORY;
/

