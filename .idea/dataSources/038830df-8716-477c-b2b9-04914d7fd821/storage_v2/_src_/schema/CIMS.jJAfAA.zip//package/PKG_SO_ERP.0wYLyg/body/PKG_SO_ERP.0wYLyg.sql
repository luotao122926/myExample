create PACKAGE BODY      PKG_SO_ERP IS
  /*----------------------------------------------------------------
  *         包：PKG_SO_ERP
  *   创建日期：2014-08-16
  *     创建者：廖丽章
  *   功能说明：1、销售单据结算触发相关业务处理。
  *
  *   过程成功：P_RESULT = 0
  *             P_ERR_MSG = 'SUCCESS';
  *
  *   过程失败：P_RESULT < -20000;
  *             P_ERR_MSG = 过程异常失败的提示信息
  *
  */ ----------------------------------------------------------------

  --V_DATA_FORMAT CONSTANT VARCHAR2(10) := 'YYYY-MM-DD'; --日期格式
  V_FLAG_AUDIT  CONSTANT CHAR(1) := 'A'; --A审核对账
  V_FLAG_SETTLE CONSTANT CHAR(1) := 'S'; --S结算对账

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-08-16
  *     创建者：廖丽章
  *   功能说明：回写ERP AR发票信息到财务单
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_UPDATE_SO_ARINVOICE(
                                  P_ENTITY_ID IN NUMBER,
                                  P_EXPIRY_DATE IN VARCHAR2,
                                  P_RESULT  OUT NUMBER, --返回错误ID
                                  P_ERR_MSG OUT VARCHAR2 --返回错误信息
                                  ) IS
                                  
    V_EXPIRY_DATE  DATE;    
    V_SO_STATUS    VARCHAR2(100);    
    V_SOURCE_NAME  VARCHAR2(100);    
    V_LINE_TYPE    VARCHAR2(100); 
    V_CRU_DATE DATE;
    V_CREATED_BY VARCHAR2(100); 
    V_CUSTOMER_TRX_ID NUMBER; 
    V_TRX_NUMBER VARCHAR2(200); 
    V_RESULT varchar2(4000); 
  BEGIN
    P_RESULT  := PKG_SO_PUB.V_RESULT;
    P_ERR_MSG := PKG_SO_PUB.V_SUCCESS;
    V_SOURCE_NAME := 'IMS订单导入';
    V_LINE_TYPE := 'LINE';
    V_SO_STATUS :='12';
    V_CRU_DATE := SYSDATE;
    V_CREATED_BY := 'SYNC_ARINVOICE';
    
    IF P_EXPIRY_DATE ='0' OR P_EXPIRY_DATE IS NULL THEN
        V_EXPIRY_DATE := SYSDATE-60;
    ELSE
        V_EXPIRY_DATE := TO_DATE(P_EXPIRY_DATE,'YYYY_MM-DD');
    END IF;
    
    FOR SO_HEADER_ROW IN (
            SELECT 
                SH.ERP_OU_ID
               ,SH.SO_NUM 
               ,SH.ENTITY_ID
            FROM  
              CIMS.T_SO_HEADER SH 
            WHERE SH.ENTITY_ID = P_ENTITY_ID
              AND SH.SO_STATUS = V_SO_STATUS
              AND SH.SETTLE_DATE>= V_EXPIRY_DATE
              AND SH.ERP_ARINVOICE_CODE IS NULL
              AND EXISTS (
                SELECT  /*+ NO_UNNEST */ 1
                  FROM APPS.CUX_IMS_AR_INVOICE_V@MDIMS2MDERP INC
                 WHERE INC.REFERENCE = SH.SO_NUM
                   AND INC.ORG_ID = SH.ERP_OU_ID
                   AND INC.BATCH_SOURCE_NAME = V_SOURCE_NAME
                   AND INC.LINE_TYPE = V_LINE_TYPE
                   AND ROWNUM=1 )
              AND ROWNUM<=1000     
     )LOOP
        BEGIN 
               SELECT 
                    INC.CUSTOMER_TRX_ID,
                    INC.TRX_NUMBER
               INTO 
                    V_CUSTOMER_TRX_ID, 
                    V_TRX_NUMBER    
              FROM APPS.CUX_IMS_AR_INVOICE_V@MDIMS2MDERP INC
             WHERE INC.BATCH_SOURCE_NAME = V_SOURCE_NAME
               AND INC.LINE_TYPE = V_LINE_TYPE
               AND INC.ORG_ID = SO_HEADER_ROW.ERP_OU_ID 
               AND INC.REFERENCE = SO_HEADER_ROW.SO_NUM
               AND ROWNUM = 1;
        
            UPDATE T_SO_HEADER SH
               SET SH.ERP_ARINVOICE_ID = V_CUSTOMER_TRX_ID,
                    SH.ERP_ARINVOICE_CODE= V_TRX_NUMBER,
                    SH.LAST_UPDATED_BY = V_CREATED_BY,
                    SH.LAST_UPDATE_DATE = V_CRU_DATE
             WHERE SH.SO_NUM = SO_HEADER_ROW.SO_NUM
               AND SH.ENTITY_ID = SO_HEADER_ROW.ENTITY_ID;
          COMMIT;  
       EXCEPTION
          WHEN OTHERS THEN  
              V_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_SO_ERP.P_UPDATE_SO_ARINVOICE',
                   SQLCODE,
              'AR发票号更新出错！单据号：'||SO_HEADER_ROW.SO_NUM||'。错误消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
       
   END;
   END LOOP;
    
   /* 
    --回写ERP AR发票信息到财务单
    UPDATE T_SO_HEADER SH
       SET (SH.ERP_ARINVOICE_ID,
            SH.ERP_ARINVOICE_CODE,
            SH.LAST_UPDATED_BY,
            SH.LAST_UPDATE_DATE) =
           (
            --CUSTOMER_TRX_ID：ERP AR发票头ID
            --TRX_NUMBER：ERP AR发票号
            SELECT  INC.CUSTOMER_TRX_ID,
                    INC.TRX_NUMBER,
                    'SYNC_ARINVOICE',
                    SYSDATE
              FROM APPS.CUX_IMS_AR_INVOICE_V@MDIMS2MDERP INC
             WHERE INC.BATCH_SOURCE_NAME = 'IMS订单导入'
               AND INC.LINE_TYPE = 'LINE'
               AND INC.ORG_ID = SH.ERP_OU_ID 
               AND INC.REFERENCE = SH.SO_NUM
               AND ROWNUM = 1)
     WHERE SH.SO_STATUS = '12' --已结算
       AND (SH.ERP_ARINVOICE_ID IS NULL OR SH.ERP_ARINVOICE_CODE IS NULL)
       AND EXISTS (SELECT  /*+ no_unnest*//*   1
              FROM APPS.CUX_IMS_AR_INVOICE_V@MDIMS2MDERP INC
             WHERE INC.REFERENCE = SH.SO_NUM
               AND INC.ORG_ID = SH.ERP_OU_ID
               AND INC.BATCH_SOURCE_NAME = 'IMS订单导入'
               AND INC.LINE_TYPE = 'LINE');
             */ 
  EXCEPTION
    WHEN OTHERS THEN
      P_RESULT  := -28209;
      P_ERR_MSG := '回写ERP AR发票信息到财务单发生异常：' || SQLERRM;
  END;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-12-10
  *     创建者：廖丽章
  *   功能说明：销售对账过程，CIMS系统销售单与ERP系统销售订单对账
  *             1)把需要引入到ERP系统的审核通过且未对账财务单添加到销售对账表（T_SO_RECONCILIATION），已添加到该表的记录不重复添加。
  *             2)从对账表中取未审核对账的记录，与ERP系统进行审核对账，并记录对账结果。
  *             3)从对账表中取未结算对账的记录，与ERP系统进行结算对账，并记录对账结果。
  *             4)回写销售单据头表的对账标识和对账时间。
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_RECONCILIATION(P_USER_CODE IN VARCHAR2, --操作用户编码
                                P_RESULT    OUT NUMBER, --返回错误ID
                                P_ERR_MSG   OUT VARCHAR2 --返回错误信息
                                ) IS
    --操作用户账号
    V_USER_CODE VARCHAR2(32);
    V_CURR_DATE DATE := SYSDATE;
  
    --未审核对账或对账失败，且状态为打开的记录
    CURSOR C_SO_RECNT_AUDIT IS
      SELECT RECNT_ID,
             SO_HEADER_ID,
             SO_NUM,
             ERP_OU_ID,
             BILL_TYPE_NAME,
             BIZ_SRC_BILL_TYPE_CODE
        FROM T_SO_RECONCILIATION
       WHERE (AUDIT_RECNT_FLAG IS NULL OR AUDIT_RECNT_FLAG = '00')
         AND STATUS = '01'; --对账状态为打开
    R_SO_RECNT_AUDIT C_SO_RECNT_AUDIT%ROWTYPE;
  
    --未结算对账或对账失败，且状态为打开的记录
    CURSOR C_SO_RECNT_SETTLE IS
      SELECT SR.RECNT_ID,
             SR.SO_HEADER_ID,
             SR.SO_NUM,
             SR.ERP_OU_ID,
             SR.BILL_TYPE_NAME,
             SR.BIZ_SRC_BILL_TYPE_CODE
        FROM T_SO_RECONCILIATION SR, T_SO_HEADER SH
       WHERE SR.SO_HEADER_ID = SH.SO_HEADER_ID
         AND (SR.SETTLE_RECNT_FLAG IS NULL OR SR.SETTLE_RECNT_FLAG = '00')
         AND (SR.AUDIT_RECNT_FLAG IS NOT NULL)
         AND NVL(SH.ERP_BOOKED_FLAG, 'N') = 'Y' --add by chen.wj 20150122 增加这个条件判断SO变更引ERP是否成功，如果成功才做对账
         AND SR.STATUS = '01' --对账状态为打开
         AND SH.SO_STATUS = '12'; --结算状态
    R_SO_RECNT_SETTLE C_SO_RECNT_SETTLE%ROWTYPE;
  
    --对账信息记录集
    V_SO_RECNT_INFO SO_RECNT_INFO;
  
  BEGIN
    --初始返回值
    P_RESULT  := PKG_SO_PUB.V_RESULT;
    P_ERR_MSG := PKG_SO_PUB.V_SUCCESS;
  
    IF (P_USER_CODE IS NULL) THEN
      V_USER_CODE := PKG_SO_PUB.V_CREATED_BY_SYS;
    ELSE
      V_USER_CODE := P_USER_CODE;
    END IF;
  
    --把未对账的单据添加到对账表
    INSERT INTO T_SO_RECONCILIATION
      (RECNT_ID,
       ENTITY_ID,
       SO_HEADER_ID,
       SO_NUM,
       SO_DATE,
       BILL_TYPE_ID,
       BILL_TYPE_CODE,
       BILL_TYPE_NAME,
       BIZ_SRC_BILL_TYPE_ID,
       BIZ_SRC_BILL_TYPE_CODE,
       BIZ_SRC_BILL_TYPE_NAME,
       CUSTOMER_ID,
       CUSTOMER_CODE,
       CUSTOMER_NAME,
       ERP_OU_ID,
       ERP_OU_NAME,
       CREATED_BY,
       CREATION_DATE,
       LAST_UPDATED_BY,
       LAST_UPDATE_DATE)
      SELECT S_SO_RECONCILIATION.NEXTVAL,
             SH.ENTITY_ID,
             SH.SO_HEADER_ID,
             SH.SO_NUM,
             SH.SO_DATE,
             SH.BILL_TYPE_ID,
             SH.BILL_TYPE_CODE,
             SH.BILL_TYPE_NAME,
             SH.BIZ_SRC_BILL_TYPE_ID,
             SH.BIZ_SRC_BILL_TYPE_CODE,
             SH.BIZ_SRC_BILL_TYPE_NAME,
             SH.CUSTOMER_ID,
             SH.CUSTOMER_CODE,
             SH.CUSTOMER_NAME,
             SH.ERP_OU_ID,
             SH.ERP_OU_NAME,
             V_USER_CODE,
             V_CURR_DATE,
             V_USER_CODE,
             V_CURR_DATE
        FROM T_SO_HEADER SH, T_SO_TYPE_EXTEND ST
       WHERE SH.BILL_TYPE_ID = ST.BILL_TYPE_ID
         AND (SH.CHECKED_ACCOUNT_FLAG IS NULL OR
             SH.CHECKED_ACCOUNT_FLAG = 'N')
         AND SH.SO_STATUS IN ('11', '12') --已审核或已结算
         AND ST.TO_ERP_FLAG = 'Y'
         AND SH.ERP_SO_ID IS NOT NULL --add by chen.wj 20150122 加入ERP销售单生成条件，因为在SO生成引ERP时如果成功ERP接口会回写这个字段，因而加入这个条件可以判断ERP，SO生成成功，才有对账这个说法
         AND NOT EXISTS (SELECT 1
                FROM T_SO_RECONCILIATION
               WHERE ENTITY_ID = SH.ENTITY_ID
                 AND SO_HEADER_ID = SH.SO_HEADER_ID);
  
    --审核对账
    FOR R_SO_RECNT_AUDIT IN C_SO_RECNT_AUDIT LOOP
      V_SO_RECNT_INFO.RECNT_ID               := R_SO_RECNT_AUDIT.RECNT_ID;
      V_SO_RECNT_INFO.SO_HEADER_ID           := R_SO_RECNT_AUDIT.SO_HEADER_ID;
      V_SO_RECNT_INFO.SO_NUM                 := R_SO_RECNT_AUDIT.SO_NUM;
      V_SO_RECNT_INFO.ERP_OU_ID              := R_SO_RECNT_AUDIT.ERP_OU_ID;
      V_SO_RECNT_INFO.BILL_TYPE_NAME         := R_SO_RECNT_AUDIT.BILL_TYPE_NAME;
      V_SO_RECNT_INFO.BIZ_SRC_BILL_TYPE_CODE := R_SO_RECNT_AUDIT.BIZ_SRC_BILL_TYPE_CODE;
    
      --对账处理
      P_SO_RECONCILIATION_PROCESS(V_SO_RECNT_INFO,
                                  V_FLAG_AUDIT,
                                  V_USER_CODE,
                                  P_RESULT,
                                  P_ERR_MSG);
      IF P_RESULT < 0 THEN
        RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      END IF;
    END LOOP;
  
    --结算对账
    FOR R_SO_RECNT_SETTLE IN C_SO_RECNT_SETTLE LOOP
      V_SO_RECNT_INFO.RECNT_ID               := R_SO_RECNT_SETTLE.RECNT_ID;
      V_SO_RECNT_INFO.SO_HEADER_ID           := R_SO_RECNT_SETTLE.SO_HEADER_ID;
      V_SO_RECNT_INFO.SO_NUM                 := R_SO_RECNT_SETTLE.SO_NUM;
      V_SO_RECNT_INFO.ERP_OU_ID              := R_SO_RECNT_SETTLE.ERP_OU_ID;
      V_SO_RECNT_INFO.BILL_TYPE_NAME         := R_SO_RECNT_SETTLE.BILL_TYPE_NAME;
      V_SO_RECNT_INFO.BIZ_SRC_BILL_TYPE_CODE := R_SO_RECNT_SETTLE.BIZ_SRC_BILL_TYPE_CODE;
    
      P_SO_RECONCILIATION_PROCESS(V_SO_RECNT_INFO,
                                  V_FLAG_SETTLE,
                                  V_USER_CODE,
                                  P_RESULT,
                                  P_ERR_MSG);
      IF P_RESULT < 0 THEN
        RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      END IF;
    END LOOP;
  
  EXCEPTION
    WHEN PKG_SO_PUB.V_BIZ_EXCEPTION THEN
      P_RESULT  := -28210;
      P_ERR_MSG := '销售对账出错，' || P_ERR_MSG;
    WHEN OTHERS THEN
      P_RESULT  := -28210;
      P_ERR_MSG := '销售对账发生异常，' || SQLERRM;
  END;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-12-10
  *     创建者：廖丽章
  *   功能说明：销售对账处理
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_RECONCILIATION_PROCESS(P_SO_RECNT_INFO IN SO_RECNT_INFO, --销售对账记录
                                        P_RECNT_FLAG    IN VARCHAR2, --对帐类型标识：A审核对账，S结算对账
                                        P_USER_CODE     IN VARCHAR2, --操作用户编码
                                        P_RESULT        OUT NUMBER, --返回错误ID
                                        P_ERR_MSG       OUT VARCHAR2 --返回错误信息
                                        ) IS
    --财务单源类型
    V_BILL_TYPE_NAME         T_SO_HEADER.BILL_TYPE_NAME%TYPE;
    V_BIZ_SRC_BILL_TYPE_CODE T_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE%TYPE;
  
    --财务单信息
    CURSOR C_SO_INFO IS(
    --套件行
      SELECT SO_HEADER_ID,
             'MODEL' AS ITEM_TYPE_CODE,
             SUM(NVL(ITEM_QTY, 0)) AS QTY,
             SUM(NVL(ITEM_SETTLE_AMOUNT, 0)) AS AMOUNT
        FROM T_SO_LINE
       WHERE SO_HEADER_ID = P_SO_RECNT_INFO.SO_HEADER_ID
         AND ITEM_IS_SET = 'Y'
       GROUP BY SO_HEADER_ID
      UNION
      --散件行
      SELECT SL.SO_HEADER_ID,
             DECODE(SL.ITEM_IS_SET, 'Y', 'OPTION', 'STANDARD') AS ITEM_TYPE_CODE,
             SUM(NVL(SLD.COMPONENT_QTY, 0)) AS QTY,
             SUM(NVL(SLD.COMPONENT_SETTLE_PRICE, 0) *
                 NVL(SLD.COMPONENT_QTY, 0)) AS AMOUNT
        FROM T_SO_LINE SL, T_SO_LINE_DETAIL SLD
       WHERE SL.SO_LINE_ID = SLD.SO_LINE_ID
         AND SL.SO_HEADER_ID = P_SO_RECNT_INFO.SO_HEADER_ID
       GROUP BY SL.SO_HEADER_ID,
                DECODE(SL.ITEM_IS_SET, 'Y', 'OPTION', 'STANDARD'));
    --财务单信息记录
    R_SO_INFO C_SO_INFO%ROWTYPE;
  
    --CIMS系统财务单产品数量和结算总金额
    V_QTY    NUMBER := 0;
    V_AMOUNT NUMBER := 0;
  
    --ERP系统销售订单产品数量和结算总金额
    V_ERP_QTY    NUMBER := 0;
    V_ERP_AMOUNT NUMBER := 0;
  
    --ERP系统销售订单在各阶段的状态
    V_STATUS_ENTERED   VARCHAR2(10) := 'Entered';
    V_STATUS_FULFILLED VARCHAR2(10) := 'Fulfilled';
    V_STATUS_CLOSED    VARCHAR2(10) := 'Closed';
    V_STATUS_BOOKED    VARCHAR2(10) := 'Booked';
    V_STATUS_RETURNED  VARCHAR2(10) := 'Returned';
    V_STATUS_AWAITING  VARCHAR2(20) := 'Awaiting Return';
  
    --对账信息
    V_MSG VARCHAR2(2048) := '';
    --对账是否成功：失败 00，成功 01
    V_RECNT_FLAG VARCHAR2(2) := '01';
    --当前系统日期时间
    V_CURR_DATE DATE := SYSDATE;
    
    --by sushu 2016-07-26
    --结算日期
    V_SETTLE_DATE Date;
    --CIMS不含税收入
    V_CIMS_REV_AMOUNT Number;
    --ERP不含税收入
    V_ERP_REV_AMOUNT Number;
    --ERP发票金额
    V_ERP_REC_AMOUNT Number;
    --CIMS不含税收入-ERP不含税收入的差异，>1或者<-1为Y。其他为N
    V_AMOUNT_DIFF varchar2(2);
    --ERP应收（AR)发票号
    V_ERP_ARINVOICE_CODE Varchar2(50);
    --ERP的OU_ID
    V_ERP_OU_ID Number;
    --正负号
    V_PLUS_MINUS_FLAG Number;
  
  BEGIN
    --初始返回值
    P_RESULT  := PKG_SO_PUB.V_RESULT;
    P_ERR_MSG := PKG_SO_PUB.V_SUCCESS;
  
    --计算CIMS财务单行产品数量和结算总金额
    FOR R_SO_INFO IN C_SO_INFO LOOP
      V_QTY    := V_QTY + R_SO_INFO.QTY;
      V_AMOUNT := V_AMOUNT + R_SO_INFO.AMOUNT;
    END LOOP;
  
    --财务单源类型
    V_BILL_TYPE_NAME         := P_SO_RECNT_INFO.BILL_TYPE_NAME;
    V_BIZ_SRC_BILL_TYPE_CODE := P_SO_RECNT_INFO.BIZ_SRC_BILL_TYPE_CODE;
  
    IF V_BIZ_SRC_BILL_TYPE_CODE IN
       (PKG_SO_PUB.V_BIZ_SRC_BILL_SO, PKG_SO_PUB.V_BIZ_SRC_BILL_RETURN_RED) THEN
      --销售订单，除折让
      --ERP的销售订单（对应CIMS的销售单和退货红冲单）
      DECLARE
        --ERP系统的销售订单信息
        CURSOR C_ERP_SO_INFO IS
          SELECT OEL.HEADER_ID,
                 LV.MEANING AS STATUS,
                 SUM(OEL.ORDERED_QUANTITY) AS ORDERED_QUANTITY,
                 SUM(OEL.ORDERED_QUANTITY * OEL.UNIT_SELLING_PRICE) AS AMOUNT
            FROM APPS.OE_ORDER_LINES_ALL@MDIMS2MDERP   OEL,
                 APPS.OE_ORDER_HEADERS_ALL@MDIMS2MDERP OEH,
                 APPS.FND_LOOKUP_VALUES@MDIMS2MDERP    LV
           WHERE LV.LOOKUP_TYPE = 'LINE_FLOW_STATUS'
             AND LV.LOOKUP_CODE = OEL.FLOW_STATUS_CODE
             AND LV.LANGUAGE = 'US' --USERENV('LANG')
             AND LV.VIEW_APPLICATION_ID = 660
             AND OEH.HEADER_ID = OEL.HEADER_ID
                --AND OEL.LINE_CATEGORY_CODE = 'ORDER',--因为启用了MIXED,
             AND OEH.ORDER_NUMBER = TO_NUMBER(P_SO_RECNT_INFO.SO_NUM) --参数
             AND OEH.ORG_ID = P_SO_RECNT_INFO.ERP_OU_ID --参数OU ID
           GROUP BY OEL.HEADER_ID, LV.MEANING;
      
        --ERP系统的销售订单信息记录
        R_ERP_SO_INFO C_ERP_SO_INFO%ROWTYPE;
      
      BEGIN
        --获取ERP销售订单的产品总数和结算总金额
        FOR R_ERP_SO_INFO IN C_ERP_SO_INFO LOOP
          IF (P_RECNT_FLAG = V_FLAG_AUDIT) THEN
            --审核对账
            IF R_ERP_SO_INFO.STATUS IN
               (V_STATUS_ENTERED, V_STATUS_FULFILLED, V_STATUS_CLOSED) THEN
              V_ERP_QTY    := (V_ERP_QTY + R_ERP_SO_INFO.ORDERED_QUANTITY);
              V_ERP_AMOUNT := (V_ERP_AMOUNT + R_ERP_SO_INFO.AMOUNT);
            END IF;
          ELSIF (P_RECNT_FLAG = V_FLAG_SETTLE) THEN
            --结算对账
            IF R_ERP_SO_INFO.STATUS IN
               (V_STATUS_FULFILLED, V_STATUS_CLOSED) THEN
              V_ERP_QTY    := (V_ERP_QTY + R_ERP_SO_INFO.ORDERED_QUANTITY);
              V_ERP_AMOUNT := (V_ERP_AMOUNT + R_ERP_SO_INFO.AMOUNT);
            END IF;
          END IF;
        END LOOP;
      EXCEPTION
        WHEN OTHERS THEN
          P_ERR_MSG := V_BILL_TYPE_NAME || '[单据号：' ||
                       P_SO_RECNT_INFO.SO_NUM || ']对账发生异常：' || SQLERRM;
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      END;
    ELSIF V_BIZ_SRC_BILL_TYPE_CODE IN
          (PKG_SO_PUB.V_BIZ_SRC_BILL_RETURN,
           PKG_SO_PUB.V_BIZ_SRC_BILL_SO_RED) THEN
      --RMA，除折让
      --ERP的RMA（对应CIMS的退货单和销售红冲单）
      DECLARE
        --ERP系统的销售订单信息
        CURSOR C_ERP_SO_INFO IS
          SELECT OEL.HEADER_ID,
                 DECODE(OEL.SHIPPABLE_FLAG,
                        'N',
                        'MODEL',
                        OEL.ITEM_TYPE_CODE) AS ITEM_TYPE_CODE,
                 LV.MEANING AS STATUS,
                 SUM(OEL.ORDERED_QUANTITY) AS ORDERED_QUANTITY,
                 SUM(OEL.ORDERED_QUANTITY * OEL.UNIT_SELLING_PRICE) AS AMOUNT
            FROM APPS.OE_ORDER_LINES_ALL@MDIMS2MDERP   OEL,
                 APPS.OE_ORDER_HEADERS_ALL@MDIMS2MDERP OEH,
                 APPS.FND_LOOKUP_VALUES@MDIMS2MDERP    LV
           WHERE LV.LOOKUP_TYPE = 'LINE_FLOW_STATUS'
             AND LV.LOOKUP_CODE = OEL.FLOW_STATUS_CODE
             AND LV.LANGUAGE = 'US' --USERENV('LANG')
             AND LV.VIEW_APPLICATION_ID = 660
             AND OEH.HEADER_ID = OEL.HEADER_ID
                --AND OEH.ORDER_CATEGORY_CODE = 'RETURN' --因为启用了MIXED,
             AND OEH.ORDER_NUMBER = TO_NUMBER(P_SO_RECNT_INFO.SO_NUM) --参数
             AND OEH.ORG_ID = P_SO_RECNT_INFO.ERP_OU_ID --参数OU ID
           GROUP BY OEL.HEADER_ID,
                    DECODE(OEL.SHIPPABLE_FLAG,
                           'N',
                           'MODEL',
                           OEL.ITEM_TYPE_CODE),
                    LV.MEANING;
      
        --ERP系统的销售订单信息记录
        R_ERP_SO_INFO C_ERP_SO_INFO%ROWTYPE;
      BEGIN
        --获取ERP销售订单的产品总数和结算总金额
        FOR R_ERP_SO_INFO IN C_ERP_SO_INFO LOOP
          IF (P_RECNT_FLAG = V_FLAG_AUDIT) THEN
            --审核对账
            IF (R_ERP_SO_INFO.ITEM_TYPE_CODE = 'MODEL') AND
               (R_ERP_SO_INFO.STATUS IN
               (V_STATUS_ENTERED, V_STATUS_BOOKED, V_STATUS_CLOSED)) THEN
              V_ERP_QTY    := (V_ERP_QTY + R_ERP_SO_INFO.ORDERED_QUANTITY);
              V_ERP_AMOUNT := (V_ERP_AMOUNT + R_ERP_SO_INFO.AMOUNT);
            ELSIF (R_ERP_SO_INFO.ITEM_TYPE_CODE = 'STANDARD') AND
                  (R_ERP_SO_INFO.STATUS IN
                  (V_STATUS_ENTERED,
                    V_STATUS_AWAITING,
                    V_STATUS_RETURNED,
                    V_STATUS_CLOSED)) THEN
              V_ERP_QTY    := (V_ERP_QTY + R_ERP_SO_INFO.ORDERED_QUANTITY);
              V_ERP_AMOUNT := (V_ERP_AMOUNT + R_ERP_SO_INFO.AMOUNT);
            END IF;
          ELSIF (P_RECNT_FLAG = V_FLAG_SETTLE) THEN
            --结算对账
            IF (R_ERP_SO_INFO.ITEM_TYPE_CODE = 'MODEL') AND
               (R_ERP_SO_INFO.STATUS IN (V_STATUS_BOOKED, V_STATUS_CLOSED)) THEN
              V_ERP_QTY    := (V_ERP_QTY + R_ERP_SO_INFO.ORDERED_QUANTITY);
              V_ERP_AMOUNT := (V_ERP_AMOUNT + R_ERP_SO_INFO.AMOUNT);
            ELSIF (R_ERP_SO_INFO.ITEM_TYPE_CODE = 'STANDARD') AND
                  (R_ERP_SO_INFO.STATUS IN
                  (V_STATUS_AWAITING, V_STATUS_RETURNED, V_STATUS_CLOSED)) THEN
              V_ERP_QTY    := (V_ERP_QTY + R_ERP_SO_INFO.ORDERED_QUANTITY);
              V_ERP_AMOUNT := (V_ERP_AMOUNT + R_ERP_SO_INFO.AMOUNT);
            END IF;
          END IF;
        END LOOP;
      EXCEPTION
        WHEN OTHERS THEN
          P_ERR_MSG := V_BILL_TYPE_NAME || '[单据号：' ||
                       P_SO_RECNT_INFO.SO_NUM || ']对账发生异常：' || SQLERRM;
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      END;
    ELSIF V_BIZ_SRC_BILL_TYPE_CODE IN
          (PKG_SO_PUB.V_BIZ_SRC_BILL_SO_DISCOUNT,
           PKG_SO_PUB.V_BIZ_SRC_BILL_DISCOUNT) THEN
      --折让RMA
      --ERP的折让RMA（对应CIMS的销售折让单和折让证明单）
      DECLARE
        --ERP系统的销售订单信息
        CURSOR C_ERP_SO_INFO IS
          SELECT OEL.HEADER_ID,
                 OEL.ITEM_TYPE_CODE,
                 LV.MEANING AS STATUS,
                 SUM(OEL.ORDERED_QUANTITY) AS ORDERED_QUANTITY,
                 SUM(OEL.ORDERED_QUANTITY * OEL.UNIT_SELLING_PRICE) AS AMOUNT
            FROM APPS.OE_ORDER_LINES_ALL@MDIMS2MDERP   OEL,
                 APPS.OE_ORDER_HEADERS_ALL@MDIMS2MDERP OEH,
                 APPS.FND_LOOKUP_VALUES@MDIMS2MDERP    LV
           WHERE LV.LOOKUP_TYPE = 'LINE_FLOW_STATUS'
             AND LV.LOOKUP_CODE = OEL.FLOW_STATUS_CODE
             AND LV.LANGUAGE = 'US' --USERENV('LANG')
             AND LV.VIEW_APPLICATION_ID = 660
             AND OEH.HEADER_ID = OEL.HEADER_ID
                --AND OEH.ORDER_CATEGORY_CODE = 'RETURN' --因为启用了MIXED,
             AND OEH.ORDER_NUMBER = TO_NUMBER(P_SO_RECNT_INFO.SO_NUM) --参数
             AND OEH.ORG_ID = P_SO_RECNT_INFO.ERP_OU_ID --参数OU ID
           GROUP BY OEL.HEADER_ID, OEL.ITEM_TYPE_CODE, LV.MEANING;
      
        --ERP系统的销售订单信息记录
        R_ERP_SO_INFO C_ERP_SO_INFO%ROWTYPE;
      BEGIN
        --获取ERP销售订单的产品总数和结算总金额
        FOR R_ERP_SO_INFO IN C_ERP_SO_INFO LOOP
          IF (P_RECNT_FLAG = V_FLAG_AUDIT) THEN
            --审核对账
            IF (R_ERP_SO_INFO.ITEM_TYPE_CODE = 'STANDARD') AND
               (R_ERP_SO_INFO.STATUS IN
               (V_STATUS_ENTERED, V_STATUS_BOOKED, V_STATUS_CLOSED)) THEN
              V_ERP_QTY    := (V_ERP_QTY + R_ERP_SO_INFO.ORDERED_QUANTITY);
              V_ERP_AMOUNT := (V_ERP_AMOUNT + R_ERP_SO_INFO.AMOUNT);
            END IF;
          ELSIF (P_RECNT_FLAG = V_FLAG_SETTLE) THEN
            --结算对账
            IF (R_ERP_SO_INFO.ITEM_TYPE_CODE = 'STANDARD') AND
               (R_ERP_SO_INFO.STATUS IN (V_STATUS_BOOKED, V_STATUS_CLOSED)) THEN
              V_ERP_QTY    := (V_ERP_QTY + R_ERP_SO_INFO.ORDERED_QUANTITY);
              V_ERP_AMOUNT := (V_ERP_AMOUNT + R_ERP_SO_INFO.AMOUNT);
            END IF;
          END IF;
        END LOOP;
      EXCEPTION
        WHEN OTHERS THEN
          P_ERR_MSG := V_BILL_TYPE_NAME || '[单据号：' ||
                       P_SO_RECNT_INFO.SO_NUM || ']对账发生异常：' || SQLERRM;
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      END;
    ELSIF V_BIZ_SRC_BILL_TYPE_CODE IN
          (PKG_SO_PUB.V_BIZ_SRC_BILL_SO_DISCOUNT,
           PKG_SO_PUB.V_BIZ_SRC_BILL_DISCOUNT) THEN
      --折让销售订单
      --ERP的折让销售订单（对应CIMS的销售折让红冲单和折让证明红冲单）
      DECLARE
        --ERP系统的销售订单信息
        CURSOR C_ERP_SO_INFO IS
          SELECT OEL.HEADER_ID,
                 OEL.ITEM_TYPE_CODE,
                 LV.MEANING AS STATUS,
                 SUM(OEL.ORDERED_QUANTITY) AS ORDERED_QUANTITY,
                 SUM(OEL.ORDERED_QUANTITY * OEL.UNIT_SELLING_PRICE) AS AMOUNT
            FROM APPS.OE_ORDER_LINES_ALL@MDIMS2MDERP   OEL,
                 APPS.OE_ORDER_HEADERS_ALL@MDIMS2MDERP OEH,
                 APPS.FND_LOOKUP_VALUES@MDIMS2MDERP    LV
           WHERE LV.LOOKUP_TYPE = 'LINE_FLOW_STATUS'
             AND LV.LOOKUP_CODE = OEL.FLOW_STATUS_CODE
             AND LV.LANGUAGE = 'US' --USERENV('LANG')
             AND LV.VIEW_APPLICATION_ID = 660
             AND OEH.HEADER_ID = OEL.HEADER_ID
                --AND OEH.ORDER_CATEGORY_CODE = 'ORDER' --因为启用了MIXED,
             AND OEH.ORDER_NUMBER = TO_NUMBER(P_SO_RECNT_INFO.SO_NUM) --参数：
             AND OEH.ORG_ID = P_SO_RECNT_INFO.ERP_OU_ID --：参数OU ID
           GROUP BY OEL.HEADER_ID, OEL.ITEM_TYPE_CODE, LV.MEANING;
      
        --ERP系统的销售订单信息记录
        R_ERP_SO_INFO C_ERP_SO_INFO%ROWTYPE;
      BEGIN
        --获取ERP销售订单的产品总数和结算总金额
        FOR R_ERP_SO_INFO IN C_ERP_SO_INFO LOOP
          IF (P_RECNT_FLAG = V_FLAG_AUDIT) THEN
            --审核对账
            IF (R_ERP_SO_INFO.ITEM_TYPE_CODE = 'STANDARD') AND
               (R_ERP_SO_INFO.STATUS IN
               (V_STATUS_ENTERED, V_STATUS_BOOKED, V_STATUS_CLOSED)) THEN
              V_ERP_QTY    := (V_ERP_QTY + R_ERP_SO_INFO.ORDERED_QUANTITY);
              V_ERP_AMOUNT := (V_ERP_AMOUNT + R_ERP_SO_INFO.AMOUNT);
            END IF;
          ELSIF (P_RECNT_FLAG = V_FLAG_SETTLE) THEN
            --结算对账
            IF (R_ERP_SO_INFO.ITEM_TYPE_CODE = 'STANDARD') AND
               (R_ERP_SO_INFO.STATUS IN (V_STATUS_BOOKED, V_STATUS_CLOSED)) THEN
              V_ERP_QTY    := (V_ERP_QTY + R_ERP_SO_INFO.ORDERED_QUANTITY);
              V_ERP_AMOUNT := (V_ERP_AMOUNT + R_ERP_SO_INFO.AMOUNT);
            END IF;
          END IF;
        END LOOP;
      EXCEPTION
        WHEN OTHERS THEN
          P_ERR_MSG := V_BILL_TYPE_NAME || '[单据号：' ||
                       P_SO_RECNT_INFO.SO_NUM || ']对账发生异常：' || SQLERRM;
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      END;
    END IF;
  
    --取绝对值之前，先赋值给CIMS不含税金额  by sushu 2016-07-26
    V_CIMS_REV_AMOUNT := V_AMOUNT;
    --取绝对值
    V_QTY        := ABS(V_QTY);
    V_AMOUNT     := ABS(V_AMOUNT);
    V_ERP_QTY    := ABS(V_ERP_QTY);
    V_ERP_AMOUNT := ABS(V_ERP_AMOUNT);
  
    --如果数量或金额不相等，则表明对账失败。
    IF (V_QTY != V_ERP_QTY) THEN
      V_RECNT_FLAG := '00';
      V_MSG        := '数量不相等：CIMS系统的数量为' || V_QTY || '，ERP系统的数量为' ||
                      V_ERP_QTY || '。';
    END IF;
  
    IF (V_AMOUNT != V_ERP_AMOUNT) THEN
      V_RECNT_FLAG := '00';
      V_MSG        := V_MSG || '金额不相等：CIMS系统的结算金额为' || V_AMOUNT ||
                      '，ERP系统的结算金额为' || V_ERP_AMOUNT || '。';
    END IF;
  
    IF V_RECNT_FLAG = '00' THEN
      V_MSG := V_BILL_TYPE_NAME || '[' || P_SO_RECNT_INFO.SO_NUM ||
               ']对账失败：' || V_MSG;
    ELSE
      V_MSG := V_BILL_TYPE_NAME || '[' || P_SO_RECNT_INFO.SO_NUM ||
               ']对账成功.';
    END IF;
  
    --回写对帐表
    IF (P_RECNT_FLAG = V_FLAG_AUDIT) THEN
      --审核对账
      UPDATE T_SO_RECONCILIATION T
         SET AUDIT_RECNT_FLAG = V_RECNT_FLAG,
             AUDIT_RECNT_DESC = V_MSG,
             AUDIT_RECNT_TIME = V_CURR_DATE,
             LAST_UPDATED_BY  = P_USER_CODE,
             LAST_UPDATE_DATE = V_CURR_DATE
       WHERE RECNT_ID = P_SO_RECNT_INFO.RECNT_ID;
    ELSIF (P_RECNT_FLAG = V_FLAG_SETTLE) Then
      
      --销售对账增加结算日期、CIMS不含税收入、ERP不含税收入、ERP发票金额；
      --by sushu 2016-07-26
      --从销售单据上获取结算日期，发票号，org_id
      Begin
        Select Sh.Settle_Date, --结算日期 
               Sh.Erp_Arinvoice_Code, --发票号
               Sh.Erp_Ou_Id,
               Order_Type.Plus_Minus_Flag
          Into v_Settle_Date,
               v_Erp_Arinvoice_Code,
               v_Erp_Ou_Id,
               v_Plus_Minus_Flag
          From t_So_Header Sh, t_So_Type_Extend Order_Type
         Where Sh.So_Num = p_So_Recnt_Info.So_Num
           And Sh.Bill_Type_Id = Order_Type.Bill_Type_Id;
      Exception
        When Others Then
          p_Err_Msg := '获取销售单据的信息失败，单据号：' || p_So_Recnt_Info.So_Num ||
                       Sqlerrm;
          Raise Pkg_So_Pub.v_Biz_Exception;
      End;
      --根据ERP应收发票号、ERP的OU_ID获取ERP不含税收入、ERP发票金额
      Begin
        Select a.Rev_Amount, --ERP不含税收入
               a.Rec_Amount --ERP发票金额
          Into v_Erp_Rev_Amount, v_Erp_Rec_Amount
          From Apps.Cux_Erp_Ar_Cust_Trx_v@Mdims2mderp a
         Where a.Org_Id = v_Erp_Ou_Id
           And a.Trx_Number = v_Erp_Arinvoice_Code;
      Exception
        When Others Then
          p_Err_Msg := '获取ERP的不含税收入、ERP发票金额失败' || Sqlerrm;
          Raise Pkg_So_Pub.v_Biz_Exception;
      End;
      --CIMS不含税金额
      v_Cims_Rev_Amount := Round(v_Cims_Rev_Amount / 1.17, 2) *
                           v_Plus_Minus_Flag;
      --ERP不含税收入取两位小数
      v_Erp_Rev_Amount := Round(v_Erp_Rev_Amount, 2);
      --ERP发票金额取两位小数
      v_Erp_Rec_Amount := Round(v_Erp_Rec_Amount, 2);
      --CIMS不含税收入-ERP不含税收入差异，>1或者<-1为Y，其他为N
      If ((v_Cims_Rev_Amount - v_Erp_Rev_Amount) > 1 Or
         (v_Cims_Rev_Amount - v_Erp_Rev_Amount) < -1) Then
        v_Amount_Diff := 'Y';
      Else
        v_Amount_Diff := 'N';
      End If;
    
      --结算对账
      UPDATE T_SO_RECONCILIATION
         SET SETTLE_RECNT_FLAG = V_RECNT_FLAG,
             SETTLE_RECNT_DESC = V_MSG,
             SETTLE_RECNT_TIME = V_CURR_DATE,
             STATUS            = '00', --结算对账后，把状态改为关闭
             LAST_UPDATED_BY   = P_USER_CODE,
             LAST_UPDATE_DATE  = V_CURR_DATE,
             SETTLE_DATE       = V_SETTLE_DATE,     --by sushu 2016-07-26
             CIMS_REV_AMOUNT   = V_CIMS_REV_AMOUNT, --by sushu 2016-07-26
             ERP_REV_AMOUNT    = V_ERP_REV_AMOUNT,  --by sushu 2016-07-26
             ERP_REC_AMOUNT    = V_ERP_REC_AMOUNT,  --by sushu 2016-07-26
             AMOUNT_DIFF       = V_AMOUNT_DIFF      --by sushu 2016-07-26
       WHERE RECNT_ID = P_SO_RECNT_INFO.RECNT_ID;
    END IF;
  
    --回写对帐标识到T_SO_HEADER表
    UPDATE T_SO_HEADER
       SET CHECKED_ACCOUNT_FLAG = 'Y', CHECKED_ACCOUNT_DATE = V_CURR_DATE
     WHERE SO_HEADER_ID = P_SO_RECNT_INFO.SO_HEADER_ID;
  
  EXCEPTION
    WHEN PKG_SO_PUB.V_BIZ_EXCEPTION THEN
      P_RESULT  := -28211;
      P_ERR_MSG := '对账处理出错：' || P_ERR_MSG;
    WHEN OTHERS THEN
      P_RESULT  := -28211;
      P_ERR_MSG := '对账处理异常：' || SQLERRM;
  END;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-01-22
  *     创建者：陈武杰
  *   功能说明：重算销售对账处理
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_RE_RECONCILIATION_PROCESS(P_SO_RECNT_INFO IN SO_RECNT_INFO, --销售对账记录
                                           P_RECNT_FLAG    IN VARCHAR2, --对帐类型标识：A审核对账，S结算对账
                                           P_USER_CODE     IN VARCHAR2, --操作用户编码
                                           P_RESULT        OUT NUMBER, --返回错误ID
                                           P_ERR_MSG       OUT VARCHAR2 --返回错误信息
                                           ) IS
    --财务单源类型
    V_BILL_TYPE_NAME         T_SO_HEADER.BILL_TYPE_NAME%TYPE;
    V_BIZ_SRC_BILL_TYPE_CODE T_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE%TYPE;
  
    --财务单信息
    CURSOR C_SO_INFO IS(
    --套件行
      SELECT SO_HEADER_ID,
             'MODEL' AS ITEM_TYPE_CODE,
             SUM(NVL(ITEM_QTY, 0)) AS QTY,
             SUM(NVL(ITEM_SETTLE_AMOUNT, 0)) AS AMOUNT
        FROM T_SO_LINE
       WHERE SO_HEADER_ID = P_SO_RECNT_INFO.SO_HEADER_ID
         AND ITEM_IS_SET = 'Y'
       GROUP BY SO_HEADER_ID
      UNION
      --散件行
      SELECT SL.SO_HEADER_ID,
             DECODE(SL.ITEM_IS_SET, 'Y', 'OPTION', 'STANDARD') AS ITEM_TYPE_CODE,
             SUM(NVL(SLD.COMPONENT_QTY, 0)) AS QTY,
             SUM(NVL(SLD.COMPONENT_SETTLE_PRICE, 0) *
                 NVL(SLD.COMPONENT_QTY, 0)) AS AMOUNT
        FROM T_SO_LINE SL, T_SO_LINE_DETAIL SLD
       WHERE SL.SO_LINE_ID = SLD.SO_LINE_ID
         AND SL.SO_HEADER_ID = P_SO_RECNT_INFO.SO_HEADER_ID
       GROUP BY SL.SO_HEADER_ID,
                DECODE(SL.ITEM_IS_SET, 'Y', 'OPTION', 'STANDARD'));
    --财务单信息记录
    R_SO_INFO C_SO_INFO%ROWTYPE;
  
    --CIMS系统财务单产品数量和结算总金额
    V_QTY    NUMBER := 0;
    V_AMOUNT NUMBER := 0;
  
    --ERP系统销售订单产品数量和结算总金额
    V_ERP_QTY    NUMBER := 0;
    V_ERP_AMOUNT NUMBER := 0;
  
    --ERP系统销售订单在各阶段的状态
    V_STATUS_ENTERED   VARCHAR2(10) := 'Entered';
    V_STATUS_FULFILLED VARCHAR2(10) := 'Fulfilled';
    V_STATUS_CLOSED    VARCHAR2(10) := 'Closed';
    V_STATUS_BOOKED    VARCHAR2(10) := 'Booked';
    V_STATUS_RETURNED  VARCHAR2(10) := 'Returned';
    V_STATUS_AWAITING  VARCHAR2(20) := 'Awaiting Return';
  
    --对账信息
    V_MSG VARCHAR2(2048) := '';
    --对账是否成功：失败 00，成功 01
    V_RECNT_FLAG VARCHAR2(2) := '01';
    --当前系统日期时间
    V_CURR_DATE DATE := SYSDATE;
    
    --by sushu 2016-07-26
    --结算日期
    V_SETTLE_DATE Date;
    --CIMS不含税收入
    V_CIMS_REV_AMOUNT Number;
    --ERP不含税收入
    V_ERP_REV_AMOUNT Number;
    --ERP发票金额
    V_ERP_REC_AMOUNT Number;
    --CIMS不含税收入-ERP不含税收入的差异，>1或者<-1为Y。其他为N
    V_AMOUNT_DIFF varchar2(2);
    --ERP应收（AR)发票号
    V_ERP_ARINVOICE_CODE Varchar2(50);
    --ERP的OU_ID
    V_ERP_OU_ID Number;
    --正负号
    V_PLUS_MINUS_FLAG Number;
  
  BEGIN
    --初始返回值
    P_RESULT  := PKG_SO_PUB.V_RESULT;
    P_ERR_MSG := PKG_SO_PUB.V_SUCCESS;
  
    --计算CIMS财务单行产品数量和结算总金额
    FOR R_SO_INFO IN C_SO_INFO LOOP
      V_QTY    := V_QTY + R_SO_INFO.QTY;
      V_AMOUNT := V_AMOUNT + R_SO_INFO.AMOUNT;
    END LOOP;
  
    --财务单源类型
    V_BILL_TYPE_NAME         := P_SO_RECNT_INFO.BILL_TYPE_NAME;
    V_BIZ_SRC_BILL_TYPE_CODE := P_SO_RECNT_INFO.BIZ_SRC_BILL_TYPE_CODE;
  
    IF V_BIZ_SRC_BILL_TYPE_CODE IN
       (PKG_SO_PUB.V_BIZ_SRC_BILL_SO, PKG_SO_PUB.V_BIZ_SRC_BILL_RETURN_RED) THEN
      --销售订单，除折让
      --ERP的销售订单（对应CIMS的销售单和退货红冲单）
      DECLARE
        --ERP系统的销售订单信息
        CURSOR C_ERP_SO_INFO IS
          SELECT OEL.HEADER_ID,
                 LV.MEANING AS STATUS,
                 SUM(OEL.ORDERED_QUANTITY) AS ORDERED_QUANTITY,
                 SUM(OEL.ORDERED_QUANTITY * OEL.UNIT_SELLING_PRICE) AS AMOUNT
            FROM APPS.OE_ORDER_LINES_ALL@MDIMS2MDERP   OEL,
                 APPS.OE_ORDER_HEADERS_ALL@MDIMS2MDERP OEH,
                 APPS.FND_LOOKUP_VALUES@MDIMS2MDERP    LV
           WHERE LV.LOOKUP_TYPE = 'LINE_FLOW_STATUS'
             AND LV.LOOKUP_CODE = OEL.FLOW_STATUS_CODE
             AND LV.LANGUAGE = 'US' --USERENV('LANG')
             AND LV.VIEW_APPLICATION_ID = 660
             AND OEH.HEADER_ID = OEL.HEADER_ID
                --AND OEL.LINE_CATEGORY_CODE = 'ORDER',--因为启用了MIXED,
             AND OEH.ORDER_NUMBER = TO_NUMBER(P_SO_RECNT_INFO.SO_NUM) --参数
             AND OEH.ORG_ID = P_SO_RECNT_INFO.ERP_OU_ID --参数OU ID
           GROUP BY OEL.HEADER_ID, LV.MEANING;
      
        --ERP系统的销售订单信息记录
        R_ERP_SO_INFO C_ERP_SO_INFO%ROWTYPE;
      
      BEGIN
        --获取ERP销售订单的产品总数和结算总金额
        FOR R_ERP_SO_INFO IN C_ERP_SO_INFO LOOP
          IF (P_RECNT_FLAG = V_FLAG_AUDIT) THEN
            --审核对账
            IF R_ERP_SO_INFO.STATUS IN
               (V_STATUS_ENTERED, V_STATUS_FULFILLED, V_STATUS_CLOSED) THEN
              V_ERP_QTY    := (V_ERP_QTY + R_ERP_SO_INFO.ORDERED_QUANTITY);
              V_ERP_AMOUNT := (V_ERP_AMOUNT + R_ERP_SO_INFO.AMOUNT);
            END IF;
          ELSIF (P_RECNT_FLAG = V_FLAG_SETTLE) THEN
            --结算对账
            IF R_ERP_SO_INFO.STATUS IN
               (V_STATUS_FULFILLED, V_STATUS_CLOSED) THEN
              V_ERP_QTY    := (V_ERP_QTY + R_ERP_SO_INFO.ORDERED_QUANTITY);
              V_ERP_AMOUNT := (V_ERP_AMOUNT + R_ERP_SO_INFO.AMOUNT);
            END IF;
          END IF;
        END LOOP;
      EXCEPTION
        WHEN OTHERS THEN
          P_ERR_MSG := V_BILL_TYPE_NAME || '[单据号：' ||
                       P_SO_RECNT_INFO.SO_NUM || ']对账发生异常：' || SQLERRM;
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      END;
    ELSIF V_BIZ_SRC_BILL_TYPE_CODE IN
          (PKG_SO_PUB.V_BIZ_SRC_BILL_RETURN,
           PKG_SO_PUB.V_BIZ_SRC_BILL_SO_RED) THEN
      --RMA，除折让
      --ERP的RMA（对应CIMS的退货单和销售红冲单）
      DECLARE
        --ERP系统的销售订单信息
        CURSOR C_ERP_SO_INFO IS
          SELECT OEL.HEADER_ID,
                 DECODE(OEL.SHIPPABLE_FLAG,
                        'N',
                        'MODEL',
                        OEL.ITEM_TYPE_CODE) AS ITEM_TYPE_CODE,
                 LV.MEANING AS STATUS,
                 SUM(OEL.ORDERED_QUANTITY) AS ORDERED_QUANTITY,
                 SUM(OEL.ORDERED_QUANTITY * OEL.UNIT_SELLING_PRICE) AS AMOUNT
            FROM APPS.OE_ORDER_LINES_ALL@MDIMS2MDERP   OEL,
                 APPS.OE_ORDER_HEADERS_ALL@MDIMS2MDERP OEH,
                 APPS.FND_LOOKUP_VALUES@MDIMS2MDERP    LV
           WHERE LV.LOOKUP_TYPE = 'LINE_FLOW_STATUS'
             AND LV.LOOKUP_CODE = OEL.FLOW_STATUS_CODE
             AND LV.LANGUAGE = 'US' --USERENV('LANG')
             AND LV.VIEW_APPLICATION_ID = 660
             AND OEH.HEADER_ID = OEL.HEADER_ID
                --AND OEH.ORDER_CATEGORY_CODE = 'RETURN' --因为启用了MIXED,
             AND OEH.ORDER_NUMBER = TO_NUMBER(P_SO_RECNT_INFO.SO_NUM) --参数
             AND OEH.ORG_ID = P_SO_RECNT_INFO.ERP_OU_ID --参数OU ID
           GROUP BY OEL.HEADER_ID,
                    DECODE(OEL.SHIPPABLE_FLAG,
                           'N',
                           'MODEL',
                           OEL.ITEM_TYPE_CODE),
                    LV.MEANING;
      
        --ERP系统的销售订单信息记录
        R_ERP_SO_INFO C_ERP_SO_INFO%ROWTYPE;
      BEGIN
        --获取ERP销售订单的产品总数和结算总金额
        FOR R_ERP_SO_INFO IN C_ERP_SO_INFO LOOP
          IF (P_RECNT_FLAG = V_FLAG_AUDIT) THEN
            --审核对账
            IF (R_ERP_SO_INFO.ITEM_TYPE_CODE = 'MODEL') AND
               (R_ERP_SO_INFO.STATUS IN
               (V_STATUS_ENTERED, V_STATUS_BOOKED, V_STATUS_CLOSED)) THEN
              V_ERP_QTY    := (V_ERP_QTY + R_ERP_SO_INFO.ORDERED_QUANTITY);
              V_ERP_AMOUNT := (V_ERP_AMOUNT + R_ERP_SO_INFO.AMOUNT);
            ELSIF (R_ERP_SO_INFO.ITEM_TYPE_CODE = 'STANDARD') AND
                  (R_ERP_SO_INFO.STATUS IN
                  (V_STATUS_ENTERED,
                    V_STATUS_AWAITING,
                    V_STATUS_RETURNED,
                    V_STATUS_CLOSED)) THEN
              V_ERP_QTY    := (V_ERP_QTY + R_ERP_SO_INFO.ORDERED_QUANTITY);
              V_ERP_AMOUNT := (V_ERP_AMOUNT + R_ERP_SO_INFO.AMOUNT);
            END IF;
          ELSIF (P_RECNT_FLAG = V_FLAG_SETTLE) THEN
            --结算对账
            IF (R_ERP_SO_INFO.ITEM_TYPE_CODE = 'MODEL') AND
               (R_ERP_SO_INFO.STATUS IN (V_STATUS_BOOKED, V_STATUS_CLOSED)) THEN
              V_ERP_QTY    := (V_ERP_QTY + R_ERP_SO_INFO.ORDERED_QUANTITY);
              V_ERP_AMOUNT := (V_ERP_AMOUNT + R_ERP_SO_INFO.AMOUNT);
            ELSIF (R_ERP_SO_INFO.ITEM_TYPE_CODE = 'STANDARD') AND
                  (R_ERP_SO_INFO.STATUS IN
                  (V_STATUS_AWAITING, V_STATUS_RETURNED, V_STATUS_CLOSED)) THEN
              V_ERP_QTY    := (V_ERP_QTY + R_ERP_SO_INFO.ORDERED_QUANTITY);
              V_ERP_AMOUNT := (V_ERP_AMOUNT + R_ERP_SO_INFO.AMOUNT);
            END IF;
          END IF;
        END LOOP;
      EXCEPTION
        WHEN OTHERS THEN
          P_ERR_MSG := V_BILL_TYPE_NAME || '[单据号：' ||
                       P_SO_RECNT_INFO.SO_NUM || ']对账发生异常：' || SQLERRM;
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      END;
    ELSIF V_BIZ_SRC_BILL_TYPE_CODE IN
          (PKG_SO_PUB.V_BIZ_SRC_BILL_SO_DISCOUNT,
           PKG_SO_PUB.V_BIZ_SRC_BILL_DISCOUNT) THEN
      --折让RMA
      --ERP的折让RMA（对应CIMS的销售折让单和折让证明单）
      DECLARE
        --ERP系统的销售订单信息
        CURSOR C_ERP_SO_INFO IS
          SELECT OEL.HEADER_ID,
                 OEL.ITEM_TYPE_CODE,
                 LV.MEANING AS STATUS,
                 SUM(OEL.ORDERED_QUANTITY) AS ORDERED_QUANTITY,
                 SUM(OEL.ORDERED_QUANTITY * OEL.UNIT_SELLING_PRICE) AS AMOUNT
            FROM APPS.OE_ORDER_LINES_ALL@MDIMS2MDERP   OEL,
                 APPS.OE_ORDER_HEADERS_ALL@MDIMS2MDERP OEH,
                 APPS.FND_LOOKUP_VALUES@MDIMS2MDERP    LV
           WHERE LV.LOOKUP_TYPE = 'LINE_FLOW_STATUS'
             AND LV.LOOKUP_CODE = OEL.FLOW_STATUS_CODE
             AND LV.LANGUAGE = 'US' --USERENV('LANG')
             AND LV.VIEW_APPLICATION_ID = 660
             AND OEH.HEADER_ID = OEL.HEADER_ID
                --AND OEH.ORDER_CATEGORY_CODE = 'RETURN' --因为启用了MIXED,
             AND OEH.ORDER_NUMBER = TO_NUMBER(P_SO_RECNT_INFO.SO_NUM) --参数
             AND OEH.ORG_ID = P_SO_RECNT_INFO.ERP_OU_ID --参数OU ID
           GROUP BY OEL.HEADER_ID, OEL.ITEM_TYPE_CODE, LV.MEANING;
      
        --ERP系统的销售订单信息记录
        R_ERP_SO_INFO C_ERP_SO_INFO%ROWTYPE;
      BEGIN
        --获取ERP销售订单的产品总数和结算总金额
        FOR R_ERP_SO_INFO IN C_ERP_SO_INFO LOOP
          IF (P_RECNT_FLAG = V_FLAG_AUDIT) THEN
            --审核对账
            IF (R_ERP_SO_INFO.ITEM_TYPE_CODE = 'STANDARD') AND
               (R_ERP_SO_INFO.STATUS IN
               (V_STATUS_ENTERED, V_STATUS_BOOKED, V_STATUS_CLOSED)) THEN
              V_ERP_QTY    := (V_ERP_QTY + R_ERP_SO_INFO.ORDERED_QUANTITY);
              V_ERP_AMOUNT := (V_ERP_AMOUNT + R_ERP_SO_INFO.AMOUNT);
            END IF;
          ELSIF (P_RECNT_FLAG = V_FLAG_SETTLE) THEN
            --结算对账
            IF (R_ERP_SO_INFO.ITEM_TYPE_CODE = 'STANDARD') AND
               (R_ERP_SO_INFO.STATUS IN (V_STATUS_BOOKED, V_STATUS_CLOSED)) THEN
              V_ERP_QTY    := (V_ERP_QTY + R_ERP_SO_INFO.ORDERED_QUANTITY);
              V_ERP_AMOUNT := (V_ERP_AMOUNT + R_ERP_SO_INFO.AMOUNT);
            END IF;
          END IF;
        END LOOP;
      EXCEPTION
        WHEN OTHERS THEN
          P_ERR_MSG := V_BILL_TYPE_NAME || '[单据号：' ||
                       P_SO_RECNT_INFO.SO_NUM || ']对账发生异常：' || SQLERRM;
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      END;
    ELSIF V_BIZ_SRC_BILL_TYPE_CODE IN
          (PKG_SO_PUB.V_BIZ_SRC_BILL_SO_DISCOUNT,
           PKG_SO_PUB.V_BIZ_SRC_BILL_DISCOUNT) THEN
      --折让销售订单
      --ERP的折让销售订单（对应CIMS的销售折让红冲单和折让证明红冲单）
      DECLARE
        --ERP系统的销售订单信息
        CURSOR C_ERP_SO_INFO IS
          SELECT OEL.HEADER_ID,
                 OEL.ITEM_TYPE_CODE,
                 LV.MEANING AS STATUS,
                 SUM(OEL.ORDERED_QUANTITY) AS ORDERED_QUANTITY,
                 SUM(OEL.ORDERED_QUANTITY * OEL.UNIT_SELLING_PRICE) AS AMOUNT
            FROM APPS.OE_ORDER_LINES_ALL@MDIMS2MDERP   OEL,
                 APPS.OE_ORDER_HEADERS_ALL@MDIMS2MDERP OEH,
                 APPS.FND_LOOKUP_VALUES@MDIMS2MDERP    LV
           WHERE LV.LOOKUP_TYPE = 'LINE_FLOW_STATUS'
             AND LV.LOOKUP_CODE = OEL.FLOW_STATUS_CODE
             AND LV.LANGUAGE = 'US' --USERENV('LANG')
             AND LV.VIEW_APPLICATION_ID = 660
             AND OEH.HEADER_ID = OEL.HEADER_ID
                --AND OEH.ORDER_CATEGORY_CODE = 'ORDER' --因为启用了MIXED,
             AND OEH.ORDER_NUMBER = TO_NUMBER(P_SO_RECNT_INFO.SO_NUM) --参数：
             AND OEH.ORG_ID = P_SO_RECNT_INFO.ERP_OU_ID --：参数OU ID
           GROUP BY OEL.HEADER_ID, OEL.ITEM_TYPE_CODE, LV.MEANING;
      
        --ERP系统的销售订单信息记录
        R_ERP_SO_INFO C_ERP_SO_INFO%ROWTYPE;
      BEGIN
        --获取ERP销售订单的产品总数和结算总金额
        FOR R_ERP_SO_INFO IN C_ERP_SO_INFO LOOP
          IF (P_RECNT_FLAG = V_FLAG_AUDIT) THEN
            --审核对账
            IF (R_ERP_SO_INFO.ITEM_TYPE_CODE = 'STANDARD') AND
               (R_ERP_SO_INFO.STATUS IN
               (V_STATUS_ENTERED, V_STATUS_BOOKED, V_STATUS_CLOSED)) THEN
              V_ERP_QTY    := (V_ERP_QTY + R_ERP_SO_INFO.ORDERED_QUANTITY);
              V_ERP_AMOUNT := (V_ERP_AMOUNT + R_ERP_SO_INFO.AMOUNT);
            END IF;
          ELSIF (P_RECNT_FLAG = V_FLAG_SETTLE) THEN
            --结算对账
            IF (R_ERP_SO_INFO.ITEM_TYPE_CODE = 'STANDARD') AND
               (R_ERP_SO_INFO.STATUS IN (V_STATUS_BOOKED, V_STATUS_CLOSED)) THEN
              V_ERP_QTY    := (V_ERP_QTY + R_ERP_SO_INFO.ORDERED_QUANTITY);
              V_ERP_AMOUNT := (V_ERP_AMOUNT + R_ERP_SO_INFO.AMOUNT);
            END IF;
          END IF;
        END LOOP;
      EXCEPTION
        WHEN OTHERS THEN
          P_ERR_MSG := V_BILL_TYPE_NAME || '[单据号：' ||
                       P_SO_RECNT_INFO.SO_NUM || ']对账发生异常：' || SQLERRM;
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      END;
    END IF;
  
    --取绝对值之前，先赋值给CIMS不含税金额  by sushu 2016-07-26
    V_CIMS_REV_AMOUNT := V_AMOUNT;
    --取绝对值
    V_QTY        := ABS(V_QTY);
    V_AMOUNT     := ABS(V_AMOUNT);
    V_ERP_QTY    := ABS(V_ERP_QTY);
    V_ERP_AMOUNT := ABS(V_ERP_AMOUNT);
  
    --如果数量或金额不相等，则表明对账失败。
    IF (V_QTY != V_ERP_QTY) THEN
      V_RECNT_FLAG := '00';
      V_MSG        := '数量不相等：CIMS系统的数量为' || V_QTY || '，ERP系统的数量为' ||
                      V_ERP_QTY || '。';
    END IF;
  
    IF (V_AMOUNT != V_ERP_AMOUNT) THEN
      V_RECNT_FLAG := '00';
      V_MSG        := V_MSG || '金额不相等：CIMS系统的结算金额为' || V_AMOUNT ||
                      '，ERP系统的结算金额为' || V_ERP_AMOUNT || '。';
    END IF;
  
    IF V_RECNT_FLAG = '00' THEN
      V_MSG := V_BILL_TYPE_NAME || '[' || P_SO_RECNT_INFO.SO_NUM ||
               ']对账失败：' || V_MSG;
    ELSE
      V_MSG := V_BILL_TYPE_NAME || '[' || P_SO_RECNT_INFO.SO_NUM ||
               ']对账成功.';
    END IF;
  
    --回写对帐表
    IF (P_RECNT_FLAG = V_FLAG_AUDIT) THEN
      --审核对账
      UPDATE T_SO_RECONCILIATION T
         SET AUDIT_RECNT_FLAG = V_RECNT_FLAG,
             AUDIT_RECNT_DESC = V_MSG,
             --AUDIT_RECNT_TIME = V_CURR_DATE,
             LAST_UPDATED_BY  = P_USER_CODE,
             LAST_UPDATE_DATE = V_CURR_DATE,
             REMARK           = P_USER_CODE ||
                                TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') ||
                                '重新审核对账' || CHR(10)
       WHERE RECNT_ID = P_SO_RECNT_INFO.RECNT_ID;
    ELSIF (P_RECNT_FLAG = V_FLAG_SETTLE) Then
      
      --销售对账增加结算日期、CIMS不含税收入、ERP不含税收入、ERP发票金额；
      --by sushu 2016-07-26
      --从销售单据上获取结算日期，发票号，org_id
      Begin
        Select Sh.Settle_Date, --结算日期 
               Sh.Erp_Arinvoice_Code, --发票号
               Sh.Erp_Ou_Id,
               Order_Type.Plus_Minus_Flag
          Into v_Settle_Date,
               v_Erp_Arinvoice_Code,
               v_Erp_Ou_Id,
               v_Plus_Minus_Flag
          From t_So_Header Sh, t_So_Type_Extend Order_Type
         Where Sh.So_Num = p_So_Recnt_Info.So_Num
           And Sh.Bill_Type_Id = Order_Type.Bill_Type_Id;
      Exception
        When Others Then
          p_Err_Msg := '获取销售单据的信息失败，单据号：' || p_So_Recnt_Info.So_Num ||
                       Sqlerrm;
          Raise Pkg_So_Pub.v_Biz_Exception;
      End;
      --根据ERP应收发票号、ERP的OU_ID获取ERP不含税收入、ERP发票金额
      Begin
        Select a.Rev_Amount, --ERP不含税收入
               a.Rec_Amount --ERP发票金额
          Into v_Erp_Rev_Amount, v_Erp_Rec_Amount
          From Apps.Cux_Erp_Ar_Cust_Trx_v@Mdims2mderp a
         Where a.Org_Id = v_Erp_Ou_Id
           And a.Trx_Number = v_Erp_Arinvoice_Code;
      Exception
        When Others Then
          p_Err_Msg := '获取ERP的不含税收入、ERP发票金额失败' || Sqlerrm;
          Raise Pkg_So_Pub.v_Biz_Exception;
      End;
      --CIMS不含税金额
      v_Cims_Rev_Amount := Round(v_Cims_Rev_Amount / 1.17, 2) *
                           v_Plus_Minus_Flag;
      --ERP不含税收入取两位小数
      v_Erp_Rev_Amount := Round(v_Erp_Rev_Amount, 2);
      --ERP发票金额取两位小数
      v_Erp_Rec_Amount := Round(v_Erp_Rec_Amount, 2);
      --CIMS不含税收入-ERP不含税收入差异，>1或者<-1为Y，其他为N
      If ((v_Cims_Rev_Amount - v_Erp_Rev_Amount) > 1 Or
         (v_Cims_Rev_Amount - v_Erp_Rev_Amount) < -1) Then
        v_Amount_Diff := 'Y';
      Else
        v_Amount_Diff := 'N';
      End If;
      
      --结算对账
      UPDATE T_SO_RECONCILIATION
         SET SETTLE_RECNT_FLAG = V_RECNT_FLAG,
             SETTLE_RECNT_DESC = V_MSG,
             --SETTLE_RECNT_TIME = V_CURR_DATE,
             STATUS           = '00', --结算对账后，把状态改为关闭
             LAST_UPDATED_BY  = P_USER_CODE,
             LAST_UPDATE_DATE = V_CURR_DATE,
             REMARK           = P_USER_CODE ||
                                TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') ||
                                '重新结算对账' || CHR(10),
             SETTLE_DATE       = V_SETTLE_DATE,     --by sushu 2016-07-26
             CIMS_REV_AMOUNT   = V_CIMS_REV_AMOUNT, --by sushu 2016-07-26
             ERP_REV_AMOUNT    = V_ERP_REV_AMOUNT,  --by sushu 2016-07-26
             ERP_REC_AMOUNT    = V_ERP_REC_AMOUNT,  --by sushu 2016-07-26
             AMOUNT_DIFF       = V_AMOUNT_DIFF      --by sushu 2016-07-26
       WHERE RECNT_ID = P_SO_RECNT_INFO.RECNT_ID;
    END IF;
  
    --回写对帐标识到T_SO_HEADER表
    UPDATE T_SO_HEADER
       SET CHECKED_ACCOUNT_FLAG = 'Y', CHECKED_ACCOUNT_DATE = V_CURR_DATE
     WHERE SO_HEADER_ID = P_SO_RECNT_INFO.SO_HEADER_ID;
  
  EXCEPTION
    /*WHEN PKG_SO_PUB.V_BIZ_EXCEPTION THEN
    P_RESULT  := -28211;
    P_ERR_MSG := '对账处理出错：' || P_ERR_MSG;*/
    WHEN OTHERS THEN
      P_ERR_MSG := P_ERR_MSG || SQLERRM;
      UPDATE T_SO_RECONCILIATION
         SET REMARK = TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') ||
                      '重新结算对账出错：' || P_ERR_MSG
       WHERE RECNT_ID = P_SO_RECNT_INFO.RECNT_ID;
      /*P_RESULT  := -28211;
      P_ERR_MSG := '对账处理异常：' || SQLERRM;*/
  END;
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-01-22
  *     创建者：陈武杰
  *   功能说明：重算销售对账过程
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_RE_RECONCILIATION(P_USER_CODE IN VARCHAR2, --操作用户编码
                                   P_RESULT    OUT NUMBER, --返回错误ID
                                   P_ERR_MSG   OUT VARCHAR2 --返回错误信息
                                   ) IS
    --操作用户账号
    V_USER_CODE VARCHAR2(32);
    V_CURR_DATE DATE := SYSDATE;
  
    --未审核对账或对账失败，且状态为打开的记录
    CURSOR C_SO_RECNT_AUDIT IS
      SELECT A.RECNT_ID,
             A.SO_HEADER_ID,
             A.SO_NUM,
             A.ERP_OU_ID,
             A.BILL_TYPE_NAME,
             A.BIZ_SRC_BILL_TYPE_CODE
        FROM T_SO_RECONCILIATION A, T_SO_HEADER SH
       WHERE A.SO_NUM = SH.SO_NUM
         AND SH.ERP_SO_ID IS NOT NULL
         AND A.AUDIT_RECNT_FLAG = '00'; --只对已经审核对账过数据重新对账，对audit_recnt_flag等于空不重新对账;
    R_SO_RECNT_AUDIT C_SO_RECNT_AUDIT%ROWTYPE;
  
    --未结算对账或对账失败，且状态为打开的记录
    CURSOR C_SO_RECNT_SETTLE IS
      SELECT SR.RECNT_ID,
             SR.SO_HEADER_ID,
             SR.SO_NUM,
             SR.ERP_OU_ID,
             SR.BILL_TYPE_NAME,
             SR.BIZ_SRC_BILL_TYPE_CODE
        FROM T_SO_RECONCILIATION SR, T_SO_HEADER SH
       WHERE SR.SO_NUM = SH.SO_NUM
         AND SR.AUDIT_RECNT_FLAG IS NOT NULL
         AND NVL(SH.ERP_BOOKED_FLAG, 'N') = 'Y'
         AND SR.SETTLE_RECNT_FLAG = '00'; --只对已经结算对账过数据重新对账，对SETTLE_RECNT_FLAG等于空不重新对账;
    R_SO_RECNT_SETTLE C_SO_RECNT_SETTLE%ROWTYPE;
  
    --对账信息记录集
    V_SO_RECNT_INFO SO_RECNT_INFO;
  
  BEGIN
    --初始返回值
    P_RESULT  := PKG_SO_PUB.V_RESULT;
    P_ERR_MSG := PKG_SO_PUB.V_SUCCESS;
  
    IF (P_USER_CODE IS NULL) THEN
      V_USER_CODE := PKG_SO_PUB.V_CREATED_BY_SYS;
    ELSE
      V_USER_CODE := P_USER_CODE;
    END IF;
  
    --审核对账
    FOR R_SO_RECNT_AUDIT IN C_SO_RECNT_AUDIT LOOP
      V_SO_RECNT_INFO.RECNT_ID               := R_SO_RECNT_AUDIT.RECNT_ID;
      V_SO_RECNT_INFO.SO_HEADER_ID           := R_SO_RECNT_AUDIT.SO_HEADER_ID;
      V_SO_RECNT_INFO.SO_NUM                 := R_SO_RECNT_AUDIT.SO_NUM;
      V_SO_RECNT_INFO.ERP_OU_ID              := R_SO_RECNT_AUDIT.ERP_OU_ID;
      V_SO_RECNT_INFO.BILL_TYPE_NAME         := R_SO_RECNT_AUDIT.BILL_TYPE_NAME;
      V_SO_RECNT_INFO.BIZ_SRC_BILL_TYPE_CODE := R_SO_RECNT_AUDIT.BIZ_SRC_BILL_TYPE_CODE;
    
      --重对账处理
      P_SO_RE_RECONCILIATION_PROCESS(V_SO_RECNT_INFO,
                                     V_FLAG_AUDIT,
                                     V_USER_CODE,
                                     P_RESULT,
                                     P_ERR_MSG);
      IF P_RESULT < 0 THEN
        RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      END IF;
    END LOOP;
  
    --结算对账
    FOR R_SO_RECNT_SETTLE IN C_SO_RECNT_SETTLE LOOP
      V_SO_RECNT_INFO.RECNT_ID               := R_SO_RECNT_SETTLE.RECNT_ID;
      V_SO_RECNT_INFO.SO_HEADER_ID           := R_SO_RECNT_SETTLE.SO_HEADER_ID;
      V_SO_RECNT_INFO.SO_NUM                 := R_SO_RECNT_SETTLE.SO_NUM;
      V_SO_RECNT_INFO.ERP_OU_ID              := R_SO_RECNT_SETTLE.ERP_OU_ID;
      V_SO_RECNT_INFO.BILL_TYPE_NAME         := R_SO_RECNT_SETTLE.BILL_TYPE_NAME;
      V_SO_RECNT_INFO.BIZ_SRC_BILL_TYPE_CODE := R_SO_RECNT_SETTLE.BIZ_SRC_BILL_TYPE_CODE;
    
      P_SO_RE_RECONCILIATION_PROCESS(V_SO_RECNT_INFO,
                                     V_FLAG_SETTLE,
                                     V_USER_CODE,
                                     P_RESULT,
                                     P_ERR_MSG);
      IF P_RESULT < 0 THEN
        RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      END IF;
    END LOOP;
  
  EXCEPTION
    /*WHEN PKG_SO_PUB.V_BIZ_EXCEPTION THEN
    P_RESULT  := -28210;
    P_ERR_MSG := '销售对账出错，' || P_ERR_MSG;*/
    WHEN OTHERS THEN
      P_RESULT  := -28210;
      P_ERR_MSG := '销售对账发生异常，' || SQLERRM;
  END;

  /*测试*/

  PROCEDURE P_SO_JIESUAN(P_SO_HEADER_ID IN NUMBER, --销售对账记录
                         P_RECNT_FLAG   IN VARCHAR2, --对帐类型标识：A审核对账，S结算对账
                         P_ERP_QTY      OUT NUMBER,
                         P_ERP_AMOUNT   OUT NUMBER,
                         P_RESULT       OUT NUMBER, --返回错误ID
                         P_ERR_MSG      OUT VARCHAR2 --返回错误信息
                         ) IS
    --财务单源类型
    V_BILL_TYPE_NAME         T_SO_HEADER.BILL_TYPE_NAME%TYPE;
    V_BIZ_SRC_BILL_TYPE_CODE T_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE%TYPE;
  
    CURSOR C_SO_HEADER IS
      SELECT * FROM T_SO_HEADER WHERE SO_HEADER_ID = P_SO_HEADER_ID;
  
    --销售单据头信息记录
    P_SO_RECNT_INFO C_SO_HEADER%ROWTYPE;
  
    --财务单信息
    CURSOR C_SO_INFO IS(
    --套件行
      SELECT SO_HEADER_ID,
             'MODEL' AS ITEM_TYPE_CODE,
             SUM(NVL(ITEM_QTY, 0)) AS QTY,
             SUM(NVL(ITEM_SETTLE_AMOUNT, 0)) AS AMOUNT
        FROM T_SO_LINE
       WHERE SO_HEADER_ID = P_SO_RECNT_INFO.SO_HEADER_ID
         AND ITEM_IS_SET = 'Y'
       GROUP BY SO_HEADER_ID
      UNION
      --散件行
      SELECT SL.SO_HEADER_ID,
             DECODE(SL.ITEM_IS_SET, 'Y', 'OPTION', 'STANDARD') AS ITEM_TYPE_CODE,
             SUM(NVL(SLD.COMPONENT_QTY, 0)) AS QTY,
             SUM(NVL(SLD.COMPONENT_SETTLE_PRICE, 0) *
                 NVL(SLD.COMPONENT_QTY, 0)) AS AMOUNT
        FROM T_SO_LINE SL, T_SO_LINE_DETAIL SLD
       WHERE SL.SO_LINE_ID = SLD.SO_LINE_ID
         AND SL.SO_HEADER_ID = P_SO_RECNT_INFO.SO_HEADER_ID
       GROUP BY SL.SO_HEADER_ID,
                DECODE(SL.ITEM_IS_SET, 'Y', 'OPTION', 'STANDARD'));
    --财务单信息记录
    R_SO_INFO C_SO_INFO%ROWTYPE;
  
    --CIMS系统财务单产品数量和结算总金额
    V_QTY    NUMBER := 0;
    V_AMOUNT NUMBER := 0;
  
    --ERP系统销售订单产品数量和结算总金额
    V_ERP_QTY    NUMBER := 0;
    V_ERP_AMOUNT NUMBER := 0;
  
    --ERP系统销售订单在各阶段的状态
    V_STATUS_ENTERED   VARCHAR2(10) := 'Entered';
    V_STATUS_FULFILLED VARCHAR2(10) := 'Fulfilled';
    V_STATUS_CLOSED    VARCHAR2(10) := 'Closed';
    V_STATUS_BOOKED    VARCHAR2(10) := 'Booked';
    V_STATUS_RETURNED  VARCHAR2(10) := 'Returned';
    V_STATUS_AWAITING  VARCHAR2(20) := 'Awaiting Return';
  
    --对账信息
    V_MSG VARCHAR2(2048) := '';
    --对账是否成功：失败 00，成功 01
    V_RECNT_FLAG VARCHAR2(2) := '01';
    --当前系统日期时间
    V_CURR_DATE DATE := SYSDATE;
  
  BEGIN
    --初始返回值
    P_RESULT  := PKG_SO_PUB.V_RESULT;
    P_ERR_MSG := PKG_SO_PUB.V_SUCCESS;
  
    --计算CIMS财务单行产品数量和结算总金额
    FOR R_SO_INFO IN C_SO_INFO LOOP
      V_QTY    := V_QTY + R_SO_INFO.QTY;
      V_AMOUNT := V_AMOUNT + R_SO_INFO.AMOUNT;
    END LOOP;
  
    --财务单源类型
    V_BILL_TYPE_NAME         := P_SO_RECNT_INFO.BILL_TYPE_NAME;
    V_BIZ_SRC_BILL_TYPE_CODE := P_SO_RECNT_INFO.BIZ_SRC_BILL_TYPE_CODE;
  
    IF V_BIZ_SRC_BILL_TYPE_CODE IN
       (PKG_SO_PUB.V_BIZ_SRC_BILL_SO, PKG_SO_PUB.V_BIZ_SRC_BILL_RETURN_RED) THEN
      --销售订单，除折让
      --ERP的销售订单（对应CIMS的销售单和退货红冲单）
      DECLARE
        --ERP系统的销售订单信息
        CURSOR C_ERP_SO_INFO IS
          SELECT OEL.HEADER_ID,
                 LV.MEANING AS STATUS,
                 SUM(OEL.ORDERED_QUANTITY) AS ORDERED_QUANTITY,
                 SUM(OEL.ORDERED_QUANTITY * OEL.UNIT_SELLING_PRICE) AS AMOUNT
            FROM APPS.OE_ORDER_LINES_ALL@MDIMS2MDERP   OEL,
                 APPS.OE_ORDER_HEADERS_ALL@MDIMS2MDERP OEH,
                 APPS.FND_LOOKUP_VALUES@MDIMS2MDERP    LV
           WHERE LV.LOOKUP_TYPE = 'LINE_FLOW_STATUS'
             AND LV.LOOKUP_CODE = OEL.FLOW_STATUS_CODE
             AND LV.LANGUAGE = 'US' --USERENV('LANG')
             AND LV.VIEW_APPLICATION_ID = 660
             AND OEH.HEADER_ID = OEL.HEADER_ID
                --AND OEL.LINE_CATEGORY_CODE = 'ORDER',--因为启用了MIXED,
             AND OEH.ORDER_NUMBER = TO_NUMBER(P_SO_RECNT_INFO.SO_NUM) --参数
             AND OEH.ORG_ID = P_SO_RECNT_INFO.ERP_OU_ID --参数OU ID
           GROUP BY OEL.HEADER_ID, LV.MEANING;
      
        --ERP系统的销售订单信息记录
        R_ERP_SO_INFO C_ERP_SO_INFO%ROWTYPE;
      
      BEGIN
        --获取ERP销售订单的产品总数和结算总金额
        FOR R_ERP_SO_INFO IN C_ERP_SO_INFO LOOP
          IF (P_RECNT_FLAG = V_FLAG_AUDIT) THEN
            --审核对账
            IF R_ERP_SO_INFO.STATUS IN
               (V_STATUS_ENTERED, V_STATUS_FULFILLED, V_STATUS_CLOSED) THEN
              V_ERP_QTY    := (V_ERP_QTY + R_ERP_SO_INFO.ORDERED_QUANTITY);
              V_ERP_AMOUNT := (V_ERP_AMOUNT + R_ERP_SO_INFO.AMOUNT);
            END IF;
          ELSIF (P_RECNT_FLAG = V_FLAG_SETTLE) THEN
            --结算对账
            IF R_ERP_SO_INFO.STATUS IN
               (V_STATUS_FULFILLED, V_STATUS_CLOSED) THEN
              V_ERP_QTY    := (V_ERP_QTY + R_ERP_SO_INFO.ORDERED_QUANTITY);
              V_ERP_AMOUNT := (V_ERP_AMOUNT + R_ERP_SO_INFO.AMOUNT);
            END IF;
          END IF;
        END LOOP;
      EXCEPTION
        WHEN OTHERS THEN
          P_ERR_MSG := V_BILL_TYPE_NAME || '[单据号：' ||
                       P_SO_RECNT_INFO.SO_NUM || ']对账发生异常：' || SQLERRM;
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      END;
    ELSIF V_BIZ_SRC_BILL_TYPE_CODE IN
          (PKG_SO_PUB.V_BIZ_SRC_BILL_RETURN,
           PKG_SO_PUB.V_BIZ_SRC_BILL_SO_RED) THEN
      --RMA，除折让
      --ERP的RMA（对应CIMS的退货单和销售红冲单）
      DECLARE
        --ERP系统的销售订单信息
        CURSOR C_ERP_SO_INFO IS
          SELECT OEL.HEADER_ID,
                 DECODE(OEL.SHIPPABLE_FLAG,
                        'N',
                        'MODEL',
                        OEL.ITEM_TYPE_CODE) AS ITEM_TYPE_CODE,
                 LV.MEANING AS STATUS,
                 SUM(OEL.ORDERED_QUANTITY) AS ORDERED_QUANTITY,
                 SUM(OEL.ORDERED_QUANTITY * OEL.UNIT_SELLING_PRICE) AS AMOUNT
            FROM APPS.OE_ORDER_LINES_ALL@MDIMS2MDERP   OEL,
                 APPS.OE_ORDER_HEADERS_ALL@MDIMS2MDERP OEH,
                 APPS.FND_LOOKUP_VALUES@MDIMS2MDERP    LV
           WHERE LV.LOOKUP_TYPE = 'LINE_FLOW_STATUS'
             AND LV.LOOKUP_CODE = OEL.FLOW_STATUS_CODE
             AND LV.LANGUAGE = 'US' --USERENV('LANG')
             AND LV.VIEW_APPLICATION_ID = 660
             AND OEH.HEADER_ID = OEL.HEADER_ID
                --AND OEH.ORDER_CATEGORY_CODE = 'RETURN' --因为启用了MIXED,
             AND OEH.ORDER_NUMBER = TO_NUMBER(P_SO_RECNT_INFO.SO_NUM) --参数
             AND OEH.ORG_ID = P_SO_RECNT_INFO.ERP_OU_ID --参数OU ID
           GROUP BY OEL.HEADER_ID,
                    DECODE(OEL.SHIPPABLE_FLAG,
                           'N',
                           'MODEL',
                           OEL.ITEM_TYPE_CODE),
                    LV.MEANING;
      
        --ERP系统的销售订单信息记录
        R_ERP_SO_INFO C_ERP_SO_INFO%ROWTYPE;
      BEGIN
        --获取ERP销售订单的产品总数和结算总金额
        FOR R_ERP_SO_INFO IN C_ERP_SO_INFO LOOP
          IF (P_RECNT_FLAG = V_FLAG_AUDIT) THEN
            --审核对账
            IF (R_ERP_SO_INFO.ITEM_TYPE_CODE = 'MODEL') AND
               (R_ERP_SO_INFO.STATUS IN
               (V_STATUS_ENTERED, V_STATUS_BOOKED, V_STATUS_CLOSED)) THEN
              V_ERP_QTY    := (V_ERP_QTY + R_ERP_SO_INFO.ORDERED_QUANTITY);
              V_ERP_AMOUNT := (V_ERP_AMOUNT + R_ERP_SO_INFO.AMOUNT);
            ELSIF (R_ERP_SO_INFO.ITEM_TYPE_CODE = 'STANDARD') AND
                  (R_ERP_SO_INFO.STATUS IN
                  (V_STATUS_ENTERED,
                    V_STATUS_AWAITING,
                    V_STATUS_RETURNED,
                    V_STATUS_CLOSED)) THEN
              V_ERP_QTY    := (V_ERP_QTY + R_ERP_SO_INFO.ORDERED_QUANTITY);
              V_ERP_AMOUNT := (V_ERP_AMOUNT + R_ERP_SO_INFO.AMOUNT);
            END IF;
          ELSIF (P_RECNT_FLAG = V_FLAG_SETTLE) THEN
            --结算对账
            IF (R_ERP_SO_INFO.ITEM_TYPE_CODE = 'MODEL') AND
               (R_ERP_SO_INFO.STATUS IN (V_STATUS_BOOKED, V_STATUS_CLOSED)) THEN
              V_ERP_QTY    := (V_ERP_QTY + R_ERP_SO_INFO.ORDERED_QUANTITY);
              V_ERP_AMOUNT := (V_ERP_AMOUNT + R_ERP_SO_INFO.AMOUNT);
            ELSIF (R_ERP_SO_INFO.ITEM_TYPE_CODE = 'STANDARD') AND
                  (R_ERP_SO_INFO.STATUS IN
                  (V_STATUS_AWAITING, V_STATUS_RETURNED, V_STATUS_CLOSED)) THEN
              V_ERP_QTY    := (V_ERP_QTY + R_ERP_SO_INFO.ORDERED_QUANTITY);
              V_ERP_AMOUNT := (V_ERP_AMOUNT + R_ERP_SO_INFO.AMOUNT);
            END IF;
          END IF;
        END LOOP;
      EXCEPTION
        WHEN OTHERS THEN
          P_ERR_MSG := V_BILL_TYPE_NAME || '[单据号：' ||
                       P_SO_RECNT_INFO.SO_NUM || ']对账发生异常：' || SQLERRM;
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      END;
    ELSIF V_BIZ_SRC_BILL_TYPE_CODE IN
          (PKG_SO_PUB.V_BIZ_SRC_BILL_SO_DISCOUNT,
           PKG_SO_PUB.V_BIZ_SRC_BILL_DISCOUNT) THEN
      --折让RMA
      --ERP的折让RMA（对应CIMS的销售折让单和折让证明单）
      DECLARE
        --ERP系统的销售订单信息
        CURSOR C_ERP_SO_INFO IS
          SELECT OEL.HEADER_ID,
                 OEL.ITEM_TYPE_CODE,
                 LV.MEANING AS STATUS,
                 SUM(OEL.ORDERED_QUANTITY) AS ORDERED_QUANTITY,
                 SUM(OEL.ORDERED_QUANTITY * OEL.UNIT_SELLING_PRICE) AS AMOUNT
            FROM APPS.OE_ORDER_LINES_ALL@MDIMS2MDERP   OEL,
                 APPS.OE_ORDER_HEADERS_ALL@MDIMS2MDERP OEH,
                 APPS.FND_LOOKUP_VALUES@MDIMS2MDERP    LV
           WHERE LV.LOOKUP_TYPE = 'LINE_FLOW_STATUS'
             AND LV.LOOKUP_CODE = OEL.FLOW_STATUS_CODE
             AND LV.LANGUAGE = 'US' --USERENV('LANG')
             AND LV.VIEW_APPLICATION_ID = 660
             AND OEH.HEADER_ID = OEL.HEADER_ID
                --AND OEH.ORDER_CATEGORY_CODE = 'RETURN' --因为启用了MIXED,
             AND OEH.ORDER_NUMBER = TO_NUMBER(P_SO_RECNT_INFO.SO_NUM) --参数
             AND OEH.ORG_ID = P_SO_RECNT_INFO.ERP_OU_ID --参数OU ID
           GROUP BY OEL.HEADER_ID, OEL.ITEM_TYPE_CODE, LV.MEANING;
      
        --ERP系统的销售订单信息记录
        R_ERP_SO_INFO C_ERP_SO_INFO%ROWTYPE;
      BEGIN
        --获取ERP销售订单的产品总数和结算总金额
        FOR R_ERP_SO_INFO IN C_ERP_SO_INFO LOOP
          IF (P_RECNT_FLAG = V_FLAG_AUDIT) THEN
            --审核对账
            IF (R_ERP_SO_INFO.ITEM_TYPE_CODE = 'STANDARD') AND
               (R_ERP_SO_INFO.STATUS IN
               (V_STATUS_ENTERED, V_STATUS_BOOKED, V_STATUS_CLOSED)) THEN
              V_ERP_QTY    := (V_ERP_QTY + R_ERP_SO_INFO.ORDERED_QUANTITY);
              V_ERP_AMOUNT := (V_ERP_AMOUNT + R_ERP_SO_INFO.AMOUNT);
            END IF;
          ELSIF (P_RECNT_FLAG = V_FLAG_SETTLE) THEN
            --结算对账
            IF (R_ERP_SO_INFO.ITEM_TYPE_CODE = 'STANDARD') AND
               (R_ERP_SO_INFO.STATUS IN (V_STATUS_BOOKED, V_STATUS_CLOSED)) THEN
              V_ERP_QTY    := (V_ERP_QTY + R_ERP_SO_INFO.ORDERED_QUANTITY);
              V_ERP_AMOUNT := (V_ERP_AMOUNT + R_ERP_SO_INFO.AMOUNT);
            END IF;
          END IF;
        END LOOP;
      EXCEPTION
        WHEN OTHERS THEN
          P_ERR_MSG := V_BILL_TYPE_NAME || '[单据号：' ||
                       P_SO_RECNT_INFO.SO_NUM || ']对账发生异常：' || SQLERRM;
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      END;
    ELSIF V_BIZ_SRC_BILL_TYPE_CODE IN
          (PKG_SO_PUB.V_BIZ_SRC_BILL_SO_DISCOUNT,
           PKG_SO_PUB.V_BIZ_SRC_BILL_DISCOUNT) THEN
      --折让销售订单
      --ERP的折让销售订单（对应CIMS的销售折让红冲单和折让证明红冲单）
      DECLARE
        --ERP系统的销售订单信息
        CURSOR C_ERP_SO_INFO IS
          SELECT OEL.HEADER_ID,
                 OEL.ITEM_TYPE_CODE,
                 LV.MEANING AS STATUS,
                 SUM(OEL.ORDERED_QUANTITY) AS ORDERED_QUANTITY,
                 SUM(OEL.ORDERED_QUANTITY * OEL.UNIT_SELLING_PRICE) AS AMOUNT
            FROM APPS.OE_ORDER_LINES_ALL@MDIMS2MDERP   OEL,
                 APPS.OE_ORDER_HEADERS_ALL@MDIMS2MDERP OEH,
                 APPS.FND_LOOKUP_VALUES@MDIMS2MDERP    LV
           WHERE LV.LOOKUP_TYPE = 'LINE_FLOW_STATUS'
             AND LV.LOOKUP_CODE = OEL.FLOW_STATUS_CODE
             AND LV.LANGUAGE = 'US' --USERENV('LANG')
             AND LV.VIEW_APPLICATION_ID = 660
             AND OEH.HEADER_ID = OEL.HEADER_ID
                --AND OEH.ORDER_CATEGORY_CODE = 'ORDER' --因为启用了MIXED,
             AND OEH.ORDER_NUMBER = TO_NUMBER(P_SO_RECNT_INFO.SO_NUM) --参数：
             AND OEH.ORG_ID = P_SO_RECNT_INFO.ERP_OU_ID --：参数OU ID
           GROUP BY OEL.HEADER_ID, OEL.ITEM_TYPE_CODE, LV.MEANING;
      
        --ERP系统的销售订单信息记录
        R_ERP_SO_INFO C_ERP_SO_INFO%ROWTYPE;
      BEGIN
        --获取ERP销售订单的产品总数和结算总金额
        FOR R_ERP_SO_INFO IN C_ERP_SO_INFO LOOP
          IF (P_RECNT_FLAG = V_FLAG_AUDIT) THEN
            --审核对账
            IF (R_ERP_SO_INFO.ITEM_TYPE_CODE = 'STANDARD') AND
               (R_ERP_SO_INFO.STATUS IN
               (V_STATUS_ENTERED, V_STATUS_BOOKED, V_STATUS_CLOSED)) THEN
              V_ERP_QTY    := (V_ERP_QTY + R_ERP_SO_INFO.ORDERED_QUANTITY);
              V_ERP_AMOUNT := (V_ERP_AMOUNT + R_ERP_SO_INFO.AMOUNT);
            END IF;
          ELSIF (P_RECNT_FLAG = V_FLAG_SETTLE) THEN
            --结算对账
            IF (R_ERP_SO_INFO.ITEM_TYPE_CODE = 'STANDARD') AND
               (R_ERP_SO_INFO.STATUS IN (V_STATUS_BOOKED, V_STATUS_CLOSED)) THEN
              V_ERP_QTY    := (V_ERP_QTY + R_ERP_SO_INFO.ORDERED_QUANTITY);
              V_ERP_AMOUNT := (V_ERP_AMOUNT + R_ERP_SO_INFO.AMOUNT);
            END IF;
          END IF;
        END LOOP;
      EXCEPTION
        WHEN OTHERS THEN
          P_ERR_MSG := V_BILL_TYPE_NAME || '[单据号：' ||
                       P_SO_RECNT_INFO.SO_NUM || ']对账发生异常：' || SQLERRM;
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      END;
    END IF;
  
    --取绝对值
    V_QTY        := ABS(V_QTY);
    V_AMOUNT     := ABS(V_AMOUNT);
    P_ERP_QTY    := ABS(V_ERP_QTY);
    P_ERP_AMOUNT := ABS(V_ERP_AMOUNT);
  
  EXCEPTION
    /*WHEN PKG_SO_PUB.V_BIZ_EXCEPTION THEN
    P_RESULT  := -28211;
    P_ERR_MSG := '对账处理出错：' || P_ERR_MSG;*/
    WHEN OTHERS THEN
    
      P_RESULT  := -28211;
      P_ERR_MSG := '对账处理异常：' || SQLERRM;
  END;
  
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-05-04
  *     创建者：申广延
  *   功能说明：子库转移ERP对账
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_COMP2ERP_SUBINV(P_SO_RECNT_INFO IN SO_RECNT_INFO, --销售对账记录
                                        P_COUNT_LINE    OUT NUMBER,
                                        P_QTY           OUT NUMBER,
                                        P_RESULT        OUT NUMBER, --返回错误ID
                                        P_ERR_MSG       OUT VARCHAR2 --返回错误信息
                                        ) IS

    --财务单源类型
    --V_BIZ_SRC_BILL_TYPE_CODE T_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE%TYPE;

    V_SRV_INV_CODE T_SO_HEADER.MIDDLE_INV_CODE%TYPE;
    V_SRV_INV_ORG_CODE T_SO_HEADER.ERP_SUBINV_CODE%TYPE;--仓库组织机构
    V_COUNT_LINE NUMBER := 0;
    V_TOTAL_QTY NUMBER := 0;
  BEGIN
    --初始返回值
    P_RESULT  := PKG_SO_PUB.V_RESULT;
    P_ERR_MSG := PKG_SO_PUB.V_SUCCESS;
  
    --财务单源类型
    --V_BIZ_SRC_BILL_TYPE_CODE := P_SO_RECNT_INFO.BIZ_SRC_BILL_TYPE_CODE;
    
    /*
           单据类型     来源子库    目标子库
           销售单       发货仓      中间仓  
           销售红冲单   中间仓      发货仓  
           退货单       中间仓      收货仓  
           退货红冲单   收货仓      中间仓  
    */  
    SELECT CASE BIZ_SRC_BILL_TYPE_CODE WHEN PKG_SO_PUB.V_BIZ_SRC_BILL_SO THEN SHIP_INV_CODE
                                      WHEN PKG_SO_PUB.V_BIZ_SRC_BILL_SO_RED THEN MIDDLE_INV_CODE
                                      WHEN PKG_SO_PUB.V_BIZ_SRC_BILL_RETURN THEN MIDDLE_INV_CODE
                                      WHEN PKG_SO_PUB.V_BIZ_SRC_BILL_RETURN_RED THEN CONSIGNEE_INV_CODE 
                                      ELSE SHIP_INV_CODE END 
    INTO V_SRV_INV_CODE                                    
    FROM T_SO_HEADER
    WHERE SO_HEADER_ID = P_SO_RECNT_INFO.SO_HEADER_ID; 
    
    SELECT ORGANIZATION_CODE 
    INTO V_SRV_INV_ORG_CODE
    FROM T_INV_INVENTORIES
    WHERE INVENTORY_CODE = V_SRV_INV_CODE
    AND ENTITY_ID = P_SO_RECNT_INFO.ENTITY_ID;

  SELECT count(0) count_line, --大于等于CIMS行数
  nvl(sum(decode(mmt.subinventory_code,V_SRV_INV_CODE, mmt.TRANSACTION_QUANTITY,0)),0) total_qty--1.参数：M29C44F190是调出子库
  INTO V_COUNT_LINE,V_TOTAL_QTY
  FROM APPS.MTL_MATERIAL_TRANSACTIONS@mdims2mderp mmt, APPS.org_organization_definitions@mdims2mderp ood
  WHERE mmt.ORGANIZATION_ID = ood.ORGANIZATION_ID
  and TRANSACTION_TYPE_ID = 2 --固定值，事务处理类型：子库存转移
  -- and mmt.TRANSACTION_ACTION_ID = 2 --固定值，ACTION：Subinventory transfer
  AND TRANSACTION_SOURCE_TYPE_ID = 13 --固定值，来源类型：库存
  --and to_char(mmt.transaction_date,'YYMM') = '1504'--2.参数：事物处理日期范围，CIMS和ERP的交易要发生在同一个期间
  and (mmt.LOGICAL_TRANSACTION = 2 OR mmt.LOGICAL_TRANSACTION IS NULL) --固定值
  and mmt.TRANSACTION_QUANTITY < 0 --固定值：在途仓有多笔进出，只统计出
  and mmt.TRANSACTION_REFERENCE = P_SO_RECNT_INFO.SO_NUM --3.参数：CIMS单据号
  and organization_code = V_SRV_INV_ORG_CODE; --4.参数：库存组织代码
  
  P_COUNT_LINE := V_COUNT_LINE;  		    
  P_QTY := ABS(V_TOTAL_QTY);--子库转移
  
  EXCEPTION
    WHEN PKG_SO_PUB.V_BIZ_EXCEPTION THEN
      P_RESULT  := -28211;
      P_ERR_MSG := '子库转移ERP对账取数出错：' || P_ERR_MSG;
    WHEN OTHERS THEN
      P_RESULT  := -28211;
      P_ERR_MSG := '子库转移ERP对账取数异常：' || SQLERRM;
  END;  
  
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-05-04
  *     创建者：申广延
  *   功能说明：PO对账
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_COMP2ERP_PO(P_SO_RECNT_INFO IN SO_RECNT_INFO, --销售对账记录
                                        P_QTY           OUT NUMBER,
                                        P_RESULT        OUT NUMBER, --返回错误ID
                                        P_ERR_MSG       OUT VARCHAR2 --返回错误信息
                                        ) IS
    --财务单源类型
    V_BIZ_SRC_BILL_TYPE_CODE T_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE%TYPE;
    V_PO_NUMBER VARCHAR2(100);
    V_ORDER_NUMBER VARCHAR2(100);
    V_ERP_OU_ID VARCHAR2(100);
    V_FACTORY_OU_ID VARCHAR2(100);
    V_OU_ID VARCHAR2(100);
    
    
    
    V_ORDER_QTY NUMBER;
    V_CANCEL_QTY NUMBER;
    V_DELI_QTY NUMBER;
    V_ORDER_AMT NUMBER;
    V_CANCEL_AMT NUMBER;
    V_DELI_AMT NUMBER;     
    
  BEGIN
    --初始返回值
    P_RESULT  := PKG_SO_PUB.V_RESULT;
    P_ERR_MSG := PKG_SO_PUB.V_SUCCESS;
  
    V_BIZ_SRC_BILL_TYPE_CODE := P_SO_RECNT_INFO.BIZ_SRC_BILL_TYPE_CODE;
    
    
   select po_number, --销售组织，从工厂采购的PO号
         order_number, --工厂，销售订单号            
         requirement_org_id, --销售OU ID
         supplier_org_id     --工厂OU ID
    INTO V_PO_NUMBER,V_ORDER_NUMBER,V_ERP_OU_ID,V_FACTORY_OU_ID     
    from apps.CUX_ICP_LOGIST_REQ_LINES_V@mdims2mderp
   where req_header_id = P_SO_RECNT_INFO.ERP_LOGIST_HEADER_ID; --参数：关联物流号 


/* 
分类	对账单据类型	对账项目
正向	销售单、退货红冲单	工厂OU：子库转移
                        内销OU：客户SO
                        内销OU：PO（关联交易） --
销售折让、折让证明单(与推式相同)	　
--------------------------------
反向	源单退回 : 销售红冲单、退货单
                        (无需对账)	工厂OU：子库转移
                        内销OU：客户RMA
                        内销OU：PO退回（关联交易） --
反向销售: 退货单	工厂OU：子库转移
                        内销OU：客户RMA
                        工厂OU：PO（关联交易） --
销售折让红冲、折让证明红冲单(与推式相同)	　
*/
/*
    IF V_BIZ_SRC_BILL_TYPE_CODE = PKG_SO_PUB.V_BIZ_SRC_BILL_RETURN AND P_SO_RECNT_INFO.RETURN_MODE = '3' THEN --拉式反向销售
       V_OU_ID := V_FACTORY_OU_ID;
    ELSE 
       V_OU_ID := V_ERP_OU_ID;
    END IF;
*/
  V_OU_ID := V_ERP_OU_ID; 
    
  SELECT sum(pod.QUANTITY_ORDERED) QUANTITY_ORDERED, --订购数量(单据数量)
         sum(pod.QUANTITY_CANCELLED) QUANTITY_CANCELLED, --取消数量
         sum(pod.QUANTITY_DELIVERED) QUANTITY_DELIVERED, --入库数量
         sum(pod.QUANTITY_ORDERED*pol.UNIT_PRICE) AMOUNT_ORDERED, --订购金额
         sum(pod.QUANTITY_CANCELLED*pol.UNIT_PRICE) AMOUNT_CANCELLED, --取消金额
         sum(pod.QUANTITY_DELIVERED*pol.UNIT_PRICE) AMOUNT_DELIVERED --入库金额
    INTO V_ORDER_QTY,V_CANCEL_QTY,V_DELI_QTY,V_ORDER_AMT,V_CANCEL_AMT,V_DELI_AMT     
    FROM APPS.PO_HEADERS_ALL@mdims2mderp        POH,
         APPS.PO_LINES_ALL@mdims2mderp          POL,
         APPS.PO_DISTRIBUTIONS_ALL@mdims2mderp  POD
   WHERE POH.PO_HEADER_ID = POL.PO_HEADER_ID
     and POL.PO_LINE_ID = POD.PO_LINE_ID
     and poh.ORG_ID = V_OU_ID --参数：OU ID
     and poh.SEGMENT1 = V_PO_NUMBER--参数：采购单号
     ;
     
  P_QTY := V_DELI_QTY;--PO 入库数量   

  EXCEPTION
    WHEN NO_DATA_FOUND THEN 
      P_RESULT  := -28211;
      P_ERR_MSG := 'PO对账取数处理出错：销售单'||P_SO_RECNT_INFO.SO_NUM||'在找不到对应erp PO单' ;         
    WHEN PKG_SO_PUB.V_BIZ_EXCEPTION THEN
      P_RESULT  := -28211;
      P_ERR_MSG := 'PO对账取数处理出错：' || P_ERR_MSG;
    WHEN OTHERS THEN
      P_RESULT  := -28211;
      P_ERR_MSG := 'PO对账取数处理异常：' || SQLERRM;
  END;    

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-05-04
  *     创建者：申广延
  *   功能说明：SO对账
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_COMP2ERP_SO(P_SO_RECNT_INFO IN SO_RECNT_INFO, --销售对账记录
                                        P_RECNT_FLAG    IN VARCHAR2, --对帐类型标识：A审核对账，S结算对账
                                        P_USER_CODE     IN VARCHAR2, --操作用户编码
                                        P_SO_QTY        OUT NUMBER, --数量
                                        P_SO_AMOUNT        OUT NUMBER, --金额
                                        P_RESULT        OUT NUMBER, --返回错误ID
                                        P_ERR_MSG       OUT VARCHAR2 --返回错误信息
                                        ) IS  
    --财务单源类型
    V_BILL_TYPE_NAME         T_SO_HEADER.BILL_TYPE_NAME%TYPE;
    V_BIZ_SRC_BILL_TYPE_CODE T_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE%TYPE;
   
    --ERP系统销售订单产品数量和结算总金额
    V_ERP_QTY    NUMBER := 0;
    V_ERP_AMOUNT NUMBER := 0;
  
    --ERP系统销售订单在各阶段的状态
    V_STATUS_ENTERED   VARCHAR2(10) := 'Entered';
    V_STATUS_FULFILLED VARCHAR2(10) := 'Fulfilled';
    V_STATUS_CLOSED    VARCHAR2(10) := 'Closed';
    V_STATUS_BOOKED    VARCHAR2(10) := 'Booked';
    V_STATUS_RETURNED  VARCHAR2(10) := 'Returned';
    V_STATUS_AWAITING  VARCHAR2(20) := 'Awaiting Return';
  
    --对账信息
    V_MSG VARCHAR2(2048) := '';
    --对账是否成功：失败 00，成功 01
    V_RECNT_FLAG VARCHAR2(2) := '01';
    --当前系统日期时间
    V_CURR_DATE DATE := SYSDATE;
  
  BEGIN
    --初始返回值
    P_RESULT  := PKG_SO_PUB.V_RESULT;
    P_ERR_MSG := PKG_SO_PUB.V_SUCCESS;
  
    --财务单源类型
    V_BILL_TYPE_NAME         := P_SO_RECNT_INFO.BILL_TYPE_NAME;
    V_BIZ_SRC_BILL_TYPE_CODE := P_SO_RECNT_INFO.BIZ_SRC_BILL_TYPE_CODE;
  
    IF V_BIZ_SRC_BILL_TYPE_CODE IN
       (PKG_SO_PUB.V_BIZ_SRC_BILL_SO, PKG_SO_PUB.V_BIZ_SRC_BILL_RETURN_RED) THEN
      --销售订单，除折让
      --ERP的销售订单（对应CIMS的销售单和退货红冲单）
      DECLARE
        --ERP系统的销售订单信息
        CURSOR C_ERP_SO_INFO IS
          SELECT OEL.HEADER_ID,
                 LV.MEANING AS STATUS,
                 SUM(OEL.ORDERED_QUANTITY) AS ORDERED_QUANTITY,
                 SUM(OEL.ORDERED_QUANTITY * OEL.UNIT_SELLING_PRICE) AS AMOUNT
            FROM APPS.OE_ORDER_LINES_ALL@MDIMS2MDERP   OEL,
                 APPS.OE_ORDER_HEADERS_ALL@MDIMS2MDERP OEH,
                 APPS.FND_LOOKUP_VALUES@MDIMS2MDERP    LV
           WHERE LV.LOOKUP_TYPE = 'LINE_FLOW_STATUS'
             AND LV.LOOKUP_CODE = OEL.FLOW_STATUS_CODE
             AND LV.LANGUAGE = 'US' --USERENV('LANG')
             AND LV.VIEW_APPLICATION_ID = 660
             AND OEH.HEADER_ID = OEL.HEADER_ID
                --AND OEL.LINE_CATEGORY_CODE = 'ORDER',--因为启用了MIXED,
             AND OEH.ORDER_NUMBER = TO_NUMBER(P_SO_RECNT_INFO.SO_NUM) --参数
             AND OEH.ORG_ID = P_SO_RECNT_INFO.ERP_OU_ID --参数OU ID
           GROUP BY OEL.HEADER_ID, LV.MEANING;
      
        --ERP系统的销售订单信息记录
        R_ERP_SO_INFO C_ERP_SO_INFO%ROWTYPE;
      
      BEGIN
        --获取ERP销售订单的产品总数和结算总金额
        FOR R_ERP_SO_INFO IN C_ERP_SO_INFO LOOP
          IF (P_RECNT_FLAG = V_FLAG_AUDIT) THEN
            --审核对账
            IF R_ERP_SO_INFO.STATUS IN
               (V_STATUS_ENTERED, V_STATUS_FULFILLED, V_STATUS_CLOSED) THEN
              V_ERP_QTY    := (V_ERP_QTY + R_ERP_SO_INFO.ORDERED_QUANTITY);
              V_ERP_AMOUNT := (V_ERP_AMOUNT + R_ERP_SO_INFO.AMOUNT);
            END IF;
          ELSIF (P_RECNT_FLAG = V_FLAG_SETTLE) THEN
            --结算对账
            IF R_ERP_SO_INFO.STATUS IN
               (V_STATUS_FULFILLED, V_STATUS_CLOSED) THEN
              V_ERP_QTY    := (V_ERP_QTY + R_ERP_SO_INFO.ORDERED_QUANTITY);
              V_ERP_AMOUNT := (V_ERP_AMOUNT + R_ERP_SO_INFO.AMOUNT);
            END IF;
          END IF;
        END LOOP;
      EXCEPTION
        WHEN OTHERS THEN
          P_ERR_MSG := V_BILL_TYPE_NAME || '[单据号：' ||
                       P_SO_RECNT_INFO.SO_NUM || ']对账发生异常：' || SQLERRM;
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      END;
    ELSIF V_BIZ_SRC_BILL_TYPE_CODE IN
          (PKG_SO_PUB.V_BIZ_SRC_BILL_RETURN,
           PKG_SO_PUB.V_BIZ_SRC_BILL_SO_RED) THEN
      --RMA，除折让
      --ERP的RMA（对应CIMS的退货单和销售红冲单）
      DECLARE
        --ERP系统的销售订单信息
        CURSOR C_ERP_SO_INFO IS
          SELECT OEL.HEADER_ID,
                 DECODE(OEL.SHIPPABLE_FLAG,
                        'N',
                        'MODEL',
                        OEL.ITEM_TYPE_CODE) AS ITEM_TYPE_CODE,
                 LV.MEANING AS STATUS,
                 SUM(OEL.ORDERED_QUANTITY) AS ORDERED_QUANTITY,
                 SUM(OEL.ORDERED_QUANTITY * OEL.UNIT_SELLING_PRICE) AS AMOUNT
            FROM APPS.OE_ORDER_LINES_ALL@MDIMS2MDERP   OEL,
                 APPS.OE_ORDER_HEADERS_ALL@MDIMS2MDERP OEH,
                 APPS.FND_LOOKUP_VALUES@MDIMS2MDERP    LV
           WHERE LV.LOOKUP_TYPE = 'LINE_FLOW_STATUS'
             AND LV.LOOKUP_CODE = OEL.FLOW_STATUS_CODE
             AND LV.LANGUAGE = 'US' --USERENV('LANG')
             AND LV.VIEW_APPLICATION_ID = 660
             AND OEH.HEADER_ID = OEL.HEADER_ID
                --AND OEH.ORDER_CATEGORY_CODE = 'RETURN' --因为启用了MIXED,
             AND OEH.ORDER_NUMBER = TO_NUMBER(P_SO_RECNT_INFO.SO_NUM) --参数
             AND OEH.ORG_ID = P_SO_RECNT_INFO.ERP_OU_ID --参数OU ID
           GROUP BY OEL.HEADER_ID,
                    DECODE(OEL.SHIPPABLE_FLAG,
                           'N',
                           'MODEL',
                           OEL.ITEM_TYPE_CODE),
                    LV.MEANING;
      
        --ERP系统的销售订单信息记录
        R_ERP_SO_INFO C_ERP_SO_INFO%ROWTYPE;
      BEGIN
        --获取ERP销售订单的产品总数和结算总金额
        FOR R_ERP_SO_INFO IN C_ERP_SO_INFO LOOP
          IF (P_RECNT_FLAG = V_FLAG_AUDIT) THEN
            --审核对账
            IF (R_ERP_SO_INFO.ITEM_TYPE_CODE = 'MODEL') AND
               (R_ERP_SO_INFO.STATUS IN
               (V_STATUS_ENTERED, V_STATUS_BOOKED, V_STATUS_CLOSED)) THEN
              V_ERP_QTY    := (V_ERP_QTY + R_ERP_SO_INFO.ORDERED_QUANTITY);
              V_ERP_AMOUNT := (V_ERP_AMOUNT + R_ERP_SO_INFO.AMOUNT);
            ELSIF (R_ERP_SO_INFO.ITEM_TYPE_CODE = 'STANDARD') AND
                  (R_ERP_SO_INFO.STATUS IN
                  (V_STATUS_ENTERED,
                    V_STATUS_AWAITING,
                    V_STATUS_RETURNED,
                    V_STATUS_CLOSED)) THEN
              V_ERP_QTY    := (V_ERP_QTY + R_ERP_SO_INFO.ORDERED_QUANTITY);
              V_ERP_AMOUNT := (V_ERP_AMOUNT + R_ERP_SO_INFO.AMOUNT);
            END IF;
          ELSIF (P_RECNT_FLAG = V_FLAG_SETTLE) THEN
            --结算对账
            IF (R_ERP_SO_INFO.ITEM_TYPE_CODE = 'MODEL') AND
               (R_ERP_SO_INFO.STATUS IN (V_STATUS_BOOKED, V_STATUS_CLOSED)) THEN
              V_ERP_QTY    := (V_ERP_QTY + R_ERP_SO_INFO.ORDERED_QUANTITY);
              V_ERP_AMOUNT := (V_ERP_AMOUNT + R_ERP_SO_INFO.AMOUNT);
            ELSIF (R_ERP_SO_INFO.ITEM_TYPE_CODE = 'STANDARD') AND
                  (R_ERP_SO_INFO.STATUS IN
                  (V_STATUS_AWAITING, V_STATUS_RETURNED, V_STATUS_CLOSED)) THEN
              V_ERP_QTY    := (V_ERP_QTY + R_ERP_SO_INFO.ORDERED_QUANTITY);
              V_ERP_AMOUNT := (V_ERP_AMOUNT + R_ERP_SO_INFO.AMOUNT);
            END IF;
          END IF;
        END LOOP;
      EXCEPTION
        WHEN OTHERS THEN
          P_ERR_MSG := V_BILL_TYPE_NAME || '[单据号：' ||
                       P_SO_RECNT_INFO.SO_NUM || ']对账发生异常：' || SQLERRM;
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      END;
    ELSIF V_BIZ_SRC_BILL_TYPE_CODE IN
          (PKG_SO_PUB.V_BIZ_SRC_BILL_SO_DISCOUNT,
           PKG_SO_PUB.V_BIZ_SRC_BILL_DISCOUNT) THEN
      --折让RMA
      --ERP的折让RMA（对应CIMS的销售折让单和折让证明单）
      DECLARE
        --ERP系统的销售订单信息
        CURSOR C_ERP_SO_INFO IS
          SELECT OEL.HEADER_ID,
                 OEL.ITEM_TYPE_CODE,
                 LV.MEANING AS STATUS,
                 SUM(OEL.ORDERED_QUANTITY) AS ORDERED_QUANTITY,
                 SUM(OEL.ORDERED_QUANTITY * OEL.UNIT_SELLING_PRICE) AS AMOUNT
            FROM APPS.OE_ORDER_LINES_ALL@MDIMS2MDERP   OEL,
                 APPS.OE_ORDER_HEADERS_ALL@MDIMS2MDERP OEH,
                 APPS.FND_LOOKUP_VALUES@MDIMS2MDERP    LV
           WHERE LV.LOOKUP_TYPE = 'LINE_FLOW_STATUS'
             AND LV.LOOKUP_CODE = OEL.FLOW_STATUS_CODE
             AND LV.LANGUAGE = 'US' --USERENV('LANG')
             AND LV.VIEW_APPLICATION_ID = 660
             AND OEH.HEADER_ID = OEL.HEADER_ID
                --AND OEH.ORDER_CATEGORY_CODE = 'RETURN' --因为启用了MIXED,
             AND OEH.ORDER_NUMBER = TO_NUMBER(P_SO_RECNT_INFO.SO_NUM) --参数
             AND OEH.ORG_ID = P_SO_RECNT_INFO.ERP_OU_ID --参数OU ID
           GROUP BY OEL.HEADER_ID, OEL.ITEM_TYPE_CODE, LV.MEANING;
      
        --ERP系统的销售订单信息记录
        R_ERP_SO_INFO C_ERP_SO_INFO%ROWTYPE;
      BEGIN
        --获取ERP销售订单的产品总数和结算总金额
        FOR R_ERP_SO_INFO IN C_ERP_SO_INFO LOOP
          IF (P_RECNT_FLAG = V_FLAG_AUDIT) THEN
            --审核对账
            IF (R_ERP_SO_INFO.ITEM_TYPE_CODE = 'STANDARD') AND
               (R_ERP_SO_INFO.STATUS IN
               (V_STATUS_ENTERED, V_STATUS_BOOKED, V_STATUS_CLOSED)) THEN
              V_ERP_QTY    := (V_ERP_QTY + R_ERP_SO_INFO.ORDERED_QUANTITY);
              V_ERP_AMOUNT := (V_ERP_AMOUNT + R_ERP_SO_INFO.AMOUNT);
            END IF;
          ELSIF (P_RECNT_FLAG = V_FLAG_SETTLE) THEN
            --结算对账
            IF (R_ERP_SO_INFO.ITEM_TYPE_CODE = 'STANDARD') AND
               (R_ERP_SO_INFO.STATUS IN (V_STATUS_BOOKED, V_STATUS_CLOSED)) THEN
              V_ERP_QTY    := (V_ERP_QTY + R_ERP_SO_INFO.ORDERED_QUANTITY);
              V_ERP_AMOUNT := (V_ERP_AMOUNT + R_ERP_SO_INFO.AMOUNT);
            END IF;
          END IF;
        END LOOP;
      EXCEPTION
        WHEN OTHERS THEN
          P_ERR_MSG := V_BILL_TYPE_NAME || '[单据号：' ||
                       P_SO_RECNT_INFO.SO_NUM || ']对账发生异常：' || SQLERRM;
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      END;
    ELSIF V_BIZ_SRC_BILL_TYPE_CODE IN
          (PKG_SO_PUB.V_BIZ_SRC_BILL_SO_DISCOUNT_RED,
           PKG_SO_PUB.V_BIZ_SRC_BILL_DISCOUNT_RED) THEN
      --折让销售订单
      --ERP的折让销售订单（对应CIMS的销售折让红冲单和折让证明红冲单）
      DECLARE
        --ERP系统的销售订单信息
        CURSOR C_ERP_SO_INFO IS
          SELECT OEL.HEADER_ID,
                 OEL.ITEM_TYPE_CODE,
                 LV.MEANING AS STATUS,
                 SUM(OEL.ORDERED_QUANTITY) AS ORDERED_QUANTITY,
                 SUM(OEL.ORDERED_QUANTITY * OEL.UNIT_SELLING_PRICE) AS AMOUNT
            FROM APPS.OE_ORDER_LINES_ALL@MDIMS2MDERP   OEL,
                 APPS.OE_ORDER_HEADERS_ALL@MDIMS2MDERP OEH,
                 APPS.FND_LOOKUP_VALUES@MDIMS2MDERP    LV
           WHERE LV.LOOKUP_TYPE = 'LINE_FLOW_STATUS'
             AND LV.LOOKUP_CODE = OEL.FLOW_STATUS_CODE
             AND LV.LANGUAGE = 'US' --USERENV('LANG')
             AND LV.VIEW_APPLICATION_ID = 660
             AND OEH.HEADER_ID = OEL.HEADER_ID
                --AND OEH.ORDER_CATEGORY_CODE = 'ORDER' --因为启用了MIXED,
             AND OEH.ORDER_NUMBER = TO_NUMBER(P_SO_RECNT_INFO.SO_NUM) --参数：
             AND OEH.ORG_ID = P_SO_RECNT_INFO.ERP_OU_ID --：参数OU ID
           GROUP BY OEL.HEADER_ID, OEL.ITEM_TYPE_CODE, LV.MEANING;
      
        --ERP系统的销售订单信息记录
        R_ERP_SO_INFO C_ERP_SO_INFO%ROWTYPE;
      BEGIN
        --获取ERP销售订单的产品总数和结算总金额
        FOR R_ERP_SO_INFO IN C_ERP_SO_INFO LOOP
          IF (P_RECNT_FLAG = V_FLAG_AUDIT) THEN
            --审核对账
            IF (R_ERP_SO_INFO.ITEM_TYPE_CODE = 'STANDARD') AND
               (R_ERP_SO_INFO.STATUS IN
               (V_STATUS_ENTERED, V_STATUS_BOOKED, V_STATUS_CLOSED)) THEN
              V_ERP_QTY    := (V_ERP_QTY + R_ERP_SO_INFO.ORDERED_QUANTITY);
              V_ERP_AMOUNT := (V_ERP_AMOUNT + R_ERP_SO_INFO.AMOUNT);
            END IF;
          ELSIF (P_RECNT_FLAG = V_FLAG_SETTLE) THEN
            --结算对账
            IF (R_ERP_SO_INFO.ITEM_TYPE_CODE = 'STANDARD') AND
               (R_ERP_SO_INFO.STATUS IN (V_STATUS_BOOKED, V_STATUS_CLOSED)) THEN
              V_ERP_QTY    := (V_ERP_QTY + R_ERP_SO_INFO.ORDERED_QUANTITY);
              V_ERP_AMOUNT := (V_ERP_AMOUNT + R_ERP_SO_INFO.AMOUNT);
            END IF;
          END IF;
        END LOOP;
      EXCEPTION
        WHEN OTHERS THEN
          P_ERR_MSG := V_BILL_TYPE_NAME || '[单据号：' ||
                       P_SO_RECNT_INFO.SO_NUM || ']对账发生异常：' || SQLERRM;
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      END;
    END IF;
  
    --取绝对值
    V_ERP_QTY    := ABS(V_ERP_QTY);
    V_ERP_AMOUNT := ABS(V_ERP_AMOUNT);
  
    P_SO_QTY := V_ERP_QTY;
    P_SO_AMOUNT := V_ERP_AMOUNT;
  EXCEPTION
    WHEN PKG_SO_PUB.V_BIZ_EXCEPTION THEN
      P_RESULT  := -28211;
      P_ERR_MSG := 'SO对账取数处理出错：' || P_ERR_MSG;
    WHEN OTHERS THEN
      P_RESULT  := -28211;
      P_ERR_MSG := 'PO对账取数处理异常：' || SQLERRM;
  END; 

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-05-04
  *     创建者：申广延
  *   功能说明：销售单统计
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_HEADER_CAL_PULL(P_SO_RECNT_INFO IN SO_RECNT_INFO, --销售对账记录
                                           P_ENTRY_QTY     OUT NUMBER,--入库总数量
                                           P_TOTAL_QTY     OUT NUMBER,--总数量
                                           P_TOTAL_AMOUNT   OUT NUMBER,--总金额
                                           P_RESULT        OUT NUMBER, --返回错误ID
                                           P_ERR_MSG       OUT VARCHAR2 --返回错误信息
                                        ) IS

    --财务单信息
    CURSOR C_SO_INFO IS
      SELECT SO_HEADER_ID,
             SUM(NVL(ITEM_QTY, 0)) AS QTY,
             SUM(NVL(ITEM_SETTLE_AMOUNT, 0)) AS AMOUNT,
             SUM(NVL(REVERSAL_QTY, 0)) AS REVERSAL_QTY,
             SUM(NVL(RETURN_QTY, 0)) AS RETURN_QTY          
        FROM T_SO_LINE
       WHERE SO_HEADER_ID = P_SO_RECNT_INFO.SO_HEADER_ID
       GROUP BY SO_HEADER_ID;
              
    --财务单信息记录
    R_SO_INFO C_SO_INFO%ROWTYPE;
    --CIMS系统财务单产品数量和结算总金额
    V_QTY    NUMBER := 0;
    V_AMOUNT NUMBER := 0;      
    V_REVERSAL_QTY    NUMBER := 0;--已红冲
    V_RETURN_QTY NUMBER := 0;     --已退货     
  BEGIN
    --初始返回值
    P_RESULT  := PKG_SO_PUB.V_RESULT;
    P_ERR_MSG := PKG_SO_PUB.V_SUCCESS;
  
     --计算CIMS财务单行产品数量和结算总金额
    FOR R_SO_INFO IN C_SO_INFO LOOP
      V_QTY    := V_QTY + R_SO_INFO.QTY;
      V_AMOUNT := V_AMOUNT + R_SO_INFO.AMOUNT;
      V_REVERSAL_QTY := V_REVERSAL_QTY + R_SO_INFO.Reversal_Qty;
      V_RETURN_QTY := V_RETURN_QTY + R_SO_INFO.Return_Qty;
    END LOOP;
    
    IF P_SO_RECNT_INFO.BIZ_SRC_BILL_TYPE_CODE = PKG_SO_PUB.V_BIZ_SRC_BILL_RETURN AND P_SO_RECNT_INFO.RETURN_MODE = '3' THEN --拉式反向销售
      P_ENTRY_QTY := V_QTY;
    ELSE 
      P_ENTRY_QTY := V_QTY - V_REVERSAL_QTY - V_RETURN_QTY;
    END IF;    
    P_TOTAL_QTY := V_QTY;
    P_TOTAL_AMOUNT := V_AMOUNT;
  EXCEPTION
    WHEN PKG_SO_PUB.V_BIZ_EXCEPTION THEN
      P_RESULT  := -28211;
      P_ERR_MSG := 'CIMS财务单对账取数处理出错：' || P_ERR_MSG;
    WHEN OTHERS THEN
      P_RESULT  := -28211;
      P_ERR_MSG := 'CIMS财务单对账取数处理异常：' || SQLERRM;
  END;     

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-05-04
  *     创建者：申广延
  *   功能说明：销售单统计
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_HEADER_CAL_PUSH(P_SO_RECNT_INFO IN SO_RECNT_INFO, --销售对账记录
                                           P_TOTAL_QTY     OUT NUMBER,--总数量
                                           P_TOTAL_AMOUNT  OUT NUMBER,--总金额
                                           P_RESULT        OUT NUMBER, --返回错误ID
                                           P_ERR_MSG       OUT VARCHAR2 --返回错误信息
                                        ) IS

    --财务单信息
    CURSOR C_SO_INFO IS(
    --套件行
      SELECT SO_HEADER_ID,
             'MODEL' AS ITEM_TYPE_CODE,
             SUM(NVL(ITEM_QTY, 0)) AS QTY,
             SUM(NVL(ITEM_SETTLE_AMOUNT, 0)) AS AMOUNT
        FROM T_SO_LINE
       WHERE SO_HEADER_ID = P_SO_RECNT_INFO.SO_HEADER_ID
         AND ITEM_IS_SET = 'Y'
       GROUP BY SO_HEADER_ID
      UNION
      --散件行
      SELECT SL.SO_HEADER_ID,
             DECODE(SL.ITEM_IS_SET, 'Y', 'OPTION', 'STANDARD') AS ITEM_TYPE_CODE,
             SUM(NVL(SLD.COMPONENT_QTY, 0)) AS QTY,
             SUM(NVL(SLD.COMPONENT_SETTLE_PRICE, 0) *
                 NVL(SLD.COMPONENT_QTY, 0)) AS AMOUNT
        FROM T_SO_LINE SL, T_SO_LINE_DETAIL SLD
       WHERE SL.SO_LINE_ID = SLD.SO_LINE_ID
         AND SL.SO_HEADER_ID = P_SO_RECNT_INFO.SO_HEADER_ID
       GROUP BY SL.SO_HEADER_ID,
                DECODE(SL.ITEM_IS_SET, 'Y', 'OPTION', 'STANDARD'));
              
    --财务单信息记录
    R_SO_INFO C_SO_INFO%ROWTYPE;
    --CIMS系统财务单产品数量和结算总金额
    V_QTY    NUMBER := 0;
    V_AMOUNT NUMBER := 0;      
   
  BEGIN
    --初始返回值
    P_RESULT  := PKG_SO_PUB.V_RESULT;
    P_ERR_MSG := PKG_SO_PUB.V_SUCCESS;
  
     --计算CIMS财务单行产品数量和结算总金额
    FOR R_SO_INFO IN C_SO_INFO LOOP
      V_QTY    := V_QTY + R_SO_INFO.QTY;
      V_AMOUNT := V_AMOUNT + R_SO_INFO.AMOUNT;
    END LOOP;
    
    P_TOTAL_QTY := V_QTY;
    P_TOTAL_AMOUNT := V_AMOUNT;
  EXCEPTION
    WHEN PKG_SO_PUB.V_BIZ_EXCEPTION THEN
      P_RESULT  := -28211;
      P_ERR_MSG := 'CIMS财务单对账取数处理出错：' || P_ERR_MSG;
    WHEN OTHERS THEN
      P_RESULT  := -28211;
      P_ERR_MSG := 'CIMS财务单对账取数处理异常：' || SQLERRM;
  END;    
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-05-05
  *     创建者：申广延
  *   功能说明：销售对账处理
  *   对账项目
  *   子库转移 当前订单物件数量
  *   PO   入库数量
  *   SO   当前订单物件数量，总金额
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_COM2ERP_PROCESS(P_SO_RECNT_INFO IN SO_RECNT_INFO, --销售对账记录
                                        P_RECNT_FLAG    IN VARCHAR2, --对帐类型标识：A审核对账，S结算对账
                                        P_USER_CODE     IN VARCHAR2, --操作用户编码
                                        P_UPDATE_FLAG   IN VARCHAR2, --回写标志，'Y'回写，测试用''
                                        P_RESULT        OUT NUMBER, --返回错误ID
                                        P_ERR_MSG       OUT VARCHAR2 --返回错误信息
                                        ) IS
    --模式（推式拉式）   
    V_PUSH_OR_PULL VARCHAR2(20);
                                     
    --财务单源类型
    V_BILL_TYPE_NAME         T_SO_HEADER.BILL_TYPE_NAME%TYPE;
    V_BIZ_SRC_BILL_TYPE_CODE T_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE%TYPE;
  
    --CIMS系统财务单产品数量和结算总金额、入库数量
    V_QTY    NUMBER := 0;
    V_AMOUNT NUMBER := 0;
    V_ENTRY_QTY NUMBER := 0;
    --ERP系统销售订单产品数量和结算总金额
    V_SO_QTY    NUMBER := 0;
    V_SO_AMOUNT NUMBER := 0;
    
    --子库转移数量、PO单数量
    V_SUBINV_COUNT_LINE NUMBER := 0;
    V_SUBINV_QTY NUMBER := 0;
    V_PO_QTY     NUMBER := 0;
  
    --对账信息
    V_MSG VARCHAR2(2048) := '';
    V_RESULT VARCHAR2(10) := '';
    --对账是否成功：失败 00，成功 01
    V_RECNT_FLAG VARCHAR2(2) := '01';
    --当前系统日期时间
    V_CURR_DATE DATE := SYSDATE;
  
    V_SO_RECNT_INFO_BLUE SO_RECNT_INFO;
    V_ENTRY_QTY_BLUE NUMBER := 0; 
    V_QTY_BLUE NUMBER := 0;
    V_AMOUNT_BLUE NUMBER := 0;
    
    --by sushu 2016-07-26
    --结算日期
    V_SETTLE_DATE Date;
    --CIMS不含税收入
    V_CIMS_REV_AMOUNT Number;
    --ERP不含税收入
    V_ERP_REV_AMOUNT Number;
    --ERP发票金额
    V_ERP_REC_AMOUNT Number;
    --CIMS不含税收入-ERP不含税收入的差异，>1或者<-1为Y。其他为N
    V_AMOUNT_DIFF varchar2(2);
    --ERP应收（AR)发票号
    V_ERP_ARINVOICE_CODE Varchar2(50);
    --ERP的OU_ID
    V_ERP_OU_ID Number;
    --正负号
    V_PLUS_MINUS_FLAG Number;
    
    V_TAX_RATE Number := 1.13;
  BEGIN
    --初始返回值
    P_RESULT  := PKG_SO_PUB.V_RESULT;
    P_ERR_MSG := PKG_SO_PUB.V_SUCCESS;
  
    --取模式
    SELECT SH.TRX_MODE
      INTO V_PUSH_OR_PULL
      FROM T_SO_HEADER SH
     WHERE SH.SO_HEADER_ID = P_SO_RECNT_INFO.SO_HEADER_ID;
    IF V_PUSH_OR_PULL IS NULL THEN       
      PKG_BD.P_GET_PARAMETER_VALUE(PKG_SO_PUB.V_ARG_SO_AR_PUSH_OR_PULL,
                                   P_SO_RECNT_INFO.ENTITY_ID,
                                   NULL,
                                   NULL,
                                   V_PUSH_OR_PULL);  
    END IF; 
    
    SELECT NVL(SL.TAX_RATE, 1.13)
      INTO V_TAX_RATE
      FROM CIMS.T_SO_LINE SL
     WHERE SL.SO_HEADER_ID = P_SO_RECNT_INFO.SO_HEADER_ID
       AND ROWNUM = 1;
                                      
    --财务单源类型
    V_BILL_TYPE_NAME         := P_SO_RECNT_INFO.BILL_TYPE_NAME;
    V_BIZ_SRC_BILL_TYPE_CODE := P_SO_RECNT_INFO.BIZ_SRC_BILL_TYPE_CODE;  

  

  
  IF V_PUSH_OR_PULL = 'PULL' THEN --拉式
    --计算CIMS财务单行产品数量和结算总金额
    P_SO_HEADER_CAL_PULL(P_SO_RECNT_INFO,V_ENTRY_QTY,V_QTY,V_AMOUNT,V_MSG,V_RESULT);
        
    --折让销售单，折让销售红冲，折让证明，折让证明红冲
      IF V_BIZ_SRC_BILL_TYPE_CODE IN (PKG_SO_PUB.V_BIZ_SRC_BILL_SO_DISCOUNT,
        PKG_SO_PUB.V_BIZ_SRC_BILL_SO_DISCOUNT_RED,
        PKG_SO_PUB.V_BIZ_SRC_BILL_DISCOUNT,
        PKG_SO_PUB.V_BIZ_SRC_BILL_DISCOUNT_RED) THEN
        --SO
        P_SO_COMP2ERP_SO(P_SO_RECNT_INFO,P_RECNT_FLAG,P_USER_CODE,V_SO_QTY,V_SO_AMOUNT,V_RESULT,V_MSG);

        --如果数量或金额不相等，则表明对账失败。   
          IF (V_QTY != V_SO_QTY) THEN
            V_RECNT_FLAG := '00';
            V_MSG        := '数量不相等：CIMS系统的数量为' || V_QTY || '，ERP系统的数量为' ||
                            V_SO_QTY || '。';
          END IF;
        
          IF (V_AMOUNT != V_SO_AMOUNT) THEN
            V_RECNT_FLAG := '00';
            V_MSG        := V_MSG || '金额不相等：CIMS系统的结算金额为' || V_AMOUNT ||
                            '，ERP系统的结算金额为' || V_SO_AMOUNT || '。';
          END IF;
              
      ELSE  
        --1.子库转移
        P_SO_COMP2ERP_SUBINV(P_SO_RECNT_INFO,V_SUBINV_COUNT_LINE,V_SUBINV_QTY,V_RESULT,V_MSG);
        IF (V_SUBINV_COUNT_LINE = 0) THEN
           V_RECNT_FLAG := '00';
           V_MSG        := '对应的销售单不存在ERP系统子库转移对账表中。';         
        END IF;
                  
        IF (V_QTY != V_SUBINV_QTY) THEN
           V_RECNT_FLAG := '00';
           V_MSG        := '数量不相等：CIMS系统的数量为' || V_QTY || '，ERP系统子库转移的数量为' ||
                          V_SUBINV_QTY || '。';         
        END IF;
            
        --2.SO
        IF V_RECNT_FLAG != '00' THEN
          P_SO_COMP2ERP_SO(P_SO_RECNT_INFO,P_RECNT_FLAG,P_USER_CODE,V_SO_QTY,V_SO_AMOUNT,V_RESULT,V_MSG);
          IF (V_QTY != V_SO_QTY) THEN
             V_RECNT_FLAG := '00';
             V_MSG        := '数量不相等：CIMS系统的数量为' || V_QTY || '，ERP系统SO的数量为' ||
                            V_SUBINV_QTY || '。'; 
          END IF;                  
          IF (V_AMOUNT != V_SO_AMOUNT) THEN
            V_RECNT_FLAG := '00';
            V_MSG        := V_MSG || '金额不相等：CIMS系统的结算金额为' || V_AMOUNT ||
                            '，ERP系统的结算金额为' || V_SO_AMOUNT || '。';
          END IF;
        END IF;
            
        --3.PO  
        IF V_RECNT_FLAG != '00' THEN
          --销售红冲单找单单对
          IF V_BIZ_SRC_BILL_TYPE_CODE = PKG_SO_PUB.V_BIZ_SRC_BILL_SO_RED THEN
            --取蓝单
            P_SO_GET_HEADER(P_SO_RECNT_INFO.ORIG_SO_NUM,V_SO_RECNT_INFO_BLUE,V_RESULT,V_MSG);
            P_SO_HEADER_CAL_PULL(V_SO_RECNT_INFO_BLUE,V_ENTRY_QTY_BLUE,V_QTY_BLUE,V_AMOUNT_BLUE,V_MSG,V_RESULT);                   
            V_ENTRY_QTY := V_ENTRY_QTY_BLUE;
            P_SO_COMP2ERP_PO(P_SO_RECNT_INFO,V_PO_QTY,V_RESULT,V_MSG);
          ELSE
            P_SO_COMP2ERP_PO(P_SO_RECNT_INFO,V_PO_QTY,V_RESULT,V_MSG);
          END IF;
               
          IF (V_ENTRY_QTY != V_PO_QTY) THEN
           V_RECNT_FLAG := '00';
           V_MSG        := '数量不相等：CIMS系统的入库数量为' || V_ENTRY_QTY || '，ERP系统PO的入库数量为' ||
                          V_PO_QTY || '。';                   
          END IF;         
        END IF; 
      END IF;     
    ELSE --推式
      --计算CIMS财务单行产品数量和结算总金额
      P_SO_HEADER_CAL_PUSH(P_SO_RECNT_INFO,V_QTY,V_AMOUNT,V_MSG,V_RESULT);
      
      P_SO_COMP2ERP_SO(P_SO_RECNT_INFO,P_RECNT_FLAG,P_USER_CODE,V_SO_QTY,V_SO_AMOUNT,V_RESULT,V_MSG);
    END IF;                  
  
    IF V_RECNT_FLAG = '00' THEN
      V_MSG := V_BILL_TYPE_NAME || '[' || P_SO_RECNT_INFO.SO_NUM ||
               ']对账失败：' || V_MSG;
    ELSE
      V_MSG := V_BILL_TYPE_NAME || '[' || P_SO_RECNT_INFO.SO_NUM ||
               ']对账成功.';
    END IF;  
  
  --追加对数信息
  IF V_PUSH_OR_PULL = 'PULL' THEN
     V_MSG := V_MSG||'财务单总数量:'||V_QTY;
     V_MSG := V_MSG||',财务单入库数量:'||V_ENTRY_QTY;
     V_MSG := V_MSG||',财务单总金额:'||V_AMOUNT;
     V_MSG := V_MSG||',子库转移数量:'||V_SUBINV_QTY;
     V_MSG := V_MSG||',SO数量:'||V_SO_QTY;
     V_MSG := V_MSG||',SO总金额:'||V_SO_AMOUNT;
     V_MSG := V_MSG||',PO入库数量:'||V_PO_QTY;   
  ELSE
     V_MSG := V_MSG||'财务单总数量:'||V_QTY;
     V_MSG := V_MSG||',财务单总金额:'||V_AMOUNT;
     V_MSG := V_MSG||',SO数量:'||V_SO_QTY;
     V_MSG := V_MSG||',SO总金额:'||V_SO_AMOUNT;         
  END IF;   
  
    P_RESULT := V_RECNT_FLAG;
    P_ERR_MSG := V_MSG;

    
    IF P_UPDATE_FLAG = 'Y' THEN
      IF V_PUSH_OR_PULL = 'PULL' THEN --拉式
        
        --销售对账增加结算日期、CIMS不含税收入、ERP不含税收入、ERP发票金额；
        --by sushu 2016-07-26
        --从销售单据上获取结算日期，发票号，org_id
        Begin
          Select Sh.Settle_Date, --结算日期 
                 Sh.Erp_Arinvoice_Code, --发票号
                 Sh.Erp_Ou_Id,
                 Order_Type.Plus_Minus_Flag
            Into v_Settle_Date,
                 v_Erp_Arinvoice_Code,
                 v_Erp_Ou_Id,
                 v_Plus_Minus_Flag
            From t_So_Header Sh, t_So_Type_Extend Order_Type
           Where Sh.So_Num = p_So_Recnt_Info.So_Num
             And Sh.Bill_Type_Id = Order_Type.Bill_Type_Id;
        Exception
          When Others Then
            p_Err_Msg := '获取销售单据的信息失败，单据号：' || p_So_Recnt_Info.So_Num ||
                         Sqlerrm;
            Raise Pkg_So_Pub.v_Biz_Exception;
        End;
        --根据ERP应收发票号、ERP的OU_ID获取ERP不含税收入、ERP发票金额
        Begin
          Select a.Rev_Amount, --ERP不含税收入
                 a.Rec_Amount --ERP发票金额
            Into v_Erp_Rev_Amount, v_Erp_Rec_Amount
            From Apps.Cux_Erp_Ar_Cust_Trx_v@Mdims2mderp a
           Where a.Org_Id = v_Erp_Ou_Id
             And a.Trx_Number = v_Erp_Arinvoice_Code;
        Exception
          When Others Then
            p_Err_Msg := '获取ERP的不含税收入、ERP发票金额失败' || Sqlerrm;
            Raise Pkg_So_Pub.v_Biz_Exception;
        End;
        --CIMS不含税金额
        v_Cims_Rev_Amount := Round(v_Amount / NVL(V_TAX_RATE, 1.13), 2) * v_Plus_Minus_Flag;
        --ERP不含税收入取两位小数
        v_Erp_Rev_Amount := Round(v_Erp_Rev_Amount, 2);
        --ERP发票金额取两位小数
        v_Erp_Rec_Amount := Round(v_Erp_Rec_Amount, 2);
        --CIMS不含税收入-ERP不含税收入差异，>1或者<-1为Y，其他为N
        If ((v_Cims_Rev_Amount - v_Erp_Rev_Amount) > 1 Or
           (v_Cims_Rev_Amount - v_Erp_Rev_Amount) < -1) Then
          v_Amount_Diff := 'Y';
        Else
          v_Amount_Diff := 'N';
        End If;
        
        --结算对账
        UPDATE T_SO_RECONCILIATION
           SET SETTLE_RECNT_FLAG = V_RECNT_FLAG,
               SETTLE_RECNT_DESC = V_MSG,
               SETTLE_RECNT_TIME = V_CURR_DATE,
               STATUS            = '00', --结算对账后，把状态改为关闭
               LAST_UPDATED_BY   = P_USER_CODE,
               LAST_UPDATE_DATE  = V_CURR_DATE,
               SETTLE_DATE       = V_SETTLE_DATE,     --by sushu 2016-07-26
               CIMS_REV_AMOUNT   = V_CIMS_REV_AMOUNT, --by sushu 2016-07-26
               ERP_REV_AMOUNT    = V_ERP_REV_AMOUNT,  --by sushu 2016-07-26
               ERP_REC_AMOUNT    = V_ERP_REC_AMOUNT,  --by sushu 2016-07-26
               AMOUNT_DIFF       = V_AMOUNT_DIFF      --by sushu 2016-07-26
         WHERE RECNT_ID = P_SO_RECNT_INFO.RECNT_ID;          
      ELSE --推式
        --回写对帐表
        IF (P_RECNT_FLAG = V_FLAG_AUDIT) THEN
          --审核对账
          UPDATE T_SO_RECONCILIATION T
             SET AUDIT_RECNT_FLAG = V_RECNT_FLAG,
                 AUDIT_RECNT_DESC = V_MSG,
                 AUDIT_RECNT_TIME = V_CURR_DATE,
                 LAST_UPDATED_BY  = P_USER_CODE,
                 LAST_UPDATE_DATE = V_CURR_DATE
           WHERE RECNT_ID = P_SO_RECNT_INFO.RECNT_ID;
        ELSIF (P_RECNT_FLAG = V_FLAG_SETTLE) Then
          
          --销售对账增加结算日期、CIMS不含税收入、ERP不含税收入、ERP发票金额；
          --by sushu 2016-07-26
          --从销售单据上获取结算日期，发票号，org_id
          Begin
            Select Sh.Settle_Date, --结算日期 
                   Sh.Erp_Arinvoice_Code, --发票号
                   Sh.Erp_Ou_Id,
                   Order_Type.Plus_Minus_Flag
              Into v_Settle_Date,
                   v_Erp_Arinvoice_Code,
                   v_Erp_Ou_Id,
                   v_Plus_Minus_Flag
              From t_So_Header Sh, t_So_Type_Extend Order_Type
             Where Sh.So_Num = p_So_Recnt_Info.So_Num
               And Sh.Bill_Type_Id = Order_Type.Bill_Type_Id;
          Exception
            When Others Then
              p_Err_Msg := '获取销售单据的信息失败，单据号：' || p_So_Recnt_Info.So_Num ||
                           Sqlerrm;
              Raise Pkg_So_Pub.v_Biz_Exception;
          End;
          --根据ERP应收发票号、ERP的OU_ID获取ERP不含税收入、ERP发票金额
          Begin
            Select a.Rev_Amount, --ERP不含税收入
                   a.Rec_Amount --ERP发票金额
              Into v_Erp_Rev_Amount, v_Erp_Rec_Amount
              From Apps.Cux_Erp_Ar_Cust_Trx_v@Mdims2mderp a
             Where a.Org_Id = v_Erp_Ou_Id
               And a.Trx_Number = v_Erp_Arinvoice_Code;
          Exception
            When Others Then
              p_Err_Msg := '获取ERP的不含税收入、ERP发票金额失败' || Sqlerrm;
              Raise Pkg_So_Pub.v_Biz_Exception;
          End;
          --CIMS不含税金额
          v_Cims_Rev_Amount := Round(v_Amount / NVL(V_TAX_RATE, 1.13), 2) *
                               v_Plus_Minus_Flag;
          --ERP不含税收入取两位小数
          v_Erp_Rev_Amount := Round(v_Erp_Rev_Amount, 2);
          --ERP发票金额取两位小数
          v_Erp_Rec_Amount := Round(v_Erp_Rec_Amount, 2);
          --CIMS不含税收入-ERP不含税收入差异，>1或者<-1为Y，其他为N
          If ((v_Cims_Rev_Amount - v_Erp_Rev_Amount) > 1 Or
             (v_Cims_Rev_Amount - v_Erp_Rev_Amount) < -1) Then
            v_Amount_Diff := 'Y';
          Else
            v_Amount_Diff := 'N';
          End If;
        
          --结算对账
          UPDATE T_SO_RECONCILIATION
             SET SETTLE_RECNT_FLAG = V_RECNT_FLAG,
                 SETTLE_RECNT_DESC = V_MSG,
                 SETTLE_RECNT_TIME = V_CURR_DATE,
                 STATUS            = '00', --结算对账后，把状态改为关闭
                 LAST_UPDATED_BY   = P_USER_CODE,
                 LAST_UPDATE_DATE  = V_CURR_DATE,
                 SETTLE_DATE       = V_SETTLE_DATE,     --by sushu 2016-07-26
                 CIMS_REV_AMOUNT   = V_CIMS_REV_AMOUNT, --by sushu 2016-07-26
                 ERP_REV_AMOUNT    = V_ERP_REV_AMOUNT,  --by sushu 2016-07-26
                 ERP_REC_AMOUNT    = V_ERP_REC_AMOUNT,  --by sushu 2016-07-26
                 AMOUNT_DIFF       = V_AMOUNT_DIFF      --by sushu 2016-07-26
           WHERE RECNT_ID = P_SO_RECNT_INFO.RECNT_ID;
         END IF;
       END IF;
     
      --回写对帐标识到T_SO_HEADER表
      UPDATE T_SO_HEADER
         SET CHECKED_ACCOUNT_FLAG = 'Y', CHECKED_ACCOUNT_DATE = V_CURR_DATE, LAST_UPDATE_DATE  = V_CURR_DATE
       WHERE SO_HEADER_ID = P_SO_RECNT_INFO.SO_HEADER_ID;
       
      COMMIT;  --新增事物提交  防止锁定
    /**   
    ELSE --测试
         --V_QTY V_ENTRY_QTY V_AMOUNT V_SUBINV_QTY V_SO_QTY  V_SO_AMOUNT V_PO_QTY 
         P_ERR_MSG := P_ERR_MSG||'财务单总数量:'||V_QTY;
         P_ERR_MSG := P_ERR_MSG||',财务单入库数量:'||V_ENTRY_QTY;
         P_ERR_MSG := P_ERR_MSG||',财务单总金额:'||V_AMOUNT;
         P_ERR_MSG := P_ERR_MSG||',子库转移数量:'||V_SUBINV_QTY;
         P_ERR_MSG := P_ERR_MSG||',SO数量:'||V_SO_QTY;
         P_ERR_MSG := P_ERR_MSG||',SO总金额:'||V_SO_AMOUNT;
         P_ERR_MSG := P_ERR_MSG||',PO入库数量:'||V_PO_QTY;
         **/                  
    END IF;
  EXCEPTION
    WHEN PKG_SO_PUB.V_BIZ_EXCEPTION THEN
      P_RESULT  := -28211;
      P_ERR_MSG := '对账处理出错：' || P_ERR_MSG;
    WHEN OTHERS THEN
      P_RESULT  := -28211;
      P_ERR_MSG := '对账处理异常：' || SQLERRM;
  END; 
 
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-5-5
  *     创建者：申广延
  *   功能说明：销售对账过程，CIMS系统销售单与ERP系统销售订单对账
  *             1)把需要引入到ERP系统的审核通过且未对账财务单添加到销售对账表（T_SO_RECONCILIATION），已添加到该表的记录不重复添加。
  *             2)从对账表中取未审核对账的记录，与ERP系统进行审核对账，并记录对账结果。
  *             3)从对账表中取未结算对账的记录，与ERP系统进行结算对账，并记录对账结果。
  *             4)回写销售单据头表的对账标识和对账时间。
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_COM2ERP_MAIN(P_ENTITY_ID              IN NUMBER, --主体ID
                              P_PAGE_SIZE              IN NUMBER, --单次处理单据数（分页）
                              P_LASTUPDATE_INTERVAL    IN NUMBER, --具体当前日期的间隔范围
                              P_USER_CODE              IN VARCHAR2, --操作用户编码
                              P_RESULT                 OUT NUMBER, --返回错误ID
                              P_ERR_MSG                OUT VARCHAR2 --返回错误信息
                              ) IS
    --操作用户账号
    V_USER_CODE VARCHAR2(32);
    V_CURR_DATE DATE := SYSDATE;
  
    --拉式不用审核对账
    --未审核对账或对账失败，且状态为打开的记录 推式
    CURSOR C_SO_RECNT_AUDIT_PUSH IS
      SELECT RECNT_ID,
             SO_HEADER_ID,
             SO_NUM,
             ERP_OU_ID,
             BILL_TYPE_NAME,
             BIZ_SRC_BILL_TYPE_CODE,
             ENTITY_ID,
             RETURN_MODE,
             ERP_LOGIST_HEADER_ID,
             ORIG_SO_NUM             
        FROM T_SO_RECONCILIATION
       WHERE (AUDIT_RECNT_FLAG IS NULL OR AUDIT_RECNT_FLAG = '00')
         AND STATUS = '01' --对账状态为打开
         AND PUSH_OR_PULL = 'PUSH'
         AND ENTITY_ID = P_ENTITY_ID
         AND LAST_UPDATE_DATE > SYSDATE - P_LASTUPDATE_INTERVAL
         AND ROWNUM < P_PAGE_SIZE;--推式 只有推式有审核对账
    R_SO_RECNT_AUDIT_PUSH C_SO_RECNT_AUDIT_PUSH%ROWTYPE;

    --未结算对账或对账失败，且状态为打开的记录 推式
    CURSOR C_SO_RECNT_SETTLE_PUSH IS
      SELECT SR.RECNT_ID,
             SR.SO_HEADER_ID,
             SR.SO_NUM,
             SR.ERP_OU_ID,
             SR.BILL_TYPE_NAME,
             SR.BIZ_SRC_BILL_TYPE_CODE,
             SR.ENTITY_ID,
             SR.RETURN_MODE,
             SR.ERP_LOGIST_HEADER_ID,
             SR.ORIG_SO_NUM              
        FROM T_SO_RECONCILIATION SR, T_SO_HEADER SH
       WHERE SR.SO_HEADER_ID = SH.SO_HEADER_ID
         AND (SR.SETTLE_RECNT_FLAG IS NULL OR SR.SETTLE_RECNT_FLAG = '00')
         AND (SR.AUDIT_RECNT_FLAG IS NOT NULL)
         AND NVL(SH.ERP_BOOKED_FLAG, 'N') = 'Y' --add by chen.wj 20150122 增加这个条件判断SO变更引ERP是否成功，如果成功才做对账
         AND SR.STATUS = '01' --对账状态为打开
         AND SR.PUSH_OR_PULL = 'PUSH'
         AND SH.SO_STATUS = '12'--结算状态
         AND SH.ENTITY_ID = P_ENTITY_ID
         AND SH.LAST_UPDATE_DATE > SYSDATE - P_LASTUPDATE_INTERVAL
         AND ROWNUM < P_PAGE_SIZE;
          
    R_SO_RECNT_SETTLE_PUSH C_SO_RECNT_SETTLE_PUSH%ROWTYPE;
  
    --未结算对账或对账失败，且状态为打开的记录 拉式
    CURSOR C_SO_RECNT_SETTLE_PULL IS
      SELECT SR.RECNT_ID,
             SR.SO_HEADER_ID,
             SR.SO_NUM,
             SR.ERP_OU_ID,
             SR.BILL_TYPE_NAME,
             SR.BIZ_SRC_BILL_TYPE_CODE,
             SR.ENTITY_ID,
             SR.RETURN_MODE,
             SR.ERP_LOGIST_HEADER_ID,
             SR.ORIG_SO_NUM              
        FROM T_SO_RECONCILIATION SR, T_SO_HEADER SH
       WHERE SR.SO_HEADER_ID = SH.SO_HEADER_ID
         AND (SR.SETTLE_RECNT_FLAG IS NULL OR SR.SETTLE_RECNT_FLAG = '00')
         AND SR.STATUS = '01' --对账状态为打开
         AND SR.PUSH_OR_PULL = 'PULL'
         AND NVL(SH.ERP_BOOKED_FLAG, 'N') = 'Y' --add by chen.wj 20150122 增加这个条件判断SO变更引ERP是否成功，如果成功才做对账         
         AND SH.SO_STATUS = '12' --结算状态
         AND SH.ENTITY_ID = P_ENTITY_ID
         AND SH.LAST_UPDATE_DATE > SYSDATE - P_LASTUPDATE_INTERVAL
         AND ROWNUM < P_PAGE_SIZE
         ;
                  
    R_SO_RECNT_SETTLE_PULL C_SO_RECNT_SETTLE_PULL%ROWTYPE;  
  
    --对账信息记录集
    V_SO_RECNT_INFO SO_RECNT_INFO;
  
  BEGIN
    --初始返回值
    P_RESULT  := PKG_SO_PUB.V_RESULT;
    P_ERR_MSG := PKG_SO_PUB.V_SUCCESS;
  
    IF (P_USER_CODE IS NULL) THEN
      V_USER_CODE := PKG_SO_PUB.V_CREATED_BY_SYS;
    ELSE
      V_USER_CODE := P_USER_CODE;
    END IF;

    BEGIN
      --把未对账的单据添加到对账表
      INSERT INTO T_SO_RECONCILIATION
        (RECNT_ID,
         ENTITY_ID,
         SO_HEADER_ID,
         SO_NUM,
         SO_DATE,
         BILL_TYPE_ID,
         BILL_TYPE_CODE,
         BILL_TYPE_NAME,
         BIZ_SRC_BILL_TYPE_ID,
         BIZ_SRC_BILL_TYPE_CODE,
         BIZ_SRC_BILL_TYPE_NAME,
         CUSTOMER_ID,
         CUSTOMER_CODE,
         CUSTOMER_NAME,
         ERP_OU_ID,
         ERP_OU_NAME,
         CREATED_BY,
         CREATION_DATE,
         LAST_UPDATED_BY,
         LAST_UPDATE_DATE,
         RETURN_MODE,
         ERP_LOGIST_HEADER_ID,
         ORIG_SO_NUM,
         PUSH_OR_PULL)
        SELECT S_SO_RECONCILIATION.NEXTVAL,
               SH.ENTITY_ID,
               SH.SO_HEADER_ID,
               SH.SO_NUM,
               SH.SO_DATE,
               SH.BILL_TYPE_ID,
               SH.BILL_TYPE_CODE,
               SH.BILL_TYPE_NAME,
               SH.BIZ_SRC_BILL_TYPE_ID,
               SH.BIZ_SRC_BILL_TYPE_CODE,
               SH.BIZ_SRC_BILL_TYPE_NAME,
               SH.CUSTOMER_ID,
               SH.CUSTOMER_CODE,
               SH.CUSTOMER_NAME,
               SH.ERP_OU_ID,
               SH.ERP_OU_NAME,
               V_USER_CODE,
               V_CURR_DATE,
               V_USER_CODE,
               V_CURR_DATE,
               SH.RETURN_MODE,
               SH.ERP_LOGIST_HEADER_ID,
               SH.ORIG_SO_NUM,
               SH.TRX_MODE
          FROM T_SO_HEADER SH, T_SO_TYPE_EXTEND ST
         WHERE SH.BILL_TYPE_ID = ST.BILL_TYPE_ID
           AND (SH.CHECKED_ACCOUNT_FLAG IS NULL OR
               SH.CHECKED_ACCOUNT_FLAG = 'N')
           AND ((SH.SO_STATUS IN ('11', '12') AND SH.TRX_MODE = 'PUSH')--推式已审核或已结算
               OR (SH.SO_STATUS = '12' AND SH.TRX_MODE = 'PULL'))--拉式 已结算
           AND ST.TO_ERP_FLAG = 'Y'
           AND SH.ERP_SO_ID IS NOT NULL --add by chen.wj 20150122 加入ERP销售单生成条件，因为在SO生成引ERP时如果成功ERP接口会回写这个字段，因而加入这个条件可以判断ERP，SO生成成功，才有对账这个说法
           AND NOT EXISTS (SELECT 1
                  FROM T_SO_RECONCILIATION
                 WHERE ENTITY_ID = SH.ENTITY_ID
                   AND SO_HEADER_ID = SH.SO_HEADER_ID)
           AND SH.ENTITY_ID = P_ENTITY_ID
           AND SH.LAST_UPDATE_DATE > SYSDATE - P_LASTUPDATE_INTERVAL
           AND ROWNUM < P_PAGE_SIZE;
      
      COMMIT;
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;

    --审核对账 推式
    FOR R_SO_RECNT_AUDIT_PUSH IN C_SO_RECNT_AUDIT_PUSH LOOP
      V_SO_RECNT_INFO.RECNT_ID               := R_SO_RECNT_AUDIT_PUSH.RECNT_ID;
      V_SO_RECNT_INFO.SO_HEADER_ID           := R_SO_RECNT_AUDIT_PUSH.SO_HEADER_ID;
      V_SO_RECNT_INFO.SO_NUM                 := R_SO_RECNT_AUDIT_PUSH.SO_NUM;
      V_SO_RECNT_INFO.ERP_OU_ID              := R_SO_RECNT_AUDIT_PUSH.ERP_OU_ID;
      V_SO_RECNT_INFO.BILL_TYPE_NAME         := R_SO_RECNT_AUDIT_PUSH.BILL_TYPE_NAME;
      V_SO_RECNT_INFO.BIZ_SRC_BILL_TYPE_CODE := R_SO_RECNT_AUDIT_PUSH.BIZ_SRC_BILL_TYPE_CODE;
      V_SO_RECNT_INFO.ENTITY_ID              := R_SO_RECNT_AUDIT_PUSH.ENTITY_ID;
      V_SO_RECNT_INFO.RETURN_MODE            := R_SO_RECNT_AUDIT_PUSH.RETURN_MODE;
      V_SO_RECNT_INFO.ERP_LOGIST_HEADER_ID   := R_SO_RECNT_AUDIT_PUSH.ERP_LOGIST_HEADER_ID;
      V_SO_RECNT_INFO.ORIG_SO_NUM            := R_SO_RECNT_AUDIT_PUSH.ORIG_SO_NUM;

      BEGIN
        SAVEPOINT SUCCESS_FLAG1;
        
        --对账处理
        P_SO_COM2ERP_PROCESS(V_SO_RECNT_INFO,
                             V_FLAG_AUDIT,
                             V_USER_CODE,
                             'Y',
                             P_RESULT,
                             P_ERR_MSG);
        PKG_SO_PUB.P_EXCEPTION_THROWS(P_RESULT);
      EXCEPTION
        WHEN OTHERS THEN
          ROLLBACK TO SUCCESS_FLAG1;
          PKG_SO_RT.P_TABLE_ACTION_LOG('ERP_RECONCILIATION', --操作表名称
                             'ERP审核对账_推式', --操作说明
                             V_SO_RECNT_INFO.SO_NUM, --关键主键
                             1, --是否出错，1出错，0未出错
                             'ERP审核对账_推式，异常信息：' || P_ERR_MSG || SQLERRM --错误信息
                             );
          --初始返回值
          P_RESULT  := PKG_SO_PUB.V_RESULT;
          P_ERR_MSG := PKG_SO_PUB.V_SUCCESS;
          GOTO HEADER1;
      END;
      <<HEADER1>>
      NULL;
      
    END LOOP;
    
    
    --结算对账 推式
    FOR R_SO_RECNT_SETTLE_PUSH IN C_SO_RECNT_SETTLE_PUSH LOOP
      V_SO_RECNT_INFO.RECNT_ID               := R_SO_RECNT_SETTLE_PUSH.RECNT_ID;
      V_SO_RECNT_INFO.SO_HEADER_ID           := R_SO_RECNT_SETTLE_PUSH.SO_HEADER_ID;
      V_SO_RECNT_INFO.SO_NUM                 := R_SO_RECNT_SETTLE_PUSH.SO_NUM;
      V_SO_RECNT_INFO.ERP_OU_ID              := R_SO_RECNT_SETTLE_PUSH.ERP_OU_ID;
      V_SO_RECNT_INFO.BILL_TYPE_NAME         := R_SO_RECNT_SETTLE_PUSH.BILL_TYPE_NAME;
      V_SO_RECNT_INFO.BIZ_SRC_BILL_TYPE_CODE := R_SO_RECNT_SETTLE_PUSH.BIZ_SRC_BILL_TYPE_CODE;
      V_SO_RECNT_INFO.ENTITY_ID              := R_SO_RECNT_SETTLE_PUSH.ENTITY_ID;
      V_SO_RECNT_INFO.RETURN_MODE            := R_SO_RECNT_SETTLE_PUSH.RETURN_MODE;
      V_SO_RECNT_INFO.ERP_LOGIST_HEADER_ID   := R_SO_RECNT_SETTLE_PUSH.ERP_LOGIST_HEADER_ID;
      V_SO_RECNT_INFO.ORIG_SO_NUM            := R_SO_RECNT_SETTLE_PUSH.ORIG_SO_NUM;

      BEGIN
        SAVEPOINT SUCCESS_FLAG2;
        
        --对账处理
        P_SO_COM2ERP_PROCESS(V_SO_RECNT_INFO,
                                  V_FLAG_SETTLE,
                                  V_USER_CODE,
                                  'Y',
                                  P_RESULT,
                                  P_ERR_MSG);
        PKG_SO_PUB.P_EXCEPTION_THROWS(P_RESULT);
      EXCEPTION
        WHEN OTHERS THEN
          ROLLBACK TO SUCCESS_FLAG2;
          PKG_SO_RT.P_TABLE_ACTION_LOG('ERP_RECONCILIATION', --操作表名称
                             'ERP结算对账_推式', --操作说明
                             V_SO_RECNT_INFO.SO_NUM, --关键主键
                             1, --是否出错，1出错，0未出错
                             'ERP结算对账_推式，异常信息：' || P_ERR_MSG || SQLERRM --错误信息
                             );
          --初始返回值
          P_RESULT  := PKG_SO_PUB.V_RESULT;
          P_ERR_MSG := PKG_SO_PUB.V_SUCCESS;
          GOTO HEADER2;
      END;
      <<HEADER2>>
      NULL;
      
    END LOOP;

    --审核对账 拉式
    FOR R_SO_RECNT_SETTLE_PULL IN C_SO_RECNT_SETTLE_PULL LOOP
      V_SO_RECNT_INFO.RECNT_ID               := R_SO_RECNT_SETTLE_PULL.RECNT_ID;
      V_SO_RECNT_INFO.SO_HEADER_ID           := R_SO_RECNT_SETTLE_PULL.SO_HEADER_ID;
      V_SO_RECNT_INFO.SO_NUM                 := R_SO_RECNT_SETTLE_PULL.SO_NUM;
      V_SO_RECNT_INFO.ERP_OU_ID              := R_SO_RECNT_SETTLE_PULL.ERP_OU_ID;
      V_SO_RECNT_INFO.BILL_TYPE_NAME         := R_SO_RECNT_SETTLE_PULL.BILL_TYPE_NAME;
      V_SO_RECNT_INFO.BIZ_SRC_BILL_TYPE_CODE := R_SO_RECNT_SETTLE_PULL.BIZ_SRC_BILL_TYPE_CODE;
      V_SO_RECNT_INFO.ENTITY_ID              := R_SO_RECNT_SETTLE_PULL.ENTITY_ID;
      V_SO_RECNT_INFO.RETURN_MODE            := R_SO_RECNT_SETTLE_PULL.RETURN_MODE;
      V_SO_RECNT_INFO.ERP_LOGIST_HEADER_ID   := R_SO_RECNT_SETTLE_PULL.ERP_LOGIST_HEADER_ID;
      V_SO_RECNT_INFO.ORIG_SO_NUM            := R_SO_RECNT_SETTLE_PULL.ORIG_SO_NUM;
      
      BEGIN
        SAVEPOINT SUCCESS_FLAG3;
        
        --对账处理
        P_SO_COM2ERP_PROCESS(V_SO_RECNT_INFO,
                                  V_FLAG_AUDIT,
                                  V_USER_CODE,
                                  'Y',
                                  P_RESULT,
                                  P_ERR_MSG);
        PKG_SO_PUB.P_EXCEPTION_THROWS(P_RESULT);
      EXCEPTION
        WHEN OTHERS THEN
          ROLLBACK TO SUCCESS_FLAG3;
          PKG_SO_RT.P_TABLE_ACTION_LOG('ERP_RECONCILIATION', --操作表名称
                             'ERP审核对账_拉式', --操作说明
                             V_SO_RECNT_INFO.SO_NUM, --关键主键
                             1, --是否出错，1出错，0未出错
                             'ERP审核对账_拉式，异常信息：' || P_ERR_MSG || SQLERRM --错误信息
                             );
          --初始返回值
          P_RESULT  := PKG_SO_PUB.V_RESULT;
          P_ERR_MSG := PKG_SO_PUB.V_SUCCESS;
          GOTO HEADER3;
      END;
      <<HEADER3>>
      NULL;

    END LOOP;
  
  EXCEPTION
    WHEN PKG_SO_PUB.V_BIZ_EXCEPTION THEN
      P_RESULT  := -28210;
      P_ERR_MSG := '销售对账出错，' || P_ERR_MSG;
    WHEN OTHERS THEN
      P_RESULT  := -28210;
      P_ERR_MSG := '销售对账发生异常，' || SQLERRM;
  END;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-05-05
  *     创建者：申广延
  *   功能说明：取销售单
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_GET_HEADER(P_SO_NUM IN NUMBER, --销售单号
                                        P_SO_RECNT_INFO OUT SO_RECNT_INFO, --操作用户编码
                                        P_RESULT        OUT NUMBER, --返回错误ID
                                        P_ERR_MSG       OUT VARCHAR2 --返回错误信息
                                        ) IS 
  BEGIN
    --初始返回值
    P_RESULT  := PKG_SO_PUB.V_RESULT;
    P_ERR_MSG := PKG_SO_PUB.V_SUCCESS;
  
  
  SELECT '',
      SO_HEADER_ID           ,
      SO_NUM                 ,
      ERP_OU_ID              ,
      BILL_TYPE_NAME         ,
      BIZ_SRC_BILL_TYPE_CODE ,
      ENTITY_ID              ,
      RETURN_MODE            ,
      ERP_LOGIST_HEADER_ID   ,
      ORIG_SO_NUM            ,
      pkg_bd.F_GET_PARAMETER_VALUE('SO_AR_PUSH_OR_PULL',ENTITY_ID,NULL,NULL)
  INTO P_SO_RECNT_INFO   
  FROM T_SO_HEADER
  WHERE SO_NUM = P_SO_NUM;
         
  EXCEPTION
    WHEN NO_DATA_FOUND THEN 
      P_RESULT  := -28211;
      P_ERR_MSG := '查找销售单出错，单号'||P_SO_RECNT_INFO.SO_NUM||'找不到。' ;             
    WHEN OTHERS THEN
      P_RESULT  := -28210;
      P_ERR_MSG := '查找销售单发生异常，' || SQLERRM;
  END; 
  -------------------------------------------------------------------------------
  /*
  *   TEST
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_COM2ERP_TEST(P_SO_NUM IN VARCHAR2, --销售单号
                                        P_RECNT_FLAG    IN VARCHAR2, --对帐类型标识：A审核对账，S结算对账
                                        P_USER_CODE     IN VARCHAR2, --操作用户编码
                                        P_RESULT        OUT NUMBER, --返回错误ID
                                        P_ERR_MSG       OUT VARCHAR2 --返回错误信息
                                        ) IS
      V_SO_RECNT_INFO SO_RECNT_INFO;     
      V_USER_CODE    VARCHAR2(50);                              
  BEGIN
    --初始返回值
    P_RESULT  := PKG_SO_PUB.V_RESULT;
    P_ERR_MSG := PKG_SO_PUB.V_SUCCESS;
  
    IF (P_USER_CODE IS NULL) THEN
      V_USER_CODE := PKG_SO_PUB.V_CREATED_BY_SYS;
    ELSE
      V_USER_CODE := P_USER_CODE;
    END IF;
  
  SELECT '',
      SO_HEADER_ID           ,
      SO_NUM                 ,
      ERP_OU_ID              ,
      BILL_TYPE_NAME         ,
      BIZ_SRC_BILL_TYPE_CODE ,
      ENTITY_ID              ,
      RETURN_MODE            ,
      ERP_LOGIST_HEADER_ID   ,
      ORIG_SO_NUM            ,
      pkg_bd.F_GET_PARAMETER_VALUE('SO_AR_PUSH_OR_PULL',ENTITY_ID,NULL,NULL)
  INTO V_SO_RECNT_INFO   
  FROM T_SO_HEADER
  WHERE SO_NUM = P_SO_NUM;
  
  P_SO_COM2ERP_PROCESS(V_SO_RECNT_INFO,P_RECNT_FLAG,V_USER_CODE,'',P_RESULT,P_ERR_MSG);
       
  EXCEPTION
    WHEN PKG_SO_PUB.V_BIZ_EXCEPTION THEN
      P_RESULT  := -28210;
      P_ERR_MSG := '销售对账出错，' || P_ERR_MSG;
    WHEN OTHERS THEN
      P_RESULT  := -28210;
      P_ERR_MSG := '销售对账发生异常，' || SQLERRM;
  END;    
  
  -------------------------------------------------------------------------------
  /*
  *   单挑记录对账
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_COM2ERP_SINGLE(P_SO_NUM IN VARCHAR2, --销售单号
                                        P_RECNT_FLAG    IN VARCHAR2, --对帐类型标识：A审核对账，S结算对账
                                        P_USER_CODE     IN VARCHAR2, --操作用户编码
                                        P_RESULT        OUT NUMBER, --返回错误ID
                                        P_ERR_MSG       OUT VARCHAR2 --返回错误信息
                                        ) IS
      V_SO_RECNT_INFO SO_RECNT_INFO;     
      
      --操作用户账号
      V_USER_CODE VARCHAR2(50);
      V_CURR_DATE DATE := SYSDATE;                                  
  BEGIN
    --初始返回值
    P_RESULT  := PKG_SO_PUB.V_RESULT;
    P_ERR_MSG := PKG_SO_PUB.V_SUCCESS;
  
    IF (P_USER_CODE IS NULL) THEN
      V_USER_CODE := PKG_SO_PUB.V_CREATED_BY_SYS;
    ELSE
      V_USER_CODE := P_USER_CODE;
    END IF;
  
  SELECT '',
      SO_HEADER_ID           ,
      SO_NUM                 ,
      ERP_OU_ID              ,
      BILL_TYPE_NAME         ,
      BIZ_SRC_BILL_TYPE_CODE ,
      ENTITY_ID              ,
      RETURN_MODE            ,
      ERP_LOGIST_HEADER_ID   ,
      ORIG_SO_NUM            ,
      pkg_bd.F_GET_PARAMETER_VALUE('SO_AR_PUSH_OR_PULL',ENTITY_ID,NULL,NULL)
  INTO V_SO_RECNT_INFO   
  FROM T_SO_HEADER
  WHERE SO_NUM = P_SO_NUM;
  
    --把未对账的单据添加到对账表
    INSERT INTO T_SO_RECONCILIATION
      (RECNT_ID,
       ENTITY_ID,
       SO_HEADER_ID,
       SO_NUM,
       SO_DATE,
       BILL_TYPE_ID,
       BILL_TYPE_CODE,
       BILL_TYPE_NAME,
       BIZ_SRC_BILL_TYPE_ID,
       BIZ_SRC_BILL_TYPE_CODE,
       BIZ_SRC_BILL_TYPE_NAME,
       CUSTOMER_ID,
       CUSTOMER_CODE,
       CUSTOMER_NAME,
       ERP_OU_ID,
       ERP_OU_NAME,
       CREATED_BY,
       CREATION_DATE,
       LAST_UPDATED_BY,
       LAST_UPDATE_DATE,
       RETURN_MODE,
       ERP_LOGIST_HEADER_ID,
       ORIG_SO_NUM,
       PUSH_OR_PULL)
      SELECT S_SO_RECONCILIATION.NEXTVAL,
             SH.ENTITY_ID,
             SH.SO_HEADER_ID,
             SH.SO_NUM,
             SH.SO_DATE,
             SH.BILL_TYPE_ID,
             SH.BILL_TYPE_CODE,
             SH.BILL_TYPE_NAME,
             SH.BIZ_SRC_BILL_TYPE_ID,
             SH.BIZ_SRC_BILL_TYPE_CODE,
             SH.BIZ_SRC_BILL_TYPE_NAME,
             SH.CUSTOMER_ID,
             SH.CUSTOMER_CODE,
             SH.CUSTOMER_NAME,
             SH.ERP_OU_ID,
             SH.ERP_OU_NAME,
             V_USER_CODE,
             V_CURR_DATE,
             V_USER_CODE,
             V_CURR_DATE,
             SH.RETURN_MODE,
             ERP_LOGIST_HEADER_ID,
             ORIG_SO_NUM,
             V_SO_RECNT_INFO.PUSH_OR_PULL
        FROM T_SO_HEADER SH, T_SO_TYPE_EXTEND ST
       WHERE SH.BILL_TYPE_ID = ST.BILL_TYPE_ID
         AND SH.SO_NUM = P_SO_NUM
         AND (SH.CHECKED_ACCOUNT_FLAG IS NULL OR
             SH.CHECKED_ACCOUNT_FLAG = 'N')
         AND ((SH.SO_STATUS IN ('11', '12') AND V_SO_RECNT_INFO.PUSH_OR_PULL = 'PUSH')--推式已审核或已结算
             OR (SH.SO_STATUS = '12' AND V_SO_RECNT_INFO.PUSH_OR_PULL = 'PULL'))--拉式 已结算
         AND ST.TO_ERP_FLAG = 'Y'
         AND SH.ERP_SO_ID IS NOT NULL --add by chen.wj 20150122 加入ERP销售单生成条件，因为在SO生成引ERP时如果成功ERP接口会回写这个字段，因而加入这个条件可以判断ERP，SO生成成功，才有对账这个说法
         AND NOT EXISTS (SELECT 1
                FROM T_SO_RECONCILIATION
               WHERE ENTITY_ID = SH.ENTITY_ID
                 AND SO_HEADER_ID = SH.SO_HEADER_ID);  
  
  
  P_SO_COM2ERP_PROCESS(V_SO_RECNT_INFO,P_RECNT_FLAG,V_USER_CODE,'Y',P_RESULT,P_ERR_MSG);
       
  EXCEPTION
    WHEN PKG_SO_PUB.V_BIZ_EXCEPTION THEN
      P_RESULT  := -28210;
      P_ERR_MSG := '销售对账出错，' || P_ERR_MSG;
    WHEN OTHERS THEN
      P_RESULT  := -28210;
      P_ERR_MSG := '销售对账发生异常，' || SQLERRM;
  END;    
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-5-5
  *     创建者：申广延
  *   功能说明：销售重新对账
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_RECOM2ERP_MAIN(P_USER_CODE IN VARCHAR2, --操作用户编码
                                P_RESULT    OUT NUMBER, --返回错误ID
                                P_ERR_MSG   OUT VARCHAR2 --返回错误信息
                                ) IS
    --操作用户账号
    V_USER_CODE VARCHAR2(32);
    V_CURR_DATE DATE := SYSDATE;
  
    --拉式不用审核对账
    --未审核对账或对账失败，且状态为打开的记录 推式
    CURSOR C_SO_RECNT_AUDIT_PUSH IS
      SELECT A.RECNT_ID,
             A.SO_HEADER_ID,
             A.SO_NUM,
             A.ERP_OU_ID,
             A.BILL_TYPE_NAME,
             A.BIZ_SRC_BILL_TYPE_CODE,
             A.ENTITY_ID,
             A.RETURN_MODE,
             A.ERP_LOGIST_HEADER_ID,
             A.ORIG_SO_NUM              
        FROM T_SO_RECONCILIATION A, T_SO_HEADER SH
       WHERE A.SO_NUM = SH.SO_NUM
         AND SH.ERP_SO_ID IS NOT NULL
         AND A.PUSH_OR_PULL = 'PUSH'--推式 只有推式有审核对账
         AND A.AUDIT_RECNT_FLAG = '00'; --只对已经审核对账过数据重新对账，对audit_recnt_flag等于空不重新对账;
    R_SO_RECNT_AUDIT C_SO_RECNT_AUDIT_PUSH%ROWTYPE;

    --未结算对账或对账失败，且状态为打开的记录
    CURSOR C_SO_RECNT_SETTLE_PUSH IS
      SELECT SR.RECNT_ID,
             SR.SO_HEADER_ID,
             SR.SO_NUM,
             SR.ERP_OU_ID,
             SR.BILL_TYPE_NAME,
             SR.BIZ_SRC_BILL_TYPE_CODE,
             SR.ENTITY_ID,
             SR.RETURN_MODE,
             SR.ERP_LOGIST_HEADER_ID,
             SR.ORIG_SO_NUM              
        FROM T_SO_RECONCILIATION SR, T_SO_HEADER SH
       WHERE SR.SO_NUM = SH.SO_NUM
         AND SR.AUDIT_RECNT_FLAG IS NOT NULL
         AND NVL(SH.ERP_BOOKED_FLAG, 'N') = 'Y'
         AND PUSH_OR_PULL = 'PUSH'--推式
         AND SR.SETTLE_RECNT_FLAG = '00'; --只对已经结算对账过数据重新对账，对SETTLE_RECNT_FLAG等于空不重新对账;
         
    R_SO_RECNT_SETTLE C_SO_RECNT_SETTLE_PUSH%ROWTYPE;

    --未结算对账或对账失败，且状态为打开的记录 拉式
    CURSOR C_SO_RECNT_SETTLE_PULL IS
      SELECT SR.RECNT_ID,
             SR.SO_HEADER_ID,
             SR.SO_NUM,
             SR.ERP_OU_ID,
             SR.BILL_TYPE_NAME,
             SR.BIZ_SRC_BILL_TYPE_CODE,
             SR.ENTITY_ID,
             SR.RETURN_MODE,
             SR.ERP_LOGIST_HEADER_ID,
             SR.ORIG_SO_NUM              
        FROM T_SO_RECONCILIATION SR, T_SO_HEADER SH
       WHERE SR.SO_HEADER_ID = SH.SO_HEADER_ID
         AND SR.PUSH_OR_PULL = 'PULL'
         AND NVL(SH.ERP_BOOKED_FLAG, 'N') = 'Y' --add by chen.wj 20150122 增加这个条件判断SO变更引ERP是否成功，如果成功才做对账         
         AND SR.SETTLE_RECNT_FLAG = '00'; --只对已经结算对账过数据重新对账，对SETTLE_RECNT_FLAG等于空不重新对账;
  
    --对账信息记录集
    V_SO_RECNT_INFO SO_RECNT_INFO;
  
  BEGIN
    --初始返回值
    P_RESULT  := PKG_SO_PUB.V_RESULT;
    P_ERR_MSG := PKG_SO_PUB.V_SUCCESS;
  
    IF (P_USER_CODE IS NULL) THEN
      V_USER_CODE := PKG_SO_PUB.V_CREATED_BY_SYS;
    ELSE
      V_USER_CODE := P_USER_CODE;
    END IF;

    --审核对账 推式
    FOR R_SO_RECNT_AUDIT IN C_SO_RECNT_AUDIT_PUSH LOOP
      V_SO_RECNT_INFO.RECNT_ID               := R_SO_RECNT_AUDIT.RECNT_ID;
      V_SO_RECNT_INFO.SO_HEADER_ID           := R_SO_RECNT_AUDIT.SO_HEADER_ID;
      V_SO_RECNT_INFO.SO_NUM                 := R_SO_RECNT_AUDIT.SO_NUM;
      V_SO_RECNT_INFO.ERP_OU_ID              := R_SO_RECNT_AUDIT.ERP_OU_ID;
      V_SO_RECNT_INFO.BILL_TYPE_NAME         := R_SO_RECNT_AUDIT.BILL_TYPE_NAME;
      V_SO_RECNT_INFO.BIZ_SRC_BILL_TYPE_CODE := R_SO_RECNT_AUDIT.BIZ_SRC_BILL_TYPE_CODE;
      V_SO_RECNT_INFO.ENTITY_ID              := R_SO_RECNT_AUDIT.ENTITY_ID;
      V_SO_RECNT_INFO.RETURN_MODE            := R_SO_RECNT_AUDIT.RETURN_MODE;
      V_SO_RECNT_INFO.ERP_LOGIST_HEADER_ID   := R_SO_RECNT_AUDIT.ERP_LOGIST_HEADER_ID;
      V_SO_RECNT_INFO.ORIG_SO_NUM            := R_SO_RECNT_AUDIT.ORIG_SO_NUM;
         
      --对账处理
      P_SO_COM2ERP_PROCESS(V_SO_RECNT_INFO,
                                  V_FLAG_AUDIT,
                                  V_USER_CODE,
                                  'Y',
                                  P_RESULT,
                                  P_ERR_MSG);
                                  
      IF P_RESULT < 0 THEN
        RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      END IF;
    END LOOP;
    
    
    --结算对账 推式
    FOR R_SO_RECNT_SETTLE IN C_SO_RECNT_SETTLE_PUSH LOOP
      V_SO_RECNT_INFO.RECNT_ID               := R_SO_RECNT_SETTLE.RECNT_ID;
      V_SO_RECNT_INFO.SO_HEADER_ID           := R_SO_RECNT_SETTLE.SO_HEADER_ID;
      V_SO_RECNT_INFO.SO_NUM                 := R_SO_RECNT_SETTLE.SO_NUM;
      V_SO_RECNT_INFO.ERP_OU_ID              := R_SO_RECNT_SETTLE.ERP_OU_ID;
      V_SO_RECNT_INFO.BILL_TYPE_NAME         := R_SO_RECNT_SETTLE.BILL_TYPE_NAME;
      V_SO_RECNT_INFO.BIZ_SRC_BILL_TYPE_CODE := R_SO_RECNT_SETTLE.BIZ_SRC_BILL_TYPE_CODE;
      V_SO_RECNT_INFO.ENTITY_ID              := R_SO_RECNT_SETTLE.ENTITY_ID;
      V_SO_RECNT_INFO.RETURN_MODE            := R_SO_RECNT_SETTLE.RETURN_MODE;
      V_SO_RECNT_INFO.ERP_LOGIST_HEADER_ID   := R_SO_RECNT_SETTLE.ERP_LOGIST_HEADER_ID;
      V_SO_RECNT_INFO.ORIG_SO_NUM            := R_SO_RECNT_SETTLE.ORIG_SO_NUM;
    
      P_SO_COM2ERP_PROCESS(V_SO_RECNT_INFO,
                                  V_FLAG_SETTLE,
                                  V_USER_CODE,
                                  'Y',
                                  P_RESULT,
                                  P_ERR_MSG);
                                 
      IF P_RESULT < 0 THEN
        RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      END IF;
    END LOOP;

    --结算对账 拉式
    FOR R_SO_RECNT_SETTLE IN C_SO_RECNT_SETTLE_PULL LOOP
      V_SO_RECNT_INFO.RECNT_ID               := R_SO_RECNT_SETTLE.RECNT_ID;
      V_SO_RECNT_INFO.SO_HEADER_ID           := R_SO_RECNT_SETTLE.SO_HEADER_ID;
      V_SO_RECNT_INFO.SO_NUM                 := R_SO_RECNT_SETTLE.SO_NUM;
      V_SO_RECNT_INFO.ERP_OU_ID              := R_SO_RECNT_SETTLE.ERP_OU_ID;
      V_SO_RECNT_INFO.BILL_TYPE_NAME         := R_SO_RECNT_SETTLE.BILL_TYPE_NAME;
      V_SO_RECNT_INFO.BIZ_SRC_BILL_TYPE_CODE := R_SO_RECNT_SETTLE.BIZ_SRC_BILL_TYPE_CODE;
      V_SO_RECNT_INFO.ENTITY_ID              := R_SO_RECNT_SETTLE.ENTITY_ID;
      V_SO_RECNT_INFO.RETURN_MODE            := R_SO_RECNT_SETTLE.RETURN_MODE;
      V_SO_RECNT_INFO.ERP_LOGIST_HEADER_ID   := R_SO_RECNT_SETTLE.ERP_LOGIST_HEADER_ID;
      V_SO_RECNT_INFO.ORIG_SO_NUM            := R_SO_RECNT_SETTLE.ORIG_SO_NUM;
    
      P_SO_COM2ERP_PROCESS(V_SO_RECNT_INFO,
                                  V_FLAG_SETTLE,
                                  V_USER_CODE,
                                  'Y',
                                  P_RESULT,
                                  P_ERR_MSG);
                                 
      IF P_RESULT < 0 THEN
        RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      END IF;
    END LOOP;
      
  EXCEPTION
    WHEN PKG_SO_PUB.V_BIZ_EXCEPTION THEN
      P_RESULT  := -28210;
      P_ERR_MSG := '销售对账出错，' || P_ERR_MSG;
    WHEN OTHERS THEN
      P_RESULT  := -28210;
      P_ERR_MSG := '销售对账发生异常，' || SQLERRM;
  END;                                          
END PKG_SO_ERP;
/

