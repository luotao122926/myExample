create PACKAGE      PKG_INV_TRANSACTION IS

    --检测是否调用物料事务(可以单独使用)
    PROCEDURE check_transaction_yesOrNo_p(
        in_entity_id            IN    T_INV_TRANSACTION_HISTORY.entity_id%TYPE,--经营主体ID
        in_bill_type_id            IN    T_INV_BILL_TYPES.bill_type_id%TYPE,--单据类型ID
        is_business_state        IN    T_INV_TRANSACTION_HISTORY.business_state%TYPE,--单据状态
        os_transaction_flag        OUT    VARCHAR2,--是否调用物料事物 是（Y）、否（N）
        on_flag                    OUT    NUMBER,
        os_prompt                OUT    VARCHAR2
    );
    --add by lingyy 2014-12-09 获取业务单据信息
    PROCEDURE get_bill_info_p(
    in_entity_id            IN    T_INV_TRANSACTION_HISTORY.entity_id%TYPE,--经营主体ID
        in_business_header_id    IN    T_INV_TRANSACTION_HISTORY.business_header_id%TYPE,--业务单据头ID
        is_bill_kind                IN        VARCHAR2,--B1（采购中转）、B2（仓库调拨）、B3（仓库盘点）、B4（销售）、B5（推广物料）
        on_flag                    OUT    NUMBER,
        os_prompt                OUT    VARCHAR2
    );
    --数据准备
    PROCEDURE init_p(
        in_business_header_id    IN    T_INV_TRANSACTION_HISTORY.business_header_id%TYPE,--业务单据头ID
        is_bill_kind                IN        VARCHAR2,--B1（采购中转）、B2（仓库调拨）、B3（仓库盘点）、B4（销售）、B5（推广物料）
        is_business_state        IN    T_INV_TRANSACTION_HISTORY.business_state%TYPE,--单据状态
        os_whether_same_inv       OUT      VARCHAR2, --是否相同仓库
        on_flag                   OUT      NUMBER,
        os_prompt                 OUT      VARCHAR2
    );

    --基本信息校验(可以单独使用)
    PROCEDURE check_bill_info(
        in_entity_id            IN    T_INV_TRANSACTION_HISTORY.entity_id%TYPE,--经营主体ID
        is_business_state        IN    T_INV_TRANSACTION_HISTORY.business_state%TYPE,--单据状态
        id_transaction_date        IN    T_INV_TRANSACTION_HISTORY.transaction_date%TYPE,--业务日期
        in_source_type_id        IN    T_INV_BILL_TYPES.source_type_id%TYPE,--单据源类型ID
        in_transaction_type_id    IN    T_INV_BILL_PERIOD_LINE.transaction_type_id%TYPE,--物料事务类型ID
        in_if_null                IN    NUMBER,--是否是空的业务单据，0否，1是
        on_flag                   OUT      NUMBER,
        os_prompt                 OUT      VARCHAR2
    );
    --写物料事务历史
    PROCEDURE inv_transaction_deal(
        in_if_null                IN    NUMBER,--是否是空的业务单据，0否，1是
        on_flag                    OUT    NUMBER,
        os_prompt                OUT    VARCHAR2
    );
    --比对业务单据和历史表的数据是否一致
    PROCEDURE inv_bill_history_check(
    on_flag                    OUT    NUMBER,
    os_prompt                OUT    VARCHAR2,
    on_if_dif                OUT    NUMBER--0不同;1相同
    );

    --更新现有量表
    PROCEDURE inv_update_onhand(
        id_transaction_date        IN    T_INV_TRANSACTION_HISTORY.transaction_date%TYPE,--业务日期
        on_flag                    OUT    NUMBER,
        os_prompt                OUT    VARCHAR2
    );

    PROCEDURE inv_update_reconciliation(
    in_if_null                IN    NUMBER,--是否是空的业务单据，0否，1是
    on_flag                    OUT    NUMBER,
    os_prompt                OUT    VARCHAR2
    );

    --重算时的特殊处理
    PROCEDURE recount_transaction_deal_p(
        in_entity_id            IN    T_INV_TRANSACTION_HISTORY.entity_id%TYPE,--经营主体ID
        in_business_header_id    IN    T_INV_TRANSACTION_HISTORY.business_header_id%TYPE,--业务单据头ID
        in_business_state        IN    T_INV_TRANSACTION_HISTORY.business_state%TYPE, --业务类型
        in_bill_type_id            IN    T_INV_BILL_TYPES.bill_type_id%TYPE,--单据类型ID
        on_flag                    OUT    NUMBER,
        os_prompt                OUT    VARCHAR2
    );

    --物料事务处理总过程
    PROCEDURE inv_transaction_total_deal(
        in_entity_id            IN    T_INV_TRANSACTION_HISTORY.entity_id%TYPE,--经营主体ID
        in_bill_type_id            IN    T_INV_BILL_TYPES.bill_type_id%TYPE,--单据类型ID
        is_business_state        IN    T_INV_TRANSACTION_HISTORY.business_state%TYPE,--单据状态
        id_transaction_date        IN    T_INV_TRANSACTION_HISTORY.transaction_date%TYPE,--业务日期
        in_business_header_id    IN    T_INV_TRANSACTION_HISTORY.business_header_id%TYPE,--业务单据头ID
        in_if_null                IN    NUMBER,--是否是空的业务单据，0否，1是
        is_bill_kind                IN        VARCHAR2,--B1（采购中转）、B2（仓库调拨）、B3（仓库盘点）、B4（销售）、B5（推广物料）
        on_flag                    OUT    NUMBER,
        os_prompt                OUT    VARCHAR2
    );
    
    --写物料事务历史前检查负库存
    PROCEDURE inv_transaction_onhand_check(
        in_if_null                IN     NUMBER,--是否是空的业务单据，0否，1是
        id_transaction_date       IN       t_inv_transaction_history.transaction_date%TYPE,
        on_flag                   OUT    NUMBER,
        os_prompt                 OUT    VARCHAR2
    );
    
          --写物料事务历史前检查负库存
   PROCEDURE inv_transaction_negative(
        in_if_null                IN     NUMBER,--是否是空的业务单据，0否，1是
        id_transaction_date       IN       t_inv_transaction_history.transaction_date%TYPE,
        in_inventory_id           IN     NUMBER,
        in_item_id                IN     NUMBER,
        in_quantity               IN     NUMBER,
        on_flag                   OUT    NUMBER,
        os_prompt                 OUT    VARCHAR2
    );

END PKG_INV_TRANSACTION;
/

