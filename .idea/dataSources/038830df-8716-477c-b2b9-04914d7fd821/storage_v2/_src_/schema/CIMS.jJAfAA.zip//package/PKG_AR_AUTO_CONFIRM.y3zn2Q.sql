create package      PKG_AR_AUTO_CONFIRM is

  -- Author  : TIANMENGZHU
  -- Created : 2015/3/30 10:26:57
  -- Purpose : 财务收款自动确认

  V_BIZ_EXCEPTION EXCEPTION; --自定义业务异常

  /*
  * 收款自动确认，根据收款方法配置的业务分类、是否自动确认，过滤制单状态的收款，插入ERP收款接口表，
  */
  Procedure P_CONFIRM_RECEIPT(P_RESULT OUT VARCHAR2 --返回错误信息
                              );

  /*
  *自动确认成功/失败，更新收款头表对应字段
  *成功：引入ERP标志、引入资金标志更新为“Y”；ATTRIBUTE8更新“自动确认成功”；确认人=admin、确认时间=sysdate、单据状态=3；
  *失败：将错误信息写入ATTRIBUTE8
  */
  FUNCTION F_UPDATE_RECEIPT_HEAD(P_CASH_RECEIPT_ID T_AR_CASH_RECEIPT_HEADERS.CASH_RECEIPT_ID%TYPE, --收款ID（收款）
                                 P_INTO_ERP_FLAG   T_AR_RECEIPT_METHODS.INTO_ERP_FLAG%TYPE, --引入ERP标志
                                 P_INTO_BAN_FLAG   T_AR_RECEIPT_METHODS.INTO_BAN_FLAG%TYPE, --引入资金标志
                                 P_ERROR_INFO      VARCHAR2 --错误信息
                                 ) RETURN VARCHAR2;
end PKG_AR_AUTO_CONFIRM;
/

