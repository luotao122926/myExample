create PACKAGE PKG_BD_DATAPRIV  AS
  --通用数据权限的VPD策略
  function F_VPD_FOR_ALL(p_schema in varchar2 default NULL,
                       p_object in varchar2 default NULL) RETURN varchar2;

  --获以数据权限的VPD filter函数
  function F_VPD_GET_FILTER(p_table in varchar2 ,
                       p_client_identifier in varchar2 ) RETURN varchar2;
  --增加表的应用策略
   procedure P_VPD_AddPolicy(t_policy_table in varchar2 default NULL);

   --取消表的应用策略
   procedure P_VPD_DropPolicy(t_policy_table in varchar2 default NULL);

   --同步权限数据至权限中间表
   procedure P_SYC_PRIVDATA(
             P_USER_ID    IN NUMBER,
             P_ENTITY_ID  IN NUMBER,
             P_DATA_TYPE  IN VARCHAR2,
             P_RESULT     OUT NUMBER, --返回错误ID
             P_ERR_MSG    OUT VARCHAR2 --返回错误信息
   );
   
    --复制用户权限 lilh6 2019-1-22
   Procedure p_Copy_User_privdata(p_User_Code1 In Varchar2, --授权用户编码
                                   p_User_Code2 In Varchar2, --复制用户编码
                                   p_Entity_Id  In Number, --主体id
                                   p_copy_type  In Varchar2,--复制的权限类型
                                   p_Result     Out Varchar2 --返回错误ID
                                   );



END PKG_BD_DATAPRIV;
/

