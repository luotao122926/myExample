create Package Body Pkg_Pln_Lg_Collect Is

v_Nl      Constant Varchar2(2) := Chr(13) || Chr(10); --换行
  v_Null    Constant Varchar2(4) := 'NULL'; --空值
  v_True    Constant Varchar2(2) := 'Y';
  v_False   Constant Varchar2(2) := 'N';
  v_Result  Constant Number := 0; --成功返回
  v_Success Constant Varchar2(10) := 'SUCCESS';
  v_Failure Constant Varchar2(10) := 'FAILURE';
  v_Base_Exception Exception; --自定义异常
 
  v_Docking_System_A3    Constant Varchar2(100) := 'A3'; --A3系统管理仓库
  v_Docking_System_CIMS  Constant Varchar2(100) := 'CIMS'; --CIMS系统管理的仓库
  v_Bill_Allot_Type_Code    Varchar2(100) := '1033';
  v_Bill_Sales_Type_Code    Varchar2(100) := '1020';
  
  v_Review_Type_Share_Ship      Varchar2(100) := 'PLN_SHARE_SHIP';  --发货计划
  v_Review_Type_Store_Up_Stock  Varchar2(100) := 'INV_STORE_UP_STOCK'; --备货库存
  v_Review_Type_Match_Ship      Varchar2(100) := 'PLN_MATCH_ORDER_SHIP'; --匹配订单发货
  
  v_Line_State_Closed     Varchar2(32) := 'CLOSED'; --已关闭状态
  v_Line_State_Awaited    Varchar2(32) := 'AWAITED'; --待关闭状态
  v_Line_State_Normal      Varchar2(32) := 'NORMAL'; --正常 
  
  v_Active Constant Varchar2(10) := 'Active';  --可用激活状态
  
  v_global_action VARCHAR2(100);
  
  v_Discount_Type_Common Varchar2(32) := 'COMMON'; --常规到款
  v_Discount_Type_Discount Varchar2(32) := 'DISCOUNT';  --折让到款

  -----------------------------------------------------------------------------
  -- AUTHOR  : Nicro.Li
  -- CREATED : 2017-10-24
  -- PURPOSE : T提货订单汇总预约结转
  -----------------------------------------------------------------------------   
  Procedure p_Reservation_Collect(In_Entity_Id        In Number, --订单ID
                                  In_Check_Begin_Date In Date, --送审开始日期
                                  In_Check_End_Date   In Date, --送审结束日期
                                  In_User_Code        In Varchar2, --用户编码
                                  Out_Result          Out Varchar2 --返回结果：SUCCESS——>过程执行完成；FAILURE——>中途抛错
                                  ) is
     Cursor c_LgOrder_Line Is
      Select *
        From t_Pln_Lg_Order_Head  oh
       Where  oh.order_head_id in   -- add by ex_zhangcc
         (select h.order_head_id from  t_pln_lg_order_head h,
                         t_pln_lg_order_line Lol
                  where h.order_head_id=lol.order_head_id
                  and h.entity_id in
                   (select e.entity_id
                      from up_codelist u, up_codelist_entity e
                     where u.codetype = 'plnMergeEntity'
                       and u.id = e.codelist_id
                       and u.code_value=In_Entity_Id
                       )
        -- And h.Entity_Id = In_Entity_Id
         And Exists
       (Select *
                From t_Pln_Order_Type Ot
               Where Ot.Source_Order_Type_Id = 1
                 And Upper(Nvl(Ot.Is_Business_Control, '_')) Not In('SHARE_SHIP_ORDER', 'PRO_ORDER')
                 And Ot.Order_Type_Id = h.Order_Type_Id
                 And Ot.Entity_Id =h.entity_id --  mody by ex_zhangcc
                 )
         And h.order_date Between  In_Check_Begin_Date  And
             In_Check_End_Date
         And Not Exists (Select 1
                From t_Pln_Lg_Relation Lr
               Where Lr.Lg_Order_Line_Id = Lol.Order_Line_Id
                 And Lr.Lg_Order_Head_Id = h.Order_Head_Id)
         And Not Exists
       (Select 1
                From t_pln_reservation_coll_line Lcl
               Where Lcl.Order_Head_Id = h.Order_Head_Id
                 And Lcl.Order_Line_Id = Lol.Order_Line_Id)
        AND nvl(lOL.Collect_Order_Line_Flag,'N') <>'Y' --ADD BY ex_zhangcc
        And nvl(Lol.is_marked_collect_flag,'N') = 'Y'
        AND nvl(lol.lock_inv_pre, 0) = 0 --hejy3 没有做预占用
           and h.order_Head_State in ('679', '381')) for update nowait;
    r_LgOrder_Line   c_LgOrder_Line%Rowtype;
    Type c_Get_LgOrder_Line Is Ref Cursor;
    v_Get_LgOrder_Line c_Get_LgOrder_Line;
    v_Check_Sql    Varchar2(5000);
    v_Insert_Sql   Varchar2(5000);
    v_Sql_Fmt      Varchar2(3000);
    v_Sql_Where    Varchar2(3000);
    v_Sql_Qty      Varchar2(2000);
    v_Groupby      Varchar2(2000);
    v_Update_Sql   Varchar2(3000);
    v_Update_Where Varchar2(1000);
    v_Count        Number;
    v_Index        Number;
    v_Order_Number_List  Varchar2(4000);
    v_Seq_Num      Number;
    v_Mrp_Org_Code   Varchar2(400);
    v_Consignee_Group Varchar2(300);
    v_Integral_Transport_Days  Number;
  Begin
    Out_Result := v_Success;
    v_Count  := 0;
    -- 锁定表汇总提货订单头
    begin
      Open c_LgOrder_Line;
    Exception
     when others then
       Out_Result := '打开游标失败,锁定提货订单头失败!' || v_Nl || sqlerrm;
       raise v_Base_Exception;
    end;
    

    --组合汇条件字段
    For r_Para In (Select Decode(Upper(Trim(Ocp.Column_Code)),
                                  'CONSIGNEE_ADDR_NAME',
                                  'Nvl(' || Trim(Ocp.Table_Alias) || '.PRIMARY_CONSIGNEE_ADDR, ' ||
                                  Trim(Ocp.Table_Alias) || '.' || Trim(Ocp.Column_Code) || ') CONSIGNEE_ADDR_NAME',
                                  Trim(Ocp.Table_Alias) || '.' || Trim(Ocp.Column_Code)) Field,
                          Decode(Upper(Trim(Ocp.Column_Code)),
                                  'CONSIGNEE_ADDR_NAME',
                                  'Nvl(' || Trim(Ocp.Table_Alias) || '.PRIMARY_CONSIGNEE_ADDR, ' ||
                                  Trim(Ocp.Table_Alias) || '.' || Trim(Ocp.Column_Code) || ')',
                                  Trim(Ocp.Table_Alias) || '.' || Trim(Ocp.Column_Code)) FieldGroup, 
                          Ocp.*
                     From t_Pln_Ord_Collect_Param Ocp
                    Where Ocp.Entity_Id = In_Entity_Id
                      And Ocp.Is_Group_By = 'Y'
                      And Ocp.Param_Type = 'RC_COLLECT_TYPE'
                    Order By Ocp.Seq_Num
                      ) Loop
      If Upper(r_Para.Column_Code) = 'CONSIGNEE_ADDR_NAME' Then
        v_Consignee_Group := r_Para.Table_Alias || '.CONSIGNEE_ADDR_CODE';
      End If;
      v_Count := v_Count + 1;
      If v_Sql_Fmt Is Null Then
        v_Sql_Fmt := r_Para.Field;
      Else
        v_Sql_Fmt := v_Sql_Fmt || ',' || r_Para.Field;
      End If;
      --汇总动态条件
      If v_Groupby Is Null Then
        v_Groupby := r_Para.Fieldgroup;
      Else
        v_Groupby := v_Groupby || ',' || r_Para.Fieldgroup;
      End If;
      
      --插入汇总数据汇总条件SQL条件
      If Upper(r_Para.Column_Code) = 'CARLOAD_MEET_NUM' Then
        If v_Sql_Where Is Null Then
          v_Sql_Where := ' Nvl(Ch.pre_field_' || Trim(To_Char(v_Count, '00')) || ', ''_'') = Nvl(' ||  r_Para.Fieldgroup || ', ''_'')';
        Else
          v_Sql_Where := v_Sql_Where || ' And ' ||
             ' Nvl(Ch.pre_field_' || Trim(To_Char(v_Count, '00')) || ', ''_'') = Nvl(' ||  r_Para.Fieldgroup || ', ''_'')';
        End If;
        --更新产地数量汇总条件SQL条件
        If v_Update_Where Is Null Then
          v_Update_Where := ' Nvl(Ch.pre_field_' || Trim(To_Char(v_Count, '00')) || ', ''_'') = Nvl(' ||  r_Para.Fieldgroup || ', ''_'')';
        Else
          v_Update_Where := v_Update_Where || ' And ' ||
             ' Nvl(Ch.pre_field_' || Trim(To_Char(v_Count, '00')) || ', ''_'') = Nvl(' ||  r_Para.Fieldgroup || ', ''_'')';
        End If;
      Else
        If v_Sql_Where Is Null Then
          v_Sql_Where := ' Ch.pre_field_' || Trim(To_Char(v_Count, '00')) || ' = ' ||  r_Para.Fieldgroup;
        Else
          v_Sql_Where := v_Sql_Where || ' And ' ||
             ' Ch.pre_field_' || Trim(To_Char(v_Count, '00')) || ' = ' ||  r_Para.Fieldgroup;
        End If;
        --更新产地数量汇总条件SQL条件
        If v_Update_Where Is Null Then
          v_Update_Where := ' Ch.pre_field_' || Trim(To_Char(v_Count, '00')) || ' = ' ||  r_Para.Fieldgroup;
        Else
          v_Update_Where := v_Update_Where || ' And ' ||
             ' Ch.pre_field_' || Trim(To_Char(v_Count, '00')) || ' = ' ||  r_Para.Fieldgroup;
        End If;
      End If;
    End Loop;
    --增加收货地址ID写入
    If v_Consignee_Group Is Not Null Then
      v_Sql_Fmt := v_Sql_Fmt || ',' || v_Consignee_Group;
      v_Groupby := v_Groupby || ',' || v_Consignee_Group;
    End If;
    For i In 1..v_Count Loop
      If v_Insert_Sql Is Null Then
        v_Insert_Sql := 'pre_field_' || Trim(To_Char(i, '00'));
      Else
        v_Insert_Sql := v_Insert_Sql || ',' || 'pre_field_' || Trim(To_Char(i, '00'));
      End If;
    End Loop;
    If v_Consignee_Group Is Not Null Then
      v_Insert_Sql := v_Insert_Sql || ',CONSIGNEE_ADDR_CODE ';
    End If;
    If v_Groupby Is Null Then
      Out_Result := '未设置提货订单汇总条件，汇总提货订单数据失败！';
      Raise v_Base_Exception;
    End If;


    --组合SQL生成汇总头表
    v_Insert_Sql := 'insert into t_pln_reservation_coll_head(reservation_Head_Id,Entity_Id, Created_By, Creation_Date, Last_Updated_By,Last_Update_Date,' ||
                    ' Collect_Date,' || v_Insert_Sql || ', coll_qty, coll_volume)';
    v_Sql_Fmt := 'select s_pln_reservation_coll_head.Nextval,' || Chr(10) ||
                in_Entity_Id || ',' || Chr(10) ||
                ' ''' || In_User_Code || ''',' || Chr(10) ||
                ' Sysdate,' || Chr(10) ||
                ' ''' || In_User_Code || ''',' || Chr(10) ||
                ' Sysdate,'||
                'trunc(sysdate),'||
                'Lg.* From (' || Chr(10) ||
                'Select '||v_Sql_Fmt || Chr(10) ||
                '      ,Sum(Nvl(LoL.SUBMIT_HQ_QTY, 0)  -' || Chr(10) ||
                '       Nvl(Lol.HQ_AFFIRMED_QTY, 0)),' || Chr(10) ||
                '       Sum(Round((Nvl(LoL.SUBMIT_HQ_QTY, 0) -' || Chr(10) ||
                '              Nvl(Lol.HQ_AFFIRMED_QTY, 0)) * Lol.Unit_Volume,' || Chr(10) ||
                '             2)) ' || Chr(10) ||
                '  From t_Pln_Lg_Order_Head  Loh,' || Chr(10) ||
                '       t_Pln_Lg_Order_Line  Lol,' || Chr(10) ||
                '       t_Pln_Producing_Area Ppa' || Chr(10) ||
                ' Where Loh.Order_Head_Id = Lol.Order_Head_Id' || Chr(10) ||
                '   And Lol.Producing_Area_Id = Ppa.Producing_Area_Id(+)' || Chr(10) ||
                '   And Loh.Entity_Id  in (' || Chr(10) ||
                'select e.entity_id from up_codelist u, up_codelist_entity e' ||chr(10)||
                ' where u.codetype = ''plnMergeEntity'''|| chr(10)||
                'and u.id = e.codelist_id' || chr(10) ||
                'and u.code_value = :1)' || chr(10) ||
                ' And Loh.Order_Type_Id In (Select  Ot.Order_Type_Id ' || Chr(10) ||
                '            From t_Pln_Order_Type Ot' || Chr(10) ||
                '           Where Ot.Source_Order_Type_Id = 1' || Chr(10) ||
                '             And Upper(Nvl(Ot.Is_Business_Control, ''_'')) Not In(''SHARE_SHIP_ORDER'', ''PRO_ORDER'')' || Chr(10) ||
                '   And Ot.Entity_Id  in (' || Chr(10) ||
                'select e.entity_id from up_codelist u, up_codelist_entity e' ||chr(10)||
                ' where u.codetype = ''plnMergeEntity'''|| chr(10)||
                'and u.id = e.codelist_id' || chr(10) ||
                'and u.code_value = :2))' || chr(10) ||                
                ' And Loh.To_Checkup_Date BETWEEN :3 And :4 ' ||
                --当天已生成汇总数据且未转T+3的不再生成汇总头
                ' And Not Exists' || chr(10) ||
                '         (Select 1' || chr(10) ||
                '                  From t_pln_reservation_coll_head Ch' || Chr(10) ||
                '                 Where Ch.Entity_Id in(
                  select e.entity_id from up_codelist u, up_codelist_entity e
                  where u.codetype = ''plnMergeEntity''
                  and u.id = e.codelist_id
                  and u.code_value = :5)' || chr(10) ||
                '             And Nvl(Ch.Reservation_Flag, ''N'') = ''N'' '|| Chr(10) ||
                '                   And Nvl(Ch.To_Plnorder_Flag, ''N'') != ''Y'' And ' || v_Sql_Where ||
                '                   And Ch.Collect_Date = Trunc(Sysdate))' || Chr(10) ||
                --  --未转T+3提货订单
                '   And Not Exists (Select 1' || Chr(10) ||
                '          From t_Pln_Lg_Relation Lr' || Chr(10) ||
                '         Where Lr.Lg_Order_Line_Id = Lol.Order_Line_Id' || Chr(10) ||
                '           And Lr.Lg_Order_Head_Id = Loh.Order_Head_Id)' || Chr(10) ||
                --待转T+3为0的数据不汇总
                '  And  Nvl(LoL.SUBMIT_HQ_QTY, 0) -' || Chr(10) ||
                '       Nvl(Lol.HQ_AFFIRMED_QTY, 0) > 0 ' || Chr(10) ||
                ' and Loh.order_Head_State in (''679'', ''381'')' ||
                ' and nvl(Lol.is_marked_collect_flag,''N'')=''R'''||
                --add by lizhen 2016-06-22 已关闭订单行不进行汇总操作
                ' And Nvl(Lol.Order_Line_State, ''NORMAL'') != ''CLOSED'' ' || Chr(10) ||
                ' and nvl(lol.lock_inv_pre, 0) = 0' || Chr(10) || --hejy3 没有做预占用
                ' And Nvl(Lol.Collect_Order_Line_Flag, ''N'') = ''N'' ' || Chr(10) || --lizhen 2017-07-24
                ' Group By  ' || v_Groupby || 
                ' Order By ' || v_Groupby || ' ) Lg' ;

    Begin
      --插入提货汇总头数据
      Execute Immediate v_Insert_Sql || chr(10) || v_Sql_Fmt
      Using In_Entity_Id, In_Entity_Id, In_Check_Begin_Date, To_Date(To_Char(In_Check_End_Date, 'YYYY-MM-DD') || ' 23:59:59', 'YYYY-MM-DD HH24:mi:ss'), In_Entity_Id;
      --dbms_output.put_line(v_Insert_Sql || chr(10) || v_Sql_Fmt);
    Exception
      When Others Then
        Out_Result := '插入提货订单汇总头数据失败！'  || v_Nl || Sqlerrm;
        dbms_output.put_line(v_Insert_Sql || chr(10) || v_Sql_Fmt);
        Raise v_Base_Exception;
    End;
    --更新汇总单单号
    Update t_pln_reservation_coll_head h
       Set h.reservation_coll_number = Pkg_Bd.f_Get_Bill_No('PLN_RESERVATION_COLLECT',
                                                   Null,
                                                   In_Entity_Id,
                                                   Null)
     Where h.Collect_Date = Trunc(Sysdate)
       And h.reservation_coll_number Is Null;


    --开始循环前写入提货订单行数据
    v_Insert_Sql := 'Insert Into t_pln_reservation_coll_line (reservation_Line_Id, reservation_Head_Id,serial_number,  Order_Head_Id,' || Chr(10) ||
        '   Order_Line_Id, Order_Number, Item_Id, Item_Code, Item_Name, Item_Unit, Item_Price,' || Chr(10) ||
        '   Item_Volume, Apply_Qty, Center_Check_Qty, Affirmed_Qty, To_Plnorder_Qty,' || Chr(10) ||
        '   To_Plnorder_Volume, Producing_Area_Id, Producing_Area_Name, Mrp_Org_Code, Customer_Code, Customer_Name,' || Chr(10) ||
        '   Sales_Center_Code, Sales_Center_Name, Order_Type_Id, Order_Type_Name,' || Chr(10) ||
        '   Project_Order_Type, Project_Order_Number, Project_Order_Line_Id, Apply_List_Price, Apply_Discount_Rate,' || Chr(10) ||
        '   Created_By, Creation_Date, Last_Updated_By, Last_Update_Date,' || Chr(10) ||
        '   Program_Updated_By, Program_Update_Date, Version, Entity_Id, Sales_Main_Type, Sales_Sub_Type)' ||
        ' Select s_pln_reservation_coll_line.Nextval, Lg.* From (' || Chr(10) ||
        '  select (Select ch.reservation_Head_Id' || Chr(10) ||
        '          From t_pln_reservation_coll_head Ch' || Chr(10) ||
        '         Where '||
        '             Nvl(Ch.To_Plnorder_Flag, ''N'') != ''Y''' || Chr(10) ||
        '             And Nvl(Ch.Reservation_Flag, ''N'') = ''N'' '|| Chr(10) ||
        --20161215 hejy3 不用trunc
        --'           And Trunc(Ch.Collect_Date) = Trunc(Sysdate) And ' || Chr(10) || v_Sql_Where ||
        '           And Ch.Collect_Date = Trunc(Sysdate) And ' || Chr(10) || v_Sql_Where ||
        '   And Ch.Entity_Id in ( ' || Chr(10) ||
        -- add by ex_zhangcc 2015-11-19
        'select e.entity_id from up_codelist u, up_codelist_entity e' ||chr(10)||
        ' where u.codetype = ''plnMergeEntity'''|| chr(10)||
        ' and u.id = e.codelist_id' || chr(10) ||
        ' and u.code_value = '''|| To_Char(In_Entity_Id) || ''')' || chr(10) ||
        --add by lizhen 2016-08-24 拆份多张单据后只取1行
        '       And Rownum <= 1) COLLECT_HEAD_ID,' || Chr(10) ||
        '       Rownum, ' || Chr(10) ||
        '       Loh.Order_Head_Id,' || Chr(10) ||
        '       Order_Line_Id,' || Chr(10) ||
        '       Loh.Order_Number,' || Chr(10) ||
        '       Lol.Item_Id,' || Chr(10) ||
        '       Lol.Item_Code,' || Chr(10) ||
        '       Lol.Item_Name,' || Chr(10) ||
        '       Lol.Default_Unit,' || Chr(10) ||
        '       Lol.List_Price,' || Chr(10) ||
        '       Lol.Unit_Volume,' || Chr(10) ||
        '       Lol.Quantity,' || Chr(10) ||
        '       Lol.Center_Affirm_Quantity,' || Chr(10) ||
        '       Lol.Affirmed_Quantity,' || Chr(10) ||
        '       Nvl(LoL.SUBMIT_HQ_QTY, 0)  -' || Chr(10) ||
        '       Nvl(Lol.HQ_AFFIRMED_QTY, 0) To_Plnorder_Qty,' || Chr(10) ||
        '       Round((Nvl(LoL.SUBMIT_HQ_QTY, 0) -' || Chr(10) ||
        '              Nvl(Lol.HQ_AFFIRMED_QTY, 0)) * Lol.Unit_Volume,' || Chr(10) ||
        '             2) To_Plnorder_Volume,' || Chr(10) ||
        '       Lol.Producing_Area_Id,' || Chr(10) ||
        '       Ppa.Producing_Area_Name,' || Chr(10) ||
        '       Ppa.Mrp_Org_Code,' || Chr(10) ||
        '       Loh.Customer_Code,' || Chr(10) ||
        '       Loh.Customer_Name,' || Chr(10) ||
        '       Loh.Sales_Center_Code,' || Chr(10) ||
        '       Loh.Sales_Center_Name,' || Chr(10) ||
        '       Loh.Order_Type_Id,' || Chr(10) ||
        '       Loh.Order_Type_Name,' || Chr(10) ||
        '       Lol.Project_Order_Type,' || Chr(10) ||
        '       Lol.Project_Order_Number,' || Chr(10) ||
        '       Lol.Project_Order_Line_Id,' || Chr(10) ||
        '       Lol.Apply_List_Price,' || Chr(10) ||
        '       Lol.Apply_Discount_Rate,' || Chr(10) ||
        '       ''' || In_User_Code || ''' Created_By,' || Chr(10) ||
        '       Sysdate Creation_Date,' || Chr(10) ||
        '       ''' || In_User_Code || ''' Last_Updated_By,' || Chr(10) ||
        '       Sysdate Last_Update_Date,' || Chr(10) ||
        '       ''' || In_User_Code || ''' Program_Updated_By,' || Chr(10) ||
        '       Sysdate Program_Update_Date,' || Chr(10) ||
        '       1 Version,' || Chr(10) ||
        '       Lol.Entity_Id,' || Chr(10) ||
        '       Lol.Sales_Main_Type,' || Chr(10) ||
        '       Lol.Sales_Sub_Type ' || Chr(10) ||
        '  From t_Pln_Lg_Order_Head  Loh,' || Chr(10) ||
        '       t_Pln_Lg_Order_Line  Lol,' || Chr(10) ||
        '       t_Pln_Producing_Area Ppa' || Chr(10) ||
        ' Where Loh.Order_Head_Id = Lol.Order_Head_Id' || Chr(10) ||
        '   And Lol.Producing_Area_Id = Ppa.Producing_Area_Id(+)' || Chr(10) ||
        '   And Loh.Entity_Id in ( ' || Chr(10) ||
        -- add by ex_zhangcc 2015-11-19
          'select e.entity_id from up_codelist u, up_codelist_entity e' ||chr(10)||
                ' where u.codetype = ''plnMergeEntity'''|| chr(10)||
                ' and u.id = e.codelist_id' || chr(10) ||
                ' and u.code_value = :1)' || chr(10) ||
        ' and Loh.order_Head_State in (''679'', ''381'')' ||
        '   And Loh.Order_Type_Id in ' || Chr(10) ||
        ' (Select Ot.Order_Type_Id ' || Chr(10) ||
        '          From t_Pln_Order_Type Ot' || Chr(10) ||
        '         Where Ot.Source_Order_Type_Id = 1' || Chr(10) ||
        '           And Upper(Nvl(Ot.Is_Business_Control, ''_'')) Not In(''SHARE_SHIP_ORDER'', ''PRO_ORDER'') ' || Chr(10) ||
        '   And Ot.Entity_Id  in (' || Chr(10) ||
                'select e.entity_id from up_codelist u, up_codelist_entity e' ||chr(10)||
                ' where u.codetype = ''plnMergeEntity'''|| chr(10)||
                'and u.id = e.codelist_id' || chr(10) ||
                'and u.code_value = :2))' || chr(10) ||   
        ' And Loh.To_Checkup_Date BETWEEN :3 And :4 ' ||
        '   And Exists (Select 1' || Chr(10) ||
        '          From t_pln_reservation_coll_head Ch' || Chr(10) ||
        -- 2015-11-19
        '         Where ' || v_Sql_Where ||
        '           And Nvl(Ch.Reservation_Flag, ''N'') = ''N'' '|| Chr(10) ||
        '           And Nvl(Ch.To_Plnorder_Flag, ''N'') != ''Y''' || Chr(10) ||
        --2015-12-14
        '           And Ch.Entity_Id in ( ' || Chr(10) ||
        -- add by ex_zhangcc 2015-11-19
        '       select e.entity_id from up_codelist u, up_codelist_entity e' ||chr(10)||
        '       where u.codetype = ''plnMergeEntity'''|| chr(10)||
        '       and u.id = e.codelist_id' || chr(10) ||
        '       and u.code_value = '''|| To_Char(In_Entity_Id) || ''')' || chr(10) ||
        --20161215 hejy3 不用trunc
        --'           And Trunc(Ch.Collect_Date) = Trunc(Sysdate))' || Chr(10) ||
        '           And Ch.Collect_Date = Trunc(Sysdate))' || Chr(10) ||
        '   And Not Exists (Select 1' || Chr(10) ||
        '          From t_Pln_Lg_Relation Lr' || Chr(10) ||
        '         Where Lr.Lg_Order_Line_Id = Lol.Order_Line_Id' || Chr(10) ||
        '           And Lr.Lg_Order_Head_Id = Loh.Order_Head_Id)' || Chr(10) ||
        '  And  Nvl(LoL.SUBMIT_HQ_QTY, 0) -' || Chr(10) ||
        '       Nvl(Lol.HQ_AFFIRMED_QTY, 0) > 0 ' || Chr(10) ||
        ' and nvl(Lol.is_marked_collect_flag,''N'')=''R'''||
        ' And Nvl(Lol.Collect_Order_Line_Flag, ''N'') = ''N'' ' || Chr(10) ||
        --add by lizhen 2016-06-22 已关闭订单行不进行汇总操作
        ' And Nvl(Lol.Order_Line_State, ''NORMAL'') != ''CLOSED'' ' || Chr(10) ||
        ' and nvl(lol.lock_inv_pre, 0) = 0' || Chr(10) || --hejy3 没有做预占用
        ' Order By Lol.Item_Code) Lg';
    
    --行入行表数据
    Begin
      Execute Immediate v_Insert_Sql
      Using In_Entity_Id, In_Entity_Id, In_Check_Begin_Date, To_Date(To_Char(In_Check_End_Date, 'YYYY-MM-DD') || ' 23:59:59', 'YYYY-MM-DD HH24:mi:ss');
      dbms_output.put_line('插入行表：' || v_Insert_Sql);
    Exception
      When Others Then
        Out_Result := '插入提货订单汇总明细行失败！' || v_Nl || Sqlerrm;
        dbms_output.put_line(chr(10) || v_Insert_Sql);
        Raise v_Base_Exception;
    End;    

    For r_Head In (Select *
                     From t_Pln_Reservation_Coll_Head Rch
                    Where Rch.Collect_Date = Trunc(Sysdate)
                    And Rch.Entity_Id = In_Entity_Id
                    And Rch.To_Plnorder_Flag = 'N'
                    And Rch.Reservation_Flag = 'N') Loop
      If r_Head.Consignee_Addr_Code Is Not Null Then
        Begin
          Select (Select Integral_Transport_Days
                    From Table(Pkg_Pln_Report.f_Get_Lg_Transport_Line_New(In_Begin_Area_Code => Ppa.District_Code,
                                                                          In_End_Area_Code   => r_Head.Consignee_Addr_Code,
                                                                          In_Entity_Id       => Ppa.Entity_Id)))
            Into v_Integral_Transport_Days
            From t_Pln_Producing_Area Ppa
           Where Ppa.Mrp_Org_Code =
                 Pkg_Pln_Pub.f_Get_Rcordpara_Collect_Value(In_Entity_Id   => r_Head.Entity_Id,
                                                           In_Head_Id     => r_Head.Reservation_Head_Id,
                                                           In_Table_Alias => 'PPA',
                                                           In_Column_Code => 'MRP_ORG_CODE')
             And Ppa.Entity_Id = r_Head.Entity_Id;
        Exception
          When Others Then
            v_Integral_Transport_Days := 0;
        End;
        --更新运输在途天数
        Update t_Pln_Reservation_Coll_Head Rch
           Set Rch.Integral_Transport_Days = v_Integral_Transport_Days
         Where Rch.Reservation_Head_Id = r_Head.Reservation_Head_Id;
      End If;
    End Loop;
    
    Update t_Pln_Reservation_Coll_Head Rch
       Set (Rch.Coll_Qty, Rch.Coll_Volume) =
           (Select Sum(Nvl(Rcl.To_Plnorder_Qty, 0)),
                   Sum(Nvl(Rcl.To_Plnorder_Volume, 0))
              From t_Pln_Reservation_Coll_Line Rcl
             Where Rcl.Reservation_Head_Id = Rch.Reservation_Head_Id)
     Where Rch.Collect_Date = Trunc(Sysdate)
       And Rch.To_Plnorder_Flag = 'N'
       And Rch.Reservation_Flag = 'N';
         
    Update t_Pln_Lg_Order_Line Ol
       Set Ol.Collect_Order_Line_Flag = 'Y',
           Ol.Last_Updated_By         = In_User_Code,
           Ol.Make_Order_Line_Flag    = 'Y',
           ol.reservation_collect_book_flag = 'Y',
           Ol.Last_Update_Date        = Sysdate,
           Ol.Affirm_Quantity         = Null,
           Ol.Inv_Id                  = 0,
           Ol.Inv_Code                = Null,
           Ol.Inv_Name                = Null,
           Ol.Version                 = Nvl(Ol.Version, 0) + 1
     Where Ol.Order_Line_Id In
           (Select Cl.Order_Line_Id
              From t_Pln_Reservation_Coll_Line Cl,
                   t_Pln_Reservation_Coll_Head Ch
             Where Cl.Reservation_Head_Id = Ch.Reservation_Head_Id
               And Ch.Entity_Id In
                   (Select e.Entity_Id
                      From Up_Codelist u, Up_Codelist_Entity e
                     Where u.Codetype = 'plnMergeEntity'
                       And u.Id = e.Codelist_Id
                       And u.Code_Value = To_Char(In_Entity_Id))
               And Ch.Collect_Date = Trunc(Sysdate)
               And Ch.To_Plnorder_Flag != 'Y');
  Exception
    When v_Base_Exception Then
      Out_Result := Out_Result || subStr(dbms_utility.format_error_backtrace,1,100);
      Rollback;
    When Others Then
      Out_Result := Out_Result || v_Nl || subStr(Sqlerrm,1200) || subStr(dbms_utility.format_error_backtrace,1,200);
      Rollback;
  END;
  
  -----------------------------------------------------------------------------
  -- AUTHOR  : Nicro.Li
  -- CREATED : 2016-08-17
  -- PURPOSE : 提货订单预约汇总数据转T+3订单, 只处理单1主体
  -----------------------------------------------------------------------------
  Procedure p_LgRc_To_PlnOrder_Single(In_Entity_Id       In Number, --主体ID
                                      In_Order_Type_Id   In Number, --订单类型ID
                                      In_Reservation_Head_Id In Number, --提货提货订单头ID
                                      In_User_Code       In Varchar2, --用户编码
                                      Out_Result          In Out Varchar2 --返回结果：SUCCESS——>过程执行完成；FAILURE——>中途抛错
                                      ) Is
    v_Order_Number      Varchar2(50);
    v_End_Date          Date;
    v_Sales_Center_Id   Number;
    v_Sales_Center_Code Varchar2(50);
    v_Sales_Center_Name Varchar2(200);
    v_Customer_Id       Number;
    v_Customer_Code     Varchar2(50);
    v_Customer_Name     Varchar2(320);
    v_Producing_Area_Id Number;
    v_Mrp_Org_Code      Varchar2(60);
    r_Reservation_Head  t_pln_reservation_coll_head%Rowtype;
    r_Order_Type        t_Pln_Order_Type%Rowtype;
    r_Producing_Area    t_Pln_Producing_Area%Rowtype;
    r_Period            t_Pln_Order_Period%Rowtype;
    v_Sql               Varchar2(100);
    v_Order_Head_Id     Number;
    v_Index             Number;
    v_Account_Id        Number;
    v_Acc_Relation_Id   Number;
    v_Consignee_Addr    t_Pln_Order_Head.Consignee_Addr%Type;
    v_Sales_Main_Type   t_Pln_Order_Head.Sales_Main_Type%Type;
    v_Account_Code      t_Customer_Account.Account_Code%Type;
    v_count_line        Number;
    v_Period_Id         Number;
    v_Consignee_Id      Number;
    v_Carload_Meet_Num  t_Pln_Lg_Order_Head.Carload_Meet_Num%Type;
    v_Lg_Order_Number   t_pln_lg_order_head.order_number%Type; --add by lizhen 2017-03-22
    v_Default_PlnOrder_Type_Id     Number; --add by lizhen 2017-03-22
    v_Pln_Walkthrough_Enable_Flag  Varchar2(32); --add by lizhen 2017-03-22
    
    v_auto_inv_review VARCHAR2(10); --是否自动库存评审
    v_err_num NUMBER; --错误号
    
    v_Next_Excute_Step Varchar2(100);
    v_Nextauto_Excute  Varchar2(100);
    v_Next_State       Varchar2(100);
    v_Next_Action      Varchar2(100);
    v_Curr_Action      Varchar2(100);
    v_Curr_State       Varchar2(100);
    v_Can_Option_Flag  Varchar2(2);
  Begin
    Out_Result := v_Success;
    --查找提货汇总订单头
    Begin
      Select *
        Into r_Reservation_Head
        From t_pln_reservation_coll_head Rch
       Where Rch.Reservation_Head_Id = In_Reservation_Head_Id
         --And Tch.Walkthrough_Confirm_Flag = 'Y'
         And Rch.To_Plnorder_Flag = 'N'
         For Update Nowait;
    Exception
      When Others Then
        Out_Result := '锁定提货预约汇总头失败,数据被锁定!汇总头:ID' || In_Reservation_Head_Id || v_Nl ||
                    Sqlerrm;
        Raise v_Base_Exception;
    End;
    
    --是否自动库存评审
    Begin
      Select Nvl(Pkg_Bd.f_Get_Parameter_Value('PLN_LG_TO_PLN_AUTO_INV_REVIEW',
                                              In_Entity_Id),
                 'N')
        Into v_Auto_Inv_Review
        From Dual;
    Exception
      When Others Then
        Out_Result := '获取是否自动库存评审失败!参数编码[PLN_LG_TO_PLN_AUTO_INV_REVIEW]' || v_Nl ||
                      Sqlerrm;
        Raise v_Base_Exception;
    End;
    
    Begin
      -- 查找周期
      Select *
        Into r_Period
        From t_Pln_Order_Period Op
       Where Op.Entity_Id = In_Entity_Id
         And Op.Period_Type = 'T+3周期'
         And Op.Period_Code = r_Reservation_Head.Reservation_Period_Code;
    Exception
      When Others Then
        Out_Result := '获取订单周期信息失败，周期编码：' || r_Reservation_Head.Reservation_Period_Code || v_Nl ||
                    Sqlerrm;
        Raise v_Base_Exception;
    End;
    
    v_Period_Id := r_Period.Period_Id;                                               
    -- 检查周期
    Pkg_Pln_Pub.p_Check_Period(v_Period_Id,
                               'T+3周期',
                               'Y',
                               'N',
                               'O',
                               Out_Result);
    If Out_Result <> v_Success Then
      Out_Result :=Out_Result||'主体ID:'|| In_Entity_Id;
      Raise v_Base_Exception;
    End If;
    
    -- 检查订单类型
    Begin
      Select *
        Into r_Order_Type
        From t_Pln_Order_Type Ty
       Where Ty.Entity_Id = In_Entity_Id
         And Ty.Order_Type_Id = In_Order_Type_Id
         And Trunc(Sysdate) Between Ty.Begin_Date And
             Nvl(Ty.End_Date, Trunc(Sysdate));
    Exception
      When No_Data_Found Then
        Out_Result := '订单类型已关闭!' || '单据类型ID:' || In_Order_Type_Id;
        Raise v_Base_Exception;
    End;

    --插入汇总条件数据
    v_Index := 0;
    For r_Pln_Para In (Select *
                          From t_Pln_Ord_Collect_Param Ocp
                         Where Ocp.Entity_Id = In_Entity_Id
                           And Ocp.Param_Type = 'RC_COLLECT_TYPE'
                         Order By Ocp.Seq_Num) Loop
      v_Index := v_Index + 1;
      If Upper(r_Pln_Para.Column_Code) = 'CONSIGNEE_ADDR_NAME' Then
        Begin
          v_Consignee_Addr := Pkg_Pln_Pub.f_Get_Rcordpara_Collect_Value(In_Entity_Id   => In_Entity_Id,
                                                                        In_Head_Id     => In_Reservation_Head_Id,
                                                                        In_Table_Alias => 'LOH',
                                                                        In_Column_Code => 'CONSIGNEE_ADDR_NAME');
        
        Exception
          When Others Then
            Out_Result := '查找T+3订单收货地址信息失败!汇总订单订单号:' ||
                          r_Reservation_Head.Reservation_Coll_Number || v_Nl ||
                          Sqlerrm;
            Raise v_Base_Exception;
        End;
      Elsif Upper(r_Pln_Para.Column_Code) = 'SALES_MAIN_TYPE' Then
        Begin
          v_Sales_Main_Type := Pkg_Pln_Pub.f_Get_Rcordpara_Collect_Value(In_Entity_Id   => In_Entity_Id,
                                                                         In_Head_Id     => In_Reservation_Head_Id,
                                                                         In_Table_Alias => 'LOH',
                                                                         In_Column_Code => 'SALES_MAIN_TYPE');
        Exception
          When Others Then
            Out_Result := '查找T+3订单营销大类信息失败!' || v_Nl || Sqlerrm;
            Raise v_Base_Exception;
        End;
      Elsif Upper(r_Pln_Para.Column_Code) = 'SALES_CENTER_NAME' Then
        Begin
          v_Sales_Center_Name := Pkg_Pln_Pub.f_Get_Rcordpara_Collect_Value(In_Entity_Id   => In_Entity_Id,
                                                                           In_Head_Id     => In_Reservation_Head_Id,
                                                                           In_Table_Alias => 'LOH',
                                                                           In_Column_Code => 'SALES_CENTER_NAME');
          Select Bsc.Sales_Center_Id, Bsc.Sales_Center_Code
            Into v_Sales_Center_Id, v_Sales_Center_Code
            From v_Bd_Sales_Center Bsc
           Where Bsc.Sales_Center_Name = v_Sales_Center_Name
             And Bsc.Entity_Id = In_Entity_Id;
        Exception
          When Others Then
            Out_Result := '查找营销中心信息失败!' || v_Nl || Sqlerrm;
            Raise v_Base_Exception;
        End;
      Elsif Upper(r_Pln_Para.Column_Code) = 'ACCOUNT_CODE' Then
        Begin
          v_Account_Code := Pkg_Pln_Pub.f_Get_Rcordpara_Collect_Value(In_Entity_Id   => In_Entity_Id,
                                                                      In_Head_Id     => In_Reservation_Head_Id,
                                                                      In_Table_Alias => 'LOH',
                                                                      In_Column_Code => 'ACCOUNT_CODE');
         
          Execute Immediate 'Select Aor.Relation_Id, Ca.Account_Id
                              From t_Customer_Acc_Org_Relation Aor,
                                   t_Customer_Account          Ca
                             Where Aor.Account_Id = Ca.Account_Id
                               And Ca.Active_Flag = ''Y''
                               And Ca.Entity_Id = :1
                               And Ca.Account_Code = :2'
          Into v_Acc_Relation_Id, v_Account_Id
          Using In_Entity_Id, v_Account_Code;
        Exception
          When Others Then
            Out_Result := '查找T+3订单营销大类信息失败!' || Sqlerrm;
            Raise v_Base_Exception;
        End;
        --根据账户信息查找营销中心、客户信息
        Begin
          Select Tco.Sales_Center_Id,
                 Uou.Code,
                 Uou.Name,
                 Tch.Customer_Id,
                 Tch.Customer_Code,
                 Tch.Customer_Name
            Into v_Sales_Center_Id,
                 v_Sales_Center_Code,
                 v_Sales_Center_Name,
                 v_Customer_Id,
                 v_Customer_Code,
                 v_Customer_Name
            From t_Customer_Acc_Org_Relation Aor,
                 t_Customer_Org              Tco,
                 t_Customer_Header           Tch,
                 Up_Org_Unit                 Uou
           Where Aor.Relation_Id = v_Acc_Relation_Id
             And Aor.Customer_Org_Id = Tco.Customer_Org_Id
             And Tco.Customer_Id = Tch.Customer_Id
             And Tco.Sales_Center_Id = Uou.Unit_Id
             --如果已经获取了中心ID，则中心ID加入查询条件
             And Tco.Sales_Center_Id = Nvl(v_Sales_Center_Id, Tco.Sales_Center_Id)
             And Tch.Active_Flag = 'Active'
             And Tco.Active_Flag = 'Active'
             And Tco.Entity_Id = In_Entity_Id;
        Exception
          When Others Then
            Out_Result := '获取营销中心信息失败！' || v_Nl ||
              '账户与中心、客户关系ID：' || To_Char(v_Acc_Relation_Id) || v_Nl || Sqlerrm;
            Raise v_Base_Exception;
        End;
      Elsif Upper(r_Pln_Para.Column_Code) = 'CARLOAD_MEET_NUM' Then
        Begin
          v_Carload_Meet_Num := Pkg_Pln_Pub.f_Get_Rcordpara_Collect_Value(In_Entity_Id   => In_Entity_Id,
                                                                          In_Head_Id     => In_Reservation_Head_Id,
                                                                          In_Table_Alias => 'LOH',
                                                                          In_Column_Code => 'CARLOAD_MEET_NUM');
        Exception
          When Others Then
            Out_Result := '查找T+3订单齐套号信息失败!' || v_Nl || Sqlerrm;
            Raise v_Base_Exception;
        End;
      Elsif Upper(r_Pln_Para.Column_Code) = 'ORDER_NUMBER' Then
        --add by lizhen 2017-03-22 如果增加了提货订单单号汇总时，则营销中心客户等取提货订单头数据
        Begin
          v_Lg_Order_Number := Pkg_Pln_Pub.f_Get_Rcordpara_Collect_Value(In_Entity_Id   => In_Entity_Id,
                                                                         In_Head_Id     => In_Reservation_Head_Id,
                                                                         In_Table_Alias => 'LOH',
                                                                         In_Column_Code => 'ORDER_NUMBER');
        Exception
          When Others Then
            Out_Result := '查找提货订单单号信息失败!' || v_Nl || Sqlerrm;
            Raise v_Base_Exception;
        End;
        Begin
          Select Loh.Sales_Center_Id,
                 Loh.Sales_Center_Code,
                 Loh.Sales_Center_Name,
                 Loh.Customer_Id,
                 Loh.Customer_Code,
                 Loh.Customer_Name,
                 Loh.Account_Id,
                 Loh.Account_Code,
                 Loh.Sales_Main_Type
            Into v_Sales_Center_Id,
                 v_Sales_Center_Code,
                 v_Sales_Center_Name,
                 v_Customer_Id,
                 v_Customer_Code,
                 v_Customer_Name,
                 v_Account_Id,
                 v_Account_Code,
                 v_Sales_Main_Type
            From t_Pln_Lg_Order_Head Loh
           Where Loh.Entity_Id = In_Entity_Id
             And Loh.Order_Number = v_Lg_Order_Number;
        Exception
          When Others Then
            Out_Result := '根据提货订单单号获取中心、客户、账户信息失败!' || v_Nl || Sqlerrm;
            Raise v_Base_Exception;
        End;
      End If;
    End Loop;
    
    
    If v_Sales_Center_Code Is Not Null And
       (v_Customer_Id Is Null Or v_Customer_Code Is Null) Then
      --查找营销中心
      Begin
        Select Tch.Customer_Id,
               Tch.Customer_Code,
               Tch.Customer_Name,
               Tca.Account_Id,
               Tca.Account_Code
          Into v_Customer_Id,
               v_Customer_Code,
               v_Customer_Name,
               v_Account_Id,
               v_Account_Code
          From Cims.t_Customer_Org              Tco,
               Cims.t_Customer_Header           Tch,
               Cims.t_Customer_Acc_Org_Relation Aor,
               Cims.t_Customer_Account          Tca,
               Cims.t_Pln_Reservation_Coll_Line Rcl
         Where Tco.Customer_Id = Tch.Customer_Id
           And Tch.Active_Flag = 'Active'
           And Tco.Active_Flag = 'Active'
           And Tco.Entity_Id = In_Entity_Id
           And Aor.Customer_Org_Id = Tco.Customer_Org_Id
           And Aor.Account_Id = Tca.Account_Id
           And Tco.Sales_Center_Code = v_Sales_Center_Code
           And Rcl.Reservation_Head_Id = In_Reservation_Head_Id
           And Rcl.Customer_Code = Tch.Customer_Code
           And Rcl.Sales_Center_Code = Tco.Sales_Center_Code
           And Rownum <= 1;
      Exception
        When Others Then
          Out_Result := '获取客户信息失败！' || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
      End;
    End If;
    If v_Sales_Center_Id Is Null Then
      Out_Result := '未找到订单类型对应的营销中心!';
      Raise v_Base_Exception;
    End If;
    
    --add by lizhen 2016-08-17
    v_Consignee_Id := 1;

    --生成计划订单
    Begin     
      v_Mrp_Org_Code := Pkg_Pln_Pub.f_Get_RcOrdPara_Collect_Value(In_Entity_Id   => In_Entity_Id,
                                                                  In_Head_Id     => In_Reservation_Head_Id,
                                                                  In_Table_Alias => 'PPA',
                                                                  In_Column_Code => 'MRP_ORG_CODE');   
      Select Ppa.Producing_Area_Id
        Into v_Producing_Area_Id
        From t_Pln_Producing_Area Ppa
       Where Ppa.Mrp_Org_Code = v_Mrp_Org_Code 
         And Ppa.Entity_Id = In_Entity_Id;
    Exception
      When No_Data_Found Then
        v_Producing_Area_Id := Null;
      When Others Then
        Out_Result := '获取产地信息失败！' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;
    If v_Producing_Area_Id Is Not Null Then
      Begin
        Select *
          Into r_Producing_Area
          From t_Pln_Producing_Area Pa
         Where Pa.Producing_Area_Id = v_Producing_Area_Id
           And Pa.Entity_Id = In_Entity_Id;
      Exception
        When Others Then
          Out_Result := '获取产地信息失败！' || v_Nl || '产地id:' ||
                      To_Char(v_Producing_Area_Id);
          Raise v_Base_Exception;
      End;

      --获取订单号
      Pkg_Pln_Pub.p_Create_Order_Number('plnMakeOrder',
                                        v_Period_Id,
                                        v_Sales_Center_Id,
                                        in_Entity_Id,
                                        v_Order_Number);
      If v_Order_Number Is Null Then
        Out_Result := '获取订单单号失败。' || v_Nl ||
          '营销中心ID：' || To_Char(v_Sales_Center_Id);
        Raise v_Base_Exception;
      End If;

      Select s_Pln_Order_Head.Nextval Into v_Order_Head_Id From Dual;
      --插入订单头数据
      Insert Into t_Pln_Order_Head
        (Entity_Id,
         Order_Head_Id,   --订单头ID
         Order_Number,   --订单单号
         Order_Type_Id,  --单据类型ID
         Order_Type_Code, --单据类型编码
         Order_Type_Name,  --单据类型名称
         Period_Id,        --周期ID
         Period_Code,      --周期编码
         Form_State,       --订单头状态
         Sales_Center_Id,  --营销中心ID
         Sales_Center_Code, --营销中心编码
         Sales_Center_Name, --营销中心名称
         Customer_Id,       --客户ID
         Customer_Code,     --客户编码
         Customer_Name,     --客户名称
         Account_Id,        --账户ID
         Account_Code,
         Invoice_Customer_Id, --开票单位ID
         Invoice_Customer_Code, --开票单位编码
         Invoice_Customer_Name, --开票单位名称
         Sys_Source,            --来源系统
         Source_type,          --来源类型
         Source_Order_Head_Id, --来源头ID
         Source_Order_Number, --来源订单号为提货汇总单号
         Consignee_Id,        --收货地址ID
         Consignee_Addr,      --收货地址
         Sales_Main_Type,   --营销大类
         Producing_Area_Id,  --产地ID
         Producing_Area_Code, --产地编码
         Producing_Area_Name, --产地名称
         Is_Aps_Need,         --引APS标志
         Out_Line_Flag,      --下线直发标志
         Neat_Set_Rate,      --齐套率
         Carload_Meet_Num,   --提货齐套号
         book_receipt_date, --预约收货日期
         Created_By,
         Creation_Date,
         Last_Updated_By,
         Last_Update_Date)
      Values
        (In_Entity_Id, --Entity_Id, 主体ID
         v_Order_Head_Id, --Order_Head_Id,   --订单头ID
         v_Order_Number, --Order_Number,   --订单单号
         r_Order_Type.Order_Type_Id, --Order_Type_Id,  --单据类型ID
         r_Order_Type.Order_Type_Code, --Order_Type_Code, --单据类型编码
         r_Order_Type.Order_Type_Name, --Order_Type_Name,  --单据类型名称
         r_Period.Period_Id, --Period_Id,        --周期ID
         r_Period.Period_Code, --Period_Code,      --周期编码
         '19', --Form_State,       --订单头状态
         v_Sales_Center_Id,  --Sales_Center_Id,  --营销中心ID
         v_Sales_Center_Code, --Sales_Center_Code, --营销中心编码
         v_Sales_Center_Name, --Sales_Center_Name, --营销中心名称
         v_Customer_Id, --Customer_Id,       --客户ID
         v_Customer_Code, --Customer_Code,     --客户编码
         v_Customer_Name, --Customer_Name,     --客户名称
         v_Account_Id, --Account_Id,        --账户ID
         v_Account_Code,                    --账户编码 2016-08-17
         v_Customer_Id, --Invoice_Customer_Id, --开票单位ID
         v_Customer_Code, --Invoice_Customer_Code, --开票单位编码
         v_Customer_Name, --Invoice_Customer_Name, --开票单位名称
         'CIMS', --Sys_Source,            --来源系统
         '提货订单', --Source_type,          --来源类型
         r_Reservation_Head.Reservation_Head_Id, --Source_Order_Head_Id, --来源头ID
         r_Reservation_Head.Reservation_Coll_Number, --Source_Order_Number, --来源订单号为提货汇总单号
         v_Consignee_Id, --Consignee_Id,  --收货地址ID
         v_Consignee_Addr, --Consignee_Addr,      --收货地址
         v_Sales_Main_Type, --Sales_Main_Type,   --营销大类
         r_Producing_Area.Producing_Area_Id, --Producing_Area_Id,  --产地ID
         r_Producing_Area.Producing_Area_Code, --Producing_Area_Code, --产地编码
         r_Producing_Area.Producing_Area_Name, --Producing_Area_Name, --产地名称
         'N', --Is_Aps_Need,         --引APS标志
         'N', --Out_Line_Flag,      --下线直发标志
         0, --Neat_Set_Rate,      --齐套率
         v_Carload_Meet_Num, --Carload_Meet_Num --齐套号
         r_Reservation_Head.Reservation_Ship_Date, --预约收货日期
         In_User_Code, --Created_By,
         Sysdate, --Creation_Date,
         In_User_Code, --Last_Updated_By,
         Sysdate --Last_Update_Date
         );

      Begin
        --插入计划订单行表
        Insert Into t_Pln_Order_Line
          (Entity_Id,
           Order_Line_Id,
           Order_Head_Id,
           Can_Supply_Date,
           Begin_Supply_Date,
           End_Supply_Date,
           Complete_Date,
           Source_Head_Id,
           Source_Head_Code,
           Source_Type_Name,
           Created_By,
           Creation_Date,
           Last_Updated_By,
           Last_Update_Date,
           Remark,
           Aps_Flag,
           Item_Id,
           Item_Code,
           Item_Desc,
           Item_Uom,
           Item_Price,
           Apply_Qty,
           Can_Produce_Qty,
           Producing_Area_Id,
           Producing_Area_Code,
           Producing_Area_Name,
           Expect_Date, --add by lizhen 2016-08-17 期望到货日期
           Is_Line_Walkthrough,
           Is_Order_Walkthrough,
           Is_Fixed,
           Aps_Promise_Time,
           Intf_Type,
           Check_Qty,
           Supply_Qty)
          Select In_Entity_Id,
                 s_Pln_Order_Line.Nextval,
                 v_Order_Head_Id,
                 r_Period.End_Date Can_Supply_Date,
                 r_Period.Begin_Date Begin_Supply_Date,
                 r_Period.End_Date End_Supply_Date,
                 r_Period.End_Date Complete_Date,
                 r_Reservation_Head.Reservation_Head_Id Source_Head_Id,
                 r_Reservation_Head.Reservation_Coll_Number Source_Head_Code,
                 '提货订单' Source_Type_Name,
                 In_User_Code Created_By,
                 Sysdate Creation_Date,
                 In_User_Code Last_Updated_By,
                 Sysdate Last_Update_Date,
                 Null Remark,
                 'N' Aps_Flag,
                 Lg.*,
                 Null, --Intf_Type
                 0 Check_Qty,
                 0 Supply_Qty
            From (Select Lol.Item_Id,
                         Tbi.Item_Code,
                         Max(Tbi.Item_Name) Item_Name,
                         Max(Lol.Default_Unit) Default_Unit,
                         Max(Rcl.Item_Price),
                         Sum(Rcl.To_Plnorder_Qty) Apply_Qty,
                         Sum(Rcl.To_Plnorder_Qty) Can_Produce_Qty,
                         Lol.Producing_Area_Id,
                         Lol.Producing_Area_Code,
                         Max(Lol.Producing_Area_Name) Producing_Area_Name,
                         Min(Loh.Consignment_Date) Expect_Date,
                         Null Is_Line_Walkthrough,
                         Null Is_Order_Walkthrough,
                         Null Is_Fixed,
                         Null Walkthrough_Rec_Date
                    From t_Pln_Reservation_Coll_Line Rcl,
                         t_Pln_Lg_Order_Line   Lol,
                         t_Bd_Item             Tbi,
                         t_Pln_Lg_Order_Head   Loh,
                         t_Pln_Producing_Area  Ppa
                   Where Rcl.Order_Line_Id = Lol.Order_Line_Id
                     And Rcl.Order_Head_Id = Lol.Order_Head_Id
                     And Rcl.Order_Head_Id = Loh.Order_Head_Id
                     And Rcl.Entity_Id = In_Entity_Id
                     And Rcl.Producing_Area_Id =r_Producing_Area.Producing_Area_Id --add 2015-8-29
                     And Rcl.Reservation_Head_Id = In_Reservation_Head_Id
                     And Tbi.Item_Id = Lol.Item_Id
                     And Tbi.Entity_Id = Lol.Entity_Id
                     And Ppa.Producing_Area_Id = Lol.Producing_Area_Id
                     And Ppa.Entity_Id = Lol.Entity_Id
                   Group By Lol.Item_Id,
                            Tbi.Item_Code,
                            Lol.Producing_Area_Id,
                            Lol.Producing_Area_Code) Lg;
      Exception
        When Others Then
          Out_Result := '插入T+3订单行表失败！' || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
      End;
      --插入提货订单与计划订单关系表
      Insert Into t_Pln_Lg_Relation
        (Entity_Id,
         Relation_Id,
         Order_Line_Id,
         Order_Head_Id,
         Lg_Order_Line_Id,
         Lg_Order_Head_Id,
         Creation_Date,
         Created_By,
         Last_Update_Date,
         Last_Updated_By)
        Select l.Entity_Id,
               Seq_Pln_Lg_Relation.Nextval Relation_Id,
               l.Order_Line_Id,
               l.Order_Head_Id,
               Cl.Order_Line_Id,
               Cl.Order_Head_Id,
               Sysdate                     Creation_Date,
               In_User_Code                 Created_By,
               Sysdate                     Last_Update_Date,
               In_User_Code                 Last_Updated_By
          From t_Pln_Order_Line      l,
               t_Pln_Reservation_Coll_Line Cl,
               t_pln_reservation_coll_head Ch
         Where l.Order_Head_Id = v_Order_Head_Id
           And Ch.Reservation_Head_Id = In_Reservation_Head_Id
           And Ch.Reservation_Head_Id = Cl.Reservation_Head_Id
           And Cl.Entity_Id = l.Entity_Id
           And l.Producing_Area_Id = r_Producing_Area.Producing_Area_Id
           And l.Item_Id = Cl.Item_Id
           And l.Producing_Area_Id = Cl.Producing_Area_Id
           And Not Exists
         (Select 0
                  From t_Pln_Lg_Relation r
                 Where r.Lg_Order_Line_Id = Cl.Order_Line_Id)
           And Cl.Entity_Id = In_Entity_Id;
      --add by ex_zhangcc 2016-1-12
      Select Count(0)
        Into v_Count_Line
        From t_Pln_Order_Line l
       Where l.Order_Head_Id = v_Order_Head_Id;
      If v_count_line=0  Then
        Delete t_pln_order_head Where order_head_id=v_Order_Head_Id;
      Else
        v_Curr_State := '19';
        v_Curr_Action := '送审';
        v_Can_Option_Flag := 'N';
        Loop
          --'获取当单据据类型的下一单据状态';
          Pkg_Pln_Pub.p_Get_Order_Next_Status(p_Order_Type_Id    => r_Order_Type.Order_Type_Id,
                                              p_Curr_State       => v_Curr_State,
                                              p_Curr_Action      => v_Curr_Action,
                                              p_Can_Option_Flag  => v_Can_Option_Flag,
                                              p_Next_Excute_Step => v_Next_Excute_Step,
                                              p_Nextauto_Excute  => v_Nextauto_Excute,
                                              p_Next_State       => v_Next_State,
                                              p_Next_Action      => v_Next_Action,
                                              p_Result           => Out_Result);
          If Out_Result <> v_Success Then
            Out_Result := '获取订单下一状态失败！当前订单状态：' || v_Curr_State || v_Nl ||
                      Out_Result;
            Raise v_Base_Exception;
          End If;
          Pkg_Pln_Order.p_Order_Operate(v_Order_Head_Id,
                                        r_Order_Type.Order_Type_Id,
                                        v_Curr_Action,
                                        In_User_Code,
                                        Out_Result);
                                        
          If Out_Result <> v_Success Then
            Raise v_Base_Exception;
          End If;                              
          --非自动执行则退出循环
          --订单为排产状态后退出循环
          If v_Next_State = '32' Then
            Pkg_Pln_Intf.P_CREATE_INTF_WEEK_ORDER(P_HEAD_ID       => v_Order_Head_Id,
                                                  P_ORDER_TYPE_ID => r_Order_Type.Order_Type_Id,
                                                  P_USER_CODE     => In_User_Code,
                                                  P_RESULT        => Out_Result);
            If Out_Result <> v_Success Then
              Raise v_Base_Exception;
            End If;
            Exit;
          End If;
          v_Curr_State  := v_Next_State;
          v_Curr_Action := v_Next_Action;
          --'获取当单据据类型的下一单据状态';
          Pkg_Pln_Pub.p_Get_Order_Next_Status(p_Order_Type_Id    => r_Order_Type.Order_Type_Id,
                                              p_Curr_State       => v_Curr_State,
                                              p_Curr_Action      => v_Curr_Action,
                                              p_Can_Option_Flag  => v_Can_Option_Flag,
                                              p_Next_Excute_Step => v_Next_Excute_Step,
                                              p_Nextauto_Excute  => v_Nextauto_Excute,
                                              p_Next_State       => v_Next_State,
                                              p_Next_Action      => v_Next_Action,
                                              p_Result           => Out_Result);
          If Out_Result <> v_Success Then
            Out_Result := '获取订单下一状态失败！当前订单状态：' || v_Curr_State || v_Nl ||
                      Out_Result;
            Raise v_Base_Exception;
          End If;
        End Loop;
      End If;
    End If;

    --更新提货订单行表已汇总状态
    Update t_Pln_Lg_Order_Line Ol
       Set Ol.Make_Order_Line_Flag    = 'Y',
           Ol.Collect_Order_Line_Flag = 'Y',
           Ol.Last_Updated_By         = In_User_Code,
           Ol.Last_Update_Date        = Sysdate,
           Ol.To_Pln_Qty             =
           (Select Tl.To_Plnorder_Qty
              From t_Pln_Reservation_Coll_Line Tl
             Where Tl.Order_Line_Id = Ol.Order_Line_Id
               And Tl.Reservation_Head_Id = In_Reservation_Head_Id)
     Where Ol.Order_Line_Id In
           (Select Cl.Order_Line_Id
              From t_Pln_Reservation_Coll_Line Cl
             Where Cl.Reservation_Head_Id = In_Reservation_Head_Id);
    
    --更新提货订单产地分解评审字段
    Update t_Pln_Lg_Order_Line Ol
       Set Ol.Pln_Chk_Qty        = Ol.To_Pln_Qty,
           Ol.Pln_Chk_Adjust_Qty = Ol.To_Pln_Qty,
           Ol.Pln_Chk_Pro_Area   = Ol.Producing_Area_Name
     Where Ol.Order_Line_Id In
           (Select Cl.Order_Line_Id
              From t_Pln_Reservation_Coll_Line Cl
             Where Cl.Reservation_Head_Id = In_Reservation_Head_Id);
             
    --插入预约收货时间 章娟 2018-3-29
    Update t_Pln_Lg_Order_Line Ol
       Set Ol.BOOK_RECEIPT_DATE =
           (select max(t.RESERVATION_SHIP_DATE)
              from t_pln_reservation_coll_head t
             where t.Reservation_Head_Id = In_Reservation_Head_Id)
     Where Ol.Order_Line_Id In
           (Select Cl.Order_Line_Id
              From t_Pln_Reservation_Coll_Line Cl
             Where Cl.Reservation_Head_Id = In_Reservation_Head_Id);
    --更新结转单号到汇总单头
    Update t_Pln_Reservation_Coll_Head Rch
       Set Rch.To_Plnorder_Number = Decode(Rch.To_Plnorder_Number,
                                           Null,
                                           v_Order_Number,
                                           Rch.To_Plnorder_Number || ', ' ||
                                           v_Order_Number)
     Where Rch.Reservation_Head_Id = In_Reservation_Head_Id;
  Exception
    When v_Base_Exception Then
      Out_Result := Out_Result;
      Rollback;
    When Others Then
      Out_Result := Out_Result || v_Nl || Sqlerrm;
      Rollback;
  End;
  
  -----------------------------------------------------------------------------
  -- AUTHOR  : Nicro.Li
  -- CREATED : 2017-11-03
  -- PURPOSE : 提货订单预约汇总数据转T+3订单,多主体处理
  -----------------------------------------------------------------------------
  Procedure p_LgRc_To_Plnorder_All(In_Reservation_Head_Id In Number, --提货汇总订单头ID
                                   In_Order_Type_Id       In Number, --计划订单类型ID
                                   In_User_Code           In Varchar2, --用户编码
                                   Out_Result             In Out Varchar2 --返回结果：SUCCESS——>过程执行完成；FAILURE——>中途抛错
                                   ) Is
    r_Reservation_Head t_pln_reservation_coll_head%Rowtype;
    v_Order_Type_Id     Number;
    v_Coll_Volume       Number;
    v_Count             Number;
  Begin
    --查找提货汇总订单头
    Out_Result := v_Success;
    Begin
      Select *
        Into r_Reservation_Head
        From t_pln_reservation_coll_head Rch
       Where Rch.Reservation_Head_Id = In_Reservation_Head_Id
         --And Tch.Walkthrough_Confirm_Flag = 'Y'
         And Rch.To_Plnorder_Flag = 'N'
         For Update Nowait;
    Exception
      When Others Then
        Out_Result := '锁定提货预约汇总头失败,数据被锁定!汇总头:ID' || In_Reservation_Head_Id || v_Nl ||
                    Sqlerrm;
        Raise v_Base_Exception;
    End;
    
    If r_Reservation_Head.Reservation_Flag != 'S' Then
      Out_Result := '预约汇总APS预约未完成，不允许结转T+3订单！';
      Raise v_Base_Exception;
    End If;
    
    Begin
      Select To_Number(Vuc.Code_Name)
        Into v_Coll_Volume
        From v_Up_Codelist Vuc
       Where Vuc.Codetype = 'PLN_RESERVATION_COLL_VOLUME'
         And Vuc.Enabled = '0'
         And Vuc.Code_Value =
             Pkg_Pln_Pub.f_Get_Rcordpara_Collect_Value(In_Entity_Id   => r_Reservation_Head.Entity_Id,
                                                       In_Head_Id     => In_Reservation_Head_Id,
                                                       In_Table_Alias => 'PPA',
                                                       In_Column_Code => 'MRP_ORG_CODE');
    Exception
      When Others Then 
        Out_Result := '获取产地最小允许发运体积失败，请检查是否配置了快码PLN_RESERVATION_COLL_VOLUME值！' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;                                                  
    End;
    
    If Nvl(v_Coll_Volume, 0) > Nvl(r_Reservation_Head.Coll_Volume, 0) Then
      Out_Result := '体积未达到产地最小发运体积需求，不允许进行T+3订单结转。' || v_Nl ||
				'该汇总行最小要求发运体积为【' || v_Coll_Volume || '】';
      Raise v_Base_Exception;
    End If;
    
    Select Count(*)
      Into v_Count
      From t_Pln_Reservation_Coll_Line Rcl
     Where Rcl.Reservation_Head_Id = In_Reservation_Head_Id
       And Rcl.To_Plnorder_Qty > Nvl(Rcl.Aps_Reservation_Qty, 0);
    
    If Nvl(v_Count, 0) > 0 Then
      Out_Result := '预约汇总行表存在APS预约不满足的产品行，不允许进行T+3订单结转。';
      Raise v_Base_Exception;
    End If;
    
    For Row_Collect_Info In (Select Cl.Entity_Id --主体
                               From t_Pln_Reservation_Coll_Head Ch,
                                    t_pln_reservation_coll_line Cl
                              Where Ch.Reservation_Head_Id = Cl.Reservation_Head_Id
                                And Ch.Reservation_Head_Id = In_Reservation_Head_Id --传入汇总头ID
                              Group By Cl.Entity_Id) Loop
      --add by lizhen 增加订单单据类型参数传入，为空时取系统参数黙认设置
      If In_Order_Type_Id Is Null Then
        Begin
          Select Vuc.Code_Value
            Into v_Order_Type_Id
            From v_Up_Codelist Vuc
           Where Vuc.Codetype = 'PLN_RESERVATION_TO_PLNORDER'
             And Vuc.Enabled = '0'
             And Vuc.Code_Name = Row_Collect_Info.Entity_Id;
        Exception
          When Others Then
            Out_Result := '快码“PLN_RESERVATION_TO_PLNORDER”没有配置T+3订单ID';
            Raise v_Base_Exception;
        End;
      Else
        --add by lizhen 2017-08-30由于洗衣机多主体，所以再单据类型名称再查询一次单据
        --必须保证计划订单单据类型名称无重复
        Begin
          Select Pot.Order_Type_Id
            Into v_Order_Type_Id
            From t_Pln_Order_Type Pot
           Where Pot.Order_Type_Name =
                 (Select Ot.Order_Type_Name
                    From t_Pln_Order_Type Ot
                   Where Ot.Order_Type_Id = In_Order_Type_Id)
             And Pot.Source_Order_Type_Id = 0
             And Pot.Entity_Id = Row_Collect_Info.Entity_Id;
        Exception
          When Others Then
            Out_Result := '检查单据类型信息是否正确，单据类型ID:' || In_Order_Type_Id;
            Raise v_Base_Exception;
        End;
      End If;
        
      --生成计划订单
      p_LgRc_To_PlnOrder_Single(Row_Collect_Info.Entity_Id,
                                v_Order_Type_Id,
                                In_Reservation_Head_Id,
                                In_User_Code,
                                Out_Result);
      If Out_Result <> v_Success Then
        Raise v_Base_Exception;
      End If;
    End Loop;
      
    --更新转计划标志
    Update t_pln_reservation_coll_head Ch
       Set Ch.To_Plnorder_Flag = 'Y',
           Ch.Last_Updated_By  = In_User_Code,
           Ch.Last_Update_Date = Sysdate,
           Ch.Version          = Nvl(Ch.Version, 0) + 1
     Where Ch.Reservation_Head_Id = In_Reservation_Head_Id;
  Exception
    When v_Base_Exception Then
      Out_Result := '提货订单转T+3订单失败，汇总单号:' || r_Reservation_Head.Reservation_Coll_Number || v_Nl ||
                  Out_Result;
      Rollback;
    When Others Then
      Out_Result := '提货订单汇总单转T+3失败!' || v_Nl || Substr(Sqlerrm, 1, 256) || v_Nl ||
                  Substr(Dbms_Utility.Format_Error_Backtrace, 1, 100);
      Rollback;
  End;
  
  -----------------------------------------------------------------------------
  -- AUTHOR  : hejy3
  -- CREATED : 2018-9-21
  -- PURPOSE : 提货订单预约汇总基数拆单处理 SINGLE
  -----------------------------------------------------------------------------
  PROCEDURE P_LG_COLLECT_SPLIT(IN_ENTITY_ID          IN NUMBER, --主体ID
                               IN_PERIOD_CODE        IN VARCHAR2, --周期
                               IN_COLLECT_MODE       IN VARCHAR2, --汇总模式
                               IN_USER_CODE          IN VARCHAR2, --操作用户
                               OUT_RESULT            OUT VARCHAR2 --返回结果：SUCCESS,成功；
    )
  IS
    V_COLLECT_MAX_QTY NUMBER;
    V_CURR_COLLECT_MAX_QTY NUMBER;
    R_LG_COLLECT_HEAD T_PLN_LG_COLLECT_HEAD%ROWTYPE;
    V_SUM_QTY NUMBER;
    V_NEW_COLLECT_HEAD_ID NUMBER;
    V_ROW_COUNT NUMBER;
    V_ITEM_CODE VARCHAR2(100);
  BEGIN
    OUT_RESULT := v_Success;
    
    --获取汇总基数
    V_COLLECT_MAX_QTY := TO_NUMBER(NVL(PKG_BD.F_GET_PARAMETER_VALUE('PLN_LG_COLLECT_MAX_QTY', IN_ENTITY_ID), '0'));
    
    --为0不处理，直接返回
    IF V_COLLECT_MAX_QTY = 0 AND IN_COLLECT_MODE NOT IN ('SINGLE') THEN
      RETURN;
    END IF;
    
    IF IN_COLLECT_MODE IN ('NORMAL', 'SINGLE') THEN --汇总单一单一个SKU，按SKU控制基数
      FOR R_CH IN (
        SELECT H.COLLECT_HEAD_ID, SUM(L.TO_PLNORDER_QTY) SUM_TO_PLN_QTY
          FROM T_PLN_LG_COLLECT_HEAD H,
               T_PLN_LG_COLLECT_LINE L
         WHERE H.COLLECT_HEAD_ID = L.COLLECT_HEAD_ID
           AND H.COLLECT_DATE = TRUNC(SYSDATE)
           AND H.PRE_FIELD_20 IN (SELECT O.DEAL_BATCH FROM t_pln_wait_collect_order O)
           AND H.PERIOD_CODE = IN_PERIOD_CODE
           AND NVL(H.TO_PLNORDER_FLAG, 'N') = 'N'
           AND H.ENTITY_ID IN (select e.entity_id from up_codelist u, up_codelist_entity e
                                where u.id = e.codelist_id
                                  and u.codetype = 'plnMergeEntity'
                                  and u.code_value = to_char(IN_ENTITY_ID))
         GROUP BY H.COLLECT_HEAD_ID
         HAVING /*SUM(L.TO_PLNORDER_QTY) > V_COLLECT_MAX_QTY AND*/ COUNT(1) > 1 --取合并数量超过基数的汇总数据
         ) 
      LOOP
        V_CURR_COLLECT_MAX_QTY := V_COLLECT_MAX_QTY;
        IF IN_COLLECT_MODE = 'SINGLE' THEN
          --获取产品编码
          V_ITEM_CODE := Pkg_Pln_Pub.f_Get_T3ordpara_Collect_Value(p_Entity_Id          => IN_ENTITY_ID,
                                                                  p_Lg_Collect_Head_Id => R_CH.Collect_Head_Id,
                                                                  p_Table_Alias        => 'LOL',
                                                                  p_Column_Code        => 'ITEM_CODE');
          --产品编码不为空时按产品检查汇总基数
          IF V_ITEM_CODE IS NOT NULL THEN
            BEGIN
              SELECT P.COLLECT_MAX_QTY
                INTO V_CURR_COLLECT_MAX_QTY
                FROM T_PLN_ITEM_PROPERTY P
               WHERE P.ENTITY_ID = IN_ENTITY_ID
                 AND P.ITEM_CODE = V_ITEM_CODE;
            EXCEPTION
              WHEN OTHERS THEN
                V_CURR_COLLECT_MAX_QTY := V_COLLECT_MAX_QTY;
            END;
          END IF;
          
          IF V_CURR_COLLECT_MAX_QTY IS NULL THEN
            V_CURR_COLLECT_MAX_QTY := V_COLLECT_MAX_QTY;
          END IF;
        END IF;
        
        --汇总数量超出基数才处理
        IF R_CH.SUM_TO_PLN_QTY > V_CURR_COLLECT_MAX_QTY AND V_CURR_COLLECT_MAX_QTY <> 0 THEN
        --LOOP
          V_SUM_QTY := 0;
          V_NEW_COLLECT_HEAD_ID := 0;
          V_ROW_COUNT := 0;
          FOR R_CL IN (
            SELECT L.*
              FROM T_PLN_LG_COLLECT_LINE L
             WHERE L.COLLECT_HEAD_ID = R_CH.COLLECT_HEAD_ID
             ORDER BY L.COLLECT_LINE_ID
            )
          LOOP
            V_ROW_COUNT := V_ROW_COUNT + 1;
            IF V_NEW_COLLECT_HEAD_ID = 0 THEN
              SELECT S_PLN_LG_COLLECT_HEAD.NEXTVAL INTO V_NEW_COLLECT_HEAD_ID FROM DUAL;
            END IF;
            V_SUM_QTY := V_SUM_QTY + R_CL.TO_PLNORDER_QTY;
            
            IF V_SUM_QTY >= V_CURR_COLLECT_MAX_QTY THEN
              --把汇总行调整到新汇总头
              IF V_SUM_QTY = V_CURR_COLLECT_MAX_QTY OR V_ROW_COUNT = 1 THEN
                UPDATE T_PLN_LG_COLLECT_LINE L
                   SET L.COLLECT_HEAD_ID = V_NEW_COLLECT_HEAD_ID,
                       L.LAST_UPDATED_BY = IN_USER_CODE,
                       L.LAST_UPDATE_DATE = SYSDATE
                 WHERE L.COLLECT_LINE_ID = R_CL.COLLECT_LINE_ID;
              END IF;
              
                --插入新的汇总头
                SELECT H.*
                  INTO R_LG_COLLECT_HEAD
                  FROM T_PLN_LG_COLLECT_HEAD H
                 WHERE H.COLLECT_HEAD_ID = R_CH.COLLECT_HEAD_ID;
                  
                R_LG_COLLECT_HEAD.COLLECT_HEAD_ID := V_NEW_COLLECT_HEAD_ID;
                R_LG_COLLECT_HEAD.CREATED_BY := IN_USER_CODE;
                R_LG_COLLECT_HEAD.CREATION_DATE := SYSDATE;
                R_LG_COLLECT_HEAD.LAST_UPDATED_BY := IN_USER_CODE;
                R_LG_COLLECT_HEAD.LAST_UPDATE_DATE := SYSDATE;
                INSERT INTO T_PLN_LG_COLLECT_HEAD VALUES R_LG_COLLECT_HEAD;
              
              IF V_SUM_QTY = V_CURR_COLLECT_MAX_QTY OR 
                V_SUM_QTY > V_CURR_COLLECT_MAX_QTY AND V_ROW_COUNT = 1 THEN
                --EXIT; --跳出循环
                V_NEW_COLLECT_HEAD_ID := 0;
                V_ROW_COUNT := 0;
                V_SUM_QTY := 0;
              ELSIF V_SUM_QTY > V_CURR_COLLECT_MAX_QTY AND V_ROW_COUNT > 1 THEN
                SELECT S_PLN_LG_COLLECT_HEAD.NEXTVAL INTO V_NEW_COLLECT_HEAD_ID FROM DUAL;
                UPDATE T_PLN_LG_COLLECT_LINE L
                   SET L.COLLECT_HEAD_ID = V_NEW_COLLECT_HEAD_ID,
                       L.LAST_UPDATED_BY = IN_USER_CODE,
                       L.LAST_UPDATE_DATE = SYSDATE
                 WHERE L.COLLECT_LINE_ID = R_CL.COLLECT_LINE_ID;
                V_SUM_QTY := R_CL.TO_PLNORDER_QTY;
                V_ROW_COUNT := 1;
              END IF;
            ELSE
              --把汇总行调整到新汇总头
              UPDATE T_PLN_LG_COLLECT_LINE L
                 SET L.COLLECT_HEAD_ID = V_NEW_COLLECT_HEAD_ID,
                     L.LAST_UPDATED_BY = IN_USER_CODE,
                     L.LAST_UPDATE_DATE = SYSDATE
               WHERE L.COLLECT_LINE_ID = R_CL.COLLECT_LINE_ID;
            END IF;
          END LOOP;
          
          --1、V_ROW_COUNT > 0 AND V_NEW_COLLECT_HEAD_ID > 0 表示还有汇总行未生成汇总头数据
          --2、V_ROW_COUNT = 0 AND V_NEW_COLLECT_HEAD_ID = 0 表示循环全部处理完，没有待处理行
          IF (V_ROW_COUNT > 0 AND V_NEW_COLLECT_HEAD_ID > 0) OR
            (V_ROW_COUNT = 0 AND V_NEW_COLLECT_HEAD_ID = 0) THEN
            IF V_ROW_COUNT > 0 AND V_NEW_COLLECT_HEAD_ID > 0 THEN
              --插入新的汇总头
              SELECT H.*
                INTO R_LG_COLLECT_HEAD
                FROM T_PLN_LG_COLLECT_HEAD H
               WHERE H.COLLECT_HEAD_ID = R_CH.COLLECT_HEAD_ID;
                  
              R_LG_COLLECT_HEAD.COLLECT_HEAD_ID := V_NEW_COLLECT_HEAD_ID;
              R_LG_COLLECT_HEAD.CREATED_BY := IN_USER_CODE;
              R_LG_COLLECT_HEAD.CREATION_DATE := SYSDATE;
              R_LG_COLLECT_HEAD.LAST_UPDATED_BY := IN_USER_CODE;
              R_LG_COLLECT_HEAD.LAST_UPDATE_DATE := SYSDATE;
              INSERT INTO T_PLN_LG_COLLECT_HEAD VALUES R_LG_COLLECT_HEAD;
              V_NEW_COLLECT_HEAD_ID := 0;
            END IF;
            DELETE FROM T_PLN_LG_COLLECT_HEAD H WHERE H.COLLECT_HEAD_ID = R_CH.COLLECT_HEAD_ID;
            --EXIT; --跳出循环
          END IF;
        --END LOOP;
        END IF;
      END LOOP;
    ELSIF IN_COLLECT_MODE = 'MULTIPLE' THEN --汇总单一单多个SKU，按整单控制基数
      FOR R_CH IN (
        SELECT H.COLLECT_HEAD_ID, SUM(L.TO_PLNORDER_QTY) SUM_TO_PLN_QTY
          FROM T_PLN_LG_COLLECT_HEAD H,
               T_PLN_LG_COLLECT_LINE L
         WHERE H.COLLECT_HEAD_ID = L.COLLECT_HEAD_ID
           AND H.COLLECT_DATE = TRUNC(SYSDATE)
           AND H.PRE_FIELD_20 IN (SELECT O.DEAL_BATCH FROM t_pln_wait_collect_order O)
           AND H.PERIOD_CODE = IN_PERIOD_CODE
           AND NVL(H.TO_PLNORDER_FLAG, 'N') = 'N'
           AND H.ENTITY_ID IN (select e.entity_id from up_codelist u, up_codelist_entity e
                                where u.id = e.codelist_id
                                  and u.codetype = 'plnMergeEntity'
                                  and u.code_value = to_char(IN_ENTITY_ID))
         GROUP BY H.COLLECT_HEAD_ID
         HAVING SUM(L.TO_PLNORDER_QTY) > V_COLLECT_MAX_QTY AND COUNT(DISTINCT L.ORDER_HEAD_ID) > 1 --取合并数量超过基数的汇总数据
         )
      LOOP
        --LOOP
          V_SUM_QTY := 0;
          V_NEW_COLLECT_HEAD_ID := 0;
          V_ROW_COUNT := 0;
          FOR R_CL IN (
            SELECT OH.ORDER_HEAD_ID, OH.TO_CHECKUP_DATE, SUM(L.TO_PLNORDER_QTY) SUM_TO_PLNORDER_QTY
              FROM T_PLN_LG_COLLECT_LINE L,
                   T_PLN_LG_ORDER_HEAD OH
             WHERE OH.ORDER_HEAD_ID = L.ORDER_HEAD_ID
               AND L.COLLECT_HEAD_ID = R_CH.COLLECT_HEAD_ID
             GROUP BY OH.ORDER_HEAD_ID, OH.TO_CHECKUP_DATE
             ORDER BY OH.TO_CHECKUP_DATE, OH.ORDER_HEAD_ID, SUM(L.TO_PLNORDER_QTY) DESC
            )
          LOOP
            V_ROW_COUNT := V_ROW_COUNT + 1;
            IF V_NEW_COLLECT_HEAD_ID = 0 THEN
              SELECT S_PLN_LG_COLLECT_HEAD.NEXTVAL INTO V_NEW_COLLECT_HEAD_ID FROM DUAL;
            END IF;
            V_SUM_QTY := V_SUM_QTY + R_CL.SUM_TO_PLNORDER_QTY;
            
            IF V_SUM_QTY >= V_COLLECT_MAX_QTY THEN
              --把汇总行调整到新汇总头
              IF V_SUM_QTY = V_COLLECT_MAX_QTY OR V_ROW_COUNT = 1 THEN
                UPDATE T_PLN_LG_COLLECT_LINE L
                   SET L.COLLECT_HEAD_ID = V_NEW_COLLECT_HEAD_ID,
                       L.LAST_UPDATED_BY = IN_USER_CODE,
                       L.LAST_UPDATE_DATE = SYSDATE
                 WHERE L.COLLECT_HEAD_ID = R_CH.COLLECT_HEAD_ID
                   AND L.ORDER_HEAD_ID = R_CL.ORDER_HEAD_ID;
              END IF;
               
              --插入新的汇总头
              SELECT H.*
                INTO R_LG_COLLECT_HEAD
                FROM T_PLN_LG_COLLECT_HEAD H
               WHERE H.COLLECT_HEAD_ID = R_CH.COLLECT_HEAD_ID;
                
              R_LG_COLLECT_HEAD.COLLECT_HEAD_ID := V_NEW_COLLECT_HEAD_ID;
              R_LG_COLLECT_HEAD.CREATED_BY := IN_USER_CODE;
              R_LG_COLLECT_HEAD.CREATION_DATE := SYSDATE;
              R_LG_COLLECT_HEAD.LAST_UPDATED_BY := IN_USER_CODE;
              R_LG_COLLECT_HEAD.LAST_UPDATE_DATE := SYSDATE;
              INSERT INTO T_PLN_LG_COLLECT_HEAD VALUES R_LG_COLLECT_HEAD;
              
              IF V_SUM_QTY = V_COLLECT_MAX_QTY OR 
                V_SUM_QTY > V_COLLECT_MAX_QTY AND V_ROW_COUNT = 1 THEN
                --EXIT; --跳出循环
                V_NEW_COLLECT_HEAD_ID := 0;
                V_ROW_COUNT := 0;
                V_SUM_QTY := 0;
              ELSIF V_SUM_QTY > V_COLLECT_MAX_QTY AND V_ROW_COUNT > 1 THEN
                SELECT S_PLN_LG_COLLECT_HEAD.NEXTVAL INTO V_NEW_COLLECT_HEAD_ID FROM DUAL;
                UPDATE T_PLN_LG_COLLECT_LINE L
                   SET L.COLLECT_HEAD_ID = V_NEW_COLLECT_HEAD_ID,
                       L.LAST_UPDATED_BY = IN_USER_CODE,
                       L.LAST_UPDATE_DATE = SYSDATE
                 WHERE L.COLLECT_HEAD_ID = R_CH.COLLECT_HEAD_ID
                   AND L.ORDER_HEAD_ID = R_CL.ORDER_HEAD_ID;
                V_SUM_QTY := R_CL.SUM_TO_PLNORDER_QTY;
                V_ROW_COUNT := 1;
              END IF;
            ELSE
              --把汇总行调整到新汇总头
              UPDATE T_PLN_LG_COLLECT_LINE L
                 SET L.COLLECT_HEAD_ID = V_NEW_COLLECT_HEAD_ID,
                     L.LAST_UPDATED_BY = IN_USER_CODE,
                     L.LAST_UPDATE_DATE = SYSDATE
               WHERE L.COLLECT_HEAD_ID = R_CH.COLLECT_HEAD_ID
                 AND L.ORDER_HEAD_ID = R_CL.ORDER_HEAD_ID;
            END IF;
          END LOOP;
          
          --1、V_ROW_COUNT > 0 AND V_NEW_COLLECT_HEAD_ID > 0 表示还有汇总行未生成汇总头数据
          --2、V_ROW_COUNT = 0 AND V_NEW_COLLECT_HEAD_ID = 0 表示循环全部处理完，没有待处理行
          IF (V_ROW_COUNT > 0 AND V_NEW_COLLECT_HEAD_ID > 0) OR
            (V_ROW_COUNT = 0 AND V_NEW_COLLECT_HEAD_ID = 0) THEN
            IF V_ROW_COUNT > 0 AND V_NEW_COLLECT_HEAD_ID > 0 THEN
              --插入新的汇总头
              SELECT H.*
                INTO R_LG_COLLECT_HEAD
                FROM T_PLN_LG_COLLECT_HEAD H
               WHERE H.COLLECT_HEAD_ID = R_CH.COLLECT_HEAD_ID;
                  
              R_LG_COLLECT_HEAD.COLLECT_HEAD_ID := V_NEW_COLLECT_HEAD_ID;
              R_LG_COLLECT_HEAD.CREATED_BY := IN_USER_CODE;
              R_LG_COLLECT_HEAD.CREATION_DATE := SYSDATE;
              R_LG_COLLECT_HEAD.LAST_UPDATED_BY := IN_USER_CODE;
              R_LG_COLLECT_HEAD.LAST_UPDATE_DATE := SYSDATE;
              INSERT INTO T_PLN_LG_COLLECT_HEAD VALUES R_LG_COLLECT_HEAD;
              V_NEW_COLLECT_HEAD_ID := 0;
            END IF;
            DELETE FROM T_PLN_LG_COLLECT_HEAD H WHERE H.COLLECT_HEAD_ID = R_CH.COLLECT_HEAD_ID;
            --EXIT; --跳出循环
          END IF;
        --END LOOP;
      END LOOP;
    END IF;
  EXCEPTION
    When Others Then
      Out_Result := '提货订单预约汇总基数拆单处理失败，!' || v_Nl || Substr(Sqlerrm, 1, 256) || v_Nl ||
                  Substr(Dbms_Utility.Format_Error_Backtrace, 1, 100);
      Rollback;
  END P_LG_COLLECT_SPLIT;

End Pkg_Pln_Lg_Collect;
/

