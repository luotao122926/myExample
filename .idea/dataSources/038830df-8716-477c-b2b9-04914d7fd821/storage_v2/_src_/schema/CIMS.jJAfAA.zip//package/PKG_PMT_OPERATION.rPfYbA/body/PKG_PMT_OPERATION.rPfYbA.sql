create PACKAGE BODY PKG_PMT_OPERATION IS

  V_NL             CONSTANT VARCHAR2(2) := CHR(13) || CHR(10); --换行
  /*
     create-date 2016-2-29
     create_by   wulin
     描述 : 中转单红冲回写红冲数量
  */
  PROCEDURE P_ORDER_WRITEBACK_AMOUNT_RED(I_PO_NUMBER IN T_INV_PO_HEADERS.PO_NUM%TYPE, --中转单单号
                                         I_ENTITY_ID IN NUMBER, --实体ID
                                         O_FLAG      OUT VARCHAR2, --返回值
                                         O_FLAG_MSG  OUT VARCHAR2 --返回信息
                                         ) IS
    V_OLD_PO_NUMBER   T_INV_PO_HEADERS.OLD_PO_NUM%TYPE;
    V_BILL_TYPE_CODE  T_INV_BILL_TYPES.BILL_TYPE_CODE%TYPE;
    V_RED_QTY         T_INV_PO_LINES.BILLED_QTY%TYPE; --中转单红冲数量
    V_OLD_RED_QTY     T_PMT_ORDER_INV_DETAIL.CANCEL_QTY%TYPE; --原红冲数量
    V_PMT_OLD_QTY     T_PMT_ORDER_INV_DETAIL.STORAGED_QTY%TYPE; --原入库数量
    V_PMT_NEW_QTY     T_PMT_ORDER_INV_DETAIL.STORAGED_QTY%TYPE; --现入库数量
    V_PMT_NEW_RED_QTY T_PMT_ORDER_INV_DETAIL.CANCEL_QTY%TYPE; --现红冲数量
    V_PMT_ORDER_NUM   T_PMT_ORDER_HEADER.ORDER_NUM%TYPE; --采购订单号;
    V_CANCEL_AMOUNT   NUMBER := 0;

    V_CANCEL_AMOUNT_TOTAL NUMBER := 0;

    --红冲单头表
    CURSOR C_RED_PO_HEAD_INFO IS
      SELECT *
        FROM T_INV_PO_HEADERS
       WHERE PO_NUM = I_PO_NUMBER
         AND ENTITY_ID = I_ENTITY_ID;

    V_RED_HEADER_INFO C_RED_PO_HEAD_INFO%ROWTYPE;
  
    CURSOR C_PMT_INV_DETAIL_INFO(P_PO_NUM VARCHAR2, P_ENTITY_ID NUMBER) IS
      SELECT OD.* FROM T_PMT_ORDER_INV_DETAIL OD
      INNER JOIN T_PMT_ORDER_LINES L ON (L.ORDER_LINE_ID = OD.ORDER_LINE_ID)
      WHERE OD.PO_NUM = P_PO_NUM AND OD.ENTITY_ID = P_ENTITY_ID
      FOR UPDATE OF OD.PMT_INV_DETAIL_ID,L.ORDER_LINE_ID WAIT 3;
    --R_PMT_INV_DETAIL_INFO C_PMT_INV_DETAIL_INFO%ROWTYPE;

  BEGIN
    O_FLAG     := PKG_PMT_OPERATION.V_RESULT;
    O_FLAG_MSG := PKG_PMT_OPERATION.V_RESULT_MSG;
    --获取原PO单据号
    BEGIN
      SELECT T.OLD_PO_NUM
        INTO V_OLD_PO_NUMBER
        FROM T_INV_PO_HEADERS T
       WHERE T.PO_NUM = I_PO_NUMBER
         AND T.ENTITY_ID = I_ENTITY_ID;
    EXCEPTION
      WHEN OTHERS THEN
        O_FLAG     := -1;
        O_FLAG_MSG := '推广物料回写红冲数量失败！ 找不到该单据!';
        RAISE PKG_PMT_OPERATION.PMT_EXCEPTION;
    END;
    --获取红冲单头记录
    OPEN C_RED_PO_HEAD_INFO;
    LOOP
      FETCH C_RED_PO_HEAD_INFO
        INTO V_RED_HEADER_INFO;

      EXIT WHEN C_RED_PO_HEAD_INFO%NOTFOUND;
    END LOOP;
    CLOSE C_RED_PO_HEAD_INFO;
    -- 判断单据是否为红冲单
    BEGIN
      SELECT T.BILL_TYPE_CODE
        INTO V_BILL_TYPE_CODE
        FROM T_INV_BILL_TYPES T
       WHERE T.BILL_TYPE_ID = V_RED_HEADER_INFO.PO_TYPE_ID
         AND T.ENTITY_ID = V_RED_HEADER_INFO.ENTITY_ID
         AND T.CANCEL_FLAG = 'Y';
    EXCEPTION
      WHEN OTHERS THEN
        O_FLAG     := -1;
        O_FLAG_MSG := '推广物料回写红冲数量失败！ 该单据不是红冲单!';
        RAISE PKG_PMT_OPERATION.PMT_EXCEPTION;
    END;

        --遍历对应采购单的入库明细
    /*OPEN C_PMT_INV_DETAIL_INFO;
      LOOP
        FETCH C_PMT_INV_DETAIL_INFO
          INTO R_PMT_INV_DETAIL_INFO;
      
        EXIT WHEN C_PMT_INV_DETAIL_INFO%NOTFOUND;*/
    FOR R_PMT_INV_DETAIL_INFO IN C_PMT_INV_DETAIL_INFO(V_OLD_PO_NUMBER,V_RED_HEADER_INFO.ENTITY_ID) LOOP
    --获取红冲单行
        FOR RED_LINE_INFO IN (SELECT * FROM T_INV_PO_LINES T WHERE T.PO_ID = V_RED_HEADER_INFO.PO_ID) LOOP
          IF (R_PMT_INV_DETAIL_INFO.PMT_ID = RED_LINE_INFO.ITEM_ID)/*
          AND (R_PMT_INV_DETAIL_INFO.ACTUAL_QTY IS NULL OR R_PMT_INV_DETAIL_INFO.CANCEL_QTY IS NULL
          OR R_PMT_INV_DETAIL_INFO.STORAGE_NOW_QTY > (NVL(R_PMT_INV_DETAIL_INFO.ACTUAL_QTY,0)
           + NVL(R_PMT_INV_DETAIL_INFO.CANCEL_QTY,0)))*/ THEN
            V_OLD_RED_QTY     := NVL(R_PMT_INV_DETAIL_INFO.CANCEL_QTY, 0);
            V_PMT_OLD_QTY     := NVL(R_PMT_INV_DETAIL_INFO.STORAGE_NOW_QTY, 0);
            V_RED_QTY         := NVL(RED_LINE_INFO.BILLED_QTY, 0);
            V_PMT_NEW_QTY     := V_PMT_OLD_QTY - V_RED_QTY;
            V_PMT_NEW_RED_QTY := V_OLD_RED_QTY + V_RED_QTY;
            --校验红冲数量是否小于于入库执行明细上的当前入库数量
            IF V_PMT_NEW_QTY < 0 THEN
              O_FLAG     := -1;
              O_FLAG_MSG := '推广物料回写红冲数量失败！ 红冲数量[' || V_RED_QTY || ']>现入库数量[' ||
                            V_PMT_OLD_QTY || ']!';
              RAISE PKG_PMT_OPERATION.PMT_EXCEPTION;
            END IF;
            V_CANCEL_AMOUNT       := V_RED_QTY *
                                     R_PMT_INV_DETAIL_INFO.PMT_PRICE;
            V_CANCEL_AMOUNT_TOTAL := V_CANCEL_AMOUNT_TOTAL + V_CANCEL_AMOUNT;
            --更新入库执行表
            UPDATE T_PMT_ORDER_INV_DETAIL TPM
               SET TPM.STORAGE_NOW_QTY = V_PMT_NEW_QTY,
                   TPM.CANCEL_QTY      = V_PMT_NEW_RED_QTY
             WHERE /*TPM.PO_NUM = V_OLD_PO_NUMBER
               AND TPM.PMT_ID = RED_LINE_INFO.ITEM_ID
               AND TPM.ENTITY_ID = V_RED_HEADER_INFO.ENTITY_ID*/
               TPM.PMT_INV_DETAIL_ID = R_PMT_INV_DETAIL_INFO.PMT_INV_DETAIL_ID
               ;

            --更新相关物料的入库数量

            UPDATE T_PMT_ORDER_INV_DETAIL OI
               SET OI.STORAGED_QTY = OI.STORAGED_QTY - V_RED_QTY
             --WHERE OI.PMT_CODE = R_PMT_INV_DETAIL_INFO.PMT_CODE;
             WHERE OI.ORDER_LINE_ID = R_PMT_INV_DETAIL_INFO.ORDER_LINE_ID
             --AND OI.PO_NUM = V_OLD_PO_NUMBER
             AND OI.PMT_CODE = R_PMT_INV_DETAIL_INFO.PMT_CODE 
             AND OI.ENTITY_ID = V_RED_HEADER_INFO.ENTITY_ID;

            --更新采购单行上对应的数量
            UPDATE T_PMT_ORDER_LINES L
               SET L.STORAGED_QTY = L.STORAGED_QTY - V_RED_QTY
             WHERE L.ORDER_LINE_ID = R_PMT_INV_DETAIL_INFO.ORDER_LINE_ID;

            V_PMT_ORDER_NUM := R_PMT_INV_DETAIL_INFO.ORDER_HEAD_NUM;
          END IF;
        
        END LOOP;
    END LOOP;
    BEGIN
      /**
        如果采购订单为关闭状态则红冲部分释放预算
      */
      IF V_PMT_ORDER_NUM IS NOT NULL THEN

        FOR PMT_ORDER_NUM IN (SELECT *
                                FROM T_PMT_ORDER_HEADER T
                               WHERE T.ORDER_NUM = V_PMT_ORDER_NUM) LOOP
          IF PMT_ORDER_NUM.ORDER_STATUS = PKG_PMT_OPERATION.V_CLOSE_STATUS THEN
            P_UNOCCUPY_BUDGET(I_ORDER_ID   => PMT_ORDER_NUM.ORDER_HEAD_ID,
                              I_FEE_AMOUNT => V_CANCEL_AMOUNT_TOTAL,
                              I_ENTITY_ID  => I_ENTITY_ID,
                              O_FLAG       => O_FLAG,
                              O_FLAG_MSG   => O_FLAG_MSG);

            IF O_FLAG <> PKG_PMT_OPERATION.V_RESULT THEN
              RAISE PKG_PMT_OPERATION.PMT_EXCEPTION;
            END IF;
          END IF;
        END LOOP;
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        ROLLBACK;
        O_FLAG     := -1;
        O_FLAG_MSG := '释放推广物料采购合同预算不成功：' || O_FLAG_MSG || V_NL || SUBSTR(SQLERRM, 1, 200);
    END;
  EXCEPTION
    WHEN PKG_PMT_OPERATION.PMT_EXCEPTION THEN
      ROLLBACK;
      IF O_FLAG = V_RESULT THEN
        O_FLAG := '-1';
      END IF;
      IF O_FLAG_MSG IS NULL THEN
        O_FLAG_MSG := '调用P_ORDER_WRITEBACK_AMOUNT_RED失败' || SUBSTR(SQLERRM, 1, 200);
      END IF;
      --O_FLAG_MSG := '释放推广物料采购合同预算不成功：' || O_FLAG_MSG;
      RETURN;
    WHEN OTHERS THEN
      ROLLBACK;
      O_FLAG     := -1;
      IF SQLCODE = -30006 OR SQLCODE = -54 THEN
        O_FLAG := '-3';
        O_FLAG_MSG := '中转单红冲回写红冲数量（红冲单）发生异常，同时存在其他操作：' || SQLERRM;
      ELSE
        O_FLAG_MSG := '中转单红冲回写红冲数量（红冲单）发生异常：[SQLCODE：' || SQLCODE || '，MSG：' ||
                      SQLERRM || ']';
      END IF;
      --O_FLAG_MSG := '调用P_ORDER_WRITEBACK_AMOUNT_RED失败' || SUBSTR(SQLERRM, 1, 200);
  END P_ORDER_WRITEBACK_AMOUNT_RED;
  /**
  * 关闭推广物料采购申请单
  **/
  PROCEDURE P_CLOSE_PMT_ORDER(I_ORDER_ID  IN T_PMT_ORDER_HEADER.ORDER_HEAD_ID%TYPE, --采购头表ID
                              I_OPER_TYPE IN VARCHAR2, --操作类型 为Y 则如果有没有入库完的继续关闭并且释放预算，否则不关闭返回信息
                              I_ENTITY_ID IN NUMBER, --实体ID
                              O_FLAG      OUT VARCHAR2, --返回值
                              O_FLAG_MSG  OUT VARCHAR2 --返回信息
                              ) IS
    --采购订单头表信息
    CURSOR C_ORDER_HEADER_INFO IS
      SELECT *
        FROM T_PMT_ORDER_HEADER
       WHERE ORDER_HEAD_ID = I_ORDER_ID
         AND ENTITY_ID = I_ENTITY_ID;
    --头表信息
    V_ORDER_HEADER_INFO C_ORDER_HEADER_INFO%ROWTYPE;

    V_MSG VARCHAR2(2000) := ''; --拼接当前单据未入库产品信息

    V_CANCEL_AMOUNT NUMBER := 0; --每行取消金额

    V_CANCEL_QTY NUMBER := 0; --每行取消数量

    V_CANCEL_AMOUNT_TOTAL NUMBER := 0; --当前单据总共需要释放的预算金额

    V_CANCEL_FLAG VARCHAR2(4) := 'N';

  BEGIN
    O_FLAG     := PKG_PMT_OPERATION.V_RESULT;
    O_FLAG_MSG := PKG_PMT_OPERATION.V_RESULT_MSG;
    --获取采购申请单记录
    OPEN C_ORDER_HEADER_INFO;
    LOOP
      FETCH C_ORDER_HEADER_INFO
        INTO V_ORDER_HEADER_INFO;

      EXIT WHEN C_ORDER_HEADER_INFO%NOTFOUND;
    END LOOP;
    CLOSE C_ORDER_HEADER_INFO;

    --校验单据状态 在制单  审核通过  已执行状态下的单据才能关闭 其他状态不允许关闭
    IF V_ORDER_HEADER_INFO.ORDER_STATUS NOT IN
       (PKG_PMT_OPERATION.V_CREATE_STATUS,
        PKG_PMT_OPERATION.V_CRIDIT_STATUS,
        PKG_PMT_OPERATION.V_ZX_STATUS) THEN
      O_FLAG     := -1;
      O_FLAG_MSG := '只有状态在制单,审核通过,已执行状态的单据才能关闭 请检查！';
      RAISE PKG_PMT_OPERATION.PMT_EXCEPTION;
    END IF;
    /**
      校验单据为非红冲单
    */
    BEGIN
      SELECT T.CANCEL_FLAG
        INTO V_CANCEL_FLAG
        FROM T_INV_BILL_TYPES T
       WHERE T.BILL_TYPE_CODE = V_ORDER_HEADER_INFO.BILLED_TYPE
         AND T.ENTITY_ID = V_ORDER_HEADER_INFO.ENTITY_ID;

    EXCEPTION
      WHEN OTHERS THEN
        O_FLAG     := '-1';
        O_FLAG_MSG := '单据类型不存在';
        RAISE PKG_PMT_OPERATION.PMT_EXCEPTION;
    END;

    IF V_CANCEL_FLAG = 'Y' THEN
      O_FLAG     := '-1';
      O_FLAG_MSG := '红冲单不能关闭';
      RAISE PKG_PMT_OPERATION.PMT_EXCEPTION;
    END IF;

    --获取采购订单行表
    FOR ORDER_LINE_INFO IN (SELECT *
                              FROM T_PMT_ORDER_LINES T
                             WHERE T.ORDER_HEAD_ID = I_ORDER_ID) LOOP
      --计算每一订单行未入库的数量
      V_CANCEL_QTY := ORDER_LINE_INFO.APPLY_QTY -
                      NVL(ORDER_LINE_INFO.STORAGED_QTY, 0);
      --计算每一订单行未入库金额
      V_CANCEL_AMOUNT := V_CANCEL_QTY * ORDER_LINE_INFO.PMT_PRICE;

      --计算未入库总金额
      V_CANCEL_AMOUNT_TOTAL := V_CANCEL_AMOUNT_TOTAL + V_CANCEL_AMOUNT;

      IF V_CANCEL_QTY > 0 THEN

        V_MSG := V_MSG || '物料[' || ORDER_LINE_INFO.PMT_CODE || ']还有[' ||
                 V_CANCEL_QTY || ']未入库  ';
      END IF;

    END LOOP;

    --如果总金额为0则表示当前单据已经全部入库 则不需要释放预算 直接跳到执行修改单据状态的位置
    IF V_CANCEL_AMOUNT_TOTAL = 0 THEN
      GOTO UPDATESTATUS;
    END IF;
    --如果前台每有确认释放预算则返回详细入库信息到前台展示
    IF I_OPER_TYPE = 'N' THEN
      O_FLAG     := -2;
      O_FLAG_MSG := V_MSG;
      RAISE PKG_PMT_OPERATION.PMT_EXCEPTION;
    END IF;
    --当订单为制单状态时可直接关闭 不需要释放库存占用
    IF V_ORDER_HEADER_INFO.ORDER_STATUS <>
       PKG_PMT_OPERATION.V_CREATE_STATUS THEN
      --释放库存占用
      P_UNOCCUPY_BUDGET(I_ORDER_ID   => I_ORDER_ID,
                        I_FEE_AMOUNT => V_CANCEL_AMOUNT_TOTAL,
                        I_ENTITY_ID  => I_ENTITY_ID,
                        O_FLAG       => O_FLAG,
                        O_FLAG_MSG   => O_FLAG_MSG);

      IF O_FLAG <> PKG_PMT_OPERATION.V_RESULT THEN
        RAISE PKG_PMT_OPERATION.PMT_EXCEPTION;
      END IF;
    ELSIF 'Y' = V_ORDER_HEADER_INFO.BUDGET_FLAG AND 0 < V_ORDER_HEADER_INFO.BUDGET_AMOUNT THEN
      O_FLAG     := -1;
      O_FLAG_MSG := '制单状态预算标识已占用，只能流程页面进行作废或驳回！';
      RAISE PKG_PMT_OPERATION.PMT_EXCEPTION;
    END IF;
    --更新单据状态 以及重算预算
    <<UPDATESTATUS>>

    UPDATE T_PMT_ORDER_HEADER T
       SET T.ORDER_STATUS = PKG_PMT_OPERATION.V_CLOSE_STATUS
     WHERE T.ORDER_HEAD_ID = I_ORDER_ID;

    PKG_PMT_OPERATION.P_RESET_OCCUPY_BUDGET(I_ORDER_ID => I_ORDER_ID,
                                            O_FLAG     => O_FLAG,
                                            O_FLAG_MSG => O_FLAG_MSG);

    IF O_FLAG <> PKG_PMT_OPERATION.V_RESULT THEN
      RAISE PKG_PMT_OPERATION.PMT_EXCEPTION;
    END IF;

  EXCEPTION
    WHEN PKG_PMT_OPERATION.PMT_EXCEPTION THEN
      RETURN;
    WHEN OTHERS THEN
      O_FLAG     := -1;
      O_FLAG_MSG := '调用P_CLOSE_PMT_ORDER失败' || SUBSTR(SQLERRM, 1, 200);
  END P_CLOSE_PMT_ORDER;

  /**
    释放政策预算费用
  */
  PROCEDURE P_UNOCCUPY_BUDGET(I_ORDER_ID   IN T_PMT_ORDER_HEADER.ORDER_HEAD_ID%TYPE, --采购头表ID
                              I_FEE_AMOUNT IN NUMBER,
                              I_ENTITY_ID  IN NUMBER, --实体ID
                              O_FLAG       OUT VARCHAR2, --返回值
                              O_FLAG_MSG   OUT VARCHAR2 --返回信息
                              ) IS
    --采购订单头表信息
    CURSOR C_ORDER_HEADER_INFO IS
      SELECT *
        FROM T_PMT_ORDER_HEADER
       WHERE ORDER_HEAD_ID = I_ORDER_ID
         AND ENTITY_ID = I_ENTITY_ID;
    V_USER_ID              NUMBER;
    V_ORDER_HEADER_INFO    C_ORDER_HEADER_INFO%ROWTYPE;
    V_ENTITY_ID            T_PMT_ORDER_HEADER.ENTITY_ID%TYPE; --主体ID
    V_BUDGET_AMOUNT        T_PMT_ORDER_HEADER.BUDGET_AMOUNT%TYPE; --占用金额
    V_BUDGET_SEGMENT_01_ID T_PMT_ORDER_HEADER.BUDGET_SEGMENT_01_ID%TYPE; --预算树第一层
    V_BUDGET_SEGMENT_02_ID T_PMT_ORDER_HEADER.BUDGET_SEGMENT_02_ID%TYPE; --预算树第二层
    V_BUDGET_SEGMENT_03_ID T_PMT_ORDER_HEADER.BUDGET_SEGMENT_03_ID%TYPE; --预算树第三层
    V_BUDGET_SEGMENT_04_ID T_PMT_ORDER_HEADER.BUDGET_SEGMENT_04_ID%TYPE; --预算树第四层
    V_BUDGET_SEGMENT_05_ID T_PMT_ORDER_HEADER.BUDGET_SEGMENT_05_ID%TYPE; --预算树第五层
    V_BUDGET_SEGMENT_06_ID T_PMT_ORDER_HEADER.BUDGET_SEGMENT_06_ID%TYPE; --预算树第六层
    V_DATE_FLOW_ID       T_PMT_ORDER_HEADER.DATE_FLOW_ID%TYPE; --预算树ID

  BEGIN
    O_FLAG     := PKG_PMT_OPERATION.V_RESULT;
    O_FLAG_MSG := PKG_PMT_OPERATION.V_RESULT_MSG;
    --获取采购申请单记录
    OPEN C_ORDER_HEADER_INFO;
    LOOP
      FETCH C_ORDER_HEADER_INFO
        INTO V_ORDER_HEADER_INFO;

      EXIT WHEN C_ORDER_HEADER_INFO%NOTFOUND;
    END LOOP;
    CLOSE C_ORDER_HEADER_INFO;

    V_ENTITY_ID            := V_ORDER_HEADER_INFO.ENTITY_ID;
    V_BUDGET_AMOUNT        := I_FEE_AMOUNT;
    V_BUDGET_SEGMENT_01_ID := V_ORDER_HEADER_INFO.BUDGET_SEGMENT_01_ID;
    V_BUDGET_SEGMENT_02_ID := V_ORDER_HEADER_INFO.BUDGET_SEGMENT_02_ID;
    V_BUDGET_SEGMENT_03_ID := V_ORDER_HEADER_INFO.BUDGET_SEGMENT_03_ID;
    V_BUDGET_SEGMENT_04_ID := V_ORDER_HEADER_INFO.BUDGET_SEGMENT_04_ID;
    V_BUDGET_SEGMENT_05_ID := V_ORDER_HEADER_INFO.BUDGET_SEGMENT_05_ID;
    V_BUDGET_SEGMENT_06_ID := V_ORDER_HEADER_INFO.BUDGET_SEGMENT_06_ID;
    V_DATE_FLOW_ID       := V_ORDER_HEADER_INFO.DATE_FLOW_ID;
    IF (V_DATE_FLOW_ID IS NULL) THEN
      O_FLAG     := '-1';
      O_FLAG_MSG := '预算树ID为空';
      RAISE PKG_PMT_OPERATION.PMT_EXCEPTION;
    END IF;

    IF (V_ENTITY_ID IS NULL) THEN
      O_FLAG     := '-1';
      O_FLAG_MSG := '主体ID为空';
      RAISE PKG_PMT_OPERATION.PMT_EXCEPTION;
    END IF;

    IF (V_BUDGET_AMOUNT IS NULL) THEN
      O_FLAG     := '-1';
      O_FLAG_MSG := '占用金额为0';
      RAISE PKG_PMT_OPERATION.PMT_EXCEPTION;
    END IF;
    IF (V_BUDGET_SEGMENT_01_ID IS NULL) THEN
      V_BUDGET_SEGMENT_01_ID := -1;
    END IF;
    IF (V_BUDGET_SEGMENT_02_ID IS NULL) THEN
      V_BUDGET_SEGMENT_02_ID := -1;
    END IF;
    IF (V_BUDGET_SEGMENT_03_ID IS NULL) THEN
      V_BUDGET_SEGMENT_03_ID := -1;
    END IF;
    IF (V_BUDGET_SEGMENT_04_ID IS NULL) THEN
      V_BUDGET_SEGMENT_04_ID := -1;
    END IF;
    IF (V_BUDGET_SEGMENT_05_ID IS NULL) THEN
      V_BUDGET_SEGMENT_05_ID := -1;
    END IF;
    IF (V_BUDGET_SEGMENT_06_ID IS NULL) THEN
      V_BUDGET_SEGMENT_06_ID := -1;
    END IF;

    SELECT T.USER_ID
      INTO V_USER_ID
      FROM UP_ORG_USER T
     WHERE T.ACCOUNT = V_ORDER_HEADER_INFO.LAST_UPDATED_BY;

    PKG_BUDGET.P_WRITE_FEE(V_DATE_FLOW_ID,
                           V_ENTITY_ID,
                           V_BUDGET_SEGMENT_01_ID,
                           V_BUDGET_SEGMENT_02_ID,
                           V_BUDGET_SEGMENT_03_ID,
                           V_BUDGET_SEGMENT_04_ID,
                           V_BUDGET_SEGMENT_05_ID,
                           V_BUDGET_SEGMENT_06_ID,
                           '推广物料',
                           I_ORDER_ID,
                           V_ORDER_HEADER_INFO.ORDER_NUM,
                           NULL,
                           NULL,
                           '-' || V_BUDGET_AMOUNT,
                           V_USER_ID,
                           O_FLAG_MSG);
		IF 'SUCCESS' <> O_FLAG_MSG THEN
      O_FLAG     := -1;
      O_FLAG_MSG := '调用PKG_BUDGET.P_WRITE_FEE不成功:' || O_FLAG_MSG;
      RETURN;
    END IF;
    --重算采购单占用预算
    PKG_PMT_OPERATION.P_RESET_OCCUPY_BUDGET(I_ORDER_ID => I_ORDER_ID,
                                            O_FLAG     => O_FLAG,
                                            O_FLAG_MSG => O_FLAG_MSG);

    IF O_FLAG <> PKG_PMT_OPERATION.V_RESULT THEN
      RAISE PKG_PMT_OPERATION.PMT_EXCEPTION;
    END IF;
  EXCEPTION
    WHEN PKG_PMT_OPERATION.PMT_EXCEPTION THEN
      ROLLBACK;
      O_FLAG     := -1;
      O_FLAG_MSG := '释放推广物料采购合同预算不成功：' || O_FLAG_MSG;
      RETURN;
    WHEN OTHERS THEN
      ROLLBACK;
      O_FLAG     := -1;
      O_FLAG_MSG := '调用P_UNOCCUPY_BUDGET失败' || SUBSTR(SQLERRM, 1, 200);
  END P_UNOCCUPY_BUDGET;
  /*
    重算采购单占用预算金额
  */
  PROCEDURE P_RESET_OCCUPY_BUDGET(I_ORDER_ID IN T_PMT_ORDER_HEADER.ORDER_HEAD_ID%TYPE,
                                  O_FLAG     OUT VARCHAR2, --返回值
                                  O_FLAG_MSG OUT VARCHAR2 --返回信息
                                  ) IS

    V_STORAGED_AMOUNT NUMBER := 0; --实际占用预算金额
  BEGIN
    O_FLAG     := PKG_PMT_OPERATION.V_RESULT;
    O_FLAG_MSG := PKG_PMT_OPERATION.V_RESULT_MSG;

    --获取采购订单行表
    FOR ORDER_LINE_INFO IN (SELECT *
                              FROM T_PMT_ORDER_LINES T
                             WHERE T.ORDER_HEAD_ID = I_ORDER_ID) LOOP
      V_STORAGED_AMOUNT := V_STORAGED_AMOUNT +
                           NVL(ORDER_LINE_INFO.STORAGED_QTY, 0) *
                           ORDER_LINE_INFO.PMT_PRICE;
    END LOOP;

    UPDATE T_PMT_ORDER_HEADER T
       SET T.BUDGET_AMOUNT = V_STORAGED_AMOUNT
     WHERE T.ORDER_HEAD_ID = I_ORDER_ID;

  EXCEPTION
    WHEN PKG_PMT_OPERATION.PMT_EXCEPTION THEN
      RETURN;
    WHEN OTHERS THEN
      O_FLAG     := -1;
      O_FLAG_MSG := '调用P_RESET_OCCUPY_BUDGET失败' || SUBSTR(SQLERRM, 1, 200);
  END P_RESET_OCCUPY_BUDGET;

END PKG_PMT_OPERATION;
/

