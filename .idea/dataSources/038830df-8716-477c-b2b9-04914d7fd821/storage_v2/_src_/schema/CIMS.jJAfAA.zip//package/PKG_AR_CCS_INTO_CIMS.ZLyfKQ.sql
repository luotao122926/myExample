create package      PKG_AR_CCS_INTO_CIMS is

  -- Author  : TIANMENGZHU
  -- Created : 2015/6/17 8:56:31
  -- Purpose : CCS纸票录入、客户内产品转款、三方解付引入CIMS

  -- CCS纸票录入，接口表数据插入业务表
  PROCEDURE P_RECEIPT_INTO_NEW(P_CASH_RECEIPT_ID in number, --收款头ID
                               P_MESSAGE         out varchar2 --成功则返回“SUCCESS”，否则返回出错信息
                               );

  --CCS客户内产品转款，接口表数据插入业务表
  PROCEDURE P_TURNFEE_INTO_NEW(P_CASH_TURNFEE_ID in number, --转款头ID
                               P_MESSAGE         out varchar2 --成功则返回“SUCCESS”，否则返回出错信息
                               );

  -- CCS三方解付申请引入CIMS，接口表数据插入业务表
  PROCEDURE P_THREE_PAY_APPLY_INTO(P_THREE_PAY_ID IN NUMBER, --三方解付明细申请ID
                                   P_MESSAGE      OUT VARCHAR2 --成功则返回“SUCCESS”，否则返回出错信息
                                   );

  -- CCS接口表数据插入业务表批量测试
  PROCEDURE P_CCS_BATCH_INTO_CIMS(P_FLAG_ID IN NUMBER, --批处理ID，1-收款；2-转款；3-三方解付
                                  P_MESSAGE OUT VARCHAR2 --成功则返回“SUCCESS”，否则返回出错信息
                                  );
end PKG_AR_CCS_INTO_CIMS;
/

