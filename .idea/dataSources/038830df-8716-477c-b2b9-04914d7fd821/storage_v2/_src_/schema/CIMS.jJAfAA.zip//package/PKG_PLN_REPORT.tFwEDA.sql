create PACKAGE PKG_PLN_REPORT IS

  -- Author  : NICRO.LI
  -- Created : 2016-06-17 17:42:02
  -- Purpose : 

  FUNCTION F_GET_LG_CONTRACT_PROGRESS(P_LG_ORDER_LINE_ID IN NUMBER,
                                      P_LG_ORDER_HEAD_ID IN NUMBER)
    RETURN TBL_LG_CONTRACT_PROGRESS
    PIPELINED;

  ------------------------------------------------------------------------
  -- Author  : NICRO.LI
  -- Created : 2016-07-26 17:42:02
  -- Purpose : 返回运输线路数据
  -------------------------------------------------------------------------
  FUNCTION F_GET_LG_TRANSPORT_LINE(P_BEGIN_AREA_CODE IN VARCHAR2,
                                   P_END_AREA_CODE   IN VARCHAR2)
    RETURN TAB_LG_TRANSPORT_LINE;
    
  ------------------------------------------------------------------------
  -- Author  : NICRO.LI
  -- Created : 2017-12-1 17:42:02
  -- Purpose : 返回运输线路数据，通过主体过滤数据
  -------------------------------------------------------------------------
  FUNCTION F_GET_LG_TRANSPORT_LINE_NEW(IN_BEGIN_AREA_CODE IN VARCHAR2,
                                       IN_END_AREA_CODE   IN VARCHAR2,
                                       IN_ENTITY_ID       IN NUMBER)
    RETURN TAB_LG_TRANSPORT_LINE;
  
  ------------------------------------------------------------------------
  -- Author  : hejy3
  -- Created : 2018-11-28
  -- Purpose : 返回集拼运输线路数据，通过主体过滤数据
  -------------------------------------------------------------------------
  FUNCTION F_GET_LG_TRANSPORT_LINE_PROD(IN_BEGIN_AREA_CODE IN VARCHAR2,
                                        IN_END_AREA_CODE   IN VARCHAR2,
                                        IN_TRANSPORT_LINE_TYPE IN VARCHAR2,
                                        IN_ENTITY_ID       IN NUMBER)
    RETURN TAB_LG_TRANSPORT_LINE;
  ------------------------------------------------------------------------
  -- Author  : lilh6
  -- Created : 2018-12-26
  -- Purpose : 返回下线直发仓库信息，通过产地，中心，主体过滤数据
  -------------------------------------------------------------------------
  Function f_Get_Lg_Transport_Line_Inv(In_Producing_Area_Id In Number,
                                       In_Sales_Center_Code In Varchar2,
                                       In_End_Area_Code     In Varchar2,
                                       In_Entity_Id         In Number)
    Return Tab_Lg_Transport_Line;
    
END PKG_PLN_REPORT;
/

