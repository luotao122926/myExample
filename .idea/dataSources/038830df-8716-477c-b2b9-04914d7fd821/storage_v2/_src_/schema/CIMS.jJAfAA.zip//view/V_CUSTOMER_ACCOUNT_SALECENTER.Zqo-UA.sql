create view V_CUSTOMER_ACCOUNT_SALECENTER as
select h.customer_id,
       h.customer_code,
       h.customer_name,
       h.active_flag,
       h.customer_status,
       o.entity_id,
       --o.active_flag orgActive_flag,
       --DECODE(o.active_flag,'Freezing', 'Active',o.active_flag) orgActive_flag,
       (CASE WHEN 'Freezing' = o.active_flag THEN 'Active' ELSE o.active_flag END) as orgActive_flag,--改动2：原来直接取t_customer_org o.active_flag
       a.account_id,
       a.account_code,
       a.account_name,
       --a.account_status,
       --DECODE(a.active_flag,'Y', 1, 2) as account_status,
       (CASE WHEN 'Y' = a.active_flag THEN 1 ELSE 2 END) as account_status,--改动1：原来直接取t_customer_account的a.account_status
       a.account_status AS account_freezing_status,
       a.active_flag as accActive_flag,
       A.relation_id,
       o.customer_org_id,
       o.sales_center_id,
       o.sales_center_code,
       o.sales_center_name,
       O.ORG_CUSTOMER_FATHER_ID,
       O.ORG_CUSTOMER_FATHER_CODE,
       O.ORG_CUSTOMER_FATHER_NAME,
       O.COOPERATION_MODEL,
       h.customer_enterprise_nature,
       h.is_virtual_customer,
       a.is_free_proto,
       a.is_refund_person,
       nvl(a.is_default_account,'N') is_default_account,
       a.is_refund_verified_credit,
       a.is_turnfee_verified_credit,
       a.remark as remark,
       (CASE WHEN exists(select 1 from t_customer_account_address ca where ca.ACCOUNT_ID = a.ACCOUNT_ID)  then 1 else 0 end) isAllocate
       /**(SELECT decode(COUNT(ca.ACCOUNT_ID), 0 , 0, 1) FROM cims.t_customer_account_address ca WHERE ca.ACCOUNT_ID = a.ACCOUNT_ID) AS isAllocate**/
       /**decode((select count(ta.account_id)
                from t_customer_account ta
               where ta.account_id = a.account_id
                 and ta.account_id not in
                     (select ca.account_id
                        from t_customer_account_address ca
                       group by ca.account_id)),
              0,
              1,
              0) as isAllocate**/
  from t_customer_account a
  left join t_customer_header h
    on h.customer_id = a.customer_id
  left join t_customer_org o
    on (A.CUSTOMER_ORG_ID = o.customer_org_id and (a.entity_id = o.entity_id or (a.entity_id is null and o.entity_id is null)))
  /*left join t_customer_acc_org_relation r
    on a.account_id = r.account_id
  left join t_customer_org o
    on (r.customer_org_id = o.customer_org_id and (a.entity_id = o.entity_id or (a.entity_id is null and o.entity_id is null)))*/
  with read only
/

comment on column V_CUSTOMER_ACCOUNT_SALECENTER.CUSTOMER_ID is '客户ID'
/

comment on column V_CUSTOMER_ACCOUNT_SALECENTER.CUSTOMER_CODE is '客户编码'
/

comment on column V_CUSTOMER_ACCOUNT_SALECENTER.CUSTOMER_NAME is '客户名称'
/

comment on column V_CUSTOMER_ACCOUNT_SALECENTER.ACTIVE_FLAG is '客户有效状态'
/

comment on column V_CUSTOMER_ACCOUNT_SALECENTER.CUSTOMER_STATUS is '客户状态'
/

comment on column V_CUSTOMER_ACCOUNT_SALECENTER.ENTITY_ID is '主体ID'
/

comment on column V_CUSTOMER_ACCOUNT_SALECENTER.ORGACTIVE_FLAG is '组织状态'
/

comment on column V_CUSTOMER_ACCOUNT_SALECENTER.ACCOUNT_ID is '账户ID'
/

comment on column V_CUSTOMER_ACCOUNT_SALECENTER.ACCOUNT_CODE is '账户编码'
/

comment on column V_CUSTOMER_ACCOUNT_SALECENTER.ACCOUNT_NAME is '账户名称'
/

comment on column V_CUSTOMER_ACCOUNT_SALECENTER.ACCOUNT_STATUS is '账户状态:1/有效,2/失效'
/

comment on column V_CUSTOMER_ACCOUNT_SALECENTER.ACCOUNT_FREEZING_STATUS is '账户状态:1/有效,2/失效,-1/冻结'
/

comment on column V_CUSTOMER_ACCOUNT_SALECENTER.RELATION_ID is '关系ID'
/

comment on column V_CUSTOMER_ACCOUNT_SALECENTER.CUSTOMER_ORG_ID is '组织ID'
/

comment on column V_CUSTOMER_ACCOUNT_SALECENTER.SALES_CENTER_ID is '中心ID'
/

comment on column V_CUSTOMER_ACCOUNT_SALECENTER.SALES_CENTER_CODE is '中心编码'
/

comment on column V_CUSTOMER_ACCOUNT_SALECENTER.SALES_CENTER_NAME is '中心名称'
/

comment on column V_CUSTOMER_ACCOUNT_SALECENTER.ORG_CUSTOMER_FATHER_ID is '中心关联客户ID'
/

comment on column V_CUSTOMER_ACCOUNT_SALECENTER.ORG_CUSTOMER_FATHER_CODE is '中心关联客户编码'
/

comment on column V_CUSTOMER_ACCOUNT_SALECENTER.ORG_CUSTOMER_FATHER_NAME is '中心关联客户名称'
/

comment on column V_CUSTOMER_ACCOUNT_SALECENTER.COOPERATION_MODEL is '合作类型'
/

comment on column V_CUSTOMER_ACCOUNT_SALECENTER.CUSTOMER_ENTERPRISE_NATURE is '客户企业性质'
/

comment on column V_CUSTOMER_ACCOUNT_SALECENTER.IS_VIRTUAL_CUSTOMER is '是否虚拟客户'
/

comment on column V_CUSTOMER_ACCOUNT_SALECENTER.IS_FREE_PROTO is '是否免费出样'
/

comment on column V_CUSTOMER_ACCOUNT_SALECENTER.IS_REFUND_PERSON is '是否退款到个人'
/

comment on column V_CUSTOMER_ACCOUNT_SALECENTER.IS_DEFAULT_ACCOUNT is '是否是本客户的主账户，默认为N'
/

comment on column V_CUSTOMER_ACCOUNT_SALECENTER.IS_REFUND_VERIFIED_CREDIT is '是否退款控额度，默认为Y'
/

comment on column V_CUSTOMER_ACCOUNT_SALECENTER.IS_TURNFEE_VERIFIED_CREDIT is '是否转款控额度，默认为Y'
/

comment on column V_CUSTOMER_ACCOUNT_SALECENTER.REMARK is '备注'
/

comment on column V_CUSTOMER_ACCOUNT_SALECENTER.ISALLOCATE is '是否分配'
/

