create PACKAGE BODY      PKG_SO_RT IS
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-01-22
  *     创建者：陈武杰
  *   功能说明：关联订单
  *   T_INV_PROC_GROUP_HEADERS ERP-OMS-029 接口服务名称：例程集
  * SELECT *  FROM T_INV_PROC_GROUP_HEADERS A WHERE A.GROUP_CODE IN ('A01', 'B01', 'B02')
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_TABLE_ACTION_LOG(P_TABLE_NAME     VARCHAR2, --操作表名称
                               P_ACTION_REMARKS VARCHAR2, --操作说明
                               P_PK             VARCHAR2, --关键主键
                               P_ISERR          NUMBER, --是否出错，1出错，0未出错
                               P_MSG            VARCHAR2 --错误信息
                               ) AS
    PRAGMA AUTONOMOUS_TRANSACTION; --自治事务
  BEGIN
    INSERT INTO T_SO_TABLE_ACTION_LOG
      (ID, TABLE_NAME, ACTION_REMARKS, PK_NUM, ISERR, MSG, CREATED)
    VALUES
      (SYS_GUID(),
       P_TABLE_NAME,
       P_ACTION_REMARKS,
       P_PK,
       P_ISERR,
       P_MSG,
       SYSDATE);
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      NULL;
  END;
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-01-22
  *     创建者：陈武杰
  *   功能说明：关联订单
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_TO_RT_ORDER(P_SO_HEADER_ID IN T_SO_HEADER.SO_HEADER_ID%TYPE, --销售单头id
                             P_RESULT       IN OUT NUMBER, --返回错误ID
                             P_ERR_MSG      IN OUT VARCHAR2 --返回错误信息
                             ) AS
    --PRAGMA AUTONOMOUS_TRANSACTION; --自治事务
    --销售单据头
    CURSOR C_SO_HEADER IS
      SELECT * FROM T_SO_HEADER WHERE SO_HEADER_ID = P_SO_HEADER_ID;
    R_SO_HEADER C_SO_HEADER%ROWTYPE;
  
    --关联定单头接口表
    R_RT_HEADERS INTF_CUX_ICP_ORDER_REQ_HEADERS%ROWTYPE;
  
    V_ID INTF_CUX_ICP_ORDER_REQ_HEADERS.ID%TYPE;
    --固定变量
    V_PROC_GROUP_ID      INTF_CUX_ICP_ORDER_REQ_HEADERS.PROC_GROUP_ID%TYPE; --例程集ID    NUMBER
    V_SUPPLIER_SYSTEM    INTF_CUX_ICP_ORDER_REQ_HEADERS.SUPPLIER_SYSTEM%TYPE; --供方来源系统VARCHAR2(30)
    V_REQUIREMENT_SYSTEM INTF_CUX_ICP_ORDER_REQ_HEADERS.REQUIREMENT_SYSTEM%TYPE; --需方来源系统VARCHAR2(30)
    --V_SOURCE_ORDERS_TYPE INTF_CUX_ICP_ORDER_REQ_HEADERS.SOURCE_ORDERS_TYPE%TYPE; --来源单据类型VARCHAR2(100)01中转单/02财务单
    V_STATUS INTF_CUX_ICP_ORDER_REQ_HEADERS.STATUS%TYPE; --状态：N待发送；P已发送；S成功VARCHAR2(100)
    --根据条件改变变量
    V_SUPPLIER_ORG_ID INTF_CUX_ICP_ORDER_REQ_HEADERS.SUPPLIER_ORG_ID%TYPE; --SUPPLIER_ORG_ID供方OU ID
    V_SUPPLIER_ORG    INTF_CUX_ICP_ORDER_REQ_HEADERS.SUPPLIER_ORG%TYPE; --SUPPLIER_ORG供方OU
    V_S_ORDER_TYPE_ID INTF_CUX_ICP_ORDER_REQ_HEADERS.S_ORDER_TYPE_ID%TYPE; --S_ORDER_TYPE_ID销售订单类型ID
    V_S_ORDER_TYPE    INTF_CUX_ICP_ORDER_REQ_HEADERS.S_ORDER_TYPE%TYPE; --S_ORDER_TYPE销售订单类型
  
    V_REQUIREMENT_ORG_ID INTF_CUX_ICP_ORDER_REQ_HEADERS.REQUIREMENT_ORG_ID%TYPE; --REQUIREMENT_ORG_ID需方OU ID
    V_REQUIREMENT_ORG    INTF_CUX_ICP_ORDER_REQ_HEADERS.REQUIREMENT_ORG%TYPE; --REQUIREMENT_ORG需方OU
    V_SOURCE_CODE        INTF_CUX_ICP_ORDER_REQ_HEADERS.SOURCE_CODE%TYPE; --SOURCE_CODE
    V_SOURCE_ORDERS      INTF_CUX_ICP_ORDER_REQ_HEADERS.SOURCE_ORDERS%TYPE; --SOURCE_ORDERS来源单据
  
    V_RECEIVE_ORG_ID  INTF_CUX_ICP_ORDER_REQ_HEADERS.RECEIVE_ORG_ID%TYPE; -- RECEIVE_ORG_ID 接收组织ID
    V_RECEIVE_ORG     INTF_CUX_ICP_ORDER_REQ_HEADERS.RECEIVE_ORG%TYPE; -- RECEIVE_ORG 接收组织
    V_SHIPPING_ORG_ID INTF_CUX_ICP_ORDER_REQ_HEADERS.SHIPPING_ORG_ID%TYPE; -- SHIPPING_ORG_ID 发运组织ID
    V_SHIPPING_ORG    INTF_CUX_ICP_ORDER_REQ_HEADERS.SHIPPING_ORG%TYPE; -- SHIPPING_ORG 发运组织
  
    V_SO_CNT NUMBER; --查询记录条数
    --关联交易模式 chen.wj
    V_SO_TRX_MODE VARCHAR2(10);
  
    --chenzh
    V_PRICE_LIST_ID VARCHAR2(100); --价格列表id
    V_VENDOR_CODE   VARCHAR2(100); --供应商编码
    V_PRICE         NUMBER; --不含税价格
  
    V_PULL_MODE NUMBER;
    
    ----------add by wangc 2015-6-23--------
    --当前日期 
    V_CURR_DATE DATE;
    --日期格式 
    V_DATA_FORMAT  VARCHAR2(10) := 'YYYY-MM-DD';
     --当前时间
    V_CURR_TIME DATE := SYSDATE;
    -----------------------------------------
  BEGIN
    --初始返回值
    P_RESULT  := PKG_SO_PUB.V_RESULT;
    P_ERR_MSG := PKG_SO_PUB.V_SUCCESS;
  
    V_PROC_GROUP_ID := 843; --1  843 A01 关联订单  ORDERS  同步生成PO、SO 2013-11-01
    --V_SUPPLIER_SYSTEM := 'GERP';
    --V_REQUIREMENT_SYSTEM := 'GERP';
    --V_SOURCE_ORDERS_TYPE := '02'; --01中转单/02财务单
    V_STATUS := 'N';
  
    --获取销售单据头数据
    OPEN C_SO_HEADER;
    FETCH C_SO_HEADER
      INTO R_SO_HEADER;
    CLOSE C_SO_HEADER;
  
    --防重复检查
    SELECT COUNT(*)
      INTO V_SO_CNT
      FROM INTF_CUX_ICP_ORDER_REQ_HEADERS
     WHERE SOURCE_ORDERS = R_SO_HEADER.SO_NUM
       AND SOURCE_ORDERS_TYPE = V_SOURCE_ORDERS_TYPE;
  
    IF V_SO_CNT > 0 THEN
      P_ERR_MSG := '销售单据[单据号：' || R_SO_HEADER.SO_NUM ||
                   ']已生成关联订单[INTF_CUX_ICP_ORDER_REQ_HEADERS]表记录';
      RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
    END IF;
    --获取对应的ERP订单类型
    /*    --ERP那么反馈，如果没有特殊要求不用传值
    BEGIN
      SELECT TRANSACTION_TYPE_ID, NAME
        INTO V_S_ORDER_TYPE_ID, V_S_ORDER_TYPE
        FROM V_SO_ERP_TYPE_RELATION
       WHERE SRC_TYPE_ID = R_SO_HEADER.BIZ_SRC_BILL_TYPE_ID
         AND ORG_ID = R_SO_HEADER.ERP_OU_ID
         AND ROWNUM = 1;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        P_ERR_MSG := '销售单据类型[源类型ID：' || R_SO_HEADER.BIZ_SRC_BILL_TYPE_ID ||
                     ']没有配置对应的ERP订单类型或ERP订单类型不属于当前OU[OU ID：' ||
                     R_SO_HEADER.ERP_OU_ID || ']。';
        RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      WHEN OTHERS THEN
        P_ERR_MSG := '获取对应的ERP订单类型发生异常：' || SQLERRM;
        RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
    END;*/
    /*
                                        正向销售   反向销售
    SUPPLIER_ORG_ID NUMBER  供方OU ID     工厂      内销
    SUPPLIER_ORG  VARCHAR2(100) 供方OU    工厂      内销
    REQUIREMENT_ORG_ID  NUMBER  需方OU ID 内销      工厂
    REQUIREMENT_ORG VARCHAR2(100) 需方OU  内销      工厂
    RECEIVE_ORG_ID  NUMBER  接收组织ID    内销      工厂
    RECEIVE_ORG VARCHAR2(100) 接收组织    内销      工厂
    SHIPPING_ORG_ID NUMBER  发运组织ID    工厂      内销
    SHIPPING_ORG  VARCHAR2(100) 发运组织  工厂      内销
    */
    --退货方式：1-推式，2-拉式源单退回，3-拉式反向销售
    IF NVL(R_SO_HEADER.RETURN_MODE, '1') = '3' THEN
      --3-拉式反向销售
      --SUPPLIER_ORG_ID供方OU ID 内销
      V_SUPPLIER_ORG_ID := R_SO_HEADER.ERP_OU_ID;
      V_SUPPLIER_ORG    := R_SO_HEADER.ERP_OU_NAME;
    
      --REQUIREMENT_ORG_ID需方OU ID  工厂
      V_REQUIREMENT_ORG_ID := R_SO_HEADER.FACTORY_OU_ID;
      --REQUIREMENT_ORG需方OU
      V_REQUIREMENT_ORG := R_SO_HEADER.FACTORY_OU_NAME;
      --接收库存组织 工厂
      V_RECEIVE_ORG_ID := R_SO_HEADER.ERP_SUBINV_ID;
      V_RECEIVE_ORG    := R_SO_HEADER.ERP_SUBINV_CODE;
      /*
      临时解决源单库存组织不对问题
      */
      /* SELECT A.ORGANIZATION_ID, A.ORGANIZATION_CODE
             INTO V_RECEIVE_ORG_ID,V_RECEIVE_ORG
       FROM CIMS.T_INV_INVENTORIES A, CIMS.T_INV_ORGANIZATION B
      WHERE A.ENTITY_ID = B.ENTITY_ID
        AND B.ORGANIZATION_ID = A.ORGANIZATION_ID
        AND B.ORGANIZATION_CODE = A.ORGANIZATION_CODE
        AND A.INVENTORY_CODE = R_SO_HEADER.CONSIGNEE_INV_CODE
        AND a.entity_id=R_SO_HEADER.Entity_Id;*/
    
      --发运库存组织 内销
      --V_SHIPPING_ORG_ID 
      --V_SHIPPING_ORG    
      BEGIN
        --add by chen.wj 20150206
        -- -1错误,0非拉式,1销售,2红冲,3源单退回,4反向销售,5源单退货红冲，6拉式其他单据类型
        /*
        'TRX001'; --推式成品销售
        'TRX002'; --推式销售结算
        'TRX003'; --拉式成品销售
        'TRX004'; --拉式源单退回
        'TRX005'; --拉式反向销售
        */
        V_PULL_MODE := PKG_SO_PUB.F_PULL_MODE(R_SO_HEADER.SO_NUM);
        SELECT DECODE(V_PULL_MODE,
                      1,
                      PKG_SO_PUB.V_SO_TRX_MODE_003,
                      2,
                      PKG_SO_PUB.V_SO_TRX_MODE_004,
                      3,
                      PKG_SO_PUB.V_SO_TRX_MODE_004,
                      4,
                      PKG_SO_PUB.V_SO_TRX_MODE_005,
                      5,
                      PKG_SO_PUB.V_SO_TRX_MODE_003,
                      V_PULL_MODE)
          INTO V_SO_TRX_MODE
          FROM DUAL;
        --工厂OU和ERP OU 交互
        --IF V_SO_TRX_MODE = PKG_SO_PUB.V_SO_TRX_MODE_005 THEN--edit by chen.wj 20150304
        SELECT SUPPLIER_SUBINV_ID, --库存组织
               SUPPLIER_SUBINV_CODE --库存组织编码
          INTO V_SHIPPING_ORG_ID, V_SHIPPING_ORG
          FROM T_SO_SUPPLIER_REQUIREMENT T
         WHERE T.ENTITY_ID = R_SO_HEADER.ENTITY_ID
           AND T.REQUIREMENT_OU_ID = R_SO_HEADER.FACTORY_OU_ID
           AND T.SUPPLIER_OU_ID = R_SO_HEADER.ERP_OU_ID
           AND T.TRADE_MODE_CODE = V_SO_TRX_MODE;
        /*ELSE
          SELECT ERP_SUBINV_ID, --库存组织
                 ERP_SUBINV_CODE --库存组织编码
            INTO V_SHIPPING_ORG_ID, V_SHIPPING_ORG
            FROM T_SO_SUPPLIER_REQUIREMENT T
           WHERE T.ENTITY_ID = R_SO_HEADER.ENTITY_ID
             AND T.SUPPLIER_OU_ID = R_SO_HEADER.FACTORY_OU_ID
             AND T.TRADE_MODE_CODE = V_SO_TRX_MODE;
        END IF;*/
      
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          P_ERR_MSG := '供方OU ID[' || R_SO_HEADER.FACTORY_OU_ID || '],主体ID[' ||
                       R_SO_HEADER.ENTITY_ID || '],关联交易模式编码[' ||
                       V_SO_TRX_MODE ||
                       '],T_SO_SUPPLIER_REQUIREMENT表未设置对应的ERP OU！';
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
        WHEN OTHERS THEN
          P_ERR_MSG := '供方OU ID[' || R_SO_HEADER.FACTORY_OU_ID || '],主体ID[' ||
                       R_SO_HEADER.ENTITY_ID || '],关联交易模式编码[' ||
                       V_SO_TRX_MODE ||
                       '],T_SO_SUPPLIER_REQUIREMENT表未设置对应的ERP OU！' ||
                       SQLERRM;
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      END;
    ELSE
      --SUPPLIER_ORG_ID供方OU ID 工厂
      V_SUPPLIER_ORG_ID := R_SO_HEADER.FACTORY_OU_ID;
      V_SUPPLIER_ORG    := R_SO_HEADER.FACTORY_OU_NAME;
    
      --REQUIREMENT_ORG_ID需方OU ID  内销
      V_REQUIREMENT_ORG_ID := R_SO_HEADER.ERP_OU_ID;
      --REQUIREMENT_ORG需方OU
      V_REQUIREMENT_ORG := R_SO_HEADER.ERP_OU_NAME;
      --接收库存组织 内销
      --V_RECEIVE_ORG_ID ;
      --V_RECEIVE_ORG    ;
      BEGIN
        --add by chen.wj 20150206
        -- -1错误,0非拉式,1销售,2红冲,3源单退回,4反向销售,5源单退货红冲，6拉式其他单据类型
        V_PULL_MODE := PKG_SO_PUB.F_PULL_MODE(R_SO_HEADER.SO_NUM);
        SELECT DECODE(V_PULL_MODE,
                      1,
                      PKG_SO_PUB.V_SO_TRX_MODE_003,
                      2,
                      PKG_SO_PUB.V_SO_TRX_MODE_004,
                      3,
                      PKG_SO_PUB.V_SO_TRX_MODE_004,
                      4,
                      PKG_SO_PUB.V_SO_TRX_MODE_005,
                      5,
                      PKG_SO_PUB.V_SO_TRX_MODE_003,
                      V_PULL_MODE)
          INTO V_SO_TRX_MODE
          FROM DUAL;
        --工厂OU和ERP OU 交互
        --edit by chen.wj 20150304
        IF V_SO_TRX_MODE = PKG_SO_PUB.V_SO_TRX_MODE_005 THEN
          SELECT SUPPLIER_SUBINV_ID, --库存组织
                 SUPPLIER_SUBINV_CODE --库存组织编码
            INTO V_RECEIVE_ORG_ID, V_RECEIVE_ORG
            FROM T_SO_SUPPLIER_REQUIREMENT T
           WHERE T.ENTITY_ID = R_SO_HEADER.ENTITY_ID
             AND T.REQUIREMENT_OU_ID = R_SO_HEADER.ERP_OU_ID
             AND T.SUPPLIER_OU_ID = R_SO_HEADER.FACTORY_OU_ID
             AND T.TRADE_MODE_CODE = V_SO_TRX_MODE;
        ELSE
          SELECT ERP_SUBINV_ID, --库存组织
                 ERP_SUBINV_CODE --库存组织编码
            INTO V_RECEIVE_ORG_ID, V_RECEIVE_ORG
            FROM T_SO_SUPPLIER_REQUIREMENT T
           WHERE T.ENTITY_ID = R_SO_HEADER.ENTITY_ID
             AND T.REQUIREMENT_OU_ID = R_SO_HEADER.ERP_OU_ID
             AND T.SUPPLIER_OU_ID = R_SO_HEADER.FACTORY_OU_ID
             AND T.TRADE_MODE_CODE = V_SO_TRX_MODE;
        END IF;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          P_ERR_MSG := '供方OU ID[' || R_SO_HEADER.FACTORY_OU_ID || '],主体ID[' ||
                       R_SO_HEADER.ENTITY_ID || '],关联交易模式编码[' ||
                       V_SO_TRX_MODE ||
                       '],T_SO_SUPPLIER_REQUIREMENT表未设置对应的ERP OU！';
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
        WHEN OTHERS THEN
          P_ERR_MSG := '供方OU ID[' || R_SO_HEADER.FACTORY_OU_ID || '],主体ID[' ||
                       R_SO_HEADER.ENTITY_ID || '],关联交易模式编码[' ||
                       V_SO_TRX_MODE ||
                       '],T_SO_SUPPLIER_REQUIREMENT表未设置对应的ERP OU！' ||
                       SQLERRM;
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      END;
    
      --发运库存组织 工厂
      V_SHIPPING_ORG_ID := R_SO_HEADER.ERP_SUBINV_ID;
      V_SHIPPING_ORG    := R_SO_HEADER.ERP_SUBINV_CODE;
      /*
      临时解决源单库存组织不对问题
      */
      /*SELECT A.ORGANIZATION_ID, A.ORGANIZATION_CODE
             INTO V_SHIPPING_ORG_ID,V_SHIPPING_ORG
       FROM CIMS.T_INV_INVENTORIES A, CIMS.T_INV_ORGANIZATION B
      WHERE A.ENTITY_ID = B.ENTITY_ID
        AND B.ORGANIZATION_ID = A.ORGANIZATION_ID
        AND B.ORGANIZATION_CODE = A.ORGANIZATION_CODE
        AND A.INVENTORY_CODE = R_SO_HEADER.CONSIGNEE_INV_CODE
        AND a.entity_id=R_SO_HEADER.Entity_Id;*/
    
    END IF;
    V_SOURCE_ORDERS := R_SO_HEADER.SO_NUM;
    /*，取序列*/
    V_ID := S_CUX_ICP_ORDER_REQ_HEADERS.NEXTVAL;
  
    INSERT INTO INTF_CUX_ICP_ORDER_REQ_HEADERS
      (ID, --
       SOURCE_HEADER_ID, --来源头ID
       PROC_GROUP_ID, --例程集ID
       SUPPLIER_SYSTEM, --供方来源系统
       SUPPLIER_ORG_ID, --供方OU ID
       SUPPLIER_ORG, --供方OU
       S_ORDER_TYPE_ID, --销售订单类型ID
       S_ORDER_TYPE, --销售订单类型
       REQUIREMENT_SYSTEM, --需方来源系统
       REQUIREMENT_ORG_ID, --需方OU ID
       REQUIREMENT_ORG, --需方OU
       SOURCE_CODE, --
       SOURCE_ORDERS, --来源单据
       SOURCE_ORDERS_TYPE, --来源单据类型
       RECEIVE_ORG_ID, --接收组织ID
       RECEIVE_ORG, --接收组织
       SHIPPING_ORG_ID, --发运组织ID
       SHIPPING_ORG, --发运组织
       COMMENTS, --备注信息
       STATUS, --状态：N待发送；P已发送；S成功
       --POST_DATE, --提交请求时间
       RETRANSMISSION_NUMBER, --重发次数
       ENTITY_ID --主体ID
       )
    VALUES
      (V_ID, --ID
       R_SO_HEADER.SO_HEADER_ID, --SOURCE_HEADER_ID来源头ID
       V_PROC_GROUP_ID, --PROC_GROUP_ID例程集ID
       V_SUPPLIER_SYSTEM, --SUPPLIER_SYSTEM供方来源系统
       V_SUPPLIER_ORG_ID, -- SUPPLIER_ORG_ID 供方OU ID
       V_SUPPLIER_ORG, -- SUPPLIER_ORG 供方OU
       V_S_ORDER_TYPE_ID, -- S_ORDER_TYPE_ID 销售订单类型ID
       V_S_ORDER_TYPE, -- S_ORDER_TYPE 销售订单类型
       V_REQUIREMENT_SYSTEM, --REQUIREMENT_SYSTEM需方来源系统
       V_REQUIREMENT_ORG_ID, -- REQUIREMENT_ORG_ID 需方OU ID
       V_REQUIREMENT_ORG, -- REQUIREMENT_ORG 需方OU
       V_SOURCE_CODE, -- SOURCE_CODE
       V_SOURCE_ORDERS, -- SOURCE_ORDERS 来源单据
       V_SOURCE_ORDERS_TYPE, --SOURCE_ORDERS_TYPE来源单据类型
       V_RECEIVE_ORG_ID, -- RECEIVE_ORG_ID 接收组织ID
       V_RECEIVE_ORG, -- RECEIVE_ORG 接收组织
       V_SHIPPING_ORG_ID, -- SHIPPING_ORG_ID 发运组织ID
       V_SHIPPING_ORG, -- SHIPPING_ORG 发运组织
       NULL, --COMMENTS备注信息
       V_STATUS, --STATUS状态：N待发送；P已发送；S成功
       --SYSDATE, --POST_DATE提交请求时间
       0, --RETRANSMISSION_NUMBER重发次数
       R_SO_HEADER.ENTITY_ID --ENTITY_ID主体ID7
       );
  
    /*  chenzh  获取含税产品价格   2015-02-28 */
  
    BEGIN
      --供应商信息
      SELECT A.VENDOR_CODE --供应商编码
        INTO V_VENDOR_CODE
        FROM V_INV_VENDOR_VIEW A
       WHERE A.ENTITY_ID = R_SO_HEADER.ENTITY_ID --实体ID
         AND A.OPERATING_UNIT = R_SO_HEADER.FACTORY_OU_ID --供方OU ID --供方OU ID --20150427 chen.wj 查询供应商信息，只用工厂OU查询。啊甘、欧阳讨论决定
         AND ROWNUM = 1;
      /*AND A.VENDOR_SITE_OPERATING_UNIT = A.OPERATING_UNIT--edit by chen.wj 20150416啊甘要求只用主体和OU来取供应商编码
      AND A.ORGANIZATION_CODE = V_SHIPPING_ORG; --供方库存组织*/
    
    EXCEPTION
      WHEN OTHERS THEN
        P_ERR_MSG := 'T_INV_VENDOR_ORGANIZATION表查询供应商信息异常：' || SQLERRM ||
                     ',主体ID[' || R_SO_HEADER.ENTITY_ID || '],工厂OU_ID[' ||
                     R_SO_HEADER.FACTORY_OU_ID || ']';
        RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
    END;
  
    BEGIN
      --供应商价格列表
      SELECT A.PRICE_LIST_ID --价格列表ID
        INTO V_PRICE_LIST_ID
        FROM T_BD_VENDOR_PRICELIST A
       WHERE A.ENTITY_ID = R_SO_HEADER.ENTITY_ID
         AND A.TYPE_CODE = 'TRANSIT_TYPE' --add by chen.wj 20150326 增加 中转采购 类别
         AND A.VENDOR_CODE = V_VENDOR_CODE --供应商编码
            --add by chen.wj 20150403 增加有效日期条件
         AND TRUNC(R_SO_HEADER.SO_DATE) >= A.BEGIN_DATE
         AND TRUNC(R_SO_HEADER.SO_DATE) <= NVL(A.END_DATE, SYSDATE);
    
    EXCEPTION
      WHEN OTHERS THEN
        P_ERR_MSG := 'T_BD_VENDOR_PRICELIST表查询不到记录,供应商编码[' || V_VENDOR_CODE || ']';
        RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
    END;
  
    FOR REC IN (SELECT A.SO_HEADER_ID     AS SOURCE_HEADER_ID,
                       A.SO_LINE_NUM      AS REQ_LINE_NUM,
                       A.ITEM_ID          AS SUPPLIER_ITEM_ID,
                       A.ITEM_CODE        AS SUPPLIER_ITEM_NUM,
                       A.ITEM_NAME        AS SUPPLIER_ITEM_NAME,
                       A.ITEM_ID          AS REQUIRE_ITEM_ID,
                       A.ITEM_CODE        AS REQUIRE_ITEM_NUM,
                       A.ITEM_UOM         AS PRIMARY_UNIT_OF_MEASURE,
                       A.ITEM_QTY         AS REQUEST_QUANTITY,
                       A.ITEM_PRICE       AS UNIT_PRICE,
                       R_SO_HEADER.SO_NUM AS SOUREC_HEADER,
                       A.SO_LINE_ID       AS SOURCE_LINE,
                       A.REMARK           AS COMMENTS,
                       V_ID               AS HEADER_ID
                  FROM T_SO_LINE A
                 WHERE A.SO_HEADER_ID = P_SO_HEADER_ID
                 ORDER BY A.SO_LINE_NUM) LOOP
    ---------add by wangc 2015-6-23----------
    --取当前日期
    V_CURR_DATE := TO_DATE(TO_CHAR(V_CURR_TIME, V_DATA_FORMAT),
                           V_DATA_FORMAT);
    -----------------------------------------
      BEGIN
        V_PRICE := PKG_BD_PRICE.F_GET_PRICE(R_SO_HEADER.ACCOUNT_ID, --账户ID
                                            REC.SUPPLIER_ITEM_NUM, --产品编码\
                                            TO_CHAR(V_CURR_DATE,
                                                    'yyyymmdd'), --单据日期 update by wangc 2015-6-23
                                           -- TO_CHAR(R_SO_HEADER.SO_DATE,
                                           --         'yyyymmdd'), --单据日期
                                            V_PRICE_LIST_ID, --价格列表ID
                                            R_SO_HEADER.ENTITY_ID); --业务主体ID
        IF V_PRICE IS NULL THEN
          P_ERR_MSG := '账号[' || R_SO_HEADER.ACCOUNT_CODE || ',' || R_SO_HEADER.ACCOUNT_ID || '],产品编码[' ||
                       REC.SUPPLIER_ITEM_NUM || '],价格列表ID[' ||
                       V_PRICE_LIST_ID || '],主体ID[' || R_SO_HEADER.ENTITY_ID ||
                       ']，获取不到不含税价格，请检查产品不含税价格配置！';
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
        END IF;
      EXCEPTION
        WHEN OTHERS THEN
          P_ERR_MSG := 'PKG_BD_PRICE.F_GET_PRICE 获取产品[' || REC.SUPPLIER_ITEM_NUM || ']不含税价格发生异常。单据[' ||
                       R_SO_HEADER.SO_NUM || '],账户[' || R_SO_HEADER.ACCOUNT_CODE || ',' || R_SO_HEADER.ACCOUNT_ID || '],日期[' || 
                       TO_CHAR(V_CURR_DATE,'yyyymmdd') || '],价格列表[' || V_PRICE_LIST_ID || '],主体ID[' ||
                       R_SO_HEADER.ENTITY_ID || ']';
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      END;
    
      INSERT INTO INTF_CUX_ICP_ORDER_REQ_LINES
        (ID, --
         SOURCE_HEADER_ID, --来源头ID
         REQ_LINE_NUM, --行号
         --SUPPLIER_ITEM_ID, --供方信息物料编码ID
         SUPPLIER_ITEM_NUM, --供方物料编码
         --REQUIRE_ITEM_ID, --需方信息物料编码ID
         REQUIRE_ITEM_NUM, --需方物料编码
         PRIMARY_UNIT_OF_MEASURE, --单位
         REQUEST_QUANTITY, --需求数量
         NEED_DATE, --需求日期
         UNIT_PRICE, --不含税单价
         SOURCE_HEADER, --来源头信息
         SOURCE_LINE, --来源行号
         COMMENTS, --行备注
         HEADERS_ID --关联交易order Headers表的主键
         )
      VALUES
        (S_CUX_ICP_ORDER_REQ_LINES.NEXTVAL, --
         REC.SOURCE_HEADER_ID, --来源头ID
         REC.REQ_LINE_NUM, --行号
         --REC.SUPPLIER_ITEM_ID, --供方信息物料编码ID
         REC.SUPPLIER_ITEM_NUM, --供方物料编码
         --REC.REQUIRE_ITEM_ID, --需方信息物料编码ID
         REC.REQUIRE_ITEM_NUM, --需方物料编码
         REC.PRIMARY_UNIT_OF_MEASURE, --单位
         REC.REQUEST_QUANTITY, --需求数量
         R_SO_HEADER.SETTLE_DATE, --需求日期  取结算日期
         V_PRICE,--edit by chen.wj 20150512 曾详胜要求将保留小数点2位去掉，按照取价函数取出来多少是多少，不再加工
         /*ROUND(V_PRICE, 2), -- ROUND(REC.UNIT_PRICE, 2), --V_PRICE, --不含税单价 --REC.UNIT_PRICE, -- */
         REC.SOUREC_HEADER, --来源头信息
         REC.SOURCE_LINE, --来源行号
         REC.COMMENTS, --行备注
         REC.HEADER_ID --关联交易order Headers表的主键
         );
    END LOOP;
  
    P_TABLE_ACTION_LOG('INTF_CUX_ICP_ORDER_REQ_HEADERS', --操作表名称
                       '销售单生成关联订单', --操作说明
                       R_SO_HEADER.SO_NUM, --关键主键
                       0, --是否出错，1出错，0未出错
                       '' --错误信息
                       );
  EXCEPTION
    WHEN OTHERS THEN
      --ROLLBACK;
      P_RESULT  := -1;
      P_ERR_MSG := '销售单据头[ID：' || P_SO_HEADER_ID || ']生成关联订单出错，原因：' ||
                   P_ERR_MSG || SQLERRM;
      P_TABLE_ACTION_LOG('INTF_CUX_ICP_ORDER_REQ_HEADERS', --操作表名称
                         '销售单生成关联订单', --操作说明
                         R_SO_HEADER.SO_NUM, --关键主键
                         1, --是否出错，1出错，0未出错
                         P_ERR_MSG --错误信息
                         );
      --RAISE_APPLICATION_ERROR(-20123, P_ERR_MSG, FALSE);
  END;
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-07-22
  *     创建者：xiongpl
  *   功能说明：跨事业部关联订单，如中央内销销售给热水内销，两内销间关联订单
  */
  -------------------------------------------------------------------------------  
  PROCEDURE P_SO_TO_RT_ORDER_ENTITY(P_SO_HEADER_ID IN T_SO_HEADER.SO_HEADER_ID%TYPE, --销售单头id
                             P_RESULT       IN OUT NUMBER, --返回错误ID
                             P_ERR_MSG      IN OUT VARCHAR2 --返回错误信息
                             ) AS
    --PRAGMA AUTONOMOUS_TRANSACTION; --自治事务
    --销售单据头
    CURSOR C_SO_HEADER IS
      SELECT * FROM T_SO_HEADER WHERE SO_HEADER_ID = P_SO_HEADER_ID;
    R_SO_HEADER C_SO_HEADER%ROWTYPE;
  
    --关联定单头接口表
    R_RT_HEADERS INTF_CUX_ICP_ORDER_REQ_HEADERS%ROWTYPE;
  
    V_ID INTF_CUX_ICP_ORDER_REQ_HEADERS.ID%TYPE;
    --固定变量
    V_PROC_GROUP_ID      INTF_CUX_ICP_ORDER_REQ_HEADERS.PROC_GROUP_ID%TYPE; --例程集ID    NUMBER
    V_SUPPLIER_SYSTEM    INTF_CUX_ICP_ORDER_REQ_HEADERS.SUPPLIER_SYSTEM%TYPE; --供方来源系统VARCHAR2(30)
    V_REQUIREMENT_SYSTEM INTF_CUX_ICP_ORDER_REQ_HEADERS.REQUIREMENT_SYSTEM%TYPE; --需方来源系统VARCHAR2(30)
    V_SOURCE_ORDERS_TYPE INTF_CUX_ICP_ORDER_REQ_HEADERS.SOURCE_ORDERS_TYPE%TYPE; --来源单据类型VARCHAR2(100)01中转单/02财务单
    V_STATUS INTF_CUX_ICP_ORDER_REQ_HEADERS.STATUS%TYPE; --状态：N待发送；P已发送；S成功VARCHAR2(100)
    --根据条件改变变量
    V_SUPPLIER_ORG_ID INTF_CUX_ICP_ORDER_REQ_HEADERS.SUPPLIER_ORG_ID%TYPE; --SUPPLIER_ORG_ID供方OU ID
    V_SUPPLIER_ORG    INTF_CUX_ICP_ORDER_REQ_HEADERS.SUPPLIER_ORG%TYPE; --SUPPLIER_ORG供方OU
    V_S_ORDER_TYPE_ID INTF_CUX_ICP_ORDER_REQ_HEADERS.S_ORDER_TYPE_ID%TYPE; --S_ORDER_TYPE_ID销售订单类型ID
    V_S_ORDER_TYPE    INTF_CUX_ICP_ORDER_REQ_HEADERS.S_ORDER_TYPE%TYPE; --S_ORDER_TYPE销售订单类型
  
    V_REQUIREMENT_ORG_ID INTF_CUX_ICP_ORDER_REQ_HEADERS.REQUIREMENT_ORG_ID%TYPE; --REQUIREMENT_ORG_ID需方OU ID
    V_REQUIREMENT_ORG    INTF_CUX_ICP_ORDER_REQ_HEADERS.REQUIREMENT_ORG%TYPE; --REQUIREMENT_ORG需方OU
    V_SOURCE_CODE        INTF_CUX_ICP_ORDER_REQ_HEADERS.SOURCE_CODE%TYPE; --SOURCE_CODE
    V_SOURCE_ORDERS      INTF_CUX_ICP_ORDER_REQ_HEADERS.SOURCE_ORDERS%TYPE; --SOURCE_ORDERS来源单据
  
    V_RECEIVE_ORG_ID  INTF_CUX_ICP_ORDER_REQ_HEADERS.RECEIVE_ORG_ID%TYPE; -- RECEIVE_ORG_ID 接收组织ID
    V_RECEIVE_ORG     INTF_CUX_ICP_ORDER_REQ_HEADERS.RECEIVE_ORG%TYPE; -- RECEIVE_ORG 接收组织
    V_SHIPPING_ORG_ID INTF_CUX_ICP_ORDER_REQ_HEADERS.SHIPPING_ORG_ID%TYPE; -- SHIPPING_ORG_ID 发运组织ID
    V_SHIPPING_ORG    INTF_CUX_ICP_ORDER_REQ_HEADERS.SHIPPING_ORG%TYPE; -- SHIPPING_ORG 发运组织
  
    V_SO_CNT NUMBER; --查询记录条数
    --关联交易模式 chen.wj
    V_SO_TRX_MODE VARCHAR2(10);
    V_TRX_RATE NUMBER;  --事业部采购税率
  
    --采购方
    V_TARGET_ENTITY_ID  NUMBER; --采购方主体ID
    V_PRICE_LIST_ID VARCHAR2(100); --价格列表id
    V_VENDOR_CODE   VARCHAR2(100); --供应商编码
    V_PRICE         NUMBER; --不含税价格
  
    V_PULL_MODE NUMBER;
    
    ----------add by wangc 2015-6-23--------
    --当前日期 
    V_CURR_DATE DATE;
    --日期格式 
    V_DATA_FORMAT  VARCHAR2(10) := 'YYYY-MM-DD';
     --当前时间
    V_CURR_TIME DATE := SYSDATE;
    -----------------------------------------
  BEGIN
    --初始返回值
    P_RESULT  := PKG_SO_PUB.V_RESULT;
    P_ERR_MSG := PKG_SO_PUB.V_SUCCESS;
  
    V_PROC_GROUP_ID := 846; --1  843 A01 关联订单  ORDERS  同步生成PO、SO 2013-11-01 ;[846 A02 单边采购 单边关联订单(采购订单)  edited by zhoujg3]
    --V_SUPPLIER_SYSTEM := 'GERP';
    --V_REQUIREMENT_SYSTEM := 'GERP';
    V_SOURCE_ORDERS_TYPE := V_SOURCE_ORDERS_TYPE_G; --01中转单/02财务单/03财务单关联交易单边模式
    V_STATUS := 'N';
  
    --获取销售单据头数据
    OPEN C_SO_HEADER;
    FETCH C_SO_HEADER
      INTO R_SO_HEADER;
    CLOSE C_SO_HEADER;
  
    --防重复检查
    SELECT COUNT(*)
      INTO V_SO_CNT
      FROM INTF_CUX_ICP_ORDER_REQ_HEADERS
     WHERE SOURCE_ORDERS = 'G'||R_SO_HEADER.SO_NUM
       AND SOURCE_ORDERS_TYPE = V_SOURCE_ORDERS_TYPE_G;
  
    IF V_SO_CNT > 0 THEN
      P_ERR_MSG := '销售单据[单据号：G' || R_SO_HEADER.SO_NUM ||
                   ']已生成关联订单[INTF_CUX_ICP_ORDER_REQ_HEADERS]表记录';
      RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
    END IF;
    /*
                                        正向销售   反向销售
    SUPPLIER_ORG_ID NUMBER  供方OU ID     工厂      内销
    SUPPLIER_ORG  VARCHAR2(100) 供方OU    工厂      内销
    REQUIREMENT_ORG_ID  NUMBER  需方OU ID 内销      工厂
    REQUIREMENT_ORG VARCHAR2(100) 需方OU  内销      工厂
    RECEIVE_ORG_ID  NUMBER  接收组织ID    内销      工厂
    RECEIVE_ORG VARCHAR2(100) 接收组织    内销      工厂
    SHIPPING_ORG_ID NUMBER  发运组织ID    工厂      内销
    SHIPPING_ORG  VARCHAR2(100) 发运组织  工厂      内销
    */
    --退货方式：1-推式，2-拉式源单退回，3-拉式反向销售  
    IF NVL(R_SO_HEADER.RETURN_MODE, '1') <> '3' THEN
 
      --供方：OU ID 销售方内销公司
      V_SUPPLIER_ORG_ID := R_SO_HEADER.ERP_OU_ID;
      V_SUPPLIER_ORG    := R_SO_HEADER.ERP_OU_NAME;
      --供方：发运库存组织
      BEGIN
        -- -1错误,0非拉式,1销售,2红冲,3源单退回,4反向销售,5源单退货红冲，6拉式其他单据类型
        /*
        'TRX001'; --推式成品销售
        'TRX002'; --推式销售结算
        'TRX003'; --拉式成品销售
        'TRX004'; --拉式源单退回
        'TRX005'; --拉式反向销售
        */          
        V_PULL_MODE := PKG_SO_PUB.F_PULL_MODE(R_SO_HEADER.SO_NUM);
        SELECT DECODE(V_PULL_MODE,
                      1,
                      PKG_SO_PUB.V_SO_TRX_MODE_003,
                      2,
                      PKG_SO_PUB.V_SO_TRX_MODE_004,
                      3,
                      PKG_SO_PUB.V_SO_TRX_MODE_004,
                      4,
                      PKG_SO_PUB.V_SO_TRX_MODE_005,
                      5,
                      PKG_SO_PUB.V_SO_TRX_MODE_003,
                      V_PULL_MODE)
          INTO V_SO_TRX_MODE
          FROM DUAL;
        IF V_SO_TRX_MODE = PKG_SO_PUB.V_SO_TRX_MODE_005 THEN
          P_ERR_MSG := '此销售单[ID：' || P_SO_HEADER_ID || ']不允许做反向销售业务' ;
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
        ELSIF V_SO_TRX_MODE ='0' THEN --推式
          V_SHIPPING_ORG_ID := R_SO_HEADER.ERP_SUBINV_ID;
          V_SHIPPING_ORG := R_SO_HEADER.Erp_Subinv_Code;
        ELSE   --拉式
          SELECT ERP_SUBINV_ID, --库存组织
                 ERP_SUBINV_CODE --库存组织编码
            INTO V_SHIPPING_ORG_ID, V_SHIPPING_ORG
            FROM T_SO_SUPPLIER_REQUIREMENT T
           WHERE T.ENTITY_ID = R_SO_HEADER.ENTITY_ID
             AND T.REQUIREMENT_OU_ID = R_SO_HEADER.ERP_OU_ID
             AND T.SUPPLIER_OU_ID = R_SO_HEADER.FACTORY_OU_ID
             AND T.TRADE_MODE_CODE = V_SO_TRX_MODE;
        END IF;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          P_ERR_MSG := '工厂OU ID[' || R_SO_HEADER.FACTORY_OU_ID || '],主体ID[' ||
                       R_SO_HEADER.ENTITY_ID || '],关联交易模式编码[' ||
                       V_SO_TRX_MODE ||
                       '],T_SO_SUPPLIER_REQUIREMENT表未设置对应的ERP OU！';
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
        WHEN OTHERS THEN
          P_ERR_MSG := '工厂OU ID[' || R_SO_HEADER.FACTORY_OU_ID || '],主体ID[' ||
                       R_SO_HEADER.ENTITY_ID || '],关联交易模式编码[' ||
                       V_SO_TRX_MODE ||
                       '],T_SO_SUPPLIER_REQUIREMENT表未设置对应的ERP OU！' ||
                       SQLERRM;
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      END;     
      --需方：(采购方内销公司)OU、库存组织
      BEGIN
         --根据供方业务主体、供方OU、需方客户 获取需方信息与供应商； 
         SELECT REQUIREMENT_OU_ID,REQUIREMENT_OU_NAME,
                 REQUIREMENT_ORGANIZATION_ID, --库存组织
                 REQUIREMENT_ORGANIZATION_CODE, --库存组织编码
                 REQUIREMENT_ENTITY_ID,
                 SUPPLIER_VENDOR_CODE,
                 NVL(TRX_RATE,0) TRX_RATE
            INTO V_REQUIREMENT_ORG_ID, V_REQUIREMENT_ORG,
                 V_RECEIVE_ORG_ID,V_RECEIVE_ORG,V_TARGET_ENTITY_ID,
                 V_VENDOR_CODE,V_TRX_RATE
            FROM T_SO_SUPPLIER_REQUIRE_ENTITY T
           WHERE T.SUPPLIER_ENTITY_ID = R_SO_HEADER.Entity_Id 
              and T.SUPPLIER_OU_ID=R_SO_HEADER.ERP_OU_ID
              and T.REQUIREMENT_CUSTOMER_ID=R_SO_HEADER.CUSTOMER_ID;
         V_TRX_RATE := (V_TRX_RATE/100) + 1;  --折算后税率          
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          P_ERR_MSG := '事业部客户[' || R_SO_HEADER.Customer_Name || ']在供需关系T_SO_SUPPLIER_REQUIRE_ENTITY中未进行配置！';
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
        WHEN OTHERS THEN
          P_ERR_MSG := '事业部客户[' || R_SO_HEADER.Customer_Name || ']在供需关系T_SO_SUPPLIER_REQUIRE_ENTITY中未进行配置！'||SQLERRM;
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      END;     
    
    END IF;
    V_SOURCE_ORDERS := 'G'||R_SO_HEADER.SO_NUM;
    /*，取序列*/
    V_ID := S_CUX_ICP_ORDER_REQ_HEADERS.NEXTVAL;
  
    INSERT INTO INTF_CUX_ICP_ORDER_REQ_HEADERS
      (ID, --
       SOURCE_HEADER_ID, --来源头ID
       PROC_GROUP_ID, --例程集ID
       SUPPLIER_SYSTEM, --供方来源系统
       SUPPLIER_ORG_ID, --供方OU ID
       SUPPLIER_ORG, --供方OU
       S_ORDER_TYPE_ID, --销售订单类型ID
       S_ORDER_TYPE, --销售订单类型
       REQUIREMENT_SYSTEM, --需方来源系统
       REQUIREMENT_ORG_ID, --需方OU ID
       REQUIREMENT_ORG, --需方OU
       SOURCE_CODE, --
       SOURCE_ORDERS, --来源单据
       SOURCE_ORDERS_TYPE, --来源单据类型
       RECEIVE_ORG_ID, --接收组织ID
       RECEIVE_ORG, --接收组织
       SHIPPING_ORG_ID, --发运组织ID
       SHIPPING_ORG, --发运组织
       COMMENTS, --备注信息
       STATUS, --状态：N待发送；P已发送；S成功
       --POST_DATE, --提交请求时间
       RETRANSMISSION_NUMBER, --重发次数
       ENTITY_ID --主体ID
       )
    VALUES
      (V_ID, --ID
       R_SO_HEADER.SO_HEADER_ID, --SOURCE_HEADER_ID来源头ID
       V_PROC_GROUP_ID, --PROC_GROUP_ID例程集ID
       V_SUPPLIER_SYSTEM, --SUPPLIER_SYSTEM供方来源系统
       V_SUPPLIER_ORG_ID, -- SUPPLIER_ORG_ID 供方OU ID
       V_SUPPLIER_ORG, -- SUPPLIER_ORG 供方OU
       V_S_ORDER_TYPE_ID, -- S_ORDER_TYPE_ID 销售订单类型ID
       V_S_ORDER_TYPE, -- S_ORDER_TYPE 销售订单类型
       V_REQUIREMENT_SYSTEM, --REQUIREMENT_SYSTEM需方来源系统
       V_REQUIREMENT_ORG_ID, -- REQUIREMENT_ORG_ID 需方OU ID
       V_REQUIREMENT_ORG, -- REQUIREMENT_ORG 需方OU
       V_SOURCE_CODE, -- SOURCE_CODE
       V_SOURCE_ORDERS, -- SOURCE_ORDERS 来源单据
       V_SOURCE_ORDERS_TYPE, --SOURCE_ORDERS_TYPE来源单据类型
       V_RECEIVE_ORG_ID, -- RECEIVE_ORG_ID 接收组织ID
       V_RECEIVE_ORG, -- RECEIVE_ORG 接收组织
       V_SHIPPING_ORG_ID, -- SHIPPING_ORG_ID 发运组织ID
       V_SHIPPING_ORG, -- SHIPPING_ORG 发运组织
       NULL, --COMMENTS备注信息
       V_STATUS, --STATUS状态：N待发送；P已发送；S成功
       --SYSDATE, --POST_DATE提交请求时间
       0, --RETRANSMISSION_NUMBER重发次数
       R_SO_HEADER.ENTITY_ID --ENTITY_ID主体ID7
       );
  
    FOR REC IN (SELECT LD.SO_HEADER_ID     AS SOURCE_HEADER_ID,
                       LD.SO_LINE_DETAIL_NUM      AS REQ_LINE_NUM,
                       LD.COMPONENT_ID          AS SUPPLIER_ITEM_ID,
                       LD.COMPONENT_CODE        AS SUPPLIER_ITEM_NUM,
                       LD.COMPONENT_NAME        AS SUPPLIER_ITEM_NAME,
                       LD.COMPONENT_ID          AS REQUIRE_ITEM_ID,
                       LD.COMPONENT_CODE        AS REQUIRE_ITEM_NUM,
                       LD.COMPONENT_UOM         AS PRIMARY_UNIT_OF_MEASURE,
                       LD.COMPONENT_QTY         AS REQUEST_QUANTITY,
                       A.ITEM_SETTLE_PRICE  AS UNIT_PRICE,--取结算单价（套机码价格）
                       --A.ITEM_PRICE       AS UNIT_PRICE,
                       'G'||R_SO_HEADER.SO_NUM AS SOUREC_HEADER,
                       LD.SO_LINE_DETAIL_ID       AS SOURCE_LINE,
                       A.REMARK           AS COMMENTS,
                       V_ID               AS HEADER_ID,
                       LD.ITEM_CODE       AS LINE_ITEM_CODE,--套机码
                       LD.COMPONENT_PRICE AS DETAIL_UNIT_PRICE --散件价格
                  FROM T_SO_LINE A, T_SO_LINE_DETAIL LD 
                 WHERE A.SO_HEADER_ID = P_SO_HEADER_ID AND A.SO_LINE_ID = LD.SO_LINE_ID
                 ORDER BY LD.SO_LINE_DETAIL_NUM) LOOP
    ---------add by wangc 2015-6-23----------
    --取当前日期
    V_CURR_DATE := TO_DATE(TO_CHAR(V_CURR_TIME, V_DATA_FORMAT),
                           V_DATA_FORMAT);
    -----------------------------------------
     --套机码也是散件，价格取单据行价格,
      IF REC.SUPPLIER_ITEM_NUM = REC.LINE_ITEM_CODE THEN 
         REC.DETAIL_UNIT_PRICE := REC.UNIT_PRICE;
      ELSE
         --套机下单，散件价格检查标记Y
         UPDATE INTF_CUX_ICP_ORDER_REQ_HEADERS H
            SET H.PRICE_CHECK_FLAG = 'Y'
          WHERE H.ID = REC.HEADER_ID;
         --散件取价，可以为空
         REC.DETAIL_UNIT_PRICE := PKG_BD_PRICE.F_GET_PRICE( R_SO_HEADER.ACCOUNT_ID,
                                          REC.SUPPLIER_ITEM_NUM,
                                          TO_CHAR(SYSDATE,'YYYYMMDD'),
                                          NULL,
                                          R_SO_HEADER.ENTITY_ID); 
      END IF;
      
      --编码汇总，已存在则累加数量
      SELECT COUNT(*)
        INTO V_SO_CNT
        FROM INTF_CUX_ICP_ORDER_REQ_LINES T
       WHERE T.SOURCE_HEADER_ID = P_SO_HEADER_ID
         AND T.SUPPLIER_ITEM_NUM = REC.SUPPLIER_ITEM_NUM
         AND T.HEADERS_ID = REC.HEADER_ID;
      
      IF V_SO_CNT > 0 THEN
        UPDATE INTF_CUX_ICP_ORDER_REQ_LINES T
           SET T.REQUEST_QUANTITY = (NVL(REQUEST_QUANTITY, 0) +
                                    REC.REQUEST_QUANTITY)
         WHERE T.SOURCE_HEADER_ID = P_SO_HEADER_ID
           AND T.SUPPLIER_ITEM_NUM = REC.SUPPLIER_ITEM_NUM
           AND T.HEADERS_ID = REC.HEADER_ID;
      ELSE
      
        INSERT INTO INTF_CUX_ICP_ORDER_REQ_LINES
          (ID, --
           SOURCE_HEADER_ID, --来源头ID
           REQ_LINE_NUM, --行号
           --SUPPLIER_ITEM_ID, --供方信息物料编码ID
           SUPPLIER_ITEM_NUM, --供方物料编码
           --REQUIRE_ITEM_ID, --需方信息物料编码ID
           REQUIRE_ITEM_NUM, --需方物料编码
           PRIMARY_UNIT_OF_MEASURE, --单位
           REQUEST_QUANTITY, --需求数量
           NEED_DATE, --需求日期
           UNIT_PRICE, --不含税单价
           SOURCE_HEADER, --来源头信息
           SOURCE_LINE, --来源行号
           COMMENTS, --行备注
           HEADERS_ID, --关联交易order Headers表的主键
           ITEM_PRICE --含税单价
           )
        VALUES
          (S_CUX_ICP_ORDER_REQ_LINES.NEXTVAL, --
           REC.SOURCE_HEADER_ID, --来源头ID
           REC.REQ_LINE_NUM, --行号
           --REC.SUPPLIER_ITEM_ID, --供方信息物料编码ID
           REC.SUPPLIER_ITEM_NUM, --供方物料编码
           --REC.REQUIRE_ITEM_ID, --需方信息物料编码ID
           REC.REQUIRE_ITEM_NUM, --需方物料编码
           REC.PRIMARY_UNIT_OF_MEASURE, --单位
           REC.REQUEST_QUANTITY, --需求数量
           R_SO_HEADER.SETTLE_DATE, --需求日期  取结算日期
           REC.DETAIL_UNIT_PRICE / V_TRX_RATE, -- 2016-3-9号新增除以税率
           /*ROUND(V_PRICE, 2), -- ROUND(REC.UNIT_PRICE, 2), --V_PRICE, --不含税单价 --REC.UNIT_PRICE, -- */
           REC.SOUREC_HEADER, --来源头信息
           REC.SOURCE_LINE, --来源行号
           REC.COMMENTS, --行备注
           REC.HEADER_ID, --关联交易order Headers表的主键
           REC.DETAIL_UNIT_PRICE
           );
      END IF;
    END LOOP;
  
    P_TABLE_ACTION_LOG('INTF_CUX_ICP_ORDER_REQ_HEADERS', --操作表名称
                       '销售单生成关联订单', --操作说明
                       'G'||R_SO_HEADER.SO_NUM, --关键主键
                       0, --是否出错，1出错，0未出错
                       '' --错误信息
                       );
  EXCEPTION
    WHEN OTHERS THEN
      --ROLLBACK;
      P_RESULT  := -1;
      P_ERR_MSG := '销售单据头[ID：' || P_SO_HEADER_ID || ']生成关联订单出错，原因：' ||
                   P_ERR_MSG || SQLERRM;
      P_TABLE_ACTION_LOG('INTF_CUX_ICP_ORDER_REQ_HEADERS', --操作表名称
                         '销售单生成关联订单', --操作说明
                         'G'||R_SO_HEADER.SO_NUM, --关键主键
                         1, --是否出错，1出错，0未出错
                         P_ERR_MSG --错误信息
                         );
      --RAISE_APPLICATION_ERROR(-20123, P_ERR_MSG, FALSE);
  END;  
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-01-22
  *     创建者：陈武杰
  *   功能说明：物流订单
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_TO_LG_ORDER(P_SO_HEADER_ID IN T_SO_HEADER.SO_HEADER_ID%TYPE, --销售单头id
                             P_STATUS       IN VARCHAR2, --状态：N待发送；P已发送；S成功，如果前面有关联订单，需要将状态传空值，这样才可以实现串行
                             P_RESULT       IN OUT NUMBER, --返回错误ID
                             P_ERR_MSG      IN OUT VARCHAR2 --返回错误信息
                             ) AS
    --销售单据头
    CURSOR C_SO_HEADER IS
      SELECT * FROM T_SO_HEADER WHERE SO_HEADER_ID = P_SO_HEADER_ID;
    R_SO_HEADER C_SO_HEADER%ROWTYPE;
  
    --物流订单头表
    R_LG_ORDER INTF_CUX_ICP_LOGIST_REQ_HEADER%ROWTYPE;
  
    --物流订单行表
    R_LG_ORDER_LINE INTF_CUX_ICP_LOGIST_REQ_LINES%ROWTYPE;
  
    --库存组织编码
    V_INV_ORG_ZCODE T_INV_ORGANIZATION.ORGANIZATION_CODE%TYPE;
  
    --来源子库编码（仓库编码）
    V_SRC_INV_CODE T_INV_INVENTORIES.INVENTORY_CODE%TYPE;
  
    --目标子库编码
    V_TARGET_INV_CODE T_INV_INVENTORIES.INVENTORY_CODE%TYPE;
  
    --接收子库
    V_RECEIVE_SUBINV INTF_CUX_ICP_LOGIST_REQ_LINES.RECEIVE_SUBINV%TYPE;
    
    --取的中间仓   chenzh 2015/05/28
    V_MIDDLE_INV_CODE T_INV_INVENTORIES.INVENTORY_CODE%TYPE;
  
    --仓库ID、编码、名称
    V_INV_ID   T_INV_INVENTORIES.INVENTORY_ID%TYPE;
    V_INV_CODE T_INV_INVENTORIES.INVENTORY_CODE%TYPE;
    V_INV_NAME T_INV_INVENTORIES.INVENTORY_NAME%TYPE;
  
    --RETURN_MODE VARCHAR2(2) 退货方式：1-推式，2-拉式源单退回，3-拉式反向销售
    V_RETURN_MODE T_SO_HEADER.RETURN_MODE%TYPE;
  
    V_COUNT NUMBER;
    --关联交易模式 chen.wj
    V_SO_TRX_MODE VARCHAR2(10);
    
    --是否启用关联交易仓库
    V_SO_ICP_INV_ENABLE VARCHAR2(10);
  
    V_PULL_MODE NUMBER;
  
  BEGIN
    --初始返回值
    P_RESULT  := PKG_SO_PUB.V_RESULT;
    P_ERR_MSG := PKG_SO_PUB.V_SUCCESS;
  
    --获取销售单头信息
    OPEN C_SO_HEADER;
    FETCH C_SO_HEADER
      INTO R_SO_HEADER;
    CLOSE C_SO_HEADER;
    --退货方式：1-推式，2-拉式源单退回，3-拉式反向销售
    V_RETURN_MODE := NVL(R_SO_HEADER.RETURN_MODE, '1'); --默认1-推式
  
    --V_PULL_MODE := PKG_SO_PUB.F_PULL_MODE(R_SO_HEADER.SO_NUM); -- -1错误,0非拉式,1销售,2红冲,3源单退回,4反向销售,5源单退货红冲，6拉式其他单据类型
  
    --判断是否重复生成物流
    SELECT COUNT(*)
      INTO V_COUNT
      FROM INTF_CUX_ICP_LOGIST_REQ_HEADER
     WHERE (REQUIREMENT_ORDER_TYPE = V_SOURCE_ORDERS_TYPE OR
           SUPPLIER_ORDER_TYPE = V_SOURCE_ORDERS_TYPE)
       AND REQUIREMENT_ORDER_NUM = R_SO_HEADER.SO_NUM;
    IF V_COUNT > 0 THEN
      P_ERR_MSG := '销售单据[单据号：' || R_SO_HEADER.SO_NUM ||
                   ']已生成物流订单[INTF_CUX_ICP_LOGIST_REQ_HEADER]表记录';
      RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
    END IF;
  
    --add by chen.wj 20150206
    -- -1错误,0非拉式,1销售,2红冲,3源单退回,4反向销售,5源单退货红冲，6拉式其他单据类型
    /*
    'TRX001'; --推式成品销售
    'TRX002'; --推式销售结算
    'TRX003'; --拉式成品销售
    'TRX004'; --拉式源单退回
    'TRX005'; --拉式反向销售
    */
    V_PULL_MODE := PKG_SO_PUB.F_PULL_MODE(R_SO_HEADER.SO_NUM);
  
    --NUMBER
    R_LG_ORDER.ID := S_CUX_ICP_LOGIST_REQ_HEADER.NEXTVAL;
  
    --NUMBER 来源头ID
    R_LG_ORDER.SOURCE_HEADER_ID := R_SO_HEADER.SO_HEADER_ID;
  
    --NUMBER 例程集ID
    --退货方式：1-推式，2-拉式源单退回，3-拉式反向销售
  
    -- '1001'; --销售单
    --850 B01 同步物流
    --拉式销售单、退货红冲单、反向销售物流订单用B01，其他用B02
    IF (R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE IN
       (PKG_SO_PUB.V_BIZ_SRC_BILL_SO, PKG_SO_PUB.V_BIZ_SRC_BILL_RETURN_RED)) OR
       V_RETURN_MODE = '3' THEN
      R_LG_ORDER.PROC_GROUP_ID := 850; --.850 B01 同步物流
      R_LG_ORDER.GROUP_CODE    := 'B01';
    ELSE
      R_LG_ORDER.PROC_GROUP_ID := 853; --853 B02 同步物流退回;
      R_LG_ORDER.GROUP_CODE    := 'B02';
    END IF;
  
    --VARCHAR2(30) 需方系统
    R_LG_ORDER.REQUIREMENT_SYSTEM := 'GERP';
  
    --VARCHAR2(100) 需方来源单据
    R_LG_ORDER.REQUIREMENT_ORDER_NUM := R_SO_HEADER.SO_NUM;
  
    --VARCHAR2(100) 需方来源单据类型
    R_LG_ORDER.REQUIREMENT_ORDER_TYPE := V_SOURCE_ORDERS_TYPE; --01中转单 / 02财务单;
    /*
                                                    正向  红冲  源单  反向
    REQUIREMENT_ORG_ID  NUMBER  需方OU ID           内销  内销  内销  工厂
    RECEIVE_INV_ORG_ID  NUMBER  接收库存组织ID      内销  内销  内销  工厂
    SUPPLIER_ORG_ID NUMBER  供方OU ID               工厂  工厂  工厂  内销
    SUPPLIER_INV_ORG_ID NUMBER  供方发运库存组织ID  工厂  工厂  工厂  内销
        */
    --反向销售，需方为工厂，工厂OU，工厂库存组织，工厂收货仓
    IF R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE =
       PKG_SO_PUB.V_BIZ_SRC_BILL_RETURN AND V_RETURN_MODE = '3' THEN
      --VARCHAR2(100) 需方OU
      R_LG_ORDER.REQUIREMENT_ORG    := R_SO_HEADER.FACTORY_OU_NAME;
      R_LG_ORDER.REQUIREMENT_ORG_ID := R_SO_HEADER.FACTORY_OU_ID;
    
      R_LG_ORDER.RECEIVE_INV_ORG_ID := R_SO_HEADER.ERP_SUBINV_ID; --接收库存组织ID-->RECEIVE_INV_ORG_ID
      R_LG_ORDER.RECEIVE_INV_ORG    := R_SO_HEADER.ERP_SUBINV_CODE; --接收库存组织-->RECEIVE_INV_ORG
      /*
      临时解决源单库存组织不对问题
      */
      /*SELECT A.ORGANIZATION_ID, A.ORGANIZATION_CODE
             INTO R_LG_ORDER.RECEIVE_INV_ORG_ID,R_LG_ORDER.RECEIVE_INV_ORG
       FROM CIMS.T_INV_INVENTORIES A, CIMS.T_INV_ORGANIZATION B
      WHERE A.ENTITY_ID = B.ENTITY_ID
        AND B.ORGANIZATION_ID = A.ORGANIZATION_ID
        AND B.ORGANIZATION_CODE = A.ORGANIZATION_CODE
        AND A.INVENTORY_CODE = R_SO_HEADER.CONSIGNEE_INV_CODE
        AND a.entity_id=R_SO_HEADER.Entity_Id;*/
    
      --供方
      R_LG_ORDER.SUPPLIER_ORG    := R_SO_HEADER.ERP_OU_NAME; --供方OU-->SUPPLIER_ORG FACTORY_OU_NAME
      R_LG_ORDER.SUPPLIER_ORG_ID := R_SO_HEADER.ERP_OU_ID; --供方OU ID-->SUPPLIER_ORG_ID FACTORY_OU_ID
    
      BEGIN
        --需方工厂，找供方内销
        SELECT A.SUPPLIER_SUBINV_ID,
               A.SUPPLIER_SUBINV_CODE,
               A.SUPPLIER_SUBINVENTORY_CODE,
               A.SUPPLIER_SUBINVENTORY_CODE AS SUPPLIER_SUBINVENTORY_CODE1
          INTO R_LG_ORDER.SUPPLIER_INV_ORG_ID, --供方发运库存组织ID-->SUPPLIER_INV_ORG_ID
               R_LG_ORDER.SUPPLIER_INV_ORG, --供方发运库存组织-->SUPPLIER_INV_ORG
               V_SRC_INV_CODE, --来源子库编码（仓库编码） 供方内销正品仓
               V_TARGET_INV_CODE --目标子库编码 供方内销正品仓
          FROM T_SO_SUPPLIER_REQUIREMENT A
         WHERE A.TRADE_MODE_CODE = PKG_SO_PUB.V_SO_TRX_MODE_005
           AND A.REQUIREMENT_OU_ID = R_SO_HEADER.FACTORY_OU_ID
           AND A.SUPPLIER_OU_ID = R_SO_HEADER.ERP_OU_ID;
      EXCEPTION
        WHEN OTHERS THEN
          P_ERR_MSG := '需方工厂OU[' || R_SO_HEADER.FACTORY_OU_ID ||
                       ']查询[T_SO_SUPPLIER_REQUIREMENT]供方内销库存组织信息发生异常：' ||
                       SQLERRM;
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      END;
    
      --接收子库
      --V_RECEIVE_SUBINV := R_SO_HEADER.CONSIGNEE_INV_CODE; --需方工厂，正品仓
      V_RECEIVE_SUBINV := R_SO_HEADER.MIDDLE_INV_CODE; --需方工厂，中间仓
    
    ELSE
      /*供方为工厂，工厂OU，工厂库存组织，工厂中间仓
      供方工厂，找需方内销
      */
      IF R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE = PKG_SO_PUB.V_BIZ_SRC_BILL_SO THEN
        --正向销售
      
        --VARCHAR2(100) 需方OU
        R_LG_ORDER.REQUIREMENT_ORG    := R_SO_HEADER.ERP_OU_NAME;
        R_LG_ORDER.REQUIREMENT_ORG_ID := R_SO_HEADER.ERP_OU_ID;
        --通过内销OU找到销售库存组织
        BEGIN
          SELECT A.ERP_SUBINV_ID, A.ERP_SUBINV_CODE, A.SUBINVENTORY_CODE
            INTO R_LG_ORDER.RECEIVE_INV_ORG_ID,
                 R_LG_ORDER.RECEIVE_INV_ORG,
                 V_RECEIVE_SUBINV
            FROM T_SO_SUPPLIER_REQUIREMENT A
           WHERE A.TRADE_MODE_CODE = PKG_SO_PUB.V_SO_TRX_MODE_003
             AND A.REQUIREMENT_OU_ID = R_SO_HEADER.ERP_OU_ID
             AND A.SUPPLIER_OU_ID = R_SO_HEADER.FACTORY_OU_ID;
        EXCEPTION
          WHEN OTHERS THEN
            P_ERR_MSG := 'OU_ID[' || R_SO_HEADER.ERP_OU_ID || ']，主体ID[' ||
                         R_SO_HEADER.ENTITY_ID || ']查询库存组织信息发生异常：' ||
                         SQLERRM;
            RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
        END;
        --VARCHAR2(100) 供方OU
        R_LG_ORDER.SUPPLIER_ORG    := R_SO_HEADER.FACTORY_OU_NAME;
        R_LG_ORDER.SUPPLIER_ORG_ID := R_SO_HEADER.FACTORY_OU_ID;
        --直接从头表获取工厂库存组织
        R_LG_ORDER.SUPPLIER_INV_ORG_ID := R_SO_HEADER.ERP_SUBINV_ID; --供方发运库存组织ID-->SUPPLIER_INV_ORG_ID
        R_LG_ORDER.SUPPLIER_INV_ORG    := R_SO_HEADER.ERP_SUBINV_CODE; --供方发运库存组织-->SUPPLIER_INV_ORG
      
        V_SRC_INV_CODE    := R_SO_HEADER.MIDDLE_INV_CODE; --edit by chen.wj 20150313 R_SO_HEADER.SHIP_INV_CODE; --来源子库编码（仓库编码） 
        V_TARGET_INV_CODE := R_SO_HEADER.MIDDLE_INV_CODE; --目标子库编码 
        
        --内部关联交易客户，工厂卖营销的关联物流，来源仓是'内部关联交易客户的未结算仓'
        IF (NVL(R_SO_HEADER.ENTITY_CUST_FLAG,PKG_SO_PUB.V_NO) = PKG_SO_PUB.V_YES) THEN 
          V_SRC_INV_CODE := R_SO_HEADER.NOSETTLED_INVENTORY_CODE;
        END IF;
      ELSIF R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE =
            PKG_SO_PUB.V_BIZ_SRC_BILL_RETURN_RED THEN
        --退货红冲单与销售单类似，销售单取发货仓，退货红冲取收货仓
        --VARCHAR2(100) 需方OU
        R_LG_ORDER.REQUIREMENT_ORG    := R_SO_HEADER.ERP_OU_NAME;
        R_LG_ORDER.REQUIREMENT_ORG_ID := R_SO_HEADER.ERP_OU_ID;
        --通过内销OU找到销售库存组织
        BEGIN
          SELECT A.ERP_SUBINV_ID, A.ERP_SUBINV_CODE, A.SUBINVENTORY_CODE
            INTO R_LG_ORDER.RECEIVE_INV_ORG_ID,
                 R_LG_ORDER.RECEIVE_INV_ORG,
                 V_RECEIVE_SUBINV
            FROM T_SO_SUPPLIER_REQUIREMENT A
           WHERE A.TRADE_MODE_CODE = PKG_SO_PUB.V_SO_TRX_MODE_003
             AND A.REQUIREMENT_OU_ID = R_SO_HEADER.ERP_OU_ID
             AND A.SUPPLIER_OU_ID = R_SO_HEADER.FACTORY_OU_ID;
        EXCEPTION
          WHEN OTHERS THEN
            P_ERR_MSG := 'OU_ID[' || R_SO_HEADER.ERP_OU_ID || ']，主体ID[' ||
                         R_SO_HEADER.ENTITY_ID || ']查询库存组织信息发生异常：' ||
                         SQLERRM;
            RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
        END;
        --VARCHAR2(100) 供方OU
        R_LG_ORDER.SUPPLIER_ORG    := R_SO_HEADER.FACTORY_OU_NAME;
        R_LG_ORDER.SUPPLIER_ORG_ID := R_SO_HEADER.FACTORY_OU_ID;
        --直接从头表获取工厂库存组织
        R_LG_ORDER.SUPPLIER_INV_ORG_ID := R_SO_HEADER.ERP_SUBINV_ID; --供方发运库存组织ID-->SUPPLIER_INV_ORG_ID
        R_LG_ORDER.SUPPLIER_INV_ORG    := R_SO_HEADER.ERP_SUBINV_CODE; --供方发运库存组织-->SUPPLIER_INV_ORG
        /*
        临时解决源单库存组织不对问题
        */
        /*SELECT A.ORGANIZATION_ID, A.ORGANIZATION_CODE
               INTO R_LG_ORDER.SUPPLIER_INV_ORG_ID,R_LG_ORDER.SUPPLIER_INV_ORG
         FROM CIMS.T_INV_INVENTORIES A, CIMS.T_INV_ORGANIZATION B
        WHERE A.ENTITY_ID = B.ENTITY_ID
          AND B.ORGANIZATION_ID = A.ORGANIZATION_ID
          AND B.ORGANIZATION_CODE = A.ORGANIZATION_CODE
          AND A.INVENTORY_CODE = R_SO_HEADER.MIDDLE_INV_CODE
          AND a.entity_id=R_SO_HEADER.Entity_Id;*/
      
        V_SRC_INV_CODE    := R_SO_HEADER.MIDDLE_INV_CODE; --edit by chen.wj 20150313 R_SO_HEADER.CONSIGNEE_INV_CODE; --来源子库编码（仓库编码） 
        V_TARGET_INV_CODE := R_SO_HEADER.MIDDLE_INV_CODE; --目标子库编码 
        
        --内部关联交易客户，工厂卖营销的关联物流，来源仓是'内部关联交易客户的未结算仓'
        IF (NVL(R_SO_HEADER.ENTITY_CUST_FLAG,PKG_SO_PUB.V_NO) = PKG_SO_PUB.V_YES) THEN 
          V_SRC_INV_CODE := R_SO_HEADER.NOSETTLED_INVENTORY_CODE;
        END IF;
        
      ELSIF R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE =
            PKG_SO_PUB.V_BIZ_SRC_BILL_SO_RED THEN
        /*
        'TRX001'; --推式成品销售
        'TRX002'; --推式销售结算
        'TRX003'; --拉式成品销售
        'TRX004'; --拉式源单退回
        'TRX005'; --拉式反向销售
        */
        --VARCHAR2(100) 需方OU
        R_LG_ORDER.REQUIREMENT_ORG    := R_SO_HEADER.ERP_OU_NAME;
        R_LG_ORDER.REQUIREMENT_ORG_ID := R_SO_HEADER.ERP_OU_ID;
        --通过内销OU找到销售库存组织
        BEGIN
          SELECT A.ERP_SUBINV_ID, A.ERP_SUBINV_CODE, A.SUBINVENTORY_CODE
            INTO R_LG_ORDER.RECEIVE_INV_ORG_ID,
                 R_LG_ORDER.RECEIVE_INV_ORG,
                 V_RECEIVE_SUBINV
            FROM T_SO_SUPPLIER_REQUIREMENT A
           WHERE A.TRADE_MODE_CODE = PKG_SO_PUB.V_SO_TRX_MODE_004
             AND A.REQUIREMENT_OU_ID = R_SO_HEADER.ERP_OU_ID
             AND A.SUPPLIER_OU_ID = R_SO_HEADER.FACTORY_OU_ID;
        EXCEPTION
          WHEN OTHERS THEN
            P_ERR_MSG := 'OU_ID[' || R_SO_HEADER.ERP_OU_ID || ']，主体ID[' ||
                         R_SO_HEADER.ENTITY_ID || ']查询库存组织信息发生异常：' ||
                         SQLERRM;
            RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
        END;
        --VARCHAR2(100) 供方OU
        R_LG_ORDER.SUPPLIER_ORG    := R_SO_HEADER.FACTORY_OU_NAME;
        R_LG_ORDER.SUPPLIER_ORG_ID := R_SO_HEADER.FACTORY_OU_ID;
        --直接从头表获取工厂库存组织
        R_LG_ORDER.SUPPLIER_INV_ORG_ID := R_SO_HEADER.ERP_SUBINV_ID; --供方发运库存组织ID-->SUPPLIER_INV_ORG_ID
        R_LG_ORDER.SUPPLIER_INV_ORG    := R_SO_HEADER.ERP_SUBINV_CODE; --供方发运库存组织-->SUPPLIER_INV_ORG
      
        V_SRC_INV_CODE := R_SO_HEADER.MIDDLE_INV_CODE; --来源子库编码（仓库编码）  退货未结算仓
        --V_TARGET_INV_CODE := R_SO_HEADER.MIDDLE_INV_CODE; --目标子库编码  蓝单中间仓
        
        --内部关联交易客户，工厂卖营销的关联物流，来源仓是'内部关联交易客户的未结算仓'
        IF (NVL(R_SO_HEADER.ENTITY_CUST_FLAG,PKG_SO_PUB.V_NO) = PKG_SO_PUB.V_YES) THEN 
          V_SRC_INV_CODE := R_SO_HEADER.NOSETTLED_INVENTORY_CODE;
        END IF;
        
        BEGIN
          SELECT A.MIDDLE_INV_CODE
            INTO V_TARGET_INV_CODE
            FROM T_SO_HEADER A
           WHERE A.SO_NUM = R_SO_HEADER.ORIG_SO_NUM;
        EXCEPTION
          WHEN OTHERS THEN
            P_ERR_MSG := '销售红冲单号[' || R_SO_HEADER.SO_NUM || ']查询蓝单信息异常';
            RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
        END;
      ELSIF R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE =
            PKG_SO_PUB.V_BIZ_SRC_BILL_RETURN THEN
        /*
        'TRX001'; --推式成品销售
        'TRX002'; --推式销售结算
        'TRX003'; --拉式成品销售
        'TRX004'; --拉式源单退回
        'TRX005'; --拉式反向销售
        */
        --VARCHAR2(100) 需方OU
        R_LG_ORDER.REQUIREMENT_ORG    := R_SO_HEADER.ERP_OU_NAME;
        R_LG_ORDER.REQUIREMENT_ORG_ID := R_SO_HEADER.ERP_OU_ID;
        --通过内销OU找到销售库存组织
        BEGIN
          SELECT A.ERP_SUBINV_ID, A.ERP_SUBINV_CODE, A.SUBINVENTORY_CODE
            INTO R_LG_ORDER.RECEIVE_INV_ORG_ID,
                 R_LG_ORDER.RECEIVE_INV_ORG,
                 V_RECEIVE_SUBINV
            FROM T_SO_SUPPLIER_REQUIREMENT A
           WHERE A.TRADE_MODE_CODE = PKG_SO_PUB.V_SO_TRX_MODE_004
             AND A.REQUIREMENT_OU_ID = R_SO_HEADER.ERP_OU_ID
             AND A.SUPPLIER_OU_ID = R_SO_HEADER.FACTORY_OU_ID;
        EXCEPTION
          WHEN OTHERS THEN
            P_ERR_MSG := 'OU_ID[' || R_SO_HEADER.ERP_OU_ID || ']，主体ID[' ||
                         R_SO_HEADER.ENTITY_ID || ']查询库存组织信息发生异常：' ||
                         SQLERRM;
            RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
        END;
        --VARCHAR2(100) 供方OU
        R_LG_ORDER.SUPPLIER_ORG    := R_SO_HEADER.FACTORY_OU_NAME;
        R_LG_ORDER.SUPPLIER_ORG_ID := R_SO_HEADER.FACTORY_OU_ID;
        --直接从头表获取工厂库存组织
        R_LG_ORDER.SUPPLIER_INV_ORG_ID := R_SO_HEADER.ERP_SUBINV_ID; --供方发运库存组织ID-->SUPPLIER_INV_ORG_ID
        R_LG_ORDER.SUPPLIER_INV_ORG    := R_SO_HEADER.ERP_SUBINV_CODE; --供方发运库存组织-->SUPPLIER_INV_ORG
        /*
        临时解决源单库存组织不对问题
        */
        /*SELECT A.ORGANIZATION_ID, A.ORGANIZATION_CODE
               INTO R_LG_ORDER.SUPPLIER_INV_ORG_ID,R_LG_ORDER.SUPPLIER_INV_ORG
         FROM CIMS.T_INV_INVENTORIES A, CIMS.T_INV_ORGANIZATION B
        WHERE A.ENTITY_ID = B.ENTITY_ID
          AND B.ORGANIZATION_ID = A.ORGANIZATION_ID
          AND B.ORGANIZATION_CODE = A.ORGANIZATION_CODE
          AND A.INVENTORY_CODE = R_SO_HEADER.MIDDLE_INV_CODE --仓库代码
          AND a.entity_id=R_SO_HEADER.Entity_Id;*/
      
        V_SRC_INV_CODE := R_SO_HEADER.MIDDLE_INV_CODE; --来源子库编码（仓库编码）  退货未结算仓
        --V_TARGET_INV_CODE := R_SO_HEADER.MIDDLE_INV_CODE; --目标子库编码  源单中间仓
        
        --内部关联交易客户，工厂卖营销的关联物流，来源仓是'内部关联交易客户的未结算仓'
        IF (NVL(R_SO_HEADER.ENTITY_CUST_FLAG,PKG_SO_PUB.V_NO) = PKG_SO_PUB.V_YES) THEN 
          V_SRC_INV_CODE := R_SO_HEADER.NOSETTLED_INVENTORY_CODE;
        END IF;
        
        BEGIN
          /*SELECT A.MIDDLE_INV_CODE
           INTO V_TARGET_INV_CODE
           FROM T_SO_HEADER A
          WHERE A.RETURN_ORIG_SO_NUM =
                (SELECT B.ORIG_SO_NUM
                   FROM T_SO_HEADER B
                  WHERE B.SO_NUM = R_SO_HEADER.SO_NUM);*/
          SELECT A.MIDDLE_INV_CODE
            INTO V_TARGET_INV_CODE
            FROM T_SO_HEADER A
           WHERE A.SO_NUM = R_SO_HEADER.RETURN_ORIG_SO_NUM;
        EXCEPTION
          WHEN OTHERS THEN
            P_ERR_MSG := '销售退货单号[' || R_SO_HEADER.SO_NUM || ']查询源单信息异常';
            RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
        END;
      END IF;
    
    END IF;
  
    --VARCHAR2(100) 供方系统
    R_LG_ORDER.SUPPLIER_SYSTEM := 'GERP';
  
    --VARCHAR2(100) 供方来源单据
    R_LG_ORDER.SUPPLIER_ORDER_NUM := R_SO_HEADER.SO_NUM;
  
    --VARCHAR2(100) 供方来源单据类型
    R_LG_ORDER.SUPPLIER_ORDER_TYPE := V_SOURCE_ORDERS_TYPE; --01中转单 / 02财务单;
  
    --NUMBER 主体ID
    R_LG_ORDER.ENTITY_ID := R_SO_HEADER.ENTITY_ID;
  
    INSERT INTO INTF_CUX_ICP_LOGIST_REQ_HEADER
      (ID, ---->ID
       SOURCE_HEADER_ID, --来源头ID    -->SOURCE_HEADER_ID SO_HEADER_ID
       PROC_GROUP_ID, --例程集ID    -->PROC_GROUP_ID 850 B01 同步物流 853 B02 同步物流退回
       GROUP_CODE,
       --REQUIREMENT_SYSTEM, --需方系统-->REQUIREMENT_SYSTEM GERP
       REQUIREMENT_ORG, --需方OU-->REQUIREMENT_ORG ERP_OU_NAME
       REQUIREMENT_ORG_ID, --需方OU ID-->REQUIREMENT_ORG_ID ERP_OU_ID
       REQUIREMENT_ORDER_NUM, --需方来源单据-->REQUIREMENT_ORDER_NUM SO_NUM
       REQUIREMENT_ORDER_TYPE, --需方来源单据类型-->REQUIREMENT_ORDER_TYPE 01中转单/02财务单
       RECEIVE_INV_ORG_ID, --接收库存组织ID-->RECEIVE_INV_ORG_ID
       RECEIVE_INV_ORG, --接收库存组织-->RECEIVE_INV_ORG
       --SUPPLIER_SYSTEM, --供方系统-->SUPPLIER_SYSTEM GERP
       SUPPLIER_ORG, --供方OU-->SUPPLIER_ORG FACTORY_OU_NAME
       SUPPLIER_ORG_ID, --供方OU ID-->SUPPLIER_ORG_ID FACTORY_OU_ID
       SUPPLIER_INV_ORG_ID, --供方发运库存组织ID-->SUPPLIER_INV_ORG_ID
       SUPPLIER_INV_ORG, --供方发运库存组织-->SUPPLIER_INV_ORG
       --SUPPLIER_ORDER_NUM, --供方来源单据-->SUPPLIER_ORDER_NUM
       --SUPPLIER_ORDER_TYPE, --供方来源单据类型-->SUPPLIER_ORDER_TYPE
       --S_ORDER_TYPE_ID, --退货销售订单类型ID-->S_ORDER_TYPE_ID
       --S_ORDER_TYPE, --退货销售订单类型-->S_ORDER_TYPE
       COMMENTS, --备注信息-->COMMENTS REMARK
       ENTITY_ID, --主体ID--> ENTITY_ID
       STATUS_SOURCE, --状态：N待发送；P已发送；S成功--STATUS
       ICP_LG_RECEIVE_MODE
       )
    VALUES
      (R_LG_ORDER.ID, ---->ID
       R_LG_ORDER.SOURCE_HEADER_ID, --来源头ID    -->SOURCE_HEADER_ID SO_HEADER_ID
       R_LG_ORDER.PROC_GROUP_ID, --例程集ID    -->PROC_GROUP_ID 850 B01 同步物流 853 B02 同步物流退回
       R_LG_ORDER.GROUP_CODE,
       --R_LG_ORDER.REQUIREMENT_SYSTEM, --需方系统-->REQUIREMENT_SYSTEM GERP
       R_LG_ORDER.REQUIREMENT_ORG, --需方OU-->REQUIREMENT_ORG ERP_OU_NAME
       R_LG_ORDER.REQUIREMENT_ORG_ID, --需方OU ID-->REQUIREMENT_ORG_ID ERP_OU_ID
       R_LG_ORDER.REQUIREMENT_ORDER_NUM, --需方来源单据-->REQUIREMENT_ORDER_NUM SO_NUM
       R_LG_ORDER.REQUIREMENT_ORDER_TYPE, --需方来源单据类型-->REQUIREMENT_ORDER_TYPE 01中转单/02财务单
       R_LG_ORDER.RECEIVE_INV_ORG_ID, --接收库存组织ID-->RECEIVE_INV_ORG_ID
       R_LG_ORDER.RECEIVE_INV_ORG, --接收库存组织-->RECEIVE_INV_ORG
       --R_LG_ORDER.SUPPLIER_SYSTEM, --供方系统-->SUPPLIER_SYSTEM GERP
       R_LG_ORDER.SUPPLIER_ORG, --供方OU-->SUPPLIER_ORG FACTORY_OU_NAME
       R_LG_ORDER.SUPPLIER_ORG_ID, --供方OU ID-->SUPPLIER_ORG_ID FACTORY_OU_ID
       R_LG_ORDER.SUPPLIER_INV_ORG_ID, --供方发运库存组织ID-->SUPPLIER_INV_ORG_ID
       R_LG_ORDER.SUPPLIER_INV_ORG, --供方发运库存组织-->SUPPLIER_INV_ORG
       --R_LG_ORDER.SUPPLIER_ORDER_NUM, --供方来源单据-->SUPPLIER_ORDER_NUM
       --R_LG_ORDER.SUPPLIER_ORDER_TYPE, --供方来源单据类型-->SUPPLIER_ORDER_TYPE
       --R_LG_ORDER.S_ORDER_TYPE_ID, --退货销售订单类型ID-->S_ORDER_TYPE_ID
       --R_LG_ORDER.S_ORDER_TYPE, --退货销售订单类型-->S_ORDER_TYPE
       R_LG_ORDER.COMMENTS, --备注信息-->COMMENTS REMARK
       R_LG_ORDER.ENTITY_ID, --主体ID--> ENTITY_ID
       P_STATUS, --状态：N待发送；P已发送；S成功
       '0'
       );
    --chenzh     2015/0528   获取销售中间仓
    --获取
    V_SO_ICP_INV_ENABLE :=pkg_bd.F_GET_PARAMETER_VALUE('SO_ICP_INV_ENABLE',R_SO_HEADER.ENTITY_ID,null,null);
    IF V_SO_ICP_INV_ENABLE='1' THEN
      P_GET_ICP_INV(R_SO_HEADER,V_MIDDLE_INV_CODE,P_RESULT,P_ERR_MSG);
      IF P_RESULT < 0 THEN
         RAISE PKG_SO_PUB.V_BIZ_EXCEPTION; 
      END IF;      
    END IF;  
    -- -1错误,0非拉式,1销售,2红冲,3源单退回,4反向销售,5源单退货红冲，6拉式其他单据类型
    IF V_PULL_MODE IN (1, 4, 5) THEN
      --销售单，退货红冲单来源仓 chenzh 2015/05/28
      IF V_PULL_MODE IN (1,5) AND V_SO_ICP_INV_ENABLE = '1' THEN
        --V_SRC_INV_CODE := V_MIDDLE_INV_CODE;
        V_TARGET_INV_CODE:= V_MIDDLE_INV_CODE;
      END IF;
           
      FOR REC IN (SELECT *
                    FROM T_SO_LINE A
                   WHERE A.SO_HEADER_ID = R_SO_HEADER.SO_HEADER_ID
                   ORDER BY A.SO_LINE_NUM) LOOP
        R_LG_ORDER_LINE := NULL;
      
        -- NUMBER[965]
        R_LG_ORDER_LINE.ID := S_CUX_ICP_LOGIST_REQ_LINES.NEXTVAL;
      
        --行号 NUMBER[1]
        R_LG_ORDER_LINE.REQ_LINE_NUM := REC.SO_LINE_NUM;
      
        R_LG_ORDER_LINE.SOURCE_HEADER_ID := R_SO_HEADER.SO_HEADER_ID; --来源头ID
        R_LG_ORDER_LINE.REQ_LINE_NUM     := REC.SO_LINE_NUM; --行号
        R_LG_ORDER_LINE.ORDER_LINE_NUM   := REC.SO_LINE_NUM; --关联订单行号
        R_LG_ORDER_LINE.ISS_DATE         := R_SO_HEADER.SETTLE_DATE; --发出日期 销售单结算日期
        R_LG_ORDER_LINE.RECEIVE_DATE     := R_SO_HEADER.SETTLE_DATE; --接收日期 销售单结算日期,由SO_DATE改为SETTLE_DATE
        R_LG_ORDER_LINE.SOURCE_HEADER    := R_SO_HEADER.SO_NUM; --来源头信息
        R_LG_ORDER_LINE.SOURCE_LINE      := REC.SO_LINE_ID; --供方来源行号
        --R_LG_ORDER_LINE.REQUIRE_SOURCE_LINE:=REC.SO_LINE_ID; --需方来源行号
        --供方信息物料编码ID NUMBER[]
        R_LG_ORDER_LINE.SUPPLIER_ITEM_ID := REC.ITEM_ID;
      
        --供方信息物料编码 VARCHAR2(100)[31022211001551]
        R_LG_ORDER_LINE.SUPPLIER_ITEM_NUM := REC.ITEM_CODE;
      
        --需方信息物料编码ID NUMBER[]
        R_LG_ORDER_LINE.REQUIRE_ITEM_ID := REC.ITEM_ID;
      
        --需方信息物料编码 VARCHAR2(100)[31022211001551]
        R_LG_ORDER_LINE.REQUIRE_ITEM_NUM := REC.ITEM_CODE;
      
        --单位 VARCHAR2(100)[Tai]
        R_LG_ORDER_LINE.PRIMARY_UNIT_OF_MEASURE := REC.ITEM_UOM;
      
        --发出数量 NUMBER[111]
        R_LG_ORDER_LINE.REQUEST_QUANTITY := REC.ITEM_QTY;
      
        --    --来源子库 VARCHAR2(100)[MA3311]  
        R_LG_ORDER_LINE.SUPPLIER_SORCE_SUBINV := V_SRC_INV_CODE;
      
        ---    --发出商品子库 VARCHAR2(100)[MX1351]  
        R_LG_ORDER_LINE.SUPPLIER_SHIP_SUBINV := V_TARGET_INV_CODE;
      
        ---   --接收子库 VARCHAR2(100)[SWC34B1110] 有问题，取值
        R_LG_ORDER_LINE.RECEIVE_SUBINV := V_RECEIVE_SUBINV;
      
        INSERT INTO INTF_CUX_ICP_LOGIST_REQ_LINES
          (ID,
           HEADERS_ID,
           SOURCE_HEADER_ID,
           REQ_LINE_NUM,
           --ORDER_HEADER_ID,
           ORDER_LINE_NUM,
           --SUPPLIER_ITEM_ID,
           SUPPLIER_ITEM_NUM,
           --REQUIRE_ITEM_ID,
           REQUIRE_ITEM_NUM,
           PRIMARY_UNIT_OF_MEASURE,
           REQUEST_QUANTITY,
           SUPPLIER_SORCE_SUBINV,
           SUPPLIER_SORCE_LOCATION,
           SUPPLIER_SORCE_LOCATION_ID,
           SUPPLIER_SHIP_SUBINV,
           SUPPLIER_SHIP_LOCATION,
           SUPPLIER_SHIP_LOCATION_ID,
           ISS_LOT_NUMBER,
           ISS_DATE,
           RECEIVE_SUBINV,
           RECEIVE_LOCATION,
           RECEIVE_LOCATION_ID,
           RECEIVE_LOT_NUMBER,
           RECEIVE_DATE,
           SOURCE_HEADER,
           SOURCE_LINE,
           REQUIRE_SOURCE_LINE,
           COMMENTS,
           LOGIST_HEADER_ID, --关联物流号
           LOGIST_LINE_ID)
        VALUES
          (R_LG_ORDER_LINE.ID, --
           R_LG_ORDER.ID,
           R_LG_ORDER_LINE.SOURCE_HEADER_ID, --来源头ID
           R_LG_ORDER_LINE.REQ_LINE_NUM, --行号
           --R_LG_ORDER_LINE.ORDER_HEADER_ID, --关联订单号
           R_LG_ORDER_LINE.ORDER_LINE_NUM, --关联订单行号
           --R_LG_ORDER_LINE.SUPPLIER_ITEM_ID, --供方信息物料编码ID
           R_LG_ORDER_LINE.SUPPLIER_ITEM_NUM, --供方信息物料编码
           --R_LG_ORDER_LINE.REQUIRE_ITEM_ID, --需方信息物料编码ID
           R_LG_ORDER_LINE.REQUIRE_ITEM_NUM, --需方信息物料编码
           R_LG_ORDER_LINE.PRIMARY_UNIT_OF_MEASURE, --单位
           R_LG_ORDER_LINE.REQUEST_QUANTITY, --发出数量
           R_LG_ORDER_LINE.SUPPLIER_SORCE_SUBINV, --来源子库
           R_LG_ORDER_LINE.SUPPLIER_SORCE_LOCATION, --来源货位
           R_LG_ORDER_LINE.SUPPLIER_SORCE_LOCATION_ID, --来源货位ID
           R_LG_ORDER_LINE.SUPPLIER_SHIP_SUBINV, --发出商品子库
           R_LG_ORDER_LINE.SUPPLIER_SHIP_LOCATION, --发出商品货位
           R_LG_ORDER_LINE.SUPPLIER_SHIP_LOCATION_ID, --发出商品货位ID
           R_LG_ORDER_LINE.ISS_LOT_NUMBER, --发出批次
           R_LG_ORDER_LINE.ISS_DATE, --发出日期
           R_LG_ORDER_LINE.RECEIVE_SUBINV, --接收子库
           R_LG_ORDER_LINE.RECEIVE_LOCATION, --接收库存货位
           R_LG_ORDER_LINE.RECEIVE_LOCATION_ID, --接收库存货位ID
           R_LG_ORDER_LINE.RECEIVE_LOT_NUMBER, --接收批次
           R_LG_ORDER_LINE.RECEIVE_DATE, --接收日期
           R_LG_ORDER_LINE.SOURCE_HEADER, --来源头信息
           R_LG_ORDER_LINE.SOURCE_LINE, --供方来源行号
           R_LG_ORDER_LINE.REQUIRE_SOURCE_LINE, --需方来源行号
           R_LG_ORDER_LINE.COMMENTS, --行备注
           R_LG_ORDER_LINE.LOGIST_HEADER_ID, --关联物流号
           R_LG_ORDER_LINE.LOGIST_LINE_ID --关联物流行ID
           );
      
      END LOOP;
    ELSIF V_PULL_MODE IN (2) THEN
      -- -1错误,0非拉式,1销售,2红冲,3源单退回,4反向销售,5源单退货红冲，6拉式其他单据类型
      --销售红冲单目标仓 chenzh 2015/05/28
      IF V_SO_ICP_INV_ENABLE = '1' THEN
         V_TARGET_INV_CODE   := V_MIDDLE_INV_CODE;
      END IF;
     
  
      FOR REC IN (SELECT *
                    FROM T_SO_LINE A
                   WHERE A.SO_HEADER_ID = R_SO_HEADER.SO_HEADER_ID
                   ORDER BY A.SO_LINE_NUM) LOOP
      
        R_LG_ORDER_LINE := NULL;
        /*
        PO_LINE_NUM ORDER_LINE_NUM：源关联订单的行号    REQ_LINE_NUM
        ERP_ORDER_HEADER_ID ORDER_HEADER_ID：源关联订单的头ID   ORDER_HEADER_ID
        REQ_LINE_ID LOGIST_LINE_ID：源物流的行ID   REQ_LINE_ID
        
        select * from V_INV_PO_BACK_RELATION_VIEW
        */
        --查询蓝单关联订单中的
        BEGIN
          /*SELECT ORDER_HEADER_ID
           INTO R_LG_ORDER_LINE.ORDER_HEADER_ID --关联订单号
           FROM INTF_CUX_ICP_LOGIST_REQ_LINES A
          WHERE A.SOURCE_HEADER = R_SO_HEADER.ORIG_SO_NUM --蓝单号
            AND A.REQUIRE_ITEM_NUM = REC.ITEM_CODE;*/
          SELECT --A.SO_NUM,
          --A.SO_HEADER_ID,
           A.ERP_ORDER_HEADER_ID AS ORDER_HEADER_ID, --ORDER_HEADER_ID
           --A.ERP_LOGIST_HEADER_ID,
           C.ORDER_LINE_NUM,
           --B.ITEM_CODE,
           C.REQ_LINE_ID AS LOGIST_LINE_ID --LOGIST_LINE_ID
            INTO R_LG_ORDER_LINE.ORDER_HEADER_ID,
                 R_LG_ORDER_LINE.ORDER_LINE_NUM,
                 R_LG_ORDER_LINE.LOGIST_LINE_ID
            FROM T_SO_HEADER                                 A,
                 T_SO_LINE                                   B,
                 APPS.CUX_ICP_LOGIST_REQ_LINES_V@MDIMS2MDERP C
           WHERE B.SO_HEADER_ID = A.SO_HEADER_ID
             AND A.ERP_LOGIST_HEADER_ID = C.REQ_HEADER_ID
             AND B.ITEM_CODE = C.SUPPLIER_ITEM_NUM
             AND A.BIZ_SRC_BILL_TYPE_CODE = '1001'
             AND B.ITEM_CODE = REC.ITEM_CODE
             AND A.SO_NUM = R_SO_HEADER.ORIG_SO_NUM; --蓝单号
        EXCEPTION
          WHEN OTHERS THEN
            P_ERR_MSG := '销售红冲单号[' || R_SO_HEADER.SO_NUM || ']查询蓝单关联物流订单异常';
            RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
        END;
        IF R_LG_ORDER_LINE.ORDER_HEADER_ID IS NULL THEN
          P_ERR_MSG := '销售红冲单号[' || R_SO_HEADER.SO_NUM || ']获取蓝单关联订单号异常';
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
        END IF;
      
        -- NUMBER[965]
        R_LG_ORDER_LINE.ID := S_CUX_ICP_LOGIST_REQ_LINES.NEXTVAL;
      
        --行号 NUMBER[1]
        R_LG_ORDER_LINE.REQ_LINE_NUM := REC.SO_LINE_NUM;
      
        R_LG_ORDER_LINE.SOURCE_HEADER_ID := R_SO_HEADER.SO_HEADER_ID; --来源头ID
        R_LG_ORDER_LINE.REQ_LINE_NUM     := REC.SO_LINE_NUM; --行号
        --R_LG_ORDER_LINE.ORDER_LINE_NUM   := REC.SO_LINE_NUM; --关联订单行号
        R_LG_ORDER_LINE.ISS_DATE      := R_SO_HEADER.SETTLE_DATE; --发出日期 销售单结算日期
        R_LG_ORDER_LINE.RECEIVE_DATE  := R_SO_HEADER.SETTLE_DATE; --接收日期 销售单结算日期,由SO_DATE改为SETTLE_DATE
        R_LG_ORDER_LINE.SOURCE_HEADER := R_SO_HEADER.SO_NUM; --来源头信息
        R_LG_ORDER_LINE.SOURCE_LINE   := REC.SO_LINE_ID; --供方来源行号
        --R_LG_ORDER_LINE.REQUIRE_SOURCE_LINE:=REC.SO_LINE_ID; --需方来源行号
        --供方信息物料编码ID NUMBER[]
        R_LG_ORDER_LINE.SUPPLIER_ITEM_ID := REC.ITEM_ID;
      
        --供方信息物料编码 VARCHAR2(100)[31022211001551]
        R_LG_ORDER_LINE.SUPPLIER_ITEM_NUM := REC.ITEM_CODE;
      
        --需方信息物料编码ID NUMBER[]
        R_LG_ORDER_LINE.REQUIRE_ITEM_ID := REC.ITEM_ID;
      
        --需方信息物料编码 VARCHAR2(100)[31022211001551]
        R_LG_ORDER_LINE.REQUIRE_ITEM_NUM := REC.ITEM_CODE;
      
        --单位 VARCHAR2(100)[Tai]
        R_LG_ORDER_LINE.PRIMARY_UNIT_OF_MEASURE := REC.ITEM_UOM;
      
        --发出数量 NUMBER[111]
        R_LG_ORDER_LINE.REQUEST_QUANTITY := REC.ITEM_QTY;
      
        --    --来源子库 VARCHAR2(100)[MA3311]  
        R_LG_ORDER_LINE.SUPPLIER_SORCE_SUBINV := V_SRC_INV_CODE;
      
        ---    --发出商品子库 VARCHAR2(100)[MX1351]  
        R_LG_ORDER_LINE.SUPPLIER_SHIP_SUBINV := V_TARGET_INV_CODE;
      
        ---   --接收子库 VARCHAR2(100)[SWC34B1110] 有问题，取值
        R_LG_ORDER_LINE.RECEIVE_SUBINV := V_RECEIVE_SUBINV;
      
        INSERT INTO INTF_CUX_ICP_LOGIST_REQ_LINES
          (ID,
           HEADERS_ID,
           SOURCE_HEADER_ID,
           REQ_LINE_NUM,
           ORDER_HEADER_ID,
           ORDER_LINE_NUM,
           --SUPPLIER_ITEM_ID,
           SUPPLIER_ITEM_NUM,
           --REQUIRE_ITEM_ID,
           REQUIRE_ITEM_NUM,
           PRIMARY_UNIT_OF_MEASURE,
           REQUEST_QUANTITY,
           SUPPLIER_SORCE_SUBINV,
           SUPPLIER_SORCE_LOCATION,
           SUPPLIER_SORCE_LOCATION_ID,
           SUPPLIER_SHIP_SUBINV,
           SUPPLIER_SHIP_LOCATION,
           SUPPLIER_SHIP_LOCATION_ID,
           ISS_LOT_NUMBER,
           ISS_DATE,
           RECEIVE_SUBINV,
           RECEIVE_LOCATION,
           RECEIVE_LOCATION_ID,
           RECEIVE_LOT_NUMBER,
           RECEIVE_DATE,
           SOURCE_HEADER,
           SOURCE_LINE,
           REQUIRE_SOURCE_LINE,
           COMMENTS,
           LOGIST_HEADER_ID, --关联物流号
           LOGIST_LINE_ID)
        VALUES
          (R_LG_ORDER_LINE.ID, --
           R_LG_ORDER.ID,
           R_LG_ORDER_LINE.SOURCE_HEADER_ID, --来源头ID
           R_LG_ORDER_LINE.REQ_LINE_NUM, --行号
           R_LG_ORDER_LINE.ORDER_HEADER_ID, --关联订单号
           R_LG_ORDER_LINE.ORDER_LINE_NUM, --关联订单行号
           --R_LG_ORDER_LINE.SUPPLIER_ITEM_ID, --供方信息物料编码ID
           R_LG_ORDER_LINE.SUPPLIER_ITEM_NUM, --供方信息物料编码
           --R_LG_ORDER_LINE.REQUIRE_ITEM_ID, --需方信息物料编码ID
           R_LG_ORDER_LINE.REQUIRE_ITEM_NUM, --需方信息物料编码
           R_LG_ORDER_LINE.PRIMARY_UNIT_OF_MEASURE, --单位
           R_LG_ORDER_LINE.REQUEST_QUANTITY, --发出数量
           R_LG_ORDER_LINE.SUPPLIER_SORCE_SUBINV, --来源子库
           R_LG_ORDER_LINE.SUPPLIER_SORCE_LOCATION, --来源货位
           R_LG_ORDER_LINE.SUPPLIER_SORCE_LOCATION_ID, --来源货位ID
           R_LG_ORDER_LINE.SUPPLIER_SHIP_SUBINV, --发出商品子库
           R_LG_ORDER_LINE.SUPPLIER_SHIP_LOCATION, --发出商品货位
           R_LG_ORDER_LINE.SUPPLIER_SHIP_LOCATION_ID, --发出商品货位ID
           R_LG_ORDER_LINE.ISS_LOT_NUMBER, --发出批次
           R_LG_ORDER_LINE.ISS_DATE, --发出日期
           R_LG_ORDER_LINE.RECEIVE_SUBINV, --接收子库
           R_LG_ORDER_LINE.RECEIVE_LOCATION, --接收库存货位
           R_LG_ORDER_LINE.RECEIVE_LOCATION_ID, --接收库存货位ID
           R_LG_ORDER_LINE.RECEIVE_LOT_NUMBER, --接收批次
           R_LG_ORDER_LINE.RECEIVE_DATE, --接收日期
           R_LG_ORDER_LINE.SOURCE_HEADER, --来源头信息
           R_LG_ORDER_LINE.SOURCE_LINE, --供方来源行号
           R_LG_ORDER_LINE.REQUIRE_SOURCE_LINE, --需方来源行号
           R_LG_ORDER_LINE.COMMENTS, --行备注
           R_LG_ORDER_LINE.LOGIST_HEADER_ID, --关联物流号
           R_LG_ORDER_LINE.LOGIST_LINE_ID --关联物流行ID
           );
      
      END LOOP;
    ELSIF V_PULL_MODE IN (3) THEN
      -- -1错误,0非拉式,1销售,2红冲,3源单退回,4反向销售,5拉式其他单据类型
      --蓝单目标仓，中间仓，红单发出仓，中间仓 chenzh 2015/05/28
      IF V_SO_ICP_INV_ENABLE = '1' THEN
         --V_RECEIVE_SUBINV := V_MIDDLE_INV_CODE;
         V_TARGET_INV_CODE := V_MIDDLE_INV_CODE;
      END IF;
      FOR REC IN (SELECT *
                    FROM T_SO_LINE A
                   WHERE A.SO_HEADER_ID = R_SO_HEADER.SO_HEADER_ID
                   ORDER BY A.SO_LINE_NUM) LOOP
      
        R_LG_ORDER_LINE := NULL;
        --查询蓝单关联订单中的
        BEGIN
          /*SELECT ORDER_HEADER_ID
           INTO R_LG_ORDER_LINE.ORDER_HEADER_ID --关联订单号
           FROM INTF_CUX_ICP_LOGIST_REQ_LINES A
          WHERE A.SOURCE_HEADER = R_SO_HEADER.RETURN_ORIG_SO_NUM --源单号
            AND A.REQUIRE_ITEM_NUM = REC.ITEM_CODE;*/
        
          SELECT --A.SO_NUM,
          --A.SO_HEADER_ID,
           A.ERP_ORDER_HEADER_ID AS ORDER_HEADER_ID, --ORDER_HEADER_ID
           --A.ERP_LOGIST_HEADER_ID,
           C.ORDER_LINE_NUM,
           --B.ITEM_CODE,
           C.REQ_LINE_ID AS LOGIST_LINE_ID --LOGIST_LINE_ID
            INTO R_LG_ORDER_LINE.ORDER_HEADER_ID,
                 R_LG_ORDER_LINE.ORDER_LINE_NUM,
                 R_LG_ORDER_LINE.LOGIST_LINE_ID
            FROM T_SO_HEADER                                 A,
                 T_SO_LINE                                   B,
                 APPS.CUX_ICP_LOGIST_REQ_LINES_V@MDIMS2MDERP C
           WHERE B.SO_HEADER_ID = A.SO_HEADER_ID
             AND A.ERP_LOGIST_HEADER_ID = C.REQ_HEADER_ID
             AND B.ITEM_CODE = C.SUPPLIER_ITEM_NUM
             AND A.BIZ_SRC_BILL_TYPE_CODE = '1001'
             AND B.ITEM_CODE = REC.ITEM_CODE
             AND A.SO_NUM = R_SO_HEADER.RETURN_ORIG_SO_NUM; --源单号;
        EXCEPTION
          WHEN OTHERS THEN
            P_ERR_MSG := '销售红冲单号[' || R_SO_HEADER.SO_NUM || ']查询源单关联物流订单异常';
            RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
        END;
        IF R_LG_ORDER_LINE.ORDER_HEADER_ID IS NULL THEN
          P_ERR_MSG := '销售退货单号[' || R_SO_HEADER.SO_NUM || ']获取源单关联订单号异常';
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
        END IF;
      
        -- NUMBER[965]
        R_LG_ORDER_LINE.ID := S_CUX_ICP_LOGIST_REQ_LINES.NEXTVAL;
      
        --行号 NUMBER[1]
        R_LG_ORDER_LINE.REQ_LINE_NUM := REC.SO_LINE_NUM;
      
        R_LG_ORDER_LINE.SOURCE_HEADER_ID := R_SO_HEADER.SO_HEADER_ID; --来源头ID
        R_LG_ORDER_LINE.REQ_LINE_NUM     := REC.SO_LINE_NUM; --行号
        --R_LG_ORDER_LINE.ORDER_LINE_NUM   := REC.SO_LINE_NUM; --关联订单行号
        R_LG_ORDER_LINE.ISS_DATE      := R_SO_HEADER.SETTLE_DATE; --发出日期 销售单结算日期
        R_LG_ORDER_LINE.RECEIVE_DATE  := R_SO_HEADER.SETTLE_DATE; --接收日期 销售单结算日期,由SO_DATE改为SETTLE_DATE
        R_LG_ORDER_LINE.SOURCE_HEADER := R_SO_HEADER.SO_NUM; --来源头信息
        R_LG_ORDER_LINE.SOURCE_LINE   := REC.SO_LINE_ID; --供方来源行号
        --R_LG_ORDER_LINE.REQUIRE_SOURCE_LINE:=REC.SO_LINE_ID; --需方来源行号
        --供方信息物料编码ID NUMBER[]
        R_LG_ORDER_LINE.SUPPLIER_ITEM_ID := REC.ITEM_ID;
      
        --供方信息物料编码 VARCHAR2(100)[31022211001551]
        R_LG_ORDER_LINE.SUPPLIER_ITEM_NUM := REC.ITEM_CODE;
      
        --需方信息物料编码ID NUMBER[]
        R_LG_ORDER_LINE.REQUIRE_ITEM_ID := REC.ITEM_ID;
      
        --需方信息物料编码 VARCHAR2(100)[31022211001551]
        R_LG_ORDER_LINE.REQUIRE_ITEM_NUM := REC.ITEM_CODE;
      
        --单位 VARCHAR2(100)[Tai]
        R_LG_ORDER_LINE.PRIMARY_UNIT_OF_MEASURE := REC.ITEM_UOM;
      
        --发出数量 NUMBER[111]
        R_LG_ORDER_LINE.REQUEST_QUANTITY := REC.ITEM_QTY;
      
        --    --来源子库 VARCHAR2(100)[MA3311]  
        R_LG_ORDER_LINE.SUPPLIER_SORCE_SUBINV := V_SRC_INV_CODE;
      
        ---    --发出商品子库 VARCHAR2(100)[MX1351]  
        R_LG_ORDER_LINE.SUPPLIER_SHIP_SUBINV := V_TARGET_INV_CODE;
      
        ---   --接收子库 VARCHAR2(100)[SWC34B1110] 有问题，取值
        R_LG_ORDER_LINE.RECEIVE_SUBINV := V_RECEIVE_SUBINV;
      
        INSERT INTO INTF_CUX_ICP_LOGIST_REQ_LINES
          (ID,
           HEADERS_ID,
           SOURCE_HEADER_ID,
           REQ_LINE_NUM,
           ORDER_HEADER_ID,
           ORDER_LINE_NUM,
           --SUPPLIER_ITEM_ID,
           SUPPLIER_ITEM_NUM,
           --REQUIRE_ITEM_ID,
           REQUIRE_ITEM_NUM,
           PRIMARY_UNIT_OF_MEASURE,
           REQUEST_QUANTITY,
           SUPPLIER_SORCE_SUBINV,
           SUPPLIER_SORCE_LOCATION,
           SUPPLIER_SORCE_LOCATION_ID,
           SUPPLIER_SHIP_SUBINV,
           SUPPLIER_SHIP_LOCATION,
           SUPPLIER_SHIP_LOCATION_ID,
           ISS_LOT_NUMBER,
           ISS_DATE,
           RECEIVE_SUBINV,
           RECEIVE_LOCATION,
           RECEIVE_LOCATION_ID,
           RECEIVE_LOT_NUMBER,
           RECEIVE_DATE,
           SOURCE_HEADER,
           SOURCE_LINE,
           REQUIRE_SOURCE_LINE,
           COMMENTS,
           LOGIST_HEADER_ID, --关联物流号
           LOGIST_LINE_ID)
        VALUES
          (R_LG_ORDER_LINE.ID, --
           R_LG_ORDER.ID,
           R_LG_ORDER_LINE.SOURCE_HEADER_ID, --来源头ID
           R_LG_ORDER_LINE.REQ_LINE_NUM, --行号
           R_LG_ORDER_LINE.ORDER_HEADER_ID, --关联订单号
           R_LG_ORDER_LINE.ORDER_LINE_NUM, --关联订单行号
           --R_LG_ORDER_LINE.SUPPLIER_ITEM_ID, --供方信息物料编码ID
           R_LG_ORDER_LINE.SUPPLIER_ITEM_NUM, --供方信息物料编码
           --R_LG_ORDER_LINE.REQUIRE_ITEM_ID, --需方信息物料编码ID
           R_LG_ORDER_LINE.REQUIRE_ITEM_NUM, --需方信息物料编码
           R_LG_ORDER_LINE.PRIMARY_UNIT_OF_MEASURE, --单位
           R_LG_ORDER_LINE.REQUEST_QUANTITY, --发出数量
           R_LG_ORDER_LINE.SUPPLIER_SORCE_SUBINV, --来源子库
           R_LG_ORDER_LINE.SUPPLIER_SORCE_LOCATION, --来源货位
           R_LG_ORDER_LINE.SUPPLIER_SORCE_LOCATION_ID, --来源货位ID
           R_LG_ORDER_LINE.SUPPLIER_SHIP_SUBINV, --发出商品子库
           R_LG_ORDER_LINE.SUPPLIER_SHIP_LOCATION, --发出商品货位
           R_LG_ORDER_LINE.SUPPLIER_SHIP_LOCATION_ID, --发出商品货位ID
           R_LG_ORDER_LINE.ISS_LOT_NUMBER, --发出批次
           R_LG_ORDER_LINE.ISS_DATE, --发出日期
           R_LG_ORDER_LINE.RECEIVE_SUBINV, --接收子库
           R_LG_ORDER_LINE.RECEIVE_LOCATION, --接收库存货位
           R_LG_ORDER_LINE.RECEIVE_LOCATION_ID, --接收库存货位ID
           R_LG_ORDER_LINE.RECEIVE_LOT_NUMBER, --接收批次
           R_LG_ORDER_LINE.RECEIVE_DATE, --接收日期
           R_LG_ORDER_LINE.SOURCE_HEADER, --来源头信息
           R_LG_ORDER_LINE.SOURCE_LINE, --供方来源行号
           R_LG_ORDER_LINE.REQUIRE_SOURCE_LINE, --需方来源行号
           R_LG_ORDER_LINE.COMMENTS, --行备注
           R_LG_ORDER_LINE.LOGIST_HEADER_ID, --关联物流号
           R_LG_ORDER_LINE.LOGIST_LINE_ID --关联物流行ID
           );
      
      END LOOP;
    END IF;
    P_TABLE_ACTION_LOG('INTF_CUX_ICP_LOGIST_REQ_HEADER', --操作表名称
                       '销售单生成物流订单', --操作说明
                       R_SO_HEADER.SO_NUM, --关键主键
                       0, --是否出错，1出错，0未出错
                       '' --错误信息
                       );
  EXCEPTION
    WHEN OTHERS THEN
      --ROLLBACK;
      P_RESULT  := -1;
      P_ERR_MSG := '销售单据头[ID：' || P_SO_HEADER_ID || ']生成关联物流订单出错，原因：' ||
                   P_ERR_MSG || SQLERRM;
      P_TABLE_ACTION_LOG('INTF_CUX_ICP_LOGIST_REQ_HEADER', --操作表名称
                         '销售单生成物流订单', --操作说明
                         R_SO_HEADER.SO_NUM, --关键主键
                         1, --是否出错，1出错，0未出错
                         P_ERR_MSG --错误信息
                         );
      --RAISE_APPLICATION_ERROR(-20123, P_ERR_MSG, FALSE);
  
  END;
  /*PROCEDURE P_SO_TO_LG_ORDER_1(P_SO_HEADER_ID IN T_SO_HEADER.SO_HEADER_ID%TYPE, --销售单头id
                               P_STATUS       IN VARCHAR2, --状态：N待发送；P已发送；S成功，如果前面有关联订单，需要将状态传空值，这样才可以实现串行
                               P_RESULT       IN OUT NUMBER, --返回错误ID
                               P_ERR_MSG      IN OUT VARCHAR2 --返回错误信息
                               ) AS
    --销售单据头
    CURSOR C_SO_HEADER IS
      SELECT * FROM T_SO_HEADER WHERE SO_HEADER_ID = P_SO_HEADER_ID;
    R_SO_HEADER C_SO_HEADER%ROWTYPE;
  
    --物流订单头表
    R_LG_ORDER INTF_CUX_ICP_LOGIST_REQ_HEADER%ROWTYPE;
  
    --物流订单行表
    R_LG_ORDER_LINE INTF_CUX_ICP_LOGIST_REQ_LINES%ROWTYPE;
  
    --库存组织编码
    V_INV_ORG_CODE T_INV_ORGANIZATION.ORGANIZATION_CODE%TYPE;
  
    --来源子库编码（仓库编码）
    V_SRC_INV_CODE T_INV_INVENTORIES.INVENTORY_CODE%TYPE;
  
    --目标子库编码
    V_TARGET_INV_CODE T_INV_INVENTORIES.INVENTORY_CODE%TYPE;
  
    --接收子库
    V_RECEIVE_SUBINV INTF_CUX_ICP_LOGIST_REQ_LINES.RECEIVE_SUBINV%TYPE;
  
    --仓库ID、编码、名称
    V_INV_ID   T_INV_INVENTORIES.INVENTORY_ID%TYPE;
    V_INV_CODE T_INV_INVENTORIES.INVENTORY_CODE%TYPE;
    V_INV_NAME T_INV_INVENTORIES.INVENTORY_NAME%TYPE;
  
    --RETURN_MODE VARCHAR2(2) 退货方式：1-推式，2-拉式源单退回，3-拉式反向销售
    V_RETURN_MODE T_SO_HEADER.RETURN_MODE%TYPE;
  
    V_COUNT NUMBER;
    --关联交易模式 chen.wj
    V_SO_TRX_MODE VARCHAR2(10);
  
    V_PULL_MODE NUMBER;
  
  BEGIN
    --初始返回值
    P_RESULT  := PKG_SO_PUB.V_RESULT;
    P_ERR_MSG := PKG_SO_PUB.V_SUCCESS;
  
    --获取销售单头信息
    OPEN C_SO_HEADER;
    FETCH C_SO_HEADER
      INTO R_SO_HEADER;
    CLOSE C_SO_HEADER;
    --退货方式：1-推式，2-拉式源单退回，3-拉式反向销售
    V_RETURN_MODE := NVL(R_SO_HEADER.RETURN_MODE, '1'); --默认1-推式
  
    V_PULL_MODE := PKG_SO_PUB.F_PULL_MODE(R_SO_HEADER.SO_NUM); -- -1错误,0非拉式,1销售,2红冲,3源单退回,4反向销售,5源单退货红冲，6拉式其他单据类型
  
    --判断是否重复生成物流
    SELECT COUNT(*)
      INTO V_COUNT
      FROM INTF_CUX_ICP_LOGIST_REQ_HEADER
     WHERE (REQUIREMENT_ORDER_TYPE = V_SOURCE_ORDERS_TYPE OR
           SUPPLIER_ORDER_TYPE = V_SOURCE_ORDERS_TYPE)
       AND REQUIREMENT_ORDER_NUM = R_SO_HEADER.SO_NUM;
    IF V_COUNT > 0 THEN
      P_ERR_MSG := '销售单据[单据号：' || R_SO_HEADER.SO_NUM ||
                   ']已生成物流订单[INTF_CUX_ICP_LOGIST_REQ_HEADER]表记录';
      RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
    END IF;
    --内销库存组织
    BEGIN
      --add by chen.wj 20150206
      -- -1错误,0非拉式,1销售,2红冲,3源单退回,4反向销售,5源单退货红冲，6拉式其他单据类型
      \*
      'TRX001'; --推式成品销售
      'TRX002'; --推式销售结算
      'TRX003'; --拉式成品销售
      'TRX004'; --拉式源单退回
      'TRX005'; --拉式反向销售
      *\
      V_PULL_MODE := PKG_SO_PUB.F_PULL_MODE(R_SO_HEADER.SO_NUM);
      SELECT DECODE(V_PULL_MODE,
                    1,
                    PKG_SO_PUB.V_SO_TRX_MODE_003,
                    2,
                    PKG_SO_PUB.V_SO_TRX_MODE_004,
                    3,
                    PKG_SO_PUB.V_SO_TRX_MODE_004,
                    4,
                    PKG_SO_PUB.V_SO_TRX_MODE_005,
                    5,
                    PKG_SO_PUB.V_SO_TRX_MODE_003,
                    V_PULL_MODE)
        INTO V_SO_TRX_MODE
        FROM DUAL;
    
      --工厂OU和ERP OU 交互
      SELECT T.SUBINVENTORY_CODE --内销正品仓
        INTO V_RECEIVE_SUBINV
        FROM T_SO_SUPPLIER_REQUIREMENT T
       WHERE T.ENTITY_ID = R_SO_HEADER.ENTITY_ID
         AND T.SUPPLIER_OU_ID = R_SO_HEADER.FACTORY_OU_ID
         AND T.TRADE_MODE_CODE = V_SO_TRX_MODE;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        P_ERR_MSG := '供方OU ID[' || R_SO_HEADER.FACTORY_OU_ID || '],主体ID[' ||
                     R_SO_HEADER.ENTITY_ID || '],关联交易模式编码[' ||
                     V_SO_TRX_MODE ||
                     '],T_SO_SUPPLIER_REQUIREMENT表未设置对应的ERP OU！';
        RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      WHEN OTHERS THEN
        P_ERR_MSG := '供方OU ID[' || R_SO_HEADER.FACTORY_OU_ID || '],主体ID[' ||
                     R_SO_HEADER.ENTITY_ID || '],关联交易模式编码[' ||
                     V_SO_TRX_MODE ||
                     '],T_SO_SUPPLIER_REQUIREMENT表未设置对应的ERP OU！' || SQLERRM;
        RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
    END;
  
    -- '1001'; --销售单
    IF (R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE = PKG_SO_PUB.V_BIZ_SRC_BILL_SO) THEN
      --销售单据
      --仓库ID、
      V_INV_ID := R_SO_HEADER.SHIP_INV_ID; --发货仓库ID
      --编码、
      V_INV_CODE := R_SO_HEADER.SHIP_INV_CODE; --发货仓库编码
      --名称
      V_INV_NAME := R_SO_HEADER.SHIP_INV_NAME; --发货仓库名称
      --来源子库编码（仓库编码）
      V_SRC_INV_CODE := R_SO_HEADER.SHIP_INV_CODE; --发货仓库编码
      --目标子库编码
      V_TARGET_INV_CODE := R_SO_HEADER.MIDDLE_INV_CODE; --中间仓库编码
    
      -- '1002'; --销售红冲单
    ELSIF (R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE =
          PKG_SO_PUB.V_BIZ_SRC_BILL_SO_RED) THEN
      --销售红冲单
      V_INV_ID          := R_SO_HEADER.MIDDLE_INV_ID; --中间仓库ID
      V_INV_CODE        := R_SO_HEADER.MIDDLE_INV_CODE; --中间仓库编码
      V_INV_NAME        := R_SO_HEADER.MIDDLE_INV_NAME; --中间仓库名称，主要在进行（子库）库存转移，包括：待结算仓库、退货未结算仓库等，从库存管理的相关配置表获取。
      V_SRC_INV_CODE    := R_SO_HEADER.MIDDLE_INV_CODE; --中间仓库编码
      V_TARGET_INV_CODE := R_SO_HEADER.SHIP_INV_CODE; --发货仓库编码
    
      --'1003'; --退货单
    ELSIF (R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE =
          PKG_SO_PUB.V_BIZ_SRC_BILL_RETURN) THEN
      --退货单
      IF V_RETURN_MODE = '2' THEN
        --退货方式：1-推式，2-拉式源单退回，3-拉式反向销售
      
        V_INV_ID          := R_SO_HEADER.MIDDLE_INV_ID; --中间仓库ID
        V_INV_CODE        := R_SO_HEADER.MIDDLE_INV_CODE; --中间仓库编码
        V_INV_NAME        := R_SO_HEADER.MIDDLE_INV_NAME; --中间仓库名称
        V_SRC_INV_CODE    := R_SO_HEADER.MIDDLE_INV_CODE; --中间仓库编码
        V_TARGET_INV_CODE := R_SO_HEADER.CONSIGNEE_INV_CODE; --收货仓库编码
      ELSIF V_RETURN_MODE = '3' THEN
      
        V_SRC_INV_CODE    := V_RECEIVE_SUBINV; --中间仓库编码
        V_TARGET_INV_CODE := V_RECEIVE_SUBINV; --收货仓库编码
        V_RECEIVE_SUBINV  := R_SO_HEADER.CONSIGNEE_INV_CODE; --收货仓库编码
      END IF;
    
      --'1004'; --退货红冲单
    ELSIF (R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE =
          PKG_SO_PUB.V_BIZ_SRC_BILL_RETURN_RED) THEN
      --退货红冲单
      V_INV_ID          := R_SO_HEADER.MIDDLE_INV_ID;
      V_INV_CODE        := R_SO_HEADER.MIDDLE_INV_CODE;
      V_INV_NAME        := R_SO_HEADER.MIDDLE_INV_NAME;
      V_SRC_INV_CODE    := R_SO_HEADER.MIDDLE_INV_CODE;
      V_TARGET_INV_CODE := R_SO_HEADER.CONSIGNEE_INV_CODE;
    ELSE
      P_ERR_MSG := '折让单（' || R_SO_HEADER.BILL_TYPE_NAME || '）不需要进行物流订单！';
      RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
    END IF;
  
    --NUMBER
    R_LG_ORDER.ID := S_CUX_ICP_LOGIST_REQ_HEADER.NEXTVAL;
  
    --NUMBER 来源头ID
    R_LG_ORDER.SOURCE_HEADER_ID := R_SO_HEADER.SO_HEADER_ID;
  
    --NUMBER 例程集ID
    --退货方式：1-推式，2-拉式源单退回，3-拉式反向销售
  
    -- '1001'; --销售单
    --850 B01 同步物流
    --拉式销售单、反向销售物流订单用B01，其他用B02
    IF (R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE = PKG_SO_PUB.V_BIZ_SRC_BILL_SO) OR
       V_RETURN_MODE = '3' THEN
      R_LG_ORDER.PROC_GROUP_ID := 850; --.850 B01 同步物流
      R_LG_ORDER.GROUP_CODE    := 'B01';
    ELSE
      R_LG_ORDER.PROC_GROUP_ID := 853; --853 B02 同步物流退回;
      R_LG_ORDER.GROUP_CODE    := 'B02';
    END IF;
  
    --VARCHAR2(30) 需方系统
    R_LG_ORDER.REQUIREMENT_SYSTEM := 'GERP';
  
    --VARCHAR2(100) 需方来源单据
    R_LG_ORDER.REQUIREMENT_ORDER_NUM := R_SO_HEADER.SO_NUM;
  
    --VARCHAR2(100) 需方来源单据类型
    R_LG_ORDER.REQUIREMENT_ORDER_TYPE := V_SOURCE_ORDERS_TYPE; --01中转单 / 02财务单;
    \*
                                                    正向  红冲  源单  反向
    REQUIREMENT_ORG_ID  NUMBER  需方OU ID           内销  内销  内销  工厂
    RECEIVE_INV_ORG_ID  NUMBER  接收库存组织ID      内销  内销  内销  工厂
    SUPPLIER_ORG_ID NUMBER  供方OU ID               工厂  工厂  工厂  内销
    SUPPLIER_INV_ORG_ID NUMBER  供方发运库存组织ID  工厂  工厂  工厂  内销
        *\
    IF V_RETURN_MODE = '3' THEN
      --VARCHAR2(100) 需方OU
      R_LG_ORDER.REQUIREMENT_ORG    := R_SO_HEADER.FACTORY_OU_NAME;
      R_LG_ORDER.REQUIREMENT_ORG_ID := R_SO_HEADER.FACTORY_OU_ID;
    
      R_LG_ORDER.RECEIVE_INV_ORG_ID := R_SO_HEADER.ERP_SUBINV_ID; --接收库存组织ID-->RECEIVE_INV_ORG_ID
      R_LG_ORDER.RECEIVE_INV_ORG    := R_SO_HEADER.ERP_SUBINV_CODE; --接收库存组织-->RECEIVE_INV_ORG
    
      --VARCHAR2(100) 供方OU
      R_LG_ORDER.SUPPLIER_ORG    := R_SO_HEADER.ERP_OU_NAME;
      R_LG_ORDER.SUPPLIER_ORG_ID := R_SO_HEADER.ERP_OU_ID;
    
      BEGIN
        SELECT INV_ORG.ORGANIZATION_ID, INV_ORG.ORGANIZATION_CODE
          INTO R_LG_ORDER.SUPPLIER_INV_ORG_ID, --供方发运库存组织ID-->SUPPLIER_INV_ORG_ID
               R_LG_ORDER.SUPPLIER_INV_ORG --供方发运库存组织-->SUPPLIER_INV_ORG
          FROM T_INV_ORGANIZATION INV_ORG
         WHERE INV_ORG.ENTITY_ID = R_SO_HEADER.ENTITY_ID
           AND INV_ORG.OPERATING_UNIT = R_SO_HEADER.ERP_OU_ID
           AND ROWNUM = 1;
      EXCEPTION
        WHEN OTHERS THEN
          P_ERR_MSG := 'OU_ID[' || R_SO_HEADER.ERP_OU_ID || ']，主体ID[' ||
                       R_SO_HEADER.ENTITY_ID || ']查询库存组织信息发生异常：' || SQLERRM;
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      END;
    ELSE
      --VARCHAR2(100) 需方OU
      R_LG_ORDER.REQUIREMENT_ORG    := R_SO_HEADER.ERP_OU_NAME;
      R_LG_ORDER.REQUIREMENT_ORG_ID := R_SO_HEADER.ERP_OU_ID;
      --通过内销OU找到销售库存组织
      BEGIN
        SELECT INV_ORG.ORGANIZATION_ID, INV_ORG.ORGANIZATION_CODE
          INTO R_LG_ORDER.RECEIVE_INV_ORG_ID, --接收库存组织ID-->RECEIVE_INV_ORG_ID
               R_LG_ORDER.RECEIVE_INV_ORG --接收库存组织-->RECEIVE_INV_ORG
          FROM T_INV_ORGANIZATION INV_ORG
         WHERE INV_ORG.ENTITY_ID = R_SO_HEADER.ENTITY_ID
           AND INV_ORG.OPERATING_UNIT = R_SO_HEADER.ERP_OU_ID
           AND ROWNUM = 1;
      EXCEPTION
        WHEN OTHERS THEN
          P_ERR_MSG := 'OU_ID[' || R_SO_HEADER.ERP_OU_ID || ']，主体ID[' ||
                       R_SO_HEADER.ENTITY_ID || ']查询库存组织信息发生异常：' || SQLERRM;
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      END;
      --VARCHAR2(100) 供方OU
      R_LG_ORDER.SUPPLIER_ORG    := R_SO_HEADER.FACTORY_OU_NAME;
      R_LG_ORDER.SUPPLIER_ORG_ID := R_SO_HEADER.FACTORY_OU_ID;
      --直接从头表获取工厂库存组织
      R_LG_ORDER.SUPPLIER_INV_ORG_ID := R_SO_HEADER.ERP_SUBINV_ID; --供方发运库存组织ID-->SUPPLIER_INV_ORG_ID
      R_LG_ORDER.SUPPLIER_INV_ORG    := R_SO_HEADER.ERP_SUBINV_CODE; --供方发运库存组织-->SUPPLIER_INV_ORG
    END IF;
  
    --VARCHAR2(100) 供方系统
    R_LG_ORDER.SUPPLIER_SYSTEM := 'GERP';
  
    --VARCHAR2(100) 供方来源单据
    R_LG_ORDER.SUPPLIER_ORDER_NUM := R_SO_HEADER.SO_NUM;
  
    --VARCHAR2(100) 供方来源单据类型
    R_LG_ORDER.SUPPLIER_ORDER_TYPE := V_SOURCE_ORDERS_TYPE; --01中转单 / 02财务单;
  
    --获取对应的ERP订单类型
    BEGIN
      SELECT TRANSACTION_TYPE_ID, NAME
        INTO R_LG_ORDER.S_ORDER_TYPE_ID, R_LG_ORDER.S_ORDER_TYPE
        FROM V_SO_ERP_TYPE_RELATION
       WHERE SRC_TYPE_ID = R_SO_HEADER.BIZ_SRC_BILL_TYPE_ID
         AND ORG_ID = R_SO_HEADER.ERP_OU_ID
         AND ROWNUM = 1;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        P_ERR_MSG := '销售单据类型[源类型ID：' || R_SO_HEADER.BIZ_SRC_BILL_TYPE_ID ||
                     ']没有配置对应的ERP订单类型或ERP订单类型不属于当前OU[OU ID：' ||
                     R_SO_HEADER.ERP_OU_ID || ']。';
        RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      WHEN OTHERS THEN
        P_ERR_MSG := '获取对应的ERP订单类型发生异常：' || SQLERRM;
        RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
    END;
    \*    --NUMBER 退货销售订单类型ID  
    R_LG_ORDER.S_ORDER_TYPE_ID := R_SO_HEADER.;
    
    --VARCHAR2(100) 退货销售订单类型
    R_LG_ORDER.S_ORDER_TYPE := R_SO_HEADER.;
    
    *\
  
    --VARCHAR2(240) 备注信息
    --R_LG_ORDER.COMMENTS := R_SO_HEADER.REMARK;
  
    --NUMBER 主体ID
    R_LG_ORDER.ENTITY_ID := R_SO_HEADER.ENTITY_ID;
  
    INSERT INTO INTF_CUX_ICP_LOGIST_REQ_HEADER
      (ID, ---->ID
       SOURCE_HEADER_ID, --来源头ID    -->SOURCE_HEADER_ID SO_HEADER_ID
       PROC_GROUP_ID, --例程集ID    -->PROC_GROUP_ID 850 B01 同步物流 853 B02 同步物流退回
       GROUP_CODE,
       --REQUIREMENT_SYSTEM, --需方系统-->REQUIREMENT_SYSTEM GERP
       REQUIREMENT_ORG, --需方OU-->REQUIREMENT_ORG ERP_OU_NAME
       REQUIREMENT_ORG_ID, --需方OU ID-->REQUIREMENT_ORG_ID ERP_OU_ID
       REQUIREMENT_ORDER_NUM, --需方来源单据-->REQUIREMENT_ORDER_NUM SO_NUM
       REQUIREMENT_ORDER_TYPE, --需方来源单据类型-->REQUIREMENT_ORDER_TYPE 01中转单/02财务单
       RECEIVE_INV_ORG_ID, --接收库存组织ID-->RECEIVE_INV_ORG_ID
       RECEIVE_INV_ORG, --接收库存组织-->RECEIVE_INV_ORG
       --SUPPLIER_SYSTEM, --供方系统-->SUPPLIER_SYSTEM GERP
       SUPPLIER_ORG, --供方OU-->SUPPLIER_ORG FACTORY_OU_NAME
       SUPPLIER_ORG_ID, --供方OU ID-->SUPPLIER_ORG_ID FACTORY_OU_ID
       SUPPLIER_INV_ORG_ID, --供方发运库存组织ID-->SUPPLIER_INV_ORG_ID
       SUPPLIER_INV_ORG, --供方发运库存组织-->SUPPLIER_INV_ORG
       --SUPPLIER_ORDER_NUM, --供方来源单据-->SUPPLIER_ORDER_NUM
       --SUPPLIER_ORDER_TYPE, --供方来源单据类型-->SUPPLIER_ORDER_TYPE
       --S_ORDER_TYPE_ID, --退货销售订单类型ID-->S_ORDER_TYPE_ID
       --S_ORDER_TYPE, --退货销售订单类型-->S_ORDER_TYPE
       COMMENTS, --备注信息-->COMMENTS REMARK
       ENTITY_ID, --主体ID--> ENTITY_ID
       STATUS --状态：N待发送；P已发送；S成功--STATUS
       )
    VALUES
      (R_LG_ORDER.ID, ---->ID
       R_LG_ORDER.SOURCE_HEADER_ID, --来源头ID    -->SOURCE_HEADER_ID SO_HEADER_ID
       R_LG_ORDER.PROC_GROUP_ID, --例程集ID    -->PROC_GROUP_ID 850 B01 同步物流 853 B02 同步物流退回
       R_LG_ORDER.GROUP_CODE,
       --R_LG_ORDER.REQUIREMENT_SYSTEM, --需方系统-->REQUIREMENT_SYSTEM GERP
       R_LG_ORDER.REQUIREMENT_ORG, --需方OU-->REQUIREMENT_ORG ERP_OU_NAME
       R_LG_ORDER.REQUIREMENT_ORG_ID, --需方OU ID-->REQUIREMENT_ORG_ID ERP_OU_ID
       R_LG_ORDER.REQUIREMENT_ORDER_NUM, --需方来源单据-->REQUIREMENT_ORDER_NUM SO_NUM
       R_LG_ORDER.REQUIREMENT_ORDER_TYPE, --需方来源单据类型-->REQUIREMENT_ORDER_TYPE 01中转单/02财务单
       R_LG_ORDER.RECEIVE_INV_ORG_ID, --接收库存组织ID-->RECEIVE_INV_ORG_ID
       R_LG_ORDER.RECEIVE_INV_ORG, --接收库存组织-->RECEIVE_INV_ORG
       --R_LG_ORDER.SUPPLIER_SYSTEM, --供方系统-->SUPPLIER_SYSTEM GERP
       R_LG_ORDER.SUPPLIER_ORG, --供方OU-->SUPPLIER_ORG FACTORY_OU_NAME
       R_LG_ORDER.SUPPLIER_ORG_ID, --供方OU ID-->SUPPLIER_ORG_ID FACTORY_OU_ID
       R_LG_ORDER.SUPPLIER_INV_ORG_ID, --供方发运库存组织ID-->SUPPLIER_INV_ORG_ID
       R_LG_ORDER.SUPPLIER_INV_ORG, --供方发运库存组织-->SUPPLIER_INV_ORG
       --R_LG_ORDER.SUPPLIER_ORDER_NUM, --供方来源单据-->SUPPLIER_ORDER_NUM
       --R_LG_ORDER.SUPPLIER_ORDER_TYPE, --供方来源单据类型-->SUPPLIER_ORDER_TYPE
       --R_LG_ORDER.S_ORDER_TYPE_ID, --退货销售订单类型ID-->S_ORDER_TYPE_ID
       --R_LG_ORDER.S_ORDER_TYPE, --退货销售订单类型-->S_ORDER_TYPE
       R_LG_ORDER.COMMENTS, --备注信息-->COMMENTS REMARK
       R_LG_ORDER.ENTITY_ID, --主体ID--> ENTITY_ID
       P_STATUS --状态：N待发送；P已发送；S成功
       );
    --V_PULL_MODE:=PKG_SO_PUB.F_PULL_MODE(B.SO_NUM); 
    -- -1错误,0非拉式,1销售,2红冲,3源单退回,4反向销售,5源单退货红冲，6拉式其他单据类型
    IF V_PULL_MODE IN (1, 4) THEN
    
      FOR REC IN (SELECT *
                    FROM T_SO_LINE A
                   WHERE A.SO_HEADER_ID = R_SO_HEADER.SO_HEADER_ID
                   ORDER BY A.SO_LINE_NUM) LOOP
        R_LG_ORDER_LINE := NULL;
      
        -- NUMBER[965]
        R_LG_ORDER_LINE.ID := S_CUX_ICP_LOGIST_REQ_LINES.NEXTVAL;
      
        --行号 NUMBER[1]
        R_LG_ORDER_LINE.REQ_LINE_NUM := REC.SO_LINE_NUM;
      
        \*
            关联订单号     ORDER_HEADER_ID     
            关联订单行号      ORDER_LINE_NUM      
            来源头信息     SOURCE_HEADER 
            来源头ID      SOURCE_HEADER_ID   
            来源行号      SOURCE_LINE   
            关联物流号 LOGIST_HEADER_ID
            关联物流行ID     LOGIST_LINE_ID
        
              --关联订单号 NUMBER[15264]
              R_LG_ORDER_LINE.ORDER_HEADER_ID := R_LG_ORDER.ID;
            
              --关联订单行号 NUMBER[1]
              R_LG_ORDER_LINE.ORDER_LINE_NUM := REC.SO_LINE_NUM;
              
              --来源头ID NUMBER[1779]
              R_LG_ORDER_LINE.SOURCE_HEADER_ID := R_SO_HEADER.SO_HEADER_ID;
        
              --来源头信息 VARCHAR2(100)[P100000007]
              R_LG_ORDER_LINE.SOURCE_HEADER := R_SO_HEADER.SO_NUM;
              --供方来源行号 NUMBER[1959]
              R_LG_ORDER_LINE.SOURCE_LINE := REC.SO_LINE_ID;
              R_LG_ORDER_LINE.LOGIST_HEADER_ID,--关联物流号
              R_LG_ORDER_LINE.LOGIST_LINE_ID --关联物流行ID
              
              
        *\
        R_LG_ORDER_LINE.SOURCE_HEADER_ID := R_SO_HEADER.SO_HEADER_ID; --来源头ID
        R_LG_ORDER_LINE.REQ_LINE_NUM     := REC.SO_LINE_NUM; --行号
        R_LG_ORDER_LINE.ORDER_LINE_NUM   := REC.SO_LINE_NUM; --关联订单行号
        R_LG_ORDER_LINE.ISS_DATE         := R_SO_HEADER.SETTLE_DATE; --发出日期 销售单结算日期
        R_LG_ORDER_LINE.RECEIVE_DATE     := R_SO_HEADER.SETTLE_DATE; --接收日期 销售单结算日期
        R_LG_ORDER_LINE.SOURCE_HEADER    := R_SO_HEADER.SO_NUM; --来源头信息
        R_LG_ORDER_LINE.SOURCE_LINE      := REC.SO_LINE_ID; --供方来源行号
        --R_LG_ORDER_LINE.REQUIRE_SOURCE_LINE:=REC.SO_LINE_ID; --需方来源行号
        --供方信息物料编码ID NUMBER[]
        R_LG_ORDER_LINE.SUPPLIER_ITEM_ID := REC.ITEM_ID;
      
        --供方信息物料编码 VARCHAR2(100)[31022211001551]
        R_LG_ORDER_LINE.SUPPLIER_ITEM_NUM := REC.ITEM_CODE;
      
        --需方信息物料编码ID NUMBER[]
        R_LG_ORDER_LINE.REQUIRE_ITEM_ID := REC.ITEM_ID;
      
        --需方信息物料编码 VARCHAR2(100)[31022211001551]
        R_LG_ORDER_LINE.REQUIRE_ITEM_NUM := REC.ITEM_CODE;
      
        --单位 VARCHAR2(100)[Tai]
        R_LG_ORDER_LINE.PRIMARY_UNIT_OF_MEASURE := REC.ITEM_UOM;
      
        --发出数量 NUMBER[111]
        R_LG_ORDER_LINE.REQUEST_QUANTITY := REC.ITEM_QTY;
      
        --    --来源子库 VARCHAR2(100)[MA3311]  
        R_LG_ORDER_LINE.SUPPLIER_SORCE_SUBINV := V_SRC_INV_CODE;
      
        ---    --发出商品子库 VARCHAR2(100)[MX1351]  
        R_LG_ORDER_LINE.SUPPLIER_SHIP_SUBINV := V_TARGET_INV_CODE;
      
        ---   --接收子库 VARCHAR2(100)[SWC34B1110] 有问题，取值
        R_LG_ORDER_LINE.RECEIVE_SUBINV := V_RECEIVE_SUBINV;
      
        INSERT INTO INTF_CUX_ICP_LOGIST_REQ_LINES
          (ID,
           HEADERS_ID,
           SOURCE_HEADER_ID,
           REQ_LINE_NUM,
           --ORDER_HEADER_ID,
           ORDER_LINE_NUM,
           --SUPPLIER_ITEM_ID,
           SUPPLIER_ITEM_NUM,
           --REQUIRE_ITEM_ID,
           REQUIRE_ITEM_NUM,
           PRIMARY_UNIT_OF_MEASURE,
           REQUEST_QUANTITY,
           SUPPLIER_SORCE_SUBINV,
           SUPPLIER_SORCE_LOCATION,
           SUPPLIER_SORCE_LOCATION_ID,
           SUPPLIER_SHIP_SUBINV,
           SUPPLIER_SHIP_LOCATION,
           SUPPLIER_SHIP_LOCATION_ID,
           ISS_LOT_NUMBER,
           ISS_DATE,
           RECEIVE_SUBINV,
           RECEIVE_LOCATION,
           RECEIVE_LOCATION_ID,
           RECEIVE_LOT_NUMBER,
           --RECEIVE_DATE,
           SOURCE_HEADER,
           SOURCE_LINE,
           REQUIRE_SOURCE_LINE,
           COMMENTS,
           LOGIST_HEADER_ID, --关联物流号
           LOGIST_LINE_ID)
        VALUES
          (R_LG_ORDER_LINE.ID, --
           R_LG_ORDER.ID,
           R_LG_ORDER_LINE.SOURCE_HEADER_ID, --来源头ID
           R_LG_ORDER_LINE.REQ_LINE_NUM, --行号
           --R_LG_ORDER_LINE.ORDER_HEADER_ID, --关联订单号
           R_LG_ORDER_LINE.ORDER_LINE_NUM, --关联订单行号
           --R_LG_ORDER_LINE.SUPPLIER_ITEM_ID, --供方信息物料编码ID
           R_LG_ORDER_LINE.SUPPLIER_ITEM_NUM, --供方信息物料编码
           --R_LG_ORDER_LINE.REQUIRE_ITEM_ID, --需方信息物料编码ID
           R_LG_ORDER_LINE.REQUIRE_ITEM_NUM, --需方信息物料编码
           R_LG_ORDER_LINE.PRIMARY_UNIT_OF_MEASURE, --单位
           R_LG_ORDER_LINE.REQUEST_QUANTITY, --发出数量
           R_LG_ORDER_LINE.SUPPLIER_SORCE_SUBINV, --来源子库
           R_LG_ORDER_LINE.SUPPLIER_SORCE_LOCATION, --来源货位
           R_LG_ORDER_LINE.SUPPLIER_SORCE_LOCATION_ID, --来源货位ID
           R_LG_ORDER_LINE.SUPPLIER_SHIP_SUBINV, --发出商品子库
           R_LG_ORDER_LINE.SUPPLIER_SHIP_LOCATION, --发出商品货位
           R_LG_ORDER_LINE.SUPPLIER_SHIP_LOCATION_ID, --发出商品货位ID
           R_LG_ORDER_LINE.ISS_LOT_NUMBER, --发出批次
           R_LG_ORDER_LINE.ISS_DATE, --发出日期
           R_LG_ORDER_LINE.RECEIVE_SUBINV, --接收子库
           R_LG_ORDER_LINE.RECEIVE_LOCATION, --接收库存货位
           R_LG_ORDER_LINE.RECEIVE_LOCATION_ID, --接收库存货位ID
           R_LG_ORDER_LINE.RECEIVE_LOT_NUMBER, --接收批次
           --R_LG_ORDER_LINE.RECEIVE_DATE, --接收日期
           R_LG_ORDER_LINE.SOURCE_HEADER, --来源头信息
           R_LG_ORDER_LINE.SOURCE_LINE, --供方来源行号
           R_LG_ORDER_LINE.REQUIRE_SOURCE_LINE, --需方来源行号
           R_LG_ORDER_LINE.COMMENTS, --行备注
           R_LG_ORDER_LINE.LOGIST_HEADER_ID, --关联物流号
           R_LG_ORDER_LINE.LOGIST_LINE_ID --关联物流行ID
           );
      
      END LOOP;
    ELSIF V_PULL_MODE IN (2, 5) THEN
      -- -1错误,0非拉式,1销售,2红冲,3源单退回,4反向销售,5源单退货红冲，6拉式其他单据类型
    
      FOR REC IN (SELECT *
                    FROM T_SO_LINE A
                   WHERE A.SO_HEADER_ID = R_SO_HEADER.SO_HEADER_ID
                   ORDER BY A.SO_LINE_NUM) LOOP
        --查询蓝单关联订单中的
        SELECT ORDER_HEADER_ID
          INTO R_LG_ORDER_LINE.ORDER_HEADER_ID --关联订单号
          FROM INTF_CUX_ICP_LOGIST_REQ_LINES A
         WHERE A.SOURCE_HEADER = R_SO_HEADER.ORIG_SO_NUM --蓝单号
           AND A.REQUIRE_ITEM_NUM = REC.ITEM_CODE;
      
        R_LG_ORDER_LINE := NULL;
      
        -- NUMBER[965]
        R_LG_ORDER_LINE.ID := S_CUX_ICP_LOGIST_REQ_LINES.NEXTVAL;
      
        --行号 NUMBER[1]
        R_LG_ORDER_LINE.REQ_LINE_NUM := REC.SO_LINE_NUM;
      
        R_LG_ORDER_LINE.SOURCE_HEADER_ID := R_SO_HEADER.SO_HEADER_ID; --来源头ID
        R_LG_ORDER_LINE.REQ_LINE_NUM     := REC.SO_LINE_NUM; --行号
        R_LG_ORDER_LINE.ORDER_LINE_NUM   := REC.SO_LINE_NUM; --关联订单行号
        R_LG_ORDER_LINE.ISS_DATE         := R_SO_HEADER.SETTLE_DATE; --发出日期 销售单结算日期
        R_LG_ORDER_LINE.RECEIVE_DATE     := R_SO_HEADER.SETTLE_DATE; --接收日期 销售单结算日期
        R_LG_ORDER_LINE.SOURCE_HEADER    := R_SO_HEADER.SO_NUM; --来源头信息
        R_LG_ORDER_LINE.SOURCE_LINE      := REC.SO_LINE_ID; --供方来源行号
        --R_LG_ORDER_LINE.REQUIRE_SOURCE_LINE:=REC.SO_LINE_ID; --需方来源行号
        --供方信息物料编码ID NUMBER[]
        R_LG_ORDER_LINE.SUPPLIER_ITEM_ID := REC.ITEM_ID;
      
        --供方信息物料编码 VARCHAR2(100)[31022211001551]
        R_LG_ORDER_LINE.SUPPLIER_ITEM_NUM := REC.ITEM_CODE;
      
        --需方信息物料编码ID NUMBER[]
        R_LG_ORDER_LINE.REQUIRE_ITEM_ID := REC.ITEM_ID;
      
        --需方信息物料编码 VARCHAR2(100)[31022211001551]
        R_LG_ORDER_LINE.REQUIRE_ITEM_NUM := REC.ITEM_CODE;
      
        --单位 VARCHAR2(100)[Tai]
        R_LG_ORDER_LINE.PRIMARY_UNIT_OF_MEASURE := REC.ITEM_UOM;
      
        --发出数量 NUMBER[111]
        R_LG_ORDER_LINE.REQUEST_QUANTITY := REC.ITEM_QTY;
      
        --    --来源子库 VARCHAR2(100)[MA3311]  
        R_LG_ORDER_LINE.SUPPLIER_SORCE_SUBINV := V_SRC_INV_CODE;
      
        ---    --发出商品子库 VARCHAR2(100)[MX1351]  
        R_LG_ORDER_LINE.SUPPLIER_SHIP_SUBINV := V_TARGET_INV_CODE;
      
        ---   --接收子库 VARCHAR2(100)[SWC34B1110] 有问题，取值
        R_LG_ORDER_LINE.RECEIVE_SUBINV := V_RECEIVE_SUBINV;
      
        INSERT INTO INTF_CUX_ICP_LOGIST_REQ_LINES
          (ID,
           HEADERS_ID,
           SOURCE_HEADER_ID,
           REQ_LINE_NUM,
           ORDER_HEADER_ID,
           ORDER_LINE_NUM,
           --SUPPLIER_ITEM_ID,
           SUPPLIER_ITEM_NUM,
           --REQUIRE_ITEM_ID,
           REQUIRE_ITEM_NUM,
           PRIMARY_UNIT_OF_MEASURE,
           REQUEST_QUANTITY,
           SUPPLIER_SORCE_SUBINV,
           SUPPLIER_SORCE_LOCATION,
           SUPPLIER_SORCE_LOCATION_ID,
           SUPPLIER_SHIP_SUBINV,
           SUPPLIER_SHIP_LOCATION,
           SUPPLIER_SHIP_LOCATION_ID,
           ISS_LOT_NUMBER,
           ISS_DATE,
           RECEIVE_SUBINV,
           RECEIVE_LOCATION,
           RECEIVE_LOCATION_ID,
           RECEIVE_LOT_NUMBER,
           --RECEIVE_DATE,
           SOURCE_HEADER,
           SOURCE_LINE,
           REQUIRE_SOURCE_LINE,
           COMMENTS,
           LOGIST_HEADER_ID, --关联物流号
           LOGIST_LINE_ID)
        VALUES
          (R_LG_ORDER_LINE.ID, --
           R_LG_ORDER.ID,
           R_LG_ORDER_LINE.SOURCE_HEADER_ID, --来源头ID
           R_LG_ORDER_LINE.REQ_LINE_NUM, --行号
           R_LG_ORDER_LINE.ORDER_HEADER_ID, --关联订单号
           R_LG_ORDER_LINE.ORDER_LINE_NUM, --关联订单行号
           --R_LG_ORDER_LINE.SUPPLIER_ITEM_ID, --供方信息物料编码ID
           R_LG_ORDER_LINE.SUPPLIER_ITEM_NUM, --供方信息物料编码
           --R_LG_ORDER_LINE.REQUIRE_ITEM_ID, --需方信息物料编码ID
           R_LG_ORDER_LINE.REQUIRE_ITEM_NUM, --需方信息物料编码
           R_LG_ORDER_LINE.PRIMARY_UNIT_OF_MEASURE, --单位
           R_LG_ORDER_LINE.REQUEST_QUANTITY, --发出数量
           R_LG_ORDER_LINE.SUPPLIER_SORCE_SUBINV, --来源子库
           R_LG_ORDER_LINE.SUPPLIER_SORCE_LOCATION, --来源货位
           R_LG_ORDER_LINE.SUPPLIER_SORCE_LOCATION_ID, --来源货位ID
           R_LG_ORDER_LINE.SUPPLIER_SHIP_SUBINV, --发出商品子库
           R_LG_ORDER_LINE.SUPPLIER_SHIP_LOCATION, --发出商品货位
           R_LG_ORDER_LINE.SUPPLIER_SHIP_LOCATION_ID, --发出商品货位ID
           R_LG_ORDER_LINE.ISS_LOT_NUMBER, --发出批次
           R_LG_ORDER_LINE.ISS_DATE, --发出日期
           R_LG_ORDER_LINE.RECEIVE_SUBINV, --接收子库
           R_LG_ORDER_LINE.RECEIVE_LOCATION, --接收库存货位
           R_LG_ORDER_LINE.RECEIVE_LOCATION_ID, --接收库存货位ID
           R_LG_ORDER_LINE.RECEIVE_LOT_NUMBER, --接收批次
           --R_LG_ORDER_LINE.RECEIVE_DATE, --接收日期
           R_LG_ORDER_LINE.SOURCE_HEADER, --来源头信息
           R_LG_ORDER_LINE.SOURCE_LINE, --供方来源行号
           R_LG_ORDER_LINE.REQUIRE_SOURCE_LINE, --需方来源行号
           R_LG_ORDER_LINE.COMMENTS, --行备注
           R_LG_ORDER_LINE.LOGIST_HEADER_ID, --关联物流号
           R_LG_ORDER_LINE.LOGIST_LINE_ID --关联物流行ID
           );
      
      END LOOP;
    ELSIF V_PULL_MODE IN (3) THEN
      -- -1错误,0非拉式,1销售,2红冲,3源单退回,4反向销售,5拉式其他单据类型
    
      FOR REC IN (SELECT *
                    FROM T_SO_LINE A
                   WHERE A.SO_HEADER_ID = R_SO_HEADER.SO_HEADER_ID
                   ORDER BY A.SO_LINE_NUM) LOOP
        --查询蓝单关联订单中的
        SELECT ORDER_HEADER_ID
          INTO R_LG_ORDER_LINE.ORDER_HEADER_ID --关联订单号
          FROM INTF_CUX_ICP_LOGIST_REQ_LINES A
         WHERE A.SOURCE_HEADER = R_SO_HEADER.RETURN_ORIG_SO_NUM --源单号
           AND A.REQUIRE_ITEM_NUM = REC.ITEM_CODE;
      
        R_LG_ORDER_LINE := NULL;
      
        -- NUMBER[965]
        R_LG_ORDER_LINE.ID := S_CUX_ICP_LOGIST_REQ_LINES.NEXTVAL;
      
        --行号 NUMBER[1]
        R_LG_ORDER_LINE.REQ_LINE_NUM := REC.SO_LINE_NUM;
      
        R_LG_ORDER_LINE.SOURCE_HEADER_ID := R_SO_HEADER.SO_HEADER_ID; --来源头ID
        R_LG_ORDER_LINE.REQ_LINE_NUM     := REC.SO_LINE_NUM; --行号
        R_LG_ORDER_LINE.ORDER_LINE_NUM   := REC.SO_LINE_NUM; --关联订单行号
        R_LG_ORDER_LINE.ISS_DATE         := R_SO_HEADER.SETTLE_DATE; --发出日期 销售单结算日期
        R_LG_ORDER_LINE.RECEIVE_DATE     := R_SO_HEADER.SETTLE_DATE; --接收日期 销售单结算日期
        R_LG_ORDER_LINE.SOURCE_HEADER    := R_SO_HEADER.SO_NUM; --来源头信息
        R_LG_ORDER_LINE.SOURCE_LINE      := REC.SO_LINE_ID; --供方来源行号
        --R_LG_ORDER_LINE.REQUIRE_SOURCE_LINE:=REC.SO_LINE_ID; --需方来源行号
        --供方信息物料编码ID NUMBER[]
        R_LG_ORDER_LINE.SUPPLIER_ITEM_ID := REC.ITEM_ID;
      
        --供方信息物料编码 VARCHAR2(100)[31022211001551]
        R_LG_ORDER_LINE.SUPPLIER_ITEM_NUM := REC.ITEM_CODE;
      
        --需方信息物料编码ID NUMBER[]
        R_LG_ORDER_LINE.REQUIRE_ITEM_ID := REC.ITEM_ID;
      
        --需方信息物料编码 VARCHAR2(100)[31022211001551]
        R_LG_ORDER_LINE.REQUIRE_ITEM_NUM := REC.ITEM_CODE;
      
        --单位 VARCHAR2(100)[Tai]
        R_LG_ORDER_LINE.PRIMARY_UNIT_OF_MEASURE := REC.ITEM_UOM;
      
        --发出数量 NUMBER[111]
        R_LG_ORDER_LINE.REQUEST_QUANTITY := REC.ITEM_QTY;
      
        --    --来源子库 VARCHAR2(100)[MA3311]  
        R_LG_ORDER_LINE.SUPPLIER_SORCE_SUBINV := V_SRC_INV_CODE;
      
        ---    --发出商品子库 VARCHAR2(100)[MX1351]  
        R_LG_ORDER_LINE.SUPPLIER_SHIP_SUBINV := V_TARGET_INV_CODE;
      
        ---   --接收子库 VARCHAR2(100)[SWC34B1110] 有问题，取值
        R_LG_ORDER_LINE.RECEIVE_SUBINV := V_RECEIVE_SUBINV;
      
        INSERT INTO INTF_CUX_ICP_LOGIST_REQ_LINES
          (ID,
           HEADERS_ID,
           SOURCE_HEADER_ID,
           REQ_LINE_NUM,
           ORDER_HEADER_ID,
           ORDER_LINE_NUM,
           --SUPPLIER_ITEM_ID,
           SUPPLIER_ITEM_NUM,
           --REQUIRE_ITEM_ID,
           REQUIRE_ITEM_NUM,
           PRIMARY_UNIT_OF_MEASURE,
           REQUEST_QUANTITY,
           SUPPLIER_SORCE_SUBINV,
           SUPPLIER_SORCE_LOCATION,
           SUPPLIER_SORCE_LOCATION_ID,
           SUPPLIER_SHIP_SUBINV,
           SUPPLIER_SHIP_LOCATION,
           SUPPLIER_SHIP_LOCATION_ID,
           ISS_LOT_NUMBER,
           ISS_DATE,
           RECEIVE_SUBINV,
           RECEIVE_LOCATION,
           RECEIVE_LOCATION_ID,
           RECEIVE_LOT_NUMBER,
           --RECEIVE_DATE,
           SOURCE_HEADER,
           SOURCE_LINE,
           REQUIRE_SOURCE_LINE,
           COMMENTS,
           LOGIST_HEADER_ID, --关联物流号
           LOGIST_LINE_ID)
        VALUES
          (R_LG_ORDER_LINE.ID, --
           R_LG_ORDER.ID,
           R_LG_ORDER_LINE.SOURCE_HEADER_ID, --来源头ID
           R_LG_ORDER_LINE.REQ_LINE_NUM, --行号
           R_LG_ORDER_LINE.ORDER_HEADER_ID, --关联订单号
           R_LG_ORDER_LINE.ORDER_LINE_NUM, --关联订单行号
           --R_LG_ORDER_LINE.SUPPLIER_ITEM_ID, --供方信息物料编码ID
           R_LG_ORDER_LINE.SUPPLIER_ITEM_NUM, --供方信息物料编码
           --R_LG_ORDER_LINE.REQUIRE_ITEM_ID, --需方信息物料编码ID
           R_LG_ORDER_LINE.REQUIRE_ITEM_NUM, --需方信息物料编码
           R_LG_ORDER_LINE.PRIMARY_UNIT_OF_MEASURE, --单位
           R_LG_ORDER_LINE.REQUEST_QUANTITY, --发出数量
           R_LG_ORDER_LINE.SUPPLIER_SORCE_SUBINV, --来源子库
           R_LG_ORDER_LINE.SUPPLIER_SORCE_LOCATION, --来源货位
           R_LG_ORDER_LINE.SUPPLIER_SORCE_LOCATION_ID, --来源货位ID
           R_LG_ORDER_LINE.SUPPLIER_SHIP_SUBINV, --发出商品子库
           R_LG_ORDER_LINE.SUPPLIER_SHIP_LOCATION, --发出商品货位
           R_LG_ORDER_LINE.SUPPLIER_SHIP_LOCATION_ID, --发出商品货位ID
           R_LG_ORDER_LINE.ISS_LOT_NUMBER, --发出批次
           R_LG_ORDER_LINE.ISS_DATE, --发出日期
           R_LG_ORDER_LINE.RECEIVE_SUBINV, --接收子库
           R_LG_ORDER_LINE.RECEIVE_LOCATION, --接收库存货位
           R_LG_ORDER_LINE.RECEIVE_LOCATION_ID, --接收库存货位ID
           R_LG_ORDER_LINE.RECEIVE_LOT_NUMBER, --接收批次
           --R_LG_ORDER_LINE.RECEIVE_DATE, --接收日期
           R_LG_ORDER_LINE.SOURCE_HEADER, --来源头信息
           R_LG_ORDER_LINE.SOURCE_LINE, --供方来源行号
           R_LG_ORDER_LINE.REQUIRE_SOURCE_LINE, --需方来源行号
           R_LG_ORDER_LINE.COMMENTS, --行备注
           R_LG_ORDER_LINE.LOGIST_HEADER_ID, --关联物流号
           R_LG_ORDER_LINE.LOGIST_LINE_ID --关联物流行ID
           );
      
      END LOOP;
    END IF;
    P_TABLE_ACTION_LOG('INTF_CUX_ICP_LOGIST_REQ_HEADER', --操作表名称
                       '销售单生成物流订单', --操作说明
                       R_SO_HEADER.SO_NUM, --关键主键
                       0, --是否出错，1出错，0未出错
                       '' --错误信息
                       );
  EXCEPTION
    WHEN OTHERS THEN
      P_RESULT  := -1;
      P_ERR_MSG := '销售单据头[ID：' || P_SO_HEADER_ID || ']生成关联物流订单出错，原因：' ||
                   P_ERR_MSG || SQLERRM;
      P_TABLE_ACTION_LOG('INTF_CUX_ICP_LOGIST_REQ_HEADER', --操作表名称
                         '销售单生成物流订单', --操作说明
                         R_SO_HEADER.SO_NUM, --关键主键
                         1, --是否出错，1出错，0未出错
                         P_ERR_MSG --错误信息
                         );
  END;*/
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-07-22
  *     创建者：xiongpl
  *   功能说明：跨事业部关联物流订单，如中央内销销售给热水内销，两内销间关联物流
  */
  -------------------------------------------------------------------------------  
  PROCEDURE P_SO_TO_LG_ORDER_ENTITY(P_SO_HEADER_ID IN T_SO_HEADER.SO_HEADER_ID%TYPE, --销售单头id
                             P_STATUS       IN VARCHAR2, --状态：N待发送；P已发送；S成功，如果前面有关联订单，需要将状态传空值，这样才可以实现串行
                             P_RESULT       IN OUT NUMBER, --返回错误ID
                             P_ERR_MSG      IN OUT VARCHAR2 --返回错误信息
                             ) AS
    --销售单据头
    CURSOR C_SO_HEADER IS
      SELECT * FROM T_SO_HEADER WHERE SO_HEADER_ID = P_SO_HEADER_ID;
    R_SO_HEADER C_SO_HEADER%ROWTYPE;
  
    --物流订单头表
    R_LG_ORDER INTF_CUX_ICP_LOGIST_REQ_HEADER%ROWTYPE;
  
    --物流订单行表
    R_LG_ORDER_LINE INTF_CUX_ICP_LOGIST_REQ_LINES%ROWTYPE;
  
    --库存组织编码
    V_INV_ORG_ZCODE T_INV_ORGANIZATION.ORGANIZATION_CODE%TYPE;
    --供方财务仓
    V_SUPPLIER_INV_CODE T_INV_INVENTORIES.INVENTORY_CODE%TYPE;
    --来源子库编码（仓库编码）
    V_SUPPLIER_SORCE_SUBINV T_INV_INVENTORIES.INVENTORY_CODE%TYPE;
  
    --目标子库编码
    V_SUPPLIER_SHIP_SUBINV T_INV_INVENTORIES.INVENTORY_CODE%TYPE;
  
    --接收子库
    V_RECEIVE_SUBINV INTF_CUX_ICP_LOGIST_REQ_LINES.RECEIVE_SUBINV%TYPE;
    
    --取的中间仓   chenzh 2015/05/28
    V_MIDDLE_INV_CODE T_INV_INVENTORIES.INVENTORY_CODE%TYPE;
  
    --仓库ID、编码、名称
    V_INV_ID   T_INV_INVENTORIES.INVENTORY_ID%TYPE;
    V_INV_CODE T_INV_INVENTORIES.INVENTORY_CODE%TYPE;
    V_INV_NAME T_INV_INVENTORIES.INVENTORY_NAME%TYPE;
  
    --RETURN_MODE VARCHAR2(2) 退货方式：1-推式，2-拉式源单退回，3-拉式反向销售
    V_RETURN_MODE T_SO_HEADER.RETURN_MODE%TYPE;
  
    V_COUNT NUMBER;
    --关联交易模式 chen.wj
    V_SO_TRX_MODE VARCHAR2(10);
    
    --是否启用关联交易仓库
    V_SO_ICP_INV_ENABLE VARCHAR2(10);
  
    V_PULL_MODE NUMBER;
    --需方主体、需方主体是否启用、异步物流接收状态
    --V_REQUIREMENT_ENTITY_ID  NUMBER;
    V_SO_PO_GEN_ENABLE       VARCHAR(32);
    V_STATUS_RECEIVE         VARCHAR(32) := 'N';  
    V_ICP_LG_RECEIVE_MODE              VARCHAR(32);
    
    V_PRICE         NUMBER; --含税价格,源单退回取价，关联开票用
  BEGIN
    --初始返回值
    P_RESULT  := PKG_SO_PUB.V_RESULT;
    P_ERR_MSG := PKG_SO_PUB.V_SUCCESS;
  
    --获取销售单头信息
    OPEN C_SO_HEADER;
    FETCH C_SO_HEADER
      INTO R_SO_HEADER;
    CLOSE C_SO_HEADER;
    --退货方式：1-推式，2-拉式源单退回，3-拉式反向销售
    V_RETURN_MODE := NVL(R_SO_HEADER.RETURN_MODE, '1'); --默认1-推式
  
    --V_PULL_MODE := PKG_SO_PUB.F_PULL_MODE(R_SO_HEADER.SO_NUM); -- -1错误,0非拉式,1销售,2红冲,3源单退回,4反向销售,5源单退货红冲，6拉式其他单据类型
  
    --判断是否重复生成物流
    SELECT COUNT(*)
      INTO V_COUNT
      FROM INTF_CUX_ICP_LOGIST_REQ_HEADER
     WHERE (REQUIREMENT_ORDER_TYPE = V_SOURCE_ORDERS_TYPE_G OR
           SUPPLIER_ORDER_TYPE = V_SOURCE_ORDERS_TYPE_G)
       AND REQUIREMENT_ORDER_NUM = 'G'||R_SO_HEADER.SO_NUM;
    IF V_COUNT > 0 THEN
      P_ERR_MSG := '销售单据[单据号：G' || R_SO_HEADER.SO_NUM ||
                   ']已生成物流订单[INTF_CUX_ICP_LOGIST_REQ_HEADER]表记录';
      RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
    END IF;
  
    --add by chen.wj 20150206
    -- -1错误,0非拉式,1销售,2红冲,3源单退回,4反向销售,5源单退货红冲，6拉式其他单据类型
    /*
    'TRX001'; --推式成品销售
    'TRX002'; --推式销售结算
    'TRX003'; --拉式成品销售
    'TRX004'; --拉式源单退回
    'TRX005'; --拉式反向销售
    */
    V_PULL_MODE := PKG_SO_PUB.F_PULL_MODE(R_SO_HEADER.SO_NUM);
  
    --NUMBER
    R_LG_ORDER.ID := S_CUX_ICP_LOGIST_REQ_HEADER.NEXTVAL;
  
    --NUMBER 来源头ID
    R_LG_ORDER.SOURCE_HEADER_ID := R_SO_HEADER.SO_HEADER_ID;
  
    --NUMBER 例程集ID
    --退货方式：1-推式，2-拉式源单退回，3-拉式反向销售
  
    -- '1001'; --销售单
    --850 B01 同步物流
    --拉式销售单、退货红冲单、反向销售物流订单用B01，其他用B02
    IF V_RETURN_MODE = '3'  THEN
       P_ERR_MSG := '此销售单[ID：' || P_SO_HEADER_ID || ']不允许做反向销售业务' ;
       RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
    END IF;
    --875 B08 单边采购接收;877 B09 单边采购退回;   edited by zhoujg3 2016-09-19
    IF (R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE IN
       (PKG_SO_PUB.V_BIZ_SRC_BILL_SO, PKG_SO_PUB.V_BIZ_SRC_BILL_RETURN_RED)) THEN
      /**
      R_LG_ORDER.PROC_GROUP_ID := 862; --.850 B01 异步物流
      R_LG_ORDER.GROUP_CODE    := 'B04';
      */
      R_LG_ORDER.PROC_GROUP_ID := 875; --.875 B08 单边采购接收
      R_LG_ORDER.GROUP_CODE    := 'B08';
    ELSE
      /**
      R_LG_ORDER.PROC_GROUP_ID := 866; --853 B02 异步物流退回;
      R_LG_ORDER.GROUP_CODE    := 'B05';
      */
      R_LG_ORDER.PROC_GROUP_ID := 877; --877 B09 单边采购退回;
      R_LG_ORDER.GROUP_CODE    := 'B09';
    END IF;
  
    --VARCHAR2(30) 需方系统
    R_LG_ORDER.REQUIREMENT_SYSTEM := 'GERP';
  
    --VARCHAR2(100) 需方来源单据
    R_LG_ORDER.REQUIREMENT_ORDER_NUM := R_SO_HEADER.SO_NUM;
  
    --VARCHAR2(100) 需方来源单据类型
    R_LG_ORDER.REQUIREMENT_ORDER_TYPE := V_SOURCE_ORDERS_TYPE_G; --03事业部关联交易单边模式;

    IF R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE IN (PKG_SO_PUB.V_BIZ_SRC_BILL_SO_RED,PKG_SO_PUB.V_BIZ_SRC_BILL_RETURN) THEN
      --销售红冲与有源退货
      SELECT COUNT(*) INTO V_COUNT
          FROM T_SO_HEADER A
         WHERE A.SO_NUM = NVL(R_SO_HEADER.ORIG_SO_NUM,R_SO_HEADER.RETURN_ORIG_SO_NUM);
      IF V_COUNT=0 THEN
          P_ERR_MSG := '销售红冲/退货单号[' || R_SO_HEADER.SO_NUM || ']查询蓝单[' || NVL(R_SO_HEADER.ORIG_SO_NUM,R_SO_HEADER.RETURN_ORIG_SO_NUM) || ']信息异常';
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      END IF;    
    END IF;      
    --IF R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE IN (PKG_SO_PUB.V_BIZ_SRC_BILL_SO,PKG_SO_PUB.V_BIZ_SRC_BILL_RETURN_RED) THEN
    --正向销售,退货红冲单
    --ELSIF R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE IN (PKG_SO_PUB.V_BIZ_SRC_BILL_SO_RED,PKG_SO_PUB.V_BIZ_SRC_BILL_RETURN) THEN    
    --销售红冲，有源退货
    --END IF;   
    
    /**
    --获取需方主体,并获取requirement_entity_id生成中转单是否启用；
     SELECT DISTINCT SR.REQUIREMENT_ENTITY_ID INTO V_REQUIREMENT_ENTITY_ID
       FROM CIMS.T_SO_SUPPLIER_REQUIRE_ENTITY SR
      WHERE SR.SUPPLIER_ENTITY_ID = R_SO_HEADER.ENTITY_ID
        AND SR.REQUIREMENT_CUSTOMER_ID = R_SO_HEADER.CUSTOMER_ID;
     
     PKG_BD.P_GET_PARAMETER_VALUE('SO_PO_GEN_ENABLE',
                                 V_REQUIREMENT_ENTITY_ID,
                                 NULL,
                                 NULL,
                                 V_SO_PO_GEN_ENABLE); 
     IF V_SO_PO_GEN_ENABLE = 'N' THEN
        V_STATUS_RECEIVE := 'N'; 
     END IF;
     */
      BEGIN
         --根据供方业务主体、供方OU、需方客户 对应的'营销模式'； 
         SELECT T.ICP_LG_RECEIVE_MODE INTO V_ICP_LG_RECEIVE_MODE
            FROM T_SO_SUPPLIER_REQUIRE_ENTITY T
           WHERE T.SUPPLIER_ENTITY_ID = R_SO_HEADER.ENTITY_ID
              and T.SUPPLIER_OU_ID=R_SO_HEADER.ERP_OU_ID
              and T.REQUIREMENT_CUSTOMER_ID=R_SO_HEADER.CUSTOMER_ID;           
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          P_ERR_MSG := '事业部客户[' || R_SO_HEADER.CUSTOMER_NAME || ']在事业部供需关系配置中未设置PO接收模式！';
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
        WHEN OTHERS THEN
          P_ERR_MSG := '查询事业部客户[' || R_SO_HEADER.CUSTOMER_NAME || ']在事业部供需关系配置中PO接收模式出现异常！'||SQLERRM;
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      END; 

     --内部关联交易营销模式: 02 关联物流第二步需对端系统例如电商，回写签收信息。
     IF (V_ICP_LG_RECEIVE_MODE = '2' AND PKG_SO_PUB.V_BIZ_SRC_BILL_SO = R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE) THEN
        V_STATUS_RECEIVE := NULL;
     END IF;
     
     
      --begin   取供需
      --供方:OU
      R_LG_ORDER.SUPPLIER_ORG    := R_SO_HEADER.ERP_OU_NAME;
      R_LG_ORDER.SUPPLIER_ORG_ID := R_SO_HEADER.ERP_OU_ID;
      --供方：发运库存组织
      BEGIN
        -- -1错误,0非拉式,1销售,2红冲,3源单退回,4反向销售,5源单退货红冲，6拉式其他单据类型
        /*
        'TRX001'; --推式成品销售
        'TRX002'; --推式销售结算
        'TRX003'; --拉式成品销售
        'TRX004'; --拉式源单退回
        'TRX005'; --拉式反向销售
        */          
        SELECT DECODE(V_PULL_MODE,
                      1,
                      PKG_SO_PUB.V_SO_TRX_MODE_003,
                      2,
                      PKG_SO_PUB.V_SO_TRX_MODE_004,
                      3,
                      PKG_SO_PUB.V_SO_TRX_MODE_004,
                      4,
                      PKG_SO_PUB.V_SO_TRX_MODE_005,
                      5,
                      PKG_SO_PUB.V_SO_TRX_MODE_003,
                      V_PULL_MODE)
          INTO V_SO_TRX_MODE
          FROM DUAL;
        --供方：来源子库、目标子库  
        IF V_SO_TRX_MODE = PKG_SO_PUB.V_SO_TRX_MODE_005 THEN
          P_ERR_MSG := '此销售单[ID：' || P_SO_HEADER_ID || ']不允许做反向销售业务' ;
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
        ELSIF V_SO_TRX_MODE ='0' THEN --推式
          R_LG_ORDER.SUPPLIER_INV_ORG_ID := R_SO_HEADER.ERP_SUBINV_ID;
          R_LG_ORDER.SUPPLIER_INV_ORG := R_SO_HEADER.ERP_SUBINV_CODE;   
          V_SUPPLIER_SORCE_SUBINV := R_SO_HEADER.MIDDLE_INV_CODE;    
          V_SUPPLIER_SHIP_SUBINV := R_SO_HEADER.NOSETTLED_INVENTORY_CODE;--发出仓来自未结算仓
          /**
          IF R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE IN --销售单、退货红冲
                 (PKG_SO_PUB.V_BIZ_SRC_BILL_SO,PKG_SO_PUB.V_BIZ_SRC_BILL_RETURN_RED) THEN   
              V_SUPPLIER_SHIP_SUBINV := R_SO_HEADER.NOSETTLED_INVENTORY_CODE;--发出仓来自未结算仓
          ELSIF R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE IN  --销售红冲、有源退货
                 (PKG_SO_PUB.V_BIZ_SRC_BILL_SO_RED,PKG_SO_PUB.V_BIZ_SRC_BILL_RETURN) THEN
            BEGIN
              SELECT A.MIDDLE_INV_CODE
                INTO V_SUPPLIER_SHIP_SUBINV
                FROM T_SO_HEADER A
               WHERE A.SO_NUM = nvl(R_SO_HEADER.RETURN_ORIG_SO_NUM,R_SO_HEADER.ORIG_SO_NUM);
            EXCEPTION
              WHEN OTHERS THEN
                P_ERR_MSG := '销售单号[' || R_SO_HEADER.SO_NUM || ']查询源单信息异常';
                RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
            END;
          END IF;  
          */          
        ELSE  --拉式
          SELECT ERP_SUBINV_ID, --库存组织
                 ERP_SUBINV_CODE, --库存组织编码
                 SUBINVENTORY_CODE --来源子库编码
            INTO R_LG_ORDER.SUPPLIER_INV_ORG_ID, R_LG_ORDER.SUPPLIER_INV_ORG,V_SUPPLIER_INV_CODE
            FROM T_SO_SUPPLIER_REQUIREMENT T
           WHERE T.ENTITY_ID = R_SO_HEADER.ENTITY_ID
             AND T.REQUIREMENT_OU_ID = R_SO_HEADER.ERP_OU_ID
             AND T.SUPPLIER_OU_ID = R_SO_HEADER.FACTORY_OU_ID
             AND T.TRADE_MODE_CODE = V_SO_TRX_MODE;
           --不经未结或退未结仓 
           V_SUPPLIER_SORCE_SUBINV  := V_SUPPLIER_INV_CODE;  --来源子库编码     
           V_SUPPLIER_SHIP_SUBINV := V_SUPPLIER_INV_CODE; --目标子库编码     
                     
        END IF;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          P_ERR_MSG := '工厂OU ID[' || R_SO_HEADER.FACTORY_OU_ID || '],主体ID[' ||
                       R_SO_HEADER.ENTITY_ID || '],关联交易模式编码[' ||
                       V_SO_TRX_MODE ||
                       '],T_SO_SUPPLIER_REQUIREMENT表未设置对应的ERP OU！';
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
        WHEN OTHERS THEN
          P_ERR_MSG := '工厂OU ID[' || R_SO_HEADER.FACTORY_OU_ID || '],主体ID[' ||
                       R_SO_HEADER.ENTITY_ID || '],关联交易模式编码[' ||
                       V_SO_TRX_MODE ||
                       '],T_SO_SUPPLIER_REQUIREMENT表未设置对应的ERP OU！' ||
                       SQLERRM;
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      END;            
      
      --需方：(采购方内销公司)OU、库存组织、仓库
      BEGIN
         --根据供方业务主体、供方OU、需方客户 获取需方信息； 
         SELECT REQUIREMENT_OU_ID,REQUIREMENT_OU_NAME,
                 REQUIREMENT_ORGANIZATION_ID, --库存组织
                 REQUIREMENT_ORGANIZATION_CODE, --库存组织编码
                 REQUIREMENT_INVENTORY_CODE
            INTO R_LG_ORDER.REQUIREMENT_ORG_ID, R_LG_ORDER.REQUIREMENT_ORG,
                 R_LG_ORDER.RECEIVE_INV_ORG_ID, R_LG_ORDER.RECEIVE_INV_ORG,V_RECEIVE_SUBINV
            FROM T_SO_SUPPLIER_REQUIRE_ENTITY T
           WHERE T.SUPPLIER_ENTITY_ID = R_SO_HEADER.Entity_Id 
              and T.SUPPLIER_OU_ID=R_SO_HEADER.ERP_OU_ID
              and T.REQUIREMENT_CUSTOMER_ID=R_SO_HEADER.CUSTOMER_ID;           
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          P_ERR_MSG := '事业部客户[' || R_SO_HEADER.Customer_Name || ']在供需关系T_SO_SUPPLIER_REQUIRE_ENTITY中未进行配置！';
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
        WHEN OTHERS THEN
          P_ERR_MSG := '事业部客户[' || R_SO_HEADER.Customer_Name || ']在供需关系T_SO_SUPPLIER_REQUIRE_ENTITY中未进行配置！'||SQLERRM;
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      END;           
    --end   取供需
  
    --VARCHAR2(100) 供方系统
    R_LG_ORDER.SUPPLIER_SYSTEM := 'GERP';
  
    --VARCHAR2(100) 供方来源单据
    R_LG_ORDER.SUPPLIER_ORDER_NUM := 'G'||R_SO_HEADER.SO_NUM;
  
    --VARCHAR2(100) 供方来源单据类型
    R_LG_ORDER.SUPPLIER_ORDER_TYPE := V_SOURCE_ORDERS_TYPE_G; --01中转单 / 02财务单;
  
    --NUMBER 主体ID
    R_LG_ORDER.ENTITY_ID := R_SO_HEADER.ENTITY_ID;
  
    INSERT INTO INTF_CUX_ICP_LOGIST_REQ_HEADER
      (ID, ---->ID
       SOURCE_HEADER_ID, --来源头ID    -->SOURCE_HEADER_ID SO_HEADER_ID
       PROC_GROUP_ID, --例程集ID    -->PROC_GROUP_ID 850 B01 同步物流 853 B02 同步物流退回
       GROUP_CODE,
       --REQUIREMENT_SYSTEM, --需方系统-->REQUIREMENT_SYSTEM GERP
       REQUIREMENT_ORG, --需方OU-->REQUIREMENT_ORG ERP_OU_NAME
       REQUIREMENT_ORG_ID, --需方OU ID-->REQUIREMENT_ORG_ID ERP_OU_ID
       REQUIREMENT_ORDER_NUM, --需方来源单据-->REQUIREMENT_ORDER_NUM SO_NUM
       REQUIREMENT_ORDER_TYPE, --需方来源单据类型-->REQUIREMENT_ORDER_TYPE 01中转单/02财务单
       RECEIVE_INV_ORG_ID, --接收库存组织ID-->RECEIVE_INV_ORG_ID
       RECEIVE_INV_ORG, --接收库存组织-->RECEIVE_INV_ORG
       --SUPPLIER_SYSTEM, --供方系统-->SUPPLIER_SYSTEM GERP
       SUPPLIER_ORG, --供方OU-->SUPPLIER_ORG FACTORY_OU_NAME
       SUPPLIER_ORG_ID, --供方OU ID-->SUPPLIER_ORG_ID FACTORY_OU_ID
       SUPPLIER_INV_ORG_ID, --供方发运库存组织ID-->SUPPLIER_INV_ORG_ID
       SUPPLIER_INV_ORG, --供方发运库存组织-->SUPPLIER_INV_ORG
       --SUPPLIER_ORDER_NUM, --供方来源单据-->SUPPLIER_ORDER_NUM
       --SUPPLIER_ORDER_TYPE, --供方来源单据类型-->SUPPLIER_ORDER_TYPE
       --S_ORDER_TYPE_ID, --退货销售订单类型ID-->S_ORDER_TYPE_ID
       --S_ORDER_TYPE, --退货销售订单类型-->S_ORDER_TYPE
       COMMENTS, --备注信息-->COMMENTS REMARK
       ENTITY_ID, --主体ID--> ENTITY_ID
      -- STATUS_SOURCE, --状态：N待发送；P已发送；S成功--
       STATUS,
       STATUS_SUPPLIER,
       STATUS_RECEIVE,
       ICP_LG_RECEIVE_MODE
       )
    VALUES
      (R_LG_ORDER.ID, ---->ID
       R_LG_ORDER.SOURCE_HEADER_ID, --来源头ID    -->SOURCE_HEADER_ID SO_HEADER_ID
       R_LG_ORDER.PROC_GROUP_ID, --例程集ID    -->PROC_GROUP_ID 850 B01 同步物流 853 B02 同步物流退回
       R_LG_ORDER.GROUP_CODE,
       --R_LG_ORDER.REQUIREMENT_SYSTEM, --需方系统-->REQUIREMENT_SYSTEM GERP
       R_LG_ORDER.REQUIREMENT_ORG, --需方OU-->REQUIREMENT_ORG ERP_OU_NAME
       R_LG_ORDER.REQUIREMENT_ORG_ID, --需方OU ID-->REQUIREMENT_ORG_ID ERP_OU_ID
       'G'||R_LG_ORDER.REQUIREMENT_ORDER_NUM, --需方来源单据-->REQUIREMENT_ORDER_NUM SO_NUM
       R_LG_ORDER.REQUIREMENT_ORDER_TYPE, --需方来源单据类型-->REQUIREMENT_ORDER_TYPE 01中转单/02财务单
       R_LG_ORDER.RECEIVE_INV_ORG_ID, --接收库存组织ID-->RECEIVE_INV_ORG_ID
       R_LG_ORDER.RECEIVE_INV_ORG, --接收库存组织-->RECEIVE_INV_ORG
       --R_LG_ORDER.SUPPLIER_SYSTEM, --供方系统-->SUPPLIER_SYSTEM GERP
       R_LG_ORDER.SUPPLIER_ORG, --供方OU-->SUPPLIER_ORG FACTORY_OU_NAME
       R_LG_ORDER.SUPPLIER_ORG_ID, --供方OU ID-->SUPPLIER_ORG_ID FACTORY_OU_ID
       R_LG_ORDER.SUPPLIER_INV_ORG_ID, --供方发运库存组织ID-->SUPPLIER_INV_ORG_ID
       R_LG_ORDER.SUPPLIER_INV_ORG, --供方发运库存组织-->SUPPLIER_INV_ORG
       --R_LG_ORDER.SUPPLIER_ORDER_NUM, --供方来源单据-->SUPPLIER_ORDER_NUM
       --R_LG_ORDER.SUPPLIER_ORDER_TYPE, --供方来源单据类型-->SUPPLIER_ORDER_TYPE
       --R_LG_ORDER.S_ORDER_TYPE_ID, --退货销售订单类型ID-->S_ORDER_TYPE_ID
       --R_LG_ORDER.S_ORDER_TYPE, --退货销售订单类型-->S_ORDER_TYPE
       R_LG_ORDER.COMMENTS, --备注信息-->COMMENTS REMARK
       R_LG_ORDER.ENTITY_ID, --主体ID--> ENTITY_ID
       P_STATUS, --状态：N待发送；P已发送；S成功
       'N',
       V_STATUS_RECEIVE,
       V_ICP_LG_RECEIVE_MODE
       );
    
    /**
    --单边模式，内部客户，跨事业部单据关联物流的中间仓：推式来自未结算仓[NOSETTLED_INVENTORY]；拉式来自工厂和营销供需关系配置的营销仓  zhoujg3 2016-09-23 
    --chenzh     2015/0528   获取销售中间仓
    --获取
    V_SO_ICP_INV_ENABLE :=pkg_bd.F_GET_PARAMETER_VALUE('SO_ICP_INV_ENABLE',R_SO_HEADER.ENTITY_ID,null,null);
    IF V_SO_ICP_INV_ENABLE='1' THEN
      P_GET_ICP_INV(R_SO_HEADER,V_MIDDLE_INV_CODE,P_RESULT,P_ERR_MSG);
      IF P_RESULT < 0 THEN
         RAISE PKG_SO_PUB.V_BIZ_EXCEPTION; 
      END IF;      
    END IF;  
    */
    -- -1错误,0非拉式,1销售,2红冲,3源单退回,4反向销售,5源单退货红冲，6拉式其他单据类型
    --IF V_PULL_MODE IN (1, 5) THEN
    IF R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE IN 
        (PKG_SO_PUB.V_BIZ_SRC_BILL_SO,PKG_SO_PUB.V_BIZ_SRC_BILL_RETURN_RED) THEN    
      /**
      --销售单，退货红冲单来源仓 chenzh 2015/05/28
      IF V_SO_ICP_INV_ENABLE = '1' THEN
        --V_SUPPLIER_SORCE_SUBINV := V_MIDDLE_INV_CODE;
        V_SUPPLIER_SHIP_SUBINV:= V_MIDDLE_INV_CODE;
      END IF;
      */
      FOR REC IN (SELECT *
                    FROM T_SO_LINE_DETAIL A
                   WHERE A.SO_HEADER_ID = R_SO_HEADER.SO_HEADER_ID
                   ORDER BY A.SO_LINE_DETAIL_NUM) LOOP
        R_LG_ORDER_LINE := NULL;
      
        -- NUMBER[965]
        R_LG_ORDER_LINE.ID := S_CUX_ICP_LOGIST_REQ_LINES.NEXTVAL;
      
        R_LG_ORDER_LINE.SOURCE_HEADER_ID := R_SO_HEADER.SO_HEADER_ID; --来源头ID
        R_LG_ORDER_LINE.REQ_LINE_NUM     := REC.SO_LINE_DETAIL_NUM; --行号
        R_LG_ORDER_LINE.ORDER_LINE_NUM   := REC.SO_LINE_DETAIL_NUM; --关联订单行号
        --R_LG_ORDER_LINE.ISS_DATE         := R_SO_HEADER.SETTLE_DATE; --发出日期 销售单结算日期
        --单边模式写接口表签收日期为空
        --R_LG_ORDER_LINE.RECEIVE_DATE     := R_SO_HEADER.SETTLE_DATE; --接收日期 销售单结算日期,由AUDIT_DATE改为SETTLE_DATE
        R_LG_ORDER_LINE.ISS_DATE         := R_SO_HEADER.AUDIT_DATE; --发出日期
        R_LG_ORDER_LINE.RECEIVE_DATE     := R_SO_HEADER.AUDIT_DATE; --直接传审核日期
        R_LG_ORDER_LINE.SOURCE_HEADER    := 'G'||R_SO_HEADER.SO_NUM; --来源头信息
        R_LG_ORDER_LINE.SOURCE_LINE      := REC.SO_LINE_DETAIL_ID; --供方来源行号
        --R_LG_ORDER_LINE.REQUIRE_SOURCE_LINE:=REC.SO_LINE_ID; --需方来源行号
        --供方信息物料编码ID NUMBER[]
        R_LG_ORDER_LINE.SUPPLIER_ITEM_ID := REC.COMPONENT_ID;
      
        --供方信息物料编码 VARCHAR2(100)[31022211001551]
        R_LG_ORDER_LINE.SUPPLIER_ITEM_NUM := REC.COMPONENT_CODE;
      
        --需方信息物料编码ID NUMBER[]
        R_LG_ORDER_LINE.REQUIRE_ITEM_ID := REC.COMPONENT_ID;
      
        --需方信息物料编码 VARCHAR2(100)[31022211001551]
        R_LG_ORDER_LINE.REQUIRE_ITEM_NUM := REC.COMPONENT_CODE;
      
        --单位 VARCHAR2(100)[Tai]
        R_LG_ORDER_LINE.PRIMARY_UNIT_OF_MEASURE := REC.COMPONENT_UOM;
      
        --发出数量 NUMBER[111]
        R_LG_ORDER_LINE.REQUEST_QUANTITY := REC.COMPONENT_QTY;
      
        --    --来源子库 VARCHAR2(100)[MA3311]  
        R_LG_ORDER_LINE.SUPPLIER_SORCE_SUBINV := V_SUPPLIER_SORCE_SUBINV;
      
        ---    --发出商品子库 VARCHAR2(100)[MX1351]  
        R_LG_ORDER_LINE.SUPPLIER_SHIP_SUBINV := V_SUPPLIER_SHIP_SUBINV;
      
        ---   --接收子库 VARCHAR2(100)[SWC34B1110] 有问题，取值
        R_LG_ORDER_LINE.RECEIVE_SUBINV := V_RECEIVE_SUBINV;
        
        --套机码也是散件，价格取单据行价格,
        IF REC.COMPONENT_CODE = REC.ITEM_CODE THEN 
           SELECT SL.ITEM_SETTLE_PRICE
             INTO V_PRICE
             FROM T_SO_LINE SL
            WHERE SL.SO_LINE_ID = REC.SO_LINE_ID;
        ELSE
           --套机下单，散件价格检查标记Y
           UPDATE INTF_CUX_ICP_LOGIST_REQ_HEADER H
              SET H.PRICE_CHECK_FLAG = 'Y'
            WHERE H.ID = R_LG_ORDER.ID;
           --散件取价，可以为空
           V_PRICE := PKG_BD_PRICE.F_GET_PRICE( R_SO_HEADER.ACCOUNT_ID,
                                            R_LG_ORDER_LINE.SUPPLIER_ITEM_NUM,
                                            TO_CHAR(SYSDATE,'YYYYMMDD'),
                                            NULL,
                                            R_SO_HEADER.ENTITY_ID); 
        END IF;
        --编码汇总，已存在则累加数量
        SELECT COUNT(*)
          INTO V_COUNT
          FROM INTF_CUX_ICP_LOGIST_REQ_LINES T
         WHERE T.SOURCE_HEADER_ID = P_SO_HEADER_ID
           AND T.SUPPLIER_ITEM_NUM = REC.COMPONENT_CODE
           AND T.HEADERS_ID = R_LG_ORDER.ID;
        
        IF V_COUNT > 0 THEN
          UPDATE INTF_CUX_ICP_LOGIST_REQ_LINES T
             SET T.REQUEST_QUANTITY = (NVL(REQUEST_QUANTITY, 0) +
                                      REC.COMPONENT_QTY)
           WHERE T.SOURCE_HEADER_ID = P_SO_HEADER_ID
             AND T.SUPPLIER_ITEM_NUM = REC.COMPONENT_CODE
             AND T.HEADERS_ID = R_LG_ORDER.ID;
        ELSE
            INSERT INTO INTF_CUX_ICP_LOGIST_REQ_LINES
              (ID,
               HEADERS_ID,
               SOURCE_HEADER_ID,
               REQ_LINE_NUM,
               --ORDER_HEADER_ID,
               ORDER_LINE_NUM,
               --SUPPLIER_ITEM_ID,
               SUPPLIER_ITEM_NUM,
               --REQUIRE_ITEM_ID,
               REQUIRE_ITEM_NUM,
               PRIMARY_UNIT_OF_MEASURE,
               REQUEST_QUANTITY,
               SUPPLIER_SORCE_SUBINV,
               SUPPLIER_SORCE_LOCATION,
               SUPPLIER_SORCE_LOCATION_ID,
               SUPPLIER_SHIP_SUBINV,
               SUPPLIER_SHIP_LOCATION,
               SUPPLIER_SHIP_LOCATION_ID,
               ISS_LOT_NUMBER,
               ISS_DATE,
               RECEIVE_SUBINV,
               RECEIVE_LOCATION,
               RECEIVE_LOCATION_ID,
               RECEIVE_LOT_NUMBER,
               RECEIVE_DATE,
               SOURCE_HEADER,
               SOURCE_LINE,
               REQUIRE_SOURCE_LINE,
               COMMENTS,
               LOGIST_HEADER_ID, --关联物流号
               LOGIST_LINE_ID,
               ITEM_PRICE)
            VALUES
              (R_LG_ORDER_LINE.ID, --
               R_LG_ORDER.ID,
               R_LG_ORDER_LINE.SOURCE_HEADER_ID, --来源头ID
               R_LG_ORDER_LINE.REQ_LINE_NUM, --行号
               --R_LG_ORDER_LINE.ORDER_HEADER_ID, --关联订单号
               R_LG_ORDER_LINE.ORDER_LINE_NUM, --关联订单行号
               --R_LG_ORDER_LINE.SUPPLIER_ITEM_ID, --供方信息物料编码ID
               R_LG_ORDER_LINE.SUPPLIER_ITEM_NUM, --供方信息物料编码
               --R_LG_ORDER_LINE.REQUIRE_ITEM_ID, --需方信息物料编码ID
               R_LG_ORDER_LINE.REQUIRE_ITEM_NUM, --需方信息物料编码
               R_LG_ORDER_LINE.PRIMARY_UNIT_OF_MEASURE, --单位
               R_LG_ORDER_LINE.REQUEST_QUANTITY, --发出数量
               R_LG_ORDER_LINE.SUPPLIER_SORCE_SUBINV, --来源子库
               R_LG_ORDER_LINE.SUPPLIER_SORCE_LOCATION, --来源货位
               R_LG_ORDER_LINE.SUPPLIER_SORCE_LOCATION_ID, --来源货位ID
               R_LG_ORDER_LINE.SUPPLIER_SHIP_SUBINV, --发出商品子库
               R_LG_ORDER_LINE.SUPPLIER_SHIP_LOCATION, --发出商品货位
               R_LG_ORDER_LINE.SUPPLIER_SHIP_LOCATION_ID, --发出商品货位ID
               R_LG_ORDER_LINE.ISS_LOT_NUMBER, --发出批次
               R_LG_ORDER_LINE.ISS_DATE, --发出日期
               R_LG_ORDER_LINE.RECEIVE_SUBINV, --接收子库
               R_LG_ORDER_LINE.RECEIVE_LOCATION, --接收库存货位
               R_LG_ORDER_LINE.RECEIVE_LOCATION_ID, --接收库存货位ID
               R_LG_ORDER_LINE.RECEIVE_LOT_NUMBER, --接收批次
               R_LG_ORDER_LINE.RECEIVE_DATE, --接收日期
               R_LG_ORDER_LINE.SOURCE_HEADER, --来源头信息
               R_LG_ORDER_LINE.SOURCE_LINE, --供方来源行号
               R_LG_ORDER_LINE.REQUIRE_SOURCE_LINE, --需方来源行号
               R_LG_ORDER_LINE.COMMENTS, --行备注
               R_LG_ORDER_LINE.LOGIST_HEADER_ID, --关联物流号
               R_LG_ORDER_LINE.LOGIST_LINE_ID, --关联物流行ID
               V_PRICE --含税价，关联开票用
               );
        END IF;    
      END LOOP;
      
    --ELSIF V_PULL_MODE IN (2,3) THEN
    ELSIF R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE IN
          (PKG_SO_PUB.V_BIZ_SRC_BILL_SO_RED,PKG_SO_PUB.V_BIZ_SRC_BILL_RETURN) THEN    
      -- -1错误,0非拉式,1销售,2红冲,3源单退回,4反向销售,5源单退货红冲，6拉式其他单据类型
      --销售红冲单目标仓 chenzh 2015/05/28
      IF V_SO_ICP_INV_ENABLE = '1' THEN
         V_SUPPLIER_SHIP_SUBINV   := V_MIDDLE_INV_CODE;
      END IF;
     
  
      FOR REC IN (SELECT *
                    FROM T_SO_LINE_DETAIL A
                   WHERE A.SO_HEADER_ID = R_SO_HEADER.SO_HEADER_ID
                   ORDER BY A.SO_LINE_DETAIL_NUM) LOOP
      
        R_LG_ORDER_LINE := NULL;

        --查询蓝单关联订单中的
        BEGIN

          SELECT DISTINCT
           A.ERP_ORDER_HEADER_ID2 AS ORDER_HEADER_ID, --ORDER_HEADER_ID
           --A.ERP_LOGIST_HEADER_ID,
           C.ORDER_LINE_NUM,
           --B.ITEM_CODE,
           C.REQ_LINE_ID AS LOGIST_LINE_ID --LOGIST_LINE_ID
            INTO R_LG_ORDER_LINE.ORDER_HEADER_ID,
                 R_LG_ORDER_LINE.ORDER_LINE_NUM,
                 R_LG_ORDER_LINE.LOGIST_LINE_ID
            FROM T_SO_HEADER                                 A,
                 T_SO_LINE_DETAIL                            B,
                 APPS.CUX_ICP_LOGIST_REQ_LINES_V@MDIMS2MDERP C
           WHERE B.SO_HEADER_ID = A.SO_HEADER_ID
             AND A.ERP_LOGIST_HEADER_ID2 = C.REQ_HEADER_ID
             AND B.COMPONENT_CODE = C.SUPPLIER_ITEM_NUM
             AND A.BIZ_SRC_BILL_TYPE_CODE = '1001'
             AND B.COMPONENT_CODE = REC.COMPONENT_CODE
             AND A.SO_NUM = NVL(R_SO_HEADER.ORIG_SO_NUM,R_SO_HEADER.RETURN_ORIG_SO_NUM); --蓝单号
        EXCEPTION
          WHEN OTHERS THEN
            P_ERR_MSG := '销售红冲/退货单号[' || R_SO_HEADER.SO_NUM || ']查询蓝单[' || NVL(R_SO_HEADER.ORIG_SO_NUM,R_SO_HEADER.RETURN_ORIG_SO_NUM) || '],产品(散件)[' || REC.COMPONENT_CODE || '] 对应的关联物流订单异常';
            RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
        END;
        IF R_LG_ORDER_LINE.ORDER_HEADER_ID IS NULL THEN
          P_ERR_MSG := '销售红冲/退货单号[' || R_SO_HEADER.SO_NUM || ']获取蓝单[' || NVL(R_SO_HEADER.ORIG_SO_NUM,R_SO_HEADER.RETURN_ORIG_SO_NUM) || '],产品(散件)[' || REC.COMPONENT_CODE || '] 对应的关联订单号异常';
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
        END IF;
        
        /**
        R_LG_ORDER_LINE.ORDER_HEADER_ID := 1111111;
        R_LG_ORDER_LINE.ORDER_LINE_NUM := 1;
        R_LG_ORDER_LINE.LOGIST_LINE_ID := 2222222;
        */
        
        
        -- NUMBER[965]
        R_LG_ORDER_LINE.ID := S_CUX_ICP_LOGIST_REQ_LINES.NEXTVAL;
      
        --行号 NUMBER[1]
        R_LG_ORDER_LINE.REQ_LINE_NUM := REC.SO_LINE_DETAIL_NUM;
      
        R_LG_ORDER_LINE.SOURCE_HEADER_ID := R_SO_HEADER.SO_HEADER_ID; --来源头ID
        R_LG_ORDER_LINE.REQ_LINE_NUM     := REC.SO_LINE_DETAIL_NUM; --行号
        --R_LG_ORDER_LINE.ORDER_LINE_NUM   := REC.SO_LINE_NUM; --关联订单行号
        --R_LG_ORDER_LINE.ISS_DATE      := R_SO_HEADER.SETTLE_DATE; --发出日期 销售单结算日期
        --R_LG_ORDER_LINE.RECEIVE_DATE  := R_SO_HEADER.SETTLE_DATE; --接收日期 销售单结算日期,由SO_DATE改为SETTLE_DATE
        R_LG_ORDER_LINE.ISS_DATE      := R_SO_HEADER.AUDIT_DATE; --发出日期
        R_LG_ORDER_LINE.RECEIVE_DATE  := R_SO_HEADER.AUDIT_DATE; --直接传审核日期
        R_LG_ORDER_LINE.SOURCE_HEADER := 'G'||R_SO_HEADER.SO_NUM; --来源头信息
        R_LG_ORDER_LINE.SOURCE_LINE   := REC.SO_LINE_DETAIL_ID; --供方来源行号
        --R_LG_ORDER_LINE.REQUIRE_SOURCE_LINE:=REC.SO_LINE_ID; --需方来源行号
        --供方信息物料编码ID NUMBER[]
        R_LG_ORDER_LINE.SUPPLIER_ITEM_ID := REC.COMPONENT_ID;
      
        --供方信息物料编码 VARCHAR2(100)[31022211001551]
        R_LG_ORDER_LINE.SUPPLIER_ITEM_NUM := REC.COMPONENT_CODE;
      
        --需方信息物料编码ID NUMBER[]
        R_LG_ORDER_LINE.REQUIRE_ITEM_ID := REC.COMPONENT_ID;
      
        --需方信息物料编码 VARCHAR2(100)[31022211001551]
        R_LG_ORDER_LINE.REQUIRE_ITEM_NUM := REC.COMPONENT_CODE;
      
        --单位 VARCHAR2(100)[Tai]
        R_LG_ORDER_LINE.PRIMARY_UNIT_OF_MEASURE := REC.COMPONENT_UOM;
      
        --发出数量 NUMBER[111]
        R_LG_ORDER_LINE.REQUEST_QUANTITY := REC.COMPONENT_QTY;
      
        --    --来源子库 VARCHAR2(100)[MA3311]  
        R_LG_ORDER_LINE.SUPPLIER_SORCE_SUBINV := V_SUPPLIER_SORCE_SUBINV;
      
        ---    --发出商品子库 VARCHAR2(100)[MX1351]  
        R_LG_ORDER_LINE.SUPPLIER_SHIP_SUBINV := V_SUPPLIER_SHIP_SUBINV;
      
        ---   --接收子库 VARCHAR2(100)[SWC34B1110] 有问题，取值
        R_LG_ORDER_LINE.RECEIVE_SUBINV := V_RECEIVE_SUBINV;
        
        --套机码也是散件，价格取单据行价格,
        IF REC.COMPONENT_CODE = REC.ITEM_CODE THEN 
           SELECT SL.ITEM_SETTLE_PRICE
             INTO V_PRICE
             FROM T_SO_LINE SL
            WHERE SL.SO_LINE_ID = REC.SO_LINE_ID;
        ELSE
           --套机下单，散件价格检查标记Y
           UPDATE INTF_CUX_ICP_LOGIST_REQ_HEADER H
              SET H.PRICE_CHECK_FLAG = 'Y'
            WHERE H.ID = R_LG_ORDER.ID;
           --散件取价，可以为空
           V_PRICE := PKG_BD_PRICE.F_GET_PRICE( R_SO_HEADER.ACCOUNT_ID,
                                            R_LG_ORDER_LINE.SUPPLIER_ITEM_NUM,
                                            TO_CHAR(SYSDATE,'YYYYMMDD'),
                                            NULL,
                                            R_SO_HEADER.ENTITY_ID); 
        END IF;
        
        --编码汇总，已存在则累加数量
        SELECT COUNT(*)
          INTO V_COUNT
          FROM INTF_CUX_ICP_LOGIST_REQ_LINES T
         WHERE T.SOURCE_HEADER_ID = P_SO_HEADER_ID
           AND T.SUPPLIER_ITEM_NUM = REC.COMPONENT_CODE
           AND T.HEADERS_ID = R_LG_ORDER.ID;
        
        IF V_COUNT > 0 THEN
          UPDATE INTF_CUX_ICP_LOGIST_REQ_LINES T
             SET T.REQUEST_QUANTITY = (NVL(REQUEST_QUANTITY, 0) +
                                      REC.COMPONENT_QTY)
           WHERE T.SOURCE_HEADER_ID = P_SO_HEADER_ID
             AND T.SUPPLIER_ITEM_NUM = REC.COMPONENT_CODE
             AND T.HEADERS_ID = R_LG_ORDER.ID;
        ELSE
            INSERT INTO INTF_CUX_ICP_LOGIST_REQ_LINES
              (ID,
               HEADERS_ID,
               SOURCE_HEADER_ID,
               REQ_LINE_NUM,
               ORDER_HEADER_ID,
               ORDER_LINE_NUM,
               --SUPPLIER_ITEM_ID,
               SUPPLIER_ITEM_NUM,
               --REQUIRE_ITEM_ID,
               REQUIRE_ITEM_NUM,
               PRIMARY_UNIT_OF_MEASURE,
               REQUEST_QUANTITY,
               SUPPLIER_SORCE_SUBINV,
               SUPPLIER_SORCE_LOCATION,
               SUPPLIER_SORCE_LOCATION_ID,
               SUPPLIER_SHIP_SUBINV,
               SUPPLIER_SHIP_LOCATION,
               SUPPLIER_SHIP_LOCATION_ID,
               ISS_LOT_NUMBER,
               ISS_DATE,
               RECEIVE_SUBINV,
               RECEIVE_LOCATION,
               RECEIVE_LOCATION_ID,
               RECEIVE_LOT_NUMBER,
               RECEIVE_DATE,
               SOURCE_HEADER,
               SOURCE_LINE,
               REQUIRE_SOURCE_LINE,
               COMMENTS,
               LOGIST_HEADER_ID, --关联物流号
               LOGIST_LINE_ID,
               ITEM_PRICE)
            VALUES
              (R_LG_ORDER_LINE.ID, --
               R_LG_ORDER.ID,
               R_LG_ORDER_LINE.SOURCE_HEADER_ID, --来源头ID
               R_LG_ORDER_LINE.REQ_LINE_NUM, --行号
               R_LG_ORDER_LINE.ORDER_HEADER_ID, --关联订单号
               R_LG_ORDER_LINE.ORDER_LINE_NUM, --关联订单行号
               --R_LG_ORDER_LINE.SUPPLIER_ITEM_ID, --供方信息物料编码ID
               R_LG_ORDER_LINE.SUPPLIER_ITEM_NUM, --供方信息物料编码
               --R_LG_ORDER_LINE.REQUIRE_ITEM_ID, --需方信息物料编码ID
               R_LG_ORDER_LINE.REQUIRE_ITEM_NUM, --需方信息物料编码
               R_LG_ORDER_LINE.PRIMARY_UNIT_OF_MEASURE, --单位
               R_LG_ORDER_LINE.REQUEST_QUANTITY, --发出数量
               R_LG_ORDER_LINE.SUPPLIER_SORCE_SUBINV, --来源子库
               R_LG_ORDER_LINE.SUPPLIER_SORCE_LOCATION, --来源货位
               R_LG_ORDER_LINE.SUPPLIER_SORCE_LOCATION_ID, --来源货位ID
               R_LG_ORDER_LINE.SUPPLIER_SHIP_SUBINV, --发出商品子库
               R_LG_ORDER_LINE.SUPPLIER_SHIP_LOCATION, --发出商品货位
               R_LG_ORDER_LINE.SUPPLIER_SHIP_LOCATION_ID, --发出商品货位ID
               R_LG_ORDER_LINE.ISS_LOT_NUMBER, --发出批次
               R_LG_ORDER_LINE.ISS_DATE, --发出日期
               R_LG_ORDER_LINE.RECEIVE_SUBINV, --接收子库
               R_LG_ORDER_LINE.RECEIVE_LOCATION, --接收库存货位
               R_LG_ORDER_LINE.RECEIVE_LOCATION_ID, --接收库存货位ID
               R_LG_ORDER_LINE.RECEIVE_LOT_NUMBER, --接收批次
               R_LG_ORDER_LINE.RECEIVE_DATE, --接收日期
               R_LG_ORDER_LINE.SOURCE_HEADER, --来源头信息
               R_LG_ORDER_LINE.SOURCE_LINE, --供方来源行号
               R_LG_ORDER_LINE.REQUIRE_SOURCE_LINE, --需方来源行号
               R_LG_ORDER_LINE.COMMENTS, --行备注
               R_LG_ORDER_LINE.LOGIST_HEADER_ID, --关联物流号
               R_LG_ORDER_LINE.LOGIST_LINE_ID, --关联物流行ID
               V_PRICE --含税价，关联开票用
               );
        END IF;
      END LOOP;

    END IF;
    
    
    P_TABLE_ACTION_LOG('INTF_CUX_ICP_LOGIST_REQ_HEADER', --操作表名称
                       '销售单生成物流订单', --操作说明
                       'G'||R_SO_HEADER.SO_NUM, --关键主键
                       0, --是否出错，1出错，0未出错
                       '' --错误信息
                       );
  EXCEPTION
    WHEN OTHERS THEN
      --ROLLBACK;
      P_RESULT  := -1;
      P_ERR_MSG := '销售单据头[ID：' || P_SO_HEADER_ID || ']生成关联物流订单出错，原因：' ||
                   P_ERR_MSG || SQLERRM;
      P_TABLE_ACTION_LOG('INTF_CUX_ICP_LOGIST_REQ_HEADER', --操作表名称
                         '销售单生成物流订单', --操作说明
                         'G'||R_SO_HEADER.SO_NUM, --关键主键
                         1, --是否出错，1出错，0未出错
                         P_ERR_MSG --错误信息
                         );
      --RAISE_APPLICATION_ERROR(-20123, P_ERR_MSG, FALSE);
  
  END;
    
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2016-03-07
  *     创建者：xiongpl
  *   功能说明：根据库存组织与客户ID获取关联交易仓
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_GET_ICP_INV( P_SO_HEADER  IN T_SO_HEADER%ROWTYPE,            --销售单记录
                             P_INV_CODE   OUT T_SO_ICP_INVENTORY.INVENTORY_CODE%TYPE,  --仓库编码
                             P_RESULT     OUT NUMBER, --返回错误ID
                             P_ERR_MSG    OUT VARCHAR2 --返回错误信息
                             ) AS
    V_MIDDLE_INV_CODE     T_SO_ICP_INVENTORY.INVENTORY_CODE%TYPE; --关联交易仓库编码
  BEGIN    
    --初始返回值
    P_RESULT  := PKG_SO_PUB.V_RESULT;
    P_ERR_MSG := PKG_SO_PUB.V_SUCCESS;
        
    BEGIN    
      --根据库存组织、客户进行查找
      SELECT DL.INVENTORY_CODE
        INTO V_MIDDLE_INV_CODE
        FROM T_SO_ICP_INVENTORY II, T_SO_ICP_INVENTORY_DETAIL DL
       WHERE II.ICP_INV_ID = DL.ICP_INV_ID
         AND DL.CUSTOMER_ID = P_SO_HEADER.CUSTOMER_ID
         AND II.ORGANIZATION_ID = P_SO_HEADER.ERP_SUBINV_ID
         AND II.ENTITY_ID = NVL(P_SO_HEADER.ENTITY_ID,II.ENTITY_ID);
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        --如果根据客户没找到，则直接根据库存组织再次查找
        SELECT T.INVENTORY_CODE
          INTO V_MIDDLE_INV_CODE
          FROM T_SO_ICP_INVENTORY T
         WHERE T.ORGANIZATION_ID = P_SO_HEADER.ERP_SUBINV_ID
           AND T.ENTITY_ID = NVL(P_SO_HEADER.ENTITY_ID,T.ENTITY_ID);
    END;          
    IF V_MIDDLE_INV_CODE IS NULL THEN 
       RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
    END IF;
    P_INV_CODE :=V_MIDDLE_INV_CODE;

  EXCEPTION
    WHEN OTHERS THEN
      P_RESULT  := -1;
      P_ERR_MSG := '主体[' || P_SO_HEADER.ENTITY_ID || '],子库[' || P_SO_HEADER.ERP_SUBINV_ID || ',' || P_SO_HEADER.ERP_SUBINV_CODE || '],客户['|| P_SO_HEADER.CUSTOMER_ID || ',' || P_SO_HEADER.CUSTOMER_CODE || ']未配置关联交易仓' || SQLERRM;           
  END;    
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-02-05
  *     创建者：陈武杰
  *   功能说明：关联订单回调，关联订单交易成功回调
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_ORDER_WRITE_BACK(P_SO_NUM T_SO_HEADER.SO_NUM%TYPE
                               --P_SO_HEADER_ID IN T_SO_HEADER.SO_HEADER_ID%TYPE --销售单头ID
                               --P_RESULT       IN OUT NUMBER, --返回错误ID
                               --P_ERR_MSG      IN OUT VARCHAR2 --返回错误信息
                               ) AS
    V_RELATED_TRANS_ID T_SO_HEADER.RELATED_TRANS_ID%TYPE;
    P_SO_HEADER_ID     T_SO_HEADER.SO_HEADER_ID%TYPE;
  BEGIN
    SELECT A.SO_HEADER_ID
      INTO P_SO_HEADER_ID
      FROM T_SO_HEADER A
     WHERE A.SO_NUM = P_SO_NUM;
    BEGIN
      --更新销售单头表关联交易订单ID
      SELECT A.X_ICP_SEQ_ID
        INTO V_RELATED_TRANS_ID
        FROM INTF_CUX_ICP_ORDER_REQ_HEADERS A
       WHERE A.SOURCE_ORDERS_TYPE = V_SOURCE_ORDERS_TYPE --'02'--必须加上订单类型，因为SOURCE_HEADER_ID中PO和SO单的HEADER_ID一起有重复
         AND A.SOURCE_HEADER_ID = P_SO_HEADER_ID;
    
      UPDATE T_SO_HEADER A
         SET A.RELATED_TRANS_ID = V_RELATED_TRANS_ID --关联交易订单ID
       WHERE A.SO_HEADER_ID = P_SO_HEADER_ID
      /*AND A.RELATED_TRANS_ID IS NULL*/
      ;
    EXCEPTION
      WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20123,
                                'SO_HEADER_ID[' || P_SO_HEADER_ID ||
                                ']P_ORDER_WRITE_BACK，更新关联交易订单ID错误：' ||
                                SQLERRM,
                                FALSE);
    END;
    BEGIN
      --更新销售单行明细表，关联订单信息
      FOR REC IN (SELECT SOURCE_HEADER,
                         SOURCE_HEADER_ID,
                         SOURCE_LINE,
                         A.SUPPLIER_ITEM_NUM,
                         A.REQUIRE_ITEM_NUM,
                         A.ID
                    FROM INTF_CUX_ICP_ORDER_REQ_LINES A
                   WHERE A.HEADERS_ID =
                         (SELECT A1.ID
                            FROM INTF_CUX_ICP_ORDER_REQ_HEADERS A1
                           WHERE A1.SOURCE_HEADER_ID = P_SO_HEADER_ID
                             AND A1.SOURCE_ORDERS_TYPE = V_SOURCE_ORDERS_TYPE /* '02'*/
                          )
                   ORDER BY A.REQ_LINE_NUM) LOOP
      
        UPDATE T_SO_LINE_DETAIL A
           SET RELATED_TRANS_LINE_ID = REC.ID --关联交易订单行ID
         WHERE A.SO_HEADER_ID = REC.SOURCE_HEADER_ID
           AND A.SO_LINE_ID = REC.SOURCE_LINE
           AND (A.ITEM_CODE = REC.REQUIRE_ITEM_NUM OR
               A.ITEM_CODE = REC.SUPPLIER_ITEM_NUM)
        /*AND A.RELATED_TRANS_LINE_ID IS NULL*/
        ;
      
      END LOOP;
    EXCEPTION
      WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20123,
                                'SO_HEADER_ID[' || P_SO_HEADER_ID ||
                                ']P_ORDER_WRITE_BACK，更新关联交易订单行ID错误：' ||
                                SQLERRM,
                                FALSE);
    END;
    PKG_SO_RT.P_TABLE_ACTION_LOG(P_TABLE_NAME     => 'P_ORDER_WRITE_BACK',
                                 P_ACTION_REMARKS => '关联订单回调',
                                 P_PK             => P_SO_HEADER_ID,
                                 P_ISERR          => 0, --是否出错，1出错，0未出错
                                 P_MSG            => '关联订单回调成功！');
  EXCEPTION
    WHEN OTHERS THEN
      --ROLLBACK;
      PKG_SO_RT.P_TABLE_ACTION_LOG(P_TABLE_NAME     => 'P_ORDER_WRITE_BACK',
                                   P_ACTION_REMARKS => '关联订单回调',
                                   P_PK             => P_SO_HEADER_ID,
                                   P_ISERR          => 1, --是否出错，1出错，0未出错
                                   P_MSG            => SQLERRM);
    
      RAISE_APPLICATION_ERROR(-20123,
                              '关联订单回调错误：' || SQLERRM,
                              FALSE);
    
  END;
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-02-05
  *     创建者：陈武杰
  *   功能说明：关联物流回写，只要物流订单成功就触发回调
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_LOGIST_WRITE_BACK(P_SO_NUM T_SO_HEADER.SO_NUM%TYPE
                                --P_SO_HEADER_ID IN T_SO_HEADER.SO_HEADER_ID%TYPE --销售单头ID
                                --P_RESULT       IN OUT NUMBER, --返回错误ID
                                --P_ERR_MSG      IN OUT VARCHAR2 --返回错误信息
                                ) AS
    --PRAGMA AUTONOMOUS_TRANSACTION; --自治事务
    P_RESULT       NUMBER;
    P_ERR_MSG      VARCHAR2(2000);
    V_SO_HEADER_ID T_SO_HEADER.SO_HEADER_ID%TYPE;
    V_PULL_MODE    NUMBER;
  BEGIN
    /*不用回调触发生成SO生成记录，改用【P_JOB_MAKE_SO_CHANGE】JOB调用！！！！！！edit by chen.wj 20150319*/
    /*--初始返回值
    P_RESULT  := PKG_SO_PUB.V_RESULT;
    P_ERR_MSG := PKG_SO_PUB.V_SUCCESS;
    
    --V_PULL_MODE := PKG_SO_PUB.F_PULL_MODE_BY_HEADERID(P_SO_HEADER_ID); -- -1错误,0非拉式,1销售,2红冲,3源单退回,4反向销售,5源单退货红冲，6拉式其他单据类型
    V_PULL_MODE := PKG_SO_PUB.F_PULL_MODE(P_SO_NUM);
    IF V_PULL_MODE IN (1, 5) THEN
      BEGIN
        --在物流订单交易成功情况下，不包括已经做了SO变更
        SELECT B.SO_HEADER_ID
          INTO V_SO_HEADER_ID
          FROM INTF_CUX_ICP_LOGIST_REQ_HEADER A, T_SO_HEADER B
         WHERE (A.REQUIREMENT_ORDER_NUM = B.SO_NUM OR
               A.SUPPLIER_ORDER_NUM = B.SO_NUM)
              --AND B.SO_HEADER_ID = P_SO_HEADER_ID
           AND B.SO_NUM = P_SO_NUM
              --AND A.RESPONSETYPE_1 = 'N' --发货确认返回状态：N成功，E失败，W警告
              --AND A.RESPONSETYPE_2 = 'N' --接收返回状态：N成功，E失败，W警告
           AND A.STATUS = 'S'
           AND NOT EXISTS (SELECT 1
                  FROM INTF_OE_HEADERS_IFACE_ALL C
                 WHERE C.ORDER_NUMBER = B.SO_NUM
                   AND C.UPDATE_TRX_ID IS NOT NULL);
      
      EXCEPTION
        WHEN OTHERS THEN
          \*RAISE_APPLICATION_ERROR(-20123,
          'SO_HEADER_ID[' || V_SO_HEADER_ID ||
          ']P_LOGIST_WRITE_BACK，获取SO_NUM错误：' ||
          SQLERRM,
          FALSE);*\
          RETURN;
      END;
    
      --拉式销售，SO变更
      --触发SO变更接口（BOOK登记通过SO变更一起发给ERP，故不需再调用BOOK登记接口）
      PKG_SO_BIZ.P_SO_TO_ERP(V_SO_HEADER_ID,
                             PKG_SO_PUB.V_ERP_TRXCODE_CHANGE,
                             P_RESULT,
                             P_ERR_MSG);
      IF P_RESULT <> 0 THEN
        RAISE_APPLICATION_ERROR(-20123,
                                'SO_HEADER_ID[' || V_SO_HEADER_ID ||
                                ']P_RT_WRITE_BACK，SO变更错误：' || P_ERR_MSG,
                                FALSE);
      END IF;
      --COMMIT;
    END IF;*/
    NULL;
  EXCEPTION
    WHEN OTHERS THEN
      --ROLLBACK;
      PKG_SO_RT.P_TABLE_ACTION_LOG(P_TABLE_NAME     => 'P_LOGIST_WRITE_BACK',
                                   P_ACTION_REMARKS => '关联物流回调',
                                   P_PK             => V_SO_HEADER_ID,
                                   P_ISERR          => 1, --是否出错，1出错，0未出错
                                   P_MSG            => SQLERRM);
  END;
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-02-05
  *     创建者：陈武杰
  *   功能说明：RMA接收回调， RMA接收成功，回调
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_RMA_WRITE_BACK(P_SO_HEADER_ID IN T_SO_HEADER.SO_HEADER_ID%TYPE --销售单头ID
                             --P_RESULT       IN OUT NUMBER, --返回错误ID
                             --P_ERR_MSG      IN OUT VARCHAR2 --返回错误信息
                             ) AS
    --PRAGMA AUTONOMOUS_TRANSACTION; --自治事务
    P_RESULT    NUMBER;
    P_ERR_MSG   VARCHAR2(2000);
    V_SO_NUM    T_SO_HEADER.SO_NUM%TYPE;
    V_PULL_MODE NUMBER;
    R_SO_HEADER T_SO_HEADER%ROWTYPE;
  BEGIN
    /*不用回调触发关联交易记录，改用【P_JOB_MAKE_RT_LOGIST】JOB调用！！！！！！edit by chen.wj 20150319*/
    --初始返回值
    /*P_RESULT  := PKG_SO_PUB.V_RESULT;
    P_ERR_MSG := PKG_SO_PUB.V_SUCCESS;
    
    -- -1错误,0非拉式,1销售,2红冲,3源单退回,4反向销售,5源单退货红冲，6拉式其他单据类型
    V_PULL_MODE := PKG_SO_PUB.F_PULL_MODE_BY_HEADERID(P_SO_HEADER_ID);
    IF V_PULL_MODE IN (2, 3) THEN
      --退货、红冲，直接调用物流订单
      BEGIN
        SELECT *
          INTO R_SO_HEADER
          FROM T_SO_HEADER A
         WHERE A.SO_HEADER_ID = P_SO_HEADER_ID;
        --在RMA接收成功情况下，不包括物流订单
        SELECT B.SO_NUM, PKG_SO_PUB.F_PULL_MODE(B.SO_NUM) -- -1错误,0非拉式,1销售,2红冲,3源单退回,4反向销售,5源单退货红冲，6拉式其他单据类型
          INTO V_SO_NUM, V_PULL_MODE
          FROM INTF_OE_HEADERS_IFACE_ALL A, T_SO_HEADER B
         WHERE A.ORDER_NUMBER = B.SO_NUM
           AND B.SO_HEADER_ID = P_SO_HEADER_ID
           AND A.STATUS = 'S'
           AND A.ERROR_FLAG = 'N'
           AND RMA_RECEIVE_TRX_STATUS = 'S'
           AND NOT EXISTS
         (SELECT 1
                  FROM INTF_CUX_ICP_LOGIST_REQ_HEADER D
                 WHERE D.REQUIREMENT_ORDER_NUM = R_SO_HEADER.SO_NUM);
      
      EXCEPTION
        WHEN OTHERS THEN
          RAISE_APPLICATION_ERROR(-20123,
                                  'SO_HEADER_ID[' || P_SO_HEADER_ID ||
                                  ']P_RMA_WRITE_BACK，获取SO_NUM错误：' ||
                                  SQLERRM,
                                  FALSE);
      END;
      P_MAIN(P_SO_HEADER_ID, P_RESULT, P_ERR_MSG);
      IF P_RESULT <> 0 THEN
        RAISE_APPLICATION_ERROR(-20123,
                                'SO_HEADER_ID[' || P_SO_HEADER_ID ||
                                ']P_RMA_WRITE_BACK，生成关联订单、物流订单错误：' ||
                                P_ERR_MSG,
                                FALSE);
      END IF;
      --COMMIT;
    ELSIF V_PULL_MODE = 4 THEN
      --关联交易
      BEGIN
        --在RMA接收成功情况下，不包括关联订单 
        SELECT B.SO_NUM, PKG_SO_PUB.F_PULL_MODE(B.SO_NUM) -- -1错误,0非拉式,1销售,2红冲,3源单退回,4反向销售,5源单退货红冲，6拉式其他单据类型
          INTO V_SO_NUM, V_PULL_MODE
          FROM INTF_OE_HEADERS_IFACE_ALL A, T_SO_HEADER B
         WHERE A.ORDER_NUMBER = B.SO_NUM
           AND B.SO_HEADER_ID = P_SO_HEADER_ID
           AND A.STATUS = 'S'
           AND A.ERROR_FLAG = 'N'
           AND RMA_RECEIVE_TRX_STATUS = 'S'
           AND NOT EXISTS
         (SELECT 1
                  FROM INTF_CUX_ICP_ORDER_REQ_HEADERS C
                 WHERE  C.Source_Orders = b.so_num);
      
      EXCEPTION
        WHEN OTHERS THEN
          RAISE_APPLICATION_ERROR(-20123,
                                  'SO_HEADER_ID[' || P_SO_HEADER_ID ||
                                  ']P_RMA_WRITE_BACK，获取SO_NUM错误：' ||
                                  SQLERRM,
                                  FALSE);
      END;
      P_MAIN(P_SO_HEADER_ID, P_RESULT, P_ERR_MSG);
      IF P_RESULT <> 0 THEN
        RAISE_APPLICATION_ERROR(-20123,
                                'SO_HEADER_ID[' || P_SO_HEADER_ID ||
                                ']P_RMA_WRITE_BACK，生成物流订单错误：' || P_ERR_MSG,
                                FALSE);
      END IF;
      --COMMIT;
    END IF;*/
    NULL;
  EXCEPTION
    WHEN OTHERS THEN
      --ROLLBACK;
      PKG_SO_RT.P_TABLE_ACTION_LOG(P_TABLE_NAME     => 'P_RMA_WRITE_BACK',
                                   P_ACTION_REMARKS => 'RMA接收回调',
                                   P_PK             => P_SO_HEADER_ID,
                                   P_ISERR          => 1, --是否出错，1出错，0未出错
                                   P_MSG            => SQLERRM);
  END;
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-02-05
  *     创建者：陈武杰
  *   功能说明：SO变更回调
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SOCHANGE_WRITE_BACK(P_SO_HEADER_ID IN T_SO_HEADER.SO_HEADER_ID%TYPE --销售单头ID
                                  --P_RESULT       IN OUT NUMBER, --返回错误ID
                                  --P_ERR_MSG      IN OUT VARCHAR2 --返回错误信息
                                  ) AS
    R_SO_HEADER T_SO_HEADER%ROWTYPE;
    V_PULL_MODE NUMBER;
    P_RESULT    NUMBER;
    P_ERR_MSG   VARCHAR2(4000);
  BEGIN
    BEGIN
      SELECT *
        INTO R_SO_HEADER
        FROM T_SO_HEADER A
       WHERE A.SO_HEADER_ID = P_SO_HEADER_ID
         AND NOT EXISTS
       (SELECT 1
                FROM INTF_OE_HEADERS_IFACE_ALL C
               WHERE C.GLOBAL_ATTRIBUTE12 = A.SO_NUM
                 AND C.RMA_RECEIVE_TRX_ID IS NOT NULL);
    EXCEPTION
      WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20123,
                                'SO_HEADER_ID[' || P_SO_HEADER_ID ||
                                ']P_SOCHANGE_WRITE_BACK，查询销售单异常：' ||
                                SQLERRM,
                                FALSE);
    END;
  
    -- -1错误,0非拉式,1销售,2红冲,3源单退回,4反向销售,5源单退货红冲，6拉式其他单据类型
    V_PULL_MODE := PKG_SO_PUB.F_PULL_MODE_BY_HEADERID(P_SO_HEADER_ID);
    IF V_PULL_MODE IN (2, 3, 4) THEN
      PKG_SO_BIZ.P_SO_TO_ERP(P_SO_HEADER_ID,
                             PKG_SO_PUB.V_ERP_TRXCODE_RMA_RECV,
                             P_RESULT,
                             P_ERR_MSG);
      IF P_RESULT = 0 THEN
        PKG_SO_RT.P_TABLE_ACTION_LOG(P_TABLE_NAME     => 'P_SOCHANGE_WRITE_BACK',
                                     P_ACTION_REMARKS => 'SO变更回调',
                                     P_PK             => P_SO_HEADER_ID,
                                     P_ISERR          => 0, --是否出错，1出错，0未出错
                                     P_MSG            => 'SO变更回调成功！');
      ELSE
      
        RAISE_APPLICATION_ERROR(-20123,
                                'SO_HEADER_ID[' || P_SO_HEADER_ID ||
                                ']P_SOCHANGE_WRITE_BACK，调用RMA接收错误：' ||
                                P_ERR_MSG,
                                FALSE);
      END IF;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      PKG_SO_RT.P_TABLE_ACTION_LOG(P_TABLE_NAME     => 'P_SOCHANGE_WRITE_BACK',
                                   P_ACTION_REMARKS => 'SO变更回调',
                                   P_PK             => P_SO_HEADER_ID,
                                   P_ISERR          => 1, --是否出错，1出错，0未出错
                                   P_MSG            => SQLERRM);
  END;
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-03-20
  *     创建者：陈武杰
  *   功能说明：生成SO变更标记记录
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_JOB_MAKE_SO_CHANGE(P_SUCCESS_COUNT OUT NUMBER, --成功记录条数
                                 P_FAIL_COUNT    OUT NUMBER --失败记录条数
                                 ) AS
    P_RESULT  NUMBER;
    P_ERR_MSG VARCHAR2(4000);
    V_SDATE   DATE;
    V_EDATE   DATE;
  BEGIN
    P_SUCCESS_COUNT := 0;
    P_FAIL_COUNT    := 0;
    V_SDATE         := SYSDATE;
    FOR REC IN (SELECT SO_HEADER_ID, SO_NUM
                  FROM (SELECT A.SO_HEADER_ID, A.SO_NUM
                          FROM CIMS.T_SO_HEADER A
                         WHERE EXISTS (SELECT 1
                                  FROM CIMS.INTF_OE_HEADERS_IFACE_ALL C
                                 WHERE C.GLOBAL_ATTRIBUTE12 = A.SO_NUM
                                   AND C.UPDATE_TRX_ID IS NULL)
                           AND A.ERP_LOGIST_HEADER_ID IS NOT NULL
                           AND A.IS_MATERIAL = PKG_SO_PUB.V_NO
                           AND A.TRX_MODE = PKG_SO_PUB.V_TRADE_MODE_PULL
                           AND A.SO_STATUS  = PKG_SO_PUB.V_SETTLED
                           AND A.BIZ_SRC_BILL_TYPE_CODE IN ('1001', '1004')
                           AND A.LAST_UPDATE_DATE > SYSDATE - PKG_SO_PUB.V_SO_PERFORMANCE_OPT_RANGE) S
                 WHERE EXISTS (SELECT /*+ no_unnest*/ 1
                          FROM CIMS.CUX_ICP_LOGIST_REQ_HEADERS_V B
                         WHERE B.REQUIREMENT_ORDER_TYPE = 'CIMS-SEND'
                           AND B.STATUS = '5'
                           AND B.ORDER_STATUS = 'RECEIVE_CONFIRM'
                           AND B.REQUIREMENT_ORDER_NUM = S.SO_NUM)
                ) LOOP
      BEGIN
        PKG_SO_BIZ.P_SO_TO_ERP(P_SO_HEADER_ID => REC.SO_HEADER_ID,
                               P_ERP_TRX_CODE => PKG_SO_PUB.V_ERP_TRXCODE_CHANGE, --PKG_SO_PUB.V_ERP_TRXCODE_CHANGE   SO变更标记
                               P_RESULT       => P_RESULT,
                               P_ERR_MSG      => P_ERR_MSG);
        IF P_RESULT = PKG_SO_PUB.V_RESULT THEN
          P_SUCCESS_COUNT := P_SUCCESS_COUNT + 1;
          COMMIT;
        ELSE
          RAISE_APPLICATION_ERROR(-20123, P_ERR_MSG, FALSE);
        END IF;
      EXCEPTION
        WHEN OTHERS THEN
          ROLLBACK;
          P_FAIL_COUNT := P_FAIL_COUNT + 1;
          PKG_SO_RT.P_TABLE_ACTION_LOG(P_TABLE_NAME     => 'P_JOB_MAKE_SO_CHANGE',
                                       P_ACTION_REMARKS => 'JOB调用SO变更标记记录',
                                       P_PK             => REC.SO_NUM,
                                       P_ISERR          => 1, --是否出错，1出错，0未出错
                                       P_MSG            => P_ERR_MSG);
      END;
    END LOOP;
    V_EDATE := SYSDATE;
    PKG_SO_RT.P_TABLE_ACTION_LOG(P_TABLE_NAME     => 'P_JOB_MAKE_SO_CHANGE',
                                 P_ACTION_REMARKS => '生成SO变更标记记录JOB运行日志',
                                 P_PK             => TO_CHAR(SYSDATE,
                                                             'yyyymmdd'),
                                 P_ISERR          => 0, --是否出错，1出错，0未出错
                                 P_MSG            => '开始时间[' ||
                                                     TO_CHAR(V_SDATE,
                                                             'yyyy-mm-dd hh24:mi:ss') ||
                                                     ']，结算时间[' ||
                                                     TO_CHAR(V_EDATE,
                                                             'yyyy-mm-dd hh24:mi:ss') ||
                                                     ']，成功记录条数[' ||
                                                     P_SUCCESS_COUNT ||
                                                     ']，失败记录条数[' ||
                                                     P_FAIL_COUNT || ']');
  END;
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-03-20
  *     创建者：陈武杰
  *   功能说明：生成关联交易物流订单记录
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_JOB_MAKE_RT_LOGIST(P_SUCCESS_COUNT OUT NUMBER, --成功记录条数
                                 P_FAIL_COUNT    OUT NUMBER --失败记录条数
                                 ) AS
    P_RESULT  NUMBER;
    P_ERR_MSG VARCHAR2(4000);
    V_SDATE   DATE;
    V_EDATE   DATE;
  BEGIN
    P_SUCCESS_COUNT := 0;
    P_FAIL_COUNT    := 0;
    V_SDATE         := SYSDATE;
    FOR REC IN (SELECT *
                  FROM (SELECT A.SO_HEADER_ID,
                               A.SO_NUM,
                               (CASE
                                 WHEN A.BIZ_SRC_BILL_TYPE_CODE = '1002' THEN --如果是红冲单看蓝单号
                                  A.ORIG_SO_NUM
                                 WHEN A.BIZ_SRC_BILL_TYPE_CODE = '1003' AND --如果是退货，而且是有源退货，看源单号
                                      NVL(A.RETURN_MODE, '1') = '2' THEN
                                  A.RETURN_ORIG_SO_NUM
                                 WHEN A.BIZ_SRC_BILL_TYPE_CODE = '1003' AND --如果是退货，但无源，则为反向销售
                                      NVL(A.RETURN_MODE, '1') = '3' THEN
                                  '反向销售'
                                 ELSE
                                  '错误'
                               END) AS ORIG_SO_NUM
                          FROM T_SO_HEADER A
                         WHERE A.ERP_LOGIST_HEADER_ID IS NULL --关联交易物流订单没完成
                           AND NVL(A.IS_MATERIAL, 'N') = 'N' --非推广物料
                           AND A.BIZ_SRC_BILL_TYPE_CODE IN ('1002', '1003') --红冲，退货
                           AND PKG_SO_PUB.F_PULL_MODE_BY_HEADERID(A.SO_HEADER_ID) IN
                               (2, 3, 4) --红冲、有源退货、反向销售
                           AND EXISTS
                         (SELECT 1 --已经生成RMA接收标记
                                  FROM INTF_OE_HEADERS_IFACE_ALL C
                                 WHERE /*C.RMA_RECEIVE_TRX_ID IS NOT NULL --edit by chen.wj 20150326 需要改成RMA接收成功状态*/
                                 C.RMA_RECEIVE_TRX_STATUS = 'S'
                              AND C.GLOBAL_ATTRIBUTE12 = A.SO_NUM)
                           AND A.LAST_UPDATE_DATE > SYSDATE - PKG_SO_PUB.V_SO_PERFORMANCE_OPT_RANGE) B
                 WHERE NOT EXISTS
                 (SELECT 1 --撇开已经生成关联交易物流订单记录
                          FROM INTF_CUX_ICP_LOGIST_REQ_HEADER B1
                         WHERE B1.REQUIREMENT_ORDER_NUM = B.SO_NUM)
                   AND ('反向销售' = B.ORIG_SO_NUM OR EXISTS --要么是反向销售不用看蓝（源）单，要么是红冲看蓝单，要么是有源退货看源单
                        (SELECT 1
                           FROM INTF_CUX_ICP_LOGIST_REQ_HEADER B2
                          WHERE B2.REQUIREMENT_ORDER_NUM = B.ORIG_SO_NUM
                            AND B2.X_ICP_SEQ_ID IS NOT NULL))) LOOP
      BEGIN
        PKG_SO_RT.P_MAIN(P_SO_HEADER_ID => REC.SO_HEADER_ID,
                         P_RESULT       => P_RESULT,
                         P_ERR_MSG      => P_ERR_MSG);
        IF P_RESULT = PKG_SO_PUB.V_RESULT THEN
          P_SUCCESS_COUNT := P_SUCCESS_COUNT + 1;
          COMMIT;
        ELSE
          RAISE_APPLICATION_ERROR(-20123, P_ERR_MSG, FALSE);
        END IF;
      EXCEPTION
        WHEN OTHERS THEN
          ROLLBACK;
          P_FAIL_COUNT := P_FAIL_COUNT + 1;
          PKG_SO_RT.P_TABLE_ACTION_LOG(P_TABLE_NAME     => 'P_JOB_MAKE_RT_LOGIST',
                                       P_ACTION_REMARKS => 'JOB调用生成关联交易物流订单记录',
                                       P_PK             => REC.SO_NUM,
                                       P_ISERR          => 1, --是否出错，1出错，0未出错
                                       P_MSG            => P_ERR_MSG);
      END;
    END LOOP;
    V_EDATE := SYSDATE;
    PKG_SO_RT.P_TABLE_ACTION_LOG(P_TABLE_NAME     => 'P_JOB_MAKE_RT_LOGIST',
                                 P_ACTION_REMARKS => '生成关联交易物流订单记录JOB运行日志',
                                 P_PK             => TO_CHAR(SYSDATE,
                                                             'yyyymmdd'),
                                 P_ISERR          => 0, --是否出错，1出错，0未出错
                                 P_MSG            => '开始时间[' ||
                                                     TO_CHAR(V_SDATE,
                                                             'yyyy-mm-dd hh24:mi:ss') ||
                                                     ']，结算时间[' ||
                                                     TO_CHAR(V_EDATE,
                                                             'yyyy-mm-dd hh24:mi:ss') ||
                                                     ']，成功记录条数[' ||
                                                     P_SUCCESS_COUNT ||
                                                     ']，失败记录条数[' ||
                                                     P_FAIL_COUNT || ']');
  END;
  
  /*
     普通客户关联关易入口
  */
  PROCEDURE P_MAIN(P_SO_HEADER_ID IN T_SO_HEADER.SO_HEADER_ID%TYPE, --销售单头id
                   P_RESULT       IN OUT NUMBER, --返回错误ID
                   P_ERR_MSG      IN OUT VARCHAR2 --返回错误信息
                   ) AS
  
    V_PULL_MODE NUMBER;
  
    R_SO_HEADER T_SO_HEADER%ROWTYPE;
    
    V_INTF_SYSTEM_TYPE VARCHAR2(32);--财务接口对接系统标识 ERP：美的现有ERP系统；NC：用友NC财务系统。
  BEGIN
    --初始返回值
    P_RESULT  := PKG_SO_PUB.V_RESULT;
    P_ERR_MSG := PKG_SO_PUB.V_SUCCESS;
    BEGIN
      SELECT *
        INTO R_SO_HEADER
        FROM T_SO_HEADER
       WHERE SO_HEADER_ID = P_SO_HEADER_ID;
    
      IF R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE NOT IN
         (PKG_SO_PUB.V_BIZ_SRC_BILL_SO,
          PKG_SO_PUB.V_BIZ_SRC_BILL_SO_RED,
          PKG_SO_PUB.V_BIZ_SRC_BILL_RETURN,
          PKG_SO_PUB.V_BIZ_SRC_BILL_RETURN_RED) THEN
        RETURN;
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        /*P_TABLE_ACTION_LOG(P_TABLE_NAME     => 'PKG_SO_RT.P_MAIN',
        P_ACTION_REMARKS => '关联交易SO_HEADER_ID查询销售单',
        P_PK             => R_SO_HEADER.SO_HEADER_ID,
        P_ISERR          => 1,
        P_MSG            => SQLERRM);*/
        RAISE_APPLICATION_ERROR(-20123,
                                '销售单头ID[' || P_SO_HEADER_ID ||
                                ']查询销售单记录，出错：' || SQLERRM,
                                FALSE);
      
    END;
    
    --推广物料不触发关联交易（写接口表前加一道过滤）
    IF (NVL(R_SO_HEADER.IS_MATERIAL,PKG_SO_PUB.V_NO) = PKG_SO_PUB.V_YES) THEN
       RETURN;
    END IF;
    
    PKG_BD.P_GET_PARAMETER_VALUE(PKG_SO_PUB.V_INTF_SYSTEM_TYPE,
                                 R_SO_HEADER.ENTITY_ID,
                                 NULL,
                                 NULL,
                                 V_INTF_SYSTEM_TYPE);

    IF(V_INTF_SYSTEM_TYPE IS NOT NULL AND V_INTF_SYSTEM_TYPE = PKG_SO_PUB.V_INTF_SYSTEM_TYPE_NC) THEN
      RETURN;
    END IF;
    
    V_PULL_MODE := PKG_SO_PUB.F_PULL_MODE(R_SO_HEADER.SO_NUM);
    -- -1错误,0非拉式,1销售,2红冲,3源单退回,4反向销售,5源单退货红冲，6拉式其他单据类型
    IF V_PULL_MODE IN (1, 4, 5) THEN
      P_SO_TO_RT_ORDER(P_SO_HEADER_ID, P_RESULT, P_ERR_MSG);
      IF P_RESULT <> 0 THEN
        RAISE_APPLICATION_ERROR(-20123, P_ERR_MSG, FALSE);
      END IF;
      P_SO_TO_LG_ORDER(P_SO_HEADER_ID, '', P_RESULT, P_ERR_MSG); --如果前面有关联订单，需要将状态传空值，这样才可以实现串行
      IF P_RESULT <> 0 THEN
        RAISE_APPLICATION_ERROR(-20123, P_ERR_MSG, FALSE);
      END IF;
    
    ELSIF V_PULL_MODE IN (2, 3) THEN
      P_SO_TO_LG_ORDER(P_SO_HEADER_ID, 'N', P_RESULT, P_ERR_MSG);
      IF P_RESULT <> 0 THEN
        RAISE_APPLICATION_ERROR(-20123, P_ERR_MSG, FALSE);
      END IF;
    
    END IF;
    
    --以销售单行的更新税率/税码更新 ERP SO 接口表记录
    UPDATE INTF_OE_LINES_IFACE_ALL LI
       SET LI.TAX_CODE        =
           (SELECT SOL.TAX_CODE
              FROM T_SO_LINE SOL
             WHERE SOL.SO_LINE_ID = TO_NUMBER(LI.ORIG_SYS_LINE_REF)
               AND SOL.SO_HEADER_ID = R_SO_HEADER.SO_HEADER_ID
               AND ROWNUM = 1),
           LI.LAST_UPDATE_DATE = SYSDATE
     WHERE EXISTS (SELECT 1
              FROM INTF_OE_HEADERS_IFACE_ALL HI
             WHERE LI.OE_HEADERS_ID = HI.OE_HEADERS_ID
               AND HI.ORDER_NUMBER = TO_NUMBER(R_SO_HEADER.SO_NUM));
  
  EXCEPTION
    WHEN OTHERS THEN
      P_RESULT := -1;
      --P_ERR_MSG := SQLERRM;
      P_TABLE_ACTION_LOG(P_TABLE_NAME     => 'PKG_SO_RT.P_MAIN',
                         P_ACTION_REMARKS => '关联交易入口',
                         P_PK             => P_SO_HEADER_ID,
                         P_ISERR          => 1,
                         P_MSG            => P_ERR_MSG);
      --RAISE_APPLICATION_ERROR(-20123, SQLERRM, FALSE);
  END;

  /*
     事业部客户关联关易入口
  */
  PROCEDURE P_MAIN_ENTITY(P_SO_HEADER_ID IN T_SO_HEADER.SO_HEADER_ID%TYPE, --销售单头id
                   P_RESULT       IN OUT NUMBER, --返回错误ID
                   P_ERR_MSG      IN OUT VARCHAR2 --返回错误信息
                   ) AS
  
    V_PULL_MODE NUMBER;
  
    R_SO_HEADER T_SO_HEADER%ROWTYPE;
    --退货方式：1-推式，2-拉式源单退回，3-拉式反向销售
    V_RETURN_MODE T_SO_HEADER.RETURN_MODE%TYPE;
    
    V_INTF_HEAD_ID  NUMBER; --中转单接口表ID
    P_RESULT_MSG VARCHAR(500);
    V_PO_NUM t_Inv_Po_Headers.Po_Num%TYPE;
    V_SO_PO_GEN_ENABLE  VARCHAR(32);--是否启用生成中转单
    
    V_INTF_SYSTEM_TYPE VARCHAR2(32);--财务接口对接系统标识 ERP：美的现有ERP系统；NC：用友NC财务系统。
  BEGIN
    --初始返回值
    P_RESULT  := PKG_SO_PUB.V_RESULT;
    P_ERR_MSG := PKG_SO_PUB.V_SUCCESS;
    BEGIN
      SELECT *
        INTO R_SO_HEADER
        FROM T_SO_HEADER
       WHERE SO_HEADER_ID = P_SO_HEADER_ID;
    
      IF R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE NOT IN
         (PKG_SO_PUB.V_BIZ_SRC_BILL_SO,
          PKG_SO_PUB.V_BIZ_SRC_BILL_SO_RED,
          PKG_SO_PUB.V_BIZ_SRC_BILL_RETURN,
          PKG_SO_PUB.V_BIZ_SRC_BILL_RETURN_RED) THEN
        RETURN;
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        /*P_TABLE_ACTION_LOG(P_TABLE_NAME     => 'PKG_SO_RT.P_MAIN',
        P_ACTION_REMARKS => '关联交易SO_HEADER_ID查询销售单',
        P_PK             => R_SO_HEADER.SO_HEADER_ID,
        P_ISERR          => 1,
        P_MSG            => SQLERRM);*/
        RAISE_APPLICATION_ERROR(-20123,
                                '销售单头ID[' || P_SO_HEADER_ID ||
                                ']查询销售单记录，出错：' || SQLERRM,
                                FALSE);
      
    END;
    
    --推广物料不触发关联交易（写接口表前加一道过滤）
    IF (NVL(R_SO_HEADER.IS_MATERIAL,PKG_SO_PUB.V_NO) = PKG_SO_PUB.V_YES) THEN
       RETURN;
    END IF;
    
    PKG_BD.P_GET_PARAMETER_VALUE(PKG_SO_PUB.V_INTF_SYSTEM_TYPE,
                                 R_SO_HEADER.ENTITY_ID,
                                 NULL,
                                 NULL,
                                 V_INTF_SYSTEM_TYPE);

    IF(V_INTF_SYSTEM_TYPE IS NOT NULL AND V_INTF_SYSTEM_TYPE = PKG_SO_PUB.V_INTF_SYSTEM_TYPE_NC) THEN
      RETURN;
    END IF;
    
    V_RETURN_MODE := NVL(R_SO_HEADER.RETURN_MODE, '1'); --默认1-推式    
    IF V_RETURN_MODE = '3'  THEN
       P_ERR_MSG := '此销售单[ID：' || P_SO_HEADER_ID || ']不允许做反向销售业务' ;
       RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
    END IF;
        
    V_PULL_MODE := PKG_SO_PUB.F_PULL_MODE(R_SO_HEADER.SO_NUM);
    --销售单、退货红冲单
    IF R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE IN (PKG_SO_PUB.V_BIZ_SRC_BILL_SO, PKG_SO_PUB.V_BIZ_SRC_BILL_RETURN_RED) THEN
      P_SO_TO_RT_ORDER_ENTITY(P_SO_HEADER_ID, P_RESULT, P_ERR_MSG);
      IF P_RESULT <> 0 THEN
        RAISE_APPLICATION_ERROR(-20123, P_ERR_MSG, FALSE);
      END IF;
      P_SO_TO_LG_ORDER_ENTITY(P_SO_HEADER_ID, '', P_RESULT, P_ERR_MSG); --如果前面有关联订单，需要将状态传空值，这样才可以实现串行
      IF P_RESULT <> 0 THEN
        RAISE_APPLICATION_ERROR(-20123, P_ERR_MSG, FALSE);
      END IF;
    --红冲单、退货单
    ELSIF R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE IN (PKG_SO_PUB.V_BIZ_SRC_BILL_SO_RED, PKG_SO_PUB.V_BIZ_SRC_BILL_RETURN) THEN
      P_SO_TO_LG_ORDER_ENTITY(P_SO_HEADER_ID, 'P', P_RESULT, P_ERR_MSG);
      IF P_RESULT <> 0 THEN
        RAISE_APPLICATION_ERROR(-20123, P_ERR_MSG, FALSE);
      END IF;
    
    END IF;
/*    
    PKG_BD.P_GET_PARAMETER_VALUE('SO_PO_GEN_ENABLE',
                                 R_SO_HEADER.ENTITY_ID,
                                 NULL,
                                 NULL,
                                 V_SO_PO_GEN_ENABLE);    
    IF V_SO_PO_GEN_ENABLE = 'Y' THEN
      --销售单插入中转接口表：
      PKG_INV_SO_PO.P_SO_CREATE_TO_INTF(P_SO_HEADER_ID, --销售单头ID
                                      'SYS', --账户编码
                                      V_INTF_HEAD_ID,   --生成的接口头ID
                                      P_RESULT_MSG); --返回的结果
      IF P_RESULT_MSG <> 'SUCCESS' THEN
        P_ERR_MSG :=P_RESULT_MSG;
        RAISE_APPLICATION_ERROR(-20123, '销售单【'||R_SO_HEADER.SO_NUM||'】生成中转单接口出错：'||P_RESULT_MSG, FALSE);
      END IF;                                    
      --更新中转接口表到正式表：
      PKG_INV_SO_PO.P_INTF_CREATE_TO_PO(V_INTF_HEAD_ID, --接口表头ID
                          'SYS', --账户编码
                          V_PO_NUM , --生成的中转单号
                          P_RESULT_MSG); --返回的结果  
      IF P_RESULT_MSG <> 'SUCCESS' THEN
        P_ERR_MSG :=P_RESULT_MSG;
        RAISE_APPLICATION_ERROR(-20123, '销售单【'||R_SO_HEADER.SO_NUM||'】生成中转单出错：'||P_RESULT_MSG, FALSE);
      END IF;       
    END IF;  */                      
  
  EXCEPTION
    WHEN OTHERS THEN
      P_RESULT := -1;
      --P_ERR_MSG := SQLERRM;
      P_TABLE_ACTION_LOG(P_TABLE_NAME     => 'PKG_SO_RT.P_MAIN_ENTITY',
                         P_ACTION_REMARKS => '事业部客户关联交易入口',
                         P_PK             => P_SO_HEADER_ID,
                         P_ISERR          => 1,
                         P_MSG            => P_ERR_MSG);
      --RAISE_APPLICATION_ERROR(-20123, SQLERRM, FALSE);
  END;
  
  /*
  
  */
  PROCEDURE P_TEST(P_SQL VARCHAR2) AS
  BEGIN
    EXECUTE IMMEDIATE P_SQL;
  END;
  -------------------------------------------------------------------------------  
  /*
  *   创建日期：2016-11-17
  *     创建者：周建刚
  *   功能说明：内部关联交易客户，需方主体在CIMS实施，则根据供方的销售单生成需方对应的PO单
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_TO_PO(P_SO_HEADER_ID IN T_SO_HEADER.SO_HEADER_ID%TYPE, --销售单头id
                       P_RESULT       IN OUT NUMBER, --返回错误ID
                       P_ERR_MSG      IN OUT VARCHAR2 --返回错误信息
                       ) AS
    --销售单据头
    CURSOR C_SO_HEADER IS
      SELECT * FROM T_SO_HEADER WHERE SO_HEADER_ID = P_SO_HEADER_ID;
    R_SO_HEADER C_SO_HEADER%ROWTYPE;
    
    --事业部供需关系配置
    R_SO_SUPPLIER_REQUIRE_ENTITY T_SO_SUPPLIER_REQUIRE_ENTITY%ROWTYPE;
    
    R_INV_PO_HEADERS T_INV_PO_HEADERS%ROWTYPE;
    
    --是否启用生成跨主体中转单
    V_SO_PO_GEN_ENABLE  VARCHAR2(32);
    
    --生成的接口头ID
    V_INTF_HEAD_ID VARCHAR2(32);
    
    V_USER_CODE VARCHAR2(32) := 'SYS';
    --中转单号
    V_PO_NUM VARCHAR2(32);
    --中转单头ID
    V_PO_HEAD_ID VARCHAR2(32);
    --特殊库存占用标识
    V_SPECIAL_OCCUPY_FLAG VARCHAR2(32);
    --物流对接方式
    V_LG_SEND_TYPE VARCHAR2(32);
    
    V_INTF_SYSTEM_TYPE VARCHAR2(32);--财务接口对接系统标识 ERP：美的现有ERP系统；NC：用友NC财务系统。
  BEGIN
    --初始返回值
    P_RESULT  := PKG_SO_PUB.V_RESULT;
    P_ERR_MSG := PKG_SO_PUB.V_SUCCESS;

    --获取销售单据头数据
    OPEN C_SO_HEADER;
    FETCH C_SO_HEADER
      INTO R_SO_HEADER;
    CLOSE C_SO_HEADER;
    
    PKG_BD.P_GET_PARAMETER_VALUE(PKG_SO_PUB.V_INTF_SYSTEM_TYPE,
                                 R_SO_HEADER.ENTITY_ID,
                                 NULL,
                                 NULL,
                                 V_INTF_SYSTEM_TYPE);

    IF(V_INTF_SYSTEM_TYPE IS NOT NULL AND V_INTF_SYSTEM_TYPE = PKG_SO_PUB.V_INTF_SYSTEM_TYPE_NC) THEN
      RETURN;
    END IF;
    
    IF (NVL(R_SO_HEADER.ENTITY_CUST_FLAG,PKG_SO_PUB.V_NO) <> PKG_SO_PUB.V_YES) THEN
      P_ERR_MSG := '非内部关联交易客户[' || R_SO_HEADER.CUSTOMER_NAME || ']不需要根据供方的销售单生成需方对应的PO单！';
      RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
    END IF;
    
    BEGIN
       --根据供方业务主体、供方OU、需方客户 获取事业部供需关系配置； 
       SELECT T.* INTO R_SO_SUPPLIER_REQUIRE_ENTITY
          FROM T_SO_SUPPLIER_REQUIRE_ENTITY T
         WHERE T.SUPPLIER_ENTITY_ID = R_SO_HEADER.ENTITY_ID
            AND T.SUPPLIER_OU_ID = R_SO_HEADER.ERP_OU_ID
            AND T.REQUIREMENT_CUSTOMER_ID = R_SO_HEADER.CUSTOMER_ID;           
    EXCEPTION
      WHEN OTHERS THEN
        P_ERR_MSG := '查询事业部客户在事业部供需关系配置出现异常！主体['
        || R_SO_HEADER.ENTITY_ID || '],供方OU[' || R_SO_HEADER.ERP_OU_ID || '],客户[' || R_SO_HEADER.CUSTOMER_ID || ',' || R_SO_HEADER.CUSTOMER_CODE || ']' || SQLERRM;
        RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
    END;
      
    IF (/*R_SO_SUPPLIER_REQUIRE_ENTITY NOT NULL AND */R_SO_SUPPLIER_REQUIRE_ENTITY.REQUIREMENT_ENTITY_ID IS NOT NULL) THEN
      --获取需方主体是否生成PO单的配置 SO_PO_GEN_ENABLE,chenyj8,20180312按需方主体判断是否需要生成PO
      BEGIN
        PKG_BD.P_GET_PARAMETER_VALUE('SO_PO_GEN_ENABLE',
                                     R_SO_SUPPLIER_REQUIRE_ENTITY.REQUIREMENT_ENTITY_ID,
                                     NULL,
                                     NULL,
                                     V_SO_PO_GEN_ENABLE);
      EXCEPTION
        WHEN OTHERS THEN
          P_ERR_MSG := 'SO_PO_GEN_ENABLE 主体参数,主体[' ||
                       R_SO_HEADER.ENTITY_ID || ']的参数设置异常，请检查。' ||
                       SQLERRM;
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      END;

      --生成中转单
      IF (V_SO_PO_GEN_ENABLE = PKG_SO_PUB.V_YES) THEN
        --生成中转单步骤一：根据销售单插入接口表 INTF_INV_PO_HEADERS_SOURCE
        PKG_INV_SO_PO.P_SO_CREATE_TO_INTF(R_SO_HEADER.SO_HEADER_ID,V_USER_CODE,V_INTF_HEAD_ID,P_ERR_MSG);
        IF P_ERR_MSG <> PKG_SO_PUB.V_SUCCESS THEN
          P_ERR_MSG := '根据销售单插入接口表 INTF_INV_PO_HEADERS_SOURCE失败：' || P_ERR_MSG;
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
        END IF;
        
        --生成中转单步骤二：根据中转单接口表生成中转单
        PKG_INV_SO_PO.P_INTF_CREATE_TO_PO(V_INTF_HEAD_ID,V_USER_CODE,V_PO_NUM,V_PO_HEAD_ID,P_ERR_MSG);
        IF P_ERR_MSG <> PKG_SO_PUB.V_SUCCESS THEN
          P_ERR_MSG := '根据中转单接口表生成中转单失败：' || P_ERR_MSG;
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
        END IF;
        
        BEGIN
           --根据中转单号、ID获取中转单 
           SELECT T.* INTO R_INV_PO_HEADERS
              FROM T_INV_PO_HEADERS T
             WHERE T.PO_NUM = V_PO_NUM
              AND T.PO_ID = V_PO_HEAD_ID;           
        EXCEPTION
          WHEN OTHERS THEN
            P_ERR_MSG := '根据中转单号[' || V_PO_HEAD_ID || ',' || V_PO_NUM || ']获取中转单出现异常！'|| SQLERRM;
            RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
        END;
        
        --获取单据类型对应的特殊库存占用标识
        BEGIN
          SELECT SPECIAL_OCCUPY_FLAG
            INTO V_SPECIAL_OCCUPY_FLAG
            FROM T_INV_BILL_TYPES
           WHERE BILL_TYPE_CODE = R_INV_PO_HEADERS.PO_TYPE
             AND ENTITY_ID = R_INV_PO_HEADERS.ENTITY_ID;       
        EXCEPTION
          WHEN OTHERS THEN
            P_ERR_MSG := '获取单据类型[' || R_INV_PO_HEADERS.PO_TYPE || '],主体[' || R_INV_PO_HEADERS.ENTITY_ID || ']对应的特殊库存占用标识出现异常！'|| SQLERRM;
            RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
        END;
        
        --处理特殊库存占用
        IF (NVL(V_SPECIAL_OCCUPY_FLAG,PKG_SO_PUB.V_NO) = PKG_SO_PUB.V_YES) THEN
            
            PKG_PLN_SHARES.P_ORDER_SPECIAL_OCCUPY(R_INV_PO_HEADERS.ENTITY_ID,R_INV_PO_HEADERS.PO_ID,R_INV_PO_HEADERS.PO_TYPE_ID,V_USER_CODE,P_ERR_MSG);
            IF P_ERR_MSG <> PKG_SO_PUB.V_SUCCESS THEN
              P_ERR_MSG := '处理特殊库存占用失败：' || P_ERR_MSG || '。入参主体['
               || R_INV_PO_HEADERS.ENTITY_ID || '],中转单[' || R_INV_PO_HEADERS.PO_ID || '],类型[' || R_INV_PO_HEADERS.PO_TYPE_ID || ']';
              RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
            END IF;

        END IF;
      
        --生成中转单步骤三：中转单推送物流系统改由业务在中转单管理界面人工触发
      END IF;
      
    END IF;

  EXCEPTION
    WHEN PKG_SO_PUB.V_BIZ_EXCEPTION THEN
      P_RESULT  := -28000;
      P_ERR_MSG := '内部关联交易客户，根据供方的销售单[' || P_SO_HEADER_ID ||
                   ']生成需方对应的PO单发生异常，原因：' || P_ERR_MSG;
    WHEN OTHERS THEN
      P_RESULT  := -28009;
      P_ERR_MSG := '内部关联交易客户，根据供方的销售单[' || P_SO_HEADER_ID ||
                   ']生成需方对应的PO单发生异常，原因：' || SQLERRM;
  END;
  
  -----------------------------------------------------------------------------
  --处理需要校验价格的单边订单
  -----------------------------------------------------------------------------
  PROCEDURE P_JOB_CHECK_PRICE
  (
    P_ENTITY_ID      IN T_SO_HEADER.ENTITY_ID%TYPE, --主体id
    P_SO_HEADER_ID   IN T_SO_HEADER.SO_HEADER_ID%TYPE, --销售单头id
    P_RESULT         IN OUT NUMBER, --返回错误ID
    P_ERR_MSG        IN OUT VARCHAR2 --返回错误信息
  ) IS

  V_CNT           NUMBER;
  V_PRICE_LINE    NUMBER; --销售单行不含税价格
  V_PRICE_DETAIL  NUMBER; --销售单明细不含税价格
  V_ACCOUNT_ID    T_SO_HEADER.ACCOUNT_ID%TYPE;--账户ID
  V_TRX_RATE      NUMBER;  --事业部采购税率
  V_DIFF_NUMBER   NUMBER;  --重算价格允许的误差范围
  BEGIN
    P_RESULT               := 0;
    P_ERR_MSG              := 'SUCCESS';
    V_DIFF_NUMBER          := 0.0001;
    --关联订单校验价格
    FOR R_ORDER_REQ_HEADER IN (
        SELECT *
          FROM CIMS.INTF_CUX_ICP_ORDER_REQ_HEADERS T
         WHERE T.SOURCE_ORDERS_TYPE IN ('03')
           AND T.X_ICP_SEQ_ID IS NULL
           AND T.PRICE_CHECK_FLAG = 'Y'
           AND NVL(T.PRICE_ERR_FLAG,'_') <> 'N'
           AND T.ENTITY_ID = P_ENTITY_ID
           AND T.SOURCE_HEADER_ID = NVL(P_SO_HEADER_ID, T.SOURCE_HEADER_ID)) LOOP
        BEGIN
         --取销售单账户ID
          SELECT ACCOUNT_ID
              INTO V_ACCOUNT_ID
              FROM T_SO_HEADER
             WHERE SO_HEADER_ID = R_ORDER_REQ_HEADER.SOURCE_HEADER_ID;
             
          --取配置税率
          SELECT NVL(TRX_RATE, 0) TRX_RATE
           INTO V_TRX_RATE
           FROM T_SO_SUPPLIER_REQUIRE_ENTITY T
          WHERE T.SUPPLIER_ENTITY_ID = R_ORDER_REQ_HEADER.ENTITY_ID
            AND T.SUPPLIER_OU_ID = R_ORDER_REQ_HEADER.SUPPLIER_ORG_ID
            AND T.REQUIREMENT_OU_ID = R_ORDER_REQ_HEADER.REQUIREMENT_ORG_ID
            AND ROWNUM = 1;
            
          V_TRX_RATE := (V_TRX_RATE/100) + 1;  --折算后税率          
         
          --重新取价
          FOR R_ORDER_REQ_LINE IN (
              SELECT *
                FROM CIMS.INTF_CUX_ICP_ORDER_REQ_LINES L
               WHERE L.HEADERS_ID = R_ORDER_REQ_HEADER.ID
          ) LOOP
            
            --散件取价，可以为空
            V_PRICE_DETAIL := PKG_BD_PRICE.F_GET_PRICE( V_ACCOUNT_ID,
                                          R_ORDER_REQ_LINE.SUPPLIER_ITEM_NUM,
                                          TO_CHAR(SYSDATE,'YYYYMMDD'),
                                          NULL,
                                          R_ORDER_REQ_HEADER.ENTITY_ID);
             UPDATE CIMS.INTF_CUX_ICP_ORDER_REQ_LINES LINE
                SET LINE.UNIT_PRICE = V_PRICE_DETAIL / V_TRX_RATE,
                    LINE.ITEM_PRICE = V_PRICE_DETAIL
              WHERE LINE.ID = R_ORDER_REQ_LINE.ID;
             --更新取价时间
             UPDATE CIMS.INTF_CUX_ICP_ORDER_REQ_HEADERS H
                SET H.PRICE_RESET_DATE = SYSDATE
              WHERE H.ID = R_ORDER_REQ_HEADER.ID;
          END LOOP;
          
         
          --计算销售单行的总价
          SELECT SUM(NVL(L.ITEM_SETTLE_PRICE,0)*L.ITEM_QTY)/V_TRX_RATE INTO V_PRICE_LINE FROM T_SO_LINE L WHERE L.SO_HEADER_ID = R_ORDER_REQ_HEADER.SOURCE_HEADER_ID;
          --计算接口表价格
          SELECT SUM(NVL(L.UNIT_PRICE,0)*L.REQUEST_QUANTITY) INTO V_PRICE_DETAIL FROM INTF_CUX_ICP_ORDER_REQ_LINES L WHERE L.HEADERS_ID = R_ORDER_REQ_HEADER.ID;
          
          IF ABS(V_PRICE_LINE - V_PRICE_DETAIL) < V_DIFF_NUMBER THEN 
             UPDATE INTF_CUX_ICP_ORDER_REQ_HEADERS H
               SET H.PRICE_ERR_FLAG = 'N', H.PRICE_ERR_MSG = NULL
             WHERE H.ID = R_ORDER_REQ_HEADER.ID;
             
     
          ELSE
             /*
                 chenyj8 20180727 关联订单,重算价格后，还是有差异而且所有散件都维护了价格，
                 则按散件价格配比单据总价格重算散件价格
             */
             SELECT COUNT(1)
               INTO V_CNT
               FROM CIMS.INTF_CUX_ICP_ORDER_REQ_LINES RL
              WHERE RL.SOURCE_HEADER = R_ORDER_REQ_HEADER.SOURCE_ORDERS
                AND RL.UNIT_PRICE IS NULL
                AND RL.SOURCE_HEADER_ID =
                    R_ORDER_REQ_HEADER.SOURCE_HEADER_ID;
             
             IF V_CNT > 0 THEN
               SELECT '没有定义价格的产品(散件):' || WM_CONCAT(RL.SUPPLIER_ITEM_NUM)
                 INTO P_ERR_MSG
                 FROM CIMS.INTF_CUX_ICP_ORDER_REQ_LINES RL
                WHERE RL.SOURCE_HEADER = R_ORDER_REQ_HEADER.SOURCE_ORDERS
                  AND RL.UNIT_PRICE IS NULL
                  AND RL.SOURCE_HEADER_ID =
                      R_ORDER_REQ_HEADER.SOURCE_HEADER_ID;
               P_ERR_MSG := P_ERR_MSG || ';销售单据行价格总和（不含税）[' || V_PRICE_LINE ||
                            ']跟接口价格总和[' || V_PRICE_DETAIL || ']不一致，请检查;';
               RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
             END IF;
 
             --按散件价格配比分配单据头结算价
             UPDATE CIMS.INTF_CUX_ICP_ORDER_REQ_LINES RL
                SET RL.ITEM_PRICE = (SELECT SUM(NVL(L.ITEM_SETTLE_PRICE, 0) * L.ITEM_QTY)
                                      FROM CIMS.T_SO_LINE L
                                     WHERE L.SO_HEADER_ID = RL.SOURCE_HEADER_ID) *
                                   RL.ITEM_PRICE /
                                   (SELECT SUM(NVL(L.ITEM_PRICE, 0) * L.REQUEST_QUANTITY)
                                      FROM CIMS.INTF_CUX_ICP_ORDER_REQ_LINES L
                                     WHERE L.SOURCE_HEADER = RL.SOURCE_HEADER),
                    RL.UNIT_PRICE = ((SELECT SUM(NVL(L.ITEM_SETTLE_PRICE, 0) * L.ITEM_QTY)
                                       FROM CIMS.T_SO_LINE L
                                      WHERE L.SO_HEADER_ID = RL.SOURCE_HEADER_ID) *
                                   RL.ITEM_PRICE /
                                   (SELECT SUM(NVL(L.ITEM_PRICE, 0) * L.REQUEST_QUANTITY)
                                       FROM CIMS.INTF_CUX_ICP_ORDER_REQ_LINES L
                                      WHERE L.SOURCE_HEADER = RL.SOURCE_HEADER)) / V_TRX_RATE
              WHERE RL.SOURCE_HEADER = R_ORDER_REQ_HEADER.SOURCE_ORDERS
                 AND RL.SOURCE_HEADER_ID = R_ORDER_REQ_HEADER.SOURCE_HEADER_ID;
             
             --重算配比价格后，更新校验标记
             UPDATE INTF_CUX_ICP_ORDER_REQ_HEADERS OH
                SET OH.PRICE_ERR_FLAG   = 'N',
                    OH.PRICE_ERR_MSG    = NULL
              WHERE 1 = 1
                AND EXISTS
              (SELECT TO_CHAR(P1), TO_CHAR(P2), SOURCE_ORDERS
                       FROM (SELECT (SELECT SUM(NVL(L.ITEM_SETTLE_PRICE, 0) *
                                                L.ITEM_QTY)
                                       FROM CIMS.T_SO_LINE L
                                      WHERE L.SO_HEADER_ID =
                                            T.SOURCE_HEADER_ID) P1,
                                    (SELECT SUM(NVL(L.ITEM_PRICE, 0) *
                                                L.REQUEST_QUANTITY)
                                       FROM CIMS.INTF_CUX_ICP_ORDER_REQ_LINES L
                                      WHERE L.SOURCE_HEADER = T.SOURCE_ORDERS) P2,
                                    T.SOURCE_ORDERS
                               FROM CIMS.INTF_CUX_ICP_ORDER_REQ_HEADERS T
                              WHERE T.SOURCE_ORDERS = R_ORDER_REQ_HEADER.SOURCE_ORDERS)
                      WHERE ABS(P1 - P2) < V_DIFF_NUMBER
                        AND SOURCE_ORDERS = OH.SOURCE_ORDERS);
           
          END IF;
          --把关联订单的价格带到关联物流行
          UPDATE INTF_CUX_ICP_LOGIST_REQ_LINES RL
             SET RL.ITEM_PRICE = (SELECT OL.ITEM_PRICE
                                    FROM INTF_CUX_ICP_ORDER_REQ_LINES OL
                                   WHERE OL.SOURCE_HEADER_ID =
                                         RL.SOURCE_HEADER_ID
                                     AND OL.SOURCE_HEADER =
                                         RL.SOURCE_HEADER
                                     AND OL.SUPPLIER_ITEM_NUM =
                                         RL.SUPPLIER_ITEM_NUM
                                     AND ROWNUM = 1),
                 RL.UNIT_PRICE = (SELECT OL.UNIT_PRICE
                                    FROM INTF_CUX_ICP_ORDER_REQ_LINES OL
                                   WHERE OL.SOURCE_HEADER_ID =
                                         RL.SOURCE_HEADER_ID
                                     AND OL.SOURCE_HEADER =
                                         RL.SOURCE_HEADER
                                     AND OL.SUPPLIER_ITEM_NUM =
                                         RL.SUPPLIER_ITEM_NUM
                                     AND ROWNUM = 1)
           WHERE RL.SOURCE_HEADER = R_ORDER_REQ_HEADER.SOURCE_ORDERS
             AND RL.SOURCE_HEADER_ID = R_ORDER_REQ_HEADER.SOURCE_HEADER_ID;
                 
        EXCEPTION
        WHEN OTHERS THEN
          P_RESULT  := -1;
          P_ERR_MSG := '关联订单价格校验处理异常,原因：' || P_ERR_MSG || SUBSTR(SQLERRM,1,1000);
          UPDATE INTF_CUX_ICP_ORDER_REQ_HEADERS H
             SET H.PRICE_ERR_FLAG = 'Y', H.PRICE_ERR_MSG = P_ERR_MSG
           WHERE H.ID = R_ORDER_REQ_HEADER.ID;
        END;

    END LOOP;
     
    --关联物流校验价格
    FOR R_LG_REQ_HEADER IN (
        SELECT *
          FROM CIMS.INTF_CUX_ICP_LOGIST_REQ_HEADER T
         WHERE T.REQUIREMENT_ORDER_TYPE IN ('03')
           --AND T.X_ICP_SEQ_ID IS NULL
           AND T.PRICE_CHECK_FLAG = 'Y'
           AND NVL(T.PRICE_ERR_FLAG,'_') <> 'N'
           AND T.ENTITY_ID = P_ENTITY_ID
           AND T.SOURCE_HEADER_ID = NVL(P_SO_HEADER_ID, T.SOURCE_HEADER_ID)) LOOP
        BEGIN
        
        --取销售单账户ID
          SELECT ACCOUNT_ID
              INTO V_ACCOUNT_ID
              FROM T_SO_HEADER
             WHERE SO_HEADER_ID = R_LG_REQ_HEADER.SOURCE_HEADER_ID;
             
          --取配置税率
          SELECT NVL(TRX_RATE, 0) TRX_RATE
           INTO V_TRX_RATE
           FROM T_SO_SUPPLIER_REQUIRE_ENTITY T
          WHERE T.SUPPLIER_ENTITY_ID = R_LG_REQ_HEADER.ENTITY_ID
            AND T.SUPPLIER_OU_ID = R_LG_REQ_HEADER.SUPPLIER_ORG_ID
            AND T.REQUIREMENT_OU_ID = R_LG_REQ_HEADER.REQUIREMENT_ORG_ID
            AND ROWNUM = 1;
            
          V_TRX_RATE := (V_TRX_RATE/100) + 1;  --折算后税率               
          --重新取价
          FOR R_LG_REQ_LINE IN (
              SELECT *
                FROM CIMS.INTF_CUX_ICP_LOGIST_REQ_LINES L
               WHERE L.HEADERS_ID = R_LG_REQ_HEADER.ID
          ) LOOP
            
            --散件取价，可以为空
            V_PRICE_DETAIL := PKG_BD_PRICE.F_GET_PRICE( V_ACCOUNT_ID,
                                          R_LG_REQ_LINE.SUPPLIER_ITEM_NUM,
                                          TO_CHAR(SYSDATE,'YYYYMMDD'),
                                          NULL,
                                          R_LG_REQ_HEADER.ENTITY_ID);
             UPDATE CIMS.INTF_CUX_ICP_LOGIST_REQ_LINES LINE
                SET LINE.UNIT_PRICE = V_PRICE_DETAIL / V_TRX_RATE,
                    LINE.ITEM_PRICE = V_PRICE_DETAIL
              WHERE LINE.ID = R_LG_REQ_LINE.ID;
             --更新取价时间
             UPDATE CIMS.INTF_CUX_ICP_LOGIST_REQ_HEADER H
                SET H.PRICE_RESET_DATE = SYSDATE
              WHERE H.ID = R_LG_REQ_HEADER.ID;
          END LOOP;
          
         
          --计算销售单行的总价
          SELECT SUM(NVL(L.ITEM_SETTLE_PRICE,0)*L.ITEM_QTY) INTO V_PRICE_LINE FROM T_SO_LINE L WHERE L.SO_HEADER_ID = R_LG_REQ_HEADER.SOURCE_HEADER_ID;
          --计算接口表价格
          SELECT SUM(NVL(L.ITEM_PRICE,0)*L.REQUEST_QUANTITY) INTO V_PRICE_DETAIL FROM INTF_CUX_ICP_LOGIST_REQ_LINES L WHERE L.HEADERS_ID = R_LG_REQ_HEADER.ID;
          
          IF V_PRICE_LINE = V_PRICE_DETAIL THEN 
             UPDATE INTF_CUX_ICP_LOGIST_REQ_HEADER H
               SET H.PRICE_ERR_FLAG = 'N', H.PRICE_ERR_MSG = NULL
             WHERE H.ID = R_LG_REQ_HEADER.ID;
          ELSE
             /*
                 chenyj8 20180727 关联物流,重算价格后，还是有差异而且所有散件都维护了价格，
                 则按散件价格配比单据总价格重算散件价格
             */
             SELECT COUNT(1)
               INTO V_CNT
               FROM CIMS.INTF_CUX_ICP_LOGIST_REQ_LINES RL
              WHERE RL.SOURCE_HEADER = R_LG_REQ_HEADER.REQUIREMENT_ORDER_NUM
                AND RL.UNIT_PRICE IS NULL
                AND RL.SOURCE_HEADER_ID =
                    R_LG_REQ_HEADER.SOURCE_HEADER_ID;
             
             IF V_CNT > 0 THEN
               SELECT '没有定义价格的产品(散件):' || WM_CONCAT(RL.SUPPLIER_ITEM_NUM)
                 INTO P_ERR_MSG
                 FROM CIMS.INTF_CUX_ICP_LOGIST_REQ_LINES RL
                WHERE RL.SOURCE_HEADER = R_LG_REQ_HEADER.REQUIREMENT_ORDER_NUM
                  AND RL.UNIT_PRICE IS NULL
                  AND RL.SOURCE_HEADER_ID =
                      R_LG_REQ_HEADER.SOURCE_HEADER_ID;
               P_ERR_MSG := P_ERR_MSG || ';销售单据行价格总和（不含税）[' || V_PRICE_LINE ||
                            ']跟接口价格总和[' || V_PRICE_DETAIL || ']不一致，请检查;';
               RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
             END IF;
 
             --按散件价格配比分配单据头结算价
             UPDATE CIMS.INTF_CUX_ICP_LOGIST_REQ_LINES RL
                SET RL.ITEM_PRICE = (SELECT SUM(NVL(L.ITEM_SETTLE_PRICE, 0) * L.ITEM_QTY)
                                      FROM CIMS.T_SO_LINE L
                                     WHERE L.SO_HEADER_ID = RL.SOURCE_HEADER_ID) *
                                   RL.ITEM_PRICE /
                                   (SELECT SUM(NVL(L.ITEM_PRICE, 0) * L.REQUEST_QUANTITY)
                                      FROM CIMS.INTF_CUX_ICP_LOGIST_REQ_LINES L
                                     WHERE L.SOURCE_HEADER = RL.SOURCE_HEADER),
                    RL.UNIT_PRICE = ((SELECT SUM(NVL(L.ITEM_SETTLE_PRICE, 0) * L.ITEM_QTY)
                                       FROM CIMS.T_SO_LINE L
                                      WHERE L.SO_HEADER_ID = RL.SOURCE_HEADER_ID) *
                                   RL.ITEM_PRICE /
                                   (SELECT SUM(NVL(L.ITEM_PRICE, 0) * L.REQUEST_QUANTITY)
                                       FROM CIMS.INTF_CUX_ICP_LOGIST_REQ_LINES L
                                      WHERE L.SOURCE_HEADER = RL.SOURCE_HEADER)) / V_TRX_RATE
              WHERE RL.SOURCE_HEADER = R_LG_REQ_HEADER.REQUIREMENT_ORDER_NUM
                 AND RL.SOURCE_HEADER_ID = R_LG_REQ_HEADER.SOURCE_HEADER_ID;
             
             --重算配比价格后，更新校验标记
             UPDATE INTF_CUX_ICP_LOGIST_REQ_HEADER OH
                SET OH.PRICE_ERR_FLAG   = 'N',
                    OH.PRICE_ERR_MSG    = NULL
              WHERE 1 = 1
                AND EXISTS
              (SELECT TO_CHAR(P1), TO_CHAR(P2), REQUIREMENT_ORDER_NUM
                       FROM (SELECT (SELECT SUM(NVL(L.ITEM_SETTLE_PRICE, 0) *
                                                L.ITEM_QTY)
                                       FROM CIMS.T_SO_LINE L
                                      WHERE L.SO_HEADER_ID =
                                            T.SOURCE_HEADER_ID) P1,
                                    (SELECT SUM(NVL(L.ITEM_PRICE, 0) *
                                                L.REQUEST_QUANTITY)
                                       FROM CIMS.INTF_CUX_ICP_LOGIST_REQ_LINES L
                                      WHERE L.SOURCE_HEADER = T.REQUIREMENT_ORDER_NUM) P2,
                                    T.REQUIREMENT_ORDER_NUM
                               FROM CIMS.INTF_CUX_ICP_LOGIST_REQ_HEADER T
                              WHERE T.REQUIREMENT_ORDER_NUM = R_LG_REQ_HEADER.REQUIREMENT_ORDER_NUM)
                      WHERE ABS(P1 - P2) < V_DIFF_NUMBER
                        AND REQUIREMENT_ORDER_NUM = OH.REQUIREMENT_ORDER_NUM);
          END IF;
          
        EXCEPTION
        WHEN OTHERS THEN
          P_RESULT  := -1;
          P_ERR_MSG := '关联物流价格校验处理异常,原因：' || P_ERR_MSG || SUBSTR(SQLERRM,1,1000);
          UPDATE INTF_CUX_ICP_LOGIST_REQ_HEADER H
             SET H.PRICE_ERR_FLAG = 'Y', H.PRICE_ERR_MSG = P_ERR_MSG
           WHERE H.ID = R_LG_REQ_HEADER.ID;
        END;

    END LOOP;
     
      
  EXCEPTION
    WHEN OTHERS THEN
      P_RESULT  := -1;
      P_ERR_MSG := '价格校验处理异常，异常原因：' || SUBSTR(SQLERRM,1,100);
  END;
  -------------------------------------------------------------------------------
END PKG_SO_RT;
/

