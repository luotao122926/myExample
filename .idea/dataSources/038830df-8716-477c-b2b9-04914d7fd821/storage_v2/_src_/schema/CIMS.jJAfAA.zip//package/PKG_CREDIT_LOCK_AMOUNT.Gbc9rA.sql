create package PKG_CREDIT_LOCK_AMOUNT is

  -- Author  : TIANMENGZHU
  -- Created : 2017/7/3 8:42:27
  -- Purpose : 

  FUNCTION F_GET_LOCK_AMOUNT(IN_ENTITY_ID       NUMBER, --主体ID 不能为空
                             IN_CUSTOMER_ID     NUMBER, --客户ID 可以为空
                             IS_CUSTOMER_CODE   VARCHAR2, --客户编码
                             IN_ACCOUNT_ID      NUMBER, --账户ID 可以为空
                             IS_ACCOUNT_CODE    VARCHAR2, --账户编码 可以为空
                             IN_CREDIT_GROUP_ID NUMBER, --额度组ID 可以为空
                             IN_SALES_CENTER_ID   NUMBER, --营销中心ID
                             IS_SALES_CENTER_CODE VARCHAR2, --营销中心编码
                             IS_USER_ACC        VARCHAR2 --用户账号 不能为空
                             ,IS_DISCOUNT_TYPE   VARCHAR2--折让方式
                             ) RETURN TAB_CREDIT_LOCK_AMOUNT
    PIPELINED;

end PKG_CREDIT_LOCK_AMOUNT;
/

