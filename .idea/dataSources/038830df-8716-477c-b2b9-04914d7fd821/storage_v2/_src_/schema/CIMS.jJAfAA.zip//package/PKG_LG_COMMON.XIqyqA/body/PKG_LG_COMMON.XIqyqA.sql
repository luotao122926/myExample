create PACKAGE BODY      PKG_LG_COMMON AS

  ----------------------------------------------------------------------
  -- AUTHOR  : XUQF
  -- CREATED : 2014-08-05
  -- PURPOSE : 拆分字符串
  ----------------------------------------------------------------------
  FUNCTION F_SPLIT_STR(AS_STR IN VARCHAR2, AS_SPLIT_STR IN VARCHAR2)
    RETURN TYPE_SPLIT AS
    LS_STR   TYPE_SPLIT := TYPE_SPLIT();
    V_SY_STR VARCHAR2(32767);
    V_STR    VARCHAR2(1000);
  BEGIN
    IF TRIM(AS_STR) IS NULL OR TRIM(AS_SPLIT_STR) IS NULL THEN
      RETURN LS_STR;
    END IF;
  
    V_SY_STR := AS_STR;
  
    IF INSTR(V_SY_STR, AS_SPLIT_STR) = 0 THEN
      LS_STR.EXTEND;
      LS_STR(LS_STR.COUNT) := V_SY_STR;
      RETURN LS_STR;
    END IF;
  
    LOOP
    
      IF INSTR(V_SY_STR, AS_SPLIT_STR) = 0 THEN
        V_STR := V_SY_STR;
        LS_STR.EXTEND;
        LS_STR(LS_STR.COUNT) := V_STR;
        EXIT;
      END IF;
    
      V_STR := SUBSTR(V_SY_STR, 1, INSTR(V_SY_STR, AS_SPLIT_STR) - 1);
      LS_STR.EXTEND;
      LS_STR(LS_STR.COUNT) := V_STR;
    
      V_SY_STR := SUBSTR(V_SY_STR, INSTR(V_SY_STR, AS_SPLIT_STR) + 1);
    
      IF V_SY_STR IS NULL THEN
        EXIT;
      END IF;
    END LOOP;
  
    RETURN LS_STR;
  END;

  ----------------------------------------------------------------------
  -- AUTHOR  : XUQF
  -- CREATED : 2014-09-10
  -- PURPOSE : 生成供应商信息
  ----------------------------------------------------------------------
  PROCEDURE P_LG_GENERATION_VENDOR_INFO(O_RESULT     OUT VARCHAR2, --返回错误码
                                        O_RESULT_MSG OUT VARCHAR2 --返回错误信息
                                        ) IS
  
    V_SOURCE_VENDOR_ID  INTF_LG_VENDOR_INFO_HEAD.SOURCE_VENDOR_ID%TYPE; --源供应商ID
    V_ENTITY_ID         T_INV_ORGANIZATION.ENTITY_ID%TYPE; --主体ID
    V_LG_VENDOR_HEAD    T_LG_VENDOR_INFO_HEAD%ROWTYPE; --供应商头表
    V_LG_VENDOR_LINE    T_LG_VENDOR_INFO_LINE%ROWTYPE; --供应商行表
    V_LG_VENDOR_CONTACT T_LG_VENDOR_CONTACT_INFO%ROWTYPE; --供应商联系人信息表
    V_LG_VENDOR_BANK    T_LG_VENDOR_BANK_INFO%ROWTYPE; --供应商银行信息表
    --V_VENDOR_ID_SEQ    NUMBER; --供应商ID序列
  
  BEGIN
    O_RESULT     := '1';
    O_RESULT_MSG := '生成成功';
  
    --初始化源供应商ID
    V_SOURCE_VENDOR_ID := -1;
    V_ENTITY_ID        := -1;
  
    --遍历供应商接口表 根据源供应商ID排序 （增加处理状态标识！！！！）
    FOR C_INTF_LG_VENDOR_HEAD IN (SELECT A.*, B.ENTITY_ID
                                    FROM INTF_LG_VENDOR_INFO_HEAD A,
                                         T_INV_ORGANIZATION       B
                                   WHERE A.OPER_FLAG = '00'
                                     AND A.OPERATING_UNIT = B.OPERATING_UNIT
                                   ORDER BY A.SOURCE_VENDOR_ID, B.ENTITY_ID) LOOP
    
      --比较源供应商ID跟上一条数据是否一致 不一致则重新生成供应商头
      IF (NOT (V_SOURCE_VENDOR_ID = C_INTF_LG_VENDOR_HEAD.SOURCE_VENDOR_ID AND
          V_ENTITY_ID = C_INTF_LG_VENDOR_HEAD.ENTITY_ID)) THEN
      
        --构建供应商头表
        V_LG_VENDOR_HEAD.VENDOR_ID          := S_LG_VENDOR_HEAD.NEXTVAL; --承运商ID
        V_LG_VENDOR_HEAD.ENTITY_ID          := C_INTF_LG_VENDOR_HEAD.ENTITY_ID; --主体ID
        V_LG_VENDOR_HEAD.VENDOR_TYPE_CODE   := C_INTF_LG_VENDOR_HEAD.VENDOR_TYPE_CODE; --供应商类型编码
        V_LG_VENDOR_HEAD.VENDOR_TYPE        := C_INTF_LG_VENDOR_HEAD.VENDOR_TYPE; --供应商类型
        V_LG_VENDOR_HEAD.VENDOR_CODE        := C_INTF_LG_VENDOR_HEAD.VENDOR_CODE; --供应商编码
        V_LG_VENDOR_HEAD.VENDOR_NAME        := C_INTF_LG_VENDOR_HEAD.VENDOR_NAME; --供应商名称
        V_LG_VENDOR_HEAD.VENDOR_SIMPLE_NAME := C_INTF_LG_VENDOR_HEAD.VENDOR_SIMPLE_NAME; --供应商简称
        V_LG_VENDOR_HEAD.SOURCE_VENDOR_ID   := C_INTF_LG_VENDOR_HEAD.SOURCE_VENDOR_ID; --源供应商ID
        V_LG_VENDOR_HEAD.TAX_REGISTER_NUM   := C_INTF_LG_VENDOR_HEAD.TAX_REGISTER_NUM; --税务登记号
        V_LG_VENDOR_HEAD.REGISTER_ADDRESS   := C_INTF_LG_VENDOR_HEAD.REGISTER_ADDRESS; --企业注册地址
        V_LG_VENDOR_HEAD.PROVINCE           := C_INTF_LG_VENDOR_HEAD.PROVINCE; --省份
        V_LG_VENDOR_HEAD.CITY               := C_INTF_LG_VENDOR_HEAD.CITY; --城市
        V_LG_VENDOR_HEAD.BLACKLIST_FLAG     := C_INTF_LG_VENDOR_HEAD.BLACKLIST_FLAG; --是否黑名单
        V_LG_VENDOR_HEAD.CREATED_BY         := 'LG'; --创建人
        V_LG_VENDOR_HEAD.CREATION_DATE      := SYSDATE; --创建日期
        V_LG_VENDOR_HEAD.LAST_UPDATED_BY    := 'LG'; --修改人
        V_LG_VENDOR_HEAD.LAST_UPDATE_DATE   := SYSDATE; --修改日期
      
        --判断内部供应商、外部供应商
        IF V_LG_VENDOR_HEAD.VENDOR_TYPE_CODE = '100' THEN
          V_LG_VENDOR_HEAD.VENDOR_MAIN_TYPE := '00';
        ELSE
          V_LG_VENDOR_HEAD.VENDOR_MAIN_TYPE := '01';
        END IF;
      
        --插入供应商头表
        INSERT INTO T_LG_VENDOR_INFO_HEAD VALUES V_LG_VENDOR_HEAD;
      
      END IF;
    
      --构建供应商行表
      V_LG_VENDOR_LINE.VENDOR_LINE_ID       := S_LG_VENDOR_LINE.NEXTVAL; --供应商行ID
      V_LG_VENDOR_LINE.VENDOR_ID            := V_LG_VENDOR_HEAD.VENDOR_ID; --供应商ID
      V_LG_VENDOR_LINE.OPERATING_UNIT       := C_INTF_LG_VENDOR_HEAD.OPERATING_UNIT; --经营组织ID
      V_LG_VENDOR_LINE.OPERATING_UNIT_CODE  := C_INTF_LG_VENDOR_HEAD.OPERATING_UNIT_CODE; --经营组织编码
      V_LG_VENDOR_LINE.INVOICE_ADDRESS      := C_INTF_LG_VENDOR_HEAD.INVOICE_ADDRESS; --开票地址
      V_LG_VENDOR_LINE.VENDOR_TEL           := C_INTF_LG_VENDOR_HEAD.VENDOR_TEL; --电话
      V_LG_VENDOR_LINE.PAYMENT_WAY          := C_INTF_LG_VENDOR_HEAD.PAYMENT_WAY; --付款方式
      V_LG_VENDOR_LINE.PAYMENT_CONDITION    := C_INTF_LG_VENDOR_HEAD.PAYMENT_CONDITION; --付款条件
      V_LG_VENDOR_LINE.BANK_ACCOUNT         := C_INTF_LG_VENDOR_HEAD.BANK_ACCOUNT; --银行账号
      V_LG_VENDOR_LINE.STATUS               := C_INTF_LG_VENDOR_HEAD.STATUS; --供应商状态
      V_LG_VENDOR_LINE.ADMIT_DATE           := C_INTF_LG_VENDOR_HEAD.ADMIT_DATE; --准入日期
      V_LG_VENDOR_LINE.DEPOSIT_BANK         := C_INTF_LG_VENDOR_HEAD.DEPOSIT_BANK; --开户行名称
      V_LG_VENDOR_LINE.NO_AVAIL_DATE        := C_INTF_LG_VENDOR_HEAD.NO_AVAIL_DATE; --无效日期
      V_LG_VENDOR_LINE.BANK_ACCOUNT_NAME    := C_INTF_LG_VENDOR_HEAD.BANK_ACCOUNT_NAME; --银行账号名称
      V_LG_VENDOR_LINE.VENDOR_SITE_ID       := C_INTF_LG_VENDOR_HEAD.VENDOR_SITE_ID; --供应商地点ID
      V_LG_VENDOR_LINE.VENDOR_SITE_CODE     := C_INTF_LG_VENDOR_HEAD.VENDOR_SITE_CODE; --供应商地点名称
      V_LG_VENDOR_LINE.VENDOR_SITE_CODE_ALT := C_INTF_LG_VENDOR_HEAD.VENDOR_SITE_CODE_ALT; --供应商地点简称
      V_LG_VENDOR_LINE.CREATED_BY           := 'LG'; --创建人
      V_LG_VENDOR_LINE.CREATION_DATE        := SYSDATE; --创建日期
      V_LG_VENDOR_LINE.LAST_UPDATED_BY      := 'LG'; --最后更新人
      V_LG_VENDOR_LINE.LAST_UPDATE_DATE     := SYSDATE; --最后更新时间
    
      --插入供应商行表
      INSERT INTO T_LG_VENDOR_INFO_LINE VALUES V_LG_VENDOR_LINE;
    
      --更新承运商接口表状态
      UPDATE INTF_LG_VENDOR_INFO_HEAD
         SET OPER_FLAG = '01'
       WHERE VENDOR_INFO_HEAD_ID =
             C_INTF_LG_VENDOR_HEAD.VENDOR_INFO_HEAD_ID;
    
      --重新给源供应商ID附值
      V_SOURCE_VENDOR_ID := V_LG_VENDOR_HEAD.SOURCE_VENDOR_ID;
      V_ENTITY_ID        := V_LG_VENDOR_HEAD.ENTITY_ID;
    
    END LOOP;
  
    --遍历供应商联系人接口表
    FOR C_INTF_LG_VENDOR_CONTAC IN (SELECT *
                                      FROM INTF_LG_VENDOR_CONTACT_INFO) LOOP
    
      --构建供应商联系人信息表
      V_LG_VENDOR_CONTACT.VENDOR_CONTACT_ID    := S_LG_VENDOR_CONTACT.NEXTVAL; --供应商联系人信息ID
      V_LG_VENDOR_CONTACT.VENDOR_SITE_ID       := C_INTF_LG_VENDOR_CONTAC.VENDOR_SITE_ID; --供应商地点ID
      V_LG_VENDOR_CONTACT.VENDOR_SITE_CODE     := C_INTF_LG_VENDOR_CONTAC.VENDOR_SITE_CODE; --供应商地点名称
      V_LG_VENDOR_CONTACT.VENDOR_SITE_CODE_ALT := C_INTF_LG_VENDOR_CONTAC.VENDOR_SITE_CODE_ALT; --供应商地点简称
      V_LG_VENDOR_CONTACT.CONTACT              := C_INTF_LG_VENDOR_CONTAC.CONTACT; --联系人
      V_LG_VENDOR_CONTACT.UPDATE_DATE          := C_INTF_LG_VENDOR_CONTAC.UPDATE_DATE; --更新日期
      V_LG_VENDOR_CONTACT.CREATED_BY           := 'LG'; --创建人
      V_LG_VENDOR_CONTACT.CREATION_DATE        := SYSDATE; --创建日期
      V_LG_VENDOR_CONTACT.LAST_UPDATED_BY      := 'LG'; --最后更新人
      V_LG_VENDOR_CONTACT.LAST_UPDATE_DATE     := SYSDATE; --最后更新时间
    
      --插入供应商联系人表
      INSERT INTO T_LG_VENDOR_CONTACT_INFO VALUES V_LG_VENDOR_CONTACT;
    
      --更新承运商联系人接口表状态
      UPDATE INTF_LG_VENDOR_CONTACT_INFO
         SET OPER_FLAG = '01'
       WHERE VENDOR_CONTACT_ID = C_INTF_LG_VENDOR_CONTAC.VENDOR_CONTACT_ID;
    
    END LOOP;
  
    --遍历供应商银行接口表
    FOR C_INTF_LG_VENDOR_BANK IN (SELECT * FROM INTF_LG_VENDOR_BANK_INFO) LOOP
    
      --构建供应商银行信息表
      V_LG_VENDOR_BANK.VENDOR_BANK_ID       := S_LG_VENDOR_BANK.NEXTVAL; --供应商银行信息ID
      V_LG_VENDOR_BANK.VENDOR_SITE_ID       := C_INTF_LG_VENDOR_BANK.VENDOR_SITE_ID; --供应商地点ID
      V_LG_VENDOR_BANK.VENDOR_SITE_CODE     := C_INTF_LG_VENDOR_BANK.VENDOR_SITE_CODE; --供应商地点名称
      V_LG_VENDOR_BANK.VENDOR_SITE_CODE_ALT := C_INTF_LG_VENDOR_BANK.VENDOR_SITE_CODE_ALT; --供应商地点简称
      V_LG_VENDOR_BANK.BANK_ACCOUNT         := C_INTF_LG_VENDOR_BANK.BANK_ACCOUNT; --银行帐号
      V_LG_VENDOR_BANK.BANK_ACCOUNT_NAME    := C_INTF_LG_VENDOR_BANK.BANK_ACCOUNT_NAME; --银行帐号名称
      V_LG_VENDOR_BANK.DEPOSIT_BANK         := C_INTF_LG_VENDOR_BANK.DEPOSIT_BANK; --开户银行
      V_LG_VENDOR_BANK.UBANK_NO             := C_INTF_LG_VENDOR_BANK.UBANK_NO; --银行联行号
      V_LG_VENDOR_BANK.BEGIN_DATE           := C_INTF_LG_VENDOR_BANK.BEGIN_DATE; --账户有效期自
      V_LG_VENDOR_BANK.END_DATE             := C_INTF_LG_VENDOR_BANK.END_DATE; --账户有效期至
      V_LG_VENDOR_BANK.INVALID_DATE         := C_INTF_LG_VENDOR_BANK.INVALID_DATE; --无效日期
      V_LG_VENDOR_BANK.UPDATE_DATE          := C_INTF_LG_VENDOR_BANK.UPDATE_DATE; --更新日期
      V_LG_VENDOR_BANK.CREATED_BY           := 'LG'; --创建人
      V_LG_VENDOR_BANK.CREATION_DATE        := SYSDATE; --创建日期
      V_LG_VENDOR_BANK.LAST_UPDATED_BY      := 'LG'; --最后更新人
      V_LG_VENDOR_BANK.LAST_UPDATE_DATE     := SYSDATE; --最后更新时间
    
      --插入供应商银行表
      INSERT INTO T_LG_VENDOR_BANK_INFO VALUES V_LG_VENDOR_BANK;
    
      --更新承运商银行接口表状态
      UPDATE INTF_LG_VENDOR_BANK_INFO
         SET OPER_FLAG = '01'
       WHERE VENDOR_BANK_ID = C_INTF_LG_VENDOR_BANK.VENDOR_BANK_ID;
    
    END LOOP;
  
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      O_RESULT     := '0';
      O_RESULT_MSG := '生成失败';
      RETURN;
    WHEN OTHERS THEN
      O_RESULT     := '0';
      O_RESULT_MSG := SUBSTR(SQLERRM(SQLCODE), 1, 256);
      RETURN;
  END;

  ----------------------------------------------------------------------
  -- AUTHOR  : XUQF
  -- CREATED : 2014-10-17
  -- PURPOSE : 引入供应商信息
  ----------------------------------------------------------------------
  PROCEDURE P_LG_IMPORT_VENDOR_INFO(I_VENDOR_INTF_IDS IN VARCHAR2, --供应商ID集合
                                    I_OPER_NAME       IN VARCHAR2, --登录账号
                                    O_RESULT          OUT VARCHAR2, --返回错误码
                                    O_RESULT_MSG      OUT VARCHAR2 --返回错误信息
                                    ) IS
  
    V_VENDOR_INTF_IDS TYPE_SPLIT; --发货计划ID数组
    --V_SOURCE_VENDOR_ID  INTF_LG_VENDOR_INFO_HEAD.SOURCE_VENDOR_ID%TYPE; --源供应商ID
    --V_ENTITY_ID         T_INV_ORGANIZATION.ENTITY_ID%TYPE; --主体ID
    V_LG_VENDOR_HEAD    T_LG_VENDOR_INFO_HEAD%ROWTYPE; --供应商头表
    V_LG_VENDOR_LINE    T_LG_VENDOR_INFO_LINE%ROWTYPE; --供应商行表
    V_LG_VENDOR_CONTACT T_LG_VENDOR_CONTACT_INFO%ROWTYPE; --供应商联系人信息表
    V_LG_VENDOR_BANK    T_LG_VENDOR_BANK_INFO%ROWTYPE; --供应商银行信息表
    V_VENDOR_INTF_COUNT NUMBER; --承运商接口表数量
    V_VENDOR_COUNT      NUMBER; --承运商数量
    --V_VENDOR_ID_SEQ    NUMBER; --供应商ID序列
  
  BEGIN
    O_RESULT     := '1';
    O_RESULT_MSG := '引入成功';
  
    --将字符串拆分成数组
    V_VENDOR_INTF_IDS := PKG_LG_COMMON.F_SPLIT_STR(AS_STR       => I_VENDOR_INTF_IDS,
                                                   AS_SPLIT_STR => ',');
    
    /* 因同一个OU_ID可能归属多个不同主体，注释掉 2017-07-27
    --判断接口表中未引入供应商的数量
    SELECT COUNT(*)
      INTO V_VENDOR_INTF_COUNT
      FROM INTF_LG_VENDOR_INFO_HEAD
     WHERE VENDOR_INFO_HEAD_ID IN
           (SELECT COLUMN_VALUE FROM TABLE(V_VENDOR_INTF_IDS))
       AND OPER_FLAG = '00';
    IF V_VENDOR_INTF_COUNT = 0 THEN
      O_RESULT     := '1001';
      O_RESULT_MSG := '引入失败！选择的供应商已引入到业务系统，不能重复引入！';
      RETURN;
    END IF;
    */
  
    --初始化源供应商ID
    --V_SOURCE_VENDOR_ID := -1;
    --V_ENTITY_ID        := -1;
  
    --遍历供应商接口表 根据源供应商ID排序 （增加处理状态标识！！！！）
    FOR C_INTF_LG_VENDOR_HEAD IN (
         SELECT DISTINCT B.ENTITY_ID, A.*
           FROM INTF_LG_VENDOR_INFO_HEAD A, T_INV_ORGANIZATION B
          WHERE A.VENDOR_INFO_HEAD_ID IN
                (SELECT COLUMN_VALUE FROM TABLE(V_VENDOR_INTF_IDS))
            --AND A.OPER_FLAG = '00'
            AND A.OPERATING_UNIT = B.OPERATING_UNIT
            AND NOT EXISTS
          (SELECT 1
                   FROM T_LG_VENDOR_INFO_HEAD T1, T_LG_VENDOR_INFO_LINE T2
                  WHERE T1.VENDOR_ID = T2.VENDOR_ID
                    AND T1.SOURCE_VENDOR_ID = A.SOURCE_VENDOR_ID
                    AND T1.ENTITY_ID = B.ENTITY_ID
                    AND T2.OPERATING_UNIT = A.OPERATING_UNIT)
          --ORDER BY A.SOURCE_VENDOR_ID, B.ENTITY_ID
    ) LOOP 
    
      --判断供应商ID是否存在
      SELECT COUNT(*)
        INTO V_VENDOR_COUNT
        FROM T_LG_VENDOR_INFO_HEAD T
       WHERE T.SOURCE_VENDOR_ID = C_INTF_LG_VENDOR_HEAD.SOURCE_VENDOR_ID
         AND T.ENTITY_ID = C_INTF_LG_VENDOR_HEAD.ENTITY_ID;
    
      --供应商信息不存在，生成供应商头信息
      IF V_VENDOR_COUNT = 0 THEN
      
        --构建供应商头表
        V_LG_VENDOR_HEAD.VENDOR_ID          := S_LG_VENDOR_HEAD.NEXTVAL; --承运商ID
        V_LG_VENDOR_HEAD.ENTITY_ID          := C_INTF_LG_VENDOR_HEAD.ENTITY_ID; --主体ID
        V_LG_VENDOR_HEAD.VENDOR_TYPE_CODE   := C_INTF_LG_VENDOR_HEAD.VENDOR_TYPE_CODE; --供应商类型编码
        V_LG_VENDOR_HEAD.VENDOR_TYPE        := C_INTF_LG_VENDOR_HEAD.VENDOR_TYPE; --供应商类型
        V_LG_VENDOR_HEAD.VENDOR_CODE        := C_INTF_LG_VENDOR_HEAD.VENDOR_CODE; --供应商编码
        V_LG_VENDOR_HEAD.VENDOR_NAME        := C_INTF_LG_VENDOR_HEAD.VENDOR_NAME; --供应商名称
        V_LG_VENDOR_HEAD.VENDOR_SIMPLE_NAME := C_INTF_LG_VENDOR_HEAD.VENDOR_SIMPLE_NAME; --供应商简称
        V_LG_VENDOR_HEAD.SOURCE_VENDOR_ID   := C_INTF_LG_VENDOR_HEAD.SOURCE_VENDOR_ID; --源供应商ID
        V_LG_VENDOR_HEAD.TAX_REGISTER_NUM   := C_INTF_LG_VENDOR_HEAD.TAX_REGISTER_NUM; --税务登记号
        V_LG_VENDOR_HEAD.REGISTER_ADDRESS   := C_INTF_LG_VENDOR_HEAD.REGISTER_ADDRESS; --企业注册地址
        V_LG_VENDOR_HEAD.PROVINCE           := C_INTF_LG_VENDOR_HEAD.PROVINCE; --省份
        V_LG_VENDOR_HEAD.CITY               := C_INTF_LG_VENDOR_HEAD.CITY; --城市
        V_LG_VENDOR_HEAD.BLACKLIST_FLAG     := C_INTF_LG_VENDOR_HEAD.BLACKLIST_FLAG; --是否黑名单
        V_LG_VENDOR_HEAD.CREATED_BY         := I_OPER_NAME; --创建人
        V_LG_VENDOR_HEAD.CREATION_DATE      := SYSDATE; --创建日期
        V_LG_VENDOR_HEAD.LAST_UPDATED_BY    := I_OPER_NAME; --修改人
        V_LG_VENDOR_HEAD.LAST_UPDATE_DATE   := SYSDATE; --修改日期
      
        --判断内部供应商、外部供应商
        IF V_LG_VENDOR_HEAD.VENDOR_TYPE_CODE = '100' THEN
          V_LG_VENDOR_HEAD.VENDOR_MAIN_TYPE := '00';
        ELSE
          V_LG_VENDOR_HEAD.VENDOR_MAIN_TYPE := '01';
        END IF;
      
        --插入供应商头表
        INSERT INTO T_LG_VENDOR_INFO_HEAD VALUES V_LG_VENDOR_HEAD;
      
      ELSE
      
        --获取已存在的供应商ID
        SELECT VENDOR_ID
          INTO V_LG_VENDOR_HEAD.VENDOR_ID
          FROM T_LG_VENDOR_INFO_HEAD T
         WHERE T.SOURCE_VENDOR_ID = C_INTF_LG_VENDOR_HEAD.SOURCE_VENDOR_ID
           AND T.ENTITY_ID = C_INTF_LG_VENDOR_HEAD.ENTITY_ID;
      
      END IF;
    
      --构建供应商行表
      V_LG_VENDOR_LINE.VENDOR_LINE_ID       := S_LG_VENDOR_LINE.NEXTVAL; --供应商行ID
      V_LG_VENDOR_LINE.VENDOR_ID            := V_LG_VENDOR_HEAD.VENDOR_ID; --供应商ID
      V_LG_VENDOR_LINE.OPERATING_UNIT       := C_INTF_LG_VENDOR_HEAD.OPERATING_UNIT; --经营组织ID
      V_LG_VENDOR_LINE.OPERATING_UNIT_CODE  := C_INTF_LG_VENDOR_HEAD.OPERATING_UNIT_CODE; --经营组织编码
      V_LG_VENDOR_LINE.OPER_TYPE            := C_INTF_LG_VENDOR_HEAD.OPER_TYPE; --业务类型
      V_LG_VENDOR_LINE.INVOICE_ADDRESS      := C_INTF_LG_VENDOR_HEAD.INVOICE_ADDRESS; --开票地址
      V_LG_VENDOR_LINE.VENDOR_TEL           := C_INTF_LG_VENDOR_HEAD.VENDOR_TEL; --电话
      V_LG_VENDOR_LINE.PAYMENT_WAY          := C_INTF_LG_VENDOR_HEAD.PAYMENT_WAY; --付款方式
      V_LG_VENDOR_LINE.PAYMENT_CONDITION    := C_INTF_LG_VENDOR_HEAD.PAYMENT_CONDITION; --付款条件
      V_LG_VENDOR_LINE.BANK_ACCOUNT         := C_INTF_LG_VENDOR_HEAD.BANK_ACCOUNT; --银行账号
      V_LG_VENDOR_LINE.STATUS               := C_INTF_LG_VENDOR_HEAD.STATUS; --供应商状态
      V_LG_VENDOR_LINE.ADMIT_DATE           := C_INTF_LG_VENDOR_HEAD.ADMIT_DATE; --准入日期
      V_LG_VENDOR_LINE.DEPOSIT_BANK         := C_INTF_LG_VENDOR_HEAD.DEPOSIT_BANK; --开户行名称
      V_LG_VENDOR_LINE.NO_AVAIL_DATE        := C_INTF_LG_VENDOR_HEAD.NO_AVAIL_DATE; --无效日期
      V_LG_VENDOR_LINE.BANK_ACCOUNT_NAME    := C_INTF_LG_VENDOR_HEAD.BANK_ACCOUNT_NAME; --银行账号名称
      V_LG_VENDOR_LINE.VENDOR_SITE_ID       := C_INTF_LG_VENDOR_HEAD.VENDOR_SITE_ID; --供应商地点ID
      V_LG_VENDOR_LINE.VENDOR_SITE_CODE     := C_INTF_LG_VENDOR_HEAD.VENDOR_SITE_CODE; --供应商地点名称
      V_LG_VENDOR_LINE.VENDOR_SITE_CODE_ALT := C_INTF_LG_VENDOR_HEAD.VENDOR_SITE_CODE_ALT; --供应商地点简称
      V_LG_VENDOR_LINE.CREATED_BY           := I_OPER_NAME; --创建人
      V_LG_VENDOR_LINE.CREATION_DATE        := SYSDATE; --创建日期
      V_LG_VENDOR_LINE.LAST_UPDATED_BY      := I_OPER_NAME; --最后更新人
      V_LG_VENDOR_LINE.LAST_UPDATE_DATE     := SYSDATE; --最后更新时间
    
      --插入供应商行表
      INSERT INTO T_LG_VENDOR_INFO_LINE VALUES V_LG_VENDOR_LINE;
    
      --更新承运商接口表状态
      UPDATE INTF_LG_VENDOR_INFO_HEAD
         SET OPER_FLAG = '01'
       WHERE VENDOR_INFO_HEAD_ID =
             C_INTF_LG_VENDOR_HEAD.VENDOR_INFO_HEAD_ID;
    
      --遍历供应商联系人接口表
      FOR C_INTF_LG_VENDOR_CONTAC IN (SELECT *
                                        FROM INTF_LG_VENDOR_CONTACT_INFO
                                       WHERE VENDOR_SITE_ID =
                                             C_INTF_LG_VENDOR_HEAD.VENDOR_SITE_ID
                                         AND OPER_FLAG = '00') LOOP
      
        --构建供应商联系人信息表
        V_LG_VENDOR_CONTACT.VENDOR_CONTACT_ID    := S_LG_VENDOR_CONTACT.NEXTVAL; --供应商联系人信息ID
        V_LG_VENDOR_CONTACT.VENDOR_SITE_ID       := C_INTF_LG_VENDOR_CONTAC.VENDOR_SITE_ID; --供应商地点ID
        V_LG_VENDOR_CONTACT.VENDOR_SITE_CODE     := C_INTF_LG_VENDOR_CONTAC.VENDOR_SITE_CODE; --供应商地点名称
        V_LG_VENDOR_CONTACT.VENDOR_SITE_CODE_ALT := C_INTF_LG_VENDOR_CONTAC.VENDOR_SITE_CODE_ALT; --供应商地点简称
        V_LG_VENDOR_CONTACT.CONTACT              := C_INTF_LG_VENDOR_CONTAC.CONTACT; --联系人
        V_LG_VENDOR_CONTACT.UPDATE_DATE          := C_INTF_LG_VENDOR_CONTAC.UPDATE_DATE; --更新日期
        V_LG_VENDOR_CONTACT.CREATED_BY           := I_OPER_NAME; --创建人
        V_LG_VENDOR_CONTACT.CREATION_DATE        := SYSDATE; --创建日期
        V_LG_VENDOR_CONTACT.LAST_UPDATED_BY      := I_OPER_NAME; --最后更新人
        V_LG_VENDOR_CONTACT.LAST_UPDATE_DATE     := SYSDATE; --最后更新时间
      
        --插入供应商联系人表
        INSERT INTO T_LG_VENDOR_CONTACT_INFO VALUES V_LG_VENDOR_CONTACT;
      
        --更新承运商联系人接口表状态
        UPDATE INTF_LG_VENDOR_CONTACT_INFO
           SET OPER_FLAG = '01'
         WHERE VENDOR_CONTACT_ID =
               C_INTF_LG_VENDOR_CONTAC.VENDOR_CONTACT_ID;
      
      END LOOP;
    
      --遍历供应商银行接口表
      FOR C_INTF_LG_VENDOR_BANK IN (SELECT *
                                      FROM INTF_LG_VENDOR_BANK_INFO
                                     WHERE VENDOR_SITE_ID =
                                           C_INTF_LG_VENDOR_HEAD.VENDOR_SITE_ID
                                       AND OPER_FLAG = '00') LOOP
      
        --构建供应商银行信息表
        V_LG_VENDOR_BANK.VENDOR_BANK_ID       := S_LG_VENDOR_BANK.NEXTVAL; --供应商银行信息ID
        V_LG_VENDOR_BANK.VENDOR_SITE_ID       := C_INTF_LG_VENDOR_BANK.VENDOR_SITE_ID; --供应商地点ID
        V_LG_VENDOR_BANK.VENDOR_SITE_CODE     := C_INTF_LG_VENDOR_BANK.VENDOR_SITE_CODE; --供应商地点名称
        V_LG_VENDOR_BANK.VENDOR_SITE_CODE_ALT := C_INTF_LG_VENDOR_BANK.VENDOR_SITE_CODE_ALT; --供应商地点简称
        V_LG_VENDOR_BANK.BANK_ACCOUNT         := C_INTF_LG_VENDOR_BANK.BANK_ACCOUNT; --银行帐号
        V_LG_VENDOR_BANK.BANK_ACCOUNT_NAME    := C_INTF_LG_VENDOR_BANK.BANK_ACCOUNT_NAME; --银行帐号名称
        V_LG_VENDOR_BANK.DEPOSIT_BANK         := C_INTF_LG_VENDOR_BANK.DEPOSIT_BANK; --开户银行
        V_LG_VENDOR_BANK.UBANK_NO             := C_INTF_LG_VENDOR_BANK.UBANK_NO; --银行联行号
        V_LG_VENDOR_BANK.BEGIN_DATE           := C_INTF_LG_VENDOR_BANK.BEGIN_DATE; --账户有效期自
        V_LG_VENDOR_BANK.END_DATE             := C_INTF_LG_VENDOR_BANK.END_DATE; --账户有效期至
        V_LG_VENDOR_BANK.INVALID_DATE         := C_INTF_LG_VENDOR_BANK.INVALID_DATE; --无效日期
        V_LG_VENDOR_BANK.UPDATE_DATE          := C_INTF_LG_VENDOR_BANK.UPDATE_DATE; --更新日期
        V_LG_VENDOR_BANK.CREATED_BY           := I_OPER_NAME; --创建人
        V_LG_VENDOR_BANK.CREATION_DATE        := SYSDATE; --创建日期
        V_LG_VENDOR_BANK.LAST_UPDATED_BY      := I_OPER_NAME; --最后更新人
        V_LG_VENDOR_BANK.LAST_UPDATE_DATE     := SYSDATE; --最后更新时间
      
        --插入供应商银行表
        INSERT INTO T_LG_VENDOR_BANK_INFO VALUES V_LG_VENDOR_BANK;
      
        --更新承运商银行接口表状态
        UPDATE INTF_LG_VENDOR_BANK_INFO
           SET OPER_FLAG = '01'
         WHERE VENDOR_BANK_ID = C_INTF_LG_VENDOR_BANK.VENDOR_BANK_ID;
      
      END LOOP;
    
    END LOOP;
  
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      O_RESULT     := '0';
      O_RESULT_MSG := '引入失败';
      ROLLBACK;
      RETURN;
    WHEN OTHERS THEN
      O_RESULT     := '0';
      O_RESULT_MSG := SUBSTR(SQLERRM(SQLCODE), 1, 256);
      ROLLBACK;
      RETURN;
  END;
  --------------------------------------------------------------------------------
  /*
  *   创建日期：2014-11-12
  *     创建者：张丹凤
  *   功能说明：获取二级代码的值或者名称
      参数说明：1-获取 code_value 2-获取 code_name
  *   返回结果： code_name
  *
  */
  -------------------------------------------------------------------------------
  FUNCTION FUN_GET_V_CODELIST(P_CODE_ID VARCHAR2, P_CODE_TYPE VARCHAR2)
    RETURN VARCHAR2 IS
    V_RESULT VARCHAR2(200) := '0';
  BEGIN
    BEGIN
      SELECT T.CODE_NAME
        INTO V_RESULT
        FROM V_UP_CODELIST T
       WHERE T.CODE_VALUE = P_CODE_ID
         AND T.CODETYPE = P_CODE_TYPE
         AND ROWNUM = 1;
    EXCEPTION
      WHEN OTHERS THEN
        V_RESULT := '-1';
    END;
  
    RETURN V_RESULT;
  END;

  ----------------------------------------------------------------------
  -- AUTHOR  : XUQF
  -- CREATED : 2015-01-07
  -- PURPOSE : 获取收货单位
  ----------------------------------------------------------------------
  FUNCTION P_CONSIGNEE_ADDRESS(I_CONTRACT_ID VARCHAR2) RETURN VARCHAR2 IS
  
    V_LG_CONTRACT         T_LG_CONTRACT%ROWTYPE; --运输合同
    V_CONSIGNEE_COMPANY   T_LG_CONTRACT.CONSIGNEE_COMPANY_NAME%TYPE; --收货公司名称
    V_SALES_ORDER_TYPE_ID T_LG_CONTRACT_LINE.SALES_ORDER_TYPE_ID%TYPE; --销售单类型ID
    V_SOURCE_TYPE_CODE    T_INV_SOURCE_TYPES.SOURCE_TYPE_CODE%TYPE; --销售单类型
  
  BEGIN
  
    BEGIN
      --查询运输合同
      SELECT *
        INTO V_LG_CONTRACT
        FROM T_LG_CONTRACT T
       WHERE T.CONTRACT_ID = I_CONTRACT_ID;
    
    EXCEPTION
      WHEN OTHERS THEN
        V_CONSIGNEE_COMPANY := '';
    END;
  
    BEGIN
      --查询销售单类型
      SELECT SALES_ORDER_TYPE_ID
        INTO V_SALES_ORDER_TYPE_ID
        FROM T_LG_CONTRACT_LINE T
       WHERE T.CONTRACT_ID = I_CONTRACT_ID
         AND ROWNUM = 1;
    
      --获取销售单据类型
      SELECT A.SOURCE_TYPE_CODE
        INTO V_SOURCE_TYPE_CODE
        FROM T_INV_SOURCE_TYPES A
       WHERE A.SOURCE_TYPE_ID =
             (SELECT B.SOURCE_TYPE_ID
                FROM T_INV_BILL_TYPES B
               WHERE B.BILL_TYPE_ID = V_SALES_ORDER_TYPE_ID);
    
      IF (V_SOURCE_TYPE_CODE = '1008') THEN
        --调拨单取仓库作为收货单位
        V_CONSIGNEE_COMPANY := V_LG_CONTRACT.CONSIGNEE_INVENTORY_CODE ||
                               V_LG_CONTRACT.CONSIGNEE_INVENTORY_NAME;
      ELSE
        V_CONSIGNEE_COMPANY := V_LG_CONTRACT.CONSIGNEE_COMPANY_CODE ||
                               V_LG_CONTRACT.CONSIGNEE_COMPANY_NAME;
      END IF;
    
    EXCEPTION
      WHEN OTHERS THEN
        V_CONSIGNEE_COMPANY := V_LG_CONTRACT.CONSIGNEE_COMPANY_CODE ||
                               V_LG_CONTRACT.CONSIGNEE_COMPANY_NAME;
    END;
  
    RETURN V_CONSIGNEE_COMPANY;
  END;

  ----------------------------------------------------------------------
  -- AUTHOR  : XUQF
  -- CREATED : 2015-01-12
  -- PURPOSE : 获取单据类型
  ----------------------------------------------------------------------
  FUNCTION P_GET_ORDER_TYPE(I_CONTRACT_ID VARCHAR2) RETURN VARCHAR2 IS
  
    V_SALES_ORDER_TYPE_ID T_LG_CONTRACT_LINE.SALES_ORDER_TYPE_ID%TYPE; --销售单类型ID
    V_SOURCE_TYPE_CODE    T_INV_SOURCE_TYPES.SOURCE_TYPE_CODE%TYPE; --销售单类型
    V_ORDER_TYPE          VARCHAR2(30); --单据类型 销售/调拨
  
  BEGIN
  
    BEGIN
      --查询销售单类型
      SELECT SALES_ORDER_TYPE_ID
        INTO V_SALES_ORDER_TYPE_ID
        FROM T_LG_CONTRACT_LINE T
       WHERE T.CONTRACT_ID = I_CONTRACT_ID
         AND ROWNUM = 1;
    
      --获取销售单据类型
      SELECT A.SOURCE_TYPE_CODE
        INTO V_SOURCE_TYPE_CODE
        FROM T_INV_SOURCE_TYPES A
       WHERE A.SOURCE_TYPE_ID =
             (SELECT B.SOURCE_TYPE_ID
                FROM T_INV_BILL_TYPES B
               WHERE B.BILL_TYPE_ID = V_SALES_ORDER_TYPE_ID);
    
      IF (V_SOURCE_TYPE_CODE = '1008') THEN
        --调拨单
        V_ORDER_TYPE := '调';
      ELSE
        --销售单
        V_ORDER_TYPE := '销';
      END IF;
    
    EXCEPTION
      WHEN OTHERS THEN
        V_ORDER_TYPE := '';
    END;
  
    RETURN V_ORDER_TYPE;
  END;
  
  
  ----------------------------------------------------------------------
  -- AUTHOR  : guibr
  -- CREATED : 2019-03-18
  -- PURPOSE : 获取集拼主体
  ----------------------------------------------------------------------
  FUNCTION P_GET_ENTITY_GROUP(IN_ENTITY_ID NUMBER) RETURN NUMBER IS
    V_ENTITY_GROUP_ID     NUMBER; --获取集拼主体
  BEGIN
  
    BEGIN
      SELECT ENTITY_ID
        INTO V_ENTITY_GROUP_ID
        FROM T_LG_ENTITY_GROUP
       WHERE GROUP_CODE IN
             (SELECT GROUP_CODE FROM T_LG_ENTITY_GROUP WHERE ENTITY_ID = IN_ENTITY_ID)
            AND IS_COLLAGE='Y';
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
           V_ENTITY_GROUP_ID := IN_ENTITY_ID;
    END;
  
    RETURN V_ENTITY_GROUP_ID;
    
  END;

END PKG_LG_COMMON;
/

