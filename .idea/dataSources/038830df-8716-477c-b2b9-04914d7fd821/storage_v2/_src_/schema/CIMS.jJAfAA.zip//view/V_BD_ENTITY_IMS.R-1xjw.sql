create view V_BD_ENTITY_IMS as
select uou.unit_id          entity_id,
       uou.name             entity_name,
       uou.description      entity_desc,
       uou.created_by,
       uou.creation_date,
       uou.last_updated_by,
       uou.last_update_date
  from up_org_unit uou, up_org_dimension_unit u
 where u.unit_id = uou.id
   and uou.type_id in
       (select ut.id from up_org_unit_type ut where ut.code = 'BU')
 start with u.parent_dimension_unit_id = '-1'
connect by prior u.dimension_unit_id = u.parent_dimension_unit_id
/

