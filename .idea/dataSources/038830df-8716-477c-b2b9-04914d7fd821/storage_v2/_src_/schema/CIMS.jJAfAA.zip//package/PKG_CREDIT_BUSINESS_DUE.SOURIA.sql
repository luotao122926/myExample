create package      PKG_CREDIT_BUSINESS_DUE is

  -- Author  : SUDONGYUAN
  -- Created : 2014/7/30 21:42:59
  -- Purpose :
  V_NL         CONSTANT VARCHAR2(2) := CHR(13) || CHR(10); --换行
  V_SEC_RESULT CONSTANT NUMBER := 0; --成功返回
  V_SUCCESS    CONSTANT VARCHAR2(10) := 'SUCCESS';
  V_BASE_EXCEPTION EXCEPTION; --自定义异常

  PROCEDURE 新客户初始化信用信息;
  PROCEDURE PRC_CREDIT_CUSTOMER_INIT(P_ENTITY_ID   IN NUMBER, --主体ID
                                     P_CUSTOMER_ID IN NUMBER, --客户ID
                                     P_USERNAME    IN VARCHAR2, --登录用户名
                                     P_RESULT      OUT NUMBER,
                                     P_ERR_MSG     OUT VARCHAR2);
  PROCEDURE PRC_CREDIT_CUST_CATEGORY_INIT(P_ENTITY_ID       IN NUMBER, --主体ID
                                          P_CUSTOMER_ID     IN NUMBER, --客户ID
                                          P_SALES_MAIN_TYPE IN VARCHAR2, --营销大类编码
                                          P_PROJ_NUMBER     IN VARCHAR2, --项目号
                                          P_USERNAME        IN VARCHAR2, --登录用户名
                                          P_RESULT          OUT NUMBER,
                                          P_ERR_MSG         OUT VARCHAR2);
  /*PROCEDURE PRC_CREDIT_CUST_CATEGORY_DEL(P_ENTITY_ID       IN NUMBER, --主体ID
                                         P_CUSTOMER_ID     IN NUMBER, --客户ID
                                         P_SALES_MAIN_TYPE IN VARCHAR2, --营销大类编码
                                         --P_PROJ_NUMBER     IN VARCHAR2, --项目号
                                         P_USERNAME IN VARCHAR2, --登录用户名
                                         P_RESULT   OUT NUMBER,
                                         P_ERR_MSG  OUT VARCHAR2);*/
  PROCEDURE 额度组维护模块;
  FUNCTION FUN_GET_SALESTYPE_CHECK(P_ENTITY_ID Number ,
                                   P_CREDIT_GROUP_ID NUMBER,
                                   P_DEFAULT_FLAG    VARCHAR2)
    RETURN VARCHAR2;
  FUNCTION FUN_GET_SALESTYPE_CHECK_INFO(P_ENTITY_ID Number ,
                                        P_CREDIT_GROUP_ID NUMBER,
                                        P_SALESTYPE_STR   varchar2)
    RETURN VARCHAR2;
  FUNCTION FUN_GET_CUSTOMER_CHECK(P_CREDIT_GROUP_ID NUMBER,
                                  P_CUSTOMER_STR    varchar2) RETURN VARCHAR2;
  FUNCTION FUN_GET_CUSTOMER_DEL_CHECK(P_CREDIT_GROUP_ID NUMBER,
                                      P_CUSTOMER_STR    varchar2) RETURN NUMBER;
  PROCEDURE PRC_CREDIT_SALES_TYPE_SAVE(P_ENTITY_ID       IN NUMBER, --主体ID
                                      P_CREDIT_GROUP_ID IN NUMBER, --客户额度组ID
                                      P_salesTypeStr    IN VARCHAR2, --营销大类字符串
                                       P_USERNAME        IN VARCHAR2, --登录用户名
                                       --PROCEDURE PRC_CREDIT_SALES_TYPE_SAVE(
                                       P_RESULT          OUT NUMBER,
                                       P_ERR_MSG         OUT VARCHAR2);
  PROCEDURE PRC_CREDIT_AMOUNT_SAVE(P_ENTITY_ID       IN NUMBER, --主体ID
                                   P_CREDIT_GROUP_ID IN NUMBER, --客户额度组ID
                                   P_USERNAME        IN VARCHAR2, --登录用户名
                                   P_RESULT          OUT NUMBER,
                                   P_ERR_MSG         OUT VARCHAR2);
                                   
                                   
    
    --------------------------------------------------------------------------------
  /*
  *   创建日期：2019-11-07
  *     创建者：guibr
  *   功能说明：按客户调整客户额度组维护模块
  *   返回结果：0:成功，-20000：失败
  *
  */
  -------------------------------------------------------------------------------
  PROCEDURE PRC_CREDIT_AMOUNT_RELOAD(P_ENTITY_ID         IN NUMBER, --主体ID
                                    P_CUSTOMER_ID        IN NUMBER, --客户ID
                                    P_ACCOUNT_ID         IN NUMBER, --账户ID
                                    P_USERNAME           IN VARCHAR2, --登录用户名
                                    P_RESULT          OUT NUMBER ,
                                    P_ERR_MSG         OUT VARCHAR2
                                  );   
                                  
                                                                 
  --------------------------------------------------------------------------------
  /*
  *   创建日期：2019-11-07
  *     创建者：guibr
  *   功能说明：找出客户错误额度组重新计算客户款项
  *   返回结果：0:成功，-20000：失败
  *
  */
  -------------------------------------------------------------------------------
  PROCEDURE PRC_CREDIT_GROUP_ERROR_REP(P_ENTITY_ID         IN NUMBER, --主体ID
                                    P_USERNAME           IN VARCHAR2, --登录用户名
                                    P_RESULT          OUT NUMBER ,
                                    P_ERR_MSG         OUT VARCHAR2
                                  );                                 

end PKG_CREDIT_BUSINESS_DUE;
/

