create PACKAGE BODY      PKG_CUST_CHECK IS
  -- AUTHOR  : WMANG
  -- CRATED : 2015/1/15 9:56:03E
  PROCEDURE PKG_CUST_ACC_CHECK(P_ENTITY_ID          IN NUMBER, --主体ID
                               P_CUSTOMER_ID        IN NUMBER, --客户ID
                               P_ACCOUNT_ID         IN NUMBER, --账户ID
                               P_SELESMAINTYPE_CODE IN VARCHAR2, --营销大类编码
                               P_MESSAGE            OUT VARCHAR2 --成功则返回“SUCCESS”，否则返回出错信息
                               ) IS
    V_CUSTOMER_NAME VARCHAR2(100); --客户名称
    V_SALESMAINTYPE_NAME VARCHAR2(50); --营销大类名称
    V_SALESMAINTYPE_COUNT NUMBER; --查询营销大类总数
    V_ACC_COUNT NUMBER; --查询账户总数
    V_BIZ_EXCEPTION EXCEPTION; --自定义业务异常
  BEGIN
    P_MESSAGE := 'SUCCESS';

    IF P_ENTITY_ID IS NULL THEN
      P_MESSAGE := '主体不能为空！';
      RAISE V_BIZ_EXCEPTION;
    END IF;

    IF P_CUSTOMER_ID IS NULL THEN
      P_MESSAGE := '客户ID不能为空！';
      RAISE V_BIZ_EXCEPTION;
    END IF;

    IF P_ACCOUNT_ID IS NULL THEN
      P_MESSAGE := '账户ID不能为空！';
      RAISE V_BIZ_EXCEPTION;
    END IF;

    IF P_SELESMAINTYPE_CODE IS NULL THEN
      P_MESSAGE := '营销大类不能为空！';
      RAISE V_BIZ_EXCEPTION;
    END IF;

    BEGIN
      SELECT H.CUSTOMER_NAME
        INTO V_CUSTOMER_NAME
        FROM CIMS.T_CUSTOMER_HEADER H
       WHERE H.CUSTOMER_ID = P_CUSTOMER_ID;
    EXCEPTION
      WHEN OTHERS THEN
        P_MESSAGE := '根据客户ID(' || P_CUSTOMER_ID || ')查询客户出错！';
        RAISE V_BIZ_EXCEPTION;
    END;
    
    BEGIN  
      SELECT C.CLASS_NAME
        INTO V_SALESMAINTYPE_NAME
        FROM CIMS.T_BD_ITEM_CLASS C
       WHERE C.CLASS_CODE = P_SELESMAINTYPE_CODE
         AND C.ENTITY_ID = P_ENTITY_ID; --关于产品分类、组织需要根据主体过滤问题的修改
    EXCEPTION
      WHEN OTHERS THEN
        P_MESSAGE := '根据营销大类编码(' || P_SELESMAINTYPE_CODE || ')查询营销大类出错！';
        RAISE V_BIZ_EXCEPTION;
    END;

    BEGIN
      SELECT COUNT(ACC.ACCOUNT_ID)
        INTO V_ACC_COUNT
        FROM CIMS.T_CUSTOMER_ACCOUNT ACC
       WHERE ACC.ENTITY_ID = P_ENTITY_ID
         AND ACC.ACTIVE_FLAG = 'Y'
         AND ACC.CUSTOMER_ID = P_CUSTOMER_ID
         AND ACC.ACCOUNT_ID = P_ACCOUNT_ID;
    EXCEPTION
      WHEN OTHERS THEN
        P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_CUST_CHECK.PKG_CUST_ACC_CHECK',
                                            SQLCODE,
                                            '获取客户和账户关系失败！：' || SQLERRM);
        RAISE V_BIZ_EXCEPTION;
    END;

    IF V_ACC_COUNT <= 0 THEN
      P_MESSAGE := '客户('||V_CUSTOMER_NAME||')下不存在此有效帐户！';
      RAISE V_BIZ_EXCEPTION;
    END IF;

    BEGIN
      SELECT COUNT(T.SALES_MAIN_TYPE_ID)
        INTO V_SALESMAINTYPE_COUNT
        FROM CIMS.T_CUSTOMER_SALES_MAIN_TYPE T
       WHERE T.ACTIVE_FLAG = 'Active'
         AND T.ENTITY_ID = P_ENTITY_ID
         AND T.CUSTOM_ID = P_CUSTOMER_ID
         AND T.SALES_MAIN_TYPE_CODE = P_SELESMAINTYPE_CODE;
    EXCEPTION
      WHEN OTHERS THEN
        P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_CUST_CHECK.PKG_CUST_ACC_CHECK',
                                            SQLCODE,
                                            '获取客户和营销大类关系失败！：' || SQLERRM);
    END;

    IF V_SALESMAINTYPE_COUNT <= 0 THEN
      P_MESSAGE := '客户('||V_CUSTOMER_NAME||')没有经营此大类('||V_SALESMAINTYPE_NAME||')！';
      RAISE V_BIZ_EXCEPTION;
    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      NULL;
  END PKG_CUST_ACC_CHECK;

  -- AUTHOR  : WMANG
  -- CRATED : 2015/3/25 9:56:03E
  PROCEDURE PKG_AR_UPDATE_ORDER(P_ENTITY_ID       IN NUMBER, --主体ID
                                P_ORDER_HEADER_ID IN NUMBER, --对账单ID
                                P_MESSAGE         OUT VARCHAR2 --成功则返回“SUCCESS”，否则返回出错信息
                                ) IS
    V_BIZ_EXCEPTION EXCEPTION; --自定义异常
    --V_ORDER_NUMBER VARCHAR(100);

    CURSOR V_SO_HEADER IS
        SELECT SO.*
          FROM T_SO_HEADER SO
         WHERE SO.ENTITY_ID = P_ENTITY_ID
           AND SO.SO_NUM IN
               (SELECT AR.ORDER_NUMBER
                  FROM T_AR_SOA_ORDER_DETAILS AR
                 WHERE AR.SOA_ORDER_HEAD_ID = P_ORDER_HEADER_ID)
           FOR UPDATE;

    CCREC V_SO_HEADER%ROWTYPE;
  BEGIN
    P_MESSAGE := 'SUCCESS';

    IF P_ENTITY_ID IS NULL THEN
      P_MESSAGE:='主体ID不能为空';
      RAISE V_BIZ_EXCEPTION;
    END IF;

    IF P_ORDER_HEADER_ID IS NULL THEN
      P_MESSAGE:='对账单ID不能为空';
      RAISE V_BIZ_EXCEPTION;
    END IF;

    BEGIN
      OPEN V_SO_HEADER;
    
      LOOP
        FETCH V_SO_HEADER
          INTO CCREC;
        EXIT WHEN V_SO_HEADER%NOTFOUND;
        
        UPDATE T_SO_HEADER SO
           SET SO.CHECKED_ACCOUNT_FLAG = 'Y'
              ,SO.CHECKED_ACCOUNT_DATE = SYSDATE
         WHERE SO.SO_HEADER_ID = CCREC.SO_HEADER_ID
           AND SO.ENTITY_ID = P_ENTITY_ID;
      END LOOP;
      CLOSE V_SO_HEADER;
    EXCEPTION
      WHEN OTHERS THEN
        P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_CUST_CHECK.PKG_AR_UPDATE_ORDER',
                                            SQLCODE,
                                            '销售单状态更新失败！：' || SQLERRM);
    END;
  EXCEPTION
    WHEN OTHERS THEN
       NULL;
       /* P_MESSAGE:=PKG_BD.F_ADD_ERROR_LOG('PKG_CUST_CHECK.PKG_AR_UPDATE_ORDER',
                                            SQLCODE,
                                            '销售单更新失败！：' || SQLERRM);*/
  END PKG_AR_UPDATE_ORDER;

END PKG_CUST_CHECK;
/

