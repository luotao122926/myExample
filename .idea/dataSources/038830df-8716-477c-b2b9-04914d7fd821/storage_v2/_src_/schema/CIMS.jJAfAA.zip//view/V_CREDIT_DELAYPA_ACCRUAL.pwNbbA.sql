create view V_CREDIT_DELAYPA_ACCRUAL as
select A.ENTITY_ID ,
         A.BILL_NUM , --单据号
         A.CUSTOMER_ID,
         A.CUSTOMER_CODE,
         A.CUSTOMER_NAME,
         A.SALES_CENTER_ID,--营销中心ID
         A.SALES_CENTER_CODE,--营销中心编码
         A.SALES_CENTER_NAME, --营销中心名称
         B.BAD_RECORD_TYPE,--不良记录类型
         '1' ACCRUAL_TYPE, --利息类型
         A.BRING_ACCRUAL_AMOUNT ACCRUAL_SUM , --计息金额
         A.BRING_ACCRUAL_DAYS  ACCRUAL_COUNT , --计息天数
         /*(CASE A.ENTITY_ID WHEN 10 THEN 0.01
                           WHEN 14 THEN (CASE WHEN NVL(A.OVERDUE_FLAG,'0') = '1' THEN 0.18/360
                                              WHEN NVL(A.DELAY_FLAG,'0') = '1' THEN 0.12/360
                                              WHEN A.DELAYPAY_TYPE = 3 THEN 0.12/360
                                              WHEN A.DELAYPAY_TYPE = 1 THEN 0.08/360
                                              END)
         END ) ACCRUAL_RATE , --利率*/
         (Select t.overdue_year_rate From t_credit_delaypay_configue t Where t.entity_id = a.entity_id And t.bill_type_id = a.bill_type_id
         And t.delaypay_type = a.delaypay_type And Rownum = 1) ACCRUAL_RATE, --逾期利率
         A.ACCRUAL_AMOUNT , --逾期利息金额
         a.approval_amount , --审批金额
         (Case a.delaypay_type When 1 Then (Ceil(a.due_time-a.last_approval_time))
                               Else 0 End ) ACCRUAL_KY_COUNT, --跨月天数
         (Select t.year_rate From t_credit_delaypay_configue t Where t.entity_id = a.entity_id And t.bill_type_id = a.bill_type_id
         And t.delaypay_type = a.delaypay_type And Rownum = 1) ACCRUAL_KY_RATE, --跨月利率
         a.accrual_ky_amount, --跨月利息
         (nvl(a.ACCRUAL_AMOUNT,0) + nvl(a.accrual_ky_amount,0)) ACCRUAL_TO_SUM , --利息总金额
         a.payed_accrual_amount, --已兑现利息金额
         '' vchar1,  --备用字段1
         '' vchar2   --备用字段2
    from T_CREDIT_DELAYPAY A , T_CREDIT_BAD_RECORD B
    WHERE A.BILL_ID = B.BILL_ID(+)
      AND (NVL(A.ACCRUAL_AMOUNT,0) > 0
       Or  Nvl(a.accrual_ky_amount,0) > 0)
/

comment on column V_CREDIT_DELAYPA_ACCRUAL.ENTITY_ID is '业务主体ID'
/

comment on column V_CREDIT_DELAYPA_ACCRUAL.BILL_NUM is '单据号'
/

comment on column V_CREDIT_DELAYPA_ACCRUAL.CUSTOMER_ID is '客户ID'
/

comment on column V_CREDIT_DELAYPA_ACCRUAL.CUSTOMER_CODE is '客户编码'
/

comment on column V_CREDIT_DELAYPA_ACCRUAL.CUSTOMER_NAME is '客户名称'
/

comment on column V_CREDIT_DELAYPA_ACCRUAL.SALES_CENTER_ID is '营销中心ID'
/

comment on column V_CREDIT_DELAYPA_ACCRUAL.SALES_CENTER_CODE is '营销中心编码'
/

comment on column V_CREDIT_DELAYPA_ACCRUAL.SALES_CENTER_NAME is '营销中心名称'
/

comment on column V_CREDIT_DELAYPA_ACCRUAL.BAD_RECORD_TYPE is '不良记录类型'
/

comment on column V_CREDIT_DELAYPA_ACCRUAL.ACCRUAL_TYPE is '利息类型'
/

comment on column V_CREDIT_DELAYPA_ACCRUAL.ACCRUAL_SUM is '计息金额'
/

comment on column V_CREDIT_DELAYPA_ACCRUAL.ACCRUAL_COUNT is '计息天数'
/

comment on column V_CREDIT_DELAYPA_ACCRUAL.ACCRUAL_RATE is '逾期年利率'
/

comment on column V_CREDIT_DELAYPA_ACCRUAL.ACCRUAL_AMOUNT is '逾期利息金额'
/

comment on column V_CREDIT_DELAYPA_ACCRUAL.APPROVAL_AMOUNT is '审批金额'
/

comment on column V_CREDIT_DELAYPA_ACCRUAL.ACCRUAL_KY_COUNT is '跨月天数'
/

comment on column V_CREDIT_DELAYPA_ACCRUAL.ACCRUAL_KY_RATE is '跨月利率'
/

comment on column V_CREDIT_DELAYPA_ACCRUAL.ACCRUAL_KY_AMOUNT is '跨月利息'
/

comment on column V_CREDIT_DELAYPA_ACCRUAL.ACCRUAL_TO_SUM is '利息总金额'
/

comment on column V_CREDIT_DELAYPA_ACCRUAL.PAYED_ACCRUAL_AMOUNT is '已兑现利息金额'
/

