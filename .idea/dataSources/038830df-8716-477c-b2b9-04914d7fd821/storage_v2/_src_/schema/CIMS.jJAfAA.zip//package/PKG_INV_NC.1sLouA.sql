create PACKAGE      PKG_INV_NC  AS

  -----------------------------------------------------------------------------
  --处理存货单据保存接口推送NC
  -----------------------------------------------------------------------------
  PROCEDURE P_INSERT_INTF_NC
  (
    BIll_TYPE              IN     INTF_NC_INV_HEADER.BIll_TYPE%TYPE,--单据类型
    SOURCE_HEADER_ID       IN NUMBER,--单据头ID
    P_RESULT               IN OUT NUMBER, --返回错误ID
    P_ERR_MSG              IN OUT VARCHAR2 --返回错误信息
  );

  -----------------------------------------------------------------------------
  --保存采购单到接口表
  -----------------------------------------------------------------------------
  PROCEDURE P_INSERT_INTF_PO_ORDER
  (
    SOURCE_HEADER_ID       IN NUMBER,--单据头ID
    P_RESULT               IN OUT NUMBER, --返回错误ID
    P_ERR_MSG              IN OUT VARCHAR2 --返回错误信息
  );

  -----------------------------------------------------------------------------
  --保存盘点单到接口表
  -----------------------------------------------------------------------------
  PROCEDURE P_INSERT_INTF_CHECK_ORDER
  (
    SOURCE_HEADER_ID       IN NUMBER,--单据头ID
    P_RESULT               IN OUT NUMBER, --返回错误ID
    P_ERR_MSG              IN OUT VARCHAR2 --返回错误信息
  );

  -----------------------------------------------------------------------------
  --保存发放单到接口表
  -----------------------------------------------------------------------------
  PROCEDURE P_INSERT_INTF_PMT_ORDER
  (
    SOURCE_HEADER_ID       IN NUMBER,--单据头ID
    P_RESULT               IN OUT NUMBER, --返回错误ID
    P_ERR_MSG              IN OUT VARCHAR2 --返回错误信息
  );

END PKG_INV_NC;
/

