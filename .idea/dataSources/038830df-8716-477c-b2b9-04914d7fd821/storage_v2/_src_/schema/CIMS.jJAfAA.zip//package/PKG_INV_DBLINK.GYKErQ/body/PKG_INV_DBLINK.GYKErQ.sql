create package body PKG_INV_DBLINK Is
  v_Base_Exception Exception; --自定义异常
  v_Success Constant varchar2(10) := 'SUCCESS';
  v_Nl Constant varchar2(2) := Chr(13) || Chr(10); --换行

 --------------------------------------------------------------------------
  --Author: sushu
  -- Created : 2016-12-13
  --Purpose:中转单关联交易校验产品是否分配有效的供应商
  --------------------------------------------------------------------------
  Procedure p_item_vendor_relation(p_Po_Num In varchar2, --中转单号
                                   p_Entity_Id In Number, --主体
                                   p_Result       Out varchar2) Is --返回的结果
    
    v_Item_Vendor_Relation varchar2(10); --是否校验物料使用批准得供应商
    v_Vendor_Code varchar2(100); --供应商
    v_Finance_Operating_Id Number; --财务仓Ou
    v_Erp_Trancation varchar2(100); --ERP事务处理类型
    v_Vendor_Id Number; --erp对应的供应商ID
    v_Vendor_Site_Id Number; --erp对应的供应商地点ID
    v_Item_Code varchar2(2000); --产品拼接串
  
    Begin
      p_Result := v_Success;
      
      --获取是否校验物料使用批准的供应商的校验关系
      Begin
        v_Item_Vendor_Relation := Pkg_Bd.F_Get_Parameter_Value('inv_item_vendor_relation',p_Entity_Id);
      Exception
        When Others Then
          p_Result := p_Result || '获取系统参数inv_item_vendor_relation的值失败' || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
      End;
      
      If(v_Item_Vendor_Relation = 'Y') Then
        --获取供应商以及财务仓ou
        Begin
          Select t.Vendor_Code, t.Finance_Operating_Id, t.Erp_Trancation
            Into v_Vendor_Code, v_Finance_Operating_Id, v_Erp_Trancation
            From t_Inv_Po_Headers t
           Where t.Po_Num = p_Po_Num
             And t.Entity_Id = p_Entity_Id;
        Exception
          When Others Then
            p_Result := p_Result || '获取供应商和财务仓ou报错' || v_Nl || '中转单号：' || p_Po_Num || v_Nl ||
                        Sqlerrm;
            Raise v_Base_Exception;
        End;
        
        If(v_Erp_Trancation = '07') Then
          Begin
            Select r_Vendor_Id, r_Vendor_Site_Id
              Into v_Vendor_Id, v_Vendor_Site_Id
              From Apps.Cux_Icp_Business_All@Mdims2mderp
             Where r_Vendor_Num = v_Vendor_Code
               And Supplier_System = 'GERP'
               And Requirement_System = 'GERP'
               And r_Org_Id = v_Finance_Operating_Id
               And Nvl(Disable_Date, Sysdate + 1) > Sysdate;
          Exception
            When Others Then
              p_Result := p_Result || '正向采购获取ERP中供应商ID以及供应商地点报错' || v_Nl || '供应商：' ||
                          v_Vendor_Code || v_Nl || '财务仓OU:' ||
                          v_Finance_Operating_Id || v_Nl || Sqlerrm;
              Raise v_Base_Exception;
          End;
        Elsif(v_Erp_Trancation = '09') Then
          Begin
            Select r_Vendor_Id, r_Vendor_Site_Id
              Into v_Vendor_Id, v_Vendor_Site_Id
              From Apps.Cux_Icp_Business_All@Mdims2mderp
             Where s_Customer_Number = v_Vendor_Code
               And Supplier_System = 'GERP'
               And Requirement_System = 'GERP'
               And s_Org_Id = v_Finance_Operating_Id
               And Nvl(Disable_Date, Sysdate + 1) > Sysdate;
          Exception
            When Others Then
              p_Result := p_Result || '返向中转获取ERP中供应商ID以及供应商地点报错' || v_Nl || '供应商：' ||
                          v_Vendor_Code || v_Nl || '财务仓OU:' ||
                          v_Finance_Operating_Id || v_Nl || Sqlerrm;
              Raise v_Base_Exception;
          End;
        End If;
        
        If(v_Erp_Trancation = '07') Then
          --获取中转单上没有对应批准供应商上的产品
          Begin
            Select Wm_Concat(b.Item_Code)
              Into v_Item_Code
              From Cims.t_Inv_Po_Headers             a,
                   Cims.t_Inv_Po_Lines               b,
                   Apps.Mtl_System_Items@Mdims2mderp Mi
             Where a.Po_Id = b.Po_Id
               And a.Po_Num = p_Po_Num
               And Mi.Must_Use_Approved_Vendor_Flag = 'Y'
               And Mi.Segment1 = b.Item_Code
               And a.Finance_Organization_Id = Mi.Organization_Id
               And Not Exists
             (Select 1
                      From Apps.Po_Approved_Supplier_List@Mdims2mderp m
                     Where m.Item_Id = Mi.Inventory_Item_Id
                       And Nvl(m.Disable_Flag, 'N') = 'N'
                       And m.Vendor_Id = v_Vendor_Id
                       And (m.Using_Organization_Id = -1 Or
                           m.Vendor_Site_Id = v_Vendor_Site_Id));
            If (v_Item_Code Is Not Null) Then
              p_Result := p_Result || '获取中转单上没有对应批准的有效供应商的产品：' || v_Item_Code || v_Nl ||
                          Sqlerrm;
              Raise v_Base_Exception;
            End If;
          Exception
            When Others Then
              p_Result := p_Result || '获取中转单上没有对应批准的有效供应商的产品失败' || v_Nl || '供应商：' ||
                          v_Vendor_Code || v_Nl || '财务仓OU:' ||
                          v_Finance_Operating_Id || v_Nl || Sqlerrm;
              Raise v_Base_Exception;
          End;
        Elsif(v_Erp_Trancation = '09') Then
          --获取中转单上没有对应批准供应商上的产品
          Begin
            Select Wm_Concat(b.Item_Code)
              Into v_Item_Code
              From Cims.t_Inv_Po_Headers             a,
                   Cims.t_Inv_Po_Lines               b,
                   Apps.Mtl_System_Items@Mdims2mderp Mi
             Where a.Po_Id = b.Po_Id
               And a.Po_Num = p_Po_Num
               And Mi.Must_Use_Approved_Vendor_Flag = 'Y'
               And Mi.Segment1 = b.Item_Code
               And a.Vendor_Organization_Id = Mi.Organization_Id
               And Not Exists
             (Select 1
                      From Apps.Po_Approved_Supplier_List@Mdims2mderp m
                     Where m.Item_Id = Mi.Inventory_Item_Id
                       And Nvl(m.Disable_Flag, 'N') = 'N'
                       And m.Vendor_Id = v_Vendor_Id
                       And (m.Using_Organization_Id = -1 Or
                           m.Vendor_Site_Id = v_Vendor_Site_Id));
            If (v_Item_Code Is Not Null) Then
              p_Result := p_Result || '获取中转单上没有对应批准的有效供应商的产品：' || v_Item_Code || v_Nl ||
                          Sqlerrm;
              Raise v_Base_Exception;
            End If;
          Exception
            When Others Then
              p_Result := p_Result || '获取中转单上没有对应批准的有效供应商的产品失败' || v_Nl || '供应商：' ||
                          v_Vendor_Code || v_Nl || '财务仓OU:' ||
                          v_Finance_Operating_Id || v_Nl || Sqlerrm;
              Raise v_Base_Exception;
          End;
        End If;
        
      End If;
      
      
    Exception
      When v_Base_Exception Then
        p_Result := '操作失败，' || p_Result;
      When Others Then
        p_Result := '操作失败' || v_Nl || Sqlerrm;
    End;                                
   
  
  
  --------------------------------------------------------------------------
  --Author: sushu
  -- Created : 2016-12-19
  --Purpose:工单入库校验产品是否分配有效的供应商
  --------------------------------------------------------------------------
  Procedure p_wip_item_vendor_relation(p_Trace_Trans_Id In Number, --中转单号
                                   p_Entity_Id In Number, --主体
                                   p_Result       Out varchar2) is --返回的结果
     
  
    v_Item_Vendor_Relation varchar2(10); --是否校验物料使用批准得供应商
    v_Item_Vendor_Code varchar2(100); --供应商
    v_Item_Finance_Operating_Id Number; --财务仓Ou
    v_Item_Vendor_Id Number; --erp对应的供应商ID
    v_Item_Vendor_Site_Id Number; --erp对应的供应商地点ID
    v_Item_Code varchar2(2000); --产品拼接串
    v_product_erp_transcation   varchar2(10); --产地对应的ERP处理类型  by sushu 2017-01-09
                              
    Begin
      p_Result := v_Success;
      
      --获取是否校验物料使用批准的供应商的校验关系
      Begin
        v_Item_Vendor_Relation := Pkg_Bd.f_Get_Parameter_Value('inv_item_vendor_relation',
                                                               p_Entity_Id);
      Exception
        When Others Then
          p_Result := '获取系统参数inv_item_vendor_relation的值失败' || v_Nl ||
                      Sqlerrm;
          Raise v_Base_Exception;
      End;
      
      --获取erp事务处理类型
      Begin
        Select t.Erp_Inv_Trans_Po
          Into v_Product_Erp_Transcation
          From t_Pln_Producing_Area t, t_Inv_Wip_To_Po_Trace T1
         Where t.Producing_Area_Id = T1.Po_Area_Id
           And T1.Trace_Trans_Id = p_Trace_Trans_Id
           And Rownum = 1;
      Exception
        When Others Then
          p_Result := '获取产地对应的ERP处理类型报错' || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
      End;
      
      If (v_Item_Vendor_Relation = 'Y' And v_Product_Erp_Transcation = '03') Then
        --获取供应商以及财务仓ou
        Begin
          Select Distinct Vv.Vendor_Code, t.Finance_Operating_Id
            Into v_Item_Vendor_Code, v_Item_Finance_Operating_Id
            From t_Inv_Wip_To_Po_Trace t, v_Inv_Vendor_View Vv
           Where t.Trace_Trans_Id = p_Trace_Trans_Id
             And t.Vendor_Id = Vv.Vendor_Id;
        Exception
          When Others Then
            p_Result := '校验产品是否匹配有效供应商失败，获取供应商和财务仓ou报错' || v_Nl || Sqlerrm;
            Raise v_Base_Exception;
        End;
      
        Begin
          Select r_Vendor_Id, r_Vendor_Site_Id
            Into v_Item_Vendor_Id, v_Item_Vendor_Site_Id
            From Apps.Cux_Icp_Business_All@Mdims2mderp
           Where r_Vendor_Num = v_Item_Vendor_Code
             And Supplier_System = 'GERP'
             And Requirement_System = 'GERP'
             And r_Org_Id = v_Item_Finance_Operating_Id
             And Nvl(Disable_Date, Sysdate + 1) > Sysdate;
        Exception
          When Others Then
            p_Result := '校验产品是否匹配有效供应商失败，正向采购获取ERP中供应商ID以及供应商地点报错' || v_Nl ||
                        '供应商：' || v_Item_Vendor_Id || v_Nl || '财务仓OU:' ||
                        v_Item_Finance_Operating_Id || v_Nl || Sqlerrm;
            Raise v_Base_Exception;
        End;
      
        --获取中转单上没有对应批准供应商上的产品
        Begin
          Select Wm_Concat(a.Item_Code)
            Into v_Item_Code
            From t_Inv_Wip_To_Po_Trace             a,
                 Apps.Mtl_System_Items@Mdims2mderp Mi
           Where a.Trace_Trans_Id = p_Trace_Trans_Id
             And Mi.Must_Use_Approved_Vendor_Flag = 'Y'
             And Mi.Segment1 = a.Item_Code
             And a.Finance_Organization_Id = Mi.Organization_Id
             And Not Exists
           (Select 1
                    From Apps.Po_Approved_Supplier_List@Mdims2mderp m
                   Where m.Item_Id = Mi.Inventory_Item_Id
                     And Nvl(m.Disable_Flag, 'N') = 'N'
                     And m.Vendor_Id = v_Item_Vendor_Id
                     And (m.Using_Organization_Id = -1 Or
                         m.Vendor_Site_Id = v_Item_Vendor_Site_Id));
          If (v_Item_Code Is Not Null) Then
            p_Result := '获取中转单上没有对应批准的有效供应商的产品：' || v_Item_Code || v_Nl ||
                        Sqlerrm;
            Raise v_Base_Exception;
          End If;
        Exception
          When Others Then
            p_Result := '校验产品是否匹配有效供应商失败，获取中转单上没有对应批准的有效供应商的产品失败' || v_Nl ||
                        '供应商：' || v_Item_Vendor_Code || v_Nl || '财务仓OU:' ||
                        v_Item_Finance_Operating_Id || v_Nl || p_Result || v_Nl ||
                        Sqlerrm;
            Raise v_Base_Exception;
        End;
      
      End If;
          
      
    Exception
      When v_Base_Exception Then
        p_Result := '操作失败，' || p_Result;
      When Others Then
        p_Result := '操作失败' || v_Nl || Sqlerrm;
    End;
  
end PKG_INV_DBLINK;
/

