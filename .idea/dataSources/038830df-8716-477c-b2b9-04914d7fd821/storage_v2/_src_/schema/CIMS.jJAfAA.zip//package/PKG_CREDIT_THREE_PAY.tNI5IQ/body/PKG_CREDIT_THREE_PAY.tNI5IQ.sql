create package body PKG_CREDIT_THREE_PAY is
  V_NL         CONSTANT VARCHAR2(2) := CHR(13) || CHR(10); --换行
  V_SEC_RESULT CONSTANT NUMBER := 0; --成功返回
  V_SUCCESS    CONSTANT VARCHAR2(10) := 'SUCCESS';

  --------------------------------------------------------------------------------
  /*
  *   创建日期：2015-07-29
  *     创建者：梁颜明
  *   功能说明：三方承兑解付、冲销更新三方铺底的实际铺底金额
  *    因为不限制三方承兑收款必须申请三方铺底，如果没有有效的三方铺底，也返回成功
  
      19：三方承兑解付
      20：三方承兑解付冲销
  */
  -------------------------------------------------------------------------------
  PROCEDURE PRC_CREDIT_TREEDELAYPAY_UPDATE(P_ENTITY_ID       IN NUMBER, --主体ID
                                           P_ACTION_TYPE     IN NUMBER, --动作标示
                                           P_SALES_MAIN_TYPE IN VARCHAR2, --营销大类
                                           P_ACCOUNT_ID      IN NUMBER, --账户ID
                                           P_CUSTOMER_ID     IN NUMBER, --客户ID
                                           P_ORDER_ID        IN NUMBER, --单据ID
                                           P_USERNAME        IN VARCHAR2,
                                           P_RESULT          IN OUT NUMBER, --返回错误ID
                                           P_ERR_MSG         IN OUT VARCHAR2 --返回错误信息                          
                                           ) is
    CURSOR C_TREE_CREDIT_DELAYPAY IS
      select d.bill_id,
             --ch.cash_date,
             d.entity_id,
             d.bill_num,
             d.bill_type_id,
             --d.bill_status,
             --d.customer_id,
             --d.customer_code,
             --d.account_id,
             --d.sales_main_type,
             --d.requis_date,
             --d.end_date,
             --d.planpay_date,
             d.requis_amount,
             d.approval_amount,
             d.approvaled_amount
        from t_credit_delaypay d
       inner join t_ar_cash_receipt_headers ch
          on (ch.cash_receipt_id = P_ORDER_ID and
             d.moneyorder_number = ch.cash_code)
       where 3 = d.delaypay_type
         and d.entity_id = P_ENTITY_ID
         and d.sales_main_type = P_SALES_MAIN_TYPE
         and d.due_by is null
         and d.bill_status = '3'
            --and d.bill_status in ('1', '2', '3', '4')
         and d.customer_id = P_CUSTOMER_ID
         and d.account_id = P_ACCOUNT_ID
      -- order by decode(d.bill_status, '3', 0, 1)
      ;
  
    V_TREE_CREDIT_DELAYPAY C_TREE_CREDIT_DELAYPAY%rowtype;
    V_COUNT                number;
    V_LINES_AMOUNT         number; --三方承兑票面金额
    V_THREEPAY_SUM         number; --已解付金额
    V_THREENOPAY_SUM       number; --已解付金额
  begin
    if P_ACTION_TYPE = 19 then
      --因为不限制三方承兑收款必须申请三方铺底，如果没有有效的三方铺底，也返回成功
      P_RESULT  := V_SEC_RESULT;
      P_ERR_MSG := V_SUCCESS;
    
      V_COUNT := 0;
      open C_TREE_CREDIT_DELAYPAY;
      loop
        fetch C_TREE_CREDIT_DELAYPAY
          into V_TREE_CREDIT_DELAYPAY;
        exit when C_TREE_CREDIT_DELAYPAY%NOTFOUND;
        if 0 = V_COUNT then
          V_COUNT := (1 + V_COUNT);
        else
          P_RESULT  := -20000;
          P_ERR_MSG := '更新实际铺底金额发生错误：相同三方承兑票据、营销大类存在多笔有效的三方铺底';
          return;
        end if;
        select l.amount, sum(p.solution_pay_amount)
          into V_LINES_AMOUNT, V_THREEPAY_SUM
          from t_ar_cash_receipt_lines l
          left join t_ar_acce_solu_pay p
            on (p.cash_receipt_lines_id = l.cash_receipt_lines_id and
               p.solution_pay_status in ('2', '3'))
         where l.cash_receipt_id = P_ORDER_ID
           and l.sales_main_type_code = P_SALES_MAIN_TYPE
         group by l.amount;
        V_THREENOPAY_SUM := (V_LINES_AMOUNT - V_THREEPAY_SUM);
        if V_THREENOPAY_SUM < V_TREE_CREDIT_DELAYPAY.APPROVAL_AMOUNT then
          --如果票据已解付金额加上铺底金额大于票面金额，则票据对应的有效三方铺底金额减少
          update t_credit_delaypay d
             set d.approval_amount  = V_THREENOPAY_SUM,
                 d.last_updated_by  = P_USERNAME,
                 d.last_update_date = sysdate
           where d.bill_id = V_TREE_CREDIT_DELAYPAY.bill_id
             and d.approval_amount = V_TREE_CREDIT_DELAYPAY.approval_amount;
          if sql%rowcount = 0 then
            P_RESULT  := -20000;
            P_ERR_MSG := '更新实际铺底金额发生错误：无法更新记录，可能记录已被修改';
          end if;
          --com.midea.ims.creditmanage.bo.impl.DelayPayManagerBOImpl.doCreditDelaypaySubmit line 455
          /*PKG_CREDIT_ACCOUNT_CONTROL.PRC_CREDIT_SALES_BILL(P_ENTITY_ID       => P_ENTITY_ID,
          P_ACTION_TYPE     => 22,
          P_Settlement_SUM  => (V_THREENOPAY_SUM -
                               V_TREE_CREDIT_DELAYPAY.APPROVAL_AMOUNT), --结算金额
          P_Discount_SUM    => null, --折让金额
          P_SALES_MAIN_TYPE => P_SALES_MAIN_TYPE, --营销大类
          P_ACCOUNT_ID      => P_ACCOUNT_ID, --账户ID
          P_CUSTOMER_ID     => P_CUSTOMER_ID, --客户ID
          P_PROJ_NUMBER     => null, --项目号
          P_CREATED_MODE    => NULL, --开单方式：1-自动，2-人工（销售开单，如果为人工开单，则校验时不解锁金额）
          P_ORDER_ID        => V_TREE_CREDIT_DELAYPAY.bill_id, --铺底单据ID
          P_ORDER_TYPE      => V_TREE_CREDIT_DELAYPAY.bill_type_id, --单据类型
          P_USERNAME        => P_USERNAME, --操作人
          P_RESULT          => P_RESULT,
          P_ERR_MSG         => P_ERR_MSG);*/
        
          PKG_CREDIT_ACCOUNT_CONTROL.PRC_CREDIT_FUND_UPDATE(P_ENTITY_ID       => P_ENTITY_ID, --主体ID
                                                            P_ACTION_TYPE     => 22, --动作标示
                                                            P_Settlement_SUM  => (V_THREENOPAY_SUM -
                                                                                 V_TREE_CREDIT_DELAYPAY.APPROVAL_AMOUNT), --结算金额
                                                            P_Discount_SUM    => null, --折扣金额
                                                            P_SALES_MAIN_TYPE => P_SALES_MAIN_TYPE, --营销大类
                                                            P_ACCOUNT_ID      => P_ACCOUNT_ID, --账户ID
                                                            P_CUSTOMER_ID     => P_CUSTOMER_ID, --客户ID
                                                            P_PROJ_NUMBER     => null, --项目号
                                                            P_ORDER_ID        => V_TREE_CREDIT_DELAYPAY.bill_id, --单据ID
                                                            P_ORDER_TYPE      => V_TREE_CREDIT_DELAYPAY.bill_type_id, --单据类型
                                                            P_CREATED_MODE    => null, --开单方式：1-自动，2-人工（销售开单，如果为人工开单，则校验时不解锁金额）
                                                            P_USERNAME        => P_USERNAME,
                                                            P_RESULT          => P_RESULT, --返回错误ID
                                                            P_ERR_MSG         => P_ERR_MSG --返回错误信息
                                                            );
        end if;
      end loop;
    elsif P_ACTION_TYPE = 20 then
      /*P_RESULT := -20000;
      P_ERR_MSG := '三方承兑解付冲销暂不支持更新三方铺底';*/
      P_RESULT  := V_SEC_RESULT;
      P_ERR_MSG := V_SUCCESS;
    end if;
  end;

end PKG_CREDIT_THREE_PAY;
/

