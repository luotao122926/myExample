create Package Body      PKG_AR_WRITE_OFF_BUSINESS Is

  -----------------------------------------------------------------------------
  --  销售跟ERP有 DBLINK 交互方式 的程序包                                                   --
  -----------------------------------------------------------------------------
  
  
  

  --------------------------------------------------------------------------
  --Author: guibr
  --Created: 2018-12-11
  --业务核销  倒推业务账龄
  --------------------------------------------------------------------------
  Procedure P_AR_WRITE_OFF_BUSINESS_MAIN(
                                 IN_ENTITY_ID IN  NUMBER,  --主体 
                                 P_MATCH_DATE IN VARCHAR2, 
                                 P_RESULT  OUT VARCHAR2,-- 失败时返回异常消息
                                 P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，失败返回“ERROR”
    ) --返回值    
    IS     
    V_CHILD_RESULT VARCHAR2(1000);
    V_CHILD_MESSAGE VARCHAR2(1000);
    V_RANGE_30 DATE;
    V_RANGE_60 DATE;
    V_RANGE_90 DATE;
    V_RANGE_120 DATE;
    V_RANGE_150 DATE;
    V_RANGE_180 DATE;
    V_RANGE_210 DATE;
    V_RANGE_240 DATE;
    V_RANGE_270 DATE;
    V_RANGE_300 DATE;
    V_RANGE_330 DATE;
    V_RANGE_360 DATE;
    V_RANGE_375 DATE;
    V_RANGE_LAST DATE;
    V_RANGE_JUST DATE;
    V_RANGE_JUST_PREV DATE;
    V_MOUNT_PREV NUMBER;
    V_JUST_FLAG VARCHAR2(2);
    V_AR_SALE_MAIN_TYPE   PKG_AR_WRITE_OFF.AR_SALE_MAIN_TYPE;
    V_AMOUNT_ADD_UP NUMBER;
    V_WRITE_OFF_AMOUNT NUMBER;
    V_LOOP_END_FLAG  VARCHAR2(2);
    
    V_CUSTOMER_CODE  T_CUSTOMER_HEADER.CUSTOMER_CODE%TYPE;  
    V_CUSTOMER_NAME  T_CUSTOMER_HEADER.CUSTOMER_NAME%TYPE;  
    
    V_SALES_CENTER_ID NUMBER;
    V_SALES_CENTER_CODE  UP_ORG_UNIT.CODE%TYPE;
    V_SALES_CENTER_NAME  UP_ORG_UNIT.NAME%TYPE;   
      
    V_ERP_OU_ID  NUMBER;
    V_ERP_OU_NAME  VARCHAR2(400);
    
    V_PARAM_MATCH_DATE DATE;
    
  BEGIN
      P_MESSAGE := PKG_AR_WRITE_OFF.V_SUCCESS;
      V_PARAM_MATCH_DATE := TO_DATE(P_MATCH_DATE,'yyyy-mm-dd');
      delete from T_SO_ACCOUNT_AGE_BUSINESS where ENTITY_ID= IN_ENTITY_ID and  MATCH_DATE = V_PARAM_MATCH_DATE;
      V_AR_SALE_MAIN_TYPE := PKG_AR_WRITE_OFF.F_AR_DEFAULT_SALE_MAIN_TYPE(IN_ENTITY_ID);
      V_RANGE_30 := V_PARAM_MATCH_DATE-30;
      V_RANGE_60 := V_PARAM_MATCH_DATE-60;
      V_RANGE_90 := V_PARAM_MATCH_DATE-90;
      V_RANGE_120 := V_PARAM_MATCH_DATE-120;
      V_RANGE_150 := V_PARAM_MATCH_DATE-150;
      V_RANGE_180 := V_PARAM_MATCH_DATE-180;
      V_RANGE_210 := V_PARAM_MATCH_DATE-210;
      V_RANGE_240 := V_PARAM_MATCH_DATE-240;
      V_RANGE_270 := V_PARAM_MATCH_DATE-270;
      V_RANGE_300 := V_PARAM_MATCH_DATE-300;
      V_RANGE_330 := V_PARAM_MATCH_DATE-330;
      V_RANGE_360 := V_PARAM_MATCH_DATE-360;
      V_RANGE_375 := V_PARAM_MATCH_DATE-375;
      V_RANGE_LAST := V_RANGE_375-1;
      FOR 
         SO_HEADER_ROW 
         IN(  
              SELECT 
                 ENTITY_ID
                ,CUSTOMER_ID
                ,ACCOUNT_ID
                ,MIN(CUSTOMER_CODE) CUSTOMER_CODE
                ,MIN(CUSTOMER_NAME) CUSTOMER_NAME
                ,MIN(ERP_OU_ID) ERP_OU_ID
                ,MIN(ERP_OU_NAME) ERP_OU_NAME
                ,MIN(SALES_CENTER_ID) SALES_CENTER_ID
                ,MIN(SALES_CENTER_CODE) SALES_CENTER_CODE
                ,MIN(SALES_CENTER_NAME) SALES_CENTER_NAME
                ,sum(SETTLE_AMOUNT) SETTLE_AMOUNT
                ,sum(case when  SETTLE_DATE>=V_RANGE_30 and SETTLE_AMOUNT>0 then SETTLE_AMOUNT else 0 end) AMOUNT30
                ,sum(case when  SETTLE_DATE>=V_RANGE_30 and SETTLE_AMOUNT<0 then SETTLE_AMOUNT else 0 end) NE_AMOUNT30
                ,sum(case when  SETTLE_DATE>=V_RANGE_60 and SETTLE_AMOUNT>0 then SETTLE_AMOUNT else 0 end) AMOUNT60
                ,sum(case when  SETTLE_DATE>=V_RANGE_60 and SETTLE_AMOUNT<0 then SETTLE_AMOUNT else 0 end) NE_AMOUNT60
                ,sum(case when  SETTLE_DATE>=V_RANGE_90 and SETTLE_AMOUNT>0 then SETTLE_AMOUNT else 0 end) AMOUNT90
                ,sum(case when  SETTLE_DATE>=V_RANGE_90 and SETTLE_AMOUNT<0 then SETTLE_AMOUNT else 0 end) NE_AMOUNT90
                ,sum(case when  SETTLE_DATE>=V_RANGE_120 and SETTLE_AMOUNT>0 then SETTLE_AMOUNT else 0 end) AMOUNT120
                ,sum(case when  SETTLE_DATE>=V_RANGE_120 and SETTLE_AMOUNT<0 then SETTLE_AMOUNT else 0 end) NE_AMOUNT120
                ,sum(case when  SETTLE_DATE>=V_RANGE_150 and SETTLE_AMOUNT>0 then SETTLE_AMOUNT else 0 end) AMOUNT150
                ,sum(case when  SETTLE_DATE>=V_RANGE_150 and SETTLE_AMOUNT<0 then SETTLE_AMOUNT else 0 end) NE_AMOUNT150
                ,sum(case when  SETTLE_DATE>=V_RANGE_180 and SETTLE_AMOUNT>0 then SETTLE_AMOUNT else 0 end) AMOUNT180
                ,sum(case when  SETTLE_DATE>=V_RANGE_180 and SETTLE_AMOUNT<0 then SETTLE_AMOUNT else 0 end) NE_AMOUNT180
                ,sum(case when  SETTLE_DATE>=V_RANGE_210 and SETTLE_AMOUNT>0 then SETTLE_AMOUNT else 0 end) AMOUNT210
                ,sum(case when  SETTLE_DATE>=V_RANGE_210 and SETTLE_AMOUNT<0 then SETTLE_AMOUNT else 0 end) NE_AMOUNT210
                ,sum(case when  SETTLE_DATE>=V_RANGE_240 and SETTLE_AMOUNT>0 then SETTLE_AMOUNT else 0 end) AMOUNT240
                ,sum(case when  SETTLE_DATE>=V_RANGE_240 and SETTLE_AMOUNT<0 then SETTLE_AMOUNT else 0 end) NE_AMOUNT240
                ,sum(case when  SETTLE_DATE>=V_RANGE_270 and SETTLE_AMOUNT>0 then SETTLE_AMOUNT else 0 end) AMOUNT270
                ,sum(case when  SETTLE_DATE>=V_RANGE_270 and SETTLE_AMOUNT<0 then SETTLE_AMOUNT else 0 end) NE_AMOUNT270
                ,sum(case when  SETTLE_DATE>=V_RANGE_300 and SETTLE_AMOUNT>0 then SETTLE_AMOUNT else 0 end) AMOUNT300
                ,sum(case when  SETTLE_DATE>=V_RANGE_300 and SETTLE_AMOUNT<0 then SETTLE_AMOUNT else 0 end) NE_AMOUNT300
                ,sum(case when  SETTLE_DATE>=V_RANGE_330 and SETTLE_AMOUNT>0 then SETTLE_AMOUNT else 0 end) AMOUNT330
                ,sum(case when  SETTLE_DATE>=V_RANGE_330 and SETTLE_AMOUNT<0 then SETTLE_AMOUNT else 0 end) NE_AMOUNT330
                ,sum(case when  SETTLE_DATE>=V_RANGE_360 and SETTLE_AMOUNT>0 then SETTLE_AMOUNT else 0 end) AMOUNT360
                ,sum(case when  SETTLE_DATE>=V_RANGE_360 and SETTLE_AMOUNT<0 then SETTLE_AMOUNT else 0 end) NE_AMOUNT360
                ,sum(case when  SETTLE_DATE>=V_RANGE_375 and SETTLE_AMOUNT>0 then SETTLE_AMOUNT else 0 end) AMOUNT375
                ,sum(case when  SETTLE_DATE>=V_RANGE_375 and SETTLE_AMOUNT<0 then SETTLE_AMOUNT else 0 end) NE_AMOUNT375
              from (
                   V_AR_SO_WRITE_OFF_DETAIL
               ) where  ENTITY_ID = IN_ENTITY_ID
                   and  SETTLE_DATE < V_PARAM_MATCH_DATE+1
               group by ENTITY_ID
                       ,CUSTOMER_ID
                       ,ACCOUNT_ID
        )LOOP
           BEGIN    
               IF SO_HEADER_ROW.SETTLE_AMOUNT >0 THEN
                  IF SO_HEADER_ROW.SETTLE_AMOUNT < SO_HEADER_ROW.AMOUNT30 THEN
                       V_RANGE_JUST := V_RANGE_30;
                       V_RANGE_JUST_PREV := null ;
                       V_MOUNT_PREV :=0;
                       V_JUST_FLAG := '0';
                  ELSIF  SO_HEADER_ROW.SETTLE_AMOUNT = SO_HEADER_ROW.AMOUNT30  THEN
                       V_RANGE_JUST := V_RANGE_30;
                       V_RANGE_JUST_PREV := null; 
                       V_MOUNT_PREV :=0;
                       V_JUST_FLAG := '1';
                 ELSIF SO_HEADER_ROW.SETTLE_AMOUNT < SO_HEADER_ROW.AMOUNT60 THEN
                       V_RANGE_JUST := V_RANGE_60;
                       V_RANGE_JUST_PREV := V_RANGE_30 ;
                       V_MOUNT_PREV :=SO_HEADER_ROW.AMOUNT30;
                       V_JUST_FLAG := '0';
                 ELSIF  SO_HEADER_ROW.SETTLE_AMOUNT = SO_HEADER_ROW.AMOUNT60  THEN
                       V_RANGE_JUST := V_RANGE_60;
                       V_RANGE_JUST_PREV := V_RANGE_30 ;
                       V_MOUNT_PREV :=SO_HEADER_ROW.AMOUNT30;
                       V_JUST_FLAG := '1';       
                 ELSIF SO_HEADER_ROW.SETTLE_AMOUNT < SO_HEADER_ROW.AMOUNT90 THEN
                       V_RANGE_JUST := V_RANGE_90;
                       V_RANGE_JUST_PREV := V_RANGE_60 ;
                        V_MOUNT_PREV :=SO_HEADER_ROW.AMOUNT60;
                       V_JUST_FLAG := '0';
                 ELSIF  SO_HEADER_ROW.SETTLE_AMOUNT = SO_HEADER_ROW.AMOUNT90  THEN
                       V_RANGE_JUST := V_RANGE_90;
                        V_RANGE_JUST_PREV := V_RANGE_60 ;
                        V_MOUNT_PREV :=SO_HEADER_ROW.AMOUNT60;
                       V_JUST_FLAG := '1';    
                 ELSIF SO_HEADER_ROW.SETTLE_AMOUNT < SO_HEADER_ROW.AMOUNT120 THEN
                       V_RANGE_JUST := V_RANGE_120;
                       V_RANGE_JUST_PREV := V_RANGE_90 ;
                       V_MOUNT_PREV :=SO_HEADER_ROW.AMOUNT90;
                       V_JUST_FLAG := '0';
                 ELSIF  SO_HEADER_ROW.SETTLE_AMOUNT = SO_HEADER_ROW.AMOUNT120  THEN
                       V_RANGE_JUST := V_RANGE_120;
                       V_RANGE_JUST_PREV := V_RANGE_90 ;
                       V_MOUNT_PREV :=SO_HEADER_ROW.AMOUNT90;
                       V_JUST_FLAG := '1';  
                 ELSIF SO_HEADER_ROW.SETTLE_AMOUNT < SO_HEADER_ROW.AMOUNT150 THEN
                       V_RANGE_JUST := V_RANGE_150;
                       V_RANGE_JUST_PREV := V_RANGE_120 ;
                       V_MOUNT_PREV :=SO_HEADER_ROW.AMOUNT120;
                       V_JUST_FLAG := '0';
                 ELSIF  SO_HEADER_ROW.SETTLE_AMOUNT = SO_HEADER_ROW.AMOUNT150  THEN
                       V_RANGE_JUST := V_RANGE_150;
                       V_RANGE_JUST_PREV := V_RANGE_120 ;
                       V_MOUNT_PREV :=SO_HEADER_ROW.AMOUNT120;
                       V_JUST_FLAG := '1';   
                 ELSIF SO_HEADER_ROW.SETTLE_AMOUNT < SO_HEADER_ROW.AMOUNT180 THEN
                       V_RANGE_JUST := V_RANGE_180;
                       V_RANGE_JUST_PREV := V_RANGE_150;
                       V_MOUNT_PREV :=SO_HEADER_ROW.AMOUNT150; 
                       V_JUST_FLAG := '0';
                 ELSIF  SO_HEADER_ROW.SETTLE_AMOUNT = SO_HEADER_ROW.AMOUNT180  THEN
                       V_RANGE_JUST := V_RANGE_180;
                       V_RANGE_JUST_PREV := V_RANGE_150;
                       V_MOUNT_PREV :=SO_HEADER_ROW.AMOUNT150;  
                       V_JUST_FLAG := '1';      
                 ELSIF SO_HEADER_ROW.SETTLE_AMOUNT < SO_HEADER_ROW.AMOUNT210 THEN
                       V_RANGE_JUST := V_RANGE_210;
                       V_RANGE_JUST_PREV := V_RANGE_180 ;
                       V_MOUNT_PREV :=SO_HEADER_ROW.AMOUNT180; 
                       V_JUST_FLAG := '0';
                 ELSIF  SO_HEADER_ROW.SETTLE_AMOUNT = SO_HEADER_ROW.AMOUNT210  THEN
                       V_RANGE_JUST := V_RANGE_210;
                       V_RANGE_JUST_PREV := V_RANGE_180 ;
                       V_MOUNT_PREV :=SO_HEADER_ROW.AMOUNT180; 
                       V_JUST_FLAG := '1';    
                 ELSIF SO_HEADER_ROW.SETTLE_AMOUNT < SO_HEADER_ROW.AMOUNT240 THEN
                       V_RANGE_JUST := V_RANGE_240;
                       V_RANGE_JUST_PREV := V_RANGE_210 ;
                       V_MOUNT_PREV :=SO_HEADER_ROW.AMOUNT210; 
                       V_JUST_FLAG := '0';
                 ELSIF  SO_HEADER_ROW.SETTLE_AMOUNT = SO_HEADER_ROW.AMOUNT240  THEN
                       V_RANGE_JUST := V_RANGE_240;
                       V_RANGE_JUST_PREV := V_RANGE_210 ;
                       V_MOUNT_PREV :=SO_HEADER_ROW.AMOUNT210; 
                       V_JUST_FLAG := '1';               
                 ELSIF SO_HEADER_ROW.SETTLE_AMOUNT < SO_HEADER_ROW.AMOUNT270 THEN
                       V_RANGE_JUST := V_RANGE_270;
                       V_RANGE_JUST_PREV := V_RANGE_240;
                       V_MOUNT_PREV :=SO_HEADER_ROW.AMOUNT240; 
                       V_JUST_FLAG := '0';
                 ELSIF  SO_HEADER_ROW.SETTLE_AMOUNT = SO_HEADER_ROW.AMOUNT270  THEN
                       V_RANGE_JUST := V_RANGE_270;
                       V_RANGE_JUST_PREV := V_RANGE_240;
                       V_MOUNT_PREV :=SO_HEADER_ROW.AMOUNT240; 
                       V_JUST_FLAG := '1';     
                 ELSIF SO_HEADER_ROW.SETTLE_AMOUNT < SO_HEADER_ROW.AMOUNT300 THEN
                       V_RANGE_JUST := V_RANGE_300;
                       V_RANGE_JUST_PREV := V_RANGE_270;
                       V_MOUNT_PREV :=SO_HEADER_ROW.AMOUNT270; 
                       V_JUST_FLAG := '0';
                 ELSIF  SO_HEADER_ROW.SETTLE_AMOUNT = SO_HEADER_ROW.AMOUNT300  THEN
                       V_RANGE_JUST := V_RANGE_300;
                       V_RANGE_JUST_PREV := V_RANGE_270;
                       V_MOUNT_PREV :=SO_HEADER_ROW.AMOUNT270; 
                       V_JUST_FLAG := '1';      
                 ELSIF  SO_HEADER_ROW.SETTLE_AMOUNT < SO_HEADER_ROW.AMOUNT330  THEN
                       V_RANGE_JUST := V_RANGE_330;
                       V_RANGE_JUST_PREV := V_RANGE_300;
                       V_MOUNT_PREV :=SO_HEADER_ROW.AMOUNT300; 
                       V_JUST_FLAG := '0';                                         
                 ELSIF SO_HEADER_ROW.SETTLE_AMOUNT = SO_HEADER_ROW.AMOUNT330 THEN
                       V_RANGE_JUST := V_RANGE_330;
                       V_RANGE_JUST_PREV := V_RANGE_300;
                       V_MOUNT_PREV :=SO_HEADER_ROW.AMOUNT300; 
                       V_JUST_FLAG := '1';
                 ELSIF  SO_HEADER_ROW.SETTLE_AMOUNT < SO_HEADER_ROW.AMOUNT360  THEN
                       V_RANGE_JUST := V_RANGE_360;
                       V_RANGE_JUST_PREV := V_RANGE_330;
                       V_MOUNT_PREV :=SO_HEADER_ROW.AMOUNT330; 
                       V_JUST_FLAG := '0';          
                 ELSIF  SO_HEADER_ROW.SETTLE_AMOUNT = SO_HEADER_ROW.AMOUNT360  THEN
                       V_RANGE_JUST := V_RANGE_360;
                       V_RANGE_JUST_PREV := V_RANGE_330;
                       V_MOUNT_PREV :=SO_HEADER_ROW.AMOUNT330; 
                       V_JUST_FLAG := '1';        
                 ELSIF SO_HEADER_ROW.SETTLE_AMOUNT < SO_HEADER_ROW.AMOUNT375 THEN
                       V_RANGE_JUST := V_RANGE_375;
                       V_RANGE_JUST_PREV := V_RANGE_360;
                       V_MOUNT_PREV :=SO_HEADER_ROW.AMOUNT360; 
                       V_JUST_FLAG := '0';
                 ELSIF  SO_HEADER_ROW.SETTLE_AMOUNT = SO_HEADER_ROW.AMOUNT375  THEN
                       V_RANGE_JUST := V_RANGE_375;
                       V_RANGE_JUST_PREV := V_RANGE_360;
                       V_MOUNT_PREV :=SO_HEADER_ROW.AMOUNT360;
                       V_JUST_FLAG := '1';              
                 ELSE
                     V_RANGE_JUST := null;
                     V_RANGE_JUST_PREV := V_RANGE_375;
                     V_MOUNT_PREV :=SO_HEADER_ROW.AMOUNT375;
                     V_JUST_FLAG := '2';
                 END IF;
               ELSIF SO_HEADER_ROW.SETTLE_AMOUNT < 0 THEN   
                  IF SO_HEADER_ROW.SETTLE_AMOUNT > SO_HEADER_ROW.NE_AMOUNT30 THEN
                       V_RANGE_JUST := V_RANGE_30;
                       V_RANGE_JUST_PREV := null ;
                       V_MOUNT_PREV :=0;
                       V_JUST_FLAG := '0';
                  ELSIF  SO_HEADER_ROW.SETTLE_AMOUNT = SO_HEADER_ROW.NE_AMOUNT30  THEN
                       V_RANGE_JUST := V_RANGE_30;
                       V_RANGE_JUST_PREV := null ;
                       V_MOUNT_PREV :=0;
                       V_JUST_FLAG := '1';
                 ELSIF SO_HEADER_ROW.SETTLE_AMOUNT > SO_HEADER_ROW.NE_AMOUNT60 THEN
                       V_RANGE_JUST := V_RANGE_60;
                       V_RANGE_JUST_PREV := V_RANGE_30 ;
                       V_MOUNT_PREV := SO_HEADER_ROW.NE_AMOUNT30;
                       V_JUST_FLAG := '0';
                 ELSIF  SO_HEADER_ROW.SETTLE_AMOUNT = SO_HEADER_ROW.NE_AMOUNT60  THEN
                       V_RANGE_JUST := V_RANGE_60;
                       V_RANGE_JUST_PREV := V_RANGE_30 ;
                       V_MOUNT_PREV := SO_HEADER_ROW.NE_AMOUNT30;
                       V_JUST_FLAG := '1';       
                 ELSIF SO_HEADER_ROW.SETTLE_AMOUNT > SO_HEADER_ROW.NE_AMOUNT90 THEN
                       V_RANGE_JUST := V_RANGE_90;
                       V_RANGE_JUST_PREV := V_RANGE_60 ;
                       V_MOUNT_PREV := SO_HEADER_ROW.NE_AMOUNT60;
                       V_JUST_FLAG := '0';
                 ELSIF  SO_HEADER_ROW.SETTLE_AMOUNT = SO_HEADER_ROW.NE_AMOUNT90  THEN
                       V_RANGE_JUST := V_RANGE_90;
                       V_RANGE_JUST_PREV := V_RANGE_60 ;
                       V_MOUNT_PREV := SO_HEADER_ROW.NE_AMOUNT60;
                       V_JUST_FLAG := '1';    
                 ELSIF SO_HEADER_ROW.SETTLE_AMOUNT > SO_HEADER_ROW.NE_AMOUNT120 THEN
                       V_RANGE_JUST := V_RANGE_120;
                       V_RANGE_JUST_PREV := V_RANGE_90 ;
                       V_MOUNT_PREV := SO_HEADER_ROW.NE_AMOUNT90;
                       V_JUST_FLAG := '0';
                 ELSIF  SO_HEADER_ROW.SETTLE_AMOUNT = SO_HEADER_ROW.NE_AMOUNT120  THEN
                       V_RANGE_JUST := V_RANGE_120;
                       V_RANGE_JUST_PREV := V_RANGE_90 ;
                       V_MOUNT_PREV := SO_HEADER_ROW.NE_AMOUNT90;
                       V_JUST_FLAG := '1';  
                 ELSIF SO_HEADER_ROW.SETTLE_AMOUNT > SO_HEADER_ROW.NE_AMOUNT150 THEN
                       V_RANGE_JUST := V_RANGE_150;
                       V_RANGE_JUST_PREV := V_RANGE_120 ;
                       V_MOUNT_PREV := SO_HEADER_ROW.NE_AMOUNT120;
                       V_JUST_FLAG := '0';
                 ELSIF  SO_HEADER_ROW.SETTLE_AMOUNT = SO_HEADER_ROW.NE_AMOUNT150  THEN
                       V_RANGE_JUST := V_RANGE_150;
                       V_RANGE_JUST_PREV := V_RANGE_120 ;
                       V_MOUNT_PREV := SO_HEADER_ROW.NE_AMOUNT120;
                       V_JUST_FLAG := '1';   
                 ELSIF SO_HEADER_ROW.SETTLE_AMOUNT > SO_HEADER_ROW.NE_AMOUNT180 THEN
                       V_RANGE_JUST := V_RANGE_180;
                       V_RANGE_JUST_PREV := V_RANGE_150 ;
                       V_MOUNT_PREV := SO_HEADER_ROW.NE_AMOUNT150;
                       V_JUST_FLAG := '0';
                 ELSIF  SO_HEADER_ROW.SETTLE_AMOUNT = SO_HEADER_ROW.NE_AMOUNT180  THEN
                       V_RANGE_JUST := V_RANGE_180;
                       V_RANGE_JUST_PREV := V_RANGE_150 ;
                       V_MOUNT_PREV := SO_HEADER_ROW.NE_AMOUNT150;
                       V_JUST_FLAG := '1';      
                 ELSIF SO_HEADER_ROW.SETTLE_AMOUNT > SO_HEADER_ROW.NE_AMOUNT210 THEN
                       V_RANGE_JUST := V_RANGE_210;
                       V_RANGE_JUST_PREV := V_RANGE_180 ;
                       V_MOUNT_PREV := SO_HEADER_ROW.NE_AMOUNT180;
                       V_JUST_FLAG := '0';
                 ELSIF  SO_HEADER_ROW.SETTLE_AMOUNT = SO_HEADER_ROW.NE_AMOUNT210  THEN
                       V_RANGE_JUST := V_RANGE_210;
                       V_RANGE_JUST_PREV := V_RANGE_180 ;
                       V_MOUNT_PREV := SO_HEADER_ROW.NE_AMOUNT180;
                       V_JUST_FLAG := '1';    
                 ELSIF SO_HEADER_ROW.SETTLE_AMOUNT > SO_HEADER_ROW.NE_AMOUNT240 THEN
                       V_RANGE_JUST := V_RANGE_240;
                       V_RANGE_JUST_PREV := V_RANGE_210 ;
                       V_MOUNT_PREV := SO_HEADER_ROW.NE_AMOUNT210;
                       V_JUST_FLAG := '0';
                 ELSIF  SO_HEADER_ROW.SETTLE_AMOUNT = SO_HEADER_ROW.NE_AMOUNT240  THEN
                       V_RANGE_JUST := V_RANGE_240;
                       V_RANGE_JUST_PREV := V_RANGE_210 ;
                       V_MOUNT_PREV := SO_HEADER_ROW.NE_AMOUNT210;
                       V_JUST_FLAG := '1';               
                 ELSIF SO_HEADER_ROW.SETTLE_AMOUNT > SO_HEADER_ROW.NE_AMOUNT270 THEN
                       V_RANGE_JUST := V_RANGE_270;
                       V_RANGE_JUST_PREV := V_RANGE_240 ;
                       V_MOUNT_PREV := SO_HEADER_ROW.NE_AMOUNT240;
                       V_JUST_FLAG := '0';
                 ELSIF  SO_HEADER_ROW.SETTLE_AMOUNT = SO_HEADER_ROW.NE_AMOUNT270  THEN
                       V_RANGE_JUST := V_RANGE_270;
                       V_RANGE_JUST_PREV := V_RANGE_240 ;
                       V_MOUNT_PREV := SO_HEADER_ROW.NE_AMOUNT240;
                       V_JUST_FLAG := '1';     
                 ELSIF SO_HEADER_ROW.SETTLE_AMOUNT > SO_HEADER_ROW.NE_AMOUNT300 THEN
                       V_RANGE_JUST := V_RANGE_300;
                       V_RANGE_JUST_PREV := V_RANGE_270 ;
                       V_MOUNT_PREV := SO_HEADER_ROW.NE_AMOUNT270;
                       V_JUST_FLAG := '0';
                 ELSIF  SO_HEADER_ROW.SETTLE_AMOUNT = SO_HEADER_ROW.NE_AMOUNT300  THEN
                       V_RANGE_JUST := V_RANGE_300;
                       V_RANGE_JUST_PREV := V_RANGE_270 ;
                       V_MOUNT_PREV := SO_HEADER_ROW.NE_AMOUNT270;
                       V_JUST_FLAG := '1';          
                ELSIF SO_HEADER_ROW.SETTLE_AMOUNT > SO_HEADER_ROW.NE_AMOUNT330 THEN
                       V_RANGE_JUST := V_RANGE_330;
                       V_RANGE_JUST_PREV := V_RANGE_300 ;
                       V_MOUNT_PREV := SO_HEADER_ROW.NE_AMOUNT300;
                       V_JUST_FLAG := '0';
                 ELSIF  SO_HEADER_ROW.SETTLE_AMOUNT = SO_HEADER_ROW.NE_AMOUNT330  THEN
                       V_RANGE_JUST := V_RANGE_330;
                       V_RANGE_JUST_PREV := V_RANGE_300 ;
                       V_MOUNT_PREV := SO_HEADER_ROW.NE_AMOUNT300;
                       V_JUST_FLAG := '1';                   
                 ELSIF SO_HEADER_ROW.SETTLE_AMOUNT > SO_HEADER_ROW.NE_AMOUNT360 THEN
                       V_RANGE_JUST := V_RANGE_360;
                       V_RANGE_JUST_PREV := V_RANGE_330 ;
                       V_MOUNT_PREV := SO_HEADER_ROW.NE_AMOUNT330;
                       V_JUST_FLAG := '0';
                 ELSIF  SO_HEADER_ROW.SETTLE_AMOUNT = SO_HEADER_ROW.NE_AMOUNT360  THEN
                       V_RANGE_JUST := V_RANGE_360;
                       V_RANGE_JUST_PREV := V_RANGE_330 ;
                       V_MOUNT_PREV := SO_HEADER_ROW.NE_AMOUNT330;
                       V_JUST_FLAG := '1';               
                 ELSIF SO_HEADER_ROW.SETTLE_AMOUNT > SO_HEADER_ROW.NE_AMOUNT375 THEN
                       V_RANGE_JUST := V_RANGE_375;
                       V_RANGE_JUST_PREV := V_RANGE_360 ;
                       V_MOUNT_PREV := SO_HEADER_ROW.NE_AMOUNT360;
                       V_JUST_FLAG := '0';
                 ELSIF  SO_HEADER_ROW.SETTLE_AMOUNT = SO_HEADER_ROW.NE_AMOUNT375  THEN
                       V_RANGE_JUST := V_RANGE_375;
                       V_RANGE_JUST_PREV := V_RANGE_360 ;
                       V_MOUNT_PREV := SO_HEADER_ROW.NE_AMOUNT360;
                       V_JUST_FLAG := '1';              
                 ELSE
                     V_RANGE_JUST_PREV := V_RANGE_375 ;
                     V_MOUNT_PREV := SO_HEADER_ROW.NE_AMOUNT375;
                     V_RANGE_JUST := null;
                     V_JUST_FLAG := '2';
                 END IF;
               ELSE 
                   NULL;
               END IF;
               
             IF SO_HEADER_ROW.SETTLE_AMOUNT >0 THEN
                 IF V_JUST_FLAG = '1' AND V_RANGE_JUST IS NOT NULL THEN
                      --余额正好相等  全部插入账龄
                      P_AR_WRITE_OFF_BUSINESS_DETAIL(IN_ENTITY_ID,SO_HEADER_ROW.CUSTOMER_ID,SO_HEADER_ROW.ACCOUNT_ID,P_MATCH_DATE,V_RANGE_JUST, SO_HEADER_ROW.SETTLE_AMOUNT,V_AR_SALE_MAIN_TYPE,V_CHILD_RESULT,V_CHILD_MESSAGE);
                 ELSIF V_JUST_FLAG = '0' AND V_RANGE_JUST IS NOT NULL THEN   
                        --上个月的明细全部插入账龄
                        P_AR_WRITE_OFF_BUSINESS_DETAIL(IN_ENTITY_ID,SO_HEADER_ROW.CUSTOMER_ID,SO_HEADER_ROW.ACCOUNT_ID,P_MATCH_DATE,V_RANGE_JUST_PREV,SO_HEADER_ROW.SETTLE_AMOUNT,V_AR_SALE_MAIN_TYPE,V_CHILD_RESULT,V_CHILD_MESSAGE);  
                       
                        V_AMOUNT_ADD_UP := NVL(V_MOUNT_PREV,0);   
                        V_LOOP_END_FLAG :='0';
                         FOR 
                            SO_HEADER_DETAIL
                           IN( 
                              SELECT 
                                OD.CUSTOMER_ID 
                               ,(CASE WHEN OD.BIZ_SRC_BILL_TYPE_CODE IN ('1','-1') THEN '1' ELSE '2' END) ORDER_MAIN_TYPE
                               ,(CASE WHEN OD.BIZ_SRC_BILL_TYPE_CODE IN ('1','-1') THEN '1' ELSE OD.BIZ_SRC_BILL_TYPE_CODE END) SO_ORDER_TYPE 
                               ,OD.SO_HEADER_ID 
                               ,OD.SO_NUM 
                               ,OD.SO_DATE 
                               ,OD.SETTLE_DATE 
                               ,OD.SETTLE_AMOUNT 
                               ,(CASE WHEN OD.BIZ_SRC_BILL_TYPE_CODE NOT IN ('1','-1') AND OD.SO_STATUS='12'  THEN '0' 
                                      WHEN OD.BIZ_SRC_BILL_TYPE_CODE IN ('1','-1')  THEN '0' 
                                      ELSE '1' END ) SETTLED_FLAG 
                               ,OD.CUSTOMER_CODE 
                               ,OD.CUSTOMER_NAME 
                               ,OD.ENTITY_ID 
                               ,(CASE WHEN OD.SALES_MAIN_TYPE IS NULL THEN V_AR_SALE_MAIN_TYPE.SALE_MAIN_TYPE_CODE ELSE OD.SALES_MAIN_TYPE END) SALES_MAIN_TYPE
                               ,(CASE WHEN OD.SALES_MAIN_TYPE_NAME IS NULL THEN V_AR_SALE_MAIN_TYPE.SALE_MAIN_TYPE_NAME ELSE OD.SALES_MAIN_TYPE_NAME  END) SALES_MAIN_TYPE_NAME   
                               ,OD.ERP_OU_ID 
                               ,OD.ERP_OU_NAME 
                               ,OD.SALES_CENTER_ID
                               ,OD.SALES_CENTER_CODE 
                               ,OD.SALES_CENTER_NAME 
                               ,OD.ACCOUNT_ID 
                          FROM V_AR_SO_WRITE_OFF_DETAIL OD
                          where  OD.ENTITY_ID = IN_ENTITY_ID
                            AND OD.CUSTOMER_ID =  SO_HEADER_ROW.CUSTOMER_ID
                            AND OD.ACCOUNT_ID = SO_HEADER_ROW.ACCOUNT_ID
                            and  OD.SETTLE_DATE <  V_PARAM_MATCH_DATE+1
                            and ( V_RANGE_JUST_PREV IS NULL OR OD.SETTLE_DATE < V_RANGE_JUST_PREV )
                            AND　OD.SETTLE_DATE >= V_RANGE_JUST
                            AND  OD.SETTLE_AMOUNT>0 ORDER BY OD.SETTLE_DATE DESC
                    )LOOP
                       BEGIN      
                           V_AMOUNT_ADD_UP := SO_HEADER_DETAIL.SETTLE_AMOUNT + V_AMOUNT_ADD_UP;
                           V_WRITE_OFF_AMOUNT := 0;
                           IF V_AMOUNT_ADD_UP >= SO_HEADER_ROW.SETTLE_AMOUNT THEN
                               V_WRITE_OFF_AMOUNT := V_AMOUNT_ADD_UP - SO_HEADER_ROW.SETTLE_AMOUNT;
                               V_LOOP_END_FLAG := '1';
                           END IF;
                             INSERT INTO T_SO_ACCOUNT_AGE_BUSINESS(
                              ACCOUNT_AGE_ID                                --财龄ID
                              ,CUSTOMER_ID                                  --客户ID
                              ,ORDER_MAIN_TYPE                              --单据主类型（收款单/财务单）1代表收款单、2代表财务单
                              ,AR_TYPE                                      --应收类型（应收款/回款）1代表应收款，2代表回款
                              ,SO_ORDER_TYPE                                --财务单据类型
                              ,ORDER_ID                                      --单据ID
                              ,ORDER_LINES_ID                                --单据行ID
                              ,ORDER_NUMBER                                  --单据号
                              ,ORDER_DATE                                    --单据日期
                              ,AGE_DATE                                      --账龄日期
                              ,ORDER_AMOUNT                                  --单据金额
                              ,WRITE_OFF_AMOUNT                              --核销金额
                              ,USED_FLAG                                    --核销标志（0:全部核销；1:部分核销；2:未核销）
                              ,SETTLED_FLAG                                 --结算标志(0:已结算；1:未结算)
                              ,CUSTOMER_CODE                                --客户编码
                              ,CUSTOMER_NAME                                --客户名称
                              ,ENTITY_ID                                    --主体ID
                              ,SALES_MAIN_TYPE_ID                            --营销大类ID
                              ,SALES_MAIN_TYPE_CODE                          --营销大类编码
                              ,SALES_MAIN_TYPE_NAME                          --营销大类名称
                              ,MATCH_DATE                                   --核销日期
                              ,ERP_OU_ID                                    --ERP_OU_ID
                              ,ERP_OU_NAME                                  --ERP_OU_NAME
                              ,WRITE_OFF_AMOUNT2                            --未核销金额
                              ,SALES_CENTER_ID                              --营销中心ID
                              ,SALES_CENTER_CODE                            --营销中心编码
                              ,SALES_CENTER_NAME                            --营销中心名称
                              ,ACCOUNT_ID                                   --账户ID
                              ,PROTO_QUOTA )                                 --样机额度
                  　　   VALUES( 
                              S_SO_ACCOUNT_AGE_BUSINESS.Nextval
                             ,SO_HEADER_DETAIL.CUSTOMER_ID
                             ,SO_HEADER_DETAIL.ORDER_MAIN_TYPE
                             ,'2'
                             ,SO_HEADER_DETAIL.SO_ORDER_TYPE 
                             ,SO_HEADER_DETAIL.SO_HEADER_ID
                             ,null
                             ,SO_HEADER_DETAIL.SO_NUM
                             ,SO_HEADER_DETAIL.SO_DATE
                             ,SO_HEADER_DETAIL.SETTLE_DATE
                             ,SO_HEADER_DETAIL.SETTLE_AMOUNT
                             ,V_WRITE_OFF_AMOUNT
                             ,(CASE WHEN V_WRITE_OFF_AMOUNT =0 THEN '2' ELSE '1' END)
                             ,SO_HEADER_DETAIL.SETTLED_FLAG 
                             ,SO_HEADER_DETAIL.CUSTOMER_CODE
                             ,SO_HEADER_DETAIL.CUSTOMER_NAME
                             ,SO_HEADER_DETAIL.ENTITY_ID
                             ,null
                             ,SO_HEADER_DETAIL.SALES_MAIN_TYPE
                             ,SO_HEADER_DETAIL.SALES_MAIN_TYPE_NAME   
                             ,V_PARAM_MATCH_DATE
                             ,SO_HEADER_DETAIL.ERP_OU_ID
                             ,SO_HEADER_DETAIL.ERP_OU_NAME
                             ,SO_HEADER_DETAIL.SETTLE_AMOUNT-V_WRITE_OFF_AMOUNT
                             ,SO_HEADER_DETAIL.SALES_CENTER_ID
                             ,SO_HEADER_DETAIL.SALES_CENTER_CODE
                             ,SO_HEADER_DETAIL.SALES_CENTER_NAME
                             ,SO_HEADER_DETAIL.ACCOUNT_ID
                             ,null
                           );
                           IF  V_LOOP_END_FLAG ='1' THEN
                               EXIT; 
                           END IF;
                         
                       EXCEPTION
                          WHEN OTHERS THEN 
                            P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
                            P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_AR_PRIOR_WRITE_OFFS', SQLCODE,
                                    '循环插入账龄明细出错！错误日志：主体：'||IN_ENTITY_ID||
                                    '，客户'||SO_HEADER_DETAIL.CUSTOMER_CODE||
                                    '，账户：'||SO_HEADER_DETAIL.ACCOUNT_ID||
                                    '，事物处理日期：'||P_MATCH_DATE||
                                    '。异常消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
                        END;
                      END LOOP; 
                      
               ELSIF V_JUST_FLAG = '2'  THEN  
                      --上个月的明细全部插入账龄   余额  大于0
                     P_AR_WRITE_OFF_BUSINESS_DETAIL(IN_ENTITY_ID,SO_HEADER_ROW.CUSTOMER_ID,SO_HEADER_ROW.ACCOUNT_ID,P_MATCH_DATE,V_RANGE_JUST_PREV, SO_HEADER_ROW.SETTLE_AMOUNT,V_AR_SALE_MAIN_TYPE,V_CHILD_RESULT,V_CHILD_MESSAGE);  
                        
                   --  SELECT CUSTOMER_CODE,CUSTOMER_NAME INTO V_CUSTOMER_CODE,V_CUSTOMER_NAME FROM T_CUSTOMER_HEADER WHERE CUSTOMER_ID = SO_HEADER_ROW.CUSTOMER_ID;
                  --   SELECT UNIT_ID,CODE,NAME INTO V_SALES_CENTER_ID,V_SALES_CENTER_CODE,V_SALES_CENTER_NAME FROM UP_ORG_UNIT WHERE UNIT_ID = SO_HEADER_ROW.SALES_CENTER_ID;
                  --   SELECT CODE_VALUE,CODE_NAME INTO V_ERP_OU_ID,V_ERP_OU_NAME FROM V_UP_CODELIST WHERE CODETYPE='ar_ou_id'   AND CODE_VALUE=SO_HEADER_ROW.IN_ERP_OU_ID;
    
                     INSERT INTO T_SO_ACCOUNT_AGE_BUSINESS(
                              ACCOUNT_AGE_ID                                --财龄ID
                              ,CUSTOMER_ID                                  --客户ID
                              ,ORDER_MAIN_TYPE                              --单据主类型（收款单/财务单）1代表收款单、2代表财务单
                              ,AR_TYPE                                      --应收类型（应收款/回款）1代表应收款，2代表回款
                              ,SO_ORDER_TYPE                                --财务单据类型
                              ,ORDER_ID                                      --单据ID
                              ,ORDER_LINES_ID                                --单据行ID
                              ,ORDER_NUMBER                                  --单据号
                              ,ORDER_DATE                                    --单据日期
                              ,AGE_DATE                                      --账龄日期
                              ,ORDER_AMOUNT                                  --单据金额
                              ,WRITE_OFF_AMOUNT                              --核销金额
                              ,USED_FLAG                                    --核销标志（0:全部核销；1:部分核销；2:未核销）
                              ,SETTLED_FLAG                                 --结算标志(0:已结算；1:未结算)
                              ,CUSTOMER_CODE                                --客户编码
                              ,CUSTOMER_NAME                                --客户名称
                              ,ENTITY_ID                                    --主体ID
                              ,SALES_MAIN_TYPE_ID                            --营销大类ID
                              ,SALES_MAIN_TYPE_CODE                          --营销大类编码
                              ,SALES_MAIN_TYPE_NAME                          --营销大类名称
                              ,MATCH_DATE                                   --核销日期
                              ,ERP_OU_ID                                    --ERP_OU_ID
                              ,ERP_OU_NAME                                  --ERP_OU_NAME
                              ,WRITE_OFF_AMOUNT2                            --未核销金额
                              ,SALES_CENTER_ID                              --营销中心ID
                              ,SALES_CENTER_CODE                            --营销中心编码
                              ,SALES_CENTER_NAME                            --营销中心名称
                              ,ACCOUNT_ID                                   --账户ID
                              ,PROTO_QUOTA )                                 --样机额度
                  　　   VALUES( 
                              S_SO_ACCOUNT_AGE_BUSINESS.Nextval
                             ,SO_HEADER_ROW.CUSTOMER_ID
                             ,'1'
                             ,'2'
                             ,'1'
                             ,0
                             ,null
                             ,'375天后回款汇总'
                             ,V_RANGE_LAST
                             ,V_RANGE_LAST
                             ,SO_HEADER_ROW.SETTLE_AMOUNT - V_MOUNT_PREV 
                             ,0
                             ,'2'
                             ,'0'
                             ,SO_HEADER_ROW.CUSTOMER_CODE
                             ,SO_HEADER_ROW.CUSTOMER_NAME
                             ,SO_HEADER_ROW.ENTITY_ID
                             ,null
                             ,V_AR_SALE_MAIN_TYPE.SALE_MAIN_TYPE_CODE
                             ,V_AR_SALE_MAIN_TYPE.SALE_MAIN_TYPE_NAME 
                             ,V_PARAM_MATCH_DATE
                             ,SO_HEADER_ROW.ERP_OU_ID
                             ,SO_HEADER_ROW.ERP_OU_NAME
                             ,SO_HEADER_ROW.SETTLE_AMOUNT - V_MOUNT_PREV 
                             ,SO_HEADER_ROW.SALES_CENTER_ID
                             ,SO_HEADER_ROW.SALES_CENTER_CODE
                             ,SO_HEADER_ROW.SALES_CENTER_NAME
                             ,SO_HEADER_ROW.ACCOUNT_ID
                             ,null
                           );                 
               END IF;
           ELSIF  SO_HEADER_ROW.SETTLE_AMOUNT < 0 THEN     
                 IF V_JUST_FLAG = '1' AND V_RANGE_JUST IS NOT NULL THEN
                      --余额正好相等  全部插入账龄
                      P_AR_WRITE_OFF_BUSINESS_DETAIL(IN_ENTITY_ID,SO_HEADER_ROW.CUSTOMER_ID,SO_HEADER_ROW.ACCOUNT_ID,P_MATCH_DATE,V_RANGE_JUST, SO_HEADER_ROW.SETTLE_AMOUNT,V_AR_SALE_MAIN_TYPE,V_CHILD_RESULT,V_CHILD_MESSAGE);
                 ELSIF V_JUST_FLAG = '0' AND V_RANGE_JUST IS NOT NULL THEN  
                       --插入上一周期的明细
                      P_AR_WRITE_OFF_BUSINESS_DETAIL(IN_ENTITY_ID,SO_HEADER_ROW.CUSTOMER_ID,SO_HEADER_ROW.ACCOUNT_ID,P_MATCH_DATE,V_RANGE_JUST_PREV, SO_HEADER_ROW.SETTLE_AMOUNT,V_AR_SALE_MAIN_TYPE,V_CHILD_RESULT,V_CHILD_MESSAGE);
                      
                        --循环推算终点单据
                        V_AMOUNT_ADD_UP := NVL(V_MOUNT_PREV,0);   
                        V_LOOP_END_FLAG :='0';
                         FOR 
                            SO_HEADER_DETAIL
                           IN( 
                              SELECT 
                                OD.CUSTOMER_ID 
                               ,(CASE WHEN OD.BIZ_SRC_BILL_TYPE_CODE IN ('1','-1') THEN '1' ELSE '2' END) ORDER_MAIN_TYPE
                               ,(CASE WHEN OD.BIZ_SRC_BILL_TYPE_CODE IN ('1','-1') THEN '1' ELSE OD.BIZ_SRC_BILL_TYPE_CODE END) SO_ORDER_TYPE 
                               ,OD.SO_HEADER_ID 
                               ,OD.SO_NUM 
                               ,OD.SO_DATE 
                               ,OD.SETTLE_DATE 
                               ,OD.SETTLE_AMOUNT 
                               ,(CASE WHEN OD.BIZ_SRC_BILL_TYPE_CODE NOT IN ('1','-1') AND OD.SO_STATUS='12'  THEN '0' 
                                      WHEN OD.BIZ_SRC_BILL_TYPE_CODE IN ('1','-1')  THEN '0' 
                                      ELSE '1' END ) SETTLED_FLAG 
                               ,OD.CUSTOMER_CODE 
                               ,OD.CUSTOMER_NAME 
                               ,OD.ENTITY_ID 
                               ,(CASE WHEN OD.SALES_MAIN_TYPE IS NULL THEN V_AR_SALE_MAIN_TYPE.SALE_MAIN_TYPE_CODE ELSE OD.SALES_MAIN_TYPE END) SALES_MAIN_TYPE
                               ,(CASE WHEN OD.SALES_MAIN_TYPE_NAME IS NULL THEN V_AR_SALE_MAIN_TYPE.SALE_MAIN_TYPE_NAME ELSE OD.SALES_MAIN_TYPE_NAME  END) SALES_MAIN_TYPE_NAME   
                               ,OD.ERP_OU_ID 
                               ,OD.ERP_OU_NAME 
                               ,OD.SALES_CENTER_ID
                               ,OD.SALES_CENTER_CODE 
                               ,OD.SALES_CENTER_NAME 
                               ,OD.ACCOUNT_ID 
                          FROM V_AR_SO_WRITE_OFF_DETAIL OD
                          where  OD.ENTITY_ID = IN_ENTITY_ID
                            AND OD.CUSTOMER_ID =  SO_HEADER_ROW.CUSTOMER_ID
                            AND OD.ACCOUNT_ID = SO_HEADER_ROW.ACCOUNT_ID
                            and  OD.SETTLE_DATE < V_PARAM_MATCH_DATE+1
                            and ( V_RANGE_JUST_PREV IS NULL OR OD.SETTLE_DATE < V_RANGE_JUST_PREV )
                            AND　OD.SETTLE_DATE >= V_RANGE_JUST
                            AND  OD.SETTLE_AMOUNT < 0 ORDER BY OD.SETTLE_DATE DESC
                    )LOOP
                       BEGIN      
                           V_AMOUNT_ADD_UP := SO_HEADER_DETAIL.SETTLE_AMOUNT + V_AMOUNT_ADD_UP;
                           V_WRITE_OFF_AMOUNT := 0;
                           IF V_AMOUNT_ADD_UP <= SO_HEADER_ROW.SETTLE_AMOUNT THEN
                               V_WRITE_OFF_AMOUNT := V_AMOUNT_ADD_UP - SO_HEADER_ROW.SETTLE_AMOUNT;
                               V_WRITE_OFF_AMOUNT := ABS(V_WRITE_OFF_AMOUNT);
                               V_LOOP_END_FLAG := '1';
                           END IF;
                             INSERT INTO T_SO_ACCOUNT_AGE_BUSINESS(
                              ACCOUNT_AGE_ID                                --财龄ID
                              ,CUSTOMER_ID                                  --客户ID
                              ,ORDER_MAIN_TYPE                              --单据主类型（收款单/财务单）1代表收款单、2代表财务单
                              ,AR_TYPE                                      --应收类型（应收款/回款）1代表应收款，2代表回款
                              ,SO_ORDER_TYPE                                --财务单据类型
                              ,ORDER_ID                                      --单据ID
                              ,ORDER_LINES_ID                                --单据行ID
                              ,ORDER_NUMBER                                  --单据号
                              ,ORDER_DATE                                    --单据日期
                              ,AGE_DATE                                      --账龄日期
                              ,ORDER_AMOUNT                                  --单据金额
                              ,WRITE_OFF_AMOUNT                              --核销金额
                              ,USED_FLAG                                    --核销标志（0:全部核销；1:部分核销；2:未核销）
                              ,SETTLED_FLAG                                 --结算标志(0:已结算；1:未结算)
                              ,CUSTOMER_CODE                                --客户编码
                              ,CUSTOMER_NAME                                --客户名称
                              ,ENTITY_ID                                    --主体ID
                              ,SALES_MAIN_TYPE_ID                            --营销大类ID
                              ,SALES_MAIN_TYPE_CODE                          --营销大类编码
                              ,SALES_MAIN_TYPE_NAME                          --营销大类名称
                              ,MATCH_DATE                                   --核销日期
                              ,ERP_OU_ID                                    --ERP_OU_ID
                              ,ERP_OU_NAME                                  --ERP_OU_NAME
                              ,WRITE_OFF_AMOUNT2                            --未核销金额
                              ,SALES_CENTER_ID                              --营销中心ID
                              ,SALES_CENTER_CODE                            --营销中心编码
                              ,SALES_CENTER_NAME                            --营销中心名称
                              ,ACCOUNT_ID                                   --账户ID
                              ,PROTO_QUOTA )                                 --样机额度
                  　　   VALUES( 
                              S_SO_ACCOUNT_AGE_BUSINESS.Nextval
                             ,SO_HEADER_DETAIL.CUSTOMER_ID
                             ,SO_HEADER_DETAIL.ORDER_MAIN_TYPE
                             ,'1'
                             ,SO_HEADER_DETAIL.SO_ORDER_TYPE 
                             ,SO_HEADER_DETAIL.SO_HEADER_ID
                             ,null
                             ,SO_HEADER_DETAIL.SO_NUM
                             ,SO_HEADER_DETAIL.SO_DATE
                             ,SO_HEADER_DETAIL.SETTLE_DATE
                             ,ABS(SO_HEADER_DETAIL.SETTLE_AMOUNT)
                             ,V_WRITE_OFF_AMOUNT
                             ,(CASE WHEN V_WRITE_OFF_AMOUNT =0 THEN '2' ELSE '1' END)
                             ,SO_HEADER_DETAIL.SETTLED_FLAG 
                             ,SO_HEADER_DETAIL.CUSTOMER_CODE
                             ,SO_HEADER_DETAIL.CUSTOMER_NAME
                             ,SO_HEADER_DETAIL.ENTITY_ID
                             ,null
                             ,SO_HEADER_DETAIL.SALES_MAIN_TYPE
                             ,SO_HEADER_DETAIL.SALES_MAIN_TYPE_NAME   
                             ,V_PARAM_MATCH_DATE
                             ,SO_HEADER_DETAIL.ERP_OU_ID
                             ,SO_HEADER_DETAIL.ERP_OU_NAME
                             ,ABS(SO_HEADER_DETAIL.SETTLE_AMOUNT)-V_WRITE_OFF_AMOUNT
                             ,SO_HEADER_DETAIL.SALES_CENTER_ID
                             ,SO_HEADER_DETAIL.SALES_CENTER_CODE
                             ,SO_HEADER_DETAIL.SALES_CENTER_NAME
                             ,SO_HEADER_DETAIL.ACCOUNT_ID
                             ,null
                           );
                           IF  V_LOOP_END_FLAG ='1' THEN
                               EXIT; 
                           END IF;
                         
                       EXCEPTION
                          WHEN OTHERS THEN 
                            P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
                            P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_AR_PRIOR_WRITE_OFFS', SQLCODE,
                                    '循环插入账龄明细出错！错误日志：主体：'||IN_ENTITY_ID||
                                    '，客户'||SO_HEADER_DETAIL.CUSTOMER_CODE||
                                    '，账户：'||SO_HEADER_DETAIL.ACCOUNT_ID||
                                    '，事物处理日期：'||P_MATCH_DATE||
                                    '。异常消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
                        END;
                      END LOOP; 
                  ELSIF V_JUST_FLAG = '2'  THEN  
                       --上个月的明细全部插入账龄
                       P_AR_WRITE_OFF_BUSINESS_DETAIL(IN_ENTITY_ID,SO_HEADER_ROW.CUSTOMER_ID,SO_HEADER_ROW.ACCOUNT_ID,P_MATCH_DATE,V_RANGE_JUST_PREV, SO_HEADER_ROW.SETTLE_AMOUNT,V_AR_SALE_MAIN_TYPE,V_CHILD_RESULT,V_CHILD_MESSAGE);  
                       INSERT INTO T_SO_ACCOUNT_AGE_BUSINESS(
                              ACCOUNT_AGE_ID                                --财龄ID
                              ,CUSTOMER_ID                                  --客户ID
                              ,ORDER_MAIN_TYPE                              --单据主类型（收款单/财务单）1代表收款单、2代表财务单
                              ,AR_TYPE                                      --应收类型（应收款/回款）1代表应收款，2代表回款
                              ,SO_ORDER_TYPE                                --财务单据类型
                              ,ORDER_ID                                      --单据ID
                              ,ORDER_LINES_ID                                --单据行ID
                              ,ORDER_NUMBER                                  --单据号
                              ,ORDER_DATE                                    --单据日期
                              ,AGE_DATE                                      --账龄日期
                              ,ORDER_AMOUNT                                  --单据金额
                              ,WRITE_OFF_AMOUNT                              --核销金额
                              ,USED_FLAG                                    --核销标志（0:全部核销；1:部分核销；2:未核销）
                              ,SETTLED_FLAG                                 --结算标志(0:已结算；1:未结算)
                              ,CUSTOMER_CODE                                --客户编码
                              ,CUSTOMER_NAME                                --客户名称
                              ,ENTITY_ID                                    --主体ID
                              ,SALES_MAIN_TYPE_ID                            --营销大类ID
                              ,SALES_MAIN_TYPE_CODE                          --营销大类编码
                              ,SALES_MAIN_TYPE_NAME                          --营销大类名称
                              ,MATCH_DATE                                   --核销日期
                              ,ERP_OU_ID                                    --ERP_OU_ID
                              ,ERP_OU_NAME                                  --ERP_OU_NAME
                              ,WRITE_OFF_AMOUNT2                            --未核销金额
                              ,SALES_CENTER_ID                              --营销中心ID
                              ,SALES_CENTER_CODE                            --营销中心编码
                              ,SALES_CENTER_NAME                            --营销中心名称
                              ,ACCOUNT_ID                                   --账户ID
                              ,PROTO_QUOTA )                                 --样机额度
                  　　   VALUES( 
                              S_SO_ACCOUNT_AGE_BUSINESS.Nextval
                             ,SO_HEADER_ROW.CUSTOMER_ID
                             ,'2'
                             ,'1'
                             ,'1001'
                             ,0
                             ,null
                             ,'375天后应收汇总'
                             ,V_RANGE_LAST
                             ,V_RANGE_LAST
                             ,ABS(SO_HEADER_ROW.SETTLE_AMOUNT - V_MOUNT_PREV)
                             ,0
                             ,'2'
                             ,'1'
                             ,SO_HEADER_ROW.CUSTOMER_CODE
                             ,SO_HEADER_ROW.CUSTOMER_NAME
                             ,SO_HEADER_ROW.ENTITY_ID
                             ,null
                             ,V_AR_SALE_MAIN_TYPE.SALE_MAIN_TYPE_CODE
                             ,V_AR_SALE_MAIN_TYPE.SALE_MAIN_TYPE_NAME 
                             ,V_PARAM_MATCH_DATE
                             ,SO_HEADER_ROW.ERP_OU_ID
                             ,SO_HEADER_ROW.ERP_OU_NAME
                             ,ABS(SO_HEADER_ROW.SETTLE_AMOUNT - V_MOUNT_PREV)
                             ,SO_HEADER_ROW.SALES_CENTER_ID
                             ,SO_HEADER_ROW.SALES_CENTER_CODE
                             ,SO_HEADER_ROW.SALES_CENTER_NAME
                             ,SO_HEADER_ROW.ACCOUNT_ID
                             ,null
                           );                 
               END IF;  
           END IF;
           
            UPDATE T_SO_ACCOUNT_AGE_BUSINESS F
            SET F.PROTO_QUOTA = (SELECT Q.PROTO_QUOTA 
                                 FROM T_AR_PROTO_QUOTA Q
                                 WHERE Q.ENTITY_ID = F.ENTITY_ID
                                    AND Q.CUSTOMER_ID = F.CUSTOMER_ID
                                    AND Q.ACCOUNT_ID = F.ACCOUNT_ID
                                    AND Q.ACTIVE_FLAG='Y'
                                    AND ROWNUM=1)
            WHERE F.ENTITY_ID = IN_ENTITY_ID
             AND F.MATCH_DATE = V_PARAM_MATCH_DATE;  
           
           COMMIT;    
           EXCEPTION
                WHEN OTHERS THEN 
                 ROLLBACK ;
                 P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
                 P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_AR_PRIOR_WRITE_OFFS', SQLCODE,
                          '推算账龄明细出错！错误日志：主体：'||SO_HEADER_ROW.ENTITY_ID||
                          '，客户'||SO_HEADER_ROW.CUSTOMER_ID||
                          '，账户：'||SO_HEADER_ROW.ACCOUNT_ID||
                          '，事物处理日期：'||P_MATCH_DATE||
                          '。异常消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
            END;
        END LOOP;        
    END;
    
    --------------------------------------------------------------------------
  --Author: guibr
  --Created: 2018-12-11
  --业务核销  插入账龄明细
  --------------------------------------------------------------------------
  Procedure P_AR_WRITE_OFF_BUSINESS_DETAIL(
                                 IN_ENTITY_ID IN  NUMBER,  --主体 
                                 P_CUSTOMER_ID IN  NUMBER,  --客户ID
                                 P_ACCOUNT_ID IN  NUMBER,  --账户ID
                                 P_MATCH_DATE IN VARCHAR2, --核销日期。默认取TRUNC(SYSDATE - 1,'DD')
                                 P_RANGE_DATE  IN DATE,  
                                 P_AGE_MOUNT  IN NUMBER,
                                 P_AR_SALE_MAIN_TYPE  IN  PKG_AR_WRITE_OFF.AR_SALE_MAIN_TYPE,
                                 P_RESULT  OUT VARCHAR2,-- 失败时返回异常消息
                                 P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，失败返回“ERROR”
      )  IS 
    V_SQL  VARCHAR2(30000);
    V_UPDATE_TABLE VARCHAR2(10000);
    V_UPDATE_WHERE VARCHAR2(10000) ;
    V_PARAM_RANGE_DATE  VARCHAR2(50);
   BEGIN 
       P_MESSAGE := PKG_AR_WRITE_OFF.V_SUCCESS;
       V_UPDATE_TABLE := 'INSERT INTO T_SO_ACCOUNT_AGE_BUSINESS(
                              ACCOUNT_AGE_ID                            
                              ,CUSTOMER_ID                               
                              ,ORDER_MAIN_TYPE                              
                              ,AR_TYPE                                      
                              ,SO_ORDER_TYPE                               
                              ,ORDER_ID                                    
                              ,ORDER_LINES_ID                                
                              ,ORDER_NUMBER                                 
                              ,ORDER_DATE                                    
                              ,AGE_DATE                                     
                              ,ORDER_AMOUNT                                 
                              ,WRITE_OFF_AMOUNT                             
                              ,USED_FLAG                                   
                              ,SETTLED_FLAG                                 
                              ,CUSTOMER_CODE                                
                              ,CUSTOMER_NAME                              
                              ,ENTITY_ID                                  
                              ,SALES_MAIN_TYPE_ID                          
                              ,SALES_MAIN_TYPE_CODE                          
                              ,SALES_MAIN_TYPE_NAME                          
                              ,MATCH_DATE                                
                              ,ERP_OU_ID                                
                              ,ERP_OU_NAME                                 
                              ,WRITE_OFF_AMOUNT2                            
                              ,SALES_CENTER_ID                              
                              ,SALES_CENTER_CODE                           
                              ,SALES_CENTER_NAME                            
                              ,ACCOUNT_ID                                  
                              ,PROTO_QUOTA )';
        V_UPDATE_WHERE :=  ' SELECT '
                             ||' S_SO_ACCOUNT_AGE_BUSINESS.Nextval '
                             ||'  ,OD.CUSTOMER_ID '
                             ||'  ,(CASE WHEN OD.BIZ_SRC_BILL_TYPE_CODE IN (''1'',''-1'') THEN ''1'' ELSE ''2'' END) ORDER_MAIN_TYPE '
                             ||'  ,(CASE WHEN OD.SETTLE_AMOUNT>0 THEN ''2'' else ''1'' end) AR_TYPE '
                             ||' ,(CASE WHEN OD.BIZ_SRC_BILL_TYPE_CODE IN (''1'',''-1'') THEN ''1'' ELSE OD.BIZ_SRC_BILL_TYPE_CODE END) SO_ORDER_TYPE  '
                             ||' ,OD.SO_HEADER_ID '
                             ||' ,null '
                             ||'  ,OD.SO_NUM '
                             ||' ,OD.SO_DATE '
                             ||' ,OD.SETTLE_DATE '
                             ||' ,ABS(OD.SETTLE_AMOUNT) '
                             ||' ,0 '
                             ||'  ,''2'' '
                             ||' ,(CASE WHEN OD.BIZ_SRC_BILL_TYPE_CODE NOT IN (''1'',''-1'') AND OD.SO_STATUS=''12''  THEN ''0'' '
                             ||'       WHEN OD.BIZ_SRC_BILL_TYPE_CODE IN (''1'',''-1'')  THEN ''0''  '
                             ||'        ELSE ''1'' END ) SETTLED_FLAG  '
                             ||' ,OD.CUSTOMER_CODE '
                             ||' ,OD.CUSTOMER_NAME '
                             ||' ,OD.ENTITY_ID '
                             ||' ,null '
                             ||'  ,(CASE WHEN OD.SALES_MAIN_TYPE IS NULL THEN '''||P_AR_SALE_MAIN_TYPE.SALE_MAIN_TYPE_CODE||''' ELSE OD.SALES_MAIN_TYPE END) SALES_MAIN_TYPE '
                             ||' ,(CASE WHEN OD.SALES_MAIN_TYPE_NAME IS NULL THEN ''' ||P_AR_SALE_MAIN_TYPE.SALE_MAIN_TYPE_NAME|| ''' ELSE OD.SALES_MAIN_TYPE_NAME  END) SALES_MAIN_TYPE_NAME ' 
                             ||',TO_DATE('''||P_MATCH_DATE||''',''yyyy-mm-dd'')'
                             ||',OD.ERP_OU_ID '
                             ||',OD.ERP_OU_NAME '
                             ||',ABS(OD.SETTLE_AMOUNT) '
                             ||',OD.SALES_CENTER_ID '
                             ||',OD.SALES_CENTER_CODE '
                             ||',OD.SALES_CENTER_NAME '
                             ||',OD.ACCOUNT_ID '
                             ||' ,null '
                        ||' FROM V_AR_SO_WRITE_OFF_DETAIL OD ';
                        
        V_SQL :=  V_UPDATE_TABLE || V_UPDATE_WHERE; 
        V_SQL :=  V_SQL || ' WHERE  OD.ENTITY_ID ='|| IN_ENTITY_ID
                            ||' AND OD.CUSTOMER_ID ='|| P_CUSTOMER_ID
                            ||' AND OD.ACCOUNT_ID ='|| P_ACCOUNT_ID
                            ||' AND  OD.SETTLE_DATE < TO_DATE('''||P_MATCH_DATE||''',''yyyy-mm-dd'')+1' ;                                           
        IF  P_RANGE_DATE IS NOT NULL   THEN
              V_PARAM_RANGE_DATE := TO_CHAR(P_RANGE_DATE,'yyyy-mm-dd');
              V_SQL :=  V_SQL || ' and  OD.SETTLE_DATE >= TO_DATE('''||V_PARAM_RANGE_DATE||''',''yyyy-mm-dd'')' ;    
        ELSE  
            RETURN;  --日期为空不插入明细数据  直接返回
        END IF;   
        IF P_AGE_MOUNT>0 THEN
            V_SQL :=  V_SQL || ' AND  OD.SETTLE_AMOUNT>0 ';
        ELSIF  P_AGE_MOUNT<0 THEN 
            V_SQL :=  V_SQL || ' AND  OD.SETTLE_AMOUNT<0 ';
        ELSE     
           RAISE_APPLICATION_ERROR(-20000, '金额为0不存在账龄');   
        END IF  ;  
      --  dbms_output.put_line(V_SQL);
        EXECUTE IMMEDIATE V_SQL ; 
   EXCEPTION
       WHEN OTHERS THEN 
          P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
          P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_AR_PRIOR_WRITE_OFFS', SQLCODE,
              '插入账龄明细出错！错误日志：主体：'||IN_ENTITY_ID||
              '，客户'||P_CUSTOMER_ID||
              '，账户：'||P_ACCOUNT_ID||
              '，事物处理日期：'||P_MATCH_DATE||
              '。异常消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
   END;


  
  --冻结账龄日报表
  PROCEDURE P_AR_AGE_DISCOUNT_FREEZE
  (
      IN_ENTITY_ID IN  NUMBER,  --主体 
      P_MATCH_DATE IN VARCHAR2, --核销日期。默认取TRUNC(SYSDATE - 1,'DD')
      P_RESULT  OUT VARCHAR2,
      P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  )AS
  BEGIN
      P_MESSAGE := PKG_AR_WRITE_OFF.V_SUCCESS;
      delete from T_SO_ACCOUNT_BUSINESS_DISCOUNT where ENTITY_ID= IN_ENTITY_ID and  FREEZE_DATE = P_MATCH_DATE;
      
      INSERT INTO T_SO_ACCOUNT_BUSINESS_DISCOUNT(
         SALES_CENTER_ID
        ,SALES_CENTER_CODE
        ,SALES_CENTER_NAME
        ,ACCOUNT_CODE
        ,CUSTOMER_ID
        ,CUSTOMER_CODE
        ,CUSTOMER_NAME
        ,DISCOUNT_FREEZE_ID
        ,CREATED_BY
        ,CREATION_DATE
        ,LAST_UPDATED_BY
        ,LAST_UPDATE_DATE
        ,FREEZE_DATE
        ,ENTITY_ID
        ,SALES_MAIN_TYPE_CODE
        ,SETTLE_AMOUNT
        ,SO_NUM
        ,BIZ_SRC_BILL_TYPE_CODE
        ,ACCOUNT_ID
        ,PROTO_QUOTA
        )
        SELECT 
               SH.SALES_CENTER_ID
              ,SH.SALES_CENTER_CODE
              ,SH.SALES_CENTER_NAME
              ,SH.ACCOUNT_CODE
              ,SH.CUSTOMER_ID
              ,SH.CUSTOMER_CODE
              ,SH.CUSTOMER_NAME
              ,S_SO_ACCOUNT_DISCOUNT.NEXTVAL
              ,'SYSTEM'
              ,SYSDATE
              ,'SYSTEM'
              ,SYSDATE
              ,P_MATCH_DATE
              ,SH.ENTITY_ID
              ,SH.SALES_MAIN_TYPE
              ,SH.SETTLE_AMOUNT * TE.APPLIED_PLUS_MINUS_FLAG SETTLE_AMOUNT
               ,SH.SO_NUM
               ,SH.BIZ_SRC_BILL_TYPE_CODE
               ,SH.ACCOUNT_ID
               ,(SELECT Q.PROTO_QUOTA 
                               FROM T_AR_PROTO_QUOTA Q
                               WHERE Q.ENTITY_ID = SH.ENTITY_ID
                                  AND Q.CUSTOMER_CODE = SH.CUSTOMER_CODE
                                  AND Q.ACCOUNT_CODE = SH.ACCOUNT_CODE
                                  AND Q.ACTIVE_FLAG='Y'
                                  AND ROWNUM=1)
               FROM CIMS.T_SO_HEADER SH
               ,CIMS.T_SO_TYPE_EXTEND TE
        WHERE   SH.ENTITY_ID = IN_ENTITY_ID
              AND SH.BIZ_SRC_BILL_TYPE_CODE IN ('1003','1004','1007', '1008')
              AND NVL(SH.SETTLE_FLAG, 'N') <> 'Y'
              AND SH.BILL_TYPE_ID = TE.BILL_TYPE_ID
              AND SH.SO_DATE < TO_DATE(P_MATCH_DATE, 'YYYY-MM-DD')+1; --未结算的
            
       INSERT INTO T_SO_ACCOUNT_BUSINESS_DISCOUNT(
          SALES_CENTER_ID
          ,SALES_CENTER_CODE
          ,SALES_CENTER_NAME
          ,ACCOUNT_CODE
          ,CUSTOMER_ID
          ,CUSTOMER_CODE
          ,CUSTOMER_NAME
          ,DISCOUNT_FREEZE_ID
          ,CREATED_BY
          ,CREATION_DATE
          ,LAST_UPDATED_BY
          ,LAST_UPDATE_DATE
          ,FREEZE_DATE
          ,ENTITY_ID
          ,SALES_MAIN_TYPE_CODE
          ,SETTLE_AMOUNT
          ,SO_NUM
          ,BIZ_SRC_BILL_TYPE_CODE
          ,ACCOUNT_ID
           ,PROTO_QUOTA
          )
          SELECT 
                SH.SALES_CENTER_ID
                ,SH.SALES_CENTER_CODE
                ,SH.SALES_CENTER_NAME
                ,SH.ACCOUNT_CODE
                ,SH.CUSTOMER_ID
                ,SH.CUSTOMER_CODE
                ,SH.CUSTOMER_NAME
                ,S_SO_ACCOUNT_DISCOUNT.NEXTVAL
                ,'SYSTEM'
                ,SYSDATE
                ,'SYSTEM'
                ,SYSDATE
                ,P_MATCH_DATE
                ,SH.ENTITY_ID
                ,SH.SALES_MAIN_TYPE
                ,SH.SETTLE_AMOUNT * TE.APPLIED_PLUS_MINUS_FLAG SETTLE_AMOUNT
                 ,SH.SO_NUM
                 ,SH.BIZ_SRC_BILL_TYPE_CODE
                 ,SH.ACCOUNT_ID
                 ,(SELECT Q.PROTO_QUOTA 
                                 FROM T_AR_PROTO_QUOTA Q
                                 WHERE Q.ENTITY_ID = SH.ENTITY_ID
                                    AND Q.CUSTOMER_CODE = SH.CUSTOMER_CODE
                                    AND Q.ACCOUNT_CODE = SH.ACCOUNT_CODE
                                    AND Q.ACTIVE_FLAG='Y'
                                    AND ROWNUM=1)
                 FROM CIMS.T_SO_HEADER SH
                 ,CIMS.T_SO_TYPE_EXTEND TE
          WHERE 
                SH.ENTITY_ID = IN_ENTITY_ID
                AND SH.BIZ_SRC_BILL_TYPE_CODE IN ('1003', '1004','1007', '1008')
                AND NVL(SH.SETTLE_FLAG, 'N') = 'Y'
                AND SH.BILL_TYPE_ID = TE.BILL_TYPE_ID
                AND SH.Settle_Date >= TO_DATE(P_MATCH_DATE, 'YYYY-MM-DD')+1 --已结算大于核销日期的单据   
                AND SH.SO_DATE < TO_DATE(P_MATCH_DATE, 'YYYY-MM-DD')+1; --单据日期小于核销日期
       EXCEPTION WHEN OTHERS THEN
              ROLLBACK;
              P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
              P_RESULT := PKG_BD.F_ADD_ERROR_LOG('P_AR_WRITE_OFF_BUSINESS_DETAIL.P_AR_AGE_DISCOUNT_FREEZE', SQLCODE,
                      '冻结日账龄报表出错！异常消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
          
         
        END;


END PKG_AR_WRITE_OFF_BUSINESS;
/

