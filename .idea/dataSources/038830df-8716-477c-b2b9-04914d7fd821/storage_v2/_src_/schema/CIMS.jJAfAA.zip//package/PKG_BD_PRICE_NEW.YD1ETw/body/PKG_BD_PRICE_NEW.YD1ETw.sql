create Package Body PKG_BD_PRICE_NEW Is
  /*取价函数*/
  function F_GET_PRICE
  (
   P_ACC_ID    t_customer_account.account_id%type,  --账户ID
   P_ITEM_CODE   t_bd_item.item_code%type,           --产品编码
   P_BILL_DATE  VARCHAR2,        --单据日期
   P_PRICE_LIST_ID  t_bd_price_list.price_list_id%type,    --价格列表ID
   P_ENTITY_ID    up_org_unit.ENTITY_ID%type     --业务主体ID
   ) --
   return NUMBER is
    LD_PRICE     NUMBER;
    LD_DISCOUNT  NUMBER;
    LD_MONTH_DISCOUNT  NUMBER;
    LS_CX_FLAG  varchar2(2);
    LS_RETURN_SYSTEM_ID t_bd_price_system.price_system_id%type; --价格体系ID
    LS_RETURN_LIST_ID t_bd_price_list.price_list_id%type; --价格列表ID
    LD_RESULT NUMBER; --返回错误ID
    LS_ERR_MSG varchar2(1000);--返回错误信息  
  begin
    P_GET_PRICE_MAIN(P_ACC_ID,
                P_ITEM_CODE,
                P_BILL_DATE,
                P_PRICE_LIST_ID,
                P_ENTITY_ID,
                LD_PRICE,
                LD_DISCOUNT,
                LD_MONTH_DISCOUNT,
                LS_CX_FLAG,
                LS_RETURN_SYSTEM_ID, --价格体系ID
                LS_RETURN_LIST_ID,
                LD_RESULT, --返回错误ID
                LS_ERR_MSG --返回错误信息  
                );
     return LD_PRICE;
  end;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-08-15
  *     创建者：xiongpl
          p_get_price  *   功能说明：取价后台接口方法(旧)
  */
  -------------------------------------------------------------------------------
  procedure P_GET_PRICE
  (
   P_ACC_ID       IN t_customer_account.account_id%type,  --账户ID
   P_ITEM_CODE      IN t_bd_item.item_code%type, --产品编码
   P_BILL_DATE    IN VARCHAR2,        --单据日期,YYYYMMDD
   P_PRICE_LIST_ID IN t_bd_price_list.price_list_id%type,--价格列表ID
   P_ENTITY_ID    IN up_org_unit.ENTITY_ID%type, --业务主体ID
   P_PRICE        out NUMBER, --返回价格
   P_DISCOUNT     out NUMBER, --返回折扣率
   P_MONTH_DISCOUNT      out NUMBER, --返回月返
   P_CX_FLAG      out VARCHAR2 --返回是否促销机   
   )
   is

    LS_PRICE_MODE varchar2(32);
    LD_PRICE     NUMBER;
    LD_DISCOUNT  NUMBER;
    LD_MONTH_DISCOUNT  NUMBER;
    LS_CX_FLAG  varchar2(2);
    
    LD_RETURN_SYSTEM_ID t_bd_price_system.price_system_id%type;
    LD_RETURN_LIST_ID  t_bd_price_list.price_list_id%type;
    LD_RESULT    NUMBER;
    LS_ERR_MSG   varchar2(2500);
    v_PLN_C2M_PRICE_PRIORITY varchar2(50); --定制机取价优先级
    v_C2m_Customized_Flag varchar2(2);  --是否定制机产品
    v_COMPE_ATTR     varchar2(32);
    V_COUNT          Number;

  begin
 
     -- BD_PRICE_MODE :(XSGS:销司多层级定价模式  JXS: 经销商模式)
     LS_PRICE_MODE :=pkg_bd.F_GET_PARAMETER_VALUE('BD_PRICE_MODE',P_ENTITY_ID,null,null);
     
     --获取定制机取价优先级
    v_PLN_C2M_PRICE_PRIORITY := Pkg_Bd.f_Get_Parameter_Value('PLN_C2M_PRICE_PRIORITY',
                                                           P_ENTITY_ID);
    --获取产品是否C2M定制产品
    Begin
      Select Count(1)
        Into V_COUNT
        From t_Bd_Item i
       Where i.Item_Code = P_ITEM_CODE
         And i.Entity_Id = P_ENTITY_ID
         And I.ITEM_CODE Like '71%';
      If V_COUNT > 0 Then
        v_C2m_Customized_Flag := 'Y';
      Else
        v_C2m_Customized_Flag := 'N';
      End If;
    Exception
      When Others Then
        v_C2m_Customized_Flag := 'N';
    End;
     if (LS_PRICE_MODE = 'XSGS') then  --家用
       --非定制机产品或者是定制机产品,且取价模式优先价格体系的，先取价格列表价格
      If v_C2m_Customized_Flag = 'N' Or (v_Pln_C2m_Price_Priority = 'PRICE' And
         v_C2m_Customized_Flag = 'Y') Then
         P_GET_PRICE_10(
             P_ENTITY_ID ,
             P_ACC_ID   , P_ITEM_CODE,
             P_BILL_DATE,P_PRICE_LIST_ID,
             LD_PRICE    , LD_DISCOUNT,
             LD_MONTH_DISCOUNT, LS_CX_FLAG,
             LD_RETURN_SYSTEM_ID,LD_RETURN_LIST_ID,LD_RESULT,LS_ERR_MSG );
       --定制机按价格体系取价，取不到，则在按选配项取价
        If v_C2m_Customized_Flag = 'Y'And LD_PRICE Is Null Then
          Pkg_Bd_Price.P_GET_PRICE_C2M(P_ACC_ID,
                       P_ITEM_CODE,
                       P_BILL_DATE,
                       P_PRICE_LIST_ID,
                       P_ENTITY_ID,
                       LD_PRICE,
                       LD_DISCOUNT,
                       LD_MONTH_DISCOUNT,
                       LS_CX_FLAG,
                       v_COMPE_ATTR);
        End If;
        --如果是定制机产品，取价优先级是取选配项价格，先取选配项价格
        Elsif v_Pln_C2m_Price_Priority = 'C2M' And v_C2m_Customized_Flag = 'Y' Then
          Pkg_Bd_Price.P_GET_PRICE_C2M(P_ACC_ID,
                         P_ITEM_CODE,
                         P_BILL_DATE,
                         P_PRICE_LIST_ID,
                         P_ENTITY_ID,
                         LD_PRICE,
                         LD_DISCOUNT,
                         LD_MONTH_DISCOUNT,
                         LS_CX_FLAG,
                         v_COMPE_ATTR);
          --按选配项取不到价格，则取价格体系价格
          --优先按选配价格取价的，取不到价后不找价格体系的价格列表价格 2020-5-6 lilh6
          /*If LD_PRICE Is Null Then
            P_GET_PRICE_10(
               P_ENTITY_ID ,
               P_ACC_ID   , P_ITEM_CODE,
               P_BILL_DATE,P_PRICE_LIST_ID,
               LD_PRICE    , LD_DISCOUNT,
               LD_MONTH_DISCOUNT, LS_CX_FLAG,
               LD_RETURN_SYSTEM_ID,LD_RETURN_LIST_ID,LD_RESULT,LS_ERR_MSG );
         End If;*/
       End If;
     end if;
     if (LS_PRICE_MODE = 'JXS') then  --厨电
       --非定制机产品或者是定制机产品,且取价模式优先价格体系的，先取价格列表价格
       If v_C2m_Customized_Flag = 'N' Or (v_Pln_C2m_Price_Priority = 'PRICE' And
         v_C2m_Customized_Flag = 'Y') Then
         P_GET_PRICE_14(
             P_ENTITY_ID ,
             P_ACC_ID   , P_ITEM_CODE,
             P_BILL_DATE,P_PRICE_LIST_ID,
             LD_PRICE    , LD_DISCOUNT,
             LD_MONTH_DISCOUNT, LS_CX_FLAG,
             LD_RETURN_SYSTEM_ID,LD_RETURN_LIST_ID,LD_RESULT,LS_ERR_MSG );
       --定制机按价格体系取价，取不到，则在按选配项取价
         If v_C2m_Customized_Flag = 'Y'And LD_PRICE Is Null Then
           Pkg_Bd_Price.P_GET_PRICE_C2M(P_ACC_ID,
                       P_ITEM_CODE,
                       P_BILL_DATE,
                       P_PRICE_LIST_ID,
                       P_ENTITY_ID,
                       LD_PRICE,
                       LD_DISCOUNT,
                       LD_MONTH_DISCOUNT,
                       LS_CX_FLAG,
                       v_COMPE_ATTR);
         End If;
        --如果是定制机产品，取价优先级是取选配项价格，先取选配项价格
       Elsif v_Pln_C2m_Price_Priority = 'C2M' And v_C2m_Customized_Flag = 'Y' Then
         Pkg_Bd_Price.P_GET_PRICE_C2M(P_ACC_ID,
                         P_ITEM_CODE,
                         P_BILL_DATE,
                         P_PRICE_LIST_ID,
                         P_ENTITY_ID,
                         LD_PRICE,
                         LD_DISCOUNT,
                         LD_MONTH_DISCOUNT,
                         LS_CX_FLAG,
                         v_COMPE_ATTR);
          --按选配项取不到价格，则取价格体系价格
          --优先按选配价格取价的，取不到价后不找价格体系的价格列表价格 2020-5-6 lilh6
         /*If LD_PRICE Is Null Then
            P_GET_PRICE_14(
               P_ENTITY_ID ,
               P_ACC_ID   , P_ITEM_CODE,
               P_BILL_DATE,P_PRICE_LIST_ID,
               LD_PRICE    , LD_DISCOUNT,
               LD_MONTH_DISCOUNT, LS_CX_FLAG,
               LD_RETURN_SYSTEM_ID,LD_RETURN_LIST_ID,LD_RESULT,LS_ERR_MSG );
         End If;*/
       End If;
     end if;
     
     P_PRICE := LD_PRICE; --返回价格
     P_DISCOUNT :=LD_DISCOUNT; --返回折扣率
     P_MONTH_DISCOUNT   :=LD_MONTH_DISCOUNT; --返回月返
     P_CX_FLAG          :=LS_CX_FLAG; --返回是否促销机

  end;

  /*取价过程,入口过程，优惠品(旧)*/
  procedure P_GET_PRICE_YH
  (
   P_ACC_ID       IN t_customer_account.account_id%type,  --账户ID
   P_ITEM_CODE      IN t_bd_item.item_code%type, --产品编码
   P_BILL_DATE    IN VARCHAR2,        --单据日期 YYYYMMDD
   P_PRICE_LIST_ID IN t_bd_price_list.price_list_id%type,--价格列表ID
   P_ENTITY_ID    IN up_org_unit.ENTITY_ID%type, --业务主体ID
   P_PRICE        out NUMBER, --返回价格
   P_DISCOUNT     out NUMBER, --返回折扣率
   P_MONTH_DISCOUNT      out NUMBER, --返回月返
   P_CX_FLAG      out VARCHAR2 --返回是否促销机     
   )   is

    LS_PRICE_MODE varchar2(32);
    LD_PRICE     NUMBER;
    LD_DISCOUNT  NUMBER;
    LD_MONTH_DISCOUNT  NUMBER;
    LS_CX_FLAG  varchar2(2);
    
    LD_RETURN_SYSTEM_ID t_bd_price_system.price_system_id%type;
    LD_RETURN_LIST_ID  t_bd_price_list.price_list_id%type;
    LD_RESULT    NUMBER;
    LS_ERR_MSG   varchar2(2500);    

  begin
     --优惠品
     -- BD_PRICE_MODE :(XSGS:销司多层级定价模式  JXS: 经销商模式)
     LS_PRICE_MODE :=pkg_bd.F_GET_PARAMETER_VALUE('BD_PRICE_MODE',P_ENTITY_ID,null,null);
     if (LS_PRICE_MODE = 'XSGS') then  --家用
       P_GET_PRICE_10_YH(
           P_ENTITY_ID ,
           P_ACC_ID   , P_ITEM_CODE,
           P_BILL_DATE,P_PRICE_LIST_ID,
           LD_PRICE    , LD_DISCOUNT,
           LD_MONTH_DISCOUNT, LS_CX_FLAG ,
           LD_RETURN_SYSTEM_ID,LD_RETURN_LIST_ID,LD_RESULT,LS_ERR_MSG );
     end if;
     if (LS_PRICE_MODE = 'JXS') then  --厨电
       P_GET_PRICE_14_YH(
           P_ENTITY_ID ,
           P_ACC_ID   , P_ITEM_CODE,
           P_BILL_DATE,P_PRICE_LIST_ID,
           LD_PRICE    , LD_DISCOUNT,
           LD_MONTH_DISCOUNT, LS_CX_FLAG,
           LD_RETURN_SYSTEM_ID,LD_RETURN_LIST_ID,LD_RESULT,LS_ERR_MSG );
     end if;

     P_PRICE := LD_PRICE; --返回价格
     P_DISCOUNT :=LD_DISCOUNT; --返回折扣率
     P_MONTH_DISCOUNT   :=LD_MONTH_DISCOUNT; --返回月返
     P_CX_FLAG          :=LS_CX_FLAG; --返回是否促销机   

  end;  
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-08-15
  *     创建者：xiongpl
          p_get_price  *   功能说明：取价后台接口方法（新）
  */
  -------------------------------------------------------------------------------
  procedure P_GET_PRICE_MAIN
  (
   P_ACC_ID       IN t_customer_account.account_id%type,  --账户ID
   P_ITEM_CODE      IN t_bd_item.item_code%type, --产品编码
   P_BILL_DATE    IN VARCHAR2,        --单据日期,YYYYMMDD
   P_PRICE_LIST_ID IN t_bd_price_list.price_list_id%type,--价格列表ID
   P_ENTITY_ID    IN up_org_unit.ENTITY_ID%type, --业务主体ID
   P_PRICE        out NUMBER, --返回价格
   P_DISCOUNT     out NUMBER, --返回折扣率
   P_MONTH_DISCOUNT      out NUMBER, --返回月返
   P_CX_FLAG      out VARCHAR2, --返回是否促销机
   P_RETURN_SYSTEM_ID   OUT t_bd_price_system.price_system_id%type, --返回价格体系ID
   P_RETURN_LIST_ID   OUT t_bd_price_list.price_list_id%type, --返回价格列表ID
   P_RESULT      OUT NUMBER, --返回错误ID
   P_ERR_MSG     OUT VARCHAR2 --返回错误信息      
   )
   is

    LS_PRICE_MODE varchar2(32);
    LD_PRICE     NUMBER;
    LD_DISCOUNT  NUMBER;
    LD_MONTH_DISCOUNT  NUMBER;
    LS_CX_FLAG  varchar2(2);
    VR_RETURN_LIST     T_BD_PRICE_LIST%ROWTYPE;
    v_PLN_C2M_PRICE_PRIORITY varchar2(50); --定制机取价优先级
    v_C2m_Customized_Flag varchar2(2);  --是否定制机产品
    v_COMPE_ATTR     varchar2(2000);
    V_COUNT          Number;

  begin
     --初始返回值
     P_RESULT  := 0;
     P_ERR_MSG := 'SUCCESS';   
     -- BD_PRICE_MODE :(XSGS:销司多层级定价模式  JXS: 经销商模式)
     LS_PRICE_MODE :=pkg_bd.F_GET_PARAMETER_VALUE('BD_PRICE_MODE',P_ENTITY_ID,null,null);

      --获取定制机取价优先级
    v_PLN_C2M_PRICE_PRIORITY := Pkg_Bd.f_Get_Parameter_Value('PLN_C2M_PRICE_PRIORITY',
                                                           P_ENTITY_ID);
    --获取产品是否C2M定制产品
    Begin
      Select Count(1)
        Into V_COUNT
        From t_Bd_Item i
       Where i.Item_Code = P_ITEM_CODE
         And i.Entity_Id = P_ENTITY_ID
         And I.ITEM_CODE Like '71%';
      If V_COUNT > 0 Then
        v_C2m_Customized_Flag := 'Y';
      Else
        v_C2m_Customized_Flag := 'N';
      End If;
    Exception
      When Others Then
        v_C2m_Customized_Flag := 'N';
    End;
     if (LS_PRICE_MODE = 'XSGS') then  --家用
       --非定制机产品或者是定制机产品,且取价模式优先价格体系的，先取价格列表价格
      If v_C2m_Customized_Flag = 'N' Or (v_Pln_C2m_Price_Priority = 'PRICE' And
         v_C2m_Customized_Flag = 'Y') Then
         P_GET_PRICE_10(
           P_ENTITY_ID ,
           P_ACC_ID   , P_ITEM_CODE,
           P_BILL_DATE,P_PRICE_LIST_ID,
           LD_PRICE    , LD_DISCOUNT,
           LD_MONTH_DISCOUNT, LS_CX_FLAG,
           P_RETURN_SYSTEM_ID,P_RETURN_LIST_ID,P_RESULT,P_ERR_MSG );
       --定制机按价格体系取价，取不到，则在按选配项取价
        If v_C2m_Customized_Flag = 'Y'And LD_PRICE Is Null Then
          Pkg_Bd_Price.P_GET_PRICE_C2M(P_ACC_ID,
                       P_ITEM_CODE,
                       P_BILL_DATE,
                       P_PRICE_LIST_ID,
                       P_ENTITY_ID,
                       LD_PRICE,
                       LD_DISCOUNT,
                       LD_MONTH_DISCOUNT,
                       LS_CX_FLAG,
                       v_COMPE_ATTR);
        End If;
        --如果是定制机产品，取价优先级是取选配项价格，先取选配项价格
        Elsif v_Pln_C2m_Price_Priority = 'C2M' And v_C2m_Customized_Flag = 'Y' Then
          Pkg_Bd_Price.P_GET_PRICE_C2M(P_ACC_ID,
                         P_ITEM_CODE,
                         P_BILL_DATE,
                         P_PRICE_LIST_ID,
                         P_ENTITY_ID,
                         LD_PRICE,
                         LD_DISCOUNT,
                         LD_MONTH_DISCOUNT,
                         LS_CX_FLAG,
                         v_COMPE_ATTR);
          --按选配项取不到价格，则取价格体系价格
          --优先按选配价格取价的，取不到价后不找价格体系的价格列表价格 2020-5-6 lilh6
          /*If LD_PRICE Is Null Then
            P_GET_PRICE_10(
           P_ENTITY_ID ,
           P_ACC_ID   , P_ITEM_CODE,
           P_BILL_DATE,P_PRICE_LIST_ID,
           LD_PRICE    , LD_DISCOUNT,
           LD_MONTH_DISCOUNT, LS_CX_FLAG,
           P_RETURN_SYSTEM_ID,P_RETURN_LIST_ID,P_RESULT,P_ERR_MSG );
         End If;*/
       End If;
     end if;
     if (LS_PRICE_MODE = 'JXS') then  --厨电
       --非定制机产品或者是定制机产品,且取价模式优先价格体系的，先取价格列表价格
       If v_C2m_Customized_Flag = 'N' Or (v_Pln_C2m_Price_Priority = 'PRICE' And
         v_C2m_Customized_Flag = 'Y') Then
         P_GET_PRICE_14(
           P_ENTITY_ID ,
           P_ACC_ID   , P_ITEM_CODE,
           P_BILL_DATE,P_PRICE_LIST_ID,
           LD_PRICE    , LD_DISCOUNT,
           LD_MONTH_DISCOUNT, LS_CX_FLAG,
           P_RETURN_SYSTEM_ID,P_RETURN_LIST_ID,P_RESULT,P_ERR_MSG );
       --定制机按价格体系取价，取不到，则在按选配项取价
         If v_C2m_Customized_Flag = 'Y'And LD_PRICE Is Null Then
           Pkg_Bd_Price.P_GET_PRICE_C2M(P_ACC_ID,
                       P_ITEM_CODE,
                       P_BILL_DATE,
                       P_PRICE_LIST_ID,
                       P_ENTITY_ID,
                       LD_PRICE,
                       LD_DISCOUNT,
                       LD_MONTH_DISCOUNT,
                       LS_CX_FLAG,
                       v_COMPE_ATTR);
         End If;
        --如果是定制机产品，取价优先级是取选配项价格，先取选配项价格
       Elsif v_Pln_C2m_Price_Priority = 'C2M' And v_C2m_Customized_Flag = 'Y' Then
         Pkg_Bd_Price.P_GET_PRICE_C2M(P_ACC_ID,
                         P_ITEM_CODE,
                         P_BILL_DATE,
                         P_PRICE_LIST_ID,
                         P_ENTITY_ID,
                         LD_PRICE,
                         LD_DISCOUNT,
                         LD_MONTH_DISCOUNT,
                         LS_CX_FLAG,
                         v_COMPE_ATTR);
          --按选配项取不到价格，则取价格体系价格
          --优先按选配价格取价的，取不到价后不找价格体系的价格列表价格 2020-5-6 lilh6
         /*If LD_PRICE Is Null Then
            P_GET_PRICE_14(
           P_ENTITY_ID ,
           P_ACC_ID   , P_ITEM_CODE,
           P_BILL_DATE,P_PRICE_LIST_ID,
           LD_PRICE    , LD_DISCOUNT,
           LD_MONTH_DISCOUNT, LS_CX_FLAG,
           P_RETURN_SYSTEM_ID,P_RETURN_LIST_ID,P_RESULT,P_ERR_MSG );
         End If;*/
       End If;
     end if;
     If v_C2m_Customized_Flag = 'Y' And LD_PRICE Is Not Null Then
       P_RESULT := 0;
       P_ERR_MSG := 'SUCCESS';
     Elsif v_C2m_Customized_Flag = 'Y' And LD_PRICE Is Null And v_COMPE_ATTR Is Not Null Then
       --定制机取价报错，抛出特定异常
       P_RESULT := -1;
       P_ERR_MSG := v_COMPE_ATTR;
       PKG_SO_PUB.P_EXCEPTION_THROWS(P_RESULT);
     End If;
     P_PRICE := LD_PRICE; --返回价格
     P_DISCOUNT :=LD_DISCOUNT; --返回折扣率
     P_MONTH_DISCOUNT   :=LD_MONTH_DISCOUNT; --返回月返
     P_CX_FLAG          :=LS_CX_FLAG; --返回是否促销机
     IF 0 < P_RETURN_LIST_ID AND 0 = P_RESULT AND 'SUCCESS' = P_ERR_MSG  THEN
       BEGIN
         SELECT * INTO VR_RETURN_LIST FROM T_BD_PRICE_LIST L WHERE L.PRICE_LIST_ID = P_RETURN_LIST_ID;
         IF 'Y' <> VR_RETURN_LIST.ACTIVE_FLAG THEN
           P_ERR_MSG := (P_ERR_MSG || ' 但' || VR_RETURN_LIST.LIST_NAME || '并非有效价格列表');
         END IF;
         IF 'Y' = VR_RETURN_LIST.CUST_FLAG THEN
           P_ERR_MSG := (P_ERR_MSG || ' 注意' || VR_RETURN_LIST.LIST_NAME || '是客户专用价格列表：' || VR_RETURN_LIST.CUSTOMER_CODE);
         END IF;
         IF TO_DATE(P_BILL_DATE,'YYYYMMDD') > VR_RETURN_LIST.END_DATE THEN
           P_ERR_MSG := (P_ERR_MSG || ' 注意' || VR_RETURN_LIST.LIST_NAME || '已经到期');
         END IF;
         IF TO_DATE(P_BILL_DATE,'YYYYMMDD') < VR_RETURN_LIST.BEGIN_DATE THEN
           P_ERR_MSG := (P_ERR_MSG || ' 注意' || VR_RETURN_LIST.LIST_NAME || '开始日期还没到');
         END IF;
       EXCEPTION WHEN OTHERS THEN
         NULL;
       END;
     END IF;
    --根据P_RESULT判断是否抛出异常
    PKG_SO_PUB.P_EXCEPTION_THROWS(P_RESULT);
    
  EXCEPTION
    WHEN PKG_SO_PUB.V_BIZ_EXCEPTION THEN
      P_RESULT  := -28000;
      P_ERR_MSG :=  '根据 主体ID[' || P_ENTITY_ID || '], 账户ID[' || P_ACC_ID || '],产品编码['||P_ITEM_CODE||
                    '],单据日期['||P_BILL_DATE||'] 成品取价出错：' || P_ERR_MSG;
    WHEN OTHERS THEN
      P_RESULT  := -28000;
      P_ERR_MSG :=  '根据 主体ID[' || P_ENTITY_ID || '], 账户ID[' || P_ACC_ID || '],产品编码['||P_ITEM_CODE||
                    '],单据日期['||P_BILL_DATE||'] 成品取价发生异常：' || P_ERR_MSG;

  end;

  /*取价过程,入口过程，优惠品（新）*/
  procedure P_GET_PRICE_YH_MAIN
  (
   P_ACC_ID       IN t_customer_account.account_id%type,  --账户ID
   P_ITEM_CODE      IN t_bd_item.item_code%type, --产品编码
   P_BILL_DATE    IN VARCHAR2,        --单据日期 YYYYMMDD
   P_PRICE_LIST_ID IN t_bd_price_list.price_list_id%type,--价格列表ID
   P_ENTITY_ID    IN up_org_unit.ENTITY_ID%type, --业务主体ID
   P_PRICE        out NUMBER, --返回价格
   P_DISCOUNT     out NUMBER, --返回折扣率
   P_MONTH_DISCOUNT      out NUMBER, --返回月返
   P_CX_FLAG      out VARCHAR2, --返回是否促销机
   P_RETURN_SYSTEM_ID   OUT t_bd_price_system.price_system_id%type, --返回价格体系ID
   P_RETURN_LIST_ID   OUT t_bd_price_list.price_list_id%type, --返回价格列表ID
   P_RESULT      OUT NUMBER, --返回错误ID
   P_ERR_MSG     OUT VARCHAR2 --返回错误信息       
   )   is

    LS_PRICE_MODE varchar2(32);
    LD_PRICE     NUMBER;
    LD_DISCOUNT  NUMBER;
    LD_MONTH_DISCOUNT  NUMBER;
    LS_CX_FLAG  varchar2(2);

  begin
     --优惠品
     --初始返回值
     P_RESULT  := 0;
     P_ERR_MSG := 'SUCCESS';       
     -- BD_PRICE_MODE :(XSGS:销司多层级定价模式  JXS: 经销商模式)
     LS_PRICE_MODE :=pkg_bd.F_GET_PARAMETER_VALUE('BD_PRICE_MODE',P_ENTITY_ID,null,null);
     if (LS_PRICE_MODE = 'XSGS') then  --家用
       P_GET_PRICE_10_YH(
           P_ENTITY_ID ,
           P_ACC_ID   , P_ITEM_CODE,
           P_BILL_DATE,P_PRICE_LIST_ID,
           LD_PRICE    , LD_DISCOUNT,
           LD_MONTH_DISCOUNT, LS_CX_FLAG ,
           P_RETURN_SYSTEM_ID,P_RETURN_LIST_ID,P_RESULT,P_ERR_MSG);
     end if;
     if (LS_PRICE_MODE = 'JXS') then  --厨电
       P_GET_PRICE_14_YH(
           P_ENTITY_ID ,
           P_ACC_ID   , P_ITEM_CODE,
           P_BILL_DATE,P_PRICE_LIST_ID,
           LD_PRICE    , LD_DISCOUNT,
           LD_MONTH_DISCOUNT, LS_CX_FLAG,
           P_RETURN_SYSTEM_ID,P_RETURN_LIST_ID,P_RESULT,P_ERR_MSG );
     end if;

     P_PRICE := LD_PRICE; --返回价格
     P_DISCOUNT :=LD_DISCOUNT; --返回折扣率
     P_MONTH_DISCOUNT   :=LD_MONTH_DISCOUNT; --返回月返
     P_CX_FLAG          :=LS_CX_FLAG; --返回是否促销机
    --根据P_RESULT判断是否抛出异常
    PKG_SO_PUB.P_EXCEPTION_THROWS(P_RESULT);
    
  EXCEPTION
    WHEN PKG_SO_PUB.V_BIZ_EXCEPTION THEN
      P_RESULT  := -28000;
      P_ERR_MSG :=  '根据 主体ID[' || P_ENTITY_ID || '], 账户ID[' || P_ACC_ID || '],产品编码['||P_ITEM_CODE||
                    '],单据日期['||P_BILL_DATE||'] 成品优惠品取价出错：' || P_ERR_MSG;
    WHEN OTHERS THEN
      P_RESULT  := -28000;
      P_ERR_MSG :=  '根据 主体ID[' || P_ENTITY_ID || '], 账户ID[' || P_ACC_ID || '],产品编码['||P_ITEM_CODE||
                    '],单据日期['||P_BILL_DATE||'] 成品优惠品取价发生异常：' || P_ERR_MSG;     

  end;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-08-15
  *     创建者：xiongpl
  *   功能说明：家用取价过程  ，正品

  注：
    结算金额 = SUM(数量 * 单价 * (1 -月返/100 - 折扣/100 ))
    折让金额 = SUM(数量 * 单价 * 折扣/100)
  */
  -------------------------------------------------------------------------------
  procedure P_GET_PRICE_10
  (
   P_ENTITY_ID    IN NUMBER,
   P_ACC_ID       IN t_customer_account.account_id%type,  --账户ID
   P_ITEM_CODE      IN t_bd_item.item_code%type,           --产品编码
   P_BILL_DATE    IN VARCHAR2,                         --单据日期
   P_PRICE_LIST_ID IN t_bd_price_list.price_list_id%type,--价格列表ID
   P_PRICE        out NUMBER,        --返回价格
   P_DISCOUNT     out NUMBER,        --返回折扣率
   P_MONTH_DISCOUNT      out NUMBER, --返回月返
   P_CX_FLAG      out VARCHAR2,       --返回是否促销机
   P_RETURN_SYSTEM_ID   OUT t_bd_price_system.price_system_id%type, --返回价格体系ID
   P_RETURN_LIST_ID   OUT t_bd_price_list.price_list_id%type, --返回价格列表ID
   P_RESULT      IN OUT NUMBER, --返回错误ID
   P_ERR_MSG     IN OUT VARCHAR2 --返回错误信息     
   )
   is
    LD_CUSR_ID t_customer_account.customer_id%type;
    LD_UNIT_ID up_org_unit.unit_id%type;
    LD_SYSTEM_ID t_bd_price_system.price_system_id%type;
    priceSystemCust t_bd_price_system_cust%ROWTYPE ;
    LD_PRICE_LIST_ID t_bd_price_list.price_list_id%type;
    LS_PRICE_TYPE   t_bd_price_system.price_type%type;  --价格体系类型，T推广物料，C成品

    priceSystemOrg t_bd_price_system_org%ROWTYPE ;
    priceSystem    t_bd_price_system%ROWTYPE ;
    LD_CUST_CNT number;
    LD_ORG_CNT number;
    LD_CNT number;

  begin

    if (P_PRICE_LIST_ID is not null) then
       --DBMS_OUTPUT.PUT_LINE('P_PRICE_LIST_ID: NULL');
    --1、如果价格列表不为空，则直接从价格列表上取价格,月返
       P_DISCOUNT := 0;
       P_CX_FLAG := 'N';
       --1.1 根据价格列表ID、产品ID，查找价格、月返率
       P_GET_PRICE_FROM_LIST_10(
          P_ENTITY_ID ,
          P_ITEM_CODE,
          P_BILL_DATE,
          P_PRICE_LIST_ID,
          P_PRICE,
          P_MONTH_DISCOUNT,
          P_CX_FLAG,
          P_RESULT,
          P_ERR_MSG
       );
       P_RETURN_LIST_ID := P_PRICE_LIST_ID;
    else
    --2、如果价格列表为空，则从价格体系上定位到具体价格列表，并从价格列表上取价格
      --2.1 根据账户ID、找对应的客户
       BEGIN
         select customer_id
           into LD_CUSR_ID
           from t_customer_account
          where account_id = P_ACC_ID
            and entity_id = P_ENTITY_ID;
         --and active_flag = 'Y';
       EXCEPTION
         WHEN NO_DATA_FOUND THEN
            P_ERR_MSG := '账户ID[' || P_ACC_ID || ']、主体[' || P_ENTITY_ID || '] 未获取到账户记录';
            RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
         WHEN OTHERS THEN
            P_ERR_MSG := '根据账户ID[' || P_ACC_ID ||']、主体[' || P_ENTITY_ID ||
                         ']获取账户信息发生异常：' || SQLERRM;
            RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
       END;     
      --2.2 根据账户ID、找对应的中心
       BEGIN
         select co.sales_center_id
           into LD_UNIT_ID
           from t_customer_acc_org_relation rl, t_customer_org co
          where rl.customer_org_id = co.customer_org_id
            and rl.account_id = P_ACC_ID
            and co.entity_id = P_ENTITY_ID;
         --and active_flag = 'Y';
       EXCEPTION
         WHEN NO_DATA_FOUND THEN
            P_ERR_MSG := '账户ID[' || P_ACC_ID || ']、主体[' || P_ENTITY_ID || '] 未获取到中心信息';
            RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
         WHEN OTHERS THEN
            P_ERR_MSG := '根据账户ID[' || P_ACC_ID ||']、主体[' || P_ENTITY_ID ||
                         ']获取中心信息发生异常：' || SQLERRM;
            RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
       END;        
       
       --判断产品是成品还是推广物料，用于取不同的价格体系
       BEGIN
         select decode(is_material,'Y','T','C') into LS_PRICE_TYPE from t_bd_item
            where item_code = P_ITEM_CODE and entity_id = P_ENTITY_ID;
       EXCEPTION
         WHEN NO_DATA_FOUND THEN
            P_ERR_MSG := '产品编码[' || P_ITEM_CODE || ']、主体[' || P_ENTITY_ID || '] 未获取到产品记录';
            RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
         WHEN OTHERS THEN
            P_ERR_MSG := '根据产品编码[' || P_ITEM_CODE ||']、主体[' || P_ENTITY_ID ||
                         ']获取产品记录发生异常：' || SQLERRM;
            RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
       END;           
      --2.3 根据单据日期找到对应的价格体系，并找到对应的价格列表ID、折扣率
       BEGIN
         select price_system_id
           into LD_SYSTEM_ID
           from t_bd_price_system ps
          where P_BILL_DATE >= to_char(ps.begin_date, 'YYYYMMDD')
            and P_BILL_DATE <= to_char(nvl(ps.end_date,to_date(P_BILL_DATE,'YYYYMMDD')+1), 'YYYYMMDD')
            and ps.entity_id = P_ENTITY_ID
            and ps.price_type = LS_PRICE_TYPE
            and ps.active_flag = 'Y';
          P_RETURN_SYSTEM_ID := LD_SYSTEM_ID;
       EXCEPTION
         WHEN NO_DATA_FOUND THEN
            P_ERR_MSG := '价格类型[' || LS_PRICE_TYPE || ']、日期[' || P_BILL_DATE || '] 未获取到价格体系记录';
            RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
         WHEN OTHERS THEN
            P_ERR_MSG := '根据价格类型[' || LS_PRICE_TYPE ||']、日期[' || P_BILL_DATE ||
                         ']获取价格体系发生异常：' || SQLERRM;
            RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
       END;            

       select count(1) into LD_CUST_CNT
         from t_bd_price_system_cust sc
        where sc.price_system_id = LD_SYSTEM_ID
          and sc.sales_center_id = LD_UNIT_ID
          and sc.customer_id = LD_CUSR_ID
          and sc.active_flag = 'Y';
       --2.4判断是否找到客户关联价格列表
       if (LD_CUST_CNT>0) then            
         BEGIN
           select sc.*
             into priceSystemCust
             from t_bd_price_system_cust sc
            where sc.price_system_id = LD_SYSTEM_ID
              and sc.sales_center_id = LD_UNIT_ID
              and sc.customer_id = LD_CUSR_ID
              and sc.active_flag = 'Y';
           P_DISCOUNT := nvl(priceSystemCust.Discount,0); --20150424 为空返回0
           LD_PRICE_LIST_ID := priceSystemCust.Price_List_Id;     
           P_RETURN_LIST_ID := priceSystemCust.Price_List_Id;    
                    
         EXCEPTION
           WHEN NO_DATA_FOUND THEN
              P_ERR_MSG := '价格体系[' || LD_SYSTEM_ID || ']、中心[' || LD_UNIT_ID || '],客户['||LD_CUSR_ID||'] 未获取到价格列表';
              RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
           WHEN OTHERS THEN
              P_ERR_MSG := '价格体系[' || LD_SYSTEM_ID || ']、中心[' || LD_UNIT_ID || '],客户['||LD_CUSR_ID||
                        '] 获取价格列表发生异常：' || SQLERRM;
              RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
         END;              

       else
       --2.5 如果没找到客户价格，则取对应中心价格列表
         select count(1) into LD_ORG_CNT
           from t_bd_price_system_org so
          where so.price_system_id = LD_SYSTEM_ID
            and so.sales_center_id = LD_UNIT_ID
            and so.active_flag = 'Y';
         if (LD_ORG_CNT>0) then
           
           BEGIN
             select so.*
               into priceSystemOrg
               from t_bd_price_system_org so
              where so.price_system_id = LD_SYSTEM_ID
                and so.sales_center_id = LD_UNIT_ID
                and so.active_flag = 'Y';

             P_DISCOUNT := nvl(priceSystemOrg.Discount,0);--20150424 为空返回0
             LD_PRICE_LIST_ID := priceSystemOrg.Price_List_Id; 
             P_RETURN_LIST_ID := priceSystemOrg.Price_List_Id;              
                      
           EXCEPTION
             WHEN NO_DATA_FOUND THEN
                P_ERR_MSG := '价格体系[' || LD_SYSTEM_ID || ']、中心[' || LD_UNIT_ID ||'] 未获取到中心价格列表';
                RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
             WHEN OTHERS THEN
                P_ERR_MSG := '价格体系[' || LD_SYSTEM_ID || ']、中心[' || LD_UNIT_ID ||'] 获取中心价格列表发生异常：' || SQLERRM;
                RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
           END;            
           
         else
         --2.6 如果没找到中心价格列表，则取总部默认价格列表

           BEGIN
             select ps.*
               into priceSystem
               from t_bd_price_system ps
              where ps.price_system_id = LD_SYSTEM_ID
                and ps.active_flag = 'Y';

             P_DISCOUNT := 0;
             LD_PRICE_LIST_ID := priceSystem.bu_price_list_id;
             P_RETURN_LIST_ID := priceSystem.bu_price_list_id;   
             --DBMS_OUTPUT.PUT_LINE('总部P_PRICE_LIST_ID: '||LD_PRICE_LIST_ID);
                      
           EXCEPTION
             WHEN NO_DATA_FOUND THEN
                P_ERR_MSG := '价格体系[' || LD_SYSTEM_ID || '] 未获取到总部价格列表';
                RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
             WHEN OTHERS THEN
                P_ERR_MSG := '价格体系[' || LD_SYSTEM_ID || '] 获取总部价格列表发生异常：' || SQLERRM;
                RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
           END;             
           
         end if;

       end if;

       P_CX_FLAG := 'N'; --是否促销机
      --2.4 根据价格列表ID、产品ID，查找价格、月返率
       P_GET_PRICE_FROM_LIST_10(
          P_ENTITY_ID ,
          P_ITEM_CODE,
          P_BILL_DATE,
          LD_PRICE_LIST_ID,
          P_PRICE,
          P_MONTH_DISCOUNT,
          P_CX_FLAG,
          P_RESULT,
          P_ERR_MSG
       );
    end if;
    
    --根据P_RESULT判断是否抛出异常
    PKG_SO_PUB.P_EXCEPTION_THROWS(P_RESULT);   
  EXCEPTION
    WHEN PKG_SO_PUB.V_BIZ_EXCEPTION THEN
      P_RESULT  := -28000;
      P_ERR_MSG :=  '销司模式取价出错：' || substr(dbms_utility.format_error_backtrace,
                                                   1,
                                                   100) || P_ERR_MSG;
    WHEN OTHERS THEN
      P_RESULT  := -28000;
      P_ERR_MSG :=  '销司模式取价发生异常：' || substr(dbms_utility.format_error_backtrace,
                                                   1,
                                                   100) || P_ERR_MSG;
  end;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-08-15
  *     创建者：xiongpl
  *   功能说明：家用取价过程  ，优惠品

  注：
    结算金额 = SUM(数量 * 单价 * (1 -月返/100 - 折扣/100 ))
    折让金额 = SUM(数量 * 单价 * 折扣/100)
  */
  -------------------------------------------------------------------------------
  procedure P_GET_PRICE_10_YH
  (
   P_ENTITY_ID    IN NUMBER,
   P_ACC_ID       IN t_customer_account.account_id%type,  --账户ID
   P_ITEM_CODE      IN t_bd_item.item_code%type,           --产品编码
   P_BILL_DATE    IN VARCHAR2,                         --单据日期
   P_PRICE_LIST_ID IN t_bd_price_list.price_list_id%type,--价格列表ID
   P_PRICE        out NUMBER,        --返回价格
   P_DISCOUNT     out NUMBER,        --返回折扣率
   P_MONTH_DISCOUNT      out NUMBER, --返回月返
   P_CX_FLAG      out VARCHAR2,       --返回是否促销机
   P_RETURN_SYSTEM_ID   OUT t_bd_price_system.price_system_id%type, --返回价格体系ID
   P_RETURN_LIST_ID   OUT t_bd_price_list.price_list_id%type, --返回价格列表ID
   P_RESULT      IN OUT NUMBER, --返回错误ID
   P_ERR_MSG     IN OUT VARCHAR2 --返回错误信息      
   )
   is
    LD_CUSR_ID t_customer_account.customer_id%type;
    LD_UNIT_ID up_org_unit.unit_id%type;
    LD_SYSTEM_ID t_bd_price_system.price_system_id%type;
    LS_PRICE_TYPE   t_bd_price_system.price_type%type;  --价格体系类型，T推广物料，C成品

    priceSystemCust t_bd_price_system_cust%ROWTYPE ;
    LD_PRICE_LIST_ID t_bd_price_list.price_list_id%type;

    priceSystemOrg t_bd_price_system_org%ROWTYPE ;
    priceSystem    t_bd_price_system%ROWTYPE ;
    LD_CUST_CNT number;
    LD_ORG_CNT number;
    LD_CNT number;

  begin

    if (P_PRICE_LIST_ID is not null) then
       --DBMS_OUTPUT.PUT_LINE('P_PRICE_LIST_ID: NULL');
    --1、如果价格列表不为空，则直接从价格列表上取价格,月返
       P_DISCOUNT := 0;
       P_CX_FLAG := 'N';
       --1.1 根据价格列表ID、产品ID，查找价格、月返率
       P_GET_PRICE_FROM_LIST_10(
          P_ENTITY_ID ,
          P_ITEM_CODE,
          P_BILL_DATE,
          P_PRICE_LIST_ID,
          P_PRICE,
          P_MONTH_DISCOUNT,
          P_CX_FLAG,
          P_RESULT,
          P_ERR_MSG      
       );
       P_RETURN_LIST_ID := P_PRICE_LIST_ID;       
    else
    --2、如果价格列表为空，则从价格体系上定位到具体价格列表，并从价格列表上取价格
      --2.1 根据账户ID、找对应的客户
       BEGIN
         select customer_id
           into LD_CUSR_ID
           from t_customer_account
          where account_id = P_ACC_ID
            and entity_id = P_ENTITY_ID;
         --and active_flag = 'Y';
       EXCEPTION
         WHEN NO_DATA_FOUND THEN
            P_ERR_MSG := '账户ID[' || P_ACC_ID || ']、主体[' || P_ENTITY_ID || '] 未获取到账户记录';
            RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
         WHEN OTHERS THEN
            P_ERR_MSG := '根据账户ID[' || P_ACC_ID ||']、主体[' || P_ENTITY_ID ||
                         ']获取账户信息发生异常：' || SQLERRM;
            RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
       END;        
       
      --2.2 根据账户ID、找对应的中心
       BEGIN
         select co.sales_center_id
           into LD_UNIT_ID
           from t_customer_acc_org_relation rl, t_customer_org co
          where rl.customer_org_id = co.customer_org_id
            and rl.account_id = P_ACC_ID
            and co.entity_id = P_ENTITY_ID;
         --and active_flag = 'Y';
       EXCEPTION
         WHEN NO_DATA_FOUND THEN
            P_ERR_MSG := '账户ID[' || P_ACC_ID || ']、主体[' || P_ENTITY_ID || '] 未获取到中心信息';
            RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
         WHEN OTHERS THEN
            P_ERR_MSG := '根据账户ID[' || P_ACC_ID ||']、主体[' || P_ENTITY_ID ||
                         ']获取中心信息发生异常：' || SQLERRM;
            RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
       END;         
       
       --判断产品是成品还是推广物料，用于取不同的价格体系
       BEGIN
         select decode(is_material,'Y','T','C') into LS_PRICE_TYPE from t_bd_item
            where item_code = P_ITEM_CODE and entity_id = P_ENTITY_ID;
       EXCEPTION
         WHEN NO_DATA_FOUND THEN
            P_ERR_MSG := '产品编码[' || P_ITEM_CODE || ']、主体[' || P_ENTITY_ID || '] 未获取到产品记录';
            RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
         WHEN OTHERS THEN
            P_ERR_MSG := '根据产品编码[' || P_ITEM_CODE ||']、主体[' || P_ENTITY_ID ||
                         ']获取产品记录发生异常：' || SQLERRM;
            RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
       END;           
      --2.3 根据单据日期找到对应的价格体系，并找到对应的价格列表ID、折扣率
       BEGIN
         select price_system_id
           into LD_SYSTEM_ID
           from t_bd_price_system ps
          where P_BILL_DATE >= to_char(ps.begin_date, 'YYYYMMDD')
            and P_BILL_DATE <= to_char(nvl(ps.end_date,to_date(P_BILL_DATE,'YYYYMMDD')+1), 'YYYYMMDD')
            and ps.entity_id = P_ENTITY_ID
            and ps.price_type = LS_PRICE_TYPE
            and ps.active_flag = 'Y';
         P_RETURN_SYSTEM_ID := LD_SYSTEM_ID;
       EXCEPTION
         WHEN NO_DATA_FOUND THEN
            P_ERR_MSG := '价格类型[' || LS_PRICE_TYPE || ']、日期[' || P_BILL_DATE || '] 未获取到价格体系记录';
            RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
         WHEN OTHERS THEN
            P_ERR_MSG := '根据价格类型[' || LS_PRICE_TYPE ||']、日期[' || P_BILL_DATE ||
                         ']获取价格体系发生异常：' || SQLERRM;
            RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
       END;            

       select count(1) into LD_CUST_CNT
         from t_bd_price_system_cust sc
        where sc.price_system_id = LD_SYSTEM_ID
          and sc.sales_center_id = LD_UNIT_ID
          and sc.customer_id = LD_CUSR_ID
          and sc.sub_price_list_id is not null   --优惠品新增判断
          and sc.active_flag = 'Y';
       --2.4判断是否找到客户关联价格列表
       if (LD_CUST_CNT>0) then
         BEGIN
           select sc.*
             into priceSystemCust
             from t_bd_price_system_cust sc
            where sc.price_system_id = LD_SYSTEM_ID
              and sc.sales_center_id = LD_UNIT_ID
              and sc.customer_id = LD_CUSR_ID
              and sc.sub_price_list_id is not null   --优惠品新增判断
              and sc.active_flag = 'Y';

           P_DISCOUNT := nvl(priceSystemCust.Sub_Discount,0);           --优惠品折扣 --20150424 为空返回0
           LD_PRICE_LIST_ID := priceSystemCust.Sub_Price_List_Id;  --优惠品列表ID 
           P_RETURN_LIST_ID := priceSystemCust.Sub_Price_List_Id;
                    
         EXCEPTION
           WHEN NO_DATA_FOUND THEN
              P_ERR_MSG := '价格体系[' || LD_SYSTEM_ID || ']、中心[' || LD_UNIT_ID || '],客户['||LD_CUSR_ID||'] 未获取到价格列表';
              RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
           WHEN OTHERS THEN
              P_ERR_MSG := '价格体系[' || LD_SYSTEM_ID || ']、中心[' || LD_UNIT_ID || '],客户['||LD_CUSR_ID||
                        '] 获取价格列表发生异常：' || SQLERRM;
              RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
         END;          
         
       else
       --2.5 如果没找到客户价格，则取对应中心价格列表
         select count(1) into LD_ORG_CNT
           from t_bd_price_system_org so
          where so.price_system_id = LD_SYSTEM_ID
            and so.sales_center_id = LD_UNIT_ID
            and so.sub_price_list_id is not null   --优惠品新增判断
            and so.active_flag = 'Y';
         if (LD_ORG_CNT>0) then

           BEGIN
             select so.*
               into priceSystemOrg
               from t_bd_price_system_org so
              where so.price_system_id = LD_SYSTEM_ID
                and so.sales_center_id = LD_UNIT_ID
                and so.sub_price_list_id is not null   --优惠品新增判断
                and so.active_flag = 'Y';

             P_DISCOUNT := nvl(priceSystemOrg.Sub_Discount,0);    --优惠品折扣 --20150424 为空返回0
             LD_PRICE_LIST_ID := priceSystemOrg.Sub_Price_List_Id; --优惠品列表ID
             P_RETURN_LIST_ID := priceSystemOrg.Sub_Price_List_Id;
                      
           EXCEPTION
             WHEN NO_DATA_FOUND THEN
                P_ERR_MSG := '价格体系[' || LD_SYSTEM_ID || ']、中心[' || LD_UNIT_ID ||'] 未获取到中心价格列表';
                RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
             WHEN OTHERS THEN
                P_ERR_MSG := '价格体系[' || LD_SYSTEM_ID || ']、中心[' || LD_UNIT_ID ||'] 获取中心价格列表发生异常：' || SQLERRM;
                RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
           END;             
           
         else
         --2.6 如果没找到中心价格列表，则返回

           P_PRICE  := null;
           P_DISCOUNT := 0;
           P_MONTH_DISCOUNT   := 0;
           P_CX_FLAG := 'N';
           return;
           --2.6 如果没找到中心价格列表，则取总部默认价格列表
           BEGIN
             select ps.*
               into priceSystem
               from t_bd_price_system ps
              where ps.price_system_id = LD_SYSTEM_ID
                and ps.active_flag = 'Y';

             P_DISCOUNT := 0;
             LD_PRICE_LIST_ID := priceSystem.bu_price_list_id;
             P_RETURN_LIST_ID := priceSystem.bu_price_list_id;
             --DBMS_OUTPUT.PUT_LINE('总部P_PRICE_LIST_ID: '||LD_PRICE_LIST_ID);
                      
           EXCEPTION
             WHEN NO_DATA_FOUND THEN
                P_ERR_MSG := '价格体系[' || LD_SYSTEM_ID || '] 未获取到总部价格列表';
                RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
             WHEN OTHERS THEN
                P_ERR_MSG := '价格体系[' || LD_SYSTEM_ID || '] 获取总部价格列表发生异常：' || SQLERRM;
                RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
           END;            
           
         end if;

       end if;

       P_CX_FLAG := 'N'; --是否促销机
      --2.4 根据价格列表ID、产品ID，查找价格、月返率
       P_GET_PRICE_FROM_LIST_10(
          P_ENTITY_ID ,
          P_ITEM_CODE,
          P_BILL_DATE,
          LD_PRICE_LIST_ID,
          P_PRICE,
          P_MONTH_DISCOUNT,
          P_CX_FLAG,
          P_RESULT,
          P_ERR_MSG
       );
    end if;

    --根据P_RESULT判断是否抛出异常
    PKG_SO_PUB.P_EXCEPTION_THROWS(P_RESULT);   
  EXCEPTION
    WHEN PKG_SO_PUB.V_BIZ_EXCEPTION THEN
      P_RESULT  := -28000;
      P_ERR_MSG :=  '销司模式取价出错：' || substr(dbms_utility.format_error_backtrace,
                                                   1,
                                                   100) || P_ERR_MSG;
    WHEN OTHERS THEN
      P_RESULT  := -28000;
      P_ERR_MSG :=  '销司模式取价发生异常：' || substr(dbms_utility.format_error_backtrace,
                                                   1,
                                                   100) || P_ERR_MSG;
  end;
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-08-15
  *     创建者：xiongpl
  *   功能说明：厨电取价过程 ,正品

  注：
    结算金额 = SUM(数量 * 单价 * (1 -月返/100 - 折扣/100 ))
    折让金额 = SUM(数量 * 单价 * 折扣/100)
  */
  -------------------------------------------------------------------------------
  procedure P_GET_PRICE_14
  (
   P_ENTITY_ID    IN NUMBER,
   P_ACC_ID       IN t_customer_account.account_id%type,  --账户ID
   P_ITEM_CODE      IN t_bd_item.item_code%type,           --产品编码
   P_BILL_DATE    IN VARCHAR2,                         --单据日期
   P_PRICE_LIST_ID IN t_bd_price_list.price_list_id%type,--价格列表ID
   P_PRICE        out NUMBER,        --返回价格
   P_DISCOUNT     out NUMBER,        --返回折扣率
   P_MONTH_DISCOUNT      out NUMBER, --返回月返
   P_CX_FLAG      out VARCHAR2,       --返回是否促销机
   P_RETURN_SYSTEM_ID   OUT t_bd_price_system.price_system_id%type, --返回价格体系ID
   P_RETURN_LIST_ID   OUT t_bd_price_list.price_list_id%type, --返回价格列表ID
   P_RESULT      IN OUT NUMBER, --返回错误ID
   P_ERR_MSG     IN OUT VARCHAR2 --返回错误信息     
   )
   is
    LD_CNT number;
    LD_CUST_CNT number;
    LD_ORG_CNT number;

    LD_CUSR_ID t_customer_account.customer_id%type;
    LD_UNIT_ID up_org_unit.unit_id%type;
    LD_SYSTEM_ID t_bd_price_system.price_system_id%type;
    LS_PRICE_TYPE   t_bd_price_system.price_type%type;  --价格体系类型，T推广物料，C成品

    priceSystemCust t_bd_price_system_cust%ROWTYPE ;
    priceSystemOrg t_bd_price_system_org%ROWTYPE ;
    priceSystem    t_bd_price_system%ROWTYPE ;
    LD_PRICE_LIST_ID t_bd_price_list.price_list_id%type;

    LS_CUSR_TYPE t_bd_price_cust_config.price_type%type;
    LS_IS_MATERIAL t_bd_item.is_material%type;

  begin
    LS_CUSR_TYPE := null;
    IF P_ACC_ID is not null then
      --1 根据账户ID、找对应的客户
       BEGIN
         select customer_id
           into LD_CUSR_ID
           from t_customer_account
          where account_id = P_ACC_ID
            and entity_id = P_ENTITY_ID;
         --and active_flag = 'Y';
       EXCEPTION
         WHEN NO_DATA_FOUND THEN
            P_ERR_MSG := '账户ID[' || P_ACC_ID || ']、主体[' || P_ENTITY_ID || '] 未获取到账户记录';
            RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
         WHEN OTHERS THEN
            P_ERR_MSG := '根据账户ID[' || P_ACC_ID ||']、主体[' || P_ENTITY_ID ||
                         ']获取账户信息发生异常：' || SQLERRM;
            RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
       END;           
       --2 根据账户ID、找对应的中心         
       BEGIN
         select co.sales_center_id
           into LD_UNIT_ID
           from t_customer_acc_org_relation rl, t_customer_org co
          where rl.customer_org_id = co.customer_org_id
            and rl.account_id = P_ACC_ID
            and co.entity_id = P_ENTITY_ID;
         --and active_flag = 'Y';
       EXCEPTION
         WHEN NO_DATA_FOUND THEN
            P_ERR_MSG := '账户ID[' || P_ACC_ID || ']、主体[' || P_ENTITY_ID || '] 未获取到中心信息';
            RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
         WHEN OTHERS THEN
            P_ERR_MSG := '根据账户ID[' || P_ACC_ID ||']、主体[' || P_ENTITY_ID ||
                         ']获取中心信息发生异常：' || SQLERRM;
            RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
       END;           
       --3、找客户中心对应的取价类型（客户渠道类型）  EBUSINESS:电商客户,  PROJECT:工程客户,OEM:OEM客户,  COMMON:常规客户,CARRIER:承运商客户
         /*select p.price_type
           into LS_CUSR_TYPE
           from t_bd_price_cust_config p
          where p.customer_id = LD_CUSR_ID
            and p.sales_center_id = LD_UNIT_ID
            and p.active_flag='Y';      */
        --Engineering 工程客户；WholesaleChannels 渠道客户；E-Commerce  电商客户；CommonChannelsofRetail  零售客户
       BEGIN
          select (select t.industry_type
            from t_customer_channel_type t
           where t.customer_id = LD_CUSR_ID
             and t.entity_id = P_ENTITY_ID
             and t.active_flag = 'Active') into LS_CUSR_TYPE FROM DUAL;
       EXCEPTION
         WHEN NO_DATA_FOUND THEN
            P_ERR_MSG := '客户ID[' || LD_CUSR_ID || ']、主体[' || P_ENTITY_ID || '] 未获取到客户业态类型';
            RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
         WHEN OTHERS THEN
            P_ERR_MSG := '根据客户ID[' || LD_CUSR_ID ||']、主体[' || P_ENTITY_ID ||
                         ']获取客户业态类型发生异常：' || SQLERRM;
            RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
       END;            
           
    end if;
    if (P_PRICE_LIST_ID is not null) then
    --4、如果价格列表不为空，则直接从价格列表上取价格,月返率
       P_DISCOUNT := 0;
       --4.1 根据价格列表ID、产品ID，查找价格、月返率
       P_GET_PRICE_FROM_LIST_14(
          P_ENTITY_ID ,
          P_ITEM_CODE,
          P_BILL_DATE,
          LS_CUSR_TYPE,
          P_PRICE_LIST_ID,
          P_PRICE,
          P_MONTH_DISCOUNT,
          P_CX_FLAG,
          P_RESULT,
          P_ERR_MSG
       );
       P_RETURN_LIST_ID := P_PRICE_LIST_ID;       
    else
    --5、如果价格列表为空，则从价格类型对应的价格体系上定位到具体价格列表，并从价格列表上取价格
      --5.1 根据单据日期找到对应的价格体系，并找到对应的价格列表ID、折扣率
      /* select price_system_id
         into LD_SYSTEM_ID
         from t_bd_price_type pt
        where P_BILL_DATE >= to_char(pt.begin_date, 'YYYYMMDD')
          and P_BILL_DATE <= to_char(pt.end_date, 'YYYYMMDD')
          and pt.entity_id = P_ENTITY_ID
          and pt.price_type = LS_CUSR_TYPE
          and pt.active_flag = 'Y';

       select bu_price_list_id
         into LD_PRICE_LIST_ID
         from t_bd_price_system ps
        where ps.price_system_id=LD_SYSTEM_ID;      */

      --调整为： 如果价格列表为空，则从价格列表中取客户专用价格列表，如果没取到，则进一步取价格体系
      --判断推广物料时，不走客户专用取价  --产品表：W物料、N产品 、Y推广物料  --价格列表：Y成品   N成品优惠品  T推广物料

       BEGIN
        select decode(is_material, 'Y', 'T', 'Y')
          into LS_IS_MATERIAL
          from t_bd_item bi
         where bi.item_code = P_ITEM_CODE
           and bi.entity_id = P_ENTITY_ID;
       EXCEPTION
         WHEN NO_DATA_FOUND THEN
            P_ERR_MSG := '产品编码[' || P_ITEM_CODE || ']、主体[' || P_ENTITY_ID || '] 未获取到产品记录';
            RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
         WHEN OTHERS THEN
            P_ERR_MSG := '根据产品编码[' || P_ITEM_CODE ||']、主体[' || P_ENTITY_ID ||
                         ']获取产品记录发生异常：' || SQLERRM;
            RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
       END;           

      select count(1)
        into LD_CNT
        from t_bd_price_list pl
       where P_BILL_DATE >= to_char(pl.begin_date, 'YYYYMMDD')
         and P_BILL_DATE <=
             to_char(nvl(pl.end_date, to_date(P_BILL_DATE, 'YYYYMMDD') + 1),
                     'YYYYMMDD')
         and pl.entity_id = P_ENTITY_ID
         and pl.cust_flag = 'Y'
         and pl.customer_id = LD_CUSR_ID
         and pl.qualtity_flag = LS_IS_MATERIAL --正品 或 推广物料
         and pl.active_flag = 'Y';
      if (LD_CNT = 1) then
        select pl.price_list_id
          into LD_PRICE_LIST_ID
          from t_bd_price_list pl
         where P_BILL_DATE >= to_char(pl.begin_date, 'YYYYMMDD')
           and P_BILL_DATE <= to_char(nvl(pl.end_date,
                                          to_date(P_BILL_DATE, 'YYYYMMDD') + 1),
                                      'YYYYMMDD')
           and pl.entity_id = P_ENTITY_ID
           and pl.cust_flag = 'Y'
           and pl.customer_id = LD_CUSR_ID
           and pl.qualtity_flag = LS_IS_MATERIAL  --正品 或 推广物料
           and pl.active_flag = 'Y';
         P_DISCOUNT := 0;
         P_RETURN_LIST_ID := LD_PRICE_LIST_ID;       
       else
--
         --判断产品是成品还是推广物料，用于取不同的价格体系
         BEGIN
           select decode(is_material,'Y','T','C') into LS_PRICE_TYPE from t_bd_item
              where item_code = P_ITEM_CODE and entity_id = P_ENTITY_ID;
         EXCEPTION
           WHEN NO_DATA_FOUND THEN
              P_ERR_MSG := '产品编码[' || P_ITEM_CODE || ']、主体[' || P_ENTITY_ID || '] 未获取到产品记录';
              RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
           WHEN OTHERS THEN
              P_ERR_MSG := '根据产品编码[' || P_ITEM_CODE ||']、主体[' || P_ENTITY_ID ||
                           ']获取产品记录发生异常：' || SQLERRM;
              RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
         END;              
        --5.3 根据单据日期找到对应的价格体系，并找到对应的价格列表ID、折扣率
         BEGIN
           select price_system_id
             into LD_SYSTEM_ID
             from t_bd_price_system ps
            where P_BILL_DATE >= to_char(ps.begin_date, 'YYYYMMDD')
              and P_BILL_DATE <= to_char(nvl(ps.end_date,to_date(P_BILL_DATE,'YYYYMMDD')+1), 'YYYYMMDD')
              and ps.entity_id = P_ENTITY_ID
              and ps.price_type = LS_PRICE_TYPE
              and ps.active_flag = 'Y';
           P_RETURN_SYSTEM_ID := LD_SYSTEM_ID;
         EXCEPTION
           WHEN NO_DATA_FOUND THEN
              P_ERR_MSG := '价格类型[' || LS_PRICE_TYPE || ']、日期[' || P_BILL_DATE || '] 未获取到价格体系记录';
              RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
           WHEN OTHERS THEN
              P_ERR_MSG := '根据价格类型[' || LS_PRICE_TYPE ||']、日期[' || P_BILL_DATE ||
                           ']获取价格体系发生异常：' || SQLERRM;
              RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
         END;  
            
         select count(1) into LD_CUST_CNT
           from t_bd_price_system_cust sc
          where sc.price_system_id = LD_SYSTEM_ID
            and sc.sales_center_id = LD_UNIT_ID
            and sc.customer_id = LD_CUSR_ID
            and sc.active_flag = 'Y';
         --5.4判断是否找到客户关联价格列表
         if (LD_CUST_CNT>0) then
           BEGIN
             select sc.*
               into priceSystemCust
               from t_bd_price_system_cust sc
              where sc.price_system_id = LD_SYSTEM_ID
                and sc.sales_center_id = LD_UNIT_ID
                and sc.customer_id = LD_CUSR_ID
                and sc.active_flag = 'Y';

             P_DISCOUNT := nvl(priceSystemCust.Discount,0); --20150424 为空返回0
             LD_PRICE_LIST_ID := priceSystemCust.Price_List_Id;   
             P_RETURN_LIST_ID := priceSystemCust.Price_List_Id;   
                      
           EXCEPTION
             WHEN NO_DATA_FOUND THEN
                P_ERR_MSG := '价格体系[' || LD_SYSTEM_ID || ']、中心[' || LD_UNIT_ID || '],客户['||LD_CUSR_ID||'] 未获取到价格列表';
                RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
             WHEN OTHERS THEN
                P_ERR_MSG := '价格体系[' || LD_SYSTEM_ID || ']、中心[' || LD_UNIT_ID || '],客户['||LD_CUSR_ID||
                          '] 获取价格列表发生异常：' || SQLERRM;
                RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
           END;
           
         else
         --5.5 如果没找到客户价格，则取对应中心价格列表
           select count(1) into LD_ORG_CNT
             from t_bd_price_system_org so
            where so.price_system_id = LD_SYSTEM_ID
              and so.sales_center_id = LD_UNIT_ID
              and so.active_flag = 'Y';
           if (LD_ORG_CNT>0) then
             BEGIN
               select so.*
                 into priceSystemOrg
                 from t_bd_price_system_org so
                where so.price_system_id = LD_SYSTEM_ID
                  and so.sales_center_id = LD_UNIT_ID
                  and so.active_flag = 'Y';

               P_DISCOUNT := nvl(priceSystemOrg.Discount,0);--20150424 为空返回0
               LD_PRICE_LIST_ID := priceSystemOrg.Price_List_Id;
               P_RETURN_LIST_ID := priceSystemOrg.Price_List_Id;                 
                        
             EXCEPTION
               WHEN NO_DATA_FOUND THEN
                  P_ERR_MSG := '价格体系[' || LD_SYSTEM_ID || ']、中心[' || LD_UNIT_ID ||'] 未获取到中心价格列表';
                  RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
               WHEN OTHERS THEN
                  P_ERR_MSG := '价格体系[' || LD_SYSTEM_ID || ']、中心[' || LD_UNIT_ID ||'] 获取中心价格列表发生异常：' || SQLERRM;
                  RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
             END; 
             
           else
           --5.6 如果没找到中心价格列表，则取总部默认价格列表             
             BEGIN
               select ps.*
                 into priceSystem
                 from t_bd_price_system ps
                where ps.price_system_id = LD_SYSTEM_ID
                  and ps.active_flag = 'Y';

               P_DISCOUNT := 0;
               LD_PRICE_LIST_ID := priceSystem.bu_price_list_id;
               P_RETURN_LIST_ID := priceSystem.bu_price_list_id;
               --DBMS_OUTPUT.PUT_LINE('总部P_PRICE_LIST_ID: '||LD_PRICE_LIST_ID);
                        
             EXCEPTION
               WHEN NO_DATA_FOUND THEN
                  P_ERR_MSG := '价格体系[' || LD_SYSTEM_ID || '] 未获取到总部价格列表';
                  RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
               WHEN OTHERS THEN
                  P_ERR_MSG := '价格体系[' || LD_SYSTEM_ID || '] 获取总部价格列表发生异常：' || SQLERRM;
                  RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
             END;              
             
           end if;
         end if;
--
       end if;

      --5.7 根据价格列表ID、产品ID，查找价格、月返率
       P_GET_PRICE_FROM_LIST_14(
          P_ENTITY_ID ,
          P_ITEM_CODE,
          P_BILL_DATE,
          LS_CUSR_TYPE,
          LD_PRICE_LIST_ID,
          P_PRICE,
          P_MONTH_DISCOUNT,
          P_CX_FLAG,
          P_RESULT,
          P_ERR_MSG
       );
    end if;

    --根据P_RESULT判断是否抛出异常
    PKG_SO_PUB.P_EXCEPTION_THROWS(P_RESULT);   
  EXCEPTION
    WHEN PKG_SO_PUB.V_BIZ_EXCEPTION THEN
      P_RESULT  := -28000;
      P_ERR_MSG :=  '经销商模式取价出错：' || substr(dbms_utility.format_error_backtrace,
                                                   1,
                                                   100) || P_ERR_MSG;
    WHEN OTHERS THEN
      P_RESULT  := -28000;
      P_ERR_MSG :=  '经销商模式取价发生异常：' || substr(dbms_utility.format_error_backtrace,
                                                   1,
                                                   100) || P_ERR_MSG;    
  end;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-08-15
  *     创建者：xiongpl
  *   功能说明：厨电取价过程 ,优惠品

  注：
    结算金额 = SUM(数量 * 单价 * (1 -月返/100 - 折扣/100 ))
    折让金额 = SUM(数量 * 单价 * 折扣/100)
  */
  -------------------------------------------------------------------------------
  procedure P_GET_PRICE_14_YH
  (
   P_ENTITY_ID    IN NUMBER,
   P_ACC_ID       IN t_customer_account.account_id%type,  --账户ID
   P_ITEM_CODE      IN t_bd_item.item_code%type,           --产品编码
   P_BILL_DATE    IN VARCHAR2,                         --单据日期
   P_PRICE_LIST_ID IN t_bd_price_list.price_list_id%type,--价格列表ID
   P_PRICE        out NUMBER,        --返回价格
   P_DISCOUNT     out NUMBER,        --返回折扣率
   P_MONTH_DISCOUNT      out NUMBER, --返回月返
   P_CX_FLAG      out VARCHAR2,       --返回是否促销机
   P_RETURN_SYSTEM_ID   OUT t_bd_price_system.price_system_id%type, --返回价格体系ID
   P_RETURN_LIST_ID   OUT t_bd_price_list.price_list_id%type, --返回价格列表ID
   P_RESULT      IN OUT NUMBER, --返回错误ID
   P_ERR_MSG     IN OUT VARCHAR2 --返回错误信息     
   )
   is
    LD_CNT number;
    LD_CUST_CNT number;
    LD_ORG_CNT number;

    LD_CUSR_ID t_customer_account.customer_id%type;
    LD_UNIT_ID up_org_unit.unit_id%type;
    LD_SYSTEM_ID t_bd_price_system.price_system_id%type;
    LS_PRICE_TYPE   t_bd_price_system.price_type%type;  --价格体系类型，T推广物料，C成品

    priceSystemCust t_bd_price_system_cust%ROWTYPE ;
    priceSystemOrg t_bd_price_system_org%ROWTYPE ;
    priceSystem    t_bd_price_system%ROWTYPE ;
    LD_PRICE_LIST_ID t_bd_price_list.price_list_id%type;

    LS_CUSR_TYPE t_bd_price_cust_config.price_type%type;

  begin

    --1 根据账户ID、找对应的客户      
     BEGIN
       select customer_id
         into LD_CUSR_ID
         from t_customer_account
        where account_id = P_ACC_ID
          and entity_id = P_ENTITY_ID;
       --and active_flag = 'Y';
     EXCEPTION
       WHEN NO_DATA_FOUND THEN
          P_ERR_MSG := '账户ID[' || P_ACC_ID || ']、主体[' || P_ENTITY_ID || '] 未获取到账户记录';
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
       WHEN OTHERS THEN
          P_ERR_MSG := '根据账户ID[' || P_ACC_ID ||']、主体[' || P_ENTITY_ID ||
                       ']获取账户信息发生异常：' || SQLERRM;
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
     END;         
       
     --2 根据账户ID、找对应的中心
     BEGIN
       select co.sales_center_id
         into LD_UNIT_ID
         from t_customer_acc_org_relation rl, t_customer_org co
        where rl.customer_org_id = co.customer_org_id
          and rl.account_id = P_ACC_ID
          and co.entity_id = P_ENTITY_ID;
       --and active_flag = 'Y';
     EXCEPTION
       WHEN NO_DATA_FOUND THEN
          P_ERR_MSG := '账户ID[' || P_ACC_ID || ']、主体[' || P_ENTITY_ID || '] 未获取到中心信息';
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
       WHEN OTHERS THEN
          P_ERR_MSG := '根据账户ID[' || P_ACC_ID ||']、主体[' || P_ENTITY_ID ||
                       ']获取中心信息发生异常：' || SQLERRM;
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
     END;         
       
     --3、找客户中心对应的取价类型（客户渠道类型）  EBUSINESS:电商客户,  PROJECT:工程客户,OEM:OEM客户,  COMMON:常规客户,CARRIER:承运商客户
       /*select p.price_type
         into LS_CUSR_TYPE
         from t_bd_price_cust_config p
        where p.customer_id = LD_CUSR_ID
          and p.sales_center_id = LD_UNIT_ID
          and p.active_flag='Y';      */
      --Engineering 工程客户；WholesaleChannels 渠道客户；E-Commerce  电商客户；CommonChannelsofRetail  零售客户
     BEGIN
        SELECT (select t.industry_type
          from t_customer_channel_type t
         where t.customer_id = LD_CUSR_ID
           and t.entity_id = P_ENTITY_ID
           and t.active_flag = 'Active') into LS_CUSR_TYPE FROM DUAL;
     EXCEPTION
       WHEN NO_DATA_FOUND THEN
          P_ERR_MSG := '客户ID[' || LD_CUSR_ID || ']、主体[' || P_ENTITY_ID || '] 未获取到客户业态类型';
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
       WHEN OTHERS THEN
          P_ERR_MSG := '根据客户ID[' || LD_CUSR_ID ||']、主体[' || P_ENTITY_ID ||
                       ']获取客户业态类型发生异常：' || SQLERRM;
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
     END;           

    if (P_PRICE_LIST_ID is not null) then
    --4、如果价格列表不为空，则直接从价格列表上取价格,月返率
       P_DISCOUNT := 0;
       --4.1 根据价格列表ID、产品ID，查找价格、月返率
       P_GET_PRICE_FROM_LIST_14(
          P_ENTITY_ID ,
          P_ITEM_CODE,
          P_BILL_DATE,
          LS_CUSR_TYPE,
          P_PRICE_LIST_ID,
          P_PRICE,
          P_MONTH_DISCOUNT,
          P_CX_FLAG,
          P_RESULT,
          P_ERR_MSG          
       );
      P_RETURN_LIST_ID := P_PRICE_LIST_ID;
    else
    --5、如果价格列表为空，则从价格类型对应的价格体系上定位到具体价格列表，并从价格列表上取价格
      --5.1 根据单据日期找到对应的价格体系，并找到对应的价格列表ID、折扣率
      /* select price_system_id
         into LD_SYSTEM_ID
         from t_bd_price_type pt
        where P_BILL_DATE >= to_char(pt.begin_date, 'YYYYMMDD')
          and P_BILL_DATE <= to_char(pt.end_date, 'YYYYMMDD')
          and pt.entity_id = P_ENTITY_ID
          and pt.price_type = LS_CUSR_TYPE
          and pt.active_flag = 'Y';

       select bu_price_list_id
         into LD_PRICE_LIST_ID
         from t_bd_price_system ps
        where ps.price_system_id=LD_SYSTEM_ID;      */

      --调整为： 如果价格列表为空，则从价格列表中取客户专用价格列表，如果没取到，则进一步取价格体系
       select count(1)
         into LD_CNT
         from t_bd_price_list pl
        where P_BILL_DATE >= to_char(pl.begin_date, 'YYYYMMDD')
          and P_BILL_DATE <= to_char(nvl(pl.end_date,to_date(P_BILL_DATE,'YYYYMMDD')+1), 'YYYYMMDD')
          and pl.entity_id = P_ENTITY_ID
          and pl.cust_flag='Y'
          and pl.customer_id = LD_CUSR_ID
          and nvl(pl.qualtity_flag,'Y') = 'N'  --优惠品
          and pl.active_flag = 'Y';
       if (LD_CNT = 1) then
         select pl.price_list_id
           into LD_PRICE_LIST_ID
           from t_bd_price_list pl
          where P_BILL_DATE >= to_char(pl.begin_date, 'YYYYMMDD')
            and P_BILL_DATE <= to_char(nvl(pl.end_date,to_date(P_BILL_DATE,'YYYYMMDD')+1), 'YYYYMMDD')
            and pl.entity_id = P_ENTITY_ID
            and pl.cust_flag='Y'
            and pl.customer_id = LD_CUSR_ID
            and nvl(pl.qualtity_flag,'Y') = 'N'   --优惠品
            and pl.active_flag = 'Y';
         P_DISCOUNT := 0;
         P_RETURN_LIST_ID := LD_PRICE_LIST_ID;
       else
--
         --判断产品是成品还是推广物料，用于取不同的价格体系
         BEGIN
           select decode(is_material,'Y','T','C') into LS_PRICE_TYPE from t_bd_item
              where item_code = P_ITEM_CODE and entity_id = P_ENTITY_ID;
         EXCEPTION
           WHEN NO_DATA_FOUND THEN
              P_ERR_MSG := '产品编码[' || P_ITEM_CODE || ']、主体[' || P_ENTITY_ID || '] 未获取到产品记录';
              RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
           WHEN OTHERS THEN
              P_ERR_MSG := '根据产品编码[' || P_ITEM_CODE ||']、主体[' || P_ENTITY_ID ||
                           ']获取产品记录发生异常：' || SQLERRM;
              RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
         END;             
        --5.3 根据单据日期找到对应的价格体系，并找到对应的价格列表ID、折扣率            
         BEGIN
           select price_system_id
             into LD_SYSTEM_ID
             from t_bd_price_system ps
            where P_BILL_DATE >= to_char(ps.begin_date, 'YYYYMMDD')
              and P_BILL_DATE <= to_char(nvl(ps.end_date,to_date(P_BILL_DATE,'YYYYMMDD')+1), 'YYYYMMDD')
              and ps.entity_id = P_ENTITY_ID
              and ps.price_type = LS_PRICE_TYPE
              and ps.active_flag = 'Y';
           P_RETURN_SYSTEM_ID := LD_SYSTEM_ID;
         EXCEPTION
           WHEN NO_DATA_FOUND THEN
              P_ERR_MSG := '价格类型[' || LS_PRICE_TYPE || ']、日期[' || P_BILL_DATE || '] 未获取到价格体系记录';
              RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
           WHEN OTHERS THEN
              P_ERR_MSG := '根据价格类型[' || LS_PRICE_TYPE ||']、日期[' || P_BILL_DATE ||
                           ']获取价格体系发生异常：' || SQLERRM;
              RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
         END;              

         select count(1) into LD_CUST_CNT
           from t_bd_price_system_cust sc
          where sc.price_system_id = LD_SYSTEM_ID
            and sc.sales_center_id = LD_UNIT_ID
            and sc.customer_id = LD_CUSR_ID
            and sc.sub_price_list_id is not null   --优惠品新增判断
            and sc.active_flag = 'Y';
         --5.4判断是否找到客户关联价格列表
         if (LD_CUST_CNT>0) then
           BEGIN
             select sc.*
               into priceSystemCust
               from t_bd_price_system_cust sc
              where sc.price_system_id = LD_SYSTEM_ID
                and sc.sales_center_id = LD_UNIT_ID
                and sc.customer_id = LD_CUSR_ID
                and sc.sub_price_list_id is not null   --优惠品新增判断
                and sc.active_flag = 'Y';

             P_DISCOUNT := nvl(priceSystemCust.Sub_Discount,0);      --优惠品折扣 --20150424 为空返回0
             LD_PRICE_LIST_ID := priceSystemCust.Sub_Price_List_Id;  --优惠品列表 
             P_RETURN_LIST_ID := priceSystemCust.Sub_Price_List_Id;
                      
           EXCEPTION
             WHEN NO_DATA_FOUND THEN
                P_ERR_MSG := '价格体系[' || LD_SYSTEM_ID || ']、中心[' || LD_UNIT_ID || '],客户['||LD_CUSR_ID||'] 未获取到价格列表';
                RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
             WHEN OTHERS THEN
                P_ERR_MSG := '价格体系[' || LD_SYSTEM_ID || ']、中心[' || LD_UNIT_ID || '],客户['||LD_CUSR_ID||
                          '] 获取价格列表发生异常：' || SQLERRM;
                RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
           END;              
           
         else
         --5.5 如果没找到客户价格，则取对应中心价格列表
           select count(1) into LD_ORG_CNT
             from t_bd_price_system_org so
            where so.price_system_id = LD_SYSTEM_ID
              and so.sales_center_id = LD_UNIT_ID
              and so.sub_price_list_id is not null   --优惠品新增判断
              and so.active_flag = 'Y';
           if (LD_ORG_CNT>0) then             
             BEGIN
               select so.*
                 into priceSystemOrg
                 from t_bd_price_system_org so
                where so.price_system_id = LD_SYSTEM_ID
                  and so.sales_center_id = LD_UNIT_ID
                  and so.sub_price_list_id is not null   --优惠品新增判断
                  and so.active_flag = 'Y';

               P_DISCOUNT := nvl(priceSystemOrg.Sub_Discount,0);--20150424 为空返回0
               LD_PRICE_LIST_ID := priceSystemOrg.Sub_Price_List_Id;
               P_RETURN_LIST_ID := priceSystemOrg.Sub_Price_List_Id;
                        
             EXCEPTION
               WHEN NO_DATA_FOUND THEN
                  P_ERR_MSG := '价格体系[' || LD_SYSTEM_ID || ']、中心[' || LD_UNIT_ID ||'] 未获取到中心价格列表';
                  RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
               WHEN OTHERS THEN
                  P_ERR_MSG := '价格体系[' || LD_SYSTEM_ID || ']、中心[' || LD_UNIT_ID ||'] 获取中心价格列表发生异常：' || SQLERRM;
                  RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
             END;              
             
           else
           --5.6 如果没找到中心价格列表，则取总部默认价格列表
             BEGIN
               select ps.*
                 into priceSystem
                 from t_bd_price_system ps
                where ps.price_system_id = LD_SYSTEM_ID
                  and ps.active_flag = 'Y';

               P_DISCOUNT := 0;
               LD_PRICE_LIST_ID := priceSystem.bu_price_list_id;
               P_RETURN_LIST_ID := priceSystem.bu_price_list_id;
               --DBMS_OUTPUT.PUT_LINE('总部P_PRICE_LIST_ID: '||LD_PRICE_LIST_ID);
                        
             EXCEPTION
               WHEN NO_DATA_FOUND THEN
                  P_ERR_MSG := '价格体系[' || LD_SYSTEM_ID || '] 未获取到总部价格列表';
                  RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
               WHEN OTHERS THEN
                  P_ERR_MSG := '价格体系[' || LD_SYSTEM_ID || '] 获取总部价格列表发生异常：' || SQLERRM;
                  RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
             END;              
             
           end if;
         end if;
--
       end if;

      --5.7 根据价格列表ID、产品ID，查找价格、月返率
       P_GET_PRICE_FROM_LIST_14(
          P_ENTITY_ID ,
          P_ITEM_CODE,
          P_BILL_DATE,
          LS_CUSR_TYPE,
          LD_PRICE_LIST_ID,
          P_PRICE,
          P_MONTH_DISCOUNT,
          P_CX_FLAG,
          P_RESULT,
          P_ERR_MSG
       );
    end if;

    --根据P_RESULT判断是否抛出异常
    PKG_SO_PUB.P_EXCEPTION_THROWS(P_RESULT);   
  EXCEPTION
    WHEN PKG_SO_PUB.V_BIZ_EXCEPTION THEN
      P_RESULT  := -28000;
      P_ERR_MSG :=  '经销商模式取价出错：' || substr(dbms_utility.format_error_backtrace,
                                                   1,
                                                   100) || P_ERR_MSG;
    WHEN OTHERS THEN
      P_RESULT  := -28000;
      P_ERR_MSG :=  '经销商模式取价发生异常：' || substr(dbms_utility.format_error_backtrace,
                                                   1,
                                                   100) || P_ERR_MSG;        
  end;

  /*家用主体，根据价格列表进行取价*/
  procedure P_GET_PRICE_FROM_LIST_10
  (
   P_ENTITY_ID    IN NUMBER,
   P_ITEM_CODE      IN t_bd_item.item_code%type, --产品编码
   P_BILL_DATE     IN VARCHAR2,        --单据日期
   P_PRICE_LIST_ID IN t_bd_price_list.price_list_id%type,--价格列表ID
   P_PRICE        out NUMBER, --返回价格
   P_MONTH_DISCOUNT      out NUMBER, --返回月返
   P_CX_FLAG      out VARCHAR2, --返回是否促销机
   P_RESULT      IN OUT NUMBER, --返回错误ID
   P_ERR_MSG     IN OUT VARCHAR2 --返回错误信息      
   )
   is
    --LD_MONTH_DISCOUNT t_bd_price_line.discount%type;

  begin
     --DBMS_OUTPUT.PUT_LINE('P_PRICE_LIST_ID:'||P_PRICE_LIST_ID);
     select pl.list_price,nvl(pl.discount,0) discount
            into P_PRICE,P_MONTH_DISCOUNT
        from t_bd_price_line pl
        where pl.price_list_id = P_PRICE_LIST_ID
          and pl.item_code = P_ITEM_CODE
          and P_BILL_DATE >= to_char(nvl(pl.begin_date,to_date(P_BILL_DATE,'YYYYMMDD')-1), 'YYYYMMDD')
          and P_BILL_DATE <= to_char(nvl(pl.end_date,to_date(P_BILL_DATE,'YYYYMMDD')+1), 'YYYYMMDD')
          and 'Y' = pl.active_flag
          --and rownum = 1
          ;
     P_CX_FLAG := 'N';

  exception
    when NO_DATA_FOUND then
       P_PRICE  := null;
       P_MONTH_DISCOUNT   := 0;
       P_CX_FLAG := 'N';
       P_RESULT  := -28000;
       --P_ERR_MSG :=  '根据价格列表ID['||P_PRICE_LIST_ID||']未获取到记录：'|| SQLERRM;
       PKG_BD_PRICE.P_G_PRICE_DESC_FROM_LIST_10(P_ENTITY_ID => P_ENTITY_ID,P_ITEM_CODE => P_ITEM_CODE
       ,P_BILL_DATE => TO_DATE(P_BILL_DATE,'YYYYMMDD'),P_PRICE_LIST_ID => P_PRICE_LIST_ID,P_DESC => P_ERR_MSG);         
    WHEN OTHERS THEN
       P_PRICE  := null;
       P_MONTH_DISCOUNT   := 0;
       P_CX_FLAG := 'N';    
       P_RESULT  := -28000;
       --P_ERR_MSG :=   '根据价格列表ID['||P_PRICE_LIST_ID||']取价时发生异常：'|| SQLERRM;  
       PKG_BD_PRICE.P_G_PRICE_DESC_FROM_LIST_10(P_ENTITY_ID => P_ENTITY_ID,P_ITEM_CODE => P_ITEM_CODE
       ,P_BILL_DATE => TO_DATE(P_BILL_DATE,'YYYYMMDD'),P_PRICE_LIST_ID => P_PRICE_LIST_ID,P_DESC => P_ERR_MSG);          
  end;

  /*厨电主体，根据价格列表进行取价
  --产品竞争属性  COMMON:常规机  PROMOTION:促销机
  */
  procedure P_GET_PRICE_FROM_LIST_14
  (
   P_ENTITY_ID    IN NUMBER,
   P_ITEM_CODE      IN t_bd_item.item_code%type, --产品编码
   P_BILL_DATE     IN VARCHAR2,        --单据日期
   P_CUSR_TYPE    IN t_bd_price_type.price_type%type, --取价类型
   P_PRICE_LIST_ID IN t_bd_price_list.price_list_id%type,--价格列表ID
   P_PRICE        out NUMBER, --返回价格
   P_MONTH_DISCOUNT      out NUMBER, --返回月返
   P_CX_FLAG      out VARCHAR2, --返回是否促销机
   P_RESULT      IN OUT NUMBER, --返回错误ID
   P_ERR_MSG     IN OUT VARCHAR2 --返回错误信息      
   )
   is
    LS_COMPET_ATTR t_bd_price_line.competite_attr%type;  --产品竞争属性

  begin
    if P_CUSR_TYPE is not null then
        begin
         select pl.list_price,nvl(pl.discount,0) discount ,pl.competite_attr
                into P_PRICE,P_MONTH_DISCOUNT, LS_COMPET_ATTR
            from t_bd_price_line pl
            where pl.price_list_id = P_PRICE_LIST_ID
              and pl.item_code = P_ITEM_CODE
              and pl.channel_attr = P_CUSR_TYPE
              and P_BILL_DATE >= to_char(nvl(pl.begin_date,to_date(P_BILL_DATE,'YYYYMMDD')-1), 'YYYYMMDD')
              and P_BILL_DATE <= to_char(nvl(pl.end_date,to_date(P_BILL_DATE,'YYYYMMDD')+1), 'YYYYMMDD')
              and 'Y' = pl.active_flag
              --and rownum = 1
              ;
        exception
          when NO_DATA_FOUND then
           select pl.list_price,nvl(pl.discount,0) discount ,pl.competite_attr
                  into P_PRICE,P_MONTH_DISCOUNT, LS_COMPET_ATTR
              from t_bd_price_line pl
              where pl.price_list_id = P_PRICE_LIST_ID
                and pl.item_code = P_ITEM_CODE
                and pl.channel_attr is null
                and P_BILL_DATE >= to_char(nvl(pl.begin_date,to_date(P_BILL_DATE,'YYYYMMDD')-1), 'YYYYMMDD')
                and P_BILL_DATE <= to_char(nvl(pl.end_date,to_date(P_BILL_DATE,'YYYYMMDD')+1), 'YYYYMMDD')
                and 'Y' = pl.active_flag
                --and rownum = 1
                ;
        end;

     else
       select pl.list_price,nvl(pl.discount,0) discount ,pl.competite_attr
              into P_PRICE,P_MONTH_DISCOUNT, LS_COMPET_ATTR
          from t_bd_price_line pl
          where pl.price_list_id = P_PRICE_LIST_ID
            and pl.item_code = P_ITEM_CODE
            and pl.channel_attr is null
            and P_BILL_DATE >= to_char(nvl(pl.begin_date,to_date(P_BILL_DATE,'YYYYMMDD')-1), 'YYYYMMDD')
            and P_BILL_DATE <= to_char(nvl(pl.end_date,to_date(P_BILL_DATE,'YYYYMMDD')+1), 'YYYYMMDD')
            and 'Y' = pl.active_flag
            --and rownum = 1
            ;
     end if;
     if (LS_COMPET_ATTR = 'PROMOTION') then  --促销机
        P_CX_FLAG := 'Y';
     else
        P_CX_FLAG := 'N';
     end if;

  exception
    when NO_DATA_FOUND then
       P_PRICE  := null;
       P_MONTH_DISCOUNT   := 0;
       P_CX_FLAG := 'N';
       P_RESULT  := -28000;
       --P_ERR_MSG :=  '根据价格列表ID['||P_PRICE_LIST_ID||']未获取到记录：'|| SQLERRM;  
       PKG_BD_PRICE.P_G_PRICE_DESC_FROM_LIST_14(P_ENTITY_ID => P_ENTITY_ID,P_ITEM_CODE => P_ITEM_CODE
       ,P_BILL_DATE => TO_DATE(P_BILL_DATE,'YYYYMMDD'),P_CUSR_TYPE => P_CUSR_TYPE,P_PRICE_LIST_ID => P_PRICE_LIST_ID,P_DESC => P_ERR_MSG);         
    WHEN OTHERS THEN
       P_PRICE  := null;
       P_MONTH_DISCOUNT   := 0;
       P_CX_FLAG := 'N';    
       P_RESULT  := -28000;
       --P_ERR_MSG :=   '根据价格列表ID['||P_PRICE_LIST_ID||']取价时发生异常：'|| SQLERRM;  
       PKG_BD_PRICE.P_G_PRICE_DESC_FROM_LIST_14(P_ENTITY_ID => P_ENTITY_ID,P_ITEM_CODE => P_ITEM_CODE
       ,P_BILL_DATE => TO_DATE(P_BILL_DATE,'YYYYMMDD'),P_CUSR_TYPE => P_CUSR_TYPE,P_PRICE_LIST_ID => P_PRICE_LIST_ID,P_DESC => P_ERR_MSG);                 
  end;

  -----------------------------------------------------------------------------
  --  取价格列表ID           --
  -----------------------------------------------------------------------------
  PROCEDURE P_GET_PRICE_LIST_ID
  (
   P_ENTITY_ID    IN NUMBER,
   P_ACC_ID       IN t_customer_account.account_id%type,  --账户ID
   P_BILL_DATE    IN VARCHAR2,                         --单据日期
   P_PRICE_LIST_ID OUT NUMBER,--价格列表ID
   P_MESSAGE      out VARCHAR2       --返回是否促销机
   )
   is
    LD_CUSR_ID t_customer_account.customer_id%type;
    LD_UNIT_ID up_org_unit.unit_id%type;
    LD_SYSTEM_ID t_bd_price_system.price_system_id%type;
    priceSystemCust t_bd_price_system_cust%ROWTYPE ;
    LD_PRICE_LIST_ID t_bd_price_list.price_list_id%type;

    priceSystemOrg t_bd_price_system_org%ROWTYPE ;
    priceSystem    t_bd_price_system%ROWTYPE ;
    LD_CUST_CNT number;
    LD_ORG_CNT number;
    LD_CNT number;

  begin
    P_MESSAGE := 'OK';

    if (P_PRICE_LIST_ID is null) then
    --2、如果价格列表为空，则从价格体系上定位到具体价格列表，并从价格列表上取价格
      --2.1 根据账户ID、找对应的客户
       select customer_id
         into LD_CUSR_ID
         from t_customer_account
        where account_id = P_ACC_ID
          and entity_id = P_ENTITY_ID;
      --2.2 根据账户ID、找对应的中心
       select co.sales_center_id
         into LD_UNIT_ID
         from t_customer_acc_org_relation rl, t_customer_org co
        where rl.customer_org_id = co.customer_org_id
          and rl.account_id = P_ACC_ID
          and co.entity_id = P_ENTITY_ID;
       --and active_flag = 'Y';
      --2.3 根据单据日期找到对应的价格体系，并找到对应的价格列表ID、折扣率
       select price_system_id
         into LD_SYSTEM_ID
         from t_bd_price_system ps
        where P_BILL_DATE >= to_char(ps.begin_date, 'YYYYMMDD')
          and P_BILL_DATE <= to_char(nvl(ps.end_date,to_date(P_BILL_DATE,'YYYYMMDD')+1), 'YYYYMMDD')
          and ps.entity_id = P_ENTITY_ID
          and ps.active_flag = 'Y';

       select count(1) into LD_CUST_CNT
         from t_bd_price_system_cust sc
        where sc.price_system_id = LD_SYSTEM_ID
          and sc.sales_center_id = LD_UNIT_ID
          and sc.customer_id = LD_CUSR_ID
          and sc.active_flag = 'Y';
       --2.4判断是否找到客户关联价格列表
       if (LD_CUST_CNT>0) then
         select sc.*
           into priceSystemCust
           from t_bd_price_system_cust sc
          where sc.price_system_id = LD_SYSTEM_ID
            and sc.sales_center_id = LD_UNIT_ID
            and sc.customer_id = LD_CUSR_ID
            and sc.active_flag = 'Y';

         --P_DISCOUNT := priceSystemCust.Discount;
         LD_PRICE_LIST_ID := priceSystemCust.Price_List_Id;
       else
       --2.5 如果没找到客户价格，则取对应中心价格列表
         select count(1) into LD_ORG_CNT
           from t_bd_price_system_org so
          where so.price_system_id = LD_SYSTEM_ID
            and so.sales_center_id = LD_UNIT_ID
            and so.active_flag = 'Y';
         if (LD_ORG_CNT>0) then
           select so.*
             into priceSystemOrg
             from t_bd_price_system_org so
            where so.price_system_id = LD_SYSTEM_ID
              and so.sales_center_id = LD_UNIT_ID
              and so.active_flag = 'Y';

           --P_DISCOUNT := priceSystemOrg.Discount;
           LD_PRICE_LIST_ID := priceSystemOrg.Price_List_Id;
         else
         --2.6 如果没找到中心价格列表，则取总部默认价格列表
           select ps.*
             into priceSystem
             from t_bd_price_system ps
            where ps.price_system_id = LD_SYSTEM_ID
              and ps.active_flag = 'Y';

           --P_DISCOUNT := 0;
           LD_PRICE_LIST_ID := priceSystem.bu_price_list_id;

           --DBMS_OUTPUT.PUT_LINE('总部P_PRICE_LIST_ID: '||LD_PRICE_LIST_ID);
         END IF;

       END IF;
       P_PRICE_LIST_ID := LD_PRICE_LIST_ID;
    END IF;

  END P_GET_PRICE_LIST_ID;

  -----------------------------------------------------------------------------
  --  取价格列表ID   根据中心        --add by wangcong   update by lixiuhan 20151107
  -----------------------------------------------------------------------------
  PROCEDURE P_GET_PRICE_LIST_ID_CENTER(P_ENTITY_ID         IN NUMBER,
                                       P_SALES_CENTER_CODE IN T_BD_PRICE_SYSTEM_ORG.SALES_CENTER_CODE%TYPE, --中心CODE
                                       P_BILL_DATE         IN VARCHAR2, --单据日期
                                       P_ITEM_CODE         IN T_BD_PRICE_LINE.ITEM_CODE%TYPE, --产品编码
                                       P_PRICE             OUT NUMBER, --价格
                                       P_MONTH_DISCOUNT    OUT NUMBER, --月返
                                       P_MESSAGE           OUT VARCHAR2 --返回提示信息
                                       ) IS
    P_PRICE_SYS_ID         NUMBER; --价格体系ID
    P_BU_PRICE_LIST_ID     T_BD_PRICE_SYSTEM.Bu_Price_List_Id%TYPE; --价格体系价格列表ID
    P_PRICE_SYS_CNT        NUMBER; --价格体系数量
    P_CENTER_PRICE_SYS_CNT NUMBER; --中心价格体系数量
    R_PRICE_SYS_CENTER     T_BD_PRICE_SYSTEM_ORG%ROWTYPE; --中心价格体系记录
    P_PRICE_LIST_ID        NUMBER; --价格列表ID
    P_PRICE_LINE_CNT       NUMBER; --价格列表行数量
    R_PRICE_LINE           T_BD_PRICE_LINE%ROWTYPE; --价格列表行记录
    P_IS_METERIAL          T_BD_PRICE_SYSTEM.PRICE_TYPE%TYPE; --产品类型（物料、产品、推广物料）                                     --是否推广物料

  BEGIN
    P_MESSAGE := 'SUCCESS';

    --取是否推广物料
    SELECT DECODE(TBI.IS_MATERIAL, 'Y', 'T', 'C')
      INTO P_IS_METERIAL
      FROM T_BD_ITEM TBI
     WHERE TBI.ITEM_CODE = P_ITEM_CODE
       AND TBI.ENTITY_ID = P_ENTITY_ID;

    --1、查询统计单据日期内的价格体系
    SELECT COUNT(*)
      INTO P_PRICE_SYS_CNT
      FROM T_BD_PRICE_SYSTEM TPS
     WHERE P_BILL_DATE >= to_char(TPS.BEGIN_DATE, 'YYYYMMDD')
       AND P_BILL_DATE <=
           to_char(nvl(TPS.END_DATE, to_date(P_BILL_DATE, 'YYYYMMDD') + 1),
                   'YYYYMMDD')
       AND TPS.ENTITY_ID = P_ENTITY_ID
       AND TPS.ACTIVE_FLAG = 'Y'
       AND TPS.PRICE_TYPE = P_IS_METERIAL;

    IF P_PRICE_SYS_CNT = 1  THEN
      --1.1查找到对应的1条价格体系
      SELECT TPS.PRICE_SYSTEM_ID,TPS.BU_PRICE_LIST_ID
        INTO P_PRICE_SYS_ID,P_BU_PRICE_LIST_ID
        FROM T_BD_PRICE_SYSTEM TPS
       WHERE P_BILL_DATE >= to_char(TPS.BEGIN_DATE, 'YYYYMMDD')
         AND P_BILL_DATE <=
             to_char(nvl(TPS.END_DATE, to_date(P_BILL_DATE, 'YYYYMMDD') + 1),
                     'YYYYMMDD')
         AND TPS.ENTITY_ID = P_ENTITY_ID
         AND TPS.ACTIVE_FLAG = 'Y'
         AND TPS.PRICE_TYPE = P_IS_METERIAL;

      --根据中心编码、价格体系ID，查找中心价格体系
      SELECT COUNT(*)
        INTO P_CENTER_PRICE_SYS_CNT
        FROM T_BD_PRICE_SYSTEM_ORG TSO
       WHERE TSO.PRICE_SYSTEM_ID = P_PRICE_SYS_ID
         AND TSO.ACTIVE_FLAG = 'Y'
         AND TSO.SALES_CENTER_CODE = P_SALES_CENTER_CODE;

      IF P_CENTER_PRICE_SYS_CNT = 1 THEN
        --1.1.1查找到对应的1条中心价格体系
        SELECT *
          INTO R_PRICE_SYS_CENTER
          FROM T_BD_PRICE_SYSTEM_ORG BSO
         WHERE BSO.PRICE_SYSTEM_ID = P_PRICE_SYS_ID
           AND BSO.ACTIVE_FLAG = 'Y'
           AND BSO.SALES_CENTER_CODE = P_SALES_CENTER_CODE;

        --取价格列表ID
        P_PRICE_LIST_ID := R_PRICE_SYS_CENTER.PRICE_LIST_ID;

      ELSIF P_CENTER_PRICE_SYS_CNT > 1 THEN
        --1.1.2查找到多条中心价格体系
        P_MESSAGE := '中心对应不能对应多个价格列表';
        RETURN;

      ELSE
        --1.1.3没有查找到中心价格体系，则取价格体系的价格
        P_PRICE_LIST_ID := P_BU_PRICE_LIST_ID;
      END IF;

      --1.1.4取得价格列表后，再去取产品价格
      --根据价格列表ID和产品查询价格
        SELECT COUNT(*)
          INTO P_PRICE_LINE_CNT
            FROM T_BD_PRICE_LINE BPL
           WHERE BPL.PRICE_LIST_ID = P_PRICE_LIST_ID
             AND BPL.ITEM_CODE = P_ITEM_CODE
             AND P_BILL_DATE >= to_char(BPL.BEGIN_DATE, 'YYYYMMDD')
             AND P_BILL_DATE <= to_char(nvl(BPL.END_DATE,
                                            to_date(P_BILL_DATE, 'YYYYMMDD') + 1),
                                        'YYYYMMDD')
             AND 'Y' = BPL.ACTIVE_FLAG;

        IF P_PRICE_LINE_CNT = 1 THEN
          --1.1.4.1取价产品价格
          SELECT *
            INTO R_PRICE_LINE
            FROM T_BD_PRICE_LINE BPL
           WHERE BPL.PRICE_LIST_ID = P_PRICE_LIST_ID
             AND BPL.ITEM_CODE = P_ITEM_CODE
             AND P_BILL_DATE >= to_char(BPL.BEGIN_DATE, 'YYYYMMDD')
             AND P_BILL_DATE <= to_char(nvl(BPL.END_DATE,
                                            to_date(P_BILL_DATE, 'YYYYMMDD') + 1),
                                        'YYYYMMDD')
             AND 'Y' = BPL.ACTIVE_FLAG;

          P_PRICE          := R_PRICE_LINE.LIST_PRICE;
          P_MONTH_DISCOUNT := R_PRICE_LINE.DISCOUNT;
        ELSIF P_PRICE_LINE_CNT > 1 THEN
           --1.1.4.2取价产品价格
            P_MESSAGE := '单据时间内产品查询到多个价格';
            RETURN;
        ELSE
           --1.1.4.3取价产品价格
            P_MESSAGE := '单据时间内查没有询到产品价格';
            RETURN;
        END IF;


    ELSIF P_PRICE_SYS_CNT > 1 THEN
      --1.2查找到对应的多条价格体系
      P_MESSAGE := '单据时间内查询到多个价格体系';
      RETURN;
    ELSE
      --1.3没有查找到对应的价格体系
      P_MESSAGE := '单据时间内未查询到价格体系';
      RETURN;
    END IF;

  END;

END PKG_BD_PRICE_NEW;
/

