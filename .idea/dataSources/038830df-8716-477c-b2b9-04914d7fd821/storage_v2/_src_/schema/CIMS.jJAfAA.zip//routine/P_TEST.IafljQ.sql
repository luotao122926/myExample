create procedure p_test
 as
 begin
   null;
 end;
/

