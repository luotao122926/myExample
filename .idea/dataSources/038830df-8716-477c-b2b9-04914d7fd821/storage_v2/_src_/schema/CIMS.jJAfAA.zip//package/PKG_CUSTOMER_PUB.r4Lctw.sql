create PACKAGE PKG_CUSTOMER_PUB is

  V_CUSTOMER_CHANNEL_TYPE_15             CONSTANT VARCHAR2(32) := '15'; --客户经营渠道类型：网批[15]
  
  FUNCTION F_CHECK_CUST_HAVE_FREEZING
  --检查客户集团、事业部、中心、账户是否冻结
  (P_ACTION_FLAG     varchar2, --功能冻结标识：01信用铺底02提货订单，不能为空，为空是返回-1
   P_CUSTOMER_ID     number, --客户ID，不能为空，为空是返回-1
   P_ENTITY_ID       number, --事业部对应的主体ID，不能为空，为空是返回-1 建议传入前台cookie的主体ID
   P_SALES_CENTER_ID number, --中心ID，可以为空，不为空时不判断账户是否冻结
   P_ACCOUNT_ID      number --账户ID，可以为空
   --，不为空时判断账户或者账户所挂的中心是否冻结，但不检查所挂中心ID是否与P_SALES_CENTER_ID一致
   ) return number
  --0成功（无冻结状态）
    --1客户头（集团）冻结
    --2事业部冻结
    --3账户所挂中心冻结
    --4账户非有效（冻结、失效）
    --5传入中心冻结
    --负1传入参数不合法
    ---2传入账户ID对应的账户或账户中心关系、客户中心关系不存在
    ---3传入账户对应的客户id或主体id与传入的客户id或主体id不一致
  ;

  FUNCTION F_CHECK_CUST_HAVE_STATUS
  --检查客户集团、事业部、中心、账户的状态是否是P_STATUS指定的状态
  (P_CUSTOMER_ID     number, --客户ID，不能为空，为空是返回-1
   P_ENTITY_ID       number, --事业部对应的主体ID，不能为空，为空是返回-1 建议传入前台cookie的主体ID
   P_SALES_CENTER_ID number, --中心ID，可以为空，不为空时不判断账户的状态是否是P_STATUS指定的状态
   P_ACCOUNT_ID      number, --账户ID，可以为空
   --，不为空时判断账户或者账户所挂的中心的状态是否是P_STATUS指定的状态，但不检查所挂中心ID是否与P_SALES_CENTER_ID一致
   P_STATUS VARCHAR2 DEFAULT 'Inactive') return number;

  FUNCTION F_CHECK_CUST_HAVE_FREEZING_MSG
  --检查客户集团、事业部、中心、账户是否冻结
  (P_ACTION_FLAG     varchar2, --功能冻结标识：01信用铺底02提货订单，不能为空，为空是返回-1
   P_CUSTOMER_ID     number, --客户ID，不能为空，为空是返回-1
   P_ENTITY_ID       number, --事业部对应的主体ID，不能为空，为空是返回-1 建议传入前台cookie的主体ID
   P_SALES_CENTER_ID number, --中心ID，可以为空，不为空时不判断账户是否冻结
   P_ACCOUNT_ID      number --账户ID，可以为空
   --，不为空时判断账户或者账户所挂的中心是否冻结，但不检查所挂中心ID是否与P_SALES_CENTER_ID一致
   ) return varchar2
  --0成功（无冻结状态）
    --1客户头（集团）冻结
    --2事业部冻结
    --3账户所挂中心冻结
    --4账户非有效（冻结、失效）
    --5传入中心冻结
    --负1传入参数不合法
    ---2传入账户ID对应的账户或账户中心关系、客户中心关系不存在
    ---3传入账户对应的客户id或主体id与传入的客户id或主体id不一致
  ;

  FUNCTION F_CHECK_CUST_H_UNDO_SHIP
  --检查账户是否存在未完成的发货通知单，如果存在，返回非空的字符串，否则返回空
  (IN_ENTITY_ID    number, --主体ID
   IN_ACCOUNT_ID   NUMBER, --账户ID，可以为空，为空时取IS_ACCOUNT_CODE进行查询，不为空时关联账户表得到账户编码
   IS_ACCOUNT_CODE VARCHAR2 --账户编码，可以为空，不为空时忽略IN_ACCOUNT_ID，为空时IN_ACCOUNT_ID关联账户表得到账户编码
   ) RETURN VARCHAR2;

END PKG_CUSTOMER_PUB;
/

