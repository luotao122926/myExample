create PACKAGE      PKG_LG_COMMON AS

  ----------------------------------------------------------------------
  -- AUTHOR  : XUQF
  -- CREATED : 2014-08-05
  -- PURPOSE : 拆分字符串
  ----------------------------------------------------------------------
  FUNCTION F_SPLIT_STR(AS_STR IN VARCHAR2, AS_SPLIT_STR IN VARCHAR2)
    RETURN TYPE_SPLIT;

  ----------------------------------------------------------------------
  -- AUTHOR  : XUQF
  -- CREATED : 2014-09-10
  -- PURPOSE : 生成供应商信息
  ----------------------------------------------------------------------
  PROCEDURE P_LG_GENERATION_VENDOR_INFO(O_RESULT     OUT VARCHAR2, --返回错误码
                                        O_RESULT_MSG OUT VARCHAR2 --返回错误信息
                                        );

  ----------------------------------------------------------------------
  -- AUTHOR  : XUQF
  -- CREATED : 2014-10-17
  -- PURPOSE : 引入供应商信息
  ----------------------------------------------------------------------
  PROCEDURE P_LG_IMPORT_VENDOR_INFO(I_VENDOR_INTF_IDS IN VARCHAR2, --供应商ID集合
                                    I_OPER_NAME       IN VARCHAR2, --登录账号
                                    O_RESULT          OUT VARCHAR2, --返回错误码
                                    O_RESULT_MSG      OUT VARCHAR2 --返回错误信息
                                    );
  --------------------------------------------------------------------------------
  /*
  *   创建日期：2014-11-12
  *     创建者：张丹凤
  *   功能说明：获取二级代码的值或者名称
      参数说明：1-获取 code_value 2-获取 code_name
  *   返回结果： code_name
  *
  */
  -------------------------------------------------------------------------------
  FUNCTION FUN_GET_V_CODELIST(P_CODE_ID   VARCHAR2, --待转值
                              P_CODE_TYPE VARCHAR2 --编码类型 codeType
                              ) RETURN VARCHAR2;

  ----------------------------------------------------------------------
  -- AUTHOR  : XUQF
  -- CREATED : 2015-01-07
  -- PURPOSE : 获取收货单位
  ----------------------------------------------------------------------
  FUNCTION P_CONSIGNEE_ADDRESS(I_CONTRACT_ID VARCHAR2) RETURN VARCHAR2;

  ----------------------------------------------------------------------
  -- AUTHOR  : XUQF
  -- CREATED : 2015-01-12
  -- PURPOSE : 获取单据类型
  ----------------------------------------------------------------------
  FUNCTION P_GET_ORDER_TYPE(I_CONTRACT_ID VARCHAR2) RETURN VARCHAR2;
  
  
    ----------------------------------------------------------------------
  -- AUTHOR  : guibr
  -- CREATED : 2019-03-18
  -- PURPOSE : 获取集拼主体
  ----------------------------------------------------------------------
  FUNCTION P_GET_ENTITY_GROUP(IN_ENTITY_ID NUMBER) RETURN NUMBER;

END PKG_LG_COMMON;
/

