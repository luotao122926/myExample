create Package      Pkg_Trx_Oi Is

  -- Author  : DENGMINGYU
  -- Created : 2007-10-8 21:34:12
  -- Purpose : 营销系统与税控机发票打印接口包

  -- 反回值接口常量
  Err_Ok                 Constant Varchar2(50) := 'OK';
  Err_Param_Err          Constant Varchar2(50) := '参数不在允许的范围内';
  Err_Unknow             Constant Varchar2(50) := '不明错误：';
  Err_Trx_Not_Found      Constant Varchar2(50) := '发票号码不存在';
  Err_Trx_Dup            Constant Varchar2(50) := '发票号码已经存在';
  Err_No_Queue           Constant Varchar2(50) := '找不到打印队列项';
  Err_Trx_Not_Cancelable Constant Varchar2(50) := '发票不能作废';
  Err_Trx_State_Err      Constant Varchar2(50) := '发票状态不对，不能操作';
  Err_Dup_Trx_Code       Constant Varchar2(50) := '发现重复的发票号';

  --打印后回写数据
  Procedure Create_So_Trx_Callback(p_Trx_Id In t_So_Trx_Headers.idTrx_Id%Type --打印队列ID
                                  , p_Trx_Code In t_So_Trx_Headers.Trx_Code%Type
                                   --发票号码
                                  , p_Trx_Date In t_So_Trx_Headers.Trx_Date%Type
                                   --发票日期
                                  , p_Result Out Varchar2
                                   --返回值
                                   );
                                   
 Procedure Create_So_Trx_Callback(p_Trx_Id In t_So_Trx_Headers.idTrx_Id%Type --打印队列ID
                                  , p_Trx_Code In t_So_Trx_Headers.Trx_Code%Type
                                   --发票号码
                                  , p_Trx_Date In t_So_Trx_Headers.Trx_Date%Type
                                  
                                  , p_Material_Trx_Amount In number
                                  
                                  , p_Material_Amount In number
                                  
                                  , p_Tax_Amount In number
                                  
                                  , p_Original_TRX_CODE In Varchar2
                                  
                                  , p_Created_By In Varchar2
                                   --发票日期
                                  , p_Result Out Varchar2
                                   --返回值
                                   );                                      
                                   
                                   
  --开具电子发票回写接口 add by huanghb12
  Procedure Create_So_Trx_Callback_Ecm(
                                    p_Trx_Id In t_So_Trx_Headers.idTrx_Id%Type --打印队列ID
                                    
                                  , p_Trx_Code In t_So_Trx_Headers.Trx_Code%Type
                                   --发票号码
                                   
                                   , p_Pdf_Url In t_So_Trx_Headers.pdf_url%Type
                                   --电子发票开票结果
                                   
                                  , p_Trx_Date In t_So_Trx_Headers.Trx_Date%Type
                                  
                                  , p_Material_Trx_Amount In number
                                  
                                  , p_Material_Amount In number
                                  
                                  , p_Tax_Amount In number
                                  
                                  , p_Original_TRX_CODE In Varchar2
                                  
                                  , p_SOURCE_SYSTEM In Varchar2
                                  
                                  , p_Created_By In Varchar2
                                   --发票日期
                                  , p_Result Out Varchar2
                                   --返回值
                                   );                                   
  --作废发票回写数据
  Procedure Cancel_So_Trx_Callback(p_Trx_Code In t_So_Trx_Headers.Trx_Code%Type --作废的发票号码
                                  , p_Result Out Varchar2
                                   --返回值
                                   );

  --锁定发票
  Procedure Lock_Trx(p_Trx_Id In t_So_Trx_Headers.idTrx_Id%Type --打印队列ID
                    , p_Result Out Varchar2
                     --返回值
                     );

  --解锁发票
  Procedure Unlock_Trx(p_Trx_Id In t_So_Trx_Headers.idTrx_Id%Type --打印队列ID
                      , p_Result Out Varchar2
                       --返回值
                       );
End Pkg_Trx_Oi;
/

