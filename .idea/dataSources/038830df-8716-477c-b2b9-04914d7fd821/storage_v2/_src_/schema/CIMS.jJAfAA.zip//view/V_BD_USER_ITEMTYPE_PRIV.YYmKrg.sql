create view V_BD_USER_ITEMTYPE_PRIV as
select distinct i."USER_ID",i."USER_CODE",i."USER_NAME",i."ITEM_CLASS_ID",i."CLASS_CODE",i."CLASS_NAME",i."ENTITY_ID"
  from (select uu.user_id, --用户ID
               uu.account user_code, --用户编码
               uu.name user_name, --用户名称
               ic.item_class_id, --产品类别ID
               ic.class_code, --产品类别编码
               ic.class_name, --产品类别名称
               et.entity_id --主体id
          from up_org_user uu,
               (select *
                  from t_bd_item_class
                 where class_type = 'M'
                   and active_flag = 'Y') ic,
               (select u.unit_id entity_id,
                       u.code    entity_code,
                       u.name    entity_name
                  from up_org_unit u
                 where u.type_code = 'BU'
                   and u.active_flag = 'T') et
         where ic.entity_id = et.entity_id
        minus
        --用户独立授权的限制访问的产品类别
        select dpt.user_id,
               uu.account user_code,
               uu.name user_name,
               ic.item_class_id, --产品类别ID
               ic.class_code, --产品类别编码
               ic.class_name, --产品类别名称
               dpt.entity_id
          from t_bd_datapriv_itemtype dpt,
               t_bd_item_class        ic,
               up_org_user            uu
         where dpt.item_class_code = ic.class_code
           and dpt.user_id = uu.user_id
           and dpt.active_flag = 'Y' --有效记录
           and ic.active_flag = 'Y'
     ) i
/

