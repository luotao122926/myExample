create PACKAGE BODY      PKG_AR_AUTO_CONFIRM IS

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-03-30
  *     创建者：田梦竹
  *   功能说明：收款自动确认，根据收款方法配置的业务分类、是否自动确认，过滤制单状态的收款，插入ERP收款接口表
  *   2015-10-14修改
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_CONFIRM_RECEIPT(P_RESULT OUT VARCHAR2 --成功则返回“SUCCESS”，否则返回出错信息
                              ) IS
    V_CASH_RECEIPT_CODE       VARCHAR2(32); --收款单据编号
    V_CASH_RECEIPT_ID         NUMBER; --收款头ID
    V_ENTITY_ID               NUMBER; --收款头主体ID
    V_CUSTOMER                NUMBER; --收款头客户ID
    V_CASH_CODE               VARCHAR2(40); --票据号
    V_APPENDIX_FLAG           VARCHAR2(2); --附件上传标志Y/N
    V_LINE_AMOUNT             NUMBER; --单张收款单的分款金额总和
    V_CODE_REPEAT_FLAG        NUMBER; --票据号重复标志，0--不重复，非0---重复
    V_SUB_CODE_SUM            NUMBER; -- 票据分号总数
    LINE_COUNT                NUMBER; --收款行数据总数
    V_CONFIRMED_CASH_CODES    VARCHAR2(4000); --记录合并导入的已自动确认过的票据号（注：该过程由JOB定时跑，半小时一次，所以该字段长度不需要太长，不会有太多的合并导入单据生成）
    V_UNITE_AMOUNT            NUMBER(12, 2); ---合并导入票据的总金额（插入资金使用）
    V_ERP_RECEIPT_METHOD_NAME VARCHAR2(100); --ERP收款方法名称
    V_ERP_RECEIPT_METHOD_ID   NUMBER; --ERP收款方法ID（插入资金、ERP接口表使用）
    V_ERP_BANK_ACCT_USE_ID    NUMBER; --ERP收款方银行账号ID（插入ERP接口表使用）
    V_ERP_BANK_ACCOUNT_ID     NUMBER; --ERP银行账号ID（插入资金使用）
    V_ERP_BANK_ACCOUNT_NAME   VARCHAR2(100); -- ERP银行账号名称（插入资金使用）
    V_CUST_BANK               VARCHAR2(600); --客户银行（插入资金使用）
    V_CUST_BANK_ACCOUNT       VARCHAR2(150); --客户银行账号（插入资金使用）
    V_SET_BOOK_ID             NUMBER; --账套ID
    V_ERROR_MESSAGE           VARCHAR2(1000); --收款确认校验错误信息

    --收款头、收款方法
    CURSOR C_RECEIPT_HEADERS IS
      SELECT TH.*,
             T.RECEIPT_METHOD_NAME,
             NVL(T.RECEIPT_ENTRY_CODE, 'N') RECEIPT_ENTRY_CODE,
             NVL(T.RECEIPT_CLASS_CODE, 'N') RECEIPT_CLASS_CODE,
             NVL(T.INTO_ERP_FLAG, 'N') INTO_ERP_FLAG,
             NVL(T.INTO_BAN_FLAG, 'N') INTO_BAN_FLAG,
             T.TYPE METHOD_TYPE,
             NVL(T.IS_EFFECTIVE, 'N') IS_EFFECTIVE,
             DECODE(T.RECEIPT_TYPE, '3', 'TP', 'RP') RECEIPT_TYPE,
             T.BUSINESS_TYPE,
             T.CASH_CODE_LENGTH,
             T.ERP_RECEIPT_METHOD_ID,
             T.PAY_MENT_MODE,
             T.ERP_HANDLE,
             T.CASH_DATE_TERM,
             T.RECEIPT_REQUIRE,
             T.ERP_AR_ID,
             T.ERP_RECEIPT_METHOD_NAME,
             T.ERP_AR_NAME,
             U.CODE SALES_CENTER_CODE,
             U.NAME SALES_CENTER_NAME
        FROM CIMS.T_AR_CASH_RECEIPT_HEADERS TH
        LEFT JOIN CIMS.UP_ORG_UNIT U
          ON U.UNIT_ID = TH.SALES_CENTER_ID
         AND U.ENTITY_ID = TH.ENTITY_ID, CIMS.T_AR_RECEIPT_METHODS T
       WHERE TH.RECEIPT_STATUS_ID = '1'
         AND T.BUSINESS_TYPE IN ('1', '4', '5')
         AND NVL(T.RECEIPT_CLASS_CODE, 'N') = 'Y'
         AND NVL(T.TYPE, 'N') = 'N'
         AND T.RECEIPT_METHOD_NAME <> '初始化收款'
         AND (NVL(T.INTO_ERP_FLAG, 'N') = 'Y' OR
             NVL(T.INTO_BAN_FLAG, 'N') = 'Y')
         AND TH.RECEIPT_METHOD_ID = T.RECEIPT_METHOD_ID
         AND TH.ENTITY_ID = T.ENTITY_ID
         AND NVL(T.IS_EFFECTIVE, 'N') = 'Y';

    HEAD_ROW C_RECEIPT_HEADERS%ROWTYPE; --收款头游标行数据

    --收款行
    CURSOR C_RECEIPT_LINES IS
      SELECT L.*
        FROM CIMS.T_AR_CASH_RECEIPT_LINES L
       WHERE L.CASH_RECEIPT_ID = V_CASH_RECEIPT_ID;

    LINE_ROW C_RECEIPT_LINES%ROWTYPE; --收款行游标行数据

    --客户下有效营销大类
    CURSOR C_SALES_MAIN_TYPE IS
      SELECT T2.ITEM_CLASS_ID SALES_MAIN_TYPE_ID,
             T1.SALES_MAIN_TYPE_CODE,
             T1.SALES_MAIN_TYPE_NAME
        FROM T_CUSTOMER_SALES_MAIN_TYPE T1, T_BD_ITEM_CLASS T2
       WHERE T1.SALES_MAIN_TYPE_CODE = T2.CLASS_CODE
         AND T1.ENTITY_ID = T2.ENTITY_ID
         AND T1.ACTIVE_FLAG = 'Active'
         AND T2.ACTIVE_FLAG = 'Y'
         AND T1.ENTITY_ID = V_ENTITY_ID
         AND T1.CUSTOM_ID = V_CUSTOMER;

    SALES_MAIN_TYPE_ROW   C_SALES_MAIN_TYPE%ROWTYPE; --有效营销大类游标行数据
    SALES_MAIN_TYPE_COUNT NUMBER; --营销大类总数

    --根据票据号获取所有子票据（合并导入）
    CURSOR C_RECEIPT_HEADERS_UNITE IS
      SELECT TH.*,
             T.RECEIPT_METHOD_NAME,
             NVL(T.RECEIPT_ENTRY_CODE, 'N') RECEIPT_ENTRY_CODE,
             NVL(T.RECEIPT_CLASS_CODE, 'N') RECEIPT_CLASS_CODE,
             NVL(T.INTO_ERP_FLAG, 'N') INTO_ERP_FLAG,
             NVL(T.INTO_BAN_FLAG, 'N') INTO_BAN_FLAG,
             T.TYPE METHOD_TYPE,
             NVL(T.IS_EFFECTIVE, 'N') IS_EFFECTIVE,
             DECODE(T.RECEIPT_TYPE, '3', 'TP', 'RP') RECEIPT_TYPE,
             T.BUSINESS_TYPE,
             T.CASH_CODE_LENGTH,
             T.ERP_RECEIPT_METHOD_ID,
             T.PAY_MENT_MODE,
             T.ERP_HANDLE,
             T.CASH_DATE_TERM,
             T.RECEIPT_REQUIRE,
             T.ERP_AR_ID,
             T.ERP_RECEIPT_METHOD_NAME,
             T.ERP_AR_NAME,
             U.CODE SALES_CENTER_CODE,
             U.NAME SALES_CENTER_NAME
        FROM CIMS.T_AR_CASH_RECEIPT_HEADERS TH
        LEFT JOIN CIMS.UP_ORG_UNIT U
          ON U.UNIT_ID = TH.SALES_CENTER_ID
         AND U.ENTITY_ID = TH.ENTITY_ID, CIMS.T_AR_RECEIPT_METHODS T
       WHERE TH.RECEIPT_STATUS_ID = '1'
         AND TH.CASH_CODE = V_CASH_CODE
         AND TH.ENTITY_ID = V_ENTITY_ID
         AND NVL(TH.UNITE_FLAG, 'N') = 'Y'
         AND TH.RECEIPT_METHOD_ID = T.RECEIPT_METHOD_ID
       ORDER BY TH.SUB_CASH_CODE;

    UNITE_ROW C_RECEIPT_HEADERS_UNITE%ROWTYPE; --合并导入票据行数据

  BEGIN
    FOR HEAD_ROW IN C_RECEIPT_HEADERS LOOP
      V_ERROR_MESSAGE           := 'SUCCESS';
      V_CONFIRMED_CASH_CODES    := '';
      V_ERP_RECEIPT_METHOD_NAME := HEAD_ROW.ERP_RECEIPT_METHOD_NAME;
      V_CASH_RECEIPT_CODE       := HEAD_ROW.CASH_RECEIPT_CODE;
      V_CASH_RECEIPT_ID         := HEAD_ROW.CASH_RECEIPT_ID;
      V_ENTITY_ID               := HEAD_ROW.ENTITY_ID;
      V_CUSTOMER                := HEAD_ROW.CUSTOMER_ID;

      --校验收款方法：
      V_ERROR_MESSAGE := PKG_AR_COMMON.F_VALIDATE_ENTITY_METHOD(V_ENTITY_ID,
                                                                HEAD_ROW.RECEIPT_METHOD_ID,
                                                                HEAD_ROW.BUSINESS_TYPE,
                                                                NULL);
      IF V_ERROR_MESSAGE = 'SUCCESS' THEN
        --校验收款单:必填项
        IF HEAD_ROW.CASH_RECEIPT_ID IS NULL THEN
          V_ERROR_MESSAGE := '收款单id为空';
        ELSIF HEAD_ROW.CASH_RECEIPT_CODE IS NULL THEN
          V_ERROR_MESSAGE := '收款单据编号为空';
        ELSIF HEAD_ROW.RECEIPT_METHOD_ID IS NULL THEN
          V_ERROR_MESSAGE := '收款单' || V_CASH_RECEIPT_CODE || '的收款方法为空';
        ELSIF HEAD_ROW.CUSTOMER_ID IS NULL THEN
          V_ERROR_MESSAGE := '收款单' || V_CASH_RECEIPT_CODE || '的客户id为空';
        ELSIF HEAD_ROW.CUSTOMER_CODE IS NULL THEN
          V_ERROR_MESSAGE := '收款单' || V_CASH_RECEIPT_CODE || '的客户编码为空';
        ELSIF HEAD_ROW.SALES_CENTER_CODE IS NULL THEN
          V_ERROR_MESSAGE := '收款单' || V_CASH_RECEIPT_CODE || '的营销中心编码为空';
        ELSIF HEAD_ROW.ACCOUNT_ID IS NULL THEN
          V_ERROR_MESSAGE := '收款单' || V_CASH_RECEIPT_CODE || '的账户id为空';
        ELSIF HEAD_ROW.ACCOUNT_CODE IS NULL THEN
          V_ERROR_MESSAGE := '收款单' || V_CASH_RECEIPT_CODE || '的账户编码为空';
        ELSIF HEAD_ROW.ERP_OU_ID IS NULL THEN
          V_ERROR_MESSAGE := '收款单' || V_CASH_RECEIPT_CODE || '的OU为空';
        ELSIF HEAD_ROW.CASH_RECEIPT_DATE IS NULL THEN
          V_ERROR_MESSAGE := '收款单' || V_CASH_RECEIPT_CODE || '的单据日期为空';
        ELSIF HEAD_ROW.GL_DATE IS NULL THEN
          V_ERROR_MESSAGE := '收款单' || V_CASH_RECEIPT_CODE || '的总账日期为空';
        ELSIF HEAD_ROW.BUDGET_ITEM_NAME IS NULL THEN
          V_ERROR_MESSAGE := '收款单' || V_CASH_RECEIPT_CODE || '的预算项目为空';
        ELSIF HEAD_ROW.AMOUNT IS NULL THEN
          V_ERROR_MESSAGE := '收款单' || V_CASH_RECEIPT_CODE || '的金额为空';
        ELSIF HEAD_ROW.CURRENCY_CODE IS NULL THEN
          V_ERROR_MESSAGE := '收款单' || V_CASH_RECEIPT_CODE || '的币种为空';
          --校验金额必须大于0
        ELSIF HEAD_ROW.AMOUNT <= 0 THEN
          V_ERROR_MESSAGE := '收款单' || V_CASH_RECEIPT_CODE || '的金额必须大于0';
          --校验收款必填项（收款方法配置）
        ELSIF (HEAD_ROW.RECEIPT_REQUIRE = 'Y') THEN
          IF HEAD_ROW.DRAWER IS NULL THEN
            V_ERROR_MESSAGE := '收款单' || V_CASH_RECEIPT_CODE || '的出票人为空';
          ELSIF HEAD_ROW.DRAWER_BANK_ACCOUNT IS NULL THEN
            V_ERROR_MESSAGE := '收款单' || V_CASH_RECEIPT_CODE || '的出票人银行账户为空';
          ELSIF HEAD_ROW.DRAWER_BANK IS NULL THEN
            V_ERROR_MESSAGE := '收款单' || V_CASH_RECEIPT_CODE || '的出票人银行空';
          ELSIF HEAD_ROW.ACCEPTANCE_BANK_NAME IS NULL THEN
            V_ERROR_MESSAGE := '收款单' || V_CASH_RECEIPT_CODE || '的承兑银行号为空';
          END IF;
        ELSIF HEAD_ROW.DRAWER_BANK_ACCOUNT IS NOT NULL AND
              LENGTH(HEAD_ROW.DRAWER_BANK_ACCOUNT) >= 38 THEN
          V_ERROR_MESSAGE := '收款单' || V_CASH_RECEIPT_CODE ||
                             '的出票人银行账户长度必须小于3';
        END IF;
      END IF;
      --若引入资金，第一收款人、第一收款人银行、第一收款人银行账号不能为空
      IF V_ERROR_MESSAGE = 'SUCCESS' AND HEAD_ROW.INTO_BAN_FLAG = 'Y' THEN
        IF HEAD_ROW.FIRST_RECEIPT_NAME IS NULL THEN
          V_ERROR_MESSAGE := '收款单' || V_CASH_RECEIPT_CODE || '的第一收款人为空';
        ELSIF HEAD_ROW.FIRST_RECEIPT_BANK_ACCOUNT IS NULL THEN
          V_ERROR_MESSAGE := '收款单' || V_CASH_RECEIPT_CODE || '的第一收款人银行账户为空';
        ELSIF HEAD_ROW.FIRST_RECEIPT_BANK IS NULL THEN
          V_ERROR_MESSAGE := '收款单' || V_CASH_RECEIPT_CODE || '的第一收款人银行为空';
        END IF;
      END IF;

      --格式校验:第一收款人银行账号和出票人银行账号格式：字母、数字、中划线；票据号格式：数字
      IF V_ERROR_MESSAGE = 'SUCCESS' THEN
        V_ERROR_MESSAGE := PKG_AR_COMMON.F_VALIDATE_FORMAT(V_CASH_RECEIPT_CODE,
                                                           HEAD_ROW.FIRST_RECEIPT_BANK_ACCOUNT,
                                                           HEAD_ROW.DRAWER_BANK_ACCOUNT,
                                                           HEAD_ROW.CASH_CODE);
      END IF;

      --校验票据号长度（收款方法配置）
      IF V_ERROR_MESSAGE = 'SUCCESS' THEN
        V_ERROR_MESSAGE := PKG_AR_COMMON.F_VALIDATE_CODE_LEN(V_CASH_RECEIPT_CODE,
                                                             HEAD_ROW.CASH_CODE_LENGTH,
                                                             HEAD_ROW.CASH_CODE);
      END IF;

      --校验票据期限：到期日>当天 、 到期日>=单据日期  、 到期日期-单据日期>票据期限
      IF V_ERROR_MESSAGE = 'SUCCESS' THEN
        V_ERROR_MESSAGE := PKG_AR_COMMON.F_VALIDATE_CODE_DATE_TERM(V_CASH_RECEIPT_CODE,
                                                                   HEAD_ROW.DUE_DATE,
                                                                   HEAD_ROW.CASH_DATE,
                                                                   HEAD_ROW.CASH_DATE_TERM);
      END IF;

      ---------------------------------待改----------------------------------------------
      --校验附件:根据系统参数设置来判断(厨电要求必须上传附件)
      IF V_ERROR_MESSAGE = 'SUCCESS' THEN
        PKG_BD.P_GET_PARAMETER_VALUE('ar_appendix_param',
                                     HEAD_ROW.ENTITY_ID,
                                     NULL,
                                     NULL,
                                     V_APPENDIX_FLAG);
        IF V_APPENDIX_FLAG = 'Y' AND HEAD_ROW.APPENDIX_ID IS NULL THEN
          V_ERROR_MESSAGE := '收款单' || V_CASH_RECEIPT_CODE || '的附件为空';
        END IF;
      END IF;
      -------------------------------------------------------------------------------

      --校验客户、中心、账户是否对应且有效
      IF V_ERROR_MESSAGE = 'SUCCESS' THEN
        V_ERROR_MESSAGE := PKG_AR_COMMON.F_VALIDATE_CUST_CENTER_ACC(HEAD_ROW.ENTITY_ID,
                                                                    HEAD_ROW.CUSTOMER_CODE,
                                                                    HEAD_ROW.SALES_CENTER_CODE,
                                                                    HEAD_ROW.ACCOUNT_CODE);
      END IF;

      --校验主体-OU是否一一对应
      IF V_ERROR_MESSAGE = 'SUCCESS' THEN
        V_ERROR_MESSAGE := PKG_AR_COMMON.F_VALIDATE_ENTITY_OU(HEAD_ROW.ENTITY_ID,
                                                              HEAD_ROW.ERP_OU_ID);
      END IF;

      --校验客户、OU是否对应有效
      IF V_ERROR_MESSAGE = 'SUCCESS' THEN
        V_ERROR_MESSAGE := PKG_AR_COMMON.F_VALIDATE_CUST_OU(HEAD_ROW.CUSTOMER_ID,
                                                            HEAD_ROW.ERP_OU_ID);
      END IF;

      --校验票据号是否重复（合并导入、已冲销、冲销原单、已引接口的票据号，允许重复）
      IF V_ERROR_MESSAGE = 'SUCCESS' THEN
        V_ERROR_MESSAGE := PKG_AR_COMMON.F_VALIDATE_CODE_REPEAT(V_CASH_RECEIPT_CODE,
                                                                HEAD_ROW.CASH_CODE,
                                                                HEAD_ROW.SUB_CASH_CODE,
                                                                HEAD_ROW.UNITE_FLAG,
                                                                HEAD_ROW.CASH_RECEIPT_ID);
      END IF;

      --校验客户下的营销大类
      IF V_ERROR_MESSAGE = 'SUCCESS' THEN
        SELECT COUNT(*)
          INTO LINE_COUNT
          FROM CIMS.T_AR_CASH_RECEIPT_LINES L
         WHERE L.CASH_RECEIPT_ID = HEAD_ROW.CASH_RECEIPT_ID;
        IF LINE_COUNT > 0 THEN
          V_LINE_AMOUNT := 0.0;
          --校验分款明细
          FOR LINE_ROW IN C_RECEIPT_LINES LOOP
            IF LINE_ROW.AMOUNT IS NULL THEN
              V_ERROR_MESSAGE := '收款单' || V_CASH_RECEIPT_CODE ||
                                 '的分款明细中金额为空';
            ELSIF LINE_ROW.AMOUNT IS NOT NULL AND LINE_ROW.AMOUNT <= 0 THEN
              V_ERROR_MESSAGE := '收款单' || V_CASH_RECEIPT_CODE ||
                                 '的分款明细中金额小于等于0';
            ELSIF LINE_ROW.SALES_MAIN_TYPE_CODE IS NULL OR
                  LINE_ROW.SALES_MAIN_TYPE_NAME IS NULL OR
                  LINE_ROW.SALES_MAIN_TYPE_ID IS NULL THEN
              V_ERROR_MESSAGE := '收款单' || V_CASH_RECEIPT_CODE ||
                                 '的分款明细中营销大类的id/编码/名称为空';
            ELSE
              SELECT COUNT(*)
                INTO SALES_MAIN_TYPE_COUNT
                FROM T_CUSTOMER_SALES_MAIN_TYPE T1, T_BD_ITEM_CLASS T2
               WHERE T1.SALES_MAIN_TYPE_CODE = T2.CLASS_CODE
                 AND T1.ENTITY_ID = T2.ENTITY_ID
                 AND T1.ACTIVE_FLAG = 'Active'
                 AND T2.ACTIVE_FLAG = 'Y'
                 AND T1.ENTITY_ID = HEAD_ROW.ENTITY_ID
                 AND T1.CUSTOM_ID = HEAD_ROW.CUSTOMER_ID;
              IF SALES_MAIN_TYPE_COUNT > 0 THEN
                --判断营销大类是否有效，是否属于收款的客户
                FOR SALES_MAIN_TYPE_ROW IN C_SALES_MAIN_TYPE LOOP
                  IF LINE_ROW.SALES_MAIN_TYPE_CODE =
                     SALES_MAIN_TYPE_ROW.SALES_MAIN_TYPE_CODE THEN
                    V_ERROR_MESSAGE := 'SUCCESS';
                    EXIT;
                  ELSE
                    V_ERROR_MESSAGE := '收款单' || V_CASH_RECEIPT_CODE ||
                                       '的分款明细中营销大类不是有效的，或不存在';
                  END IF;
                END LOOP;
              ELSE
                V_ERROR_MESSAGE := '收款单' || V_CASH_RECEIPT_CODE ||
                                   '客户下的有效营销大类为空';
              END IF;
            END IF;
            V_LINE_AMOUNT := V_LINE_AMOUNT + LINE_ROW.AMOUNT;
          END LOOP;
        ELSE
          V_ERROR_MESSAGE := '收款单行为空';
        END IF;
        IF V_ERROR_MESSAGE = 'SUCCESS' AND V_LINE_AMOUNT <> HEAD_ROW.AMOUNT THEN
          V_ERROR_MESSAGE := '收款单' || V_CASH_RECEIPT_CODE ||
                             '的金额与分款明细中金额总和不等';
        END IF;
      END IF;

      --------------------------------------------开始确认------------------------------------------------------------------------
      --若引入ERP，则校验ERP会计周期（不校验，直接过，因为引入ERP接口时，会判断会计周期是否开启，若不开启，则不会引入）
      --1、触发信控
      IF V_ERROR_MESSAGE = 'SUCCESS' THEN
        PKG_AR_BOND.P_CREDIT_CONTRL(HEAD_ROW.CASH_RECEIPT_ID,
                                    HEAD_ROW.ENTITY_ID,
                                    HEAD_ROW.ACCOUNT_ID,
                                    HEAD_ROW.CUSTOMER_ID,
                                    HEAD_ROW.RECEIPT_TYPE,
                                    'admin',
                                    V_ERROR_MESSAGE);
      END IF;

      --2、收款确认引接口校验
      IF V_ERROR_MESSAGE = 'SUCCESS' THEN
        PKG_AR_COMMON.P_VALIDATE_RECEIPT_CONFIRM(HEAD_ROW.ENTITY_ID,
                                                 HEAD_ROW.CUSTOMER_ID,
                                                 HEAD_ROW.ERP_OU_ID,
                                                 HEAD_ROW.CASH_CODE_LENGTH,
                                                 HEAD_ROW.RECEIPT_ENTRY_CODE,
                                                 HEAD_ROW.INTO_ERP_FLAG,
                                                 HEAD_ROW.INTO_BAN_FLAG,
                                                 HEAD_ROW.ERP_HANDLE,
                                                 HEAD_ROW.ATTRIBUTE7,
                                                 HEAD_ROW.ATTRIBUTE13,
                                                 HEAD_ROW.Refund_Apply_Id,
                                                 HEAD_ROW.ERP_RECEIPT_METHOD_NAME,
                                                 V_ERP_RECEIPT_METHOD_ID,
                                                 V_ERP_BANK_ACCT_USE_ID,
                                                 V_ERP_BANK_ACCOUNT_ID,
                                                 V_ERP_BANK_ACCOUNT_NAME,
                                                 V_CUST_BANK_ACCOUNT,
                                                 V_CUST_BANK,
                                                 V_SET_BOOK_ID,
                                                 V_ERROR_MESSAGE);
      END IF;
      --3、插入接口表
      IF V_ERROR_MESSAGE = 'SUCCESS' THEN
        --非合并导入
        IF HEAD_ROW.UNITE_FLAG IS NULL OR HEAD_ROW.UNITE_FLAG <> 'Y' THEN
          --引ERP
          IF HEAD_ROW.INTO_ERP_FLAG = 'Y' AND HEAD_ROW.ERP_HANDLE = '1' THEN
            --引ERP收款
            PKG_AR_COMMON.P_INSERT_ERP_RECEIPT(HEAD_ROW.CASH_RECEIPT_ID,
                                               V_ERP_RECEIPT_METHOD_ID,
                                               V_ERP_BANK_ACCT_USE_ID,
                                               V_ERROR_MESSAGE);
          ELSIF HEAD_ROW.INTO_ERP_FLAG = 'Y' AND HEAD_ROW.ERP_HANDLE = '2' THEN
            --引入ERP AR发票
            PKG_AR_COMMON.P_INSERT_AR_INVOICE(HEAD_ROW.CASH_RECEIPT_ID,
                                              V_SET_BOOK_ID,
                                              V_ERROR_MESSAGE);
            --引资金
          ELSIF HEAD_ROW.INTO_BAN_FLAG = 'Y' THEN
            PKG_AR_COMMON.P_INSERT_GTSP_RECEIPT(HEAD_ROW.CASH_RECEIPT_ID,
                                                V_CUST_BANK_ACCOUNT,
                                                V_CUST_BANK,
                                                V_ERP_RECEIPT_METHOD_ID,
                                                V_ERP_BANK_ACCOUNT_ID,
                                                V_ERP_BANK_ACCOUNT_NAME,
                                                V_ERROR_MESSAGE);
          END IF;
          --4、更新收款头表
          V_ERROR_MESSAGE := F_UPDATE_RECEIPT_HEAD(HEAD_ROW.CASH_RECEIPT_ID,
                                                   HEAD_ROW.INTO_ERP_FLAG,
                                                   HEAD_ROW.INTO_BAN_FLAG,
                                                   V_ERROR_MESSAGE);
          IF V_ERROR_MESSAGE <> 'SUCCESS' THEN
            RAISE V_BIZ_EXCEPTION;
          ELSE
            COMMIT;
          END IF;
        ELSE
          ------------------------------------------合并导入----------------------------------------------------------
          /*票据分号中的总数 等于 查询的记录数，可以进行确认，
          * 单张引入ERP，合并引入资金系统，已确认过的票据不再进行确认
          * 合并导入（若子票据没有录完，则不进行确认，前面已经校验过，故此处不再校验）
          * 票据号在已经自动确认过的票据中，则不校验
            */
          BEGIN
            IF V_SUB_CODE_SUM = V_CODE_REPEAT_FLAG AND
               (V_CONFIRMED_CASH_CODES IS NULL OR
               INSTR(V_CONFIRMED_CASH_CODES, HEAD_ROW.CASH_CODE) <= 0) THEN
              V_CONFIRMED_CASH_CODES := V_CONFIRMED_CASH_CODES ||
                                        HEAD_ROW.CASH_CODE || ',';
              --初始化合并导入资金的金额
              V_UNITE_AMOUNT := 0.0;
              --合并导入：引ERP
              FOR UNITE_ROW IN C_RECEIPT_HEADERS_UNITE LOOP
                --收款确认校验
                PKG_AR_COMMON.P_VALIDATE_RECEIPT_CONFIRM(UNITE_ROW.ENTITY_ID,
                                                         UNITE_ROW.CUSTOMER_ID,
                                                         UNITE_ROW.ERP_OU_ID,
                                                         UNITE_ROW.CASH_CODE_LENGTH,
                                                         UNITE_ROW.RECEIPT_ENTRY_CODE,
                                                         UNITE_ROW.INTO_ERP_FLAG,
                                                         UNITE_ROW.INTO_BAN_FLAG,
                                                         UNITE_ROW.ERP_HANDLE,
                                                         UNITE_ROW.ATTRIBUTE7,
                                                         UNITE_ROW.ATTRIBUTE13,
                                                         UNITE_ROW.Refund_Apply_Id,
                                                         UNITE_ROW.ERP_RECEIPT_METHOD_NAME,
                                                         V_ERP_RECEIPT_METHOD_ID,
                                                         V_ERP_BANK_ACCT_USE_ID,
                                                         V_ERP_BANK_ACCOUNT_ID,
                                                         V_ERP_BANK_ACCOUNT_NAME,
                                                         V_CUST_BANK_ACCOUNT,
                                                         V_CUST_BANK,
                                                         V_SET_BOOK_ID,
                                                         V_ERROR_MESSAGE);
                IF V_ERROR_MESSAGE = 'SUCCESS' THEN
                  --引入ERP，查询所有子票据，分别插入接口表
                  IF UNITE_ROW.INTO_ERP_FLAG = 'Y' THEN
                    --引ERP
                    IF UNITE_ROW.INTO_ERP_FLAG = 'Y' AND
                       UNITE_ROW.ERP_HANDLE = '1' THEN
                      --引ERP收款
                      PKG_AR_COMMON.P_INSERT_ERP_RECEIPT(UNITE_ROW.CASH_RECEIPT_ID,
                                                         V_ERP_RECEIPT_METHOD_ID,
                                                         V_ERP_BANK_ACCT_USE_ID,
                                                         V_ERROR_MESSAGE);
                    ELSIF UNITE_ROW.INTO_ERP_FLAG = 'Y' AND
                          UNITE_ROW.ERP_HANDLE = '2' THEN
                      --引入ERP AR发票
                      PKG_AR_COMMON.P_INSERT_AR_INVOICE(UNITE_ROW.CASH_RECEIPT_ID,
                                                        V_SET_BOOK_ID,
                                                        V_ERROR_MESSAGE);
                    END IF;
                    IF V_ERROR_MESSAGE <> 'SUCCESS' THEN
                      RAISE V_BIZ_EXCEPTION;
                    END IF;
                  END IF;
                  IF HEAD_ROW.INTO_BAN_FLAG = 'Y' THEN
                    V_UNITE_AMOUNT := V_UNITE_AMOUNT + UNITE_ROW.AMOUNT;
                  END IF;
                END IF;
              END LOOP;
              --合并导入：引资金
              --引入资金，查询所有子票据，将第一张子票据插入接口表
              IF V_ERROR_MESSAGE = 'SUCCESS' AND
                 HEAD_ROW.INTO_BAN_FLAG = 'Y' THEN
                FOR UNITE_ROW IN C_RECEIPT_HEADERS_UNITE LOOP

                  --校验通过，插入接口表
                  IF V_ERROR_MESSAGE = 'SUCCESS' THEN
                    --插入资金接口
                    INSERT INTO CIMS.INTF_GTSP_CIMS_TRAVEL_REGISTER
                      (ID,
                       --报文种类（资金状态：04，纸票在途登记报文）
                       BUSINESSTYPE,
                       --明细个数
                       ITEMRECNUM,
                       --系统导入日期
                       INPUTDATE,
                       --系统导出日期
                       OUTPUTDATE,
                       --来源系统编码
                       SOURCESYSTEMCODE,
                       --收款单据编号
                       RECIVECODE,
                       --付款方编码（即客户编码）
                       PAYMENTCODE,
                       --付款方名称（客户名称）
                       PAYMENTNAME,
                       --收款单头ID
                       ATTRIBUTE1,
                       --付款方银行账号（客户银行账号）
                       PAYBANKACCOUT,
                       --付款方银行名称（客户银行名称）
                       PAYBANKNAME,
                       --出票人
                       DRAWEROFBILL,
                       --出票银行
                       DRAWERBANKACOUNT,
                       --出票银行名称
                       DRAWERBANKNAME,
                       --上手背书人
                       LASTENDORSER,
                       --付款票据金额
                       BILLPAYAMOUNT,
                       --币种
                       CURRENCY,
                       --票据类型（纸票/电票）
                       BILLTYPE,
                       --结算方式
                       PAYMENTMODE,
                       --ERP收款方法ID
                       RECIVEMETHOD,
                       --ERP收款方银行账号
                       RECIVEBANKACCOUT,
                       --收款账号（ERP收款方银行账户名称）
                       RECIVEACCOUT,
                       --收款单位编号（ERP_OU_ID）
                       RECIVEUNITCODE,
                       --第一收款人
                       FIRSTRECIVENAME,
                       --第一收款人银行
                       FIRSTRECIVEBANK,
                       --第一收款人开户银行账户
                       FIRSTRECIVEBANKCCCOUT,
                       --出票日期
                       DATEOFDRAFT,
                       --到期日期
                       DATEOFMATURITY,
                       --票据号
                       BILLNO,
                       --承兑银行号
                       ACCEPTANCEBANKNO,
                       --预算项目
                       BUDGETITEM,
                       --状态:04. IMS-纸票在途登记；
                       STATUS,
                       --ERP_OU_ID
                       OUID,
                       --预算项目
                       ATTRIBUTE2,
                       --自动确认标志
                       ATTRIBUTE3)
                    VALUES
                      (S_INTF_GTS_IMS_TRAVEL_REGISTER.NEXTVAL,
                       '04',
                       1,
                       SYSDATE,
                       SYSDATE,
                       'CIMS',
                       UNITE_ROW.CASH_RECEIPT_CODE,
                       UNITE_ROW.CUSTOMER_CODE,
                       UNITE_ROW.CUSTOMER_NAME,
                       TO_CHAR(UNITE_ROW.CASH_RECEIPT_ID),
                       V_CUST_BANK_ACCOUNT,
                       V_CUST_BANK,
                       UNITE_ROW.DRAWER,
                       UNITE_ROW.DRAWER_BANK_ACCOUNT,
                       UNITE_ROW.DRAWER_BANK,
                       UNITE_ROW.BACK_WRITE_NAME,
                       --合并所有子票据的金额总和
                       V_UNITE_AMOUNT,
                       UNITE_ROW.CURRENCY_CODE,
                       DECODE(UNITE_ROW.RECEIPT_ENTRY_CODE,
                              'Y',
                              '纸票',
                              '电票'),
                       UNITE_ROW.PAY_MENT_MODE,
                       V_ERP_RECEIPT_METHOD_ID,
                       V_ERP_BANK_ACCOUNT_ID,
                       V_ERP_BANK_ACCOUNT_NAME,
                       UNITE_ROW.ERP_OU_ID,
                       UNITE_ROW.FIRST_RECEIPT_NAME,
                       UNITE_ROW.FIRST_RECEIPT_BANK,
                       UNITE_ROW.FIRST_RECEIPT_BANK_ACCOUNT,
                       UNITE_ROW.CASH_DATE,
                       UNITE_ROW.DUE_DATE,
                       UNITE_ROW.CASH_CODE,
                       UNITE_ROW.ACCEPTANCE_BANK_NAME,
                       UNITE_ROW.BUDGET_ITEM_NAME,
                       '04',
                       UNITE_ROW.ERP_OU_ID,
                       UNITE_ROW.BUDGET_ITEM_NAME,
                       'auto');
                  ELSE
                    RAISE V_BIZ_EXCEPTION;
                  END IF;
                  EXIT;
                END LOOP;
              END IF;
              --合并导入：更新收款头
              FOR UNITE_ROW IN C_RECEIPT_HEADERS_UNITE LOOP
                V_ERROR_MESSAGE := F_UPDATE_RECEIPT_HEAD(UNITE_ROW.CASH_RECEIPT_ID,
                                                         UNITE_ROW.INTO_ERP_FLAG,
                                                         UNITE_ROW.INTO_BAN_FLAG,
                                                         V_ERROR_MESSAGE);
              END LOOP;
            END IF;
            COMMIT;
          EXCEPTION
            WHEN OTHERS THEN
              ROLLBACK;
              UPDATE CIMS.T_AR_CASH_RECEIPT_HEADERS T
                 SET T.ATTRIBUTE8 = TO_CHAR(SYSDATE, 'yyyy-mm-dd hh24:mi:ss') ||
                                    '自动确认失败：' || V_ERROR_MESSAGE
               WHERE T.CASH_RECEIPT_ID = UNITE_ROW.CASH_RECEIPT_ID;
              COMMIT;
          END;
        END IF;
      ELSE
        --触发信控失败，记录错误信息，更新收款头表ATTRIBUTE8
        V_ERROR_MESSAGE := F_UPDATE_RECEIPT_HEAD(HEAD_ROW.CASH_RECEIPT_ID,
                                                 HEAD_ROW.INTO_ERP_FLAG,
                                                 HEAD_ROW.INTO_BAN_FLAG,
                                                 V_ERROR_MESSAGE);
        IF V_ERROR_MESSAGE <> 'SUCCESS' THEN
          RAISE V_BIZ_EXCEPTION;
        END IF;
      END IF;

    END LOOP;
    P_RESULT := V_ERROR_MESSAGE;
  EXCEPTION
    WHEN V_BIZ_EXCEPTION THEN
      ROLLBACK;
    WHEN NO_DATA_FOUND THEN
      V_ERROR_MESSAGE := '没有需要自动确认的收款单';
      P_RESULT        := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_AUTO_CONFIRM.P_CONFIRM_RECEIPT',
                                                SQLCODE,
                                                V_ERROR_MESSAGE || SQLERRM);
    WHEN OTHERS THEN
      ROLLBACK;
      P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_AUTO_CONFIRM.P_AUTO_CONFIRM_RECEIPT',
                                         SQLCODE,
                                         '收款自动确认失败！：' || SQLERRM);
  END;

  /*
  *自动确认成功、失败，更新收款头表对应字段
  *成功：引入ERP标志、引入资金标志更新为“Y”；ATTRIBUTE8更新“自动确认成功”；确认人=admin、确认时间=sysdate、单据状态=3；
  *失败：将错误信息写入ATTRIBUTE8
  */
  FUNCTION F_UPDATE_RECEIPT_HEAD(P_CASH_RECEIPT_ID T_AR_CASH_RECEIPT_HEADERS.CASH_RECEIPT_ID%TYPE, --收款ID（收款）
                                 P_INTO_ERP_FLAG   T_AR_RECEIPT_METHODS.INTO_ERP_FLAG%TYPE, --引入ERP标志
                                 P_INTO_BAN_FLAG   T_AR_RECEIPT_METHODS.INTO_BAN_FLAG%TYPE, --引入资金标志
                                 P_ERROR_INFO      VARCHAR2 --错误信息
                                 ) RETURN VARCHAR2 AS
  BEGIN
    IF P_ERROR_INFO = 'SUCCESS' THEN
      --更新收款头表：确认人、确认时间、单据状态、引入接口备注ATTRIBUTE1/ATTRIBUTE2
      UPDATE CIMS.T_AR_CASH_RECEIPT_HEADERS T
         SET T.REVIEWED_BY       = 'admin',
             T.REVIEWED_DATE     = TRUNC(SYSDATE),
             T.RECEIPT_STATUS_ID = '3',
             T.ATTRIBUTE1        = DECODE(P_INTO_ERP_FLAG, 'Y', 'Y', ''),
             T.ATTRIBUTE2        = DECODE(P_INTO_BAN_FLAG, 'Y', 'Y', ''),
             T.ATTRIBUTE8        = TO_CHAR(SYSDATE, 'yyyy-mm-dd hh24:mi:ss') ||
                                   '自动确认成功'
       WHERE T.CASH_RECEIPT_ID = P_CASH_RECEIPT_ID;
    ELSE
      UPDATE CIMS.T_AR_CASH_RECEIPT_HEADERS T
         SET T.ATTRIBUTE8 = TO_CHAR(SYSDATE, 'yyyy-mm-dd hh24:mi:ss') ||
                            '自动确认失败：' || P_ERROR_INFO
       WHERE T.CASH_RECEIPT_ID = P_CASH_RECEIPT_ID;
    END IF;
    RETURN 'SUCCESS';
  EXCEPTION
    WHEN OTHERS THEN
      RETURN PKG_BD.F_ADD_ERROR_LOG('PKG_AR_AUTO_CONFIRM.F_UPDATE_RECEIPT_HEAD',
                                    SQLCODE,
                                    substr(dbms_utility.format_error_backtrace,
                                           1,
                                           100) || SQLERRM);
  END;
END PKG_AR_AUTO_CONFIRM;
/

