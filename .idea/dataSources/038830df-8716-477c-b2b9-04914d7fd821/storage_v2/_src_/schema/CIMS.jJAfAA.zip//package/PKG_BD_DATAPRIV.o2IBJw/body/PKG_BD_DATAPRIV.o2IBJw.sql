create Package Body PKG_BD_DATAPRIV Is

  v_Success Constant Varchar2(10) := 'SUCCESS';

  ----------------------------------------
  /*数据权限通用策略 add by xiongpl*/
  /*
   SALES_ORG_ID  组织ID    v_bd_user_org_priv
   CUSTOMER_ID  客户ID    v_bd_user_cust_priv
   ACCOUNT_ID  账户ID      v_bd_user_acc_priv
   INV_ID  仓库ID          v_bd_user_inv_priv
   PRODUCING_AREA_ID  产地ID   v_bd_user_prodarea_priv
   SALES_MAIN_TYPE    产品大类Code   v_bd_user_itemtype_priv
   BILL_TYPE_ID      单据类型ID  v_bd_user_billtype_priv
   CHANNELTYPE  渠道类型code v_bd_user_channletype_priv,  --用户渠道类型（业态类型）权限视图
   MARKETMODE  营销模式code v_bd_user_marketmode_priv    --用户营销模式（合作类型）权限视图


  */
  ----------------------------------------
  function F_VPD_FOR_ALL(p_schema in varchar2 default NULL,
                       p_object in varchar2 default NULL)
    RETURN varchar2 AS
    l_mod  varchar2(48) := sys_context('userenv', 'module');             --模块
    l_table  varchar2(32) := sys_context('userenv', 'action');           --操作，一般为表名
    l_userAccountOrEntityId varchar2(64) := sys_context('userenv', 'client_identifier');  --自定义参数，一般为用户编码与主体ID

  BEGIN
    --INSERT INTO T_BD_VPD_LOG VALUES( 'l_mod:'||l_mod||'--p_object:'||p_object||'---l_table:'||l_table);
    if( l_mod ='vpdmodulename') then
      if (upper(p_object) != upper(l_table) ) then
         return ' 1 =1' ;
      end if;
      return F_VPD_GET_FILTER(l_table,l_userAccountOrEntityId);
    elsif (l_mod ='report') THEN
      if (upper(p_object) != upper(l_table) ) then
         return ' 1 =1' ;
      end if;
      --INSERT INTO T_BD_VPD_LOG VALUES( '日志时间：'||sysdate||'---传参信息10---'||l_mod||';'|| l_table || '; '||l_userAccountOrEntityId);
      return F_VPD_GET_FILTER(l_table,l_userAccountOrEntityId);
    ELSE
      return ' 1=1';
    end if;
  END;

  --获以数据权限的VPD filter函数
  function F_VPD_GET_FILTER(p_table in varchar2 ,
                       p_client_identifier in varchar2 ) RETURN varchar2 AS

    l_userAccount varchar2(64) := ''; --用户编码
    l_UE PKG_BD_UTIL.T_VARRAY;
    l_entityId varchar2(64) := ''; --主体ID

    l_filterSql    varchar2(2500) := ' 1=1';
    --受控字段列表游标
    cursor configDetail is
      select dcd.column_type,dcd.column_code
        from t_bd_datapriv_config dc,t_bd_datapriv_config_detail dcd
       where dcd.priv_config_id = dc.priv_config_id
         and dc.table_code=p_table;
         --and dc.table_code='t_bd_price_cust_config';
    privColumn configDetail%ROWTYPE ;

  BEGIN
   --INSERT INTO T_BD_VPD_LOG VALUES( '--拼出SQL---');
    --INSERT INTO T_BD_VPD_LOG VALUES( '日志时间：'||sysdate||'---传参信息10---'||l_mod||';'|| l_table || '; '||l_userAccountOrEntityId||'---拼出SQL---'||l_filterSql);
    IF (p_table is null or p_table='' or p_client_identifier is null  or  p_client_identifier='') THEN
      l_filterSql := ' 1 = 2';
      --INSERT INTO T_BD_VPD_LOG VALUES( '日志时间：'||sysdate||'---传参信息11---'||l_mod||';'|| l_table || '; '||l_userAccountOrEntityId||'---拼出SQL---'||l_filterSql);
      return l_filterSql;
    END IF;

    l_UE :=PKG_BD_UTIL.str_split(p_client_identifier,';');
    l_userAccount :=  l_UE(1);
    l_entityId := l_UE(2);

  --LOOP循环判断

   OPEN configDetail;
    LOOP
      FETCH configDetail
        INTO privColumn;
      EXIT WHEN configDetail%NOTFOUND;
      if (privColumn.column_type = 'CUSTOMER_ID') THEN
      --如果是客户 v_bd_user_cust_priv
        l_filterSql :=l_filterSql||' and '|| privColumn.column_code||' in (select customer_id from mt_bd_user_cust_priv  where user_code='''|| l_userAccount ||'''and entity_id='''||l_entityId||''')';
      elsif (privColumn.column_type = 'ACCOUNT_ID') THEN
      --如果是账户 v_bd_user_acc_priv
        l_filterSql :=l_filterSql||' and '|| privColumn.column_code||' in (select account_id from mt_bd_user_acc_priv  where user_code='''|| l_userAccount ||'''and entity_id='''||l_entityId||''')';
      elsif (privColumn.column_type = 'SALES_CENTER_ID') THEN
      --如果是中心 v_bd_user_org_priv
        l_filterSql :=l_filterSql||' and '|| privColumn.column_code||' in (select unit_id from mt_bd_user_org_priv  where user_code='''|| l_userAccount ||'''and entity_id='''||l_entityId||''')';
      elsif (privColumn.column_type='INV_ID') THEN
      --如果是仓库 v_bd_user_inv_priv
        l_filterSql :=l_filterSql||' and '|| privColumn.column_code||' in (select inventory_id from mt_bd_user_inv_priv  where user_code='''|| l_userAccount ||'''and entity_id='''||l_entityId||''')';
      elsif (privColumn.column_type='PRODUCING_AREA_ID') THEN
      --如果是产地ID  v_bd_user_prodarea_priv
        l_filterSql :=l_filterSql||' and '|| privColumn.column_code||' in (select producing_area_id from mt_bd_user_prodarea_priv  where user_code='''|| l_userAccount ||'''and entity_id='''||l_entityId||''')';
      elsif (privColumn.column_type = 'SALES_MAIN_TYPE') THEN
      --如果是产品大类 v_bd_user_itemtype_priv
        l_filterSql :=l_filterSql||' and '|| privColumn.column_code||' in (select class_code from mt_bd_user_itemtype_priv  where user_code='''|| l_userAccount ||'''and entity_id='''||l_entityId||''')';
      elsif (privColumn.column_type = 'BILL_TYPE_ID') THEN
      --如果是单据类型 v_bd_user_billtype_priv
        l_filterSql :=l_filterSql||' and '|| privColumn.column_code||' in (select bill_type_id from mt_bd_user_billtype_priv  where user_code='''|| l_userAccount ||'''and entity_id='''||l_entityId||''')';
        elsif (privColumn.column_type = 'CHANNELTYPE') THEN
      --如果是渠道类型code v_bd_user_channletype_priv
        l_filterSql :=l_filterSql||' and '|| privColumn.column_code||' in (select code_id from v_bd_user_channletype_priv  where user_code='''|| l_userAccount ||'''and entity_id='''||l_entityId||''')';
         elsif (privColumn.column_type = 'MARKETMODE') THEN
      --如果是营销模式code v_bd_user_marketmode_priv
        l_filterSql :=l_filterSql||' and '|| privColumn.column_code||' in (select code_id from v_bd_user_marketmode_priv  where user_code='''|| l_userAccount ||'''and entity_id='''||l_entityId||''')';
      END IF;


    END LOOP;
    CLOSE configDetail;
    --INSERT INTO T_BD_VPD_LOG VALUES( '日志时间：'||sysdate||'---传参信息22---'||l_mod||';'|| l_table || '; '||l_userAccountOrEntityId||'---拼出SQL---'||l_filterSql);
    return l_filterSql;
  END;

  ----------------------------------------
  /*数据权限增加表应用策略  add by lixh*/
  /*
    t_policy_table  应用策略表
  */
  ----------------------------------------

  procedure P_VPD_AddPolicy
    (t_policy_table in varchar2 default NULL) IS
    BEGIN
      DBMS_RLS.ADD_POLICY ( OBJECT_SCHEMA => 'CIMS',
      OBJECT_NAME => t_policy_table,
      POLICY_NAME => 'F_VPD_FOR_ALL',
      FUNCTION_SCHEMA => 'CIMS',
      POLICY_FUNCTION => 'PKG_BD_DATAPRIV.F_VPD_FOR_ALL',
      STATEMENT_TYPES => 'SELECT');
    END;

 ----------------------------------------
  /*数据权限取消表应用策略  add by lixh*/
  /*
    t_policy_table  应用策略表
  */
  ----------------------------------------

  procedure P_VPD_DropPolicy
    (t_policy_table in varchar2 default NULL) AS
    BEGIN

      DBMS_RLS.drop_policy ( OBJECT_SCHEMA => 'CIMS',
      OBJECT_NAME =>t_policy_table,
      POLICY_NAME => 'F_VPD_FOR_ALL');

    END;

  --同步权限数据至权限中间表
  procedure P_SYC_PRIVDATA(
             P_USER_ID    IN NUMBER,
             P_ENTITY_ID  IN NUMBER,
             P_DATA_TYPE  IN VARCHAR2,
             P_RESULT     OUT NUMBER, --返回错误ID
             P_ERR_MSG    OUT VARCHAR2 --返回错误信息
   )  IS

  BEGIN
    --初始返回值
    P_RESULT  := 0;
    P_ERR_MSG := 'SUCCESS';
   /* 
    select * from cims.mt_bd_user_acc_priv;
    select * from cims.mt_bd_user_cust_priv;
    select * from cims.mt_bd_user_org_priv;
    select * from mt_bd_user_billtype_priv ; 
    select * from mt_bd_user_inv_priv; 
    select * from mt_bd_user_itemtype_priv;
    select * from mt_bd_user_prodarea_priv;*/
    
    IF P_USER_ID IS NULL OR P_USER_ID = -1 THEN
      
         IF P_DATA_TYPE = 'ACC'  THEN 
           --delete from MT_BD_USER_ACC_PRIV where ENTITY_ID = P_ENTITY_ID;
           --insert into mt_bd_user_acc_priv(USER_ID,USER_CODE,ACCOUNT_ID,ENTITY_ID) select USER_ID,USER_CODE,ACCOUNT_ID,ENTITY_ID from v_bd_user_acc_priv  where ENTITY_ID = P_ENTITY_ID;
           
           delete from MT_BD_USER_ACC_PRIV where (USER_ID,USER_CODE,ACCOUNT_ID,ENTITY_ID) IN
           (SELECT USER_ID,USER_CODE,ACCOUNT_ID,ENTITY_ID FROM cims.MT_BD_USER_ACC_PRIV 
              minus
            SELECT USER_ID,USER_CODE,ACCOUNT_ID,ENTITY_ID FROM cims.V_BD_USER_ACC_PRIV );
            
           insert into mt_bd_user_acc_priv(USER_ID,USER_CODE,ACCOUNT_ID,ENTITY_ID) 
            select USER_ID,USER_CODE,ACCOUNT_ID,ENTITY_ID from 
           (SELECT USER_ID,USER_CODE,ACCOUNT_ID,ENTITY_ID FROM cims.V_BD_USER_ACC_PRIV 
              minus
            SELECT USER_ID,USER_CODE,ACCOUNT_ID,ENTITY_ID FROM cims.MT_BD_USER_ACC_PRIV);
           
           COMMIT;
         END IF;   
         IF P_DATA_TYPE = 'CUST'  THEN     
          -- delete from  MT_BD_USER_CUST_PRIV  where ENTITY_ID = P_ENTITY_ID;
          -- insert into mt_bd_user_cust_priv(USER_ID,USER_CODE,SALES_CENTER_ID,CUSTOMER_ID,ACTIVE_FLAG,ENTITY_ID) select USER_ID,USER_CODE,SALES_CENTER_ID,CUSTOMER_ID,ACTIVE_FLAG,ENTITY_ID from v_bd_user_cust_priv  where ENTITY_ID = P_ENTITY_ID;
           
             delete from MT_BD_USER_CUST_PRIV where (USER_ID,USER_CODE,SALES_CENTER_ID,CUSTOMER_ID,ACTIVE_FLAG,ENTITY_ID) IN
           (SELECT USER_ID,USER_CODE,SALES_CENTER_ID,CUSTOMER_ID,ACTIVE_FLAG,ENTITY_ID FROM cims.MT_BD_USER_CUST_PRIV 
              minus
            SELECT USER_ID,USER_CODE,SALES_CENTER_ID,CUSTOMER_ID,ACTIVE_FLAG,ENTITY_ID FROM cims.V_BD_USER_CUST_PRIV );
            
           insert into MT_BD_USER_CUST_PRIV(USER_ID,USER_CODE,SALES_CENTER_ID,CUSTOMER_ID,ACTIVE_FLAG,ENTITY_ID) 
            select USER_ID,USER_CODE,SALES_CENTER_ID,CUSTOMER_ID,ACTIVE_FLAG,ENTITY_ID from 
           (SELECT USER_ID,USER_CODE,SALES_CENTER_ID,CUSTOMER_ID,ACTIVE_FLAG,ENTITY_ID FROM cims.V_BD_USER_CUST_PRIV 
              minus
            SELECT USER_ID,USER_CODE,SALES_CENTER_ID,CUSTOMER_ID,ACTIVE_FLAG,ENTITY_ID FROM cims.MT_BD_USER_CUST_PRIV);
         
          COMMIT;
         END IF; 
         IF P_DATA_TYPE = 'BILLTYPE'  THEN   
           --delete from  MT_BD_USER_BILLTYPE_PRIV  where ENTITY_ID = P_ENTITY_ID;
           --insert into mt_bd_user_billtype_priv(USER_ID,USER_CODE,BILL_TYPE_ID,ENTITY_ID) select USER_ID,USER_CODE,BILL_TYPE_ID,ENTITY_ID from v_bd_user_billtype_priv  where ENTITY_ID = P_ENTITY_ID;
            delete from MT_BD_USER_BILLTYPE_PRIV where (USER_ID,USER_CODE,BILL_TYPE_ID,ENTITY_ID) IN
           (SELECT USER_ID,USER_CODE,BILL_TYPE_ID,ENTITY_ID FROM cims.MT_BD_USER_BILLTYPE_PRIV 
              minus
            SELECT USER_ID,USER_CODE,BILL_TYPE_ID,ENTITY_ID FROM cims.v_bd_user_billtype_priv );
            
           insert into MT_BD_USER_BILLTYPE_PRIV(USER_ID,USER_CODE,BILL_TYPE_ID,ENTITY_ID) 
            select USER_ID,USER_CODE,BILL_TYPE_ID,ENTITY_ID from 
           (SELECT USER_ID,USER_CODE,BILL_TYPE_ID,ENTITY_ID FROM cims.v_bd_user_billtype_priv 
              minus
            SELECT USER_ID,USER_CODE,BILL_TYPE_ID,ENTITY_ID FROM cims.MT_BD_USER_BILLTYPE_PRIV);
         
          COMMIT;
         END IF;   
         IF P_DATA_TYPE = 'INV'  THEN 
          -- delete from MT_BD_USER_INV_PRIV  where ENTITY_ID = P_ENTITY_ID;
          -- insert into mt_bd_user_inv_priv(USER_ID,USER_CODE,INVENTORY_ID,UNIT_ID,ENTITY_ID) select USER_ID,USER_CODE,INVENTORY_ID,UNIT_ID,ENTITY_ID from v_bd_user_inv_priv  where ENTITY_ID = P_ENTITY_ID;
          delete from MT_BD_USER_INV_PRIV where (USER_ID,USER_CODE,INVENTORY_ID,UNIT_ID,ENTITY_ID) IN
           (SELECT USER_ID,USER_CODE,INVENTORY_ID,UNIT_ID,ENTITY_ID FROM cims.MT_BD_USER_INV_PRIV 
              minus
            SELECT USER_ID,USER_CODE,INVENTORY_ID,UNIT_ID,ENTITY_ID FROM cims.v_bd_user_inv_priv );
            
           insert into MT_BD_USER_INV_PRIV(USER_ID,USER_CODE,INVENTORY_ID,UNIT_ID,ENTITY_ID) 
            select USER_ID,USER_CODE,INVENTORY_ID,UNIT_ID,ENTITY_ID from 
           (SELECT USER_ID,USER_CODE,INVENTORY_ID,UNIT_ID,ENTITY_ID FROM cims.v_bd_user_inv_priv 
              minus
           SELECT USER_ID,USER_CODE,INVENTORY_ID,UNIT_ID,ENTITY_ID FROM cims.MT_BD_USER_INV_PRIV);
         
          COMMIT;
         END IF;  
         
         IF P_DATA_TYPE = 'ORG'  THEN   
           --delete from  MT_BD_USER_ORG_PRIV;
           -- insert into mt_bd_user_org_priv(USER_ID,USER_CODE,UNIT_ID,ENTITY_ID) select USER_ID,USER_CODE,UNIT_ID,ENTITY_ID from v_bd_user_org_priv;
           delete from MT_BD_USER_ORG_PRIV where (USER_ID,USER_CODE,UNIT_ID,ENTITY_ID) IN
           (SELECT USER_ID,USER_CODE,UNIT_ID,ENTITY_ID FROM cims.MT_BD_USER_ORG_PRIV 
              minus
            SELECT USER_ID,USER_CODE,UNIT_ID,ENTITY_ID FROM cims.v_bd_user_org_priv );
            
           insert into MT_BD_USER_ORG_PRIV(USER_ID,USER_CODE,UNIT_ID,ENTITY_ID) 
            select USER_ID,USER_CODE,UNIT_ID,ENTITY_ID from 
           (SELECT USER_ID,USER_CODE,UNIT_ID,ENTITY_ID FROM cims.v_bd_user_org_priv 
              minus
            SELECT USER_ID,USER_CODE,UNIT_ID,ENTITY_ID FROM cims.MT_BD_USER_ORG_PRIV);
         
          COMMIT;
         END IF;   
         IF P_DATA_TYPE = 'ITEMTYPE'  THEN   
           --delete from MT_BD_USER_ITEMTYPE_PRIV;
          -- insert into mt_bd_user_itemtype_priv(USER_ID,USER_CODE,ITEM_CLASS_ID,ENTITY_ID) select USER_ID,USER_CODE,ITEM_CLASS_ID,ENTITY_ID from v_bd_user_itemtype_priv;
          
             delete from MT_BD_USER_ITEMTYPE_PRIV where (USER_ID,USER_CODE,ITEM_CLASS_ID,ENTITY_ID,CLASS_CODE) IN
           (SELECT USER_ID,USER_CODE,ITEM_CLASS_ID,ENTITY_ID,CLASS_CODE FROM cims.MT_BD_USER_ITEMTYPE_PRIV 
              minus
            SELECT USER_ID,USER_CODE,ITEM_CLASS_ID,ENTITY_ID,CLASS_CODE FROM cims.v_bd_user_itemtype_priv );
            
           insert into MT_BD_USER_ITEMTYPE_PRIV(USER_ID,USER_CODE,ITEM_CLASS_ID,ENTITY_ID,CLASS_CODE) 
            select USER_ID,USER_CODE,ITEM_CLASS_ID,ENTITY_ID,CLASS_CODE from 
           (SELECT USER_ID,USER_CODE,ITEM_CLASS_ID,ENTITY_ID,CLASS_CODE FROM cims.v_bd_user_itemtype_priv 
              minus
            SELECT USER_ID,USER_CODE,ITEM_CLASS_ID,ENTITY_ID,CLASS_CODE FROM cims.MT_BD_USER_ITEMTYPE_PRIV);
          
         
          COMMIT;
         END IF;
         IF P_DATA_TYPE = 'PRODAREA'  THEN   
           --delete from MT_BD_USER_PRODAREA_PRIV;
          -- insert into mt_bd_user_prodarea_priv(USER_ID,USER_CODE,PRODUCING_AREA_ID,ENTITY_ID) select USER_ID,USER_CODE,PRODUCING_AREA_ID,ENTITY_ID from v_bd_user_prodarea_priv;
           delete from MT_BD_USER_PRODAREA_PRIV where (USER_ID,USER_CODE,PRODUCING_AREA_ID,ENTITY_ID) IN
           (SELECT USER_ID,USER_CODE,PRODUCING_AREA_ID,ENTITY_ID FROM cims.MT_BD_USER_PRODAREA_PRIV 
              minus
            SELECT USER_ID,USER_CODE,PRODUCING_AREA_ID,ENTITY_ID FROM cims.v_bd_user_prodarea_priv );
            
           insert into MT_BD_USER_PRODAREA_PRIV(USER_ID,USER_CODE,PRODUCING_AREA_ID,ENTITY_ID) 
            select USER_ID,USER_CODE,PRODUCING_AREA_ID,ENTITY_ID from 
           (SELECT USER_ID,USER_CODE,PRODUCING_AREA_ID,ENTITY_ID FROM cims.v_bd_user_prodarea_priv 
              minus
            SELECT USER_ID,USER_CODE,PRODUCING_AREA_ID,ENTITY_ID FROM cims.MT_BD_USER_PRODAREA_PRIV);
           
           COMMIT;
         END IF;  
          
   ELSE
       delete from  mt_bd_user_acc_priv where USER_ID=P_USER_ID;
       insert into mt_bd_user_acc_priv(USER_ID,USER_CODE,ACCOUNT_ID,ENTITY_ID) select USER_ID,USER_CODE,ACCOUNT_ID,ENTITY_ID from v_bd_user_acc_priv where USER_ID=P_USER_ID;
      
       delete from  mt_bd_user_cust_priv  where USER_ID=P_USER_ID;
       insert into mt_bd_user_cust_priv(USER_ID,USER_CODE,SALES_CENTER_ID,CUSTOMER_ID,ACTIVE_FLAG,ENTITY_ID) select USER_ID,USER_CODE,SALES_CENTER_ID,CUSTOMER_ID,ACTIVE_FLAG,ENTITY_ID from v_bd_user_cust_priv  where USER_ID=P_USER_ID;
     
       delete from  mt_bd_user_org_priv  where USER_ID=P_USER_ID;
       insert into mt_bd_user_org_priv(USER_ID,USER_CODE,UNIT_ID,ENTITY_ID) select USER_ID,USER_CODE,UNIT_ID,ENTITY_ID from v_bd_user_org_priv  where USER_ID=P_USER_ID;
     
       delete from  mt_bd_user_billtype_priv  where USER_ID=P_USER_ID;
       insert into mt_bd_user_billtype_priv(USER_ID,USER_CODE,BILL_TYPE_ID,ENTITY_ID) select USER_ID,USER_CODE,BILL_TYPE_ID,ENTITY_ID from v_bd_user_billtype_priv  where USER_ID=P_USER_ID;
   
       delete from  mt_bd_user_inv_priv  where USER_ID=P_USER_ID;
       insert into mt_bd_user_inv_priv(USER_ID,USER_CODE,INVENTORY_ID,UNIT_ID,ENTITY_ID) select USER_ID,USER_CODE,INVENTORY_ID,UNIT_ID,ENTITY_ID from v_bd_user_inv_priv  where USER_ID=P_USER_ID;
   
       delete from  mt_bd_user_itemtype_priv  where USER_ID=P_USER_ID;
       insert into mt_bd_user_itemtype_priv(USER_ID,USER_CODE,ITEM_CLASS_ID,ENTITY_ID,CLASS_CODE) select USER_ID,USER_CODE,ITEM_CLASS_ID,ENTITY_ID,CLASS_CODE from v_bd_user_itemtype_priv  where USER_ID=P_USER_ID;
   
       delete from  mt_bd_user_prodarea_priv where USER_ID=P_USER_ID;
       insert into mt_bd_user_prodarea_priv(USER_ID,USER_CODE,PRODUCING_AREA_ID,ENTITY_ID) select USER_ID,USER_CODE,PRODUCING_AREA_ID,ENTITY_ID from v_bd_user_prodarea_priv  where USER_ID=P_USER_ID;
      
       COMMIT;
   END IF;
    
   /* 
    --1、同步组织权限数据
    for i in (select USER_ID,UNIT_ID,ENTITY_ID,max(OpType) as OpType
                from ( (select USER_ID,UNIT_ID,ENTITY_ID,'D' as OpType from MT_BD_USER_ORG_PRIV)
                       union all
                       (select USER_ID,UNIT_ID,ENTITY_ID,'I' as OpType
                          from v_bd_user_org_priv_default  --默认组织权限
                        union
                        select USER_ID,sales_center_id,ENTITY_ID,'I' as OpType
                          from v_bd_user_org_priv_addbycust  
                        union
                        select USER_ID,sales_center_id,ENTITY_ID,'I' as OpType
                          from v_bd_user_org_priv_addbyacc   ) )
               group by USER_ID,UNIT_ID,ENTITY_ID
               having count(*) = 1)
    loop
      case i.OpType
        when 'D' then
          delete from MT_BD_USER_ORG_PRIV t
           where t.USER_ID = i.USER_ID and t.UNIT_ID = i.UNIT_ID and t.ENTITY_ID = i.ENTITY_ID;
        when 'I' then
          insert into MT_BD_USER_ORG_PRIV(USER_ID,UNIT_ID,ENTITY_ID)
          values(i.USER_ID,i.UNIT_ID,i.ENTITY_ID);
      end case;
    end loop;
    --2、同步客户权限数据
    for i in (select USER_ID,SALES_CENTER_ID,CUSTOMER_ID,ACTIVE_FLAG,ENTITY_ID,max(OpType) as OpType
                from ( (select USER_ID,SALES_CENTER_ID,CUSTOMER_ID,ACTIVE_FLAG,ENTITY_ID,'D' as OpType from MT_BD_USER_CUST_PRIV)
                       union all
                       (select USER_ID,SALES_CENTER_ID,CUSTOMER_ID,ACTIVE_FLAG,ENTITY_ID,'I' as OpType
                          from v_bd_user_cust_priv_default  --用户默认的客户权限
                        union
                        select USER_ID,SALES_CENTER_ID,CUSTOMER_ID,ACTIVE_FLAG,ENTITY_ID,'I' as OpType
                          from v_bd_user_cust_priv_add  --用户独立授权的客户
                        union
                        select USER_ID,SALES_CENTER_ID,CUSTOMER_ID,ACTIVE_FLAG,ENTITY_ID,'I' as OpType
                          from v_bd_user_cust_priv_addbyacc  ) )
               group by USER_ID,SALES_CENTER_ID,CUSTOMER_ID,ACTIVE_FLAG,ENTITY_ID
               having count(*) = 1)
    loop
      case i.OpType
        when 'D' then
          delete from MT_BD_USER_CUST_PRIV t
           where i.USER_ID = t.USER_ID and i.SALES_CENTER_ID = t.SALES_CENTER_ID
             and i.CUSTOMER_ID = t.CUSTOMER_ID and i.ACTIVE_FLAG = t.ACTIVE_FLAG and i.ENTITY_ID = t.ENTITY_ID;
        when 'I' then
          insert into MT_BD_USER_CUST_PRIV(USER_ID,SALES_CENTER_ID,CUSTOMER_ID,ACTIVE_FLAG,ENTITY_ID)
          values(i.USER_ID,i.SALES_CENTER_ID,i.CUSTOMER_ID,i.ACTIVE_FLAG,i.ENTITY_ID);
      end case;
    end loop;
    --3、同步账户权限数据
    for i in (select USER_ID,ACCOUNT_ID,ENTITY_ID,max(OpType) as OpType
                from ( (select USER_ID,ACCOUNT_ID,ENTITY_ID,'D' as OpType from MT_BD_USER_ACC_PRIV)
                       union all
                       (select USER_ID,ACCOUNT_ID,ENTITY_ID,'I' as OpType
                          from v_bd_user_acc_priv_default  --用户默认的账户权限
                        union
                        select USER_ID,ACCOUNT_ID,ENTITY_ID,'I' as OpType
                          from v_bd_user_acc_priv_add  ) )
               group by USER_ID,ACCOUNT_ID,ENTITY_ID
               having count(*) = 1)
    loop
      case i.OpType
        when 'D' then
          delete from MT_BD_USER_ACC_PRIV t
           where t.USER_ID = i.USER_ID and t.ACCOUNT_ID = i.ACCOUNT_ID and t.ENTITY_ID = i.ENTITY_ID;
        when 'I' then
          insert into MT_BD_USER_ACC_PRIV(USER_ID,ACCOUNT_ID,ENTITY_ID)
          values(i.USER_ID,i.ACCOUNT_ID,i.ENTITY_ID);
      end case;
    end loop;
   */

   EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      P_ERR_MSG := '同步权限数据至中间间出错：' || SQLERRM;
      P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_BD_DATAPRIV.P_SYC_PRIVDATA',
                  SQLCODE,
                  '同步权限数据至中间间出错！错误消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
  END ;
  
  
  --复制用户权限 lilh6 2019-1-22
  Procedure p_Copy_User_Privdata(p_User_Code1 In Varchar2, --授权用户编码
                                 p_User_Code2 In Varchar2, --复制用户编码
                                 p_Entity_Id  In Number, --主体id
                                 p_Copy_Type  In Varchar2, --复制的权限类型
                                 p_Result     Out Varchar2 --返回错误ID
                                 ) Is
    v_Value Varchar2(2000);
    v_Id    Varchar2(32);
    v_user_id Number;
    v_user_name Varchar2(100);
    v_count Number;
  Begin
    p_Result := v_Success;
    Begin
      --获取授权用户id
      Select t.Id,t.user_id,t.name
        Into v_Id,v_user_id,v_user_name
        From Up_Org_User t
       Where t.Account = p_User_Code1;
    Exception
      When Others Then
        v_Value := '授权用户不存在，请检查用户账号=' || p_User_Code1 || ',是否错误或者不存在CIMS系统！' || Sqlerrm;
    End;
    If v_Value Is Null Then
      --检查复制用户
      Select Count(1)
        Into v_Count
        From Up_Org_User t
       Where t.Account = p_User_Code2;
     If v_count = 0 Then
       v_Value := '复制用户不存在，请检查复制账号=' || p_User_Code2 || ',是否错误或者不存在CIMS系统！';
     End If;
   End If;
    
    If v_Value Is Null Then
      If p_Copy_Type = 'USER' Or p_Copy_Type = 'ALL' Then
        --部门用户关系表Up_Sec_Role_User
        Insert Into Up_Sec_Role_User
          (Id, User_Id, Role_Id, Role_Type, Role_Name)
          Select Sys_Guid(),
                 v_Id,
                 t.Role_Id,
                 t.Role_Type,
                 t.Role_Name
            From Up_Sec_Role_User t, Up_Org_User u, Up_Org_Unit Ou
           Where t.User_Id = u.Id
             And t.Role_Type = 'unit'
             And u.Account = p_User_Code2
             And Ou.Id = t.Role_Id
             And Ou.Entity_Id = p_Entity_Id
             And Not Exists
           (Select 1
                    From Up_Sec_Role_User tt, Up_Org_User uu, Up_Org_Unit Ouu
                   Where tt.User_Id = uu.Id
                     And tt.Role_Type = 'unit'
                     And uu.Account = p_User_Code1
                     And Ouu.Id = tt.Role_Id
                     And tt.role_id = t.role_id
                     And Ouu.Entity_Id = p_Entity_Id);
        --复制组织单元用户关系表Up_Org_Unit_User    
        Insert Into Up_Org_Unit_User
          (Id,
           Unit_Id,
           User_Id,
           Created_By,
           Creation_Date,
           Last_Updated_By,
           Last_Update_Date)
          Select Sys_Guid(),
                 t.Unit_Id,
                 v_Id,
                 'program',
                 Sysdate,
                 'program',
                 Sysdate
            From Up_Org_Unit_User t, Up_Org_User u, Up_Org_Unit Ou
           Where t.User_Id = u.Id
             And t.Unit_Id = Ou.Id
             And u.Account = p_User_Code2
             And Ou.Entity_Id = p_Entity_Id
             And Not Exists
           (Select 1
                    From Up_Org_Unit_User tt, Up_Org_User uu, Up_Org_Unit Ouu
                   Where tt.User_Id = uu.Id
                     And tt.Unit_Id = Ouu.Id
                     And uu.Account = p_User_Code1
                     And tt.unit_id = t.unit_id
                     And Ouu.Entity_Id = p_Entity_Id);
        --复制业务角色用户关系表(包含所属组织)Up_Sec_Busi_Role_Unit_User
        Insert Into Up_Sec_Busi_Role_Unit_User
          (Id,
           User_Id,
           Unit_Id,
           Role_Id,
           Created_By,
           Creation_Date,
           Last_Updated_By,
           Last_Update_Date)
          Select Sys_Guid(),
                 v_Id,
                 t.Unit_Id,
                 t.Role_Id,
                 'program',
                 Sysdate,
                 'program',
                 Sysdate
            From Up_Sec_Busi_Role_Unit_User t,
                 Up_Org_User                u,
                 Up_Org_Unit                Ou
           Where t.User_Id = u.Id
             And t.Unit_Id = Ou.Id
             And u.Account = p_User_Code2
             And Ou.Entity_Id = p_Entity_Id
             And Not Exists (Select 1
                    From Up_Sec_Busi_Role_Unit_User tt,
                         Up_Org_User                uu,
                         Up_Org_Unit                Ouu
                   Where tt.User_Id = uu.Id
                     And tt.Unit_Id = Ouu.Id
                     And uu.Account = p_User_Code1
                     And tt.unit_id = t.unit_id
                     And tt.role_id = t.role_id
                     And Ouu.Entity_Id = p_Entity_Id);
        --复制角色用户关系表Up_Sec_Role_User
        Insert Into Up_Sec_Role_User
          (Id, User_Id, Role_Id, Role_Type, Role_Name)
          Select Sys_Guid(),
                 v_Id,
                 t.Role_Id,
                 t.Role_Type,
                 t.Role_Name
            From Up_Sec_Role_User t, Up_Org_User u
           Where t.User_Id = u.Id
             And t.Role_Type = 'busiRole'
             And u.Account = p_User_Code2
             And Not Exists (Select 1
                    From Up_Sec_Role_User tt, Up_Org_User uu
                   Where tt.User_Id = uu.Id
                     And uu.Account = p_User_Code1
                     And tt.role_id = t.role_id
                     And tt.Role_Type = 'busiRole');
      End If;
      --用户部门权限
      If p_Copy_Type = 'ORG' Or p_Copy_Type = 'ALL' Then
        Insert Into t_Bd_Datapriv_Org
          (Priv_Unit_Id,
           User_Id,
           User_Code,
           Unit_Id,
           Unit_Code,
           Unit_Name,
           Sub_Cust_Acc,
           Sub_Inv,
           Created_By,
           Creation_Date,
           Last_Updated_By,
           Last_Update_Date,
           Entity_Id,
           Active_Flag)
          Select Seq_Bd_Row_Id.Nextval,
                 v_user_id,
                 p_User_Code1,
                 t.Unit_Id,
                 t.Unit_Code,
                 t.Unit_Name,
                 'Y',
                 'Y',
                 'program',
                 Sysdate,
                 'program',
                 Sysdate,
                 t.Entity_Id,
                 'Y'
            From t_Bd_Datapriv_Org t
           Where t.User_Code = p_User_Code2
             And t.Entity_Id = p_Entity_Id
             And Not Exists (Select 1
                    From t_Bd_Datapriv_Org o
                   Where o.User_Code = p_User_Code1
                     And o.Entity_Id = p_Entity_Id
                     And o.Unit_Id = t.Unit_Id);
      End If;
      --用户客户权限
      If p_Copy_Type = 'CUST' Or p_Copy_Type = 'ALL' Then
        Insert Into t_Bd_Datapriv_Cust
          (Priv_Cust_Id,
           User_Id,
           User_Code,
           Customer_Id,
           Customer_Code,
           Customer_Name,
           Begin_Date,
           Created_By,
           Creation_Date,
           Last_Updated_By,
           Last_Update_Date,
           Entity_Id,
           Active_Flag)
          Select Seq_Bd_Row_Id.Nextval,
                 v_user_id,
                 p_User_Code1,
                 t.Customer_Id,
                 t.Customer_Code,
                 t.Customer_Name,
                 Trunc(Sysdate),
                 'program',
                 Sysdate,
                 'program',
                 Sysdate,
                 t.Entity_Id,
                 'Y'
            From t_Bd_Datapriv_Cust t
           Where t.User_Code = p_User_Code2
             And t.Entity_Id = p_Entity_Id
             And Not Exists
           (Select 1
                    From t_Bd_Datapriv_Cust c
                   Where c.User_Code = p_User_Code1
                     And c.Entity_Id = p_Entity_Id
                     And c.Customer_Id = t.Customer_Id);
      End If;
      --用户客户账户权限
      If p_Copy_Type = 'CUST_ACC' Or p_Copy_Type = 'ALL' Then
        Insert Into t_Bd_Datapriv_Cust_Acc
          (Priv_Custacc_Id,
           User_Id,
           User_Code,
           Customer_Id,
           Customer_Code,
           Customer_Name,
           Customer_Account_Id,
           Customer_Account_Code,
           Customer_Account_Name,
           Begin_Date,
           Created_By,
           Creation_Date,
           Last_Updated_By,
           Last_Update_Date,
           Entity_Id,
           Active_Flag)
          Select Seq_Bd_Row_Id.Nextval,
                 v_user_id,
                 p_User_Code1,
                 t.Customer_Id,
                 t.Customer_Code,
                 t.Customer_Name,
                 t.Customer_Account_Id,
                 t.Customer_Account_Code,
                 t.Customer_Account_Name,
                 Trunc(Sysdate),
                 'program',
                 Sysdate,
                 'program',
                 Sysdate,
                 t.Entity_Id,
                 'Y'
            From t_Bd_Datapriv_Cust_Acc t
           Where t.User_Code = p_User_Code2
             And t.Entity_Id = p_Entity_Id
             And Not Exists
           (Select 1
                    From t_Bd_Datapriv_Cust_Acc a
                   Where a.User_Code = p_User_Code1
                     And a.Entity_Id = p_Entity_Id
                     And a.Customer_Account_Id = t.Customer_Account_Id);
      End If;
      --用户仓库权限
      If p_Copy_Type = 'INV' Or p_Copy_Type = 'ALL' Then
        Insert Into t_Bd_Datapriv_Inv
          (Priv_Inv_Id,
           User_Id,
           User_Code,
           Inventory_Id,
           Inventory_Code,
           Inventory_Name,
           Begin_Date,
           Created_By,
           Creation_Date,
           Last_Updated_By,
           Last_Update_Date,
           Entity_Id,
           Active_Flag)
          Select Seq_Bd_Row_Id.Nextval,
                 v_user_id,
                 p_User_Code1,
                 t.Inventory_Id,
                 t.Inventory_Code,
                 t.Inventory_Name,
                 Trunc(Sysdate),
                 'program',
                 Sysdate,
                 'program',
                 Sysdate,
                 t.Entity_Id,
                 'Y'
            From t_Bd_Datapriv_Inv t
           Where t.User_Code = p_User_Code2
             And t.Entity_Id = p_Entity_Id
             And Not Exists
           (Select 1
                    From t_Bd_Datapriv_Inv Di
                   Where Di.User_Code = p_User_Code1
                     And Di.Entity_Id = p_Entity_Id
                     And Di.Inventory_Id = t.Inventory_Id);
      End If;
      --用户价格列表类型权限
      If p_Copy_Type = 'PRICE' Or p_Copy_Type = 'ALL' Then
        Insert Into t_Bd_Datapriv_Price
          (Priv_Price_Id,
           User_Id,
           User_Code,
           Price_Type_Code,
           Price_Type_Name,
           Begin_Date,
           Created_By,
           Creation_Date,
           Last_Updated_By,
           Last_Update_Date,
           Entity_Id,
           Active_Flag)
          Select Seq_Bd_Row_Id.Nextval,
                 v_user_id,
                 p_User_Code1,
                 t.Price_Type_Code,
                 t.Price_Type_Name,
                 Trunc(Sysdate),
                 'program',
                 Sysdate,
                 'program',
                 Sysdate,
                 t.Entity_Id,
                 'Y'
            From t_Bd_Datapriv_Price t
           Where t.User_Code = p_User_Code2
             And t.Entity_Id = p_Entity_Id
             And Not Exists
           (Select 1
                    From t_Bd_Datapriv_Price p
                   Where p.User_Code = p_User_Code1
                     And p.Entity_Id = p_Entity_Id
                     And p.Price_Type_Code = t.Price_Type_Code);
      End If;
      --用户产地权限
      If p_Copy_Type = 'PRODUCING' Or p_Copy_Type = 'ALL' Then
        Insert Into t_Bd_Datapriv_Producing
          (Priv_Producing_Id,
           User_Id,
           User_Code,
           Producing_Area_Id,
           Producing_Area_Code,
           Producing_Area_Name,
           Begin_Date,
           Created_By,
           Creation_Date,
           Last_Updated_By,
           Last_Update_Date,
           Entity_Id,
           Active_Flag)
          Select Seq_Bd_Row_Id.Nextval,
                 v_user_id,
                 p_User_Code1,
                 t.Producing_Area_Id,
                 t.Producing_Area_Code,
                 t.Producing_Area_Name,
                 Sysdate,
                 'program',
                 Sysdate,
                 'program',
                 Sysdate,
                 t.Entity_Id,
                 'Y'
            From t_Bd_Datapriv_Producing t
           Where t.User_Code = p_User_Code2
             And t.Entity_Id = p_Entity_Id
             And Not Exists
           (Select 1
                    From t_Bd_Datapriv_Producing Dp
                   Where Dp.User_Code = p_User_Code1
                     And Dp.Entity_Id = p_Entity_Id
                     And Dp.Producing_Area_Id = t.Producing_Area_Id);
      End If;
      --中转单据类型
      If p_Copy_Type = 'BILLTYPE_ADD' Or p_Copy_Type = 'ALL' Then
        Insert Into t_Bd_Datapriv_Billtype_Add
          (Priv_Billtype_Id,
           User_Id,
           User_Code,
           Billtype_Id,
           Billtype_Code,
           Billtype_Name,
           Operation_Type,
           Begin_Date,
           Created_By,
           Creation_Date,
           Last_Updated_By,
           Last_Update_Date,
           Entity_Id,
           Active_Flag)
          Select Seq_Bd_Row_Id.Nextval,
                 v_user_id,
                 p_User_Code1,
                 t.Billtype_Id,
                 t.Billtype_Code,
                 t.Billtype_Name,
                 t.Operation_Type,
                 Sysdate,
                 'program',
                 Sysdate,
                 'program',
                 Sysdate,
                 t.Entity_Id,
                 'Y'
            From t_Bd_Datapriv_Billtype_Add t
           Where t.User_Code = p_User_Code2
             And t.Entity_Id = p_Entity_Id
             And Not Exists
           (Select 1
                    From t_Bd_Datapriv_Billtype_Add a
                   Where a.User_Code = p_User_Code1
                     And a.Entity_Id = p_Entity_Id
                     And t.Billtype_Id = a.Billtype_Id
                     And t.Operation_Type = a.Operation_Type);
      End If;
      --复制预算数权限
      If p_Copy_Type = 'BUDGET' Or p_Copy_Type = 'ALL' Then
        Insert Into Cims.t_Bd_Datapriv_Budget
          (Priv_Budget_Id,
           User_Id,
           User_Code,
           Data_Flow_Id,
           Data_Flow_Name,
           Begin_Date,
           Created_By,
           Creation_Date,
           Last_Updated_By,
           Last_Update_Date,
           Entity_Id,
           Active_Flag)
          Select Seq_Bd_Row_Id.Nextval,
                 v_user_id,
                 p_User_Code1,
                 t.Data_Flow_Id,
                 t.Data_Flow_Name,
                 Sysdate,
                 'program',
                 Sysdate,
                 'program',
                 Sysdate,
                 t.Entity_Id,
                 'Y'
            From t_Bd_Datapriv_Budget t
           Where t.User_Code = p_User_Code2
             And t.Entity_Id = p_Entity_Id
             And Not Exists
           (Select 1
                    From t_Bd_Datapriv_Budget b
                   Where b.User_Code = p_User_Code1
                     And b.Entity_Id = p_Entity_Id
                     And b.Data_Flow_Id = t.Data_Flow_Id);
      End If;
      --复制营销类别
      If p_Copy_Type = 'ITEMTYPE' Or p_Copy_Type = 'ALL' Then
        Insert Into t_Bd_Datapriv_Itemtype
          (Priv_Mtlcategory_Id,
           User_Id,
           User_Code,
           Item_Class_Id,
           Item_Class_Code,
           Item_Class_Fullname,
           Begin_Date,
           Created_By,
           Creation_Date,
           Last_Updated_By,
           Last_Update_Date,
           Entity_Id,
           Active_Flag)
          Select Seq_Bd_Row_Id.Nextval,
                 v_User_Id,
                 p_User_Code1,
                 t.Item_Class_Id,
                 t.Item_Class_Code,
                 t.Item_Class_Fullname,
                 Sysdate,
                 'program',
                 Sysdate,
                 'program',
                 Sysdate,
                 t.Entity_Id,
                 'Y'
            From t_Bd_Datapriv_Itemtype t
           Where t.User_Code = p_User_Code2
             And t.Entity_Id = p_Entity_Id
             And Not Exists (Select 1
                    From t_Bd_Datapriv_Itemtype a
                   Where a.User_Code = p_User_Code1
                     And a.Entity_Id = p_Entity_Id
                     And t.Item_Class_Id = a.Item_Class_Id);        
      End If;
      
      --复制单据类别
      If p_Copy_Type = 'BILLTYPE' Or p_Copy_Type = 'ALL' Then
        Insert Into t_Bd_Datapriv_Billtype
          (Priv_Billtype_Id,
           User_Id,
           User_Code,
           Billtype_Code,
           Billtype_Name,
           Begin_Date,
           Created_By,
           Creation_Date,
           Last_Updated_By,
           Last_Update_Date,
           Entity_Id,
           Active_Flag,
           Billtype_Id)
          Select Seq_Bd_Row_Id.Nextval,
                 v_User_Id,
                 p_User_Code1,
                 t.Billtype_Code,
                 t.Billtype_Name,
                 Sysdate,
                 'program',
                 Sysdate,
                 'program',
                 Sysdate,
                 t.Entity_Id,
                 'Y',
                 T.BILLTYPE_ID
            From t_Bd_Datapriv_Billtype t
           Where t.User_Code = p_User_Code2
             And t.Entity_Id = p_Entity_Id
             And Not Exists (Select 1
                    From t_Bd_Datapriv_Billtype a
                   Where a.User_Code = p_User_Code1
                     And a.Entity_Id = p_Entity_Id
                     And t.Billtype_Id = a.Billtype_Id);
      End If;
      --用户特权
      If p_Copy_Type = 'FUNCTION' Or p_Copy_Type = 'ALL' Then
        Insert Into t_Bd_User_Function
          (User_Function_Id,
           User_Account,
           User_Name,
           Function01_Flag,
           Function02_Flag,
           Function03_Flag,
           Function04_Flag,
           Function05_Flag,
           Function06_Flag,
           Function07_Flag,
           Function08_Flag,
           Function09_Flag,
           Function10_Flag,
           Created_By,
           Creation_Date,
           Last_Updated_By,
           Last_Update_Date)
          Select s_Bd_User_Function.Nextval,
                 p_User_Code1,
                 v_user_name,
                 t.Function01_Flag,
                 t.Function02_Flag,
                 t.Function03_Flag,
                 t.Function04_Flag,
                 t.Function05_Flag,
                 t.Function06_Flag,
                 t.Function07_Flag,
                 t.Function08_Flag,
                 t.Function09_Flag,
                 t.Function10_Flag,
                 'program',
                 Sysdate,
                 'program',
                 Sysdate
            From t_Bd_User_Function t
           Where t.User_Account = p_User_Code2
             And Not Exists (Select 1
                    From t_Bd_User_Function a
                   Where a.User_Account = p_User_Code1);        
      End If;
    Else
      p_Result := v_Value;
    End If;
  Exception
    When Others Then
      p_Result := '用户权限复制失败，错误信息：' || Sqlerrm ||
                  Substr(Dbms_Utility.Format_Error_Backtrace, 1, 200);
  End p_Copy_User_Privdata;

End PKG_BD_DATAPRIV;
/

