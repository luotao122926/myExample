create view V_BD_ITEM_ASSEMBLIES_SUB as
SELECT S.ITEM_SUBASSEMBLY_ID,
       A.ITEM_ID, --套件产品ID
       A.ITEM_CODE, --套件产品编码
       A.ITEM_NAME, --套件产品名称
       A.ENTITY_ID, --主体ID
       A.ACTIVE_FLAG AS ASSEMBLE_ACTIVE_FLAG, --配套有效标识
       A.BEGIN_DATE, --启动日期
       A.END_DATE, --停用日期
       S.ITEM_ID    AS SUB_ITEM_ID, --散件产品ID
       I.ITEM_CODE  AS SUB_ITEM_CODE, --散件产品编码
       --S.ITEM_NAME  AS SUB_ITEM_NAME, --散件产品名称
       I.ITEM_NAME  AS SUB_ITEM_NAME, --散件产品名称
       --S.ITEM_UOM  AS SUB_ITEM_UMO, --散件产品单位
       I.DEFAULTUNIT AS SUB_ITEM_UOM, --散件产品单位
       S.ACTIVE_FLAG, --配套散件有效标识
       S.QUANTITY, --散件数量
       S.VALUE_SCALE --散件产品价值比例
  FROM T_BD_ITEM_ASSEMBLIES A, T_BD_ITEM_ASSEMBLIES_SUB S, T_BD_ITEM I
 WHERE A.ITEM_ASSEMBLY_ID = S.ITEM_ASSEMBLY_ID AND S.ITEM_ID = I.ITEM_ID
   AND S.ENTITY_ID = I.ENTITY_ID
   AND A.ENTITY_ID = S.ENTITY_ID
with read only
/

