create Package Body      PKG_AR_INVOICE Is

  v_Base_Exception Exception; --自定义异常
  
      --------------------------------------------------------------------------
  --Author: guibr
  --Created: 2016-07-28
  --获取开票配置信息
  --------------------------------------------------------------------------
  PROCEDURE P_GET_AR_CONFIG(P_ENTITY_ID       IN   NUMBER,
                            P_SALES_CENTER_ID IN   NUMBER,
                            P_CUSTOMER_ID     IN   NUMBER,
                            P_OU_ID           IN   NUMBER,
                            P_AR_CONF  OUT  TYPE_AR_CONF
                          ) IS
      V_TRX_RATE NUMBER; --税率
      V_MAX_TRX_AMOUNT         NUMBER(20,2);  --最大开票额
      V_MAX_DISCOUNT_LIMT      NUMBER(20,2);  --最大折扣率
      V_WHETHER_SPLIT          VARCHAR2(2);--是否允许拆分
      v_Value          Varchar2(1000);
  BEGIN
    Begin  
       Select 
             TRX_RATE
            ,TRX_LIMT
            ,DISCOUNT_LIMT
            ,WHETHER_SPLIT
          Into 
              V_TRX_RATE
             ,V_MAX_TRX_AMOUNT
             ,V_MAX_DISCOUNT_LIMT
             ,V_WHETHER_SPLIT
          From t_Ar_Conf Ac
          Where Ac.Entity_Id = p_Entity_Id
          And   Ac.Customer_Id = p_Customer_Id
          AND   Ac.Sales_Center_Id = p_Sales_Center_Id;
        Exception
          When Too_Many_Rows Then
            v_Value := '获取AR参数失败，同一客户+中心配置了多条AR参数。客户ID：' || To_Char(p_Customer_Id)||'中心ID：' || To_Char(p_Sales_Center_Id);
            Raise v_Base_Exception;
          When No_Data_Found Then
              --客户+中心 未设置参数则查询客户设置
             Begin
              Select 
                 TRX_RATE
                ,TRX_LIMT
                ,DISCOUNT_LIMT
                ,WHETHER_SPLIT
              Into 
                  V_TRX_RATE
                 ,V_MAX_TRX_AMOUNT
                 ,V_MAX_DISCOUNT_LIMT
                 ,V_WHETHER_SPLIT
              From t_Ar_Conf Ac
              Where Ac.Entity_Id = p_Entity_Id
              And   Ac.Customer_Id = p_Customer_Id
              And  Ac.Sales_Center_Id is null;
            Exception
              When Too_Many_Rows Then
                v_Value := '获取AR参数失败，同一客户配置了多条AR参数。客户ID：' || To_Char(p_Customer_Id);
                Raise v_Base_Exception;
              When No_Data_Found Then
                --客户未设置参数则查询中心设置
                Begin
                  Select 
                      TRX_RATE
                     ,TRX_LIMT
                     ,DISCOUNT_LIMT
                     ,WHETHER_SPLIT
                  Into 
                       V_TRX_RATE
                      ,V_MAX_TRX_AMOUNT
                      ,V_MAX_DISCOUNT_LIMT
                      ,V_WHETHER_SPLIT
                    From t_Ar_Conf Ac
                   Where Ac.Entity_Id = p_Entity_Id
                     And Ac.Sales_Center_Id = p_Sales_Center_Id
                     And Ac.Customer_Id Is Null;
                Exception
                  When Too_Many_Rows Then
                    v_Value := '获取AR参数失败，同一中心配置了多条AR参数。中心ID：' ||
                               To_Char(p_Sales_Center_Id);
                    Raise v_Base_Exception;
                  When No_Data_Found Then
                    --中心无参数则查询主体设置
                    Begin
                      Select 
                          TRX_RATE
                         ,TRX_LIMT
                         ,DISCOUNT_LIMT
                         ,WHETHER_SPLIT
                      Into 
                           V_TRX_RATE
                          ,V_MAX_TRX_AMOUNT
                          ,V_MAX_DISCOUNT_LIMT
                          ,V_WHETHER_SPLIT
                        From t_Ar_Conf Ac
                       Where Ac.Entity_Id = p_Entity_Id
                         And Ac.Erp_Ou = p_Ou_id              --by anht 增加主体OU判断
                         And Ac.Sales_Center_Id Is Null
                         And Ac.Customer_Id Is Null;
                    Exception
                      When Too_Many_Rows Then
                        v_Value := '获取AR参数失败，同一主体配置了多条AR参数。主体ID：' ||
                                   To_Char(p_Entity_Id);
                        Raise v_Base_Exception;
                    End;
                End;
            End;
      End;
    
    P_AR_CONF.TRX_RATE := V_TRX_RATE;
    P_AR_CONF.MAX_TRX_AMOUNT := V_MAX_TRX_AMOUNT;
    P_AR_CONF.MAX_DISCOUNT_LIMT := V_MAX_DISCOUNT_LIMT;
    P_AR_CONF.WHETHER_SPLIT := V_WHETHER_SPLIT;
  Exception
    When v_Base_Exception Then
        RAISE_APPLICATION_ERROR(-20000,v_Value);
  END ;
  
  
  -- 取银行账户
  function F_GET_CUSTOMER_BANK(
      p_Entity_Id       Number,  
      p_Customer_Id     Number
   ) 
   return varchar2 is
     S_BANK_ACCOUNT Varchar2(1000);
  Begin
      select 
          bank_account
       INTO  
          S_BANK_ACCOUNT
       from (
          select 
             substrb(nvl(d1.BANK, d1.ACCOUNTS_NAME) || d1.BANK_ACCOUNT, 0, 300) bank_account
          from cims.t_customer_bank d1  
          where d1.customer_id = p_Customer_Id
           AND  d1.active_flag = 'Active'
           AND  d1.entity_id = p_Entity_Id
           order by SSA_PRIMARY_FIELD desc nulls last
       ) where rownum<=1;
       return S_BANK_ACCOUNT;
   Exception  
     When  No_Data_Found Then
       S_BANK_ACCOUNT := null;
       return S_BANK_ACCOUNT;
     When Others Then
       S_BANK_ACCOUNT := null; 
       return S_BANK_ACCOUNT;
  END;
  
  
  
   -- 取客户银行名称 add by huanghb12
  function F_GET_CUSTOMER_BANK_NAME(
      p_Entity_Id       Number,  
      p_Customer_Id     Number
   ) 
   return varchar2 is
     S_BANK_ACCOUNT Varchar2(1000);
  Begin
      select 
          bank_account
       INTO  
          S_BANK_ACCOUNT
       from (
          select 
             substrb(nvl(d1.BANK, d1.ACCOUNTS_NAME), 0, 300) bank_account
          from cims.t_customer_bank d1  
          where d1.customer_id = p_Customer_Id
           AND  d1.active_flag = 'Active'
           AND  d1.entity_id = p_Entity_Id
           order by SSA_PRIMARY_FIELD desc nulls last
       ) where rownum<=1;
       return S_BANK_ACCOUNT;
   Exception  
     When  No_Data_Found Then
       S_BANK_ACCOUNT := null;
       return S_BANK_ACCOUNT;
     When Others Then
       S_BANK_ACCOUNT := null; 
       return S_BANK_ACCOUNT;
  END;

 -- 取客户银行账号 add by huanghb12
  function F_GET_CUSTOMER_BANK_ACCOUNT(
      p_Entity_Id       Number,  
      p_Customer_Id     Number
   ) 
   return varchar2 is
     S_BANK_ACCOUNT Varchar2(1000);
  Begin
      select 
          bank_account
       INTO  
          S_BANK_ACCOUNT
       from (
          select 
             substrb(d1.BANK_ACCOUNT, 0, 300) bank_account
          from cims.t_customer_bank d1  
          where d1.customer_id = p_Customer_Id
           AND  d1.active_flag = 'Active'
           AND  d1.entity_id = p_Entity_Id
           order by SSA_PRIMARY_FIELD desc nulls last
       ) where rownum<=1;
       return S_BANK_ACCOUNT;
   Exception  
     When  No_Data_Found Then
       S_BANK_ACCOUNT := null;
       return S_BANK_ACCOUNT;
     When Others Then
       S_BANK_ACCOUNT := null; 
       return S_BANK_ACCOUNT;
  END;

  Function f_Get_Ar_Config(p_Entity_Id       Number,
                           p_Sales_Center_Id Number,
                           p_Customer_Id     Number,
                           p_Ou_id           Number) Return Type_Ar_Config Is
    r_Ar_Confing     t_Ar_Conf%Rowtype;
    v_Type_Ar_Config Type_Ar_Config := Type_Ar_Config();
    v_Value          Varchar2(1000);
  Begin
    
   Begin  
         Select 
              *
           Into
             r_Ar_Confing
          From t_Ar_Conf Ac
          Where Ac.Entity_Id = p_Entity_Id
          And   Ac.Customer_Id = p_Customer_Id
          AND   Ac.Sales_Center_Id = p_Sales_Center_Id;
        Exception
          When Too_Many_Rows Then
            v_Value := '获取AR参数失败，同一客户+中心配置了多条AR参数。客户ID：' || To_Char(p_Customer_Id)||'中心ID：' || To_Char(p_Sales_Center_Id);
            Raise v_Base_Exception;
          When No_Data_Found Then
               --客户+中心 未设置参数则查询客户设置
                Begin
                  Select *
                    Into r_Ar_Confing
                    From t_Ar_Conf Ac
                   Where Ac.Entity_Id = p_Entity_Id
                     And Ac.Customer_Id = p_Customer_Id
                     And  Ac.Sales_Center_Id is null;
                Exception
                  When Too_Many_Rows Then
                    v_Value := '获取AR参数失败，同一客户配置了多条AR参数。客户ID：' || To_Char(p_Customer_Id);
                    Raise v_Base_Exception;
                  When No_Data_Found Then
                
                    --客户未设置参数则查询中心设置
                    Begin
                      Select *
                        Into r_Ar_Confing
                        From t_Ar_Conf Ac
                       Where Ac.Entity_Id = p_Entity_Id
                         And Ac.Sales_Center_Id = p_Sales_Center_Id
                         And Ac.Customer_Id Is Null;
                    Exception
                      When Too_Many_Rows Then
                        v_Value := '获取AR参数失败，同一中心配置了多条AR参数。中心ID：' ||
                                   To_Char(p_Sales_Center_Id);
                        Raise v_Base_Exception;
                      When No_Data_Found Then
                        --中心无参数则查询主体设置
                        Begin
                          Select *
                            Into r_Ar_Confing
                            From t_Ar_Conf Ac
                           Where Ac.Entity_Id = p_Entity_Id
                             And Ac.Erp_Ou = p_Ou_id              --by anht 增加主体OU判断
                             And Ac.Sales_Center_Id Is Null
                             And Ac.Customer_Id Is Null;
                        Exception
                          When Too_Many_Rows Then
                            v_Value := '获取AR参数失败，同一主体配置了多条AR参数。主体ID：' ||
                                       To_Char(p_Entity_Id);
                            Raise v_Base_Exception;
                          When Others Then
                            Null;
                        End;
                    End;
               
                 When Others Then
                    Null;
                End;
                
      End;              

    v_Type_Ar_Config.Extend;
    v_Type_Ar_Config(v_Type_Ar_Config.Count) := Type_Ar_Config_Row(p_Entity_Id, --Entity_Id,
                                                                   p_Sales_Center_Id, --Sales_Center_Id,
                                                                   p_Customer_Id, --Customer_Id,
                                                                   r_Ar_Confing.Ar_Conf_Initial, --Ar_Conf_Initial,
                                                                   r_Ar_Confing.Apply_Flag, --Apply_Flag,
                                                                   r_Ar_Confing.Approval_Flag, --Approval_Flag,
                                                                   r_Ar_Confing.Auto_Settle_Flag, --Auto_Settle_Flag,
                                                                   r_Ar_Confing.Settle_Next_Month_Flag, --Settle_Next_Month_Flag,
                                                                   r_Ar_Confing.So_Order_Type, --So_Order_Type,
                                                                   r_Ar_Confing.Trx_Limt, --Trx_Limt,
                                                                   r_Ar_Confing.Limt_Amount, --Limt_Amount,
                                                                   r_Ar_Confing.Limt_Day, --Limt_Day,
                                                                   r_Ar_Confing.Discount_Limt, --Discount_Limt
                                                                   r_Ar_Confing.Trx_Rate, --Trx_Rate,
                                                                   r_Ar_Confing.Trx_Type, --v_Row.trx_type --Trx_Type
                                                                   r_Ar_Confing.dis_trx_type, --v_Row.dis_trx_type --Trx_Type
                                                                   r_Ar_Confing.discount_line --v_Row.discount_line --Trx_Type
                                                                   );
    Return v_Type_Ar_Config;
  Exception
    When v_Base_Exception Then
      --Raise_Application_Error(2100, v_Value);
      RAISE_APPLICATION_ERROR(-20000,v_Value);
      Return Null;
    When Others Then
      Return Null;
  End;

  /*
  过程描述：用于检查发票状态是否可进行相关操作
  参数说明：
  P_TRX_ID   发票头ID
  CHECK_TYPE 检查类型（此检查用于什么操作）
  P_RESULT 反回参数，如果返回值不为 ERR_OK 则表示检查失败
  */
  Procedure p_Check_Status(p_Trx_Id   In Number,
                           Check_Type In Varchar2,
                           p_Result   In Out Varchar2) Is
    Vtrxrow   t_So_Trx_Headers%Rowtype;
    Vrowcount Number;
  Begin
    --用于取消合并操作前的状态检查
    If Check_Type = 'CANCEL_TRX_SPLIT' Then
      Select Count(1)
        Into Vrowcount
        From t_So_Trx_Headers         Sth,
             t_So_Trx_Header_Relation Sthr,
             t_So_Trx_Header_Relation Sthr1
       Where (Sth.Trx_Code Is Not Null Or
             Sth.State Not In (Ts_Not_Printed, Ts_In_Queue, Ts_Unknow)) -- 增加未引入瑞智系统状态的发票的判断
         And Sth.Idtrx_Id = Sthr.Idtrx_Id
         And Sthr.So_Head_Id = Sthr1.So_Head_Id
         And Sthr1.Idtrx_Id = p_Trx_Id;
      If Vrowcount <= 0 Then
        Begin
          Select *
            Into Vtrxrow
            From t_So_Trx_Headers Sth
           Where Sth.Idtrx_Id = p_Trx_Id
             For Update; --锁定
        Exception
          When No_Data_Found Then
            p_Result := Err_Trx_No_Found;
        End;
      Else
        p_Result := '已拆分单据已引入瑞智 或 ' || Err_Trx_Printed;
      End If; --TS_NOT_PRINTED,TS_IN_QUEUE,TS_UNKNOW代表未开票，发票可以失效/禁止打印
      If p_Result = Err_Ok And Nvl(Vtrxrow.State, Ts_Unknow) Not In
         (Ts_Not_Printed, Ts_In_Queue, Ts_Unknow) Then
        p_Result := Err_Trx_Cannt_Disable; --判断能不能失效/禁止打印
      End If;
    Elsif Check_Type = 'CANCEL_SO_TRX' Then
      ----用于作废操作前的状态检查
      Select Count(1)
        Into Vrowcount
        From t_So_Trx_Headers Sth
       Where Sth.Idtrx_Id = p_Trx_Id;
      If Vrowcount <= 0 Then
        p_Result := Err_Trx_No_Found; --发票ID不存在
      End If;
    Else
      p_Result := '未定义' || Check_Type || '操作的状态检查！';
    End If;
  End;

  --得到发票折扣率
  Function Get_Trx_Discount_Amount(p_Trx_Id t_So_Trx_Headers.Idtrx_Id%Type --发票ID
                                   ) Return Number As
    Vsummtldiscountamount Number;
    Vsumotheramount       Number;
    Vmtllinecount         Number;
    Votherlinecount       Number;
    Vdiscountamount       Number := 0;

  Begin
    Select -1 * Sum(Round(Case
                            When Tl.Item_Id < 0 Or Tl.Discount = 0 Then
                             0
                            Else
                             round(Tl.Price,6) * Tl.Quantity -
                             Round(round(Tl.Price,6) * Tl.Quantity * (100 - Nvl(Tl.Discount, 0)) / 100,
                                   2)
                          End,
                          2)),
           Sum(Round(Decode(Sign(Tl.Item_Id),
                            -1,
                            round(Tl.Price,6) * (100 - Nvl(Tl.Discount, 0)) / 100 *
                            Tl.Quantity,
                            0),
                     2)),
           Count(Decode(Sign(Tl.Item_Id), -1, Null, 1)),
           Count(Decode(Sign(Tl.Item_Id), -1, 1, Null))

      Into Vsummtldiscountamount,
           Vsumotheramount,
           Vmtllinecount,
           Votherlinecount
      From t_So_Trx_Lines Tl
     Where Tl.Idtrx_Id = p_Trx_Id
       And Tl.Discount <> 100
       And Tl.Quantity <> 0
       And Tl.Price <> 0;
    If (Vmtllinecount > 0) Then
      --有普通商品折扣
      Vdiscountamount := Vsummtldiscountamount + Vsumotheramount;
    Elsif (Vmtllinecount = 0 And Votherlinecount <> 0) Then
      --没有普通商品，只有普通的补差单或一批虚拟商品（虚拟折扣折让行不可能在一批商品的情况下存在)
      Select -1 * Sum(Round(round(Tl.Price,6) * Tl.Quantity -
                            Round(round(Tl.Price,6) * Tl.Quantity *
                                  (100 - Nvl(Tl.Discount, 0)) / 100,
                                  2),
                            2))
        Into Vdiscountamount
        From t_So_Trx_Lines Tl
       Where Tl.Idtrx_Id = p_Trx_Id;
    End If;
    Return Vdiscountamount;
  End;

  --发票作废和（针对一个发票池头进行作废）
  Procedure Cancel_So_Trx(p_Trx_Id  In t_So_Trx_Headers.Idtrx_Id%Type --作废的发票号码
                         ,
                          p_User_Id In t_So_Trx_Headers.Created_By%Type
                          --用户ID
                         ,
                          p_Result Out Varchar2
                          --返回值
                          ) Is
    Vstate   t_So_Trx_Headers.State%Type;
    Vtrxcode t_So_Trx_Headers.Trx_Code%Type;

    Vcount Number;
  Begin
    p_Result := Err_Ok;
    Savepoint Procstart;

    --检查状态（发票号是否存在）
    p_Check_Status(p_Trx_Id, 'CANCEL_SO_TRX', p_Result);

    --更新发票池对应数据
    If p_Result = Err_Ok Then
      Begin
        Select Sth.State, Sth.Trx_Code
          Into Vstate, Vtrxcode
          From t_So_Trx_Headers Sth
         Where Sth.Idtrx_Id = p_Trx_Id
           For Update;

        If Vstate = Pkg_Trx.Ts_Printed Then
          --更新销售表中对应的发票号
          Update t_So_Header Soh
             Set Soh.Invoice_Num_List = Trim(Substr(Soh.Invoice_Num_List,
                                                    1,
                                                    Instr(Soh.Invoice_Num_List,
                                                          Vtrxcode) - 1)) ||
                                        Trim(Substr(Soh.Invoice_Num_List,
                                                    Instr(Soh.Invoice_Num_List,
                                                          Vtrxcode) +
                                                    Length(Vtrxcode) + 1,
                                                    10000)),
                 Soh.Invoice_Date     = Decode(Soh.Invoice_Date,
                                               Vtrxcode,
                                               Null,
                                               Vtrxcode || ',',
                                               Null,
                                               ',' || Vtrxcode,
                                               Null,
                                               Soh.Invoice_Date),
                 Soh.Last_Update_Date = Sysdate,
                 Soh.Last_Updated_By  = p_User_Id
           Where Instr(Soh.Invoice_Num_List, Vtrxcode) > 0
             And Soh.So_Header_Id In
                 (Select Sthr.So_Head_Id
                    From t_So_Trx_Header_Relation Sthr, t_So_Trx_Headers Sth
                   Where Sthr.Idtrx_Id = Sth.Idtrx_Id
                     And Sth.Idtrx_Id = p_Trx_Id);
          --更新发票池
          Update t_So_Trx_Headers Sth
             Set Sth.Trx_Code         = Null,
                 Sth.Trx_Date         = Null,
                 Sth.Have_Signin_Flag = 'N'
                 --作废发票时将重置巳建回执标志
                ,
                 Sth.State            = Pkg_Trx.Ts_In_Queue,
                 Sth.Last_Updated_By  = p_User_Id,
                 Sth.Last_Update_Date = Sysdate
           Where Sth.Idtrx_Id = p_Trx_Id;

          --更新回执单据行为巳作废
          Update t_So_Trx_Signin_Lines Tsl
             Set Tsl.Have_Cancelled_Flag = 'Y'
           Where Tsl.Trx_Id = p_Trx_Id
             And Nvl(Tsl.Have_Cancelled_Flag, 'N') = 'N';

        Else
          --其它状态的发票无法作废
          p_Result := Err_Trx_Not_Cancelable;
        End If;
      Exception
        When No_Data_Found Then
          p_Result := Err_Trx_No_Found;
      End;
    End If;

    If p_Result = Err_Ok Then
      Commit;
    Else
      Rollback To Savepoint Procstart;
    End If;
  Exception
    When Others Then
      Rollback To Savepoint Procstart;
      p_Result := Err_Unknow || Sqlerrm;
  End;

  --删除单张发票及相关表记录
    Procedure p_Delete_Trx(p_Trx_Id In Number, p_Result In Out Varchar2) As
    Begin
        --删除发票行关系数据
        Delete t_So_Trx_Line_Relation Stlr
        Where Stlr.Trx_Line_Id In (Select Stl.Trx_Line_Id From t_So_Trx_Lines Stl Where Stl.Idtrx_Id = p_Trx_Id);
        Dbms_Output.Put_Line('删除发票行关系数据' || To_Char(Sql%Rowcount));

        --删除发票行
        Delete t_So_Trx_Lines Stl Where Stl.Idtrx_Id = p_Trx_Id;
        Dbms_Output.Put_Line('删除发票行' || To_Char(Sql%Rowcount));

        --删除发票头关系数据
        Delete t_So_Trx_Header_Relation Sthr Where Sthr.Idtrx_Id = p_Trx_Id;
        Dbms_Output.Put_Line('删除发票头关系数据' || To_Char(Sql%Rowcount));

         --删除发票头
        Delete t_So_Trx_Headers Sth Where Sth.Idtrx_Id = p_Trx_Id;
        Dbms_Output.Put_Line('删除发票头' || To_Char(Sql%Rowcount));

    Exception
        When Others Then
            Rollback;
            p_Result := Err_Unknow || Sqlerrm;
    End;

  --------------------------------------------------------------------------
  --Author: Tianmengzhu
  --Created: 2014-10-15
  --发票池：取消拆分/合并，关联删除发票
  --------------------------------------------------------------------------
    Procedure p_Delete_Trx_Cascade(p_Trx_Id In Number, p_Result In Out Varchar2) As
        v_Num    Number := 0;
        v_Trx_Id Number;
        --查出某发票对应的销售单对应的其它发票
        Cursor c_Trx_Id Is
            Select Distinct Sthr.Idtrx_Id
            From t_So_Trx_Header_Relation Sthr
            Where Sthr.so_head_id In (Select Thr.so_head_id From t_So_Trx_Header_Relation Thr Where Thr.Idtrx_Id = p_Trx_Id)
            Minus
            Select p_Trx_Id From Dual;
    Begin
        If p_Result = Err_Ok Then
            --检查状态，发票是否可进行取消合并操作
            p_Check_Status(p_Trx_Id, 'CANCEL_TRX_SPLIT', p_Result);
            If p_Result = Err_Ok Then
                --查出某发票对应的销售单对应的发票数量
                Select Count(Distinct Sthr.Idtrx_Id)
                Into v_Num
                From t_So_Trx_Header_Relation Sthr
                Where Sthr.so_head_id In (Select Thr.so_head_id From t_So_Trx_Header_Relation Thr Where Thr.Idtrx_Id = p_Trx_Id);
                If v_Num > 1 Then
                    --关联的发票不止一张
                    Open c_Trx_Id;
                    p_Delete_Trx(p_Trx_Id, p_Result);
                    If p_Result = Err_Ok Then
                        Loop
                            Fetch c_Trx_Id
                                Into v_Trx_Id;
                            Exit When c_Trx_Id%Notfound;
                            p_Delete_Trx_Cascade(v_Trx_Id, p_Result);
                        End Loop;
                    Else
                        Rollback;
                    End If;
                    Close c_Trx_Id;
                Else
                    p_Delete_Trx(p_Trx_Id, p_Result);
                    If p_Result <> Err_Ok Then
                        Rollback;
                    End If;
                End If;
            Else
                Rollback;
                p_Result := '发票头ID为' || To_Char(p_Trx_Id) || p_Result;
            End If;
        End If;
    Exception
        When Others Then
            Rollback;
            p_Result := Err_Unknow || Sqlerrm;
    End;


  --------------------------------------------------------------------------
  --Author: Tianmengzhu
  --Created: 2014-10-15
  --发票池：取消拆分/合并，取消形式：删除发票号，删除与该笔发票拆分相关的记录
  --------------------------------------------------------------------------
    Procedure p_Cancel_Trx_Split(p_Trx_Id In t_So_Trx_Headers.Idtrx_Id%Type --发票池ID
                                                          , p_Result Out Varchar2
                                                           --返回值
                                                           ) Is
      Begin
          p_Result := Err_Ok;
          --联级删除发票相关信息，p_delete_trx_cascade中巳做状态判断和事务处理
          p_Delete_Trx_Cascade(p_Trx_Id, p_Result);
      End;


  --------------------------------------------------------------------------
  --Author: Tianmengzhu
  --Created: 2014-10-15
  --发票池：取消开票（状态：准备开票-->未开票）
  --------------------------------------------------------------------------
    Procedure p_Cancel_Trx_Print_Queue(p_Trx_Id In t_So_Trx_Headers.Idtrx_Id%Type --发票池ID
                                    , p_User_Account In t_So_Trx_Headers.Created_By%Type
                                    , p_Result Out Varchar2
                                     --返回值
                                     ) Is
      Vtrxrow t_So_Trx_Headers%Rowtype;
    Begin
      p_Result := Err_Ok;

      Begin
        Select * Into Vtrxrow From t_So_Trx_Headers Sth Where Sth.Idtrx_Id = p_Trx_Id For Update; --锁定
      Exception
        When No_Data_Found Then
          Rollback;
          p_Result := Err_Trx_No_Found;
      End;

      --TS_IN_QUEUE代表准备开票，如果不是准备开票状态，这个P_TRX_ID是无效的
      If p_Result = Err_Ok And Nvl(Vtrxrow.State, Ts_Unknow) <> Ts_In_Queue Then
        p_Result := Err_Trx_Cannt_Cancel_Printed;
      End If;

      If p_Result = Err_Ok Then
        --状态更新为未开票
        Update t_So_Trx_Headers Sth
        Set Sth.State = Ts_Not_Printed, Sth.Last_Updated_By = p_User_Account, Sth.Last_Update_Date = Sysdate
        Where Sth.Idtrx_Id = p_Trx_Id;
      End If;

      If p_Result <> Err_Ok Then
        Rollback;
      End If;

    Exception
      When Others Then
        Rollback;
        p_Result := Err_Unknow || Sqlerrm;
    End;

  --------------------------------------------------------------------------
  --Author: Tianmengzhu
  --Created: 2014-10-15
  --发票池：开票（状态：未开票-->准备开票）
  --------------------------------------------------------------------------
    Procedure p_Ins_Trx_Print_Queue(p_Trx_Id In t_So_Trx_Headers.Idtrx_Id%Type --发票池ID
                                 , p_User_Account In t_So_Trx_Headers.Created_By%Type
                                  --用户ID
                                 , p_Result Out Varchar2
                                  --返回值
                                  ) Is
      Vtrxrow t_So_Trx_Headers%Rowtype;
      IN_TOH_ID number;
    Begin
      p_Result := Err_Ok;

      Begin
        Select * Into Vtrxrow From t_So_Trx_Headers Sth Where Sth.Idtrx_Id = p_Trx_Id For Update; --锁定
      Exception
        When No_Data_Found Then
          Rollback;
          p_Result := Err_Trx_No_Found;
      End;

      --TS_NOT_PRINTED代表未开票，发票可以开票
      If p_Result = Err_Ok And Nvl(Vtrxrow.State, Ts_Unknow) <> Ts_Not_Printed Then
        p_Result := Err_Trx_Cannt_Printed; --判断能不能开票
      End If;

      If p_Result = Err_Ok And Vtrxrow.Trx_Code Is Not Null Then
        p_Result := Err_Trx_Printed;
      End If;

      If p_Result = Err_Ok Then
        --状态更新为准备开票
        Update t_So_Trx_Headers Sth
        Set Sth.State = Ts_In_Queue, Sth.Last_Updated_By = p_User_Account, Sth.Last_Update_Date = Sysdate
        Where Sth.Idtrx_Id = p_Trx_Id;
      End If;

      If p_Result <> Err_Ok Then
        Rollback;
      End If;

    Exception
      When Others Then
        Rollback;
        p_Result := Err_Unknow || Sqlerrm;
    End;

  --------------------------------------------------------------------------
  --Author: Nicro.Li
  --Created: 2014-10-15
  --把发票池接口表的数据转换成正式发票池数据
  --------------------------------------------------------------------------
  Procedure p_Create_So_Trx(p_Trx_Oi_Header_Id In t_So_Trx_Oi_Headers.Toh_Id%Type, --转换用的接口ID
                            p_User_Code        In Varchar2, --用户ID
                            p_Trx_Header_Code  Out t_So_Trx_Headers.Trx_Header_Code%Type, --返回发票池头编码
                            p_Result           Out Varchar2 --返回值
                            ) Is
          --得到发票头
          Cursor c_Oi_Header(p_Header_Id In t_So_Trx_Oi_Headers.Toh_Id%Type) Is
            Select *
              From t_So_Trx_Oi_Headers Stoh
             Where Stoh.Toh_Id = p_Header_Id
               For Update Nowait;
          r_Oi_Head c_Oi_Header%Rowtype;

          --得到发票行
          Cursor c_Oi_Line(p_Header_Id In t_So_Trx_Oi_Lines.Toh_Id%Type,
                           p_Sign      Number,
                           p_Mixtrx    Varchar2) Is
            Select Tsl.So_Header_Id,
                   Tbi.Item_Code,
                   Tbi.Item_Name,
                   Tbi.Defaultunit Uom_Code,
                   Nvl(Tbi.Is_Virtual, Err_No) Is_Virtual,
                   Tol.*
              From t_So_Line Tsl, t_So_Trx_Oi_Lines Tol, t_Bd_Item Tbi
             Where Tsl.So_Line_Id = Tol.Line_Id
               And Tbi.Item_Id = Tol.Item_Id
               And Tbi.Entity_Id = Tol.Entity_Id
               And ((Tol.Price * (100 - Tol.Discount) / 100 * Tol.Quantity >= 0 And
                   p_Sign >= 0) --发票正数为主或总金额是0，则只取正数和0部分
                   Or (Tol.Price * (100 - Tol.Discount) / 100 * Tol.Quantity < 0 And
                   p_Sign < 0) --发票负数为主，则只取负部分
                   )
               And (Nvl(Tbi.Is_Virtual, Err_No) = Err_No Or p_Mixtrx = 'N') --如果是商品与补差混合型发票，则只拿出商品
               And Tol.Toh_Id = p_Header_Id;

          --得到会作为折扣合并进发票内的商品行
          Cursor c_Oi_Discount_Line(p_Header_Id In t_So_Trx_Oi_Lines.Toh_Id%Type,
                                    p_Sign      Number,
                                    p_Mixtrx    Varchar2) Is
            Select Tsl.So_Header_Id,
                   Stol.Entity_Id,
                   Stol.Line_Id,
                   Stol.Item_Id,
                   Stol.Price,
                   Stol.Quantity,
                   Stol.Discount,
                   Stol.Trx_Rate,
                   'Y' Discount_Split,
                    Nvl(Tbi.Is_Virtual, Err_No) Is_Virtual
              From t_So_Line Tsl, t_So_Trx_Oi_Lines Stol, t_Bd_Item Tbi
             Where Tsl.So_Line_Id = Stol.Line_Id
               And Tbi.Item_Id = Stol.Item_Id
               And Tbi.Entity_Id = Stol.Entity_Id
               And (((Stol.Price * (100 - Stol.Discount) / 100 * Stol.Quantity < 0 And
                   p_Sign >= 0) --发票正数为主，则只取余下的负部分
                   Or (Stol.Price * (100 - Stol.Discount) / 100 * Stol.Quantity > 0 And
                   p_Sign < 0)) --发票负数为主，则只取正数部分
                   )
               And (Nvl(Tbi.Is_Virtual, Err_No) = Err_No Or p_Mixtrx = Err_No)
               And Stol.Toh_Id = p_Header_Id
            Union All
            --取汇总的补价差，放到最大的行ID中
            --为保证补价差单据折扣，计算的完整性，先按折扣金额方向做汇总，把补价差单汇总成一个折扣行进行折扣拆分
            Select l.So_Header_Id,
                   Tl.Entity_Id,
                   Tl.Line_Id,
                   Tl.Item_Id,
                   Abs(Tl.Price) Price,
                   Decode(Tl.Price, 0, 1, Sign(Tl.Price)) Quantity,
                   Tl.Discount,
                   Tl.Trx_Rate,
                   'Y' Discount_Split,
                   Nvl(Tl.Is_Virtual, Err_No) Is_Virtual
              From (Select Stol.Entity_Id,
                           Max(Stol.Line_Id) Line_Id,
                           Stol.Item_Id,
                           Sum(Stol.Price * Stol.Quantity *
                               (1 - Nvl(Stol.Discount, 0) / 100)) Price,
                           1 Quantity,
                           0 Discount,
                           Stol.Trx_Rate,
                           Tbi.Is_Virtual
                      From t_So_Line Tsl, t_So_Trx_Oi_Lines Stol, t_Bd_Item Tbi
                     Where Tsl.So_Line_Id = Stol.Line_Id
                       And Tbi.Item_Id = Stol.Item_Id
                       And Nvl(Tbi.Is_Virtual, Err_No) = Err_Yes
                       And p_Mixtrx = 'Y' --如果是商品与补差混合型发票，则连补差单的行也拿过来
                       And Stol.Toh_Id = p_Header_Id
                     Group By Stol.Entity_Id, Stol.Item_Id, Stol.Trx_Rate,Tbi.Is_Virtual) Tl,
                   t_So_Line l
             Where Tl.Line_Id = l.So_Line_Id
            Union All
            --将其它的补价差行单价设置为0
            --Discount_Split ='N' 表示不参与折扣拆分行，只做发票与财务单关系行写入
            Select Tsl.So_Header_Id,
                   Stol.Entity_Id,
                   Stol.Line_Id,
                   Stol.Item_Id,
                   Stol.Price,
                   Stol.Quantity,
                   Stol.Discount,
                   Stol.Trx_Rate,
                   'N' Discount_Split,
                   Nvl(Tbi.Is_Virtual, Err_No) Is_Virtual 
              From t_So_Line Tsl, t_So_Trx_Oi_Lines Stol, t_Bd_Item Tbi
             Where Tsl.So_Line_Id = Stol.Line_Id
               And Stol.Item_Id = Tbi.Item_Id
               And Tbi.Entity_Id = Stol.Entity_Id
               And Nvl(Tbi.Is_Virtual, Err_No) = Err_Yes
               And p_Mixtrx = 'Y' --如果是商品与补差混合型发票，则连补差单的行也拿过来
               And Stol.Toh_Id = p_Header_Id
               And Stol.Line_Id <>
                   (Select Max(Ol.Line_Id)
                      From t_So_Trx_Oi_Lines Ol, t_Bd_Item Bi
                     Where Toh_Id = p_Header_Id
                       And Ol.Item_Id = Bi.Item_Id
                       And Bi.Entity_Id = Ol.Entity_Id
                       And Nvl(Bi.Is_Virtual, Err_No) = Err_Yes);

          --处理发票的折扣时，把发票商品行从大到小顺序处理(不理正负)
          Cursor c_Trx_Line(p_Trx_Id In t_So_Trx_Lines.Idtrx_Id%Type) Is
            Select Stl.*,
                   Stl.Price * (100 - Stl.Discount) / 100 * Stl.Quantity Sum_Amount
              From t_So_Trx_Lines Stl
             Where Stl.Price * (100 - Stl.Discount) / 100 * Stl.Quantity <> 0
               And Stl.Idtrx_Id = p_Trx_Id
             Order By Abs(Stl.Price * (100 - Stl.Discount) / 100 * Stl.Quantity) Desc;

          Type t_Discount_Line Is Table Of c_Oi_Discount_Line%Rowtype Index By Binary_Integer;
          v_Discount_Line t_Discount_Line;
          Type t_Order_Head_Id_List Is Table Of Number Index By Binary_Integer;
          v_Order_Head_Id_List t_Order_Head_Id_List;

          v_Count          Number;
          v_Taxpayer_Type  Varchar2(100);
          v_Dis_Trx_Type   Varchar2(100);
          v_Customer_Code  t_Customer_Header.Customer_Code%Type;
          v_So_Trx_Head_Id Number;
          v_So_Trx_Line_Id t_So_Trx_Lines.Trx_Line_Id%Type;

          v_Max_Trx_Amount    Number;
          v_Max_Discount_Rate Number;
          v_Trx_Discount_Rate Number;
          v_Trx_Rate          Number;
          v_Priced_If_Sign    Number;
          v_Trx_Amount_Sign   Number; --混合发票方向 1:正数发票  -1:负数发票

          v_Discount_Limit_Flag Varchar2(3);
          v_Cancel_Order_In_Trx Varchar2(3);
          v_Line_Data_Count     Number;
          v_Temp_Value          Number;
          v_Mix_Trx_Flag        Varchar2(3); --混合发票标志

          v_Hide_Discount_Line_Flag Varchar2(60);
          v_Line_Index              Number;

          v_Split_Affter_Qty      Number;
          v_Split_Befor_Qty       Number;
          v_Split_Discount        Number;
          v_Split_Affter_Discount Number;
          v_Split_Diff_Qty        Number; --合并数量差异

          v_So_Order_Discount Number;
          v_Split_Diff_Value  Number;

          v_Trx_Sum_Value  Number;

          v_Trx_Line_Rate  Number;

           v_Trx_Row_Count  Number;
           V_TRX_DISTRIBUTION_NEW varchar2(30);
           
           V_VALID_CCS_INVOICE_INFO VARCHAR2(30);--ADD BY huanghb12 是否启用美云销的开票信息 默认是Y-启用
           
           V_AR_CONF   TYPE_AR_CONF;
           V_WHETHER_SPLIT          VARCHAR2(2);--是否允许拆分
           V_ENTITY_CUST_FLAG       VARCHAR2(2);
           V_DISCOUNT_TAG    VARCHAR2(2);
           V_INTF_REQ_FLAG   VARCHAR2(2);
          
           V_SO_ALL_AMOUNT Number;   
           V_SO_DEVIATION_AMOUNT Number; 
           V_SO_DEVIATION_COUNT Number; 
           
           V_SO_TAX_AMOUNT Number; 
           
           V_CUSTOMER_REGISTRATION_CODE varchar2(50);
          
          V_IDENTIFICATION_NUMBER T_SO_INVOICE_INFO.IDENTIFICATION_NUMBER%TYPE;
          V_INVOICE_ADDRESS T_SO_TRX_HEADERS.INVOICE_ADDRESS%TYPE; --开票地址
          V_INVOICE_TEL T_SO_TRX_HEADERS.INVOICE_TEL%TYPE; --开票电话
          V_INVOICE_BANK T_SO_TRX_HEADERS.INVOICE_BANK%TYPE; --开户行
          V_INVOICE_BANK_ACCOUNT T_SO_TRX_HEADERS.INVOICE_BANK_ACCOUNT%TYPE; --银行账号
          
          V_invoice_contact T_SO_INVOICE_INFO.Invoice_Contact%TYPE;
          V_invoice_contact_Tel T_SO_INVOICE_INFO.Invoice_Contact_Tel%TYPE;
          V_invoice_contact_Addr T_SO_INVOICE_INFO.Invoice_Contact_Addr%TYPE;
          
          V_CHK_MSG VARCHAR2(1000);
        Begin
          p_Result := Err_Ok; 
          --正数补价差单：表示总部的收入单据，所以开票金额
          --负数补价差单：表示客户收入（奖励等）
          Open c_Oi_Header(p_Trx_Oi_Header_Id);
          Fetch c_Oi_Header
            Into r_Oi_Head;
          If c_Oi_Header%Notfound Then
            p_Result := '接口(TOH_ID=' || To_Char(p_Trx_Oi_Header_Id) ||
                        ')未找到数据，生成发票失败！';
            Raise v_Base_Exception;
          End If;
          r_Oi_Head.Trans_Type := Nvl(r_Oi_Head.Trans_Type, Tt_Normal);
          V_CUSTOMER_REGISTRATION_CODE := r_Oi_Head.Customer_Registration_Code;

          --检查回写标记。
          If Nvl(r_Oi_Head.Oi_Flag, 'N') = 'Y' Then
            p_Result := '接口数据(TOH_ID=' || To_Char(p_Trx_Oi_Header_Id) ||
                        ')已经被处理过，不能再次产生发票';
            Raise v_Base_Exception;
          End If;

          --检查发票合并的销售单据是否为同一经营组织
          Select Count(1)
            Into v_Count
            From (Select Tsh.Erp_Ou_Id
                    From t_So_Trx_Oi_Lines Tol, t_So_Line Tsl, t_So_Header Tsh
                   Where Tol.Line_Id = Tsl.So_Line_Id
                     And Tsl.So_Header_Id = Tsh.So_Header_Id
                     And Tol.Toh_Id = p_Trx_Oi_Header_Id
                   Group By Tsh.Erp_Ou_Id);
          If v_Count > 1 Then
            p_Result := '接口数据(TOH_ID=' || To_Char(p_Trx_Oi_Header_Id) ||
                        ')对应销售单据不是同一经营组织，开票失败。';
            Raise v_Base_Exception;
          End If;

              --检查发票行税率是否一致
          Select Count(1)
            Into v_Trx_Row_Count
            From (select trx_rate from t_So_Trx_Oi_Lines Tol where Tol.toh_id = p_Trx_Oi_Header_Id group by TRX_RATE);
          If v_Trx_Row_Count > 1 Then
            p_Result := '接口数据(TOH_ID=' || To_Char(p_Trx_Oi_Header_Id) ||
                        ')对应销售单行开票税率不一致，开票失败。';
            Raise v_Base_Exception;
          End If;
          
          Select TRX_RATE into v_Trx_Line_Rate from t_So_Trx_Oi_Lines Stol where  Stol.Toh_Id = p_Trx_Oi_Header_Id and rownum=1;
          
         --得到发票金额上限，折扣上限
         -- Select Trx_Rate, Max_Trx_Amount, Max_Discount_Limt
         --  Into v_Trx_Rate, v_Max_Trx_Amount, v_Max_Discount_Rate
         --   From Table(f_Get_Ar_Config(p_Entity_Id       => r_Oi_Head.Entity_Id,
         --                              p_Sales_Center_Id => r_Oi_Head.Sales_Center_Id,
         --                             p_Customer_Id     => r_Oi_Head.Trx_Customer_Id，
         --                               p_Ou_id           => r_Oi_Head.Erp_Ou_Id));--by anht 增加主体OU判断
         
       
          P_GET_AR_CONFIG(r_Oi_Head.Entity_Id
                           ,r_Oi_Head.Sales_Center_Id
                           ,r_Oi_Head.Trx_Customer_Id
                           ,r_Oi_Head.Erp_Ou_Id
                           ,V_AR_CONF
                         );       
          v_Trx_Rate  :=   V_AR_CONF.TRX_RATE;
          v_Max_Trx_Amount :=   V_AR_CONF.MAX_TRX_AMOUNT;
          v_Max_Discount_Rate := V_AR_CONF.MAX_DISCOUNT_LIMT;
          V_WHETHER_SPLIT := V_AR_CONF.WHETHER_SPLIT;      
        
         If v_Max_Trx_Amount Is Null Then
            v_Max_Trx_Amount := Unlimit_Trxamount;
          End If;
          If v_Max_Discount_Rate Is Null Then
            v_Max_Discount_Rate := 99;
          End If;
          
          v_Trx_Rate :=nvl(v_Trx_Line_Rate,v_Trx_Rate);
          
          If v_Trx_Rate Is Null Then
             --v_Trx_Rate := 17;
             v_Trx_Rate := Pkg_Bd.f_Get_Parameter_Value(p_Config_Code => 'AR_VAT_RATE',
                                                                    p_Entity_Id   => r_Oi_Head.Entity_Id);
            
          End If;
          If V_WHETHER_SPLIT Is Null Then
            V_WHETHER_SPLIT := 'Y';
          End If;
          
          --检查客户是否可以开增值税发票
          If p_Result = Err_Ok Then
            Begin
              Select Tch.Customer_Code, Tch.Customer_Registration_Type
                Into v_Customer_Code, v_Taxpayer_Type
                From t_Customer_Header Tch
               Where Tch.Customer_Id = r_Oi_Head.Trx_Customer_Id;
            Exception
              When No_Data_Found Then
                p_Result := '接口数据有误，客户ID' || r_Oi_Head.Trx_Customer_Id || '找不到';
                Raise v_Base_Exception;
            End;

            Select Count(1)
              Into v_Count
              From Up_Org_Unit Uou
             Where Uou.Unit_Id = r_Oi_Head.Sales_Center_Id;
            If v_Count <= 0 Then
              p_Result := '接口数据有误，营销中心ID' || To_Char(r_Oi_Head.Sales_Center_Id) ||
                          '找不到';
              Raise v_Base_Exception;
            End If;
          End If;

          --判断纳税人类型
          If p_Result = Err_Ok And
             Nvl(v_Taxpayer_Type, '无') Not In (Tpt_Commontaxpayer) And
             r_Oi_Head.Trx_Type = 'INCREMENT_TRX_MATCH' Then
            p_Result := '客户' || v_Customer_Code || '的纳税人类型是"' ||
                        Nvl(v_Taxpayer_Type, '无') || '"不能开增值税发票';
            Raise v_Base_Exception;
          End If;

          --判断状态
          If p_Result = Err_Ok And
             r_Oi_Head.State Not In (Ts_Not_Printed, Ts_In_Queue) Then
            p_Result := '接口数据有误，发票状态只能是TS_NOT_PRINTED或TS_IN_QUEUE';
            Raise v_Base_Exception;
          End If;

          If p_Result = Err_Ok Then
            --得到发票的正负方向
            Select Sign(Sum(Stol.Price * (100 - Stol.Discount) / 100 *
                            Stol.Quantity))
              Into v_Trx_Amount_Sign
              From t_So_Trx_Oi_Lines Stol
             Where Stol.Toh_Id = p_Trx_Oi_Header_Id;

            If v_Trx_Amount_Sign Is Null Then
              p_Result := '接口数据有误，发票头ID:' || p_Trx_Oi_Header_Id || '接口没有发票行';
              Raise v_Base_Exception;
            End If;
          End If;

          If p_Result = Err_Ok Then
            --得到补价差的正负方向
            Select Sign(Sum(Stol.Price * (100 - Stol.Discount) / 100 *
                            Stol.Quantity))
              Into v_Priced_If_Sign --注意，此变量可能为null
              From t_So_Trx_Oi_Lines Stol
             Where Stol.Toh_Id = p_Trx_Oi_Header_Id
               And Exists
             (Select 1
                      From t_Bd_Item i
                     Where i.Item_Id = Stol.Item_Id
                       And i.Entity_Id = Stol.Entity_Id
                       And Nvl(i.Is_Virtual, Err_No) = Err_Yes);
          End If;

          --取得配置数据
          If p_Result = Err_Ok Then
            Begin
              v_Discount_Limit_Flag := Pkg_Bd.f_Get_Parameter_Value(p_Config_Code => 'SO_TRX_DISCOUNT_LIMIT',
                                                                    p_Entity_Id   => r_Oi_Head.Entity_Id);
            Exception
              When Others Then
                p_Result := '获取主体参数失败，系统参数编码：SO_TRX_DISCOUNT_LIMIT ' || v_Nl ||
                            Sqlerrm;
                Raise v_Base_Exception;
            End;
            --得到当前主体是否允许无蓝单的红单开单票
            Begin
              v_Cancel_Order_In_Trx := Pkg_Bd.f_Get_Parameter_Value(p_Config_Code => 'SO_CANCEL_ORDER_IN_TRX',
                                                                    p_Entity_Id   => r_Oi_Head.Entity_Id);
            Exception
              When Others Then
                p_Result := '获取主体参数失败，系统参数编码：SO_CANCEL_ORDER_IN_TRX ' || v_Nl ||
                            Sqlerrm;
                Raise v_Base_Exception;
            End;

            --计算折扣率
            -- 正负补差为0里不能开票保存问题
            --正数补价差单：表示总部的收入单据，所以开票金额
            --负数补价差单：表示客户收入（奖励等）
            Select Decode(Sum(Decode(Nvl(Bi.Is_Virtual, Err_No),
                                     Err_No,
                                     Stol.Price * Stol.Quantity,
                                     Null)),
                          0,
                          0,
                          Sum(Decode(Nvl(Bi.Is_Virtual, Err_No),
                                     Err_Yes,
                                     -1 * Stol.Price * (100 - Stol.Discount) / 100 *
                                     Stol.Quantity,
                                     --补差单是算作折扣的，补差单的金额需要算作反向金额
                                     Stol.Price * Stol.Discount / 100 *
                                     Stol.Quantity)) * 100 /
                          Sum(Decode(Nvl(Bi.Is_Virtual, Err_No),
                                     Err_No,
                                     Stol.Price * Stol.Quantity,
                                     Null)))
              Into v_Trx_Discount_Rate
              From t_So_Trx_Oi_Lines Stol, t_Bd_Item Bi
             Where Stol.Toh_Id = p_Trx_Oi_Header_Id
               And Bi.Item_Id = Stol.Item_Id
               And Bi.Entity_Id = Stol.Entity_Id;
               
               
            v_Trx_Discount_Rate := round(v_Trx_Discount_Rate,2);    

            If  v_Trx_Discount_Rate > v_Max_Discount_Rate And
               v_Discount_Limit_Flag = Err_Yes Then
              p_Result := '发票的折扣率' || To_Char(v_Trx_Discount_Rate) ||
                          '%超出设置的开票上限' || To_Char(v_Max_Discount_Rate) ||
                          '%，不能保存';
              Raise v_Base_Exception;
            End If;

            --判断是否商品与补差混合型发票
            Select Count(*),
                   Count(Decode(Nvl(Tbi.Is_Virtual, Err_No),
                                Err_Yes,
                                Null,
                                Nvl(Tbi.Is_Virtual, Err_No)))
              Into v_Line_Data_Count, v_Temp_Value
              From t_So_Trx_Oi_Lines Stol, t_Bd_Item Tbi
             Where Stol.Toh_Id = p_Trx_Oi_Header_Id
               And Tbi.Item_Id = Stol.Item_Id
               And Tbi.Entity_Id = Stol.Entity_Id;
            --当没有补价差单(V_temp_value >0)时，相减为0
            If (v_Line_Data_Count - v_Temp_Value = 0 And v_Temp_Value > 0) Or
               v_Temp_Value = 0 --当有全都是补价差单时，vTempValue = 0
               Or r_Oi_Head.Trans_Type = Tt_Hide_Discount_Line --如果是“隐藏折扣，补差单独一行保存”，则算作非混合发票
             Then
              v_Mix_Trx_Flag := 'N';
            Else
              v_Mix_Trx_Flag := 'Y';
            End If;
          End If;
          
         V_TRX_DISTRIBUTION_NEW:= PKG_BD.F_GET_PARAMETER_VALUE('AR_TRX_DISTRIBUTION_GOODS', r_Oi_Head.Entity_Id, NULL, NULL);
         
         --是否启用美云销开票信息 add by huanghb12 20190925
          V_VALID_CCS_INVOICE_INFO:= PKG_BD.F_GET_PARAMETER_VALUE('IS_VALID_CCS_INVOICE_INFO', r_Oi_Head.Entity_Id, NULL, NULL);
         
         IF V_VALID_CCS_INVOICE_INFO = 'Y' THEN
            --校验销售单来源CCS订单开票信息一致性
         for r_invoice_info in (
           Select Distinct soh.so_num,
                           i.identification_number,
                           i.invoice_address,
                           i.invoice_tel,
                           i.invoice_bank,
                           i.invoice_bank_account,
                           i.invoice_contact,
                           i.invoice_contact_tel,
                           i.invoice_contact_addr
             From t_So_Line Sol,
                  t_So_Trx_Oi_Lines Stol,
                  t_so_header soh,
                  t_so_invoice_info i
            Where Sol.So_Line_Id = Stol.Line_Id
              and sol.so_header_id = soh.so_header_id
              and soh.entity_id = i.entity_id(+)
              and soh.sys_source_order_num = i.source_order_number(+)
              And Stol.Toh_Id = p_Trx_Oi_Header_Id
            order by i.identification_number,
                     i.invoice_address,
                     i.invoice_tel,
                     i.invoice_bank,
                     i.invoice_bank_account)
          loop
            --税号
            if V_IDENTIFICATION_NUMBER is null or nvl(r_invoice_info.identification_number, '_') = nvl(V_IDENTIFICATION_NUMBER, '_') then
              V_IDENTIFICATION_NUMBER := r_invoice_info.identification_number;
            else
              if V_CHK_MSG is null then
                V_CHK_MSG := '税号';
              else 
                V_CHK_MSG := V_CHK_MSG || '、税号';
              end if;
            end if;
            --开票地址
            if V_INVOICE_ADDRESS is null or nvl(r_invoice_info.invoice_address, '_') = nvl(V_INVOICE_ADDRESS, '_') then
              V_INVOICE_ADDRESS := r_invoice_info.invoice_address;
            else
              if V_CHK_MSG is null then
                V_CHK_MSG := '开票地址';
              else 
                V_CHK_MSG := V_CHK_MSG || '、开票地址';
              end if;
            end if;
            --开票电话
            if V_INVOICE_TEL is null or nvl(r_invoice_info.invoice_tel, '_') = nvl(V_INVOICE_TEL, '_') then
              V_INVOICE_TEL := r_invoice_info.invoice_tel;
            else
              if V_CHK_MSG is null then
                V_CHK_MSG := '开票电话';
              else 
                V_CHK_MSG := V_CHK_MSG || '、开票电话';
              end if;
            end if;
            --开户行
            if V_INVOICE_BANK is null or nvl(r_invoice_info.invoice_bank, '_') = nvl(V_INVOICE_BANK, '_') then
              V_INVOICE_BANK := r_invoice_info.invoice_bank;
            else
              if V_CHK_MSG is null then
                V_CHK_MSG := '开户行';
              else 
                V_CHK_MSG := V_CHK_MSG || '、开户行';
              end if;
            end if;
            --银行账号
            if V_INVOICE_BANK_ACCOUNT is null or nvl(r_invoice_info.invoice_bank_account, '_') = nvl(V_INVOICE_BANK_ACCOUNT, '_') then
              V_INVOICE_BANK_ACCOUNT := r_invoice_info.invoice_bank_account;
            else
              if V_CHK_MSG is null then
                V_CHK_MSG := '银行账号';
              else 
                V_CHK_MSG := V_CHK_MSG || '、银行账号';
              end if;
            end if;
            
            if V_CHK_MSG is not null then
              p_Result := '待开票销售单存在' || V_CHK_MSG || '等开票信息不一致，不能保存';
              Raise v_Base_Exception;
            end if;
            
            --收票人
            if V_invoice_contact is null or nvl(r_invoice_info.invoice_contact, '_') = nvl(V_invoice_contact, '_') then
              V_invoice_contact := r_invoice_info.invoice_contact;
            end if;
            --收票人电话
            if V_invoice_contact_tel is null or nvl(r_invoice_info.invoice_contact_tel, '_') = nvl(V_invoice_contact_tel, '_') then
              V_invoice_contact_tel := r_invoice_info.invoice_contact_tel;
            end if;
            --收票地址
            if V_invoice_contact_addr is null or nvl(r_invoice_info.invoice_contact_addr, '_') = nvl(V_invoice_contact_addr, '_') then
              V_invoice_contact_addr := r_invoice_info.invoice_contact_addr;
            end if;
            
          end loop;
         
         END IF;
         
        
          --插入头数据
          If p_Result = Err_Ok Then
                Select s_So_Trx_Headers.Nextval Into v_So_Trx_Head_Id From Dual;
                --生成发票池编码
                p_Trx_Header_Code := Trim(To_Char(v_So_Trx_Head_Id, '0000000000'));
                --发票池编码替换，如果用户把替换的字符串删除掉，就不会有发票池编码在备注上。
                r_Oi_Head.Comments := Replace(r_Oi_Head.Comments,
                                              Mc_Trx_Header_Code,
                                              p_Trx_Header_Code);

                --判断是否隐藏折扣行
                If r_Oi_Head.Trans_Type = Tt_Hide_Discount_Line Then
                  v_Hide_Discount_Line_Flag := 'N'; --隐藏即不显示折扣折让行
                Else
                  v_Hide_Discount_Line_Flag := 'Y';
                End If;
                Begin
                  --产生发票池头数据
                  Insert Into t_So_Trx_Headers
                    (Idtrx_Id,
                     Created_By,
                     Creation_Date,
                     Last_Updated_By,
                     Last_Update_Date,
                     Trx_Header_Code,
                     Trx_Code,
                     Trx_Type,
                     Trx_Date,
                     Trx_Checker,
                     Trx_Maker,
                     Comments,
                     Printable,
                     State,
                     Center_Sign_Flag,
                     Customer_Sign_Flag,
                     Hq_Sign_Flag,
                     Ems_Code,
                     Have_Signin_Flag,
                     Center_Sign_Date,
                     Customer_Sign_Date,
                     Hq_Sign_Date,
                     Hide_Discount_Line,
                     Erp_Ou_Id,
                     Voucher_Header_Id,
                     Voucher_Number,
                     Sales_Center_Id,
                     Customer_Id,
                     Entity_Id,
                     Trx_Flag,
                     Trx_Account,
                     Trx_Ratepayer_Type,
                     Signin_Code,
                     Account_Id,
                     Attribute1,
                     Attribute2,
                     Attribute3,
                     Attribute4,
                     Attribute5,
                     Attribute6,
                     INVOICE_CORPORATION,
                     CUSTOMER_CODE,
                     CUSTOMER_NAME
                     )--开票单位 add by anht
                  Values
                    (v_So_Trx_Head_Id, --Idtrx_Id,
                     p_User_Code, --Created_By,
                     Sysdate, --Creation_Date,
                     p_User_Code, --Last_Updated_By,
                     Sysdate, --Last_Update_Date,
                     p_Trx_Header_Code, --Trx_Header_Code 发票池编码
                     Null, --Trx_Code  发票号
                     r_Oi_Head.Trx_Type, --Trx_Type,  发票类型
                     /*Trunc(Sysdate), --Trx_Date,  开票日期*/
                     null,--bu anht Trx_Date,  开票日期
                     Null, --Trx_Checker,  复核
                     p_User_Code, --Trx_Maker,    开票人
                     r_Oi_Head.Comments, --Comments,    备注
                     'Y', --Printable,   可以打印
                     Ts_In_Queue, --State,       发票状态
                     'N', --Center_Sign_Flag,  中心接收
                     'N', --Customer_Sign_Flag, 客户签收
                     'N', --Hq_Sign_Flag,       总部回执
                     Null, --Ems_Code, EMS单号
                     Null, --Have_Signin_Flag,   已建回执
                     Null, --Center_Sign_Date,   中心签收日期
                     Null, --Customer_Sign_Date,  客户签收日期
                     Null, --Hq_Sign_Date,        总部回执日期
                     v_Hide_Discount_Line_Flag, --Hide_Discount_Line,  隐藏折扣行
                     r_Oi_Head.Erp_Ou_Id, --Erp_Ou_Id,           OU_ID经营组织ID
                     Null, --Voucher_Header_Id,   凭证头ID
                     Null, --Voucher_Number,      凭证编码
                     r_Oi_Head.Sales_Center_Id, --Sales_Center_Id,     中心ID
                     r_Oi_Head.Trx_Customer_Id, --Customer_Id,         客户ID
                     r_Oi_Head.Entity_Id, --Entity_Id,           主体ID
                     'N', --Trx_Flag,            是否开票
                     Null, --Trx_Account,         发票金额
                     v_Taxpayer_Type, --Trx_Ratepayer_Type,  纳税人类型
                     Null, --Signin_Code,         回执编码
                     r_Oi_Head.Account_Id, --Account_Id,
                     Null, --Attribute1,
                     Null, --Attribute2,
                     Null, --Attribute3,
                     Null, --Attribute4,
                     Null, --Attribute5,
                     r_Oi_Head.Trans_Type, --Attribute6
                     r_Oi_Head.Invoice_Corporation,
                     r_Oi_Head.ATTRIBUTE1,
                     r_Oi_Head.ATTRIBUTE2
                     );--开票单位 add by anht
                Exception
                  When Others Then
                    p_Result := '插入发票池头表失败。' || v_Nl || Sqlerrm || v_Nl || Sqlcode;
                    Raise v_Base_Exception;
                End;
                
              If r_Oi_Head.Trans_Type in(Tt_DISCOUNT_DISTRIBUTION_GOODS,Tt_RETURN_DISTRIBUTION_GOODS) Then
                   p_Create_So_Trx_Added(p_Trx_Oi_Header_Id,p_User_Code,v_So_Trx_Head_Id,v_Max_Discount_Rate,v_Cancel_Order_In_Trx,v_Trx_Rate,p_Result);
              else 
                
                If r_Oi_Head.Trans_Type = Tt_Single_Batch_Row Then
                  r_Oi_Head.Trans_Param := Nvl(r_Oi_Head.Trans_Param, '一批商品');

                  Select s_So_Trx_Lines.Nextval Into v_So_Trx_Line_Id From Dual;

                  --向头关系表放数据
                  Insert Into t_So_Trx_Header_Relation
                    (Id, Idtrx_Id, So_Head_Id)
                    Select s_So_Trx_Header_Relation.Nextval, So.*
                      From (Select Distinct v_So_Trx_Head_Id, Sol.So_Header_Id
                              From t_So_Line Sol, t_So_Trx_Oi_Lines Stol
                             Where Sol.So_Line_Id = Stol.Line_Id
                               And Stol.Toh_Id = p_Trx_Oi_Header_Id) So;

                  --向关系表放数据
                  Begin
                    Insert Into t_So_Trx_Line_Relation
                      (Id,
                       Trx_Line_Id,
                       So_Line_Id,
                       Quantity,
                       Price,
                       Discount,
                       Discount_Flag,
                       So_Order_Discount)
                      Select s_So_Trx_Line_Relation.Nextval,
                             v_So_Trx_Line_Id,
                             Stol.Line_Id,
                             Stol.Quantity,
                             Stol.Price,
                             Stol.Discount,
                             'N',
                             Stol.Discount
                        From t_So_Trx_Oi_Lines Stol
                       Where Stol.Toh_Id = p_Trx_Oi_Header_Id;
                  End;
                  --向发票行表放虚拟商品
                  Insert Into t_So_Trx_Lines
                    (Trx_Line_Id,
                     Item_Id,
                     Idtrx_Id,
                     Created_By,
                     Creation_Date,
                     Last_Updated_By,
                     Last_Update_Date,
                     Item_Name,
                     Item_Model,
                     Item_Code,
                     Item_Unit,
                     Quantity,
                     Price,
                     Discount,
                     Trx_Rate,
                     Entity_Id)
                    Select v_So_Trx_Line_Id,
                       --  -100,
                           (select i.item_id from cims.t_bd_item i
                               where i.item_code='Z0000000000002' and i.entity_id=r_Oi_Head.Entity_Id), --by xusw
                           v_So_Trx_Head_Id,
                           p_User_Code,
                           Sysdate,
                           p_User_Code,
                           Sysdate,
                           r_Oi_Head.Trans_Param,
                           Null,
                           'Z0000000000002', --by xusw
                           Null,
                           1,
                            --计算发票金额 --by xusw
                           Decode(v_Mix_Trx_Flag,'Y',
                           (Select Sum(Stol.Price * Stol.Quantity)
                              From t_So_Trx_Oi_Lines Stol, t_Bd_Item Bi
                             Where Stol.Toh_Id = p_Trx_Oi_Header_Id
                               And Bi.Entity_Id = r_Oi_Head.Entity_Id
                               And Bi.Item_Id = Stol.Item_Id
                               And Stol.Item_Id > 0),
                               (Select Sum(Stol.Price * Stol.Quantity)
                              From t_So_Trx_Oi_Lines Stol, t_Bd_Item Bi
                             Where Stol.Toh_Id = p_Trx_Oi_Header_Id
                               And Bi.Entity_Id = r_Oi_Head.Entity_Id
                               And Bi.Item_Id = Stol.Item_Id
                               ))
                           ,
                           nvl(v_Trx_Discount_Rate,0), --by xusw
                           --计算折扣率
                           v_Trx_Rate,
                           r_Oi_Head.Entity_Id
                      From Dual;
                Else
                  --为行操作初始化
                  v_Order_Head_Id_List.Delete();
                  v_Line_Index := 0;

                  --初步形成发票行数据，即只放入纯正数或纯负数的有效商品行
                  For r_Oi_Line In c_Oi_Line(p_Trx_Oi_Header_Id,
                                             v_Trx_Amount_Sign,
                                             v_Mix_Trx_Flag) Loop
                    --如果在列表v_Order_Head_Id_List中找不到销售单头ID，则向头关系表放入关系数据
                    If Not v_Order_Head_Id_List.Exists(r_Oi_Line.So_Header_Id) Then
                      v_Order_Head_Id_List(r_Oi_Line.So_Header_Id) := r_Oi_Line.So_Header_Id;
                      Insert Into t_So_Trx_Header_Relation
                        (Id, Idtrx_Id, So_Head_Id)
                      Values
                        (s_So_Trx_Header_Relation.Nextval,
                         v_So_Trx_Head_Id,
                         r_Oi_Line.So_Header_Id);
                    End If;

                    --尝试更新商品行的数量，需要相同物料ID、价格和折扣。
                    If r_Oi_Line.Is_Virtual = Err_No Then
                      -- 普通商品
                      Update t_So_Trx_Lines Stl
                         Set Stl.Quantity = Stl.Quantity + r_Oi_Line.Quantity,
                             Stl.Discount = Decode(Stl.Quantity + r_Oi_Line.Quantity,
                                                   0,
                                                   Stl.Discount,
                                                   (Stl.Quantity * Stl.Discount +
                                                   r_Oi_Line.Quantity *
                                                   r_Oi_Line.Discount) /
                                                   (Stl.Quantity + r_Oi_Line.Quantity)) --求出新折扣率是多少
                       Where Stl.Idtrx_Id = v_So_Trx_Head_Id
                         And Stl.Item_Id = r_Oi_Line.Item_Id
                            --忽略折扣合并时，不同产品折扣行可合并到同一发票行
                         And (Stl.Discount = r_Oi_Line.Discount Or
                             r_Oi_Head.Trans_Type = Tt_Ignore_Discount)
                         And Stl.Price = r_Oi_Line.Price
                         and nvl(Stl.TRX_RATE,0) = nvl(r_Oi_Line.TRX_RATE,0)   --不同税率的不能合并
                      Returning Stl.Trx_Line_Id Into v_So_Trx_Line_Id;
                    Else
                      --当是补价差单合并，把价格相加（注：现在没有允许这种业务，这段代码应该不会被执行）
                      Update t_So_Trx_Lines Stl
                         Set Stl.Price = Stl.Price + r_Oi_Line.Price
                       Where Stl.Idtrx_Id = v_So_Trx_Head_Id
                         And Stl.Item_Id = r_Oi_Line.Item_Id
                         And Stl.Discount = r_Oi_Line.Discount
                      Returning Stl.Trx_Line_Id Into v_So_Trx_Line_Id;
                    End If;
                    --如果没有更新成功，就添加新的
                    If Sql%Rowcount <= 0 Then
                      Select s_So_Trx_Lines.Nextval Into v_So_Trx_Line_Id From Dual;
                      If r_Oi_Line.Is_Virtual = Err_No Then
                        Insert Into t_So_Trx_Lines
                          (Trx_Line_Id,
                           Item_Id,
                           Idtrx_Id,
                           Created_By,
                           Creation_Date,
                           Last_Updated_By,
                           Last_Update_Date,
                           Item_Name,
                           Item_Model,
                           Item_Code,
                           Item_Unit,
                           Quantity,
                           Price,
                           Discount,
                           Trx_Rate,
                           Entity_Id)
                        Values
                          (v_So_Trx_Line_Id, --Trx_Line_Id,
                           r_Oi_Line.Item_Id, --Item_Id,
                           v_So_Trx_Head_Id, --Idtrx_Id,
                           p_User_Code, --Created_By,
                           Sysdate, --Creation_Date,
                           p_User_Code, --Last_Updated_By,
                           Sysdate, --Last_Update_Date,
                           r_Oi_Line.Item_Name, --Item_Name,
                           Null, --Item_Model,
                           r_Oi_Line.Item_Code, --Item_Code,
                           r_Oi_Line.Uom_Code, --Item_Unit,
                           r_Oi_Line.Quantity, --Quantity,
                           r_Oi_Line.Price, --Price,
                           r_Oi_Line.Discount, --Discount,
                           v_Trx_Rate, --Trx_Rate,  取销售单上税率
                           r_Oi_Head.Entity_Id --Entity_Id
                           );
                      Else
                        --补价差则以补价差总额的符号作为数量
                        Insert Into t_So_Trx_Lines
                          (Trx_Line_Id,
                           Idtrx_Id,
                           Created_By,
                           Creation_Date,
                           Last_Updated_By,
                           Last_Update_Date,
                           Item_Id,
                           Item_Name,
                           Item_Model,
                           Item_Code,
                           Item_Unit,
                           Quantity,
                           Price,
                           Discount,
                           Trx_Rate,
                           Entity_Id)
                        Values
                          (v_So_Trx_Line_Id, --Trx_Line_Id,
                           v_So_Trx_Head_Id, --Idtrx_Id,
                           p_User_Code, --Created_By,
                           Sysdate, --Creation_Date,
                           p_User_Code, --Last_Updated_By,
                           Sysdate, --Last_Update_Date,
                           r_Oi_Line.Item_Id, --Item_Id,
                           r_Oi_Line.Item_Name, --Item_Name,
                           Null, --Item_Model,
                           r_Oi_Line.Item_Code, --Item_Code,
                           r_Oi_Line.Uom_Code, --Item_Unit,
                           Decode(v_Priced_If_Sign,
                                  0,
                                  r_Oi_Line.Quantity,
                                  v_Priced_If_Sign), --Quantity,
                           r_Oi_Line.Price, --Price,
                           r_Oi_Line.Discount, --Discount,
                           v_Trx_Rate, --Trx_Rate,
                           r_Oi_Head.Entity_Id --Entity_Id
                           );
                      End If;
                    End If;
                    --无轮是新增还是修改原商品行的数量，关系表都不会存在销售单行与这个发票行的关系，所以要新增
                    Insert Into t_So_Trx_Line_Relation
                      (Id,
                       Trx_Line_Id,
                       So_Line_Id,
                       Quantity,
                       Price,
                       Discount,
                       Discount_Flag,
                       So_Order_Discount)
                    Values
                      (s_So_Trx_Line_Relation.Nextval,
                       v_So_Trx_Line_Id,
                       r_Oi_Line.Line_Id,
                       r_Oi_Line.Quantity,
                       r_Oi_Line.Price,
                       r_Oi_Line.Discount,
                       'N',
                       0);
                  End Loop;
                  If v_Order_Head_Id_List.Count <= 0 Then
                    p_Result := '出现不明错误，没有产生发票行，TOH_ID' || p_Trx_Oi_Header_Id;
                    Raise v_Base_Exception;
                  End If;

                  --向v_Discount_Line数组放入折扣行数据
                  If p_Result = Err_Ok Then
                    v_Count := 0;
                    For Vlinedata In c_Oi_Discount_Line(p_Trx_Oi_Header_Id,
                                                        v_Trx_Amount_Sign,
                                                        v_Mix_Trx_Flag) Loop
                      v_Discount_Line(v_Count) := Vlinedata;
                      v_Count := v_Count + 1;
                    End Loop;
                  End If;

                  --处理冲销的商品
                  If p_Result = Err_Ok And v_Discount_Line.Count > 0 Then
                    For i In v_Discount_Line.First .. v_Discount_Line.Last Loop
                      --如果在列表v_Order_Head_Id_List中找不到销售单头ID，则向头关系表放入关系数据
                      If v_Discount_Line.Exists(i) And
                         Not
                          v_Order_Head_Id_List.Exists(v_Discount_Line(i).So_Header_Id) Then
                        v_Order_Head_Id_List(v_Discount_Line(i).So_Header_Id) := v_Discount_Line(i)
                                                                                 .So_Header_Id;
                        Insert Into t_So_Trx_Header_Relation
                          (Id, Idtrx_Id, So_Head_Id)
                        Values
                          (s_So_Trx_Header_Relation.Nextval,
                           v_So_Trx_Head_Id,
                           v_Discount_Line(i).So_Header_Id);
                      End If;

                      If Not v_Discount_Line.Exists(i) Then
                        Null;
                      Elsif v_Discount_Line(i).Is_Virtual = Err_No Then
                        -- 普通商品
                        Begin
                          Select Stl.Quantity, Stl.Trx_Line_Id, Stl.Discount
                            Into v_Split_Befor_Qty,
                                 v_So_Trx_Line_Id,
                                 v_Split_Discount
                            From t_So_Trx_Lines Stl
                           Where Stl.Idtrx_Id = v_So_Trx_Head_Id
                             And Stl.Item_Id = v_Discount_Line(i).Item_Id
                             And Stl.Price = v_Discount_Line(i).Price
                                --匆略折扣合并财务单行
                             And (Stl.Discount = v_Discount_Line(i).Discount Or
                                 r_Oi_Head.Trans_Type = Tt_Ignore_Discount)
                             For Update;

                          --计算商品冲掉之后数量应该是多少
                          --合并后数量 = 发票行数量 + 折扣合并行数量
                          v_Split_Affter_Qty := v_Split_Befor_Qty + v_Discount_Line(i)
                                               .Quantity;

                          --如果互冲之后数量为0,但出现折扣不一样的情况，将不能互冲,这里逻辑取反(not)，使得循环可以继续
                          If Not (v_Split_Affter_Qty = 0 And
                              v_Split_Discount <> v_Discount_Line(i).Discount) Then
                            v_Split_Diff_Qty := v_Discount_Line(i)
                                                .Quantity - v_Split_Affter_Qty;
                            --如果剩余的数量与反向商品数量的符号相同，即冲过头了，这时发票里的商品行数量应该是0,然后剩余部分商品用于作为折扣合进发票行中
                            If Sign(v_Split_Affter_Qty) =
                               Sign(v_Discount_Line(i).Quantity) Then
                              v_Discount_Line(i).Quantity := v_Split_Affter_Qty;
                              v_Split_Affter_Qty := 0;
                            Else
                              --符号不同，也可能是0，没冲过头，冲销商品的数量清0
                              v_Split_Diff_Qty := v_Discount_Line(i).Quantity;
                              v_Discount_Line(i).Quantity := 0;
                            End If;

                            Insert Into t_So_Trx_Line_Relation
                              (Id,
                               Trx_Line_Id,
                               So_Line_Id,
                               Quantity,
                               Price,
                               Discount,
                               Discount_Flag,
                               So_Order_Discount)
                            Values
                              (s_So_Trx_Line_Relation.Nextval,
                               v_So_Trx_Line_Id,
                               v_Discount_Line(i).Line_Id,
                               v_Split_Diff_Qty,
                               v_Discount_Line(i).Price,
                               v_Discount_Line(i).Discount,
                               'N',
                               0);

                            --折扣不一样的话，即r_oi_head.Trans_Type = TT_IGNORE_DISCOUNT，需要重算商品行的折扣率
                            If v_Split_Discount != v_Discount_Line(i).Discount Then
                              Select Decode(Sum(Decode(Nvl(Tbi.Is_Virtual, 'N'),
                                                       'N',
                                                       Stlr.Price * Stlr.Quantity,
                                                       Null)),
                                            0,
                                            0,
                                            Sum(Decode(Nvl(Tbi.Is_Virtual, 'N'),
                                                       'Y',
                                                       -1 * Stlr.Price *
                                                       (100 - Stlr.Discount) / 100 *
                                                       Stlr.Quantity
                                                       --补差单是算作折扣的，补差单的金额需要算作反向金额
                                                      ,
                                                       Stlr.Price * Stlr.Discount / 100 *
                                                       Stlr.Quantity)) * 100 /
                                            Sum(Decode(Nvl(Tbi.Is_Virtual, 'N'),
                                                       'N',
                                                       Stlr.Price * Stlr.Quantity,
                                                       Null)))
                                Into v_Split_Affter_Discount
                                From t_So_Line              Sol,
                                     t_So_Trx_Line_Relation Stlr,
                                     t_Bd_Item              Tbi
                               Where Sol.So_Line_Id = Stlr.So_Line_Id
                                 And Sol.Item_Id = Tbi.Item_Id
                                 And Stlr.Trx_Line_Id = v_So_Trx_Line_Id;
                            Else
                              v_Split_Affter_Discount := v_Split_Discount;
                            End If;

                            Update t_So_Trx_Lines Stl
                               Set Stl.Quantity = v_Split_Affter_Qty,
                                   Stl.Discount = Nvl(v_Split_Affter_Discount,
                                                      v_Split_Discount)
                             Where Stl.Trx_Line_Id = v_So_Trx_Line_Id;
                          End If;
                        Exception
                          When No_Data_Found Then
                            --没有找到任何数据，即这个反向的商品找不到要冲的正向商品
                            --并且系统设定这个主体不能红单与销售单合并,或者发票金额是0,就报错。
                            If v_Cancel_Order_In_Trx = 'Y' Or v_Trx_Amount_Sign = 0 Then
                              p_Result := '经检查，所产生的发票行的商品数量不全是正数或负数，无法保存';
                              Exit;
                            End If;
                        End;
                      Else
                        --补价差单类商品冲销
                        If v_Discount_Line(i).Discount_Split = 'Y' Then
                          Declare
                            v_Split_Amount      Number;
                            v_Split_Diff_Amount Number;
                          Begin
                            Select Stl.Price, Stl.Quantity, Stl.Trx_Line_Id
                              Into v_Split_Amount, v_Priced_If_Sign, v_So_Trx_Line_Id
                              From t_So_Trx_Lines Stl
                             Where Stl.Idtrx_Id = v_So_Trx_Head_Id
                               And Stl.Item_Id = v_Discount_Line(i).Item_Id
                               And Stl.Discount = v_Discount_Line(i).Discount
                               For Update;

                            --计算商品冲掉之后数量应该是多少
                            v_Split_Amount      := (v_Split_Amount * v_Priced_If_Sign + v_Discount_Line(i)
                                                   .Price * v_Discount_Line(i)
                                                   .Quantity) / v_Priced_If_Sign;
                            v_Split_Diff_Amount := v_Discount_Line(i)
                                                   .Price * v_Discount_Line(i)
                                                   .Quantity -
                                                    v_Split_Amount * v_Priced_If_Sign;
                            --如果剩余的金额与反向商品金额的符号相同，即冲过头了，这时发票里的商品行金额应该是0,然后剩余部分商品用于作为折扣合进发票行中
                            If Sign(v_Split_Amount * v_Priced_If_Sign) =
                               Sign(v_Discount_Line(i)
                                    .Price * v_Discount_Line(i).Quantity) Then
                              v_Discount_Line(i).Price := v_Split_Amount / v_Discount_Line(i)
                                                         .Quantity;
                              v_Split_Affter_Qty := 0;
                            Else
                              --符号不同，也可能是0，没冲过头，冲销商品的金额清0
                              v_Split_Diff_Amount := v_Discount_Line(i).Price;
                              v_Discount_Line(i).Price := 0;
                            End If;

                            Update t_So_Trx_Lines Stl
                               Set Stl.Price    = v_Split_Amount,
                                   Stl.Quantity = Decode(v_Split_Amount,
                                                         0,
                                                         0,
                                                         Stl.Quantity)
                             Where Stl.Trx_Line_Id = v_So_Trx_Line_Id;

                            Begin
                              --折让单据已汇总合并金额，只需更新关系表
                              Insert Into t_So_Trx_Line_Relation
                                (Id,
                                 Trx_Line_Id,
                                 So_Line_Id,
                                 Quantity,
                                 Price,
                                 Discount,
                                 Discount_Flag,
                                 So_Order_Discount)
                              Values
                                (s_So_Trx_Line_Relation.Nextval,
                                 v_So_Trx_Line_Id,
                                 v_Discount_Line(i).Line_Id,
                                 v_Discount_Line(i).Quantity,
                                 v_Split_Diff_Amount,
                                 v_Discount_Line(i).Discount,
                                 'N',
                                 0);
                            Exception
                              When Dup_Val_On_Index Then
                                Null;
                            End;
                          Exception
                            When No_Data_Found Then
                              If v_Mix_Trx_Flag = 'N' And
                                 r_Oi_Head.Trans_Type <> Tt_Hide_Discount_Line Then
                                --混合发票的补价差单是当作折扣合进发票商品行的，不需要报错，反之，需要报个错误
                                p_Result := '反向金额的虚拟产品找不到冲销的发票行，无法保存';
                                Exit;
                              End If;
                          End;
                        End If;
                      End If;

                      --如果商品行处理完，一般是价格或数量是0，就可以从数组中删除
                      If v_Discount_Line(i)
                       .Price * (100 - v_Discount_Line(i).Discount) / 100 * v_Discount_Line(i)
                         .Quantity = 0 Or v_Discount_Line(i).Discount_Split = 'N' Then
                        --删除之前先写关系表
                        Begin
                          Insert Into t_So_Trx_Line_Relation
                            (Id,
                             Trx_Line_Id,
                             So_Line_Id,
                             Quantity,
                             Price,
                             Discount,
                             Discount_Flag,
                             So_Order_Discount)
                          Values
                            (s_So_Trx_Line_Relation.Nextval,
                             v_So_Trx_Line_Id,
                             v_Discount_Line(i).Line_Id,
                             v_Discount_Line(i).Quantity,
                             v_Discount_Line(i).Price,
                             v_Discount_Line(i).Discount,
                             'N',
                             0);
                        Exception
                          When Dup_Val_On_Index Then
                            Null;
                        End;
                        v_Discount_Line.Delete(i);
                      End If;
                    End Loop;
                  End If;

                  --处理完商品冲销，还有剩的，比如是补价差单或反向数量商品作为折扣合进商品行中。
                  --当V_trx_amount_sign =0 时，运行到这里的v_Discount_Line.count一定是0,否则P_RESULT会有错误信息
                  If p_Result = Err_Ok And v_Discount_Line.Count > 0 Then
                    For i In v_Discount_Line.First .. v_Discount_Line.Last Loop
                      If Not v_Discount_Line.Exists(i) Then
                        Null;
                      Elsif v_Discount_Line(i).Is_Virtual = 'N' Then
                        v_So_Order_Discount := v_Discount_Line(i).Discount;
                        For v_Trx_Line In c_Trx_Line(v_So_Trx_Head_Id) Loop
                          --vTempValue是折扣,把v_Discount_Line(i)的行金额加上原来vTrxLineData的折扣金额，算出初算的折扣率
                          v_Split_Discount := (v_Trx_Line.Price * v_Trx_Line.Discount / 100 *
                                              v_Trx_Line.Quantity - v_Discount_Line(i)
                                              .Price *
                                              (100 - v_Discount_Line(i).Discount) / 100 * v_Discount_Line(i)
                                              .Quantity) /
                                              (v_Trx_Line.Price * v_Trx_Line.Quantity) * 100;

                          --合上补价差行的金额超过了折扣上限
                          If (Abs(v_Split_Discount) > v_Max_Discount_Rate) Then
                            --超过折扣上限时把商品行折扣设置成最大折扣
                            v_Split_Discount   := v_Max_Discount_Rate *
                                                  Sign(v_Split_Discount);
                            v_Split_Diff_Value := (v_Discount_Line(i)
                                                  .Price * v_Discount_Line(i).Quantity *
                                                   (v_Discount_Line(i).Discount) / 100 +
                                                   (v_Trx_Line.Price *
                                                   v_Trx_Line.Quantity *
                                                   (v_Trx_Line.Discount -
                                                   v_Split_Discount) / 100)) /
                                                  (v_Discount_Line(i)
                                                  .Price * v_Discount_Line(i).Quantity) * 100;

                            v_Discount_Line(i).Discount := v_Split_Diff_Value;
                          Else
                            --改成折扣率100
                            v_Split_Diff_Value := v_Discount_Line(i).Discount;
                            v_Discount_Line(i).Discount := 100;
                          End If;

                          --更新发票商品行的折扣率
                          Update t_So_Trx_Lines Stl
                             Set Stl.Discount = v_Split_Discount
                           Where Stl.Trx_Line_Id = v_Trx_Line.Trx_Line_Id;

                          Insert Into t_So_Trx_Line_Relation
                            (Id,
                             Trx_Line_Id,
                             So_Line_Id,
                             Quantity,
                             Price,
                             Discount,
                             Discount_Flag,
                             So_Order_Discount)
                          Values
                            (s_So_Trx_Line_Relation.Nextval,
                             v_Trx_Line.Trx_Line_Id,
                             v_Discount_Line(i).Line_Id,
                             v_Discount_Line(i).Quantity,
                             v_Discount_Line(i).Price,
                             v_Discount_Line(i).Discount,
                             'Y',
                             v_So_Order_Discount);
                          If v_Discount_Line(i)
                           .Price * (100 - v_Discount_Line(i).Discount) / 100 * v_Discount_Line(i)
                             .Quantity = 0 Then
                            v_Discount_Line.Delete(i);
                            Exit;
                          End If;
                        End Loop;
                      Elsif r_Oi_Head.Trans_Type <> Tt_Hide_Discount_Line Then
                        --补价差单类商品，把金额作为折扣合进发票商品行中。
                        For v_Trx_Line In c_Trx_Line(v_So_Trx_Head_Id) Loop
                          --vTempValue是折扣,把v_Discount_Line(i)的行金额加上原来vTrxLineData的折扣金额，算出初算的折扣率
                          v_Split_Discount := (v_Trx_Line.Price * v_Trx_Line.Discount / 100 *
                                              v_Trx_Line.Quantity - v_Discount_Line(i)
                                              .Price *
                                              (100 - v_Discount_Line(i).Discount) / 100 * v_Discount_Line(i)
                                              .Quantity) /
                                              (v_Trx_Line.Price * v_Trx_Line.Quantity) * 100;

                          --合上补价差行的金额超过了折扣上限
                          If (Abs(v_Split_Discount) > v_Max_Discount_Rate) Then
                            v_Split_Discount   := v_Max_Discount_Rate *
                                                  Sign(v_Split_Discount);
                            v_Split_Diff_Value := v_Trx_Line.Price *
                                                  (v_Trx_Line.Discount -
                                                  v_Split_Discount) / 100 *
                                                  v_Trx_Line.Quantity / v_Discount_Line(i)
                                                 .Quantity;

                            v_Discount_Line(i).Price := v_Discount_Line(i)
                                                        .Price -
                                                         v_Split_Diff_Value *
                                                         (100 - v_Discount_Line(i)
                                                          .Discount) / 100;
                          Else
                            v_Split_Diff_Value := v_Discount_Line(i).Price;
                            v_Discount_Line(i).Price := 0;
                          End If;

                          --更新发票商品行的折扣率
                          Update t_So_Trx_Lines Stl
                             Set Stl.Discount = v_Split_Discount
                           Where Stl.Trx_Line_Id = v_Trx_Line.Trx_Line_Id;

                          Insert Into t_So_Trx_Line_Relation
                            (Id,
                             Trx_Line_Id,
                             So_Line_Id,
                             Quantity,
                             Price,
                             Discount,
                             Discount_Flag,
                             So_Order_Discount)
                          Values
                            (s_So_Trx_Line_Relation.Nextval,
                             v_Trx_Line.Trx_Line_Id,
                             v_Discount_Line(i).Line_Id,
                             v_Discount_Line(i).Quantity,
                             v_Split_Diff_Value,
                             v_Discount_Line(i).Discount,
                             'N',
                             0);
                          If v_Discount_Line(i)
                           .Price * (100 - v_Discount_Line(i).Discount) / 100 * v_Discount_Line(i)
                             .Quantity = 0 Then
                            v_Discount_Line.Delete(i);
                            Exit;
                          End If;
                        End Loop;
                      End If;
                    End Loop; --OuterLoop

                    If p_Result = Err_Ok And v_Discount_Line.Count > 0 Then
                      Declare
                        v_Amount Number;
                      Begin
                        If v_Dis_Trx_Type = 'N' Then
                          --普通保存方式不允许产生虚拟折扣行
                          p_Result := '客户' || v_Customer_Code ||
                                      '的折扣金额大于发票行金额，最大开票折扣率设置得较小或设置不显示折扣折让行，但合并时程序需要产生虚拟折扣折让行。\n请查询相关的金额或更改财务单的组合';
                          Raise v_Base_Exception;
                        Elsif r_Oi_Head.Trans_Type In (Tt_Normal) Then
                          p_Result := '本保存方式(' || Tt_Normal ||
                                      ')不允许生产折扣折让行，但合并发票行却发现需要产生，需合并折扣金额大于发票行可折让金额。\n请选择其它方式保存或更改财务单的组合';
                          Raise v_Base_Exception;
                        Else
                          --统计出剩余对冲商品的总金额
                          v_Amount := 0;
                          For i In v_Discount_Line.First .. v_Discount_Line.Last Loop
                            If v_Discount_Line.Exists(i) Then
                              v_Amount := v_Amount + v_Discount_Line(i)
                                         .Quantity * v_Discount_Line(i).Price *
                                          (100 - v_Discount_Line(i).Discount) / 100;
                            End If;
                          End Loop;
                          If v_Trx_Amount_Sign = Sign(v_Amount) Then
                            --如果金额与发票金额同正负方向，则提示出错。
                            p_Result := '经检查，自动产生的虚拟折扣折让行金额与发票金额符号相同，无法保存';
                            Raise v_Base_Exception;
                          Else
                            Select s_So_Trx_Lines.Nextval
                              Into v_So_Trx_Line_Id
                              From Dual;
                            For i In v_Discount_Line.First .. v_Discount_Line.Last Loop
                              If v_Discount_Line.Exists(i) Then
                                Insert Into t_So_Trx_Line_Relation
                                  (Id,
                                   Trx_Line_Id,
                                   So_Line_Id,
                                   Quantity,
                                   Price,
                                   Discount,
                                   Discount_Flag,
                                   So_Order_Discount)
                                Values
                                  (s_So_Trx_Line_Relation.Nextval,
                                   v_So_Trx_Line_Id,
                                   v_Discount_Line(i).Line_Id,
                                   v_Discount_Line(i).Quantity,
                                   v_Discount_Line(i).Price,
                                   v_Discount_Line(i).Discount,
                                   'N',
                                   0);
                              End If;
                            End Loop;
                            Insert Into t_So_Trx_Lines
                              (Trx_Line_Id,
                               Idtrx_Id,
                               Created_By,
                               Creation_Date,
                               Last_Updated_By,
                               Last_Update_Date,
                               Item_Id,
                               Item_Name,
                               Item_Model,
                               Item_Code,
                               Item_Unit,
                               Quantity,
                               Price,
                               Discount,
                               Trx_Rate,
                               Entity_Id)
                              Select v_So_Trx_Line_Id, --Trx_Line_Id,
                                     v_So_Trx_Head_Id, --Idtrx_Id,
                                     p_User_Code, --Created_By,
                                     Sysdate, --Creation_Date,
                                     p_User_Code, --Last_Updated_By,
                                     Sysdate, --Last_Update_Date,
                                    -- -100, --Item_Id,
                                     max((select i.item_id from cims.t_bd_item i
                                        where i.item_code='Z0000000000002' and i.entity_id=r_Oi_Head.Entity_Id)),
                                     '折扣折让', --Item_Name,
                                     Null, --Item_Model,
                                     'z折扣', --Item_Code,
                                     '元', --Item_Unit,
                                     1, --Quantity,
                                     Sum(Stlr.Quantity * Stlr.Price *
                                         (100 - Stlr.Discount) / 100), --Price,
                                     0, --Discount,
                                     v_Trx_Rate, --Trx_Rate,
                                     r_Oi_Head.Entity_Id --Entity_Id
                                From t_So_Trx_Line_Relation Stlr
                               Where Stlr.Trx_Line_Id = v_So_Trx_Line_Id;
                          End If;
                        End If;
                      End;
                    End If;
                  End If;
                End If;
              End If;
          END IF;    
              
          Close c_Oi_Header;

          If p_Result = Err_Ok Then
            --处理完成回写成功标记
            Update t_So_Trx_Oi_Headers Stoh
               Set Stoh.Oi_Flag          = 'Y',
                   Stoh.Oi_Id            = v_So_Trx_Head_Id,
                   stoh.TRX_HEADER_CODE  = p_Trx_Header_Code,
                   Stoh.Last_Updated_By  = p_User_Code,
                   Stoh.Last_Update_Date = Sysdate,
                   Stoh.customer_registration_code = nvl(V_IDENTIFICATION_NUMBER, V_CUSTOMER_REGISTRATION_CODE),
                   Stoh.invoice_address = V_INVOICE_ADDRESS,
                   Stoh.invoice_tel = V_INVOICE_TEL,
                   Stoh.invoice_bank = V_INVOICE_BANK,
                   Stoh.invoice_bank_account = V_INVOICE_BANK_ACCOUNT,
                   
                   Stoh.Invoice_Contact = V_invoice_contact,
                   STOH.INVOICE_CONTACT_TEL = V_invoice_contact_Tel,
                   STOH.INVOICE_CONTACT_ADDR = V_invoice_contact_Addr
             Where Stoh.Toh_Id = p_Trx_Oi_Header_Id;

            select
              sum(round(stl.price * stl.quantity * (100 - stl.discount) / 100,2))
            into
              v_Trx_Sum_Value
            from t_so_trx_lines stl where stl.idtrx_id = v_So_Trx_Head_Id;
            
            SELECT 
               SUM(NVL(MATERIAL_TRX_AMOUNT,0) - NVL(MATERIAL_AMOUNT,0))
            INTO
                V_SO_TAX_AMOUNT
            FROM 
                V_SO_TRX_LINES_OI  
            WHERE   
               TRX_ID = V_SO_TRX_HEAD_ID;  
               
               v_Trx_Sum_Value:=nvl(v_Trx_Sum_Value,0);
               V_SO_TAX_AMOUNT :=nvl(V_SO_TAX_AMOUNT,0);
                     
            update t_so_trx_headers h
             set h.trx_account = v_Trx_Sum_Value,
                 h.TRX_RATE = v_Trx_Rate,
                 H.TAX_AMOUNT = V_SO_TAX_AMOUNT,
                 h.customer_registration_code = nvl(V_IDENTIFICATION_NUMBER, V_CUSTOMER_REGISTRATION_CODE),
                 h.invoice_address = V_INVOICE_ADDRESS,
                 h.invoice_tel = V_INVOICE_TEL,
                 h.invoice_bank = V_INVOICE_BANK,
                 h.invoice_bank_account = V_INVOICE_BANK_ACCOUNT,
                 
                 H.Invoice_Contact = V_invoice_contact,
                 H.INVOICE_CONTACT_TEL = V_invoice_contact_Tel,
                 H.INVOICE_CONTACT_ADDR = V_invoice_contact_Addr
             where h.idtrx_id = v_So_Trx_Head_Id;

             IF v_Trx_Sum_Value = 0 then
                    update t_so_trx_headers h
                    set h.TRX_DATE = sysdate,
                    trx_code='0000',
                    state='TS_PRINTED'
                    where h.idtrx_id = v_So_Trx_Head_Id;

                    UPDATE t_so_header soh SET soh.invoice_num_list = DECODE(INSTR (soh.invoice_num_list, '0000'),
                          0 , DECODE(SIGN(NVL(LENGTH(soh.invoice_num_list|| DECODE(soh.invoice_num_list, NULL, NULL, ',')|| '0000' ),
                          0 )- 60),-1, soh.invoice_num_list|| DECODE(soh.invoice_num_list, NULL, NULL, ',')|| '0000',
                          soh.invoice_num_list ),NULL, '0000', soh.invoice_num_list),
                          soh.invoice_date = sysdate,
                          soh.last_update_date = SYSDATE,
                          soh.last_updated_by = p_User_Code
                   WHERE soh.so_header_id IN (SELECT sthr.so_head_id FROM t_so_trx_header_relation sthr WHERE sthr.idtrx_id = v_So_Trx_Head_Id );

             end IF;

             UPDATE t_so_header soh SET INVOICE_STATUS = '已送审开票'
             WHERE soh.so_header_id IN (SELECT sthr.so_head_id FROM t_so_trx_header_relation sthr WHERE sthr.idtrx_id = v_So_Trx_Head_Id );

             P_CHECK_PREPARE_TRX(v_So_Trx_Head_Id,p_Result);
             IF p_Result<>'OK' THEN
                    return;
             END IF;

             P_CHECK_SO_TRX(v_So_Trx_Head_Id,p_Result);
             IF p_Result<>'OK' THEN
                    return;
             END IF;
       
             IF V_TRX_DISTRIBUTION_NEW = 'Y' THEN
                 P_CHECK_DISCOUNT_ROW(v_So_Trx_Head_Id,p_Result);
                 IF p_Result<>'OK' THEN
                        return;
                 END IF;
             END IF; 
             
             P_FREEZE_SO_TRX(v_So_Trx_Head_Id,p_Result);
             IF p_Result<>'OK' THEN
                    return;
             END IF;   
             
             P_CHECK_ALLOW_SPLIT(v_So_Trx_Head_Id,V_WHETHER_SPLIT,V_ENTITY_CUST_FLAG,V_DISCOUNT_TAG,p_Result);
             IF p_Result<>'OK' THEN
                    return;
             END IF;   
             
             
             
             
             IF V_ENTITY_CUST_FLAG ='Y' THEN
                  V_INTF_REQ_FLAG :='N';
                  IF  V_DISCOUNT_TAG ='Y' THEN
                      V_INTF_REQ_FLAG :='D';
                  END IF;
                  
                                   
                  
                  update t_so_trx_headers h
                  set h.ENTITY_CUST_FLAG = 'Y'
                        ,h.INTF_TAX_FLAG = 'N'    --税控回写成功
                        ,h.INTF_REQ_FLAG = V_INTF_REQ_FLAG
                        ,h.TAX_CONTROL_FLAG = 'N'
                  where h.idtrx_id = v_So_Trx_Head_Id;    
                  
                  
             SELECT
                  COUNT(*)
             INTO 
                  V_SO_DEVIATION_COUNT   
             FROM 
                  T_SO_TRX_LINES L
             WHERE 
                   L.IDTRX_ID = V_SO_TRX_HEAD_ID
             AND   L.ITEM_ID>0 ;
                       
             IF V_SO_DEVIATION_COUNT>0 THEN
                      --计算销售汇总金额
                      SELECT 
                        SUM(ROUND(P.APPLIED_PLUS_MINUS_FLAG*L.ITEM_PRICE*((100-NVL(L.DISCOUNT_RATE, 0)-NVL(L.MONTH_DISCOUNT_RATE, 0)) / 100) * L.ITEM_QTY, 2)) MATERIAL_TRX_AMOUNT
                      INTO
                         V_SO_ALL_AMOUNT
                      FROM 
                        T_SO_HEADER H
                      INNER JOIN T_SO_TYPE_EXTEND P ON H.ENTITY_ID = P.ENTITY_ID AND H.BILL_TYPE_ID = P.BILL_TYPE_ID
                      INNER JOIN T_SO_LINE L ON  H.SO_HEADER_ID = L.SO_HEADER_ID
                      WHERE H.SO_HEADER_ID IN(
                          SELECT
                             SO_HEAD_ID
                          FROM 
                              T_SO_TRX_HEADER_RELATION
                          WHERE 
                             IDTRX_ID = v_So_Trx_Head_Id);
                      -- 计算差已          
                      V_SO_DEVIATION_AMOUNT := V_SO_ALL_AMOUNT-v_Trx_Sum_Value;    
                    
                      UPDATE T_SO_TRX_HEADERS H
                       SET  H.TRX_ACCOUNT_DEVIATION = V_SO_DEVIATION_AMOUNT
                           ,H.TRX_ACCOUNT = V_TRX_SUM_VALUE+(V_SO_DEVIATION_AMOUNT)
                      WHERE H.IDTRX_ID = V_SO_TRX_HEAD_ID;
                  
                      UPDATE T_SO_TRX_LINES L
                        SET L.TRX_ACCOUNT_DEVIATION = V_SO_DEVIATION_AMOUNT
                      WHERE L.IDTRX_ID = V_SO_TRX_HEAD_ID
                        AND L.ITEM_ID>0
                        AND ROWNUM=1;
              END IF; 
                  
   
             ELSE
                 update t_so_trx_headers h
                 set h.ENTITY_CUST_FLAG = 'N'
                      ,h.INTF_TAX_FLAG = 'N'    --税控回写成功
                      ,h.INTF_REQ_FLAG = 'D'
                     ,h.TAX_CONTROL_FLAG = 'N'
                 where h.idtrx_id = v_So_Trx_Head_Id;        
             END IF;
             
             
             
          Else
            Rollback;
          End If;
  Exception
    When v_Base_Exception Then
      p_Result := p_Result || v_Nl || Sqlerrm || v_Nl || Sqlcode;
      Rollback;
    When Others Then
      Rollback;
      P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_INVOICE.p_Create_So_Trx', SQLCODE,
            '开票错误：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM || p_Trx_Oi_Header_Id);
      p_Result := Err_Unknow || Sqlerrm || Sqlcode || '. ERR:' || p_Result;
  End;
  
  
     --Author: guibr 
  --Created: 2016-07-01
  --把发票池接口表的数据转换成正式发票池数据   洗衣机最新开票方式 
  --国税总局统一要求，升级后将使用商品编码开具发票   营改增新开票方式
  --------------------------------------------------------------------------
  Procedure p_Create_So_Trx_Added(p_Trx_Oi_Header_Id In t_So_Trx_Oi_Headers.Toh_Id%Type, --转换用的接口ID
                                  p_User_Code        In Varchar2, --用户ID
                                  p_So_Trx_Head_Id   In Number,
                                  p_Max_Discount_Rate In Number,
                                  P_Cancel_Order_In_Trx In Varchar2,
                                  P_Trx_Rate        In Number,
                                  p_Result           Out Varchar2 --返回值
                                  )                         
  IS  
     V_TRANS_PARAM  t_So_Trx_Oi_Headers.TRANS_PARAM%Type;  
     V_SO_TRX_LINE_ID NUMBER;   
     V_SO_DISCOUNT_SUM NUMBER;  
   --  V_SO_TRX_SUM NUMBER;   
     V_SO_TRX_COUNT NUMBER;   
     V_SO_DISCOUNT_SIGN NUMBER;  
     V_SO_TRX_AVG NUMBER;     
     V_SO_TRX_ALLOW NUMBER;   
     V_SO_TRX_LOOP NUMBER;   
     V_SO_TRX_TEM NUMBER;       
     V_SO_TRX_SURPLUS NUMBER;  
     V_SO_NEW_DISCOUNT NUMBER;           
     V_SO_PLUS_SUM NUMBER;    
     V_SO_TRX_AMOUNT NUMBER;   
     
     V_TRX_ROW_PLUS NUMBER;
     V_TRX_ROW_NEGATIVE NUMBER;  
     
     V_TRX_ROW_RETURN NUMBER;    
     V_SO_TRANS_TYPE VARCHAR2(200);
     
     V_SO_RETURN_SUM  NUMBER; 
     V_ENITTY_ID NUMBER; 
     V_PARAM_ITEM_CODE VARCHAR2(200); 
  begin
     p_Result := Err_Ok;
     V_PARAM_ITEM_CODE :='Z0000000000001';
     Select 
          TRANS_PARAM 
         ,ATTRIBUTE4
         ,TRANS_TYPE
         ,oh.entity_id
       into
          V_TRANS_PARAM
          ,V_SO_TRX_AMOUNT
          ,V_SO_TRANS_TYPE
          ,V_ENITTY_ID
       From t_So_Trx_Oi_Headers oh
       Where oh.Toh_Id = p_Trx_Oi_Header_Id;
       
      -- V_TRANS_PARAM := Nvl(V_TRANS_PARAM, '一批商品'); 
       
       INSERT INTO T_SO_TRX_HEADER_RELATION   --插入头关系表
        (ID, IDTRX_ID, SO_HEAD_ID)
        SELECT S_SO_TRX_HEADER_RELATION.NEXTVAL, SO.*
          FROM (SELECT DISTINCT p_So_Trx_Head_Id, SOL.SO_HEADER_ID
                  FROM T_SO_LINE SOL, T_SO_TRX_OI_LINES STOL
                 WHERE SOL.SO_LINE_ID = STOL.LINE_ID
                   AND STOL.TOH_ID = p_Trx_Oi_Header_Id) SO;  
       
       V_SO_TRX_COUNT :=0;
       V_SO_PLUS_SUM :=0;
       V_SO_RETURN_SUM :=0;
       
       FOR OI_TRX_ROW IN (
                 SELECT 
                     OI.ITEM_ID
                    ,OI.PRICE
                    ,OI.DISCOUNT
                    ,OI.TRX_RATE
                    ,SUM(NVL(OI.QUANTITY,0)) QUANTITY
                    ,M.ITEM_CODE
                    ,M.ITEM_NAME
                    ,M.DEFAULTUNIT
                    ,OI.ENTITY_ID
                    ,SUM(OI.PRICE * OI.QUANTITY) TRX_AMOUNT
                    ,SUM(OI.PRICE * (100 - OI.DISCOUNT) / 100 * OI.QUANTITY) TRX_DISCOUTN_SUM 
                  FROM T_SO_TRX_OI_LINES OI
                  LEFT JOIN T_BD_ITEM M ON OI.ITEM_ID = M.ITEM_ID
                  WHERE TOH_ID = P_TRX_OI_HEADER_ID AND NVL(M.IS_VIRTUAL,ERR_NO)=Err_No
                  GROUP BY 
                     OI.ITEM_ID
                    ,OI.PRICE
                    ,OI.DISCOUNT
                    ,OI.TRX_RATE
                    ,M.ITEM_CODE
                    ,M.ITEM_NAME
                    ,M.DEFAULTUNIT
                    ,OI.ENTITY_ID
                   order by OI.DISCOUNT
        )LOOP 
           BEGIN 
                  SELECT S_SO_TRX_LINES.NEXTVAL INTO V_SO_TRX_LINE_ID FROM DUAL;
                  IF OI_TRX_ROW.TRX_DISCOUTN_SUM>0 THEN
                     V_SO_PLUS_SUM := V_SO_PLUS_SUM + OI_TRX_ROW.TRX_AMOUNT;
                     V_SO_TRX_COUNT :=V_SO_TRX_COUNT+1;
                  ELSE   
                     V_SO_RETURN_SUM :=  V_SO_RETURN_SUM + OI_TRX_ROW.TRX_DISCOUTN_SUM;  
                  END IF;   
                  
                  INSERT INTO T_SO_TRX_LINES
                             (TRX_LINE_ID,
                             ITEM_ID,
                             IDTRX_ID,
                             CREATED_BY,
                             CREATION_DATE,
                             LAST_UPDATED_BY,
                             LAST_UPDATE_DATE,
                             ITEM_NAME,
                             ITEM_MODEL,
                             ITEM_CODE,
                             ITEM_UNIT,
                             QUANTITY,
                             PRICE,
                             DISCOUNT,
                             TRX_RATE,
                             ENTITY_ID,
                             DISCOUNT_AMOUNT
                             )
                             values(                     
                             V_SO_TRX_LINE_ID
                             ,OI_TRX_ROW.ITEM_ID
                             ,P_SO_TRX_HEAD_ID
                             ,P_USER_CODE
                             ,SYSDATE
                             ,P_USER_CODE
                             ,SYSDATE
                             ,OI_TRX_ROW.ITEM_NAME
                             ,NULL
                             ,OI_TRX_ROW.ITEM_CODE
                             ,OI_TRX_ROW.DEFAULTUNIT
                             ,OI_TRX_ROW.QUANTITY
                             ,OI_TRX_ROW.PRICE
                             ,OI_TRX_ROW.DISCOUNT
                             ,OI_TRX_ROW.TRX_RATE
                             ,OI_TRX_ROW.ENTITY_ID
                             ,nvl(OI_TRX_ROW.TRX_AMOUNT,0) - nvl(OI_TRX_ROW.TRX_DISCOUTN_SUM,0)
                             ); 
                     
                    INSERT INTO T_SO_TRX_LINE_RELATION
                              (ID,
                               TRX_LINE_ID,
                               SO_LINE_ID,
                               QUANTITY,
                               PRICE,
                               DISCOUNT,
                               DISCOUNT_FLAG,
                               SO_ORDER_DISCOUNT)  
                       SELECT 
                          S_SO_TRX_LINE_RELATION.NEXTVAL
                          ,V_SO_TRX_LINE_ID
                          ,OI.LINE_ID
                          ,OI.QUANTITY
                          ,OI.PRICE
                          ,OI.DISCOUNT
                          ,'N'
                          ,0
                       FROM 
                           T_SO_TRX_OI_LINES OI
                           LEFT JOIN T_BD_ITEM M ON OI.ITEM_ID = M.ITEM_ID
                        WHERE   OI.TOH_ID = P_TRX_OI_HEADER_ID
                          AND   OI.ITEM_ID  = OI_TRX_ROW.ITEM_ID
                          AND   OI.PRICE = OI_TRX_ROW.PRICE
                          AND   OI.DISCOUNT = OI_TRX_ROW.DISCOUNT
                          AND   OI.TRX_RATE = OI_TRX_ROW.TRX_RATE
                          AND   NVL(M.IS_VIRTUAL,ERR_NO)=ERR_NO;                     
           END;
        END LOOP;      
         
        SELECT SUM(OI.PRICE * (100 - OI.DISCOUNT) / 100 * OI.QUANTITY)
              INTO V_SO_DISCOUNT_SUM --注意，此变量可能为NULL
              FROM T_SO_TRX_OI_LINES OI
             WHERE OI.TOH_ID = P_TRX_OI_HEADER_ID
               AND EXISTS
              (SELECT 1
                      FROM T_BD_ITEM I
                     WHERE I.ITEM_ID = OI.ITEM_ID
                       AND I.ENTITY_ID = OI.ENTITY_ID
                       AND NVL(I.IS_VIRTUAL, ERR_NO) = ERR_YES);
                       
     IF V_SO_TRANS_TYPE = 'RETURN_DISTRIBUTION_GOODS' THEN    
        V_SO_DISCOUNT_SUM := NVL(V_SO_DISCOUNT_SUM,0) + V_SO_RETURN_SUM;
               
        DELETE FROM  T_SO_TRX_LINES 
        where ITEM_ID >0 
        AND QUANTITY<0 
        AND IDTRX_ID = P_SO_TRX_HEAD_ID; --删除退货行 做为折扣分配其他行
     END IF;            
                       
       
     /*  SELECT SUM(OI.PRICE * (100 - OI.DISCOUNT) / 100 * OI.QUANTITY)
              INTO V_SO_TRX_SUM --注意，此变量可能为NULL
              FROM T_SO_TRX_OI_LINES OI
             WHERE OI.TOH_ID = P_TRX_OI_HEADER_ID
               AND EXISTS
              (SELECT 1
                      FROM T_BD_ITEM I
                     WHERE I.ITEM_ID = OI.ITEM_ID
                       AND I.ENTITY_ID = OI.ENTITY_ID
                       AND NVL(I.IS_VIRTUAL, ERR_NO) = ERR_NO);     */         
 
        IF V_SO_DISCOUNT_SUM IS NOT NULL THEN    
           -- V_SO_TRX_SUM := NVL(V_SO_TRX_SUM,0);            
            IF (V_SO_DISCOUNT_SUM>0 )
              or (V_SO_DISCOUNT_SUM<0 AND V_SO_PLUS_SUM <= 0)
              THEN
               FOR OI_TRX_ROW IN (
                     SELECT 
                         M.ITEM_ID
                        ,0 DISCOUNT
                        ,P_Trx_Rate TRX_RATE
                        ,V_SO_DISCOUNT_SUM PRICE
                        ,M.ITEM_CODE
                        ,M.ITEM_NAME
                        ,M.DEFAULTUNIT
                        ,V_ENITTY_ID ENTITY_ID
                      FROM  T_BD_ITEM M 
                      WHERE M.Entity_Id= V_ENITTY_ID
                       AND  M.Item_Code= V_PARAM_ITEM_CODE
                      AND ROWNUM=1
            )LOOP 
               BEGIN 
                      SELECT S_SO_TRX_LINES.NEXTVAL INTO V_SO_TRX_LINE_ID FROM DUAL;
                      
                      IF OI_TRX_ROW.PRICE <= 0 THEN
                           V_SO_DISCOUNT_SIGN := -1;
                      ELSE 
                           V_SO_DISCOUNT_SIGN := 1;
                      END IF;
                      
                      INSERT INTO T_SO_TRX_LINES
                                 (TRX_LINE_ID,
                                 ITEM_ID,
                                 IDTRX_ID,
                                 CREATED_BY,
                                 CREATION_DATE,
                                 LAST_UPDATED_BY,
                                 LAST_UPDATE_DATE,
                                 ITEM_NAME,
                                 ITEM_MODEL,
                                 ITEM_CODE,
                                 ITEM_UNIT,
                                 QUANTITY,
                                 PRICE,
                                 DISCOUNT,
                                 TRX_RATE,
                                 ENTITY_ID)
                                 values(                     
                                 V_SO_TRX_LINE_ID
                                 ,OI_TRX_ROW.ITEM_ID
                                 ,P_SO_TRX_HEAD_ID
                                 ,P_USER_CODE
                                 ,SYSDATE
                                 ,P_USER_CODE
                                 ,SYSDATE
                                 ,nvl(V_TRANS_PARAM,OI_TRX_ROW.ITEM_NAME)
                                 ,NULL
                                 ,OI_TRX_ROW.ITEM_CODE
                                 ,OI_TRX_ROW.DEFAULTUNIT
                                 ,V_SO_DISCOUNT_SIGN
                                 ,abs(OI_TRX_ROW.PRICE)
                                 ,0
                                 ,OI_TRX_ROW.TRX_RATE
                                 ,OI_TRX_ROW.ENTITY_ID); 
                         
                        INSERT INTO T_SO_TRX_LINE_RELATION
                                  (ID,
                                   TRX_LINE_ID,
                                   SO_LINE_ID,
                                   QUANTITY,
                                   PRICE,
                                   DISCOUNT,
                                   DISCOUNT_FLAG,
                                   SO_ORDER_DISCOUNT)  
                           SELECT 
                              S_SO_TRX_LINE_RELATION.NEXTVAL
                              ,V_SO_TRX_LINE_ID
                              ,OI.LINE_ID
                              ,OI.QUANTITY
                              ,OI.PRICE
                              ,OI.DISCOUNT
                              ,'N'
                              ,0
                           FROM 
                               T_SO_TRX_OI_LINES OI
                               LEFT JOIN T_BD_ITEM M ON OI.ITEM_ID = M.ITEM_ID
                            WHERE   OI.TOH_ID = P_TRX_OI_HEADER_ID
                              AND   OI.ITEM_ID  = OI_TRX_ROW.ITEM_ID
                              AND   OI.PRICE = OI_TRX_ROW.PRICE
                              AND   OI.DISCOUNT = OI_TRX_ROW.DISCOUNT
                              AND   OI.TRX_RATE = OI_TRX_ROW.TRX_RATE
                              AND   NVL(M.IS_VIRTUAL,ERR_NO)=ERR_YES;                     
               END;
              END LOOP;      
            
            ELSIF  V_SO_DISCOUNT_SUM < 0 AND V_SO_PLUS_SUM > 0   THEN
                 P_CREATE_DISCOUNT_SPILT(P_SO_TRX_HEAD_ID,V_SO_DISCOUNT_SUM,V_SO_PLUS_SUM,V_SO_TRX_COUNT,p_Result); --分配折扣 
            END IF;            
       END IF;   
         
  /**  IF V_SO_TRANS_TYPE = 'RETURN_DISTRIBUTION_GOODS' THEN
        SELECT COUNT(*) INTO V_TRX_ROW_PLUS FROM T_SO_TRX_LINES  WHERE ITEM_ID >0 AND QUANTITY>0 AND IDTRX_ID = P_SO_TRX_HEAD_ID;  
        SELECT COUNT(*) INTO V_TRX_ROW_NEGATIVE FROM T_SO_TRX_LINES  WHERE ITEM_ID >0 AND QUANTITY<0 AND IDTRX_ID = P_SO_TRX_HEAD_ID;
         
        IF V_TRX_ROW_PLUS>0 and V_TRX_ROW_NEGATIVE>0 and V_SO_PLUS_SUM>0 THEN   
            SELECT  
              SUM(SI.PRICE * (100 - SI.DISCOUNT) / 100 * SI.QUANTITY) 
             INTO V_TRX_ROW_RETURN 
            FROM T_SO_TRX_LINES SI
             WHERE ITEM_ID >0 
             AND QUANTITY<0 
             AND IDTRX_ID = P_SO_TRX_HEAD_ID;
             
             DELETE FROM  T_SO_TRX_LINES 
             where ITEM_ID >0 
             AND QUANTITY<0 
             AND IDTRX_ID = P_SO_TRX_HEAD_ID; --删除退货行 做为折扣分配其他行
             
             P_CREATE_DISCOUNT_SPILT(P_SO_TRX_HEAD_ID,V_TRX_ROW_RETURN,V_SO_PLUS_SUM,V_SO_TRX_COUNT,p_Result); --分配折扣 
        END IF;
        
     END IF;   **/
       
         FOR SO_TRX_ROW IN (
                      SELECT 
                         SI.QUANTITY
                        ,SI.PRICE
                        ,SI.DISCOUNT
                        ,SI.TRX_RATE
                        ,SI.PRICE * (100 - SI.DISCOUNT) / 100 * SI.QUANTITY TRX_DISCOUTN_SUM 
                        ,SI.PRICE * SI.QUANTITY TRX_SUM 
                        ,SI.TRX_LINE_ID
                        ,M.ITEM_CODE
                      FROM
                        T_SO_TRX_LINES SI
                         LEFT JOIN T_BD_ITEM M ON SI.ITEM_ID = M.ITEM_ID
                      WHERE
                        IDTRX_ID = P_SO_TRX_HEAD_ID
                        AND SI.ITEM_ID >0
                  )LOOP 
                    BEGIN 
                          IF SO_TRX_ROW.DISCOUNT > p_Max_Discount_Rate THEN
                                  p_Result := '发票行:'||SO_TRX_ROW.ITEM_CODE ||'折扣:'||SO_TRX_ROW.DISCOUNT
                                  ||' 大于发票配置允许的最大折扣:'||p_Max_Discount_Rate;
                               return;
                          END IF;
                          
                          IF P_Cancel_Order_In_Trx='Y'
                             AND V_SO_TRX_AMOUNT<>0 
                             AND SO_TRX_ROW.TRX_DISCOUTN_SUM<>0
                             AND SIGN(V_SO_TRX_AMOUNT)<>SIGN(SO_TRX_ROW.TRX_DISCOUTN_SUM)
                          THEN
                              p_Result := '经检查，所产生的发票行的商品数量不全是正数或负数，无法保存';
                              return;
                          END IF; 
                          
                    END;
                 END LOOP;         
  
  end p_Create_So_Trx_added;    
  
  
  --------------------------------------------------------------------------
  --Author: guibr
  --Created: 2016-01-25
  --分配折扣行
  --------------------------------------------------------------------------
  Procedure P_CREATE_DISCOUNT_SPILT(IN_IDTRX_ID In t_so_trx_headers.IDTRX_ID%Type, --发票头ID
                                    IN_SO_DISCOUNT_SUM number,
                                    IN_SO_PLUS_SUM number,
                                    IN_SO_TRX_COUNT number,
                                    p_Result Out Varchar2 --返回值
                           ) Is
     V_SO_TRX_ALLOW NUMBER;   
     V_SO_TRX_LOOP NUMBER;   
     V_SO_TRX_TEM NUMBER;       
     V_SO_TRX_SURPLUS NUMBER;  
     V_SO_NEW_DISCOUNT NUMBER; 
     V_SO_TRX_AVG NUMBER;
  begin
      p_Result := Err_Ok;
      V_SO_TRX_AVG := -1*IN_SO_DISCOUNT_SUM/IN_SO_PLUS_SUM;
      V_SO_TRX_LOOP := 0;
      V_SO_TRX_TEM := 0;
      FOR SO_TRX_ROW IN (
          SELECT 
             SI.QUANTITY
            ,SI.PRICE
            ,SI.DISCOUNT
            ,SI.TRX_RATE
            ,SI.PRICE * (100 - SI.DISCOUNT) / 100 * SI.QUANTITY TRX_DISCOUTN_SUM 
            ,SI.PRICE * SI.QUANTITY TRX_SUM 
            ,SI.TRX_LINE_ID
          FROM
            T_SO_TRX_LINES SI
          WHERE
            IDTRX_ID = IN_IDTRX_ID
      )LOOP 
        BEGIN 
            IF SO_TRX_ROW.TRX_DISCOUTN_SUM > 0 THEN
                  V_SO_TRX_LOOP := V_SO_TRX_LOOP+1;
                  IF V_SO_TRX_LOOP = IN_SO_TRX_COUNT THEN
                       V_SO_TRX_ALLOW := -1*IN_SO_DISCOUNT_SUM-V_SO_TRX_TEM;
                  ELSE   
                       V_SO_TRX_ALLOW := SO_TRX_ROW.TRX_SUM * V_SO_TRX_AVG;  
                       V_SO_TRX_ALLOW := round(V_SO_TRX_ALLOW,2);
                  END IF; 
                       V_SO_TRX_SURPLUS := SO_TRX_ROW.TRX_SUM - SO_TRX_ROW.TRX_DISCOUTN_SUM;
                       V_SO_TRX_SURPLUS := V_SO_TRX_SURPLUS+V_SO_TRX_ALLOW;
                       V_SO_NEW_DISCOUNT := (V_SO_TRX_SURPLUS/SO_TRX_ROW.TRX_SUM)*100;
                       V_SO_NEW_DISCOUNT := round(V_SO_NEW_DISCOUNT,10);
                                   
                        IF V_SO_TRX_LOOP <> IN_SO_TRX_COUNT THEN
                             V_SO_TRX_TEM := V_SO_TRX_TEM +V_SO_TRX_ALLOW ;
                        END IF;
        
                       UPDATE T_SO_TRX_LINES SET DISCOUNT = V_SO_NEW_DISCOUNT,DISCOUNT_AMOUNT=V_SO_TRX_SURPLUS
                       where TRX_LINE_ID= SO_TRX_ROW.TRX_LINE_ID and IDTRX_ID = IN_IDTRX_ID;
            END IF;              
        END;
      END LOOP;                          
  end  P_CREATE_DISCOUNT_SPILT;                              

   --------------------------------------------------------------------------
  --Author: guibr
  --Created: 2016-01-25
  --校验发票开票金额，销售单金额是否超额开票
  --------------------------------------------------------------------------
  Procedure P_CHECK_PREPARE_TRX(IN_IDTRX_ID In t_so_trx_headers.IDTRX_ID%Type, --发票头ID
                           p_Result Out Varchar2 --返回值
                           ) Is
      N_TRX_ACCOUNT      number;
      N_TRX_LINE_ACCOUNT number;
      N_TRX_OI_ACCOUNT number;
  begin
     p_Result := Err_Ok;
      select
          nvl(TRX_ACCOUNT,0)
      Into
          N_TRX_ACCOUNT
      from
          t_so_trx_headers
      where
          IDTRX_ID = IN_IDTRX_ID;

     select
         sum(nvl(material_trx_amount,0)-nvl(discount_trx_amount,0))
     into
         N_TRX_LINE_ACCOUNT
     from
         v_so_trx_lines_oi
     where
         trx_id = IN_IDTRX_ID;

         N_TRX_ACCOUNT := nvl(N_TRX_ACCOUNT,0);
          N_TRX_LINE_ACCOUNT := nvl(N_TRX_LINE_ACCOUNT,0);

     if  abs(N_TRX_ACCOUNT-N_TRX_LINE_ACCOUNT)>1 then
          p_Result := '经检查，发票头金额:'||N_TRX_ACCOUNT||'跟开票行金额:'||N_TRX_LINE_ACCOUNT||'有差已';
         -- Raise v_Base_Exception;
     end if;

     select
         nvl(ATTRIBUTE4,0)
     into
         N_TRX_OI_ACCOUNT
     from
         T_SO_TRX_OI_HEADERS
     where
         OI_ID = IN_IDTRX_ID;

          N_TRX_OI_ACCOUNT := nvl(N_TRX_OI_ACCOUNT,0);

     if  abs(N_TRX_ACCOUNT-N_TRX_OI_ACCOUNT)>1 then
           p_Result := '经检查，发票头金额:'||N_TRX_ACCOUNT||'跟接口头金额:'||N_TRX_OI_ACCOUNT||'有差已';
         -- Raise v_Base_Exception;
     end if;

  end P_CHECK_PREPARE_TRX;


  --------------------------------------------------------------------------
  --Author: guibr
  --Created: 2016-01-25
  --校验发票开票金额，销售单金额是否超额开票
  --------------------------------------------------------------------------
  Procedure P_CHECK_SO_TRX(IN_IDTRX_ID In t_so_trx_headers.IDTRX_ID%Type, --发票头ID
                           p_Result Out Varchar2 --返回值
                           )Is
      S_DIFFERENCE      Varchar2(4000)  ;
      N_TOH_ID          number;
  begin
      p_Result := Err_Ok;

     Select TOH_ID Into N_TOH_ID From t_so_trx_oi_headers Sth Where Sth.Oi_Id = IN_IDTRX_ID;

     FOR SO_TRX_LINE_ROW IN(
        select
           SL.SO_LINE_ID
           ,SL.ITEM_CODE
           ,SL.Item_Name
           ,SO.SO_NUM
           ,nvl(SOL.ITEM_TRX_AMOUNT,0) ITEM_TRX_AMOUNT
           ,TY.APPLIED_PLUS_MINUS_FLAG*SL.ITEM_SETTLE_AMOUNT ITEM_SETTLE_AMOUNT
         FROM CIMS.T_SO_LINE SL
         INNER JOIN CIMS.T_SO_HEADER SO ON SO.SO_HEADER_ID = SL.SO_HEADER_ID
         LEFT  JOIN CIMS.V_SO_BILL_TYPE_EXTEND TY ON TY.BILL_TYPE_ID = SO.BILL_TYPE_ID
         LEFT JOIN  (SELECT
                       LINE_ID
                       ,SUM(OL.QUANTITY *OL.PRICE*(100 - NVL(OL.DISCOUNT,0))/100)  ITEM_TRX_AMOUNT
                       FROM CIMS.T_SO_TRX_OI_LINES  OL,CIMS.T_SO_TRX_OI_HEADERS OH
                       WHERE OL.TOH_ID = OH.TOH_ID and EXISTS (
                         SELECT 1 FROM CIMS.T_SO_TRX_HEADERS TH WHERE TH.IDTRX_ID = OH.OI_ID AND             ROWNUM=1
                       )
                       GROUP BY LINE_ID
                     ) SOL ON SOL.LINE_ID = SL.SO_LINE_ID
          where  SO.BILL_TYPE_CODE NOT IN('1028','1029')
          and  exists (
             select
               1
              from
               cims.T_SO_TRX_OI_LINES OI
             where OI.Toh_Id = N_TOH_ID
             and   OI.LINE_ID = SL.SO_LINE_ID
          ) )
         LOOP
           begin
              IF abs(nvl(SO_TRX_LINE_ROW.ITEM_TRX_AMOUNT,0)) - abs(nvl(SO_TRX_LINE_ROW.ITEM_SETTLE_AMOUNT,0)) > 1 then
                  S_DIFFERENCE := S_DIFFERENCE
                  ||'销售单号：'||SO_TRX_LINE_ROW.SO_NUM
                  ||'销售单行：'||SO_TRX_LINE_ROW.ITEM_CODE
                  ||'开票总金额:'||SO_TRX_LINE_ROW.ITEM_TRX_AMOUNT
                  ||'结算总金额:'||SO_TRX_LINE_ROW.ITEM_SETTLE_AMOUNT
                  ||';';
              end IF;
           end;
         END LOOP;

         IF S_DIFFERENCE is not null then
             p_Result := '经检查，存在销售行超额开票情况:'||S_DIFFERENCE;
             --Raise v_Base_Exception;
         end IF;
    end P_CHECK_SO_TRX;

  --------------------------------------------------------------------------
  --Author: guibr
  --Created: 2016-01-25
  --冻结开票易明细数据
  --------------------------------------------------------------------------
  Procedure P_FREEZE_SO_TRX(IN_IDTRX_ID In t_so_trx_headers.IDTRX_ID%Type, --发票头ID
                            p_Result Out Varchar2 --返回值
                           ) is

  begin
    p_Result := Err_Ok;
    insert  into  T_SO_TRX_LINES_OI(
         TRX_LINE_ID
         ,FINANCE_ENTITY_ID
         ,FINANCE_MAIN_ENTITY_ID
         ,TRX_ID
         ,CREATED_BY
         ,CREATION_DATE
         ,LAST_UPDATED_BY
         ,LAST_UPDATE_DATE
         ,MATERIAL_ID
         ,MATERIAL_NAME
         ,MATERIAL_CODE
         ,MATERIAL_MODEL
         ,MATERIAL_UNIT
         ,QUANTITY
         ,PRICE
         ,DISCOUNT
         ,TRX_RATE
         ,MATERIAL_TRX_AMOUNT
         ,MATERIAL_AMOUNT
         ,LINE_NUM
         )
      select
              TRX_LINE_ID
             ,FINANCE_ENTITY_ID
             ,FINANCE_MAIN_ENTITY_ID
             ,TRX_ID
             ,CREATED_BY
             ,CREATION_DATE
             ,LAST_UPDATED_BY
             ,LAST_UPDATE_DATE
             ,MATERIAL_ID 
             ,MATERIAL_NAME
             ,MATERIAL_CODE
             ,MATERIAL_MODEL
             ,MATERIAL_UNIT
             ,QUANTITY
             ,PRICE
             ,DISCOUNT
             ,TRX_RATE
             ,MATERIAL_TRX_AMOUNT
             ,MATERIAL_AMOUNT
             ,LINE_NUM
        from  V_SO_TRX_LINES_OI
        where TRX_ID = IN_IDTRX_ID;
  end P_FREEZE_SO_TRX;
  
  
       --------------------------------------------------------------------------
  --Author: guibr
  --Created: 2016-07-28
  --检查开票折扣行限制
  --------------------------------------------------------------------------
  Procedure P_CHECK_DISCOUNT_ROW(IN_IDTRX_ID In t_so_trx_headers.IDTRX_ID%Type, --发票头ID
                                 p_Result Out Varchar2 --返回值
                           )is
      V_DISCOUNT_ROW number;  
      V_TRX_ROW number;     
      V_TRX_DISCOUNT_ROW number;                     
  BEGIN
      p_Result := Err_Ok;
      SELECT COUNT(*) INTO V_DISCOUNT_ROW FROM T_SO_TRX_LINES WHERE ITEM_ID<0 AND QUANTITY<0 and IDTRX_ID = IN_IDTRX_ID;
      SELECT COUNT(*) INTO V_TRX_ROW FROM T_SO_TRX_LINES WHERE ITEM_ID>0 and IDTRX_ID = IN_IDTRX_ID;
      SELECT COUNT(*) INTO V_TRX_DISCOUNT_ROW FROM T_SO_TRX_LINES WHERE ITEM_ID>0 AND DISCOUNT>0 and IDTRX_ID = IN_IDTRX_ID;
      IF V_DISCOUNT_ROW > 0 AND V_TRX_ROW >68 THEN
            p_Result := '经检查，开票存在折扣行且开票行超过68行';
            return ;
      END IF;
      
      IF V_TRX_DISCOUNT_ROW >68 THEN
            p_Result := '经检查，开票存在折扣行超过68行';
            return ;
      END IF;
    
  END; 
  
  
    --------------------------------------------------------------------------
  --Author: guibr
  --Created: 2016-10-17
  --检查开票是否允许拆分
  --------------------------------------------------------------------------
  Procedure P_CHECK_ALLOW_SPLIT(IN_IDTRX_ID In t_so_trx_headers.IDTRX_ID%Type, --发票头ID
                                IS_WHETHER_SPLIT IN VARCHAR2,
                                OS_ENTITY_CUST_FLAG OUT VARCHAR2,
                                OS_DISCOUNT_TAG OUT VARCHAR2,
                                p_Result Out Varchar2 --返回值
                           ) is
       V_SO_COUNT number;  
       V_ENTITY_CUST_FLAG  VARCHAR2(2); --事业部客户标识: N 普通客户，Y 内部关联交易客户
       V_RESULT           NUMBER;   --返回错误ID
       V_ERR_MSG          VARCHAR2(10000);
       V_TEM_TAG          VARCHAR2(2);
       V_DISCOUNT_TAG     VARCHAR2(2);
       V_SO_HEADER_TAG    VARCHAR2(2); 
       
       V_NO_ENTITY_TAG          VARCHAR2(2);
   BEGIN  
     p_Result := Err_Ok;
     V_TEM_TAG := 'Y';
     V_NO_ENTITY_TAG :='Y';
     V_DISCOUNT_TAG  := 'N';
     V_SO_HEADER_TAG := 'N';
      
     FOR 
      HEAD_ID_ROW 
       IN(SELECT 
               IDTRX_ID
               ,SO_HEAD_ID 
          FROM 
              T_SO_TRX_HEADER_RELATION
          WHERE 
              IDTRX_ID =  IN_IDTRX_ID   
        )LOOP
           FOR 
              SO_HEAD_ROW 
             IN(
                SELECT 
                   ENTITY_CUST_FLAG
                  ,ENTITY_ID
                  ,SO_NUM
                  ,SO_HEADER_ID 
                  ,H.BIZ_SRC_BILL_TYPE_CODE
                FROM 
                  T_SO_HEADER H
                WHERE   
                 SO_HEADER_ID = HEAD_ID_ROW.SO_HEAD_ID
             )
            LOOP 
              
             --  PKG_SO_INTF.P_SO_ENTITY_CUST_FLAG_BY_NUM(SO_HEAD_ROW.ENTITY_ID
             --                                          ,SO_HEAD_ROW.SO_NUM
             --                                          ,V_ENTITY_CUST_FLAG
             --                                           ,V_RESULT
             --                                          ,V_ERR_MSG
             --                                         );
             
             
             -- IF V_RESULT < 0 THEN
             --    p_Result := V_ERR_MSG;
             --    return;
             --  END IF;     
               
             --  IF V_ENTITY_CUST_FLAG='Y' AND NVL(SO_HEAD_ROW.ENTITY_CUST_FLAG,'N')<>'Y' THEN
             --        p_Result := '销售单:'||SO_HEAD_ROW.SO_NUM||' 检查是内部客户,单据没有标注为跨事业部订单标志。';
             --     return;
             --  END IF;    
             
             V_ENTITY_CUST_FLAG := NVL(SO_HEAD_ROW.ENTITY_CUST_FLAG,'N');                                                         
            
               IF   IS_WHETHER_SPLIT='N'
                 OR V_ENTITY_CUST_FLAG='Y'   --跨事业部订单不允许拆分开票
                THEN 
                      SELECT 
                          COUNT(1)
                      INTO
                          V_SO_COUNT   
                      FROM 
                          T_SO_TRX_HEADER_RELATION
                      WHERE 
                          SO_HEAD_ID = SO_HEAD_ROW.SO_HEADER_ID;
                     
                     IF  V_SO_COUNT >1 AND SO_HEAD_ROW.BIZ_SRC_BILL_TYPE_CODE IN('1001','1002','1003','1004') THEN
                          p_Result := '经检查，该发票销售单:'||SO_HEAD_ROW.SO_NUM||'不允许拆分开票,或为跨事业部订单。';
                          return;
                     END IF;          
               END IF;    
               
               IF NVL(SO_HEAD_ROW.ENTITY_CUST_FLAG,'N')<>'Y' THEN
                     V_TEM_TAG := 'N';
               END IF; 
               
               IF NVL(SO_HEAD_ROW.ENTITY_CUST_FLAG,'N')='Y' THEN
                     V_NO_ENTITY_TAG := 'N';
               END IF; 
               
               IF SO_HEAD_ROW.BIZ_SRC_BILL_TYPE_CODE IN('1005','1006','1007','1008') THEN
                    V_DISCOUNT_TAG := 'Y';
               END IF;
               
               IF SO_HEAD_ROW.BIZ_SRC_BILL_TYPE_CODE IN('1001','1002','1003','1004') THEN
                    V_SO_HEADER_TAG := 'Y';
               END IF;               
       
            END LOOP;
        END LOOP; 
        
        OS_DISCOUNT_TAG := V_DISCOUNT_TAG;   
        
        IF V_TEM_TAG = 'N' AND V_NO_ENTITY_TAG ='N' THEN
               p_Result := '经检查，跨事业部客户销售折让单，折让证明单不允许与其他单据类型合并开票';
              return;
        END IF;
        
        IF V_TEM_TAG = 'Y' THEN
            OS_ENTITY_CUST_FLAG := 'Y';
            
            IF  V_DISCOUNT_TAG='Y' AND V_SO_HEADER_TAG='Y' THEN
                 p_Result := '经检查，跨事业部客户销售折让单，折让证明单不允许与其他单据类型合并开票';
                return;
            END IF;
            
        END IF;                                
   END; 
   
   
     --------------------------------------------------------------------------
  --Author: guibr
  --Created: 2016-10-19
  --处理内部客户开票信息引入关联开票接口
  --------------------------------------------------------------------------
  Procedure P_ENTITY_CUST_IMP_INTF(
                           IN_ENTITY_ID IN NUMBER,
                             OS_MESSAGE OUT VARCHAR2) --返回值     
     is
     N_REQ_HEADE_ID NUMBER;
     N_MATERIAL_TRX_AMOUNT NUMBER;
     N_MATERIAL_AMOUNT NUMBER;
     N_TRX_AMOUNT NUMBER;
     N_ALL_TRX_AMOUNT NUMBER;
     N_ALL_AMOUNT NUMBER;
     S_ERR_MESSAGE VARCHAR(300);
     S_UPDATE_TRX_STATUS VARCHAR(50);
  BEGIN
    OS_MESSAGE :='OK';
     FOR 
       TRX_HEADER_ROW 
       IN(
           SELECT 
              IDTRX_ID
             ,TRX_CODE
             ,TRX_DATE
             ,ERP_OU_ID
             ,ENTITY_ID
             ,TRX_ACCOUNT
             ,TRX_HEADER_CODE
             ,TRX_RATE
           FROM 
              T_SO_TRX_HEADERS H
           WHERE ENTITY_CUST_FLAG='Y'  
             AND INTF_REQ_FLAG='N' 
             AND STATE = 'TS_PRINTED'
             AND H.ENTITY_ID = IN_ENTITY_ID
             AND NOT EXISTS (
               SELECT
                 RH.SOURCE_HEADER_ID 
               FROM  
                  INTF_CUX_ICP_INVOICE_REQ_HEAD RH
               WHERE 
                  RH.SOURCE_HEADER_ID = H.IDTRX_ID
             )  
        )LOOP
          BEGIN 
            SAVEPOINT SP;
            N_REQ_HEADE_ID := S_CUX_ICP_INVOICE_REQ_HEAD.NEXTVAL;
            N_ALL_TRX_AMOUNT:=0;
            N_ALL_AMOUNT:=0;
            INSERT 
              INTO
               INTF_CUX_ICP_INVOICE_REQ_HEAD(
                SOURCE_HEADER_ID
               ,GL_DATE
               ,CURRENCY_CODE
               ,CONVERSION_DATE
               ,CONVERSION_RATE_AR
               ,CONVERSION_RATE_AP
               ,TAX_AMOUNT
               ,ATTRIBUTE1
               ,ATTRIBUTE2
               ,ATTRIBUTE3
               ,ATTRIBUTE4
               ,ATTRIBUTE5
               ,ATTRIBUTE6
               ,ATTRIBUTE7
               ,ATTRIBUTE8
               ,ATTRIBUTE9
               ,ATTRIBUTE10
               ,ESB_SERIAL_NUM
               ,ESB_DATA_SOURCE
               ,INTF_STATUS
               ,ERROR_FLAG
               ,ERROR_MSG
               ,POST_DATE
               ,RETURN_DATE
               ,RESPONSE_TYPE
               ,RESPONSE_CODE
               ,RESPONSE_MESSAGE
               ,OPERSTATUS
               ,TRX_ID
               ,SOURCE_NUM
               ,SOURCE_CODE
               ,CREATED_BY
               ,LAST_UPDATED_BY
               ,CREATION_DATE
               ,ORG_ID
               ,ENTITY_ID
               ,LAST_UPDATE_DATE
               ,CONVERSION_TYPE
               ,GROUP_CODE
               )
            VALUES(
                TRX_HEADER_ROW.IDTRX_ID
                ,to_char(TRX_HEADER_ROW.TRX_DATE,'yyyy-mm-dd')
                ,'CNY'
                ,to_char(TRX_HEADER_ROW.TRX_DATE,'yyyy-mm-dd')--汇率日期
                ,null
                ,null
                ,null  --税额
                ,TRX_HEADER_ROW.TRX_RATE
                ,TRX_HEADER_ROW.TRX_ACCOUNT
                ,null
                ,null
                ,null
                ,null
                ,null
                ,null
                ,null
                ,null  --扩展字段
                ,null
                ,'ERP-IMS-077'    --接口编码
                ,'N'
                ,null
                ,null
                ,null
                ,null
                ,null
                ,null  
                ,null
                ,'N'
                ,N_REQ_HEADE_ID
                ,TRX_HEADER_ROW.TRX_HEADER_CODE
                ,'CIMS'
                ,'admin'
                ,'admin'
                ,sysdate
                ,TRX_HEADER_ROW.ERP_OU_ID
                ,TRX_HEADER_ROW.ENTITY_ID
                ,sysdate
                ,'Corporate'
               ,'C03'
             );       
          FOR 
             TRX_LINE_ROW 
             IN(   
                  SELECT 
                    L.LOGIST_LINE_ID 
                   ,L.ITEM_PRICE
                   ,L.REQUEST_QUANTITY * P.APPLIED_PLUS_MINUS_FLAG ITEM_QTY
                   ,L.SOURCE_LINE SO_LINE_ID
                   ,H.SO_NUM
                  FROM 
                    T_SO_HEADER H
                  INNER JOIN T_SO_TYPE_EXTEND P ON H.ENTITY_ID = P.ENTITY_ID AND H.BILL_TYPE_ID = P.BILL_TYPE_ID
                  --INNER JOIN INTF_CUX_ICP_LOGIST_REQ_HEADER RH ON 'G'||H.SO_NUM = RH.REQUIREMENT_ORDER_NUM
                  INNER JOIN INTF_CUX_ICP_LOGIST_REQ_LINES L ON H.SO_HEADER_ID = L.SOURCE_HEADER_ID AND 'G'||H.SO_NUM=L.SOURCE_HEADER 
                  WHERE 
                   EXISTS (SELECT 1 FROM INTF_CUX_ICP_LOGIST_REQ_HEADER RH WHERE 'G'||H.SO_NUM = RH.REQUIREMENT_ORDER_NUM AND RH.ERP_LOGIST_RECEIVE_FLAG='Y') 
                   AND H.SO_HEADER_ID IN(
                      SELECT
                         SO_HEAD_ID
                      FROM 
                          T_SO_TRX_HEADER_RELATION
                      WHERE 
                         IDTRX_ID = TRX_HEADER_ROW.IDTRX_ID)
                   )LOOP
                       IF TRX_LINE_ROW.LOGIST_LINE_ID IS NULL THEN
                            RAISE_APPLICATION_ERROR(-20001,TRX_LINE_ROW.SO_NUM||'关联物流行ID没有回写'); 
                       END IF;
                       
                       SELECT 
                          UPDATE_TRX_STATUS
                        INTO
                          S_UPDATE_TRX_STATUS
                       FROM 
                          INTF_OE_HEADERS_IFACE_ALL 
                       where 
                          ORDER_NUMBER = TRX_LINE_ROW.SO_NUM;
                          
                       IF S_UPDATE_TRX_STATUS <>'S'  THEN
                           RAISE_APPLICATION_ERROR(-20001,TRX_LINE_ROW.SO_NUM||'SO没有完成变更'); 
                       END IF;
                  
                       N_MATERIAL_TRX_AMOUNT := ROUND(TRX_LINE_ROW.ITEM_PRICE * TRX_LINE_ROW.ITEM_QTY, 2);
                       N_MATERIAL_AMOUNT := ROUND(TRX_LINE_ROW.ITEM_PRICE * TRX_LINE_ROW.ITEM_QTY /(1 + TRX_HEADER_ROW.TRX_RATE / 100),2);
                       
                       N_TRX_AMOUNT := (N_MATERIAL_TRX_AMOUNT-N_MATERIAL_AMOUNT);
                       
                       N_ALL_TRX_AMOUNT := N_ALL_TRX_AMOUNT+N_TRX_AMOUNT;
                       
                       N_ALL_AMOUNT := N_ALL_AMOUNT + N_MATERIAL_TRX_AMOUNT;
                       
                       
                       INSERT 
                         INTO 
                         INTF_CUX_ICP_INVOICE_REQ_LINES(
                            SOURCE_HEADER_ID
                            ,REQ_LOGIST_ID
                            ,SETTLEMENT_PRICE
                            ,SETTLEMENT_PRICE_NT
                            ,TAX_AMOUNT
                            ,REQUEST_QUANTITY
                            ,ATTRIBUTE1
                            ,ATTRIBUTE2
                            ,ATTRIBUTE3
                            ,ATTRIBUTE4
                            ,ATTRIBUTE5
                            ,TRX_LINE_ID
                            ,SOURCE_LINE_NUM
                            ,TRX_ID
                            ,SO_NUM
                            ,SIGN_REQUEST_QUANTITY
                            )
                          VALUES(
                             TRX_HEADER_ROW.IDTRX_ID
                            ,TRX_LINE_ROW.LOGIST_LINE_ID
                            ,ROUND(TRX_LINE_ROW.ITEM_PRICE,6)
                            ,ROUND(TRX_LINE_ROW.ITEM_PRICE/(1 + TRX_HEADER_ROW.TRX_RATE / 100),6)
                            ,ABS(N_TRX_AMOUNT)
                            ,ABS(TRX_LINE_ROW.ITEM_QTY)
                            ,null
                            ,null
                            ,null
                            ,null
                            ,null
                            ,S_CUX_ICP_INVOICE_REQ_LINES.NEXTVAL
                            ,TRX_LINE_ROW.SO_LINE_ID
                            ,N_REQ_HEADE_ID
                            ,TRX_LINE_ROW.SO_NUM
                            ,TRX_LINE_ROW.ITEM_QTY
                          );
                   END LOOP;
                   
                   UPDATE INTF_CUX_ICP_INVOICE_REQ_HEAD SET TAX_AMOUNT=ABS(N_ALL_TRX_AMOUNT),SIGN_TAX_AMOUNT=N_ALL_TRX_AMOUNT  WHERE TRX_ID=N_REQ_HEADE_ID;
                   UPDATE T_SO_TRX_HEADERS SET INTF_REQ_FLAG = 'Y',INTF_ERROR_MSG=null WHERE IDTRX_ID = TRX_HEADER_ROW.IDTRX_ID ;
                   
                   IF abs(nvl(N_ALL_AMOUNT,0) - nvl(TRX_HEADER_ROW.TRX_ACCOUNT,0))>0.5 THEN
                       RAISE_APPLICATION_ERROR(-20001,'开票行汇总金额跟开票头金额不一致'); 
                   END IF;    
                   COMMIT;
            EXCEPTION
                WHEN OTHERS THEN
                     ROLLBACK TO SAVEPOINT SP;
                     --设置ESB异步回调处理错误
                     S_ERR_MESSAGE := substr(sqlerrm,1,100);
                     UPDATE 
                       T_SO_TRX_HEADERS 
                     SET 
                     INTF_REQ_FLAG = 'E'
                    ,INTF_ERROR_MSG = S_ERR_MESSAGE
                    WHERE IDTRX_ID = TRX_HEADER_ROW.IDTRX_ID;    
           END;
        END LOOP;
  END; 
    
  --------------------------------------------------------------------------
  --Author: guibr
  --Created: 2016-10-19
  --处理内部客户税控信息引入关联开票接口
  --------------------------------------------------------------------------
  Procedure P_ENTITY_CUST_TAX_INTF(
                               IN_ENTITY_ID IN NUMBER,
                                 OS_MESSAGE Out Varchar2)  --返回值   
      IS
     N_REQ_HEADE_ID     NUMBER;
     N_ALL_AMOUNT       NUMBER;
     S_ERR_MESSAGE      VARCHAR(300);  
     N_SET_OF_BOOKS_ID  NUMBER;
     S_INVOICE_NO       VARCHAR(300);  
     N_CURRENT_COUNT    NUMBER;
     S_OLD_TRX_DATE     VARCHAR(300);  
      
    -- N_REQ_HEADER_ID    NUMBER; --关联交易号
  BEGIN
       OS_MESSAGE :='OK';
     FOR 
       TRX_HEADER_ROW 
       IN(
           SELECT 
              H.IDTRX_ID
             ,H.TRX_CODE
             ,H.TRX_DATE
             ,H.ERP_OU_ID
             ,H.ENTITY_ID
             ,H.TRX_ACCOUNT
             ,H.TRX_HEADER_CODE
             ,H.TRX_RATE
             ,H.CUSTOMER_CODE
             ,H.TRX_TYPE
             ,RH.REQ_HEADER_ID
             ,H.TAX_AMOUNT
             ,H.SOURCE_SYSTEM
             ,H.TAX_CONTROL_FLAG
             ,H.AUTO_FLAG
             ,H.INTF_REQ_FLAG
           FROM 
              T_SO_TRX_HEADERS H
            LEFT JOIN INTF_CUX_ICP_INVOICE_REQ_HEAD RH ON H.IDTRX_ID = RH.SOURCE_HEADER_ID 
           WHERE
           -- ENTITY_CUST_FLAG='Y' 
           -- AND INTF_REQ_FLAG='Y'   
                H.INTF_TAX_FLAG='N' 
             AND H.STATE = 'TS_PRINTED' 
          --   AND  RH.REQ_HEADER_ID IS NOT NULL 
             AND H.ENTITY_ID = IN_ENTITY_ID
             AND  rownum <= 1000
        )LOOP
          BEGIN 
            SAVEPOINT SP;
            
            IF TRX_HEADER_ROW.INTF_REQ_FLAG IN('Y','N','E')
               AND TRX_HEADER_ROW.REQ_HEADER_ID IS NULL 
            THEN 
                RAISE_APPLICATION_ERROR(-20001,'未回写关联交易号'); 
            END IF;  
            
            
            SELECT
               NVL(MAX(SET_OF_BOOKS_ID),0) 
            INTO 
               N_SET_OF_BOOKS_ID 
            FROM T_INV_ORGANIZATION
            WHERE OPERATING_UNIT = TRX_HEADER_ROW.ERP_OU_ID;
            N_ALL_AMOUNT :=0;
            
         /*
            SELECT 
                COUNT(*)
            INTO
                N_CURRENT_COUNT  
            FROM 
                INTF_CUX_ICP_INVOICE_TAX_CONTR
            WHERE     
                 PROCESS_TYPE = 'I'
             AND SOURCE_HEADER_ID = TRX_HEADER_ROW.IDTRX_ID;
             
            IF N_CURRENT_COUNT>0 THEN
                  SELECT 
                     INVOICE_NO
                    ,INVOICE_DATE
                  INTO
                     S_INVOICE_NO
                    ,S_OLD_TRX_DATE 
                  FROM (  
                    SELECT 
                         SOURCE_HEADER_ID
                        ,INVOICE_NO
                        ,INVOICE_DATE
                    FROM 
                        INTF_CUX_ICP_INVOICE_TAX_CONTR
                    WHERE     
                         PROCESS_TYPE = 'I'
                     AND SOURCE_HEADER_ID = TRX_HEADER_ROW.IDTRX_ID
                     ORDER BY TRX_ID DESC) 
                  WHERE ROWNUM=1;
            END IF;   */     
          
            FOR 
             TRX_LINE_ROW 
             IN(   
                 SELECT 
                     H.ERP_ARINVOICE_ID
                    ,H.ERP_ARINVOICE_CODE
                    ,H.CUSTOMER_CODE
                    ,H.ERP_OU_ID
                    ,H.SO_NUM
                    ,SUM(
                         CASE WHEN H.BIZ_SRC_BILL_TYPE_CODE IN('1005','1006','1007','1008') THEN
                            ROUND(OL.PRICE*((100-NVL(OL.DISCOUNT, 0)) / 100) * OL.QUANTITY, 2)
                         ELSE
                            ROUND(L.ITEM_PRICE*((100-NVL(L.DISCOUNT_RATE, 0)-NVL(L.MONTH_DISCOUNT_RATE, 0)) / 100) * OL.QUANTITY, 2)
                         END 
                    ) MATERIAL_TRX_AMOUNT
                    ,SUM(
                        CASE WHEN H.BIZ_SRC_BILL_TYPE_CODE IN('1005','1006','1007','1008') THEN
                            ROUND(OL.PRICE*((100-NVL(OL.DISCOUNT, 0)) / 100) * OL.Quantity /(1 + TRX_HEADER_ROW.TRX_RATE / 100),2)
                        ELSE
                            ROUND(L.ITEM_PRICE*((100-NVL(L.DISCOUNT_RATE, 0)-NVL(L.MONTH_DISCOUNT_RATE, 0)) / 100) * OL.Quantity /(1 + TRX_HEADER_ROW.TRX_RATE / 100),2)
                        END
                     ) MATERIAL_AMOUNT
                  FROM 
                    T_SO_HEADER H
                  --INNER JOIN T_SO_TYPE_EXTEND P ON H.ENTITY_ID = P.ENTITY_ID AND H.BILL_TYPE_ID = P.BILL_TYPE_ID
                  INNER JOIN T_SO_LINE L ON  H.SO_HEADER_ID = L.SO_HEADER_ID
                  INNER JOIN T_SO_TRX_OI_HEADERS OH ON  OH.OI_ID = TRX_HEADER_ROW.IDTRX_ID
                  INNER JOIN T_SO_TRX_OI_LINES OL ON  OL.TOH_ID = OH.TOH_ID AND OL.LINE_ID = L.SO_LINE_ID
                  WHERE H.SO_HEADER_ID IN(
                      SELECT
                         SO_HEAD_ID
                      FROM 
                          T_SO_TRX_HEADER_RELATION
                      WHERE 
                         IDTRX_ID = TRX_HEADER_ROW.IDTRX_ID)
                   GROUP BY
                         H.ERP_ARINVOICE_ID
                        ,H.ERP_ARINVOICE_CODE
                        ,H.CUSTOMER_CODE
                        ,H.ERP_OU_ID
                        ,H.SO_NUM
                   )LOOP
                          N_ALL_AMOUNT := N_ALL_AMOUNT+TRX_LINE_ROW.MATERIAL_TRX_AMOUNT;
            
                          IF TRX_LINE_ROW.ERP_ARINVOICE_ID IS NULL THEN
                                 RAISE_APPLICATION_ERROR(-20001,TRX_LINE_ROW.SO_NUM||'未回写发票号'); 
                          END IF; 
                        /*  
                          IF N_CURRENT_COUNT>0 THEN
                            
                              N_REQ_HEADE_ID := S_CUX_ICP_INVOICE_TAX_CONTR.NEXTVAL;
                              
                              INSERT 
                                INTO
                                 INTF_CUX_ICP_INVOICE_TAX_CONTR(
                                      REQ_HEADER_ID
                                     ,CUSTOMER_NUMBER
                                     ,CUSTOMER_TRX_ID
                                     ,TRX_NUMBER
                                     ,INVOICE_TYPE
                                     ,PROCESS_TYPE
                                     ,PROCESS_FLAG
                                     ,INVOICE_NO
                                     ,INVOICE_DATE
                                     ,INVOICE_AMOUNT
                                     ,TAX_RATE
                                     ,TAX_AMOUNT
                                     ,SET_OF_BOOKS_ID
                                     ,ORG_ID
                                     ,SOURCE_CODE
                                     ,SOURCE_NUM
                                     ,ESB_SERIAL_NUM
                                     ,ESB_DATA_SOURCE
                                     ,SOURCE_LINE_NUM
                                     ,REQUEST_ID
                                     ,PROCESS_STATUS
                                     ,PROCESS_MESSAGE
                                     ,ATTRIBUTE1
                                     ,ATTRIBUTE2
                                     ,ATTRIBUTE3
                                     ,ATTRIBUTE4
                                     ,ATTRIBUTE5
                                     ,ATTRIBUTE6
                                     ,ATTRIBUTE7
                                     ,ATTRIBUTE8
                                     ,ATTRIBUTE9
                                     ,ATTRIBUTE10
                                     ,TRX_ID
                                     ,CREATED_BY
                                     ,LAST_UPDATED_BY
                                     ,CREATION_DATE
                                     ,LAST_UPDATE_DATE
                                     ,INTF_STATUS
                                     ,ERROR_FLAG
                                     ,ERROR_MSG
                                     ,POST_DATE
                                     ,RETURN_DATE
                                     ,RESPONSE_TYPE
                                     ,RESPONSE_CODE
                                     ,RESPONSE_MESSAGE
                                     ,OPERSTATUS
                                     ,ENTITY_ID
                                     ,SO_NUM
                                     ,SOURCE_HEADER_ID
                                     ,CUSTOMER_TRX_AMOUNT
                                     ,CUSTOMER_TAX_AMOUNT
                                 )
                              VALUES(
                                  TRX_HEADER_ROW.REQ_HEADER_ID
                                 ,TRX_LINE_ROW.CUSTOMER_CODE
                                 ,TRX_LINE_ROW.ERP_ARINVOICE_ID
                                 ,TRX_LINE_ROW.ERP_ARINVOICE_CODE
                                 ,TRX_HEADER_ROW.TRX_TYPE
                                 ,'C'
                                 ,'1'
                                 ,S_INVOICE_NO
                                 ,S_OLD_TRX_DATE
                                 ,TRX_HEADER_ROW.TRX_ACCOUNT
                                 ,TRX_HEADER_ROW.TRX_RATE
                                 ,TRX_HEADER_ROW.TAX_AMOUNT
                                 ,N_SET_OF_BOOKS_ID--分类账id
                                 ,TRX_LINE_ROW.ERP_OU_ID
                                 ,'CIMS'
                                 ,N_REQ_HEADE_ID
                                 ,null
                                 ,'ERP-IMS-078'--ESB数据来源
                                 ,null
                                 ,null
                                 ,null
                                 ,null
                                 ,'IMS'||TRX_HEADER_ROW.IDTRX_ID --ATTRIBUTE1
                                 ,null
                                 ,null
                                 ,null
                                 ,null
                                 ,null
                                 ,null
                                 ,null
                                 ,null
                                 ,null --扩展字段
                                 ,N_REQ_HEADE_ID
                                 ,'admin'
                                 ,'admin'
                                 ,sysdate
                                 ,sysdate
                                 ,'N'
                                 ,null
                                 ,null
                                 ,null
                                 ,null
                                 ,null
                                 ,null
                                 ,null
                                 ,'N'
                                 ,TRX_HEADER_ROW.ENTITY_ID
                                 ,TRX_LINE_ROW.SO_NUM
                                 ,TRX_HEADER_ROW.IDTRX_ID
                                 ,TRX_LINE_ROW.MATERIAL_TRX_AMOUNT
                                 ,TRX_LINE_ROW.MATERIAL_TRX_AMOUNT-TRX_LINE_ROW.MATERIAL_AMOUNT
                               );    
                          END IF;*/
                          
                          N_REQ_HEADE_ID := S_CUX_ICP_INVOICE_TAX_CONTR.NEXTVAL;
                          
                          INSERT 
                            INTO
                             INTF_CUX_ICP_INVOICE_TAX_CONTR(
                                  REQ_HEADER_ID
                                 ,CUSTOMER_NUMBER
                                 ,CUSTOMER_TRX_ID
                                 ,TRX_NUMBER
                                 ,INVOICE_TYPE
                                 ,PROCESS_TYPE
                                 ,PROCESS_FLAG
                                 ,INVOICE_NO
                                 ,INVOICE_DATE
                                 ,INVOICE_AMOUNT
                                 ,TAX_RATE
                                 ,TAX_AMOUNT
                                 ,SET_OF_BOOKS_ID
                                 ,ORG_ID
                                 ,SOURCE_CODE
                                 ,SOURCE_NUM
                                 ,ESB_SERIAL_NUM
                                 ,ESB_DATA_SOURCE
                                 ,SOURCE_LINE_NUM
                                 ,REQUEST_ID
                                 ,PROCESS_STATUS
                                 ,PROCESS_MESSAGE
                                 ,ATTRIBUTE1
                                 ,ATTRIBUTE2
                                 ,ATTRIBUTE3
                                 ,ATTRIBUTE4
                                 ,ATTRIBUTE5
                                 ,ATTRIBUTE6
                                 ,ATTRIBUTE7
                                 ,ATTRIBUTE8
                                 ,ATTRIBUTE9
                                 ,ATTRIBUTE10
                                 ,TRX_ID
                                 ,CREATED_BY
                                 ,LAST_UPDATED_BY
                                 ,CREATION_DATE
                                 ,LAST_UPDATE_DATE
                                 ,INTF_STATUS
                                 ,ERROR_FLAG
                                 ,ERROR_MSG
                                 ,POST_DATE
                                 ,RETURN_DATE
                                 ,RESPONSE_TYPE
                                 ,RESPONSE_CODE
                                 ,RESPONSE_MESSAGE
                                 ,OPERSTATUS
                                 ,ENTITY_ID
                                 ,SO_NUM
                                 ,SOURCE_HEADER_ID
                                 ,CUSTOMER_TRX_AMOUNT
                                 ,CUSTOMER_TAX_AMOUNT
                             )
                          VALUES(
                              TRX_HEADER_ROW.REQ_HEADER_ID
                             ,TRX_LINE_ROW.CUSTOMER_CODE
                             ,TRX_LINE_ROW.ERP_ARINVOICE_ID
                             ,TRX_LINE_ROW.ERP_ARINVOICE_CODE
                             ,(CASE
                                    WHEN LENGTH(TRX_HEADER_ROW.TRX_CODE)>=18  THEN SUBSTR(TRX_HEADER_ROW.TRX_CODE, 0, LENGTH(TRX_HEADER_ROW.TRX_CODE)-8) 
                                    ELSE TRX_HEADER_ROW.TRX_CODE 
                              END)
                             ,'I'
                             ,'1'
                             ,(CASE
                                  --  WHEN (TRX_HEADER_ROW.SOURCE_SYSTEM = 'ECM' AND TRX_HEADER_ROW.REQ_HEADER_ID IS NULL)   THEN 'ECM00001'
                                    WHEN LENGTH(TRX_HEADER_ROW.TRX_CODE)>=18  THEN SUBSTR(TRX_HEADER_ROW.TRX_CODE,-8) 
                                    ELSE TRX_HEADER_ROW.TRX_CODE 
                              END)
                             --,TRX_HEADER_ROW.TRX_CODE
                             ,to_char(TRX_HEADER_ROW.TRX_DATE,'yyyy-mm-dd')
                             ,TRX_HEADER_ROW.TRX_ACCOUNT
                             ,NVL(TRX_HEADER_ROW.TRX_RATE,0)/100
                             ,TRX_HEADER_ROW.TAX_AMOUNT
                             ,N_SET_OF_BOOKS_ID--分类账id
                             ,TRX_LINE_ROW.ERP_OU_ID
                             ,'CIMS'
                             ,N_REQ_HEADE_ID
                             ,null
                             ,'ERP-IMS-078'--ESB数据来源
                             ,null
                             ,null
                             ,null
                             ,null
                             ,'IMS'||TRX_HEADER_ROW.IDTRX_ID --ATTRIBUTE1
                             ,(CASE WHEN ((TRX_HEADER_ROW.SOURCE_SYSTEM = 'ECM' AND TRX_HEADER_ROW.REQ_HEADER_ID IS NULL) OR TRX_HEADER_ROW.TRX_ACCOUNT=0)  THEN 'XY' 
                                    WHEN  TRX_HEADER_ROW.REQ_HEADER_ID IS NOT NULL  THEN 'ICP' 
                               ELSE NULL END)--虚拟ERP补检查金额
                             ,null 
                             ,null
                             ,null
                             ,null
                             ,null
                             ,null
                             ,null
                             ,null --扩展字段
                             ,N_REQ_HEADE_ID
                             ,'admin'
                             ,'admin'
                             ,sysdate
                             ,sysdate
                             ,'N'
                             ,null
                             ,null
                             ,null
                             ,null
                             ,null
                             ,null
                             ,null
                             ,'N'
                             ,TRX_HEADER_ROW.ENTITY_ID
                             ,TRX_LINE_ROW.SO_NUM
                             ,TRX_HEADER_ROW.IDTRX_ID
                             ,TRX_LINE_ROW.MATERIAL_TRX_AMOUNT
                             ,TRX_LINE_ROW.MATERIAL_TRX_AMOUNT-TRX_LINE_ROW.MATERIAL_AMOUNT
                           );    
               END LOOP;    
                        
               UPDATE T_SO_TRX_HEADERS SET INTF_TAX_FLAG = 'Y',INTF_ERROR_MSG=null WHERE IDTRX_ID = TRX_HEADER_ROW.IDTRX_ID ;     
               IF abs(nvl(N_ALL_AMOUNT,0) - nvl(TRX_HEADER_ROW.TRX_ACCOUNT,0))>0.5  THEN
                    NULL;
                    --   RAISE_APPLICATION_ERROR(-20001,'开票行汇总金额跟开票头金额不一致'); 
               END IF; 
               COMMIT;   
           EXCEPTION
                WHEN OTHERS THEN
                     ROLLBACK TO SAVEPOINT SP;
                     --设置ESB异步回调处理错误
                     S_ERR_MESSAGE := substr(sqlerrm,1,100);
                     UPDATE 
                       T_SO_TRX_HEADERS 
                     SET 
                     INTF_TAX_FLAG = 'E'
                    ,INTF_ERROR_MSG = S_ERR_MESSAGE
                    WHERE IDTRX_ID = TRX_HEADER_ROW.IDTRX_ID;    
          END;
        END LOOP;
  END; 
  
    --------------------------------------------------------------------------
  --Author: guibr
  --Created: 2016-10-19
  --处理内部客户关联交易号更新发票接口
  --------------------------------------------------------------------------
  Procedure P_ENTITY_CUST_INVOICE_INTF(
                           IN_ENTITY_ID IN NUMBER,
                             OS_MESSAGE OUT VARCHAR2) --返回值     
    IS     
    N_SET_OF_BOOKS_ID NUMBER;
    S_ERR_MESSAGE VARCHAR2(500);
    N_REQ_HEADE_ID NUMBER;
  BEGIN
     OS_MESSAGE :='OK';
     FOR 
       TRX_HEADER_ROW 
       IN(
           SELECT 
             SOURCE_HEADER_ID
            ,TRX_ID
            ,ORG_ID
            ,REQ_HEADER_ID
          FROM
             INTF_CUX_ICP_INVOICE_REQ_HEAD 
          WHERE INTF_STATUS='S' 
            AND OPERSTATUS='N'
            AND REQ_HEADER_ID IS NOT NULL
            AND ENTITY_ID = IN_ENTITY_ID
      )LOOP
        BEGIN 
          SAVEPOINT SP;
          SELECT
               NVL(MAX(SET_OF_BOOKS_ID),0) 
          INTO 
               N_SET_OF_BOOKS_ID 
          FROM T_INV_ORGANIZATION
          WHERE OPERATING_UNIT = TRX_HEADER_ROW.ORG_ID;  
          
          FOR 
                 TRX_LINE_ROW 
                 IN(
                   SELECT 
                       H.ERP_ARINVOICE_ID
                      ,H.ERP_ARINVOICE_CODE
                      ,H.CUSTOMER_CODE
                      ,H.ERP_OU_ID
                      ,H.SO_NUM
                      ,H.ENTITY_ID
                  FROM 
                      T_SO_HEADER H
                  WHERE H.SO_HEADER_ID IN(
                        SELECT
                           SO_HEAD_ID
                        FROM 
                            T_SO_TRX_HEADER_RELATION
                        WHERE 
                           IDTRX_ID = TRX_HEADER_ROW.SOURCE_HEADER_ID
                   )        
                )LOOP                                            
                     IF TRX_LINE_ROW.ERP_ARINVOICE_ID IS NULL THEN
                          RAISE_APPLICATION_ERROR(-20001,TRX_LINE_ROW.SO_NUM||'未回写发票号'); 
                     END IF; 
                     
                     N_REQ_HEADE_ID := S_INVOICE_TRAN_NUM.NEXTVAL;
                     
                     INSERT 
                         INTO
                          INTF_AR_INVOICE_TRAN_NUM(
                           SET_OF_BOOKS_ID
                          ,ORG_ID
                          ,REQ_HEADER_ID
                          ,CUSTOMER_TRX_ID
                          ,SOURCE_CODE
                          ,SOURCE_NUM
                          ,SOURCE_LINE_NUM
                          ,ESB_SERIAL_NUM
                          ,ESB_DATA_SOURCE
                          ,ATTRIBUTE1
                          ,ATTRIBUTE2
                          ,ATTRIBUTE3
                          ,ATTRIBUTE4
                          ,ATTRIBUTE5
                          ,TRX_ID
                          ,CREATED_BY
                          ,LAST_UPDATED_BY
                          ,CREATION_DATE
                          ,LAST_UPDATE_DATE
                          ,INTF_STATUS
                          ,ERROR_FLAG
                          ,ERROR_MSG
                          ,POST_DATE
                          ,RETURN_DATE
                          ,RESPONSE_TYPE
                          ,RESPONSE_CODE
                          ,RESPONSE_MESSAGE
                          ,OPERSTATUS
                          ,ENTITY_ID
                          ,SO_NUM
                          ,SOURCE_HEADER_ID
                          )
                      VALUES(
                           N_SET_OF_BOOKS_ID
                          ,TRX_LINE_ROW.ERP_OU_ID
                          ,TRX_HEADER_ROW.REQ_HEADER_ID
                          ,TRX_LINE_ROW.ERP_ARINVOICE_ID
                          ,'CIMS'
                          ,N_REQ_HEADE_ID
                          ,TRX_LINE_ROW.SO_NUM
                          ,null
                          ,'ERP-IMS-079' 
                          ,null
                          ,null
                          ,null
                          ,null
                          ,null
                          ,N_REQ_HEADE_ID
                          ,'admin'
                          ,'admin'
                          ,sysdate
                          ,sysdate
                          ,'N'
                          ,null
                          ,null
                          ,null
                          ,null
                          ,null
                          ,null
                          ,null
                          ,'N'
                          ,TRX_LINE_ROW.ENTITY_ID
                          ,TRX_LINE_ROW.SO_NUM
                          ,TRX_HEADER_ROW.SOURCE_HEADER_ID
                      );
                END LOOP;    
                
                UPDATE 
                        INTF_CUX_ICP_INVOICE_REQ_HEAD 
                SET 
                        OPERSTATUS = 'S'
                       ,ERROR_MSG = NULL
                WHERE SOURCE_HEADER_ID = TRX_HEADER_ROW.SOURCE_HEADER_ID; 
                COMMIT;
          EXCEPTION
                WHEN OTHERS THEN
                     ROLLBACK TO SAVEPOINT SP;
                     --设置ESB异步回调处理错误
                     S_ERR_MESSAGE := substr(sqlerrm,1,80);
                     UPDATE 
                        INTF_CUX_ICP_INVOICE_REQ_HEAD 
                     SET 
                        OPERSTATUS = 'E'
                       ,ERROR_MSG = S_ERR_MESSAGE
                    WHERE SOURCE_HEADER_ID = TRX_HEADER_ROW.SOURCE_HEADER_ID; 
          END;
        END LOOP;
  END; 
  
  
   
  
      --------------------------------------------------------------------------
  --Author: guibr
  --Created: 2016-10-23
  --处理接口处理标志重置
  --------------------------------------------------------------------------
  Procedure P_ENTITY_CUST_RESET(OS_MESSAGE Out Varchar2)   --返回值    
    IS
  BEGIN
    
      UPDATE 
        T_SO_TRX_HEADERS 
      SET 
        INTF_REQ_FLAG = 'N'
       ,INTF_ERROR_MSG = NULL
      WHERE 
         INTF_REQ_FLAG = 'E'; 
         
       UPDATE 
         T_SO_TRX_HEADERS 
       SET 
         INTF_TAX_FLAG = 'N'
        ,INTF_ERROR_MSG = NULL
      WHERE 
         INTF_TAX_FLAG = 'E';
         
      UPDATE 
          INTF_CUX_ICP_INVOICE_REQ_HEAD 
       SET 
          OPERSTATUS = 'N'
         ,ERROR_MSG = NULL
      WHERE 
          OPERSTATUS = 'E';   
            
      UPDATE 
         INTF_INV_TRANSACTION_HEAD 
       SET 
          OPERSTATUS = 'N'
         ,ERROR_MSG = NULL
      WHERE 
          OPERSTATUS = 'E';  
               
  END P_ENTITY_CUST_RESET;  
  
  
 --------------------------------------------------------------------------
  --Author: guibr
  --Created: 2016-12-09
  --销售单对冲自动写入关联交易预开票
  --------------------------------------------------------------------------
  Procedure P_ENTITY_SO_TAX(
                            IN_ENTITY_ID IN NUMBER,
                             OS_MESSAGE OUT VARCHAR2) --返回值  
   IS     
    N_ACCOUNT_ID   NUMBER;
    S_ACCOUNT_CODE VARCHAR2(100);
    N_ENTITY_ID NUMBER;
    N_ERP_OU_ID NUMBER;
    S_CUSTOMER_CODE VARCHAR2(100);
    N_TRX_OI_HEADERS_ID NUMBER;
    S_TRX_HEADER_CODE   VARCHAR2(100);
    S_ERROR_MSG VARCHAR2(10000);
    S_SO_NUM_STR VARCHAR2(10000);
    S_ENTITY_CUST_FLAG VARCHAR2(30);
    
    S_CREATED_BY VARCHAR2(100); 
    S_INVOICE_NUM_LIST VARCHAR2(10000);
    N_TRX_COUNT NUMBER;
    N_TRX_RATE NUMBER;
    S_PARAM_ECM_COLLECT VARCHAR2(100); 
    V_AR_VAT_RATE varchar2(50);  
  BEGIN
       OS_MESSAGE :='OK';
       S_ACCOUNT_CODE :='-1';
       S_CUSTOMER_CODE :='-1';
       N_ENTITY_ID :=0;
       N_ERP_OU_ID :=0;
       S_SO_NUM_STR :='';
       
       S_ENTITY_CUST_FLAG :='-1';
       S_CREATED_BY := '-1';
       S_INVOICE_NUM_LIST :='-1';
       N_TRX_COUNT :=0;
       S_PARAM_ECM_COLLECT := PKG_BD.F_GET_PARAMETER_VALUE('ECM_TAX_ERP_COLLECT', IN_ENTITY_ID, NULL, NULL); 
       V_AR_VAT_RATE := PKG_BD.F_GET_PARAMETER_VALUE('AR_VAT_RATE', IN_ENTITY_ID, NULL, NULL); 
       N_TRX_RATE :=-1;
       FOR 
         TRX_HEADER_ROW 
       IN(   
              SELECT 
                  H.SETTLE_AMOUNT * P.APPLIED_PLUS_MINUS_FLAG
                 ,H.CUSTOMER_ID
                 ,H.CUSTOMER_CODE
                 ,H.ACCOUNT_ID
                 ,H.ACCOUNT_CODE 
                 ,C.CUSTOMER_REGISTRATION_TYPE
                 ,H.SALES_CENTER_ID
                 ,H.SALES_CENTER_NAME
                 ,H.ENTITY_ID
                 ,H.ERP_OU_ID
                 ,h.CUSTOMER_NAME
                 ,h.INVOICE_CORPORATION
                 ,H.SO_HEADER_ID
                 ,P.APPLIED_PLUS_MINUS_FLAG
                 ,H.SO_NUM
                 ,H.ENTITY_CUST_FLAG
                 ,H.CREATED_BY
                 ,H.INVOICE_NUM_LIST
                 ,H.SO_NUM OLD_NUM
                ,(SELECT TAX_RATE FROM T_SO_LINE L WHERE L.SO_HEADER_ID=H.SO_HEADER_ID AND ROWNUM=1 ) TAX_RATE
               FROM CIMS.T_SO_HEADER H 
               INNER JOIN T_SO_TYPE_EXTEND P ON H.ENTITY_ID = P.ENTITY_ID AND H.BILL_TYPE_ID = P.BILL_TYPE_ID
                LEFT JOIN T_CUSTOMER_HEADER C ON H.CUSTOMER_ID = C.CUSTOMER_ID
            WHERE 
              NOT EXISTS (
                SELECT 1 FROM  CIMS.T_SO_TRX_HEADER_RELATION R WHERE R.SO_HEAD_ID = H.SO_HEADER_ID
              ) AND H.INVOICE_NUM_LIST IS NOT NULL 
                AND H.SO_STATUS = 12 
              --  AND H.ENTITY_CUST_FLAG = 'Y'
                AND h.biz_src_bill_type_code in('1001','1003')
                AND H.Settle_Date>=to_date('2017-01-04','yyyy-mm-dd')
                AND H.Entity_Id = IN_ENTITY_ID
                AND rownum <= 10000
               
              union all  
                
              SELECT 
                   H.SETTLE_AMOUNT * P.APPLIED_PLUS_MINUS_FLAG
                  ,H.CUSTOMER_ID
                  ,H.CUSTOMER_CODE
                  ,H.ACCOUNT_ID
                  ,H.ACCOUNT_CODE 
                  ,C.CUSTOMER_REGISTRATION_TYPE
                  ,H.SALES_CENTER_ID
                  ,H.SALES_CENTER_NAME
                  ,H.ENTITY_ID
                  ,H.ERP_OU_ID
                  ,h.CUSTOMER_NAME
                  ,h.INVOICE_CORPORATION
                  ,H.SO_HEADER_ID
                  ,P.APPLIED_PLUS_MINUS_FLAG
                  ,H.SO_NUM
                  ,H.ENTITY_CUST_FLAG
                  ,(select CREATED_BY from T_SO_HEADER HR where HR.SO_NUM=H.ORIG_SO_NUM ) CREATED_BY
                  ,H.INVOICE_NUM_LIST
                  ,H.ORIG_SO_NUM OLD_NUM
                  ,(SELECT TAX_RATE FROM T_SO_LINE L WHERE L.SO_HEADER_ID=H.SO_HEADER_ID AND ROWNUM=1 ) TAX_RATE
              FROM CIMS.T_SO_HEADER H 
              INNER JOIN T_SO_TYPE_EXTEND P ON H.ENTITY_ID = P.ENTITY_ID AND H.BILL_TYPE_ID = P.BILL_TYPE_ID
               LEFT JOIN T_CUSTOMER_HEADER C ON H.CUSTOMER_ID = C.CUSTOMER_ID
              WHERE 
              NOT EXISTS (
                SELECT 1 FROM  CIMS.T_SO_TRX_HEADER_RELATION R WHERE R.SO_HEAD_ID = H.SO_HEADER_ID
              ) AND H.INVOICE_NUM_LIST IS NOT NULL 
                AND H.SO_STATUS = 12 
              --  AND H.ENTITY_CUST_FLAG = 'Y'
                AND h.biz_src_bill_type_code in('1002','1004') 
                AND H.Entity_Id = IN_ENTITY_ID
                AND H.Settle_Date>=to_date('2017-01-04','yyyy-mm-dd')
                AND EXISTS (
                 SELECT 1 FROM CIMS.T_SO_HEADER O WHERE  H.ORIG_SO_NUM = O.SO_NUM AND O.SO_STATUS = 12
                )
                AND rownum <= 10000
              ORDER BY 
                 ENTITY_ID
                ,ERP_OU_ID
                ,CUSTOMER_ID
                ,CUSTOMER_CODE
                ,ACCOUNT_ID
                ,ACCOUNT_CODE
                ,ENTITY_CUST_FLAG
                ,INVOICE_NUM_LIST
                ,OLD_NUM
                ,CREATED_BY
        )LOOP
           BEGIN 
               IF    (TRX_HEADER_ROW.CUSTOMER_CODE <> S_CUSTOMER_CODE
                 OR TRX_HEADER_ROW.ACCOUNT_CODE <> S_ACCOUNT_CODE 
                 OR TRX_HEADER_ROW.ENTITY_ID <> N_ENTITY_ID
                 OR TRX_HEADER_ROW.ERP_OU_ID  <> N_ERP_OU_ID 
                 OR  NVL(TRX_HEADER_ROW.ENTITY_CUST_FLAG,'N')  <> S_ENTITY_CUST_FLAG 
                 OR (TRX_HEADER_ROW.CREATED_BY  <> S_CREATED_BY AND TRX_HEADER_ROW.CREATED_BY = 'ECM' )
                 OR TRX_HEADER_ROW.INVOICE_NUM_LIST  <> S_INVOICE_NUM_LIST
                 OR NVL(TRX_HEADER_ROW.TAX_RATE,'-1')  <> N_TRX_RATE
                 OR N_TRX_COUNT>100)
               THEN 
                IF N_ENTITY_ID <>0 THEN
                       P_ENTITY_SO_TAX_AUTO(N_TRX_OI_HEADERS_ID,S_SO_NUM_STR,S_ENTITY_CUST_FLAG,S_CREATED_BY,S_INVOICE_NUM_LIST,S_PARAM_ECM_COLLECT,NVL(N_TRX_RATE,V_AR_VAT_RATE),S_ERROR_MSG);       
                     COMMIT;     
                END IF;
                
                 SAVEPOINT SP;
                 S_CUSTOMER_CODE := TRX_HEADER_ROW.CUSTOMER_CODE;
                 S_ACCOUNT_CODE := TRX_HEADER_ROW.ACCOUNT_CODE;
                 N_ENTITY_ID   :=TRX_HEADER_ROW.ENTITY_ID;
                 N_ERP_OU_ID := TRX_HEADER_ROW.ERP_OU_ID;
                 
                 S_CREATED_BY := TRX_HEADER_ROW.CREATED_BY;
                 S_INVOICE_NUM_LIST := TRX_HEADER_ROW.INVOICE_NUM_LIST;
                 N_TRX_RATE := TRX_HEADER_ROW.TAX_RATE;
                 
                 S_ENTITY_CUST_FLAG := NVL(TRX_HEADER_ROW.ENTITY_CUST_FLAG,'N');
                 N_TRX_OI_HEADERS_ID := S_SO_TRX_OI_HEADERS.Nextval;
                 S_SO_NUM_STR :='';
                 N_TRX_COUNT :=0;
                 
                 INSERT 
                    INTO 
                      T_SO_TRX_OI_HEADERS(
                        TOH_ID
                       ,TRX_TYPE
                       ,STATE
                       ,COMMENTS
                       ,OI_FLAG
                       ,OI_ID
                       ,TRX_CUSTOMER_ID
                       ,SALES_CENTER_ID
                       ,ENTITY_ID
                       ,CREATED_BY
                       ,CREATION_DATE
                       ,LAST_UPDATED_BY
                       ,LAST_UPDATE_DATE
                       ,TRANS_TYPE
                       ,TRANS_PARAM
                       ,ACCOUNT_ID
                       ,ERP_OU_ID
                       ,ATTRIBUTE1
                       ,ATTRIBUTE2
                       ,ATTRIBUTE3
                       ,ATTRIBUTE4
                       ,ATTRIBUTE5
                       ,ATTRIBUTE6
                       ,INVOICE_CORPORATION
                      )values(
                         N_TRX_OI_HEADERS_ID
                        ,'INCREMENT_TRX_MATCH'
                        ,'TS_IN_QUEUE'
                        ,null
                        ,null
                        ,null
                        ,TRX_HEADER_ROW.CUSTOMER_ID
                        ,TRX_HEADER_ROW.SALES_CENTER_ID
                        ,TRX_HEADER_ROW.ENTITY_ID
                        ,'admin'
                        ,sysdate
                        ,'admin'
                        ,sysdate
                        ,'NORMAL'
                        ,null
                        ,TRX_HEADER_ROW.ACCOUNT_ID
                        ,TRX_HEADER_ROW.ERP_OU_ID
                        ,TRX_HEADER_ROW.CUSTOMER_CODE
                        ,TRX_HEADER_ROW.CUSTOMER_NAME
                        ,TRX_HEADER_ROW.CUSTOMER_REGISTRATION_TYPE
                        ,null
                        ,null
                        ,null
                        ,TRX_HEADER_ROW.INVOICE_CORPORATION
                      );
               END IF; 
               
               N_TRX_COUNT :=N_TRX_COUNT+1;
               S_SO_NUM_STR  := S_SO_NUM_STR||','||TRX_HEADER_ROW.SO_NUM;
               INSERT
                   INTO 
                   T_SO_TRX_OI_LINES
                    (TOL_ID
                    ,TOH_ID
                    ,ENTITY_ID
                    ,LINE_ID
                    ,ITEM_ID
                    ,PRICE
                    ,QUANTITY
                    ,DISCOUNT
                    ,TRX_RATE
                    ,CREATED_BY
                    ,CREATION_DATE
                    ,LAST_UPDATED_BY
                    ,LAST_UPDATE_DATE)
                 SELECT 
                    S_SO_TRX_OI_LINES.NEXTVAL
                   ,N_TRX_OI_HEADERS_ID
                   ,TRX_HEADER_ROW.ENTITY_ID
                   ,L.SO_LINE_ID
                   ,L.ITEM_ID
                   ,L.ITEM_SETTLE_PRICE
                   ,L.ITEM_QTY * TRX_HEADER_ROW.APPLIED_PLUS_MINUS_FLAG
                   ,NVL(L.DISCOUNT_RATE,0) + NVL(L.MONTH_DISCOUNT_RATE,0)
                   ,NVL(N_TRX_RATE,V_AR_VAT_RATE)
                   ,'admin'
                   ,SYSDATE
                   ,'admin'
                   ,SYSDATE
                FROM CIMS.T_SO_LINE L
                WHERE SO_HEADER_ID = TRX_HEADER_ROW.SO_HEADER_ID;       
          EXCEPTION
                WHEN OTHERS THEN
                     ROLLBACK TO SAVEPOINT SP;
                     --设置ESB异步回调处理错误         
                     S_ERROR_MSG := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_INVOICE.P_ENTITY_SO_TAX', SQLCODE,
            '销售单对冲自动写入预开票失败！。异常消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
                
            END;
        END LOOP;
        
        IF  S_SO_NUM_STR IS NOT NULL 
          AND LENGTH(S_SO_NUM_STR)>0
              THEN
             IF N_ENTITY_ID <>0 THEN
                    P_ENTITY_SO_TAX_AUTO(N_TRX_OI_HEADERS_ID,S_SO_NUM_STR,S_ENTITY_CUST_FLAG,S_CREATED_BY,S_INVOICE_NUM_LIST,S_PARAM_ECM_COLLECT,NVL(N_TRX_RATE,V_AR_VAT_RATE),S_ERROR_MSG);       
                  COMMIT;     
              END IF;
        END IF;  
   EXCEPTION
          WHEN OTHERS THEN
               ROLLBACK TO SAVEPOINT SP;      
               S_ERROR_MSG := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_INVOICE.P_ENTITY_SO_TAX', SQLCODE,
      '销售单对冲自动写入预开票失败！。异常消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
                
   
  END P_ENTITY_SO_TAX;
  
  
    --------------------------------------------------------------------------
  --Author: guibr
  --Created: 2016-12-09
  --销售单对冲自动写入发票池
  --------------------------------------------------------------------------
  Procedure P_ENTITY_SO_TAX_AUTO(
                             IN_HEADERS_ID IN NUMBER,
                             IS_NUM_STR IN VARCHAR2,
                             IS_ENTITY_FLAG IN VARCHAR2,
                             IS_CREATED_BY IN VARCHAR2,
                             IS_INVOICE_NUM IN VARCHAR2,
                             IS_PARAM_ECM_COLLECT IN VARCHAR2,
                             IS_VAT_RATE IN VARCHAR2,
                             OS_MESSAGE OUT VARCHAR2) --返回值     
     IS     
     
    N_SO_TRX_HEAD_ID    NUMBER;
    S_TRX_HEADER_CODE   VARCHAR2(100);
    S_ERROR_MSG VARCHAR2(10000);
    
    N_TRX_SUM_VALUE   NUMBER;
    N_SO_TAX_AMOUNT   NUMBER;
    
    S_ENTITY_FLAG    VARCHAR2(100);
    S_TAX_FLAG    VARCHAR2(100);
    
  BEGIN     
          OS_MESSAGE :='OK';                      
          N_SO_TRX_HEAD_ID := S_SO_TRX_HEADERS.Nextval;
          S_TRX_HEADER_CODE := Trim(To_Char(N_SO_TRX_HEAD_ID, '0000000000'));
          
          S_ENTITY_FLAG :=nvl(IS_ENTITY_FLAG,'N');
                          
          UPDATE T_SO_TRX_OI_HEADERS SET COMMENTS = substr(IS_NUM_STR,1,1200)
          WHERE TOH_ID = IN_HEADERS_ID;
                          
               --产生发票池头数据
          INSERT INTO T_SO_TRX_HEADERS
            (IDTRX_ID,
             CREATED_BY,
             CREATION_DATE,
             LAST_UPDATED_BY,
             LAST_UPDATE_DATE,
             TRX_HEADER_CODE,
             TRX_CODE,
             TRX_TYPE,
             TRX_DATE,
             TRX_CHECKER,
             TRX_MAKER,
             COMMENTS,
             PRINTABLE,
             STATE,
             CENTER_SIGN_FLAG,
             CUSTOMER_SIGN_FLAG,
             HQ_SIGN_FLAG,
             EMS_CODE,
             HAVE_SIGNIN_FLAG,
             CENTER_SIGN_DATE,
             CUSTOMER_SIGN_DATE,
             HQ_SIGN_DATE,
             HIDE_DISCOUNT_LINE,
             ERP_OU_ID,
             VOUCHER_HEADER_ID,
             VOUCHER_NUMBER,
             SALES_CENTER_ID,
             CUSTOMER_ID,
             ENTITY_ID,
             TRX_FLAG,
             TRX_ACCOUNT,
             TRX_RATEPAYER_TYPE,
             SIGNIN_CODE,
             ACCOUNT_ID,
             ATTRIBUTE1,
             ATTRIBUTE2,
             ATTRIBUTE3,
             ATTRIBUTE4,
             ATTRIBUTE5,
             ATTRIBUTE6,
             INVOICE_CORPORATION,
             CUSTOMER_CODE,
             CUSTOMER_NAME
             )
          SELECT 
             N_SO_TRX_HEAD_ID,
             'admin', 
             SYSDATE,
             'admin',
             SYSDATE,
             S_TRX_HEADER_CODE, 
             NULL, 
             TRX_TYPE, 
             NULL,
             NULL, 
             'admin', 
             COMMENTS,
             'Y', 
             TS_IN_QUEUE,
             'N', 
             'N', 
             'N',
             NULL, 
             NULL, 
             NULL, 
             NULL, 
             NULL, 
             'N', 
             ERP_OU_ID, 
             NULL, 
             NULL, 
             SALES_CENTER_ID, 
             TRX_CUSTOMER_ID, 
             ENTITY_ID, 
             'N', 
             NULL, 
             ATTRIBUTE3, 
             NULL, 
             ACCOUNT_ID,
             NULL, 
             NULL, 
             NULL,
             NULL, 
             NULL, 
             TRANS_TYPE, 
             INVOICE_CORPORATION,
             ATTRIBUTE1,
             ATTRIBUTE2
            FROM 
               T_SO_TRX_OI_HEADERS
            WHERE  TOH_ID =  IN_HEADERS_ID;
                        
            P_CREATE_SO_TRX_ADDED(IN_HEADERS_ID
                                 ,'admin'
                                 ,N_SO_TRX_HEAD_ID
                                 ,100
                                 ,'N'
                                 ,TO_NUMBER(IS_VAT_RATE)
                                 ,S_ERROR_MSG);    
                                                 
            IF S_ERROR_MSG<>'OK' THEN
               RAISE_APPLICATION_ERROR(-20001,S_ERROR_MSG);
            END IF;       
                          
                                    --处理完成回写成功标记
           UPDATE T_SO_TRX_OI_HEADERS STOH
             SET STOH.OI_FLAG          = 'Y',
                 STOH.OI_ID            = N_SO_TRX_HEAD_ID,
                 STOH.LAST_UPDATED_BY  = 'admin',
                 STOH.LAST_UPDATE_DATE = SYSDATE
           WHERE STOH.TOH_ID = IN_HEADERS_ID;  
                           
        /*  SELECT
            SUM(ROUND(STL.PRICE * STL.QUANTITY * (100 - STL.DISCOUNT) / 100,2))
          INTO
            N_TRX_SUM_VALUE
          FROM T_SO_TRX_LINES STL
         WHERE STL.IDTRX_ID = N_SO_TRX_HEAD_ID;*/
         
         SELECT 
             SUM(ROUND(P.APPLIED_PLUS_MINUS_FLAG*L.ITEM_PRICE*((100-NVL(L.DISCOUNT_RATE, 0)-NVL(L.MONTH_DISCOUNT_RATE, 0)) / 100) * L.ITEM_QTY, 2)) MATERIAL_TRX_AMOUNT
           INTO
             N_TRX_SUM_VALUE   
         FROM 
            cims.T_SO_HEADER H
         INNER JOIN cims.T_SO_TYPE_EXTEND P ON H.ENTITY_ID = P.ENTITY_ID AND H.BILL_TYPE_ID = P.BILL_TYPE_ID
         INNER JOIN cims.T_SO_LINE L ON H.SO_HEADER_ID = L.SO_HEADER_ID
         WHERE H.SO_HEADER_ID IN(
            SELECT
               SO_HEAD_ID
            FROM 
                cims.T_SO_TRX_HEADER_RELATION
            WHERE 
               IDTRX_ID = N_SO_TRX_HEAD_ID);
         
         
                          
          SELECT 
             SUM(NVL(MATERIAL_TRX_AMOUNT,0) - NVL(MATERIAL_AMOUNT,0))
          INTO
              N_SO_TAX_AMOUNT
          FROM 
              V_SO_TRX_LINES_OI  
          WHERE   
             TRX_ID = N_SO_TRX_HEAD_ID;  
             N_SO_TAX_AMOUNT :=nvl(N_SO_TAX_AMOUNT,0);
               N_TRX_SUM_VALUE :=nvl(N_TRX_SUM_VALUE,0);
                                   
          UPDATE T_SO_TRX_HEADERS H
           SET H.TRX_ACCOUNT = N_TRX_SUM_VALUE,
               H.TRX_RATE = IS_VAT_RATE,
               H.TAX_AMOUNT = N_SO_TAX_AMOUNT
           WHERE H.IDTRX_ID = N_SO_TRX_HEAD_ID;
       
      IF IS_CREATED_BY = 'ECM' AND  NVL(S_ENTITY_FLAG,'N') <> 'Y' AND IS_PARAM_ECM_COLLECT ='Y'  THEN     --电商单据
         UPDATE T_SO_TRX_HEADERS H
           SET H.TRX_DATE = SYSDATE,
               H.TRX_CODE	='ECM00001',
               H.STATE='TS_PRINTED'
          WHERE H.IDTRX_ID = N_SO_TRX_HEAD_ID;
      ELSE    
          UPDATE T_SO_TRX_HEADERS H
           SET H.TRX_DATE = SYSDATE,
               H.TRX_CODE	= IS_INVOICE_NUM,
               H.STATE='TS_PRINTED'
          WHERE H.IDTRX_ID = N_SO_TRX_HEAD_ID;    
      END IF;  
      
     S_TAX_FLAG :='D';
     IF S_ENTITY_FLAG = 'Y' THEN  --事业部客户
        S_TAX_FLAG :='N';  --需要关联交易
     END IF;
     
     UPDATE T_SO_TRX_HEADERS H
              SET H.ENTITY_CUST_FLAG = S_ENTITY_FLAG
                 ,H.INTF_TAX_FLAG='N'    --税控回写成功
                 ,H.INTF_REQ_FLAG=S_TAX_FLAG
                 ,AUTO_FLAG = 'Y'
                 ,TAX_CONTROL_FLAG='N'
                 ,SOURCE_SYSTEM = IS_CREATED_BY
     WHERE H.IDTRX_ID = N_SO_TRX_HEAD_ID;     
                                     
     UPDATE T_SO_HEADER SOH 
            SET INVOICE_STATUS = '已送审开票'
     WHERE SOH.SO_HEADER_ID IN (
            SELECT STHR.SO_HEAD_ID 
            FROM T_SO_TRX_HEADER_RELATION STHR 
            WHERE STHR.IDTRX_ID = N_SO_TRX_HEAD_ID );                                              
                             
  END P_ENTITY_SO_TAX_AUTO;
  
  
   --------------------------------------------------------------------------
  --Author: guibr
  --Created: 2016-12-09
  --取消开票 取消ERP税控信息
  --------------------------------------------------------------------------
  Procedure P_SO_TAX_CANCEL(IS_IDTRX_ID  IN VARCHAR2,
                            USER_ACCOUNT IN VARCHAR2,
                            OS_MESSAGE OUT VARCHAR2) --返回值  
   IS
      N_SET_OF_BOOKS_ID  NUMBER;    
      N_ALL_AMOUNT       NUMBER; 
      N_REQ_HEADE_ID     NUMBER;
      S_ERR_MESSAGE      VARCHAR(300);  
      N_CURRENT_COUNT    NUMBER;
  BEGIN   
     OS_MESSAGE :='OK';
     FOR 
       TRX_HEADER_ROW 
       IN(
           SELECT 
              H.IDTRX_ID
             ,H.TRX_CODE
             ,H.TRX_DATE
             ,H.ERP_OU_ID
             ,H.ENTITY_ID
             ,H.TRX_ACCOUNT
             ,H.TRX_HEADER_CODE
             ,H.TRX_RATE
             ,H.CUSTOMER_CODE
             ,H.TRX_TYPE
             ,H.REQ_HEADER_ID
             ,H.TAX_AMOUNT
             ,H.SOURCE_SYSTEM
             ,H.TAX_CONTROL_FLAG
             ,H.AUTO_FLAG
             ,H.INTF_REQ_FLAG
           FROM 
              T_SO_TRX_HEADERS H
           WHERE
              H.IDTRX_ID IN( IS_IDTRX_ID )
        )LOOP
          BEGIN 
          
            SELECT
               NVL(MAX(SET_OF_BOOKS_ID),0) 
            INTO 
               N_SET_OF_BOOKS_ID 
            FROM T_INV_ORGANIZATION
            WHERE OPERATING_UNIT = TRX_HEADER_ROW.ERP_OU_ID;
            
            N_ALL_AMOUNT :=0;
            
            SELECT 
                COUNT(*)
            INTO
                N_CURRENT_COUNT  
            FROM 
                INTF_CUX_ICP_INVOICE_TAX_CONTR
            WHERE     
                 PROCESS_TYPE = 'I'
             AND SOURCE_HEADER_ID = TRX_HEADER_ROW.IDTRX_ID;
            
            IF N_CURRENT_COUNT>0 THEN    
                FOR 
                  TRX_LINE_ROW 
                     IN(   
                           SELECT 
                               H.ERP_ARINVOICE_ID
                              ,H.ERP_ARINVOICE_CODE
                              ,H.CUSTOMER_CODE
                              ,H.ERP_OU_ID
                              ,H.SO_NUM
                              ,SUM(
                                     CASE WHEN H.BIZ_SRC_BILL_TYPE_CODE IN('1005','1006','1007','1008') THEN
                                        ROUND(OL.PRICE*((100-NVL(OL.DISCOUNT, 0)) / 100) * OL.QUANTITY, 2)
                                     ELSE
                                        ROUND(L.ITEM_PRICE*((100-NVL(L.DISCOUNT_RATE, 0)-NVL(L.MONTH_DISCOUNT_RATE, 0)) / 100) * OL.QUANTITY, 2)
                                     END 
                               ) MATERIAL_TRX_AMOUNT
                              ,SUM(
                                    CASE WHEN H.BIZ_SRC_BILL_TYPE_CODE IN('1005','1006','1007','1008') THEN
                                        ROUND(OL.PRICE*((100-NVL(OL.DISCOUNT, 0)) / 100) * OL.Quantity /(1 + TRX_HEADER_ROW.TRX_RATE / 100),2)
                                    ELSE
                                        ROUND(L.ITEM_PRICE*((100-NVL(L.DISCOUNT_RATE, 0)-NVL(L.MONTH_DISCOUNT_RATE, 0)) / 100) * OL.Quantity /(1 + TRX_HEADER_ROW.TRX_RATE / 100),2)
                                    END
                               ) MATERIAL_AMOUNT
                            FROM 
                              T_SO_HEADER H
                            INNER JOIN T_SO_TYPE_EXTEND P ON H.ENTITY_ID = P.ENTITY_ID AND H.BILL_TYPE_ID = P.BILL_TYPE_ID
                            INNER JOIN T_SO_LINE L ON  H.SO_HEADER_ID = L.SO_HEADER_ID
                            INNER JOIN T_SO_TRX_OI_HEADERS OH ON  OH.OI_ID = TRX_HEADER_ROW.IDTRX_ID
                            INNER JOIN T_SO_TRX_OI_LINES OL ON  OL.TOH_ID = OH.TOH_ID AND OL.LINE_ID = L.SO_LINE_ID
                            WHERE H.SO_HEADER_ID IN(
                                SELECT
                                   SO_HEAD_ID
                                FROM 
                                    T_SO_TRX_HEADER_RELATION
                                WHERE 
                                   IDTRX_ID = TRX_HEADER_ROW.IDTRX_ID)
                             GROUP BY
                                   H.ERP_ARINVOICE_ID
                                  ,H.ERP_ARINVOICE_CODE
                                  ,H.CUSTOMER_CODE
                                  ,H.ERP_OU_ID
                                  ,H.SO_NUM
                        )LOOP
                                    N_ALL_AMOUNT := N_ALL_AMOUNT+TRX_LINE_ROW.MATERIAL_TRX_AMOUNT;
                      
                                    IF TRX_LINE_ROW.ERP_ARINVOICE_ID IS NULL THEN
                                           RAISE_APPLICATION_ERROR(-20001,'取消ERP税控信息失败:'||TRX_LINE_ROW.SO_NUM||'未回写发票号'); 
                                    END IF; 
                                    
                                    N_REQ_HEADE_ID := S_CUX_ICP_INVOICE_TAX_CONTR.NEXTVAL;
                                        
                                    INSERT 
                                      INTO
                                       INTF_CUX_ICP_INVOICE_TAX_CONTR(
                                            REQ_HEADER_ID
                                           ,CUSTOMER_NUMBER
                                           ,CUSTOMER_TRX_ID
                                           ,TRX_NUMBER
                                           ,INVOICE_TYPE
                                           ,PROCESS_TYPE
                                           ,PROCESS_FLAG
                                           ,INVOICE_NO
                                           ,INVOICE_DATE
                                           ,INVOICE_AMOUNT
                                           ,TAX_RATE
                                           ,TAX_AMOUNT
                                           ,SET_OF_BOOKS_ID
                                           ,ORG_ID
                                           ,SOURCE_CODE
                                           ,SOURCE_NUM
                                           ,ESB_SERIAL_NUM
                                           ,ESB_DATA_SOURCE
                                           ,SOURCE_LINE_NUM
                                           ,REQUEST_ID
                                           ,PROCESS_STATUS
                                           ,PROCESS_MESSAGE
                                           ,ATTRIBUTE1
                                           ,ATTRIBUTE2
                                           ,ATTRIBUTE3
                                           ,ATTRIBUTE4
                                           ,ATTRIBUTE5
                                           ,ATTRIBUTE6
                                           ,ATTRIBUTE7
                                           ,ATTRIBUTE8
                                           ,ATTRIBUTE9
                                           ,ATTRIBUTE10
                                           ,TRX_ID
                                           ,CREATED_BY
                                           ,LAST_UPDATED_BY
                                           ,CREATION_DATE
                                           ,LAST_UPDATE_DATE
                                           ,INTF_STATUS
                                           ,ERROR_FLAG
                                           ,ERROR_MSG
                                           ,POST_DATE
                                           ,RETURN_DATE
                                           ,RESPONSE_TYPE
                                           ,RESPONSE_CODE
                                           ,RESPONSE_MESSAGE
                                           ,OPERSTATUS
                                           ,ENTITY_ID
                                           ,SO_NUM
                                           ,SOURCE_HEADER_ID
                                           ,CUSTOMER_TRX_AMOUNT
                                           ,CUSTOMER_TAX_AMOUNT
                                       )
                                    VALUES(
                                        TRX_HEADER_ROW.REQ_HEADER_ID
                                       ,TRX_LINE_ROW.CUSTOMER_CODE
                                       ,TRX_LINE_ROW.ERP_ARINVOICE_ID
                                       ,TRX_LINE_ROW.ERP_ARINVOICE_CODE
                                       ,TRX_HEADER_ROW.TRX_TYPE
                                       ,'C'
                                       ,'1'
                                       ,(CASE
                                          --    WHEN (TRX_HEADER_ROW.SOURCE_SYSTEM = 'ECM' AND TRX_HEADER_ROW.REQ_HEADER_ID IS NULL)   THEN 'ECM00001'
                                              WHEN LENGTH(TRX_HEADER_ROW.TRX_CODE)>=18  THEN SUBSTR(TRX_HEADER_ROW.TRX_CODE,-8) 
                                              ELSE TRX_HEADER_ROW.TRX_CODE 
                                        END)
                                       --,TRX_HEADER_ROW.TRX_CODE
                                       ,to_char(TRX_HEADER_ROW.TRX_DATE,'yyyy-mm-dd')
                                       ,TRX_HEADER_ROW.TRX_ACCOUNT
                                       ,NVL(TRX_HEADER_ROW.TRX_RATE,0)/100
                                       ,TRX_HEADER_ROW.TAX_AMOUNT
                                       ,N_SET_OF_BOOKS_ID--分类账id
                                       ,TRX_LINE_ROW.ERP_OU_ID
                                       ,'CIMS'
                                       ,N_REQ_HEADE_ID
                                       ,null
                                       ,'ERP-IMS-078'--ESB数据来源
                                       ,null
                                       ,null
                                       ,null
                                       ,null
                                       ,'IMS'||TRX_HEADER_ROW.IDTRX_ID --ATTRIBUTE1
                                       ,(CASE WHEN ((TRX_HEADER_ROW.SOURCE_SYSTEM = 'ECM' AND TRX_HEADER_ROW.REQ_HEADER_ID IS NULL) OR TRX_HEADER_ROW.TRX_ACCOUNT=0)  THEN 'XY' 
                                              WHEN  TRX_HEADER_ROW.REQ_HEADER_ID IS NOT NULL  THEN 'ICP' 
                                              ELSE NULL END)
                                       ,null
                                       ,null
                                       ,null
                                       ,null
                                       ,null
                                       ,null
                                       ,null
                                       ,null --扩展字段
                                       ,N_REQ_HEADE_ID
                                       ,USER_ACCOUNT
                                       ,USER_ACCOUNT
                                       ,sysdate
                                       ,sysdate
                                       ,'N'
                                       ,null
                                       ,null
                                       ,null
                                       ,null
                                       ,null
                                       ,null
                                       ,null
                                       ,'N'
                                       ,TRX_HEADER_ROW.ENTITY_ID
                                       ,TRX_LINE_ROW.SO_NUM
                                       ,TRX_HEADER_ROW.IDTRX_ID
                                       ,TRX_LINE_ROW.MATERIAL_TRX_AMOUNT
                                       ,TRX_LINE_ROW.MATERIAL_TRX_AMOUNT-TRX_LINE_ROW.MATERIAL_AMOUNT
                                     );    
                         END LOOP;    
                 END IF;
                 
                 UPDATE T_SO_TRX_HEADERS SET INTF_TAX_FLAG = 'C',INTF_ERROR_MSG=null WHERE IDTRX_ID = TRX_HEADER_ROW.IDTRX_ID ;     
                        
                 IF abs(nvl(N_ALL_AMOUNT,0) - nvl(TRX_HEADER_ROW.TRX_ACCOUNT,0))>0.5 THEN
                     NULL;
                        -- RAISE_APPLICATION_ERROR(-20001,'取消ERP税控信息失败:开票行汇总金额跟开票头金额不一致'); 
                 END IF; 
               
             --  COMMIT;   
           EXCEPTION
                WHEN OTHERS THEN
                    -- ROLLBACK TO SAVEPOINT SP;
                     --设置ESB异步回调处理错误
                     S_ERR_MESSAGE := substr(sqlerrm,1,100);
                     OS_MESSAGE := S_ERR_MESSAGE;
                     UPDATE 
                       T_SO_TRX_HEADERS 
                     SET INTF_ERROR_MSG = S_ERR_MESSAGE
                    WHERE IDTRX_ID = TRX_HEADER_ROW.IDTRX_ID;    
          END;
        END LOOP;
 
  END P_SO_TAX_CANCEL;  
  
  
    --------------------------------------------------------------------------
  --Author: guibr
  --Created: 2017-03-23
  --取消销售单税控信息CIMS开票
  --------------------------------------------------------------------------                              
  Procedure P_SO_HEADER_CANCEL(IS_SOHEADER_ID IN NUMBER,
                               OS_MESSAGE OUT VARCHAR2) IS
                               
    N_IDTRX_COUNT       NUMBER;  
    S_RETURN_MESSAGE    VARCHAR2(1000);  
                           
  BEGIN
     OS_MESSAGE :='OK';
     FOR 
       TRX_HEADER_ROW 
       IN(
            SELECT 
               IDTRX_ID
            FROM 
               T_SO_TRX_HEADER_RELATION 
            WHERE     
               SO_HEAD_ID = IS_SOHEADER_ID
          )LOOP
             BEGIN
                  SELECT 
                      COUNT(1)
                  INTO
                      N_IDTRX_COUNT
                  FROM 
                     T_SO_TRX_HEADERS 
                  WHERE IDTRX_ID = TRX_HEADER_ROW.IDTRX_ID
                    AND AUTO_FLAG='Y';
                    
                  IF N_IDTRX_COUNT>0 THEN
                     P_SO_TAX_CANCEL(TRX_HEADER_ROW.IDTRX_ID,'ECM',S_RETURN_MESSAGE); 
                     IF  S_RETURN_MESSAGE<> 'OK' THEN
                           S_RETURN_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_INVOICE.P_SO_HEADER_CANCEL', SQLCODE,
                                  '取消开票错误：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM || TRX_HEADER_ROW.IDTRX_ID);
                     END IF;
                     
                      UPDATE T_SO_HEADER SOH 
                        SET INVOICE_STATUS = NULL
                      WHERE SOH.SO_HEADER_ID IN (
                        SELECT STHR.SO_HEAD_ID 
                        FROM T_SO_TRX_HEADER_RELATION STHR 
                        WHERE STHR.IDTRX_ID = TRX_HEADER_ROW.IDTRX_ID );  
                     
                     
                       DELETE FROM T_SO_TRX_LINE_RELATION WHERE TRX_LINE_ID IN(
                           SELECT TRX_LINE_ID FROM  T_SO_TRX_LINES WHERE IDTRX_ID=TRX_HEADER_ROW.IDTRX_ID
                       );
                       DELETE FROM T_SO_TRX_LINES WHERE IDTRX_ID=TRX_HEADER_ROW.IDTRX_ID;
                       
                       DELETE FROM T_SO_TRX_HEADER_RELATION WHERE IDTRX_ID=TRX_HEADER_ROW.IDTRX_ID;
                       
                       DELETE FROM T_SO_TRX_HEADERS WHERE IDTRX_ID=TRX_HEADER_ROW.IDTRX_ID;
                  END IF;    
             END;
           END LOOP; 
   END P_SO_HEADER_CANCEL; 
   
   --------------------------------------------------------------------------
  --Author: guibr
  --Created: 2019-04-01
  --电子发票初始化 指定条件发票走电子票
  --------------------------------------------------------------------------                              
  Procedure P_SO_E_INVOICE_INI(IN_ENTITY_ID IN NUMBER,
                               OS_MESSAGE OUT VARCHAR2) IS  
     S_INVOICE_INI_DAY VARCHAR(100);
     N_INVOICE_INI_DAY NUMBER;
  BEGIN
     OS_MESSAGE :='OK';
     --S_INVOICE_INI_DAY := PKG_BD.F_GET_PARAMETER_VALUE('AR_INVOICE_INI_DAY', IN_ENTITY_ID, NULL, NULL); 
     --N_INVOICE_INI_DAY := TO_NUMBER(S_INVOICE_INI_DAY);
     
     UPDATE CIMS.T_SO_HEADER H 
       SET H.INVOICE_TYPE='5'
          ,H.LAST_UPDATE_DATE = SYSDATE
     WHERE H.ENTITY_ID = IN_ENTITY_ID 
      AND  H.BIZ_SRC_BILL_TYPE_CODE IN('1001','1002','1003','1004')
      --AND H.CUSTOMER_ID IN(SELECT CUSTOM_ID FROM CIMS.T_CUSTOMER_SALES_MAIN_TYPE WHERE ENTITY_ID = IN_ENTITY_ID AND NET_BATCH_FLAG='Y' )
      AND H.SO_DATE>=TO_DATE('2019-03-15','yyyy-mm-dd')  --网批20190315上线
      AND H.INVOICE_NUM_LIST IS NULL
      --AND H.SETTLE_DATE<=SYSDATE-N_INVOICE_INI_DAY
      AND NOT EXISTS (SELECT 1 FROM  CIMS.T_SO_TRX_HEADER_RELATION R WHERE R.SO_HEAD_ID = H.SO_HEADER_ID)
      AND H.INVOICE_TYPE IS NULL
      AND H.CUSTOMER_CHANNEL_TYPE = '15' --网批订单
      AND H.CUSTOMER_CODE <> 'E0115801' --排除电商客户
      AND H.ENTITY_ID NOT IN (10,11,24,25,31) --暂时排除总部主体
      --不存在纸票的开票信息
     -- AND NOT EXISTS (SELECT 1 FROM T_SO_INVOICE_INFO I
     --                 WHERE I.SOURCE_ORDER_NUMBER = H.SYS_SOURCE_ORDER_NUM
     --                    AND I.INVOICE_TYPE = 'INCREMENT_TRX_MATCH')
      --客户开票配置非增值税发票
      AND NOT EXISTS (SELECT 1 FROM T_AR_CONF C
                 WHERE C.ENTITY_ID = H.ENTITY_ID
                   AND C.CUSTOMER_ID = H.CUSTOMER_ID
                   AND C.SALES_CENTER_ID = H.SALES_CENTER_ID
                   AND C.TRX_TYPE = 'INCREMENT_TRX_MATCH')
      ;
       
  END P_SO_E_INVOICE_INI;  
    
       
  --------------------------------------------------------------------------
  --Author: guibr
  --Created: 2019-04-01
  --电子发票创建
  --------------------------------------------------------------------------                              
  Procedure P_SO_E_INVOICE_CREATE(IN_ENTITY_ID IN NUMBER,
                               OS_MESSAGE OUT VARCHAR2) IS
                               
    S_INVOICE_INI_DAY VARCHAR(100);
    N_INVOICE_INI_DAY NUMBER;
    S_INVOICE_CREATE_DAY VARCHAR(100);
    S_CURRENT_DAY VARCHAR(100);
          
   -- N_ACCOUNT_ID   NUMBER;
  --  S_ACCOUNT_CODE VARCHAR2(100);
  --  N_ENTITY_ID NUMBER;
  --  N_ERP_OU_ID NUMBER;
  --  S_CUSTOMER_CODE VARCHAR2(100);
    N_TRX_OI_HEADERS_ID NUMBER;
    S_TRX_HEADER_CODE   VARCHAR2(100);
    S_ERROR_MSG VARCHAR2(10000);
--    S_SO_NUM_STR VARCHAR2(10000);
    N_TRX_MOUNT NUMBER;
   -- N_SINGLE_TRX_MOUNT NUMBER;
  --  N_MAX_TRX_AMOUNT NUMBER;
 --   N_TRX_RATE NUMBER;  
    N_CONF_RATE NUMBER;      
    V_AR_CONF   TYPE_AR_CONF;    
    N_RED_SO_HEADER_ID  NUMBER;     
    N_RETURN_SO_HEADER_ID  NUMBER; 
    N_RETURN_SO_NUM   VARCHAR2(100);
    N_RETURN_RED_HEADER_ID  NUMBER;  
    N_RED_SO_STATUS  VARCHAR2(100); 
    N_RETURN_SO_STATUS  VARCHAR2(100); 
    N_RETURN_RED_SO_STATUS  VARCHAR2(100);  
    
    N_RED_SO_MOUNT  NUMBER; 
    N_RETURN_SO_MOUNT   NUMBER;
    N_RETURN_RED_SO_MOUNT   NUMBER; 
    
    N_ADJUEST_SO_HEADER_ID  NUMBER;  
    N_ADJUEST_SO_STATUS  VARCHAR2(100);  
    N_ADJUEST_SO_MOUNT  NUMBER;      
    N_INVOICE_MAX_MOUNT  NUMBER; 
    
    V_CUSTOMER_REGISTRATION_CODE T_SO_TRX_OI_HEADERS.CUSTOMER_REGISTRATION_CODE%TYPE;
    V_INVOICE_CORPORATION T_SO_TRX_OI_HEADERS.INVOICE_CORPORATION%TYPE;
    V_INVOICE_ADDRESS T_SO_TRX_OI_HEADERS.INVOICE_ADDRESS%TYPE;
    V_INVOICE_TEL T_SO_TRX_OI_HEADERS.INVOICE_TEL%TYPE;
    V_INVOICE_BANK T_SO_TRX_OI_HEADERS.INVOICE_BANK%TYPE;
    V_INVOICE_BANK_ACCOUNT T_SO_TRX_OI_HEADERS.INVOICE_BANK_ACCOUNT%TYPE;
    
    S_REGISTRATION_CODE VARCHAR2(500);  
    S_REGISTRATION_TYPE VARCHAR2(500);  
    
    S_INVOICE_TYPE  VARCHAR2(500); 
    V_VALID_CCS_INVOICE_INFO   VARCHAR2(500); 
  BEGIN
     OS_MESSAGE :='OK';
     N_INVOICE_MAX_MOUNT := PKG_BD.F_GET_PARAMETER_VALUE('AR_INVOICE_MAX_MOUNT', IN_ENTITY_ID, NULL, NULL);
               --是否启用美云销开票信息 add by huanghb12 20190925
     V_VALID_CCS_INVOICE_INFO:= PKG_BD.F_GET_PARAMETER_VALUE('IS_VALID_CCS_INVOICE_INFO',IN_ENTITY_ID, NULL, NULL);
         
     
     /*S_INVOICE_INI_DAY := PKG_BD.F_GET_PARAMETER_VALUE('AR_INVOICE_INI_DAY', IN_ENTITY_ID, NULL, NULL);
     N_INVOICE_INI_DAY := TO_NUMBER(S_INVOICE_INI_DAY); 
     
     S_INVOICE_CREATE_DAY := PKG_BD.F_GET_PARAMETER_VALUE('AR_INVOICE_CREATE_DAY', IN_ENTITY_ID, NULL, NULL); 
     SELECT TO_CHAR(SYSDATE, 'dd' ) INTO S_CURRENT_DAY FROM DUAL;
     IF S_CURRENT_DAY <> S_INVOICE_CREATE_DAY THEN
         RETURN;
     END IF;*/

     
    -- S_ACCOUNT_CODE :='-1';
   --  S_CUSTOMER_CODE :='-1';
   --  N_ENTITY_ID :=0;
    -- N_ERP_OU_ID :=0;
    -- S_SO_NUM_STR :='';
     N_TRX_MOUNT :=0;
   --  N_MAX_TRX_AMOUNT :=0;
   --  N_TRX_RATE :=-1;
   --  N_SINGLE_TRX_MOUNT :=0;
     
     
     FOR 
         TRX_HEADER_ROW 
       IN(   
              SELECT 
                  H.SETTLE_AMOUNT * P.APPLIED_PLUS_MINUS_FLAG SETTLE_AMOUNT
                 ,H.CUSTOMER_ID
                 ,H.CUSTOMER_CODE
                 ,H.ACCOUNT_ID
                 ,H.ACCOUNT_CODE 
                 ,C.CUSTOMER_REGISTRATION_TYPE
                 ,H.SALES_CENTER_ID
                 ,H.SALES_CENTER_NAME
                 ,H.ENTITY_ID
                 ,H.ERP_OU_ID
                 ,h.CUSTOMER_NAME
                 ,h.INVOICE_CORPORATION
                 ,H.SO_HEADER_ID
                 ,P.APPLIED_PLUS_MINUS_FLAG
                 ,H.SO_NUM
                 ,H.ENTITY_CUST_FLAG
                 ,H.CREATED_BY
                 ,H.INVOICE_NUM_LIST
                 ,H.SO_NUM OLD_NUM
                ,(SELECT TAX_RATE FROM T_SO_LINE L WHERE L.SO_HEADER_ID=H.SO_HEADER_ID AND ROWNUM=1 ) TAX_RATE
                ,H.SYS_SOURCE_ORDER_NUM
               FROM CIMS.T_SO_HEADER H 
               INNER JOIN T_SO_TYPE_EXTEND P ON H.ENTITY_ID = P.ENTITY_ID AND H.BILL_TYPE_ID = P.BILL_TYPE_ID
               LEFT JOIN T_CUSTOMER_HEADER C ON H.CUSTOMER_ID = C.CUSTOMER_ID
            WHERE 
                 H.ENTITY_ID = IN_ENTITY_ID
                AND H.SO_STATUS = 12 
                AND H.BIZ_SRC_BILL_TYPE_CODE IN('1001')
                AND H.INVOICE_TYPE = '5' 
                AND H.SO_DATE>=TO_DATE('2019-03-15','yyyy-mm-dd') --网批20190315上线
                AND H.INVOICE_NUM_LIST IS NULL
                --AND H.SETTLE_DATE<=SYSDATE-N_INVOICE_INI_DAY
                AND H.ORIG_SO_NUM  IS NULL
                AND NOT EXISTS (SELECT 1 FROM  CIMS.T_SO_TRX_HEADER_RELATION R WHERE R.SO_HEAD_ID = H.SO_HEADER_ID)
                AND H.CUSTOMER_CHANNEL_TYPE = '15' --网批订单
                AND H.CUSTOMER_CODE <> 'E0115801' --排除电商客户
                --不存在纸票的开票信息
              --  AND NOT EXISTS (SELECT 1 FROM T_SO_INVOICE_INFO I
              --                   WHERE I.SOURCE_ORDER_NUMBER = H.SYS_SOURCE_ORDER_NUM
             --                      AND I.INVOICE_TYPE = 'INCREMENT_TRX_MATCH')
                --客户开票配置非增值税发票
                AND NOT EXISTS (SELECT 1 FROM T_AR_CONF C
                           WHERE C.ENTITY_ID = H.ENTITY_ID
                             AND C.CUSTOMER_ID = H.CUSTOMER_ID
                             AND C.SALES_CENTER_ID = H.SALES_CENTER_ID
                             AND C.TRX_TYPE = 'INCREMENT_TRX_MATCH')
                --AND H.CUSTOMER_ID IN(SELECT CUSTOM_ID FROM CIMS.T_CUSTOMER_SALES_MAIN_TYPE WHERE ENTITY_ID =IN_ENTITY_ID AND ACTIVE_FLAG ='Active' AND  NET_BATCH_FLAG='Y')
              --  AND H.RETURN_ORIG_SO_NUM IS NULL  
           /*   union all    
               SELECT 
                   H.SETTLE_AMOUNT * P.APPLIED_PLUS_MINUS_FLAG SETTLE_AMOUNT
                  ,H.CUSTOMER_ID
                  ,H.CUSTOMER_CODE
                  ,H.ACCOUNT_ID
                  ,H.ACCOUNT_CODE 
                  ,C.CUSTOMER_REGISTRATION_TYPE
                  ,H.SALES_CENTER_ID
                  ,H.SALES_CENTER_NAME
                  ,H.ENTITY_ID
                  ,H.ERP_OU_ID
                  ,h.CUSTOMER_NAME
                  ,h.INVOICE_CORPORATION
                  ,H.SO_HEADER_ID
                  ,P.APPLIED_PLUS_MINUS_FLAG
                  ,H.SO_NUM
                  ,H.ENTITY_CUST_FLAG
                  ,(select CREATED_BY from T_SO_HEADER HR where HR.SO_NUM=H.ORIG_SO_NUM ) CREATED_BY
                  ,H.INVOICE_NUM_LIST
                  ,H.ORIG_SO_NUM OLD_NUM
                  ,(SELECT TAX_RATE FROM T_SO_LINE L WHERE L.SO_HEADER_ID=H.SO_HEADER_ID AND ROWNUM=1 ) TAX_RATE
              FROM CIMS.T_SO_HEADER H 
              INNER JOIN T_SO_TYPE_EXTEND P ON H.ENTITY_ID = P.ENTITY_ID AND H.BILL_TYPE_ID = P.BILL_TYPE_ID
               LEFT JOIN T_CUSTOMER_HEADER C ON H.CUSTOMER_ID = C.CUSTOMER_ID
              WHERE 
                 H.ENTITY_ID = IN_ENTITY_ID
                AND H.SO_STATUS = 12 
                AND H.BIZ_SRC_BILL_TYPE_CODE IN('1002','1004') 
                AND H.INVOICE_TYPE = '5' 
                AND H.SO_DATE>=TO_DATE('2019-03-15','yyyy-mm-dd') --网批20190315上线
                AND H.INVOICE_NUM_LIST IS NULL
                AND H.SETTLE_DATE<=SYSDATE-N_INVOICE_INI_DAY
                AND NOT EXISTS (SELECT 1 FROM  CIMS.T_SO_TRX_HEADER_RELATION R WHERE R.SO_HEAD_ID = H.SO_HEADER_ID)
                AND H.CUSTOMER_ID IN(SELECT CUSTOM_ID FROM CIMS.T_CUSTOMER_SALES_MAIN_TYPE WHERE ENTITY_ID =IN_ENTITY_ID AND NET_BATCH_FLAG='Y')
                AND EXISTS (
                   SELECT 1 FROM CIMS.T_SO_HEADER O WHERE  H.ORIG_SO_NUM = O.SO_NUM AND O.SO_STATUS = 12
                ) 
                union all    
                SELECT 
                   H.SETTLE_AMOUNT * P.APPLIED_PLUS_MINUS_FLAG SETTLE_AMOUNT
                  ,H.CUSTOMER_ID
                  ,H.CUSTOMER_CODE
                  ,H.ACCOUNT_ID
                  ,H.ACCOUNT_CODE 
                  ,C.CUSTOMER_REGISTRATION_TYPE
                  ,H.SALES_CENTER_ID
                  ,H.SALES_CENTER_NAME
                  ,H.ENTITY_ID
                  ,H.ERP_OU_ID
                  ,h.CUSTOMER_NAME
                  ,h.INVOICE_CORPORATION
                  ,H.SO_HEADER_ID
                  ,P.APPLIED_PLUS_MINUS_FLAG
                  ,H.SO_NUM
                  ,H.ENTITY_CUST_FLAG
                  ,(select CREATED_BY from T_SO_HEADER HR where HR.SO_NUM=H.ORIG_SO_NUM ) CREATED_BY
                  ,H.INVOICE_NUM_LIST
                  ,H.RETURN_ORIG_SO_NUM OLD_NUM
                  ,(SELECT TAX_RATE FROM T_SO_LINE L WHERE L.SO_HEADER_ID=H.SO_HEADER_ID AND ROWNUM=1 ) TAX_RATE
              FROM CIMS.T_SO_HEADER H 
              INNER JOIN T_SO_TYPE_EXTEND P ON H.ENTITY_ID = P.ENTITY_ID AND H.BILL_TYPE_ID = P.BILL_TYPE_ID
               LEFT JOIN T_CUSTOMER_HEADER C ON H.CUSTOMER_ID = C.CUSTOMER_ID
              WHERE 
                  H.ENTITY_ID = IN_ENTITY_ID
                AND H.SO_STATUS = 12 
                AND H.BIZ_SRC_BILL_TYPE_CODE IN('1003') 
                AND H.INVOICE_TYPE = '5' 
                AND H.SO_DATE>=TO_DATE('2019-03-15','yyyy-mm-dd') --网批20190315上线
                AND H.INVOICE_NUM_LIST IS NULL
                AND H.SETTLE_DATE<=SYSDATE-N_INVOICE_INI_DAY
                AND NOT EXISTS (SELECT 1 FROM  CIMS.T_SO_TRX_HEADER_RELATION R WHERE R.SO_HEAD_ID = H.SO_HEADER_ID)
                AND H.CUSTOMER_ID IN(SELECT CUSTOM_ID FROM CIMS.T_CUSTOMER_SALES_MAIN_TYPE WHERE ENTITY_ID =IN_ENTITY_ID AND NET_BATCH_FLAG='Y')
                AND H.RETURN_ORIG_SO_NUM IS NOT NULL  
                AND EXISTS (
                   SELECT 1 FROM CIMS.T_SO_HEADER O WHERE  H.RETURN_ORIG_SO_NUM = O.SO_NUM AND O.SO_STATUS = 12
                )
              ORDER BY 
                 ENTITY_ID
                ,ERP_OU_ID
                ,CUSTOMER_ID
                ,CUSTOMER_CODE
                ,ACCOUNT_ID
                ,ACCOUNT_CODE
                ,SALES_CENTER_ID
                ,OLD_NUM
                ,TAX_RATE
                ,SETTLE_AMOUNT
             */   
       )LOOP
           BEGIN  
    
                BEGIN 
                   SELECT 
                       SH.SO_HEADER_ID
                      ,SH.SO_STATUS
                      ,SH.SETTLE_AMOUNT
                   INTO 
                       N_ADJUEST_SO_HEADER_ID
                      ,N_ADJUEST_SO_STATUS 
                      ,N_ADJUEST_SO_MOUNT
                   FROM CIMS.T_SO_HEADER SH
                   WHERE ENTITY_ID = IN_ENTITY_ID 
                   AND SH.BIZ_SRC_BILL_TYPE_CODE = '1001' --调账单
                   AND SH.INVOICE_NUM_LIST IS NULL
                   AND SH.ORIG_SO_NUM = TRX_HEADER_ROW.SO_NUM;
                EXCEPTION
                   WHEN NO_DATA_FOUND THEN
                      N_ADJUEST_SO_HEADER_ID :=0;
                      N_ADJUEST_SO_STATUS:='12';
                      N_ADJUEST_SO_MOUNT:=0;
                END;
           
               BEGIN 
                   SELECT 
                       SH.SO_HEADER_ID
                      ,SH.SO_STATUS
                      ,-1*SH.SETTLE_AMOUNT
                   INTO 
                       N_RED_SO_HEADER_ID
                      ,N_RED_SO_STATUS 
                      ,N_RED_SO_MOUNT
                   FROM CIMS.T_SO_HEADER SH
                   WHERE ENTITY_ID = IN_ENTITY_ID 
                   AND SH.INVOICE_NUM_LIST IS NULL
                   AND SH.BIZ_SRC_BILL_TYPE_CODE = '1002' --红冲
                   AND SH.ORIG_SO_NUM = TRX_HEADER_ROW.SO_NUM;
                EXCEPTION
                   WHEN NO_DATA_FOUND THEN
                      N_RED_SO_HEADER_ID :=0;
                      N_RED_SO_STATUS:='12';
                      N_RED_SO_MOUNT:=0;
               END;
                
               BEGIN 
                   SELECT 
                       SH.SO_HEADER_ID
                      ,SH.SO_STATUS
                      ,SH.SO_NUM
                      ,-1*SH.SETTLE_AMOUNT
                   INTO 
                       N_RETURN_SO_HEADER_ID
                      ,N_RETURN_SO_STATUS
                      ,N_RETURN_SO_NUM
                      ,N_RETURN_SO_MOUNT
                   FROM CIMS.T_SO_HEADER SH
                   WHERE ENTITY_ID = IN_ENTITY_ID 
                   AND SH.INVOICE_NUM_LIST IS NULL
                   AND SH.BIZ_SRC_BILL_TYPE_CODE = '1003' --退货
                   AND SH.RETURN_ORIG_SO_NUM = TRX_HEADER_ROW.SO_NUM;
                EXCEPTION
                   WHEN NO_DATA_FOUND THEN
                      N_RETURN_SO_HEADER_ID :=0;
                      N_RETURN_SO_STATUS:='12';
                      N_RETURN_SO_NUM:='0';
                      N_RETURN_SO_MOUNT:=0;
               END;
                
              IF N_RETURN_SO_NUM <>'0' THEN
                  BEGIN 
                     SELECT 
                         SH.SO_HEADER_ID
                        ,SH.SO_STATUS
                        ,SH.SETTLE_AMOUNT
                     INTO 
                         N_RETURN_RED_HEADER_ID
                        ,N_RETURN_RED_SO_STATUS
                        ,N_RETURN_RED_SO_MOUNT
                     FROM CIMS.T_SO_HEADER SH
                     WHERE ENTITY_ID = IN_ENTITY_ID 
                     AND SH.INVOICE_NUM_LIST IS NULL
                     AND SH.BIZ_SRC_BILL_TYPE_CODE = '1004' --退货红冲
                     AND SH.ORIG_SO_NUM = N_RETURN_SO_NUM;
                   EXCEPTION
                     WHEN NO_DATA_FOUND THEN
                        N_RETURN_RED_HEADER_ID :=0;
                        N_RETURN_RED_SO_STATUS:='12';
                        N_RETURN_RED_SO_MOUNT:=0;
                   END;
              ELSE  
                       N_RETURN_RED_HEADER_ID :=0;
                       N_RETURN_RED_SO_STATUS:='12';
                       N_RETURN_RED_SO_MOUNT:=0;
              END IF;
                
              IF N_RED_SO_STATUS <>'12' OR N_RETURN_SO_STATUS<>'12' OR N_RETURN_RED_SO_STATUS<>'12' OR N_ADJUEST_SO_STATUS<>'12' THEN
                   CONTINUE;
              END IF;
              
              N_TRX_MOUNT :=0;
           
              N_TRX_MOUNT :=N_TRX_MOUNT+TRX_HEADER_ROW.SETTLE_AMOUNT; 
              N_TRX_MOUNT :=N_TRX_MOUNT+N_RED_SO_MOUNT;
              N_TRX_MOUNT :=N_TRX_MOUNT+N_RETURN_SO_MOUNT;
              N_TRX_MOUNT :=N_TRX_MOUNT+N_RETURN_RED_SO_MOUNT;
              N_TRX_MOUNT :=N_TRX_MOUNT+N_ADJUEST_SO_MOUNT; 
              
              
        
          IF V_VALID_CCS_INVOICE_INFO = 'Y' THEN
            --校验销售单来源CCS订单开票信息一致性
              --获取开票信息
              BEGIN
                SELECT I.INVOICE_CUSTOMER, I.IDENTIFICATION_NUMBER,I.INVOICE_TYPE
                  INTO V_INVOICE_CORPORATION, V_CUSTOMER_REGISTRATION_CODE,S_INVOICE_TYPE
                  FROM T_SO_INVOICE_INFO I
                 WHERE I.ENTITY_ID = TRX_HEADER_ROW.ENTITY_ID
                   AND I.INVOICE_OPT_TYPE = 'ADD'
                 --  AND I.INVOICE_TYPE = 'ELECTRONIC_TRX_MATCH'
                   AND I.SOURCE_ORDER_NUMBER = TRX_HEADER_ROW.SYS_SOURCE_ORDER_NUM
                   AND ROWNUM = 1;
                 
                 IF upper(V_INVOICE_CORPORATION) ='NULL'  THEN
                        V_INVOICE_CORPORATION := TRX_HEADER_ROW.INVOICE_CORPORATION;
                        V_CUSTOMER_REGISTRATION_CODE := NULL;
                 END IF;  
                 
                 IF upper(V_CUSTOMER_REGISTRATION_CODE) ='NULL'  THEN
                        V_INVOICE_CORPORATION := TRX_HEADER_ROW.INVOICE_CORPORATION;
                        V_CUSTOMER_REGISTRATION_CODE := NULL;
                 END IF;  
                   
              EXCEPTION
                WHEN OTHERS THEN
                  V_INVOICE_CORPORATION := TRX_HEADER_ROW.INVOICE_CORPORATION;
                  V_CUSTOMER_REGISTRATION_CODE := NULL;
                  S_INVOICE_TYPE := 'ELECTRONIC_TRX_MATCH';
              END;
          ELSE    
               V_INVOICE_CORPORATION := TRX_HEADER_ROW.INVOICE_CORPORATION;
               V_CUSTOMER_REGISTRATION_CODE := NULL;
               S_INVOICE_TYPE := 'ELECTRONIC_TRX_MATCH';
          END IF;   
              
             P_GET_AR_CONFIG(TRX_HEADER_ROW.ENTITY_ID
                               ,TRX_HEADER_ROW.SALES_CENTER_ID
                               ,TRX_HEADER_ROW.CUSTOMER_ID
                               ,TRX_HEADER_ROW.ERP_OU_ID
                               ,V_AR_CONF
              );
                        
             N_CONF_RATE  :=  V_AR_CONF.TRX_RATE;
           --  N_MAX_TRX_AMOUNT := V_AR_CONF.MAX_TRX_AMOUNT;
            
              
              N_TRX_OI_HEADERS_ID := S_SO_TRX_OI_HEADERS.Nextval;
              INSERT 
                      INTO 
                        T_SO_TRX_OI_HEADERS(
                          TOH_ID
                         ,TRX_TYPE
                         ,STATE
                         ,COMMENTS
                         ,OI_FLAG
                         ,OI_ID
                         ,TRX_CUSTOMER_ID
                         ,SALES_CENTER_ID
                         ,ENTITY_ID
                         ,CREATED_BY
                         ,CREATION_DATE
                         ,LAST_UPDATED_BY
                         ,LAST_UPDATE_DATE
                         ,TRANS_TYPE
                         ,TRANS_PARAM
                         ,ACCOUNT_ID
                         ,ERP_OU_ID
                         ,ATTRIBUTE1
                         ,ATTRIBUTE2
                         ,ATTRIBUTE3
                         ,ATTRIBUTE4
                         ,ATTRIBUTE5
                         ,ATTRIBUTE6
                         ,INVOICE_CORPORATION
                         ,CUSTOMER_REGISTRATION_CODE
                        )values(
                           N_TRX_OI_HEADERS_ID
                          ,S_INVOICE_TYPE  --电子发票
                          ,'TS_IN_QUEUE'  
                          ,null
                          ,null
                          ,null
                          ,TRX_HEADER_ROW.CUSTOMER_ID
                          ,TRX_HEADER_ROW.SALES_CENTER_ID
                          ,TRX_HEADER_ROW.ENTITY_ID
                          ,'admin'
                          ,sysdate
                          ,'admin'
                          ,sysdate
                          ,'NORMAL'
                          ,null
                          ,TRX_HEADER_ROW.ACCOUNT_ID
                          ,TRX_HEADER_ROW.ERP_OU_ID
                          ,TRX_HEADER_ROW.CUSTOMER_CODE
                          ,TRX_HEADER_ROW.CUSTOMER_NAME
                          ,TRX_HEADER_ROW.CUSTOMER_REGISTRATION_TYPE
                          ,null
                          ,null
                          ,null
                          ,V_INVOICE_CORPORATION--TRX_HEADER_ROW.INVOICE_CORPORATION
                          ,V_CUSTOMER_REGISTRATION_CODE
                     );
                        
                  INSERT
                     INTO 
                     T_SO_TRX_OI_LINES
                      (TOL_ID
                      ,TOH_ID
                      ,ENTITY_ID
                      ,LINE_ID
                      ,ITEM_ID
                      ,PRICE
                      ,QUANTITY
                      ,DISCOUNT
                      ,TRX_RATE
                      ,CREATED_BY
                      ,CREATION_DATE
                      ,LAST_UPDATED_BY
                      ,LAST_UPDATE_DATE)
                   SELECT 
                      S_SO_TRX_OI_LINES.NEXTVAL
                     ,N_TRX_OI_HEADERS_ID
                     ,TRX_HEADER_ROW.ENTITY_ID
                     ,L.SO_LINE_ID
                     ,L.ITEM_ID
                     ,l.ITEM_PRICE
                     ,L.ITEM_QTY * P.APPLIED_PLUS_MINUS_FLAG
                     ,NVL(L.DISCOUNT_RATE,0) + NVL(L.MONTH_DISCOUNT_RATE,0)
                     ,NVL(L.TAX_RATE,N_CONF_RATE)
                     ,'admin'
                     ,SYSDATE
                     ,'admin'
                     ,SYSDATE
                  FROM CIMS.T_SO_LINE L
                  INNER JOIN CIMS.T_SO_HEADER H ON H.SO_HEADER_ID = L.SO_HEADER_ID
                  INNER JOIN T_SO_TYPE_EXTEND P ON H.ENTITY_ID = P.ENTITY_ID AND H.BILL_TYPE_ID = P.BILL_TYPE_ID
                  WHERE H.SO_HEADER_ID IN(TRX_HEADER_ROW.SO_HEADER_ID,N_RED_SO_HEADER_ID,N_RETURN_SO_HEADER_ID,N_RETURN_RED_HEADER_ID,N_ADJUEST_SO_HEADER_ID); 
             
                  UPDATE T_SO_TRX_OI_HEADERS SET COMMENTS = substr(ATTRIBUTE1 || ',' || TRX_HEADER_ROW.SO_NUM,1,1000)||' 网批电票', ATTRIBUTE4=N_TRX_MOUNT||'' where TOH_ID=N_TRX_OI_HEADERS_ID;
                  p_Create_So_Trx(N_TRX_OI_HEADERS_ID,'INVOICE_CREATE',S_TRX_HEADER_CODE,S_ERROR_MSG);
                  IF S_ERROR_MSG <>'OK' THEN
                      RAISE_APPLICATION_ERROR(-20001,S_ERROR_MSG); 
                  END IF;
                               
                  IF N_TRX_MOUNT > N_INVOICE_MAX_MOUNT THEN
                      update cims.t_so_trx_headers th set th.intf_error_msg='开票金额超电商开票额度',th.state='TS_NOT_PRINTED' where th.trx_header_code =S_TRX_HEADER_CODE;
                  END IF;
                         
                  BEGIN 
                     select 
                       ch.CUSTOMER_REGISTRATION_CODE,ch.CUSTOMER_REGISTRATION_TYPE 
                     INTO 
                       S_REGISTRATION_CODE,S_REGISTRATION_TYPE
                     from cims.t_customer_header ch where ch.customer_code = TRX_HEADER_ROW.CUSTOMER_CODE AND rownum=1;
                  EXCEPTION
                       WHEN NO_DATA_FOUND THEN
                         S_REGISTRATION_CODE := NULL;
                         S_REGISTRATION_TYPE:=NULL;
                  END;   
                           
                  IF  S_REGISTRATION_TYPE = 'GeneralTaxpayer' 
                    AND S_REGISTRATION_CODE IS NULL 
                    AND V_CUSTOMER_REGISTRATION_CODE IS NULL  THEN 
                         update cims.t_so_trx_headers th set th.intf_error_msg='一般纳税人 没有纳税登记号,需要在CRM维护',th.state='TS_NOT_PRINTED' where th.trx_header_code =S_TRX_HEADER_CODE;
                  END IF;     
                 COMMIT;    
              
           
           /*
              IF ((TRX_HEADER_ROW.CUSTOMER_CODE <> S_CUSTOMER_CODE
                 OR TRX_HEADER_ROW.ACCOUNT_CODE <> S_ACCOUNT_CODE 
                 OR TRX_HEADER_ROW.ENTITY_ID <> N_ENTITY_ID
                 OR TRX_HEADER_ROW.ERP_OU_ID  <> N_ERP_OU_ID 
                 OR NVL(TRX_HEADER_ROW.TAX_RATE,'-1')  <> N_TRX_RATE
                 OR N_TRX_MOUNT >= N_MAX_TRX_AMOUNT
                ) OR 1=1) --网批订单一单一票
               THEN                   
                   P_GET_AR_CONFIG(TRX_HEADER_ROW.ENTITY_ID
                               ,TRX_HEADER_ROW.SALES_CENTER_ID
                               ,TRX_HEADER_ROW.CUSTOMER_ID
                               ,TRX_HEADER_ROW.ERP_OU_ID
                               ,V_AR_CONF
                   );
                        
                   N_CONF_RATE  :=  V_AR_CONF.TRX_RATE;
                   N_MAX_TRX_AMOUNT := V_AR_CONF.MAX_TRX_AMOUNT;
               
                   IF N_ENTITY_ID <>0 AND N_SINGLE_TRX_MOUNT> 0  THEN
                         UPDATE T_SO_TRX_OI_HEADERS SET COMMENTS = substr(ATTRIBUTE1 || ',' || S_SO_NUM_STR,1,1200), ATTRIBUTE4=N_SINGLE_TRX_MOUNT||'' where TOH_ID=N_TRX_OI_HEADERS_ID;
                         p_Create_So_Trx(N_TRX_OI_HEADERS_ID,'INVOICE_CREATE',S_TRX_HEADER_CODE,S_ERROR_MSG);
                         IF S_ERROR_MSG <>'OK' THEN
                              RAISE_APPLICATION_ERROR(-20001,S_ERROR_MSG); 
                         END IF;
                         
                         
                         IF N_SINGLE_TRX_MOUNT > N_INVOICE_MAX_MOUNT THEN
                             update cims.t_so_trx_headers th set th.intf_error_msg='开票金额超电商开票额度',th.state='TS_NOT_PRINTED' where th.trx_header_code =S_TRX_HEADER_CODE;
                         END IF;
                         
                         BEGIN 
                            select 
                               ch.CUSTOMER_REGISTRATION_CODE,ch.CUSTOMER_REGISTRATION_TYPE 
                            INTO 
                               S_REGISTRATION_CODE,S_REGISTRATION_TYPE
                             from cims.t_customer_header ch where ch.customer_code = S_CUSTOMER_CODE AND rownum=1;
                         EXCEPTION
                              WHEN NO_DATA_FOUND THEN
                                 S_REGISTRATION_CODE := NULL;
                                 S_REGISTRATION_TYPE:=NULL;
                         END;   
                           
                         IF  S_REGISTRATION_TYPE = 'GeneralTaxpayer' AND S_REGISTRATION_CODE IS NULL THEN 
                                update cims.t_so_trx_headers th set th.intf_error_msg='一般纳税人 没有纳税登记号,需要在CRM维护',th.state='TS_NOT_PRINTED' where th.trx_header_code =S_TRX_HEADER_CODE;
                         END IF;
                         
                         COMMIT;    
                   END IF;
                
                  -- SAVEPOINT SP;
                   
                   S_CUSTOMER_CODE := TRX_HEADER_ROW.CUSTOMER_CODE;
                   S_ACCOUNT_CODE := TRX_HEADER_ROW.ACCOUNT_CODE;
                   N_ENTITY_ID   :=TRX_HEADER_ROW.ENTITY_ID;
                   N_ERP_OU_ID := TRX_HEADER_ROW.ERP_OU_ID;
                   N_TRX_RATE := NVL(TRX_HEADER_ROW.TAX_RATE,N_CONF_RATE);
                   N_TRX_OI_HEADERS_ID := S_SO_TRX_OI_HEADERS.Nextval;
                   S_SO_NUM_STR :='';
                   IF N_ENTITY_ID <>0 THEN
                     N_TRX_MOUNT := TRX_HEADER_ROW.SETTLE_AMOUNT;
                   END IF;  
                   
                   N_SINGLE_TRX_MOUNT :=0;
                     
                   INSERT 
                      INTO 
                        T_SO_TRX_OI_HEADERS(
                          TOH_ID
                         ,TRX_TYPE
                         ,STATE
                         ,COMMENTS
                         ,OI_FLAG
                         ,OI_ID
                         ,TRX_CUSTOMER_ID
                         ,SALES_CENTER_ID
                         ,ENTITY_ID
                         ,CREATED_BY
                         ,CREATION_DATE
                         ,LAST_UPDATED_BY
                         ,LAST_UPDATE_DATE
                         ,TRANS_TYPE
                         ,TRANS_PARAM
                         ,ACCOUNT_ID
                         ,ERP_OU_ID
                         ,ATTRIBUTE1
                         ,ATTRIBUTE2
                         ,ATTRIBUTE3
                         ,ATTRIBUTE4
                         ,ATTRIBUTE5
                         ,ATTRIBUTE6
                         ,INVOICE_CORPORATION
                         ,CUSTOMER_REGISTRATION_CODE
                        )values(
                           N_TRX_OI_HEADERS_ID
                          ,'ELECTRONIC_TRX_MATCH'  --电子发票
                          ,'TS_IN_QUEUE'  
                          ,null
                          ,null
                          ,null
                          ,TRX_HEADER_ROW.CUSTOMER_ID
                          ,TRX_HEADER_ROW.SALES_CENTER_ID
                          ,TRX_HEADER_ROW.ENTITY_ID
                          ,'admin'
                          ,sysdate
                          ,'admin'
                          ,sysdate
                          ,'NORMAL'
                          ,null
                          ,TRX_HEADER_ROW.ACCOUNT_ID
                          ,TRX_HEADER_ROW.ERP_OU_ID
                          ,TRX_HEADER_ROW.CUSTOMER_CODE
                          ,TRX_HEADER_ROW.CUSTOMER_NAME
                          ,TRX_HEADER_ROW.CUSTOMER_REGISTRATION_TYPE
                          ,null
                          ,null
                          ,null
                          ,V_INVOICE_CORPORATION--TRX_HEADER_ROW.INVOICE_CORPORATION
                          ,V_CUSTOMER_REGISTRATION_CODE
                        );
                 END IF; 

                 S_SO_NUM_STR  := S_SO_NUM_STR||','||TRX_HEADER_ROW.SO_NUM;
                 
                 N_SINGLE_TRX_MOUNT :=N_SINGLE_TRX_MOUNT+TRX_HEADER_ROW.SETTLE_AMOUNT;
                 N_SINGLE_TRX_MOUNT :=N_SINGLE_TRX_MOUNT+N_RED_SO_MOUNT;
                 N_SINGLE_TRX_MOUNT :=N_SINGLE_TRX_MOUNT+N_RETURN_SO_MOUNT;
                 N_SINGLE_TRX_MOUNT :=N_SINGLE_TRX_MOUNT+N_RETURN_RED_SO_MOUNT;
                 N_SINGLE_TRX_MOUNT :=N_SINGLE_TRX_MOUNT+N_ADJUEST_SO_MOUNT;
                 
                 
                 INSERT
                     INTO 
                     T_SO_TRX_OI_LINES
                      (TOL_ID
                      ,TOH_ID
                      ,ENTITY_ID
                      ,LINE_ID
                      ,ITEM_ID
                      ,PRICE
                      ,QUANTITY
                      ,DISCOUNT
                      ,TRX_RATE
                      ,CREATED_BY
                      ,CREATION_DATE
                      ,LAST_UPDATED_BY
                      ,LAST_UPDATE_DATE)
                   SELECT 
                      S_SO_TRX_OI_LINES.NEXTVAL
                     ,N_TRX_OI_HEADERS_ID
                     ,TRX_HEADER_ROW.ENTITY_ID
                     ,L.SO_LINE_ID
                     ,L.ITEM_ID
                     ,L.ITEM_SETTLE_PRICE
                     ,L.ITEM_QTY * P.APPLIED_PLUS_MINUS_FLAG
                     ,NVL(L.DISCOUNT_RATE,0) + NVL(L.MONTH_DISCOUNT_RATE,0)
                     ,N_TRX_RATE
                     ,'admin'
                     ,SYSDATE
                     ,'admin'
                     ,SYSDATE
                  FROM CIMS.T_SO_LINE L
                  INNER JOIN CIMS.T_SO_HEADER H ON H.SO_HEADER_ID = L.SO_HEADER_ID
                  INNER JOIN T_SO_TYPE_EXTEND P ON H.ENTITY_ID = P.ENTITY_ID AND H.BILL_TYPE_ID = P.BILL_TYPE_ID
                  WHERE H.SO_HEADER_ID IN(TRX_HEADER_ROW.SO_HEADER_ID,N_RED_SO_HEADER_ID,N_RETURN_SO_HEADER_ID,N_RETURN_RED_HEADER_ID,N_ADJUEST_SO_HEADER_ID); 
                */
          EXCEPTION
                WHEN OTHERS THEN
                     ROLLBACK;
                     --设置ESB异步回调处理错误         
                     OS_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_INVOICE.P_SO_E_INVOICE_CREATE', SQLCODE,
                      '电子发票开票失败！。异常消息：' ||TRX_HEADER_ROW.SO_NUM ||' '|| substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
                
           END;
         END LOOP;  
       
       /*   
         IF  S_SO_NUM_STR IS NOT NULL 
           AND LENGTH(S_SO_NUM_STR)>0
              THEN
              IF N_ENTITY_ID <>0 AND  N_SINGLE_TRX_MOUNT> 0  THEN
                 UPDATE T_SO_TRX_OI_HEADERS SET COMMENTS = substr(ATTRIBUTE1 || ',' || S_SO_NUM_STR,1,1200), ATTRIBUTE4=N_SINGLE_TRX_MOUNT||'' where TOH_ID=N_TRX_OI_HEADERS_ID;
                 p_Create_So_Trx(N_TRX_OI_HEADERS_ID,'INVOICE_CREATE',S_TRX_HEADER_CODE,S_ERROR_MSG);
                 IF S_ERROR_MSG <>'OK' THEN
                      RAISE_APPLICATION_ERROR(-20001,S_ERROR_MSG); 
                 END IF;
                 
                 IF N_SINGLE_TRX_MOUNT > N_INVOICE_MAX_MOUNT THEN
                     update cims.t_so_trx_headers th set th.intf_error_msg='开票金额超电商开票额度',th.state='TS_NOT_PRINTED' where th.trx_header_code =S_TRX_HEADER_CODE;
                 END IF;
                 
                  BEGIN 
                    select 
                       ch.CUSTOMER_REGISTRATION_CODE,ch.CUSTOMER_REGISTRATION_TYPE 
                    INTO 
                       S_REGISTRATION_CODE,S_REGISTRATION_TYPE
                     from cims.t_customer_header ch where ch.customer_code = S_CUSTOMER_CODE AND rownum=1;
                  EXCEPTION
                      WHEN NO_DATA_FOUND THEN
                         S_REGISTRATION_CODE := NULL;
                         S_REGISTRATION_TYPE:=NULL;
                   END;   
                   
                   IF  S_REGISTRATION_TYPE = 'GeneralTaxpayer' AND S_REGISTRATION_CODE IS NULL THEN 
                        update cims.t_so_trx_headers th set th.intf_error_msg='一般纳税人 没有纳税登记号,需要在CRM维护',th.state='TS_NOT_PRINTED' where th.trx_header_code =S_TRX_HEADER_CODE;
                   END IF;
                 
                 COMMIT;     
              END IF;
         END IF; */
     EXCEPTION    
         WHEN OTHERS THEN
           ROLLBACK;
           --设置ESB异步回调处理错误         
           OS_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_INVOICE.P_SO_E_INVOICE_CREATE', SQLCODE,
            '电子发票开票失败！。异常消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
          
  END P_SO_E_INVOICE_CREATE;          
                        
  
  
End PKG_AR_INVOICE;
/

