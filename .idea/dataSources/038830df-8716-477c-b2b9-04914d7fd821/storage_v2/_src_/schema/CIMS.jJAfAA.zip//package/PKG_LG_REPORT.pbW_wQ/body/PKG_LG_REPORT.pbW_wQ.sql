create PACKAGE BODY      PKG_LG_REPORT AS

  ----------------------------------------------------------------------
  -- AUTHOR  : XUQF
  -- CREATED : 2015-02-05
  -- PURPOSE : 基地发运汇总
  ----------------------------------------------------------------------
  PROCEDURE P_LG_AREA_SHIP_COLLECT(O_RESULT     OUT VARCHAR2, --返回错误码
                                   O_RESULT_MSG OUT VARCHAR2 --返回错误信息
                                   ) IS

    V_LG_AREA_SHIP_COLLECT T_LG_AREA_SHIP_COLLECT%ROWTYPE; --基地发运汇总表
    V_RECORD               NUMBER; --记录数
    V_DATE                 DATE; --执行日期
    --V_DAY                  VARCHAR2(10); --日
    V_BEGIN_TIME           DATE; --统计开始时间
    V_BEGIN_M              DATE; --统计开始时间
    V_END_TIME             DATE; --统计结束时间
  BEGIN

    O_RESULT     := '1';
    O_RESULT_MSG := '生成成功';

    --检查汇总记录是否存在
    SELECT COUNT(T.AREA_SHIP_COLLECT_ID)
      INTO V_RECORD
      FROM T_LG_AREA_SHIP_COLLECT T
     WHERE TRUNC(T.RECORD_DATE) = TRUNC(SYSDATE - 1);

    IF V_RECORD > 0 THEN

      V_DATE       := TRUNC(SYSDATE - 1);
      O_RESULT     := '1001';
      O_RESULT_MSG := '日期' || V_DATE || '的数据已执行！';
      RETURN;

    END IF;

    --遍历产地表 目前只给家用使用（不包含中心仓）

  --遍历多主体
    FOR C_ENTITY_ID IN (SELECT T.CODE_VALUE
                          FROM UP_CODELIST T
                         WHERE T.CODETYPE = 'LG_ENTITYCODE') LOOP

      FOR C_PLN_PRODUCING_AREA IN (SELECT T.PRODUCING_AREA_ID,
                                          T.PRODUCING_AREA_NAME,
                                          T.ENTITY_ID
                                     FROM T_PLN_PRODUCING_AREA T
                                    WHERE T.ENTITY_ID =
                                          C_ENTITY_ID.CODE_VALUE) LOOP

        --遍历产品大类
        FOR C_BD_ITEM_CLASS IN (SELECT T.CLASS_CODE
                                  FROM T_BD_ITEM_CLASS T
                                 WHERE T.CLASS_TYPE = 'M'
                                   AND T.ACTIVE_FLAG = 'Y'
                                   AND T.ENTITY_ID =
                                       C_PLN_PRODUCING_AREA.ENTITY_ID) LOOP

          V_BEGIN_TIME := To_date(To_char(Trunc(SYSDATE),
                                          'yyyy/mm/dd hh24:mi:ss'),
                                  'yyyy/mm/dd hh24:mi:ss') +
                          pkg_bd.F_GET_PARAMETER_VALUE('lgReportTimeCode',
                                                       C_PLN_PRODUCING_AREA.ENTITY_ID,
                                                       null,
                                                       null) / 24 - 1;
          V_END_TIME   := To_date(To_char(Trunc(SYSDATE),
                                          'yyyy/mm/dd hh24:mi:ss'),
                                  'yyyy/mm/dd hh24:mi:ss') +
                          pkg_bd.F_GET_PARAMETER_VALUE('lgReportTimeCode',
                                                       C_PLN_PRODUCING_AREA.ENTITY_ID,
                                                       null,
                                                       null) / 24;
          V_BEGIN_M := To_date(to_char(sysdate-1,'yyyyMM')||'01 00:00:00','yyyyMMdd hh24:mi:ss') ;

          --当日开单数
          SELECT SUM(NVL(T3.ITEM_QTY - T3.CANCEL_QTY, 0) *
                     decode(T1.entity_id,
                             10,
                             DECODE(T3.ITEM_UOM, 'Set', 1, 'Tai', 0.5, 'Ea', 0, 0),
                             11,
                             DECODE(T3.ITEM_UOM, 'Set', 1, 'Tai', 0.5, 'Ea', 0, 0),
                             24,
                             DECODE(T3.ITEM_UOM, 'Set', 1, 'Tai', 0.5, 'Ea', 0, 0),
                             1)) --套1 台0.5 件0
            INTO V_LG_AREA_SHIP_COLLECT.DAILY_ORDER_NUM
            FROM T_LG_SHIP_DOC      T1,
                 T_INV_INVENTORIES  T2,
                 T_LG_SHIP_DOC_LINE T3
           WHERE T1.SHIP_DOC_ID = T3.SHIP_DOC_ID
             AND T1.SHIP_INVENTORY_ID = T2.INVENTORY_ID(+)
             AND T1.DOC_STATUS = '00'
             AND T1.ENTITY_ID = C_PLN_PRODUCING_AREA.ENTITY_ID
             AND T3.SALES_MAIN_TYPE = C_BD_ITEM_CLASS.CLASS_CODE
             AND T2.PRODUCING_AREA_ID =
                 C_PLN_PRODUCING_AREA.PRODUCING_AREA_ID
             AND TRUNC(T1.CREATION_DATE) = TRUNC(SYSDATE - 1);
             
          --当月开单数
          SELECT SUM(NVL(T3.ITEM_QTY - T3.CANCEL_QTY, 0) *
                     decode(T1.entity_id,
                             10,
                             DECODE(T3.ITEM_UOM, 'Set', 1, 'Tai', 0.5, 'Ea', 0, 0),
                             11,
                             DECODE(T3.ITEM_UOM, 'Set', 1, 'Tai', 0.5, 'Ea', 0, 0),
                             24,
                             DECODE(T3.ITEM_UOM, 'Set', 1, 'Tai', 0.5, 'Ea', 0, 0),
                             1)) --套1 台0.5 件0
            INTO V_LG_AREA_SHIP_COLLECT.MONTH_TOTAL_ORDER_NUM
            FROM T_LG_SHIP_DOC      T1,
                 T_INV_INVENTORIES  T2,
                 T_LG_SHIP_DOC_LINE T3
           WHERE T1.SHIP_DOC_ID = T3.SHIP_DOC_ID
             AND T1.SHIP_INVENTORY_ID = T2.INVENTORY_ID(+)
             AND T1.DOC_STATUS = '00'
             AND T1.ENTITY_ID = C_PLN_PRODUCING_AREA.ENTITY_ID
             AND T3.SALES_MAIN_TYPE = C_BD_ITEM_CLASS.CLASS_CODE
             AND T2.PRODUCING_AREA_ID =
                 C_PLN_PRODUCING_AREA.PRODUCING_AREA_ID
             AND T1.CREATION_DATE BETWEEN V_BEGIN_M AND V_END_TIME;

          --未开单
          SELECT SUM(NVL(T1.ITEM_QTY, 0) *
                     decode(T1.entity_id,
                             10,
                             DECODE(T1.ITEM_UOM, 'Set', 1, 'Tai', 0.5, 'Ea', 0, 0),
                             11,
                             DECODE(T1.ITEM_UOM, 'Set', 1, 'Tai', 0.5, 'Ea', 0, 0),
                             24,
                             DECODE(T1.ITEM_UOM, 'Set', 1, 'Tai', 0.5, 'Ea', 0, 0),
                             1))
            INTO V_LG_AREA_SHIP_COLLECT.WITHOUT_ORDER_NUM
            FROM T_LG_SHIP_PLAN T1, T_INV_INVENTORIES T2
           WHERE T1.STATUS = '00'
             AND T1.ENTITY_ID = C_PLN_PRODUCING_AREA.ENTITY_ID
             AND T1.SHIP_INVENTORY_ID = T2.INVENTORY_ID
             AND T1.SALES_MAIN_TYPE = C_BD_ITEM_CLASS.CLASS_CODE
             AND T2.PRODUCING_AREA_ID =
                 C_PLN_PRODUCING_AREA.PRODUCING_AREA_ID;

          --当日发运
          SELECT SUM(NVL(T2.FACT_SHIP_QTY, 0) *
                     decode(T1.entity_id,
                             10,
                             DECODE(T2.ITEM_UOM, 'Set', 1, 'Tai', 0.5, 'Ea', 0, 0),
                             11,
                             DECODE(T2.ITEM_UOM, 'Set', 1, 'Tai', 0.5, 'Ea', 0, 0),
                             24,
                             DECODE(T2.ITEM_UOM, 'Set', 1, 'Tai', 0.5, 'Ea', 0, 0),
                             1))
            INTO V_LG_AREA_SHIP_COLLECT.DAILY_SHIP_NUM
            FROM T_LG_CONTRACT      T1,
                 T_LG_CONTRACT_LINE T2,
                 T_INV_INVENTORIES  T3
           WHERE T2.CONTRACT_ID = T1.CONTRACT_ID
             AND T1.ENTITY_ID = C_PLN_PRODUCING_AREA.ENTITY_ID
             AND T3.INVENTORY_ID = T1.SHIP_INVENTORY_ID
             AND T2.SALES_MAIN_TYPE = C_BD_ITEM_CLASS.CLASS_CODE
             AND T3.PRODUCING_AREA_ID =
                 C_PLN_PRODUCING_AREA.PRODUCING_AREA_ID
             AND T1.FACT_SHIP_DATE BETWEEN V_BEGIN_TIME AND V_END_TIME;
          --    AND TRUNC(T1.CREATION_DATE) = TRUNC(SYSDATE - 1);
          
         --当月发运
          SELECT SUM(NVL(T2.FACT_SHIP_QTY, 0) *
                     decode(T1.entity_id,
                             10,
                             DECODE(T2.ITEM_UOM, 'Set', 1, 'Tai', 0.5, 'Ea', 0, 0),
                             11,
                             DECODE(T2.ITEM_UOM, 'Set', 1, 'Tai', 0.5, 'Ea', 0, 0),
                             24,
                             DECODE(T2.ITEM_UOM, 'Set', 1, 'Tai', 0.5, 'Ea', 0, 0),
                             1))
            INTO V_LG_AREA_SHIP_COLLECT.MONTH_TOTAL_SHIP_NUM
            FROM T_LG_CONTRACT      T1,
                 T_LG_CONTRACT_LINE T2,
                 T_INV_INVENTORIES  T3
           WHERE T2.CONTRACT_ID = T1.CONTRACT_ID
             AND T1.ENTITY_ID = C_PLN_PRODUCING_AREA.ENTITY_ID
             AND T3.INVENTORY_ID = T1.SHIP_INVENTORY_ID
             AND T2.SALES_MAIN_TYPE = C_BD_ITEM_CLASS.CLASS_CODE
             AND T3.PRODUCING_AREA_ID =
                 C_PLN_PRODUCING_AREA.PRODUCING_AREA_ID
             AND T1.FACT_SHIP_DATE BETWEEN V_BEGIN_M AND V_END_TIME;

          --开单未提
          SELECT SUM((NVL(T2.ITEM_QTY, 0) - NVL(T2.FACT_SHIP_QTY, 0) -
                     NVL(T2.CANCEL_QTY, 0)) *
                     decode(T1.entity_id,
                             10,
                             DECODE(T2.ITEM_UOM, 'Set', 1, 'Tai', 0.5, 'Ea', 0, 0),
                             11,
                             DECODE(T2.ITEM_UOM, 'Set', 1, 'Tai', 0.5, 'Ea', 0, 0),
                             24,
                             DECODE(T2.ITEM_UOM, 'Set', 1, 'Tai', 0.5, 'Ea', 0, 0),
                             1))
            INTO V_LG_AREA_SHIP_COLLECT.WITHOUT_SHIP_NUM
            FROM T_LG_SHIP_DOC      T1,
                 T_LG_SHIP_DOC_LINE T2,
                 T_INV_INVENTORIES  T3
           WHERE T1.SHIP_DOC_ID = T2.SHIP_DOC_ID
             AND T1.ENTITY_ID = C_PLN_PRODUCING_AREA.ENTITY_ID
             AND T1.SHIP_INVENTORY_ID = T3.INVENTORY_ID
             AND T1.DOC_STATUS = '00'
             AND T2.SALES_MAIN_TYPE = C_BD_ITEM_CLASS.CLASS_CODE
             AND T3.PRODUCING_AREA_ID =
                 C_PLN_PRODUCING_AREA.PRODUCING_AREA_ID;

          --获取上一日对应的日期
          /*SELECT TO_CHAR(SYSDATE - 1, 'dd') INTO V_DAY FROM DUAL;

          --判断是否是月初
          IF V_DAY = '01' THEN

            V_LG_AREA_SHIP_COLLECT.MONTH_TOTAL_ORDER_NUM := NVL(V_LG_AREA_SHIP_COLLECT.DAILY_ORDER_NUM,
                                                                0);
            V_LG_AREA_SHIP_COLLECT.MONTH_TOTAL_SHIP_NUM  := NVL(V_LG_AREA_SHIP_COLLECT.DAILY_SHIP_NUM,
                                                                0);

          ELSE

            --上一日 月累计开单数和月累计发运数
            BEGIN
              SELECT T.MONTH_TOTAL_ORDER_NUM, T.MONTH_TOTAL_SHIP_NUM
                INTO V_LG_AREA_SHIP_COLLECT.MONTH_TOTAL_ORDER_NUM,
                     V_LG_AREA_SHIP_COLLECT.MONTH_TOTAL_SHIP_NUM
                FROM T_LG_AREA_SHIP_COLLECT T
               WHERE T.AREA_ID = C_PLN_PRODUCING_AREA.PRODUCING_AREA_ID
                 AND T.SALES_MAIN_TYPE = C_BD_ITEM_CLASS.CLASS_CODE
                 AND T.ENTITY_ID = C_PLN_PRODUCING_AREA.ENTITY_ID
                 AND TRUNC(T.RECORD_DATE) = TRUNC(SYSDATE - 2);
            EXCEPTION
              WHEN OTHERS THEN
                NULL;
            END;

            V_LG_AREA_SHIP_COLLECT.MONTH_TOTAL_ORDER_NUM := NVL(V_LG_AREA_SHIP_COLLECT.MONTH_TOTAL_ORDER_NUM,
                                                                0) +
                                                            NVL(V_LG_AREA_SHIP_COLLECT.DAILY_ORDER_NUM,
                                                                0);
            V_LG_AREA_SHIP_COLLECT.MONTH_TOTAL_SHIP_NUM  := NVL(V_LG_AREA_SHIP_COLLECT.MONTH_TOTAL_SHIP_NUM,
                                                                0) +
                                                            NVL(V_LG_AREA_SHIP_COLLECT.DAILY_SHIP_NUM,
                                                                0);

          END IF;*/

          --基地发运汇总表
          INSERT INTO T_LG_AREA_SHIP_COLLECT
            (AREA_SHIP_COLLECT_ID,
             ENTITY_ID,
             AREA_ID,
             AREA_NAME,
             SALES_MAIN_TYPE,
             DAILY_ORDER_NUM,
             WITHOUT_ORDER_NUM,
             MONTH_TOTAL_ORDER_NUM,
             DAILY_SHIP_NUM,
             WITHOUT_SHIP_NUM,
             MONTH_TOTAL_SHIP_NUM,
             RECORD_DATE,
             CREATED_BY,
             CREATION_DATE,
             LAST_UPDATED_BY,
             LAST_UPDATE_DATE)
          VALUES
            (S_LG_AREA_SHIP_COLLECT.NEXTVAL,
             C_PLN_PRODUCING_AREA.ENTITY_ID, --主体
             C_PLN_PRODUCING_AREA.PRODUCING_AREA_ID, --基地ID
             C_PLN_PRODUCING_AREA.PRODUCING_AREA_NAME, --基地
             C_BD_ITEM_CLASS.CLASS_CODE, --营销大类
             NVL(V_LG_AREA_SHIP_COLLECT.DAILY_ORDER_NUM, 0), --当日开单数量
             NVL(V_LG_AREA_SHIP_COLLECT.WITHOUT_ORDER_NUM, 0), --未开单数量
             NVL(V_LG_AREA_SHIP_COLLECT.MONTH_TOTAL_ORDER_NUM, 0), --月累计开单数量
             NVL(V_LG_AREA_SHIP_COLLECT.DAILY_SHIP_NUM, 0), --当日发运数量
             NVL(V_LG_AREA_SHIP_COLLECT.WITHOUT_SHIP_NUM, 0), --开单未发运数量
             NVL(V_LG_AREA_SHIP_COLLECT.MONTH_TOTAL_SHIP_NUM, 0), --当月累计发运数量
             TRUNC(SYSDATE - 1),
             'LG',
             SYSDATE,
             'LG',
             SYSDATE);

        END LOOP;

      END LOOP;

    END LOOP;

  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      O_RESULT     := '0';
      O_RESULT_MSG := '生成失败';
      RETURN;
    WHEN OTHERS THEN
      O_RESULT     := '0';
      O_RESULT_MSG := SUBSTR(SQLERRM(SQLCODE), 1, 256);
      RETURN;
  END;

  ----------------------------------------------------------------------
  -- AUTHOR  : XUQF
  -- CREATED : 2015-02-05
  -- PURPOSE : 基地发运明细
  ----------------------------------------------------------------------
  PROCEDURE P_LG_AREA_SHIP_DETAIL(O_RESULT     OUT VARCHAR2, --返回错误码
                                  O_RESULT_MSG OUT VARCHAR2 --返回错误信息
                                  ) IS

    V_LG_AREA_SHIP_DETAIL T_LG_AREA_SHIP_DETAIL%ROWTYPE; --基地发运汇总表
    V_RECORD              NUMBER; --记录数
    V_DATE                DATE; --执行日期
    --V_DAY                 VARCHAR2(10); --日
    V_BEGIN_TIME           DATE; --统计开始时间
    V_BEGIN_M              DATE; --统计开始时间
    V_END_TIME             DATE; --统计结束时间

  BEGIN

    O_RESULT     := '1';
    O_RESULT_MSG := '生成成功';

    --检查汇总记录是否存在
    SELECT COUNT(T.AREA_SHIP_DETAIL_ID)
      INTO V_RECORD
      FROM T_LG_AREA_SHIP_DETAIL T
     WHERE TRUNC(T.RECORD_DATE) = TRUNC(SYSDATE - 1);

    IF V_RECORD > 0 THEN

      V_DATE       := TRUNC(SYSDATE - 1);
      O_RESULT     := '1001';
      O_RESULT_MSG := '日期' || V_DATE || '的数据已执行！';
      RETURN;

    END IF;


      --遍历多主体
    FOR C_ENTITY_ID IN (SELECT T.CODE_VALUE
                          FROM UP_CODELIST T
                         WHERE T.CODETYPE = 'LG_ENTITYCODE') LOOP

    --遍历产地表 目前只给家用使用
    FOR C_PLN_PRODUCING_AREA IN (SELECT T.PRODUCING_AREA_ID,
                                        T.PRODUCING_AREA_NAME,
                                        T.ENTITY_ID
                                   FROM T_PLN_PRODUCING_AREA T
                                  WHERE T.ENTITY_ID = C_ENTITY_ID.CODE_VALUE) LOOP

      --遍历产品大类
      FOR C_BD_ITEM_CLASS IN (SELECT T.CLASS_CODE
                                FROM T_BD_ITEM_CLASS T
                               WHERE T.CLASS_TYPE = 'M'
                                 AND T.ACTIVE_FLAG = 'Y'
                                 AND T.ENTITY_ID =
                                     C_PLN_PRODUCING_AREA.ENTITY_ID) LOOP

        --遍历营销中心
        FOR C_BD_SALES_CENTER IN (SELECT T.SALES_CENTER_ID,
                                         T.SALES_CENTER_NAME
                                    FROM V_BD_SALES_CENTER T
                                   WHERE T.ENTITY_ID =
                                         C_PLN_PRODUCING_AREA.ENTITY_ID) LOOP

         V_BEGIN_TIME := To_date(To_char(Trunc(SYSDATE),
                                          'yyyy/mm/dd hh24:mi:ss'),
                                  'yyyy/mm/dd hh24:mi:ss') +
                          pkg_bd.F_GET_PARAMETER_VALUE('lgReportTimeCode',
                                                       C_PLN_PRODUCING_AREA.ENTITY_ID,
                                                       null,
                                                       null) / 24 - 1;
          V_END_TIME   := To_date(To_char(Trunc(SYSDATE),
                                          'yyyy/mm/dd hh24:mi:ss'),
                                  'yyyy/mm/dd hh24:mi:ss') +
                          pkg_bd.F_GET_PARAMETER_VALUE('lgReportTimeCode',
                                                       C_PLN_PRODUCING_AREA.ENTITY_ID,
                                                       null,
                                                       null) / 24;
                                                       
          V_BEGIN_M := To_date(to_char(sysdate-1,'yyyyMM')||'01 00:00:00','yyyyMMdd hh24:mi:ss') ;

          --当日发运
          SELECT SUM(NVL(T2.FACT_SHIP_QTY, 0) *
                     decode(T1.entity_id,
                             10,
                             DECODE(T2.ITEM_UOM, 'Set', 1, 'Tai', 0.5, 'Ea', 0, 0),
                             11,
                             DECODE(T2.ITEM_UOM, 'Set', 1, 'Tai', 0.5, 'Ea', 0, 0),
                             24,
                             DECODE(T2.ITEM_UOM, 'Set', 1, 'Tai', 0.5, 'Ea', 0, 0),
                             1))
            INTO V_LG_AREA_SHIP_DETAIL.DAILY_SHIP_NUM
            FROM T_LG_CONTRACT      T1,
                 T_LG_CONTRACT_LINE T2,
                 T_INV_INVENTORIES  T3
           WHERE T2.CONTRACT_ID = T1.CONTRACT_ID
             AND T1.ENTITY_ID = C_PLN_PRODUCING_AREA.ENTITY_ID
             AND T3.INVENTORY_ID = T1.SHIP_INVENTORY_ID
             AND T2.SALES_MAIN_TYPE = C_BD_ITEM_CLASS.CLASS_CODE
             AND T3.PRODUCING_AREA_ID =
                 C_PLN_PRODUCING_AREA.PRODUCING_AREA_ID
             AND T1.SALES_CENTER_ID = C_BD_SALES_CENTER.SALES_CENTER_ID
             AND  T1.FACT_SHIP_DATE BETWEEN V_BEGIN_TIME AND V_END_TIME;
             
          
          --当月发运
          SELECT SUM(NVL(T2.FACT_SHIP_QTY, 0) *
                     decode(T1.entity_id,
                             10,
                             DECODE(T2.ITEM_UOM, 'Set', 1, 'Tai', 0.5, 'Ea', 0, 0),
                             11,
                             DECODE(T2.ITEM_UOM, 'Set', 1, 'Tai', 0.5, 'Ea', 0, 0),
                             24,
                             DECODE(T2.ITEM_UOM, 'Set', 1, 'Tai', 0.5, 'Ea', 0, 0),
                             1))
            INTO V_LG_AREA_SHIP_DETAIL.MONTH_TOTAL_SHIP_NUM
            FROM T_LG_CONTRACT      T1,
                 T_LG_CONTRACT_LINE T2,
                 T_INV_INVENTORIES  T3
           WHERE T2.CONTRACT_ID = T1.CONTRACT_ID
             AND T1.ENTITY_ID = C_PLN_PRODUCING_AREA.ENTITY_ID
             AND T3.INVENTORY_ID = T1.SHIP_INVENTORY_ID
             AND T2.SALES_MAIN_TYPE = C_BD_ITEM_CLASS.CLASS_CODE
             AND T3.PRODUCING_AREA_ID =
                 C_PLN_PRODUCING_AREA.PRODUCING_AREA_ID
             AND T1.SALES_CENTER_ID = C_BD_SALES_CENTER.SALES_CENTER_ID
             AND  T1.FACT_SHIP_DATE BETWEEN V_BEGIN_M AND V_END_TIME;

          --开单未提
          SELECT SUM((NVL(T2.ITEM_QTY, 0) - NVL(T2.FACT_SHIP_QTY, 0) -
                     NVL(T2.CANCEL_QTY, 0)) *
                     decode(T1.entity_id,
                             10,
                             DECODE(T2.ITEM_UOM, 'Set', 1, 'Tai', 0.5, 'Ea', 0, 0),
                             11,
                             DECODE(T2.ITEM_UOM, 'Set', 1, 'Tai', 0.5, 'Ea', 0, 0),
                             24,
                             DECODE(T2.ITEM_UOM, 'Set', 1, 'Tai', 0.5, 'Ea', 0, 0),
                             1))
            INTO V_LG_AREA_SHIP_DETAIL.WITHOUT_SHIP_NUM
            FROM T_LG_SHIP_DOC      T1,
                 T_LG_SHIP_DOC_LINE T2,
                 T_INV_INVENTORIES  T3
           WHERE T1.SHIP_DOC_ID = T2.SHIP_DOC_ID
             AND T1.ENTITY_ID = C_PLN_PRODUCING_AREA.ENTITY_ID
             AND T1.SHIP_INVENTORY_ID = T3.INVENTORY_ID
             AND T1.DOC_STATUS = '00'
             AND T2.SALES_MAIN_TYPE = C_BD_ITEM_CLASS.CLASS_CODE
             AND T1.SALES_CENTER_ID = C_BD_SALES_CENTER.SALES_CENTER_ID
             AND T3.PRODUCING_AREA_ID =
                 C_PLN_PRODUCING_AREA.PRODUCING_AREA_ID;

             --获取上一日对应的日期
          /*SELECT TO_CHAR(SYSDATE - 1, 'dd') INTO V_DAY FROM DUAL;

          --判断是否是月初
          IF V_DAY = '01' THEN

            V_LG_AREA_SHIP_DETAIL.MONTH_TOTAL_SHIP_NUM := NVL(V_LG_AREA_SHIP_DETAIL.DAILY_SHIP_NUM,
                                                              0);

          ELSE

            --上一日 月累计开单数和月累计发运数
            BEGIN
              SELECT T.MONTH_TOTAL_SHIP_NUM
                INTO V_LG_AREA_SHIP_DETAIL.MONTH_TOTAL_SHIP_NUM
                FROM T_LG_AREA_SHIP_DETAIL T
               WHERE T.AREA_ID = C_PLN_PRODUCING_AREA.PRODUCING_AREA_ID
                 AND T.SALES_MAIN_TYPE = C_BD_ITEM_CLASS.CLASS_CODE
                 AND T.ENTITY_ID = C_PLN_PRODUCING_AREA.ENTITY_ID
                 AND T.SALES_CENTER_ID = C_BD_SALES_CENTER.SALES_CENTER_ID
                 AND TRUNC(T.RECORD_DATE) = TRUNC(SYSDATE - 2);
            EXCEPTION
              WHEN OTHERS THEN
                NULL;
            END;

            V_LG_AREA_SHIP_DETAIL.MONTH_TOTAL_SHIP_NUM := NVL(V_LG_AREA_SHIP_DETAIL.MONTH_TOTAL_SHIP_NUM,
                                                              0) +
                                                          NVL(V_LG_AREA_SHIP_DETAIL.DAILY_SHIP_NUM,
                                                              0);

          END IF;*/

          --基地发运汇总表
          INSERT INTO T_LG_AREA_SHIP_DETAIL
            (AREA_SHIP_DETAIL_ID,
             ENTITY_ID,
             AREA_ID,
             AREA_NAME,
             SALES_MAIN_TYPE,
             SALES_CENTER_ID,
             SALES_CENTER_NAME,
             DAILY_SHIP_NUM,
             WITHOUT_SHIP_NUM,
             MONTH_TOTAL_SHIP_NUM,
             RECORD_DATE,
             CREATED_BY,
             CREATION_DATE,
             LAST_UPDATED_BY,
             LAST_UPDATE_DATE)
          VALUES
            (S_LG_AREA_SHIP_DETAIL.NEXTVAL,
             C_PLN_PRODUCING_AREA.ENTITY_ID, --主体
             C_PLN_PRODUCING_AREA.PRODUCING_AREA_ID, --基地ID
             C_PLN_PRODUCING_AREA.PRODUCING_AREA_NAME, --基地
             C_BD_ITEM_CLASS.CLASS_CODE, --营销大类
             C_BD_SALES_CENTER.SALES_CENTER_ID, --营销中心ID
             C_BD_SALES_CENTER.SALES_CENTER_NAME, --营销中心
             NVL(V_LG_AREA_SHIP_DETAIL.DAILY_SHIP_NUM, 0), --当日发运数量
             NVL(V_LG_AREA_SHIP_DETAIL.WITHOUT_SHIP_NUM, 0), --开单未发运数量
             NVL(V_LG_AREA_SHIP_DETAIL.MONTH_TOTAL_SHIP_NUM, 0), --当月累计发运数量
             TRUNC(SYSDATE - 1),
             'LG',
             SYSDATE,
             'LG',
             SYSDATE);

        END LOOP;

      END LOOP;

    END LOOP;

  END LOOP;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      O_RESULT     := '0';
      O_RESULT_MSG := '生成失败';
      RETURN;
    WHEN OTHERS THEN
      O_RESULT     := '0';
      O_RESULT_MSG := SUBSTR(SQLERRM(SQLCODE), 1, 256);
      RETURN;
  END;

END PKG_LG_REPORT;
/

