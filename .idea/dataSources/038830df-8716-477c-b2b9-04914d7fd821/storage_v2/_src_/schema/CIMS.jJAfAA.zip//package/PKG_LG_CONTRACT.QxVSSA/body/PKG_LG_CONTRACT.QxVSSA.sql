create PACKAGE BODY      PKG_LG_CONTRACT IS

  ----------------------------------------------------------------------
  -- AUTHOR  : XUQF
  -- CREATED : 2014-08-04
  -- PURPOSE : 生成实际发货信息 按照客户、地点、地址、发货仓库分组
  ----------------------------------------------------------------------
  PROCEDURE P_LG_GENE_ACTUAL_SHIP_OLD(I_VEHICLE_NUM IN VARCHAR2,
                                      O_RESULT      OUT VARCHAR2,
                                      O_RESULT_MSG  OUT VARCHAR2) IS

    V_PICK_FLAG               T_LG_SHIP_DOC.PICK_FLAG%TYPE; --自提标志
    V_NUM                     NUMBER; --循环次数
    V_SHIP_INTERFACE_ID       INTF_LG_SHIP.SHIP_INTERFACE_ID%TYPE;
    V_SHIP_DATE               INTF_LG_SHIP.SHIP_DATE%TYPE;
    V_LG_SHIP_DOC             T_LG_SHIP_DOC%ROWTYPE;
    V_ORIGIN_ORDER_NUM        T_LG_SHIP_DOC_LINE.ORIGIN_ORDER_NUM%TYPE;
    V_SALES_ORDER_TYPE_ID     T_LG_SHIP_DOC_LINE.SALES_ORDER_TYPE_ID%TYPE;
    V_SALES_MAIN_TYPE         T_LG_SHIP_DOC_LINE.SALES_MAIN_TYPE%TYPE;
    V_LG_ACTUAL_SHIP_ROW      T_LG_ACTUAL_SHIP%ROWTYPE;
    V_LG_ACTUAL_SHIP_LINE_ROW T_LG_ACTUAL_SHIP_LINE%ROWTYPE;
    TYPE TYPE_LG_ACTUAL_SHIP IS TABLE OF T_LG_ACTUAL_SHIP%ROWTYPE INDEX BY BINARY_INTEGER;
    V_LG_ACTUAL_SHIP TYPE_LG_ACTUAL_SHIP;
    TYPE TYPE_LG_ACTUAL_SHIP_LINE IS TABLE OF T_LG_ACTUAL_SHIP_LINE%ROWTYPE INDEX BY BINARY_INTEGER;
    V_LG_ACTUAL_SHIP_LINE TYPE_LG_ACTUAL_SHIP_LINE;

  BEGIN
    commit;

    O_RESULT     := '1';
    O_RESULT_MSG := '生成成功';
    V_PICK_FLAG  := '';
    V_NUM        := 0;

    --通过排车编号查询发货接口头表
    BEGIN
      SELECT SHIP_INTERFACE_ID, SHIP_DATE
        INTO V_SHIP_INTERFACE_ID, V_SHIP_DATE
        FROM INTF_LG_SHIP
       WHERE VEHICLE_NUM = I_VEHICLE_NUM;
    EXCEPTION
      WHEN OTHERS THEN
        O_RESULT     := '1001';
        O_RESULT_MSG := '排车编号[' || I_VEHICLE_NUM || ']不存在，请检查！';
        RETURN;
    END;

    --判断同一个排车编号对应的发货通知单提货方式是否一致
    FOR C_LG_PICK_FLAG IN (SELECT PICK_FLAG
                             FROM T_LG_SHIP_DOC
                            WHERE SHIP_DOC_ID IN
                                  (SELECT SHIP_DOC_ID
                                     FROM INTF_LG_SHIP_LINE
                                    WHERE SHIP_INTERFACE_ID =
                                          V_SHIP_INTERFACE_ID)) LOOP
      IF V_NUM > 0 THEN
        IF V_PICK_FLAG <> C_LG_PICK_FLAG.PICK_FLAG THEN
          O_RESULT     := '1002';
          O_RESULT_MSG := '排车编号[' || I_VEHICLE_NUM ||
                          ']对应的发货通知单存在不同的提货方式，请检查！';
          RETURN;
        END IF;
      END IF;

      V_NUM       := V_NUM + 1;
      V_PICK_FLAG := C_LG_PICK_FLAG.PICK_FLAG;

    END LOOP;

    --非自提，生成运输合同
    IF V_PICK_FLAG = 'N' THEN

      --按照客户、地点、地址、发货仓库分组
      FOR C_LG_SHIP_DOC IN (SELECT CUSTOMER_ID,
                                   CONSIGNEE_LOCATION_ID,
                                   CONSIGNEE_ADDR,
                                   SHIP_INVENTORY_ID
                              FROM T_LG_SHIP_DOC
                             WHERE SHIP_DOC_ID IN
                                   (SELECT SHIP_DOC_ID
                                      FROM INTF_LG_SHIP_LINE
                                     WHERE SHIP_INTERFACE_ID =
                                           V_SHIP_INTERFACE_ID)
                             GROUP BY (CUSTOMER_ID, CONSIGNEE_LOCATION_ID,
                                       CONSIGNEE_ADDR, SHIP_INVENTORY_ID)) LOOP

        --初始化默认值
        V_ORIGIN_ORDER_NUM    := '';
        V_SALES_ORDER_TYPE_ID := -1;
        V_SALES_MAIN_TYPE     := '';

        --根据营销大类、订单号、销售单类型排序
        FOR C_LG_SHIP_DOC_LINE IN (SELECT *
                                     FROM T_LG_SHIP_DOC_LINE
                                    WHERE SHIP_DOC_ID IN
                                          (SELECT SHIP_DOC_ID
                                             FROM T_LG_SHIP_DOC
                                            WHERE SHIP_DOC_ID IN
                                                  (SELECT SHIP_DOC_ID
                                                     FROM INTF_LG_SHIP_LINE
                                                    WHERE SHIP_INTERFACE_ID =
                                                          V_SHIP_INTERFACE_ID)
                                              AND CUSTOMER_ID =
                                                  C_LG_SHIP_DOC.CUSTOMER_ID
                                              AND CONSIGNEE_LOCATION_ID =
                                                  C_LG_SHIP_DOC.CONSIGNEE_LOCATION_ID
                                              AND CONSIGNEE_ADDR =
                                                  C_LG_SHIP_DOC.CONSIGNEE_ADDR
                                              AND SHIP_INVENTORY_ID =
                                                  C_LG_SHIP_DOC.SHIP_INVENTORY_ID)
                                      AND SHIP_DOC_LINE_ID IN
                                          (SELECT SHIP_DOC_LINE_ID
                                             FROM INTF_LG_SHIP_LINE
                                            WHERE SHIP_INTERFACE_ID =
                                                  V_SHIP_INTERFACE_ID)
                                    ORDER BY ORIGIN_ORDER_NUM,
                                             SALES_ORDER_TYPE_ID,
                                             SALES_MAIN_TYPE) LOOP

          IF (NOT (V_ORIGIN_ORDER_NUM = C_LG_SHIP_DOC_LINE.ORIGIN_ORDER_NUM AND
              V_SALES_ORDER_TYPE_ID =
              C_LG_SHIP_DOC_LINE.SALES_ORDER_TYPE_ID AND
              V_SALES_MAIN_TYPE = C_LG_SHIP_DOC_LINE.SALES_MAIN_TYPE)) THEN

            --查询发货通知单行
            BEGIN
              SELECT *
                INTO V_LG_SHIP_DOC
                FROM T_LG_SHIP_DOC
               WHERE SHIP_DOC_ID = C_LG_SHIP_DOC_LINE.SHIP_DOC_ID;
            EXCEPTION
              WHEN OTHERS THEN
                O_RESULT     := '1001';
                O_RESULT_MSG := '发货通知单行[ID:' ||
                                C_LG_SHIP_DOC_LINE.SHIP_DOC_ID ||
                                ']不存在，请检查！';
                RETURN;
            END;

            --构建实际发货信息头
            V_LG_ACTUAL_SHIP_ROW.ACTUAL_SHIP_ID          := S_LG_ACTUAL_SHIP.NEXTVAL;
            V_LG_ACTUAL_SHIP_ROW.ENTITY_ID               := V_LG_SHIP_DOC.ENTITY_ID;
            V_LG_ACTUAL_SHIP_ROW.SALES_MAIN_TYPE         := C_LG_SHIP_DOC_LINE.SALES_MAIN_TYPE;
            V_LG_ACTUAL_SHIP_ROW.VEHICLE_NUM             := I_VEHICLE_NUM;
            V_LG_ACTUAL_SHIP_ROW.SALES_ORDER_TYPE_ID     := C_LG_SHIP_DOC_LINE.SALES_ORDER_TYPE_ID;
            V_LG_ACTUAL_SHIP_ROW.VENDOR_ID               := V_LG_SHIP_DOC.VENDOR_ID;
            V_LG_ACTUAL_SHIP_ROW.VENDOR_CODE             := V_LG_SHIP_DOC.VENDOR_CODE;
            V_LG_ACTUAL_SHIP_ROW.VENDOR_NAME             := V_LG_SHIP_DOC.VENDOR_NAME;
            V_LG_ACTUAL_SHIP_ROW.SHIP_INVENTORY_ID       := V_LG_SHIP_DOC.SHIP_INVENTORY_ID;
            V_LG_ACTUAL_SHIP_ROW.CONSIGNEE_INVENTORY_ID  := V_LG_SHIP_DOC.CONSIGNEE_INVENTORY_ID;
            V_LG_ACTUAL_SHIP_ROW.CONSIGNEE_LOCATION_CODE := V_LG_SHIP_DOC.CONSIGNEE_LOCATION_CODE;
            V_LG_ACTUAL_SHIP_ROW.CONSIGNEE_ADDR          := V_LG_SHIP_DOC.CONSIGNEE_ADDR;
            V_LG_ACTUAL_SHIP_ROW.SHIP_WAY                := V_LG_SHIP_DOC.SHIP_WAY;
            V_LG_ACTUAL_SHIP_ROW.ORIGIN_TYPE             := C_LG_SHIP_DOC_LINE.ORIGIN_TYPE;
            V_LG_ACTUAL_SHIP_ROW.ORIGIN_ORDER_NUM        := C_LG_SHIP_DOC_LINE.ORIGIN_ORDER_NUM;
            V_LG_ACTUAL_SHIP_ROW.ORIGIN_ORDER_ID         := C_LG_SHIP_DOC_LINE.ORIGIN_ORDER_ID;
            V_LG_ACTUAL_SHIP_ROW.CUSTOMER_ID             := V_LG_SHIP_DOC.CUSTOMER_ID;
            V_LG_ACTUAL_SHIP_ROW.CUSTOMER_CODE           := V_LG_SHIP_DOC.CUSTOMER_CODE;
            V_LG_ACTUAL_SHIP_ROW.CUSTOMER_NAME           := V_LG_SHIP_DOC.CUSTOMER_NAME;
            V_LG_ACTUAL_SHIP_ROW.ACCOUNT_CODE            := V_LG_SHIP_DOC.ACCOUNT_CODE;
            V_LG_ACTUAL_SHIP_ROW.SHIP_DATE               := V_SHIP_DATE;
            V_LG_ACTUAL_SHIP_ROW.CREATED_BY              := 'LG';
            V_LG_ACTUAL_SHIP_ROW.CREATION_DATE           := SYSDATE;
            V_LG_ACTUAL_SHIP_ROW.LAST_UPDATED_BY         := 'LG';
            V_LG_ACTUAL_SHIP_ROW.LAST_UPDATE_DATE        := SYSDATE;

            --add by tusj 2015/8/3(样机管理增加字段)
            --begin
            V_LG_ACTUAL_SHIP_ROW.SHIP_TERMINAL_ENTITY_ID      := V_LG_SHIP_DOC.SHIP_TERMINAL_ENTITY_ID; --发货门店ID
            V_LG_ACTUAL_SHIP_ROW.SHIP_TERMINAL_CODE           := V_LG_SHIP_DOC.SHIP_TERMINAL_CODE; --发货门店编码
            V_LG_ACTUAL_SHIP_ROW.SHIP_TERMINAL_NAME           := V_LG_SHIP_DOC.SHIP_TERMINAL_NAME; --发货门店名称
            V_LG_ACTUAL_SHIP_ROW.CONSIGNEE_TERMINAL_ENTITY_ID := V_LG_SHIP_DOC.CONSIGNEE_TERMINAL_ENTITY_ID; --收货门店ID
            V_LG_ACTUAL_SHIP_ROW.CONSIGNEE_TERMINAL_CODE      := V_LG_SHIP_DOC.CONSIGNEE_TERMINAL_CODE; --收货门店编码
            V_LG_ACTUAL_SHIP_ROW.WHETHER_A3                   := V_LG_SHIP_DOC.WHETHER_A3; --是否发A3
            V_LG_ACTUAL_SHIP_ROW.CONSIGNEE_TERMINAL_NAME      := V_LG_SHIP_DOC.CONSIGNEE_TERMINAL_NAME; --收货门店名称
            --end
            --add by tusj 2015/8/3

            V_LG_ACTUAL_SHIP(V_LG_ACTUAL_SHIP.COUNT + 1) := V_LG_ACTUAL_SHIP_ROW;

          END IF;

          --构建实际发货信息行
          V_LG_ACTUAL_SHIP_LINE_ROW.ACTUAL_SHIP_LINE_ID := S_LG_ACTUAL_SHIP_LINE.NEXTVAL;
          V_LG_ACTUAL_SHIP_LINE_ROW.SHIP_INFO_ID        := V_LG_ACTUAL_SHIP_ROW.ACTUAL_SHIP_ID;
          V_LG_ACTUAL_SHIP_LINE_ROW.SHIP_DOC_LINE_ID    := C_LG_SHIP_DOC_LINE.SHIP_DOC_LINE_ID;
          V_LG_ACTUAL_SHIP_LINE_ROW.ITEM_CODE           := C_LG_SHIP_DOC_LINE.ITEM_CODE;
          V_LG_ACTUAL_SHIP_LINE_ROW.ITEM_NAME           := C_LG_SHIP_DOC_LINE.ITEM_DESC;

          --查询实际发货数量
          BEGIN
            SELECT ITEM_QTY
              INTO V_LG_ACTUAL_SHIP_LINE_ROW.ITEM_QTY
              FROM INTF_LG_SHIP_LINE T
             WHERE T.SHIP_DOC_LINE_ID = C_LG_SHIP_DOC_LINE.SHIP_DOC_LINE_ID
               AND T.SHIP_INTERFACE_ID = V_SHIP_INTERFACE_ID;
          EXCEPTION
            WHEN OTHERS THEN
              O_RESULT     := '1001';
              O_RESULT_MSG := '查询实际发货数量失败，请检查！';
              RETURN;
          END;
          --回写发货通知单行实际发货数量
          UPDATE T_LG_SHIP_DOC_LINE
             SET FACT_SHIP_QTY  = NVL(FACT_SHIP_QTY, 0) +
                                  V_LG_ACTUAL_SHIP_LINE_ROW.ITEM_QTY,
                 FACT_SHIP_DATE = SYSDATE
           WHERE SHIP_DOC_LINE_ID = C_LG_SHIP_DOC_LINE.SHIP_DOC_LINE_ID;

          V_LG_ACTUAL_SHIP_LINE_ROW.CREATED_BY          := 'LG';
          V_LG_ACTUAL_SHIP_LINE_ROW.CREATION_DATE       := SYSDATE;
          V_LG_ACTUAL_SHIP_LINE_ROW.LAST_UPDATED_BY     := 'LG';
          V_LG_ACTUAL_SHIP_LINE_ROW.LAST_UPDATE_DATE    := SYSDATE;
          V_LG_ACTUAL_SHIP_LINE_ROW.ORIGIN_LINE_ID      := C_LG_SHIP_DOC_LINE.ORIGIN_LINE_ID;
          V_LG_ACTUAL_SHIP_LINE_ROW.ORIGIN_SHIP_PLAN_ID := C_LG_SHIP_DOC_LINE.ORIGIN_SHIP_PLAN_ID;

          V_LG_ACTUAL_SHIP_LINE(V_LG_ACTUAL_SHIP_LINE.COUNT + 1) := V_LG_ACTUAL_SHIP_LINE_ROW;

          V_ORIGIN_ORDER_NUM    := C_LG_SHIP_DOC_LINE.ORIGIN_ORDER_NUM;
          V_SALES_ORDER_TYPE_ID := C_LG_SHIP_DOC_LINE.SALES_ORDER_TYPE_ID;
          V_SALES_MAIN_TYPE     := C_LG_SHIP_DOC_LINE.SALES_MAIN_TYPE;

        END LOOP;

      END LOOP;

      --自提，不生成运输合同
    ELSIF V_PICK_FLAG = 'Y' THEN

      --按照客户、发货仓库分组
      FOR C_LG_SHIP_DOC IN (SELECT CUSTOMER_ID, SHIP_INVENTORY_ID
                              FROM T_LG_SHIP_DOC
                             WHERE SHIP_DOC_ID IN
                                   (SELECT SHIP_DOC_ID
                                      FROM INTF_LG_SHIP_LINE
                                     WHERE SHIP_INTERFACE_ID =
                                           V_SHIP_INTERFACE_ID)
                             GROUP BY (CUSTOMER_ID, SHIP_INVENTORY_ID)) LOOP

        --初始化默认值
        V_ORIGIN_ORDER_NUM    := '';
        V_SALES_ORDER_TYPE_ID := -1;
        V_SALES_MAIN_TYPE     := '';

        --根据营销大类、订单号、销售单类型排序
        FOR C_LG_SHIP_DOC_LINE IN (SELECT *
                                     FROM T_LG_SHIP_DOC_LINE
                                    WHERE SHIP_DOC_ID IN
                                          (SELECT SHIP_DOC_ID
                                             FROM T_LG_SHIP_DOC
                                            WHERE SHIP_DOC_ID IN
                                                  (SELECT SHIP_DOC_ID
                                                     FROM INTF_LG_SHIP_LINE
                                                    WHERE SHIP_INTERFACE_ID =
                                                          V_SHIP_INTERFACE_ID)
                                              AND CUSTOMER_ID =
                                                  C_LG_SHIP_DOC.CUSTOMER_ID
                                              AND SHIP_INVENTORY_ID =
                                                  C_LG_SHIP_DOC.SHIP_INVENTORY_ID)
                                      AND SHIP_DOC_LINE_ID IN
                                          (SELECT SHIP_DOC_LINE_ID
                                             FROM INTF_LG_SHIP_LINE
                                            WHERE SHIP_INTERFACE_ID =
                                                  V_SHIP_INTERFACE_ID)
                                    ORDER BY ORIGIN_ORDER_NUM,
                                             SALES_ORDER_TYPE_ID,
                                             SALES_MAIN_TYPE) LOOP

          IF (NOT (V_ORIGIN_ORDER_NUM = C_LG_SHIP_DOC_LINE.ORIGIN_ORDER_NUM AND
              V_SALES_ORDER_TYPE_ID =
              C_LG_SHIP_DOC_LINE.SALES_ORDER_TYPE_ID AND
              V_SALES_MAIN_TYPE = C_LG_SHIP_DOC_LINE.SALES_MAIN_TYPE)) THEN

            --查询发货通知单行
            BEGIN
              SELECT *
                INTO V_LG_SHIP_DOC
                FROM T_LG_SHIP_DOC
               WHERE SHIP_DOC_ID = C_LG_SHIP_DOC_LINE.SHIP_DOC_ID;
            EXCEPTION
              WHEN OTHERS THEN
                O_RESULT     := '1001';
                O_RESULT_MSG := '发货通知单行[ID:' ||
                                C_LG_SHIP_DOC_LINE.SHIP_DOC_ID ||
                                ']不存在，请检查！';
                RETURN;
            END;

            --构建实际发货信息头
            V_LG_ACTUAL_SHIP_ROW.ACTUAL_SHIP_ID          := S_LG_ACTUAL_SHIP.NEXTVAL;
            V_LG_ACTUAL_SHIP_ROW.ENTITY_ID               := V_LG_SHIP_DOC.ENTITY_ID;
            V_LG_ACTUAL_SHIP_ROW.SALES_MAIN_TYPE         := C_LG_SHIP_DOC_LINE.SALES_MAIN_TYPE;
            V_LG_ACTUAL_SHIP_ROW.VEHICLE_NUM             := I_VEHICLE_NUM;
            V_LG_ACTUAL_SHIP_ROW.SALES_ORDER_TYPE_ID     := C_LG_SHIP_DOC_LINE.SALES_ORDER_TYPE_ID;
            V_LG_ACTUAL_SHIP_ROW.VENDOR_ID               := V_LG_SHIP_DOC.VENDOR_ID;
            V_LG_ACTUAL_SHIP_ROW.VENDOR_CODE             := V_LG_SHIP_DOC.VENDOR_CODE;
            V_LG_ACTUAL_SHIP_ROW.VENDOR_NAME             := V_LG_SHIP_DOC.VENDOR_NAME;
            V_LG_ACTUAL_SHIP_ROW.SHIP_INVENTORY_ID       := V_LG_SHIP_DOC.SHIP_INVENTORY_ID;
            V_LG_ACTUAL_SHIP_ROW.CONSIGNEE_INVENTORY_ID  := V_LG_SHIP_DOC.CONSIGNEE_INVENTORY_ID;
            V_LG_ACTUAL_SHIP_ROW.CONSIGNEE_LOCATION_CODE := V_LG_SHIP_DOC.CONSIGNEE_LOCATION_CODE;
            V_LG_ACTUAL_SHIP_ROW.CONSIGNEE_ADDR          := V_LG_SHIP_DOC.CONSIGNEE_ADDR;
            V_LG_ACTUAL_SHIP_ROW.SHIP_WAY                := V_LG_SHIP_DOC.SHIP_WAY;
            V_LG_ACTUAL_SHIP_ROW.ORIGIN_TYPE             := C_LG_SHIP_DOC_LINE.ORIGIN_TYPE;
            V_LG_ACTUAL_SHIP_ROW.ORIGIN_ORDER_NUM        := C_LG_SHIP_DOC_LINE.ORIGIN_ORDER_NUM;
            V_LG_ACTUAL_SHIP_ROW.ORIGIN_ORDER_ID         := C_LG_SHIP_DOC_LINE.ORIGIN_ORDER_ID;
            V_LG_ACTUAL_SHIP_ROW.CUSTOMER_ID             := V_LG_SHIP_DOC.CUSTOMER_ID;
            V_LG_ACTUAL_SHIP_ROW.CUSTOMER_CODE           := V_LG_SHIP_DOC.CUSTOMER_CODE;
            V_LG_ACTUAL_SHIP_ROW.CUSTOMER_NAME           := V_LG_SHIP_DOC.CUSTOMER_NAME;
            V_LG_ACTUAL_SHIP_ROW.ACCOUNT_CODE            := V_LG_SHIP_DOC.ACCOUNT_CODE;
            V_LG_ACTUAL_SHIP_ROW.SHIP_DATE               := V_SHIP_DATE;
            V_LG_ACTUAL_SHIP_ROW.CREATED_BY              := 'LG';
            V_LG_ACTUAL_SHIP_ROW.CREATION_DATE           := SYSDATE;
            V_LG_ACTUAL_SHIP_ROW.LAST_UPDATED_BY         := 'LG';
            V_LG_ACTUAL_SHIP_ROW.LAST_UPDATE_DATE        := SYSDATE;

            V_LG_ACTUAL_SHIP(V_LG_ACTUAL_SHIP.COUNT + 1) := V_LG_ACTUAL_SHIP_ROW;

          END IF;

          --构建实际发货信息行
          V_LG_ACTUAL_SHIP_LINE_ROW.ACTUAL_SHIP_LINE_ID := S_LG_ACTUAL_SHIP_LINE.NEXTVAL;
          V_LG_ACTUAL_SHIP_LINE_ROW.SHIP_INFO_ID        := V_LG_ACTUAL_SHIP_ROW.ACTUAL_SHIP_ID;
          V_LG_ACTUAL_SHIP_LINE_ROW.SHIP_DOC_LINE_ID    := C_LG_SHIP_DOC_LINE.SHIP_DOC_LINE_ID;
          V_LG_ACTUAL_SHIP_LINE_ROW.ITEM_CODE           := C_LG_SHIP_DOC_LINE.ITEM_CODE;
          V_LG_ACTUAL_SHIP_LINE_ROW.ITEM_NAME           := C_LG_SHIP_DOC_LINE.ITEM_DESC;

          --查询实际发货数量
          BEGIN
            SELECT ITEM_QTY
              INTO V_LG_ACTUAL_SHIP_LINE_ROW.ITEM_QTY
              FROM INTF_LG_SHIP_LINE T
             WHERE T.SHIP_DOC_LINE_ID = C_LG_SHIP_DOC_LINE.SHIP_DOC_LINE_ID
               AND T.SHIP_INTERFACE_ID = V_SHIP_INTERFACE_ID;
          EXCEPTION
            WHEN OTHERS THEN
              O_RESULT     := '1001';
              O_RESULT_MSG := '查询实际发货数量失败，请检查！';
              RETURN;
          END;
          --回写发货通知单行实际发货数量
          UPDATE T_LG_SHIP_DOC_LINE
             SET FACT_SHIP_QTY  = NVL(FACT_SHIP_QTY, 0) +
                                  V_LG_ACTUAL_SHIP_LINE_ROW.ITEM_QTY,
                 FACT_SHIP_DATE = SYSDATE
           WHERE SHIP_DOC_LINE_ID = C_LG_SHIP_DOC_LINE.SHIP_DOC_LINE_ID;

          V_LG_ACTUAL_SHIP_LINE_ROW.CREATED_BY          := 'LG';
          V_LG_ACTUAL_SHIP_LINE_ROW.CREATION_DATE       := SYSDATE;
          V_LG_ACTUAL_SHIP_LINE_ROW.LAST_UPDATED_BY     := 'LG';
          V_LG_ACTUAL_SHIP_LINE_ROW.LAST_UPDATE_DATE    := SYSDATE;
          V_LG_ACTUAL_SHIP_LINE_ROW.ORIGIN_LINE_ID      := C_LG_SHIP_DOC_LINE.ORIGIN_LINE_ID;
          V_LG_ACTUAL_SHIP_LINE_ROW.ORIGIN_SHIP_PLAN_ID := C_LG_SHIP_DOC_LINE.ORIGIN_SHIP_PLAN_ID;

          V_LG_ACTUAL_SHIP_LINE(V_LG_ACTUAL_SHIP_LINE.COUNT + 1) := V_LG_ACTUAL_SHIP_LINE_ROW;

          V_ORIGIN_ORDER_NUM    := C_LG_SHIP_DOC_LINE.ORIGIN_ORDER_NUM;
          V_SALES_ORDER_TYPE_ID := C_LG_SHIP_DOC_LINE.SALES_ORDER_TYPE_ID;
          V_SALES_MAIN_TYPE     := C_LG_SHIP_DOC_LINE.SALES_MAIN_TYPE;

        END LOOP;

      END LOOP;

    END IF;

    --插入实际发货信息头表
    FOR I IN V_LG_ACTUAL_SHIP.FIRST .. V_LG_ACTUAL_SHIP.LAST LOOP
      INSERT INTO T_LG_ACTUAL_SHIP VALUES V_LG_ACTUAL_SHIP (I);
    END LOOP;
    --插入实际发货信息行表
    FOR I IN V_LG_ACTUAL_SHIP_LINE.FIRST .. V_LG_ACTUAL_SHIP_LINE.LAST LOOP
      INSERT INTO T_LG_ACTUAL_SHIP_LINE VALUES V_LG_ACTUAL_SHIP_LINE (I);
    END LOOP;
    --回写排车编号到发货通知单
    UPDATE T_LG_SHIP_DOC
       SET VEHICLE_NUM = I_VEHICLE_NUM
     WHERE SHIP_DOC_ID IN
           (SELECT SHIP_DOC_ID
              FROM INTF_LG_SHIP_LINE
             WHERE SHIP_INTERFACE_ID = V_SHIP_INTERFACE_ID);

  EXCEPTION
    WHEN OTHERS THEN
      O_RESULT     := '0';
      O_RESULT_MSG := '生成实际发货信息失败！' || SUBSTR(SQLERRM(SQLCODE), 1, 256);
      RETURN;
  END;

  ----------------------------------------------------------------------
  -- AUTHOR  : XUQF
  -- CREATED : 2014-08-04
  -- PURPOSE : 生成实际发货信息 按照发货通知单分组
  ----------------------------------------------------------------------
  PROCEDURE P_LG_GENERATION_ACTUAL_SHIP(I_VEHICLE_NUM IN VARCHAR2,
                                        O_RESULT      OUT VARCHAR2,
                                        O_RESULT_MSG  OUT VARCHAR2) IS

    V_PICK_FLAG               T_LG_SHIP_DOC.PICK_FLAG%TYPE; --自提标志
    V_NUM                     NUMBER; --循环次数
    V_SHIP_INTERFACE_ID       INTF_LG_SHIP.SHIP_INTERFACE_ID%TYPE;
    V_SHIP_DATE               INTF_LG_SHIP.SHIP_DATE%TYPE;
    V_LG_SHIP_DOC             T_LG_SHIP_DOC%ROWTYPE;
    V_ORIGIN_ORDER_NUM        T_LG_SHIP_DOC_LINE.ORIGIN_ORDER_NUM%TYPE;
    V_SALES_ORDER_TYPE_ID     T_LG_SHIP_DOC_LINE.SALES_ORDER_TYPE_ID%TYPE;
    V_SALES_MAIN_TYPE         T_LG_SHIP_DOC_LINE.SALES_MAIN_TYPE%TYPE;
    V_LG_ACTUAL_SHIP_ROW      T_LG_ACTUAL_SHIP%ROWTYPE;
    V_LG_ACTUAL_SHIP_LINE_ROW T_LG_ACTUAL_SHIP_LINE%ROWTYPE;
    TYPE TYPE_LG_ACTUAL_SHIP IS TABLE OF T_LG_ACTUAL_SHIP%ROWTYPE INDEX BY BINARY_INTEGER;
    V_LG_ACTUAL_SHIP TYPE_LG_ACTUAL_SHIP;
    TYPE TYPE_LG_ACTUAL_SHIP_LINE IS TABLE OF T_LG_ACTUAL_SHIP_LINE%ROWTYPE INDEX BY BINARY_INTEGER;
    V_LG_ACTUAL_SHIP_LINE TYPE_LG_ACTUAL_SHIP_LINE;
    TYPE C_LG_SHIP_DOC IS REF CURSOR; --声明动态游标
    V_LG_SHIP_DOC_CURSOR C_LG_SHIP_DOC; --定义游标
    V_LG_SHIP_DOC_LINE   T_LG_SHIP_DOC_LINE%ROWTYPE; --发货通知单行
    V_DISCOUNT_TYPE       T_LG_SHIP_DOC_LINE.DISCOUNT_TYPE%TYPE;--折扣类型
  BEGIN
    O_RESULT     := '1';
    O_RESULT_MSG := '生成成功';
    V_PICK_FLAG  := '';
    V_NUM        := 0;

    --通过排车编号查询发货接口头表
    BEGIN
      SELECT SHIP_INTERFACE_ID, SHIP_DATE
        INTO V_SHIP_INTERFACE_ID, V_SHIP_DATE
        FROM INTF_LG_SHIP
       WHERE VEHICLE_NUM = I_VEHICLE_NUM;
    EXCEPTION
      WHEN OTHERS THEN
        O_RESULT     := '1001';
        O_RESULT_MSG := '排车编号[' || I_VEHICLE_NUM || ']不存在，请检查！';
        RETURN;
    END;

    --判断实际发货数量是否大于发货通知单的剩余数量
    FOR C_INTF_LG_SHIP_LINE IN (SELECT SHIP_DOC_LINE_ID,
                                       NVL(ITEM_QTY, 0) ITEM_QTY
                                  FROM INTF_LG_SHIP_LINE
                                 WHERE SHIP_INTERFACE_ID =
                                       V_SHIP_INTERFACE_ID) LOOP

      --查询发货通知行
      SELECT *
        INTO V_LG_SHIP_DOC_LINE
        FROM T_LG_SHIP_DOC_LINE T
       WHERE T.SHIP_DOC_LINE_ID = C_INTF_LG_SHIP_LINE.SHIP_DOC_LINE_ID;

      --判断本次发货数量是否大于发货通知单的产品数量-实际发货数量-取消数量
      IF C_INTF_LG_SHIP_LINE.ITEM_QTY >
         NVL(V_LG_SHIP_DOC_LINE.ITEM_QTY, 0) -
         NVL(V_LG_SHIP_DOC_LINE.FACT_SHIP_QTY, 0) -
         NVL(V_LG_SHIP_DOC_LINE.CANCEL_QTY, 0) THEN

        O_RESULT     := '1002';
        O_RESULT_MSG := '生成实际发货信息失败！ 发货通知单行ID[' ||
                        C_INTF_LG_SHIP_LINE.SHIP_DOC_LINE_ID || '],产品编码[' ||
                        V_LG_SHIP_DOC_LINE.ITEM_CODE || '],产品数量[' ||
                        NVL(V_LG_SHIP_DOC_LINE.ITEM_QTY, 0) || ']-实际发货数量[' ||
                        NVL(V_LG_SHIP_DOC_LINE.FACT_SHIP_QTY, 0) ||
                        ']-取消数量[' || NVL(V_LG_SHIP_DOC_LINE.CANCEL_QTY, 0) ||
                        ']=剩余发送数量[' ||
                        (NVL(V_LG_SHIP_DOC_LINE.ITEM_QTY, 0) -
                        NVL(V_LG_SHIP_DOC_LINE.FACT_SHIP_QTY, 0) -
                        NVL(V_LG_SHIP_DOC_LINE.CANCEL_QTY, 0)) ||
                        ']<本次发货数量[' || C_INTF_LG_SHIP_LINE.ITEM_QTY || ']。';
        RETURN;

      END IF;

    END LOOP;

    --判断同一个排车编号对应的发货通知单提货方式是否一致
    FOR C_LG_PICK_FLAG IN (SELECT PICK_FLAG
                             FROM T_LG_SHIP_DOC
                            WHERE SHIP_DOC_ID IN
                                  (SELECT SHIP_DOC_ID
                                     FROM INTF_LG_SHIP_LINE
                                    WHERE SHIP_INTERFACE_ID =
                                          V_SHIP_INTERFACE_ID)) LOOP
      IF V_NUM > 0 THEN
        IF V_PICK_FLAG <> C_LG_PICK_FLAG.PICK_FLAG THEN
          O_RESULT     := '1002';
          O_RESULT_MSG := '排车编号[' || I_VEHICLE_NUM ||
                          ']对应的发货通知单存在不同的提货方式，请检查！';
          RETURN;
        END IF;
      END IF;

      V_NUM       := V_NUM + 1;
      V_PICK_FLAG := C_LG_PICK_FLAG.PICK_FLAG;

    END LOOP;

    --按照发货通知单号分组
    FOR C_LG_SHIP_DOC IN (SELECT SHIP_DOC_CODE, ENTITY_ID
                            FROM T_LG_SHIP_DOC
                           WHERE SHIP_DOC_ID IN
                                 (SELECT SHIP_DOC_ID
                                    FROM INTF_LG_SHIP_LINE
                                   WHERE SHIP_INTERFACE_ID =
                                         V_SHIP_INTERFACE_ID)
                           GROUP BY (SHIP_DOC_CODE, ENTITY_ID)) LOOP

      --初始化默认值
      V_ORIGIN_ORDER_NUM    := '';
      V_SALES_ORDER_TYPE_ID := -1;
      V_SALES_MAIN_TYPE     := '';
      V_DISCOUNT_TYPE       := '-';

      --根据营销大类、订单号、销售单类型,折扣类型排序
      FOR C_LG_SHIP_DOC_LINE IN (SELECT *
                                   FROM T_LG_SHIP_DOC_LINE
                                  WHERE SHIP_DOC_ID IN
                                        (SELECT SHIP_DOC_ID
                                           FROM T_LG_SHIP_DOC
                                          WHERE SHIP_DOC_ID IN
                                                (SELECT SHIP_DOC_ID
                                                   FROM INTF_LG_SHIP_LINE
                                                  WHERE SHIP_INTERFACE_ID =
                                                        V_SHIP_INTERFACE_ID)
                                            AND SHIP_DOC_CODE =
                                                C_LG_SHIP_DOC.SHIP_DOC_CODE
                                            AND ENTITY_ID =
                                                C_LG_SHIP_DOC.ENTITY_ID)
                                    AND SHIP_DOC_LINE_ID IN
                                        (SELECT SHIP_DOC_LINE_ID
                                           FROM INTF_LG_SHIP_LINE
                                          WHERE SHIP_INTERFACE_ID =
                                                V_SHIP_INTERFACE_ID)
                                  ORDER BY ORIGIN_ORDER_NUM,
                                           SALES_ORDER_TYPE_ID,
                                           SALES_MAIN_TYPE,
                                           DISCOUNT_TYPE) LOOP

        IF (NOT
            (V_ORIGIN_ORDER_NUM = C_LG_SHIP_DOC_LINE.ORIGIN_ORDER_NUM AND
            V_SALES_ORDER_TYPE_ID = C_LG_SHIP_DOC_LINE.SALES_ORDER_TYPE_ID AND
            V_SALES_MAIN_TYPE = C_LG_SHIP_DOC_LINE.SALES_MAIN_TYPE AND 
            V_DISCOUNT_TYPE = C_LG_SHIP_DOC_LINE.DISCOUNT_TYPE)) THEN

          --查询发货通知单行
          BEGIN
            SELECT *
              INTO V_LG_SHIP_DOC
              FROM T_LG_SHIP_DOC
             WHERE SHIP_DOC_ID = C_LG_SHIP_DOC_LINE.SHIP_DOC_ID;
          EXCEPTION
            WHEN OTHERS THEN
              O_RESULT     := '1001';
              O_RESULT_MSG := '发货通知单行[ID:' ||
                              C_LG_SHIP_DOC_LINE.SHIP_DOC_ID || ']不存在，请检查！';
              RETURN;
          END;

          --构建实际发货信息头
          V_LG_ACTUAL_SHIP_ROW.ACTUAL_SHIP_ID          := S_LG_ACTUAL_SHIP.NEXTVAL;
          V_LG_ACTUAL_SHIP_ROW.ENTITY_ID               := V_LG_SHIP_DOC.ENTITY_ID;
          V_LG_ACTUAL_SHIP_ROW.SALES_MAIN_TYPE         := C_LG_SHIP_DOC_LINE.SALES_MAIN_TYPE;
          V_LG_ACTUAL_SHIP_ROW.VEHICLE_NUM             := I_VEHICLE_NUM;
          V_LG_ACTUAL_SHIP_ROW.SALES_ORDER_TYPE_ID     := C_LG_SHIP_DOC_LINE.SALES_ORDER_TYPE_ID;
          V_LG_ACTUAL_SHIP_ROW.VENDOR_ID               := V_LG_SHIP_DOC.VENDOR_ID;
          V_LG_ACTUAL_SHIP_ROW.VENDOR_CODE             := V_LG_SHIP_DOC.VENDOR_CODE;
          V_LG_ACTUAL_SHIP_ROW.VENDOR_NAME             := V_LG_SHIP_DOC.VENDOR_NAME;
          V_LG_ACTUAL_SHIP_ROW.SHIP_INVENTORY_ID       := V_LG_SHIP_DOC.SHIP_INVENTORY_ID;
          V_LG_ACTUAL_SHIP_ROW.CONSIGNEE_INVENTORY_ID  := V_LG_SHIP_DOC.CONSIGNEE_INVENTORY_ID;
          V_LG_ACTUAL_SHIP_ROW.CONSIGNEE_LOCATION_CODE := V_LG_SHIP_DOC.CONSIGNEE_LOCATION_CODE;
          V_LG_ACTUAL_SHIP_ROW.CONSIGNEE_ADDR          := V_LG_SHIP_DOC.CONSIGNEE_ADDR;
          V_LG_ACTUAL_SHIP_ROW.SHIP_WAY                := V_LG_SHIP_DOC.SHIP_WAY;
          V_LG_ACTUAL_SHIP_ROW.ORIGIN_TYPE             := C_LG_SHIP_DOC_LINE.ORIGIN_TYPE;
          V_LG_ACTUAL_SHIP_ROW.ORIGIN_ORDER_NUM        := C_LG_SHIP_DOC_LINE.ORIGIN_ORDER_NUM;
          V_LG_ACTUAL_SHIP_ROW.ORIGIN_ORDER_ID         := C_LG_SHIP_DOC_LINE.ORIGIN_ORDER_ID;
          V_LG_ACTUAL_SHIP_ROW.CUSTOMER_ID             := V_LG_SHIP_DOC.CUSTOMER_ID;
          V_LG_ACTUAL_SHIP_ROW.CUSTOMER_CODE           := V_LG_SHIP_DOC.CUSTOMER_CODE;
          V_LG_ACTUAL_SHIP_ROW.CUSTOMER_NAME           := V_LG_SHIP_DOC.CUSTOMER_NAME;
          V_LG_ACTUAL_SHIP_ROW.ACCOUNT_CODE            := V_LG_SHIP_DOC.ACCOUNT_CODE;
          V_LG_ACTUAL_SHIP_ROW.SHIP_DATE               := V_SHIP_DATE;
          V_LG_ACTUAL_SHIP_ROW.CREATED_BY              := 'LG';
          V_LG_ACTUAL_SHIP_ROW.CREATION_DATE           := SYSDATE;
          V_LG_ACTUAL_SHIP_ROW.LAST_UPDATED_BY         := 'LG';
          V_LG_ACTUAL_SHIP_ROW.LAST_UPDATE_DATE        := SYSDATE;
          --add by tusj 2015/8/3(样机管理增加字段)
          --begin
          V_LG_ACTUAL_SHIP_ROW.SHIP_TERMINAL_ENTITY_ID      := V_LG_SHIP_DOC.SHIP_TERMINAL_ENTITY_ID; --发货门店ID
          V_LG_ACTUAL_SHIP_ROW.SHIP_TERMINAL_CODE           := V_LG_SHIP_DOC.SHIP_TERMINAL_CODE; --发货门店编码
          V_LG_ACTUAL_SHIP_ROW.SHIP_TERMINAL_NAME           := V_LG_SHIP_DOC.SHIP_TERMINAL_NAME; --发货门店名称
          V_LG_ACTUAL_SHIP_ROW.CONSIGNEE_TERMINAL_ENTITY_ID := V_LG_SHIP_DOC.CONSIGNEE_TERMINAL_ENTITY_ID; --收货门店ID
          V_LG_ACTUAL_SHIP_ROW.CONSIGNEE_TERMINAL_CODE      := V_LG_SHIP_DOC.CONSIGNEE_TERMINAL_CODE; --收货门店编码
          V_LG_ACTUAL_SHIP_ROW.WHETHER_A3                   := V_LG_SHIP_DOC.WHETHER_A3; --是否发A3
          V_LG_ACTUAL_SHIP_ROW.CONSIGNEE_TERMINAL_NAME      := V_LG_SHIP_DOC.CONSIGNEE_TERMINAL_NAME; --收货门店名称
          V_LG_ACTUAL_SHIP_ROW.DISCOUNT_TYPE                := C_LG_SHIP_DOC_LINE.DISCOUNT_TYPE; --折扣类型
          --end
          --add by tusj 2015/8/3

          V_LG_ACTUAL_SHIP(V_LG_ACTUAL_SHIP.COUNT + 1) := V_LG_ACTUAL_SHIP_ROW;

        END IF;

        --构建实际发货信息行
        V_LG_ACTUAL_SHIP_LINE_ROW.ACTUAL_SHIP_LINE_ID := S_LG_ACTUAL_SHIP_LINE.NEXTVAL;
        V_LG_ACTUAL_SHIP_LINE_ROW.SHIP_INFO_ID        := V_LG_ACTUAL_SHIP_ROW.ACTUAL_SHIP_ID;
        V_LG_ACTUAL_SHIP_LINE_ROW.SHIP_DOC_LINE_ID    := C_LG_SHIP_DOC_LINE.SHIP_DOC_LINE_ID;
        V_LG_ACTUAL_SHIP_LINE_ROW.ITEM_CODE           := C_LG_SHIP_DOC_LINE.ITEM_CODE;
        V_LG_ACTUAL_SHIP_LINE_ROW.ITEM_NAME           := C_LG_SHIP_DOC_LINE.ITEM_DESC;

        --查询实际发货数量
        BEGIN
          SELECT ITEM_QTY,SHIP_DATE
            INTO V_LG_ACTUAL_SHIP_LINE_ROW.ITEM_QTY,V_LG_ACTUAL_SHIP_LINE_ROW.SHIP_DATE
            FROM INTF_LG_SHIP_LINE T
           WHERE T.SHIP_DOC_LINE_ID = C_LG_SHIP_DOC_LINE.SHIP_DOC_LINE_ID
             AND T.SHIP_INTERFACE_ID = V_SHIP_INTERFACE_ID;
        EXCEPTION
          WHEN OTHERS THEN
            O_RESULT     := '1001';
            O_RESULT_MSG := '查询实际发货数量失败，请检查！';
            RETURN;
        END;
        --回写发货通知单行实际发货数量
        UPDATE T_LG_SHIP_DOC_LINE
           SET FACT_SHIP_QTY  = NVL(FACT_SHIP_QTY, 0) +
                                V_LG_ACTUAL_SHIP_LINE_ROW.ITEM_QTY,
               FACT_SHIP_DATE = SYSDATE,
               LAST_UPDATE_DATE = SYSDATE
         WHERE SHIP_DOC_LINE_ID = C_LG_SHIP_DOC_LINE.SHIP_DOC_LINE_ID;

        V_LG_ACTUAL_SHIP_LINE_ROW.CREATED_BY          := 'LG';
        V_LG_ACTUAL_SHIP_LINE_ROW.CREATION_DATE       := SYSDATE;
        V_LG_ACTUAL_SHIP_LINE_ROW.LAST_UPDATED_BY     := 'LG';
        V_LG_ACTUAL_SHIP_LINE_ROW.LAST_UPDATE_DATE    := SYSDATE;
        V_LG_ACTUAL_SHIP_LINE_ROW.ORIGIN_LINE_ID      := C_LG_SHIP_DOC_LINE.ORIGIN_LINE_ID;
        V_LG_ACTUAL_SHIP_LINE_ROW.ORIGIN_SHIP_PLAN_ID := C_LG_SHIP_DOC_LINE.ORIGIN_SHIP_PLAN_ID;

        V_LG_ACTUAL_SHIP_LINE(V_LG_ACTUAL_SHIP_LINE.COUNT + 1) := V_LG_ACTUAL_SHIP_LINE_ROW;

        V_ORIGIN_ORDER_NUM    := C_LG_SHIP_DOC_LINE.ORIGIN_ORDER_NUM;
        V_SALES_ORDER_TYPE_ID := C_LG_SHIP_DOC_LINE.SALES_ORDER_TYPE_ID;
        V_SALES_MAIN_TYPE     := C_LG_SHIP_DOC_LINE.SALES_MAIN_TYPE;
        V_DISCOUNT_TYPE       := C_LG_SHIP_DOC_LINE.DISCOUNT_TYPE;

      END LOOP;

    END LOOP;

    --插入实际发货信息头表
    FOR I IN V_LG_ACTUAL_SHIP.FIRST .. V_LG_ACTUAL_SHIP.LAST LOOP
      INSERT INTO T_LG_ACTUAL_SHIP VALUES V_LG_ACTUAL_SHIP (I);
    END LOOP;
    --插入实际发货信息行表
    FOR I IN V_LG_ACTUAL_SHIP_LINE.FIRST .. V_LG_ACTUAL_SHIP_LINE.LAST LOOP
      INSERT INTO T_LG_ACTUAL_SHIP_LINE VALUES V_LG_ACTUAL_SHIP_LINE (I);
    END LOOP;

    --更新发货通知单前先锁表
    OPEN V_LG_SHIP_DOC_CURSOR FOR 'SELECT SHIP_DOC_ID
      FROM T_LG_SHIP_DOC
     WHERE SHIP_DOC_ID IN
           (SELECT SHIP_DOC_ID
              FROM INTF_LG_SHIP_LINE
             WHERE SHIP_INTERFACE_ID = ' || V_SHIP_INTERFACE_ID || ')
       FOR UPDATE WAIT 5';

    --回写排车编号到发货通知单
    UPDATE T_LG_SHIP_DOC
       SET VEHICLE_NUM = I_VEHICLE_NUM, LAST_UPDATE_DATE = SYSDATE
     WHERE SHIP_DOC_ID IN
           (SELECT SHIP_DOC_ID
              FROM INTF_LG_SHIP_LINE
             WHERE SHIP_INTERFACE_ID = V_SHIP_INTERFACE_ID);

  EXCEPTION
    WHEN OTHERS THEN
      O_RESULT     := '0';
      O_RESULT_MSG := '生成实际发货信息失败！' || SUBSTR(SQLERRM(SQLCODE), 1, 256);
      RETURN;
  END;

  ----------------------------------------------------------------------
  -- AUTHOR  : XUQF
  -- CREATED : 2014-08-07
  -- PURPOSE : 生成运输合同
  ----------------------------------------------------------------------
PROCEDURE P_LG_GENERATION_CONTRACT(I_VEHICLE_NUM IN VARCHAR2,
                                   O_RESULT      OUT VARCHAR2,
                                   O_RESULT_MSG  OUT VARCHAR2) IS
  V_LG_SHIP_ROW              INTF_LG_SHIP%ROWTYPE;
  V_LG_VEHICLE_INFO_ROW      T_LG_VEHICLE_INFO%ROWTYPE;
  V_LG_SHIP_DOC              T_LG_SHIP_DOC%ROWTYPE;
  V_LG_CONTRACT_ROW          T_LG_CONTRACT%ROWTYPE;
  V_LG_SHIP_DOC_LINE         T_LG_SHIP_DOC_LINE%ROWTYPE;
  V_LG_VEHICLE_INFO_LINE_ROW T_LG_VEHICLE_INFO_LINE%ROWTYPE;
  V_LG_CONTRACT_LINE_ROW     T_LG_CONTRACT_LINE%ROWTYPE;
  V_NUM                      NUMBER;
  TYPE TYPE_LG_CONTRACT IS TABLE OF T_LG_CONTRACT%ROWTYPE INDEX BY BINARY_INTEGER;
  V_LG_CONTRACT TYPE_LG_CONTRACT;
  TYPE TYPE_LG_VEHICLE_INFO_LINE IS TABLE OF T_LG_VEHICLE_INFO_LINE%ROWTYPE INDEX BY BINARY_INTEGER;
  V_LG_VEHICLE_INFO_LINE TYPE_LG_VEHICLE_INFO_LINE;
  TYPE TYPE_LG_CONTRACT_LINE IS TABLE OF T_LG_CONTRACT_LINE%ROWTYPE INDEX BY BINARY_INTEGER;
  V_LG_CONTRACT_LINE         TYPE_LG_CONTRACT_LINE;
  V_LG_CONTRACT_LINE_TEMP    T_LG_CONTRACT_LINE%ROWTYPE;
  V_LG_LINE_FREIGHT_STANDARD T_LG_LINE_FREIGHT_STANDARD%ROWTYPE;
  V_LG_INSURANCE_ROW         T_LG_INSURANCE%ROWTYPE;
  V_LIST_PRICE               T_BD_PRICE_LINE.LIST_PRICE%TYPE;
  V_SOURCE_TYPE_CODE         T_INV_SOURCE_TYPES.SOURCE_TYPE_CODE%TYPE; --单据类型
  V_TAX_RATE                 T_LG_CONTRACT.TAX_RATE%TYPE; --税率
  V_TRANSPORT_LINE_ID        T_LG_TRANSPORT_LINE.TRANSPORT_LINE_ID%TYPE; --运输线路ID
  V_TOTAL_VOLUME             NUMBER; --当前车的总体积
  V_OU_MODE                  VARCHAR2(20); --OU模式
  V_ORDER_LG_TYPE            T_PLN_ORDER_TYPE.ORDER_LG_TYPE%TYPE; --提货类型 add by liyuanji
  V_TRANSFER_SPLIT_FLAG      VARCHAR2(20); --主体参数，是否按直发客户拆分                        

BEGIN
  O_RESULT     := '1';
  O_RESULT_MSG := '生成成功';

  --commit;

  --通过排车编号查询发货接口头表
  SELECT *
    INTO V_LG_SHIP_ROW
    FROM INTF_LG_SHIP
   WHERE VEHICLE_NUM = I_VEHICLE_NUM;

  --获取该车总体积
  SELECT NVL(SUM(B.UNIT_VOLUME * A.ITEM_QTY), 0)
    INTO V_TOTAL_VOLUME
    FROM INTF_LG_SHIP_LINE A, T_LG_SHIP_DOC_LINE B
   WHERE A.SHIP_INTERFACE_ID = V_LG_SHIP_ROW.SHIP_INTERFACE_ID
     AND A.SHIP_DOC_LINE_ID = B.SHIP_DOC_LINE_ID;

  --获取发货通知中的主体和发运方式
  SELECT *
    INTO V_LG_SHIP_DOC
    FROM T_LG_SHIP_DOC
   WHERE SHIP_DOC_ID =
         (SELECT SHIP_DOC_ID
            FROM INTF_LG_SHIP_LINE
           WHERE SHIP_INTERFACE_ID = V_LG_SHIP_ROW.SHIP_INTERFACE_ID
             AND ROWNUM = 1);
  BEGIN
    --查询保险费价格列表ID
    SELECT *
      INTO V_LG_INSURANCE_ROW
      FROM T_LG_INSURANCE
     WHERE ENTITY_ID = V_LG_SHIP_DOC.ENTITY_ID
       AND TRANSPORT_WAY = V_LG_SHIP_DOC.SHIP_WAY
       AND BEGIN_DATE <= SYSDATE
       AND (END_DATE IS NULL OR
           (END_DATE IS NOT NULL AND END_DATE >= SYSDATE));
  EXCEPTION
    WHEN OTHERS THEN
      NULL;
  END;

  --获取运费税率
  BEGIN
    SELECT TAX_RATE
      INTO V_TAX_RATE
      FROM T_LG_TAX_RATE_CONF
     WHERE CHARGES_TYPE_CODE = '00'
       AND ENTITY_ID = V_LG_SHIP_DOC.ENTITY_ID
       AND DEFAULT_FLAG = 'Y';
  EXCEPTION
    WHEN OTHERS THEN
      NULL;
  END;

  --获取线路
  V_TRANSPORT_LINE_ID := PKG_LG_SHIP.F_GET_TRANSPORT_LINE_NEW(in_ENTITY_ID               => V_LG_SHIP_DOC.ENTITY_ID,
                                                              in_SHIP_TO_LOCATION_CODE   => V_LG_SHIP_DOC.SHIP_TO_LOCATION_CODE,
                                                              in_CONSIGNEE_LOCATION_CODE => V_LG_SHIP_DOC.CONSIGNEE_LOCATION_CODE,
                                                              in_SHIP_WAY                => V_LG_SHIP_DOC.SHIP_WAY,
                                                              in_SHIP_TYPE               => V_LG_SHIP_DOC.SHIP_TYPE,
                                                              in_LOAD_VEHICLE_TYPE       => V_LG_SHIP_DOC.Load_Vehicle_Type);

  BEGIN
    --获取单位运费、附加运费、计价单位和装车类型
    SELECT T.UNIT_PRICE_OF_FREIGHT,
           T.EXTRA_SHIP_CHARGES,
           T.PRICE_UNIT,
           T.LOAD_VEHICLE_TYPE
      INTO V_LG_LINE_FREIGHT_STANDARD.UNIT_PRICE_OF_FREIGHT,
           V_LG_LINE_FREIGHT_STANDARD.EXTRA_SHIP_CHARGES,
           V_LG_LINE_FREIGHT_STANDARD.PRICE_UNIT,
           V_LG_LINE_FREIGHT_STANDARD.LOAD_VEHICLE_TYPE
      FROM T_LG_LINE_FREIGHT_STANDARD T
     WHERE T.TRANSPORT_LINE_ID = V_TRANSPORT_LINE_ID
       AND T.SHIP_WAY = V_LG_SHIP_DOC.SHIP_WAY
       AND T.SHIP_TYPE = V_LG_SHIP_DOC.SHIP_TYPE
          --AND T.LOAD_VEHICLE_TYPE = V_LG_SHIP_DOC.LOAD_VEHICLE_TYPE
       AND T.VENDOR_ID = V_LG_SHIP_DOC.VENDOR_ID
       AND T.ENTITY_ID = V_LG_SHIP_DOC.ENTITY_ID
       AND T.BEGIN_DATE <= SYSDATE
       AND (T.END_DATE IS NULL OR T.END_DATE >= SYSDATE)
       AND T.MIN_VOL_WEIGHT <= V_TOTAL_VOLUME
       AND (T.MAX_VOL_WEIGHT IS NULL OR T.MAX_VOL_WEIGHT > V_TOTAL_VOLUME);
  EXCEPTION
    WHEN OTHERS THEN
      NULL;
  END;

  --chenyj8，20180720 根据主体参数设置是否按直发客户拆合同
  BEGIN
    V_TRANSFER_SPLIT_FLAG := PKG_BD.F_GET_PARAMETER_VALUE('LG_CONTRACT_TRANSFER_SPLIT',
                                                          V_LG_SHIP_DOC.ENTITY_ID,
                                                          NULL,
                                                          NULL);
  EXCEPTION
    WHEN OTHERS THEN
      V_TRANSFER_SPLIT_FLAG := 'N';
  END;

  --初始化默认值
  V_LG_SHIP_DOC.CUSTOMER_ID           := -1;
  V_LG_SHIP_DOC.CONSIGNEE_LOCATION_ID := -1;
  V_LG_SHIP_DOC.CONSIGNEE_ADDR        := '';
  V_LG_SHIP_DOC.SHIP_INVENTORY_ID     := -1;
  V_LG_SHIP_DOC.TRANSFER_CUSTOMER_ID  := -1;

  V_NUM := 0;
  --按照客户、收货地点、收货地址、发货仓库,直发客户（按主体）,
  FOR C_LG_SHIP_DOC IN (SELECT SHIP_DOC_ID,
                               SHIP_DOC_CODE,
                               DOC_STATUS,
                               ENTITY_ID,
                               SHIP_WAY,
                               SALES_CENTER_ID,
                               CUSTOMER_ID,
                               CUSTOMER_CODE,
                               CUSTOMER_NAME,
                               ACCOUNT_CODE,
                               CUSTOMER_CONTACTS,
                               CUSTOMER_CONTACTS_PHONES,
                               SHIP_TYPE,
                               VEHICLE_NUM,
                               LOAD_VEHICLE_TYPE,
                               SHIP_TO_LOCATION_ID,
                               SHIP_TO_LOCATION_CODE,
                               SHIP_TO_LOCATION,
                               SHIP_INVENTORY_ID,
                               SHIP_INVENTORY_CODE,
                               SHIP_INVENTORY_NAME,
                               CONSIGNEE_INVENTORY_ID,
                               CONSIGNEE_INVENTORY_CODE,
                               CONSIGNEE_INVENTORY_NAME,
                               CONSIGNEE_ADDR,
                               CONSIGNEE_LOCATION_ID,
                               CONSIGNEE_LOCATION_CODE,
                               CONSIGNEE_LOCATION,
                               CONSIGNEE_COMPANY_ID,
                               CONSIGNEE_COMPANY_CODE,
                               CONSIGNEE_COMPANY_NAME,
                               CONSIGNEE_COMPANY_ADDR,
                               CONSIGNEE_COMPANY_CONTACT_ID,
                               CONSIGNEE_COMPANY_CONTRACT,
                               CONSIGNEE_COMPANY_TEL,
                               DISTANCE,
                               VENDOR_ID,
                               VENDOR_CODE,
                               VENDOR_NAME,
                               VENDOR_CONTACT,
                               VENDOR_TEL,
                               TOTAL_AMOUNT,
                               CONSIGN_COMPANY_ID,
                               REQUIRE_SHIP_DATE,
                               REQUIRE_ARRIVE_DATE,
                               PRINT_TIMES,
                               ORIGIN_SHIP_DOC_CODE,
                               PICK_FLAG,
                               BATCH_DEAL_NUM,
                               FIRST_PRINT_BY,
                               FIRST_PRINT_TIME,
                               LAST_PRINT_BY,
                               LAST_PRINT_TIME,
                               ADDRESS_CHANGE_FLAG,
                               VENDOR_STATUS,
                               VENDOR_ERROR_MESSAGE,
                               IMPORT_VENDOR_TIME,
                               DOC_DATE,
                               REMARK,
                               CREATED_BY,
                               CREATION_DATE,
                               LAST_UPDATED_BY,
                               LAST_UPDATE_DATE,
                               IS_CUSG_FLAG,
                               CUSTOMER_ORDER_NUMBER,
                               SALES_CENTER_CODE,
                               SALES_CENTER_NAME,
                               SHIP_STATUS,
                               SHIP_ADDR,
                               SHIP_CONTRACT,
                               SHIP_TEL,
                               SHIP_TERMINAL_ENTITY_ID,
                               SHIP_TERMINAL_CODE,
                               SHIP_TERMINAL_NAME,
                               CONSIGNEE_TERMINAL_ENTITY_ID,
                               CONSIGNEE_TERMINAL_CODE,
                               CONSIGNEE_TERMINAL_NAME,
                               WHETHER_A3,
                               WHETHER_PURE_TRANSPORT,
                               CUSTOMER_CHANNEL_TYPE,
                               CARRY_DATE,
                               PLATFORM_SIGN,
                               QT_ORDER,
                               EXPECT_DATE,
                               IF_APPOINTMENT_SHIP,
                               ENGAGEMENT_DATE,
                               DISABLE_QT_FLAG,
                               TRANSFER_ENTITY_ID,
                               DECODE(V_TRANSFER_SPLIT_FLAG,
                                      'N',
                                      -1,
                                      TRANSFER_CUSTOMER_ID) TRANSFER_CUSTOMER_ID,
                               TRANSFER_CUSTOMER_CODE,
                               TRANSFER_CUSTOMER_NAME,
                               TRANSFER_ACCOUNT_ID,
                               TRANSFER_ACCOUNT_CODE,
                               CUSTOMER_ORDER_DATE,
                               LG_PROCESS_TYPE,
                               CONSIGNMENT_DATE,
                               DIRECT_TRANSPORT_FALG,
                               WAIT_FOR_PREAPPOINT_FLAG,
                               BOOK_RECEIPT_DATE,
                               CANCEL_PREAPPOIN_FLAG,
                               DIRECT_TRANSPORT_DATE,
                               DISTRIBUTE_MODE
                               
                          FROM T_LG_SHIP_DOC
                         WHERE SHIP_DOC_ID IN
                               (SELECT SHIP_DOC_ID
                                  FROM INTF_LG_SHIP_LINE
                                 WHERE SHIP_INTERFACE_ID =
                                       V_LG_SHIP_ROW.SHIP_INTERFACE_ID)
                         ORDER BY CUSTOMER_ID,
                                  CONSIGNEE_LOCATION_ID,
                                  CONSIGNEE_ADDR,
                                  SHIP_INVENTORY_ID,
                                  TRANSFER_CUSTOMER_ID) LOOP
    IF V_NUM = 0 THEN
      --构建排车信息
      V_LG_VEHICLE_INFO_ROW.VEHICLE_INFO_ID        := S_LG_VEHICLE_INFO.NEXTVAL;
      V_LG_VEHICLE_INFO_ROW.ENTITY_ID              := C_LG_SHIP_DOC.ENTITY_ID;
      V_LG_VEHICLE_INFO_ROW.VEHICLE_NUM            := V_LG_SHIP_ROW.VEHICLE_NUM;
      V_LG_VEHICLE_INFO_ROW.SHIP_DATE              := V_LG_SHIP_ROW.SHIP_DATE;
      V_LG_VEHICLE_INFO_ROW.VEHICLE_BRAND_NUM      := V_LG_SHIP_ROW.VEHICLE_BRAND_NUM;
      V_LG_VEHICLE_INFO_ROW.CHAUFFEUR_TEL          := V_LG_SHIP_ROW.CHAUFFEUR_TEL;
      V_LG_VEHICLE_INFO_ROW.CHAUFFEUR_IDENTITY_NUM := V_LG_SHIP_ROW.CHAUFFEUR_IDENTITY_NUM;
      V_LG_VEHICLE_INFO_ROW.CHAUFFEUR              := V_LG_SHIP_ROW.CHAUFFEUR;
      V_LG_VEHICLE_INFO_ROW.SEAL_NUM               := V_LG_SHIP_ROW.SEAL_NUM;
      V_LG_VEHICLE_INFO_ROW.SEAL_DATE              := V_LG_SHIP_ROW.SEAL_DATE;
      V_LG_VEHICLE_INFO_ROW.SEAL_BY                := V_LG_SHIP_ROW.SEALE_USER; --不统一
      V_LG_VEHICLE_INFO_ROW.SIGN_SEAL_NUM          := '';
      V_LG_VEHICLE_INFO_ROW.SIGN_SEAL_DATE         := '';
      V_LG_VEHICLE_INFO_ROW.SIGN_SEAL_BY           := '';
      V_LG_VEHICLE_INFO_ROW.SEAL_STATUS            := '';
      V_LG_VEHICLE_INFO_ROW.VENDOR_ID              := C_LG_SHIP_DOC.VENDOR_ID;
      V_LG_VEHICLE_INFO_ROW.VENDOR_CODE            := C_LG_SHIP_DOC.VENDOR_CODE;
      V_LG_VEHICLE_INFO_ROW.VENDOR_NAME            := C_LG_SHIP_DOC.VENDOR_NAME;
      V_LG_VEHICLE_INFO_ROW.VENDOR_CONTACT         := C_LG_SHIP_DOC.VENDOR_CONTACT;
      V_LG_VEHICLE_INFO_ROW.VENDOR_TEL             := C_LG_SHIP_DOC.VENDOR_TEL;
      V_LG_VEHICLE_INFO_ROW.CREATED_BY             := 'LG';
      V_LG_VEHICLE_INFO_ROW.CREATION_DATE          := SYSDATE;
      V_LG_VEHICLE_INFO_ROW.LAST_UPDATED_BY        := 'LG';
      V_LG_VEHICLE_INFO_ROW.LAST_UPDATE_DATE       := SYSDATE;
      V_LG_VEHICLE_INFO_ROW.CARRIER_NAME           := V_LG_SHIP_ROW.CARRIER_NAME; --下属承运商
    
    END IF;
  
    IF (NOT
        (V_LG_SHIP_DOC.CUSTOMER_ID = C_LG_SHIP_DOC.CUSTOMER_ID AND
        V_LG_SHIP_DOC.CONSIGNEE_LOCATION_ID =
        C_LG_SHIP_DOC.CONSIGNEE_LOCATION_ID AND
        V_LG_SHIP_DOC.CONSIGNEE_ADDR = C_LG_SHIP_DOC.CONSIGNEE_ADDR AND
        V_LG_SHIP_DOC.SHIP_INVENTORY_ID = C_LG_SHIP_DOC.SHIP_INVENTORY_ID AND
        V_LG_SHIP_DOC.TRANSFER_CUSTOMER_ID =
        C_LG_SHIP_DOC.TRANSFER_CUSTOMER_ID
        
        )) THEN
    
      --构建运输合同头
      V_LG_CONTRACT_ROW.CONTRACT_ID       := S_LG_CONTRACT.NEXTVAL;
      V_LG_CONTRACT_ROW.ENTITY_ID         := C_LG_SHIP_DOC.ENTITY_ID;
      V_LG_CONTRACT_ROW.CONTRACT_CODE     := PKG_BD.F_GET_BILL_NO(P_BILL_TYPE  => 'lgContractNo',
                                                                  P_PREFIX_ADD => NULL,
                                                                  P_ENTITY_ID  => C_LG_SHIP_DOC.ENTITY_ID,
                                                                  P_USER_ID    => NULL);
      V_LG_CONTRACT_ROW.BILLS_STATUS      := '00';
      V_LG_CONTRACT_ROW.VEHICLE_INFO_ID   := V_LG_VEHICLE_INFO_ROW.VEHICLE_INFO_ID;
      V_LG_CONTRACT_ROW.SALES_CENTER_ID   := C_LG_SHIP_DOC.SALES_CENTER_ID;
      V_LG_CONTRACT_ROW.SALES_CENTER_CODE := C_LG_SHIP_DOC.SALES_CENTER_CODE; --营销中心编码
      V_LG_CONTRACT_ROW.SALES_CENTER_NAME := C_LG_SHIP_DOC.SALES_CENTER_NAME; --营销中心名称
      V_LG_CONTRACT_ROW.SHIP_WAY          := C_LG_SHIP_DOC.SHIP_WAY;
      --V_LG_CONTRACT_ROW.LOAD_VEHICLE_TYPE            := C_LG_SHIP_DOC.LOAD_VEHICLE_TYPE; --不同的发货通知单可能既有整车也有零担
      V_LG_CONTRACT_ROW.LOAD_VEHICLE_TYPE            := NVL(V_LG_LINE_FREIGHT_STANDARD.LOAD_VEHICLE_TYPE,
                                                            '01'); --取排车信息对应的实际装车类型 无线路默认为整车
      V_LG_CONTRACT_ROW.SHIP_TYPE                    := C_LG_SHIP_DOC.SHIP_TYPE;
      V_LG_CONTRACT_ROW.CUSTOMER_ID                  := C_LG_SHIP_DOC.CUSTOMER_ID;
      V_LG_CONTRACT_ROW.CUSTOMER_CODE                := C_LG_SHIP_DOC.CUSTOMER_CODE;
      V_LG_CONTRACT_ROW.CUSTOMER_NAME                := C_LG_SHIP_DOC.CUSTOMER_NAME;
      V_LG_CONTRACT_ROW.ACCOUNT_CODE                 := C_LG_SHIP_DOC.ACCOUNT_CODE;
      V_LG_CONTRACT_ROW.CUSTOMER_CONTACTS            := C_LG_SHIP_DOC.CUSTOMER_CONTACTS;
      V_LG_CONTRACT_ROW.CUSTOMER_CONTACTS_PHONES     := C_LG_SHIP_DOC.CUSTOMER_CONTACTS_PHONES;
      V_LG_CONTRACT_ROW.SHIP_TO_LOCATION_ID          := C_LG_SHIP_DOC.SHIP_TO_LOCATION_ID;
      V_LG_CONTRACT_ROW.SHIP_TO_LOCATION_CODE        := C_LG_SHIP_DOC.SHIP_TO_LOCATION_CODE;
      V_LG_CONTRACT_ROW.SHIP_TO_LOCATION             := C_LG_SHIP_DOC.SHIP_TO_LOCATION;
      V_LG_CONTRACT_ROW.SHIP_INVENTORY_ID            := C_LG_SHIP_DOC.SHIP_INVENTORY_ID;
      V_LG_CONTRACT_ROW.SHIP_INVENTORY_CODE          := C_LG_SHIP_DOC.SHIP_INVENTORY_CODE;
      V_LG_CONTRACT_ROW.SHIP_INVENTORY_NAME          := C_LG_SHIP_DOC.SHIP_INVENTORY_NAME;
      V_LG_CONTRACT_ROW.CONSIGNEE_INVENTORY_ID       := C_LG_SHIP_DOC.CONSIGNEE_INVENTORY_ID;
      V_LG_CONTRACT_ROW.CONSIGNEE_INVENTORY_CODE     := C_LG_SHIP_DOC.CONSIGNEE_INVENTORY_CODE;
      V_LG_CONTRACT_ROW.CONSIGNEE_INVENTORY_NAME     := C_LG_SHIP_DOC.CONSIGNEE_INVENTORY_NAME;
      V_LG_CONTRACT_ROW.CONSIGNEE_ADDR               := C_LG_SHIP_DOC.CONSIGNEE_ADDR;
      V_LG_CONTRACT_ROW.CONSIGNEE_LOCATION_ID        := C_LG_SHIP_DOC.CONSIGNEE_LOCATION_ID;
      V_LG_CONTRACT_ROW.CONSIGNEE_LOCATION_CODE      := C_LG_SHIP_DOC.CONSIGNEE_LOCATION_CODE;
      V_LG_CONTRACT_ROW.CONSIGNEE_LOCATION           := C_LG_SHIP_DOC.CONSIGNEE_LOCATION;
      V_LG_CONTRACT_ROW.CONSIGNEE_COMPANY_ID         := C_LG_SHIP_DOC.CONSIGNEE_COMPANY_ID;
      V_LG_CONTRACT_ROW.CONSIGNEE_COMPANY_CODE       := C_LG_SHIP_DOC.CONSIGNEE_COMPANY_CODE;
      V_LG_CONTRACT_ROW.CONSIGNEE_COMPANY_NAME       := C_LG_SHIP_DOC.CONSIGNEE_COMPANY_NAME;
      V_LG_CONTRACT_ROW.CONSIGNEE_COMPANY_ADDR       := C_LG_SHIP_DOC.CONSIGNEE_COMPANY_ADDR;
      V_LG_CONTRACT_ROW.CONSIGNEE_COMPANY_CONTACT_ID := C_LG_SHIP_DOC.CONSIGNEE_COMPANY_CONTACT_ID;
      V_LG_CONTRACT_ROW.CONSIGNEE_COMPANY_CONTRACT   := C_LG_SHIP_DOC.CONSIGNEE_COMPANY_CONTRACT;
      V_LG_CONTRACT_ROW.CONSIGNEE_COMPANY_TEL        := C_LG_SHIP_DOC.CONSIGNEE_COMPANY_TEL;
      V_LG_CONTRACT_ROW.IS_CUSG_FLAG                 := C_LG_SHIP_DOC.IS_CUSG_FLAG; --是否直发
      --chenyj8 20180718 增肌直发客户信息
      V_LG_CONTRACT_ROW.TRANSFER_CUSTOMER_ID   := C_LG_SHIP_DOC.TRANSFER_CUSTOMER_ID;
      V_LG_CONTRACT_ROW.TRANSFER_CUSTOMER_CODE := C_LG_SHIP_DOC.TRANSFER_CUSTOMER_CODE;
      V_LG_CONTRACT_ROW.TRANSFER_CUSTOMER_NAME := C_LG_SHIP_DOC.TRANSFER_CUSTOMER_NAME;
      V_LG_CONTRACT_ROW.TRANSFER_ACCOUNT_ID    := C_LG_SHIP_DOC.TRANSFER_ACCOUNT_ID;
    
      --判断当前主体是推式还是拉式
      V_OU_MODE := PKG_BD.F_GET_PARAMETER_VALUE(P_CONFIG_CODE => 'getOUMode', --参数配置编码
                                                P_ENTITY_ID   => C_LG_SHIP_DOC.ENTITY_ID, --业务主体ID
                                                P_UNIT_ID     => NULL, --中心ID
                                                P_CUSTOMER_ID => NULL --客户ID
                                                );
    
      --判断推式拉式获取经营单位的方式
      BEGIN
        IF V_OU_MODE = 'PULL' THEN
          --拉式直接在CODELIST表中获取
          SELECT A.CODE_VALUE, A.CODE_NAME
            INTO V_LG_CONTRACT_ROW.OPERATING_UNIT,
                 V_LG_CONTRACT_ROW.SHIP_COMPANY
            FROM UP_CODELIST A
           WHERE A.CODETYPE = 'SO_OU_ID'
             AND A.CODE_VALUE =
                 (SELECT B.CODE_VALUE
                    FROM V_UP_CODELIST B
                   WHERE B.CODETYPE = 'SO_OU_ID'
                     AND B.ENTITY_ID = C_LG_SHIP_DOC.ENTITY_ID
                     AND ROWNUM = 1);
        
        ELSE
          --通过仓库获取
          /* SELECT OPERATING_UNIT_NAME, OPERATING_UNIT
           INTO V_LG_CONTRACT_ROW.SHIP_COMPANY,
                V_LG_CONTRACT_ROW.OPERATING_UNIT
           FROM T_INV_ORGANIZATION
          WHERE ORGANIZATION_ID =
                (SELECT ORGANIZATION_ID
                   FROM T_INV_INVENTORIES
                  WHERE INVENTORY_ID =
                        V_LG_CONTRACT_ROW.SHIP_INVENTORY_ID)
            AND ENTITY_ID = C_LG_SHIP_DOC.ENTITY_ID;*/
        
          --update tusj 2015.9.29
          SELECT A.OPERATING_UNIT_NAME, A.OPERATING_UNIT
            INTO V_LG_CONTRACT_ROW.SHIP_COMPANY,
                 V_LG_CONTRACT_ROW.OPERATING_UNIT
            FROM T_INV_ORGANIZATION A, T_INV_INVENTORIES B
           WHERE A.ORGANIZATION_ID = B.ORGANIZATION_ID
             AND A.ENTITY_ID = B.ENTITY_ID
             AND B.INVENTORY_ID = V_LG_CONTRACT_ROW.SHIP_INVENTORY_ID
             AND A.ENTITY_ID = C_LG_SHIP_DOC.ENTITY_ID;
          --end tusj 2015.9.29
        END IF;
      
      EXCEPTION
        WHEN OTHERS THEN
          O_RESULT     := '2001';
          O_RESULT_MSG := '经营单位信息不存在！';
          RETURN;
      END;
    
      V_LG_CONTRACT_ROW.REQUIRE_SHIP_DATE   := C_LG_SHIP_DOC.REQUIRE_SHIP_DATE; --多个发货通知单发货时间可能不一致
      V_LG_CONTRACT_ROW.FACT_SHIP_DATE      := V_LG_SHIP_ROW.SHIP_DATE;
      V_LG_CONTRACT_ROW.REQUIRE_ARRIVE_DATE := C_LG_SHIP_DOC.REQUIRE_ARRIVE_DATE; --多个发货通知单发货时间可能不一致
      V_LG_CONTRACT_ROW.FACT_ARRIVE_DATE    := NULL;
      V_LG_CONTRACT_ROW.DROP_SHIP_FLAG      := NULL; --暂时保留
      V_LG_CONTRACT_ROW.DISTANCE            := C_LG_SHIP_DOC.DISTANCE;
      V_LG_CONTRACT_ROW.FREIGHT             := 0; --后面汇总计算
      V_LG_CONTRACT_ROW.TAX_AMOUNT          := 0; --后面汇总计算
    
      --获取经营单位
      --BEGIN
      --SELECT T.OPERATING_UNIT
      --INTO V_LG_CONTRACT_ROW.OPERATING_UNIT
      --FROM T_INV_ORGANIZATION T
      --WHERE ORGANIZATION_ID =
      --(SELECT ORGANIZATION_ID
      --FROM T_INV_INVENTORIES
      --WHERE INVENTORY_ID = V_LG_CONTRACT_ROW.SHIP_INVENTORY_ID);
      --EXCEPTION
      --WHEN OTHERS THEN
      --NULL;
      --END;
    
      V_LG_CONTRACT_ROW.TAX_RATE              := NVL(V_TAX_RATE, 0); --运费税率
      V_LG_CONTRACT_ROW.FREIGHT_NO_TAX        := 0; --后面汇总计算
      V_LG_CONTRACT_ROW.ORIGIN_SHIP_CHARGES   := 0; --后面汇总计算
      V_LG_CONTRACT_ROW.ADJUST_SHIP_CHARGES   := 0; --重新计算时填写
      V_LG_CONTRACT_ROW.FREIGHT_ADJUST_REASON := NULL;
      V_LG_CONTRACT_ROW.PRICE_UNIT            := V_LG_LINE_FREIGHT_STANDARD.PRICE_UNIT;
      V_LG_CONTRACT_ROW.TOTAL_VOLUME          := 0; --后面汇总计算
      V_LG_CONTRACT_ROW.TOTAL_WEIGHT          := 0; --后面汇总计算
      V_LG_CONTRACT_ROW.TOTAL_AMOUNT          := 0; --后面汇总计算
      V_LG_CONTRACT_ROW.WEIGHT_UNIT           := 'KG'; --系统默认
      V_LG_CONTRACT_ROW.VOL_UNIT              := '方'; --系统默认
      V_LG_CONTRACT_ROW.PRINT_FLAG            := 'N';
      V_LG_CONTRACT_ROW.PRINT_TIMES           := 0;
      V_LG_CONTRACT_ROW.PRINT_DATE            := NULL;
      V_LG_CONTRACT_ROW.RECEIVE_FLAG          := 'N';
      V_LG_CONTRACT_ROW.RECEIVE_DATE          := NULL;
      V_LG_CONTRACT_ROW.RECEIVE_BY_NAME       := NULL;
      V_LG_CONTRACT_ROW.BACK_FLAG             := 'N';
      V_LG_CONTRACT_ROW.BACK_DATE             := NULL;
      V_LG_CONTRACT_ROW.LOCK_FLAG             := 'N';
      V_LG_CONTRACT_ROW.JUDGEMAR_CODE         := NULL;
      V_LG_CONTRACT_ROW.INSURANCE_FLAG        := 'Y'; --默认购买保险
      V_LG_CONTRACT_ROW.INSURACE_ID           := V_LG_INSURANCE_ROW.INSURER_ID; --命名不一致
    
      --获取保险商CODE和NAME
      BEGIN
        SELECT VENDOR_CODE, VENDOR_NAME
          INTO V_LG_CONTRACT_ROW.INSURACE_CODE,
               V_LG_CONTRACT_ROW.INSURACE_NAME
          FROM T_LG_VENDOR_INFO_HEAD
         WHERE VENDOR_ID = V_LG_CONTRACT_ROW.INSURACE_ID;
      EXCEPTION
        WHEN OTHERS THEN
          NULL;
      END;
    
      V_LG_CONTRACT_ROW.RISK_AMOUNT            := 0; --投保金额 后面汇总计算
      V_LG_CONTRACT_ROW.INSURANCE              := 0; --保险费 后面汇总计算
      V_LG_CONTRACT_ROW.COMPENSATION_AMOUNT    := NULL;
      V_LG_CONTRACT_ROW.COMPENSATION_REASON    := NULL;
      V_LG_CONTRACT_ROW.COMPENSATION_DATE      := NULL;
      V_LG_CONTRACT_ROW.CLAIM_VENDOR_CODE      := NULL;
      V_LG_CONTRACT_ROW.CLAIM_VENDOR_NAME      := NULL;
      V_LG_CONTRACT_ROW.BREAK_CLAIMANT_AMOUNT  := NULL;
      V_LG_CONTRACT_ROW.BREAK_CLAIMANT_REASON  := NULL;
      V_LG_CONTRACT_ROW.BREAK_CLAIMANT_DATE    := NULL;
      V_LG_CONTRACT_ROW.DAMAGE_CLAIMANT_AMOUNT := NULL;
      V_LG_CONTRACT_ROW.DAMAGE_CLAIMANT_REASON := NULL;
      V_LG_CONTRACT_ROW.DAMAGE_CLAIMANT_DATE   := NULL;
      V_LG_CONTRACT_ROW.BREAK_CLAIM_DATE       := NULL;
      V_LG_CONTRACT_ROW.DAMAGE_CLAIM_DATE      := NULL;
      V_LG_CONTRACT_ROW.DAMAGE_INC_DEC_CODE    := NULL;
      V_LG_CONTRACT_ROW.BREAK_INC_DEC_CODE     := NULL;
      V_LG_CONTRACT_ROW.CONTRACT_TYPE          := '00';
      V_LG_CONTRACT_ROW.ORIGIN_CONTRACT_CODE   := NULL;
      V_LG_CONTRACT_ROW.FREIGHT_BATCH_FLAG     := NULL;
      V_LG_CONTRACT_ROW.INSUANCE_BATCH_FLAG    := NULL;
      V_LG_CONTRACT_ROW.FREIGHT_BATCH_NUM      := NULL;
      V_LG_CONTRACT_ROW.INSURANCE_BATCH_NUM    := NULL;
      V_LG_CONTRACT_ROW.SEND_FLAG              := NULL;
      V_LG_CONTRACT_ROW.VENDOR_FLAG            := NULL;
      V_LG_CONTRACT_ROW.VENDOR_ERROR_MESSAGE   := NULL;
      V_LG_CONTRACT_ROW.IMPORT_VENDOR_TIME     := NULL;
      V_LG_CONTRACT_ROW.CONTRACT_DATE          := SYSDATE;
      V_LG_CONTRACT_ROW.REG_CARRIAGE_FLAG      := 'N';
      V_LG_CONTRACT_ROW.REG_INSURANCE_FLAG     := 'N';
      V_LG_CONTRACT_ROW.PROMOTION_PRODUCT_VOL  := NULL; --暂时保留
      V_LG_CONTRACT_ROW.CREATED_BY             := 'LG';
      V_LG_CONTRACT_ROW.CREATION_DATE          := SYSDATE;
      V_LG_CONTRACT_ROW.LAST_UPDATED_BY        := 'LG';
      V_LG_CONTRACT_ROW.LAST_UPDATE_DATE       := SYSDATE;
      V_LG_CONTRACT_ROW.REMARK                 := NULL;
    
      V_LG_CONTRACT(V_LG_CONTRACT.COUNT + 1) := V_LG_CONTRACT_ROW;
    
    END IF;
    --遍历发货接口行
    FOR C_LG_SHIP_DOC_LINE IN (SELECT *
                                 FROM INTF_LG_SHIP_LINE
                                WHERE SHIP_DOC_ID =
                                      C_LG_SHIP_DOC.SHIP_DOC_ID
                                  AND SHIP_INTERFACE_ID =
                                      (SELECT SHIP_INTERFACE_ID
                                         FROM INTF_LG_SHIP
                                        WHERE VEHICLE_NUM = I_VEHICLE_NUM)) LOOP
      --查询发货通知单行相关信息
      SELECT *
        INTO V_LG_SHIP_DOC_LINE
        FROM T_LG_SHIP_DOC_LINE
       WHERE SHIP_DOC_LINE_ID = C_LG_SHIP_DOC_LINE.SHIP_DOC_LINE_ID;
    
      --构建排车信息行表
      V_LG_VEHICLE_INFO_LINE_ROW.VEHICLE_INFO_LINE_ID := S_LG_VEHICLE_INFO_LINE.NEXTVAL;
      V_LG_VEHICLE_INFO_LINE_ROW.VEHICLE_INFO_ID      := V_LG_VEHICLE_INFO_ROW.VEHICLE_INFO_ID;
      V_LG_VEHICLE_INFO_LINE_ROW.SHIP_DOC_LINE_ID     := C_LG_SHIP_DOC_LINE.SHIP_DOC_LINE_ID;
      V_LG_VEHICLE_INFO_LINE_ROW.SHIP_DOC_ID          := C_LG_SHIP_DOC_LINE.SHIP_DOC_ID;
      V_LG_VEHICLE_INFO_LINE_ROW.ORIGIN_TYPE          := V_LG_SHIP_DOC_LINE.ORIGIN_TYPE;
      V_LG_VEHICLE_INFO_LINE_ROW.ORIGIN_ORDER_NUM     := V_LG_SHIP_DOC_LINE.ORIGIN_ORDER_NUM;
      V_LG_VEHICLE_INFO_LINE_ROW.ORIGIN_ORDER_ID      := V_LG_SHIP_DOC_LINE.ORIGIN_ORDER_ID;
      V_LG_VEHICLE_INFO_LINE_ROW.ORIGIN_LINE_ID       := V_LG_SHIP_DOC_LINE.ORIGIN_LINE_ID;
      V_LG_VEHICLE_INFO_LINE_ROW.CONTRACT_CODE        := V_LG_CONTRACT_ROW.CONTRACT_CODE;
      V_LG_VEHICLE_INFO_LINE_ROW.ITEM_CODE            := V_LG_SHIP_DOC_LINE.ITEM_CODE;
      V_LG_VEHICLE_INFO_LINE_ROW.ITEM_NAME            := V_LG_SHIP_DOC_LINE.ITEM_DESC;
      V_LG_VEHICLE_INFO_LINE_ROW.ITEM_QTY             := C_LG_SHIP_DOC_LINE.ITEM_QTY;
      V_LG_VEHICLE_INFO_LINE_ROW.CREATED_BY           := 'LG';
      V_LG_VEHICLE_INFO_LINE_ROW.CREATION_DATE        := SYSDATE;
      V_LG_VEHICLE_INFO_LINE_ROW.LAST_UPDATED_BY      := 'LG';
      V_LG_VEHICLE_INFO_LINE_ROW.LAST_UPDATE_DATE     := SYSDATE;
    
      V_LG_VEHICLE_INFO_LINE(V_LG_VEHICLE_INFO_LINE.COUNT + 1) := V_LG_VEHICLE_INFO_LINE_ROW;
    
      --获取销售单据类型
      BEGIN
        SELECT A.SOURCE_TYPE_CODE
          INTO V_SOURCE_TYPE_CODE
          FROM T_INV_SOURCE_TYPES A
         WHERE A.SOURCE_TYPE_ID =
               (SELECT B.SOURCE_TYPE_ID
                  FROM T_INV_BILL_TYPES B
                 WHERE B.BILL_TYPE_ID =
                       V_LG_SHIP_DOC_LINE.SALES_ORDER_TYPE_ID);
      EXCEPTION
        WHEN OTHERS THEN
          NULL;
      END;
      --记录LMS发货时间
      V_LG_CONTRACT_LINE_ROW.SHIP_DATE := C_LG_SHIP_DOC_LINE.SHIP_DATE;
    
      -----------------------------------------------------------------------------------------------
      --add by liyuanji 支持提货订单多单据类型
    
      IF V_LG_SHIP_DOC_LINE.ORIGIN_TYPE = '02' THEN
      
        SELECT B.ORDER_LG_TYPE
          INTO V_ORDER_LG_TYPE
          FROM T_PLN_LG_ORDER_HEAD A, T_PLN_ORDER_TYPE B
         WHERE A.ORDER_NUMBER = V_LG_SHIP_DOC_LINE.ORIGIN_ORDER_NUM
           AND A.ORDER_TYPE_ID = B.ORDER_TYPE_ID;
      
      END IF;
      -----------------------------------------------------------------------------------------------
    
      --推广物料 不包括套件
      IF V_SOURCE_TYPE_CODE = '1009' AND
         (V_ORDER_LG_TYPE IS NULL OR V_ORDER_LG_TYPE = '02' OR
         V_ORDER_LG_TYPE = '03') THEN
      
        --构建运输合同行
        V_LG_CONTRACT_LINE_ROW.CONTRACT_LINE_ID    := S_LG_CONTRACT_LINE.NEXTVAL;
        V_LG_CONTRACT_LINE_ROW.CONTRACT_ID         := V_LG_CONTRACT_ROW.CONTRACT_ID;
        V_LG_CONTRACT_LINE_ROW.SALES_MAIN_TYPE     := V_LG_SHIP_DOC_LINE.SALES_MAIN_TYPE;
        V_LG_CONTRACT_LINE_ROW.SALES_SUB_TYPE      := V_LG_SHIP_DOC_LINE.SALES_SUB_TYPE; --营销小类
        V_LG_CONTRACT_LINE_ROW.SALES_ORDER_TYPE_ID := V_LG_SHIP_DOC_LINE.SALES_ORDER_TYPE_ID;
        V_LG_CONTRACT_LINE_ROW.SO_DOC_ID           := NULL; --财务单ID 推广物料为空
        V_LG_CONTRACT_LINE_ROW.SO_DOC_NUM          := NULL; --财务单编码 推广物料为空
        V_LG_CONTRACT_LINE_ROW.ITEM_CODE           := V_LG_SHIP_DOC_LINE.ITEM_CODE;
        --V_LG_CONTRACT_LINE_ROW.ITEM_NAME           := V_LG_SHIP_DOC_LINE.ITEM_DESC;
        --重新获取产品描述
        BEGIN
          SELECT T.ITEM_NAME
            INTO V_LG_CONTRACT_LINE_ROW.ITEM_NAME
            FROM T_BD_ITEM T
           WHERE T.ITEM_CODE = V_LG_SHIP_DOC_LINE.ITEM_CODE
             AND T.ENTITY_ID = C_LG_SHIP_DOC.ENTITY_ID;
        EXCEPTION
          WHEN OTHERS THEN
            V_LG_CONTRACT_LINE_ROW.ITEM_NAME := V_LG_SHIP_DOC_LINE.ITEM_DESC;
        END;
        V_LG_CONTRACT_LINE_ROW.ITEM_UOM      := V_LG_SHIP_DOC_LINE.ITEM_UOM;
        V_LG_CONTRACT_LINE_ROW.ITEM_PRICE    := V_LG_SHIP_DOC_LINE.ITEM_PRICE;
        V_LG_CONTRACT_LINE_ROW.FACT_SHIP_QTY := C_LG_SHIP_DOC_LINE.ITEM_QTY;
        V_LG_CONTRACT_LINE_ROW.UNIT_VOLUME   := V_LG_SHIP_DOC_LINE.UNIT_VOLUME;
        V_LG_CONTRACT_LINE_ROW.UNIT_WEIGHT   := V_LG_SHIP_DOC_LINE.UNIT_WEIGHT;
        V_LG_CONTRACT_LINE_ROW.AMOUNT        := V_LG_CONTRACT_LINE_ROW.ITEM_PRICE *
                                                V_LG_CONTRACT_LINE_ROW.FACT_SHIP_QTY;
        V_LG_CONTRACT_LINE_ROW.TOTAL_VOLUME  := NVL(V_LG_CONTRACT_LINE_ROW.UNIT_VOLUME *
                                                    V_LG_CONTRACT_LINE_ROW.FACT_SHIP_QTY,
                                                    0);
        V_LG_CONTRACT_LINE_ROW.TOTAL_WEIGHT  := NVL(V_LG_CONTRACT_LINE_ROW.UNIT_WEIGHT *
                                                    V_LG_CONTRACT_LINE_ROW.FACT_SHIP_QTY,
                                                    0);
        V_LG_CONTRACT_LINE_ROW.SET_FLAG      := V_LG_SHIP_DOC_LINE.SET_FLAG;
        V_LG_CONTRACT_LINE_ROW.SET_CODE      := NULL;
      
        --计算运费
        IF V_LG_LINE_FREIGHT_STANDARD.PRICE_UNIT = '00' THEN
          --按体积计算
          V_LG_CONTRACT_LINE_ROW.FREIGHT := ROUND(NVL(V_LG_CONTRACT_LINE_ROW.TOTAL_VOLUME *
                                                      V_LG_LINE_FREIGHT_STANDARD.UNIT_PRICE_OF_FREIGHT,
                                                      0),
                                                  2);
        ELSIF V_LG_LINE_FREIGHT_STANDARD.PRICE_UNIT = '01' THEN
          --按重量计算
          V_LG_CONTRACT_LINE_ROW.FREIGHT := ROUND(NVL(V_LG_CONTRACT_LINE_ROW.TOTAL_WEIGHT *
                                                      V_LG_LINE_FREIGHT_STANDARD.UNIT_PRICE_OF_FREIGHT,
                                                      0),
                                                  2);
        ELSE
          V_LG_CONTRACT_LINE_ROW.FREIGHT := 0;
        END IF;
      
        BEGIN
          --查询保费列表价格
          SELECT LIST_PRICE
            INTO V_LIST_PRICE
            FROM T_BD_PRICE_LINE
           WHERE ITEM_CODE = V_LG_CONTRACT_LINE_ROW.ITEM_CODE
             AND PRICE_LIST_ID = V_LG_INSURANCE_ROW.PRICE_LIST_ID
             AND ENTITY_ID = C_LG_SHIP_DOC.ENTITY_ID;
        EXCEPTION
          WHEN OTHERS THEN
            NULL;
        END;
        --计算保费 列表价格*税率
        V_LG_CONTRACT_LINE_ROW.INSURANCE := ROUND(V_LG_CONTRACT_LINE_ROW.FACT_SHIP_QTY *
                                                  V_LIST_PRICE *
                                                  V_LG_INSURANCE_ROW.INSURANCE_RATE / 100,
                                                  2);
        --计算投保金额
        V_LG_CONTRACT_LINE_ROW.RISK_AMOUNT            := ROUND(V_LG_CONTRACT_LINE_ROW.FACT_SHIP_QTY *
                                                               NVL(V_LIST_PRICE,
                                                                   0),
                                                               2);
        V_LG_CONTRACT_LINE_ROW.FACT_RECEIVE_QTY       := NULL;
        V_LG_CONTRACT_LINE_ROW.AFFIRM_QTY             := NULL;
        V_LG_CONTRACT_LINE_ROW.SHATTER_QTY            := 0;
        V_LG_CONTRACT_LINE_ROW.DIFF_QTY               := 0;
        V_LG_CONTRACT_LINE_ROW.MOULD_QTY              := 0;
        V_LG_CONTRACT_LINE_ROW.OUT_LINE_QTY           := 0;
        V_LG_CONTRACT_LINE_ROW.PACK_SHATTER_QTY       := 0;
        V_LG_CONTRACT_LINE_ROW.DIFF_REASON            := NULL;
        V_LG_CONTRACT_LINE_ROW.DAMAGE_CLAIMANT_AMOUNT := 0;
        V_LG_CONTRACT_LINE_ROW.BREAK_CLAIMANT_AMOUNT  := 0;
        V_LG_CONTRACT_LINE_ROW.ORIGIN_ORIGIN_TYPE     := V_LG_SHIP_DOC_LINE.ORIGIN_ORIGIN_TYPE;
        V_LG_CONTRACT_LINE_ROW.ORIGIN_ORIGIN_DOC_CODE := V_LG_SHIP_DOC_LINE.ORIGIN_ORIGIN_DOC_CODE;
        V_LG_CONTRACT_LINE_ROW.ORIGIN_ORIGIN_HEAD_ID  := V_LG_SHIP_DOC_LINE.ORIGIN_ORIGIN_HEAD_ID;
        V_LG_CONTRACT_LINE_ROW.ORIGIN_ORIGIN_LINE_ID  := V_LG_SHIP_DOC_LINE.ORIGIN_ORIGIN_LINE_ID;
        V_LG_CONTRACT_LINE_ROW.ORIGIN_TYPE            := V_LG_SHIP_DOC_LINE.ORIGIN_TYPE;
        V_LG_CONTRACT_LINE_ROW.ORIGIN_ORDER_ID        := V_LG_SHIP_DOC_LINE.ORIGIN_ORDER_ID;
        V_LG_CONTRACT_LINE_ROW.ORIGIN_LINE_ID         := V_LG_SHIP_DOC_LINE.ORIGIN_LINE_ID;
        V_LG_CONTRACT_LINE_ROW.ORIGIN_ORDER_NUM       := V_LG_SHIP_DOC_LINE.ORIGIN_ORDER_NUM;
        V_LG_CONTRACT_LINE_ROW.INVENTORY_CODE         := ''; --暂时保留
        V_LG_CONTRACT_LINE_ROW.INVENTORY_NAME         := ''; --暂时保留
        V_LG_CONTRACT_LINE_ROW.CREATED_BY             := 'LG';
        V_LG_CONTRACT_LINE_ROW.CREATION_DATE          := SYSDATE;
        V_LG_CONTRACT_LINE_ROW.LAST_UPDATED_BY        := 'LG';
        V_LG_CONTRACT_LINE_ROW.LAST_UPDATE_DATE       := SYSDATE;
        V_LG_CONTRACT_LINE_ROW.REMARK                 := NULL;
        V_LG_CONTRACT_LINE_ROW.CUSTOMER_ORDER_NUMBER  := C_LG_SHIP_DOC.CUSTOMER_ORDER_NUMBER; --客户订单号
        V_LG_CONTRACT_LINE_ROW.SHIP_DOC_LINE_ID       := V_LG_SHIP_DOC_LINE.SHIP_DOC_LINE_ID; --发货通知单行ID
        V_LG_CONTRACT_LINE_ROW.PROJECT_ORDER_TYPE     := V_LG_SHIP_DOC_LINE.PROJECT_ORDER_TYPE; --批文类型
        V_LG_CONTRACT_LINE_ROW.PROJECT_ORDER_NUMBER   := V_LG_SHIP_DOC_LINE.PROJECT_ORDER_NUMBER; --批文号
        V_LG_CONTRACT_LINE_ROW.PROJECT_ORDER_HEAD_ID  := V_LG_SHIP_DOC_LINE.PROJECT_ORDER_HEAD_ID; --批文头ID
        V_LG_CONTRACT_LINE_ROW.PROJECT_ORDER_LINE_ID  := V_LG_SHIP_DOC_LINE.PROJECT_ORDER_LINE_ID; --批文行ID
        V_LG_CONTRACT_LINE_ROW.APPLY_LIST_PRICE       := V_LG_SHIP_DOC_LINE.APPLY_LIST_PRICE; --申请价（工程机批文价格）
        V_LG_CONTRACT_LINE_ROW.APPLY_DISCOUNT_RATE    := V_LG_SHIP_DOC_LINE.APPLY_DISCOUNT_RATE; --申请折扣（工程机批文折扣）
        V_LG_CONTRACT_LINE_ROW.PROJECT_ORDER_FLAG     := V_LG_SHIP_DOC_LINE.PROJECT_ORDER_FLAG; --是否工程机
        --chenyj8 20170410 增加CCS订单号
        V_LG_CONTRACT_LINE_ROW.SYS_SOURCE_ORDER_NUM := V_LG_SHIP_DOC_LINE.SYS_SOURCE_ORDER_NUM; --CCS订单号
        V_LG_CONTRACT_LINE_ROW.DISTRIBUTE_MODE := C_LG_SHIP_DOC.DISTRIBUTE_MODE;--代销单配送方式
        V_LG_CONTRACT_LINE_ROW.CUSTOMER_CHANNEL_TYPE := C_LG_SHIP_DOC.CUSTOMER_CHANNEL_TYPE;--经营渠道类型
        
        
        V_LG_CONTRACT_LINE(V_LG_CONTRACT_LINE.COUNT + 1) := V_LG_CONTRACT_LINE_ROW;
      
        --销售或调拨
      ELSE
      
        --销售
        IF (V_SOURCE_TYPE_CODE = '1006') THEN
          V_SOURCE_TYPE_CODE := '00';
          --调拨
        ELSIF (V_SOURCE_TYPE_CODE = '1008') THEN
          V_SOURCE_TYPE_CODE := '01';
          --备货
        ELSIF (V_SOURCE_TYPE_CODE = '1005') THEN
          V_SOURCE_TYPE_CODE := '02';
        ELSE
          O_RESULT     := '1001';
          O_RESULT_MSG := '销售单类型错误';
          RETURN;
        END IF;
      
        --通过发货通知单行ID查询财务单或调拨单
        FOR C_SO_LG_SHIPDOC IN (SELECT *
                                  FROM (SELECT A.*
                                          FROM V_SO_LG_SHIPDOC A
                                         WHERE A.SHIP_DOC_LINE_ID =
                                               C_LG_SHIP_DOC_LINE.SHIP_DOC_LINE_ID
                                           AND A.VEHICLE_NUM = I_VEHICLE_NUM
                                        UNION
                                        SELECT B.*
                                          FROM V_INV_LG_SHIPDOC B
                                         WHERE B.SHIP_DOC_LINE_ID =
                                               C_LG_SHIP_DOC_LINE.SHIP_DOC_LINE_ID
                                           AND B.VEHICLE_NUM = I_VEHICLE_NUM)
                                 WHERE BILL_TYPE = V_SOURCE_TYPE_CODE) LOOP
        
          IF V_LG_SHIP_DOC_LINE.SET_FLAG = 'Y' THEN
            --拆分套件到散件
            FOR C_BD_ITEM_ASSEMBLIES_SUB IN (SELECT ITEM_CODE,
                                                    ITEM_NAME,
                                                    QUANTITY
                                               FROM T_BD_ITEM_ASSEMBLIES_SUB
                                              WHERE ITEM_ASSEMBLY_ID =
                                                    (SELECT ITEM_ASSEMBLY_ID
                                                       FROM T_BD_ITEM_ASSEMBLIES
                                                      WHERE ITEM_CODE =
                                                            V_LG_SHIP_DOC_LINE.ITEM_CODE
                                                        AND ENTITY_ID =
                                                            C_LG_SHIP_DOC.ENTITY_ID)
                                                AND ENTITY_ID =
                                                    C_LG_SHIP_DOC.ENTITY_ID) LOOP
              --构建运输合同行
              V_LG_CONTRACT_LINE_ROW.CONTRACT_LINE_ID    := S_LG_CONTRACT_LINE.NEXTVAL;
              V_LG_CONTRACT_LINE_ROW.CONTRACT_ID         := V_LG_CONTRACT_ROW.CONTRACT_ID;
              V_LG_CONTRACT_LINE_ROW.SALES_MAIN_TYPE     := V_LG_SHIP_DOC_LINE.SALES_MAIN_TYPE;
              V_LG_CONTRACT_LINE_ROW.SALES_SUB_TYPE      := V_LG_SHIP_DOC_LINE.SALES_SUB_TYPE; --营销小类
              V_LG_CONTRACT_LINE_ROW.SALES_ORDER_TYPE_ID := V_LG_SHIP_DOC_LINE.SALES_ORDER_TYPE_ID;
              V_LG_CONTRACT_LINE_ROW.SO_DOC_ID           := C_SO_LG_SHIPDOC.SO_HEADER_ID;
              V_LG_CONTRACT_LINE_ROW.SO_DOC_NUM          := C_SO_LG_SHIPDOC.SO_NUM;
              V_LG_CONTRACT_LINE_ROW.ITEM_CODE           := C_BD_ITEM_ASSEMBLIES_SUB.ITEM_CODE;
              V_LG_CONTRACT_LINE_ROW.ITEM_NAME           := C_BD_ITEM_ASSEMBLIES_SUB.ITEM_NAME;
              --chenyj8 20170410 增加CCS订单号
              V_LG_CONTRACT_LINE_ROW.SYS_SOURCE_ORDER_NUM := V_LG_SHIP_DOC_LINE.SYS_SOURCE_ORDER_NUM; --CCS订单号
              V_LG_CONTRACT_LINE_ROW.DISTRIBUTE_MODE := C_LG_SHIP_DOC.DISTRIBUTE_MODE;--代销单配送方式
              V_LG_CONTRACT_LINE_ROW.CUSTOMER_CHANNEL_TYPE := C_LG_SHIP_DOC.CUSTOMER_CHANNEL_TYPE;--经营渠道类型
              --查询产品单位、重量、体积
              BEGIN
                SELECT DEFAULTUNIT, GROSSWEIGHT, PACKINGSIZE
                  INTO V_LG_CONTRACT_LINE_ROW.ITEM_UOM,
                       V_LG_CONTRACT_LINE_ROW.UNIT_WEIGHT,
                       V_LG_CONTRACT_LINE_ROW.UNIT_VOLUME
                  FROM T_BD_ITEM
                 WHERE ITEM_CODE = C_BD_ITEM_ASSEMBLIES_SUB.ITEM_CODE
                   AND ENTITY_ID = C_LG_SHIP_DOC.ENTITY_ID;
              EXCEPTION
                WHEN OTHERS THEN
                  NULL;
              END;
            
              V_LG_CONTRACT_LINE_ROW.ITEM_PRICE := V_LG_SHIP_DOC_LINE.ITEM_PRICE; --在基础模块获取（熊培良确认）
            
              --实发数量 = 散件数量 * 产品数量
              V_LG_CONTRACT_LINE_ROW.FACT_SHIP_QTY := C_BD_ITEM_ASSEMBLIES_SUB.QUANTITY *
                                                      C_SO_LG_SHIPDOC.ITEM_QTY;
              V_LG_CONTRACT_LINE_ROW.AMOUNT        := V_LG_CONTRACT_LINE_ROW.ITEM_PRICE *
                                                      V_LG_CONTRACT_LINE_ROW.FACT_SHIP_QTY;
              V_LG_CONTRACT_LINE_ROW.TOTAL_VOLUME  := NVL(V_LG_CONTRACT_LINE_ROW.UNIT_VOLUME *
                                                          V_LG_CONTRACT_LINE_ROW.FACT_SHIP_QTY,
                                                          0);
              V_LG_CONTRACT_LINE_ROW.TOTAL_WEIGHT  := NVL(V_LG_CONTRACT_LINE_ROW.UNIT_WEIGHT *
                                                          V_LG_CONTRACT_LINE_ROW.FACT_SHIP_QTY,
                                                          0);
              V_LG_CONTRACT_LINE_ROW.SET_FLAG      := V_LG_SHIP_DOC_LINE.SET_FLAG;
              V_LG_CONTRACT_LINE_ROW.SET_CODE      := V_LG_SHIP_DOC_LINE.ITEM_CODE;
            
              --计算运费
              IF V_LG_LINE_FREIGHT_STANDARD.PRICE_UNIT = '00' THEN
                --按体积计算
                V_LG_CONTRACT_LINE_ROW.FREIGHT := ROUND(NVL(V_LG_CONTRACT_LINE_ROW.TOTAL_VOLUME *
                                                            V_LG_LINE_FREIGHT_STANDARD.UNIT_PRICE_OF_FREIGHT,
                                                            0),
                                                        2);
              ELSIF V_LG_LINE_FREIGHT_STANDARD.PRICE_UNIT = '01' THEN
                --按重量计算
                V_LG_CONTRACT_LINE_ROW.FREIGHT := ROUND(NVL(V_LG_CONTRACT_LINE_ROW.TOTAL_WEIGHT *
                                                            V_LG_LINE_FREIGHT_STANDARD.UNIT_PRICE_OF_FREIGHT,
                                                            0),
                                                        2);
              ELSE
                V_LG_CONTRACT_LINE_ROW.FREIGHT := 0;
              END IF;
            
              BEGIN
                --查询列表价格
                SELECT LIST_PRICE
                  INTO V_LIST_PRICE
                  FROM T_BD_PRICE_LINE
                 WHERE ITEM_CODE = V_LG_CONTRACT_LINE_ROW.ITEM_CODE
                   AND PRICE_LIST_ID = V_LG_INSURANCE_ROW.PRICE_LIST_ID
                   AND ENTITY_ID = C_LG_SHIP_DOC.ENTITY_ID;
              EXCEPTION
                WHEN OTHERS THEN
                  NULL;
              END;
              --计算保费 实发数量*列表价格*税率
              V_LG_CONTRACT_LINE_ROW.INSURANCE := ROUND(V_LG_CONTRACT_LINE_ROW.FACT_SHIP_QTY *
                                                        V_LIST_PRICE *
                                                        V_LG_INSURANCE_ROW.INSURANCE_RATE / 100,
                                                        2);
            
              --计算投保金额
              V_LG_CONTRACT_LINE_ROW.RISK_AMOUNT            := ROUND(V_LG_CONTRACT_LINE_ROW.FACT_SHIP_QTY *
                                                                     NVL(V_LIST_PRICE,
                                                                         0),
                                                                     2);
              V_LG_CONTRACT_LINE_ROW.FACT_RECEIVE_QTY       := NULL;
              V_LG_CONTRACT_LINE_ROW.AFFIRM_QTY             := NULL;
              V_LG_CONTRACT_LINE_ROW.SHATTER_QTY            := 0;
              V_LG_CONTRACT_LINE_ROW.DIFF_QTY               := 0;
              V_LG_CONTRACT_LINE_ROW.MOULD_QTY              := 0;
              V_LG_CONTRACT_LINE_ROW.OUT_LINE_QTY           := 0;
              V_LG_CONTRACT_LINE_ROW.PACK_SHATTER_QTY       := 0;
              V_LG_CONTRACT_LINE_ROW.DIFF_REASON            := NULL;
              V_LG_CONTRACT_LINE_ROW.DAMAGE_CLAIMANT_AMOUNT := 0;
              V_LG_CONTRACT_LINE_ROW.BREAK_CLAIMANT_AMOUNT  := 0;
              V_LG_CONTRACT_LINE_ROW.ORIGIN_ORIGIN_TYPE     := V_LG_SHIP_DOC_LINE.ORIGIN_ORIGIN_TYPE;
              V_LG_CONTRACT_LINE_ROW.ORIGIN_ORIGIN_DOC_CODE := V_LG_SHIP_DOC_LINE.ORIGIN_ORIGIN_DOC_CODE;
              V_LG_CONTRACT_LINE_ROW.ORIGIN_ORIGIN_HEAD_ID  := V_LG_SHIP_DOC_LINE.ORIGIN_ORIGIN_HEAD_ID;
              V_LG_CONTRACT_LINE_ROW.ORIGIN_ORIGIN_LINE_ID  := V_LG_SHIP_DOC_LINE.ORIGIN_ORIGIN_LINE_ID;
              V_LG_CONTRACT_LINE_ROW.ORIGIN_TYPE            := V_LG_SHIP_DOC_LINE.ORIGIN_TYPE;
              V_LG_CONTRACT_LINE_ROW.ORIGIN_ORDER_ID        := V_LG_SHIP_DOC_LINE.ORIGIN_ORDER_ID;
              V_LG_CONTRACT_LINE_ROW.ORIGIN_LINE_ID         := V_LG_SHIP_DOC_LINE.ORIGIN_LINE_ID;
              V_LG_CONTRACT_LINE_ROW.ORIGIN_ORDER_NUM       := V_LG_SHIP_DOC_LINE.ORIGIN_ORDER_NUM;
              V_LG_CONTRACT_LINE_ROW.INVENTORY_CODE         := ''; --暂时保留
              V_LG_CONTRACT_LINE_ROW.INVENTORY_NAME         := ''; --暂时保留
              V_LG_CONTRACT_LINE_ROW.CREATED_BY             := 'LG';
              V_LG_CONTRACT_LINE_ROW.CREATION_DATE          := SYSDATE;
              V_LG_CONTRACT_LINE_ROW.LAST_UPDATED_BY        := 'LG';
              V_LG_CONTRACT_LINE_ROW.LAST_UPDATE_DATE       := SYSDATE;
              V_LG_CONTRACT_LINE_ROW.REMARK                 := NULL;
              V_LG_CONTRACT_LINE_ROW.CUSTOMER_ORDER_NUMBER  := C_LG_SHIP_DOC.CUSTOMER_ORDER_NUMBER; --客户订单号
              V_LG_CONTRACT_LINE_ROW.SHIP_DOC_LINE_ID       := V_LG_SHIP_DOC_LINE.SHIP_DOC_LINE_ID; --发货通知单行ID
              V_LG_CONTRACT_LINE_ROW.PROJECT_ORDER_TYPE     := V_LG_SHIP_DOC_LINE.PROJECT_ORDER_TYPE; --批文类型
              V_LG_CONTRACT_LINE_ROW.PROJECT_ORDER_NUMBER   := V_LG_SHIP_DOC_LINE.PROJECT_ORDER_NUMBER; --批文号
              V_LG_CONTRACT_LINE_ROW.PROJECT_ORDER_HEAD_ID  := V_LG_SHIP_DOC_LINE.PROJECT_ORDER_HEAD_ID; --批文头ID
              V_LG_CONTRACT_LINE_ROW.PROJECT_ORDER_LINE_ID  := V_LG_SHIP_DOC_LINE.PROJECT_ORDER_LINE_ID; --批文行ID
              V_LG_CONTRACT_LINE_ROW.APPLY_LIST_PRICE       := V_LG_SHIP_DOC_LINE.APPLY_LIST_PRICE; --申请价（工程机批文价格）
              V_LG_CONTRACT_LINE_ROW.APPLY_DISCOUNT_RATE    := V_LG_SHIP_DOC_LINE.APPLY_DISCOUNT_RATE; --申请折扣（工程机批文折扣）
              V_LG_CONTRACT_LINE_ROW.PROJECT_ORDER_FLAG     := V_LG_SHIP_DOC_LINE.PROJECT_ORDER_FLAG; --是否工程机
            
              V_LG_CONTRACT_LINE_ROW.MATCH_NUMBER := V_LG_SHIP_DOC_LINE.MATCH_NUMBER;
              V_LG_CONTRACT_LINE_ROW.BEGIN_NUMBER := V_LG_SHIP_DOC_LINE.BEGIN_NUMBER;
            
              V_LG_CONTRACT_LINE(V_LG_CONTRACT_LINE.COUNT + 1) := V_LG_CONTRACT_LINE_ROW;
            
            END LOOP;
          
          ELSE
            --非套件
          
            --构建运输合同行
            V_LG_CONTRACT_LINE_ROW.CONTRACT_LINE_ID    := S_LG_CONTRACT_LINE.NEXTVAL;
            V_LG_CONTRACT_LINE_ROW.CONTRACT_ID         := V_LG_CONTRACT_ROW.CONTRACT_ID;
            V_LG_CONTRACT_LINE_ROW.SALES_MAIN_TYPE     := V_LG_SHIP_DOC_LINE.SALES_MAIN_TYPE;
            V_LG_CONTRACT_LINE_ROW.SALES_SUB_TYPE      := V_LG_SHIP_DOC_LINE.SALES_SUB_TYPE; --营销小类
            V_LG_CONTRACT_LINE_ROW.SALES_ORDER_TYPE_ID := V_LG_SHIP_DOC_LINE.SALES_ORDER_TYPE_ID;
            V_LG_CONTRACT_LINE_ROW.SO_DOC_ID           := C_SO_LG_SHIPDOC.SO_HEADER_ID;
            V_LG_CONTRACT_LINE_ROW.SO_DOC_NUM          := C_SO_LG_SHIPDOC.SO_NUM;
            V_LG_CONTRACT_LINE_ROW.ITEM_CODE           := V_LG_SHIP_DOC_LINE.ITEM_CODE;
            --chenyj8 20170410 增加CCS订单号
            V_LG_CONTRACT_LINE_ROW.SYS_SOURCE_ORDER_NUM := V_LG_SHIP_DOC_LINE.SYS_SOURCE_ORDER_NUM; --CCS订单号
            V_LG_CONTRACT_LINE_ROW.DISTRIBUTE_MODE := C_LG_SHIP_DOC.DISTRIBUTE_MODE;--代销单配送方式
            V_LG_CONTRACT_LINE_ROW.CUSTOMER_CHANNEL_TYPE := C_LG_SHIP_DOC.CUSTOMER_CHANNEL_TYPE;--经营渠道类型
           
           --V_LG_CONTRACT_LINE_ROW.ITEM_NAME           := V_LG_SHIP_DOC_LINE.ITEM_DESC;
            --重新获取产品描述
            BEGIN
              SELECT T.ITEM_NAME
                INTO V_LG_CONTRACT_LINE_ROW.ITEM_NAME
                FROM T_BD_ITEM T
               WHERE T.ITEM_CODE = V_LG_SHIP_DOC_LINE.ITEM_CODE
                 AND T.ENTITY_ID = C_LG_SHIP_DOC.ENTITY_ID;
            EXCEPTION
              WHEN OTHERS THEN
                V_LG_CONTRACT_LINE_ROW.ITEM_NAME := V_LG_SHIP_DOC_LINE.ITEM_DESC;
            END;
          
            V_LG_CONTRACT_LINE_ROW.ITEM_UOM      := V_LG_SHIP_DOC_LINE.ITEM_UOM;
            V_LG_CONTRACT_LINE_ROW.ITEM_PRICE    := V_LG_SHIP_DOC_LINE.ITEM_PRICE;
            V_LG_CONTRACT_LINE_ROW.FACT_SHIP_QTY := C_SO_LG_SHIPDOC.ITEM_QTY;
            V_LG_CONTRACT_LINE_ROW.UNIT_VOLUME   := V_LG_SHIP_DOC_LINE.UNIT_VOLUME;
            V_LG_CONTRACT_LINE_ROW.UNIT_WEIGHT   := V_LG_SHIP_DOC_LINE.UNIT_WEIGHT;
            V_LG_CONTRACT_LINE_ROW.AMOUNT        := V_LG_CONTRACT_LINE_ROW.ITEM_PRICE *
                                                    V_LG_CONTRACT_LINE_ROW.FACT_SHIP_QTY;
            V_LG_CONTRACT_LINE_ROW.TOTAL_VOLUME  := NVL(V_LG_CONTRACT_LINE_ROW.UNIT_VOLUME *
                                                        V_LG_CONTRACT_LINE_ROW.FACT_SHIP_QTY,
                                                        0);
            V_LG_CONTRACT_LINE_ROW.TOTAL_WEIGHT  := NVL(V_LG_CONTRACT_LINE_ROW.UNIT_WEIGHT *
                                                        V_LG_CONTRACT_LINE_ROW.FACT_SHIP_QTY,
                                                        0);
            V_LG_CONTRACT_LINE_ROW.SET_FLAG      := V_LG_SHIP_DOC_LINE.SET_FLAG;
            V_LG_CONTRACT_LINE_ROW.SET_CODE      := NULL;
          
            --计算运费
            IF V_LG_LINE_FREIGHT_STANDARD.PRICE_UNIT = '00' THEN
              --按体积计算
              V_LG_CONTRACT_LINE_ROW.FREIGHT := ROUND(NVL(V_LG_CONTRACT_LINE_ROW.TOTAL_VOLUME *
                                                          V_LG_LINE_FREIGHT_STANDARD.UNIT_PRICE_OF_FREIGHT,
                                                          0),
                                                      2);
            ELSIF V_LG_LINE_FREIGHT_STANDARD.PRICE_UNIT = '01' THEN
              --按重量计算
              V_LG_CONTRACT_LINE_ROW.FREIGHT := ROUND(NVL(V_LG_CONTRACT_LINE_ROW.TOTAL_WEIGHT *
                                                          V_LG_LINE_FREIGHT_STANDARD.UNIT_PRICE_OF_FREIGHT,
                                                          0),
                                                      2);
            ELSE
              V_LG_CONTRACT_LINE_ROW.FREIGHT := 0;
            END IF;
          
            BEGIN
              --查询列表价格
              SELECT LIST_PRICE
                INTO V_LIST_PRICE
                FROM T_BD_PRICE_LINE
               WHERE ITEM_CODE = V_LG_CONTRACT_LINE_ROW.ITEM_CODE
                 AND PRICE_LIST_ID = V_LG_INSURANCE_ROW.PRICE_LIST_ID
                 AND ENTITY_ID = C_LG_SHIP_DOC.ENTITY_ID;
            EXCEPTION
              WHEN OTHERS THEN
                NULL;
            END;
            --计算保费 列表价格*税率
            V_LG_CONTRACT_LINE_ROW.INSURANCE := ROUND(V_LG_CONTRACT_LINE_ROW.FACT_SHIP_QTY *
                                                      V_LIST_PRICE *
                                                      V_LG_INSURANCE_ROW.INSURANCE_RATE / 100,
                                                      2);
            --计算投保金额
            V_LG_CONTRACT_LINE_ROW.RISK_AMOUNT            := ROUND(V_LG_CONTRACT_LINE_ROW.FACT_SHIP_QTY *
                                                                   NVL(V_LIST_PRICE,
                                                                       0),
                                                                   2);
            V_LG_CONTRACT_LINE_ROW.FACT_RECEIVE_QTY       := NULL;
            V_LG_CONTRACT_LINE_ROW.AFFIRM_QTY             := NULL;
            V_LG_CONTRACT_LINE_ROW.SHATTER_QTY            := 0;
            V_LG_CONTRACT_LINE_ROW.DIFF_QTY               := 0;
            V_LG_CONTRACT_LINE_ROW.MOULD_QTY              := 0;
            V_LG_CONTRACT_LINE_ROW.OUT_LINE_QTY           := 0;
            V_LG_CONTRACT_LINE_ROW.PACK_SHATTER_QTY       := 0;
            V_LG_CONTRACT_LINE_ROW.DIFF_REASON            := NULL;
            V_LG_CONTRACT_LINE_ROW.DAMAGE_CLAIMANT_AMOUNT := 0;
            V_LG_CONTRACT_LINE_ROW.BREAK_CLAIMANT_AMOUNT  := 0;
            V_LG_CONTRACT_LINE_ROW.ORIGIN_ORIGIN_TYPE     := V_LG_SHIP_DOC_LINE.ORIGIN_ORIGIN_TYPE;
            V_LG_CONTRACT_LINE_ROW.ORIGIN_ORIGIN_DOC_CODE := V_LG_SHIP_DOC_LINE.ORIGIN_ORIGIN_DOC_CODE;
            V_LG_CONTRACT_LINE_ROW.ORIGIN_ORIGIN_HEAD_ID  := V_LG_SHIP_DOC_LINE.ORIGIN_ORIGIN_HEAD_ID;
            V_LG_CONTRACT_LINE_ROW.ORIGIN_ORIGIN_LINE_ID  := V_LG_SHIP_DOC_LINE.ORIGIN_ORIGIN_LINE_ID;
            V_LG_CONTRACT_LINE_ROW.ORIGIN_TYPE            := V_LG_SHIP_DOC_LINE.ORIGIN_TYPE;
            V_LG_CONTRACT_LINE_ROW.ORIGIN_ORDER_ID        := V_LG_SHIP_DOC_LINE.ORIGIN_ORDER_ID;
            V_LG_CONTRACT_LINE_ROW.ORIGIN_LINE_ID         := V_LG_SHIP_DOC_LINE.ORIGIN_LINE_ID;
            V_LG_CONTRACT_LINE_ROW.ORIGIN_ORDER_NUM       := V_LG_SHIP_DOC_LINE.ORIGIN_ORDER_NUM;
            V_LG_CONTRACT_LINE_ROW.INVENTORY_CODE         := ''; --暂时保留
            V_LG_CONTRACT_LINE_ROW.INVENTORY_NAME         := ''; --暂时保留
            V_LG_CONTRACT_LINE_ROW.CREATED_BY             := 'LG';
            V_LG_CONTRACT_LINE_ROW.CREATION_DATE          := SYSDATE;
            V_LG_CONTRACT_LINE_ROW.LAST_UPDATED_BY        := 'LG';
            V_LG_CONTRACT_LINE_ROW.LAST_UPDATE_DATE       := SYSDATE;
            V_LG_CONTRACT_LINE_ROW.REMARK                 := NULL;
            V_LG_CONTRACT_LINE_ROW.CUSTOMER_ORDER_NUMBER  := C_LG_SHIP_DOC.CUSTOMER_ORDER_NUMBER; --客户订单号
            V_LG_CONTRACT_LINE_ROW.SHIP_DOC_LINE_ID       := V_LG_SHIP_DOC_LINE.SHIP_DOC_LINE_ID; --发货通知单行ID
            V_LG_CONTRACT_LINE_ROW.PROJECT_ORDER_TYPE     := V_LG_SHIP_DOC_LINE.PROJECT_ORDER_TYPE; --批文类型
            V_LG_CONTRACT_LINE_ROW.PROJECT_ORDER_NUMBER   := V_LG_SHIP_DOC_LINE.PROJECT_ORDER_NUMBER; --批文号
            V_LG_CONTRACT_LINE_ROW.PROJECT_ORDER_HEAD_ID  := V_LG_SHIP_DOC_LINE.PROJECT_ORDER_HEAD_ID; --批文头ID
            V_LG_CONTRACT_LINE_ROW.PROJECT_ORDER_LINE_ID  := V_LG_SHIP_DOC_LINE.PROJECT_ORDER_LINE_ID; --批文行ID
            V_LG_CONTRACT_LINE_ROW.APPLY_LIST_PRICE       := V_LG_SHIP_DOC_LINE.APPLY_LIST_PRICE; --申请价（工程机批文价格）
            V_LG_CONTRACT_LINE_ROW.APPLY_DISCOUNT_RATE    := V_LG_SHIP_DOC_LINE.APPLY_DISCOUNT_RATE; --申请折扣（工程机批文折扣）
            V_LG_CONTRACT_LINE_ROW.PROJECT_ORDER_FLAG     := V_LG_SHIP_DOC_LINE.PROJECT_ORDER_FLAG; --是否工程机
          
            V_LG_CONTRACT_LINE_ROW.MATCH_NUMBER := V_LG_SHIP_DOC_LINE.MATCH_NUMBER;
            V_LG_CONTRACT_LINE_ROW.BEGIN_NUMBER := V_LG_SHIP_DOC_LINE.BEGIN_NUMBER;
          
            V_LG_CONTRACT_LINE(V_LG_CONTRACT_LINE.COUNT + 1) := V_LG_CONTRACT_LINE_ROW;
          
          END IF;
        
        END LOOP;
      
      END IF;
    
    END LOOP;
  
    V_NUM                               := V_NUM + 1;
    V_LG_SHIP_DOC.CUSTOMER_ID           := C_LG_SHIP_DOC.CUSTOMER_ID;
    V_LG_SHIP_DOC.CONSIGNEE_LOCATION_ID := C_LG_SHIP_DOC.CONSIGNEE_LOCATION_ID;
    V_LG_SHIP_DOC.CONSIGNEE_ADDR        := C_LG_SHIP_DOC.CONSIGNEE_ADDR;
    V_LG_SHIP_DOC.SHIP_INVENTORY_ID     := C_LG_SHIP_DOC.SHIP_INVENTORY_ID;
    V_LG_SHIP_DOC.TRANSFER_CUSTOMER_ID  := C_LG_SHIP_DOC.TRANSFER_CUSTOMER_ID;
  
  END LOOP;

  --插入排车信息表
  BEGIN
    INSERT INTO T_LG_VEHICLE_INFO VALUES V_LG_VEHICLE_INFO_ROW;
  EXCEPTION
    WHEN OTHERS THEN
      O_RESULT     := '1007';
      O_RESULT_MSG := '生成排车信息头表失败！' || SUBSTR(SQLERRM(SQLCODE), 1, 256);
      RETURN;
  END;
  --插入排车信息行表
  BEGIN
    FOR I IN V_LG_VEHICLE_INFO_LINE.FIRST .. V_LG_VEHICLE_INFO_LINE.LAST LOOP
      INSERT INTO T_LG_VEHICLE_INFO_LINE VALUES V_LG_VEHICLE_INFO_LINE (I);
    END LOOP;
  EXCEPTION
    WHEN OTHERS THEN
      O_RESULT     := '1008';
      O_RESULT_MSG := '生成排车信息行表失败！' || SUBSTR(SQLERRM(SQLCODE), 1, 256);
      RETURN;
  END;
  --插入运输合同头表
  BEGIN
    FOR I IN V_LG_CONTRACT.FIRST .. V_LG_CONTRACT.LAST LOOP
      INSERT INTO T_LG_CONTRACT VALUES V_LG_CONTRACT (I);
    END LOOP;
  EXCEPTION
    WHEN OTHERS THEN
      O_RESULT     := '1009';
      O_RESULT_MSG := '生成运输合同头表失败！' || SUBSTR(SQLERRM(SQLCODE), 1, 256);
      RETURN;
  END;
  --插入运输合同行表
  BEGIN
    FOR I IN V_LG_CONTRACT_LINE.FIRST .. V_LG_CONTRACT_LINE.LAST LOOP
      INSERT INTO T_LG_CONTRACT_LINE VALUES V_LG_CONTRACT_LINE (I);
    END LOOP;
  EXCEPTION
    WHEN OTHERS THEN
      O_RESULT     := '1010';
      O_RESULT_MSG := '生成运输合同行表失败！' || SUBSTR(SQLERRM(SQLCODE), 1, 256);
      RETURN;
  END;

  --组合财务单号、订单号、产品编码相同的行
  FOR C_LG_CONTRACT IN (SELECT CONTRACT_ID
                          FROM T_LG_CONTRACT
                         WHERE VEHICLE_INFO_ID =
                               (SELECT VEHICLE_INFO_ID
                                  FROM T_LG_VEHICLE_INFO
                                 WHERE VEHICLE_NUM = I_VEHICLE_NUM)) LOOP
    FOR C_LG_CONTRACT_LINE IN (SELECT *
                                 FROM T_LG_CONTRACT_LINE
                                WHERE CONTRACT_ID =
                                      C_LG_CONTRACT.CONTRACT_ID
                                ORDER BY ORIGIN_ORDER_NUM,
                                         SO_DOC_NUM,
                                         ITEM_CODE) LOOP
    
      IF (V_LG_CONTRACT_LINE_TEMP.ORIGIN_ORDER_NUM =
         C_LG_CONTRACT_LINE.ORIGIN_ORDER_NUM AND
         V_LG_CONTRACT_LINE_TEMP.SO_DOC_NUM =
         C_LG_CONTRACT_LINE.SO_DOC_NUM AND
         V_LG_CONTRACT_LINE_TEMP.ITEM_CODE = C_LG_CONTRACT_LINE.ITEM_CODE) THEN
      
        --更新上一条记录 将数据合并
        UPDATE T_LG_CONTRACT_LINE
           SET FACT_SHIP_QTY = FACT_SHIP_QTY +
                               C_LG_CONTRACT_LINE.FACT_SHIP_QTY,
               AMOUNT        = AMOUNT + C_LG_CONTRACT_LINE.AMOUNT,
               TOTAL_VOLUME  = TOTAL_VOLUME +
                               C_LG_CONTRACT_LINE.TOTAL_VOLUME,
               TOTAL_WEIGHT  = TOTAL_WEIGHT +
                               C_LG_CONTRACT_LINE.TOTAL_WEIGHT,
               FREIGHT       = FREIGHT + C_LG_CONTRACT_LINE.FREIGHT,
               INSURANCE     = INSURANCE + C_LG_CONTRACT_LINE.INSURANCE
         WHERE CONTRACT_LINE_ID = V_LG_CONTRACT_LINE_TEMP.CONTRACT_LINE_ID;
      
        --删除本行记录
        DELETE FROM T_LG_CONTRACT_LINE
         WHERE CONTRACT_LINE_ID = C_LG_CONTRACT_LINE.CONTRACT_LINE_ID;
      
      ELSE
        V_LG_CONTRACT_LINE_TEMP := C_LG_CONTRACT_LINE;
      END IF;
    END LOOP;
  
    --运输合同运费、保险费、体积、重量、金额汇总
    SELECT NVL(SUM(FREIGHT), 0) +
           NVL(V_LG_LINE_FREIGHT_STANDARD.EXTRA_SHIP_CHARGES, 0),
           SUM(INSURANCE),
           SUM(TOTAL_VOLUME),
           SUM(TOTAL_WEIGHT),
           SUM(AMOUNT),
           SUM(RISK_AMOUNT)
      INTO V_LG_CONTRACT_ROW.FREIGHT,
           V_LG_CONTRACT_ROW.INSURANCE,
           V_LG_CONTRACT_ROW.TOTAL_VOLUME,
           V_LG_CONTRACT_ROW.TOTAL_WEIGHT,
           V_LG_CONTRACT_ROW.TOTAL_AMOUNT,
           V_LG_CONTRACT_ROW.RISK_AMOUNT
      FROM T_LG_CONTRACT_LINE
     WHERE CONTRACT_ID = C_LG_CONTRACT.CONTRACT_ID;
  
    --汇总客户订单号到运输合同头
    V_LG_CONTRACT_ROW.CUSTOMER_ORDER_NUMBER := PKG_LG_CONTRACT.F_COLLECT_CUST_ORDER_NUM(I_CONTRACT_ID => C_LG_CONTRACT.CONTRACT_ID);
  
    --更新运输合同头
    UPDATE T_LG_CONTRACT
       SET FREIGHT               = V_LG_CONTRACT_ROW.FREIGHT,
           ORIGIN_SHIP_CHARGES   = V_LG_CONTRACT_ROW.FREIGHT,
           FREIGHT_NO_TAX        = ROUND(V_LG_CONTRACT_ROW.FREIGHT /
                                         (1 + TAX_RATE / 100),
                                         2),
           TAX_AMOUNT            = V_LG_CONTRACT_ROW.FREIGHT -
                                   ROUND(V_LG_CONTRACT_ROW.FREIGHT /
                                         (1 + TAX_RATE / 100),
                                         2),
           INSURANCE             = V_LG_CONTRACT_ROW.INSURANCE,
           TOTAL_VOLUME          = V_LG_CONTRACT_ROW.TOTAL_VOLUME,
           TOTAL_WEIGHT          = V_LG_CONTRACT_ROW.TOTAL_WEIGHT,
           TOTAL_AMOUNT          = V_LG_CONTRACT_ROW.TOTAL_AMOUNT,
           RISK_AMOUNT           = V_LG_CONTRACT_ROW.RISK_AMOUNT,
           REG_CARRIAGE_FLAG     = 'Y',
           REG_INSURANCE_FLAG    = 'Y',
           CUSTOMER_ORDER_NUMBER = V_LG_CONTRACT_ROW.CUSTOMER_ORDER_NUMBER
     WHERE CONTRACT_ID = C_LG_CONTRACT.CONTRACT_ID;
  
    --清空比对的变量
    V_LG_CONTRACT_LINE_TEMP.ORIGIN_ORDER_NUM := NULL;
    V_LG_CONTRACT_LINE_TEMP.SO_DOC_NUM       := NULL;
    V_LG_CONTRACT_LINE_TEMP.ITEM_CODE        := NULL;
  
  END LOOP;

  --生成完运输合同提交，防止发送给A3取不到数据
  COMMIT;

EXCEPTION
  WHEN OTHERS THEN
    O_RESULT     := '0';
    O_RESULT_MSG := '生成运输合同失败！' || SUBSTR(SQLERRM(SQLCODE), 1, 256);
    RETURN;
END;

  ----------------------------------------------------------------------
  -- AUTHOR  : XUQF
  -- CREATED : 2014-07-29
  -- PURPOSE : 重新计算体积、重量
  ----------------------------------------------------------------------
  PROCEDURE P_RECOUNT_VOLUME_WEIGHT(I_CONTRACT_ID   IN NUMBER,
                                    I_ACCOUNT       IN VARCHAR2, --登录账号
                                    O_AMOUNT_WEIGHT OUT NUMBER,
                                    O_AMOUNT_VOLUME OUT NUMBER,
                                    O_RESULT        OUT VARCHAR2,
                                    O_RESULT_MSG    OUT VARCHAR2) IS
    V_LG_CONTRACT_LINE_ROW T_LG_CONTRACT_LINE%ROWTYPE;
    V_LG_CONTRACT_ROW      T_LG_CONTRACT%ROWTYPE;
    V_CONTRACT_ID          T_LG_CONTRACT.CONTRACT_ID%TYPE; --运输合同头ID
    V_CONTRACT_LINE_ID     T_LG_CONTRACT_LINE.CONTRACT_LINE_ID%TYPE; --运输合同头ID

  BEGIN
    O_RESULT     := '1';
    O_RESULT_MSG := '计算成功';

    --查询运输合同信息
    BEGIN
      SELECT *
        INTO V_LG_CONTRACT_ROW
        FROM T_LG_CONTRACT
       WHERE CONTRACT_ID = I_CONTRACT_ID;
    EXCEPTION
      WHEN OTHERS THEN
        O_RESULT     := '1001';
        O_RESULT_MSG := '查询失败！运输合同号[' || I_CONTRACT_ID || ']不存在，请检查！';
        RETURN;
    END;

    --判断运输合同是否关联结算批
    IF V_LG_CONTRACT_ROW.FREIGHT_BATCH_NUM IS NOT NULL THEN

      O_RESULT     := '1002';
      O_RESULT_MSG := '运输合同ID[' || I_CONTRACT_ID || ']已经关联运费结算批，不能重新计算！';
      RETURN;
    END IF;

    FOR C_LG_CONTRACT_LINE IN (SELECT *
                                 FROM T_LG_CONTRACT_LINE
                                WHERE CONTRACT_ID = I_CONTRACT_ID) LOOP

      BEGIN
        --查询产品单位重量和单位体积
        SELECT PACKINGSIZE, GROSSWEIGHT
          INTO V_LG_CONTRACT_LINE_ROW.UNIT_VOLUME,
               V_LG_CONTRACT_LINE_ROW.UNIT_WEIGHT
          FROM T_BD_ITEM
         WHERE ITEM_CODE = C_LG_CONTRACT_LINE.ITEM_CODE
           AND ENTITY_ID = V_LG_CONTRACT_ROW.ENTITY_ID;
      EXCEPTION
        WHEN OTHERS THEN
          NULL;
      END;

      --更新合同行表前加锁
      SELECT CONTRACT_LINE_ID
        INTO V_CONTRACT_LINE_ID
        FROM T_LG_CONTRACT_LINE
       WHERE CONTRACT_LINE_ID = C_LG_CONTRACT_LINE.CONTRACT_LINE_ID
         FOR UPDATE WAIT 5;

      --更新运输合同行表的单位体积、单位重量、总体积和总重量
      UPDATE T_LG_CONTRACT_LINE
         SET UNIT_VOLUME      = V_LG_CONTRACT_LINE_ROW.UNIT_VOLUME,
             UNIT_WEIGHT      = V_LG_CONTRACT_LINE_ROW.UNIT_WEIGHT,
             TOTAL_VOLUME     = V_LG_CONTRACT_LINE_ROW.UNIT_VOLUME *
                                C_LG_CONTRACT_LINE.FACT_SHIP_QTY,
             TOTAL_WEIGHT     = V_LG_CONTRACT_LINE_ROW.UNIT_WEIGHT *
                                C_LG_CONTRACT_LINE.FACT_SHIP_QTY,
             LAST_UPDATED_BY  = I_ACCOUNT,
             LAST_UPDATE_DATE = SYSDATE
       WHERE CONTRACT_LINE_ID = C_LG_CONTRACT_LINE.CONTRACT_LINE_ID;

    END LOOP;

    --汇总运输合同行重量和体积
    SELECT SUM(TOTAL_VOLUME), SUM(TOTAL_WEIGHT)
      INTO V_LG_CONTRACT_ROW.TOTAL_VOLUME, V_LG_CONTRACT_ROW.TOTAL_WEIGHT
      FROM T_LG_CONTRACT_LINE
     WHERE CONTRACT_ID = I_CONTRACT_ID;

    --更新运输合同前加锁
    SELECT CONTRACT_ID
      INTO V_CONTRACT_ID
      FROM T_LG_CONTRACT
     WHERE CONTRACT_ID = I_CONTRACT_ID
       FOR UPDATE WAIT 5;

    --更新运输合同的总体积和重量
    UPDATE T_LG_CONTRACT
       SET TOTAL_VOLUME     = V_LG_CONTRACT_ROW.TOTAL_VOLUME,
           TOTAL_WEIGHT     = V_LG_CONTRACT_ROW.TOTAL_WEIGHT,
           LAST_UPDATED_BY  = I_ACCOUNT,
           LAST_UPDATE_DATE = SYSDATE
     WHERE CONTRACT_ID = I_CONTRACT_ID;

    O_AMOUNT_WEIGHT := V_LG_CONTRACT_ROW.TOTAL_WEIGHT;
    O_AMOUNT_VOLUME := V_LG_CONTRACT_ROW.TOTAL_VOLUME;

  EXCEPTION
    WHEN OTHERS THEN
      O_RESULT     := '0';
      O_RESULT_MSG := '计算失败！' || SUBSTR(SQLERRM(SQLCODE), 1, 256);
      RETURN;
  END;

  ----------------------------------------------------------------------
  -- AUTHOR  : XUQF
  -- CREATED : 2014-07-29
  -- PURPOSE : 重新计算运费
  ----------------------------------------------------------------------
  PROCEDURE P_RECOUNT_FREIGHT(I_CONTRACT_ID    IN NUMBER,
                              I_ACCOUNT        IN VARCHAR2, --登录账号
                              O_AMOUNT_FREIGHT OUT NUMBER,
                              O_PRICE_UNIT     OUT VARCHAR2,
                              O_RESULT         OUT VARCHAR2,
                              O_RESULT_MSG     OUT VARCHAR2) IS
    V_LG_CONTRACT_ROW          T_LG_CONTRACT%ROWTYPE;
    V_VENDOR_ID                T_LG_VEHICLE_INFO.VENDOR_ID%TYPE;
    V_LG_LINE_FREIGHT_STANDARD T_LG_LINE_FREIGHT_STANDARD%ROWTYPE;
    V_LG_CONTRACT_LINE_ROW     T_LG_CONTRACT_LINE%ROWTYPE;
    V_TAX_RATE                 T_LG_CONTRACT.TAX_RATE%TYPE; --税率
    V_TRANSPORT_LINE_ID        T_LG_TRANSPORT_LINE.TRANSPORT_LINE_ID%TYPE; --运输线路ID
    V_CONTRACT_ID              T_LG_CONTRACT.CONTRACT_ID%TYPE; --运输合同头ID
    V_CONTRACT_LINE_ID         T_LG_CONTRACT_LINE.CONTRACT_LINE_ID%TYPE; --运输合同头ID
    V_TOTAL_VOLUME             NUMBER; --合同对应车的总体积

  BEGIN
    O_RESULT     := '1';
    O_RESULT_MSG := '计算成功';

    --查询运输合同信息
    BEGIN
      SELECT *
        INTO V_LG_CONTRACT_ROW
        FROM T_LG_CONTRACT
       WHERE CONTRACT_ID = I_CONTRACT_ID;
    EXCEPTION
      WHEN OTHERS THEN
        O_RESULT     := '1001';
        O_RESULT_MSG := '查询失败！运输合同ID[' || I_CONTRACT_ID || ']不存在，请检查！';
        RETURN;
    END;

    --判断运输合同是否关联结算批
    IF V_LG_CONTRACT_ROW.FREIGHT_BATCH_NUM IS NOT NULL THEN

      O_RESULT     := '1002';
      O_RESULT_MSG := '运输合同ID[' || I_CONTRACT_ID || ']已经关联运费结算批，不能重新计算！';
      RETURN;
    END IF;

    --查询承运商相关信息
    BEGIN
      SELECT D.VENDOR_ID
        INTO V_VENDOR_ID
        FROM T_LG_SHIP_DOC D
       WHERE D.SHIP_DOC_ID IN
             (SELECT L.SHIP_DOC_ID
                FROM T_LG_SHIP_DOC_LINE L
               WHERE L.SHIP_DOC_LINE_ID IN
                     (SELECT L.SHIP_DOC_LINE_ID
                        FROM T_LG_CONTRACT_LINE L
                       WHERE L.CONTRACT_ID = I_CONTRACT_ID))
         AND D.ENTITY_ID = V_LG_CONTRACT_ROW.ENTITY_ID
         AND ROWNUM = 1;
    EXCEPTION WHEN OTHERS THEN O_RESULT := '1003';
      O_RESULT_MSG := '计算失败！合同号[:' || I_CONTRACT_ID || ']对应的承运商不存在，请检查！';
      RETURN;
    END;

    --获取该车总体积
    SELECT NVL(SUM(T.TOTAL_VOLUME), 0)
      INTO V_TOTAL_VOLUME
      FROM T_LG_CONTRACT T
     WHERE T.VEHICLE_INFO_ID = V_LG_CONTRACT_ROW.VEHICLE_INFO_ID;

    --获取运费税率
    BEGIN
      SELECT TAX_RATE
        INTO V_TAX_RATE
        FROM T_LG_TAX_RATE_CONF
       WHERE CHARGES_TYPE_CODE = '00'
         AND ENTITY_ID = V_LG_CONTRACT_ROW.ENTITY_ID
         AND DEFAULT_FLAG = 'Y';
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;

    --获取线路
    V_TRANSPORT_LINE_ID := PKG_LG_SHIP.F_GET_TRANSPORT_LINE_NEW(in_ENTITY_ID               => V_LG_CONTRACT_ROW.ENTITY_ID,
                                                                in_SHIP_TO_LOCATION_CODE   => V_LG_CONTRACT_ROW.SHIP_TO_LOCATION_CODE,
                                                                in_CONSIGNEE_LOCATION_CODE => V_LG_CONTRACT_ROW.CONSIGNEE_LOCATION_CODE,
                                                                in_SHIP_WAY                => V_LG_CONTRACT_ROW.SHIP_WAY,
                                                                in_SHIP_TYPE               => V_LG_CONTRACT_ROW.SHIP_TYPE,
                                                                in_LOAD_VEHICLE_TYPE       => V_LG_CONTRACT_ROW.Load_Vehicle_Type);

    IF V_TRANSPORT_LINE_ID = 0 THEN

      O_RESULT     := '1004';
      O_RESULT_MSG := '计算失败！未查到合同对应的线路。发货地编码：' ||
                      V_LG_CONTRACT_ROW.SHIP_TO_LOCATION_CODE || ',收货地编码' ||
                      V_LG_CONTRACT_ROW.CONSIGNEE_LOCATION_CODE || '。请检查！';
      RETURN;

    END IF;

    --获取单位运费、附加运费、计价单位和装车类型
    BEGIN
      SELECT T.UNIT_PRICE_OF_FREIGHT,
             T.EXTRA_SHIP_CHARGES,
             T.PRICE_UNIT,
             T.LOAD_VEHICLE_TYPE
        INTO V_LG_LINE_FREIGHT_STANDARD.UNIT_PRICE_OF_FREIGHT,
             V_LG_LINE_FREIGHT_STANDARD.EXTRA_SHIP_CHARGES,
             V_LG_LINE_FREIGHT_STANDARD.PRICE_UNIT,
             V_LG_LINE_FREIGHT_STANDARD.LOAD_VEHICLE_TYPE
        FROM T_LG_LINE_FREIGHT_STANDARD T
       WHERE T.TRANSPORT_LINE_ID = V_TRANSPORT_LINE_ID
         AND T.SHIP_WAY = V_LG_CONTRACT_ROW.SHIP_WAY
         AND T.SHIP_TYPE = V_LG_CONTRACT_ROW.SHIP_TYPE
            --AND T.LOAD_VEHICLE_TYPE = V_LG_SHIP_DOC.LOAD_VEHICLE_TYPE
         AND T.VENDOR_ID = V_VENDOR_ID
         AND T.ENTITY_ID = V_LG_CONTRACT_ROW.ENTITY_ID
         AND T.BEGIN_DATE <= SYSDATE
         AND (T.END_DATE IS NULL OR T.END_DATE >= SYSDATE)
         AND T.MIN_VOL_WEIGHT <= V_TOTAL_VOLUME
         AND (T.MAX_VOL_WEIGHT IS NULL OR T.MAX_VOL_WEIGHT > V_TOTAL_VOLUME);

    EXCEPTION
      WHEN OTHERS THEN
        O_RESULT     := '1005';
        O_RESULT_MSG := '计算失败！线路ID[' || V_TRANSPORT_LINE_ID ||
                        ']对应的费用标准信息不存在，请检查！';
        RETURN;
    END;

    FOR C_LG_CONTRACT_LINE IN (SELECT *
                                 FROM T_LG_CONTRACT_LINE
                                WHERE CONTRACT_ID = I_CONTRACT_ID) LOOP

      --计算运费
      IF V_LG_LINE_FREIGHT_STANDARD.PRICE_UNIT = '00' THEN
        --按体积计算
        V_LG_CONTRACT_LINE_ROW.FREIGHT := ROUND(NVL(C_LG_CONTRACT_LINE.TOTAL_VOLUME *
                                                    V_LG_LINE_FREIGHT_STANDARD.UNIT_PRICE_OF_FREIGHT,
                                                    0),
                                                2);
      ELSIF V_LG_LINE_FREIGHT_STANDARD.PRICE_UNIT = '01' THEN
        --按重量计算
        V_LG_CONTRACT_LINE_ROW.FREIGHT := ROUND(NVL(C_LG_CONTRACT_LINE.TOTAL_WEIGHT *
                                                    V_LG_LINE_FREIGHT_STANDARD.UNIT_PRICE_OF_FREIGHT,
                                                    0),
                                                2);
      ELSE
        V_LG_CONTRACT_LINE_ROW.FREIGHT := 0;
      END IF;

      --更新合同行表前加锁
      SELECT CONTRACT_LINE_ID
        INTO V_CONTRACT_LINE_ID
        FROM T_LG_CONTRACT_LINE
       WHERE CONTRACT_LINE_ID = C_LG_CONTRACT_LINE.CONTRACT_LINE_ID
         FOR UPDATE WAIT 5;

      --更新运输合同行运费
      UPDATE T_LG_CONTRACT_LINE
         SET FREIGHT          = V_LG_CONTRACT_LINE_ROW.FREIGHT,
             LAST_UPDATED_BY  = I_ACCOUNT,
             LAST_UPDATE_DATE = SYSDATE
       WHERE CONTRACT_LINE_ID = C_LG_CONTRACT_LINE.CONTRACT_LINE_ID;

    END LOOP;

    --汇总运输合同行运费
    SELECT NVL(SUM(FREIGHT), 0) +
           NVL(V_LG_LINE_FREIGHT_STANDARD.EXTRA_SHIP_CHARGES, 0)
      INTO V_LG_CONTRACT_ROW.FREIGHT
      FROM T_LG_CONTRACT_LINE
     WHERE CONTRACT_ID = I_CONTRACT_ID;

    --更新运输合同前加锁
    SELECT CONTRACT_ID
      INTO V_CONTRACT_ID
      FROM T_LG_CONTRACT
     WHERE CONTRACT_ID = I_CONTRACT_ID
       FOR UPDATE WAIT 5;

    --更新运输合同的运费、调整运费、税率、运费（不含税）、费用类型、装车类型
    UPDATE T_LG_CONTRACT
       SET FREIGHT             = V_LG_CONTRACT_ROW.FREIGHT,
           TAX_RATE            = V_TAX_RATE,
           ADJUST_SHIP_CHARGES = V_LG_CONTRACT_ROW.FREIGHT,
           FREIGHT_NO_TAX      = ROUND(V_LG_CONTRACT_ROW.FREIGHT /
                                       (1 + NVL(V_TAX_RATE, 0) / 100),
                                       2),
           TAX_AMOUNT          = V_LG_CONTRACT_ROW.FREIGHT -
                                 ROUND(V_LG_CONTRACT_ROW.FREIGHT /
                                       (1 + NVL(V_TAX_RATE, 0) / 100),
                                       2),
           PRICE_UNIT          = V_LG_LINE_FREIGHT_STANDARD.PRICE_UNIT,
           LOAD_VEHICLE_TYPE   = V_LG_LINE_FREIGHT_STANDARD.LOAD_VEHICLE_TYPE,
           LAST_UPDATED_BY     = I_ACCOUNT,
           LAST_UPDATE_DATE    = SYSDATE
     WHERE CONTRACT_ID = I_CONTRACT_ID;

    O_AMOUNT_FREIGHT := V_LG_CONTRACT_ROW.FREIGHT;
    O_PRICE_UNIT     := V_LG_LINE_FREIGHT_STANDARD.PRICE_UNIT;

  EXCEPTION
    WHEN OTHERS THEN
      O_RESULT     := '0';
      O_RESULT_MSG := '计算失败！' || SUBSTR(SQLERRM(SQLCODE), 1, 256);
      RETURN;
  END;
  ----------------------------------------------------------------------
  -- AUTHOR  : XUQF
  -- CREATED : 2014-07-29
  -- PURPOSE : 重新计算保险费
  ----------------------------------------------------------------------
  PROCEDURE P_RECOUNT_INSURANCE(I_CONTRACT_ID      IN NUMBER,
                                I_ACCOUNT          IN VARCHAR2, --登录账号
                                O_AMOUNT_INSURANCE OUT NUMBER,
                                O_RESULT           OUT VARCHAR2,
                                O_RESULT_MSG       OUT VARCHAR2) IS
    V_LG_CONTRACT_ROW  T_LG_CONTRACT%ROWTYPE;
    V_LG_INSURANCE_ROW T_LG_INSURANCE%ROWTYPE;
    V_LIST_PRICE       T_BD_PRICE_LINE.LIST_PRICE%TYPE;
    V_LG_VENDOR_INFO   T_LG_VENDOR_INFO_HEAD%ROWTYPE; --供应商信息
    V_CONTRACT_ID      T_LG_CONTRACT.CONTRACT_ID%TYPE; --运输合同头ID
    V_CONTRACT_LINE_ID T_LG_CONTRACT_LINE.CONTRACT_LINE_ID%TYPE; --运输合同头ID

  BEGIN
    O_RESULT     := '1';
    O_RESULT_MSG := '计算成功';

    --查询运输合同信息
    BEGIN
      SELECT *
        INTO V_LG_CONTRACT_ROW
        FROM T_LG_CONTRACT
       WHERE CONTRACT_ID = I_CONTRACT_ID;
    EXCEPTION
      WHEN OTHERS THEN
        O_RESULT     := '1001';
        O_RESULT_MSG := '查询失败！运输合同号[' || I_CONTRACT_ID || ']不存在，请检查！';
        RETURN;
    END;

    --判断运输合同是否关联结算批
    IF V_LG_CONTRACT_ROW.INSURANCE_BATCH_NUM IS NOT NULL THEN

      O_RESULT     := '1002';
      O_RESULT_MSG := '运输合同ID[' || I_CONTRACT_ID || ']已经关联保险费结算批，不能重新计算！';
      RETURN;
    END IF;

    --查询保险费价格列表ID和税率
    BEGIN
      SELECT *
        INTO V_LG_INSURANCE_ROW
        FROM T_LG_INSURANCE
       WHERE ENTITY_ID = V_LG_CONTRACT_ROW.ENTITY_ID
         AND TRANSPORT_WAY = V_LG_CONTRACT_ROW.SHIP_WAY
         AND BEGIN_DATE <= SYSDATE
         AND (END_DATE IS NULL OR
             (END_DATE IS NOT NULL AND END_DATE >= SYSDATE));
    EXCEPTION
      WHEN OTHERS THEN
        O_RESULT     := '1003';
        O_RESULT_MSG := '计算失败！保险费价格列表不存在，请检查！';
        RETURN;
    END;

    --获取保险商
    BEGIN
      SELECT *
        INTO V_LG_VENDOR_INFO
        FROM T_LG_VENDOR_INFO_HEAD
       WHERE VENDOR_ID = V_LG_INSURANCE_ROW.INSURER_ID;
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;

    FOR C_LG_CONTRACT_LINE IN (SELECT *
                                 FROM T_LG_CONTRACT_LINE
                                WHERE CONTRACT_ID = I_CONTRACT_ID) LOOP

      --查询列表价格
      BEGIN
        SELECT LIST_PRICE
          INTO V_LIST_PRICE
          FROM T_BD_PRICE_LINE
         WHERE ITEM_CODE = C_LG_CONTRACT_LINE.ITEM_CODE
           and nvl(begin_date,sysdate) <= sysdate
           and sysdate <= nvl(end_date,sysdate)
           AND PRICE_LIST_ID = V_LG_INSURANCE_ROW.PRICE_LIST_ID
           AND ENTITY_ID = V_LG_CONTRACT_ROW.ENTITY_ID;
      EXCEPTION
        WHEN OTHERS THEN
          O_RESULT     := '1004';
          O_RESULT_MSG := '计算失败！产品[' || C_LG_CONTRACT_LINE.ITEM_CODE ||
                          ']价格不存在，请检查！';
          RETURN;
      END;

      --更新合同行表前加锁
      SELECT CONTRACT_LINE_ID
        INTO V_CONTRACT_LINE_ID
        FROM T_LG_CONTRACT_LINE
       WHERE CONTRACT_LINE_ID = C_LG_CONTRACT_LINE.CONTRACT_LINE_ID
         FOR UPDATE WAIT 5;

      --更新运输合同行保险费
      UPDATE T_LG_CONTRACT_LINE
         SET INSURANCE        = ROUND(V_LIST_PRICE *
                                      C_LG_CONTRACT_LINE.FACT_SHIP_QTY *
                                      V_LG_INSURANCE_ROW.INSURANCE_RATE / 100,
                                      2),
             LAST_UPDATED_BY  = I_ACCOUNT,
             LAST_UPDATE_DATE = SYSDATE
       WHERE CONTRACT_LINE_ID = C_LG_CONTRACT_LINE.CONTRACT_LINE_ID;

    END LOOP;

    --汇总运输合同行保险费
    SELECT SUM(INSURANCE)
      INTO V_LG_CONTRACT_ROW.INSURANCE
      FROM T_LG_CONTRACT_LINE
     WHERE CONTRACT_ID = I_CONTRACT_ID;

    --更新运输合同前加锁
    SELECT CONTRACT_ID
      INTO V_CONTRACT_ID
      FROM T_LG_CONTRACT
     WHERE CONTRACT_ID = I_CONTRACT_ID
       FOR UPDATE WAIT 5;

    --更新运输合同的保费、保险商
    UPDATE T_LG_CONTRACT
       SET INSURANCE        = NVL(V_LG_CONTRACT_ROW.INSURANCE, 0),
           INSURACE_CODE    = V_LG_VENDOR_INFO.VENDOR_CODE,
           INSURACE_NAME    = V_LG_VENDOR_INFO.VENDOR_NAME,
           LAST_UPDATED_BY  = I_ACCOUNT,
           LAST_UPDATE_DATE = SYSDATE
     WHERE CONTRACT_ID = I_CONTRACT_ID;

    O_AMOUNT_INSURANCE := V_LG_CONTRACT_ROW.INSURANCE;

  EXCEPTION
    WHEN OTHERS THEN
      O_RESULT     := '0';
      O_RESULT_MSG := '计算失败！' || SUBSTR(SQLERRM(SQLCODE), 1, 256);
      RETURN;
  END;

  ----------------------------------------------------------------------
  -- AUTHOR  : XUQF
  -- CREATED : 2014-10-23
  -- PURPOSE : 重新计算包装破损费
  ----------------------------------------------------------------------
  PROCEDURE P_RECOUNT_DAMAGE_FEE(I_CONTRACT_ID       IN NUMBER, --运输合同ID
                                 I_ACCOUNT           IN VARCHAR2, --登录账号
                                 O_DAMAGE_FEE        OUT NUMBER, --包装破损索赔金额
                                 O_CLAIM_VENDOR_CODE OUT VARCHAR2, --索赔单位编码
                                 O_CLAIM_VENDOR_NAME OUT VARCHAR2, --索赔单位名称
                                 O_RESULT            OUT VARCHAR2, --返回错误码
                                 O_RESULT_MSG        OUT VARCHAR2 --返回错误信息
                                 ) IS
    V_LG_CONTRACT_ROW   T_LG_CONTRACT%ROWTYPE; --运输合同
    V_DAMAGE_QTY        NUMBER;
    V_CHARGES_TYPE_ID   T_LG_CHARGES_TYPE.CHARGES_TYPE_ID%TYPE; --费用类型ID
    V_CHARGES_SORT_CODE T_LG_CHARGES_MATERIAL.CHARGES_SORT_CODE%TYPE; --物流费用分类
    V_PRICE             T_LG_CHARGES_TYPE_PRICE.PRICE%TYPE; --分类价格
    V_CHARGES_TYPE_CODE T_LG_CHARGES_TYPE.CHARGES_TYPE_CODE%TYPE; --费用类型编码
    V_CONTRACT_ID       T_LG_CONTRACT.CONTRACT_ID%TYPE; --运输合同头ID
    V_CONTRACT_LINE_ID  T_LG_CONTRACT_LINE.CONTRACT_LINE_ID%TYPE; --运输合同头ID

  BEGIN
    O_RESULT     := '1';
    O_RESULT_MSG := '计算成功';

    --查询运输合同信息
    BEGIN
      SELECT *
        INTO V_LG_CONTRACT_ROW
        FROM T_LG_CONTRACT
       WHERE CONTRACT_ID = I_CONTRACT_ID;
    EXCEPTION
      WHEN OTHERS THEN
        O_RESULT     := '1001';
        O_RESULT_MSG := '查询失败！运输合同ID[' || I_CONTRACT_ID || ']不存在，请检查！';
        RETURN;
    END;

    --判断运输合同是否关联费用增减单
    IF V_LG_CONTRACT_ROW.DAMAGE_INC_DEC_CODE IS NOT NULL THEN

      O_RESULT     := '1002';
      O_RESULT_MSG := '运输合同ID[' || I_CONTRACT_ID ||
                      ']的包装破损索赔金额已经关联费用增减单，不能重新计算！';
      RETURN;
    END IF;

    --判断运输合同是否存在包装破损的产品
    BEGIN
      SELECT SUM(PACK_SHATTER_QTY)
        INTO V_DAMAGE_QTY
        FROM T_LG_CONTRACT_LINE
       WHERE CONTRACT_ID = I_CONTRACT_ID;
    EXCEPTION
      WHEN OTHERS THEN
        O_RESULT     := '1003';
        O_RESULT_MSG := '运输合同ID[' || I_CONTRACT_ID || ']不存在包装破损的数据，请检查！';
        RETURN;
    END;

    IF V_DAMAGE_QTY = 0 OR V_DAMAGE_QTY IS NULL THEN
      O_RESULT     := '1004';
      O_RESULT_MSG := '运输合同不存在包装破损的产品，无需计算！';
      RETURN;
    END IF;

    --获取配置的费用类型编码
    V_CHARGES_TYPE_CODE := PKG_BD.F_GET_PARAMETER_VALUE(P_CONFIG_CODE => 'damageChargesTypeCode', --参数配置编码
                                                        P_ENTITY_ID   => NULL, --业务主体ID
                                                        P_UNIT_ID     => NULL, --中心ID
                                                        P_CUSTOMER_ID => NULL --客户ID
                                                        );

    --判断费用类型编码是否为空
    IF V_CHARGES_TYPE_CODE IS NULL THEN

      O_RESULT     := '1005';
      O_RESULT_MSG := '费用类型编码不能为空！请检查参数配置！';
      RETURN;

    END IF;

    --根据费用类型编码、价格类型（04包装破损费）获取对应的费用类型ID
    BEGIN
      SELECT CHARGES_TYPE_ID
        INTO V_CHARGES_TYPE_ID
        FROM T_LG_CHARGES_TYPE T
       WHERE T.CHARGES_TYPE_CODE = V_CHARGES_TYPE_CODE
         AND T.ENTITY_ID = V_LG_CONTRACT_ROW.ENTITY_ID
         AND T.PRICE_TYPE_CODE = '04';
    EXCEPTION
      WHEN OTHERS THEN
        O_RESULT     := '1006';
        O_RESULT_MSG := '物流费用类型不存在，请检查配置！';
        RETURN;
    END;

    FOR C_LG_CONTRACT_LINE IN (SELECT *
                                 FROM T_LG_CONTRACT_LINE
                                WHERE CONTRACT_ID = I_CONTRACT_ID) LOOP

      --判断是否存在包装破损产品 待修改！！！
      IF C_LG_CONTRACT_LINE.PACK_SHATTER_QTY > 0 THEN

        BEGIN

          --通过产品编码和价格类型查询产品对应的分类
          SELECT A.CHARGES_SORT_CODE
            INTO V_CHARGES_SORT_CODE
            FROM T_LG_CHARGES_MATERIAL A, T_LG_CHARGES_CATEGORY B
           WHERE A.CHARGES_SORT_CODE = B.CHARGES_SORT_CODE
             AND A.ENTITY_ID = B.ENTITY_ID
             AND A.ITEM_CODE = C_LG_CONTRACT_LINE.ITEM_CODE
             AND B.PRICE_TYPE = '04';

          --通过产品对应的分类查询费用类型对应的分类价格
          SELECT PRICE
            INTO V_PRICE
            FROM T_LG_CHARGES_TYPE_PRICE
           WHERE CHARGES_TYPE_ID = V_CHARGES_TYPE_ID
             AND ENTITY_ID = V_LG_CONTRACT_ROW.ENTITY_ID
             AND CHARGES_SORT_CODE = V_CHARGES_SORT_CODE;

        EXCEPTION
          WHEN OTHERS THEN
            NULL;
        END;

        --更新合同行表前加锁
        SELECT CONTRACT_LINE_ID
          INTO V_CONTRACT_LINE_ID
          FROM T_LG_CONTRACT_LINE
         WHERE CONTRACT_LINE_ID = C_LG_CONTRACT_LINE.CONTRACT_LINE_ID
           FOR UPDATE WAIT 5;

        --更新运输合同行包装破损索赔金额
        UPDATE T_LG_CONTRACT_LINE
           SET DAMAGE_CLAIMANT_AMOUNT = V_PRICE *
                                        C_LG_CONTRACT_LINE.PACK_SHATTER_QTY,
               LAST_UPDATED_BY        = I_ACCOUNT,
               LAST_UPDATE_DATE       = SYSDATE
         WHERE CONTRACT_LINE_ID = C_LG_CONTRACT_LINE.CONTRACT_LINE_ID;

      END IF;

    END LOOP;

    --汇总运输合同行包装破损索赔金额
    SELECT SUM(DAMAGE_CLAIMANT_AMOUNT)
      INTO O_DAMAGE_FEE
      FROM T_LG_CONTRACT_LINE
     WHERE CONTRACT_ID = I_CONTRACT_ID;

    --获取运输合同对应的承运商
    BEGIN
      SELECT VENDOR_CODE, VENDOR_NAME
        INTO O_CLAIM_VENDOR_CODE, O_CLAIM_VENDOR_NAME
        FROM T_LG_VEHICLE_INFO
       WHERE VEHICLE_INFO_ID = V_LG_CONTRACT_ROW.VEHICLE_INFO_ID;
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;

    --更新运输合同前加锁
    SELECT CONTRACT_ID
      INTO V_CONTRACT_ID
      FROM T_LG_CONTRACT
     WHERE CONTRACT_ID = I_CONTRACT_ID
       FOR UPDATE WAIT 5;

    --更新运输合同包装破损索赔金额及索赔单位编码、名称
    UPDATE T_LG_CONTRACT
       SET DAMAGE_CLAIMANT_AMOUNT = O_DAMAGE_FEE,
           CLAIM_VENDOR_CODE      = O_CLAIM_VENDOR_CODE,
           CLAIM_VENDOR_NAME      = O_CLAIM_VENDOR_NAME,
           LAST_UPDATED_BY        = I_ACCOUNT,
           LAST_UPDATE_DATE       = SYSDATE
     WHERE CONTRACT_ID = I_CONTRACT_ID;

  EXCEPTION
    WHEN OTHERS THEN
      O_RESULT     := '0';
      O_RESULT_MSG := '计算失败！' || SUBSTR(SQLERRM(SQLCODE), 1, 256);
      RETURN;
  END;

  ----------------------------------------------------------------------
  -- AUTHOR  : XUQF
  -- CREATED : 2014-09-16
  -- PURPOSE : 到货签收
  ----------------------------------------------------------------------
  PROCEDURE P_DELIVERY_RECEIPT(I_CONTRACT_CODE  IN VARCHAR2, --合同号
                               I_ENTITY_ID      IN NUMBER, --主体ID
                               I_RECEIPT_STATUS IN VARCHAR2, --合同签收状态
                               O_RESULT         OUT VARCHAR2,
                               O_RESULT_MSG     OUT VARCHAR2) IS

    V_RECEIPT_INTERFACE_ID   INTF_LG_DELIVERY_RECEIPT.RECEIPT_INTERFACE_ID%TYPE; --到货签收接口表ID
    V_CHARGES_TYPE_ID        T_LG_CHARGES_TYPE.CHARGES_TYPE_ID%TYPE; --费用类型ID
    V_CHARGES_SORT_CODE      T_LG_CHARGES_MATERIAL.CHARGES_SORT_CODE%TYPE; --物流费用分类
    V_PRICE                  T_LG_CHARGES_TYPE_PRICE.PRICE%TYPE; --分类价格
    V_DAMAGE_CLAIMANT_AMOUNT T_LG_CONTRACT_LINE.DAMAGE_CLAIMANT_AMOUNT%TYPE; --包装破损索赔金额
    V_DAMAGE_NUM             NUMBER; --包装破损行数量
    V_LG_VEHICLE_INFO        T_LG_VEHICLE_INFO%ROWTYPE; --排车信息表
    V_CONTRACT_ID            T_LG_CONTRACT.CONTRACT_ID%TYPE; --运输合同头ID
    V_CONTRACT_LINE_ID       T_LG_CONTRACT_LINE.CONTRACT_LINE_ID%TYPE; --运输合同头ID
    V_COUNT NUMBER;
    V_SC_TRSF BOOLEAN := FALSE;
    V_SET_FLAG T_LG_CONTRACT_LINE.SET_FLAG%TYPE;
    V_SET_CODE T_LG_CONTRACT_LINE.SET_CODE%TYPE;
    V_ITEM_CODE T_LG_CONTRACT_LINE.ITEM_CODE%TYPE;
    V_SO_DOC_ID T_LG_CONTRACT_LINE.SO_DOC_ID%TYPE;
  BEGIN
    --初始化默认值
    O_RESULT     := '1';
    O_RESULT_MSG := '到货签收成功';
    V_DAMAGE_NUM := 0;

    --通过运输合同和主体查询到货签收接口头表
    BEGIN
      SELECT max(RECEIPT_INTERFACE_ID)
        INTO V_RECEIPT_INTERFACE_ID
        FROM INTF_LG_DELIVERY_RECEIPT
       WHERE CONTRACT_CODE = I_CONTRACT_CODE
         AND ENTITY_ID = I_ENTITY_ID;
    EXCEPTION
      WHEN OTHERS THEN
        O_RESULT     := '1001';
        O_RESULT_MSG := '运输合同[' || I_CONTRACT_CODE || ']在签收信息表不存在，请检查！';
        RETURN;
    END;
    
    SELECT count(1) INTO V_COUNT
      FROM T_Bd_Center_Relation R,
           t_lg_contract c
     where c.contract_code = I_CONTRACT_CODE
       and c.entity_id = I_ENTITY_ID
       and R.hq_Entity_Id <> R.sc_Entity_Id
       and R.hq_Entity_Id = c.entity_id
       and R.hq_Sales_Center_Code = c.sales_center_code
       and R.hq_Customer_Code = c.customer_code;
      
    IF V_COUNT > 0 THEN
      V_SC_TRSF := TRUE;
    END IF;

    --遍历到货签收接口行表
    FOR C_LG_DELIVERY_RECEIPT_LINE IN (SELECT *
                                         FROM INTF_LG_DELIVERY_RECEIPT_LINE
                                        WHERE RECEIPT_INTERFACE_ID =
                                              V_RECEIPT_INTERFACE_ID) LOOP

      --判断是否存在包装破损产品 待修改！！！
      IF C_LG_DELIVERY_RECEIPT_LINE.PACK_SHATTER_QTY > 0 THEN

        --设置包装破损费用默认值
        V_DAMAGE_CLAIMANT_AMOUNT := 0;
        --增加破损数量
        V_DAMAGE_NUM := V_DAMAGE_NUM + 1;

        BEGIN

          --根据费用类型编码、价格类型（04包装破损费）获取对应的费用类型ID
          SELECT CHARGES_TYPE_ID
            INTO V_CHARGES_TYPE_ID
            FROM T_LG_CHARGES_TYPE T
           WHERE T.CHARGES_TYPE_CODE = '1002' --需要配置参数，在参数中查询获取
             AND T.ENTITY_ID = I_ENTITY_ID
             AND T.PRICE_TYPE_CODE = '04';

          --通过产品编码和价格类型查询产品对应的分类
          SELECT A.CHARGES_SORT_CODE
            INTO V_CHARGES_SORT_CODE
            FROM T_LG_CHARGES_MATERIAL A, T_LG_CHARGES_CATEGORY B
           WHERE A.CHARGES_SORT_CODE = B.CHARGES_SORT_CODE
             AND A.ENTITY_ID = B.ENTITY_ID
             AND A.ITEM_CODE = C_LG_DELIVERY_RECEIPT_LINE.ITEM_CODE
             AND B.PRICE_TYPE = '04';

          --通过产品对应的分类查询费用类型对应的分类价格
          SELECT PRICE
            INTO V_PRICE
            FROM T_LG_CHARGES_TYPE_PRICE
           WHERE CHARGES_TYPE_ID = V_CHARGES_TYPE_ID
             AND ENTITY_ID = I_ENTITY_ID
             AND CHARGES_SORT_CODE = V_CHARGES_SORT_CODE;

          --计算包装破损索赔金额
          V_DAMAGE_CLAIMANT_AMOUNT := V_PRICE *
                                      C_LG_DELIVERY_RECEIPT_LINE.PACK_SHATTER_QTY;

        EXCEPTION
          WHEN OTHERS THEN
            NULL;
        END;
      END IF;

      --更新合同行表前加锁
      SELECT L.CONTRACT_LINE_ID, NVL(L.SET_FLAG, 'N'), L.SET_CODE, L.ITEM_CODE, L.SO_DOC_ID
        INTO V_CONTRACT_LINE_ID, V_SET_FLAG, V_SET_CODE, V_ITEM_CODE, V_SO_DOC_ID
        FROM T_LG_CONTRACT_LINE L
       WHERE L.CONTRACT_LINE_ID = C_LG_DELIVERY_RECEIPT_LINE.CONTRACT_LINE_ID
         FOR UPDATE WAIT 5;

      --更新运输合同行表
      UPDATE T_LG_CONTRACT_LINE
         SET FACT_RECEIVE_QTY       = C_LG_DELIVERY_RECEIPT_LINE.FACT_RECEIVE_QTY,
             SHATTER_QTY            = C_LG_DELIVERY_RECEIPT_LINE.SHATTER_QTY,
             DIFF_QTY               = C_LG_DELIVERY_RECEIPT_LINE.DIFF_QTY,
             MOULD_QTY              = C_LG_DELIVERY_RECEIPT_LINE.MOULD_QTY,
             OUT_LINE_QTY           = C_LG_DELIVERY_RECEIPT_LINE.OUT_LINE_QTY,
             PACK_SHATTER_QTY       = C_LG_DELIVERY_RECEIPT_LINE.PACK_SHATTER_QTY,
             DIFF_REASON            = C_LG_DELIVERY_RECEIPT_LINE.DIFF_REASON,
             REFUSE_QTY             =C_LG_DELIVERY_RECEIPT_LINE.REFUSE_QTY,
             DAMAGE_CLAIMANT_AMOUNT = V_DAMAGE_CLAIMANT_AMOUNT,
             LAST_UPDATED_BY        = 'A3',
             LAST_UPDATE_DATE       = SYSDATE
       WHERE CONTRACT_LINE_ID = C_LG_DELIVERY_RECEIPT_LINE.CONTRACT_LINE_ID;
      
      IF V_SC_TRSF THEN
        IF V_SET_FLAG = 'Y' AND V_SET_CODE IS NOT NULL THEN
          UPDATE T_SO_LINE_DETAIL D
             SET D.FACT_RECEIVE_QTY = NVL(C_LG_DELIVERY_RECEIPT_LINE.FACT_RECEIVE_QTY, 0),
                 D.FACT_REV_GOOD_QTY = NVL(C_LG_DELIVERY_RECEIPT_LINE.FACT_RECEIVE_QTY, 0) -
                                       NVL(C_LG_DELIVERY_RECEIPT_LINE.SHATTER_QTY, 0) -
                                       NVL(C_LG_DELIVERY_RECEIPT_LINE.PACK_SHATTER_QTY, 0),
                 D.FACT_REV_SHATTER_QTY = NVL(C_LG_DELIVERY_RECEIPT_LINE.SHATTER_QTY, 0) +
                                          NVL(C_LG_DELIVERY_RECEIPT_LINE.PACK_SHATTER_QTY, 0),
                 D.FACT_REV_DEFECTIVE_QTY = 0,
                 D.MISSING_QTY = NVL(C_LG_DELIVERY_RECEIPT_LINE.DIFF_QTY, 0),
                 D.REJECTED_QTY = NVL(C_LG_DELIVERY_RECEIPT_LINE.REFUSE_QTY, 0),
                 D.LAST_UPDATED_BY = 'A3',
                 D.LAST_UPDATE_DATE = SYSDATE
           WHERE D.SO_HEADER_ID = V_SO_DOC_ID
             AND D.ITEM_CODE = V_SET_CODE
             AND D.COMPONENT_CODE = V_ITEM_CODE;
        ELSE
          UPDATE T_SO_LINE_DETAIL D
             SET D.FACT_RECEIVE_QTY = NVL(C_LG_DELIVERY_RECEIPT_LINE.FACT_RECEIVE_QTY, 0),
                 D.FACT_REV_GOOD_QTY = NVL(C_LG_DELIVERY_RECEIPT_LINE.FACT_RECEIVE_QTY, 0) -
                                       NVL(C_LG_DELIVERY_RECEIPT_LINE.SHATTER_QTY, 0) -
                                       NVL(C_LG_DELIVERY_RECEIPT_LINE.PACK_SHATTER_QTY, 0),
                 D.FACT_REV_SHATTER_QTY = NVL(C_LG_DELIVERY_RECEIPT_LINE.SHATTER_QTY, 0) +
                                          NVL(C_LG_DELIVERY_RECEIPT_LINE.PACK_SHATTER_QTY, 0),
                 D.FACT_REV_DEFECTIVE_QTY = 0,
                 D.MISSING_QTY = NVL(C_LG_DELIVERY_RECEIPT_LINE.DIFF_QTY, 0),
                 D.REJECTED_QTY = NVL(C_LG_DELIVERY_RECEIPT_LINE.REFUSE_QTY, 0),
                 D.LAST_UPDATED_BY = 'A3',
                 D.LAST_UPDATE_DATE = SYSDATE
           WHERE D.SO_HEADER_ID = V_SO_DOC_ID
             AND D.ITEM_CODE = V_ITEM_CODE
             AND D.COMPONENT_CODE = V_ITEM_CODE;
        END IF;
      END IF;
    END LOOP;

    IF V_DAMAGE_NUM > 0 THEN

      --获取运输合同对应的承运商
      BEGIN
        SELECT VENDOR_CODE, VENDOR_NAME
          INTO V_LG_VEHICLE_INFO.VENDOR_CODE, V_LG_VEHICLE_INFO.VENDOR_NAME
          FROM T_LG_VEHICLE_INFO
         WHERE VEHICLE_INFO_ID =
               (SELECT VEHICLE_INFO_ID
                  FROM T_LG_CONTRACT
                 WHERE CONTRACT_CODE = I_CONTRACT_CODE
                   AND ENTITY_ID = I_ENTITY_ID);
      EXCEPTION
        WHEN OTHERS THEN
          NULL;
      END;

    END IF;

    --更新运输合同前加锁
    SELECT CONTRACT_ID
      INTO V_CONTRACT_ID
      FROM T_LG_CONTRACT
     WHERE CONTRACT_CODE = I_CONTRACT_CODE
       AND ENTITY_ID = I_ENTITY_ID
       FOR UPDATE WAIT 5;

    --更新运输合同状态
    UPDATE T_LG_CONTRACT T
       SET T.RECEIVE_FLAG      = 'Y',
           T.RECEIVE_DATE      = SYSDATE,
           T.CLAIM_VENDOR_CODE = V_LG_VEHICLE_INFO.VENDOR_CODE,
           T.CLAIM_VENDOR_NAME = V_LG_VEHICLE_INFO.VENDOR_NAME,
           T.BILLS_STATUS      = I_RECEIPT_STATUS,
           T.LAST_UPDATED_BY   = 'A3',
           T.LAST_UPDATE_DATE  = SYSDATE,
           T.FACT_ARRIVE_DATE = (SELECT ILDR.FACT_ARRIVE_DATE
                                    FROM CIMS.INTF_LG_DELIVERY_RECEIPT ILDR
                                   WHERE ILDR.RECEIPT_INTERFACE_ID =
                                         V_RECEIPT_INTERFACE_ID),
           T.UNLOADED_DATE     = (SELECT ILDR.UNLOADED_DATE
                                    FROM CIMS.INTF_LG_DELIVERY_RECEIPT ILDR
                                   WHERE ILDR.RECEIPT_INTERFACE_ID =
                                         V_RECEIPT_INTERFACE_ID)
     WHERE T.CONTRACT_CODE = I_CONTRACT_CODE
       AND T.ENTITY_ID = I_ENTITY_ID;

  EXCEPTION
    WHEN OTHERS THEN
      O_RESULT     := '0';
      O_RESULT_MSG := '到货签收失败！' || SUBSTR(SQLERRM(SQLCODE), 1, 256);
      RETURN;
  END;

  ----------------------------------------------------------------------
  -- AUTHOR  : XUQF
  -- CREATED : 2015-01-30
  -- PURPOSE : 批量计算体积
  ----------------------------------------------------------------------
  PROCEDURE P_BATCH_COUNT_VOLLUME(I_BEGIN_DATE IN VARCHAR2, --开始时间
                                  I_END_DATE   IN VARCHAR2, --结束时间
                                  I_ENTITY_ID  IN NUMBER, --主体ID
                                  I_ACCOUNT    IN VARCHAR2, --登录账号
                                  O_RESULT     OUT VARCHAR2,
                                  O_RESULT_MSG OUT VARCHAR2) IS

    V_LG_CONTRACT_LINE T_LG_CONTRACT_LINE%ROWTYPE; --运输合同行
    V_LG_CONTRACT      T_LG_CONTRACT%ROWTYPE; --运输合同
    V_CONTRACT_ID      T_LG_CONTRACT.CONTRACT_ID%TYPE; --运输合同头ID
    V_CONTRACT_LINE_ID T_LG_CONTRACT_LINE.CONTRACT_LINE_ID%TYPE; --运输合同行ID

  BEGIN
    --初始化默认值
    O_RESULT     := '1';
    O_RESULT_MSG := '计算成功';

    FOR C_LG_CONTRACT IN (SELECT *
                            FROM T_LG_CONTRACT
                           WHERE CONTRACT_DATE >=
                                 TO_DATE(I_BEGIN_DATE, 'YYYY-MM-DD')
                             AND CONTRACT_DATE <=
                                 TO_DATE(I_END_DATE || '23:59:59',
                                         'YYYY-MM-DD HH24:MI:SS')
                             AND ENTITY_ID = I_ENTITY_ID
                             AND FREIGHT_BATCH_NUM IS NULL) LOOP

      FOR C_LG_CONTRACT_LINE IN (SELECT *
                                   FROM T_LG_CONTRACT_LINE
                                  WHERE CONTRACT_ID =
                                        C_LG_CONTRACT.CONTRACT_ID) LOOP

        BEGIN
          --查询产品单位重量和单位体积
          SELECT PACKINGSIZE, GROSSWEIGHT
            INTO V_LG_CONTRACT_LINE.UNIT_VOLUME,
                 V_LG_CONTRACT_LINE.UNIT_WEIGHT
            FROM T_BD_ITEM
           WHERE ITEM_CODE = C_LG_CONTRACT_LINE.ITEM_CODE
             AND ENTITY_ID = I_ENTITY_ID;
        EXCEPTION
          WHEN OTHERS THEN
            GOTO LOOP_LINE_END;
        END;

        --更新合同行表前加锁
        SELECT CONTRACT_LINE_ID
          INTO V_CONTRACT_LINE_ID
          FROM T_LG_CONTRACT_LINE
         WHERE CONTRACT_LINE_ID = C_LG_CONTRACT_LINE.CONTRACT_LINE_ID
           FOR UPDATE WAIT 5;

        --更新运输合同行表的单位体积、单位重量、总体积和总重量
        UPDATE T_LG_CONTRACT_LINE
           SET UNIT_VOLUME      = V_LG_CONTRACT_LINE.UNIT_VOLUME,
               UNIT_WEIGHT      = V_LG_CONTRACT_LINE.UNIT_WEIGHT,
               TOTAL_VOLUME     = V_LG_CONTRACT_LINE.UNIT_VOLUME *
                                  C_LG_CONTRACT_LINE.FACT_SHIP_QTY,
               TOTAL_WEIGHT     = V_LG_CONTRACT_LINE.UNIT_WEIGHT *
                                  C_LG_CONTRACT_LINE.FACT_SHIP_QTY,
               LAST_UPDATED_BY  = I_ACCOUNT,
               LAST_UPDATE_DATE = SYSDATE
         WHERE CONTRACT_LINE_ID = C_LG_CONTRACT_LINE.CONTRACT_LINE_ID;

        <<LOOP_LINE_END>>
        NULL;

      END LOOP;

      --汇总运输合同行重量和体积
      SELECT SUM(TOTAL_VOLUME), SUM(TOTAL_WEIGHT)
        INTO V_LG_CONTRACT.TOTAL_VOLUME, V_LG_CONTRACT.TOTAL_WEIGHT
        FROM T_LG_CONTRACT_LINE
       WHERE CONTRACT_ID = C_LG_CONTRACT.CONTRACT_ID;

      --更新运输合同前加锁
      SELECT CONTRACT_ID
        INTO V_CONTRACT_ID
        FROM T_LG_CONTRACT
       WHERE CONTRACT_ID = C_LG_CONTRACT.CONTRACT_ID
         FOR UPDATE WAIT 5;

      --更新运输合同的总体积和重量
      UPDATE T_LG_CONTRACT
         SET TOTAL_VOLUME     = V_LG_CONTRACT.TOTAL_VOLUME,
             TOTAL_WEIGHT     = V_LG_CONTRACT.TOTAL_WEIGHT,
             LAST_UPDATED_BY  = I_ACCOUNT,
             LAST_UPDATE_DATE = SYSDATE
       WHERE CONTRACT_ID = C_LG_CONTRACT.CONTRACT_ID;

    END LOOP;

  EXCEPTION
    WHEN OTHERS THEN
      O_RESULT     := '0';
      O_RESULT_MSG := '计算失败！' || SUBSTR(SQLERRM(SQLCODE), 1, 256);
      RETURN;
  END;

  ----------------------------------------------------------------------
  -- AUTHOR  : XUQF
  -- CREATED : 2015-01-30
  -- PURPOSE : 批量计算运费
  ----------------------------------------------------------------------
  PROCEDURE P_BATCH_COUNT_FREIGHT(I_BEGIN_DATE IN VARCHAR2, --开始时间
                                  I_END_DATE   IN VARCHAR2, --结束时间
                                  I_ENTITY_ID  IN NUMBER, --主体ID
                                  I_ACCOUNT    IN VARCHAR2, --登录账号
                                  O_RESULT     OUT VARCHAR2,
                                  O_RESULT_MSG OUT VARCHAR2) IS

    V_LG_CONTRACT              T_LG_CONTRACT%ROWTYPE; --运输合同
    V_CONTRACT_ID              T_LG_CONTRACT.CONTRACT_ID%TYPE; --运输合同头ID
    V_CONTRACT_LINE_ID         T_LG_CONTRACT_LINE.CONTRACT_LINE_ID%TYPE; --运输合同行ID
    V_TRANSPORT_LINE_ID        T_LG_TRANSPORT_LINE.TRANSPORT_LINE_ID%TYPE; --运输线路ID
    V_VENDOR_ID                T_LG_VEHICLE_INFO.VENDOR_ID%TYPE; --排车信息ID
    V_LG_LINE_FREIGHT_STANDARD T_LG_LINE_FREIGHT_STANDARD%ROWTYPE; --线路运费表
    V_TAX_RATE                 T_LG_CONTRACT.TAX_RATE%TYPE; --税率
    V_TOTAL_VOLUME             NUMBER; --合同对应车的总体积

  BEGIN
    --初始化默认值
    O_RESULT     := '1';
    O_RESULT_MSG := '计算成功';

    --获取运费税率
    BEGIN
      SELECT TAX_RATE
        INTO V_TAX_RATE
        FROM T_LG_TAX_RATE_CONF
       WHERE CHARGES_TYPE_CODE = '00'
         AND ENTITY_ID = I_ENTITY_ID
         AND DEFAULT_FLAG = 'Y';
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;

    FOR C_LG_CONTRACT IN (SELECT *
                            FROM T_LG_CONTRACT
                           WHERE CONTRACT_DATE >=
                                 TO_DATE(I_BEGIN_DATE, 'YYYY-MM-DD')
                             AND CONTRACT_DATE <=
                                 TO_DATE(I_END_DATE || '23:59:59',
                                         'YYYY-MM-DD HH24:MI:SS')
                             AND ENTITY_ID = I_ENTITY_ID
                             AND FREIGHT_BATCH_NUM IS NULL) LOOP

      --查询承运商相关信息
      BEGIN

        SELECT D.VENDOR_ID
          INTO V_VENDOR_ID
          FROM T_LG_SHIP_DOC D
         WHERE D.SHIP_DOC_ID IN
               (SELECT L.SHIP_DOC_ID
                  FROM T_LG_SHIP_DOC_LINE L
                 WHERE L.SHIP_DOC_LINE_ID IN
                       (SELECT L.SHIP_DOC_LINE_ID
                          FROM T_LG_CONTRACT_LINE L
                         WHERE L.CONTRACT_ID = C_LG_CONTRACT.CONTRACT_ID))
           AND D.ENTITY_ID = I_ENTITY_ID
           AND ROWNUM = 1;

      EXCEPTION
        WHEN OTHERS THEN
          GOTO LOOP_HEAD_END;
      END;

      --获取该车总体积
      SELECT NVL(SUM(T.TOTAL_VOLUME), 0)
        INTO V_TOTAL_VOLUME
        FROM T_LG_CONTRACT T
       WHERE T.VEHICLE_INFO_ID = C_LG_CONTRACT.VEHICLE_INFO_ID;

      --获取线路
      V_TRANSPORT_LINE_ID := PKG_LG_SHIP.F_GET_TRANSPORT_LINE_NEW(in_ENTITY_ID               => C_LG_CONTRACT.ENTITY_ID,
                                                                  in_SHIP_TO_LOCATION_CODE   => C_LG_CONTRACT.SHIP_TO_LOCATION_CODE,
                                                                  in_CONSIGNEE_LOCATION_CODE => C_LG_CONTRACT.CONSIGNEE_LOCATION_CODE,
                                                                  in_SHIP_WAY                => C_LG_CONTRACT.SHIP_WAY,
                                                                  in_SHIP_TYPE               => C_LG_CONTRACT.SHIP_TYPE,
                                                                  in_LOAD_VEHICLE_TYPE       => C_LG_CONTRACT.Load_Vehicle_Type);

      --获取单位运费、附加运费、计价单位和装车类型
      BEGIN
        SELECT T.UNIT_PRICE_OF_FREIGHT,
               T.EXTRA_SHIP_CHARGES,
               T.PRICE_UNIT,
               T.LOAD_VEHICLE_TYPE
          INTO V_LG_LINE_FREIGHT_STANDARD.UNIT_PRICE_OF_FREIGHT,
               V_LG_LINE_FREIGHT_STANDARD.EXTRA_SHIP_CHARGES,
               V_LG_LINE_FREIGHT_STANDARD.PRICE_UNIT,
               V_LG_LINE_FREIGHT_STANDARD.LOAD_VEHICLE_TYPE
          FROM T_LG_LINE_FREIGHT_STANDARD T
         WHERE T.TRANSPORT_LINE_ID = V_TRANSPORT_LINE_ID
           AND T.SHIP_WAY = C_LG_CONTRACT.SHIP_WAY
           AND T.SHIP_TYPE = C_LG_CONTRACT.SHIP_TYPE
              --AND T.LOAD_VEHICLE_TYPE = V_LG_SHIP_DOC.LOAD_VEHICLE_TYPE
           AND T.VENDOR_ID = V_VENDOR_ID
           AND T.ENTITY_ID = C_LG_CONTRACT.ENTITY_ID
           AND T.BEGIN_DATE <= SYSDATE
           AND (T.END_DATE IS NULL OR T.END_DATE >= SYSDATE)
           AND T.MIN_VOL_WEIGHT <= V_TOTAL_VOLUME
           AND (T.MAX_VOL_WEIGHT IS NULL OR
               T.MAX_VOL_WEIGHT > V_TOTAL_VOLUME);

      EXCEPTION
        WHEN OTHERS THEN
          GOTO LOOP_HEAD_END;
      END;

      FOR C_LG_CONTRACT_LINE IN (SELECT *
                                   FROM T_LG_CONTRACT_LINE
                                  WHERE CONTRACT_ID =
                                        C_LG_CONTRACT.CONTRACT_ID) LOOP

        --计算运费
        IF V_LG_LINE_FREIGHT_STANDARD.PRICE_UNIT = '00' THEN
          --按体积计算
          C_LG_CONTRACT_LINE.FREIGHT := ROUND(NVL(C_LG_CONTRACT_LINE.TOTAL_VOLUME *
                                                  V_LG_LINE_FREIGHT_STANDARD.UNIT_PRICE_OF_FREIGHT,
                                                  0),
                                              2);
        ELSIF V_LG_LINE_FREIGHT_STANDARD.PRICE_UNIT = '01' THEN
          --按重量计算
          C_LG_CONTRACT_LINE.FREIGHT := ROUND(NVL(C_LG_CONTRACT_LINE.TOTAL_WEIGHT *
                                                  V_LG_LINE_FREIGHT_STANDARD.UNIT_PRICE_OF_FREIGHT,
                                                  0),
                                              2);
        ELSE
          C_LG_CONTRACT_LINE.FREIGHT := 0;
        END IF;

        --更新合同行表前加锁
        SELECT CONTRACT_LINE_ID
          INTO V_CONTRACT_LINE_ID
          FROM T_LG_CONTRACT_LINE
         WHERE CONTRACT_LINE_ID = C_LG_CONTRACT_LINE.CONTRACT_LINE_ID
           FOR UPDATE WAIT 5;

        --更新运输合同行运费
        UPDATE T_LG_CONTRACT_LINE
           SET FREIGHT          = C_LG_CONTRACT_LINE.FREIGHT,
               LAST_UPDATED_BY  = I_ACCOUNT,
               LAST_UPDATE_DATE = SYSDATE
         WHERE CONTRACT_LINE_ID = C_LG_CONTRACT_LINE.CONTRACT_LINE_ID;

      END LOOP;

      --汇总运输合同行运费
      SELECT NVL(SUM(FREIGHT), 0) +
             NVL(V_LG_LINE_FREIGHT_STANDARD.EXTRA_SHIP_CHARGES, 0)
        INTO V_LG_CONTRACT.FREIGHT
        FROM T_LG_CONTRACT_LINE
       WHERE CONTRACT_ID = C_LG_CONTRACT.CONTRACT_ID;

      --更新运输合同前加锁
      SELECT CONTRACT_ID
        INTO V_CONTRACT_ID
        FROM T_LG_CONTRACT
       WHERE CONTRACT_ID = C_LG_CONTRACT.CONTRACT_ID
         FOR UPDATE WAIT 5;

      --更新运输合同的运费、调整运费、税率、运费（不含税）、费用类型、装车类型
      UPDATE T_LG_CONTRACT
         SET FREIGHT             = V_LG_CONTRACT.FREIGHT,
             TAX_RATE            = V_TAX_RATE,
             ADJUST_SHIP_CHARGES = V_LG_CONTRACT.FREIGHT,
             FREIGHT_NO_TAX      = ROUND(V_LG_CONTRACT.FREIGHT /
                                         (1 + NVL(V_TAX_RATE, 0) / 100),
                                         2),
             TAX_AMOUNT          = V_LG_CONTRACT.FREIGHT -
                                   ROUND(V_LG_CONTRACT.FREIGHT /
                                         (1 + NVL(V_TAX_RATE, 0) / 100),
                                         2),
             PRICE_UNIT          = V_LG_LINE_FREIGHT_STANDARD.PRICE_UNIT,
             LOAD_VEHICLE_TYPE   = V_LG_LINE_FREIGHT_STANDARD.LOAD_VEHICLE_TYPE,
             LAST_UPDATED_BY     = I_ACCOUNT,
             LAST_UPDATE_DATE    = SYSDATE
       WHERE CONTRACT_ID = C_LG_CONTRACT.CONTRACT_ID;

      <<LOOP_HEAD_END>>
      NULL;

    END LOOP;

  EXCEPTION
    WHEN OTHERS THEN
      O_RESULT     := '0';
      O_RESULT_MSG := '计算失败！' || SUBSTR(SQLERRM(SQLCODE), 1, 256);
      RETURN;
  END;

  ----------------------------------------------------------------------
  -- AUTHOR  : XUQF
  -- CREATED : 2014-12-12
  -- PURPOSE : 批量计算保费
  ----------------------------------------------------------------------
  PROCEDURE P_BATCH_COUNT_INSURANCE(I_BEGIN_DATE IN VARCHAR2, --开始时间
                                    I_END_DATE   IN VARCHAR2, --结束时间
                                    I_ENTITY_ID  IN NUMBER, --主体ID
                                    I_ACCOUNT    IN VARCHAR2, --登录账号
                                    O_RESULT     OUT VARCHAR2,
                                    O_RESULT_MSG OUT VARCHAR2) IS

    V_LG_INSURANCE     T_LG_INSURANCE%ROWTYPE; --保险费标准
    V_LIST_PRICE       T_BD_PRICE_LINE.LIST_PRICE%TYPE; --保险费对应的产品价格
    V_LG_CONTRACT      T_LG_CONTRACT%ROWTYPE; --运输合同
    V_LG_VENDOR_INFO   T_LG_VENDOR_INFO_HEAD%ROWTYPE; --供应商信息
    V_CONTRACT_ID      T_LG_CONTRACT.CONTRACT_ID%TYPE; --运输合同头ID
    V_CONTRACT_LINE_ID T_LG_CONTRACT_LINE.CONTRACT_LINE_ID%TYPE; --运输合同行ID

  BEGIN
    --初始化默认值
    O_RESULT     := '1';
    O_RESULT_MSG := '计算成功';

    FOR C_LG_CONTRACT IN (SELECT *
                            FROM T_LG_CONTRACT
                           WHERE CONTRACT_DATE >=
                                 TO_DATE(I_BEGIN_DATE, 'YYYY-MM-DD')
                             AND CONTRACT_DATE <=
                                 TO_DATE(I_END_DATE || '23:59:59',
                                         'YYYY-MM-DD HH24:MI:SS')
                             AND ENTITY_ID = I_ENTITY_ID
                             AND INSURANCE_BATCH_NUM IS NULL) LOOP

      --查询保险费价格列表ID和税率
      BEGIN
        SELECT *
          INTO V_LG_INSURANCE
          FROM T_LG_INSURANCE
         WHERE ENTITY_ID = C_LG_CONTRACT.ENTITY_ID
           AND TRANSPORT_WAY = C_LG_CONTRACT.SHIP_WAY
           AND BEGIN_DATE <= SYSDATE
           AND (END_DATE IS NULL OR
               (END_DATE IS NOT NULL AND END_DATE >= SYSDATE));
      EXCEPTION
        WHEN OTHERS THEN
          O_RESULT     := '1003';
          O_RESULT_MSG := '计算失败！保险费价格列表不存在或已失效，请检查！';
          RETURN;
      END;

      --获取保险商
      BEGIN
        SELECT *
          INTO V_LG_VENDOR_INFO
          FROM T_LG_VENDOR_INFO_HEAD
         WHERE VENDOR_ID = V_LG_INSURANCE.INSURER_ID;
      EXCEPTION
        WHEN OTHERS THEN
          NULL;
      END;

      FOR C_LG_CONTRACT_LINE IN (SELECT *
                                   FROM T_LG_CONTRACT_LINE
                                  WHERE CONTRACT_ID =
                                        C_LG_CONTRACT.CONTRACT_ID) LOOP
        --查询列表价格
        BEGIN
          SELECT LIST_PRICE
            INTO V_LIST_PRICE
            FROM T_BD_PRICE_LINE
           WHERE ITEM_CODE = C_LG_CONTRACT_LINE.ITEM_CODE
             and nvl(begin_date,sysdate) <= sysdate
             and sysdate <= nvl(end_date,sysdate)
             AND PRICE_LIST_ID = V_LG_INSURANCE.PRICE_LIST_ID
             AND ENTITY_ID = C_LG_CONTRACT.ENTITY_ID;
        EXCEPTION
          WHEN OTHERS THEN
            GOTO LOOP_LINE_END;
        END;

/*
        --更新合同行表前加锁
        SELECT CONTRACT_LINE_ID
          INTO V_CONTRACT_LINE_ID
          FROM T_LG_CONTRACT_LINE
         WHERE CONTRACT_LINE_ID = C_LG_CONTRACT_LINE.CONTRACT_LINE_ID
           FOR UPDATE WAIT 5;
*/
        --更新运输合同行保险费
        UPDATE T_LG_CONTRACT_LINE
           SET INSURANCE        = ROUND(V_LIST_PRICE *
                                        C_LG_CONTRACT_LINE.FACT_SHIP_QTY *
                                        V_LG_INSURANCE.INSURANCE_RATE / 100,
                                        2),
               LAST_UPDATED_BY  = I_ACCOUNT,
               LAST_UPDATE_DATE = SYSDATE
         WHERE CONTRACT_LINE_ID = C_LG_CONTRACT_LINE.CONTRACT_LINE_ID;

        <<LOOP_LINE_END>>
        NULL;

      END LOOP;

      --汇总运输合同行保险费
      SELECT SUM(INSURANCE)
        INTO V_LG_CONTRACT.INSURANCE
        FROM T_LG_CONTRACT_LINE
       WHERE CONTRACT_ID = C_LG_CONTRACT.CONTRACT_ID;

      --更新运输合同前加锁
      /*
      SELECT CONTRACT_ID
        INTO V_CONTRACT_ID
        FROM T_LG_CONTRACT
       WHERE CONTRACT_ID = C_LG_CONTRACT.CONTRACT_ID
         FOR UPDATE WAIT 5;
         */

      --更新运输合同的运费、调整运费、税率、运费（不含税）
      UPDATE T_LG_CONTRACT
         SET INSURANCE        = NVL(V_LG_CONTRACT.INSURANCE, 0),
             INSURACE_CODE    = V_LG_VENDOR_INFO.VENDOR_CODE,
             INSURACE_NAME    = V_LG_VENDOR_INFO.VENDOR_NAME,
             LAST_UPDATED_BY  = I_ACCOUNT,
             LAST_UPDATE_DATE = SYSDATE
       WHERE CONTRACT_ID = C_LG_CONTRACT.CONTRACT_ID;

      <<LOOP_HEAD_END>>
      NULL;

    END LOOP;

  EXCEPTION
    WHEN OTHERS THEN
      O_RESULT     := '0';
      O_RESULT_MSG := '计算失败！' || SUBSTR(SQLERRM(SQLCODE), 1, 256);
      RETURN;
  END;

  ----------------------------------------------------------------------
  -- AUTHOR  : XUQF
  -- CREATED : 2015-01-07
  -- PURPOSE : 发货确认（仓库由CIMS维护的情况）
  ----------------------------------------------------------------------
  PROCEDURE P_SHIP_CONFIRM(I_ACTUAL_SHIP_ID IN VARCHAR2, --实际发货信息ID
                           I_ACCOUNT        IN VARCHAR2, --登录账号
                           O_RESULT         OUT VARCHAR2,
                           O_RESULT_MSG     OUT VARCHAR2) IS

    V_VEHICLE_NUM T_LG_ACTUAL_SHIP.VEHICLE_NUM%TYPE; --排车编号
    --V_SHIP_DOC_ID T_LG_SHIP_DOC.SHIP_DOC_ID%TYPE; --发货通知单ID

  BEGIN
    --初始化默认值
    O_RESULT     := '1';
    O_RESULT_MSG := '回写成功';

    --获取排车信息
    BEGIN
      SELECT T.VEHICLE_NUM
        INTO V_VEHICLE_NUM
        FROM T_LG_ACTUAL_SHIP T
       WHERE T.ACTUAL_SHIP_ID = I_ACTUAL_SHIP_ID;
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;

    --更新发货通知单排车信息
    UPDATE T_LG_SHIP_DOC T
       SET VEHICLE_NUM      = V_VEHICLE_NUM,
           LAST_UPDATED_BY  = I_ACCOUNT,
           LAST_UPDATE_DATE = SYSDATE
     WHERE T.SHIP_DOC_ID IN
           (SELECT A.SHIP_DOC_ID
              FROM T_LG_SHIP_DOC_LINE A
             WHERE A.SHIP_DOC_LINE_ID IN
                   (SELECT B.SHIP_DOC_LINE_ID
                      FROM T_LG_ACTUAL_SHIP_LINE B
                     WHERE B.SHIP_INFO_ID = I_ACTUAL_SHIP_ID));

    --遍历实际发货信息行表
    FOR C_LG_ACTUAL_SHIP_LINE IN (SELECT *
                                    FROM T_LG_ACTUAL_SHIP_LINE T
                                   WHERE T.SHIP_INFO_ID = I_ACTUAL_SHIP_ID) LOOP

      --更新发货通知单实发信息
      UPDATE T_LG_SHIP_DOC_LINE
         SET FACT_SHIP_QTY    = NVL(FACT_SHIP_QTY, 0) +
                                C_LG_ACTUAL_SHIP_LINE.ITEM_QTY,
             FACT_SHIP_DATE   = SYSDATE,
             LAST_UPDATED_BY  = I_ACCOUNT,
             LAST_UPDATE_DATE = SYSDATE
       WHERE SHIP_DOC_LINE_ID = C_LG_ACTUAL_SHIP_LINE.SHIP_DOC_LINE_ID;

    END LOOP;

  EXCEPTION
    WHEN OTHERS THEN
      O_RESULT     := '0';
      O_RESULT_MSG := '回写失败！' || SUBSTR(SQLERRM(SQLCODE), 1, 256);
      RETURN;
  END;

  ----------------------------------------------------------------------
  -- AUTHOR  : XUQF
  -- CREATED : 2015-01-19
  -- PURPOSE : 汇总客户订单号
  ----------------------------------------------------------------------
  FUNCTION F_COLLECT_CUST_ORDER_NUM(I_CONTRACT_ID VARCHAR2) RETURN VARCHAR2 IS

    V_CUST_ORDER_NUMBER T_LG_CONTRACT.CUSTOMER_ORDER_NUMBER%TYPE; --客户订单号

  BEGIN

    --遍历合同行表
    FOR C_CUST_ORDER_NUMBER IN (SELECT T.CUSTOMER_ORDER_NUMBER
                                  FROM T_LG_CONTRACT_LINE T
                                 WHERE T.CONTRACT_ID = I_CONTRACT_ID) LOOP

      --过滤相同的客户订单号
      IF V_CUST_ORDER_NUMBER IS NULL AND
         C_CUST_ORDER_NUMBER.CUSTOMER_ORDER_NUMBER IS NOT NULL THEN

        V_CUST_ORDER_NUMBER := C_CUST_ORDER_NUMBER.CUSTOMER_ORDER_NUMBER;
      ELSE
        IF INSTR(V_CUST_ORDER_NUMBER,
                 C_CUST_ORDER_NUMBER.CUSTOMER_ORDER_NUMBER) = 0 THEN
          V_CUST_ORDER_NUMBER := V_CUST_ORDER_NUMBER || '，' ||
                                 C_CUST_ORDER_NUMBER.CUSTOMER_ORDER_NUMBER;
        END IF;
      END IF;

    END LOOP;

    RETURN V_CUST_ORDER_NUMBER;

  END;

END PKG_LG_CONTRACT;
/

