create view V_BD_PRICE_APPLY as
select PRICE_APPLY_ID,
       APPLY_CODE,
       APPLY_STATUS,
       APPLY_DATE,
       APPLY_PERSON,
       APPLY_TYPE,
       LOCK_FLAG,
       PROJECT_FLAG,
       TUAN_FLAG,
       PROJECT_ID,
       PROJECT_CODE,
       CUSTOMER_ID,
       CUSTOMER_CODE,
       CUSTOMER_ACCOUNT_ID,
       CUSTOMER_ACCOUNT_CODE,
       BEGIN_DATE,
       END_DATE,
       CREATED_BY,
       CREATION_DATE,
       LAST_UPDATED_BY,
       LAST_UPDATE_DATE,
       REMARK,
       ENTITY_ID,
       DOC_STATUS
  from T_BD_PRICE_APPLY
 where LOCK_FLAG = 'N'
   and APPLY_STATUS = '30'
/

