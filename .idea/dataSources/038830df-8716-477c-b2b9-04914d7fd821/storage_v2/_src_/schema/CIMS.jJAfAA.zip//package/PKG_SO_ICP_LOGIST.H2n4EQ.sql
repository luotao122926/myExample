create PACKAGE      PKG_SO_ICP_LOGIST  AS

  -----------------------------------------------------------------------------
  --处理内部客户关联交易物流接收主过程
  -----------------------------------------------------------------------------
  PROCEDURE P_SYC_SO_ICP_LOGIST_MAIN
  (
    P_SO_NUM       IN VARCHAR2,--财务单号
    P_RESULT         IN OUT NUMBER, --返回错误ID
    P_ERR_MSG        IN OUT VARCHAR2 --返回错误信息
  );

  -----------------------------------------------------------------------------
  --更新物流接收状态
  -----------------------------------------------------------------------------
  PROCEDURE P_UPDATE_ICP_LOGIST
  (
    P_SO_HEADER       IN T_SO_HEADER%ROWTYPE,--财务单头
    P_RESULT         IN OUT NUMBER, --返回错误ID
    P_ERR_MSG        IN OUT VARCHAR2 --返回错误信息
  );

  -----------------------------------------------------------------------------
  --更新完结状态表处理情况
  -----------------------------------------------------------------------------
  PROCEDURE P_UPDATE_SO_FINISH_STATE
  (
    P_SO_NUM       IN INTF_SO_FINISH_STATE.SO_NUM%TYPE,--财务单
    P_ICP_TYPE         IN INTF_SO_FINISH_STATE.ICP_TYPE%TYPE, --关联物流接收处理状态 S-成功，W-警告,E-错误
    P_RESULT         IN OUT NUMBER, --返回错误ID
    P_ERR_MSG        IN OUT VARCHAR2 --返回错误信息
  );

END PKG_SO_ICP_LOGIST;
/

