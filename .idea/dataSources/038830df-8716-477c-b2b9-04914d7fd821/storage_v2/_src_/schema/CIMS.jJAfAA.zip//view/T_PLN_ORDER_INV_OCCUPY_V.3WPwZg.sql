create view T_PLN_ORDER_INV_OCCUPY_V as
SELECT ROUND(DBMS_RANDOM.VALUE(1000000000,9999999999)) SENUM,
       ENTITY_ID,
       SALES_CENTER_CODE,
       SALES_CENTER_NAME,
       CUSTOMER_CODE,
       CUSTOMER_NAME,
       ORIGIN_TYPE,
       ORIGIN_NUMBER,
       ITEM_ID,
       ITEM_CODE,
       ITEM_NAME,
       INVENTORY_ID,
       INVENTORY_CODE,
       INVENTORY_NAME,
       TOTALCOUNT,
       NOT_CARRY_QTY, --20170414 hejy3 增加未下达数量
       SALES_MAIN_TYPE, --20170704 XIAOXU 增加营销大类
       SALES_SUB_TYPE   --20170704 XIAOXU 增加营销小类
       ,hremark
       ,lremark
       ,END_SUPPLY_DATE
       ,CATALOG_ATTRIBUTE06 --20200326 EX_WANGKANG增加扩展字段6
  FROM (SELECT T.ENTITY_ID,
               D.SALES_CENTER_CODE,
               D.SALES_CENTER_NAME,
               D.CUSTOMER_CODE,
               D.CUSTOMER_NAME,
               T.ORIGIN_TYPE,
               T.ORIGIN_NUMBER,
               B.ITEM_ID,
               B.ITEM_CODE,
               B.ITEM_NAME,
               C.INVENTORY_ID,
               C.INVENTORY_CODE,
               C.INVENTORY_NAME,
               T.STOCK_AFFIRM_QTY + T.SUPPLY_QTY - T.SO_ORDER_QTY -
               T.SUNDRY_QTY TOTALCOUNT,
               L.SHARE_QTY - NVL(L.CARRY_QTY, 0) NOT_CARRY_QTY, --20170414 hejy3 增加未下达数量
               B.SALES_MAIN_TYPE, --20170704 XIAOXU 增加营销大类
               B.SALES_SUB_TYPE   --20170704 XIAOXU 增加营销小类
               ,d.remark as hremark
               ,l.remark as lremark
               ,L.END_SUPPLY_DATE --订单入库日期
               ,B.CATALOG_ATTRIBUTE06 --20200326 EX_WANGKANG增加扩展字段6
          FROM T_PLN_ORDER_INV_OCCUPY T,
               T_BD_ITEM              B,
               T_INV_INVENTORIES      C,
               T_PLN_ORDER_HEAD       D
               ,T_PLN_ORDER_LINE      L --20170414 hejy3 增加未下达数量
         WHERE T.ITEM_ID = B.ITEM_ID
           AND C.INVENTORY_ID = T.INVENTORY_ID
           AND T.ORIGIN_NUMBER = D.ORDER_NUMBER(+)
           AND T.ORIGIN_HEAD_ID = D.ORDER_HEAD_ID(+)
           AND T.ORIGIN_LINE_ID = L.ORDER_LINE_ID(+) --20170414 hejy3 增加未下达数量
           AND T.ORIGIN_TYPE = '订单与工单完全匹配'
           AND T.STOCK_AFFIRM_QTY + T.SUPPLY_QTY - T.SO_ORDER_QTY - T.SUNDRY_QTY > 0
        UNION ALL
        SELECT T.ENTITY_ID,
               D.SALES_CENTER_CODE,
               D.SALES_CENTER_NAME,
               D.CUSTOMER_CODE,
               D.CUSTOMER_NAME,
               T.ORIGIN_TYPE,
               T.ORIGIN_NUMBER,
               B.ITEM_ID,
               B.ITEM_CODE,
               B.ITEM_NAME,
               C.INVENTORY_ID,
               C.INVENTORY_CODE,
               C.INVENTORY_NAME,
               T.STOCK_AFFIRM_QTY + T.SUPPLY_QTY - T.SO_ORDER_QTY -
               T.SUNDRY_QTY TOTALCOUNT,
               0 NOT_CARRY_QTY, --20170414 hejy3 增加未下达数量
               B.SALES_MAIN_TYPE, --20170704 XIAOXU 增加营销大类
               B.SALES_SUB_TYPE   --20170704 XIAOXU 增加营销小类
               ,'' as hremark
               ,'' as lremark
               ,null as END_SUPPLY_DATE --订单入库日期
                ,B.CATALOG_ATTRIBUTE06 --20200326 EX_WANGKANG增加扩展字段6
          FROM T_PLN_ORDER_INV_OCCUPY   T,
               T_BD_ITEM                B,
               T_INV_INVENTORIES        C,
               T_PMT_COLLAR_REQUIS_HEAD D
         WHERE T.ITEM_ID = B.ITEM_ID
           AND C.INVENTORY_ID = T.INVENTORY_ID
           AND T.ORIGIN_NUMBER = D.PMT_ORDER_NUM(+)
           AND T.ORIGIN_HEAD_ID = D.COLLAR_REQUIS_HEAD_ID(+)
           AND T.ORIGIN_TYPE = '推广物料发放单'
           AND T.STOCK_AFFIRM_QTY + T.SUPPLY_QTY - T.SO_ORDER_QTY - T.SUNDRY_QTY > 0
        UNION ALL
        SELECT T.ENTITY_ID,
               D.SALES_CENTER_CODE,
               D.SALES_CENTER_NAME,
               D.CUSTOMER_CODE,
               D.CUSTOMER_NAME,
               T.ORIGIN_TYPE,
               T.ORIGIN_NUMBER,
               B.ITEM_ID,
               B.ITEM_CODE,
               B.ITEM_NAME,
               C.INVENTORY_ID,
               C.INVENTORY_CODE,
               C.INVENTORY_NAME,
               T.STOCK_AFFIRM_QTY + T.SUPPLY_QTY - T.SO_ORDER_QTY -
               T.SUNDRY_QTY TOTALCOUNT,
               0 NOT_CARRY_QTY, --20170414 hejy3 增加未下达数量
               B.SALES_MAIN_TYPE, --20170704 XIAOXU 增加营销大类
               B.SALES_SUB_TYPE   --20170704 XIAOXU 增加营销小类
               ,'' as hremark
               ,'' as lremark
               ,null as END_SUPPLY_DATE --订单入库日期
                ,B.CATALOG_ATTRIBUTE06 --20200326 EX_WANGKANG增加扩展字段6
          FROM T_PLN_ORDER_INV_OCCUPY T,
               T_BD_ITEM              B,
               T_INV_INVENTORIES      C,
               T_PLN_LG_ORDER_HEAD    D
         WHERE T.ITEM_ID = B.ITEM_ID
           AND C.INVENTORY_ID = T.INVENTORY_ID
           AND T.ORIGIN_NUMBER = D.ORDER_NUMBER(+)
           AND T.ORIGIN_HEAD_ID = D.ORDER_HEAD_ID(+)
           AND T.ORIGIN_TYPE NOT IN ('推广物料发放单', '订单与工单完全匹配')
           AND T.STOCK_AFFIRM_QTY + T.SUPPLY_QTY - T.SO_ORDER_QTY - T.SUNDRY_QTY > 0
        --
        UNION ALL
        SELECT L.ENTITY_ID,
               NULL SALES_CENTER_CODE,
               NULL SALES_CENTER_NAME,
               NULL CUSTOMER_CODE,
               NULL CUSTOMER_NAME,
               '网批' ORIGIN_TYPE,
               NULL ORIGIN_NUMBER,
               L.ITEM_ID,
               BI.ITEM_CODE,
               BI.ITEM_NAME,
               L.INVENTORY_ID,
               I.INVENTORY_CODE,
               I.INVENTORY_NAME,
               L.QUANTITY TOTALCOUNT,
               0 NOT_CARRY_QTY,
               BI.SALES_MAIN_TYPE,
               BI.SALES_SUB_TYPE
               ,'' as hremark
               ,'' as lremark
                 ,null as END_SUPPLY_DATE --订单入库日期
                ,BI.CATALOG_ATTRIBUTE06 --20200326 EX_WANGKANG增加扩展字段6
          FROM T_INV_LOCKIN L,
               T_BD_ITEM BI,
               T_INV_INVENTORIES I
         WHERE L.ITEM_ID = BI.ITEM_ID
           AND L.INVENTORY_ID = I.INVENTORY_ID
        )
/

