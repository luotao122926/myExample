create PACKAGE PKG_BD_PRICE_NEW  AS
  /*取价函数*/
  function F_GET_PRICE
  (
   P_ACC_ID    t_customer_account.account_id%type,  --账户ID
   P_ITEM_CODE   t_bd_item.item_code%type,           --产品编码
   P_BILL_DATE  VARCHAR2,        --单据日期
   P_PRICE_LIST_ID  t_bd_price_list.price_list_id%type,    --价格列表ID
   P_ENTITY_ID    up_org_unit.ENTITY_ID%type     --业务主体ID
   ) --
   return NUMBER;
  /*（旧）取价过程,入口过程，正品*/
  procedure P_GET_PRICE
  (
   P_ACC_ID       IN t_customer_account.account_id%type,  --账户ID
   P_ITEM_CODE      IN t_bd_item.item_code%type, --产品编码
   P_BILL_DATE    IN VARCHAR2,        --单据日期 YYYYMMDD
   P_PRICE_LIST_ID IN t_bd_price_list.price_list_id%type,--价格列表ID
   P_ENTITY_ID    IN up_org_unit.ENTITY_ID%type, --业务主体ID
   P_PRICE        out NUMBER, --返回价格
   P_DISCOUNT     out NUMBER, --返回折扣率
   P_MONTH_DISCOUNT      out NUMBER, --返回月返
   P_CX_FLAG      out VARCHAR2 --返回是否促销机  
   );
  /*（旧）取价过程,入口过程，优惠品*/
  procedure P_GET_PRICE_YH
  (
   P_ACC_ID       IN t_customer_account.account_id%type,  --账户ID
   P_ITEM_CODE      IN t_bd_item.item_code%type, --产品编码
   P_BILL_DATE    IN VARCHAR2,        --单据日期 YYYYMMDD
   P_PRICE_LIST_ID IN t_bd_price_list.price_list_id%type,--价格列表ID
   P_ENTITY_ID    IN up_org_unit.ENTITY_ID%type, --业务主体ID
   P_PRICE        out NUMBER, --返回价格
   P_DISCOUNT     out NUMBER, --返回折扣率
   P_MONTH_DISCOUNT      out NUMBER, --返回月返
   P_CX_FLAG      out VARCHAR2 --返回是否促销机    
   );
  /*（新）取价过程,入口过程，正品*/
  procedure P_GET_PRICE_MAIN
  (
   P_ACC_ID       IN t_customer_account.account_id%type,  --账户ID
   P_ITEM_CODE      IN t_bd_item.item_code%type, --产品编码
   P_BILL_DATE    IN VARCHAR2,        --单据日期 YYYYMMDD
   P_PRICE_LIST_ID IN t_bd_price_list.price_list_id%type,--价格列表ID
   P_ENTITY_ID    IN up_org_unit.ENTITY_ID%type, --业务主体ID
   P_PRICE        out NUMBER, --返回价格
   P_DISCOUNT     out NUMBER, --返回折扣率
   P_MONTH_DISCOUNT      out NUMBER, --返回月返
   P_CX_FLAG      out VARCHAR2, --返回是否促销机
   P_RETURN_SYSTEM_ID   OUT t_bd_price_system.price_system_id%type, --返回价格体系ID
   P_RETURN_LIST_ID   OUT t_bd_price_list.price_list_id%type, --返回价格列表ID
   P_RESULT       OUT NUMBER, --返回错误ID
   P_ERR_MSG      OUT VARCHAR2 --返回错误信息   
   );
  /*（新）取价过程,入口过程，优惠品*/
  procedure P_GET_PRICE_YH_MAIN
  (
   P_ACC_ID       IN t_customer_account.account_id%type,  --账户ID
   P_ITEM_CODE      IN t_bd_item.item_code%type, --产品编码
   P_BILL_DATE    IN VARCHAR2,        --单据日期 YYYYMMDD
   P_PRICE_LIST_ID IN t_bd_price_list.price_list_id%type,--价格列表ID
   P_ENTITY_ID    IN up_org_unit.ENTITY_ID%type, --业务主体ID
   P_PRICE        out NUMBER, --返回价格
   P_DISCOUNT     out NUMBER, --返回折扣率
   P_MONTH_DISCOUNT      out NUMBER, --返回月返
   P_CX_FLAG      out VARCHAR2, --返回是否促销机
   P_RETURN_SYSTEM_ID   OUT t_bd_price_system.price_system_id%type, --返回价格体系ID
   P_RETURN_LIST_ID   OUT t_bd_price_list.price_list_id%type, --返回价格列表ID
   P_RESULT       OUT NUMBER, --返回错误ID
   P_ERR_MSG      OUT VARCHAR2 --返回错误信息     
   );

  /*家用取价过程,正品*/
  procedure P_GET_PRICE_10
  (
   P_ENTITY_ID    IN NUMBER,
   P_ACC_ID       IN t_customer_account.account_id%type,  --账户ID
   P_ITEM_CODE      IN t_bd_item.item_code%type, --产品编码
   P_BILL_DATE    IN VARCHAR2,        --单据日期
   P_PRICE_LIST_ID IN t_bd_price_list.price_list_id%type,--价格列表ID
   P_PRICE        out NUMBER, --返回价格
   P_DISCOUNT     out NUMBER, --返回折扣率
   P_MONTH_DISCOUNT      out NUMBER, --返回月返
   P_CX_FLAG      out VARCHAR2, --返回是否促销机
   P_RETURN_SYSTEM_ID   OUT t_bd_price_system.price_system_id%type, --返回价格体系ID
   P_RETURN_LIST_ID   OUT t_bd_price_list.price_list_id%type, --返回价格列表ID
   P_RESULT      IN OUT NUMBER, --返回错误ID
   P_ERR_MSG     IN OUT VARCHAR2 --返回错误信息      
   );
  /*家用取价过程,优惠品*/
  procedure P_GET_PRICE_10_YH
  (
   P_ENTITY_ID    IN NUMBER,
   P_ACC_ID       IN t_customer_account.account_id%type,  --账户ID
   P_ITEM_CODE      IN t_bd_item.item_code%type, --产品编码
   P_BILL_DATE    IN VARCHAR2,        --单据日期
   P_PRICE_LIST_ID IN t_bd_price_list.price_list_id%type,--价格列表ID
   P_PRICE        out NUMBER, --返回价格
   P_DISCOUNT     out NUMBER, --返回折扣率
   P_MONTH_DISCOUNT      out NUMBER, --返回月返
   P_CX_FLAG      out VARCHAR2, --返回是否促销机
   P_RETURN_SYSTEM_ID   OUT t_bd_price_system.price_system_id%type, --返回价格体系ID
   P_RETURN_LIST_ID   OUT t_bd_price_list.price_list_id%type, --返回价格列表ID
   P_RESULT      IN OUT NUMBER, --返回错误ID
   P_ERR_MSG     IN OUT VARCHAR2 --返回错误信息      
   );
  /*厨电取价过程,正品*/
  procedure P_GET_PRICE_14
  (
   P_ENTITY_ID    IN NUMBER,
   P_ACC_ID       IN t_customer_account.account_id%type,  --账户ID
   P_ITEM_CODE      IN t_bd_item.item_code%type, --产品编码
   P_BILL_DATE    IN VARCHAR2,        --单据日期
   P_PRICE_LIST_ID IN t_bd_price_list.price_list_id%type,--价格列表ID
   P_PRICE        out NUMBER, --返回价格
   P_DISCOUNT     out NUMBER, --返回折扣率
   P_MONTH_DISCOUNT      out NUMBER, --返回月返
   P_CX_FLAG      out VARCHAR2, --返回是否促销机
   P_RETURN_SYSTEM_ID   OUT t_bd_price_system.price_system_id%type, --返回价格体系ID
   P_RETURN_LIST_ID   OUT t_bd_price_list.price_list_id%type, --返回价格列表ID
   P_RESULT      IN OUT NUMBER, --返回错误ID
   P_ERR_MSG     IN OUT VARCHAR2 --返回错误信息     
   );
  /*厨电取价过程，优惠品*/
  procedure P_GET_PRICE_14_YH
  (
   P_ENTITY_ID    IN NUMBER,
   P_ACC_ID       IN t_customer_account.account_id%type,  --账户ID
   P_ITEM_CODE      IN t_bd_item.item_code%type, --产品编码
   P_BILL_DATE    IN VARCHAR2,        --单据日期
   P_PRICE_LIST_ID IN t_bd_price_list.price_list_id%type,--价格列表ID
   P_PRICE        out NUMBER, --返回价格
   P_DISCOUNT     out NUMBER, --返回折扣率
   P_MONTH_DISCOUNT      out NUMBER, --返回月返
   P_CX_FLAG      out VARCHAR2, --返回是否促销机
   P_RETURN_SYSTEM_ID   OUT t_bd_price_system.price_system_id%type, --返回价格体系ID
   P_RETURN_LIST_ID   OUT t_bd_price_list.price_list_id%type, --返回价格列表ID
   P_RESULT      IN OUT NUMBER, --返回错误ID
   P_ERR_MSG     IN OUT VARCHAR2 --返回错误信息     
   );
  /*根据价格列表进行取价（家用）*/
  procedure P_GET_PRICE_FROM_LIST_10
  (
   P_ENTITY_ID    IN NUMBER,
   P_ITEM_CODE      IN t_bd_item.item_code%type, --产品编码
   P_BILL_DATE     IN VARCHAR2,        --单据日期
   P_PRICE_LIST_ID IN t_bd_price_list.price_list_id%type,--价格列表ID
   P_PRICE        out NUMBER, --返回价格
   P_MONTH_DISCOUNT      out NUMBER, --返回月返
   P_CX_FLAG      out VARCHAR2, --返回是否促销机
   P_RESULT      IN OUT NUMBER, --返回错误ID
   P_ERR_MSG     IN OUT VARCHAR2 --返回错误信息      
   );

  /*根据价格列表进行取价（厨电）*/
  procedure P_GET_PRICE_FROM_LIST_14
  (
   P_ENTITY_ID    IN NUMBER,
   P_ITEM_CODE      IN t_bd_item.item_code%type, --产品编码
   P_BILL_DATE     IN VARCHAR2,        --单据日期
   P_CUSR_TYPE    IN t_bd_price_type.price_type%type, --取价类型
   P_PRICE_LIST_ID IN t_bd_price_list.price_list_id%type,--价格列表ID
   P_PRICE        out NUMBER, --返回价格
   P_MONTH_DISCOUNT      out NUMBER, --返回月返
   P_CX_FLAG      out VARCHAR2, --返回是否促销机
   P_RESULT      IN OUT NUMBER, --返回错误ID
   P_ERR_MSG     IN OUT VARCHAR2 --返回错误信息      
   );

  -----------------------------------------------------------------------------
  --  取价格列表ID           --
  -----------------------------------------------------------------------------
  PROCEDURE P_GET_PRICE_LIST_ID
  (
   P_ENTITY_ID    IN NUMBER,
   P_ACC_ID       IN t_customer_account.account_id%type,  --账户ID
   P_BILL_DATE    IN VARCHAR2,                         --单据日期
   P_PRICE_LIST_ID OUT NUMBER,--价格列表ID
   P_MESSAGE      out VARCHAR2       --返回是否促销机
   );


  -----------------------------------------------------------------------------
  --  取价格列表ID   根据中心        --add by wangcong
  -----------------------------------------------------------------------------
  PROCEDURE P_GET_PRICE_LIST_ID_CENTER
  (
   P_ENTITY_ID               IN NUMBER,
   P_SALES_CENTER_CODE       IN T_BD_PRICE_SYSTEM_ORG.SALES_CENTER_CODE%TYPE,  --中心CODE
   P_BILL_DATE               IN VARCHAR2,                                      --单据日期
   P_ITEM_CODE               IN T_BD_PRICE_LINE.ITEM_CODE%TYPE,                --产品编码
   P_PRICE                   OUT NUMBER,                                       --价格
   P_MONTH_DISCOUNT          OUT NUMBER,                                       --月返
   P_MESSAGE                 OUT VARCHAR2                                      --返回提示信息
   );
END PKG_BD_PRICE_NEW;
/

