create PACKAGE PKG_POL_RPT AS
  ----------------------------------------------------------------------
  --  author:梁颜明 中心本年返利计提报表
  ----------------------------------------------------------------------
  FUNCTION ORDER_CLS_AMOUNT(IN_ENTITY_ID         IN NUMBER,
                            IS_YEAR_CODE         IN VARCHAR2,
                            IN_SALES_CENTER_ID   IN NUMBER,
                            IS_SALES_CENTER_CODE IN VARCHAR2,
                            IS_SALES_CENTER_NAME IN VARCHAR2,
                            IS_USER_CODE         IN VARCHAR2)
    RETURN TAB_POL_ORDER_CLS_AMOUNT
    PIPELINED;

END PKG_POL_RPT;
/

