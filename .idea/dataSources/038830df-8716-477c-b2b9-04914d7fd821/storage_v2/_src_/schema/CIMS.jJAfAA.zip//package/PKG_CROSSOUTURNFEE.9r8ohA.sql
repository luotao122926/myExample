create package PKG_CROSSOUTURNFEE AS
  --包头声明

  V_SUCCESS       CONSTANT VARCHAR2(10) := 'SUCCESS';
  V_ERROR         CONSTANT VARCHAR2(10) := 'ERROR';
  V_YES           CONSTANT CHAR(1) := 'Y';
  V_NO            CONSTANT CHAR(1) := 'N';
  V_OK            CONSTANT CHAR(2) := 'OK';
  V_BIZ_EXCEPTION EXCEPTION; --自定义业务异常

  V_AR_SALE_MAIN_TYPE_WRITE_OFF     CONSTANT VARCHAR2(30) := 'ar_sale_main_type_write_off'; --系统参数中定义是否区分营销大类
  V_AR_SALE_MAIN_DEF_WRITE_OFF      CONSTANT VARCHAR2(30) := 'ar_default_sale_main_write_off';-- 系统参数中定义主体的默认营销大类

  --销售单据源类型编码
  V_BIZ_SRC_BILL_SO              CONSTANT CHAR(4) := '1001'; --销售单
  V_BIZ_SRC_BILL_SO_RED          CONSTANT CHAR(4) := '1002'; --销售红冲单
  V_BIZ_SRC_BILL_RETURN          CONSTANT CHAR(4) := '1003'; --退货单
  V_BIZ_SRC_BILL_RETURN_RED      CONSTANT CHAR(4) := '1004'; --退货红冲单
  V_BIZ_SRC_BILL_SO_DISCOUNT     CONSTANT CHAR(4) := '1005'; --销售折让单
  V_BIZ_SRC_BILL_SO_DISCOUNT_RED CONSTANT CHAR(4) := '1006'; --销售折让红冲单
  V_BIZ_SRC_BILL_DISCOUNT        CONSTANT CHAR(4) := '1007'; --折让证明单
  V_BIZ_SRC_BILL_DISCOUNT_RED    CONSTANT CHAR(4) := '1008'; --折让证明红冲单
  V_BIZ_SRC_BILL_RATE            CONSTANT CHAR(4) := '1009'; --扣率折让单
  V_BIZ_SRC_BILL_RATE_RED        CONSTANT CHAR(4) := '1010'; --扣率折让红冲单

  TYPE AR_SALE_MAIN_TYPE IS RECORD(
  --默认营销大类配置
    IS_SALE_MAIN_WRITEOFF      T_BD_PARAM_ENTITY.ENTITY_VALUE%TYPE, --是否区分营销大类。Y：区分；N：不区分
    SALE_MAIN_TYPE_ID          T_BD_ITEM_CLASS.ITEM_CLASS_ID%TYPE, --营销大类ID
    DEFAULT_SALE_MAIN_TYPE_ID  T_BD_ITEM_CLASS.ITEM_CLASS_ID%TYPE, --默认营销大类ID
    SALE_MAIN_TYPE_CODE        T_BD_ITEM_CLASS.CLASS_CODE%TYPE, --营销大类编码
    SALE_MAIN_TYPE_NAME        T_BD_ITEM_CLASS.CLASS_NAME%TYPE, --营销大类名称
    P_RESULT                   VARCHAR2(400),--执行消息
    P_MESSAGE                  VARCHAR2(10) --成功则返回“OK”，否则返回出错信息
    );

 FUNCTION F_AR_DEFAULT_SALE_MAIN_TYPE
  --------------------   根据主体判断是否区分营销大类核销  -----------------
  ---------------------------   获取默认的营销大类  -----------------------
 (
    ENTITY_ID                        IN NUMBER --主体ID
 ) RETURN PKG_CROSSOUTURNFEE.AR_SALE_MAIN_TYPE;

 FUNCTION F_AR_GET_SALE_MAIN_TYPE_ID
  --------------------   根据主体和营销大类ID取得转换后的营销大类ID  -----------------
  --------------------    不区分营销大类，取参数值；区分营销大类，取默认营销大类ID  -----------------------
 (
    ENTITY_ID                        IN NUMBER, --主体ID
    SALE_MAIN_TYPE_ID                IN T_BD_ITEM_CLASS.ITEM_CLASS_ID%TYPE --营销大类ID
 ) RETURN T_BD_ITEM_CLASS.ITEM_CLASS_ID%TYPE;

 FUNCTION F_AR_GET_SALE_MAIN_TYPE_CODE
  --------------------   根据主体和营销大类ID取得转换后的营销大类编码  -----------------
  --------------------    不区分营销大类，取参数值；区分营销大类，取默认营销大类编码  -----------------------
 (
    ENTITY_ID                        IN NUMBER, --主体ID
    SALE_MAIN_TYPE_CODE              IN T_BD_ITEM_CLASS.CLASS_CODE%TYPE --营销大类编码
 ) RETURN T_BD_ITEM_CLASS.CLASS_CODE%TYPE;

 FUNCTION F_AR_GET_SALE_MAIN_TYPE_NAME
  --------------------   根据主体和营销大类ID取得转换后的营销大类编码  -----------------
  --------------------    不区分营销大类，取参数值；区分营销大类，取默认营销大类名称  -----------------------
 (
    ENTITY_ID                        IN NUMBER, --主体ID
    SALE_MAIN_TYPE_NAME              IN T_BD_ITEM_CLASS.CLASS_NAME%TYPE --营销大类名称
 ) RETURN T_BD_ITEM_CLASS.CLASS_NAME%TYPE;


  --收款单状态确认、正负收款单插入、插入AR收款接口表，AR发票接口表、正负收款单与老核销关系产生新的核销关系插入核销表
  PROCEDURE P_AR_CASH_TURNFEECOMMIT
  (
      p_result  OUT VARCHAR2,
      P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  );



    --核销接口表插入【erp】
  PROCEDURE P_SO_ORDER_RECEIPT_NEW
  (
      p_result  OUT VARCHAR2,
      P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  );

  -- 核销关系推送ERP校验。一张收款单和一张财务单只能核销一次
  PROCEDURE P_SO_ORDER_RECEIPT_CHECK
  (
      p_result  OUT VARCHAR2,
      P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  );

  -- 取消核销关系推送ER
  PROCEDURE P_SO_ORDER_RECEIPT_CANCEL
  (
      P_RESULT  OUT VARCHAR2,
      P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  );

  -- 三方转款协议插入
 /* PROCEDURE P_CASH_TURNFEE_AGREEMENT
  (
      p_date    IN date,
      p_result  OUT VARCHAR2,
      P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  );*/

  --自动坏账准备计提
  PROCEDURE P_SO_BAD_BILL_PROVISION_REPROT
  (
      P_DATE    IN  DATE,
      P_RESULT  OUT VARCHAR2,
      P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  );

  --坏账准备计提沉淀报表
  PROCEDURE P_SO_BAD_BILL_PROVISION_PREC_R
    (

       P_DATE    IN DATE,
       P_RESULT  OUT VARCHAR2,
       P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
   );
  --客户自动核销处理
  PROCEDURE P_AR_WRITE_OFFS_TRAN
  (
      p_date    in date,
      p_result  OUT VARCHAR2,
      P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  );


 --收款冲销单跟原收款单进行核销
 PROCEDURE P_AR_WRITE_OFFS_ORDER
 (
     P_DATE    IN DATE,
     p_result  OUT VARCHAR2,
     P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
 );

 PROCEDURE P_AR_WRITE_OFFS_NEW
 (
     p_time    in date,
     p_result  OUT VARCHAR2,
     P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
 );

  --生成转款头行表，插入3个接口表
  PROCEDURE P_AR_CASH_TURNFEE_NEW
  (
      p_result  out VARCHAR2,
      P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  );
  --退款申请进行撤回修改:11、撤回作废:2、GTMS已驳回:10 这三个状态
  PROCEDURE P_AR_CASH_STATUS
  (
      P_DATE        IN  DATE,
      P_RESULT      OUT VARCHAR2,
      P_MESSAGE     OUT VARCHAR2
  );
  -- 结算更改过程
  PROCEDURE P_AR_SETTLED_WRITE_OFF
  (
      P_DATE         IN  DATE,
      P_RESULT      OUT VARCHAR2,
      P_MESSAGE     OUT VARCHAR2
  );
  --逾期分段动态表
  PROCEDURE P_AR_OVERDUE_TABLE
  (
    P_RESULT      OUT VARCHAR2,
    P_MESSAGE     OUT VARCHAR2
  );
  --坏账确认单据生成
  PROCEDURE BAD_BILL_PROVISION_COMMIT
  (
   P_ID          IN VARCHAR2,
   P_ENTITY_ID   IN NUMBER,
   P_STATUS      IN VARCHAR2,
   P_USER        IN VARCHAR2,
   P_RESULT      OUT VARCHAR2,
   P_MESSAGE     OUT VARCHAR2

  );

  --三方转款协议
  PROCEDURE P_CASH_TURNFEE_AGREEMENT
  (
      P_DATE    IN DATE,
      P_RESULT  OUT VARCHAR2,
      P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  );

  --核销对账检查
  PROCEDURE P_AR_WRITE_OFF_CHECK
  (
      P_DATE           IN  DATE DEFAULT SYSDATE - 1,       -- 检查日期。默认为当前前一天的日期
      P_RESULT  OUT VARCHAR2,
      P_MESSAGE OUT VARCHAR2
  );

end PKG_CROSSOUTURNFEE;
/

