create package      pkg_pg_test is

procedure pg_udcodelist(
          codeType in varchar2,--编码类型
          codeValue in  varchar2,--编码值
          codeName out varchar2, --码表名称
          p_Message out varchar2  --输出信息
  );
end pkg_pg_test;

/

