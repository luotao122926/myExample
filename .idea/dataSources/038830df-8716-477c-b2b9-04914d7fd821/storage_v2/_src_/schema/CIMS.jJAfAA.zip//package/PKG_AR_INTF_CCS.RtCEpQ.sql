create PACKAGE      PKG_AR_INTF_CCS is

-- CCS对账接口表数据插入业务表
  PROCEDURE P_ACCOUNT_CCS
(
  P_MESSAGE                  out varchar2 --成功则返回“SUCCESS”，否则返回出错信息
                                );

END PKG_AR_INTF_CCS;
/

