create Package Pkg_Pln_Intf_Ims Is

  -- Author  : NICRO.LI
  -- Created : 2015-07-18 17:24:25
  -- Purpose : IMS系统接口

  -- Public type declarations
  ------------------------------------------------------------------------------------------
  -- Author  : NICRO.LI
  -- Created : 2015-07-18 17:24:25
  -- Purpose : IMS
  ------------------------------------------------------------------------------------------
  Procedure p_Create_Lgorder(p_Intf_Id In Number, p_Result Out Varchar2);

  ------------------------------------------------------------------------------------------
  -- Author  : NICRO.LI
  -- Created : 2015-07-18 17:24:25
  -- Purpose : 生成CIMS销售单后，同时生成IMS的采购单、财务单
  ------------------------------------------------------------------------------------------
  Procedure p_Soorder_To_Ims_Pox(p_Lg_Ship_Info_Id In Number,
                                 p_Result          Out Varchar2);

  ---------------------------------------------------------------------------------
  -- Author  : 何加源
  -- Created : 2015-11-20
  -- Purpose : 获取独资主体订单锁款标志
  ---------------------------------------------------------------------------------
  FUNCTION f_get_Ims_Lg_Lock_flag(p_Lg_Order_Head_Id In Number, --提货订单头ID
                                  p_Entity_Id        In NUMBER) --主体ID
  RETURN VARCHAR2;
  
  ---------------------------------------------------------------------------------
  -- Author  : 何加源
  -- Created : 2016-6-18
  -- Purpose : 回写IMS订单
  ---------------------------------------------------------------------------------
  PROCEDURE p_WriteBack_Ims_Lg_Order(p_Io_Opt_Id IN NUMBER, --操作接口ID
                                     p_Result OUT VARCHAR2); --返回信息
  
  ---------------------------------------------------------------------------------
  -- Author  : 何加源
  -- Created : 2016-8-29
  -- Purpose : 回写CIMS单号
  ---------------------------------------------------------------------------------
  PROCEDURE p_WriteBack_Cims_PoxSo;
  
  ---------------------------------------------------------------------------------
  -- Author  : 何加源
  -- Created : 2015-11-20
  -- Purpose : 写操作接口表
  ---------------------------------------------------------------------------------
  PROCEDURE P_WriteBack_Opt_Intf(p_Lg_Order_Head_Id In Number, --提货订单头ID
                                 p_Lg_Order_Line_Id In Number, --提货订单行ID
                                 p_Entity_Id        In NUMBER, --主体ID
                                 p_Opt_Type         IN VARCHAR2, --操作类型
                                 p_Transaction_Qty  IN NUMBER, --数量
                                 p_Deal_Money_Cims  IN VARCHAR2, --CIMS款项处理标志
                                 p_Deal_Money_Ims   IN VARCHAR2, --IMS款项处理标志
                                 p_User_Code        IN VARCHAR2, --操作用户
                                 p_Result           Out Varchar2);
End Pkg_Pln_Intf_Ims;
/

