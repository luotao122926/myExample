create package body PKG_PLN_INTF_CCS is

  v_Nl    Constant Varchar2(2) := Chr(13) || Chr(10); --换行
  v_True  Constant Varchar2(2) := 'Y';
  v_False Constant Varchar2(2) := 'N';
  v_Active Constant Varchar2(10):='Active';
  v_Success Constant Varchar2(10) := 'SUCCESS';
  v_Failure Constant Varchar2(10) := 'FAILURE';
  v_Account_Active Constant Varchar2(10) := '1';   --有效
  v_Account_NoActive Constant Varchar2(10) := '2'; --无效

  v_Status_Init    Constant Varchar2(10) :='01'; --接口表状态
  v_Status_Sucess  Constant Varchar2(10) :='02';
  v_Status_Fail    Constant Varchar2(10) :='03';

  v_head_state_init     Constant Varchar2(50) :='19';  --制单状态
  v_head_state_back     Constant Varchar2(50) :='415'; --已驳回状态
  v_head_state_send     Constant Varchar2(50) :='20';  --已送审状态
  v_head_state_check    Constant Varchar2(50) :='23';  --评审完毕
  v_head_state_make     Constant Varchar2(50) :='32';  --已排产
  v_head_state_finish   Constant Varchar2(50) :='306'; --已完成(销售回写）
  v_head_state_capacity   Constant Varchar2(50) :='2225'; --已引APS产能可视

  v_Account_Parameter      Constant Varchar2(500) :='ACCOUNT_SYS';
  v_Main_Parameter         Constant Varchar2(500) :='ITEM_SALES_MAIN_TYPE_FILTER';
  v_Sub_Parameter          Constant Varchar2(500) :='ITEM_SALES_SUB_TYPE_FILTER';
  v_Bussiness_Control      Constant Varchar2(500) :='share_ship_order';
  v_Pro_Order              CONSTANT VARCHAR2(500) := 'pro_order'; --推广物料

  v_Discount_Type_Common Varchar2(32) := 'COMMON'; --常规到款
  v_Discount_Type_Discount Varchar2(32) := 'DISCOUNT';  --折让到款


  Procedure P_CREATE_INTF_LG_ORDER(p_Intf_Id In Number, p_Result Out Varchar2) Is

      r_Pln_Lg_Order_Head Intf_Pln_Lg_Order_Head%Rowtype;
      r_Pln_Lg_Order_HeadLock t_pln_lg_order_head%Rowtype;

      Cursor c_Pln_Lg_Order_Line Is
      Select *
        From intf_pln_lg_order_line ol
       Where ol.intf_head_id = p_Intf_Id
         And ol.intf_status = v_Status_Init;
      r_Pln_Lg_Order_Line  c_Pln_Lg_Order_Line%Rowtype;

      r_Pln_Order_Type     t_Pln_Order_Type%Rowtype;

      v_Value           Varchar2(1000);
      v_Count           Number;
      v_Entity_Name     Varchar2(100);
      v_Sys_Source      Varchar2(50);
      v_Item_Id         Number;
      v_Item_Desc       Varchar2(240);
      v_Item_Uom        Varchar2(32);
      v_Is_Rounding     Varchar2(2);
      v_Rounding_Cnt    Number;
      v_Item_Main_Type_Filter  Varchar2(32);  --add by lizhen 2017-05-26
      v_Item_Sub_Type_Filter   Varchar2(32);  --add by lizhen 2017-05-26
      v_SALES_MAIN_TYPE varchar2(32);
      v_SALES_SUB_TYPE  varchar2(32);
      v_Order_Type_Code Varchar2(40);
      v_Order_Type_Name Varchar2(100);

      v_Sales_Center_Code Varchar2(100);
      v_Sales_Center_Name Varchar2(240);

      v_Customer_Code Varchar2(100);
      v_Customer_Name Varchar2(240);
      v_Customer_Id   number;

      v_Account_Id           number;
      v_Account_Code         Varchar2(100);
      v_Account_Name         Varchar2(240);

      v_Invoice_Contract_Id  Number;        --开票单位联系人ID
      v_Invoice_Contract     Varchar2(100); --开票单位联系人名称
      v_Invoice_Tel          Varchar2(100); --开票单位联系人电话

      v_Consignee_Id         Number;        --收货单位ID
      v_Consignee_Code       Varchar2(240); --收货单位编码
      v_Consignee_Name       Varchar2(240); --收货单位名称

      v_Consignment_Addr_Id  Number;        --收货地点ID
      v_Consignee_Addr       Varchar2(240); --收货地址
      v_Consignee_Addr_Code  Varchar2(240); --收货地址编码
      v_Consignee_Contact_Id Number;        --收货联系人ID
      v_Consignee_Contract   Varchar2(240); --收货联系人
      v_Consignee_Tel        Varchar2(240); --收货联系电话
      v_Preappoint_Flag      Varchar2(2);   --收货预约标志
      
      --产品价格
      v_Apply_Price          Number;        --批文申请价
      v_Apply_Cnt            Number;        --批文可使用数量
      v_Apply_Discount       Number;        --批文折扣
      v_Item_Price           Number;        --产品价格
      v_Discount             Number;        --折扣
      v_Month_Discount       Number;        --月返
      v_Cx_Flag              Varchar2(10);  --是否促销机
      v_Apply_Amount         Number;        --申请金额
      v_Apply_Type           Varchar2(128); --批文类型
      v_Apply_Code           VARCHAR2(32);  --批文编码

      v_Lg_Order_Head_Id     Number;        --提货订单头ID
      v_Order_Number         Varchar2(100); --订单编码
      v_Lg_Order_Line_Id     Number;        --提货订单行ID

      v_Message              Varchar2(1000);
      v_OrderTypeCode        Varchar2(32);
      
      V_IS_MATERIAL          T_BD_ITEM.IS_MATERIAL%TYPE; --物料标志
      v_default_unit         t_bd_item.defaultunit%TYPE; --产品单位
      
      v_Producing_Area_Id    Number;
      v_producing_Area_Code  t_Pln_Producing_Area.Producing_Area_Code%Type;
      v_Producing_Area_Name  t_Pln_Producing_Area.Producing_Area_Name%Type;
      v_Pln_Is_Merge_Lg_Order Varchar2(100);
      v_Unit_Volume           Number;
      v_Unit_Weight           Number;
      v_Consignee_Add_4_Flag  Varchar2(10);
      v_Producing_Area_Id_count NUMBER;  --检查订单行产地是否一致用
      v_Prod_Area_Id          NUMBER;  --订单头上基地ID
      v_Prod_Area_Code        Varchar2(32);   --订单头上基地编码
      v_Prod_Area_Name        Varchar2(100);  --订单头上基地名称
      
      V_RESET_DIS_FLAG VARCHAR2(10) := 'Y'; --是否重新取折扣
      
      V_MINIMUM_QUANTITY      Number;  --起订量      
      V_IS_MINIMUM_QUANTITY_CONTROLS   Varchar2(2); --起订量控制
      
      v_ccs_proj_reg_code t_pln_lg_order_head.ccs_proj_reg_code%type; --20170519 hejy3 项目登录号
			v_Order_Head_State  t_Pln_Lg_Order_Head.Order_Head_State%Type;
      v_Cre_Dis_Type_Enable Varchar2(32); --是否启用折扣类型
      v_Inventory_Id      t_inv_inventories.inventory_id%Type;
      v_Inventory_Code    t_inv_inventories.inventory_code%Type;
      v_Inventory_Name    t_Inv_Inventories.Inventory_Name%Type;
      v_Discount_Type     t_Pln_Lg_Order_Line.Discount_Type%Type;
    --PRAGMA AUTONOMOUS_TRANSACTION;  --modi by lizhen 2015-12-16取消自制式事务
      v_Item_Competite_Attr t_pln_lg_order_line.item_competite_attr%type; --20170727 hejy3 引入产品竞争属性
    v_Price_Apply_Use_Discount t_bd_param_list.default_value%type := 'N'; --20170710 hejy3 价格批文开单使用折扣
      V_Lg_Order_Project_Flag Varchar2(32); --add by lizhen 2017-09-25
      v_belong_to_center_id t_pln_lg_order_head.belong_to_center_id%type;
      v_belong_to_center_code t_pln_lg_order_head.belong_to_center_code%type;
      v_belong_to_center_name t_pln_lg_order_head.belong_to_center_name%type;
      v_belong_to_customer_id t_pln_lg_order_head.belong_to_customer_id%type;
      v_belong_to_customer_code t_pln_lg_order_head.belong_to_customer_code%type;
      v_belong_to_customer_name t_pln_lg_order_head.belong_to_customer_name%type;
      v_Customer_Level t_pln_lg_order_head.customer_level%type;
      v_item_plot_ratio t_bd_item.item_plot_ratio%type;
      V_DOWN_PAY_RATE t_pln_lg_order_head.down_pay_scale%type;
	  V_DISTRIBUTION_FLAG t_pln_lg_order_head.lg_distribution_flag%type;
      V_HEADER_REMARK t_pln_lg_order_head.Remark%type;  --订单头备注
      R_INV_INVENTORIES T_INV_INVENTORIES%ROWTYPE;
    V_CUSTOMIZE_FLAG T_PLN_LG_ORDER_LINE.CUSTOMIZE_FLAG%TYPE;
    V_PARTY_ACOUNT_ID T_PLN_LG_ORDER_LINE.ACCOUNT_ID%TYPE;
    V_SC_ACCOUNT_ID T_PLN_LG_ORDER_LINE.LOANS_SC_ACCOUNT_ID%TYPE;
    V_AGENT_ACCOUNT_ID T_PLN_LG_ORDER_LINE.LOANS_AGENT_ACCOUNT_ID%TYPE;
  Begin
    p_Result := v_Success;
    ----------------------------------------------------------------------
    --  接口数据头表数据检测
    ----------------------------------------------------------------------

    --检测订单接口
    Begin
      v_Value := '锁定订单接口头表失败！';
      Select *
        Into r_Pln_Lg_Order_Head
        From Intf_Pln_Lg_Order_Head h
       Where h.Intf_Id = p_Intf_Id
         And h.Intf_Status = v_Status_Init
         For Update Nowait;
    Exception
      When Others Then
        p_Result := v_Value || v_Nl || Sqlerrm;
        raise V_CCS_EXCEPTION;
    End;

    if p_Result = v_Success then
      v_Value := '来源系统检测：';
      if Nvl(r_Pln_Lg_Order_Head.Sys_Source, '_') = '_' then
         p_Result := v_Value || '未录入来源系统标示。';
           raise V_CCS_EXCEPTION;
      end if;
    End if;

    --主体编码检测
    if p_Result = v_Success then
      begin
        v_Value := '主体编码检测：';
        select b.entity_name
           into v_Entity_Name
        from v_bd_entity b
        where b.entity_id=r_Pln_Lg_Order_Head.Entity_Id;
      exception
         When Others Then
          p_Result := v_Value || '主体编码' || r_Pln_Lg_Order_Head.Entity_Id ||'无效。';
          raise V_CCS_EXCEPTION;
      End;
      
      v_Entity_Name := '事业部：' || v_Entity_Name;
    end if;
    
    --add by lizhen 2016-01-16 快码设置是否不启用4级收货地点
    Begin
      Select Nvl(Uc.Code_Value, 'Y')
        Into v_Consignee_Add_4_Flag
        From Up_Codelist Uc
       Where Uc.Codetype = 'PLN_CONSIGNEE_ADD_4'
         And Uc.Enabled = 0;
    Exception
      When Others Then
        v_Consignee_Add_4_Flag := 'Y';
    End;

    --检查单据类型
    If p_Result = v_Success Then
      Begin
        v_Value := '单据类型检查：';
        Select *
          Into r_Pln_Order_Type
          From t_Pln_Order_Type Ot
         Where Ot.Order_Type_Id = r_Pln_Lg_Order_Head.Order_Type_Id
           and ot.entity_id = r_Pln_Lg_Order_Head.Entity_Id
           And Trunc(r_Pln_Lg_Order_Head.Intf_Date) Between Ot.Begin_Date And
               Trunc(Nvl(Ot.End_Date, Sysdate));
      Exception
        When Others Then
          p_Result := v_Value || v_Entity_Name || '，单据类型ID：' ||
                      To_Char(r_Pln_Lg_Order_Head.Order_Type_Id) ||
                      '不存在或者单据类型失效。';
            raise V_CCS_EXCEPTION;
       End;
    End If;

    Begin
      v_Item_Main_Type_Filter := Pkg_Bd.f_Get_Parameter_Value('ITEM_SALES_MAIN_TYPE_FILTER',
                                                              r_Pln_Lg_Order_Head.Entity_Id);
    Exception
      When Others Then
        p_Result := '获取ITEM_SALES_MAIN_TYPE_FILTER参数失败！' || v_Nl || Sqlerrm;
        Raise v_Ccs_Exception;
    End;
    --ADD BY LIZHEN 获取行是否按小类控制
    Begin
      v_Item_Sub_Type_Filter := Pkg_Bd.f_Get_Parameter_Value('ITEM_SALES_SUB_TYPE_FILTER',
                                                              r_Pln_Lg_Order_Head.Entity_Id);
    Exception
      When Others Then
        p_Result := '获取ITEM_SALES_SUB_TYPE_FILTER参数失败！' || v_Nl || Sqlerrm;
        Raise v_Ccs_Exception;
    End;
    --营销大类检测
    --modi by lizhen 2017-05-26 根据参数检查头表是否需要大类
    BEGIN
      v_Value := '检查订单营销大类一致性：';
      SELECT DISTINCT BI.SALES_MAIN_TYPE
        INTO v_SALES_MAIN_TYPE
        FROM INTF_PLN_LG_ORDER_LINE L, T_BD_ITEM BI
       WHERE L.INTF_HEAD_ID = p_Intf_Id
         AND L.ITEM_CODE = BI.ITEM_CODE
         AND L.ENTITY_ID = BI.ENTITY_ID;
    EXCEPTION
      WHEN OTHERS THEN
        v_SALES_MAIN_TYPE := NULL;
    END;
    
    If p_Result = v_Success THEN
      IF v_Item_Main_Type_Filter = 'Y'
        --网批订单不校验大类
        and nvl(r_Pln_Lg_Order_Head.Customer_Channel_Type, '_') not in(pkg_pln_pub.V_CUSTOMER_CHANNEL_TYPE_WP ,pkg_pln_pub.V_CUSTOMER_CHANNEL_TYPE_NIFFER,
        PKG_PLN_PUB.V_CUSTOMER_CHANNEL_TYPE_SHARE)Then
        BEGIN
          v_Value := '检查订单营销大类一致性：';
          SELECT DISTINCT BI.SALES_MAIN_TYPE
            INTO v_SALES_MAIN_TYPE
            FROM INTF_PLN_LG_ORDER_LINE L, T_BD_ITEM BI
           WHERE L.INTF_HEAD_ID = p_Intf_Id
             AND L.ITEM_CODE = BI.ITEM_CODE
             AND L.ENTITY_ID = BI.ENTITY_ID;
        EXCEPTION
          WHEN OTHERS THEN
            p_Result := v_Value || v_Entity_Name || '，订单存在产品大类不一致的产品，请检查。';
            raise v_Ccs_Exception;
        END;
        
        Begin
          v_Value := '营销大类检测：';
          Select Ic.Class_Code
            Into v_Sales_Main_Type
            From t_Bd_Item_Class Ic
           Where Ic.Class_Code = v_SALES_MAIN_TYPE
             And Ic.Entity_Id = r_Pln_Lg_Order_Head.Entity_Id
             And Ic.Active_Flag = v_True;
        Exception
          When Others Then
            p_Result := v_Value || v_Entity_Name || '，营销大类编码 ' ||
                        v_SALES_MAIN_TYPE || '不存在或者失效。';
            Raise v_Ccs_Exception;
        End;
      ELSIF v_SALES_MAIN_TYPE IS NULL THEN
        v_SALES_MAIN_TYPE := r_Pln_Lg_Order_Head.Sales_Main_Type;    
      END IF;
    End If;
   --营销小类检测
   --modi by lizhen 2017-05-26 根据参数检查头表是否需要小类
    If p_Result = v_Success And v_Item_Sub_Type_Filter = 'Y'
      --网批订单不校验大类
      and nvl(r_Pln_Lg_Order_Head.Customer_Channel_Type, '_') not in(pkg_pln_pub.V_CUSTOMER_CHANNEL_TYPE_WP ,pkg_pln_pub.V_CUSTOMER_CHANNEL_TYPE_NIFFER,
      PKG_PLN_PUB.V_CUSTOMER_CHANNEL_TYPE_SHARE) Then
      Begin
          v_Value := '营销小类检测：';
          Select ic.class_code
            Into v_SALES_SUB_TYPE
            From t_bd_item_class ic
           Where ic.class_code = r_Pln_Lg_Order_Head.Sales_Sub_Type
             And ic.entity_id=r_Pln_Lg_Order_Head.Entity_Id
             And ic.active_flag=v_True;
        Exception
          When Others Then
            p_Result := v_Value || v_Entity_Name || '，营销小类编码 ' ||
                        r_Pln_Lg_Order_Head.Sales_Sub_Type ||
                        '不存在或者失效。';
              raise V_CCS_EXCEPTION;
        End;
   End If;
   
   --验证收货仓库编码的有效性 add by huanghb12
    If p_Result = v_Success And r_Pln_Lg_Order_Head.Rcv_Inv_Code is not null Then
      Begin
          v_Value := '验证收货仓库编码的有效性：';
          Select i.*
            Into R_INV_INVENTORIES 
            From t_Inv_Inventories i
           Where i.inventory_code = r_Pln_Lg_Order_Head.Rcv_Inv_Code
             And i.entity_id=r_Pln_Lg_Order_Head.Entity_Id;
          
          r_Pln_Lg_Order_Head.Inventory_To_Id   := R_INV_INVENTORIES.INVENTORY_ID;
          r_Pln_Lg_Order_Head.Rcv_Inv_Code   := R_INV_INVENTORIES.INVENTORY_CODE;
          r_Pln_Lg_Order_Head.Rcv_Inv_Name   := R_INV_INVENTORIES.INVENTORY_NAME;
        Exception
          When Others Then
            p_Result := v_Value || v_Entity_Name || '，收货仓库编码 ' ||
                        r_Pln_Lg_Order_Head.Rcv_Inv_Code ||
                        '不存在或者失效。';
              raise V_CCS_EXCEPTION;
        End;
        
       --推广物料检查(物料单据类型、仓库物料类型)
       v_Value := '推广物料检查';
       IF r_Pln_Order_Type.Is_Business_Control = v_Pro_Order AND NVL(R_INV_INVENTORIES.STOCK_TYPE,'10') <> '11' THEN
         p_Result := v_Value || v_Entity_Name || '，仓库：' || r_Pln_Lg_Order_Head.Rcv_Inv_Code ||
                     '不是推广物料，不允许通过单据类型：' || r_Pln_Order_Type.Order_Type_Name || '报送';
         raise V_CCS_EXCEPTION;
       END IF;
    
   End If;
   --end  by huanghb12
   
   --add by lizhen 2017-05-26 检查是否需要折扣类型
   Begin
     Select Pkg_Bd.f_Get_Parameter_Value(p_Config_Code => 'CRE_DIS_TYPE_ENABLE',
                                         p_Entity_Id   => r_Pln_Lg_Order_Head.Entity_Id)
       Into v_Cre_Dis_Type_Enable
       From Dual;
   Exception
     When Others Then
       p_Result := '获取主体参数失败，系统参数编码【PLN_IS_MERGE_LG_ORDER】';
       Raise v_Ccs_Exception;
   End;
   
   --add by lizhen 2017-08-17 获取价格批文开单使用折扣参数
  Begin
    v_Price_Apply_Use_Discount := Pkg_Bd.f_Get_Parameter_Value('PLN_PRICE_APPLY_USE_DISCOUNT',
                                                               r_Pln_Lg_Order_Head.Entity_Id);
  Exception
    When Others Then
      v_Price_Apply_Use_Discount := 'N';
  End;
   
  --add by lizhen 2017-09-25 获取订单行是否只允许录入批文
  Begin
    V_Lg_Order_Project_Flag := Pkg_Bd.f_Get_Parameter_Value('PLN_LG_ORDER_PROJECT_FLAG',
                                                               r_Pln_Lg_Order_Head.Entity_Id);
  Exception
    When Others Then
      V_Lg_Order_Project_Flag := 'N';
  End;
  
   
   --获取T+3系统参数
   Begin
     Select Pkg_Bd.f_Get_Parameter_Value(p_Config_Code => 'PLN_IS_MERGE_LG_ORDER',
                                         p_Entity_Id   => r_Pln_Lg_Order_Head.Entity_Id)
       Into v_Pln_Is_Merge_Lg_Order
       From Dual;
   Exception
     When Others Then
       p_Result := '获取主体参数失败，系统参数编码【PLN_IS_MERGE_LG_ORDER】';
       Raise v_Ccs_Exception;
   End;

   --订单行检测
   If p_Result = v_Success Then
     Select Count(1)
       Into v_Count
       From intf_pln_lg_order_line l
      Where l.intf_head_id = r_Pln_Lg_Order_Head.Intf_Id
        And l.Entity_Id = r_Pln_Lg_Order_Head.Entity_Id;
     If v_Count = 0 Then
       p_Result := v_Entity_Name || '，无订单行资料，校验失败。';
         raise V_CCS_EXCEPTION;
     End If;
   End If;
   
   --检测营销中心编码
   If p_Result = v_Success Then
     Begin
       v_Value :='营销中心检查：';
       Select u.Code, u.Name,u.unit_id
          Into v_Sales_Center_Code, v_Sales_Center_Name,r_Pln_Lg_Order_Head.Sales_Center_Id
          From Up_Org_Unit u
         Where --u.Unit_Id = r_Pln_Lg_Order_Head.Sales_Center_Id
               U.UNIT_ID = decode(r_Pln_Lg_Order_Head.SALES_CENTER_ID,-1,U.UNIT_ID,r_Pln_Lg_Order_Head.SALES_CENTER_ID)
               --如果SALES_CENTER_ID = -1，则使用SALES_CENTER_CODE作为查询条件，否则忽略次条件 add by huanghb12
           AND U.CODE = decode(r_Pln_Lg_Order_Head.SALES_CENTER_ID,-1,r_Pln_Lg_Order_Head.SALES_CENTER_CODE,U.CODE)
           And u.Active_Flag = 'T';
      Exception
        When Others Then
          p_Result := v_Value || v_Entity_Name ||  '，营销中心不存在或者中心已失效。' || v_Nl ||
                      '中心ID='||to_char(r_Pln_Lg_Order_Head.Sales_Center_Id)||
                      ',中心编码='||r_Pln_Lg_Order_Head.Sales_Center_Code||
                      ',中心名称='||r_Pln_Lg_Order_Head.Sales_Center_Name;
          raise V_CCS_EXCEPTION;
      End;
   End If;
   --检测客户编码
    If p_Result = v_Success Then
      --客户ID为-1且客户编码不为空，用客户编码获取客户表数据
      v_Value := '客户检查：';
      if r_Pln_Lg_Order_Head.Customer_Id = -1 and r_Pln_Lg_Order_Head.Customer_Code is not null then
        begin
          Select customer_id, Customer_Code,Customer_Name
            Into r_Pln_Lg_Order_Head.Customer_Id, v_Customer_Code,v_Customer_Name
            From t_customer_header Ch
           Where Ch.Customer_Code = r_Pln_Lg_Order_Head.Customer_Code
             And Ch.Active_Flag = v_Active;
        Exception
          when others then
             p_Result := v_Value || v_Entity_Name || '，客户不存在或已失效。'||v_Nl||
                      '客户ID='||to_char(r_Pln_Lg_Order_Head.Customer_Id)||
                      ',客户编码='||r_Pln_Lg_Order_Head.Customer_Code||
                      ',客户名称='||r_Pln_Lg_Order_Head.Customer_Name;
            raise V_CCS_EXCEPTION;
        end;
      else
        begin
          --v_Value := '客户检查：';
          Select Customer_Code,Customer_Name
               Into v_Customer_Code,v_Customer_Name
          From t_customer_header Ch
          Where Ch.Customer_Id= r_Pln_Lg_Order_Head.Customer_Id
          And   Ch.Active_Flag=v_Active;
        Exception
          when others then
             p_Result := v_Value || v_Entity_Name || '，客户不存在或已失效。'||v_Nl||
                      '客户ID='||to_char(r_Pln_Lg_Order_Head.Customer_Id)||
                      ',客户编码='||r_Pln_Lg_Order_Head.Customer_Code||
                      ',客户名称='||r_Pln_Lg_Order_Head.Customer_Name;
            raise V_CCS_EXCEPTION;
        end;
      end if;
    End If;
   
   --检测账户编码
   If p_Result = v_Success Then
      Begin
        v_Value := '客户账户检查：';
        Select Ca.Account_Code, nvl(Ca.Account_Name,' '),Ca.account_id
          Into v_Account_Code, v_Account_Name,v_Account_Id
          From v_customer_account_salecenter Ca
        Where  Ca.sales_center_id = r_Pln_Lg_Order_Head.Sales_Center_Id
           And Ca.customer_id=r_Pln_Lg_Order_Head.Customer_Id
           And Ca.entity_id=r_Pln_Lg_Order_Head.Entity_Id
           And Ca.Active_Flag = v_Active
           AND ca.account_status= v_Account_Active;
        --账户ID不为空才检查，为空则直接取视图数据
        if r_Pln_Lg_Order_Head.Account_Id = -1 then
          r_Pln_Lg_Order_Head.Account_Id := v_Account_Id;
        else
          if v_Account_Id<>r_Pln_Lg_Order_Head.Account_Id then
             p_Result := v_Value || '中心客户账户对应关系有误。'||v_Nl||
                       '事业部ID='||To_Char(r_Pln_Lg_Order_Head.Entity_Id)||
                       ',事业部='||v_Entity_Name||v_Nl||
                       '中心ID='||To_Char(r_Pln_Lg_Order_Head.Sales_Center_Id)||
                       ',中心编码='||r_Pln_Lg_Order_Head.Sales_Center_Code||
                       ',中心名称='||r_Pln_Lg_Order_Head.Sales_Center_Name||v_Nl||
                       '客户ID='||To_Char(r_Pln_Lg_Order_Head.Customer_Id)||
                       ',客户编码='||r_Pln_Lg_Order_Head.Customer_Code||
                       ',客户名称='||r_Pln_Lg_Order_Head.Customer_Name||v_Nl||
                       '账户ID='||To_Char(r_Pln_Lg_Order_Head.Account_Id)||
                       ',账户编码='||r_Pln_Lg_Order_Head.account_code;
               raise V_CCS_EXCEPTION;
          end if;
        end if;
      Exception
        When Others Then
          p_Result := v_Value ||'不存在对应的账户，或账户未激活。'||v_Nl||
                      '事业部ID='||To_Char(r_Pln_Lg_Order_Head.Entity_Id)||
                       ',事业部='||v_Entity_Name||v_Nl||
                       '中心ID='||To_Char(r_Pln_Lg_Order_Head.Sales_Center_Id)||
                       ',中心编码='||r_Pln_Lg_Order_Head.Sales_Center_Code||
                       ',中心名称='||r_Pln_Lg_Order_Head.Sales_Center_Name||v_Nl||
                       '客户ID='||To_Char(r_Pln_Lg_Order_Head.Customer_Id)||
                       ',客户编码='||r_Pln_Lg_Order_Head.Customer_Code||
                       ',客户名称='||r_Pln_Lg_Order_Head.Customer_Name||v_Nl||
                       '账户ID='||To_Char(r_Pln_Lg_Order_Head.Account_Id)||
                       ',账户编码='||r_Pln_Lg_Order_Head.account_code;
          raise V_CCS_EXCEPTION;
      End;
    End If;

    --开票单位检测
    If p_Result = v_Success Then
      Begin
        v_Value := '开票联系人检查：';

        Select Tca.Contacts_Name, Tca.Contacts_Phones
          Into  v_Invoice_Contract, v_Invoice_Tel
          From t_Customer_Account_Address Ca, t_Customer_Address Tca
         Where
           ca.account_id=r_Pln_Lg_Order_Head.Account_Id
           And Tca.Contacts_Id=r_Pln_Lg_Order_Head.Invoice_Contact_Id
           And Tca.Address_Id = Ca.Address_Id
           And Tca.Address_Type = 'BillTo'
           And tca.entity_id=r_Pln_Lg_Order_Head.Entity_Id
           And ca.entity_id=r_Pln_Lg_Order_Head.Entity_Id
           And Tca.Active_Flag=v_Active;
      Exception
        When Others Then
         null;
      End;
    End If;

    --收货单位检测
    --modi by lizhen 2017-06-05 根据标志是否检查客户收货地址
    --检查收货地址有效性: A(ALL CHECK):接口、发货都检查  N(NO CHECK):都不检查 S(SHIP CHECK):发货检查、接口生成提货订单不检查
    If r_Pln_Lg_Order_Head.Is_Chk_Consinee_Address = 'A' Then
      Begin
        v_Value := '获取客户收货地址信息。';
        --modi by lizhen 2016-01-12 客户收货地点取4级地点信息
        Select Tca.Address_Id,
               Decode(v_Consignee_Add_4_Flag, 'N', nvl(tca.towns, Tca.Area), Tca.Towns), --Tca.Area,
               Tca.Address,
               Tca.Contacts_Id,
               Tca.Contacts_Name,
               Tca.Contacts_Phones,
               Tca.Preappoint_Flag
          Into v_Consignee_Id,
               v_Consignee_Addr_Code,
               v_Consignee_Addr,
               v_Consignee_Contact_Id,
               v_Consignee_Contract,
               v_Consignee_Tel,
               v_Preappoint_Flag
          From t_Customer_Account_Address Ca, t_Customer_Address Tca
         Where Ca.Account_Id   = r_Pln_Lg_Order_Head.Account_Id
           And Tca.Address_Id = r_Pln_Lg_Order_Head.Consignee_Id
           And Tca.Address_Id = Ca.Address_Id
           And Tca.Address_Type = 'ShipTo'
           And Tca.Active_Flag=v_Active;
      Exception
        When Others Then
          p_Result := v_Value || v_Entity_Name || '，账号：' ||
                      To_Char(r_Pln_Lg_Order_Head.Account_Id) ||
                      ' 收货地址ID：'||
                       To_Char(r_Pln_Lg_Order_Head.Consignee_Id) ||
                      '不存在或已失效。';
          raise V_CCS_EXCEPTION;
      End;
    Else
      if r_Pln_Lg_Order_Head.Consignee_Addr_Name is null or
         r_Pln_Lg_Order_Head.Consignee_Contract is null or
         r_Pln_Lg_Order_Head.Consignee_Tel is null or
         r_Pln_Lg_Order_Head.Consignee_Addr_Code is null
      then
        p_Result := '收货地址(Consignee_Addr_Name)、收货联系人(Consignee_Contract)、收货联系电话(Consignee_Tel)、收货地点(Consignee_Addr_Code)均不能为空。';
        raise V_CCS_EXCEPTION;
      end if;
      --add by lizhen 2017-06-05不检查地址，收货地址取接口表头
      v_Consignee_Id := r_Pln_Lg_Order_Head.Consignee_Id;
      v_Consignee_Addr := r_Pln_Lg_Order_Head.Consignee_Addr_Name;
      v_Consignee_Contact_Id := r_Pln_Lg_Order_Head.Consignee_Contact_Id;
      v_Consignee_Contract := r_Pln_Lg_Order_Head.Consignee_Contract;
      v_Consignee_Tel := r_Pln_Lg_Order_Head.Consignee_Tel;
      v_Consignee_Addr_Code := r_Pln_Lg_Order_Head.Consignee_Addr_Code;
    End If;
    
    -- add by ex_zhangka 2019-02-20 如果传递的预约标志是Y，不管收货地址，否则，取收货地址的预约标志
    If r_Pln_Lg_Order_Head.Wait_For_Preappoint_Flag = 'Y'
      Then v_Preappoint_Flag := r_Pln_Lg_Order_Head.Wait_For_Preappoint_Flag;
    End If;
    
    --收货地点检测
    Begin
      v_Value := '检查收货地点信息是否为4级地址信息。';
      Select Bd.Row_Id
        Into v_Consignment_Addr_Id
        From t_Bd_District Bd
       Where Bd.District_Code = v_Consignee_Addr_Code
         And Bd.Level_Seq = Decode(v_Consignee_Add_4_Flag, 'N', Bd.Level_Seq, 5); --add by lizhen 2016-01-12 客户收货地点取4级地点信息
    Exception
      When Others Then
         p_Result := v_Value || v_Nl || v_Entity_Name || '，收货地址ID：' || r_Pln_Lg_Order_Head.Consignee_Id || v_Nl ||
                    ' 收货地址编码：'|| To_Char(v_Consignee_Addr_Code) || v_Nl ||
                    '客户编码：' || r_Pln_Lg_Order_Head.Customer_Code || v_Nl ||
                    '账户编码：' || r_Pln_Lg_Order_Head.Account_Code || v_Nl ||
                    '无对应的收货地点信息。';
           raise V_CCS_EXCEPTION;
    End;

    --20170519 hejy3 获取CCS项目登录号
    IF r_Pln_Lg_Order_Head.Proj_Reg_Code IS NOT NULL THEN
      BEGIN
        SELECT B.ORI_BUSINESS_CODE
          INTO v_ccs_proj_reg_code
          FROM INTF_PG_BUSINESS B
         WHERE B.PROJECT_CODE = r_Pln_Lg_Order_Head.Proj_Reg_Code
           AND B.ENTITY_ID = r_Pln_Lg_Order_Head.Entity_Id
           AND ROWNUM = 1;
      EXCEPTION
        WHEN OTHERS THEN
          v_ccs_proj_reg_code := NULL;
      END;
    END IF;
    
    --获取划拨中心客户
    --优先按照接口的划拨信息设置
    IF r_Pln_Lg_Order_Head.Belong_To_Customer_Code IS NOT NULL THEN
      v_belong_to_center_id := r_Pln_Lg_Order_Head.Belong_To_Center_Id;
      v_belong_to_center_code := r_Pln_Lg_Order_Head.Belong_To_Center_Code;
      v_belong_to_center_name := r_Pln_Lg_Order_Head.Belong_To_Center_Name;
      v_belong_to_customer_id := r_Pln_Lg_Order_Head.Belong_To_Customer_Id;
      v_belong_to_customer_code := r_Pln_Lg_Order_Head.Belong_To_Customer_Code;
      v_belong_to_customer_name := r_Pln_Lg_Order_Head.Belong_To_Customer_Name;
    ELSE
      begin
        select r.transfer_center_id, r.transfer_center_code, r.transfer_center_name,
               r.transfer_customer_id, r.transfer_customer_code, r.transfer_customer_name
          into v_belong_to_center_id, v_belong_to_center_code, v_belong_to_center_name,
               v_belong_to_customer_id, v_belong_to_customer_code, v_belong_to_customer_name
          from t_pln_transfer_relation r
         where r.entity_id = r_Pln_Lg_Order_Head.Entity_Id
           and r.central_pur_customer_id = r_Pln_Lg_Order_Head.Customer_Id
           and r.address_id = v_Consignee_Id
           and sysdate between r.begin_date and nvl(r.end_date, sysdate + 1)
           and rownum = 1;
      exception
        when others then
          v_belong_to_center_id := r_Pln_Lg_Order_Head.Sales_Center_Id;
          v_belong_to_center_code := r_Pln_Lg_Order_Head.Sales_Center_Code;
          v_belong_to_center_name := r_Pln_Lg_Order_Head.Sales_Center_Name;
          v_belong_to_customer_id := r_Pln_Lg_Order_Head.Customer_Id;
          v_belong_to_customer_code := r_Pln_Lg_Order_Head.Customer_Code;
          v_belong_to_customer_name := r_Pln_Lg_Order_Head.Customer_Name;
      end;
    END IF;

    --20171225 hejy3 客户属性
    if r_Pln_Lg_Order_Head.Customer_Level is null then
      begin
        select smt.custom_level into v_Customer_Level
          from t_customer_sales_main_type smt
          where smt.custom_level is not null
            and smt.custom_id = r_Pln_Lg_Order_Head.Customer_Id
            and smt.entity_id = r_Pln_Lg_Order_Head.Entity_Id
            and smt.sales_main_type_id =
               (select min(mt.sales_main_type_id)
                  from t_customer_sales_main_type mt
                 where mt.custom_id = smt.custom_id
                   and mt.entity_id = smt.entity_id
                   and mt.custom_level is not null);
      exception
        when others then
          v_Customer_Level := null;
      end;
    else
      v_Customer_Level := r_Pln_Lg_Order_Head.Customer_Level;
    end if;
	--校验客户是否需要进行分拨  add by jiangwei29
   If r_Pln_Lg_Order_Head.Sales_Center_Id is not null and r_Pln_Lg_Order_Head.Customer_Id is not null then
     Begin
         select c.is_distribution
           into V_DISTRIBUTION_FLAG
           from cims.t_pln_special_customer c
          where c.customer_id = r_Pln_Lg_Order_Head.Customer_Id
            and c.sales_center_id = r_Pln_Lg_Order_Head.Sales_Center_Id
            and c.entity_id = r_Pln_Lg_Order_Head.Entity_Id;
       Exception
         When Others Then
           V_DISTRIBUTION_FLAG := 'N';
       End;
   End If;
   --end by jiangwei29

    ----------------------------------------------------------------------
    --  接口头表数据插入正式表
    ----------------------------------------------------------------------


    If p_Result = v_Success Then
      --修改订单头 适用退回后重新提交的情况
      --按照来源ID检查是否退回后重新提交
      BEGIN
        Select h.Order_Head_Id, h.Order_Head_State, h.Order_Number
          Into r_Pln_Lg_Order_Head.Order_Head_Id,
               v_Order_Head_State,
               r_Pln_Lg_Order_Head.Order_Number
          FROM T_PLN_LG_ORDER_HEAD H
         Where ((h.Sys_Source = r_Pln_Lg_Order_Head.Sys_Source And
               h.Source_Order_Id = r_Pln_Lg_Order_Head.Source_Order_Id and
               h.source_order_id <> -1) Or
               --add by lizhen 2017-05-12 相同来源单据时更新提货订单单头 
               --由于代销单生成的提货订单存在一对多，这里要允许来源单号相同  lilh6 2019-3-5
               (h.Sys_Source = r_Pln_Lg_Order_Head.Sys_Source And nvl(h.Sys_Source,'_') <> 'CIMSDX' And
               h.Source_Order_Number = r_Pln_Lg_Order_Head.Source_Order_Number));
      EXCEPTION
        When Too_many_rows Then
          p_Result := v_Entity_Name || '，查询来源单号在目标主体是否已存在单据。';
          raise V_CCS_EXCEPTION;
        WHEN no_data_found THEN
          r_pln_lg_order_head.Order_Head_Id := NULL;
      END;
      
      If v_Order_Head_State Not In (19, 415) Then
        IF r_Pln_Lg_Order_Head.Customer_Channel_Type   in(pkg_pln_pub.V_CUSTOMER_CHANNEL_TYPE_WP ,pkg_pln_pub.V_CUSTOMER_CHANNEL_TYPE_NIFFER,
          PKG_PLN_PUB.V_CUSTOMER_CHANNEL_TYPE_SHARE) then
          p_Result := v_Success;
          Update Intf_Pln_Lg_Order_Head Oh
             Set Oh.Intf_Status = v_Status_Sucess,
                 Oh.Error_Message = p_Result,
                 Oh.Order_Head_Id = r_Pln_Lg_Order_Head.Order_Head_Id,
                 Oh.Order_Number = r_Pln_Lg_Order_Head.Order_Number
           Where Oh.Intf_Id = r_Pln_Lg_Order_Head.Intf_Id;
          RETURN;
        else
          p_Result := v_Entity_Name || '，查询来源单号在目标主体已存在单据且单据状态不允许进行更新。' || v_Nl ||
            'CIMS提货订单号：' || r_Pln_Lg_Order_Head.Order_Number;
          raise V_CCS_EXCEPTION;
        end if;
      End If;
      
      If r_pln_lg_order_head.order_head_id is not null then

         --检测订单接口
          Begin
            v_Value := '锁定提货订单驳回状态业务表失败,订单已被锁定或状态异常！';
            Select *
              INTO r_Pln_Lg_Order_HeadLock
              From T_PLN_LG_ORDER_HEAD h
             Where h.order_head_id=r_pln_lg_order_head.order_head_id
               --And h.order_head_state = v_head_state_back
               AND h.order_head_state IN (v_head_state_init, v_head_state_back, v_head_state_capacity)
               For Update Nowait;

            v_Lg_Order_Head_Id := r_pln_lg_order_head.order_head_id;
            v_Order_Number := r_Pln_Lg_Order_HeadLock.Order_Number;
          Exception
            When Others Then
              p_Result := v_Value || v_Nl || v_Entity_Name || '，' || Sqlerrm;
              raise V_CCS_EXCEPTION;
          End;

          begin
             v_Value :='驳回后重新报送更新提货订单头表信息：';

             update T_PLN_LG_ORDER_HEAD
             set   ENTITY_ID                = r_Pln_Lg_Order_Head.Entity_Id                  ,   --主体编码
                   ORDER_TYPE_ID            = r_Pln_Order_Type.Order_Type_Id                 ,
                   ORDER_TYPE_CODE          = r_Pln_Order_Type.Order_Type_Code               ,    --单据类型
                   ORDER_TYPE_NAME          = r_Pln_Order_Type.Order_Type_Name               ,
                   SALES_YEAR_ID            = null                                           ,   --销售年度
                   PERIOD_ID                = null                                           ,   --周期ID
                   PERIOD_CODE              = null                                           ,   --周期编码
                   ORDER_HEAD_STATE         = decode(ORDER_HEAD_STATE, v_head_state_capacity, v_head_state_capacity, v_head_state_init),
                   FORM_STATE               = null                                           ,   --表单状态，计划订单使用
                   SALES_CENTER_ID          = r_Pln_Lg_Order_Head.Sales_Center_Id            ,
                   SALES_CENTER_CODE        = v_Sales_Center_Code                            ,   --营销中心
                   SALES_CENTER_NAME        = v_Sales_Center_Name                            ,
                   CUSTOMER_ID              = r_Pln_Lg_Order_Head.Customer_Id                ,
                   CUSTOMER_CODE            = v_Customer_Code                                ,   --客户信息
                   CUSTOMER_NAME            = v_Customer_Name                                ,
                   --ACCOUNT_ID               = r_Pln_Lg_Order_Head.Account_Id                 ,
                   ACCOUNT_ID               = v_Account_Id,
                   ACCOUNT_CODE             = v_Account_Code                                 ,   --账户信息
                   ACCOUNT_NAME             = v_Account_Name                                 ,
                   --2017117 hejy3 营销大类取变量值
                   SALES_MAIN_TYPE          = v_SALES_MAIN_TYPE,--Decode(v_Item_Main_Type_Filter, 'Y', v_SALES_MAIN_TYPE, Null),        --营销大小类
                   SALES_SUB_TYPE           = Decode(v_Item_Sub_Type_Filter, 'Y', r_Pln_Lg_Order_Head.Sales_Sub_Type, Null) , --modi by lizhen 2017-05-26
                   ORDER_EFFECTIVE_DATE     = r_Pln_Lg_Order_Head.Order_Effective_Date       ,
                   SOURCE_ORDER_ID          = r_Pln_Lg_Order_Head.Source_Order_Id            ,             --SOURCE_ORDER_ID 来源订单ID
                   SOURCE_ORDER_NUMBER      = r_Pln_Lg_Order_Head.SOURCE_ORDER_NUMBER        ,             --SOURCE_ORDER_NUMBER 来源订单号
                   CUSTOMER_ORDER_NUMBER    = r_Pln_Lg_Order_Head.Customer_Order_Number      ,             --客户订单号（电商订单）
                   CUSTOMER_ORDER_DATE      = r_Pln_Lg_Order_Head.Customer_Order_Date        ,             --客户订单日期
                   EXIGENCE                 = r_Pln_Lg_Order_Head.Exigence                   ,             --紧急程度
                   TRUN_FLAG                = 'N'                                            ,             --是否结转
                   SHIP_MODE                = r_Pln_Lg_Order_Head.Ship_Mode                  ,             --发运方式
                   PROJECT_ORDER_FLAG       = r_Pln_Lg_Order_Head.Project_Order_Flag         ,             --工程项目标示
                   PROJECT_NUMBER           = r_Pln_Lg_Order_Head.Project_Number             ,             --工程项目编号
                   DIRECT_SEND_FLAG         = r_Pln_Lg_Order_Head.Direct_Send_Flag           ,             --直发标志
                   IS_NEED_BILL             = r_Pln_Lg_Order_Head.Is_Need_Bill               ,             --是否需要随货同行联（厨电）
                   CLIENT_CARRY_FLAG        = r_Pln_Lg_Order_Head.Client_Carry_Flag          ,             --是否客户自提
                   ORDER_DATE               = r_Pln_Lg_Order_Head.Order_Date                 ,             --订单日期
                   INVOICE_CUSTOMER_ID      = r_Pln_Lg_Order_Head.Customer_Id                ,             --INVOICE_CUSTOMER_ID 开票客户ID
                   INVOICE_CUSTOMER_CODE    = v_Customer_Code                                ,             --INVOICE_CUSTOMER_CODE 开票客户编码
                   INVOICE_CUSTOMER_NAME    = v_Customer_Name                                ,             --INVOICE_CUSTOMER_NAME 开票客户名称
                   INVOICE_CONTACT_ID       = r_Pln_Lg_Order_Head.Invoice_Contact_Id         ,             --INVOICE_CONTACT_ID 开票单位联系人ID
                   INVOICE_CONTRACT         = v_Invoice_Contract                             ,             --INVOICE_CONTRACT 开票单位联系人
                   INVOICE_TEL              = v_Invoice_Tel                                  ,             --INVOICE_TEL 开票单位电话
                   INVENTORY_TO_ID          = r_Pln_Lg_Order_Head.Inventory_To_Id            ,             --收货仓id add by huanghb12
                   RCV_INV_CODE             = r_Pln_Lg_Order_Head.Rcv_Inv_Code               ,             --收货仓库编码 add by huanghb12
                   RCV_INV_NAME             = r_Pln_Lg_Order_Head.Rcv_Inv_Name               ,             --收货仓库名称 add by huanghb12
                   CONSIGNEE_ID             = v_Consignee_Id                                 ,             --CONSIGNEE_ID 收货单位ID
                   CONSIGNEE_CODE           = v_Customer_Code                                ,             --CONSIGNEE_CODE 收货单位编码
                   CONSIGNEE_NAME           = v_Customer_Name                                ,             --CONSIGNEE_NAME 收货单位名称
                   CONSIGNEE_ADDR_NAME      = v_Consignee_Addr                               ,             --CONSIGNEE_ADDR_NAME 收货单位地址
                   CONSIGNEE_EXTEND_ADDR    = r_Pln_Lg_Order_Head.Consignee_Extend_Addr      ,             --CONSIGNEE_EXTEND_ADDR 收货扩展地址（主要应用与工程机）
                   CONSIGNMENT_ADD_ID       = v_Consignment_Addr_Id                          ,             --CONSIGNMENT_ADD_ID 收货地点ID
                   CONSIGNEE_ADDR_CODE      = v_Consignee_Addr_Code                          ,             --CONSIGNEE_ADDR_CODE 收货单位地址编码（物流根据该编码选择承运商）
                   CONSIGNEE_CONTACT_ID     = v_Consignee_Contact_Id                         ,             --CONSIGNEE_CONTACT_ID 收货单位联系人ID
                   CONSIGNEE_CONTRACT       = v_Consignee_Contract                           ,             --CONSIGNEE_CONTRACT 收货单位联系人
                   CONSIGNEE_TEL            = v_Consignee_Tel                                ,             --CONSIGNEE_TEL 收货单位联系电话
                   WAIT_FOR_PREAPPOINT_FLAG = v_Preappoint_Flag                              ,             --WAIT_FOR_PREAPPOINT_FLAG 预约标志（根据客户收货地址获取）
                   TRANSFER_CUSTOMER_ID     = r_Pln_Lg_Order_Head.TRANSFER_CUSTOMER_ID       ,                       --分部客户ID（冰洗客户订单所属ID）
                   SYS_SOURCE               = r_Pln_Lg_Order_Head.SYS_SOURCE                 ,                       --系统来源
                   CREATED_BY               = 'PKG_PLN_INTF_CCS'                             ,
                   CREATION_DATE            = sysdate                                        ,
                   LAST_UPDATED_BY          = 'PKG_PLN_INTF_CCS'                             ,
                   LAST_UPDATE_DATE         = sysdate                                        ,
                   REMARK                   = r_Pln_Lg_Order_Head.REMARK                     ,
                   PRE_FIELD_01             = r_Pln_Lg_Order_Head.PRE_FIELD_01               ,
                   PRE_FIELD_02             = r_Pln_Lg_Order_Head.PRE_FIELD_02               ,
                   PRE_FIELD_03             = r_Pln_Lg_Order_Head.PRE_FIELD_03               ,
                   PRE_FIELD_04             = r_Pln_Lg_Order_Head.PRE_FIELD_04               ,
                   PRE_FIELD_05             = r_Pln_Lg_Order_Head.PRE_FIELD_05               ,
                   PRE_FIELD_06             = r_Pln_Lg_Order_Head.PRE_FIELD_06               ,
                   PREFERENTIAL_FLAG        = r_Pln_Lg_Order_Head.PREFERENTIAL_FLAG          ,                       --优惠品标示
                   PROGRAM_UPDATED_BY       = 'PKG_PLN_INTF_CCS'                             ,
                   PROGRAM_UPDATE_DATE      = sysdate                                        ,
                   proj_reg_code            = r_Pln_Lg_Order_Head.Proj_Reg_Code              ,                        --商机登陆编码
                   --200160920 接口状态为Q时取接口状态，否则取原单状态
                   APS_CAPACITY_STATE       = decode(r_Pln_Lg_Order_Head.Aps_Capacity_State, 'Q', r_Pln_Lg_Order_Head.Aps_Capacity_State, r_Pln_Lg_Order_HeadLock.Aps_Capacity_State),                --APS产能可视处理标识（N: 未引入 P: 处理中 S：处理完成 Q：排队中）
                   e_platform               = r_Pln_Lg_Order_Head.e_Platform                 ,              --平台信息
                   CONSIGNMENT_DATE         = r_Pln_Lg_Order_Head.Consignment_Date           ,                --期望到货日期
                   m_task_complete_rate     = r_Pln_Lg_Order_Head.m_Task_Complete_Rate       ,                --月度任务完成比
                   ccs_proj_reg_code        = v_ccs_proj_reg_code, --20170519 hejy3 项目登录号
									 Carload_Meet_Num         = r_Pln_Lg_Order_Head.Carload_Meet_Num,   --add by lizhen 2017-05-12 齐套号
                   Sys_Origin               = decode(r_Pln_Lg_Order_Head.Sys_Origin,null,r_Pln_Lg_Order_Head.Sys_Source,r_Pln_Lg_Order_Head.Sys_Origin),  --上级来源系统 add by 2017-05-26
                   Origin_Order_Id          = decode(r_Pln_Lg_Order_Head.Origin_Order_Id,null,r_Pln_Lg_Order_Head.Source_Order_Id,r_Pln_Lg_Order_Head.Origin_Order_Id),  --上级来源头ID add by 2017-05-26
                   Origin_Order_Number      = decode(r_Pln_Lg_Order_Head.Origin_Order_Number,null,r_Pln_Lg_Order_Head.Source_Order_Number,r_Pln_Lg_Order_Head.Origin_Order_Number), --上级来源单号 add by 2017-05-26
                   Agent_Customer_Id        = r_Pln_Lg_Order_Head.Agent_Customer_Id, --代理商ID add by 2017-06-14
                   Agent_Customer_Code      = r_Pln_Lg_Order_Head.Agent_Customer_Code, --代理商编码 add by 2017-06-14
                   Agent_Customer_Name      = r_Pln_Lg_Order_Head.Agent_Customer_Name, --代理商名称 add by 2017-06-14
				   Distribute_Customer_Code = r_Pln_Lg_Order_Head.Distribute_Customer_Code, -- 分销门店编码  jiangwe29 2019-04-28
                   Distribute_Customer_Name = r_Pln_Lg_Order_Head.Distribute_Customer_Name, -- 分销门店名称  jiangwe29 2019-04-28
                   IS_CHK_CONSINEE_ADDRESS  = r_Pln_Lg_Order_Head.Is_Chk_Consinee_Address, --是否检查发货地址 ADD BY LIZHEN 2017-06-05
                   Ori_Sys_Source           = r_Pln_Lg_Order_Head.Ori_Sys_Source --CCS APP系统来源 add by lizhen 2017-06-05               
                   ,belong_to_center_id     = v_belong_to_center_id
                   ,belong_to_center_code   = v_belong_to_center_code
                   ,belong_to_center_name   = v_belong_to_center_name
                   ,belong_to_customer_id   = v_belong_to_customer_id
                   ,belong_to_customer_code = v_belong_to_customer_code
                   ,belong_to_customer_name = v_belong_to_customer_name
                   ,Customer_Level           = v_Customer_Level
                   ,sup_req_entity_flag     = r_Pln_Lg_Order_Head.Sup_Req_Entity_Flag
                   ,LG_PROCESS_TYPE         = DECODE(r_Pln_Lg_Order_Head.Customer_Channel_Type, '15', 'WP','17','NIFFER', r_Pln_Lg_Order_Head.Lg_Process_Type)
                   ,CUSTOMER_CHANNEL_TYPE   = r_Pln_Lg_Order_Head.Customer_Channel_Type
                   ,PAYMENT_FLAG            = r_Pln_Lg_Order_Head.Payment_Flag
                   ,FUND_CHECK_MODE         = r_Pln_Lg_Order_Head.Fund_Check_Mode
				   ,RERENT_TYPE             = r_Pln_Lg_Order_Head.Rerent_Type   -- 续租时长  jiangwei29
		   ,pln_order_number        = r_Pln_Lg_Order_Head.Pln_Order_Number     --add by huanghb12 2018-09-26 ccs推送的计划订单编号
		   ,LG_DISTRIBUTION_FLAG    = V_DISTRIBUTION_FLAG --add by jiangwei29 2019-5-16 分拨标识
              where  ORDER_HEAD_ID=r_pln_lg_order_head.order_head_id;
          exception
              When Others Then
              p_Result := v_Value||v_Entity_Name || '，单号ID '||r_pln_lg_order_head.order_head_id||
              '，失败。' || v_Nl || Sqlerrm;
                raise V_CCS_EXCEPTION;
          End;
      else

        --生成订单号
        Begin
          --网批订单用特定编号规则
          if r_Pln_Lg_Order_Head.Customer_Channel_Type   in(pkg_pln_pub.V_CUSTOMER_CHANNEL_TYPE_WP ) then
            pkg_bd.P_GET_BILL_NO(P_BILL_TYPE  => 'plnLgOrderWP',
                                 P_PREFIX_ADD => null,
                                 P_ENTITY_ID  => r_pln_lg_order_head.entity_id,
                                 P_USER_ID    => 0,
                                 P_BILL_NO    => v_Order_Number);
          else
            Pkg_Pln_Pub.p_Create_Order_Number(p_Order_Number_Type => 'plnLgOrder', --单据编码规则
                                              p_Period_Id         => 0,
                                              p_Sales_Center_Id   => r_pln_lg_order_head.sales_center_id,
                                              p_Entity_Id         => r_pln_lg_order_head.Entity_Id,
                                              p_Order_Number      => v_Order_Number);
          end if;

          If Nvl(v_Order_Number, '_') = '_' Then
            p_Result := v_Entity_Name || '，获取客户订单单号失败，单号编码规则：plnLgOrder。';
              raise V_CCS_EXCEPTION;
          End If;
        Exception
          When Others Then
            p_Result := v_Entity_Name || '，获取客户订单单号失败，单号编码规则：plnLgOrder。';
              raise V_CCS_EXCEPTION;
        End;
        --新增订单头
        Begin
            Select s_pln_lg_order_head.Nextval Into v_Lg_Order_Head_Id From Dual;

            IF (r_Pln_Lg_Order_Head.Book_Type = 'JD') THEN
              V_HEADER_REMARK := r_Pln_Lg_Order_Head.REMARK || '  配送中心：' || r_Pln_Lg_Order_Head.Distribution_Center_Name
                  || '，配送仓库：' || r_Pln_Lg_Order_Head.Distribution_Warehouse_Name
                  || '，期望到货日期：' || TO_CHAR(r_Pln_Lg_Order_Head.EXPECTED_CLOSING_TIME,'yyyy-MM-dd');
            ELSE
              V_HEADER_REMARK := r_Pln_Lg_Order_Head.REMARK;
            END IF;

            v_Value := '开始插入提货订单头表信息：'; 

            insert into T_PLN_LG_ORDER_HEAD
              (ENTITY_ID,       -- 主体ID
               ORDER_HEAD_ID,   -- 订单头ID
               ORDER_NUMBER,    -- 订单编码
               ORDER_TYPE_ID,
               ORDER_TYPE_CODE, --订单类型
               ORDER_TYPE_NAME,
               SALES_YEAR_ID,   --销售年度
               PERIOD_ID,       --周期
               PERIOD_CODE,
               ORDER_HEAD_STATE,   --订单状态，提货订单使用
               FORM_STATE,         --订单状态，计划订单使用
               SALES_CENTER_ID,    --营销中心
               SALES_CENTER_CODE,
               SALES_CENTER_NAME,
               CUSTOMER_ID,        --客户信息
               CUSTOMER_CODE,
               CUSTOMER_NAME,
               ACCOUNT_ID,         --账户信息
               ACCOUNT_CODE,
               ACCOUNT_NAME,
               SALES_MAIN_TYPE,    --营销大类*
               SALES_SUB_TYPE,     --营销小类
               ORDER_EFFECTIVE_DATE,           --订单有效期
               SOURCE_ORDER_ID,                --来源订单ID
               SOURCE_ORDER_NUMBER,            --来源订单号
               CUSTOMER_ORDER_NUMBER,          --客户订单号（电商订单）
               CUSTOMER_ORDER_DATE,            --客户订单号
               EXIGENCE,                       --紧急程度
               TRUN_FLAG,                      --是否结转
               LOCK_INV_FLAG,                  --是否锁定库存
               LOCK_AMOUNT_FLAG,               --是否锁定余款
               TO_PLAN_FLAG,                   --是否生产运力计划
               SHIP_MODE,                      --发运方式*
               PROJECT_ORDER_FLAG,             --工程项目标示
               PROJECT_NUMBER,                 --工程项目编号
               DIRECT_SEND_FLAG,               --直发标志*
               IS_NEED_BILL,                   --是否需要随货同行联（厨电）
               CLIENT_CARRY_FLAG,              --是否客户自提
               SHIP_FLAG,                      --是否确认发货（返写，该订单是否发货）
               CANCEL_FLAG,                    --是否取消（评审时，关闭订单，小电结案标识）
               LINK_PIPE_FLAG,                 --是否含连接管
               FINANCE_FLAG,                   --是否开单完毕（回写）
               ORDER_DATE,                     --订单日期
               INVOICE_CUSTOMER_ID,            --开票客户ID
               INVOICE_CUSTOMER_CODE,          --开票客户编码
               INVOICE_CUSTOMER_NAME,          --开票客户名称
               INVOICE_CONTACT_ID,             --开票单位联系人ID
               INVOICE_CONTRACT,               --开票单位联系人
               INVOICE_TEL,                    --开票单位电话
               INVENTORY_TO_ID,                 --收货仓库ID  add by huanghb12
               RCV_INV_CODE,                   --收货仓库编码 add by huanghb12
               RCV_INV_NAME,                   --收货仓库名称 add by huanghb12
               CONSIGNEE_ID,                   --收货单位ID
               CONSIGNEE_CODE,                 --收货单位编码
               CONSIGNEE_NAME,                 --收货单位名称
               CONSIGNEE_ADDR_NAME,            --收货单位地址
               CONSIGNEE_EXTEND_ADDR,          --收货扩展地址（主要应用与工程机）
               CONSIGNMENT_ADD_ID,             --收货地点ID
               CONSIGNEE_ADDR_CODE,            --收货单位地址编码（物流根据该编码选择承运商）
               CONSIGNEE_CONTACT_ID,           --收货单位联系人ID
               CONSIGNEE_CONTRACT,             --收货单位联系人
               CONSIGNEE_TEL,                  --收货单位联系电话
               TRANSFER_CUSTOMER_ID,           --分部客户ID（冰洗客户订单所属ID）
               SYS_SOURCE,                     --系统来源
               CREATED_BY,
               CREATION_DATE,
               LAST_UPDATED_BY,
               LAST_UPDATE_DATE,
               REMARK,
               PRE_FIELD_01,
               PRE_FIELD_02,
               PRE_FIELD_03,
               PRE_FIELD_04,
               PRE_FIELD_05,
               PRE_FIELD_06,
               PREFERENTIAL_FLAG,              --优惠品标示
               PROGRAM_UPDATED_BY,
               PROGRAM_UPDATE_DATE,
               SHIP_TYPE,                      --发货类型
               PROJ_REG_CODE,        --商机登陆编码
               APS_CAPACITY_STATE,   --APS产能可视处理标识（N: 未引入 P: 处理中 S：处理完成 Q：排队中）
               e_platform,        --平台信息
               CONSIGNMENT_DATE,   --期望到货日期
               M_task_complete_rate, --月度任务完成比
               ccs_proj_reg_code, --20170519 hejy3 项目登录号
							 Carload_Meet_Num,  --齐套号 add by lizhen 2017-05-12
               Sys_Origin,  --上级来源系统 add by 2017-05-26
               Origin_Order_Id,  --上级来源头ID add by 2017-05-26
               Origin_Order_Number, --上级来源单号 add by 20
               Agent_Customer_Id, --代理商ID add by 2017-06-14
               Agent_Customer_Code, --代理商编码 add by 2017-06-14
               Agent_Customer_Name, --代理商名称 add by 2017-06-14
			   Distribute_Customer_Code, --分销门店编码  jiangwei29 2019-04-28
               Distribute_Customer_Name, --分销门店名称  jiangwei29 2019-04-28
               IS_CHK_CONSINEE_ADDRESS, --是否检查收货地址 add by lizhen 2017-06-05 
               ORI_SYS_SOURCE  --CCS APP系统来源 add by lizhen 2017-06-05
               ,belong_to_center_id
               ,belong_to_center_code
               ,belong_to_center_name
               ,belong_to_customer_id
               ,belong_to_customer_code
               ,belong_to_customer_name
               ,Customer_Level
               ,sup_req_entity_flag    --按供需关系跨主体结转标志 lilh6 2018-8-28
	       ,BOOK_TYPE                    --COMMON 常规；TMALL 天猫 ADD BY huanghb12 2018-09-12
               ,WAIT_FOR_PREAPPOINT_FLAG     --待预约标志 ADD BY huanghb12 2018-09-12
               ,LG_PROCESS_TYPE
	       ,pln_order_number             --add by huanghb12 2018-09-26 ccs推送的计划订单编号
               ,CUSTOMER_CHANNEL_TYPE
               ,PAYMENT_FLAG
               ,FUND_CHECK_MODE
               ,Distribution_Center_Name
               ,Distribution_Center_Code
               ,Distribution_Warehouse_Name
               ,Distribution_Warehouse_Code
               ,ORIGIN_VERNDOR_CODE
               ,ORIGIN_VERNDOR_NAME
               ,EXPECTED_CLOSING_TIME
               ,ORIGIN_SALES_TYPE_CODE          --外部系统(天猫)品类编码
               ,ORIGIN_SALES_TYPE_NAME          --外部系统(天猫)品类名称
	       ,LG_DISTRIBUTION_FLAG     --add by jiangwei29 2019-5-16 分拨标识
               ,ORIGIN_SERVICE_ITEM_ID          --服务商品ID(天猫库容可视接口用到，生活电器在天猫内部处理时区分多个服务商品)
			   ,RERENT_TYPE        -- 续租时长  jiangwei29
			,isentryhome   --是否送货入户  ex_wangkang4 20200511
               ,Total_Number  --总单数量  ex_wangkang4 20200511
	       )   
            values
              (r_Pln_Lg_Order_Head.Entity_Id,  --主体编码
               v_Lg_Order_Head_Id,             --订单头ID
               v_Order_Number,                 --订单编号
               r_Pln_Order_Type.Order_Type_Id,
               r_Pln_Order_Type.Order_Type_Code,--单据类型
               r_Pln_Order_Type.Order_Type_Name,
               null,                           --销售年度
               null,                           --周期ID
               null,                           --周期编码
               v_head_state_init,              --单据状态，默认制单状态
               null,                           --表单状态，计划订单使用
               r_Pln_Lg_Order_Head.Sales_Center_Id,
               v_Sales_Center_Code,            --营销中心
               v_Sales_Center_Name,
               r_Pln_Lg_Order_Head.Customer_Id,
               v_Customer_Code,                --客户信息
               v_Customer_Name,
               --r_Pln_Lg_Order_Head.Account_Id,
               v_Account_Id,
               v_Account_Code,                 --账户信息
               v_Account_Name,
               --2017117 hejy3 营销大类取变量值
               v_SALES_MAIN_TYPE,--Decode(v_Item_Main_Type_Filter, 'Y', v_SALES_MAIN_TYPE, Null), --营销大小类
               Decode(v_Item_Sub_Type_Filter, 'Y', r_Pln_Lg_Order_Head.Sales_Sub_Type, Null), --营销小类
               r_Pln_Lg_Order_Head.Order_Effective_Date,
               r_Pln_Lg_Order_Head.Source_Order_Id,      --SOURCE_ORDER_ID 来源订单ID
               r_Pln_Lg_Order_Head.SOURCE_ORDER_NUMBER,  --SOURCE_ORDER_NUMBER 来源订单号
               r_Pln_Lg_Order_Head.Customer_Order_Number,--客户订单号（电商订单）
               r_Pln_Lg_Order_Head.Customer_Order_Date,  --客户订单日期
               r_Pln_Lg_Order_Head.Exigence,             --紧急程度
               'N',                                      --是否结转
               r_Pln_Order_Type.Is_Lock_Inv_Flag,        --是否锁定库存
               'N',                                      --是否锁定余款
               'N',                                      --是否生产运力计划
               r_Pln_Lg_Order_Head.Ship_Mode,            --发运方式
               r_Pln_Lg_Order_Head.Project_Order_Flag,   --工程项目标示
               r_Pln_Lg_Order_Head.Project_Number,       --工程项目编号
               r_Pln_Lg_Order_Head.Direct_Send_Flag,     --直发标志
               r_Pln_Lg_Order_Head.Is_Need_Bill,         --是否需要随货同行联（厨电）
               r_Pln_Lg_Order_Head.Client_Carry_Flag,    --是否客户自提
               'N',                                      --SHIP_FLAG  是否确认发货（返写，该订单是否发货）
               'N',                                      --CANCEL_FLAG 是否取消（评审时，关闭订单，小电结案标识）
               'N',                                      --LINK_PIPE_FLAG 是否含连接管
               'N',                                      --FINANCE_FLAG 是否开单完毕（回写）
               r_Pln_Lg_Order_Head.Order_Date,           --订单日期
               r_Pln_Lg_Order_Head.Customer_Id,          --INVOICE_CUSTOMER_ID 开票客户ID
               v_Customer_Code,                          --INVOICE_CUSTOMER_CODE 开票客户编码
               v_Customer_Name,                          --INVOICE_CUSTOMER_NAME 开票客户名称
               r_Pln_Lg_Order_Head.Invoice_Contact_Id,   --INVOICE_CONTACT_ID 开票单位联系人ID
               v_Invoice_Contract,                       --INVOICE_CONTRACT 开票单位联系人
               v_Invoice_Tel,                            --INVOICE_TEL 开票单位电话
               r_Pln_Lg_Order_Head.INVENTORY_TO_ID,       --收货仓库ID  add by huanghb12
               r_Pln_Lg_Order_Head.RCV_INV_CODE,         --收货仓库编码 add by huanghb12
               r_Pln_Lg_Order_Head.RCV_INV_NAME,         --收货仓库名称 add by huanghb12
               v_Consignee_Id,                           --CONSIGNEE_ID 收货单位ID
               v_Customer_Code,                          --CONSIGNEE_CODE 收货单位编码
               v_Customer_Name,                          --CONSIGNEE_NAME 收货单位名称
               v_Consignee_Addr,                         --CONSIGNEE_ADDR_NAME 收货单位地址
               r_Pln_Lg_Order_Head.Consignee_Extend_Addr,--CONSIGNEE_EXTEND_ADDR 收货扩展地址（主要应用与工程机）
               v_Consignment_Addr_Id,                    --CONSIGNMENT_ADD_ID 收货地点ID
               v_Consignee_Addr_Code,                    --CONSIGNEE_ADDR_CODE 收货单位地址编码（物流根据该编码选择承运商）
               v_Consignee_Contact_Id,                   --CONSIGNEE_CONTACT_ID 收货单位联系人ID
               v_Consignee_Contract,                     --CONSIGNEE_CONTRACT 收货单位联系人
               v_Consignee_Tel,                          --CONSIGNEE_TEL 收货单位联系电话
               r_Pln_Lg_Order_Head.TRANSFER_CUSTOMER_ID,           --分部客户ID（冰洗客户订单所属ID）
               r_Pln_Lg_Order_Head.SYS_SOURCE,                     --系统来源
               'PKG_PLN_INTF_CCS',
               sysdate,
               'PKG_PLN_INTF_CCS',
               sysdate,
               V_HEADER_REMARK,
               r_Pln_Lg_Order_Head.PRE_FIELD_01,
               r_Pln_Lg_Order_Head.PRE_FIELD_02,
               r_Pln_Lg_Order_Head.PRE_FIELD_03,
               r_Pln_Lg_Order_Head.PRE_FIELD_04,
               r_Pln_Lg_Order_Head.PRE_FIELD_05,
               r_Pln_Lg_Order_Head.PRE_FIELD_06,
               r_Pln_Lg_Order_Head.PREFERENTIAL_FLAG,              --优惠品标示
               'PKG_PLN_INTF_CCS',
               sysdate,
               '01',                                              --发运类型（01工厂发货 02省内发货 03直发超市 04异地调拨）
                r_Pln_Lg_Order_Head.Proj_Reg_Code,
                r_Pln_Lg_Order_Head.Aps_Capacity_State,
                r_Pln_Lg_Order_Head.e_Platform,
                nvl(r_Pln_Lg_Order_Head.Consignment_Date,r_Pln_Lg_Order_Head.EXPECTED_CLOSING_TIME),
                r_Pln_Lg_Order_Head.m_Task_Complete_Rate,
								v_ccs_proj_reg_code, --20170519 hejy3 项目登录号
                r_Pln_Lg_Order_Head.Carload_Meet_Num,   --add by lizhen 2017-05-12
                decode(r_Pln_Lg_Order_Head.Sys_Origin,null,r_Pln_Lg_Order_Head.Sys_Source,r_Pln_Lg_Order_Head.Sys_Origin),  --上级来源系统 add by 2017-05-26
                decode(r_Pln_Lg_Order_Head.Origin_Order_Id,null,r_Pln_Lg_Order_Head.Source_Order_Id,r_Pln_Lg_Order_Head.Origin_Order_Id),  --上级来源头ID add by 2017-05-26
                decode(r_Pln_Lg_Order_Head.Origin_Order_Number,null,r_Pln_Lg_Order_Head.Source_Order_Number,r_Pln_Lg_Order_Head.Origin_Order_Number), --上级来源单号 add by 2017-05-26
                r_Pln_Lg_Order_Head.Agent_Customer_Id, --代理商ID add by 2017-06-14
                r_Pln_Lg_Order_Head.Agent_Customer_Code, --代理商编码 add by 2017-06-14
                r_Pln_Lg_Order_Head.Agent_Customer_Name, --代理商名称 add by 2017-06-14
				r_Pln_Lg_Order_Head.Distribute_Customer_Code, --分销门店编码 jiangwei29 2019-04-28
                r_Pln_Lg_Order_Head.Distribute_Customer_Name, --分销门店名称 jiangwei29 2019-04-28
                r_Pln_Lg_Order_Head.Is_Chk_Consinee_Address, --是否检查收货地址 add by lizhen 2017-06-05
                r_Pln_Lg_Order_Head.Ori_Sys_Source  --CCS APP系统来源 add by lizhen 2017-06-05 
                ,v_belong_to_center_id
                ,v_belong_to_center_code
                ,v_belong_to_center_name
                ,v_belong_to_customer_id
                ,v_belong_to_customer_code
                ,v_belong_to_customer_name
                ,v_Customer_Level
                ,r_Pln_Lg_Order_Head.Sup_Req_Entity_Flag
		,r_Pln_Lg_Order_Head.Book_Type                    --COMMON 常规；TMALL 天猫 ADD BY huanghb12 2018-09-12
                --,r_Pln_Lg_Order_Head.Wait_For_Preappoint_Flag     --待预约标志 ADD BY huanghb12 2018-09-12
                ,v_Preappoint_Flag                        --WAIT_FOR_PREAPPOINT_FLAG 预约标志（根据客户收货地址获取）
                ,DECODE(r_Pln_Lg_Order_Head.Customer_Channel_Type, '15', 'WP', r_Pln_Lg_Order_Head.Lg_Process_Type)
		,r_Pln_Lg_Order_Head.Pln_Order_Number             --add by huanghb12 2018-09-26 ccs推送的计划订单编号
                ,r_Pln_Lg_Order_Head.Customer_Channel_Type
                ,r_Pln_Lg_Order_Head.Payment_Flag
                ,r_Pln_Lg_Order_Head.Fund_Check_Mode
                ,r_Pln_Lg_Order_Head.Distribution_Center_Name
                ,r_Pln_Lg_Order_Head.Distribution_Center_Code
                ,r_Pln_Lg_Order_Head.Distribution_Warehouse_Name
                ,r_Pln_Lg_Order_Head.Distribution_Warehouse_Code
                ,r_Pln_Lg_Order_Head.ORIGIN_VERNDOR_CODE
                ,r_Pln_Lg_Order_Head.ORIGIN_VERNDOR_NAME
                ,r_Pln_Lg_Order_Head.EXPECTED_CLOSING_TIME
                ,r_Pln_Lg_Order_Head.PRE_FIELD_09            --外部系统(天猫)品类编码
                ,r_Pln_Lg_Order_Head.PRE_FIELD_10            --外部系统(天猫)品类名称
		,V_DISTRIBUTION_FLAG     --add by jiangwei29 2019-5-16 分拨标识
                ,r_Pln_Lg_Order_Head.PRE_FIELD_13            --服务商品ID(天猫库容可视接口用到，生活电器在天猫内部处理时区分多个服务商品)
				,r_Pln_Lg_Order_Head.Rerent_Type   -- 续租时长  jiangwei29
		        ,r_Pln_Lg_Order_Head.Isentryhome  --是否送货入户 ex_wangkang4 20200511
        ,r_Pln_Lg_Order_Head.Total_Number --总单数量   ex_wangkang4 20200511
                );

               --更新接口表数据
               update Intf_Pln_Lg_Order_Head h set h.order_head_id= v_Lg_Order_Head_Id,             --订单头ID
               h.order_number=v_Order_Number where h.intf_id=p_Intf_Id;
              Exception
                When Others Then
                  p_Result := v_Value || '，失败。' || v_Entity_Name || v_Nl || Sqlerrm;
                    raise V_CCS_EXCEPTION;
              End;
        End if;
    End If;

    ----------------------------------------------------------------------
    --  接口数据行表数据检测
    ----------------------------------------------------------------------
    --20160330 何加源 重新获取折扣参数
    V_RESET_DIS_FLAG := PKG_BD.F_GET_PARAMETER_VALUE('PLN_LG_ORDER_FROM_CCS_RESET_DIS', r_Pln_Lg_Order_Head.Entity_Id);

    --检测并将接口表行数据插入业务表
    If p_Result = v_Success THEN
       IF r_Pln_Lg_Order_Head.Order_Head_Id IS NOT NULL THEN
         --先删除0数量产品
         INSERT INTO T_PLN_LINE_DEL_HIS
           (DEL_HIS_ID,
            ENTITY_ID,
            ORIGIN_TYPE,
            ORDER_LINE_ID,
            ORDER_HEAD_ID,
            ITEM_ID,
            ITEM_CODE,
            ITEM_NAME,
            LIST_PRICE,
            QUANTITY,
            DISCOUNT_RATE,
            ORDERED_DISCOUNT_RATE,
            PROJECT_ORDER_TYPE,
            PROJECT_ORDER_NUMBER,
            PROJECT_ORDER_LINE_ID,
            APPLY_LIST_PRICE,
            APPLY_DISCOUNT_RATE,
            SOURCE_TYPE,
            SOURCE_LINE_ID,
            TO_APS_CAPACITY_QTY,
            APS_CAPACITY_REC_QTY,
            APS_CAPACITY_REC_DATE,
            APS_CAPACITY_INTF_FLAG,
            PRODUCING_AREA_ID,
            PRODUCING_AREA_CODE,
            PRODUCING_AREA_NAME,
            CREATED_BY,
            CREATION_DATE,
            LAST_UPDATED_BY,
            LAST_UPDATE_DATE,
            REMARK,
            PRE_FIELD_01,
            PRE_FIELD_02,
            PRE_FIELD_03,
            PRE_FIELD_04,
            PRE_FIELD_05,
            PRE_FIELD_06,
            PROGRAM_UPDATED_BY,
            PROGRAM_UPDATE_DATE)
           SELECT S_PLN_LINE_DEL_HIS.NEXTVAL,
                  L.ENTITY_ID,
                  'LG_ORDER',
                  L.ORDER_LINE_ID,
                  L.ORDER_HEAD_ID,
                  L.ITEM_ID,
                  L.ITEM_CODE,
                  L.ITEM_NAME,
                  L.LIST_PRICE,
                  L.QUANTITY,
                  L.DISCOUNT_RATE,
                  L.ORDERED_DISCOUNT_RATE,
                  L.PROJECT_ORDER_TYPE,
                  L.PROJECT_ORDER_NUMBER,
                  L.PROJECT_ORDER_LINE_ID,
                  L.APPLY_LIST_PRICE,
                  L.APPLY_DISCOUNT_RATE,
                  L.SOURCE_TYPE,
                  L.SOURCE_LINE_ID,
                  L.TO_APS_CAPACITY_QTY,
                  L.APS_CAPACITY_REC_QTY,
                  L.APS_CAPACITY_REC_DATE,
                  'N',
                  L.PRODUCING_AREA_ID,
                  L.PRODUCING_AREA_CODE,
                  L.PRODUCING_AREA_NAME,
                  'PKG_PLN_INTF_CCS',
                  SYSDATE,
                  'PKG_PLN_INTF_CCS',
                  SYSDATE,
                  L.REMARK,
                  NULL,
                  NULL,
                  NULL,
                  NULL,
                  NULL,
                  NULL,
                  'PKG_PLN_INTF_CCS',
                  SYSDATE
             FROM T_PLN_LG_ORDER_LINE L
            WHERE L.ORDER_HEAD_ID = R_PLN_LG_ORDER_HEAD.ORDER_HEAD_ID
              --当次接口数据0数量产品
              AND EXISTS (SELECT 1
                     FROM INTF_PLN_LG_ORDER_LINE IL
                    WHERE IL.INTF_HEAD_ID = P_INTF_ID
                      AND IL.ITEM_CODE = L.ITEM_CODE
                      AND NVL(IL.PROJECT_ORDER_TYPE, '_') = NVL(L.PROJECT_ORDER_TYPE, '_')
                      AND NVL(IL.PROJECT_ORDER_NUMBER, '_') = NVL(L.PROJECT_ORDER_NUMBER, '_')
                      AND NVL(IL.SHARE_VENDOR_TYPE, '_') = NVL(L.SHARE_VENDOR_TYPE, '_')
                      AND NVL(IL.SHARE_VENDOR_CODE, '_') = NVL(L.SHARE_VENDOR_CODE, '_')
                      AND IL.QUANTITY = 0);
         
         --删除数据
         DELETE FROM T_PLN_LG_ORDER_LINE L
          WHERE L.ORDER_HEAD_ID = R_PLN_LG_ORDER_HEAD.ORDER_HEAD_ID
            --当次接口数据0数量产品
            AND EXISTS (SELECT 1
                   FROM INTF_PLN_LG_ORDER_LINE IL
                  WHERE IL.INTF_HEAD_ID = P_INTF_ID
                    AND IL.ITEM_CODE = L.ITEM_CODE
                    AND NVL(IL.PROJECT_ORDER_TYPE, '_') = NVL(L.PROJECT_ORDER_TYPE, '_')
                    AND NVL(IL.PROJECT_ORDER_NUMBER, '_') = NVL(L.PROJECT_ORDER_NUMBER, '_')
                    AND NVL(IL.SHARE_VENDOR_TYPE, '_') = NVL(L.SHARE_VENDOR_TYPE, '_')
                    AND NVL(IL.SHARE_VENDOR_CODE, '_') = NVL(L.SHARE_VENDOR_CODE, '_')
                    AND IL.QUANTITY = 0);
         --add by lizhen 提货订单为 制单、驳回时，重引单据时删除行表产品编码在接口行不存数据
         If v_Order_Head_State In (19, 415) Then
           --add by lizhen 2017-06-17 接口行不存在，订单行存在的产品删除
           INSERT INTO T_PLN_LINE_DEL_HIS
           (DEL_HIS_ID,
            ENTITY_ID,
            ORIGIN_TYPE,
            ORDER_LINE_ID,
            ORDER_HEAD_ID,
            ITEM_ID,
            ITEM_CODE,
            ITEM_NAME,
            LIST_PRICE,
            QUANTITY,
            DISCOUNT_RATE,
            ORDERED_DISCOUNT_RATE,
            PROJECT_ORDER_TYPE,
            PROJECT_ORDER_NUMBER,
            PROJECT_ORDER_LINE_ID,
            APPLY_LIST_PRICE,
            APPLY_DISCOUNT_RATE,
            SOURCE_TYPE,
            SOURCE_LINE_ID,
            TO_APS_CAPACITY_QTY,
            APS_CAPACITY_REC_QTY,
            APS_CAPACITY_REC_DATE,
            APS_CAPACITY_INTF_FLAG,
            PRODUCING_AREA_ID,
            PRODUCING_AREA_CODE,
            PRODUCING_AREA_NAME,
            CREATED_BY,
            CREATION_DATE,
            LAST_UPDATED_BY,
            LAST_UPDATE_DATE,
            REMARK,
            PRE_FIELD_01,
            PRE_FIELD_02,
            PRE_FIELD_03,
            PRE_FIELD_04,
            PRE_FIELD_05,
            PRE_FIELD_06,
            PROGRAM_UPDATED_BY,
            PROGRAM_UPDATE_DATE)
           SELECT S_PLN_LINE_DEL_HIS.NEXTVAL,
                  L.ENTITY_ID,
                  'LG_ORDER',
                  L.ORDER_LINE_ID,
                  L.ORDER_HEAD_ID,
                  L.ITEM_ID,
                  L.ITEM_CODE,
                  L.ITEM_NAME,
                  L.LIST_PRICE,
                  L.QUANTITY,
                  L.DISCOUNT_RATE,
                  L.ORDERED_DISCOUNT_RATE,
                  L.PROJECT_ORDER_TYPE,
                  L.PROJECT_ORDER_NUMBER,
                  L.PROJECT_ORDER_LINE_ID,
                  L.APPLY_LIST_PRICE,
                  L.APPLY_DISCOUNT_RATE,
                  L.SOURCE_TYPE,
                  L.SOURCE_LINE_ID,
                  L.TO_APS_CAPACITY_QTY,
                  L.APS_CAPACITY_REC_QTY,
                  L.APS_CAPACITY_REC_DATE,
                  'N',
                  L.PRODUCING_AREA_ID,
                  L.PRODUCING_AREA_CODE,
                  L.PRODUCING_AREA_NAME,
                  'PKG_PLN_INTF_CCS',
                  SYSDATE,
                  'PKG_PLN_INTF_CCS',
                  SYSDATE,
                  L.REMARK,
                  NULL,
                  NULL,
                  NULL,
                  NULL,
                  NULL,
                  NULL,
                  'PKG_PLN_INTF_CCS',
                  SYSDATE
             FROM T_PLN_LG_ORDER_LINE L
            WHERE L.ORDER_HEAD_ID = R_PLN_LG_ORDER_HEAD.ORDER_HEAD_ID
              --提货订单行存在，接口行不存在的产品，删除
              And Not EXISTS (SELECT 1
                     FROM INTF_PLN_LG_ORDER_LINE IL
                    WHERE IL.INTF_HEAD_ID = P_INTF_ID
                      AND IL.ITEM_CODE = L.ITEM_CODE
                      AND NVL(IL.PROJECT_ORDER_TYPE, '_') = NVL(L.PROJECT_ORDER_TYPE, '_')
                      AND NVL(IL.PROJECT_ORDER_NUMBER, '_') = NVL(L.PROJECT_ORDER_NUMBER, '_')
                      AND NVL(IL.SHARE_VENDOR_TYPE, '_') = NVL(L.SHARE_VENDOR_TYPE, '_')
                      AND NVL(IL.SHARE_VENDOR_CODE, '_') = NVL(L.SHARE_VENDOR_CODE, '_')
                      );
           --删除数据
           Delete From t_Pln_Lg_Order_Line l
            Where l.Order_Head_Id = r_Pln_Lg_Order_Head.Order_Head_Id
                 --当次接口数据0数量产品
              And Not Exists (Select 1
                     From Intf_Pln_Lg_Order_Line Il
                    Where Il.Intf_Head_Id = p_Intf_Id
                      And Il.Item_Code = l.Item_Code
                      AND NVL(IL.PROJECT_ORDER_TYPE, '_') = NVL(L.PROJECT_ORDER_TYPE, '_')
                      AND NVL(IL.PROJECT_ORDER_NUMBER, '_') = NVL(L.PROJECT_ORDER_NUMBER, '_')
                      AND NVL(IL.SHARE_VENDOR_TYPE, '_') = NVL(L.SHARE_VENDOR_TYPE, '_')
                      AND NVL(IL.SHARE_VENDOR_CODE, '_') = NVL(L.SHARE_VENDOR_CODE, '_')
                      );
         End If;                   
       END IF;

       Open c_Pln_Lg_Order_Line;
       Loop
         Fetch c_Pln_Lg_Order_Line
           into r_Pln_Lg_Order_Line;
         Exit When c_Pln_Lg_Order_Line%Notfound Or p_Result <> v_Success;
         
         IF r_Pln_Lg_Order_Line.Quantity > 0 THEN --接口数量大于0才处理
           --Select s_Pln_Lg_Order_Line.Nextval Into v_Lg_Order_Line_Id From Dual;
           v_Apply_Type     := Null;
           v_Apply_Code     := Null;
           v_Item_Price     := Null;
           v_Apply_Price    := Null;
           v_Apply_Discount := Null;
           
           --ＣＣｓ送审Ｃｉｍｓ接口，　对于熊小美产品，需要控制起订量，起订量严控，且产品满足起订要求，才允许送审
           IF r_Pln_Lg_Order_Head.Sys_Source ='CCS' THEN
              Begin 
          SELECT P.MINIMUM_QUANTITY,
                    P.IS_MINIMUM_QUANTITY_CONTROLS,
                    BI.ROUNDING_CNT
                  INTO 
                       V_MINIMUM_QUANTITY,
                       V_IS_MINIMUM_QUANTITY_CONTROLS,
                       V_ROUNDING_CNT    
                  FROM T_PLN_ITEM_PROPERTY P, T_BD_ITEM BI    
                  WHERE P.ITEM_ID = BI.ITEM_ID
                    AND P.ENTITY_ID = r_Pln_Lg_Order_Head.Entity_Id 
                    AND BI.ITEM_CODE = r_Pln_Lg_Order_Line.Item_Code;
                    exception 
                    When No_Data_Found Then
                      V_MINIMUM_QUANTITY := 0;
                      V_IS_MINIMUM_QUANTITY_CONTROLS := 'N';
                      V_ROUNDING_CNT := 0;
                    end;
           IF V_ROUNDING_CNT >0 AND r_Pln_Lg_Order_Line.Quantity >0 AND V_IS_MINIMUM_QUANTITY_CONTROLS = 'Y' AND V_MINIMUM_QUANTITY > 0 THEN
              IF r_Pln_Lg_Order_Line.Quantity - V_MINIMUM_QUANTITY <0  OR mod((r_Pln_Lg_Order_Line.Quantity - V_MINIMUM_QUANTITY) ,V_ROUNDING_CNT) != 0 THEN
                   p_Result := v_Entity_Name || '，产品编码:'|| r_Pln_Lg_Order_Line.Item_Code ||',起订量:'|| V_MINIMUM_QUANTITY ||',凑整数:'|| V_ROUNDING_CNT ||',目前订单数量:'||r_Pln_Lg_Order_Line.Quantity || ',不满足凑整或起定量要求（计算公式：（订单数量-起订量）/凑整数 = 整数 ）， 请调整订单数量!';
                   Raise V_CCS_EXCEPTION;
              end if;
           end if;
           End if; 
              
           --获取产品价格
           If r_Pln_Order_Type.Is_Get_Cims_Price = 'Y' or r_Pln_Lg_Order_Head.Sys_Source = 'CIMS' Then
             
              IF r_Pln_Lg_Order_Line.Project_Order_Line_Id is not null
                and r_Pln_Lg_Order_Line.Project_Order_Line_Id <> -1 THEN
                  --引用批文
                  Begin
                     v_Value := '取批文价格：';
                    select p.apply_price,
                           (p.apply_cnt-nvl(p.used_cnt,0)-nvl(p.lock_cnt,0)) a_cnt,
                           0 As discount, 
                           --nvl(p.discount,0) as discount, --modi lizhen 2015-12-25批文不取折扣
                           a.apply_type,
                           a.apply_code,
                           Nvl(p.month_discount, 0),
                           p.list_price  --modi by lizhen 2107-08-17
                      into v_Apply_Price,v_Apply_Cnt,v_Apply_Discount,v_Apply_Type,v_Apply_Code,
                      v_Month_Discount, v_Item_Price  --modi by lizhen 2107-08-17
                    from t_bd_price_apply_detail p,t_bd_price_apply a
                    where p.PRICE_APPLY_ID=a.price_apply_id
                      and p.apply_detail_id=r_Pln_Lg_Order_Line.Project_Order_Line_Id
                      and p.item_code= r_Pln_Lg_Order_Line.Item_Code;
                  Exception
                     When Others Then
                       v_Apply_Price    := Null;
                       v_Apply_Discount := 0;
                       v_Apply_Cnt      :=0;
                       v_Month_Discount := 0;

                  End;
                --modi by lizhen 2017-08-17批文折扣取接口行正常折扣率（CCS写入的）
                If Nvl(r_Pln_Lg_Order_Head.Ori_Sys_Source, '_') != 'APP' Then
                   --v_Apply_Discount := r_Pln_Lg_Order_Line.Discount_Rate; --modi by lizhen 2107-08-17
                  --20170710 hejy3 价格批文开单使用折扣
                  if v_Price_Apply_Use_Discount = 'Y' then
                    v_Discount := 0;
                    v_Apply_Discount := nvl(r_Pln_Lg_Order_Line.Discount_Rate, 0);
                  end if;
                End If;
              ELSIF r_Pln_Lg_Order_Head.PREFERENTIAL_FLAG = v_True then
                  Begin
                      v_Value := '获取产品单价：';
                      --20170727 hejy3 引入产品竞争属性
                      Pkg_Bd_Price.P_GET_PRICE_LINE_YH(IN_ACC_ID         => r_Pln_Lg_Order_Head.Account_Id,
                                                    IS_ITEM_CODE      => r_Pln_Lg_Order_Line.Item_Code,
                                                    IS_BILL_DATE      => To_Char(Sysdate, 'yyyymmdd'),
                                                    IN_PRICE_LIST_ID  => Null,
                                                    IN_ENTITY_ID      => r_Pln_Lg_Order_Head.Entity_Id,
                                                    ON_PRICE          => v_Item_Price,
                                                    ON_DISCOUNT       => v_Discount,
                                                    ON_MONTH_DISCOUNT => v_Month_Discount,
                                                    OS_CX_FLAG        => v_Cx_Flag,
                                                    OS_COMPE_ATTR     => v_Item_Competite_Attr);
                      
                      --不重新取折扣则直接取接口折扣月返
                      IF V_RESET_DIS_FLAG = 'N' THEN
                        IF r_Pln_Lg_Order_Line.Discount_Rate IS NOT NULL THEN
                          v_Discount := r_Pln_Lg_Order_Line.Discount_Rate;
                        END IF;
                        IF r_Pln_Lg_Order_Line.Ordered_Discount_Rate IS NOT NULL THEN
                          v_Month_Discount := r_Pln_Lg_Order_Line.Ordered_Discount_Rate;
                        END IF;
                      END IF;
                  Exception
                      When Others Then
                        v_Item_Price     := Null;
                        v_Discount       := 0;
                        v_Month_Discount := 0;
                        v_Cx_Flag        := 'N';
                  End;
              else
                  Begin
                      v_Value := '获取产品单价：';
                      Pkg_Bd_Price.p_Get_Price(p_Acc_Id         => r_Pln_Lg_Order_Head.Account_Id,
                                             p_Item_Code      => r_Pln_Lg_Order_Line.Item_Code,
                                             p_Bill_Date      => To_Char(Sysdate,
                                                                         'yyyymmdd'),
                                             p_Price_List_Id  => Null,
                                             p_Entity_Id      => r_Pln_Lg_Order_Head.Entity_Id,
                                             p_Price          => v_Item_Price,
                                             p_Discount       => v_Discount,
                                             p_Month_Discount => v_Month_Discount,
                                             p_Cx_Flag        => v_Cx_Flag);
                      
                      --不重新取折扣则直接取接口折扣月返
                      IF V_RESET_DIS_FLAG = 'N' THEN
                        IF r_Pln_Lg_Order_Line.Discount_Rate IS NOT NULL THEN
                          v_Discount := r_Pln_Lg_Order_Line.Discount_Rate;
                        END IF;
                        IF r_Pln_Lg_Order_Line.Ordered_Discount_Rate IS NOT NULL THEN
                          v_Month_Discount := r_Pln_Lg_Order_Line.Ordered_Discount_Rate;
                        END IF;
                      END IF;
                  Exception
                      When Others Then
                        v_Item_Price     := Null;
                        v_Discount       := 0;
                        v_Month_Discount := 0;
                        v_Cx_Flag        := 'N';
                  End;
              END IF;
          Else
            --add by lizhen 2017-06-05 不需重新取价
            If r_Pln_Lg_Order_Line.Project_Order_Number Is Not Null Then
              v_Apply_Type     := r_Pln_Lg_Order_Line.Project_Order_Type;
              v_Apply_Code     := r_Pln_Lg_Order_Line.Project_Order_Number;
              v_Apply_Price    := r_Pln_Lg_Order_Line.Apply_List_Price;
              --modi by lizhen 2017-08-17非APP订单，批文折扣取正常单据的折扣率
              If r_Pln_Lg_Order_Head.Ori_Sys_Source = 'APP' Then
                 v_Apply_Discount := r_Pln_Lg_Order_Line.Apply_Discount_Rate;
              Else
                v_Apply_Discount := r_Pln_Lg_Order_Line.Discount_Rate;
              End If;
            Else
              v_Item_Price     := r_Pln_Lg_Order_Line.List_Price;
              v_Discount       := r_Pln_Lg_Order_Line.Discount_Rate;
            End If;
            v_Month_Discount := r_Pln_Lg_Order_Line.Ordered_Discount_Rate;
          End If;
           
           IF v_Apply_Type = 'PG' THEN
             PKG_PLN_PUB.P_GET_CUSTOMIZE_INFO(IN_ENTITY_ID      => r_Pln_Lg_Order_Line.Entity_Id,
                                           IN_PG_APPLY_CODE     => r_Pln_Lg_Order_Line.PROJECT_ORDER_NUMBER,
                                           IN_ITEM_CODE         => r_Pln_Lg_Order_Line.ITEM_CODE,
                                           OUT_CUSTOMIZE_FLAG   => V_CUSTOMIZE_FLAG,
                                           OUT_ACCOUNT_ID       => V_PARTY_ACOUNT_ID,
                                           OUT_SC_ACCOUNT_ID    => V_SC_ACCOUNT_ID,
                                           OUT_AGENT_ACCOUNT_ID => V_AGENT_ACCOUNT_ID);
           ELSE
             V_CUSTOMIZE_FLAG := r_Pln_Lg_Order_Line.Customize_Flag;
           END IF;
           
           if r_Pln_Order_Type.IS_MATERIAL_RANGE_FLAG=v_True then
             Begin
                  v_Value := '产品型谱编码检查：';
                  if V_CUSTOMIZE_FLAG = 'Y' THEN
                    Select Bi.Item_Id, Bi.Defaultunit, Bi.Item_Name,nvl(Bi.SALES_MAIN_TYPE,'-'),
                          nvl(Bi.sales_sub_type,'-'),Bi.Is_Rounding,Bi.Rounding_Cnt,nvl(bi.is_material,'N'),
                          bi.defaultunit, To_Number(bi.packingsize), To_Number(Nvl(bi.grossweight, 0)),
                          bi.item_plot_ratio
                      Into v_Item_Id, v_Item_Uom, v_Item_Desc,v_SALES_MAIN_TYPE, v_SALES_SUB_TYPE,
                      --add by lizhen 2015-12-05增加体积
                           v_Is_Rounding,v_Rounding_Cnt,V_IS_MATERIAL,v_default_unit, v_Unit_Volume, v_Unit_Weight
                           ,v_item_plot_ratio
                      From T_BD_ITEM  Bi,t_Pln_Item_Dyn_Attribute da
                   Where  bi.item_id=da.item_id
                      and bi.entity_id=da.entity_id
                      and Trunc(sysdate) Between da.begin_date And
                                                 Trunc(Nvl(da.end_date, Sysdate))
                      and Bi.Item_Code = r_Pln_Lg_Order_Line.Item_Code
                      And Bi.Entity_Id = r_Pln_Lg_Order_Line.Entity_Id
                      --20180102 hejy3 按销售使能标志控制
                      And Bi.active_flag = v_True;
                  ELSE
                   Select Bi.Item_Id, Bi.Defaultunit, Bi.Item_Name,nvl(Bi.SALES_MAIN_TYPE,'-'),
                          nvl(Bi.sales_sub_type,'-'),Bi.Is_Rounding,Bi.Rounding_Cnt,nvl(bi.is_material,'N'),
                          bi.defaultunit, To_Number(bi.packingsize), To_Number(Nvl(bi.grossweight, 0)),
                          bi.item_plot_ratio
                      Into v_Item_Id, v_Item_Uom, v_Item_Desc,v_SALES_MAIN_TYPE, v_SALES_SUB_TYPE,
                      --add by lizhen 2015-12-05增加体积
                           v_Is_Rounding,v_Rounding_Cnt,V_IS_MATERIAL,v_default_unit, v_Unit_Volume, v_Unit_Weight
                           ,v_item_plot_ratio
                      From T_BD_ITEM  Bi,t_Pln_Item_Dyn_Attribute da
                   Where  bi.item_id=da.item_id
                      and bi.entity_id=da.entity_id
                      and Trunc(sysdate) Between da.begin_date And
                                                 Trunc(Nvl(da.end_date, Sysdate))
                      and Bi.Item_Code = r_Pln_Lg_Order_Line.Item_Code
                      And Bi.Entity_Id = r_Pln_Lg_Order_Line.Entity_Id
                      --20180102 hejy3 按销售使能标志控制
                      --20180522 hejy3 按在产在销标志控制
                      And Bi.Atsale_Flag = v_True
                      And Bi.active_flag = v_True;
                  END IF;
               Exception
                 When Others Then
                    p_Result := v_Value || v_Entity_Name || '，产品编码：' || r_Pln_Lg_Order_Line.Item_Code ||
                              '不在型谱范围或产品已失效，请检查产品在产在销标识和有效标识是否为Y，且已维护有效产品型谱';
                      raise V_CCS_EXCEPTION;
               End;

           elsif r_Pln_Order_Type.IS_SAMPLE_NEED = v_true then
               Begin
                 v_Value := '样机产品检查：';
                 Select Bi.Item_Id, Bi.Defaultunit, Bi.Item_Name,nvl(Bi.SALES_MAIN_TYPE,'-'),
                        nvl(Bi.sales_sub_type,'-'),Bi.Is_Rounding,Bi.Rounding_Cnt,nvl(bi.is_material,'N'),
                        bi.defaultunit, To_Number(bi.packingsize), To_Number(Nvl(bi.grossweight, 0)),
                        bi.item_plot_ratio
                    Into v_Item_Id, v_Item_Uom, v_Item_Desc,v_SALES_MAIN_TYPE, v_SALES_SUB_TYPE,
                         v_Is_Rounding,v_Rounding_Cnt,V_IS_MATERIAL,v_default_unit,
                         v_Unit_Volume, v_Unit_Weight --add by lizhen 2015-12-05增加体积
                         ,v_item_plot_ratio
                    From T_BD_ITEM  Bi
                 Where Bi.Item_Code = r_Pln_Lg_Order_Line.Item_Code
                    And Bi.Entity_Id = r_Pln_Lg_Order_Line.Entity_Id
                    And Bi.active_flag = v_True
                    And Bi.productform='SAMPLE_PRODUCT';
               Exception
                 When Others Then
                    p_Result := v_Value || v_Entity_Name || '，样机产品编码：' || r_Pln_Lg_Order_Line.Item_Code ||
                              '不存在或者已失效，请检查产品是否为样机和有效标识是否为Y';
                      raise V_CCS_EXCEPTION;
               End;
           else
             --20180522 hejy3 优惠品控制
             if r_Pln_Lg_Order_Head.Preferential_Flag = v_True then
               Begin
                 v_Value := '产品编码检查：';
                 Select Bi.Item_Id, Bi.Defaultunit, Bi.Item_Name,nvl(Bi.SALES_MAIN_TYPE,'-'),
                        nvl(Bi.sales_sub_type,'-'),Bi.Is_Rounding,Bi.Rounding_Cnt,nvl(bi.is_material,'N'),
                        bi.defaultunit, To_Number(bi.packingsize), To_Number(Nvl(bi.grossweight, 0)),
                        bi.item_plot_ratio
                   Into v_Item_Id, v_Item_Uom, v_Item_Desc,v_SALES_MAIN_TYPE, v_SALES_SUB_TYPE,
                        v_Is_Rounding,v_Rounding_Cnt,V_IS_MATERIAL,v_default_unit,
                        v_Unit_Volume, v_Unit_Weight   --add by lizhen 2015-12-05增加体积
                        ,v_item_plot_ratio
                   From T_BD_ITEM  Bi
                  Where Bi.Item_Code = r_Pln_Lg_Order_Line.Item_Code
                    And Bi.Entity_Id = r_Pln_Lg_Order_Line.Entity_Id
                    And Bi.active_flag = v_True;
               Exception
                 When Others Then
                    p_Result := v_Value || '，产品编码：' || r_Pln_Lg_Order_Line.Item_Code ||
                                '在事业部：' || v_Entity_Name || '不存在或者产品已失效，请检查产品有效标志是否为Y';
                    raise V_CCS_EXCEPTION;
               end;
             else
               Begin
                    v_Value := '产品编码检查：';
                 if V_CUSTOMIZE_FLAG = 'Y' THEN
                   Select Bi.Item_Id, Bi.Defaultunit, Bi.Item_Name,nvl(Bi.SALES_MAIN_TYPE,'-'),
                        nvl(Bi.sales_sub_type,'-'),Bi.Is_Rounding,Bi.Rounding_Cnt,nvl(bi.is_material,'N'),
                        bi.defaultunit, To_Number(bi.packingsize), To_Number(Nvl(bi.grossweight, 0)),
                        bi.item_plot_ratio
                    Into v_Item_Id, v_Item_Uom, v_Item_Desc,v_SALES_MAIN_TYPE, v_SALES_SUB_TYPE,
                         v_Is_Rounding,v_Rounding_Cnt,V_IS_MATERIAL,v_default_unit,
                         v_Unit_Volume, v_Unit_Weight   --add by lizhen 2015-12-05增加体积
                         ,v_item_plot_ratio
                    From T_BD_ITEM  Bi
                 Where Bi.Item_Code = r_Pln_Lg_Order_Line.Item_Code
                    And Bi.Entity_Id = r_Pln_Lg_Order_Line.Entity_Id
                    --20180102 hejy3 按销售使能标志控制
                    And Bi.active_flag = v_True;
                 ELSE
                   Select Bi.Item_Id, Bi.Defaultunit, Bi.Item_Name,nvl(Bi.SALES_MAIN_TYPE,'-'),
                          nvl(Bi.sales_sub_type,'-'),Bi.Is_Rounding,Bi.Rounding_Cnt,nvl(bi.is_material,'N'),
                          bi.defaultunit, To_Number(bi.packingsize), To_Number(Nvl(bi.grossweight, 0)),
                          bi.item_plot_ratio
                      Into v_Item_Id, v_Item_Uom, v_Item_Desc,v_SALES_MAIN_TYPE, v_SALES_SUB_TYPE,
                           v_Is_Rounding,v_Rounding_Cnt,V_IS_MATERIAL,v_default_unit,
                           v_Unit_Volume, v_Unit_Weight   --add by lizhen 2015-12-05增加体积
                           ,v_item_plot_ratio
                      From T_BD_ITEM  Bi
                   Where Bi.Item_Code = r_Pln_Lg_Order_Line.Item_Code
                      And Bi.Entity_Id = r_Pln_Lg_Order_Line.Entity_Id
                      --20180102 hejy3 按销售使能标志控制
                      --20180522 hejy3 按在产在销标志控制
                      And Bi.Atsale_Flag = v_True
                      And Bi.active_flag = v_True;
                  END IF;
               Exception
                 When Others Then
                    p_Result := v_Value || '，产品编码：' || r_Pln_Lg_Order_Line.Item_Code ||
                              '在事业部：' || v_Entity_Name || '不存在或者产品已失效，请检查产品在产在销标识和有效标识是否为Y';
                      raise V_CCS_EXCEPTION;
               End;
             end if;
           End if;
           
           --推广物料检查
           v_Value := '推广物料检查';
           IF r_Pln_Order_Type.Is_Business_Control = v_Pro_Order AND V_IS_MATERIAL <> 'Y' THEN
             p_Result := v_Value || v_Entity_Name || '，产品：' || r_Pln_Lg_Order_Line.Item_Code ||
                         '不是推广物料，不允许通过单据类型：' || r_Pln_Order_Type.Order_Type_Name || '报送';
             raise V_CCS_EXCEPTION;
           ELSIF r_Pln_Order_Type.Is_Business_Control <> v_Pro_Order AND V_IS_MATERIAL = 'Y' THEN
             p_Result := v_Value || v_Entity_Name || '，产品：' || r_Pln_Lg_Order_Line.Item_Code ||
                         '是推广物料，不允许通过单据类型：' || r_Pln_Order_Type.Order_Type_Name || '报送';
             raise V_CCS_EXCEPTION;
           END IF;
           
           --20180308 hejy3
           IF nvl(r_Pln_Order_Type.Is_Count, 'N') <> 'Y' then
             v_Is_Rounding := 'N';
           end if;

           --获取产品价格
           /*If r_Pln_Order_Type.Is_Get_Cims_Price = 'Y' or r_Pln_Lg_Order_Head.Sys_Source = 'CIMS' Then

              v_Apply_Type     := Null;
              v_Apply_Code     := Null;
              v_Item_Price     := Null;
              v_Apply_Price    := Null;
              v_Apply_Discount := Null;

              IF r_Pln_Lg_Order_Line.Project_Order_Line_Id is not null
                and r_Pln_Lg_Order_Line.Project_Order_Line_Id <> -1 THEN
                  --引用批文
                  Begin
                     v_Value := '取批文价格：';
                    select p.apply_price,
                           (p.apply_cnt-nvl(p.used_cnt,0)-nvl(p.lock_cnt,0)) a_cnt,
                           0 As discount, 
                           --nvl(p.discount,0) as discount, --modi lizhen 2015-12-25批文不取折扣
                           a.apply_type,
                           a.apply_code,
                           Nvl(p.month_discount, 0),
                           p.list_price  --modi by lizhen 2107-08-17
                      into v_Apply_Price,v_Apply_Cnt,v_Apply_Discount,v_Apply_Type,v_Apply_Code,
                      v_Month_Discount, v_Item_Price  --modi by lizhen 2107-08-17
                    from t_bd_price_apply_detail p,t_bd_price_apply a
                    where p.PRICE_APPLY_ID=a.price_apply_id
                      and p.apply_detail_id=r_Pln_Lg_Order_Line.Project_Order_Line_Id
                      and p.item_code= r_Pln_Lg_Order_Line.Item_Code;
                  Exception
                     When Others Then
                       v_Apply_Price    := Null;
                       v_Apply_Discount := 0;
                       v_Apply_Cnt      :=0;
                       v_Month_Discount := 0;

                  End;
                --v_Item_Price := r_Pln_Lg_Order_Line.List_Price;   --modi by lizhen 2105-09-07
                --v_Discount = r_Pln_Lg_Order_Line.Discount_Rate; --modi by lizhen 2105-09-07
                --modi by lizhen 2017-08-17批文折扣取接口行正常折扣率（CCS写入的）
                If Nvl(r_Pln_Lg_Order_Head.Ori_Sys_Source, '_') != 'APP' Then
                   --v_Apply_Discount := r_Pln_Lg_Order_Line.Discount_Rate; --modi by lizhen 2107-08-17
                  --20170710 hejy3 价格批文开单使用折扣
                  if v_Price_Apply_Use_Discount = 'Y' then
                    v_Discount := 0;
                    v_Apply_Discount := nvl(r_Pln_Lg_Order_Line.Discount_Rate, 0);
                  end if;
                End If;
              ELSIF r_Pln_Lg_Order_Head.PREFERENTIAL_FLAG = v_True then
                  Begin
                      v_Value := '获取产品单价：';
                      --20170727 hejy3 引入产品竞争属性
                      \*Pkg_Bd_Price.P_GET_PRICE_YH(p_Acc_Id         => r_Pln_Lg_Order_Head.Account_Id,
                                             p_Item_Code      => r_Pln_Lg_Order_Line.Item_Code,
                                             p_Bill_Date      => To_Char(Sysdate,
                                                                         'yyyymmdd'),
                                             p_Price_List_Id  => Null,
                                             p_Entity_Id      => r_Pln_Lg_Order_Head.Entity_Id,
                                             p_Price          => v_Item_Price,
                                             p_Discount       => v_Discount,
                                             p_Month_Discount => v_Month_Discount,
                                             p_Cx_Flag        => v_Cx_Flag);*\
                      Pkg_Bd_Price.P_GET_PRICE_LINE_YH(IN_ACC_ID         => r_Pln_Lg_Order_Head.Account_Id,
                                                    IS_ITEM_CODE      => r_Pln_Lg_Order_Line.Item_Code,
                                                    IS_BILL_DATE      => To_Char(Sysdate, 'yyyymmdd'),
                                                    IN_PRICE_LIST_ID  => Null,
                                                    IN_ENTITY_ID      => r_Pln_Lg_Order_Head.Entity_Id,
                                                    ON_PRICE          => v_Item_Price,
                                                    ON_DISCOUNT       => v_Discount,
                                                    ON_MONTH_DISCOUNT => v_Month_Discount,
                                                    OS_CX_FLAG        => v_Cx_Flag,
                                                    OS_COMPE_ATTR     => v_Item_Competite_Attr);
                      
                      --不重新取折扣则直接取接口折扣月返
                      IF V_RESET_DIS_FLAG = 'N' THEN
                        IF r_Pln_Lg_Order_Line.Discount_Rate IS NOT NULL THEN
                          v_Discount := r_Pln_Lg_Order_Line.Discount_Rate;
                        END IF;
                        IF r_Pln_Lg_Order_Line.Ordered_Discount_Rate IS NOT NULL THEN
                          v_Month_Discount := r_Pln_Lg_Order_Line.Ordered_Discount_Rate;
                        END IF;
                      END IF;
                  Exception
                      When Others Then
                        v_Item_Price     := Null;
                        v_Discount       := 0;
                        v_Month_Discount := 0;
                        v_Cx_Flag        := 'N';
                  End;
              else
                  Begin
                      v_Value := '获取产品单价：';
                      Pkg_Bd_Price.p_Get_Price(p_Acc_Id         => r_Pln_Lg_Order_Head.Account_Id,
                                             p_Item_Code      => r_Pln_Lg_Order_Line.Item_Code,
                                             p_Bill_Date      => To_Char(Sysdate,
                                                                         'yyyymmdd'),
                                             p_Price_List_Id  => Null,
                                             p_Entity_Id      => r_Pln_Lg_Order_Head.Entity_Id,
                                             p_Price          => v_Item_Price,
                                             p_Discount       => v_Discount,
                                             p_Month_Discount => v_Month_Discount,
                                             p_Cx_Flag        => v_Cx_Flag);
                      
                      --不重新取折扣则直接取接口折扣月返
                      IF V_RESET_DIS_FLAG = 'N' THEN
                        IF r_Pln_Lg_Order_Line.Discount_Rate IS NOT NULL THEN
                          v_Discount := r_Pln_Lg_Order_Line.Discount_Rate;
                        END IF;
                        IF r_Pln_Lg_Order_Line.Ordered_Discount_Rate IS NOT NULL THEN
                          v_Month_Discount := r_Pln_Lg_Order_Line.Ordered_Discount_Rate;
                        END IF;
                      END IF;
                  Exception
                      When Others Then
                        v_Item_Price     := Null;
                        v_Discount       := 0;
                        v_Month_Discount := 0;
                        v_Cx_Flag        := 'N';
                  End;
              END IF;
          Else
            --add by lizhen 2017-06-05 不需重新取价
            If r_Pln_Lg_Order_Line.Project_Order_Number Is Not Null Then
              v_Apply_Type     := r_Pln_Lg_Order_Line.Project_Order_Type;
              v_Apply_Code     := r_Pln_Lg_Order_Line.Project_Order_Number;
              v_Apply_Price    := r_Pln_Lg_Order_Line.Apply_List_Price;
              --modi by lizhen 2017-08-17非APP订单，批文折扣取正常单据的折扣率
              If r_Pln_Lg_Order_Head.Ori_Sys_Source = 'APP' Then
                 v_Apply_Discount := r_Pln_Lg_Order_Line.Apply_Discount_Rate;
              Else
                v_Apply_Discount := r_Pln_Lg_Order_Line.Discount_Rate;
              End If;
            Else
              v_Item_Price     := r_Pln_Lg_Order_Line.List_Price;
              v_Discount       := r_Pln_Lg_Order_Line.Discount_Rate;
            End If;
            v_Month_Discount := r_Pln_Lg_Order_Line.Ordered_Discount_Rate;
          End If;*/
          
          --20170830 hejy3 非常规到款方式折扣清0
          if nvl(r_Pln_Lg_Order_Line.Discount_Type, v_Discount_Type_Common) != v_Discount_Type_Common THEN
            v_Discount := 0;
            v_Apply_Discount := 0;
          END IF;
          
          --add by lizhen 2017-09-25工程机提货订单行表必须为工程机批文
         If r_Pln_Lg_Order_Head.Project_Order_Flag = 'Y' And V_Lg_Order_Project_Flag = 'Y' 
           And Nvl(v_Apply_Type, '_') != 'PG' Then
           p_Result := v_Entity_Name || '，该提货订单为工程机提货，订单行必须录入工程机批文';
           raise V_CCS_EXCEPTION;
         End If;
          
          --add by lizhen 2017-06-08获取仓库信息
          --20171101 hejy3 仓库编码不为空，按照仓库编码获取仓库信息
          --网批业务按区域仓库关系获取评审仓库
          If (r_Pln_Order_Type.Is_Auto_Inv_Review = 'Y' and nvl(r_Pln_Lg_Order_Head.Customer_Channel_Type, '_') not in(pkg_pln_pub.V_CUSTOMER_CHANNEL_TYPE_WP ,pkg_pln_pub.V_CUSTOMER_CHANNEL_TYPE_NIFFER,
            PKG_PLN_PUB.V_CUSTOMER_CHANNEL_TYPE_SHARE))
            or r_Pln_Lg_Order_Line.Inventory_Code is not null
            Then
            Begin
              Select Tii.Inventory_Id,
                     Tii.Inventory_Code,
                     Tii.Inventory_Name
                Into v_Inventory_Id, v_Inventory_Code, v_Inventory_Name
                From t_Inv_Inventories Tii
               Where Tii.Entity_Id = r_Pln_Lg_Order_Head.Entity_Id
                 And Tii.Inventory_Code = r_Pln_Lg_Order_Line.Inventory_Code
                 --add by lizhen 2017-06-23增加客户OU组织过滤
                 And 'Y' = Pkg_Inv_Pub.f_Get_Custimer_Inv_Org(In_Entity_Id   => Tii.Entity_Id,
                                                          In_Customer_Id     => r_Pln_Lg_Order_Head.Customer_Id,
                                                          In_Organization_Id => Tii.Organization_Id);
            Exception
              When No_Data_Found Then
                /*p_Result := '单据类型自动库存评审，获取仓库信息失败，请检查客户OU库存组织与仓库库存组织是否一致！'
                  || v_Nl || '仓库编码：' || r_Pln_Lg_Order_Line.Inventory_Code;*/
                p_Result := v_Entity_Name || '，获取仓库信息失败，请检查仓库编码是否正确，客户OU库存组织与仓库库存组织是否一致！'
                  || v_Nl || '仓库编码：' || r_Pln_Lg_Order_Line.Inventory_Code;
                Raise v_Ccs_Exception;
              When Others Then
                --p_Result := '单据类型自动库存评审，获取仓库信息失败！' || v_Nl || Sqlerrm;
                p_Result := '获取仓库信息失败！仓库编码：' || r_Pln_Lg_Order_Line.Inventory_Code || v_Nl || Sqlerrm;
                Raise v_Ccs_Exception;
            End;
          End If;

          If nvl(r_Pln_Lg_Order_Line.Quantity, 0) = 0 Then
            p_Result := v_Entity_Name || '，订单行有误，产品编码：' || r_Pln_Lg_Order_Line.Item_Code || '，产品申请数量为0。';
            raise V_CCS_EXCEPTION;
          End If;

          IF r_Pln_Lg_Order_Line.Project_Order_Line_Id is not null
            and r_Pln_Lg_Order_Line.Project_Order_Line_Id <> -1 THEN
            --使用批文
            If v_Apply_Price Is Null  Then
              p_Result := v_Entity_Name || '，获取批文价格失败：批文行ID：'||r_Pln_Lg_Order_Line.Project_Order_Line_Id ||
              ' 申请产品编码：' || r_Pln_Lg_Order_Line.Item_Code || '，批文价格为空或引用批文行无效。';
                raise V_CCS_EXCEPTION;
            End If;
            If r_Pln_Lg_Order_Line.Quantity>v_Apply_Cnt Then
              p_Result := v_Entity_Name || '，获取引入失败：批文行ID：'||r_Pln_Lg_Order_Line.Project_Order_Line_Id ||
              ' 申请产品数量：' || r_Pln_Lg_Order_Line.Quantity || ' 超过批文可使用数量 '
              ||v_Apply_Cnt||'。';
                raise V_CCS_EXCEPTION;
            End if;
            /*v_Apply_Amount := Round((Nvl(r_Pln_Lg_Order_Line.Quantity, 0) * v_Apply_Price *
                              (100 - Nvl(v_Month_Discount, 0)
                              --modi by lizhen 2015-12-25 批文不计算折扣，只计算月返
                               \*Nvl(v_Apply_Discount, 0)*\)) / 100,2);*/
            SELECT Round((Nvl(r_Pln_Lg_Order_Line.Quantity, 0) * v_Apply_Price *
                              (100 - Nvl(v_Month_Discount, 0)
                              --modi by lizhen 2015-12-25 批文不计算折扣，只计算月返
                              --20170710 hejy3 价格批文开单使用折扣
                               - decode(v_Price_Apply_Use_Discount, 'Y', nvl(v_Apply_Discount, 0), 0)
                               )) / 100,2)
               INTO v_Apply_Amount
               FROM DUAL;

          ELSE
            If r_Pln_Lg_Order_Line.Project_Order_Number Is Not Null Then
              --不使用批文
              If v_Apply_Price Is Null and r_Pln_Order_Type.Is_Price_Check =v_True Then
                p_Result := v_Entity_Name || '，获取产品价格失败：产品编码：' || r_Pln_Lg_Order_Line.Item_Code || '，单价为空。';
                raise V_CCS_EXCEPTION;
              End If;

              v_Apply_Amount := Round((Nvl(r_Pln_Lg_Order_Line.Quantity, 0) * nvl(v_Apply_Price,0) *
                                --ADD BY LIZHEN 2015-12-25 增加月返
                                (100 - Nvl(v_Apply_Discount, 0) - Nvl(v_Month_Discount, 0))) / 100,2);
            else
              --不使用批文
              If v_Item_Price Is Null and r_Pln_Order_Type.Is_Price_Check =v_True Then
                if r_Pln_Lg_Order_Head.Preferential_Flag = v_True then
                  p_Result := v_Entity_Name || '，获取产品优惠品价格失败：产品编码：' || r_Pln_Lg_Order_Line.Item_Code || '，单价为空。';
                else
                p_Result := v_Entity_Name || '，获取产品价格失败：产品编码：' || r_Pln_Lg_Order_Line.Item_Code || '，单价为空。';
                end if;
                raise V_CCS_EXCEPTION;
              End If;

              v_Apply_Amount := Round((Nvl(r_Pln_Lg_Order_Line.Quantity, 0) * nvl(v_Item_Price,0) *
                                --ADD BY LIZHEN 2015-12-25 增加月返
                                (100 - Nvl(v_Discount, 0) - Nvl(v_Month_Discount, 0))) / 100,2);
              --来源代销单的，且接口重新取价的，增加更新代销单行上直供价 lilh6 2019-3-27
              If r_Pln_Lg_Order_Head.Sys_Source = 'CIMSDX'And r_Pln_Order_Type.Is_Get_Cims_Price = 'Y' Then
                Update t_Pln_Dx_Order_Line l
                   Set l.List_Price   = v_Item_Price,
                       l.Apply_Amount = v_Item_Price * l.Quantity
                 Where l.Item_Code = r_Pln_Lg_Order_Line.Item_Code
                   And l.entity_id = r_Pln_Lg_Order_Line.Entity_Id
                   And l.Order_Head_Id =
                       (Select h.Order_Head_Id
                          From t_Pln_Dx_Order_Head h
                         Where h.Order_Number =
                               r_Pln_Lg_Order_Head.Source_Order_Number);
              End If;
            End If;
          END IF;

         --add by lizhen 2015-08-24 T+3提货模式接口无产地时，系统自动获取
         If r_Pln_Lg_Order_Line.Producing_Area_Id IS NULL AND v_Pln_Is_Merge_Lg_Order In ('TN_SUM', 'TN_SINGLE') 
                                                                               --lilh6 17-8-3 业务类型不检查产地
           And Upper(Nvl(r_Pln_Order_Type.Is_Business_Control, '_')) NOT IN ('PRO_ORDER','NO_CHECK_PROD_AREA','SC_LG_ORDER') Then
           Begin
             v_Producing_Area_Id := Pkg_Pln_Pub.f_Get_Item_Prod_Area_Priority(p_Entity_Id       => r_Pln_Lg_Order_Head.Entity_Id,
                                                                              p_Sales_Center_Id => r_Pln_Lg_Order_Head.Sales_Center_Id,
                                                                              p_Item_Id         => v_Item_Id,
                                                                              p_Item_Life_Cycle => 'N');
             Select Pa.Producing_Area_Code, Pa.Producing_Area_Name
               Into v_Producing_Area_Code, v_Producing_Area_Name
               From t_Pln_Producing_Area Pa
              Where Pa.Producing_Area_Id = v_Producing_Area_Id;
           Exception
             When Others Then
               p_Result := v_Entity_Name || '，产品' || r_Pln_Lg_Order_Line.Item_Code || '获取默认产地信息失败！请检查是否存在有效的产品产地优先级关系。';
               Raise v_Ccs_Exception;
           End;           
         --CIMS间结转的单据，检查产地在当前主体是否存在，不存在则重新获取 lilh6 2019-2-18
         Elsif r_Pln_Lg_Order_Line.Producing_Area_Id Is Not Null And r_Pln_Lg_Order_Head.Sys_Source = 'CIMS'AND v_Pln_Is_Merge_Lg_Order In ('TN_SUM', 'TN_SINGLE') 
                                                                               --lilh6 17-8-3 业务类型不检查产地
           And Upper(Nvl(r_Pln_Order_Type.Is_Business_Control, '_')) NOT IN ('PRO_ORDER','NO_CHECK_PROD_AREA','SC_LG_ORDER')Then
           Select Count(1)
             Into v_Count
             From t_Pln_Producing_Area a
            Where a.Producing_Area_Id = r_Pln_Lg_Order_Line.Producing_Area_Id
              And a.entity_id = r_Pln_Lg_Order_Head.Entity_Id;
           --存在，直接赋值
           If v_Count >0 Then 
             v_Producing_Area_Id := r_Pln_Lg_Order_Line.Producing_Area_Id;
             v_producing_Area_Code := r_Pln_Lg_Order_Line.Producing_Area_Code;
             v_Producing_Area_Name := r_Pln_Lg_Order_Line.Producing_Area_Name;
           Else
           --不存在，重新获取
             Begin
               v_Producing_Area_Id := Pkg_Pln_Pub.f_Get_Item_Prod_Area_Priority(p_Entity_Id       => r_Pln_Lg_Order_Head.Entity_Id,
                                                                                p_Sales_Center_Id => r_Pln_Lg_Order_Head.Sales_Center_Id,
                                                                                p_Item_Id         => v_Item_Id,
                                                                                p_Item_Life_Cycle => 'N');
               Select Pa.Producing_Area_Code, Pa.Producing_Area_Name
                 Into v_Producing_Area_Code, v_Producing_Area_Name
                 From t_Pln_Producing_Area Pa
                Where Pa.Producing_Area_Id = v_Producing_Area_Id;
             Exception
               When Others Then
                 p_Result := v_Entity_Name || '，产品' || r_Pln_Lg_Order_Line.Item_Code || '获取默认产地信息失败！请检查是否存在有效的产品产地优先级关系。';
                 Raise v_Ccs_Exception;
             End;
           End If;             
         Else   
           v_Producing_Area_Id := r_Pln_Lg_Order_Line.Producing_Area_Id;
           v_producing_Area_Code := r_Pln_Lg_Order_Line.Producing_Area_Code;
           v_Producing_Area_Name := r_Pln_Lg_Order_Line.Producing_Area_Name;
         End If;
         --modi by lizhen 2015-12-05 检查数量不允许为负数或者空
         If r_Pln_Lg_Order_Line.Quantity Is Null Or r_Pln_Lg_Order_Line.Quantity < 0 Then
           p_Result := v_Entity_Name || '，引入订单行失败，提货申请数量为空或者负数！' || 
             '产品编码：' || r_Pln_Lg_Order_Line.Item_Code;
           Raise v_Ccs_Exception;
         End If;

          --接口表行数据插入业务表行
          If p_Result = v_Success Then

            BEGIN
              --按来源头行检查是否退回重新送审的数据
              IF r_Pln_Lg_Order_Head.Order_Head_Id IS NOT NULL THEN
                BEGIN
                  SELECT l.order_line_id
                    INTO r_Pln_Lg_Order_Line.Order_Line_Id
                    FROM t_pln_lg_order_line l, t_pln_lg_order_head h
                   WHERE l.order_head_id = h.order_head_id
                     AND h.sys_source In ('CIMS', 'CCS','CSS') --add by lizhen 2017-05-12 增加CIMS 
                     AND h.order_head_id = r_Pln_Lg_Order_Head.Order_Head_Id
                     AND l.item_code = r_Pln_Lg_Order_Line.Item_Code
                     AND NVL(L.PROJECT_ORDER_TYPE, '_') = NVL(v_Apply_Type, '_')
                     AND NVL(L.PROJECT_ORDER_NUMBER, '_') = NVL(r_Pln_Lg_Order_Line.PROJECT_ORDER_NUMBER, '_')
                     AND NVL(L.SHARE_VENDOR_TYPE, '_') = NVL(r_Pln_Lg_Order_Line.SHARE_VENDOR_TYPE, '_')
                     AND NVL(L.SHARE_VENDOR_CODE, '_') = NVL(r_Pln_Lg_Order_Line.SHARE_VENDOR_CODE, '_')
                     ;
                EXCEPTION
                  WHEN no_data_found THEN
                    r_Pln_Lg_Order_Line.Order_Line_Id := NULL;
                END;
              ELSE
                r_Pln_Lg_Order_Line.Order_Line_Id := NULL;
              END IF;
              
              --之前已经引入则做更新
              IF r_Pln_Lg_Order_Line.Order_Line_Id IS NOT NULL THEN
                --20170920 hejy3 选配明细引入
                v_Lg_Order_Line_Id := r_Pln_Lg_Order_Line.Order_Line_Id;
                
                UPDATE T_PLN_LG_ORDER_LINE L
                   SET L.ITEM_ID = v_Item_Id,
                       L.ITEM_CODE = r_Pln_Lg_Order_Line.Item_Code,
                       L.ITEM_NAME = v_Item_Desc,
                       L.UNIT_VOLUME = v_Unit_Volume,
                       L.UNIT_WEIGHT = v_Unit_Weight,
                       L.LIST_PRICE = v_Item_Price,
                       L.SALES_MAIN_TYPE = v_SALES_MAIN_TYPE,
                       L.SALES_SUB_TYPE = v_SALES_SUB_TYPE,
                       L.QUANTITY = r_Pln_Lg_Order_Line.Quantity,
                       L.AFFIRM_QUANTITY = NULL,
                       L.FINANCE_QUANTITY = NULL,
                       L.Cancel_Qty = NULL,
                       l.received_qty = NULL,
                       l.virtual_qty = r_Pln_Lg_Order_Line.Virtual_Qty,
                       l.apply_amount = v_Apply_Amount,
                       l.inv_id = Nvl(v_Inventory_Id, 0),  -- 仓库id modi by lizhen 2017-06-08
                       l.inv_code = v_Inventory_Code,  -- 仓库编码 modi by lizhen 2017-06-08
                       l.inv_name = v_Inventory_Name,  -- 仓库名称 modi by lizhen 2017-06-08
                       l.ship_inv_id = NULL,
                       l.ship_inv_code = NULL,                -- 发货仓编码（调拨使用）
                       l.ship_inv_name = NULL,                -- 发货仓名称（调拨使用）
                       l.price_list_id = NULL,                -- 价格列表id
                       l.price_system_id = NULL,              -- 价格体系id
                       l.discount_rate = v_Discount,                -- 扣率（从价格列表带出，或手工填写）
                       l.ordered_discount_rate = v_Month_Discount,        -- 月返。从价格列表获取的折扣（荣事达洗衣机需求）
                       l.discount_type_id = NULL,             -- 款项类型id（额度组、折扣类型统一名称）
                       --l.sales_order_type_id = NULL,          -- 销售单类型id --modi by lizhen 2016-07-25不更新销售单据类型ID
                       l.project_order_type = v_Apply_Type,           -- 批文类型（新增）
                       l.project_order_number = v_Apply_Code,         -- 批文号
                       l.project_order_line_id = r_Pln_Lg_Order_Line.Project_Order_Line_Id,        -- 批文行id（用于基础模块进行对应产品扣减）
                       l.apply_list_price = v_Apply_Price,             -- 申请价（工程机批文价格）
                       l.apply_discount_rate = v_Apply_Discount,          -- 申请折扣（工程机批文折扣）
                       l.source_type = r_Pln_Lg_Order_Head.Exigence,                  -- 发货状态（“紧急订单”）
                       l.spec_qty = v_Rounding_Cnt,                     -- 凑整数量（厨电，从产品数据获取）
                       l.is_need_int = v_Is_Rounding,                  -- 是否凑整（厨电，从产品数据获取）
                       l.is_logistics = NULL,                 -- 是否生成发货单或运输合同（厨电）
                       l.biz_source_type = r_Pln_Lg_Order_Line.Biz_Source_Type,              -- 来源类型
                       l.biz_source_number = r_Pln_Lg_Order_Line.Biz_Source_Number,            -- 来源号
                       l.source_head_id = r_Pln_Lg_Order_Line.Source_Head_Id,               -- 来源头id
                       l.source_head_code = r_Pln_Lg_Order_Line.Source_Head_Code,             -- 来源头编码
                       l.source_line_id = r_Pln_Lg_Order_Line.Source_Line_Id,               -- 来源行iid
                       l.lock_inv_pre = NULL,                 -- 锁定库存数量
                       l.lock_amount_percent = NULL,          -- 行锁定金额百分比
                       l.lock_amount_pre = NULL,              -- 行锁定金额
                       l.low_stock_init = NULL,               -- 默认最低库存？
                       l.high_stock_init = NULL,              -- 默认最高库存？
                       l.low_stock_adjust = NULL,             -- 调整最低库存？
                       l.high_stock_adjust = NULL,            -- 调整最高库存？
                       l.low_stock_confirm = NULL,            -- 确认最低库存？
                       l.high_stock_confirm = NULL,           -- 确认最高库存？
                       l.sended_qty = NULL,                   -- 已直发数量？
                       l.hq_pln4_order_qty = NULL,            -- 转总部计划订单数量（提货订单库存评审未满足部分需要转计划订单）
                       l.pln4_order_awaiting_qty = NULL,      -- 转总部计划订单等待数量
                       l.last_updated_by = 'PKG_PLN_INTF_CCS',              -- 最后修改人
                       l.last_update_date = SYSDATE,             -- 最后修改日期
                       l.remark = r_Pln_Lg_Order_Line.Remark,                       -- 备注
                       l.pre_field_01 = r_Pln_Lg_Order_Line.Pre_Field_01,                 -- 订单行评审意见（原预留字段1）
                       l.pre_field_02 = r_Pln_Lg_Order_Line.Pre_Field_02,                 -- 预留字段2
                       l.pre_field_03 = r_Pln_Lg_Order_Line.Pre_Field_03,                 -- 预留字段3
                       l.pre_field_04 = r_Pln_Lg_Order_Line.Pre_Field_04,                 -- 预留字段4
                       l.pre_field_05 = r_Pln_Lg_Order_Line.Pre_Field_05,                 -- 预留字段5
                       l.pre_field_06 = r_Pln_Lg_Order_Line.Pre_Field_06,                 -- 预留字段6
                       l.carried_quantity = NULL,             -- 已提货数
                       l.affirmed_quantity = NULL,            -- 已评审数量
                       l.lg_ship_doc_id = NULL,               -- 发货通知单头id
                       l.check_content = NULL,                -- 评审意见
                       l.program_updated_by = 'PKG_PLN_INTF_CCS',           -- 程序修改来源
                       l.program_update_date = SYSDATE,           -- 修改时间
                       l.DEFAULT_UNIT = v_default_unit,                   --产品单位
                       l.PRODUCING_AREA_ID = v_Producing_Area_Id,              --产地ID
                       l.PRODUCING_AREA_CODE = v_producing_Area_Code,            --产地编码
                       l.PRODUCING_AREA_NAME = v_Producing_Area_Name,           --产地名称
                       L.CENTER_AFFIRM_QUANTITY = r_Pln_Lg_Order_Line.Quantity, --中心评审数量
                       L.CENTER_AFFIRM_AMOUNT = v_Apply_Amount,--NULL, --中心评审金额
                       L.IS_MARKED_COLLECT_FLAG = NULL,
                       L.SUBMIT_HQ_QTY = r_Pln_Lg_Order_Line.Quantity,
                       /*L.TO_APS_CAPACITY_QTY = NULL,
                       L.APS_CAPACITY_REC_QTY = NULL,
                       L.APS_CAPACITY_REC_DATE = NULL,*/
                       L.WORKTHROUGH_FLAG = NULL,
                       --L.ESTIMATE_CONSIGNMENT_DATE = NULL,
                       L.VERSION = NVL(L.VERSION, 0) + 1,
                       l.agent_usable_qty = r_Pln_Lg_Order_Line.Agent_Usable_Qty, --代理商可用库存
                       l.agent_stock_qty = r_Pln_Lg_Order_Line.Agent_Stock_Qty, --代理商库存水位
                       l.predict_already_qty = r_Pln_Lg_Order_Line.Predict_Already_Qty,  --剩余预测数提货量
                       l.discount_type = r_Pln_Lg_Order_Line.Discount_Type, --折扣类型 add by lizhen 2017-08-17
                       --Decode(v_Cre_Dis_Type_Enable, 'Y', v_Discount_Type_Common, Null), --折扣类型
                       l.match_number   = r_Pln_Lg_Order_Line.Match_Number, --配比数 add by lizhen 2017-06-08
                       l.begin_number   = r_Pln_Lg_Order_Line.Begin_Number  --起订数 add by lizhen 2017-06-08
                       ,l.item_competite_attr = v_Item_Competite_Attr --20170727 hejy3 引入产品竞争属性
                       ,l.item_plot_ratio = v_item_plot_ratio
                       ,l.demand_forecast_prompt = r_Pln_Lg_Order_Line.Demand_Forecast_Prompt
                       ,l.line_effective_flag = r_Pln_Lg_Order_Line.Line_Effective_Flag
                       ,l.pln_order_number        = r_Pln_Lg_Order_Head.Pln_Order_Number  --ccs推送的计划订单编号
                       ,l.origin_amount = r_Pln_Lg_Order_Line.Origin_Amount
                       ,l.lg_freight_fare = r_Pln_Lg_Order_Line.Lg_Freight_Fare --单台运费
					   ,l.custom_properties = r_Pln_Lg_Order_Line.Custom_Properties  --add by houhs at 20191101 增加定制属性字段
                       ,l.share_vendor_type = r_Pln_Lg_Order_Line.Share_Vendor_Type
                       ,l.sales_center_code = r_Pln_Lg_Order_Line.Share_Vendor_Code
                       ,l.share_vendor_name = r_Pln_Lg_Order_Line.Share_Vendor_Name
                       ,l.project_name=r_Pln_Lg_Order_Line.Project_Name   --add ex_wangkang4 20200520 项目名称
                 WHERE L.ORDER_LINE_ID = r_Pln_Lg_Order_Line.Order_Line_Id;
                 
                 --更新接口行表
                Update Intf_Pln_Lg_Order_Line l
                   Set l.Order_Line_Id = r_Pln_Lg_Order_Line.Order_Line_Id,
                       l.Order_Head_Id = v_Lg_Order_Head_Id
                 Where l.Intf_Id = r_Pln_Lg_Order_Line.Intf_Id;
                 
                
                --20170920 hejy3 删除原来已经引入的选配明细
                DELETE FROM T_PLN_LG_ORDER_ITEM_MATCH M
                 WHERE M.ORDER_LINE_ID = r_Pln_Lg_Order_Line.Order_Line_Id;
              ELSE
                Select s_Pln_Lg_Order_Line.Nextval Into v_Lg_Order_Line_Id From Dual;
                v_Value := '开始插入订单行表数据';

                Insert Into t_pln_lg_order_line
                ( entity_id,                     --业务主体
                  ORDER_LINE_ID,                -- 订单行id
                  ORDER_HEAD_ID,                 -- 订单头id
                  order_line_state,             -- 订单行状态
                  item_id,                      -- 产品id
                  item_code,                    -- 产品编码
                  item_name,                    -- 产品名称
                  unit_volume,                  -- 单位体积
                  unit_weight,                  -- 单位重量
                  list_price,                   -- 单价
                  sales_sub_type,               -- 营销小类
                  sales_main_type,              -- 营销大类
                  quantity,                     -- 申请数量
                  affirm_quantity,              -- 评审数量
                  finance_quantity,             -- 开单数量（出仓单数量，销售回写）
                  cancel_qty,                   -- 取消数量（物流回写）
                  received_qty,                 -- 签收数量（厨电，物流回写，建议删除）
                  way_qty,                      -- 在途数量（厨电，建议删除）
                  virtual_qty,                  -- 提货计划数（厨电，现有量）
                  apply_amount,                 -- 申请金额=申请数量*单价
                  inv_id,                       -- 仓库id
                  inv_code,                     -- 仓库编码
                  inv_name,                     -- 仓库名称
                  ship_inv_code,                -- 发货仓编码（调拨使用）
                  ship_inv_name,                -- 发货仓名称（调拨使用）
                  price_list_id,                -- 价格列表id
                  price_system_id,              -- 价格体系id
                  discount_rate,                -- 扣率（从价格列表带出，或手工填写）
                  ordered_discount_rate,        -- 月返。从价格列表获取的折扣（荣事达洗衣机需求）
                  discount_type_id,             -- 款项类型id（额度组、折扣类型统一名称）
                  sales_order_type_id,          -- 销售单类型id
                  project_order_type,           -- 批文类型（新增）
                  project_order_number,         -- 批文号
                  project_order_line_id,        -- 批文行id（用于基础模块进行对应产品扣减）
                  apply_list_price,             -- 申请价（工程机批文价格）
                  apply_discount_rate,          -- 申请折扣（工程机批文折扣）
                  source_type,                  -- 发货状态（“紧急订单”）
                  spec_qty,                     -- 凑整数量（厨电，从产品数据获取）
                  is_need_int,                  -- 是否凑整（厨电，从产品数据获取）
                  is_logistics,                 -- 是否生成发货单或运输合同（厨电）
                  biz_source_type,              -- 来源类型
                  biz_source_number,            -- 来源号
                  source_head_id,               -- 来源头id
                  source_head_code,             -- 来源头编码
                  source_line_id,               -- 来源行iid
                  lock_inv_pre,                 -- 锁定库存数量
                  lock_amount_percent,          -- 行锁定金额百分比
                  lock_amount_pre,              -- 行锁定金额
                  low_stock_init,               -- 默认最低库存？
                  high_stock_init,              -- 默认最高库存？
                  low_stock_adjust,             -- 调整最低库存？
                  high_stock_adjust,            -- 调整最高库存？
                  low_stock_confirm,            -- 确认最低库存？
                  high_stock_confirm,           -- 确认最高库存？
                  sended_qty,                   -- 已直发数量？
                  hq_pln4_order_qty,            -- 转总部计划订单数量（提货订单库存评审未满足部分需要转计划订单）
                  pln4_order_awaiting_qty,      -- 转总部计划订单等待数量
                  created_by,                   -- 创建人
                  creation_date,                -- 创建日期
                  last_updated_by,              -- 最后修改人
                  last_update_date,             -- 最后修改日期
                  remark,                       -- 备注
                  pre_field_01,                 -- 订单行评审意见（原预留字段1）
                  pre_field_02,                 -- 预留字段2
                  pre_field_03,                 -- 预留字段3
                  pre_field_04,                 -- 预留字段4
                  pre_field_05,                 -- 预留字段5
                  pre_field_06,                 -- 预留字段6
                  carried_quantity,             -- 已提货数
                  affirmed_quantity,            -- 已评审数量
                  lg_ship_doc_id,               -- 发货通知单头id
                  check_content,                -- 评审意见
                  program_updated_by,           -- 程序修改来源
                  program_update_date,           -- 修改时间
                  DEFAULT_UNIT,                   --产品单位
                  PRODUCING_AREA_ID,              --产地ID
                  PRODUCING_AREA_CODE,            --产地编码
                  PRODUCING_AREA_NAME,             --产地名称
                  agent_usable_qty,                --代理商可用库存
                  agent_stock_qty,                  --代理商库存水位
                  Predict_Already_Qty,              --剩余预测数提货量
                  discount_type, --折扣类型
                  match_number, --配比数 add by lizhen 2017-06-08
                  begin_number  --起订数 add by lizhen 2017-06-08
                  ,item_competite_attr --20170727 hejy3 引入产品竞争属性
                  ,item_plot_ratio
                  ,demand_forecast_prompt
                  ,line_effective_flag
                  ,pln_order_number --ccs推送的计划订单编号
                  ,origin_amount
                  ,lg_freight_fare --单台运费
				  ,custom_properties  --add by houhs at 20191101 增加定制属性字段
                  ,share_vendor_type
                  ,share_vendor_code
                  ,share_vendor_name
                  ,Project_Name  --add by ex_wangkang4 项目名称
                 )
              Values
                ( r_Pln_Lg_Order_Line.Entity_Id,  --ENTITY_ID --主体ID
                  v_Lg_Order_Line_Id,             --ORDER_LINE_ID --行ID
                  v_Lg_Order_Head_Id,             --ORDER_HEAD_ID --头ID
                  null,                           --ORDER_LINE_STATE --单据行状态
                  v_Item_Id,                      -- 产品id
                  r_Pln_Lg_Order_Line.Item_Code,  -- 产品编码
                  v_Item_Desc,                    -- 产品名称
                  v_Unit_Volume,  ----unit_volume   单位体积 lizhen 2015-12-05
                  --r_Pln_Lg_Order_Line.unit_volume, --unit_volume   单位体积
                  v_Unit_Weight, --unit_weight   单位重量 modi by lizhen 2015-12-05
                  --r_Pln_Lg_Order_Line.unit_weight, --unit_weight   单位重量
                  v_Item_Price,                   --list_price 单价
                  v_SALES_SUB_TYPE,               -- 营销小类
                  v_SALES_MAIN_TYPE,              -- 营销大类
                  r_Pln_Lg_Order_Line.Quantity,   -- 申请数量
                  null,                           -- 评审数量
                  null,                           -- 开单数量（出仓单数量，销售回写）
                  null,                           -- 取消数量（物流回写）
                  null,                           -- 签收数量（厨电，物流回写，建议删除）
                  null,                           -- 在途数量（厨电，建议删除）
                  r_Pln_Lg_Order_Line.virtual_qty,  -- 提货计划数（厨电，现有量）
                  v_Apply_Amount,                 -- 申请金额=申请数量*单价
                  Nvl(v_Inventory_Id, 0),         -- 仓库id  modi by lizhen 2017-06-08
                  v_Inventory_Code,               -- 仓库编码 modi by lizhen 2017-06-08
                  v_Inventory_Name,               -- 仓库名称 modi by lizhen 2017-06-08
                  null,                           -- 发货仓编码（调拨使用）
                  null,                           -- 发货仓名称（调拨使用）
                  null,                           -- 价格列表id
                  null,                           -- 价格体系id
                  v_Discount,                     -- 扣率（从价格列表带出，或手工填写）
                  v_Month_Discount,               -- 月返。从价格列表获取的折扣（荣事达洗衣机需求）
                  null,                           -- 款项类型id（额度组、折扣类型统一名称）
                  null,                           -- 销售单类型id
                  v_Apply_type,                   -- 批文类型（新增）
                  v_Apply_Code,                   -- 批文号
                  r_Pln_Lg_Order_Line.project_order_line_id,        -- 批文行id（用于基础模块进行对应产品扣减）
                  v_Apply_Price,             -- 申请价（工程机批文价格）
                  v_Apply_Discount,          -- 申请折扣（工程机批文折扣）
                  r_Pln_Lg_Order_Head.Exigence,   -- 发货状态（“紧急订单”）
                  v_Rounding_Cnt,                     -- 凑整数量（厨电，从产品数据获取）
                  v_Is_Rounding,                  -- 是否凑整（厨电，从产品数据获取）
                  null,                 -- 是否生成发货单或运输合同（厨电）
                  r_Pln_Lg_Order_Line.biz_source_type,              -- 来源类型
                  r_Pln_Lg_Order_Line.biz_source_number,            -- 来源号
                  r_Pln_Lg_Order_Line.source_head_id,               -- 来源头id
                  r_Pln_Lg_Order_Line.source_head_code,             -- 来源头编码
                  r_Pln_Lg_Order_Line.source_line_id,               -- 来源行iid
                  null,                                             -- 锁定库存数量
                  null,                                             -- 行锁定金额百分比
                  null,                                             -- 行锁定金额
                  null,                                             -- 默认最低库存？
                  null,                                             -- 默认最高库存？
                  null,                                             -- 调整最低库存？
                  null,                                             -- 调整最高库存？
                  null,                                             -- 确认最低库存？
                  null,                                             -- 确认最高库存？
                  null,                                             -- 已直发数量？
                  null,            -- 转总部计划订单数量（提货订单库存评审未满足部分需要转计划订单）
                  null,      -- 转总部计划订单等待数量
                  'PKG_PLN_INTF_CCS',                   -- 创建人
                  sysdate,                -- 创建日期
                  'PKG_PLN_INTF_CCS',              -- 最后修改人
                  sysdate,             -- 最后修改日期
                  r_Pln_Lg_Order_Line.remark,                       -- 备注
                  r_Pln_Lg_Order_Line.pre_field_01,                 -- 订单行评审意见（原预留字段1）
                  r_Pln_Lg_Order_Line.pre_field_02,                 -- 预留字段2
                  r_Pln_Lg_Order_Line.pre_field_03,                 -- 预留字段3
                  r_Pln_Lg_Order_Line.pre_field_04,                 -- 预留字段4
                  r_Pln_Lg_Order_Line.pre_field_05,                 -- 预留字段5
                  r_Pln_Lg_Order_Line.pre_field_06,                 -- 预留字段6
                  null,                                             -- 已提货数
                  null,                                             -- 已评审数量
                  null,                                             -- 发货通知单头id
                  null,                                             -- 评审意见
                  'PKG_PLN_INTF_CCS',                               -- 程序修改来源
                  SYSDATE,                                          -- 修改时间
                  v_default_unit,                                    --产品单位
                  v_PRODUCING_AREA_ID,             --产地ID   --modi by lizhen 2015-08-24
                  v_PRODUCING_AREA_CODE,           --产地编码 --modi by lizhen 2015-08-24
                  v_PRODUCING_AREA_NAME,            --产地名称 --modi by lizhen 2015-08-24
                  r_Pln_Lg_Order_Line.Agent_Usable_Qty, --代理商可用库存
                  r_Pln_Lg_Order_Line.Agent_Stock_Qty, --代理商库存水位
                  r_Pln_Lg_Order_Line.Predict_Already_Qty,  --剩余预测数提货量
                  r_Pln_Lg_Order_Line.Discount_Type, --折扣类型 add by lizhen 2017-08-17
                  --Decode(v_Cre_Dis_Type_Enable, 'Y', v_Discount_Type_Common, Null), --折扣类型
                  r_Pln_Lg_Order_Line.Match_Number, --配比数 add by lizhen 2017-06-08
                  r_Pln_Lg_Order_Line.Begin_Number  --起订数 add by lizhen 2017-06-08
                  ,v_Item_Competite_Attr --20170727 hejy3 引入产品竞争属性
                  ,v_item_plot_ratio
                  ,r_Pln_Lg_Order_Line.Demand_Forecast_Prompt
                  ,r_Pln_Lg_Order_Line.Line_Effective_Flag
                  ,r_Pln_Lg_Order_Head.Pln_Order_Number --ccs推送的计划订单编号
                  , r_Pln_Lg_Order_Line.Origin_Amount
                  ,r_Pln_Lg_Order_Line.Lg_Freight_Fare --单台运费
				  ,r_Pln_Lg_Order_Line.Custom_Properties   --add by houhs at 20191101 增加定制属性字段
                  ,r_Pln_Lg_Order_Line.Share_Vendor_Type
                  ,r_Pln_Lg_Order_Line.Share_Vendor_Code
                  ,r_Pln_Lg_Order_Line.Share_Vendor_Name
                  ,r_Pln_Lg_Order_Line.Project_Name   --add by ex_wangkang4 20200520  项目名称
                  );

                  --更新接口行表
                  update intf_pln_lg_order_line l
                  set l.order_line_id=v_Lg_Order_Line_Id,l.order_head_id=v_Lg_Order_Head_Id
                  where l.intf_id=r_Pln_Lg_Order_Line.Intf_Id;
               END IF;

            Exception
              When Others Then
                p_Result := v_Value || '失败。' || v_Nl || Sqlerrm;
                  raise V_CCS_EXCEPTION;
            End;
          End If;
          
          --20170920 hejy3 插入选配明细
          if p_Result = v_Success then
            v_Value := '插入选配明细数据';
            begin
              insert into t_pln_lg_order_item_match
                (entity_id,
                 item_match_id,
                 order_line_id,
                 order_head_id,
                 item_code,
                 item_name,
                 item_matc_id,
                 item_matc_name,
                 item_option_id,
                 item_option_name,
                 pre_field_01,
                 pre_field_02,
                 pre_field_03,
                 pre_field_04,
                 pre_field_05,
                 pre_field_06,
                 remark,
                 created_by,
                 creation_date,
                 last_updated_by,
                 last_update_date)
              select im.entity_id,
                     s_pln_lg_order_item_match.nextval,
                     v_Lg_Order_Line_Id,
                     v_Lg_Order_Head_Id,
                     im.item_code,
                     im.item_name,
                     im.item_matc_id,
                     im.item_matc_name,
                     im.item_option_id,
                     im.item_option_name,
                     im.pre_field_01,
                     im.pre_field_02,
                     im.pre_field_03,
                     im.pre_field_04,
                     im.pre_field_05,
                     im.pre_field_06,
                     im.remark,
                     'PKG_PLN_INTF_CCS',
                     sysdate,
                     'PKG_PLN_INTF_CCS',
                     sysdate
                from intf_pln_lg_order_item_match im
               where im.intf_id = r_Pln_Lg_Order_Line.Intf_Id;
            exception
              When Others Then
                p_Result := v_Value || '失败。' || v_Nl || Sqlerrm;
                raise V_CCS_EXCEPTION;
            end;
          end if;
          
        END IF;
      end loop;
      close c_Pln_Lg_Order_Line;
   end if;
   
   --检查订单行产地是否对应同一个基地
   IF P_RESULT = V_SUCCESS AND R_PLN_ORDER_TYPE.IS_PRODUCT_AREA_SPLIT = 'Y' THEN
     SELECT COUNT(DISTINCT PA.PROD_AREA_ID)
       INTO V_PRODUCING_AREA_ID_COUNT
       FROM T_PLN_LG_ORDER_LINE L, T_PLN_PRODUCING_AREA PA
      WHERE PA.PRODUCING_AREA_ID = L.PRODUCING_AREA_ID
        AND L.ORDER_HEAD_ID = V_LG_ORDER_HEAD_ID;
     IF V_PRODUCING_AREA_ID_COUNT <> 1 THEN
       BEGIN
         --获取订单行数
         SELECT COUNT(1)
           INTO V_COUNT
           FROM T_PLN_LG_ORDER_LINE L
          WHERE L.ORDER_HEAD_ID = V_LG_ORDER_HEAD_ID;
         --获取基地
         SELECT TT.PROD_AREA_ID, TT.PROD_AREA_CODE, TT.PROD_AREA_NAME
           INTO v_Prod_Area_Id,v_Prod_Area_Code,v_Prod_Area_Name
           FROM (SELECT T.PROD_AREA_ID,
                        T.PROD_AREA_CODE,
                        T.PROD_AREA_NAME,
                        COUNT(DISTINCT T.ITEM_CODE) COUNT1
                   FROM (SELECT L.ITEM_CODE,
                                PPA.PRODUCING_AREA_ID,
                                PPA.PRODUCING_AREA_CODE,
                                PPA.PRODUCING_AREA_NAME,
                                B.PROD_AREA_ID,
                                B.PROD_AREA_CODE,
                                B.PROD_AREA_NAME
                           FROM CIMS.T_PLN_ITEM_PRODUCING_AREA A,
                                CIMS.T_PLN_PRODUCING_AREA      PPA,
                                CIMS.T_PLN_PRODUCTION_BASE     B,
                                CIMS.T_PLN_LG_ORDER_LINE       L
                          WHERE A.PRODUCING_AREA_ID = PPA.PRODUCING_AREA_ID
                            AND PPA.PROD_AREA_ID = B.PROD_AREA_ID
                            AND A.PRODUCING_AREA_ID = L.PRODUCING_AREA_ID
                            AND L.ITEM_CODE = A.ITEM_CODE
                            AND (A.ENTITY_ID = L.ENTITY_ID OR
                                A.ENTITY_ID IN
                                (SELECT DISTINCT OTR.TRANSFER_ENTITY_ID
                                    FROM T_PLN_ORDER_TYPE_RELA OTR
                                   WHERE OTR.SOURCE_ENTITY_ID = L.ENTITY_ID))
                            AND L.ORDER_HEAD_ID = v_Lg_Order_Head_Id
                         UNION ALL
                         SELECT L.ITEM_CODE,
                                NULL,
                                NULL,
                                NULL,
                                B.PROD_AREA_ID,
                                B.PROD_AREA_CODE,
                                B.PROD_AREA_NAME
                           FROM CIMS.T_PLN_ITEM_BASE_RELATION A,
                                CIMS.T_PLN_PRODUCTION_BASE    B,
                                CIMS.T_PLN_LG_ORDER_LINE      L
                          WHERE A.PROD_AREA_ID = B.PROD_AREA_ID
                            AND L.ITEM_CODE = A.ITEM_CODE
                            AND (A.ENTITY_ID = L.ENTITY_ID OR
                                A.ENTITY_ID IN
                                (SELECT DISTINCT OTR.TRANSFER_ENTITY_ID
                                    FROM T_PLN_ORDER_TYPE_RELA OTR
                                   WHERE OTR.SOURCE_ENTITY_ID = L.ENTITY_ID))
                            AND L.ORDER_HEAD_ID = v_Lg_Order_Head_Id) T
                  GROUP BY T.PROD_AREA_ID,
                           T.PROD_AREA_CODE,
                           T.PROD_AREA_NAME) TT
          WHERE TT.COUNT1 >= v_Count
            AND ROWNUM = 1;   
       EXCEPTION
         WHEN OTHERS THEN
           P_RESULT := v_Entity_Name || '，订单行上所有产品的产地对应的基地不一致！获取基地失败！';
           RAISE V_CCS_EXCEPTION;
       END;
     ELSE
       BEGIN
         --获取提货订单头上的基地
         SELECT PB.PROD_AREA_ID, PB.PROD_AREA_CODE, PB.PROD_AREA_NAME
           INTO V_PROD_AREA_ID, V_PROD_AREA_CODE, V_PROD_AREA_NAME
           FROM T_PLN_LG_ORDER_LINE   T,
                T_PLN_PRODUCING_AREA  PA,
                T_PLN_PRODUCTION_BASE PB
          WHERE T.ORDER_HEAD_ID = V_LG_ORDER_HEAD_ID
            AND T.PRODUCING_AREA_ID = PA.PRODUCING_AREA_ID
            AND PA.PROD_AREA_ID = PB.PROD_AREA_ID
            AND ROWNUM = 1;
       EXCEPTION
         WHEN OTHERS THEN
           P_RESULT := v_Entity_Name || '，获取基地失败！';
           RAISE V_CCS_EXCEPTION;
       END;    
     END IF;
     UPDATE T_PLN_LG_ORDER_HEAD H
        SET H.PROD_AREA_ID   = V_PROD_AREA_ID,
            H.PROD_AREA_CODE = V_PROD_AREA_CODE,
            H.PROD_AREA_NAME = V_PROD_AREA_NAME
      WHERE H.ORDER_HEAD_ID = V_LG_ORDER_HEAD_ID;
   END IF;
   
   --ADD BY LIZHEN 2017-08-16启用了折让到款的主体CCS提单时检查款项
   If v_Cre_Dis_Type_Enable = 'Y' Then
     --20180620 hejy3 提交不锁款默认为常规
     IF r_Pln_Order_Type.Source_Order_Type_Id = 1 THEN --提货订单才处理
      IF r_Pln_Order_Type.Chk_Cusg_Amount_Flag In ('S', 'RS') THEN --送审锁款取配置表，否则默认为空
        BEGIN
          SELECT L.DOWN_PAY_RATE INTO V_DOWN_PAY_RATE
            FROM T_CREDIT_ACCOUNT_LIMIT L
           WHERE L.ENTITY_ID = r_Pln_Lg_Order_Head.Entity_Id
             AND L.CUSTOMER_ID = r_Pln_Lg_Order_Head.Customer_Id
             AND L.SALES_CENTER_ID = r_Pln_Lg_Order_Head.Sales_Center_Id
             AND L.ACCOUNT_ID = r_Pln_Lg_Order_Head.Account_Id;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            --获取参数值
            BEGIN
              V_DOWN_PAY_RATE := PKG_BD.F_GET_PARAMETER_VALUE('CREDIT_DOWN_PAY_SCALE',
                                                               r_Pln_Lg_Order_Head.Entity_Id);
            EXCEPTION
              WHEN OTHERS THEN
                P_RESULT := '获取订金比例参数【CREDIT_DOWN_PAY_SCALE】失败！' || V_NL ||
                            SQLERRM;
                RAISE V_CCS_EXCEPTION;
            END;
        END;
      ELSE
        V_DOWN_PAY_RATE := NULL;
      END IF;
    END IF;
    
    --20180620 hejy3 非送审锁款或送审锁款锁0订金则设置折扣类型为常规到款
    IF nvl(r_Pln_Order_Type.Chk_Cusg_Amount_Flag, 'N') NOT IN ('S', 'RS', 'HQ') or V_DOWN_PAY_RATE <= 0
      or (nvl(r_Pln_Lg_Order_Head.Customer_Channel_Type, '_')   in(pkg_pln_pub.V_CUSTOMER_CHANNEL_TYPE_WP ,pkg_pln_pub.V_CUSTOMER_CHANNEL_TYPE_NIFFER,
      PKG_PLN_PUB.V_CUSTOMER_CHANNEL_TYPE_SHARE) and
         r_Pln_Lg_Order_Head.Fund_Check_Mode = PKG_PLN_PUB.FUND_CHECK_MODE_ORDER)
         or (nvl(r_Pln_Lg_Order_Head.Customer_Channel_Type, '_') = PKG_PLN_PUB.V_CUSTOMER_CHANNEL_TYPE_SHARE) then
      --更新折扣类型
     Update t_Pln_Lg_Order_Line Lol
        Set Lol.Discount_Type = v_Discount_Type_Common
      Where Lol.Order_Head_Id = v_Lg_Order_Head_Id
        And Lol.Discount_Type Is Null;
    else
     For r_Check_Amount In (Select Nvl(Lol.Sales_Main_Type, Bi.Sales_Main_Type) Sales_Main_Type,
                                   Lol.Discount_Type,
                                   Sum(Round(Decode(Lol.Project_Order_Number,
                                                    Null,
                                                    (Nvl(Lol.Quantity, 0) *
                                                    Nvl(Lol.List_Price, 0) *
                                                    (100 - Nvl(Lol.Discount_Rate, 0) -
                                                    Nvl(Lol.Ordered_Discount_Rate, 0))) / 100,
                                                    (Nvl(Lol.Quantity, 0) *
                                                    Nvl(Lol.Apply_List_Price,0) *
                                                    (100 -
                                                    Decode(v_Price_Apply_Use_Discount,
                                                             'Y',
                                                             Nvl(Lol.Apply_Discount_Rate, 0),
                                                             0) -
                                                    Nvl(Lol.Ordered_Discount_Rate, 0))) / 100),
                                             2)) Apply_Amount,
                                   Sum(Round(Decode(Lol.Project_Order_Number,
                                                    Null,
                                                    (Nvl(Lol.Quantity, 0) *
                                                    Nvl(Lol.List_Price, 0) *
                                                    Nvl(Lol.Discount_Rate, 0)) / 100,
                                                    Nvl(Lol.Quantity, 0) *
                                                     Nvl(Lol.Apply_List_Price, 0) *
                                                     Decode(v_Price_Apply_Use_Discount,
                                                            'Y',
                                                            Nvl(Lol.Apply_Discount_Rate, 0), 0) / 100),
                                             2)) Discount_Amount
                              From t_Pln_Lg_Order_Line Lol, t_Bd_Item Bi
                             Where Lol.Item_Id = Bi.Item_Id
                               And Bi.Entity_Id = Lol.Entity_Id
                               And Lol.Order_Head_Id = v_Lg_Order_Head_Id
                               And Lol.Entity_Id = r_Pln_Lg_Order_Head.Entity_Id
                             Group By Nvl(Lol.Sales_Main_Type, Bi.Sales_Main_Type),
                                      Lol.Discount_Type) Loop
       If r_Check_Amount.Discount_Type Is Null Then
         --如果CCS未传入 到款类型时，接口同时检查常规到款、折让到款，优先使用常规到款
         pkg_pln_intf_ccs.p_Submit_Check_Amount(p_Order_Type_Id   => r_Pln_Lg_Order_Head.Order_Type_Id,
                                                p_Customer_Id     => r_Pln_Lg_Order_Head.Customer_Id,
                                                p_Account_Id      => v_Account_Id,
                                                p_Sales_Main_Type => r_Check_Amount.Sales_Main_Type,
                                                p_Amount          => r_Check_Amount.Apply_Amount,
                                                p_Discount_Amount => r_Check_Amount.Discount_Amount,
                                                p_Result          => p_Result,
                                                p_Message         => v_Message,
                                                IN_DISCOUNT_TYPE  => v_Discount_Type_Common);
         If p_Result != v_Success Then
           --常规款项不足检查折让款项
           pkg_pln_intf_ccs.p_Submit_Check_Amount(p_Order_Type_Id   => r_Pln_Lg_Order_Head.Order_Type_Id,
                                                  p_Customer_Id     => r_Pln_Lg_Order_Head.Customer_Id,
                                                  p_Account_Id      => v_Account_Id,
                                                  p_Sales_Main_Type => r_Check_Amount.Sales_Main_Type,
                                                  p_Amount          => r_Check_Amount.Apply_Amount,
                                                  p_Discount_Amount => r_Check_Amount.Discount_Amount,
                                                  p_Result          => p_Result,
                                                  p_Message         => v_Message,
                                                  IN_DISCOUNT_TYPE  => v_Discount_Type_Discount);
           If p_Result != v_Success Then
             p_Result := v_Entity_Name || '，检查客户常规到款、折让到款可提货金额都不满足本次提货订单金额。';
             Raise V_CCS_EXCEPTION;
           Else
             v_Discount_Type := v_Discount_Type_Discount;
           End If;
         Else
           v_Discount_Type := v_Discount_Type_Common;
         End If;
       Else
         pkg_pln_intf_ccs.p_Submit_Check_Amount(p_Order_Type_Id   => r_Pln_Lg_Order_Head.Order_Type_Id,
                                                p_Customer_Id     => r_Pln_Lg_Order_Head.Customer_Id,
                                                p_Account_Id      => v_Account_Id,
                                                p_Sales_Main_Type => r_Check_Amount.Sales_Main_Type,
                                                p_Amount          => r_Check_Amount.Apply_Amount,
                                                p_Discount_Amount => r_Check_Amount.Discount_Amount,
                                                p_Result          => p_Result,
                                                p_Message         => v_Message,
                                                IN_DISCOUNT_TYPE  => r_Check_Amount.Discount_Type);
         If p_Result != v_Success Then
           p_Result := v_Entity_Name || '，'||v_Message;
           Raise V_CCS_EXCEPTION;
         Else
           v_Discount_Type := r_Check_Amount.Discount_Type; 
         End If;
       End If;
         
       --更新折扣类型
       Update t_Pln_Lg_Order_Line Lol
          Set Lol.Discount_Type = v_Discount_Type,
              --20171206 hejy3 折让到款把折扣率清0
              lol.discount_rate = decode(v_Discount_Type, v_Discount_Type_Discount, 0, lol.discount_rate),
              lol.apply_discount_rate = decode(v_Discount_Type, v_Discount_Type_Discount, 0, lol.apply_discount_rate)
        Where Lol.Order_Head_Id = v_Lg_Order_Head_Id
          And Nvl(Lol.Sales_Main_Type, r_Check_Amount.Sales_Main_Type) = r_Check_Amount.Sales_Main_Type
          And Lol.Discount_Type Is Null;
     End Loop;
     end if;
   End If;

   If p_Result = v_Success Then
      begin
        v_Value := '订单送审：';
        pkg_pln_order.p_Order_Operate(p_Order_Head_Id    => v_Lg_Order_Head_Id,
                                      p_Order_Type_Id    => r_Pln_Lg_Order_Head.Order_Type_Id,
                                      p_Operation_Action => '送审',
                                      p_User_Code        => 'admin',
                                      p_Result           => p_Result);
        if p_Result <> v_Success then
            raise V_CCS_EXCEPTION;
        end if;
      exception
         when V_CCS_EXCEPTION then
              p_Result := v_Value ||'失败。'||v_Entity_Name || '，'||p_Result;
              raise V_CCS_EXCEPTION;
         When Others Then
              p_Result := v_Value ||'失败。'||v_Entity_Name || '，'||p_Result||v_Nl||sqlerrm;
              raise V_CCS_EXCEPTION;
      End;

      if r_Pln_Order_Type.Is_Business_Control = v_Bussiness_Control And nvl(r_Pln_Order_Type.Is_Dierect_Match, 'N') <> 'Y' Then
        Begin
          v_Value := '自动匹配评审：';
          Pkg_Pln_Lg_Order.p_Lgorder_Shareship_Review(v_Lg_Order_Head_Id,
                                                      'admin',
                                                      p_Result);
          
          if p_Result <> v_Success then
              raise V_CCS_EXCEPTION;
          end if;

         /* v_Message:='提货订单可发货数量不足: '||v_Nl;
          v_Count:=0;
          For r_pln_lg_line_check in ( select *
                          from t_pln_lg_order_line l
                          where nvl(l.quantity,0) <> nvl(l.affirm_quantity,0)
                          and l.order_head_id=v_Lg_Order_Head_Id
                          and l.entity_id=r_Pln_Lg_Order_Head.Entity_Id) loop
          v_Message:=v_Message|| '产品编码 '|| r_pln_lg_line_check.item_code||
                       ' 申请数量 '||r_pln_lg_line_check.quantity||
                       ' 可提货数量 '||r_pln_lg_line_check.affirm_quantity||v_Nl;
          v_Count:=v_Count+1;
          End loop;

          if v_Count>0 then
            p_Result:=v_Message;
            raise V_CCS_EXCEPTION;
          end if;*/

        exception
           when V_CCS_EXCEPTION then
             p_Result := v_Value ||'失败。'||v_Entity_Name || '，'||p_Result;
             raise V_CCS_EXCEPTION;
           When Others Then
             p_Result := v_Value ||'失败。'||v_Entity_Name || '，'||p_Result||v_Nl||sqlerrm;
             raise V_CCS_EXCEPTION;
        End;
      
      else
        --暂时把网批订单自动评审做成异步处理
        IF NVL(r_Pln_Lg_Order_Head.Customer_Channel_Type, '_') not in(pkg_pln_pub.V_CUSTOMER_CHANNEL_TYPE_WP ,pkg_pln_pub.V_CUSTOMER_CHANNEL_TYPE_NIFFER,
          PKG_PLN_PUB.V_CUSTOMER_CHANNEL_TYPE_SHARE) THEN
          --常规订单自动评审
          v_Value := '自动库存评审：';
          PKG_PLN_LG_ORDER.P_LGORDER_AUTO_SHIP(IN_LG_ORDER_ID => v_Lg_Order_Head_Id, OUT_RESULT => p_Result);
          IF p_Result <> v_Success THEN
            p_Result := v_Value ||'失败。'||v_Entity_Name || '，'||p_Result;
            raise V_CCS_EXCEPTION;
          END IF;
        END IF;
      end if;

   End If;

   if p_Result = v_Success then
      begin
        v_Value := '更新接口表状态：';
        Update Intf_Pln_Lg_Order_Head Oh
         Set Oh.Intf_Status = v_Status_Sucess,
             Oh.Error_Message = p_Result,
             oh.last_update_date = sysdate,
             Oh.Order_Head_Id=v_Lg_Order_Head_Id,
             Oh.Order_Number=v_Order_Number
       Where Oh.Intf_Id = r_Pln_Lg_Order_Head.Intf_Id;
       --Commit;  --modi by lizhen 2015-12-16取消自制式事务
      exception
         When Others Then
          p_Result := v_Value || '接口表ID ' || r_Pln_Lg_Order_Head.Intf_Id ||'失败。';
          raise V_CCS_EXCEPTION;
      End;
    end if;


   <<errlable>>
   If p_Result <> v_Success Then
      raise V_CCS_EXCEPTION;
    End If;

  Exception
    When V_CCS_EXCEPTION Then
      Rollback;
      p_Result := '失败：' || p_Result;
      Update Intf_Pln_Lg_Order_Head Oh
         Set Oh.Intf_Status = v_Status_Fail, Oh.Error_Message = p_Result
       Where Oh.Intf_Id = p_Intf_Id;

      v_Value:=pkg_bd.F_ADD_ERROR_LOG('pkg_pln_intf_ccs.P_CREATE_INTF_LG_ORDER',
                               1000,
                               p_Intf_Id||'|'||p_Result);
    When Others Then
      Rollback;
      p_Result := '失败：' || p_Result || v_Nl || Sqlerrm;
      Update Intf_Pln_Lg_Order_Head Oh
         Set Oh.Intf_Status = v_Status_Fail, Oh.Error_Message = p_Result
       Where Oh.Intf_Id = p_Intf_Id;

      v_Value:=pkg_bd.F_ADD_ERROR_LOG('pkg_pln_intf_ccs.P_CREATE_INTF_LG_ORDER',
                               1000,
                               p_Intf_Id||'|'||p_Result);
      --Commit;  --modi by lizhen 2015-12-16取消自制式事务
  End;
  
  /*
   计划订单接口函数
  */
  PROCEDURE P_CREATE_INTF_PL_ORDER(p_Intf_Id      IN NUMBER, --计划订单接口表订单头ID
                                   p_Result       OUT VARCHAR2) IS
    v_Value Varchar2(1000);
  PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
    p_Result := v_Success;
    
    pkg_pln_intf_ccs.P_CREATE_INTF_PL_ORDER_NEW(p_Intf_Id => p_Intf_Id,
                                                p_Result  => p_Result);
    
    IF p_Result <> v_Success THEN
      RAISE V_CCS_EXCEPTION;
    else
      commit;
    END IF;
  EXCEPTION
    --20170904 hejy3 针对V_CCS_EXCEPTION异常回写订单
    when V_CCS_EXCEPTION then
      Rollback;
      p_Result := '失败：' || p_Result;
      Update Intf_Pln_Order_Head Oh
         Set Oh.Intf_Status = v_Status_Fail, Oh.Error_Message = p_Result
       Where Oh.Intf_Id = p_Intf_Id;

      v_Value:=pkg_bd.F_ADD_ERROR_LOG('pkg_pln_intf_ccs.P_CREATE_INTF_PL_ORDER',
                               2000,
                               p_Intf_Id||'|'||p_Result);
      Commit;
     When Others Then
      Rollback;
      p_Result := '失败：' || p_Result || v_Nl || Sqlerrm;
      Update Intf_Pln_Order_Head Oh
         Set Oh.Intf_Status = v_Status_Fail, Oh.Error_Message = p_Result
       Where Oh.Intf_Id = p_Intf_Id;

      v_Value:=pkg_bd.F_ADD_ERROR_LOG('pkg_pln_intf_ccs.P_CREATE_INTF_PL_ORDER',
                               2000,
                               p_Intf_Id||'|'||p_Result);
      Commit;
  END P_CREATE_INTF_PL_ORDER;

  PROCEDURE P_CREATE_INTF_PL_ORDER_NEW(p_Intf_Id      IN NUMBER, --计划订单接口表订单头ID
                                   p_Result       OUT VARCHAR2) is

      r_Pln_Order_Head     Intf_Pln_Order_Head%Rowtype;
      r_Pln_Order_Type     T_Pln_Order_Type%Rowtype;
      r_Pln_Order_Period   T_pln_order_period%Rowtype;

      cursor c_Pln_Order_Line is
             select * from intf_Pln_Order_Line l
             where l.intf_head_id = p_Intf_Id
             And   l.intf_status  = v_Status_Init;
      r_Pln_Order_Line  c_Pln_Order_Line%Rowtype;

      v_Value           Varchar2(1000);
      v_Count           Number;
      v_LineCount       Number;
      v_Entity_Name     Varchar2(100);
      v_Period_Id       Number;
      v_Period_Code t_Pln_Order_Period.Period_Code%Type;
      v_Period_Week t_Pln_Order_Period.Statistic_Week%Type;

      v_Order_Type_Code r_Pln_Order_Type.Order_Type_Code%Type;
      v_Order_Type_Name r_Pln_Order_Type.Order_Type_Name%Type;
      v_Send_By_Type    r_Pln_Order_Type.Send_By_Type%Type;

      v_SALES_MAIN_TYPE varchar2(32);--订单头大小类
      v_SALES_SUB_TYPE  varchar2(32);

      v_Sales_Center_Code Varchar2(100);
      v_Sales_Center_Name Varchar2(240);

      v_Customer_Code Varchar2(100);
      v_Customer_Name Varchar2(240);
      v_Customer_Id   number;

      v_Account_Id           number;
      v_Account_Code         Varchar2(100);
      v_Account_Name         Varchar2(240);

      v_Invoice_Contract_Id  Number;        --开票单位联系人ID
      v_Invoice_Contract     Varchar2(100); --开票单位联系人名称
      v_Invoice_Tel          Varchar2(100); --开票单位联系人电话

      v_Consignee_Id         Number;        --收货单位ID
      v_Consignee_Code       Varchar2(240); --收货单位编码
      v_Consignee_Name       Varchar2(240); --收货单位名称

      v_Consignment_Addr_Id  Number;        --收货地点ID
      v_Consignee_Addr       Varchar2(240); --收货地址
      v_Consignee_Addr_Code  Varchar2(240); --收货地址编码
      v_Consignee_Contact_Id Number;        --收货联系人ID
      v_Consignee_Contract   Varchar2(240); --收货联系人
      v_Consignee_Tel        Varchar2(240); --收货联系电话

      v_Producing_Area_Id    Number;
      v_Producing_Area_Code  Varchar2(100);
      v_Producing_Area_Name  Varchar2(240);

      v_Order_Head_Id        Number;
      v_Order_Number         Varchar2(60);
      v_Batch_Id             Number := 1;

      v_Item_Main_Type_Filter               Varchar2(10);
      v_Item_Sub_Type_Filter                Varchar2(10);
      v_Order_Line_Id                       number;
      v_Item_Id         Number;
      v_Item_Desc       Varchar2(240);
      v_Item_Uom        Varchar2(32);

      v_ITEM_SALES_MAIN_TYPE varchar2(32); --订单行产品大小类
      v_ITEM_SALES_SUB_TYPE  varchar2(32);

      v_Item_Price           Number;        --产品价格
      v_Discount             Number;        --折扣
      v_Month_Discount       Number;        --月返
      v_Cx_Flag              Varchar2(10);  --是否促销机
      v_Apply_Amount         Number;        --申请金额
      v_CanApplyNum          Number;        --周排产可生产数量
      v_Is_Check_Price                      varchar2(10);--是否检查价格
      v_Is_MATERIAL_RANGE_FLAG              varchar2(10);--是否受产品型谱控制
      V_IS_SAMPLE_NEED                      varchar2(10);--是否样机订单
      v_IS_Week                             varchar2(10);--是否周排产订单
      
      V_IS_MATERIAL          T_BD_ITEM.IS_MATERIAL%TYPE; --物料标志
      v_is_business_control  t_pln_order_type.is_business_control%TYPE;
      v_Unit_Volume           Number;
      v_Unit_Weight           Number;
      v_Consignee_Add_4_Flag  Varchar2(10);
      v_promise_days          Number; --承诺交期天数
      V_Can_Supply_Date      T_PLN_ORDER_LINE.Can_Supply_Date%Type;

  --PRAGMA AUTONOMOUS_TRANSACTION;
  Begin
    p_Result:=v_Success;

    ----------------------------------------------------------------------
    --  接口数据头表数据检测
    ----------------------------------------------------------------------

     --检测订单接口
    Begin
      v_Value := '锁定订单接口头表失败！';
      Select *
        Into r_Pln_Order_Head
        From Intf_Pln_Order_Head h
       Where h.Intf_Id = p_Intf_Id
         And h.Intf_Status = v_Status_Init
         For Update Nowait;
    Exception
      When Others Then
        p_Result := v_Value || sqlerrm;
        raise V_CCS_EXCEPTION;
    End;

    if p_Result = v_Success then
      v_Value := '来源系统检测：';
      if Nvl(r_Pln_Order_Head.Sys_Source, '_') = '_' then
         p_Result := v_Value || '未录入来源系统标示。';
           raise V_CCS_EXCEPTION;
      end if;
    End if;
    
    --add by lizhen 2016-01-16 快码设置是否不启用4级收货地点
    Begin
      Select Nvl(Uc.Code_Value, 'Y')
        Into v_Consignee_Add_4_Flag
        From Up_Codelist Uc
       Where Uc.Codetype = 'PLN_CONSIGNEE_ADD_4'
         And Uc.Enabled = 0;
    Exception
      When Others Then
        v_Consignee_Add_4_Flag := 'Y';
    End;

     --主体编码检测
    if p_Result = v_Success then
      begin
        v_Value := '主体编码检测：';
        select b.entity_name
           into v_Entity_Name
        from v_bd_entity b
        where b.entity_id=r_Pln_Order_Head.Entity_Id;
      exception
         When Others Then
          p_Result := v_Value || '主体编码' || r_Pln_Order_Head.Entity_Id ||'无效。';
          raise V_CCS_EXCEPTION;
      End;
    end if;

    If p_Result = v_Success Then
      --检查单据类型
      Begin
        v_Value := '单据类型检查：';
        Select Ot.Order_Type_Code,
               Ot.Order_Type_Name,
               Ot.Period_Week,
               Ot.Send_By_Type,
               Ot.Is_Price_Check,
               Ot.Is_Material_Range_Flag,
               Ot.Is_Sample_Need,
               Ot.Is_Week,
               ot.is_business_control,
               ot.promise_days
          Into v_Order_Type_Code,
               v_Order_Type_Name,
               v_Period_Week,
               v_Send_By_Type,
               v_Is_Check_Price,
               v_Is_MATERIAL_RANGE_FLAG,
               V_IS_SAMPLE_NEED,
               v_IS_Week,
               v_is_business_control,
               v_promise_days
          From t_Pln_Order_Type Ot
         Where Ot.Order_Type_Id = r_Pln_Order_Head.Order_Type_Id
           And Ot.Entity_Id=r_Pln_Order_Head.Entity_Id
           And Trunc(Sysdate) Between Ot.Begin_Date And
               Trunc(Nvl(Ot.End_Date, Sysdate));
      Exception
        When Others Then
          p_Result := v_Value || '单据类型ID：' ||
                      To_Char(r_Pln_Order_Head.Order_Type_Id) ||
                      '不存在或者单据类型已失效。';
      End;
      
      --订单承诺周期按订单时间+n天做承诺交期
      If v_promise_days Is Not Null Then
        Begin
          Select Loh.To_Checkup_Date + v_Promise_Days
            Into V_Can_Supply_Date
            From t_Pln_Lg_Order_Head Loh
           Where Loh.Order_Head_Id = r_Pln_Order_Head.Source_Order_Head_Id;
        Exception
          When Others Then
            V_Can_Supply_Date := Null;
        End;
      End If;
    End If;

    If p_Result = v_Success Then
      Begin
        v_Value := '获取周期信息';
        Select Op.Period_Id, Op.Period_Code, Op.Statistic_Week
          Into v_Period_Id, v_Period_Code, v_Period_Week
          From t_Pln_Order_Period Op
         Where Op.Entity_Id = r_Pln_Order_Head.Entity_Id
           And Op.Period_Id = r_Pln_Order_Head.Period_Id
               /*F_Get_Period(r_Pln_Order_Head.Order_Type_Id,
                            r_Pln_Order_Head.Entity_Id)*/;
         /*if v_Period_Id != r_Pln_Order_Head.Period_Id then
            v_Value:='接口上报周期 ID' || r_Pln_Order_Head.Period_Id
                     ||' 与系统获取默认周期 ID' ||  v_Period_Id
                     ||' 不一致';
              raise V_CCS_EXCEPTION;
         end if;*/
      Exception
        When Others Then
          p_Result := v_Value || '失败。' ;
            raise V_CCS_EXCEPTION;
      End;
    End If;



    /*\*
        0  按周报送
        1  按月报送
        2  按月多次报送
        3  按年报送
        4  按周多次报送
        5  不定期报送
        *\
    If v_Send_By_Type in (0,1,3) Then
      Select Count(1)
       Into v_Count
       From t_pln_order_head h
      Where h.customer_id
        And l.Entity_Id = r_Pln_Order_Head.Entity_Id;
     If v_Count = 0 Then
       p_Result := '无订单行资料，校验失败。';
         raise V_CCS_EXCEPTION;
     End If;
    End If;*/

    --获取大类检测主体参数
    Begin
      v_Item_Main_Type_Filter := Pkg_Bd.f_Get_Parameter_Value('ITEM_SALES_MAIN_TYPE_FILTER',
                                                         r_Pln_Order_Head.Entity_Id);
    Exception
      When Others Then
        p_Result := '获取ITEM_SALES_MAIN_TYPE_FILTER参数失败' ;
          raise V_CCS_EXCEPTION;
    End;
    --获取小类检测主体参数
    Begin
      v_Item_Sub_Type_Filter := Pkg_Bd.f_Get_Parameter_Value('ITEM_SALES_SUB_TYPE_FILTER',
                                                         r_Pln_Order_Head.Entity_Id);
    Exception
      When Others Then
        p_Result := '获取ITEM_SALES_SUB_TYPE_FILTER参数失败';
          raise V_CCS_EXCEPTION;
    End;
    If p_Result = v_Success Then
      Begin
          Select Count(1)
            Into v_LineCount
          From intf_Pln_Order_Line l
          Where l.intf_head_id = p_Intf_Id;

          If v_Count = 0 Then
             p_Result := '无订单行资料，校验失败。';
               raise V_CCS_EXCEPTION;
          End If;

      Exception
         When Others Then
          p_Result := '计算订单行总行数有误' ;
            raise V_CCS_EXCEPTION;
      End;
    End If;

    --营销大类检测
    If v_Item_Main_Type_Filter=v_True Then
      Begin
        v_Value := '营销大类检测：';
        Select ic.class_code
          Into v_SALES_MAIN_TYPE
          From t_bd_item_class ic
         Where ic.class_code = r_Pln_Order_Head.Sales_Main_Type
           And ic.entity_id=r_Pln_Order_Head.Entity_Id
           And ic.active_flag=v_True;
      Exception
        When Others Then
          p_Result := v_Value || '营销大类编码 [' ||
                      r_Pln_Order_Head.Sales_Main_Type ||
                      '] 不存在或者失效。';
            raise V_CCS_EXCEPTION;
      End;
      Select Count(1)
        Into v_Count
        From intf_Pln_Order_Line l, t_Bd_Item Bi
       Where l.intf_head_id = p_Intf_Id
         And Bi.Item_Code = l.item_code
         And Bi.Entity_Id = r_Pln_Order_Head.Entity_Id
         And Bi.Sales_Main_Type = r_Pln_Order_Head.Sales_Main_Type;
      If v_Count != v_LineCount Then
        p_Result := '订单行产品与订单头大类不匹配';
          raise V_CCS_EXCEPTION;
      End If;
    End if;


   --营销小类检测

   If v_Item_Sub_Type_Filter=v_True Then
      Begin
          v_Value := '营销小类检测：';
          Select ic.class_code
            Into v_SALES_SUB_TYPE
            From t_bd_item_class ic
           Where ic.class_code = r_Pln_Order_Head.Sales_Sub_Type
             And ic.entity_id=r_Pln_Order_Head.Entity_Id
             And ic.active_flag=v_True;
       Exception
          When Others Then
            p_Result := v_Value || '营销小类编码 [' ||
                        r_Pln_Order_Head.Sales_Sub_Type ||
                        '] 不存在或者失效。';
              raise V_CCS_EXCEPTION;
       End;

      Select Count(1)
        Into v_Count
        From intf_Pln_Order_Line l, t_Bd_Item Bi
       Where l.intf_head_id = p_Intf_Id
         And Bi.Item_Code = l.item_code
         And Bi.Entity_Id = r_Pln_Order_Head.Entity_Id
         And Bi.Sales_Sub_Type = r_Pln_Order_Head.Sales_Sub_Type;
      If v_Count != v_LineCount Then
        p_Result := '订单行产品与订单头小类不匹配';
          raise V_CCS_EXCEPTION;
      End If;
    End if;


   --检测营销中心编码
   If p_Result = v_Success Then
     Begin
       v_Value :='营销中心检查：';
       Select u.Code, u.Name
          Into v_Sales_Center_Code, v_Sales_Center_Name
          From Up_Org_Unit u
         Where u.Unit_Id = r_Pln_Order_Head.Sales_Center_Id
           And u.Active_Flag = 'T';
      Exception
        When Others Then
          p_Result := v_Value || '营销中心ID：' ||
                      To_Char(r_Pln_Order_Head.Sales_Center_Id) ||
                      '不存在或者中心已失效。';
          raise V_CCS_EXCEPTION;
      End;
   End If;
   --检测客户编码
    If p_Result = v_Success Then
      begin
        v_Value := '客户检查：';
        Select Customer_Code,Customer_Name
             Into v_Customer_Code,v_Customer_Name
        From t_customer_header Ch
        Where Ch.Customer_Id= r_Pln_Order_Head.Customer_Id
        And   Ch.Active_Flag=v_Active;
      Exception
        when others then
           p_Result := v_Value || '客户ID：' ||
                      To_Char(r_Pln_Order_Head.Customer_Id) ||
                      '不存在或已失效。';
          raise V_CCS_EXCEPTION;
      end;
    End If;
   --检测账户编码
   If p_Result = v_Success Then
      Begin
        v_Value := '客户账户检查：';
        Select Ca.Account_Code, nvl(Ca.Account_Name,' '),Ca.account_id
          Into v_Account_Code, v_Account_Name,v_Account_Id
          From v_customer_account_salecenter Ca
        Where  Ca.sales_center_id = r_Pln_Order_Head.Sales_Center_Id
           And Ca.customer_id=r_Pln_Order_Head.Customer_Id
           And Ca.entity_id=r_Pln_Order_Head.Entity_Id
           And Ca.Active_Flag = v_Active
           AND ca.account_status= v_Account_Active;
        if v_Account_Id<>r_Pln_Order_Head.Account_Id then
           p_Result := v_Value || ' 主体ID：'||
                      To_Char(r_Pln_Order_Head.Entity_Id) ||
                      ' 中心ID：'||
                      To_Char(r_Pln_Order_Head.Customer_Id) ||
                      ' 客户ID：'||
                      To_Char(r_Pln_Order_Head.Customer_Id) ||
                      ' 账户ID：' ||
                      To_Char(r_Pln_Order_Head.Account_Id) ||
                      '对应关系有误';
             raise V_CCS_EXCEPTION;
        end if;
      Exception
        When Others Then
          p_Result := v_Value ||' 主体ID：'||
                      To_Char(r_Pln_Order_Head.Entity_Id) ||
                      ' 中心ID：' ||
                      To_Char(r_Pln_Order_Head.Sales_Center_Id) ||
                      ' 客户ID：' ||
                      To_Char(r_Pln_Order_Head.Customer_Id) ||
                      '不存在对应的账户，或账户未激活。';
          raise V_CCS_EXCEPTION;
      End;
    End If;

    --开票单位检测
    If p_Result = v_Success Then
      Begin
        v_Value := '开票联系人检查：';

        Select Tca.Contacts_Name, Tca.Contacts_Phones
          Into  v_Invoice_Contract, v_Invoice_Tel
          From t_Customer_Account_Address Ca, t_Customer_Address Tca
         Where
           ca.account_id=r_Pln_Order_Head.Account_Id
           And Tca.Contacts_Id=r_Pln_Order_Head.Invoice_Contract_Id
           And Tca.Address_Id = Ca.Address_Id
           And Tca.Address_Type = 'BillTo'
           And tca.entity_id=r_Pln_Order_Head.Entity_Id
           And ca.entity_id=r_Pln_Order_Head.Entity_Id
           And Tca.Active_Flag=v_Active;
      Exception
        When Others Then
          /*p_Result := v_Value || '账号：' ||
                      To_Char(r_Pln_Order_Head.Account_Id) ||
                      ' 开票联系人ID：'||
                       To_Char(r_Pln_Order_Head.Invoice_Contract_Id) ||
                      '不存在。';
          raise V_CCS_EXCEPTION;*/
          null;
      End;
    End If;

    --收货单位检测
    If p_Result = v_Success Then
      Begin
        --modi by lizhen 2016-01-16  获取客户4级收货地点信息
        Select Tca.Address_Id,
               Decode(v_Consignee_Add_4_Flag, 'N', nvl(tca.towns, Tca.Area), Tca.Towns),
               Tca.Address,
               Tca.Contacts_Id,
               Tca.Contacts_Name,
               Tca.Contacts_Phones
          Into v_Consignee_Id,
               v_Consignee_Addr_Code,
               v_Consignee_Addr,
               v_Consignee_Contact_Id,
               v_Consignee_Contract,
               v_Consignee_Tel
          From t_Customer_Account_Address Ca, t_Customer_Address Tca
         Where Ca.Account_Id   = r_Pln_Order_Head.Account_Id
           And Tca.Address_Id = r_Pln_Order_Head.Consignee_Id
           And Tca.Address_Id = Ca.Address_Id
           And Tca.Address_Type = 'ShipTo'
           And Tca.Active_Flag='Active';
      Exception
        When Others Then
          /*p_Result := v_Value || '账号：' ||
                      To_Char(r_Pln_Lg_Order_Head.Account_Id) ||
                      ' 收货地址ID：'||
                       To_Char(r_Pln_Lg_Order_Head.Consignee_Id) ||
                      '不存在或已失效。';
          raise V_CCS_EXCEPTION;*/
        null;
      End;
      --收货地点检测
      Begin
        Select Bd.Row_Id
          Into v_Consignment_Addr_Id
          From t_Bd_District Bd
         Where Bd.District_Code = v_Consignee_Addr_Code
          And Bd.Level_Seq = Decode(v_Consignee_Add_4_Flag, 'N', Bd.Level_Seq, 5);
      Exception
        When Others Then
           /*p_Result := v_Value || '收货地址ID：' ||
                      r_Pln_Lg_Order_Head.Consignee_Id ||
                      ' 收货地址编码：'||
                       To_Char(v_Consignee_Addr_Code) ||
                      '无对应的收货地点信息。';
             raise V_CCS_EXCEPTION;*/
        null;
      End;
    End If;

    If p_Result = v_Success Then
      Begin
        v_Value             := '获取中心最优产地';

        v_Producing_Area_Id := Pkg_Pln_Pub.f_Get_Cen_Prod_Area_Priority(p_Sales_Center_Id => r_Pln_Order_Head.Sales_Center_Id,
                                                                        p_Item_Id         => 0,
                                                                        p_Entity_Id       => r_Pln_Order_Head.Entity_Id,
                                                                        p_User_Code       => 'admin');
        Select Pa.Producing_Area_Code, Pa.Producing_Area_Name
          Into v_Producing_Area_Code, v_Producing_Area_Name
          From t_Pln_Producing_Area Pa
         Where Pa.Producing_Area_Id = v_Producing_Area_Id
           And Trunc(Sysdate) Between Pa.Begin_Date And
               Trunc(Nvl(Pa.End_Date, Sysdate));
      Exception
        When Others Then
          p_Result := v_Value || '失败，中心ID：' ||
                      To_Char(r_Pln_Order_Head.Sales_Center_Id) ;
            raise V_CCS_EXCEPTION;
      End;
    End If;
    ----------------------------------------------------------------------
    --  接口头表数据插入正式表
    ----------------------------------------------------------------------
    If p_Result = v_Success Then
        --生成订单号
        Begin
          Pkg_Pln_Pub.p_Create_Order_Number(p_Order_Number_Type => 'plnMakeOrder', --单据编码规则
                                            p_Period_Id         => v_Period_Id,
                                            p_Sales_Center_Id   => r_Pln_Order_Head.Sales_Center_Id,
                                            p_Entity_Id         => r_Pln_Order_Head.Entity_Id,
                                            p_Order_Number      => v_Order_Number);

          If Nvl(v_Order_Number, '_') = '_' Then
            p_Result := '获取客户订单单号失败，单号编码规则：plnMakeOrder。';
              raise V_CCS_EXCEPTION;
          End If;
        Exception
          When Others Then
            p_Result := '获取客户订单单号失败，单号编码规则：plnMakeOrder。';
              raise V_CCS_EXCEPTION;
        End;

        /*
        0  按周报送
        1  按月报送
        2  按月多次报送
        3  按年报送
        4  按周多次报送
        5  不定期报送
        */

        /*If v_Send_By_Type In (2, 4) Then
          Begin
            Select Count(1) + 1
              Into v_Batch_Id
              From t_Pln_Order_Collect_Head Och
             Where Och.Order_Type_Id = r_Pln_Order_Head.Order_Type_Id
               And Och.Period_Id = v_Period_Id;
          Exception
            When Others Then
              v_Batch_Id := 1;
          End;
        Else
          v_Batch_Id := 1;
        End If;*/

        --新增订单头
        Begin
            Select s_pln_order_head.Nextval Into v_Order_Head_Id From Dual;

            v_Value := '开始插入计划订单头表信息：';
            insert into t_pln_order_head
             (entity_id,
              order_head_id,
              order_number,
              order_type_id,
              order_type_code,
              order_type_name,
              sales_year_id,
              period_id,
              period_code,
              order_head_state,
              form_state,
              old_order_number,
              sales_center_id,
              sales_center_code,
              sales_center_name,
              customer_id,
              customer_code,
              customer_name,
              account_id,
              account_code,
              account_name,
              sales_main_type,
              batch_id,
              supply_date,
              description,
              back_reason,
              refer_date,
              hq_check_date,
              fc_check_date,
              affirm_date,
              refer_user,
              hq_check_user,
              fc_check_user,
              affirm_user,
              hq_check_comment,
              complete_date,
              close_date,
              need_arrang_flag,
              affirm_flag,
              invoice_customer_id,
              invoice_customer_code,
              invoice_customer_name,
              invoice_contract_id,
              invoice_contract,
              invoice_tel,
              consignee_id,
              consignee_code,
              consignee_name,
              consignee_addr,
              consignment_addr_id,
              consignee_addr_code,
              consignee_contact_id,
              consignee_contract,
              consignee_tel,
              locked_proportion,
              aps_ims_import_date,
              sys_source,
              source_type,
              source_order_number,
              last_week_flag,
              created_by,
              creation_date,
              last_updated_by,
              last_update_date,
              remark,
              pre_field_01,
              pre_field_02,
              pre_field_03,
              pre_field_04,
              pre_field_05,
              pre_field_06,
              producing_area_id,
              producing_area_code,
              producing_area_name,
              repair_inv_flag,
              po_match_flag,
              is_aps_need,
              business_type,
              sales_sub_type,
              program_updated_by,
              program_update_date,
              version,
              hq_confirm_by,
              hq_confirm_date,
              origin_system_code,
              source_order_head_id,
              center_check_user,
              center_check_date)
              values
              (r_Pln_Order_Head.Entity_Id,
               v_Order_Head_Id,
               v_Order_Number,
               r_Pln_Order_Head.Order_Type_Id, --订单类型ID
               v_Order_Type_Code,
               v_Order_Type_Name,
               null,                           --SALES_YEAR_ID 销售年度
               v_Period_Id,                    --周期ID
               v_Period_Code,
               null,                           --ORDER_HEAD_STATE 提货订单
               v_head_state_init,              --FORM_STATE 计划订单状态
               null,                           --OLD_ORDER_NUMBER 原订单号（未使用）
               r_Pln_Order_Head.Sales_Center_Id,  --中心
               v_Sales_Center_Code,
               v_Sales_Center_Name,
               r_Pln_Order_Head.Customer_Id,      --客户
               v_Customer_Code,
               v_Customer_Name,
               r_Pln_Order_Head.Account_Id,       --账户
               v_Account_Code,
               v_Account_Name,
               r_Pln_Order_Head.Sales_Main_Type, --营销大类
               v_Batch_Id,                             --BATCH_ID
               r_Pln_Order_Period.End_Date,      --SUPPLY_DATE 交货日期
               null,                             --DESCRIPTION 描述
               null,                             --BACK_REASON
               null,                             --REFER_DATE 中心送审日期
               null,                             --HQ_CHECK_DATE
               null,                             --FC_CHECK_DATE
               null,                             --AFFIRM_DATE
               null,                             --REFER_USER
               null,                             --HQ_CHECK_USER
               null,                             --FC_CHECK_USER
               null,                             --AFFIRM_USER
               null,                             --HQ_CHECK_COMMENT
               null,                             --COMPLETE_DATE 完成日期（该订单完成日期）
               null,                             --CLOSE_DATE 关闭日期（该订单关闭日期）
               null,                             --NEED_ARRANG_FLAG
               null,                             --AFFIRM_FLAG
               r_Pln_Order_Head.Invoice_Customer_Id,          --INVOICE_CUSTOMER_ID
               v_Customer_Code,
               v_Customer_Name,
               r_Pln_Order_Head.Invoice_Contract_Id,
               v_Invoice_Contract,
               v_Invoice_Tel,
               r_Pln_Order_Head.Consignee_Id,     --收货单位ID
               v_Customer_Code,
               v_Customer_Name,
               v_Consignee_Addr,                  --收货单位地址
               v_Consignment_Addr_Id,             --收货地点ID
               v_Consignee_Addr_Code,             --收货单位地址编码
               v_Consignee_Contact_Id,
               v_Consignee_Contract,
               v_Consignee_Tel,
               r_Pln_Order_Type.Locked_Proportion,--锁款比率（提交订单后按比例锁定客户款项）
               null,                              --APS_IMS_IMPORT_DATE
               r_Pln_Order_Head.Sys_Source,       --来源系统（记录客户订单来源的系统）
               r_Pln_Order_Head.Source_Type,      --来源类型（记录来源订单类型）
               r_Pln_Order_Head.Source_Order_Number,--来源单据单号（记录来源订单号）
               null,                                --LAST_WEEK_FLAG 是否最后一周需求（第四周周订单自动生成）
               'CCS',
               sysdate,
               'CCS',
               sysdate,
               r_Pln_Order_Head.Remark,
               r_Pln_Order_Head.Pre_Field_01,
               r_Pln_Order_Head.Pre_Field_02,
               r_Pln_Order_Head.Pre_Field_03,
               r_Pln_Order_Head.Pre_Field_04,
               r_Pln_Order_Head.Pre_Field_05,
               r_Pln_Order_Head.Pre_Field_06,
               v_Producing_Area_Id,
               v_Producing_Area_Code,
               v_Producing_Area_Name,
               null,                                --REPAIR_INV_FLAG 返修入库标志
               null,                                --PO_MATCH_FLAG 中转退货标志
               null,                                --IS_APS_NEED
               null,                                --BUSINESS_TYPE
               r_Pln_Order_Head.Sales_Sub_Type,
               'CCS',                                --PROGRAM_UPDATED_BY
               sysdate,
               1,
               null,
               null,
               r_Pln_Order_Head.Origin_System_Code, --上级来源系统编码
               r_Pln_Order_Head.SOURCE_ORDER_HEAD_ID,--来源单据头ID
               null,
               null);

              --更新接口表数据
            update intf_pln_order_head h set h.order_head_id= v_Order_Head_Id,
                   h.order_number=v_Order_Number where h.intf_id=p_Intf_Id;

        Exception
            When Others Then
              p_Result := v_Value || '，失败。' || sqlerrm;
                raise V_CCS_EXCEPTION;
        End;
     End if;

     ----------------------------------------------------------------------
     --  接口行表数据插入正式表
     ----------------------------------------------------------------------

     If p_Result = v_Success Then
         Open c_Pln_Order_Line;
         Loop
              Fetch c_Pln_Order_Line
               into r_Pln_Order_Line;
              Exit when c_Pln_Order_Line%Notfound Or p_Result <> v_Success;

              Select s_Pln_Order_Line.Nextval Into v_Order_Line_Id From Dual;

           if v_Is_MATERIAL_RANGE_FLAG = v_True then
              Begin
               v_Value := '产品型谱编码检查：';
               Select Bi.Item_Id, Bi.Defaultunit, Bi.Item_Name,nvl(Bi.SALES_MAIN_TYPE,'-'),
                      nvl(Bi.sales_sub_type,'-'),nvl(bi.is_material,'N'),
                      To_Number(bi.packingsize), To_Number(Nvl(bi.grossweight, 0))
                  Into v_Item_Id, v_Item_Uom, v_Item_Desc,v_ITEM_SALES_MAIN_TYPE,
                  v_ITEM_SALES_SUB_TYPE,V_IS_MATERIAL,
                  v_Unit_Volume, v_Unit_Weight --add by lizhen 2015-12-05 增加体积
                  From T_BD_ITEM  Bi,t_pln_item_dyn_attribute da
                Where bi.item_id=da.item_id
                  and bi.entity_id=da.entity_id
                  and Trunc(sysdate) Between da.begin_date And
                                                 Trunc(Nvl(da.end_date, Sysdate))
                  And Bi.Item_Code = r_Pln_Order_Line.Item_Code
                  And Bi.Entity_Id = r_Pln_Order_Line.Entity_Id;
              Exception
               When Others Then
                  p_Result := v_Value || '，产品编码：' || r_Pln_Order_Line.Item_Code ||
                            '不在型谱范围或产品已失效';
                    raise V_CCS_EXCEPTION;
              End;
            elsif V_IS_SAMPLE_NEED = v_True then

               Begin
                  v_Value := '样机产品检查：';
                   Select Bi.Item_Id, Bi.Defaultunit, Bi.Item_Name,nvl(Bi.SALES_MAIN_TYPE,'-'),
                          nvl(Bi.sales_sub_type,'-'),nvl(bi.is_material,'N'),
                          To_Number(bi.packingsize), To_Number(Nvl(bi.grossweight, 0))
                      Into v_Item_Id, v_Item_Uom, v_Item_Desc,v_SALES_MAIN_TYPE,
                      --add by lizhen 2015-12-05 增加体积
                      v_SALES_SUB_TYPE,V_IS_MATERIAL, v_Unit_Volume, v_Unit_Weight
                      From T_BD_ITEM  Bi
                   Where  Bi.Item_Code = r_Pln_Order_Line.Item_Code
                      And Bi.Entity_Id = r_Pln_Order_Line.Entity_Id
                      And Bi.active_flag = v_True
                      And Bi.productform='SAMPLE_PRODUCT';
               Exception
                 When Others Then
                    p_Result := v_Value || '，产品编码：' || r_Pln_Order_Line.Item_Code ||
                              '不为样机或产品已失效';
                      raise V_CCS_EXCEPTION;
               End;

            else
                Begin
                    v_Value := '产品检查：';
                     Select Bi.Item_Id, Bi.Defaultunit, Bi.Item_Name,nvl(Bi.SALES_MAIN_TYPE,'-'),
                            nvl(Bi.sales_sub_type,'-'),nvl(bi.is_material,'N'),
                            To_Number(bi.packingsize), To_Number(Nvl(bi.grossweight, 0))
                        Into v_Item_Id, v_Item_Uom, v_Item_Desc,v_SALES_MAIN_TYPE,
                        --add by lizhen 2015-12-05 增加体积
                        v_SALES_SUB_TYPE,V_IS_MATERIAL, v_Unit_Volume, v_Unit_Weight
                        From T_BD_ITEM  Bi
                     Where  Bi.Item_Code = r_Pln_Order_Line.Item_Code
                        And Bi.Entity_Id = r_Pln_Order_Line.Entity_Id
                        And Bi.active_flag = v_True;
                 Exception
                   When Others Then
                      p_Result := v_Value || '，产品编码：' || r_Pln_Order_Line.Item_Code ||
                                '不存在或产品已失效';
                        raise V_CCS_EXCEPTION;
                 End;
            End if;
         
         --推广物料检查
         v_Value := '推广物料检查';
         IF v_is_business_control = v_Pro_Order AND V_IS_MATERIAL <> 'Y' THEN
           p_Result := v_Value || '，产品：' || r_Pln_Order_Line.Item_Code ||
                       '不是推广物料，不允许通过单据类型：' || v_Order_Type_Name || '报送';
           raise V_CCS_EXCEPTION;
         ELSIF v_is_business_control <> v_Pro_Order AND V_IS_MATERIAL = 'Y' THEN
           p_Result := v_Value || '，产品：' || r_Pln_Order_Line.Item_Code ||
                       '是推广物料，不允许通过单据类型：' || v_Order_Type_Name || '报送';
           raise V_CCS_EXCEPTION;
         END IF;

         If p_Result = v_Success Then
            --判断产品数量
            If v_IS_Week = v_False and nvl(r_Pln_Order_Line.Apply_Qty, 0) = 0 Then
              p_Result := '订单行有误，产品编码：' || r_Pln_Order_Line.Item_Code || '，产品申请数量为0。';
                raise V_CCS_EXCEPTION;
            End If;


            /* P_EntityId             in Number,
                            P_Sales_Center_Id      in Number,
                            P_Account_Id           in Number,
                            P_Item_Main_Type       in varchar2,
                            P_Item_Sub_Type        in varchar2,
                            P_Period_Id            in Number,
                            P_Order_Type_id        in Number,
                            P_Item_id              in Number,
                            P_PRODUCING_AREA_ID    in Number,*/
            if v_IS_Week=v_True then
              Begin
                   v_Value:= '判断排产数量';
                   PKG_PLN_INTF_CCS.P_GET_WEEK_CAN_APPLY_NUM(
                                              r_Pln_Order_Head.Entity_Id,
                                              r_Pln_Order_Head.Sales_Center_Id,
                                              r_Pln_Order_Head.Account_Id,
                                              r_Pln_Order_Head.Sales_Main_Type,
                                              r_Pln_Order_Head.Sales_Sub_Type,
                                              r_Pln_Order_Head.Period_Id,
                                              r_Pln_Order_Head.Order_Type_Id,
                                              v_Item_Id,
                                              r_Pln_Order_Line.Producing_Area_Id,
                                              v_CanApplyNum);

                   if r_Pln_Order_Line.Apply_Qty > nvl(v_CanApplyNum,0) then
                      p_Result := '订单行有误，订单接口头ID：' || r_Pln_Order_Line.Intf_Head_Id
                                  || '，订单接口行ID：'||r_Pln_Order_Line.Intf_Id||v_Nl
                                  || '产品编码：'||r_Pln_Order_Line.Item_Code
                                  || ' 申请数量: '||r_Pln_Order_Line.Apply_Qty
                                  || ' 大于 可生产数量：'||v_CanApplyNum;
                        raise V_CCS_EXCEPTION;
                   end if;
              Exception
                when others then
                  p_Result := '获取可排产数量有误，'
                                              ||' 主体：'|| r_Pln_Order_Head.Entity_Id
                                              ||' 中心：'|| r_Pln_Order_Head.Sales_Center_Id
                                              ||' 账户：'|| r_Pln_Order_Head.Account_Id
                                              ||' 大类：'|| r_Pln_Order_Head.Sales_Main_Type
                                              ||' 小类：'|| r_Pln_Order_Head.Sales_Sub_Type
                                              ||' 周期：'|| r_Pln_Order_Head.Period_Id
                                              ||' 订单类型：'|| r_Pln_Order_Head.Order_Type_Id
                                              ||' 产品：'|| r_Pln_Order_Line.Item_Id
                                              ||' 产地：'|| r_Pln_Order_Line.Producing_Area_Id;
                    raise V_CCS_EXCEPTION;
              End;
            End if;


            --add by 徐鸿就  2016-6-18
            /*Begin
                v_Value := '获取产品单价：';
                Pkg_Bd_Price.p_Get_Price(
                                       p_Acc_Id         => r_Pln_Order_Head.Account_Id,
                                       p_Item_Code      => r_Pln_Order_Line.Item_Code,
                                       p_Bill_Date      => To_Char(Sysdate,
                                                                   'yyyymmdd'),
                                       p_Price_List_Id  => Null,
                                       p_Entity_Id      => r_Pln_Order_Head.Entity_Id,
                                       p_Price          => v_Item_Price,
                                       p_Discount       => v_Discount,
                                       p_Month_Discount => v_Month_Discount,
                                       p_Cx_Flag        => v_Cx_Flag);
            Exception
                When Others Then
                  v_Item_Price     := Null;
                  v_Discount       := 0;
                  v_Month_Discount := 0;
                  v_Cx_Flag        := 'N';
            End;

            If v_Item_Price Is Null  Then
              p_Result := '获取产品价格失败：产品编码：' || r_Pln_Order_Line.Item_Code || '，单价为空。';
                raise V_CCS_EXCEPTION;
            End If;*/
            
            If r_Pln_Order_Line.Item_Price Is Null Then 
              p_Result := '产品价格为空，写入CIMS订单表失败！';
                   Raise V_CCS_EXCEPTION;
            End If;

            v_Apply_Amount := Round((Nvl(r_Pln_Order_Line.Apply_Qty, 0) * r_Pln_Order_Line.Item_Price *
                            (100 - Nvl(v_Discount, 0))) / 100,2);

        End if;

        if p_Result=v_Success then
          if v_IS_Week = v_True or r_Pln_Order_Line.Producing_Area_Id is not null then
            v_Producing_Area_Id:=r_Pln_Order_Line.Producing_Area_Id;
            begin
                Select Pa.Producing_Area_Code, Pa.Producing_Area_Name
                Into v_Producing_Area_Code, v_Producing_Area_Name
                From t_Pln_Producing_Area Pa
               Where Pa.Producing_Area_Id = v_Producing_Area_Id
                 And Trunc(Sysdate) Between Pa.Begin_Date And
                     Trunc(Nvl(Pa.End_Date, Sysdate));
            Exception
              When Others Then
                p_Result := v_Value || '失败，中心ID：' ||
                            To_Char(r_Pln_Order_Head.Sales_Center_Id) ;
                  raise V_CCS_EXCEPTION;
            End;
          end if;
        end if;
        --add by lizhen 2015-12-05 检查订单行不允许引入申请数量为空与负数行
        If r_Pln_Order_Line.Apply_Qty Is Null Or r_Pln_Order_Line.Apply_Qty < 0 Then
          p_Result := '引入订单行失败，订单行不允许引入申请数量为空与负数行！' || v_Nl ||
             '产品编码：' || r_Pln_Order_Line.Item_Code;
          raise V_CCS_EXCEPTION;
        End If;

        If p_Result = v_Success Then

          Begin
            v_Value := '开始插入订单行表数据';

            insert into t_Pln_Order_Line(
                              entity_id,
                              order_line_id,
                              order_head_id,
                              order_line_state,
                              producing_area_id,
                              producing_area_code,
                              producing_area_name,
                              item_id,
                              item_code,
                              item_desc,
                              item_uom,
                              item_price,
                              month_plan_qty,
                              apply_qty,
                              check_qty,
                              can_produce_qty,
                              supply_qty,
                              cancel_inv_check_qty,
                              cancel_inv_in_qty,
                              share_qty,
                              carry_qty,
                              so_order_qty,
                              sundry_qty,
                              sundry_type,
                              price_list_id,
                              price_system_id,
                              discount_type_id,
                              sales_order_type_id,
                              discount_rate,
                              amount,
                              status,
                              check_comment,
                              fcchk_comment,
                              ctchk_comment,
                              can_supply_date,
                              begin_supply_date,
                              end_supply_date,
                              priority,
                              adjust_begin_date,
                              adjust_reason,
                              adjust_qty,
                              check_adjust_qty,
                              adjust_end_date,
                              check_result,
                              sale_qty,
                              old_material_id,
                              discard_qty,
                              take_out_qty,
                              other_out_qty,
                              favourable_qty,
                              loss_amount,
                              repair_fee,
                              buy_price,
                              material_priority,
                              customer_priority,
                              complete_date,
                              inv_affirm_qty,
                              inventory_id,
                              inventory_code,
                              inventory_name,
                              source_head_id,
                              source_head_code,
                              source_line_id,
                              source_type_name,
                              consignee_id,
                              consignee_name,
                              consignee_addr,
                              consignee_contact_id,
                              consignee_contract,
                              consignee_tel,
                              inventory_to_id,
                              inventory_code_to,
                              inventory_desc_to,
                              month_req_total_qty,
                              month_req_inv_aff_qty,
                              month_req_proc_qty,
                              month_req_proc_qty_w1,
                              month_req_proc_qty_w2,
                              month_req_proc_qty_w3,
                              month_req_proc_qty_w4,
                              gap_qty,
                              created_by,
                              creation_date,
                              last_updated_by,
                              last_update_date,
                              remark,
                              repair_inv_flag,
                              pre_field_02,
                              pre_field_03,
                              pre_field_04,
                              pre_field_05,
                              pre_field_06,
                              begin_share_date,
                              end_share_date,
                              begin_carry_date,
                              end_carry_date,
                              begin_so_order_date,
                              end_so_order_date,
                              program_updated_by,
                              program_update_date,
                              version,
                              center_check_qty,
                              first_aps_time,
                              last_aps_time,
                              aps_back_qty,
                              aps_flag
                              ) values (
                              r_Pln_Order_Line.Entity_Id,
                              v_Order_Line_Id,
                              v_Order_Head_Id,
                              v_head_state_init,
                              v_Producing_Area_Id,
                              v_Producing_Area_Code,
                              v_Producing_Area_Name,
                              v_Item_Id,
                              r_Pln_Order_Line.Item_Code,
                              v_Item_Desc,
                              v_Item_Uom,
                              r_Pln_Order_Line.Item_Price,
                              null,                       --MONTH_PLAN_QTY 月计划数量
                              r_Pln_Order_Line.Apply_Qty,
                              r_Pln_Order_Line.Apply_Qty, --CHECK_QTY 评审数量
                              r_Pln_Order_Line.Apply_Qty, --CAN_PRODUCE_QTY 可生产数量（已排产数量,del）
                              null,                       --SUPPLY_QTY 已供货数量（已入内销仓）
                              null,                       --CANCEL_INV_CHECK_QTY 已取消库评数量（制定发货计划时取消的库评数量）
                              null,                       --CANCEL_INV_IN_QTY 已取消入库数量（制定发货计划时取消的生产数量）
                              null,                       --SHARE_QTY
                              null,                       --CARRY_QTY
                              null,                       --SO_ORDER_QTY
                              null,                       --SUNDRY_QTY
                              null,                       --SUNDRY_TYPE
                              null,                       --PRICE_LIST_ID
                              null,                       --PRICE_SYSTEM_ID
                              null,                       --DISCOUNT_TYPE_ID
                              null,                       --SALES_ORDER_TYPE_ID
                              v_Discount,
                              v_Apply_Amount,
                              null,                       --STATUS
                              null,                       --CHECK_COMMENT
                              null,                       --FCCHK_COMMENT
                              null,                       --CTCHK_COMMENT
                              V_Can_Supply_Date,         --can_supply_date
                              null,
                              null,
                              null,                       --PRIORITY
                              null,
                              null,
                              null,
                              null,                       --CHECK_ADJUST_QTY
                              null,
                              null,
                              null,
                              null,                       --OLD_MATERIAL_ID
                              null,                       --DISCARD_QTY
                              null,                       --TAKE_OUT_QTY
                              null,                       --OTHER_OUT_QTY
                              null,                       --FAVOURABLE_QTY
                              null,
                              null,
                              null,
                              null,
                              null,
                              null,                       --COMPLETE_DATE 完成日期
                              null,                       --INV_AFFIRM_QTY
                              null,                       --INVENTORY_ID
                              null,                       --INVENTORY_CODE
                              null,                       --INVENTORY_NAME
                              r_Pln_Order_Line.Source_Head_Id,      --SOURCE_HEAD_ID
                              r_Pln_Order_Line.Source_Head_Code,       --SOURCE_HEAD_CODE
                              r_Pln_Order_Line.Source_Line_Id,
                              r_Pln_Order_Line.Source_Type_Name,
                              null,                                    --CONSIGNEE_ID
                              null,                                    --CONSIGNEE_NAME
                              null,                                    --CONSIGNEE_ADDR
                              null,                                    --CONSIGNEE_CONTACT_ID
                              null,                                    --CONSIGNEE_CONTRACT
                              null,                                    --CONSIGNEE_TEL
                              null,                                    --INVENTORY_TO_ID
                              null,
                              null,
                              null,                                    --MONTH_REQ_TOTAL_QTY
                              null,
                              null,
                              null,
                              null,
                              null,
                              null,
                              null,                                    --GAP_QTY
                              r_Pln_Order_Head.Sys_Source,
                              sysdate,
                              r_Pln_Order_Head.Sys_Source,
                              sysdate,
                              r_Pln_Order_Line.Remark,
                              null,                                    --REPAIR_INV_FLAG
                              null,                                    --PRE_FIELD_02
                              null,
                              null,
                              null,
                              null,                                    --PRE_FIELD_06
                              null,                                    --BEGIN_SHARE_DATE
                              null,                                    --END_SHARE_DATE
                              null,
                              null,
                              null,
                              null,                                    --END_SO_ORDER_DATE
                              r_Pln_Order_Head.Sys_Source,             --PROGRAM_UPDATED_BY
                              sysdate,
                              1,                                       --VERSION
                              null,                                    --CENTER_CHECK_QTY 厨电中心评审数量
                              null,                                    --FIRST_APS_TIME 初次引aps承诺时间
                              null,                                    --LAST_APS_TIME  完成aps承诺时间
                              null,                                    --APS_BACK_QTY  aps承诺数量
                              'N'                                     --APS_FLAG 生产量等于aps承诺量表示为Y  默认为null
                              );
                --更新接口行表
                update intf_pln_order_line l
                set l.order_line_id=v_Order_Line_Id,l.order_head_id=v_Order_Head_Id
                where l.intf_id=r_Pln_Order_Line.Intf_Id;

          Exception
            When Others Then
              p_Result := v_Value || '失败。' ;
                raise V_CCS_EXCEPTION;
          End;

        End if;

      End Loop;

      close c_Pln_Order_Line;
   End If;

   --周排产订单
   If p_Result = v_Success Then
      begin
        v_Value:='周排产回写库存评审占用量';
        if v_IS_Week = v_True then
          PKG_PLN_order.p_Import_Order_Inv_Review(r_Pln_Order_Head.Sales_Center_Id,
                                                  v_Period_Id,
                                                  r_Pln_Order_Head.Order_Type_Id,
                                                  v_Order_Head_Id,
                                                  r_Pln_Order_Head.Entity_Id,
                                                  'CCS',
                                                  p_Result);
          if p_Result <> v_Success then
            raise V_CCS_EXCEPTION;
          end if;
        end if;
       Exception
          when V_CCS_EXCEPTION then
              p_Result := v_Value || '失败。'||p_Result;
              raise V_CCS_EXCEPTION;
          When Others Then
              p_Result := v_Value || '失败。'||p_Result|| v_Nl || Sqlerrm;
              raise V_CCS_EXCEPTION;
       End;
   End If;
   --订单送审
   If p_Result = v_Success Then
      begin
          v_Value:='订单送审';
          pkg_pln_order.p_Order_Operate(p_Order_Head_Id    => v_Order_Head_Id,
                                        p_Order_Type_Id    => r_Pln_Order_Head.Order_Type_Id,
                                        p_Operation_Action => '送审',
                                        p_User_Code        => 'admin',
                                        p_Result           => p_Result);
          if p_Result <> v_Success then
              raise V_CCS_EXCEPTION;
          end if;
       Exception
          when V_CCS_EXCEPTION then
              p_Result := v_Value || '失败。'||p_Result;
              raise V_CCS_EXCEPTION;
          When Others Then
              p_Result := v_Value || '失败。'||p_Result|| v_Nl || Sqlerrm;
              raise V_CCS_EXCEPTION;
       End;
   End If;

   if p_Result = v_Success then
      begin
        v_Value := '更新接口表状态：';
        Update Intf_Pln_Order_Head Oh
         Set Oh.Intf_Status = v_Status_Sucess,
             Oh.Error_Message = p_Result,
             Oh.Order_Head_Id=v_Order_Head_Id,
             Oh.Order_Number=v_Order_Number
       Where Oh.Intf_Id = r_Pln_Order_Head.Intf_Id;
       --Commit;
      exception
         When Others Then
          p_Result := v_Value || '接口表ID ' || r_Pln_Order_Head.Intf_Id ||'失败。';
          raise V_CCS_EXCEPTION;
      End;
    end if;

  <<errlable>>
   If p_Result <> v_Success Then
      raise V_CCS_EXCEPTION;
   End If;

  Exception
    --20170904 hejy3 针对V_CCS_EXCEPTION异常回写订单
    when V_CCS_EXCEPTION then
      Rollback;
      p_Result := '失败：' || p_Result;
      Update Intf_Pln_Order_Head Oh
         Set Oh.Intf_Status = v_Status_Fail, Oh.Error_Message = p_Result
       Where Oh.Intf_Id = p_Intf_Id;

      v_Value:=pkg_bd.F_ADD_ERROR_LOG('pkg_pln_intf_ccs.P_CREATE_INTF_PL_ORDER',
                               2000,
                               p_Intf_Id||'|'||p_Result);
      --Commit;
     When Others Then
      Rollback;
      p_Result := '失败：' || p_Result || v_Nl || Sqlerrm;
      Update Intf_Pln_Order_Head Oh
         Set Oh.Intf_Status = v_Status_Fail, Oh.Error_Message = p_Result
       Where Oh.Intf_Id = p_Intf_Id;

      v_Value:=pkg_bd.F_ADD_ERROR_LOG('pkg_pln_intf_ccs.P_CREATE_INTF_PL_ORDER',
                               2000,
                               p_Intf_Id||'|'||p_Result);
      --Commit;
  End P_CREATE_INTF_PL_ORDER_NEW;


  Function F_GET_PERIOD(p_Order_Type_Id In Number, --单据类型ID
                                p_Entity_Id     In Number --主体ID
                                ) Return Number is
       v_Period_Id Number;
  Begin
     v_Period_Id:=Pkg_Pln_Pub.f_Get_Default_Period(p_Order_Type_Id,p_Entity_Id);
     return v_Period_Id;
  Exception
    When Others Then
      return null;
  End;



  function F_GET_PARAMETER_VALUE
  (
   P_CONFIG_CODE    t_bd_param_list.param_code%type,  --参数配置编码
   P_ENTITY_ID      up_org_unit.ENTITY_ID%type, --业务主体ID
   P_UNIT_ID        up_org_unit.Unit_Id%type default null, --中心ID
   P_CUSTOMER_ID    t_customer_header.customer_id%type default null --客户ID
   ) Return Varchar2 is
            v_Param_Value Varchar2(100);
            v_Error       Varchar2(500);
   Begin
            v_Param_Value:=Pkg_Bd.F_GET_PARAMETER_VALUE(
                            P_CONFIG_CODE,
                            P_ENTITY_ID,
                            P_UNIT_ID,
                            P_CUSTOMER_ID
                            );
     return v_Param_Value;
   Exception
     When Others Then
      v_Error:= sqlcode||sqlerrm;
      return null;
   End;

   function F_GET_MONTH_PLAN(
            P_EntityId             Number,
            P_Sales_Center_Id      Number,
            P_Account_Id           Number,
            P_Item_Main_Type       varchar2,
            P_Item_Sub_Type        varchar2,
            P_Period_Id            Number,
            P_Order_Type_id        Number

   ) return T_MONTHPLAN_ITEM_TABLE pipelined is
   --动态游标
   c_Month_Plan_Item cur_type;
   c_Week_Num        cur_type;
   --返回table对象
   V_MONTHPLAN_ITEM R_MONTHPLAN_ITEM;

   /*V_MONTHPLAN_ITEM_TABLE T_MONTHPLAN_ITEM_TABLE := T_MONTHPLAN_ITEM_TABLE();*/

   autoMonthSql varchar2(2000);
   autoWeekSql  varchar2(2000);
   v_error      varchar2(1000);
   v_Week_Num   number;

   v_Sys_AccountFlag          varchar2(10);
   v_Sys_Main_Type_Filter     varchar2(10);
   v_Sys_Sub_Type_Filter      varchar2(10);
   Begin

        v_Sys_AccountFlag:=F_GET_PARAMETER_VALUE(v_Account_Parameter,P_EntityId,null,null);
        v_Sys_Main_Type_Filter:=F_GET_PARAMETER_VALUE(v_Main_Parameter,
                                                     P_EntityId,null,null);
        v_Sys_Sub_Type_Filter:=F_GET_PARAMETER_VALUE(v_Sub_Parameter,
                                                     P_EntityId,null,null);
        autoMonthSql:='select  i.item_id,
                 i.item_code,
                 i.ITEM_NAME,
                 i.DEFAULTUNIT,
                 max(t.item_price) as item_price,t.PRODUCING_AREA_ID,t.PRODUCING_AREA_CODE,PRODUCING_AREA_NAME,
                 sum(t.CAN_PRODUCE_QTY-nvl(t.check_adjust_qty,0)) as QNUMBBER
                 ,null,
                 null
                 from t_pln_order_line t,t_bd_item i
                  where t.order_head_id in (select order_head_id
                 from t_pln_order_head poh,t_pln_order_type ot ' ||

                 'where sales_center_id = '|| P_Sales_Center_Id ;
         If (v_Sys_AccountFlag=v_True) Then
                 autoMonthSql:=autoMonthSql||' and account_Id= '||P_Account_Id;
         End if;

         If (v_Sys_Main_Type_Filter=v_True) Then
                 autoMonthSql:=autoMonthSql||' and sales_main_type= '''
                                           ||P_Item_Main_Type||'''';
         End if;

         If (v_Sys_Sub_Type_Filter=v_True) Then
                 autoMonthSql:=autoMonthSql||' and sales_sub_type= '''
                                           ||P_Item_Sub_Type||'''';
         End if;

        autoMonthSql:=autoMonthSql||
            ' and exists(select 1 from t_pln_order_period op,t_pln_order_period opp '||
            ' where opp.period_id = op.parent_period_id and op.period_id = '||P_Period_Id ||
            ' and opp.period_type = '||'''月'''||' and opp.period_id = poh.period_id )'||
            ' and ot.order_type_id = poh.order_type_id and ot.dest_order_type_id = '||P_Order_Type_id||
            ' and ot.send_by_type in (1, 2) and poh.form_state = '||v_head_state_check||' ) '||
            ' and t.item_id=i.item_id
             group by i.item_id, i.item_code, i.ITEM_NAME,
             i.DEFAULTUNIT,t.PRODUCING_AREA_ID,t.PRODUCING_AREA_CODE,PRODUCING_AREA_NAME';


        autoWeekSql:='Select Sum(tPol.Can_Produce_Qty) as qNumbber
                         From t_Pln_Order_Line tPol, t_Pln_Order_Head tPoh
                         Where tPol.Order_Head_Id = tPoh.Order_Head_Id
                           And tPoh.Form_State In ('''||
                           v_head_state_check||''','''||
                           v_head_state_make ||''','''||
                           v_head_state_finish||
                           ''') And tPoh.Sales_Center_Id = '|| P_Sales_Center_Id ||
                           ' And tPoh.Order_Type_Id = '|| P_Order_Type_id  ||
                           ' And tPoh.entity_Id = '|| P_EntityId ||
                           ' And Exists
                             (Select 1
                                     From t_Pln_Order_Period Pop,t_Pln_Order_Period Ppop
                                     Where Ppop.Parent_Period_Id=Pop.Parent_Period_Id
                                  and  Pop.Period_Id = '|| P_Period_Id||
                                ' and  Pop.entity_id= '||P_EntityId||
                                ' and  Ppop.period_id = tPoh.period_id )
                               And tPol.Item_Id = :1
                               And tPol.Producing_Area_Id = :2';
         If (v_Sys_AccountFlag=v_True) Then
                 autoWeekSql:=autoWeekSql||' and tPoh.account_Id= '||P_Account_Id;
         End if;

         If (v_Sys_Main_Type_Filter=v_True) Then
                 autoWeekSql:=autoWeekSql||' and tPoh.sales_main_type= '''
                                         ||P_Item_Main_Type||'''';
         End if;

         If (v_Sys_Sub_Type_Filter=v_True) Then
                 autoWeekSql:=autoWeekSql||' and tPoh.sales_sub_type= '''
                                         ||P_Item_Sub_Type||'''';
         End if;
        dbms_output.put_line(autoMonthSql);
        dbms_output.put_line(autoWeekSql);
        OPEN c_Month_Plan_Item for autoMonthSql;
        LOOP
          Fetch c_Month_Plan_Item into V_MONTHPLAN_ITEM;
        EXIT WHEN c_Month_Plan_Item%notfound;

             OPEN c_Week_Num for autoWeekSql
                              using V_MONTHPLAN_ITEM.ITEM_ID,V_MONTHPLAN_ITEM.PRODUCING_AREA_ID;
             Fetch c_Week_Num into v_Week_Num;
             Close c_Week_Num;
             V_MONTHPLAN_ITEM.WEEK_NUM:=nvl(v_Week_Num,0);
             V_MONTHPLAN_ITEM.CANUSE_NUM:=V_MONTHPLAN_ITEM.MONTH_NUM
                                          -V_MONTHPLAN_ITEM.WEEK_NUM;
             pipe row(V_MONTHPLAN_ITEM);
        END LOOP;
        CLOSE c_Month_Plan_Item;
     return;
   Exception
      When Others Then
      v_error:= '异常'||sqlerrm;
      dbms_output.put_line(v_error);
      return;
   End;

    function F_GET_MONTH_PLAN_TEST(
            P_EntityId             Number,
            P_Sales_Center_Id      Number,
            P_Account_Id           Number,
            P_Item_Main_Type       varchar2,
            P_Item_Sub_Type        varchar2,
            P_Period_Id            Number,
            P_Order_Type_id        Number

   ) return varchar2 is
   --动态游标
   c_Month_Plan_Item cur_type;
   c_Week_Num        cur_type;
   --返回table对象
   V_MONTHPLAN_ITEM R_MONTHPLAN_ITEM;

   V_MONTHPLAN_ITEM_TABLE T_MONTHPLAN_ITEM_TABLE := T_MONTHPLAN_ITEM_TABLE();

   autoMonthSql varchar2(2000);
   autoWeekSql  varchar2(2000);
   v_error      varchar2(1000);
   v_Week_Num   number;

   v_Sys_AccountFlag          varchar2(10);
   v_Sys_Main_Type_Filter     varchar2(10);
   v_Sys_Sub_Type_Filter      varchar2(10);
   Begin

        v_Sys_AccountFlag:=F_GET_PARAMETER_VALUE(v_Account_Parameter,P_EntityId,null,null);
        v_Sys_Main_Type_Filter:=F_GET_PARAMETER_VALUE(v_Main_Parameter,
                                                     P_EntityId,null,null);
        v_Sys_Sub_Type_Filter:=F_GET_PARAMETER_VALUE(v_Sub_Parameter,
                                                     P_EntityId,null,null);
        autoMonthSql:='select  i.item_id,
                 i.item_code,
                 i.ITEM_NAME,
                 i.DEFAULTUNIT,
                 max(t.item_price) as item_price,t.PRODUCING_AREA_ID,t.PRODUCING_AREA_CODE,PRODUCING_AREA_NAME,
                 sum(t.CAN_PRODUCE_QTY-nvl(t.check_adjust_qty,0)) as QNUMBBER
                 ,null,
                 null
                 from t_pln_order_line t,t_bd_item i
                  where t.order_head_id in (select order_head_id
                 from t_pln_order_head poh,t_pln_order_type ot ' ||

                 'where sales_center_id = '|| P_Sales_Center_Id ;
         If (v_Sys_AccountFlag=v_True) Then
                 autoMonthSql:=autoMonthSql||' and account_Id= '||P_Account_Id;
         End if;

         If (v_Sys_Main_Type_Filter=v_True) Then
                 autoMonthSql:=autoMonthSql||' and sales_main_type= '''
                                           ||P_Item_Main_Type||'''';
         End if;

         If (v_Sys_Sub_Type_Filter=v_True) Then
                 autoMonthSql:=autoMonthSql||' and sales_sub_type= '''
                                           ||P_Item_Sub_Type||'''';
         End if;

        autoMonthSql:=autoMonthSql||
            ' and exists(select 1 from t_pln_order_period op,t_pln_order_period opp '||
            ' where opp.period_id = op.parent_period_id and op.period_id = '||P_Period_Id ||
            ' and opp.period_type = '||'''月'''||' and opp.period_id = poh.period_id )'||
            ' and ot.order_type_id = poh.order_type_id and ot.dest_order_type_id = '||P_Order_Type_id||
            ' and ot.send_by_type in (1, 2) and poh.form_state = '||v_head_state_check||' ) '||
            ' and t.item_id=i.item_id
             group by i.item_id, i.item_code, i.ITEM_NAME,
             i.DEFAULTUNIT,t.PRODUCING_AREA_ID,t.PRODUCING_AREA_CODE,PRODUCING_AREA_NAME';


        autoWeekSql:='Select Sum(tPol.Can_Produce_Qty) as qNumbber
                         From t_Pln_Order_Line tPol, t_Pln_Order_Head tPoh
                         Where tPol.Order_Head_Id = tPoh.Order_Head_Id
                           And tPoh.Form_State In ('''||
                           v_head_state_check||''','''||
                           v_head_state_make ||''','''||
                           v_head_state_finish||
                           ''') And tPoh.Sales_Center_Id = '|| P_Sales_Center_Id ||
                           ' And tPoh.Order_Type_Id = '|| P_Order_Type_id  ||
                           ' And tPoh.entity_Id = '|| P_EntityId ||
                           ' And Exists
                             (Select 1
                                     From t_Pln_Order_Period Pop,t_Pln_Order_Period Ppop
                                     Where Ppop.Parent_Period_Id=Pop.Parent_Period_Id
                                  and  Pop.Period_Id = '|| P_Period_Id||
                                ' and  Pop.entity_id= '||P_EntityId||
                                ' and  Ppop.period_id = tPoh.period_id )
                               And tPol.Item_Id = :1
                               And tPol.Producing_Area_Id = :2';
         If (v_Sys_AccountFlag=v_True) Then
                 autoWeekSql:=autoWeekSql||' and tPoh.account_Id= '||P_Account_Id;
         End if;

         If (v_Sys_Main_Type_Filter=v_True) Then
                 autoWeekSql:=autoWeekSql||' and tPoh.sales_main_type= '''
                                         ||P_Item_Main_Type||'''';
         End if;

         If (v_Sys_Sub_Type_Filter=v_True) Then
                 autoWeekSql:=autoWeekSql||' and tPoh.sales_sub_type= '''
                                         ||P_Item_Sub_Type||'''';
         End if;
        dbms_output.put_line(autoMonthSql);
        dbms_output.put_line(autoWeekSql);
        OPEN c_Month_Plan_Item for autoMonthSql;
        LOOP
          Fetch c_Month_Plan_Item into V_MONTHPLAN_ITEM;
        EXIT WHEN c_Month_Plan_Item%notfound;

             OPEN c_Week_Num for autoWeekSql
                              using V_MONTHPLAN_ITEM.ITEM_ID,V_MONTHPLAN_ITEM.PRODUCING_AREA_ID;
             Fetch c_Week_Num into v_Week_Num;
             Close c_Week_Num;
             V_MONTHPLAN_ITEM.WEEK_NUM:=nvl(v_Week_Num,0);
             V_MONTHPLAN_ITEM.CANUSE_NUM:=V_MONTHPLAN_ITEM.MONTH_NUM
                                          -V_MONTHPLAN_ITEM.WEEK_NUM;
             /*pipe row(V_MONTHPLAN_ITEM);*/
             dbms_output.put_line(V_MONTHPLAN_ITEM.ITEM_ID);
             dbms_output.put_line(V_MONTHPLAN_ITEM.MONTH_NUM);
             dbms_output.put_line(V_MONTHPLAN_ITEM.WEEK_NUM);
        END LOOP;
        CLOSE c_Month_Plan_Item;
     return null;
   Exception
      When Others Then
      v_error:= '异常'||sqlcode||sqlerrm;
      dbms_output.put_line(v_error);
      return null;
   End;




   function F_GET_WEEK_CAN_APPLY_NUM(
            P_EntityId             Number,
            P_Sales_Center_Id      Number,
            P_Account_Id           Number,
            P_Item_Main_Type       varchar2,
            P_Item_Sub_Type        varchar2,
            P_Period_Id            Number,
            P_Order_Type_id        Number,
            P_Item_id              Number,
            P_PRODUCING_AREA_ID    Number

   ) return number is

   c_Month_Plan_Item cur_type;
   V_MONTHPLAN_ITEM R_MONTHPLAN_ITEM;

   Begin

      open c_Month_Plan_Item for  select * from
                                  table(PKG_PLN_INTF_CCS.F_GET_MONTH_PLAN(P_EntityId,
                                            P_Sales_Center_Id,
                                            P_Account_Id,
                                            P_Item_Main_Type,
                                            P_Item_Sub_Type,
                                            P_Period_Id,
                                            P_Order_Type_id))t
                                            where t.item_id=P_Item_id
                                            and t.PRODUCING_AREA_ID=P_PRODUCING_AREA_ID;
     Fetch c_Month_Plan_Item into V_MONTHPLAN_ITEM;
     Close c_Month_Plan_Item;
     return nvl(V_MONTHPLAN_ITEM.CANUSE_NUM,0);
   Exception
      When Others Then
      return null;
   End;

   Procedure P_GET_WEEK_CAN_APPLY_NUM(
                            P_EntityId             in Number,
                            P_Sales_Center_Id      in Number,
                            P_Account_Id           in Number,
                            P_Item_Main_Type       in varchar2,
                            P_Item_Sub_Type        in varchar2,
                            P_Period_Id            in Number,
                            P_Order_Type_id        in Number,
                            P_Item_id              in Number,
                            P_PRODUCING_AREA_ID    in Number,
                            P_CanApplyNum          out number
                            ) is

     --动态游标
   c_Month_Plan_Item cur_type;
   c_Week_Num        cur_type;
   --返回table对象
   V_MONTHPLAN_ITEM R_MONTHPLAN_ITEM;

   /*V_MONTHPLAN_ITEM_TABLE T_MONTHPLAN_ITEM_TABLE := T_MONTHPLAN_ITEM_TABLE();*/

   autoMonthSql varchar2(2000);
   autoWeekSql  varchar2(2000);
   v_error      varchar2(1000);
   v_Week_Num   number;

   v_Sys_AccountFlag          varchar2(10);
   v_Sys_Main_Type_Filter     varchar2(10);
   v_Sys_Sub_Type_Filter      varchar2(10);
   v_CanApplyNum              number;
   Begin

        v_Sys_AccountFlag:=F_GET_PARAMETER_VALUE(v_Account_Parameter,P_EntityId,null,null);
        v_Sys_Main_Type_Filter:=F_GET_PARAMETER_VALUE(v_Main_Parameter,
                                                     P_EntityId,null,null);
        v_Sys_Sub_Type_Filter:=F_GET_PARAMETER_VALUE(v_Sub_Parameter,
                                                     P_EntityId,null,null);
        autoMonthSql:='select  i.item_id,
                 i.item_code,
                 i.ITEM_NAME,
                 i.DEFAULTUNIT,
                 max(t.item_price) as item_price,t.PRODUCING_AREA_ID,t.PRODUCING_AREA_CODE,PRODUCING_AREA_NAME,
                 sum(t.CAN_PRODUCE_QTY-nvl(t.check_adjust_qty,0)) as QNUMBBER
                 ,null,
                 null
                 from t_pln_order_line t,t_bd_item i
                  where t.order_head_id in (select order_head_id
                 from t_pln_order_head poh,t_pln_order_type ot ' ||

                 'where sales_center_id = '|| P_Sales_Center_Id ;
         If (v_Sys_AccountFlag=v_True) Then
                 autoMonthSql:=autoMonthSql||' and account_Id= '||P_Account_Id;
         End if;

         If (v_Sys_Main_Type_Filter=v_True) Then
                 autoMonthSql:=autoMonthSql||' and sales_main_type= '''
                                           ||P_Item_Main_Type||'''';
         End if;

         If (v_Sys_Sub_Type_Filter=v_True) Then
                 autoMonthSql:=autoMonthSql||' and sales_sub_type= '''
                                           ||P_Item_Sub_Type||'''';
         End if;

        autoMonthSql:=autoMonthSql||
            ' and exists(select 1 from t_pln_order_period op,t_pln_order_period opp '||
            ' where opp.period_id = op.parent_period_id and op.period_id = '||P_Period_Id ||
            ' and opp.period_type = '||'''月'''||' and opp.period_id = poh.period_id )'||
            ' and ot.order_type_id = poh.order_type_id and ot.dest_order_type_id = '||P_Order_Type_id||
            ' and ot.send_by_type in (1, 2) and poh.form_state = '||v_head_state_check||' ) '||
            ' and t.item_id=i.item_id and t.item_id='||P_Item_id||
            ' and t.PRODUCING_AREA_ID='||P_PRODUCING_AREA_ID||
            ' group by i.item_id, i.item_code, i.ITEM_NAME,
             i.DEFAULTUNIT,t.PRODUCING_AREA_ID,t.PRODUCING_AREA_CODE,PRODUCING_AREA_NAME';


        autoWeekSql:='Select Sum(tPol.Can_Produce_Qty-nvl(tPol.check_adjust_qty,0)) as qNumbber
                         From t_Pln_Order_Line tPol, t_Pln_Order_Head tPoh
                         Where tPol.Order_Head_Id = tPoh.Order_Head_Id
                           And tPoh.Form_State In ('''||
                           v_head_state_check||''','''||
                           v_head_state_make ||''','''||
                           v_head_state_finish||
                           ''') And tPoh.Sales_Center_Id = '|| P_Sales_Center_Id ||
                           ' And tPoh.Order_Type_Id = '|| P_Order_Type_id  ||
                           ' And tPoh.entity_Id = '|| P_EntityId ||
                           ' And Exists
                             (Select 1
                                     From t_Pln_Order_Period Pop,t_Pln_Order_Period Ppop
                                     Where Ppop.Parent_Period_Id=Pop.Parent_Period_Id
                                  and  Pop.Period_Id = '|| P_Period_Id||
                                ' and  Pop.entity_id= '||P_EntityId||
                                ' and  Ppop.period_id = tPoh.period_id )'||
                                ' And tPol.Item_Id = '||P_Item_id||
                                ' And tPol.Producing_Area_Id = '||P_PRODUCING_AREA_ID;
         If (v_Sys_AccountFlag=v_True) Then
                 autoWeekSql:=autoWeekSql||' and tPoh.account_Id= '||P_Account_Id;
         End if;

         If (v_Sys_Main_Type_Filter=v_True) Then
                 autoWeekSql:=autoWeekSql||' and tPoh.sales_main_type= '''
                                         ||P_Item_Main_Type||'''';
         End if;

         If (v_Sys_Sub_Type_Filter=v_True) Then
                 autoWeekSql:=autoWeekSql||' and tPoh.sales_sub_type= '''
                                         ||P_Item_Sub_Type||'''';
         End if;
        /*dbms_output.put_line(autoMonthSql);
        dbms_output.put_line(autoWeekSql);*/
        OPEN c_Month_Plan_Item for autoMonthSql;
          Fetch c_Month_Plan_Item into V_MONTHPLAN_ITEM;
        CLOSE c_Month_Plan_Item;


        OPEN c_Week_Num for autoWeekSql;
             Fetch c_Week_Num into v_Week_Num;
        Close c_Week_Num;
        P_CanApplyNum:=nvl(V_MONTHPLAN_ITEM.MONTH_NUM,0)-nvl(v_Week_Num,0);

   Exception
     when Others Then
      P_CanApplyNum:=0;
   End;

   function F_GET_VEHICLE_INFO(
            p_OrderHead_Id         Number
   ) return varchar2  is
        v_Vehicle_Infos varchar2(2000);

   Begin
        For c_Vehicle_Infos In (
               select i.*
                 from t_lg_vehicle_info i,
                 t_lg_vehicle_info_line l,
                 t_pln_lg_order_head h
               where i.vehicle_info_id=l.vehicle_info_id
               and   i.entity_id=h.entity_id
               and   l.origin_order_id=h.order_head_id
               and   h.order_head_id=p_OrderHead_Id
               and   l.origin_type='02')
               --01：计划订单 02：提货订单 03 ：调拨订单 04：促销品
        Loop
               v_Vehicle_Infos:=v_Vehicle_Infos
                                ||c_Vehicle_Infos.Vehicle_Num
                                ||',';
        End Loop;
        v_Vehicle_Infos:= nvl(v_Vehicle_Infos,',');
        return substr(v_Vehicle_Infos,0,length(v_Vehicle_Infos)-1);
   Exception
     when Others Then
       return null;
   End;

   function F_GET_VEHICLE_INFO_MONTH(
            p_OrderHead_Id         Number
   ) return varchar2  is
        v_Vehicle_Infos varchar2(2000);

   Begin
        For c_Vehicle_Infos In (
               select i.*
                 from t_lg_vehicle_info i,
                 t_lg_vehicle_info_line l
               where i.vehicle_info_id=l.vehicle_info_id
               and   l.origin_type='01'
               and exists(select 1 from t_pln_lg_order_ship_review r
                   where r.origin_order_line_id=l.origin_line_id
                   and r.entity_id=i.entity_id
                   and r.order_head_id=1073) )
               --01：计划订单 02：提货订单 03 ：调拨订单 04：促销品
        Loop
               v_Vehicle_Infos:=v_Vehicle_Infos
                                ||c_Vehicle_Infos.Vehicle_Num
                                ||',';
        End Loop;
        v_Vehicle_Infos:= nvl(v_Vehicle_Infos,',');
        return substr(v_Vehicle_Infos,0,length(v_Vehicle_Infos)-1);
   Exception
     when Others Then
       return null;
   End;

   Function F_Get_Cen_Prod_Area(p_Sales_Center_Id In Number,
                                p_Item_Id         In Number,
                                p_Entity_Id       In Number)
   return number is
          v_Product_Area number;
   Begin
          v_Product_Area:= PKG_PLN_PUB.f_Get_Cen_Prod_Area_Priority(
                                                  p_Sales_Center_Id,
                                                  p_Item_Id,
                                                  p_Entity_Id,
                                                  'CCS');
          return v_Product_Area;
   Exception
     when Others Then
       return null;
   End;

   /*
   月预测接口
  */
  PROCEDURE P_CREATE_MONTH_FORECAST(P_INTF_ID IN NUMBER, --月预测接口表ID
                                    P_RESULT  OUT VARCHAR2) IS
    R_INTF_MONTH_FORECAST_HEAD INTF_MONTH_FORECAST_HEAD%ROWTYPE;
    R_INTF_MONTH_FORECAST_LINE INTF_MONTH_FORECAST_LINE%ROWTYPE;
    R_STP_MONTH_PLAN_HEAD      T_STP_MONTH_PLAN_HEAD%ROWTYPE;
    R_STP_MONTH_PLAN_LINE      T_STP_MONTH_PLAN_LINES%ROWTYPE;
    R_PLN_ORDER_TYPE           T_PLN_ORDER_TYPE%ROWTYPE;
    V_PERIOD_CODE              T_PLN_ORDER_PERIOD.PERIOD_CODE%TYPE;
    V_ENTITY_NAME              V_BD_ENTITY.ENTITY_NAME%TYPE;
    v_is_business_control      VARCHAR2(100);
  
    V_VALUE              VARCHAR2(1000);
    V_ERR_MSG            VARCHAR2(1000);
    V_IS_SALES_MAIN_TYPE VARCHAR2(32);
    V_COUNT              NUMBER;
    V_head_COUNT         NUMBER;--头表中含有的数量
     --add by huanghb12
    VS_ITEM_LIFE_CYCLE   VARCHAR2(10);
    VS_CHECK_RESULT      VARCHAR2(4000);
    --huanghb12
    v_is_producing_area  varchar2(32);
  
    --PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
    P_RESULT := V_SUCCESS;
  
    --获取接口头信息
    V_VALUE := '锁定月预测接口头表失败！';
    BEGIN
      SELECT H.*
        INTO R_INTF_MONTH_FORECAST_HEAD
        FROM INTF_MONTH_FORECAST_HEAD H
       WHERE H.INTF_ID = P_INTF_ID
         AND H.INTF_STATUS = V_STATUS_INIT
         FOR UPDATE NOWAIT;
    EXCEPTION
      WHEN OTHERS THEN
        P_RESULT := V_VALUE || V_NL || SQLERRM;
        RAISE V_CCS_EXCEPTION;
    END;
  
    --主体编码检测
    IF P_RESULT = V_SUCCESS THEN
      BEGIN
        V_VALUE := '主体检测：';
        SELECT B.ENTITY_ID
          INTO R_STP_MONTH_PLAN_HEAD.ENTITY_ID
          FROM V_BD_ENTITY B
         WHERE B.ENTITY_ID = R_INTF_MONTH_FORECAST_HEAD.ENTITY_ID;
      EXCEPTION
        WHEN OTHERS THEN
          P_RESULT := V_VALUE || V_NL || '主体：' ||
                      R_INTF_MONTH_FORECAST_HEAD.ENTITY_ID || '无效，请检查接口数据。';
          RAISE V_CCS_EXCEPTION;
      END;
    END IF;
  
    --检查月预测类型
    IF P_RESULT = V_SUCCESS THEN
      BEGIN
        V_VALUE := '月预测类型检查：';
        SELECT OT.ORDER_TYPE_ID, OT.ORDER_TYPE_NAME, nvl(ot.is_business_control,'_')
          INTO R_STP_MONTH_PLAN_HEAD.PLAN_TYPE,
               R_PLN_ORDER_TYPE.ORDER_TYPE_NAME,
               v_is_business_control
          FROM T_PLN_ORDER_TYPE OT
         WHERE OT.ORDER_TYPE_ID =
               R_INTF_MONTH_FORECAST_HEAD.MONTH_PLAN_TYPE
           AND TRUNC(R_INTF_MONTH_FORECAST_HEAD.INTF_DATE) BETWEEN
               OT.BEGIN_DATE AND TRUNC(NVL(OT.END_DATE, SYSDATE));
      EXCEPTION
        WHEN OTHERS THEN
          P_RESULT := V_VALUE || V_NL || '月预测类型ID：' ||
                      TO_CHAR(R_INTF_MONTH_FORECAST_HEAD.MONTH_PLAN_TYPE) ||
                      '不存在或者已失效。';
          RAISE V_CCS_EXCEPTION;
      END;
    END IF;
    --获取行产地是否为空参数 lilh6 2019-7-9
    BEGIN
      v_is_producing_area := PKG_BD.F_GET_PARAMETER_VALUE('PLN_STP_MONTH_PRODUCE',
                                                         R_STP_MONTH_PLAN_HEAD.ENTITY_ID);
    EXCEPTION
      WHEN OTHERS THEN
        P_RESULT := '获取PLN_STP_MONTH_PRODUCE参数失败。' || V_NL || SQLERRM;
        RAISE V_CCS_EXCEPTION;
    END;
    --营销大类是否必填
    BEGIN
      V_IS_SALES_MAIN_TYPE := PKG_BD.F_GET_PARAMETER_VALUE('PLAN_SALES_MAIN_TYPE_FILTER',
                                                           R_STP_MONTH_PLAN_HEAD.ENTITY_ID);
    EXCEPTION
      WHEN OTHERS THEN
        P_RESULT := '获取PLAN_SALES_MAIN_TYPE_FILTER参数失败！' || V_NL || SQLERRM;
        RAISE V_CCS_EXCEPTION;
    END;
  
    IF P_RESULT = V_SUCCESS THEN
      BEGIN
        V_VALUE := '获取默认周期信息';
        SELECT OP.PERIOD_ID, OP.PERIOD_CODE
          INTO R_STP_MONTH_PLAN_HEAD.PLAN_PERIOD, V_PERIOD_CODE
          FROM T_PLN_ORDER_PERIOD OP
         WHERE OP.ENTITY_ID = R_INTF_MONTH_FORECAST_HEAD.ENTITY_ID
           AND OP.PERIOD_ID =
               F_GET_PERIOD(R_INTF_MONTH_FORECAST_HEAD.MONTH_PLAN_TYPE,
                            R_INTF_MONTH_FORECAST_HEAD.ENTITY_ID);
        --校验传入的周期信息与默认的周期信息，如果传入-1，则不做这层校验，否则校验 add by huanghb12
        IF R_INTF_MONTH_FORECAST_HEAD.MONTH_PLAN_PERIOD != -1 THEN
          --校验传入的周期信息
          IF R_STP_MONTH_PLAN_HEAD.PLAN_PERIOD != R_INTF_MONTH_FORECAST_HEAD.MONTH_PLAN_PERIOD THEN
            P_RESULT := V_VALUE || V_NL || '接口上报周期 ID' ||
                        R_INTF_MONTH_FORECAST_HEAD.MONTH_PLAN_PERIOD ||
                        ' 与系统获取默认周期 ID' || R_STP_MONTH_PLAN_HEAD.PLAN_PERIOD ||
                        ' 不一致';
            RAISE V_CCS_EXCEPTION;
          END IF;
        ELSE
          --否则将查询到的周期，回写到接口表变量 huanghb12
          R_INTF_MONTH_FORECAST_HEAD.MONTH_PLAN_PERIOD := R_STP_MONTH_PLAN_HEAD.PLAN_PERIOD;
        END IF;                     
      EXCEPTION
        WHEN OTHERS THEN
          P_RESULT := V_VALUE || '失败。' || V_NL || SQLERRM;
          RAISE V_CCS_EXCEPTION;
      END;
    END IF;
  
    --检查营销大类
    IF P_RESULT = V_SUCCESS AND V_IS_SALES_MAIN_TYPE = 'Y' THEN
      --如果接口头表营销大类为空-检查订单营销大类一致性add by huanghb12
      IF R_INTF_MONTH_FORECAST_HEAD.SALES_MAIN_TYPE IS NULL THEN
        --检查订单营销大类一致性 ：就是订单中产品明细里面的产品的营销大类是否一致，如果不一致则抛出异常 
        BEGIN
          v_Value := '检查订单营销大类一致性：';
          SELECT DISTINCT BI.SALES_MAIN_TYPE
            INTO R_INTF_MONTH_FORECAST_HEAD.SALES_MAIN_TYPE
            FROM INTF_MONTH_FORECAST_LINE L, T_BD_ITEM BI
           WHERE L.INTF_ID = P_INTF_ID
             AND L.ITEM_CODE = BI.ITEM_CODE
             AND L.ENTITY_ID = BI.ENTITY_ID;
        EXCEPTION
          WHEN OTHERS THEN
            p_Result := v_Value || v_Entity_Name || '，订单存在产品大类不一致的产品，请检查。';
            raise v_Ccs_Exception;
        END;
        --add by huanghb12
      ELSE
        --营销大类检查
        BEGIN
          V_VALUE := '营销大类检查：';
          SELECT CLASS_CODE
            INTO R_STP_MONTH_PLAN_HEAD.SALES_MAIN_TYPE
            FROM (SELECT IC.CLASS_CODE
                    FROM T_BD_ITEM_CLASS IC
                   WHERE IC.CLASS_CODE =
                         R_INTF_MONTH_FORECAST_HEAD.SALES_MAIN_TYPE
                     AND IC.ENTITY_ID = R_INTF_MONTH_FORECAST_HEAD.ENTITY_ID
                     AND IC.ACTIVE_FLAG = V_TRUE
                  UNION ALL
                  SELECT DISTINCT R.SC_ITEM_CLASS_CODE CLASS_CODE
                    FROM T_BD_ITEM_CLASS_RELATION R
                   WHERE R.HQ_ITEM_CLASS_CODE =
                         R_INTF_MONTH_FORECAST_HEAD.SALES_MAIN_TYPE
                     AND R.SALE_TYPE = 'M'
                     AND SYSDATE BETWEEN NVL(R.BEGIN_DATE, SYSDATE) AND
                         NVL(R.END_DATE, SYSDATE)
                     AND R.SC_ENTITY_ID = R_INTF_MONTH_FORECAST_HEAD.ENTITY_ID);
        EXCEPTION
          WHEN OTHERS THEN
            P_RESULT := V_VALUE || V_NL || '营销大类编码：' ||
                        R_INTF_MONTH_FORECAST_HEAD.SALES_MAIN_TYPE ||
                        '不存在或者已失效。';
            RAISE V_CCS_EXCEPTION;
        END;
      END IF;
    END IF;
  
    --检查营销小类
    IF P_RESULT = V_SUCCESS AND
       R_INTF_MONTH_FORECAST_HEAD.SALES_SUB_TYPE IS NOT NULL THEN
      BEGIN
        V_VALUE := '营销小类检查：';
        SELECT IC.CLASS_CODE
          INTO R_STP_MONTH_PLAN_HEAD.SALES_SUB_TYPE
          FROM T_BD_ITEM_CLASS IC
         WHERE IC.CLASS_CODE = R_INTF_MONTH_FORECAST_HEAD.SALES_SUB_TYPE
           AND IC.ENTITY_ID = R_INTF_MONTH_FORECAST_HEAD.ENTITY_ID
           AND IC.ACTIVE_FLAG = V_TRUE;
      EXCEPTION
        WHEN OTHERS THEN
          P_RESULT := V_VALUE || V_NL || '营销小类编码 ' ||
                      R_INTF_MONTH_FORECAST_HEAD.SALES_SUB_TYPE ||
                      '不存在或者已失效。';
          RAISE V_CCS_EXCEPTION;
      END;
    END IF;
  
    --检测营销中心编码
    IF P_RESULT = V_SUCCESS THEN
      BEGIN
        V_VALUE := '营销中心检查：';
        SELECT U.UNIT_ID, U.CODE, U.NAME
          INTO R_STP_MONTH_PLAN_HEAD.SALES_CENTER_ID,
               R_STP_MONTH_PLAN_HEAD.SALES_CENTER_CODE,
               R_STP_MONTH_PLAN_HEAD.SALES_CENTER_NAME
          FROM UP_ORG_UNIT U
         WHERE --U.UNIT_ID = R_INTF_MONTH_FORECAST_HEAD.SALES_CENTER_ID add by huanghb12
               --如果SALES_CENTER_ID = -1 则忽略此条件，否则用SALES_CENTER_ID查询 add by huanghb12
               U.UNIT_ID = decode(R_INTF_MONTH_FORECAST_HEAD.SALES_CENTER_ID,-1,U.UNIT_ID,R_INTF_MONTH_FORECAST_HEAD.SALES_CENTER_ID)
               --如果SALES_CENTER_ID = -1，则使用SALES_CENTER_CODE作为查询条件，否则忽略次条件 add by huanghb12
           AND U.CODE = decode(R_INTF_MONTH_FORECAST_HEAD.SALES_CENTER_ID,-1,R_INTF_MONTH_FORECAST_HEAD.SALES_CENTER_CODE,U.CODE)
           AND U.ACTIVE_FLAG = 'T';
          --写到接口头变量中，方便后续调用 huanghb12
          R_INTF_MONTH_FORECAST_HEAD.SALES_CENTER_ID :=  R_STP_MONTH_PLAN_HEAD.SALES_CENTER_ID;
      EXCEPTION
        WHEN OTHERS THEN
          P_RESULT := V_VALUE || V_NL || '营销中心：' ||
                      TO_CHAR(R_INTF_MONTH_FORECAST_HEAD.SALES_CENTER_CODE) ||
                      '不存在或者已失效。';
          RAISE V_CCS_EXCEPTION;
      END;
    END IF;
  
    --检测客户编码
    IF P_RESULT = V_SUCCESS THEN
      BEGIN
        V_VALUE := '客户检查：';
        SELECT CH.CUSTOMER_ID, CH.CUSTOMER_CODE, CH.CUSTOMER_NAME
          INTO R_STP_MONTH_PLAN_HEAD.CUSTOMER_ID,
               R_STP_MONTH_PLAN_HEAD.CUSTOMER_CODE,
               R_STP_MONTH_PLAN_HEAD.CUSTOMER_NAME
          FROM T_CUSTOMER_HEADER CH
         WHERE --CH.CUSTOMER_ID = R_INTF_MONTH_FORECAST_HEAD.CUSTOMER_ID
               CH.CUSTOMER_ID = decode(R_INTF_MONTH_FORECAST_HEAD.CUSTOMER_ID,-1,CH.CUSTOMER_ID,R_INTF_MONTH_FORECAST_HEAD.CUSTOMER_ID) --add by huanghb12
           AND CH.CUSTOMER_CODE = decode(R_INTF_MONTH_FORECAST_HEAD.CUSTOMER_ID,-1,R_INTF_MONTH_FORECAST_HEAD.CUSTOMER_CODE,CH.CUSTOMER_CODE) --add by huanghb12
           AND CH.ACTIVE_FLAG = V_ACTIVE;
           
           R_INTF_MONTH_FORECAST_HEAD.CUSTOMER_ID := R_STP_MONTH_PLAN_HEAD.CUSTOMER_ID;--add by huanghb12
      EXCEPTION
        WHEN OTHERS THEN
          P_RESULT := V_VALUE || V_NL || '客户：' ||
                      TO_CHAR(R_INTF_MONTH_FORECAST_HEAD.CUSTOMER_CODE) ||
                      '不存在或已失效。';
          RAISE V_CCS_EXCEPTION;
      END;
    END IF;
  
    --检测账户编码
    IF P_RESULT = V_SUCCESS THEN
      BEGIN
        V_VALUE := '客户账户检查：';
        SELECT CA.ACCOUNT_CODE, NVL(CA.ACCOUNT_NAME, ' '), CA.ACCOUNT_ID
          INTO R_STP_MONTH_PLAN_HEAD.ACCOUNT_CODE,
               R_STP_MONTH_PLAN_HEAD.ACCOUNT_NAME,
               R_STP_MONTH_PLAN_HEAD.ACCOUNT_ID
          FROM V_CUSTOMER_ACCOUNT_SALECENTER CA
         WHERE CA.SALES_CENTER_ID =
               R_INTF_MONTH_FORECAST_HEAD.SALES_CENTER_ID
           AND CA.CUSTOMER_ID = R_INTF_MONTH_FORECAST_HEAD.CUSTOMER_ID
           AND CA.ENTITY_ID = R_INTF_MONTH_FORECAST_HEAD.ENTITY_ID
           AND CA.ACTIVE_FLAG = V_ACTIVE
           AND CA.ACCOUNT_STATUS = V_ACCOUNT_ACTIVE;
        --账户ID不为空才检查，为空则直接取视图数据
        if R_INTF_MONTH_FORECAST_HEAD.ACCOUNT_ID <> -1 then
          IF R_STP_MONTH_PLAN_HEAD.ACCOUNT_ID <>
             R_INTF_MONTH_FORECAST_HEAD.ACCOUNT_ID THEN
            P_RESULT := V_VALUE || V_NL || '主体ID：' ||
                        TO_CHAR(R_INTF_MONTH_FORECAST_HEAD.ENTITY_ID) ||
                        ' 中心ID：' ||
                        TO_CHAR(R_INTF_MONTH_FORECAST_HEAD.SALES_CENTER_ID) ||
                        ' 客户ID：' ||
                        TO_CHAR(R_INTF_MONTH_FORECAST_HEAD.CUSTOMER_ID) ||
                        ' 账户ID：' ||
                        TO_CHAR(R_INTF_MONTH_FORECAST_HEAD.ACCOUNT_ID) ||
                        '对应关系有误';
            RAISE V_CCS_EXCEPTION;
          END IF;
        END IF;
      EXCEPTION
        WHEN OTHERS THEN
          P_RESULT := V_VALUE || V_NL || '主体ID：' ||
                      TO_CHAR(R_INTF_MONTH_FORECAST_HEAD.ENTITY_ID) ||
                      ' 中心ID：' ||
                      TO_CHAR(R_INTF_MONTH_FORECAST_HEAD.SALES_CENTER_ID) ||
                      ' 客户ID：' ||
                      TO_CHAR(R_INTF_MONTH_FORECAST_HEAD.CUSTOMER_ID) ||
                      '不存在对应的账户，或账户未激活。';
          RAISE V_CCS_EXCEPTION;
      END;
    END IF;
  
    --检查重复报送
    IF P_RESULT = V_SUCCESS THEN
      SELECT COUNT(1)
        INTO V_COUNT
        FROM T_STP_MONTH_PLAN_HEAD H,t_pln_order_type t
       WHERE H.ENTITY_ID = R_INTF_MONTH_FORECAST_HEAD.ENTITY_ID
         AND H.PLAN_TYPE = R_INTF_MONTH_FORECAST_HEAD.MONTH_PLAN_TYPE
         AND H.PLAN_PERIOD = R_INTF_MONTH_FORECAST_HEAD.MONTH_PLAN_PERIOD
         AND H.SALES_MAIN_TYPE = R_INTF_MONTH_FORECAST_HEAD.SALES_MAIN_TYPE
         AND H.ACCOUNT_ID = R_INTF_MONTH_FORECAST_HEAD.ACCOUNT_ID
         And nvl(h.source_order_head_id,0) <> R_INTF_MONTH_FORECAST_HEAD.SOURCE_ORDER_HEAD_ID
         AND H.PLAN_STATUS <> '06'
         AND h.plan_type = t.order_type_id
         AND h.entity_id = t.entity_id
         AND t.send_by_type = 1;
      IF V_COUNT > 0 THEN
        P_RESULT := '中心[' || R_STP_MONTH_PLAN_HEAD.SALES_CENTER_NAME ||
                    ']客户[' || R_STP_MONTH_PLAN_HEAD.CUSTOMER_NAME ||
                    ']在周期[' || V_PERIOD_CODE || ']已经提交过[' ||
                    R_PLN_ORDER_TYPE.ORDER_TYPE_NAME || ']，不能重复提交。';
        RAISE V_CCS_EXCEPTION;
      END IF;
      --查询该中心是否已经汇总
      SELECT COUNT(0)
        INTO V_COUNT
        FROM T_STP_MONTH_PLAN_HEAD H,t_pln_order_type t
       WHERE H.ENTITY_ID = R_INTF_MONTH_FORECAST_HEAD.ENTITY_ID
         AND H.SALES_CENTER_CODE = R_INTF_MONTH_FORECAST_HEAD.SALES_CENTER_CODE --中心编码
         AND H.PLAN_TYPE = R_INTF_MONTH_FORECAST_HEAD.MONTH_PLAN_TYPE --计划类型
         AND H.PLAN_PERIOD = R_INTF_MONTH_FORECAST_HEAD.MONTH_PLAN_PERIOD --计划周期
         AND H.SALES_MAIN_TYPE = R_INTF_MONTH_FORECAST_HEAD.SALES_MAIN_TYPE --营销大类
         AND H.CUSTOMER_CODE IS NULL -- 客户为空
         AND H.PLAN_STATUS <> '06' --非关闭状态
         And h.plan_type = t.order_type_id
         And h.entity_id = t.entity_id
         And t.send_by_type = 1;
      IF V_COUNT > 0 THEN
        P_RESULT := '客户所属的中心[' || R_STP_MONTH_PLAN_HEAD.SALES_CENTER_NAME || ']已存在有效的月预测，不允许报送客户预测。';
        RAISE V_CCS_EXCEPTION;
      END IF;
    END IF;
  
    --检查是否有月预测计划行
    IF P_RESULT = V_SUCCESS THEN
      SELECT COUNT(1)
        INTO V_COUNT
        FROM INTF_MONTH_FORECAST_LINE L
       WHERE L.INTF_ID = R_INTF_MONTH_FORECAST_HEAD.INTF_ID
         AND L.ENTITY_ID = R_INTF_MONTH_FORECAST_HEAD.ENTITY_ID;
      IF V_COUNT = 0 THEN
        P_RESULT := '无月预测计划行资料，不能提交。';
        RAISE V_CCS_EXCEPTION;
      END IF;
    END IF;
  
    --检查是否月预测计划行产品产地是否有重复
    IF P_RESULT = V_SUCCESS THEN
      Begin
        If v_is_producing_area = 'Y' Then
          SELECT COUNT(1)
            INTO V_COUNT
            FROM INTF_MONTH_FORECAST_LINE L
           WHERE L.INTF_ID = R_INTF_MONTH_FORECAST_HEAD.INTF_ID
             AND L.ENTITY_ID = R_INTF_MONTH_FORECAST_HEAD.ENTITY_ID
           GROUP BY L.ITEM_CODE, L.PRODUCING_AREA_ID
          HAVING COUNT(1) > 1;
        Else
          SELECT COUNT(1)
            INTO V_COUNT
            FROM INTF_MONTH_FORECAST_LINE L
           WHERE L.INTF_ID = R_INTF_MONTH_FORECAST_HEAD.INTF_ID
             AND L.ENTITY_ID = R_INTF_MONTH_FORECAST_HEAD.ENTITY_ID
           GROUP BY L.ITEM_CODE
          HAVING COUNT(1) > 1;
        End If;
      EXCEPTION
        WHEN OTHERS THEN
          V_COUNT := 0;
      END;
      IF V_COUNT > 0 THEN
        P_RESULT := '月预测计划行相同的产品和产地只允许存在一行。';
        RAISE V_CCS_EXCEPTION;
      END IF;
    END IF;
  
    IF P_RESULT = V_SUCCESS THEN
      --生成月预测计划编号
      BEGIN
        PKG_BD.P_GET_BILL_NO(P_BILL_TYPE  => 'stpMonthPlanNo',
                             P_PREFIX_ADD => NULL,
                             P_ENTITY_ID  => R_STP_MONTH_PLAN_HEAD.ENTITY_ID,
                             P_USER_ID    => NULL,
                             P_BILL_NO    => R_STP_MONTH_PLAN_HEAD.PLAN_SEQUENCE);
      
        IF NVL(R_STP_MONTH_PLAN_HEAD.PLAN_SEQUENCE, '_') = '_' THEN
          P_RESULT := '获取月预测计划编号失败，单号编码规则：stpMonthPlanNo。';
          RAISE V_CCS_EXCEPTION;
        END IF;
      EXCEPTION
        WHEN OTHERS THEN
          P_RESULT := '获取月预测计划编号失败，单号编码规则：stpMonthPlanNo。' || V_NL ||
                      SQLERRM;
          RAISE V_CCS_EXCEPTION;
      END;
    END IF;
  
    IF P_RESULT = V_SUCCESS THEN
      --新增月预测计划头
      BEGIN
        V_HEAD_COUNT:=0;
        SELECT COUNT(1)
          INTO V_HEAD_COUNT
          FROM T_STP_MONTH_PLAN_HEAD A
         WHERE A.SOURCE_ORDER_HEAD_ID =
               R_INTF_MONTH_FORECAST_HEAD.SOURCE_ORDER_HEAD_ID
           And a.plan_status = '01';
        IF V_HEAD_COUNT>0 THEN  
            SELECT A.MONTH_PLAN_HEAD_ID,a.plan_sequence
              INTO R_STP_MONTH_PLAN_HEAD.MONTH_PLAN_HEAD_ID,
                   R_STP_MONTH_PLAN_HEAD.PLAN_SEQUENCE
              FROM T_STP_MONTH_PLAN_HEAD A
             WHERE A.SOURCE_ORDER_HEAD_ID =
                   R_INTF_MONTH_FORECAST_HEAD.SOURCE_ORDER_HEAD_ID
               AND ROWNUM = 1;
        ELSE 
          SELECT COUNT(1)
            INTO V_HEAD_COUNT
            FROM T_STP_MONTH_PLAN_HEAD A
           WHERE A.SOURCE_ORDER_HEAD_ID =
                 R_INTF_MONTH_FORECAST_HEAD.SOURCE_ORDER_HEAD_ID
             And a.plan_status <> '01';
          If V_HEAD_COUNT > 0 Then
            P_RESULT := '客户预测已关闭或者不是制单状态，不能重新提交！CCS预测头ID：' || R_INTF_MONTH_FORECAST_HEAD.SOURCE_ORDER_HEAD_ID;
            V_VALUE := '客户预测已关闭或者不是制单状态，不能重新提交！CCS预测头ID：' || R_INTF_MONTH_FORECAST_HEAD.SOURCE_ORDER_HEAD_ID;
            RAISE V_CCS_EXCEPTION;
          Else
            SELECT S_STP_MONTH_PLAN_HEAD.NEXTVAL
              INTO R_STP_MONTH_PLAN_HEAD.MONTH_PLAN_HEAD_ID
              FROM DUAL;
          End If;
             
        END IF; 
        R_STP_MONTH_PLAN_HEAD.ENTITY_ID        := R_INTF_MONTH_FORECAST_HEAD.ENTITY_ID;
        R_STP_MONTH_PLAN_HEAD.PLAN_NAME        := R_INTF_MONTH_FORECAST_HEAD.MONTH_PLAN_NAME;
        R_STP_MONTH_PLAN_HEAD.PLAN_STATUS      := '04';
        R_STP_MONTH_PLAN_HEAD.CREATED_BY       := 'PKG_PLN_INTF_CCS';
        R_STP_MONTH_PLAN_HEAD.CREATION_DATE    := SYSDATE;
        R_STP_MONTH_PLAN_HEAD.LAST_UPDATED_BY  := 'PKG_PLN_INTF_CCS';
        R_STP_MONTH_PLAN_HEAD.LAST_UPDATE_DATE := SYSDATE;
        R_STP_MONTH_PLAN_HEAD.VERSION          := 1;
        R_STP_MONTH_PLAN_HEAD.plan_mode        := 'CUSTOMER';
        R_STP_MONTH_PLAN_HEAD.SYS_SOURCE :=R_INTF_MONTH_FORECAST_HEAD.SYS_SOURCE;
		    R_STP_MONTH_PLAN_HEAD.SOURCE_ORDER_HEAD_ID :=R_INTF_MONTH_FORECAST_HEAD.SOURCE_ORDER_HEAD_ID;
        R_STP_MONTH_PLAN_HEAD.Source_Order_Number := R_INTF_MONTH_FORECAST_HEAD.Source_Order_Number;
        V_VALUE := '写入月预测计划头表：';
       IF V_HEAD_COUNT>0 THEN
       UPDATE T_STP_MONTH_PLAN_HEAD A
          SET A.ENTITY_ID        = R_STP_MONTH_PLAN_HEAD.ENTITY_ID,
              A.PLAN_NAME        = R_STP_MONTH_PLAN_HEAD.PLAN_NAME,
              A.PLAN_STATUS      = R_STP_MONTH_PLAN_HEAD.PLAN_STATUS,
              A.CREATED_BY       = R_STP_MONTH_PLAN_HEAD.CREATED_BY,
              A.CREATION_DATE    = R_STP_MONTH_PLAN_HEAD.CREATION_DATE,
              A.LAST_UPDATED_BY  = R_STP_MONTH_PLAN_HEAD.LAST_UPDATED_BY,
              A.LAST_UPDATE_DATE = R_STP_MONTH_PLAN_HEAD.LAST_UPDATE_DATE,
              A.VERSION          = R_STP_MONTH_PLAN_HEAD.VERSION,
              A.SYS_SOURCE       = R_STP_MONTH_PLAN_HEAD.SYS_SOURCE
        WHERE A.MONTH_PLAN_HEAD_ID = R_STP_MONTH_PLAN_HEAD.MONTH_PLAN_HEAD_ID;
         ELSE 
        INSERT INTO T_STP_MONTH_PLAN_HEAD VALUES R_STP_MONTH_PLAN_HEAD;
        END IF;
      EXCEPTION
        WHEN OTHERS THEN
          P_RESULT := V_VALUE || '，失败。' || V_NL || SQLERRM;
          RAISE V_CCS_EXCEPTION;
      END;
    END IF;

     --add by huanghb12  校验产品生命周期
    BEGIN
      VS_ITEM_LIFE_CYCLE := PKG_BD.F_GET_PARAMETER_VALUE('PLN_ITEM_LIFE_CYCLE', R_INTF_MONTH_FORECAST_HEAD.ENTITY_ID);
    EXCEPTION
      WHEN OTHERS THEN
        P_RESULT := '获取PLN_ITEM_LIFE_CYCLE参数失败。' || V_NL || SQLERRM;
        RAISE V_CCS_EXCEPTION;
    END;
    --end huanghb12 
      
    --检测并将接口表行数据插入业务表
    IF P_RESULT = V_SUCCESS THEN
      --删除原来的数据再插入
      DELETE FROM T_STP_MONTH_PLAN_LINES line WHERE line.month_plan_head_id=R_STP_MONTH_PLAN_HEAD.MONTH_PLAN_HEAD_ID;
      FOR R_INTF_MONTH_FORECAST_LINE IN (SELECT *
                                           FROM INTF_MONTH_FORECAST_LINE L
                                          WHERE L.INTF_ID = P_INTF_ID) LOOP
        EXIT WHEN P_RESULT <> V_SUCCESS;
        IF P_RESULT = V_SUCCESS THEN
          BEGIN
            V_VALUE := '产品编码检查：';
            SELECT BI.ITEM_ID,
                   BI.ITEM_CODE,
                   BI.ITEM_NAME,
                   BI.SALES_MAIN_TYPE,
                   BI.SALES_SUB_TYPE
              INTO R_STP_MONTH_PLAN_LINE.ITEM_ID,
                   R_STP_MONTH_PLAN_LINE.ITEM_CODE,
                   R_STP_MONTH_PLAN_LINE.ITEM_NAME,
                   R_STP_MONTH_PLAN_LINE.SALES_MAIN_TYPE,
                   R_STP_MONTH_PLAN_LINE.SALES_SUB_TYPE
              FROM T_BD_ITEM BI
             WHERE BI.ITEM_CODE = R_INTF_MONTH_FORECAST_LINE.ITEM_CODE
               AND BI.ENTITY_ID = R_INTF_MONTH_FORECAST_LINE.ENTITY_ID
               AND BI.ACTIVE_FLAG = V_TRUE;
          EXCEPTION
            WHEN OTHERS THEN
              P_RESULT := V_VALUE || V_NL || '产品编码：' ||
                          R_INTF_MONTH_FORECAST_LINE.ITEM_CODE || '不存在或已失效';
              RAISE V_CCS_EXCEPTION;
          END;
        END IF;
        
        --add by huanghb12 检验产品生命周期  提报月订单的时候
        IF P_RESULT = V_SUCCESS AND VS_ITEM_LIFE_CYCLE != 'N' And v_is_producing_area = 'Y' THEN
          BEGIN
            V_VALUE := '产品生命周期检查：';
            --调用函数，校验产品的生命周期
            VS_CHECK_RESULT := NULL;
            VS_CHECK_RESULT := PKG_PLN_PUB.p_Chk_Item_Prdc_Life_Cycle( R_INTF_MONTH_FORECAST_LINE.ENTITY_ID, 
                                                                       R_STP_MONTH_PLAN_LINE.Item_Id,
                                                                       R_INTF_MONTH_FORECAST_LINE.Producing_Area_Id,
                                                                       --检查是否允许提交
                                                                       PKG_PLN_PUB.v_Phase_Month_Submit,
                                                                       --增加一个参数：月预测计划订单类型
                                                                       'MONTH_PLAN');
            IF VS_CHECK_RESULT != 'Y' THEN
              --如果检测不通过则，抛出异常
              RAISE V_CCS_EXCEPTION;
            END IF;   
          EXCEPTION
            WHEN OTHERS THEN
             p_Result := VS_CHECK_RESULT||'，按生命周期控制，不允许报送！' || sqlerrm;
             RAISE V_CCS_EXCEPTION;
          END;
        END IF;
        --end huanghb12
      
      
        IF P_RESULT = V_SUCCESS And v_is_producing_area = 'Y' THEN
          BEGIN
            V_VALUE := '产地检查：';
            SELECT Distinct A.PRODUCING_AREA_CODE, A.PRODUCING_AREA_NAME
              INTO R_STP_MONTH_PLAN_LINE.PRODUCING_AREA_CODE,
                   R_STP_MONTH_PLAN_LINE.PRODUCING_AREA_NAME
              FROM T_PLN_PRODUCING_AREA A
            --modi by lizhen 2016-02-23 产地按产地编码检查
             WHERE --A.PRODUCING_AREA_NAME = R_INTF_MONTH_FORECAST_LINE.PRODUCING_AREA_NAME
             A.PRODUCING_AREA_CODE =
             R_INTF_MONTH_FORECAST_LINE.PRODUCING_AREA_CODE --ADD BY LIZHEN 2016-02-23
             AND (A.ENTITY_ID = R_INTF_MONTH_FORECAST_LINE.ENTITY_ID OR
             A.ENTITY_ID IN
             (SELECT DISTINCT R.HQ_ENTITY_ID
                 FROM T_BD_CENTER_RELATION R
                WHERE R.SC_ENTITY_ID = R_INTF_MONTH_FORECAST_LINE.ENTITY_ID))
             AND TRUNC(R_INTF_MONTH_FORECAST_LINE.INTF_DATE) BETWEEN
             A.BEGIN_DATE AND NVL(A.END_DATE, SYSDATE + 1);
          EXCEPTION
            WHEN OTHERS THEN
              P_RESULT := V_VALUE || V_NL || '产地：' ||
                          R_INTF_MONTH_FORECAST_LINE.PRODUCING_AREA_NAME ||
                          '不存在或已失效';
              RAISE V_CCS_EXCEPTION;
          END;
        END IF;
      
        IF P_RESULT = V_SUCCESS And v_is_producing_area = 'Y' THEN
          BEGIN
            V_VALUE := '产品产地检查：';
            BEGIN
              SELECT COUNT(1)
                INTO V_COUNT
                FROM T_PLN_ITEM_PRODUCING_AREA A
               WHERE A.ITEM_CODE = R_INTF_MONTH_FORECAST_LINE.ITEM_CODE
                    --modi by lizhen 2016-02-23 产地按产地编码检查
                    --AND A.PRODUCING_AREA_NAME = R_INTF_MONTH_FORECAST_LINE.PRODUCING_AREA_NAME
                 AND A.PRODUCING_AREA_CODE =
                     R_INTF_MONTH_FORECAST_LINE.PRODUCING_AREA_CODE --add by lizhen 2016-02-23
                 AND (A.ENTITY_ID = R_INTF_MONTH_FORECAST_LINE.ENTITY_ID OR
                     A.ENTITY_ID IN
                     (SELECT DISTINCT R.HQ_ENTITY_ID
                         FROM T_BD_CENTER_RELATION R
                        WHERE R.SC_ENTITY_ID =
                              R_INTF_MONTH_FORECAST_LINE.ENTITY_ID))
                 AND TRUNC(R_INTF_MONTH_FORECAST_LINE.INTF_DATE) BETWEEN
                     A.BEGIN_DATE AND NVL(A.END_DATE, SYSDATE + 1);
            EXCEPTION
              WHEN OTHERS THEN
                V_COUNT := 0;
            END;
            IF V_COUNT = 0 THEN
              P_RESULT := V_VALUE || V_NL || '产品编码：' ||
                          R_INTF_MONTH_FORECAST_LINE.ITEM_CODE || '在产地：' ||
                          R_INTF_MONTH_FORECAST_LINE.PRODUCING_AREA_NAME ||
                          '不生产';
              RAISE V_CCS_EXCEPTION;
            END IF;
          END;
        END IF;
      
        R_STP_MONTH_PLAN_LINE.MONTH_PLAN_QTY := R_INTF_MONTH_FORECAST_LINE.MONTH_PLAN_QTY;
        --MODI BY DENGJH 2016-10-14增加单价和金额
        R_STP_MONTH_PLAN_LINE.PRICE             := R_INTF_MONTH_FORECAST_LINE.PRICE;
        R_STP_MONTH_PLAN_LINE.MONTH_PLAN_AMOUNT := R_INTF_MONTH_FORECAST_LINE.MONTH_PLAN_AMOUNT;
      
        IF NVL(R_STP_MONTH_PLAN_LINE.MONTH_PLAN_QTY, 0) < 0 Then
          If v_is_business_control = 'collect' Then
            P_RESULT := 'M+1月预计提货量有误，产品编码：' ||
                        R_INTF_MONTH_FORECAST_LINE.ITEM_CODE || '数量不能小于0。';
            RAISE V_CCS_EXCEPTION;
          Else
            P_RESULT := '月预测计划行数量有误，产品编码：' ||
                        R_INTF_MONTH_FORECAST_LINE.ITEM_CODE || '数量不能小于0。';
            RAISE V_CCS_EXCEPTION;
          End If;
        END IF;
        
        IF NVL(R_STP_MONTH_PLAN_LINE.M2_Month_Plan_Qty, 0) < 0 THEN
          P_RESULT := 'M+2月预计提货量有误，产品编码：' ||
                      R_INTF_MONTH_FORECAST_LINE.ITEM_CODE || '数量不能小于0。';
          RAISE V_CCS_EXCEPTION;
        END IF;
        
        IF NVL(R_STP_MONTH_PLAN_LINE.M3_Month_Plan_Qty, 0) < 0 THEN
          P_RESULT := 'M+3月预计提货量有误，产品编码：' ||
                      R_INTF_MONTH_FORECAST_LINE.ITEM_CODE || '数量不能小于0。';
          RAISE V_CCS_EXCEPTION;
        END IF;
      
        --接口表行数据插入业务表行
        IF P_RESULT = V_SUCCESS THEN
        
          BEGIN
            V_VALUE := '写入月预测计划行表数据';
          
            SELECT S_STP_MONTH_PLAN_LINES.NEXTVAL
              INTO R_STP_MONTH_PLAN_LINE.MONTH_PLAN_LINE_ID
              FROM DUAL;
            R_STP_MONTH_PLAN_LINE.MONTH_PLAN_HEAD_ID := R_STP_MONTH_PLAN_HEAD.MONTH_PLAN_HEAD_ID;
            R_STP_MONTH_PLAN_LINE.ENTITY_ID          := R_INTF_MONTH_FORECAST_LINE.ENTITY_ID;
            R_STP_MONTH_PLAN_LINE.CREATED_BY         := 'PKG_PLN_INTF_CCS';
            R_STP_MONTH_PLAN_LINE.CREATION_DATE      := SYSDATE;
            R_STP_MONTH_PLAN_LINE.LAST_UPDATED_BY    := 'PKG_PLN_INTF_CCS';
            R_STP_MONTH_PLAN_LINE.LAST_UPDATE_DATE   := SYSDATE;
            R_STP_MONTH_PLAN_LINE.VERSION            := 1;
            R_STP_MONTH_PLAN_LINE.current_stock           :=R_INTF_MONTH_FORECAST_LINE.Current_Stock;
            R_STP_MONTH_PLAN_LINE.expected_stock_eom      :=R_INTF_MONTH_FORECAST_LINE.expected_stock_eom;
            R_STP_MONTH_PLAN_LINE.monthly_average_sales   :=R_INTF_MONTH_FORECAST_LINE.monthly_average_sales;
            R_STP_MONTH_PLAN_LINE.m1_monthly_average_sales:=R_INTF_MONTH_FORECAST_LINE.m1_monthly_average_sales;
			-- modi by jiangwei29 增加分销金额字段
            R_STP_MONTH_PLAN_LINE.m1_monthly_average_amount:=R_INTF_MONTH_FORECAST_LINE.m1_monthly_average_amount;
            R_STP_MONTH_PLAN_LINE.m1_stock_eom            :=R_INTF_MONTH_FORECAST_LINE.m1_stock_eom;
            R_STP_MONTH_PLAN_LINE.m1_stocktopin_ratio     :=R_INTF_MONTH_FORECAST_LINE.m1_stocktopin_ratio;
            R_STP_MONTH_PLAN_LINE.m1_abnormal_hints       :=R_INTF_MONTH_FORECAST_LINE.m1_abnormal_hints;
            R_STP_MONTH_PLAN_LINE.m2_monthly_average_sales:=R_INTF_MONTH_FORECAST_LINE.m2_monthly_average_sales;
	        R_STP_MONTH_PLAN_LINE.m2_monthly_average_amount:=R_INTF_MONTH_FORECAST_LINE.m2_monthly_average_amount;
            R_STP_MONTH_PLAN_LINE.m2_month_plan_qty       :=R_INTF_MONTH_FORECAST_LINE.m2_month_plan_qty;
            R_STP_MONTH_PLAN_LINE.m2_month_plan_amount    :=R_INTF_MONTH_FORECAST_LINE.m2_month_plan_amount;
            R_STP_MONTH_PLAN_LINE.m2_stock_eom            :=R_INTF_MONTH_FORECAST_LINE.m2_stock_eom;
            R_STP_MONTH_PLAN_LINE.m2_stocktopin_ratio     :=R_INTF_MONTH_FORECAST_LINE.m2_stocktopin_ratio;
            R_STP_MONTH_PLAN_LINE.m2_abnormal_hints       :=R_INTF_MONTH_FORECAST_LINE.m2_abnormal_hints;
            R_STP_MONTH_PLAN_LINE.m3_monthly_average_sales:=R_INTF_MONTH_FORECAST_LINE.m3_monthly_average_sales;
	        R_STP_MONTH_PLAN_LINE.m3_monthly_average_amount:=R_INTF_MONTH_FORECAST_LINE.m3_monthly_average_amount;
            R_STP_MONTH_PLAN_LINE.m3_month_plan_qty       :=R_INTF_MONTH_FORECAST_LINE.m3_month_plan_qty;
            R_STP_MONTH_PLAN_LINE.m3_month_plan_amount    :=R_INTF_MONTH_FORECAST_LINE.m3_month_plan_amount;
            R_STP_MONTH_PLAN_LINE.m3_stock_eom            :=R_INTF_MONTH_FORECAST_LINE.m3_stock_eom;
            R_STP_MONTH_PLAN_LINE.m3_stocktopin_ratio     :=R_INTF_MONTH_FORECAST_LINE.m3_stocktopin_ratio;
            R_STP_MONTH_PLAN_LINE.m3_abnormal_hints       :=R_INTF_MONTH_FORECAST_LINE.m3_abnormal_hints;
            --R_STP_MONTH_PLAN_LINE.source_mode             :='add'; --标记行上数据是汇总生成的还是新增的
            INSERT INTO T_STP_MONTH_PLAN_LINES
            VALUES R_STP_MONTH_PLAN_LINE;
          EXCEPTION
            WHEN OTHERS THEN
              P_RESULT := V_VALUE || '失败。' || V_NL || SQLERRM;
              RAISE V_CCS_EXCEPTION;
          END;
        END IF;
      END LOOP;
    END IF;
  
    IF P_RESULT = V_SUCCESS THEN
      BEGIN
        V_VALUE := '更新接口表状态：';
        UPDATE INTF_MONTH_FORECAST_HEAD H
           SET H.INTF_STATUS     = V_STATUS_SUCESS,
               H.ERROR_MESSAGE   = P_RESULT,
               H.MONTH_PLAN_ID   = R_STP_MONTH_PLAN_HEAD.MONTH_PLAN_HEAD_ID,
               H.MONTH_PLAN_CODE = R_STP_MONTH_PLAN_HEAD.PLAN_SEQUENCE
         WHERE H.INTF_ID = P_INTF_ID;
        --COMMIT;
      EXCEPTION
        WHEN OTHERS THEN
          P_RESULT := V_VALUE || '接口表ID：' || P_INTF_ID || '失败。';
          RAISE V_CCS_EXCEPTION;
      END;
    END IF;
  
    IF P_RESULT <> V_SUCCESS THEN
      RAISE V_CCS_EXCEPTION;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      --ROLLBACK;
      P_RESULT := '失败：' || P_RESULT || V_NL || SQLERRM;
      UPDATE INTF_MONTH_FORECAST_HEAD H
         SET H.INTF_STATUS = V_STATUS_FAIL, H.ERROR_MESSAGE = P_RESULT
       WHERE H.INTF_ID = P_INTF_ID;
    
      V_VALUE := PKG_BD.F_ADD_ERROR_LOG('PKG_PLN_INTF_CCS.P_CREATE_MONTH_FORECAST',
                                        1000,
                                        P_INTF_ID || '|' || P_RESULT);
      --COMMIT;
  END;
  
  /*
   获取产品最优产地
  */
  Function f_Get_Item_Prod_Area(p_Entity_Id       In Number,
                                p_Sales_Center_Id In Number,
                                p_Item_Code       In Varchar2,
                                p_Item_Life_Cycle In Varchar2 Default 'Y' --add by lizhen 2016-04-22
                                ) Return Number Is
    v_Product_Area_Id    Number;
    v_Item_Id            Number;
    v_Hq_Entity_Id       Number; --总部主体
    v_Hq_Sales_Center_Id Number; --总部中心
  Begin
    Begin
      --获取当前主体产品ID
      Select i.Item_Id
        Into v_Item_Id
        From t_Bd_Item i
       Where i.Entity_Id = p_Entity_Id
         And i.Item_Code = p_Item_Code;
    Exception
      When No_Data_Found Then
        v_Item_Id := Null;
    End;
    --先获取当前主体最优产品产地id
    v_Product_Area_Id := Pkg_Pln_Pub.f_Get_Item_Prod_Area_Priority(p_Entity_Id,
                                                                   p_Sales_Center_Id,
                                                                   v_Item_Id,
                                                                   p_Item_Life_Cycle --add by lizhen 2016-04-22
                                                                   );
    --当前主体产品最优产地不存在，则获取跨主体关系，找总部主体的最优产地 lilh6 2018-10-10
    If v_Product_Area_Id Is Null Or v_Product_Area_Id = 0 Then
      --获取跨主体关系，针对存在一对多主体的跨主体关系修改 lilh6 2018-10-10
      For r_Hq In (Select Distinct r.Hq_Entity_Id, r.Hq_Sales_Center_Id
                     From t_Bd_Center_Relation r
                    Where r.Sc_Entity_Id = p_Entity_Id
                      And r.Sc_Entity_Id <> r.Hq_Entity_Id
                      And r.Sc_Sales_Center_Id = p_Sales_Center_Id) Loop
        v_Hq_Entity_Id       := r_Hq.Hq_Entity_Id;
        v_Hq_Sales_Center_Id := r_Hq.Hq_Sales_Center_Id;
        --获取总部主体产品id
        Begin
          Select i.Item_Id
            Into v_Item_Id
            From t_Bd_Item i
           Where i.Entity_Id = v_Hq_Entity_Id
             And i.Item_Code = p_Item_Code;
        Exception
          When No_Data_Found Then
            v_Item_Id := Null;
        End;
        --产品id不为空，直接获取最优产地id
        If v_Item_Id Is Not Null Then
          v_Product_Area_Id := Pkg_Pln_Pub.f_Get_Item_Prod_Area_Priority(v_Hq_Entity_Id, --P_ENTITY_ID,
                                                                         v_Hq_Sales_Center_Id, --P_SALES_CENTER_ID,
                                                                         v_Item_Id,
                                                                         p_Item_Life_Cycle --add by lizhen 2016-04-22
                                                                         );
          If v_Product_Area_Id Is Not Null And v_Product_Area_Id <> 0 Then
            --最优产地id不为空，直接返回
            Return v_Product_Area_Id;
          End If;
        End If;
      End Loop;
    Else
      Return v_Product_Area_Id;
    End If;
  
    Return v_Product_Area_Id;
  Exception
    When Others Then
      Return Null;
  End;
   
  -----------------------------------------------------------------------------
  -- AUTHOR  : Nicro.Li
  -- CREATED : 2015-12-09
  -- PURPOSE : 订单送审前检查到款金额，检查金额时增加非送审锁款单据的金额检查，需扣减该部份款项
  --IN_DISCOUNT_TYPE参数说明：ALL：先检查常到款，不足时再检查折让到款 COMMON:只检查常规到款 DISCOUNT：只检查折让到款
  -----------------------------------------------------------------------------
  Procedure p_Submit_Check_Amount(p_Order_Type_Id   In Number, --单据类型ID
                                  p_Customer_Id     In Number, --客户ID
                                  p_Account_Id      In Number, --账户ID
                                  p_Sales_Main_Type In Varchar2, --产品大类
                                  p_Amount          In Number, --提货金额
                                  p_Discount_Amount In Number, --折扣金额额
                                  p_Result          In Out Varchar2, --返回结果：SUCCESS——>过程执行完成；FAILURE——>中途抛错
                                  p_Message         Out Varchar2, --返回信息：这里的值初始为SUCCESS
                                  IN_DISCOUNT_TYPE  In Varchar2 Default 'ALL' --ADD BY LIZHEN 2017-08-17增加检查到款类型
                                  ) Is
    r_Order_Type                 t_Pln_Order_Type%Rowtype;
    v_Lg_No_Ship_Amount          Number; --提货订单已评审未发货金额
    v_Lg_No_Ship_Discount_Amount Number;
    v_Credit_Amount              Number;
    v_Credit_Discount_Amount     Number;
    v_Param_Down_Pay_Rate number; --20170601 hejy3 是否启用订金控制
    v_Order_Down_Pay_Rate number := 100; --20170601 hejy3 订金比例
    v_Sales_Center_Id number; --20170601 hejy3 中心ID
    v_Order_Amount number;
    v_Order_Dis_Amount number;
    v_Down_Pay_Tip boolean := false; --是否提示订金比例
    v_Cre_Dis_Type_Enable_Flag  t_Bd_Param_List.Default_Value%Type; -- add by lizhen 2017-08-17
    v_Discount_Type_Value Varchar2(128);
  Begin
    p_Result := v_Success;
    p_Message := v_Success;
    v_Discount_Type_Value := IN_DISCOUNT_TYPE;
    Begin
      Select *
        Into r_Order_Type
        From t_Pln_Order_Type Ot
       Where Ot.Order_Type_Id = p_Order_Type_Id;
    Exception
      When Others Then
        p_Result  := v_Failure;
        p_Message := '获取订单单据类败！单据类型ID：' || To_Char(p_Order_Type_Id) || v_Nl ||
                     Sqlerrm;
        Raise V_CCS_EXCEPTION;
    End;
    --add by lizhen 2016-05-17不锁款时，不检查到款余额
    --20180706 hejy3 非送审锁款直接返回成功
    If Nvl(r_Order_Type.Chk_Cusg_Amount_Flag, 'N') not in ('S', 'RS') Then
      p_Result := v_Success;
      p_Message := v_Success;
      Return;
    End If;
    
   --20170601 hejy3 获取订金控制参数
   v_Order_Amount := p_Amount;
   v_Order_Dis_Amount := p_Discount_Amount;
   
    Begin
      v_Cre_Dis_Type_Enable_Flag := Pkg_Bd.f_Get_Parameter_Value('CRE_DIS_TYPE_ENABLE',
                                                                 r_Order_Type.Entity_Id);
    Exception
      When Others Then
        p_Result := '获取CRE_DIS_TYPE_ENABLE参数失败！' || v_Nl || Sqlerrm;
        Raise v_Ccs_Exception;
    End;
   
   if r_Order_Type.Chk_Cusg_Amount_Flag = 'S' THEN
     Begin
       Select Pkg_Bd.f_Get_Parameter_Value(p_Config_Code => 'CREDIT_DOWN_PAY_SCALE',
                                           p_Entity_Id   => r_Order_Type.Entity_Id)
         Into v_Param_Down_Pay_Rate
         From Dual;
     Exception
       When Others Then
         p_Result := '获取主体参数失败，系统参数编码【CREDIT_DOWN_PAY_SCALE】';
         Raise V_CCS_EXCEPTION;
     End;
     
     --if v_Param_Down_Pay_Rate is null then --未启用订金控制按100%检查
     --  v_Order_Down_Pay_Rate := 100;
     --else
     v_Down_Pay_Tip := true;
     --获取中心ID
     BEGIN
       SELECT s.sales_center_id into v_Sales_Center_Id
         FROM V_CUSTOMER_ACCOUNT_SALECENTER S
        WHERE S.entity_id = r_Order_Type.Entity_Id
          AND S.account_id = p_Account_Id
          AND S.customer_id = p_Customer_Id
          AND S.active_flag = v_Active
          and s.account_status = v_Account_Active;
     exception
       when others then
         p_Result := '根据客户和账户获取中心失败！' || v_Nl ||
                  ' 客户ID：' || To_Char(p_Customer_Id) ||
                  ' 账户ID：' || To_Char(p_Account_Id);
         raise V_CCS_EXCEPTION;
     END;
       
     --获取订金比例
     BEGIN
       SELECT L.DOWN_PAY_RATE INTO v_Order_Down_Pay_Rate
         FROM T_CREDIT_ACCOUNT_LIMIT L
        WHERE L.ENTITY_ID = r_Order_Type.Entity_Id
          AND L.CUSTOMER_ID = p_Customer_Id
          AND L.SALES_CENTER_ID = v_Sales_Center_Id
          AND L.ACCOUNT_ID = p_Account_Id;
      EXCEPTION
        WHEN NO_DATA_FOUND Then
          --modi by lizhen 2017-08-24信用未找到订金比率配置则取主体参数，主体参数设置为NULL时，取100
          If v_Param_Down_Pay_Rate Is Null Then
	    v_Down_Pay_Tip := False;
            v_Order_Down_Pay_Rate := 100;
          Else
            --使用参数值
            v_Order_Down_Pay_Rate := v_Param_Down_Pay_Rate;
          End If;
     END;
     --end if;
   else
     v_Order_Down_Pay_Rate := 100;
   END IF;
   
   --订金比例为0直接返回
   if v_Order_Down_Pay_Rate = 0 then
     p_Result := v_Success;
     p_Message := v_Success;
     Return;
   end if;
   
   v_Order_Amount := v_Order_Amount * v_Order_Down_Pay_Rate / 100;
   v_Order_Dis_Amount := v_Order_Dis_Amount * v_Order_Down_Pay_Rate / 100;
   
   If v_Discount_Type_Value In ('ALL', 'COMMON') Then
     --modi by lizhen 2017-08-22 取用 折让到款的主体未传参数时，先检查常规款项，然后再检查折让款项
     If v_Cre_Dis_Type_Enable_Flag = 'Y' Then
       v_Discount_Type_Value := 'COMMON';
     End If;
     
      --获取客户账户的到款余额
      v_Credit_Amount := Pkg_Credit_Tools.Fun_Get_Amount(p_Entity_Id       => r_Order_Type.Entity_Id,
                                                         p_Customer_Id     => p_Customer_Id,
                                                         p_Account_Id      => p_Account_Id,
                                                         p_Sales_Main_Type => p_Sales_Main_Type,
                                                         p_Flag            => 1,
                                                         IS_DISCOUNT_TYPE  => v_Discount_Type_Value);
      
      If /*p_Amount*/v_Order_Amount > Nvl(v_Credit_Amount, 0) Then
        p_Result := v_Failure;
        if v_Down_Pay_Tip then
          p_Message := '检查客户到款可提货金额:本次提货金额【' || To_Char(p_Amount) || '】' ||
            '，订金比例【'||to_char(v_Order_Down_Pay_Rate)||'】' || '，订金金额【'||to_char(v_Order_Amount)||'】'||
            '> 到款可提货金额【' || To_Char(Nvl(v_Credit_Amount, 0)) || '】' ||
            '，到款可提货余额不足！';
        else
          p_Message := '检查客户到款可提货金额:本次提货金额【' || To_Char(/*p_Amount*/v_Order_Amount) || '】' ||
            '> 到款可提货金额【' || To_Char(Nvl(v_Credit_Amount, 0)) || '】' ||
            '，到款可提货余额不足！';
        end if;
        Raise V_CCS_EXCEPTION;
      End If;
      --获取客户账户的到款折扣余额
      v_Credit_Discount_Amount := Pkg_Credit_Tools.Fun_Get_Amount(p_Entity_Id       => r_Order_Type.Entity_Id,
                                                                  p_Customer_Id     => p_Customer_Id,
                                                                  p_Account_Id      => p_Account_Id,
                                                                  p_Sales_Main_Type => p_Sales_Main_Type,
                                                                  p_Flag            => 2,
                                                                  IS_DISCOUNT_TYPE  => 'COMMON');
      If Nvl(/*p_Discount_Amount*/v_Order_Dis_Amount, 0) <> 0 And
         /*p_Discount_Amount*/v_Order_Dis_Amount > Nvl(v_Credit_Discount_Amount, 0) Then
        p_Result := v_Failure;
        if v_Down_Pay_Tip then
          p_Message := '检查客户到款可用折扣金额:本次提货折扣金额【' || To_Char(p_Discount_Amount) || '】' ||
            '，订金比例【'||to_char(v_Order_Down_Pay_Rate)||'】' || '，订金折扣金额【'||to_char(v_Order_Dis_Amount)||'】'||
            '> 到款可提货折扣金额【' || To_Char(Nvl(v_Credit_Discount_Amount, 0)) || '】' ||
            '，到款可提货折扣余额不足！';
        else
          p_Message := '检查客户到款可用折扣金额:本次提货折扣金额【' || To_Char(/*p_Discount_Amount*/v_Order_Dis_Amount) || '】' ||
            '> 到款可提货折扣金额【' || To_Char(Nvl(v_Credit_Discount_Amount, 0)) || '】' ||
            '，到款可提货折扣余额不足！';
        end if;
        Raise V_CCS_EXCEPTION;
      End If;
    End If;
    
    --add by lizhen 2017-08-17客户常规款项不足时检查折让到款余额
    If (p_Result != v_Success And v_Discount_Type_Value = 'ALL') Or v_Discount_Type_Value = 'DISCOUNT' Then
      p_Result := v_Success;
      p_Message := v_Success;
      If v_Cre_Dis_Type_Enable_Flag != 'Y' Then
        Return;
      End If;
      --获取客户账户的到款余额
      v_Credit_Amount := Pkg_Credit_Tools.Fun_Get_Amount(p_Entity_Id       => r_Order_Type.Entity_Id,
                                                         p_Customer_Id     => p_Customer_Id,
                                                         p_Account_Id      => p_Account_Id,
                                                         p_Sales_Main_Type => p_Sales_Main_Type,
                                                         p_Flag            => 1,
                                                         IS_DISCOUNT_TYPE  => 'DISCOUNT');
      
      If v_Order_Amount + Nvl(v_Order_Dis_Amount, 0) > Nvl(v_Credit_Amount, 0) Then
        p_Result := v_Failure;
        if v_Down_Pay_Tip then
          p_Message := '检查客户折让到款可提货金额:本次提货金额【' || To_Char(p_Amount) || '】' ||
            '，订金比例【'||to_char(v_Order_Down_Pay_Rate)||'】' || '，订金金额【'||to_char(v_Order_Amount + Nvl(v_Order_Dis_Amount, 0))||'】'||
            '> 折让到款可提货金额【' || To_Char(Nvl(v_Credit_Amount, 0)) || '】' ||
            '，折让到款可提货余额不足！';
        else
          p_Message := '检查客户折让到款可提货金额:本次提货金额【' || To_Char(v_Order_Amount + Nvl(v_Order_Dis_Amount, 0)) || '】' ||
            '> 折让到款可提货金额【' || To_Char(Nvl(v_Credit_Amount, 0)) || '】' ||
            '，折让到款可提货余额不足！';
        end if;
        If IN_DISCOUNT_TYPE = 'ALL' Then
          p_Message := '检查客户常规到款、折让到款可提货金额都不满足本次提货订单金额。';
        End If;
        Raise V_CCS_EXCEPTION;
      End If;
    End If;
  Exception
    When v_ccs_EXCEPTION Then
      p_Result  := v_Failure;
      p_Message := p_Message;
    When Others Then
      p_Result  := v_Failure;
      p_Message := p_Message || v_Nl || Sqlerrm;
  End;
  
  -----------------------------------------------------------------------------
  -- AUTHOR  : Nicro.Li
  -- CREATED : 2016-04-05
  -- PURPOSE : 根据产品、单据送审类型获取产品的库存可用量（符合条件仓库的汇总）
  -----------------------------------------------------------------------------                                      
  Function f_Get_Lgorder_Noship_Qty(p_Entity_Id In Number, ----主体ID
                                    p_Item_Code   In Varchar2, --产品编码
                                    p_Order_Submit_Type In Varchar2, --单据送审类型
                                    p_User_Code In Varchar2 --用户编码
                                    ) Return Number Is
  v_Item_Id     Number;
  Begin
    Select Tbi.Item_Id
      Into v_Item_Id
      From t_Bd_Item Tbi
     Where Tbi.Item_Code = p_Item_Code
       And Tbi.Entity_Id = p_Entity_Id;
       
    Return Pkg_Pln_Pub.f_Get_Lgorder_Noship_Qty(p_Entity_Id => p_Entity_Id,
                                                p_Item_Id   => v_Item_Id,
                                                p_Order_Submit_Type => p_Order_Submit_Type, --单据送审类型
                                                p_User_Code => p_User_Code);
  Exception
    When Others Then
      Return 0;
  End;
  
  -----------------------------------------------------------------------------
  -- AUTHOR  : Nicro.Li
  -- CREATED : 2016-04-05
  -- PURPOSE : 根据产品、单据送审类型获取产品的库存可用量（符合条件仓库的汇总）
  --           CCS获取总部评审时，获取数据 总部产能可视预计可用数量
  -----------------------------------------------------------------------------
  Function f_Get_Item_Usable_Qty(p_Entity_Id         In Number, ----主体ID
                                 p_Item_Code         In Varchar2, --产品编码
                                 p_Order_Submit_Type In Varchar2, --单据送审类型
                                 p_Sales_Center_Id   In Number, --营销中心ID
                                 p_Lg_Order_Noship   In Varchar2, --是否扣减已评未发货数量  Y:扣减  N:不扣减
                                 p_Producing_Area_Id In Number, ----产地ID
                                 p_User_Code         In Varchar2)
    Return Number Is
    v_Item_Id     Number;
    v_Org_Id      Number;
  Begin
    Select Tbi.Item_Id
      Into v_Item_Id
      From t_Bd_Item Tbi
     Where Tbi.Item_Code = p_Item_Code
       And Tbi.Entity_Id = p_Entity_Id;
    If p_Order_Submit_Type = 'HQ_TYPE' Then   
      Select Pa.Mrp_Org_Id
        Into v_Org_Id
        From t_Pln_Producing_Area Pa
       Where Pa.Producing_Area_Id = p_Producing_Area_Id;
         
      Return Pkg_Pln_Pub.f_Get_Item_Usable_Qty(p_Entity_Id         => p_Entity_Id,
                                               p_Item_Id           => v_Item_Id,
                                               p_Order_Submit_Type => p_Order_Submit_Type,
                                               p_Sales_Center_Id   => p_Sales_Center_Id,
                                               p_Lg_Order_Noship   => p_Lg_Order_Noship,
                                               p_User_Code         => p_User_Code) +
       Pkg_Pln_Intf_Aps.f_Get_Item_Capacity_Qty(p_Organization_Id => v_Org_Id,
                                                p_Item_Code       => p_Item_Code);
    Else
      Return Pkg_Pln_Pub.f_Get_Item_Usable_Qty(p_Entity_Id         => p_Entity_Id,
                                               p_Item_Id           => v_Item_Id,
                                               p_Order_Submit_Type => p_Order_Submit_Type,
                                               p_Sales_Center_Id   => p_Sales_Center_Id,
                                               p_Lg_Order_Noship   => p_Lg_Order_Noship,
                                               p_User_Code         => p_User_Code);
    End If;
  Exception
    When Others Then
      Return 0;
  End;
  
  -----------------------------------------------------------------------------
  -- AUTHOR  : Nicro.Li
  -- CREATED : 2016-04-12
  -- PURPOSE : 根据产品、产地ID获取APS剩余产能
  -----------------------------------------------------------------------------
  Function f_Get_Item_Capacity_Qty(p_Producing_Area_Id In Number, ----产地ID
                                   p_Item_Code         In Varchar2 --产品编码
                                   ) Return Number Is
    v_Org_Id Number;
  Begin
    Select Pa.Mrp_Org_Id
      Into v_Org_Id
      From t_Pln_Producing_Area Pa
     Where Pa.Producing_Area_Id = p_Producing_Area_Id;
    Return Pkg_Pln_Intf_Aps.f_Get_Item_Capacity_Qty(p_Organization_Id => v_Org_Id,
                                                    p_Item_Code       => p_Item_Code);
  Exception
    When Others Then
      Return 0;
  End;
  
  -----------------------------------------------------------------------------
  -- AUTHOR  : Nicro.Li
  -- CREATED : 2016-05-05
  -- PURPOSE : 根据返回提货订单行的产能可视可满足数量
  -----------------------------------------------------------------------------
  Function f_Get_Line_Capacity_Qty(p_Order_Line_Id     In Number, --提货订单行ID
                                   p_Order_Submit_Type In Varchar2, --单据送审类型
                                   p_Sales_Center_Id   In Number, --营销中心ID
                                   p_Lg_Order_Noship   In Varchar2, --是否扣减已评未发货数量  Y:扣减  N:不扣减                                                    
                                   p_User_Code         In Varchar2 --用户编码
                                   ) Return Number Is
    r_Order_Line t_Pln_Lg_Order_Line%Rowtype;    
  Begin
    Begin
      Select *
        Into r_Order_Line
        From t_Pln_Lg_Order_Line Lol
       Where Lol.Order_Line_Id = p_Order_Line_Id;
    Exception
      When Others Then
        Return Null;
    End;
    
    Return Pkg_Pln_Pub.f_Get_Item_Usable_Qty(p_Entity_Id         => r_Order_Line.Entity_Id,
                                             p_Item_Id           => r_Order_Line.Item_Id,
                                             p_Order_Submit_Type => p_Order_Submit_Type,
                                             p_Sales_Center_Id   => p_Sales_Center_Id,
                                             p_Lg_Order_Noship   => p_Lg_Order_Noship,
                                             p_User_Code         => p_User_Code) +
       Nvl(r_Order_Line.Aps_Capacity_Rec_Qty, 0);
  Exception
    When Others Then
      Return Null;
  End;
  
  -----------------------------------------------------------------------------
  -- AUTHOR  : Nicro.Li
  -- CREATED : 2016-05-11
  -- PURPOSE : 返回提货订单行的产能可视未满足数量
  -----------------------------------------------------------------------------
  Function f_Get_Line_NotCapacity_Qty(p_Order_Line_Id     In Number  --提货订单行ID
                                     ) Return Number Is
    r_Order_Line t_Pln_Lg_Order_Line%Rowtype;    
  Begin
    Begin
      Select *
        Into r_Order_Line
        From t_Pln_Lg_Order_Line Lol
       Where Lol.Order_Line_Id = p_Order_Line_Id;
    Exception
      When Others Then
        Return Null;
    End;
    Return Abs(Nvl(r_Order_Line.Aps_Capacity_Rec_Qty, 0) - Nvl(r_Order_Line.To_Aps_Capacity_Qty, 0));
  Exception
    When Others Then
      Return Null;
  End;
  
  -----------------------------------------------------------------------------
  -- AUTHOR  : Nicro.Li
  -- CREATED : 2016-05-21
  -- PURPOSE : 提货订单送审完成后，提交APS处理产能可视请求
  -----------------------------------------------------------------------------
  Procedure p_Submit_Aps_Capacity_Request(p_Lg_Order_Head_Id In Number,  --提货订单头ID
                                          p_Result           Out Varchar2 --返回错误信息
                                          ) Is
    v_Request_Id           Number;
    v_Batch_Id             Number;
    v_Entity_Code          Varchar2(32);
    v_Pln_Capacity_Aps     Varchar2(32);
    v_Pln_Aps_Auto_Request Varchar2(32);
    v_Err_Msg              Varchar2(4000);
    r_Lg_Head              t_Pln_Lg_Order_Head%Rowtype;
    r_Order_Type           t_pln_order_type%Rowtype;
    v_Pln_Capacity_Modle    Varchar2(32);
    v_msg varchar2(2000);
  Begin
    p_Result := v_Success;
    Begin
      Select *
        Into r_Lg_Head
        From t_Pln_Lg_Order_Head Oh
       Where Oh.Order_Head_Id = p_Lg_Order_Head_Id;
         --For Update Nowait;  modi by lizhen 2016-08-10
    Exception
      When Others Then
        p_Result := '订单头锁定数据失败。' || v_Nl || '订单头ID：' || p_Lg_Order_Head_Id || v_Nl ||
                    Sqlerrm;
        Raise v_Ccs_Exception;
    End;
    --add by lizhen 2016-05-19 
    --获取系统参数是否启用产能可视
    Begin
      v_Pln_Capacity_Aps := Pkg_Bd.f_Get_Parameter_Value('PLN_CAPACITY_APS', r_Lg_Head.Entity_Id);
    Exception
      When Others Then
        p_Result := '获取是否使用APS产能可视参数PLN_CAPACITY_APS参数失败！' || v_Nl || Sqlerrm;
        Raise v_Ccs_Exception;
    End;
    --add by lizhen 2016-05-20
    --引APS产能可视是否自动提交APS产能可视处理请求
    Begin
      v_Pln_Aps_Auto_Request := Pkg_Bd.f_Get_Parameter_Value('PLN_CAPACITY_APS_AUTO_REQUEST',
                                                                      r_Lg_Head.Entity_Id);
    Exception
      When Others Then
        p_Result := '获取自动提交APS产能可视请求参数PLN_CAPACITY_APS_AUTO_REQUEST参数失败！' || v_Nl || Sqlerrm;
        Raise v_Ccs_Exception;
    End;
    
    --add by lizhen 2016-12-28
    --获取系统参数产能可视模式参数
    Begin
      v_Pln_Capacity_Modle := Pkg_Bd.f_Get_Parameter_Value('PLN_CAPACITY_MODEL', r_Lg_Head.Entity_Id);
    Exception
      When Others Then
        p_Result := '获取产能可视模式参数PLN_CAPACITY_MODEL参数失败！' || v_Nl || Sqlerrm;
        Raise v_Ccs_Exception;
    End;
    If v_Pln_Capacity_Modle = 'CIMS' Then
      Return;
    End If;
    
    Begin
      Select Ue.Entity_Code_Name
        Into v_Entity_Code
        From Up_Codelist Up, Up_Codelist_Entity Ue
       Where Up.Codetype = 'PlnEntityToMainEntity'
         And Up.Id = Ue.Codelist_Id
         And Ue.Entity_Id = r_Lg_Head.Entity_Id;
    Exception
      When No_Data_Found Then
        Begin
          Select Entity.Entity_Code
            Into v_Entity_Code
            From v_Bd_Entity Entity
           Where Entity.Entity_Id = r_Lg_Head.Entity_Id;
        Exception
          When Others Then
            p_Result := '获取主体编码失败，主体ID：' || To_Char(r_Lg_Head.Entity_Id) || Sqlerrm;
            Raise v_Ccs_Exception;
        End;
      When Others Then
        p_Result := '获取主体失败,主体快码PlnEntityToMainEntity' || Sqlerrm;
        Raise v_Ccs_Exception;
    End;
    
    --查找单据类型
    Select *
      Into r_Order_Type
      From t_Pln_Order_Type Ot
     Where Ot.Order_Type_Id = r_Lg_Head.Order_Type_Id;
    
    --add by lizhen 2016-05-19 提交APS产能可视运行请求致APS系统
    --20180209 hejy3 改用订单类型的产能可视标识控制 
    If r_Order_Type.Lg_Order_Submit_Type = 'HQ_TYPE' and r_Order_Type.Is_Pln_Capacity = 'Y' And
       v_Pln_Capacity_Aps = 'Y' And Nvl(v_Pln_Aps_Auto_Request, 'N') = 'Y' And
       r_Lg_Head.Batch_Id Is Not Null Then
      v_msg := substr('单号='||r_Lg_Head.Order_Number||'请求APS产能可视接口开始',1,1333);
      v_msg := pkg_bd.F_ADD_ERROR_LOG('Aps_Pre_Cal_Resource_Pub.Main_Out','000000',v_msg);
      Aps_Pre_Cal_Resource_Pub.Main_Out(p_Bu_Code    => v_Entity_Code,
                                        p_Batch_Id   => r_Lg_Head.Batch_Id,
                                        x_Status     => p_Result, /*X_STATUS:'SUCCESS:成功', 'ERROR:失败'*/
                                        x_Msg_Data   => v_Err_Msg,
                                        x_Request_Id => v_Request_Id);
      v_msg := substr('单号='||r_Lg_Head.Order_Number||'请求APS产能可视接口结束,p_Batch_Id='||to_char(r_Lg_Head.Batch_Id)||',x_Status='||
               p_Result||',x_Msg_Data='||v_Err_Msg||',x_Request_Id='||to_char(v_Request_Id),1,1333);
      v_msg := pkg_bd.F_ADD_ERROR_LOG('Aps_Pre_Cal_Resource_Pub.Main_Out','000000',v_msg);
      If Nvl(p_Result, '_') <> v_Success Then
        Begin
          Insert Into Intf_Pln_Order_Capacity_Rec
            (Order_Capacity_Id,
             Batch_Id,
             Entity_Code,
             Organization_Id,
             Order_Number,
             Order_Line_Id,
             Order_Line_Number,
             Order_Schedule_Success,
             Capacity_Qty,
             Pre_Field_01,
             Pre_Field_02,
             Pre_Field_03,
             Pre_Field_04,
             Pre_Field_05,
             Pre_Field_06,
             Intf_State,
             Intf_Error_Msg,
             Created_By,
             Creation_Date,
             Last_Updated_By,
             Last_Update_Date,
             Trx_No)
          Select s_Intf_Pln_Order_Capacity_Rec.Nextval,
                 r_Lg_Head.Batch_Id,
                 v_Entity_Code Entity_Code,
                 Ppa.Mrp_Org_Id Organization_Id,
                 Loh.Order_Number,
                 Lol.Order_Line_Id,
                 Rownum Order_Line_Number,
                 'Y' Order_Schedule_Success,
                 0 Capacity_Qty,
                 Null Pre_Field_01,
                 Null Pre_Field_02,
                 Null Pre_Field_03,
                 Null Pre_Field_04,
                 Null Pre_Field_05,
                 Null Pre_Field_06,
                 'N' Intf_State,
                 'APS请求处理失败，CIMS系统把本批次提交数据当产能不足处理' Intf_Error_Msg,
                 'CIMS' Created_By,
                 Sysdate Creation_Date,
                 'CIMS' Last_Updated_By,
                 Sysdate Last_Update_Date,
                 'APS-IMS-014' Trx_No
            From t_Pln_Lg_Order_Head  Loh,
                 t_Pln_Lg_Order_Line  Lol,
                 t_Pln_Producing_Area Ppa
           Where Loh.Order_Head_Id = Lol.Order_Head_Id
             And Loh.Order_Head_Id = p_Lg_Order_Head_Id
             And Ppa.Producing_Area_Id = Lol.Producing_Area_Id
             And Not Exists
           (Select 1
                    From Intf_Pln_Order_Capacity_Rec Ocr
                   Where Ocr.Batch_Id = r_Lg_Head.Batch_Id
                     And Ocr.Entity_Code = v_Entity_Code
                     And Ocr.Order_Number = Loh.Order_Number
                     And Ocr.Order_Line_Id = Lol.Order_Line_Id);
        Exception
          When Others Then
            p_Result := '提交APS处理产能可视请求失败，写CIMS接收接口失败！' || v_Nl || 
                    'APS请求号：' || v_Request_Id || v_Nl ||
                    'APS错误信息：' || v_Err_Msg || v_Nl || Sqlerrm;
            Raise v_Ccs_Exception;
        End;
        /*p_Result := '提交APS处理产能可视请求失败！' || v_Nl || 
                    'APS请求号：' || v_Request_Id || v_Nl ||
                    'APS错误信息：' || v_Err_Msg;
        Raise v_Ccs_Exception;*/
      End If;
      --APS请求执行完成后，回写CIMS接口表，CIMS处理接口表数据
      Pkg_Pln_Intf_Aps.p_Capacity_Receiver_Pro(p_Batch_Id    => r_Lg_Head.Batch_Id,
                                               p_Entity_Code => v_Entity_Code,
                                               p_Result      => p_Result);
      If p_Result <> v_Success Then
        Raise v_Ccs_Exception;
      End If;
    End If;
  Exception
    When v_Ccs_Exception Then
      p_Result := p_Result;
      Rollback;
    When Others Then
      Rollback;
      p_Result := p_Result || v_Nl || Sqlerrm;
  End;
  
  -----------------------------------------------------------------------------
  -- AUTHOR  : Nicro.Li
  -- CREATED : 2016-05-24
  -- PURPOSE : CCS已引APS产能可视的订单状态关闭订单
  -----------------------------------------------------------------------------
  Procedure p_Close_Lgorder_Capacity(p_Lg_Order_Head_Id In Number, --提货订单头ID
                                     p_Result           In Out Varchar2 --关闭订单原因，成功（SUCCESS) 失败返回错误信息
                                     ) Is
    r_Lgorder_Head t_Pln_Lg_Order_Head%Rowtype;
  Begin
    Begin
      Select Loh.Order_Head_State, Loh.Aps_Capacity_State
        Into r_Lgorder_Head.Order_Head_State,
             r_Lgorder_Head.Aps_Capacity_State
        From t_Pln_Lg_Order_Head Loh
       Where Loh.Order_Head_Id = p_Lg_Order_Head_Id;
    Exception
      When Others Then
        p_Result := '获取提货订单头信息失败';
        Raise v_Ccs_Exception;
    End;
    If Not (r_Lgorder_Head.Order_Head_State = '2225' And Nvl(r_Lgorder_Head.Aps_Capacity_State, 'N') = 'S') Then
      p_Result := '提货订单状态不正确，只有“已引APS产能可视”且“处理完成”的提货订单才允许关闭！';
      Raise v_Ccs_Exception;
    End If;
    Pkg_Pln_Lg_Order.p_Execute_Lgorder_Operate(p_Order_Head_Id    => p_Lg_Order_Head_Id,
                                               p_Operation_Action => '关闭',
                                               p_Next_State       => '304',
                                               p_User_Code        => 'CCS_INTF',
                                               p_Result           => p_Result);
  Exception
    When v_Ccs_Exception Then
      Rollback;
      p_Result := p_Result || v_Nl ||
                  'Pkg_Pln_Intf_CCs.p_Close_LgOrder_Capacity过程失败。';
    When Others Then
      Rollback;
      p_Result := p_Result || v_Nl ||
                  'Pkg_Pln_Intf_CCs.p_Close_LgOrder_Capacity过程失败。';
  End;
  
  ------------------------------------------------------------------------------------------
  ---- AUTHOR  : Nicro.Li
  -- CREATED : 2016-06-29
  -- PURPOSE : 提货订单产能可视检查、产能不足时方法默认返回成功，但会同时返回产可视异常信息
  ------------------------------------------------------------------------------------------
  Procedure p_Chk_Item_Capacity(p_Entity_Id     In Number, --主体ID
                                p_Param_Id      In Number, ----检查产能数集ID
                                p_User_Code     In Varchar2, ----用户ID
                                p_Result        In Out Varchar2, --成功则反回 SUCCESS 失败则返回失败原因
                                p_Chk_Msg       In Out Varchar2 --产能检查不通过时返回错误信息
                                ) Is
    Cursor c_Chk_Param Is
      Select * From t_Pln_Capacity_Chk_Param cp
      Where cp.param_id = p_Param_Id 
        And cp.entity_id = p_Entity_Id;                             
    r_Chk_Param      c_Chk_Param%Rowtype;
    v_Inv_Can_Used Number := 0; --库存可用量
    v_Meet_An_Order_Qty Number := 0; --备货订单数量 
    v_Aps_Residual_Capacity Number := 0; --APS剩余产能
    v_Organization_Id       Number := 0;   
    v_Err_Msg               Varchar2(4000);  
    v_Pln_Capacity_Aps      VARCHAR2(32);   --产能可视启用标识
    v_Item_Id               Number;
    v_Lg_Order_Submit_Type  t_Pln_Order_Type.Lg_Order_Submit_Type%Type;                       
    v_Pln_Capacity_Modle    Varchar2(32);
    v_Pln_Capacity_Advance_Period  Number;
    v_Period_Id                    Number;  
    v_Count                        Number;
    v_Msg_End                      varchar2(100);
    v_CAPACITY_STRICT_FLAG         varchar2(100);
    V_ORDER_TYPE_CAPACITY T_PLN_ORDER_TYPE.IS_PLN_CAPACITY%TYPE;                     
  Begin
    p_Result := v_Success;
    p_Chk_Msg := Null;
    
    --获取系统参数是否启用产能可视
    Begin
      v_Pln_Capacity_Aps := Pkg_Bd.f_Get_Parameter_Value('PLN_CAPACITY_APS', p_Entity_Id);
    Exception
      When Others Then
        p_Result := '获取是否使用APS产能可视参数PLN_CAPACITY_APS参数失败！' || v_Nl || Sqlerrm;
        Raise v_Ccs_Exception;
    End;
    If Nvl(v_Pln_Capacity_Aps, 'N') != 'Y' Then
      Return;
    End If;
    
    --add by lizhen 2016-12-07
    --获取系统参数产能可视模式参数
    Begin
      v_Pln_Capacity_Modle := Pkg_Bd.f_Get_Parameter_Value('PLN_CAPACITY_MODEL', p_Entity_Id);
    Exception
      When Others Then
        p_Result := '获取产能可视模式参数PLN_CAPACITY_MODEL参数失败！' || v_Nl || Sqlerrm;
        Raise v_Ccs_Exception;
    End;
    
    --获取产能可视严控标识 add by ex_dengjh
    Begin
      v_CAPACITY_STRICT_FLAG := Pkg_Bd.f_Get_Parameter_Value('PLN_CAPACITY_STRICT_FLAG', p_Entity_Id);
    Exception
      When Others Then
        p_Result := '获取产能可视严控标识PLN_CAPACITY_STRICT_FLAG参数失败！' || v_Nl || Sqlerrm;
        Raise v_Ccs_Exception;
    End;
    
    /*If Nvl(v_Pln_Capacity_Aps, 'N') != 'Y' Then
      Return;
    End If;*/
    Open c_Chk_Param;    
    
    --校验提货订单申请量是否大于库存可用量加上APS剩余产能
    v_Err_Msg := Null;
    Loop
      Fetch c_Chk_Param Into r_Chk_Param;
      If c_Chk_Param%Rowcount = 0 Then
        p_Result := '获取参数失败，参数集表无数据。参数集ID:' ||
                      To_Char(p_Param_Id);
        Raise v_Ccs_Exception;
      End If;
      Exit When c_Chk_Param%Notfound;
      --获取组织ID
      Begin
        Select Tpa.Mrp_Org_Id
          Into v_Organization_Id
          From t_Pln_Producing_Area Tpa
         Where Tpa.Producing_Area_Id = r_Chk_Param.Producing_Area_Id;
      Exception
        When Others Then
          p_Result := '获取组织ID失败,产地ID:' ||
                      To_Char(r_Chk_Param.Producing_Area_Id) || v_Nl || Sqlerrm;
          Raise v_Ccs_Exception;
      End;      
      
      --提货订单据类型
      Begin
        Select Ot.Lg_Order_Submit_Type, ot.is_pln_capacity
          Into v_Lg_Order_Submit_Type, V_ORDER_TYPE_CAPACITY
          From t_Pln_Order_Type Ot
         Where Ot.Order_Type_Id = r_Chk_Param.Order_Type_Id;
      Exception
        When Others Then
          p_Result := '获取订单单据类型失败,单据类型ID:' ||
                      To_Char(r_Chk_Param.Order_Type_Id) || v_Nl || Sqlerrm;
          Raise v_Ccs_Exception;
      End;
      
      --单据类型不做产能可视直接返回
      if nvl(V_ORDER_TYPE_CAPACITY, 'N') <> 'Y' then
        return;
      end if;
      
      if v_Pln_Capacity_Modle <> 'APS-CIMS' and nvl(v_Lg_Order_Submit_Type, 'COMPOSITE_TYPE') <> 'HQ_TYPE' THEN
        return;
      END IF;
      
      Begin
        Select Bi.Item_Id
          Into v_Item_Id
          From t_Bd_Item Bi
         Where Bi.Item_Code = r_Chk_Param.Item_Code
           And Bi.Entity_Id = r_Chk_Param.Entity_Id;
      Exception
        When Others Then
          p_Result := '获取产品信息失败，产品编码:' ||
                      To_Char(r_Chk_Param.Item_Code) || v_Nl || Sqlerrm;
          Raise v_Ccs_Exception;
      End;
    
      --获取库存可用量
      --add by lizhen 2016-12-07增加产能可视模式检查
      If v_Pln_Capacity_Modle = 'APS' Then
	      v_Inv_Can_Used := Pkg_Pln_Pub.f_Get_Item_Usable_Qty(p_Entity_Id         => r_Chk_Param.Entity_Id,
	                                                          p_Item_Id           => v_Item_Id,
	                                                          p_Order_Submit_Type => v_Lg_Order_Submit_Type,
	                                                          p_Sales_Center_Id   => 0,
	                                                          p_Lg_Order_Noship   => 'Y',
	                                                          p_User_Code         => p_User_Code);
	      --获取APS剩余产能                                                            
	      v_Aps_Residual_Capacity := Pkg_Pln_Intf_Aps.f_Get_Item_Capacity_Qty(p_Organization_Id => v_Organization_Id,
	                                                                          p_Item_Code       => r_Chk_Param.Item_Code);
      elsif v_Pln_Capacity_Modle = 'APS-CIMS' then
        v_Inv_Can_Used := 0;
        --获取APS剩余产能                                                            
        v_Aps_Residual_Capacity := Pkg_Pln_Intf_Aps.f_Get_Item_Capacity_Qty(p_Organization_Id => v_Organization_Id,
                                                                            p_Item_Code       => r_Chk_Param.Item_Code);
      Else
        --获取默设计的订单周期
        v_Count := 1;
        v_Inv_Can_Used := 0;
        Begin
          Select Ipc.Item_Curr_Capacity_Qty
            Into v_Aps_Residual_Capacity
            From v_Pln_Item_Period_Capacity Ipc
           Where Ipc.Entity_Id = r_Chk_Param.Entity_Id
             And Ipc.Item_Code = r_Chk_Param.Item_Code
             And Ipc.Producing_Area_Id = r_Chk_Param.Producing_Area_Id
             And Ipc.Period_Id = Case
                   When Pkg_Bd.f_Get_Parameter_Value(p_Config_Code => 'PLN_CAPACITY_PERIOD_TYPE',
                                                     p_Entity_Id   => Ipc.Entity_Id) = 'M' Then
                    (Select Min(Pac.Period_Id)
                       From t_Pln_Assenbly_Capacity Pac
                      Where Pac.Entity_Id = Ipc.Entity_Id
                        And (Select Op.Begin_Date
                               From t_Pln_Order_Period Op
                              Where Op.Period_Id =
                                    Pkg_Pln_Capacity.f_Get_Parameter_Month_Period(p_Entity_Id   => Ipc.Entity_Id,
                                                                                  p_Period_Type => 'W',
                                                                                  p_Date        => Trunc(Sysdate))) Between
                            Pac.Begin_Date And Pac.End_Date)
                   Else
                    Pkg_Pln_Capacity.f_Get_Parameter_Month_Period(Ipc.Entity_Id,
                                                                  'W',
                                                                  Trunc(Sysdate))
                 End;
          /*Select Iwc.Item_Week_Capacity_Qty
            Into v_Aps_Residual_Capacity
            From v_Pln_Item_Week_Capacity Iwc
           Where Iwc.Item_Code = r_Chk_Param.Item_Code
             And Iwc.Producing_Area_Id = r_Chk_Param.Producing_Area_Id
             And Iwc.Period_Id = v_Period_Id
             And Iwc.Entity_Id = r_Chk_Param.Entity_Id;*/
        Exception
          When No_Data_Found Then
            --未查找到产能设置，表示该产品不做产能检查，把数据设置成特别大
            v_Aps_Residual_Capacity := 9999999999;
          When Others Then
            p_Result := '获取产品剩余产能失败！' || v_Nl || 
                        '产品编码：' || r_Chk_Param.Item_Code || v_Nl || Sqlerrm;
            Raise v_Ccs_Exception;
        End;
      End If;
      If r_Chk_Param.Apply_Qty > v_Inv_Can_Used Then
        If r_Chk_Param.Apply_Qty - v_Inv_Can_Used > v_Aps_Residual_Capacity  Then
          If v_Err_Msg Is Null Then
            v_Err_Msg := '产品编码为【' || r_Chk_Param.Item_Code || '】的申请数量【' ||
                         r_Chk_Param.Apply_Qty || '】> 产品可用量【' ||
                         v_Inv_Can_Used || '】+APS剩余产能【' ||
                         v_Aps_Residual_Capacity || '】';
          Else
            v_Err_Msg := v_Err_Msg || v_Nl || '产品编码为【' ||
                         r_Chk_Param.Item_Code || '】的申请数量【' ||
                         r_Chk_Param.Apply_Qty || '】> 产品可用量【' ||
                         v_Inv_Can_Used || '】+APS剩余产能【' ||
                         v_Aps_Residual_Capacity || '】';
          End If;
        End If;
      End If;
    End Loop;
    Close c_Chk_Param;
    If v_Err_Msg Is Not Null Then
      If v_Pln_Capacity_Modle = 'CIMS' Then
        If v_CAPACITY_STRICT_FLAG = 'NOSTRICT' Then
          v_msg_End := '总部周期产能用完，本周期难以满足，是否续继提交？';
          p_Chk_Msg := '提货订单送审预警！预警原因：' || v_Nl || v_Err_Msg || v_Nl || v_Msg_End;
        Else
          p_Chk_Msg := '提货订单送审失败！失败原因：' || v_Nl || v_Err_Msg;
          p_Result := p_Chk_Msg;
        End If;
      Else
        --ex_dengjh   根据产能可视严控标识增加错误提示
        If v_CAPACITY_STRICT_FLAG = 'NOSTRICT' then
          v_Msg_End := '总部月度产能额度用完，本月难以满足，建议改单，是否继续提交？';
        else
          v_Msg_End := '是否提交排队请求？';
        end if;
        p_Chk_Msg := '提货订单送审预警！预警原因：' || v_Nl || v_Err_Msg || v_Nl || v_Msg_End;
      End If;
    End If;
  Exception
    When v_Ccs_Exception Then
      Rollback;
      p_Result := p_Result || v_Nl ||
                  'Pkg_Pln_Intf_CCs.p_Chk_Item_Capacity过程失败。';
    When Others Then
      Rollback;
      p_Result := p_Result || v_Nl ||
                  'Pkg_Pln_Intf_CCs.p_Chk_Item_Capacity过程失败。'; 
  End;
 ------------------------------------------------------------------------------------------
  ---- AUTHOR  : ex_dengjh
  -- CREATED : 2017-03-31
  -- PURPOSE : 获取产品可用量
  ------------------------------------------------------------------------------------------
  Procedure P_GET_ITEM_USABLE_QTY(IN_ENTITY_ID         in NUMBER, --主体ID
                                  IN_ITEM_CODE         in VARCHAR2, --产品编码
                                  IN_ORDER_SUBMIT_TYPE in VARCHAR2, --提货订单评审类型
                                  IN_SALES_CENTER_ID   in NUMBER, --中心ID
                                  IN_CUSTOMER_ID       IN NUMBER, --客户ID
                                  IN_LG_ORDER_NOSHIP   in VARCHAR2, --是否扣减已评未发货量
                                  IN_PRODUCING_AREA_ID in NUMBER, --产地ID
                                  IN_USER_CODE         in VARCHAR2, --用户
                                  OUT_CEN_INV_QTY      out NUMBER, --中心仓库存
                                  OUT_HQ_INV_QTY       out NUMBER, --基地仓库存
                                  OUT_CAPACITY_QTY     out NUMBER, --当前剩余产能数量（预计可供货量）
                                  OUT_ASSIGN_QTY       out NUMBER, --月度剩余分配量
                                  OUT_RESULT           out VARCHAR2 --成功返回SUCCESS，失败返回错误信息
                                  ) IS
    v_Pln_Capacity_Aps  VARCHAR2(100);
    v_Pln_Capacity_Mode VARCHAR2(100);
    v_item_id           number;
    v_action            varchar2(100);
    v_org_id            number;
  BEGIN
    --获取系统参数是否启用产能可视
    OUT_RESULT := v_Success;
    v_action := '获取产能可视主体参数';
    Begin
      v_Pln_Capacity_Aps := Pkg_Bd.f_Get_Parameter_Value('PLN_CAPACITY_APS',
                                                         IN_ENTITY_ID);
    Exception
      When Others Then
        OUT_RESULT := '获取是否使用APS产能可视参数PLN_CAPACITY_APS参数失败！' || v_Nl ||
                      Sqlerrm;
        Raise v_Ccs_Exception;
    End;
  
    if v_Pln_Capacity_Aps = 'N' then
      OUT_ASSIGN_QTY := 9999999999; --没启动产能可视的，不继续操作
    else
      --获取产能可视模式
      v_action := '获取产能可视模式';
      Begin
        v_Pln_Capacity_Mode := Pkg_Bd.f_Get_Parameter_Value('PLN_CAPACITY_MODEL',
                                                            IN_ENTITY_ID);
      Exception
        When Others Then
          OUT_RESULT := '获取产能可视模式PLN_CAPACITY_MODEL参数失败！' || v_Nl ||
                        Sqlerrm;
          Raise v_Ccs_Exception;
      End;
      if v_Pln_Capacity_Mode = 'APS-CIMS' then
        --获取商品ID
        v_action := '获取产能可视模式';
        select bi.item_id
          into v_item_id
          from t_bd_item bi
         where bi.item_code = IN_ITEM_CODE
           and bi.entity_id = in_entity_id;
        v_action        := '获取中心仓库存';
        OUT_CEN_INV_QTY := Pkg_Pln_Pub.f_Get_Item_Inv_Usable_Qty(p_Entity_Id         => in_entity_id,
                                                                 p_Item_Id           => v_item_id,
                                                                 p_Order_Submit_Type => 'CENTER_TYPE',
                                                                 p_Sales_Center_Id   => IN_SALES_CENTER_ID,
                                                                 p_User_Code         => in_user_code);
        v_action        := '获取基地仓库存';
        OUT_HQ_INV_QTY  := Pkg_Pln_Pub.f_Get_Item_Inv_Usable_Qty(p_Entity_Id         => in_entity_id,
                                                                 p_Item_Id           => v_item_id,
                                                                 p_Order_Submit_Type => 'HQ_TYPE',
                                                                 p_Sales_Center_Id   => IN_SALES_CENTER_ID,
                                                                 p_User_Code         => in_user_code);
        v_action        := '获取月度剩余分配量';
        OUT_ASSIGN_QTY  := PKG_PLN_PUB.F_GET_ITEM_MONTH_ASSIGN_QTY(IN_ENTITY_ID       => in_entity_id,
                                                                   IN_SALES_CENTER_ID => IN_SALES_CENTER_ID,
                                                                   IN_CUSTOMER_ID     => IN_CUSTOMER_ID,
                                                                   IN_ITEM_ID         => v_item_id);
        v_action        := '获取当前剩余产能';
        select ppa.mrp_org_id
          into v_org_id
          from t_pln_producing_area ppa
         where ppa.producing_area_id = IN_PRODUCING_AREA_ID;
        OUT_CAPACITY_QTY := Pkg_Pln_Intf_Aps.f_Get_Item_Capacity_Qty(p_Organization_Id => v_org_id,
                                                                     p_Item_Code       => IN_ITEM_CODE);
      elsif v_Pln_Capacity_Mode = 'APS' then
        v_action         := '获取预计可供货量';
        OUT_CAPACITY_QTY := PKG_PLN_INTF_CCS.f_Get_Item_Usable_Qty(p_Entity_Id         => in_entity_id,
                                                                   p_Item_Code         => IN_ITEM_CODE,
                                                                   p_Order_Submit_Type => IN_ORDER_SUBMIT_TYPE,
                                                                   p_Sales_Center_Id   => IN_SALES_CENTER_ID,
                                                                   p_Lg_Order_Noship   => IN_LG_ORDER_NOSHIP,
                                                                   p_Producing_Area_Id => IN_PRODUCING_AREA_ID,
                                                                   p_User_Code         => in_user_code);
        OUT_ASSIGN_QTY   := 9999999999;
      Elsif v_Pln_Capacity_Mode = 'CIMS'  Then
        v_action         := '获取预计可供货量';
        OUT_CAPACITY_QTY := PKG_PLN_CAPACITY.f_Get_Item_Capacity_Qty_New(p_Producing_Area_Id => IN_PRODUCING_AREA_ID,
                                                                         p_Item_Code         => IN_ITEM_CODE,
                                                                         p_Date              => Trunc(Sysdate),
                                                                         p_Entity_Id         => IN_ENTITY_ID,
                                                                         p_Period_Id         => Null);
        --获取商品ID
        v_action := '获取产能可视模式';
        Select Bi.Item_Id
          Into v_Item_Id
          From t_Bd_Item Bi
         Where Bi.Item_Code = In_Item_Code
           And Bi.Entity_Id = In_Entity_Id;
        v_action        := '获取月度剩余分配量';
        OUT_ASSIGN_QTY  := PKG_PLN_PUB.F_GET_ITEM_MONTH_ASSIGN_QTY(IN_ENTITY_ID       => in_entity_id,
                                                                   IN_SALES_CENTER_ID => IN_SALES_CENTER_ID,
                                                                   IN_CUSTOMER_ID     => IN_CUSTOMER_ID,
                                                                   IN_ITEM_ID         => v_item_id);                                                                
      end if;
    end if;
  exception
    when others then
      OUT_RESULT := v_action || '出错:' || v_Nl || Sqlerrm || v_Nl ||
                    OUT_RESULT;
    
  END;
  
  ------------------------------------------------------------------------------------------
  ---- AUTHOR  : ex_dengjh
  -- CREATED : 2017-04-05
  -- PURPOSE : 获取产品严控标识及分配量
  ------------------------------------------------------------------------------------------
  Procedure p_Chk_Item_Capacity_and_assign(IN_ENTITY_ID        in NUMBER, --主体ID
                                           IN_PARAM_ID         in NUMBER, --产能检查参数集ID
                                           IN_SALES_CENTER_ID  in NUMBER, --中心ID
                                           IN_CUSTOMER_ID       IN NUMBER, --客户ID
                                           IN_USER_CODE        in VARCHAR2, --用户
                                           OUT_RESULT          out VARCHAR2, --返回结果，成功返回SUCCESS，否则返回错误信息
                                           OUT_CAP_STRICT_FLAG out VARCHAR2, --产能严控标志
                                           OUT_CHK_MSG         out VARCHAR2 --产能检查不通过时返回提示信息
                                           ) is
    v_Pln_Capacity_Aps  VARCHAR2(100);
    v_Pln_Capacity_Mode VARCHAR2(100);
    Cursor c_Chk_Param Is
      Select *
        From t_Pln_Capacity_Chk_Param cp
       Where cp.param_id = IN_PARAM_ID
         And cp.entity_id = IN_ENTITY_ID;
    r_Chk_Param   c_Chk_Param%Rowtype;
    v_Item_Id     NUMBER;
    v_Item_Assign number;
    v_Err_Msg     Varchar2(4000);
    V_IS_PLN_CAPACITY T_PLN_ORDER_TYPE.IS_PLN_CAPACITY%TYPE := 'N'; --是否启用产能可视
  begin
    OUT_RESULT := v_Success;
    --获取系统参数是否启用产能可视
    Begin
      v_Pln_Capacity_Aps := Pkg_Bd.f_Get_Parameter_Value('PLN_CAPACITY_APS',
                                                         IN_ENTITY_ID);
    Exception
      When Others Then
        OUT_RESULT := '获取是否使用APS产能可视参数PLN_CAPACITY_APS参数失败！' || v_Nl ||
                      Sqlerrm;
        Raise v_Ccs_Exception;
    End;
  
    if v_Pln_Capacity_Aps = 'Y' then
      --获取产能可视模式
      Begin
        v_Pln_Capacity_Mode := Pkg_Bd.f_Get_Parameter_Value('PLN_CAPACITY_MODEL',
                                                            IN_ENTITY_ID);
      Exception
        When Others Then
          OUT_RESULT := '获取产能可视模式PLN_CAPACITY_MODEL参数失败！' || v_Nl ||
                        Sqlerrm;
          Raise v_Ccs_Exception;
      End;
      --获取产能可视严控标识 
      Begin
        OUT_CAP_STRICT_FLAG := Pkg_Bd.f_Get_Parameter_Value('PLN_CAPACITY_STRICT_FLAG',
                                                            in_Entity_Id);
      Exception
        When Others Then
          OUT_RESULT := '获取产能可视严控标识PLN_CAPACITY_STRICT_FLAG参数失败！' || v_Nl ||
                        Sqlerrm;
          Raise v_Ccs_Exception;
      End;
      --modi by lizhen 2017-09-06 CIMS产能模式也进行月分配数量检查
      --if v_Pln_Capacity_Mode = 'APS-CIMS' then
      if v_Pln_Capacity_Mode In ('CIMS', 'APS-CIMS') then
        open c_Chk_Param;
        Loop
          Fetch c_Chk_Param
            Into r_Chk_Param;
          If c_Chk_Param%Rowcount = 0 Then
            OUT_RESULT := '获取参数失败，参数集表无数据。参数集ID:' || To_Char(IN_PARAM_ID);
            Raise v_Ccs_Exception;
          End If;
          Exit When c_Chk_Param%Notfound;
          
          --20170706 hejy3 检查单据类型产能可视标志
          BEGIN
            SELECT T.IS_PLN_CAPACITY
              INTO V_IS_PLN_CAPACITY
              FROM T_PLN_ORDER_TYPE T
             WHERE T.ORDER_TYPE_ID = r_Chk_Param.Order_Type_Id;
          exception
            when others then
              V_IS_PLN_CAPACITY := 'N';
          END;
          
          IF V_IS_PLN_CAPACITY <> 'Y' THEN --未启用产能可视直接返回
            RETURN;
          END IF;
          
          Begin
            Select Bi.Item_Id
              Into v_Item_Id
              From t_Bd_Item Bi
             Where Bi.Item_Code = r_Chk_Param.Item_Code
               And Bi.Entity_Id = r_Chk_Param.Entity_Id;
          Exception
            When Others Then
              OUT_RESULT := '获取产品信息失败，产品编码:' ||
                            To_Char(r_Chk_Param.Item_Code) || v_Nl ||
                            Sqlerrm;
              Raise v_Ccs_Exception;
          End;
          -- 获取月度分配量
          v_Item_Assign := PKG_PLN_PUB.F_GET_ITEM_MONTH_ASSIGN_QTY(IN_ENTITY_ID       => IN_ENTITY_ID,
                                                                   IN_SALES_CENTER_ID => IN_SALES_CENTER_ID,
                                                                   IN_CUSTOMER_ID     => IN_CUSTOMER_ID,
                                                                   IN_ITEM_ID         => v_Item_Id);
          if r_Chk_Param.Apply_Qty > v_Item_Assign then
            If v_Err_Msg Is Null Then
              v_Err_Msg := '产品编码为【' || r_Chk_Param.Item_Code || '】的申请数量【' ||
                           r_Chk_Param.Apply_Qty || '】> 月度剩余分配量【' ||
                           v_Item_Assign || '】';
            Else
              v_Err_Msg := v_Err_Msg || v_Nl || '产品编码为【' ||
                           r_Chk_Param.Item_Code || '】的申请数量【' ||
                           r_Chk_Param.Apply_Qty || '】> 月度剩余分配量【' ||
                           v_Item_Assign || '】';
            End If;
          end if;
        end loop;
        close c_Chk_Param;
      end if;
      if v_Err_Msg is null then
        --检查剩余产能
        PKG_PLN_INTF_CCS.p_Chk_Item_Capacity(p_Entity_Id => IN_ENTITY_ID,
                                             p_Param_Id  => in_Param_Id,
                                             p_User_Code => IN_USER_CODE,
                                             p_Result    => OUT_RESULT,
                                             p_Chk_Msg   => OUT_CHK_MSG);
        if OUT_RESULT <> v_Success then
          Raise v_Ccs_Exception;
        end if;
      else
        OUT_RESULT := v_Err_Msg;--分配量检查不通过
      end if;
      /*If v_Err_Msg Is Not Null Then
        OUT_CHK_MSG := '检查失败！失败原因：' || v_Nl || v_Err_Msg;
      End If;*/
      
    end if;
  Exception
    When v_Ccs_Exception Then    
      OUT_RESULT := OUT_RESULT || v_Nl ||
                    'Pkg_Pln_Intf_CCs.p_Chk_Item_Capacity_and_assign过程失败。';
    When Others Then   
      OUT_RESULT := OUT_RESULT || v_Nl ||
                    'Pkg_Pln_Intf_CCs.p_Chk_Item_Capacity_and_assign过程失败。';
  end;
 
 -----------------------------------------------------------------------------
 --更新来自CCS的库存水位
 -----------------------------------------------------------------------------
 PROCEDURE P_UPDATE_PLN_STOCK(IN_ENTITY_ID IN NUMBER, --单据头ID
                              P_RESULT     IN OUT NUMBER, --返回错误ID
                              P_ERR_MSG    IN OUT VARCHAR2 --返回错误信息
                              ) IS
 
 BEGIN
   --初始返回值
   P_RESULT  := 0;
   P_ERR_MSG := 'SUCCESS';
 
   --清空临时表  
   DELETE FROM INTF_PLN_INV_STOCK_TEMP T WHERE T.ENTITY_ID = IN_ENTITY_ID;
   --插入临时数据
   INSERT INTO INTF_PLN_INV_STOCK_TEMP
     --(ORDER_LINE_ID, AGENT_STOCK_QTY, AGENT_USABLE_QTY,ENTITY_ID, SKU_INVSALE_STANDARD)
     (ENTITY_ID, ORDER_LINE_ID, ORDER_TYPE_ID, ITEM_CODE, SALES_CENTER_CODE, CUSTOMER_CODE)  
     --SELECT L.ORDER_LINE_ID, AA.AGENT_STOCK_QTY, AA.AGENT_USABLE_QTY,L.ENTITY_ID, AA.SKU_INVSALE_STANDARD
     SELECT H.ENTITY_ID,
            L.ORDER_LINE_ID,
            H.ORDER_TYPE_ID,
            L.ITEM_CODE,
            H.SALES_CENTER_CODE,
            H.CUSTOMER_CODE
       FROM CIMS.T_PLN_LG_ORDER_LINE L,
            CIMS.T_PLN_LG_ORDER_HEAD H/*,
            (SELECT I.ENTITY_ID,
                    I.SALES_CENTER_CODE,
                    I.CUSTOMER_CODE,
                    I.ITEM_CODE,
                    I.AGENT_USABLE_QTY,
                    I.AGENT_STOCK_QTY,
                    I.SKU_INVSALE_STANDARD
               FROM CIMS.INTF_PLN_INV_STOCK I
              WHERE I.CREATION_DATE > TRUNC(SYSDATE)
                AND I.ENTITY_ID = IN_ENTITY_ID
                AND I.INTF_ID =
                    (SELECT MAX(II.INTF_ID)
                       FROM CIMS.INTF_PLN_INV_STOCK II
                      WHERE II.ITEM_CODE = I.ITEM_CODE
                        AND II.SALES_CENTER_CODE = I.SALES_CENTER_CODE
                        AND II.CUSTOMER_CODE = I.CUSTOMER_CODE
                        AND II.ENTITY_ID = IN_ENTITY_ID
                        AND II.CREATION_DATE > TRUNC(SYSDATE))) AA*/
      WHERE L.ORDER_HEAD_ID = H.ORDER_HEAD_ID
        /*AND L.ITEM_CODE = AA.ITEM_CODE
        AND H.SALES_CENTER_CODE = AA.SALES_CENTER_CODE
        AND H.CUSTOMER_CODE = AA.CUSTOMER_CODE*/
        AND H.TO_CHECKUP_DATE BETWEEN TRUNC(ADD_MONTHS(SYSDATE, -3)) AND TRUNC(SYSDATE) + 1 --3个月内
        AND H.ORDER_HEAD_STATE NOT IN ('19', '304', '23', '415') --非制单、已关闭、评审完毕、已驳回状态
        AND NVL(L.ORDER_LINE_STATE, 'NORMAL') <> 'CLOSED' --行状态非已关闭
        /*AND EXISTS
      (SELECT 1
               FROM CIMS.T_PLN_ORDER_TYPE T
              WHERE T.ORDER_TYPE_ID = H.ORDER_TYPE_ID
                AND T.SOURCE_ORDER_TYPE_ID = 1 --提货订单
                AND UPPER(NVL(T.IS_BUSINESS_CONTROL, '_')) NOT IN
                    ('PRO_ORDER', 'COMPENSATION')) --非推广物料提货订单
        AND H.ORDER_TYPE_ID NOT IN
            (SELECT UCL.CODE_VALUE
               FROM CIMS.UP_CODELIST UCL, CIMS.UP_CODELIST_ENTITY UCLE
              WHERE UCL.CODETYPE = 'PLG_LGORDER_CENTER_TRANSFER'
                AND UCL.ID = UCLE.CODELIST_ID
                AND UCL.ENABLED = 0
                AND UCLE.ENTITY_ID = IN_ENTITY_ID)*/
        AND CASE
              WHEN H.ORDER_HEAD_STATE IN ('20', '2225', '1455') AND H.HQ_LG_ORDER_HEAD_ID IS NULL THEN
                L.QUANTITY - NVL(L.AFFIRMED_QUANTITY, 0) - NVL(L.CANCEL_QTY, 0)
              ELSE
                NVL(L.CENTER_AFFIRM_QUANTITY, L.QUANTITY) - NVL(L.AFFIRMED_QUANTITY, 0) - NVL(L.CANCEL_QTY, 0)
            END > 0
        AND H.ENTITY_ID = IN_ENTITY_ID;
   
    --删除不需统计的单据类型数据
    --推广物料、物流全赔
    delete from INTF_PLN_INV_STOCK_TEMP t
     where t.order_type_id in
           (SELECT T.ORDER_TYPE_ID
              FROM CIMS.T_PLN_ORDER_TYPE T
             WHERE T.ENTITY_ID = IN_ENTITY_ID
               AND T.SOURCE_ORDER_TYPE_ID = 1 --提货订单
               AND UPPER(NVL(T.IS_BUSINESS_CONTROL, '_')) IN ('PRO_ORDER', 'COMPENSATION'));
    
    --中心备货提货订单
    delete from INTF_PLN_INV_STOCK_TEMP t
     where t.order_type_id in
           (SELECT UCL.CODE_VALUE
              FROM CIMS.UP_CODELIST UCL, CIMS.UP_CODELIST_ENTITY UCLE
             WHERE UCL.CODETYPE = 'PLG_LGORDER_CENTER_TRANSFER'
               AND UCL.ID = UCLE.CODELIST_ID
               AND UCL.ENABLED = 0
               AND UCLE.ENTITY_ID = IN_ENTITY_ID);
    
    --调拨申请
    delete from INTF_PLN_INV_STOCK_TEMP t
     where t.order_type_id in
           (SELECT T.ORDER_TYPE_ID
              FROM CIMS.T_PLN_ORDER_TYPE T
             WHERE T.ENTITY_ID = IN_ENTITY_ID
               AND T.SOURCE_ORDER_TYPE_ID <> 1);
               
    insert into INTF_PLN_INV_STOCK_TEMP
     (order_line_id,
      entity_id,
      agent_usable_qty,
      agent_stock_qty,
      created_by,
      last_updated_by,
      creation_date,
      last_update_date,
      sku_invsale_standard,
      order_type_id,
      sales_center_code,
      customer_code,
      item_code,
      intf_id,
      max_intf_id)
    select t.order_line_id,
           t.entity_id,
           i.agent_usable_qty,
           i.agent_stock_qty,
           'admin',
           'admin',
           sysdate,
           sysdate,
           i.sku_invsale_standard,
           t.order_type_id,
           t.sales_center_code,
           t.customer_code,
           t.item_code,
           i.intf_id,
           (MAX(i.intf_id) OVER(PARTITION BY t.order_line_id)) max_intf_id
      from INTF_PLN_INV_STOCK_TEMP t, CIMS.INTF_PLN_INV_STOCK I
     where I.CREATION_DATE > TRUNC(SYSDATE)
       AND I.ENTITY_ID = IN_ENTITY_ID
       and i.customer_code = t.customer_code
       and i.sales_center_code = t.sales_center_code
       and i.item_code = t.item_code;
   
   --删除无效数据
   DELETE FROM INTF_PLN_INV_STOCK_TEMP T
    WHERE T.ENTITY_ID = IN_ENTITY_ID
      AND (T.max_intf_id is null or t.max_intf_id <> t.intf_id);
   
   --更新提货订单行
   UPDATE CIMS.T_PLN_LG_ORDER_LINE L
      SET (L.AGENT_USABLE_QTY, L.AGENT_STOCK_QTY, L.SKU_INVSALE_STANDARD) = (SELECT TP.AGENT_USABLE_QTY,
                                                           TP.AGENT_STOCK_QTY,
                                                           TP.SKU_INVSALE_STANDARD
                                                      FROM CIMS.INTF_PLN_INV_STOCK_TEMP TP
                                                     WHERE TP.ORDER_LINE_ID =
                                                           L.ORDER_LINE_ID),
          L.LAST_UPDATE_DATE = SYSDATE
    WHERE L.ENTITY_ID = IN_ENTITY_ID
      AND EXISTS (SELECT 1
             FROM CIMS.INTF_PLN_INV_STOCK_TEMP T
            WHERE T.ORDER_LINE_ID = L.ORDER_LINE_ID);
 EXCEPTION
   WHEN OTHERS THEN
     P_RESULT  := -1;
     P_ERR_MSG := '更新来自CCS的库存水位出错,主体ID：' || IN_ENTITY_ID || ',出错原因：' ||
                  SUBSTR(SQLERRM, 1, 500);
     PKG_PLN_PUB.P_WRITE_JOB_LOG(P_MODULE_CODE          => 'PLN',
                                        P_PROCEDURE_NAME       => 'PKG_PLN_INTF_CCS.P_UPDATE_PLN_STOCK',
                                        P_ERROR_MSG            => P_ERR_MSG,
                                        P_SOURCE_ORDER_HEAD_ID => NULL,
                                        P_SOURCE_ORDER_LINE_ID => NULL,
                                        P_ITEM_ID              => NULL,
                                        P_INVENTORY_ID         => NULL,
                                        P_QUANTITY             => NULL);
 END;
 
  -----------------------------------------------------------------------------
  --校验需求提交
  -----------------------------------------------------------------------------
  PROCEDURE P_CHECK_DEMAND_FORECAST(IN_CHK_BATCH_ID IN NUMBER, --校验批次ID
                                    OUT_RESULT      OUT VARCHAR2, --返回结果，成功返回SUCCESS，否则返回错误信息
                                    OUT_CHK_MSG     OUT VARCHAR2, --校验提示信息
                                    OUT_PROMPT	    OUT VARCHAR2,
                                    OUT_ITEM_CODE   OUT VARCHAR2
                                    )
  IS
    V_BEGIN_DATE DATE;
    V_BEGIN_DATE_CURR_MONTH DATE;
    V_END_DATE DATE;
    V_MONTH_PLAN_QTY NUMBER;
    V_ORDER_QTY NUMBER;
    v_Pln_Of_Time_Month number;
  BEGIN
    OUT_RESULT := v_Success;
    FOR R_CHK IN (
      SELECT DP.ENTITY_ID,
             DP.ACCOUNT_ID,
             P.ITEM_ID,
             DP.ITEM_CODE,
             DP.QUANTITY,
             P.DEMAND_FORECAST_STANDARD
        FROM T_PLN_CHK_DEMAND_PARAM DP, T_PLN_ITEM_PROPERTY P
       WHERE DP.CHK_BATCH_ID = IN_CHK_BATCH_ID
         AND DP.ENTITY_ID = P.ENTITY_ID
         AND DP.ITEM_CODE = P.ITEM_CODE
         AND NVL(P.NEW_PRODUCT_FLAG, 'N') <> 'Y'
         AND P.DEMAND_FORECAST_STANDARD IS NOT NULL)
    LOOP
      IF V_BEGIN_DATE IS NULL THEN
        --获取月统计的起始和终止日期
        PKG_PLN_PUB.p_Get_CurrentPeriodDate(p_Entity_Id                 => R_CHK.ENTITY_ID,
                                            IN_CAL_DATE                 => SYSDATE,
                                            p_Current_Period_Begin_Date => V_BEGIN_DATE,
                                            p_Current_Period_End_Date   => V_END_DATE);
        
        Begin
          v_Pln_Of_Time_Month := to_number(Pkg_Bd.f_Get_Parameter_Value('PLN_CAPACITY_AHEAD_OF_TIME_MONTH',
                                                                        R_CHK.ENTITY_ID));
        Exception
          When Others Then
            v_Pln_Of_Time_Month := 0;
        End;
        
        V_BEGIN_DATE_CURR_MONTH := ADD_MONTHS(V_BEGIN_DATE, v_Pln_Of_Time_Month);
      END IF;
      
      --月预测数量
      SELECT SUM(PL.MONTH_PLAN_QTY)
        INTO V_MONTH_PLAN_QTY
        FROM T_STP_MONTH_PLAN_HEAD PH,
             T_STP_MONTH_PLAN_LINES PL,
             T_PLN_ORDER_PERIOD OP,
             T_PLN_ORDER_TYPE OT
       WHERE PH.MONTH_PLAN_HEAD_ID = PL.MONTH_PLAN_HEAD_ID
         AND PH.PLAN_PERIOD = OP.PERIOD_ID
         AND PH.PLAN_TYPE = OT.ORDER_TYPE_ID
         AND PH.ENTITY_ID = R_CHK.ENTITY_ID
         AND PH.ACCOUNT_ID = R_CHK.ACCOUNT_ID
         AND PL.ITEM_ID = R_CHK.ITEM_ID
         AND OT.ORDER_TYPE_NAME IN ('月预测计划(M+1)', '三月滚动预测')
         AND PH.PLAN_STATUS = '04'
         AND OP.BEGIN_DATE BETWEEN V_BEGIN_DATE_CURR_MONTH AND V_END_DATE;
      
      --已提单数量
      SELECT sum(CASE
               WHEN h.ORDER_HEAD_STATE IN ('2225', '20', '1455') THEN
                l.QUANTITY
               WHEN h.ORDER_HEAD_STATE IN ('679', '381') THEN
                l.CENTER_AFFIRM_QUANTITY
             END - NVL(l.AFFIRMED_QUANTITY, 0) - NVL(l.CANCEL_QTY, 0))
        INTO V_ORDER_QTY
        FROM T_PLN_LG_ORDER_HEAD H, T_PLN_LG_ORDER_LINE L
       WHERE H.ORDER_HEAD_ID = L.ORDER_HEAD_ID
         and h.ENTITY_ID = r_chk.entity_id
         AND h.ORDER_HEAD_STATE IN ('2225', '20', '1455', '679', '381')
         AND NVL(l.ORDER_LINE_STATE, 'NORMAL') <> 'CLOSED'
         AND NVL(l.COLLECT_ORDER_LINE_FLAG, 'N') = 'N'
         AND H.TO_CHECKUP_DATE BETWEEN V_BEGIN_DATE AND V_END_DATE + 1
         and h.account_id = r_chk.account_id
         and l.item_id = r_chk.item_id
         AND EXISTS
       (SELECT 1
                FROM CIMS.T_PLN_ORDER_TYPE T
               WHERE h.ORDER_TYPE_ID = T.ORDER_TYPE_ID
                 AND T.SOURCE_ORDER_TYPE_ID = 1
                 AND NVL(T.IS_BUSINESS_CONTROL, '_') NOT IN
                     ('pro_order', 'share_ship_order', 'COMPENSATION', 'RELET_ORDER'))
         AND CASE
               WHEN h.ORDER_HEAD_STATE IN ('2225', '20', '1455') THEN
                l.QUANTITY
               WHEN h.ORDER_HEAD_STATE IN ('679', '381') THEN
                l.CENTER_AFFIRM_QUANTITY
             END - NVL(l.AFFIRMED_QUANTITY, 0) - NVL(l.CANCEL_QTY, 0) > 0;
      
      
      SELECT NVL(V_ORDER_QTY, 0) + NVL(SUM(NVL(L.CENTER_AFFIRMED_QTY, 0) + NVL(L.HQ_AFFIRMED_QTY, 0) +
                     DECODE(L.MAKE_ORDER_LINE_FLAG, 'Y', NVL(L.TO_PLN_QTY, 0), NVL(L.PLN_AFFIRMED_QTY, 0))), 0)
        INTO V_ORDER_QTY
        FROM T_PLN_LG_ORDER_HEAD H,
             T_PLN_LG_ORDER_LINE L
       WHERE H.ORDER_HEAD_ID = L.ORDER_HEAD_ID
         AND H.TO_CHECKUP_DATE BETWEEN V_BEGIN_DATE_CURR_MONTH AND V_END_DATE + 1
         AND H.ENTITY_ID = R_CHK.ENTITY_ID
         AND H.ACCOUNT_ID = R_CHK.ACCOUNT_ID
         AND L.ITEM_ID = R_CHK.ITEM_ID
         AND H.ORDER_HEAD_STATE NOT IN ('19', '415')
         AND EXISTS (SELECT 1 FROM T_PLN_ORDER_TYPE T
            WHERE H.ORDER_TYPE_ID = T.ORDER_TYPE_ID
              AND T.SOURCE_ORDER_TYPE_ID = 1
              AND NVL(T.IS_BUSINESS_CONTROL, '_') NOT IN ('pro_order', 'COMPENSATION', 'RELET_ORDER'));
      
      IF NVL(V_ORDER_QTY, 0) + NVL(R_CHK.QUANTITY, 0) > NVL(V_MONTH_PLAN_QTY, 0) * R_CHK.DEMAND_FORECAST_STANDARD / 100 THEN
        OUT_CHK_MSG := OUT_CHK_MSG || '产品'||R_CHK.ITEM_CODE||'本次送审数量('||NVL(R_CHK.QUANTITY,0)||')+已送审数量('||NVL(V_ORDER_QTY, 0)||')>月度需求('||
                       NVL(V_MONTH_PLAN_QTY, 0) * R_CHK.DEMAND_FORECAST_STANDARD / 100||')'||v_Nl;
        IF OUT_ITEM_CODE IS NULL THEN
          OUT_ITEM_CODE := R_CHK.ITEM_CODE;
        ELSE
          OUT_ITEM_CODE := OUT_ITEM_CODE || ',' || R_CHK.ITEM_CODE;
        END IF;  
      END IF;
    END LOOP;
    
    IF OUT_CHK_MSG IS NOT NULL THEN
      OUT_CHK_MSG := OUT_CHK_MSG || '，将不反馈交期，建议拆单送审，是否继续送审？';
      OUT_PROMPT := '超月度需求预测，交期待定';
    END IF;
  END P_CHECK_DEMAND_FORECAST;
  
  ----------------------------------------------------------------------
  -- Author  : lilh6
  -- Created : 2018-11-05
  -- Purpose : 获取价格,销售预测使用
  ----------------------------------------------------------------------
  Procedure p_Get_New_Item_Price(p_Acc_Id         In t_Customer_Account.Account_Id%Type, --账户ID
                                 p_Item_Code      In t_Bd_Item.Item_Code%Type, --产品编码
                                 p_Bill_Date      In Varchar2, --单据日期,YYYYMMDD
                                 p_Price_List_Id  In t_Bd_Price_List.Price_List_Id%Type, --价格列表ID
                                 p_Entity_Id      In Up_Org_Unit.Entity_Id%Type, --业务主体ID
                                 p_Price          Out Number, --返回价格
                                 p_Discount       Out Number, --返回折扣率
                                 p_Month_Discount Out Number, --返回月返
                                 p_Cx_Flag        Out Varchar2 --返回是否促销机
                                 ) Is
    Ld_Price          Number;
    Ld_Discount       Number;
    Ld_Month_Discount Number;
    Ls_Cx_Flag        Varchar2(2);
  Begin
    Pkg_Bd_Price.p_Get_Price(p_Acc_Id, --账户ID
                             p_Item_Code, --产品编码
                             p_Bill_Date, --单据日期,YYYYMMDD
                             p_Price_List_Id, --价格列表ID
                             p_Entity_Id, --业务主体ID
                             p_Price, --返回价格
                             p_Discount, --返回折扣率
                             p_Month_Discount, --返回月返
                             p_Cx_Flag --返回是否促销机
                             );
    --正常取价取不到，则获取新品价格
    If p_Price Is Null Then
      Begin
        Select t.Standard_Rate
          Into p_Price
          From t_Pln_Item_Property t
         Where t.Item_Code = p_Item_Code
           And t.New_Product_Flag = 'Y'
           And t.Entity_Id = p_Entity_Id;
      Exception
        When Others Then
          p_Price := Null;
      End;
    End If;
  End p_Get_New_Item_Price;
  ----------------------------------------------------------------------
  -- Author  : lilh6
  -- Created : 2019-02-18
  -- Purpose : 代销单生成
  ----------------------------------------------------------------------
  Procedure p_Create_Intf_Dx_Order(p_Intf_Id     In Number, --代销单接口表订单头ID
                                   p_Appendix_Id In Varchar2, --附件id
                                   p_Result      Out Varchar2,
                                   p_Result_Num  Out Varchar2) Is
    r_Pln_Dx_Order_Head  Intf_Pln_Dx_Order_Head%Rowtype;
    r_Pln_Order_Type     t_Pln_Order_Type%Rowtype;
    v_Value              Varchar2(3500);
    v_Count              Number;
    v_Entity_Name        Varchar2(100); --事业部
    v_Order_Number       t_Pln_Dx_Order_Head.Order_Number%Type; --单号
    v_Dx_Order_Head_Id   Number; --订单头id
    v_Item_Id            Number;
    v_Item_Uom           Varchar2(32);
    v_Item_Desc          Varchar2(240);
    v_Sales_Main_Type    Varchar2(32);
    v_Sales_Sub_Type     Varchar2(32);
    v_Unit_Volume        Number; --单位体积
    v_Unit_Weight        Number; --单据重量
    v_Item_Price         Number; --直供价
    v_Apply_Amount       Number; --直供金额
    v_Discount           Number;
    v_Month_Discount     Number;
    v_Cx_Flag            Varchar2(10);
    v_Dx_Order_Line_Id   Number; --订单行id
    v_Dx_Order_Detail_Id Number; --订单明细id
    v_Addr               Varchar2(2000);
    v_Ter_Addr           Varchar2(2000);
    v_Shopmanager_Name   Varchar2(100);
    v_Shopmanager_Phone  Varchar2(100);
    v_Pln_Dx_Use_Retail_Price Varchar2(32);
    v_pre_settle_price   Number; --预结算价
    v_pre_settle_amount  Number; --预结算金额
    v_deduction_point    Number; --扣点
    v_deal_price         Number; --成交金额
  Begin
    p_Result := v_Success;
    -----------  接口数据头表数据检测  --------------------
    --检测订单接口
    Begin
      v_Value := '锁定代销单接口头表失败！';
      Select *
        Into r_Pln_Dx_Order_Head
        From Intf_Pln_Dx_Order_Head h
       Where h.Intf_Head_Id = p_Intf_Id
         And h.Intf_State = 'N'
         For Update Nowait;
    Exception
      When Others Then
        p_Result := v_Value || v_Nl || Sqlerrm;
        Raise v_Ccs_Exception;
    End;
    
    --是否使用零售价评审
    Begin
      v_Pln_Dx_Use_Retail_Price := Pkg_Bd.f_Get_Parameter_Value('PLN_DX_USE_RETAIL_PRICE',
                                                                r_Pln_Dx_Order_Head.Entity_Id);
    Exception
      When Others Then
        p_Result := '获取PLN_DX_USE_RETAIL_PRICE参数失败！' || v_Nl || Sqlerrm;
        Raise v_Ccs_Exception;
    End;
  
    --主体编码检测
    If p_Result = v_Success Then
      Begin
        v_Value := '主体编码检查：';
        Select b.Entity_Name
          Into v_Entity_Name
          From v_Bd_Entity b
         Where b.Entity_Id = r_Pln_Dx_Order_Head.Entity_Id;
      Exception
        When Others Then
          p_Result := v_Value || '主体编码' || r_Pln_Dx_Order_Head.Entity_Id ||
                      '无效。';
          Raise v_Ccs_Exception;
      End;
      v_Entity_Name := '事业部：' || v_Entity_Name;
    End If;
  
    --检查代销单是否重复提交
    If p_Result = v_Success Then
      Begin
        v_Value := '代销单是否重复报送检查：';
        Select h.Order_Number
          Into v_Order_Number
          From t_Pln_Dx_Order_Head h
         Where h.Entity_Id = r_Pln_Dx_Order_Head.Entity_Id
           And h.Source_Order_Number =
               r_Pln_Dx_Order_Head.Source_Order_Number;
      Exception
        When Others Then
          Null;
      End;
      If v_Order_Number Is Not Null Then
        p_Result := v_Success;
        p_Result_Num := v_Order_Number;
        --更新接口状态
        Update Intf_Pln_Dx_Order_Head h
           Set h.Intf_State       = 'S',
               h.Error_Meg        = 'SUCCESS,根据来源代销单查询CIMS代销单已存在，无需重新创建代销单',
               h.order_number     = v_Order_Number,
               h.Last_Updated_By  = 'CIMS_INTF',
               h.Last_Update_Date = Sysdate
         Where h.Intf_Head_Id = p_Intf_Id;
        Return;
        /*p_Result := v_Value || v_Entity_Name || '，代销单' ||
                    r_Pln_Dx_Order_Head.Source_Order_Number ||
                    '已报送CIMS，CIMS代销单号：' || v_Order_Number || '，不能重复报送！';
        Raise v_Ccs_Exception;*/
      End If;
    End If;
  
    --检查单据类型
    If p_Result = v_Success Then
      Begin
        v_Value := '单据类型检查：';
        Select Ot.*
          Into r_Pln_Order_Type
          From t_Pln_Order_Type Ot, Up_Codelist Uc, Up_Codelist_Entity Uce
         Where Ot.Order_Type_Code = Uce.Entity_Code_Name
           And Ot.Entity_Id = Uce.Entity_Id
           And Uce.Codelist_Id = Uc.Id
           And Uce.Enabled = 0
           And uce.entity_id = r_Pln_Dx_Order_Head.Entity_Id
           And Uc.Enabled = 0
           And Uc.Code_Value = r_Pln_Dx_Order_Head.Order_Type --接口传递的订单类型
           And Uc.Codetype = 'PLN_DX_ORDER_MATCH'
           And Trunc(r_Pln_Dx_Order_Head.Creation_Date) Between
               Ot.Begin_Date And Trunc(Nvl(Ot.End_Date, Sysdate));
      Exception
        When Others Then
          p_Result := v_Value || v_Entity_Name || '，代销单据类型不存在或者已失效。';
          Raise v_Ccs_Exception;
      End;
    End If;
  
    --代销单行检测
    If p_Result = v_Success Then
      Select Count(1)
        Into v_Count
        From Intf_Pln_Dx_Order_Line l
       Where l.Intf_Head_Id = r_Pln_Dx_Order_Head.Intf_Head_Id;
      If v_Count = 0 Then
        p_Result := v_Entity_Name || '，无代销单行资料，校验失败。';
        Raise v_Ccs_Exception;
      End If;
      --行产品是否重复检查
      Select Count(1)
        Into v_Count
        From (Select 1
                From Intf_Pln_Dx_Order_Line l
               Where l.Intf_Head_Id = r_Pln_Dx_Order_Head.Intf_Head_Id
               Group By l.Item_Code
              Having Count(1) > 1);
      If v_Count > 0 Then
        p_Result := v_Entity_Name || '，代销单存在重复的产品行资料，校验失败。';
        Raise v_Ccs_Exception;
      End If;
    End If;
  
    --检测营销中心编码
    If p_Result = v_Success Then
      Begin
        v_Value := '营销中心检查：';
        Select u.Name, u.Unit_Id
          Into r_Pln_Dx_Order_Head.Sales_Center_Name,
               r_Pln_Dx_Order_Head.Sales_Center_Id
          From Up_Org_Unit u
         Where u.Code = r_Pln_Dx_Order_Head.Sales_Center_Code
           And u.Entity_Id = r_Pln_Dx_Order_Head.Entity_Id
           And u.Active_Flag = 'T';
      Exception
        When Others Then
          p_Result := v_Value || v_Entity_Name || '，营销中心不存在或者中心已失效。' || v_Nl ||
                      ',中心编码=' || r_Pln_Dx_Order_Head.Sales_Center_Code;
          Raise v_Ccs_Exception;
      End;
    End If;
  
    --检测客户编码
    If p_Result = v_Success Then
      Begin
        v_Value := '客户检查：';
        Select Ch.Customer_Name, Ch.Customer_Id
          Into r_Pln_Dx_Order_Head.Customer_Name,
               r_Pln_Dx_Order_Head.Customer_Id
          From t_Customer_Header Ch
         Where Ch.Customer_Code = r_Pln_Dx_Order_Head.Customer_Code
           And Ch.Active_Flag = v_Active;
      Exception
        When Others Then
          p_Result := v_Value || v_Entity_Name || '，客户不存在或已失效。' || v_Nl ||
                      ',客户编码=' || r_Pln_Dx_Order_Head.Customer_Code;
          Raise v_Ccs_Exception;
      End;
    End If;
  
    --检测账户编码
    If p_Result = v_Success Then
      Begin
        v_Value := '客户账户检查：';
        Select Ca.Account_Code, Nvl(Ca.Account_Name, ' '), Ca.Account_Id
          Into r_Pln_Dx_Order_Head.Account_Code,
               r_Pln_Dx_Order_Head.Account_Name,
               r_Pln_Dx_Order_Head.Account_Id
          From v_Customer_Account_Salecenter Ca
         Where Ca.Sales_Center_Id = r_Pln_Dx_Order_Head.Sales_Center_Id
           And Ca.Customer_Id = r_Pln_Dx_Order_Head.Customer_Id
           And Ca.Entity_Id = r_Pln_Dx_Order_Head.Entity_Id
           And Ca.Active_Flag = v_Active
           And Ca.Account_Status = v_Account_Active;
      Exception
        When Others Then
          p_Result := v_Value || '中心客户不存在对应的账户，或账户未激活。' || v_Nl || '事业部ID=' ||
                      To_Char(r_Pln_Dx_Order_Head.Entity_Id) ||
                      v_Entity_Name || v_Nl || '中心ID=' ||
                      To_Char(r_Pln_Dx_Order_Head.Sales_Center_Id) ||
                      ',中心编码=' || r_Pln_Dx_Order_Head.Sales_Center_Code ||
                      ',中心名称=' || r_Pln_Dx_Order_Head.Sales_Center_Name || v_Nl ||
                      '客户ID=' || To_Char(r_Pln_Dx_Order_Head.Customer_Id) ||
                      ',客户编码=' || r_Pln_Dx_Order_Head.Customer_Code ||
                      ',客户名称=' || r_Pln_Dx_Order_Head.Customer_Name;
          Raise v_Ccs_Exception;
      End;
    End If;
  
    --检测门店编码
    If p_Result = v_Success Then
      Begin
        v_Value := '门店检查：';
        Select Pt.Terminal_Name, Pt.Terminal_Id
          Into r_Pln_Dx_Order_Head.Terminal_Name,
               r_Pln_Dx_Order_Head.Terminal_Id
          From t_Pro_Terminal Pt
         Where Pt.Terminal_Code = r_Pln_Dx_Order_Head.Terminal_Code;
      Exception
        When Others Then
          p_Result := v_Value || v_Entity_Name || '，门店不存在或门店还未同步。' || v_Nl ||
                      ',门店编码=' || r_Pln_Dx_Order_Head.Terminal_Code;
          Raise v_Ccs_Exception;
      End;
    End If;
  
    --根据中心+门店+主体获取客户、账户信息
    /*If p_Result = v_Success Then
      Begin
        v_Value := '门店对应的客户检查：';
        Select Pte.Customer_Id,
               Pte.Customer_Code,
               Pte.Customer_Name,
               Pte.Account_Id,
               Pte.Account_Code
          Into r_Pln_Dx_Order_Head.Customer_Id,
               r_Pln_Dx_Order_Head.Customer_Code,
               r_Pln_Dx_Order_Head.Customer_Name,
               r_Pln_Dx_Order_Head.Account_Id,
               r_Pln_Dx_Order_Head.Account_Code
          From t_Pro_Terminal_Entity Pte
         Where Pte.Terminal_Code = r_Pln_Dx_Order_Head.Terminal_Code
           And Pte.Sales_Center_Code =
               r_Pln_Dx_Order_Head.Sales_Center_Code
           And Pte.Entity_Id = r_Pln_Dx_Order_Head.Entity_Id;
      Exception
        When Others Then
          p_Result := v_Value || v_Entity_Name ||
                      '，门店对应的客户不存在，请检查门店客户关系是否已维护。' || v_Nl || ',门店编码=' ||
                      r_Pln_Dx_Order_Head.Terminal_Code || ',中心编码=' ||
                      r_Pln_Dx_Order_Head.Sales_Center_Code;
          Raise v_Ccs_Exception;
      End;
    End If;*/
  
    --地址、联系人检查
    If r_Pln_Dx_Order_Head.Consignee_Addr Is Null Or
       r_Pln_Dx_Order_Head.Consignee_Addr_Code Is Null Or
       r_Pln_Dx_Order_Head.Consignee_Contact Is Null Or
       r_Pln_Dx_Order_Head.Consignee_Tel Is Null Then
      p_Result := '送装地址(Consignee_Addr)、顾客(Consignee_Contact)、顾客联系电话(Consignee_Tel)、送装地址编码(Consignee_Addr_Code)均不能为空。';
      Raise v_Ccs_Exception;
    End If;
    --收货地点检查
    If p_Result = v_Success Then
      Begin
        Select t.Full_Name
          Into v_Addr
          From t_Bd_District t
         Where t.District_Code = r_Pln_Dx_Order_Head.Consignee_Addr_Code
           And t.Active_Flag = 'Y';
        r_Pln_Dx_Order_Head.Consignee_Addr := v_Addr ||
                                              r_Pln_Dx_Order_Head.Consignee_Addr;
      Exception
        When Others Then
          p_Result := '送装地址编码(Consignee_Addr_Code)不存在或已失效。送装地址编码=' ||
                      r_Pln_Dx_Order_Head.Consignee_Addr_Code;
          Raise v_Ccs_Exception;
      End;
    End If;
  
    --样机销售，导购姓名，电话不能为空
    If r_Pln_Order_Type.Is_Business_Control = 'DXYJ' Then
      --检查门店的联系人与电话
      Begin
        Select Pte.Shopmanager_Name, Pte.Shopmanager_Phone
          Into v_Shopmanager_Name, v_Shopmanager_Phone
          From t_Pro_Terminal_Entity Pte
         Where Pte.Terminal_Code = r_Pln_Dx_Order_Head.Terminal_Code
           And Pte.Sales_Center_Code =
               r_Pln_Dx_Order_Head.Sales_Center_Code
           And pte.customer_code = r_Pln_Dx_Order_Head.Customer_Code
           And Pte.Entity_Id = r_Pln_Dx_Order_Head.Entity_Id;
        --不用强校验门店负责人为空或者门店负责人电话为空
        /*If v_Shopmanager_Name Is Null Or v_Shopmanager_Phone Is Null Then
          p_Result := v_Entity_Name || '，门店负责人为空或者门店负责人电话为空！请到门店查看与维护页面检查。门店编码=' ||
                      r_Pln_Dx_Order_Head.Terminal_Code || ',中心编码=' ||
                      r_Pln_Dx_Order_Head.Sales_Center_Code;
          Raise v_Ccs_Exception;
        End If;*/
      Exception
        When Others Then
          p_Result := '检查门店与中心、客户关系失败！请到门店查看与维护页面检查门店信息是否存在。门店编码=' ||
                      r_Pln_Dx_Order_Head.Terminal_Code || ',中心编码=' ||
                      r_Pln_Dx_Order_Head.Sales_Center_Code || ',客户编码=' || r_Pln_Dx_Order_Head.Customer_Code || v_Nl ||
                      Sqlerrm;
          Raise v_Ccs_Exception;
      End;
      
      --样机订单不能有赠品
      Select Count(1)
        Into v_Count
        From Intf_Pln_Dx_Order_Line l
       Where l.Intf_Head_Id = p_Intf_Id
         And Nvl(l.Is_Gift, '_') = 'Y';
      If v_count > 0 Then
        p_Result := '样机销售代销单不能报送赠品！';
        Raise v_Ccs_Exception;
      End If;
      
    End If;
  
    --门店地址检查
    If p_Result = v_Success Then
      Begin
        Select t.Full_Name
          Into v_Ter_Addr
          From t_Bd_District t
         Where t.District_Code = r_Pln_Dx_Order_Head.Terminal_Addr_Code
           And t.Active_Flag = 'Y';
        r_Pln_Dx_Order_Head.Terminal_Addr := v_Ter_Addr ||
                                             r_Pln_Dx_Order_Head.Terminal_Addr;
      Exception
        When Others Then
          p_Result := '门店地址编码(Terminal_Addr_Code)不存在或已失效。门店地址编码=' ||
                      r_Pln_Dx_Order_Head.Terminal_Addr_Code;
          Raise v_Ccs_Exception;
      End;
    End If;
  
    --开始生成代销单头表数据
    If p_Result = v_Success Then
      --生成订单号
      Begin
        Pkg_Pln_Pub.p_Create_Order_Number(p_Order_Number_Type => 'plnDxOrder', --单据编码规则
                                          p_Period_Id         => 0,
                                          p_Sales_Center_Id   => r_Pln_Dx_Order_Head.Sales_Center_Id,
                                          p_Entity_Id         => r_Pln_Dx_Order_Head.Entity_Id,
                                          p_Order_Number      => v_Order_Number);
      
        If Nvl(v_Order_Number, '_') = '_' Then
          p_Result := v_Entity_Name || '，获取代销单单号失败，单号编码规则：plnDxOrder。';
          Raise v_Ccs_Exception;
        End If;
      Exception
        When Others Then
          p_Result := v_Entity_Name || '，获取代销单单号失败，单号编码规则：plnDxOrder。' || v_Nl ||
                      Sqlerrm;
          Raise v_Ccs_Exception;
      End;
    
      --新增订单头
      Begin
        Select s_Pln_Dx_Order_Head.Nextval
          Into v_Dx_Order_Head_Id
          From Dual;
        v_Value := '开始插入代销单头表信息：';
        Insert Into t_Pln_Dx_Order_Head
          (Entity_Id, --主体
           Order_Head_Id, --代销单头id
           Order_Number, --代销单号
           Order_Type_Id, --订单类型id
           Order_Type_Code, --订单类型编码
           Order_Type_Name, --订单类型名称
           Order_Date, --订单日期
           Form_State, --订单状态
           Sys_Source, --来源系统
           Source_Order_Number, --来源代销单
           External_Order_Number, --外部订单号
           Identifying_Code, --验证码
           Terminal_Id, --门店id
           Terminal_Code, --门店编码
           Terminal_Name, --门店名称
           Terminal_Addr_Code, --门店地址编码
           Terminal_Addr, --门店地址
           Sales_Center_Id, --中心id
           Sales_Center_Code, --中心编码
           Sales_Center_Name, --中心名称
           Customer_Id, --客户id
           Customer_Code, --客户编码
           Customer_Name, --客户名称
           Account_Id, --账户id
           Account_Code, --账户编码
           Account_Name, --账户名称
           Consignee_Contact, --顾客姓名
           Consignee_Tel, --顾客电话
           Consignee_Addr_Code, --收货地址编码
           Consignee_Addr, --收货地址
           Expect_Install_Begin_Date, --预约送装日期起
           Expect_Install_End_Date, --预约送装日期止
           Sales_Name, --导购姓名
           Sales_Tel, --导购电话
           Appendix, --附件
           Remark, --备注
           terminal_pick_flag, --门店顾客自提
           MEASURE_START, --上门测量开始时间
           MEASURE_END, --上门测量结束时间
           vip_code, --会员编码
           Created_By, --创建人
           Creation_Date, --创建日期
           Last_Updated_By, --最后更新人
           Last_Update_Date, --最后更新日期
           SALES_CHECKUP_DATE --销量评审时间，默认都销量评审
           )
        Values
          (r_Pln_Dx_Order_Head.Entity_Id, --主体
           v_Dx_Order_Head_Id, --代销单头id
           v_Order_Number, --代销单号
           r_Pln_Order_Type.Order_Type_Id, --订单类型id
           r_Pln_Order_Type.Order_Type_Code, --订单类型编码
           r_Pln_Order_Type.Order_Type_Name, --订单类型名称
           Trunc(Sysdate),
           '01', --订单状态 01 已送审
           r_Pln_Dx_Order_Head.Sys_Source, --来源系统
           r_Pln_Dx_Order_Head.Source_Order_Number, --来源代销单号
           r_Pln_Dx_Order_Head.External_Order_Number, --外部订单号
           r_Pln_Dx_Order_Head.Identifying_Code, --验证码
           r_Pln_Dx_Order_Head.Terminal_Id, --门店id
           r_Pln_Dx_Order_Head.Terminal_Code, --门店编码
           r_Pln_Dx_Order_Head.Terminal_Name, --门店名称
           r_Pln_Dx_Order_Head.Terminal_Addr_Code, --门店地址编码
           r_Pln_Dx_Order_Head.Terminal_Addr, --门店地址
           r_Pln_Dx_Order_Head.Sales_Center_Id, --中心id
           r_Pln_Dx_Order_Head.Sales_Center_Code, --中心编码
           r_Pln_Dx_Order_Head.Sales_Center_Name, --中心名称
           r_Pln_Dx_Order_Head.Customer_Id, --客户id
           r_Pln_Dx_Order_Head.Customer_Code, --客户编码
           r_Pln_Dx_Order_Head.Customer_Name, --客户名称
           r_Pln_Dx_Order_Head.Account_Id, --账户id
           r_Pln_Dx_Order_Head.Account_Code, --账号编码
           r_Pln_Dx_Order_Head.Account_Name, --账号名称
           r_Pln_Dx_Order_Head.Consignee_Contact, --顾客姓名
           r_Pln_Dx_Order_Head.Consignee_Tel, --顾客电话
           r_Pln_Dx_Order_Head.Consignee_Addr_Code, --收货地址编码
           r_Pln_Dx_Order_Head.Consignee_Addr, --收货地址
           r_Pln_Dx_Order_Head.Expect_Install_Begin_Date, --预约送装日期起
           r_Pln_Dx_Order_Head.Expect_Install_End_Date, --预约送装日期止
           r_Pln_Dx_Order_Head.Sales_Name, --导购姓名
           r_Pln_Dx_Order_Head.Sales_Tel, --导购电话
           p_Appendix_Id, --附件ID
           r_Pln_Dx_Order_Head.Remark, --备注
           r_Pln_Dx_Order_Head.Terminal_Pick_Flag,
           r_Pln_Dx_Order_Head.Measure_Start,
           r_Pln_Dx_Order_Head.Measure_End,
           r_Pln_Dx_Order_Head.Vip_Code,
           'PKG_PLN_INTF_CCS',
           Sysdate,
           'PKG_PLN_INTF_CCS',
           Sysdate,
           Sysdate);
        --更新接口表数据
        Update Intf_Pln_Dx_Order_Head h
           Set h.Order_Number      = v_Order_Number,
               h.Order_Head_Id     = v_Dx_Order_Head_Id,
               h.Order_Type_Id     = r_Pln_Order_Type.Order_Type_Id,
               h.Order_Type_Code   = r_Pln_Order_Type.Order_Type_Code,
               h.Order_Type_Name   = r_Pln_Order_Type.Order_Type_Name,
               h.Terminal_Id       = r_Pln_Dx_Order_Head.Terminal_Id,
               h.Terminal_Name     = r_Pln_Dx_Order_Head.Terminal_Name,
               h.Sales_Center_Id   = r_Pln_Dx_Order_Head.Sales_Center_Id,
               h.Sales_Center_Name = r_Pln_Dx_Order_Head.Sales_Center_Name,
               h.Customer_Id       = r_Pln_Dx_Order_Head.Customer_Id,
               h.Customer_Code     = r_Pln_Dx_Order_Head.Customer_Code,
               h.Customer_Name     = r_Pln_Dx_Order_Head.Customer_Name,
               h.Account_Id        = r_Pln_Dx_Order_Head.Account_Id,
               h.Account_Code      = r_Pln_Dx_Order_Head.Account_Code,
               h.Account_Name      = r_Pln_Dx_Order_Head.Account_Name,
               h.Last_Updated_By   = 'CIMS_INTF',
               h.Last_Update_Date  = Sysdate
         Where h.Intf_Head_Id = p_Intf_Id;
      Exception
        When Others Then
          p_Result := v_Value || '，失败。' || v_Entity_Name || v_Nl || Sqlerrm;
          Raise v_Ccs_Exception;
      End;
    End If;
    -----------------------  接口数据行表数据校验   ----------------------------
    If p_Result = v_Success Then
      For r_Pln_Dx_Order_Line In (Select *
                                    From Intf_Pln_Dx_Order_Line l
                                   Where l.Intf_Head_Id = p_Intf_Id) Loop
        --接口数量大于0才处理
        If r_Pln_Dx_Order_Line.Quantity > 0 Then
          Begin
            v_Value := '产品编码检查：';
            Select Bi.Item_Id,
                   Bi.Defaultunit,
                   Bi.Item_Name,
                   Nvl(Bi.Sales_Main_Type, '-'),
                   Nvl(Bi.Sales_Sub_Type, '-'),
                   To_Number(Bi.Packingsize),
                   To_Number(Nvl(Bi.Grossweight, 0))
              Into v_Item_Id,
                   v_Item_Uom,
                   v_Item_Desc,
                   v_Sales_Main_Type,
                   v_Sales_Sub_Type,
                   v_Unit_Volume,
                   v_Unit_Weight
              From t_Bd_Item Bi
             Where Bi.Item_Code = r_Pln_Dx_Order_Line.Item_Code
               And Bi.Entity_Id = r_Pln_Dx_Order_Head.Entity_Id
               And Bi.Atsale_Flag = v_True
               And Bi.Active_Flag = v_True;
          Exception
            When Others Then
              p_Result := v_Value || '产品编码：' ||
                          r_Pln_Dx_Order_Line.Item_Code || '在' ||
                          v_Entity_Name ||
                          '不存在或者产品已失效，请检查产品在产在销标识和有效标识是否为Y';
              Raise v_Ccs_Exception;
          End;
          --获取产品价格
          Begin
            v_Value := '获取产品单价：';
            Pkg_Bd_Price.p_Get_Price(p_Acc_Id         => r_Pln_Dx_Order_Head.Account_Id,
                                     p_Item_Code      => r_Pln_Dx_Order_Line.Item_Code,
                                     p_Bill_Date      => To_Char(Sysdate,
                                                                 'yyyymmdd'),
                                     p_Price_List_Id  => Null,
                                     p_Entity_Id      => r_Pln_Dx_Order_Head.Entity_Id,
                                     p_Price          => v_Item_Price,
                                     p_Discount       => v_Discount,
                                     p_Month_Discount => v_Month_Discount,
                                     p_Cx_Flag        => v_Cx_Flag);
          
          Exception
            When Others Then
              v_Item_Price     := Null;
              v_Discount       := 0;
              v_Month_Discount := 0;
              v_Cx_Flag        := 'N';
          End;
          --是否必须检查价格
          If r_Pln_Order_Type.Is_Price_Check = 'Y' And v_Item_Price Is Null Then
            p_Result := '获取产品价格失败：' || v_Entity_Name || '，中心编码：' ||
                        r_Pln_Dx_Order_Head.Sales_Center_Code || '，中心名称：' ||
                        r_Pln_Dx_Order_Head.Sales_Center_Name || '，客户编码：' ||
                        r_Pln_Dx_Order_Head.Customer_Code || '，客户名称：' ||
                        r_Pln_Dx_Order_Head.Customer_Name || ',产品编码：' ||
                        r_Pln_Dx_Order_Line.Item_Code || '，单价为空。';
            Raise v_Ccs_Exception;
          End If;
          If v_Item_Price Is Not Null Then
            v_Apply_Amount := Round(v_Item_Price *
                                    r_Pln_Dx_Order_Line.Quantity,
                                    2);
          Else
            v_Apply_Amount := Null;
          End If;
          
          --处理预结算价
          If 'Y' = v_Pln_Dx_Use_Retail_Price Then
            --获取扣点
            Begin
              Select p.deduction_point
                Into v_deduction_point
                From t_Pln_Dx_Cus_Point p
               Where p.Customer_Code = r_Pln_Dx_Order_Head.Customer_Code
                 And p.Entity_Id = r_Pln_Dx_Order_Head.Entity_Id
                 And p.Sales_Main_Type = v_Sales_Main_Type;
            Exception
              When Others Then
                v_deduction_point := 0;
            End;
            v_pre_settle_price := round(r_Pln_Dx_Order_Line.Retail_Price * (1-v_deduction_point),2);
            v_pre_settle_amount := v_pre_settle_price * r_Pln_Dx_Order_Line.Quantity;
          Else
            v_pre_settle_price := v_Item_Price;
            v_pre_settle_amount := v_Apply_Amount;
          End If;
          
          --处理成交金额
          If r_Pln_Dx_Order_Line.Retail_Amount Is Not Null Then
            --成交金额=零售金额-厂家承担券-系统承担券
            v_deal_price := r_Pln_Dx_Order_Line.Retail_Amount - r_Pln_Dx_Order_Line.Manufacturer_Coupon - r_Pln_Dx_Order_Line.System_Coupon;
          End If;
          
          --接口表行数据插入业务表行
          If p_Result = v_Success Then
            Begin
              Select s_Pln_Dx_Order_Line.Nextval
                Into v_Dx_Order_Line_Id
                From Dual;
              v_Value := '开始插入代销行表数据';
              Insert Into t_Pln_Dx_Order_Line
                (Entity_Id, --主体id
                 Order_Line_Id, --订单行id
                 Order_Head_Id, --订单头id
                 Item_Id, --产品id
                 Item_Code, --产品编码
                 Item_Name, --产品名称
                 Sales_Main_Type, --营销大类
                 Sales_Sub_Type, --营销小类
                 Unit_Volume, --单位体积
                 Unit_Weight, --单位重量
                 Default_Unit, --单位
                 Quantity, --申请数量
                 Retail_Price, --零售价
                 Retail_Amount, --零售金额
                 List_Price, --直供价
                 Apply_Amount, --直供金额
                 pre_settle_price, --预结算价
                 pre_settle_amount, --预结算金额
                 deduction_point, --扣点
                 is_gift, --是否赠品
                 Manufacturer_Coupon,  --厂家承担券
                 System_Coupon,  --系统承担券
                 deal_price,   --成交价格
                 Remark,
                 Created_By,
                 Creation_Date,
                 Last_Updated_By,
                 Last_Update_Date)
              Values
                (r_Pln_Dx_Order_Head.Entity_Id, --主体
                 v_Dx_Order_Line_Id, --订单行id
                 v_Dx_Order_Head_Id, --订单头id
                 v_Item_Id, --产品id
                 r_Pln_Dx_Order_Line.Item_Code, --产品编码
                 v_Item_Desc, --产品描述
                 v_Sales_Main_Type, --营销大类
                 v_Sales_Sub_Type, --营销小类
                 v_Unit_Volume, --单位体积
                 v_Unit_Weight, --单位重量
                 v_Item_Uom, --单位
                 r_Pln_Dx_Order_Line.Quantity,
                 r_Pln_Dx_Order_Line.Retail_Price, --零售价
                 r_Pln_Dx_Order_Line.Retail_Amount, --零售金额
                 v_Item_Price, --直供价
                 v_Apply_Amount, --直供金额
                 v_pre_settle_price, --预结算价
                 v_pre_settle_amount, --预结算金额
                 v_deduction_point, --扣点
                 nvl(r_Pln_Dx_Order_Line.Is_Gift,'N'), --是否赠品
                 r_Pln_Dx_Order_Line.Manufacturer_Coupon,  --厂家承担券
                 r_Pln_Dx_Order_Line.System_Coupon, --系统承担券
                 v_deal_price,  --成交价
                 r_Pln_Dx_Order_Line.Remark, --备注
                 'PKG_PLN_INTF_CCS',
                 Sysdate,
                 'PKG_PLN_INTF_CCS',
                 Sysdate);
              --更新接口行表
              Update Intf_Pln_Dx_Order_Line l
                 Set l.Order_Line_Id    = v_Dx_Order_Line_Id,
                     l.Order_Head_Id    = v_Dx_Order_Head_Id,
                     l.Item_Id          = v_Item_Id,
                     l.Item_Name        = v_Item_Desc,
                     l.Sales_Main_Type  = v_Sales_Main_Type,
                     l.Sales_Sub_Type   = v_Sales_Sub_Type,
                     l.Unit_Volume      = v_Unit_Volume,
                     l.Unit_Weight      = v_Unit_Weight,
                     l.Default_Unit     = v_Item_Uom,
                     l.Last_Updated_By  = 'CIMS_INTF',
                     l.Last_Update_Date = Sysdate
               Where l.Intf_Line_Id = r_Pln_Dx_Order_Line.Intf_Line_Id;
            Exception
              When Others Then
                p_Result := v_Value || '失败。' || v_Nl || Sqlerrm;
                Raise v_Ccs_Exception;
            End;
          
          End If;
          --更新赠品明细
          If p_Result = v_Success Then
            For r_Pln_Dx_Order_Detail In (Select *
                                            From Intf_Pln_Dx_Order_Detail d
                                           Where d.Intf_Line_Id =
                                                 r_Pln_Dx_Order_Line.Intf_Line_Id) Loop
              Begin
                v_Value := '开始插入代销单赠品明细表数据';
                Select s_Pln_Dx_Order_Detail.Nextval
                  Into v_Dx_Order_Detail_Id
                  From Dual;
                Insert Into t_Pln_Dx_Order_Detail
                  (Entity_Id,
                   Order_Detail_Id,
                   Order_Line_Id,
                   Order_Head_Id,
                   Item_Code,
                   Item_Name,
                   Quantity,
                   Remark,
                   Created_By,
                   Creation_Date,
                   Last_Updated_By,
                   Last_Update_Date)
                Values
                  (r_Pln_Dx_Order_Head.Entity_Id,
                   v_Dx_Order_Detail_Id,
                   v_Dx_Order_Line_Id,
                   v_Dx_Order_Head_Id,
                   r_Pln_Dx_Order_Detail.Item_Code,
                   r_Pln_Dx_Order_Detail.Item_Name,
                   r_Pln_Dx_Order_Detail.Quantity,
                   r_Pln_Dx_Order_Detail.Remark,
                   'PKG_PLN_INTF_CCS',
                   Sysdate,
                   'PKG_PLN_INTF_CCS',
                   Sysdate);
                --更新接口明细
                Update Intf_Pln_Dx_Order_Detail d
                   Set d.Order_Detail_Id  = v_Dx_Order_Detail_Id,
                       d.Order_Line_Id    = v_Dx_Order_Line_Id,
                       d.Order_Head_Id    = v_Dx_Order_Head_Id,
                       d.Last_Updated_By  = 'CIMS_INTF',
                       d.Last_Update_Date = Sysdate
                 Where d.Intf_Detail_Id =
                       r_Pln_Dx_Order_Detail.Intf_Detail_Id;
              Exception
                When Others Then
                  p_Result := v_Value || '失败。' || v_Nl || Sqlerrm;
                  Raise v_Ccs_Exception;
              End;
            End Loop;
          
          End If;
          --更新行的赠品明细
          Update t_Pln_Dx_Order_Line l
             Set l.Detail_Qty =
                 (Select Count(1)
                    From t_Pln_Dx_Order_Detail d
                   Where d.Order_Line_Id = v_Dx_Order_Line_Id)
           Where l.Order_Line_Id = v_Dx_Order_Line_Id;
        End If;
      End Loop;
    End If;
    If p_Result = v_Success Then
      --更新接口状态
      Begin
        v_Value := '更新接口表状态：';
        Update Intf_Pln_Dx_Order_Head h
           Set h.Intf_State       = 'S',
               h.Error_Meg        = 'SUCCESS',
               h.Last_Updated_By  = 'CIMS_INTF',
               h.Last_Update_Date = Sysdate
         Where h.Intf_Head_Id = p_Intf_Id;
      Exception
        When Others Then
          p_Result := v_Value || '失败，接口表ID ' || p_Intf_Id || Sqlerrm;
          Raise v_Ccs_Exception;
      End;
      --返回单号
      p_Result_Num := v_Order_Number;
    
    End If;
  Exception
    When v_Ccs_Exception Then
      Rollback;
      p_Result := '失败：' || p_Result;
      Update Intf_Pln_Dx_Order_Head h
         Set h.Intf_State       = 'E',
             h.Error_Meg        = p_Result,
             h.Last_Updated_By  = 'CIMS_INTF',
             h.Last_Update_Date = Sysdate
       Where h.Intf_Head_Id = p_Intf_Id;
      v_Value := Pkg_Bd.f_Add_Error_Log('pkg_pln_intf_ccs.p_Create_Intf_Dx_Order',
                                        1000,
                                        p_Intf_Id || '|' || p_Result);
    When Others Then
      Rollback;
      p_Result := '失败：' || p_Result || v_Nl || Sqlerrm;
      Update Intf_Pln_Dx_Order_Head h
         Set h.Intf_State       = 'E',
             h.Error_Meg        = p_Result,
             h.Last_Updated_By  = 'CIMS_INTF',
             h.Last_Update_Date = Sysdate
       Where h.Intf_Head_Id = p_Intf_Id;
      v_Value := Pkg_Bd.f_Add_Error_Log('pkg_pln_intf_ccs.p_Create_Intf_Dx_Order',
                                        1000,
                                        p_Intf_Id || '|' || p_Result);
  End p_Create_Intf_Dx_Order;
end PKG_PLN_INTF_CCS;
/

