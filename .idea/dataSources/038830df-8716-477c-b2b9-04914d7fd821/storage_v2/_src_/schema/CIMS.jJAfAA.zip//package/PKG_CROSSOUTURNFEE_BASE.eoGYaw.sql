create package PKG_CROSSOUTURNFEE_BASE AS

 FUNCTION F_T_AR_CONF_INITIAL
  --------------------   根据主体ID、营销中心ID、客户ID查询应收配置  -----------------
  --------------------   SHIP_FLAG：发货确认；RECEIVE_FLAG：收货确认；CHECKED_ACCOUNT_FLAG：客户对账   -----------------------
 (
    P_ENTITY_ID                                      IN T_AR_CONF.ENTITY_ID%TYPE, --主体ID
    P_SALES_CENTER_ID                           IN T_AR_CONF.SALES_CENTER_ID%TYPE, --营销中心ID
    P_CUSTOMER_ID                               IN T_AR_CONF.CUSTOMER_ID%TYPE, --客户ID
    P_ERP_OU_ID                                    IN T_AR_CONF.ERP_OU%TYPE --ERP_OU_ID
 ) RETURN T_AR_CONF.AR_CONF_INITIAL%TYPE;

end PKG_CROSSOUTURNFEE_BASE;
/

