create view V_CUSTOMER_OU as
select ERPOU_ID,
       ENTITY_ID,
       CUSTOMER_ID,
       CUSTOMER_CODE,
       ERPOU,
       COUNTRY,
       PROVINCE,
       ADDRESS,
       ACTIVE_FLAG,
       CREATED_BY,
       CREATION_DATE,
       LAST_UPDATE_DATE,
       LAST_UPDATE_BY,
       LAST_INTERFACE_DATE,
       SIEBEL_ERPOU_ID,
       SIEBEL_CUSTOMER_ID,
       PRE_FIELD_01,
       PRE_FIELD_02,
       PRE_FIELD_03,
       PRE_FIELD_04,
       PRE_FIELD_05,
       PRE_FIELD_06
  from T_CUSTOMER_OU with read only
/

comment on column V_CUSTOMER_OU.ERPOU_ID is 'ERPOU_ID'
/

comment on column V_CUSTOMER_OU.ENTITY_ID is '主体ID'
/

comment on column V_CUSTOMER_OU.CUSTOMER_ID is '客户ID'
/

comment on column V_CUSTOMER_OU.CUSTOMER_CODE is '客户编码'
/

comment on column V_CUSTOMER_OU.ERPOU is '对应ERPOU'
/

comment on column V_CUSTOMER_OU.COUNTRY is '国家(ISO国家数字编码)'
/

comment on column V_CUSTOMER_OU.PROVINCE is '省份(省份代码)'
/

comment on column V_CUSTOMER_OU.ADDRESS is '由国家、省份、地级市、县区、乡镇拼接而成'
/

comment on column V_CUSTOMER_OU.ACTIVE_FLAG is '是否有效(Y/N)'
/

comment on column V_CUSTOMER_OU.CREATED_BY is '创建人'
/

comment on column V_CUSTOMER_OU.CREATION_DATE is '创建日期'
/

comment on column V_CUSTOMER_OU.LAST_UPDATE_DATE is '最后修改时间'
/

comment on column V_CUSTOMER_OU.LAST_UPDATE_BY is '最后修改人'
/

comment on column V_CUSTOMER_OU.LAST_INTERFACE_DATE is '最后同步时间'
/

comment on column V_CUSTOMER_OU.SIEBEL_ERPOU_ID is '主数据ERPOU_ID'
/

comment on column V_CUSTOMER_OU.SIEBEL_CUSTOMER_ID is '主数据客户ID'
/

comment on column V_CUSTOMER_OU.PRE_FIELD_01 is '预留字段1'
/

comment on column V_CUSTOMER_OU.PRE_FIELD_02 is '预留字段2'
/

comment on column V_CUSTOMER_OU.PRE_FIELD_03 is '预留字段3'
/

comment on column V_CUSTOMER_OU.PRE_FIELD_04 is '预留字段4'
/

comment on column V_CUSTOMER_OU.PRE_FIELD_05 is '预留字段5'
/

comment on column V_CUSTOMER_OU.PRE_FIELD_06 is '预留字段6'
/

