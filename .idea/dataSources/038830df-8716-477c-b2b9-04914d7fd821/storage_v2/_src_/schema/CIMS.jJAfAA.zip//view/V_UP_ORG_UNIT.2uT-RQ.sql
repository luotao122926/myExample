create view V_UP_ORG_UNIT as
select t.unit_id , --单位ID
       t.code unit_code,  --单位编码
       t.name unit_name, --单位名称
       xt.ext_textbox short_name,  --单位简称
       xt.ext_unit_ename eng_name,  --英文名
       t.type_code, --单位编码（事业部：BU,营销区域：SR ，营销中心：SC）
       t.par_unit_id, --上级单位ID
       t.entity_id,
       t.created_by,
       t.creation_date,
       t.last_updated_by,
       t.last_update_date,
       t.level_seq, --层级
       t.level_num, --层级码
       t.full_name --单位全称
  from up_org_unit t, up_org_unit_ext xt
  where t.id = xt.id
 order by t.level_num
/

