create view V_CREDIT_CONTACT_AMOUNT_DELAY as
SELECT 'delay' Business_ID ,  --业务类型
       DELAY.BILL_ID BILL_ID, --单据id
       DELAY.Bill_Num  BILL_NUM, --单据编号
       DELAY.BILL_DATE BILL_DATE, --单据日期
       DELAY.BILL_STATUS , --单据状态
       DELAY.Bill_Type_Id , --单据类型id
       TO_CHAR(DELAY.Bill_Type_Id) BILL_TYPE_CODE , --单据类型编码
       decode(DELAY.Bill_Type_Id,1,'常规铺底单据',
                                 2,'超额铺底单据',
                                 3,'临时铺底单据') bill_type_name, --单据类型名称
       DELAY.Last_Approval_Time settle_date, --单据结算日期
       null account_date, --客户对帐日期
       null checked_account_date, --财务对帐日期
       DELAY.Customer_Id, --客户id
       DELAY.Customer_Code, --客户编码
       DELAY.Customer_Name, --客户名称
       DELAY.Account_Id,  --账户ID
       DELAY.Account_Code, --账户编码
       DELAY.Account_Name, --账户名称
       PKG_CREDIT_TOOLS.FUN_GET_CODELIST(cus_main_type.cooperation_model_id,
                                         'MIDEA_MARKET_MODE',
                                         2) customer_type, --客户类型
       DELAY.Entity_Id, --主体
       DELAY.Sales_Center_Id, --营销中心id
       DELAY.Sales_Center_Code, --营销中心编码
       DELAY.Sales_Center_Name, --营销中心名称
       DELAY.Sales_Region_Id, --销售区域ID
       DELAY.Sales_Region_name, --销售区域名称
       null  brand_code, --品牌编码
       null  brand_name, --品牌名称
       DELAY.sales_main_type  sales_main_type, --营销大类编码
       item_class.CLASS_NAME  sales_main_type_name, --营销大类名称
       --soh.small_category,                   --营销小类
       null                        project_num, --批文编码
       null                        project_name, --批文名称
       NULL                        cash_code, --票据号
       NULL                        cash_date, --票据日期
       NULL                        due_date, --到期日期
       null                        invoice_num_list, --发票号串（税控发票）
       null                        invoice_date, --发票日期（税控日期）
       DELAY.Sales_Year_Id, --销售年度ID
       DELAY.Sales_Year_Id sales_year, --销售年度
       to_char(DELAY.DELAYPAY_TYPE)  src_type, --来源类型
       decode(DELAY.DELAYPAY_TYPE,1,'铺底（跨月）',2,'铺底（不跨月）',
                                  3,'三方铺底',
                                  4,'临时电汇',
                                  5,'运输赔偿',
                                  6,'备货转销售',
                                  7,'冻结额度',
                                  8,'冻结扣率折让',
                                  9,'其他',
                                  10,'冻结保证金') src_type_name, --来源类型名称
       TO_CHAR(DELAY.DELAYPAY_TYPE)  src_bill_num, --来源号
       null discount_type_id, --折扣id
       null discount_type_name, --折扣名称
       null                        discount_item, --折让项目
       null                        discount_mode, --折让方式
        (case when DELAY.Bill_Status = 3  --审批通过
             and nvl(DELAY.DUE_BY,'0') = '0' --没有到期
            then 'Y' ELSE 'N' END)  settle_flag, --是否结算
       nvl(DELAY.Requis_Amount,0) list_amount, --列表金额
       (nvl(DELAY.Requis_Amount,0) - nvl(DELAY.Approval_Amount,0)) discount_amount, --折让金额
       --中央空调项目，垫资类型，在做信用重算的时候
       (case when DELAY.Bill_Type_Id = '3'  --临时铺底
                  and DELAY.DELAYPAY_TYPE = '11' --临时铺底类型为11的单据，重算结算金额的时候，需要减去工程已核销金额
              then  (nvl(DELAY.Approval_Amount,0)- NVL(DELAY.PROJ_SETTLED_AMOUNT,0))
             ELSE nvl(DELAY.Approval_Amount,0) END)  settle_amount, --结算金额

       0 SOLUTION_PAY_AMOUNT, --三方承兑已解付金额
       DELAY.Remark, --备注
       DELAY.Creation_Time creation_date, --录入日期
       1                        sales_receipt,
       1 cnt,
       null fund_ctrl_mode, --控制方式
       null created_mode,  --制单方式
       decode(DELAY.Delaypay_Type,3,'Y','N') draft_flag, --是否为承兑
       null audit_flag, --审核标识
       Null src_type_id,
       Null src_type_code,
       null import_erp,  --是否ERP引入
       DELAY_HEAD.SOURCE_SYS,
       DELAY_HEAD.SOURCE_TYPE,
       DELAY_HEAD.SOURCE_CODE
       ,CAST(NULL AS VARCHAR2(128)) AS discount_type--折让方式 add by liangym2 20171030
  FROM T_CREDIT_DELAYPAY          DELAY, --铺底申请表
       T_CREDIT_DELAYPAY_HEAD     DELAY_HEAD,--铺底头表
       T_CUSTOMER_SALES_MAIN_TYPE cus_main_type, --客户营销大类关系表
       v_bd_item_class_ims        item_class --营销大类信息
 WHERE DELAY.customer_id = cus_main_type.custom_id
   AND DELAY_HEAD.BILL_HEAD_ID = DELAY.BILL_HEAD_ID
   AND DELAY.SALES_MAIN_TYPE = cus_main_type.sales_main_type_code
   AND DELAY.entity_id = cus_main_type.entity_id
   and DELAY.sales_main_type = item_class.CLASS_CODE
   AND item_class.CLASS_TYPE = 'M'
   AND DELAY.Entity_Id = ITEM_CLASS.ENTITY_ID
/

