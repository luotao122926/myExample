create view T_INV_TRANSACTION_HISTORY_V as
select  a.ENTITY_ID
       ,a.TRANSACTION_ID
       ,a.TRANSACTION_DATE
       ,a.PERIOD_ID
       ,a.PERIOD_NAME
       ,a.SOURCE_TYPE_ID
       ,a.BILL_TYPE_ID
       ,a.BUSINESS_STATE
       ,a.TRANSACTION_TYPE_ID
       ,a.ACTION_TYPE
       ,a.BUSINESS_NUM
       ,a.BUSINESS_HEADER_ID
       ,a.BUSINESS_LINE_ID
       ,a.BUSINESS_LINE_DETAIL_ID
       ,a.ITEM_ID
       ,a.ITEM_CODE
       ,a.ITEM_NAME
       ,a.TRANSACTION_UOM
       ,a.INVENTORY_ID
       ,a.INVENTORY_CODE
       ,a.INVENTORY_NAME
       ,a.TO_INVENTORY_ID
       ,a.TO_INVENTORY_CODE
       ,a.TO_INVENTORY_NAME
       ,a.FROM_INVENTORY_ID
       ,a.FROM_INVENTORY_CODE
       ,a.FROM_INVENTORY_NAME
       ,a.TRANSACTION_QUANTITY
       ,a.CREATED_BY
       ,a.CREATION_DATE
       ,a.LAST_UPDATED_BY
       ,a.LAST_UPDATE_DATE
       ,a.REMARK,
        a.ORIGINAL_BILL_NUM,
        a.TERMINAL_CODE,
        a.TERMINAL_NAME,
       c.class_name itemMName,--大类名称
       d.class_name itemSName ,--小类名称
       zt.code_name djzt,
       djy.SOURCE_TYPE_NAME,
       billName.BILL_TYPE_NAME,
       wl.TRANSACTION_TYPE_NAME,
       hd.code_name hd  ,
       c.class_code itemM,--营销大类编码
       d.class_code itemS,--营销小类编码
       zx.UNIT_ID ,--单位
       zx.INVENTORY_TYPE ,--仓库类型
       sc.sales_center_name,
       sc.sales_center_code
       from T_INV_TRANSACTION_HISTORY a,
            t_bd_item b,
            t_bd_item_class c,
            t_bd_item_class d,
            up_codelist zt,
            T_INV_SOURCE_TYPES djy,
            T_INV_BILL_TYPES billName,
            T_INV_TRANSACTION_TYPES wl,
            up_codelist hd,T_INV_INVENTORIES zx,
            V_BD_SALES_CENTER sc
 where a.item_id = b.item_id and
       b.SALES_MAIN_TYPE = c.class_code and

       d.parentc_lass_id=(select item_class_id
                           from t_bd_item_class
                          where class_code=b.SALES_MAIN_TYPE
                           and entity_id=b.entity_id) and

       b.SALES_SUB_TYPE = d.class_code and a
       .BUSINESS_STATE = zt.code_value and
       zt.CODETYPE = 'BD_BILL_STATUS' and
       a.SOURCE_TYPE_ID = djy.SOURCE_TYPE_ID and
       a.BILL_TYPE_ID=billName.BILL_TYPE_ID and
       a.TRANSACTION_TYPE_ID=wl.TRANSACTION_TYPE_ID and
       a.ACTION_TYPE=hd.code_value and
       hd.CODETYPE = 'INV_ACTION_TYPE'  and
       a.INVENTORY_CODE =zx.INVENTORY_CODE and
       zx.unit_id=sc.sales_center_id
       and a.entity_id = b.entity_id
       and a.entity_id = c.entity_id
       and a.entity_id = d.entity_id
       and a.entity_id = djy.entity_id
       and a.entity_id = billName.Entity_Id
       and a.entity_id = wl.entity_id
       and a.entity_id = zx.entity_id
       and a.entity_id = sc.entity_id
/

