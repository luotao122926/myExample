create PACKAGE PKG_CREDIT_AR AS
  -----------------------------------------------------------------------------
  --    客户款项销售单金额冻结    --add by liangym2
  -----------------------------------------------------------------------------
  PROCEDURE PRC_SO_AMOUNT_FREEZE(IN_ENTITY_ID       IN NUMBER, --主体ID
                                 IS_PERIOD_NAME     IN VARCHAR2, --期间名称
                                 IS_LAST_UPDATED_BY IN VARCHAR2, --冻结
                                 OS_MESSAGE         OUT VARCHAR2, --返回提示信息
                                 OS_PRE_FIELD01     OUT VARCHAR2, --预留参数
                                 OS_PRE_FIELD02     OUT VARCHAR2, --预留参数
                                 OS_PRE_FIELD03     OUT VARCHAR2, --预留参数
                                 OS_PRE_FIELD04     OUT VARCHAR2, --预留参数
                                 OS_PRE_FIELD05     OUT VARCHAR2, --预留参数
                                 OS_PRE_FIELD06     OUT VARCHAR2);
END PKG_CREDIT_AR;
/

