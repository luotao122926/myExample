create package PKG_PG is

  -- Author  : WILDWIND
  -- Created : 2015/1/15 15:33:10
  -- Purpose : 工程机模块存储过程


  -- 初始化区域与中心对应关系表
  PROCEDURE init_pg_area_org(P_ENTITY_ID in number,
                             P_USER_CODE in varchar2,
                             P_DISTRICT_LEVEL in number,
                             P_RESULT out varchar2
                             );

  -- 根据地点编码获取对应的组织信息
  -- 根据地市树从叶子节点向上遍历，若遍历到对应关系即返回，若未遍历
  -- 到对应关系返-1
    PROCEDURE get_distree_org( P_ENTITY_ID in number,
                             P_DISTRICT_CODE in varchar2,
                             P_UNIT_ID out number,
                             P_CENTER_CODE out varchar2,
                             P_CNETER_NAME out varchar2,
                             P_ERR_MESSAGE out varchar2
                             );
   
  
   ----------------------------------------------------------------------
  -- Author  : WANGCONG
  -- Created : 2017/09/26
  -- Purpose : 每日更新工程机占比
  ----------------------------------------------------------------------
  Procedure P_PG_APPLY_AMOUNT_SCALE(P_MESSAGE OUT VARCHAR2);
  
     ----------------------------------------------------------------------
  -- Author  : WANGCONG
  -- Created : 2017/11/08
  -- Purpose : 自动冻结工程机批文
  ----------------------------------------------------------------------
  Procedure P_PG_APPLY_PRICE_FREEZE(P_MESSAGE OUT VARCHAR2);


end PKG_PG;
/

