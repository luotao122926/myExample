create Package Pkg_Inv_So_Po Is

  -- Author  : SUU
  -- Created : 2015-07-30 17:03:42
  -- Purpose : 销售单触发生成中转单


  --------------------------------------------------------------------------
  --Author: sushu
  --Purpose:销售单触发生成中转单
  --------------------------------------------------------------------------
  Procedure p_so_create_to_intf(p_So_Head_Id In Number, --销售单头ID
                                p_User_Code In varchar2, --账户编码
                                p_Intf_Head_Id     Out varchar2,   --生成的接口头ID
                                p_Result     Out varchar2); --返回的结果


  --------------------------------------------------------------------------
  --Author: sushu
  -- Created : 2015-08-11
  --Purpose:接口表触发生成中转单
  --------------------------------------------------------------------------
  Procedure p_intf_create_to_po(p_Intf_Head_Id In Number, --接口表头ID
                                p_User_Code    In varchar2, --账户编码
                                p_Po_Num       Out varchar2, --生成的中转单号
                                p_Po_Head_Id   Out varchar2,  --生成的中转单ID
                                p_Result       Out varchar2); --返回的结果

  --------------------------------------------------------------------------
  --Author: sushu
  -- Created : 2015-09-16
  --Purpose:自治事务，更新接口表的状态以及错误信息
  --------------------------------------------------------------------------
  function F_ADD_ERROR_LOG(p_Intf_Head_Id  in varchar2, --接口头ID
                           p_Result in varchar2) --错误信息
    Return Varchar2;



  --------------------------------------------------------------------------
  --Author: sushu
  -- Created : 2015-10-26
  --Purpose:大物流接口表触发生成中转单，区分推式、拉式
  --------------------------------------------------------------------------
  Procedure p_intf_logis_create_to_po(p_Intf_Head_Id In Number, --接口表头ID
                                      p_User_Code    In varchar2, --账户编码
                                      p_Po_Num       Out varchar2, --生成的中转单号
                                      p_Po_Head_Id   Out varchar2,  --生成的中转单ID
                                      p_Result       Out varchar2); --返回的结果



  --------------------------------------------------------------------------
  --Author: sushu
  -- Created : 2015-10-26
  --Purpose:接大物流口表触发生成中转单，推式需要找原单的
  --------------------------------------------------------------------------
  Procedure p_find_order_create_to_po(p_Intf_Head_Id In Number, --接口表头ID
                                      p_User_Code    In varchar2, --账户编码
                                      p_Po_Num       Out varchar2, --生成的中转单号
                                      p_Po_Head_Id   Out varchar2,  --生成的中转单ID
                                      p_Result       Out varchar2); --返回的结果


  --------------------------------------------------------------------------
  --Author: sushu
  -- Created : 2015-11-20
  --Purpose:自治事务，插入接口表
  --------------------------------------------------------------------------
  function F_ERROR_LOG(p_Result in varchar2) --错误信息
    Return Varchar2;
    
    
  --------------------------------------------------------------------------
  --Author: sushu
  -- Created : 2016-08-23
  --Purpose:中转单关联交易校验产品是否分配有效的供应商
  --------------------------------------------------------------------------
  /*Procedure p_item_vendor_relation(p_Po_Num In varchar2, --中转单号
                                   p_Entity_Id In Number, --主体
                                   p_Result       Out varchar2); --返回的结果
*/


  --------------------------------------------------------------------------
  --author:sushu
  --created:2017-04-24
  --purpose:CIMS-电商，生成调拨单
  --------------------------------------------------------------------------
  Procedure p_intf_ecm_inv_to_trsf(p_Intf_Head_Id   In Number,--接口头ID
                                   p_Trsf_Order_Num Out Varchar2,--返回调拨单号
                                   P_Result         Out varchar2);--返回结果

End Pkg_Inv_So_Po;
/

