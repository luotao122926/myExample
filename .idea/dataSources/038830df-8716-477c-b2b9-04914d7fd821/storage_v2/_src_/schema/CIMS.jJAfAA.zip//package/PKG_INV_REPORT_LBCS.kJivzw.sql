create Package PKG_INV_REPORT_LBCS Is
  --生成期末库存量
  Procedure INV_REPORT_LBCS_INSERT(p_batch_id     Number, --批次ID
                                   p_inventory_id Number, --仓库
                                   p_end_date     Date, --期末日期
                                   p_user         Varchar2, --创建人
                                   p_return_code  Out Varchar2, --返回代码，OK表示成功，其他表示错误
                                   p_return_msg   Out Varchar2 --返回信息
                                   );
  --删除期末库存量
  Procedure INV_REPORT_LBCS_DELETE(p_batch_id    Number, --批次ID
                                   p_return_code Out Varchar2, --返回代码，OK表示成功，其他表示错误
                                   p_return_msg  Out Varchar2 --返回信息
                                   );
end PKG_INV_REPORT_LBCS;
/

