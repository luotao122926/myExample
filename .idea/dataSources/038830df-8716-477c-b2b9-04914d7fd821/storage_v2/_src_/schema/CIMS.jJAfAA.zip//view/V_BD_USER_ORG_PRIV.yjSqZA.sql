create view V_BD_USER_ORG_PRIV as
select distinct g."USER_ID",g."USER_CODE",g."USER_NAME",g."UNIT_ID",g."UNIT_CODE",g."LEVEL_NUM",g."UNIT_NAME",g."ENTITY_ID"
  from (
  --默认组织权限
  select *
    from v_bd_user_org_priv_default
  union all
  --根据独立授权客户推算出的中心
  select *
    from v_bd_user_org_priv_addbycust
  union all
  --根据独立授权账户推算出的客户进一步推算出的中心
  select * from v_bd_user_org_priv_addbyacc
        ) g

/

