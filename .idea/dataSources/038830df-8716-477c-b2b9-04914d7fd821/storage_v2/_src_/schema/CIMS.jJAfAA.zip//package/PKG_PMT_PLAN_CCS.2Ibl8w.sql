create PACKAGE PKG_PMT_PLAN_CCS IS
  ----------------------------------------------------------------------
  -- Author  : liyuanji
  -- Created : 2015-08-01
  -- Purpose : 推广物料月需求计划接口（CCS）
  --1、C-IMS对CCS同步过来的月计划订单进行校验，有一行失败则整张订单都失败。
  --2、C-IMS将校验结果记录接口状态，同时记录错误信息。CCS根据接口状态进行后续处理，如校验失败CCS可根据错误信息修正后重新写接口表。
  ----------------------------------------------------------------------
  /*
   推广物料接口函数
  */
  PROCEDURE P_INTF_PMT_PLAN( I_PLAN_HEAD_ID         IN NUMBER, --接口头ID
                             O_RESULT               OUT Varchar2, --返回错误码
                             O_RESULT_MSG           OUT Varchar2 --返回错误信息
                             );


  ----------------------------------------------------------------------

END PKG_PMT_PLAN_CCS;
/

