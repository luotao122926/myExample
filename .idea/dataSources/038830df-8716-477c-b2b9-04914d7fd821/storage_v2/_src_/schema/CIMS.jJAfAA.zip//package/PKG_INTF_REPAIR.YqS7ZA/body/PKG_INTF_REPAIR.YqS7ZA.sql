create package body PKG_INTF_REPAIR is

  ------
  --- 纠错逻辑
  --- CIMS：状态为成功，但实际上ERP不成功，则自动纠正为新建，重推
  --- 如果最近1-30天内提交的单据，CIMS状态为不成功，但ERP实际为成功，则自动纠正为成功
  --- ERP库存事务日期，取60天以内的库存事务进行校验
  ------

  -- 日期范围
  v_pre_date1  number := 1;
  v_pre_date10 number := 10;
  v_pre_date30 number := 30;
  v_pre_date60 number := 60;

  -- Function and procedure implementations
  -- 订单自动纠错
  -- 01:SO生成，ERP已成功，CIMS接口未成功
  -- 02:SO生成，ERP未成功，CIMS接口状态为成功
  -- 03:SO变更，ERP成功，CIMS接口未成功
  -- 04:SO变更，ERP未成功，CIMS接口状态为成功
  procedure p_intf_oe_repair is
    -- 查询待修复接口数据-SO生成
    cursor c_bill_oe01 is
      select o.order_number,
             o.org_id,
             o.orig_sys_document_ref document_ref_id,
             o.oe_headers_id,
             o.gen_trx_status,
             o.update_trx_status
        from cims.intf_oe_headers_iface_all o
       where nvl(o.gen_trx_status, 'N') <> 'S'
         and nvl(o.post_date, trunc(sysdate) - 2) < trunc(sysdate) - 1
         and exists (select 1
                from apps.oe_order_headers_all@mdims2mderp a
               where a.order_number = o.order_number
                 and a.org_id = o.org_id
                 and a.ordered_date < trunc(sysdate));
  
    cursor c_bill_oe02 is
      select o.order_number,
             o.org_id,
             o.orig_sys_document_ref document_ref_id,
             o.oe_headers_id,
             o.gen_trx_status,
             o.update_trx_status
        from cims.intf_oe_headers_iface_all o
       where nvl(o.gen_trx_status, 'N') <> 'N'
         and not exists (select 1
                from apps.oe_order_headers_all@mdims2mderp a
               where a.order_number = o.order_number
                 and a.org_id = o.org_id);
  
    -- 查询待修复接口数据-SO变更
    cursor c_bill_oe03 is
      select o.order_number,
             o.org_id,
             o.orig_sys_document_ref document_ref_id,
             o.oe_headers_id,
             o.gen_trx_status,
             o.update_trx_status
        from cims.intf_oe_headers_iface_all o
       where nvl(o.update_trx_status, 'N') <> 'S'
         and nvl(o.post_date, trunc(sysdate) - 2) < trunc(sysdate) - 1
         and exists (select 1
                from apps.oe_order_headers_all@mdims2mderp a
               where a.order_number = o.order_number
                 and a.org_id = o.org_id
                 and a.flow_status_code in ('BOOKED', 'CLOSED')
                 and a.booked_date < trunc(sysdate - 1));
  
    cursor c_bill_oe04 is
      select o.order_number,
             o.org_id,
             o.orig_sys_document_ref document_ref_id,
             o.oe_headers_id,
             o.gen_trx_status,
             o.update_trx_status
        from cims.intf_oe_headers_iface_all o
       where nvl(o.update_trx_status, 'N') = 'S'
         and not exists
       (select 1
                from apps.oe_order_headers_all@mdims2mderp a
               where a.order_number = o.order_number
                 and a.org_id = o.org_id
                 and a.flow_status_code in ('BOOKED', 'CLOSED'));
  
  begin
    -- 修复SO生成:补充ID及修复接口状态
    for bill01 in c_bill_oe01 loop
      -- 更新明细-ERP line_id
      update cims.t_so_line_detail ld
         set ld.erp_so_line_id = (select line_id
                                    from apps.oe_order_headers_all@mdims2mderp a,
                                         apps.oe_order_lines_all@mdims2mderp   al
                                   where a.header_id = al.header_id
                                     and a.order_number = bill01.order_number
                                     and a.org_id = bill01.org_id
                                     and al.attribute1 =
                                         to_char(ld.so_line_detail_id))
       where ld.so_header_id = bill01.document_ref_id;
    
      -- 更新头表-ERP head_id
      update cims.t_so_header so
         set so.erp_so_id   = (select header_id
                                 from apps.oe_order_headers_all@mdims2mderp a
                                where a.order_number = bill01.order_number
                                  and a.org_id = bill01.org_id),
             so.erp_so_code = bill01.order_number
       where so.so_header_id = bill01.document_ref_id;
    
      -- 需补充line_id
      update cims.intf_oe_lines_iface_all intf_l
         set intf_l.line_id = (select line_id
                                 from apps.oe_order_headers_all@mdims2mderp a,
                                      apps.oe_order_lines_all@mdims2mderp   al
                                where a.header_id = al.header_id
                                  and a.order_number = bill01.order_number
                                  and a.org_id = bill01.org_id
                                  and al.attribute1 = intf_l.attribute1)
       where intf_l.oe_headers_id = bill01.oe_headers_id;
    
      -- 正向销售需补充header_id
      update cims.intf_oe_headers_iface_all intf
         set intf.header_id = (select header_id
                                 from apps.oe_order_headers_all@mdims2mderp a
                                where a.order_number = bill01.order_number
                                  and a.org_id = bill01.org_id)
       where 1 = 1
         and intf.order_number = bill01.order_number
         and intf.org_id = bill01.org_id
         and intf.biz_src_bill_type_code in ('1001', '1004');
    
      -- 更新接口状态
      update cims.intf_oe_headers_iface_all intf
         set intf.gen_trx_status        = 'S',
             intf.status                = 'S',
             intf.update_trx_send_times = 1,
             intf.error_flag            = 'N',
             intf.error_msg             = '系统自动修复生成-成功-' ||
                                          intf.gen_trx_status ||
                                          to_char(sysdate,
                                                  '-yyyymmdd-hh24:mi:ss')
       where 1 = 1
         and intf.order_number = bill01.order_number
         and intf.org_id = bill01.org_id;
    
    /*dbms_output.put_line('order_number:' || bill01.order_number ||
                                   ',系统自动修复生成-成功-' ||
                                   bill01.gen_trx_status ||
                                   to_char(sysdate, '-yyyymmdd-hh24:mi:ss'));*/
    
    end loop;
  
    commit;
  
    -- 修复接口状态为N-未处理成功
    for bill02 in c_bill_oe02 loop
      -- 更新接口状态
      update cims.intf_oe_headers_iface_all intf
         set intf.gen_trx_status        = 'N',
             intf.gen_request_id        = null,
             intf.gen_trx_send_times    = 1,
             intf.update_trx_status     = null,
             intf.update_request_id     = null,
             intf.update_trx_send_times = 1,
             intf.status                = 'N',
             intf.error_flag            = 'N',
             intf.error_msg             = '系统自动修复生成-重推-' ||
                                          intf.gen_trx_status ||
                                          to_char(sysdate,
                                                  '-yyyymmdd-hh24:mi:ss')
       where 1 = 1
         and intf.order_number = bill02.order_number
         and intf.org_id = bill02.org_id
         and nvl(intf.gen_trx_status, 'N') <> 'N'
         and not exists (select 1
                from apps.oe_order_headers_all@mdims2mderp a
               where a.order_number = intf.order_number
                 and a.org_id = intf.org_id);
    
    /*dbms_output.put_line('order_number:' || bill02.order_number ||
                                   ',系统自动修复生成-重推-' ||
                                   bill02.gen_trx_status ||
                                   to_char(sysdate, '-yyyymmdd-hh24:mi:ss'));*/
    end loop;
  
    commit;
  
    -- 修复接口状态为S
    for bill03 in c_bill_oe03 loop
      -- 更新接口状态
      update cims.intf_oe_headers_iface_all intf
         set intf.update_trx_status = 'S',
             intf.status            = 'S',
             intf.error_flag        = 'N',
             intf.error_msg         = '系统自动修复变更-成功-' ||
                                      intf.update_trx_status ||
                                      to_char(sysdate,
                                              '-yyyymmdd-hh24:mi:ss')
       where 1 = 1
         and intf.order_number = bill03.order_number
         and intf.org_id = bill03.org_id
         and nvl(intf.update_trx_status, 'N') <> 'S'
         and exists
       (select 1
                from apps.oe_order_headers_all@mdims2mderp a
               where a.order_number = intf.order_number
                 and a.org_id = intf.org_id
                 and a.flow_status_code in ('BOOKED', 'CLOSED'));
    
    /*dbms_output.put_line('order_number:' || bill03.order_number ||
                                   ',系统自动修复变更-成功-' ||
                                   bill03.update_trx_status ||
                                   to_char(sysdate, '-yyyymmdd-hh24:mi:ss'));*/
    end loop;
  
    commit;
  
    -- 修复接口状态为S
    for bill04 in c_bill_oe04 loop
      -- 更新接口状态
      update cims.intf_oe_headers_iface_all intf
         set intf.update_trx_status = 'N',
             intf.status            = 'S',
             intf.update_request_id = null,
             intf.error_flag        = 'N',
             intf.error_msg         = '系统自动修复变更-' ||
                                      intf.update_trx_status ||
                                      to_char(sysdate,
                                              '-yyyymmdd-hh24:mi:ss')
       where 1 = 1
         and intf.order_number = bill04.order_number
         and intf.org_id = bill04.org_id
         and nvl(intf.update_trx_status, 'N') <> 'N'
         and not exists
       (select 1
                from apps.oe_order_headers_all@mdims2mderp a
               where a.order_number = intf.order_number
                 and a.org_id = intf.org_id
                 and a.flow_status_code in ('BOOKED', 'CLOSED'));
    
    /*dbms_output.put_line('order_number:' || bill04.order_number ||
                                   ',系统自动修复变更-重推-' ||
                                   bill04.update_trx_status ||
                                   to_char(sysdate, '-yyyymmdd-hh24:mi:ss'));*/
    end loop;
  
    commit;
  
  end;

  -- 库存事务接口自动纠错
  -- 01:CIMS不成功，核对ERP是否成功，如果成功则标记为成功，否则不作处理-不含盘点单
  -- 02:CIMS不为新建，核对ERP是否成功，如果不成功则标记新建，否则不作处理-不含盘点单
  -- 03:CIMS不成功，核对ERP是否成功，如果成功则标记为成功，否则不作处理-盘点单
  -- 04:CIMS不为新建，核对ERP是否成功，如果不成功则标记新建，否则不作处理-盘点单
  procedure p_intf_inv_repair is
    i_count      number;
    erp_pre_date number;
    -- 库存事务不成功单据-纠正为成功-非盘点单、中转单
    cursor c_inv_transaction01(in_pre_date number) is
      select h.id head_id, h.order_num, h.subinventory inv_code, h.status
        from cims.intf_inv_transaction_head h
       where nvl(h.status, 'N') <> 'S'
         and h.order_num not like 'C%'
         and h.order_num not like 'P%'
         and h.post_date > trunc(sysdate) - in_pre_date
         and h.post_date < trunc(sysdate);
  
    -- 库存事务不成功单据-纠正为失败，1个月以内-非盘点单、中转单-暂处理
    cursor c_inv_transaction02(in_pre_date number) is
      select h.id head_id, h.order_num, h.subinventory inv_code, h.status
        from cims.intf_inv_transaction_head h
       where nvl(h.status, 'N') <> 'N'
         and h.order_num not like 'C%'
         and h.order_num not like 'P%'
         and h.post_date > trunc(sysdate) - in_pre_date
         and h.post_date < trunc(sysdate)
         and h.subinventory is not null;
  
    -- 库存事务不成功单据-纠正为成功-盘点单、中转单，存在记录则认为成功
    cursor c_inv_transaction03(in_pre_date number) is
      select h.id head_id, h.order_num, h.subinventory inv_code, h.status
        from cims.intf_inv_transaction_head h
       where nvl(h.status, 'N') <> 'S'
         and (h.order_num like 'C%' or h.order_num like 'P%')
         and h.post_date > trunc(sysdate) - in_pre_date
         and h.post_date < trunc(sysdate);
  
    -- 库存事务不成功单据-纠正为重推-盘点单、中转单，不存在记录则重推
    cursor c_inv_transaction04(in_pre_date number) is
      select h.id head_id, h.order_num, h.subinventory inv_code, h.status
        from cims.intf_inv_transaction_head h
       where nvl(h.status, 'N') <> 'N'
         and (h.order_num like 'C%' or h.order_num like 'P%')
         and h.post_date > trunc(sysdate) - in_pre_date
         and h.post_date < trunc(sysdate);
  begin
    erp_pre_date := v_pre_date60;
  
    for inv01 in c_inv_transaction01(v_pre_date30) loop
      -- 如果存在
      select count(*)
        into i_count
        from apps.mtl_material_transactions@mdims2mderp inv_erp
       where 1 = 1
         and inv_erp.transaction_date > trunc(sysdate) - erp_pre_date
         and inv_erp.transaction_reference = inv01.order_num
         and inv_erp.source_code = 'CIMS'
         and inv_erp.subinventory_code = inv01.inv_code
         and inv_erp.transaction_quantity < 0;
    
      -- 存在单据号+子库，则更新为成功
      if i_count > 0 then
        update cims.intf_inv_transaction_head h
           set h.status     = 'S',
               h.error_flag = null,
               h.error_msg  = '系统自动修复-成功-' || h.status ||
                              to_char(sysdate, '-yyyymmdd-hh24:mi:ss')
         where nvl(h.status, 'N') <> 'S'
           and h.id = inv01.head_id;
      
        /*dbms_output.put_line('order_number:' || inv01.order_num ||
        ',系统自动修复-成功-' || inv01.status ||
        to_char(sysdate, '-yyyymmdd-hh24:mi:ss'));*/
      end if;
    end loop;
  
    commit;
  
    for inv02 in c_inv_transaction02(v_pre_date30) loop
      -- 如果存在
      select count(*)
        into i_count
        from apps.mtl_material_transactions@mdims2mderp inv_erp
       where 1 = 1
         and inv_erp.transaction_date > trunc(sysdate) - erp_pre_date
         and inv_erp.transaction_reference = inv02.order_num
         and inv_erp.source_code = 'CIMS'
         and inv_erp.subinventory_code = inv02.inv_code
         and inv_erp.transaction_quantity < 0;
    
      -- 存在单据号+子库，则更新为成功
      if i_count = 0 then
        update cims.intf_inv_transaction_head h
           set h.status     = 'N',
               h.error_flag = null,
               h.error_msg  = '系统自动修复-重推-' || h.status ||
                              to_char(sysdate, '-yyyymmdd-hh24:mi:ss')
         where nvl(h.status, 'N') <> 'N'
           and h.id = inv02.head_id;
      
        /*dbms_output.put_line('order_number:' || inv02.order_num ||
        ',系统自动修复-重推-' || inv02.status ||
        to_char(sysdate, '-yyyymmdd-hh24:mi:ss'));*/
      end if;
    end loop;
    commit;
  
    for inv03 in c_inv_transaction03(v_pre_date30) loop
      -- 如果存在
      select count(*)
        into i_count
        from apps.mtl_material_transactions@mdims2mderp inv_erp
       where 1 = 1
         and inv_erp.transaction_date > trunc(sysdate) - erp_pre_date
         and inv_erp.transaction_reference = inv03.order_num
         and inv_erp.source_code = 'CIMS'
         and inv_erp.subinventory_code = inv03.inv_code;
    
      -- 存在单据号+子库，则更新为成功
      if i_count > 0 then
        update cims.intf_inv_transaction_head h
           set h.status     = 'S',
               h.error_flag = null,
               h.error_msg  = '系统自动修复-成功-' || h.status ||
                              to_char(sysdate, '-yyyymmdd-hh24:mi:ss')
         where nvl(h.status, 'N') <> 'S'
           and h.id = inv03.head_id;
      
        /*dbms_output.put_line('order_number:' || inv03.order_num ||
        ',系统自动修复-成功-' || inv03.status ||
        to_char(sysdate, '-yyyymmdd-hh24:mi:ss'));*/
      end if;
    end loop;
    commit;
  
    for inv04 in c_inv_transaction04(v_pre_date30) loop
      -- 如果存在
      select count(*)
        into i_count
        from apps.mtl_material_transactions@mdims2mderp inv_erp
       where 1 = 1
         and inv_erp.transaction_date > trunc(sysdate) - erp_pre_date
         and inv_erp.transaction_reference = inv04.order_num
         and inv_erp.source_code = 'CIMS'
         and inv_erp.subinventory_code = inv04.inv_code;
    
      -- 存在单据号+子库，则更新为成功
      if i_count = 0 then
        update cims.intf_inv_transaction_head h
           set h.status     = 'N',
               h.error_flag = null,
               h.error_msg  = '系统自动修复-重推-' || h.status ||
                              to_char(sysdate, '-yyyymmdd-hh24:mi:ss')
         where nvl(h.status, 'N') <> 'N'
           and h.id = inv04.head_id;
      
        /*dbms_output.put_line('order_number:' || inv04.order_num ||
        ',系统自动修复-重推-' || inv04.status ||
        to_char(sysdate, '-yyyymmdd-hh24:mi:ss'));*/
      end if;
    end loop;
    commit;
  
  end;

  procedure p_intf_deal_repair is
  begin
    PKG_INTF_REPAIR.p_intf_oe_repair;
    PKG_INTF_REPAIR.p_intf_inv_repair;
  end;

end PKG_INTF_REPAIR;
/

