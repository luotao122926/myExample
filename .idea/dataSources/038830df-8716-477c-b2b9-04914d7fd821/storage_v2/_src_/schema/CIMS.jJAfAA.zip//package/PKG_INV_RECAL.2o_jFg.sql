create PACKAGE      pkg_inv_recal
IS
   g_recal_quanlity               NUMBER;                --重算的业务单据数量
   g_ret_code                     NUMBER;                            --错误码
   g_ret_desc                     VARCHAR2 (256);                  --错误描述
   g_have_id                      NUMBER;            --表中存在头ID对应的记录
   g_not_have_id                  NUMBER;          --表中不存在头ID对应的记录
   g_status_success               NUMBER;                          --重算成功
   g_status_not_beign             NUMBER;                        --重算未开赛
   g_status_recaling              NUMBER;                            --重算中
   g_status_fail                  NUMBER;                          --重算失败
   g_normal_trsf                  NUMBER;                        --正常调拨单
   g_normal_trsf_red              NUMBER;                    --正常调拨红冲单
   --业务错误码
   err_success                    NUMBER;                              --成功
   err_bus_have_recal_proc        NUMBER;            --存在正在运行的重算过程
   err_bus_get_begin_date_fail    NUMBER;                  --获取重算时间失败
   err_bus_no_id                  NUMBER;          --表中不存在头ID对应的记录
   --系统错误码
   err_sys_lock                   NUMBER;            --事务一致性控制加锁异常
   err_sys_unlock                 NUMBER;            --事务一致性控制解锁异常
   err_sys_begin_date             NUMBER;              --获取重算开始时间异常
   err_sys_recal_so               NUMBER;                    --重算销售单异常
   err_sys_recal_po               NUMBER;                    --重算采购单异常
   err_sys_recal_trsf             NUMBER;                    --重算调拨单异常
   err_sys_recal_check            NUMBER;                    --重算盘点单异常
   err_sys_recal_stockup          NUMBER;                    --重算备货单异常
   err_sys_recal_send             NUMBER;                --重算领用发放单异常
   err_sys_update_so              NUMBER;                    --更新销售单异常
   err_sys_update_po              NUMBER;                    --更新采购单异常
   err_sys_update_trsf            NUMBER;                    --更新调拨单异常
   err_sys_update_check           NUMBER;                    --更新盘点单异常
   err_sys_update_stockup         NUMBER;                    --更新备货单异常
   err_sys_update_send            NUMBER;                --更新领用发放单异常
   err_sys_recal_history          NUMBER;                    --写重算日志异常
   err_sys_inv_init               NUMBER;                        --初始化异常
   err_sys_exec_update            NUMBER;          --调用物料历史记录处理异常
   err_sys_update_all             NUMBER;
   err_sys_recal_all              NUMBER;              --物料事物处理重算异常
   err_sys_recal_onhand           NUMBER;                    --现有量重算异常

--初始化全局变量
   PROCEDURE p_inv_init;

--重算主过程
   PROCEDURE p_inv_recal_main (
      in_entity_id   IN       NUMBER,                            --经营主体ID
      on_ret_code    OUT      NUMBER,                                --错误码
      on_ret_desc    OUT      VARCHAR2                             --错误描述
   );

--事务一致性控制：加锁
   PROCEDURE p_inv_recal_lock (
      in_entity_id        IN       NUMBER,                       --经营主体ID
      in_sequence_recal   OUT      NUMBER                    --重算日志记录ID
   );

--事务一致性控制：解锁
   PROCEDURE p_inv_recal_unlock (
      in_entity_id        IN       NUMBER,                       --经营主体ID
      in_sequence_recal   IN       NUMBER,                   --重算日志记录ID
      in_status           IN       NUMBER,
      --重算结果标识 0:重算成功 1：未开始 2：重算中 3：重算失败
      on_ret_code         OUT      NUMBER,                           --错误码
      on_ret_desc         OUT      VARCHAR2                        --错误描述
   );

--获取重算开始时间
   PROCEDURE p_inv_get_recal_begin_date (
      in_entity_id    IN       NUMBER,                           --经营主体ID
      od_begin_date   OUT      DATE,                           --重算开始时间
      on_period_id    OUT      NUMBER                          --重算会计期间
   );

--写重算历史记录
   PROCEDURE p_inv_recal_history (
      in_entity_id        IN       NUMBER,                       --经营主体ID
      in_sequence_recal   IN       NUMBER,                   --重算日志记录ID
      in_head_id          IN       NUMBER,                     --业务单据头ID
      in_bill_state       IN       VARCHAR2,                       --单据状态
      is_bill_kind        IN       VARCHAR2,
--B1（采购中转）、B2（仓库调拨）、B3（仓库盘点）、B4（销售）、B5（推广物料）、B6（备货转销售）
      on_ret_code         OUT      NUMBER,                           --错误码
      on_ret_desc         OUT      VARCHAR2                        --错误描述
   );

--重算所有业务单据
   PROCEDURE p_inv_recal_all (
      in_entity_id        IN   NUMBER,                           --经营主体ID
      id_begin_date       IN   DATE,                           --重算开始时间
      in_sequence_recal   IN   NUMBER                        --重算日志记录ID
   );

--重算现有量
   PROCEDURE p_inv_recal_onhand (
      in_entity_id    IN   NUMBER,                               --经营主体ID
      id_begin_date   IN   DATE,                               --重算开始时间
      in_period_id    IN   NUMBER                            --重算会计期间ID
   );

   PROCEDURE p_inv_update_all (
      in_entity_id        IN   NUMBER,                           --经营主体ID
      in_head_id          IN   NUMBER,                         --业务单据头ID
      in_bill_type_id     IN   NUMBER,                       --业务单据类型ID
      id_begin_date       IN   DATE,                           --重算开始时间
      in_sequence_recal   IN   NUMBER                        --重算日志记录ID
   );

--更新销售单现有量
   PROCEDURE p_inv_update_so (
      in_entity_id        IN       NUMBER,                       --经营主体ID
      in_head_id          IN       NUMBER,                     --业务单据头ID
      in_bill_type_id     IN   NUMBER,                                              --业务单据类型ID
      id_begin_date       IN       DATE,                       --重算开始时间
      in_sequence_recal   IN       NUMBER,                   --重算日志记录ID
      in_have_id          OUT      NUMBER    --是否存在业务单据头ID对应的记录
   );

--更新采购单现有量
   PROCEDURE p_inv_update_po (
      in_entity_id        IN       NUMBER,                       --经营主体ID
      in_head_id          IN       NUMBER,                     --业务单据头ID
      in_bill_type_id     IN       NUMBER,                                          --业务单据类型ID
      id_begin_date       IN       DATE,                       --重算开始时间
      in_sequence_recal   IN       NUMBER,                   --重算日志记录ID
      in_have_id          OUT      NUMBER    --是否存在业务单据头ID对应的记录
   );

--更新调拨单现有量
   PROCEDURE p_inv_update_trsf (
      in_entity_id        IN       NUMBER,                       --经营主体ID
      in_head_id          IN       NUMBER,                     --业务单据头ID
      in_bill_type_id     IN       NUMBER,                                          --业务单据类型ID
      id_begin_date       IN       DATE,                       --重算开始时间
      in_sequence_recal   IN       NUMBER,                   --重算日志记录ID
      in_have_id          OUT      NUMBER    --是否存在业务单据头ID对应的记录
   );

--更新盘点单现有量
   PROCEDURE p_inv_update_check (
      in_entity_id        IN       NUMBER,                       --经营主体ID
      in_head_id          IN       NUMBER,                     --业务单据头ID
      in_bill_type_id     IN       NUMBER,                                          --业务单据类型ID
      id_begin_date       IN       DATE,                       --重算开始时间
      in_sequence_recal   IN       NUMBER,                   --重算日志记录ID
      in_have_id          OUT      NUMBER    --是否存在业务单据头ID对应的记录
   );

--更新备货单现有量
   PROCEDURE p_inv_update_stockup (
      in_entity_id        IN       NUMBER,                       --经营主体ID
      in_head_id          IN       NUMBER,                     --业务单据头ID
      in_bill_type_id     IN       NUMBER,                                          --业务单据类型ID
      id_begin_date       IN       DATE,                       --重算开始时间
      in_sequence_recal   IN       NUMBER,                   --重算日志记录ID
      in_have_id          OUT      NUMBER    --是否存在业务单据头ID对应的记录
   );

--更新领用发放单现有量
   PROCEDURE p_inv_update_send (
      in_entity_id        IN       NUMBER,                       --经营主体ID
      in_head_id          IN       NUMBER,                     --业务单据头ID
      in_bill_type_id     IN       NUMBER,                                          --业务单据类型ID
      id_begin_date       IN       DATE,                       --重算开始时间
      in_sequence_recal   IN       NUMBER,                   --重算日志记录ID
      in_have_id          OUT      NUMBER    --是否存在业务单据头ID对应的记录
   );

   PROCEDURE p_inv_update_null (
      in_entity_id        IN       NUMBER,                       --经营主体ID
      in_head_id          IN       NUMBER,                     --业务单据头ID
      id_begin_date       IN       DATE,                       --重算开始时间
      in_sequence_recal   IN       NUMBER,                   --重算日志记录ID
      in_bill_type_id     IN       NUMBER,                   --业务单据类型ID
      in_have_id          OUT      NUMBER    --是否存在业务单据头ID对应的记录
   );

   PROCEDURE p_inv_exec_update (
      in_entity_id          IN   NUMBER,                         --经营主体ID
      in_head_id            IN   NUMBER,                       --业务单据头ID
      in_sequence_recal     IN   NUMBER,                     --重算日志记录ID
      in_bill_type_id       IN   NUMBER,                         --单据类型ID
      in_if_null            IN   NUMBER,       --是否是空的业务单据，0否，1是
      is_business_state     IN   t_inv_transaction_history.business_state%TYPE,
      --单据状态
      id_transaction_date   IN   t_inv_transaction_history.transaction_date%TYPE,
      --业务日期
      is_bill_kind          IN   VARCHAR2
--B1（采购中转）、B2（仓库调拨）、B3（仓库盘点）、B4（销售）、B5（推广物料）、B6（备货转销售）
   );
   FUNCTION F_GET_TRANS_RECORD(vn_entity_id IN NUMBER,
   vn_bill_type_id IN T_INV_BILL_TYPES.BILL_TYPE_ID%TYPE,
   vn_bill_status_code IN t_inv_bill_period_line.BILL_STATUS_CODE%TYPE) 
   RETURN INT;
END pkg_inv_recal;
/

