create package PKG_CSS_OI is

  -- Author  : HUTAO
  -- Created : 2014/7/28 8:44:47

     PROCEDURE P_SYNCHRO_INSTALL(p_entity_id number);
     
     --从ccs获取安装卡信息
     PROCEDURE GET_PG_DETAIL_FROM_CSS(p_entity_id number);
     
     --从ccs获取安装卡信息job
     PROCEDURE GET_PG_DETAIL_FROM_CSS_JOB;

end PKG_CSS_OI;
/

