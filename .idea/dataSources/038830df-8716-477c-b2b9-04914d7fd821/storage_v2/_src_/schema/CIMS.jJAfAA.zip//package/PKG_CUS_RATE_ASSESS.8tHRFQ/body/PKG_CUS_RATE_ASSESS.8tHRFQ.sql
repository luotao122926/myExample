create PACKAGE BODY PKG_CUS_RATE_ASSESS IS

  /*
  *执行语义的SQL
  */
  function fun_get_val_by_semantic_sql(P_Get_Val_Sql   clob,
                                       P_EntityId      number,
                                       P_CustomerId    number, --预留未使用
                                       P_CustomerCode  varchar2,
                                       P_SalesMainType varchar2,
                                       P_StartTime     varchar2,
                                       P_EndTime       varchar2)
    return number is
    V_Get_Val_Sql clob;
    v_reslut      number;
  begin
    V_Get_Val_Sql := regexp_replace(P_Get_Val_Sql,
                                    ':((rate){0,1}(assess){0,1}){1}',
                                    ':');
    V_Get_Val_Sql := replace(V_Get_Val_Sql, ':EntityId', P_EntityId);
    V_Get_Val_Sql := replace(V_Get_Val_Sql, ':CustomerId', P_CustomerId);
    V_Get_Val_Sql := replace(V_Get_Val_Sql,
                             ':CustomerCode',
                             chr(39) || P_CustomerCode || chr(39));
    V_Get_Val_Sql := replace(V_Get_Val_Sql,
                             ':SalesMainType',
                             chr(39) || P_SalesMainType || chr(39));
    V_Get_Val_Sql := replace(V_Get_Val_Sql,
                             ':StartTime',
                             chr(39) || P_StartTime || chr(39));
    V_Get_Val_Sql := replace(V_Get_Val_Sql,
                             ':EndTime',
                             chr(39) || P_EndTime || chr(39));
    begin
      execute immediate V_Get_Val_Sql
        into v_reslut;
      /*if v_reslut is null then
        dbms_output.put_line(V_Get_Val_Sql);
      end if;*/
    exception
      WHEN NO_DATA_FOUND THEN
        return null;
      WHEN zero_divide then
        return null;
      when others then
        RAISE_APPLICATION_ERROR(-20100,
                                '执行语义SQL获取指标值发生异常：' || V_Get_Val_Sql ||
                                dbms_utility.format_error_stack(),
                                TRUE);
        --dbms_output.put_line('异常：'|| V_Get_Val_Sql);
    end;

    return v_reslut;
  end fun_get_val_by_semantic_sql;

  /*
  *客户评级：客户评级数据
  */
  PROCEDURE P_RATE_CUS_INDEX_DATA(P_TEMPLATE_IDS in varchar2, --考核模板ID
                                  P_CREATED_BY   in varchar2, --操作员
                                  P_MESSAGE      out varchar2 --成功则返回“SUCCESS”，否则返回出错信息
                                  ) IS
  BEGIN
    for cur in (SELECT NVL(REGEXP_SUBSTR(P_TEMPLATE_IDS,
                                         '[^,]+',
                                         1,
                                         LEVEL,
                                         'i'),
                           'NULLL') AS STR
                  FROM DUAL
                CONNECT BY LEVEL <=
                           1 +
                           length(REGEXP_REPLACE(P_TEMPLATE_IDS, '[^,]+', ''))) loop
      --delete from t_customer_rate_index_score where template_id = cur.STR;
      insert into t_customer_rate_index_score
        (id,
         entity_id,
         template_id,
         rate_description,
         customer_id,
         customer_code,
         customer_name,
         sales_main_type,
         index_id,
         index_name,
         is_subtract,
         created_by,
         creation_date,
         last_update_by,
         last_update_date,
         index_score,
         score,
         PRE_FIELD_06)
        with t0 as
         (select t.entity_id,
                 t.sales_main_type  sales_main_type,
                 t.marketing_model  marketing_model,
                 t.channel_type,
                 t.brand_code       brand_code,
                 t.template_id,
                 t.rate_description
            from cims.t_customer_rate_template t
           where t.template_id = cur.STR),
        tt as
         (select ts.template_id,
                 ts.index_id,
                 ts.index_name,
                 ts.is_subtract,
                 ts.is_manually
            from cims.t_customer_rate_standard ts
           where exists
           (select 1 from t0 where t0.template_id = ts.template_id)),
        et as
         (select cl.CODE_VALUE,
                 cl.CODETYPE,
                 cl.CODE_NAME,
                 nvl(cl.ENTITY_ID, t0.entity_id) as entity_id
            from cims.v_up_codelist cl
           inner join t0
              on ((cl.ENTITY_ID is null or cl.ENTITY_ID = t0.entity_id) and
                 cl.CODETYPE in ('BD_SALES_MAIN_TYPE'
                                  --,'MIDEA_MARKET_MODE',
                                  --'MIDEA_ACCNT_CHANNEL_TYPE',
                                  --'MIDEA_BRAND_NAME'
                                  --
                                  ))),
        t1 as
         (select NVL(REGEXP_SUBSTR(t0.sales_main_type,
                                   '[^,]+',
                                   1,
                                   LEVEL,
                                   'i'),
                     'NULLL') AS STR
            from t0
          CONNECT BY LEVEL <=
                     1 + length(REGEXP_REPLACE(t0.sales_main_type, '[^,]+'))),
        t2 as
         (select NVL(REGEXP_SUBSTR(t0.marketing_model,
                                   '[^,]+',
                                   1,
                                   LEVEL,
                                   'i'),
                     'NULLL') AS STR
            from t0
          CONNECT BY LEVEL <=
                     1 + length(REGEXP_REPLACE(t0.marketing_model, '[^,]+'))),
        t3 as
         (select NVL(REGEXP_SUBSTR(t0.channel_type, '[^,]+', 1, LEVEL, 'i'),
                     'NULLL') AS STR
            from t0
          CONNECT BY LEVEL <=
                     1 + length(REGEXP_REPLACE(t0.channel_type, '[^,]+'))),
        t4 as
         (select NVL(REGEXP_SUBSTR(t0.brand_code, '[^,]+', 1, LEVEL, 'i'),
                     'NULLL') AS STR
            from t0
          CONNECT BY LEVEL <=
                     1 + length(REGEXP_REPLACE(t0.brand_code, '[^,]+'))),
        t5 as
         (select distinct d.dept_id,
                          t0.template_id,
                          t0.rate_description,
                          h.customer_id,
                          h.customer_code,
                          h.customer_name,
                          b.sales_main_type_code,
                          smt_et.CODE_NAME as sales_main_type_name,
                          tt.index_id,
                          tt.index_name,
                          tt.is_subtract,
                          tt.is_manually
            from cims.t_customer_header h
           inner join cims.t_customer_dept d
              on (d.customer_id = h.customer_id and 'Active' = d.active_flag and
                 h.active_flag = 'Active')
           inner join t0
              on (t0.entity_id = d.dept_id)
           inner join cims.t_customer_brand b
              on (b.customer_id = h.customer_id and 'Active' = b.active_flag
                 --品牌
                 and exists (select 1 from t4 where b.brand_code = t4.str)
                 --营销大类
                  and exists
                  (select 1 from t1 where b.sales_main_type_code = t1.str)
                 --合作类型
                  and exists
                  (select 1 from t2 where b.cooperation_model = t2.str) and
                  b.entity_id = d.dept_id)
           inner join et smt_et
              on (smt_et.entity_id = b.entity_id and
                 smt_et.CODE_VALUE = b.sales_main_type_code and
                 smt_et.CODETYPE = 'BD_SALES_MAIN_TYPE')
           inner join cims.t_customer_channel_type ct
              on (ct.customer_id = h.customer_id and
                 'Active' = ct.active_flag
                 --业态类型
                 and exists (select 1 from t3 where ct.industry_type = t3.str) and
                  ct.entity_id = d.dept_id)
           inner join tt
              on (tt.template_id = t0.template_id))
        select s_customer_rate_index_score.nextval,
               t5.dept_id,
               t5.template_id,
               t5.rate_description,
               t5.customer_id,
               t5.customer_code,
               t5.customer_name,
               t5.sales_main_type_code,
               t5.index_id,
               t5.index_name,
               t5.is_subtract,
               P_CREATED_BY,
               sysdate,
               P_CREATED_BY,
               sysdate,
               decode(t5.is_manually, '1', null, 0),
               decode(t5.is_manually, '1', null, 0),
               t5.sales_main_type_name
          from t5;
    end loop;

    P_MESSAGE := 'SUCCESS';

  END P_RATE_CUS_INDEX_DATA;

  /*
  *客户评级：自动计算
  */
  PROCEDURE P_RATE_CALINDEX(P_TEMPLATE_IDS in varchar2, --评级模板ID
                            P_CREATED_BY   in varchar2, --操作员
                            P_MESSAGE      out varchar2 --成功则返回“SUCCESS”，否则返回出错信息
                            ) IS
  BEGIN
    merge into cims.t_customer_rate_index_score mt
    using (
      with tt as
       (SELECT NVL(REGEXP_SUBSTR(P_TEMPLATE_IDS, '[^,]+', 1, LEVEL, 'i'),
                   'NULLL') AS STR
          FROM DUAL
        CONNECT BY LEVEL <=
                   1 + length(REGEXP_REPLACE(P_TEMPLATE_IDS, '[^,]+', ''))),
      t0 as
       (select t.template_id, t.index_id, s.get_val_sql
          from cims.t_customer_rate_standard t
         inner join cims.t_customer_rate_index_library l
            on (l.index_id = t.index_id and 0 = l.is_manually
               --
               --and l.index_id = 292
               --
               )
         inner join cims.t_pol_semantic s
            on (s.semantic_id = l.fun_name)
         inner join tt
            on (t.template_id = to_number(tt.str)))
      select cis.id,
             fun_get_val_by_semantic_sql(t0.get_val_sql,
                                         cis.entity_id,
                                         cis.customer_id,
                                         cis.customer_code,
                                         cis.sales_main_type,
                                         to_char(tpl.rate_begin_time,
                                                 'yyyy-mm-dd'),
                                         to_char(tpl.rate_end_time,
                                                 'yyyy-mm-dd')) as index_score
        from cims.t_customer_rate_index_score cis
       inner join cims.t_customer_rate_template tpl
          on (tpl.template_id = cis.template_id)
       inner join t0
          on (t0.template_id = cis.template_id and
             t0.index_id = cis.index_id)) ut on (mt.id = ut.id) when matched then
        update
           set mt.index_score      = nvl(ut.index_score, 0),
               mt.last_update_by   = P_CREATED_BY,
               mt.last_update_date = sysdate;
    --更新模板状态
    merge into CIMS.T_CUSTOMER_RATE_TEMPLATE mt
    using (
      with tt as
       (SELECT NVL(REGEXP_SUBSTR(P_TEMPLATE_IDS, '[^,]+', 1, LEVEL, 'i'),
                   'NULLL') AS STR
          FROM DUAL
        CONNECT BY LEVEL <=
                   1 + length(REGEXP_REPLACE(P_TEMPLATE_IDS, '[^,]+', '')))
      select t.template_id
        from CIMS.T_CUSTOMER_RATE_TEMPLATE t
       inner join tt
          on (t.template_id = to_number(tt.str))) ut on (mt.template_id = ut.template_id) when matched then
        update
           set mt.execute_status = 3 /*,
                       mt.approve_status = decode(mt.approve_status,
                                                  '4', --审批通过
                                                  '1',
                                                  '2', --审批中
                                                  '1',
                                                  mt.approve_status --未审核以及驳回
                                                  )*/
        --where mt.approve_status <> '2'--审批中不修改由其他地方校验控制
        --5已评分 3已启动未评分
        ;
    P_MESSAGE := 'SUCCESS';

  END;

  /*
  *客户评级：评分
  */
  PROCEDURE P_RATE_SCORE(P_TEMPLATE_IDS in varchar2, --评级模板ID
                         P_CREATED_BY   in varchar2, --操作员
                         P_MESSAGE      out varchar2 --成功则返回“SUCCESS”，否则返回出错信息
                         ) IS
  BEGIN
    insert into cims.t_customer_rate_result
      (rate_result_id,
       entity_id,
       template_id,
       rate_description,
       customer_id,
       customer_code,
       customer_name,
       sales_main_type,
       score,
       customer_level,
       created_by,
       creation_date,
       last_update_by,
       last_update_date,
       check_status)
      with tt as
       (SELECT NVL(REGEXP_SUBSTR(P_TEMPLATE_IDS, '[^,]+', 1, LEVEL, 'i'),
                   'NULLL') AS STR
          FROM DUAL
        CONNECT BY LEVEL <=
                   1 + length(REGEXP_REPLACE(P_TEMPLATE_IDS, '[^,]+', ''))),
      t0 as
       (select t.template_id,
               t.entity_id,
               t.index_id,
               t.standard_id,
               t.is_subtract,
               r.range_begin,
               r.range_end,
               r.matching_score,
               r.matching_score * decode(t.is_subtract, null, 0, 1, -1, 1) as matching_score0,
               t.SCORES,
               nvl((select max(r0.range_end)
                     from cims.t_customer_rate_range r0
                    where r0.standard_id = r.standard_id
                      and r0.range_end < decode(r.range_end,
                                                null,
                                                1 + r0.range_end,
                                                r.range_end)),
                   0) as pre_end
          from cims.t_customer_rate_standard t
         inner join tt
            on (t.template_id = to_number(tt.str))
         inner join cims.t_customer_rate_range r
            on (r.standard_id = t.standard_id)),
      t1_1 as
       (select lr.entity_id,
               lr.range_begin,
               lr.range_end,
               to_number((select cl.code_value
                           from cims.up_codelist cl
                          where cl.id = lr.level_id)) as level_num
          from cims.t_customer_level_range lr
         where exists (select 1 from t0 where lr.entity_id = t0.entity_id)),
      t1 as
       (select t1_1.entity_id,
               t1_1.range_begin,
               t1_1.range_end,
               t1_1.level_num,
               min(t1_1.level_num) over(partition by t1_1.entity_id) as min_level_num,
               max(t1_1.level_num) over(partition by t1_1.entity_id) as max_level_num,
               max(t1_1.range_end) over(partition by t1_1.entity_id) as max_range_end,
               min(t1_1.range_begin) over(partition by t1_1.entity_id) as min_range_begin,
               count(0) over(partition by t1_1.entity_id) as count_level_range
          from t1_1),
      t2 as
       (select nvl(t0.entity_id, t.entity_id) as entity_id,
               t.template_id,
               t.customer_id,
               t.customer_code,
               t.customer_name,
               t.sales_main_type,
               sum(decode(t.INDEX_SCORE,
                          null,
                          0,
                          decode(t0.index_id,
                                 null,
                                 0,
                                 decode(t0.matching_score0,
                                        null,
                                        0,
                                        t0.matching_score0)))) as score,
               min(s.custom_level) as custom_level
          from cims.t_customer_rate_index_score t
          left join t_customer_sales_main_type s
            on (s.entity_id = t.entity_id and t.customer_id = s.custom_id and
               s.sales_main_type_code = t.sales_main_type)
         inner join t0
        --满足区间得分定义（加上得分不为空的条件，可以对相应模板相应指标进行一票否决，即没有该模板该项指标的评分）
            on (t0.template_id = t.template_id and t0.index_id = t.index_id and
               (t0.range_begin < t.INDEX_SCORE or
               t.INDEX_SCORE = t0.range_begin or
               (t0.range_begin is null and t.INDEX_SCORE > t0.pre_end)) and
               (t0.range_end is null or t0.range_end > t.INDEX_SCORE))
         where not exists
         (select 1
                  from t0
                --该指标值对应模板的所有指标值满足区间条件，并且区间得分为空，那么一票否决（即没有对应模板的评分）
                 where t0.matching_score is null
                   and t0.template_id = t.template_id
                   and (t0.range_begin < t.INDEX_SCORE or
                       t.INDEX_SCORE = t0.range_begin or
                       (t0.range_begin is null and
                       t.INDEX_SCORE > t0.pre_end))
                   and (t0.range_end is null or t0.range_end > t.INDEX_SCORE))
         group by nvl(t0.entity_id, t.entity_id),
                  t.template_id,
                  t.customer_id,
                  t.customer_code,
                  t.customer_name,
                  --综合得分可以去掉这个分组 是否是综合 可以在评级模板加一个字段或者用预留字段
                  --再在码表里面配置事业部是否综合 可以将码表值作为后台默认或者前台默认设置
                  t.sales_main_type),
      t3 as
       (select t2.entity_id,
               t2.template_id,
               t2.customer_id,
               t2.customer_code,
               t2.customer_name,
               t2.sales_main_type,
               t2.score,
               t2.custom_level,
               --排名
               dense_rank() over(partition by t2.template_id, t2.sales_main_type order by t2.score desc) as rk,
               --排序
               row_number() over(partition by t2.template_id, t2.sales_main_type order by t2.score desc, nvl(t2.custom_level, 9999)) as rn,
               max(t2.score) over(partition by t2.template_id, t2.sales_main_type) as max_score
          from t2),
      t4 as
       (select t3.template_id,
               t3.sales_main_type,
               max(t3.rk) as max_rk,
               max(t3.rn) as max_rn
          from t3
         group by t3.template_id, t3.sales_main_type),
      t5 as
       (select t3.entity_id,
               t3.template_id,
               t3.customer_id,
               t3.customer_code,
               t3.customer_name,
               t3.sales_main_type,
               t3.score,
               t3.max_score,
               t4.max_rk,
               t4.max_rn,
               t3.rk,
               100 * (t3.rn / t4.max_rn) as rn_per
          from t3
         inner join t4
            on (t3.template_id = t4.template_id and
               (nvl(t3.sales_main_type, ' ') = nvl(t4.sales_main_type, ' ')))),
      t6 as
       (select t5.entity_id,
               t5.template_id,
               t5.customer_id,
               t5.customer_code,
               t5.customer_name,
               t5.sales_main_type,
               t5.score,
               t5.rk,
               t5.max_rk,
               --按排序先后取满足等级区间开始、结束的等级
               (select max(t1.level_num)
                  from t1
                 where t1.entity_id = t5.entity_id
                      --排名最大值必须大于等级区间个数
                   and t5.max_rk > t1.count_level_range
                   and t5.rn_per > t1.range_begin
                   and t5.rn_per <= t1.range_end) as level_num,
               (select t1.max_level_num
                  from t1
                 where t1.entity_id = t5.entity_id
                      --排名最大值必须大于等级区间个数
                   and t5.max_rk > t1.count_level_range
                   and t5.rn_per > t1.max_range_end
                   and 1 = rownum) as max_level_num,
               (select t1.min_level_num
                  from t1
                 where t1.entity_id = t5.entity_id
                      --排名最大值必须大于等级区间个数
                   and t5.max_rk > t1.count_level_range
                   and t5.rn_per <= t1.min_range_begin
                   and 1 = rownum) as min_level_num,
               (select (case
                         when t5.max_rk > t1.count_level_range then
                         --如果排名最大值大于等级区间定义个数，此值为空
                          null
                         when 1 = t5.max_rk then
                         --如果排名都一样，即所有分数都一样，分数大于0取最高的客户等级，否则取最低的客户等级（客户等级值越小，等级越高）
                          (case
                            when 0 < t5.max_score then
                             t1.min_level_num
                            else
                             t1.max_level_num
                          end)
                         else
                         --如果排名最大值小于等于等级区间定义个数，按排名先后取等级
                          t5.rk + t1.min_level_num - 1
                       end)
                  from t1
                 where t1.entity_id = t5.entity_id
                   and 1 = rownum) as less_rk_level
          from t5),
      t7 as
       (select t6.template_id,
               t6.sales_main_type,
               t6.rk,
               min(nvl(level_num, nvl(max_level_num, min_level_num))) as rk_level_num
          from t6
         group by t6.template_id, t6.sales_main_type, t6.rk)
      select s_customer_rate_result.nextval,
             t6.entity_id,
             t6.template_id,
             (select t.RATE_DESCRIPTION
                from cims.t_customer_rate_template t
               where t.template_id = t6.template_id),
             t6.customer_id,
             t6.customer_code,
             t6.customer_name,
             t6.sales_main_type,
             t6.score,
             nvl((case
                   when 0 >= t6.score or t6.rk >= t6.max_rk then
                    (select t1.max_level_num
                       from t1
                      where t1.entity_id = t6.entity_id
                        and 1 = rownum)
                   else
                    t7.rk_level_num
                 end),
                 nvl(level_num,
                     nvl(max_level_num, nvl(min_level_num, less_rk_level)))),
             P_CREATED_BY,
             sysdate,
             P_CREATED_BY,
             sysdate,
             1
        from t6
        left join t7
          on (t7.template_id = t6.template_id and
             t7.sales_main_type = t6.sales_main_type and t7.rk = t6.rk);
    --更新评分状态
    merge into CIMS.T_CUSTOMER_RATE_TEMPLATE mt
    using (
      with tt as
       (SELECT NVL(REGEXP_SUBSTR(P_TEMPLATE_IDS, '[^,]+', 1, LEVEL, 'i'),
                   'NULLL') AS STR
          FROM DUAL
        CONNECT BY LEVEL <=
                   1 + length(REGEXP_REPLACE(P_TEMPLATE_IDS, '[^,]+', '')))
      select t.template_id
        from CIMS.T_CUSTOMER_RATE_TEMPLATE t
       inner join tt
          on (t.template_id = to_number(tt.str))) ut on (mt.template_id = ut.template_id) when matched then
        update
           set mt.execute_status = 5, mt.approve_status = '1'
        --5已评分 3已启动未评分
        ;

    P_MESSAGE := 'SUCCESS';

  END P_RATE_SCORE;

  /*
  *客户考核：客户考核数据
  */
  PROCEDURE P_ASSESS_CUS_INDEX_DATA(P_TEMPLATE_IDS in varchar2, --考核模板ID
                                    P_CREATED_BY   in varchar2, --操作员
                                    P_MESSAGE      out varchar2 --成功则返回“SUCCESS”，否则返回出错信息
                                    ) IS
  BEGIN
    for cur in (SELECT NVL(REGEXP_SUBSTR(P_TEMPLATE_IDS,
                                         '[^,]+',
                                         1,
                                         LEVEL,
                                         'i'),
                           'NULLL') AS STR
                  FROM DUAL
                CONNECT BY LEVEL <=
                           1 +
                           length(REGEXP_REPLACE(P_TEMPLATE_IDS, '[^,]+', ''))) loop
      --delete from t_customer_ASSESS_index_score where template_id = cur.STR;
      insert into t_customer_ASSESS_index_score
        (id,
         entity_id,
         template_id,
         ASSESS_description,
         customer_id,
         customer_code,
         customer_name,
         sales_main_type,
         index_id,
         index_name,
         is_subtract,
         created_by,
         creation_date,
         last_update_by,
         last_update_date,
         index_score,
         score,
         PRE_FIELD_01)
        with t0 as
         (select t.entity_id,
                 t.sales_main_type    sales_main_type,
                 t.marketing_model    marketing_model,
                 t.channel_type,
                 t.brand_code         brand_code,
                 t.template_id,
                 t.ASSESS_description
            from cims.t_customer_ASSESS_template t
           where t.template_id = cur.STR),
        tt as
         (select ts.template_id, ts.index_id, ts.index_name, ts.is_subtract
            from cims.t_customer_ASSESS_standard ts
           where exists
           (select 1 from t0 where t0.template_id = ts.template_id)),
        et as
         (select cl.CODE_VALUE,
                 cl.CODETYPE,
                 cl.CODE_NAME,
                 nvl(cl.ENTITY_ID, t0.entity_id) as entity_id
            from cims.v_up_codelist cl
           inner join t0
              on ((cl.ENTITY_ID is null or cl.ENTITY_ID = t0.entity_id) and
                 cl.CODETYPE in ('BD_SALES_MAIN_TYPE'
                                  --,'MIDEA_MARKET_MODE',
                                  --'MIDEA_ACCNT_CHANNEL_TYPE',
                                  --'MIDEA_BRAND_NAME'
                                  --
                                  ))),
        t1 as
         (select NVL(REGEXP_SUBSTR(t0.sales_main_type,
                                   '[^,]+',
                                   1,
                                   LEVEL,
                                   'i'),
                     'NULLL') AS STR
            from t0
          CONNECT BY LEVEL <=
                     1 + length(REGEXP_REPLACE(t0.sales_main_type, '[^,]+'))),
        t2 as
         (select NVL(REGEXP_SUBSTR(t0.marketing_model,
                                   '[^,]+',
                                   1,
                                   LEVEL,
                                   'i'),
                     'NULLL') AS STR
            from t0
          CONNECT BY LEVEL <=
                     1 + length(REGEXP_REPLACE(t0.marketing_model, '[^,]+'))),
        t3 as
         (select NVL(REGEXP_SUBSTR(t0.channel_type, '[^,]+', 1, LEVEL, 'i'),
                     'NULLL') AS STR
            from t0
          CONNECT BY LEVEL <=
                     1 + length(REGEXP_REPLACE(t0.channel_type, '[^,]+'))),
        t4 as
         (select NVL(REGEXP_SUBSTR(t0.brand_code, '[^,]+', 1, LEVEL, 'i'),
                     'NULLL') AS STR
            from t0
          CONNECT BY LEVEL <=
                     1 + length(REGEXP_REPLACE(t0.brand_code, '[^,]+'))),
        t5 as
         (select distinct d.dept_id,
                          t0.template_id,
                          t0.ASSESS_description,
                          h.customer_id,
                          h.customer_code,
                          h.customer_name,
                          b.sales_main_type_code,
                          smt_et.CODE_NAME as sales_main_type_name,
                          tt.index_id,
                          tt.index_name,
                          tt.is_subtract
            from cims.t_customer_header h
           inner join cims.t_customer_dept d
              on (d.customer_id = h.customer_id and 'Active' = d.active_flag and
                 h.active_flag = 'Active')
           inner join t0
              on (t0.entity_id = d.dept_id)
           inner join cims.t_customer_brand b
              on (b.customer_id = h.customer_id and 'Active' = b.active_flag
                 --品牌
                 and exists (select 1 from t4 where b.brand_code = t4.str)
                 --营销大类
                  and exists
                  (select 1 from t1 where b.sales_main_type_code = t1.str)
                 --合作类型
                  and exists
                  (select 1 from t2 where b.cooperation_model = t2.str) and
                  b.entity_id = d.dept_id)
           inner join et smt_et
              on (smt_et.entity_id = b.entity_id and
                 smt_et.CODE_VALUE = b.sales_main_type_code and
                 smt_et.CODETYPE = 'BD_SALES_MAIN_TYPE')
           inner join cims.t_customer_channel_type ct
              on (ct.customer_id = h.customer_id and
                 'Active' = ct.active_flag
                 --业态类型
                 and exists (select 1 from t3 where ct.industry_type = t3.str) and
                  ct.entity_id = d.dept_id)
           inner join tt
              on (tt.template_id = t0.template_id))
        select s_customer_ASSESS_index_score.nextval,
               t5.dept_id,
               t5.template_id,
               t5.ASSESS_description,
               t5.customer_id,
               t5.customer_code,
               t5.customer_name,
               t5.sales_main_type_code,
               t5.index_id,
               t5.index_name,
               t5.is_subtract,
               P_CREATED_BY,
               sysdate,
               P_CREATED_BY,
               sysdate,
               null,
               null,
               t5.sales_main_type_name
          from t5;
    end loop;

    P_MESSAGE := 'SUCCESS';

  END P_ASSESS_CUS_INDEX_DATA;

  /*
  *客户考核：自动计算
  */
  PROCEDURE P_ASSESS_CALINDEX(P_TEMPLATE_IDS in varchar2, --评级模板ID
                              P_CREATED_BY   in varchar2, --操作员
                              P_MESSAGE      out varchar2 --成功则返回“SUCCESS”，否则返回出错信息
                              ) IS
  BEGIN
    merge into cims.t_customer_ASSESS_index_score mt
    using (
      with tt as
       (SELECT NVL(REGEXP_SUBSTR(P_TEMPLATE_IDS, '[^,]+', 1, LEVEL, 'i'),
                   'NULLL') AS STR
          FROM DUAL
        CONNECT BY LEVEL <=
                   1 + length(REGEXP_REPLACE(P_TEMPLATE_IDS, '[^,]+', ''))),
      t0 as
       (select t.template_id, t.index_id, s.get_val_sql
          from cims.t_customer_ASSESS_standard t
         inner join cims.t_customer_assess_index_lib l
            on (l.index_id = t.index_id and 0 = l.is_manually
               --
               --and l.index_id = 292
               --
               )
         inner join cims.t_pol_semantic s
            on (s.semantic_id = l.fun_name)
         inner join tt
            on (t.template_id = to_number(tt.str)))
      select cis.id,
             fun_get_val_by_semantic_sql(t0.get_val_sql,
                                         cis.entity_id,
                                         cis.customer_id,
                                         cis.customer_code,
                                         cis.sales_main_type,
                                         to_char(tpl.ASSESS_begin_time,
                                                 'yyyy-mm-dd'),
                                         to_char(tpl.ASSESS_end_time,
                                                 'yyyy-mm-dd')) as index_score
        from cims.t_customer_ASSESS_index_score cis
       inner join cims.t_customer_ASSESS_template tpl
          on (tpl.template_id = cis.template_id)
       inner join t0
          on (t0.template_id = cis.template_id and
             t0.index_id = cis.index_id)) ut on (mt.id = ut.id) when matched then
        update
           set mt.index_score      = nvl(ut.index_score, 0),
               mt.last_update_by   = P_CREATED_BY,
               mt.last_update_date = sysdate;
    --更新模板状态
    merge into CIMS.T_CUSTOMER_ASSESS_TEMPLATE mt
    using (
      with tt as
       (SELECT NVL(REGEXP_SUBSTR(P_TEMPLATE_IDS, '[^,]+', 1, LEVEL, 'i'),
                   'NULLL') AS STR
          FROM DUAL
        CONNECT BY LEVEL <=
                   1 + length(REGEXP_REPLACE(P_TEMPLATE_IDS, '[^,]+', '')))
      select t.template_id
        from CIMS.T_CUSTOMER_ASSESS_TEMPLATE t
       inner join tt
          on (t.template_id = to_number(tt.str))) ut on (mt.template_id = ut.template_id) when matched then
        update
           set mt.execute_status = 3
        --5已评分 3已启动未评分
        ;
    P_MESSAGE := 'SUCCESS';

  END;

  /*
  *客户考核：评分
  */
  PROCEDURE P_ASSESS_SCORE(P_TEMPLATE_IDS in varchar2, --评级模板ID
                           P_CREATED_BY   in varchar2, --操作员
                           P_MESSAGE      out varchar2 --成功则返回“SUCCESS”，否则返回出错信息
                           ) IS
  BEGIN
    insert into cims.t_customer_ASSESS_result
      (ASSESS_result_id,
       entity_id,
       template_id,
       ASSESS_description,
       customer_id,
       customer_code,
       customer_name,
       sales_main_type,
       score,
       created_by,
       creation_date,
       last_update_by,
       last_update_date)
      with tt as
       (SELECT NVL(REGEXP_SUBSTR(P_TEMPLATE_IDS, '[^,]+', 1, LEVEL, 'i'),
                   'NULLL') AS STR
          FROM DUAL
        CONNECT BY LEVEL <=
                   1 + length(REGEXP_REPLACE(P_TEMPLATE_IDS, '[^,]+', ''))),
      t0 as
       (select t.template_id,
               t.entity_id,
               t.index_id,
               t.ASSESS_ID,
               t.is_subtract,
               r.range_begin,
               r.range_end,
               r.matching_score,
               r.matching_score * decode(t.is_subtract, null, 0, 1, -1, 1) as matching_score0,
               t.SCORES,
               nvl((select max(r0.range_end)
                     from cims.t_customer_ASSESS_range r0
                    where r0.ASSESS_ID = r.ASSESS_ID
                      and r0.range_end < decode(r.range_end,
                                                null,
                                                1 + r0.range_end,
                                                r.range_end)),
                   0) as pre_end
          from cims.t_customer_ASSESS_standard t
         inner join tt
            on (t.template_id = to_number(tt.str))
         inner join cims.t_customer_ASSESS_range r
            on (r.ASSESS_ID = t.ASSESS_ID)),
      t2 as
       (select nvl(t0.entity_id, t.entity_id) as entity_id,
               t.template_id,
               t.customer_id,
               t.customer_code,
               t.customer_name,
               t.sales_main_type,
               sum(decode(t.INDEX_SCORE,
                          null,
                          0,
                          decode(t0.index_id,
                                 null,
                                 0,
                                 decode(t0.matching_score0,
                                        null,
                                        0,
                                        t0.matching_score0)))) as score
          from cims.t_customer_ASSESS_index_score t
         inner join t0
        --满足区间得分定义（加上得分不为空的条件，可以对相应模板相应指标进行一票否决，即没有该模板该项指标的评分）
            on (t0.template_id = t.template_id and t0.index_id = t.index_id and
               (t0.range_begin < t.INDEX_SCORE or
               t.INDEX_SCORE = t0.range_begin or
               (t0.range_begin is null and t.INDEX_SCORE > t0.pre_end)) and
               (t0.range_end is null or t0.range_end > t.INDEX_SCORE))
         where not exists
         (select 1
                  from t0
                --该指标值对应模板的所有指标值满足区间条件，并且区间得分为空，那么一票否决（即没有对应模板的评分）
                 where t0.matching_score is null
                   and t0.template_id = t.template_id
                   and (t0.range_begin < t.INDEX_SCORE or
                       t.INDEX_SCORE = t0.range_begin or
                       (t0.range_begin is null and
                       t.INDEX_SCORE > t0.pre_end))
                   and (t0.range_end is null or t0.range_end > t.INDEX_SCORE))
         group by nvl(t0.entity_id, t.entity_id),
                  t.template_id,
                  t.customer_id,
                  t.customer_code,
                  t.customer_name,
                  --综合得分可以去掉这个分组 是否是综合 可以在考核模板加一个字段或者用预留字段
                  --再在码表里面配置事业部是否综合 可以将码表值作为后台默认或者前台默认设置
                  t.sales_main_type)
      select s_customer_ASSESS_result.nextval,
             t2.entity_id,
             t2.template_id,
             (select t.ASSESS_DESCRIPTION
                from cims.t_customer_ASSESS_template t
               where t.template_id = t2.template_id),
             t2.customer_id,
             t2.customer_code,
             t2.customer_name,
             t2.sales_main_type,
             t2.score,
             P_CREATED_BY,
             sysdate,
             P_CREATED_BY,
             sysdate
        from t2;
    --更新评分状态
    merge into CIMS.T_CUSTOMER_ASSESS_TEMPLATE mt
    using (
      with tt as
       (SELECT NVL(REGEXP_SUBSTR(P_TEMPLATE_IDS, '[^,]+', 1, LEVEL, 'i'),
                   'NULLL') AS STR
          FROM DUAL
        CONNECT BY LEVEL <=
                   1 + length(REGEXP_REPLACE(P_TEMPLATE_IDS, '[^,]+', '')))
      select t.template_id
        from CIMS.T_CUSTOMER_ASSESS_TEMPLATE t
       inner join tt
          on (t.template_id = to_number(tt.str))) ut on (mt.template_id = ut.template_id) when matched then
        update
           set mt.execute_status = 5
        --5已评分 3已启动未评分
        ;

    P_MESSAGE := 'SUCCESS';

  END P_ASSESS_SCORE;

END PKG_CUS_RATE_ASSESS;
/

