create PACKAGE PKG_POL_IMPORT AS
  
  -----------------------------------------------------------------------------
  -- Author  : liangym2
  -- Created : 2018/04/12 18:18:40
  --  外部零售补贴标准导入临时表检查：
  -----------------------------------------------------------------------------
  PROCEDURE P_CHECK_EXT_RETAIL_SUB(IN_ENTITY_ID IN NUMBER --主体ID
                                   ,IOS_BILL_NO  IN OUT VARCHAR2 --导入批次号
                                   ,OS_MESSAGE   OUT VARCHAR2 --成功则返回“SUCCESS”，否则返回出错信息
                                   );
  
  -----------------------------------------------------------------------------
  -- Author  : liangym2
  -- Created : 2018/04/12 18:18:40
  --  外部零售补贴标准插入临时表：
  -----------------------------------------------------------------------------
  PROCEDURE P_INSERT_EXT_RETAIL_SUB_TMP(ITAB_LIST IN TAB_IMPORT_COLS --导入数据集合
                                        --对ITAB_LIST的某些字段非空性检查，由java后台实现，避免多次TABLE(ITAB_LIST)
                                        ,IN_ENTITY_ID IN NUMBER --主体ID
                                        ,IOS_BILL_NO  IN OUT VARCHAR2 --导入批次号
                                        ,OS_MESSAGE   OUT VARCHAR2 --成功则返回“SUCCESS”，否则返回出错信息
                                        );

  ----------------------------------------------------------------------   
  -- Author  : huanghb12
  -- Created : 2018/02/28 16:34:40
  -- Purpose : 检查临时表T_POL_EXT_RETAIL_TMP数据的有效性
  ----------------------------------------------------------------------
  PROCEDURE P_CHECK_EXTRETAIL_IMPORT(P_ENTITY_ID   IN NUMBER
                                    ,P_IMPORT_CODE IN VARCHAR2
                                    ,P_RESULT      OUT VARCHAR2);

  ----------------------------------------------------------------------   
  -- Author  : ZHOULY2
  -- Created : 2018-7-13 14:33:22
  -- Purpose : 划拨单导入校验
  ----------------------------------------------------------------------
  PROCEDURE P_CHECK_TRANSFER_LINES_IMPORT(P_HEADER_ID   IN NUMBER
                                         ,P_TYPE        IN VARCHAR2
                                         ,P_USER_CODE   IN VARCHAR2
                                         ,P_RESULT_CODE OUT VARCHAR2
                                         ,P_RESULT_MSG  OUT VARCHAR2);


END PKG_POL_IMPORT;
/

