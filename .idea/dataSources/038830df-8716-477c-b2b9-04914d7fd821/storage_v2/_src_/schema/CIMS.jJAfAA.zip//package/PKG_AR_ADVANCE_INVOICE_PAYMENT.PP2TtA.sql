create package PKG_AR_ADVANCE_INVOICE_PAYMENT is

  -- Author  : TIANMENGZHU
  -- Created : 2016/1/20 14:37:28
  -- Purpose : 超三个月提前开票未回款

  V_BIZ_EXCEPTION EXCEPTION; --自定义业务异常

  /*
  * 生成甲方客户提前开票汇总报表
  */
  PROCEDURE P_THREE_MON_INVOICE_PAY_REPORT(P_MESSAGE OUT VARCHAR2);

end PKG_AR_ADVANCE_INVOICE_PAYMENT;
/

