create PACKAGE BODY PKG_CREDIT_LOCK_AMOUNT IS

  LG_LINE_STATE_NORMAL CONSTANT VARCHAR2(10) := 'NORMAL';
  LG_LINE_STATE_CLOSED CONSTANT VARCHAR2(10) := 'CLOSED';
  
  /*
  select * from table(PKG_CREDIT_LOCK_AMOUNT.F_GET_LOCK_AMOUNT(13,NULL,'C0020904',NULL,'C0020904',475,null,null,'liangxr',NULL));
  */
  
  --需要一起修改的存储过程函数：PKG_CREDIT_LAMOUNT_CCS.P_GET_LOCK_AMOUNT/PKG_CREDIT_LOCK_AMOUNT.F_GET_LOCK_AMOUNT/PKG_CREDIT_DIS.F_GET_LOCK_AMOUNT
  FUNCTION F_GET_LOCK_AMOUNT(IN_ENTITY_ID       NUMBER, --主体ID 不能为空
                             IN_CUSTOMER_ID     NUMBER, --客户ID 可以为空
                             IS_CUSTOMER_CODE   VARCHAR2, --客户编码
                             IN_ACCOUNT_ID      NUMBER, --账户ID 可以为空
                             IS_ACCOUNT_CODE    VARCHAR2, --账户编码 可以为空
                             IN_CREDIT_GROUP_ID NUMBER, --额度组ID 可以为空
                             IN_SALES_CENTER_ID   NUMBER, --营销中心ID
                             IS_SALES_CENTER_CODE VARCHAR2, --营销中心编码
                             IS_USER_ACC        VARCHAR2 --用户账号 不能为空
                             ,IS_DISCOUNT_TYPE   VARCHAR2--折让方式
                             ) RETURN TAB_CREDIT_LOCK_AMOUNT
    PIPELINED AS
  
    V_CENTER_ID      NUMBER;
    VN_CREDIT_GROUP_ID       NUMBER;
    V_LOCK_AMOUT_ROW OBJ_CREDIT_LOCK_AMOUNT;
  
    CURSOR C_LOCK_AMOUT IS
      SELECT CG.CREDIT_GROUP_NAME     AS CREDIT_GROUP_NAME,
             V.ENTITY_ID,
             V.CUSTOMER_ID,
             V.SALES_CENTER_ID,
             V.CUSTOMER_CODE,
             V.CUSTOMER_NAME,
             V.ACCOUNT_ID,
             V.ACCOUNT_CODE,
             V.ACCOUNT_NAME,
             V.SALES_MAIN_TYPE,
             V.CREDIT_GROUP_ID,
             V.DISCOUNT_TYPE,
             V.ORIGIN_ORDER_NUM,V.ORDER_NUM,
             V.DOWN_PAY_SCALE,--锁定订金比例  update 2018/5/31 by 梁颜明
             V.LOCK_METHOD,
             V.LOCKED_AMOUNT,
             V.LOCKED_DISCOUNT_AMOUNT,
             V.LOCKED_DOWNPAY_AMOUNT,
             V.LOCKED_DIS_DP_AMOUNT,
             V.SALES_CENTER_CODE      SALES_CENTER_CODE,
             V.SALES_CENTER_NAME      SALES_CENTER_NAME
        FROM (SELECT BI.ENTITY_ID,
                     BI.CUSTOMER_ID,
                     BI.SALES_CENTER_ID,
                     BI.SALES_CENTER_CODE,
                     BI.SALES_CENTER_NAME,
                     BI.CUSTOMER_CODE,
                     BI.CUSTOMER_NAME,
                     BI.ACCOUNT_ID,
                     BI.ACCOUNT_CODE,
                     BI.ACCOUNT_NAME,
                     BI.SALES_MAIN_TYPE,
                     PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(BI.ENTITY_ID,
                                                            BI.CUSTOMER_ID,
                                                            BI.SALES_MAIN_TYPE,
                                                            BI.ACCOUNT_ID) AS CREDIT_GROUP_ID,
                     NULL AS DISCOUNT_TYPE,
                     --BI.DISCOUNT_TYPE,
                     BI.ORIGIN_ORDER_NUM,BI.ORDER_NUM,
                     LO.DOWN_PAY_SCALE,--锁定订金比例  update 2018/5/31 by 梁颜明
                     BI.LOCK_METHOD,
                     SUM(BI.LOCKED_AMOUNT) LOCKED_AMOUNT,
                     SUM(BI.LOCKED_DOWNPAY_AMOUNT) LOCKED_DOWNPAY_AMOUNT,
                     SUM(BI.LOCKED_DISCOUNT_AMOUNT) LOCKED_DISCOUNT_AMOUNT,
                     SUM(BI.LOCKED_DIS_DP_AMOUNT) LOCKED_DIS_DP_AMOUNT
                FROM (
                      --v_credit_contact_amount_ar
                      SELECT T.ENTITY_ID ENTITY_ID,
                              T.CUSTOMER_ID CUSTOMER_ID,
                              T.CUSTOMER_CODE CUSTOMER_CODE,
                              T.CUSTOMER_NAME CUSTOMER_NAME,
                              T.ACCOUNT_ID,
                              T.ACCOUNT_CODE ACCOUNT_CODE,
                              T.ACCOUNT_NAME ACCOUNT_NAME,
                     AC.SALES_CENTER_ID,
                     AC.SALES_CENTER_CODE,
                     AC.SALES_CENTER_NAME,
                              T.SALES_MAIN_TYPE SALES_MAIN_TYPE,
                              NVL(T.DISCOUNT_TYPE,'COMMON') AS DISCOUNT_TYPE,
                              0 AS IS_DOWN_PAY,CAST(NULL AS NUMERIC) AS DOWN_PAY_SCALE,-- ADD YB LIANGYM2 2018-5-31 订金比例 暂时不用而是外面关联取订金比例
                              CAST(NULL AS NUMERIC) AS SRC_LG_ORDER_ID,-- ADD YB LIANGYM2 2018-5-31 来源提货订单ID
                              T.BILL_NUM ORIGIN_ORDER_NUM,NULL AS ORDER_NUM,
                              '三方承兑锁款' LOCK_METHOD,
                              NVL(ROUND(CASE T.BUSINESS_ID
                                        WHEN 'ar' Then
                                        --(CASE WHEN T.FUND_CTRL_MODE = 'Y' THEN --是否为承兑
                                        --mod by sudy 2015-12-26 到款模块三方承兑冲销改变了方式，由之前不生成冲销单改成生成产冲销单据
                                        --重算需要调整，将冲销单据剔除掉
                                        /*(CASE WHEN T.FUND_CTRL_MODE = 'Y' And t.SETTLE_AMOUNT >= 0 THEN --是否为承兑
                                        NVL(T.SETTLE_AMOUNT,0)-NVL(T.SOLUTION_PAY_AMOUNT,0) ELSE 0 END)*/
                                        
                                        --mod by 龙鸿文 2016-1-11 区分三方承兑单据是否被冲销(T.writeoff_receipt_flag = 'Y')
                                         (CASE
                                           WHEN T.FUND_CTRL_MODE = 'Y' AND
                                                T.writeoff_receipt_flag = 'Y' THEN
                                            NVL(T.SETTLE_AMOUNT, 0)
                                           WHEN T.FUND_CTRL_MODE = 'Y' AND
                                                T.writeoff_receipt_flag = 'N' THEN
                                            NVL(T.SETTLE_AMOUNT, 0) -
                                            NVL(T.SOLUTION_PAY_AMOUNT, 0)
                                           ELSE
                                            0
                                         END)
                                      
                                      /*WHEN 'so' THEN
                                         --销售单,特批销售单,工程买断销售单
                                        (CASE WHEN T.BILL_TYPE_CODE IN (1020,1022,1023) AND T.CREATED_MODE = 10 THEN
                                          (-1) * NVL(T.SETTLE_AMOUNT,0) ELSE 0 END)
                                      WHEN 'order' THEN
                                         NVL(T.SETTLE_AMOUNT,0)*/
                                        ELSE
                                         0
                                      END, 2),
                                  0) LOCKED_AMOUNT,
                              0 LOCKED_DOWNPAY_AMOUNT, --锁定订金
                              0 LOCKED_DISCOUNT_AMOUNT,
                              0 LOCKED_DIS_DP_AMOUNT --锁定折扣订金
                        FROM V_CREDIT_CONTACT_AMOUNT_AR T
                        INNER JOIN T_CUSTOMER_ACCOUNT AC ON (AC.ACCOUNT_ID = T.ACCOUNT_ID
                        AND AC.SALES_CENTER_ID = V_CENTER_ID AND AC.ENTITY_ID = IN_ENTITY_ID)
                       WHERE T.ENTITY_ID = IN_ENTITY_ID
                         AND T.CUSTOMER_CODE =
                             NVL(IS_CUSTOMER_CODE, T.CUSTOMER_CODE)
                         AND T.ACCOUNT_CODE = NVL(IS_ACCOUNT_CODE, T.ACCOUNT_CODE)
                         AND T.SETTLE_FLAG = 'Y'
                         AND 'Y' = T.FUND_CTRL_MODE
                         --AND T.SALES_CENTER_ID = V_CENTER_ID
                      UNION ALL
                      
                      --1、已下达发运计划但未生成发货通知锁款
                        SELECT T.ENTITY_ID ENTITY_ID,
                               T.CUSTOMER_ID CUSTOMER_ID,
                               T.CUSTOMER_CODE CUSTOMER_CODE,
                               T.CUSTOMER_NAME CUSTOMER_NAME,
                               A.ACCOUNT_ID AS ACCOUNT_ID,
                               T.ACCOUNT_CODE ACCOUNT_CODE,
                               T.ACCOUNT_CODE ACCOUNT_NAME,
                     A.SALES_CENTER_ID,
                     A.SALES_CENTER_CODE,
                     A.SALES_CENTER_NAME,
                               T.SALES_MAIN_TYPE SALES_MAIN_TYPE,
                               NVL(T.DISCOUNT_TYPE, 'COMMON') AS DISCOUNT_TYPE,
                               0 AS IS_DOWN_PAY,CAST(NULL AS NUMERIC) AS DOWN_PAY_SCALE,-- ADD YB LIANGYM2 2018-5-31 订金比例 暂时不用而是外面关联取订金比例
                               DECODE(T.ORIGIN_ORIGIN_TYPE,'02',T.ORIGIN_ORIGIN_HEAD_ID,T.ORIGIN_ORDER_ID) AS SRC_LG_ORDER_ID,-- ADD YB LIANGYM2 2018-5-31 来源提货订单ID
                               DECODE(T.ORIGIN_ORIGIN_TYPE,'02',T.ORIGIN_ORIGIN_ORDER_CODE,T.ORIGIN_ORDER_NUM) AS ORIGIN_ORDER_NUM,T.ORIGIN_ORDER_NUM AS ORDER_NUM,
                               /*DECODE(T.LOCK_AMOUNT_FLAG,
                                      'S',
                                      '送审锁款',
                                      'Y',
                                      '发货锁定到款',
                                      'RS',
                                      '资源送审锁定到款',
                                      'RT',
                                      '资源提货锁定到款')*/C.CODE_NAME LOCK_METHOD,
                               NVL(ROUND(CASE
                                           --20200314 家用直发锁款调整
                                           when t.origin_type = '01' and nvl(t.direct_transport_falg, 'N') = 'Y' and 
                                             (select nvl(h.amount_lock_flag, 'N')
                                                from t_pln_order_head h
                                               where h.order_head_id = t.origin_order_id) = 'NT'
                                             then
                                               0
                                           WHEN T.LOCK_AMOUNT_FLAG IN ('S', 'Y','HQ') THEN
                                           --未确认数量*单价*(100-折扣-月返)/100
                                            NVL(T.UNAFFIRM_QTY, 0) *
                                            NVL(T.ITEM_PRICE, 0) *
                                            (100 - NVL(T.DISCOUNT_RATE, 0) -
                                             NVL(T.MONTH_DISCOUNT_RATE, 0)) / 100
                                           ELSE
                                            0
                                         END,
                                         2),
                                   0) LOCKED_AMOUNT,
                               0 LOCKED_DOWNPAY_AMOUNT, --锁定订金
                               NVL(ROUND(CASE
                                           --20200314 家用直发锁款调整
                                           when t.origin_type = '01' and nvl(t.direct_transport_falg, 'N') = 'Y' and 
                                             (select nvl(h.amount_lock_flag, 'N')
                                                from t_pln_order_head h
                                               where h.order_head_id = t.origin_order_id) = 'NT'
                                             then
                                               0
                                           WHEN T.LOCK_AMOUNT_FLAG IN ('S', 'Y','HQ') THEN
                                            NVL(T.UNAFFIRM_QTY, 0) *
                                            NVL(T.ITEM_PRICE, 0) *
                                            NVL(T.DISCOUNT_RATE, 0) / 100
                                           ELSE
                                            0
                                         END,
                                         2),
                                   0) LOCKED_DISCOUNT_AMOUNT,
                               0 LOCKED_DIS_DP_AMOUNT --锁定折扣订金
                                FROM T_LG_SHIP_PLAN T
                                INNER JOIN T_CUSTOMER_ACCOUNT A
                                ON (A.ACCOUNT_CODE = T.ACCOUNT_CODE AND A.ENTITY_ID = IN_ENTITY_ID
                                AND A.SALES_CENTER_ID = V_CENTER_ID)
                                LEFT JOIN UP_CODELIST C
                                  ON (C.CODE_VALUE = T.LOCK_AMOUNT_FLAG AND C.CODETYPE = 'plnlockMoneyFlag')
                               WHERE T.ENTITY_ID = IN_ENTITY_ID
                                 AND T.CUSTOMER_CODE =
                                     NVL(IS_CUSTOMER_CODE, T.CUSTOMER_CODE)
                                 AND T.ACCOUNT_CODE =
                                     NVL(IS_ACCOUNT_CODE, T.ACCOUNT_CODE)
                                 AND T.STATUS IN ('00', '01') --撤销单据没有锁款
                                 AND T.LOCK_AMOUNT_FLAG IN
                                     ('S', 'Y', 'RS', 'RT','HQ')
                                 AND NVL(T.CUSTOMIZE_FLAG, 'N') = 'N'
                                 --AND T.SALES_CENTER_ID = V_CENTER_ID
                              UNION ALL
                              --3、已生成发货通知未生成销售单锁款
                              SELECT A.ENTITY_ID ENTITY_ID,
                               A.CUSTOMER_ID CUSTOMER_ID,
                               A.CUSTOMER_CODE CUSTOMER_CODE,
                               A.CUSTOMER_NAME CUSTOMER_NAME,
                               ACC.ACCOUNT_ID AS ACCOUNT_ID,
                               A.ACCOUNT_CODE ACCOUNT_CODE,
                               A.ACCOUNT_CODE ACCOUNT_NAME,
                     ACC.SALES_CENTER_ID,
                     ACC.SALES_CENTER_CODE,
                     ACC.SALES_CENTER_NAME,
                               B.SALES_MAIN_TYPE SALES_MAIN_TYPE,
                               NVL(B.DISCOUNT_TYPE, 'COMMON') AS DISCOUNT_TYPE,
                               0 AS IS_DOWN_PAY,CAST(NULL AS NUMERIC) AS DOWN_PAY_SCALE,-- ADD YB LIANGYM2 2018-5-31 订金比例 暂时不用而是外面关联取订金比例
                               DECODE(B.ORIGIN_ORIGIN_TYPE,'02',B.ORIGIN_ORIGIN_HEAD_ID,B.ORIGIN_ORDER_ID) AS SRC_LG_ORDER_ID,-- ADD YB LIANGYM2 2018-5-31 来源提货订单ID
                               DECODE(B.ORIGIN_ORIGIN_TYPE,'02',B.ORIGIN_ORIGIN_DOC_CODE,B.ORIGIN_ORDER_NUM) AS ORIGIN_ORDER_NUM,B.ORIGIN_ORDER_NUM AS ORDER_NUM,
                               /*DECODE(B.LOCK_AMOUNT_FLAG,
                                      'S',
                                      '送审锁款',
                                      'Y',
                                      '发货锁定到款',
                                      'RS',
                                      '资源送审锁定到款',
                                      'RT',
                                      '资源提货锁定到款')*/C.CODE_NAME LOCK_METHOD,
                               NVL(ROUND(CASE
                                           --20200314 家用直发锁款调整
                                           when b.origin_type = '01' and nvl(a.direct_transport_falg, 'N') = 'Y' and 
                                             (select nvl(h.amount_lock_flag, 'N')
                                                from t_pln_order_head h
                                               where h.order_head_id = b.origin_order_id) = 'NT'
                                             then
                                               0
                                           WHEN B.LOCK_AMOUNT_FLAG IN ('S', 'Y','HQ') THEN
                                           --(ITEM_QTY产品数量 - FACT_SHIP_QTY实际发货数量 - CANCEL_QTY累积取消数量)*单价*(100-折扣-月返)/100
                                            (NVL(B.ITEM_QTY, 0) -
                                            NVL(B.FACT_SHIP_QTY, 0) -
                                            NVL(B.CANCEL_QTY, 0)) *
                                            NVL(B.ITEM_PRICE, 0) *
                                            (100 - NVL(B.DISCOUNT_RATE, 0) -
                                            NVL(B.MONTH_DISCOUNT_RATE, 0)) / 100
                                           ELSE
                                            0
                                         END,
                                         2),
                                   0) LOCKED_AMOUNT,
                               0 LOCKED_DOWNPAY_AMOUNT, --锁定订金
                               NVL(ROUND(CASE
                                           --20200314 家用直发锁款调整
                                           when b.origin_type = '01' and nvl(a.direct_transport_falg, 'N') = 'Y' and 
                                             (select nvl(h.amount_lock_flag, 'N')
                                                from t_pln_order_head h
                                               where h.order_head_id = b.origin_order_id) = 'NT'
                                             then
                                               0
                                           WHEN B.LOCK_AMOUNT_FLAG IN ('S', 'Y','HQ') THEN
                                            (NVL(B.ITEM_QTY, 0) -
                                            NVL(B.FACT_SHIP_QTY, 0) -
                                            NVL(B.CANCEL_QTY, 0)) *
                                            NVL(B.ITEM_PRICE, 0) *
                                            NVL(B.DISCOUNT_RATE, 0) / 100
                                           ELSE
                                            0
                                         END,
                                         2),
                                   0) LOCKED_DISCOUNT_AMOUNT,
                               0 LOCKED_DIS_DP_AMOUNT --锁定折扣订金
                                FROM T_LG_SHIP_DOC A --发货通知单头
                               INNER JOIN T_LG_SHIP_DOC_LINE B --发货通知单行
                                  ON (A.SHIP_DOC_ID = B.SHIP_DOC_ID)
                                
                                INNER JOIN T_CUSTOMER_ACCOUNT ACC
                                ON (ACC.ACCOUNT_CODE = A.ACCOUNT_CODE AND ACC.ENTITY_ID = IN_ENTITY_ID
                                AND ACC.SALES_CENTER_ID = V_CENTER_ID)
                                LEFT JOIN UP_CODELIST C
                                  ON (C.CODE_VALUE = B.LOCK_AMOUNT_FLAG AND C.CODETYPE = 'plnlockMoneyFlag')
                               WHERE A.ENTITY_ID = IN_ENTITY_ID
                                 AND A.CUSTOMER_CODE =
                                     NVL(IS_CUSTOMER_CODE, A.CUSTOMER_CODE)
                                 AND A.ACCOUNT_CODE =
                                     NVL(IS_ACCOUNT_CODE, A.ACCOUNT_CODE)
                                 AND A.DOC_STATUS <> '01' --单据状态 00正常 01红冲
                                 AND B.LOCK_AMOUNT_FLAG IN
                                     ('S', 'Y', 'RS', 'RT','HQ')
                                 AND NVL(A.CUSTOMIZE_FLAG, 'N') = 'N'
                                 --AND A.SALES_CENTER_ID = V_CENTER_ID
                              UNION ALL
                              --制定发货需求计划下达（直发客户） 发货计划未确认（未生成发货通知单）
                              SELECT T.TRANSFER_ENTITY_ID ENTITY_ID,
                               T.TRANSFER_CUSTOMER_ID CUSTOMER_ID,
                               T.TRANSFER_CUSTOMER_CODE CUSTOMER_CODE,
                               T.TRANSFER_CUSTOMER_NAME CUSTOMER_NAME,
                               T.TRANSFER_ACCOUNT_ID ACCOUNT_ID,
                               T.TRANSFER_ACCOUNT_CODE ACCOUNT_CODE,
                               T.TRANSFER_ACCOUNT_CODE ACCOUNT_NAME,
                     A.SALES_CENTER_ID,
                     A.SALES_CENTER_CODE,
                     A.SALES_CENTER_NAME,
                               T.TRANSFER_ITEM_MAIN_TYPE SALES_MAIN_TYPE,
                               NVL(T.TRANSFER_DISCOUNT_TYPE, 'COMMON') AS DISCOUNT_TYPE,
                               0 AS IS_DOWN_PAY,CAST(NULL AS NUMERIC) AS DOWN_PAY_SCALE,-- ADD YB LIANGYM2 2018-5-31 订金比例 暂时不用而是外面关联取订金比例
                               DECODE(T.ORIGIN_ORIGIN_TYPE,'02',T.ORIGIN_ORIGIN_HEAD_ID,T.ORIGIN_ORDER_ID) AS SRC_LG_ORDER_ID,-- ADD YB LIANGYM2 2018-5-31 来源提货订单ID
                               DECODE(T.ORIGIN_ORIGIN_TYPE,'02',T.ORIGIN_ORIGIN_ORDER_CODE,T.ORIGIN_ORDER_NUM) AS ORIGIN_ORDER_NUM,T.ORIGIN_ORDER_NUM AS ORDER_NUM,
                               '发货锁定到款（直发）' LOCK_METHOD,
                               NVL(ROUND(
                                         --锁定代理商到款(未确认数量*直发列表价*(100-直发扣率-直发月返)/100)
                                         NVL(T.UNAFFIRM_QTY, 0) *
                                         NVL(T.TRANSFER_LIST_PRICE, 0) *
                                         (100 -
                                          NVL(T.TRANSFER_DISCOUNT_RATE, 0) -
                                          NVL(T.TRANSFER_MONTH_DISCOUNT_RATE,
                                              0)) / 100,
                                         2),
                                   0) LOCKED_AMOUNT,
                               0 LOCKED_DOWNPAY_AMOUNT, --锁定订金
                               NVL(ROUND(NVL(T.UNAFFIRM_QTY, 0) *
                                         NVL(T.TRANSFER_LIST_PRICE, 0) *
                                         NVL(T.TRANSFER_DISCOUNT_RATE, 0) / 100,
                                         2),
                                   0) LOCKED_DISCOUNT_AMOUNT, --锁定代理商折让(未确认数量*直发列表价*直发扣率/100),
                               0 LOCKED_DIS_DP_AMOUNT --锁定折扣订金
                                FROM T_LG_SHIP_PLAN T
                                INNER JOIN T_CUSTOMER_ACCOUNT A
                                ON (A.ACCOUNT_ID = T.TRANSFER_ACCOUNT_ID AND A.ENTITY_ID = IN_ENTITY_ID
                                AND A.SALES_CENTER_ID = V_CENTER_ID)
                               WHERE T.TRANSFER_ENTITY_ID = IN_ENTITY_ID
                                 AND T.TRANSFER_ACCOUNT_CODE =
                                     NVL(IS_ACCOUNT_CODE, T.TRANSFER_ACCOUNT_CODE)
                                 AND T.TRANSFER_CUSTOMER_CODE =
                                     NVL(IS_CUSTOMER_CODE,
                                         T.TRANSFER_CUSTOMER_CODE)
                                 AND T.STATUS IN ('00', '01') --撤销单据没有锁款
                                 AND T.TRANSFER_LOCK_AMOUNT_FLAG = 'Y'
                                 AND T.TRANSFER_ITEM_MAIN_TYPE IS NOT NULL
                              UNION ALL
                              --制定发货需求计划下达（直发客户） 发货通知单未生成销售单
                              SELECT A.TRANSFER_ENTITY_ID ENTITY_ID,
                               A.TRANSFER_CUSTOMER_ID CUSTOMER_ID,
                               A.TRANSFER_CUSTOMER_CODE CUSTOMER_CODE,
                               A.TRANSFER_CUSTOMER_NAME AS CUSTOMER_NAME,
                               A.TRANSFER_ACCOUNT_ID ACCOUNT_ID,
                               A.TRANSFER_ACCOUNT_CODE ACCOUNT_CODE,
                               A.TRANSFER_ACCOUNT_CODE ACCOUNT_NAME,
                     ACC.SALES_CENTER_ID,
                     ACC.SALES_CENTER_CODE,
                     ACC.SALES_CENTER_NAME,
                               B.TRANSFER_ITEM_MAIN_TYPE SALES_MAIN_TYPE,
                               NVL(B.TRANSFER_DISCOUNT_TYPE, 'COMMON') AS DISCOUNT_TYPE,
                               0 AS IS_DOWN_PAY,CAST(NULL AS NUMERIC) AS DOWN_PAY_SCALE,-- ADD YB LIANGYM2 2018-5-31 订金比例 暂时不用而是外面关联取订金比例
                               DECODE(B.ORIGIN_ORIGIN_TYPE,'02',B.ORIGIN_ORIGIN_HEAD_ID,B.ORIGIN_ORDER_ID) AS SRC_LG_ORDER_ID,-- ADD YB LIANGYM2 2018-5-31 来源提货订单ID
                               DECODE(B.ORIGIN_ORIGIN_TYPE,'02',B.ORIGIN_ORIGIN_DOC_CODE,B.ORIGIN_ORDER_NUM) AS ORIGIN_ORDER_NUM,B.ORIGIN_ORDER_NUM AS ORDER_NUM,
                               '发货锁定到款（直发）' LOCK_METHOD,
                               NVL(ROUND( --锁定代理商到款((产品数量-已取消数量-已转采购数量)*直发列表价*(100-直发扣率-直发月返)/100)
                                         (NVL(B.ITEM_QTY, 0) -
                                         NVL(B.CANCEL_QTY, 0) -
                                         NVL(B.TRANSFER_TO_POX_QTY, 0)) *
                                         NVL(B.TRANSFER_LIST_PRICE, 0) *
                                         (100 -
                                         NVL(B.TRANSFER_DISCOUNT_RATE, 0) -
                                         NVL(B.TRANSFER_MONTH_DISCOUNT_RATE,
                                              0)) / 100,
                                         2),
                                   0) LOCKED_AMOUNT,
                               0 LOCKED_DOWNPAY_AMOUNT, --锁定订金
                               NVL(ROUND((NVL(B.ITEM_QTY, 0) -
                                         NVL(B.FACT_SHIP_QTY, 0) -
                                         NVL(B.CANCEL_QTY, 0) -
                                         NVL(B.TRANSFER_TO_POX_QTY, 0)) *
                                         NVL(B.TRANSFER_LIST_PRICE, 0) *
                                         NVL(B.TRANSFER_DISCOUNT_RATE, 0) / 100,
                                         2),
                                   0) LOCKED_DISCOUNT_AMOUNT, --锁定代理商折让((产品数量-已取消数量-已转采购数量)*直发列表价*直发扣率/100)
                               0 LOCKED_DIS_DP_AMOUNT --锁定折扣订金
                                FROM T_LG_SHIP_DOC A --发货通知单头
                               INNER JOIN T_LG_SHIP_DOC_LINE B
                                  ON (A.SHIP_DOC_ID = B.SHIP_DOC_ID) --发货通知单行
                                INNER JOIN T_CUSTOMER_ACCOUNT ACC
                                ON (ACC.ACCOUNT_ID = A.TRANSFER_ACCOUNT_ID AND ACC.ENTITY_ID = IN_ENTITY_ID
                                AND ACC.SALES_CENTER_ID = V_CENTER_ID)
                               WHERE A.TRANSFER_ENTITY_ID = IN_ENTITY_ID
                                 AND A.TRANSFER_ACCOUNT_CODE =
                                     NVL(IS_ACCOUNT_CODE, A.TRANSFER_ACCOUNT_CODE)
                                 AND A.TRANSFER_CUSTOMER_CODE =
                                     NVL(IS_CUSTOMER_CODE,
                                         A.TRANSFER_CUSTOMER_CODE)
                                 AND A.DOC_STATUS <> '01' --单据状态 00正常 01红冲
                                 AND B.TRANSFER_LOCK_AMOUNT_FLAG = 'Y'
                                 AND B.TRANSFER_ITEM_MAIN_TYPE IS NOT NULL
                              UNION ALL
                              --送审锁款：已经送审未下达发运计划的锁款 提货订单 常规部分
                              SELECT A.ENTITY_ID ENTITY_ID,
                               A.CUSTOMER_ID CUSTOMER_ID,
                               A.CUSTOMER_CODE CUSTOMER_CODE,
                               A.CUSTOMER_NAME CUSTOMER_NAME,
                               A.ACCOUNT_ID ACCOUNT_ID,
                               A.ACCOUNT_CODE ACCOUNT_CODE,
                               A.ACCOUNT_NAME ACCOUNT_NAME,
                     ACC.SALES_CENTER_ID,
                     ACC.SALES_CENTER_CODE,
                     ACC.SALES_CENTER_NAME,
                               B.SALES_MAIN_TYPE SALES_MAIN_TYPE,
                               --'COMMON' AS DISCOUNT_TYPE,--常规部分
                               NVL(B.DISCOUNT_TYPE,'COMMON') AS DISCOUNT_TYPE,
                               0 AS IS_DOWN_PAY,CAST(NULL AS NUMERIC) AS DOWN_PAY_SCALE,-- ADD YB LIANGYM2 2018-5-31 订金比例 暂时不用而是外面关联取订金比例
                               A.ORDER_HEAD_ID AS SRC_LG_ORDER_ID,-- ADD YB LIANGYM2 2018-5-31 来源提货订单ID
                               A.ORDER_NUMBER ORIGIN_ORDER_NUM,NULL AS ORDER_NUM,
                               /*DECODE(A.LOCK_AMOUNT_FLAG,
                                      'S',
                                      '送审锁款',
                                      'RS',
                                      '资源送审锁款')*/C.CODE_NAME LOCK_METHOD,
                               NVL(ROUND(CASE
                                           WHEN nvl(b.order_line_state,LG_LINE_STATE_NORMAL)=LG_LINE_STATE_CLOSED
                                             and nvl(b.is_lock_amount,'N')<>'NT' THEN
                                             0
                                           --20200314 家用直发锁款调整
                                           WHEN (A.LOCK_AMOUNT_FLAG = 'S'
                                               --2016-09-23 TIANMZH修改，订金比例为空或小于0时，计算锁定到款，否则，锁定到款为0.
                                                AND (A.DOWN_PAY_SCALE IS NULL OR A.DOWN_PAY_SCALE < 0)) 
                                                OR NVL(B.IS_LOCK_AMOUNT, 'N') = 'Y' THEN
                                            (CASE
                                              when nvl(b.is_lock_amount,'N')='NT' THEN
                                                NVL(B.CENTER_AFFIRM_QUANTITY, 0) - NVL(B.CANCEL_QTY, 0)
                                            --2016-09-13 TIANMZH修改，增加'2225'，显示产能可视状态('2225'提货订单金额。
                                              WHEN A.ORDER_HEAD_STATE IN ('20', '1455', '2225') and nvl(b.order_line_state,LG_LINE_STATE_NORMAL)<>LG_LINE_STATE_CLOSED THEN
                                               NVL(DECODE(A.HQ_LG_ORDER_HEAD_ID,NULL,B.QUANTITY,0,B.QUANTITY,B.CENTER_AFFIRM_QUANTITY), 0) -
                                               NVL(B.AFFIRMED_QUANTITY, 0) - NVL(B.CANCEL_QTY, 0)
                                               -(NVL(B.transfer_hq_affirmed_qty,0)-NVL(B.SENDED_QTY,0))
                                               -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                              WHEN A.ORDER_HEAD_STATE IN ('381', '679') and nvl(b.order_line_state,LG_LINE_STATE_NORMAL)<>LG_LINE_STATE_CLOSED THEN
                                               NVL(B.CENTER_AFFIRM_QUANTITY, 0) - NVL(B.AFFIRMED_QUANTITY, 0) - NVL(B.CANCEL_QTY, 0)
                                               -(NVL(B.transfer_hq_affirmed_qty,0)-NVL(B.SENDED_QTY,0))
                                               -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                              ELSE
                                               0
                                            END)
                                           ELSE
                                            0
                                         END
                                         * DECODE(B.PROJECT_ORDER_TYPE,
                                                   NULL,
                                                   NVL(B.LIST_PRICE, 0),
                                                   NVL(B.APPLY_LIST_PRICE, 0))
                                           --ADD BY LIZHEN 2015-11-30 增加月返计算
                                            * (100 -
                                            DECODE(B.PROJECT_ORDER_TYPE,
                                                      NULL,
                                                      NVL(B.DISCOUNT_RATE, 0),
                                                      NVL(B.APPLY_DISCOUNT_RATE, 0)) -
                                            NVL(B.ORDERED_DISCOUNT_RATE, 0)) / 100,
                                         2),
                                   0) LOCKED_AMOUNT,
                               
                               --ADD TIANMZH 2016-09-13 ，增加锁定订金（锁款方式 = "送审锁款"，订金比例 > 0，锁定订金=锁定到款*订金比例）
                               NVL(ROUND(CASE
                                           --20200314 家用直发锁款调整
                                           WHEN (nvl(b.order_line_state,LG_LINE_STATE_NORMAL)=LG_LINE_STATE_CLOSED and nvl(b.is_lock_amount,'N')<>'NT')
                                             OR NVL(B.IS_LOCK_AMOUNT, 'N') = 'Y' THEN
                                             0
                                           WHEN A.LOCK_AMOUNT_FLAG = 'S' AND NVL(A.DOWN_PAY_SCALE, 0) > 0 THEN
                                            (CASE
                                              WHEN NVL(B.IS_LOCK_AMOUNT, 'N') = 'NT' THEN
                                                NVL(B.CENTER_AFFIRM_QUANTITY, 0) - NVL(B.CANCEL_QTY, 0)
                                            --2016-09-13 TIANMZH修改，增加'2225'，显示产能可视状态('2225'提货订单金额。
                                              WHEN A.ORDER_HEAD_STATE IN ('20', '1455', '2225') and nvl(b.order_line_state,LG_LINE_STATE_NORMAL)<>LG_LINE_STATE_CLOSED THEN
                                               NVL(DECODE(A.HQ_LG_ORDER_HEAD_ID,NULL,B.QUANTITY,0,B.QUANTITY,B.CENTER_AFFIRM_QUANTITY), 0) -
                                               NVL(B.AFFIRMED_QUANTITY, 0) -
                                               NVL(B.CANCEL_QTY, 0) - (NVL(B.transfer_hq_affirmed_qty,0)-NVL(B.SENDED_QTY,0)) --20180105 hejy3 增加订金发货锁全款处理
                                               -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                              WHEN A.ORDER_HEAD_STATE IN ('381', '679') and nvl(b.order_line_state,LG_LINE_STATE_NORMAL)<>LG_LINE_STATE_CLOSED THEN
                                               NVL(B.CENTER_AFFIRM_QUANTITY, 0) - NVL(B.AFFIRMED_QUANTITY, 0) - NVL(B.CANCEL_QTY, 0)
                                               -(NVL(B.transfer_hq_affirmed_qty,0)-NVL(B.SENDED_QTY,0))
                                               -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                              ELSE
                                               0
                                            END) *
                                            DECODE(B.PROJECT_ORDER_TYPE,
                                                   NULL,
                                                   NVL(B.LIST_PRICE, 0),
                                                   NVL(B.APPLY_LIST_PRICE, 0))
                                           --ADD BY LIZHEN 2015-11-30 增加月返计算
                                            * (100 -
                                            DECODE(B.PROJECT_ORDER_TYPE,
                                                      NULL,
                                                      NVL(B.DISCOUNT_RATE, 0),
                                                      NVL(B.APPLY_DISCOUNT_RATE, 0)) -
                                            NVL(B.ORDERED_DISCOUNT_RATE, 0)) / 100 *
                                            A.DOWN_PAY_SCALE / 100
                                           ELSE
                                            0
                                         END,
                                         2),
                                   0) LOCKED_DOWNPAY_AMOUNT, --锁定订金
                               NVL(ROUND(CASE
                                           WHEN nvl(b.order_line_state,LG_LINE_STATE_NORMAL)=LG_LINE_STATE_CLOSED
                                             and nvl(b.is_lock_amount,'N')<>'NT' THEN
                                             0
                                           WHEN B.DISCOUNT_TYPE <> 'COMMON' THEN
                                             0
                                           --20200314 家用直发锁款调整
                                           WHEN (A.LOCK_AMOUNT_FLAG = 'S' AND (A.DOWN_PAY_SCALE IS NULL OR A.DOWN_PAY_SCALE < 0)) 
                                             OR NVL(B.IS_LOCK_AMOUNT, 'N') = 'Y' THEN
                                           --ADD BY LIZHEN 2015-11-30 T+3订单回写取消数量，并会释放款项，所以取消数量重算时不计入锁款
                                            (CASE
                                              when nvl(b.is_lock_amount,'N')='NT' THEN
                                                NVL(B.CENTER_AFFIRM_QUANTITY, 0) - NVL(B.CANCEL_QTY, 0)
                                            --2016-09-13 TIANMZH修改，增加'2225'，显示产能可视状态('2225'提货订单金额。
                                              WHEN A.ORDER_HEAD_STATE IN ('20', '1455', '2225') and nvl(b.order_line_state,LG_LINE_STATE_NORMAL)<>LG_LINE_STATE_CLOSED THEN
                                               NVL(DECODE(A.HQ_LG_ORDER_HEAD_ID,NULL,B.QUANTITY,0,B.QUANTITY,B.CENTER_AFFIRM_QUANTITY), 0) -
                                               NVL(B.AFFIRMED_QUANTITY, 0) - NVL(B.CANCEL_QTY, 0)
                                               -(NVL(B.transfer_hq_affirmed_qty,0)-NVL(B.SENDED_QTY,0))
                                               -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                              WHEN A.ORDER_HEAD_STATE IN ('381', '679') and nvl(b.order_line_state,LG_LINE_STATE_NORMAL)<>LG_LINE_STATE_CLOSED THEN
                                               NVL(B.CENTER_AFFIRM_QUANTITY, 0) - NVL(B.AFFIRMED_QUANTITY, 0) - NVL(B.CANCEL_QTY, 0)
                                               -(NVL(B.transfer_hq_affirmed_qty,0)-NVL(B.SENDED_QTY,0))
                                               -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                              ELSE
                                               0
                                            END)
                                           ELSE
                                            0
                                         END
                                         * DECODE(B.PROJECT_ORDER_TYPE,
                                                   NULL,
                                                   NVL(B.LIST_PRICE, 0),
                                                   NVL(B.APPLY_LIST_PRICE, 0)) *
                                            DECODE(B.PROJECT_ORDER_TYPE,
                                                   NULL,
                                                   NVL(B.DISCOUNT_RATE, 0),
                                                   NVL(B.APPLY_DISCOUNT_RATE, 0)) / 100,
                                         2),
                                   0) LOCKED_DISCOUNT_AMOUNT,
                               NVL(ROUND(CASE
                                           --20200314 家用直发锁款调整
                                           WHEN (nvl(b.order_line_state,LG_LINE_STATE_NORMAL)=LG_LINE_STATE_CLOSED and nvl(b.is_lock_amount,'N')<>'NT')
                                             OR NVL(B.IS_LOCK_AMOUNT, 'N') = 'Y' THEN
                                             0
                                           WHEN B.DISCOUNT_TYPE <> 'COMMON' THEN
                                             0
                                           WHEN A.LOCK_AMOUNT_FLAG = 'S' AND NVL(A.DOWN_PAY_SCALE, 0) > 0 THEN
                                           --ADD BY LIZHEN 2015-11-30 T+3订单回写取消数量，并会释放款项，所以取消数量重算时不计入锁款
                                            (CASE
                                              WHEN NVL(B.IS_LOCK_AMOUNT, 'N') = 'NT' THEN
                                                NVL(B.CENTER_AFFIRM_QUANTITY, 0) - NVL(B.CANCEL_QTY, 0)
                                            --2016-09-13 TIANMZH修改，增加'2225'，显示产能可视状态('2225'提货订单金额。
                                              WHEN A.ORDER_HEAD_STATE IN ('20', '1455', '2225') and nvl(b.order_line_state,LG_LINE_STATE_NORMAL)<>LG_LINE_STATE_CLOSED THEN
                                               NVL(DECODE(A.HQ_LG_ORDER_HEAD_ID,NULL,B.QUANTITY,0,B.QUANTITY,B.CENTER_AFFIRM_QUANTITY), 0) -
                                               NVL(B.AFFIRMED_QUANTITY, 0) -
                                               NVL(B.CANCEL_QTY, 0) - (NVL(B.transfer_hq_affirmed_qty,0)-NVL(B.SENDED_QTY,0)) --20180105 hejy3 增加订金发货锁全款处理
                                               -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                              WHEN A.ORDER_HEAD_STATE IN ('381', '679') and nvl(b.order_line_state,LG_LINE_STATE_NORMAL)<>LG_LINE_STATE_CLOSED THEN
                                               NVL(B.CENTER_AFFIRM_QUANTITY, 0) - NVL(B.AFFIRMED_QUANTITY, 0) - NVL(B.CANCEL_QTY, 0)
                                               -(NVL(B.transfer_hq_affirmed_qty,0)-NVL(B.SENDED_QTY,0))
                                               -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                              ELSE
                                               0
                                            END) *
                                            DECODE(B.PROJECT_ORDER_TYPE,
                                                   NULL,
                                                   NVL(B.LIST_PRICE, 0),
                                                   NVL(B.APPLY_LIST_PRICE, 0)) *
                                            DECODE(B.PROJECT_ORDER_TYPE,
                                                   NULL,
                                                   NVL(B.DISCOUNT_RATE, 0),
                                                   NVL(B.APPLY_DISCOUNT_RATE, 0)) / 100 *
                                            A.DOWN_PAY_SCALE / 100
                                           ELSE
                                            0
                                         END,
                                         2),
                                   0) LOCKED_DIS_DP_AMOUNT --锁定折扣订金
                                FROM T_PLN_LG_ORDER_HEAD A --物流订单头表
                               INNER JOIN T_PLN_LG_ORDER_LINE B --物流订单行表
                                  ON (A.ORDER_HEAD_ID = B.ORDER_HEAD_ID)
                                INNER JOIN T_CUSTOMER_ACCOUNT ACC
                                ON (ACC.ACCOUNT_ID = A.ACCOUNT_ID AND ACC.ENTITY_ID = IN_ENTITY_ID
                                AND ACC.SALES_CENTER_ID = V_CENTER_ID)
                                LEFT JOIN UP_CODELIST C
                                  ON (C.CODE_VALUE = A.LOCK_AMOUNT_FLAG AND C.CODETYPE = 'plnlockMoneyFlag')
                               WHERE A.ENTITY_ID = IN_ENTITY_ID
                                 AND A.ACCOUNT_CODE =
                                     NVL(IS_ACCOUNT_CODE, A.ACCOUNT_CODE)
                                 AND A.CUSTOMER_CODE =
                                     NVL(IS_CUSTOMER_CODE, A.CUSTOMER_CODE)
                                 AND A.ORDER_HEAD_STATE IN
                                    --2016-09-13 TIANMZH修改，增加'2225'，显示产能可视状态('2225'提货订单金额。
                                     ('20', '23', '381', '679', '1455', '2225', '304')
                                 AND A.LOCK_AMOUNT_FLAG IN ('S', 'RS')
                                 AND NVL(A.CUSTOMIZE_FLAG, 'N') = 'N'
                                 --AND A.SALES_CENTER_ID = V_CENTER_ID
                              UNION ALL
                              --hejy3 送总部评审锁款
                              SELECT A.ENTITY_ID ENTITY_ID,
                               A.CUSTOMER_ID CUSTOMER_ID,
                               A.CUSTOMER_CODE CUSTOMER_CODE,
                               A.CUSTOMER_NAME CUSTOMER_NAME,
                               A.ACCOUNT_ID ACCOUNT_ID,
                               A.ACCOUNT_CODE ACCOUNT_CODE,
                               A.ACCOUNT_NAME ACCOUNT_NAME,
                               ACC.SALES_CENTER_ID,
                               ACC.SALES_CENTER_CODE,
                               ACC.SALES_CENTER_NAME,
                               B.SALES_MAIN_TYPE SALES_MAIN_TYPE,
                               --'COMMON' AS DISCOUNT_TYPE,--常规部分
                               NVL(B.DISCOUNT_TYPE,'COMMON') AS DISCOUNT_TYPE,
                               0 AS IS_DOWN_PAY,CAST(NULL AS NUMERIC) AS DOWN_PAY_SCALE,-- ADD YB LIANGYM2 2018-5-31 订金比例 暂时不用而是外面关联取订金比例
                               A.ORDER_HEAD_ID AS SRC_LG_ORDER_ID,-- ADD YB LIANGYM2 2018-5-31 来源提货订单ID
                               A.ORDER_NUMBER ORIGIN_ORDER_NUM,NULL AS ORDER_NUM,
                               /*DECODE(A.LOCK_AMOUNT_FLAG,
                                      'S',
                                      '送审锁款',
                                      'RS',
                                      '资源送审锁款')*/C.CODE_NAME LOCK_METHOD,
                               NVL(ROUND(CASE
                                           WHEN nvl(b.order_line_state,LG_LINE_STATE_NORMAL)=LG_LINE_STATE_CLOSED
                                             and nvl(b.is_lock_amount,'N')<>'NT' THEN
                                             0
                                           --20200314 家用直发锁款调整
                                           WHEN (A.DOWN_PAY_SCALE IS NULL OR A.DOWN_PAY_SCALE < 0) 
                                             OR NVL(B.IS_LOCK_AMOUNT, 'N') = 'Y' THEN
                                            (CASE
                                              when nvl(b.is_lock_amount,'N')='NT' THEN
                                                NVL(B.CENTER_AFFIRM_QUANTITY, 0) - NVL(B.CANCEL_QTY, 0)
                                            --2016-09-13 TIANMZH修改，增加'2225'，显示产能可视状态('2225'提货订单金额。
                                              WHEN (A.ORDER_HEAD_STATE IN ('20', '1455', '2225') AND HA.SUBMIT_TO_HQ_FLAG = 'Y')
                                                OR A.SUBMIT_TO_HQ_FLAG = 'Y' THEN
                                               NVL(B.CENTER_AFFIRM_QUANTITY, 0) - NVL(B.AFFIRMED_QUANTITY, 0) - NVL(B.CANCEL_QTY, 0)
                                               -(NVL(B.transfer_hq_affirmed_qty,0)-NVL(B.SENDED_QTY,0))
                                               -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                              ELSE
                                               0
                                            END)
                                           ELSE
                                            0
                                         END
                                         * DECODE(B.PROJECT_ORDER_TYPE,
                                                   NULL,
                                                   NVL(B.LIST_PRICE, 0),
                                                   NVL(B.APPLY_LIST_PRICE, 0))
                                           --ADD BY LIZHEN 2015-11-30 增加月返计算
                                            * (100 -
                                            DECODE(B.PROJECT_ORDER_TYPE,
                                                      NULL,
                                                      NVL(B.DISCOUNT_RATE, 0),
                                                      NVL(B.APPLY_DISCOUNT_RATE, 0)) -
                                            NVL(B.ORDERED_DISCOUNT_RATE, 0)) / 100,
                                         2),
                                   0) LOCKED_AMOUNT,
                               
                               --ADD TIANMZH 2016-09-13 ，增加锁定订金（锁款方式 = "送审锁款"，订金比例 > 0，锁定订金=锁定到款*订金比例）
                               NVL(ROUND(CASE
                                           --20200314 家用直发锁款调整
                                           WHEN (nvl(b.order_line_state,LG_LINE_STATE_NORMAL)=LG_LINE_STATE_CLOSED and nvl(b.is_lock_amount,'N')<>'NT')
                                             OR NVL(B.IS_LOCK_AMOUNT, 'N') = 'Y' THEN
                                             0
                                           WHEN NVL(A.DOWN_PAY_SCALE, 0) > 0 THEN
                                            (CASE
                                              WHEN NVL(B.IS_LOCK_AMOUNT, 'N') = 'NT' THEN
                                                NVL(B.CENTER_AFFIRM_QUANTITY, 0) - NVL(B.CANCEL_QTY, 0)
                                            --2016-09-13 TIANMZH修改，增加'2225'，显示产能可视状态('2225'提货订单金额。
                                              WHEN (A.ORDER_HEAD_STATE IN ('20', '1455', '2225') AND HA.SUBMIT_TO_HQ_FLAG = 'Y')
                                                OR A.SUBMIT_TO_HQ_FLAG = 'Y' THEN
                                               NVL(B.CENTER_AFFIRM_QUANTITY, 0) - NVL(B.AFFIRMED_QUANTITY, 0) - NVL(B.CANCEL_QTY, 0)
                                               -(NVL(B.transfer_hq_affirmed_qty,0)-NVL(B.SENDED_QTY,0))
                                               -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                              ELSE
                                               0
                                            END) *
                                            DECODE(B.PROJECT_ORDER_TYPE,
                                                   NULL,
                                                   NVL(B.LIST_PRICE, 0),
                                                   NVL(B.APPLY_LIST_PRICE, 0))
                                           --ADD BY LIZHEN 2015-11-30 增加月返计算
                                            * (100 -
                                            DECODE(B.PROJECT_ORDER_TYPE,
                                                      NULL,
                                                      NVL(B.DISCOUNT_RATE, 0),
                                                      NVL(B.APPLY_DISCOUNT_RATE, 0)) -
                                            NVL(B.ORDERED_DISCOUNT_RATE, 0)) / 100 *
                                            A.DOWN_PAY_SCALE / 100
                                           ELSE
                                            0
                                         END,
                                         2),
                                   0) LOCKED_DOWNPAY_AMOUNT, --锁定订金
                               NVL(ROUND(CASE
                                           WHEN nvl(b.order_line_state,LG_LINE_STATE_NORMAL)=LG_LINE_STATE_CLOSED
                                             and nvl(b.is_lock_amount,'N')<>'NT' THEN
                                             0
                                           WHEN B.DISCOUNT_TYPE <> 'COMMON' THEN
                                             0
                                           --20200314 家用直发锁款调整
                                           WHEN (A.DOWN_PAY_SCALE IS NULL OR A.DOWN_PAY_SCALE < 0) 
                                             OR NVL(B.IS_LOCK_AMOUNT, 'N') = 'Y' THEN
                                           --ADD BY LIZHEN 2015-11-30 T+3订单回写取消数量，并会释放款项，所以取消数量重算时不计入锁款
                                            (CASE
                                              when nvl(b.is_lock_amount,'N')='NT' THEN
                                                NVL(B.CENTER_AFFIRM_QUANTITY, 0) - NVL(B.CANCEL_QTY, 0)
                                            --2016-09-13 TIANMZH修改，增加'2225'，显示产能可视状态('2225'提货订单金额。
                                              WHEN (A.ORDER_HEAD_STATE IN ('20', '1455', '2225') AND HA.SUBMIT_TO_HQ_FLAG = 'Y')
                                                OR A.SUBMIT_TO_HQ_FLAG = 'Y' THEN
                                               NVL(B.CENTER_AFFIRM_QUANTITY, 0) - NVL(B.AFFIRMED_QUANTITY, 0) - NVL(B.CANCEL_QTY, 0)
                                               -(NVL(B.transfer_hq_affirmed_qty,0)-NVL(B.SENDED_QTY,0))
                                               -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                              ELSE
                                               0
                                            END)
                                           ELSE
                                            0
                                         END
                                         * DECODE(B.PROJECT_ORDER_TYPE,
                                                   NULL,
                                                   NVL(B.LIST_PRICE, 0),
                                                   NVL(B.APPLY_LIST_PRICE, 0)) *
                                            DECODE(B.PROJECT_ORDER_TYPE,
                                                   NULL,
                                                   NVL(B.DISCOUNT_RATE, 0),
                                                   NVL(B.APPLY_DISCOUNT_RATE, 0)) / 100,
                                         2),
                                   0) LOCKED_DISCOUNT_AMOUNT,
                               NVL(ROUND(CASE
                                           --20200314 家用直发锁款调整
                                           WHEN (nvl(b.order_line_state,LG_LINE_STATE_NORMAL)=LG_LINE_STATE_CLOSED and nvl(b.is_lock_amount,'N')<>'NT')
                                             OR NVL(B.IS_LOCK_AMOUNT, 'N') = 'Y' THEN
                                             0
                                           WHEN B.DISCOUNT_TYPE <> 'COMMON' THEN
                                             0
                                           WHEN NVL(A.DOWN_PAY_SCALE, 0) > 0 THEN
                                           --ADD BY LIZHEN 2015-11-30 T+3订单回写取消数量，并会释放款项，所以取消数量重算时不计入锁款
                                            (CASE
                                              WHEN NVL(B.IS_LOCK_AMOUNT, 'N') = 'NT' THEN
                                                NVL(B.CENTER_AFFIRM_QUANTITY, 0) -  NVL(B.CANCEL_QTY, 0)
                                            --2016-09-13 TIANMZH修改，增加'2225'，显示产能可视状态('2225'提货订单金额。
                                              WHEN (A.ORDER_HEAD_STATE IN ('20', '1455', '2225') AND HA.SUBMIT_TO_HQ_FLAG = 'Y')
                                                OR A.SUBMIT_TO_HQ_FLAG = 'Y' THEN
                                               NVL(B.CENTER_AFFIRM_QUANTITY, 0) - NVL(B.AFFIRMED_QUANTITY, 0) - NVL(B.CANCEL_QTY, 0)
                                               -(NVL(B.transfer_hq_affirmed_qty,0)-NVL(B.SENDED_QTY,0))
                                               -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                              ELSE
                                               0
                                            END) *
                                            DECODE(B.PROJECT_ORDER_TYPE,
                                                   NULL,
                                                   NVL(B.LIST_PRICE, 0),
                                                   NVL(B.APPLY_LIST_PRICE, 0)) *
                                            DECODE(B.PROJECT_ORDER_TYPE,
                                                   NULL,
                                                   NVL(B.DISCOUNT_RATE, 0),
                                                   NVL(B.APPLY_DISCOUNT_RATE, 0)) / 100 *
                                            A.DOWN_PAY_SCALE / 100
                                           ELSE
                                            0
                                         END,
                                         2),
                                   0) LOCKED_DIS_DP_AMOUNT --锁定折扣订金
                                FROM T_PLN_LG_ORDER_HEAD A --物流订单头表
                               INNER JOIN T_PLN_LG_ORDER_LINE B --物流订单行表
                                  ON (A.ORDER_HEAD_ID = B.ORDER_HEAD_ID)
                                INNER JOIN T_CUSTOMER_ACCOUNT ACC
                                ON (ACC.ACCOUNT_ID = A.ACCOUNT_ID AND ACC.ENTITY_ID = IN_ENTITY_ID
                                AND ACC.SALES_CENTER_ID = V_CENTER_ID)
                                LEFT JOIN UP_CODELIST C
                                  ON (C.CODE_VALUE = A.LOCK_AMOUNT_FLAG AND C.CODETYPE = 'plnlockMoneyFlag')
                                LEFT JOIN T_PLN_LG_ORDER_HEAD HA
                                  ON (HA.ORDER_HEAD_ID = A.HQ_LG_ORDER_HEAD_ID)
                               WHERE A.ENTITY_ID = IN_ENTITY_ID
                                 AND A.ACCOUNT_CODE =
                                     NVL(IS_ACCOUNT_CODE, A.ACCOUNT_CODE)
                                 AND A.CUSTOMER_CODE =
                                     NVL(IS_CUSTOMER_CODE, A.CUSTOMER_CODE)
                                 AND A.ORDER_HEAD_STATE IN
                                    --2016-09-13 TIANMZH修改，增加'2225'，显示产能可视状态('2225'提货订单金额。
                                     ('20', '23', '381', '679', '1455', '2225', '304')
                                 AND A.LOCK_AMOUNT_FLAG IN ('HQ')
                                 AND NVL(A.CUSTOMIZE_FLAG, 'N') = 'N'
                              UNION ALL
                              --针对已结转总部主体且发货锁款的提货订单 常规部分
                              SELECT A.ENTITY_ID ENTITY_ID,
                               A.CUSTOMER_ID CUSTOMER_ID,
                               A.CUSTOMER_CODE CUSTOMER_CODE,
                               A.CUSTOMER_NAME CUSTOMER_NAME,
                               A.ACCOUNT_ID ACCOUNT_ID,
                               A.ACCOUNT_CODE ACCOUNT_CODE,
                               A.ACCOUNT_NAME ACCOUNT_NAME,
                     ACC.SALES_CENTER_ID,
                     ACC.SALES_CENTER_CODE,
                     ACC.SALES_CENTER_NAME,
                               B.SALES_MAIN_TYPE SALES_MAIN_TYPE,
                               --'COMMON' AS DISCOUNT_TYPE,--常规部分
                               NVL(B.DISCOUNT_TYPE,'COMMON') AS DISCOUNT_TYPE,
                               0 AS IS_DOWN_PAY,CAST(NULL AS NUMERIC) AS DOWN_PAY_SCALE,-- ADD YB LIANGYM2 2018-5-31 订金比例 暂时不用而是外面关联取订金比例
                               A.ORDER_HEAD_ID AS SRC_LG_ORDER_ID,-- ADD YB LIANGYM2 2018-5-31 来源提货订单ID
                               A.ORDER_NUMBER ORIGIN_ORDER_NUM,NULL AS ORDER_NUM,
                               /*DECODE(A.LOCK_AMOUNT_FLAG,
                                      'Y',
                                      '发货锁款')*/c.code_name LOCK_METHOD,
                               NVL(ROUND(CASE WHEN NVL(B.IS_LOCK_AMOUNT, 'N') <> 'NT' THEN
                                            (NVL(B.transfer_hq_affirmed_qty,0)-NVL(B.SENDED_QTY,0)) *
                                            DECODE(B.PROJECT_ORDER_TYPE,
                                                   NULL,
                                                   NVL(B.LIST_PRICE, 0),
                                                   NVL(B.APPLY_LIST_PRICE, 0))
                                           --ADD BY LIZHEN 2015-11-30 增加月返计算
                                            * (100 -
                                            DECODE(B.PROJECT_ORDER_TYPE,
                                                      NULL,
                                                      NVL(B.DISCOUNT_RATE, 0),
                                                      NVL(B.APPLY_DISCOUNT_RATE, 0)) -
                                            NVL(B.ORDERED_DISCOUNT_RATE, 0)) / 100
                                           ELSE 0 END
                                         ,2),
                                   0) LOCKED_AMOUNT,
                               0 LOCKED_DOWNPAY_AMOUNT, --锁定订金
                               NVL(ROUND(CASE
                                           WHEN B.DISCOUNT_TYPE <> 'COMMON' THEN
                                             0
                                           WHEN NVL(B.IS_LOCK_AMOUNT, 'N') <> 'NT' THEN
                                           (NVL(B.transfer_hq_affirmed_qty,0)-NVL(B.SENDED_QTY,0)) *
                                            DECODE(B.PROJECT_ORDER_TYPE,
                                                   NULL,
                                                   NVL(B.LIST_PRICE, 0),
                                                   NVL(B.APPLY_LIST_PRICE, 0)) *
                                            DECODE(B.PROJECT_ORDER_TYPE,
                                                   NULL,
                                                   NVL(B.DISCOUNT_RATE, 0),
                                                   NVL(B.APPLY_DISCOUNT_RATE, 0)) / 100
                                           ELSE 0
                                         END,
                                         2),
                                   0) LOCKED_DISCOUNT_AMOUNT,
                               0 LOCKED_DIS_DP_AMOUNT --锁定折扣订金
                                FROM T_PLN_LG_ORDER_HEAD A --物流订单头表
                               INNER JOIN T_PLN_LG_ORDER_LINE B --物流订单行表
                                  ON (A.ORDER_HEAD_ID = B.ORDER_HEAD_ID)
                                INNER JOIN T_CUSTOMER_ACCOUNT ACC
                                ON (ACC.ACCOUNT_ID = A.ACCOUNT_ID AND ACC.ENTITY_ID = IN_ENTITY_ID
                                AND ACC.SALES_CENTER_ID = V_CENTER_ID)
                                LEFT JOIN UP_CODELIST C
                                  ON (C.CODE_VALUE = A.LOCK_AMOUNT_FLAG AND C.CODETYPE = 'plnlockMoneyFlag')
                               WHERE A.ENTITY_ID = IN_ENTITY_ID
                                 AND A.ACCOUNT_CODE =
                                     NVL(IS_ACCOUNT_CODE, A.ACCOUNT_CODE)
                                 AND A.CUSTOMER_CODE =
                                     NVL(IS_CUSTOMER_CODE, A.CUSTOMER_CODE)
                                 AND A.ORDER_HEAD_STATE IN
                                     ('20', '23', '381', '679', '1455', '2225', '304')
                                 AND B.TRANSFER_HQ_AFFIRMED_QTY > 0
                                 AND NVL(A.CUSTOMIZE_FLAG, 'N') = 'N'
                                
                              UNION ALL
                              --1.2、计划订单
                              SELECT POH.ENTITY_ID ENTITY_ID,
                               POH.CUSTOMER_ID CUSTOMER_ID,
                               POH.CUSTOMER_CODE CUSTOMER_CODE,
                               POH.CUSTOMER_NAME CUSTOMER_NAME,
                               POH.ACCOUNT_ID ACCOUNT_ID,
                               POH.ACCOUNT_CODE ACCOUNT_CODE,
                               POH.ACCOUNT_NAME ACCOUNT_NAME,
                     ACC.SALES_CENTER_ID,
                     ACC.SALES_CENTER_CODE,
                     ACC.SALES_CENTER_NAME,
                               NVL(POL.SALES_MAIN_TYPE,
                                   BI.SALES_MAIN_TYPE) SALES_MAIN_TYPE,
                               'COMMON' AS DISCOUNT_TYPE,
                               0 AS IS_DOWN_PAY,CAST(NULL AS NUMERIC) AS DOWN_PAY_SCALE,-- ADD YB LIANGYM2 2018-5-31 订金比例 暂时不用而是外面关联取订金比例
                               CAST(NULL AS NUMERIC) AS SRC_LG_ORDER_ID,-- ADD YB LIANGYM2 2018-5-31 来源提货订单ID
                               POH.ORDER_NUMBER ORIGIN_ORDER_NUM,NULL AS ORDER_NUM,
                               --POH.LOCK_AMOUNT_FLAG 送审锁款,(这一行写错了别名)
                               /*DECODE(POH.LOCK_AMOUNT_FLAG,
                                      'S',
                                      '送审锁款',
                                      'Y',
                                      '发货锁定到款')*/C.CODE_NAME LOCK_METHOD,
                               NVL(ROUND((CASE
                                            WHEN NVL(POH.DOWN_PAY_SCALE, -1) < 0 THEN
                                              CASE
                                               WHEN POH.FORM_STATE NOT IN
                                                    ('23',
                                                     '32',
                                                     '248',
                                                     '303',
                                                     '304',
                                                     '306') THEN
                                                NVL(POL.APPLY_QTY, 0) -
                                                NVL(POL.CARRY_QTY, 0) -
                                                NVL(POL.CANCEL_INV_CHECK_QTY, 0) -
                                                NVL(POL.CANCEL_INV_IN_QTY, 0)
                                               WHEN POH.FORM_STATE IN ('23', '32') THEN
                                                NVL(POL.CAN_PRODUCE_QTY, 0) +
                                                NVL(POL.INV_AFFIRM_QTY, 0) -
                                                NVL(POL.CARRY_QTY, 0) -
                                                NVL(POL.CANCEL_INV_CHECK_QTY, 0) -
                                                NVL(POL.CANCEL_INV_IN_QTY, 0)
                                               ELSE
                                                0
                                              END
                                            ELSE
                                              0
                                          END
                                         ) * POL.ITEM_PRICE *
                                         (100 -
                                         NVL(POL.DISCOUNT_RATE, 0) -
                                         NVL(POL.ORDERED_DISCOUNT_RATE,
                                              0)) / 100,
                                         2),
                                   0) LOCKED_AMOUNT,
                               NVL(ROUND((CASE
                                            WHEN POH.DOWN_PAY_SCALE > 0 THEN
                                              POH.DOWN_PAY_SCALE / 100 *
                                              CASE
                                               WHEN POH.FORM_STATE NOT IN
                                                    ('23',
                                                     '32',
                                                     '248',
                                                     '303',
                                                     '304',
                                                     '306') THEN
                                                NVL(POL.APPLY_QTY, 0) -
                                                NVL(POL.CARRY_QTY, 0) -
                                                NVL(POL.CANCEL_INV_CHECK_QTY, 0) -
                                                NVL(POL.CANCEL_INV_IN_QTY, 0)
                                               WHEN POH.FORM_STATE IN ('23', '32') THEN
                                                NVL(POL.CAN_PRODUCE_QTY, 0) +
                                                NVL(POL.INV_AFFIRM_QTY, 0) -
                                                NVL(POL.CARRY_QTY, 0) -
                                                NVL(POL.CANCEL_INV_CHECK_QTY, 0) -
                                                NVL(POL.CANCEL_INV_IN_QTY, 0)
                                               ELSE
                                                0
                                              END
                                            ELSE
                                              0
                                          END
                                         ) * POL.ITEM_PRICE *
                                         (100 -
                                         NVL(POL.DISCOUNT_RATE, 0) -
                                         NVL(POL.ORDERED_DISCOUNT_RATE,
                                              0)) / 100,
                                         2),
                                   0) LOCKED_DOWNPAY_AMOUNT, --锁定订金
                               NVL(ROUND((CASE
                                            WHEN NVL(POH.DOWN_PAY_SCALE, -1) < 0 THEN
                                              CASE
                                               WHEN POH.FORM_STATE NOT IN
                                                    ('23', '32', '248', '303', '304', '306') THEN
                                                NVL(POL.APPLY_QTY, 0) -
                                                NVL(POL.CARRY_QTY, 0) -
                                                NVL(POL.CANCEL_INV_CHECK_QTY, 0) -
                                                NVL(POL.CANCEL_INV_CHECK_QTY, 0)
                                               WHEN POH.FORM_STATE IN
                                                    ('23', '32') THEN--, '306'
                                                NVL(POL.CAN_PRODUCE_QTY, 0) +
                                                NVL(POL.INV_AFFIRM_QTY, 0) -
                                                NVL(POL.CARRY_QTY, 0) -
                                                NVL(POL.CANCEL_INV_CHECK_QTY, 0) -
                                                NVL(POL.CANCEL_INV_CHECK_QTY, 0)
                                               ELSE
                                                0
                                              END
                                            ELSE
                                              0
                                          END
                                         ) * POL.ITEM_PRICE *
                                         NVL(POL.DISCOUNT_RATE, 0) / 100,
                                         2),
                                   0) LOCKED_DISCOUNT_AMOUNT,
                               NVL(ROUND((CASE
                                            WHEN POH.DOWN_PAY_SCALE > 0 THEN
                                              POH.DOWN_PAY_SCALE / 100 *
                                              CASE
                                               WHEN POH.FORM_STATE NOT IN
                                                    ('23', '32', '248', '303', '304', '306') THEN
                                                NVL(POL.APPLY_QTY, 0) -
                                                NVL(POL.CARRY_QTY, 0) -
                                                NVL(POL.CANCEL_INV_CHECK_QTY, 0) -
                                                NVL(POL.CANCEL_INV_CHECK_QTY, 0)
                                               WHEN POH.FORM_STATE IN
                                                    ('23', '32') THEN--, '306'
                                                NVL(POL.CAN_PRODUCE_QTY, 0) +
                                                NVL(POL.INV_AFFIRM_QTY, 0) -
                                                NVL(POL.CARRY_QTY, 0) -
                                                NVL(POL.CANCEL_INV_CHECK_QTY, 0) -
                                                NVL(POL.CANCEL_INV_CHECK_QTY, 0)
                                               ELSE
                                                0
                                              END
                                            ELSE
                                              0
                                          END
                                         ) * POL.ITEM_PRICE *
                                         NVL(POL.DISCOUNT_RATE, 0) / 100,
                                         2),
                                   0) AS LOCKED_DIS_DP_AMOUNT
                                FROM T_PLN_ORDER_HEAD POH --计划订单头表
                               INNER JOIN T_PLN_ORDER_LINE POL
                                  ON (POH.ORDER_HEAD_ID = POL.ORDER_HEAD_ID) --计划订单行表
                                INNER JOIN T_CUSTOMER_ACCOUNT ACC
                                ON (ACC.ACCOUNT_ID = POH.ACCOUNT_ID AND ACC.ENTITY_ID = IN_ENTITY_ID
                                AND ACC.SALES_CENTER_ID = V_CENTER_ID)
                               INNER JOIN T_PLN_ORDER_TYPE POT
                                  ON (POT.ORDER_TYPE_ID = POH.ORDER_TYPE_ID) --订单类型表
                               INNER JOIN t_Bd_Item BI
                                  ON (Bi.Item_Id = Pol.Item_Id And
                                     Bi.Entity_Id = Pol.Entity_Id)
                                LEFT JOIN UP_CODELIST C
                                  ON (C.CODE_VALUE = POH.LOCK_AMOUNT_FLAG AND C.CODETYPE = 'plnlockMoneyFlag')
                               WHERE POH.ENTITY_ID = IN_ENTITY_ID
                                 AND POH.ACCOUNT_CODE =
                                     NVL(IS_ACCOUNT_CODE, POH.ACCOUNT_CODE)
                                 AND POH.CUSTOMER_CODE =
                                     NVL(IS_CUSTOMER_CODE, POH.CUSTOMER_CODE)
                                 AND NVL(POH.LOCK_AMOUNT_FLAG, 'N') = 'S'
                                 AND POH.FORM_STATE NOT IN
                                     ('19', '248', '303', '304', '305')
                                 --AND POH.SALES_CENTER_ID = V_CENTER_ID
                      ) BI
                                LEFT JOIN T_PLN_LG_ORDER_HEAD LO
                                ON (LO.ORDER_HEAD_ID = BI.SRC_LG_ORDER_ID AND LO.ENTITY_ID = IN_ENTITY_ID
                                AND (IS_CUSTOMER_CODE IS NULL OR LO.CUSTOMER_CODE = IS_CUSTOMER_CODE)
                                AND (IS_ACCOUNT_CODE IS NULL OR LO.ACCOUNT_CODE = IS_ACCOUNT_CODE)
                                )
              --WHERE CO.SALES_CENTER_ID = V_CENTER_ID
               GROUP BY BI.ENTITY_ID,
                        BI.CUSTOMER_ID,
                        BI.SALES_CENTER_ID,
                        BI.SALES_CENTER_CODE,
                        BI.SALES_CENTER_NAME,
                        BI.CUSTOMER_CODE,
                        BI.CUSTOMER_NAME,
                        BI.ACCOUNT_ID,
                        BI.ACCOUNT_CODE,
                        BI.ACCOUNT_NAME,
                        BI.SALES_MAIN_TYPE,
                        PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(BI.ENTITY_ID,
                                                               BI.CUSTOMER_ID,
                                                               BI.SALES_MAIN_TYPE,
                                                               BI.ACCOUNT_ID),
                        --BI.DISCOUNT_TYPE,
                        BI.ORIGIN_ORDER_NUM,BI.ORDER_NUM,
                        LO.DOWN_PAY_SCALE,--锁定订金比例  update 2018/5/31 by 梁颜明
                        BI.LOCK_METHOD
              --梁颜明 2016-09-24修改 锁定到款拆分为普通的锁款和订金 计算锁定到款时两值要相加
              HAVING 0 <> SUM(BI.LOCKED_DISCOUNT_AMOUNT + BI.LOCKED_DIS_DP_AMOUNT)
              --
              OR 0 <> SUM(BI.LOCKED_AMOUNT + BI.LOCKED_DOWNPAY_AMOUNT)
              --
              UNION ALL
              SELECT D.ENTITY_ID,
                     D.CUSTOMER_ID,
                     D.SALES_CENTER_ID,
                     D.SALES_CENTER_CODE,
                     D.SALES_CENTER_NAME,
                     D.CUSTOMER_CODE,
                     D.CUSTOMER_NAME,
                     D.ACCOUNT_ID,
                     D.ACCOUNT_CODE,
                     D.ACCOUNT_NAME,
                     D.SALES_MAIN_TYPE,
                     D.CREDIT_GROUP_ID,
                     NULL AS DISCOUNT_TYPE,
                     D.ORIGIN_ORDER_NUM,
                     NULL ORDER_NUM,
                     D.DOWN_PAY_SCALE,
                     D.LOCK_METHOD,
                     D.LOCKED_AMOUNT,
                     D.LOCKED_DOWNPAY_AMOUNT,
                     D.LOCKED_DISCOUNT_AMOUNT,
                     D.LOCKED_DIS_DP_AMOUNT
                FROM T_CREDIT_LOCK_AMOUNT_DETAIL D
               WHERE D.ENTITY_ID = IN_ENTITY_ID
                 AND D.SALES_CENTER_ID = V_CENTER_ID
                 AND D.ACCOUNT_CODE = NVL(IS_ACCOUNT_CODE, D.ACCOUNT_CODE)
                 AND D.CUSTOMER_CODE = NVL(IS_CUSTOMER_CODE, D.CUSTOMER_CODE)
                 AND (D.LOCKED_DISCOUNT_AMOUNT + D.LOCKED_DIS_DP_AMOUNT <> 0
                   OR D.LOCKED_AMOUNT + D.LOCKED_DOWNPAY_AMOUNT <> 0)
              ) V
       INNER JOIN T_CREDIT_GROUP CG
          ON (CG.ENTITY_ID = V.ENTITY_ID AND
             CG.CREDIT_GROUP_ID = V.CREDIT_GROUP_ID)
       WHERE (VN_CREDIT_GROUP_ID IS NULL OR 0 >= VN_CREDIT_GROUP_ID
             --
             OR VN_CREDIT_GROUP_ID = V.CREDIT_GROUP_ID)
         AND EXISTS (SELECT VA.ACCOUNT_ID
                FROM CIMS.MT_BD_USER_ACC_PRIV VA
               WHERE VA.USER_CODE = IS_USER_ACC
                 AND VA.ENTITY_ID = IN_ENTITY_ID
                 AND VA.ACCOUNT_ID = V.ACCOUNT_ID)
                 ;
    --无中心条件
    CURSOR C_LOCK_AMOUT_NOCENTER IS
      SELECT CG.CREDIT_GROUP_NAME     AS CREDIT_GROUP_NAME,
             V.ENTITY_ID,
             V.CUSTOMER_ID,
             V.SALES_CENTER_ID,
             V.CUSTOMER_CODE,
             V.CUSTOMER_NAME,
             V.ACCOUNT_ID,
             V.ACCOUNT_CODE,
             V.ACCOUNT_NAME,
             V.SALES_MAIN_TYPE,
             V.CREDIT_GROUP_ID,
             V.DISCOUNT_TYPE,
             V.ORIGIN_ORDER_NUM,V.ORDER_NUM,
             V.DOWN_PAY_SCALE,--锁定订金比例  update 2018/5/31 by 梁颜明
             V.LOCK_METHOD,
             V.LOCKED_AMOUNT,
             V.LOCKED_DISCOUNT_AMOUNT,
             V.LOCKED_DOWNPAY_AMOUNT,
             V.LOCKED_DIS_DP_AMOUNT,
             V.SALES_CENTER_CODE      SALES_CENTER_CODE,
             V.SALES_CENTER_NAME      SALES_CENTER_NAME
        FROM (SELECT BI.ENTITY_ID,
                     BI.CUSTOMER_ID,
                     A.SALES_CENTER_ID,
                     A.SALES_CENTER_CODE,
                     A.SALES_CENTER_NAME,
                     BI.CUSTOMER_CODE,
                     BI.CUSTOMER_NAME,
                     A.ACCOUNT_ID,
                     BI.ACCOUNT_CODE,
                     BI.ACCOUNT_NAME,
                     BI.SALES_MAIN_TYPE,
                     PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(BI.ENTITY_ID,
                                                            BI.CUSTOMER_ID,
                                                            BI.SALES_MAIN_TYPE,
                                                            A.ACCOUNT_ID) AS CREDIT_GROUP_ID,
                     NULL AS DISCOUNT_TYPE,
                     --BI.DISCOUNT_TYPE,
                     BI.ORIGIN_ORDER_NUM,BI.ORDER_NUM,
                     LO.DOWN_PAY_SCALE,--锁定订金比例  update 2018/5/31 by 梁颜明
                     BI.LOCK_METHOD,
                     SUM(BI.LOCKED_AMOUNT) LOCKED_AMOUNT,
                     SUM(BI.LOCKED_DOWNPAY_AMOUNT) LOCKED_DOWNPAY_AMOUNT,
                     SUM(BI.LOCKED_DISCOUNT_AMOUNT) LOCKED_DISCOUNT_AMOUNT,
                     SUM(BI.LOCKED_DIS_DP_AMOUNT) LOCKED_DIS_DP_AMOUNT
                FROM (
                      --v_credit_contact_amount_ar
                      SELECT T.ENTITY_ID ENTITY_ID,
                              T.CUSTOMER_ID CUSTOMER_ID,
                              T.CUSTOMER_CODE CUSTOMER_CODE,
                              T.CUSTOMER_NAME CUSTOMER_NAME,
                              T.ACCOUNT_ID,
                              T.ACCOUNT_CODE ACCOUNT_CODE,
                              T.ACCOUNT_NAME ACCOUNT_NAME,
                              T.SALES_MAIN_TYPE SALES_MAIN_TYPE,
                              NVL(T.DISCOUNT_TYPE,'COMMON') AS DISCOUNT_TYPE,
                              0 AS IS_DOWN_PAY,CAST(NULL AS NUMERIC) AS DOWN_PAY_SCALE,-- ADD YB LIANGYM2 2018-5-31 订金比例 暂时不用而是外面关联取订金比例
                              CAST(NULL AS NUMERIC) AS SRC_LG_ORDER_ID,-- ADD YB LIANGYM2 2018-5-31 来源提货订单ID
                              T.BILL_NUM ORIGIN_ORDER_NUM,NULL AS ORDER_NUM,
                              '三方承兑锁款' LOCK_METHOD,
                              NVL(ROUND(CASE T.BUSINESS_ID
                                        WHEN 'ar' Then
                                        --(CASE WHEN T.FUND_CTRL_MODE = 'Y' THEN --是否为承兑
                                        --mod by sudy 2015-12-26 到款模块三方承兑冲销改变了方式，由之前不生成冲销单改成生成产冲销单据
                                        --重算需要调整，将冲销单据剔除掉
                                        /*(CASE WHEN T.FUND_CTRL_MODE = 'Y' And t.SETTLE_AMOUNT >= 0 THEN --是否为承兑
                                        NVL(T.SETTLE_AMOUNT,0)-NVL(T.SOLUTION_PAY_AMOUNT,0) ELSE 0 END)*/
                                        
                                        --mod by 龙鸿文 2016-1-11 区分三方承兑单据是否被冲销(T.writeoff_receipt_flag = 'Y')
                                         (CASE
                                           WHEN T.FUND_CTRL_MODE = 'Y' AND
                                                T.writeoff_receipt_flag = 'Y' THEN
                                            NVL(T.SETTLE_AMOUNT, 0)
                                           WHEN T.FUND_CTRL_MODE = 'Y' AND
                                                T.writeoff_receipt_flag = 'N' THEN
                                            NVL(T.SETTLE_AMOUNT, 0) -
                                            NVL(T.SOLUTION_PAY_AMOUNT, 0)
                                           ELSE
                                            0
                                         END)
                                      
                                      /*WHEN 'so' THEN
                                         --销售单,特批销售单,工程买断销售单
                                        (CASE WHEN T.BILL_TYPE_CODE IN (1020,1022,1023) AND T.CREATED_MODE = 10 THEN
                                          (-1) * NVL(T.SETTLE_AMOUNT,0) ELSE 0 END)
                                      WHEN 'order' THEN
                                         NVL(T.SETTLE_AMOUNT,0)*/
                                        ELSE
                                         0
                                      END, 2),
                                  0) LOCKED_AMOUNT,
                              0 LOCKED_DOWNPAY_AMOUNT, --锁定订金
                              0 LOCKED_DISCOUNT_AMOUNT,
                              0 LOCKED_DIS_DP_AMOUNT --锁定折扣订金
                        FROM V_CREDIT_CONTACT_AMOUNT_AR T
                       WHERE T.ENTITY_ID = IN_ENTITY_ID
                         AND T.CUSTOMER_CODE =
                             NVL(IS_CUSTOMER_CODE, T.CUSTOMER_CODE)
                         AND T.ACCOUNT_CODE = NVL(IS_ACCOUNT_CODE, T.ACCOUNT_CODE)
                         AND 'Y' = T.FUND_CTRL_MODE
                         AND T.SETTLE_FLAG = 'Y'
                      UNION ALL
                      --1、已下达发运计划但未生成发货通知锁款
                        SELECT T.ENTITY_ID ENTITY_ID,
                               T.CUSTOMER_ID CUSTOMER_ID,
                               T.CUSTOMER_CODE CUSTOMER_CODE,
                               T.CUSTOMER_NAME CUSTOMER_NAME,
                               0 AS ACCOUNT_ID,
                               T.ACCOUNT_CODE ACCOUNT_CODE,
                               T.ACCOUNT_CODE ACCOUNT_NAME,
                               T.SALES_MAIN_TYPE SALES_MAIN_TYPE,
                               NVL(T.DISCOUNT_TYPE, 'COMMON') AS DISCOUNT_TYPE,
                               0 AS IS_DOWN_PAY,CAST(NULL AS NUMERIC) AS DOWN_PAY_SCALE,-- ADD YB LIANGYM2 2018-5-31 订金比例 暂时不用而是外面关联取订金比例
                               DECODE(T.ORIGIN_ORIGIN_TYPE,'02',T.ORIGIN_ORIGIN_HEAD_ID,T.ORIGIN_ORDER_ID) AS SRC_LG_ORDER_ID,-- ADD YB LIANGYM2 2018-5-31 来源提货订单ID
                               DECODE(T.ORIGIN_ORIGIN_TYPE,'02',T.ORIGIN_ORIGIN_ORDER_CODE,T.ORIGIN_ORDER_NUM) AS ORIGIN_ORDER_NUM,T.ORIGIN_ORDER_NUM AS ORDER_NUM,
                               /*DECODE(T.LOCK_AMOUNT_FLAG,
                                      'S',
                                      '送审锁款',
                                      'Y',
                                      '发货锁定到款',
                                      'RS',
                                      '资源送审锁定到款',
                                      'RT',
                                      '资源提货锁定到款')*/c.code_name LOCK_METHOD,
                               NVL(ROUND(CASE
                                           --20200314 家用直发锁款调整
                                           when t.origin_type = '01' and nvl(t.direct_transport_falg, 'N') = 'Y' and 
                                             (select nvl(h.amount_lock_flag, 'N')
                                                from t_pln_order_head h
                                               where h.order_head_id = t.origin_order_id) = 'NT'
                                             then
                                               0
                                           WHEN T.LOCK_AMOUNT_FLAG IN ('S', 'Y','HQ') THEN
                                           --未确认数量*单价*(100-折扣-月返)/100
                                            NVL(T.UNAFFIRM_QTY, 0) *
                                            NVL(T.ITEM_PRICE, 0) *
                                            (100 - NVL(T.DISCOUNT_RATE, 0) -
                                             NVL(T.MONTH_DISCOUNT_RATE, 0)) / 100
                                           ELSE
                                            0
                                         END,
                                         2),
                                   0) LOCKED_AMOUNT,
                               0 LOCKED_DOWNPAY_AMOUNT, --锁定订金
                               NVL(ROUND(CASE
                                           --20200314 家用直发锁款调整
                                           when t.origin_type = '01' and nvl(t.direct_transport_falg, 'N') = 'Y' and 
                                             (select nvl(h.amount_lock_flag, 'N')
                                                from t_pln_order_head h
                                               where h.order_head_id = t.origin_order_id) = 'NT'
                                             then
                                               0
                                           WHEN T.LOCK_AMOUNT_FLAG IN ('S', 'Y','HQ') THEN
                                            NVL(T.UNAFFIRM_QTY, 0) *
                                            NVL(T.ITEM_PRICE, 0) *
                                            NVL(T.DISCOUNT_RATE, 0) / 100
                                           ELSE
                                            0
                                         END,
                                         2),
                                   0) LOCKED_DISCOUNT_AMOUNT,
                               0 LOCKED_DIS_DP_AMOUNT --锁定折扣订金
                                FROM T_LG_SHIP_PLAN T
                                LEFT JOIN UP_CODELIST C
                                  ON (C.CODE_VALUE = T.LOCK_AMOUNT_FLAG AND C.CODETYPE = 'plnlockMoneyFlag')
                               WHERE T.ENTITY_ID = IN_ENTITY_ID
                                 AND T.CUSTOMER_CODE =
                                     NVL(IS_CUSTOMER_CODE, T.CUSTOMER_CODE)
                                 AND T.ACCOUNT_CODE =
                                     NVL(IS_ACCOUNT_CODE, T.ACCOUNT_CODE)
                                 AND T.STATUS IN ('00', '01') --撤销单据没有锁款
                                 AND T.LOCK_AMOUNT_FLAG IN
                                     ('S', 'Y', 'RS', 'RT','HQ')
                                 AND NVL(T.CUSTOMIZE_FLAG, 'N') = 'N'
                              UNION ALL
                              --3、已生成发货通知未生成销售单锁款
                              SELECT A.ENTITY_ID ENTITY_ID,
                               A.CUSTOMER_ID CUSTOMER_ID,
                               A.CUSTOMER_CODE CUSTOMER_CODE,
                               A.CUSTOMER_NAME CUSTOMER_NAME,
                               0 AS ACCOUNT_ID,
                               A.ACCOUNT_CODE ACCOUNT_CODE,
                               A.ACCOUNT_CODE ACCOUNT_NAME,
                               B.SALES_MAIN_TYPE SALES_MAIN_TYPE,
                               NVL(B.DISCOUNT_TYPE, 'COMMON') AS DISCOUNT_TYPE,
                               0 AS IS_DOWN_PAY,CAST(NULL AS NUMERIC) AS DOWN_PAY_SCALE,-- ADD YB LIANGYM2 2018-5-31 订金比例 暂时不用而是外面关联取订金比例
                               DECODE(B.ORIGIN_ORIGIN_TYPE,'02',B.ORIGIN_ORIGIN_HEAD_ID,B.ORIGIN_ORDER_ID) AS SRC_LG_ORDER_ID,-- ADD YB LIANGYM2 2018-5-31 来源提货订单ID
                               DECODE(B.ORIGIN_ORIGIN_TYPE,'02',B.ORIGIN_ORIGIN_DOC_CODE,B.ORIGIN_ORDER_NUM) AS ORIGIN_ORDER_NUM,B.ORIGIN_ORDER_NUM AS ORDER_NUM,
                               /*DECODE(B.LOCK_AMOUNT_FLAG,
                                      'S',
                                      '送审锁款',
                                      'Y',
                                      '发货锁定到款',
                                      'RS',
                                      '资源送审锁定到款',
                                      'RT',
                                      '资源提货锁定到款')*/C.CODE_NAME LOCK_METHOD,
                               NVL(ROUND(CASE
                                           --20200314 家用直发锁款调整
                                           when b.origin_type = '01' and nvl(a.direct_transport_falg, 'N') = 'Y' and 
                                             (select nvl(h.amount_lock_flag, 'N')
                                                from t_pln_order_head h
                                               where h.order_head_id = b.origin_order_id) = 'NT'
                                             then
                                               0
                                           WHEN B.LOCK_AMOUNT_FLAG IN ('S', 'Y','HQ') THEN
                                           --(ITEM_QTY产品数量 - FACT_SHIP_QTY实际发货数量 - CANCEL_QTY累积取消数量)*单价*(100-折扣-月返)/100
                                            (NVL(B.ITEM_QTY, 0) -
                                            NVL(B.FACT_SHIP_QTY, 0) -
                                            NVL(B.CANCEL_QTY, 0)) *
                                            NVL(B.ITEM_PRICE, 0) *
                                            (100 - NVL(B.DISCOUNT_RATE, 0) -
                                            NVL(B.MONTH_DISCOUNT_RATE, 0)) / 100
                                           ELSE
                                            0
                                         END,
                                         2),
                                   0) LOCKED_AMOUNT,
                               0 LOCKED_DOWNPAY_AMOUNT, --锁定订金
                               NVL(ROUND(CASE
                                           --20200314 家用直发锁款调整
                                           when b.origin_type = '01' and nvl(a.direct_transport_falg, 'N') = 'Y' and 
                                             (select nvl(h.amount_lock_flag, 'N')
                                                from t_pln_order_head h
                                               where h.order_head_id = b.origin_order_id) = 'NT'
                                             then
                                               0
                                           WHEN B.LOCK_AMOUNT_FLAG IN ('S', 'Y','HQ') THEN
                                            (NVL(B.ITEM_QTY, 0) -
                                            NVL(B.FACT_SHIP_QTY, 0) -
                                            NVL(B.CANCEL_QTY, 0)) *
                                            NVL(B.ITEM_PRICE, 0) *
                                            NVL(B.DISCOUNT_RATE, 0) / 100
                                           ELSE
                                            0
                                         END,
                                         2),
                                   0) LOCKED_DISCOUNT_AMOUNT,
                               0 LOCKED_DIS_DP_AMOUNT --锁定折扣订金
                                FROM T_LG_SHIP_DOC A --发货通知单头
                               INNER JOIN T_LG_SHIP_DOC_LINE B --发货通知单行
                                  ON (A.SHIP_DOC_ID = B.SHIP_DOC_ID)
                                LEFT JOIN UP_CODELIST C
                                  ON (C.CODE_VALUE = B.LOCK_AMOUNT_FLAG AND C.CODETYPE = 'plnlockMoneyFlag')
                               WHERE A.ENTITY_ID = IN_ENTITY_ID
                                 AND A.CUSTOMER_CODE =
                                     NVL(IS_CUSTOMER_CODE, A.CUSTOMER_CODE)
                                 AND A.ACCOUNT_CODE =
                                     NVL(IS_ACCOUNT_CODE, A.ACCOUNT_CODE)
                                 AND A.DOC_STATUS <> '01' --单据状态 00正常 01红冲
                                 AND B.LOCK_AMOUNT_FLAG IN
                                     ('S', 'Y', 'RS', 'RT','HQ')
                                 AND NVL(A.CUSTOMIZE_FLAG, 'N') = 'N'
                              UNION ALL
                              --制定发货需求计划下达（直发客户） 发货计划未确认（未生成发货通知单）
                              SELECT T.TRANSFER_ENTITY_ID ENTITY_ID,
                               T.TRANSFER_CUSTOMER_ID CUSTOMER_ID,
                               T.TRANSFER_CUSTOMER_CODE CUSTOMER_CODE,
                               T.TRANSFER_CUSTOMER_NAME CUSTOMER_NAME,
                               T.TRANSFER_ACCOUNT_ID ACCOUNT_ID,
                               T.TRANSFER_ACCOUNT_CODE ACCOUNT_CODE,
                               T.TRANSFER_ACCOUNT_CODE ACCOUNT_NAME,
                               T.TRANSFER_ITEM_MAIN_TYPE SALES_MAIN_TYPE,
                               NVL(T.TRANSFER_DISCOUNT_TYPE, 'COMMON') AS DISCOUNT_TYPE,
                               0 AS IS_DOWN_PAY,CAST(NULL AS NUMERIC) AS DOWN_PAY_SCALE,-- ADD YB LIANGYM2 2018-5-31 订金比例 暂时不用而是外面关联取订金比例
                               DECODE(T.ORIGIN_ORIGIN_TYPE,'02',T.ORIGIN_ORIGIN_HEAD_ID,T.ORIGIN_ORDER_ID) AS SRC_LG_ORDER_ID,-- ADD YB LIANGYM2 2018-5-31 来源提货订单ID
                               DECODE(T.ORIGIN_ORIGIN_TYPE,'02',T.ORIGIN_ORIGIN_ORDER_CODE,T.ORIGIN_ORDER_NUM) AS ORIGIN_ORDER_NUM,T.ORIGIN_ORDER_NUM AS ORDER_NUM,
                               '发货锁定到款（直发）' LOCK_METHOD,
                               NVL(ROUND(
                                         --锁定代理商到款(未确认数量*直发列表价*(100-直发扣率-直发月返)/100)
                                         NVL(T.UNAFFIRM_QTY, 0) *
                                         NVL(T.TRANSFER_LIST_PRICE, 0) *
                                         (100 -
                                          NVL(T.TRANSFER_DISCOUNT_RATE, 0) -
                                          NVL(T.TRANSFER_MONTH_DISCOUNT_RATE,
                                              0)) / 100,
                                         2),
                                   0) LOCKED_AMOUNT,
                               0 LOCKED_DOWNPAY_AMOUNT, --锁定订金
                               NVL(ROUND(NVL(T.UNAFFIRM_QTY, 0) *
                                         NVL(T.TRANSFER_LIST_PRICE, 0) *
                                         NVL(T.TRANSFER_DISCOUNT_RATE, 0) / 100,
                                         2),
                                   0) LOCKED_DISCOUNT_AMOUNT, --锁定代理商折让(未确认数量*直发列表价*直发扣率/100),
                               0 LOCKED_DIS_DP_AMOUNT --锁定折扣订金
                                FROM T_LG_SHIP_PLAN T
                               WHERE T.TRANSFER_ENTITY_ID = IN_ENTITY_ID
                                 AND T.TRANSFER_ACCOUNT_CODE =
                                     NVL(IS_ACCOUNT_CODE, T.TRANSFER_ACCOUNT_CODE)
                                 AND T.TRANSFER_CUSTOMER_CODE =
                                     NVL(IS_CUSTOMER_CODE,
                                         T.TRANSFER_CUSTOMER_CODE)
                                 AND T.STATUS IN ('00', '01') --撤销单据没有锁款
                                 AND T.TRANSFER_LOCK_AMOUNT_FLAG = 'Y'
                                 AND T.TRANSFER_ITEM_MAIN_TYPE IS NOT NULL
                              UNION ALL
                              --制定发货需求计划下达（直发客户） 发货通知单未生成销售单
                              SELECT A.TRANSFER_ENTITY_ID ENTITY_ID,
                               A.TRANSFER_CUSTOMER_ID CUSTOMER_ID,
                               A.TRANSFER_CUSTOMER_CODE CUSTOMER_CODE,
                               A.TRANSFER_CUSTOMER_NAME AS CUSTOMER_NAME,
                               A.TRANSFER_ACCOUNT_ID ACCOUNT_ID,
                               A.TRANSFER_ACCOUNT_CODE ACCOUNT_CODE,
                               A.TRANSFER_ACCOUNT_CODE ACCOUNT_NAME,
                               B.TRANSFER_ITEM_MAIN_TYPE SALES_MAIN_TYPE,
                               NVL(B.TRANSFER_DISCOUNT_TYPE, 'COMMON') AS DISCOUNT_TYPE,
                               0 AS IS_DOWN_PAY,CAST(NULL AS NUMERIC) AS DOWN_PAY_SCALE,-- ADD YB LIANGYM2 2018-5-31 订金比例 暂时不用而是外面关联取订金比例
                               DECODE(B.ORIGIN_ORIGIN_TYPE,'02',B.ORIGIN_ORIGIN_HEAD_ID,B.ORIGIN_ORDER_ID) AS SRC_LG_ORDER_ID,-- ADD YB LIANGYM2 2018-5-31 来源提货订单ID
                               DECODE(B.ORIGIN_ORIGIN_TYPE,'02',B.ORIGIN_ORIGIN_DOC_CODE,B.ORIGIN_ORDER_NUM) AS ORIGIN_ORDER_NUM,B.ORIGIN_ORDER_NUM AS ORDER_NUM,
                               '发货锁定到款（直发）' LOCK_METHOD,
                               NVL(ROUND( --锁定代理商到款((产品数量-已取消数量-已转采购数量)*直发列表价*(100-直发扣率-直发月返)/100)
                                         (NVL(B.ITEM_QTY, 0) -
                                         NVL(B.CANCEL_QTY, 0) -
                                         NVL(B.TRANSFER_TO_POX_QTY, 0)) *
                                         NVL(B.TRANSFER_LIST_PRICE, 0) *
                                         (100 -
                                         NVL(B.TRANSFER_DISCOUNT_RATE, 0) -
                                         NVL(B.TRANSFER_MONTH_DISCOUNT_RATE,
                                              0)) / 100,
                                         2),
                                   0) LOCKED_AMOUNT,
                               0 LOCKED_DOWNPAY_AMOUNT, --锁定订金
                               NVL(ROUND((NVL(B.ITEM_QTY, 0) -
                                         NVL(B.FACT_SHIP_QTY, 0) -
                                         NVL(B.CANCEL_QTY, 0) -
                                         NVL(B.TRANSFER_TO_POX_QTY, 0)) *
                                         NVL(B.TRANSFER_LIST_PRICE, 0) *
                                         NVL(B.TRANSFER_DISCOUNT_RATE, 0) / 100,
                                         2),
                                   0) LOCKED_DISCOUNT_AMOUNT, --锁定代理商折让((产品数量-已取消数量-已转采购数量)*直发列表价*直发扣率/100)
                               0 LOCKED_DIS_DP_AMOUNT --锁定折扣订金
                                FROM T_LG_SHIP_DOC A --发货通知单头
                               INNER JOIN T_LG_SHIP_DOC_LINE B
                                  ON (A.SHIP_DOC_ID = B.SHIP_DOC_ID) --发货通知单行
                               WHERE A.TRANSFER_ENTITY_ID = IN_ENTITY_ID
                                 AND A.TRANSFER_ACCOUNT_CODE =
                                     NVL(IS_ACCOUNT_CODE, A.TRANSFER_ACCOUNT_CODE)
                                 AND A.TRANSFER_CUSTOMER_CODE =
                                     NVL(IS_CUSTOMER_CODE,
                                         A.TRANSFER_CUSTOMER_CODE)
                                 AND A.DOC_STATUS <> '01' --单据状态 00正常 01红冲
                                 AND B.TRANSFER_LOCK_AMOUNT_FLAG = 'Y'
                                 AND B.TRANSFER_ITEM_MAIN_TYPE IS NOT NULL
                              UNION ALL
                              --送审锁款：已经送审未下达发运计划的锁款 提货订单 常规部分
                              SELECT A.ENTITY_ID ENTITY_ID,
                               A.CUSTOMER_ID CUSTOMER_ID,
                               A.CUSTOMER_CODE CUSTOMER_CODE,
                               A.CUSTOMER_NAME CUSTOMER_NAME,
                               0 ACCOUNT_ID,
                               A.ACCOUNT_CODE ACCOUNT_CODE,
                               A.ACCOUNT_NAME ACCOUNT_NAME,
                               B.SALES_MAIN_TYPE SALES_MAIN_TYPE,
                               --'COMMON' AS DISCOUNT_TYPE,--常规部分
                               NVL(B.DISCOUNT_TYPE,'COMMON') AS DISCOUNT_TYPE,
                               0 AS IS_DOWN_PAY,CAST(NULL AS NUMERIC) AS DOWN_PAY_SCALE,-- ADD YB LIANGYM2 2018-5-31 订金比例 暂时不用而是外面关联取订金比例
                               A.ORDER_HEAD_ID AS SRC_LG_ORDER_ID,-- ADD YB LIANGYM2 2018-5-31 来源提货订单ID
                               A.ORDER_NUMBER ORIGIN_ORDER_NUM,NULL AS ORDER_NUM,
                               /*DECODE(A.LOCK_AMOUNT_FLAG,
                                      'S',
                                      '送审锁款',
                                      'RS',
                                      '资源送审锁款')*/C.CODE_NAME LOCK_METHOD,
                               NVL(ROUND(CASE
                                           WHEN nvl(b.order_line_state,LG_LINE_STATE_NORMAL)=LG_LINE_STATE_CLOSED
                                             and nvl(b.is_lock_amount,'N')<>'NT' THEN
                                             0
                                           --20200314 家用直发锁款调整
                                           WHEN (A.LOCK_AMOUNT_FLAG = 'S'
                                               --2016-09-23 TIANMZH修改，订金比例为空或小于0时，计算锁定到款，否则，锁定到款为0.
                                                AND (A.DOWN_PAY_SCALE IS NULL OR A.DOWN_PAY_SCALE < 0)) 
                                               OR NVL(B.IS_LOCK_AMOUNT, 'N') = 'Y' THEN
                                            (CASE
                                              when nvl(b.is_lock_amount,'N')='NT' THEN
                                                NVL(B.CENTER_AFFIRM_QUANTITY, 0) - NVL(B.CANCEL_QTY, 0)
                                            --2016-09-13 TIANMZH修改，增加'2225'，显示产能可视状态('2225'提货订单金额。
                                              WHEN A.ORDER_HEAD_STATE IN ('20', '1455', '2225') and nvl(b.order_line_state,LG_LINE_STATE_NORMAL)<>LG_LINE_STATE_CLOSED THEN
                                               NVL(DECODE(A.HQ_LG_ORDER_HEAD_ID,NULL,B.QUANTITY,0,B.QUANTITY,B.CENTER_AFFIRM_QUANTITY), 0) -
                                               NVL(B.AFFIRMED_QUANTITY, 0) - NVL(B.CANCEL_QTY, 0)
                                               -(NVL(B.transfer_hq_affirmed_qty,0)-NVL(B.SENDED_QTY,0))
                                               -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                              WHEN A.ORDER_HEAD_STATE IN ('381', '679') and nvl(b.order_line_state,LG_LINE_STATE_NORMAL)<>LG_LINE_STATE_CLOSED THEN
                                               NVL(B.CENTER_AFFIRM_QUANTITY, 0) - NVL(B.AFFIRMED_QUANTITY, 0) - NVL(B.CANCEL_QTY, 0)
                                               -(NVL(B.transfer_hq_affirmed_qty,0)-NVL(B.SENDED_QTY,0))
                                               -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                              ELSE
                                               0
                                            END)
                                           ELSE
                                            0
                                         END
                                         * DECODE(B.PROJECT_ORDER_TYPE,
                                                   NULL,
                                                   NVL(B.LIST_PRICE, 0),
                                                   NVL(B.APPLY_LIST_PRICE, 0))
                                           --ADD BY LIZHEN 2015-11-30 增加月返计算
                                            * (100 -
                                            DECODE(B.PROJECT_ORDER_TYPE,
                                                      NULL,
                                                      NVL(B.DISCOUNT_RATE, 0),
                                                      NVL(B.APPLY_DISCOUNT_RATE, 0)) -
                                            NVL(B.ORDERED_DISCOUNT_RATE, 0)) / 100,
                                         2),
                                   0) LOCKED_AMOUNT,
                               
                               --ADD TIANMZH 2016-09-13 ，增加锁定订金（锁款方式 = "送审锁款"，订金比例 > 0，锁定订金=锁定到款*订金比例）
                               NVL(ROUND(CASE
                                           --20200314 家用直发锁款调整
                                           WHEN (nvl(b.order_line_state,LG_LINE_STATE_NORMAL)=LG_LINE_STATE_CLOSED and nvl(b.is_lock_amount,'N')<>'NT')
                                             OR NVL(B.IS_LOCK_AMOUNT, 'N') = 'Y' THEN
                                             0
                                           WHEN A.LOCK_AMOUNT_FLAG = 'S' AND NVL(A.DOWN_PAY_SCALE, 0) > 0 THEN
                                            (CASE
                                              WHEN NVL(B.IS_LOCK_AMOUNT, 'N') = 'NT' THEN
                                                NVL(B.CENTER_AFFIRM_QUANTITY, 0) - NVL(B.CANCEL_QTY, 0)
                                            --2016-09-13 TIANMZH修改，增加'2225'，显示产能可视状态('2225'提货订单金额。
                                              WHEN A.ORDER_HEAD_STATE IN ('20', '1455', '2225') and nvl(b.order_line_state,LG_LINE_STATE_NORMAL)<>LG_LINE_STATE_CLOSED THEN
                                               NVL(DECODE(A.HQ_LG_ORDER_HEAD_ID,NULL,B.QUANTITY,0,B.QUANTITY,B.CENTER_AFFIRM_QUANTITY), 0) -
                                               NVL(B.AFFIRMED_QUANTITY, 0) -
                                               NVL(B.CANCEL_QTY, 0) - (NVL(B.transfer_hq_affirmed_qty,0)-NVL(B.SENDED_QTY,0)) --20180105 hejy3 增加订金发货锁全款处理
                                               -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                              WHEN A.ORDER_HEAD_STATE IN ('381', '679') and nvl(b.order_line_state,LG_LINE_STATE_NORMAL)<>LG_LINE_STATE_CLOSED THEN
                                               NVL(B.CENTER_AFFIRM_QUANTITY, 0) - NVL(B.AFFIRMED_QUANTITY, 0) - NVL(B.CANCEL_QTY, 0)
                                               - (NVL(B.transfer_hq_affirmed_qty,0)-NVL(B.SENDED_QTY,0))
                                               -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                              ELSE
                                               0
                                            END) *
                                            DECODE(B.PROJECT_ORDER_TYPE,
                                                   NULL,
                                                   NVL(B.LIST_PRICE, 0),
                                                   NVL(B.APPLY_LIST_PRICE, 0))
                                           --ADD BY LIZHEN 2015-11-30 增加月返计算
                                            * (100 -
                                            DECODE(B.PROJECT_ORDER_TYPE,
                                                      NULL,
                                                      NVL(B.DISCOUNT_RATE, 0),
                                                      NVL(B.APPLY_DISCOUNT_RATE, 0)) -
                                            NVL(B.ORDERED_DISCOUNT_RATE, 0)) / 100 *
                                            A.DOWN_PAY_SCALE / 100
                                           ELSE
                                            0
                                         END,
                                         2),
                                   0) LOCKED_DOWNPAY_AMOUNT, --锁定订金
                               NVL(ROUND(CASE
                                           WHEN nvl(b.order_line_state,LG_LINE_STATE_NORMAL)=LG_LINE_STATE_CLOSED
                                             and nvl(b.is_lock_amount,'N')<>'NT' THEN
                                             0
                                           WHEN B.DISCOUNT_TYPE <> 'COMMON' THEN
                                             0
                                           --20200314 家用直发锁款调整
                                           WHEN (A.LOCK_AMOUNT_FLAG = 'S' AND (A.DOWN_PAY_SCALE IS NULL OR A.DOWN_PAY_SCALE < 0)) 
                                             OR NVL(B.IS_LOCK_AMOUNT, 'N') = 'Y' THEN
                                           --ADD BY LIZHEN 2015-11-30 T+3订单回写取消数量，并会释放款项，所以取消数量重算时不计入锁款
                                            (CASE
                                              when nvl(b.is_lock_amount,'N')='NT' THEN
                                                NVL(B.CENTER_AFFIRM_QUANTITY, 0) - NVL(B.CANCEL_QTY, 0)
                                            --2016-09-13 TIANMZH修改，增加'2225'，显示产能可视状态('2225'提货订单金额。
                                              WHEN A.ORDER_HEAD_STATE IN ('20', '1455', '2225') and nvl(b.order_line_state,LG_LINE_STATE_NORMAL)<>LG_LINE_STATE_CLOSED THEN
                                               NVL(DECODE(A.HQ_LG_ORDER_HEAD_ID,NULL,B.QUANTITY,0,B.QUANTITY,B.CENTER_AFFIRM_QUANTITY), 0) -
                                               NVL(B.AFFIRMED_QUANTITY, 0) - NVL(B.CANCEL_QTY, 0)
                                               -(NVL(B.transfer_hq_affirmed_qty,0)-NVL(B.SENDED_QTY,0))
                                               -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                              WHEN A.ORDER_HEAD_STATE IN ('381', '679') and nvl(b.order_line_state,LG_LINE_STATE_NORMAL)<>LG_LINE_STATE_CLOSED THEN
                                               NVL(B.CENTER_AFFIRM_QUANTITY, 0) - NVL(B.AFFIRMED_QUANTITY, 0) - NVL(B.CANCEL_QTY, 0)
                                               -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                              ELSE
                                               0
                                            END)
                                           ELSE
                                            0
                                         END
                                         * DECODE(B.PROJECT_ORDER_TYPE,
                                                   NULL,
                                                   NVL(B.LIST_PRICE, 0),
                                                   NVL(B.APPLY_LIST_PRICE, 0)) *
                                            DECODE(B.PROJECT_ORDER_TYPE,
                                                   NULL,
                                                   NVL(B.DISCOUNT_RATE, 0),
                                                   NVL(B.APPLY_DISCOUNT_RATE, 0)) / 100,
                                         2),
                                   0) LOCKED_DISCOUNT_AMOUNT,
                               NVL(ROUND(CASE
                                           --20200314 家用直发锁款调整
                                           WHEN (nvl(b.order_line_state,LG_LINE_STATE_NORMAL)=LG_LINE_STATE_CLOSED and nvl(b.is_lock_amount,'N')<>'NT')
                                             OR NVL(B.IS_LOCK_AMOUNT, 'N') = 'Y' THEN
                                             0
                                           WHEN B.DISCOUNT_TYPE <> 'COMMON' THEN
                                             0
                                           WHEN A.LOCK_AMOUNT_FLAG = 'S' AND NVL(A.DOWN_PAY_SCALE, 0) > 0 THEN
                                           --ADD BY LIZHEN 2015-11-30 T+3订单回写取消数量，并会释放款项，所以取消数量重算时不计入锁款
                                            (CASE
                                              WHEN NVL(B.IS_LOCK_AMOUNT, 'N') = 'NT' THEN
                                                NVL(B.CENTER_AFFIRM_QUANTITY, 0) - NVL(B.CANCEL_QTY, 0)
                                            --2016-09-13 TIANMZH修改，增加'2225'，显示产能可视状态('2225'提货订单金额。
                                              WHEN A.ORDER_HEAD_STATE IN ('20', '1455', '2225') and nvl(b.order_line_state,LG_LINE_STATE_NORMAL)<>LG_LINE_STATE_CLOSED THEN
                                               NVL( DECODE(A.HQ_LG_ORDER_HEAD_ID,NULL,B.QUANTITY,0,B.QUANTITY,B.CENTER_AFFIRM_QUANTITY), 0) -
                                               NVL(B.AFFIRMED_QUANTITY, 0) -
                                               NVL(B.CANCEL_QTY, 0) - (NVL(B.transfer_hq_affirmed_qty,0)-NVL(B.SENDED_QTY,0)) --20180105 hejy3 增加订金发货锁全款处理
                                               -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                              WHEN A.ORDER_HEAD_STATE IN ('381', '679') and nvl(b.order_line_state,LG_LINE_STATE_NORMAL)<>LG_LINE_STATE_CLOSED THEN
                                               NVL(B.CENTER_AFFIRM_QUANTITY, 0) - NVL(B.AFFIRMED_QUANTITY, 0) - NVL(B.CANCEL_QTY, 0)
                                               - (NVL(B.transfer_hq_affirmed_qty,0)-NVL(B.SENDED_QTY,0))
                                               -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                              ELSE
                                               0
                                            END) *
                                            DECODE(B.PROJECT_ORDER_TYPE,
                                                   NULL,
                                                   NVL(B.LIST_PRICE, 0),
                                                   NVL(B.APPLY_LIST_PRICE, 0)) *
                                            DECODE(B.PROJECT_ORDER_TYPE,
                                                   NULL,
                                                   NVL(B.DISCOUNT_RATE, 0),
                                                   NVL(B.APPLY_DISCOUNT_RATE, 0)) / 100 *
                                            A.DOWN_PAY_SCALE / 100
                                           ELSE
                                            0
                                         END,
                                         2),
                                   0) LOCKED_DIS_DP_AMOUNT --锁定折扣订金
                                FROM T_PLN_LG_ORDER_HEAD A --物流订单头表
                               INNER JOIN T_PLN_LG_ORDER_LINE B --物流订单行表
                                  ON (A.ORDER_HEAD_ID = B.ORDER_HEAD_ID)
                                LEFT JOIN UP_CODELIST C
                                  ON (C.CODE_VALUE = A.LOCK_AMOUNT_FLAG AND C.CODETYPE = 'plnlockMoneyFlag')
                               WHERE A.ENTITY_ID = IN_ENTITY_ID
                                 AND A.ACCOUNT_CODE =
                                     NVL(IS_ACCOUNT_CODE, A.ACCOUNT_CODE)
                                 AND A.CUSTOMER_CODE =
                                     NVL(IS_CUSTOMER_CODE, A.CUSTOMER_CODE)
                                 AND A.ORDER_HEAD_STATE IN
                                    --2016-09-13 TIANMZH修改，增加'2225'，显示产能可视状态('2225'提货订单金额。
                                     ('20', '23', '381', '679', '1455', '2225', '304')
                                 AND A.LOCK_AMOUNT_FLAG IN ('S', 'RS')
                                 AND NVL(A.CUSTOMIZE_FLAG, 'N') = 'N'
                              UNION ALL
                              --送总部评审锁款
                              SELECT A.ENTITY_ID ENTITY_ID,
                               A.CUSTOMER_ID CUSTOMER_ID,
                               A.CUSTOMER_CODE CUSTOMER_CODE,
                               A.CUSTOMER_NAME CUSTOMER_NAME,
                               0 ACCOUNT_ID,
                               A.ACCOUNT_CODE ACCOUNT_CODE,
                               A.ACCOUNT_NAME ACCOUNT_NAME,
                               B.SALES_MAIN_TYPE SALES_MAIN_TYPE,
                               --'COMMON' AS DISCOUNT_TYPE,--常规部分
                               NVL(B.DISCOUNT_TYPE,'COMMON') AS DISCOUNT_TYPE,
                               0 AS IS_DOWN_PAY,CAST(NULL AS NUMERIC) AS DOWN_PAY_SCALE,-- ADD YB LIANGYM2 2018-5-31 订金比例 暂时不用而是外面关联取订金比例
                               A.ORDER_HEAD_ID AS SRC_LG_ORDER_ID,-- ADD YB LIANGYM2 2018-5-31 来源提货订单ID
                               A.ORDER_NUMBER ORIGIN_ORDER_NUM,NULL AS ORDER_NUM,
                               /*DECODE(A.LOCK_AMOUNT_FLAG,
                                      'S',
                                      '送审锁款',
                                      'RS',
                                      '资源送审锁款')*/C.CODE_NAME LOCK_METHOD,
                               NVL(ROUND(CASE
                                           WHEN nvl(b.order_line_state,LG_LINE_STATE_NORMAL)=LG_LINE_STATE_CLOSED
                                             and nvl(b.is_lock_amount,'N')<>'NT' THEN
                                             0
                                           --20200314 家用直发锁款调整
                                           WHEN (A.DOWN_PAY_SCALE IS NULL OR A.DOWN_PAY_SCALE < 0) 
                                             OR NVL(B.IS_LOCK_AMOUNT, 'N') = 'Y' THEN
                                            (CASE
                                              when nvl(b.is_lock_amount,'N')='NT' THEN
                                                NVL(B.CENTER_AFFIRM_QUANTITY, 0) - NVL(B.CANCEL_QTY, 0)
                                            --2016-09-13 TIANMZH修改，增加'2225'，显示产能可视状态('2225'提货订单金额。
                                              WHEN (A.ORDER_HEAD_STATE IN ('20', '1455', '2225') and ha.SUBMIT_TO_HQ_FLAG = 'Y')
                                                or a.SUBMIT_TO_HQ_FLAG = 'Y' THEN
                                               NVL(DECODE(A.HQ_LG_ORDER_HEAD_ID,NULL,B.QUANTITY,0,B.QUANTITY,B.CENTER_AFFIRM_QUANTITY), 0) -
                                               NVL(B.AFFIRMED_QUANTITY, 0) - NVL(B.CANCEL_QTY, 0)
                                               -(NVL(B.transfer_hq_affirmed_qty,0)-NVL(B.SENDED_QTY,0))
                                               -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                              ELSE
                                               0
                                            END)
                                           ELSE
                                            0
                                         END
                                         * DECODE(B.PROJECT_ORDER_TYPE,
                                                   NULL,
                                                   NVL(B.LIST_PRICE, 0),
                                                   NVL(B.APPLY_LIST_PRICE, 0))
                                           --ADD BY LIZHEN 2015-11-30 增加月返计算
                                            * (100 -
                                            DECODE(B.PROJECT_ORDER_TYPE,
                                                      NULL,
                                                      NVL(B.DISCOUNT_RATE, 0),
                                                      NVL(B.APPLY_DISCOUNT_RATE, 0)) -
                                            NVL(B.ORDERED_DISCOUNT_RATE, 0)) / 100,
                                         2),
                                   0) LOCKED_AMOUNT,
                               
                               --ADD TIANMZH 2016-09-13 ，增加锁定订金（锁款方式 = "送审锁款"，订金比例 > 0，锁定订金=锁定到款*订金比例）
                               NVL(ROUND(CASE
                                           --20200314 家用直发锁款调整
                                           WHEN (nvl(b.order_line_state,LG_LINE_STATE_NORMAL)=LG_LINE_STATE_CLOSED and nvl(b.is_lock_amount,'N')<>'NT')
                                             OR NVL(B.IS_LOCK_AMOUNT, 'N') = 'Y' THEN
                                             0
                                           WHEN NVL(A.DOWN_PAY_SCALE, 0) > 0 THEN
                                            (CASE
                                              WHEN NVL(B.IS_LOCK_AMOUNT, 'N') = 'NT' THEN
                                                NVL(B.CENTER_AFFIRM_QUANTITY, 0) - NVL(B.CANCEL_QTY, 0)
                                            --2016-09-13 TIANMZH修改，增加'2225'，显示产能可视状态('2225'提货订单金额。
                                              WHEN (A.ORDER_HEAD_STATE IN ('20', '1455', '2225') and ha.SUBMIT_TO_HQ_FLAG = 'Y')
                                                or a.SUBMIT_TO_HQ_FLAG = 'Y' THEN
                                               NVL(DECODE(A.HQ_LG_ORDER_HEAD_ID,NULL,B.QUANTITY,0,B.QUANTITY,B.CENTER_AFFIRM_QUANTITY), 0) -
                                               NVL(B.AFFIRMED_QUANTITY, 0) - NVL(B.CANCEL_QTY, 0)
                                               -(NVL(B.transfer_hq_affirmed_qty,0)-NVL(B.SENDED_QTY,0))
                                               -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                              ELSE
                                               0
                                            END) *
                                            DECODE(B.PROJECT_ORDER_TYPE,
                                                   NULL,
                                                   NVL(B.LIST_PRICE, 0),
                                                   NVL(B.APPLY_LIST_PRICE, 0))
                                           --ADD BY LIZHEN 2015-11-30 增加月返计算
                                            * (100 -
                                            DECODE(B.PROJECT_ORDER_TYPE,
                                                      NULL,
                                                      NVL(B.DISCOUNT_RATE, 0),
                                                      NVL(B.APPLY_DISCOUNT_RATE, 0)) -
                                            NVL(B.ORDERED_DISCOUNT_RATE, 0)) / 100 *
                                            A.DOWN_PAY_SCALE / 100
                                           ELSE
                                            0
                                         END,
                                         2),
                                   0) LOCKED_DOWNPAY_AMOUNT, --锁定订金
                               NVL(ROUND(CASE
                                           WHEN nvl(b.order_line_state,LG_LINE_STATE_NORMAL)=LG_LINE_STATE_CLOSED
                                             and nvl(b.is_lock_amount,'N')<>'NT' THEN
                                             0
                                           WHEN B.DISCOUNT_TYPE <> 'COMMON' THEN
                                             0
                                           --20200314 家用直发锁款调整
                                           WHEN (A.DOWN_PAY_SCALE IS NULL OR A.DOWN_PAY_SCALE < 0) 
                                             OR NVL(B.IS_LOCK_AMOUNT, 'N') = 'Y' THEN
                                           --ADD BY LIZHEN 2015-11-30 T+3订单回写取消数量，并会释放款项，所以取消数量重算时不计入锁款
                                            (CASE
                                              when nvl(b.is_lock_amount,'N')='NT' THEN
                                                NVL(B.CENTER_AFFIRM_QUANTITY, 0) - NVL(B.CANCEL_QTY, 0)
                                            --2016-09-13 TIANMZH修改，增加'2225'，显示产能可视状态('2225'提货订单金额。
                                              WHEN (A.ORDER_HEAD_STATE IN ('20', '1455', '2225') and ha.SUBMIT_TO_HQ_FLAG = 'Y')
                                                or a.SUBMIT_TO_HQ_FLAG = 'Y' THEN
                                               NVL(DECODE(A.HQ_LG_ORDER_HEAD_ID,NULL,B.QUANTITY,0,B.QUANTITY,B.CENTER_AFFIRM_QUANTITY), 0) -
                                               NVL(B.AFFIRMED_QUANTITY, 0) - NVL(B.CANCEL_QTY, 0)
                                               -(NVL(B.transfer_hq_affirmed_qty,0)-NVL(B.SENDED_QTY,0))
                                               -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                              ELSE
                                               0
                                            END)
                                           ELSE
                                            0
                                         END
                                         * DECODE(B.PROJECT_ORDER_TYPE,
                                                   NULL,
                                                   NVL(B.LIST_PRICE, 0),
                                                   NVL(B.APPLY_LIST_PRICE, 0)) *
                                            DECODE(B.PROJECT_ORDER_TYPE,
                                                   NULL,
                                                   NVL(B.DISCOUNT_RATE, 0),
                                                   NVL(B.APPLY_DISCOUNT_RATE, 0)) / 100,
                                         2),
                                   0) LOCKED_DISCOUNT_AMOUNT,
                               NVL(ROUND(CASE
                                           --20200314 家用直发锁款调整
                                           WHEN (nvl(b.order_line_state,LG_LINE_STATE_NORMAL)=LG_LINE_STATE_CLOSED and nvl(b.is_lock_amount,'N')<>'NT')
                                             OR NVL(B.IS_LOCK_AMOUNT, 'N') = 'Y' THEN
                                             0
                                           WHEN B.DISCOUNT_TYPE <> 'COMMON' THEN
                                             0
                                           WHEN NVL(A.DOWN_PAY_SCALE, 0) > 0 THEN
                                           --ADD BY LIZHEN 2015-11-30 T+3订单回写取消数量，并会释放款项，所以取消数量重算时不计入锁款
                                            (CASE
                                              WHEN NVL(B.IS_LOCK_AMOUNT, 'N') = 'NT' THEN
                                                NVL(B.CENTER_AFFIRM_QUANTITY, 0) - NVL(B.CANCEL_QTY, 0)
                                            --2016-09-13 TIANMZH修改，增加'2225'，显示产能可视状态('2225'提货订单金额。
                                              WHEN (A.ORDER_HEAD_STATE IN ('20', '1455', '2225') and ha.SUBMIT_TO_HQ_FLAG = 'Y')
                                                or a.SUBMIT_TO_HQ_FLAG = 'Y' THEN
                                               NVL(DECODE(A.HQ_LG_ORDER_HEAD_ID,NULL,B.QUANTITY,0,B.QUANTITY,B.CENTER_AFFIRM_QUANTITY), 0) -
                                               NVL(B.AFFIRMED_QUANTITY, 0) - NVL(B.CANCEL_QTY, 0)
                                               -(NVL(B.transfer_hq_affirmed_qty,0)-NVL(B.SENDED_QTY,0))
                                               -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                              ELSE
                                               0
                                            END) *
                                            DECODE(B.PROJECT_ORDER_TYPE,
                                                   NULL,
                                                   NVL(B.LIST_PRICE, 0),
                                                   NVL(B.APPLY_LIST_PRICE, 0)) *
                                            DECODE(B.PROJECT_ORDER_TYPE,
                                                   NULL,
                                                   NVL(B.DISCOUNT_RATE, 0),
                                                   NVL(B.APPLY_DISCOUNT_RATE, 0)) / 100 *
                                            A.DOWN_PAY_SCALE / 100
                                           ELSE
                                            0
                                         END,
                                         2),
                                   0) LOCKED_DIS_DP_AMOUNT --锁定折扣订金
                                FROM T_PLN_LG_ORDER_HEAD A --物流订单头表
                               INNER JOIN T_PLN_LG_ORDER_LINE B --物流订单行表
                                  ON (A.ORDER_HEAD_ID = B.ORDER_HEAD_ID)
                                LEFT JOIN UP_CODELIST C
                                  ON (C.CODE_VALUE = A.LOCK_AMOUNT_FLAG AND C.CODETYPE = 'plnlockMoneyFlag')
                                LEFT JOIN T_PLN_LG_ORDER_HEAD HA
                                  ON (HA.ORDER_HEAD_ID = A.HQ_LG_ORDER_HEAD_ID)
                               WHERE A.ENTITY_ID = IN_ENTITY_ID
                                 AND A.ACCOUNT_CODE =
                                     NVL(IS_ACCOUNT_CODE, A.ACCOUNT_CODE)
                                 AND A.CUSTOMER_CODE =
                                     NVL(IS_CUSTOMER_CODE, A.CUSTOMER_CODE)
                                 AND A.ORDER_HEAD_STATE IN
                                    --2016-09-13 TIANMZH修改，增加'2225'，显示产能可视状态('2225'提货订单金额。
                                     ('20', '23', '381', '679', '1455', '2225', '304')
                                 AND A.LOCK_AMOUNT_FLAG IN ('HQ')
                                 AND NVL(A.CUSTOMIZE_FLAG, 'N') = 'N'
                              UNION ALL
                              --针对已结转总部主体且发货锁款的提货订单 常规部分
                              SELECT A.ENTITY_ID ENTITY_ID,
                               A.CUSTOMER_ID CUSTOMER_ID,
                               A.CUSTOMER_CODE CUSTOMER_CODE,
                               A.CUSTOMER_NAME CUSTOMER_NAME,
                               A.ACCOUNT_ID ACCOUNT_ID,
                               A.ACCOUNT_CODE ACCOUNT_CODE,
                               A.ACCOUNT_NAME ACCOUNT_NAME,
                               B.SALES_MAIN_TYPE SALES_MAIN_TYPE,
                               --'COMMON' AS DISCOUNT_TYPE,--常规部分
                               NVL(B.DISCOUNT_TYPE,'COMMON') AS DISCOUNT_TYPE,
                               0 AS IS_DOWN_PAY,CAST(NULL AS NUMERIC) AS DOWN_PAY_SCALE,-- ADD YB LIANGYM2 2018-5-31 订金比例 暂时不用而是外面关联取订金比例
                               A.ORDER_HEAD_ID AS SRC_LG_ORDER_ID,-- ADD YB LIANGYM2 2018-5-31 来源提货订单ID
                               A.ORDER_NUMBER ORIGIN_ORDER_NUM,NULL AS ORDER_NUM,
                               /*DECODE(A.LOCK_AMOUNT_FLAG,
                                      'Y',
                                      '发货锁款')*/C.CODE_NAME LOCK_METHOD,
                               NVL(ROUND(CASE WHEN NVL(B.IS_LOCK_AMOUNT, 'N') <> 'NT' THEN
                                            (NVL(B.transfer_hq_affirmed_qty,0)-NVL(B.SENDED_QTY,0)) *
                                            DECODE(B.PROJECT_ORDER_TYPE,
                                                   NULL,
                                                   NVL(B.LIST_PRICE, 0),
                                                   NVL(B.APPLY_LIST_PRICE, 0))
                                           --ADD BY LIZHEN 2015-11-30 增加月返计算
                                            * (100 -
                                            DECODE(B.PROJECT_ORDER_TYPE,
                                                      NULL,
                                                      NVL(B.DISCOUNT_RATE, 0),
                                                      NVL(B.APPLY_DISCOUNT_RATE, 0)) -
                                            NVL(B.ORDERED_DISCOUNT_RATE, 0)) / 100
                                           ELSE 0 END
                                         ,2),
                                   0) LOCKED_AMOUNT,
                               0 LOCKED_DOWNPAY_AMOUNT, --锁定订金
                               NVL(ROUND(CASE
                                           WHEN B.DISCOUNT_TYPE <> 'COMMON' THEN
                                             0
                                           WHEN NVL(B.IS_LOCK_AMOUNT, 'N') <> 'NT' THEN
                                           (NVL(B.transfer_hq_affirmed_qty,0)-NVL(B.SENDED_QTY,0)) *
                                            DECODE(B.PROJECT_ORDER_TYPE,
                                                   NULL,
                                                   NVL(B.LIST_PRICE, 0),
                                                   NVL(B.APPLY_LIST_PRICE, 0)) *
                                            DECODE(B.PROJECT_ORDER_TYPE,
                                                   NULL,
                                                   NVL(B.DISCOUNT_RATE, 0),
                                                   NVL(B.APPLY_DISCOUNT_RATE, 0)) / 100
                                           ELSE 0
                                         END,
                                         2),
                                   0) LOCKED_DISCOUNT_AMOUNT,
                               0 LOCKED_DIS_DP_AMOUNT --锁定折扣订金
                                FROM T_PLN_LG_ORDER_HEAD A --物流订单头表
                               INNER JOIN T_PLN_LG_ORDER_LINE B --物流订单行表
                                  ON (A.ORDER_HEAD_ID = B.ORDER_HEAD_ID)
                                LEFT JOIN UP_CODELIST C
                                  ON (C.CODE_VALUE = A.LOCK_AMOUNT_FLAG AND C.CODETYPE = 'plnlockMoneyFlag')
                               WHERE A.ENTITY_ID = IN_ENTITY_ID
                                 AND A.ACCOUNT_CODE =
                                     NVL(IS_ACCOUNT_CODE, A.ACCOUNT_CODE)
                                 AND A.CUSTOMER_CODE =
                                     NVL(IS_CUSTOMER_CODE, A.CUSTOMER_CODE)
                                 --AND NVL(B.ORDER_LINE_STATE, 'NORMAL') <> 'CLOSED'
                                 AND A.ORDER_HEAD_STATE IN
                                     ('20', '23', '381', '679', '1455', '2225', '304')
                                 AND B.TRANSFER_HQ_AFFIRMED_QTY > 0
                                 AND NVL(A.CUSTOMIZE_FLAG, 'N') = 'N'
                                 --AND A.HQ_LG_ORDER_HEAD_ID IS NOT NULL
                                 --AND A.LOCK_AMOUNT_FLAG = 'Y'
                              UNION ALL
                              --1.2、计划订单
                              SELECT POH.ENTITY_ID ENTITY_ID,
                               POH.CUSTOMER_ID CUSTOMER_ID,
                               POH.CUSTOMER_CODE CUSTOMER_CODE,
                               POH.CUSTOMER_NAME CUSTOMER_NAME,
                               POH.ACCOUNT_ID ACCOUNT_ID,
                               POH.ACCOUNT_CODE ACCOUNT_CODE,
                               POH.ACCOUNT_NAME ACCOUNT_NAME,
                               NVL(POL.SALES_MAIN_TYPE,
                                   BI.SALES_MAIN_TYPE) SALES_MAIN_TYPE,
                               'COMMON' AS DISCOUNT_TYPE,
                               0 AS IS_DOWN_PAY,CAST(NULL AS NUMERIC) AS DOWN_PAY_SCALE,-- ADD YB LIANGYM2 2018-5-31 订金比例 暂时不用而是外面关联取订金比例
                               CAST(NULL AS NUMERIC) AS SRC_LG_ORDER_ID,-- ADD YB LIANGYM2 2018-5-31 来源提货订单ID
                               POH.ORDER_NUMBER ORIGIN_ORDER_NUM,NULL AS ORDER_NUM,
                               --POH.LOCK_AMOUNT_FLAG 送审锁款,(这一行写错了别名)
                               /*DECODE(POH.LOCK_AMOUNT_FLAG,
                                      'S',
                                      '送审锁款',
                                      'Y',
                                      '发货锁定到款')*/c.code_name LOCK_METHOD,
                               NVL(ROUND((CASE
                                            WHEN NVL(POH.DOWN_PAY_SCALE, -1) < 0 THEN
                                              CASE
                                               WHEN POH.FORM_STATE NOT IN
                                                    ('23',
                                                     '32',
                                                     '248',
                                                     '303',
                                                     '304',
                                                     '306') THEN
                                                NVL(POL.APPLY_QTY, 0) -
                                                NVL(POL.CARRY_QTY, 0) -
                                                NVL(POL.CANCEL_INV_CHECK_QTY, 0) -
                                                NVL(POL.CANCEL_INV_IN_QTY, 0)
                                               WHEN POH.FORM_STATE IN ('23', '32') THEN
                                                NVL(POL.CAN_PRODUCE_QTY, 0) +
                                                NVL(POL.INV_AFFIRM_QTY, 0) -
                                                NVL(POL.CARRY_QTY, 0) -
                                                NVL(POL.CANCEL_INV_CHECK_QTY, 0) -
                                                NVL(POL.CANCEL_INV_IN_QTY, 0)
                                               ELSE
                                                0
                                              END
                                            ELSE
                                              0
                                          END
                                         ) * POL.ITEM_PRICE *
                                         (100 -
                                         NVL(POL.DISCOUNT_RATE, 0) -
                                         NVL(POL.ORDERED_DISCOUNT_RATE,
                                              0)) / 100,
                                         2),
                                   0) LOCKED_AMOUNT,
                               NVL(ROUND((CASE
                                            WHEN POH.DOWN_PAY_SCALE > 0 THEN
                                              POH.DOWN_PAY_SCALE / 100 *
                                              CASE
                                               WHEN POH.FORM_STATE NOT IN
                                                    ('23',
                                                     '32',
                                                     '248',
                                                     '303',
                                                     '304',
                                                     '306') THEN
                                                NVL(POL.APPLY_QTY, 0) -
                                                NVL(POL.CARRY_QTY, 0) -
                                                NVL(POL.CANCEL_INV_CHECK_QTY, 0) -
                                                NVL(POL.CANCEL_INV_IN_QTY, 0)
                                               WHEN POH.FORM_STATE IN ('23', '32') THEN
                                                NVL(POL.CAN_PRODUCE_QTY, 0) +
                                                NVL(POL.INV_AFFIRM_QTY, 0) -
                                                NVL(POL.CARRY_QTY, 0) -
                                                NVL(POL.CANCEL_INV_CHECK_QTY, 0) -
                                                NVL(POL.CANCEL_INV_IN_QTY, 0)
                                               ELSE
                                                0
                                              END
                                            ELSE
                                              0
                                          END
                                         ) * POL.ITEM_PRICE *
                                         (100 -
                                         NVL(POL.DISCOUNT_RATE, 0) -
                                         NVL(POL.ORDERED_DISCOUNT_RATE,
                                              0)) / 100,
                                         2),
                                   0) LOCKED_DOWNPAY_AMOUNT, --锁定订金
                               NVL(ROUND((CASE
                                            WHEN NVL(POH.DOWN_PAY_SCALE, -1) < 0 THEN
                                              CASE
                                               WHEN POH.FORM_STATE NOT IN
                                                    ('23', '32', '248', '303', '304', '306') THEN
                                                NVL(POL.APPLY_QTY, 0) -
                                                NVL(POL.CARRY_QTY, 0) -
                                                NVL(POL.CANCEL_INV_CHECK_QTY, 0) -
                                                NVL(POL.CANCEL_INV_CHECK_QTY, 0)
                                               WHEN POH.FORM_STATE IN
                                                    ('23', '32') THEN--, '306'
                                                NVL(POL.CAN_PRODUCE_QTY, 0) +
                                                NVL(POL.INV_AFFIRM_QTY, 0) -
                                                NVL(POL.CARRY_QTY, 0) -
                                                NVL(POL.CANCEL_INV_CHECK_QTY, 0) -
                                                NVL(POL.CANCEL_INV_CHECK_QTY, 0)
                                               ELSE
                                                0
                                              END
                                            ELSE
                                              0
                                          END
                                         ) * POL.ITEM_PRICE *
                                         NVL(POL.DISCOUNT_RATE, 0) / 100,
                                         2),
                                   0) LOCKED_DISCOUNT_AMOUNT,
                               NVL(ROUND((CASE
                                            WHEN POH.DOWN_PAY_SCALE > 0 THEN
                                              POH.DOWN_PAY_SCALE / 100 *
                                              CASE
                                               WHEN POH.FORM_STATE NOT IN
                                                    ('23', '32', '248', '303', '304', '306') THEN
                                                NVL(POL.APPLY_QTY, 0) -
                                                NVL(POL.CARRY_QTY, 0) -
                                                NVL(POL.CANCEL_INV_CHECK_QTY, 0) -
                                                NVL(POL.CANCEL_INV_CHECK_QTY, 0)
                                               WHEN POH.FORM_STATE IN
                                                    ('23', '32') THEN--, '306'
                                                NVL(POL.CAN_PRODUCE_QTY, 0) +
                                                NVL(POL.INV_AFFIRM_QTY, 0) -
                                                NVL(POL.CARRY_QTY, 0) -
                                                NVL(POL.CANCEL_INV_CHECK_QTY, 0) -
                                                NVL(POL.CANCEL_INV_CHECK_QTY, 0)
                                               ELSE
                                                0
                                              END
                                            ELSE
                                              0
                                          END
                                         ) * POL.ITEM_PRICE *
                                         NVL(POL.DISCOUNT_RATE, 0) / 100,
                                         2),
                                   0) AS LOCKED_DIS_DP_AMOUNT
                                FROM T_PLN_ORDER_HEAD POH --计划订单头表
                               INNER JOIN T_PLN_ORDER_LINE POL
                                  ON (POH.ORDER_HEAD_ID = POL.ORDER_HEAD_ID) --计划订单行表
                               INNER JOIN T_PLN_ORDER_TYPE POT
                                  ON (POT.ORDER_TYPE_ID = POH.ORDER_TYPE_ID) --订单类型表
                               INNER JOIN t_Bd_Item BI
                                  ON (Bi.Item_Id = Pol.Item_Id And
                                     Bi.Entity_Id = Pol.Entity_Id)
                                LEFT JOIN UP_CODELIST C
                                  ON (C.CODE_VALUE = poh.LOCK_AMOUNT_FLAG AND C.CODETYPE = 'plnlockMoneyFlag')
                               WHERE POH.ENTITY_ID = IN_ENTITY_ID
                                 AND POH.ACCOUNT_CODE =
                                     NVL(IS_ACCOUNT_CODE, POH.ACCOUNT_CODE)
                                 AND POH.CUSTOMER_CODE =
                                     NVL(IS_CUSTOMER_CODE, POH.CUSTOMER_CODE)
                                 AND NVL(POH.LOCK_AMOUNT_FLAG, 'N') = 'S'
                                 AND POH.FORM_STATE NOT IN
                                     ('19', '248', '303', '304', '305')
                      ) BI
                                INNER JOIN T_CUSTOMER_ACCOUNT A
                                ON ((A.ACCOUNT_ID = BI.ACCOUNT_ID OR A.ACCOUNT_CODE = BI.ACCOUNT_CODE)
                                AND A.ENTITY_ID = BI.ENTITY_ID AND A.ENTITY_ID = IN_ENTITY_ID)
                                LEFT JOIN T_PLN_LG_ORDER_HEAD LO
                                ON (LO.ORDER_HEAD_ID = BI.SRC_LG_ORDER_ID AND LO.ENTITY_ID = IN_ENTITY_ID
                                AND (IS_CUSTOMER_CODE IS NULL OR LO.CUSTOMER_CODE = IS_CUSTOMER_CODE)
                                AND (IS_ACCOUNT_CODE IS NULL OR LO.ACCOUNT_CODE = IS_ACCOUNT_CODE)
                                )
               GROUP BY BI.ENTITY_ID,
                        BI.CUSTOMER_ID,
                        A.SALES_CENTER_ID,
                        A.SALES_CENTER_CODE,
                        A.SALES_CENTER_NAME,
                        BI.CUSTOMER_CODE,
                        BI.CUSTOMER_NAME,
                        A.ACCOUNT_ID,
                        BI.ACCOUNT_CODE,
                        BI.ACCOUNT_NAME,
                        BI.SALES_MAIN_TYPE,
                        PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(BI.ENTITY_ID,
                                                               BI.CUSTOMER_ID,
                                                               BI.SALES_MAIN_TYPE,
                                                               A.ACCOUNT_ID),
                        --BI.DISCOUNT_TYPE,
                        BI.ORIGIN_ORDER_NUM,BI.ORDER_NUM,
                        LO.DOWN_PAY_SCALE,--锁定订金比例  update 2018/5/31 by 梁颜明
                        BI.LOCK_METHOD
              --梁颜明 2016-09-24修改 锁定到款拆分为普通的锁款和订金 计算锁定到款时两值要相加
              HAVING 0 <> SUM(BI.LOCKED_DISCOUNT_AMOUNT + BI.LOCKED_DIS_DP_AMOUNT)
              --
              OR 0 <> SUM(BI.LOCKED_AMOUNT + BI.LOCKED_DOWNPAY_AMOUNT)
              --
              UNION ALL
              SELECT D.ENTITY_ID,
                     D.CUSTOMER_ID,
                     D.SALES_CENTER_ID,
                     D.SALES_CENTER_CODE,
                     D.SALES_CENTER_NAME,
                     D.CUSTOMER_CODE,
                     D.CUSTOMER_NAME,
                     D.ACCOUNT_ID,
                     D.ACCOUNT_CODE,
                     D.ACCOUNT_NAME,
                     D.SALES_MAIN_TYPE,
                     D.CREDIT_GROUP_ID,
                     NULL AS DISCOUNT_TYPE,
                     D.ORIGIN_ORDER_NUM,
                     NULL ORDER_NUM,
                     D.DOWN_PAY_SCALE,
                     D.LOCK_METHOD,
                     D.LOCKED_AMOUNT,
                     D.LOCKED_DOWNPAY_AMOUNT,
                     D.LOCKED_DISCOUNT_AMOUNT,
                     D.LOCKED_DIS_DP_AMOUNT
                FROM T_CREDIT_LOCK_AMOUNT_DETAIL D
               WHERE D.ENTITY_ID = IN_ENTITY_ID
                 AND D.ACCOUNT_CODE = NVL(IS_ACCOUNT_CODE, D.ACCOUNT_CODE)
                 AND D.CUSTOMER_CODE = NVL(IS_CUSTOMER_CODE, D.CUSTOMER_CODE)
                 AND (D.LOCKED_DISCOUNT_AMOUNT + D.LOCKED_DIS_DP_AMOUNT <> 0
                   OR D.LOCKED_AMOUNT + D.LOCKED_DOWNPAY_AMOUNT <> 0)
              ) V
       INNER JOIN T_CREDIT_GROUP CG
          ON (CG.ENTITY_ID = V.ENTITY_ID AND
             CG.CREDIT_GROUP_ID = V.CREDIT_GROUP_ID)
       WHERE (VN_CREDIT_GROUP_ID IS NULL OR 0 >= VN_CREDIT_GROUP_ID
             --
             OR VN_CREDIT_GROUP_ID = V.CREDIT_GROUP_ID)
         AND EXISTS (SELECT VA.ACCOUNT_ID
                FROM CIMS.V_BD_USER_ACC_PRIV VA
               WHERE VA.USER_CODE = IS_USER_ACC
                 AND VA.ENTITY_ID = IN_ENTITY_ID
                 AND VA.ACCOUNT_ID = V.ACCOUNT_ID)
                 ;
    R_LOCK_AMOUT C_LOCK_AMOUT%ROWTYPE;
  
  BEGIN
    VN_CREDIT_GROUP_ID := IN_CREDIT_GROUP_ID;
    V_CENTER_ID := IN_SALES_CENTER_ID;
    IF 0 >= VN_CREDIT_GROUP_ID THEN
      VN_CREDIT_GROUP_ID := NULL;
    END IF;
    IF 0 >= V_CENTER_ID THEN
      V_CENTER_ID := NULL;
    END IF;
    IF V_CENTER_ID IS NULL AND IS_CUSTOMER_CODE IS NOT NULL THEN
      SELECT V.SALES_CENTER_ID
        INTO V_CENTER_ID
        FROM V_CUSTOMER_ACCOUNT_SALECENTER V
       WHERE V.CUSTOMER_CODE = NVL(IS_CUSTOMER_CODE,V.CUSTOMER_CODE)
         AND V.ACCOUNT_CODE = IS_ACCOUNT_CODE
         AND V.ENTITY_ID = IN_ENTITY_ID;
    END IF;
    
    IF V_CENTER_ID IS NOT NULL THEN
      OPEN C_LOCK_AMOUT;
    ELSE
      OPEN C_LOCK_AMOUT_NOCENTER;
    END IF;
  
    --FOR R_LOCK_AMOUT IN C_LOCK_AMOUT 
    LOOP
      IF V_CENTER_ID IS NOT NULL THEN
        FETCH C_LOCK_AMOUT INTO R_LOCK_AMOUT;
        EXIT WHEN C_LOCK_AMOUT%NOTFOUND;
      ELSE
        FETCH C_LOCK_AMOUT_NOCENTER INTO R_LOCK_AMOUT;
        EXIT WHEN C_LOCK_AMOUT_NOCENTER%NOTFOUND;
      END IF;
      V_LOCK_AMOUT_ROW := OBJ_CREDIT_LOCK_AMOUNT(R_LOCK_AMOUT.ENTITY_ID,
                                                 R_LOCK_AMOUT.CUSTOMER_ID,
                                                 R_LOCK_AMOUT.CUSTOMER_CODE,
                                                 R_LOCK_AMOUT.CUSTOMER_NAME,
                                                 R_LOCK_AMOUT.ACCOUNT_ID,
                                                 R_LOCK_AMOUT.ACCOUNT_CODE,
                                                 R_LOCK_AMOUT.ACCOUNT_NAME,
                                                 R_LOCK_AMOUT.SALES_MAIN_TYPE,
                                                 R_LOCK_AMOUT.ORIGIN_ORDER_NUM,R_LOCK_AMOUT.ORDER_NUM,
                                                 R_LOCK_AMOUT.DOWN_PAY_SCALE,--锁定订金比例  update 2018/5/31 by 梁颜明
                                                 R_LOCK_AMOUT.LOCK_METHOD,
                                                 R_LOCK_AMOUT.LOCKED_AMOUNT,
                                                 R_LOCK_AMOUT.LOCKED_DISCOUNT_AMOUNT,
                                                 R_LOCK_AMOUT.LOCKED_DOWNPAY_AMOUNT,
                                                 R_LOCK_AMOUT.LOCKED_DIS_DP_AMOUNT,
                                                 R_LOCK_AMOUT.SALES_CENTER_ID,
                                                 R_LOCK_AMOUT.SALES_CENTER_CODE,
                                                 R_LOCK_AMOUT.SALES_CENTER_NAME,
                                                 R_LOCK_AMOUT.CREDIT_GROUP_ID,
                                                 R_LOCK_AMOUT.CREDIT_GROUP_NAME,
                                                 R_LOCK_AMOUT.DISCOUNT_TYPE);
      PIPE ROW(V_LOCK_AMOUT_ROW);
    
    END LOOP;
    IF V_CENTER_ID IS NOT NULL THEN
      CLOSE C_LOCK_AMOUT;
    ELSE
      CLOSE C_LOCK_AMOUT_NOCENTER;
    END IF;
    RETURN;
  END F_GET_LOCK_AMOUNT;

END PKG_CREDIT_LOCK_AMOUNT;
/

