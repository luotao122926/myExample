create package PKG_PLN_COLLECT_ORDER is

  --------------------------------------------------------------------------------------------
  -- Author  : 李振
  -- Created : 2014-07-02 11:05:52
  -- Purpose : 计划订单管理 订单汇总功能处理过程
  --------------------------------------------------------------------------------------------

  --------------------------------------------------------------------------------------------
  -- Author  : 李振
  -- Created : 2014-07-02 11:05:52
  -- Purpose : 计划订单管理 订单汇总功能库存评审自动库存评审
  -- Return:  R_RESULT返回值： 0：无错误    -21000：程序错误中断处理
  --          R_ERR_MSG: SUCCESS:无错误     其它（信息）：程序错误信息说明
  --------------------------------------------------------------------------------------------
  PROCEDURE P_AUTO_STOCK_AFFIRM(P_COLLECT_HEAD_ID   IN NUMBER, --汇总订单头ID
                                P_STOCK_AFFIRM_TYPE IN NUMBER, --库存评审类型：1：汇总库存评审 2：计划订单库存评审
                                P_ENTITY_ID         IN NUMBER, --主体ID
                                P_USER_ID           IN VARCHAR2, --用户ID
                                P_RESULT            OUT NUMBER, --错误返回值
                                P_ERR_MSG           OUT VARCHAR2); --错误信息

  --------------------------------------------------------------------------------------------
  -- Author  : 李振
  -- Created : 2014-07-02 11:05:52
  -- Purpose : 计划订单管理 订单汇总功能单行库存评审自动库存评审
  -- Return:  R_RESULT返回值： 0：无错误    -21000：程序错误中断处理
  --          R_ERR_MSG: SUCCESS:无错误     其它（信息）：程序错误信息说明
  --------------------------------------------------------------------------------------------
  PROCEDURE P_SINGLE_AUTO_STOCK_AFFIRM(P_COLLECT_HEAD_ID   IN NUMBER, --汇总订单头ID
                                       P_COOLECT_LINE_ID   IN NUMBER, --汇总订行头ID
                                       P_STOCK_AFFIRM_TYPE IN NUMBER, --库存评审类型：1：汇总库存评审 2：计划订单库存评审
                                       P_ENTITY_ID         IN NUMBER, --主体ID
                                       P_USER_ID           IN VARCHAR2,
                                       P_RESULT            OUT NUMBER,
                                       P_ERR_MSG           OUT VARCHAR2); --错误信息

end PKG_PLN_COLLECT_ORDER;
/

