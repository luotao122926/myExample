create view V_CREDIT_CONTACT_AMOUNT_ORDER as
SELECT 'order' Business_ID ,  --业务类型
       order_plan.ship_plan_id BILL_ID, --单据id
       to_char(order_plan.ship_plan_id) BILL_NUM, --单据编号
       order_plan.ship_info_date BILL_DATE, --单据日期
       order_plan.status BILL_STATUS, --单据状态
       --01：计划订单 02：提货订单 03 ：调拨订单 04：促销品
       to_number(order_plan.origin_type)  bill_type_id, --单据类型id
       order_plan.origin_type bill_type_code , --单据类型编码
       decode(order_plan.origin_type,'01','计划订单',
                                     '02','提货订单',
                                     '03','调拨订单',
                                     '04','促销品') bill_type_name, --单据类型名称
       order_plan.creation_date settle_date, --单据结算日期
       null account_date, --客户对帐日期
       null checked_account_date, --财务对帐日期
       order_plan.customer_id, --客户id
       order_plan.customer_code, --客户编码
       order_plan.customer_name, --客户名称
       cus_account.account_id,   --账户ID
       cus_account.account_code, --账户编码
       cus_account.account_name, --账户名称
       PKG_CREDIT_TOOLS.FUN_GET_CODELIST(cus_main_type.cooperation_model_id,
                                         'MIDEA_MARKET_MODE',
                                         2) customer_type, --客户类型
       --NVL (precus.customer_id, cih.customer_id)     pre_customer_id,    --上级单位ID
       --NVL (precus.customer_code, cih.customer_code) pre_customer_code,  --上级单位编码
       --NVL (precus.customer_name, cih.customer_name) pre_customer_name,  --上级单位名称
       --soh.finance_main_entity_id,              --主主体
       order_plan.entity_id, --主体
       order_plan.sales_center_id, --营销中心id
       order_plan.sales_center_code, --营销中心编码
       order_plan.Sales_Center_Name, --营销中心名称
       v_center.sales_region_id, --销售区域ID
       v_center.sales_region_name, --销售区域名称
       item.brand                   brand_code, --品牌编码
       item.brand                   brand_name, --品牌名称
       item.sales_main_type         sales_main_type, --营销大类编码
       item_class.CLASS_NAME        sales_main_type_name, --营销大类名称
       --soh.small_category,                   --营销小类
       null                        project_num, --批文编码
       null                        project_name, --批文名称
       NULL                        cash_code, --票据号
       NULL                        cash_date, --票据日期
       NULL                        due_date, --到期日期
       null                        invoice_num_list, --发票号串（税控发票）
       null                        invoice_date, --发票日期（税控日期）
       null sales_year_id, --销售年度ID
       null  sales_year, --销售年度
       source_type.Source_Type_Code  src_type, --来源类型
       /*decode(order_plan.origin_type,'01','计划订单',
                                     '02','提货订单',
                                     '03','调拨订单',
                                     '04','促销品')*/
       source_type.source_type_name src_type_name, --来源类型名称
       order_plan.origin_origin_order_code src_bill_num, --来源号
       null discount_type_id, --折扣id
       null discount_type_name, --折扣名称
       null                        discount_item, --折让项目
       null                        discount_mode, --折让方式
       --soh.check_flag,                     --是否校验
       'Y' settle_flag, --是否结算
       /*0 receipt_amount,                        --收款金额
       0 receipt_dis_amount,                      --收款折让金额*/
       /*DECODE (itt.transaction_source_type_id, 1, -1, 2, 1, 0)
       * DECODE (  DECODE (soh.presales_flag, 'N', 0, 1)
                 * DECODE (soh.account_flag, 'Y', 0, 1),
                 0, 0,
                 1, soh.presales_amount
                ) presales_amount                                --铺底金额*/
       decode(order_plan.status,'03',0,1) * nvl(order_plan.item_qty,0) * nvl(order_plan.item_price,0) list_amount, --列表金额
       decode(order_plan.status,'03',0,1) * nvl(order_plan.item_qty,0) * nvl(order_plan.item_price,0) * decode(source_type.source_type_code,'1008',0,nvl(order_plan.discount_rate,0)) discount_amount, --折让金额
       decode(order_plan.status,'03',0,1) * nvl(order_plan.item_qty,0) * nvl(order_plan.item_price,0) * (1-nvl(order_plan.discount_rate,0)) * decode(source_type.source_type_code,'1008',0,1) settle_amount, --结算金额
       0 SOLUTION_PAY_AMOUNT, --三方承兑已解付金额
       /*DECODE (itt.transaction_source_type_id, 1, -1, 2, 1, 0)
       * DECODE (DECODE (soh.presales_flag, 'N', 0, 1)* DECODE (soh.account_flag, 'Y', 0, 1),
                 0,
                 soh.instant_dis_amount,
                 1,
                 0) instant_dis_amount,           --即返额 */
       order_plan.remark, --备注
       order_plan.creation_date, --录入日期
       1                        sales_receipt,
       --soh.patch_amount,                         --补息（去掉）
       --0 paste_amount,                           --贴息（去掉）
       --sy.item_type,                             --产品类型
       --NVL (soh.ora_intooiflag_c, 'N') intooiflag, --是否引入财务
       1 cnt,
       null fund_ctrl_mode, --控制方式
       null created_mode,  --制单方式
       'N' draft_flag, --是否为承兑
       null audit_flag, --审核标识
       source_type.source_type_id src_type_id,
       source_type.source_type_code src_type_code,
       null import_erp  --是否ERP引入
       ,order_plan.discount_type --折让方式 add by liangym2 20171030
--SOH.NC_OI_FLAG,                               --引入NC接口标示
--cih.FINANCIAL_STATISTICAL_TYPE                --财务统计属性 <客户属性控制>
  FROM T_LG_SHIP_PLAN             order_plan, --发货需求计划
       T_BD_ITEM                  ITEM, --产品物料表
       T_CUSTOMER_SALES_MAIN_TYPE cus_main_type, --客户营销大类关系表
       T_CUSTOMER_ACCOUNT         cus_account,  --客户账户关系表
       v_bd_sales_center          v_center, --营销区域视图
       v_bd_item_class_ims        item_class, --营销大类信息
       T_INV_BILL_TYPES           bill_type,  --业务单据类型
       T_INV_SOURCE_TYPES         source_type  --单据源类型
 WHERE order_plan.item_code = ITEM.ITEM_CODE
   AND order_plan.customer_id = cus_main_type.custom_id
   AND ITEM.SALES_MAIN_TYPE = cus_main_type.sales_main_type_code
   AND order_plan.entity_id = cus_main_type.entity_id
   and order_plan.sales_center_id = v_center.sales_center_id
   and item.sales_main_type = item_class.CLASS_CODE
   and item_class.CLASS_TYPE = 'M'
   AND order_plan.entity_id = cus_account.entity_id
   and order_plan.customer_id = cus_account.customer_id
   and order_plan.account_code = cus_account.account_code
   and cus_account.active_flag <> 'N'
   and order_plan.sales_order_type_id = bill_type.bill_type_id(+)
   and bill_type.source_type_id = source_type.source_type_id
/

