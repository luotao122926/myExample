create PACKAGE PKG_CUS_RATE_ASSESS is
  /*
  *执行语义的SQL
  */
  function fun_get_val_by_semantic_sql(P_Get_Val_Sql   clob,
                                       P_EntityId      number,
                                       P_CustomerId    number, --预留未使用
                                       P_CustomerCode  varchar2,
                                       P_SalesMainType varchar2,
                                       P_StartTime     varchar2,
                                       P_EndTime       varchar2)
    return number;

  /*
  *客户评级：客户评级数据
  */
  PROCEDURE P_RATE_CUS_INDEX_DATA(P_TEMPLATE_IDS in varchar2, --评级模板ID
                                  P_CREATED_BY   in varchar2, --操作员
                                  P_MESSAGE      out varchar2 --成功则返回“SUCCESS”，否则返回出错信息
                                  );
  /*
  *客户评级：自动计算
  */
  PROCEDURE P_RATE_CALINDEX(P_TEMPLATE_IDS in varchar2, --评级模板ID
                            P_CREATED_BY   in varchar2, --操作员
                            P_MESSAGE      out varchar2 --成功则返回“SUCCESS”，否则返回出错信息
                            );
  /*
  *客户评级：评分
  */
  PROCEDURE P_RATE_SCORE(P_TEMPLATE_IDS in varchar2, --评级模板ID
                         P_CREATED_BY   in varchar2, --操作员
                         P_MESSAGE      out varchar2 --成功则返回“SUCCESS”，否则返回出错信息
                         );
  /*
  *客户考核：客户考核数据
  */
  PROCEDURE P_ASSESS_CUS_INDEX_DATA(P_TEMPLATE_IDS in varchar2, --评级模板ID
                                    P_CREATED_BY   in varchar2, --操作员
                                    P_MESSAGE      out varchar2 --成功则返回“SUCCESS”，否则返回出错信息
                                    );

  /*
  *客户考核：自动计算
  */
  PROCEDURE P_ASSESS_CALINDEX(P_TEMPLATE_IDS in varchar2, --评级模板ID
                              P_CREATED_BY   in varchar2, --操作员
                              P_MESSAGE      out varchar2 --成功则返回“SUCCESS”，否则返回出错信息
                              );
  /*
  *客户考核：评分
  */
  PROCEDURE P_ASSESS_SCORE(P_TEMPLATE_IDS in varchar2, --评级模板ID
                           P_CREATED_BY   in varchar2, --操作员
                           P_MESSAGE      out varchar2 --成功则返回“SUCCESS”，否则返回出错信息
                           );

END PKG_CUS_RATE_ASSESS;
/

