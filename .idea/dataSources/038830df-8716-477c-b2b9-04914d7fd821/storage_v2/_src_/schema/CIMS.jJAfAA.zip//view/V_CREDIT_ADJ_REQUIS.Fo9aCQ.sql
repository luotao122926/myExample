create view V_CREDIT_ADJ_REQUIS as
SELECT a."BILL_ID",
       a."ENTITY_ID",
       a."BILL_NUM",
       a."BILL_STATUS",
       a."CREATED_BY",
       a."CREATION_TIME",
       a."BILL_DATE",
       a."CUSTOMER_ID",
       a."CUSTOMER_CODE",
       a."CUSTOMER_NAME",
       a."SALES_REGION_ID",
       a."SALES_REGION_CODE",
       a."SALES_REGION_NAME",
       a."SALES_CENTER_ID",
       a."SALES_CENTER_CODE",
       a."SALES_CENTER_NAME",
       a."SALES_MAIN_TYPE",
       a."OLD_CREDIT_LINE",
       a."ADJ_AMOUNT",
       a."NEW_CREDIT_LINE",
       a."BEGIN_DATE",
       a."END_DATE",
       a."ADJ_REASON",
       a."LAST_APPROVAL_TIME",
       a."LAST_UPDATED_BY",
       a."LAST_UPDATE_DATE",
       a."CANCEL_BY",
       a."CANCEL_TIME",
       a."DUE_BY",
       a."DUE_TIME",
       a."PRE_FIELD_01",
       a."PRE_FIELD_02",
       a."PRE_FIELD_03",
       a."PRE_FIELD_04",
       a."PRE_FIELD_05",
       a."PRE_FIELD_06",
       b.custom_level,
       b.custom_credit_level,
       B.sales_main_type_code,
       B.Sales_main_type_name,
       nvl((SELECT SUM(X.COUNTER)
          FROM T_CREDIT_BAD_RECORD X
         WHERE X.ENTITY_ID = A.ENTITY_ID
           AND X.CUSTOMER_ID = A.CUSTOMER_ID),0) counter,
       a.version,
       '' approval_note --审批意见，视图就不去审批表取了，界面直接去后台查询加载
  FROM t_credit_adj_requis        a,
       t_customer_sales_main_type b
      -- t_bd_item_class            c,
       --t_credit_bad_record        d
 WHERE A.ENTITY_ID = B.ENTITY_ID
   AND A.CUSTOMER_ID = B.CUSTOM_ID
   AND A.SALES_MAIN_TYPE = B.SALES_MAIN_TYPE_CODE
   AND NVL(upper(B.ACTIVE_FLAG),'ACTIVE') = 'ACTIVE'
/

