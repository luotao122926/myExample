create FUNCTION      f_get_maxid(tablename varchar2,
                             keyname     varchar2
                             ) return number is

    f_sql     varchar2(4000);
    max_num   number;
     
  begin
    --查询表中主键的最大值
    f_sql := 'select nvl(max(' || keyname || '),0)+1 from ' || tablename;
    execute immediate f_sql into max_num;
    dbms_output.put_line('表' || tablename || '的' || keyname || '最大值为:' || max_num);
    return max_num;
  exception
    when others then
      return 0;
  end f_get_maxid;
/

