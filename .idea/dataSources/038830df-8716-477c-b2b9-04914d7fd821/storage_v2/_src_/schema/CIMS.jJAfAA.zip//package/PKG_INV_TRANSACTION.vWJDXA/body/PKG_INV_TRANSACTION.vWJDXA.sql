create PACKAGE BODY      pkg_inv_transaction
AS
--定义全局变量
   pkgn_source_type_id        t_inv_bill_types.source_type_id%TYPE;
   --单据源类型ID
   pkgn_head_id               t_inv_bill_types.bill_period_head_id%TYPE;
   --单据周期头ID
   pkgs_transaction_flag      t_inv_bill_period_line.transaction_flag%TYPE;
   --是否有物料事务
   pkgn_transaction_type_id   t_inv_bill_period_line.transaction_type_id%TYPE;
   --物料事务类型ID
   pkgn_if_his                NUMBER                                              := 1;
   --是否已有物料事物历史记录    0否，1是
   pkgn_entity_id             t_inv_transaction_history.entity_id%TYPE;
   --经营主体ID
   pkgn_period_id             t_inv_inventory_periods.period_id%TYPE;
   --期间ID
   pkgs_business_state        t_inv_transaction_history.business_state%TYPE;
   --业务单据状态
   pkgn_business_header_id    t_inv_transaction_history.business_header_id%TYPE;
   --业务单据头ID
   pkgs_business_num          t_inv_transaction_history.business_num%TYPE;
   --业务单据号
   pkgd_transaction_date      t_inv_transaction_history.transaction_date%TYPE;
   --业务日期
   pkgs_period_name           t_inv_transaction_history.period_name%TYPE;
   --期间名称
   pkgs_action_type           t_inv_transaction_history.action_type%TYPE;
   --活动类型
   pkgs_new_str               CLOB                                                := '';
   --本次insert的历史ID串
   pkgn_bill_type_id          t_inv_bill_types.bill_type_id%TYPE;
   --单据类型ID
   pkgn_created_by            t_inv_transaction_history.created_by%TYPE;
   --操作人
   pkgd_sysdate               DATE;                                    --物料事物的处理时间保持一致
   pkgn_if_null               NUMBER;
   pkgn_error_code            NUMBER;
   pkgs_bill_type_flag        t_inv_bill_types.negative_inventory_flag%TYPE;

   --是否允许负库存，是  Y，否 N，默认为 是 Y

   --存储业务单据的信息
   TYPE ty_bill_rec IS RECORD (
      header_id              t_inv_transaction_history.business_header_id%TYPE,
      --业务单据头ID
      business_num           t_inv_transaction_history.business_num%TYPE,
      --业务单据号
      line_id                t_inv_transaction_history.business_line_id%TYPE,
      --业务单据行ID
      line_detail_id         t_inv_transaction_history.business_line_detail_id%TYPE,
      --业务单据行明细ID
      item_id                t_inv_transaction_history.item_id%TYPE,                       --产品ID
      item_code              t_inv_transaction_history.item_code%TYPE,
      --产品编码
      item_name              VARCHAR2 (240),                                             --产品名称
      transaction_uom        t_inv_transaction_history.transaction_uom%TYPE,
      --单位
      inventory_id           t_inv_transaction_history.inventory_id%TYPE,
      --仓库ID
      inventory_code         t_inv_transaction_history.inventory_code%TYPE,
      --仓库编码
      inventory_name         t_inv_transaction_history.inventory_name%TYPE,
      --仓库名称

      terminal_entity_id  t_pro_terminal_entity.terminal_entity_id%TYPE, --门店主体ID add by  GUIBR20150723 样机
      terminal_code       t_pro_terminal.terminal_code%TYPE, --门店编码 add by  GUIBR20150723 样机
      terminal_name       t_pro_terminal.terminal_name%TYPE, --门店名称 add by  GUIBR20150723 样机
      
      original_bill_num   VARCHAR2(100),
      remark              VARCHAR2(4000),

      transaction_quantity   t_inv_transaction_history.transaction_quantity%TYPE,
      --数量
      created_by             t_inv_transaction_history.created_by%TYPE,
      --操作人
      from_inventory_id      t_inv_transaction_history.from_inventory_id%TYPE,
      --源仓库ID
      from_inventory_code    t_inv_transaction_history.from_inventory_code%TYPE,
      --源仓库编码
      from_inventory_name    t_inv_transaction_history.from_inventory_name%TYPE,
      --源仓库名称
      to_inventory_id        t_inv_transaction_history.to_inventory_id%TYPE,
      --目的仓库ID
      to_inventory_code      t_inv_transaction_history.to_inventory_code%TYPE,
      --目的仓库编码
      to_inventory_name      t_inv_transaction_history.to_inventory_name%TYPE,
      --目的仓库名称
      oper_kind              NUMBER                               --操作类型    0不变；1增加；2修改
   );

   TYPE ty_bill_tab IS TABLE OF ty_bill_rec
      INDEX BY BINARY_INTEGER;

   ty_bill                    ty_bill_tab;

--对前台录入参数的为空校验
   PROCEDURE check_is_null (
      in_entity_id            IN       t_inv_transaction_history.entity_id%TYPE,
      --经营主体ID
      in_bill_type_id         IN       t_inv_bill_types.bill_type_id%TYPE,
      --单据类型ID
      is_business_state       IN       t_inv_transaction_history.business_state%TYPE,
      --单据状态
      id_transaction_date     IN       t_inv_transaction_history.transaction_date%TYPE,
      --业务日期
      in_business_header_id   IN       t_inv_transaction_history.business_header_id%TYPE,
      --业务单据头ID
      in_if_null              IN       NUMBER,                        --是否是空的业务单据，0否，1是
      on_flag                 OUT      NUMBER,
      os_prompt               OUT      VARCHAR2
   )
   AS
   BEGIN
      IF in_entity_id IS NULL
      THEN
         on_flag      := -1;
         os_prompt    := '经营主体ID传入为空！';
         RETURN;
      ELSIF in_bill_type_id IS NULL
      THEN
         on_flag      := -1;
         os_prompt    := '单据类型ID传入为空！';
         RETURN;
      ELSIF is_business_state IS NULL
      THEN
         on_flag      := -1;
         os_prompt    := '单据状态传入为空！';
         RETURN;
      ELSIF id_transaction_date IS NULL
      THEN
         on_flag      := -1;
         os_prompt    := '业务日期传入为空！';
         RETURN;
      ELSIF in_business_header_id IS NULL
      THEN
         on_flag      := -1;
         os_prompt    := '业务单据头ID传入为空！';
         RETURN;
      ELSIF in_if_null IS NULL
      THEN
         on_flag      := -1;
         os_prompt    := '是否为空业务单据传入为空！';
         RETURN;
      END IF;
   END check_is_null;

--检测是否调用物料事务
   PROCEDURE check_transaction_yesorno_p (
      in_entity_id          IN       t_inv_transaction_history.entity_id%TYPE,
      --经营主体ID
      in_bill_type_id       IN       t_inv_bill_types.bill_type_id%TYPE,
      --单据类型ID
      is_business_state     IN       t_inv_transaction_history.business_state%TYPE,
      --单据状态
      os_transaction_flag   OUT      VARCHAR2,
      --是否调用物料事物 是（Y）、否（N）
      on_flag               OUT      NUMBER,
      os_prompt             OUT      VARCHAR2
   )
   AS
      vn_types_count   NUMBER;
      vn_line_count    NUMBER;
   BEGIN
      on_flag                := 0;
      os_prompt              := '单据类型不存在或已失效！';

      SELECT bill_period_head_id, source_type_id, negative_inventory_flag
        INTO pkgn_head_id, pkgn_source_type_id, pkgs_bill_type_flag
        FROM t_inv_bill_types
       WHERE entity_id = in_entity_id
         AND bill_type_id = in_bill_type_id
         AND begin_date <= pkgd_transaction_date
         AND (end_date >= pkgd_transaction_date OR end_date IS NULL);

      os_prompt              := '单据周期行不能存在或已失效！';

      SELECT transaction_flag
        INTO pkgs_transaction_flag
        FROM t_inv_bill_period_line
       WHERE bill_period_head_id = pkgn_head_id AND bill_status_code = is_business_state;

      os_transaction_flag    := pkgs_transaction_flag;

      IF pkgs_transaction_flag = 'N'
      THEN
         os_prompt    := '不需要调用物料事务！';
         RETURN;
      ELSE
         SELECT transaction_type_id
           INTO pkgn_transaction_type_id
           FROM t_inv_bill_period_line
          WHERE bill_period_head_id = pkgn_head_id AND bill_status_code = is_business_state;

         pkgn_entity_id         := in_entity_id;
         pkgs_business_state    := is_business_state;
         os_prompt              := '物料事务类型不存在或已失效！';

         SELECT action_type
           INTO pkgs_action_type
           FROM t_inv_transaction_types
          WHERE entity_id = pkgn_entity_id
            AND transaction_type_id = pkgn_transaction_type_id
            AND begin_date <= pkgd_transaction_date
            AND (end_date >= pkgd_transaction_date OR end_date IS NULL);

         pkgn_bill_type_id      := in_bill_type_id;
      END IF;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN

         --on_flag                := 0;               --未找到配置数据，默认不需要调用物料事务，返回0
         on_flag                := -1; --update by lingyy 2015-03-30 未找到配置信息，返回-1.
         os_transaction_flag    := 'N';
         os_prompt              := '未找到配置数据:' || os_prompt;
         --rollback;        在java里检查on_flag，来判断是否进行事务回滚（通过抛出异常方式进行回滚）或提交
         RETURN;
      WHEN OTHERS
      THEN
         on_flag                := -1;
         os_transaction_flag    := 'N';
         os_prompt              := '调用check_transaction_yesOrNo_p时发生异常！';
         --rollback;
         RETURN;
   END check_transaction_yesorno_p;

--add by lingyy 2014-12-09 获取业务单据信息
   PROCEDURE get_bill_info_p (
      in_entity_id            IN       t_inv_transaction_history.entity_id%TYPE,
      --经营主体ID
      in_business_header_id   IN       t_inv_transaction_history.business_header_id%TYPE,
      --业务单据头ID
      is_bill_kind            IN       VARCHAR2,
--B1（采购中转）、B2（仓库调拨）、B3（仓库盘点）、B4（销售）、B5（推广物料）、B6(备货单)
      on_flag                 OUT      NUMBER,
      os_prompt               OUT      VARCHAR2
   )
   AS
   BEGIN
      on_flag                    := 0;
      os_prompt                  := '';
      pkgn_business_header_id    := in_business_header_id;
      pkgd_sysdate               := SYSDATE;
      pkgn_created_by            := NULL;
      pkgs_business_num          := NULL;

      IF is_bill_kind = 'B1'
      THEN                                                                           --B1采购中转单
         SELECT po_num, created_by
           INTO pkgs_business_num, pkgn_created_by
           FROM t_inv_po_headers
          WHERE entity_id = in_entity_id AND po_id = in_business_header_id;
      ELSIF is_bill_kind = 'B2'
      THEN                                                                            --B2仓库调拨单
         SELECT trsf_order_num, created_by
           INTO pkgs_business_num, pkgn_created_by
           FROM t_inv_trsf_order
          WHERE entity_id = in_entity_id AND trsf_order_id = in_business_header_id;
      ELSIF is_bill_kind = 'B3'
      THEN                                                                            --B3仓库盘点单
         SELECT check_order_num, created_by
           INTO pkgs_business_num, pkgn_created_by
           FROM t_inv_check_orders
          WHERE entity_id = in_entity_id AND check_order_id = in_business_header_id;
      ELSIF is_bill_kind = 'B4'
      THEN                                                                                --B4销售单
         SELECT so_num, created_by
           INTO pkgs_business_num, pkgn_created_by
           FROM t_so_header
          WHERE entity_id = in_entity_id AND so_header_id = in_business_header_id;
      ELSIF is_bill_kind = 'B5'
      THEN                                                                            --B5推广物料单
         SELECT PMT_SEND_NUM, created_by
           INTO pkgs_business_num, pkgn_created_by
           FROM T_PMT_COLLAR_SEND_HEAD
          WHERE entity_id = in_entity_id AND COLLAR_SEND_HEAD_ID = in_business_header_id;
      ELSIF is_bill_kind = 'B6'
      THEN                                                                                --B6备货单
         SELECT stockup_order_num, created_by
           INTO pkgs_business_num, pkgn_created_by
           FROM t_inv_stockup_order
          WHERE entity_id = in_entity_id AND stockup_order_id = in_business_header_id;
      ELSE
         on_flag      := -1;
         os_prompt    := '物料事务处理过程无法处理该单据类型！单据类型: ' || is_bill_kind;
         RETURN;
      END IF;

      IF pkgs_business_num IS NULL
      THEN
         on_flag      := -1;
         os_prompt    := '该业务单据单据编码为空，请核查单据！';
         RETURN;
      END IF;

      IF pkgn_created_by IS NULL
      THEN
         on_flag      := -1;
         os_prompt    := '该业务单据创建人为空，请核查单据！';
         RETURN;
      END IF;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         on_flag      := -1;
         os_prompt    := '该业务单据不存在！';
         RETURN;
      WHEN OTHERS
      THEN
         on_flag      := -1;
         os_prompt    := '调用get_bill_info_p时发生异常！' || SUBSTR (SQLERRM, 1, 200);
         --rollback;
         RETURN;
   END get_bill_info_p;

   PROCEDURE init_p (
      in_business_header_id   IN       t_inv_transaction_history.business_header_id%TYPE,
      --业务单据头ID
      is_bill_kind            IN       VARCHAR2,
      --B1（采购中转）、B2（仓库调拨）、B3（仓库盘点）、B4（销售）、B5（推广物料）
      is_business_state       IN       t_inv_transaction_history.business_state%TYPE,
      --是否相同仓库
      os_whether_same_inv     OUT      VARCHAR2,
      --单据状态
      on_flag                 OUT      NUMBER,
      os_prompt               OUT      VARCHAR2
   )
   AS
      vn_transaction_quantity   t_inv_transaction_history.transaction_quantity%TYPE;
      so_data                   pkg_so_biz.bill_data_inv_array;
      a                         NUMBER                                                := 0;
      vs_productform            t_bd_item.productform%TYPE;                              --产品形态
   BEGIN
      on_flag      := 0;
      os_prompt    := '';
      os_whether_same_inv := 'N';
      so_data.DELETE;
      ty_bill.DELETE; --add by lingyy 2015-01-15
      --调业务单据的过程，返回业务单据信息
      pkg_so_biz.p_bill_data_for_inv (is_bill_kind,
                                      is_business_state,
                                      in_business_header_id,
                                      so_data,
                                      on_flag,
                                      os_prompt
                                     );

      IF on_flag < 0
      THEN
         os_prompt    := '调用业务单据接口失败，原因：' || os_prompt;
         --rollback;
         RETURN;
      ELSE
         IF so_data.COUNT = 0
         THEN
            /* del by lingyy 2014-10-27 记录为空，属于正常情况，无须设置on_flag为-1.
              on_flag := -1;
             os_prompt := '调用业务单据接口,返回业务单据信息为空';
             */--rollback;
            RETURN;
         END IF;
      END IF;

      --ty_bill.DELETE;   --del by lingyy 2015-01-15 放到过程最开始处执行,防止空单时调用不到。

      FOR i IN 1 .. so_data.COUNT
      LOOP
          /*add by lingyy 2014-11-4 增加接口日志表，调式使用，上线时，去掉此模块功能*/
         /* INSERT INTO BILL_DATA_INV_LOG(
              BILL_ID          , --业务单据头ID
              BILL_NUM         , --业务单据号
              LINE_ID          , --业务单据行ID
              LINE_DETAIL_ID   , --业务单据行明细ID
              ITEM_ID          , --产品ID
              ITEM_CODE        , --产品编码
              ITEM_NAME        , --产品名称
              ITEM_UOM         , --产品单位
              SRC_INV_ID       , --仓库ID（来源仓库）
              ITEM_QTY         , --数量
              CREATED_BY       , --操作人
              TARGET_INV_ID    , --目的仓库ID
              CREATE_DATE
           )
           VALUES(
              so_data(i).BILL_ID,
              so_data(i).BILL_NUM,
              so_data(i).LINE_ID,
              so_data(i).LINE_DETAIL_ID,
              so_data(i).ITEM_ID     ,
              so_data(i).ITEM_CODE    ,
              so_data(i).ITEM_NAME    ,
              so_data(i).ITEM_UOM     ,
              so_data(i).SRC_INV_ID   ,
              so_data(i).ITEM_QTY     ,
              so_data(i).CREATED_BY   ,
              so_data(i).TARGET_INV_ID,
              sysdate
           );
           */

         /*add end*/
         a                                   := a + 1;

         --检测返回的头ID是否正确
         IF in_business_header_id <> so_data (i).bill_id
         THEN
            on_flag      := -1;
            os_prompt    :=
                  '业务单据接口返回的头ID是：'
               || so_data (i).bill_id
               || ',与实际值：'
               || in_business_header_id
               || '不符';
            --rollback;
            RETURN;
         END IF;
         
         IF  so_data (i).src_inv_id is not null and nvl(so_data (i).src_inv_id,-1) =  nvl(so_data (i).target_inv_id,-1) THEN
              os_whether_same_inv := 'Y';
         END IF;

         ty_bill (a).header_id               := so_data (i).bill_id;                          --头ID
         ty_bill (a).line_id                 := so_data (i).line_id;                          --行ID
         ty_bill (a).line_detail_id          := so_data (i).line_detail_id;               --行明细ID
         ty_bill (a).item_id                 := so_data (i).item_id;
         ty_bill (a).item_code               := so_data (i).item_code;                      --产品ID
         ty_bill (a).item_name               := so_data (i).item_name;                    --产品编码
         ty_bill (a).transaction_uom         := so_data (i).item_uom;                         --单位
         ty_bill (a).inventory_id            := so_data (i).src_inv_id;                     --仓库ID

         ty_bill (a).terminal_entity_id      := so_data (i).src_terminal_entity_id;         --门店 20150724 gubr
	       ty_bill (a).terminal_code           := so_data (i).src_terminal_code;              --门店编码 20150724 gubr
	       ty_bill (a).terminal_name           := so_data (i).src_terminal_name;              --门店名称 20150724 gubr

          ty_bill (a).remark           := so_data (i).remark;
          ty_bill (a).original_bill_num           := so_data (i).original_bill_num;
         
         /*add by lingyy 2015-01-12 增加对产品是否是散件的校验*/
         vs_productform                      := NULL;

         BEGIN
            SELECT productform
              INTO vs_productform
              FROM t_bd_item
             WHERE item_id = so_data (i).item_id;
         EXCEPTION
            WHEN NO_DATA_FOUND
            THEN
               on_flag      := -1;
               os_prompt    := '产品表中不存在该产品(' || so_data (i).item_code || ')记录！';
               RETURN;
         END;

         IF vs_productform = 'SET_PRODUCT'                      --SET_PRODUCT 为套件标识，否则为散件
         THEN
            on_flag      := -1;
            os_prompt    := '产品(' || so_data (i).item_code || ')为套件！请核对单据！';
            RETURN;
         END IF;

         /*add end.*/

         --01 入库 ,02 出库 ,03 转移(第一条是出库，第二条是入库）
         SELECT DECODE (pkgs_action_type,
                        '01', so_data (i).item_qty,
                        '02', -so_data (i).item_qty,
                        '03', -so_data (i).item_qty
                       )
           INTO vn_transaction_quantity
           FROM DUAL;

           ty_bill (a).transaction_quantity    := vn_transaction_quantity;                      --数量
           ty_bill (a).created_by              := so_data (i).created_by;                     --操作人
           ty_bill (a).to_inventory_id         := so_data (i).target_inv_id;

         --目的仓库ID

         --转移时，需要多生成一条目的仓库的业务单据信息
         IF so_data (i).target_inv_id IS NOT NULL AND pkgs_action_type = '03'
         THEN
            a                                   := a + 1;
            ty_bill (a).header_id               := so_data (i).bill_id;                      --头ID
            ty_bill (a).line_id                 := so_data (i).line_id;                      --行ID
            ty_bill (a).line_detail_id          := so_data (i).line_detail_id;
            --行明细ID
            ty_bill (a).item_id                 := so_data (i).item_id;                    --产品ID
            ty_bill (a).item_code               := so_data (i).item_code;                --产品编码
            ty_bill (a).item_name               := so_data (i).item_name;                --产品名称
            ty_bill (a).transaction_uom         := so_data (i).item_uom;                     --单位
            ty_bill (a).inventory_id            := so_data (i).target_inv_id;              --仓库ID

	          ty_bill (a).terminal_entity_id      := so_data (i).target_terminal_entity_id;         --门店 20150724 gubr
	          ty_bill (a).terminal_code           := so_data (i).target_terminal_code;              --门店编码 20150724 gubr
	          ty_bill (a).terminal_name           := so_data (i).target_terminal_name;              --门店名称 20150724 gubr

            ty_bill (a).transaction_quantity    := -vn_transaction_quantity;
            --数量,目的仓库的数量转为正数
            ty_bill (a).created_by              := so_data (i).created_by;                 --操作人
            ty_bill (a).from_inventory_id       := so_data (i).src_inv_id;
             ty_bill (a).remark           := so_data (i).remark;
             ty_bill (a).original_bill_num           := so_data (i).original_bill_num;
            
         --源仓库ID
         END IF;
      END LOOP;
   EXCEPTION
      WHEN OTHERS
      THEN
         on_flag      := -1;
         os_prompt    := '调用init_p时发生异常！' || SUBSTR (SQLERRM, 1, 200);
         --rollback;
         RETURN;
   END init_p;

   PROCEDURE check_bill_info (
      in_entity_id             IN       t_inv_transaction_history.entity_id%TYPE,
      --经营主体ID
      is_business_state        IN       t_inv_transaction_history.business_state%TYPE,
      --单据状态
      id_transaction_date      IN       t_inv_transaction_history.transaction_date%TYPE,
      --业务日期
      in_source_type_id        IN       t_inv_bill_types.source_type_id%TYPE,
      --单据源类型ID
      in_transaction_type_id   IN       t_inv_bill_period_line.transaction_type_id%TYPE,
      --物料事务类型ID
      in_if_null               IN       NUMBER,                       --是否是空的业务单据，0否，1是
      on_flag                  OUT      NUMBER,
      os_prompt                OUT      VARCHAR2
   )
   AS
      vn_count1          NUMBER;
      vn_count2          NUMBER;
      vn_count3          NUMBER;
      vn_count4          NUMBER;
      vn_count5          NUMBER;
      vn_count6          NUMBER;
      vn_count7          NUMBER;
      vn_count8          NUMBER;
      vn_count_periods   NUMBER;                                         --add_by_lingyy 2014-10-31
      vs_status          t_inv_inventory_periods.status%TYPE;
   BEGIN
      on_flag      := 0;
      os_prompt    := '';

      --1、单据源类型是否存在、有效
      SELECT COUNT (*)
        INTO vn_count1
        FROM t_inv_source_types
       WHERE entity_id = in_entity_id
         AND source_type_id = in_source_type_id
         AND begin_date <= id_transaction_date
         AND (end_date >= id_transaction_date OR end_date IS NULL);

      IF vn_count1 = 0
      THEN
         on_flag      := -1;
         os_prompt    := '单据源类型(ID：' || in_source_type_id || ')不存在或已失效！';
         --rollback;
         RETURN;
      END IF;

      --2、物料事务类型是否存在、有效
      SELECT COUNT (*)
        INTO vn_count2
        FROM t_inv_transaction_types
       WHERE entity_id = in_entity_id
         AND transaction_type_id = in_transaction_type_id
         AND begin_date <= id_transaction_date
         AND (end_date >= id_transaction_date OR end_date IS NULL);

      IF vn_count2 = 0
      THEN
         on_flag      := -1;
         os_prompt    := '物料事务类型(ID：' || in_transaction_type_id || ')不存在或已失效';
         --rollback;
         RETURN;
      END IF;

      --3、业务日期是否落在一个存货会计期间，会计期间是否打开
      BEGIN
         /*add_by_lingyy 2014-10-31 增加对会计期间时间段是否存在，是否日期重复的校验*/
         SELECT COUNT (*)
           INTO vn_count_periods
           FROM t_inv_inventory_periods
          WHERE entity_id = pkgn_entity_id
            AND begin_date <= id_transaction_date
            AND (end_date >= id_transaction_date OR end_date IS NULL);

         IF vn_count_periods != 1
         THEN
            on_flag      := -1;
            os_prompt    :=
                  '业务日期('
               || TO_CHAR (id_transaction_date, 'YYYY-MM-DD')
               || ')对应的会计期间不存在，或存在开始时间/结束时间重复的会计期间！';
            --rollback;
            RETURN;
         END IF;

         /*add end*/
         SELECT period_id, status, period_name
           INTO pkgn_period_id, vs_status, pkgs_period_name
           FROM t_inv_inventory_periods
          WHERE entity_id = pkgn_entity_id
            AND begin_date <= id_transaction_date
            AND (end_date >= id_transaction_date OR end_date IS NULL);

         IF vs_status = '00'
         THEN
            on_flag      := -1;
            os_prompt    :=
                  '业务日期('
               || TO_CHAR (id_transaction_date, 'YYYY-MM-DD')
               || ')所在的会计期间已关闭！';
            --rollback;
            RETURN;
         END IF;
      EXCEPTION
         WHEN NO_DATA_FOUND
         THEN
            on_flag      := -1;
            os_prompt    :=
               '业务日期(' || TO_CHAR (id_transaction_date, 'YYYY-MM-DD')
               || ')未找到对应的会计期间';
            --rollback;
            RETURN;
      END;

      --4、单据周期是否存在、有效
      SELECT COUNT (*)
        INTO vn_count5
        FROM t_inv_bill_period_head
       WHERE entity_id = pkgn_entity_id
         AND bill_period_head_id = pkgn_head_id
         AND begin_date <= id_transaction_date
         AND (end_date >= id_transaction_date OR end_date IS NULL);

      IF vn_count5 = 0
      THEN
         on_flag      := -1;
         os_prompt    := '单据周期维护头表(ID：' || pkgn_head_id || ')不存在或已失效！';
         --rollback;
         RETURN;
      END IF;

      IF in_if_null = 0
      THEN                                                        --不是空业务单据时才检测产品、仓库
         --循环校验每条业务单据信息中的产品和仓库
         FOR i IN 1 .. ty_bill.COUNT
         LOOP
            --5、产品ID是否存在、有效
            SELECT COUNT (*)
              INTO vn_count3
              FROM t_bd_item
             WHERE item_id = ty_bill (i).item_id ;
         --    AND active_flag = 'Y';   update by guibr 去掉产品有效性

            IF vn_count3 = 0
            THEN
               on_flag      := -1;
               os_prompt    := '产品(编码：' || ty_bill (i).item_code || ')不存在！';
               --rollback;
               RETURN;
            END IF;

            --6、仓库ID是否存在、有效，转移的情况下，来源仓、目的仓都要校验
            SELECT COUNT (*)
              INTO vn_count4
              FROM t_inv_inventories
             WHERE inventory_id = ty_bill (i).inventory_id
               AND begin_date <= id_transaction_date
               AND (end_date >= id_transaction_date OR end_date IS NULL);

            IF vn_count4 = 0
            THEN
               on_flag      := -1;
               os_prompt    := '仓库(ID：' || ty_bill (i).inventory_id || ')不存在或已失效！';
               --rollback;
               RETURN;
            ELSE
               SELECT inventory_code, inventory_name
                 INTO ty_bill (i).inventory_code, ty_bill (i).inventory_name
                 FROM t_inv_inventories
                WHERE inventory_id = ty_bill (i).inventory_id
                  AND begin_date <= id_transaction_date
                  AND (end_date >= id_transaction_date OR end_date IS NULL);

               IF ty_bill (i).to_inventory_id IS NOT NULL
               THEN
                  SELECT COUNT (*)
                    INTO vn_count7
                    FROM t_inv_inventories
                   WHERE inventory_id = ty_bill (i).to_inventory_id
                     AND begin_date <= id_transaction_date
                     AND (end_date >= id_transaction_date OR end_date IS NULL);

                  IF vn_count7 = 0
                  THEN
                     on_flag      := -1;
                     os_prompt    :=
                                  '仓库(ID：' || ty_bill (i).to_inventory_id || ')不存在或已失效！';
                     --rollback;
                     RETURN;
                  ELSE
                     SELECT inventory_code, inventory_name
                       INTO ty_bill (i).to_inventory_code, ty_bill (i).to_inventory_name
                       FROM t_inv_inventories
                      WHERE inventory_id = ty_bill (i).to_inventory_id
                        AND begin_date <= id_transaction_date
                        AND (end_date >= id_transaction_date OR end_date IS NULL);

                     --add by lingyy 2015-01-02 增加对仓库是否相同的校验
                     IF ty_bill (i).inventory_id = ty_bill (i).to_inventory_id
                     THEN
                        on_flag      := -1;
                        os_prompt    :=
                              '来源仓库编码：'
                           || ty_bill (i).inventory_code
                           || '与目的仓库编码：'
                           || ty_bill (i).to_inventory_code
                           || '相同！';
                        --rollback;
                        RETURN;
                     END IF;
                  --add end.
                  END IF;
               ELSIF ty_bill (i).from_inventory_id IS NOT NULL
               THEN
                  SELECT COUNT (*)
                    INTO vn_count8
                    FROM t_inv_inventories
                   WHERE inventory_id = ty_bill (i).from_inventory_id
                     AND begin_date <= id_transaction_date
                     AND (end_date >= id_transaction_date OR end_date IS NULL);

                  IF vn_count8 = 0
                  THEN
                     on_flag      := -1;
                     os_prompt    :=
                                '仓库(ID：' || ty_bill (i).from_inventory_id || ')不存在或已失效！';
                     --rollback;
                     RETURN;
                  ELSE
                     SELECT inventory_code, inventory_name
                       INTO ty_bill (i).from_inventory_code, ty_bill (i).from_inventory_name
                       FROM t_inv_inventories
                      WHERE inventory_id = ty_bill (i).from_inventory_id
                        AND begin_date <= id_transaction_date
                        AND (end_date >= id_transaction_date OR end_date IS NULL);

                     --add by lingyy 2015-01-02 增加对仓库是否相同的校验
                     IF ty_bill (i).inventory_id = ty_bill (i).from_inventory_id
                     THEN
                        on_flag      := -1;
                        os_prompt    :=
                              '目的仓库编码：'
                           || ty_bill (i).inventory_code
                           || '与来源仓库编码：'
                           || ty_bill (i).from_inventory_code
                           || '相同！';
                        --rollback;
                        RETURN;
                     END IF;
                  --add end.
                  END IF;
               END IF;
            END IF;
         END LOOP;
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         on_flag      := -1;
         os_prompt    := '调用check_bill_info时发生异常！' || SUBSTR (SQLERRM, 1, 200);
         --rollback;
         RETURN;
   END check_bill_info;
   
       --写物料事务历史前检查负库存
   PROCEDURE inv_transaction_onhand_check(
        in_if_null                IN     NUMBER,--是否是空的业务单据，0否，1是
        id_transaction_date       IN       t_inv_transaction_history.transaction_date%TYPE,
        on_flag                   OUT    NUMBER,
        os_prompt                 OUT    VARCHAR2
   ) AS
      CURSOR get_transaction_history
        IS                                                       --上次业务单据有值，本次业务单据为空
           SELECT   business_line_id, business_line_detail_id, inventory_id, item_id,
                    SUM (transaction_quantity) transaction_quantity
               FROM t_inv_transaction_history
              WHERE entity_id = pkgn_entity_id
                AND business_state = pkgs_business_state
                AND bill_type_id = pkgn_bill_type_id
                AND business_header_id = pkgn_business_header_id
           GROUP BY business_line_id, business_line_detail_id, inventory_id, item_id
             HAVING SUM (transaction_quantity) <> 0;

      c_get_history               get_transaction_history%ROWTYPE; 
      onhand_bill                 ty_bill_tab;   
      v_serial_number             number;
      v_serial_index              number;
   BEGIN
        on_flag              := 0;
        os_prompt            := '';
        IF pkgn_if_his = 0 THEN 
               IF in_if_null = 0 THEN 
                     FOR i IN 1 .. ty_bill.COUNT LOOP
                         inv_transaction_negative(
                                in_if_null
                               ,id_transaction_date
                               ,ty_bill (i).inventory_id
                               ,ty_bill (i).item_id
                               ,ty_bill (i).transaction_quantity
                               ,on_flag
                               ,os_prompt
                        );
                        IF on_flag = -1 THEN
                           return;
                        END IF;
                     END LOOP;
               END IF;
        ELSIF pkgn_if_his = 1 THEN
             IF in_if_null = 1 THEN
                 FOR c_get_history IN get_transaction_history LOOP
                        inv_transaction_negative(
                                in_if_null
                               ,id_transaction_date
                               ,c_get_history.inventory_id
                               ,c_get_history.item_id
                               ,-1*c_get_history.transaction_quantity 
                               ,on_flag
                               ,os_prompt
                        );
                        IF on_flag = -1 THEN
                           return;
                        END IF; 
                 END LOOP;    
             ELSE
                v_serial_number :=0;
                FOR c_get_history IN get_transaction_history LOOP  
                    v_serial_number := v_serial_number + 1;
                    onhand_bill (v_serial_number).item_id := c_get_history.item_id;
                    onhand_bill (v_serial_number).inventory_id := c_get_history.inventory_id;
                    onhand_bill (v_serial_number).line_id := c_get_history.business_line_id;
                    onhand_bill (v_serial_number).line_detail_id := c_get_history.business_line_detail_id;
                    onhand_bill (v_serial_number).transaction_quantity := c_get_history.transaction_quantity;
                END LOOP;   
             
                FOR i IN 1 .. ty_bill.COUNT LOOP    
                       v_serial_index := 0;
                       FOR j IN 1 .. onhand_bill.COUNT LOOP
                          IF      onhand_bill (j).item_id = ty_bill (i).item_id 
                             and  onhand_bill (j).inventory_id = ty_bill (i).inventory_id 
                             and  onhand_bill (j).line_id = ty_bill (i).line_id 
                             and  nvl(onhand_bill (j).line_detail_id,-1) = nvl(ty_bill (i).line_detail_id,-1)
                          then     
                              v_serial_index := j;
                              EXIT;
                          END IF;    
                        END LOOP;  
                        IF v_serial_index = 0 then
                             inv_transaction_negative(
                                    in_if_null
                                   ,id_transaction_date
                                   ,ty_bill (i).inventory_id
                                   ,ty_bill (i).item_id
                                   ,ty_bill (i).transaction_quantity
                                   ,on_flag
                                   ,os_prompt
                            );
                            IF on_flag = -1 THEN
                               return;
                            END IF;
                        ELSE
                            inv_transaction_negative(
                                    in_if_null
                                   ,id_transaction_date
                                   ,ty_bill (i).inventory_id
                                   ,ty_bill (i).item_id
                                   ,(ty_bill (i).transaction_quantity - onhand_bill (v_serial_index).transaction_quantity)
                                   ,on_flag
                                   ,os_prompt
                            );
                            IF on_flag = -1 THEN
                               return;
                            END IF;
                        END IF; 
                END LOOP;
                
                FOR j IN 1 .. onhand_bill.COUNT LOOP
                       v_serial_index := 0;
                       FOR i IN 1 .. ty_bill.COUNT LOOP    
                          IF      onhand_bill (j).item_id = ty_bill (i).item_id 
                             and  onhand_bill (j).inventory_id = ty_bill (i).inventory_id 
                             and  onhand_bill (j).line_id = ty_bill (i).line_id 
                             and  nvl(onhand_bill (j).line_detail_id,-1) = nvl(ty_bill (i).line_detail_id,-1)
                          then     
                              v_serial_index := j;
                              EXIT;
                          END IF;
                        END LOOP;
                        IF v_serial_index = 0 then
                            inv_transaction_negative(
                                    in_if_null
                                   ,id_transaction_date
                                   ,onhand_bill (j).inventory_id
                                   ,onhand_bill (j).item_id
                                   ,-1*onhand_bill (j).transaction_quantity
                                   ,on_flag
                                   ,os_prompt
                            );
                            IF on_flag = -1 THEN
                               return;
                            END IF;
                        END IF;
                END LOOP;
                
             END IF;
        END IF;  
   EXCEPTION
      WHEN OTHERS THEN
         on_flag      := -1;
         os_prompt    := '调用inv_transaction_onhand_check时发生异常！' || SUBSTR (SQLERRM, 1, 200);
        RETURN;     
  END inv_transaction_onhand_check; 
  
  
      --写物料事务历史前检查负库存
   PROCEDURE inv_transaction_negative(
        in_if_null                IN     NUMBER,--是否是空的业务单据，0否，1是
        id_transaction_date       IN       t_inv_transaction_history.transaction_date%TYPE,
        in_inventory_id           IN     NUMBER,
        in_item_id                IN     NUMBER,
        in_quantity               IN     NUMBER,
        on_flag                   OUT    NUMBER,
        os_prompt                 OUT    VARCHAR2
    )
    AS 
          vs_inv_flag         t_inv_inventories.negative_inventory_flag%TYPE;
          vn_count            NUMBER;
          vn_quantity         NUMBER;
          V_INVENTORY_CODE    T_INV_INVENTORIES.INVENTORY_CODE%TYPE;  --仓库编码
          V_ITEM_CODE         T_BD_ITEM.ITEM_CODE%TYPE;               --产品编码
    BEGIN 
      on_flag              := 0;
      os_prompt            := '';    
      IF in_quantity < 0 THEN 
           SELECT negative_inventory_flag
            INTO vs_inv_flag
            FROM t_inv_inventories
           WHERE inventory_id = in_inventory_id
             AND begin_date <= id_transaction_date
             AND (end_date >= id_transaction_date OR end_date IS NULL);  
      
          SELECT COUNT (*)
            INTO vn_count
            FROM t_inv_onhand
           WHERE entity_id = pkgn_entity_id
             AND inventory_id = in_inventory_id
             AND item_id = in_item_id;        
         IF pkgs_bill_type_flag = 'N' AND vs_inv_flag = 'N' THEN  
              IF vn_count = 0 THEN
                 -- 根据仓库ID、产品ID获取仓库编码、产品编码，以便完善错误提示信息，方便业务查找。modify by zhoujg3 2-15-07-06   [begin]
                  SELECT I.INVENTORY_CODE INTO V_INVENTORY_CODE FROM T_INV_INVENTORIES I WHERE I.INVENTORY_ID = in_inventory_id;
                  SELECT I.ITEM_CODE INTO V_ITEM_CODE FROM T_BD_ITEM I WHERE I.ITEM_ID = in_item_id;
                  on_flag      := -1;
                  os_prompt    :=
                          '更新库存现有量异常：经营主体(ID:'
                       || pkgn_entity_id
                       || ');仓库(ID:'
                       || in_inventory_id
                       || ',仓库编码:'
                       || V_INVENTORY_CODE
                       || ');产品(ID:'
                       || in_item_id
                       || ',产品编码:'
                       || V_ITEM_CODE
                       || ')的库存现有量不足！(库存：0,单据需求：'
                       ||in_quantity
                       ||')'; 
                     return;  
               ELSE 
                    SELECT   quantity
                     INTO vn_quantity
                     FROM t_inv_onhand
                    WHERE entity_id = pkgn_entity_id
                      AND inventory_id = in_inventory_id
                      AND item_id = in_item_id
                    FOR UPDATE;   
                   vn_quantity    := vn_quantity + in_quantity;  
                   
                    IF vn_quantity < 0 THEN 
                       -- 根据仓库ID、产品ID获取仓库编码、产品编码，以便完善错误提示信息，方便业务查找。modify by zhoujg3 2-15-07-06   [begin]
                        SELECT I.INVENTORY_CODE INTO V_INVENTORY_CODE FROM T_INV_INVENTORIES I WHERE I.INVENTORY_ID = in_inventory_id;
                        SELECT I.ITEM_CODE INTO V_ITEM_CODE FROM T_BD_ITEM I WHERE I.ITEM_ID = in_item_id;
                        on_flag      := -1;
                        os_prompt    :=
                                '更新库存现有量异常：经营主体(ID:'
                             || pkgn_entity_id
                             || ');仓库(ID:'
                             || in_inventory_id
                             || ',仓库编码:'
                             || V_INVENTORY_CODE
                             || ');产品(ID:'
                             || in_item_id
                             || ',产品编码:'
                             || V_ITEM_CODE
                             || ')的库存现有量不足！(库存：0,单据需求：'
                             ||in_quantity
                             ||')'; 
                         return;  
                     END IF;
               END IF; 
         END IF;  
      END IF;              
   END;

--写物料事务历史
   PROCEDURE inv_transaction_deal (
      in_if_null   IN       NUMBER,                                   --是否是空的业务单据，0否，1是
      on_flag      OUT      NUMBER,
      os_prompt    OUT      VARCHAR2
   )
   AS
      vs_new                      VARCHAR2 (1000);
      vs_same                     VARCHAR2 (1000);
      vn_history_id               NUMBER;
      vn_count1                   NUMBER;
      vn_quantity                 NUMBER;
      vn_transaction_id           t_inv_transaction_history.transaction_id%TYPE;
      vs_transaction_id           VARCHAR2 (1000);
      vs_line_id                  VARCHAR2 (1000);
      vs_line_detail_id           VARCHAR2 (1000);
      v_business_line_id          t_inv_transaction_history.business_line_id%TYPE;
      v_business_line_detail_id   t_inv_transaction_history.business_line_detail_id%TYPE;
      v_item_id                   t_inv_transaction_history.item_id%TYPE;
      v_inventory_id              t_inv_transaction_history.inventory_id%TYPE;
      v_transaction_quantity      t_inv_transaction_history.transaction_quantity%TYPE;
      v_transaction_id            t_inv_transaction_history.transaction_id%TYPE;
      vs_same_str                 CLOB;
      vs_id                       VARCHAR2 (1000);

      TYPE mycur IS REF CURSOR;

      v_cur                       mycur;
      v_sql                       CLOB;

      TYPE cur IS REF CURSOR;

      v_id_cur                    cur;
      v_id_sql                    CLOB;
      vn_ty_detail_id             t_inv_transaction_history.business_line_detail_id%TYPE;

      CURSOR get_transaction_history
      IS                                                       --上次业务单据有值，本次业务单据为空
         SELECT   business_line_id, business_line_detail_id, inventory_id, item_id,
                  SUM (transaction_quantity) transaction_quantity
             FROM t_inv_transaction_history
            WHERE entity_id = pkgn_entity_id
              AND business_state = pkgs_business_state
              AND bill_type_id = pkgn_bill_type_id
              AND business_header_id = pkgn_business_header_id
         GROUP BY business_line_id, business_line_detail_id, inventory_id, item_id
           HAVING SUM (transaction_quantity) <> 0;

      c_get_history               get_transaction_history%ROWTYPE;
   BEGIN
      on_flag              := 0;
      os_prompt            := '';
      vs_line_id           := '';
      vs_line_detail_id    := '';
      vs_transaction_id    := '';
      pkgs_new_str         := '';

      IF pkgn_if_his = 0
      THEN                                 --第一次调物料事物 或者 上次调物料事物处理时业务单据为空
         --in_if_null = 1是，上次和本次业务单据为空，不做处理
         IF in_if_null = 0
         THEN                                          --上次业务单据为空，本次不为空，做insert操作
            FOR i IN 1 .. ty_bill.COUNT
            LOOP
               vn_history_id    := s_inv_transaction_history.NEXTVAL;
               IF ty_bill (i).remark IS NOT NULL THEN
                  ty_bill (i).remark := substr(ty_bill (i).remark,1,300);
               END IF;   
               INSERT INTO t_inv_transaction_history
                           (entity_id, transaction_id, transaction_date, period_id,
                            period_name, source_type_id, business_state,
                            transaction_type_id, action_type, business_header_id,
                            business_line_id, business_line_detail_id, item_id,
                            item_code, item_name,
                            transaction_uom, inventory_id,
                            inventory_code, inventory_name,
                            to_inventory_id, to_inventory_code,
                            to_inventory_name, from_inventory_id,
                            from_inventory_code, from_inventory_name,
                            transaction_quantity, created_by,
                            creation_date, last_updated_by, last_update_date, remark,
                            bill_type_id, business_num,terminal_entity_id,terminal_code,terminal_name
                           ,ORIGINAL_BILL_NUM
                           )
                    VALUES (pkgn_entity_id, vn_history_id, pkgd_transaction_date, pkgn_period_id,
                            pkgs_period_name, pkgn_source_type_id, pkgs_business_state,
                            pkgn_transaction_type_id, pkgs_action_type, ty_bill (i).header_id,
                            ty_bill (i).line_id, ty_bill (i).line_detail_id, ty_bill (i).item_id,
                            ty_bill (i).item_code, ty_bill (i).item_name,
                            ty_bill (i).transaction_uom, ty_bill (i).inventory_id,
                            ty_bill (i).inventory_code, ty_bill (i).inventory_name,
                            ty_bill (i).to_inventory_id, ty_bill (i).to_inventory_code,
                            ty_bill (i).to_inventory_name, ty_bill (i).from_inventory_id,
                            ty_bill (i).from_inventory_code, ty_bill (i).from_inventory_name,
                            ty_bill (i).transaction_quantity, ty_bill (i).created_by,
                            pkgd_sysdate,
                                         /*update by lingyy 2014-11-26 对修改人/修改时间赋值*/
                                         --null,null,
                                         ty_bill (i).created_by, pkgd_sysdate,
                                                                              /*update end*/
                            ty_bill (i).remark,
                            pkgn_bill_type_id, pkgs_business_num,
			                      ty_bill (i).terminal_entity_id,ty_bill (i).terminal_code,ty_bill (i).terminal_name
                           ,ty_bill (i).original_bill_num
                           );

               SELECT TO_CHAR (vn_history_id)
                 INTO vs_new
                 FROM DUAL;

               IF pkgs_new_str IS NULL
               THEN
                  pkgs_new_str    := vs_new;
               ELSE
                  pkgs_new_str    := vs_new || ',' || pkgs_new_str;
               END IF;
            END LOOP;
         END IF;
      ELSIF pkgn_if_his = 1
      THEN                                                        --上次调物料事物处理时业务单据有值
         IF in_if_null = 1
         THEN                                                                    --本次业务单据为空
            FOR c_get_history IN get_transaction_history
            LOOP
               vn_history_id    := s_inv_transaction_history.NEXTVAL;

               --取当前最近的行明细ID
               INSERT INTO t_inv_transaction_history
                           (entity_id, transaction_id, transaction_date, period_id, period_name,
                            source_type_id, business_state, transaction_type_id, action_type,
                            business_header_id, business_line_id, business_line_detail_id, item_id,
                            item_code, item_name, transaction_uom, inventory_id, inventory_code,
                            inventory_name, to_inventory_id, to_inventory_code, to_inventory_name,
                            from_inventory_id, from_inventory_code, from_inventory_name,
                            transaction_quantity, created_by, creation_date, last_updated_by,
                            last_update_date, remark, bill_type_id, business_num ,terminal_entity_id,terminal_code,terminal_name,original_bill_num)
                  SELECT pkgn_entity_id, vn_history_id, transaction_date, period_id, period_name,
                         source_type_id, pkgs_business_state, transaction_type_id, action_type,
                         business_header_id, business_line_id, business_line_detail_id, item_id,
                         item_code, item_name, transaction_uom, inventory_id, inventory_code,
                         inventory_name, to_inventory_id, to_inventory_code, to_inventory_name,
                         from_inventory_id, from_inventory_code, from_inventory_name,
                         c_get_history.transaction_quantity * (-1), created_by, pkgd_sysdate,

                         /*update by lingyy 2014-11-26 对修改人/修改时间赋值*/
                         --null,null,
                         last_updated_by, pkgd_sysdate,
                                                       /*update end*/
                         remark, pkgn_bill_type_id,
                                                 --pkgs_business_num, del by lingyy 2014-10-27 业务单据为空时，该全局变量不会被赋值，这里直接用表中的businesss_num代替即可。
                                                 business_num            --add by lingyy 2014-10-27
			                  ,terminal_entity_id,terminal_code,terminal_name,original_bill_num   --add by guibr 20150724
                    FROM t_inv_transaction_history
                   WHERE entity_id = pkgn_entity_id
                     AND business_state = pkgs_business_state
                     AND bill_type_id = pkgn_bill_type_id
                     AND business_header_id = pkgn_business_header_id
                     AND business_line_id = c_get_history.business_line_id
                     AND NVL (business_line_detail_id, -1) =
                                                      NVL (c_get_history.business_line_detail_id,
                                                           -1)
                     AND item_id = c_get_history.item_id
                     AND inventory_id = c_get_history.inventory_id
                     AND ROWNUM = 1;

               SELECT TO_CHAR (vn_history_id)
                 INTO vs_new
                 FROM DUAL;

               IF pkgs_new_str IS NULL
               THEN
                  pkgs_new_str    := vs_new;
               ELSE
                  pkgs_new_str    := vs_new || ',' || pkgs_new_str;
               END IF;
            END LOOP;
         ELSIF in_if_null = 0
         THEN                                                                     --本次业务单据有值
            FOR i IN 1 .. ty_bill.COUNT
            LOOP                             --用本次业务单据和历史表作比较。比对，到行明细ID一级。
               SELECT NVL (SUM (transaction_quantity), -1), NVL (MAX (transaction_id), -1)
                 INTO vn_quantity, vn_transaction_id
                 FROM t_inv_transaction_history
                WHERE entity_id = pkgn_entity_id
                  AND business_state = pkgs_business_state
                  AND bill_type_id = pkgn_bill_type_id
                  AND business_header_id = pkgn_business_header_id
                  AND business_line_id = ty_bill (i).line_id
                  AND NVL (business_line_detail_id, -1) = NVL (ty_bill (i).line_detail_id, -1)
                  AND inventory_id = ty_bill (i).inventory_id
                  AND item_id = ty_bill (i).item_id;

               /*update by lingyy 2014-11-13 vn_quantity为-1时，可能是新增记录，也可能数量就是-1，所以不能用该变量判断是否为新增记录
                                              改由vn_transaction_id判断，因为该ID正常情况不能为-1，只有新增记录时，该字段才能为-1*/
               --if vn_quantity = -1 then--本次业务单据新增的数据
               IF vn_transaction_id = -1
               THEN                                                         --本次业务单据新增的数据
                  /*update end.*/
                  ty_bill (i).oper_kind    := 1;
               ELSE                                                   --本次业务单据中有，历史表中有
                  IF ty_bill (i).transaction_quantity = vn_quantity
                  THEN                                                       --两者数据中的数量相同
                     ty_bill (i).oper_kind    := 0;                           --0不变；1增加；2修改
                  ELSE
                     ty_bill (i).oper_kind    := 2;
                  END IF;

                  SELECT NVL (ty_bill (i).line_detail_id, -1)
                    INTO vn_ty_detail_id
                    FROM DUAL;

                  v_id_sql    :=
                        'select transaction_id from t_inv_transaction_history
                        where entity_id = '
                     || pkgn_entity_id
                     || ' and business_state = '''
                     || pkgs_business_state
                     || ''' and bill_type_id = '
                     || pkgn_bill_type_id
                     || 'and business_header_id = '
                     || pkgn_business_header_id
                     || ' and business_line_id = '
                     || ty_bill (i).line_id
                     || 'and nvl(business_line_detail_id,-1) = nvl('
                     || vn_ty_detail_id
                     || ',-1)
                        and inventory_id = '
                     || ty_bill (i).inventory_id
                     || ' and item_id = '
                     || ty_bill (i).item_id;

                  OPEN v_id_cur FOR v_id_sql;

                  LOOP
                     FETCH v_id_cur
                      INTO v_transaction_id;

                     EXIT WHEN v_id_cur%NOTFOUND;

                     SELECT TO_CHAR (v_transaction_id)
                       INTO vs_id
                       FROM DUAL;

                     IF vs_same_str IS NULL
                     THEN
                        vs_same_str    := vs_id;
                     ELSE
                        vs_same_str    := vs_id || ',' || vs_same_str;
                     END IF;
                  END LOOP;

                  CLOSE v_id_cur;
               END IF;
            END LOOP;

            IF vs_same_str IS NULL
            THEN
               vs_same_str    := '0';
            END IF;

            --历史表中有，本次业务单据中没有的，直接红冲。比对，到行明细ID一级。
            v_sql    :=
                  'select business_line_id,business_line_detail_id,inventory_id,item_id,sum(transaction_quantity) transaction_quantity
                    from t_inv_transaction_history
                    where entity_id = '
               || pkgn_entity_id
               || ' and business_state = '''
               || pkgs_business_state
               || ''' and bill_type_id = '
               || pkgn_bill_type_id
               || '
                    and business_header_id = '
               || pkgn_business_header_id
               || '
                    and transaction_id not in ('
               || vs_same_str
               || ')
                    group by business_line_id,business_line_detail_id,inventory_id,item_id
                    having sum(transaction_quantity)<>0';

            OPEN v_cur FOR v_sql;

            LOOP
               FETCH v_cur
                INTO v_business_line_id, v_business_line_detail_id, v_item_id, v_inventory_id,
                     v_transaction_quantity;

               EXIT WHEN v_cur%NOTFOUND;
               vn_history_id    := s_inv_transaction_history.NEXTVAL;

               INSERT INTO t_inv_transaction_history
                           (entity_id, transaction_id, transaction_date, period_id, period_name,
                            source_type_id, business_state, transaction_type_id, action_type,
                            business_header_id, business_line_id, business_line_detail_id, item_id,
                            item_code, item_name, transaction_uom, inventory_id, inventory_code,
                            inventory_name, to_inventory_id, to_inventory_code, to_inventory_name,
                            from_inventory_id, from_inventory_code, from_inventory_name,
                            transaction_quantity, created_by, creation_date, last_updated_by,
                            last_update_date, remark, bill_type_id, business_num ,terminal_entity_id,terminal_code,terminal_name,original_bill_num)
                  SELECT entity_id, vn_history_id, transaction_date, period_id, period_name,
                         source_type_id, business_state, transaction_type_id, action_type,
                         business_header_id, business_line_id, business_line_detail_id, item_id,
                         item_code, item_name, transaction_uom, inventory_id, inventory_code,
                         inventory_name, to_inventory_id, to_inventory_code, to_inventory_name,
                         from_inventory_id, from_inventory_code, from_inventory_name,
                         v_transaction_quantity * (-1), created_by, creation_date, last_updated_by,
                         last_update_date, remark, bill_type_id, business_num ,terminal_entity_id,terminal_code,terminal_name,original_bill_num
                    FROM t_inv_transaction_history
                   WHERE entity_id = pkgn_entity_id
                     AND business_state = pkgs_business_state
                     AND bill_type_id = pkgn_bill_type_id
                     AND business_header_id = pkgn_business_header_id
                     AND business_line_id = v_business_line_id
                     AND NVL (business_line_detail_id, -1) = NVL (v_business_line_detail_id, -1)
                     AND inventory_id = v_inventory_id
                     AND item_id = v_item_id
                     AND ROWNUM = 1;

               SELECT TO_CHAR (vn_history_id)
                 INTO vs_new
                 FROM DUAL;

               IF pkgs_new_str IS NULL
               THEN
                  pkgs_new_str    := vs_new;
               ELSE
                  pkgs_new_str    := vs_new || ',' || pkgs_new_str;
               END IF;
            END LOOP;

            CLOSE v_cur;

            FOR i IN 1 .. ty_bill.COUNT
            LOOP                              --根据oper_kind--0不变；1增加；2修改，处理本次业务单据
               IF ty_bill (i).oper_kind = 1
               THEN
                  vn_history_id    := s_inv_transaction_history.NEXTVAL;
                  
                  IF ty_bill (i).remark IS NOT NULL THEN
                     ty_bill (i).remark := substr(ty_bill (i).remark,1,300);
                  END IF;

                  INSERT INTO t_inv_transaction_history
                              (entity_id, transaction_id, transaction_date,
                               period_id, period_name, source_type_id,
                               business_state, transaction_type_id, action_type,
                               business_header_id, business_line_id,
                               business_line_detail_id, item_id,
                               item_code, item_name,
                               transaction_uom, inventory_id,
                               inventory_code, inventory_name,
                               to_inventory_id, to_inventory_code,
                               to_inventory_name, from_inventory_id,
                               from_inventory_code, from_inventory_name,
                               transaction_quantity, created_by,
                               creation_date, last_updated_by, last_update_date, remark,
                               bill_type_id, business_num ,terminal_entity_id,terminal_code,terminal_name,original_bill_num
                              )
                       VALUES (pkgn_entity_id, vn_history_id, pkgd_transaction_date,
                               pkgn_period_id, pkgs_period_name, pkgn_source_type_id,
                               pkgs_business_state, pkgn_transaction_type_id, pkgs_action_type,
                               ty_bill (i).header_id, ty_bill (i).line_id,
                               ty_bill (i).line_detail_id, ty_bill (i).item_id,
                               ty_bill (i).item_code, ty_bill (i).item_name,
                               ty_bill (i).transaction_uom, ty_bill (i).inventory_id,
                               ty_bill (i).inventory_code, ty_bill (i).inventory_name,
                               ty_bill (i).to_inventory_id, ty_bill (i).to_inventory_code,
                               ty_bill (i).to_inventory_name, ty_bill (i).from_inventory_id,
                               ty_bill (i).from_inventory_code, ty_bill (i).from_inventory_name,
                               ty_bill (i).transaction_quantity, ty_bill (i).created_by,
                               pkgd_sysdate,
                                            /*update by lingyy 2014-11-26 对修改人/修改时间赋值*/
                                            --null,null,
                                            ty_bill (i).created_by, pkgd_sysdate,
                                                                                 /*update end*/
                               ty_bill (i).remark,
                               pkgn_bill_type_id, pkgs_business_num
			                        ,ty_bill (i).terminal_entity_id,ty_bill (i).terminal_code,ty_bill (i).terminal_name --add by guibr 20150724
                              ,ty_bill (i).original_bill_num
                              );

                  SELECT TO_CHAR (vn_history_id)
                    INTO vs_new
                    FROM DUAL;

                  IF pkgs_new_str IS NULL
                  THEN
                     pkgs_new_str    := vs_new;
                  ELSE
                     pkgs_new_str    := vs_new || ',' || pkgs_new_str;
                  END IF;
               ELSIF ty_bill (i).oper_kind = 2
               THEN
                  vn_history_id    := s_inv_transaction_history.NEXTVAL;

                  SELECT SUM (transaction_quantity)
                    INTO vn_quantity
                    FROM t_inv_transaction_history
                   WHERE entity_id = pkgn_entity_id
                     AND business_state = pkgs_business_state
                     AND bill_type_id = pkgn_bill_type_id
                     AND business_header_id = pkgn_business_header_id
                     AND business_line_id = ty_bill (i).line_id
                     AND NVL (business_line_detail_id, -1) = NVL (ty_bill (i).line_detail_id, -1)
                     AND inventory_id = ty_bill (i).inventory_id
                     AND item_id = ty_bill (i).item_id;
                     
                 IF ty_bill (i).remark IS NOT NULL THEN
                     ty_bill (i).remark := substr(ty_bill (i).remark,1,300);
                  END IF;

                  INSERT INTO t_inv_transaction_history
                              (entity_id, transaction_id, transaction_date,
                               period_id, period_name, source_type_id,
                               business_state, transaction_type_id, action_type,
                               business_header_id, business_line_id,
                               business_line_detail_id, item_id,
                               item_code, item_name,
                               transaction_uom, inventory_id,
                               inventory_code, inventory_name,
                               to_inventory_id, to_inventory_code,
                               to_inventory_name, from_inventory_id,
                               from_inventory_code, from_inventory_name,
                               transaction_quantity,
                               created_by, creation_date, last_updated_by,
                               last_update_date, remark, bill_type_id, business_num,terminal_entity_id,terminal_code,terminal_name,original_bill_num
                              )
                       VALUES (pkgn_entity_id, vn_history_id, pkgd_transaction_date,
                               pkgn_period_id, pkgs_period_name, pkgn_source_type_id,
                               pkgs_business_state, pkgn_transaction_type_id, pkgs_action_type,
                               ty_bill (i).header_id, ty_bill (i).line_id,
                               ty_bill (i).line_detail_id, ty_bill (i).item_id,
                               ty_bill (i).item_code, ty_bill (i).item_name,
                               ty_bill (i).transaction_uom, ty_bill (i).inventory_id,
                               ty_bill (i).inventory_code, ty_bill (i).inventory_name,
                               ty_bill (i).to_inventory_id, ty_bill (i).to_inventory_code,
                               ty_bill (i).to_inventory_name, ty_bill (i).from_inventory_id,
                               ty_bill (i).from_inventory_code, ty_bill (i).from_inventory_name,
                               ty_bill (i).transaction_quantity - vn_quantity,
                               ty_bill (i).created_by, pkgd_sysdate,
                                                                    /*update by lingyy 2014-11-26 对修改人/修改时间赋值*/
                                                                    --null,null,
                                                                    ty_bill (i).created_by,
                               pkgd_sysdate,
                                            /*update end*/
                               ty_bill (i).remark, pkgn_bill_type_id, pkgs_business_num
			                         ,ty_bill (i).terminal_entity_id,ty_bill (i).terminal_code,ty_bill (i).terminal_name,ty_bill (i).original_bill_num
                              );

                  SELECT TO_CHAR (vn_history_id)
                    INTO vs_new
                    FROM DUAL;

                  IF pkgs_new_str IS NULL
                  THEN
                     pkgs_new_str    := vs_new;
                  ELSE
                     pkgs_new_str    := vs_new || ',' || pkgs_new_str;
                  END IF;
               END IF;
            END LOOP;
         END IF;
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         on_flag      := -1;
         os_prompt    := '调用inv_transaction_deal时发生异常！' || SUBSTR (SQLERRM, 1, 200);
         --rollback;
         RETURN;
   END inv_transaction_deal;

   PROCEDURE inv_bill_history_check (
      on_flag     OUT   NUMBER,
      os_prompt   OUT   VARCHAR2,
      on_if_dif   OUT   NUMBER                                                         --0不同;1相同
   )
   AS
      vn_quantity_his              NUMBER;
      vn_history_id                t_inv_transaction_history.transaction_id%TYPE;
      vs_id                        VARCHAR2 (1000);
      vs_new                       VARCHAR2 (1000);
      vs_transaction_id            CLOB;
      vs_line_id                   VARCHAR2 (1000);

      TYPE mycur IS REF CURSOR;

      v_cur                        mycur;
      v_sql                        CLOB;
      v_business_header_id         t_inv_transaction_history.business_header_id%TYPE;
      v_business_line_id           t_inv_transaction_history.business_line_id%TYPE;
      v_business_line_detail_id    t_inv_transaction_history.business_line_detail_id%TYPE;
      v_inventory_id               t_inv_transaction_history.inventory_id%TYPE;
      v_item_id                    t_inv_transaction_history.item_id%TYPE;
      v_transaction_quantity       t_inv_transaction_history.transaction_quantity%TYPE;
      vn_bill_inventory_id         NUMBER;
      vn_bill_item_id              NUMBER;
      vn_business_line_id          t_inv_transaction_history.business_line_id%TYPE;
      vn_business_line_detail_id   t_inv_transaction_history.business_line_detail_id%TYPE;
      vn_detail_id                 t_inv_transaction_history.business_line_detail_id%TYPE;

      CURSOR get_transaction_id
      IS
         SELECT *
           FROM t_inv_transaction_history
          WHERE entity_id = pkgn_entity_id
            AND business_state = pkgs_business_state
            AND bill_type_id = pkgn_bill_type_id
            AND business_header_id = pkgn_business_header_id
            AND business_line_id = vn_business_line_id
            AND NVL (business_line_detail_id, -1) = NVL (vn_business_line_detail_id, -1)
            AND inventory_id = vn_bill_inventory_id
            AND item_id = vn_bill_item_id;

      c_get_id                     get_transaction_id%ROWTYPE;
   BEGIN
      on_flag              := 0;
      os_prompt            := '';
      vs_transaction_id    := '';
      on_if_dif            := 1;                                                 --默认比对结果相同

      --用业务单据和物料事务历史信息比对
      FOR i IN 1 .. ty_bill.COUNT
      LOOP
         SELECT SUM (transaction_quantity)
           INTO vn_quantity_his
           FROM t_inv_transaction_history
          WHERE entity_id = pkgn_entity_id
            AND business_state = pkgs_business_state
            AND bill_type_id = pkgn_bill_type_id
            AND business_header_id = pkgn_business_header_id
            AND business_line_id = ty_bill (i).line_id
            AND NVL (business_line_detail_id, -1) = NVL (ty_bill (i).line_detail_id, -1)
            AND inventory_id = ty_bill (i).inventory_id
            AND item_id = ty_bill (i).item_id;

         IF ty_bill (i).transaction_quantity <> vn_quantity_his
         THEN
            vn_history_id    := s_inv_transaction_history.NEXTVAL;
            
            IF ty_bill (i).remark IS NOT NULL THEN
                  ty_bill (i).remark := substr(ty_bill (i).remark,1,300);
             END IF;

            --如果不同，增加一条差额的历史记录
            INSERT INTO t_inv_transaction_history
                        (entity_id, transaction_id, transaction_date, period_id,
                         period_name, source_type_id, business_state,
                         transaction_type_id, action_type, business_header_id,
                         business_line_id, business_line_detail_id, item_id,
                         item_code, item_name,
                         transaction_uom, inventory_id,
                         inventory_code, inventory_name,
                         to_inventory_id, to_inventory_code,
                         to_inventory_name, from_inventory_id,
                         from_inventory_code, from_inventory_name,
                         transaction_quantity,
                         created_by, creation_date, last_updated_by,
                         last_update_date, remark, bill_type_id, business_num  ,terminal_entity_id,terminal_code,terminal_name
                         ,original_bill_num
                        )
                 VALUES (pkgn_entity_id, vn_history_id, pkgd_transaction_date, pkgn_period_id,
                         pkgs_period_name, pkgn_source_type_id, pkgs_business_state,
                         pkgn_transaction_type_id, pkgs_action_type, ty_bill (i).header_id,
                         ty_bill (i).line_id, ty_bill (i).line_detail_id, ty_bill (i).item_id,
                         ty_bill (i).item_code, ty_bill (i).item_name,
                         ty_bill (i).transaction_uom, ty_bill (i).inventory_id,
                         ty_bill (i).inventory_code, ty_bill (i).inventory_name,
                         ty_bill (i).to_inventory_id, ty_bill (i).to_inventory_code,
                         ty_bill (i).to_inventory_name, ty_bill (i).from_inventory_id,
                         ty_bill (i).from_inventory_code, ty_bill (i).from_inventory_name,
                         ty_bill (i).transaction_quantity - vn_quantity_his,
                         ty_bill (i).created_by, pkgd_sysdate,
                                                               /*update by lingyy 2014-11-26 对修改人/修改时间赋值*/
                                                              --null,null,
                                                              ty_bill (i).created_by,
                         pkgd_sysdate,
                                      /*update end*/
                         ty_bill (i).remark, pkgn_bill_type_id, pkgs_business_num
			                  ,ty_bill (i).terminal_entity_id,ty_bill (i).terminal_code,ty_bill (i).terminal_name
                        ,ty_bill (i).original_bill_num
                        );

            SELECT TO_CHAR (vn_history_id)
              INTO vs_new
              FROM DUAL;

            IF pkgs_new_str IS NULL
            THEN
               pkgs_new_str    := vs_new;
            ELSE
               pkgs_new_str    := vs_new || ',' || pkgs_new_str;
            END IF;

            on_if_dif        := 0;
         END IF;

         vn_business_line_id           := ty_bill (i).line_id;
         vn_business_line_detail_id    := ty_bill (i).line_detail_id;
         vn_bill_inventory_id          := ty_bill (i).inventory_id;
         vn_bill_item_id               := ty_bill (i).item_id;

         FOR c_get_id IN get_transaction_id
         LOOP
            SELECT TO_CHAR (c_get_id.transaction_id)
              INTO vs_id
              FROM DUAL;

            IF vs_transaction_id IS NULL
            THEN
               vs_transaction_id    := vs_id;
            ELSE
               vs_transaction_id    := vs_id || ',' || vs_transaction_id;
            END IF;
         END LOOP;
      END LOOP;

      IF vs_transaction_id IS NULL
      THEN
         vs_transaction_id    := '0';
      END IF;

      --物料事务历史中有的，本次业务单据中没有的；并且，物料历史中的sum数量不等于0的
      v_sql                :=
            'select business_line_id,business_line_detail_id,inventory_id,item_id,sum(transaction_quantity) transaction_quantity
        from t_inv_transaction_history
        where entity_id = '
         || pkgn_entity_id
         || ' and business_state = '''
         || pkgs_business_state
         || ''' and bill_type_id = '
         || pkgn_bill_type_id
         || ' and business_header_id = '
         || pkgn_business_header_id
         || 'and transaction_id not in ('
         || vs_transaction_id
         || ') group by business_line_id,business_line_detail_id,inventory_id,item_id having sum(transaction_quantity) <> 0';

      OPEN v_cur FOR v_sql;

      LOOP
         FETCH v_cur
          INTO v_business_line_id, v_business_line_detail_id, v_inventory_id, v_item_id,
               v_transaction_quantity;

         EXIT WHEN v_cur%NOTFOUND;
         --增加差额红冲记录
         vn_history_id    := s_inv_transaction_history.NEXTVAL;

         INSERT INTO t_inv_transaction_history
                     (entity_id, transaction_id, transaction_date, period_id, period_name,
                      source_type_id, business_state, transaction_type_id, action_type,
                      business_header_id, business_line_id, business_line_detail_id, item_id,
                      item_code, item_name, transaction_uom, inventory_id, inventory_code,
                      inventory_name, to_inventory_id, to_inventory_code, to_inventory_name,
                      from_inventory_id, from_inventory_code, from_inventory_name,
                      transaction_quantity, created_by, creation_date, last_updated_by,
                      last_update_date, remark, bill_type_id, business_num  ,terminal_entity_id,terminal_code,terminal_name,original_bill_num)
            SELECT pkgn_entity_id, vn_history_id, transaction_date, period_id, period_name,
                   source_type_id, pkgs_business_state, transaction_type_id, action_type,
                   business_header_id, business_line_id, business_line_detail_id, item_id,
                   item_code, item_name, transaction_uom, inventory_id, inventory_code,
                   inventory_name, to_inventory_id, to_inventory_code, to_inventory_name,
                   from_inventory_id, from_inventory_code, from_inventory_name,
                   v_transaction_quantity * (-1), created_by, pkgd_sysdate,
                                                                            /*update by lingyy 2014-11-26 对修改人/修改时间赋值*/
                                                                           --null,null,
                                                                           last_updated_by,
                   pkgd_sysdate,
                                /*update end*/
                   remark, pkgn_bill_type_id,
                                           --pkgs_business_num, del by lingyy 2014-10-27 业务单据为空时，该全局变量不会被赋值，这里直接用表中的businesss_num代替即可。
                                           business_num                  --add by lingyy 2014-10-27
		              ,terminal_entity_id,terminal_code,terminal_name ,original_bill_num      --add by guibr 20150724
              FROM t_inv_transaction_history
             WHERE entity_id = pkgn_entity_id
               AND business_state = pkgs_business_state
               AND bill_type_id = pkgn_bill_type_id
               AND business_header_id = pkgn_business_header_id
               AND business_line_id = v_business_line_id
               AND NVL (business_line_detail_id, -1) = NVL (v_business_line_detail_id, -1)
               AND item_id = v_item_id
               AND inventory_id = v_inventory_id
               AND ROWNUM = 1;

         SELECT TO_CHAR (vn_history_id)
           INTO vs_new
           FROM DUAL;

         IF pkgs_new_str IS NULL
         THEN
            pkgs_new_str    := vs_new;
         ELSE
            pkgs_new_str    := vs_new || ',' || pkgs_new_str;
         END IF;

         on_if_dif        := 0;
      END LOOP;

      CLOSE v_cur;
   EXCEPTION
      WHEN OTHERS
      THEN
         on_flag      := -1;
         os_prompt    := '调用inv_bill_history_check时发生异常！' || SUBSTR (SQLERRM, 1, 200);
         --rollback;
         RETURN;
   END inv_bill_history_check;

   PROCEDURE inv_update_onhand (
      id_transaction_date   IN       t_inv_transaction_history.transaction_date%TYPE,
      --业务日期
      on_flag               OUT      NUMBER,
      os_prompt             OUT      VARCHAR2
   )
   AS
      vn_quantity         t_inv_transaction_history.transaction_quantity%TYPE;
      vn_count            NUMBER;

      TYPE mycur IS REF CURSOR;

      v_cur               mycur;
      v_sql               CLOB;
      v_quantity          t_inv_transaction_history.transaction_quantity%TYPE;
      v_inventory_id      t_inv_transaction_history.inventory_id%TYPE;
      v_item_id           t_inv_transaction_history.item_id%TYPE;
      v_transaction_uom   t_inv_transaction_history.transaction_uom%TYPE;
      v_transaction_id    t_inv_transaction_history.transaction_id%TYPE;
      v_last_updated_by   t_inv_transaction_history.last_updated_by%TYPE;
      v_created_by        t_inv_transaction_history.created_by%TYPE;
      vs_inv_flag         t_inv_inventories.negative_inventory_flag%TYPE;
      vs_inventory_type   t_inv_inventories.inventory_type%TYPE;  --仓库类型 add by guibr 20150724
      V_INVENTORY_CODE    T_INV_INVENTORIES.INVENTORY_CODE%TYPE;  --仓库编码
      V_ITEM_CODE         T_BD_ITEM.ITEM_CODE%TYPE;               --产品编码
      OS_MESSAGE          VARCHAR2(1000);                               --调用门店库存现有量计算返回结果 add by guibr 20150724
   BEGIN
      on_flag      := 0;
      os_prompt    := '';

      IF pkgs_new_str IS NOT NULL
      THEN                                                           --只有在产生差额时更新现有量表
         /*v_sql    :=
               'select transaction_quantity quantity,inventory_id,item_id,transaction_uom,transaction_id,last_updated_by,created_by
            from t_inv_transaction_history
            where entity_id = '
            || pkgn_entity_id
            || ' and business_state = '''
            || pkgs_business_state
            || ''' and bill_type_id = '
            || pkgn_bill_type_id
            || ' and business_header_id = '
            || pkgn_business_header_id
            || 'and transaction_id in ('
            || pkgs_new_str
            || ') order by ITEM_CODE';
            

           
         OPEN v_cur FOR v_sql;
*/
         v_sql    := '
           select transaction_quantity quantity,
                  inventory_id,
                  item_id,
                  transaction_uom,
                  transaction_id,
                  last_updated_by,
                  created_by
             from t_inv_transaction_history
            where entity_id = :1
              and business_state = :2
              and bill_type_id = :3
              and business_header_id = :4
              and Instr(:5, transaction_id) > 0
            order by ITEM_CODE
            ';
            
         OPEN v_cur FOR v_sql using pkgn_entity_id,pkgs_business_state,pkgn_bill_type_id,pkgn_business_header_id,pkgs_new_str;
          
         LOOP
            FETCH v_cur
             INTO v_quantity, v_inventory_id, v_item_id, v_transaction_uom, v_transaction_id,
                  v_last_updated_by, v_created_by;

            EXIT WHEN v_cur%NOTFOUND;

            SELECT COUNT (*)
              INTO vn_count
              FROM t_inv_onhand
             WHERE entity_id = pkgn_entity_id
               AND inventory_id = v_inventory_id
               AND item_id = v_item_id;

            SELECT negative_inventory_flag,inventory_type
              INTO vs_inv_flag,vs_inventory_type
              FROM t_inv_inventories
             WHERE inventory_id = v_inventory_id
               AND begin_date <= id_transaction_date
               AND (end_date >= id_transaction_date OR end_date IS NULL);

            IF vn_count = 0
            THEN
               --判断现有量是否可以小于零
               IF pkgs_bill_type_flag = 'N' AND vs_inv_flag = 'N' AND v_quantity < 0
               THEN
                  -- 根据仓库ID、产品ID获取仓库编码、产品编码，以便完善错误提示信息，方便业务查找。modify by zhoujg3 2-15-07-06   [begin]
                  SELECT I.INVENTORY_CODE INTO V_INVENTORY_CODE FROM T_INV_INVENTORIES I WHERE I.INVENTORY_ID = v_inventory_id;
                  SELECT I.ITEM_CODE INTO V_ITEM_CODE FROM T_BD_ITEM I WHERE I.ITEM_ID = v_item_id;
                  on_flag      := -1;
                  os_prompt    :=
                          '更新库存现有量异常：经营主体(ID:'
                       || pkgn_entity_id
                       || ');仓库(ID:'
                       || v_inventory_id
                       || ',仓库编码:'
                       || V_INVENTORY_CODE
                       || ');产品(ID:'
                       || v_item_id
                       || ',产品编码:'
                       || V_ITEM_CODE
                       || ')的库存现有量不足！(库存：0,单据需求：'
                       ||v_quantity
                       ||')';
                  IF v_cur%ISOPEN = TRUE
                  THEN
                     CLOSE v_cur;
                  END IF;

                  RETURN;
               END IF;

               INSERT INTO t_inv_onhand
                           (created_by, creation_date, date_received, entity_id,
                            inventory_id, inv_id, item_id,
                            last_transaction_id, last_updated_by, last_update_date, quantity,
                            remark, transaction_uom
                           )
                    VALUES (v_created_by, pkgd_sysdate, pkgd_sysdate, pkgn_entity_id,
                            v_inventory_id, s_inv_current_inventory.NEXTVAL, v_item_id,
                            v_transaction_id, v_created_by, pkgd_sysdate, v_quantity,
                            NULL, v_transaction_uom
                           );

                IF vs_inventory_type = '10' THEN     --调用样机门店库存现有量计算  add by guibr 20150727
                     PKG_PROTO.P_INV_UPDATE_TERMINAL_ONHAND(v_transaction_id,OS_MESSAGE);
		                 IF OS_MESSAGE <> 'OK' THEN
                          on_flag      := -1;
                          os_prompt    := OS_MESSAGE;
                     END IF;
                END IF;

            ELSE
               SELECT     quantity
                     INTO vn_quantity
                     FROM t_inv_onhand
                    WHERE entity_id = pkgn_entity_id
                      AND inventory_id = v_inventory_id
                      AND item_id = v_item_id
               FOR UPDATE;

               vn_quantity    := vn_quantity + v_quantity;

               --判断现有量是否可以小于零
               IF pkgs_bill_type_flag = 'N' AND vs_inv_flag = 'N'
                                                                 --AND v_quantity < 0 --del by lingyy 2014-12-11
                  AND vn_quantity < 0
--add by lingyy 2014-12-11 vn_quantity变量才是库存现有量，v_quantity只是本次更新的现有量
               THEN
                  SELECT I.INVENTORY_CODE INTO V_INVENTORY_CODE FROM T_INV_INVENTORIES I WHERE I.INVENTORY_ID = v_inventory_id;
                  SELECT I.ITEM_CODE INTO V_ITEM_CODE FROM T_BD_ITEM I WHERE I.ITEM_ID = v_item_id;
                  on_flag      := -1;
                  os_prompt    :=
                          '更新库存现有量异常：经营主体(ID:'
                       || pkgn_entity_id
                       || ');仓库(ID:'
                       || v_inventory_id
                       || ',仓库编码:'
                       || V_INVENTORY_CODE
                       || ');产品(ID:'
                       || v_item_id
                       || ',产品编码:'
                       || V_ITEM_CODE
                       || ')的库存现有量不足！(库存：'
                       ||(vn_quantity - v_quantity)
                       ||',单据需求：'
                       ||v_quantity
                       ||')';

                  IF v_cur%ISOPEN = TRUE
                  THEN
                     CLOSE v_cur;
                  END IF;

                  RETURN;
               END IF;

               UPDATE t_inv_onhand
                  --SET quantity = vn_quantity, --del by lingyy 2015-01-04
               SET quantity = quantity + v_quantity,
                   --add by lingyy 2015-01-04
                   last_transaction_id = v_transaction_id,
                   --add by lingyy 2014-12-10 增加对最新交易ID的更新
                   last_updated_by = v_last_updated_by,
                   last_update_date = pkgd_sysdate
                WHERE entity_id = pkgn_entity_id
                  AND inventory_id = v_inventory_id
                  AND item_id = v_item_id;


                IF vs_inventory_type = '10' THEN     --调用样机门店库存现有量计算  add by guibr 20150727
                     PKG_PROTO.P_INV_UPDATE_TERMINAL_ONHAND(v_transaction_id,OS_MESSAGE);
		                 IF OS_MESSAGE <> 'OK' THEN
                          on_flag      := -1;
                          os_prompt    := OS_MESSAGE;
                     END IF;
                END IF;


            END IF;
         END LOOP;

         IF v_cur%ISOPEN = TRUE
         THEN
            CLOSE v_cur;
         END IF;
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         on_flag      := -1;
         os_prompt    := '调用inv_update_onhand时发生异常！' || SUBSTR (SQLERRM, 1, 200);

         --rollback;
         IF v_cur%ISOPEN = TRUE
         THEN
            CLOSE v_cur;
         END IF;

         RETURN;
   END inv_update_onhand;

   PROCEDURE inv_update_reconciliation (
      in_if_null   IN       NUMBER,                                   --是否是空的业务单据，0否，1是
      on_flag      OUT      NUMBER,
      os_prompt    OUT      VARCHAR2
   )
   AS
      vs_source_type_code   t_inv_source_types.source_type_code%TYPE;
   BEGIN
--不做特殊处理，每次都只记录本次业务单据的信息
      on_flag                := 0;
      os_prompt              := '';
      /*add by lingyy 2015-01-12 销售类单据不对账，所以不插入对账表*/
      vs_source_type_code    := NULL;

      BEGIN
         SELECT b.source_type_code
           INTO vs_source_type_code
           FROM t_inv_bill_types a, t_inv_source_types b
          WHERE a.source_type_id = b.source_type_id AND a.bill_type_id = pkgn_bill_type_id;
      EXCEPTION
         WHEN NO_DATA_FOUND
         THEN
            on_flag      := -1;
            os_prompt    := '单据类型ID(' || pkgn_bill_type_id || ')未找到其对应源类型！';
            RETURN;
      END;

      IF vs_source_type_code IN ('1006', '1007')
      THEN                                                        --源类型 销售：1006 销售退货：1007
         RETURN;
      END IF;

      /*add end.*/

      /*update by lingyy 2014-11-24 增加bill_type_id 条件，因为不同类型的单据，头ID会重复。不加的话，会删除不同类型但是头id相同的业务单据。*/
      --delete from t_inv_reconciliation
      --where entity_id = pkgn_entity_id and business_header_id = pkgn_business_header_id;
      DELETE FROM t_inv_reconciliation
            WHERE entity_id = pkgn_entity_id
              AND business_header_id = pkgn_business_header_id
              AND bill_type_id = pkgn_bill_type_id;

      /*update end.*/
      IF in_if_null = 0
      THEN                                                        --本次业务单据不为空，才记录对帐表
          /*update by lingyy 2014-11-4 修改了对账表结构，重写insert语句。*/
          --insert into t_inv_reconciliation(ENTITY_ID,RECONCILIATION_ID,BUSINESS_HEADER_ID,BUSINESS_STATE,BILL_TYPE_ID,
            --                              SOURCE_TYPE_ID,TRANSACTION_TYPE_ID,ACTION_TYPE,STATUS,CREATED_BY,
             --                             CREATION_DATE,LAST_UPDATED_BY,LAST_UPDATE_DATE,REMARK)
          --values(pkgn_entity_id,s_inv_reconciliation.nextval,pkgn_business_header_id,pkgs_business_state,pkgn_bill_type_id,
          --pkgn_source_type_id,pkgn_transaction_type_id,pkgs_action_type,'01',pkgn_created_by,
         -- pkgd_sysdate,null,null,null);
         INSERT INTO t_inv_reconciliation
                     (entity_id, reconciliation_id, transaction_date,
                      business_header_id, business_num, business_state,
                      bill_type_id, source_type_id, transaction_type_id,
                      action_type, reconciliation_time, reconciliation_flag, status, created_by,
                      creation_date, last_updated_by, last_update_date, remark
                     )
              VALUES (pkgn_entity_id, s_inv_reconciliation.NEXTVAL, pkgd_transaction_date,
                      pkgn_business_header_id, pkgs_business_num, pkgs_business_state,
                      pkgn_bill_type_id, pkgn_source_type_id, pkgn_transaction_type_id,
                      pkgs_action_type, NULL, NULL, '01', pkgn_created_by,
                      pkgd_sysdate, pkgn_created_by, pkgd_sysdate, NULL
                     );
      /*update end.*/
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         on_flag      := -1;
         os_prompt    := '调用inv_update_reconciliation时发生异常！' || SUBSTR (SQLERRM, 1, 200);
         --rollback;
         RETURN;
   END inv_update_reconciliation;

--重算时的特殊处理
   PROCEDURE recount_transaction_deal_p (
      in_entity_id            IN       t_inv_transaction_history.entity_id%TYPE,
      --经营主体ID
      in_business_header_id   IN       t_inv_transaction_history.business_header_id%TYPE,
      --业务单据头ID
      in_business_state       IN       t_inv_transaction_history.business_state%TYPE,
      --业务类型
      in_bill_type_id         IN       t_inv_bill_types.bill_type_id%TYPE,
      --单据类型ID
      on_flag                 OUT      NUMBER,
      os_prompt               OUT      VARCHAR2
   )
   AS
      CURSOR get_transaction_history
      IS
         SELECT   business_state, business_header_id, business_line_id, business_line_detail_id,
                  inventory_id, item_id, SUM (transaction_quantity) transaction_quantity
             FROM t_inv_transaction_history
            WHERE entity_id = in_entity_id
              AND business_header_id = in_business_header_id
              AND bill_type_id = in_bill_type_id
              --add by lingyy 2014-11-17 如果为99，表示整个head_id都红冲，不为99，表示只红冲单据头+单据状态的记录
              AND business_state =
                                 DECODE (in_business_state,
                                         '99', business_state,
                                         in_business_state
                                        )
         GROUP BY business_state,
                  business_header_id,
                  business_line_id,
                  business_line_detail_id,
                  inventory_id,
                  item_id
           HAVING SUM (transaction_quantity) <> 0;

      c_get_history   get_transaction_history%ROWTYPE;
      vn_history_id   t_inv_transaction_history.transaction_id%TYPE;
   BEGIN
      on_flag      := 0;
      os_prompt    := '';

      --重算时的特殊处理：业务单据空，物料历史有数据的情况。全部做差额红冲处理。
      FOR c_get_history IN get_transaction_history
      LOOP
         vn_history_id    := s_inv_transaction_history.NEXTVAL;

         INSERT INTO t_inv_transaction_history
                     (entity_id, transaction_id, transaction_date, period_id, period_name,
                      source_type_id, business_state, transaction_type_id, action_type,
                      business_header_id, business_line_id, business_line_detail_id, item_id,
                      item_code, item_name, transaction_uom, inventory_id, inventory_code,
                      inventory_name, to_inventory_id, to_inventory_code, to_inventory_name,
                      from_inventory_id, from_inventory_code, from_inventory_name,
                      transaction_quantity, created_by, creation_date, last_updated_by,
                      last_update_date, remark, bill_type_id, business_num  ,terminal_entity_id,terminal_code,terminal_name,original_bill_num)
            SELECT entity_id, vn_history_id, transaction_date, period_id, period_name,
                   source_type_id, business_state, transaction_type_id, action_type,
                   business_header_id, business_line_id, business_line_detail_id, item_id,
                   item_code, item_name, transaction_uom, inventory_id, inventory_code,
                   inventory_name, to_inventory_id, to_inventory_code, to_inventory_name,
                   from_inventory_id, from_inventory_code, from_inventory_name,
                   c_get_history.transaction_quantity * (-1), created_by, creation_date,
                   last_updated_by, last_update_date, remark, bill_type_id, business_num
		              ,terminal_entity_id,terminal_code,terminal_name,original_bill_num
              FROM t_inv_transaction_history
             WHERE entity_id = in_entity_id
               AND business_header_id = in_business_header_id
               AND business_state = c_get_history.business_state
               AND bill_type_id = in_bill_type_id
               AND business_header_id = c_get_history.business_header_id
               AND business_line_id = c_get_history.business_line_id
               AND NVL (business_line_detail_id, -1) =
                                                      NVL (c_get_history.business_line_detail_id,
                                                           -1)
               AND inventory_id = c_get_history.inventory_id
               AND item_id = c_get_history.item_id
               AND ROWNUM = 1;
      END LOOP;
   EXCEPTION
      WHEN OTHERS
      THEN
         on_flag      := -1;
         os_prompt    := '调用recount_transaction_deal_p时发生异常！' || SUBSTR (SQLERRM, 1, 200);
         --rollback;
         RETURN;
   END recount_transaction_deal_p;

--物料事务处理总过程
   PROCEDURE inv_transaction_total_deal (
      in_entity_id            IN       t_inv_transaction_history.entity_id%TYPE,
      --经营主体ID
      in_bill_type_id         IN       t_inv_bill_types.bill_type_id%TYPE,
      --单据类型ID
      is_business_state       IN       t_inv_transaction_history.business_state%TYPE,
      --单据状态
      id_transaction_date     IN       t_inv_transaction_history.transaction_date%TYPE,
      --业务日期
      in_business_header_id   IN       t_inv_transaction_history.business_header_id%TYPE,
      --业务单据头ID
      in_if_null              IN       NUMBER,                        --是否是空的业务单据，0否，1是
      is_bill_kind            IN       VARCHAR2,
--B1（采购中转）、B2（仓库调拨）、B3（仓库盘点）、B4（销售）、B5（推广物料）、ISNULL（业务单空物料历史有数据）
      on_flag                 OUT      NUMBER,
      os_prompt               OUT      VARCHAR2
   )
   AS
      vn_count1             NUMBER;
      vn_if_dif             NUMBER;
      --业务单据和物料事务历史信息比对，不同0，相同1
      vs_transaction_flag   t_inv_bill_period_line.transaction_flag%TYPE;
      
      vs_whether_same_inv   VARCHAR2(2);
   BEGIN
       /*add by lingyy 2014-11-4 增加接口日志表，调式使用，上线时，去掉此模块功能*/
      /* INSERT INTO T_INV_TRANSACTION_HISTORY_LOG(
           ENTITY_ID,
           BILL_TYPE_ID,
           BUSINESS_STATE,
           TRANSACTION_DATE,
           BUSINESS_HEAD_ID,
           IF_NULL,
           BILL_KIND,
           CREATE_DATE)
       VALUES(
           in_entity_id,
           in_bill_type_id,
           is_business_state,
           id_transaction_date,
           in_business_header_id,
           in_if_null,
           is_bill_kind,
           sysdate
       );
       */
       /*add end.*/
      on_flag                  := 0;
      os_prompt                := '';
      pkgs_new_str             := '';                                        --本次insert的历史ID串
      /* del by lingyy 2014-11-18
      if is_bill_kind = 'ISNULL' then
          --重算时的特殊处理：业务单据空，物料历史有数据的情况
          recount_transaction_deal_p(in_entity_id,in_business_header_id,is_business_state,in_bill_type_id,on_flag,os_prompt);
          RETURN;
      end if;
      */
      pkgd_transaction_date    := TRUNC (id_transaction_date);
                                           --update by lingyy 2015-01-14 只截取到年月日，去掉时分秒
      --对前台录入参数的为空校验
      check_is_null (in_entity_id,
                     in_bill_type_id,
                     is_business_state,
                     pkgd_transaction_date,
                     in_business_header_id,
                     in_if_null,
                     on_flag,
                     os_prompt
                    );

      IF on_flag < 0
      THEN
         RETURN;
      END IF;

      pkgn_bill_type_id        := in_bill_type_id;
      pkgn_if_null             := in_if_null;

      --校验是否已生成物料事务历史
      SELECT COUNT (*)
        INTO vn_count1
        FROM t_inv_transaction_history
       WHERE entity_id = in_entity_id
         AND business_state = is_business_state
         AND bill_type_id = in_bill_type_id
         AND business_header_id = in_business_header_id;

      IF vn_count1 = 0
      THEN
         pkgn_if_his    := 0;                                            --是否已有物料事物历史记录

         IF in_if_null = 1
         THEN                                          --前后两次业务单据都为空时，不做物料事物处理
            on_flag      := 0;
            os_prompt    := '空的业务单据不做物料事务处理！';
            RETURN;
         END IF;
      ELSE
         pkgn_if_his    := 1;
      END IF;

      --检测是否调用物料事务
      check_transaction_yesorno_p (in_entity_id,
                                   in_bill_type_id,
                                   is_business_state,
                                   vs_transaction_flag,
                                   on_flag,
                                   os_prompt
                                  );

      IF on_flag < 0 OR vs_transaction_flag = 'N'
      THEN
         RETURN;
      END IF;

      ----add by lingyy 2014-12-09 获取业务单据信息
      get_bill_info_p (in_entity_id, in_business_header_id, is_bill_kind, on_flag, os_prompt);

      IF on_flag < 0
      THEN
         RETURN;
      END IF;

      --数据准备
      init_p (in_business_header_id, is_bill_kind, is_business_state,vs_whether_same_inv, on_flag, os_prompt);

      IF on_flag < 0
      THEN
         RETURN;
      END IF;
      
      IF vs_whether_same_inv ='Y' and is_bill_kind='B4'  THEN  --仓库相同并且是销售单时
            on_flag      := 0;
            os_prompt    := '仓库相同并且是销售单时不做库存事物';
           return;
      END IF;

      --基本信息校验(可以单独使用)
      check_bill_info (in_entity_id,
                       is_business_state,
                       pkgd_transaction_date,
                       pkgn_source_type_id,
                       pkgn_transaction_type_id,
                       in_if_null,
                       on_flag,
                       os_prompt
                      );

      IF on_flag < 0
      THEN
         RETURN;
      END IF;
      
      inv_transaction_onhand_check(in_if_null,pkgd_transaction_date,on_flag, os_prompt);
      IF on_flag < 0
      THEN
         RETURN;
      END IF;

      --写物料事务历史
      inv_transaction_deal (in_if_null, on_flag, os_prompt);

      IF on_flag < 0
      THEN
         RETURN;
      END IF;

      --比对业务单据和历史表的数据是否一致
      inv_bill_history_check (on_flag, os_prompt, vn_if_dif);

      IF on_flag < 0
      THEN
         RETURN;
      ELSE
         IF vn_if_dif = 0
         THEN                                        --如果比对结果不平，重新比对更新历史到相等为止
            inv_bill_history_check (on_flag, os_prompt, vn_if_dif);
         END IF;
      END IF;

      --更新现有量表
      inv_update_onhand (pkgd_transaction_date, on_flag, os_prompt);

      IF on_flag < 0
      THEN
         RETURN;
      END IF;

      --更新对账信息表
      inv_update_reconciliation (in_if_null, on_flag, os_prompt);

      IF on_flag < 0
      THEN
         RETURN;
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         on_flag      := -1;
         os_prompt    :=
              '调用inv_transaction_total_deal时发生异常！' || os_prompt || SUBSTR (SQLERRM, 1, 200);
         --rollback;
         RETURN;
   END inv_transaction_total_deal;
END pkg_inv_transaction;
/

