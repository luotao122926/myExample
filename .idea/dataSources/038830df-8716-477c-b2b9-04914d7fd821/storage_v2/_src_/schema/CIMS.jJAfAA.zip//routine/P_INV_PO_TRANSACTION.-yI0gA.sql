create procedure P_INV_PO_TRANSACTION(I_ENTITY_ID IN INTEGER) IS
  /**
   PO对账逻辑：
  1、对调账的单据单独处理，作无差异，后期优化，调账单据不作程序中写死
  2、以已产生库存事务的PO单为，取出CIMS库存事务-按单据、仓库、产品汇总，与GERP进行比较(仓库、数量)
  3、以PO单为条件，获取GERP库存事务-按单据、仓库、产品汇总，且CIMS不存在的开始事务
  */

  /** v1.1
   优化内容
   1、将调整单据从程序中调整至账务调整表
   2、对PO单库存事务数量能够对上，则判断成功，不校验库存事务记录数
  */
  /** v1.2,v1.3
     优化PO单库存事务查询
     1、增加子库存转移；
     2、增加PO接收库存事务
     3、调整关联交易库存事务查询，与单据类型绑定
     4、调整账务处理单据的处理方式(由从GERP\CIMS分别查询调整为仅从CIMS查询)
  */
  /** v1.4
      1、优化查询SQL，查询ERP库存事务，增加规则：/*+ DRIVING_SITE(inv_erp) * /
      2、仓库、库存组织ID，将exists调整为in
      3、去掉类型为推广物料单据
  */

  --declare
  -- Local variables here

  -- 单据符合条件记录数
  i_bill_num integer;
  -- 单据重复次数
  i_inv_bill_count integer;

  -- 备注长度，1000个字(数字、字母、汉字均按照1个字计算)
  i_remark_length number := 1000;

  -- CIMS库存事务记录数
  count_po_inv_cims integer;
  -- GERP库存事务记录数
  count_po_inv_gerp integer;
  -- 主体
  v_entity_id integer;
  --数量
  i_qty_temp number;

  b_immediate_commit boolean; -- 执行SQL后是否及时提交事务

  -- 对账是否成功标志
  str_status varchar2(2);
  -- 对账开始日期(包含)
  str_start_date varchar2(20);
  -- 对账结束日期(不包含)
  str_end_date varchar2(20);
  -- 对账结果
  str_msg varchar2(2000);
  -- 对账结果-过程比较
  str_bill_line_msg varchar2(2000);
  -- 对账中间结果
  str_bill_line_msg2 varchar2(2000);
  --单据最终状态-接收
  str_status_end varchar2(2);
  --单据状态名称
  str_status_meaning varchar2(20);

  -- PO单、仓库、产品编码、CIMS数量、GERP数量，差异原因
  str_select_sql varchar2(4000);
  -- 插入对照表SQL
  str_insert_sql varchar2(4000);
  ---调账SQL
  str_select_sql_rec varchar2(8000);
  ---调账SQL
  str_insert_sql_rec varchar2(32000);
  -- 删除标记为错误的单据
  str_delete_sql varchar2(4000);

  -- 更新关联物流和关联订单号
  str_update_sql varchar2(4000);

  --对账程序开始时间-用于纠正更新
  str_start_time varchar2(200);
  --对账程序结束时间-用于纠正更新
  str_end_time varchar2(200);

  var_bill_no_debug varchar2(20) := 'P140000374-9999';

  i_transaction_type number; -- 库存事务类型
  STATIC_ICP_TYPE    number := 3; -- 关联交易
  STATIC_BILL_TYPE   number := 2; -- 采购
  STATIC_INTF_TYPE   number := 1; -- 库存事务接口
  STATIC_NOT_TYPE    number := 0; -- 未定义库存事务类型

  -- 待校验PO单(IMS已产生库存事务，且未核对和未排除对账)
  /*cursor po_all(in_entity_id in number, in_start_date in varchar2, in_end_date in varchar2) is
      select po.po_num bill_no,
             po.po_status status,
             bill_type.bill_period_head_id,
             bill_type.bill_type_name bill_type,
             bill_type.erp_trancation erp_trancation,
             nvl(po.erp_order_header_id, 0) erp_order_header_id,
             nvl(po.erp_logist_header_id, 0) erp_logist_header_id
      --(po.exec_date-90) erp_transaction_date  -- 增加库存事务日期过滤
        from cims.t_inv_po_headers po, cims.t_inv_bill_types bill_type
       where po.entity_id = in_entity_id
         and po.po_type_id = bill_type.bill_type_id
            --   and po.po_num = var_bill_no_debug --测试验证单据
         and exists (select 1
                from cims.t_inv_transaction_history inv_his
               where inv_his.entity_id = in_entity_id
                 and inv_his.business_num = po.po_num
                 and inv_his.transaction_date >=
                     to_date(in_start_date, 'yyyy-mm-dd')
                 and inv_his.transaction_date <
                     to_date(in_end_date, 'yyyy-mm-dd'))
         and not exists (select 1
                from cims.t_inv_taction_reconciliation rec
               where po.po_num = rec.business_num
                 and rec.entity_id = in_entity_id) --排除已对账单据
         and not exists (select 1
                from cims.t_inv_taction_reconcil_line rec_l
               where rec_l.business_num = po.po_num
                 and rec_l.reconciliation_type = 'PO'); --排除已做账务处理单据
  */
  -- 红冲差异单据(汇总比对)
  cursor c_reconciliation_po_red_diff(in_entity_id_f in number, in_start_date_f in varchar2, in_end_date_f in varchar2) is
    select distinct po.old_po_num bill_no,
                    po.finance_organization_id organization_id,
                    bill_type.erp_trancation,
                    sum(rec.cims_qty) cims_qty
      from cims.t_inv_taction_reconciliation rec,
           cims.t_inv_po_headers             po,
           cims.t_inv_bill_types             bill_type
     where rec.entity_id = in_entity_id_f
       and rec.creation_date >
           to_date(in_start_date_f, 'yyyy-mm-dd hh24:mi:ss') -
           1 / (24 * 60)
       and rec.creation_date <
           to_date(in_end_date_f, 'yyyy-mm-dd hh24:mi:ss') + 1 / (24 * 60)
       and rec.reconciliation_type = 'PO'
       and rec.status = '01'
       and rec.business_num = po.po_num
       and po.entity_id = in_entity_id_f
       and po.po_type_id = bill_type.bill_type_id
       and nvl(po.old_po_num, 'N') <> 'N'
       and nvl(bill_type.erp_trancation,'0') not in('05','06')
     group by po.old_po_num,
              po. finance_organization_id,
              bill_type.erp_trancation;

  -- 正常差异单据
  cursor c_reconciliation_po_diff(in_entity_id_f in number, in_start_date_f in varchar2, in_end_date_f in varchar2) is
    select distinct rec.business_num bill_no, bill_type.erp_trancation
      from cims.t_inv_taction_reconciliation rec,
           cims.t_inv_po_headers             po,
           cims.t_inv_bill_types             bill_type
     where rec.entity_id = in_entity_id_f
       and rec.creation_date >
           to_date(in_start_date_f, 'yyyy-mm-dd hh24:mi:ss') -
           1 / (24 * 60)
       and rec.creation_date <
           to_date(in_end_date_f, 'yyyy-mm-dd hh24:mi:ss') + 1 / (24 * 60)
       and rec.reconciliation_type = 'PO'
       and rec.status = '01'
       and rec.business_num = po.po_num
       and po.entity_id = in_entity_id_f
       and po.po_type_id = bill_type.bill_type_id;

  -- 单据周期
  -- 待验证01 2014.04.17
  /*cursor bill_period(in_period_head_id number) is
  select inv_period_l.bill_status_code status
    from cims.t_inv_bill_period_line inv_period_l
   where inv_period_l.transaction_flag = 'Y'
     and inv_period_l.bill_period_head_id = in_period_head_id;*/

  -- PO单未产生库存事务-按照产品
  cursor c_po_cims_not_inv(in_entity_id in number, in_status_end in varchar2) is
    select po.po_num bill_no,
           po.inv_finance_code inv_code,
           po_l.item_code item_code,
           bill_type.bill_type_name bill_type,
           period_l.bill_status_code status,
           bill_type.erp_trancation erp_trancation,
           nvl(po.erp_order_header_id, 0) erp_order_header_id,
           nvl(po.erp_logist_header_id, 0) erp_logist_header_id,
           po_l.shipped_qty qty
      from cims.t_inv_po_headers       po,
           cims.t_inv_po_lines         po_l,
           cims.t_inv_bill_types       bill_type,
           cims.t_inv_bill_period_line period_l
     where po.po_type_id = bill_type.bill_type_id
       and bill_type.bill_period_head_id = period_l.bill_period_head_id
       and po.po_id = po_l.po_id
       and bill_type.entity_id = in_entity_id
       and period_l.transaction_flag = 'Y'
       and decode(period_l.bill_status_code, '21', 1, '14', 2) <=
           decode(po.po_status, '21', 1, '14', 2) ---- 转化规则
       and not exists (select 1
              from cims.t_inv_taction_reconciliation rec
             where rec.business_num = po.po_num)
       and not exists
     (select 1
              from cims.t_inv_transaction_history invh
             where invh.business_num = po.po_num
               and po.inv_finance_code = invh.inventory_code
               and invh.item_code = po_l.item_code
               and invh.business_state = period_l.bill_status_code);

  -- ERP库存事务-单据、产品且CIMS未产生库存事务
  /*cursor po_inv_gerp_exists(in_entity_id in number, in_bill_no in varchar2) is
  select inv_erp.attribute13 bill_no
    from apps.mtl_material_transactions@mdims2mderp inv_erp,
         apps.mtl_system_items_b@mdims2mderp        mtl
   where 1 = 1
     and inv_erp.attribute13 = in_bill_no
        --and inv_erp.subinventory_code = str_inv_code
        --and mtl.segment1 = str_item_code
     and inv_erp.inventory_item_id = mtl.inventory_item_id
     and inv_erp.organization_id = mtl.organization_id
     and inv_erp.attribute11 = 'CIMS'
     and exists
   (select 1
            from cims.t_inv_inventories inv
           where inv.entity_id = in_entity_id
             and inv.organization_id = inv_erp.organization_id
             and inv.inventory_code = inv_erp.subinventory_code
             and inv.inventory_type not in ('08', '09'))
     and not exists
   (select 'CIMS' sys_name,
                 inv_his.business_num bill_no,
                 inv_his.inventory_code inv_code,
                 inv_his.item_code,
                 inv_his.transaction_quantity qty
            from cims.t_inv_transaction_history inv_his
           where 1 = 1
             and inv_his.entity_id = in_entity_id
             and inv_his.business_num = in_bill_no);*/

  /** erp_trancation参考值
  01  组织间转移-接口
  02  子库转移-接口
  03  账户别名发出-接口
  04  账户别名接收-接口
  05  采购订单--单据
  06  采购订单退货--单据
  07  关联交易采购--单据
  08  关联交易退货--单据
  09  关联交易反向销售--单据
  10   推广物料发放--接口
  */
  -- 返回库存事务类型
  function f_get_transaction_type(in_erp_trancation in varchar2)
    return number is
    return_bool boolean;
    return_type number;
    f_type      number;
    str_sql_f   varchar2(1000);
  
    -- 关联交易类型
    static_icp_codes varchar2(100) := ' ''07'',''08'',''09'' ';
  
    -- 采购单类型
    static_po_codes varchar2(100) := ' ''05'',''06'' ';
  
    -- 其他类型-库存事务接口
    static_intf_codes varchar2(100) := ' ''01'',''02'',''03'',''04'',''10'' ';
  begin
    return_bool := false;
    return_type := 0;
  
    if (in_erp_trancation is null) or (in_erp_trancation = '') then
      return_type := STATIC_NOT_TYPE;
      return return_type;
    end if;
  
    if return_type = 0 then
      begin
        str_sql_f := ' select count(1) from dual where ''' ||
                     in_erp_trancation || ''' in (' || static_icp_codes || ') ';
        execute immediate str_sql_f
          into f_type;
      
        if f_type > 0 then
          return_type := STATIC_ICP_TYPE;
        end if;
      end;
    end if;
  
    if return_type = 0 then
      begin
        str_sql_f := ' select count(1) from dual where ''' ||
                     in_erp_trancation || ''' in (' || static_po_codes || ') ';
        execute immediate str_sql_f
          into f_type;
      
        if f_type > 0 then
          return_type := STATIC_BILL_TYPE;
        end if;
      end;
    end if;
  
    if return_type = 0 then
      begin
        return_type := STATIC_INTF_TYPE;
      end;
    end if;
  
    return return_type;
  end;

  -- 获取库存事务接口错误原因
  function f_get_intf_result(in_entity_id_f in number,
                             in_bill_no_f   in varchar2) return varchar2 is
    return_msg varchar2(2000);
    i_count_f  number;
  begin
    return_msg := null;
  
    if in_bill_no_f = var_bill_no_debug then
      dbms_output.put_line('f_get_intf_result-good:' || in_bill_no_f);
    end if;
  
    select count(*)
      into i_count_f
      from cims.intf_inv_transaction_head invh
     where invh.order_num = in_bill_no_f
       and nvl(invh.entity_id, in_entity_id_f) = in_entity_id_f;
  
    if in_bill_no_f = var_bill_no_debug then
      dbms_output.put_line('f_get_intf_result-i_count_f:' || i_count_f);
    end if;
  
    if i_count_f = 0 then
      return_msg := '库存事务接口表没有记录';
      select count(*)
        into i_count_f
        from cims.t_inv_transaction_history h
       where h.business_num = in_bill_no_f
         and h.entity_id = in_entity_id_f;
    
      if i_count_f = 0 then
        return_msg := 'CIMS没有产生库存事务';
      end if;
    elsif i_count_f > 0 then
      select decode(nvl(invh.error_flag, 'N'),
                    'Y',
                    invh.error_msg,
                    decode(nvl(invh.response_type, 'N'),
                           'E',
                           invh.response_message,
                           '等待GERP异步回调处理结果'))
        into return_msg
        from cims.intf_inv_transaction_head invh
       where invh.order_num = in_bill_no_f
         and nvl(invh.entity_id, in_entity_id_f) = in_entity_id_f
         and rownum < 2;
    end if;
  
    if in_bill_no_f = var_bill_no_debug then
      dbms_output.put_line('f_get_intf_result-return_msg:' || return_msg);
    end if;
  
    return return_msg;
  end;

  -- 获取单据接口错误原因-单据成功才会库存事务
  function f_get_bill_result(in_entity_id_f in number,
                             in_bill_no_f   in varchar2) return varchar2 is
    return_msg_f          varchar2(2000);
    str_msg_f             varchar2(2000);
    i_count_f             number;
    i_error_f             number;
    i_responsemessage_e_f number;
    i_responsemessage_w_f number;
  begin
    return_msg_f := null;
    str_msg_f    := null;
  
    select count(*),
           sum(decode(po_intf.error_flag, 'Y', 1, 0)),
           sum(decode(po_intf.response_type, 'E', 1, 0)),
           sum(decode(po_intf.response_type, 'W', 1, 0))
      into i_count_f,
           i_error_f,
           i_responsemessage_e_f,
           i_responsemessage_w_f
      from cims.intf_cux_po_order po_intf
     where po_intf.po_number = in_bill_no_f
          --and po_intf.error_flag = 'Y'
          --and po_intf.item_code is null
       and exists
     (select *
              from cims.t_inv_po_headers po
             where po.entity_id = in_entity_id_f
               and po.po_num = in_bill_no_f
               and po_intf.po_number = po.po_num
               and po.finance_operating_id = po_intf.org_id);
  
    if (i_count_f > 0) and
       ((i_error_f + i_responsemessage_e_f + i_responsemessage_w_f) > 0) then
    
      select decode(po_intf.error_flag,
                    'Y',
                    po_intf.error_msg,
                    decode(po_intf.response_type,
                           'W',
                           po_intf.responsemessage,
                           'E',
                           po_intf.responsemessage,
                           decode(po_intf.esb_serial_num,
                                  null,
                                  '单据未发送给GERP',
                                  '具体原因需人工进一步核实')))
        into str_msg_f
        from cims.intf_cux_po_order po_intf
       where po_intf.po_number = in_bill_no_f
         and ((po_intf.error_flag =
             decode(sign(i_error_f - 1), 1, 'Y', 0, 'Y', 'E')) or
             (po_intf.response_type =
             decode(sign(i_responsemessage_e_f - 1), 1, 'E', 0, 'E', 'E')) or
             (po_intf.response_type =
             decode(sign(i_responsemessage_w_f - 1), 1, 'W', 0, 'W', 'W')) or
             (i_error_f = 0 and i_responsemessage_e_f = 0 and
             i_responsemessage_w_f = 0))
            --and po_intf.item_code is null
         and rownum < 2
         and exists
       (select 1
                from cims.t_inv_po_headers po
               where po.entity_id = in_entity_id_f
                 and po.po_num = in_bill_no_f
                 and po_intf.po_number = po.po_num
                 and po.finance_operating_id = po_intf.org_id);
    else
      begin
      
        select count(*)
          into i_count_f
          from cims.intf_cux_po_order po_intf
         where po_intf.po_number = in_bill_no_f
              --and po_intf.response_type = 'W'
           and po_intf.item_code is not null
           and exists (select *
                  from cims.t_inv_po_headers po
                 where po.entity_id = in_entity_id_f
                   and po.po_num = in_bill_no_f
                   and po_intf.po_number = po.po_num
                   and po.finance_operating_id = po_intf.org_id)
           and rownum < 2;
      
        if (i_count_f > 0) then
          select decode(po_intf.error_flag,
                        'Y',
                        po_intf.error_msg,
                        decode(po_intf.response_type,
                               'W',
                               po_intf.responsemessage,
                               'E',
                               po_intf.responsemessage,
                               decode(po_intf.esb_serial_num,
                                      null,
                                      '单据未发送给GERP',
                                      '具体原因需人工进一步核实')))
            into str_msg_f
            from cims.intf_cux_po_order po_intf
           where po_intf.po_number = in_bill_no_f
                --and po_intf.response_type = 'W'
             and po_intf.item_code is not null
             and exists
           (select *
                    from cims.t_inv_po_headers po
                   where po.entity_id = in_entity_id_f
                     and po.po_num = in_bill_no_f
                     and po_intf.po_number = po.po_num
                     and po.finance_operating_id = po_intf.org_id)
             and rownum < 2;
        end if;
      end;
    end if;
  
    if str_msg_f is null then
      return_msg_f := 'PO单接口没有错误，原因待人工进一步处理';
    
      select count(*)
        into i_count_f
        from cims.t_inv_transaction_history h
       where h.business_num = in_bill_no_f
         and h.entity_id = in_entity_id_f;
    
      if i_count_f = 0 then
        return_msg_f := 'PO单在CIMS未产生库存事务';
      end if;
    else
      return_msg_f := str_msg_f;
    
    end if;
  
    return return_msg_f;
  end;

  -- 获取关联交易原因
  function f_get_icp_result(in_entity_id_f in number,
                            in_bill_no_f   in varchar2) return varchar2 is
    return_msg_f varchar2(2000);
    i_bill_num_f number;
  
    str_status_f         varchar2(10);
    str_bill_line_msg_f  varchar2(2000);
    str_bill_line_msg2_f varchar2(2000);
  begin
    return_msg_f := '关联交易信息';
  
    -- 查找原因
    -- 异步物流
    select count(1)
      into i_bill_num_f
      from cims.intf_cux_icp_logist_req_header icp_po
     where icp_po.requirement_order_num = in_bill_no_f
       and icp_po.entity_id = in_entity_id_f;
  
    -- 异步物流接口 if-2
    if i_bill_num_f = 0 then
      begin
        -- 物流订单
        select count(1)
          into i_bill_num_f
          from cims.intf_cux_icp_order_req_headers icp_order
         where icp_order.source_orders = in_bill_no_f;
      
        -- 物流订单接口 if-3
        if i_bill_num_f > 0 then
          select decode(nvl(icp_order.error_msg, '1'),
                        '1',
                        decode(nvl(icp_order.responsemessage, '1'),
                               '1',
                               null,
                               icp_order.responsemessage),
                        icp_order.error_msg)
            into str_bill_line_msg_f
            from cims.intf_cux_icp_order_req_headers icp_order
           where icp_order.source_orders = in_bill_no_f;
        
          if str_bill_line_msg_f is null then
            str_bill_line_msg_f := '异步物流接口无数据,物流订单接口正常,原因需进一步验证1';
          end if;
        end if; -- if-3-01 end 物流订单接口
      end; ----end 异步物流接口 if i_bill_num = 0 then begin
    else
      begin
        select decode(nvl(icp_po.error_msg_rev, '1'),
                      '1',
                      decode(nvl(icp_po.responsetype_2, 'N'),
                             'N',
                             decode(nvl(icp_po.error_msg_send, '1'),
                                    '1',
                                    decode(nvl(icp_po.Responsetype_1, 'N'),
                                           'N',
                                           decode(nvl(icp_po.status, 'N'),
                                                  'N',
                                                  '异步物流接口,待推送单据至GERP',
                                                  decode(icp_po.status_receive,
                                                         'P',
                                                         '异步物流接口正常,等待GERP异步回调')),
                                           icp_po.responsemessage_1),
                                    icp_po.error_msg_send),
                             icp_po.responsemessage_2),
                      icp_po.error_msg_rev)
          into str_bill_line_msg_f
          from cims.intf_cux_icp_logist_req_header icp_po
         where icp_po.requirement_order_num = in_bill_no_f
           and icp_po.entity_id = in_entity_id_f;
      
        --异步物流接口错误信息
        if (str_bill_line_msg_f is null) or
           ((str_bill_line_msg_f is not null) and
           (str_bill_line_msg_f = '异步物流接口正常,等待GERP异步回调' or
           str_bill_line_msg_f = '异步物流接口,待推送单据至GERP')) then
          -- 物流订单
          select count(1)
            into i_bill_num_f
            from cims.intf_cux_icp_order_req_headers icp_order
           where icp_order.source_orders = in_bill_no_f;
        
          --主体ID无值and icp_order.entity_id = v_entity_id;
        
          -- 存在物流订单
          if i_bill_num_f > 0 then
            select decode(nvl(icp_order.error_flag, 'N'),
                          'N',
                          decode(nvl(icp_order.responsetype, 'N'),
                                 'W',
                                 icp_order.responsemessage,
                                 decode(nvl(icp_order.status, 'N'),
                                        'N',
                                        '异步物流接口正常,物流订单待推送至GERP',
                                        'S',
                                        '异步物流接口正常,物流订单已推送至GERP,且GERP异步返回成功')),
                          icp_order.error_msg)
              into str_bill_line_msg2_f
              from cims.intf_cux_icp_order_req_headers icp_order
             where icp_order.source_orders = in_bill_no_f;
          
            if str_bill_line_msg2_f is not null then
              str_bill_line_msg_f := str_bill_line_msg2_f; --'异步物流接口正常,原因需进一步验证2';
            else
              begin
                select count(1)
                  into i_bill_num_f
                  from apps.cux_icp_logist_req_headers_v@mdims2mderp po_icp_erp
                 where po_icp_erp.requirement_order_num = in_bill_no_f
                   and po_icp_erp.esb_data_source = 'CIMS'
                   and rownum < 2;
              
                if i_bill_num_f > 0 then
                  select status, status_name
                    into str_status_f, str_bill_line_msg2_f
                    from apps.cux_icp_logist_req_headers_v@mdims2mderp po_icp_erp
                   where po_icp_erp.requirement_order_num = in_bill_no_f
                     and po_icp_erp.esb_data_source = 'CIMS'
                     and rownum < 2;
                
                  if (str_status_f is not null) and (str_status_f <> '5') then
                    str_bill_line_msg_f := str_bill_line_msg2_f;
                  end if;
                
                end if;
              end;
            end if;
          
            --dbms_output.put_line('03-3--' || str_bill_line_msg);
          end if; -- end 存在物流订单 if i_bill_num > 0
        
        end if; -- end 异步物流接口 if str_bill_line_msg is null                  
      end;
    end if; -- if-2-01 end 异步物流接口 if i_bill_num = 0     
  
    if str_bill_line_msg_f is null then
      str_bill_line_msg_f := '异步物流接口正常,物流订单接口正常,原因需进一步验证3';
    end if;
  
    return_msg_f := str_bill_line_msg_f;
  
    return return_msg_f;
  end;

  -- 返回PO退货数量
  function f_get_po_return_qty(in_bill_no_f         in varchar2,
                               in_organization_id_f number) return number is
    return_qty number;
    return_sql varchar2(4000);
  begin
    return_qty := 0;
    return_sql := '	select /*+ DRIVING_SITE(inv_erp) */ nvl(sum(inv_erp.transaction_quantity),0) gerp_qty	 ' ||
                  '	  from apps.po_headers_all@mdims2mderp            po_erp,	 ' ||
                  '	       apps.rcv_transactions@mdims2mderp          po_rcv,	 ' ||
                  '	       apps.mtl_material_transactions@mdims2mderp inv_erp,	 ' ||
                  '	       apps.mtl_system_items_b@mdims2mderp        mtl	 ' ||
                  '	 where po_erp.po_header_id = po_rcv.po_header_id	 ' ||
                  '	   and inv_erp.transaction_source_id = po_rcv.po_header_id	 ' ||
                  '	   and inv_erp.source_line_id = po_rcv.transaction_id	 ' ||
                  '	   and inv_erp.rcv_transaction_id = po_rcv.transaction_id	 ' ||
                  '	   and inv_erp.inventory_item_id = mtl.inventory_item_id	 ' ||
                  '	   and inv_erp.organization_id = mtl.organization_id	 ' ||
                  '	   and po_rcv.transaction_type = ''RETURN TO RECEIVING''	 ' ||
                  '    and inv_erp.transaction_date>trunc(sysdate)-180 '||
                  '    and inv_erp.organization_id=' ||
                  in_organization_id_f || '	   and po_erp.segment1 = ''' ||
                  in_bill_no_f || '''	 ';
  
    execute immediate return_sql
      into return_qty;
  
    return return_qty;
  
  end;

  -- 返回不对账的SQL
  function f_get_n_reconciliation(in_entity_id_f in varchar2) return varchar2 is
    return_sql      varchar2(4000);
    return_sql_temp varchar2(4000);
  begin
    return_sql_temp := 'select inv_bill.bill_type_name business_type, ' ||
                       '       h.business_num bill_no, ' ||
                       '       h.inventory_code inv_code, ' ||
                       '       h.item_code item_code, ' ||
                       '       sum(h.transaction_quantity) cims_qty, ' ||
                       '       sum(h.transaction_quantity) gerp_qty ' ||
                       '  from cims.t_inv_transaction_history h, cims.t_inv_bill_types inv_bill ' ||
                       ' where h.entity_id = ' || in_entity_id_f ||
                       '   and h.bill_type_id = inv_bill.bill_type_id ' ||
                       '   and h.entity_id = inv_bill.entity_id ' ||
                       '  and not exists(select 1 from cims.t_inv_taction_reconciliation rec ' ||
                       '  where rec.entity_id=' || in_entity_id_f ||
                       '    and rec.business_num=h.business_num ' ||
                       '    and rec.inv_code=h.inventory_code ' ||
                       '    and rec.reconciliation_type = ''PO''' ||
                       '    and rec.item_code=h.item_code)' ||
                       '   and exists (select 1 ' ||
                       '          from cims.t_inv_taction_reconcil_line recl ' ||
                       '         where h.business_num = recl.business_num ' ||
                       '           and recl.reconciliation_type = ''PO'') ' ||
                       ' group by inv_bill.bill_type_name, ' ||
                       '          h.business_num, ' ||
                       '          h.inventory_code, ' ||
                       '          h.item_code ';
  
    return_sql := ' insert into cims.t_inv_taction_reconciliation ' ||
                  '  (entity_id, ' || '   business_type, ' ||
                  '   business_num, ' || '   reconciliation_time, ' ||
                  '   reconciliation_flag, ' || '   status, ' ||
                  '   inv_code, ' || '   item_code, ' || '   cims_qty, ' ||
                  '   gerp_qty, ' || '   remark, ' || '   created_by, ' ||
                  '   creation_date, ' || '   last_updated_by, ' ||
                  '   last_update_date,reconciliation_type,' ||
                  'erp_order_header_id,erp_logist_header_id) ' ||
                  ' select ' || in_entity_id_f ||
                  ' entity_id, business_type, bill_no  business_num, ' ||
                  ' sysdate  reconciliation_time, ' ||
                  ' ''00''  reconciliation_flag, decode(sign(cims_qty-cims_qty),0,''00'',''01'')  status, ' ||
                  '   inv_code, ' || '   item_code, ' || '   cims_qty, ' ||
                  ' cims_qty gerp_qty, ' ||
                  '   ''PO单账务调整-无差异'' remark, ' ||
                  ' ''SYS''  created_by, ' || ' sysdate  creation_date, ' ||
                  ' ''SYS''  last_updated_by, ' ||
                  ' sysdate  last_update_date,''PO'' reconciliation_type,0 erp_order_header_id,0 erp_logist_header_id from (' ||
                  return_sql_temp || ') bill_all ' || '  where 1=1 ';
  
    return return_sql;
  end;

  -- 返回库存事务对账结果
  function f_get_all_transaction(in_transaction_type_f     in number,
                                 in_entity_id_f            in varchar2,
                                 in_bill_no_f              in varchar2,
                                 in_business_type_f        in varchar2,
                                 in_erp_order_header_id_f  in number,
                                 in_erp_logist_header_id_f in number)
    return varchar2 is
    return_sql   varchar2(4000);
    select_sql_f varchar2(3500);
    erp_sql_f    varchar2(2000);
    error_msg_f  varchar2(2000);
    is_equal     number;
  begin
    return_sql   := null;
    select_sql_f := null;
    erp_sql_f    := null;
    error_msg_f  := null;
    is_equal     := 0;
    if in_transaction_type_f = STATIC_ICP_TYPE then
      erp_sql_f := ' union all ' ||
                   ' select /*+ DRIVING_SITE(inv_erp) */ inv_erp.attribute13 business_num, ' ||
                   '  inv_erp.subinventory_code inv_code, ' ||
                   '  mtl.segment1 item_code, ' ||
                   '  inv_erp.transaction_quantity gerp_qty, ' ||
                   '  0 cims_qty ' ||
                   '  from apps.mtl_material_transactions@mdims2mderp inv_erp, ' ||
                   '  apps.mtl_system_items_b@mdims2mderp        mtl ' ||
                   '   where 1 = 1 ' ||
                   '  and inv_erp.inventory_item_id = mtl.inventory_item_id ' ||
                   '    and inv_erp.organization_id = mtl.organization_id ' ||
                   '    and (inv_erp.organization_id,inv_erp.subinventory_code) in (select distinct inv.organization_id,inv.inventory_code  ' ||
                   '      from cims.t_inv_inventories inv ' ||
                   '     where inv.entity_id =' || in_entity_id_f ||
                   '      and inv.inventory_type not in(''08'',''09''))'||
                   '    and inv_erp.transaction_date>trunc(sysdate) - 360 '||
                   '    and inv_erp.attribute11 = ''CIMS'' ' ||
                   '    and inv_erp.attribute13 = ''' || in_bill_no_f ||
                   '''';
      /**'    and exists (select 1  ' ||
      '      from cims.t_inv_inventories inv ' ||
      '     where inv.entity_id =' || in_entity_id_f ||
      '       and inv.organization_id = inv_erp.organization_id ' ||
      '      and inv.inventory_code = inv_erp.subinventory_code ' ||
      '      and inv.inventory_type not in(''08'',''09''))'*/
    elsif in_transaction_type_f = STATIC_INTF_TYPE then
      erp_sql_f := ' union all ' ||
                   ' select /*+ DRIVING_SITE(inv_erp) */ inv_erp.transaction_reference business_num, ' ||
                   '  inv_erp.subinventory_code inv_code, ' ||
                   '  mtl.segment1 item_code, ' ||
                   '  inv_erp.transaction_quantity gerp_qty, ' ||
                   '  0 cims_qty ' ||
                   '  from apps.mtl_material_transactions@mdims2mderp inv_erp, ' ||
                   '   apps.mtl_system_items_b@mdims2mderp        mtl ' ||
                   '  where 1 = 1 ' ||
                   '    and inv_erp.inventory_item_id = mtl.inventory_item_id ' ||
                   '    and inv_erp.organization_id = mtl.organization_id '||
                   '    and inv_erp.transaction_date>trunc(sysdate)-180 '||
                    '   and inv_erp.transaction_reference = ''' ||
                   in_bill_no_f ||
                   '''    and (inv_erp.organization_id,inv_erp.subinventory_code) in (select distinct inv.organization_id,inv.inventory_code  ' ||
                   '      from cims.t_inv_inventories inv ' ||
                   '     where inv.entity_id =' || in_entity_id_f ||
                   '      and inv.inventory_type not in(''08'',''09''))'||
                  /*'    and exists  ' ||
                                     '    (select 1  ' ||
                                     '      from cims.t_inv_inventories inv ' ||
                                     '     where inv.entity_id =' || in_entity_id_f ||
                                     '       and inv.organization_id = inv_erp.organization_id ' ||
                                     '      and inv.inventory_code = inv_erp.subinventory_code ' ||
                                     '      and inv.inventory_type not in(''08'',''09''))' || */
                   '   and inv_erp.source_code=''CIMS'' '; --by zxs 20150918 add
    elsif in_transaction_type_f = STATIC_BILL_TYPE then
      erp_sql_f := ' union all ' ||
                   ' select /*+ DRIVING_SITE(inv_erp) */ po_erp.segment1              business_num, ' ||
                   '        inv_erp.subinventory_code    inv_code,' ||
                   '        mtl.segment1                 item_code, ' ||
                   '        inv_erp.transaction_quantity gerp_qty, ' ||
                   '        0                            cims_qty ' ||
                   '   from apps.po_headers_all@mdims2mderp            po_erp, ' ||
                   '        apps.rcv_transactions@mdims2mderp          po_rcv, ' ||
                   '        apps.mtl_material_transactions@mdims2mderp inv_erp, ' ||
                   '        apps.mtl_system_items_b@mdims2mderp        mtl ' ||
                   '  where po_erp.po_header_id = po_rcv.po_header_id ' ||
                   '    and inv_erp.transaction_source_id = po_rcv.po_header_id ' ||
                   '    and inv_erp.source_line_id = po_rcv.transaction_id ' ||
                   '    and inv_erp.rcv_transaction_id = po_rcv.transaction_id ' ||
                   '    and inv_erp.inventory_item_id = mtl.inventory_item_id ' ||
                   '    and inv_erp.organization_id = mtl.organization_id ' ||
                   '    po_rcv.transaction_type = ''DELIVER'' ' ||
                   '    and po_erp.segment1 = ''' || in_bill_no_f ||
                   '''    and inv_erp.transaction_date>trunc(sysdate) - 360 '||
                   '    and (inv_erp.organization_id,inv_erp.subinventory_code) in (select distinct inv.organization_id,inv.inventory_code  ' ||
                   '      from cims.t_inv_inventories inv ' ||
                   '     where inv.entity_id =' || in_entity_id_f ||
                   '      and inv.inventory_type not in(''08'',''09''))';
      /* '    and exists  ' || '    (select 1  ' ||
      '      from cims.t_inv_inventories inv ' ||
      '     where inv.entity_id =' || in_entity_id_f ||
      '       and inv.organization_id = inv_erp.organization_id ' ||
      '       and inv.inventory_type not in(''08'',''09'') ' ||
      '       and inv.inventory_code = inv_erp.subinventory_code)'*/
    elsif in_transaction_type_f = STATIC_NOT_TYPE then
      erp_sql_f := ' union all ' || ' select  null business_num, ' ||
                   '         null inv_code,' || '         null item_code, ' ||
                   '         0 gerp_qty, ' ||
                   '         0 cims_qty from dual ';
    end if;
  
    select_sql_f := '   select ' || in_entity_id_f || ' entity_id, ' ||
                    '          ''' || in_business_type_f ||
                    ''' business_type, ' || '          business_num, ' ||
                    '          sysdate reconciliation_time, ' ||
                    '          ''00'' reconciliation_flag, ' ||
                    '          decode(sign(gerp_qty - cims_qty), 0, ''00'', ''01'') status, ' ||
                    '          inv_code, ' || '          item_code, ' ||
                    '          cims_qty, ' || '          gerp_qty, ' ||
                    '          decode(sign(gerp_qty - cims_qty), 0, ''PO单无差异'', ''PO单有差异'') remark, ' ||
                    '          ''SYS'' created_by, ' ||
                    '          sysdate creation_date, ' ||
                    '          ''SYS'' last_updated_by, ' ||
                    '          sysdate last_update_date, ' ||
                    '          ''PO'' reconciliation_type, ' ||
                    in_erp_order_header_id_f || ' erp_order_header_id, ' ||
                    in_erp_logist_header_id_f || ' erp_logist_header_id ' ||
                    '     from (select business_num, ' ||
                    '                  inv_code, ' ||
                    '                  item_code, ' ||
                    '                  nvl(sum(gerp_qty), 0) gerp_qty, ' ||
                    '                  nvl(sum(cims_qty), 0) cims_qty ' ||
                    '             from (select h.business_num, ' ||
                    '                          h.inventory_code inv_code, ' ||
                    '                          h.item_code, ' ||
                    '                          0 gerp_qty, ' ||
                    '                          h.transaction_quantity cims_qty ' ||
                    '                     from cims.t_inv_transaction_history h ' ||
                    '                    where h.entity_id =  ' ||
                    in_entity_id_f ||
                    '                      and h.business_num = ''' ||
                    in_bill_no_f || '''   ' || erp_sql_f || ') ' ||
                    '            group by business_num, inv_code, item_code) ';
  
    execute immediate 'select count(1) from (' || select_sql_f ||
                      ') where status=''01'''
      into is_equal;
  
    -- 有差异，查找差异原因
    if in_transaction_type_f = STATIC_NOT_TYPE then
      select replace(select_sql_f,
                     'PO单有差异',
                     'PO单-业务单据类型未设置事务类型')
        into select_sql_f
        from dual;
    elsif is_equal > 0 then
      begin
        if in_transaction_type_f = STATIC_ICP_TYPE then
          begin
            --dbms_output.put_line('length:' || lengthb(select_sql_f));
            error_msg_f := f_get_icp_result(in_entity_id_f, in_bill_no_f);
            if error_msg_f is not null then
              --dbms_output.put_line('length:' || lengthb(error_msg_f));
              select replace(select_sql_f,
                             'PO单有差异',
                             substr(error_msg_f, 1, i_remark_length))
                into select_sql_f
                from dual;
            end if;
          end;
        elsif in_transaction_type_f = STATIC_INTF_TYPE then
          begin
            --dbms_output.put_line('length:' || lengthb(select_sql_f));
            error_msg_f := f_get_intf_result(in_entity_id_f, in_bill_no_f);
            if error_msg_f is not null then
              --dbms_output.put_line('length:' || lengthb(error_msg_f));
              select replace(select_sql_f,
                             'PO单有差异',
                             substr(error_msg_f, 1, i_remark_length))
                into select_sql_f
                from dual;
            end if;
          end;
        elsif in_transaction_type_f = STATIC_BILL_TYPE then
          begin
            --dbms_output.put_line('length:' || lengthb(select_sql_f));
            error_msg_f := f_get_bill_result(in_entity_id_f, in_bill_no_f);
            if error_msg_f is not null then
              --dbms_output.put_line('length:' || lengthb(error_msg_f));
              select replace(select_sql_f,
                             'PO单有差异',
                             substr(error_msg_f, 1, i_remark_length))
                into select_sql_f
                from dual;
            end if;
          end;
        end if; -- end if is_icp_f then 
      end;
    end if;
  
    return_sql := ' insert into t_inv_taction_reconciliation ' ||
                  '   (entity_id, ' || '    business_type, ' ||
                  '    business_num, ' || '    reconciliation_time, ' ||
                  '    reconciliation_flag, ' || '    status, ' ||
                  '    inv_code, ' || '    item_code, ' || '    cims_qty, ' ||
                  '    gerp_qty, ' || '    remark, ' || '    created_by, ' ||
                  '    creation_date, ' || '    last_updated_by, ' ||
                  '    last_update_date, ' || '    reconciliation_type, ' ||
                  '    erp_order_header_id, ' ||
                  '    erp_logist_header_id) ' || select_sql_f;
    return return_sql;
  end;

  -- 返回库存事务对账结果
  function f_get_diff_result(in_transaction_type_f in number,
                             in_entity_id_f        in varchar2,
                             in_bill_no_f          in varchar2)
    return varchar2 is
    return_sql   varchar2(4000);
    select_sql_f varchar2(3500);
    erp_sql_f    varchar2(2000);
    error_msg_f  varchar2(2000);
    is_equal     number;
  begin
    return_sql := null;
  
    if in_bill_no_f = var_bill_no_debug then
      dbms_output.put_line('select type:STATIC_NOT_TYPE-' ||
                           STATIC_NOT_TYPE);
      dbms_output.put_line('select type:STATIC_ICP_TYPE-' ||
                           STATIC_ICP_TYPE);
      dbms_output.put_line('select type:STATIC_INTF_TYPE-' ||
                           STATIC_INTF_TYPE);
      dbms_output.put_line('select type:STATIC_BILL_TYPE-' ||
                           STATIC_BILL_TYPE);
    
      dbms_output.put_line('in_bill_no_f:' || in_bill_no_f ||
                           ',in_transaction_type_f:' ||
                           in_transaction_type_f);
    end if;
    -- 有差异，查找差异原因
    if in_transaction_type_f = STATIC_NOT_TYPE then
      error_msg_f := 'PO单-业务单据类型未设置事务类型';
    elsif in_transaction_type_f = STATIC_ICP_TYPE then
      begin
        --dbms_output.put_line('length:' || lengthb(select_sql_f));
        if in_bill_no_f = var_bill_no_debug then
          dbms_output.put_line('111:');
        end if;
        error_msg_f := f_get_icp_result(in_entity_id_f, in_bill_no_f);
      end;
    elsif in_transaction_type_f = STATIC_INTF_TYPE then
      begin
        if in_bill_no_f = var_bill_no_debug then
          dbms_output.put_line('222:');
        end if;
        --dbms_output.put_line('length:' || lengthb(select_sql_f));
        error_msg_f := f_get_intf_result(in_entity_id_f, in_bill_no_f);
      end;
    elsif in_transaction_type_f = STATIC_BILL_TYPE then
      begin
        if in_bill_no_f = var_bill_no_debug then
          dbms_output.put_line('333:');
        end if;
        --dbms_output.put_line('length:' || lengthb(select_sql_f));
        error_msg_f := f_get_bill_result(in_entity_id_f, in_bill_no_f);
      end;
    end if;
  
    if in_bill_no_f = var_bill_no_debug then
      dbms_output.put_line('error_msg_f:' || error_msg_f);
    end if;
  
    -- 更新原因
    if error_msg_f is not null then
      return_sql := ' update t_inv_taction_reconciliation rec ' ||
                    ' set rec.remark = ''' || error_msg_f ||
                    ''' where rec.business_num = ''' || in_bill_no_f ||
                    '''   and rec.entity_id =' || in_entity_id_f ||
                    '     and rec.reconciliation_type = ''PO''  ';
    end if;
  
    return return_sql;
  end;

  -- 合并
  function f_get_all_inv_transaction_sql(in_entity_id_f  in varchar2,
                                         in_start_date_f in varchar2,
                                         in_end_date_f   in varchar2)
    return varchar2 is
    return_sql   varchar2(30000);
    select_sql_f varchar2(30000);
    erp_sql_f    varchar2(2000);
    error_msg_f  varchar2(2000);
    is_equal     number;
  begin
    return_sql := null;
  
    return_sql := 'insert into cims.t_inv_taction_reconciliation ' ||
                  '  (entity_id, ' || '   business_type, ' ||
                  '   business_num, ' || '   reconciliation_time, ' ||
                  '   reconciliation_flag, ' || '   status, ' ||
                  '   inv_code, ' || '   item_code, ' || '   cims_qty, ' ||
                  '   gerp_qty, ' || '   remark, ' || '   created_by, ' ||
                  '   creation_date, ' || '   last_updated_by, ' ||
                  '   last_update_date, ' ||
                  '   reconciliation_type,erp_order_header_id,erp_logist_header_id) ' ||
                  '  select ' || in_entity_id_f || ' entity_id, ' ||
                  '         bill_type.bill_type_name business_type, ' ||
                  '         bill_all.business_num business_num, ' ||
                  '         sysdate reconciliation_time, ' ||
                  '         ''00'' reconciliation_flag, ' ||
                  '         decode(sign(cims_qty - gerp_qty), 0, ''00'', ''01'') status, ' ||
                  '         bill_all.inv_code, ' ||
                  '         bill_all.item_code, ' ||
                  '         bill_all.cims_qty, ' ||
                  '         bill_all.gerp_qty, ' ||
                  '         decode(sign(nvl(cims_qty, 0) - nvl(gerp_qty, 0)), ' ||
                  '                -1, ' ||
                  '                ''PO单有差异-待确认'', ' ||
                  '                0, ' ||
                  '                ''PO单无差异'', ' ||
                  '                1, ' ||
                  '                ''PO单有差异-待确认'') remark, ' ||
                  '         ''SYS'' created_by, ' ||
                  '         sysdate creation_date, ' ||
                  '         ''SYS'' last_updated_by, ' ||
                  '         sysdate last_update_date, ' ||
                  '         ''PO'' reconciliation_type, ' ||
                  '         po.erp_order_header_id,' ||
                  '         po.erp_logist_header_id ' ||
                  '    from (select business_num,inv_code,item_code,sum(gerp_qty) gerp_qty,sum(cims_qty) cims_qty from (' ||
                  ' select inv.business_num, ' ||
                  '       inv.inventory_code inv_code, ' ||
                  '       inv.item_code, ' || '       0 gerp_qty, ' ||
                  '       inv.transaction_quantity cims_qty ' ||
                  '  from cims.t_inv_transaction_history inv ' ||
                  ' where inv.entity_id =' || in_entity_id_f ||
                  '   and exists (select 1 ' ||
                  '          from cims.t_inv_po_headers po ' ||
                  '         where po.entity_id =' || in_entity_id_f ||
                  '           and po.po_num = inv.business_num) ' ||
                  ---- 2015.9.7排除推广物料单 --启用T打头进行排除
                  '    and inv.item_code not like ''T%'' '||
                  /*'   and not exists (select 1 ' ||
                  '          from cims.t_inv_po_headers po,cims.t_pmt_order_header pmt ' ||
                  '         where po.entity_id =' || in_entity_id_f ||
                  '           and po.sched_order_num = pmt.order_num  '||
                  '           and po.old_po_num is null '||
                  '           and po.po_num = inv.business_num) ' ||*/
                  '    and not exists(select 1 from cims.t_inv_taction_reconciliation rec ' ||
                  '        where rec.business_num=inv.business_num and rec.reconciliation_type=''PO'')' ||
                  'union all ' ||
                  'select /*+ DRIVING_SITE(inv_erp) */ inv_erp.attribute13          business_num, ' ||
                  '       inv_erp.subinventory_code    inv_code, ' ||
                  '       mtl.segment1                 item_code, ' ||
                  '       inv_erp.transaction_quantity gerp_qty, ' ||
                  '       0                            cims_qty ' ||
                  '  from apps.mtl_material_transactions@mdims2mderp inv_erp, ' ||
                  '       apps.mtl_system_items_b@mdims2mderp        mtl ' ||
                  ' where 1 = 1 ' ||
                  '   and inv_erp.inventory_item_id = mtl.inventory_item_id ' ||
                  '   and inv_erp.organization_id = mtl.organization_id ' ||
                  '   and inv_erp.transaction_date > ' ||
                  '       to_date(''' || in_start_date_f ||
                  ''', ''yyyy-mm-dd'') ' ||
                  '   and inv_erp.transaction_date < ' ||
                  '       to_date(''' || in_end_date_f ||
                  ''', ''yyyy-mm-dd'') ' || '   and exists (select 1 ' ||
                  '          from cims.t_inv_po_headers po ' ||
                  '         where po.entity_id =' || in_entity_id_f ||
                  '           and po.po_num = inv_erp.attribute13) ' ||
                  '    and mtl.segment1 not like ''T%'' '||
                   '   and inv_erp.attribute11 = ''CIMS'' ' ||
                  '    and (inv_erp.organization_id,inv_erp.subinventory_code) in (select distinct inv.organization_id,inv.inventory_code  ' ||
                  '      from cims.t_inv_inventories inv ' ||
                  '     where inv.entity_id =' || in_entity_id_f ||
                  '      and inv.inventory_type not in(''08'',''09''))' ||
                 /*'   and exists (select 1 ' ||
                                   '          from cims.t_inv_inventories inv ' ||
                                   '         where inv.entity_id =' || in_entity_id_f ||
                                   '           and inv.organization_id = inv_erp.organization_id ' ||
                                   '           and inv.inventory_code = inv_erp.subinventory_code ' ||
                                   '           and inv.inventory_type not in (''08'', ''09'')) ' || */
                  '    and not exists(select 1 from cims.t_inv_taction_reconciliation rec ' ||
                  '        where rec.business_num=inv_erp.attribute13 and rec.reconciliation_type=''PO'')' ||
                  ' union all ' ||
                  '  select /*+ DRIVING_SITE(inv_erp) */ inv_erp.transaction_reference business_num, ' ||
                  '         inv_erp.subinventory_code     inv_code, ' ||
                  '         mtl.segment1                  item_code, ' ||
                  '         inv_erp.transaction_quantity  gerp_qty, ' ||
                  '         0                             cims_qty ' ||
                  '    from apps.mtl_material_transactions@mdims2mderp inv_erp, ' ||
                  '         apps.mtl_system_items_b@mdims2mderp        mtl ' ||
                  '   where 1 = 1 ' ||
                  '          and inv_erp.inventory_item_id = mtl.inventory_item_id ' ||
                  '     and inv_erp.organization_id = mtl.organization_id ' ||
                  '     and inv_erp.transaction_date > ' ||
                  '         to_date(''' || in_start_date_f ||
                  ''', ''yyyy-mm-dd'') ' ||
                  '     and inv_erp.transaction_date < ' ||
                  '         to_date(''' || in_end_date_f ||
                  ''', ''yyyy-mm-dd'') ' || '     and exists (select 1 ' ||
                  '            from cims.t_inv_po_headers po ' ||
                  '           where po.entity_id =' || in_entity_id_f ||
                  '             and po.po_num = inv_erp.transaction_reference)    ' ||
                  '    and mtl.segment1 not like ''T%'' '||
                  '    and (inv_erp.organization_id,inv_erp.subinventory_code) in (select distinct inv.organization_id,inv.inventory_code  ' ||
                  '      from cims.t_inv_inventories inv ' ||
                  '     where inv.entity_id =' || in_entity_id_f ||
                  '      and inv.inventory_type not in(''08'',''09''))' ||
                 /*'     and exists (select 1 ' ||
                                   '            from cims.t_inv_inventories inv ' ||
                                   '           where inv.entity_id =' || in_entity_id_f ||
                                   '             and inv.organization_id = inv_erp.organization_id ' ||
                                   '             and inv.inventory_code = inv_erp.subinventory_code ' ||
                                   '             and inv.inventory_type not in (''08'', ''09'')) ' || */
                  '    and not exists(select 1 from cims.t_inv_taction_reconciliation rec ' ||
                  '        where rec.business_num=inv_erp.transaction_reference and rec.reconciliation_type=''PO'')' ||
                  '  union all ' ||
                  '      select /*+ DRIVING_SITE(inv_erp) */ po_erp.segment1              business_num, ' ||
                  '             inv_erp.subinventory_code    inv_code, ' ||
                  '             mtl.segment1                 item_code, ' ||
                  '             inv_erp.transaction_quantity gerp_qty, ' ||
                  '             0                            cims_qty ' ||
                  '        from apps.po_headers_all@mdims2mderp            po_erp, ' ||
                  '             apps.rcv_transactions@mdims2mderp          po_rcv, ' ||
                  '             apps.mtl_material_transactions@mdims2mderp inv_erp, ' ||
                  '             apps.mtl_system_items_b@mdims2mderp        mtl ' ||
                  '       where po_erp.po_header_id = po_rcv.po_header_id ' ||
                  '         and inv_erp.transaction_source_id = po_rcv.po_header_id ' ||
                  '         and inv_erp.source_line_id = po_rcv.transaction_id ' ||
                  '         and inv_erp.rcv_transaction_id = po_rcv.transaction_id ' ||
                  '         and inv_erp.inventory_item_id = mtl.inventory_item_id ' ||
                  '         and inv_erp.organization_id = mtl.organization_id ' ||
                  '         and inv_erp.transaction_date > ' ||
                  '             to_date(''' || in_start_date_f ||
                  ''', ''yyyy-mm-dd'') ' ||
                  '         and inv_erp.transaction_date < ' ||
                  '             to_date(''' || in_end_date_f ||
                  ''', ''yyyy-mm-dd'') ' ||
                  '         and exists (select 1 ' ||
                  '                from cims.t_inv_po_headers po ' ||
                  '               where po.entity_id =' || in_entity_id_f ||
                  '                 and po.po_num = po_erp.segment1) ' ||
                  '    and mtl.segment1 not like ''T%'' '||
                  '    and (inv_erp.organization_id,inv_erp.subinventory_code) in (select distinct inv.organization_id,inv.inventory_code  ' ||
                  '      from cims.t_inv_inventories inv ' ||
                  '     where inv.entity_id =' || in_entity_id_f ||
                  '      and inv.inventory_type not in(''08'',''09''))' ||
                 /*'         and exists ' || '       (select 1 ' ||
                                   '                from cims.t_inv_inventories inv ' ||
                                   '               where inv.entity_id =' || in_entity_id_f ||
                                   '                 and inv.organization_id = inv_erp.organization_id ' ||
                                   '                 and inv.inventory_type not in (''08'', ''09'') ' ||
                                   '                 and inv.inventory_code = inv_erp.subinventory_code) ' || */
                  '    and not exists(select 1 from cims.t_inv_taction_reconciliation rec ' ||
                  '        where rec.business_num=po_erp.segment1 and rec.reconciliation_type=''PO'')' ||
                  ')  group by business_num,inv_code,item_code) bill_all,cims.t_inv_po_headers po, cims.t_inv_bill_types bill_type ' ||
                  '   where 1 = 1 and  po.entity_id =' || in_entity_id_f ||
                  '     and po.po_type_id = bill_type.bill_type_id ' ||
                  '     and po.po_num=bill_all.business_num ';
  
    return return_sql;
  end;
begin
  -- Test statements here

  -- 初始化参数
  --v_entity_id := 10;
  v_entity_id    := I_ENTITY_ID;
  str_start_date := to_char(sysdate - 60, 'yyyy-mm-dd');
  --str_end_date   := '2015-01-23';
  str_end_date := to_char(sysdate + 1, 'yyyy-mm-dd');

  str_status_end := '14'; --单据最终状态-接收

  b_immediate_commit := true; -- 全过程处理一次完成

  --- 删除对账不成功单据
  str_delete_sql := ' delete cims.t_inv_taction_reconciliation rec ' ||
                    '  where rec.entity_id = ' || v_entity_id ||
                    '   and rec.reconciliation_type = ''PO''' ||
                    '   and exists (select 1 ' ||
                    '          from cims.t_inv_taction_reconciliation rec2 ' ||
                    '         where rec.business_num = rec2.business_num ' ||
                    '           and rec2.status = ''01'' ' ||
                    '           and rec2.reconciliation_type = ''PO'') ';

  --dbms_output.put_line('11');
  execute immediate str_delete_sql;
  if b_immediate_commit then
    commit;
  end if;

  --不参与对账单据
  str_insert_sql_rec := f_get_n_reconciliation(v_entity_id);

  --execute immediate str_select_sql;
  --dbms_output.put_line('011');
  --execute immediate str_select_sql_rec;
  if str_insert_sql_rec is not null then
    execute immediate str_insert_sql_rec;
    if b_immediate_commit then
      commit;
    end if;
  end if;

  --记录开始时间,用于限定更新范围
  select to_char(sysdate, 'yyyy-mm-dd hh24:mi:ss')
    into str_start_time
    from dual;

  str_insert_sql_rec := null;
  str_insert_sql_rec := f_get_all_inv_transaction_sql(v_entity_id,
                                                      str_start_date,
                                                      str_end_date);
  if str_insert_sql_rec is not null then
    execute immediate str_insert_sql_rec;
    if b_immediate_commit then
      commit;
    end if;
  end if;

  --记录结束时间
  select to_char(sysdate, 'yyyy-mm-dd hh24:mi:ss')
    into str_end_time
    from dual;

  -- 处理普通采购红冲单(源PO退回)
  for po_red_diff01 in c_reconciliation_po_red_diff(v_entity_id,
                                                    str_start_time,
                                                    str_end_time) loop
    str_msg            := null;
    str_insert_sql_rec := '';
  
    i_transaction_type := f_get_transaction_type(po_red_diff01.erp_trancation);
  
    -- 普通采购订单
    if i_transaction_type = STATIC_BILL_TYPE then
    
      -- 获取ERP退货库存数量
      i_qty_temp := f_get_po_return_qty(po_red_diff01.bill_no,
                                        po_red_diff01.organization_id);
    
      if i_qty_temp = po_red_diff01.cims_qty then
      
        str_insert_sql_rec := ' update cims.t_inv_taction_reconciliation rec ' ||
                              ' set rec.status           = ''00'', ' ||
                              '  rec.last_update_date = sysdate + 1 / (24 * 60), ' ||
                              '  rec.gerp_qty         = ' || i_qty_temp || ', ' ||
                              '  rec.remark           = ''原单退回数量相同'' ' ||
                              '  where rec.entity_id = ' || v_entity_id ||
                              '   and exists (select 1 ' ||
                              '          from cims.t_inv_po_headers po ' ||
                              '         where po.po_num = rec.business_num ' ||
                              '           and rec.entity_id = po.entity_id ' ||
                              '           and po.old_po_num = ''' ||
                              po_red_diff01.bill_no || ''') ';
      else
        str_msg := f_get_intf_result(v_entity_id, po_red_diff01.bill_no);
      
        str_insert_sql_rec := ' update cims.t_inv_taction_reconciliation rec ' ||
                              ' set rec.status           = ''01'', ' ||
                              '  rec.last_update_date = sysdate, ' ||
                              '  rec.gerp_qty         = ' || i_qty_temp || ', ' ||
                              '  rec.remark           = ''原单退回数量不同,' ||
                              str_msg || ''' ' ||
                              '  where rec.entity_id = ' || v_entity_id ||
                              '   and exists (select 1 ' ||
                              '          from cims.t_inv_po_headers po ' ||
                              '         where po.po_num = rec.business_num ' ||
                              '           and rec.entity_id = po.entity_id ' ||
                              '           and po.old_po_num = ''' ||
                              po_red_diff01.bill_no || ''') ';
      end if; -- if i_qty_temp = po_red_diff01.cims_qty then
    
      if str_insert_sql_rec is not null then
        execute immediate str_insert_sql_rec;
        if b_immediate_commit then
          commit;
        end if;
      end if;
    
    end if; -- if i_transaction_type = STATIC_BILL_TYPE then
  
  end loop;

  for po_diff01 in c_reconciliation_po_diff(v_entity_id,
                                            str_start_time,
                                            str_end_time) loop
    str_msg            := null;
    str_insert_sql_rec := '';
  
    i_transaction_type := f_get_transaction_type(po_diff01.erp_trancation);
  
    str_insert_sql_rec := f_get_diff_result(i_transaction_type,
                                            v_entity_id,
                                            po_diff01.bill_no);
    if str_insert_sql_rec is not null then
      execute immediate str_insert_sql_rec;
      if b_immediate_commit then
        commit;
      end if;
    end if;
  
  end loop;

  commit;

end P_INV_PO_TRANSACTION;
/

