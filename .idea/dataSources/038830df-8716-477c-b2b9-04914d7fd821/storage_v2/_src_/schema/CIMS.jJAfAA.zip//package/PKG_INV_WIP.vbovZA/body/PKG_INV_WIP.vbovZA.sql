create Package Body      Pkg_Inv_Wip Is

  v_Nl      Constant Varchar2(2) := Chr(13) || Chr(10); --换行
  v_Null    Constant Varchar2(4) := 'NULL'; --空值
  v_True    Constant Varchar2(2) := 'Y';
  v_False   Constant Varchar2(2) := 'N';
  v_Close   Constant Varchar2(2) := 'C'; --关闭
  v_Result  Constant Number := 0; --成功返回
  v_Success Constant Varchar2(10) := 'SUCCESS';
  v_Base_Exception Exception; --自定义异常
  v_Ar_PULL  Constant Varchar2(10) := 'PULL'; --拉式
  v_Ar_Push Constant Varchar2(10) := 'PUSH'; --推式

  Procedure p_Inv_Wip Is
    Cursor Wip_Intf_Cur Is
      Select * From t_Inv_Wip_In_Info_Intf;
    Cursor Wip_Cur(Code In Varchar2) Is
      Select * From t_Inv_Wip_In_Info Where Wip_Entity_Code = Code;
    Wip_Intf_Row t_Inv_Wip_In_Info_Intf%Rowtype;
    Wip_Row      t_Inv_Wip_In_Info%Rowtype;
    Finishedqty  Number(28);
  Begin
    Begin
      Open Wip_Intf_Cur;
      Loop
        Fetch Wip_Intf_Cur
          Into Wip_Intf_Row;
        Exit When Wip_Intf_Cur%Notfound;
        Update t_Inv_Wip_In_Info
           Set Wip_Entity_Code = Wip_Intf_Row.Enti_Code
         Where Wip_Entity_Code = Wip_Intf_Row.Enti_Code;
        If Sql%Notfound Then
          Insert Into t_Inv_Wip_In_Info
            (Wip_Entity_Id,
             Storage_Name,
             Produce_Qty,
             Storage_Id,
             Storage_Code,
             Entity_Id,
             Wip_Entity_Code,
             Wip_Entity_Desc,
             Producing_Area_Id,
             Producing_Area_Name,
             Enti_End_Date,
             End_Flag,
             Item_Code,
             Item_Name,
             Finished_Qty,
             Exec_Qty,
             Lock_Qty,
             Intf_Time,
             Remark,
             Created_By,
             Creation_Date,
             Last_Updated_By,
             Last_Update_Date,
             Can_Qty,
             Now_Qty,
             Uom_Code)

            Select Seq_Inv_Row_Id.Nextval,
                   Aa.Storage_Name,
                   Aa.Produce_Qty,
                   Aa.Storage_Id,
                   Aa.Storage_Code,
                   Aa.Entity_Id,
                   Aa.Enti_Code,
                   Aa.Enti_Name,
                   Aa.Producing_Area_Id,
                   Aa.Producing_Area_Name,
                   Aa.Enti_End_Date,
                   Aa.End_Flag,
                   Aa.Item_Code,
                   Aa.Item_Name,
                   Aa.Finished_Qty,
                   Aa.Exec_Qty,
                   Aa.Lock_Qty,
                   Aa.Intf_Time,
                   Aa.Remark,
                   Aa.Created_By,
                   Aa.Creation_Date,
                   Aa.Last_Updated_By,
                   Aa.Last_Update_Date,
                   Aa.Can_Qty,
                   Aa.Now_Qty,
                   Aa.Uom_Code
              From (Select e.Storage_Name,
                           Sum(b.Pln_Request_Qty) Produce_Qty,
                           e.Storage_Id,
                           e.Storage_Code,
                           a.Entity_Id,
                           a.Enti_Code,
                           a.Enti_Name,
                           a.Producing_Area_Id,
                           --A.PRODUCING_AREA_CDOE,
                           a.Producing_Area_Name,
                           a.Enti_End_Date,
                           a.End_Flag,
                           a.Item_Code,
                           a.Item_Name,
                           a.Finished_Qty,
                           a.Exec_Qty,
                           a.Lock_Qty,
                           a.Intf_Time,
                           a.Remark,
                           a.Created_By,
                           a.Creation_Date,
                           a.Last_Updated_By,
                           a.Last_Update_Date,
                           a.Can_Qty,
                           a.Now_Qty,
                           a.Uom_Code
                      From t_Inv_Wip_In_Info_Intf       a,
                           t_Inv_Intf                   b,
                           t_Pln_Order_Line             c,
                           t_Pln_Order_Head             d,
                           t_Inv_Logistics_Ship_To_Priv e
                     Where a.Enti_Code = b.Enti_Code
                       And b.Detail_Id = c.Order_Line_Id
                       And c.Order_Head_Id = d.Order_Head_Id
                       And d.Sales_Center_Code = e.Sales_Center_Code
                       And a.Enti_Code = Wip_Intf_Row.Enti_Code
                       And e.Producing_Area_Id =
                           Wip_Intf_Row.Producing_Area_Id
                     Group By e.Storage_Name,
                              e.Storage_Id,
                              e.Storage_Code,
                              a.Entity_Id,
                              a.Enti_Code,
                              a.Enti_Name,
                              a.Producing_Area_Id,
                              --A.PRODUCING_AREA_CDOE,
                              a.Producing_Area_Name,
                              a.Enti_End_Date,
                              a.End_Flag,
                              a.Item_Code,
                              a.Item_Name,
                              a.Finished_Qty,
                              a.Exec_Qty,
                              a.Lock_Qty,
                              a.Intf_Time,
                              a.Remark,
                              a.Created_By,
                              a.Creation_Date,
                              a.Last_Updated_By,
                              a.Last_Update_Date,
                              a.Can_Qty,
                              a.Now_Qty,
                              a.Uom_Code) Aa;

        Else
          Finishedqty := Wip_Intf_Row.Finished_Qty;
          Open Wip_Cur(Wip_Intf_Row.Enti_Code);
          Loop
            Fetch Wip_Cur
              Into Wip_Row;
            Exit When Wip_Cur%Notfound;

            If ((Wip_Row.Finished_Qty < Wip_Row.Produce_Qty) And
               (Wip_Row.Produce_Qty <= Finishedqty)) Then
              Update t_Inv_Wip_In_Info
                 Set Finished_Qty = Wip_Row.Produce_Qty
               Where Wip_Entity_Code = Wip_Row.Wip_Entity_Code;
              Finishedqty := Finishedqty - Wip_Row.Produce_Qty;

            Elsif ((Wip_Row.Finished_Qty < Wip_Row.Produce_Qty) And
                  (Wip_Row.Produce_Qty > Finishedqty) And
                  (Wip_Row.Finished_Qty < Finishedqty)) Then
              Update t_Inv_Wip_In_Info
                 Set Finished_Qty = Finishedqty
               Where Wip_Entity_Code = Wip_Row.Wip_Entity_Code;
              Finishedqty := 0;
            End If;
          End Loop;
          Close Wip_Cur;

        End If;
      End Loop;
      Close Wip_Intf_Cur;
    End;
  End;
  ----------------------------------------------------------------------
  -- AUTHOR  : liugsh
  -- CREATED : 2014-08-08
  -- PURPOSE : 工单信息
  ----------------------------------------------------------------------
  Procedure p_Inv_Wip_Erp(p_Org_Id    In Number,
                          p_User_Code In Varchar2,
                          p_Result    Out Varchar2) Is
    Cursor Wip_Intf_Cur Is
      Select Ie.*
        From Intf_Inv_Wip_In_Info_Erp Ie
       Where Ie.Intf_State = 'I'
         --And ie.wip_entity_name = 'Z1冀20150315300101'
         And Ie.Organization_Id = p_Org_Id; --接口表游标

    Cursor Wip_Cur(p_wip_entity_id In Varchar2) Is
      Select * From t_Inv_Wip_In_Info Where Wip_Entity_id = p_wip_entity_id; --信息表游标

    Wip_Intf_Row Wip_Intf_Cur%Rowtype; --接口表记录
    Wip_Row      t_Inv_Wip_In_Info%Rowtype; --信息表记录
    Finishedqty  Number(28); --
    v_Value      Varchar2(2000);
    v_Count      Number;
    v_Item_Id        Number;
    v_Item_Name      Varchar2(240);
    v_Message        VARCHAR2(2000);
    v_Po_Area_id     Number;
    v_Po_Area_code   varchar2(100);
    v_po_Area_Name   varchar2(100);
    v_Po_Org_id      Number;
    v_entity_id      Number;
    v_detial_item_code varchar2(100);  --订单明细行产品编码
    V_Wip_count          Number;  --工单对应工单与订单关系行数
    v_Order_Number varchar2(2000); --工单对应的订单拼接的串 by sushu 2016-08-03
    v_Lg_Order_Number varchar2(3000); --工单对应的计划订单所对应的提货订单 by sushu 2016-08-08



  Begin
    --把JAVA的事务先提交到数据库防止出错后被回滚
    Commit;
    p_Result := v_Success;

    Update Intf_Inv_Wip_In_Info_Erp e
       Set e.Intf_State = 'E', e.Intf_Err_Msg = '无产品编码信息'
     Where e.Organization_Id = p_Org_Id
       And e.Intf_State = 'I'
       And e.Primary_Item_Name Is Null;


    --更新工单与订单匹配关系数据
    Update Intf_Pln_Wip_Order_Relation Wor
       Set Wor.Intf_Status  = 'E',
           Wor.Intf_Err_Msg = '存在订单与工单关系，但无工单信息'
     Where wor.organization_id = p_Org_Id
     and Not Exists
     (Select 1
              From Intf_Inv_Wip_In_Info_Erp Iie
             Where Iie.Wip_Entity_Id = Wor.Wip_Entity_Id
               And Iie.Organization_Id = Wor.Organization_Id)
                and Wor.Intf_Status  = 'I';

    Begin
      Open Wip_Intf_Cur; --循环接口游标，如果有值存在，则更新，否则插入
      Loop
        --从接口表游标取一行数据
        Fetch Wip_Intf_Cur
          Into Wip_Intf_Row;
        Exit When Wip_Intf_Cur%Notfound;
        p_Result := v_Success;


       --检查工单是否存在 工单与订单匹配关系，没有则不更新工单到IMS工单信息表,zhagnwm 20150923
        Begin
          --获取产品名称
          SELECT Count(1)
            INTO V_Wip_count
            FROM Intf_Pln_Wip_Order_Relation BI
           WHERE BI.Wip_Entity_Id = WIP_INTF_ROW.Wip_Entity_Id
             /*AND EXISTS (SELECT 1
                    FROM CIMS.T_INV_ORGANIZATION IO
                   WHERE IO.ORGANIZATION_ID = P_ORG_ID
                     AND IO.ENTITY_ID = BI.ENTITY_ID)*/;
            if V_Wip_count=0 then
              v_Message := '不存在工单与订单对应关系' || v_Nl ||
                        Sqlerrm;
              Update Intf_Inv_Wip_In_Info_Erp ie
               Set ie.intf_state      = 'E',
                   ie.Intf_Err_Msg     = v_Message,
                   ie.Last_Updated_By  = p_User_Code,
                   ie.Last_Update_Date = Sysdate
               Where ie.Intf_Id = Wip_Intf_Row.Intf_Id;

              Commit;
              Goto DONOTHIING;
            End If;
        Exception
          When Others Then
            Null;
            Commit;
            Goto DONOTHIING;
        End;

        ---- 获取主体ID zhangwm 20150923
        begin
           select entity_id , item_code
             into  v_entity_id,v_detial_item_code
             FROM t_pln_order_detail s
             where exists (select 1
                               from intf_pln_wip_order_relation r
                               where r.wip_entity_id =WIP_INTF_ROW.wip_entity_id
                                 and r.order_detail_id = s.order_detail_id)
                                 group By s.entity_id,
                                          s.item_code;

              if(v_detial_item_code <> WIP_INTF_ROW.PRIMARY_ITEM_NAME )  then
                  v_Message := '工单产品编码：' || Wip_Intf_Row.PRIMARY_ITEM_NAME || '订单明细产品编码：' || v_detial_item_code||'不一致！' ||v_Nl || Sqlerrm;
                        Update Intf_Inv_Wip_In_Info_Erp ie
                         Set ie.intf_state      = 'E',
                              ie.Intf_Err_Msg     = v_Message,
                               ie.Last_Updated_By  = p_User_Code,
                              ie.Last_Update_Date = Sysdate
                             Where ie.Intf_Id = Wip_Intf_Row.Intf_Id;
                     Commit;
                     Goto DONOTHIING;
             end if;
        exception
             when others then
              p_Result  :=  '无法获取主体信息，确认该工单是否有对应关系。没有对应关系无法获取主体。不同步到正式表';
              Update Intf_Inv_Wip_In_Info_Erp ie
               Set ie.intf_state      = 'E',
                   ie.Intf_Err_Msg     = v_Message,
                   ie.Last_Updated_By  = p_User_Code,
                   ie.Last_Update_Date = Sysdate
               Where ie.Intf_Id = Wip_Intf_Row.Intf_Id;

              Commit;
              Goto DONOTHIING;
        end;

        --add by wildwind 20150502 根据IT要求,工单产品不为内销产品的工单不插入CIMS工单表
        Begin
          --获取产品ID
          SELECT BI.ITEM_ID, BI.ITEM_NAME
            INTO V_ITEM_ID, V_ITEM_NAME
            FROM T_BD_ITEM BI
           WHERE BI.ITEM_CODE = WIP_INTF_ROW.PRIMARY_ITEM_NAME
                 AND  BI.Entity_Id = v_entity_id
             /*AND EXISTS (SELECT 1
                    FROM CIMS.T_INV_ORGANIZATION IO
                   WHERE IO.ORGANIZATION_ID = P_ORG_ID
                     AND IO.ENTITY_ID = BI.ENTITY_ID)*/;
        Exception
          When Others Then
            Null;
            v_Message := '获取产品ID失败，产品编码：' || Wip_Intf_Row.PRIMARY_ITEM_NAME || v_Nl ||
                        Sqlerrm;
            Update Intf_Inv_Wip_In_Info_Erp ie
               Set ie.intf_state      = 'E',
                   ie.Intf_Err_Msg     = v_Message,
                   ie.Last_Updated_By  = p_User_Code,
                   ie.Last_Update_Date = Sysdate
             Where ie.Intf_Id = Wip_Intf_Row.Intf_Id;
            Commit;
            Goto DONOTHIING;
        End;
         --获取中转产地ID,编码，名称，组织ID  zhangwm begin
        begin
        select a.producing_area_id,
               a.producing_area_code,
               a.producing_area_name,
               a.mrp_org_id
          into v_Po_Area_id,
               v_Po_Area_code,
               v_po_Area_Name,
               v_Po_Org_id
          from cims.t_pln_producing_area a
         where a.producing_area_id =
               nvl((Select a.Po_Area_Id
                     From t_inv_producting_item a
                    Where a.item_code = WIP_INTF_ROW.PRIMARY_ITEM_NAME
                      and a.entity_id = v_entity_id
                      And (Trunc(Sysdate) >= a.begin_date Or
                          a.begin_date Is Null)
                      And (Trunc(Sysdate) <= a.end_date Or
                          a.end_date Is Null)),
                   (Select a.Producing_Area_Id
                      From t_Pln_Producing_Area a
                     Where a.Mrp_Org_Id = p_Org_Id
                           and a.entity_id = v_entity_id));
        exception
         when others then
         p_Result  :=  '无法获取产地信息，请维护基础数据';
        end;


/*        --根据IT要求，不从产地产品维护表取中转产地的信息，从订单行表取数据    by sushu 2016-03-29
        Begin
          Select Pa.Producing_Area_Id,
                 Pa.Producing_Area_Code,
                 Pa.Producing_Area_Name,
                 Pa.Mrp_Org_Id
            Into v_Po_Area_Id, v_Po_Area_Code, v_Po_Area_Name, v_Po_Org_Id
            From t_Pln_Producing_Area Pa
           Where Pa.Producing_Area_Id =
                 Nvl((Select Pol.Synt_Producing_Area_Id
                       From Intf_Pln_Wip_Order_Relation Pwor,
                            t_Pln_Order_Detail          Pod,
                            t_Pln_Order_Line            Pol
                      Where Pwor.Wip_Entity_Id = Wip_Intf_Row.Wip_Entity_Id
                        And Pwor.Organization_Id =
                            Wip_Intf_Row.Organization_Id
                        And Pwor.Order_Detail_Id = Pod.Order_Detail_Id
                        And Pod.Order_Line_Id = Pol.Order_Line_Id
                        And Pol.Synt_Order_Flag = 'Y'),
                     (Select a.Producing_Area_Id
                        From t_Pln_Producing_Area a
                       Where a.Mrp_Org_Id = p_Org_Id
                         And a.Entity_Id = v_Entity_Id));
        Exception
          When Others Then
            p_Result  :=  '无法获取对应的虚拟产地信息，' || '工单编码：' || Wip_Intf_Row.Wip_Entity_Name || v_Nl ||
                          '组织ID：' || To_Char(p_Org_Id);
            Update Intf_Inv_Wip_In_Info_Erp Ie
               Set Ie.Intf_State       = 'E',
                   Ie.Intf_Err_Msg     = p_Result,
                   Ie.Last_Updated_By  = p_User_Code,
                   Ie.Last_Update_Date = Sysdate
             Where Ie.Intf_Id = Wip_Intf_Row.Intf_Id;
            Commit;
            Goto DONOTHIING;
        End;*/

        --根据IT要求，获取工单对应的订单信息，把订单号拼接起来一个串 by sushu 2016-08-03
        Begin
          Select To_Char(Wm_Concat(Order_Number))
            Into v_Order_Number
            From (Select Distinct Poh.Order_Number
                    From Intf_Pln_Wip_Order_Relation Wor,
                         t_Pln_Order_Head            Poh,
                         t_Pln_Order_Detail          Pod
                   Where Wor.Wip_Entity_Id = Wip_Intf_Row.Wip_Entity_Id
                     And Wor.Order_Detail_Id = Pod.Order_Detail_Id
                     And Pod.Order_Head_Id = Poh.Order_Head_Id
                     And Pod.Entity_Id = Poh.Entity_Id);
        Exception
          When Others Then
            p_Result := '获取工单对应的订单信息失败，' || '工单编码：' || Wip_Intf_Row.Wip_Entity_Name || v_Nl ||
                        '组织ID：' || To_Char(p_Org_Id);
            Update Intf_Inv_Wip_In_Info_Erp Ie
               Set Ie.Intf_State       = 'E',
                   Ie.Intf_Err_Msg     = p_Result,
                   Ie.Last_Updated_By  = p_User_Code,
                   Ie.Last_Update_Date = Sysdate
             Where Ie.Intf_Id = Wip_Intf_Row.Intf_Id;
            Commit;
            Goto DONOTHIING;
        End;

        --根据IT要求，获取计划订单对应的提货订单号，把提货订单号拼接起来一个串  by sushu 2016-08-08
        Begin
          Select substr(To_Char(Wm_Concat(Order_Number)),1,1499)
            Into v_Lg_Order_Number
            From (Select Distinct Ploh.Order_Number
                    From Intf_Pln_Wip_Order_Relation Wor,
                         t_Pln_Order_Detail          Pod,
                         t_Pln_Lg_Relation           Plr,
                         t_Pln_Lg_Order_Head         Ploh,
                         t_Pln_Lg_Order_Line         plol
                   Where Wor.Wip_Entity_Id = Wip_Intf_Row.Wip_Entity_Id
                     And Wor.Order_Detail_Id = Pod.Order_Detail_Id
                     And Pod.Order_Head_Id = Plr.Order_Head_Id
                     And Plr.Lg_Order_Head_Id = Ploh.Order_Head_Id
                     And Pod.Entity_Id = Plr.Entity_Id
                     And Plr.Entity_Id = Ploh.Entity_Id
                     And wor.Wip_Request_Qty > 0
                     And pod.order_line_id = plr.order_line_id
                     And ploh.order_head_id = plol.order_head_id);
        Exception
          When Others Then
            p_Result := '获取工单对应订单的提货订单信息失败，' || '工单编码：' || Wip_Intf_Row.Wip_Entity_Name || v_Nl ||
                        '组织ID：' || To_Char(p_Org_Id);
            Update Intf_Inv_Wip_In_Info_Erp Ie
               Set Ie.Intf_State       = 'E',
                   Ie.Intf_Err_Msg     = p_Result,
                   Ie.Last_Updated_By  = p_User_Code,
                   Ie.Last_Update_Date = Sysdate
             Where Ie.Intf_Id = Wip_Intf_Row.Intf_Id;
            Commit;
            Goto DONOTHIING;
        End;


        --判断本行数据是否在信息表中存在 通过工单编号ENTI_CODE
        Update t_Inv_Wip_In_Info
           Set Wip_Entity_desc = Wip_Intf_Row.Description --工单号
         Where Wip_Entity_id = Wip_Intf_Row.Wip_Entity_Id
           And Organization_Id = Wip_Intf_Row.Organization_Id; --工单号
        --如果不存在，直接将
        If Sql%Notfound Then
          v_Value := '插入工单信息，工单编码：' || Wip_Intf_Row.Wip_Entity_Name || v_Nl ||
                  '组织ID:' || To_Char(p_Org_Id);



         Insert Into t_Inv_Wip_In_Info
            (Wip_Entity_Id, --工单ID
             --  Storage_Name,
             --   Storage_Id,
             --   Storage_Code,
             Entity_Id,
             Wip_Entity_Code, --工单号
             Wip_Entity_Desc,
             Producing_Area_Id,
             Producing_Area_Name,
             --    Enti_End_Date,
             --    End_Flag,
             Item_Code, --产品编码
             Item_Name, --产品名称
             Produce_Qty, --生产数量
             Finished_Qty, --完工数据
             --   Exec_Qty,
             --   Lock_Qty,
             --   Intf_Time,
             --   Remark,
             Created_By,
             Creation_Date,
             Last_Updated_By,
             Last_Update_Date,
             Can_Qty,
             Now_Qty,
             Uom_Code, --单位编码
             Organization_Id, -- 组织ID
             Seiban_Id, -- seiban ID
             Seiban_Number,
             Sales_Main_Type, -- seiban号
             po_Area_Id,  --中转产地ID
             po_Area_Code, --中转产地编码
             po_Area_Name, --中转产地名称
             po_organization_id,  -- 中转组织ID
             SCHEDULED_START_DATE, --计划开始日期 by sushu 2016-08-03
             SCHEDULED_COMPLETION_DATE, --计划完成日期 by sushu 2016-08-03
             ORDER_NUMBER, --工单对应的订单拼接的串 by sushu 2016-08-03
             LG_OREDER_NUM, --工单对应订单对应的多个提货订单拼接的串 by sushu 2016-08-08
             ENTI_END_DATE, --实际完工日期，chenyj8 2016-10-08
             STATUS_TYPE, --工单状态chenyj8,2016-10-08
             SCHEDULE_GROUP_NAME,   --计划组chenyj8,2017-05-13
             WORKSHOP_INV_CODE, --完工子库，车间仓
             PROD_LINE_CODE     --线体
             )
            Select Aa.Wip_Entity_Id,
                   --   Aa.Storage_Name,
                   --   Aa.Storage_Id,
                   --   Aa.Storage_Code,
                   --   Aa.Entity_Id,
                   v_entity_id,
                   Aa.Wip_Entity_Name, --工单号
                   Aa.Description,
                   (Select a.Producing_Area_Id
                      From t_Pln_Producing_Area a
                     Where a.Mrp_Org_Id = Aa.Organization_Id
                            and a.entity_id = v_entity_id),
                   (Select a.Producing_Area_Name
                      From t_Pln_Producing_Area a
                     Where a.Mrp_Org_Id = Aa.Organization_Id
                           and a.entity_id = v_entity_id),
                   Aa.Primary_Item_Name,
                   Aa.Primary_Item_Desc,
                   Aa.Start_Quantity, -- 起始数量
                   Aa.Quantity_Completed, --完工数量
                   -1 Created_By,
                   Sysdate Creation_Date,
                   -1 Last_Updated_By,
                   Sysdate Last_Update_Date,
                   0,
                   0,
                   Aa.Unit_Code, --单位代码
                   Aa.Organization_Id, --组织ID
                   Aa.Seibanid, --seiban ID
                   Aa.Seibannumber, --seiban 号
                   (Select i.Sales_Main_Type
                      From t_Bd_Item i
                     Where i.Item_Code = Aa.Primary_Item_Name
                       And i.Entity_Id = v_entity_id),
                    v_Po_Area_id,
                    v_Po_Area_code,
                    v_po_Area_Name,
                    v_Po_Org_id,
                    aa.scheduled_start_date, --by sushu 2016-08-03
                    aa.scheduled_completion_date, --by sushu 2016-08-03
                    v_Order_Number, --by sushu 2016-08-03
                    v_Lg_Order_Number, -- by sushu 2016-08-08
                    aa.ENTI_END_DATE, --实际完工日期，chenyj8 2016-10-08
                    to_char(aa.STATUS_TYPE), --工单状态chenyj8,2016-10-08
                    SCHEDULE_GROUP_NAME,    --计划组chenyj8,2017-05-13
                    Aa.Completion_Subinventory, --完工子库，车间仓
                    Aa.PROD_LINE_CODE           --线体
              From Intf_Inv_Wip_In_Info_Erp Aa
             Where Aa.Intf_State = 'I'
               And Aa.Organization_Id = p_Org_Id
               And Aa.Wip_Entity_Id = Wip_Intf_Row.Wip_Entity_Id
               And aa.intf_id = Wip_Intf_Row.Intf_Id;
        Else
          --如果存在，则更新
          Finishedqty := Wip_Intf_Row.Quantity_Completed; --完工数量
          Update t_Inv_Wip_In_Info Wi
             Set Wi.Finished_Qty = Wip_Intf_Row.Quantity_Completed,
                 Wi.Produce_Qty = nvl(Wip_Intf_Row.Start_Quantity, Wi.Produce_Qty),--更新生产数量，chenyj8,2016-10-08
                 Wi.Po_Area_Id = v_Po_Area_id,   --zhangwm 2015-11-13
                 Wi.Po_Area_Code = v_Po_Area_code, --zhangwm 2015-11-13
                 Wi.Po_Area_Name = v_po_Area_Name, --zhangwm 2015-11-13
                 wi.po_organization_id = v_Po_Org_id,  --zhangwm 2015-11-13
                 wi.scheduled_start_date = nvl(Wip_Intf_Row.scheduled_start_date, wi.scheduled_start_date), -- by sushu 2016-08-03,chenyj8,2016-08-22
                 wi.scheduled_completion_date = nvl(Wip_Intf_Row.scheduled_completion_date, wi.scheduled_completion_date), -- by sushu 2016-08-03,chenyj8,2016-08-22
                 wi.ENTI_END_DATE = nvl(Wip_Intf_Row.ENTI_END_DATE, wi.ENTI_END_DATE),--实际完工日期chenyj8,2016-10-08
                 wi.STATUS_TYPE = nvl(to_char(Wip_Intf_Row.STATUS_TYPE), wi.STATUS_TYPE), --工单状态chenyj8,2016-10-08
                 wi.SCHEDULE_GROUP_NAME = nvl(Wip_Intf_Row.SCHEDULE_GROUP_NAME,wi.SCHEDULE_GROUP_NAME),--计划组chenyj8,2017-05-13
                 wi.WORKSHOP_INV_CODE = nvl(Wip_Intf_Row.Completion_Subinventory,wi.WORKSHOP_INV_CODE),--完工子库，车间仓
                 wi.PROD_LINE_CODE = nvl(Wip_Intf_Row.PROD_LINE_CODE,wi.PROD_LINE_CODE)   --线体
           Where Wi.Wip_Entity_Id = Wip_Intf_Row.Wip_Entity_Id
             And Wi.Organization_Id = Wip_Intf_Row.Organization_Id;

           --更新入库完成标识  by sushu 2016-11-30
           Update t_Inv_Wip_In_Info Wi
              Set Wi.End_Flag = Decode(Sign(Wi.Produce_Qty -
                                             Nvl(Wi.Exec_Qty, 0)),
                                        0,
                                        'Y',
                                        'N')
            Where Wi.Wip_Entity_Id = Wip_Intf_Row.Wip_Entity_Id
              And Wi.Organization_Id = Wip_Intf_Row.Organization_Id;

         --modi by lizhen 2015-01-01  以下更新工单实际完工代作废注释掉
          /*Open Wip_Cur(Wip_Intf_Row.Wip_Entity_id);
          Loop
            Fetch Wip_Cur
              Into Wip_Row;
            Exit When Wip_Cur%Notfound;
            v_Value := '插入工单信息，工单编码：' || Wip_Intf_Row.Wip_Entity_Name;
            If ((Wip_Row.Finished_Qty < Wip_Row.Produce_Qty) And
               (Wip_Row.Produce_Qty <= Finishedqty)) Then
              Update t_Inv_Wip_In_Info
                 Set Finished_Qty = Wip_Row.Produce_Qty
               Where Wip_Entity_Code = Wip_Row.Wip_Entity_Code;
              Finishedqty := Finishedqty - Wip_Row.Produce_Qty;

            Elsif ((Wip_Row.Finished_Qty < Wip_Row.Produce_Qty) And
                  (Wip_Row.Produce_Qty > Finishedqty) And
                  (Wip_Row.Finished_Qty < Finishedqty)) Then
              Update t_Inv_Wip_In_Info
                 Set Finished_Qty = Finishedqty
               Where Wip_Entity_Code = Wip_Row.Wip_Entity_Code;
              Finishedqty := 0;
            End If;
          End Loop;
          Close Wip_Cur;*/
        End If;
        --处理完工单信息时，先做COMMIT提交入数据库
        If p_Result  = v_Success Then
          Commit;
        Else
          Rollback;
        End If;

        If p_Result = v_Success Then
          p_Create_Wip_Order_Relation(p_Entity_Id       => v_entity_id, --主体ID
                                      p_Organization_Id => p_Org_Id, --组织ID
                                      p_User_Code       => p_User_Code,
                                      p_Result          => p_Result,
                                      p_Wip_Entity_Id   => Wip_Intf_Row.Wip_Entity_Id --工单ID
                                      );
          --更新工单接口表
          Update Intf_Inv_Wip_In_Info_Erp e
             Set e.Intf_State       = Decode(p_Result, v_Success, 'U', 'W'),
                 e.Intf_Err_Msg     = Decode(p_Result,
                                             v_Success,
                                             Null,
                                             '生成工单与订单匹配信息失败，' || p_Result),
                 e.Last_Update_Date = Sysdate,
                 e.Last_Updated_By  = p_User_Code
           Where e.Organization_Id = p_Org_Id
             And e.Wip_Entity_Id = Wip_Intf_Row.Wip_Entity_Id
             And e.Intf_Id = Wip_Intf_Row.Intf_Id;
        End If;
        Commit;

        <<DONOTHIING>>
            Null;
      End Loop;
      Close Wip_Intf_Cur;
    End;
  Exception
    When v_Base_Exception Then
      Rollback;
      p_Result := '更新ERP工单过程处理失败，' || v_Value || v_Nl || Sqlerrm;
      Pkg_Pln_Pub.p_Write_Job_Log(p_Module_Code          => 'INV',
                                  p_Procedure_Name       => 'p_Inv_Wip_Erp',
                                  p_Error_Msg            => p_Result || v_Nl || '组织ID：' || p_Org_Id,
                                  p_Source_Order_Head_Id => Null,
                                  p_Source_Order_Line_Id => Null,
                                  p_Item_Id              => Null,
                                  p_Inventory_Id         => Null,
                                  p_Quantity             => Null);
    When Others Then
      Rollback;
      p_Result := '更新ERP工单过程处理失败，' || v_Value || v_Nl || Sqlerrm;
      Pkg_Pln_Pub.p_Write_Job_Log(p_Module_Code          => 'INV',
                                  p_Procedure_Name       => 'p_Inv_Wip_Erp',
                                  p_Error_Msg            => p_Result || v_Nl || '组织ID：' || p_Org_Id,
                                  p_Source_Order_Head_Id => Null,
                                  p_Source_Order_Line_Id => Null,
                                  p_Item_Id              => Null,
                                  p_Inventory_Id         => Null,
                                  p_Quantity             => Null);
  End;

  ----------------------------------------------------------------------
  -- Author  : NICRO.LI
  -- Created : 2014-07-29 08:55:53
  -- Purpose : 工单与订单匹配关系接口数据写入正式表
  --           处理接口表数据时，正确的数据处理完后直接保存，失败的则标志为E状态
  ----------------------------------------------------------------------
  Procedure p_Create_Wip_Order_Relation(p_Entity_Id       In Number, --主体ID
                                        p_Organization_Id In Number, --组织ID
                                        p_User_Code       In Varchar2,
                                        p_Result          Out Varchar2,
                                        p_Wip_entity_id   In Number Default Null --工单ID
                                        ) Is
    Cursor c_Wip_Order_Intf Is
      Select *
        From Intf_Pln_Wip_Order_Relation Wor
       Where Wor.Intf_Status = 'I'
         And Wor.Organization_Id = p_Organization_Id
         And Wor.Wip_Entity_Id = Nvl(p_Wip_Entity_Id, Wor.Wip_Entity_Id);

    r_Wip_Order_Intf c_Wip_Order_Intf%Rowtype;
    v_Item_Id        Number;
    v_Item_Name      Varchar2(240);
    v_Order_Line_Id  Number;
    v_Order_Head_Id  Number;
    v_Usble_Inv_Qty  Number; --add by lizhen 2016-09-22 剩余可入库数量
  Begin
    p_Result := v_Success;
    Open c_Wip_Order_Intf;
    Loop
      Fetch c_Wip_Order_Intf
        Into r_Wip_Order_Intf;
      Exit When c_Wip_Order_Intf%Notfound;
      p_Result := v_Success;
      Begin
        --获取产品ID
        Select Bi.Item_Id, Bi.Item_Name
          Into v_Item_Id, v_Item_Name
          From t_Bd_Item Bi
         Where Bi.Entity_Id = p_Entity_Id
           And Bi.Item_Code = r_Wip_Order_Intf.Item_Code;
      Exception
        When Others Then
          Null;
          p_Result := '获取产品ID失败，产品编码：' || r_Wip_Order_Intf.Item_Code || v_Nl ||
                      Sqlerrm;
          Rollback;
          Update Intf_Pln_Wip_Order_Relation r
             Set r.Intf_Status      = 'E',
                 r.Intf_Err_Msg     = p_Result,
                 r.Last_Updated_By  = p_User_Code,
                 r.Last_Update_Date = Sysdate
           Where r.Intf_Id = r_Wip_Order_Intf.Intf_Id;
          Commit;
          Goto LABLE;
      End;
      Begin
        --订单行ID,订单头ID，检查订单是否存在
        Select Oh.Order_Head_Id, Ol.Order_Line_Id
          Into v_Order_Head_Id, v_Order_Line_Id
          From t_Pln_Order_Head   Oh,
               t_Pln_Order_Line   Ol,
               t_Pln_Order_Detail Od
         Where Oh.Entity_Id = p_Entity_Id
           And Oh.Order_Head_Id = Ol.Order_Head_Id
           And Ol.Order_Line_Id = Od.Order_Line_Id
           And Od.Order_Detail_Id = r_Wip_Order_Intf.Order_Detail_Id;
      Exception
        When Others Then
          p_Result := '获取订单信息失败，必须关联订单头行表，订单明细行ID：' ||
                      To_Char(r_Wip_Order_Intf.Order_Detail_Id) || v_Nl ||
                      Sqlerrm;
          Rollback;
          Update Intf_Pln_Wip_Order_Relation r
             Set r.Intf_Status      = 'E',
                 r.Intf_Err_Msg     = p_Result,
                 r.Last_Updated_By  = p_User_Code,
                 r.Last_Update_Date = Sysdate
           Where r.Intf_Id = r_Wip_Order_Intf.Intf_Id;
          Commit;
          Goto LABLE;
      End;
      --add by lizhen 2016-09-22 检查订单匹配数量是否小于工单已入库数量 begin
      Begin
        --chenyj8,20161016修改BUG，v_Usble_Inv_Qty没有记录，则表示0
        Select count(*)--Nvl(Wor.In_Inv_Qty, 0) + Nvl(Wor.Wait_Execute_Qty, 0)
          Into v_Usble_Inv_Qty
          From t_Pln_Wip_Order_Relation Wor
         Where Wor.Organization_Id = r_Wip_Order_Intf.Organization_Id
           And Wor.Wip_Entity_Id = r_Wip_Order_Intf.Wip_Entity_Id
           And Wor.Order_Detail_Id = r_Wip_Order_Intf.Order_Detail_Id;
        IF v_Usble_Inv_Qty > 0 THEN
          Select Nvl(Wor.In_Inv_Qty, 0) + Nvl(Wor.Wait_Execute_Qty, 0)
          Into v_Usble_Inv_Qty
          From t_Pln_Wip_Order_Relation Wor
         Where Wor.Organization_Id = r_Wip_Order_Intf.Organization_Id
           And Wor.Wip_Entity_Id = r_Wip_Order_Intf.Wip_Entity_Id
           And Wor.Order_Detail_Id = r_Wip_Order_Intf.Order_Detail_Id;
        END IF;

      Exception
        When Others Then
          p_Result := '获取订单与工单关系的已入库数量失败，订单明细行ID：' ||
                      To_Char(r_Wip_Order_Intf.Order_Detail_Id) || v_Nl ||
                      Sqlerrm;
          Rollback;
          Update Intf_Pln_Wip_Order_Relation r
             Set r.Intf_Status      = 'E',
                 r.Intf_Err_Msg     = p_Result,
                 r.Last_Updated_By  = p_User_Code,
                 r.Last_Update_Date = Sysdate
           Where r.Intf_Id = r_Wip_Order_Intf.Intf_Id;
          Commit;
          Goto Lable;
      End;
      If Nvl(r_Wip_Order_Intf.Pln_Request_Qty, 0) < Nvl(v_Usble_Inv_Qty, 0) Then
        p_Result := '订单与工单关系的订单匹配数量小于工单已入库数量，不允许更新，订单明细行ID：' ||
                      To_Char(r_Wip_Order_Intf.Order_Detail_Id) || v_Nl ||
                      Sqlerrm;
          Rollback;
          Update Intf_Pln_Wip_Order_Relation r
             Set r.Intf_Status      = 'E',
                 r.Intf_Err_Msg     = p_Result,
                 r.Last_Updated_By  = p_User_Code,
                 r.Last_Update_Date = Sysdate
           Where r.Intf_Id = r_Wip_Order_Intf.Intf_Id;
          Commit;
          Goto Lable;
      Else
        --先更新工单与订单关系表信息
        Update t_Pln_Wip_Order_Relation Wor
           Set Wor.Pln_Request_Qty = r_Wip_Order_Intf.Pln_Request_Qty
         Where Wor.Organization_Id = r_Wip_Order_Intf.Organization_Id
           And Wor.Wip_Entity_Id = r_Wip_Order_Intf.Wip_Entity_Id
           And Wor.Order_Detail_Id = r_Wip_Order_Intf.Order_Detail_Id
           And Nvl(Wor.Pln_Request_Qty, 0) <> Nvl(r_Wip_Order_Intf.Pln_Request_Qty, 0);
      End If;
      --add by lizhen 2016-09-22 检查订单匹配数量是否小于工单已入库数量 end

      Begin
        --先更新工单与订单关系表信息
        Update t_Pln_Wip_Order_Relation Wor
           Set Wor.Date_Released    = to_date(r_Wip_Order_Intf.Date_Released, 'yyyy-mm-dd hh24:mi:ss'),
               Wor.Date_Closed      = to_date(r_Wip_Order_Intf.Date_Closed, 'yyyy-mm-dd hh24:mi:ss'),
               Wor.Wip_Request_Qty  = r_Wip_Order_Intf.Wip_Request_Qty,
               Wor.Wip_Done_Qty     = r_Wip_Order_Intf.Wip_Done_Qty,
               Wor.Scheduled_Start_Date = Nvl(to_date(r_Wip_Order_Intf.Scheduled_Start_Date, 'yyyy-mm-dd hh24:mi:ss'), Wor.Scheduled_Start_Date),
               Wor.Scheduled_Completed_Date = Nvl(to_date(r_Wip_Order_Intf.Scheduled_Completed_Date, 'yyyy-mm-dd hh24:mi:ss'), Wor.Scheduled_Completed_Date),
               Wor.Last_Updated_By  = p_User_Code,
               Wor.Workshop_Inv_Code = Nvl(r_Wip_Order_Intf.Workshop_Inv_Code,Wor.Workshop_Inv_Code),
               Wor.Last_Update_Date = Sysdate
         Where Wor.Organization_Id = r_Wip_Order_Intf.Organization_Id
           And Wor.Wip_Entity_Id = r_Wip_Order_Intf.Wip_Entity_Id
           And Wor.Order_Detail_Id = r_Wip_Order_Intf.Order_Detail_Id;
        If Sql%Notfound Then
          Insert Into t_Pln_Wip_Order_Relation
            (Wip_Order_Id,
             Entity_Id,
             Organization_Id,
             Wip_Entity_Id,
             Wip_Entity_Code,
             Wip_Entity_Desc,
             Item_Id,
             Item_Code,
             Item_Name,
             Wip_Schedule_Qty,
             Pln_Request_Qty,
             In_Inv_Qty,
             Wait_Execute_Qty,
             Order_Detail_Id,
             Order_Line_Id,
             Order_Head_Id,
             Wip_Request_Qty,
             Wip_Done_Qty,
             Scheduled_Start_Date,
             Scheduled_Completed_Date,
             Date_Released,
             Date_Closed,
             Source_Type,
             Created_By,
             Creation_Date,
             Last_Updated_By,
             Last_Update_Date,
             Reamrk,
             Pre_Field_01,
             Pre_Field_02,
             Pre_Field_03,
             Pre_Field_04,
             Pre_Field_05,
             Pre_Field_06,
             Workshop_Inv_Code --完工子库，车间仓
             )
          Values
            (s_Pln_Wip_Order_Relation.Nextval,
             p_Entity_Id,
             r_Wip_Order_Intf.Organization_Id, -- ORGANIZATION_ID,
             r_Wip_Order_Intf.Wip_Entity_Id, --WIP_ENTITY_ID,
             r_Wip_Order_Intf.Wip_Entity_Code, --WIP_ENTITY_CODE,
             r_Wip_Order_Intf.Wip_Entity_Desc, --WIP_ENTITY_DESC,
             v_Item_Id, --ITEM_ID,
             r_Wip_Order_Intf.Item_Code, --ITEM_CODE,
             v_Item_Name, --ITEM_NAME,
             r_Wip_Order_Intf.Wip_Schedule_Qty, --WIP_SCHEDULE_QTY,
             r_Wip_Order_Intf.Pln_Request_Qty, --PLN_REQUEST_QTY,
             0, --IN_INV_QTY,
             0, --WAIT_EXECUTE_QTY,
             r_Wip_Order_Intf.Order_Detail_Id, --ORDER_DETAIL_ID,
             v_Order_Line_Id, --ORDER_LINE_ID,
             v_Order_Head_Id, --ORDER_HEAD_ID,
             r_Wip_Order_Intf.Wip_Request_Qty, --WIP_REQUEST_QTY,
             r_Wip_Order_Intf.Wip_Done_Qty, --WIP_DONE_QTY,
             to_date(r_Wip_Order_Intf.Scheduled_Start_Date, 'yyyy-mm-dd hh24:mi:ss'), --SCHEDULED_START_DATE,
             to_date(r_Wip_Order_Intf.Scheduled_Completed_Date, 'yyyy-mm-dd hh24:mi:ss'), --SCHEDULED_COMPLETED_DATE,
             to_date(r_Wip_Order_Intf.Date_Released, 'yyyy-mm-dd hh24:mi:ss'), --DATE_RELEASED,
             to_date(r_Wip_Order_Intf.Date_Closed, 'yyyy-mm-dd hh24:mi:ss'), --DATE_CLOSED,
             r_Wip_Order_Intf.Source_Type, --SOURCE_TYPE,
             p_User_Code, --CREATED_BY,
             Sysdate, --CREATION_DATE,
             p_User_Code, --LAST_UPDATED_BY,
             Sysdate, --LAST_UPDATE_DATE,
             r_Wip_Order_Intf.Reamrk,
             r_Wip_Order_Intf.Pre_Field_01,
             r_Wip_Order_Intf.Pre_Field_02,
             r_Wip_Order_Intf.Pre_Field_03,
             r_Wip_Order_Intf.Pre_Field_04,
             r_Wip_Order_Intf.Pre_Field_05,
             r_Wip_Order_Intf.Pre_Field_06,
             r_Wip_Order_Intf.Workshop_Inv_Code --完工子库，车间仓
             );
        End If;
      Exception
        When Others Then
          p_Result := '插入工单与订单关系表失败。' || v_Nl || '失败信息：' || Sqlerrm;
          Rollback;
          Update Intf_Pln_Wip_Order_Relation r
             Set r.Intf_Status      = 'E',
                 r.Intf_Err_Msg     = p_Result,
                 r.Last_Updated_By  = p_User_Code,
                 r.Last_Update_Date = Sysdate
           Where r.Intf_Id = r_Wip_Order_Intf.Intf_Id;
          Commit;
          Goto LABLE;
      End;

      --add by huanghb12 2018-9-30 更新计划订单行上的排产结束日期SCHEDULED_COMPLETION_DATE
      BEGIN
        --根据计划订单行id，获取所有的工单，更新计划订单行
        MERGE INTO CIMS.T_PLN_ORDER_LINE OL
        USING (SELECT OD.ORDER_LINE_ID
                              ,MAX(WOR.SCHEDULED_COMPLETED_DATE) SCHEDULED_COMPLETED_DATE --ex_wangkang4  2019-12.03
                      ,MIN(WOR.SCHEDULED_START_DATE) SCHEDULED_START_DATE --ex_wangkang4  2019-12.03
                      ,MAX(II.ENTI_END_DATE) ENTI_END_DATE --ex_wangkang4 2019-11-28
                 FROM CIMS.T_INV_WIP_IN_INFO        II,
                      CIMS.T_PLN_WIP_ORDER_RELATION WOR,
                      CIMS.T_PLN_ORDER_DETAIL       OD
                WHERE II.WIP_ENTITY_ID = WOR.WIP_ENTITY_ID
                  AND WOR.ORDER_DETAIL_ID = OD.ORDER_DETAIL_ID
                  AND OD.ORDER_LINE_ID = v_Order_Line_Id
                  GROUP BY OD.ORDER_LINE_ID) UT
        ON (UT.order_line_id = OL.ORDER_LINE_ID)
        WHEN MATCHED THEN
          UPDATE --更新计划订单行上排产结束日期，当排产结束日期为空或者大于行上的该日期
             SET OL.SCHEDULED_COMPLETION_DATE = UT.SCHEDULED_COMPLETED_DATE,
                 OL.SCHEDULED_START_DATE = UT.SCHEDULED_START_DATE,
                 OL.LAST_UPDATED_BY = p_User_Code,
                 OL.LAST_UPDATE_DATE = SYSDATE,
                 OL.VERSION = NVL(OL.VERSION,0) + 1,
                 OL.FIRST_SCHEDULED_START_DATE=nvl2(OL.FIRST_SCHEDULED_START_DATE,OL.FIRST_SCHEDULED_START_DATE,UT.SCHEDULED_START_DATE),--ex_wangkang4 2019-11-28
                 OL.ENTI_END_DATE=UT.ENTI_END_DATE--ex_wangkang4 2019-11-28
           ;
      END;--end by huanghb12

      --更新接口状态
      Update Intf_Pln_Wip_Order_Relation r
         Set r.Intf_Status      = 'U',
             r.Intf_Err_Msg     = '插入数据成功',
             r.Last_Updated_By  = p_User_Code,
             r.Last_Update_Date = Sysdate
       Where r.Intf_Id = r_Wip_Order_Intf.Intf_Id;
      Commit;
      <<LABLE>>
        Null;
    End Loop;
  Exception
    When Others Then
      Rollback;
  End;

  ----------------------------------------------------------------------
  ---- AUTHOR  : Nicro.Li
  -- PURPOSE : 检验工单可入库数
  ----------------------------------------------------------------------
  Function f_Check_Wip_In_Qty(p_In_Qty        Number,
                              p_Wip_Entity_Id Number,
                              p_Entity_Id     Number,
                              p_Match_Qty     Out Number,
                              p_Supply_Qty    Out Number,
                              p_Lock_Qty      Out Number) Return Number Is
    Nwipid Number;
    Cval   Varchar2(40);
  Begin

    /* PKG_SM.P_SM_GET_ENTITY_PARAM('PLN4控制结束供货日期',
    P_ENTITY_ID,
    CVAL);*/
    If ('Y' = 'Y') Then
      Select Sum(Wh.Executed_Qty)
        Into p_Match_Qty
        From t_Inv_Po_Wip_Detail Wh,
             t_Pln_Order_Head    Ph,
             t_Pln_Order_Line    Pl,
             t_Pln_Order_Detail  Pd
       Where Wh.Wip_Entity_Id = p_Wip_Entity_Id
         And Ph.Order_Head_Id = Wh.Order_Header_Id
         And Ph.Form_State Not In ('关闭', '已结转')
         And Pl.Status In ('已排产')
         And Pl.Order_Line_Id = Pd.Order_Line_Id
         And Wh.Order_Detail_Id = Pd.Order_Detail_Id
         /*And (Trunc(Sysdate) >= Pl.Begin_Supply_Date Or
             Pl.Begin_Supply_Date Is Null)*/
         --modi by lizhen 检查入库日期使用 最后入库日期字段判段
         And (Trunc(Sysdate) <= Pl.Can_Supply_Date Or
             Pl.Can_Supply_Date Is Null)
         /*And (Trunc(Sysdate) <= Pl.End_Supply_Date Or
             Pl.End_Supply_Date Is Null)*/
         And Ph.Affirm_Flag = v_True;
    Else
      Select Sum(Wh.Executed_Qty)
        Into p_Match_Qty
        From t_Inv_Po_Wip_Detail Wh,
             t_Pln_Order_Head    Ph,
             t_Pln_Order_Line    Pl,
             t_Pln_Order_Detail  Pd
       Where Wh.Wip_Entity_Id = p_Wip_Entity_Id
         And Ph.Order_Head_Id = Wh.Order_Header_Id
         And Ph.Form_State Not In ('关闭', '已结转')
         And Pl.Status In ('待排产', '已排产')
         And Pl.Order_Line_Id = Pd.Order_Line_Id
         And Wh.Order_Detail_Id = Pd.Order_Detail_Id
         And (Trunc(Sysdate) >= Pl.Begin_Supply_Date Or
             Pl.Begin_Supply_Date Is Null)
         And Ph.Affirm_Flag = v_True;
    End If;

    Select Sum(Sd.Billed_Qty)
      Into p_Supply_Qty
      From t_Inv_Po_Lines_Detail Sd,
           t_Pln_Order_Head      Ph,
           t_Pln_Order_Line      Pl
     Where Sd.Wip_Entity_Id = p_Wip_Entity_Id
       And Ph.Order_Head_Id = Sd.Order_Header_Id
       And Ph.Form_State /*<> '关闭'*/
           Not In ('关闭', '已结转')
       And Pl.Status In ('待排产', '已排产') --暂时控制
       And Sd.Order_Line_Id = Pl.Order_Line_Id;

    Select Sum(Executed_Qty)
      Into p_Lock_Qty
      From t_Inv_Po_Wip_Detail Wd
     Where Wd.Wip_Entity_Id = p_Wip_Entity_Id
       And Nvl(Wd.Executed_Flag, v_False) = v_True;

    If (Nvl(p_In_Qty, 0) >
       Nvl(p_Match_Qty, 0) - Nvl(p_Supply_Qty, 0) - Nvl(p_Lock_Qty, 0)) Then
      Return 0;
    Else
      Return 1;
    End If;
  Exception
    When Others Then
      Return - 1;
  End;

  ------------------------------------------------------------------------
  --Author: Nicro.Li
  --获取订单某商品可入库数量
  ------------------------------------------------------------------------
  Function f_Get_Order_Supply_Qty_m(p_Item_Id           In Number, --产品ID
                                    p_Can_Supply_Date   In Date, --可入库日期
                                    p_Producing_Area_Id In Number, --产地ID
                                    p_Entity_Id         In Number, --主体ID
                                    p_Po_Line_Id        In Number, --中转单行ID
                                    p_Pln_Wip_Ord_Match In Varchar2 Default 'N' --工单与订单匹配标志
                                    ) Return Number Is
    v_Can_Supply_Qty Number;
    v_Source_Type_Code t_inv_po_headers.source_type_code%type;
  Begin
    --获取中转单入库类型
    begin
      select nvl(h.source_type_code, '01')
        into v_Source_Type_Code
        from t_inv_po_headers h, t_inv_po_lines l
       where h.po_id = l.po_id
         and l.po_line_id = p_Po_Line_Id;
    exception
      when others then
        v_Source_Type_Code := '01';
    end;

    --获取订单可入库数量
    Begin
      Select Nvl(Sum(d.Can_Produce_Qty - Nvl(d.Supply_Qty, 0) -
                     Nvl(d.Cancel_Qty, 0) -
                     --20180509 hejy3 常规入库需扣减预约直发量
                     decode(v_Source_Type_Code, '03', 0, (nvl(l.direct_transport_qty, 0) - nvl(l.cancel_direct_transport_qty, 0) - nvl(l.already_direct_transport_qty,0)))
                     ),
                 0) Can_Supply_Qty
        Into v_Can_Supply_Qty
        From t_Pln_Order_Detail d,
             t_Pln_Order_Head   h,
             t_Pln_Order_Line   l,
             t_Pln_Order_Type   t
       Where d.Order_Head_Id = h.Order_Head_Id
         And d.Entity_Id = h.Entity_Id
         And d.Order_Line_Id = l.Order_Line_Id
         And d.Order_Head_Id = h.Order_Head_Id
         And d.Producing_Area_Id = p_Producing_Area_Id
         And d.Entity_Id = p_Entity_Id
         And d.Can_Produce_Qty - Nvl(d.Supply_Qty, 0) -
             Nvl(d.Cancel_Qty, 0) > 0
         And d.Item_Id = p_Item_Id
         And Nvl(d.Close_Flag, v_False) = v_False
         And h.Order_Type_Id = t.Order_Type_Id
         And h.Entity_Id = t.Entity_Id
         And t.Match_Type_Storage = '按订单报送的时间先后顺序匹配'
         And h.Form_State In ('32', '306') --('已排产', '已完成')
         And t.Storage_Priority Is Not Null
         --modi by lizhen 2016-01-11 检查入库日期使用 最后入库日期字段判段
         And Trunc(Nvl(l.can_supply_date, Sysdate) + Nvl(t.Defer_Supply_Days, 0)) >=
             Trunc(Sysdate)
         /*And Nvl(l.End_Supply_Date, Sysdate) + Nvl(t.Defer_Supply_Days, 0) >=
             Sysdate*/
            --修改为根据周期的开始日期和主体参数控制
         And Exists (Select 1
                From t_Pln_Order_Period p
               Where p.Period_Id = h.Period_Id
                 And p.Entity_Id = h.Entity_Id
                    --增加匹配当月订单控制
                 And p.Begin_Date <= p_Can_Supply_Date)
         And (v_False = p_Pln_Wip_Ord_Match Or
             (p_Pln_Wip_Ord_Match = v_True And
             d.Order_Detail_Id In
             (Select Wd.Order_Detail_Id
                  From t_Inv_Po_Wip_Detail Wd
                 Where Wd.Po_Line_Id = p_Po_Line_Id)));
    Exception
      When Others Then
        Return 0;
    End;
    Return v_Can_Supply_Qty;
  End;

  ------------------------------------------------------------------------
  --Author: Nicro.Li
  --获取订单某商品可入库数量
  ------------------------------------------------------------------------
  Function f_Get_Order_Supply_Qty(p_Item_Id           In Number, --产品ID
                                  p_Can_Supply_Date   In Date, --可入库日期
                                  p_Producing_Area_Id In Number, --产地ID
                                  p_Entity_Id         In Number, --主体ID
                                  p_Wip_Entity_Id     In Number Default Null, --工单ID
                                  p_Source_Type_Code  in varchar2 default '01' --入库类型 01:工单入库 02:扫码入库 03:预约直发物流自动入库
                                  ) Return Number Is
    v_Can_Supply_Qty Number;
  Begin
    --获取订单可入库数量
    Begin
      Select Nvl(Sum(d.Can_Produce_Qty - Nvl(d.Supply_Qty, 0) -
                     Nvl(d.Cancel_Qty, 0) -
                     --20180509 hejy3 常规入库需扣减预约直发量
                     decode(p_Source_Type_Code, '03', 0, (nvl(l.direct_transport_qty, 0) - nvl(l.cancel_direct_transport_qty, 0)-nvl(l.already_direct_transport_qty,0)))
                     ),
                 0) Can_Supply_Qty
        Into v_Can_Supply_Qty
        From t_Pln_Order_Detail d,
             t_Pln_Order_Head   h,
             t_Pln_Order_Line   l,
             t_Pln_Order_Type   t
       Where d.Order_Head_Id = h.Order_Head_Id
         And d.Entity_Id = h.Entity_Id
         And d.Order_Line_Id = l.Order_Line_Id
         And d.Order_Head_Id = h.Order_Head_Id
         And d.Producing_Area_Id = p_Producing_Area_Id
         And d.Entity_Id = p_Entity_Id
         And d.Can_Produce_Qty - Nvl(d.Supply_Qty, 0) -
             Nvl(d.Cancel_Qty, 0) > 0
         And d.Item_Id = p_Item_Id
         And Nvl(d.Close_Flag, v_False) = v_False
         And h.Order_Type_Id = t.Order_Type_Id
         And h.Entity_Id = t.Entity_Id
         And t.Match_Type_Storage = '按订单报送的时间先后顺序匹配'
         And h.Form_State In ('32', '306') --('已排产', '已完成')
         And t.Storage_Priority Is Not Null
         --modi by lizhen 2016-01-11 检查入库日期使用 最后入库日期字段判段
         And Trunc(Nvl(l.can_supply_date, Sysdate) + Nvl(t.Defer_Supply_Days, 0)) >=
             Trunc(Sysdate)
         /*And Nvl(l.End_Supply_Date, Sysdate) + Nvl(t.Defer_Supply_Days, 0) >=
             Sysdate*/
            --修改为根据周期的开始日期和主体参数控制
         And Exists
       (Select 1
                From t_Pln_Order_Period p
               Where p.Period_Id = h.Period_Id
                 And p.Entity_Id = h.Entity_Id
                    --增加匹配当月订单控制
                 And p.Begin_Date <= p_Can_Supply_Date)
         And (p_Wip_Entity_Id Is Null Or Exists
              (Select 1
                 From t_Inv_Po_Wip_Detail Pwd
                Where Pwd.Order_Detail_Id = d.Order_Detail_Id
                  And Pwd.Order_Line_Id = d.Order_Line_Id
                  And Pwd.Order_Header_Id = d.Order_Head_Id
                  And Pwd.Item_Id = d.Item_Id
                  And Pwd.Wip_Entity_Id = p_Wip_Entity_Id));
    Exception
      When Others Then
        Return 0;
    End;
    Return v_Can_Supply_Qty;
  End;

  ------------------------------------------------------------------------
  --分别获取备货订单和定制订单的可红冲数量
  ------------------------------------------------------------------------
  Function f_Get_Ord_Usable_Red_Qty(p_Item_Id              In Number, --产品ID
                                    p_Producing_Area_Id    In Number, --产地ID
                                    p_Entity_Id            In Number, --主体ID
                                    p_Order_Usable_Red_Qty In Out Number, --订单可红冲数量
                                    p_Old_Po_Line_Id       In Number Default 0, --原中转单行ID
                                    p_Pln_Wip_Ord_Match    In Varchar Default 'N' --匹配标志
                                    ) Return Varchar2 Is
    n_Can_Supply_Qty  Number;
    v_Can_Supply_Date Date;
    v_Changer_Period  Number;
    p_Return          Varchar2(400);
  Begin
    p_Return := v_Success;
    --检查商品有效
    --订单可入库时间(相对周期开始日期的天数)
    v_Can_Supply_Date := Trunc(Sysdate - To_Number(Nvl(Pkg_Bd.f_Get_Parameter_Value('ORDER_ADVANCE_SUPPLY_DAYS',
                                                                                      p_Entity_Id),
                                                       '0')));

    --获取订单已入库可红冲数量
    If p_Return = v_Success Then
      Begin
        Select Nvl(Sum(Nvl(d.Supply_Qty, 0)), 0)
          Into p_Order_Usable_Red_Qty
          From t_Pln_Order_Detail d,
               t_Pln_Order_Head   h,
               t_Pln_Order_Line   l,
               t_Pln_Order_Type   t
         Where d.Order_Head_Id = h.Order_Head_Id
           And d.Entity_Id = h.Entity_Id
           And d.Order_Line_Id = l.Order_Line_Id
           And d.Order_Head_Id = h.Order_Head_Id
           And d.Producing_Area_Id = p_Producing_Area_Id
           And d.Entity_Id = p_Entity_Id
           And d.Item_Id = p_Item_Id
           And Nvl(d.Supply_Qty, 0) > 0
           And h.Order_Type_Id = t.Order_Type_Id
           And h.Entity_Id = t.Entity_Id
           And h.Form_State In ('32', '306') --('已排产', '已完成')
           And t.Match_Type_Storage = '按订单报送的时间先后顺序匹配'
           And t.Storage_Priority Is Not Null
              --工单与订单完全匹配订单 增加只查询当前明细行
           And (p_Pln_Wip_Ord_Match = v_False Or
               (p_Pln_Wip_Ord_Match = v_True And
               d.Order_Detail_Id In
               (Select d.Order_Detail_Id
                    From t_Inv_Po_Lines_Detail d
                   Where d.Po_Line_Id = p_Old_Po_Line_Id
                     And d.Entity_Id = p_Entity_Id)));

      Exception
        When Others Then
          p_Return := '获取备货订单可入库数量出错,错误信息' || Sqlerrm;
      End;
    End If;
    Return p_Return;
  End;

  ----------------------------------------------------------------------
  ---- AUTHOR  : Nicro.Li
  -- CREATED : 2014-08-08
  -- PURPOSE : 生成采购单
  ----------------------------------------------------------------------
  Procedure p_Create_Wip_To_Po_Order(p_Trace_Trans_Id  In Number, --事务ID
                                     p_Entity_Id       In Number, --主体ID
                                     p_User_Code       In Varchar2, --用户编码
                                     p_Result          Out Varchar2, --返回结果，成功返回“SUCCESS”，失败返回错误信息
                                     p_Po_Order_Number Out Varchar2 --返回中转单单号
                                     ) Is
    Cursor c_Line Is
      Select t.Item_Id,
             Bi.Item_Code,
             Bi.Item_Name,
             Bi.Defaultunit,
             Bi.Commoditybarcode,
             Sum(t.Quantity) Shipment_Quantity
        From t_Inv_Wip_To_Po_Trace t, t_Bd_Item Bi
       Where t.Trace_Trans_Id = p_Trace_Trans_Id
         And Bi.Entity_Id = p_Entity_Id
         And t.Item_Id = Bi.Item_Id
       Group By t.Item_Id,
                Bi.Item_Code,
                Bi.Item_Name,
                Bi.Defaultunit,
                Bi.Commoditybarcode;

    Cursor c_Sup_Line(p_Po_Head_Id Number) Is
      Select * From t_Inv_Po_Lines l Where l.Po_Id = p_Po_Head_Id;

    v_Pln_Wip_Ord_Match Varchar2(10);
    v_Can_Supply_Qty    Number := 0;
    v_Usable_Supply_Qty Number := 0;
    v_Wip_Entity_Code   Varchar2(100);

    v_Match_Qty  Number;
    v_Supply_Qty Number;
    v_Lock_Qty   Number;
    v_Quan       Number;

    v_Po_Order_Type_Id    Number;
    v_Inv_Finance_Id      Number;
    v_Inv_Logistics_Id    Number;
    v_Inv_Logistics_Code varchar2(100); --add by sushu 2015-10-19
    v_Inv_Logistics_Name varchar2(100); --add by sushu 2015-10-19
    v_Inv_Storage_Tran_Flag varchar2(2); --add by sushu 2015-10-19
    v_Price_List_Id       Number;
    v_Sales_Center_Id     Number;
    v_Vendor_Id           Number;
    v_Cleared_Inv_Code    Varchar2(100);
    v_Workshop_Inv_Code   Varchar2(100);

    v_Find            Number := 0;
    v_Org_Id          Number := 0;
    v_Vendor_Org_Id   Number := 0;
    v_Vendor_Operating_Id  Number:=0;
    v_Inv_Period_Id   Number := 0;
    v_Po_Header_Id    Number := 0;
    v_Po_Order_Number Varchar2(100);

    v_Line_Num        Number := 0;
    v_Supply_Seq      Varchar2(60); --入库优化顺序
    v_Inv_Date        Number; --可提前入库天数
    v_Can_Supply_Date Date; --可入库日期

    v_Wip_Qty            Number := 0;
    v_Pln_Qty            Number := 0;
    v_Wip_Detail_Count   Number := 0;
    v_Sum_Wip_Detail_Qty Number := 0;
    v_Wip_Match_Qty      Number := 0;
    v_user_id            Number;
    v_price              Number := 0; --返回价格
    v_discount           Number := 0; --返回折扣率
    v_month_discount     Number := 0; --返回月返
    v_cx_flag            Varchar2(10); --返回是否促销机
    v_billed_date        Date;
    v_item_price_list_id Number;


    v_inv_organization_id   Number;
    v_inv_operating_unit_id Number;
    v_Pln_Order_Qty         Number;

    v_Order_Inventory_id    Number;  --订单已入库仓库
    v_Order_Inventory_Code  Varchar2(100);
    v_Inventory_Code        Varchar2(100);
    v_Sum_Executed_Qty      Number;
    v_Ar_Push_Or_Pull       Varchar2(10);
    v_erp_trancation     varchar2(10); --ERP处理类型    by sushu 2015-6-19  change zhangwm 2015-10-27
    v_producing_area_id Number; --产地ID  add by sushu 2015-8-26
    v_producing_area_code varchar2(32); --产地编码  add by sushu 2015-8-26
    v_producing_area_name Varchar2(100); --产地名称  add by sushu 2015-8-26
    v_product_erp_transcation   varchar2(10); --产地对应的ERP处理类型    by zhangwm 2015-6-19
    v_Order_Input_Same_Inven_Flag varchar2(10); --根据主体判断是否必须入同一个仓库，Y是，N否  by sushu 2016-1-12
    v_Input_Num varchar2(32); --入库单号  by sushu 2016-08-05
    v_Item_Code varchar2(1000); --校验没有维护成本的编码 by sushu 2016-10-13
    v_Organization_Code varchar2(10); --组织编码  by sushu 2016-10-13
    v_Organization_Id Number;  --组织Id  by sushu 2016-10-13
    v_Item_Vendor_Relation varchar2(10); --是否校验物料使用批准得供应商 by sushu 2016-11-12
    v_Item_Vendor_Code varchar2(100); --供应商 by sushu 2016-11-12
    v_Item_Finance_Operating_Id Number; --财务仓Ou by sushu 2016-11-12
    v_Item_Vendor_Id Number; --erp对应的供应商ID by sushu 2016-11-12
    v_Item_Vendor_Site_Id Number; --erp对应的供应商地点ID by sushu 2016-11-12
    v_source_type_code varchar2(100);--工单入库来源类型编码 chenyj8 2017-11-20
    v_wip_order_direct_qty Number := 0;--按工单直发数量 chenyj8 20190408

    Cursor c_Get_Wip Is
      Select *
        From t_Inv_Wip_In_Info i
       Where i.Wip_Entity_Id In
             (Select t.Wip_Entity_Id
                From t_Inv_Wip_To_Po_Trace t
               Where t.Trace_Trans_Id = p_Trace_Trans_Id
                And t.close_flag = v_False)
         For Update Nowait;
    r_wip_Info  c_Get_Wip%Rowtype;

    Cursor c_Match_Pln_Order Is
      Select h.Order_Number,
             h.Order_Head_Id,
             l.Order_Line_Id,
             d.Order_Detail_Id,
             d.Item_Id,
             d.Item_Code,
             Trunc(Nvl(l.can_supply_date, Sysdate) + Nvl(t.Defer_Supply_Days, 0)) Can_Supply_Date,
             Nvl(d.Can_Produce_Qty -
                 Nvl(d.Supply_Qty, 0) -
                 Nvl(d.Cancel_Qty, 0),
                 0) Order_Can_Supply_Qty --订单可入库数量
        From t_Pln_Order_Detail d,
             t_Pln_Order_Head   h,
             t_Pln_Order_Line   l,
             t_Pln_Order_Type   t
       Where d.Order_Head_Id = h.Order_Head_Id
         And d.Entity_Id = h.Entity_Id
         And d.Order_Line_Id = l.Order_Line_Id
         And d.Order_Head_Id = h.Order_Head_Id
         And d.Entity_Id = p_Entity_Id
         --And d.order_detail_id = r_Wip.Order_Detail_id
         And d.Can_Produce_Qty -
             Nvl(d.Supply_Qty, 0) -
             Nvl(d.Cancel_Qty, 0) > 0
         --And d.Item_Id = r_Wip.Item_Id
         And Nvl(d.Close_Flag, 'N') = 'N'
         And h.Order_Type_Id = t.Order_Type_Id
         And h.Entity_Id = t.Entity_Id
         And t.Match_Type_Storage =
             '按订单报送的时间先后顺序匹配'
         And h.Form_State In ('32', '306') --('已排产', '已完成')
         And t.Storage_Priority Is Not Null
         ;
    r_Match_Order c_Match_Pln_Order%Rowtype;
    Type c_Get_Pln_Order Is Ref Cursor;
    v_Get_Pln_Order c_Get_Pln_Order;
    v_Select_Sql   Varchar2(4000);
    v_OrderBy_Sql  Varchar2(4000);
    r_Inv_Inventories t_inv_inventories%Rowtype;
    v_Order_Inv_Org_Id Number;
  Begin
    p_Result := v_Success;
    --参数验证
    If (p_Trace_Trans_Id Is Null) Then
      p_Result := '无效参数';
      Raise v_Base_Exception;
    End If;
    --获取主体库存管理模式
    /*PULL  拉式
    PUSH  推式*/
    v_Ar_Push_Or_Pull := Pkg_Bd.F_Get_Parameter_Value('SO_AR_PUSH_OR_PULL',
                                                        p_Entity_Id);
    Begin
      Open c_Get_Wip;
      Fetch c_Get_Wip Into r_wip_Info;
      If c_Get_Wip%Notfound Then
        p_Result := '获取工单信息表失败，执行中转单批次ID:' || To_Char(p_Trace_Trans_Id);
        Raise v_Base_Exception;
      End If;
      Close c_Get_Wip;
    Exception
      When Others Then
        p_Result := '工单信息表锁定失败！';
        Raise v_Base_Exception;
    End;

    Begin
      Select Pt.Organization_Id,
             Pt.Po_Order_Type_Id,
             Pt.Billed_Date,
             Pt.Inv_Finance_Id,
             Pt.Inv_Logistics_Id,
             Pt.Price_List_Id,
             Pt.Sales_Center_Id,
             Pt.Vendor_Id,
             Pt.Cleared_Inv_Code,
             Pt.Workshop_Inv_Code,
        --     bt.erp_trancation,   --by sushu 2015-6-19
             pt.po_area_id,  --by sushu 2015-10-13
             pt.po_area_code,  --by sushu 2015-10-13
             pt.po_area_name,  --by sushu 2015-10-13
             pt.vendor_organization_id,   --by zhangwm 2015-10-27
             pt.vendor_operating_id,      --by zhangwm 2015-10-27
             pt.finance_organization_id,  --by zhangwm 2015-10-27
             pt.finance_operating_id,      --by zhangwm 2015-10-27
             pt.input_num, --by sushu 2016-08-05
             pt.source_type_code
        Into v_Org_Id,
             v_Po_Order_Type_Id,
             v_Billed_Date,
             v_Inv_Finance_Id,
             v_Inv_Logistics_Id,
             v_Price_List_Id,
             v_Sales_Center_Id,
             v_Vendor_Id,
             v_Cleared_Inv_Code,
             v_Workshop_Inv_Code,
       --      v_erp_trancation,  --by sushu 2015-6-19
             v_producing_area_id,  --by sushu 2015-10-13
             v_producing_area_code,  --by sushu 2015-10-13
             v_producing_area_name,  --by sushu 2015-10-13
             v_Vendor_Org_Id,         --by zhangwm 2015-10-27
             v_Vendor_Operating_Id,   --by zhangwm 2015-10-27
             v_inv_organization_id,   --by zhangwm 2015-10-27
             v_inv_operating_unit_id,  --by zhangwm 2015-10-27
             v_Input_Num, -- by sushu 2016-08-05
             v_source_type_code
        From t_Inv_Wip_To_Po_Trace Pt, t_inv_bill_types bt --by sushu 2015-6-19
       Where Pt.Trace_Trans_Id = p_Trace_Trans_Id
        And pt.po_order_type_id=bt.bill_type_id  --by sushu 2015-6-19
       Group By Pt.Entity_Id,
                Pt.Organization_Id,
                Pt.Sales_Main_Type,
                Pt.Po_Order_Type_Id,
                Pt.Po_Order_Type,
                Pt.Billed_Date,
                Pt.Inv_Finance_Id,
                Pt.Inv_Logistics_Id,
                Pt.Price_List_Id,
                Pt.Sales_Center_Id,
                Pt.Vendor_Id,
                Pt.Cleared_Inv_Code,
                Pt.Workshop_Inv_Code,
                Pt.Remark,
                Pt.Vendor_Operating_Id,
                Pt.Vendor_Organization_Id,
                Pt.Vendor_Site_Code,
                Pt.Vendor_Site_Name,
           --    bt.erp_trancation,  --by sushu 2015-6-19
                pt.po_area_id,  --by sushu 2015-10-13
                pt.po_area_code,  --by sushu 2015-10-13
                pt.po_area_name,  --by sushu 2015-10-13
                pt.vendor_organization_id,   --by zhangwm 2015-10-27
                pt.vendor_operating_id,      --by zhangwm 2015-10-27
                pt.finance_organization_id,  --by zhangwm 2015-10-27
                pt.finance_operating_id,     --by zhangwm 2015-10-27
                pt.input_num, -- by sushu 2016-08-05
                pt.source_type_code;
    Exception
      When Others Then
        p_Result := '生成中转单失败，中转单选项信息' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;

    --根据组织获取产地信息  add by sushu 2015-8-26  --by sushu 2015-10-13
    If v_producing_area_id Is Null Then
      p_Result := '生成中转单失败，获取中转产地信息为空。' || v_Nl || Sqlerrm;
      Raise v_Base_Exception;
    End If;
    --根据产地获取ERP事物处理类型，并校验是否符合事物处理类型。zhangwm 2015-10-27
    begin

      select t.erp_inv_trans_po
        into v_product_erp_transcation
        from t_pln_producing_area t
        where t.producing_area_id = v_producing_area_id;

      if(v_product_erp_transcation = '03') Then
         v_erp_trancation := '07';    --关联交易采购
         if(v_Vendor_Org_Id = v_inv_organization_id or v_Vendor_Operating_Id = v_inv_operating_unit_id)  then
            p_Result := '产地对应ERP事物类型为关联交易，供应商组织ID'||v_Vendor_Org_Id|| '供应商经营单位ID'||v_Vendor_Operating_Id||'财务仓组织ID'||v_inv_organization_id|| '财务仓经营单位ID'|| v_inv_operating_unit_id||'不符合关联交易要求，请重新选择！' || v_Nl || Sqlerrm;
            Raise v_Base_Exception;
         end If;
      elsif(v_product_erp_transcation = '01') Then
         v_erp_trancation := '01';    -- 组织间转移
         if(v_Vendor_Org_Id = v_inv_organization_id or v_Vendor_Operating_Id != v_inv_operating_unit_id)  then
            p_Result := '产地对应ERP事物类型为组织间转移，供应商组织ID'||v_Vendor_Org_Id|| '供应商经营单位ID'||v_Vendor_Operating_Id||'财务仓组织ID'||v_inv_organization_id|| '财务仓经营单位ID'|| v_inv_operating_unit_id||'不符合组织间要求，请重新选择！' || v_Nl || Sqlerrm;
            Raise v_Base_Exception;
         end If;
      elsif(v_product_erp_transcation = '02') Then
         v_erp_trancation := '02';    -- 子库转移
         if(v_Vendor_Org_Id != v_inv_organization_id or v_Vendor_Operating_Id != v_inv_operating_unit_id)  then
            p_Result := '产地对应ERP事物类型为子库转移，供应商组织ID'||v_Vendor_Org_Id|| '供应商经营单位ID'||v_Vendor_Operating_Id||'财务仓组织ID'||v_inv_organization_id|| '财务仓经营单位ID'|| v_inv_operating_unit_id||'不符合子库转移要求，请重新选择！' || v_Nl || Sqlerrm;
            Raise v_Base_Exception;
         end If;
      else
        p_Result := '产地维护的ERP事物类型不正确，请维护该产地对应的ERP事物处理类型未维护或维护不正确。' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
      end if;
    End;


    If v_Org_Id Is Null Then
      p_Result := '生成中转单失败，组织ID不可为空。' || v_Nl || Sqlerrm;
      Raise v_Base_Exception;
    End If;

    If v_Po_Order_Type_Id Is Null Then
      p_Result := '生成中转单失败，中转单据类型不可为空。' || v_Nl || Sqlerrm;
      Raise v_Base_Exception;
    End If;

    If v_billed_date Is Null Then
      p_Result := '生成中转单失败，单据日期不可为空。' || v_Nl || Sqlerrm;
      Raise v_Base_Exception;
    End If;

    If v_Inv_Finance_Id Is Null Then
      p_Result := '生成中转单失败，财务仓库ID不可为空。' || v_Nl || Sqlerrm;
      Raise v_Base_Exception;
    End If;


    --add by sushu 2015-10-19
    If v_Inv_Logistics_Id Is Not Null Then
      Begin
        Select t.Storage_Code, t.Storage_Name, t.Storage_Tran_Flag
          Into v_Inv_Logistics_Code,
               v_Inv_Logistics_Name,
               v_Inv_Storage_Tran_Flag
          From t_Inv_Storage_Info t
         Where t.Storage_Id = v_Inv_Logistics_Id;
      Exception
        When Others Then
          p_Result := '获取实体仓信息失败。' || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
      End;
    End If;
/*    If v_Inv_Logistics_Id Is Null Then
      p_Result := '生成中转单失败，实体仓库ID不可为空。' || v_Nl || Sqlerrm;
      Raise v_Base_Exception;
    End If;*/

    --子库转移不需要校验价格列表
    If v_Price_List_Id Is Null and v_product_erp_transcation <> '02' Then
      p_Result := '生成中转单失败，价格列表ID不可为空。' || v_Nl || Sqlerrm;
      Raise v_Base_Exception;
    End If;

    If v_Sales_Center_Id Is Null Then
      p_Result := '生成中转单失败，营销中心ID不可为空。' || v_Nl || Sqlerrm;
      Raise v_Base_Exception;
    End If;

/*    If v_Cleared_Inv_Code Is Null And v_Ar_Push_Or_Pull = v_Ar_Push Then
      p_Result := '生成中转单失败，结算仓编码不可为空。' || v_Nl || Sqlerrm;
      Raise v_Base_Exception;
    End If;*/

    --by sushu 2015-6-19
    If v_Cleared_Inv_Code Is Null And (v_erp_trancation ='07' Or v_erp_trancation ='08' Or v_erp_trancation ='09') Then
      p_Result := '生成中转单失败，结算仓编码不可为空。' || v_Nl || Sqlerrm;
      Raise v_Base_Exception;
    End If;

    If v_Workshop_Inv_Code Is Null Then
      p_Result := '生成中转单失败，车间仓编码不可为空。' || v_Nl || Sqlerrm;
      Raise v_Base_Exception;
    End If;

    --获取工单与订单是否完全匹配参数
    v_Pln_Wip_Ord_Match := Pkg_Bd.F_Get_Parameter_Value('PLN_WIP_ORD_MATCH',
                                                        p_Entity_Id);

    --获取订单提前入库日期
    v_Inv_Date := -to_Number(Nvl(Pkg_Bd.f_Get_Parameter_Value('ORDER_ADVANCE_SUPPLY_DAYS',
                                                                       p_Entity_Id),
                                        '0'));
    v_Can_Supply_Date := Trunc(Sysdate + v_Inv_Date);

    --获取单据日期
    Begin
      Select Max(p.Billed_Date), Max(p.Price_List_Id)
        Into v_Billed_Date, v_Item_Price_List_Id
        From t_Inv_Wip_To_Po_Trace p
       Where p.Trace_Trans_Id = p_Trace_Trans_Id
         And p.Close_Flag = v_False;
    Exception
      When Others Then
        p_Result := '获取单据日期失败，事务表ID：' || p_Trace_Trans_Id || v_Nl ||
                    Sqlerrm;
        Raise v_Base_Exception;
    End;
    --新工单入库方式,取消匹配检查
    If v_Pln_Wip_Ord_Match <> 'Y' Then
      Null;
    Else
      --检查可入库数量
      For r In (Select t.Item_Id,
                       t.Item_Code,
                       p.Producing_Area_Id,
                       Decode(v_Pln_Wip_Ord_Match,
                              v_True,
                              t.Wip_Entity_Id,
                              Null) Wip_Entity_Id,
                       Sum(t.Quantity) Quantity
                  From t_Inv_Wip_To_Po_Trace t, t_Pln_Producing_Area p
                 Where p.Mrp_Org_Id = t.Organization_Id
                   And p.Entity_Id = p_Entity_Id
                   And t.Trace_Trans_Id = p_Trace_Trans_Id
                 Group By t.Trace_Trans_Id,
                          t.Item_Id,
                          t.Item_Code,
                          p.Producing_Area_Id,
                          Decode(v_Pln_Wip_Ord_Match,
                                 v_True,
                                 t.Wip_Entity_Id,
                                 Null)) Loop
        v_Can_Supply_Qty := f_get_order_supply_qty(r.item_id,
                                                   v_Can_Supply_Date,
                                                   r.producing_area_id,
                                                   p_entity_id,
                                                   null,
                                                   nvl(v_source_type_code, '01'));

        Select Nvl(Sum(Nvl(d.Executed_Qty, 0)), 0)
          Into v_Quan
          From t_Inv_Po_Headers     o,
               t_Inv_Po_Lines       l,
               t_Inv_Inventories    i,
               t_Pln_Producing_Area p,
               t_Inv_Po_Wip_Detail  d/*,
               Up_Codelist          c*/
         Where o.Po_Id = l.Po_Id
           And i.Inventory_Id = o.Inv_Finance_Id
           And p.Mrp_Org_Id = d.Organization_Id
           And p.Entity_Id = o.Entity_Id
           And p.Producing_Area_Id = r.Producing_Area_Id
           And o.Entity_Id = p_Entity_Id
           And l.Item_Id = r.Item_Id
           And o.Source_Type = '工单入库'
           And o.Po_Status IN ('10', '21') --制单、已发货
           --And c.Codetype = 'BD_BILL_STATUS'
           --And c.Code_Value = o.Po_Status
           --And c.Code_Name = '已执行'
           And o.Old_Po_Id Is Null --红冲单据不统计
           And d.Wip_Entity_Id = r.Wip_Entity_Id
           And d.Po_Line_Id = l.Po_Line_Id
           And d.Item_Id = l.Item_Id
           --20180526 hejy3 只取未关闭的中转单
           and nvl(o.close_flag, 'N') = 'N';

        If v_Can_Supply_Qty - v_Quan < r.Quantity Then
          p_Result := '产品：' || r.Item_Code || '  本次入库数量：' ||
                      To_Char(r.Quantity) || ' >　订单可匹配数量：' ||
                      To_Char(v_Can_Supply_Qty - v_Quan) || '（周期内可入库数量：' ||
                      To_Char(v_Can_Supply_Qty) || '　-　订单在途占用数量：' ||
                      To_Char(v_Quan) || '　）';
          Raise v_Base_Exception;
        End If;
      End Loop;

      --更新工单未执行数量
      For r_Trace In (Select t.Wip_Entity_Id,
                             t.Wip_Entity_Code,
                             t.Quantity,
                             t.Organization_Id,
                             t.order_detail_id
                        From t_Inv_Wip_To_Po_Trace t
                       Where t.Trace_Trans_Id = p_Trace_Trans_Id) Loop

        --20190408 chenyj8,按工单预约直发的数量，前台入库非直发模式要扣减
         if nvl(v_source_type_code,'01') <> '03' then
            select sum(nvl(pr.direct_transport_qty, 0) -
                       nvl(pr.already_direct_transport_qty, 0))
              into v_wip_order_direct_qty
              from cims.t_pln_wip_order_relation pr
             where pr.wip_entity_id = r_Trace.Wip_Entity_Id
               and pr.order_detail_id = r_Trace.Order_Detail_Id
               and pr.organization_id = r_Trace.Organization_Id;

               if v_wip_order_direct_qty < 0 then
                  v_wip_order_direct_qty := 0;
               end if;

         end if;

        --判断工单未执行数量
        Select Wii.Produce_Qty - Nvl(Wii.Exec_Qty, 0) -
               Nvl(Wii.Lock_Qty, 0) - v_wip_order_direct_qty,
               Wii.Wip_Entity_Code
          Into v_Usable_Supply_Qty, v_Wip_Entity_Code
          From t_Inv_Wip_In_Info Wii
         Where Wii.Wip_Entity_Id = r_Trace.Wip_Entity_Id
           And Wii.Wip_Entity_Code = r_Trace.Wip_Entity_Code
           And Wii.Organization_Id = r_Trace.Organization_Id;



        If v_Usable_Supply_Qty < r_Trace.Quantity Then
          p_Result := '工单：' || r_Trace.Wip_Entity_Code ||
                      '  工单可入库数量(工单数量-已入库数量-未执行数量-工单直发数量)不够；工单可入库数量:' ||
                      To_Char(Nvl(v_Usable_Supply_Qty, 0)) || ' 将入库数' ||
                      To_Char(r_Trace.Quantity);
          Raise v_Base_Exception;
        Else
          Update t_Inv_Wip_In_Info t
             Set t.Lock_Qty = Nvl(t.Lock_Qty, 0) + Nvl(r_Trace.Quantity, 0)
           Where t.Wip_Entity_Id = r_Trace.Wip_Entity_Id
             And t.Wip_Entity_Code = r_Trace.Wip_Entity_Code
             And t.Organization_Id = r_Trace.Organization_Id;
        End If;
      End Loop;

    End If;
    --验证工单和供应商，仓库是否匹配
    If (p_Result = v_Success) Then
      Begin
        Select Count(*)
          Into v_Find
          From t_Inv_Wip_To_Po_Trace t
         Where t.Trace_Trans_Id = p_Trace_Trans_Id
         Group By Organization_Id;
      Exception
        When No_Data_Found Then
          Null;
        When Others Then
          p_Result := '入库的工单必须为同工厂-' || To_Char(p_Trace_Trans_Id);
          Raise v_Base_Exception;
      End;
    End If;
    If p_Result = v_Success Then
      Select Count(1)
        Into v_Find
        From t_Lg_Vendor_Info_Head Vih--, t_Lg_Vendor_Info_Line Vil
       Where Vih.Entity_Id = p_Entity_Id
         And vih.vendor_id = v_Vendor_Id
         /*And Vil.Vendor_Id = Vih.Vendor_Id
         And Exists (Select 1
                From t_Inv_Organization o
               Where o.Operating_Unit = Vil.Operating_Unit
                 And o.Organization_Id = v_Org_Id)*/;
      If v_Find <= 0 Then
        p_Result := '工单与供应商组织不匹配，工单组织ID：' || To_Char(v_Org_Id) ||
                 '，供应商ID：' || To_Char(v_Vendor_Id);
        Raise v_Base_Exception;
      End If;
    End If;
    --库存周期
    If p_Result = v_Success Then
      Pkg_Inv_Pub.p_Get_Inv_Period(p_Entity_Id,
                                   v_billed_date,
                                   1,
                                   v_Inv_Period_Id,
                                   p_Result);
      If (p_Result <> v_Success) Then
        Raise v_Base_Exception;
      End If;
    End If;

    --插入头
    If (p_Result = v_Success) Then
      Begin
        Select s_Inv_Po_Headers.Nextval Into v_Po_Header_Id From Dual;

        Insert Into t_Inv_Po_Headers
          (Po_Id, --采购单据ID
           Entity_Id, --经营主体ID
           Po_Type_Id, --单据类型ID
           Po_Type, --单据类型
           Po_Num, --采购单据编号
           Billed_Date, --单据日期
           Po_Status, --单据状态
           Sales_Main_Type, --营销大类
           Inv_Finance_Id, --财务仓ID
           Inv_Finance_Code, --财务仓编码
           Inv_Finance_Name, --财务仓名称
           Inv_Logistics_Id, --实体仓ID
           Inv_Logistics_Code, --实体仓编码
           Inv_Logistics_Name, --实体仓名称
           Vendor_Id, --供应商ID
           Vendor_Code, --供应商编码
           Vendor_Name, --供应商名称
           Workshop_Inv_Code, --车间仓
           Cleared_Inv_Code, --结算仓
           Sales_Center_Id, --营销中心ID
           Sales_Center_Code, --营销中心编码
           Sales_Center_Name, --营销中心名称
           Price_List_Id, --价格列表ID
           Roping_Flag, --入库拉运标志(实体仓获取）
           Close_Flag,  --关闭标志
           Remark, --备注
           Created_By, --创建者
           Creation_Date, --创建日期
           Last_Updated_By, --更新者
           Last_Update_Date, --更新日期
           Source_Type, --来源代号(工单入库)
           vendor_operating_id,
           vendor_organization_id,
           Vendor_Site_Code,
           Vendor_Site_Name,
           Finance_Organization_id,
           Finance_Operating_id,
           Red_Order_Flag,
           Input_Num,  --入库单号（马龙传送带专用） --add by lizhen 2015-03-18
           producing_area_id,  --add by sushu 2015-8-26
           producing_area_code,  --add by sushu 2015-8-26
           producing_area_name,   --add by sushu 2015-8-26
           erp_trancation,     --add by zhangwm 2015-10-27
           source_type_code  --add by chenyj8 2017-11-20
           )
          Select v_Po_Header_Id, --采购单据ID
                 Pt.Entity_Id, --经营主体ID
                 Pt.Po_Order_Type_Id, --单据类型ID
                 Pt.Po_Order_Type, --单据类型
                 To_Char(v_Po_Header_Id), --采购单据编号,先使用ID，保存前再UPDATE单号
                 Pt.Billed_Date, --单据日期
                 '10' Po_Status, --单据状态
                 Pt.Sales_Main_Type, --营销大类
                 Pt.Inv_Finance_Id, --财务仓ID
                 Iif.Inventory_Code Inv_Finance_Code, --财务仓编码
                 Iif.Inventory_Name Inv_Finance_Name, --财务仓名称
                 Pt.Inv_Logistics_Id, --实体仓ID
                 --Isi.Storage_Code Inv_Logistics_Code, --实体仓编码  --add by sushu 2015-10-19
                 --Isi.Storage_Name Inv_Logistics_Name, --实体仓名称  --add by sushu 2015-10-19
                 v_Inv_Logistics_Code,  --add by sushu 2015-10-19
                 v_Inv_Logistics_Name,  --add by sushu 2015-10-19
                 Pt.Vendor_Id, --供应商ID
                 Vih.Vendor_Code, --供应商编码
                 Vih.Vendor_Name, --供应商名称
                 Pt.Workshop_Inv_Code, --车间仓
                 Pt.Cleared_Inv_Code, --结算仓
                 Pt.Sales_Center_Id, --营销中心ID
                 Uou.Code Sales_Center_Code, --营销中心编码
                 Uou.Name Sales_Center_Name, --营销中心名称
                 Pt.Price_List_Id, --价格列表ID
                 --Isi.Storage_Tran_Flag, --入库拉运标志(实体仓获取） --add by sushu 2015-10-19
                 v_Inv_Storage_Tran_Flag, --add by sushu 2015-10-19
                 v_False, --关闭标志
                 Pt.Remark, --备注
                 p_User_Code Created_By, --创建者
                 Sysdate Creation_Date, --创建日期
                 p_User_Code Last_Updated_By, --更新者
                 Sysdate Last_Update_Date, --更新日期
                 '工单入库' Source_Type, --来源代号(工单入库)
                 pt.vendor_operating_id,
                 pt.vendor_organization_id,
                 pt.vendor_site_code,
                 pt.vendor_site_name,
                 tio.organization_id,
                 tio.operating_unit,
                 v_False,
                 Min(Pt.Input_Num),   --入库单号（马龙传送带专用） add by lizhen 2015-03-18
                 v_producing_area_id,  -- add by sushu 2015-8-26
                 v_producing_area_code,  --add by sushu 2015-8-26
                 v_producing_area_name,   --add by sushu 2015-8-26
                 v_erp_trancation,    --add by zhangwm 2015-10-27
                 v_source_type_code  --add by chenyj8 2017-11-20
            From t_Inv_Wip_To_Po_Trace Pt,
                 t_Inv_Inventories     Iif,
                 --t_Inv_Storage_Info    Isi, --add by sushu 2015-10-19
                 t_Lg_Vendor_Info_Head Vih,
                 Up_Org_Unit           Uou,
                 t_inv_organization    tio
           Where Pt.Trace_Trans_Id = p_Trace_Trans_Id
             And Iif.Inventory_Id = Pt.Inv_Finance_Id
             --And Isi.Storage_Id = Pt.Inv_Logistics_Id  --add by sushu 2015-10-19
             And Vih.Vendor_Id = Pt.Vendor_Id
             And Uou.Unit_Id = Pt.Sales_Center_Id
             And tio.organization_id = iif.organization_id
             And tio.entity_id = p_Entity_Id
           Group By Pt.Entity_Id,
                    Pt.Organization_Id,
                    Pt.Sales_Main_Type,
                    Pt.Po_Order_Type_Id,
                    Pt.Po_Order_Type,
                    Pt.Billed_Date,
                    Pt.Inv_Finance_Id,
                    Iif.Inventory_Code,
                    Iif.Inventory_Name,
                    Pt.Inv_Logistics_Id,
                    --Isi.Storage_Code, --add by sushu 2015-10-19
                    -- Isi.Storage_Name, --add by sushu 2015-10-19
                    --Isi.Storage_Tran_Flag, --add by sushu 2015-10-19
                    Pt.Price_List_Id,
                    Pt.Sales_Center_Id,
                    Uou.Code,
                    Uou.Name,
                    Pt.Vendor_Id,
                    Vih.Vendor_Code,
                    Vih.Vendor_Name,
                    Pt.Cleared_Inv_Code,
                    Pt.Workshop_Inv_Code,
                    Pt.Remark,
                    pt.vendor_operating_id,
                    pt.vendor_organization_id,
                    pt.vendor_site_code,
                    pt.vendor_site_name,
                    tio.organization_id,
                    tio.operating_unit;
      Exception
        When Others Then
          p_Result := '插入中转单头表失败。' || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
      End;
    End If;

    --定制订单记录计划订单号,车间仓的运作模式
    update t_Inv_Po_Headers t
       set t.sched_order_num = (select pt.sched_order_num
                                  from t_Inv_Wip_To_Po_Trace Pt
                                 where pt.trace_trans_id = p_Trace_Trans_Id
                                   and rownum = 1),
           t.business_type   = (select inv.business_type
                                  from cims.t_inv_vendor_mrpii_inv inv
                                 where inv.entity_id = t.entity_id
                                   and inv.organization_id =
                                       t.vendor_organization_id
                                   and inv.workshop_inv_code =
                                       t.workshop_inv_code
                                   and rownum = 1)
     where t.po_id = v_Po_Header_Id;
    --检查是否生成多张中转单头
    If p_Result = v_Success Then
      Select Count(1)
        Into v_Find
        From t_Inv_Po_Headers Ph
       Where Ph.Po_Num = To_Char(v_Po_Header_Id)
         And Ph.Entity_Id = p_Entity_Id;
      If v_Find > 1 Then
        p_Result := '生成中转单失败，中转入库不可同时生成多张中转头。请检查生成中转单选项值是否存在不同的设置。';
        Raise v_Base_Exception;
      End If;
      If v_Find = 0 Then
        p_Result := '生成中转单失败，未生成中转单。';
        Raise v_Base_Exception;
      End If;
    End If;
    --插入行表

    If (p_Result = v_Success) Then
      For r_Line In c_Line Loop
        v_Line_Num := v_Line_Num + 1;
        --chenyj8 2017-03-25 子库转移不需要价格
        if v_product_erp_transcation <> '02' then
          Begin

            pkg_bd_price.p_Get_Price(p_Acc_Id         => Null, --账户ID
                                     p_Item_Code      => r_Line.Item_Code, --产品ID
                                     p_Bill_Date      => To_Char(v_Billed_Date, 'YYYYMMDD'), --单据日期
                                     p_Price_List_Id  => v_Item_Price_List_Id, --价格列表ID
                                     p_Entity_Id      => p_Entity_Id, --业务主体ID
                                     p_Price          => v_Price, --返回价格
                                     p_Discount       => v_Discount, --返回折扣率
                                     p_Month_Discount => v_Month_Discount, --返回月返
                                     p_Cx_Flag        => v_Cx_Flag --返回是否促销机
                                     );
            Exception
              When Others Then
                p_Result := '获取商品单价失败，商品编码：' || r_Line.Item_Code || v_Nl || Sqlerrm;
                Raise v_Base_Exception;
            End;
          If v_price Is Null Then
            p_Result := '获取商品单价失败，商品编码：' || r_Line.Item_Code ||
              '，价格列表ID：' || To_Char(v_Item_Price_List_Id) || v_Nl || Sqlerrm;
            Raise v_Base_Exception;
          End If;
        End If;

        Begin
          Insert Into t_Inv_Po_Lines
            (Po_Line_Id, --采购单行ID
             Po_Id, --采购单ID
             Po_Line_Num, --采购单行编码
             Item_Id, --产品ID
             Item_Code, --产品编码，即销售码
             Item_Name, --产品名称
             Item_Bar_Code, --产品标识
             Uom_Code, --产品单位
             Item_Price, --产品价格
             Billed_Qty, --开单数量
             Created_By, --创建者
             Creation_Date, --创建日期
             Last_Updated_By, --更新者
             Last_Update_Date --更新日期
             )
          Values
            (s_Inv_Po_Lines.Nextval,
             v_Po_Header_Id,
             v_Line_Num,
             r_Line.Item_Id, --产品ID
             r_Line.Item_Code, --产品编码，即销售码
             r_Line.Item_Name, --产品名称
             r_Line.Commoditybarcode, --产品标识
             r_Line.Defaultunit, --产品单位
             v_Price, --产品价格
             r_Line.Shipment_Quantity, --开单数量
             p_User_Code,
             Sysdate,
             p_User_Code,
             Sysdate);
        Exception
          When Others Then
            p_Result := '插入中转单行表数据失败。' || v_Nl || Sqlerrm;
            Raise v_Base_Exception;
        End;
      End Loop;
    End If;

    --建立工单与采购单的关系
    If (p_Result = v_Success) Then
      If v_Pln_Wip_Ord_Match <> v_True Then
        Begin
          Insert Into t_Inv_Po_Wip_Detail
            (Wip_Detail_Id, --
             Organization_Id, --组织
             Entity_Id, --主体ID
             Wip_Entity_Id, --工单ID
             Wip_Entity_Code, --工单编码
             Po_Head_Id, --中转单头ID
             Order_Header_Id, --订单头ID
             Order_Line_Id, --订单行ID
             Order_Detail_Id, --订单明细行ID
             Item_Id, --产品ID
             Item_Code, --产品编码
             Item_Name, --产品名称
             Item_Bar_Code, --产品条码
             Executed_Qty, --执行数量
             Executed_Date, --执行时间
             Executed_Flag, --执行标志
             Created_By, --创建者
             Creation_Date, --创建日期
             Last_Updated_By, --更新者
             Last_Update_Date --更新日期
             )
            Select s_Inv_Po_Wip_Detail.Nextval, --
                   Pt.Organization_Id, --组织
                   Pt.Entity_Id, --主体ID
                   Pt.Wip_Entity_Id,
                   Pt.Wip_Entity_Code, --工单编码
                   v_Po_Header_Id, --中转单头ID
                   Null                        Order_Header_Id, --订单头ID
                   Null                        Order_Line_Id, --订单行ID
                   Null                        Order_Detail_Id, --订单明细行ID
                   Pt.Item_Id, --产品ID
                   Pt.Item_Code, --产品编码
                   Bi.Item_Name, --产品名称
                   Bi.Barcode, --产品条码
                   Pt.Quantity                 Executed_Qty, --执行数量
                   Null                        Executed_Date, --执行时间
                   v_False                     Executed_Flag, --执行标志
                   p_User_Code, --创建者
                   Sysdate, --创建日期
                   p_User_Code, --更新者
                   Sysdate --更新日期
              From t_Inv_Wip_To_Po_Trace Pt, t_Bd_Item Bi
             Where Pt.Trace_Trans_Id = p_Trace_Trans_Id
               And Bi.Item_Id = Pt.Item_Id;

          For r_Sup_Line In c_Sup_Line(v_Po_Header_Id) Loop
            Update t_Inv_Po_Wip_Detail Wd
               Set Wd.Po_Line_Id = r_Sup_Line.Po_Line_Id
             Where Wd.Po_Head_Id = r_Sup_Line.Po_Id
               And Wd.Item_Id = r_Sup_Line.Item_Id;
          End Loop;
        Exception
          When Others Then
            p_Result := '建立工单与采购单关系异常：' || v_Nl || Sqlerrm;
            Raise v_Base_Exception;
        End;
      Else
        Begin
          --获取订单入库顺序参数
          v_Supply_Seq := Pkg_Bd.f_Get_Parameter_Value('SUPPLY_IN_PROPER_ORDER',
                                                         p_Entity_Id);

          For r_Wip In (Select p.Producing_Area_Id,
                               t.Wip_Entity_Id,
                               t.Wip_Entity_Code,
                               t.Item_Id,
                               t.Item_Code,
                               bi.item_name Item_Desc,
                               bi.barcode,
                               t.Organization_Id,
                               t.inv_finance_id,
                               ii.inventory_code,
                               Sum(t.Quantity) Quantity,
                               t.Order_Detail_id
                          From t_Inv_Wip_To_Po_Trace t,
                               t_Pln_Producing_Area  p,
                               t_Inv_Inventories     ii,
                               t_bd_item             bi
                         Where p.Mrp_Org_Id = t.Organization_Id
                           And p.Entity_Id = p_Entity_Id
                           And t.Trace_Trans_Id = p_Trace_Trans_Id
                           And ii.inventory_id = t.inv_finance_id
                           And bi.item_id = t.item_id
                         Group By t.Trace_Trans_Id,
                                  t.Item_Id,
                                  t.Item_Code,
                                  bi.barcode,
                                  p.Producing_Area_Id,
                                  t.Wip_Entity_Id,
                                  t.Wip_Entity_Code,
                                  bi.item_name,
                                  t.Organization_Id,
                                  t.inv_finance_id,
                                  ii.inventory_code,
                                  t.Order_Detail_id) Loop
            v_Wip_Qty := r_Wip.Quantity;
            --add by lizhen 2015-07-13 获取仓库信息
            Begin
              Select *
                Into r_Inv_Inventories
                From t_Inv_Inventories Tii
               Where Tii.Inventory_Id = r_Wip.Inv_Finance_Id;
            Exception
              When Others Then
                p_Result := '获取入库仓库信息失败！' || v_Nl || Sqlerrm;
                Raise v_Base_Exception;
            End;

            v_Select_Sql := 'Select h.Order_Number,
                                   h.Order_Head_Id,
                                   l.Order_Line_Id,
                                   d.Order_Detail_Id,
                                   d.Item_Id,
                                   d.Item_Code,
                                   Trunc(Nvl(l.can_supply_date, Sysdate) + Nvl(t.Defer_Supply_Days, 0)) Can_Supply_Date,
                                   Nvl(d.Can_Produce_Qty -
                                       Nvl(d.Supply_Qty, 0) -
                                       Nvl(d.Cancel_Qty, 0) -
                                       decode('''||v_Source_Type_Code||''', ''03'', 0, (nvl(l.direct_transport_qty, 0) - nvl(l.cancel_direct_transport_qty, 0) - nvl(l.already_direct_transport_qty,0))),
                                       0) Order_Can_Supply_Qty
                              From t_Pln_Order_Detail d,
                                   t_Pln_Order_Head   h,
                                   t_Pln_Order_Line   l,
                                   t_Pln_Order_Type   t
                             Where d.Order_Head_Id = h.Order_Head_Id
                               And d.Entity_Id = h.Entity_Id
                               And d.Order_Line_Id = l.Order_Line_Id
                               And d.Order_Head_Id = h.Order_Head_Id
                               And d.Entity_Id = ' || p_Entity_Id || '
                               And d.order_detail_id = ' || r_Wip.Order_Detail_id ||
                               ' And d.Can_Produce_Qty -
                                   Nvl(d.Supply_Qty, 0) -
                                   Nvl(d.Cancel_Qty, 0) > 0
                               And d.Item_Id = ' || r_Wip.Item_Id || '
                               And Nvl(d.Close_Flag, ''N'') = ''N''
                               And h.Order_Type_Id = t.Order_Type_Id
                               And h.Entity_Id = t.Entity_Id
                               And t.Match_Type_Storage = ''按订单报送的时间先后顺序匹配''
                               And h.Form_State In (''32'', ''306'') ' || --('已排产', '已完成')
                               ' And t.Storage_Priority Is Not Null
                               And Exists
                             (Select 1
                                      From t_Pln_Order_Period p
                                     Where p.Period_Id = h.Period_Id
                                       And p.Entity_Id = h.Entity_Id
                                       And p.Begin_Date <= To_Date('''
                              || To_Char(v_Can_Supply_Date, 'YYYY-MM-DD') || ''', ''YYYY-MM-DD''))
                               And Exists
                             (Select 1
                                      From t_Pln_Wip_Order_Relation Wor
                                     Where Wor.Order_Detail_Id = d.Order_Detail_Id
                                       And Wor.Order_Line_Id = d.Order_Line_Id
                                       And Wor.Order_Head_Id = d.Order_Head_Id
                                       And ((Wor.Pln_Request_Qty - Wor.In_Inv_Qty -
                                           Wor.Wait_Execute_Qty > 0 And
                                           Wor.Source_Type = ''H'') Or
                                           (Nvl(Wor.Source_Type, ''A'') <> ''H''))
                                       And Wor.Wip_Entity_Id = ' || r_Wip.Wip_Entity_Id || ')';

            v_OrderBy_Sql := ' Order By Decode(''' || v_Supply_Seq || ''',
                                               ''周期优先'',
                                               h.Period_Id,
                                               1),
                                        Decode(''' || v_Supply_Seq || ''',
                                               ''定制订单优先'',
                                               h.Period_Id,
                                               1),
                                        t.Storage_Priority,
                                        Nvl(h.out_line_flag, ''N'') Desc,
                                        Nvl(h.Neat_Set_Rate, 0) Desc,
                                        h.Refer_Date,
                                        d.Can_Produce_Qty';
            --dbms_output.put_line(v_Select_Sql || v_OrderBy_Sql);
            Open v_Get_Pln_Order For v_Select_Sql || v_Nl || v_OrderBy_Sql;


            --工单本次可匹配数量按工单排产数量匹配
            Loop
              Fetch v_Get_Pln_Order Into r_Match_Order;
              Exit When v_Get_Pln_Order%Notfound;
              If v_Get_Pln_Order%Rowcount = 0 Then
                p_Result := '查询匹配订单失败，未找到可匹配的订单数据，工单单号：' || r_Wip.Wip_Entity_Code;
                Raise v_Base_Exception;
              End If;
              If r_Match_Order.Can_Supply_Date < Trunc(Sysdate) Then
                p_Result := '订单截止入库日期到期，工单无法入库。' || v_Nl ||
                  '工单单号：' || r_Wip.Wip_Entity_Code || v_Nl ||
                  '订单单号：' || r_Match_Order.Order_Number || v_Nl ||
                  '产品编码：' || r_Match_Order.Item_Code || v_Nl ||
                  '截止入库日期：' || To_Char(r_Match_Order.Can_Supply_Date, 'YYYY-MM-DD');
                Raise v_Base_Exception;
              End If;

              --by sushu 2016-1-12
              --根据主体判断是否必须入同一个仓库，当为N时，不需要校验入同一个仓库，为Y必须入到一个仓库
              --获取工单与订单是否完全匹配参数
              v_Order_Input_Same_Inven_Flag := Pkg_Bd.F_Get_Parameter_Value('inv_order_input_same_inventory',
                                                        p_Entity_Id);
              If(v_Order_Input_Same_Inven_Flag = 'Y' and nvl(v_source_type_code,'01') <> '03') Then
                Begin
                  --add by lizhen 2015-07-09下线直发订单允许工单中转库存单存在下线直发仓、基地正品财务仓两种仓库的单据
                  Select Iph.Inv_Finance_Id,
                         Iph.Inv_Finance_Code,
                         Tii.Organization_Id
                    Into v_Order_Inventory_Id,
                         v_Order_Inventory_Code,
                         v_Order_Inv_Org_Id
                    From Cims.t_Inv_Po_Headers        Iph,
                         Cims.t_Inv_Po_Lines          Ipl,
                         Cims.t_Inv_Po_Wip_Detail     Pwd,
                         Cims.t_Inv_Bill_Types        Ibt,
                         Cims.t_Inv_Transaction_Types Itt,
                         Cims.t_Inv_Inventories       Tii --add by lizhen 2015-07-09 下线直发仓可与基地仓共同入库
                   Where Iph.Po_Id = Ipl.Po_Id
                     And Ipl.Po_Line_Id = Pwd.Po_Line_Id
                     And Iph.Po_Id = Pwd.Po_Head_Id
                     And Ibt.Bill_Type_Id = Iph.Po_Type_Id
                     And Tii.Inventory_Id = Iph.Inv_Finance_Id --add by lizhen 2015-07-09
                     And Nvl(Tii.Out_Line_Flag, 'N') != 'Y' --add by lizhen 2015-07-09
                     and Iph.Ship_Doc_Code is null
                     And Itt.Transaction_Type_Id = Ibt.Transaction_Type_Id
                     And Pwd.Order_Line_Id = r_Match_Order.Order_Line_Id
                     And Pwd.Order_Header_Id = r_Match_Order.Order_Head_Id
                     And Itt.Action_Type = '01'
                     And Nvl(Iph.Close_Flag, v_False) = v_False
                     And Iph.Source_Type = '工单入库' Having
                   Sum(Pwd.Executed_Qty -
                             Nvl((Select Sum(Pol.Executed_Qty)
                                   From t_Inv_Po_Headers      Ph,
                                        t_Inv_Po_Lines        Il,
                                        t_Inv_Po_Lines_Detail Pol
                                  Where Ph.Po_Id = Il.Po_Id
                                    And Pol.Po_Line_Id = Il.Po_Line_Id
                                    And Pol.Po_Head_Id = Ph.Po_Id
                                    And Ph.Old_Po_Id = Iph.Po_Id
                                    And Pol.Order_Header_Id =
                                        Pwd.Order_Header_Id
                                    And Pol.Order_Line_Id = Pwd.Order_Line_Id
                                    And Pol.Order_Detail_Id =
                                        Pwd.Order_Detail_Id
                                    And Pol.Wip_Entity_Id = Pwd.Wip_Entity_Id),
                                 0)) > 0
                   Group By Iph.Inv_Finance_Id,
                            Iph.Inv_Finance_Code,
                            Tii.Organization_Id, --add by lizhen 2015-07-13
                            Pwd.Order_Header_Id,
                            Pwd.Order_Line_Id;

                  If r_Wip.Inv_Finance_Id <> v_Order_Inventory_Id And
                     Nvl(r_Inv_Inventories.Out_Line_Flag, 'N') != 'Y' Then
                    p_Result := '订单已执行的中转单入库财务仓库编码与本次入库仓库编码不一致。' || v_Nl ||
                                '订单明细行ID：' || r_Match_Order.Order_Detail_Id || v_Nl ||
                                '工单编码：' || r_Wip.Wip_Entity_Code || v_Nl ||
                                '产品编码：' || r_Wip.Item_Code || v_Nl ||
                                '已入库仓库编码：' || v_Order_Inventory_Code || v_Nl ||
                                '本次入库仓库编码：' || r_Wip.Inventory_Code || v_Nl ||
                                Sqlerrm;
                    Raise v_Base_Exception;
                  End If;
                  --ADD BY LIZHEN 2015-07-13下线直发仓必须与非下线直发仓为同一库存组织
                  If Nvl(v_Order_Inv_Org_Id, 0) <>
                     Nvl(r_Inv_Inventories.Organization_Id, 0) And
                     Nvl(r_Inv_Inventories.Out_Line_Flag, 'N') = 'Y' Then
                    p_Result := '订单已执行的中转单入库财务仓库库存组织与本次入库仓库库存组织不一致。' || v_Nl ||
                                '订单明细行ID：' || r_Match_Order.Order_Detail_Id || v_Nl ||
                                '工单编码：' || r_Wip.Wip_Entity_Code || v_Nl ||
                                '产品编码：' || r_Wip.Item_Code || v_Nl ||
                                '已入库仓库存组织ID：' || To_Char(v_Order_Inv_Org_Id) || v_Nl ||
                                '已入库仓库编码：' || v_Order_Inventory_Code || v_Nl ||
                                '本次入库仓库存组织ID：' ||
                                To_Char(r_Inv_Inventories.Organization_Id) || v_Nl ||
                                '本次入库仓库编码：' || r_Wip.Inventory_Code || v_Nl ||
                                Sqlerrm;
                    Raise v_Base_Exception;
                  End If;
                Exception
                  When Too_Many_Rows Then
                    p_Result := '获取订单已执行的中转单入库财务仓信息失败，订单明细行对应多个财务仓。' || v_Nl ||
                                '订单明细行ID：' || r_Match_Order.Order_Detail_Id || v_Nl ||
                                '工单编码：' || r_Wip.Wip_Entity_Code || v_Nl ||
                                '产品编码：' || r_Wip.Item_Code || v_Nl || Sqlerrm;
                    Raise v_Base_Exception;
                  When No_Data_Found Then
                    Null;
                  When Others Then
                    p_Result := '查询已入库仓库信息失败！' || v_Nl || p_Result || Sqlerrm;
                    Raise v_Base_Exception;
                End;
              End If;


              Begin
                Select Sum(Pwd.Executed_Qty)--, Iph.Inv_Finance_Id
                  Into v_Sum_Wip_Detail_Qty--, v_Order_Inventory_Id
                  From t_Inv_Po_Wip_Detail Pwd, t_Inv_Po_Headers Iph
                 Where Nvl(Pwd.Executed_Flag, v_False) <> v_True
                   And Pwd.Order_Detail_Id = r_Match_Order.Order_Detail_Id
                   And Pwd.Order_Line_Id = r_Match_Order.Order_Line_Id
                   And Pwd.Order_Header_Id = r_Match_Order.Order_Head_Id
                   And Pwd.Item_Id = r_Match_Order.Item_Id
                   --MODI BY LIZHEN 2015-02-03 检查订单的中转在途数量（订单对应的所有工单）
                   --And Pwd.Wip_Entity_Id = r_Wip.Wip_Entity_Id --只查检当前工单未执行的入库数量
                   And Iph.Po_Id = Pwd.Po_Head_Id
                   And nvl(pwd.executed_flag, v_False) = v_False
                   And Exists
                 (Select 1
                          From t_Inv_Po_Headers o, t_Inv_Po_Lines l
                         Where o.Po_Id = l.Po_Id
                           And o.Po_Id = Pwd.Po_Head_Id
                           And l.Po_Line_Id = Pwd.Po_Line_Id
                           And l.Item_Id = Pwd.Item_Id
                              --只检查工单明细行是否存在中转单，为工单入库的，不检查中转单是否执行
                              --因为存在执行了，但是没有生成中转明细行。避免合并工单 中转单执行，但明细行未执行，导致重复匹配同一订单明细行问题
                           And o.Source_Type = '工单入库'
                           And o.Entity_Id = p_Entity_Id
                           And o.Old_Po_Id Is Null);
                 --Group By Iph.Inv_Finance_Id;
              Exception
                When Too_Many_Rows Then
                  p_Result := '获取订单未执行的中转单入库财务仓信息失败，订单明细行对应多个财务仓。' || v_Nl ||
                              '订单明细行ID：' || r_Match_Order.Order_Detail_Id || v_Nl ||
                              '工单编码：' || r_Wip.Wip_Entity_Code || v_Nl ||
                              '产品编码：' || r_Wip.Item_Code || v_Nl || Sqlerrm;
                  Raise v_Base_Exception;
                When No_Data_Found Then
                  v_Sum_Wip_Detail_Qty := 0;
                When Others Then
                  p_Result := '获取订单未执行的中转单入库财务仓信息、匹配数量失败。' || v_Nl ||
                              '订单明细行ID：' || r_Match_Order.Order_Detail_Id || v_Nl ||
                              '工单编码：' || r_Wip.Wip_Entity_Code || v_Nl ||
                              '产品编码：' || r_Wip.Item_Code || v_Nl || Sqlerrm;
                  Raise v_Base_Exception;
              End;
              v_Wip_Match_Qty := r_Match_Order.Order_Can_Supply_Qty;

              Begin
                Select Nvl(Wor.Pln_Request_Qty, 0) - Nvl(Wor.In_Inv_Qty, 0) -
                       Nvl(Wor.Wait_Execute_Qty, 0)
                  Into v_Pln_Order_Qty
                  From t_Pln_Wip_Order_Relation Wor
                 Where Wor.Wip_Entity_Id = r_Wip.Wip_Entity_Id
                   And Wor.Order_Detail_Id = r_Match_Order.Order_Detail_Id;
              Exception
                When Others Then
                  p_Result := '获取工单与订单匹配关系信息失败，工单ID:' || To_Char(r_Wip.Wip_Entity_Id)
                           || '，订单明细行ID：' || To_Char(r_Match_Order.Order_Detail_Id) || v_Nl || Sqlerrm;
                  Raise v_Base_Exception;
              End;
              --按最小数量匹配
              v_Pln_Qty := Least(v_Wip_Qty,
                                 v_Wip_Match_Qty -
                                 Nvl(v_Sum_Wip_Detail_Qty, 0), nvl(v_Pln_Order_Qty, 0));
              If r_Match_Order.Order_Can_Supply_Qty - Nvl(v_Sum_Wip_Detail_Qty, 0) < v_Pln_Qty Then
                Exit;
                p_Result := Substr('工单的可匹配数量大于订单的可入库量，工单可匹配数量：' ||
                                   v_Wip_Match_Qty || '，订单可入库数量：' ||
                                   r_Match_Order.Order_Can_Supply_Qty - Nvl(v_Sum_Wip_Detail_Qty, 0) || v_Nl ||
                                   Sqlerrm,
                                   1,
                                   240);
                Raise v_Base_Exception;
              End If;

              If v_Pln_Qty > 0 Then
                Insert Into t_Inv_Po_Wip_Detail
                  (Wip_Detail_Id, --
                   Organization_Id, --组织
                   Entity_Id, --主体ID
                   Wip_Entity_Id, --工单ID
                   Wip_Entity_Code, --工单编码
                   Po_Head_Id, --中转单头ID
                   Po_Line_Id, --中转单行ID
                   Order_Header_Id, --订单头ID
                   Order_Line_Id, --订单行ID
                   Order_Detail_Id, --订单明细行ID
                   Item_Id, --产品ID
                   Item_Code, --产品编码
                   Item_Name, --产品名称
                   Item_Bar_Code, --产品条码
                   Executed_Qty, --执行数量
                   Executed_Date, --执行时间
                   Executed_Flag, --执行标志
                   Created_By, --创建者
                   Creation_Date, --创建日期
                   Last_Updated_By, --更新者
                   Last_Update_Date --更新日期
                   )
                  Select s_Inv_Po_Wip_Detail.Nextval, --
                         r_Wip.Organization_Id, --组织
                         p_Entity_Id, --主体ID
                         r_Wip.Wip_Entity_Id,
                         r_Wip.Wip_Entity_Code, --工单编码
                         v_Po_Header_Id, --中转单头ID
                         (Select Ipl.Po_Line_Id
                            From t_Inv_Po_Lines Ipl
                           Where Ipl.Po_Id = v_Po_Header_Id
                             And Ipl.Item_Id = r_Wip.Item_Id),
                         r_Match_Order.Order_Head_Id, --订单头ID
                         r_Match_Order.Order_Line_Id, --订单行ID
                         r_Match_Order.Order_Detail_Id, --订单明细行ID
                         r_Wip.Item_Id, --产品ID
                         r_Wip.Item_Code, --产品编码
                         r_Wip.Item_Desc, --产品名称
                         r_Wip.Barcode, --产品条码
                         v_Pln_Qty, --执行数量
                         Null, --执行时间
                         v_False, --执行标志
                         p_User_Code, --创建者
                         Sysdate, --创建日期
                         p_User_Code, --更新者
                         Sysdate --更新日期
                    From Dual;
              End If;

              --更新已匹配数量
              Update t_Pln_Wip_Order_Relation Wor
                 Set Wor.Wait_Execute_Qty = Nvl(Wor.Wait_Execute_Qty, 0) +
                                            v_Pln_Qty,
                     Wor.Last_Update_Date = Sysdate,
                     Wor.Last_Updated_By  = p_User_Code
               Where Wor.Wip_Entity_Id = r_Wip.Wip_Entity_Id
                 And Wor.Order_Detail_Id = r_Match_Order.Order_Detail_Id
                 And Wor.Order_Line_Id = r_Match_Order.Order_Line_Id
                 And Wor.Item_Id = r_Match_Order.Item_Id
                 And Wor.Order_Head_Id = r_Match_Order.Order_Head_Id;

              v_Wip_Qty          := v_Wip_Qty - v_Pln_Qty;
              v_Wip_Detail_Count := v_Wip_Detail_Count + 1;
              If v_Wip_Qty < 0 Or v_Pln_Qty < 0 Then
                p_Result := '工单匹配订单时错误，工单数量不满足订单匹配量！' || '工单可匹配数量：' ||
                            v_Wip_Qty || '，订单需匹配数量：' || v_Pln_Qty;
                Raise v_Base_Exception;
              End If;
              Exit When v_Wip_Qty <= 0;
              --A_RESULT存 信息时退出循环
              If p_Result <> v_Success Then
                Exit;
              End If;
            End Loop;
            Close v_Get_Pln_Order;
            If v_Wip_Qty > 0 Then
              p_Result := '工单匹配订单时错误，工单数量超过订单匹配量！' || v_Nl ||
                '剩余未匹配数量：' || v_Wip_Qty || v_Nl ||
                '工单单号：' || r_Wip.Wip_Entity_Code;
              Raise v_Base_Exception;
            End If;

            --P_RESULT存信息时退出循环
            If p_Result != v_Success Then
              Exit;
            End If;
          End Loop;

          For r_Sup_Line In c_Sup_Line(v_Po_Header_Id) Loop
            Update t_Inv_Po_Wip_Detail d
               Set d.Po_Line_Id = r_Sup_Line.Po_Line_Id
             Where d.Po_Head_Id = r_Sup_Line.Po_Id
               And Item_Id = r_Sup_Line.Item_Id;
          End Loop;

        Exception
          When Others Then
            p_Result := '建立工单与采购单关系异常：' || p_Result || v_Nl || Sqlerrm;
            Raise v_Base_Exception;
        End;
      End If;
    End If;
    --没有找到订划订单关系时提示用户
    If p_Result = v_Success And v_Pln_Wip_Ord_Match = v_True And
       v_Wip_Detail_Count = 0 Then
      p_Result := '工单未找到可匹配的订单信息！';
      Raise v_Base_Exception;
    End If;
    --验证工单与采购单的关系
    If (p_Result = v_Success) Then
      Begin
        Select Count(*)
          Into v_Find
          From (Select Po_Line_Id, Item_Id, Sum(Quantity) Quantity
                  From (Select Po_Line_Id,
                               Item_Id,
                               Sum(Executed_Qty) Quantity
                          From t_Inv_Po_Wip_Detail
                         Where Po_Head_Id = v_Po_Header_Id
                         Group By Po_Line_Id, Item_Id
                        Union All
                        Select Po_Line_Id, Item_Id, Sum(-billed_Qty) Quantity
                          From t_Inv_Po_Lines
                         Where Po_Id = v_Po_Header_Id
                         Group By Po_Line_Id, Item_Id)
                 Group By Po_Line_Id, Item_Id
                Having Sum(Quantity) <> 0);
        If (v_Find > 0) Then
          p_Result := '生成的工单与采购单行的关系不正确,请重新生成！';
          Raise v_Base_Exception;
        End If;
      Exception
        When Others Then
          p_Result := Substr('验证生成的工单与采购单行的关系异常：' || Sqlerrm,
                             1,
                             240);
          Raise v_Base_Exception;
      End;
    End If;

    If (p_Result <> v_Success) Then
      Rollback;
      Update t_Inv_Wip_To_Po_Trace t
         Set t.Close_Flag = 'E', t.Err_Msg = p_Result
       Where t.Trace_Trans_Id = p_Trace_Trans_Id;
    Else
      If p_Result = v_Success Then
        Begin
          Select u.User_Id
            Into v_User_Id
            From Up_Org_User u
           Where u.Account = p_User_Code;
          v_Po_Order_Number := Pkg_Bd.f_Get_Bill_No('invPONum',
                                                    '',
                                                    p_Entity_Id,
                                                    v_User_Id);
          If v_Po_Order_Number = '' Then
            Raise v_Base_Exception;
          End If;
        Exception
          When Others Then
            p_Result := '获取中转单单号失败，单据号生成规则：invPONum。' || v_Nl ||
                        Sqlerrm;
            Raise v_Base_Exception;
        End;
        Update t_Inv_Po_Headers Ph
           Set Ph.Po_Num = v_Po_Order_Number
         Where Ph.Po_Id = v_Po_Header_Id;

        --关闭临时表
        If (p_Result = v_Success) Then
          Update t_Inv_Wip_To_Po_Trace t
             Set t.Close_Flag = v_True,
                 t.Po_Head_Id = v_Po_Header_Id,
                 t.Po_Number  = v_Po_Order_Number
           Where t.Trace_Trans_Id = p_Trace_Trans_Id;
        End If;
      End If;
      p_Po_Order_Number := v_Po_Order_Number; --返回中转单号
    End If;
  Exception
    When v_Base_Exception Then
      Rollback;
      p_Result := '工单中转入库失败，' || p_Result;
      Update t_Inv_Wip_To_Po_Trace t
         Set t.Close_Flag = 'E', t.Err_Msg = p_Result
       Where t.Trace_Trans_Id = p_Trace_Trans_Id;
       If v_Input_Num Is Not Null Then   -- by sushu 2016-08-05
         Update t_Inv_Lms_Stockin_Headers Lsh
            Set Lsh.Remark = p_Result
          Where Lsh.Input_Num = v_Input_Num
            And Lsh.Entity_Id = p_Entity_Id;
       End If;
      Commit;
    When Others Then
      Rollback;
      p_Result := Substr('异常：' || Sqlerrm, 1, 240);
      Update t_Inv_Wip_To_Po_Trace t
         Set t.Close_Flag = 'E', t.Err_Msg = p_Result
       Where t.Trace_Trans_Id = p_Trace_Trans_Id;
       If v_Input_Num Is Not Null Then    -- by sushu 2016-08-05
         Update t_Inv_Lms_Stockin_Headers Lsh
            Set Lsh.Remark = p_Result
          Where Lsh.Input_Num = v_Input_Num
            And Lsh.Entity_Id = p_Entity_Id;
       End If;
      Commit;
  End;

  --------------------------------------------------------------------------
  --Author: Nicro.li
  --Purpose:中转单执行，进行工单与订单匹配入库
  --------------------------------------------------------------------------
  Procedure p_Execute_Po_Match(p_Po_Head_Id In Number, --中转单头ID
                               p_Entity_Id  In Number, --主体ID
                               p_User_Code  In Varchar2, --用户ID
                               p_Result     Out Varchar2) Is
   r_Po_Head t_inv_po_headers%Rowtype;

    Cursor c_Po_Line Is
      Select *
        From t_Inv_Po_Lines Pl
       Where Pl.Po_Id = p_Po_Head_Id
         For Update Nowait;
    r_Po_Line c_Po_Line%Rowtype;
    v_Value   Varchar2(2000);
  Begin
    p_Result := v_Success;
    Begin
      Select * Into r_Po_Head
        From t_Inv_Po_Headers Ph
       Where Ph.Entity_Id = p_Entity_Id
         And Ph.Po_Id = p_Po_Head_Id
         For Update Nowait;
    Exception
      When Others Then
        p_Result := '锁定中转单头信息失败！中转单头ID：' || To_Char(p_Po_Head_Id) || v_Nl ||
                    Sqlerrm;
        Return;
    End;
    --add by lizhen 中转入库单蓝单，必须执行状态做订单匹配
    -- If r_Po_Head.Source_Type = '工单入库' then
    If r_Po_Head.Source_Type = '工单入库' And (r_Po_Head.Old_Po_Id Is Not Null Or
      (r_Po_Head.Old_Po_Id Is Null And r_Po_Head.Po_Status = '14')) Then
      Open c_Po_Line;
      Loop
        Fetch c_Po_Line
          Into r_Po_Line;
        Exit When c_Po_Line%Notfound;
        p_Execute_Wip_Ord_Match(r_Po_Line.Po_Line_Id, --中转单行ID
                                Nvl(r_Po_Line.Executed_Qty, r_Po_Line.Billed_Qty), --事务数量带正负号
                                p_Entity_Id, --主体ID
                                p_User_Code, --用户ID
                                p_Result);
        If p_Result <> v_Success Then
          Rollback;
          Return;
        End If;
      End Loop;
      Close c_Po_Line;
    End If;
  Exception
    When Others Then
      Rollback;
      p_Result := '失败：' || Sqlerrm;
  End;

  --------------------------------------------------------------------------
  --Author: Nicro.li
  --Purpose:中转单执行，进行工单与订单匹配入库
  --------------------------------------------------------------------------
  Procedure p_Read_Wip_Ord_Match(p_Po_Line_Id    In Number, --中转单行ID
                                 p_Tran_Quantity In Number, --事务数量带正负号
                                 p_Entity_Id     In Number, --主体ID
                                 p_User_Code     In Varchar2, --用户ID
                                 p_Result        Out Varchar2) Is
    v_Pln_Wip_Order_Match Varchar2(10); --工单与订单是否完全匹配

    --红冲单据 可入库订单明细行游标
    Cursor c_Order_Red(i_Item_Id           Number,
                       i_Producing_Area_Id Number,
                       i_Supply_Seq        Varchar2,
                       i_Month_Match       Varchar2,
                       i_Order_Detail_Id   Number,
                       i_Inventory_Id      Number) Is
      Select h.Order_Number,
             h.Order_Head_Id,
             l.Order_Line_Id,
             d.Order_Detail_Id,
             h.Period_Id,
             h.Order_Type_Id,
             h.Form_State,
             h.Supply_Date,
             d.Item_Id,
             d.Item_Code,
             d.Item_Name,
             d.Item_Uom,
             l.Item_Id Ass_Item_Id,
             l.Item_Code Ass_Item_Code,
             l.Item_Desc Ass_Item_Name,
             l.Item_Price,
             d.Can_Produce_Qty Order_Qty,
             Nvl(d.Supply_Qty, 0) Can_Red_Qty,
             Nvl((Select Sum(Nvl(Oss.Carry_Qty, 0))
                   From t_Pln_Order_Share_Shipment Oss
                  Where Oss.Inventory_From_Id = i_Inventory_Id
                    And Nvl(Oss.Inv_Share_Flag, 'N') = 'N'
                    And Oss.Origin_Line_Id = d.Order_Line_Id),
                 0) Carry_No_So_Order_Qty,
             h.Customer_Id,
             h.Customer_Code,
             h.Customer_Name,
             t.is_lock_inv_flag
        From t_Pln_Order_Detail d,
             t_Pln_Order_Head   h,
             t_Pln_Order_Line   l,
             t_Pln_Order_Type   t
       Where d.Order_Head_Id = h.Order_Head_Id
         And d.Entity_Id = h.Entity_Id
         And d.Order_Line_Id = l.Order_Line_Id
         And d.Order_Head_Id = h.Order_Head_Id
         And d.Producing_Area_Id = i_Producing_Area_Id
         And d.Entity_Id = p_Entity_Id
         And d.Item_Id = i_Item_Id
         And Nvl(d.Supply_Qty, 0) > 0
         And h.Order_Type_Id = t.Order_Type_Id
         And h.Entity_Id = t.Entity_Id
         And h.Form_State In ('32', '306') --('已排产', '已完成')
         And t.Match_Type_Storage = '按订单报送的时间先后顺序匹配'
         And t.Storage_Priority Is Not Null
            --增加中转单红冲时，取消订单与工单配匹关系只取消系统日期当前月份的订单
         And ((v_Pln_Wip_Order_Match = v_False And Exists
              (Select 1
                  From t_Pln_Order_Period p
                 Where p.Period_Id = h.Period_Id
                   And p.Entity_Id = h.Entity_Id)) Or
             (v_Pln_Wip_Order_Match = v_True And
             d.Order_Detail_Id = i_Order_Detail_Id
             --必须散件存在占用库存量
             And (t.Is_Lock_Inv_Flag = v_True And
             Pkg_Pln_Inv_Occupy.f_Item_Ass_Occupy_Qty(i_Inventory_Id,
                                                        d.Item_Id,
                                                        v_Pln_Wip_Order_Match,
                                                        p_Entity_Id,
                                                        l.Order_Line_Id) > 0 Or
       t.Is_Lock_Inv_Flag = v_False)))
       Order By Decode(i_Supply_Seq, '周期优先', h.Period_Id, 1) Desc,
                Decode(i_Supply_Seq, '定制订单优先', h.Period_Id, 1) Desc,
                t.Storage_Priority Desc,
                h.Refer_Date Desc,
                Order_Qty Desc;
    r_Po_Line          t_Inv_Po_Lines%Rowtype;
    v_Value            Varchar2(2000);
    v_Changer_Period   Number; --定单制切换周期
    v_Count            Number; --计数
    v_Fin_Inventory_Id Number; --财务仓ID
    v_Order_Type_Name  Varchar2(100);

    v_Po_Head_Id          Number;
    v_Item_Id             Number;
    v_Item_Code           Varchar2(60);
    v_Item_Name           Varchar2(254);
    v_Item_Uom_Code       Varchar2(100);
    v_Po_Order_Number     Varchar2(100);
    v_Old_Po_Head_Id      Number;
    v_Red_Order_Flag      Varchar2(10);
    v_Old_Po_Number       Varchar2(60);
    v_Old_Po_Line_Id      Number;
    v_Is_Custom_Flag      Varchar2(2);
    v_Inv_Days            Number;
    v_Can_Supply_Date     Date;
    v_Supply_Seq          Varchar2(100);
    v_Producing_Area_Id   Number;
    v_Producing_Area_Name Varchar2(100);

    v_Can_Supply_Qty  Number; --订单可入库数量
    v_Fcan_Supply_Qty Number;
    v_Po_Executed_Qty Number;

    v_Wip_Entity_Id         Number;
    v_Wip_Can_Supply_Qty    Number;
    v_Curr_Wip_Supply_Qty   Number := 0;
    v_Order_Match_Qty       Number := 0;
    v_Pln_Detail_Supply_Qty Number := 0;
    v_Err_Num               Number;

    v_Organization_Id         Number;
    v_Item_Onhand_Qty         Number := 0; --库存现有量
    v_Item_Occupy_Qty         Number := 0; --产品总占用量
    v_Usable_Qoh_Qty          Number := 0;
    v_Inv_No_Carry_Order_Qty  Number := 0; --库存评审已分配未下达数量
    v_Pln_Occupy_Qty          Number := 0; --定制机占用量
    v_Item_Share_Qty          Number := 0; --已分配未下达数量
    v_Usable_Occupy_Qty       Number := 0; --可释放占用数量
    v_Order_Usable_Red_Qty    Number := 0; --订单可红冲数量
    v_Curr_Wip_Red_Qty        Number := 0;
    v_Order_Red_Match_Qty     Number := 0;
    v_Wip_Execute_Qty         Number := 0; --工单已入库数量
    v_Tran_Quantity           Number := 0; --
    v_Not_Inv_Lock_Qty        Number := 0; --非库存占用的中转入库单数量
    v_Read_Po_Wip_Qty         Number := 0; --已发货确订未执行的红冲中转入库数量
    v_Check_Qty               Number;
  Begin
    p_Result := v_Success;
    v_Tran_Quantity := p_Tran_Quantity;
    --获取工单与订单是否完全匹配参数
    v_Pln_Wip_Order_Match := Pkg_Bd.f_Get_Parameter_Value('PLN_WIP_ORD_MATCH',
                                                            p_Entity_Id);
    Begin
      --中转单头ID,商品
      v_Value := '获取中转单头ID,商品ID';
      Select *
        Into r_Po_Line
        From t_Inv_Po_Lines Ipl
       Where Ipl.Po_Line_Id = p_Po_Line_Id;

      v_Po_Head_Id    := r_Po_Line.Po_Id;
      v_Item_Id       := r_Po_Line.Item_Id;
      v_Item_Code     := r_Po_Line.Item_Code;
      v_Item_Name     := r_Po_Line.Item_Name;
      v_Item_Uom_Code := r_Po_Line.Uom_Code;

      --中转单号
      v_Value := '获取中转单号';
      Select o.Po_Num, o.Inv_Finance_Id, t.Bill_Type_Name
        Into v_Po_Order_Number, v_Fin_Inventory_Id, v_Order_Type_Name
        From t_Inv_Po_Headers o, t_Inv_Bill_Types t
       Where o.Po_Id = v_Po_Head_Id
         And o.Entity_Id = p_Entity_Id
         And t.Bill_Type_Id = o.Po_Type_Id;

      --获取财务仓仓库ID --
      v_Value := '判断发货仓库是否总部基地仓库';
      --判断发货仓库是否总部基地仓库；如果是总部基地仓库，才继续操作。
      Select Count(*)
        Into v_Count
        From t_Inv_Inventories Ii
       Where Ii.Entity_Id = p_Entity_Id
         And Ii.Inventory_Id = v_Fin_Inventory_Id
         And Trunc(Sysdate) Between Ii.Begin_Date And
             Nvl(Ii.End_Date, Sysdate + 1)
         And Ii.Base_Flag = v_True;
      If v_Count = 0 Then
        Raise v_Base_Exception; --不执行采购中转库存事务，直接退出。
      End If;

      --判断是否红冲单据
      v_Value := '判断中转单:' || v_Po_Order_Number || '是否红冲单据 ';
      Select Iph.Old_Po_Id
        Into v_Old_Po_Head_Id
        From t_Inv_Po_Headers Iph
       Where Iph.Po_Id = v_Po_Head_Id
         And Iph.Entity_Id = p_Entity_Id;
      --如果原单号不为空，则表示当前采购单据是红冲单；否则是蓝单。
      If v_Old_Po_Head_Id Is Not Null Then
        v_Red_Order_Flag := v_True; --当前采购是否红冲单
        v_Value          := '查找原单是否待检,单号：' || v_Old_Po_Head_Id;
        Select Iph.Po_Num
          Into v_Old_Po_Number
          From t_Inv_Po_Headers Iph
         Where Iph.Po_Id = v_Old_Po_Head_Id;
      Else
        v_Red_Order_Flag := v_False; --当前采购是否红冲单
      End If;
      --订单可入库时间(相对周期开始日期的天数)
      v_Value           := '获取[订单可入库时间]主体参数';
      v_Inv_Days        := -to_Number(Nvl(Pkg_Bd.F_Get_Parameter_Value('ORDER_ADVANCE_SUPPLY_DAYS',
                                                                         p_Entity_Id),
                                          '0'));
      v_Can_Supply_Date := Trunc(Sysdate + v_Inv_Days);

      --获取订单入库顺序参数
      v_Supply_Seq := Pkg_Bd.F_Get_Parameter_Value('SUPPLY_IN_PROPER_ORDER',
                                                     p_Entity_Id);
    Exception
      When Others Then
        v_Value := '步骤:' || v_Value || '失败!系统信息:' || Sqlerrm;
        Raise v_Base_Exception;
    End;

    --工单入库(红冲单据)
    If p_Result = v_Success Then
      --获取原采购中转单行ID
      v_Value := '获取原采购中转单行ID ,中转单号:' || v_Po_Order_Number;
      Select l.Po_Line_Id_Old
        Into v_Old_Po_Line_Id
        From t_Inv_Po_Lines l
       Where l.Po_Id = v_Po_Head_Id
         And l.Po_Line_Id = p_Po_Line_Id;
    End If;

    If p_Result = v_Success Then
      Begin
        v_Value := '获取产地';
        Select a.Producing_Area_Id, Wii.Organization_Id
          Into v_Producing_Area_Id, v_Organization_Id
          From t_Inv_Wip_In_Info Wii, t_Pln_Producing_Area a
         Where a.Mrp_Org_Id = Wii.Organization_Id
           And a.Entity_Id = p_Entity_Id
           And Wii.Wip_Entity_Id =
               (Select d.Wip_Entity_Id
                  From t_Inv_Po_Lines_Detail d
                 Where d.Po_Line_Id = v_Old_Po_Line_Id
                   And Rownum = 1);
      Exception
        When Others Then
          v_Value := '获取产地失败，中转单行ID：' || To_Char(v_Old_Po_Line_Id) || v_Nl ||
                     Sqlerrm;
          Raise v_Base_Exception;
      End;
    End If;


        Pkg_Inv_Pub.p_Get_Item_Inv_Qoh(p_Entity_Id         => p_Entity_Id,
                                       p_Inventory_Id      => v_Fin_Inventory_Id,
                                       p_Item_Id           => v_Item_Id,
                                       p_User_Code         => p_User_Code,
                                       p_Qoh_Qty           => v_Item_Onhand_Qty,
                                       p_Usable_Qoh_Qty    => v_Usable_Qoh_Qty,
                                       p_Occupy_Qty        => v_Item_Occupy_Qty,
                                       p_Result            => v_Value);
        If v_Value != v_Success Then
          v_Value := '获取库存现有量、库占用数量失败';
          Raise v_Base_Exception;
        End If;
      If v_Pln_Wip_Order_Match <> v_True Then
      --获取库存占用数量
      If p_Result = v_Success Then
        v_Value := '获取库存占用数量';
        Begin

        Select Pkg_Pln_Inv_Occupy.f_Get_Item_Occupy_Qty(v_Fin_Inventory_Id,
                                                        v_Item_Id,
                                                        p_Entity_Id,
                                                        v_Pln_Wip_Order_Match)
          Into v_Pln_Occupy_Qty
          From Dual;
      Exception
        When No_Data_Found Then
          v_Item_Occupy_Qty := 0;
        When Others Then
          p_Result := v_Value || '失败!' || '错误信息:' || p_Result || Sqlerrm;
          Raise v_Base_Exception;
      End;
    End If;

      --获取定制机占用数量
      If p_Result = v_Success Then
        v_Value := '获取定制机占用数量';
        Begin
          --计算套散件时，必需*套散件表的数量
          Select Nvl(Sum((Nvl(Oss.Share_Qty, 0) - Nvl(Oss.So_Order_Qty, 0)) *
                     Nvl((Select Ias.Quantity
                           From t_Bd_Item_Assemblies     Bia,
                                t_Bd_Item_Assemblies_Sub Ias
                          Where Bia.Item_Assembly_Id =
                                Ias.Item_Assembly_Id
                            And Bia.Entity_Id = Ias.Entity_Id
                            And Trunc(Sysdate) Between Bia.Begin_Date And
                                Nvl(Bia.End_Date, Sysdate)
                            And Trunc(Sysdate) Between Ias.Begin_Date And
                                Nvl(Ias.End_Date, Trunc(Sysdate))
                               --And Nvl(Ias.Fittings_Flag, v_False) = v_False
                            And Bia.Item_Id = Oss.Item_Id
                            And ias.item_id = v_Item_Id
                         Union All
                         --非套件产品
                         Select 1 Quantity
                           From t_Bd_Item Tbi
                          Where Tbi.Item_Id = Oss.Item_Id
                            And Not Exists
                          (Select 1
                                   From t_Bd_Item_Assemblies Bia
                                  Where Bia.Item_Id = Tbi.Item_Id
                                    And Bia.Item_Id = Oss.Item_Id
                                    And Trunc(Sysdate) Between
                                        Bia.Begin_Date And
                                        Nvl(Bia.End_Date, Sysdate))),
                         1)),
                     0)
            Into v_Item_Share_Qty
          --可用分配数量 ＝ 已分配数量 － 已开单数量
            From t_Pln_Order_Share_Shipment Oss
           Where Oss.Entity_Id = p_Entity_Id
             And Oss.Inventory_From_Id = v_Fin_Inventory_Id
             And Nvl(Oss.Close_Flag, v_False) <> v_Close
             And Nvl(Oss.Share_Qty, 0) > Nvl(Oss.So_Order_Qty, 0)
             --And Nvl(oss.inv_share_flag, 'N') = 'N'
             ;
          --可释放数量=占用-已分配未下达
          v_Usable_Occupy_Qty := v_Pln_Occupy_Qty - v_Item_Share_Qty;

          If v_Usable_Occupy_Qty < 0 Then
            v_Usable_Occupy_Qty := 0;
          End If;
        Exception
          When No_Data_Found Then
            v_Usable_Occupy_Qty := 0;
          When Others Then
            p_Result := v_Value || '失败!' || '错误信息:' || p_Result ||
                        Sqlerrm;
            Raise v_Base_Exception;
        End;
      End If;

      If v_Item_Onhand_Qty -
         (v_Item_Occupy_Qty - Nvl(v_Usable_Occupy_Qty, 0)) < 0 Then
        v_Value := '中转单号:' || v_Po_Order_Number || ' 商品编码:' ||
                   v_Item_Code || '可红冲库存不足!';
        Raise v_Base_Exception;
      End If;
      --获取订单可红冲数量 ,并检查是否可红
      If f_Get_Ord_Usable_Red_Qty(v_Item_Id,
                                  v_Producing_Area_Id,
                                  p_Entity_Id,
                                  v_Order_Usable_Red_Qty) <> v_Success Then
        v_Value := '获取订单可红冲数量：';
        Raise v_Base_Exception;
      End If;
      If v_Order_Usable_Red_Qty <= 0 Then
        v_Value := '中转单号:' || v_Po_Order_Number || ' 商品编码:' ||
                   v_Item_Code;
        Raise v_Base_Exception;
      End If;
    Else
      --获取定制机占用数量
      If p_Result = v_Success And v_Pln_Wip_Order_Match = v_True Then
        v_Value := '新占用库存方式，获取定制机占用数量';
        Begin
          Select Nvl((Select Sum(Nvl(Io.Stock_Affirm_Qty, 0) +
                                Nvl(Io.Supply_Qty, 0) -
                                Nvl(Io.So_Order_Qty, 0) -
                                Nvl(Io.Sundry_Qty, 0)) Sum_Lock_Qty
                       From t_Pln_Order_Inv_Occupy Io
                      Where Io.Item_Id = v_Item_Id
                        And Io.Inventory_Id = v_Fin_Inventory_Id
                        And Io.Entity_Id = p_Entity_Id
                        And Io.Origin_Type = '订单与工单完全匹配'
                        And Io.Origin_Line_Id In
                            (Select d.Order_Line_Id
                               From t_Inv_Po_Lines_Detail d
                              Where d.Po_Line_Id = v_Old_Po_Line_Id
                                And d.Entity_Id = p_Entity_Id)),
                     0)
            Into v_Pln_Occupy_Qty
            From Dual;
        Exception
          When No_Data_Found Then
            v_Pln_Occupy_Qty := 0;
          When Others Then
            v_Value := v_Value || '失败!' || '错误信息:' || v_Nl || Sqlerrm;
            Raise v_Base_Exception;
        End;
        Begin
          v_Value := '获取定制机已下达未开单的数量';
          --计算套散件时，必需*套散件表的数量(含库存评审部份的已下达未开单数量)
          Select Nvl(Sum((Nvl(Oss.Carry_Qty, 0) - Nvl(Oss.So_Order_Qty, 0)) *
                     Nvl((Select Ias.Quantity
                           From t_Bd_Item_Assemblies     Bia,
                                t_Bd_Item_Assemblies_Sub Ias
                          Where Bia.Item_Assembly_Id =
                                Ias.Item_Assembly_Id
                            And Bia.Entity_Id = Ias.Entity_Id
                            And Trunc(Sysdate) Between Bia.Begin_Date And
                                Nvl(Bia.End_Date, Sysdate)
                            And Trunc(Sysdate) Between Ias.Begin_Date And
                                Nvl(Ias.End_Date, Trunc(Sysdate))
                            And Bia.Item_Id = Oss.Item_Id
                            And Ias.Item_id = v_Item_Id
                         Union All
                         --非套件产品
                         Select 1 Quantity
                           From t_Bd_Item Tbi
                          Where Tbi.Item_Id = Oss.Item_Id
                            And Not Exists
                          (Select 1
                                   From t_Bd_Item_Assemblies Bia
                                  Where Bia.Item_Id = Tbi.Item_Id
                                    And Bia.Item_Id = Oss.Item_Id
                                    And Trunc(Sysdate) Between
                                        Bia.Begin_Date And
                                        Nvl(Bia.End_Date, Sysdate))),
                         1)),
                     0)
            Into v_Item_Share_Qty
          --可用分配数量 ＝ 已下达数量 － 已开单数量
            From t_Pln_Order_Share_Shipment Oss
           Where Oss.Entity_Id = p_Entity_Id
             And Oss.Inventory_From_Id = v_Fin_Inventory_Id
             And Nvl(Oss.Close_Flag, v_False) <> v_Close
             And Nvl(Oss.Carry_Qty, 0) > Nvl(Oss.So_Order_Qty, 0)
             And Oss.Origin_Line_Id In
                 (Select d.Order_Line_Id
                    From t_Inv_Po_Lines_Detail d
                   Where d.Po_Line_Id = v_Old_Po_Line_Id
                     And d.Entity_Id = p_Entity_Id)
             ;

          --add by lizhen 2015-04-07获取中转入库红冲单已发货确认未执行数量
          Begin
            Select Sum(Decode(o.Po_Status,
                              10,
                              Nvl(Ipld.Billed_Qty, 0),
                              Nvl(Ipld.Shipped_Qty, 0)))
              Into v_Read_Po_Wip_Qty
              From t_Inv_Po_Headers        o,
                   t_Inv_Po_Lines          l,
                   t_Inv_Po_Lines_Detail   Ipld,
                   t_Inv_Bill_Types        t,
                   t_Inv_Inventories       i,
                   t_Inv_Bill_Types        Ibt,
                   t_Inv_Transaction_Types Itt
             Where t.Bill_Type_Id = o.Po_Type_Id
               And t.Entity_Id = o.Entity_Id
               And o.po_id = Ipld.Po_Head_Id
               And l.po_line_id = Ipld.Po_Line_Id
               And l.Po_Id = o.Po_Id
               And i.Inventory_Id = o.Inv_Finance_Id
               And i.Entity_Id = o.Entity_Id
               And Trunc(o.Billed_Date) >= Trunc(Sysdate - 60)
               And Nvl(o.Source_Type, '_') = '工单入库'
               And Nvl(o.Close_Flag, 'N') != 'Y' --已关闭的不算红冲
               And o.Po_Status = '21' --发货确认
               And l.po_id != v_Po_Head_Id --当前单据不计算
               And o.Entity_Id = p_Entity_Id
               And i.Inventory_Id = v_Fin_Inventory_Id
               And l.Item_Id = v_Item_Id
               And Ipld.Order_Line_Id In
             (Select Pld.Order_Line_Id
                      From t_Inv_Po_Headers      Iph,
                           t_Inv_Po_Lines        Ipl,
                           t_Inv_Po_Lines_Detail Pld
                     Where Iph.Po_Id = Ipl.Po_Id
                       And Ipl.Po_Line_Id = Pld.Po_Line_Id
                       And Ipl.Po_Line_Id = v_Old_Po_Line_Id)
                  --采购单红冲出库的单据才纳入现有量计算
               And Ibt.Transaction_Type_Id = Itt.Transaction_Type_Id
               And Itt.Action_Type = '02'
               And Ibt.Bill_Type_Id = o.Po_Type_Id
             Group By l.Item_Id;
          Exception
            When No_Data_Found Then
              v_Read_Po_Wip_Qty := 0;
            When Others Then
              v_Value := v_Value || '失败!' || '获取中转入库红冲单已发货确认未执行数量:' || v_Nl ||
                         Sqlerrm;
              Raise v_Base_Exception;
          End;

          --获取库存评审的已分配未下达数量    计算套散件时，必需*套散件表的数量
          Select Nvl(Sum((Nvl(Oss.Share_Qty, 0) - Nvl(Oss.Carry_Qty, 0)) *
                     Nvl((Select Ias.Quantity
                           From t_Bd_Item_Assemblies     Bia,
                                t_Bd_Item_Assemblies_Sub Ias
                          Where Bia.Item_Assembly_Id = Ias.Item_Assembly_Id
                            And Bia.Entity_Id = Ias.Entity_Id
                            And Trunc(Sysdate) Between Bia.Begin_Date And
                                Nvl(Bia.End_Date, Sysdate)
                            And Trunc(Sysdate) Between Ias.Begin_Date And
                                Nvl(Ias.End_Date, Trunc(Sysdate))
                               --And Nvl(Ias.Fittings_Flag, v_False) = v_False
                            And Bia.Item_Id = Oss.Item_Id
                            And Ias.Item_id = v_Item_Id
                         Union All
                         --非套件产品
                         Select 1 Quantity
                           From t_Bd_Item Tbi
                          Where Tbi.Item_Id = Oss.Item_Id
                            And Not Exists
                          (Select 1
                                   From t_Bd_Item_Assemblies Bia
                                  Where Bia.Item_Id = Tbi.Item_Id
                                    And Bia.Item_Id = Oss.Item_Id
                                    And Trunc(Sysdate) Between
                                        Bia.Begin_Date And
                                        Nvl(Bia.End_Date, Sysdate))),
                         1)),
                     0)
            Into v_Inv_No_Carry_Order_Qty
          --库存评审的已分配未开单数量 ＝ 已分配数量 － 已下达未分配(已下达未开单数量在上一SQL已取数)
            From t_Pln_Order_Share_Shipment Oss
           Where Oss.Entity_Id = p_Entity_Id
             And Oss.Inventory_From_Id = v_Fin_Inventory_Id
             And Nvl(Oss.Close_Flag, v_False) <> v_Close
             And Nvl(Oss.Share_Qty, 0) > Nvl(Oss.So_Order_Qty, 0)
             And Oss.Origin_Line_Id In
                 (Select d.Order_Line_Id
                    From t_Inv_Po_Lines_Detail d
                   Where d.Po_Line_Id = v_Old_Po_Line_Id
                     And d.Entity_Id = p_Entity_Id)
             And Nvl(oss.inv_share_flag, 'N') = 'Y'
             ;

          --可冲占用=占用-已分配未开单
          --工单与订单新匹配模式下，不检查已分配数量，放到P_WIP_TO_ORDER_SHARE
          --库存评审的分配数量不参与工单中转的红冲
          --过程处理，该过程实现自动生成分配行及红冲时自动取消分配
          --已下达未开单的数量，不允许红冲，除非手工取消回下达数量
          --modi by lizhen 2015-04-07
          --库存占用可红冲数量 = 产品库存占用量 - 已下达未开单数量 - 库存评审已分配未下达数量（已下达未开单数量已算入“已下达未开单数量”）
          --             - 中转红冲已发货未执行数量
          v_Usable_Occupy_Qty := v_Pln_Occupy_Qty - nvl(v_Item_Share_Qty, 0) - nvl(v_Inv_No_Carry_Order_Qty, 0)
                                 - Nvl(v_Read_Po_Wip_Qty, 0);

          If v_Usable_Occupy_Qty < 0 Then
            v_Usable_Occupy_Qty := 0;
          End If;
        Exception
          When No_Data_Found Then
            v_Usable_Occupy_Qty := 0;
          When Others Then
            v_Value := v_Value || '失败!' || '错误信息:' || v_Nl || Sqlerrm;
            Raise v_Base_Exception;
        End;
      End If;

      --ADD BY LIZHEN 检查中转入库单，不需库存占用的数量
      Select Sum(Nvl(Ld.Executed_Qty, 0))
        Into v_Not_Inv_Lock_Qty
        From t_Pln_Order_Head      Oh,
             t_Inv_Po_Lines_Detail Ld,
             t_Pln_Order_Type      Ot
       Where Oh.Order_Head_Id = Ld.Order_Header_Id
         And Oh.Order_Type_Id = Ot.Order_Type_Id
         And Ot.Is_Lock_Inv_Flag = v_False
         And Ld.Po_Line_Id = v_Old_Po_Line_Id;

      If f_Get_Ord_Usable_Red_Qty(v_Item_Id,
                                  v_Producing_Area_Id,
                                  p_Entity_Id,
                                  v_Order_Usable_Red_Qty,
                                  v_Old_Po_Line_Id, --中转单被红冲行ID，用于查找订单行ID
                                  v_Pln_Wip_Order_Match) <> v_Success Then
        v_Value := '获取订单可取消红冲数量：';
        Raise v_Base_Exception;
      End If;
      If p_Result = v_Success And v_Pln_Wip_Order_Match = v_True Then
        If v_Order_Usable_Red_Qty >= Abs(p_Tran_Quantity) Then
          v_Order_Usable_Red_Qty := Abs(p_Tran_Quantity);
          --为保证无占用用库存的订单可正常匹配，把条件改成 订单占用用数量 + 非库存占用中转入库数量 - 本次需红冲数量  < 0
          --MODI BY LIZHEN 2015-01-11
          --If Nvl(v_Order_Usable_Red_Qty, 0) > v_Pln_Occupy_Qty Then
          --可释放占用数量
          --If Nvl(v_Pln_Occupy_Qty, 0) + Nvl(v_Not_Inv_Lock_Qty, 0) - Nvl(v_Order_Usable_Red_Qty, 0) < 0 Then
          If Nvl(v_Usable_Occupy_Qty, 0) + Nvl(v_Not_Inv_Lock_Qty, 0) < Nvl(v_Order_Usable_Red_Qty, 0) Then
            v_Value := '定制机中转红冲数量(' || To_Char(Nvl(v_Order_Usable_Red_Qty, 0)) ||
                       ')大于对应订单库存占用可红冲数量(' || To_Char(Nvl(v_Usable_Occupy_Qty, 0) +
                       Nvl(v_Not_Inv_Lock_Qty, 0)) || ')，红冲失败！' || v_Nl ||
                       '库存占用可红冲数量 = 产品库存占用量 - 已下达未开单数量 - 库存评审已分配未下达数量 - 中转红冲已发货未执行数量 ' || v_Nl ||
                       '库存占用数量：' || To_Char(v_Pln_Occupy_Qty) || v_Nl ||
                       '已下达未开单数量：' || To_Char(Nvl(v_Item_Share_Qty, 0)) || v_Nl ||
                       '库存评审已分配未下达数量：' || To_Char(Nvl(v_Inv_No_Carry_Order_Qty, 0)) || v_Nl ||
                       '中转入库红冲已确认未执行数量：' || To_Char(Nvl(v_Read_Po_Wip_Qty, 0)) || v_Nl ||
                       '请找物流相关人员去红冲相应订单的财务单，释放订单锁单库存，' ||
                       ' 在蓝单的单据行明细可以查询匹配的订单，然后再红冲中转单。';
            Raise v_Base_Exception;
          End If;
        Else
          v_Value := '订单可匹配红冲数量（' || To_Char(v_Order_Usable_Red_Qty) || '）小于本次中转单行红冲数量（'
                  || To_Char(p_Tran_Quantity) || '），中转红冲单匹配订单失败!';
          Raise v_Base_Exception;
        End If;
      End If;
      --库存可用量 + 库存占用可红冲数量 < 本次红冲数量
      If v_Usable_Qoh_Qty + Nvl(v_Usable_Occupy_Qty, 0) < Abs(p_Tran_Quantity) Then
        v_Value := '中转单号:' || v_Po_Order_Number || ' 商品编码:' ||
                   v_Item_Code || '可红冲库存不足!';
        Raise v_Base_Exception;
      End If;
    End If;

    v_Curr_Wip_Red_Qty    := 0;
    v_Order_Red_Match_Qty := 0;
    --开始红冲工单入库信息,循环原采购中转明细行
    If p_Result = v_Success Then
      v_Value := '循环原采购中转明细行';
      For r_Wip_Red In (Select d.Wip_Entity_Id,
                               d.Wip_Entity_Code,
                               Decode(v_Pln_Wip_Order_Match,
                                      v_True,
                                      d.Order_Header_Id,
                                      Null) Order_Head_Id,
                               Decode(v_Pln_Wip_Order_Match,
                                      v_True,
                                      d.Order_Number,
                                      Null) Order_Number,
                               Decode(v_Pln_Wip_Order_Match,
                                      v_True,
                                      d.Order_Line_Id,
                                      Null) Order_Line_Id,
                               Decode(v_Pln_Wip_Order_Match,
                                      v_True,
                                      d.Order_Detail_Id,
                                      Null) Order_Detail_Id,
                               Sum(Nvl(d.Executed_Qty, 0) -
                                   Nvl(d.Canceled_Qty, 0)) Order_Quantity,
                               d.Item_Barcode
                          From t_Inv_Po_Lines_Detail d
                         Where d.Po_Line_Id = v_Old_Po_Line_Id
                           And d.Entity_Id = p_Entity_Id
                           And Nvl(d.Executed_Qty, 0) -
                               Nvl(d.Canceled_Qty, 0) > 0 --未红冲完毕
                         Group By d.Wip_Entity_Id,
                                  d.Wip_Entity_Code,
                                  Decode(v_Pln_Wip_Order_Match,
                                         v_True,
                                         d.Order_Header_Id,
                                         Null),
                                  Decode(v_Pln_Wip_Order_Match,
                                         v_True,
                                         d.Order_Number,
                                         Null),
                                  Decode(v_Pln_Wip_Order_Match,
                                         v_True,
                                         d.Order_Line_Id,
                                         Null),
                                  Decode(v_Pln_Wip_Order_Match,
                                         v_True,
                                         d.Order_Detail_Id,
                                         Null),
                                  d.Item_Barcode
                         Order By Order_Quantity) Loop
        --获取本次红冲的数量
        v_Curr_Wip_Red_Qty := Least(Abs(v_Tran_Quantity), r_Wip_Red.Order_Quantity);
        --商品,产地
        If p_Result = v_Success Then
          v_Value := '获取工单:' || r_Wip_Red.Wip_Entity_Code || '商品,产地信息';
          Begin
            Select a.Producing_Area_Id,
                   Nvl(Wii.Exec_Qty, 0),
                   Wii.Organization_Id
              Into v_Producing_Area_Id,
                   v_Wip_Execute_Qty,
                   v_Organization_Id
              From t_Inv_Wip_In_Info Wii, t_Pln_Producing_Area a
             Where Wii.Wip_Entity_Id = r_Wip_Red.Wip_Entity_Id
               And a.Mrp_Org_Id = Wii.Organization_Id
               And a.Entity_Id = p_Entity_Id;
          Exception
            When Others Then
              v_Value := v_Value || '失败!' || v_Nl || Sqlerrm;
              Raise v_Base_Exception;
          End;
        End If;

        --工单需要有已入库数量 --此工单入库数量为0则跳到下一个工单进行红冲
        --Exit When v_Wip_Execute_Qty <= 0;

        If p_Result = v_Success And v_Wip_Execute_Qty > 0 Then
          --工单红冲数量
          --游标循环分别红冲订单明细行
          --增加仓库，获取占用数量
          For r_Red_Order In c_Order_Red(v_Item_Id,
                                         v_Producing_Area_Id,
                                         v_Supply_Seq,
                                         'N',
                                         r_Wip_Red.Order_Detail_Id,
                                         v_Fin_Inventory_Id) Loop
            --取   工单可红冲数量
            v_Order_Red_Match_Qty := Least(v_Curr_Wip_Red_Qty,
                                           r_Red_Order.Can_Red_Qty - r_Red_Order.Carry_No_So_Order_Qty);
            Exit When v_Order_Red_Match_Qty = 0;
            --插入匹配历史
            If p_Result = v_Success Then
              v_Value := '插入红冲中转单明细表,计划订单号:' || r_Red_Order.Order_Number ||
                         '  工单号:' || r_Wip_Red.Wip_Entity_Code;
              Insert Into t_Inv_Po_Lines_Detail
                (Po_Detail_Id, --采购单行明细id
                 Entity_Id, --经营主体id
                 Po_Head_Id, --采购单头id
                 Po_Line_Id, --采购单行id
                 Order_Header_Id, --订单头id
                 Order_Number, --订单编号
                 Order_Line_Id, --订单行id
                 Order_Detail_Id, --订单明细行id
                 Wip_Entity_Id, --工单编码
                 Wip_Entity_Code, --工单名称
                 Item_Id, --
                 Item_Code, --产品编码，即销售码
                 Item_Name, --产品名称
                 Uom_Code, --产品单位
                 Item_Barcode, --产品条码
                 Item_Suite_Id, --
                 Item_Suite_Code, --套件编码
                 Item_Suite_Name, --套件名称
                 Customer_Id, --客户id
                 Customer_Code, --客户编码
                 Customer_Name, --客户名称
                 Billed_Qty, --单据数量
                 Shipped_Qty, --发货数量，发货数量与开单数量会不一样。
                 Received_Qty, --接收数量，安得回写的实际收货数量。
                 Executed_Flag, --执行标志
                 Executed_Date, --执行日期
                 Executed_Qty, --执行数量
                 Canceled_Qty, --红冲数量
                 Created_By, --创建者
                 Creation_Date, --创建日期
                 Last_Updated_By, --更新者
                 Last_Update_Date, --更新日期
                 Remark, --备注
                 Organization_Id, --组织id
                 Aps_Wip_Intf_Flag, --已引aps工单入库接口标志
                 Aps_Wip_Intf_By, --引入aps工单入库接口用户
                 Aps_Wip_Intf_Date --引入APS工单入库接口日期
                 )
              Values
                (s_Inv_Po_Lines_Detail.Nextval, --采购单行明细id
                 p_Entity_Id, --经营主体id
                 v_Po_Head_Id, --采购单头id
                 p_Po_Line_Id, --采购单行id
                 r_Red_Order.Order_Head_Id, --订单头id
                 r_Red_Order.Order_Number, --订单编号
                 r_Red_Order.Order_Line_Id, --订单行id
                 r_Red_Order.Order_Detail_Id, --订单明细行id
                 r_Wip_Red.Wip_Entity_Id, --工单编码
                 r_Wip_Red.Wip_Entity_Code, --工单名称
                 r_Red_Order.Item_Id, --
                 r_Red_Order.Item_Code, --产品编码，即销售码
                 r_Red_Order.Item_Name, --产品名称
                 v_Item_Uom_Code, --产品单位
                 r_Wip_Red.Item_Barcode, --产品条码
                 r_Red_Order.Ass_Item_Id, --
                 r_Red_Order.Ass_Item_Code, --套件编码
                 r_Red_Order.Ass_Item_Name, --套件名称
                 r_Red_Order.Customer_Id, --客户id
                 r_Red_Order.Customer_Code, --客户编码
                 r_Red_Order.Customer_Name, --客户名称
                 v_Order_Red_Match_Qty, --billed_qty,  --单据数量
                 v_Order_Red_Match_Qty, --shipped_qty,  --发货数量，发货数量与开单数量会不一样。
                 0, --received_qty,  --接收数量，安得回写的实际收货数量。
                 'N', --执行标志
                 Null, --Executed_Date, --执行日期
                 0, -- executed_qty,  --执行数量
                 0, --canceled_qty,  --红冲数量
                 p_User_Code, --创建者
                 Sysdate, --创建日期
                 p_User_Code, --更新者
                 Sysdate, --更新日期
                 Null, --remark,  --备注
                 v_Organization_Id, --组织id
                 'N', --aps_wip_intf_flag,  --已引aps工单入库接口标志
                 Null, --aps_wip_intf_by,  --引入aps工单入库接口用户
                 Null --aps_wip_intf_date
                 );
            End If;
            --1、回写计划订单明细行入库数量
            --提前,正常,延迟.入库数量  从后往前面红冲
            If p_Result = v_Success Then
              v_Value := '更新计划订单明细行入库数量,计划订单号:' ||
                         r_Red_Order.Order_Number || '  工单号:' ||
                         r_Wip_Red.Wip_Entity_Code;
              Update t_Pln_Order_Detail Pod
              --入库数量
                 Set Pod.Supply_Qty = Nvl(Pod.Supply_Qty, 0) -
                                      Nvl(v_Order_Red_Match_Qty, 0),
                     --更新CLOSE_FLAG
                     Pod.Close_Flag = v_False
               Where Pod.Entity_Id = p_Entity_Id
                 And Pod.Order_Detail_Id = r_Red_Order.Order_Detail_Id
                 And Pod.Order_Head_Id = r_Red_Order.Order_Head_Id
                 And Pod.Order_Line_Id = r_Red_Order.Order_Line_Id;
            End If;
            --跟新订单行
            --判断当前套机行的商品是否套机
            If p_Result = v_Success Then
              v_Value := '更新计划订单行入库数量,计划订单号:' || r_Red_Order.Order_Number ||
                         '  工单号:' || r_Wip_Red.Wip_Entity_Code;
              Select Count(*)
                Into v_Count
                From t_Bd_Item_Assemblies Bia,
                     --套件行表
                     t_Bd_Item_Assemblies_Sub Ias,
                     --套件头表
                     t_Pln_Order_Line Pol
               Where Bia.Item_Assembly_Id = Ias.Item_Assembly_Id
                 And Bia.Entity_Id = Ias.Entity_Id
                 And Bia.Entity_Id = p_Entity_Id
                 And Bia.Item_Id = Pol.Item_Id
                 And Pol.Entity_Id = Bia.Entity_Id
                 And Pol.Order_Line_Id = r_Red_Order.Order_Line_Id
                 And Trunc(Sysdate) Between Ias.Begin_Date And
                     Trunc(Nvl(Ias.End_Date, Sysdate))
                 And Trunc(Sysdate) Between Bia.Begin_Date And
                     Trunc(Nvl(Bia.End_Date, Sysdate));
              --套机
              If v_Count > 0 Then
                Select Min(Sum(Nvl(Pod.Supply_Qty, 0)) /
                           Decode(Ias.Quantity,
                                  Null,
                                  1,
                                  0,
                                  1,
                                  Ias.Quantity))
                  Into v_Pln_Detail_Supply_Qty --入库数量
                  From t_Pln_Order_Detail Pod,
                       --计划周订单明细表
                       t_Bd_Item_Assemblies Bia,
                       --套件行表
                       t_Bd_Item_Assemblies_Sub Ias --套件头表
                 Where Pod.Item_Id = Ias.Item_Id
                   And Bia.Item_Assembly_Id = Ias.Item_Assembly_Id
                   And Bia.Entity_Id = Ias.Entity_Id
                   And Bia.Entity_Id = p_Entity_Id
                   And Bia.Item_Id = r_Red_Order.Ass_Item_Id
                   And Pod.Order_Line_Id = r_Red_Order.Order_Line_Id
                   And Trunc(Sysdate) Between Ias.Begin_Date And
                       Nvl(Ias.End_Date, Sysdate)
                   And Trunc(Sysdate) Between Bia.Begin_Date And
                       Nvl(Bia.End_Date, Sysdate)
                 Group By Pod.Item_Id, Ias.Quantity; --按散件行商品和配套行数量来汇总(不能缺少)
              Else
                Select Sum(Nvl(Pod.Supply_Qty, 0))
                  Into v_Pln_Detail_Supply_Qty --入库数量
                  From t_Pln_Order_Detail Pod --计划订单明细表
                 Where Pod.Entity_Id = p_Entity_Id
                   And Pod.Order_Line_Id = r_Red_Order.Order_Line_Id
                   And Pod.Order_Head_Id = r_Red_Order.Order_Head_Id;
              End If;

              --回写计划订单行数量
              Update t_Pln_Order_Line Pol --计划周订单行表
                 Set Pol.Supply_Qty = v_Pln_Detail_Supply_Qty --入库数量
               Where Pol.Entity_Id = p_Entity_Id
                 And Pol.Order_Head_Id = r_Red_Order.Order_Head_Id
                 And Pol.Order_Line_Id = r_Red_Order.Order_Line_Id;

            End If;

            --跟新工单入库数量
            Begin
              If p_Result = v_Success Then
                v_Value := '更新工单入库数量 , 工单号:' || r_Wip_Red.Wip_Entity_Code;
                Update t_Inv_Wip_In_Info Wii
                   Set Wii.Exec_Qty         = Nvl(Wii.Exec_Qty, 0) -
                                              v_Order_Red_Match_Qty,
                       Wii.Last_Update_Date = Sysdate
                 Where Wii.Wip_Entity_Id = r_Wip_Red.Wip_Entity_Id
                 Returning Wii.Exec_Qty Into v_Check_Qty;

                Update t_Inv_Wip_In_Info Wii
                   Set Wii.End_Flag = Decode(Sign(Wii.Produce_Qty -
                                                  Nvl(Wii.Exec_Qty, 0)),
                                             0,
                                             'Y',
                                             'N')
                 Where Wii.Wip_Entity_Id = r_Wip_Red.Wip_Entity_Id;
              End If;
            Exception
              When Others Then
                v_Value := v_Value || '失败!' || Sqlerrm;
                Raise v_Base_Exception;
            End;
            If Nvl(v_Check_Qty, 0) < 0 Then
              v_Value := '更新工单入库数量后异常，工单已入库数量：' || To_Char(v_Check_Qty)
                || v_Nl || '工单编码：' || r_Wip_Red.Wip_Entity_Code;
              Raise v_Base_Exception;
            End If;
            --更新工单与订单匹配入关系入库信息
            Update t_Pln_Wip_Order_Relation Wor
               Set Wor.In_Inv_Qty       = Nvl(Wor.In_Inv_Qty, 0) -
                                          v_Order_Red_Match_Qty,
                   Wor.Last_Update_Date = Sysdate
             Where Wor.Entity_Id = p_Entity_Id
               And Wor.Wip_Entity_Id = r_Wip_Red.Wip_Entity_Id
               And Wor.Order_Detail_Id = r_Red_Order.Order_Detail_Id
               And Wor.Order_Line_Id = r_Red_Order.Order_Line_Id
               And Wor.Order_Head_Id = r_Red_Order.Order_Head_Id;

            --回写原单据明细行红冲数量(蓝单红冲数量)
            Update t_Inv_Po_Lines_Detail Pld
               Set Pld.Canceled_Qty = Nvl(Pld.Canceled_Qty, 0) +
                                      v_Order_Red_Match_Qty
             Where Pld.Entity_Id = p_Entity_Id
               And Pld.Po_Line_Id = v_Old_Po_Line_Id
               And Pld.Wip_Entity_Id = r_Wip_Red.Wip_Entity_Id
               And ((Pld.Order_Detail_Id = r_Red_Order.Order_Detail_Id And
                   Pld.Order_Line_Id = r_Red_Order.Order_Line_Id And
                   Pld.Order_Header_Id = r_Red_Order.Order_Head_Id And
                   v_Pln_Wip_Order_Match = v_True) Or
                   v_Pln_Wip_Order_Match = v_False);
            If Sql%Notfound Then
              v_Value := '中转单红冲失败，更新中转单蓝单明细行失败，工单单号：' ||
                          r_Wip_Red.Wip_Entity_Code || '，中转单蓝单行ID：' ||
                          To_Char(v_Old_Po_Line_Id) || '，订单明细行ID：' ||
                          To_Char(r_Wip_Red.Order_Detail_Id) || v_Nl || Sqlerrm;
              Raise v_Base_Exception;
            End If;
            --更新工单与订单中转入库关系表，只处理ERP手工单匹配
            v_Curr_Wip_Red_Qty := v_Curr_Wip_Red_Qty -
                                  v_Order_Red_Match_Qty;
            v_Tran_Quantity := v_Tran_Quantity - v_Order_Red_Match_Qty;
            Exit When v_Curr_Wip_Red_Qty = 0 Or v_Tran_Quantity = 0;
          End Loop; --红冲订单循环结束
        End If;
        Exit When v_Tran_Quantity = 0;
      End Loop; --原工单明细循环结束
      --红冲中转单时，一行中转蓝单明细行红冲时存在剩余数量，则报异常
      If v_Curr_Wip_Red_Qty <> 0 Then
        v_Value := '中转单红冲失败，剩余【' || To_Char(v_Curr_Wip_Red_Qty) ||
                 '】数量无法正常匹配到订单，中转单蓝单行ID：' || To_Char(v_Old_Po_Line_Id);
        Raise v_Base_Exception;
      End If;
    End If;
    If p_Result <> v_Success Then
      Rollback;
    End If;
  Exception
    When v_Base_Exception Then
      Rollback;
      p_Result := v_Value || v_Nl || replace(p_Result, v_Success, '');
    When Others Then
      p_Result := v_Value || Sqlerrm;
      Rollback;
  End;


  --------------------------------------------------------------------------
  --Author: Nicro.li
  --Purpose:中转单执行，进行工单与订单匹配入库
  --------------------------------------------------------------------------
  Procedure p_Execute_Wip_Ord_Match(p_Po_Line_Id    In Number, --中转单行ID
                                    p_Tran_Quantity In Number, --事务数量带正负号
                                    p_Entity_Id     In Number, --主体ID
                                    p_User_Code     In Varchar2, --用户ID
                                    p_Result        Out Varchar2) Is
    v_Pln_Wip_Order_Match Varchar2(10); --工单与订单是否完全匹配
    --可入库订单明细行游标(非红冲单)
    Cursor c_Order(i_Item_Id           Number,
                   i_Producing_Area_Id Number,
                   i_Can_Supply_Date   Date,
                   i_Supply_Seq        Varchar2,
                   i_Month_Match       Varchar2,
                   i_Order_Detail_Id   Number, --增加传入明细行ID
                   i_Source_Type_Code  varchar2
                   ) Is
      Select h.Order_Number,
             h.Order_Head_Id,
             l.Order_Line_Id,
             d.Order_Detail_Id,
             h.Period_Id,
             h.Order_Type_Id,
             h.Form_State,
             h.Supply_Date,
             d.Item_Id,
             d.Item_Code,
             d.Item_Name,
             d.Item_Uom,
             l.Item_Id Ass_Item_Id,
             l.Item_Code Ass_Item_Code,
             l.Item_Desc Ass_Item_Name,
             l.Item_Price,
             d.Can_Produce_Qty Order_Qty,
             d.Supply_Qty,
             d.Can_Produce_Qty - Nvl(d.Supply_Qty, 0) -
             Nvl(d.Cancel_Qty, 0) -
             --20180509 hejy3 常规入库需扣减预约直发量
             decode(i_Source_Type_Code, '03', 0, (nvl(l.direct_transport_qty, 0) - nvl(l.cancel_direct_transport_qty, 0)-nvl(l.already_direct_transport_qty,0)))
             Can_Supply_Qty,
             h.Customer_Id,
             h.Customer_Code,
             h.Customer_Name,
             t.is_lock_inv_flag
        From t_Pln_Order_Detail d,
             t_Pln_Order_Head   h,
             t_Pln_Order_Line   l,
             t_Pln_Order_Type   t
       Where d.Order_Head_Id = h.Order_Head_Id
         And d.Entity_Id = h.Entity_Id
         And d.Order_Line_Id = l.Order_Line_Id
         And d.Order_Head_Id = h.Order_Head_Id
         And d.Producing_Area_Id = i_Producing_Area_Id
         And d.Entity_Id = p_Entity_Id
         And d.Can_Produce_Qty - Nvl(d.Supply_Qty, 0) -
             Nvl(d.Cancel_Qty, 0) > 0
         And d.Item_Id = i_Item_Id
         And Nvl(d.Close_Flag, v_False) = v_False
         And h.Order_Type_Id = t.Order_Type_Id
         And h.Entity_Id = t.Entity_Id
         And t.Match_Type_Storage = '按订单报送的时间先后顺序匹配'
         And h.Form_State In ('32', '306') --('已排产', '已完成')
         And t.Storage_Priority Is Not Null
            --控制终止入库日期+订单类型延迟入库天数
         --modi by lizhen 2016-01-11 检查入库日期使用 最后入库日期字段判段
         And Trunc(Nvl(l.can_supply_date, Sysdate) + Nvl(t.Defer_Supply_Days, 0)) >=
             Trunc(Sysdate)
         /*And (Nvl(l.End_Supply_Date, Sysdate) + Nvl(t.Defer_Supply_Days, 0) >=
             Sysdate)*/
            --修改为根据周期的开始日期和主体参数控制
         And Exists (Select 1
                From t_Pln_Order_Period p
               Where p.Period_Id = h.Period_Id
                 And p.Entity_Id = h.Entity_Id
                    --增加匹配当月订单控制
                 And p.Begin_Date <= i_Can_Supply_Date)
         And ((v_Pln_Wip_Order_Match = v_True And
             d.Order_Detail_Id = i_Order_Detail_Id) Or
             v_Pln_Wip_Order_Match = v_False)
       Order By Decode(i_Supply_Seq, '周期优先', h.Period_Id, 1),
                Decode(i_Supply_Seq, '定制订单优先', h.Period_Id, 1),
                t.Storage_Priority,
                h.Refer_Date,
                d.Can_Produce_Qty;

    r_Order c_Order%Rowtype;
    --红冲单据 可入库订单明细行游标
    Cursor c_Order_Red(i_Item_Id           Number,
                       i_Producing_Area_Id Number,
                       i_Supply_Seq        Varchar2,
                       i_Month_Match       Varchar2,
                       i_Order_Detail_Id   Number,
                       i_Inventory_Id      Number) Is
      Select h.Order_Number,
             h.Order_Head_Id,
             l.Order_Line_Id,
             d.Order_Detail_Id,
             h.Period_Id,
             h.Order_Type_Id,
             h.Form_State,
             h.Supply_Date,
             d.Item_Id,
             d.Item_Code,
             d.Item_Name,
             d.Item_Uom,
             l.Item_Id Ass_Item_Id,
             l.Item_Code Ass_Item_Code,
             l.Item_Desc Ass_Item_Name,
             l.Item_Price,
             d.Can_Produce_Qty Order_Qty,
             Nvl(d.Supply_Qty, 0) Can_Red_Qty,
             h.Customer_Id,
             h.Customer_Code,
             h.Customer_Name,
             t.is_lock_inv_flag
        From t_Pln_Order_Detail d,
             t_Pln_Order_Head   h,
             t_Pln_Order_Line   l,
             t_Pln_Order_Type   t
       Where d.Order_Head_Id = h.Order_Head_Id
         And d.Entity_Id = h.Entity_Id
         And d.Order_Line_Id = l.Order_Line_Id
         And d.Order_Head_Id = h.Order_Head_Id
         And d.Producing_Area_Id = i_Producing_Area_Id
         And d.Entity_Id = p_Entity_Id
         And d.Item_Id = i_Item_Id
         And Nvl(d.Supply_Qty, 0) > 0
         And h.Order_Type_Id = t.Order_Type_Id
         And h.Entity_Id = t.Entity_Id
         And h.Form_State In ('32', '306') --('已排产', '已完成')
         And t.Match_Type_Storage = '按订单报送的时间先后顺序匹配'
         And t.Storage_Priority Is Not Null
            --增加中转单红冲时，取消订单与工单配匹关系只取消系统日期当前月份的订单
         And ((v_Pln_Wip_Order_Match = v_False And Exists
              (Select 1
                  From t_Pln_Order_Period p
                 Where p.Period_Id = h.Period_Id
                   And p.Entity_Id = h.Entity_Id)) Or
             (v_Pln_Wip_Order_Match = v_True And
             d.Order_Detail_Id = i_Order_Detail_Id
             --必须散件存在占用库存量
             And (t.Is_Lock_Inv_Flag = v_True And
             Pkg_Pln_Inv_Occupy.f_Item_Ass_Occupy_Qty(i_Inventory_Id,
                                                        d.Item_Id,
                                                        v_Pln_Wip_Order_Match,
                                                        p_Entity_Id,
                                                        l.Order_Line_Id) > 0 Or
       t.Is_Lock_Inv_Flag = v_False)))
       Order By Decode(i_Supply_Seq, '周期优先', h.Period_Id, 1) Desc,
                Decode(i_Supply_Seq, '定制订单优先', h.Period_Id, 1) Desc,
                t.Storage_Priority Desc,
                h.Refer_Date Desc,
                Order_Qty Desc;
    r_Po_Line          t_Inv_Po_Lines%Rowtype;
    v_Value            Varchar2(2000);
    v_Changer_Period   Number; --定单制切换周期
    v_Count            Number; --计数
    v_Fin_Inventory_Id Number; --财务仓ID
    v_Order_Type_Name  Varchar2(100);

    v_Po_Head_Id          Number;
    v_Order_Status        Varchar2(10);
    v_Item_Id             Number;
    v_Item_Code           Varchar2(60);
    v_Item_Name           Varchar2(254);
    v_Item_Uom_Code       Varchar2(100);
    v_Po_Order_Number     Varchar2(100);
    v_Old_Po_Head_Id      Number;
    v_Red_Order_Flag      Varchar2(10);
    v_Old_Po_Number       Varchar2(60);
    v_Old_Po_Line_Id      Number;
    v_Is_Custom_Flag      Varchar2(2);
    v_Inv_Days            Number;
    v_Can_Supply_Date     Date;
    v_Supply_Seq          Varchar2(100);
    v_Producing_Area_Id   Number;
    v_Producing_Area_Name Varchar2(100);

    v_Can_Supply_Qty  Number; --订单可入库数量
    v_Fcan_Supply_Qty Number;
    v_Po_Executed_Qty Number;

    v_Wip_Entity_Id         Number;
    v_Wip_Can_Supply_Qty    Number;
    v_Curr_Wip_Supply_Qty   Number := 0;
    v_Order_Match_Qty       Number := 0;
    v_Pln_Detail_Supply_Qty Number := 0;
    v_Err_Num               Number;

    v_Organization_Id         Number;
    v_Item_Onhand_Qty         Number := 0; --库存现有量
    v_Item_Occupy_Qty         Number := 0; --产品总占用量
    v_Inv_No_Carry_Order_Qty  Number := 0; --库存评审已分配未下达数量
    v_Pln_Occupy_Qty          Number := 0; --定制机占用量
    v_Item_Share_Qty          Number := 0; --已分配未下达数量
    v_Usable_Occupy_Qty       Number := 0; --可释放占用数量
    v_Order_Usable_Red_Qty    Number := 0; --订单可红冲数量
    v_Curr_Wip_Red_Qty        Number := 0;
    v_Order_Red_Match_Qty     Number := 0;
    v_Wip_Execute_Qty         Number := 0; --工单已入库数量
    v_Tran_Quantity           Number := 0; --
    v_Not_Inv_Lock_Qty        Number := 0; --非库存占用的中转入库单数量
    v_Is_Lock_Inv_Flag        Varchar2(10);
    v_Source_Type_Code t_inv_po_headers.source_type_code%type;
  Begin
    p_Result := v_Success;
    v_Tran_Quantity := p_Tran_Quantity;
    --获取工单与订单是否完全匹配参数
    v_Pln_Wip_Order_Match := Pkg_Bd.f_Get_Parameter_Value('PLN_WIP_ORD_MATCH',
                                                            p_Entity_Id);
    Begin
      --中转单头ID,商品
      v_Value := '获取中转单头ID,商品ID';
      Select *
        Into r_Po_Line
        From t_Inv_Po_Lines Ipl
       Where Ipl.Po_Line_Id = p_Po_Line_Id;

      v_Po_Head_Id    := r_Po_Line.Po_Id;
      v_Item_Id       := r_Po_Line.Item_Id;
      v_Item_Code     := r_Po_Line.Item_Code;
      v_Item_Name     := r_Po_Line.Item_Name;
      v_Item_Uom_Code := r_Po_Line.Uom_Code;

      --中转单号
      v_Value := '获取中转单号';
      Select o.Po_Num, o.Inv_Finance_Id, t.Bill_Type_Name, o.Po_Status, o.source_type_code
        Into v_Po_Order_Number, v_Fin_Inventory_Id, v_Order_Type_Name, v_Order_Status, v_Source_Type_Code
        From t_Inv_Po_Headers o, t_Inv_Bill_Types t
       Where o.Po_Id = v_Po_Head_Id
         And o.Entity_Id = p_Entity_Id
         And t.Bill_Type_Id = o.Po_Type_Id;

      --获取财务仓仓库ID --
      v_Value := '判断发货仓库是否总部基地仓库';
      --判断发货仓库是否总部基地仓库；如果是总部基地仓库，才继续操作。
      Select Count(*)
        Into v_Count
        From t_Inv_Inventories Ii
       Where Ii.Entity_Id = p_Entity_Id
         And Ii.Inventory_Id = v_Fin_Inventory_Id
         And Trunc(Sysdate) Between Ii.Begin_Date And
             Nvl(Ii.End_Date, Sysdate + 1)
         And Ii.Base_Flag = v_True;
      If v_Count = 0 Then
        Raise v_Base_Exception; --不执行采购中转库存事务，直接退出。
      End If;

      --判断是否红冲单据
      v_Value := '判断中转单:' || v_Po_Order_Number || '是否红冲单据 ';
      Select Iph.Old_Po_Id
        Into v_Old_Po_Head_Id
        From t_Inv_Po_Headers Iph
       Where Iph.Po_Id = v_Po_Head_Id
         And Iph.Entity_Id = p_Entity_Id;
      --如果原单号不为空，则表示当前采购单据是红冲单；否则是蓝单。
      If v_Old_Po_Head_Id Is Not Null Then
        v_Red_Order_Flag := v_True; --当前采购是否红冲单
        v_Value          := '查找原单是否待检,单号：' || v_Old_Po_Head_Id;
        Select Iph.Po_Num
          Into v_Old_Po_Number
          From t_Inv_Po_Headers Iph
         Where Iph.Po_Id = v_Old_Po_Head_Id;
      Else
        v_Red_Order_Flag := v_False; --当前采购是否红冲单
      End If;

      --判断是否定制机 ,
      v_Value := '判断商品:' || v_Item_Code || '是否定制机 ';
      --只要对应套件其中有一个是定制机,则认为是定制机
      Select Count(1)
        Into v_Count
        From (Select 1
                From t_Pln_Item_Dyn_Attribute Ida
               Where Ida.Item_Id = v_Item_Id
                 And Ida.Entity_Id = p_Entity_Id
                 And Trunc(Sysdate) Between Ida.Begin_Date And
                     Trunc(Nvl(Ida.End_Date, Sysdate))
                 And Ida.Item_Dynamic_Attribute = '定制机型'
              Union All
              Select 1
                From t_Pln_Item_Dyn_Attribute Ida,
                     t_Bd_Item_Assemblies     Bia,
                     t_Bd_Item_Assemblies_Sub Ias
               Where Ida.Item_Id = Bia.Item_Id
                 And Ida.Entity_Id = Bia.Entity_Id
                 And Bia.Item_Assembly_Id = Ias.Item_Assembly_Id
                 And Ias.Entity_Id = Ida.Entity_Id
                 And Trunc(Sysdate) Between Ida.Begin_Date And
                     Trunc(Nvl(Ida.End_Date, Sysdate))
                 And Ida.Entity_Id = p_Entity_Id
                 And Ias.Item_Id = v_Item_Id
                 And Ida.Item_Dynamic_Attribute = '定制机型');

      If v_Count > 0 Then
        v_Is_Custom_Flag := v_True;
      Else
        v_Is_Custom_Flag := v_False;
      End If;

      --订单可入库时间(相对周期开始日期的天数)
      v_Value           := '获取[订单可入库时间]主体参数';
      v_Inv_Days        := -to_Number(Nvl(Pkg_Bd.F_Get_Parameter_Value('ORDER_ADVANCE_SUPPLY_DAYS',
                                                                         p_Entity_Id),
                                          '0'));
      v_Can_Supply_Date := Trunc(Sysdate + v_Inv_Days);

      --获取订单入库顺序参数
      v_Supply_Seq := Pkg_Bd.F_Get_Parameter_Value('SUPPLY_IN_PROPER_ORDER',
                                                     p_Entity_Id);
    Exception
      When Others Then
        v_Value := '步骤:' || v_Value || '失败!系统信息:' || Sqlerrm;
        Raise v_Base_Exception;
    End;

    --工单入库(非红冲单据)
    If (v_Red_Order_Flag = v_False And p_Result = v_Success) Then
      Begin
        --获取产地
        Select Pa.Producing_Area_Id, Pa.Producing_Area_Name
          Into v_Producing_Area_Id, v_Producing_Area_Name
          From t_Inv_Po_Wip_Detail Wd, t_Pln_Producing_Area Pa
         Where Wd.Organization_Id = Pa.Mrp_Org_Id
           And Wd.Po_Head_Id = v_Po_Head_Id
           And Wd.Po_Line_Id = p_Po_Line_Id
           And Wd.Item_Id = v_Item_Id
           And Pa.Entity_Id = p_Entity_Id
           And Rownum = 1;
      Exception
        When Others Then
          v_Value := '获取产地失败。' || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
      End;

      If p_Result = v_Success Then
        Begin
          --获取订单可入库时间内的可入库数量
          v_Can_Supply_Qty := f_Get_Order_Supply_Qty_m(v_Item_Id,
                                                       v_Can_Supply_Date,
                                                       v_Producing_Area_Id,
                                                       p_Entity_Id,
                                                       p_Po_Line_Id,
                                                       v_Pln_Wip_Order_Match);
        Exception
          When Others Then
            v_Value := '获取订单可入库时间内的可入库数量失败!';
            Raise v_Base_Exception;
        End;
      End If;

      If p_Result = v_Success Then
        Begin
          --获取订单可入库时间外的可入库数量失败
          Select Nvl(Sum(d.Can_Produce_Qty - Nvl(d.Supply_Qty, 0) -
                         Nvl(d.Cancel_Qty, 0) -
                         --20180509 hejy3 常规入库需扣减预约直发量
                         decode(v_Source_Type_Code, '03', 0, (nvl(l.direct_transport_qty, 0) - nvl(l.cancel_direct_transport_qty, 0)-nvl(l.already_direct_transport_qty,0)))
                         ),
                     0) Can_Supply_Qty
            Into v_Fcan_Supply_Qty
            From t_Pln_Order_Detail d,
                 t_Pln_Order_Head   h,
                 t_Pln_Order_Line   l,
                 t_Pln_Order_Type   t
           Where d.Order_Head_Id = h.Order_Head_Id
             And d.Entity_Id = h.Entity_Id
             And d.Order_Line_Id = l.Order_Line_Id
             And d.Order_Head_Id = h.Order_Head_Id
             And d.Producing_Area_Id = v_Producing_Area_Id
             And d.Entity_Id = p_Entity_Id
             And d.Can_Produce_Qty - Nvl(d.Supply_Qty, 0) -
                 Nvl(d.Cancel_Qty, 0) > 0
             And d.Item_Id = v_Item_Id
             And Nvl(d.Close_Flag, v_False) = v_False
             And h.Order_Type_Id = t.Order_Type_Id
             And h.Entity_Id = t.Entity_Id
             And t.Match_Type_Storage = '按订单报送的时间先后顺序匹配'
             And h.Form_State In ('32', '306') --('已排产', '已完成')
             And t.Storage_Priority Is Not Null
                --修改为根据周期的开始日期和主体参数控制
             And Exists
           (Select 1
                    From t_Pln_Order_Period p
                   Where p.Period_Id = h.Period_Id
                     And p.Entity_Id = h.Entity_Id
                     And p.Begin_Date >= v_Can_Supply_Date)
             And (v_False = v_Pln_Wip_Order_Match Or
                 (v_Pln_Wip_Order_Match = v_True And
                 d.Order_Detail_Id In
                 (Select Wd.Order_Detail_Id
                      From t_Inv_Po_Wip_Detail Wd
                     Where Wd.Po_Line_Id = p_Po_Line_Id)));
        Exception
          --无数据异常处理
          When No_Data_Found Then
            v_Fcan_Supply_Qty := 0;
          When Others Then
            v_Value := '获取订单可入库时间外的可入库数量失败!';
            Raise v_Base_Exception;
        End;
      End If;

      If p_Result = v_Success Then
        Begin
          Select l.Executed_Qty
            Into v_Po_Executed_Qty
            From t_Inv_Po_Lines l
           Where l.Po_Line_Id = p_Po_Line_Id;
        Exception
          When Others Then
            v_Value := '获取订单入库数量失败!';
            Raise v_Base_Exception;
        End;
      End If;

      If v_Po_Executed_Qty > v_Can_Supply_Qty And p_Result = v_Success Then
        --检查可入库数量
        v_Value := '产品编码：' || v_Item_Code || v_Nl ||
                    '订单可入库数量不足,可能是工厂提前入库,订单' || v_Nl || v_Inv_Days ||
                    '天内可入库数量：' || To_Char(v_Can_Supply_Qty) || v_Nl ||
                    v_Inv_Days || '天外可入库数量：' || To_Char(v_Fcan_Supply_Qty) || v_Nl ||
                    '单据现入库数量：' || To_Char(v_Po_Executed_Qty) || v_Nl ||
                    '因此可入库数量不足。' || v_Nl;
        Raise v_Base_Exception;
      End If;
      --循环采购单行对应的工单
      v_Value := '循环采购单行对应的工单 ';
      For c_Wip In (Select *
                      From t_Inv_Po_Wip_Detail d
                     Where d.Po_Head_Id = v_Po_Head_Id
                       And d.Po_Line_Id = p_Po_Line_Id
                       And d.Executed_Flag <> v_True) Loop

        --获取订单可入库总数量
        If p_Result = v_Success Then
          v_Value := '获取商品:' || v_Item_Code || '订单可入库总数量 ';
          Begin
            Select Decode(v_Pln_Wip_Order_Match,
                          v_True,
                          c_Wip.Wip_Entity_Id,
                          Null)
              Into v_Wip_Entity_Id
              From Dual;
            v_Can_Supply_Qty := f_Get_Order_Supply_Qty(v_Item_Id,
                                                       v_Can_Supply_Date,
                                                       v_Producing_Area_Id,
                                                       p_Entity_Id,
                                                       v_Wip_Entity_Id, --根据工单单号获取订单可入库数
                                                       v_Source_Type_Code
                                                       );
            --检查可入库数量
            If (c_Wip.Executed_Qty > v_Can_Supply_Qty) Then
              v_Value := '订单可入库数量不足,可能是工厂提前入库,订单可入库数量:' ||
                          To_Char(v_Can_Supply_Qty) || '  现入库数量' ||
                          To_Char(c_Wip.Executed_Qty) || v_Nl || '工单号:' ||
                          c_Wip.Wip_Entity_Code || '，商品编码' || v_Item_Code;
              Raise v_Base_Exception;
            End If;
          Exception
            When Others Then
              v_Value := v_Value || '失败!' || Sqlerrm;
              Raise v_Base_Exception;
          End;
        End If;

        --工单可入库数量
        If p_Result = v_Success Then
          v_Value := '获取工单:' || c_Wip.Wip_Entity_Code || '可入库数量  ';
          Begin
            Select Nvl(Wip.Produce_Qty, 0) - Nvl(Wip.Exec_Qty, 0)
              Into v_Wip_Can_Supply_Qty
              From t_Inv_Wip_In_Info Wip
             Where Wip.Wip_Entity_Id = c_Wip.Wip_Entity_Id;

            If c_Wip.Executed_Qty > v_Wip_Can_Supply_Qty Then
              p_Result := '工单可入库数量不足,工单可入库数量:' ||
                          To_Char(v_Wip_Can_Supply_Qty) || '  工单现入库数量' ||
                          To_Char(c_Wip.Executed_Qty) || v_Nl || '工单号:' ||
                          c_Wip.Wip_Entity_Code || '，商品编码' || v_Item_Code;
              Raise v_Base_Exception;
            End If;
          Exception
            When Others Then
              v_Value := v_Value || '失败!' || Sqlerrm;
              Raise v_Base_Exception;
          End;
        End If;

        If p_Result = v_Success And c_Wip.Executed_Qty > 0 Then
          v_Curr_Wip_Supply_Qty := c_Wip.Executed_Qty;
          v_Order_Match_Qty     := 0;
          --游标循环 匹配各订单
          Open c_Order(v_Item_Id,
                       v_Producing_Area_Id,
                       v_Can_Supply_Date,
                       v_Supply_Seq,
                       v_False,
                       c_Wip.Order_Detail_Id,
                       v_Source_Type_Code);
          Loop
            Fetch c_Order
              Into r_Order;
            Exit When c_Order%Notfound Or p_Result <> v_Success;
            --匹配数量 取 MIN( 当前订单可入库数量 , 工单剩余入库数量,剩余执行数量)
            If p_Result = v_Success Then
              v_Value           := '获取当前匹配数量';
              v_Order_Match_Qty := Least(v_Curr_Wip_Supply_Qty,
                                         r_Order.Can_Supply_Qty);

              /*If n_ord_match_qty > abs(p_tran_quantity) - i_exe_tran_qty Then
                n_ord_match_qty := abs(p_tran_quantity) - i_exe_tran_qty;
              End If;*/
            End If;

            Exit When(v_Order_Match_Qty <= 0);

            Begin
              --插入匹配历史
              v_Value := '插入中转单明细行，计划订单号:' || r_Order.Order_Number ||
                         '  工单号:' || c_Wip.Wip_Entity_Code;
              Insert Into t_Inv_Po_Lines_Detail
                (Po_Detail_Id, --采购单行明细id
                 Entity_Id, --经营主体id
                 Po_Head_Id, --采购单头id
                 Po_Line_Id, --采购单行id
                 Order_Header_Id, --订单头id
                 Order_Number, --订单编号
                 Order_Line_Id, --订单行id
                 Order_Detail_Id, --订单明细行id
                 Wip_Entity_Id, --工单编码
                 Wip_Entity_Code, --工单名称
                 Item_Id, --
                 Item_Code, --产品编码，即销售码
                 Item_Name, --产品名称
                 Uom_Code, --产品单位
                 Item_Barcode, --产品条码
                 Item_Suite_Id, --
                 Item_Suite_Code, --套件编码
                 Item_Suite_Name, --套件名称
                 Customer_Id, --客户id
                 Customer_Code, --客户编码
                 Customer_Name, --客户名称
                 Billed_Qty, --单据数量
                 Shipped_Qty, --发货数量，发货数量与开单数量会不一样。
                 Received_Qty, --接收数量，安得回写的实际收货数量。
                 Executed_Flag, --执行标志
                 Executed_Date, --执行日期
                 Executed_Qty, --执行数量
                 Canceled_Qty, --红冲数量
                 Created_By, --创建者
                 Creation_Date, --创建日期
                 Last_Updated_By, --更新者
                 Last_Update_Date, --更新日期
                 Remark, --备注
                 Organization_Id, --组织id
                 Aps_Wip_Intf_Flag, --已引aps工单入库接口标志
                 Aps_Wip_Intf_By, --引入aps工单入库接口用户
                 Aps_Wip_Intf_Date --引入APS工单入库接口日期
                 )
              Values
                (s_Inv_Po_Lines_Detail.Nextval, --采购单行明细id
                 p_Entity_Id, --经营主体id
                 v_Po_Head_Id, --采购单头id
                 p_Po_Line_Id, --采购单行id
                 r_Order.Order_Head_Id, --订单头id
                 r_Order.Order_Number, --订单编号
                 r_Order.Order_Line_Id, --订单行id
                 r_Order.Order_Detail_Id, --订单明细行id
                 c_Wip.Wip_Entity_Id, --工单编码
                 c_Wip.Wip_Entity_Code, --工单名称
                 c_Wip.Item_Id, --
                 c_Wip.Item_Code, --产品编码，即销售码
                 c_Wip.Item_Name, --产品名称
                 v_Item_Uom_Code, --产品单位
                 c_Wip.Item_Bar_Code, --产品条码
                 r_Order.Ass_Item_Id, --
                 r_Order.Ass_Item_Code, --套件编码
                 r_Order.Ass_Item_Name, --套件名称
                 r_Order.Customer_Id, --客户id
                 r_Order.Customer_Code, --客户编码
                 r_Order.Customer_Name, --客户名称
                 v_Order_Match_Qty, --billed_qty,  --单据数量
                 v_Order_Match_Qty, --shipped_qty,  --发货数量，发货数量与开单数量会不一样。
                 v_Order_Match_Qty, --received_qty,  --接收数量，安得回写的实际收货数量。
                 'Y', --执行标志
                 Trunc(Sysdate), --执行日期
                 v_Order_Match_Qty, -- executed_qty,  --执行数量
                 0, --canceled_qty,  --红冲数量
                 p_User_Code, --创建者
                 Sysdate, --创建日期
                 p_User_Code, --更新者
                 Sysdate, --更新日期
                 Null, --remark,  --备注
                 c_Wip.Organization_Id, --组织id
                 'N', --aps_wip_intf_flag,  --已引aps工单入库接口标志
                 Null, --aps_wip_intf_by,  --引入aps工单入库接口用户
                 Null --aps_wip_intf_date
                 );

              --1、回写计划订单明细行入库数量
              v_Value := '回写计划订单明细行入库数量,计划订单号:' || r_Order.Order_Number;
              Update t_Pln_Order_Detail Pod
              --入库数量
                 Set Pod.Supply_Qty = Nvl(Pod.Supply_Qty, 0) +
                                      Nvl(v_Order_Match_Qty, 0),
                     --第一次入库时间
                     Pod.Begin_Supply_Date = Decode(Pod.Begin_Supply_Date,
                                                    Null,
                                                    Sysdate,
                                                    Pod.Begin_Supply_Date),
                     --最后次入库时间
                     Pod.End_Supply_Date = Sysdate
               Where Pod.Entity_Id = p_Entity_Id
                 And Pod.Order_Detail_Id = r_Order.Order_Detail_Id
                 And Pod.Order_Head_Id = r_Order.Order_Head_Id
                 And Pod.Order_Line_Id = r_Order.Order_Line_Id;

              --更新明细行COLSE_FLAG
              Update t_Pln_Order_Detail Pod
                 Set Pod.Close_Flag = v_True
               Where Pod.Entity_Id = p_Entity_Id
                 And Pod.Order_Detail_Id = r_Order.Order_Detail_Id
                 And Pod.Order_Head_Id = r_Order.Order_Head_Id
                 And Pod.Order_Line_Id = r_Order.Order_Line_Id
                 And Pod.Can_Produce_Qty - Nvl(Pod.Supply_Qty, 0) -
                     Nvl(Pod.Cancel_Qty, 0) = 0;

              --跟新订单行
              v_Value := '更新订单行入库数量,计划订单号:' || r_Order.Order_Number;
              --判断当前套机行的商品是否套机
              Select Count(*)
                Into v_Count
                From t_Bd_Item_Assemblies Bia,
                     --套件行表
                     t_Bd_Item_Assemblies_Sub Ias,
                     --套件头表
                     t_Pln_Order_Line Pol
               Where Bia.Item_Assembly_Id = Ias.Item_Assembly_Id
                 And Bia.Entity_Id = Ias.Entity_Id
                 And Bia.Entity_Id = p_Entity_Id
                 And Bia.Item_Id = Pol.Item_Id
                 And Pol.Entity_Id = Bia.Entity_Id
                 And Pol.Order_Line_Id = r_Order.Order_Line_Id
                 And Trunc(Sysdate) Between Ias.Begin_Date And
                     Trunc(Nvl(Ias.End_Date, Sysdate))
                 And Trunc(Sysdate) Between Bia.Begin_Date And
                     Trunc(Nvl(Bia.End_Date, Sysdate));
              --套机
              If v_Count > 0 Then
                Select Min(Sum(Nvl(Pod.Supply_Qty, 0)) /
                           Decode(Ias.Quantity, Null, 1, 0, 1, Ias.Quantity))
                  Into v_Pln_Detail_Supply_Qty --入库数量
                  From t_Pln_Order_Detail Pod,
                       --计划周订单明细表
                       t_Bd_Item_Assemblies Bia,
                       --套件行表
                       t_Bd_Item_Assemblies_Sub Ias --套件头表
                 Where Pod.Item_Id = Ias.Item_Id
                   And Bia.Item_Assembly_Id = Ias.Item_Assembly_Id
                   And Bia.Entity_Id = Ias.Entity_Id
                   And Bia.Entity_Id = p_Entity_Id
                   And Bia.Item_Id = r_Order.Ass_Item_Id
                   And Pod.Order_Line_Id = r_Order.Order_Line_Id
                   And Trunc(Sysdate) Between Ias.Begin_Date And
                       Nvl(Ias.End_Date, Sysdate)
                   And Trunc(Sysdate) Between Bia.Begin_Date And
                       Nvl(Bia.End_Date, Sysdate)
                 Group By Pod.Item_Id, Ias.Quantity; --按散件行商品和配套行数量来汇总(不能缺少)

              Else
                Select Sum(Nvl(Pod.Supply_Qty, 0))
                  Into v_Pln_Detail_Supply_Qty --入库数量
                  From t_Pln_Order_Detail Pod --计划订单明细表
                 Where Pod.Entity_Id = p_Entity_Id
                   And Pod.Order_Line_Id = r_Order.Order_Line_Id
                   And Pod.Order_Head_Id = r_Order.Order_Head_Id;
              End If;

              If v_Pln_Detail_Supply_Qty > 0 Then
                --回写计划订单行入库数量  ,更新第一次入库日期和最后次入库日期
                Update t_Pln_Order_Line Pol
                   Set Pol.Supply_Qty = v_Pln_Detail_Supply_Qty, --入库数量
                       --第一次入库日期
                       Pol.Begin_Supply_Date = Decode(Nvl(Pol.Supply_Qty, 0),
                                                      0,
                                                      Sysdate,
                                                      Nvl(Pol.Begin_Supply_Date,
                                                          Sysdate)),
                       --最后次入库日期
                       Pol.End_Supply_Date = Sysdate
                 Where Pol.Entity_Id = p_Entity_Id
                   And Pol.Order_Head_Id = r_Order.Order_Head_Id
                   And Pol.Order_Line_Id = r_Order.Order_Line_Id;
              End If;
            Exception
              When Others Then
                v_Value := v_Value || '失败!' || ' 中转单号:' ||
                            v_Po_Order_Number || ' 订单号:' ||
                            r_Order.Order_Number || ' 工单号:' ||
                            c_Wip.Wip_Entity_Code || ' 商品编码:' ||
                            v_Item_Code || v_Nl || ' 错误信息:' || Sqlerrm;
                Raise v_Base_Exception;
            End;

            --订单库存点用数据处理,订单类型必需设置了锁定库存
            If p_Result = v_Success And nvl(r_order.is_lock_inv_flag, v_false) = v_true Then
              v_Value := '执行订单行占用库存';
              Pkg_Pln_Inv_Occupy.p_Supply_Occupy_Stocks(p_Inventory_Id      => v_Fin_Inventory_Id, --仓库id
                                                        p_Item_Id           => r_Order.Item_Id, --产品id
                                                        p_Occupy_Qty        => v_Order_Match_Qty, --占用数量
                                                        p_Match_Pln_To_Wip  => v_Pln_Wip_Order_Match, --工单与订单完全匹配标志 y:完全匹配  n:非完全匹配
                                                        p_Action_Desc       => '中转单执行', --单据操作描述 例：中转单据执行、中转红冲单执行
                                                        p_Entity_Id         => p_Entity_Id, --主体id
                                                        p_Origin_Type       => '计划订单', --来源类型
                                                        p_Origin_Head_Id    => r_Order.Order_Head_Id, --来源头id
                                                        p_Origin_Number     => r_Order.Order_Number, --来源头编码
                                                        p_Origin_Line_Id    => r_Order.Order_Line_Id, --来源行id
                                                        p_Source_Order_Type => v_Order_Type_Name, --事务来源单据类型
                                                        p_Source_Head_Id    => v_Po_Head_Id, --事务来源头id
                                                        p_Source_Number     => v_Po_Order_Number, --事务来源头编码
                                                        p_Source_Line_Id    => p_Po_Line_Id, --事务来源行id
                                                        p_User_Code         => p_User_Code, --用户id
                                                        p_Result            => v_Err_Num, --返回错误id
                                                        p_Err_Msg           => p_Result --返回错误信息
                                                        );
              If p_Result <> v_Success Then
                Raise v_Base_Exception;
              End If;
            End If;

            --add by lizhen 2015-07-10 T+N订单时计算订单的齐套率，并更新到计划订单头
            Pkg_Pln_Pub.p_Count_Order_Neat_Set_Rate(p_Order_Head_id  => r_Order.Order_Head_Id, --计划订单头ID
                                                    p_Entity_Id      => p_Entity_Id, --主体ID
                                                    p_User_Code      => p_User_Code, --用户编码
                                                    p_Result         => v_Value --返回结果，成功返回“SUCCESS”，失败返回错误信息
                                                    );
            If v_Value != v_Success Then
              Raise v_Base_Exception;
            End If;

            --跟新工单入库数量
            Begin
              If p_Result = v_Success Then
                v_Value := '更新工单入库数量 , 工单号:' || c_Wip.Wip_Entity_Code;
                Update t_Inv_Wip_In_Info Wii
                   Set Wii.Exec_Qty         = Nvl(Wii.Exec_Qty, 0) +
                                              v_Order_Match_Qty,
                       Wii.Last_Update_Date = Sysdate,
                       Wii.Lock_Qty         = Nvl(Wii.Lock_Qty, 0) -
                                              v_Order_Match_Qty
                 Where Wii.Wip_Entity_Id = c_Wip.Wip_Entity_Id;

                 Update t_Inv_Wip_In_Info Wii
                    Set Wii.End_Flag = Decode(Sign(Wii.Produce_Qty -
                                                   Nvl(Wii.Exec_Qty, 0)),
                                              0,
                                              'Y',
                                              'N')
                  Where Wii.Wip_Entity_Id = c_Wip.Wip_Entity_Id;
              End If;
              --更新工单与订单匹配关系表数据
              If p_Result = v_Success Then
                Update t_Pln_Wip_Order_Relation Wor
                   Set Wor.In_Inv_Qty       = Nvl(Wor.In_Inv_Qty, 0) +
                                              v_Order_Match_Qty,
                       Wor.Wait_Execute_Qty = Nvl(Wor.Wait_Execute_Qty, 0) -
                                              v_Order_Match_Qty,
                       Wor.Last_Updated_By  = p_User_Code,
                       Wor.Last_Update_Date = Sysdate
                 Where Wor.Entity_Id = p_Entity_Id
                   And Wor.Order_Detail_Id = r_Order.Order_Detail_Id
                   And Wor.Order_Line_Id = r_Order.Order_Line_Id
                   And Wor.Order_Head_Id = r_Order.Order_Head_Id
                   And Wor.Wip_Entity_Id = c_Wip.Wip_Entity_Id;
              End If;
            Exception
              When Others Then
                v_Value := '失败!' || Sqlerrm;
                Raise v_Base_Exception;
            End;
            If p_Result = v_Success Then
              --累计减少工单可匹配数量
              v_Curr_Wip_Supply_Qty := v_Curr_Wip_Supply_Qty -
                                       v_Order_Match_Qty;
              --判断工单是否已匹配完毕
              Exit When v_Curr_Wip_Supply_Qty = 0;
            End If;
          End Loop; --订单明细行循环结束
          Close c_Order;
          --结束此工单匹配
          v_Value := '检查工单匹配数量';
          If v_Curr_Wip_Supply_Qty < 0 Then
            v_Value := '工单与订单匹配失败，可匹配数量匹配订单后为负数。工单单号：' ||
                        c_Wip.Wip_Entity_Code || '，中转单行ID：' ||
                        To_Char(p_Po_Line_Id) || '，订单明细行ID：' ||
                        To_Char(c_Wip.Order_Detail_Id);
            Raise v_Base_Exception;
          End If;
          --结束此工单匹配
          If v_Curr_Wip_Supply_Qty > 0 Then
            v_Value := '工单与订单匹配失败，工单数量存在未配置完的数量。工单单号：' ||
                        c_Wip.Wip_Entity_Code || '，中转单行ID：' ||
                        To_Char(p_Po_Line_Id) || '，订单明细行ID：' ||
                        To_Char(c_Wip.Order_Detail_Id);
            Raise v_Base_Exception;
          End If;
          --修改工单入库明细的"生成采购单明细行"标记为Y
          If p_Result = v_Success Then
            v_Value := '修改生成采购单明细行"已执行"标记 , 工单号:' || c_Wip.Wip_Entity_Code;
            Update t_Inv_Po_Wip_Detail d
               Set d.Executed_Flag = v_True,
                   d.Executed_Date = Trunc(Sysdate)
             Where d.Wip_Entity_Id = c_Wip.Wip_Entity_Id
               And d.Po_Line_Id = c_Wip.Po_Line_Id
               And d.Po_Head_Id = c_Wip.Po_Head_Id;
          End If;
        End If;
      End Loop; --工单明细行循环结束

      --红冲单据 红冲单据流程
    Elsif v_Red_Order_Flag = v_True And p_Result = v_Success Then
      --modi by lizhen 2015-04-07 红冲功能单独放入过程。
      If v_Order_Status = '21' Then
        p_Read_Wip_Ord_Match(p_Po_Line_Id    => p_Po_Line_Id, --中转单行ID
                             p_Tran_Quantity => p_Tran_Quantity, --事务数量带正负号
                             p_Entity_Id     => p_Entity_Id, --主体ID
                             p_User_Code     => p_User_Code, --用户ID
                             p_Result        => v_Value);
        If v_Value != v_Success Then
          Raise v_Base_Exception;
        End If;
      Elsif v_Order_Status = '14' Then
        Select Count(*) Into v_Count
          From t_Inv_Po_Lines_Detail Pld
         Where Pld.Po_Head_Id = v_Po_Head_Id
           And Pld.Po_Line_Id = p_Po_Line_Id;
        If Nvl(v_Count, 0) = 0 Then
          v_Value := '中转单执行失败，中转单行未生成中转单行明细表数据。' || v_Nl ||
            '中转单行ID：' || To_Char(p_Po_Line_Id);
          Raise v_Base_Exception;
        End If;
        Begin
          For r_Red_Po In (Select *
                             From t_Inv_Po_Lines_Detail Pld
                            Where Pld.Po_Head_Id = v_Po_Head_Id
                              And Pld.Po_Line_Id = p_Po_Line_Id) Loop
            Begin
              Select Ot.Is_Lock_Inv_Flag
                Into v_Is_Lock_Inv_Flag
                From t_Pln_Order_Type Ot, t_Pln_Order_Head Poh
               Where Ot.Order_Type_Id = Poh.Order_Type_Id
                 And Poh.Order_Head_Id = r_Red_Po.Order_Header_Id
                 And Poh.Entity_Id = p_Entity_Id;
            Exception
              When Others Then
                v_Value := '获取订单单据类型信息失败。' || v_Nl ||
                  '订单头ID：' || To_Char(r_Red_Po.Order_Header_Id);
                Raise v_Base_Exception;
            End;
            --订单库存点用数据处理
            If p_Result = v_Success And
               Nvl(v_Is_Lock_Inv_Flag, v_False) = v_True Then
              v_Value := '执行订单行占用释放库存';
              Pkg_Pln_Inv_Occupy.p_Supply_Unoccupy_Stocks(p_Inventory_Id      => v_Fin_Inventory_Id, --仓库id
                                                          p_Item_Id           => r_Red_Po.Item_Id, --产品id
                                                          p_Occupy_Qty        => r_Red_Po.Shipped_Qty, --占用数量
                                                          p_Match_Pln_To_Wip  => v_Pln_Wip_Order_Match, --工单与订单完全匹配标志 y:完全匹配  n:非完全匹配
                                                          p_Action_Desc       => '中转红冲单执行', --单据操作描述 例：中转单据执行、中转红冲单执行
                                                          p_Entity_Id         => p_Entity_Id, --主体id
                                                          p_Origin_Type       => '计划订单', --来源类型
                                                          p_Origin_Head_Id    => r_Red_Po.Order_Header_Id, --来源头id
                                                          p_Origin_Number     => r_Red_Po.Order_Number, --来源头编码
                                                          p_Origin_Line_Id    => r_Red_Po.Order_Line_Id, --来源行id
                                                          p_Source_Order_Type => v_Order_Type_Name, --事务来源单据类型
                                                          p_Source_Head_Id    => v_Po_Head_Id, --事务来源头id
                                                          p_Source_Number     => v_Po_Order_Number, --事务来源头编码
                                                          p_Source_Line_Id    => p_Po_Line_Id, --事务来源行id
                                                          p_User_Code         => p_User_Code, --用户id
                                                          p_Allow_No_Occupy   => 'N',
                                                          p_Result            => v_Err_Num, --返回错误id
                                                          p_Err_Msg           => p_Result --返回错误信息
                                                          );
              If p_Result <> v_Success Then
                Raise v_Base_Exception;
              End If;
            End If;
            --add by lizhen 2015-07-10 T+N订单时计算订单的齐套率，并更新到计划订单头
            Pkg_Pln_Pub.p_Count_Order_Neat_Set_Rate(p_Order_Head_id  => r_Red_Po.Order_Header_Id, --计划订单头ID
                                                   p_Entity_Id      => p_Entity_Id, --主体ID
                                                    p_User_Code      => p_User_Code, --用户编码
                                                    p_Result         => v_Value --返回结果，成功返回“SUCCESS”，失败返回错误信息
                                                    );
            If v_Value != v_Success Then
              Raise v_Base_Exception;
            End If;
            Update t_Inv_Po_Lines_Detail Pld
               Set Pld.Received_Qty     = Pld.Shipped_Qty,
                   Pld.Executed_Flag    = 'Y',
                   Pld.Executed_Date    = Sysdate,
                   Pld.Executed_Qty     = Pld.Shipped_Qty,
                   Pld.Last_Updated_By  = p_User_Code,
                   Pld.Last_Update_Date = Sysdate
             Where Pld.Po_Detail_Id = r_Red_Po.Po_Detail_Id;
          End Loop;
        End;
      End If;
      /*If p_Result = v_Success Then
        --获取原采购中转单行ID
        v_Value := '获取原采购中转单行ID ,中转单号:' || v_Po_Order_Number;
        Select l.Po_Line_Id_Old
          Into v_Old_Po_Line_Id
          From t_Inv_Po_Lines l
         Where l.Po_Id = v_Po_Head_Id
           And l.Po_Line_Id = p_Po_Line_Id;
      End If;

      If p_Result = v_Success Then
        Begin
          v_Value := '获取产地';
          Select a.Producing_Area_Id, Wii.Organization_Id
            Into v_Producing_Area_Id, v_Organization_Id
            From t_Inv_Wip_In_Info Wii, t_Pln_Producing_Area a
           Where a.Mrp_Org_Id = Wii.Organization_Id
             And a.Entity_Id = p_Entity_Id
             And Wii.Wip_Entity_Id =
                 (Select d.Wip_Entity_Id
                    From t_Inv_Po_Lines_Detail d
                   Where d.Po_Line_Id = v_Old_Po_Line_Id
                     And Rownum = 1);
        Exception
          When Others Then
            v_Value := '获取产地失败，中转单行ID：' || To_Char(v_Old_Po_Line_Id) || v_Nl ||
                       Sqlerrm;
            Raise v_Base_Exception;
        End;
      End If;

      --获取库存占用数量
      If p_Result = v_Success Then
        v_Value := '获取库存占用数量';
        Declare
          v_Usable_Qoh_Qty  Number;
        Begin
          Pkg_Inv_Pub.p_Get_Item_Inv_Qoh(p_Entity_Id         => p_Entity_Id,
                                         p_Inventory_Id      => v_Fin_Inventory_Id,
                                         p_Item_Id           => v_Item_Id,
                                         p_User_Code         => p_User_Code,
                                         p_Qoh_Qty           => v_Item_Onhand_Qty,
                                         p_Usable_Qoh_Qty    => v_Usable_Qoh_Qty,
                                         p_Occupy_Qty        => v_Item_Occupy_Qty,
                                         p_Result            => v_Value);
          If v_Value != v_Success Then
            v_Value := '获取库存现有量、库占用数量失败';
            Raise v_Base_Exception;
          End If;
          Select Pkg_Pln_Inv_Occupy.f_Get_Item_Occupy_Qty(v_Fin_Inventory_Id,
                                                          v_Item_Id,
                                                          p_Entity_Id,
                                                          v_Pln_Wip_Order_Match)
            Into v_Pln_Occupy_Qty
            From Dual;
        Exception
          When No_Data_Found Then
            v_Item_Occupy_Qty := 0;
          When Others Then
            p_Result := v_Value || '失败!' || '错误信息:' || p_Result || Sqlerrm;
            Raise v_Base_Exception;
        End;
      End If;
      If v_Pln_Wip_Order_Match <> v_True Then
        --获取定制机占用数量
        If p_Result = v_Success Then
          v_Value := '获取定制机占用数量';
          Begin
            --计算套散件时，必需*套散件表的数量
            Select Nvl(Sum((Nvl(Oss.Share_Qty, 0) - Nvl(Oss.So_Order_Qty, 0)) *
                       Nvl((Select Ias.Quantity
                             From t_Bd_Item_Assemblies     Bia,
                                  t_Bd_Item_Assemblies_Sub Ias
                            Where Bia.Item_Assembly_Id =
                                  Ias.Item_Assembly_Id
                              And Bia.Entity_Id = Ias.Entity_Id
                              And Trunc(Sysdate) Between Bia.Begin_Date And
                                  Nvl(Bia.End_Date, Sysdate)
                              And Trunc(Sysdate) Between Ias.Begin_Date And
                                  Nvl(Ias.End_Date, Trunc(Sysdate))
                                 --And Nvl(Ias.Fittings_Flag, v_False) = v_False
                              And Bia.Item_Id = Oss.Item_Id
                              And ias.item_id = v_Item_Id
                           Union All
                           --非套件产品
                           Select 1 Quantity
                             From t_Bd_Item Tbi
                            Where Tbi.Item_Id = Oss.Item_Id
                              And Not Exists
                            (Select 1
                                     From t_Bd_Item_Assemblies Bia
                                    Where Bia.Item_Id = Tbi.Item_Id
                                      And Bia.Item_Id = Oss.Item_Id
                                      And Trunc(Sysdate) Between
                                          Bia.Begin_Date And
                                          Nvl(Bia.End_Date, Sysdate))),
                           1)),
                       0)
              Into v_Item_Share_Qty
            --可用分配数量 ＝ 已分配数量 － 已开单数量
              From t_Pln_Order_Share_Shipment Oss
             Where Oss.Entity_Id = p_Entity_Id
               And Oss.Inventory_From_Id = v_Fin_Inventory_Id
               And Nvl(Oss.Close_Flag, v_False) <> v_Close
               And Nvl(Oss.Share_Qty, 0) > Nvl(Oss.So_Order_Qty, 0)
               --And Nvl(oss.inv_share_flag, 'N') = 'N'
               ;
            --可释放数量=占用-已分配未下达
            v_Usable_Occupy_Qty := v_Pln_Occupy_Qty - v_Item_Share_Qty;

            If v_Usable_Occupy_Qty < 0 Then
              v_Usable_Occupy_Qty := 0;
            End If;
          Exception
            When No_Data_Found Then
              v_Usable_Occupy_Qty := 0;
            When Others Then
              p_Result := v_Value || '失败!' || '错误信息:' || p_Result ||
                          Sqlerrm;
              Raise v_Base_Exception;
          End;
        End If;

        If v_Item_Onhand_Qty -
           (v_Item_Occupy_Qty - Nvl(v_Usable_Occupy_Qty, 0)) < 0 Then
          v_Value := '中转单号:' || v_Po_Order_Number || ' 商品编码:' ||
                     v_Item_Code || '可红冲库存不足!';
          Raise v_Base_Exception;
        End If;
        --获取订单可红冲数量 ,并检查是否可红
        If f_Get_Ord_Usable_Red_Qty(v_Item_Id,
                                    v_Producing_Area_Id,
                                    p_Entity_Id,
                                    v_Order_Usable_Red_Qty) <> v_Success Then
          v_Value := '获取订单可红冲数量：';
          Raise v_Base_Exception;
        End If;
        If v_Order_Usable_Red_Qty <= 0 Then
          v_Value := '中转单号:' || v_Po_Order_Number || ' 商品编码:' ||
                     v_Item_Code;
          Raise v_Base_Exception;
        End If;
      Else
        --获取定制机占用数量
        If p_Result = v_Success And v_Pln_Wip_Order_Match = v_True Then
          v_Value := '新占用库存方式，获取定制机占用数量';
          Begin
            Select Nvl((Select Sum(Nvl(Io.Stock_Affirm_Qty, 0) +
                                  Nvl(Io.Supply_Qty, 0) -
                                  Nvl(Io.So_Order_Qty, 0) -
                                  Nvl(Io.Sundry_Qty, 0)) Sum_Lock_Qty
                         From t_Pln_Order_Inv_Occupy Io
                        Where Io.Item_Id = v_Item_Id
                          And Io.Inventory_Id = v_Fin_Inventory_Id
                          And Io.Entity_Id = p_Entity_Id
                          And Io.Origin_Type = '订单与工单完全匹配'
                          And Io.Origin_Line_Id In
                              (Select d.Order_Line_Id
                                 From t_Inv_Po_Lines_Detail d
                                Where d.Po_Line_Id = v_Old_Po_Line_Id
                                  And d.Entity_Id = p_Entity_Id)),
                       0)
              Into v_Pln_Occupy_Qty
              From Dual;
          Exception
            When No_Data_Found Then
              v_Pln_Occupy_Qty := 0;
            When Others Then
              v_Value := v_Value || '失败!' || '错误信息:' || v_Nl || Sqlerrm;
              Raise v_Base_Exception;
          End;
          Begin
            v_Value := '获取定制机已下达未开单的数量';
            --计算套散件时，必需*套散件表的数量
            Select Nvl(Sum((Nvl(Oss.Carry_Qty, 0) - Nvl(Oss.So_Order_Qty, 0)) *
                       Nvl((Select Ias.Quantity
                             From t_Bd_Item_Assemblies     Bia,
                                  t_Bd_Item_Assemblies_Sub Ias
                            Where Bia.Item_Assembly_Id =
                                  Ias.Item_Assembly_Id
                              And Bia.Entity_Id = Ias.Entity_Id
                              And Trunc(Sysdate) Between Bia.Begin_Date And
                                  Nvl(Bia.End_Date, Sysdate)
                              And Trunc(Sysdate) Between Ias.Begin_Date And
                                  Nvl(Ias.End_Date, Trunc(Sysdate))
                                 --And Nvl(Ias.Fittings_Flag, v_False) = v_False
                              And Bia.Item_Id = Oss.Item_Id
                              And Ias.Item_id = v_Item_Id
                           Union All
                           --非套件产品
                           Select 1 Quantity
                             From t_Bd_Item Tbi
                            Where Tbi.Item_Id = Oss.Item_Id
                              And Not Exists
                            (Select 1
                                     From t_Bd_Item_Assemblies Bia
                                    Where Bia.Item_Id = Tbi.Item_Id
                                      And Bia.Item_Id = Oss.Item_Id
                                      And Trunc(Sysdate) Between
                                          Bia.Begin_Date And
                                          Nvl(Bia.End_Date, Sysdate))),
                           1)),
                       0)
              Into v_Item_Share_Qty
            --可用分配数量 ＝ 已下达数量 － 已开单数量
              From t_Pln_Order_Share_Shipment Oss
             Where Oss.Entity_Id = p_Entity_Id
               And Oss.Inventory_From_Id = v_Fin_Inventory_Id
               And Nvl(Oss.Close_Flag, v_False) <> v_Close
               And Nvl(Oss.Carry_Qty, 0) > Nvl(Oss.So_Order_Qty, 0)
               And Oss.Origin_Line_Id In
                   (Select d.Order_Line_Id
                      From t_Inv_Po_Lines_Detail d
                     Where d.Po_Line_Id = v_Old_Po_Line_Id
                       And d.Entity_Id = p_Entity_Id)
               ;

            --获取库存评审的已分配未下达数量    计算套散件时，必需*套散件表的数量
            Select Nvl(Sum((Nvl(Oss.Share_Qty, 0) - Nvl(Oss.So_Order_Qty, 0)) *
                       Nvl((Select Ias.Quantity
                             From t_Bd_Item_Assemblies     Bia,
                                  t_Bd_Item_Assemblies_Sub Ias
                            Where Bia.Item_Assembly_Id =
                                  Ias.Item_Assembly_Id
                              And Bia.Entity_Id = Ias.Entity_Id
                              And Trunc(Sysdate) Between Bia.Begin_Date And
                                  Nvl(Bia.End_Date, Sysdate)
                              And Trunc(Sysdate) Between Ias.Begin_Date And
                                  Nvl(Ias.End_Date, Trunc(Sysdate))
                                 --And Nvl(Ias.Fittings_Flag, v_False) = v_False
                              And Bia.Item_Id = Oss.Item_Id
                              And Ias.Item_id = v_Item_Id
                           Union All
                           --非套件产品
                           Select 1 Quantity
                             From t_Bd_Item Tbi
                            Where Tbi.Item_Id = Oss.Item_Id
                              And Not Exists
                            (Select 1
                                     From t_Bd_Item_Assemblies Bia
                                    Where Bia.Item_Id = Tbi.Item_Id
                                      And Bia.Item_Id = Oss.Item_Id
                                      And Trunc(Sysdate) Between
                                          Bia.Begin_Date And
                                          Nvl(Bia.End_Date, Sysdate))),
                           1)),
                       0)
              Into v_Inv_No_Carry_Order_Qty
            --库存评审的已分配未下达数量 ＝ 已分配数量 － 已下达未分配(已下达未开单数量在上一SQL已取数)
              From t_Pln_Order_Share_Shipment Oss
             Where Oss.Entity_Id = p_Entity_Id
               And Oss.Inventory_From_Id = v_Fin_Inventory_Id
               And Nvl(Oss.Close_Flag, v_False) <> v_Close
               And Nvl(Oss.Share_Qty, 0) > Nvl(Oss.So_Order_Qty, 0)
               And Oss.Origin_Line_Id In
                   (Select d.Order_Line_Id
                      From t_Inv_Po_Lines_Detail d
                     Where d.Po_Line_Id = v_Old_Po_Line_Id
                       And d.Entity_Id = p_Entity_Id)
               And Nvl(oss.inv_share_flag, 'N') = 'Y'
               ;

            --可冲占用=占用-已分配未开单
            --工单与订单新匹配模式下，不检查已分配数量，放到P_WIP_TO_ORDER_SHARE
            --库存评审的分配数量不参与工单中转的红冲
            --过程处理，该过程实现自动生成分配行及红冲时自动取消分配
            --已下达未开单的数量，不允许红冲，除非手工取消回下达数量
            v_Usable_Occupy_Qty := v_Pln_Occupy_Qty - nvl(v_Item_Share_Qty, 0) - nvl(v_Inv_No_Carry_Order_Qty, 0);

            If v_Usable_Occupy_Qty < 0 Then
              v_Usable_Occupy_Qty := 0;
            End If;
          Exception
            When No_Data_Found Then
              v_Usable_Occupy_Qty := 0;
            When Others Then
              v_Value := v_Value || '失败!' || '错误信息:' || v_Nl || Sqlerrm;
              Raise v_Base_Exception;
          End;
        End If;

        --库存占用总量 - （计划订单占用总量 - 订单可释放占用数量）- 库存评审已分配未下达数量
        If v_Item_Onhand_Qty -
           (v_Item_Occupy_Qty - Nvl(v_Usable_Occupy_Qty, 0) - nvl(v_Inv_No_Carry_Order_Qty, 0)) < 0 Then
          v_Value := '中转单号:' || v_Po_Order_Number || ' 商品编码:' ||
                     v_Item_Code || '可红冲库存不足!';
          Raise v_Base_Exception;
        End If;
        --ADD BY LIZHEN 检查中转单是否包含
        Select Sum(Nvl(Ld.Executed_Qty, 0))
          Into v_Not_Inv_Lock_Qty
          From t_Pln_Order_Head      Oh,
               t_Inv_Po_Lines_Detail Ld,
               t_Pln_Order_Type      Ot
         Where Oh.Order_Head_Id = Ld.Order_Header_Id
           And Oh.Order_Type_Id = Ot.Order_Type_Id
           And Ot.Is_Lock_Inv_Flag = v_False
           And Ld.Po_Line_Id = v_Old_Po_Line_Id;

        If f_Get_Ord_Usable_Red_Qty(v_Item_Id,
                                    v_Producing_Area_Id,
                                    p_Entity_Id,
                                    v_Order_Usable_Red_Qty,
                                    v_Old_Po_Line_Id, --中转单被红冲行ID，用于查找订单行ID
                                    v_Pln_Wip_Order_Match) <> v_Success Then
          v_Value := '获取订单可取消红冲数量：';
          Raise v_Base_Exception;
        End If;
        If p_Result = v_Success And v_Pln_Wip_Order_Match = v_True Then
          If v_Order_Usable_Red_Qty >= Abs(p_Tran_Quantity) Then
            v_Order_Usable_Red_Qty := Abs(p_Tran_Quantity);
            --为保证无占用用库存的订单可正常匹配，把条件改成 订单占用用数量 + 非库存占用中转入库数量 - 本次需红冲数量  < 0
            --MODI BY LIZHEN 2015-01-11
            --If Nvl(v_Order_Usable_Red_Qty, 0) > v_Pln_Occupy_Qty Then
            If Nvl(v_Pln_Occupy_Qty, 0) + Nvl(v_Not_Inv_Lock_Qty, 0) - Nvl(v_Order_Usable_Red_Qty, 0) < 0 Then
              v_Value := '定制机中转红冲数量(' || To_Char(Nvl(v_Order_Usable_Red_Qty, 0)) ||
                         ')大于对应订单库存占用量(' || To_Char(Nvl(v_Pln_Occupy_Qty, 0) +
                         Nvl(v_Not_Inv_Lock_Qty, 0)) || ')，红冲失败！' ||
                         v_Nl || '请找物流相关人员去红冲相应订单的财务单，释放订单锁单库存，' ||
                         ' 在蓝单的单据行明细可以查询匹配的订单，然后再红冲中转单。';
              Raise v_Base_Exception;
            End If;
          Else
            v_Value := '订单可匹配红冲数量（' || To_Char(v_Order_Usable_Red_Qty) || '）小于本次中转单行红冲数量（'
                    || To_Char(p_Tran_Quantity) || '），中转红冲单匹配订单失败!';
            Raise v_Base_Exception;
          End If;
        End If;
      End If;

      v_Curr_Wip_Red_Qty    := 0;
      v_Order_Red_Match_Qty := 0;
      --开始红冲工单入库信息,循环原采购中转明细行
      If p_Result = v_Success Then
        v_Value := '循环原采购中转明细行';
        For r_Wip_Red In (Select d.Wip_Entity_Id,
                                 d.Wip_Entity_Code,
                                 Decode(v_Pln_Wip_Order_Match,
                                        v_True,
                                        d.Order_Header_Id,
                                        Null) Order_Head_Id,
                                 Decode(v_Pln_Wip_Order_Match,
                                        v_True,
                                        d.Order_Number,
                                        Null) Order_Number,
                                 Decode(v_Pln_Wip_Order_Match,
                                        v_True,
                                        d.Order_Line_Id,
                                        Null) Order_Line_Id,
                                 Decode(v_Pln_Wip_Order_Match,
                                        v_True,
                                        d.Order_Detail_Id,
                                        Null) Order_Detail_Id,
                                 Sum(Nvl(d.Executed_Qty, 0) -
                                     Nvl(d.Canceled_Qty, 0)) Order_Quantity,
                                 d.Item_Barcode
                            From t_Inv_Po_Lines_Detail d
                           Where d.Po_Line_Id = v_Old_Po_Line_Id
                             And d.Entity_Id = p_Entity_Id
                             And Nvl(d.Executed_Qty, 0) -
                                 Nvl(d.Canceled_Qty, 0) > 0 --未红冲完毕
                           Group By d.Wip_Entity_Id,
                                    d.Wip_Entity_Code,
                                    Decode(v_Pln_Wip_Order_Match,
                                           v_True,
                                           d.Order_Header_Id,
                                           Null),
                                    Decode(v_Pln_Wip_Order_Match,
                                           v_True,
                                           d.Order_Number,
                                           Null),
                                    Decode(v_Pln_Wip_Order_Match,
                                           v_True,
                                           d.Order_Line_Id,
                                           Null),
                                    Decode(v_Pln_Wip_Order_Match,
                                           v_True,
                                           d.Order_Detail_Id,
                                           Null),
                                    d.Item_Barcode
                           Order By Order_Quantity) Loop
          --获取本次红冲的数量
          v_Curr_Wip_Red_Qty := Least(Abs(v_Tran_Quantity), r_Wip_Red.Order_Quantity);
          --商品,产地
          If p_Result = v_Success Then
            v_Value := '获取工单:' || r_Wip_Red.Wip_Entity_Code || '商品,产地信息';
            Begin
              Select a.Producing_Area_Id,
                     Nvl(Wii.Exec_Qty, 0),
                     Wii.Organization_Id
                Into v_Producing_Area_Id,
                     v_Wip_Execute_Qty,
                     v_Organization_Id
                From t_Inv_Wip_In_Info Wii, t_Pln_Producing_Area a
               Where Wii.Wip_Entity_Id = r_Wip_Red.Wip_Entity_Id
                 And a.Mrp_Org_Id = Wii.Organization_Id
                 And a.Entity_Id = p_Entity_Id;
            Exception
              When Others Then
                v_Value := v_Value || '失败!' || v_Nl || Sqlerrm;
                Raise v_Base_Exception;
            End;
          End If;

          --工单需要有已入库数量 --此工单入库数量为0则跳到下一个工单进行红冲
          Exit When v_Wip_Execute_Qty <= 0;

          If p_Result = v_Success Then
            --工单红冲数量
            --游标循环分别红冲订单明细行
            --增加仓库，获取占用数量
            For r_Red_Order In c_Order_Red(v_Item_Id,
                                           v_Producing_Area_Id,
                                           v_Supply_Seq,
                                           'N',
                                           r_Wip_Red.Order_Detail_Id,
                                           v_Fin_Inventory_Id) Loop
              --取   工单可红冲数量
              v_Order_Red_Match_Qty := Least(v_Curr_Wip_Red_Qty,
                                             r_Red_Order.Can_Red_Qty);
              Exit When v_Order_Red_Match_Qty = 0;
              --插入匹配历史
              If p_Result = v_Success Then
                v_Value := '插入红冲中转单明细表,计划订单号:' || r_Red_Order.Order_Number ||
                           '  工单号:' || r_Wip_Red.Wip_Entity_Code;
                Insert Into t_Inv_Po_Lines_Detail
                  (Po_Detail_Id, --采购单行明细id
                   Entity_Id, --经营主体id
                   Po_Head_Id, --采购单头id
                   Po_Line_Id, --采购单行id
                   Order_Header_Id, --订单头id
                   Order_Number, --订单编号
                   Order_Line_Id, --订单行id
                   Order_Detail_Id, --订单明细行id
                   Wip_Entity_Id, --工单编码
                   Wip_Entity_Code, --工单名称
                   Item_Id, --
                   Item_Code, --产品编码，即销售码
                   Item_Name, --产品名称
                   Uom_Code, --产品单位
                   Item_Barcode, --产品条码
                   Item_Suite_Id, --
                   Item_Suite_Code, --套件编码
                   Item_Suite_Name, --套件名称
                   Customer_Id, --客户id
                   Customer_Code, --客户编码
                   Customer_Name, --客户名称
                   Billed_Qty, --单据数量
                   Shipped_Qty, --发货数量，发货数量与开单数量会不一样。
                   Received_Qty, --接收数量，安得回写的实际收货数量。
                   Executed_Flag, --执行标志
                   Executed_Date, --执行日期
                   Executed_Qty, --执行数量
                   Canceled_Qty, --红冲数量
                   Created_By, --创建者
                   Creation_Date, --创建日期
                   Last_Updated_By, --更新者
                   Last_Update_Date, --更新日期
                   Remark, --备注
                   Organization_Id, --组织id
                   Aps_Wip_Intf_Flag, --已引aps工单入库接口标志
                   Aps_Wip_Intf_By, --引入aps工单入库接口用户
                   Aps_Wip_Intf_Date --引入APS工单入库接口日期
                   )
                Values
                  (s_Inv_Po_Lines_Detail.Nextval, --采购单行明细id
                   p_Entity_Id, --经营主体id
                   v_Po_Head_Id, --采购单头id
                   p_Po_Line_Id, --采购单行id
                   r_Red_Order.Order_Head_Id, --订单头id
                   r_Red_Order.Order_Number, --订单编号
                   r_Red_Order.Order_Line_Id, --订单行id
                   r_Red_Order.Order_Detail_Id, --订单明细行id
                   r_Wip_Red.Wip_Entity_Id, --工单编码
                   r_Wip_Red.Wip_Entity_Code, --工单名称
                   r_Red_Order.Item_Id, --
                   r_Red_Order.Item_Code, --产品编码，即销售码
                   r_Red_Order.Item_Name, --产品名称
                   v_Item_Uom_Code, --产品单位
                   r_Wip_Red.Item_Barcode, --产品条码
                   r_Red_Order.Ass_Item_Id, --
                   r_Red_Order.Ass_Item_Code, --套件编码
                   r_Red_Order.Ass_Item_Name, --套件名称
                   r_Red_Order.Customer_Id, --客户id
                   r_Red_Order.Customer_Code, --客户编码
                   r_Red_Order.Customer_Name, --客户名称
                   v_Order_Red_Match_Qty, --billed_qty,  --单据数量
                   v_Order_Red_Match_Qty, --shipped_qty,  --发货数量，发货数量与开单数量会不一样。
                   v_Order_Red_Match_Qty, --received_qty,  --接收数量，安得回写的实际收货数量。
                   'Y', --执行标志
                   Trunc(Sysdate), --Executed_Date, --执行日期
                   v_Order_Red_Match_Qty, -- executed_qty,  --执行数量
                   0, --canceled_qty,  --红冲数量
                   p_User_Code, --创建者
                   Sysdate, --创建日期
                   p_User_Code, --更新者
                   Sysdate, --更新日期
                   Null, --remark,  --备注
                   v_Organization_Id, --组织id
                   'N', --aps_wip_intf_flag,  --已引aps工单入库接口标志
                   Null, --aps_wip_intf_by,  --引入aps工单入库接口用户
                   Null --aps_wip_intf_date
                   );
              End If;
              --1、回写计划订单明细行入库数量
              --提前,正常,延迟.入库数量  从后往前面红冲
              If p_Result = v_Success Then
                v_Value := '更新计划订单明细行入库数量,计划订单号:' ||
                           r_Red_Order.Order_Number || '  工单号:' ||
                           r_Wip_Red.Wip_Entity_Code;
                Update t_Pln_Order_Detail Pod
                --入库数量
                   Set Pod.Supply_Qty = Nvl(Pod.Supply_Qty, 0) -
                                        Nvl(v_Order_Red_Match_Qty, 0),
                       --更新CLOSE_FLAG
                       Pod.Close_Flag = v_False
                 Where Pod.Entity_Id = p_Entity_Id
                   And Pod.Order_Detail_Id = r_Red_Order.Order_Detail_Id
                   And Pod.Order_Head_Id = r_Red_Order.Order_Head_Id
                   And Pod.Order_Line_Id = r_Red_Order.Order_Line_Id;
              End If;
              --跟新订单行
              --判断当前套机行的商品是否套机
              If p_Result = v_Success Then
                v_Value := '更新计划订单行入库数量,计划订单号:' || r_Red_Order.Order_Number ||
                           '  工单号:' || r_Wip_Red.Wip_Entity_Code;
                Select Count(*)
                  Into v_Count
                  From t_Bd_Item_Assemblies Bia,
                       --套件行表
                       t_Bd_Item_Assemblies_Sub Ias,
                       --套件头表
                       t_Pln_Order_Line Pol
                 Where Bia.Item_Assembly_Id = Ias.Item_Assembly_Id
                   And Bia.Entity_Id = Ias.Entity_Id
                   And Bia.Entity_Id = p_Entity_Id
                   And Bia.Item_Id = Pol.Item_Id
                   And Pol.Entity_Id = Bia.Entity_Id
                   And Pol.Order_Line_Id = r_Red_Order.Order_Line_Id
                   And Trunc(Sysdate) Between Ias.Begin_Date And
                       Trunc(Nvl(Ias.End_Date, Sysdate))
                   And Trunc(Sysdate) Between Bia.Begin_Date And
                       Trunc(Nvl(Bia.End_Date, Sysdate));
                --套机
                If v_Count > 0 Then
                  Select Min(Sum(Nvl(Pod.Supply_Qty, 0)) /
                             Decode(Ias.Quantity,
                                    Null,
                                    1,
                                    0,
                                    1,
                                    Ias.Quantity))
                    Into v_Pln_Detail_Supply_Qty --入库数量
                    From t_Pln_Order_Detail Pod,
                         --计划周订单明细表
                         t_Bd_Item_Assemblies Bia,
                         --套件行表
                         t_Bd_Item_Assemblies_Sub Ias --套件头表
                   Where Pod.Item_Id = Ias.Item_Id
                     And Bia.Item_Assembly_Id = Ias.Item_Assembly_Id
                     And Bia.Entity_Id = Ias.Entity_Id
                     And Bia.Entity_Id = p_Entity_Id
                     And Bia.Item_Id = r_Red_Order.Ass_Item_Id
                     And Pod.Order_Line_Id = r_Red_Order.Order_Line_Id
                     And Trunc(Sysdate) Between Ias.Begin_Date And
                         Nvl(Ias.End_Date, Sysdate)
                     And Trunc(Sysdate) Between Bia.Begin_Date And
                         Nvl(Bia.End_Date, Sysdate)
                   Group By Pod.Item_Id, Ias.Quantity; --按散件行商品和配套行数量来汇总(不能缺少)
                Else
                  Select Sum(Nvl(Pod.Supply_Qty, 0))
                    Into v_Pln_Detail_Supply_Qty --入库数量
                    From t_Pln_Order_Detail Pod --计划订单明细表
                   Where Pod.Entity_Id = p_Entity_Id
                     And Pod.Order_Line_Id = r_Red_Order.Order_Line_Id
                     And Pod.Order_Head_Id = r_Red_Order.Order_Head_Id;
                End If;

                --回写计划订单行数量
                Update t_Pln_Order_Line Pol --计划周订单行表
                   Set Pol.Supply_Qty = v_Pln_Detail_Supply_Qty --入库数量
                 Where Pol.Entity_Id = p_Entity_Id
                   And Pol.Order_Head_Id = r_Red_Order.Order_Head_Id
                   And Pol.Order_Line_Id = r_Red_Order.Order_Line_Id;

              End If;

              --订单库存点用数据处理
              If p_Result = v_Success And nvl(r_red_order.is_lock_inv_flag, v_false) = v_true Then
                v_Value := '执行订单行占用释放库存';
                Pkg_Pln_Inv_Occupy.p_Supply_Unoccupy_Stocks(p_Inventory_Id      => v_Fin_Inventory_Id, --仓库id
                                                            p_Item_Id           => r_Red_Order.Item_Id, --产品id
                                                            p_Occupy_Qty        => v_Order_Red_Match_Qty, --占用数量
                                                            p_Match_Pln_To_Wip  => v_Pln_Wip_Order_Match, --工单与订单完全匹配标志 y:完全匹配  n:非完全匹配
                                                            p_Action_Desc       => '中转红冲单执行', --单据操作描述 例：中转单据执行、中转红冲单执行
                                                            p_Entity_Id         => p_Entity_Id, --主体id
                                                            p_Origin_Type       => '计划订单', --来源类型
                                                            p_Origin_Head_Id    => r_Red_Order.Order_Head_Id, --来源头id
                                                            p_Origin_Number     => r_Red_Order.Order_Number, --来源头编码
                                                            p_Origin_Line_Id    => r_Red_Order.Order_Line_Id, --来源行id
                                                            p_Source_Order_Type => v_Order_Type_Name, --事务来源单据类型
                                                            p_Source_Head_Id    => v_Po_Head_Id, --事务来源头id
                                                            p_Source_Number     => v_Po_Order_Number, --事务来源头编码
                                                            p_Source_Line_Id    => p_Po_Line_Id, --事务来源行id
                                                            p_User_Code         => p_User_Code, --用户id
                                                            p_Allow_No_Occupy   => 'N',
                                                            p_Result            => v_Err_Num, --返回错误id
                                                            p_Err_Msg           => p_Result --返回错误信息
                                                            );
                If p_Result <> v_Success Then
                  Raise v_Base_Exception;
                End If;
              End If;
              --跟新工单入库数量
              Begin
                If p_Result = v_Success Then
                  v_Value := '更新工单入库数量 , 工单号:' || r_Wip_Red.Wip_Entity_Code;
                  Update t_Inv_Wip_In_Info Wii
                     Set Wii.Exec_Qty         = Nvl(Wii.Exec_Qty, 0) -
                                                v_Order_Red_Match_Qty,
                         Wii.Last_Update_Date = Sysdate
                   Where Wii.Wip_Entity_Id = r_Wip_Red.Wip_Entity_Id;

                  Update t_Inv_Wip_In_Info Wii
                     Set Wii.End_Flag = Decode(Sign(Wii.Produce_Qty -
                                                    Nvl(Wii.Exec_Qty, 0)),
                                               0,
                                               'Y',
                                               'N')
                   Where Wii.Wip_Entity_Id = r_Wip_Red.Wip_Entity_Id;
                End If;
              Exception
                When Others Then
                  v_Value := v_Value || '失败!' || Sqlerrm;
                  Raise v_Base_Exception;
              End;
              --更新工单与订单匹配入关系入库信息
              Update t_Pln_Wip_Order_Relation Wor
                 Set Wor.In_Inv_Qty       = Nvl(Wor.In_Inv_Qty, 0) -
                                            v_Order_Red_Match_Qty,
                     Wor.Last_Update_Date = Sysdate
               Where Wor.Entity_Id = p_Entity_Id
                 And Wor.Wip_Entity_Id = r_Wip_Red.Wip_Entity_Id
                 And Wor.Order_Detail_Id = r_Red_Order.Order_Detail_Id
                 And Wor.Order_Line_Id = r_Red_Order.Order_Line_Id
                 And Wor.Order_Head_Id = r_Red_Order.Order_Head_Id;

              --回写原单据明细行红冲数量(蓝单红冲数量)
              Update t_Inv_Po_Lines_Detail Pld
                 Set Pld.Canceled_Qty = Nvl(Pld.Canceled_Qty, 0) +
                                        v_Order_Red_Match_Qty
               Where Pld.Entity_Id = p_Entity_Id
                 And Pld.Po_Line_Id = v_Old_Po_Line_Id
                 And Pld.Wip_Entity_Id = r_Wip_Red.Wip_Entity_Id
                 And ((Pld.Order_Detail_Id = r_Red_Order.Order_Detail_Id And
                     Pld.Order_Line_Id = r_Red_Order.Order_Line_Id And
                     Pld.Order_Header_Id = r_Red_Order.Order_Head_Id And
                     v_Pln_Wip_Order_Match = v_True) Or
                     v_Pln_Wip_Order_Match = v_False);
              If Sql%Notfound Then
                v_Value := '中转单红冲失败，更新中转单蓝单明细行失败，工单单号：' ||
                            r_Wip_Red.Wip_Entity_Code || '，中转单蓝单行ID：' ||
                            To_Char(v_Old_Po_Line_Id) || '，订单明细行ID：' ||
                            To_Char(r_Wip_Red.Order_Detail_Id) || v_Nl || Sqlerrm;
                Raise v_Base_Exception;
              End If;
              --更新工单与订单中转入库关系表，只处理ERP手工单匹配
              v_Curr_Wip_Red_Qty := v_Curr_Wip_Red_Qty -
                                    v_Order_Red_Match_Qty;
              v_Tran_Quantity := v_Tran_Quantity - v_Order_Red_Match_Qty;
              Exit When v_Curr_Wip_Red_Qty = 0 Or v_Tran_Quantity = 0;
            End Loop; --红冲订单循环结束
          End If;

          --modi by lizhen 本次事务数据为0后，退出红冲匹配
          Exit When v_Tran_Quantity = 0;
        End Loop; --原工单明细循环结束
        --红冲中转单时，一行中转蓝单明细行红冲时存在剩余数量，则报异常
        If v_Tran_Quantity <> 0 Then
          v_Value := '中转单红冲失败，剩余【' || To_Char(v_Curr_Wip_Red_Qty) ||
                   '】数量无法正常匹配到订单，中转单蓝单行ID：' || To_Char(v_Old_Po_Line_Id);
          Raise v_Base_Exception;
        End If;
      End If;*/
    End If;
    --工单与订单新匹配模式下，匹配完订单后自动生成订单分配行。
    Begin
      If v_Pln_Wip_Order_Match = v_True And p_Result = v_Success Then
        For r_Order In (Select Pld.Entity_Id,
                               Pld.Order_Header_Id,
                               Pld.Order_Line_Id,
                               Pld.Item_Id,
                               Pld.Item_Code,
                               Sum(Decode(Pld.Executed_Flag, 'Y', Pld.Executed_Qty, Pld.Shipped_Qty)) Trans_Qty,
                               Decode((Select Iph.Old_Po_Id
                                        From t_Inv_Po_Headers Iph
                                       Where Iph.Po_Id = Pld.Po_Head_Id),
                                      Null,
                                      1,
                                      -1) Trans_Sign_Flag
                          From t_Inv_Po_Lines_Detail Pld
                         Where Pld.Entity_Id = p_Entity_Id
                           And Pld.Po_Line_Id = p_Po_Line_Id
                         Group By Pld.Entity_Id,
                                  Pld.Order_Header_Id,
                                  Pld.Order_Line_Id,
                                  Pld.Item_Id,
                                  Pld.Item_Code,
                                  Pld.Po_Head_Id
                        ) Loop
          Pkg_Pln_Shares.p_Auto_Create_Share(p_Pln_Order_Line_Id => r_Order.Order_Line_Id, --订单行ID
                                             p_Inventory_Id      => v_Fin_Inventory_Id, --仓库ID(财务仓)
                                             p_Trans_Sign_Flag   => r_Order.Trans_Sign_Flag, --生成发货计划方向，1：生成发货计划  -1：取消发货计划
                                             p_Trans_Share_Qty   => r_Order.Trans_Qty, --分配数量（只传正数）
                                             p_Entity_Id         => p_Entity_Id, --主体ID
                                             p_Pln_Wip_Ord_Match => v_Pln_Wip_Order_Match, --工单与订单新匹配模式
                                             p_User_Code         => p_User_Code,
                                             p_Result            => v_Value,
                                             p_Inv_Affirm_Flag   => 'N',
                                             p_Sub_Item_id       => r_Order.Item_Id);
          If v_Value <> v_Success Then
            Raise v_Base_Exception;
          End If;
        End Loop;
      End If;
   End;

    If p_Result <> v_Success Then
      Rollback;
    End If;
  Exception
    When v_Base_Exception Then
      Rollback;
      p_Result := v_Value || v_Nl || replace(p_Result, v_Success, '');
    When Others Then
      p_Result := v_Value || Sqlerrm;
      Rollback;
  End;

  --------------------------------------------------------------------------
  --Author: sushu  2016-07-11
  --Purpose:工单入库红冲单发货状态关闭时，更新原中转单明细行以及订单行、明细信息
  --------------------------------------------------------------------------
  Procedure p_update_wip_red(p_Po_Id     In Number,    --红冲单单头Id
                             p_Old_Po_Id In Number,    --红冲单对应的原单头Id
                             p_Result    Out Varchar2) Is --返回信息
  --中转单红冲单明细行数据
  Cursor c_Po_Lines_Detail Is
  Select * From t_inv_po_lines_detail d Where d.po_head_id = p_Po_Id;

  v_Count Number;  --计数
  v_Quantity Number;
  v_Value varchar2(2000);

  Begin
    p_Result := v_Success;
    Begin
      --更新原中转单明细行数据
      v_Value := '更新原中转单明细行失败，' || v_Nl || Sqlerrm;
      Update t_Inv_Po_Lines_Detail Od
         Set Od.Canceled_Qty = Od.Canceled_Qty -
                               Nvl((Select d.Billed_Qty
                                     From t_Inv_Po_Headers      h,
                                          t_Inv_Po_Lines        l,
                                          t_Inv_Po_Lines_Detail d
                                    Where d.Po_Head_Id = h.Po_Id
                                      And d.Po_Line_Id = l.Po_Line_Id
                                      And l.Po_Id = h.Po_Id
                                      And h.Po_Id = p_Po_Id
                                      And Od.Order_Header_Id =
                                          d.Order_Header_Id
                                      And Od.Order_Line_Id = d.Order_Line_Id
                                      And Od.Order_Detail_Id =
                                          d.Order_Detail_Id
                                      And Od.Wip_Entity_Id = d.Wip_Entity_Id
                                      And Od.Item_Id = d.Item_Id
                                      And Od.Po_Line_Id = l.Po_Line_Id_Old
                                      And Od.Po_Head_Id = h.Old_Po_Id),
                                   0)
       Where Od.Po_Head_Id = p_Old_Po_Id;
      --循环遍历中转单红冲单明细行，更新订单数据
      If p_Result = v_Success Then
        For r_Po_Lines_Detail In c_Po_Lines_Detail Loop
        --更新订单明细行数据
        v_Value := '更新订单明细行数据失败' || v_Nl || Sqlerrm;
        Update t_Pln_Order_Detail Pod
           Set Pod.Supply_Qty = Nvl(Pod.Supply_Qty, 0) +
                                Nvl(r_Po_Lines_Detail.Billed_Qty, 0)
         Where Pod.Order_Detail_Id = r_Po_Lines_Detail.Order_Detail_Id
           And Pod.Order_Head_Id = r_Po_Lines_Detail.Order_Header_Id
           And Pod.Order_Line_Id = r_Po_Lines_Detail.Order_Line_Id;
        --更新明细行COLSE_FLAG
        Update t_Pln_Order_Detail Pod
           Set Pod.Close_Flag = v_True
         Where Pod.Order_Detail_Id = r_Po_Lines_Detail.Order_Detail_Id
           And Pod.Order_Head_Id = r_Po_Lines_Detail.Order_Header_Id
           And Pod.Order_Line_Id = r_Po_Lines_Detail.Order_Line_Id
           And Pod.Can_Produce_Qty - Nvl(Pod.Supply_Qty, 0) -
               Nvl(Pod.Cancel_Qty, 0) = 0;
        --更新订单行
        v_Value := '更新订单行数据失败' || v_Nl || Sqlerrm;
        --判断当前套机行的商品是否套机
        Select Count(*)
          Into v_Count
          From t_Bd_Item_Assemblies Bia,
               --套件行表
               t_Bd_Item_Assemblies_Sub Ias,
               --套件头表
               t_Pln_Order_Line Pol
         Where Bia.Item_Assembly_Id = Ias.Item_Assembly_Id
           And Bia.Entity_Id = Ias.Entity_Id
           And Bia.Item_Id = Pol.Item_Id
           And Pol.Entity_Id = Bia.Entity_Id
           And Pol.Order_Line_Id = r_Po_Lines_Detail.Order_Line_Id
           And Trunc(Sysdate) Between Ias.Begin_Date And
               Trunc(Nvl(Ias.End_Date, Sysdate))
           And Trunc(Sysdate) Between Bia.Begin_Date And
               Trunc(Nvl(Bia.End_Date, Sysdate));
        --套机
        If v_Count > 0 Then
          Select Min(trunc(Sum(Nvl(Pod.Supply_Qty, 0)) /
                     Decode(Ias.Quantity, Null, 1, 0, 1, Ias.Quantity)))
            Into v_Quantity --入库行数量，根据订单明细行总数量匹配套
            From t_Pln_Order_Detail Pod,
                 --计划周订单明细表
                 t_Bd_Item_Assemblies Bia,
                 --套件行表
                 t_Bd_Item_Assemblies_Sub Ias --套件头表
           Where Pod.Item_Id = Ias.Item_Id
             And Bia.Item_Assembly_Id = Ias.Item_Assembly_Id
             And Bia.Entity_Id = Ias.Entity_Id
             And Pod.Order_Line_Id = r_Po_Lines_Detail.Order_Line_Id
             And Trunc(Sysdate) Between Ias.Begin_Date And
                 Nvl(Ias.End_Date, Sysdate)
             And Trunc(Sysdate) Between Bia.Begin_Date And
                 Nvl(Bia.End_Date, Sysdate)
           Group By Pod.Item_Id, Ias.Quantity; --按散件行商品和配套行数量来汇总(不能缺少)

        Else
          Select Sum(Nvl(Pod.Supply_Qty, 0))
            Into v_Quantity --入库数量
            From t_Pln_Order_Detail Pod --计划订单明细表
           Where Pod.Order_Detail_Id = r_Po_Lines_Detail.Order_Detail_Id
             And Pod.Order_Line_Id = r_Po_Lines_Detail.Order_Line_Id
             And Pod.Order_Head_Id = r_Po_Lines_Detail.Order_Header_Id;
        End If;

        If v_Quantity > 0 Then
          --回写订单行入库数量
          Update t_Pln_Order_Line Pol
             Set Pol.Supply_Qty = v_Quantity
           Where Pol.Order_Head_Id = r_Po_Lines_Detail.Order_Header_Id
             And Pol.Order_Line_Id = r_Po_Lines_Detail.Order_Line_Id;
        End If;

        --更新工单入库数量
        v_Value := '更新工单数据失败' || v_Nl || Sqlerrm;
        Update t_Inv_Wip_In_Info Wii
           Set Wii.Exec_Qty         = Nvl(Wii.Exec_Qty, 0) +
                                      nvl(r_Po_Lines_Detail.Billed_Qty,0),
               Wii.Last_Update_Date = Sysdate
         Where Wii.Wip_Entity_Id = r_Po_Lines_Detail.Wip_Entity_Id;

        Update t_Inv_Wip_In_Info Wii
           Set Wii.End_Flag = Decode(Sign(Wii.Produce_Qty -
                                          Nvl(Wii.Exec_Qty, 0)),
                                     0,
                                     'Y',
                                     'N')
         Where Wii.Wip_Entity_Id = r_Po_Lines_Detail.Wip_Entity_Id;


         --更新工单与订单匹配入关系入库信息
         v_Value := '更新工单与订单匹配数据失败' || v_Nl || Sqlerrm;
         Update t_Pln_Wip_Order_Relation Wor
            Set Wor.In_Inv_Qty       = Nvl(Wor.In_Inv_Qty, 0) +
                                       nvl(r_Po_Lines_Detail.Billed_Qty,0),
                Wor.Last_Update_Date = Sysdate
          Where Wor.Entity_Id = r_Po_Lines_Detail.Entity_Id
            And Wor.Wip_Entity_Id = r_Po_Lines_Detail.Wip_Entity_Id
            And Wor.Order_Detail_Id = r_Po_Lines_Detail.Order_Detail_Id
            And Wor.Order_Line_Id = r_Po_Lines_Detail.Order_Line_Id
            And Wor.Order_Head_Id = r_Po_Lines_Detail.Order_Header_Id;

        End Loop;
      End If;
    Exception
      When Others Then
        Raise v_Base_Exception;
    End;
  Exception
    When v_Base_Exception Then
      p_Result := v_Value;
      Rollback;
  End;

End;
/

