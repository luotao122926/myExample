create view V_BD_USER_BUDGET_PRIV as
select distinct dpb.user_id,
       uu.account user_code,
       uu.name user_name,
       dbf.data_flow_id, --预算结构ID
       dbf.data_flow_name, --预算结构名称
       dbf.budget_type, --预算类型
       dpb.entity_id
  from t_bd_datapriv_budget dpb, t_pol_budget_data_flow dbf, up_org_user uu
 where dpb.data_flow_id = dbf.data_flow_id
   and dpb.user_id = uu.user_id
   and dpb.active_flag = 'Y'
/

