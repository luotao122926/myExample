create Package Body PKG_SO_REPORT Is

-----------------------------------------------------------------------------
  --  冻结上一天的销售明细                                                  --
  -----------------------------------------------------------------------------
  PROCEDURE P_DAILY_FREEZE(
     IN_ENTITY_ID      IN   NUMBER    --主体ID
    ,ID_CURRENT_DATE   IN   DATE      --当前日期
    ,IS_USER_ACCOUNT   IN   VARCHAR2  --用户账号
    ,OS_MESSAGE        OUT  VARCHAR2  --成功则返回“OK”，否则返回出错信息
  ) IS
   S_USER_ID  VARCHAR2(100);
   D_CUR_DATE DATE;
   S_CURRENT_YEAR VARCHAR2(50);
   S_CURRENT_MONTH VARCHAR2(50);
   S_CURRENT_DAY VARCHAR2(50);

   D_YEARFIRST_DATE DATE;
   D_YEARLAST_DATE  DATE;

  BEGIN
    OS_MESSAGE := 'OK';
    S_USER_ID := PKG_BD.F_GET_PARAMETER_VALUE('SL_AUTO_USER',IN_ENTITY_ID);
    D_CUR_DATE          := trunc(ID_CURRENT_DATE)-1;
    S_CURRENT_YEAR      := TO_CHAR(D_CUR_DATE,'YYYY');
    S_CURRENT_MONTH     := TO_CHAR(D_CUR_DATE,'YYYY-MM');
    S_CURRENT_DAY       := TO_CHAR(D_CUR_DATE,'YYYY-MM-DD');

    D_YEARFIRST_DATE    :=to_date(S_CURRENT_YEAR||'-01-01', 'yyyy-mm-dd');
    D_YEARLAST_DATE     :=to_date(S_CURRENT_YEAR||'-12-31', 'yyyy-mm-dd');

    DELETE FROM T_SO_DAILYLIST WHERE ENTITY_ID = IN_ENTITY_ID AND FREEZE_DATE=D_CUR_DATE; --删除之前冻结数据

    INSERT INTO T_SO_DAILYLIST(
         SO_DAILYLIST_ID,
         FREEZE_DATE,
         FREEZE_DATE_STR,
         ENTITY_ID,
         SALES_CENTER_ID,
         SALES_CENTER_CODE,
         SALES_CENTER_NAME,
         CUSTOMER_ID,
         CUSTOMER_CODE,
         CUSTOMER_NAME,
         ITEM_ID,
         ITEM_CODE,
         ITEM_NAME,
         DEFAULTUNIT,
         DEFAULTUNIT_NAME,
         SALES_MAIN_TYPE,
         SALES_MAIN_TYPE_NAME,
         SALES_SUB_TYPE,
         SALES_SUB_TYPE_NAME,
         BRAND,
         BRAND_NAME,
         FREQUENCYTYPE,
         FREQUENCYTYPE_NAME,
         PRODUCTFORM,
         PRODUCTFORM_NAME,
         ENERGYEFFRATIING,
         ANNUAL_SALES,
         ANNUAL_SALES_SET,
         ANNUAL_SALES_LIST,
         ANNUAL_SALES_SETTLE,
         MONTHLY_SALES,
         MONTHLY_SALES_SET,
         MONTHLY_SALES_LIST,
         MONTHLY_SALES_SETTLE,
         DAILY_SALES,
         DAILY_SALES_SET,
         DAILY_SALES_LIST,
         DAILY_SALES_SETTLE,
         -- 增加税码字段  jiangwei29 2019-5-14
         TAX_CODE,
         CREATED_BY,
         CREATION_DATE,
         LAST_UPDATED_BY,
         LAST_UPDATE_DATE
      )select
         S_SO_DAILYLIST.NEXTVAL,
         D_CUR_DATE,
         S_CURRENT_DAY,
         IN_ENTITY_ID,
         SALES_CENTER_ID,
         SALES_CENTER_CODE,
         SALES_CENTER_NAME,
         CUSTOMER_ID,
         CUSTOMER_CODE,
         CUSTOMER_NAME,
         ITEM_ID,
         ITEM_CODE,
         ITEM_NAME,
         DEFAULTUNIT,
         DEFAULTUNIT_NAME,
         SALES_MAIN_TYPE,
         SALES_MAIN_TYPE_NAME,
         SALES_SUB_TYPE,
         (case when t.ITEM_ID<0 then t.ITEM_NAME else t.SALES_SUB_TYPE_NAME end) SALES_SUB_TYPE_NAME,
         BRAND,
         (case when t.ITEM_ID<0 then t.ITEM_NAME else t.BRAND_NAME end) BRAND_NAME,
         FREQUENCYTYPE,
         FREQUENCYTYPE_NAME,
         PRODUCTFORM,
         (case when t.ITEM_ID<0 then t.ITEM_NAME else t.PRODUCTFORM_NAME end) PRODUCTFORM_NAME,
         (case when t.ENERGYEFFRATIING is not null and length(t.ENERGYEFFRATIING)>2 then substr(t.ENERGYEFFRATIING, 0, 2 )  else   t.ENERGYEFFRATIING   end) ENERGYEFFRATIING,
         ANNUAL_SALES,
         ANNUAL_SALES_SET,
         ANNUAL_SALES_LIST,
         ANNUAL_SALES_SETTLE,
         MONTHLY_SALES,
         MONTHLY_SALES_SET,
         MONTHLY_SALES_LIST,
         MONTHLY_SALES_SETTLE,
         DAILY_SALES,
         DAILY_SALES_SET,
         DAILY_SALES_LIST,
         DAILY_SALES_SETTLE,
         -- 增加税码字段  jiangwei29 2019-5-14
         tax_code,
         S_USER_ID,
         sysdate,
         S_USER_ID,
         sysdate
      from (
             select
      h.sales_center_id,
      h.sales_center_code,
      h.sales_center_name,
      h.customer_id,
      h.customer_code,
      h.customer_name,
      l.item_id,
      i.item_code,
      i.item_name,
      i.DEFAULTUNIT,
      u.code_name DEFAULTUNIT_NAME,
      i.sales_main_type,
      c.class_name SALES_MAIN_TYPE_NAME,
      i.sales_sub_type,
      sc.class_name SALES_SUB_TYPE_NAME,
      i.brand,
      br.code_name BRAND_NAME,
      i.frequencytype,
      fr.code_name FREQUENCYTYPE_NAME,
      i.productform,
      pr.code_name PRODUCTFORM_NAME,
      i.ENERGYEFFRATIING,

      sum(case when  to_char(h.so_date,'yyyy')=S_CURRENT_YEAR and l.ITEM_ID>0   then  e.applied_plus_minus_flag*l.item_qty  end) ANNUAL_SALES,
      sum(case when  to_char(h.so_date,'yyyy')=S_CURRENT_YEAR and i.productform in('SET_PRODUCT','WHOLE_PRODUCT')  then  e.applied_plus_minus_flag*l.item_qty
         when  to_char(h.so_date,'yyyy')=S_CURRENT_YEAR  and i.productform in('INDOOR_PRODUCT','OUTDOOR_PRODUCT')  then  (e.applied_plus_minus_flag*l.item_qty)/2
      end) ANNUAL_SALES_SET,
      sum(case when  to_char(h.so_date,'yyyy')=S_CURRENT_YEAR then  e.applied_plus_minus_flag*l.item_list_amount  end) ANNUAL_SALES_LIST,
      sum(case when  to_char(h.so_date,'yyyy')=S_CURRENT_YEAR then  e.applied_plus_minus_flag*l.ITEM_SETTLE_AMOUNT  end) ANNUAL_SALES_SETTLE,

      sum(case when  to_char(h.so_date,'yyyy-MM')=S_CURRENT_MONTH and l.ITEM_ID>0 then  e.applied_plus_minus_flag*l.item_qty  end) MONTHLY_SALES,
      sum(case when  to_char(h.so_date,'yyyy-MM')=S_CURRENT_MONTH and i.productform in('SET_PRODUCT','WHOLE_PRODUCT')  then  e.applied_plus_minus_flag*l.item_qty
         when  to_char(h.so_date,'yyyy-MM')=S_CURRENT_MONTH and i.productform in('INDOOR_PRODUCT','OUTDOOR_PRODUCT')  then  (e.applied_plus_minus_flag*l.item_qty)/2
      end) MONTHLY_SALES_SET,
      sum(case when  to_char(h.so_date,'yyyy-MM')=S_CURRENT_MONTH then  e.applied_plus_minus_flag*l.item_list_amount  end) MONTHLY_SALES_LIST,
      sum(case when  to_char(h.so_date,'yyyy-MM')=S_CURRENT_MONTH then  e.applied_plus_minus_flag*l.ITEM_SETTLE_AMOUNT  end) MONTHLY_SALES_SETTLE,

      sum(case when  to_char(h.so_date,'yyyy-MM-DD')=S_CURRENT_DAY and l.ITEM_ID>0 then  e.applied_plus_minus_flag*l.item_qty  end) DAILY_SALES,
      sum(case when  to_char(h.so_date,'yyyy-MM-DD')=S_CURRENT_DAY and i.productform in('SET_PRODUCT','WHOLE_PRODUCT')  then  e.applied_plus_minus_flag*l.item_qty
         when  to_char(h.so_date,'yyyy-MM-DD')=S_CURRENT_DAY and i.productform in('INDOOR_PRODUCT','OUTDOOR_PRODUCT')  then  (e.applied_plus_minus_flag*l.item_qty)/2
      end) DAILY_SALES_SET,
      sum(case when  to_char(h.so_date,'yyyy-MM-DD')=S_CURRENT_DAY then  e.applied_plus_minus_flag*l.item_list_amount  end) DAILY_SALES_LIST,
      sum(case when  to_char(h.so_date,'yyyy-MM-DD')=S_CURRENT_DAY then  e.applied_plus_minus_flag*l.ITEM_SETTLE_AMOUNT  end) DAILY_SALES_SETTLE,
      -- 增加税码字段  jiangwei29 2019-5-14
      l.tax_code

      from t_so_header h
      inner join  t_so_line l on l.so_header_id = h.so_header_id
      inner join  t_bd_item i on i.item_id = l.item_id
      left join  (select code_value,code_name from v_up_codelist where codetype ='BD_UOM' ) u on u.code_value = i.DEFAULTUNIT
      left join  (select class_code,class_name from t_bd_item_class where entity_id =IN_ENTITY_ID ) c on c.class_code = i.sales_main_type
      left join  (select class_code,class_name from t_bd_item_class where entity_id =IN_ENTITY_ID ) sc on sc.class_code = i.sales_sub_type
      left join  (select code_value,code_name from v_up_codelist where codetype ='GE_MPL_BRAND' ) br on br.code_value = i.brand
      left join  (select code_value,code_name from v_up_codelist where codetype ='GE_MPL_FREQUENCY_TYPE' ) fr on fr.code_value = i.frequencytype
      left join  (select code_value,code_name from v_up_codelist where codetype ='GE_MPL_PRODUCT_FORM' ) pr on pr.code_value = i.productform
      left join  (select bill_type_id,BILL_TYPE_NAME,APPLIED_PLUS_MINUS_FLAG,SRC_TYPE_CODE from V_SO_BILL_TYPE_EXTEND where entity_id =IN_ENTITY_ID) e on h.bill_type_id = e.bill_type_id
    where  e.SRC_TYPE_CODE != '1009'--扣率折让
       AND e.SRC_TYPE_CODE != '1010'
       and h.so_date between  D_YEARFIRST_DATE  and  D_CUR_DATE
       and h.entity_id =IN_ENTITY_ID
    group by h.sales_center_id,
      h.sales_center_code,
      h.sales_center_name,
      h.customer_id,
      h.customer_code,
      h.customer_name,
      l.item_id,
      l.tax_code, -- 增加税码字段
      i.item_code,
      i.item_name,
      i.DEFAULTUNIT,
      u.code_name ,
      i.sales_main_type,
      c.class_name ,
      i.sales_sub_type,
      sc.class_name ,
      i.brand,
      br.code_name ,
      i.frequencytype,
      fr.code_name ,
      i.productform,
      pr.code_name ,
      i.ENERGYEFFRATIING
      order by
      h.sales_center_code,
      h.customer_code,
      i.item_code
      ) t;
      --提交
      COMMIT;
  EXCEPTION
     WHEN NO_DATA_FOUND THEN
       NULL;
     WHEN OTHERS THEN
       OS_MESSAGE := SUBSTR(SQLERRM(SQLCODE), 1, 256);
       ROLLBACK;
  END P_DAILY_FREEZE;

END PKG_SO_REPORT;
/

