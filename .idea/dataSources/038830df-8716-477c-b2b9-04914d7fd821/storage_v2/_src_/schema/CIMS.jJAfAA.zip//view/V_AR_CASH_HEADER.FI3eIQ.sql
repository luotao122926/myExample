create view V_AR_CASH_HEADER as
SELECT cash.cash_receipt_id cash_receipt_id,                   --收款头表ID
          cash.cash_receipt_code cash_receipt_code,             --到款单据编号
          cash.receipt_method_id receipt_method_id,               --收款方法ID
                                                   NULL pull_order_number,

          --拉单号
          methods.receipt_method_name receipt_method_name,      --收款方法名称
          cash.currency_code currency_code,                             --币种
                                           NULL exchange_rate,          --汇率
          cash.customer_id customer_id,                               --客户ID
                                       cash.customer_code customer_code,

          --客户编码
          cash.customer_name customer_name,                         --客户名称
          cash.gtms_receipt_code receipt_number,                  --收款单据号
          cash.cash_receipt_date receipt_date,                      --单据日期
                                              cash.gl_date gl_date, --总账日期
          cash.gl_date post_date,             --过账日期----------------------
                                 cash.sales_center_id department_id,

          --部门ID（营销中心ID）
          org.code sales_center_code,                               --中心编码
                                     org.NAME sales_center_name,    --中心名称
          NULL employee_id,                                           --业务员
                           NULL set_of_books_id,
                                                --财务帐套ID---------------------
          NULL sales_year_id,
                             --销售年度-------------------------
          NULL sales_year_name,              --销售年度名称-------------------
                               NULL discount_type_id,
                                                     --折扣类型----------------------
          NULL discount_name,
                             --折扣类型名称---------------------
                             cash.receipt_status_id status,           --状态ID
          status.code_name status_name,
                                       --状态名称
                                       cash.due_date due_date,      --到期日期
          cash.amount amount,                                       --到款金额
                             NULL cancel_amount,
                                                --红冲金额-------------------------
                                                cash.cash_code cash_code,
                                                                      --票据号
          cash.cash_date cash_date,                                 --票据日期
                                   cash.remaek digest,          --摘要（备注）
          DECODE (cash.print_num, 0, 'N', 'Y') print_flag,
                                                          --打印标志
          NULL print_date,             --打印时间-----------------------------
                          cash.print_num print_number,              --打印次数
          parents.cash_receipt_id parent_id,                      --冲销原单ID
                                            cash.remaek comments,       --备注
          DECODE (cash.receipt_status_id, 2, 'Y', 'N') delete_flag, --删除标志
          NULL finance_main_entity_id,                              --主主体ID
                                      cash.entity_id finance_entity_id,

          --主体ID
          cash.created_by created_by,                                 --创建人
                                     cash.creation_date creation_date,

          --创建时间
          NULL last_updated_by, NULL last_update_date,
          cash.writeoff_receipt_code parent_code,                 --冲销原单号
                                                 NULL bank_account,  ---------
          cash.customer_id vendor_id, cash.customer_code vendor_code,
          cash.customer_name vendor_name, NULL ap_trx_code, NULL order_number,
          NULL order_header_id,
            DECODE (cash.receipt_status_id, 1, 1, 0)
          * cash.amount not_confirm_amount,                       --未确认金额
            DECODE (cash.receipt_status_id, 1, 0, 1)
          * cash.amount confirm_amount,                           --已确认金额
          DECODE (cash.receipt_status_id, 2, 1, 0) * cash.amount can_amount,

          --已取消金额
          NULL approve_amount,                                           -----
                              NULL patch_amount,     --补息金额---------------
                                                NULL paste_amount,

          --贴息金额---------------
          NULL oicheck_flag,                         --勾兑标志---------------
                            NULL oicheck_error,       --勾兑错误号------------
                                               NULL oicheck_mesg,

          --勾兑详细信息-----------
          cash.into_erp_status intooiflag,                       --引入ERP状态
                                          cash.into_erp_date intooidate,

          --引入ERP时间
          cash.into_erp_error intooierror,                       --引入ERP错误
                                          cash.creation_date user_date,
          DECODE (cash.receipt_status_id, 1, 'N', 2, 'N', 'Y') sign_flag,

          --签收标记
          NULL sign_by,                                               --签收人
                       NULL sign_date,                              --签收日期
                                      NULL control_method,          --控制方式
          cash.attribute3 biz_source_type,                          --来源类型
                                          --2015.12.4.tianmzh 修改来源编号、增加关联交易号
                                          cash.attribute4 biz_source_number,
                                                                    --来源编号
          cash.attribute9 related_transaction_number,             --关联交易号
                                                     NULL material_brand,
                                                                        --品牌
          cash.sales_main_type_name material_category,
                                                      --营销大类
          cash.line_remark,  --行备注
          NULL small_category,                                      --营销小类
          (SELECT l.code_name
             FROM up_codelist l
            WHERE l.code_value = methods.receipt_type
              AND codetype = 'ar_method_receipt') receipt_method_type,

          --收款方法类型
          cash.reviewed_date first_affirm_date,
          cash.gtms_sign_time storage_in_date,                       --入库时间
          --转款单号
          turn.cash_turnfee_code,
          --来源单号
          cash.attribute4 source_code
     FROM v_ar_cash_receipt_header_lines cash,
          t_ar_cash_receipt_headers parents,
          t_ar_receipt_methods methods,
          up_org_unit org,
          up_codelist status,
          t_ar_cash_turnfee_header turn
    WHERE cash.receipt_method_id = methods.receipt_method_id
      AND cash.sales_center_id = org.unit_id(+)
      AND cash.receipt_status_id = status.code_value(+)
      AND status.codetype = 'ar_reciept_status'
      AND cash.writeoff_receipt_code = parents.cash_receipt_code(+)
      AND cash.cash_turnfee_id = turn.cash_turnfee_id(+)
/

comment on table V_AR_CASH_HEADER is '收款明细视图（客户到款明细报表）'
/

comment on column V_AR_CASH_HEADER.CASH_RECEIPT_ID is '收款单据ID'
/

comment on column V_AR_CASH_HEADER.CASH_RECEIPT_CODE is '收款单据号'
/

comment on column V_AR_CASH_HEADER.RECEIPT_METHOD_ID is '收款方法ID'
/

comment on column V_AR_CASH_HEADER.PULL_ORDER_NUMBER is '拉单号（NULL）'
/

comment on column V_AR_CASH_HEADER.RECEIPT_METHOD_NAME is '拉单号'
/

comment on column V_AR_CASH_HEADER.CURRENCY_CODE is '币种'
/

comment on column V_AR_CASH_HEADER.EXCHANGE_RATE is '汇率（NULL）'
/

comment on column V_AR_CASH_HEADER.CUSTOMER_ID is '客户ID'
/

comment on column V_AR_CASH_HEADER.CUSTOMER_CODE is '客户编码'
/

comment on column V_AR_CASH_HEADER.CUSTOMER_NAME is '客户名称'
/

comment on column V_AR_CASH_HEADER.RECEIPT_NUMBER is '收款单据号'
/

comment on column V_AR_CASH_HEADER.RECEIPT_DATE is '单据日期'
/

comment on column V_AR_CASH_HEADER.GL_DATE is '总账日期'
/

comment on column V_AR_CASH_HEADER.POST_DATE is '过账日期'
/

comment on column V_AR_CASH_HEADER.DEPARTMENT_ID is '部门ID（营销中心ID）'
/

comment on column V_AR_CASH_HEADER.SALES_CENTER_CODE is '中心编码'
/

comment on column V_AR_CASH_HEADER.SALES_CENTER_NAME is '中心名称'
/

comment on column V_AR_CASH_HEADER.EMPLOYEE_ID is '业务员（NULL）'
/

comment on column V_AR_CASH_HEADER.SET_OF_BOOKS_ID is '财务账套ID（NULL）'
/

comment on column V_AR_CASH_HEADER.SALES_YEAR_ID is '销售年度id（NULL）'
/

comment on column V_AR_CASH_HEADER.SALES_YEAR_NAME is '销售年度名称（NULL）'
/

comment on column V_AR_CASH_HEADER.DISCOUNT_TYPE_ID is '折扣类型（NULL）'
/

comment on column V_AR_CASH_HEADER.DISCOUNT_NAME is '折扣类型名称（NULL）'
/

comment on column V_AR_CASH_HEADER.STATUS is '状态ID'
/

comment on column V_AR_CASH_HEADER.STATUS_NAME is '状态名称'
/

comment on column V_AR_CASH_HEADER.DUE_DATE is '票据到期日期'
/

comment on column V_AR_CASH_HEADER.AMOUNT is '金额'
/

comment on column V_AR_CASH_HEADER.CANCEL_AMOUNT is '红冲金额（NULL）'
/

comment on column V_AR_CASH_HEADER.CASH_CODE is '票据号'
/

comment on column V_AR_CASH_HEADER.CASH_DATE is '出票日期'
/

comment on column V_AR_CASH_HEADER.DIGEST is '摘要（备注）'
/

comment on column V_AR_CASH_HEADER.PRINT_FLAG is '打印标志'
/

comment on column V_AR_CASH_HEADER.PRINT_DATE is '打印时间'
/

comment on column V_AR_CASH_HEADER.PRINT_NUMBER is '打印次数'
/

comment on column V_AR_CASH_HEADER.PARENT_ID is '冲销原单ID'
/

comment on column V_AR_CASH_HEADER.COMMENTS is '备注'
/

comment on column V_AR_CASH_HEADER.DELETE_FLAG is '删除标志'
/

comment on column V_AR_CASH_HEADER.FINANCE_MAIN_ENTITY_ID is '主主体ID（NULL）'
/

comment on column V_AR_CASH_HEADER.FINANCE_ENTITY_ID is '主体ID'
/

comment on column V_AR_CASH_HEADER.CREATED_BY is '制单人'
/

comment on column V_AR_CASH_HEADER.CREATION_DATE is '制单时间'
/

comment on column V_AR_CASH_HEADER.LAST_UPDATED_BY is '（NULL）'
/

comment on column V_AR_CASH_HEADER.LAST_UPDATE_DATE is '（NULL）'
/

comment on column V_AR_CASH_HEADER.PARENT_CODE is '冲销原单号'
/

comment on column V_AR_CASH_HEADER.BANK_ACCOUNT is '（NULL）'
/

comment on column V_AR_CASH_HEADER.VENDOR_ID is '客户ID'
/

comment on column V_AR_CASH_HEADER.VENDOR_CODE is '客户编码'
/

comment on column V_AR_CASH_HEADER.VENDOR_NAME is '客户名称'
/

comment on column V_AR_CASH_HEADER.AP_TRX_CODE is '（NULL）'
/

comment on column V_AR_CASH_HEADER.ORDER_NUMBER is '（NULL）'
/

comment on column V_AR_CASH_HEADER.ORDER_HEADER_ID is '（NULL）'
/

comment on column V_AR_CASH_HEADER.NOT_CONFIRM_AMOUNT is '未确认金额'
/

comment on column V_AR_CASH_HEADER.CONFIRM_AMOUNT is '已确认金额'
/

comment on column V_AR_CASH_HEADER.CAN_AMOUNT is '已取消金额'
/

comment on column V_AR_CASH_HEADER.APPROVE_AMOUNT is '（NULL）'
/

comment on column V_AR_CASH_HEADER.PATCH_AMOUNT is '补息金额（NULL）'
/

comment on column V_AR_CASH_HEADER.PASTE_AMOUNT is '贴息金额（NULL）'
/

comment on column V_AR_CASH_HEADER.OICHECK_FLAG is '勾兑标志（NULL）'
/

comment on column V_AR_CASH_HEADER.OICHECK_ERROR is '勾兑错误号（NULL）'
/

comment on column V_AR_CASH_HEADER.OICHECK_MESG is '勾兑详细信息（NULL）'
/

comment on column V_AR_CASH_HEADER.INTOOIFLAG is '引入ERP标志'
/

comment on column V_AR_CASH_HEADER.INTOOIDATE is '引入ERP时间'
/

comment on column V_AR_CASH_HEADER.INTOOIERROR is '引入ERP错误'
/

comment on column V_AR_CASH_HEADER.USER_DATE is '创建日期'
/

comment on column V_AR_CASH_HEADER.SIGN_FLAG is '签收标记'
/

comment on column V_AR_CASH_HEADER.SIGN_BY is '签收人'
/

comment on column V_AR_CASH_HEADER.SIGN_DATE is '签收日期'
/

comment on column V_AR_CASH_HEADER.CONTROL_METHOD is '控制方式'
/

comment on column V_AR_CASH_HEADER.BIZ_SOURCE_TYPE is '来源类型'
/

comment on column V_AR_CASH_HEADER.BIZ_SOURCE_NUMBER is '来源编号'
/

comment on column V_AR_CASH_HEADER.MATERIAL_BRAND is '品牌'
/

comment on column V_AR_CASH_HEADER.MATERIAL_CATEGORY is '营销大类'
/

comment on column V_AR_CASH_HEADER.LINE_REMARK is '行备注'
/

comment on column V_AR_CASH_HEADER.SMALL_CATEGORY is '营销小类'
/

comment on column V_AR_CASH_HEADER.RECEIPT_METHOD_TYPE is '收款方法类型'
/

comment on column V_AR_CASH_HEADER.FIRST_AFFIRM_DATE is '确认时间'
/

comment on column V_AR_CASH_HEADER.STORAGE_IN_DATE is '入库时间'
/

