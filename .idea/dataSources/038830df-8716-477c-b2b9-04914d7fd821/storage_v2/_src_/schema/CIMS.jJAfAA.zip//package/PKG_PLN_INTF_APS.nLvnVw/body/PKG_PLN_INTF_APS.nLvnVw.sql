create Package Body Pkg_Pln_Intf_Aps Is

  v_Nl    Constant Varchar2(2) := Chr(13) || Chr(10); --换行
  v_True  Constant Varchar2(2) := 'Y';
  v_False Constant Varchar2(2) := 'N';
  --V_RESULT         CONSTANT NUMBER := 0; --成功返回
  v_Success Constant Varchar2(10) := 'SUCCESS';

  v_Entity_Type    Constant Varchar2(2) := 'BU';
  v_Sales_Cen_Type Constant Varchar2(2) := 'SC';
  v_Base_Exception Exception; --自定义异常
       
  -----------------------------------------------------------------------------
  -- AUTHOR  : Nicro.Li
  -- CREATED : 2016-04-09
  -- PURPOSE : 根据产品、组织ID获取APS剩余产能
  -----------------------------------------------------------------------------
  Function f_Get_Item_Capacity_Qty(p_Organization_Id In Number, ----主体ID
                                   p_Item_Code       In Varchar2 --产品编码
                                   ) Return Number Is
    v_Sql               Varchar2(4000);
    v_Item_Capacity_Qty Number;
    V_CAPACITY_MODEL    Varchar2(50);
    V_ENTITY_ID         NUMBER;
    v_Noship_Qty        number;
  Begin
    --获取主体产能可视模式
    BEGIN
      --根据组织ID，获取其中一个主体ID（组织ID对应的主体都属于同一种产能模式）
      SELECT O.ENTITY_ID
        INTO V_ENTITY_ID
        FROM T_INV_ORGANIZATION O
       WHERE O.ORGANIZATION_ID = p_Organization_Id
         AND ROWNUM = 1;
      V_CAPACITY_MODEL := PKG_BD.F_GET_PARAMETER_VALUE('PLN_CAPACITY_MODEL',
                                                       V_ENTITY_ID);
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;
    if nvl(V_CAPACITY_MODEL,'APS') = 'APS-CIMS' then
      --获取月度剩余产能
      SELECT C.CAPACITY_QTY
      into v_Item_Capacity_Qty
        FROM T_PLN_MONTH_REMAIN_CAPACIT C
       WHERE C.MRP_ORG_ID = p_Organization_Id
         AND C.ITEM_CODE = p_Item_Code;
      --获取待结转T+3数量
      select Pkg_Pln_Pub.f_Get_Lgorder_Noship_Qty(p_Entity_Id         => -1,
                                                  p_Item_Id           => -1,
                                                  p_Order_Submit_Type => '_',
                                                  p_User_Code         => null,
                                                  IN_MRP_ORG_ID       => p_Organization_Id,
                                                  IN_ITEM_CODE        => p_Item_Code)
        into v_Noship_Qty
        from dual;
      v_Item_Capacity_Qty := nvl(v_Item_Capacity_Qty,0) - nvl(v_Noship_Qty,0);
    else
      Select Nvl(p.Capacity_Qty, 0)
        Into v_Item_Capacity_Qty
        From Aps_Pre_Fg_Avl_v p
       Where p.Organization_Id = p_Organization_Id
         And p.Item_Code = p_Item_Code;
    end if;
    Return v_Item_Capacity_Qty;
  Exception
    When Others Then
      Return 0;
  End;
  
  -----------------------------------------------------------------------------
  -- AUTHOR  : Nicro.Li
  -- CREATED : 2016-04-09
  -- PURPOSE : 根据产品、组织ID获取APS剩余产能
  -----------------------------------------------------------------------------
  Procedure p_Import_Aps_Capacity(p_Batch_Id In Number,
                                  p_Result   Out Varchar2) Is                            
  Begin
    p_Result := v_Success;
    --开始写入APS产能可视处理接口表
    Begin
      Insert Into Aps_Pre_Mon_Order_Iface
        (Batch_Id,
         Business_Group,
         Organization_Id,
         Order_Number,
         Order_Line_Number,
         Order_Line_Id,
         Item_Code,
         Quantity,
         Customer_Code,
         Last_Update_Date,
         Creation_Date)
        Select Ocs.Batch_Id,
               Ocs.Business_Group,
               Ocs.Organization_Id,
               Ocs.Order_Number,
               Ocs.Order_Line_Number,
               Ocs.Order_Line_Id,
               Ocs.Item_Code,
               Ocs.Quantity,
               Ocs.Customer_Code,
               Sysdate,
               Sysdate
          From Intf_Pln_Order_Capacity_Send Ocs
         Where Ocs.Batch_Id = p_Batch_Id;
    Exception
      When Others Then
        p_Result := '写入APS系统APS产能可视接口失败！' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;
  
    --更新接口引入成功标志
    Update Intf_Pln_Order_Capacity_Send Ocs
       Set Ocs.Import_Status = 'Y'
     Where Ocs.Batch_Id = p_Batch_Id;
  Exception
    When v_Base_Exception Then
      Rollback;
      p_Result := '引入APS产能可视接口失败(p_Import_Aps_Capacity)！' || v_Nl || p_Result;
    When Others Then
      Rollback;
      p_Result := '引入APS产能可视接口失败(p_Import_Aps_Capacity)！' || v_Nl || Sqlerrm;
  End;
  
  -----------------------------------------------------------------------------
  -- AUTHOR  : Nicro.Li
  -- CREATED : 2016-04-09
  -- PURPOSE : 根据产品、组织ID获取APS剩余产能
  -----------------------------------------------------------------------------
  Procedure p_Lgorder_Aps_Capacity_Send(p_Lg_Order_Head_Id      In Number, --提货订单头ID
                                        p_Cancel_Flag           In Varchar2, --是否取消订单  N:正常引入  Y：取消提货订单
                                        p_User_Code             In Varchar2,
                                        p_Result                Out Varchar2,
                                        p_Batch_Id              Out Number,    --返回批次ID
                                        p_Entity_Code           Out Varchar2,   --返回主体编码
                                        p_Close_Line_Flag  In Varchar2 Default 'N' --是否关闭订单行 --add by lizhen 2016-06-07
                                        ) Is
    r_Lg_Order_Head t_Pln_Lg_Order_Head%Rowtype;
    r_Order_Type    t_Pln_Order_Type%Rowtype;
    v_Batch_Id                  Number;
    v_Organization_Id           Number;
    v_Entity_Code               Varchar2(32);
    v_Index                     Number;
    v_Item_Usable_Qty           Number;
    v_Import_Aps_Capacity_Qty   Number;
    v_Amount                    Number;
    v_Discount_Amount           Number;
    v_Count                     Number;
    v_Action_Type               Number;
    v_Sales_Main_Type  t_Bd_Item.Sales_Main_Type%Type;
    v_Chk_Import_Flag           Varchar2(3) := 'Y'; --是否需要引入APS接口
    v_Current_Period_Begin_Date Date;
    v_Current_Period_End_Date   Date;
    v_Pln_Order_Submit_Date     Date;
    v_Err_Msg                   Varchar2(4000);
    v_Request_Id                Number;
    v_Pln_Of_Time_Month         Number;
    v_Pln_Line_Supply_Qty       Number;
    v_Meet_An_Order_Qty         Number;
    v_Price_Apply_Use_Discount t_bd_param_list.default_value%type := 'N'; --20170710 hejy3 价格批文开单使用折扣
  Begin
    p_Result := v_Success;
    Begin
      Select *
        Into r_Lg_Order_Head
        From t_Pln_Lg_Order_Head Loh
       Where Loh.Order_Head_Id = p_Lg_Order_Head_Id
         --For Update Nowait
           ;
    Exception
      When Others Then
        p_Result := '获取提货订单信息失败，提货订单ID：' || To_Char(p_Lg_Order_Head_Id) || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;
    
    If r_Lg_Order_Head.Order_Head_State = '2225' And Nvl(r_Lg_Order_Head.Aps_Capacity_State, 'N') = 'P' Then
      p_Result := '当前提货订单已引入APS产能可视，等待APS反馈产能可视计算结果。' || v_Nl ||
                  '提货订单单号：' || r_Lg_Order_Head.Order_Number;
      Raise v_Base_Exception;
    End If;
    
    --add by lizhen 2016-05-20
    --APS产能可视统计提货订单数据周期提前月数
    Begin
      v_Pln_Of_Time_Month := Pkg_Bd.f_Get_Parameter_Value('PLN_CAPACITY_AHEAD_OF_TIME_MONTH',
                                                          r_Lg_Order_Head.Entity_Id);
    Exception
      When Others Then
        v_Pln_Of_Time_Month := 0;
    End;
    
    --20170710 hejy3 获取价格批文开单使用折扣参数
    Begin
      v_Price_Apply_Use_Discount := Pkg_Bd.f_Get_Parameter_Value('PLN_PRICE_APPLY_USE_DISCOUNT',
                                                          r_Lg_Order_Head.Entity_Id);
    Exception
      When Others Then
        v_Price_Apply_Use_Discount := 'N';
    End;

    Pkg_Pln_Pub.p_Get_Currentperioddate(p_Entity_Id                 => r_Lg_Order_Head.Entity_Id, --主体ID
                                        p_Current_Period_Begin_Date => v_Current_Period_Begin_Date, --开始日期
                                        p_Current_Period_End_Date   => v_Current_Period_End_Date --结束日期
                                        );
    v_Current_Period_Begin_Date := Add_Months(v_Current_Period_Begin_Date, v_Pln_Of_Time_Month -1);

    Begin
      Select *
        Into r_Order_Type
        From t_Pln_Order_Type Ot
       Where Ot.Order_Type_Id = r_Lg_Order_Head.Order_Type_Id;
    Exception
      When Others Then
        p_Result := '获取单据类型信息失败，单据类型ID：' || To_Char(r_Lg_Order_Head.Order_Type_Id) || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;
    
    Begin
      Select Ue.Entity_Code_Name
        Into v_Entity_Code
        From Up_Codelist Up, Up_Codelist_Entity Ue
       Where Up.Codetype = 'PlnEntityToMainEntity'
         And Up.Id = Ue.Codelist_Id
         And Ue.Entity_Id = r_Lg_Order_Head.Entity_Id;
    Exception
      When No_Data_Found Then
        Begin
          Select Entity.Entity_Code
            Into v_Entity_Code
            From v_Bd_Entity Entity
           Where Entity.Entity_Id = r_Lg_Order_Head.Entity_Id;
        Exception
          When Others Then
            p_Result := '获取主体编码失败，主体ID：' || To_Char(r_Lg_Order_Head.Entity_Id) || Sqlerrm;
            Raise v_Base_Exception;
        End;
      When Others Then
        p_Result := '获取主体失败,主体快码PlnEntityToMainEntity' || Sqlerrm;
        Raise v_Base_Exception;
    End;
    
    Begin
      Select Aps_Pre_Mon_Order_Iface_s.Nextval Into v_Batch_Id From Dual;
    Exception
      When Others Then
        p_Result := '获取APS批次序列ID失败！' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;
 
    v_Index := 0;
    For r_Order_Line In (Select *
                           From t_Pln_Lg_Order_Line Lol
                          Where Lol.Order_Head_Id = p_Lg_Order_Head_Id
                            And (p_Cancel_Flag = 'N' Or (p_Cancel_Flag = 'Y' 
                             And Lol.Aps_Capacity_Rec_Qty Is Not Null
                             --add by lizhen 2016-06-12增加按行关闭功能控制
                             And ((p_Close_Line_Flag = 'N' And 
                               Nvl(Lol.Order_Line_State, 'NORMAL') != 'CLOSED')  Or 
                              (p_Close_Line_Flag = 'Y' And 
                              Nvl(Lol.Order_Line_State, 'NORMAL') = 'AWAITED'))))) Loop
      v_Import_Aps_Capacity_Qty := 0;
      Begin
        Select Pa.Mrp_Org_Id
          Into v_Organization_Id
          From t_Pln_Producing_Area Pa
         Where Pa.Producing_Area_Id = r_Order_Line.Producing_Area_Id;
      Exception
        When Others Then
          p_Result := '获取产品产地组织ID失败。' || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
      End;
      If v_Organization_Id Is Null Then
        p_Result := '产地组织ID不允许为空。';
        Raise v_Base_Exception;
      End If;
      If p_Cancel_Flag = 'N' Then
        v_Item_Usable_Qty := Pkg_Pln_Pub.f_Get_Item_Usable_Qty(p_Entity_Id         => r_Lg_Order_Head.Entity_Id,
                                                               p_Item_Id           => r_Order_Line.Item_Id,
                                                               p_Order_Submit_Type => r_Order_Type.Lg_Order_Submit_Type,
                                                               p_Sales_Center_Id   => r_Lg_Order_Head.Sales_Center_Id,
                                                               p_Lg_Order_Noship   => 'Y',
                                                               p_User_Code         => p_User_Code);
         
        If v_Item_Usable_Qty >= r_Order_Line.Quantity Then
          v_Import_Aps_Capacity_Qty := 0;
        Else
          v_Import_Aps_Capacity_Qty := r_Order_Line.Quantity - Nvl(v_Item_Usable_Qty, 0);
        End If;  
      Else
        --add by lizhen 2016-05-17计划订单送审日期小于提货订单当期周期范围，不需取消APS产能可视数量
        Begin
          Select Trunc(Nvl(Poh.Refer_Date, Poh.Creation_Date)) Into v_Pln_Order_Submit_Date
            From t_Pln_Order_Head Poh
           Where Exists (Select 1
                    From t_Pln_Lg_Relation Lr, t_Pln_Order_Line Pol
                   Where Lr.Order_Line_Id = Pol.Order_Line_Id
                     And Pol.Order_Head_Id = Poh.Order_Head_Id
                     And Lr.Lg_Order_Line_Id = r_Order_Line.Order_Line_Id);
          If v_Pln_Order_Submit_Date <  v_Current_Period_Begin_Date Then
            v_Chk_Import_Flag := 'N';
          Else
            v_Chk_Import_Flag := 'Y';
          End If;
        Exception
          When No_Data_Found Then
            Begin
              Select Trunc(Nvl(Loh.To_Checkup_Date, Sysdate))
                Into v_Pln_Order_Submit_Date
                From t_Pln_Lg_Order_Head Loh
               Where Loh.Order_Head_Id = p_Lg_Order_Head_Id;
              If v_Pln_Order_Submit_Date < v_Current_Period_Begin_Date Then
                v_Chk_Import_Flag := 'N';
              Else
                v_Chk_Import_Flag := 'Y';
              End If; 
            Exception
              When Others Then
                v_Chk_Import_Flag := 'Y';
            End;
          When Others Then
            v_Chk_Import_Flag := 'Y';
        End;
        If v_Chk_Import_Flag = 'N' Then
          Goto chkCurrendPerionImport;
        End If;
        --T+3订单行已全部入库（含部份入库后取消订单数量）不需要重引APS取消产能
        Begin
          Select Nvl(Pol.Can_Produce_Qty, 0) - Nvl(Pol.Supply_Qty, 0) -
                 Nvl(Pol.Adjust_Qty, 0)
            Into v_Pln_Line_Supply_Qty
            From t_Pln_Order_Line Pol
           Where Exists
           (Select 1
                    From t_Pln_Lg_Relation Lr
                   Where Lr.Order_Line_Id = Pol.Order_Line_Id
                     And Lr.Lg_Order_Line_Id = r_Order_Line.Order_Line_Id);
          If Nvl(v_Pln_Line_Supply_Qty, 0) = 0 Then
            v_Chk_Import_Flag := 'N';
          Else
            v_Chk_Import_Flag := 'Y';
          End If;
        Exception
          When Others Then
            v_Chk_Import_Flag := 'Y';
        End;
        If v_Chk_Import_Flag = 'N' Then
          Goto chkCurrendPerionImport;
        End If;
        --提货订单关闭、取消扣减已发货数量
        If r_Order_Line.Aps_Capacity_Rec_Qty Is Null Then
          p_Result := '提货订单产能可视APS未反馈结果，红冲产能可视失败！' || v_Nl ||
            '提货订单单号：' || r_Lg_Order_Head.Order_Number;
          Raise v_Base_Exception;
        End If;
        --modi by lizhen 2016-07-15 不减已评审数量
        v_Import_Aps_Capacity_Qty := Nvl(r_Order_Line.Aps_Capacity_Rec_Qty, 0)/*- Nvl(r_Order_Line.Affirmed_Quantity, 0)*/; 
      End If;
      Select Decode(p_Cancel_Flag,
                    'N',
                    v_Import_Aps_Capacity_Qty -
                    Nvl(r_Order_Line.Aps_Capacity_Rec_Qty, 0), --Quantity,
                    'Y',
                    -1 * Nvl(v_Import_Aps_Capacity_Qty, 0),
                    0)
        Into v_Import_Aps_Capacity_Qty
        From Dual;
      If Abs(Nvl(v_Import_Aps_Capacity_Qty, 0)) > 0 Then
        v_Index := v_Index + 1;
        Begin
          Insert Into Intf_Pln_Order_Capacity_Send
            (Intf_Id,
             Batch_Id,
             Entity_Id,
             Business_Group,
             Organization_Id,
             Order_Number,
             Order_Line_Number,
             Order_Line_Id,
             Item_Code,
             Quantity,
             Customer_Code,
             Error_Message,
             Import_Status,
             Created_By,
             Creation_Date,
             Last_Updated_By,
             Last_Update_Date)
          Values
            (s_Intf_Pln_Order_Capacity_Send.Nextval, --Intf_Id,
             v_Batch_Id, --Batch_Id,
             r_Lg_Order_Head.Entity_Id, --Entity_Id,
             v_Entity_Code, --Business_Group,
             v_Organization_Id, --Organization_Id,
             r_Lg_Order_Head.Order_Number, --Order_Number,
             To_Char(v_Index), --Order_Line_Number,
             r_Order_Line.Order_Line_Id, --Order_Line_Id,
             r_Order_Line.Item_Code, --Item_Code,
             v_Import_Aps_Capacity_Qty, --quantity
             r_Lg_Order_Head.Customer_Code, --Customer_Code,
             Null, -- Error_Message,
             'N', -- Import_Status,
             p_User_Code, -- Created_By,
             Sysdate, --Creation_Date,
             p_User_Code, --Last_Updated_By,
             Sysdate --Last_Update_Date
             );
        Exception
          When Others Then
            p_Result := '写入CIMS APS产能可视接口失败！' || v_Nl || Sqlerrm;
            Raise v_Base_Exception; 
        End;
        
        Update t_Pln_Lg_Order_Line Ol
           Set Ol.To_Aps_Capacity_Qty = Decode(p_Cancel_Flag,
                                               'N',
                                               v_Import_Aps_Capacity_Qty,
                                               0),
               Ol.Last_Updated_By     = p_User_Code,
               Ol.Last_Update_Date    = Sysdate,
               Ol.Version             = Nvl(Ol.Version, 0) + 1
         Where Ol.Order_Line_Id = r_Order_Line.Order_Line_Id;
      End If;
      <<chkCurrendPerionImport>>
        Null;
    End Loop;
    
    --被删除的提货订单行数据，且已引入过APS产能可视的，需重新再引入取消产能可视数量
    For r_Del_Line In (Select *
                         From t_Pln_Line_Del_His Ldh
                        Where Ldh.Origin_Type = 'LG_ORDER'
                          And Ldh.Order_Head_Id = p_Lg_Order_Head_Id
                          And Nvl(Ldh.Aps_Capacity_Intf_Flag, 'N') = 'N'
                          And r_Lg_Order_Head.Aps_Capacity_State In
                              ('P', 'S')) Loop
      Begin
        Select Bi.Sales_Main_Type
          Into v_Sales_Main_Type
          From t_Bd_Item Bi
         Where Bi.Item_Id = r_Del_Line.Item_Id
           And Bi.Item_Code = r_Del_Line.Item_Code;
      Exception
        When Others Then
          p_Result := '获取产品信息失败！' || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
      End;
      
      Begin
        Select Pa.Mrp_Org_Id
          Into v_Organization_Id
          From t_Pln_Producing_Area Pa
         Where Pa.Producing_Area_Id = r_Del_Line.Producing_Area_Id;
      Exception
        When Others Then
          p_Result := '获取产品产地组织ID失败。' || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
      End;
      If v_Organization_Id Is Null Then
        p_Result := '产地组织ID不允许为空。产地ID：' || r_Del_Line.Producing_Area_Id;
        Raise v_Base_Exception;
      End If;
      
      If Nvl(r_Del_Line.Aps_Capacity_Rec_Qty, 0) > 0 Then
        v_Index := v_Index + 1;
        Begin
          Insert Into Intf_Pln_Order_Capacity_Send
            (Intf_Id,
             Batch_Id,
             Entity_Id,
             Business_Group,
             Organization_Id,
             Order_Number,
             Order_Line_Number,
             Order_Line_Id,
             Item_Code,
             Quantity,
             Customer_Code,
             Error_Message,
             Import_Status,
             Created_By,
             Creation_Date,
             Last_Updated_By,
             Last_Update_Date)
          Values
            (s_Intf_Pln_Order_Capacity_Send.Nextval, --Intf_Id,
             v_Batch_Id, --Batch_Id,
             r_Lg_Order_Head.Entity_Id, --Entity_Id,
             v_Entity_Code, --Business_Group,
             v_Organization_Id, --Organization_Id,
             r_Lg_Order_Head.Order_Number, --Order_Number,
             To_Char(v_Index), --Order_Line_Number,
             r_Del_Line.Order_Line_Id, --Order_Line_Id,
             r_Del_Line.Item_Code, --Item_Code,
             -1 * Nvl(r_Del_Line.Aps_Capacity_Rec_Qty, 0),
             r_Lg_Order_Head.Customer_Code, --Customer_Code,
             Null, -- Error_Message,
             'N', -- Import_Status,
             p_User_Code, -- Created_By,
             Sysdate, --Creation_Date,
             p_User_Code, --Last_Updated_By,
             Sysdate --Last_Update_Date
             );
        Exception
          When Others Then
            p_Result := '写入CIMS APS产能可视接口失败！' || v_Nl || Sqlerrm;
            Raise v_Base_Exception;
        End;
      End If;
      
      --检查并解锁资金
      If Nvl(Upper(r_Order_Type.Is_Business_Control), '_') != 'PRO_ORDER' Then
        --20170710 hejy3 价格批文开单使用折扣
        --If r_Del_Line.Project_Order_Type Is Null And r_Del_Line.Project_Order_Line_Id Is Null Then
        If r_Del_Line.Project_Order_Type Is not Null And r_Del_Line.Project_Order_Line_Id Is not Null Then
          if v_Price_Apply_Use_Discount = 'Y' then
            v_Amount := Nvl(r_Del_Line.Quantity, 0) * Nvl(r_Del_Line.Apply_List_Price, 0) * (100 - Nvl(r_Del_Line.Apply_Discount_Rate, 0) 
              - Nvl(r_Del_Line.Ordered_Discount_Rate, 0))/100;
            v_Discount_Amount := Nvl(r_Del_Line.Quantity, 0) * Nvl(r_Del_Line.Apply_List_Price, 0) * Nvl(r_Del_Line.Apply_Discount_Rate, 0) /100;
          else
            v_Amount := Nvl(r_Del_Line.Quantity, 0) * Nvl(r_Del_Line.Apply_List_Price, 0) * (100 - Nvl(r_Del_Line.Ordered_Discount_Rate, 0))/100;
            v_Discount_Amount := 0;
          end if;
        Else
          v_Amount := Nvl(r_Del_Line.Quantity, 0) * Nvl(r_Del_Line.List_Price, 0) * (100 - Nvl(r_Del_Line.Discount_Rate, 0) 
            - Nvl(r_Del_Line.Ordered_Discount_Rate, 0))/100;
          v_Discount_Amount := Nvl(r_Del_Line.Quantity, 0) * Nvl(r_Del_Line.List_Price, 0) * Nvl(r_Del_Line.Discount_Rate, 0) /100;
        End If;   
        If Nvl(r_Lg_Order_Head.Lock_Amount_Flag, r_Order_Type.Chk_Cusg_Amount_Flag) = 'S' Then
          Pkg_Credit_Account_Control.Prc_Credit_Order_Bill(p_Entity_Id       => r_Lg_Order_Head.Entity_Id,
                                                           p_Action_Type     => 2,
                                                           p_Settlement_Sum  => Round(Nvl(v_Amount, 0), 2),
                                                           p_Discount_Sum    => Round(Nvl(v_Discount_Amount, 0), 2),
                                                           p_Sales_Main_Type => v_Sales_Main_Type,
                                                           p_Account_Id      => r_Lg_Order_Head.Account_Id,
                                                           p_Customer_Id     => r_Lg_Order_Head.Customer_Id,
                                                           p_Proj_Number     => Null,
                                                           p_Order_Id        => r_Lg_Order_Head.Order_Head_Id,
                                                           --p_Order_Type      => r_Lg_Order_Head.Order_Type_Name,
                                                           P_ORDER_TYPE => r_Lg_Order_Head.Order_Type_Code, --20160912 hejy3 传入订单类型编码
                                                           p_Username        => p_User_Code,
                                                           p_Result          => v_Count,
                                                           p_Err_Msg         => p_Result);
          If p_Result <> v_Success Then
            p_Result := '解锁资金失败，产品大类：' || v_Sales_Main_Type || v_Nl ||
                        p_Result;
            Raise v_Base_Exception;
          End If;
        End If;
      Else
        /*--推广物料提货订单提货类型  取消资金锁定
          01  销售提货
          02  物料领用
          03  资源领用*/

        Select Decode(r_Order_Type.Order_Lg_Type,
                      Null,
                      2,
                      '01',
                      2,
                      '02',
                      40,
                      '03',
                      33,
                      2)
          Into v_Action_Type
          From Dual;
        If Nvl(r_Lg_Order_Head.Lock_Amount_Flag, r_Order_Type.Chk_Cusg_Amount_Flag) In ('RS', 'S') Then
          --推广物料资源送审锁款
          Pkg_Credit_Control_Pmt.Prc_Credit_Control_Pmt(p_Entity_Id       => r_Lg_Order_Head.Entity_Id, --主ID体
                                                        p_Action_Type     => v_Action_Type, --动作标示（32：资源提货订单评审，33：资源提货订单取消  40:提货领用）
                                                        p_Settlement_Sum  => Round(Nvl(v_Amount, 0), 2), --结算金额
                                                        p_Discount_Sum    => Round(Nvl(v_Discount_Amount, 0), 2), --折扣金额
                                                        p_Sales_Main_Type => v_Sales_Main_Type, --营销大类
                                                        p_Order_Id        => r_Lg_Order_Head.Order_Head_Id, --单据ID
                                                        p_Account_Id      => r_Lg_Order_Head.Account_Id, --账户ID
                                                        p_Customer_Id     => r_Lg_Order_Head.Customer_Id, --客户ID
                                                        p_Proj_Number     => Null, --项目号
                                                        p_Created_Mode    => Null, --开单方式
                                                        --p_Order_Type      => r_Lg_Order_Head.Order_Type_Name, --单据类型
                                                        p_Order_Type      => r_Lg_Order_Head.Order_Type_Code, --20160912 hejy3 传入订单类型编码
                                                        p_Username        => p_User_Code,
                                                        p_Result          => v_Count, --返回错误ID
                                                        p_Err_Msg         => p_Result--返回错误信息
                                                        );
          If p_Result <> v_Success Then
            p_Result := '解锁资金失败，产品大类：' || v_Sales_Main_Type || v_Nl ||
                        p_Result;
            Raise v_Base_Exception;
          End If;
        End If;
      End If;    
      
      If r_Del_Line.Project_Order_Line_Id Is Not Null Then
        -- 价格申请解锁（提货订单评审驳回时），PriceApplyBO.unlock(‘批文明细ID’，'解锁数量’，‘关联单号’ )
        Pkg_Bd_Price.p_Apply_Unlock(r_Del_Line.Project_Order_Line_Id, --批文明细ID
                                    Nvl(r_Del_Line.Quantity, 0), --解除锁定数量
                                    r_Lg_Order_Head.Order_Number, --关联单号
                                    v_Count, --返回编码，1成功，0失败
                                    p_Result);
        If v_Count != 1 Then
          p_Result := '释放批文数量失败！' || v_Nl || p_Result;
          Raise v_Base_Exception;
        Else
          p_Result := v_Success;
        End If;  
      End If;
      
      Update t_Pln_Line_Del_His Ldh
         Set Ldh.To_Aps_Capacity_Qty    = -1 * Ldh.To_Aps_Capacity_Qty,
             Ldh.Last_Updated_By        = p_User_Code,
             Ldh.Last_Update_Date       = Sysdate,
             Ldh.Version                = Nvl(Ldh.Version, 0) + 1,
             Ldh.Aps_Capacity_Intf_Flag = 'Y'
       Where Ldh.Order_Line_Id = r_Del_Line.Order_Line_Id;
    End Loop;
    
    --所有产品库存数量满足，不需需引APS的，不变更提货订单头状态
    If v_Index <> 0 Then
      --更新提货订单头引入标志
      Update t_Pln_Lg_Order_Head Loh
         Set Loh.Aps_Capacity_State      = 'P',
             Loh.Aps_Capacity_Begin_Date = Nvl(Loh.Aps_Capacity_Begin_Date,
                                               Sysdate),
             Loh.Aps_Capacity_End_Date   = Sysdate,
             Loh.Aps_Capacity_By         = p_User_Code,
             Loh.Batch_Id                = v_Batch_Id,
             --modi by lizhen 2017-05-25取消产能时，订单状态不做变更
             Loh.Order_Head_State = Decode(p_Cancel_Flag, 'Y', Loh.Order_Head_State, '2225')  --已引APS产能可视
       Where Loh.Order_Head_Id = p_Lg_Order_Head_Id;
      
       
      p_Import_Aps_Capacity(p_Batch_Id => v_Batch_Id,
                            p_Result  => p_Result);
      If p_Result <> v_Success Then
        Raise v_Base_Exception;
      End If;  
      p_Batch_Id := v_Batch_Id;
      p_Entity_Code := v_Entity_Code;                      
    End If;
  Exception
    When v_Base_Exception Then
      Rollback;
      p_Result := '写入接口表数据失败(p_Lgorder_Aps_Capacity_Send)！' || v_Nl || p_Result;
    When Others Then
      Rollback;
      p_Result := '写入接口表数据失败(p_Lgorder_Aps_Capacity_Send)！' || v_Nl || p_Result || Sqlerrm;
  End;  
  
  -----------------------------------------------------------------------------
  -- AUTHOR  : Nicro.Li
  -- CREATED : 2016-05-06
  -- PURPOSE : 把已引APS产能可视状态，且有被删除的行数据引入APS产能可视
  -----------------------------------------------------------------------------
  Procedure p_DelLine_Aps_Capacity_Send(p_Lg_Order_Head_Id In Number, --提货订单头ID
                                        p_User_Code        In Varchar2,
                                        p_Result           Out Varchar2,
                                        p_Batch_Id         Out Number,    --返回批次ID
                                        p_Entity_Code      Out Varchar2   --返回主体编码
                                        ) Is
    r_Lg_Order_Head t_Pln_Lg_Order_Head%Rowtype;
    r_Order_Type    t_Pln_Order_Type%Rowtype;
    v_Batch_Id                  Number;
    v_Organization_Id           Number;
    v_Entity_Code               Varchar2(32);
    v_Index                     Number;
    v_Item_Usable_Qty           Number;
    v_Import_Aps_Capacity_Qty   Number;
    v_Amount                    Number;
    v_Discount_Amount           Number;
    v_Count                     Number;
    v_Action_Type               Number;
    v_Sales_Main_Type  t_Bd_Item.Sales_Main_Type%Type;
    v_Err_Msg                   Varchar2(4000);
    v_Request_Id                Number;
    v_Price_Apply_Use_Discount t_bd_param_list.default_value%type := 'N'; --20170710 hejy3 价格批文开单使用折扣
  Begin
    p_Result := v_Success;
    Begin
      Select *
        Into r_Lg_Order_Head
        From t_Pln_Lg_Order_Head Loh
       Where Loh.Order_Head_Id = p_Lg_Order_Head_Id;
    Exception
      When Others Then
        p_Result := '获取提货订单信息失败，提货订单ID：' || To_Char(p_Lg_Order_Head_Id) || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;
    
    If r_Lg_Order_Head.Order_Head_State != '2225' Then
      p_Result := '当前提货订单未引入APS产能可视，引入提货订单删除行失败。' || v_Nl ||
                  '提货订单单号：' || r_Lg_Order_Head.Order_Number;
      Raise v_Base_Exception;
    End If;
    
    Begin
      Select *
        Into r_Order_Type
        From t_Pln_Order_Type Ot
       Where Ot.Order_Type_Id = r_Lg_Order_Head.Order_Type_Id;
    Exception
      When Others Then
        p_Result := '获取单据类型信息失败，单据类型ID：' || To_Char(r_Lg_Order_Head.Order_Type_Id);
        Raise v_Base_Exception;
    End;
    
    --20170710 hejy3 获取价格批文开单使用折扣参数
    Begin
      v_Price_Apply_Use_Discount := Pkg_Bd.f_Get_Parameter_Value('PLN_PRICE_APPLY_USE_DISCOUNT',
                                                          r_Lg_Order_Head.Entity_Id);
    Exception
      When Others Then
        v_Price_Apply_Use_Discount := 'N';
    End;
    
    Begin
      Select Ue.Entity_Code_Name
        Into v_Entity_Code
        From Up_Codelist Up, Up_Codelist_Entity Ue
       Where Up.Codetype = 'PlnEntityToMainEntity'
         And Up.Id = Ue.Codelist_Id
         And Ue.Entity_Id = r_Lg_Order_Head.Entity_Id;
    Exception
      When No_Data_Found Then
        Begin
          Select Entity.Entity_Code
            Into v_Entity_Code
            From v_Bd_Entity Entity
           Where Entity.Entity_Id = r_Lg_Order_Head.Entity_Id;
        Exception
          When Others Then
            p_Result := '获取主体编码失败，主体ID：' || To_Char(r_Lg_Order_Head.Entity_Id) || Sqlerrm;
            Raise v_Base_Exception;
        End;
      When Others Then
        p_Result := '获取主体失败,主体快码PlnEntityToMainEntity' || Sqlerrm;
        Raise v_Base_Exception;
    End;
    
    Begin
      Select Aps_Pre_Mon_Order_Iface_s.Nextval Into v_Batch_Id From Dual;
    Exception
      When Others Then
        p_Result := '获取APS批次序列ID失败！' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;
 
    v_Index := 0;
  
    --被删除的提货订单行数据，且已引入过APS产能可视的，需重新再引入取消产能可视数量
    For r_Del_Line In (Select *
                         From t_Pln_Line_Del_His Ldh
                        Where Ldh.Origin_Type = 'LG_ORDER'
                          And Ldh.Order_Head_Id = p_Lg_Order_Head_Id
                          And Nvl(Ldh.Aps_Capacity_Intf_Flag, 'N') = 'N'
                          And r_Lg_Order_Head.Aps_Capacity_State In ('P', 'S')) Loop
      Begin
        Select Bi.Sales_Main_Type
          Into v_Sales_Main_Type
          From t_Bd_Item Bi
         Where Bi.Item_Id = r_Del_Line.Item_Id;
      Exception
        When Others Then
          p_Result := '获取产品信息失败！' || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
      End;
      
      Begin
        Select Pa.Mrp_Org_Id
          Into v_Organization_Id
          From t_Pln_Producing_Area Pa
         Where Pa.Producing_Area_Id = r_Del_Line.Producing_Area_Id;
      Exception
        When Others Then
          p_Result := '获取产品产地组织ID失败。' || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
      End;
      If v_Organization_Id Is Null Then
        p_Result := '产地组织ID不允许为空。产地ID：' || r_Del_Line.Producing_Area_Id;
        Raise v_Base_Exception;
      End If;
      
      If Nvl(r_Del_Line.Aps_Capacity_Rec_Qty, 0) > 0 Then
        v_Index := v_Index + 1;
        Begin
          Insert Into Intf_Pln_Order_Capacity_Send
            (Intf_Id,
             Batch_Id,
             Entity_Id,
             Business_Group,
             Organization_Id,
             Order_Number,
             Order_Line_Number,
             Order_Line_Id,
             Item_Code,
             Quantity,
             Customer_Code,
             Error_Message,
             Import_Status,
             Created_By,
             Creation_Date,
             Last_Updated_By,
             Last_Update_Date)
          Values
            (s_Intf_Pln_Order_Capacity_Send.Nextval, --Intf_Id,
             v_Batch_Id, --Batch_Id,
             r_Lg_Order_Head.Entity_Id, --Entity_Id,
             v_Entity_Code, --Business_Group,
             v_Organization_Id, --Organization_Id,
             r_Lg_Order_Head.Order_Number, --Order_Number,
             To_Char(v_Index), --Order_Line_Number,
             r_Del_Line.Order_Line_Id, --Order_Line_Id,
             r_Del_Line.Item_Code, --Item_Code,
             -1 * Nvl(r_Del_Line.Aps_Capacity_Rec_Qty, 0),
             r_Lg_Order_Head.Customer_Code, --Customer_Code,
             Null, -- Error_Message,
             'N', -- Import_Status,
             p_User_Code, -- Created_By,
             Sysdate, --Creation_Date,
             p_User_Code, --Last_Updated_By,
             Sysdate --Last_Update_Date
             );
        Exception
          When Others Then
            p_Result := '写入CIMS APS产能可视接口失败！' || v_Nl || Sqlerrm;
            Raise v_Base_Exception;
        End;
      End If;
      
      --检查并解锁资金
      If Nvl(Upper(r_Order_Type.Is_Business_Control), '_') != 'PRO_ORDER' Then
        --20170710 hejy3 价格批文开单使用折扣
        --If r_Del_Line.Project_Order_Type Is Null And r_Del_Line.Project_Order_Line_Id Is Null Then
        If r_Del_Line.Project_Order_Type Is not Null And r_Del_Line.Project_Order_Line_Id Is not Null Then
          if v_Price_Apply_Use_Discount = 'Y' then
            v_Amount := Nvl(r_Del_Line.Quantity, 0) * Nvl(r_Del_Line.Apply_List_Price, 0) * (100 - Nvl(r_Del_Line.Apply_Discount_Rate, 0) 
              - Nvl(r_Del_Line.Ordered_Discount_Rate, 0))/100;
            v_Discount_Amount := Nvl(r_Del_Line.Quantity, 0) * Nvl(r_Del_Line.Apply_List_Price, 0) * (100 - Nvl(r_Del_Line.Apply_Discount_Rate, 0))/100;
          else
            v_Amount := Nvl(r_Del_Line.Quantity, 0) * Nvl(r_Del_Line.Apply_List_Price, 0) * (100 - Nvl(r_Del_Line.Ordered_Discount_Rate, 0))/100;
            v_Discount_Amount := 0;
          end if;
        Else
          v_Amount := Nvl(r_Del_Line.Quantity, 0) * Nvl(r_Del_Line.List_Price, 0) * (100 - Nvl(r_Del_Line.Discount_Rate, 0) 
            - Nvl(r_Del_Line.Ordered_Discount_Rate, 0))/100;
          v_Discount_Amount := Nvl(r_Del_Line.Quantity, 0) * Nvl(r_Del_Line.List_Price, 0) * Nvl(r_Del_Line.Discount_Rate, 0) /100;
        End If;   
        If Nvl(r_Lg_Order_Head.Lock_Amount_Flag, r_Order_Type.Chk_Cusg_Amount_Flag) = 'S' Then
          Pkg_Credit_Account_Control.Prc_Credit_Order_Bill(p_Entity_Id       => r_Lg_Order_Head.Entity_Id,
                                                           p_Action_Type     => 2,
                                                           p_Settlement_Sum  => Round(Nvl(v_Amount, 0), 2),
                                                           p_Discount_Sum    => Round(Nvl(v_Discount_Amount, 0), 2),
                                                           p_Sales_Main_Type => v_Sales_Main_Type,
                                                           p_Account_Id      => r_Lg_Order_Head.Account_Id,
                                                           p_Customer_Id     => r_Lg_Order_Head.Customer_Id,
                                                           p_Proj_Number     => Null,
                                                           p_Order_Id        => r_Lg_Order_Head.Order_Head_Id,
                                                           --p_Order_Type      => r_Lg_Order_Head.Order_Type_Name,
                                                           P_ORDER_TYPE => r_Lg_Order_Head.Order_Type_Code, --20160912 hejy3 传入订单类型编码
                                                           p_Username        => p_User_Code,
                                                           p_Result          => v_Count,
                                                           p_Err_Msg         => p_Result);
          If p_Result <> v_Success Then
            p_Result := '解锁资金失败，产品大类：' || v_Sales_Main_Type || v_Nl ||
                        p_Result;
            Raise v_Base_Exception;
          End If;
        End If;
      Else
        /*--推广物料提货订单提货类型  取消资金锁定
          01  销售提货
          02  物料领用
          03  资源领用*/

        Select Decode(r_Order_Type.Order_Lg_Type,
                      Null,
                      2,
                      '01',
                      2,
                      '02',
                      40,
                      '03',
                      33,
                      2)
          Into v_Action_Type
          From Dual;
        If Nvl(r_Lg_Order_Head.Lock_Amount_Flag, r_Order_Type.Chk_Cusg_Amount_Flag) In ('RS', 'S') Then
          --推广物料资源送审锁款
          Pkg_Credit_Control_Pmt.Prc_Credit_Control_Pmt(p_Entity_Id       => r_Lg_Order_Head.Entity_Id, --主ID体
                                                        p_Action_Type     => v_Action_Type, --动作标示（32：资源提货订单评审，33：资源提货订单取消  40:提货领用）
                                                        p_Settlement_Sum  => Round(Nvl(v_Amount, 0), 2), --结算金额
                                                        p_Discount_Sum    => Round(Nvl(v_Discount_Amount, 0), 2), --折扣金额
                                                        p_Sales_Main_Type => v_Sales_Main_Type, --营销大类
                                                        p_Order_Id        => r_Lg_Order_Head.Order_Head_Id, --单据ID
                                                        p_Account_Id      => r_Lg_Order_Head.Account_Id, --账户ID
                                                        p_Customer_Id     => r_Lg_Order_Head.Customer_Id, --客户ID
                                                        p_Proj_Number     => Null, --项目号
                                                        p_Created_Mode    => Null, --开单方式
                                                        --p_Order_Type      => r_Lg_Order_Head.Order_Type_Name, --单据类型
                                                        p_Order_Type      => r_Lg_Order_Head.Order_Type_Code, --20160912 hejy3 传入订单类型编码
                                                        p_Username        => p_User_Code,
                                                        p_Result          => v_Count, --返回错误ID
                                                        p_Err_Msg         => p_Result--返回错误信息
                                                        );
          If p_Result <> v_Success Then
            p_Result := '解锁资金失败，产品大类：' || v_Sales_Main_Type || v_Nl ||
                        p_Result;
            Raise v_Base_Exception;
          End If;
        End If;
      End If;    
      
      If r_Del_Line.Project_Order_Line_Id Is Not Null Then
        -- 价格申请解锁（提货订单评审驳回时），PriceApplyBO.unlock(‘批文明细ID’，'解锁数量’，‘关联单号’ )
        Pkg_Bd_Price.p_Apply_Unlock(r_Del_Line.Project_Order_Line_Id, --批文明细ID
                                    Nvl(r_Del_Line.Quantity, 0), --解除锁定数量
                                    r_Lg_Order_Head.Order_Number, --关联单号
                                    v_Count, --返回编码，1成功，0失败
                                    p_Result);
        If v_Count != 1 Then
          p_Result := '释放批文数量失败！' || v_Nl || p_Result;
          Raise v_Base_Exception;
        Else
          p_Result := v_Success;
        End If;  
      End If;  
      
      Update t_Pln_Line_Del_His Ldh
         Set Ldh.To_Aps_Capacity_Qty    = -1 * Ldh.To_Aps_Capacity_Qty,
             Ldh.Last_Updated_By        = p_User_Code,
             Ldh.Last_Update_Date       = Sysdate,
             Ldh.Version                = Nvl(Ldh.Version, 0) + 1,
             Ldh.Aps_Capacity_Intf_Flag = 'Y'
       Where Ldh.Order_Line_Id = r_Del_Line.Order_Line_Id;
    End Loop;
    
    --所有产品库存数量满足，不需需引APS的，不变更提货订单头状态
    If v_Index <> 0 Then    
      p_Import_Aps_Capacity(p_Batch_Id => v_Batch_Id,
                            p_Result  => p_Result);
      If p_Result <> v_Success Then
        Raise v_Base_Exception;
      End If;
      p_Batch_Id := v_Batch_Id;
      p_Entity_Code := v_Entity_Code;
    End If;
  Exception
    When v_Base_Exception Then
      Rollback;
      p_Result := '写入接口表数据失败(p_DelLine_Aps_Capacity_Send)！' || v_Nl || p_Result;
    When Others Then
      Rollback;
      p_Result := '写入接口表数据失败(p_DelLine_Aps_Capacity_Send)！' || v_Nl || Sqlerrm;
  End; 
  
  --------------------------------------------------------------------------
  --Author: Nicro.li
  --Created: 2017-11-0
  --Purpose:产能可视结果回写提货订单
  --------------------------------------------------------------------------
  Procedure p_Capacity_Receiver_Pro(p_Batch_Id    In Number,
                                    p_Entity_Code In Varchar2,
                                    p_Result      Out Varchar2) Is
    v_Entity_Id Number;
    v_Err_Msg   Varchar2(2000);
  Begin
    p_Result := v_Success;
    --处理多个订单  
    For r_Intf_Rec_Head In (Select Distinct Ocr.Order_Number
                              From Intf_Pln_Order_Capacity_Rec Ocr
                             Where Ocr.Entity_Code = p_Entity_Code
                               And Nvl(Ocr.Intf_State, 'N') = 'N'
                               And Ocr.Batch_Id = p_Batch_Id) Loop
    
      For r_Intf_Rec_Detail In (Select *
                                  From Intf_Pln_Order_Capacity_Rec Ocr
                                 Where Ocr.Entity_Code = p_Entity_Code
                                   And Ocr.Batch_Id = p_Batch_Id
                                   And Nvl(Ocr.Intf_State, 'N') = 'N'
                                   And Ocr.Order_Number = r_Intf_Rec_Head.Order_Number) Loop
        Begin
         Update t_Pln_Lg_Order_Line Lol
            Set Lol.Last_Updated_By       = 'APS_INTF',
                Lol.Last_Update_Date      = Sysdate,
                Lol.Version               = Nvl(Lol.Version, 0) + 1,
                Lol.Aps_Capacity_Rec_Qty  = r_Intf_Rec_Detail.Capacity_Qty,
                Lol.Aps_Capacity_Rec_Date = Sysdate,
                --hejy3 T+3优化 APS反馈数量不能完全满足申请数量时，更新订单行产能不能满足标志
                lol.capacity_insufficient_flag = 
                  case
                    when lol.quantity < r_Intf_Rec_Detail.Capacity_Qty then
                      'Y'
                    else
                      'N'
                  end
          Where Lol.Order_Line_Id = r_Intf_Rec_Detail.Order_Line_Id
            And Exists
          (Select 1
                   From t_Pln_Lg_Order_Head Loh
                  Where Loh.Order_Head_Id = Lol.Order_Head_Id
                    --add by lizhen 2016-06-13 制单、驳回、退回单据不再更新订单头状态。因为是先做驳回单据动作，已更新了订单状态
                    And Loh.Order_Head_State Not In ('19', '415', '303'))
         Returning Lol.Entity_Id Into v_Entity_Id;
        
          --更新接口信息
          Update Intf_Pln_Order_Capacity_Rec Ocr
             Set Ocr.Intf_State = 'Y'
           Where Ocr.Order_Capacity_Id = r_Intf_Rec_Detail.Order_Capacity_Id;
        Exception
          When Others Then
            Rollback;
            v_Err_Msg := '更新数据失败，' || Sqlerrm;
            --更新接口信息
            Update Intf_Pln_Order_Capacity_Rec Ocr
               Set Ocr.Intf_State     = 'E',
                   Ocr.Intf_Error_Msg = v_Err_Msg
             Where Ocr.Order_Capacity_Id = r_Intf_Rec_Detail.Order_Capacity_Id;
            Commit;
        End;
      End Loop;
      --更新提货订单头信息
      Update t_Pln_Lg_Order_Head Loh
         Set Loh.Order_Head_State = Case
                                      When (Select Count(1)
                                              From t_Pln_Lg_Order_Line Lol
                                             Where Lol.Order_Head_Id = Loh.Order_Head_Id
                                               And Nvl(Lol.To_Aps_Capacity_Qty, 0) <> Nvl(Lol.Aps_Capacity_Rec_Qty, 0)
                                               And Lol.To_Aps_Capacity_Qty Is Not Null) > 0 Then
                                       '2225'
                                      Else
                                       '20'
                                    End,
             Loh.Aps_Capacity_State = 'S',
             Loh.Aps_Capacity_Rec_Date = Sysdate,
             Loh.Version               = Nvl(Loh.Version, 0) + 1,
             Loh.Last_Update_Date      = Sysdate,
             Loh.Last_Updated_By       = 'APS_INTF',
             Loh.Batch_Id              = Null
       Where Loh.Order_Number = r_Intf_Rec_Head.Order_Number
         And Loh.Entity_Id = v_Entity_Id
         --add by lizhen 2016-06-13 制单、驳回、退回、已关闭单据不再更新订单头状态。因为是先做驳回单据动作，已更新了订单状态
         And Loh.Order_Head_State Not In ('19', '415', '303', '304');
    End Loop;  
  Exception
    When Others Then
      p_Result := '更新提货订单产能可视失败！' || Sqlerrm;
      Rollback;
  End; 
  
  -----------------------------------------------------------------------------
  -- AUTHOR  : Nicro.Li
  -- CREATED : 2016-04-09
  -- PURPOSE : 根据产品、组织ID获取APS剩余产能
  -----------------------------------------------------------------------------
  Procedure p_Import_Aps_Reservation(In_Batch_Id In Number,
                                     Out_Result  Out Varchar2) Is                            
  Begin
    Out_Result := v_Success;
    --开始写入APS产能可视处理接口表
    Begin
      Insert Into Aps_Pp_Pre_Ma_Order_Iface
        (Batch_Id,
         Batch_Number,
         Business_Group,
         Organization_Id,
         Order_Number,
         Order_Line_Number,
         Order_Line_Id,
         Item_Code,
         Quantity,
         Customer_Code,
         Request_Date,
         Last_Update_Date,
         Creation_Date)
        Select Prs.Batch_Id,
               Prs.Batch_Number,
               Prs.Business_Group,
               Prs.Organization_Id,
               Prs.Order_Number,
               Prs.Order_Line_Number,
               Prs.Order_Line_Id,
               Prs.Item_Code,
               Prs.Quantity,
               Prs.Customer_Code,
               Prs.Period_Date,
               Sysdate,
               Sysdate
          From Intf_Pln_Reservation_Send Prs
         Where Prs.Batch_Id = In_Batch_Id;
    Exception
      When Others Then
        Out_Result := '写入APS系统预约接口失败！' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;
  
    --更新接口引入成功标志
    Update Intf_Pln_Reservation_Send Prs
       Set Prs.Import_Status = 'Y'
     Where Prs.Batch_Id = In_Batch_Id;
  Exception
    When v_Base_Exception Then
      Rollback;
      Out_Result := '引入APS预约接口失败(p_Import_Aps_Reservation)！' || v_Nl || Out_Result;
    When Others Then
      Rollback;
      Out_Result := '引入APS预约接口失败(p_Import_Aps_Reservation)！' || v_Nl || Sqlerrm;
  End;
  
  -----------------------------------------------------------------------------
  -- AUTHOR  : Nicro.Li
  -- CREATED : 2017-11-02
  -- PURPOSE : 预约汇总数据引入APS预约接口表
  -----------------------------------------------------------------------------
  Procedure p_Lg_Aps_Reservation_Send(In_Reservation_Head_Id   In Number, --提货订单头ID
                                      In_Cancel_Flag           In Varchar2, --是否取消订单  N:正常引入  Y：取消提货订单
                                      In_User_Code             In Varchar2,
                                      Out_Result               Out Varchar2,
                                      Out_Batch_Id             Out Number,
                                      Out_Entity_Code          Out Varchar2,
                                      Out_Organization_Id      Out Number
                                      ) Is
    r_Reservation_Head t_pln_reservation_coll_head%Rowtype;
    v_Batch_Id                  Number;
    v_Batch_Number              Varchar2(32);
    v_Organization_Id           Number;
    v_Entity_Code               Varchar2(32);
    v_Index                     Number;
    v_Item_Avl_Qty              Number;
    v_Msg                       Varchar2(4000);
    v_Period_Date               Date;
    
  Begin
    Out_Result := v_Success;
    Begin
      Select *
        Into r_Reservation_Head
        From t_Pln_Reservation_Coll_Head Rch
       Where Rch.Reservation_Head_Id = In_Reservation_Head_Id
         For Update Nowait;
    Exception
      When Others Then
        Out_Result := '获取提货订单预约汇总信息失败，汇总头ID：' || To_Char(In_Reservation_Head_Id) || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;
    
    If r_Reservation_Head.To_Plnorder_Flag = 'Y' Or r_Reservation_Head.Reservation_Flag != 'N' Then
      Out_Result := '当前提货订单预约汇总已结转T+3订单或者已引入APS进行预约，不允许再次进行APS预约。' || v_Nl ||
                  '汇总单号：' || r_Reservation_Head.Reservation_Coll_Number;
      Raise v_Base_Exception;
    End If;
    
    If r_Reservation_Head.Reservation_Period_Code Is Null Then
      Out_Result := '未设置预约发货日期与预约生产周期！';
      Raise v_Base_Exception;
    Else
      Begin
        Select Op.End_Date
          Into v_Period_Date
          From t_Pln_Order_Period Op
         Where Op.Entity_Id = r_Reservation_Head.Entity_Id
           And Op.Period_Type = 'T+3周期'
           And Op.Period_Code = r_Reservation_Head.Reservation_Period_Code;
      Exception
        When Others Then
          Out_Result := '获取预约周期日期失败！' || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
      End;
    End If;
    
    Begin
      Select Ue.Entity_Code_Name
        Into v_Entity_Code
        From Up_Codelist Up, Up_Codelist_Entity Ue
       Where Up.Codetype = 'PlnEntityToMainEntity'
         And Up.Id = Ue.Codelist_Id
         And Ue.Entity_Id = r_Reservation_Head.Entity_Id;
    Exception
      When No_Data_Found Then
        Begin
          Select Entity.Entity_Code
            Into v_Entity_Code
            From v_Bd_Entity Entity
           Where Entity.Entity_Id = r_Reservation_Head.Entity_Id;
        Exception
          When Others Then
            Out_Result := '获取主体编码失败，主体ID：' || To_Char(r_Reservation_Head.Entity_Id) || Sqlerrm;
            Raise v_Base_Exception;
        End;
      When Others Then
        Out_Result := '获取主体失败,主体快码PlnEntityToMainEntity' || Sqlerrm;
        Raise v_Base_Exception;
    End;
    
    v_Msg := Null;
    For r_Check In (Select Ppa.Mrp_Org_Id,
                           Ppa.Mrp_Org_Code,
                           Rcl.Item_Code,
                           Op.End_Date,
                           Sum(Rcl.To_Plnorder_Qty) To_Plnorder_Qty
                      From t_Pln_Reservation_Coll_Line Rcl,
                           t_Pln_Reservation_Coll_Head Rch,
                           t_Pln_Order_Period          Op,
                           t_Pln_Producing_Area        Ppa
                     Where Rcl.Reservation_Head_Id = Rch.Reservation_Head_Id
                       And Op.Period_Code = Rch.Reservation_Period_Code
                       And Op.Entity_Id = Rch.Entity_Id
                       And Op.Period_Type = 'T+3周期'
                       And Ppa.Producing_Area_Id = Rcl.Producing_Area_Id
                       And Rch.Reservation_Head_Id = In_Reservation_Head_Id
                     Group By Ppa.Mrp_Org_Id, Ppa.Mrp_Org_Code, Rcl.Item_Code, Op.End_Date) Loop
      Begin
        Select Pfa.Avl_Qty
          Into v_Item_Avl_Qty
          From Aps_Pp_Pre_Period_Fg_Avl Pfa
         Where Pfa.Organization_Id = r_Check.Mrp_Org_Id
           And Pfa.Item_Number = r_Check.Item_Code
           And Pfa.Tn_Period = r_Check.End_Date;
      Exception
        When No_Data_Found Then
          v_Item_Avl_Qty := 0;
        When Others Then
          Out_Result := '获取APS周期预约产能失败！' || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
      End;
      If Nvl(v_Item_Avl_Qty, 0) < Nvl(r_Check.To_Plnorder_Qty, 0) Then
        If v_Msg Is Null Then
          v_Msg := '产品编码：' || r_Check.Item_Code;
        Else
          v_Msg := v_Msg || ', ' || r_Check.Item_Code;
        End If;
      End If;
    End Loop;
    If v_Msg Is Not Null Then
      Out_Result := v_Msg || ' 预约产能不足，APS预约失败！';
      Raise v_Base_Exception;
    End If;
    
    Begin
      Select APS_PP_PRE_MA_ORDER_IFACE_S.Nextval Into v_Batch_Id From Dual;
    Exception
      When Others Then
        Out_Result := '获取APS批次序列ID失败！' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;
 
    Begin
    v_Batch_Number := pkg_bd.F_GET_BILL_NO(P_BILL_TYPE  => 'PLN_RESERVATION_BATCH_NUMBER',
                                           P_PREFIX_ADD => Null,
                                           P_ENTITY_ID  => r_Reservation_Head.Entity_Id,
                                           P_USER_ID    => Null);
    Exception
      When Others Then
        Out_Result := '生成批次编号失败，请检查批次编号编码规则：PLN_RESERVATION_BATCH_NUMBER！' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;
    If v_Batch_Number Is Null Then
      Out_Result := '生成批次编号失败，请检查批次编号编码规则：PLN_RESERVATION_BATCH_NUMBER！';
      Raise v_Base_Exception;
    End If;
    
    Begin
      Insert Into Intf_Pln_Reservation_Send
        (Intf_Id,
         Batch_Id,
         Batch_Number,
         Entity_Id,
         Business_Group,
         Organization_Id,
         Order_Number,
         Order_Line_Number,
         Order_Line_Id,
         Item_Code,
         Quantity,
         Customer_Code,
         Period_Date,
         Import_Status,
         Created_By,
         Creation_Date,
         Last_Updated_By,
         Last_Update_Date)
        Select s_Intf_Pln_Reservation_Send.Nextval, --Intf_Id,
               v_Batch_Id, --Batch_Id,
               v_Batch_Number, --batch_number
               Rcl.Entity_Id, --Entity_Id,
               v_Entity_Code, --Business_Group,
               Ppa.Mrp_Org_Id, --Organization_Id,
               Rcl.Order_Number, --Order_Number,
               Rcl.Serial_Number, --Order_Line_Number,
               Rcl.Order_Line_Id, --Order_Line_Id,
               Rcl.Item_Code, --Item_Code,
               Rcl.To_Plnorder_Qty, --quantity
               Rcl.Customer_Code, --Customer_Code,
               v_Period_Date, --Period_Date
               'N', -- Import_Status,
               In_User_Code, -- Created_By,
               Sysdate, --Creation_Date,
               In_User_Code, --Last_Updated_By,
               Sysdate --Last_Update_Date
          From t_Pln_Reservation_Coll_Line Rcl, t_Pln_Producing_Area Ppa
         Where Rcl.Producing_Area_Id = Ppa.Producing_Area_Id
           And Rcl.Reservation_Head_Id = In_Reservation_Head_Id;
    Exception
      When Others Then
        Out_Result := '写入CIMS APS预约接口失败！' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;
    
    --更新提货订单头引入标志
    Update t_Pln_Reservation_Coll_Head Rch
       Set Rch.Reservation_Flag      = 'P',
           rch.batch_id              = v_Batch_Id
     Where Rch.Reservation_Head_Id = In_Reservation_Head_Id;
      
       
    p_Import_Aps_Reservation(In_Batch_Id => v_Batch_Id,
                             Out_Result  => out_Result);
    If Out_Result <> v_Success Then
      Raise v_Base_Exception;
    End If;
    
    Begin
      Select Ppa.Mrp_Org_Id
        Into v_Organization_Id
        From t_Pln_Producing_Area Ppa
       Where Ppa.Entity_Id = r_Reservation_Head.Entity_Id
         And Ppa.Mrp_Org_Code =
             Pkg_Pln_Pub.f_Get_Rcordpara_Collect_Value(In_Entity_Id   => r_Reservation_Head.Entity_Id,
                                                       In_Head_Id     => r_Reservation_Head.Reservation_Head_Id,
                                                       In_Table_Alias => 'PPA',
                                                       In_Column_Code => 'MRP_ORG_CODE')
         And Rownum <= 1;
    Exception
      When Others Then
        Out_Result := '获取产地对应工厂组织ID失败！' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;
    Out_Batch_Id := v_Batch_Id;
    Out_Entity_Code := v_Entity_Code;
    Out_Organization_Id := v_Organization_Id;          
  Exception
    When v_Base_Exception Then
      Rollback;
      Out_Result := '写入接口表数据失败(p_Lg_Aps_Reservation_Send)！' || v_Nl || Out_Result;
    When Others Then
      Rollback;
      Out_Result := '写入接口表数据失败(p_Lg_Aps_Reservation_Send)！' || v_Nl || Out_Result || Sqlerrm;
  End;
  
  -----------------------------------------------------------------------------
  -- AUTHOR  : Nicro.Li
  -- CREATED : 2017-11-02
  -- PURPOSE : 调用APS方法处理已引入的预约数据
  -----------------------------------------------------------------------------
  Procedure p_Aps_Reservation_Request(In_Reservation_Head_Id   In Number, --提货订单头ID               
                                      In_User_Code             In Varchar2,
                                      Out_Result               Out Varchar2                                      
                                      ) Is
    r_Reservation_Head t_pln_reservation_coll_head%Rowtype;
    v_Batch_Id                  Number;
    v_Organization_Id           Number;
    v_Entity_Code               Varchar2(32);
    v_Item_Avl_Qty              Number;
    v_Err_Msg                   Varchar2(4000);
    v_Period_Date               Varchar2(32);
    v_Request_Id                Number;
    v_Deficiency_Flag           Varchar2(3);
  Begin
    Out_Result := v_Success;
    Begin
      Select *
        Into r_Reservation_Head
        From t_Pln_Reservation_Coll_Head Rch
       Where Rch.Reservation_Head_Id = In_Reservation_Head_Id
         For Update Nowait;
    Exception
      When Others Then
        Out_Result := '获取提货订单预约汇总信息失败，汇总头ID：' || To_Char(In_Reservation_Head_Id) || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;
    
    If r_Reservation_Head.To_Plnorder_Flag = 'Y' Or r_Reservation_Head.Reservation_Flag != 'P' Then
      Out_Result := '当前提货订单预约汇总已结转T+3订单或者未引过APS预约接口，提交APS预约处理失败。' || v_Nl ||
                  '汇总单号：' || r_Reservation_Head.Reservation_Coll_Number;
      Raise v_Base_Exception;
    End If;
    
    If r_Reservation_Head.Reservation_Period_Code Is Null Then
      Out_Result := '未设置预约发货日期与预约生产周期！';
      Raise v_Base_Exception;
    Else
      Begin
        Select To_Char(Op.End_Date, 'YYYY-MM-DD')
          Into v_Period_Date
          From t_Pln_Order_Period Op
         Where Op.Entity_Id = r_Reservation_Head.Entity_Id
           And Op.Period_Type = 'T+3周期'
           And Op.Period_Code = r_Reservation_Head.Reservation_Period_Code;
      Exception
        When Others Then
          Out_Result := '获取预约周期日期失败！' || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
      End;
    End If;
    
    Begin
      Select Ue.Entity_Code_Name
        Into v_Entity_Code
        From Up_Codelist Up, Up_Codelist_Entity Ue
       Where Up.Codetype = 'PlnEntityToMainEntity'
         And Up.Id = Ue.Codelist_Id
         And Ue.Entity_Id = r_Reservation_Head.Entity_Id;
    Exception
      When No_Data_Found Then
        Begin
          Select Entity.Entity_Code
            Into v_Entity_Code
            From v_Bd_Entity Entity
           Where Entity.Entity_Id = r_Reservation_Head.Entity_Id;
        Exception
          When Others Then
            Out_Result := '获取主体编码失败，主体ID：' || To_Char(r_Reservation_Head.Entity_Id) || Sqlerrm;
            Raise v_Base_Exception;
        End;
      When Others Then
        Out_Result := '获取主体失败,主体快码PlnEntityToMainEntity' || Sqlerrm;
        Raise v_Base_Exception;
    End;
    
    Begin
      Select Ppa.Mrp_Org_Id
        Into v_Organization_Id
        From t_Pln_Producing_Area Ppa
       Where Ppa.Entity_Id = r_Reservation_Head.Entity_Id
         And Ppa.Mrp_Org_Code =
             Pkg_Pln_Pub.f_Get_Rcordpara_Collect_Value(In_Entity_Id   => r_Reservation_Head.Entity_Id,
                                                       In_Head_Id     => r_Reservation_Head.Reservation_Head_Id,
                                                       In_Table_Alias => 'PPA',
                                                       In_Column_Code => 'MRP_ORG_CODE')
         And Rownum <= 1;
    Exception
      When Others Then
        Out_Result := '获取产地对应工厂组织ID失败！' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;
    Aps_Pp_Pre_Ma_Resource_Pub.Main_Out(p_Bu_Code         => v_Entity_Code,
                                        p_Batch_Id        => r_Reservation_Head.Batch_Id,
                                        p_Organization_Id => v_Organization_Id,
                                        p_Request_Date    => v_Period_Date,
                                        x_Status          => Out_Result, /*X_STATUS:'SUCCESS:成功', 'ERROR:失败'*/
                                        x_Msg_Data        => v_Err_Msg,
                                        x_Request_Id      => v_Request_Id);
    If Out_Result <> v_Success Then
      Out_Result := Out_Result || v_Nl || v_Err_Msg;
      Raise v_Base_Exception;
    Else
      --APS预约处理成功回写汇总行表数据
      For r_Line In (Select *
                       From Intf_Pln_Reservation_Rec Prc
                      Where Prc.Batch_Id = r_Reservation_Head.Batch_Id) Loop
        Begin              
          Update t_Pln_Reservation_Coll_Line Rcl
             Set Rcl.Aps_Reservation_Qty  = r_Line.Reservation_Qty,
                 Rcl.Aps_Reservation_Date = r_Line.Reservation_Date,
                 Rcl.Aps_Rc_Order_Sucess  = r_Line.Order_Schedule_Success
           Where Rcl.Order_Line_Id = r_Line.Order_Line_Id
             And Rcl.Reservation_Head_Id = r_Reservation_Head.Reservation_Head_Id;
        Exception
          When Others Then
            Update Intf_Pln_Reservation_Rec Prc
               Set Prc.Intf_State     = 'E',
                   Prc.Intf_Error_Msg = '更新预约汇总行失败 '
             Where Prc.Intf_Id = r_Line.Intf_Id;
        End;
        --成功则更新接口标志状态
        Update Intf_Pln_Reservation_Rec Prc
           Set Prc.Intf_State = 'Y', Prc.Intf_Error_Msg = Null
         Where Prc.Intf_Id = r_Line.Intf_Id;
         
         If Nvl(v_Deficiency_Flag, 'N') = 'N' Then
           Begin
             Select Case
                      When Nvl(Rcl.To_Plnorder_Qty, 0) >
                           Nvl(Rcl.Aps_Reservation_Qty, 0) Then
                       'Y'
                      Else
                       'N'
                    End
               Into v_Deficiency_Flag
               From t_Pln_Reservation_Coll_Line Rcl
              Where Rcl.Order_Line_Id = r_Line.Order_Line_Id
                And Rcl.Reservation_Head_Id = r_Reservation_Head.Reservation_Head_Id;
           Exception
             When Others Then
               v_Deficiency_Flag := 'Y';             
           End;
         End If;
      End Loop;
      --更新汇总表表引接口状态值
      Update t_Pln_Reservation_Coll_Head Rch
         Set Rch.Reservation_Flag = Decode(v_Deficiency_Flag,
                                           Null,
                                           'D',
                                           'Y',
                                           'D',
                                           'S')
       Where Rch.Reservation_Head_Id = r_Reservation_Head.Reservation_Head_Id;
    End If;
  Exception
    When v_Base_Exception Then
      Rollback;
      --更新汇总表表引接口状态值
      Update t_Pln_Reservation_Coll_Head Rch
         Set Rch.Reservation_Flag = 'E'
       Where Rch.Reservation_Head_Id = In_Reservation_Head_Id;
      Out_Result := '执行APS预约失败(p_Lg_Aps_Reservation_Send)！' || v_Nl || Out_Result;
    When Others Then
      Rollback;
      --更新汇总表表引接口状态值
      Update t_Pln_Reservation_Coll_Head Rch
         Set Rch.Reservation_Flag = 'E'
       Where Rch.Reservation_Head_Id = In_Reservation_Head_Id;
      Out_Result := '执行APS预约失败(p_Lg_Aps_Reservation_Send)！' || v_Nl || Out_Result;
  End;
  
End Pkg_Pln_Intf_Aps;
/

