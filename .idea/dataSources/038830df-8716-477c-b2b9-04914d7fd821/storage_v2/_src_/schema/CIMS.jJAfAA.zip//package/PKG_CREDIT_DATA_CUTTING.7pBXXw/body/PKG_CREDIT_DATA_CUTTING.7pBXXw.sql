create package body PKG_CREDIT_DATA_CUTTING is

  --V_NL             CONSTANT VARCHAR2(2) := CHR(13) || CHR(10); --换行
  V_SEC_RESULT         CONSTANT NUMBER := 0; --成功返回
  V_SUCCESS        CONSTANT VARCHAR2(10) := 'SUCCESS';
  V_BASE_EXCEPTION EXCEPTION; --自定义异常
--------------------------------------------------------------------------------
  /*
  *   创建日期：2014-10-17
  *     创建者：苏冬渊
  *   功能说明：系统切割，调用入口
  *   返回结果：0:成功，-20000：失败
  *
  */
  -------------------------------------------------------------------------------
  PROCEDURE PRC_CREDIT_INIT(P_ENTITY_ID NUMBER) IS
  begin
    PRC_CREDIT_AMOUNT_INIT(P_ENTITY_ID) ;
    --PRC_CREDIT_CUST_GROUP_INIT(P_ENTITY_ID) ;
  END;

PROCEDURE 客户款项余额切割脚本 is
  begin
    null;
  end;

  --------------------------------------------------------------------------------
  /*
  *   创建日期：2014-08-08
  *     创建者：苏冬渊
  *   功能说明：额度组维护模块，额度组内营销大类增加减少时进行客户款项新增或者变更
               维护信用模块的客户款项信息
  *   返回结果：0:成功，-20000：失败
  *
  */
  -------------------------------------------------------------------------------
  PROCEDURE PRC_CREDIT_AMOUNT_INIT(P_ENTITY_ID NUMBER) IS
    i integer;
  p_result NUMBER;
  p_err_msg VARCHAR2(2000);
  --V_CREDIT_GROUP_ID T_SALES_ACCOUNT_AMOUNT.CREDIT_GROUP_ID%TYPE := 1 ;
  --V_ENTITY_ID T_SALES_ACCOUNT_AMOUNT.ENTITY_ID%TYPE := 10 ;
  V_received_amount T_SALES_ACCOUNT_AMOUNT.RECEIVED_AMOUNT%TYPE ;
  V_discount_amount T_SALES_ACCOUNT_AMOUNT.DISCOUNT_AMOUNT%TYPE ;
  V_COUNT Number ;
  begin
  -- Test statements herke
  FOR I IN (SELECT * FROM T_CUSTOMER_SALES_MAIN_TYPE t Where t.entity_id = P_ENTITY_ID) LOOP
    pkg_credit_business_due.prc_credit_cust_category_init(p_entity_id => I.ENTITY_ID,
                                                        p_customer_id => I.CUSTOM_ID,
                                                        p_sales_main_type => I.SALES_MAIN_TYPE_CODE,
                                                        p_proj_number => NULL,
                                                        p_username => 'init',
                                                        p_result => p_result,
                                                        p_err_msg => p_err_msg);

    FOR L IN (
            SELECT T.ROWID, T.*
              FROM T_SALES_ACCOUNT_MX_AMOUNT T
             WHERE T.ENTITY_ID = I.ENTITY_ID
               AND T.CUSTOMER_ID = I.Custom_Id
               AND T.SALES_MAIN_TYPE = I.SALES_MAIN_TYPE_CODE
               And t.entity_id = P_ENTITY_ID) LOOP
          --获取到款金额，折让金额（数据切割，老系统的余额）-----------款项明细
          BEGIN
            --获取到款明细余额
            SELECT NVL(SUM(T.AMOUNT),0)
              INTO V_received_amount
              FROM T_AR_CASH_RECEIPT_HEADERS T,T_AR_CASH_RECEIPT_LINES N
             WHERE T.CASH_RECEIPT_ID = N.CASH_RECEIPT_ID
               AND T.ENTITY_ID = L.ENTITY_ID
               AND T.CUSTOMER_ID = L.CUSTOMER_ID
               AND T.ACCOUNT_ID = L.ACCOUNT_ID
               AND N.Sales_Main_Type_Code = L.Sales_Main_Type;
          EXCEPTION WHEN OTHERS THEN
            V_received_amount := 0 ;
          END ;
          --获取折让明细余额
          BEGIN
            SELECT NVL(SUM(B.PLUS_MINUS_FLAG * A.DISCOUNT_AMOUNT),0)
              INTO V_discount_amount
              FROM T_SO_HEADER A, V_SO_BILL_TYPE_EXTEND B
             WHERE A.BILL_TYPE_ID = B.BILL_TYPE_ID
               AND A.ENTITY_ID = L.ENTITY_ID
               AND A.CUSTOMER_ID = L.CUSTOMER_ID
               AND A.ACCOUNT_ID = L.ACCOUNT_ID
               AND A.SALES_MAIN_TYPE = L.Sales_Main_Type
               --AND B.BILL_TYPE_CODE IN ('1028', '1029');
               AND B.SRC_TYPE_CODE IN ('1009', '1010');
          EXCEPTION WHEN OTHERS THEN
            V_discount_amount := 0 ;
          END ;
          --更新客户款项明细信息
          BEGIN
            UPDATE T_SALES_ACCOUNT_MX_AMOUNT T
               SET T.RECEIVED_AMOUNT = V_received_amount,
                   T.DISCOUNT_AMOUNT = V_discount_amount
             WHERE T.ROWID = L.ROWID;
          EXCEPTION WHEN OTHERS THEN
            p_result := -1 ;
            p_err_msg := sqlcode || '   ' || sqlerrm ;
            return ;
          END ;
      END LOOP ;
  END LOOP ;

  --初始化到款余额，折让余额
  V_received_amount := 0 ;
  V_discount_amount := 0 ;

  FOR J IN (Select Distinct A.ENTITY_ID,
                   A.Customer_id,
                   A.CUSTOMER_CODE,
                   d.customer_name,
                   A.Account_id,
                   a.account_code,
                   a.account_name,
                   B.Credit_Group_Id
              From T_Customer_Account          a,
                   T_Credit_Category_Group_Rel b,
                   T_Customer_Sales_Main_Type  c,
                   t_customer_header d
             Where A.Customer_Id = C.Custom_Id
               And a.customer_id = d.customer_id
               And C.Sales_Main_Type_Code = B.Sales_Main_Type
               And a.entity_id = c.entity_id
               And a.entity_id = P_ENTITY_ID
               --add by liangym2 2017-6-15 要判断所属额度组是否匹配
               And B.CREDIT_GROUP_ID = pkg_credit_tools.FUN_GET_CREDITGROUPID(A.ENTITY_ID,A.customer_id,b.SALES_MAIN_TYPE,A.ACCOUNT_ID)
               ) LOOP
    --获取到款金额，折让金额（数据切割，老系统的余额）
    BEGIN
      --获取到款余额
      SELECT NVL(SUM(a.amount),0)
        INTO V_received_amount
        FROM T_AR_CASH_RECEIPT_HEADERS T,t_ar_cash_receipt_lines a
       WHERE t.CASH_RECEIPT_ID = a.cash_receipt_id
         And T.ENTITY_ID = J.ENTITY_ID
         AND T.CUSTOMER_ID = J.CUSTOMER_ID
         AND T.ACCOUNT_ID = J.ACCOUNT_ID
         --2017-4-22 获取额度组增加账户ID liangym2
         And pkg_credit_tools.FUN_GET_CREDITGROUPID(T.ENTITY_ID,t.customer_id,a.sales_main_type_code,T.ACCOUNT_ID) = j.credit_group_id ;
    EXCEPTION WHEN OTHERS THEN
      V_received_amount := 0 ;
    END ;
    --获取折让余额
    BEGIN
      SELECT NVL(SUM(B.PLUS_MINUS_FLAG * A.DISCOUNT_AMOUNT),0)
        INTO V_discount_amount
        FROM T_SO_HEADER A, V_SO_BILL_TYPE_EXTEND B
       WHERE A.BILL_TYPE_ID = B.BILL_TYPE_ID
         AND A.ENTITY_ID = J.ENTITY_ID
         AND A.CUSTOMER_ID = J.CUSTOMER_ID
         AND A.ACCOUNT_ID = J.ACCOUNT_ID
         --2017-4-22 获取额度组增加账户ID liangym2
         And pkg_credit_tools.FUN_GET_CREDITGROUPID(A.ENTITY_ID,A.customer_id,a.sales_main_type,A.ACCOUNT_ID) = j.credit_group_id
         --AND B.BILL_TYPE_CODE IN ('1028', '1029') ;
         AND B.SRC_TYPE_CODE IN ('1009', '1010') ;
    EXCEPTION WHEN OTHERS THEN
      V_discount_amount := 0 ;
    END ;

    Select Count(*)
      Into V_Count
      From T_Sales_Account_Amount t
     Where T.Entity_Id = J.Entity_Id
       And T.Customer_Id = J.Customer_Id
       And T.Account_Id = J.Account_Id
       And T.Credit_Group_Id = J.Credit_Group_Id;

   If V_COUNT <= 0 Then
      --插入客户款项信息
      begin
        INSERT INTO T_SALES_ACCOUNT_AMOUNT(
              account_amount_id,
              entity_id,
              credit_group_id,
              proj_number,
              customer_id,
              customer_code,
              customer_name,
              account_id,
              account_code,
              account_name,
              sales_year_id,
              received_amount,
              sales_amount,
              lock_received_amount,
              delaypay_amount,
              temp_delaypay_amount,
              discount_amount,
              applied_discount_amount,
              freeze_discount_amount,
              lock_discount_amount,
              dispay_amount,
              amount_crtl_flag,
              discont_crtl_flag,
              creation_date,
              created_by,
              last_update_date,
              last_updated_by,
              three_not_pay,
              active_flag)
        SELECT  S_SALES_ACCOUNT_AMOUNT.NEXTVAL account_amount_id,
                J.ENTITY_ID entity_id,
                j.credit_group_id ,
                NULL proj_number,
                J.CUSTOMER_ID customer_id,
                J.CUSTOMER_CODE customer_code,
                j.customer_name customer_name,
                J.ACCOUNT_ID account_id,
                J.ACCOUNT_CODE account_code,
                J.ACCOUNT_NAME account_name,
                NULL sales_year_id,
                V_received_amount received_amount,
                0 sales_amount,
                0 lock_received_amount,
                0 delaypay_amount,
                0 temp_delaypay_amount,
                V_discount_amount discount_amount,
                0 applied_discount_amount,
                0 freeze_discount_amount,
                0 lock_discount_amount,
                0 dispay_amount,
                '0' amount_crtl_flag,
                '0' discont_crtl_flag,
                SYSDATE creation_date,
                'init' created_by,
                SYSDATE last_update_date,
                'init' last_updated_by,
                0 three_not_pay,
                '1' active_flag
                FROM dual ;
        exception when others then
          p_result := -1 ;
          p_err_msg := sqlcode || '   ' || sqlerrm ;
          return ;
        end ;
    Elsif v_count > 0 Then
      Begin
        Update T_Sales_Account_Amount t
           Set T.Received_Amount  = V_Received_Amount,
               T.Discount_Amount  = V_Discount_Amount,
               T.Last_Update_Date = Sysdate,
               T.Last_Updated_By  = 'init'
         Where T.Entity_Id = J.Entity_Id
           And T.Customer_Id = J.Customer_Id
           And T.Credit_Group_Id = J.Credit_Group_Id
           And T.Account_Id = J.Account_Id
           And rownum = 1;
      Exception When Others Then
         p_result := -1 ;
         p_err_msg := sqlcode || '   ' || sqlerrm ;
         return ;
      End ;
    End If ;
  END LOOP ;
  END;

  PROCEDURE 客户组关系切割脚本 is
  begin
    null;
  end;

  --------------------------------------------------------------------------------
  /*
  *   创建日期：2014-10-14
  *     创建者：苏冬渊
  *   功能说明：系统切割，将客户信息添加进默认客户组
  *   返回结果：0:成功，-20000：失败
  *
  */
  -------------------------------------------------------------------------------
  PROCEDURE PRC_CREDIT_CUST_GROUP_INIT(P_ENTITY_ID NUMBER) IS
    p_result NUMBER ;
    p_err_msg VARCHAR2(1000) ;
  begin
    FOR I IN (SELECT * FROM T_CUSTOMER_DEPT T WHERE T.DEPT_ID = P_ENTITY_ID) LOOP
        PKG_CREDIT_BUSINESS_DUE.prc_credit_customer_init(p_entity_id => I.DEPT_ID,
                                 p_customer_id => I.CUSTOMER_ID,
                                 p_username => 'INIT',
                                 p_result => p_result,
                                 p_err_msg => p_err_msg) ;
    END LOOP ;
  END;
  
  PROCEDURE PRC_CREDIT_DATA_CUT(P_ENTITY_ID NUMBER) IS
    v_rn number;
  begin
    v_rn := 0;
    for li in (select t.cust_amount_id
                 from T_SALES_AMOUNT_FREEZE t
                where t.entity_id = P_ENTITY_ID
                  and t.ACCOUNT_AMOUNT_ID is null) loop
      update T_SALES_AMOUNT_FREEZE T
         set ACCOUNT_AMOUNT_ID = NVL((SELECT A.ACCOUNT_AMOUNT_ID FROM T_SALES_ACCOUNT_AMOUNT A
            WHERE A.ENTITY_ID = T.ENTITY_ID
            AND A.CUSTOMER_ID = T.CUSTOMER_ID
            AND A.ACCOUNT_ID = T.ACCOUNT_ID
            AND (A.PROJ_NUMBER = T.PROJ_NUMBER OR (A.PROJ_NUMBER IS NULL OR T.PROJ_NUMBER IS NULL))
            AND A.CREDIT_GROUP_ID = PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(T.ENTITY_ID,T.CUSTOMER_ID,T.SALES_MAIN_TYPE,T.ACCOUNT_ID)
            ),0)
       where cust_amount_id = li.cust_amount_id;
      --commit;
      v_rn := (1 + v_rn);
      if 1000 = v_rn then
        v_rn := 0;
        commit;
      end if;
    end loop;
    commit;
    v_rn := 0;
    for li in (select t.cust_amount_id
                 from T_SALES_AMOUNT_FREEZE t
                where t.entity_id = P_ENTITY_ID
                  and freeze_date > trunc(freeze_date)) loop
      update T_SALES_AMOUNT_FREEZE
         set freeze_time = 1 + freeze_date
       where cust_amount_id = li.cust_amount_id;
      --commit;
      update T_SALES_AMOUNT_FREEZE
         set freeze_date = trunc(freeze_date)
       where cust_amount_id = li.cust_amount_id;
      --commit;
      v_rn := (1 + v_rn);
      if 1000 = v_rn then
        v_rn := 0;
        commit;
      end if;
    end loop;
    commit;
  END;

  PROCEDURE 铺底核销过程 is
  begin
    null;
  end;


  /*--获取客户到款余额
    参数：P_ENTITY_ID：主体ID
          P_CUSTOMER_ID：客户ID
          P_ACCOUNT_ID：账户ID
          P_SALES_MAIN_TYPE：营销大类
   */
  Function FUN_GET_AMOUNT_BALANCE(P_ENTITY_ID Number,
                                  P_CUSTOMER_ID Number ,
                                  P_ACCOUNT_ID Number,
                                  P_SALES_MAIN_TYPE Varchar2) Return Number Is
     v_amount_balance Number ;
     V_DIS_RECEIPT_AMOUNT Number ;
     V_DIS_SALES_AMOUNT Number ;
     --v_amount_three_lock Number ;
     v_credit_group_id Number ;
  Begin
     --根据客户以及营销大类获取对应的额度组ID
     --2017-4-22 获取额度组增加账户ID liangym2
     v_credit_group_id := pkg_credit_tools.FUN_GET_CREDITGROUPID(P_ENTITY_ID,P_CUSTOMER_ID,P_SALES_MAIN_TYPE,P_ACCOUNT_ID) ;
     --获取该客户该大类对应额度组下三方承兑未解付金额
     /*begin
       Select nvl(sum(pkg_credit_tools.FUN_GET_THREE_AMOUNT(a.cash_receipt_id,b.sales_main_type_code,3)),0)
        Into v_amount_three_lock
       From t_ar_cash_receipt_headers a, T_AR_CASH_RECEIPT_LINES b,t_ar_receipt_methods c
       Where a.cash_receipt_id = b.cash_receipt_id
         And a.receipt_method_id = c.receipt_method_id
         And a.entity_id = c.entity_id
         And a.entity_id = P_ENTITY_ID
         And a.customer_id = P_CUSTOMER_ID
         And a.account_id = P_ACCOUNT_ID
         And c.receipt_type = '3' --承兑
         And v_credit_group_id = pkg_credit_tools.FUN_GET_CREDITGROUPID(a.ENTITY_ID,a.CUSTOMER_ID,b.sales_main_type_code) ;
    Exception When Others Then
      v_amount_three_lock := 0 ;
    End ;*/

    --获取客户到款余额（当前有效铺底金额也可以核销到期的铺底单据）
    Begin
      Select (t.received_amount - t.sales_amount + t.delaypay_amount + t.temp_delaypay_amount
              - t.three_not_pay + T.MPAY_STREAM_AMOUNT - T.MPAY_CASH_AMOUNT)
       Into v_amount_balance
      From t_sales_account_amount t Where
      t.entity_id = P_ENTITY_ID
      And t.customer_id = P_CUSTOMER_ID
      And t.account_id = P_ACCOUNT_ID
      And t.credit_group_id = v_credit_group_id
      And t.active_flag = '1' ;
    Exception When Others Then
      v_amount_balance := 0 ;
    End ;
    
    Begin
      Select SUM(NVL(T.RECEIPT_AMOUNT,0)),SUM(NVL(T.SALES_AMOUNT,0))
       Into V_DIS_RECEIPT_AMOUNT,V_DIS_SALES_AMOUNT
      From T_CREDIT_DISCOUNT_AMOUNT t Where
      t.entity_id = P_ENTITY_ID
      AND T.CUSTOMER_ID = P_CUSTOMER_ID
      And t.account_id = P_ACCOUNT_ID
      And v_credit_group_id = PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(P_ENTITY_ID,T.CUSTOMER_ID,T.SALES_MAIN_TYPE,T.ACCOUNT_ID);
    Exception When Others Then
      V_DIS_RECEIPT_AMOUNT := 0 ;
      V_DIS_SALES_AMOUNT := 0 ;
    End ;

    --v_amount_balance := v_amount_balance - v_amount_three_lock ;
    /*If v_amount_balance < 0 Then
      v_amount_balance := 0 ;
    End If ;*/
    Return v_amount_balance + NVL(V_DIS_RECEIPT_AMOUNT,0) - NVL(V_DIS_SALES_AMOUNT,0) ;
  End ;

  /*--获取客户到款余额
    参数：P_ENTITY_ID：主体ID
          P_CUSTOMER_ID：客户ID
          P_ACCOUNT_ID：账户ID
          P_CREDIT_GROUP_ID：额度组ID
   */
  Function FUN_GET_AMOUNT_BALANCE_GROUP(P_ENTITY_ID Number,
                                        P_CUSTOMER_ID Number ,
                                        P_ACCOUNT_ID Number,
                                        P_CREDIT_GROUP_ID Number) Return Number Is
     v_amount_balance Number ;
     V_DIS_RECEIPT_AMOUNT Number ;
     V_DIS_SALES_AMOUNT Number ;
     --v_amount_three_lock Number ;
  Begin
     --获取该客户该大类对应额度组下三方承兑未解付金额
     /*begin
       Select nvl(sum(pkg_credit_tools.FUN_GET_THREE_AMOUNT(a.cash_receipt_id,b.sales_main_type_code,3)),0)
        Into v_amount_three_lock
       From t_ar_cash_receipt_headers a, T_AR_CASH_RECEIPT_LINES b,t_ar_receipt_methods c
       Where a.cash_receipt_id = b.cash_receipt_id
         And a.receipt_method_id = c.receipt_method_id
         And a.entity_id = c.entity_id
         And a.entity_id = P_ENTITY_ID
         And a.customer_id = P_CUSTOMER_ID
         And a.account_id = P_ACCOUNT_ID
         And c.receipt_type = '3' --承兑
         And P_CREDIT_GROUP_ID = pkg_credit_tools.FUN_GET_CREDITGROUPID(a.ENTITY_ID,a.CUSTOMER_ID,b.sales_main_type_code) ;
    Exception When Others Then
      v_amount_three_lock := 0 ;
    End ;*/

    --获取客户到款余额
    Begin
      Select (t.received_amount - t.sales_amount + t.delaypay_amount + t.temp_delaypay_amount
              - t.three_not_pay + T.MPAY_STREAM_AMOUNT - T.MPAY_CASH_AMOUNT)
       Into v_amount_balance
      From t_sales_account_amount t Where
      t.entity_id = P_ENTITY_ID
      And t.customer_id = P_CUSTOMER_ID
      And t.account_id = P_ACCOUNT_ID
      And t.credit_group_id = P_CREDIT_GROUP_ID
      And t.active_flag = '1' ;
    Exception When Others Then
      v_amount_balance := 0 ;
    End ;
    
    Begin
      Select SUM(NVL(T.RECEIPT_AMOUNT,0)),SUM(NVL(T.SALES_AMOUNT,0))
       Into V_DIS_RECEIPT_AMOUNT,V_DIS_SALES_AMOUNT
      From T_CREDIT_DISCOUNT_AMOUNT t Where
      t.entity_id = P_ENTITY_ID
      AND T.CUSTOMER_ID = P_CUSTOMER_ID
      And t.account_id = P_ACCOUNT_ID
      And P_CREDIT_GROUP_ID = PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(P_ENTITY_ID,T.CUSTOMER_ID,T.SALES_MAIN_TYPE,T.ACCOUNT_ID);
    Exception When Others Then
      V_DIS_RECEIPT_AMOUNT := 0 ;
      V_DIS_SALES_AMOUNT := 0 ;
    End ;

    --v_amount_balance := v_amount_balance - v_amount_three_lock ;
    /*If v_amount_balance < 0 Then
      v_amount_balance := 0 ;
    End If ;*/
    Return v_amount_balance + NVL(V_DIS_RECEIPT_AMOUNT,0) - NVL(V_DIS_SALES_AMOUNT,0) ;
  End ;

  /*--获取客户逾期欠款余额
  参数：P_ENTITY_ID：主体ID
          P_CUSTOMER_ID：客户ID
          P_ACCOUNT_ID：账户ID
          P_SALES_MAIN_TYPE：营销大类
   */
  Function FUN_GET_AMOUNT_OVERDUE(P_ENTITY_ID Number,
                                  P_CUSTOMER_ID Number ,
                                  P_ACCOUNT_ID Number,
                                  P_SALES_MAIN_TYPE Varchar2) Return Number Is
     v_amount_overdue Number ;
     v_credit_group_id Number ;
  Begin
     --根据客户以及营销大类获取对应的额度组ID
     --2017-4-22 获取额度组增加账户ID liangym2
     v_credit_group_id := pkg_credit_tools.FUN_GET_CREDITGROUPID(P_ENTITY_ID,P_CUSTOMER_ID,P_SALES_MAIN_TYPE,P_ACCOUNT_ID) ;
     --获取逾期欠款金额
     Select Nvl(Sum(Nvl(T.Transaction_Amount, 0)), 0)
      Into V_Amount_Overdue
      From T_Credit_Delaypay t
     Where T.Entity_Id = P_Entity_Id
       And T.Customer_Id = P_Customer_Id
       And T.Account_Id = P_Account_Id
       And V_Credit_Group_Id =
       --2017-4-22 获取额度组增加账户ID liangym2
           Pkg_Credit_Tools.Fun_Get_Creditgroupid(T.Entity_Id,
                                                  T.Customer_Id,
                                                  T.Sales_Main_Type,T.ACCOUNT_ID)
       And T.Payed_Flag = '0' --是否还清（1：是；0：否）
       And T.Overdue_Flag = '1' ; --是否逾期（1：是；0：否）

    If V_Amount_Overdue < 0 Then
      V_Amount_Overdue := 0 ;
    End If ;
    Return V_Amount_Overdue ;
  End ;


  /*--获取客户逾期欠款余额
    参数：P_ENTITY_ID：主体ID
          P_CUSTOMER_ID：客户ID
          P_ACCOUNT_ID：账户ID
          P_CREDIT_GROUP_ID：额度组ID
   */
  Function FUN_GET_AMOUNT_OVERDUE_GROUP(P_ENTITY_ID Number,
                                        P_CUSTOMER_ID Number ,
                                        P_ACCOUNT_ID Number,
                                        P_CREDIT_GROUP_ID Number) Return Number Is
     v_amount_overdue Number ;
  Begin
     --获取逾期欠款金额
     Select Nvl(Sum(Nvl(T.Transaction_Amount, 0)), 0)
      Into V_Amount_Overdue
      From T_Credit_Delaypay t
     Where T.Entity_Id = P_Entity_Id
       And T.Customer_Id = P_Customer_Id
       And T.Account_Id = P_Account_Id
       And P_CREDIT_GROUP_ID =
           Pkg_Credit_Tools.Fun_Get_Creditgroupid(T.Entity_Id,
                                                  T.Customer_Id,
                                                  T.Sales_Main_Type,T.ACCOUNT_ID)
       And T.Payed_Flag = '0' --是否还清（1：是；0：否）
       And T.Overdue_Flag = '1' ; --是否逾期（1：是；0：否）

    If V_Amount_Overdue < 0 Then
      V_Amount_Overdue := 0 ;
    End If ;
    Return V_Amount_Overdue ;
  End ;
  --------------------------------------------------------------------------------
  /*
  *   创建日期：2015-03-31
  *     创建者：苏冬渊
  *   功能说明：铺底核销过程，强制到期时候调用，根据到款余额核销铺底单据
                到款余额=到款金额-销售金额-三方承兑锁定金额
      备注：由于跟业务符总确认，锁款认为是未使用铺底，
            所以使用到款余额核销时候，不需要减去锁定到款金额
  *   返回结果：0:成功，-20000：失败
  *
  */
  -------------------------------------------------------------------------------
  PROCEDURE PRC_CREDIT_DELAYPAY_PAUSE(P_BILL_ID NUMBER,
                                      p_result Out NUMBER ,
                                      p_err_msg Out Varchar2 ) IS
    ROW_CREDIT_DELAYPAY T_CREDIT_DELAYPAY%Rowtype ;
    v_amount_balance Number ; --到款余额
    v_amount_overdue Number ; --逾期欠款总额
    thisDate Date := Sysdate ;
    v_Accrual_Ky_Amount Number := 0 ; --跨月利息
    entityGroupCode Varchar2(100) ;
    v_year_rate Number ;
  Begin
     p_result := V_SEC_RESULT  ;
     p_err_msg := V_SUCCESS ;

     --获取铺底单据信息
     Begin
       Select T.* Into ROW_CREDIT_DELAYPAY From T_CREDIT_DELAYPAY T
       Where T.BILL_ID = P_BILL_ID ;
     Exception When Others Then
       p_result := -20000 ;
       p_err_msg := '根据单据ID获取单据信息出错！' || Sqlerrm  ;
       Return ;
     End ;
     --获取到款余额
     v_amount_balance := FUN_GET_AMOUNT_BALANCE(ROW_CREDIT_DELAYPAY.ENTITY_ID,
                                                ROW_CREDIT_DELAYPAY.Customer_Id,
                                                ROW_CREDIT_DELAYPAY.Account_Id,
                                                ROW_CREDIT_DELAYPAY.Sales_Main_Type) ;
    --获取逾期欠款
    v_amount_overdue := FUN_GET_AMOUNT_OVERDUE( ROW_CREDIT_DELAYPAY.ENTITY_ID,
                                                ROW_CREDIT_DELAYPAY.Customer_Id,
                                                ROW_CREDIT_DELAYPAY.Account_Id,
                                                ROW_CREDIT_DELAYPAY.Sales_Main_Type) ;
    --当到款余额大于0，则应该将所有到期或者逾期铺底全部核销，标志位已还清
    --当到款余额小于0，则应该在到款余额上刨去逾期欠款的部分，才得到应该用来核销本期到期的铺底的金额
    If v_amount_balance < 0 Then
       v_amount_balance := v_amount_balance + v_amount_overdue ;
    End If ;

     --获取主体组编码
    entityGroupCode := pkg_bd.F_GET_PARAMETER_VALUE('ar_entity_group',ROW_CREDIT_DELAYPAY.Entity_Id,null,null);
     --到款余额>= 0,则该铺底单据没有用来提货,全部核销，不产生逾期
     --或者审批金额<= 0 ,说明临时铺底申请的金额为负数，则直接核销，不产生逾期
     If v_amount_balance >= 0 Or nvl(ROW_CREDIT_DELAYPAY.Approval_Amount,0) <= 0 Then
        If entityGroupCode = 'JXS' And ROW_CREDIT_DELAYPAY.Delaypay_Type = '1' Then --如果是跨月，则算跨月利息
           --获取利息计算年利率
           Begin
             Select t.year_rate Into v_year_rate
               From T_Credit_Delaypay_Configue t
              Where T.Entity_Id = Row_Credit_Delaypay.Entity_Id
                And T.Bill_Type_Id = Row_Credit_Delaypay.Bill_Type_Id
                And T.Delaypay_Type = Row_Credit_Delaypay.Delaypay_Type
                And Rownum = 1;
           Exception When Others Then
             v_year_rate := 0 ;
           End ;
           --计算跨月利息，天数（当前日期-最终审批日期）
           v_Accrual_Ky_Amount := round(ROW_CREDIT_DELAYPAY.APPROVAL_AMOUNT *
           (trunc(thisDate) - trunc(nvl(ROW_CREDIT_DELAYPAY.LAST_APPROVAL_TIME,thisDate))) *
            v_year_rate / 360,2) ;
        End If ;
        --更新铺底单据核销信息
        Begin
          Update t_credit_delaypay t
            Set t.actualpay_date = thisDate ,
                t.pay_date = thisDate,
                t.payed_flag = '1',  --是否还清（1：是；0：否）
                t.Transaction_Amount = 0 , --未核销金额
                t.Bring_Accrual_Amount = 0 , --产生逾期利息金额
                t.bring_accrual_days = 0 , --产生逾期利息天数
                t.Accrual_Amount = 0 , --逾期利息金额
                t.Overdue_Flag = '0' , --是否逾期（1：是；0：否）
                t.Accrual_Ky_Amount = v_Accrual_Ky_Amount  --跨月利息
            Where t.bill_id = P_BILL_ID ;
        Exception When Others Then
          p_result := -20000 ;
          p_err_msg := '更新铺底单据信息出错！' || Sqlerrm  ;
          Return ;
        End ;
     Elsif v_amount_balance < 0 Then
        --|到款余额| >= 审批金额，则认为本张铺底单据金额都已经用来提货
        If abs(v_amount_balance) >= ROW_CREDIT_DELAYPAY.Approval_Amount Then
           --更新铺底单据核销信息
          Begin
            Update t_credit_delaypay t
              Set t.payed_flag = '0',  --是否还清（1：是；0：否）
                  t.Transaction_Amount = ROW_CREDIT_DELAYPAY.Approval_Amount  --未核销金额
              Where t.bill_id = P_BILL_ID ;
          Exception When Others Then
             p_result := -20000 ;
             p_err_msg := '更新铺底单据信息出错！' || Sqlerrm  ;
             Return ;
          End ;

        Elsif abs(v_amount_balance) < ROW_CREDIT_DELAYPAY.Approval_Amount Then
           --更新铺底单据核销信息
          Begin
            Update t_credit_delaypay t
              Set t.payed_flag = '0',  --是否还清（1：是；0：否）
                  t.Transaction_Amount = abs(v_amount_balance)  --未核销金额
              Where t.bill_id = P_BILL_ID ;
          Exception When Others Then
             p_result := -20000 ;
             p_err_msg := '更新铺底单据信息出错！' || Sqlerrm  ;
             Return ;
          End ;
        End If ;
     End If ;
  END;

  --------------------------------------------------------------------------------
  /*
  *   创建日期：2015-04-01
  *     创建者：苏冬渊
  *   功能说明：处理信用模块中的铺底到期
                查询到期日期小于等于当前日期的铺底申请单据，进行到期操作
  *   t_sales_account_amount
  *   t_sales_account_mx_amount
      t_credit_delaypay
  */
  -------------------------------------------------------------------------------
  PROCEDURE PRC_CREDIT_DELAYPAY_DUE_DATE IS

    CURSOR CUR_T_CREDIT_DELAYPAY IS
    Select T.*
      FROM T_CREDIT_DELAYPAY T
     WHERE TRUNC(Sysdate) > TRUNC(NVL(T.DELAY_DATE, T.End_Date))
       AND T.BILL_STATUS = 3
       AND NVL(T.DUE_BY,'0') = '0' ; --DUE_BY为空则标示没有进行过到期操作

    P_RESULT  NUMBER ;
    P_ERR_MSG VARCHAR2(4000) ;
    v_action_type NUMBER ;
    v_order_type  varchar2(30) ;
  BEGIN
    P_RESULT  := V_SEC_RESULT;
    P_ERR_MSG := V_SUCCESS ;

    FOR I IN CUR_T_CREDIT_DELAYPAY LOOP
      --单据没有进行过强制到期时，必须先进行单据的到期操作
       IF I.BILL_TYPE_ID = 1 THEN --常规铺底
          v_action_type := 25 ;
          v_order_type := '常规铺底' ;

       ELSIF I.BILL_TYPE_ID = 2 THEN --超额铺底
          v_action_type := 25 ;
          v_order_type := '超额铺底' ;

       ELSIF I.BILL_TYPE_ID = 3 AND I.DELAYPAY_TYPE <> 8 THEN
          v_action_type := 26 ;
          v_order_type := '临时铺底' ;

       ELSIF I.BILL_TYPE_ID = 3 AND I.DELAYPAY_TYPE = 8 THEN
          v_action_type := 27 ;
          v_order_type := '临时铺底(折让)' ;

       ELSE
          GOTO HERE ;
       END IF ;

       pkg_credit_account_control.prc_credit_sales_bill(p_entity_id => I.ENTITY_ID,
                             p_action_type => v_action_type,
                             p_settlement_sum => I.APPROVAL_AMOUNT,
                             p_discount_sum => NULL,
                             p_sales_main_type => I.SALES_MAIN_TYPE,
                             p_account_id => I.ACCOUNT_ID,
                             p_customer_id => I.CUSTOMER_ID,
                             p_proj_number => NULL,
                             p_created_mode => NULL,
                             p_order_id => I.BILL_ID,
                             p_order_type => v_order_type,
                             p_username => '铺底核销',
                             p_result => p_result,
                             p_err_msg => p_err_msg);

       IF p_result <> V_SEC_RESULT THEN
          --到期操作失败，跳到下一个到期单据进行处理
          GOTO HERE ;
       END IF ;

       --更新铺底单据相关数据项信息
       BEGIN
         UPDATE T_CREDIT_DELAYPAY T
          SET T.TRANSACTION_AMOUNT = T.APPROVAL_AMOUNT,
              T.Due_By = '自动到期',
              T.DUE_TIME = NVL(I.DELAY_DATE,I.End_Date),
              t.Last_Updated_By = '自动到期',
              t.last_update_date = Sysdate
        WHERE T.BILL_ID = I.BILL_ID ;
       EXCEPTION WHEN OTHERS THEN
         GOTO HERE ;
       END ;
      <<HERE>>
      null ;
    END LOOP ;

  EXCEPTION WHEN OTHERS THEN
      NULL ;
  END; --PRC_CREDIT_DELAYPAY_DUE_DATE

  --------------------------------------------------------------------------------
  /*
  *   创建日期：2015-04-01
  *     创建者：苏冬渊
  *   功能说明：铺底核销过程，计划还款日期的第二天启动核销，核销的是前一天到期的单据，使用到款余额进行核销
                逾期的另外处理，不在本模块核销。

      备注：由于跟业务符总确认，锁款认为是未使用铺底，
            所以使用到款余额核销时候，不需要减去锁定到款金额
  *   返回结果：0:成功，-20000：失败
  *
  */
  -------------------------------------------------------------------------------
  PROCEDURE PRC_CREDIT_DELAYPAY_APPLIED Is

    v_amount_balance Number ; --到款余额
    v_amount_overdue Number ; --逾期欠款总额
    thisDate Date := Sysdate - 1 ;
    v_Accrual_Ky_Amount Number := 0 ; --跨月利息
    entityGroupCode Varchar2(100) ;
    v_year_rate Number ;

    p_result Number ;
    p_err_msg Varchar2(200) ;

    Cursor cur_cust_acco_group Is
      Select Distinct t.entity_id,
                      t.customer_id,
                      t.account_id,--2017-4-22 获取额度组增加账户ID liangym2
                      pkg_credit_tools.FUN_GET_CREDITGROUPID(t.entity_id,
                                                             t.customer_id,
                                                             t.sales_main_type,T.ACCOUNT_ID) credit_group_id
                      From t_credit_delaypay t
                 Where trunc(thisDate) = trunc(nvl(t.delay_date,t.planpay_date))
                   And t.payed_flag = '0'  --是否还清（1：是；0：否）
                   And t.bill_status In ('3','6') ;
  Begin

     For i In cur_cust_acco_group Loop
         --获取到款余额
         v_amount_balance := FUN_GET_AMOUNT_BALANCE_GROUP(i.ENTITY_ID,
                                                          i.Customer_Id,
                                                          i.Account_Id,
                                                          i.credit_group_id) ;
         --获取逾期欠款
         v_amount_overdue := FUN_GET_AMOUNT_OVERDUE_GROUP(i.ENTITY_ID,
                                                          i.Customer_Id,
                                                          i.Account_Id,
                                                          i.credit_group_id) ;
         --当到款余额大于0，则应该将所有到期或者逾期铺底全部核销，标志位已还清
         --当到款余额小于0，则应该在到款余额上刨去逾期欠款的部分，才得到应该用来核销本期到期的铺底的金额
         If v_amount_balance < 0 Then
            v_amount_balance := v_amount_balance + v_amount_overdue ;
         End If ;

         --获取主体组编码
         entityGroupCode := pkg_bd.F_GET_PARAMETER_VALUE('ar_entity_group',i.Entity_Id,null,null);

         For j In (Select t.* From t_credit_delaypay t Where t.entity_id = i.entity_id
                          And t.customer_id = i.customer_id
                          And t.account_id = i.account_id
                          --2017-4-22 获取额度组增加账户ID liangym2
                          And i.credit_group_id = pkg_credit_tools.FUN_GET_CREDITGROUPID(t.entity_id,
                                                                                         t.customer_id,
                                                                                         t.sales_main_type,T.ACCOUNT_ID)
                          And trunc(thisDate) = trunc(nvl(t.delay_date,t.planpay_date))
                          And t.payed_flag = '0' --是否还清（1：是：0：否）
                          And t.bill_status In ('3','6')
                          Order By nvl(t.transaction_amount,0) Desc) Loop

            --获取铺底单据的跨月利息金额
            If entityGroupCode = 'JXS' And j.Delaypay_Type = '1' Then --如果是跨月，则算跨月利息
                   --获取利息计算年利率
                   Begin
                     Select t.year_rate
                       Into v_year_rate
                       From T_Credit_Delaypay_Configue t
                      Where T.Entity_Id = j.Entity_Id
                        And T.Bill_Type_Id = j.Bill_Type_Id
                        And T.Delaypay_Type = j.Delaypay_Type
                        And Rownum = 1;
                   Exception When Others Then
                     v_year_rate := 0 ;
                   End ;
                   --计算跨月利息，天数（当前日期-最终审批日期）
                   v_Accrual_Ky_Amount := round(j.APPROVAL_AMOUNT *
                   (trunc(thisDate) - trunc(nvl(j.LAST_APPROVAL_TIME,thisDate))) *
                   v_year_rate / 360,2) ;
            End If ;


            --若是到款余额>0,则该客户，账户，额度组下的所有铺底都应该直接核销掉
            --或者审批金额<= 0 ,说明临时铺底申请的金额为负数，则直接核销，不产生逾期
            If v_amount_balance >= 0 Or nvl(j.transaction_amount,0) <= 0 Then
                --更新铺底单据核销信息
                Begin
                  Update t_credit_delaypay t
                    Set t.actualpay_date = thisDate ,
                        t.pay_date = thisDate,
                        t.payed_flag = '1',  --是否还清（1：是；0：否）
                        t.Transaction_Amount = 0 , --未核销金额
                        t.Bring_Accrual_Amount = 0 , --产生逾期利息金额
                        t.bring_accrual_days = 0 , --产生逾期利息天数
                        t.Accrual_Amount = 0 , --逾期利息金额
                        t.Overdue_Flag = '0' , --是否逾期（1：是；0：否）
                        t.Accrual_Ky_Amount = v_Accrual_Ky_Amount  --跨月利息
                    Where t.bill_id = j.bill_id ;
               Exception When Others Then
                  Goto here_1 ;
               End ;
            Elsif v_amount_balance < 0 Then
                --|到款余额| >= 审批金额，则认为本张铺底单据金额都已经用来提货
                If abs(v_amount_balance) >= nvl(j.transaction_amount,0) Then

                  --更新铺底单据核销信息
                  Begin
                    Update t_credit_delaypay t
                      Set t.payed_flag = '0', --是否还清（1：是；0：否）
                          t.Overdue_Flag = '1' , --是否逾期（1：是；0：否）
                          t.bring_accrual_amount = nvl(j.transaction_amount,0),
                          t.Accrual_Ky_Amount = v_Accrual_Ky_Amount  --跨月利息
                      Where t.bill_id = j.bill_id ;
                  Exception When Others Then
                    Goto here_1 ;
                  End ;

                  /**-生成不良记录
                   *  销售公司模式的主体，只有常规铺底才记不良记录
                   */
                  If (entityGroupCode = 'XSGS' And j.bill_type_id = 1)
                     Or (entityGroupCode = 'JXS' And j.bill_type_id In (1,2)) Then
                    PRC_CREDIT_DELAYPAY_BADRECORD(row_credit_delaypay => j,
                                                  p_result => p_result ,
                                                  p_err_msg => p_err_msg)  ;
                  End If ;
                  --到款余额减去核销的部分（v_amount_balance < 0）
                  v_amount_balance := v_amount_balance + nvl(j.transaction_amount,0) ;

                Elsif abs(v_amount_balance) < nvl(j.transaction_amount,0) Then
                  --更新铺底单据核销信息
                  Begin
                    Update t_credit_delaypay t
                      Set t.payed_flag = '0', --是否还清（1：是；0：否）
                          t.Overdue_Flag = '1' , --是否逾期（1：是；0：否）
                          t.Accrual_Ky_Amount = v_Accrual_Ky_Amount,  --跨月利息
                          t.Transaction_Amount = abs(v_amount_balance),  --未核销金额
                          t.bring_accrual_amount = abs(v_amount_balance)
                      Where t.bill_id = j.bill_id ;
                   Exception When Others Then
                     Goto here_1 ;
                   End ;

                  /**-生成不良记录
                   *  销售公司模式的主体，只有常规铺底才记不良记录
                      经销商模式的主体，临时铺底不记不良记录
                   */
                  If (entityGroupCode = 'XSGS' And j.bill_type_id = 1)
                     Or (entityGroupCode = 'JXS' And j.bill_type_id In (1,2)) Then
                      PRC_CREDIT_DELAYPAY_BADRECORD(row_credit_delaypay => j,
                                                    p_result => p_result ,
                                                    p_err_msg => p_err_msg)  ;
                  End If ;

                  v_amount_balance := 0 ;

                End If ;
             End If ;
             <<here_1>>
             --重置变量
             v_Accrual_Ky_Amount := 0 ;
         End Loop ;
     End Loop ;

  END;

  --------------------------------------------------------------------------------
  /*
  *   创建日期：2015-04-09
  *     创建者：苏冬渊
  *   功能说明：铺底核销过程，对逾期的铺底记录不良记录

  *   返回结果：0:成功，-20000：失败
  *
  */
  -------------------------------------------------------------------------------
  PROCEDURE PRC_CREDIT_DELAYPAY_BADRECORD(row_credit_delaypay t_credit_delaypay%Rowtype,
                                          p_result Out NUMBER ,
                                          p_err_msg Out Varchar2) Is
     v_count Number ;
     entityGroupCode Varchar2(100) ;
  Begin
     p_result := V_SEC_RESULT  ;
     p_err_msg := V_SUCCESS ;

     --获取主体组编码
     entityGroupCode := pkg_bd.F_GET_PARAMETER_VALUE('ar_entity_group',row_credit_delaypay.Entity_Id,null,null);
     --销售公司模式的铺底是可多笔叠加的，
     --因此一个月能会有多笔铺底逾期，但是每个月只记一次不良记录
     If entityGroupCode = 'XSGS' Then
       Select Count(1)
         Into V_Count
         From T_Credit_Bad_Record t
        Where T.Entity_Id = Row_Credit_Delaypay.Entity_Id
          And T.Customer_Id = Row_Credit_Delaypay.Customer_Id
          And T.Account_Id = Row_Credit_Delaypay.Account_Id
          And T.Active_Flag = '1' --有效
          And T.Bad_Record_Type = '1'--不良记录类型为逾期
          And trunc(t.creation_date,'MM') = trunc(Sysdate,'MM');

        If v_count > 0 Then
           Goto here ;
        End If ;
     End If ;

     Insert Into t_credit_bad_record(
        bad_record_id,
        entity_id,
        customer_id,
        customer_code,
        customer_name,
        account_id,
        account_code,
        account_name,
        sales_region_id,
        sales_region_code,
        sales_region_name,
        sales_center_id,
        sales_center_code,
        sales_center_name,
        sales_main_type,
        bad_record_type,
        active_flag,
        created_by,
        creation_date,
        last_updated_by,
        last_update_date,
        pay_date,
        counter,
        bill_id
     )Select s_credit_bad_record.nextval,
             row_credit_delaypay.entity_id,
             row_credit_delaypay.customer_id,
             row_credit_delaypay.customer_code,
             row_credit_delaypay.customer_name,
             row_credit_delaypay.account_id,
             row_credit_delaypay.account_code,
             row_credit_delaypay.account_name,
             row_credit_delaypay.sales_region_id,
             row_credit_delaypay.sales_region_code,
             row_credit_delaypay.sales_region_name,
             row_credit_delaypay.sales_center_id,
             row_credit_delaypay.sales_center_code,
             row_credit_delaypay.sales_center_name,
             row_credit_delaypay.sales_main_type,
             '1', --1:逾期
             '1' , --有效状态（1：有效；2：无效）
             '铺底核销',
             Sysdate ,
             '铺底核销',
             Sysdate ,
             Null , --还清日期
             1 , --不良记录次数
             row_credit_delaypay.bill_id
             From dual ;
      <<here>>
      Null ;
  Exception When Others Then
      p_result := -20000  ;
      p_err_msg := '生成不良记录出错！' || Sqlerrm  ;
      Return ;
  END;

  --------------------------------------------------------------------------------
  /*
  *   创建日期：2015-04-09
  *     创建者：苏冬渊
  *   功能说明：铺底核销过程
                对逾期的铺底单据，当产生销售红冲，退货，折让证明单，销售折让单
                  结算退货单，收款确认，三方承兑解付时，会进行逾期铺底核销
                其中：
  *   返回结果：0:成功，-20000：失败
  *
  */
  -------------------------------------------------------------------------------
  PROCEDURE PRC_CREDIT_DELAYPAY_APPLIED_AT Is

    v_amount Number := 0 ; --款项行可用余额
    thisDate Date := Sysdate - 1 ;
    v_Accrual_Amount Number := 0 ; --逾期利息
    v_overdue_days Number := 0 ; --逾期天数

    TYPE CUR_SALES_AMOUNT_TRANS IS TABLE OF T_SALES_AMOUNT_TRANS%ROWTYPE INDEX BY BINARY_INTEGER;
    rows_sales_amount_trans CUR_SALES_AMOUNT_TRANS ;

    v_dis_amount Number := 0 ; --当天被冲销金额

    p_result Number ;
    p_err_msg Varchar2(200) ;

    Cursor cur_cust_acco_group Is
      Select Distinct t.entity_id,
                      t.customer_id,
                      t.account_id,
                      --2017-4-22 获取额度组增加账户ID liangym2
                      pkg_credit_tools.FUN_GET_CREDITGROUPID(t.entity_id,
                                                             t.customer_id,
                                                             t.sales_main_type,T.ACCOUNT_ID) credit_group_id
                      From t_credit_delaypay t
                 Where t.payed_flag = '0'  --是否还清（1：是；0：否）
                   And t.overdue_flag = '1' --是否逾期（1：是；0：否）
                   And t.bill_status In ('3','6') ;
  Begin

     For i In cur_cust_acco_group Loop
         --获取当天进行的到款业务，退货，销售红冲等都会对客户到款余额产生影响，可以用来核销逾期的铺底
         /* 4：开单（销售红冲单）
          * 5:开单（退货单）
          * 7：开单（折让证明单）
          * 9：开单（销售折让单）
          * 13：结算（退货单）
          * 14：结算（销售单）
          * 15：收款确认
          * 19：三方承兑解付
          */
        Begin
         Select T.* Bulk Collect
           Into Rows_Sales_Amount_Trans
           From (Select A.*
                   From T_Sales_Amount_Trans a
                  Where A.Entity_Id = I.Entity_Id
                    And A.Customer_Id = I.Customer_Id
                    And A.Account_Id = I.Account_Id
                    And A.Credit_Group_Id = I.Credit_Group_Id
                    And Trunc(A.Creation_Date) = Trunc(Thisdate)
                    And A.Amount > 0
                    And A.Action_Flag In (4, 5, 7, 9, 13, 15, 19)
                    And A.Amount_Name In ('销售金额', '到款金额', '锁定到款金额')
                 Union All
                 Select A.*
                   From T_Sales_Amount_Trans a
                  Where A.Entity_Id = I.Entity_Id
                    And A.Customer_Id = I.Customer_Id
                    And A.Account_Id = I.Account_Id
                    And A.Credit_Group_Id = I.Credit_Group_Id
                    And Trunc(A.Creation_Date) = Trunc(Thisdate)
                    And A.Amount < 0
                    And A.Action_Flag = 14
                    And A.Amount_Name = '销售金额') t;
       Exception When Others Then
          Null ; --获取款项行出错，不处理，当款项获取不到时候，会逐个逾期铺底单据计算利息
       End ;

         --获取主体组编码
         --entityGroupCode := pkg_bd.F_GET_PARAMETER_VALUE('ar_entity_group',i.Entity_Id,null,null);

         For j In (Select t.* From t_credit_delaypay t Where t.entity_id = i.entity_id
                          And t.customer_id = i.customer_id
                          And t.account_id = i.account_id
                          --2017-4-22 获取额度组增加账户ID liangym2
                          And i.credit_group_id = pkg_credit_tools.FUN_GET_CREDITGROUPID(t.entity_id,
                                                                                         t.customer_id,
                                                                                         t.sales_main_type,T.ACCOUNT_ID)
                          And t.payed_flag = '0' --是否还清（1：是：0：否）
                          And t.overdue_flag = '1' --是否逾期（1：是；0：否）
                          And t.bill_status In ('3','6')
                          Order By nvl(t.delay_date,t.planpay_date) Asc) Loop

            --若是Rows_Sales_Amount_Trans.count>0,则说明当天有进行多可以核销逾期铺底的款项操作。
            --按款项情况逐行进行逾期铺底核销
            If Rows_Sales_Amount_Trans.count > 0 Then
               For k In 1 .. Rows_Sales_Amount_Trans.count Loop
                   /*** add by sudy 2015-04-27
                    *  如果准备用来核销铺底的单据在同一天被冲销了的话，不能用来核销铺底
                       1、到款单，查看是否有同一天的冲销单据存在。
                       2、其他单据查看是否被冲销（4、销售红冲单，5、退货单，7、折让证明单
                                                  9、销售折让单，15、收款确认）
                    */
                If Rows_Sales_Amount_Trans(k).PRE_FIELD_01 Is Null Then
                   --到款单，查看是否被冲销
                   If Rows_Sales_Amount_Trans(k).action_flag = 15 Then
                     Begin
                        Select nvl(sum(t.amount),0)
                          Into v_dis_amount
                          From T_Sales_Amount_Trans t
                        Where t.entity_id = Rows_Sales_Amount_Trans(k).entity_id
                          And t.customer_id = Rows_Sales_Amount_Trans(k).customer_id
                          And t.account_id = Rows_Sales_Amount_Trans(k).account_id
                          And t.sales_main_type = Rows_Sales_Amount_Trans(k).sales_main_type
                          And t.action_flag = 16
                          And t.amount_name = '到款金额'
                          And t.order_id = Rows_Sales_Amount_Trans(k).order_id --冲销ID存放的是原单ID
                          And trunc(t.creation_date) = trunc(Rows_Sales_Amount_Trans(k).creation_date) ;
                      Exception When Others Then
                        Null ;
                      End ;
                   --三方解付
                   ELSIf Rows_Sales_Amount_Trans(k).action_flag = 19 Then
                     Begin
                        Select nvl(sum(t.amount),0)
                          Into v_dis_amount
                          From T_Sales_Amount_Trans t
                        Where t.entity_id = Rows_Sales_Amount_Trans(k).entity_id
                          And t.customer_id = Rows_Sales_Amount_Trans(k).customer_id
                          And t.account_id = Rows_Sales_Amount_Trans(k).account_id
                          And t.sales_main_type = Rows_Sales_Amount_Trans(k).sales_main_type
                          And t.action_flag = 20
                          And t.amount_name = '锁定到款金额'
                          And t.order_id = Rows_Sales_Amount_Trans(k).order_id --冲销ID存放的是原单ID
                          And trunc(t.creation_date) = trunc(Rows_Sales_Amount_Trans(k).creation_date) ;
                      Exception When Others Then
                        Null ;
                      End ;
                   --退货单，折让证明单，销售折让单，查看是否被冲销
                   Elsif Rows_Sales_Amount_Trans(k).action_flag In (5,7,9) Then
                        Begin
                         Select nvl(sum(t.amount),0)
                           Into v_dis_amount
                           From T_Sales_Amount_Trans t
                          Where t.entity_id = Rows_Sales_Amount_Trans(k).entity_id
                            And t.customer_id = Rows_Sales_Amount_Trans(k).customer_id
                            And t.account_id = Rows_Sales_Amount_Trans(k).account_id
                            And t.sales_main_type = Rows_Sales_Amount_Trans(k).sales_main_type
                            And t.action_flag = decode(Rows_Sales_Amount_Trans(k).action_flag,5,6,7,8,9,10)
                            And t.amount_name = '销售金额'
                            And trunc(t.creation_date) = trunc(Rows_Sales_Amount_Trans(k).creation_date)
                            And t.order_id In (
                                 Select a.So_Header_Id
                                   From T_So_Header a
                                  Where A.Orig_So_Num = (Select T.So_Num
                                                      From T_So_Header t
                                                     Where T.So_Header_Id = Rows_Sales_Amount_Trans(k).Order_Id
                                                       And rownum = 1)) ;
                        Exception When Others Then
                          Null ;
                        End ;
                   End If ;
                  End If ;
                  --如果v_dis_amount <> 0 ,则说明单据被冲销了（全部冲销或者部分冲销）
                  If v_dis_amount > 0 Then
                    If Rows_Sales_Amount_Trans(k).amount <= v_dis_amount Then
                       Rows_Sales_Amount_Trans(k).PRE_FIELD_01 := '2' ; --已经全部被冲销，置核销完成
                       Rows_Sales_Amount_Trans(k).SALES_YEAR_ID := 0 ;  --可用核销金额为0
                    Elsif Rows_Sales_Amount_Trans(k).amount > v_dis_amount Then
                       Rows_Sales_Amount_Trans(k).PRE_FIELD_01 := '1' ; --部分被冲销，置部分核销标示
                       Rows_Sales_Amount_Trans(k).SALES_YEAR_ID := (Rows_Sales_Amount_Trans(k).amount - v_dis_amount) ;  --可用核销金额为Rows_Sales_Amount_Trans(k).amount - v_dis_amount
                    End If ;
                  End If ;


                   --如果款项行上已经核销完成则跳到下一行款项行
                   If nvl(Rows_Sales_Amount_Trans(k).PRE_FIELD_01,'0') = '2' Then
                      Goto here_1 ;
                   Elsif nvl(Rows_Sales_Amount_Trans(k).PRE_FIELD_01,'0') = '0' then
                      v_amount := Rows_Sales_Amount_Trans(k).amount ;
                   Elsif nvl(Rows_Sales_Amount_Trans(k).PRE_FIELD_01,'0') = '1' Then
                      v_amount := Rows_Sales_Amount_Trans(k).SALES_YEAR_ID ;
                   End If ;

                   /**如果款项行金额 > 铺底未核销金额
                    *  1、铺底单据：还清标示置上，铺底利息计算，未核销金额置0
                    *  2、款项行上，几下剩余可用金额，置上部分核销标示。
                           款项行核销标示：0：未开始核销，1：部分核销，2：核销完成
                       3、记下款项行与铺底单据之间的核销关系
                    */
                   If v_amount > nvl(j.transaction_amount,0) Then

                      Begin
                         --更新铺底单据核销信息
                         Update t_credit_delaypay t
                          Set t.actualpay_date = thisDate ,
                              t.pay_date = thisDate,
                              t.payed_flag = '1',  --是否还清（1：是；0：否）
                              t.Transaction_Amount = 0  --未核销金额
                          Where t.bill_id = j.bill_id ;

                         --更新款项行的核销标示，剩余可用金额
                         Rows_Sales_Amount_Trans(k).SALES_YEAR_ID := v_amount - nvl(j.transaction_amount,0) ;
                         Rows_Sales_Amount_Trans(k).PRE_FIELD_01 := '1' ; --部分核销
                         --插入单据核销关系记录表数据
                         Insert Into t_credit_delaypa_applied(
                            bill_id,
                            applied_id,
                            cash_receipt_id,
                            three_pay_id,
                            applied_amount,
                            applied_status,
                            created_by,
                            creation_date,
                            last_updated_by,
                            last_update_date,
                            action_flag
                         )Select j.bill_id,
                                 s_credit_delaypa_applied.nextval,
                                 Rows_Sales_Amount_Trans(k).order_id ,
                                 Null , --三方承兑解付ID
                                 nvl(j.transaction_amount,0), --核销金额
                                 '1', --核销状态（1：已核销；2：已冲销）
                                 '铺底核销',
                                 thisDate ,
                                 '铺底核销',
                                 thisDate,
                                 Rows_Sales_Amount_Trans(k).action_flag
                         From dual ;

                         --铺底已经还清，需要将产生的不良记录状态修改
                         Update T_Credit_Bad_Record t
                            Set T.Pay_Date = Thisdate, T.Active_Flag = '2'
                          Where T.Bill_Id = J.Bill_Id;

                          --对单据上的未核销金额进行维护
                          j.transaction_amount := 0 ;

                      Exception When Others Then
                        p_err_msg := Sqlcode || Sqlerrm ;
                        Goto here_1 ;
                      End ;
                       --逾期铺底已经核销完成，跳出铺底单据行循环
                       Goto here_2 ;

                   /**如果款项行金额 = 铺底未核销金额
                    *  1、铺底单据：还清标示置上，铺底利息计算，未核销金额置0
                    *  2、款项行上，记下剩余可用金额=0，置上核销完成标示。
                           款项行核销标示：0：未开始核销，1：部分核销，2：核销完成
                       3、记下款项行与铺底单据之间的核销关系
                    */
                   Elsif v_amount = nvl(j.transaction_amount,0) Then
                       Begin
                           --更新铺底单据核销信息
                           Update t_credit_delaypay t
                            Set t.actualpay_date = thisDate ,
                                t.pay_date = thisDate,
                                t.payed_flag = '1',  --是否还清（1：是；0：否）
                                t.Transaction_Amount = 0  --未核销金额
                            Where t.bill_id = j.bill_id ;

                           --更新款项行的核销标示，剩余可用金额
                           Rows_Sales_Amount_Trans(k).SALES_YEAR_ID := 0 ;
                           Rows_Sales_Amount_Trans(k).PRE_FIELD_01 := '2' ; --核销完成
                           --插入单据核销关系记录表数据
                           Insert Into t_credit_delaypa_applied(
                              bill_id,
                              applied_id,
                              cash_receipt_id,
                              three_pay_id,
                              applied_amount,
                              applied_status,
                              created_by,
                              creation_date,
                              last_updated_by,
                              last_update_date,
                              action_flag
                           )Select j.bill_id,
                                   s_credit_delaypa_applied.nextval,
                                   Rows_Sales_Amount_Trans(k).order_id ,
                                   Null , --三方承兑解付ID
                                   nvl(j.transaction_amount,0), --核销金额
                                   '1', --核销状态（1：已核销；2：已冲销）
                                   '铺底核销',
                                   thisDate ,
                                   '铺底核销',
                                   thisDate,
                                   Rows_Sales_Amount_Trans(k).action_flag
                           From dual ;

                         --铺底已经还清，需要将产生的不良记录状态修改
                         Update T_Credit_Bad_Record t
                            Set T.Pay_Date = Thisdate, T.Active_Flag = '2'
                          Where T.Bill_Id = J.Bill_Id;

                          --对单据上的未核销金额进行维护
                          j.transaction_amount := 0 ;

                       Exception When Others Then
                         p_err_msg := Sqlcode || Sqlerrm ;
                          Goto here_1 ;
                       End ;

                       --逾期铺底已经核销完成，跳出铺底单据行循环
                       Goto here_2 ;


                   /**如果款项行金额 < 铺底未核销金额
                    *  1、铺底单据：铺底利息计算，未核销金额 = 未核销金额 - 到款行金额
                    *  2、款项行上，记下剩余可用金额=0，置上核销完成标示。
                           款项行核销标示：0：未开始核销，1：部分核销，2：核销完成
                       3、记下款项行与铺底单据之间的核销关系
                    */
                   Elsif v_amount < nvl(j.transaction_amount,0) Then
                       Begin
                           --更新铺底单据核销信息
                           Update t_credit_delaypay t
                            Set t.Transaction_Amount = nvl(t.Transaction_Amount,0) - v_amount  --未核销金额
                            Where t.bill_id = j.bill_id ;

                           --更新款项行的核销标示，剩余可用金额
                           Rows_Sales_Amount_Trans(k).SALES_YEAR_ID := 0 ;
                           Rows_Sales_Amount_Trans(k).PRE_FIELD_01 := '2' ; --核销完成
                           --插入单据核销关系记录表数据
                           Insert Into t_credit_delaypa_applied(
                              bill_id,
                              applied_id,
                              cash_receipt_id,
                              three_pay_id,
                              applied_amount,
                              applied_status,
                              created_by,
                              creation_date,
                              last_updated_by,
                              last_update_date,
                              action_flag
                           )Select j.bill_id,
                                   s_credit_delaypa_applied.nextval,
                                   Rows_Sales_Amount_Trans(k).order_id ,
                                   Null , --三方承兑解付ID
                                   v_amount, --核销金额
                                   '1', --核销状态（1：已核销；2：已冲销）
                                   '铺底核销',
                                   thisDate ,
                                   '铺底核销',
                                   thisDate,
                                   Rows_Sales_Amount_Trans(k).action_flag
                           From dual ;

                          --对单据上的未核销金额进行维护
                          j.transaction_amount := j.transaction_amount - v_amount ;

                      Exception When Others Then
                        p_err_msg := Sqlcode || Sqlerrm ;
                         Goto here_1 ;
                      End ;
                   End If ;
                   <<here_1>>
                   --重置变量
                   v_amount := 0  ;
                  End Loop ;
             End If ;

             --计算利息
             PRC_CREDIT_DELAYPAY_ACCRUAL(row_credit_delaypay => j ,
                                         p_overdue_days => v_overdue_days , --逾期天数
                                         p_Accrual_Amount => v_Accrual_Amount , --逾期金额
                                         p_result => p_result ,
                                         p_err_msg => p_err_msg ) ;

             --如果存储过程执行成功，则更新铺底利息信息
             If p_result = V_SEC_RESULT Then
                Begin
                  Update T_Credit_Delaypay t
                     Set T.Bring_Accrual_Days = V_Overdue_Days,
                         T.Accrual_Amount     = V_Accrual_Amount
                   Where T.Bill_Id = J.Bill_Id;
                Exception When Others Then
                   Goto here_2 ;
                End ;
             End If ;


             <<here_2>>
             --重置变量
             v_overdue_days := 0 ;
             v_Accrual_Amount := 0 ;
             v_dis_amount := 0 ;

         End Loop ;
     End Loop ;

  END;

  --------------------------------------------------------------------------------
  /*
  *   创建日期：2015-04-11
  *     创建者：苏冬渊
  *   功能说明：铺底核销过程中，根据情况计算铺底的利息。

  *   返回结果：0:成功，-20000：失败
  *
  */
  -------------------------------------------------------------------------------
  PROCEDURE PRC_CREDIT_DELAYPAY_ACCRUAL(row_credit_delaypay t_credit_delaypay%Rowtype,
                                        p_overdue_days Out Number , --逾期天数
                                        p_Accrual_Amount Out Number , --逾期利息金额
                                        p_result Out NUMBER ,
                                        p_err_msg Out Varchar2) Is

     entityGroupCode Varchar2(100) ; --主体组
     thisDate Date := Sysdate - 1 ;
     v_overdue_year_rate Number ;
  Begin
     p_result := V_SEC_RESULT  ;
     p_err_msg := V_SUCCESS ;

     p_overdue_days := 0 ;
     p_Accrual_Amount := 0 ;

     --获取逾期利息计算年利率
     Begin
       Select t.OVERDUE_YEAR_RATE
         Into v_overdue_year_rate
         From T_Credit_Delaypay_Configue t
        Where T.Entity_Id = row_credit_delaypay.Entity_Id
          And T.Bill_Type_Id = row_credit_delaypay.Bill_Type_Id
          And T.Delaypay_Type = row_credit_delaypay.Delaypay_Type
          And Rownum = 1;
     Exception When Others Then
       v_overdue_year_rate := 0 ;
     End ;

     --获取主体组编码
     entityGroupCode := pkg_bd.F_GET_PARAMETER_VALUE('ar_entity_group',row_credit_delaypay.entity_id,null,null);

     --如果为销售公司模式，则只算常规铺底的利息
     If entityGroupCode = 'XSGS' Then
       If row_credit_delaypay.bill_type_id = '1' Then
          --获取计算逾期利息天数
          p_overdue_days := CEIL(MONTHS_BETWEEN(nvl(row_credit_delaypay.delay_date,row_credit_delaypay.planpay_date),thisDate)) ;
          p_Accrual_Amount := round(row_credit_delaypay.bring_accrual_amount *  --逾期金额
                                    p_overdue_days * --逾期月数
                                    v_overdue_year_rate/12 ) ; --月利率
       End If ;
     --如果为经销商模式，则所有铺底都计算利息
     Elsif entityGroupCode = 'JXS' Then
       --获取计算逾期利息天数
       p_overdue_days := ceil(thisDate-NVL(row_credit_delaypay.Delay_Date,row_credit_delaypay.Planpay_Date)) ;
       p_Accrual_Amount := round(row_credit_delaypay.bring_accrual_amount *  --逾期金额
                                 p_overdue_days * --逾期月数
                                 v_overdue_year_rate/360 ) ; --日利率
     End If ;

  END;

  --------------------------------------------------------------------------------
  /*
  *   创建日期：2015-04-11
  *     创建者：苏冬渊
  *   功能说明：铺底核销过程
                对逾期的铺底单据，使用销售红冲、退货、折让证明、销售折让、退货结算、
                销售单结算、收款确认进行核销，如果已经核销完成或者部分核销；
                此时反向操作，比如：退货红冲、折让证明红冲、销售折让红冲、收款冲销
                需要将已经核销的铺底单据回退
  *   返回结果：0:成功，-20000：失败
  *
  */
  -------------------------------------------------------------------------------
  PROCEDURE PRC_CREDIT_DELAYPAY_APPLIED_HS Is

    thisDate Date := Sysdate - 1 ;
    v_Accrual_Amount Number := 0 ; --逾期利息
    v_overdue_days Number := 0 ; --逾期天数

    Row_Credit_Delaypay T_Credit_Delaypay%Rowtype ;

    TYPE CUR_SALES_AMOUNT_TRANS IS TABLE OF T_SALES_AMOUNT_TRANS%ROWTYPE INDEX BY BINARY_INTEGER;
    rows_sales_amount_trans CUR_SALES_AMOUNT_TRANS ;

    TYPE CUR_SO_HEADER_ID IS TABLE OF T_SO_HEADER.SO_HEADER_ID%type INDEX BY BINARY_INTEGER;
    rows_so_header_id CUR_SO_HEADER_ID ;

    v_trans_id t_sales_amount_trans.trans_id%Type ;

    p_result Number ;
    p_err_msg Varchar2(200) ;


  Begin
        --获取当天进行的到款业务，退货，销售红冲等都会对客户到款余额产生影响，可以用来核销逾期的铺底
         /* 6:开单（退货红冲单）
          * 8：开单（折让证明红冲单）
          * 10：开单（销售折让红冲单）
          * 16：收款冲销
          */
        Begin
           Select A.* Bulk Collect
             Into Rows_Sales_Amount_Trans
             From T_Sales_Amount_Trans a
            Where Trunc(A.Creation_Date) = Trunc(Thisdate)
              And A.Amount > 0
              And A.Action_Flag In (6, 8, 10, 16, 20)
              And A.Amount_Name In ('销售金额', '到款金额', '锁定到款金额');
        Exception When Others Then
          Null ; --获取款项行出错，不处理，当款项获取不到时候，会逐个逾期铺底单据计算利息
        End ;

         --获取主体组编码
         --entityGroupCode := pkg_bd.F_GET_PARAMETER_VALUE('ar_entity_group',i.Entity_Id,null,null);

        For i In 1 .. Rows_Sales_Amount_Trans.count Loop

          --根据冲销单据ID获取原单据ID
          If Rows_Sales_Amount_Trans(i).action_flag In (6,8,10) Then
             Begin
               Select a.So_Header_Id Bulk Collect
                 Into rows_so_header_id
                 From T_So_Header a
                Where A.So_Num = (Select T.Orig_So_Num
                                    From T_So_Header t
                                   Where T.So_Header_Id = Rows_Sales_Amount_Trans(i)
                                        .Order_Id
                                     And rownum = 1);
             Exception When Others Then
                Null ;
             End ;


             For j In 1 .. rows_so_header_id.count Loop
                --检查是否存在同一天的正向单，有则不能用本单据来进行核销回退
                Begin
                  Select TRANS_ID Into v_trans_id From T_Sales_Amount_Trans t
                  Where t.entity_id = Rows_Sales_Amount_Trans(i).entity_id
                    And t.customer_id = Rows_Sales_Amount_Trans(i).customer_id
                    And t.account_id = Rows_Sales_Amount_Trans(i).account_id
                    And t.sales_main_type = Rows_Sales_Amount_Trans(i).sales_main_type
                    And t.action_flag = decode(Rows_Sales_Amount_Trans(i).action_flag,6,5,8,7,10,9)
                    And t.order_id = rows_so_header_id(j)
                    And trunc(t.creation_date) = Trunc(Thisdate)
                    And rownum = 1  ;
                Exception When Others Then
                  Null ;
                End ;
                --如果同一天的正向单，则跳过本次核销回退动作
                If v_trans_id Is Not Null Then
                   Goto here ;
                End If ;
               --根据逾期核销记录信息中记录的铺底单据ID以及核销金额进行核销回退
               For k In (Select T.*
                   From T_Credit_Delaypa_Applied t
                  Where T.Cash_Receipt_Id = rows_so_header_id(j)
                    And t.action_flag In (6,8,10)
                    And t.applied_status = '1' ) Loop

                    Begin
                       --更新铺底单据上的信息
                       Update T_Credit_Delaypay T1
                          Set T1.Pay_Date           = Null, --还清日期置空
                              T1.Payed_Flag         = '0', --是否还清（1：是；0：否）
                              T1.Transaction_Amount = Nvl(T1.Transaction_Amount,
                                                          0) +
                                                      Nvl(K.Applied_Amount, 0)
                        Where T1.Bill_Id = K.Bill_Id;


                       --更新逾期核销记录信息
                       Update T_Credit_Delaypa_Applied t2 Set
                       t2.applied_status = '2'  --核销状态（1：已核销；2：已冲销）
                        Where t2.applied_id = k.applied_id ;

                       /** 有可能之前铺底单据已经核销完成，但是单据冲销之后，
                          铺底单据的利息金额是需要重新算的
                        */
                       Select T3.*
                         Into Row_Credit_Delaypay
                         From T_Credit_Delaypay T3
                        Where T3.Bill_Id = K.Bill_Id;

                       --计算利息
                       PRC_CREDIT_DELAYPAY_ACCRUAL(row_credit_delaypay => Row_Credit_Delaypay ,
                                                   p_overdue_days => v_overdue_days , --逾期天数
                                                   p_Accrual_Amount => v_Accrual_Amount , --逾期金额
                                                   p_result => p_result ,
                                                   p_err_msg => p_err_msg ) ;

                       If p_result = V_SEC_RESULT Then
                          --更新铺底单据上的铺底利息信息
                          Update T_Credit_Delaypay T1
                            Set t1.bring_accrual_days = v_overdue_days ,
                                t1.accrual_amount = v_Accrual_Amount
                          Where T1.Bill_Id = K.Bill_Id;
                       End If ;

                    Exception When Others Then
                      Null ;
                    End ;

                   --重置变量
                   Row_Credit_Delaypay := Null ;
                   v_overdue_days := 0 ;
                   v_Accrual_Amount := 0 ;
               End Loop ;
             End Loop ;

          --收款冲销，传的是原单ID
          Elsif Rows_Sales_Amount_Trans(i).action_flag = 16 Then
             --检查是否存在同一天的正向单，有则不能用本单据来进行核销回退
            Begin
              Select TRANS_ID Into v_trans_id From T_Sales_Amount_Trans t
              Where t.entity_id = Rows_Sales_Amount_Trans(i).entity_id
                And t.customer_id = Rows_Sales_Amount_Trans(i).customer_id
                And t.account_id = Rows_Sales_Amount_Trans(i).account_id
                And t.sales_main_type = Rows_Sales_Amount_Trans(i).sales_main_type
                And t.action_flag = 15
                And t.order_id = Rows_Sales_Amount_Trans(i).Order_Id
                And trunc(t.creation_date) = Trunc(Thisdate)
                And rownum = 1  ;
            Exception When Others Then
              Null ;
            End ;
            --如果同一天的正向单，则跳过本次核销回退动作
            If v_trans_id Is Not Null Then
               Goto here ;
            End If ;

             For k In (Select T.*
                   From T_Credit_Delaypa_Applied t
                  Where T.Cash_Receipt_Id = Rows_Sales_Amount_Trans(i).Order_Id
                    And t.action_flag = 16
                    And t.applied_status = '1') Loop
                  Begin
                       --更新铺底单据上的信息
                       Update T_Credit_Delaypay T1
                          Set T1.Pay_Date           = Null, --还清日期置空
                              T1.Payed_Flag         = '0', --是否还清（1：是；0：否）
                              T1.Transaction_Amount = Nvl(T1.Transaction_Amount,
                                                          0) +
                                                      Nvl(K.Applied_Amount, 0)
                        Where T1.Bill_Id = K.Bill_Id;


                       --更新逾期核销记录信息
                       Update T_Credit_Delaypa_Applied t2 Set
                       t2.applied_status = '2'  --核销状态（1：已核销；2：已冲销）
                       Where t2.applied_id = k.applied_id ;

                       /** 有可能之前铺底单据已经核销完成，但是单据冲销之后，
                          铺底单据的利息金额是需要重新算的
                        */
                       Select T3.*
                         Into Row_Credit_Delaypay
                         From T_Credit_Delaypay T3
                        Where T3.Bill_Id = K.Bill_Id;

                       --计算利息
                       PRC_CREDIT_DELAYPAY_ACCRUAL(row_credit_delaypay => Row_Credit_Delaypay ,
                                                   p_overdue_days => v_overdue_days , --逾期天数
                                                   p_Accrual_Amount => v_Accrual_Amount , --逾期金额
                                                   p_result => p_result ,
                                                   p_err_msg => p_err_msg ) ;

                       If p_result = V_SEC_RESULT Then
                          --更新铺底单据上的铺底利息信息
                          Update T_Credit_Delaypay T1
                            Set t1.bring_accrual_days = v_overdue_days ,
                                t1.accrual_amount = v_Accrual_Amount
                          Where T1.Bill_Id = K.Bill_Id;
                       End If ;

                    Exception When Others Then
                      Null ;
                    End ;
                   --重置变量
                   Row_Credit_Delaypay := Null ;
                   v_overdue_days := 0 ;
                   v_Accrual_Amount := 0 ;
                   v_trans_id := Null ;
             End Loop ;

          --三方解付冲销，传的是原单ID
          Elsif Rows_Sales_Amount_Trans(i).action_flag = 20 Then
             --检查是否存在同一天的正向单，有则不能用本单据来进行核销回退
            Begin
              Select TRANS_ID Into v_trans_id From T_Sales_Amount_Trans t
              Where t.entity_id = Rows_Sales_Amount_Trans(i).entity_id
                And t.customer_id = Rows_Sales_Amount_Trans(i).customer_id
                And t.account_id = Rows_Sales_Amount_Trans(i).account_id
                And t.sales_main_type = Rows_Sales_Amount_Trans(i).sales_main_type
                And t.action_flag = 19
                And t.order_id = Rows_Sales_Amount_Trans(i).Order_Id
                And trunc(t.creation_date) = Trunc(Thisdate)
                And rownum = 1  ;
            Exception When Others Then
              Null ;
            End ;
            --如果同一天的正向单，则跳过本次核销回退动作
            If v_trans_id Is Not Null Then
               Goto here ;
            End If ;

             For k In (Select T.*
                   From T_Credit_Delaypa_Applied t
                  Where T.Cash_Receipt_Id = Rows_Sales_Amount_Trans(i).Order_Id
                    And t.action_flag = 20
                    And t.applied_status = '1') Loop
                  Begin
                       --更新铺底单据上的信息
                       Update T_Credit_Delaypay T1
                          Set T1.Pay_Date           = Null, --还清日期置空
                              T1.Payed_Flag         = '0', --是否还清（1：是；0：否）
                              T1.Transaction_Amount = Nvl(T1.Transaction_Amount,
                                                          0) +
                                                      Nvl(K.Applied_Amount, 0)
                        Where T1.Bill_Id = K.Bill_Id;


                       --更新逾期核销记录信息
                       Update T_Credit_Delaypa_Applied t2 Set
                       t2.applied_status = '2'  --核销状态（1：已核销；2：已冲销）
                       Where t2.applied_id = k.applied_id ;

                       /** 有可能之前铺底单据已经核销完成，但是单据冲销之后，
                          铺底单据的利息金额是需要重新算的
                        */
                       Select T3.*
                         Into Row_Credit_Delaypay
                         From T_Credit_Delaypay T3
                        Where T3.Bill_Id = K.Bill_Id;

                       --计算利息
                       PRC_CREDIT_DELAYPAY_ACCRUAL(row_credit_delaypay => Row_Credit_Delaypay ,
                                                   p_overdue_days => v_overdue_days , --逾期天数
                                                   p_Accrual_Amount => v_Accrual_Amount , --逾期金额
                                                   p_result => p_result ,
                                                   p_err_msg => p_err_msg ) ;

                       If p_result = V_SEC_RESULT Then
                          --更新铺底单据上的铺底利息信息
                          Update T_Credit_Delaypay T1
                            Set t1.bring_accrual_days = v_overdue_days ,
                                t1.accrual_amount = v_Accrual_Amount
                          Where T1.Bill_Id = K.Bill_Id;
                       End If ;

                    Exception When Others Then
                      Null ;
                    End ;
                   --重置变量
                   Row_Credit_Delaypay := Null ;
                   v_overdue_days := 0 ;
                   v_Accrual_Amount := 0 ;
                   v_trans_id := Null ;
             End Loop ;
          End If ;
          <<here>>
          Null ;
      End Loop ;
  END;

  --------------------------------------------------------------------------------
  /*
  *   创建日期：2015-04-13
  *     创建者：苏冬渊
  *   功能说明：铺底核销过程 执行入口
  *   返回结果：0:成功，-20000：失败
  *
  */
  -------------------------------------------------------------------------------
  PROCEDURE PRC_CREDIT_DELAYPAY_MAIN Is

  Begin
     --退货红冲、折让证明红冲、销售折让红冲、收款冲销，回退铺底单据核销过程
     PRC_CREDIT_DELAYPAY_APPLIED_HS ;
     --销售红冲，退货，折让证明单，销售折让单，结算退货单，收款确认 进行逾期铺底核销
     PRC_CREDIT_DELAYPAY_APPLIED_AT ;
     --当前到期铺底单据的到期操作
     PRC_CREDIT_DELAYPAY_DUE_DATE ;
     --到期铺底核销
     PRC_CREDIT_DELAYPAY_APPLIED ;
     Commit ;
  END;

end PKG_CREDIT_DATA_CUTTING;
/

