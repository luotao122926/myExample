create PACKAGE BODY      PKG_SO_PUB IS
  /*----------------------------------------------------------------
  *         包：PKG_SO_PUB
  *   创建日期：2014-07-05
  *     创建者：廖丽章
  *   功能说明：根据销售单据头接口表与销售单据行接口表数据，生成各种类型销售单据（财务单）。
  *
  *   过程成功：P_RESULT = 0
  *             P_ERR_MSG = 'SUCCESS';
  *
  *   过程失败：P_RESULT < -20000;
  *             P_ERR_MSG = 过程异常失败的提示信息
  *
  */ ----------------------------------------------------------------

  /*
    V_NL             CONSTANT VARCHAR2(2) := CHR(13) || CHR(10); --换行
    V_RESULT         CONSTANT NUMBER := 0; --成功返回
    V_SUCCESS        CONSTANT VARCHAR2(10) := 'SUCCESS';
    V_ERR_MSG        CONSTANT VARCHAR2(10) := '';
    V_BIZ_EXCEPTION  EXCEPTION; --自定义业务异常
  */
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-05
  *     创建者：廖丽章
  *   功能说明：校验业务单据类型是否存在及扩展配置是否已设置
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_CHECK_BILLTYPE(P_ENTITY_ID    IN NUMBER, --主体ID
                             P_BILL_TYPE_ID IN NUMBER, --业务单据类型ID
                             P_RESULT       IN OUT NUMBER, --返回错误ID
                             P_ERR_MSG      IN OUT VARCHAR2 --返回错误信息
                             ) IS
    TMP_ERR_MSG1 VARCHAR2(128) := '';
    TMP_ERR_MSG2 VARCHAR2(128) := '';
    TMP_ERR_MSG3 VARCHAR2(128) := '';

  BEGIN
    P_RESULT  := V_RESULT;
    P_ERR_MSG := V_ERR_MSG;

    --业务单据类型是否存在或超出有效期
    BEGIN
      SELECT ''
        INTO TMP_ERR_MSG1
        FROM T_INV_BILL_TYPES
       WHERE ENTITY_ID = P_ENTITY_ID
         AND BILL_TYPE_ID = P_BILL_TYPE_ID
         AND (TRUNC(SYSDATE) BETWEEN BEGIN_DATE AND NVL(END_DATE, SYSDATE));
    EXCEPTION
      WHEN OTHERS THEN
        TMP_ERR_MSG1 := '业务单据类型不存在或已超出有效期。';
    END;

    --销售单据类型视图V_SO_BILL_TYPE，业务单据类型与源类型需要预先配置好。（在库存管理模块进行配置）
    BEGIN
      SELECT ''
        INTO TMP_ERR_MSG2
        FROM V_SO_BILL_TYPE
       WHERE ENTITY_ID = P_ENTITY_ID
         AND BILL_TYPE_ID = P_BILL_TYPE_ID
         AND (TRUNC(SYSDATE) BETWEEN BEGIN_DATE AND NVL(END_DATE, SYSDATE));
    EXCEPTION
      WHEN OTHERS THEN
        TMP_ERR_MSG2 := '业务单据类型与源类型对应关系未配置。';
    END;

    --销售单据类型扩展视图V_SO_BILL_TYPE_EXTEND，业务单据类型扩展需要预先配置好。
    BEGIN
      SELECT ''
        INTO TMP_ERR_MSG3
        FROM V_SO_BILL_TYPE_EXTEND
       WHERE ENTITY_ID = P_ENTITY_ID
         AND BILL_TYPE_ID = P_BILL_TYPE_ID
         AND (TRUNC(SYSDATE) BETWEEN BEGIN_DATE AND NVL(END_DATE, SYSDATE));
    EXCEPTION
      WHEN OTHERS THEN
        TMP_ERR_MSG3 := '业务单据类型未配置扩展属性。';
    END;

    P_ERR_MSG := TMP_ERR_MSG1 || TMP_ERR_MSG2 || TMP_ERR_MSG3;

    IF P_ERR_MSG = '' THEN
      P_RESULT := V_RESULT;
    ELSE
      P_RESULT  := -28901;
      P_ERR_MSG := '主体[' || P_ENTITY_ID || ']的业务单据类型[' || P_BILL_TYPE_ID || ']：' ||
                   P_ERR_MSG;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      P_RESULT  := -28901;
      P_ERR_MSG := '业务单据类型校验发生异常！';
  END;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-05
  *     创建者：廖丽章
  *   功能说明：红冲单原单（蓝单）校验
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_CHECK_BLUEBILL(P_ENTITY_ID        IN NUMBER, --主体ID
                             P_RED_BILL_TYPE_ID IN NUMBER, --红冲单据类型ID
                             P_BLUE_BILL_NUM    IN NUMBER, --原单（蓝单）号
                             P_RESULT           IN OUT NUMBER, --返回错误ID
                             P_ERR_MSG          IN OUT VARCHAR2 --返回错误信息
                             ) IS
    TMP_ERR_MSG1 VARCHAR2(128) := '';
    TMP_ERR_MSG2 VARCHAR2(128) := '';

    V_BLUE_BILL_TYPE_ID NUMBER := 0;
  BEGIN
    P_RESULT  := V_RESULT;
    P_ERR_MSG := V_ERR_MSG;

    --判断红冲单原单（蓝单）是否存在
    BEGIN
      SELECT BILL_TYPE_ID, ''
        INTO V_BLUE_BILL_TYPE_ID, TMP_ERR_MSG1
        FROM T_SO_HEADER
       WHERE ENTITY_ID = P_ENTITY_ID
         AND SO_NUM = P_BLUE_BILL_NUM;
    EXCEPTION
      WHEN OTHERS THEN
        TMP_ERR_MSG1 := '原单（蓝单）[单据号：' || P_BLUE_BILL_NUM || ']不存在。';
    END;

    --判断原单单据类型是否与红冲单类型对应的蓝单类型一致
    BEGIN
      SELECT ''
        INTO TMP_ERR_MSG2
        FROM V_SO_BILL_TYPE_EXTEND
       WHERE ENTITY_ID = P_ENTITY_ID
         AND BILL_TYPE_ID = P_RED_BILL_TYPE_ID
         AND ORIG_BILL_TYPE_ID = V_BLUE_BILL_TYPE_ID;
    EXCEPTION
      WHEN OTHERS THEN
        TMP_ERR_MSG2 := '原单（蓝单）[单据号：' || P_BLUE_BILL_NUM ||
                        ']的类型不是红冲单对应的蓝单类型。';
    END;

    P_ERR_MSG := TMP_ERR_MSG1 || TMP_ERR_MSG2;
    IF P_ERR_MSG = '' THEN
      P_RESULT := V_RESULT;
    ELSE
      P_RESULT  := -28902;
      P_ERR_MSG := '主体[' || P_ENTITY_ID || ']的红冲单原单（蓝单）校验出错：' || P_ERR_MSG;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      P_RESULT  := -28902;
      P_ERR_MSG := '红冲单原单（蓝单）校验发生异常！';
  END;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-05
  *     创建者：廖丽章
  *   功能说明：校验营销中心是否有效
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_CHECK_SALESCENTER(P_ENTITY_ID       IN NUMBER, --主体ID
                                P_SALES_CENTER_ID IN NUMBER, --营销中心ID
                                P_RESULT          IN OUT NUMBER, --返回错误ID
                                P_ERR_MSG         IN OUT VARCHAR2 --返回错误信息
                                ) IS
    TMP_ERR_MSG1 VARCHAR2(128) := '';
    TMP_ERR_MSG2 VARCHAR2(128) := '';
    TMP_ERR_MSG3 VARCHAR2(128) := '';

    --营销中心名称
    V_SALES_CENTER_NAME VARCHAR2(100) := '';
  BEGIN
    --初始值
    P_RESULT  := V_RESULT;
    P_ERR_MSG := V_SUCCESS;

    --判断营销中心是否存在
    BEGIN
      SELECT NAME, ''
        INTO V_SALES_CENTER_NAME, TMP_ERR_MSG1
        FROM UP_ORG_UNIT
       WHERE ID = P_SALES_CENTER_ID;
    EXCEPTION
      WHEN OTHERS THEN
        TMP_ERR_MSG1 := 'ID为[' || P_SALES_CENTER_ID || ']的营销中心不存在。';
    END;

    --判断营销中心是否已分配主体
    --(待实现)

    --判断营销中心是否已定义所属销售片区
    --(待实现)

    P_ERR_MSG := TMP_ERR_MSG1 || TMP_ERR_MSG2 || TMP_ERR_MSG3;
    IF P_ERR_MSG = '' THEN
      P_RESULT := V_RESULT;
    ELSE
      P_RESULT  := -28903;
      P_ERR_MSG := '营销中心校验出错：' || P_ERR_MSG;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      P_RESULT  := -28903;
      P_ERR_MSG := '营销中心校验发生异常！';
  END;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-08-19
  *     创建者：周建刚
  *   功能说明：校验产品所属营销大类跟单据营销大类是否一致
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_CHECK_ITEM_SALES_MAIN_TYPE(P_ENTITY_ID       IN NUMBER, --主体ID
                                         P_ITEM_CODE       IN VARCHAR2,--产品编码
                                         P_SALES_MAIN_TYPE IN VARCHAR2, --营销营销大类
                                         P_RESULT          IN OUT NUMBER, --返回错误ID
                                         P_ERR_MSG         IN OUT VARCHAR2 --返回错误信息
                                ) IS
  V_SALES_MAIN_TYPE VARCHAR2(100) := '';
  BEGIN
    P_RESULT  := V_RESULT;
    P_ERR_MSG := V_SUCCESS;

    SELECT SALES_MAIN_TYPE
      INTO V_SALES_MAIN_TYPE
      FROM T_BD_ITEM
     WHERE ITEM_CODE = P_ITEM_CODE
       AND ENTITY_ID = P_ENTITY_ID;
    IF V_SALES_MAIN_TYPE != P_SALES_MAIN_TYPE THEN
      P_RESULT  := -28904;
      P_ERR_MSG := '产品[' || P_ITEM_CODE || ']' || '所属营销大类[' || V_SALES_MAIN_TYPE || ']与单据营销大类[' || P_SALES_MAIN_TYPE || ']不一致！';
    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      P_RESULT  := -28904;
      P_ERR_MSG := '校验产品[' || P_ITEM_CODE || ']' || '与单据营销大类[' || P_SALES_MAIN_TYPE || ']一致性出现异常！';
  END;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-05
  *     创建者：廖丽章
  *   功能说明：校验客户是否有效
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_CHECK_CUSTOMER(P_ENTITY_ID       IN NUMBER, --主体ID
                             P_SALES_CENTER_ID IN NUMBER, --营销中心ID
                             P_CUSTOMER_ID     IN NUMBER, --客户ID
                             P_RESULT          IN OUT NUMBER, --返回错误ID
                             P_ERR_MSG         IN OUT VARCHAR2 --返回错误信息
                             ) IS
    TMP_ERR_MSG1 VARCHAR2(128) := '';
    TMP_ERR_MSG2 VARCHAR2(128) := '';
    TMP_ERR_MSG3 VARCHAR2(128) := '';

    --客户名称
    V_CUSTOMER_NAME VARCHAR2(300) := '';
    V_CUSTOMER_CODE VARCHAR2(100) := '';
    V_CUSTOMER_MSG  VARCHAR2(420) := '';
  BEGIN
    P_RESULT  := V_RESULT;
    P_ERR_MSG := V_SUCCESS;

    --判断客户是否存在
    BEGIN
      SELECT CUSTOMER_CODE, CUSTOMER_NAME, ''
        INTO V_CUSTOMER_CODE, V_CUSTOMER_NAME, TMP_ERR_MSG1
        FROM T_CUSTOMER_HEADER
       WHERE CUSTOMER_ID = P_CUSTOMER_ID;

      V_CUSTOMER_MSG := '(' || V_CUSTOMER_CODE || ')' || V_CUSTOMER_NAME;
    EXCEPTION
      WHEN OTHERS THEN
        TMP_ERR_MSG1 := 'ID为[' || P_CUSTOMER_ID || ']客户不存在。';
    END;

    --判断客户是否属于指定主体
    BEGIN
      SELECT ''
        INTO TMP_ERR_MSG2
        FROM T_CUSTOMER_ORG
       WHERE CUSTOMER_ID = P_CUSTOMER_ID
         AND ENTITY_ID = P_ENTITY_ID;
    EXCEPTION
      WHEN OTHERS THEN
        TMP_ERR_MSG2 := V_CUSTOMER_MSG || '没有分配主体或不属于指定主体[' || P_ENTITY_ID || ']。';
    END;

    --判断客户是否属于指定营销中心
    BEGIN
      SELECT ''
        INTO TMP_ERR_MSG3
        FROM T_CUSTOMER_ORG
       WHERE CUSTOMER_ID = P_CUSTOMER_ID
         AND SALES_CENTER_ID = P_SALES_CENTER_ID;
    EXCEPTION
      WHEN OTHERS THEN
        TMP_ERR_MSG3 := V_CUSTOMER_MSG || '没有分配营销中心或不属于指定营销中心[' ||
                        P_ENTITY_ID || ']。';
    END;

    P_ERR_MSG := TMP_ERR_MSG1 || TMP_ERR_MSG2 || TMP_ERR_MSG3;
    IF P_ERR_MSG = '' THEN
      P_RESULT := V_RESULT;
    ELSE
      P_RESULT  := -28904;
      P_ERR_MSG := '客户校验出错：' || P_ERR_MSG;
    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      P_RESULT  := -28904;
      P_ERR_MSG := '客户校验发生异常！';
  END;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-05
  *     创建者：廖丽章
  *   功能说明：校验仓库是否有效
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_CHECK_INVENTORY(P_INVENTORY_ID         IN NUMBER, --仓库ID
                              P_CHECK_ONWAY_FLAG     VARCHAR2, --是否校验在途仓 Y-是 N-否
                              P_CHECK_NOSETTLED_FLAG VARCHAR2, --是否校验未结算仓
                              P_CHECK_RETURN_FLAG    VARCHAR2, --是否校验退货未结算仓
                              P_RESULT               IN OUT NUMBER, --返回错误ID
                              P_ERR_MSG              IN OUT VARCHAR2 --返回错误信息
                              ) IS
    TMP_ERR_MSG1 VARCHAR2(128) := '';
    TMP_ERR_MSG2 VARCHAR2(128) := '';
    TMP_ERR_MSG3 VARCHAR2(128) := '';
    TMP_ERR_MSG4 VARCHAR2(128) := '';
    TMP_ERR_MSG5 VARCHAR2(128) := '';

    --仓库名称、代码
    V_INVENTORY_NAME VARCHAR2(100) := '';
    V_INVENTORY_CODE VARCHAR2(100) := '';
    V_INVENTORY_MSG  VARCHAR2(220) := '';
  BEGIN
    P_RESULT  := V_RESULT;
    P_ERR_MSG := V_SUCCESS;

    --判断指定仓库是否存在
    BEGIN
      SELECT INVENTORY_CODE, INVENTORY_NAME, ''
        INTO V_INVENTORY_CODE, V_INVENTORY_NAME, TMP_ERR_MSG1
        FROM T_INV_INVENTORIES
       WHERE INVENTORY_ID = P_INVENTORY_ID;

      V_INVENTORY_MSG := '(' || V_INVENTORY_CODE || ')' || V_INVENTORY_NAME;
    EXCEPTION
      WHEN OTHERS THEN
        TMP_ERR_MSG1 := 'ID为[' || P_INVENTORY_ID || ']的仓库不存在。';
    END;

    --判断指定仓库是否超出有效期
    BEGIN
      SELECT ''
        INTO TMP_ERR_MSG2
        FROM T_INV_INVENTORIES
       WHERE INVENTORY_ID = P_INVENTORY_ID
         AND (TRUNC(SYSDATE) BETWEEN BEGIN_DATE AND NVL(END_DATE, SYSDATE));
    EXCEPTION
      WHEN OTHERS THEN
        TMP_ERR_MSG2 := V_INVENTORY_MSG || '仓库不存在或已超出有效期。';
    END;

    --判断指定仓库的在途仓是否存在且有效
    IF P_CHECK_ONWAY_FLAG = 'Y' THEN
      BEGIN
        SELECT ''
          INTO TMP_ERR_MSG3
          FROM T_INV_INVENTORIES INV, T_INV_INVENTORIES INV_TMP
         WHERE INV.INVENTORY_ID = P_INVENTORY_ID
           AND INV.ONWAY_INVENTORY_ID = INV_TMP.INVENTORY_ID
           AND (TRUNC(SYSDATE) BETWEEN INV_TMP.BEGIN_DATE AND
               NVL(INV_TMP.END_DATE, SYSDATE));
      EXCEPTION
        WHEN OTHERS THEN
          TMP_ERR_MSG3 := V_INVENTORY_MSG || '的在途仓不存在或已超出有效期。';
      END;
    END IF;

    --判断指定仓库的在未结算仓是否存在且有效
    IF P_CHECK_NOSETTLED_FLAG = 'Y' THEN
      BEGIN
        SELECT ''
          INTO TMP_ERR_MSG4
          FROM T_INV_INVENTORIES INV, T_INV_INVENTORIES INV_TMP
         WHERE INV.INVENTORY_ID = P_INVENTORY_ID
           AND INV.NOSETTLED_INVENTORY_ID = INV_TMP.INVENTORY_ID
           AND (TRUNC(SYSDATE) BETWEEN INV_TMP.BEGIN_DATE AND
               NVL(INV_TMP.END_DATE, SYSDATE));
      EXCEPTION
        WHEN OTHERS THEN
          TMP_ERR_MSG4 := V_INVENTORY_MSG || '的未结算仓不存在或已超出有效期。';
      END;
    END IF;

    --判断指定仓库的在退货未结算仓是否存在且有效
    IF P_CHECK_RETURN_FLAG = 'Y' THEN
      BEGIN
        SELECT ''
          INTO TMP_ERR_MSG5
          FROM T_INV_INVENTORIES INV, T_INV_INVENTORIES INV_TMP
         WHERE INV.INVENTORY_ID = P_INVENTORY_ID
           AND INV.RETURN_INVENTORY_ID = INV_TMP.INVENTORY_ID
           AND (TRUNC(SYSDATE) BETWEEN INV_TMP.BEGIN_DATE AND
               NVL(INV_TMP.END_DATE, SYSDATE));
      EXCEPTION
        WHEN OTHERS THEN
          TMP_ERR_MSG5 := V_INVENTORY_MSG || '的退货未结算仓不存在或已超出有效期。';
      END;
    END IF;

    P_ERR_MSG := TMP_ERR_MSG1 || TMP_ERR_MSG2 || TMP_ERR_MSG3 ||
                 TMP_ERR_MSG4 || TMP_ERR_MSG5;
    IF P_ERR_MSG = '' THEN
      P_RESULT := V_RESULT;
    ELSE
      P_RESULT  := -28905;
      P_ERR_MSG := '仓库校验出错：' || P_ERR_MSG;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      P_RESULT  := -28905;
      P_ERR_MSG := '仓库校验发生异常！';
  END;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-01-03
  *     创建者：陈武杰
  *   功能说明：判断产品数据量是否大于发货单数量
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_CHECK_QUANTITY(P_SHIP_INFO_ID IN NUMBER, --实际发货信息ID
                             P_RESULT       IN OUT NUMBER, --返回错误ID
                             P_ERR_MSG      IN OUT VARCHAR2 --返回错误信息
                             ) IS
    N_SHIP_DOC_ID   T_SO_HEADER.SHIP_DOC_ID%TYPE; --发货通知单ID
    V_SHIP_DOC_CODE T_SO_HEADER.SHIP_DOC_CODE%TYPE; --发货通知单号
    N_ITEM_SUM_QTY  NUMBER; --每种产品总数量
    N_ITEM_QTY      NUMBER; --当前产品已生成销售单数量
  BEGIN
    P_RESULT  := V_RESULT;
    P_ERR_MSG := V_ERR_MSG;
    /*    BEGIN
      \*
      1、通过实际发货信息ID查询[实际发货信息行]表中的“SHIP_DOC_LINE_ID发货通知单行ID”，
      2、再通过“SHIP_DOC_LINE_ID发货通知单行ID”查询“发货通知单行”获得SHIP_DOC_ID发货通知单ID
      3、通过“SHIP_DOC_ID发货通知单ID”源发货通知单表获得“发货通知单ID”和“发货通知单编码”
      *\
      SELECT C.SHIP_DOC_ID, C.SHIP_DOC_CODE
        INTO N_SHIP_DOC_ID, V_SHIP_DOC_CODE
        FROM T_LG_SHIP_DOC C
       WHERE C.SHIP_DOC_ID IN
             (SELECT B.SHIP_DOC_ID
                FROM T_LG_SHIP_DOC_LINE B --发货通知单行
               WHERE B.SHIP_DOC_LINE_ID IN
                     (SELECT A.SHIP_DOC_LINE_ID
                        FROM T_LG_ACTUAL_SHIP_LINE A --实际发货信息行
                       WHERE A.SHIP_INFO_ID = P_SHIP_INFO_ID))
         AND ROWNUM = 1;
    EXCEPTION
      WHEN OTHERS THEN
        P_RESULT  := -1;
        P_ERR_MSG := '实际发货信息ID[' || P_SHIP_INFO_ID || ']，查询不到发货通知单记录！';
        RETURN;
    END;*/

    -- 遍历本次将开销售单每种产品
    FOR REC IN (SELECT A.SHIP_DOC_LINE_ID,
                       NVL(A.ITEM_QTY, 0) AS 本次发货,
                       NVL(B.ITEM_QTY, 0) AS 产品数量,
                       NVL(B.FACT_SHIP_QTY, 0) AS 实际已发货数量,
                       NVL(B.CANCEL_QTY, 0) AS 取消数量
                  FROM CIMS.T_LG_ACTUAL_SHIP_LINE A,
                       CIMS.T_LG_SHIP_DOC_LINE    B
                 WHERE A.SHIP_DOC_LINE_ID = B.SHIP_DOC_LINE_ID
                   AND A.SHIP_INFO_ID = P_SHIP_INFO_ID --实际发货信息ID
                ) LOOP

      --      IF (REC.本次发货 + REC.实际发货数量 - REC.取消数量) > REC.产品数量 THEN
      IF (REC.产品数量 - REC.实际已发货数量 - REC.本次发货 - REC.取消数量) < 0 THEN
        --'以下产品本次发货大于订单数量！'||chr(10)||
        P_ERR_MSG := P_ERR_MSG || '发货通知单行ID[' || REC.SHIP_DOC_LINE_ID ||
                     ']产品数量[' || REC.产品数量 || ']，已实际已发货数量[' || REC.实际已发货数量 ||
                     ']，本次发货数量[' || REC.本次发货 || ']，累计取消数量[' || REC.取消数量 || ']' || V_NL;
        P_RESULT  := -1;
      END IF;

    END LOOP;
  END P_CHECK_QUANTITY;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-01-04
  *     创建者：廖丽章
  *   功能说明：发货确认触发生成销售单，发货通知单的产品数量与已生成的销售单产品数量进行校验，
                如果一张发货通知累计已生成的销售单产品数量大于发货通知单产品数量，
                则不允许生成销售单，直接返回提示信息。
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_CHECK_SHIP_QTY(P_SHIP_INFO_ID IN NUMBER, --实际发货信息ID
                             P_RESULT       IN OUT NUMBER, --返回错误ID
                             P_ERR_MSG      IN OUT VARCHAR2 --返回错误信息
                             ) IS
    --汇总后用于计算判断的信息
    CURSOR C_CAL_INFO IS
      SELECT X.ITEM_CODE,
             X.DOC_ACT_QTY,
             X.ACT_ITEM_QTY,
             NVL(Y.SO_ITEM_QTY, 0) AS SO_ITEM_QTY
        FROM (
              --发货通知单上发货数量信息
              SELECT LASL.ITEM_CODE, --发货产品编码
                      SUM(NVL(LASL.ITEM_QTY, 0)) AS ACT_ITEM_QTY, --本次实际发货的数量
                      --SUM(NVL(LSDL.ITEM_QTY, 0)) AS DOC_ITEM_QTY, --发货通知单行上的发货数量
                      --SUM(NVL(LSDL.CANCEL_QTY, 0)) AS DOC_CANCEL_QTY, --发货通知单行上的取消数量
                      SUM((NVL(LSDL.ITEM_QTY, 0) - NVL(LSDL.CANCEL_QTY, 0))) AS DOC_ACT_QTY --发货通知单实际的发货数量=发货数量-累计取消发货的数量
                FROM T_LG_ACTUAL_SHIP_LINE LASL, --实际发货信息行表
                      T_LG_SHIP_DOC_LINE    LSDL --发货通知单行表
               WHERE LASL.SHIP_DOC_LINE_ID = LSDL.SHIP_DOC_LINE_ID
                 AND LASL.SHIP_INFO_ID = P_SHIP_INFO_ID
               GROUP BY LASL.ITEM_CODE) X
        LEFT JOIN (
                   --发货通知单对应的财务单发货数量信息
                   SELECT SL.ITEM_CODE,
                           SUM(NVL(SL.ITEM_QTY, 0)) AS SO_ITEM_QTY
                     FROM T_SO_HEADER        SH, --销售单头表
                           T_SO_LINE          SL, --销售单行表
                           T_LG_SHIP_DOC_LINE A --发货通知单行表
                    WHERE SH.SO_HEADER_ID = SL.SO_HEADER_ID
                      AND SL.SHIP_DOC_LINE_ID = A.SHIP_DOC_LINE_ID
                      AND SH.SHIP_DOC_ID =
                          (SELECT C.SHIP_DOC_ID
                             FROM T_LG_ACTUAL_SHIP_LINE B, --实际发货信息行表
                                  T_LG_SHIP_DOC_LINE    C --发货通知单行表
                            WHERE B.SHIP_DOC_LINE_ID = C.SHIP_DOC_LINE_ID
                              AND B.SHIP_INFO_ID = P_SHIP_INFO_ID
                              AND ROWNUM = 1)
                    GROUP BY SL.ITEM_CODE) Y
          ON Y.ITEM_CODE = X.ITEM_CODE;

    --汇总后用于计算判断的信息记录
    R_CAL_INFO C_CAL_INFO%ROWTYPE;

    --产品编码
    V_ITEM_CODE T_BD_ITEM.ITEM_CODE%TYPE;
    --发货通知单实际的发货数量
    V_DOC_ACT_QTY NUMBER;
    --本次实际发货的数量
    V_ACT_ITEM_QTY NUMBER;
    --已生成销售单的产品数量
    V_SO_ITEM_QTY NUMBER;

  BEGIN
    P_ERR_MSG := '';

    FOR R_CAL_INFO IN C_CAL_INFO LOOP
      V_ITEM_CODE    := R_CAL_INFO.ITEM_CODE;
      V_DOC_ACT_QTY  := R_CAL_INFO.DOC_ACT_QTY; --发货通知单实际的发货数量
      V_ACT_ITEM_QTY := R_CAL_INFO.ACT_ITEM_QTY; --本次实际发货的数量
      V_SO_ITEM_QTY  := R_CAL_INFO.SO_ITEM_QTY; --已生成销售单的产品数量

      IF ((V_ACT_ITEM_QTY + V_SO_ITEM_QTY) > V_DOC_ACT_QTY) THEN
        P_ERR_MSG := P_ERR_MSG || '【产品[' || V_ITEM_CODE || ']本次发货数量(' ||
                     V_ACT_ITEM_QTY || ')' || '+已生成销售单的产品数量(' ||
                     V_SO_ITEM_QTY || ')】' || '大于【发货通知单该产品的数量(' ||
                     V_DOC_ACT_QTY || ')】。' || V_NL;
        P_RESULT  := -28912;
      END IF;
    END LOOP;

    --抛出错误
    IF (P_RESULT < 0) THEN
      RAISE V_BIZ_EXCEPTION;
    ELSE
      P_RESULT  := V_RESULT;
      P_ERR_MSG := V_SUCCESS;
    END IF;

  EXCEPTION
    WHEN V_BIZ_EXCEPTION THEN
      P_RESULT  := -28912;
      P_ERR_MSG := '发货通知单产品数量校验出错：' || V_NL || P_ERR_MSG;
    WHEN OTHERS THEN
      P_RESULT  := -28912;
      P_ERR_MSG := '发货通知单产品数量校验发生异常：' || SQLERRM;
  END;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-05
  *     创建者：廖丽章
  *   功能说明：保存对销售单据的操作历史
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SAVE_SO_TRACE(P_SO_TRACE IN T_SO_TRACE%ROWTYPE, --操作历史
                            P_RESULT   IN OUT NUMBER, --返回错误ID
                            P_ERR_MSG  IN OUT VARCHAR2 --返回错误信息
                            ) IS
  BEGIN
    P_RESULT  := V_RESULT;
    P_ERR_MSG := V_SUCCESS;

    INSERT INTO T_SO_TRACE
      (SO_TRACE_ID,
       SO_HEADER_ID,
       SO_LINE_ID,
       ENTITY_ID,
       OPERATION,
       ORIG_ITEM_ID,
       ORIG_ITEM_QTY,
       ORIG_ITEM_PRICE,
       ORIG_ITEM_SETTLE_PRICE,
       ORIG_ITEM_SETTLE_AMOUNT,
       ORIG_DISCOUNT_RATE,
       ORIG_DISCOUNT_AMOUNT,
       ORIG_MONTH_DISCOUNT_RATE,
       ORIG_PROJECT_TYPE_CODE,
       ORIG_PROJECT_ID,
       ORIG_PROJECT_NUM,
       ORIG_PROJECT_PRICE,
       NEW_ITEM_ID,
       NEW_ITEM_QTY,
       NEW_ITEM_PRICE,
       NEW_ITEM_SETTLE_PRICE,
       NEW_ITEM_SETTLE_AMOUNT,
       NEW_DISCOUNT_RATE,
       NEW_DISCOUNT_AMOUNT,
       NEW_MONTH_DISCOUNT_RATE,
       NEW_PROJECT_TYPE_CODE,
       NEW_PROJECT_ID,
       NEW_PROJECT_NUM,
       NEW_PROJECT_PRICE,
       CREATED_BY,
       CREATION_DATE,
       LAST_UPDATED_BY,
       LAST_UPDATE_DATE)
    VALUES
      (S_SO_TRACE.NEXTVAL,
       P_SO_TRACE.SO_HEADER_ID,
       P_SO_TRACE.SO_LINE_ID,
       P_SO_TRACE.ENTITY_ID,
       P_SO_TRACE.OPERATION,
       P_SO_TRACE.ORIG_ITEM_ID,
       P_SO_TRACE.ORIG_ITEM_QTY,
       P_SO_TRACE.ORIG_ITEM_PRICE,
       P_SO_TRACE.ORIG_ITEM_SETTLE_PRICE,
       P_SO_TRACE.ORIG_ITEM_SETTLE_AMOUNT,
       P_SO_TRACE.ORIG_DISCOUNT_RATE,
       P_SO_TRACE.ORIG_DISCOUNT_AMOUNT,
       P_SO_TRACE.ORIG_MONTH_DISCOUNT_RATE,
       P_SO_TRACE.ORIG_PROJECT_TYPE_CODE,
       P_SO_TRACE.ORIG_PROJECT_ID,
       P_SO_TRACE.ORIG_PROJECT_NUM,
       P_SO_TRACE.ORIG_PROJECT_PRICE,
       P_SO_TRACE.NEW_ITEM_ID,
       P_SO_TRACE.NEW_ITEM_QTY,
       P_SO_TRACE.NEW_ITEM_PRICE,
       P_SO_TRACE.NEW_ITEM_SETTLE_PRICE,
       P_SO_TRACE.NEW_ITEM_SETTLE_AMOUNT,
       P_SO_TRACE.NEW_DISCOUNT_RATE,
       P_SO_TRACE.NEW_DISCOUNT_AMOUNT,
       P_SO_TRACE.NEW_MONTH_DISCOUNT_RATE,
       P_SO_TRACE.NEW_PROJECT_TYPE_CODE,
       P_SO_TRACE.NEW_PROJECT_ID,
       P_SO_TRACE.NEW_PROJECT_NUM,
       P_SO_TRACE.NEW_PROJECT_PRICE,
       P_SO_TRACE.CREATED_BY,
       P_SO_TRACE.CREATION_DATE,
       P_SO_TRACE.LAST_UPDATED_BY,
       P_SO_TRACE.LAST_UPDATE_DATE);

  EXCEPTION
    WHEN OTHERS THEN
      P_RESULT  := -28906;
      P_ERR_MSG := '保存对销售单据的操作历史发生异常：' || SQLERRM;
  END;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-05
  *     创建者：廖丽章
  *   功能说明：判断产品是否套件，Y-是，N-否
  */
  -------------------------------------------------------------------------------
  /*  mark by shengy20150131
   PROCEDURE P_ITEM_IS_SET(P_ITEM_CODE IN VARCHAR2, --产品编码
                            P_IS_SET    OUT VARCHAR2, --是否套件标识：Y-是，N-否
                            P_RESULT    OUT NUMBER, --返回错误ID
                            P_ERR_MSG   OUT VARCHAR2 --返回错误信息
                            ) IS
    BEGIN
      P_RESULT  := V_RESULT;
      P_ERR_MSG := V_SUCCESS;

      P_IS_SET := F_ITEM_IS_SET(P_ITEM_CODE);
    EXCEPTION
      WHEN V_BIZ_EXCEPTION THEN
        P_RESULT  := -28907;
        P_ERR_MSG := '判断产品是否套件发生错误。';
      WHEN OTHERS THEN
        P_RESULT  := -28907;
        P_ERR_MSG := '判断产品是否套件发生异常：' || SQLERRM;
    END;
  */
  PROCEDURE P_ITEM_IS_SET(P_ENTITY_ID IN NUMBER, --主体ID
                          P_ITEM_CODE IN VARCHAR2, --产品编码
                          P_IS_SET    OUT VARCHAR2, --是否套件标识：Y-是，N-否
                          P_RESULT    OUT NUMBER, --返回错误ID
                          P_ERR_MSG   OUT VARCHAR2 --返回错误信息
                          ) IS
  BEGIN
    P_RESULT  := V_RESULT;
    P_ERR_MSG := V_SUCCESS;

    P_IS_SET := F_ITEM_IS_SET(P_ENTITY_ID, P_ITEM_CODE);
  EXCEPTION
    WHEN V_BIZ_EXCEPTION THEN
      P_RESULT  := -28907;
      P_ERR_MSG := '判断产品是否套件发生错误。';
    WHEN OTHERS THEN
      P_RESULT  := -28907;
      P_ERR_MSG := '判断产品是否套件发生异常：' || SQLERRM;
  END;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-08-16
  *     创建者：廖丽章
  *   功能说明：获取负库存标识：根据单据类型ID和仓库ID取
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_GET_NEGATIVE_INV_FLAG(P_ENTITY_ID         IN NUMBER, --主体ID add by chen.wj 20150214
                                    P_BILL_TYPE_ID      IN NUMBER, --客户ID
                                    P_INV_ID            IN NUMBER, --仓库ID
                                    P_NEGATIVE_INV_FLAG OUT VARCHAR2, --是否允许负库存，是  Y，否 N，默认为 是 Y。
                                    P_RESULT            OUT NUMBER, --返回错误ID
                                    P_ERR_MSG           OUT VARCHAR2 --返回错误信息
                                    ) IS
    --单据类型上设置的是否允许负库存标识
    V_NEG_FLAG_BILL VARCHAR2(2);

    --仓库上设置的是否允许负库存标识
    V_NEG_FLAG_INV VARCHAR2(2);

  BEGIN
    P_RESULT  := V_RESULT;
    P_ERR_MSG := V_SUCCESS;

    --获取单据类型的负库存标识
    SELECT NEGATIVE_INVENTORY_FLAG
      INTO V_NEG_FLAG_BILL
      FROM T_INV_BILL_TYPES
     WHERE BILL_TYPE_ID = P_BILL_TYPE_ID
       AND ENTITY_ID = P_ENTITY_ID; --add by chen.wj 20150214

    --获取仓库的负库存标识
    SELECT NEGATIVE_INVENTORY_FLAG
      INTO V_NEG_FLAG_INV
      FROM T_INV_INVENTORIES
     WHERE INVENTORY_ID = P_INV_ID
       AND ENTITY_ID = P_ENTITY_ID; --add by chen.wj 20150214

    IF (V_NEG_FLAG_BILL IS NOT NULL) AND (V_NEG_FLAG_BILL = 'Y') THEN
      --业务单据类型若是允许负库存，则不对仓库是否允许负库存进行判断，直接返回允许负库存
      P_NEGATIVE_INV_FLAG := 'Y';
    ELSE
      --业务单据类型不允许负库存，则需对仓库进行是否允许负库存判断
      IF (V_NEG_FLAG_INV IS NOT NULL) AND (V_NEG_FLAG_INV = 'Y') THEN
        P_NEGATIVE_INV_FLAG := 'Y';
      ELSE
        P_NEGATIVE_INV_FLAG := 'N';
      END IF;
    END IF;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      P_RESULT  := -28908;
      P_ERR_MSG := '获取负库存标识发生错误：单据类型[ID：' || P_BILL_TYPE_ID || ']或仓库[ID：' ||
                   P_INV_ID || ']不存在。';
    WHEN OTHERS THEN
      P_RESULT  := -28908;
      P_ERR_MSG := '获取负库存标识发生异常：' || SQLERRM;
  END;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-25
  *     创建者：廖丽章
  *   功能说明：判断销售单据是否可红冲
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_ALLOW_REVERSAL(P_SO_HEADER_ID   IN NUMBER, --销售单据头ID
                                P_ALLOW_REVERSAL OUT VARCHAR2, --是否可红冲：Y-是，N-否
                                P_RESULT         OUT NUMBER, --返回错误ID
                                P_ERR_MSG        OUT VARCHAR2 --返回错误信息
                                ) IS
    --发票号串
    V_INVOICE_NUM_LIST T_SO_HEADER.INVOICE_NUM_LIST%TYPE;
    --业务单据源类型编码
    V_BIZ_SRC_BILL_TYPE_CODE T_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE%TYPE;

    --用于是否已到发票池
    V_TRX_COUNT NUMBER := 0;

  BEGIN
    P_RESULT  := V_RESULT;
    P_ERR_MSG := V_SUCCESS;

    --取销售单据发票号串
    BEGIN
      SELECT INVOICE_NUM_LIST, BIZ_SRC_BILL_TYPE_CODE
        INTO V_INVOICE_NUM_LIST, V_BIZ_SRC_BILL_TYPE_CODE
        FROM T_SO_HEADER
       WHERE SO_HEADER_ID = P_SO_HEADER_ID;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        P_ERR_MSG := '单据[ID：' || P_SO_HEADER_ID || ']不存在。';
        RAISE V_BIZ_EXCEPTION;
      WHEN OTHERS THEN
        P_ERR_MSG := '获取单据[ID：' || P_SO_HEADER_ID || ']信息发生异常：' || SQLERRM;
        RAISE V_BIZ_EXCEPTION;
    END;

    --红冲单不能被红冲
    IF (V_BIZ_SRC_BILL_TYPE_CODE = V_BIZ_SRC_BILL_SO_RED) OR
       (V_BIZ_SRC_BILL_TYPE_CODE = V_BIZ_SRC_BILL_RETURN_RED) OR
       (V_BIZ_SRC_BILL_TYPE_CODE = V_BIZ_SRC_BILL_SO_DISCOUNT_RED) OR
       (V_BIZ_SRC_BILL_TYPE_CODE = V_BIZ_SRC_BILL_DISCOUNT_RED) OR
       (V_BIZ_SRC_BILL_TYPE_CODE = V_BIZ_SRC_BILL_RATE_RED) THEN
      P_ERR_MSG := '红冲单[ID：' || P_SO_HEADER_ID || ']不可红冲。';
      RAISE V_BIZ_EXCEPTION;
    END IF;

    --判断销售单据是否已到发票池
    SELECT COUNT(*)
      INTO V_TRX_COUNT
      FROM T_SO_TRX_HEADER_RELATION
     WHERE SO_HEAD_ID = P_SO_HEADER_ID;

    --如果销售单据已开发票或已经到发票池（合并送审），则不允许对该销售单据进行红冲。
    IF (NVL(V_INVOICE_NUM_LIST,'-') != '-' OR V_TRX_COUNT > 0) THEN
      P_ALLOW_REVERSAL := V_NO;
    ELSE
      P_ALLOW_REVERSAL := V_YES;
    END IF;

  EXCEPTION
    WHEN V_BIZ_EXCEPTION THEN
      P_RESULT  := -28909;
      P_ERR_MSG := '判断单据是否可红冲出错：' || P_ERR_MSG;
    WHEN OTHERS THEN
      P_RESULT  := -28909;
      P_ERR_MSG := '判断单据是否可红冲发生异常：' || SQLERRM;
  END;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-01-21
  *     创建者：申广延
  *   功能说明：根据源单据类型取对应主体的业务单据类型(前提：只能取一对一关系)
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_GET_BILL_TYPE_BY_SRC_TYPE(P_ENTITY_ID      IN NUMBER, --主体ID
                                        P_SRC_TYPE_CODE  IN VARCHAR2, --源单类型代码
                                        P_BILL_TYPE_CODE OUT VARCHAR2, --单据类型代码
                                        P_RESULT         OUT NUMBER, --返回错误ID
                                        P_ERR_MSG        OUT VARCHAR2 --返回错误信息
                                        ) IS

    V_BILL_TYPE_CODE VARCHAR2(100);
  BEGIN
    P_RESULT  := V_RESULT;
    P_ERR_MSG := V_SUCCESS;

    BEGIN
      SELECT BILL_TYPE_CODE
        INTO V_BILL_TYPE_CODE
        FROM V_SO_BILL_TYPE
       WHERE SRC_TYPE_CODE = P_SRC_TYPE_CODE
         AND ENTITY_ID = P_ENTITY_ID;

      P_BILL_TYPE_CODE := V_BILL_TYPE_CODE;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        P_ERR_MSG := '单据类型[ENTITY_ID：' || P_ENTITY_ID || ',SRC_TYPE_CODE：' ||
                     P_SRC_TYPE_CODE || ']不存在。';
        RAISE V_BIZ_EXCEPTION;
      WHEN OTHERS THEN
        P_ERR_MSG := '获取单据[ENTITY_ID：' || P_ENTITY_ID || ',SRC_TYPE_CODE：' ||
                     P_SRC_TYPE_CODE || ']信息发生异常：' || SQLERRM;
        RAISE V_BIZ_EXCEPTION;
    END;

  EXCEPTION
    WHEN V_BIZ_EXCEPTION THEN
      P_RESULT  := -28912;
      P_ERR_MSG := '根据源单据类型取业务单据类型出错：' || P_ERR_MSG;
    WHEN OTHERS THEN
      P_RESULT  := -28912;
      P_ERR_MSG := '根据源单据类型取业务单据类型发生异常：' || SQLERRM;
  END;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-25
  *     创建者：廖丽章
  *   功能说明：更新销售单据的红冲标识
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_UPDATE_REVERSAL_FLAG(P_SO_HEADER_ID IN NUMBER, --销售单据头ID（蓝单）
                                      P_USER_CODE    IN VARCHAR2, --操作用户编码
                                      P_RESULT       OUT NUMBER, --返回错误ID
                                      P_ERR_MSG      OUT VARCHAR2 --返回错误信息
                                      ) IS
    CURSOR C_SO_INFO IS
      SELECT SO_NUM, BIZ_SRC_BILL_TYPE_CODE
        FROM T_SO_HEADER
       WHERE SO_HEADER_ID = P_SO_HEADER_ID;
    R_SO_INFO C_SO_INFO%ROWTYPE;

    --单据号
    V_SO_NUM T_SO_HEADER.SO_NUM%TYPE;

    --红冲标识
    V_REVERSAL_FLAG VARCHAR2(2);

    --产品数量
    V_ITEM_QTY NUMBER;
    --红冲数量
    V_REVERSAL_QTY NUMBER;

    --金额
    V_AMOUNT NUMBER;
    --红冲金额
    V_REVERSAL_AMOUNT NUMBER;

  BEGIN
    P_RESULT  := V_RESULT;
    P_ERR_MSG := V_SUCCESS;

    OPEN C_SO_INFO;
    FETCH C_SO_INFO
      INTO R_SO_INFO;
    CLOSE C_SO_INFO;

    --销售单、退货单根据行的已红冲数量字段来判断是否已全部或部分红冲
    IF R_SO_INFO.BIZ_SRC_BILL_TYPE_CODE IN
       (V_BIZ_SRC_BILL_SO, V_BIZ_SRC_BILL_RETURN) THEN
      --获取（蓝单）开单产品数量与红冲数量
      SELECT SUM(NVL(SL.ITEM_QTY, 0)), SUM(NVL(SL.REVERSAL_QTY, 0))
        INTO V_ITEM_QTY, V_REVERSAL_QTY
        FROM T_SO_HEADER SH, T_SO_LINE SL
       WHERE SH.SO_HEADER_ID = SL.SO_HEADER_ID
         AND SH.SO_HEADER_ID = P_SO_HEADER_ID
       GROUP BY SH.SO_HEADER_ID;

      IF (V_REVERSAL_QTY = 0) THEN
        V_REVERSAL_FLAG := '10'; --未红冲
      ELSIF (V_ITEM_QTY = V_REVERSAL_QTY) THEN
        V_REVERSAL_FLAG := '11'; --全部红冲
      ELSIF (V_ITEM_QTY > V_REVERSAL_QTY) THEN
        V_REVERSAL_FLAG := '12'; --部分红冲
      END IF;
    ELSIF R_SO_INFO.BIZ_SRC_BILL_TYPE_CODE IN
          (V_BIZ_SRC_BILL_SO_DISCOUNT,
           V_BIZ_SRC_BILL_DISCOUNT,
           V_BIZ_SRC_BILL_RATE) THEN
      --折让单
      --获取（蓝单）开单折让单金额与红冲金额
      SELECT SUM(NVL(SL.ITEM_SETTLE_AMOUNT, 0)),
             SUM(NVL(SL.REVERSAL_AMOUNT, 0))
        INTO V_AMOUNT, V_REVERSAL_AMOUNT
        FROM T_SO_HEADER SH, T_SO_LINE SL
       WHERE SH.SO_HEADER_ID = SL.SO_HEADER_ID
         AND SH.SO_HEADER_ID = P_SO_HEADER_ID
       GROUP BY SH.SO_HEADER_ID;

      IF (V_REVERSAL_AMOUNT = 0) THEN
        V_REVERSAL_FLAG := '10'; --未红冲
      ELSIF (V_AMOUNT = V_REVERSAL_AMOUNT) THEN
        V_REVERSAL_FLAG := '11'; --全部红冲
      ELSIF (V_AMOUNT > V_REVERSAL_AMOUNT) THEN
        V_REVERSAL_FLAG := '12'; --部分红冲
      END IF;
    END IF;

    IF (V_REVERSAL_FLAG IS NOT NULL) THEN
      --更新蓝单上的红冲标识
      UPDATE T_SO_HEADER
         SET REVERSAL_FLAG   = V_REVERSAL_FLAG,
             REVERSALED_BY   = P_USER_CODE,
             REVERSALED_DATE = SYSDATE
       WHERE SO_HEADER_ID = P_SO_HEADER_ID;
    END IF;

  EXCEPTION
    WHEN V_BIZ_EXCEPTION THEN
      P_RESULT  := -28910;
      P_ERR_MSG := '更新销售单据的红冲标识出错：' || P_ERR_MSG;
    WHEN OTHERS THEN
      P_RESULT  := -28910;
      P_ERR_MSG := '更新销售单据的红冲标识发生异常：' || SQLERRM;
  END;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-25
  *     创建者：廖丽章
  *   功能说明：获取仓库信息
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_GET_INV_INFO(P_INV_ID   IN NUMBER, --仓库ID
                           P_INV_INFO OUT INV_INFO, --仓库信息记录
                           P_RESULT   OUT NUMBER, --返回错误ID
                           P_ERR_MSG  OUT VARCHAR2 --返回错误信息
                           ) IS
    V_CNT_INV NUMBER;
  BEGIN
    P_RESULT  := V_RESULT;
    P_ERR_MSG := V_SUCCESS;

    --判断仓库是否存在
    SELECT COUNT(*)
      INTO V_CNT_INV
      FROM T_INV_INVENTORIES
     WHERE INVENTORY_ID = P_INV_ID;
    IF V_CNT_INV = 0 THEN
      P_ERR_MSG := '仓库[ID：' || P_INV_ID || ']不存在。';
      RAISE V_BIZ_EXCEPTION;
    END IF;

    --判断仓库是否已失效
    SELECT COUNT(*)
      INTO V_CNT_INV
      FROM T_INV_INVENTORIES
     WHERE INVENTORY_ID = P_INV_ID
       AND (TRUNC(SYSDATE) BETWEEN BEGIN_DATE AND NVL(END_DATE, SYSDATE));

    IF V_CNT_INV = 0 THEN
      P_ERR_MSG := '仓库[ID：' || P_INV_ID || ']已失效。';
      RAISE V_BIZ_EXCEPTION;
    END IF;

    --获取仓库信息
    SELECT INVENTORY_ID,
           INVENTORY_CODE,
           INVENTORY_NAME,
           NOSETTLED_INVENTORY_ID,
           ONWAY_INVENTORY_ID,
           RETURN_INVENTORY_ID,
           ORGANIZATION_ID
      INTO P_INV_INFO.INVENTORY_ID,
           P_INV_INFO.INVENTORY_CODE,
           P_INV_INFO.INVENTORY_NAME,
           P_INV_INFO.NOSETTLED_INVENTORY_ID,
           P_INV_INFO.ONWAY_INVENTORY_ID,
           P_INV_INFO.RETURN_INVENTORY_ID,
           P_INV_INFO.ORGANIZATION_ID
      FROM T_INV_INVENTORIES
     WHERE INVENTORY_ID = P_INV_ID;

  EXCEPTION
    WHEN V_BIZ_EXCEPTION THEN
      P_RESULT  := -28911;
      P_ERR_MSG := '获取仓库信息出错：' || P_ERR_MSG;
    WHEN OTHERS THEN
      P_RESULT  := -28911;
      P_ERR_MSG := '获取仓库信息发生异常：' || SQLERRM;
  END;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-25
  *     创建者：廖丽章
  *   功能说明：往整型数组里加数据
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_ARRAY_PUT(P_ARRAY IN OUT TYPE_ARRAY, --整型数组
                        P_VALUE IN NUMBER --整型数据
                        ) IS
    --数组长度
    V_ARR_LEN NUMBER := 0;

  BEGIN
    IF P_ARRAY IS NULL THEN
      P_ARRAY(1) := P_VALUE;
    ELSE
      --获取数组元素个数
      V_ARR_LEN := P_ARRAY.COUNT;
      --把数据加到数组里
      P_ARRAY(V_ARR_LEN + 1) := P_VALUE;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      P_ARRAY(1) := P_VALUE;
  END;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-25
  *     创建者：廖丽章
  *   功能说明：保存异常信息到销售业务异常表
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SAVE_EXPT_INFO(P_EXPT_COMMON_INFO IN EXCEPTION_COMMON_INFO, --异常信息公共信息记录集
                             P_EXPT_ARRAY       IN TYPE_EXCEPTION_ARRAY --异常信息数组
                             ) IS
    --异常信息数组长度
    V_ARR_LEN NUMBER;

  BEGIN
    IF P_EXPT_ARRAY IS NOT NULL THEN
      V_ARR_LEN := P_EXPT_ARRAY.COUNT;

      --把销售单据生成过程的异常信息保存到异常业务表中
      FOR I IN 1 .. V_ARR_LEN LOOP
        INSERT INTO T_SO_EXCEPTION
          (SO_EXCEPTION_ID,
           BIZ_TABLE_NAME,
           BIZ_TABLE_NAME_CN,
           BIZ_KEY_ID,
           BIZ_OPER_CODE,
           BIZ_OPER_NAME,
           EXCEPTION_CODE,
           EXCEPTION_NAME,
           EXCEPTION_REMARK,
           --EXCEPTION_PROC_RESULT, --取默认值
           --EXCEPTION_PROC_COUNT, --取默认值
           CREATED_BY,
           CREATION_DATE,
           LAST_UPDATED_BY,
           LAST_UPDATE_DATE)
        VALUES
          (S_SO_EXCEPTION.NEXTVAL,
           P_EXPT_COMMON_INFO.BIZ_TABLE_NAME,
           P_EXPT_COMMON_INFO.BIZ_TABLE_NAME_CN,
           P_EXPT_COMMON_INFO.BIZ_KEY_ID,
           P_EXPT_ARRAY                        (I).BIZ_OPER_CODE,
           P_EXPT_ARRAY                        (I).BIZ_OPER_NAME,
           P_EXPT_ARRAY                        (I).EXCEPTION_CODE,
           P_EXPT_ARRAY                        (I).EXCEPTION_NAME,
           P_EXPT_ARRAY                        (I).EXCEPTION_REMARK,
           P_EXPT_COMMON_INFO.CREATED_BY,
           P_EXPT_COMMON_INFO.CREATION_DATE,
           P_EXPT_COMMON_INFO.LAST_UPDATED_BY,
           P_EXPT_COMMON_INFO.LAST_UPDATE_DATE);
      END LOOP;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      NULL;
  END;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-25
  *     创建者：廖丽章
  *   功能说明：往异常信息记录集数组里加数据
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_EXCEPTION_ARRAY_PUT(P_EXPT_ARRAY IN OUT TYPE_EXCEPTION_ARRAY, --异常信息记录集数组
                                  P_EXPT       IN EXCEPTION_INFO --异常信息记录集
                                  ) IS
    --数组长度
    V_ARR_LEN NUMBER := 0;

  BEGIN
    IF P_EXPT_ARRAY IS NULL THEN
      P_EXPT_ARRAY(1) := P_EXPT;
    ELSE
      --获取数组元素个数
      V_ARR_LEN := P_EXPT_ARRAY.COUNT;
      --把数据加到数组里
      P_EXPT_ARRAY(V_ARR_LEN + 1) := P_EXPT;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      P_EXPT_ARRAY(1) := P_EXPT;
  END;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-25
  *     创建者：廖丽章
  *   功能说明：是否抛出异常
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_EXCEPTION_THROWS(P_EXPT_CODE IN NUMBER) IS
  BEGIN
    IF P_EXPT_CODE < 0 THEN
      RAISE V_BIZ_EXCEPTION;
    END IF;
  END;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-05
  *     创建者：廖丽章
  *   功能说明：根据行政区划编码，获取上级区划编码
  */
  -------------------------------------------------------------------------------
  FUNCTION F_GET_PARENT_DISTRICT_CODE(P_DISTRICT_CODE IN VARCHAR2)
    RETURN VARCHAR2 IS
    --上级区划编码
    V_PAR_CODE VARCHAR2(100);
  BEGIN
    SELECT BD.DISTRICT_CODE
      INTO V_PAR_CODE
      FROM T_BD_DISTRICT BD
     WHERE BD.ROW_ID = (SELECT PAR_ROW_ID
                          FROM T_BD_DISTRICT
                         WHERE DISTRICT_CODE = P_DISTRICT_CODE);

    RETURN V_PAR_CODE;

  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      V_PAR_CODE := NULL;
      RETURN V_PAR_CODE;
    WHEN OTHERS THEN
      RAISE V_BIZ_EXCEPTION;
  END;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-05
  *     创建者：廖丽章
  *   功能说明：判断产品是否套件，Y-是，N-否
  */
  -------------------------------------------------------------------------------
  /*  mark by shengy20150131
    FUNCTION F_ITEM_IS_SET(P_ITEM_CODE IN VARCHAR2) RETURN VARCHAR2 IS
      --是否套件标识
      V_IS_SET CHAR(1) := 'N';

      --产品形态：SET_PRODUCT（套件）
      V_PRODUCTFORM VARCHAR2(500);

    BEGIN
      --判断产品是否为套件，产品形态字段的值为’SET_PRODUCT‘则表明是套件
      SELECT PRODUCTFORM
        INTO V_PRODUCTFORM
        FROM T_BD_ITEM
       WHERE ITEM_CODE = P_ITEM_CODE;

      IF V_PRODUCTFORM = 'SET_PRODUCT' THEN
        V_IS_SET := 'Y';
      END IF;

      RETURN V_IS_SET;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        V_IS_SET := 'N';
        RETURN V_IS_SET;
      WHEN OTHERS THEN
        RAISE V_BIZ_EXCEPTION;
    END;
  */
  FUNCTION F_ITEM_IS_SET(P_ENTITY_ID IN NUMBER, --主体ID
                         P_ITEM_CODE IN VARCHAR2) RETURN VARCHAR2 IS
    --是否套件标识
    V_IS_SET CHAR(1) := 'N';

    --产品形态：SET_PRODUCT（套件）
    V_PRODUCTFORM VARCHAR2(500);

  BEGIN
    --判断产品是否为套件，产品形态字段的值为’SET_PRODUCT‘则表明是套件
    SELECT PRODUCTFORM
      INTO V_PRODUCTFORM
      FROM T_BD_ITEM
     WHERE ITEM_CODE = P_ITEM_CODE
       AND ENTITY_ID = P_ENTITY_ID;

    IF V_PRODUCTFORM = 'SET_PRODUCT' THEN
      V_IS_SET := 'Y';
    END IF;

    RETURN V_IS_SET;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      V_IS_SET := 'N';
      RETURN V_IS_SET;
    WHEN OTHERS THEN
      RAISE V_BIZ_EXCEPTION;
  END;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-08-16
  *     创建者：廖丽章
  *   功能说明：获取应收发票配置信息
  */
  -------------------------------------------------------------------------------
  FUNCTION F_GET_AR_CONFIG(P_CUSTOMER_ID     IN NUMBER, --客户ID
                           P_SALES_CENTER_ID IN NUMBER, --营销中心ID
                           P_ENTITY_ID       IN NUMBER, --主体ID
                           P_ERP_OU_ID       IN NUMBER --ERP经营单位ID
                           ) RETURN AR_CONFIG IS
    --应收发票配置信息
    V_AR_CONFIG AR_CONFIG;

    V_AR_CONF_ID T_AR_CONF.AR_CONF_ID%TYPE;
    --末是否结算到下个月一号的标识
    V_SETTLE_NEXT_MONTH_FLAG T_AR_CONF.SETTLE_NEXT_MONTH_FLAG%TYPE;
    --应收配置始点
    V_AR_CONF_INITIAL T_AR_CONF.AR_CONF_INITIAL%TYPE;
    --自动结算标识
    V_AUTO_SETTLE_FLAG T_AR_CONF.AUTO_SETTLE_FLAG%TYPE;
    --开票申请标志
    V_APPLY_FLAG T_AR_CONF.APPLY_FLAG%TYPE;
    --开票审核标志
    V_APPROVAL_FLAG T_AR_CONF.APPROVAL_FLAG%TYPE;

  BEGIN
    V_SETTLE_NEXT_MONTH_FLAG := 'N';
    V_AR_CONF_ID             := NULL; 

    BEGIN
      --先按客户、营销中心、主体去取
      SELECT AR_CONF_ID,SETTLE_NEXT_MONTH_FLAG,
             AR_CONF_INITIAL,
             AUTO_SETTLE_FLAG,
             APPLY_FLAG,
             APPROVAL_FLAG
        INTO V_AR_CONF_ID,V_SETTLE_NEXT_MONTH_FLAG,
             V_AR_CONF_INITIAL,
             V_AUTO_SETTLE_FLAG,
             V_APPLY_FLAG,
             V_APPROVAL_FLAG
        FROM T_AR_CONF
       WHERE CUSTOMER_ID = P_CUSTOMER_ID
         AND SALES_CENTER_ID = P_SALES_CENTER_ID
         AND ENTITY_ID = P_ENTITY_ID
         AND ROWNUM = 1;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        V_AR_CONF_ID             := NULL;
        V_SETTLE_NEXT_MONTH_FLAG := NULL;
        V_AR_CONF_INITIAL        := NULL;
        V_AUTO_SETTLE_FLAG       := NULL;
        V_APPLY_FLAG             := NULL;
        V_APPROVAL_FLAG          := NULL;
      WHEN OTHERS THEN
        V_AR_CONF_ID             := NULL;
        V_SETTLE_NEXT_MONTH_FLAG := NULL;
        V_AR_CONF_INITIAL        := NULL;
        V_AUTO_SETTLE_FLAG       := NULL;
        V_APPLY_FLAG             := NULL;
        V_APPROVAL_FLAG          := NULL;
    END;

    --按客户、营销中心、主体取不到，则再按营销中心、主体去取
    IF (V_AR_CONF_ID IS NULL) THEN
      BEGIN
        --按营销中心、主体去取
        SELECT AR_CONF_ID,SETTLE_NEXT_MONTH_FLAG,
               AR_CONF_INITIAL,
               AUTO_SETTLE_FLAG,
               APPLY_FLAG,
               APPROVAL_FLAG
          INTO V_AR_CONF_ID,V_SETTLE_NEXT_MONTH_FLAG,
               V_AR_CONF_INITIAL,
               V_AUTO_SETTLE_FLAG,
               V_APPLY_FLAG,
               V_APPROVAL_FLAG
          FROM T_AR_CONF
         WHERE CUSTOMER_ID IS NULL
           AND SALES_CENTER_ID = P_SALES_CENTER_ID
           AND ENTITY_ID = P_ENTITY_ID
           AND ROWNUM = 1;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          V_AR_CONF_ID             := NULL;
          V_SETTLE_NEXT_MONTH_FLAG := NULL;
          V_AR_CONF_INITIAL        := NULL;
          V_AUTO_SETTLE_FLAG       := NULL;
          V_APPLY_FLAG             := NULL;
          V_APPROVAL_FLAG          := NULL;
        WHEN OTHERS THEN
          V_AR_CONF_ID             := NULL;
          V_SETTLE_NEXT_MONTH_FLAG := NULL;
          V_AR_CONF_INITIAL        := NULL;
          V_AUTO_SETTLE_FLAG       := NULL;
          V_APPLY_FLAG             := NULL;
          V_APPROVAL_FLAG          := NULL;
      END;
    END IF;

    --按营销中心、主体取不到，则再按主体、OU去取
    IF (V_AR_CONF_ID IS NULL) THEN
      BEGIN
        --按主体去取
        SELECT AR_CONF_ID,SETTLE_NEXT_MONTH_FLAG,
               AR_CONF_INITIAL,
               AUTO_SETTLE_FLAG,
               APPLY_FLAG,
               APPROVAL_FLAG
          INTO V_AR_CONF_ID,V_SETTLE_NEXT_MONTH_FLAG,
               V_AR_CONF_INITIAL,
               V_AUTO_SETTLE_FLAG,
               V_APPLY_FLAG,
               V_APPROVAL_FLAG
          FROM T_AR_CONF
         WHERE CUSTOMER_ID IS NULL
           AND SALES_CENTER_ID IS NULL
           AND ENTITY_ID = P_ENTITY_ID
           AND ERP_OU = TO_CHAR(P_ERP_OU_ID)
           AND ROWNUM = 1;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          V_AR_CONF_ID             := NULL;
          V_SETTLE_NEXT_MONTH_FLAG := NULL;
          V_AR_CONF_INITIAL        := NULL;
          V_AUTO_SETTLE_FLAG       := NULL;
          V_APPLY_FLAG             := NULL;
          V_APPROVAL_FLAG          := NULL;
        WHEN OTHERS THEN
          V_AR_CONF_ID             := NULL;
          V_SETTLE_NEXT_MONTH_FLAG := NULL;
          V_AR_CONF_INITIAL        := NULL;
          V_AUTO_SETTLE_FLAG       := NULL;
          V_APPLY_FLAG             := NULL;
          V_APPROVAL_FLAG          := NULL;
      END;
    END IF;
    
    V_AR_CONFIG.AR_CONF_ID             := V_AR_CONF_ID;
    V_AR_CONFIG.SETTLE_NEXT_MONTH_FLAG := V_SETTLE_NEXT_MONTH_FLAG;
    V_AR_CONFIG.AR_CONF_INITIAL        := V_AR_CONF_INITIAL;
    V_AR_CONFIG.AUTO_SETTLE_FLAG       := V_AUTO_SETTLE_FLAG;
    V_AR_CONFIG.APPLY_FLAG             := V_APPLY_FLAG;
    V_AR_CONFIG.APPROVAL_FLAG          := V_APPROVAL_FLAG;

    RETURN V_AR_CONFIG;
  EXCEPTION
    WHEN OTHERS THEN
      V_AR_CONFIG.AR_CONF_ID             := NULL;
      V_AR_CONFIG.SETTLE_NEXT_MONTH_FLAG := NULL;
      V_AR_CONFIG.AR_CONF_INITIAL        := NULL;
      V_AR_CONFIG.AUTO_SETTLE_FLAG       := NULL;
      V_AR_CONFIG.APPLY_FLAG             := NULL;
      V_AR_CONFIG.APPROVAL_FLAG          := NULL;

      RETURN V_AR_CONFIG;
  END;
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2017-08-10
  *     创建者：周建刚
  *   功能说明：获取应收发票配置ID标识
  */
  -------------------------------------------------------------------------------
  FUNCTION F_GET_AR_CONFIG_ID(P_CUSTOMER_ID     IN NUMBER, --客户ID
                             P_SALES_CENTER_ID IN NUMBER, --营销中心ID
                             P_ENTITY_ID       IN NUMBER, --主体ID
                             P_ERP_OU_ID       IN NUMBER --ERP经营单位ID
                             ) RETURN NUMBER IS
                           
    V_AR_CONF_ID T_AR_CONF.AR_CONF_ID%TYPE := -1;
    --应收发票配置记录
    V_AR_CONFIG PKG_SO_PUB.AR_CONFIG;
  BEGIN
    V_AR_CONFIG := F_GET_AR_CONFIG(P_CUSTOMER_ID,P_SALES_CENTER_ID,P_ENTITY_ID,P_ERP_OU_ID);
    V_AR_CONF_ID := V_AR_CONFIG.AR_CONF_ID;
    
    RETURN V_AR_CONF_ID;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN -1;
  END;
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-08-16
  *     创建者：廖丽章
  *   功能说明：获取单据类型信息（T_INV_BILL_TYPES）
  */
  -------------------------------------------------------------------------------
  FUNCTION F_GET_INV_BILL_TYPE_INFO(P_BILL_TYPE_ID IN NUMBER)
    RETURN INV_BILL_TYPE_INFO IS
    --库存单据类型信息记录
    V_TYPE_INFO INV_BILL_TYPE_INFO;
  BEGIN
    SELECT BILL_TYPE_ID, BILL_TYPE_CODE, BILL_TYPE_NAME
      INTO V_TYPE_INFO.BILL_TYPE_ID,
           V_TYPE_INFO.BILL_TYPE_CODE,
           V_TYPE_INFO.BILL_TYPE_NAME
      FROM T_INV_BILL_TYPES
     WHERE BILL_TYPE_ID = P_BILL_TYPE_ID;

    RETURN V_TYPE_INFO;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      V_TYPE_INFO.BILL_TYPE_ID   := NULL;
      V_TYPE_INFO.BILL_TYPE_CODE := NULL;
      V_TYPE_INFO.BILL_TYPE_NAME := NULL;

      RETURN V_TYPE_INFO;
    WHEN OTHERS THEN
      V_TYPE_INFO.BILL_TYPE_ID   := NULL;
      V_TYPE_INFO.BILL_TYPE_CODE := NULL;
      V_TYPE_INFO.BILL_TYPE_NAME := NULL;

      RETURN V_TYPE_INFO;
  END;
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-01-06
  *     创建者：陈武杰
  *   功能说明：根据当前行政区划编码和返回类型，获得行政区划编码
  */
  -------------------------------------------------------------------------------
  FUNCTION F_GET_DISTRICT(P_DISTRICT_CODE IN VARCHAR2, --地区编码
                          P_RETURN_TYPE   NUMBER --P_RETURN_TYPE对应LEVEL_SEQ,1-大区，2-省，自治区，3-市，4-县，5-乡镇
                          ) RETURN VARCHAR2 IS
    V_ROW_ID               T_BD_DISTRICT.ROW_ID%TYPE;
    V_LEVEL_SEQ            T_BD_DISTRICT.LEVEL_SEQ%TYPE; --1-大区，2-省，自治区，3-市，4-县，5-乡镇
    V_RETURN_DISTRICT_CODE T_BD_DISTRICT.DISTRICT_CODE%TYPE;
    V_LEVEL                NUMBER; --行政区划层级
  BEGIN
    V_RETURN_DISTRICT_CODE := '';
    IF P_RETURN_TYPE IS NULL THEN
      RETURN V_RETURN_DISTRICT_CODE;
    END IF;

    BEGIN
      SELECT ROW_ID, LEVEL_SEQ
        INTO V_ROW_ID, V_LEVEL_SEQ
        FROM T_BD_DISTRICT
       WHERE DISTRICT_CODE = P_DISTRICT_CODE;
    EXCEPTION
      WHEN OTHERS THEN
        RETURN V_RETURN_DISTRICT_CODE;
    END;
    --判断返回级别必须是自生或上级行政区划级别
    IF P_RETURN_TYPE > V_LEVEL_SEQ THEN
      RETURN V_RETURN_DISTRICT_CODE;
    END IF;

    BEGIN
      --递归获取上级行政区划编号
      /**
      SELECT CONNECT_BY_ROOT(A.DISTRICT_CODE), LEVEL
        INTO V_RETURN_DISTRICT_CODE, V_LEVEL
        FROM T_BD_DISTRICT A
       WHERE ROW_ID = V_ROW_ID
       START WITH LEVEL_SEQ = P_RETURN_TYPE
      CONNECT BY PRIOR ROW_ID = PAR_ROW_ID;
      */
      
      SELECT DISTRICT_CODE, LEVEL
        INTO V_RETURN_DISTRICT_CODE, V_LEVEL
        FROM T_BD_DISTRICT A
       WHERE  LEVEL_SEQ = P_RETURN_TYPE
       START WITH ROW_ID = V_ROW_ID
      CONNECT BY PRIOR PAR_ROW_ID = ROW_ID;
    EXCEPTION
      WHEN OTHERS THEN
        RETURN V_RETURN_DISTRICT_CODE;
    END;
    --dbms_output.put_line(V_LEVEL);
    RETURN V_RETURN_DISTRICT_CODE;
  END F_GET_DISTRICT;
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-02-04
  *     创建者：陈武杰
  *   功能说明：交易单据行产品上面的不含税价格获取是否正常
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_CHECK_NOT_REVENUE_PRICE(P_SO_HEADER_ID IN NUMBER, --销售单据头ID
                                      P_RESULT       IN OUT NUMBER, --返回错误ID
                                      P_ERR_MSG      IN OUT VARCHAR2 --返回错误信息
                                      ) AS
    --财务单头表信息游标
    CURSOR C_SO_HEADER IS
      SELECT T.* FROM T_SO_HEADER T WHERE T.SO_HEADER_ID = P_SO_HEADER_ID;
    --财务单头表信息记录
    R_SO_HEADER C_SO_HEADER%ROWTYPE;
    --供应商编码
    V_VENDOR_CODE T_INV_VENDOR_ORGANIZATION.VENDOR_CODE%TYPE;
    --价格列表ID
    V_PRICE_LIST_ID T_BD_VENDOR_PRICELIST.PRICE_LIST_ID%TYPE;
    --不含税价格
    V_PRICE        NUMBER;
    V_PUSH_OR_PULL VARCHAR2(50);
    V_PULL_MODE    NUMBER;
    ----------add by wangc 2015-6-23--------
    --当前日期
    V_CURR_DATE DATE;
    --日期格式
    V_DATA_FORMAT  VARCHAR2(10) := 'YYYY-MM-DD';
     --当前时间
    V_CURR_TIME DATE := SYSDATE;
    -----------------------------------------

    V_SUPPLIER_ORG_ID INTF_CUX_ICP_ORDER_REQ_HEADERS.SUPPLIER_ORG_ID%TYPE; --SUPPLIER_ORG_ID供方OU ID
    V_SUPPLIER_ORG    INTF_CUX_ICP_ORDER_REQ_HEADERS.SUPPLIER_ORG%TYPE; --SUPPLIER_ORG供方OU
    V_SHIPPING_ORG_ID INTF_CUX_ICP_ORDER_REQ_HEADERS.SHIPPING_ORG_ID%TYPE; -- SHIPPING_ORG_ID 发运组织ID
    V_SHIPPING_ORG    INTF_CUX_ICP_ORDER_REQ_HEADERS.SHIPPING_ORG%TYPE; -- SHIPPING_ORG 发运组织

    V_SO_TRX_MODE VARCHAR2(10);
  BEGIN
    P_RESULT  := PKG_SO_PUB.V_RESULT;
    P_ERR_MSG := '';

    --P_SO_HEADER_ID := 16145;

    --获取销售单据头数据
    OPEN C_SO_HEADER;
    FETCH C_SO_HEADER
      INTO R_SO_HEADER;
    CLOSE C_SO_HEADER;

    --add by chen.wj 20150319 如果是推广物料销售单，不继续走
    IF NVL(R_SO_HEADER.IS_MATERIAL, 'N') = 'Y' THEN
      RETURN;
    END IF;
    BEGIN
      V_PUSH_OR_PULL :=R_SO_HEADER.TRX_MODE;
      IF V_PUSH_OR_PULL IS NULL THEN
        PKG_BD.P_GET_PARAMETER_VALUE(PKG_SO_PUB.V_ARG_SO_AR_PUSH_OR_PULL,
                                     R_SO_HEADER.ENTITY_ID,
                                     NULL,
                                     NULL,
                                     V_PUSH_OR_PULL);
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        P_ERR_MSG := 'P_CHECK_NOT_REVENUE_PRICE不含税价格判断过程中获取' ||
                     PKG_SO_PUB.V_ARG_SO_AR_PUSH_OR_PULL || '参数失败,主体ID[' ||
                     R_SO_HEADER.ENTITY_ID || ']';
        RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
    END;
    --如果不是拉式，则不进行判断
    IF V_PUSH_OR_PULL <> 'PULL' THEN
      RETURN;
    END IF;
    --如果是拉式销售，还要判断推广物料，拉式推广物料不走关联交易
    IF R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE NOT IN
       (PKG_SO_PUB.V_BIZ_SRC_BILL_SO,
        PKG_SO_PUB.V_BIZ_SRC_BILL_SO_RED,
        PKG_SO_PUB.V_BIZ_SRC_BILL_RETURN,
        PKG_SO_PUB.V_BIZ_SRC_BILL_RETURN_RED) THEN
      RETURN;
    END IF;

    /*--20150427 chen.wj 查询供应商信息，只用工厂OU查询。啊甘、欧阳讨论决定
    IF NVL(R_SO_HEADER.RETURN_MODE, '1') = '3' THEN
      --3-拉式反向销售
      --SUPPLIER_ORG_ID供方OU ID 内销
      V_SUPPLIER_ORG_ID := R_SO_HEADER.ERP_OU_ID;
      V_SUPPLIER_ORG    := R_SO_HEADER.ERP_OU_NAME;

      BEGIN
        --add by chen.wj 20150206
        -- -1错误,0非拉式,1销售,2红冲,3源单退回,4反向销售,5源单退货红冲，6拉式其他单据类型

        V_PULL_MODE := PKG_SO_PUB.F_PULL_MODE(R_SO_HEADER.SO_NUM);
        SELECT DECODE(V_PULL_MODE,
                      1,
                      PKG_SO_PUB.V_SO_TRX_MODE_003,
                      2,
                      PKG_SO_PUB.V_SO_TRX_MODE_004,
                      3,
                      PKG_SO_PUB.V_SO_TRX_MODE_004,
                      4,
                      PKG_SO_PUB.V_SO_TRX_MODE_005,
                      5,
                      PKG_SO_PUB.V_SO_TRX_MODE_003,
                      V_PULL_MODE)
          INTO V_SO_TRX_MODE
          FROM DUAL;
        --工厂OU和ERP OU 交互
        --IF V_SO_TRX_MODE = PKG_SO_PUB.V_SO_TRX_MODE_005 THEN--edit by chen.wj 20150304
        SELECT SUPPLIER_SUBINV_ID, --库存组织
               SUPPLIER_SUBINV_CODE --库存组织编码
          INTO V_SHIPPING_ORG_ID, V_SHIPPING_ORG
          FROM T_SO_SUPPLIER_REQUIREMENT T
         WHERE T.ENTITY_ID = R_SO_HEADER.ENTITY_ID
           AND T.REQUIREMENT_OU_ID = R_SO_HEADER.FACTORY_OU_ID
           AND T.TRADE_MODE_CODE = V_SO_TRX_MODE;

      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          P_ERR_MSG := '供方OU ID[' || R_SO_HEADER.FACTORY_OU_ID || '],主体ID[' ||
                       R_SO_HEADER.ENTITY_ID || '],关联交易模式编码[' ||
                       V_SO_TRX_MODE ||
                       '],T_SO_SUPPLIER_REQUIREMENT表未设置对应的ERP OU！';
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
        WHEN OTHERS THEN
          P_ERR_MSG := '供方OU ID[' || R_SO_HEADER.FACTORY_OU_ID || '],主体ID[' ||
                       R_SO_HEADER.ENTITY_ID || '],关联交易模式编码[' ||
                       V_SO_TRX_MODE ||
                       '],T_SO_SUPPLIER_REQUIREMENT表未设置对应的ERP OU！' || SQLERRM;
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      END;
    ELSE
      --SUPPLIER_ORG_ID供方OU ID 工厂
      V_SUPPLIER_ORG_ID := R_SO_HEADER.FACTORY_OU_ID;
      V_SUPPLIER_ORG    := R_SO_HEADER.FACTORY_OU_NAME;

      --发运库存组织 工厂
      V_SHIPPING_ORG_ID := R_SO_HEADER.ERP_SUBINV_ID;
      V_SHIPPING_ORG    := R_SO_HEADER.ERP_SUBINV_CODE;

    END IF;*/

    BEGIN
      --供应商信息
      SELECT A.VENDOR_CODE --供应商编码
        INTO V_VENDOR_CODE
        FROM V_INV_VENDOR_VIEW A -- edit by chen.wj 20150306 根据苏苏提供视图T_INV_VENDOR_ORGANIZATION A
       WHERE A.ENTITY_ID = R_SO_HEADER.ENTITY_ID --实体ID
         AND A.OPERATING_UNIT = R_SO_HEADER.FACTORY_OU_ID --供方OU ID --20150427 chen.wj 查询供应商信息，只用工厂OU查询。啊甘、欧阳讨论决定
         /*AND A.VENDOR_SITE_OPERATING_UNIT = A.OPERATING_UNIT --edit by chen.wj 20150416啊甘要求只用主体和OU来取供应商编码
         AND A.ORGANIZATION_CODE = V_SHIPPING_ORG  --供方库存组织*/
         AND ROWNUM = 1;

    EXCEPTION
      WHEN OTHERS THEN
        P_ERR_MSG := 'T_INV_VENDOR_ORGANIZATION表查询供应商信息异常：'||Sqlerrm||'！主体ID[' ||
                     R_SO_HEADER.ENTITY_ID || '],供方OU_ID[' ||
                     V_SUPPLIER_ORG_ID || ']';
        RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
    END;

    BEGIN
      --供应商价格列表
      SELECT A.PRICE_LIST_ID --价格列表ID
        INTO V_PRICE_LIST_ID
        FROM T_BD_VENDOR_PRICELIST A
       WHERE A.ENTITY_ID = R_SO_HEADER.ENTITY_ID
         AND A.TYPE_CODE='TRANSIT_TYPE' --add by chen.wj 20150326 增加 中转采购 类别
         AND A.VENDOR_CODE = V_VENDOR_CODE --供应商编码
         --add by chen.wj 20150403 增加有效日期条件
         AND TRUNC(R_SO_HEADER.So_Date ) >= A.BEGIN_DATE
         AND TRUNC(R_SO_HEADER.So_Date ) <= NVL(A.END_DATE, SYSDATE);

    EXCEPTION
      WHEN OTHERS THEN
        P_ERR_MSG := 'T_BD_VENDOR_PRICELIST表查询不到供应商价格列表信息，请维护！供方OU[' ||
                     V_SUPPLIER_ORG_ID || ']，供方库存组织编码[' || V_SHIPPING_ORG ||
                     ']，供应商编码[' || V_VENDOR_CODE || ']';
        RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
    END;

    ---------add by wangc 2015-6-23----------
    --取当前日期
    V_CURR_DATE := TO_DATE(TO_CHAR(V_CURR_TIME, V_DATA_FORMAT),
                           V_DATA_FORMAT);
    -----------------------------------------
    FOR REC IN (SELECT ITEM_CODE, ITEM_PRICE
                  FROM T_SO_LINE A
                 WHERE A.SO_HEADER_ID = R_SO_HEADER.SO_HEADER_ID) LOOP

      BEGIN
        V_PRICE := PKG_BD_PRICE.F_GET_PRICE(R_SO_HEADER.ACCOUNT_ID, --账户ID
                                            REC.ITEM_CODE, --产品编码
                                            TO_CHAR(V_CURR_DATE,
                                                   'yyyymmdd'), --单据日期 update by wangc 2015-6-23
                                            --TO_CHAR(R_SO_HEADER.SO_DATE,
                                            --        'yyyymmdd'), --单据日期
                                            V_PRICE_LIST_ID, --价格列表ID
                                            R_SO_HEADER.ENTITY_ID); --业务主体ID
      EXCEPTION
        WHEN OTHERS THEN
          P_ERR_MSG := 'PKG_BD_PRICE.F_GET_PRICE 获取产品[' || REC.ITEM_CODE || ']不含税价格发生异常。单据[' ||
                       R_SO_HEADER.SO_NUM || '],账户[' || R_SO_HEADER.ACCOUNT_CODE || ',' || R_SO_HEADER.ACCOUNT_ID || '],日期[' ||
                       TO_CHAR(V_CURR_DATE,'yyyymmdd') || '],价格列表[' || V_PRICE_LIST_ID || '],主体ID[' ||
                       R_SO_HEADER.ENTITY_ID || ']';
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      END;

      IF V_PRICE IS NULL THEN
        P_ERR_MSG := P_ERR_MSG || REC.ITEM_CODE || ',';
      END IF;
      DBMS_OUTPUT.PUT_LINE('含税价格：' || REC.ITEM_PRICE || '   不含税价格：' ||
                           V_PRICE);
    END LOOP;
    IF P_ERR_MSG != NULL THEN
      P_RESULT  := -1;
      P_ERR_MSG := '销售单据头ID[' || R_SO_HEADER.SO_HEADER_ID || ']，' ||
                   P_ERR_MSG || '产品获取不到不含税价格！';
    END IF;
  EXCEPTION
    WHEN PKG_SO_PUB.V_BIZ_EXCEPTION THEN
      P_RESULT  := -28016;
      P_ERR_MSG := '销售单据[ID：' || P_SO_HEADER_ID || ']不含税价格校验出错：' || P_ERR_MSG;
    WHEN OTHERS THEN
      P_RESULT  := -28016;
      P_ERR_MSG := '销售单据[ID：' || P_SO_HEADER_ID || ']不含税价格校验出错：' || SQLERRM;
  END;
  -------------------------------------------------------------------------------
  /*
    *   创建日期：2015-02-04
    *     创建者：陈武杰
    *   功能说明：自定义单据类型
          返回值：-1错误,0非拉式,1销售,2红冲,3源单退回,4反向销售,5源单退货红冲，6拉式其他单据类型
  */
  -------------------------------------------------------------------------------
  FUNCTION F_PULL_MODE(P_SO_NUM IN VARCHAR2) RETURN NUMBER AS
    V_ENTITY_ID    NUMBER;
    R_SO_HEADER    T_SO_HEADER%ROWTYPE;
    V_PUSH_OR_PULL VARCHAR2(50);
  BEGIN
    BEGIN
      SELECT * INTO R_SO_HEADER FROM T_SO_HEADER WHERE SO_NUM = P_SO_NUM;
    EXCEPTION
      WHEN OTHERS THEN
        RETURN - 1;
    END;
    RETURN F_PULL_MODE_BY_HEADERID(R_SO_HEADER.SO_HEADER_ID);
    /*BEGIN
      PKG_BD.P_GET_PARAMETER_VALUE(PKG_SO_PUB.V_ARG_SO_AR_PUSH_OR_PULL,
                                   R_SO_HEADER.ENTITY_ID,
                                   NULL,
                                   NULL,
                                   V_PUSH_OR_PULL);
    EXCEPTION
      WHEN OTHERS THEN
        RETURN - 1;
    END;
    IF V_PUSH_OR_PULL = 'PULL' THEN
      IF R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE = PKG_SO_PUB.V_BIZ_SRC_BILL_SO THEN
        --销售单
        RETURN 1;
      ELSIF R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE =
            PKG_SO_PUB.V_BIZ_SRC_BILL_SO_RED THEN
        --红冲单
        RETURN 2;
      ELSIF R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE =
            PKG_SO_PUB.V_BIZ_SRC_BILL_RETURN THEN
        --退货单
        --RETURN_MODE 退货方式：1-推式，2-拉式源单退回，3-拉式反向销售
        IF NVL(R_SO_HEADER.RETURN_MODE, '1') = '2' THEN
          RETURN 3;
        ELSIF NVL(R_SO_HEADER.RETURN_MODE, '1') = '3' THEN
          RETURN 4;
        ELSE
          RETURN 0;
        END IF;
      ELSE
        RETURN 5;
      END IF;
    ELSE
      RETURN 0;
    END IF;*/
  END;
  -------------------------------------------------------------------------------
  /*
    *   创建日期：2015-02-04
    *     创建者：陈武杰
    *   功能说明：自定义单据类型
        返回值：-1错误,0非拉式,1销售,2红冲,3源单退回,4反向销售,5源单退货红冲，6拉式其他单据类型

  */
  -------------------------------------------------------------------------------
  FUNCTION F_PULL_MODE_BY_HEADERID(P_SO_HEADER_ID IN NUMBER) RETURN NUMBER AS
    V_ENTITY_ID    NUMBER;
    R_SO_HEADER    T_SO_HEADER%ROWTYPE;
    V_PUSH_OR_PULL VARCHAR2(50);
    --是否推广物料标识
    V_IS_MATERIAL CHAR(1) := 'N';
  BEGIN
    BEGIN
      SELECT *
        INTO R_SO_HEADER
        FROM T_SO_HEADER
       WHERE SO_HEADER_ID = P_SO_HEADER_ID;
    EXCEPTION
      WHEN OTHERS THEN
        RETURN - 1;
    END;
    BEGIN
      V_PUSH_OR_PULL :=R_SO_HEADER.TRX_MODE;
      IF V_PUSH_OR_PULL IS NULL THEN
        PKG_BD.P_GET_PARAMETER_VALUE(PKG_SO_PUB.V_ARG_SO_AR_PUSH_OR_PULL,
                                     R_SO_HEADER.ENTITY_ID,
                                     NULL,
                                     NULL,
                                     V_PUSH_OR_PULL);
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        RETURN - 1;
    END;
    V_PUSH_OR_PULL := TRIM(V_PUSH_OR_PULL);
    IF V_PUSH_OR_PULL NOT IN ('PULL','PUSH','MIXED') THEN
       RETURN - 1;
    END IF;
    --增加推广物料判断 add by shengy 20150318
    V_IS_MATERIAL := NVL(F_SOHEADER_IS_MATERIAL(P_SO_HEADER_ID),'N');--add by chen.wj 20150318 增加NVL

    IF V_PUSH_OR_PULL = 'PULL'
      AND V_IS_MATERIAL <> PKG_SO_PUB.V_YES THEN --增加推广物料判断 add by shengy 20150318
      IF R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE = PKG_SO_PUB.V_BIZ_SRC_BILL_SO THEN
        --销售单
        --销售单
        RETURN 1;
      ELSIF R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE =
            PKG_SO_PUB.V_BIZ_SRC_BILL_SO_RED THEN
        --红冲
        --红冲单
        RETURN 2;
      ELSIF R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE =
            PKG_SO_PUB.V_BIZ_SRC_BILL_RETURN THEN
        --退货
        --退货单
        --RETURN_MODE 退货方式：1-推式，2-拉式源单退回，3-拉式反向销售
        IF NVL(R_SO_HEADER.RETURN_MODE, '1') = '2' THEN
          RETURN 3;
        ELSIF NVL(R_SO_HEADER.RETURN_MODE, '1') = '3' THEN
          RETURN 4;
        ELSE
          RETURN 0;
        END IF;
      ELSIF R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE =
            PKG_SO_PUB.V_BIZ_SRC_BILL_RETURN_RED THEN
        --源单退货红冲
        RETURN 5;
      ELSE
        RETURN 6;
      END IF;
    ELSE
      RETURN 0;
    END IF;
  END;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-08-04
  *     创建者：xiongpl
  *   功能说明：判断客户是否事业部客户，Y-是，N-否
  */
  -------------------------------------------------------------------------------
  FUNCTION F_IS_ENTITY_CUST(P_CUST_ID IN NUMBER) RETURN VARCHAR2 IS
    --是否事业部客户标识
    V_IS_ENTITY_CUST CHAR(1) := 'N';

    --客户是否在 T_SO_SUPPLIER_REQUIRE_ENTITY 表存在配置
    V_EXSIT_CNT number;

  BEGIN

    SELECT COUNT(1)
      INTO V_EXSIT_CNT
      FROM T_SO_SUPPLIER_REQUIRE_ENTITY
     WHERE REQUIREMENT_CUSTOMER_ID = P_CUST_ID;

    IF V_EXSIT_CNT > 0 THEN
      V_IS_ENTITY_CUST := 'Y';
    END IF;

    RETURN V_IS_ENTITY_CUST;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      V_IS_ENTITY_CUST := 'N';
      RETURN V_IS_ENTITY_CUST;
    WHEN OTHERS THEN
      RAISE V_BIZ_EXCEPTION;
  END;


  PROCEDURE P_推广物料 AS
  BEGIN
    NULL;
  END;
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-03-17
  *     创建者：申广延
  *   功能说明：判断仓库是否推广物料仓库，Y-是，N-否
  */
  -------------------------------------------------------------------------------
  FUNCTION F_INVENTORY_IS_MATERIAL(P_INV_ID IN VARCHAR2) RETURN VARCHAR2 IS
    --是否推广物料标识
    V_IS_MATERIAL CHAR(1) := 'N';

    --存货类型
    V_STOCK_TYPE VARCHAR2(500);

  BEGIN

    SELECT STOCK_TYPE
      INTO V_STOCK_TYPE
      FROM T_INV_INVENTORIES
     WHERE INVENTORY_ID = P_INV_ID;

    IF V_STOCK_TYPE = '11' THEN
      V_IS_MATERIAL := 'Y';
    END IF;

    RETURN V_IS_MATERIAL;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      V_IS_MATERIAL := 'N';
      RETURN V_IS_MATERIAL;
    WHEN OTHERS THEN
      RAISE V_BIZ_EXCEPTION;
  END;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-03-17
  *     创建者：申广延
  *   功能说明：判断仓库是否推广物料仓库，Y-是，N-否
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_INVENTORY_IS_MATERIAL(P_INV_ID IN VARCHAR2, --仓库ID
                          P_IS_MATERIAL    OUT VARCHAR2, --是否推广物料标识：Y-是，N-否
                          P_RESULT    OUT NUMBER, --返回错误ID
                          P_ERR_MSG   OUT VARCHAR2 --返回错误信息
                          ) IS
  BEGIN
    P_RESULT  := V_RESULT;
    P_ERR_MSG := V_SUCCESS;

    P_IS_MATERIAL := F_INVENTORY_IS_MATERIAL(P_INV_ID);
  EXCEPTION
    WHEN V_BIZ_EXCEPTION THEN
      P_RESULT  := -28913;
      P_ERR_MSG := '判断仓库是否推广物料仓库发生错误。';
    WHEN OTHERS THEN
      P_RESULT  := -28913;
      P_ERR_MSG := '判断仓库是否推广物料仓库发生异常：' || SQLERRM;
  END;
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-03-17
  *     创建者：申广延
  *   功能说明：判断产品是否推广物料，Y-是，N-否
  */
  -------------------------------------------------------------------------------
  FUNCTION F_ITEM_IS_MATERIAL(P_ENTITY_ID IN NUMBER, --主体ID
                         P_ITEM_CODE IN VARCHAR2) RETURN VARCHAR2 IS
    --是否推广物料标识
    V_IS_MATERIAL CHAR(1) := 'N';


  BEGIN

    SELECT NVL(IS_MATERIAL,'N')
      INTO V_IS_MATERIAL
      FROM T_BD_ITEM
     WHERE ITEM_CODE = P_ITEM_CODE
       AND ENTITY_ID = P_ENTITY_ID;

    RETURN V_IS_MATERIAL;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      V_IS_MATERIAL := 'N';
      RETURN V_IS_MATERIAL;
    WHEN OTHERS THEN
      RAISE V_BIZ_EXCEPTION;
  END;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-03-17
  *     创建者：申广延
  *   功能说明：判断产品是否推广物料，Y-是，N-否
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_ITEM_IS_MATERIAL(P_ENTITY_ID IN NUMBER, --主体ID
                          P_ITEM_CODE IN VARCHAR2, --产品编码
                          P_IS_MATERIAL    OUT VARCHAR2, --是否推广物料标识：Y-是，N-否
                          P_RESULT    OUT NUMBER, --返回错误ID
                          P_ERR_MSG   OUT VARCHAR2 --返回错误信息
                          ) IS
  BEGIN
    P_RESULT  := V_RESULT;
    P_ERR_MSG := V_SUCCESS;

    P_IS_MATERIAL := F_ITEM_IS_MATERIAL(P_ENTITY_ID, P_ITEM_CODE);
  EXCEPTION
    WHEN V_BIZ_EXCEPTION THEN
      P_RESULT  := -28914;
      P_ERR_MSG := '判断产品是否推广物料发生错误。';
    WHEN OTHERS THEN
      P_RESULT  := -28914;
      P_ERR_MSG := '判断产品是否推广物料发生异常：' || SQLERRM;
  END;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-03-17
  *     创建者：申广延
  *   功能说明：判断销售单是否推广物料，Y-是，N-否
  */
  -------------------------------------------------------------------------------
  FUNCTION F_SOHEADER_IS_MATERIAL(P_SO_HEADER_ID IN NUMBER) RETURN VARCHAR2 IS
    --是否推广物料标识
    V_IS_MATERIAL CHAR(1) := 'N';

  BEGIN

    SELECT NVL(IS_MATERIAL,'N')
      INTO V_IS_MATERIAL
      FROM T_SO_HEADER
     WHERE SO_HEADER_ID = P_SO_HEADER_ID;

    IF V_IS_MATERIAL <> 'Y' THEN
      V_IS_MATERIAL := 'N';
    END IF;

    RETURN V_IS_MATERIAL;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      V_IS_MATERIAL := 'N';
      RETURN V_IS_MATERIAL;
    WHEN OTHERS THEN
      RAISE V_BIZ_EXCEPTION;
  END;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-03-17
  *     创建者：申广延
  *   功能说明：判断销售单是否推广物料，Y-是，N-否
  */
  -------------------------------------------------------------------------------
  FUNCTION F_INTFHEADER_IS_MATERIAL(P_SO_HEADER_INTERFACE_ID IN NUMBER) RETURN VARCHAR2 IS
    --是否推广物料标识
    V_IS_MATERIAL CHAR(1) := 'N';

    --用于推广物料
    V_MATERIAL_COUNT NUMBER := 0;
  BEGIN

    SELECT count(*)
    INTO V_MATERIAL_COUNT
    FROM T_SO_LINE_INTERFACE a,T_BD_ITEM b
    WHERE a.ENTITY_ID = b.ENTITY_ID
    AND a.ITEM_CODE = b.ITEM_CODE
    AND b.IS_MATERIAL = 'Y'
    AND a.SO_HEADER_INTERFACE_ID = P_SO_HEADER_INTERFACE_ID;

    IF V_MATERIAL_COUNT > 0 THEN
      V_IS_MATERIAL := 'Y';
    END IF;

    RETURN V_IS_MATERIAL;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      V_IS_MATERIAL := 'N';
      RETURN V_IS_MATERIAL;
    WHEN OTHERS THEN
      RAISE V_BIZ_EXCEPTION;
  END;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-03-17
  *     创建者：申广延
  *   功能说明：判断销售单明细推广物料标志是否一致，Y-是，N-否
  */
  -------------------------------------------------------------------------------
  FUNCTION F_INTFHEADER_CHECK_MATERIAL(P_SO_HEADER_INTERFACE_ID IN NUMBER) RETURN VARCHAR2 IS
    --推广物料标志是否一致
    V_IS_SAME CHAR(1) := 'N';

    V_COUNT NUMBER := 0;
    --用于推广物料
    V_MATERIAL_COUNT NUMBER := 0;
  BEGIN
    SELECT count(*)
    INTO V_COUNT
    FROM T_SO_LINE_INTERFACE a,T_BD_ITEM b
    WHERE a.ENTITY_ID = b.ENTITY_ID
    AND a.ITEM_CODE = b.ITEM_CODE
    AND a.SO_HEADER_INTERFACE_ID = P_SO_HEADER_INTERFACE_ID;

    SELECT count(*)
    INTO V_MATERIAL_COUNT
    FROM T_SO_LINE_INTERFACE a,T_BD_ITEM b
    WHERE a.ENTITY_ID = b.ENTITY_ID
    AND a.ITEM_CODE = b.ITEM_CODE
    AND b.IS_MATERIAL = 'Y'
    AND a.SO_HEADER_INTERFACE_ID = P_SO_HEADER_INTERFACE_ID;

    IF (V_COUNT = V_MATERIAL_COUNT)
      OR (V_MATERIAL_COUNT = 0) THEN
      V_IS_SAME := 'Y';
    END IF;

    RETURN V_IS_SAME;
  EXCEPTION
    WHEN OTHERS THEN
      RAISE V_BIZ_EXCEPTION;
  END;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-09-17
  *     创建者：周建刚
  *   功能说明：设置财务单据营销方式【TRX_MODE】
  *             根据主体、主体参数【SO_AR_PUSH_OR_PULL】、库存组织编码规则，
  *             设置单据的营销方式（推式:TRX_MODE=PUSH、拉式:TRX_MODE=PULL）。
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_SET_TRX_MODE(P_SO_HEADER IN OUT T_SO_HEADER%ROWTYPE, --销售单据头记录
                              P_RESULT    IN OUT NUMBER,              --返回错误ID
                              P_ERR_MSG   IN OUT VARCHAR2             --返回错误信息
                               ) IS
     V_INV_ID            T_SO_HEADER.SHIP_INV_ID%TYPE;              --仓库ID
     V_ORGANIZATION_CODE T_INV_ORGANIZATION.ORGANIZATION_CODE%TYPE; --库存组织编码
     V_PUSH_OR_PULL      T_SO_HEADER.TRX_MODE%TYPE; --营销方式主体参数【SO_AR_PUSH_OR_PULL】参数值
  BEGIN
    P_RESULT  := V_RESULT;
    P_ERR_MSG := V_SUCCESS;
    --获取影响方式主体参数【SO_AR_PUSH_OR_PULL】
    BEGIN
      PKG_BD.P_GET_PARAMETER_VALUE(PKG_SO_PUB.V_ARG_SO_AR_PUSH_OR_PULL,
                                   P_SO_HEADER.ENTITY_ID,
                                   NULL,
                                   NULL,
                                   V_PUSH_OR_PULL);
    EXCEPTION
      WHEN OTHERS THEN
        P_ERR_MSG := 'SO_AR_PUSH_OR_PULL主体参数,主体id:' ||
                     P_SO_HEADER.ENTITY_ID || '的参数设置异常，请检查。' ||
                     SQLERRM;
        RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
    END;

    /**
    推式（PUSH）：直接设置该财务单据的营销方式为推式（PUSH）
    拉式（PULL）：直接设置该财务单据的营销方式为拉式（PULL）
    推拉结合（MIXED）：有库存组织编码来决定该财务单据的营销方式（推式或拉式）,
                       库存组织首字母编码为S则为推式；否则为拉式。
    */
    IF (V_PUSH_OR_PULL = V_TRADE_MODE_PUSH) THEN
      P_SO_HEADER.TRX_MODE := V_TRADE_MODE_PUSH;
    ELSIF (V_PUSH_OR_PULL = V_TRADE_MODE_PULL) THEN
      P_SO_HEADER.TRX_MODE := V_TRADE_MODE_PULL;
    ELSIF (V_PUSH_OR_PULL = V_TRADE_MODE_MIXED) THEN
      --销售单、销售红冲：取发货仓库编码 SHIP_INV_CODE
      --退货单、退货红冲：单取收货仓库编码 CONSIGNEE_INV_CODE
      IF (P_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE = V_BIZ_SRC_BILL_SO OR P_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE = V_BIZ_SRC_BILL_SO_RED) THEN
        V_INV_ID := P_SO_HEADER.SHIP_INV_ID;
      ELSIF (P_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE = V_BIZ_SRC_BILL_RETURN OR P_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE = V_BIZ_SRC_BILL_RETURN_RED) THEN
        V_INV_ID := P_SO_HEADER.CONSIGNEE_INV_ID;
      END IF;

      --获取库存组织编码
      BEGIN
        SELECT INV_ORG.ORGANIZATION_CODE   --库存组织编码
          INTO V_ORGANIZATION_CODE
          FROM T_INV_INVENTORIES INV,T_INV_ORGANIZATION INV_ORG
         WHERE INV.ORGANIZATION_ID = INV_ORG.ORGANIZATION_ID
           AND INV.ORGANIZATION_CODE = INV_ORG.ORGANIZATION_CODE
           AND INV.ENTITY_ID = INV_ORG.ENTITY_ID
           AND INV.ENTITY_ID = P_SO_HEADER.ENTITY_ID
           AND INV.INVENTORY_ID = V_INV_ID
           AND ROWNUM = 1;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          P_ERR_MSG := '仓库[ID=' || V_INV_ID || ']未设置对应的库存组织！';
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
        WHEN OTHERS THEN
          P_ERR_MSG := '获取仓库[ID=' || V_INV_ID || ']对应的库存组织信息发生异常：' || SQLERRM;
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      END;

      --库存组织首字母编码为S则为推式；否则为拉式。
      IF (SUBSTR(V_ORGANIZATION_CODE,0,1) = 'S') THEN
        -- 推式模式下客户OU、仓库OU 相同
        P_SO_HEADER.TRX_MODE := V_TRADE_MODE_PUSH;
      ELSE
        P_SO_HEADER.TRX_MODE := V_TRADE_MODE_PULL;
      END IF;
    END IF;

  EXCEPTION
    WHEN PKG_SO_PUB.V_BIZ_EXCEPTION THEN
      P_RESULT  := -28009;
      P_ERR_MSG := '获取财务单据营销方式出错。[主体ID：' || P_SO_HEADER.ENTITY_ID ||
                   '，主体参数SO_AR_PUSH_OR_PULL营销方式：' || V_PUSH_OR_PULL ||
                   '，仓库ID：' || V_INV_ID || ']原因：' || P_ERR_MSG;
    WHEN OTHERS THEN
      P_RESULT  := -28009;
      P_ERR_MSG := '获取财务单据营销方式出错。[ID：' || P_SO_HEADER.SO_HEADER_ID ||
                   ']生成销售单据发生异常，原因：' || SQLERRM;
  END;
      
  
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2016-06-12
  *     创建者：周建刚
  *   功能说明：根据主体ID、客户ID、账户ID、营销大类编码，获取客户到款余额
  *   计算公式  到款余额 = 到款金额 - 销售金额
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_GET_RECEIVED_AMOUNT_LEFT(P_ENTITY_ID       IN  NUMBER,    --主体ID
                                       P_CUSTOMER_ID     IN  NUMBER,    --客户ID
                                       P_CUSTOMER_CODE   IN  VARCHAR2,  --客户编码
                                       P_ACCOUNT_ID      IN  NUMBER,    --账户ID
                                       P_ACCOUNT_CODE    IN  VARCHAR2,   --账户编码
                                       P_SALES_MAIN_TYPE IN  VARCHAR2,  --营销大类编码
                                       P_AMOUNT_LEFT     OUT NUMBER,    --到款余额
                                       P_RESULT          OUT NUMBER,    --返回错误ID
                                       P_ERR_MSG         OUT VARCHAR2   --返回错误信息
                               ) IS
    V_GREDIT_GROUP_ID        NUMBER;
    CUR_SALES_ACCOUNT_AMOUNT T_SALES_ACCOUNT_AMOUNT%ROWTYPE;
  BEGIN
    P_RESULT  := V_RESULT;
    P_ERR_MSG := V_SUCCESS;
    P_AMOUNT_LEFT := 0;
    
    V_GREDIT_GROUP_ID := FUN_GET_CREDITGROUPID(P_ENTITY_ID,
                                               P_CUSTOMER_ID,
                                               P_SALES_MAIN_TYPE,
                                               P_ACCOUNT_ID);
    
    SELECT T.*
      INTO CUR_SALES_ACCOUNT_AMOUNT
      FROM T_SALES_ACCOUNT_AMOUNT T
     WHERE T.ENTITY_ID = P_ENTITY_ID
       AND T.CUSTOMER_ID = P_CUSTOMER_ID
       AND T.ACCOUNT_ID = P_ACCOUNT_ID
       AND T.CREDIT_GROUP_ID = V_GREDIT_GROUP_ID;
    
    --发货确认自动开单计算公式  可用到款余额 = 到款金额 - 销售金额
    P_AMOUNT_LEFT := CUR_SALES_ACCOUNT_AMOUNT.RECEIVED_AMOUNT -
                     CUR_SALES_ACCOUNT_AMOUNT.SALES_AMOUNT;
    
  EXCEPTION
    WHEN PKG_SO_PUB.V_BIZ_EXCEPTION THEN
      P_AMOUNT_LEFT := 0;
      P_RESULT  := -28009;
      P_ERR_MSG := '开单记录使用的铺底额度，获取客户到款余额出错。主体[' || P_ENTITY_ID || 
                   ']，客户[' || P_CUSTOMER_ID || ',' || P_CUSTOMER_CODE || ']，账户[' || P_ACCOUNT_ID || ',' || P_ACCOUNT_CODE || ']';
    WHEN OTHERS THEN
      P_RESULT  := -28009;
      P_ERR_MSG := '开单记录使用的铺底额度，获取客户到款余额出错。主体[' || P_ENTITY_ID || 
                   ']，客户[' || P_CUSTOMER_ID || ',' || P_CUSTOMER_CODE || ']，账户[' || P_ACCOUNT_ID || ',' || P_ACCOUNT_CODE || ']原因：' || SQLERRM;
  END;
             
  -------------------------------------------------------------------------------
  /*
  * 创建日期：2016-06-13
  * 创建者：周建刚  zhoujg3
  * 功能说明：销售单/销售红冲单记录使用的铺底额度
	* 单据保存时记录使用的铺底额度 
	* 1、	销售单制单（包括系统自动开单、人工制单）时获取客户到款余额；
	* 2、	计算铺底使用额度情形一：如果客户到款余额 < 0 ,则 DEPLAY_AMOUNT = 销售单结算金额（SETTLE_AMOUNT）;
	* 3、	计算铺底使用额度情形二：如果客户到款余额 - 销售单结算金额 > 0 ，则 DEPLAY_AMOUNT = 0；
	* 4、	计算铺底使用额度情形三：如果客户到款余额 - 销售单结算金额 < 0，则DEPLAY_AMOUNT = 绝对值(客户到款余额 - 销售单结算金额)。
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_UPDATE_SO_DELAYPAY_AMOUNT(P_SO_HEADER_ID IN T_SO_HEADER.SO_HEADER_ID%TYPE, --销售单据头记录
                                        P_RESULT    IN OUT NUMBER,              --返回错误ID
                                        P_ERR_MSG   IN OUT VARCHAR2             --返回错误信息
                               ) IS
    V_AMOUNT_LEFT            NUMBER := 0;
    V_BLUE_DELAYPAY_AMOUNT   NUMBER := 0; --蓝单使用的铺底额度
    V_RED_DELAYPAY_AMOUNT    NUMBER := 0; --已经开出的红冲单使用的铺底额度
    V_SETTLE_AMOUNT          NUMBER := 0;
    V_DELAYPAY_AMOUNT        NUMBER := 0; --记录使用的铺底额度
    CURSOR C_B_SO_HEADER IS
      SELECT *
        FROM T_SO_HEADER
       WHERE SO_HEADER_ID = P_SO_HEADER_ID;
    R_B_SO_HEADER C_B_SO_HEADER%ROWTYPE;
    CURSOR C_SO_HEADER IS
      SELECT *
        FROM T_SO_HEADER
       WHERE ORIG_SO_NUM = R_B_SO_HEADER.ORIG_SO_NUM
       AND SO_HEADER_ID != R_B_SO_HEADER.SO_HEADER_ID;
    R_SO_HEADER C_SO_HEADER%ROWTYPE;
  BEGIN
    P_RESULT  := V_RESULT;
    P_ERR_MSG := V_SUCCESS;
    
    OPEN C_B_SO_HEADER;
    FETCH C_B_SO_HEADER
      INTO R_B_SO_HEADER;
    CLOSE C_B_SO_HEADER;
     
    P_GET_RECEIVED_AMOUNT_LEFT(R_B_SO_HEADER.ENTITY_ID,R_B_SO_HEADER.CUSTOMER_ID,R_B_SO_HEADER.CUSTOMER_CODE,
    R_B_SO_HEADER.ACCOUNT_ID,R_B_SO_HEADER.ACCOUNT_CODE,R_B_SO_HEADER.SALES_MAIN_TYPE,V_AMOUNT_LEFT,P_RESULT,P_ERR_MSG);
  
    IF (P_RESULT != V_RESULT) THEN
        P_RESULT  := -58001;
        PKG_SO_PUB.P_EXCEPTION_THROWS(P_RESULT);
    END IF;
    
    --计算销售单据结算总金额
    SELECT ROUND(SUM(NVL(ITEM_SETTLE_AMOUNT, 0)),2) AS SETTLE_AMOUNT
      INTO R_B_SO_HEADER.SETTLE_AMOUNT
      FROM T_SO_LINE
     WHERE SO_HEADER_ID = R_B_SO_HEADER.SO_HEADER_ID;
    
    V_SETTLE_AMOUNT := R_B_SO_HEADER.SETTLE_AMOUNT;

    --销售单根据到款余额（到款 - 销售）、单据结算金额计算出使用铺底额度
    IF (R_B_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE = PKG_SO_PUB.V_BIZ_SRC_BILL_SO) THEN
      IF (V_AMOUNT_LEFT <= 0) THEN
        --计算铺底使用额度情形一：如果客户到款余额 <= 0 ,则 DEPLAY_AMOUNT = 销售单结算金额(SETTLE_AMOUNT);
        V_DELAYPAY_AMOUNT := V_SETTLE_AMOUNT;
      ELSIF (V_AMOUNT_LEFT - V_SETTLE_AMOUNT >= 0) THEN
        --计算铺底使用额度情形二：如果客户到款余额 - 销售单结算金额 >= 0 ，则 DEPLAY_AMOUNT = 0；
        V_DELAYPAY_AMOUNT := 0;
      ELSIF (V_AMOUNT_LEFT - V_SETTLE_AMOUNT < 0) THEN
        --计算铺底使用额度情形三：如果客户到款余额 - 销售单结算金额 < 0，则DEPLAY_AMOUNT = 绝对值(客户到款余额 - 销售单结算金额)
        V_DELAYPAY_AMOUNT := ABS(V_AMOUNT_LEFT - V_SETTLE_AMOUNT);
      END IF;
    ELSIF (R_B_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE = PKG_SO_PUB.V_BIZ_SRC_BILL_SO_RED) THEN
      --销售红冲单的铺底使用额度 = 对应销售单的普度使用额度 * 销售红冲单的结算金额/对应销售单的结算金额。
      SELECT NVL(BLUE_SO.DELAYPAY_AMOUNT,0)
        INTO V_BLUE_DELAYPAY_AMOUNT
        FROM T_SO_HEADER BLUE_SO
       WHERE BLUE_SO.SO_NUM = R_B_SO_HEADER.ORIG_SO_NUM;
      
      --打开销售红冲单记录游标
      OPEN C_SO_HEADER;
        LOOP
          FETCH C_SO_HEADER
            INTO R_SO_HEADER;
          EXIT WHEN C_SO_HEADER%NOTFOUND;
          
          IF (R_SO_HEADER.SO_HEADER_ID IS NOT NULL
             AND R_B_SO_HEADER.SO_HEADER_ID IS NOT NULL
             AND R_SO_HEADER.SO_HEADER_ID != R_B_SO_HEADER.SO_HEADER_ID) THEN
              V_RED_DELAYPAY_AMOUNT := V_RED_DELAYPAY_AMOUNT + NVL(R_SO_HEADER.DELAYPAY_AMOUNT,0);
          END IF;
      END LOOP;
      CLOSE C_SO_HEADER;
      --关闭销售红冲单记录游标
      
      V_DELAYPAY_AMOUNT := V_BLUE_DELAYPAY_AMOUNT - V_RED_DELAYPAY_AMOUNT;
      IF (V_DELAYPAY_AMOUNT - NVL(R_B_SO_HEADER.SETTLE_AMOUNT,0) >= 0) THEN
        V_DELAYPAY_AMOUNT := R_B_SO_HEADER.SETTLE_AMOUNT;
      END IF;
      
    END IF;
    
    --更新单据使用的铺底额度
    UPDATE T_SO_HEADER SO SET SO.DELAYPAY_AMOUNT = V_DELAYPAY_AMOUNT WHERE SO.SO_HEADER_ID = R_B_SO_HEADER.SO_HEADER_ID;
    
  EXCEPTION
    WHEN PKG_SO_PUB.V_BIZ_EXCEPTION THEN
      P_RESULT  := -28009;
    WHEN OTHERS THEN
      P_RESULT  := -28009;
      P_ERR_MSG := '开单记录使用的铺底额度，获取客户到款余额出错。主体[' || R_B_SO_HEADER.ENTITY_ID || 
                   ']，客户[' || R_B_SO_HEADER.CUSTOMER_ID || ',' || R_B_SO_HEADER.CUSTOMER_CODE || ']，账户[' || R_B_SO_HEADER.ACCOUNT_ID || ',' || R_B_SO_HEADER.ACCOUNT_CODE || ']原因：' || SQLERRM;
  END;
             
  -------------------------------------------------------------------------------
  /*
  * 创建日期：2018-04-10
  * 创建者：周建刚  zhoujg3
  * 功能说明：销售开单记录税率、税码
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_GET_TAX_RATE(P_ENTITY_ID           IN NUMBER,
                           P_SALES_CENTER_ID     IN NUMBER,
                           P_CUSTOMER_ID         IN NUMBER,
                           P_ERP_OU_ID           IN NUMBER,
                           P_TAX_RATE            OUT NUMBER,
                           P_TAX_CODE            OUT VARCHAR2,
                           P_RESULT              IN OUT NUMBER,   --返回错误ID
                           P_ERR_MSG             IN OUT VARCHAR2  --返回错误信息
                          ) IS
    
  BEGIN
    P_RESULT  := V_RESULT;
    P_ERR_MSG := V_SUCCESS;
    
    BEGIN
      SELECT TRX_RATE
        INTO P_TAX_RATE
        FROM TABLE(PKG_AR_INVOICE.F_GET_AR_CONFIG(P_ENTITY_ID,
                                                  P_SALES_CENTER_ID,
                                                  P_CUSTOMER_ID,
                                                  P_ERP_OU_ID));
      IF P_TAX_RATE IS NULL THEN
        P_ERR_MSG := 'T_AR_CONF表查询不到税率，请维护！实体ID[' || P_ENTITY_ID ||
                     ']，营销中心ID[' || P_SALES_CENTER_ID ||
                     ']，客户ID[' || P_CUSTOMER_ID || ']，OU_ID[' || P_ERP_OU_ID || ']';
        RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      END IF;

    END;

    BEGIN
      SELECT CODE_NAME
        INTO P_TAX_CODE
        FROM UP_CODELIST
       WHERE CODETYPE = 'SO_TAX_RATE_CODE'
         AND CODE_VALUE = TO_CHAR(P_TAX_RATE);
    EXCEPTION
      WHEN OTHERS THEN
        P_ERR_MSG := 'UP_CODELIST表查询不到税码，请维护！代码类型[SO_TAX_RATE_CODE]，代码值[' ||
                     P_TAX_RATE || ']';
        RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
    END;

  EXCEPTION
    WHEN PKG_SO_PUB.V_BIZ_EXCEPTION THEN
      P_RESULT  := -28018;
    WHEN OTHERS THEN
      P_RESULT  := -28009;
      P_ERR_MSG := '开单记录税率、稅码出现异常！主体[' || P_ENTITY_ID || 
                   ']，营销中心[' || P_SALES_CENTER_ID || '],客户[' || P_CUSTOMER_ID || ']，OU[' || P_ERP_OU_ID || ']' || ']原因：' || SQLERRM;
  END;  
  -------------------------------------------------------------------------------
  
END PKG_SO_PUB;
/

