create package body PKG_CREDIT_SETTING is

  --------------------------------------------------------------------------------
  /*
  *   创建日期：2016-08-18
  *     创建者：梁颜明
  *   功能说明：
  *   返回结果：1：成功，2：失败
  *
  */
  -------------------------------------------------------------------------------  /**

  V_NL CONSTANT VARCHAR2(2) := CHR(13) || CHR(10); --换行
  /**
  * 信用额度初始化
  **/
  PROCEDURE P_CREDIT_AMOUNT_INIT(I_ENTITY_ID     IN NUMBER, --实体ID
                                 I_CHANGE_REASON IN VARCHAR2, --1:信用额度调整申请2:客户组变更3:信用额度初始化
                                 I_USER_ID       IN VARCHAR2, --操作人
                                 I_FLAG          IN VARCHAR2, -- 0 月初始化
                                 O_MSG           OUT VARCHAR2 --返回信息
                                 ) IS
  BEGIN
    FOR V_CREDIT_TS IN (SELECT *
                          FROM V_CREDIT_TERMS
                         WHERE ENTITY_ID = I_ENTITY_ID) LOOP
    
      BEGIN
        P_CREDIT_AMOUNT_INIT(V_CREDIT_TS,
                             I_CHANGE_REASON,
                             I_USER_ID,
                             I_FLAG,
                             1,
                             O_MSG);
        IF O_MSG <> V_SUCCESS_MSG THEN
          ROLLBACK;
          SELECT PKG_BD.F_ADD_ERROR_LOG('信用额度初始化失败',
                                        '23333',
                                        O_MSG)
            INTO O_MSG
            FROM DUAL;
        END IF;
      EXCEPTION
        WHEN OTHERS THEN
          ROLLBACK;
          O_MSG := '信用额度初始化异常，主体：' || V_CREDIT_TS.ENTITY_ID || '，客户ID：' ||
                   V_CREDIT_TS.CUSTOMER_ID || '，营销大类编码：' ||
                   V_CREDIT_TS.SALES_MAIN_TYPE_CODE;
        
          SELECT PKG_BD.F_ADD_ERROR_LOG('信用额度初始化异常',
                                        '23333',
                                        O_MSG)
            INTO O_MSG
            FROM DUAL;
      END;
    END LOOP;
  
  END P_CREDIT_AMOUNT_INIT;

  /**
  *信用额度计算规则
  *以后考虑加这几个参数：I_CHANGE_REASON I_USER_ID I_FLAG I_COMMIT
  **/
  PROCEDURE P_CREDIT_AMOUNT_DESC(I_ENTITY_ID                    IN NUMBER, --实体ID
                                 I_CUSTOMER_ID                  IN NUMBER, --客户ID
                                 IN_ACCOUNT_ID                  IN NUMBER, --账户ID
                                 I_SALES_MAIN_TYPE_CODE         IN VARCHAR2, --营销大类编码
                                 O_MSG                          OUT VARCHAR2, --返回信息
                                 OS_CUSTOMER_ACTIVE_DATE        OUT VARCHAR2,--客户事业部合作生效日期
                                 ON_COOPERATE_DAYS              OUT NUMBER,--客户事业部合作天数
                                 OS_CREDIT_LEVEL_MSG            OUT VARCHAR2,--信用等级说明
                                 ON_TWELVE_AMOUNT               OUT NUMBER,--前十二个月销售收入
                                 ON_CREDIT_CALC_PERCENT         OUT NUMBER,--信用等级额度计算比例
                                 OS_CUS_CREDIT_LINE_MSG         OUT VARCHAR2,--信用等级额度计算说明
                                 ON_LAST_YEAR_PROPORTION        OUT NUMBER,--上年月均销售铺底比例
                                 ON_THIS_YEAR_PROPORTION        OUT NUMBER,--本年月均销售铺底比例
                                 OS_THIS_YEAR_PROP_MSG          OUT VARCHAR2,--本年月均销售铺底比例特殊情况说明
                                 ON_LAST_YEAR_CUST_AMOUNT       OUT NUMBER,--上年度销售收入
                                 ON_THIS_YEAR_MONTH_CUST_AMOUNT OUT NUMBER,--本年度销售收入
                                 OS_LAST_YEAR_CREDIT_LINE_MSG   OUT VARCHAR2,--上年度信用额度说明
                                 OS_THIS_YEAR_CREDIT_LINE_MSG   OUT VARCHAR2,--本年度信用额度说明
                                 ON_LAST_YEAR_CUST_AMOUNT_AVG   OUT NUMBER, --客户上一年度月均提货金额
                                 ON_THIS_YEAR_MM_AMOUNT_AVG     OUT NUMBER, --本年月月均销售金额
                                 ON_THIS_MONTH_DELAY_AMOUNT_AVG OUT NUMBER, --本年月均铺底
                                 --OS_TWELVE_AMOUNT_MSG           OUT VARCHAR2,--前十二个月
                                 OS_CAN_USE_AMOUNT_MSG          OUT VARCHAR2--可用额度说明
                                 ) IS
    V_CREDIT_TS                 V_CREDIT_TERMS%ROWTYPE; --客户信用额度记录
    V_ENTITY_ID                 NUMBER;
    V_CUSTOMER_ID               NUMBER;
    V_SALES_MAIN_TYPE_CODE      V_CREDIT_TERMS.SALES_MAIN_TYPE_CODE%TYPE;
    V_OLD_CREDIT_LINE           V_CREDIT_TERMS.CREDIT_LINE%TYPE;
    V_OLD_CUSTOMER_CREDIT_LEVEL V_CREDIT_TERMS.CUSTOM_LEVEL%TYPE;
    V_CUSTOMER_CREDIT_LEVEL     V_CREDIT_TERMS.CUSTOM_LEVEL%TYPE;
    V_ENTITY_GROUP_CODE         T_BD_PARAM_LIST.DEFAULT_VALUE%TYPE;
    V_CUST_SALES_MAIN_TYPE      T_CUSTOMER_SALES_MAIN_TYPE%ROWTYPE;
    V_THIS_MONTH_FIRST          DATE;
    V_NOW_TIMESTAMP             DATE;
    V_CUS_CREDIT_LINE           NUMBER; --
    V_THIS_YEAR_BEGIN_DATE      DATE; --获取本年的第一天
    V_LAST_YEAR_BEGIN_DATE      DATE; --上一年最初一天
    V_LAST_YEAR_END_DATE        DATE; --上一年最后一天

    V_LAST_YEAR_CREDIT_LINE NUMBER; --上年度信用额度
    V_THIS_YEAR_CREDIT_LINE NUMBER; --本年度信用额度
    V_CURRENT_MONTH         NUMBER;
    V_COUNT                 NUMBER;

    V_IF_CONTROL_BY_TYPE         VARCHAR2(24); --是否按品类控制
    V_COOPER_DATE                T_CREDIT_RATING_CUSTOMER.COORERATION_DATE%TYPE := 0; --合作年限
    V_TWELVE_AMOUNT              T_CREDIT_RATING_CUSTOMER.LAST_TWELVE_AMOUNT%TYPE := 0; --前12个月销售金额
    V_COOPER_DATE_MARKET_MODE    T_CREDIT_RATING_CUSTOMER.MIDEA_MARKET_MODE%TYPE;
    V_TWELVE_AMOUNT_MARKET_MODE  T_CREDIT_RATING_CUSTOMER.MIDEA_MARKET_MODE%TYPE;
    V_LAST_YEAR_PROP_MARKET_MODE T_CREDIT_RATING_CUSTOMER.MIDEA_MARKET_MODE%TYPE;
    V_THIS_YEAR_PROP_MARKET_MODE T_CREDIT_RATING_CUSTOMER.MIDEA_MARKET_MODE%TYPE;
    V_THIS_YEAR_PROPORTION       NUMBER;
    V_TWELVE_AMOUNT_UNION        NUMBER := 0;

    V_ADJ_AMOUNT        NUMBER := 0;
    V_USE_DELAY         NUMBER := 0;
    V_THREEDELAY_AMOUNT NUMBER := 0;

    R_SALES_MAIN_TYPE  VARCHAR2(24);
    V_LAST_YEAR_AMOUNT NUMBER := 0;
    V_THIS_YEAR_AMOUNT NUMBER := 0;
    V_CREDIT_AMOUNT    NUMBER := 0;
    
    V_CUSTOMER_ACTIVE_DATE DATE;
    V_ACCOUNT_ID                   NUMBER;

    CURSOR C_SALES_MAIN_TYPE IS
      SELECT T.SALES_MAIN_TYPE_CODE
        FROM T_CREDIT_CUSTOMER T
       WHERE T.CUSTOMER_ID = I_CUSTOMER_ID
         AND T.ENTITY_ID = I_ENTITY_ID
            --2017 04 25 梁颜明 增加账户ID
         AND (((IN_ACCOUNT_ID IS NULL OR 0 >= IN_ACCOUNT_ID) AND
             (T.ACCOUNT_ID IS NULL OR 0 >= T.ACCOUNT_ID)) OR
             (0 < IN_ACCOUNT_ID AND T.ACCOUNT_ID = IN_ACCOUNT_ID));
  BEGIN
    BEGIN
      SELECT *
        INTO V_CREDIT_TS
        FROM V_CREDIT_TERMS T
       WHERE ENTITY_ID = I_ENTITY_ID
         AND CUSTOMER_ID = I_CUSTOMER_ID
         AND SALES_MAIN_TYPE_CODE = I_SALES_MAIN_TYPE_CODE
            --2017 5 2 梁颜明 增加账户ID
         AND (((IN_ACCOUNT_ID IS NULL OR 0 >= IN_ACCOUNT_ID) -- AND (T.ACCOUNT_ID IS NULL OR 0 >= T.ACCOUNT_ID)
             ) OR (0 < IN_ACCOUNT_ID AND T.ACCOUNT_ID = IN_ACCOUNT_ID));
    
    EXCEPTION
      WHEN OTHERS THEN
        O_MSG := '根据主体ID，客户ID，营销大类获取CreditTerms出错！！主体：' || I_ENTITY_ID ||
                 '，客户ID：' || I_CUSTOMER_ID || '，营销大类编码：' ||
                 I_SALES_MAIN_TYPE_CODE || SUBSTR(SQLERRM, 1, 200);
        RETURN;
    END;
    IF V_CREDIT_TS.CUSTOMER_ID IS NOT NULL THEN
      V_OLD_CREDIT_LINE           := V_CREDIT_TS.CREDIT_LINE;
      V_OLD_CUSTOMER_CREDIT_LEVEL := V_CREDIT_TS.CUSTOM_CREDIT_LEVEL;
    END IF;
    V_NOW_TIMESTAMP        := SYSDATE;
    V_ENTITY_ID            := V_CREDIT_TS.ENTITY_ID;
    V_CUSTOMER_ID          := V_CREDIT_TS.CUSTOMER_ID;
    V_SALES_MAIN_TYPE_CODE := V_CREDIT_TS.SALES_MAIN_TYPE_CODE;
    V_ACCOUNT_ID           := V_CREDIT_TS.ACCOUNT_ID;

    --获取主体组编码
    BEGIN
      PKG_BD.P_GET_PARAMETER_VALUE('ar_entity_group',
                                   V_ENTITY_ID,
                                   NULL,
                                   NULL,
                                   V_ENTITY_GROUP_CODE);
    EXCEPTION
      WHEN OTHERS THEN
        O_MSG := '根据主体ID,获取主体组编码出错，主体：' || V_ENTITY_ID ||
                 SUBSTR(SQLERRM, 1, 200);
        RETURN;
    END;

    --获取客户的合作期限
    V_THIS_MONTH_FIRST := TRUNC(V_NOW_TIMESTAMP, 'MM');
    BEGIN
      WITH T1 AS
       (SELECT ROWNUM AS RN,
               NVL(CUSTOMER_ACTIVE_DATE, CREATION_DATE) AS CUSTOMER_ACTIVE_DATE
          FROM T_CUSTOMER_DEPT
         WHERE DEPT_ID = V_ENTITY_ID
           AND CUSTOMER_ID = V_CUSTOMER_ID
         ORDER BY DECODE(DEPT_CUSTOMER_STATUS, 'Active', 0, 'Freezing', 1, 2),
                  DECODE(ACTIVE_FLAG, 'Active', 0, 'Freezing', 1, 2),
                  DECODE(CUSTOMER_ACTIVE_DATE,
                         NULL,
                         V_NOW_TIMESTAMP,
                         CUSTOMER_ACTIVE_DATE),
                  DECODE(CREATION_DATE, NULL, V_NOW_TIMESTAMP, CREATION_DATE))
      SELECT CUSTOMER_ACTIVE_DATE,
             V_THIS_MONTH_FIRST - TRUNC(CUSTOMER_ACTIVE_DATE)
        INTO V_CUSTOMER_ACTIVE_DATE, ON_COOPERATE_DAYS
        FROM DUAL
        LEFT JOIN T1
          ON (1 = RN);
    EXCEPTION
      WHEN OTHERS THEN
        O_MSG := '获取客户合作年限出错！！主体：' || V_ENTITY_ID || '，客户ID：' ||
                 V_CUSTOMER_ID || '，营销大类编码：' || V_SALES_MAIN_TYPE_CODE ||
                 SUBSTR(SQLERRM, 1, 200);
        RETURN;
    END;
    IF ON_COOPERATE_DAYS IS NULL THEN
      O_MSG := '无法获取客户合作年限！！主体：' || V_ENTITY_ID || '，客户ID：' || V_CUSTOMER_ID ||
               '，营销大类编码：' || V_SALES_MAIN_TYPE_CODE;
      RETURN;
    END IF;
    OS_CUSTOMER_ACTIVE_DATE := TO_CHAR(V_CUSTOMER_ACTIVE_DATE,'YYYY-MM-DD');

    --客户信用等级
    --V_CUSTOMER_CREDIT_LEVEL := '';

    OS_CREDIT_LEVEL_MSG := '';
    BEGIN
      SELECT T.*
        INTO V_CUST_SALES_MAIN_TYPE
        FROM T_CUSTOMER_SALES_MAIN_TYPE T
       WHERE ENTITY_ID = V_ENTITY_ID
         AND CUSTOM_ID = V_CUSTOMER_ID
         AND SALES_MAIN_TYPE_CODE = V_SALES_MAIN_TYPE_CODE;
      V_CUSTOMER_CREDIT_LEVEL := '1';
      IF 'XSGS' = V_ENTITY_GROUP_CODE THEN
        V_CUSTOMER_CREDIT_LEVEL := NVL(NVL(V_CUST_SALES_MAIN_TYPE.CUSTOM_LEVEL,
                                           V_CUST_SALES_MAIN_TYPE.CUSTOM_CREDIT_LEVEL),
                                       '1');
        IF V_CUST_SALES_MAIN_TYPE.CUSTOM_LEVEL IS NOT NULL THEN
          OS_CREDIT_LEVEL_MSG := OS_CREDIT_LEVEL_MSG || V_NL ||
                                 '信用等级与客户等级对应：战略经销商=S|重点经销商=A|常规经销商=B|潜在经销商=C' || V_NL ||
                                 '（客户等级在“客户管理”-“客户资料”-“客户等级维护”进行维护）';
        ELSIF V_CUST_SALES_MAIN_TYPE.CUSTOM_CREDIT_LEVEL IS NOT NULL THEN
          OS_CREDIT_LEVEL_MSG := OS_CREDIT_LEVEL_MSG || V_NL ||
                                 '客户等级为空，信用等级已维护，可以在“客户管理”-“客户资料”-“客户等级维护”进行维护';
        ELSE
          OS_CREDIT_LEVEL_MSG := OS_CREDIT_LEVEL_MSG || V_NL ||
                                 '客户等级为空信用等级也没维护，信用等级默认设置为S（可在“客户管理”-“客户资料”-“客户等级维护”进行维护）';
        END IF;
      ELSIF 'JXS' = V_ENTITY_GROUP_CODE THEN
        V_CUSTOMER_CREDIT_LEVEL := NVL(V_CUST_SALES_MAIN_TYPE.CUSTOM_LEVEL,
                                       '4');
        IF V_CUST_SALES_MAIN_TYPE.CUSTOM_LEVEL IS NULL THEN
          OS_CREDIT_LEVEL_MSG := OS_CREDIT_LEVEL_MSG || V_NL ||
                                 '客户等级为空，信用等级设置为C' || V_NL ||
                                 '（客户等级在“客户管理”-“客户资料”-“客户等级维护”进行维护）';
        ELSE
          OS_CREDIT_LEVEL_MSG := OS_CREDIT_LEVEL_MSG || V_NL ||
                                 '信用等级与客户等级对应：战略经销商=S|重点经销商=A|常规经销商=B|潜在经销商=C' || V_NL ||
                                 '（客户等级在“客户管理”-“客户资料”-“客户等级维护”进行维护）';
        END IF;
      END IF;
    
      IF 'XSGS' = V_ENTITY_GROUP_CODE THEN
        --家用额度初始化时候将客户信用等级置为最高级
        --月自动初始化
        SELECT COUNT(0)
          INTO V_COUNT
          FROM T_CREDIT_BAD_RECORD
         WHERE ENTITY_ID = V_ENTITY_ID
           AND CUSTOMER_ID = V_CUSTOMER_ID
           AND ACTIVE_FLAG = '1';
        --每个月重新计算客户信用额度
        SELECT DECODE(V_COUNT,
                      0,
                      '1', --是否有逾期：无
                      DECODE(V_CUSTOMER_CREDIT_LEVEL, '1', '2', '2', '3', '4')) --是否有逾期：有 存在是否有逾期进行相应降级处理
          INTO V_CUSTOMER_CREDIT_LEVEL
          FROM DUAL;
        IF 0 = V_COUNT THEN
          OS_CREDIT_LEVEL_MSG := OS_CREDIT_LEVEL_MSG || V_NL ||
                                 '没有不良铺底记录，每月月初信用等级会设置为最高级';
        ELSE
          OS_CREDIT_LEVEL_MSG := OS_CREDIT_LEVEL_MSG || V_NL ||
                                 '当前有不良（逾期）铺底记录，每月月初信用等级会进行相应的降级处理';
        END IF;
      ELSIF 'JXS' = V_ENTITY_GROUP_CODE THEN
        V_CUSTOMER_CREDIT_LEVEL := NVL(V_CUST_SALES_MAIN_TYPE.CUSTOM_LEVEL,
                                       '4');
        SELECT ROUND((V_NOW_TIMESTAMP - V_CUSTOMER_ACTIVE_DATE), 2) / 365
          INTO V_COUNT --合作天数/365
          FROM DUAL;
        IF 1 > V_COUNT THEN
          -- 客户合作年限小于1年的场合
          V_CUSTOMER_CREDIT_LEVEL := '4';
          OS_CREDIT_LEVEL_MSG     := OS_CREDIT_LEVEL_MSG || V_NL ||
                                     '从事业部生效时间“' ||
                                     TO_CHAR(V_CUSTOMER_ACTIVE_DATE,
                                             'YYYY-MM-DD') ||
                                     '”到现在的合作天数少于1年，信用等级设置为最低级';
        END IF;
      
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        O_MSG := '获取客户信用等级出错！！主体：' || V_ENTITY_ID || '，客户ID：' ||
                 V_CUSTOMER_ID || '，营销大类编码：' || V_SALES_MAIN_TYPE_CODE ||
                 SUBSTR(SQLERRM, 1, 200);
        RETURN;
    END;

    --取客户前12个月销售金额 ON_TWELVE_AMOUNT
    --ON_TWELVE_AMOUNT := V_CREDIT_TS.TWELVE_AMOUNT;
    BEGIN
      SELECT PKG_CREDIT_TOOLS.FUN_GET_SALES_AMOUNT_BY_DATE(V_ENTITY_ID,
                                                           V_CUSTOMER_ID,
                                                           ADD_MONTHS(V_THIS_MONTH_FIRST,
                                                                      -12),
                                                           V_THIS_MONTH_FIRST - 1,
                                                           V_SALES_MAIN_TYPE_CODE,
                                                           --2017 5 2 梁颜明 增加账户ID
                                                           V_CREDIT_TS.ACCOUNT_ID)
        INTO ON_TWELVE_AMOUNT
        FROM DUAL;
    EXCEPTION
      WHEN OTHERS THEN
        O_MSG := '获取前12个月销售金额出错！！主体：' || V_ENTITY_ID || '，客户ID：' ||
                 V_CUSTOMER_ID || '，营销大类编码：' || V_SALES_MAIN_TYPE_CODE ||
                 '，账户ID：' || V_CREDIT_TS.ACCOUNT_ID ||
                 SUBSTR(SQLERRM, 1, 200);
        RETURN;
    END;
    --最新信用额度计算 V_CUS_CREDIT_LINE

    --2016-06-07tianmzh修改，根据RDM需求MR2016052419298，修改计算客户信用额度的算法
    --，使用客户营销大类对应的前12月销售金额代替原有的前12月销售金额来参与计算。
    BEGIN
      --V_CREDIT_CALC_PERCENT
      SELECT CREDIT_CALC_PERCENT
        INTO ON_CREDIT_CALC_PERCENT
        FROM T_CREDIT_RATING
       WHERE ENTITY_ID = V_ENTITY_ID
         AND CREDIT_RATING_NAME = V_CUSTOMER_CREDIT_LEVEL
         AND TRUNC(V_NOW_TIMESTAMP) BETWEEN BEGIN_DATE AND
             NVL(END_DATE, V_NOW_TIMESTAMP)
         AND 1 = ROWNUM;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        ON_CREDIT_CALC_PERCENT := 0;
      WHEN OTHERS THEN
        O_MSG := '获取信用等级额度计算比例出错！！主体：' || V_ENTITY_ID || '，信用等级：' ||
                 V_CUSTOMER_CREDIT_LEVEL || SUBSTR(SQLERRM, 1, 200);
        RETURN;
    END;
    --信用额度 = 销售收入*计算比例
    V_CUS_CREDIT_LINE      := ROUND(ROUND(ON_TWELVE_AMOUNT, 2) *
                                    ROUND(ON_CREDIT_CALC_PERCENT, 2), --
                                    2);
    OS_CUS_CREDIT_LINE_MSG := '截止上个月底往前12个月销售收入乘以计算比例：' ||
                              ROUND(ON_TWELVE_AMOUNT, 2) || '×' ||
                              ROUND(ON_CREDIT_CALC_PERCENT, 2) || '=' ||
                              V_CUS_CREDIT_LINE ||
                              '（计算比例在“信用管理”-“信用基础数据”-“信用额度计算规则”有权限的进行查看、维护）';

    --取客户上一年度月均提货金额计算信用额度 V_LAST_YEAR_CUST_AMOUNT
    V_THIS_YEAR_BEGIN_DATE := TRUNC(V_NOW_TIMESTAMP, 'YY'); --
    V_LAST_YEAR_END_DATE   := V_THIS_YEAR_BEGIN_DATE - 1; --
    V_LAST_YEAR_BEGIN_DATE := TRUNC(V_LAST_YEAR_END_DATE, 'YY'); --
    --V_LAST_YEAR_CUST_AMOUNT := V_CREDIT_TS.L
    BEGIN
      SELECT PKG_CREDIT_TOOLS.FUN_GET_SALES_AMOUNT_BY_DATE(V_ENTITY_ID,
                                                           V_CUSTOMER_ID,
                                                           V_LAST_YEAR_BEGIN_DATE,
                                                           V_LAST_YEAR_END_DATE,
                                                           V_SALES_MAIN_TYPE_CODE,
                                                           --2017 5 2 梁颜明 增加账户ID
                                                           V_CREDIT_TS.ACCOUNT_ID)
        INTO ON_LAST_YEAR_CUST_AMOUNT
        FROM DUAL;
    EXCEPTION
      WHEN OTHERS THEN
        O_MSG := '获取上一年度月均提货金额出错！！主体：' || V_ENTITY_ID || '，客户ID：' ||
                 V_CUSTOMER_ID || '，营销大类编码：' || V_SALES_MAIN_TYPE_CODE ||
                 '，账户ID：' || V_CREDIT_TS.ACCOUNT_ID ||
                 SUBSTR(SQLERRM, 1, 200);
        RETURN;
    END;

    --此客户上年月均销售铺底比例
    --此客户本年月均销售铺底比例
    /*
        ON_LAST_YEAR_CUST_AMOUNT ON_THIS_YEAR_MONTH_CUST_AMOUNT
    OS_LAST_YEAR_CREDIT_LINE_MSG OS_THIS_YEAR_CREDIT_LINE_MSG
    ON_LAST_YEAR_CUST_AMOUNT_AVG ON_THIS_YEAR_MM_CUST_AMOUNT_AVG ON_THIS_MONTH_DELAY_AMOUNT_AVG
    V_COOPER_DATE V_TWELVE_AMOUNT V_COOPER_DATE_MARKET_MODE V_TWELVE_AMOUNT_MARKET_MODE
    V_LAST_YEAR_PROP_MARKET_MODE V_THIS_YEAR_PROP_MARKET_MODE
    */
    BEGIN
      SELECT LASTYEAR_PROPORTION,CURRENTYEAR_PROPORTION,COORERATION_DATE,LAST_TWELVE_AMOUNT,
      LASTYEAR_PROPORTION_MM,CURRENTYEAR_PROPORTION_MM,COORERATION_DATE_MM,LAST_TWELVE_AMOUNT_MM
      INTO ON_LAST_YEAR_PROPORTION,
             ON_THIS_YEAR_PROPORTION,
             V_COOPER_DATE,
             V_TWELVE_AMOUNT,
             V_LAST_YEAR_PROP_MARKET_MODE,
             V_THIS_YEAR_PROP_MARKET_MODE,
             V_COOPER_DATE_MARKET_MODE,
             V_TWELVE_AMOUNT_MARKET_MODE
      FROM (WITH T AS (--
      SELECT MAX(T.LASTYEAR_PROPORTION) OVER(ORDER BY T.ENTITY_ID,CM.CUSTOMER_ID,DECODE(V_ACCOUNT_ID,NULL,NULL,0,NULL,CM.SALES_CENTER_ID)) AS LASTYEAR_PROPORTION,
             MAX(T.CURRENTYEAR_PROPORTION) OVER(ORDER BY T.ENTITY_ID,CM.CUSTOMER_ID,DECODE(V_ACCOUNT_ID,NULL,NULL,0,NULL,CM.SALES_CENTER_ID)) AS CURRENTYEAR_PROPORTION,
             MAX(T.COORERATION_DATE) OVER(ORDER BY T.ENTITY_ID,CM.CUSTOMER_ID,DECODE(V_ACCOUNT_ID,NULL,NULL,0,NULL,CM.SALES_CENTER_ID)) AS COORERATION_DATE,
             MAX(T.LAST_TWELVE_AMOUNT) OVER(ORDER BY T.ENTITY_ID,CM.CUSTOMER_ID,DECODE(V_ACCOUNT_ID,NULL,NULL,0,NULL,CM.SALES_CENTER_ID)) AS LAST_TWELVE_AMOUNT,
             T.RELATION_ID,
             T.MIDEA_MARKET_MODE,
             /*T.DEADLINE,
             T.LASTYEAR_PROPORTION,
             T.CURRENTYEAR_PROPORTION,
             T.COORERATION_DATE,
             T.LAST_TWELVE_AMOUNT,
             CM.CUSTOMER_CODE,
             CM.CUSTOMER_STATUS,
             CM.CUSTOMER_NAME,
             CM.SALES_CENTER_CODE,
             CM.SALES_CENTER_NAME,
             CM.ORG_STATUS,
             CM.SALES_MAIN_TYPE_CODE,
             CM.SALES_MAIN_TYPE_NAME,
             CM.ACTIVE_FLAG,
             CM.COOPERATION_MODEL,*/
             CM.COOPERATION_MODEL_NAME,
             DENSE_RANK() OVER(PARTITION BY T.ENTITY_ID,CM.CUSTOMER_ID,DECODE(V_ACCOUNT_ID,NULL,NULL,0,NULL,CM.SALES_CENTER_ID) ORDER BY T.LASTYEAR_PROPORTION DESC) AS LASTYEAR_PROPORTION_MM,
             DENSE_RANK() OVER(PARTITION BY T.ENTITY_ID,CM.CUSTOMER_ID,DECODE(V_ACCOUNT_ID,NULL,NULL,0,NULL,CM.SALES_CENTER_ID) ORDER BY T.CURRENTYEAR_PROPORTION DESC) AS CURRENTYEAR_PROPORTION_MM,
             DENSE_RANK() OVER(PARTITION BY T.ENTITY_ID,CM.CUSTOMER_ID,DECODE(V_ACCOUNT_ID,NULL,NULL,0,NULL,CM.SALES_CENTER_ID) ORDER BY T.COORERATION_DATE DESC) AS COORERATION_DATE_MM,
             DENSE_RANK() OVER(PARTITION BY T.ENTITY_ID,CM.CUSTOMER_ID,DECODE(V_ACCOUNT_ID,NULL,NULL,0,NULL,CM.SALES_CENTER_ID) ORDER BY T.LAST_TWELVE_AMOUNT DESC) AS LAST_TWELVE_AMOUNT_MM
        FROM T_CREDIT_RATING_CUSTOMER T
      INNER JOIN T_CUSTOMER_COOPERATE_MODEL CM
      ON (T.ENTITY_ID = V_ENTITY_ID AND CM.ENTITY_ID = V_ENTITY_ID
      AND CM.CUSTOMER_ID = V_CUSTOMER_ID AND 'Active' = CM.ACTIVE_FLAG
         AND CM.COOPERATION_MODEL = T.MIDEA_MARKET_MODE
         AND (V_ACCOUNT_ID IS NULL OR 0 >= V_ACCOUNT_ID
         OR EXISTS (SELECT 1 FROM T_CUSTOMER_ACCOUNT CA WHERE CA.ACCOUNT_ID = V_ACCOUNT_ID
         AND CA.CUSTOMER_ID = V_CUSTOMER_ID AND CA.SALES_CENTER_ID = CM.SALES_CENTER_ID))
      )
      --
      )
      SELECT LASTYEAR_PROPORTION,
             CURRENTYEAR_PROPORTION,
             COORERATION_DATE,
             LAST_TWELVE_AMOUNT,
             (SELECT MIDEA_MARKET_MODE
                FROM (SELECT MAX(TA.MIDEA_MARKET_MODE) OVER(ORDER BY TA.RELATION_ID) AS MIDEA_MARKET_MODE
                        FROM T TA
                       WHERE 1 = TA.LASTYEAR_PROPORTION_MM)
               WHERE 1 = ROWNUM) AS LASTYEAR_PROPORTION_MM,
             (SELECT MIDEA_MARKET_MODE
                FROM (SELECT MAX(TA.MIDEA_MARKET_MODE) OVER(ORDER BY TA.RELATION_ID) AS MIDEA_MARKET_MODE
                        FROM T TA
                       WHERE 1 = TA.CURRENTYEAR_PROPORTION_MM)
               WHERE 1 = ROWNUM) AS CURRENTYEAR_PROPORTION_MM,
             (SELECT MIDEA_MARKET_MODE
                FROM (SELECT MAX(TA.MIDEA_MARKET_MODE) OVER(ORDER BY TA.RELATION_ID) AS MIDEA_MARKET_MODE
                        FROM T TA
                       WHERE 1 = TA.COORERATION_DATE_MM)
               WHERE 1 = ROWNUM) AS COORERATION_DATE_MM,
             (SELECT MIDEA_MARKET_MODE
                FROM (SELECT MAX(TA.MIDEA_MARKET_MODE) OVER(ORDER BY TA.RELATION_ID) AS MIDEA_MARKET_MODE
                        FROM T TA
                       WHERE 1 = TA.LAST_TWELVE_AMOUNT_MM)
               WHERE 1 = ROWNUM) AS LAST_TWELVE_AMOUNT_MM
        FROM T TA WHERE 1 = TA.LAST_TWELVE_AMOUNT_MM AND 1 = ROWNUM
      )-- WHERE 1 = ROWNUM
       /*WHERE T.MIDEA_MARKET_MODE IN
             (SELECT CB.COOPERATION_MODEL
                FROM T_CUSTOMER_BRAND CB
               WHERE CB.CUSTOMER_ID = V_CUSTOMER_ID
                 AND CB.ENTITY_ID = V_ENTITY_ID
                 AND CB.ACTIVE_FLAG = 'Active')
         AND T.ENTITY_ID = V_ENTITY_ID*/
         ;
    EXCEPTION
      WHEN OTHERS THEN
        ON_LAST_YEAR_PROPORTION := 0;
        ON_THIS_YEAR_PROPORTION := 0;
        V_COOPER_DATE           := 0;
        V_TWELVE_AMOUNT         := 0;
    END;
    
    BEGIN
      SELECT CL.CODE_NAME INTO V_LAST_YEAR_PROP_MARKET_MODE FROM V_UP_CODELIST CL WHERE CL.CODETYPE='MIDEA_MARKET_MODE'
      AND CL.CODE_VALUE = V_LAST_YEAR_PROP_MARKET_MODE AND (CL.ENTITY_ID IS NULL OR CL.ENTITY_ID = I_ENTITY_ID);
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;
    
    BEGIN
      SELECT CL.CODE_NAME INTO V_THIS_YEAR_PROP_MARKET_MODE FROM V_UP_CODELIST CL WHERE CL.CODETYPE='MIDEA_MARKET_MODE'
      AND CL.CODE_VALUE = V_THIS_YEAR_PROP_MARKET_MODE AND (CL.ENTITY_ID IS NULL OR CL.ENTITY_ID = I_ENTITY_ID);
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;
    
    BEGIN
      SELECT CL.CODE_NAME INTO V_COOPER_DATE_MARKET_MODE FROM V_UP_CODELIST CL WHERE CL.CODETYPE='MIDEA_MARKET_MODE'
      AND CL.CODE_VALUE = V_COOPER_DATE_MARKET_MODE AND (CL.ENTITY_ID IS NULL OR CL.ENTITY_ID = I_ENTITY_ID);
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;
    
    BEGIN
      SELECT CL.CODE_NAME INTO V_TWELVE_AMOUNT_MARKET_MODE FROM V_UP_CODELIST CL WHERE CL.CODETYPE='MIDEA_MARKET_MODE'
      AND CL.CODE_VALUE = V_TWELVE_AMOUNT_MARKET_MODE AND (CL.ENTITY_ID IS NULL OR CL.ENTITY_ID = I_ENTITY_ID);
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;

    --上年度信用额度
    V_LAST_YEAR_CREDIT_LINE      := ROUND((ON_LAST_YEAR_CUST_AMOUNT *
                                          ON_LAST_YEAR_PROPORTION) / 1200,
                                          2);
    OS_LAST_YEAR_CREDIT_LINE_MSG := '上年度销售收入乘以此客户上年月均销售铺底比例：' ||
                                    ON_LAST_YEAR_CUST_AMOUNT || '×' ||
                                    (ON_LAST_YEAR_PROPORTION) || '(合作类型：' ||
                                    V_LAST_YEAR_PROP_MARKET_MODE || ')' ||
                                    '/1200=' || V_LAST_YEAR_CREDIT_LINE;

    ----本年月销售金额
    BEGIN
      SELECT PKG_CREDIT_TOOLS.FUN_GET_SALES_AMOUNT_BY_DATE(V_ENTITY_ID,
                                                           V_CUSTOMER_ID,
                                                           V_THIS_YEAR_BEGIN_DATE,
                                                           V_THIS_MONTH_FIRST - 1,
                                                           V_SALES_MAIN_TYPE_CODE,
                                                           --2017 5 2 梁颜明 增加账户ID
                                                           V_CREDIT_TS.ACCOUNT_ID)
        INTO ON_THIS_YEAR_MONTH_CUST_AMOUNT
        FROM DUAL;
    EXCEPTION
      WHEN OTHERS THEN
        O_MSG := '获取本年月均提货金额出错！！主体：' || V_ENTITY_ID || '，客户ID：' ||
                 V_CUSTOMER_ID || '，营销大类编码：' || V_SALES_MAIN_TYPE_CODE ||
                 '，账户ID：' || V_CREDIT_TS.ACCOUNT_ID ||
                 SUBSTR(SQLERRM, 1, 200);
        RETURN;
    END;

    --本年度信用额度
    V_THIS_YEAR_CREDIT_LINE := 0;
    SELECT EXTRACT(MONTH FROM V_NOW_TIMESTAMP)
      INTO V_CURRENT_MONTH
      FROM DUAL;
    --每年从4月份开始才可以计算本年度信用额度 2017-01-05
    IF V_CURRENT_MONTH >= 4 THEN
      V_THIS_YEAR_CREDIT_LINE      := ROUND((ON_THIS_YEAR_MONTH_CUST_AMOUNT *
                                            ON_THIS_YEAR_PROPORTION) /
                                            (100 * (V_CURRENT_MONTH - 1)),
                                            2);
      OS_THIS_YEAR_CREDIT_LINE_MSG := '本年度销售收入乘以此客户本年月均销售铺底比例：' ||
                                      ON_THIS_YEAR_MONTH_CUST_AMOUNT || '×' ||
                                      (ON_THIS_YEAR_PROPORTION) || '(合作类型：' ||
                                      V_THIS_YEAR_PROP_MARKET_MODE || ')' || '/' ||
                                      (100 * (V_CURRENT_MONTH - 1)) || '=' ||
                                      V_THIS_YEAR_CREDIT_LINE;
    ELSE
      OS_THIS_YEAR_CREDIT_LINE_MSG := '每年1/2/3月份本年度信用额度为零，从4月份开始才开始计算';
    END IF;

    --------------------------------------------------------ADD BY WANGCONG---------------------------------------
    ------------------------------------------ 2016-06-07tianmzh新增start -----------------------------------------------------------------------------------
    --增加获取上年月均销售金额、本年月均销售金额、本年月均铺底。
    --上年月均销售金额
    ON_LAST_YEAR_CUST_AMOUNT_AVG   := (ON_LAST_YEAR_CUST_AMOUNT / 12);
    ON_THIS_YEAR_MM_AMOUNT_AVG     := 0.0; --本年月月均销售金额
    ON_THIS_MONTH_DELAY_AMOUNT_AVG := 0.0; --本年月均铺底
    --
    IF V_CURRENT_MONTH > 1 THEN
      ON_THIS_YEAR_MM_AMOUNT_AVG := (ON_THIS_YEAR_MONTH_CUST_AMOUNT /
                                    (V_CURRENT_MONTH - 1));
      SELECT PKG_CREDIT_TOOLS.FUN_GET_DELAY_AMOUNT_BY_DATE(V_ENTITY_ID,
                                                           V_CUSTOMER_ID,
                                                           V_SALES_MAIN_TYPE_CODE,
                                                           V_THIS_YEAR_BEGIN_DATE,
                                                           V_THIS_MONTH_FIRST,
                                                           --2017 5 2 梁颜明 增加账户ID
                                                           V_CREDIT_TS.ACCOUNT_ID) /
             (V_CURRENT_MONTH - 1)
        INTO ON_THIS_MONTH_DELAY_AMOUNT_AVG
        FROM DUAL;
    END IF;
    ----------------------------------------- 2016-06-07tianmzh新增end ---------------------------------------------------------------

    IF ON_COOPERATE_DAYS < V_COOPER_DATE THEN
      OS_CAN_USE_AMOUNT_MSG := '合作天数：' || ON_COOPERATE_DAYS ||
                               '小于合作类型参数配置指定的合作天数：' || V_COOPER_DATE ||
                               '(合作类型：' || V_COOPER_DATE_MARKET_MODE ||
                               ')，可用信用额度为零';
      RETURN;
    END IF;
    V_THIS_YEAR_PROPORTION := ON_THIS_YEAR_PROPORTION;
    --每年1/2/3月份本年度信用额度比例直接为0 2017-01-05
    IF 4 > EXTRACT(MONTH FROM SYSDATE) THEN
      V_THIS_YEAR_PROPORTION := 0;
      OS_THIS_YEAR_PROP_MSG  := '每年1/2/3月份本年度信用额度比例直接为0';
    END IF;
    --获取是否按品类控制
    pkg_bd.P_GET_PARAMETER_VALUE('if_control_by_type',
                                 I_ENTITY_ID,
                                 NULL,
                                 NULL,
                                 V_IF_CONTROL_BY_TYPE);
    IF V_IF_CONTROL_BY_TYPE = 'Y' THEN
      --按品类控制
      IF ON_TWELVE_AMOUNT < V_TWELVE_AMOUNT THEN
        OS_CAN_USE_AMOUNT_MSG := '前12个月销售收入：' || ON_TWELVE_AMOUNT ||
                                 '小于合作类型参数配置指定的前12个月销售收入：' || V_TWELVE_AMOUNT ||
                                 '(合作类型：' || V_TWELVE_AMOUNT_MARKET_MODE ||
                                 ')，可用信用额度为零';
        RETURN;
      END IF;
    
      V_ADJ_AMOUNT        := PKG_CREDIT_TOOLS.FUN_GET_ADJ_AMOUNT(I_ENTITY_ID,
                                                                 I_CUSTOMER_ID,
                                                                 I_SALES_MAIN_TYPE_CODE,
                                                                 IN_ACCOUNT_ID);
      V_USE_DELAY         := PKG_CREDIT_TOOLS.FUN_GET_USE_DELAY(I_ENTITY_ID,
                                                                I_CUSTOMER_ID,
                                                                I_SALES_MAIN_TYPE_CODE,
                                                                IN_ACCOUNT_ID);
      V_THREEDELAY_AMOUNT := PKG_CREDIT_TOOLS.FUN_GET_THREEDELAY_AMOUNT(I_ENTITY_ID,
                                                                        I_CUSTOMER_ID,
                                                                        I_SALES_MAIN_TYPE_CODE,
                                                                        IN_ACCOUNT_ID);
      IF ON_LAST_YEAR_PROPORTION = 0 AND V_THIS_YEAR_PROPORTION = 0 THEN
        --上年度和本年度额度比例为0 取客户等级额度
        V_CREDIT_AMOUNT := V_CUS_CREDIT_LINE;
        OS_CAN_USE_AMOUNT_MSG := '上年度和本年度额度比例为0，取客户等级额度：' || V_CUS_CREDIT_LINE;
      ELSIF ON_LAST_YEAR_PROPORTION = 0 AND V_THIS_YEAR_PROPORTION <> 0 THEN
        --本年度额度比例不为0 取本年度和客户等级额度的最小值
        SELECT LEAST(V_CUS_CREDIT_LINE, V_THIS_YEAR_CREDIT_LINE)
          INTO V_CREDIT_AMOUNT
          FROM DUAL;
        OS_CAN_USE_AMOUNT_MSG := '本年度额度比例不为0，取本年度和客户等级额度的最小值：'
        || V_CREDIT_AMOUNT || '（' || V_THIS_YEAR_CREDIT_LINE || '、' || V_CUS_CREDIT_LINE || '）';
      ELSIF ON_LAST_YEAR_PROPORTION <> 0 AND V_THIS_YEAR_PROPORTION = 0 THEN
        --上年度额度比例不为0 取上年度和客户等级额度的最小值
        SELECT LEAST(V_CUS_CREDIT_LINE, V_LAST_YEAR_CREDIT_LINE)
          INTO V_CREDIT_AMOUNT
          FROM DUAL;
        OS_CAN_USE_AMOUNT_MSG := '上年度额度比例不为0，取上年度和客户等级额度的最小值：'
        || V_CREDIT_AMOUNT || '（' || V_LAST_YEAR_CREDIT_LINE || '、' || V_CUS_CREDIT_LINE || '）';
      ELSIF ON_LAST_YEAR_PROPORTION <> 0 AND V_THIS_YEAR_PROPORTION <> 0 THEN
        --上年度和本年度额度比例不为0 取上年度 本年度 客户等级额度最小值
        SELECT LEAST(V_CUS_CREDIT_LINE,
                     V_LAST_YEAR_CREDIT_LINE,
                     V_THIS_YEAR_CREDIT_LINE)
          INTO V_CREDIT_AMOUNT
          FROM DUAL;
        OS_CAN_USE_AMOUNT_MSG := '上年度和本年度额度比例不为0，取上年度、本年度、客户等级额度最小值：'
        || V_CREDIT_AMOUNT || '（' || V_LAST_YEAR_CREDIT_LINE || '、' || V_THIS_YEAR_CREDIT_LINE
         || '、' || V_CUS_CREDIT_LINE || '）';
      END IF;
    ELSE
      --不按品类控制
      SELECT SUM(NVL(T.CREDIT_LINE, 0)),
             SUM(NVL(T.LASTYEAR_CREDIT_LINE, 0)),
             SUM(NVL(T.THISYEAR_CREDIT_LINE, 0)),
             SUM(NVL(T.TWELVE_AMOUNT, 0))
        INTO V_CUS_CREDIT_LINE,
             V_LAST_YEAR_AMOUNT,
             V_THIS_YEAR_AMOUNT,
             V_TWELVE_AMOUNT_UNION
      --2017 04 25 梁颜明 增加账户ID
        FROM T_CREDIT_CUSTOMER T
       WHERE T.CUSTOMER_ID = I_CUSTOMER_ID
         AND T.ENTITY_ID = I_ENTITY_ID
         AND (((IN_ACCOUNT_ID IS NULL OR 0 >= IN_ACCOUNT_ID) AND
             (T.ACCOUNT_ID IS NULL OR 0 >= T.ACCOUNT_ID)) OR
             (0 < IN_ACCOUNT_ID AND T.ACCOUNT_ID = IN_ACCOUNT_ID));
      IF V_TWELVE_AMOUNT_UNION < V_TWELVE_AMOUNT THEN
        OS_CAN_USE_AMOUNT_MSG := '前12个月销售收入：' || V_TWELVE_AMOUNT_UNION ||
                                 '小于合作类型参数配置指定的前12个月销售收入：' ||
                                 V_TWELVE_AMOUNT || '(合作类型：' ||
                                 V_TWELVE_AMOUNT_MARKET_MODE || ')，可用信用额度为零';
        RETURN;
      END IF;
      Open C_SALES_MAIN_TYPE;
      LOOP
        FETCH C_SALES_MAIN_TYPE
          INTO R_SALES_MAIN_TYPE;
        EXIT WHEN C_SALES_MAIN_TYPE%NOTFOUND;
      
        BEGIN
          V_ADJ_AMOUNT        := V_ADJ_AMOUNT +
                                 PKG_CREDIT_TOOLS.FUN_GET_ADJ_AMOUNT(I_ENTITY_ID,
                                                                     I_CUSTOMER_ID,
                                                                     R_SALES_MAIN_TYPE,
                                                                     IN_ACCOUNT_ID);
          V_USE_DELAY         := V_USE_DELAY +
                                 PKG_CREDIT_TOOLS.FUN_GET_USE_DELAY(I_ENTITY_ID,
                                                                    I_CUSTOMER_ID,
                                                                    R_SALES_MAIN_TYPE,
                                                                    IN_ACCOUNT_ID);
          V_THREEDELAY_AMOUNT := V_THREEDELAY_AMOUNT +
                                 PKG_CREDIT_TOOLS.FUN_GET_THREEDELAY_AMOUNT(I_ENTITY_ID,
                                                                            I_CUSTOMER_ID,
                                                                            R_SALES_MAIN_TYPE,
                                                                            IN_ACCOUNT_ID);
        END;
      END LOOP;
      IF ON_LAST_YEAR_PROPORTION = 0 AND V_THIS_YEAR_PROPORTION = 0 THEN
        --上年度和本年度额度比例为0 取客户等级额度
        V_CREDIT_AMOUNT := V_CUS_CREDIT_LINE;
        OS_CAN_USE_AMOUNT_MSG := '上年度和本年度额度比例为0，取客户等级额度：' || V_CUS_CREDIT_LINE;
      ELSIF ON_LAST_YEAR_PROPORTION = 0 AND V_THIS_YEAR_PROPORTION <> 0 THEN
        --本年度额度比例不为0 取本年度和客户等级额度的最小值
        SELECT LEAST(V_CUS_CREDIT_LINE, V_THIS_YEAR_AMOUNT)
          INTO V_CREDIT_AMOUNT
          FROM DUAL;
        OS_CAN_USE_AMOUNT_MSG := '本年度额度比例不为0，取本年度和客户等级额度的最小值：'
        || V_CREDIT_AMOUNT || '（' || V_THIS_YEAR_AMOUNT || '、' || V_CUS_CREDIT_LINE || '）';
      ELSIF ON_LAST_YEAR_PROPORTION <> 0 AND V_THIS_YEAR_PROPORTION = 0 THEN
        --上年度额度比例不为0 取上年度和客户等级额度的最小值
        SELECT LEAST(V_CUS_CREDIT_LINE, V_LAST_YEAR_AMOUNT)
          INTO V_CREDIT_AMOUNT
          FROM DUAL;
        OS_CAN_USE_AMOUNT_MSG := '上年度额度比例不为0，取上年度和客户等级额度的最小值：'
        || V_CREDIT_AMOUNT || '（' || V_LAST_YEAR_AMOUNT || '、' || V_CUS_CREDIT_LINE || '）';
      ELSIF ON_LAST_YEAR_PROPORTION <> 0 AND V_THIS_YEAR_PROPORTION <> 0 THEN
        --上年度和本年度额度比例不为0 取上年度 本年度 客户等级额度最小值
        SELECT LEAST(V_CUS_CREDIT_LINE,
                     V_LAST_YEAR_AMOUNT,
                     V_THIS_YEAR_AMOUNT)
          INTO V_CREDIT_AMOUNT
          FROM DUAL;
        OS_CAN_USE_AMOUNT_MSG := '上年度和本年度额度比例不为0，取客户等级、上年度、本年度额度最小值：'
        || V_CREDIT_AMOUNT || '（' || V_CUS_CREDIT_LINE || '、' || V_LAST_YEAR_AMOUNT
         || '、' || V_THIS_YEAR_AMOUNT || '）';
      END IF;
      OS_CAN_USE_AMOUNT_MSG := OS_CAN_USE_AMOUNT_MSG || V_NL || '受系统参数if_control_by_type控制，上年度、本年度、客户等级各额度取各营销大类的合并值';
    END IF;
    OS_CAN_USE_AMOUNT_MSG := OS_CAN_USE_AMOUNT_MSG || V_NL || '可用额度=信用额度+三方铺底额度-已使用铺底额度+调整额度（从16年开始不开放调整额度功能）';
    OS_CAN_USE_AMOUNT_MSG := OS_CAN_USE_AMOUNT_MSG || V_NL
    || '(' || V_CREDIT_AMOUNT || '+' || V_THREEDELAY_AMOUNT || '-' || V_USE_DELAY || '+' || V_ADJ_AMOUNT || ')';
  END P_CREDIT_AMOUNT_DESC;

  /**
  * 信用额度初始化
  **/
  PROCEDURE P_CREDIT_AMOUNT_INIT(I_ENTITY_ID            IN NUMBER, --实体ID
                                 I_CUSTOMER_ID          IN NUMBER, --客户ID
                                 I_SALES_MAIN_TYPE_CODE IN VARCHAR2, --营销大类编码
                                 I_CHANGE_REASON        IN VARCHAR2, --1:信用额度调整申请2:客户组变更3:信用额度初始化
                                 I_USER_ID              IN VARCHAR2, --操作人
                                 I_FLAG                 IN VARCHAR2, --
                                 I_COMMIT               IN NUMBER, --1、成功时数据库事务提交
                                 O_MSG                  OUT VARCHAR2, --返回信息
                                 IN_ACCOUNT_ID          IN NUMBER DEFAULT NULL --2017-5-2 增加账户ID参数，默认为空
                                 ) IS
    V_CREDIT_TS V_CREDIT_TERMS%ROWTYPE; --客户信用额度记录
  BEGIN
    BEGIN
      SELECT *
        INTO V_CREDIT_TS
        FROM V_CREDIT_TERMS T
       WHERE ENTITY_ID = I_ENTITY_ID
         AND CUSTOMER_ID = I_CUSTOMER_ID
         AND SALES_MAIN_TYPE_CODE = I_SALES_MAIN_TYPE_CODE
            --2017 5 2 梁颜明 增加账户ID
         AND (((IN_ACCOUNT_ID IS NULL OR 0 >= IN_ACCOUNT_ID) -- AND (T.ACCOUNT_ID IS NULL OR 0 >= T.ACCOUNT_ID)
             ) OR (0 < IN_ACCOUNT_ID AND T.ACCOUNT_ID = IN_ACCOUNT_ID));
    
    EXCEPTION
      WHEN OTHERS THEN
        O_MSG := '根据主体ID，客户ID，营销大类获取CreditTerms出错！！主体：' || I_ENTITY_ID ||
                 '，客户ID：' || I_CUSTOMER_ID || '，营销大类编码：' ||
                 I_SALES_MAIN_TYPE_CODE || SUBSTR(SQLERRM, 1, 200);
        RETURN;
    END;
    P_CREDIT_AMOUNT_INIT(V_CREDIT_TS,
                         I_CHANGE_REASON,
                         I_USER_ID,
                         I_FLAG,
                         I_COMMIT,
                         O_MSG);
  
  END P_CREDIT_AMOUNT_INIT;

  /**
  * 信用额度初始化
  **/
  PROCEDURE P_CREDIT_AMOUNT_INIT(I_CREDIT_TERMS  IN V_CREDIT_TERMS%ROWTYPE, --客户信用额度记录
                                 I_CHANGE_REASON IN VARCHAR2, --1:信用额度调整申请2:客户组变更3:信用额度初始化
                                 I_USER_ID       IN VARCHAR2, --操作人
                                 I_FLAG          IN VARCHAR2, --
                                 I_COMMIT        IN NUMBER, --1、成功时数据库事务提交
                                 O_MSG           OUT VARCHAR2 --返回信息
                                 ) IS
    V_ENTITY_ID                 NUMBER;
    V_CUSTOMER_ID               NUMBER;
    V_CHANGE_REASON             VARCHAR2(240);
    V_SALES_MAIN_TYPE_CODE      V_CREDIT_TERMS.SALES_MAIN_TYPE_CODE%TYPE;
    V_OLD_CREDIT_LINE           V_CREDIT_TERMS.CREDIT_LINE%TYPE;
    V_OLD_CUSTOMER_CREDIT_LEVEL V_CREDIT_TERMS.CUSTOM_LEVEL%TYPE;
    V_CUSTOMER_CREDIT_LEVEL     V_CREDIT_TERMS.CUSTOM_LEVEL%TYPE;
    V_ENTITY_GROUP_CODE         T_BD_PARAM_LIST.DEFAULT_VALUE%TYPE;
    V_CUST_SALES_MAIN_TYPE      T_CUSTOMER_SALES_MAIN_TYPE%ROWTYPE;
    V_THIS_MONTH_FIRST          DATE;
    V_NOW_TIMESTAMP             DATE;
    V_COOPERATE_DAYS            NUMBER; --
    V_LAST_TWELVE_CUST_AMOUNT   NUMBER; --客户前12个月销售金额
    V_CREDIT_CALC_PERCENT       NUMBER; --信用额度计算比例
    V_CUS_CREDIT_LINE           NUMBER; --
    V_THIS_YEAR_BEGIN_DATE      DATE; --获取本年的第一天
    V_LAST_YEAR_BEGIN_DATE      DATE; --上一年最初一天
    V_LAST_YEAR_END_DATE        DATE; --上一年最后一天
  
    V_LAST_YEAR_PROPORTION         NUMBER; --此客户上年月均销售铺底比例
    V_THIS_YEAR_PROPORTION         NUMBER; --此客户本年月均销售铺底比例
    V_LAST_YEAR_CUST_AMOUNT        NUMBER; --客户上一年度销售金额
    V_LAST_YEAR_CREDIT_LINE        NUMBER; --上年度信用额度
    V_THIS_YEAR_CREDIT_LINE        NUMBER; --本年度信用额度
    V_THIS_YEAR_MONTH_CUST_AMOUNT  NUMBER; --本年月销售金额
    V_CURRENT_MONTH                NUMBER;
    V_LAST_YEAR_CUST_AMOUNT_AVG    NUMBER; --客户上一年度月均提货金额
    V_THIS_YEAR_MM_CUST_AMOUNT_AVG NUMBER; --本年月月均销售金额
    V_THIS_MONTH_DELAY_AMOUNT_AVG  NUMBER; --本年月均铺底
    V_SALES_CODE                   V_CREDIT_TERMS.SALES_CENTER_CODE%TYPE;
    V_SALES_NAME                   V_CREDIT_TERMS.SALES_CENTER_NAME%TYPE;
    V_COUNT                        NUMBER;
    V_CUSTOMER_ACTIVE_DATE         DATE;
    VN_C                           NUMBER;
    V_ACCOUNT_ID                   NUMBER;
  
  BEGIN
    IF I_CREDIT_TERMS.CUSTOMER_ID IS NOT NULL THEN
      V_OLD_CREDIT_LINE           := I_CREDIT_TERMS.CREDIT_LINE;
      V_OLD_CUSTOMER_CREDIT_LEVEL := I_CREDIT_TERMS.CUSTOM_CREDIT_LEVEL;
    END IF;
    V_NOW_TIMESTAMP        := SYSDATE;
    V_ENTITY_ID            := I_CREDIT_TERMS.ENTITY_ID;
    V_CUSTOMER_ID          := I_CREDIT_TERMS.CUSTOMER_ID;
    V_SALES_MAIN_TYPE_CODE := I_CREDIT_TERMS.SALES_MAIN_TYPE_CODE;
    V_ACCOUNT_ID           := I_CREDIT_TERMS.ACCOUNT_ID;
  
    --获取主体组编码
    BEGIN
      PKG_BD.P_GET_PARAMETER_VALUE('ar_entity_group',
                                   V_ENTITY_ID,
                                   NULL,
                                   NULL,
                                   V_ENTITY_GROUP_CODE);
    EXCEPTION
      WHEN OTHERS THEN
        O_MSG := '根据主体ID,获取主体组编码出错，主体：' || V_ENTITY_ID ||
                 SUBSTR(SQLERRM, 1, 200);
        RETURN;
    END;
  
    --获取客户的合作期限
    V_THIS_MONTH_FIRST := TRUNC(V_NOW_TIMESTAMP, 'MM');
    BEGIN
      WITH T1 AS
       (SELECT ROWNUM AS RN,
               NVL(CUSTOMER_ACTIVE_DATE, CREATION_DATE) AS CUSTOMER_ACTIVE_DATE
          FROM T_CUSTOMER_DEPT
         WHERE DEPT_ID = V_ENTITY_ID
           AND CUSTOMER_ID = V_CUSTOMER_ID
         ORDER BY DECODE(DEPT_CUSTOMER_STATUS, 'Active', 0, 'Freezing', 1, 2),
                  DECODE(ACTIVE_FLAG, 'Active', 0, 'Freezing', 1, 2),
                  DECODE(CUSTOMER_ACTIVE_DATE,
                         NULL,
                         V_NOW_TIMESTAMP,
                         CUSTOMER_ACTIVE_DATE),
                  DECODE(CREATION_DATE, NULL, V_NOW_TIMESTAMP, CREATION_DATE))
      SELECT CUSTOMER_ACTIVE_DATE,
             V_THIS_MONTH_FIRST - TRUNC(CUSTOMER_ACTIVE_DATE),
             DECODE(I_CHANGE_REASON,
                    '1',
                    '信用额度调整申请',
                    '2',
                    '客户组变更',
                    '3',
                    '信用额度初始化')
        INTO V_CUSTOMER_ACTIVE_DATE, V_COOPERATE_DAYS, V_CHANGE_REASON
        FROM DUAL
        LEFT JOIN T1
          ON (1 = RN);
    EXCEPTION
      WHEN OTHERS THEN
        O_MSG := '获取客户合作年限出错！！主体：' || V_ENTITY_ID || '，客户ID：' ||
                 V_CUSTOMER_ID || '，营销大类编码：' || V_SALES_MAIN_TYPE_CODE ||
                 SUBSTR(SQLERRM, 1, 200);
        RETURN;
    END;
    IF V_COOPERATE_DAYS IS NULL THEN
      O_MSG := '无法获取客户合作年限！！主体：' || V_ENTITY_ID || '，客户ID：' ||
               V_CUSTOMER_ID || '，营销大类编码：' || V_SALES_MAIN_TYPE_CODE;
      RETURN;
    END IF;
  
    --客户信用等级
    --V_CUSTOMER_CREDIT_LEVEL := '';
  
    BEGIN
      SELECT T.*
        INTO V_CUST_SALES_MAIN_TYPE
        FROM T_CUSTOMER_SALES_MAIN_TYPE T
       WHERE ENTITY_ID = V_ENTITY_ID
         AND CUSTOM_ID = V_CUSTOMER_ID
         AND SALES_MAIN_TYPE_CODE = V_SALES_MAIN_TYPE_CODE;
      V_CUSTOMER_CREDIT_LEVEL := '1';
      IF 'XSGS' = V_ENTITY_GROUP_CODE THEN
        V_CUSTOMER_CREDIT_LEVEL := NVL(NVL(V_CUST_SALES_MAIN_TYPE.CUSTOM_LEVEL,
                                           V_CUST_SALES_MAIN_TYPE.CUSTOM_CREDIT_LEVEL),
                                       '1');
      ELSIF 'JXS' = V_ENTITY_GROUP_CODE THEN
        V_CUSTOMER_CREDIT_LEVEL := NVL(V_CUST_SALES_MAIN_TYPE.CUSTOM_LEVEL,
                                       '4');
      END IF;
    
      IF 'XSGS' = V_ENTITY_GROUP_CODE THEN
        --家用额度初始化时候将客户信用等级置为最高级
        IF '0' = I_FLAG THEN
          --月自动初始化
          SELECT COUNT(0)
            INTO V_COUNT
            FROM T_CREDIT_BAD_RECORD
           WHERE ENTITY_ID = V_ENTITY_ID
             AND CUSTOMER_ID = V_CUSTOMER_ID
             AND ACTIVE_FLAG = '1';
          --每个月重新计算客户信用额度
          SELECT DECODE(V_COUNT,
                        0,
                        '1', --是否有逾期：无
                        DECODE(V_CUSTOMER_CREDIT_LEVEL,
                               '1',
                               '2',
                               '2',
                               '3',
                               '4')) --是否有逾期：有 存在是否有逾期进行相应降级处理
            INTO V_CUSTOMER_CREDIT_LEVEL
            FROM DUAL;
        END IF;
      ELSIF 'JXS' = V_ENTITY_GROUP_CODE THEN
        V_CUSTOMER_CREDIT_LEVEL := NVL(V_CUST_SALES_MAIN_TYPE.CUSTOM_LEVEL,
                                       '4');
        SELECT ROUND((V_NOW_TIMESTAMP - V_CUSTOMER_ACTIVE_DATE), 2) / 365
          INTO V_COUNT --合作天数/365
          FROM DUAL;
        IF 1 > V_COUNT THEN
          -- 客户合作年限小于1年的场合
          V_CUSTOMER_CREDIT_LEVEL := '4';
        END IF;
      
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        O_MSG := '获取客户信用等级出错！！主体：' || V_ENTITY_ID || '，客户ID：' ||
                 V_CUSTOMER_ID || '，营销大类编码：' || V_SALES_MAIN_TYPE_CODE ||
                 SUBSTR(SQLERRM, 1, 200);
        RETURN;
    END;
  
    --取客户前12个月销售金额 V_LAST_TWELVE_CUST_AMOUNT
    BEGIN
      SELECT PKG_CREDIT_TOOLS.FUN_GET_SALES_AMOUNT_BY_DATE(V_ENTITY_ID,
                                                           V_CUSTOMER_ID,
                                                           ADD_MONTHS(V_THIS_MONTH_FIRST,
                                                                      -12),
                                                           V_THIS_MONTH_FIRST - 1,
                                                           V_SALES_MAIN_TYPE_CODE,
                                                           --2017 5 2 梁颜明 增加账户ID
                                                           I_CREDIT_TERMS.ACCOUNT_ID)
        INTO V_LAST_TWELVE_CUST_AMOUNT
        FROM DUAL;
    EXCEPTION
      WHEN OTHERS THEN
        O_MSG := '获取前12个月销售金额出错！！主体：' || V_ENTITY_ID || '，客户ID：' ||
                 V_CUSTOMER_ID || '，营销大类编码：' || V_SALES_MAIN_TYPE_CODE ||
                 '，账户ID：' || I_CREDIT_TERMS.ACCOUNT_ID ||
                 SUBSTR(SQLERRM, 1, 200);
        RETURN;
    END;
    --最新信用额度计算 V_CUS_CREDIT_LINE
  
    --2016-06-07tianmzh修改，根据RDM需求MR2016052419298，修改计算客户信用额度的算法
    --，使用客户营销大类对应的前12月销售金额代替原有的前12月销售金额来参与计算。
    BEGIN
      --V_CREDIT_CALC_PERCENT
      SELECT CREDIT_CALC_PERCENT
        INTO V_CREDIT_CALC_PERCENT
        FROM T_CREDIT_RATING
       WHERE ENTITY_ID = V_ENTITY_ID
         AND CREDIT_RATING_NAME = V_CUSTOMER_CREDIT_LEVEL
         AND TRUNC(V_NOW_TIMESTAMP) BETWEEN BEGIN_DATE AND
             NVL(END_DATE, V_NOW_TIMESTAMP)
         AND 1 = ROWNUM;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        V_CREDIT_CALC_PERCENT := 0;
      WHEN OTHERS THEN
        O_MSG := '获取信用等级额度计算比例出错！！主体：' || V_ENTITY_ID || '，信用等级：' ||
                 V_CUSTOMER_CREDIT_LEVEL || SUBSTR(SQLERRM, 1, 200);
        RETURN;
    END;
    --信用额度 = 销售收入*计算比例
    V_CUS_CREDIT_LINE := ROUND(ROUND(V_LAST_TWELVE_CUST_AMOUNT, 2) *
                               ROUND(V_CREDIT_CALC_PERCENT, 2),
                               2);
  
    --取客户上一年度月均提货金额计算信用额度 V_LAST_YEAR_CUST_AMOUNT
    V_THIS_YEAR_BEGIN_DATE := TRUNC(V_NOW_TIMESTAMP, 'YY'); --
    V_LAST_YEAR_END_DATE   := V_THIS_YEAR_BEGIN_DATE - 1; --
    V_LAST_YEAR_BEGIN_DATE := TRUNC(V_LAST_YEAR_END_DATE, 'YY'); --
    BEGIN
      SELECT PKG_CREDIT_TOOLS.FUN_GET_SALES_AMOUNT_BY_DATE(V_ENTITY_ID,
                                                           V_CUSTOMER_ID,
                                                           V_LAST_YEAR_BEGIN_DATE,
                                                           V_LAST_YEAR_END_DATE,
                                                           V_SALES_MAIN_TYPE_CODE,
                                                           --2017 5 2 梁颜明 增加账户ID
                                                           I_CREDIT_TERMS.ACCOUNT_ID)
        INTO V_LAST_YEAR_CUST_AMOUNT
        FROM DUAL;
    EXCEPTION
      WHEN OTHERS THEN
        O_MSG := '获取上一年度月均提货金额出错！！主体：' || V_ENTITY_ID || '，客户ID：' ||
                 V_CUSTOMER_ID || '，营销大类编码：' || V_SALES_MAIN_TYPE_CODE ||
                 '，账户ID：' || I_CREDIT_TERMS.ACCOUNT_ID ||
                 SUBSTR(SQLERRM, 1, 200);
        RETURN;
    END;
  
    --此客户上年月均销售铺底比例
    --此客户本年月均销售铺底比例
    BEGIN
      SELECT LASTYEAR_PROPORTION,CURRENTYEAR_PROPORTION INTO V_LAST_YEAR_PROPORTION, V_THIS_YEAR_PROPORTION
      FROM (SELECT NVL(MAX(T.LASTYEAR_PROPORTION), 0) AS LASTYEAR_PROPORTION,
           NVL(MAX(T.CURRENTYEAR_PROPORTION), 0) AS CURRENTYEAR_PROPORTION
      FROM T_CREDIT_RATING_CUSTOMER T
      INNER JOIN T_CUSTOMER_COOPERATE_MODEL CM
      ON (T.ENTITY_ID = V_ENTITY_ID AND CM.ENTITY_ID = V_ENTITY_ID
      AND CM.CUSTOMER_ID = V_CUSTOMER_ID AND 'Active' = CM.ACTIVE_FLAG
         AND CM.COOPERATION_MODEL = T.MIDEA_MARKET_MODE
         AND (V_ACCOUNT_ID IS NULL OR 0 >= V_ACCOUNT_ID
         OR EXISTS (SELECT 1 FROM T_CUSTOMER_ACCOUNT CA WHERE CA.ACCOUNT_ID = V_ACCOUNT_ID
         AND CA.CUSTOMER_ID = V_CUSTOMER_ID AND CA.SALES_CENTER_ID = CM.SALES_CENTER_ID))
      )
      ) WHERE 1 = ROWNUM
     /*WHERE T.MIDEA_MARKET_MODE IN
           (SELECT CB.COOPERATION_MODEL
              FROM T_CUSTOMER_BRAND CB
             WHERE CB.CUSTOMER_ID = V_CUSTOMER_ID
               AND CB.ENTITY_ID = V_ENTITY_ID
               AND CB.ACTIVE_FLAG = 'Active')
       AND T.ENTITY_ID = V_ENTITY_ID*/
       ;
    EXCEPTION WHEN OTHERS THEN
      V_LAST_YEAR_PROPORTION := 0;
      V_THIS_YEAR_PROPORTION := 0;
    END;
  
    --上年度信用额度
    V_LAST_YEAR_CREDIT_LINE := ROUND((V_LAST_YEAR_CUST_AMOUNT *
                                     V_LAST_YEAR_PROPORTION) / 1200,
                                     2);
  
    ----本年月销售金额
    BEGIN
      SELECT PKG_CREDIT_TOOLS.FUN_GET_SALES_AMOUNT_BY_DATE(V_ENTITY_ID,
                                                           V_CUSTOMER_ID,
                                                           V_THIS_YEAR_BEGIN_DATE,
                                                           V_THIS_MONTH_FIRST - 1,
                                                           V_SALES_MAIN_TYPE_CODE,
                                                           --2017 5 2 梁颜明 增加账户ID
                                                           I_CREDIT_TERMS.ACCOUNT_ID)
        INTO V_THIS_YEAR_MONTH_CUST_AMOUNT
        FROM DUAL;
    EXCEPTION
      WHEN OTHERS THEN
        O_MSG := '获取本年月均提货金额出错！！主体：' || V_ENTITY_ID || '，客户ID：' ||
                 V_CUSTOMER_ID || '，营销大类编码：' || V_SALES_MAIN_TYPE_CODE ||
                 '，账户ID：' || I_CREDIT_TERMS.ACCOUNT_ID ||
                 SUBSTR(SQLERRM, 1, 200);
        RETURN;
    END;
  
    --本年度信用额度
    V_THIS_YEAR_CREDIT_LINE := 0;
    SELECT EXTRACT(MONTH FROM V_NOW_TIMESTAMP)
      INTO V_CURRENT_MONTH
      FROM DUAL;
    --每年从4月份开始才可以计算本年度信用额度 2017-01-05
    IF V_CURRENT_MONTH >= 4 THEN
      V_THIS_YEAR_CREDIT_LINE := ROUND((V_THIS_YEAR_MONTH_CUST_AMOUNT *
                                       V_THIS_YEAR_PROPORTION) /
                                       (100 * (V_CURRENT_MONTH - 1)),
                                       2);
    END IF;
  
    --------------------------------------------------------ADD BY WANGCONG---------------------------------------
    ------------------------------------------ 2016-06-07tianmzh新增start -----------------------------------------------------------------------------------
    --增加获取上年月均销售金额、本年月均销售金额、本年月均铺底。
    --上年月均销售金额
    V_LAST_YEAR_CUST_AMOUNT_AVG    := (V_LAST_YEAR_CUST_AMOUNT / 12);
    V_THIS_YEAR_MM_CUST_AMOUNT_AVG := 0.0; --本年月月均销售金额
    V_THIS_MONTH_DELAY_AMOUNT_AVG  := 0.0; --本年月均铺底
    --
    IF V_CURRENT_MONTH > 1 THEN
      V_THIS_YEAR_MM_CUST_AMOUNT_AVG := (V_THIS_YEAR_MONTH_CUST_AMOUNT /
                                        (V_CURRENT_MONTH - 1));
      SELECT PKG_CREDIT_TOOLS.FUN_GET_DELAY_AMOUNT_BY_DATE(V_ENTITY_ID,
                                                           V_CUSTOMER_ID,
                                                           V_SALES_MAIN_TYPE_CODE,
                                                           V_THIS_YEAR_BEGIN_DATE,
                                                           V_THIS_MONTH_FIRST,
                                                           --2017 5 2 梁颜明 增加账户ID
                                                           I_CREDIT_TERMS.ACCOUNT_ID) /
             (V_CURRENT_MONTH - 1)
        INTO V_THIS_MONTH_DELAY_AMOUNT_AVG
        FROM DUAL;
    END IF;
    ----------------------------------------- 2016-06-07tianmzh新增end ---------------------------------------------------------------
  
    ----信用等级和信用额度更新
    --2016-06-07tianmzh修改，增加更新字段：上年月均销售金额、本年月均销售金额、本年月均铺底
    BEGIN
      UPDATE T_CUSTOMER_SALES_MAIN_TYPE
         SET CUSTOM_CREDIT_LEVEL       = V_CUSTOMER_CREDIT_LEVEL,
             COPPER_DATE               = V_COOPERATE_DAYS,
             CREDIT_LINE               = DECODE(I_CREDIT_TERMS.ACCOUNT_ID,
                                                NULL,
                                                V_CUS_CREDIT_LINE,
                                                0,
                                                V_CUS_CREDIT_LINE,
                                                CREDIT_LINE),
             LASTYEAR_CREDIT_LINE      = DECODE(I_CREDIT_TERMS.ACCOUNT_ID,
                                                NULL,
                                                V_LAST_YEAR_CREDIT_LINE,
                                                0,
                                                V_LAST_YEAR_CREDIT_LINE,
                                                LASTYEAR_CREDIT_LINE),
             THISYEAR_CREDIT_LINE      = DECODE(I_CREDIT_TERMS.ACCOUNT_ID,
                                                NULL,
                                                V_THIS_YEAR_CREDIT_LINE,
                                                0,
                                                V_THIS_YEAR_CREDIT_LINE,
                                                LASTYEAR_CREDIT_LINE),
             TWELVE_AMOUNT             = DECODE(I_CREDIT_TERMS.ACCOUNT_ID,
                                                NULL,
                                                V_LAST_TWELVE_CUST_AMOUNT,
                                                0,
                                                V_LAST_TWELVE_CUST_AMOUNT,
                                                TWELVE_AMOUNT),
             LASTYEAR_SALES_AMOUNT_AVG = DECODE(I_CREDIT_TERMS.ACCOUNT_ID,
                                                NULL,
                                                ROUND(V_LAST_YEAR_CUST_AMOUNT_AVG,
                                                      2),
                                                0,
                                                ROUND(V_LAST_YEAR_CUST_AMOUNT_AVG,
                                                      2),
                                                LASTYEAR_SALES_AMOUNT_AVG),
             THISYEAR_SALES_AMOUNT_AVG = DECODE(I_CREDIT_TERMS.ACCOUNT_ID,
                                                NULL,
                                                ROUND(V_THIS_YEAR_MM_CUST_AMOUNT_AVG,
                                                      2),
                                                0,
                                                ROUND(V_THIS_YEAR_MM_CUST_AMOUNT_AVG,
                                                      2),
                                                THISYEAR_SALES_AMOUNT_AVG),
             THISYEAR_DELAYPAY_AVG     = DECODE(I_CREDIT_TERMS.ACCOUNT_ID,
                                                NULL,
                                                ROUND(V_THIS_MONTH_DELAY_AMOUNT_AVG,
                                                      2),
                                                0,
                                                ROUND(V_THIS_MONTH_DELAY_AMOUNT_AVG,
                                                      2),
                                                THISYEAR_DELAYPAY_AVG)
             /* 网批客户自主注册会根据LAST_UPDATE_DATE来推给美云销。
                此处，不更新LAST_UPDATE_DATE，因为客户网批标识没有变更。
                如果更新会导致推给美云销大量数据，导致阻塞。
             LAST_UPDATE_BY            = I_USER_ID,
             LAST_UPDATE_DATE          = V_NOW_TIMESTAMP*/
       WHERE ENTITY_ID = V_ENTITY_ID
         AND CUSTOM_ID = V_CUSTOMER_ID
         AND SALES_MAIN_TYPE_CODE = V_SALES_MAIN_TYPE_CODE;
      UPDATE T_CREDIT_CUSTOMER
         SET CUSTOM_CREDIT_LEVEL       = V_CUSTOMER_CREDIT_LEVEL,
             CUSTOM_LEVEL              = V_CUST_SALES_MAIN_TYPE.CUSTOM_LEVEL,
             COPPER_DATE               = V_COOPERATE_DAYS,
             CREDIT_LINE               = V_CUS_CREDIT_LINE,
             LASTYEAR_CREDIT_LINE      = V_LAST_YEAR_CREDIT_LINE,
             THISYEAR_CREDIT_LINE      = V_THIS_YEAR_CREDIT_LINE,
             TWELVE_AMOUNT             = V_LAST_TWELVE_CUST_AMOUNT,
             LASTYEAR_SALES_AMOUNT_AVG = ROUND(V_LAST_YEAR_CUST_AMOUNT_AVG,
                                               2),
             THISYEAR_SALES_AMOUNT_AVG = ROUND(V_THIS_YEAR_MM_CUST_AMOUNT_AVG,
                                               2),
             THISYEAR_DELAYPAY_AVG     = ROUND(V_THIS_MONTH_DELAY_AMOUNT_AVG,
                                               2),
             LAST_UPDATED_BY           = I_USER_ID,
             LAST_UPDATE_DATE          = V_NOW_TIMESTAMP
       WHERE ENTITY_ID = V_ENTITY_ID
         AND CUSTOMER_ID = V_CUSTOMER_ID
         AND SALES_MAIN_TYPE_CODE = V_SALES_MAIN_TYPE_CODE
         AND (((I_CREDIT_TERMS.ACCOUNT_ID IS NULL OR
             0 >= I_CREDIT_TERMS.ACCOUNT_ID) AND
             (ACCOUNT_ID IS NULL OR 0 >= ACCOUNT_ID)) OR
             (0 < I_CREDIT_TERMS.ACCOUNT_ID AND
             I_CREDIT_TERMS.ACCOUNT_ID = ACCOUNT_ID));
    EXCEPTION
      WHEN OTHERS THEN
        O_MSG := '信用等级和信用额度更新出错！！主体：' || V_ENTITY_ID || '，客户ID：' ||
                 V_CUSTOMER_ID || '，营销大类编码：' || V_SALES_MAIN_TYPE_CODE ||
                 '，账户ID：' || I_CREDIT_TERMS.ACCOUNT_ID ||
                 SUBSTR(SQLERRM, 1, 200);
        RETURN;
    END;
  
    V_SALES_CODE := I_CREDIT_TERMS.SALES_CENTER_CODE;
    V_SALES_NAME := I_CREDIT_TERMS.SALES_CENTER_NAME;
    IF I_CREDIT_TERMS.ACCOUNT_ID IS NULL OR 0 >= I_CREDIT_TERMS.ACCOUNT_ID THEN
      /*SELECT DECODE(I_CHANGE_REASON,
      '1',
      '信用额度调整申请',
      '2',
      '客户组变更',
      '3',
      '信用额度初始化') FROM DUAL;*/
      --信用额度历史参数设置  信用额度历史追加,信用额度没有变化的，不记录额度变更历史
      IF 200 < LENGTHB(V_SALES_CODE) THEN
        V_SALES_CODE := SUBSTR(V_SALES_CODE, 1, 197) || '...';
      END IF;
      IF 200 < LENGTHB(V_SALES_NAME) THEN
        --截取197个以内（包括197）的字节
        VN_C := 0;
        FOR FLC IN (SELECT LEVEL AS LV, SUBSTR(C, LEVEL, 1) AS C
                      FROM (SELECT V_SALES_NAME C FROM DUAL) T
                    --START WITH 1 = ROWNUM
                    CONNECT BY LEVEL <= LENGTH(T.C)
                     ORDER BY LEVEL) LOOP
          IF 197 < (VN_C + LENGTHB(FLC.C)) THEN
            EXIT;
          END IF;
          VN_C := (VN_C + LENGTHB(FLC.C));
        END LOOP;
        V_SALES_NAME := SUBSTRB(V_SALES_NAME, 1, VN_C) || '...';
      END IF;
    END IF;
    --cus_credit_level 客户信用等级 --credit_cust_level 客户等级
    IF NVL(V_OLD_CREDIT_LINE, 0) <> NVL(V_CUS_CREDIT_LINE, 0) THEN
      BEGIN
        INSERT INTO T_CREDIT_ADJ_HIS
          (CREDIT_ADJ_HIS_ID,
           ENTITY_ID,
           CUSTOMER_ID,
           CUSTOMER_CODE,
           CUSTOMER_NAME,
           SALES_CENTER_CODE,
           SALES_CENTER_NAME,
           SALES_MAIN_TYPE,
           OLD_CREDIT_LINE,
           NEW_CREDIT_LINE,
           CREDIT_RATING_ID,
           CREDIT_RATING_NAME,
           CREDIT_CHANGE_DATE,
           CREDIT_CHANGE_REASON,
           CREATED_BY,
           CREATION_DATE,
           LAST_UPDATED_BY,
           LAST_UPDATE_DATE,
           --PRE_FIELD_01,
           ACCOUNT_ID)
        VALUES
          (S_CREDIT_ADJ_HIS.NEXTVAL,
           V_ENTITY_ID,
           V_CUSTOMER_ID,
           I_CREDIT_TERMS.CUSTOMER_CODE,
           I_CREDIT_TERMS.CUSTOMER_NAME,
           V_SALES_CODE,
           V_SALES_NAME,
           V_SALES_MAIN_TYPE_CODE,
           V_OLD_CREDIT_LINE,
           V_CUS_CREDIT_LINE,
           I_CREDIT_TERMS.CUSTOM_CREDIT_LEVEL,
           (SELECT CODE_NAME
              FROM V_UP_CODELIST
             WHERE CODETYPE = 'cus_credit_level'
               AND ENTITY_ID IS NULL
               AND CODE_VALUE = I_CREDIT_TERMS.CUSTOM_CREDIT_LEVEL),
           V_NOW_TIMESTAMP,
           V_CHANGE_REASON,
           I_USER_ID,
           V_NOW_TIMESTAMP,
           I_USER_ID,
           V_NOW_TIMESTAMP,
           --I_CREDIT_TERMS.ACCOUNT_ID,
           NVL(I_CREDIT_TERMS.ACCOUNT_ID, 0));
      EXCEPTION
        WHEN OTHERS THEN
          O_MSG := '记录信用额度变更历史出错！！主体：' || V_ENTITY_ID || '，客户ID：' ||
                   V_CUSTOMER_ID || '，营销大类编码：' || V_SALES_MAIN_TYPE_CODE ||
                   '，账户ID：' || I_CREDIT_TERMS.ACCOUNT_ID ||
                   SUBSTR(SQLERRM, 1, 200);
          RETURN;
      END;
    END IF;
  
    --信用等级历史参数设置  信用等级历史追加,信用等级没有变化的，不记录信用等级变更历史
    IF NVL(V_CUSTOMER_CREDIT_LEVEL, ' ') <>
       NVL(V_OLD_CUSTOMER_CREDIT_LEVEL, ' ') THEN
      BEGIN
        INSERT INTO T_CREDIT_CHANGE_HIS
          (CREDIT_CHANGE_HIS_ID,
           ENTITY_ID,
           CUSTOMER_ID,
           CUSTOMER_CODE,
           CUSTOMER_NAME,
           SALES_CENTER_CODE,
           SALES_CENTER_NAME,
           SALES_MAIN_TYPE,
           CUSTOMER_LEVEL,
           CREDIT_RATING_ID,
           CREDIT_RATING_NAME,
           CREDIT_CHANGE_DATE,
           CREDIT_CHANGE_REASON,
           CREATED_BY,
           CREATION_DATE,
           LAST_UPDATED_BY,
           LAST_UPDATE_DATE,
           --PRE_FIELD_01,
           ACCOUNT_ID)
        VALUES
          (S_CREDIT_CHANGE_HIS.NEXTVAL,
           V_ENTITY_ID,
           V_CUSTOMER_ID,
           I_CREDIT_TERMS.CUSTOMER_CODE,
           I_CREDIT_TERMS.CUSTOMER_NAME,
           V_SALES_CODE,
           V_SALES_NAME,
           V_SALES_MAIN_TYPE_CODE,
           DECODE(V_CUSTOMER_CREDIT_LEVEL,
                  NULL,
                  '无',
                  V_CUSTOMER_CREDIT_LEVEL),
           DECODE(V_CUSTOMER_CREDIT_LEVEL,
                  NULL,
                  '无',
                  V_CUSTOMER_CREDIT_LEVEL),
           (SELECT CODE_NAME
              FROM V_UP_CODELIST
             WHERE CODETYPE = 'cus_credit_level'
               AND ENTITY_ID IS NULL
               AND CODE_VALUE = V_CUSTOMER_CREDIT_LEVEL),
           V_NOW_TIMESTAMP,
           V_CHANGE_REASON,
           I_USER_ID,
           V_NOW_TIMESTAMP,
           I_USER_ID,
           V_NOW_TIMESTAMP,
           --I_CREDIT_TERMS.ACCOUNT_ID,
           NVL(I_CREDIT_TERMS.ACCOUNT_ID, 0));
      EXCEPTION
        WHEN OTHERS THEN
          O_MSG := '记录信用等级变更历史出错！！主体：' || V_ENTITY_ID || '，客户ID：' ||
                   V_CUSTOMER_ID || '，营销大类编码：' || V_SALES_MAIN_TYPE_CODE ||
                   '，账户ID：' || I_CREDIT_TERMS.ACCOUNT_ID ||
                   SUBSTR(SQLERRM, 1, 200);
          RETURN;
      END;
    END IF;
  
    O_MSG := V_SUCCESS_MSG;
  
    IF 1 = I_COMMIT THEN
      COMMIT;
    END IF;
  
  END P_CREDIT_AMOUNT_INIT;

  /**
  * 信用额度客户信息初始化，重载，不传入营销大类，2017=04-24
  **/
  PROCEDURE P_CREDIT_CUSTOMER_INIT(IN_ENTITY_ID   IN NUMBER, --主体
                                   IN_CUSTOMER_ID IN NUMBER, --客户
                                   IN_ACCOUNT_ID  IN NUMBER, --账户
                                   OS_MSG         OUT VARCHAR2 --返回信息，初始化成功返回 V_SUCCESS_MSG
                                   ) IS
  BEGIN
    FOR LI IN (SELECT S.ENTITY_ID,
                      S.CUSTOM_ID AS CUSTOMER_ID,
                      S.SALES_MAIN_TYPE_CODE
                 FROM T_CUSTOMER_SALES_MAIN_TYPE S
                WHERE S.ENTITY_ID =
                      DECODE(IN_ENTITY_ID, NULL, S.ENTITY_ID, IN_ENTITY_ID)
                  AND S.CUSTOM_ID = DECODE(IN_CUSTOMER_ID,
                                           NULL,
                                           S.CUSTOM_ID,
                                           IN_CUSTOMER_ID)
                  AND EXISTS
                (SELECT 1
                         FROM T_CUSTOMER_ORG CO
                        WHERE CO.ENTITY_ID = S.ENTITY_ID
                          AND CO.CUSTOMER_ID = S.CUSTOM_ID)) LOOP
      BEGIN
        P_CREDIT_CUSTOMER_INIT(LI.ENTITY_ID,
                               LI.CUSTOMER_ID,
                               LI.SALES_MAIN_TYPE_CODE,
                               IN_ACCOUNT_ID,
                               OS_MSG);
        IF OS_MSG <> V_SUCCESS_MSG THEN
          NULL;
        END IF;
      
      EXCEPTION
        WHEN OTHERS THEN
          NULL;
      END;
    END LOOP;
  END P_CREDIT_CUSTOMER_INIT;

  /**
  * 信用额度客户信息初始化，2017=04-24
  **/
  PROCEDURE P_CREDIT_CUSTOMER_INIT(IN_ENTITY_ID            IN NUMBER, --主体
                                   IN_CUSTOMER_ID          IN NUMBER, --客户
                                   IS_SALES_MAIN_TYPE_CODE IN VARCHAR2, --营销大类
                                   IN_ACCOUNT_ID           IN NUMBER, --账户
                                   OS_MSG                  OUT VARCHAR2 --返回信息，初始化成功返回 V_SUCCESS_MSG
                                   ) IS
    VR_CUST_SALES_M       T_CUSTOMER_SALES_MAIN_TYPE%ROWTYPE;
    VS_CRE_CONTRAL_UNIT   T_BD_PARAM_LIST.DEFAULT_VALUE%TYPE; --“CRE_CONTRAL_UNIT”（控制信用单元）参数值
    VN_COUNT              NUMBER;
    VT_CREDIT_CUSTOMER_ID T_CREDIT_CUSTOMER.CREDIT_CUSTOMER_ID%TYPE;
  BEGIN
    OS_MSG := V_SUCCESS_MSG;
    SELECT *
      INTO VR_CUST_SALES_M
      FROM T_CUSTOMER_SALES_MAIN_TYPE S
     WHERE S.ENTITY_ID = IN_ENTITY_ID
       AND S.CUSTOM_ID = IN_CUSTOMER_ID
       AND S.SALES_MAIN_TYPE_CODE = IS_SALES_MAIN_TYPE_CODE;
    BEGIN
      SELECT PKG_BD.F_GET_PARAMETER_VALUE('CRE_CONTRAL_UNIT',
                                          IN_ENTITY_ID,
                                          CO.SALES_CENTER_ID,
                                          DECODE(CO.SALES_CENTER_ID,
                                                 NULL,
                                                 NULL,
                                                 IN_CUSTOMER_ID))
        INTO VS_CRE_CONTRAL_UNIT
        FROM DUAL
      --如果IN_ACCOUNT_ID大于0 关联查询到中心 通过主体、中心、客户ID获取参数 否则获取主体参数即可
        LEFT JOIN T_CUSTOMER_ACCOUNT A
          ON (0 < IN_ACCOUNT_ID AND A.ACCOUNT_ID = IN_ACCOUNT_ID AND
             A.ENTITY_ID = IN_ENTITY_ID)
        LEFT JOIN T_CUSTOMER_ACC_ORG_RELATION AR
          ON (AR.ACCOUNT_ID = A.ACCOUNT_ID)
        LEFT JOIN T_CUSTOMER_ORG CO
          ON (CO.CUSTOMER_ORG_ID = AR.CUSTOMER_ORG_ID);
    EXCEPTION
      WHEN OTHERS THEN
        VS_CRE_CONTRAL_UNIT := 'CUSTOMER';
    END;
  
    IF VS_CRE_CONTRAL_UNIT IS NULL OR VS_CRE_CONTRAL_UNIT = 'CUSTOMER' THEN
      --按客户控制信用额度
      SELECT COUNT(0), MAX(T.CREDIT_CUSTOMER_ID)
        INTO VN_COUNT, VT_CREDIT_CUSTOMER_ID
        FROM T_CREDIT_CUSTOMER T
       WHERE T.ENTITY_ID = IN_ENTITY_ID
         AND T.CUSTOMER_ID = IN_CUSTOMER_ID
         AND T.SALES_MAIN_TYPE_CODE = IS_SALES_MAIN_TYPE_CODE
         AND (T.ACCOUNT_ID IS NULL OR 0 >= T.ACCOUNT_ID); --T.ACCOUNT_ID原则上不能小于等于0
      IF 0 = VN_COUNT THEN
        SELECT S_CREDIT_CUSTOMER.NEXTVAL
          INTO VT_CREDIT_CUSTOMER_ID
          FROM DUAL;
        INSERT INTO T_CREDIT_CUSTOMER
          (CREDIT_CUSTOMER_ID,
           ENTITY_ID,
           CUSTOMER_ID,
           CUSTOMER_CODE,
           CUSTOMER_NAME,
           SALES_CENTER_IDS,
           SALES_CENTER_CODES,
           SALES_CENTER_NAMES,
           ACCOUNT_ID,
           SALES_MAIN_TYPE_CODE,
           SALES_MAIN_TYPE_NAME,
           CUSTOM_LEVEL,
           CUSTOM_CREDIT_LEVEL,
           CREDIT_LINE,
           THISYEAR_CREDIT_LINE,
           LASTYEAR_CREDIT_LINE,
           COPPER_DATE,
           TWELVE_AMOUNT,
           LASTYEAR_SALES_AMOUNT_AVG,
           THISYEAR_SALES_AMOUNT_AVG,
           THISYEAR_DELAYPAY_AVG,
           CREATED_BY,
           CREATION_DATE,
           LAST_UPDATED_BY,
           LAST_UPDATE_DATE)
        VALUES
          (VT_CREDIT_CUSTOMER_ID,
           IN_ENTITY_ID,
           IN_CUSTOMER_ID,
           VR_CUST_SALES_M.CUSTOM_CODE,
           VR_CUST_SALES_M.CUSTOMER_NAME,
           PKG_CREDIT_INTF_DUE.FUN_GET_SALES_CENTER_INTO(IN_ENTITY_ID,
                                                         IN_CUSTOMER_ID,
                                                         NULL,
                                                         1),
           PKG_CREDIT_INTF_DUE.FUN_GET_SALES_CENTER_INTO(IN_ENTITY_ID,
                                                         IN_CUSTOMER_ID,
                                                         NULL,
                                                         2),
           PKG_CREDIT_INTF_DUE.FUN_GET_SALES_CENTER_INTO(IN_ENTITY_ID,
                                                         IN_CUSTOMER_ID,
                                                         NULL,
                                                         3),
           0,
           VR_CUST_SALES_M.SALES_MAIN_TYPE_CODE,
           VR_CUST_SALES_M.SALES_MAIN_TYPE_NAME,
           VR_CUST_SALES_M.CUSTOM_LEVEL,
           VR_CUST_SALES_M.CUSTOM_CREDIT_LEVEL,
           VR_CUST_SALES_M.CREDIT_LINE,
           VR_CUST_SALES_M.THISYEAR_CREDIT_LINE,
           VR_CUST_SALES_M.LASTYEAR_CREDIT_LINE,
           VR_CUST_SALES_M.COPPER_DATE,
           VR_CUST_SALES_M.TWELVE_AMOUNT,
           VR_CUST_SALES_M.LASTYEAR_SALES_AMOUNT_AVG,
           VR_CUST_SALES_M.THISYEAR_SALES_AMOUNT_AVG,
           VR_CUST_SALES_M.THISYEAR_DELAYPAY_AVG,
           VR_CUST_SALES_M.CREATED_BY,
           VR_CUST_SALES_M.CREATION_DATE,
           VR_CUST_SALES_M.LAST_UPDATE_BY,
           VR_CUST_SALES_M.LAST_UPDATE_DATE
           --
           )
        /*FROM T_CUSTOMER_ORG O
        WHERE O.ENTITY_ID = IN_ENTITY_ID
          AND O.CUSTOMER_ID = IN_CUSTOMER_ID
        GROUP BY O.ENTITY_ID, O.CUSTOMER_ID*/
        ;
      ELSIF 1 = VN_COUNT THEN
        UPDATE T_CREDIT_CUSTOMER
           SET CUSTOMER_NAME      = VR_CUST_SALES_M.CUSTOMER_NAME,
               SALES_CENTER_IDS    = PKG_CREDIT_INTF_DUE.FUN_GET_SALES_CENTER_INTO(IN_ENTITY_ID,
                                                                                  IN_CUSTOMER_ID,
                                                                                  NULL,
                                                                                  1),
               SALES_CENTER_CODES = PKG_CREDIT_INTF_DUE.FUN_GET_SALES_CENTER_INTO(IN_ENTITY_ID,
                                                                                  IN_CUSTOMER_ID,
                                                                                  NULL,
                                                                                  2),
               SALES_CENTER_NAMES = PKG_CREDIT_INTF_DUE.FUN_GET_SALES_CENTER_INTO(IN_ENTITY_ID,
                                                                                  IN_CUSTOMER_ID,
                                                                                  NULL,
                                                                                  3),
               ACCOUNT_ID         = 0,
               --SALES_MAIN_TYPE_CODE      = VR_CUST_SALES_M.SALES_MAIN_TYPE_CODE,
               SALES_MAIN_TYPE_NAME = VR_CUST_SALES_M.SALES_MAIN_TYPE_NAME,
               CUSTOM_LEVEL         = VR_CUST_SALES_M.CUSTOM_LEVEL,
               CUSTOM_CREDIT_LEVEL  = VR_CUST_SALES_M.CUSTOM_CREDIT_LEVEL,
               COPPER_DATE          = VR_CUST_SALES_M.COPPER_DATE /*,
                               CREDIT_LINE               = VR_CUST_SALES_M.CREDIT_LINE,
                               THISYEAR_CREDIT_LINE      = VR_CUST_SALES_M.THISYEAR_CREDIT_LINE,
                               LASTYEAR_CREDIT_LINE      = VR_CUST_SALES_M.LASTYEAR_CREDIT_LINE,
                               TWELVE_AMOUNT             = VR_CUST_SALES_M.TWELVE_AMOUNT,
                               LASTYEAR_SALES_AMOUNT_AVG = VR_CUST_SALES_M.LASTYEAR_SALES_AMOUNT_AVG,
                               THISYEAR_SALES_AMOUNT_AVG = VR_CUST_SALES_M.THISYEAR_SALES_AMOUNT_AVG,
                               THISYEAR_DELAYPAY_AVG     = VR_CUST_SALES_M.THISYEAR_DELAYPAY_AVG,
                               CREATED_BY                = VR_CUST_SALES_M.CREATED_BY,
                               CREATION_DATE             = VR_CUST_SALES_M.CREATION_DATE,
                               LAST_UPDATED_BY           = VR_CUST_SALES_M.LAST_UPDATE_BY,
                               LAST_UPDATE_DATE          = VR_CUST_SALES_M.LAST_UPDATE_DATE*/
         WHERE CREDIT_CUSTOMER_ID = VT_CREDIT_CUSTOMER_ID;
      ELSE
        OS_MSG := '初始化信用额度客户信息表，出现重复记录，主体：' || IN_ENTITY_ID || '，客户ID：' ||
                  IN_CUSTOMER_ID || '，营销大类编码：' || IS_SALES_MAIN_TYPE_CODE ||
                  '，账户ID：' || IN_ACCOUNT_ID || '，控制信用单元参数值：' ||
                  VS_CRE_CONTRAL_UNIT;
      END IF;
    ELSIF 'ACCOUNT' = VS_CRE_CONTRAL_UNIT THEN
      FOR AL IN (SELECT A.ACCOUNT_ID,
                        CO.SALES_CENTER_ID,
                        CO.SALES_CENTER_CODE,
                        CO.SALES_CENTER_NAME
                   FROM T_CUSTOMER_ACCOUNT A
                   LEFT JOIN T_CUSTOMER_ACC_ORG_RELATION AR
                     ON (AR.ACCOUNT_ID = A.ACCOUNT_ID)
                   LEFT JOIN T_CUSTOMER_ORG CO
                     ON (CO.CUSTOMER_ORG_ID = AR.CUSTOMER_ORG_ID)
                  WHERE A.ENTITY_ID = IN_ENTITY_ID
                    AND A.CUSTOMER_ID = IN_CUSTOMER_ID
                    AND ((IN_ACCOUNT_ID IS NULL OR 0 >= IN_ACCOUNT_ID) OR
                        (0 < IN_ACCOUNT_ID AND A.ACCOUNT_ID = IN_ACCOUNT_ID))) LOOP
      
        SELECT COUNT(0), MAX(T.CREDIT_CUSTOMER_ID)
          INTO VN_COUNT, VT_CREDIT_CUSTOMER_ID
          FROM T_CREDIT_CUSTOMER T
         WHERE T.ENTITY_ID = IN_ENTITY_ID
           AND T.CUSTOMER_ID = IN_CUSTOMER_ID
           AND T.SALES_MAIN_TYPE_CODE = IS_SALES_MAIN_TYPE_CODE
           AND T.ACCOUNT_ID = AL.ACCOUNT_ID;
        IF 0 = VN_COUNT THEN
          SELECT S_CREDIT_CUSTOMER.NEXTVAL
            INTO VT_CREDIT_CUSTOMER_ID
            FROM DUAL;
          INSERT INTO T_CREDIT_CUSTOMER
            (CREDIT_CUSTOMER_ID,
             ENTITY_ID,
             CUSTOMER_ID,
             CUSTOMER_CODE,
             CUSTOMER_NAME,
             SALES_CENTER_IDS,
             SALES_CENTER_CODES,
             SALES_CENTER_NAMES,
             ACCOUNT_ID,
             SALES_MAIN_TYPE_CODE,
             SALES_MAIN_TYPE_NAME,
             CUSTOM_LEVEL,
             CUSTOM_CREDIT_LEVEL,
             CREDIT_LINE,
             THISYEAR_CREDIT_LINE,
             LASTYEAR_CREDIT_LINE,
             COPPER_DATE,
             TWELVE_AMOUNT,
             LASTYEAR_SALES_AMOUNT_AVG,
             THISYEAR_SALES_AMOUNT_AVG,
             THISYEAR_DELAYPAY_AVG,
             CREATED_BY,
             CREATION_DATE,
             LAST_UPDATED_BY,
             LAST_UPDATE_DATE)
          VALUES
            (VT_CREDIT_CUSTOMER_ID,
             IN_ENTITY_ID,
             IN_CUSTOMER_ID,
             VR_CUST_SALES_M.CUSTOM_CODE,
             VR_CUST_SALES_M.CUSTOMER_NAME,
             AL.SALES_CENTER_ID,
             AL.SALES_CENTER_CODE,
             AL.SALES_CENTER_NAME,
             AL.ACCOUNT_ID,
             VR_CUST_SALES_M.SALES_MAIN_TYPE_CODE,
             VR_CUST_SALES_M.SALES_MAIN_TYPE_NAME,
             VR_CUST_SALES_M.CUSTOM_LEVEL,
             VR_CUST_SALES_M.CUSTOM_CREDIT_LEVEL,
             0, --VR_CUST_SALES_M.CREDIT_LINE,
             0, --VR_CUST_SALES_M.THISYEAR_CREDIT_LINE,
             0, --VR_CUST_SALES_M.LASTYEAR_CREDIT_LINE,
             VR_CUST_SALES_M.COPPER_DATE,
             0, --VR_CUST_SALES_M.TWELVE_AMOUNT,
             0, --VR_CUST_SALES_M.LASTYEAR_SALES_AMOUNT_AVG,
             0, --VR_CUST_SALES_M.THISYEAR_SALES_AMOUNT_AVG,
             0, --VR_CUST_SALES_M.THISYEAR_DELAYPAY_AVG,
             VR_CUST_SALES_M.CREATED_BY,
             VR_CUST_SALES_M.CREATION_DATE,
             VR_CUST_SALES_M.LAST_UPDATE_BY,
             VR_CUST_SALES_M.LAST_UPDATE_DATE
             --
             );
        ELSIF 1 = VN_COUNT THEN
          UPDATE T_CREDIT_CUSTOMER
             SET CUSTOMER_NAME      = VR_CUST_SALES_M.CUSTOMER_NAME,
                 SALES_CENTER_IDS    = AL.SALES_CENTER_ID,
                 SALES_CENTER_CODES = AL.SALES_CENTER_CODE,
                 SALES_CENTER_NAMES = AL.SALES_CENTER_NAME,
                 --ACCOUNT_ID                = AL.ACCOUNT_ID,
                 --SALES_MAIN_TYPE_CODE      = VR_CUST_SALES_M.SALES_MAIN_TYPE_CODE,
                 SALES_MAIN_TYPE_NAME = VR_CUST_SALES_M.SALES_MAIN_TYPE_NAME,
                 CUSTOM_LEVEL         = VR_CUST_SALES_M.CUSTOM_LEVEL,
                 CUSTOM_CREDIT_LEVEL  = VR_CUST_SALES_M.CUSTOM_CREDIT_LEVEL,
                 COPPER_DATE          = VR_CUST_SALES_M.COPPER_DATE /*,
                                     CREDIT_LINE               = 0, --VR_CUST_SALES_M.CREDIT_LINE,
                                     THISYEAR_CREDIT_LINE      = 0, --VR_CUST_SALES_M.THISYEAR_CREDIT_LINE,
                                     LASTYEAR_CREDIT_LINE      = 0, --VR_CUST_SALES_M.LASTYEAR_CREDIT_LINE,
                                     TWELVE_AMOUNT             = 0, --VR_CUST_SALES_M.TWELVE_AMOUNT,
                                     LASTYEAR_SALES_AMOUNT_AVG = 0, --VR_CUST_SALES_M.LASTYEAR_SALES_AMOUNT_AVG,
                                     THISYEAR_SALES_AMOUNT_AVG = 0, --VR_CUST_SALES_M.THISYEAR_SALES_AMOUNT_AVG,
                                     THISYEAR_DELAYPAY_AVG     = 0, --VR_CUST_SALES_M.THISYEAR_DELAYPAY_AVG,
                                     CREATED_BY                = VR_CUST_SALES_M.CREATED_BY,
                                     CREATION_DATE             = VR_CUST_SALES_M.CREATION_DATE,
                                     LAST_UPDATED_BY           = VR_CUST_SALES_M.LAST_UPDATE_BY,
                                     LAST_UPDATE_DATE          = VR_CUST_SALES_M.LAST_UPDATE_DATE*/
           WHERE CREDIT_CUSTOMER_ID = VT_CREDIT_CUSTOMER_ID;
        ELSE
          OS_MSG := '初始化信用额度客户信息表，出现重复记录，主体：' || IN_ENTITY_ID || '，客户ID：' ||
                    IN_CUSTOMER_ID || '，营销大类编码：' || IS_SALES_MAIN_TYPE_CODE ||
                    '，账户ID：' || IN_ACCOUNT_ID || '，控制信用单元参数值：' ||
                    VS_CRE_CONTRAL_UNIT;
        END IF;
      END LOOP;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      OS_MSG := '初始化信用额度客户信息表出错！！主体：' || IN_ENTITY_ID || '，客户ID：' ||
                IN_CUSTOMER_ID || '，营销大类编码：' || IS_SALES_MAIN_TYPE_CODE ||
                '，账户ID：' || IN_ACCOUNT_ID || SUBSTR(SQLERRM, 1, 200);
  END P_CREDIT_CUSTOMER_INIT;

end PKG_CREDIT_SETTING;
/

