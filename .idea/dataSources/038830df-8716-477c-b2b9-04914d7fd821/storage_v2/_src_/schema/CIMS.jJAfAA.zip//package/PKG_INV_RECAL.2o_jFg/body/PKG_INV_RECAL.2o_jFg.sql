create PACKAGE BODY      pkg_inv_recal
IS
/******************************************************************************
   NAME:        cims.pkg_inv_recal

   PURPOSE:     重算库存现有量，对业务单据与物料历史记录按头ID+产品ID，进行产品
                数量对比，对数量有差异的记录，重新调用物料事务处理过程进行处理。

   DEPEND ON:   1.重算时业务单据和物料事务处理不能进行操作，业务单据表和物料历史
                表不能发生变化。

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        2014/8/29   lingyy          1. Created this package.
******************************************************************************/

   --重算入口过程。
   PROCEDURE p_inv_recal_main (
      in_entity_id   IN       NUMBER,                                                  --经营主体ID
      on_ret_code    OUT      NUMBER,                                              --重算结果错误码
      on_ret_desc    OUT      VARCHAR2                                           --重算结果错误描述
   )
   IS
      vd_begin_date       DATE;                                                      --重算开始时间
      vn_period_id        NUMBER;                                                  --重开会计期间ID
      vn_sequence_recal   NUMBER;                                                  --重算日志记录ID
      vn_ret_code         NUMBER;                                                --写重算日志错误码
      vn_ret_desc         VARCHAR2 (256);                                      --写重算日志错误描述
      vn_recal_status     NUMBER;                                                        --重算状态
   BEGIN
      --初始化全局变量
      p_inv_init ();

      IF g_ret_code != err_success
      THEN
         on_ret_code    := g_ret_code;
         on_ret_desc    := g_ret_desc;
         RETURN;
      END IF;

      --错误码默认初始值为0
      on_ret_code        := err_success;
      on_ret_desc        := '';
      --重算状态默认为重算成功
      vn_recal_status    := g_status_success;
      --获取重算开始时间
      p_inv_get_recal_begin_date (in_entity_id, vd_begin_date, vn_period_id);

      IF g_ret_code != err_success
      THEN
         on_ret_code    := g_ret_code;
         on_ret_desc    := g_ret_desc;
         RETURN;
      END IF;

      --事物一致性控制：加锁
      p_inv_recal_lock (in_entity_id, vn_sequence_recal);
      COMMIT;

      IF g_ret_code != err_success
      THEN
         on_ret_code        := g_ret_code;
         on_ret_desc        := g_ret_desc;
         vn_recal_status    := g_status_fail;
         RETURN;
      END IF;

      p_inv_recal_all (in_entity_id, vd_begin_date, vn_sequence_recal);

      IF g_ret_code != err_success
      THEN
         on_ret_code        := g_ret_code;
         on_ret_desc        := g_ret_desc;
         vn_recal_status    := g_status_fail;
      /*del by lingyy 2015-01-02 屏蔽对业务单据、月度收发存，对现有量进行重算的功能
      ELSE
         p_inv_recal_onhand (in_entity_id, vd_begin_date, vn_period_id);

         IF g_ret_code != err_success
         THEN
            on_ret_code := g_ret_code;
            on_ret_desc := g_ret_desc;
            vn_recal_status := g_status_fail;
         END IF;
         del end*/
      END IF;

      --事务一致性控制：解锁
      p_inv_recal_unlock (in_entity_id, vn_sequence_recal, vn_recal_status, vn_ret_code,
                          vn_ret_desc);

      IF vn_ret_code != err_success
      THEN
         on_ret_code    := vn_ret_code;
         on_ret_desc    := vn_ret_desc;
      END IF;

      COMMIT;
   END;

   PROCEDURE p_inv_init
   IS
   BEGIN
      err_success                     := 0;                                                  --成功
      g_ret_code                      := err_success;                                      --错误码
      g_ret_desc                      := '';                                             --错误描述
      g_recal_quanlity                := 0;                                    --重算的业务单据数量
      g_not_have_id                   := 0;                              --表中不存在头ID对应的记录
      g_have_id                       := 1;                                --表中存在头ID对应的记录
      g_status_success                := 0;                                              --重算成功
      g_status_not_beign              := 1;                                            --重算未开赛
      g_status_recaling               := 2;                                                --重算中
      g_status_fail                   := 3;                                              --重算失败
      --业务逻辑异常
      err_bus_have_recal_proc         := 1001;                             --存在正在运行的重算过程
      err_bus_get_begin_date_fail     := 1002;                                   --获取重算时间失败
      err_bus_no_id                   := 1003;                           --表中不存在头ID对应的记录
      --系统异常
      err_sys_lock                    := -1001;                            --事务一致性控制加锁异常
      err_sys_unlock                  := -1002;                            --事务一致性控制解锁异常
      err_sys_begin_date              := -1003;                              --获取重算开始时间异常
      err_sys_recal_so                := -1004;                                    --重算销售单异常
      err_sys_recal_po                := -1005;                                    --重算采购单异常
      err_sys_recal_trsf              := -1006;                                    --重算调拨单异常
      err_sys_recal_check             := -1007;                                    --重算盘点单异常
      err_sys_recal_stockup           := -1008;                                    --重算备货单异常
      err_sys_recal_send              := -1009;                                --重算领用发放单异常
      err_sys_update_so               := -1010;                                    --更新销售单异常
      err_sys_update_po               := -1011;                                    --更新采购单异常
      err_sys_update_trsf             := -1012;                                    --更新调拨单异常
      err_sys_update_check            := -1013;                                    --更新盘点单异常
      err_sys_update_stockup          := -1014;                                    --更新备货单异常
      err_sys_update_send             := -1015;                                --更新领用发放单异常
      err_sys_recal_history           := -1016;                                    --写重算日志异常
      err_sys_inv_init                := -1017;                                        --初始化异常
      err_sys_exec_update             := -1018;                          --调用物料历史记录处理异常
      err_sys_update_all              := -1019;                                    --更新现有量异常
      err_sys_recal_all               := -1020;                          --重算物料事物历史记录异常
      err_sys_recal_onhand            := -1021;                                    --重算现有量异常
     
   EXCEPTION
      WHEN OTHERS
      THEN
         g_ret_code    := err_sys_inv_init;
         g_ret_desc    := SQLCODE || ' ' || SQLERRM;
   END;

--事务一致性控制：加锁
   PROCEDURE p_inv_recal_lock (
      in_entity_id        IN       NUMBER,                                              --经营主体ID
      in_sequence_recal   OUT      NUMBER                                           --重算日志记录ID
   )
   IS
      vd_cnt              NUMBER;
      vn_sequence_recal   NUMBER;
   BEGIN
      g_ret_code           := err_success;
      g_ret_desc           := '';

      SELECT COUNT (recal_id)
        INTO vd_cnt
        FROM t_inv_recal_history
       WHERE status = g_status_recaling AND entity_id = in_entity_id;

      vn_sequence_recal    := s_inv_recalculation_history.NEXTVAL;

      --判断是否存在正在运行的重算过程。
      IF vd_cnt > 0
      THEN
         --存在，则返回。
         g_ret_code    := err_bus_have_recal_proc;
         g_ret_desc    := '存在正在运行的重算过程！';
         RETURN;
      END IF;

      --记重算日志，并置重算状态为g_status_recaling,表示正在重算
      INSERT INTO t_inv_recal_history
                  (entity_id, recal_id, status, quanlity, begin_date, end_date, recal_ret_code,
                   recal_ret_desc, program_updated_by, program_update_date
                  )
           VALUES (in_entity_id, vn_sequence_recal, g_status_recaling, NULL, SYSDATE, NULL, NULL,
                   NULL, 'PKG_INV_RECAL', SYSDATE
                  );

      --返回，该条重算日志的序列号。
      in_sequence_recal    := vn_sequence_recal;
   EXCEPTION
      WHEN OTHERS
      THEN
         g_ret_code    := err_sys_lock;
         g_ret_desc    := SQLCODE || ' ' || SQLERRM;
   END;

--事务一致性控制：解锁
   PROCEDURE p_inv_recal_unlock (
      in_entity_id        IN       NUMBER,                                              --经营主体ID
      in_sequence_recal   IN       NUMBER,                                          --重算日志记录ID
      in_status           IN       NUMBER,
      --重算结果标识 0:重算成功 1：未开始 2：重算中 3：重算失败
      on_ret_code         OUT      NUMBER,                                                  --错误码
      on_ret_desc         OUT      VARCHAR2                                               --错误描述
   )
   IS
   BEGIN
      on_ret_code    := err_success;
      on_ret_desc    := '';

      UPDATE t_inv_recal_history
         SET status = in_status,
             quanlity = g_recal_quanlity,
             end_date = SYSDATE,
             recal_ret_code = g_ret_code,
             recal_ret_desc = g_ret_desc,
             program_updated_by = 'PKG_INV_RECAL',
             program_update_date = SYSDATE
       WHERE entity_id = in_entity_id AND recal_id = in_sequence_recal;
   EXCEPTION
      WHEN OTHERS
      THEN
         on_ret_code    := err_sys_unlock;
         on_ret_desc    := SQLCODE || ' ' || SQLERRM;
   END;

--获取重算开始时间
   PROCEDURE p_inv_get_recal_begin_date (
      in_entity_id    IN       NUMBER,                                                  --经营主体ID
      od_begin_date   OUT      DATE,                                                  --重算开始时间
      on_period_id    OUT      NUMBER                                                 --重算会计期间
   )
   IS
   BEGIN
      g_ret_code       := err_success;
      g_ret_desc       := '';
      od_begin_date    := NULL;
      on_period_id     := NULL;

      --获取最远一条期间状态为打开，结账标识为未结账的记录，取其开始时间为重算开始时间
      SELECT begin_date, period_id
        INTO od_begin_date, on_period_id
        FROM t_inv_inventory_periods
       WHERE begin_date =
                        (SELECT MIN (begin_date)
                           FROM t_inv_inventory_periods
                          WHERE status = '01' AND checkout_flag = '00' AND entity_id = in_entity_id) and entity_id=in_entity_id;

      IF od_begin_date IS NULL OR on_period_id IS NULL
      THEN
         g_ret_code    := err_bus_get_begin_date_fail;
         g_ret_desc    :=
            '不存在期间状态为打开(STATUS=01),结账标识为未结账(CHECKOUT_FLAG=00)的会计期间！无法获取重算开始时间！';
         RETURN;
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         g_ret_code    := err_sys_begin_date;
         g_ret_desc    := SQLCODE || ' ' || SQLERRM;
   END;

--写重算历史记录
   PROCEDURE p_inv_recal_history (
      in_entity_id        IN       NUMBER,                                              --经营主体ID
      in_sequence_recal   IN       NUMBER,                                          --重算日志记录ID
      in_head_id          IN       NUMBER,                                            --业务单据头ID
      in_bill_state       IN       VARCHAR2,                                              --单据状态
      is_bill_kind        IN       VARCHAR2,
--B1（采购中转）、B2（仓库调拨）、B3（仓库盘点）、B4（销售）、B5（推广物料）、B6（备货转销售）
      on_ret_code         OUT      NUMBER,                                                  --错误码
      on_ret_desc         OUT      VARCHAR2                                               --错误描述
   )
   IS
      vd_cnt   NUMBER;
   BEGIN
      on_ret_code    := err_success;
      on_ret_desc    := '';
      vd_cnt         := 0;

      SELECT COUNT (entity_id)
        INTO vd_cnt
        FROM t_inv_recal_detail_history
       WHERE entity_id = in_entity_id
         AND recal_id = in_sequence_recal
         AND head_id = in_head_id
         AND bill_kind = is_bill_kind
         AND bill_state = in_bill_state;

      IF vd_cnt = 0
      THEN
         INSERT INTO t_inv_recal_detail_history
                     (entity_id, recal_id, head_id, bill_kind, bill_state,
                      begin_date, end_date, inv_ret_code, inv_ret_desc, program_updated_by,
                      program_update_date
                     )
              VALUES (in_entity_id, in_sequence_recal, in_head_id, is_bill_kind, in_bill_state,
                      SYSDATE, NULL, NULL, NULL, 'PKG_INV_RECAL',
                      SYSDATE
                     );
      ELSE
         UPDATE t_inv_recal_detail_history
            SET end_date = SYSDATE,
                inv_ret_code = g_ret_code,
                inv_ret_desc = g_ret_desc,
                program_updated_by = 'PKG_INV_RECAL',
                program_update_date = SYSDATE
          WHERE entity_id = in_entity_id
            AND recal_id = in_sequence_recal
            AND head_id = in_head_id
            AND bill_kind = is_bill_kind
            AND bill_state = in_bill_state;
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         on_ret_code    := err_sys_recal_history;
         on_ret_desc    := SQLCODE || ' ' || SQLERRM;
   END;

   PROCEDURE p_inv_recal_all (
      in_entity_id        IN   NUMBER,                                                  --经营主体ID
      id_begin_date       IN   DATE,                                                  --重算开始时间
      in_sequence_recal   IN   NUMBER                                               --重算日志记录ID
   )
   IS
      CURSOR c_head
      IS
         --重算获取数量不一致的业务单据头ID
         SELECT DISTINCT header_id, bill_type_id
                    FROM (SELECT   entity_id, header_id, bill_type_id, item_id, SUM (quanlity)
                              FROM (
                                    --销售单
                                    SELECT h.entity_id, h.so_header_id header_id, h.bill_type_id,
                                           d.component_id item_id,
                                             ABS (d.component_qty)
                                           * (  (CASE
                                                    --制单日期大于重算开始日期，表示在重算区间内，产生了2笔物料事务
                                                 WHEN h.so_date >= id_begin_date
                                                 AND (h.so_status IN ('10', '11', '12'))
                                                 AND ( 
                                                     (h.Biz_Src_Bill_Type_Code = '1001' and h.middle_inv_id<>h.ship_inv_id)
                                                   or(h.Biz_Src_Bill_Type_Code = '1002' and h.middle_inv_id<>h.nosettled_inventory_id)
                                                   or(h.Biz_Src_Bill_Type_Code = '1003' and h.middle_inv_id<>h.nosettled_inventory_id)
                                                   or(h.Biz_Src_Bill_Type_Code = '1004' and h.middle_inv_id<>h.CONSIGNEE_INV_ID)
                                                 )
                                                 THEN f_get_trans_record (in_entity_id,
                                                                                h.bill_type_id,
                                                                                '10'
                                                                               )
                                                    ELSE 0
                                                 END
                                                )
                                              + (CASE
                                                    --审核日期大于重算开始日期，表示在重算区间内，产生了1笔物料事务
                                                 WHEN h.audit_date >= id_begin_date
                                                 AND h.audit_flag = 'Y'
                                                       THEN f_get_trans_record (in_entity_id,
                                                                                h.bill_type_id,
                                                                                '11'
                                                                               )
                                                    ELSE 0
                                                 END
                                                )
                                              + (CASE
                                                    --结算日期大于重算开始日期，表示在重算区间内，产生了1笔物料事务
                                                 WHEN h.settle_date >= id_begin_date
                                                 AND h.settle_flag = 'Y'
                                                       THEN f_get_trans_record (in_entity_id,
                                                                                h.bill_type_id,
                                                                                '12'
                                                                               )
                                                    ELSE 0
                                                 END
                                                )
                                                
                                               +(CASE
                                                    --制单日期大于重算开始日期，表示在重算区间内，产生了2笔物料事务
                                                 WHEN h.erp_logist_receive_date >= id_begin_date
                                                 AND h.erp_logist_receive_flag ='Y' 
                                                 AND ( 
                                                     (h.Biz_Src_Bill_Type_Code = '1001' and h.middle_inv_id<>h.nosettled_inventory_id)
                                                   or(h.Biz_Src_Bill_Type_Code = '1002' and h.middle_inv_id<>h.ship_inv_id)
                                                   or(h.Biz_Src_Bill_Type_Code = '1003' and h.middle_inv_id<>h.consignee_inv_id)
                                                   or(h.Biz_Src_Bill_Type_Code = '1004' and h.middle_inv_id<>h.nosettled_inventory_id)
                                                 )
                                                 THEN f_get_trans_record (in_entity_id,
                                                                                h.bill_type_id,
                                                                                '30'
                                                                               )
                                                    ELSE 0
                                                 END
                                                ) 
                                                
                                             ) quanlity
                                      FROM t_so_header h, t_so_line l, t_so_line_detail d
                                     WHERE h.so_header_id = l.so_header_id
                                       AND l.so_line_id = d.so_line_id
                                       AND h.entity_id = l.entity_id
                                       AND l.entity_id = d.entity_id
                                       AND (   h.so_date >= id_begin_date
                                            OR h.settle_date >= id_begin_date
                                            OR h.audit_date >= id_begin_date
                                           )
                                       AND h.entity_id = in_entity_id
                                    UNION ALL
                                    --采购单
                                    SELECT h.entity_id, h.po_id header_id,
                                           h.po_type_id bill_type_id, l.item_id,
                                             ABS (l.billed_qty)
                                           * (  (CASE
                                                    --制单日期大于重算开始日期，表示在重算区间内，产生了1笔物料事物
                                                 WHEN h.billed_date >= id_begin_date
                                                 AND h.po_status IN ('10', '21', '14')
                                                       THEN f_get_trans_record (in_entity_id,
                                                                                h.po_type_id,
                                                                                '10'
                                                                               )
                                                    ELSE 0
                                                 END
                                                )
                                              + (CASE
                                                    --已发货日期大于重算开始日期，表示在重算区间内，产生了1笔物料事物
                                                 WHEN h.ship_date >= id_begin_date
                                                 AND h.po_status IN ('21', '14')
                                                       THEN f_get_trans_record (in_entity_id,
                                                                                h.po_type_id,
                                                                                '21'
                                                                               )
                                                    ELSE 0
                                                 END
                                                )
                                              + (CASE
                                                    --已执行日期大于重算开始日期，表示在重算区间内，产生了1笔物料事物
                                                 WHEN h.exec_date >= id_begin_date
                                                 AND h.po_status = '14'
                                                       THEN f_get_trans_record (in_entity_id,
                                                                                h.po_type_id,
                                                                                '14'
                                                                               )
                                                    ELSE 0
                                                 END
                                                )
                                             ) quanlity
                                      FROM t_inv_po_headers h, t_inv_po_lines l
                                     WHERE h.po_id = l.po_id
                                       AND (   h.exec_date >= id_begin_date
                                            OR h.billed_date >= id_begin_date
                                            OR h.ship_date >= id_begin_date
                                           )
                                       AND h.entity_id = in_entity_id
                                    UNION ALL
                                    --调拨单
                                    SELECT h.entity_id, h.trsf_order_id header_id, h.bill_type_id,
                                           d.item_id item_id,
                                             ABS (d.billed_qty)
                                           * (  (CASE
                                                    --已制单日期大于重算开始日期，表示在重算区间内，产生了2笔物料事物
                                                 WHEN TRUNC (h.creation_date) >= id_begin_date
                                                 AND trsf_order_status IN ('10', '11', '13')
                                                       THEN f_get_trans_record (in_entity_id,
                                                                                h.bill_type_id,
                                                                                '10'
                                                                               )
                                                    ELSE 0
                                                 END
                                                )
                                              + (CASE
                                                    --已审核日期大于重算开始日期，表示在重算区间内，产生了2笔物料事物
                                                 WHEN h.audit_date >= id_begin_date
                                                 AND h.audit_flag = '1'
                                                       THEN f_get_trans_record (in_entity_id,
                                                                                h.bill_type_id,
                                                                                '11'
                                                                               )
                                                    ELSE 0
                                                 END
                                                )
                                              + (CASE
                                                    --已接收日期大于重算开始日期，表示在重算区间内，产生了2笔物料事物
                                                 WHEN h.rcv_date >= id_begin_date
                                                 AND h.rcv_flag = '1'
                                                       THEN f_get_trans_record (in_entity_id,
                                                                                h.bill_type_id,
                                                                                '13'
                                                                               )
                                                    ELSE 0
                                                 END
                                                )
                                             ) quanlity
                                      FROM t_inv_trsf_order h,
                                           t_inv_trsf_order_line l,
                                           t_inv_trsf_order_line_detail d
                                     WHERE h.trsf_order_id = l.trsf_order_id
                                       AND l.trsf_order_line_id = d.trsf_order_line_id
                                       AND h.entity_id = l.entity_id
                                       AND l.entity_id = d.entity_id
                                       AND (   h.audit_date >= id_begin_date
                                            OR h.rcv_date >= id_begin_date
                                            OR TRUNC (h.creation_date) >= id_begin_date
                                           )
                                       AND h.entity_id = in_entity_id
                                    UNION ALL
                                    --盘点单
                                    SELECT h.entity_id entity_id, h.check_order_id header_id,
                                           h.check_order_type_id bill_type_id, l.item_id,
                                             ABS (l.billed_qty)
                                           * (  (CASE
                                                    --制单日期大于重算开始日期，表示在重算区间内，产生了1笔物料事物
                                                 WHEN h.doc_date >= id_begin_date
                                                 AND h.po_status IN ('10', '14')
                                                       THEN f_get_trans_record
                                                                             (in_entity_id,
                                                                              h.check_order_type_id,
                                                                              '10'
                                                                             )
                                                    ELSE 0
                                                 END
                                                )
                                              + (CASE
                                                    --已执行日期大于重算开始日期，表示在重算区间内，产生了1笔物料事物
                                                 WHEN h.exec_date >= id_begin_date
                                                 AND h.po_status = '14'
                                                       THEN f_get_trans_record
                                                                             (in_entity_id,
                                                                              h.check_order_type_id,
                                                                              '14'
                                                                             )
                                                    ELSE 0
                                                 END
                                                )
                                             ) quanlity
                                      FROM t_inv_check_orders h, t_inv_check_order_lines l
                                     WHERE h.check_order_id = l.check_order_id
                                       AND (   h.exec_date >= id_begin_date
                                            OR h.doc_date >= id_begin_date
                                           )
                                       AND h.entity_id = l.entity_id
                                       AND h.entity_id = in_entity_id
                                    UNION ALL
                                    --备货单
                                    SELECT h.entity_id, h.stockup_order_id header_id,
                                           h.stockup_order_type_id bill_type_id, l.item_id item_id,
                                             ABS (l.billed_qty)
                                           * (  (CASE
                                                    --已审核日期大于重算开始日期，表示在重算区间内，产生了2笔物料事物
                                                 WHEN TRUNC (h.creation_date) >= id_begin_date
                                                 AND h.stockup_order_status IN ('10', '11', '13')
                                                       THEN f_get_trans_record
                                                                           (in_entity_id,
                                                                            h.stockup_order_type_id,
                                                                            '10'
                                                                           )
                                                    ELSE 0
                                                 END
                                                )
                                              + (CASE
                                                    --已审核日期大于重算开始日期，表示在重算区间内，产生了2笔物料事物
                                                 WHEN h.check_date >= id_begin_date
                                                 AND h.check_flag = '1'
                                                       THEN f_get_trans_record
                                                                           (in_entity_id,
                                                                            h.stockup_order_type_id,
                                                                            '11'
                                                                           )
                                                    ELSE 0
                                                 END
                                                )
                                              + (CASE
                                                    --已接收日期大于重算开始日期，表示在重算区间内，产生了2笔物料事物
                                                 WHEN h.rcv_date >= id_begin_date
                                                 AND h.rev_flag = '1'
                                                       THEN f_get_trans_record
                                                                           (in_entity_id,
                                                                            h.stockup_order_type_id,
                                                                            '13'
                                                                           )
                                                    ELSE 0
                                                 END
                                                )
                                             ) quanlity
                                      FROM t_inv_stockup_order h, t_inv_stockup_order_line l
                                     WHERE h.stockup_order_id = l.stockup_order_id
                                       AND h.entity_id = l.entity_id
                                       AND (   h.check_date >= id_begin_date
                                            OR h.rcv_date >= id_begin_date
                                            OR TRUNC (h.creation_date) >= id_begin_date
                                           )
                                       AND h.entity_id = in_entity_id
                                    /*
                                    UNION ALL
                                        --领用发放单
                                    */
                                    UNION ALL
                                    --按实体ID+头ID+产品ID，求数量和。-1*，以便和业务单据的数量进行减法操作，差额不为0，即是需要重算的单据。
                                    SELECT   entity_id, business_header_id header_id, bill_type_id,
                                             item_id, -1 * SUM (quantity) quantity
                                        FROM (
                                              --按实体ID+头ID+仓库ID+产品ID+单据状态，求出每笔物料记录，及每笔物料记录对应的产品数量。
                                              --这里的GROUP BY，主要是为了将每笔物料记录及其系统红冲的记录，合并成一条物料记录。
                                              --对数量的ABS，是因为数量带正负号，需要统一为正数。
                                              SELECT   entity_id, business_header_id, bill_type_id,
                                                       inventory_id, item_id, business_state,
                                                       ABS (SUM (transaction_quantity)) quantity
                                                  FROM t_inv_transaction_history
                                                 WHERE transaction_date >= id_begin_date
                                                   AND entity_id = in_entity_id
                                              GROUP BY entity_id,
                                                       business_header_id,
                                                       bill_type_id,
                                                       inventory_id,
                                                       item_id,
                                                       business_state)
                                    GROUP BY entity_id, business_header_id, bill_type_id, item_id)
                          GROUP BY entity_id, header_id, bill_type_id, item_id
                            HAVING SUM (quanlity) != 0                            --数量不一致的数据
                                                      );

      c_head_row   c_head%ROWTYPE;
   BEGIN
      g_ret_code    := err_success;
      g_ret_desc    := '';

      FOR c_head_row IN c_head
      LOOP
         p_inv_update_all (in_entity_id,
                           c_head_row.header_id,
                           c_head_row.bill_type_id,
                           id_begin_date,
                           in_sequence_recal
                          );
      END LOOP;
   EXCEPTION
      WHEN OTHERS
      THEN
         g_ret_code    := err_sys_recal_all;
         g_ret_desc    := SQLCODE || ' ' || SQLERRM;
   END;

   PROCEDURE p_inv_recal_onhand (
      in_entity_id    IN   NUMBER,                                                      --经营主体ID
      id_begin_date   IN   DATE,                                                      --重算开始时间
      in_period_id    IN   NUMBER                                                   --重算会计期间ID
   )
   IS
   BEGIN
      g_ret_code    := err_success;
      g_ret_desc    := '';
      MERGE INTO t_inv_onhand c
         USING (SELECT b.inventory_id, b.item_id, NVL (a.qty_lm, 0) + b.quantity quantity,
                       b.transaction_uom, b.transaction_id, b.creation_date
                  FROM (SELECT *
                          FROM t_inv_monthsum
                         WHERE period_id = in_period_id and entity_id=in_entity_id) a,
                       (SELECT   inventory_id, item_id, SUM (transaction_quantity) quantity,
                                 MAX (transaction_uom) transaction_uom,
                                 MAX (transaction_id) transaction_id,
                                 MIN (creation_date) creation_date
                            FROM t_inv_transaction_history
                           WHERE entity_id = in_entity_id AND transaction_date >= id_begin_date
                        GROUP BY inventory_id, item_id) b
                 WHERE b.inventory_id = a.inventory_id(+) AND b.item_id = a.item_id(+)) d
         ON (c.entity_id = in_entity_id AND c.inventory_id = d.inventory_id
             AND c.item_id = d.item_id)
         WHEN MATCHED THEN
            UPDATE
               SET c.quantity = d.quantity, c.last_updated_by = 'RECAL',
                   c.last_update_date = SYSDATE
               WHERE c.quantity != d.quantity
         WHEN NOT MATCHED THEN
            INSERT (entity_id, inv_id, inventory_id, item_id, transaction_uom, quantity,
                    last_transaction_id, date_received, created_by, creation_date, last_updated_by,
                    last_update_date, remark)
            VALUES (in_entity_id, s_inv_current_inventory.NEXTVAL, d.inventory_id, d.item_id,
                    d.transaction_uom, d.quantity, d.transaction_id, d.creation_date, 'RECAL',
                    d.creation_date, 'RECAL', d.creation_date, NULL);
   EXCEPTION
      WHEN OTHERS
      THEN
         g_ret_code    := err_sys_recal_onhand;
         g_ret_desc    := SQLCODE || ' ' || SQLERRM;
   END;

   PROCEDURE p_inv_exec_update (
      in_entity_id          IN   NUMBER,                                                --经营主体ID
      in_head_id            IN   NUMBER,                                              --业务单据头ID
      in_sequence_recal     IN   NUMBER,                                            --重算日志记录ID
      in_bill_type_id       IN   NUMBER,                                                --单据类型ID
      in_if_null            IN   NUMBER,                              --是否是空的业务单据，0否，1是
      is_business_state     IN   t_inv_transaction_history.business_state%TYPE,
      --单据状态
      id_transaction_date   IN   t_inv_transaction_history.transaction_date%TYPE,
      --业务日期
      is_bill_kind          IN   VARCHAR2
--B1（采购中转）、B2（仓库调拨）、B3（仓库盘点）、B4（销售）、B5（推广物料）、B6（备货转销售）
   )
   IS
      vn_ret_code   NUMBER;
      vn_ret_desc   VARCHAR2 (256);
   BEGIN
      g_ret_code          := err_success;
      g_ret_desc          := '';
      vn_ret_code         := err_success;
      vn_ret_desc         := '';
      p_inv_recal_history (in_entity_id,
                           in_sequence_recal,
                           in_head_id,
                           is_bill_kind,
                           is_business_state,
                           vn_ret_code,
                           vn_ret_desc
                          );

      IF vn_ret_code != err_success
      THEN
         g_ret_code    := vn_ret_code;
         g_ret_desc    := vn_ret_desc;
         RETURN;
      END IF;

      SAVEPOINT exec_update;
      pkg_inv_transaction.inv_transaction_total_deal (in_entity_id,
                                                      in_bill_type_id,
                                                      is_business_state,
                                                      id_transaction_date,
                                                      in_head_id,
                                                      in_if_null,
                                                      is_bill_kind,
                                                      vn_ret_code,
                                                      vn_ret_desc
                                                     );

      IF vn_ret_code != err_success
      THEN
         g_ret_code    := vn_ret_code;
         g_ret_desc    := vn_ret_desc;
         ROLLBACK TO exec_update;
      END IF;

      p_inv_recal_history (in_entity_id,
                           in_sequence_recal,
                           in_head_id,
                           is_bill_kind,
                           is_business_state,
                           vn_ret_code,
                           vn_ret_desc
                          );

      IF vn_ret_code != err_success
      THEN
         g_ret_code    := vn_ret_code;
         g_ret_desc    := vn_ret_desc;
         RETURN;
      END IF;

      --累计重算的业务单据数量
      g_recal_quanlity    := g_recal_quanlity + 1;
   EXCEPTION
      WHEN OTHERS
      THEN
         g_ret_code    := err_sys_exec_update;
         g_ret_desc    := SQLCODE || ' ' || SQLERRM;
   END;

   PROCEDURE p_inv_update_all (
      in_entity_id        IN   NUMBER,                                                  --经营主体ID
      in_head_id          IN   NUMBER,                                                --业务单据头ID
      in_bill_type_id     IN   NUMBER,                                              --业务单据类型ID
      id_begin_date       IN   DATE,                                                  --重算开始时间
      in_sequence_recal   IN   NUMBER                                               --重算日志记录ID
   )
   IS
      vn_have_id          NUMBER;
      vs_bill_type_code   VARCHAR2 (100);
   BEGIN
      g_ret_code    := err_success;
      g_ret_desc    := '';
      vn_have_id    := g_not_have_id;

      SELECT bill_type_code
        INTO vs_bill_type_code
        FROM t_inv_bill_types
       WHERE bill_type_id = in_bill_type_id;

      --销售单
      p_inv_update_so (in_entity_id,
                       in_head_id,
                       in_bill_type_id,
                       id_begin_date,
                       in_sequence_recal,
                       vn_have_id
                      );

      IF vn_have_id = g_have_id OR g_ret_code != err_success
      THEN
         RETURN;
      END IF;

      --采购单
      p_inv_update_po (in_entity_id,
                       in_head_id,
                       in_bill_type_id,
                       id_begin_date,
                       in_sequence_recal,
                       vn_have_id
                      );

      IF vn_have_id = g_have_id OR g_ret_code != err_success
      THEN
         RETURN;
      END IF;

      --调拨单
      p_inv_update_trsf (in_entity_id,
                         in_head_id,
                         in_bill_type_id,
                         id_begin_date,
                         in_sequence_recal,
                         vn_have_id
                        );

      IF vn_have_id = g_have_id OR g_ret_code != err_success
      THEN
         RETURN;
      END IF;

      --盘点单
      p_inv_update_check (in_entity_id,
                          in_head_id,
                          in_bill_type_id,
                          id_begin_date,
                          in_sequence_recal,
                          vn_have_id
                         );

      IF vn_have_id = g_have_id OR g_ret_code != err_success
      THEN
         RETURN;
      END IF;

      --备货单
      p_inv_update_stockup (in_entity_id,
                            in_head_id,
                            in_bill_type_id,
                            id_begin_date,
                            in_sequence_recal,
                            vn_have_id
                           );

      IF vn_have_id = g_have_id OR g_ret_code != err_success
      THEN
         RETURN;
      END IF;

      --推广物料单
      p_inv_update_send (in_entity_id,
                         in_head_id,
                         in_bill_type_id,
                         id_begin_date,
                         in_sequence_recal,
                         vn_have_id
                        );

      IF vn_have_id = g_have_id OR g_ret_code != err_success
      THEN
         RETURN;
      END IF;

        /*
      --业务单据中没有，物料历史记录表中有
      p_inv_update_null (in_entity_id,
                         in_head_id,
                         id_begin_date,
                         in_sequence_recal,
                         in_bill_type_id,
                         vn_have_id
                        );

      IF vn_have_id = g_have_id OR g_ret_code != err_success
      THEN
         RETURN;
      END IF;

      g_ret_code := err_bus_no_id;
      g_ret_desc :=
            '在业务单据表和物料记录历史表中，都找不到头ID为:'
         || in_head_id
         || '单据类型为:'
         || in_bill_type_id
         || '的记录！';
         */
      g_ret_code    := err_bus_no_id;
      g_ret_desc    :=
            '存在业务单据中没有，但物料记录历史表中有的单据记录(单据头ID：'
         || in_head_id
         || ')单据类型为:'
         || in_bill_type_id
         || '。请手动排查相关记录产生原因，并做处理！';
   EXCEPTION
      WHEN OTHERS
      THEN
         g_ret_code    := err_sys_update_all;
         g_ret_desc    := SQLCODE || ' ' || SQLERRM;
   END;

--更新销售单现有量
   PROCEDURE p_inv_update_so (
      in_entity_id        IN       NUMBER,                                              --经营主体ID
      in_head_id          IN       NUMBER,                                            --业务单据头ID
      in_bill_type_id     IN       NUMBER,                                          --业务单据类型ID
      id_begin_date       IN       DATE,                                              --重算开始时间
      in_sequence_recal   IN       NUMBER,                                          --重算日志记录ID
      in_have_id          OUT      NUMBER                           --是否存在业务单据头ID对应的记录
   )
   IS
      vn_bill_type_id       t_so_header.bill_type_id%TYPE;                             --单据类型ID
      vd_so_date            t_so_header.so_date%TYPE;                                    --制单日期
      vd_settle_date        t_so_header.settle_date%TYPE;                                --结算日期
      vd_cnt                NUMBER;
      vs_settle_flag        t_so_header.settle_flag%TYPE;                                --结算标识
      vd_audit_date         t_so_header.audit_date%TYPE;                                 --审核日期
      vs_audit_flag         t_so_header.settle_flag%TYPE;                                --审核标识
      --单据行或明细的数量，用以判断是否为空单。
      vn_if_null            NUMBER;                                  --是否是空的业务单据，0否，1是
      vs_business_state     t_inv_transaction_history.business_state%TYPE;
      --单据状态
      vd_transaction_date   t_inv_transaction_history.transaction_date%TYPE;
      --业务日期
      vs_bill_kind          VARCHAR2 (32);
--B1（采购中转）、B2（仓库调拨）、B3（仓库盘点）、B4（销售）、B5（推广物料）、B6（备货转销售）
      vs_so_status          t_so_header.so_status%TYPE;
      
      vs_receive_flag       varchar2 (32);
      vd_receive_date       t_so_header.erp_logist_receive_date%type;
      
      
   BEGIN
      g_ret_code      := err_success;
      g_ret_desc      := '';
      in_have_id      := g_not_have_id;
      vd_cnt          := 0;
      vn_if_null      := 0;
      vs_so_status    := NULL;

      SELECT COUNT (h.so_header_id)
        INTO vd_cnt
        FROM t_so_header h
       WHERE h.so_header_id = in_head_id
         AND entity_id = in_entity_id
         AND h.bill_type_id = in_bill_type_id;

      IF vd_cnt = 0
      THEN
         in_have_id    := g_not_have_id;
         RETURN;
      ELSE
         in_have_id      := g_have_id;
         vs_bill_kind    := 'B4';                                                          --销售单

         SELECT h.bill_type_id, h.so_date, h.settle_date, h.settle_flag, h.so_status,
                h.audit_date, h.audit_flag,h.erp_logist_receive_flag,h.erp_logist_receive_date
           INTO vn_bill_type_id, vd_so_date, vd_settle_date, vs_settle_flag, vs_so_status,
                vd_audit_date, vs_audit_flag,vs_receive_flag,vd_receive_date
           FROM t_so_header h
          WHERE h.so_header_id = in_head_id AND entity_id = in_entity_id;

         SELECT COUNT (h.so_header_id)
           INTO vd_cnt
           FROM t_so_header h, t_so_line l, t_so_line_detail d
          WHERE h.so_header_id = l.so_header_id
            AND l.so_line_id = d.so_line_id
            AND h.entity_id = l.entity_id
            AND l.entity_id = d.entity_id
            AND h.entity_id = in_entity_id;

         IF vd_cnt = 0
         THEN
            vn_if_null    := 1;
         ELSE
            vn_if_null    := 0;
         END IF;

         --制单
         IF     vd_so_date >= id_begin_date
            AND vs_so_status IN ('10', '11', '12')
            AND f_get_trans_record (in_entity_id, in_bill_type_id, '10') > 0
         THEN
            vd_transaction_date    := vd_so_date;
            vs_business_state      := '10';
            p_inv_exec_update (in_entity_id,
                               in_head_id,
                               in_sequence_recal,
                               vn_bill_type_id,
                               vn_if_null,
                               vs_business_state,
                               vd_transaction_date,
                               vs_bill_kind
                              );

            IF g_ret_code != err_success
            THEN
               RETURN;
            END IF;
         END IF;

         --已审核
         IF     vd_audit_date >= id_begin_date
            AND vs_audit_flag = 'Y'
            AND f_get_trans_record (in_entity_id, in_bill_type_id, '11') > 0
         THEN
            vd_transaction_date    := vd_audit_date;
            vs_business_state      := '11';
            p_inv_exec_update (in_entity_id,
                               in_head_id,
                               in_sequence_recal,
                               vn_bill_type_id,
                               vn_if_null,
                               vs_business_state,
                               vd_transaction_date,
                               vs_bill_kind
                              );

            IF g_ret_code != err_success
            THEN
               RETURN;
            END IF;
         END IF;
         
         
         --已PO接收
         IF     vd_receive_date >= id_begin_date
            AND vs_receive_flag = 'Y'
            AND f_get_trans_record (in_entity_id, in_bill_type_id, '30') > 0
         THEN
            vd_transaction_date    := vd_receive_date;
            vs_business_state      := '30';
            p_inv_exec_update (in_entity_id,
                               in_head_id,
                               in_sequence_recal,
                               vn_bill_type_id,
                               vn_if_null,
                               vs_business_state,
                               vd_transaction_date,
                               vs_bill_kind
                              );

            IF g_ret_code != err_success
            THEN
               RETURN;
            END IF;
         END IF;

         --已结算
         IF     vd_settle_date >= id_begin_date
            AND vs_settle_flag = 'Y'
            AND f_get_trans_record (in_entity_id, in_bill_type_id, '12') > 0
         THEN
            vd_transaction_date    := vd_settle_date;
            vs_business_state      := '12';
            p_inv_exec_update (in_entity_id,
                               in_head_id,
                               in_sequence_recal,
                               vn_bill_type_id,
                               vn_if_null,
                               vs_business_state,
                               vd_transaction_date,
                               vs_bill_kind
                              );

            IF g_ret_code != err_success
            THEN
               RETURN;
            END IF;
         END IF;
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         g_ret_code    := err_sys_update_so;
         g_ret_desc    := SQLCODE || ' ' || SQLERRM;
   END;

--更新采购单现有量
   PROCEDURE p_inv_update_po (
      in_entity_id        IN       NUMBER,                                              --经营主体ID
      in_head_id          IN       NUMBER,                                            --业务单据头ID
      in_bill_type_id     IN       NUMBER,                                          --业务单据类型ID
      id_begin_date       IN       DATE,                                              --重算开始时间
      in_sequence_recal   IN       NUMBER,                                          --重算日志记录ID
      in_have_id          OUT      NUMBER                           --是否存在业务单据头ID对应的记录
   )
   IS
      vn_bill_type_id       t_inv_po_headers.po_type_id%TYPE;                          --单据类型ID
      vd_billed_date        t_inv_po_headers.billed_date%TYPE;                           --制单日期
      vd_ship_date          t_inv_po_headers.ship_date%TYPE;                             --发货日期
      vd_exec_date          t_inv_po_headers.exec_date%TYPE;                             --执行日期
      vs_po_status          t_inv_po_headers.po_status%TYPE;                             --单据状态
      vd_cnt                NUMBER;
      --单据行或明细的数量，用以判断是否为空单。
      vn_if_null            NUMBER;                                  --是否是空的业务单据，0否，1是
      vs_business_state     t_inv_transaction_history.business_state%TYPE;
      --单据状态
      vd_transaction_date   t_inv_transaction_history.transaction_date%TYPE;
      --业务日期
      vs_bill_kind          VARCHAR2 (32);
--B1（采购中转）、B2（仓库调拨）、B3（仓库盘点）、B4（销售）、B5（推广物料）、B6（备货转销售）
   BEGIN
      g_ret_code    := err_success;
      g_ret_desc    := '';
      in_have_id    := g_not_have_id;
      vd_cnt        := 0;
      vn_if_null    := 0;

      SELECT COUNT (h.po_id)
        INTO vd_cnt
        FROM t_inv_po_headers h
       WHERE h.po_id = in_head_id AND entity_id = in_entity_id AND po_type_id = in_bill_type_id;

      IF vd_cnt = 0
      THEN
         in_have_id    := g_not_have_id;
         RETURN;
      ELSE
         in_have_id      := g_have_id;
         vs_bill_kind    := 'B1';                                                        --采购中转

         SELECT h.po_type_id, h.exec_date, h.po_status, h.billed_date, h.ship_date
           INTO vn_bill_type_id, vd_exec_date, vs_po_status, vd_billed_date, vd_ship_date
           FROM t_inv_po_headers h
          WHERE h.po_id = in_head_id AND entity_id = in_entity_id;

         SELECT COUNT (h.po_id)
           INTO vd_cnt
           FROM t_inv_po_headers h, t_inv_po_lines l
          WHERE h.po_id = l.po_id AND h.entity_id = in_entity_id;

         IF vd_cnt = 0
         THEN
            vn_if_null    := 1;
         ELSE
            vn_if_null    := 0;
         END IF;

         --制单
         IF     vd_billed_date >= id_begin_date
            AND vs_po_status IN ('10', '21', '14')
            AND f_get_trans_record (in_entity_id, in_bill_type_id, '10') > 0
         THEN
            vd_transaction_date    := vd_billed_date;
            vs_business_state      := '10';
            p_inv_exec_update (in_entity_id,
                               in_head_id,
                               in_sequence_recal,
                               vn_bill_type_id,
                               vn_if_null,
                               vs_business_state,
                               vd_transaction_date,
                               vs_bill_kind
                              );

            IF g_ret_code != err_success
            THEN
               RETURN;
            END IF;
         END IF;

         --已发货
         IF     vd_ship_date >= id_begin_date
            AND vs_po_status IN ('21', '14')
            AND f_get_trans_record (in_entity_id, in_bill_type_id, '21') > 0
         THEN
            vd_transaction_date    := vd_ship_date;
            vs_business_state      := '21';
            p_inv_exec_update (in_entity_id,
                               in_head_id,
                               in_sequence_recal,
                               vn_bill_type_id,
                               vn_if_null,
                               vs_business_state,
                               vd_transaction_date,
                               vs_bill_kind
                              );

            IF g_ret_code != err_success
            THEN
               RETURN;
            END IF;
         END IF;

         --已执行
         IF     vd_exec_date >= id_begin_date
            AND vs_po_status = '14'
            AND f_get_trans_record (in_entity_id, in_bill_type_id, '14') > 0
         THEN
            vd_transaction_date    := vd_exec_date;
            vs_business_state      := '14';
            p_inv_exec_update (in_entity_id,
                               in_head_id,
                               in_sequence_recal,
                               vn_bill_type_id,
                               vn_if_null,
                               vs_business_state,
                               vd_transaction_date,
                               vs_bill_kind
                              );

            IF g_ret_code != err_success
            THEN
               RETURN;
            END IF;
         END IF;
      END IF;
   END;

--更新调拨单现有量
   PROCEDURE p_inv_update_trsf (
      in_entity_id        IN       NUMBER,                                              --经营主体ID
      in_head_id          IN       NUMBER,                                            --业务单据头ID
      in_bill_type_id     IN       NUMBER,                                          --业务单据类型ID
      id_begin_date       IN       DATE,                                              --重算开始时间
      in_sequence_recal   IN       NUMBER,                                          --重算日志记录ID
      in_have_id          OUT      NUMBER                           --是否存在业务单据头ID对应的记录
   )
   IS
      vn_bill_type_id        t_inv_trsf_order.bill_type_id%TYPE;                       --单据类型ID
      vd_creation_date       t_inv_trsf_order.creation_date%TYPE;                        --制单日期
      vs_trsf_order_status   t_inv_trsf_order.trsf_order_status%TYPE;                    --单据状态
      vd_audit_date          t_inv_trsf_order.audit_date%TYPE;                         --已审核日期
      vs_audit_flag          t_inv_trsf_order.audit_flag%TYPE;                         --已审核标识
      vd_rcv_date            t_inv_trsf_order.rcv_date%TYPE;                           --已接收日期
      vs_rcv_flag            t_inv_trsf_order.rcv_flag%TYPE;                           --已接收标识
      vd_cnt                 NUMBER;
      --单据行或明细的数量，用以判断是否为空单。
      vn_if_null             NUMBER;                                 --是否是空的业务单据，0否，1是
      vs_business_state      t_inv_transaction_history.business_state%TYPE;
      --单据状态
      vd_transaction_date    t_inv_transaction_history.transaction_date%TYPE;
      --业务日期
      vs_bill_kind           VARCHAR2 (32);
--B1（采购中转）、B2（仓库调拨）、B3（仓库盘点）、B4（销售）、B5（推广物料）、B6（备货转销售）
   BEGIN
      g_ret_code              := err_success;
      g_ret_desc              := '';
      in_have_id              := g_not_have_id;
      vd_cnt                  := 0;
      vn_if_null              := 0;
      vs_trsf_order_status    := NULL;

      SELECT COUNT (h.trsf_order_id)
        INTO vd_cnt
        FROM t_inv_trsf_order h
       WHERE h.trsf_order_id = in_head_id AND entity_id = in_entity_id;

      IF vd_cnt = 0
      THEN
         in_have_id    := g_not_have_id;
         RETURN;
      ELSE
         in_have_id      := g_have_id;
         vs_bill_kind    := 'B2';                                                        --仓库调拨

         SELECT h.bill_type_id, h.audit_date, h.rcv_date, h.audit_flag, h.rcv_flag,
                h.trsf_order_status, TRUNC (h.creation_date)
           INTO vn_bill_type_id, vd_audit_date, vd_rcv_date, vs_audit_flag, vs_rcv_flag,
                vs_trsf_order_status, vd_creation_date
           FROM t_inv_trsf_order h
          WHERE h.trsf_order_id = in_head_id AND entity_id = in_entity_id;

         SELECT COUNT (h.trsf_order_id)
           INTO vd_cnt
           FROM t_inv_trsf_order h, t_inv_trsf_order_line l, t_inv_trsf_order_line_detail d
          WHERE h.trsf_order_id = l.trsf_order_id
            AND l.trsf_order_line_id = d.trsf_order_line_id
            AND h.entity_id = l.entity_id
            AND l.entity_id = d.entity_id
            AND h.entity_id = in_entity_id;

         IF vd_cnt = 0
         THEN
            vn_if_null    := 1;
         ELSE
            vn_if_null    := 0;
         END IF;

         --制单
         IF     vd_creation_date >= id_begin_date
            AND vs_trsf_order_status IN ('10', '11', '13')
            AND f_get_trans_record (in_entity_id, in_bill_type_id, '10') > 0
         THEN
            vd_transaction_date    := vd_creation_date;
            vs_business_state      := '10';
            p_inv_exec_update (in_entity_id,
                               in_head_id,
                               in_sequence_recal,
                               vn_bill_type_id,
                               vn_if_null,
                               vs_business_state,
                               vd_transaction_date,
                               vs_bill_kind
                              );

            IF g_ret_code != err_success
            THEN
               RETURN;
            END IF;
         END IF;

         --已审核
         IF     vd_audit_date >= id_begin_date
            AND vs_audit_flag = '1'
            AND f_get_trans_record (in_entity_id, in_bill_type_id, '11') > 0
         THEN
            vd_transaction_date    := vd_audit_date;
            vs_business_state      := '11';
            p_inv_exec_update (in_entity_id,
                               in_head_id,
                               in_sequence_recal,
                               vn_bill_type_id,
                               vn_if_null,
                               vs_business_state,
                               vd_transaction_date,
                               vs_bill_kind
                              );

            IF g_ret_code != err_success
            THEN
               RETURN;
            END IF;
         END IF;

         --已接收
         IF     vd_rcv_date >= id_begin_date
            AND vs_rcv_flag = '1'
            AND f_get_trans_record (in_entity_id, in_bill_type_id, '13') > 0
         THEN
            vd_transaction_date    := vd_rcv_date;
            vs_business_state      := '13';
            p_inv_exec_update (in_entity_id,
                               in_head_id,
                               in_sequence_recal,
                               vn_bill_type_id,
                               vn_if_null,
                               vs_business_state,
                               vd_transaction_date,
                               vs_bill_kind
                              );

            IF g_ret_code != err_success
            THEN
               RETURN;
            END IF;
         END IF;
      END IF;
   END;

--更新盘点单现有量
   PROCEDURE p_inv_update_check (
      in_entity_id        IN       NUMBER,                                              --经营主体ID
      in_head_id          IN       NUMBER,                                            --业务单据头ID
      in_bill_type_id     IN       NUMBER,                                          --业务单据类型ID
      id_begin_date       IN       DATE,                                              --重算开始时间
      in_sequence_recal   IN       NUMBER,                                          --重算日志记录ID
      in_have_id          OUT      NUMBER                           --是否存在业务单据头ID对应的记录
   )
   IS
      vn_bill_type_id       t_inv_check_orders.check_order_type_id%TYPE;               --单据类型ID
      vd_doc_date           t_inv_check_orders.doc_date%TYPE;                            --制单日期
      vd_exec_date          t_inv_check_orders.exec_date%TYPE;                           --执行日期
      vs_po_status          t_inv_check_orders.po_status%TYPE;                           --单据状态
      vd_cnt                NUMBER;
      --单据行或明细的数量，用以判断是否为空单。
      vn_if_null            NUMBER;                                  --是否是空的业务单据，0否，1是
      vs_business_state     t_inv_transaction_history.business_state%TYPE;
      --单据状态
      vd_transaction_date   t_inv_transaction_history.transaction_date%TYPE;
      --业务日期
      vs_bill_kind          VARCHAR2 (32);
--B1（采购中转）、B2（仓库调拨）、B3（仓库盘点）、B4（销售）、B5（推广物料）、B6（备货转销售）
   BEGIN
      g_ret_code      := err_success;
      g_ret_desc      := '';
      in_have_id      := g_not_have_id;
      vd_cnt          := 0;
      vn_if_null      := 0;
      vs_po_status    := NULL;

      SELECT COUNT (h.check_order_id)
        INTO vd_cnt
        FROM t_inv_check_orders h
       WHERE h.check_order_id = in_head_id AND entity_id = in_entity_id;

      IF vd_cnt = 0
      THEN
         in_have_id    := g_not_have_id;
         RETURN;
      ELSE
         in_have_id      := g_have_id;
         vs_bill_kind    := 'B3';                                                        --仓库盘点

         SELECT h.check_order_type_id, h.exec_date, h.po_status, h.doc_date
           INTO vn_bill_type_id, vd_exec_date, vs_po_status, vd_doc_date
           FROM t_inv_check_orders h
          WHERE h.check_order_id = in_head_id AND entity_id = in_entity_id;

         SELECT COUNT (h.check_order_id)
           INTO vd_cnt
           FROM t_inv_check_orders h, t_inv_check_order_lines l
          WHERE h.check_order_id = l.check_order_id AND h.entity_id = l.entity_id AND h.entity_id = in_entity_id;

         IF vd_cnt = 0
         THEN
            vn_if_null    := 1;
         ELSE
            vn_if_null    := 0;
         END IF;

         --制单
         IF     vd_doc_date >= id_begin_date
            AND vs_po_status IN ('10', '14')
            AND f_get_trans_record (in_entity_id, in_bill_type_id, '10') > 0
         THEN
            vd_transaction_date    := vd_doc_date;
            vs_business_state      := '10';
            p_inv_exec_update (in_entity_id,
                               in_head_id,
                               in_sequence_recal,
                               vn_bill_type_id,
                               vn_if_null,
                               vs_business_state,
                               vd_transaction_date,
                               vs_bill_kind
                              );

            IF g_ret_code != err_success
            THEN
               RETURN;
            END IF;
         END IF;

         --已执行
         IF     vd_exec_date >= id_begin_date
            AND vs_po_status = '14'
            AND f_get_trans_record (in_entity_id, in_bill_type_id, '14') > 0
         THEN
            vd_transaction_date    := vd_exec_date;
            vs_business_state      := '14';
            p_inv_exec_update (in_entity_id,
                               in_head_id,
                               in_sequence_recal,
                               vn_bill_type_id,
                               vn_if_null,
                               vs_business_state,
                               vd_transaction_date,
                               vs_bill_kind
                              );

            IF g_ret_code != err_success
            THEN
               RETURN;
            END IF;
         END IF;
      END IF;
   END;

--更新备货现有量
   PROCEDURE p_inv_update_stockup (
      in_entity_id        IN       NUMBER,                                              --经营主体ID
      in_head_id          IN       NUMBER,                                            --业务单据头ID
      in_bill_type_id     IN       NUMBER,                                          --业务单据类型ID
      id_begin_date       IN       DATE,                                              --重算开始时间
      in_sequence_recal   IN       NUMBER,                                          --重算日志记录ID
      in_have_id          OUT      NUMBER                           --是否存在业务单据头ID对应的记录
   )
   IS
      vn_bill_type_id           t_inv_stockup_order.stockup_order_type_id%TYPE;        --单据类型ID
      vs_stockup_order_status   t_inv_stockup_order.stockup_order_status%TYPE;           --单据状态
      vd_check_date             t_inv_stockup_order.check_date%TYPE;                   --已审核日期
      vd_rcv_date               t_inv_stockup_order.rcv_date%TYPE;                     --已接收日期
      vd_creation_date          t_inv_stockup_order.creation_date%TYPE;                  --制单日期
      vs_check_flag             t_inv_stockup_order.check_flag%TYPE;                     --审核标识
      vs_rev_flag               t_inv_stockup_order.rev_flag%TYPE;                       --接收标识
      vd_cnt                    NUMBER;
      --单据行或明细的数量，用以判断是否为空单。
      vn_if_null                NUMBER;                              --是否是空的业务单据，0否，1是
      vs_business_state         t_inv_transaction_history.business_state%TYPE;
      --单据状态
      vd_transaction_date       t_inv_transaction_history.transaction_date%TYPE;
      --业务日期
      vs_bill_kind              VARCHAR2 (32);
--B1（采购中转）、B2（仓库调拨）、B3（仓库盘点）、B4（销售）、B5（推广物料）、B6（备货转销售）
   BEGIN
      g_ret_code                 := err_success;
      g_ret_desc                 := '';
      in_have_id                 := g_not_have_id;
      vd_cnt                     := 0;
      vn_if_null                 := 0;
      vs_stockup_order_status    := NULL;

      SELECT COUNT (h.stockup_order_id)
        INTO vd_cnt
        FROM t_inv_stockup_order h
       WHERE h.stockup_order_id = in_head_id AND entity_id = in_entity_id;

      IF vd_cnt = 0
      THEN
         in_have_id    := g_not_have_id;
         RETURN;
      ELSE
         in_have_id      := g_have_id;
         vs_bill_kind    := 'B6';                                                      --备货转销售

         SELECT h.stockup_order_type_id, h.check_date, h.rcv_date, h.stockup_order_status,
                TRUNC (h.creation_date)
           INTO vn_bill_type_id, vd_check_date, vd_rcv_date, vs_stockup_order_status,
                vd_creation_date
           FROM t_inv_stockup_order h
          WHERE h.stockup_order_id = in_head_id AND entity_id = in_entity_id;

         SELECT COUNT (h.stockup_order_id)
           INTO vd_cnt
           FROM t_inv_stockup_order h, t_inv_stockup_order_line l
          WHERE h.stockup_order_id = l.stockup_order_id
            AND h.entity_id = l.entity_id
            AND h.entity_id = in_entity_id;

         IF vd_cnt = 0
         THEN
            vn_if_null    := 1;
         ELSE
            vn_if_null    := 0;
         END IF;

         --制单
         IF     vd_check_date >= id_begin_date
            AND vs_stockup_order_status IN ('10', '11', '13')
            AND f_get_trans_record (in_entity_id, in_bill_type_id, '10') > 0
         THEN
            vd_transaction_date    := vd_check_date;
            vs_business_state      := '10';
            p_inv_exec_update (in_entity_id,
                               in_head_id,
                               in_sequence_recal,
                               vn_bill_type_id,
                               vn_if_null,
                               vs_business_state,
                               vd_transaction_date,
                               vs_bill_kind
                              );

            IF g_ret_code != err_success
            THEN
               RETURN;
            END IF;
         END IF;

         --已审核
         IF     vd_check_date >= id_begin_date
            AND vs_check_flag = '1'
            AND f_get_trans_record (in_entity_id, in_bill_type_id, '11') > 0
         THEN
            vd_transaction_date    := vd_check_date;
            vs_business_state      := '11';
            p_inv_exec_update (in_entity_id,
                               in_head_id,
                               in_sequence_recal,
                               vn_bill_type_id,
                               vn_if_null,
                               vs_business_state,
                               vd_transaction_date,
                               vs_bill_kind
                              );

            IF g_ret_code != err_success
            THEN
               RETURN;
            END IF;
         END IF;

         --已接收
         IF     vd_rcv_date >= id_begin_date
            AND vs_rev_flag = '1'
            AND f_get_trans_record (in_entity_id, in_bill_type_id, '13') > 0
         THEN
            vd_transaction_date    := vd_rcv_date;
            vs_business_state      := '13';
            p_inv_exec_update (in_entity_id,
                               in_head_id,
                               in_sequence_recal,
                               vn_bill_type_id,
                               vn_if_null,
                               vs_business_state,
                               vd_transaction_date,
                               vs_bill_kind
                              );

            IF g_ret_code != err_success
            THEN
               RETURN;
            END IF;
         END IF;
      END IF;
   END;

--更新领用发放单现有量
   PROCEDURE p_inv_update_send (
      in_entity_id        IN       NUMBER,                                              --经营主体ID
      in_head_id          IN       NUMBER,                                            --业务单据头ID
      in_bill_type_id     IN       NUMBER,                                          --业务单据类型ID
      id_begin_date       IN       DATE,                                              --重算开始时间
      in_sequence_recal   IN       NUMBER,                                          --重算日志记录ID
      in_have_id          OUT      NUMBER                           --是否存在业务单据头ID对应的记录
   )
   IS
   BEGIN
      g_ret_code    := err_success;
      g_ret_desc    := '';
   END;

   PROCEDURE p_inv_update_null (
      in_entity_id        IN       NUMBER,                                              --经营主体ID
      in_head_id          IN       NUMBER,                                            --业务单据头ID
      id_begin_date       IN       DATE,                                              --重算开始时间
      in_sequence_recal   IN       NUMBER,                                          --重算日志记录ID
      in_bill_type_id     IN       NUMBER,                                          --业务单据类型ID
      in_have_id          OUT      NUMBER                           --是否存在业务单据头ID对应的记录
   )
   IS
      vn_bill_type_id       NUMBER;                                                    --单据类型ID
      vd_check_date         DATE;                                                      --已审核日期
      vd_rcv_date           DATE;                                                      --已接收日期
      vd_cnt                NUMBER;
      --单据行或明细的数量，用以判断是否为空单。
      vn_if_null            NUMBER;                                  --是否是空的业务单据，0否，1是
      vs_business_state     t_inv_transaction_history.business_state%TYPE;
      --单据状态
      vd_transaction_date   t_inv_transaction_history.transaction_date%TYPE;
      --业务日期
      vs_bill_kind          VARCHAR2 (32);
--B1（采购中转）、B2（仓库调拨）、B3（仓库盘点）、B4（销售）、B5（推广物料）、B6（备货转销售）
   BEGIN
      g_ret_code    := err_success;
      g_ret_desc    := '';
      in_have_id    := g_not_have_id;
      vd_cnt        := 0;
      vn_if_null    := 0;

      SELECT COUNT (h.entity_id)
        INTO vd_cnt
        FROM t_inv_transaction_history h
       WHERE h.business_header_id = in_head_id AND entity_id = in_entity_id;

      IF vd_cnt = 0
      THEN
         in_have_id    := g_not_have_id;
         RETURN;
      ELSE
         in_have_id      := g_have_id;
         vs_bill_kind    := 'ISNULL';
         --单据状态置为99，对于物料历史中有，业务单据中没有的记录，为了重算该条记录，给单据状态赋一个不存在的状态：99，
         p_inv_exec_update (in_entity_id,
                            in_head_id,
                            in_sequence_recal,
                            in_bill_type_id,
                            NULL,
                            '99',
                            NULL,
                            vs_bill_kind
                           );

         IF g_ret_code != err_success
         THEN
            RETURN;
         END IF;
      END IF;
   END;

   FUNCTION f_get_trans_record (
      vn_entity_id          IN   NUMBER,
      vn_bill_type_id       IN   t_inv_bill_types.bill_type_id%TYPE,
      vn_bill_status_code   IN   t_inv_bill_period_line.bill_status_code%TYPE
   )
      RETURN INT
   IS
      v_trans   NUMBER;                                                          --触发几笔物料事物
   BEGIN
      v_trans    := 0;

      SELECT DECODE (action_type, '03', 2, '02', 1, '01', 1, 0) trans
        INTO v_trans
        FROM cims.t_inv_bill_types a,
             cims.t_inv_bill_period_head b,
             cims.t_inv_bill_period_line c,
             cims.t_inv_transaction_types d,
             cims.up_codelist e
       WHERE a.bill_period_head_id = b.bill_period_head_id
         AND b.bill_period_head_id = c.bill_period_head_id
         AND c.transaction_type_id = d.transaction_type_id(+)
         AND e.code_value = c.bill_status_code
         AND e.codetype = 'BD_BILL_STATUS'
         AND a.entity_id = vn_entity_id
         AND a.entity_id= b.entity_id
         AND B.ENTITY_ID = d.entity_id
         AND a.bill_type_id = vn_bill_type_id
         AND c.bill_status_code = vn_bill_status_code;

      RETURN v_trans;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN                                          --单据没有对应的配置信息，则认为不触发物料事物。
         v_trans    := 0;
         RETURN v_trans;
   END;
END pkg_inv_recal;
/

