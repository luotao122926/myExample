create PACKAGE PKG_SO_ADJUST IS
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2017-03-16
  *     创建者：周建刚
  *   功能说明：调账申请单开财务单
	*             主要步骤如下：
	*             1、申请单根据调账的财务单号拆分写入销售单接口表
	*             2、根据销售单接口表生成销售单
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_GEN_BY_ADJUST_APPLY(
                              P_APPLY_HEADER_ID IN NUMBER, --调账申请单据头ID
                              P_USER_CODE       IN VARCHAR2, --操作用户编码
                              P_RESULT         OUT NUMBER, --返回错误ID
                              P_ERR_MSG        OUT VARCHAR2 --返回错误信息
                              );
                      
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2017-03-16
  *     创建者：周建刚
  *   功能说明：生成销售单据接口头记录
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_HEADER_INTF_GEN(P_SO_ADJUST_APPLY_HEADER IN T_SO_ADJUST_APPLY_HEADER%ROWTYPE,--调账申请单头信息
                                 P_SO_ADJUST_APPLY_LINE   IN T_SO_ADJUST_APPLY_LINE%ROWTYPE,--调账申请单行信息
                                 P_SO_HEADER_INTF         IN OUT T_SO_HEADER_INTERFACE%ROWTYPE, --销售单据接口头信息
                                 P_BILL_TYPE_CODE         IN VARCHAR2, --新开业务单据类型编码
                                 P_USER_CODE              IN VARCHAR2, --操作用户编码
                                 P_RESULT                 IN OUT NUMBER, --返回错误ID
                                 P_ERR_MSG                IN OUT VARCHAR2 --返回错误信息
                                 );

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2017-03-16
  *     创建者：周建刚
  *   功能说明：生成销售单据接口行记录
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_LINE_INTF_GEN(P_SO_ADJUST_APPLY_HEADER IN T_SO_ADJUST_APPLY_HEADER%ROWTYPE,--调账申请单头信息
                               P_SO_ADJUST_APPLY_LINE   IN T_SO_ADJUST_APPLY_LINE%ROWTYPE,--调账申请单行信息
                               P_SO_HEADER_INTF         IN T_SO_HEADER_INTERFACE%ROWTYPE, --销售单据接口头信息
                               P_SO_LINE_INTF           IN OUT T_SO_LINE_INTERFACE%ROWTYPE, --销售单据接口头信息
                               P_USER_CODE              IN VARCHAR2, --操作用户编码
                               P_RESULT                 IN OUT NUMBER, --返回错误ID
                               P_ERR_MSG                IN OUT VARCHAR2 --返回错误信息
                               );
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2017-04-22
  *     创建者：周建刚
  *   功能说明：根据退货红冲调账申请生成对应发货通知单的过程
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_ADJUSTAPPLY_TO_LG_SHIPDOC(P_APPLY_HEADER_ID IN NUMBER,     --调账申请单据头ID
                                           P_USER_CODE       IN VARCHAR2,   --操作用户编码
                                           P_SHIP_DOC_ID     OUT NUMBER,    --发货通知单ID
                                           P_SHIP_DOC_CODE   OUT VARCHAR2,  --发货通知单号
                                           P_RESULT          IN OUT NUMBER, --返回错误ID
                                           P_ERR_MSG         IN OUT VARCHAR2--返回错误信息
                                           );
  -------------------------------------------------------------------------------
END PKG_SO_ADJUST;
/

