create Package Body      Pkg_Pln_Pub Is
  
  v_Nl      Constant Varchar2(2) := Chr(13) || Chr(10); --换行
  v_Null    Constant Varchar2(4) := 'NULL'; --空值
  v_True    Constant Varchar2(2) := 'Y';
  v_False   Constant Varchar2(2) := 'N';
  v_Result  Constant Number := 0; --成功返回
  v_Success Constant Varchar2(10) := 'SUCCESS';
  v_Failure Constant Varchar2(10) := 'FAILURE';
  v_Base_Exception Exception; --自定义异常
  
  V_OPERATION_ACTION_WALKTHROUGH Constant Varchar2(10):= '预排'; --预排动作 huanghb12
  V_OPERATION_ACTION_PRODUCE Constant Varchar2(10):= '排产';
  --------------------------------------------------------------------------------------------
  -- Author  : 李振
  -- Created : 2014-07-02 11:05:52
  -- Purpose : 获取营销中心的最优产地，默认考虑商品最优物流成本
  --           P_ITEM_ID传入为空或者0时，只取营销中心的最优产的
  --
  --------------------------------------------------------------------------------------------
  Function f_Get_Cen_Prod_Area_Priority(p_Sales_Center_Id In Number,
                                        p_Item_Id         In Number,
                                        p_Entity_Id       In Number,
                                        p_User_Code       In Varchar2)
    Return Number Is
    v_Producing_Area_Id Number;
    Cursor c_Get_Prod_Area Is
      Select Producing_Area_Id
        From (Select Cp.Producing_Area_Id,
                     Cp.Producing_Area_Code,
                     Cp.Producing_Area_Priority,
                     0 Cost_Logistics
                From t_Pln_Customer_Priority Cp
               Where Cp.Sales_Center_Id = p_Sales_Center_Id
                 And Cp.Entity_Id = p_Entity_Id
                 And Trunc(Sysdate) Between Cp.Begin_Date And
                     Nvl(Cp.End_Date, Trunc(Sysdate))
                 And Nvl(Cp.Item_Id, 0) = 0
              Union All
              --按商品查找最优产地
              Select Cp.Producing_Area_Id,
                     Cp.Producing_Area_Code,
                     Cp.Producing_Area_Priority,
                     Nvl(Cp.Cost_Logistics, 999999) Cost_Logistics
                From t_Pln_Customer_Priority Cp
               Where Cp.Sales_Center_Id = p_Sales_Center_Id
                 And Cp.Entity_Id = p_Entity_Id
                 And Nvl(Cp.Item_Id, -1) = p_Item_Id
                 And Trunc(Sysdate) Between Cp.Begin_Date And
                     Nvl(Cp.End_Date, Trunc(Sysdate))
                    --存在商品优化级的，不再取中心产地优化级
                 And (Select Count(1)
                        From t_Pln_Customer_Priority p
                       Where p.Entity_Id = p_Entity_Id
                         And p.Sales_Center_Id = p_Sales_Center_Id
                         And Trunc(Sysdate) Between p.Begin_Date And
                             Nvl(p.End_Date, Trunc(Sysdate))
                         And p.Item_Id = p_Item_Id) = 0)
       Order By Cost_Logistics, Producing_Area_Priority;
    r_Get_Prod_Area c_Get_Prod_Area%Rowtype;
  Begin
    v_Producing_Area_Id := 0;
    Open c_Get_Prod_Area;
    Loop
      Fetch c_Get_Prod_Area
        Into r_Get_Prod_Area;
      Exit When v_Producing_Area_Id <> 0 Or c_Get_Prod_Area%Notfound;
      v_Producing_Area_Id := r_Get_Prod_Area.Producing_Area_Id;
    End Loop;
    Return v_Producing_Area_Id;

  Exception
    When v_Base_Exception Then
      Return 0;
    When Others Then
      Return 0;
  End f_Get_Cen_Prod_Area_Priority;

  --------------------------------------------------------------------------------------------
  -- Author  : 李振
  -- Created : 2015-04-20
  -- Purpose : 获取产品的最优产地，先取中心的优先级
  --------------------------------------------------------------------------------------------
  Function f_Get_Item_Prod_Area_Priority(p_Entity_Id       In Number,
                                         p_Sales_Center_Id In Number,
                                         p_Item_Id         In Number,
                                         p_Item_Life_Cycle In Varchar2 Default 'Y')
    Return Number Is
    v_Producing_Area_Id Number;
    VS_ITEM_LIFE_CYCLE varchar2(2);
    v_Item_Life_Cycle  Varchar2(100);
  Begin
    v_Producing_Area_Id := 0;
    --add by lizhen 2016-01-15 产品型态为“DOMESTIC_MARKET_MAKE 内销定制"是否允许制单，不检查生命周期
    --add by lizhen 2017-04-27 产品型态为“INDORR_PRODUCT","OUTDORR_PRODUCT"，退市状态时，允许下单
    Begin
      Select Distinct Listagg(Uc.Code_Name, ',') Within Group(Order By Uc.Codetype) Over(Partition By Uc.Codetype) Item_Life_Cycle
        Into v_Item_Life_Cycle
        From v_Up_Codelist Uc, t_Bd_Item Tbi
       Where Uc.Codetype = 'PLN_ORDER_CREATE_CHECK_PRODUCTTYPE'
         And Uc.Enabled = 0
         And (Tbi.Producttype = Uc.Code_Value Or
             Tbi.Productform  = Uc.CODE_VALUE) -- add by lizhen 2017-04-27
         And Tbi.Item_Id = p_Item_Id
         And Tbi.Entity_Id = Uc.Entity_Id
         And Uc.Entity_Id = p_Entity_Id;
    Exception
      When Others Then
        v_Item_Life_Cycle := Null;
    End;
    --modi by lizhen 2016-01-15
    If p_Item_Life_Cycle != 'N' Then
      BEGIN
        VS_ITEM_LIFE_CYCLE := PKG_BD.F_GET_PARAMETER_VALUE('PLN_ITEM_LIFE_CYCLE', p_Entity_Id);
      EXCEPTION
        WHEN OTHERS THEN
          RAISE V_BASE_EXCEPTION;
      END;
    Else
      VS_ITEM_LIFE_CYCLE := 'N';
    End If;
    For r_Item_Area In (Select Producing_Area_Id,
                                Producing_Area_Code,
                                Producing_Area_Name
                          From (Select a.Producing_Area_Id,
                                        Pa.Producing_Area_Code,
                                        Pa.Producing_Area_Name,
                                        Nvl(Pc.Priority, 999) * 100 +
                                        a.Producing_Area_Priority Priority
                                   From t_Pln_Item_Producing_Area a,
                                        t_Pln_Producing_Area Pa,
                                        t_pln_item_life_cycle c,-- add by exzhangcc
                                        (Select Rownum Priority,
                                                a.Sales_Center_Id,
                                                a.Producing_Area_Id,
                                                a.Producing_Area_Code,
                                                a.Entity_Id
                                           From (Select t.Sales_Center_Id,
                                                        t.Producing_Area_Id,
                                                        t.Producing_Area_Code,
                                                        t.Entity_Id,
                                                        --20160420 hejy3 增加按产品成本优先级取最优产地
                                                        --Null Cost_Price,
                                                        rank() over(ORDER BY t.cost_price) cost_Priority,
                                                        Rank() Over(Partition By t.Sales_Center_Id Order By t.Producing_Area_Priority) Priority
                                                   From t_Pln_Customer_Priority t
                                                  Where t.Sales_Center_Id = p_Sales_Center_Id
                                                    --And t.Item_Id Is Null
                                                    AND (t.item_id IS NULL OR t.item_id = p_Item_Id)
                                                  Order By cost_Priority, Priority) a) Pc
                                  Where Pa.Entity_Id = a.Entity_Id
                                    And Pa.Producing_Area_Id = a.Producing_Area_Id
                                    And Pc.Sales_Center_Id(+) = p_Sales_Center_Id
                                    And Pc.Entity_Id(+) = p_Entity_Id
                                    And Pc.Producing_Area_Id(+) = a.Producing_Area_Id
                                    And a.Entity_Id = p_Entity_Id
                                    And a.Item_Id = p_Item_Id
                                    --20161025 hejy3 终止当天不能继续使用
                                    And /*Trunc(Sysdate)*/SYSDATE Between Trunc(a.Begin_Date) And
                                        Trunc(Nvl(a.End_Date, Sysdate+1))
                                    And /*Trunc(Sysdate)*/SYSDATE Between Trunc(Pa.Begin_Date) And
                                        Trunc(Nvl(Pa.End_Date, Sysdate+1))
                                    -- add by exzhangcc
                                    and (VS_ITEM_LIFE_CYCLE='N' or (VS_ITEM_LIFE_CYCLE='Y' and c.entity_id=a.entity_id))
                                    and (VS_ITEM_LIFE_CYCLE='N' or (VS_ITEM_LIFE_CYCLE='Y' and c.system_status=nvl(a.state,'_')))
                                    --add by lizhen 2016-01-15 根据快码判断生成周期是否可用
                                    and (VS_ITEM_LIFE_CYCLE='N' or (VS_ITEM_LIFE_CYCLE='Y' and (c.is_month_flag='Y' or c.is_week_flag='Y' or c.is_aps_flag='Y' Or Instr(v_Item_Life_Cycle, Nvl(a.state, '_')) > 0)))
                                  Order By Nvl(Pc.Priority, 999) * 100 + a.Producing_Area_Priority)
                         Where Rownum = 1) Loop
      v_Producing_Area_Id := r_Item_Area.Producing_Area_Id;
    End Loop;
    Return v_Producing_Area_Id;
  Exception
    when v_Base_Exception then
      return v_Producing_Area_Id;
    When Others Then
      Return 0;
  End;

  --------------------------------------------------------------------------------------------
  -- Author  : 李振
  -- Created : 2014-07-02 11:05:52
  -- Purpose : 获取营销中心的最优产地，默认考虑商品最优物流成本
  --           P_ITEM_ID传入为空时，只取营销中心的最优产的
  -- RETURN : 返回中心或产品对应的所有列表。例：产地1,产地2,产地3
  --------------------------------------------------------------------------------------------
  Function f_Get_Cen_Prod_Area_List(p_Sales_Center_Id In Number,
                                    p_Item_Id         In Number,
                                    p_Entity_Id       In Number,
                                    p_User_Code       In Varchar2)
    Return Varchar2 Is
    v_Producing_Area_Id Varchar2(1000);
    Cursor c_Get_Prod_Area Is
      Select Producing_Area_Id
        From (Select Cp.Producing_Area_Id,
                     Cp.Producing_Area_Code,
                     Cp.Producing_Area_Priority,
                     Nvl(Cp.Cost_Logistics, 0) Cost_Logistics
                From t_Pln_Customer_Priority Cp
               Where Cp.Sales_Center_Id = p_Sales_Center_Id
                 And Cp.Entity_Id = p_Entity_Id
                 And Nvl(Cp.Item_Id, 0) = 0
                 And Trunc(Sysdate) Between Cp.Begin_Date And
                     Nvl(Cp.End_Date, Trunc(Sysdate))
              Union All
              --按商品查找最优产地
              Select Cp.Producing_Area_Id,
                     Cp.Producing_Area_Code,
                     Cp.Producing_Area_Priority,
                     Cp.Cost_Logistics Cost_Logistics
                From t_Pln_Customer_Priority Cp
               Where Cp.Sales_Center_Id = p_Sales_Center_Id
                 And Cp.Entity_Id = p_Entity_Id
                 And Nvl(Cp.Item_Id, -1) = p_Item_Id
                 And Trunc(Sysdate) Between Cp.Begin_Date And
                     Nvl(Cp.End_Date, Trunc(Sysdate))
                    --存在商品优化级的，不再取中心产地优化级
                 And (Select Count(1)
                        From t_Pln_Customer_Priority p
                       Where p.Entity_Id = p_Entity_Id
                         And p.Sales_Center_Id = p_Sales_Center_Id
                         And p.Item_Id = p_Item_Id) = 0)
       Order By Cost_Logistics, Producing_Area_Priority;
    r_Get_Prod_Area c_Get_Prod_Area%Rowtype;
  Begin
    Open c_Get_Prod_Area;
    Loop
      Fetch c_Get_Prod_Area
        Into r_Get_Prod_Area;
      Exit When c_Get_Prod_Area%Notfound;
      If v_Producing_Area_Id Is Null Then
        v_Producing_Area_Id := To_Char(r_Get_Prod_Area.Producing_Area_Id);
      Else
        If Instr(v_Producing_Area_Id,
                 To_Char(r_Get_Prod_Area.Producing_Area_Id)) = 0 Then
          v_Producing_Area_Id := v_Producing_Area_Id || ',' ||
                                 To_Char(r_Get_Prod_Area.Producing_Area_Id);
        End If;
      End If;
    End Loop;
    Return v_Producing_Area_Id;
  Exception
    When v_Base_Exception Then
      Return 0;
    When Others Then
      Return 0;
  End f_Get_Cen_Prod_Area_List;

  ------------------------------------------------------------
  /*    获取订单、汇总订单的下一状态
  *     返回：状态流程配置行ID  *
  */
  ------------------------------------------------------------
  Function f_Get_Order_Next_Status(p_Period         In Number,
                                   p_Order_Type_Id  In Number,
                                   p_Curr_State     In Varchar2,
                                   p_Operate_Action In Varchar2)
    Return Number Is
    v_Message             Varchar2(2000);
    v_Curr_Flow_Status_Id Number;
  Begin
    v_Curr_Flow_Status_Id := 0;

    Select Nvl(Fs.Flow_Status_Id, 0)
      Into v_Curr_Flow_Status_Id
      From t_Pln_Order_Type Ot, t_Pln_Order_Period Pp, t_Pln_Flow_Status Fs
     Where Pp.Entity_Id = Ot.Entity_Id
       And Pp.Period_Id = p_Period
       And Ot.Order_Type_Id = p_Order_Type_Id
       And Fs.Action_Code = p_Operate_Action
       And Fs.Flow_Id = Ot.Flow_Id
       And Fs.Curr_Status = p_Curr_State;
    Return v_Curr_Flow_Status_Id;
  Exception
    When No_Data_Found Then
      Return 0;
    When Others Then
      Return 0;
  End;

  ------------------------------------------------------------
  /*    获取订单、汇总订单的下一状态                  */
  --P_CAN_OPTION_FLAG默认传“N"，需要取Y时，有业务逻辑里面判断
  ------------------------------------------------------------
  Procedure p_Get_Order_Next_Status(p_Order_Type_Id    In Number, --单据类型ID
                                    p_Curr_State       In Varchar2, --单据当前状态
                                    p_Curr_Action      In Varchar2, --单据当前动作
                                    p_Can_Option_Flag  In Varchar2, --是否使用可选流程
                                    p_Next_Excute_Step In Out Number, --下一流程ID
                                    p_Nextauto_Excute  In Out Varchar2, --下一流程是否自动执行
                                    p_Next_State       In Out Varchar2, --下一流程状态
                                    p_Next_Action      In Out Varchar2,
                                    p_Result           In Out Varchar2) Is
    v_Message Varchar2(2000);
  Begin
    p_Next_Action     := Null;
    p_Next_State      := Null;
    p_Nextauto_Excute := Null;

    --下状态不取退回动作
    p_Result := v_Success;
    --系统后台处理，只检查必做流程，可选流程不自动返回
    --退回操作必须手工处理，系统不自动处理
    Select To_Char(Fs.Next_Status_Id),
           Next_Fs.Action_Code,
           Nvl(Next_Fs.Auto_Exe_Flag, v_False),
           Nvl(Next_Fs.Flow_Status_Id, 0)
      Into p_Next_State,
           p_Next_Action,
           p_Nextauto_Excute,
           p_Next_Excute_Step
      From t_Pln_Order_Type  Ot,
           t_Pln_Flow_Status Fs,
           t_Pln_Flow_Status Next_Fs
     Where Ot.Order_Type_Id = p_Order_Type_Id
       And Fs.Flow_Id = Ot.Flow_Id
       And Fs.Curr_Status_Id = p_Curr_State
       And Fs.Action_Code = p_Curr_Action
       And Next_Fs.Flow_Id(+) = Fs.Flow_Id
       And Next_Fs.Curr_Status(+) = Fs.Next_Status
       And Next_Fs.Action_Id(+) <> 8 --'退回'
       And Next_Fs.Action_Id(+) <> 365 --'审核驳回'
       And Next_Fs.Action_Id(+) <> 9 --'关闭'
       And Next_Fs.Action_Id(+) <> 501 --'撤回'
       And Fs.Action_Id Not In (8, 9, 365, 501) --'退回','关闭',驳回、撤回
       And Nvl(Fs.Optional_Flow_Flag, 'N') = p_Can_Option_Flag
       And Nvl(Next_Fs.Optional_Flow_Flag(+), 'N') = p_Can_Option_Flag;

  Exception
    When No_Data_Found Then
      p_Result := '获取单据下一状态失败，可能未配置对应的状态信息。';
    When Others Then
      p_Result := Substr(' 获取订单下一状态 (GET_COLLECTORDER_NEXTSTATE)' || v_Nl ||
                         '操作指引：联系管理员正确配置订单流程！' || v_Nl || '系统信息：' ||
                         Sqlerrm || v_Nl || '系统参数：P_PERIOD：' || v_Nl ||
                         '          P_ORDER_TYPE：' || p_Order_Type_Id || v_Nl ||
                         '          P_CURR_STATE：' || p_Curr_State || v_Nl ||
                         '          P_CURR_EXCUTE_STEP：' ||
                         To_Char(p_Next_Excute_Step),
                         1,
                         1800);
  End;

  ------------------------------------------------------------
  /*  根据流程ID，  获取订单、汇总订单的下一状态                  */
  --P_CAN_OPTION_FLAG默认传“N"，需要取Y时，有业务逻辑里面判断
  ------------------------------------------------------------
  Procedure p_Get_Flow_Next_Status(p_Flow_Id          In Number, --单据类型ID
                                   p_Curr_State       In Varchar2, --单据当前状态
                                   p_Curr_Action      In Varchar2, --单据当前动作
                                   p_Can_Option_Flag  In Varchar2, --是否使用可选流程
                                   p_Next_Excute_Step In Out Number, --下一流程ID
                                   p_Nextauto_Excute  In Out Varchar2, --下一流程是否自动执行
                                   p_Next_State       In Out Varchar2, --下一流程状态
                                   p_Next_Action      In Out Varchar2,
                                   p_Result           In Out Varchar2) Is
    v_Message Varchar2(2000);
  Begin
    p_Next_Action     := Null;
    p_Next_State      := Null;
    p_Nextauto_Excute := Null;

    --下状态不取退回动作
    p_Result := v_Success;
    --系统后台处理，只检查必做流程，可选流程不自动返回
    --退回操作必须手工处理，系统不自动处理
    Select To_Char(Fs.Next_Status_Id),
           Next_Fs.Action_Code,
           Nvl(Next_Fs.Auto_Exe_Flag, v_False),
           Nvl(Next_Fs.Flow_Status_Id, 0)
      Into p_Next_State,
           p_Next_Action,
           p_Nextauto_Excute,
           p_Next_Excute_Step
      From t_Pln_Flow_Status Fs,
           t_Pln_Flow_Status Next_Fs
     Where Fs.Flow_Id = p_Flow_Id
       And Fs.Curr_Status_Id = p_Curr_State
       And Fs.Action_Code = p_Curr_Action
       And Next_Fs.Flow_Id(+) = Fs.Flow_Id
       And Next_Fs.Curr_Status(+) = Fs.Next_Status
       And Next_Fs.Action_Id(+) <> 8 --'退回'
       And Next_Fs.Action_Id(+) <> 365 --'审核驳回'
       And Next_Fs.Action_Id(+) <> 9 --'关闭'
       And Next_Fs.Action_Id(+) <> 501 --'撤回'
       And Fs.Action_Id Not In (8, 9, 365, 501) --'退回','关闭',驳回、撤回
       And Nvl(Fs.Optional_Flow_Flag, 'N') = p_Can_Option_Flag
       And Nvl(Next_Fs.Optional_Flow_Flag(+), 'N') = p_Can_Option_Flag;

  Exception
    When No_Data_Found Then
      p_Result := '获取单据下一状态失败，可能未配置对应的状态信息。';
    When Others Then
      p_Result := Substr(' 获取订单下一状态 (GET_COLLECTORDER_NEXTSTATE)' || v_Nl ||
                         '操作指引：联系管理员正确配置订单流程！' || v_Nl || '系统信息：' ||
                         Sqlerrm || v_Nl || '系统参数：P_PERIOD：' || v_Nl ||
                         '          P_ORDER_TYPE：' || p_Flow_Id || v_Nl ||
                         '          P_CURR_STATE：' || p_Curr_State || v_Nl ||
                         '          P_CURR_EXCUTE_STEP：' ||
                         To_Char(p_Next_Excute_Step),
                         1,
                         1800);
  End;

  --------------------------------------------------------------------------------------------
  -- Author  : 李振
  -- Created : 2014-07-02 11:05:52
  -- Purpose : 生成单类型编码规则
  --------------------------------------------------------------------------------------------
  Function f_Create_Order_Type_Code(p_Source_Order_Type_Id In Number,
                                    p_Entity_Id            In Number)
    Return Varchar2 Is
    v_Count           Number;
    v_Order_Type_Code Varchar2(100);
  Begin
    Select Nvl(Substr(Max(Ot.Order_Type_Code), 6, 4), 0) + 1
      Into v_Count
      From t_Pln_Order_Type Ot
     Where Ot.Source_Order_Type_Id = p_Source_Order_Type_Id
       And Ot.Entity_Id = p_Entity_Id;

    Return Lpad(p_Entity_Id, 3, 0) || Lpad(p_Source_Order_Type_Id, 2, 0) || Lpad(v_Count,
                                                                                 4,
                                                                                 0);
  Exception
    When Others Then
      Return '';
  End;

  --------------------------------------------------------------------------------------------
  -- Author  : 李振
  -- Created : 2014-07-02 11:05:52
  -- Purpose : 生成产地信息编码: 主体ID(转16进制补允成2位）+ ROW_COUNT
  --------------------------------------------------------------------------------------------
  Function f_Get_Producing_Area_Code(p_Entity_Id In Number) Return Varchar2 Is
    v_Prefix    Varchar2(10);
    v_Row_Count Varchar2(10);
  Begin
    Select Rpad(Trim(To_Char(p_Entity_Id, 'XX')), 2, 0) Prefix,
           Lpad(Nvl((Select Substr(Max(Producing_Area_Code), 3, 3) + 1
                      From t_Pln_Producing_Area
                     Where Entity_Id = p_Entity_Id),
                    1),
                3,
                0) Row_Count
      Into v_Prefix, v_Row_Count
      From Dual;
    Return v_Prefix || v_Row_Count;
  Exception
    When Others Then
      Return '';
  End;

  --------------------------------------------------------------------------------------------
  -- Author  : 李振
  -- Created : 2014-07-02 11:05:52
  -- Purpose : 生成订单单据号（计划订单，提货订单）
  --------------------------------------------------------------------------------------------
  Procedure p_Create_Order_Number(p_Order_Number_Type In Varchar2, --单据号生成规格（基础数据设置）
                                  p_Period_Id         In Number, --周期ID（提货订单传0)
                                  p_Sales_Center_Id   In Number, --营销中心ID
                                  p_Entity_Id         In Number, --主体ID
                                  p_Order_Number      Out Varchar2 --返回单据号
                                  ) Is
    v_Count             Number;
    v_Center_Short_Name Varchar2(20);
    v_Date              Varchar2(12);
    v_Week_Type         Varchar2(10);
    v_Order_Number      Varchar2(100);
    v_Being_Date        Date;
    v_Entity_Id         Number;
    v_Entity_PreFix     Varchar2(100);
  Begin

    --获取周期类型
    If p_Period_Id > 0 Then
      Select Decode(Op.Period_Type,
                    '周',
                    Trim(To_Char(Op.Statistic_Week)),
                    'T+3周期',
                    Trim(To_Char(Op.Statistic_Week, '00')),
                    Null),
             Op.Begin_Date
        Into v_Week_Type, v_Being_Date
        From t_Pln_Order_Period Op
       Where Op.Entity_Id = p_Entity_Id
         And Op.Period_Id = p_Period_Id;
    End If;

    --获取中心简称
    If Nvl(p_Sales_Center_Id, 0) <> 0 Then
      Select Decode(u.Entity_Id, 10, Ue.Ext_Textbox, Ue.Ext_Textbox), u.entity_id
        Into v_Center_Short_Name, v_Entity_Id
        From Up_Org_Unit u, Up_Org_Unit_Ext Ue
       Where u.Id = Ue.Id
         And u.Unit_Id = p_Sales_Center_Id
         --And u.Type_Code = 'SC'
         And u.Entity_Id = p_Entity_Id;
    End If;
      
      --获取当前日期字串
      --所有主体使用YYMM
      Select /*Decode(p_Entity_Id,
                          10, --家用空调
                          To_Char(Nvl(v_Being_Date, Sysdate), 'YYMM'),
                          14, --厨房电器
                          To_Char(Nvl(v_Being_Date, Sysdate), 'YYYYMMDD'),
                          To_Char(Nvl(v_Being_Date, Sysdate), 'YYMM'))*/
       To_Char(Nvl(v_Being_Date, Sysdate), 'YYMM')
        Into v_Date
        From Dual;
    
    --add by lizhen 2015-04-16 订单单据编码增加主体前缀
    Begin
      Select Ucl.Code_Value
        Into v_Entity_Prefix
        From Up_Codelist Ucl, Up_Codelist_Entity Ucle
       Where Ucl.Codetype = 'PLN_ORD_NUM_ENTITY_PREFIX'
         And Ucl.Id = Ucle.Codelist_Id
         And Ucl.Enabled = 0
         And Ucle.Entity_Id = Nvl(p_Entity_Id, v_Entity_Id);
    Exception
      When No_Data_Found Then
        v_Entity_Prefix := Null;
      When Others Then
        p_Order_Number := Null;
        Raise v_Base_Exception;
    End;

    v_Order_Number := v_Center_Short_Name || v_Entity_PreFix || v_Date || v_Week_Type;
    p_Order_Number := Pkg_Bd.f_Get_Bill_No(p_Bill_Type  => p_Order_Number_Type,
                                           p_Prefix_Add => v_Order_Number,
                                           p_Entity_Id  => Nvl(p_Entity_Id, v_Entity_Id),
                                           p_User_Id    => 0);
  Exception
    When v_Base_Exception Then
      p_Order_Number := Null;
    When Others Then
      p_Order_Number := Null;
  End;
  -----------------------------------------------------------------------------------------
  --Anthor: Nicro.Li
  --Purpose: 更新下达数量
  -----------------------------------------------------------------------------------------
  Procedure p_Upd_Pln_Carry_Qty(p_Order_Share_Id   In Number, --行ID
                                p_Trans_Carry_Qty  In Number, --下达数量
                                p_Trans_Sign_Flag  In Number, --符号方向,下达传1  取消下达传-1
                                p_Entity_Id        In Number, --主体ID
                                p_User_Code        In Varchar2, --用户编码
                                p_Result           Out Varchar2, --成功返回'SUCCESS' 否则返回错误信息
                                p_Lg_Ship_Plan_Id  In Number Default Null, --运力任务计划行ID
                                p_Cusg_Ord_Plan_Id In Number Default Null --直发客户行ID
                                ) Is
    v_Value        Varchar2(2000);
    r_Share_Ship   t_Pln_Order_Share_Shipment%Rowtype;
    v_Hq_Inv_Flag  Varchar2(5);
    r_Order_Header t_Pln_Order_Head%Rowtype;
    r_order_line t_pln_order_line%rowtype; --20170517 hejy3 订单行
    v_Sales_Main_Type   Varchar2(100);
    v_Source_Order_Code Varchar2(100);
    v_Count             Number;
    v_Account_Amount    Number; --结算金额
    v_Discount_Amount   Number; --折让金额
    v_Price             Number;
    v_Discount_Rate     Number;
    v_Account_id        Number;
    v_Account_code      Varchar2(100);
    v_Customer_id       Number;
    v_Carry_Qty         Number;
    v_return_code       number;
    v_result   Varchar2(1000);
    r_lg_ship_plan     t_Lg_Ship_Plan%RowType;
    v_Month_Discount_Rate        Number;
    v_Default_Lock_Amount_Flag   Varchar2(20);

    v_New_Price             Number;    --add by xuhongjiu 2016-01-13 取计划行上的价格
    v_New_Discount_Rate     Number;    --add by xuhongjiu 2016-01-13 取计划行上的扣率
    v_New_Month_Discount_Rate        Number;  --add by xuhongjiu 2016-01-13 取计划行上的月返
    v_New_Account_Amount    Number; --结算金额
    v_New_Discount_Amount   Number; --折让金额
    v_Ims_Lg_Opt_Id NUMBER;

    v_Trsf_Amount NUMBER;
    v_Trsf_Dis_Amount NUMBER;
    v_Trsf_Sales_Main_Type t_bd_item.sales_main_type%TYPE;
    V_OS_ATTRIB01 Varchar2(1000);
    V_OS_ATTRIB02 Varchar2(1000);
    
    v_Release_Amount NUMBER;
    v_Release_Dis_Amount NUMBER;
    v_item_id number;
    v_Discount_Type   Varchar2(32);
    v_Origin_Order_Id number;
    v_Origin_Order_Type varchar2(100);
    v_Origin_Order_Type_Id number;
    v_Source_Type varchar2(100);
    V_PLN_ORDER_HEAD_ID NUMBER;
    V_PLN_ORDER_LINE_ID NUMBER;
    V_DOWN_AMOUT_FLAG   NUMBER := 0; --20180426 hejy3 处理订金标志
    V_LG_ORDER_AMOUNT_FLAG NUMBER := 0; --20180426 hejy3 处理提货额度标志
    v_LOCK_AMOUNT_FLAG t_pln_lg_order_head.lock_amount_flag%type; --20180426 hejy3 锁款标志
    in_entity_id number;
    in_user_code varchar2(32);
    v_Hq_Affirm_Lock_Full_Amount t_bd_param_list.default_value%type := 'N';
  Begin
    p_Result := v_Success;
    --参数校验
    If p_Trans_Carry_Qty = 0 Then
      Return;
    End If;

    If Not (p_Trans_Sign_Flag = 1 Or p_Trans_Sign_Flag = -1) Then
      p_Result := '参数 p_Trans_Sign_Flag 错误，只允许传入：1、-1。';
      Return;
    End If;
    
    in_entity_id := p_Entity_Id;
    in_user_code := p_User_Code;
    
    if p_Lg_Ship_Plan_Id is not null or p_Trans_Sign_Flag = -1 then
      begin
        Select *
          Into r_Lg_Ship_Plan
          From t_Lg_Ship_Plan Tp
         Where Tp.Ship_Plan_Id = p_Lg_Ship_Plan_Id;
      exception
        When Others Then
          p_Result := '获取发运计划失败:' || p_Lg_Ship_Plan_Id || v_value|| Sqlerrm;
          v_value  := p_Result;
          Raise v_Base_Exception;
      end;
      in_entity_id := r_Lg_Ship_Plan.Entity_Id;
    end if;
    
    if r_lg_ship_plan.direct_transport_falg = 'Y' and r_lg_ship_plan.direct_status = '01' then
      in_entity_id := r_Lg_Ship_Plan.Entity_Id;
      in_user_code := 'LMS';
    end if;
    
    if in_user_code is null then
      in_user_code := 'admin';
    end if;
    
    --不是计划订单来源的直接返回
    if p_Trans_Sign_Flag = -1 then

      if nvl(r_Lg_Ship_Plan.Origin_Type, '_') = '31' then
        --处理客户款项
        v_Release_Amount := (p_Trans_Carry_Qty * r_Lg_Ship_Plan.Item_Price
          * (100 - nvl(r_Lg_Ship_Plan.Discount_Rate, 0) - Nvl(r_Lg_Ship_Plan.Month_Discount_Rate, 0))) / 100;
        v_Release_Dis_Amount := (p_Trans_Carry_Qty * r_Lg_Ship_Plan.Item_Price
          * nvl(r_Lg_Ship_Plan.Discount_Rate, 0)) / 100;
          
        Begin
          Select Ca.Account_Id
            Into v_Account_Id
            From t_Customer_Account Ca
           Where Ca.Account_Code = r_Lg_Ship_Plan.Account_Code
             And Ca.Entity_Id = r_Lg_Ship_Plan.Entity_Id;
        Exception
          When Others Then
            v_Value := '获取账户ID失败，账户编码：' || r_Lg_Ship_Plan.Account_Code || v_Nl || Sqlerrm;
            Raise v_Base_Exception;
        End;
        
        IF r_Lg_Ship_Plan.Origin_Origin_Type = '02' THEN
          BEGIN
            SELECT H.ORDER_HEAD_ID, H.ORDER_TYPE_CODE, H.LOCK_AMOUNT_FLAG, h.order_type_id
              INTO v_Origin_Order_Id, v_Origin_Order_Type, v_LOCK_AMOUNT_FLAG, v_Origin_Order_Type_Id
              FROM T_PLN_LG_ORDER_HEAD H
             WHERE H.ORDER_HEAD_ID = r_Lg_Ship_Plan.Origin_Origin_Head_Id;
            
            --订金处理标志
            --20180712 hejy3 送总部锁款处理
            IF Nvl(v_LOCK_AMOUNT_FLAG, 'N') IN (V_LOCK_AMOUNT_FLAG_S, V_LOCK_AMOUNT_FLAG_RS, V_LOCK_AMOUNT_FLAG_HQ) THEN
              V_DOWN_AMOUT_FLAG := 1;
            ELSE
              V_DOWN_AMOUT_FLAG := 0;
            END IF;
            --提货额度处理标志
            V_LG_ORDER_AMOUNT_FLAG := 1;
          EXCEPTION
            WHEN OTHERS THEN
              v_Origin_Order_Id := r_Lg_Ship_Plan.Origin_Origin_Head_Id;
              v_Origin_Order_Type := '销售转采购';
              v_Origin_Order_Type_Id := -1;
          END;
          v_Source_Type := r_Lg_Ship_Plan.Origin_Origin_Type;
        ELSE
          v_Origin_Order_Id := r_Lg_Ship_Plan.Origin_Line_Id;
          v_Origin_Order_Type := '销售转采购';
          v_Source_Type := '12';
          v_Origin_Order_Type_Id := -1;
        END IF;
        
        --获取参数:销司订单总部评审锁全款
        Begin
          v_Hq_Affirm_Lock_Full_Amount := Pkg_Bd.f_Get_Parameter_Value('PLN_HQ_AFFIRM_LOCK_FULL_AMOUNT',
                                                             r_Lg_Ship_Plan.Entity_Id);
        Exception
          When Others Then
            v_Value := '获取销司订单总部评审锁全款参数PLN_HQ_AFFIRM_LOCK_FULL_AMOUNT参数失败！' || v_Nl ||
                          Sqlerrm;
            Raise v_Base_Exception;
        End;
        
        IF V_DOWN_AMOUT_FLAG = 1 OR V_LG_ORDER_AMOUNT_FLAG = 1 THEN
          --解锁款项、加锁订金
          IF V_DOWN_AMOUT_FLAG = 1 THEN
            PKG_PLN_PUB.P_CUSTOMER_AMOUNT_PROCESS(IN_ENTITY_ID       => r_Lg_Ship_Plan.Entity_Id,
                                                  IN_ORDER_TYPE_ID   => v_Origin_Order_Type_Id,
                                                  IN_ORDER_TYPE_CODE => v_Origin_Order_Type,
                                                  IN_CUSTOMER_ID     => r_Lg_Ship_Plan.Customer_Id,
                                                  IN_ACCOUNT_ID      => v_Account_Id,
                                                  IN_SALES_MAIN_TYPE => r_Lg_Ship_Plan.Sales_Main_Type,
                                                  IN_ACTION_TYPE     => 29,
                                                  IN_SOURCE_TYPE     => v_Source_Type,
                                                  IN_ORDER_ID        => v_Origin_Order_Id,
                                                  IN_PROJ_NUMBER     => null,
                                                  IN_DISCOUNT_TYPE   => nvl(r_Lg_Ship_Plan.Discount_Type, v_Discount_Type_Common),
                                                  IN_AMOUNT          => Round(V_RELEASE_AMOUNT, 2),
                                                  IN_DIS_AMOUNT      => Round(v_Release_Dis_Amount, 2),
                                                  IN_RECORD_ERR      => 'N',
                                                  IN_USER_CODE       => in_user_code,
                                                  OUT_RESULT         => p_Result);
            if p_Result <> v_Success then
              v_Value := '取消发货（销售转采购发货通知单）处理客户款项失败(锁款方式：'||v_LOCK_AMOUNT_FLAG||')！' || v_Nl || p_Result;
              Raise v_Base_Exception;
            end if;
            
          END IF;
          
          --减少提货额度占用
          IF V_LG_ORDER_AMOUNT_FLAG = 1 THEN
            PKG_CREDIT_DOWN_PAY.P_UNLOCK_ORDER_AMOUNT(IN_ORDER_ID      => v_Origin_Order_Id,
                                                      IS_ORDER_TYPE    => v_Origin_Order_Type,
                                                      IN_UNLOCK_AMOUNT => V_RELEASE_AMOUNT,
                                                      IS_USER_ACCOUNT  => in_user_code,
                                                      OS_MESSAGE       => p_Result);
            IF p_Result <> v_Success THEN
              v_Value := '释放提货订单额度失败。' || v_Nl ||
                          '客户编码：' || r_Lg_Ship_Plan.Customer_Code || v_Nl ||
                          '账户编码：' || r_Lg_Ship_Plan.Account_Code || v_Nl ||
                          '当前释放金额：' || to_char(V_RELEASE_AMOUNT) || v_Nl ||
                          '系统提示：'|| p_Result;
              RAISE v_Base_Exception;
            END IF;
          END IF;
        END IF;
        
        pkg_pln_pub.P_CUSTOMER_AMOUNT_PROCESS(IN_ENTITY_ID       => r_Lg_Ship_Plan.Entity_Id,
                                              IN_ORDER_TYPE_ID   => v_Origin_Order_Type_Id,
                                              IN_ORDER_TYPE_CODE => v_Origin_Order_Type,
                                              IN_CUSTOMER_ID     => r_Lg_Ship_Plan.Customer_Id,
                                              IN_ACCOUNT_ID      => v_Account_Id,
                                              IN_SALES_MAIN_TYPE => r_Lg_Ship_Plan.Sales_Main_Type,
                                              IN_ACTION_TYPE     => 2,
                                              IN_SOURCE_TYPE     => v_Source_Type,
                                              IN_ORDER_ID        => v_Origin_Order_Id,
                                              IN_PROJ_NUMBER     => null,
                                              IN_DISCOUNT_TYPE   => nvl(r_Lg_Ship_Plan.Discount_Type, v_Discount_Type_Common),
                                              IN_AMOUNT          => Round(v_Release_Amount, 2),
                                              IN_DIS_AMOUNT      => Round(v_Release_Dis_Amount, 2),
                                              IN_RECORD_ERR      => 'N',
                                              IN_USER_CODE       => in_user_code,
                                              OUT_RESULT         => p_Result);
        if p_Result <> v_Success then
          v_Value := '取消发货（销售转采购发货通知单）处理客户款项失败(锁款方式：'||v_LOCK_AMOUNT_FLAG||')！' || v_Nl || p_Result;
          Raise v_Base_Exception;
        end if;
          
        IF r_Lg_Ship_Plan.Project_Order_Line_Id IS NOT NULL THEN
          PKG_BD_PRICE.P_APPLY_UNLOCK(P_APPLY_DETAIL_ID => r_Lg_Ship_Plan.Project_Order_Line_Id,
                                      P_UNLOCK_CNT      => p_Trans_Carry_Qty,
                                      P_BILL_NO         => r_Lg_Ship_Plan.Origin_Order_Num,
                                      P_RETURN_CODE     => v_Value,
                                      P_RETURN_MSG      => p_Result);
          IF v_Value = '1' THEN --返回1表示成功
            p_Result := v_Success;
            v_Value := v_Success;
          ELSE
            v_Value := '批文号：'||r_Lg_Ship_Plan.Project_Order_Number||
                       '，产品编码：'||r_Lg_Ship_Plan.Item_Code||
                       '，数量：' || to_char(p_Trans_Carry_Qty)||v_Nl||
                       '解锁客户批文数量失败，错误信息：' || p_Result;
            Raise v_Base_Exception;
          END IF;
        END IF;
        
        --处理库存
        Begin
          Select bi.item_id
            Into v_item_id
            From t_bd_item bi
           Where bi.item_code = r_Lg_Ship_Plan.Item_Code
             And bi.Entity_Id = r_Lg_Ship_Plan.Entity_Id;
        Exception
          When Others Then
            v_Value := '获取产品失败，产品编码：' || r_Lg_Ship_Plan.Item_Code || v_Nl || Sqlerrm;
            Raise v_Base_Exception;
        End;
        
        PKG_PLN_INV_OCCUPY.p_Others_Unoccupy_Stocks(r_Lg_Ship_Plan.Ship_Inventory_Id,
                                                     v_item_id,
                                                     p_Trans_Sign_Flag * p_Trans_Carry_Qty,
                                                     'A',
                                                     '来源销售单的发货通知单取消发货',
                                                     r_Lg_Ship_Plan.Entity_Id,
                                                     '销售转采购',
                                                     r_Lg_Ship_Plan.Origin_Order_Id,
                                                     r_Lg_Ship_Plan.Origin_Order_Num,
                                                     r_Lg_Ship_Plan.Origin_Line_Id,
                                                     '销售转采购销售单',
                                                     r_Lg_Ship_Plan.Origin_Order_Id,
                                                     r_Lg_Ship_Plan.Origin_Order_Num,
                                                     r_Lg_Ship_Plan.Origin_Line_Id,
                                                     in_user_code,
                                                     'N',
                                                     v_Count,
                                                     v_Value);
        If v_Count <> 0 Then
          v_Value := '释放库存占用失败。' || v_Nl || v_Value;
          Raise v_Base_Exception;
        End If;
        
        --20170829 hejy3 回写提货订单取消数量
        IF nvl(r_Lg_Ship_Plan.Origin_Origin_Type, '_') = '02' then
          UPDATE T_PLN_LG_ORDER_LINE L
             SET L.CANCEL_QTY = NVL(L.CANCEL_QTY, 0) + p_Trans_Carry_Qty,
                 L.CENTER_AFFIRMED_QTY = DECODE(SIGN(NVL(L.CENTER_AFFIRMED_QTY, 0) - p_Trans_Carry_Qty), -1, 0, NVL(L.CENTER_AFFIRMED_QTY, 0) - p_Trans_Carry_Qty),
                 L.AFFIRMED_QUANTITY = DECODE(SIGN(NVL(L.AFFIRMED_QUANTITY, 0) - p_Trans_Carry_Qty), -1, 0, NVL(L.AFFIRMED_QUANTITY, 0) - p_Trans_Carry_Qty),
                 L.LAST_UPDATED_BY = in_user_code,
                 L.LAST_UPDATE_DATE = SYSDATE,
                 L.VERSION = NVL(L.VERSION, 0) + 1
           WHERE L.ORDER_LINE_ID = r_Lg_Ship_Plan.Origin_Origin_Line_Id;
          
          --更新已直发数量
          if (v_LOCK_AMOUNT_FLAG = 'Y' or (v_LOCK_AMOUNT_FLAG = 'S' and v_Hq_Affirm_Lock_Full_Amount = 'Y')) then
            update t_pln_lg_order_line l
               set l.sended_qty = greatest(nvl(l.sended_qty, 0) - p_Trans_Carry_Qty, 0)
             where l.order_line_id = r_Lg_Ship_Plan.Origin_Origin_Line_Id;
             
            update t_pln_lg_order_line l
               set l.transfer_hq_affirmed_qty = greatest(nvl(l.transfer_hq_affirmed_qty, 0) - p_Trans_Carry_Qty, 0, nvl(l.sended_qty, 0))
             where l.order_line_id = r_Lg_Ship_Plan.Origin_Origin_Line_Id;
          end if;
           
           --插入操作历史
           Begin
             Insert Into t_Pln_Order_Review_Info
              (Entity_Id, --业务主体
               Order_Review_Id, --订单评审记录ID
               Lot_Num, --批次（用于记录订单评审第几次）
               Order_Period, --订单周期（汇总的订单评审，记录订单周期）
               Source_Order_Type_Id, --源订单类型ID
               Order_Type_Id, --订单类型ID
               Order_State, --订单状态（送审、汇总、库评、产地分解等）
               Order_Type_Name, --订单类型名称
               Order_Number, --订单号（单单评审，记录订单号）
               Hq_Date, --总部评审日期
               Hq_User, --总部评审人员
               Remark, --备注
               Created_By, --创建人
               Creation_Date, --创建日期
               Last_Updated_By, --最后修改人
               Last_Update_Date, --最后修改日期
               Pre_Field_01, --预留字段1
               Pre_Field_02, --预留字段2
               Pre_Field_03, --预留字段3
               Pre_Field_04, --预留字段4
               Pre_Field_05, --预留字段5
               Pre_Field_06, --预留字段6
               Origin_Order_Head_Id, --来源订单头ID
               Origin_Order_Line_Id, --来源订单行ID
               Item_Id, --产品ID
               Item_Code, --产品编码
               Item_Name, --产品描述
               Affirm_Qty, --评审数量
               Receive_Inventory_Id, --收货仓库ID
               Send_Inventory_Id --发货仓库ID
               )
            select l.Entity_Id, --业务主体
                   s_Pln_Order_Review_Info.Nextval, --订单评审记录ID
                   (Select Count(1)
                      From t_Pln_Order_Review_Info Ri
                     Where Ri.Origin_Order_Head_Id = l.Order_Head_Id
                       And Ri.Origin_Order_Line_Id = l.Order_Line_Id) + 1, --批次（用于记录订单评审第几次）
                   Null, --订单周期（汇总的订单评审，记录订单周期）
                   t.Source_Order_Type_Id, --源订单类型ID
                   t.Order_Type_Id, --订单类型ID
                   h.Order_Head_State, --订单状态（送审、汇总、库评、产地分解等）
                   t.Order_Type_Name, --订单类型名称
                   h.Order_Number, --订单号（单单评审，记录订单号）
                   Trunc(Sysdate), --总部评审日期
                   in_user_code, --总部评审人员
                   '销售转采购生成的发货通知单，取消发货回写订单取消数量', --备注
                   in_user_code, --创建人
                   Sysdate, --创建日期
                   in_user_code, --最后修改人
                   Sysdate, --最后修改日期
                   h.Order_Head_State, --Pre_Field_01, --预留字段1(写入订单状态值)
                   Null, --Pre_Field_02, --预留字段2
                   Null, --Pre_Field_03, --预留字段3
                   Null, --Pre_Field_04, --预留字段4
                   Null, --Pre_Field_05, --预留字段5
                   Null, --Pre_Field_06, --预留字段6
                   h.Order_Head_Id, --Origin_Order_Head_Id, --来源订单头ID
                   l.Order_Line_Id, --Origin_Order_Line_Id, --来源订单行ID
                   l.Item_Id, --Item_Id, --产品ID
                   l.Item_Code, --Item_Code, --产品编码
                   l.Item_Name, --Item_Name, --产品描述
                   p_Trans_Carry_Qty * p_Trans_Sign_Flag, --Affirm_Qty --评审数量
                   h.Inventory_To_Id, --收货仓库ID
                   r_Lg_Ship_Plan.Ship_Inventory_Id --发货仓库ID
             from t_pln_lg_order_line l, t_pln_lg_order_head h, t_pln_order_type t
            where l.order_line_id = r_Lg_Ship_Plan.Origin_Origin_Line_Id
              and l.order_head_id = h.order_head_id
              and h.order_type_id = t.order_type_id;
          Exception
            When Others Then
              v_Value := '插入评审记录信息失败，失败原因：' || Sqlerrm;
              Raise v_Base_Exception;
          End;
        end if;
        
        p_Result := v_Success;
        return;
      elsif nvl(r_Lg_Ship_Plan.Origin_Type, '_') <> '01' then
        Return;
      end if;
    end if;

    if r_lg_ship_plan.direct_transport_falg = 'Y' and (nvl(r_lg_ship_plan.direct_status, '_') <> '01' or p_Trans_Sign_Flag = -1) then
      V_PLN_ORDER_HEAD_ID := r_lg_ship_plan.origin_order_id;
      V_PLN_ORDER_LINE_ID := r_lg_ship_plan.origin_line_id;
    else
      Begin
        Select *
          Into r_Share_Ship
          From t_Pln_Order_Share_Shipment Oss
         Where Oss.Order_Share_Id = p_Order_Share_Id
           And Oss.Entity_Id = in_entity_id;
      Exception
        When Others Then
          p_Result := '获取订单发货计划失败:发货计划行ID:' || To_Char(p_Order_Share_Id) ||
                      Sqlerrm;
          Return;
      End;
      
      V_PLN_ORDER_HEAD_ID := r_Share_Ship.Origin_Head_Id;
      V_PLN_ORDER_LINE_ID := r_Share_Ship.Origin_Line_Id;
    end if;

    Begin
      Select *
        Into r_Order_Header
        From t_Pln_Order_Head h
       Where h.Order_Head_Id = V_PLN_ORDER_HEAD_ID;--r_Share_Ship.Origin_Head_Id;
    Exception
      When Others Then
        p_Result := '获取订单头数据失败:头ID:' ||
                    To_Char(/*r_Share_Ship.Origin_Head_Id*/V_PLN_ORDER_HEAD_ID) || Sqlerrm;
        Return;
    End;
    
    Begin
      Select *
        Into r_order_line
        From t_Pln_Order_Line l
       Where l.order_line_id = V_PLN_ORDER_LINE_ID;--r_Share_Ship.Origin_Line_Id;
    Exception
      When Others Then
        p_Result := '获取订单行数据失败:行ID:' ||
                    To_Char(/*r_Share_Ship.Origin_Line_Id*/V_PLN_ORDER_LINE_ID) || Sqlerrm;
        Return;
    End;
    
    Begin
      Select Ot.Chk_Cusg_Amount_Flag
        Into v_Default_Lock_Amount_Flag
        From t_Pln_Order_Type Ot
       Where Ot.Order_Type_Id = r_Order_Header.Order_Type_Id;
    Exception
      When Others Then
        p_Result := '获取订单单据类型默认锁定金额标志失败:头ID:' ||
                    To_Char(r_Order_Header.Order_Type_Id) || Sqlerrm;
        Return;
    End;
    Begin
      If p_Trans_Sign_Flag = -1 or r_lg_ship_plan.direct_transport_falg = 'Y' Then
        Begin
          Select *
            Into r_Lg_Ship_Plan
            From t_Lg_Ship_Plan Tp
           Where Tp.Ship_Plan_Id = p_Lg_Ship_Plan_Id;
          --add by lizhen 2015-07-16
          If r_Lg_Ship_Plan.Origin_Origin_Head_Id Is Not Null And
             r_Lg_Ship_Plan.Origin_Origin_Line_Id Is Not Null And
             r_Lg_Ship_Plan.Origin_Origin_Type = '02' Then
            p_Upd_Lgorder_Affirm_Qty(r_Lg_Ship_Plan.Origin_Origin_Line_Id,
                                     r_Lg_Ship_Plan.Ship_Inventory_Id,
                                     p_Trans_Carry_Qty,
                                     p_Trans_Sign_Flag,---1,
                                     r_Lg_Ship_Plan.Entity_Id,
                                     in_user_code,
                                     p_Result,
                                     p_Lg_Ship_Plan_Id --运力任务计划行ID ADD BY LIZHEN 2015-08-18
                                     );
          End If;
        Exception
          When Others Then
            p_Result := '获取发货通知单失败:' || p_Lg_Ship_Plan_Id || v_value|| Sqlerrm;
            v_value  :=p_Result;
            Raise v_Base_Exception;
        End;
        If p_Result <> 'SUCCESS' Then
          v_value := '提货订单取消物流信息失败！' || v_Nl || p_Result || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
        End If;
        
        --20170510 hejy3 CIMS直发取消代理商款项锁定和批文锁定
        IF r_Lg_Ship_Plan.Transfer_Customer_Id IS NOT NULL AND r_Lg_Ship_Plan.Transfer_Entity_Id IS NOT NULL THEN
          IF r_lg_ship_plan.Agent_Order_Number IS NULL THEN
            v_Trsf_Amount := (p_Trans_Carry_Qty * r_Lg_Ship_Plan.Transfer_List_Price
              * (100 - nvl(r_Lg_Ship_Plan.Transfer_Discount_Rate, 0) - Nvl(r_Lg_Ship_Plan.Transfer_Month_Discount_Rate, 0))) / 100;
            v_Trsf_Dis_Amount := (p_Trans_Carry_Qty * r_Lg_Ship_Plan.Transfer_List_Price
              * nvl(r_Lg_Ship_Plan.Transfer_Discount_Rate, 0)) / 100;
            BEGIN
              SELECT BI.SALES_MAIN_TYPE INTO v_Trsf_Sales_Main_Type
                FROM T_BD_ITEM BI
               WHERE BI.ENTITY_ID = r_Lg_Ship_Plan.Transfer_Entity_Id
                 AND BI.ITEM_CODE = r_Lg_Ship_Plan.Item_Code;
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                v_Value := '获取分部产品营销大类失败，在分部主体未找到对应编码的产品' ||
                           '，产品编码：' || r_Lg_Ship_Plan.Item_Code;
                Raise v_Base_Exception;
            END;
            
            pkg_pln_pub.P_CUSTOMER_AMOUNT_PROCESS(IN_ENTITY_ID       => r_Lg_Ship_Plan.Transfer_Entity_Id,
                                                  IN_ORDER_TYPE_ID   => r_Order_Header.Order_Type_Id,
                                                  IN_ORDER_TYPE_CODE => r_Order_Header.Order_Type_Code,
                                                  IN_CUSTOMER_ID     => r_Lg_Ship_Plan.Transfer_Customer_Id,
                                                  IN_ACCOUNT_ID      => r_Lg_Ship_Plan.Transfer_Account_Id,
                                                  IN_SALES_MAIN_TYPE => v_Trsf_Sales_Main_Type,
                                                  IN_ACTION_TYPE     => 2,
                                                  IN_SOURCE_TYPE     => '01',
                                                  IN_ORDER_ID        => r_Share_Ship.Origin_Head_Id,
                                                  IN_PROJ_NUMBER     => null,
                                                  IN_DISCOUNT_TYPE   => nvl(r_Lg_Ship_Plan.Transfer_Discount_Type, v_Discount_Type_Common),
                                                  IN_AMOUNT          => Round(v_Trsf_Amount, 2),
                                                  IN_DIS_AMOUNT      => Round(v_Trsf_Dis_Amount, 2),
                                                  IN_RECORD_ERR      => 'N',
                                                  IN_USER_CODE       => in_user_code,
                                                  OUT_RESULT         => p_Result);
            if p_Result <> v_Success then
              v_Value := '取消发货（制定发货需求计划直发代理商）处理代理商客户款项失败！' || v_Nl || p_Result;
              Raise v_Base_Exception;
            end if;
            
            IF r_Lg_Ship_Plan.Transfer_Price_Apply_Type IS NOT NULL THEN
              PKG_BD_PRICE.P_APPLY_UNLOCK(P_APPLY_DETAIL_ID => r_Lg_Ship_Plan.Transfer_Price_Line_Id,
                                          P_UNLOCK_CNT      => p_Trans_Carry_Qty,
                                          P_BILL_NO         => r_Lg_Ship_Plan.Origin_Order_Num,
                                          P_RETURN_CODE     => v_Value,
                                          P_RETURN_MSG      => p_Result);
              IF v_Value = '1' THEN --返回1表示成功
                p_Result := v_Success;
                v_Value := v_Success;
              ELSE
                v_Value := '批文号：'||r_Lg_Ship_Plan.Transfer_Price_Apply_Code||
                           '，产品编码：'||r_Lg_Ship_Plan.Item_Code||
                           '，数量：' || to_char(p_Trans_Carry_Qty)||v_Nl||
                           '解锁分部客户批文数量失败，错误信息：' || p_Result;
                Raise v_Base_Exception;
              END IF;
            END IF;
          ELSE
            pkg_pln_lg_order.p_Update_Lg_Order_Direct_Qty(
                 In_Lg_Order_Id => r_Lg_Ship_Plan.Agent_Order_Id,
                 In_Lg_Order_Line_Id => r_Lg_Ship_Plan.Agent_Order_Line_Id,
                 In_Qty => p_Trans_Carry_Qty,
                 In_Qty_Sign => -1,
                 In_User_Code => in_user_code,
                 Out_Result => p_Result
            );
            IF p_Result <> v_Success THEN
              v_Value := '回写CIMS代理商订单失败：' || p_Result || v_Nl ||
                         '代理商订单号：' || r_Lg_Ship_Plan.Agent_Order_Number || v_Nl ||
                         '计划订单号：' || r_Lg_Ship_Plan.Origin_Order_Num || v_Nl ||
                         '发货仓库：' || r_Lg_Ship_Plan.Ship_Inventory_Code || v_Nl ||
                         '产品编码：' || r_Lg_Ship_Plan.Item_Code;
              Raise v_Base_Exception;
            END IF;
          END IF;
        END IF;
      End If;
    End;
    
    --hejy3 预约直发处理
    if r_lg_ship_plan.direct_transport_falg = 'Y' and (nvl(r_lg_ship_plan.direct_status, '_') <> '01' or p_Trans_Sign_Flag = -1) Then
      --不管有没有工单，计划订单行上的都有更新
      update t_pln_order_line l
         set l.direct_transport_qty = nvl(l.direct_transport_qty, 0) + p_Trans_Sign_Flag * p_Trans_Carry_Qty,
             l.last_updated_by = in_user_code,
             l.last_update_date = sysdate,
             l.version = nvl(l.version, 0) + 1
       where l.order_line_id = V_PLN_ORDER_LINE_ID;
      --判断工单号是否为空
      If r_lg_ship_plan.wip_entity_code Is not Null Then
        Update t_Pln_Wip_Order_Relation r
           Set r.Direct_Transport_Qty = Nvl(r.Direct_Transport_Qty, 0) +
                                        p_Trans_Sign_Flag *
                                        p_Trans_Carry_Qty,
               r.Last_Updated_By      = In_User_Code,
               r.Last_Update_Date     = Sysdate,
               r.Version              = Nvl(r.Version, 0) + 1
         Where r.Order_Line_Id = v_Pln_Order_Line_Id
           And r.Wip_Entity_Code = r_Lg_Ship_Plan.Wip_Entity_Code;
        
       --有工单，取消操作的，判断工单是否全部取消完成，直接写接口
        If p_Trans_Sign_Flag = -1 Then
          Insert Into Intf_Pln_Wip_Direct_Info
            (Intf_Id,
             Entity_Id,
             Organization_Code,
             Wip_Entity_Code,
             Direct_Transport_Flag,
             Direct_Transport_Date,
             Intf_Status,
             Created_By,
             Creation_Date,
             Last_Updated_By,
             Last_Update_Date)
            Select s_Intf_Pln_Wip_Direct_Info.Nextval,
                   r.Entity_Id,
                   o.Organization_Code,
                   r.Wip_Entity_Code,
                   'N',
                   Null,
                   'N',
                   In_User_Code,
                   Sysdate,
                   In_User_Code,
                   Sysdate
              From t_Pln_Wip_Order_Relation r, t_Inv_Organization o
             Where r.Direct_Transport_Flag = 'Y'
               And r.Entity_Id = In_Entity_Id
               And o.Entity_Id = r.Entity_Id
               And o.Organization_Id = r.Organization_Id
               And Nvl(r.Direct_Transport_Qty, 0) = 0
               And r.Wip_Entity_Code = r_Lg_Ship_Plan.Wip_Entity_Code
               And r.Order_Line_Id = v_Pln_Order_Line_Id
               And Not Exists
             (Select 1
                      From t_Pln_Wip_Order_Relation Wor
                     Where Wor.Wip_Entity_Code = r.Wip_Entity_Code
                       And Wor.Direct_Transport_Flag = 'Y'
                       And Nvl(Wor.Direct_Transport_Qty, 0) > 0);
        End If;
      End If;
    else
      Begin
        Select Bi.Sales_Main_Type
          Into v_Sales_Main_Type
          From t_Bd_Item Bi
         Where Bi.Item_Code = r_Share_Ship.Item_Code
           And Bi.Entity_Id = in_entity_id;
      Exception
        When Others Then
          p_Result := '获取产品大类换败，产品编码:' || r_Share_Ship.Item_Code || Sqlerrm;
          Raise v_Base_Exception;
      End;

      Begin
        --更新分配表
        v_Value := '更新分配表下达数量';
        Update t_Pln_Order_Share_Shipment Oss
           Set Oss.Carry_Qty        = Nvl(Oss.Carry_Qty, 0) +
                                      p_Trans_Carry_Qty * p_Trans_Sign_Flag,
               Oss.Carrying_Qty     = Nvl(Oss.Share_Qty, 0) -
                                      p_Trans_Carry_Qty * p_Trans_Sign_Flag -
                                      Nvl(Oss.Carry_Qty, 0),
               Oss.Last_Updated_By  = in_user_code,
               Oss.Last_Update_Date = Sysdate,
               Oss.Plan_Send_Date   = Null,
               Oss.Version = Nvl(Oss.Version, 0) + 1,
               Oss.Lg_Order_Head_Id = Null,  --add by lizhen 2015-03-18
               Oss.Lg_Order_Line_Id = Null   --add by lizhen 2015-03-18
         Where Oss.Order_Share_Id = r_Share_Ship.Order_Share_Id
           And Oss.Entity_Id = in_entity_id
           --add by lizhen 2015-02-12 增加返回更新后的数量为负数量报异常
           Returning Oss.Carry_Qty Into v_Carry_Qty;
       If Nvl(v_Carry_Qty, 0) < 0 Then
         v_Value := '更新失败，更新后的可下达数量为负数！' || v_Nl ||
           '更新后的下达数量：' || To_Char(v_Carry_Qty);
         Raise v_Base_Exception;
       End If;
       --add by zcc
        if p_Trans_Sign_Flag = -1 and r_Share_Ship.Lg_Order_Head_Id is Null
          --modi by lizhen 2015-10-20 增加判断发运计划只更新计划订单来源数据
           And Nvl(r_Lg_Ship_Plan.Origin_Origin_Type, '_') = '_'
           And Nvl(r_lg_ship_plan.origin_type, '_') = '01' And r_Share_Ship.Lg_Order_Line_Id is null then
          if r_lg_ship_plan.project_order_line_id is not null and
             r_lg_ship_plan.project_order_head_id is not null then
            pkg_bd_price.P_APPLY_UNLOCK(r_lg_ship_plan.project_order_line_id, --批文明细ID
                                        p_Trans_Carry_Qty, --释放锁定数量
                                        r_lg_ship_plan.origin_order_num, -- 关联单号
                                        v_return_code, --返回编码，1成功，0失败
                                        v_Value --返回提示信息
                                        );
            if v_return_code = 0 then
              Raise v_Base_Exception;
            end if;
          end if;
        End if;
       -- end;
        v_Value := '更新分配状态';
        Update t_Pln_Order_Share_Shipment Oss
           Set Oss.Close_Flag = Decode(Oss.Share_Qty,
                                       Oss.Carry_Qty,
                                       v_True,
                                       v_False)
         Where Oss.Order_Share_Id = r_Share_Ship.Order_Share_Id
           And Oss.Entity_Id = in_entity_id
           And Oss.Carry_Qty Is Not Null;
        
        if r_lg_ship_plan.direct_transport_falg = 'Y' and r_lg_ship_plan.direct_status = '01' and p_Trans_Sign_Flag = 1 then
          --更新已直发数量，不管有没有工单，更新计划订单行的
          update t_pln_order_line l
             set l.already_direct_transport_qty = nvl(l.already_direct_transport_qty, 0) + p_Trans_Sign_Flag * p_Trans_Carry_Qty
           where l.order_line_id = V_PLN_ORDER_LINE_ID;
          --有工单
          If r_lg_ship_plan.wip_entity_code Is Not Null Then
            update t_pln_wip_order_relation l
               set l.already_direct_transport_qty = nvl(l.already_direct_transport_qty, 0) + p_Trans_Sign_Flag * p_Trans_Carry_Qty
             where l.order_line_id = V_PLN_ORDER_LINE_ID
               And l.wip_entity_code = r_lg_ship_plan.wip_entity_code;
          End If;
          
          --更新分配承运商表来源制定发货需求计划ID
          update t_lg_ship_plan p
             set p.origin_ship_plan_id = r_Share_Ship.Order_Share_Id
           where p.ship_plan_id = r_lg_ship_plan.ship_plan_id;
          
          --更新发货通知单行来源制定发货需求计划ID
          update t_lg_ship_doc_line l
             set l.origin_ship_plan_id = r_Share_Ship.Order_Share_Id
           where l.ship_plan_id = r_lg_ship_plan.ship_plan_id;
          
          --更新实发行的来源制定发货需求计划ID
          update t_lg_actual_ship_line l
             set l.origin_ship_plan_id = r_Share_Ship.Order_Share_Id
           where l.ship_doc_line_id in
                 (select dl.ship_doc_line_id
                    from t_lg_ship_doc_line dl
                   where dl.ship_plan_id = r_lg_ship_plan.ship_plan_id);
        end if;

        --更新计划订单行
        v_Value := '更新计划订单行下达数量';
        Update t_Pln_Order_Line Pol
           Set Pol.Carry_Qty        = Nvl(Pol.Carry_Qty, 0) +
                                      p_Trans_Carry_Qty * p_Trans_Sign_Flag,
               Pol.Last_Updated_By  = in_user_code,
               Pol.Last_Update_Date = Sysdate,
               Pol.Begin_Carry_Date = Nvl(Pol.Begin_Carry_Date, Trunc(Sysdate)),
               Pol.End_Carry_Date   = Trunc(Sysdate),
               Pol.Version = Nvl(Pol.Version, 0) + 1
         Where Pol.Order_Line_Id = r_Share_Ship.Origin_Line_Id
           And Pol.Order_Head_Id = r_Share_Ship.Origin_Head_Id
           And Pol.Entity_Id = in_entity_id;
        If Sql%Notfound Then
          v_Value := '更新计划订单行下达数量失败，订单行ID：' ||
                     To_Char(r_Share_Ship.Origin_Line_Id);
          Raise v_Base_Exception;
        End If;

        --更新计划订单明细行
        v_Value := '更新订单明细行下达数量';
        Update t_Pln_Order_Detail Pod
           Set Pod.Carry_Qty        = Nvl(Pod.Carry_Qty, 0) +
                                      p_Trans_Carry_Qty * p_Trans_Sign_Flag *
                                      --add by lizhen 2015-09-17 增加套散件已下达数量更新时，必须*散件基数
                                      f_Get_Item_Assembly_Base(p_Ass_Item_Id => r_Share_Ship.Item_Id,
                                                               p_Sub_Item_Id => Pod.Item_Id),
               Pod.Last_Updated_By  = in_user_code,
               Pod.Last_Update_Date = Sysdate,
               Pod.Version          = Nvl(Pod.Version, 0) + 1
         Where Pod.Order_Line_Id = r_Share_Ship.Origin_Line_Id
           And Pod.Order_Head_Id = r_Share_Ship.Origin_Head_Id
           And Pod.Entity_Id = in_entity_id;
        /*If Sql%Notfound Then
          v_Value := '更新订单明细行下达数量，订单行ID：' ||
                     To_Char(r_Share_Ship.Origin_Line_Id);
          Raise v_Base_Exception;
        End If;*/

        --取消下达时，销售单据类型
        If p_Trans_Sign_Flag = -1 Then
          Begin
            Select St.Source_Type_Code,
                   Sp.Item_Price,
                   Sp.Discount_Rate,
                   Sp.Account_Code,
                   Sp.Customer_Id,
                   Sp.Month_Discount_Rate,
                   Sp.Discount_Type
              Into v_Source_Order_Code,
                   v_Price,
                   v_Discount_Rate,
                   v_Account_Code,
                   v_Customer_Id,
                   v_Month_Discount_Rate, --add by lizhen 2015-11-26
                   v_Discount_Type
              From t_Lg_Ship_Plan     Sp,
                   t_Inv_Bill_Types   Bt,
                   t_Inv_Source_Types St
             Where Sp.Ship_Plan_Id = p_Lg_Ship_Plan_Id
               And Sp.Sales_Order_Type_Id = Bt.Bill_Type_Id
               And Bt.Source_Type_Id = St.Source_Type_Id;
          Exception
            When Others Then
              v_Value := '获取运力任务计划行的单据类型失败，运力任务计划行ID：' ||
                         To_Char(p_Lg_Ship_Plan_Id) || v_Nl || Sqlerrm;
              Raise v_Base_Exception;
          End;
          --add by lizhen 物流发货计划取消运力时，重新取账户、客户信息解锁款项。
      --add by lizhen 2016-11-11只有销售单据类型时才进行取账户数据
          If v_Source_Order_Code = '1006' Then
            Begin
              Select Ca.Account_Id
                Into v_Account_Id
                From t_Customer_Account Ca
               Where Ca.Account_Code = v_Account_Code
                 And Ca.Entity_Id = in_entity_id;
            Exception
              When Others Then
                v_Value := '获取账户ID失败，账户编码：' || v_Account_Code || v_Nl || Sqlerrm;
                Raise v_Base_Exception;
            End;
          End If;
        End If;
        --MODI BY LIZHEN 单价与折扣率从物流运力计划表获取
        If p_Trans_Sign_Flag = -1 And v_Source_Order_Code = '1006' Then
          v_Account_Amount := (p_Trans_Carry_Qty * v_Price
            * (100 - nvl(v_Discount_Rate, 0) - Nvl(v_Month_Discount_Rate, 0))) / 100;
          v_Discount_Amount := (p_Trans_Carry_Qty * v_Price
            * nvl(v_Discount_Rate, 0)) / 100;
          --2015-07-16 add by lizhen 上级来源类型不是提货订单时则在该发货计划释放款项
          If Nvl(r_Lg_Ship_Plan.Origin_Origin_Type, '0') <> '02'
            And Nvl(r_Share_Ship.Lock_Amount_Flag, v_Default_Lock_Amount_Flag) in(V_LOCK_AMOUNT_FLAG_Y) Then
            pkg_pln_pub.P_CUSTOMER_AMOUNT_PROCESS(IN_ENTITY_ID       => in_entity_id,
                                                  IN_ORDER_TYPE_ID   => r_Order_Header.Order_Type_Id,
                                                  IN_ORDER_TYPE_CODE => r_Order_Header.Order_Type_Code,
                                                  IN_CUSTOMER_ID     => v_Customer_Id,
                                                  IN_ACCOUNT_ID      => v_Account_Id,
                                                  IN_SALES_MAIN_TYPE => nvl(r_order_line.sales_main_type, v_Sales_Main_Type),
                                                  IN_ACTION_TYPE     => 2,
                                                  IN_SOURCE_TYPE     => '01',
                                                  IN_ORDER_ID        => r_Share_Ship.Origin_Head_Id,
                                                  IN_PROJ_NUMBER     => null,
                                                  IN_DISCOUNT_TYPE   => nvl(r_Lg_Ship_Plan.Discount_Type, v_Discount_Type_Common),
                                                  IN_AMOUNT          => Round(v_Account_Amount, 2),
                                                  IN_DIS_AMOUNT      => Round(v_Discount_Amount, 2),
                                                  IN_RECORD_ERR      => 'N',
                                                  IN_USER_CODE       => in_user_code,
                                                  OUT_RESULT         => p_Result);
            if p_Result <> v_Success then
              v_Value := '取消发货（制定发货需求计划）处理客户款项失败！' || v_Nl || p_Result;
              Raise v_Base_Exception;
            end if;
            
          End If;
          
          --计划订单锁订金处理
          If Nvl(r_Lg_Ship_Plan.Origin_Origin_Type, '0') <> '02'
            And Nvl(r_Share_Ship.Lock_Amount_Flag, v_Default_Lock_Amount_Flag) in(V_LOCK_AMOUNT_FLAG_S) Then
            pkg_pln_pub.P_CUSTOMER_AMOUNT_PROCESS(IN_ENTITY_ID       => in_entity_id,
                                                  IN_ORDER_TYPE_ID   => r_Order_Header.Order_Type_Id,
                                                  IN_ORDER_TYPE_CODE => r_Order_Header.Order_Type_Code,
                                                  IN_CUSTOMER_ID     => v_Customer_Id,
                                                  IN_ACCOUNT_ID      => v_Account_Id,
                                                  IN_SALES_MAIN_TYPE => nvl(r_order_line.sales_main_type, v_Sales_Main_Type),
                                                  IN_ACTION_TYPE     => 29,
                                                  IN_SOURCE_TYPE     => '01',
                                                  IN_ORDER_ID        => r_Share_Ship.Origin_Head_Id,
                                                  IN_PROJ_NUMBER     => null,
                                                  IN_DISCOUNT_TYPE   => nvl(r_Lg_Ship_Plan.Discount_Type, v_Discount_Type_Common),
                                                  IN_AMOUNT          => Round(v_Account_Amount, 2),
                                                  IN_DIS_AMOUNT      => Round(v_Discount_Amount, 2),
                                                  IN_RECORD_ERR      => 'N',
                                                  IN_USER_CODE       => in_user_code,
                                                  OUT_RESULT         => p_Result);
            if p_Result <> v_Success then
              v_Value := '取消发货（制定发货需求计划）处理客户款项失败！' || v_Nl || p_Result;
              Raise v_Base_Exception;
            end if;
          End If;
        End If;

        --add by xuhongjiu 2016-01-11
        --如果是多主体订单（计划订单客户和写到物流的客户不一样）并且是送审锁款的
        --T+3提货订单计划订单发货的为非多主体订单，不在计划订单加解锁款项
        If r_Order_Header.Account_Code <> v_Account_code And v_Source_Order_Code = '1006' And
          r_lg_ship_plan.origin_origin_type Is Null And
          r_lg_ship_plan.origin_origin_head_id Is Null And
          r_lg_ship_plan.origin_origin_line_id Is Null And
          nvl(r_lg_ship_plan.Lock_Amount_Flag,'_') = V_LOCK_AMOUNT_FLAG_S Then

            --取消
            If p_Trans_Sign_Flag = -1 Then
              pkg_pln_pub.P_CUSTOMER_AMOUNT_PROCESS(IN_ENTITY_ID       => in_entity_id,
                                                    IN_ORDER_TYPE_ID   => r_Order_Header.Order_Type_Id,
                                                    IN_ORDER_TYPE_CODE => r_Order_Header.Order_Type_Code,
                                                    IN_CUSTOMER_ID     => v_Customer_id,
                                                    IN_ACCOUNT_ID      => v_Account_id,
                                                    IN_SALES_MAIN_TYPE => nvl(r_order_line.sales_main_type, v_Sales_Main_Type),
                                                    IN_ACTION_TYPE     => 2,
                                                    IN_SOURCE_TYPE     => '01',
                                                    IN_ORDER_ID        => r_Share_Ship.Origin_Head_Id,
                                                    IN_PROJ_NUMBER     => null,
                                                    IN_DISCOUNT_TYPE   => nvl(r_Lg_Ship_Plan.Discount_Type, v_Discount_Type_Common),
                                                    IN_AMOUNT          => Round(v_Account_Amount, 2),
                                                    IN_DIS_AMOUNT      => Round(v_Discount_Amount, 2),
                                                    IN_RECORD_ERR      => 'N',
                                                    IN_USER_CODE       => in_user_code,
                                                    OUT_RESULT         => p_Result);
              if p_Result <> v_Success then
                v_Value := '取消发货（制定发货需求计划，多主体采购）处理客户款型失败！' || v_Nl || p_Result;
                Raise v_Base_Exception;
              end if;

             Begin
               --增加本来计划订单的客户的锁款
               Select l.item_price,
                      l.discount_rate,
                      l.ordered_discount_rate
                 Into v_New_Price,
                      v_New_Discount_Rate,
                      v_New_Month_Discount_Rate
                 From t_Pln_Order_Line l
                Where l.order_line_id = r_Share_Ship.Origin_Line_Id;
             Exception
               When Others Then
                v_Value := '查询计划行表信息失败，订单行ID：' || r_Share_Ship.Origin_Line_Id || v_Nl || Sqlerrm;
               Raise v_Base_Exception;
              End;

              v_New_Account_Amount := (p_Trans_Carry_Qty * v_New_Price
                * (100 - nvl(v_New_Discount_Rate, 0) - Nvl(v_New_Month_Discount_Rate, 0))) / 100;
             v_New_Discount_Amount := (p_Trans_Carry_Qty * v_New_Price
                * nvl(v_New_Discount_Rate, 0)) / 100;
             pkg_pln_pub.P_CUSTOMER_AMOUNT_PROCESS(IN_ENTITY_ID       => in_entity_id,
                                                   IN_ORDER_TYPE_ID   => r_Order_Header.Order_Type_Id,
                                                   IN_ORDER_TYPE_CODE => r_Order_Header.Order_Type_Code,
                                                   IN_CUSTOMER_ID     => r_Order_Header.Customer_Id,
                                                   IN_ACCOUNT_ID      => r_Order_Header.Account_Id,
                                                   IN_SALES_MAIN_TYPE => nvl(r_order_line.sales_main_type, v_Sales_Main_Type),
                                                   IN_ACTION_TYPE     => 1,
                                                   IN_SOURCE_TYPE     => '01',
                                                   IN_ORDER_ID        => r_Share_Ship.Origin_Head_Id,
                                                   IN_PROJ_NUMBER     => null,
                                                   IN_DISCOUNT_TYPE   => nvl(r_Lg_Ship_Plan.Discount_Type, v_Discount_Type_Common),
                                                   IN_AMOUNT          => Round(v_New_Account_Amount, 2),
                                                   IN_DIS_AMOUNT      => Round(v_New_Discount_Amount, 2),
                                                   IN_RECORD_ERR      => 'N',
                                                   IN_USER_CODE       => in_user_code,
                                                   OUT_RESULT         => p_Result);
             if p_Result <> v_Success then
               v_Value := '取消发货（制定发货需求计划，多主体采购）处理客户款型失败！' || v_Nl || p_Result;
               Raise v_Base_Exception;
             end if;
             
          End If;
        End If;

        Begin
          If p_Result = v_Success Then
            v_Value := '插入单据操作历史记录';
            Insert Into t_Pln_Order_Share_History
              (Order_Share_History_Id, --
               Entity_Id, --
               Order_Header_Id, --
               Order_Line_Id, --
               Order_Share_Id, --
               Item_Id, --
               Item_Code, --
               Item_Name, --
               Inventory_From_Id, --
               Option_Type, --
               Quantity, --
               Batch_Tran_Id, --自动分配批ID
               Base_Allot_Flag, --基地间调拨
               Sales_Order_Type_Id, --单据类型ID
               Discount_Type_Id, --折扣类型ID
               Created_By, --
               Creation_Date, --
               Last_Updated_By, --
               Last_Update_Date, --
               Remark, --
               Is_Pick_Flag,    --自提标志
               Is_Cusg_Flag,    --直发标志
               Lg_Shap_Doc_Id,   --自提生成物流提货单ID
               Pre_Field_01,     --接收仓库ID
               Lg_Order_Head_Id,
               Lg_Order_Line_Id
               )
              Select s_Pln_Order_Share_History.Nextval,
                     r_Share_Ship.Entity_Id,
                     r_Share_Ship.Origin_Head_Id,
                     r_Share_Ship.Origin_Line_Id,
                     r_Share_Ship.Order_Share_Id,
                     r_Share_Ship.Item_Id,
                     r_Share_Ship.Item_Code,
                     r_Share_Ship.Item_Name,
                     r_Share_Ship.Inventory_From_Id,
                     Decode(p_Trans_Sign_Flag,
                            '1',
                            '运力任务下达',
                            -1,
                            '撤消运力任务计划',
                            '未知操作'),
                     p_Trans_Carry_Qty * p_Trans_Sign_Flag,
                     Null,
                     Null,
                     r_Share_Ship.Sales_Order_Type_Id,
                     r_Share_Ship.Discount_Rate,
                     in_user_code,
                     Sysdate,
                     in_user_code,
                     Sysdate,
                     '订单分配下达！单据类型ID：' ||
                     To_Char(r_Share_Ship.Sales_Order_Type_Id),
                     r_Share_Ship.Is_Pick_Flag,
                     r_Share_Ship.Is_Cusg_Flag,
                     r_Share_Ship.Pre_Field_04,   --发货通知单ID
                     To_Char(r_Share_Ship.Inventory_To_Id), --接收仓库ID
                     Decode(p_Trans_Sign_Flag,
                            -1,
                            r_Lg_Ship_Plan.Origin_Origin_Head_Id,
                            r_Share_Ship.Lg_Order_Head_Id),
                     Decode(p_Trans_Sign_Flag,
                            -1,
                            r_Lg_Ship_Plan.Origin_Origin_Line_Id,
                            r_Share_Ship.Lg_Order_Line_Id)      
                From Dual;
          End If;
        Exception
          When Others Then
            Rollback;
            p_Result := v_Value || Sqlerrm;
            Return;
        End;
      End;
      
    end if;
  Exception
    When v_Base_Exception Then
      Rollback;
      p_Result := v_Value;
    When Others Then
      Rollback;
      p_Result := v_Value || '失败,错误信息:' || Sqlerrm;
      Return;
  End;

  -----------------------------------------------------------------------------------------
  --Anthor: Nicro.Li
  --Purpost: 更新开单数量
  -------------------------------------------------------------------------------------------
  Procedure p_Upd_Pln_So_Order_Qty(p_Order_Share_Id   In Number, --行ID
                                   p_So_Order_Line_Id In Number,  --销售单行ID add by lizhen 2016-02-26
                                   p_Trans_Order_Qty  In Number, --开单数量
                                   p_Trans_Sign_Flag  In Number, --符号方向,开单：1  红冲：-1
                                   p_Entity_Id        In Number, --主体ID
                                   p_User_Code        In Varchar2, --用户编码
                                   p_Result           Out Varchar2, --成功返回'SUCCESS' 否则返回错误信息
                                   p_Cusg_Ord_Plan_Id In Number Default Null --直发客户行ID
                                   ) Is
    v_Value      Varchar2(2000);
    r_Share_Ship t_Pln_Order_Share_Shipment%Rowtype;
    v_Carry_Qty     Number;
    v_So_Order_Qty  Number;
    r_So_Header     t_so_header%Rowtype;
    v_Is_Business_Control  Varchar2(32);
  Begin
    p_Result := v_Success;
    --参数校验
    If p_Trans_Order_Qty = 0 Then
      Return;
    End If;
    --SAVEPOINT UPD_SO_ORDER_QTY;
    If Not (p_Trans_Sign_Flag = 1 Or p_Trans_Sign_Flag = -1) Then
      p_Result := '参数 p_Trans_Sign_Flag 错误';
      Return;
    End If;

    --add by lizhen 2016-02-25 T+3提货订单对应的销售单据（计划订单发货）不需要更新分配行信息，也不需重新加锁库存
    If p_Trans_Sign_Flag = -1 And p_So_Order_Line_Id Is Not Null Then
      Begin
        Select *
          Into r_So_Header
          From t_So_Header Tsh
         Where Exists (Select 1
                  From t_So_Line Tsl
                 Where Tsl.So_Header_Id = Tsh.So_Header_Id
                   And Tsl.So_Line_Id = p_So_Order_Line_Id);
      Exception
        When Others Then
          p_Result := '获取销售单据信息失败，销售单行ID：' || To_Char(p_So_Order_Line_Id);
          Return;
      End;
      If Nvl(r_So_Header.Origin_Origin_Type, '_') = '02' And r_So_Header.Origin_Origin_Head_Id Is Not Null Then
        --add by lizhen 2016-04-06 发货计划提货订单需要回写计划订单发货计划已下达、已开单数
        Begin
          Select Upper(Pot.Is_Business_Control)
            Into v_Is_Business_Control
            From t_Pln_Lg_Order_Head Loh, t_Pln_Order_Type Pot
           Where Loh.Order_Head_Id = r_So_Header.Origin_Origin_Head_Id
             And Pot.Order_Type_Id = Loh.Order_Type_Id;
          If Nvl(v_Is_Business_Control, '_') != 'SHARE_SHIP_ORDER' Then
            Return;
          End If;
        Exception
          When Others Then
            p_Result := '获取提货订单单据信息失败。提货订单头ID：' ||
                        To_Char(r_So_Header.Origin_Origin_Head_Id);
            Return;
        End;
      End If;
    End If;

    Begin
      Select *
        Into r_Share_Ship
        From t_Pln_Order_Share_Shipment Oss
       Where Oss.Order_Share_Id = p_Order_Share_Id
         And Oss.Entity_Id = p_Entity_Id;
    Exception
      When Others Then
        p_Result := '找不到对应数据:行ID:' || To_Char(p_Order_Share_Id) || Sqlerrm;
        Return;
    End;

    --更新分配表开单数量
    v_Value := '更新分配表开单数量';
    Update t_Pln_Order_Share_Shipment Oss
       Set Oss.So_Order_Qty = Nvl(Oss.So_Order_Qty, 0) +
                              p_Trans_Order_Qty * p_Trans_Sign_Flag,
           --红冲销售单据时，需重新发货，更新已下达数量
           Oss.Carry_Qty        = Decode(p_Trans_Sign_Flag,
                                         1,
                                         Oss.Carry_Qty,
                                         -1,
                                         Nvl(Oss.Carry_Qty, 0) +
                                         p_Trans_Order_Qty *
                                         p_Trans_Sign_Flag),
           Oss.Close_Flag       = Decode(Sign(Nvl(Oss.Share_Qty, 0) -
                                              Decode(p_Trans_Sign_Flag,
                                                     1,
                                                     Oss.Carry_Qty,
                                                     -1,
                                                     Nvl(Oss.Carry_Qty, 0) +
                                                     p_Trans_Order_Qty *
                                                     p_Trans_Sign_Flag)),
                                         0,
                                         v_True,
                                         v_False),
           Oss.Carrying_Qty    = Nvl(Oss.Share_Qty, 0) -
                                  Decode(p_Trans_Sign_Flag,
                                         1,
                                         Oss.Carry_Qty,
                                         -1,
                                         Nvl(Oss.Carry_Qty, 0) +
                                         p_Trans_Order_Qty *
                                         p_Trans_Sign_Flag),
           Oss.Last_Updated_By  = p_User_Code,
           Oss.Last_Update_Date = Sysdate,
           Oss.Version = Nvl(Oss.Version, 0) + 1
     Where Oss.Order_Share_Id = r_Share_Ship.Order_Share_Id
       And Oss.Entity_Id = p_Entity_Id
       Returning Oss.Carry_Qty, Oss.So_Order_Qty Into v_Carry_Qty, v_So_Order_Qty;
    --add by lizhen 2015-02-12 增加返回更新后的数量为负数量报异常
    If Nvl(v_Carry_Qty, 0) < 0 Or Nvl(v_So_Order_Qty, 0) < 0 Then
      v_Value := '更新失败，更新后的可下达数量为负数、或者已销售开单数量为负数！' || v_Nl ||
        '更新后的下达数量：' || To_Char(v_Carry_Qty) || v_Nl ||
        '更新后的已开单数量：' || To_Char(v_So_Order_Qty);
      Raise v_Base_Exception;
    End If;

    v_Value := '更新订单行开单数量';
    Update t_Pln_Order_Line Pol
       Set Pol.So_Order_Qty = Nvl(Pol.So_Order_Qty, 0) +
                              p_Trans_Order_Qty * p_Trans_Sign_Flag,
           --红冲销售单据时，需重新发货，更新已下达数量
           Pol.Carry_Qty           = Decode(p_Trans_Sign_Flag,
                                            1,
                                            Pol.Carry_Qty,
                                            -1,
                                            Nvl(Pol.Carry_Qty, 0) +
                                            p_Trans_Order_Qty *
                                            p_Trans_Sign_Flag),
           Pol.Last_Updated_By     = p_User_Code,
           Pol.Last_Update_Date    = Sysdate,
           Pol.Begin_So_Order_Date = Nvl(Pol.Begin_So_Order_Date,
                                         Trunc(Sysdate)),
           Pol.End_So_Order_Date   = Trunc(Sysdate),
           Pol.Version = Nvl(Pol.Version, 0) + 1
     Where Pol.Order_Line_Id = r_Share_Ship.Origin_Line_Id
       And Pol.Order_Head_Id = r_Share_Ship.Origin_Head_Id
       And Pol.Entity_Id = p_Entity_Id;
    If Sql%Notfound Then
      v_Value := '更新计划订单行下达数量失败，订单行ID：' ||
                 To_Char(r_Share_Ship.Origin_Line_Id);
      Raise v_Base_Exception;
    End If;

    --更新计划订单明细行开单数量
    v_Value := '更新订单明细行开单数量';
    Update t_Pln_Order_Detail Pod
       Set Pod.So_Order_Qty = Nvl(Pod.So_Order_Qty, 0) +
                              p_Trans_Order_Qty * p_Trans_Sign_Flag *
                             --add by lizhen 2015-09-17 增加套散件已下达数量更新时，必须*散件基数
                              f_Get_Item_Assembly_Base(p_Ass_Item_Id => r_Share_Ship.Item_Id,
                                                       p_Sub_Item_Id => Pod.Item_Id),
           --红冲销售单据时，需重新发货，更新已下达数量
           Pod.Carry_Qty        = Decode(p_Trans_Sign_Flag,
                                         1,
                                         Pod.Carry_Qty,
                                         -1,
                                         Nvl(Pod.Carry_Qty, 0) +
                                          p_Trans_Order_Qty *
                                          p_Trans_Sign_Flag *
                                         --add by lizhen 2015-09-17 增加套散件已下达数量更新时，必须*散件基数
                                          f_Get_Item_Assembly_Base(p_Ass_Item_Id => r_Share_Ship.Item_Id,
                                                                   p_Sub_Item_Id => Pod.Item_Id)),
           Pod.Last_Updated_By  = p_User_Code,
           Pod.Last_Update_Date = Sysdate,
           Pod.Version          = Nvl(Pod.Version, 0) + 1
     Where Pod.Order_Line_Id = r_Share_Ship.Origin_Line_Id
       And Pod.Order_Head_Id = r_Share_Ship.Origin_Head_Id
       And Pod.Entity_Id = p_Entity_Id;
    /*If Sql%Notfound Then
      v_Value := '更新订单明细行开单数量，订单行ID：' ||
                 To_Char(r_Share_Ship.Origin_Line_Id);
      Raise v_Base_Exception;
    End If;*/

    v_Value := '更新计划订单行开单数量';
    Update t_Pln_Order_Line Pol
       Set Pol.Status           = Decode(Sign(Nvl(Pol.Can_Produce_Qty, 0) +
                                              Nvl(Pol.Inv_Affirm_Qty, 0) -
                                              Nvl(Pol.Cancel_Inv_Check_Qty,
                                                  0) -
                                              Nvl(Pol.Cancel_Inv_In_Qty, 0) -
                                              Nvl(Pol.So_Order_Qty, 0)),
                                         1,
                                         '32', --已排产
                                         '306'), --已完成
           Pol.Last_Updated_By  = p_User_Code,
           Pol.Last_Update_Date = Sysdate,
           Pol.Version = Nvl(Pol.Version, 0) + 1
     Where Pol.Order_Line_Id = r_Share_Ship.Origin_Line_Id
       And Pol.Order_Head_Id = r_Share_Ship.Origin_Head_Id
       And Pol.Entity_Id = p_Entity_Id;

    v_Value := '更新计划订单头表状态';
    Update t_Pln_Order_Head Poh
       Set Poh.Form_State      =
           (Select Decode(Sign(Sum(Nvl(Pol.Can_Produce_Qty, 0)) +
                               Sum(Nvl(Pol.Inv_Affirm_Qty, 0)) -
                               Sum(Nvl(Pol.Cancel_Inv_Check_Qty, 0)) -
                               Sum(Nvl(Pol.Cancel_Inv_In_Qty, 0)) -
                               Sum(Nvl(Pol.So_Order_Qty, 0))),
                          1,
                          '32', --已排产
                          '306' --已完成
                          )
              From t_Pln_Order_Line Pol
             Where Pol.Order_Head_Id = Poh.Order_Head_Id),
           Poh.Last_Updated_By  = p_User_Code,
           Poh.Last_Update_Date = Sysdate,
           Poh.Version = Nvl(Poh.Version, 0) + 1
     Where Poh.Order_Head_Id = r_Share_Ship.Origin_Head_Id;
    If Sql%Notfound Then
      v_Value := '更新计划订单头状态失败，订单头ID：' ||
                 To_Char(r_Share_Ship.Origin_Head_Id);
      Raise v_Base_Exception;
    End If;

    Begin
      If p_Result = v_Success Then
        v_Value := '插入单据操作历史记录';
        Insert Into t_Pln_Order_Share_History
          (Order_Share_History_Id, --
           Entity_Id, --
           Order_Header_Id, --
           Order_Line_Id, --
           Order_Share_Id, --
           Item_Id, --
           Item_Code, --
           Item_Name, --
           Inventory_From_Id, --
           Option_Type, --
           Quantity, --
           Batch_Tran_Id, --自动分配批ID
           Base_Allot_Flag, --基地间调拨
           Sales_Order_Type_Id, --单据类型ID
           Discount_Type_Id, --折扣类型ID
           Created_By, --
           Creation_Date, --
           Last_Updated_By, --
           Last_Update_Date, --
           Remark, --
           Lg_Order_Head_Id,
           Lg_Order_Line_Id
           )
          Select s_Pln_Order_Share_History.Nextval,
                 r_Share_Ship.Entity_Id,
                 r_Share_Ship.Origin_Head_Id,
                 r_Share_Ship.Origin_Line_Id,
                 r_Share_Ship.Order_Share_Id,
                 r_Share_Ship.Item_Id,
                 r_Share_Ship.Item_Code,
                 r_Share_Ship.Item_Name,
                 r_Share_Ship.Inventory_From_Id,
                 Decode(p_Trans_Sign_Flag,
                        '1',
                        '销售开单',
                        -1,
                        '销售开单红冲',
                        '未知操作'),
                 p_Trans_Order_Qty * p_Trans_Sign_Flag,
                 Null,
                 Null,
                 r_Share_Ship.Sales_Order_Type_Id,
                 r_Share_Ship.Discount_Rate,
                 p_User_Code,
                 Sysdate,
                 p_User_Code,
                 Sysdate,
                 '订单发货计划销售开单数量更新！单据类型ID：' ||
                 To_Char(r_Share_Ship.Sales_Order_Type_Id),
                 r_Share_Ship.Lg_Order_Head_Id,
                 r_Share_Ship.Lg_Order_Line_Id
            From Dual;
      End If;
    Exception
      When Others Then
        Rollback;
        p_Result := v_Value || Sqlerrm;
        Return;
    End;
  Exception
    When v_Base_Exception Then
      Rollback;
      p_Result := v_Value;
    When Others Then
      Rollback;
      p_Result := v_Value || '失败,错误信息:' || Sqlerrm;
      Return;
  End;

  -----------------------------------------------------------------------------------------
  --Anthor: Nicro.Li
  --Purpost: 关闭运力任务，更新提货订单、调拨申请的已评审数量
  -------------------------------------------------------------------------------------------
  Procedure p_Upd_Lgorder_Affirm_Qty(p_Lgorder_Line_Id   In Number, --行ID
                                     p_Send_Inventory_Id In Number, --发货仓库ID
                                     p_Trans_Order_Qty   In Number, --运力任务取消数量
                                     p_Trans_Sign_Flag   In Number, --符号方向,开单：1  红冲：-1
                                     p_Entity_Id         In Number, --主体ID
                                     p_User_Code         In Varchar2, --用户编码
                                     p_Result            Out Varchar2, --成功返回'SUCCESS' 否则返回错误信息
                                     p_Lg_Ship_Plan_Id  In Number Default Null --运力任务计划行ID ADD BY LIZHEN 2015-08-18
                                     ) Is
    v_Value              Varchar2(2000);
    v_Send_Inventory_Qty Number;
    v_Err_Num            Number;
    r_Lgorder_Head       t_Pln_Lg_Order_Head%Rowtype;
    r_Lgorder_Line       t_Pln_Lg_Order_Line%Rowtype;
    r_Order_Type         t_Pln_Order_Type%Rowtype;
    r_Lg_Ship_Plan       t_Lg_Ship_Plan%Rowtype;
    v_Sales_Main_Type   Varchar2(100);
    v_Source_Order_Code Varchar2(100);
    v_Count             Number;
    v_Account_Amount    Number; --结算金额
    v_Discount_Amount   Number; --折让金额
    v_Affirmed_Qty      Number;
    v_Action_Type       Number;
    V_ims_order_lock_amount_flag VARCHAR2(10);  --2015-11-23 何加源 IMS订单锁款标志
    v_Hq_Review_Flag    Varchar2(32);
    v_Ims_Opt_Type      VARCHAR2(100);
    v_Ims_Deal_Money    VARCHAR2(100);
    V_DOWN_AMOUT_FLAG   NUMBER; --20160914 hejy3 处理订金标志
    V_LG_ORDER_AMOUNT_FLAG NUMBER; --20160914 hejy3 处理提货额度标志
    V_RELEASE_AMOUNT    NUMBER; --20160914 hejy3 处理金额
    V_IS_CENTER_TRSF VARCHAR2(2); --20160913 hejy3 是否中心备货提货订单
    v_Bill_Type_Code up_codelist.code_value%TYPE; --20160913 hejy3 是否中心备货提货订单
    v_OS_ATTRIB01           Varchar2(1000);
    v_OS_ATTRIB02           Varchar2(1000);
    v_Price_Apply_Use_Discount t_bd_param_list.default_value%type := 'N'; --20170710 hejy3 价格批文开单使用折扣
    v_TRANSPORT_HIS T_PLN_DIRECT_TRANSPORT_HIS%rowtype;
    v_Hq_Affirm_Lock_Full_Amount t_bd_param_list.default_value%type := 'N';
    v_Lock_Amount_Flag t_pln_lg_order_head.lock_amount_flag%type;
    v_Operation_Type varchar2(100) := '取消发货';
    in_user_code     Varchar2(32);
    R_PLN_BOOK_HEADER T_PLN_BOOK_HEADER%rowtype; --add by huanghb12 20181204
    V_Src_Type        Varchar2(32);--add by huanghb12 20181204
    V_IS_INV_LEVEL_CONTROL  Varchar2(2);   --20180514 huanghb12 库存水位标志
    v_cancel_qty_temp       NUMBER;        --add by huanghb12 2019-3-27 存取消后的总数
    V_INV_STR         VARCHAR2(2000);
    V_JSON_MSG VARCHAR2(4000);
    v_relation_type varchar2(100);
    V_SKIP_CANCEL_AMOUNT  varchar2(2) default 'N';-- add  by houhs 增加对于家用锁款跳过释放款项处理
    V_AUTO_DIRECT  varchar2(2) default 'N';-- add  by houhs 是否是自动直发的，用于更新锁款标识
    v_lock_type varchar2(32);
  Begin
    p_Result := v_Success;
    --20180320 hejy3 增加+1处理
    If p_Trans_Sign_Flag not in (-1, 1) Then
      v_Value := '过程参数异常，p_Trans_Sign_Flag参数不是-1或1。';
      Raise v_Base_Exception;
    End If;
    If p_Trans_Order_Qty <= 0 Then
      v_Value := '过程参数异常，p_Trans_Order_Qty参数必须大于0。';
      Raise v_Base_Exception;
    End If;
    
    in_user_code := p_User_Code;
    if in_user_code is null then
      in_user_code := 'admin';
    end if;

    Begin
      Select *
        Into r_Lgorder_Line
        From t_Pln_Lg_Order_Line Lol
       Where Lol.Order_Line_Id = p_Lgorder_Line_Id
         For Update Nowait;

    Exception
      When Others Then
        v_Value := '锁定提货/调拨订单行失败,订单行ID：' || To_Char(p_Lgorder_Line_Id) || v_Nl ||
                   Sqlerrm;
        Raise v_Base_Exception;
    End;
    Begin
      Select *
        Into r_Lgorder_Head
        From t_Pln_Lg_Order_Head Oh
       Where Oh.Order_Head_Id = r_Lgorder_Line.Order_Head_Id
         And Oh.Entity_Id = r_Lgorder_Line.Entity_Id;
    Exception
      When Others Then
        v_Value := '提货/调拨订单头失败，订单头ID：' ||
                   To_Char(r_Lgorder_Line.Order_Head_Id);
        Raise v_Base_Exception;
    End;

    Begin
      --add by lizhen 2015-01-11 获取当前提货订单是否送到总部评审
      Select Case
               when r_Lgorder_Head.Submit_To_Hq_Flag = 'Y' THEN
                 'Y'
               When Nvl((Select Sum(Nvl(Lol.Hq_Affirmed_Qty, 0) + Nvl(Lol.Pln_Affirmed_Qty, 0))
                          From t_Pln_Lg_Order_Line Lol
                         Where Lol.Order_Head_Id = r_Lgorder_Line.Order_Head_Id),
                        0) > 0 Then
                'Y'
               Else
                'N'
             End
        Into v_Hq_Review_Flag
        From Dual;
    Exception
      When Others Then
        v_Value := '获取提货订单是否有送到总部评审失败，订单头ID：' ||
                   To_Char(r_Lgorder_Line.Order_Head_Id) || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;

    Begin
      Select Ot.*
        Into r_Order_Type
        From t_Pln_Order_Type Ot
       Where Ot.Order_Type_Id = r_Lgorder_Head.Order_Type_Id
         And Ot.Entity_Id = r_Lgorder_Line.Entity_Id;
    Exception
      When Others Then
        v_Value := '获取单据类型信息失败，单据类型ID：' ||
                   To_Char(r_Lgorder_Head.Order_Type_Id);
        Raise v_Base_Exception;
    End;
    
    --获取T+3订单关系表的关系类型 2019-5-16
    Begin
      Select r.Relation_Type
        Into v_Relation_Type
        From t_Pln_Lg_Relation r
       Where r.Lg_Order_Line_Id = r_Lgorder_Line.Order_Line_Id
         And r.Lg_Order_Head_Id = r_Lgorder_Line.Order_Head_Id;  
    Exception
      When Others Then
        Null;
    End;
    --20170710 hejy3 获取价格批文开单使用折扣参数
    Begin
      v_Price_Apply_Use_Discount := Pkg_Bd.f_Get_Parameter_Value('PLN_PRICE_APPLY_USE_DISCOUNT',
                                                          r_Lgorder_Head.Entity_Id);
    Exception
      When Others Then
        v_Price_Apply_Use_Discount := 'N';
    End;
    
    --获取参数:销司订单总部评审锁全款
    Begin
      v_Hq_Affirm_Lock_Full_Amount := Pkg_Bd.f_Get_Parameter_Value('PLN_HQ_AFFIRM_LOCK_FULL_AMOUNT',
                                                         r_Lgorder_Head.Entity_Id);
    Exception
      When Others Then
        v_Value := '获取销司订单总部评审锁全款参数PLN_HQ_AFFIRM_LOCK_FULL_AMOUNT参数失败！' || v_Nl ||
                      Sqlerrm;
        Raise v_Base_Exception;
    End;
    
    --20160914 hejy3 检查是否中心备货提货订单
    Begin
      Select Ucl.Code_Name
        Into v_Bill_Type_Code
        From Up_Codelist Ucl, Up_Codelist_Entity Ucle
       Where Ucl.Codetype = 'PLG_LGORDER_CENTER_TRANSFER'
         And Ucl.Id = Ucle.Codelist_Id
         And Ucl.Enabled = 0
         And Ucl.Code_Value = To_Char(r_Order_Type.Order_Type_Id)
         And Ucle.Entity_Id = r_Lgorder_Head.Entity_Id;
              
      V_IS_CENTER_TRSF := 'Y'; --20160912 hejy3 中心备货提货订单
    Exception
      When No_Data_Found Then
        V_IS_CENTER_TRSF := 'N';
      When Others Then
        v_Value := '获取中心备货提货订单单据类型的CODELIST设置失败，CODELIST编码：PLG_LGORDER_CENTER_TRANSFER' || v_Nl ||
                    Sqlerrm;
        Raise v_Base_Exception;
    End;
    
    --查询物流承运商分配信息
    If p_Lg_Ship_Plan_Id Is Not Null Then
      Begin
        Select * Into r_Lg_Ship_Plan From t_lg_ship_plan sp
        Where sp.ship_plan_id = p_Lg_Ship_Plan_Id;
      Exception
        When Others Then
          v_Value := '获取物流承运商分配表数据息失败';
          Raise v_Base_Exception;
      End;
    End If;
    
    --20180320 hejy3 预约直发不检查
    if r_Lg_Ship_Plan.Direct_Transport_Falg = 'Y' and p_Trans_Sign_Flag = 1 then
      if r_Lg_Ship_Plan.Direct_Status = '01' then --发货确认
        update t_pln_lg_order_line l
           set l.already_direct_transport_qty = nvl(l.already_direct_transport_qty, 0) + p_Trans_Order_Qty * p_Trans_Sign_Flag,
               l.pln_affirmed_qty = nvl(l.pln_affirmed_qty, 0) + p_Trans_Order_Qty * p_Trans_Sign_Flag,
               l.affirmed_quantity = nvl(l.affirmed_quantity, 0) + p_Trans_Order_Qty * p_Trans_Sign_Flag,
               l.last_updated_by = in_user_code,
               l.last_update_date = sysdate,
               l.version = nvl(l.version, 0) + 1
         where l.order_line_id = p_Lgorder_Line_Id;
        
        If r_Lgorder_Head.Order_Head_State != '304' Then
          --更新头表的订单状态
          Update t_Pln_Lg_Order_Head Loh --381
             Set Loh.Order_Head_State =
                 (Case
                   --add by tangjz 2015-12-03 如果是样机订单的取消时，不更变当前单据状态
                   when r_Order_Type.Source_Order_Type_Id = 10 then
                     Loh.Order_Head_State
                   When
                  (Select Count(1)
                     From t_Pln_Lg_Order_Line Lol
                    Where Nvl(Lol.Center_Affirm_Quantity, Lol.Quantity) - Nvl(Lol.Cancel_Qty, 0) > Nvl(Lol.Affirmed_Quantity, 0)
                      And Lol.Order_Head_Id = Loh.Order_Head_Id) > 0 Then
                     --add by lizhen 2015-11-30 增加“中心评审”状态控制，如果是中心评审的取消时，不更变当前单据状态
                     Case When r_Lg_Ship_Plan.Lg_Order_Review_Flag IN ('01', '04') or r_Order_Type.Source_Order_Type_Id = 10 Then
                       --modi by lizhen 2016-01-11 未送过总部评审的单据，更新到“中心发货”状态允许继续发货
                       Case When Loh.Order_Head_State In ('679', '381') Or
                         (Nvl(v_Hq_Review_Flag, 'N') = 'Y' And Loh.Order_Head_State = '23') Then
                         Loh.Order_Head_State
                       Else
                         '1455'
                       End
                     Else
                      '381' --存在未评审完成的行，把头设置成部份评审状态
                     End
                   Else '23' End), --hejy3 没有未发货完毕的行更新头状态为评审完毕
                 Loh.Last_Update_Date = Sysdate,
                 Loh.Last_Updated_By  = in_user_code,
                 Loh.Version = Nvl(Loh.Version, 0) + 1
           Where Loh.Order_Head_Id = r_Lgorder_Head.Order_Head_Id;
        End If;
      else
        update t_pln_lg_order_line l
           set l.direct_transport_qty = nvl(l.direct_transport_qty, 0) + p_Trans_Order_Qty * p_Trans_Sign_Flag,
               l.last_updated_by = in_user_code,
               l.last_update_date = sysdate,
               l.version = nvl(l.version, 0) + 1
         where l.order_line_id = p_Lgorder_Line_Id;
      end if;
    elsif p_Trans_Sign_Flag = -1 then
      --检查订单已评审数量，是否满足本次取消运力数量
      if r_Lg_Ship_Plan.Direct_Transport_Falg = 'Y' then
        If p_Trans_Order_Qty > Nvl(r_Lgorder_Line.Direct_Transport_Qty, 0) Then
          v_Value := '更新失败，取消预约直发数量（' || To_Char(p_Trans_Order_Qty) ||
                     '）大于行已预约直发数量（' ||
                     To_Char(Nvl(r_Lgorder_Line.Direct_Transport_Qty, 0)) || '）。';
          Raise v_Base_Exception;
        End If;
      else
        If p_Trans_Order_Qty > Nvl(r_Lgorder_Line.Affirmed_Quantity, 0) Then
          v_Value := '更新失败，取消评审数量（' || To_Char(p_Trans_Order_Qty) ||
                     '）大于行已评审数量（' ||
                     To_Char(Nvl(r_Lgorder_Line.Affirmed_Quantity, 0)) || '）。';
          Raise v_Base_Exception;
        End If;
      end if;
      
      --add by huanghb12 20181126 校验预约已评审的数量Book_Affirmed_Qty（京东通过整单预约，可能存在通知单都生成后在预约的情况，导致预约评审数量是0）
      if (r_Lg_Ship_Plan.Book_Type <> 'JD' AND r_Lg_Ship_Plan.Book_Num_Cims is not null And p_Trans_Sign_Flag = -1) then
        If p_Trans_Order_Qty > Nvl(r_Lgorder_Line.Book_Affirmed_Qty, 0) Then
          v_Value := '更新失败，取消预约已评审数量（' || To_Char(p_Trans_Order_Qty) ||
                     '）大于行预约已评审数量（' ||
                     To_Char(Nvl(r_Lgorder_Line.Book_Affirmed_Qty, 0)) || '）。';
          Raise v_Base_Exception;
        End If;
      end if;
      --end huanghb12
      
      --2015-11-23 何加源 获取独资主体订单锁款标志
      IF r_Lgorder_Head.Sys_Source = 'IMS' THEN
        V_ims_order_lock_amount_flag := Pkg_Pln_Intf_Ims.f_get_Ims_Lg_Lock_flag(r_Lgorder_Head.Order_Head_Id, r_Lgorder_Head.Entity_Id);
      END IF;
      
      --ADD BY LIZHEN begin 2015-08-26 提货订单为IMS独资主体引入，发货时锁定独资主体的到款
      If r_Lgorder_Head.Sys_Source = 'IMS' And p_Trans_Sign_Flag = -1 THEN
        IF V_ims_order_lock_amount_flag = 'S' AND (r_Lg_Ship_Plan.Is_Cusg_Flag = 'Y' OR r_Lg_Ship_Plan.Pick_Flag = 'Y') THEN --2015-11-23 何加源 发货锁款才需要锁定代理商款项
          Pkg_Pln_Pub.p_Ims_Lg_Carry_Lock_Cash(p_Lg_Order_Head_Id => r_Lgorder_Head.Order_Head_Id,
                                               p_Lg_Order_Line_Id => r_Lgorder_Line.Order_Line_Id,
                                               p_Entity_Id        => r_Lgorder_Head.Entity_Id,
                                               p_Transaction_Qty  => Abs(p_Trans_Order_Qty), --当前行发货数量
                                               p_Transaction_Flag => -1, --下达事务类型：1：下达物流发货 -1：物流取消
                                               p_Result           => v_Value);
          If v_Value <> v_Success Then
              Raise v_Base_Exception;
          End If;
        END IF;
      End If;

      If r_Lgorder_Head.Sys_Source = 'IMS' And p_Trans_Sign_Flag = -1 THEN
        --XD单结转锁定且总部订单已关闭，需解锁款项
        --hejy3 20161025 增加行状态判断
        IF V_ims_order_lock_amount_flag = 'T' AND 
          (r_Lgorder_Head.Order_Head_State = '304' OR r_Lgorder_Line.Order_Line_State = 'CLOSED'
          --20161118 hejy3 转T+3后取消库存评审数量需解锁款项
           OR (r_Lg_Ship_Plan.Lg_Order_Review_Flag = '02' And r_Lgorder_Line.Make_Order_Line_Flag = 'Y')) THEN
          v_Ims_Deal_Money := '解锁款项';
        ELSE
          v_Ims_Deal_Money := '不处理款项';
        END IF;
        IF r_Lgorder_Head.Order_Head_State = '304' OR r_Lgorder_Line.Order_Line_State = 'CLOSED' THEN
          IF NVL(r_Lg_Ship_Plan.Is_Cusg_Flag, 'N') = 'Y' OR NVL(r_Lg_Ship_Plan.Pick_Flag, 'N') = 'Y' THEN
            v_Ims_Opt_Type := '关闭订单行后物流取消';
            PKG_PLN_PUB.P_WriteBack_Opt_Intf(p_Lg_Order_Head_Id => r_Lgorder_Head.Order_Head_Id, --提货订单头ID
                                             p_Lg_Order_Line_Id => r_Lgorder_Line.Order_Line_Id, --提货订单行ID
                                             p_Entity_Id        => r_Lgorder_Head.Entity_Id, --主体ID
                                             p_Opt_Type         => v_Ims_Opt_Type, --操作类型
                                             p_Transaction_Qty  => p_Trans_Sign_Flag * p_Trans_Order_Qty, --数量
                                             p_Deal_Money_Cims  => '不处理款项', --CIMS款项处理标志
                                             p_deal_Money_Ims   => v_Ims_Deal_Money, --IMS款项处理标志
                                             p_User_Code        => in_user_code, --操作用户
                                             p_Result           => v_Value);
            If v_Value <> v_Success Then
                Raise v_Base_Exception;
            End If;
          END IF;
        ELSE
          IF p_Lg_Ship_Plan_Id IS NULL OR r_Lg_Ship_Plan.Origin_Type = '02' THEN --库存评审取消才写接口
            IF NVL(r_Lg_Ship_Plan.Is_Cusg_Flag, 'N') <> 'Y' AND NVL(r_Lg_Ship_Plan.Pick_Flag, 'N') <> 'Y' THEN
              v_Ims_Opt_Type := '库存评审取消直发物流取消';
            ELSIF r_Lg_Ship_Plan.Lg_Order_Review_Flag = '02' And r_Lgorder_Line.Make_Order_Line_Flag = 'Y' THEN
              v_Ims_Opt_Type := '转计划评审后物流取消库评';
            ELSE
              v_Ims_Opt_Type := '物流取消';
            END IF;
            --2015-11-23 何加源 写操作接口过程
            PKG_PLN_PUB.P_WriteBack_Opt_Intf(p_Lg_Order_Head_Id => r_Lgorder_Head.Order_Head_Id, --提货订单头ID
                                             p_Lg_Order_Line_Id => r_Lgorder_Line.Order_Line_Id, --提货订单行ID
                                             p_Entity_Id        => r_Lgorder_Head.Entity_Id, --主体ID
                                             --p_Opt_Type         => '物流取消', --操作类型
                                             p_Opt_Type         => v_Ims_Opt_Type, --操作类型
                                             p_Transaction_Qty  => p_Trans_Sign_Flag * p_Trans_Order_Qty, --数量
                                             p_Deal_Money_Cims  => '不处理款项', --CIMS款项处理标志
                                             --p_Deal_Money_Ims   => '不处理款项', --IMS款项处理标志
                                             p_deal_Money_Ims   => v_Ims_Deal_Money, --IMS款项处理标志
                                             p_User_Code        => in_user_code, --操作用户
                                             p_Result           => v_Value);
            If v_Value <> v_Success Then
                Raise v_Base_Exception;
            End If;
          ELSIF r_Lg_Ship_Plan.Origin_Origin_Type = '02' THEN
            IF NVL(r_Lg_Ship_Plan.Is_Cusg_Flag, 'N') <> 'Y' AND NVL(r_Lg_Ship_Plan.Pick_Flag, 'N') <> 'Y' THEN
              v_Ims_Opt_Type := '总部评审取消直发物流取消';
              --2015-11-23 何加源 写操作接口过程
              PKG_PLN_PUB.P_WriteBack_Opt_Intf(p_Lg_Order_Head_Id => r_Lgorder_Head.Order_Head_Id, --提货订单头ID
                                               p_Lg_Order_Line_Id => r_Lgorder_Line.Order_Line_Id, --提货订单行ID
                                               p_Entity_Id        => r_Lgorder_Head.Entity_Id, --主体ID
                                               --p_Opt_Type         => '物流取消', --操作类型
                                               p_Opt_Type         => v_Ims_Opt_Type, --操作类型
                                               p_Transaction_Qty  => p_Trans_Sign_Flag * p_Trans_Order_Qty, --数量
                                               p_Deal_Money_Cims  => '不处理款项', --CIMS款项处理标志
                                               --p_Deal_Money_Ims   => '不处理款项', --IMS款项处理标志
                                               p_deal_Money_Ims   => v_Ims_Deal_Money, --IMS款项处理标志
                                               p_User_Code        => in_user_code, --操作用户
                                               p_Result           => v_Value);
              If v_Value <> v_Success Then
                  Raise v_Base_Exception;
              End If;
            END IF;
          End If;
        END IF;
      End If;
      
      --20160914 hejy3 移到外面
      Begin
        Select Bi.Sales_Main_Type
          Into v_Sales_Main_Type
          From t_Bd_Item Bi
         Where Bi.Item_Id = r_Lgorder_Line.Item_Id
           And Bi.Item_Code = r_Lgorder_Line.Item_Code
           And Bi.Entity_Id = r_Lgorder_Head.Entity_Id;
      Exception
        When Others Then
          v_Value := '获取产品营销大类失败，产品编码：' || r_Lgorder_Line.Item_Code || v_Nl ||
                     Sqlerrm;
          Raise v_Base_Exception;
      End;
      
      v_Lock_Amount_Flag := Nvl(r_Lgorder_Head.Lock_Amount_Flag, r_Order_Type.Chk_Cusg_Amount_Flag);
      
      IF r_Lgorder_Head.Customize_Flag = 'Y' AND p_Trans_Sign_Flag = -1
        and r_Order_Type.Source_Order_Type_Id = 1 AND V_IS_CENTER_TRSF = 'N' THEN
  
        IF r_Lgorder_Head.Order_Head_State = '304' OR --订单已关闭
           r_Lgorder_Line.Order_Line_State = 'CLOSE' OR --订单行已关闭
           --订单已送总部评审且取消中心发货数量
           --20171127 hejy3 增加销司取消处理
           (nvl(r_Lg_Ship_Plan.Lg_Order_Review_Flag, '_') = '01' AND (r_Lgorder_Head.Submit_To_Hq_Flag = 'Y' or r_Lgorder_Head.Hq_Lg_Order_Head_Id is not null)) OR
           --订单已结转T+3且取消总部评审数量
           (nvl(r_Lg_Ship_Plan.Lg_Order_Review_Flag, '_') = '02' AND r_Lgorder_Line.Make_Order_Line_Flag = 'Y') or
           --家用总部库评后转暖通的库评取消
           (nvl(r_Lg_Ship_Plan.Lg_Order_Review_Flag, '_') = '02' AND r_Lgorder_Head.Hq_Lg_Order_Head_Id is not Null) or
           v_Lock_Amount_Flag IN (V_LOCK_AMOUNT_FLAG_Y, V_LOCK_AMOUNT_FLAG_RT)
        THEN
          V_DOWN_AMOUT_FLAG := 0;
        ELSE
          V_DOWN_AMOUT_FLAG := 1;
        END IF;
        
        --正常价格列表金额
        V_RELEASE_AMOUNT  := (p_Trans_Order_Qty *
                             r_Lg_Ship_Plan.Item_Price *
                             (100 - Nvl(r_Lg_Ship_Plan.Discount_Rate, 0) -
                             Nvl(r_Lg_Ship_Plan.Month_Discount_Rate,0))) / 100;
        v_Discount_Amount := (p_Trans_Order_Qty *
                             r_Lg_Ship_Plan.Item_Price *
                             Nvl(r_Lg_Ship_Plan.Discount_Rate, 0)) / 100;
        
        --校验款项
        For r_Check_Amount In (--甲方
                               Select lol.entity_id,
                                      be.entity_name,
                                      h.customer_id,
                                      H.CUSTOMER_CODE,
                                      h.account_id,
                                      H.ACCOUNT_CODE,
                                      nvl(r_Lg_Ship_Plan.Sales_Main_Type, bi.sales_main_type) Sales_Main_Type,
                                      Nvl(r_Lg_Ship_Plan.Discount_Type, v_Discount_Type_Common) Discount_Type,                                    
                                      Sum(Round(V_RELEASE_AMOUNT
                                                * case
                                                    when lol.customize_flag = 'Y' then
                                                      -1 * (1 - V_DOWN_AMOUT_FLAG)
                                                    when nvl(lol.customize_flag, 'N') = 'N' then
                                                      case
                                                        when v_Lock_Amount_Flag in (V_LOCK_AMOUNT_FLAG_S, V_LOCK_AMOUNT_FLAG_RS, V_LOCK_AMOUNT_FLAG_HQ) then
                                                          -1 * (100 - nvl(lol.down_pay_scale, 100) * V_DOWN_AMOUT_FLAG) / 100
                                                        when v_Lock_Amount_Flag in (V_LOCK_AMOUNT_FLAG_Y, V_LOCK_AMOUNT_FLAG_RT) then
                                                          -1
                                                        else
                                                          0
                                                      end
                                                    else
                                                      0
                                                  end,2)) apply_Amount,
                                      Sum(Round(v_Discount_Amount
                                                *
                                                case
                                                  when lol.customize_flag = 'Y' then
                                                    -1 * (1 - V_DOWN_AMOUT_FLAG)
                                                  when nvl(lol.customize_flag, 'N') = 'N' then
                                                    case
                                                      when v_Lock_Amount_Flag in (V_LOCK_AMOUNT_FLAG_S, V_LOCK_AMOUNT_FLAG_RS, V_LOCK_AMOUNT_FLAG_HQ) then
                                                        -1 * (100 - nvl(lol.down_pay_scale, 100) * V_DOWN_AMOUT_FLAG) / 100
                                                      when v_Lock_Amount_Flag in (V_LOCK_AMOUNT_FLAG_Y, V_LOCK_AMOUNT_FLAG_RT) then
                                                        -1
                                                      else
                                                        0
                                                    end
                                                  else
                                                    0
                                                end,2)) Discount_Amount
                                 From t_Pln_Lg_Order_Line Lol,
                                      t_Bd_Item Bi,
                                      t_pln_lg_order_head h,
                                      v_bd_entity be
                                Where lol.order_head_id = h.order_head_id
                                  and Lol.Item_Id = Bi.Item_Id
                                  And Bi.Entity_Id = Lol.Entity_Id
                                  And Lol.Order_Head_Id = r_Lgorder_Line.Order_Head_Id
                                  And Lol.Entity_Id = r_Lgorder_Line.Entity_Id
                                  and h.entity_id = be.entity_id
                                  and lol.order_line_id = r_Lgorder_Line.Order_Line_Id
                                Group By lol.entity_id,
                                         be.entity_name,
                                         h.customer_id,
                                         h.customer_code,
                                         h.account_id,
                                         h.account_code,
                                         nvl(r_Lg_Ship_Plan.sales_main_type, bi.sales_main_type),
                                         Nvl(r_Lg_Ship_Plan.Discount_Type, v_Discount_Type_Common)
                                ) Loop
          PKG_CREDIT_ACCOUNT_CONTROL.P_CREDIT_CHECK_AMOUNT(IN_ENTITY_ID       => r_Check_Amount.Entity_Id,
                                                           IN_CUSTOMER_ID     => r_Check_Amount.Customer_Id,
                                                           IN_ACCOUNT_ID      => r_Check_Amount.Account_Id,
                                                           IN_SALES_MAIN_TYPE => r_Check_Amount.Sales_Main_Type,
                                                           IN_PROJ_NUMBER     => null,
                                                           IN_AMOUNT_SUM      => r_Check_Amount.Apply_Amount,
                                                           IN_DISAMOUNT_SUM   => r_Check_Amount.Discount_Amount,
                                                           IN_DISCOUNT_TYPE   => r_Check_Amount.Discount_Type,
                                                           IN_USER_ACCOUNT    => p_User_Code,
                                                           OUT_RESULT         => V_ERR_NUM,
                                                           OUT_ERR_MSG        => p_Result);
          IF V_ERR_NUM <> 0 THEN
            p_Result := '订单取消发货校验客户款项失败！错误提示：'||v_Nl||p_Result||v_Nl||
                        '事业部='||r_Check_Amount.entity_name||v_Nl||
                        '客户ID='||r_Check_Amount.Customer_Id||' 编码='||r_Check_Amount.customer_code||v_Nl||
                        '账户ID='||r_Check_Amount.Account_Id||' 编码='||r_Check_Amount.account_code||v_Nl||
                        '营销大类='||r_Check_Amount.Sales_Main_Type||v_Nl||
                        '折扣类型='||r_Check_Amount.Discount_Type;
            raise v_Base_Exception;
          END IF;
        End Loop;
        
        --锁定款项
        For r_Check_Amount In (--甲方
                               Select lol.entity_id,
                                      be.entity_name,
                                      h.customer_id,
                                      H.CUSTOMER_CODE,
                                      h.account_id,
                                      H.ACCOUNT_CODE,
                                      nvl(r_Lg_Ship_Plan.sales_main_type, bi.sales_main_type) Sales_Main_Type,
                                      Nvl(r_Lg_Ship_Plan.Discount_Type, v_Discount_Type_Common) Discount_Type,
                                      decode(lol.customize_flag, 'Y', ah.project_code, null) project_code,
                                      decode(lol.customize_flag, 'Y', 100, lol.down_pay_scale) down_pay_scale,
                                      h.order_head_id order_id,
                                      h.order_number order_number,
                                      '02' src_type,
                                      Sum(Round(V_RELEASE_AMOUNT
                                                *
                                                case
                                                  when lol.customize_flag = 'Y' then
                                                    -1
                                                  when nvl(lol.customize_flag, 'N') = 'N' then
                                                    case
                                                      when v_Lock_Amount_Flag in (V_LOCK_AMOUNT_FLAG_S, V_LOCK_AMOUNT_FLAG_RS, V_LOCK_AMOUNT_FLAG_HQ) then
                                                        -1
                                                      when v_Lock_Amount_Flag in (V_LOCK_AMOUNT_FLAG_Y, V_LOCK_AMOUNT_FLAG_RT) then
                                                        -1
                                                      else
                                                        0
                                                    end
                                                  else
                                                    0
                                                end,2)) apply_Amount,
                                      Sum(Round(v_Discount_Amount
                                                *
                                                case
                                                  when lol.customize_flag = 'Y' then
                                                    -1
                                                  when nvl(lol.customize_flag, 'N') = 'N' then
                                                    case
                                                      when v_Lock_Amount_Flag in (V_LOCK_AMOUNT_FLAG_S, V_LOCK_AMOUNT_FLAG_RS, V_LOCK_AMOUNT_FLAG_HQ) then
                                                        -1
                                                      when v_Lock_Amount_Flag in (V_LOCK_AMOUNT_FLAG_Y, V_LOCK_AMOUNT_FLAG_RT) then
                                                        -1
                                                      else
                                                        0
                                                    end
                                                  else
                                                    0
                                                end,2)) Discount_Amount,
                                      Sum(Round(V_RELEASE_AMOUNT
                                                *
                                                case
                                                  when lol.customize_flag = 'Y' then
                                                    1 * V_DOWN_AMOUT_FLAG
                                                  when nvl(lol.customize_flag, 'N') = 'N' then
                                                    case
                                                      when v_Lock_Amount_Flag in (V_LOCK_AMOUNT_FLAG_S, V_LOCK_AMOUNT_FLAG_RS, V_LOCK_AMOUNT_FLAG_HQ) then
                                                        1 * V_DOWN_AMOUT_FLAG
                                                      when v_Lock_Amount_Flag in (V_LOCK_AMOUNT_FLAG_Y, V_LOCK_AMOUNT_FLAG_RT) then
                                                        0
                                                      else
                                                        0
                                                    end
                                                  else
                                                    0
                                                end,2)) dp_apply_Amount,
                                      Sum(Round(v_Discount_Amount
                                                *
                                                case
                                                  when lol.customize_flag = 'Y' then
                                                    1
                                                  when nvl(lol.customize_flag, 'N') = 'N' then
                                                    case
                                                      when v_Lock_Amount_Flag in (V_LOCK_AMOUNT_FLAG_S, V_LOCK_AMOUNT_FLAG_RS, V_LOCK_AMOUNT_FLAG_HQ) then
                                                        1 * V_DOWN_AMOUT_FLAG
                                                      when v_Lock_Amount_Flag in (V_LOCK_AMOUNT_FLAG_Y, V_LOCK_AMOUNT_FLAG_RT) then
                                                        0
                                                      else
                                                        0
                                                    end
                                                  else
                                                    0
                                                end,2)) dp_Discount_Amount
                                 From t_Pln_Lg_Order_Line Lol,
                                      t_Bd_Item Bi,
                                      t_pln_lg_order_head h,
                                      v_bd_entity be,
                                      t_pg_price_apply_head ah
                                Where lol.order_head_id = h.order_head_id
                                  and Lol.Item_Id = Bi.Item_Id
                                  And Bi.Entity_Id = Lol.Entity_Id
                                  And Lol.Order_Head_Id = r_Lgorder_Line.Order_Head_Id
                                  And Lol.Entity_Id = r_Lgorder_Line.Entity_Id
                                  and h.entity_id = be.entity_id
                                  and lol.entity_id = ah.entity_id(+)
                                  and lol.project_order_number = ah.apply_code(+)
                                  and lol.order_line_id = r_Lgorder_Line.Order_Line_Id
                                Group By lol.entity_id,
                                         be.entity_name,
                                         h.customer_id,
                                         h.customer_code,
                                         h.account_id,
                                         h.account_code,
                                         nvl(r_Lg_Ship_Plan.sales_main_type, bi.sales_main_type),
                                         Nvl(r_Lg_Ship_Plan.Discount_Type, v_Discount_Type_Common),
                                         decode(lol.customize_flag, 'Y', ah.project_code, null),
                                         decode(lol.customize_flag, 'Y', 100, lol.down_pay_scale),
                                         h.order_head_id,
                                         h.order_number
                                ) Loop
          PKG_CREDIT_ACCOUNT_CONTROL.P_CREDIT_LOCK_DETAIL_HAND(IN_ENTITY_ID   => r_Check_Amount.Entity_Id,
                                                           IN_CUSTOMER_ID     => r_Check_Amount.Customer_Id,
                                                           IN_ACCOUNT_ID      => r_Check_Amount.Account_Id,
                                                           IN_SALES_MAIN_TYPE => r_Check_Amount.Sales_Main_Type,
                                                           IN_PROJ_NUMBER     => r_Check_Amount.project_code,
                                                           IN_AMOUNT_SUM      => r_Check_Amount.Apply_Amount,
                                                           IN_DISAMOUNT_SUM   => r_Check_Amount.Discount_Amount,
                                                           IN_DP_AMOUNT_SUM   => r_Check_Amount.dp_apply_Amount,
                                                           IN_DP_DISAMOUNT_SUM => r_Check_Amount.dp_Discount_Amount,
                                                           IN_DISCOUNT_TYPE   => r_Check_Amount.Discount_Type,
                                                           IN_ORDER_ID        => r_Check_Amount.order_id,
                                                           IN_ORDER_NUMBER    => r_Check_Amount.order_number,
                                                           IN_DOWNPAY_RATE    => r_Check_Amount.down_pay_scale,
                                                           IN_SRC_TYPE        => r_Check_Amount.src_type,
                                                           IN_USER_ACCOUNT    => p_User_Code,
                                                           OUT_RESULT         => V_ERR_NUM,
                                                           OUT_ERR_MSG        => p_Result);
          IF V_ERR_NUM <> 0 THEN
            p_Result := '订单取消发货处理客户款项失败！错误提示：'||v_Nl||p_Result||v_Nl||
                        '事业部='||r_Check_Amount.entity_name||v_Nl||
                        '客户ID='||r_Check_Amount.Customer_Id||' 编码='||r_Check_Amount.customer_code||v_Nl||
                        '账户ID='||r_Check_Amount.Account_Id||' 编码='||r_Check_Amount.account_code||v_Nl||
                        '营销大类='||r_Check_Amount.Sales_Main_Type||v_Nl||
                        '折扣类型='||r_Check_Amount.Discount_Type;
            raise v_Base_Exception;
          END IF;
        End Loop;
      END IF;
      
      IF NVL(r_Lgorder_Head.Customize_Flag, 'N') = 'N' THEN
      --20160914 hejy3 物流取消时释放锁款、锁定订金
      IF r_Order_Type.Source_Order_Type_Id = 1 AND V_IS_CENTER_TRSF = 'N' THEN --提货订单才处理
        --订金处理标志
        --判断提货订单行锁款标识是否为Y，如果自动锁款JOB已经全单锁款，则不需要解锁款项，否则按照原来逻辑处理 add by houhs 20200313
        IF NVL(r_Lgorder_Line.Is_Lock_Amount,'N') in ('NT') THEN
          V_DOWN_AMOUT_FLAG := 0;
          V_SKIP_CANCEL_AMOUNT := 'Y';
          V_AUTO_DIRECT := 'Y';
        ELSIF v_Lock_Amount_Flag IN (V_LOCK_AMOUNT_FLAG_S, V_LOCK_AMOUNT_FLAG_RS, V_LOCK_AMOUNT_FLAG_HQ) THEN
          V_DOWN_AMOUT_FLAG := 1;
        ELSE
          V_DOWN_AMOUT_FLAG := 0;
        END IF;
        
        IF NVL(r_Lgorder_Line.Is_Lock_Amount,'N') in ('Y') THEN
          V_AUTO_DIRECT := 'Y';
        END IF;
        --提货额度处理标志
        IF r_Lgorder_Head.Order_Head_State = '304' OR --订单已关闭
           r_Lgorder_Line.Order_Line_State = 'CLOSE' OR --订单行已关闭
           --订单已送总部评审且取消中心发货数量
           --20171127 hejy3 增加销司取消处理
           (nvl(r_Lg_Ship_Plan.Lg_Order_Review_Flag, '_') = '01' AND (r_Lgorder_Head.Order_Head_State IN ('679', '381', '23') or r_Lgorder_Head.Hq_Lg_Order_Head_Id is not null)) OR
           --订单已结转T+3且取消总部评审数量
           (nvl(r_Lg_Ship_Plan.Lg_Order_Review_Flag, '_') = '02' AND r_Lgorder_Line.Make_Order_Line_Flag = 'Y') or
           --家用总部库评后转暖通的库评取消
           (nvl(r_Lg_Ship_Plan.Lg_Order_Review_Flag, '_') = '02' AND r_Lgorder_Head.Order_Head_State IN ('679', '381', '23') And r_Lgorder_Head.Hq_Lg_Order_Head_Id is not Null)
        THEN
          V_LG_ORDER_AMOUNT_FLAG := 1;
        ELSE
          V_LG_ORDER_AMOUNT_FLAG := 0;
        END IF;
      ELSE
        V_DOWN_AMOUT_FLAG := 0;
        V_LG_ORDER_AMOUNT_FLAG := 0;
      END IF;
      
      IF V_DOWN_AMOUT_FLAG = 1 OR V_LG_ORDER_AMOUNT_FLAG = 1 THEN
        --正常价格列表金额
        V_RELEASE_AMOUNT  := (p_Trans_Order_Qty *
                             r_Lg_Ship_Plan.Item_Price *
                             (100 - Nvl(r_Lg_Ship_Plan.Discount_Rate, 0) -
                             Nvl(r_Lg_Ship_Plan.Month_Discount_Rate,0))) / 100;
        v_Discount_Amount := (p_Trans_Order_Qty *
                             r_Lg_Ship_Plan.Item_Price *
                             Nvl(r_Lg_Ship_Plan.Discount_Rate, 0)) / 100;
        
        --解锁款项、加锁订金
        IF V_DOWN_AMOUT_FLAG = 1 THEN
          pkg_pln_pub.P_CUSTOMER_AMOUNT_PROCESS(IN_ENTITY_ID       => r_Lgorder_Head.Entity_Id,
                                                IN_ORDER_TYPE_ID   => r_Lgorder_Head.Order_Type_Id,
                                                IN_ORDER_TYPE_CODE => r_Lgorder_Head.Order_Type_Code,
                                                IN_CUSTOMER_ID     => r_Lgorder_Head.Customer_Id,
                                                IN_ACCOUNT_ID      => r_Lgorder_Head.Account_Id,
                                                IN_SALES_MAIN_TYPE => nvl(r_lgorder_LIne.Sales_Main_Type, v_Sales_Main_Type),
                                                IN_ACTION_TYPE     => 29,
                                                IN_SOURCE_TYPE     => '02',
                                                IN_ORDER_ID        => r_Lgorder_Head.Order_Head_Id,
                                                IN_PROJ_NUMBER     => null,
                                                IN_DISCOUNT_TYPE   => nvl(r_Lg_Ship_Plan.Discount_Type, v_Discount_Type_Common),
                                                IN_AMOUNT          => Round(V_RELEASE_AMOUNT, 2),
                                                IN_DIS_AMOUNT      => Round(v_Discount_Amount, 2),
                                                IN_RECORD_ERR      => 'N',
                                                IN_USER_CODE       => in_user_code,
                                                OUT_RESULT         => p_Result);
          if p_Result <> v_Success then
            v_Value := '取消发货处理客户款项失败(锁款方式:'||v_Lock_Amount_Flag||')！' || v_Nl || p_Result;
            Raise v_Base_Exception;
          end if;
          
        END IF;
        
        --减少提货额度占用
        IF V_LG_ORDER_AMOUNT_FLAG = 1 THEN
          PKG_CREDIT_DOWN_PAY.P_UNLOCK_ORDER_AMOUNT(IN_ORDER_ID      => r_Lgorder_Head.Order_Head_Id,
                                                    IS_ORDER_TYPE    => r_Lgorder_Head.Order_Type_Code,
                                                    IN_UNLOCK_AMOUNT => V_RELEASE_AMOUNT,
                                                    IS_USER_ACCOUNT  => in_user_code,
                                                    OS_MESSAGE       => p_Result);
          IF p_Result <> v_Success THEN
            v_Value := '释放提货订单额度失败。' || v_Nl ||
                        '客户编码：' || r_Lgorder_Head.Customer_Code || v_Nl ||
                        '账户编码：' || r_Lgorder_Head.Account_Code || v_Nl ||
                        '当前释放金额：' || to_char(V_RELEASE_AMOUNT) || v_Nl ||
                        '系统提示：'|| p_Result;
            RAISE v_Base_Exception;
          END IF;
        END IF;
      END IF;
      
      --取消运力时，取消信用金额占用
      --If Nvl(r_Order_Type.Chk_Cusg_Amount_Flag, v_False) = v_True And p_Trans_Sign_Flag = -1 Then
      --MODI BY LIZHEN 2015-07-21 提货锁款类型时，需解锁款项
      If ((v_Lock_Amount_Flag In (V_LOCK_AMOUNT_FLAG_Y, V_LOCK_AMOUNT_FLAG_RT) And NVL(V_SKIP_CANCEL_AMOUNT,'N') = 'N') Or
        --ADD BY LIZHEN 2015-10-19 提货订单关闭状态，取消物流发货送审锁款的金额需要释放
        (r_Lgorder_Head.Order_Head_State = '304' And v_Lock_Amount_Flag In (V_LOCK_AMOUNT_FLAG_S, V_LOCK_AMOUNT_FLAG_RS, V_LOCK_AMOUNT_FLAG_HQ))
        --ADD BY LIZHEN 2016-06-22 提货订单已关闭，取消物流发货时锁款金额进行释放
        Or (r_Lgorder_Line.Order_Line_State = 'CLOSED' And v_Lock_Amount_Flag In (V_LOCK_AMOUNT_FLAG_S, V_LOCK_AMOUNT_FLAG_RS, V_LOCK_AMOUNT_FLAG_HQ))
        --add by lizhen 2015-12-02 中心评审物流取消时，状态已送审到总部的，需解锁金额且不需再发货
        Or (Nvl(r_Lg_Ship_Plan.Lg_Order_Review_Flag, '_') = '01'
        --modi by lizhen 2016-01-11 中心评审后订单为完毕状态时，取消物流不进行解锁，单据变更状态为“中心发货”
        And (r_Lgorder_Head.Order_Head_State In ('679', '381'/*, '23'*/)
          Or (Nvl(v_Hq_Review_Flag, 'N') = 'Y' And r_Lgorder_Head.Order_Head_State = '23'))
        And v_Lock_Amount_Flag = V_LOCK_AMOUNT_FLAG_S)
        --add by lizhen 2016-01-11 总部评审发货且行进行了T+3订单结转，取消物流时解锁款项
        Or (v_Lock_Amount_Flag In (V_LOCK_AMOUNT_FLAG_S, V_LOCK_AMOUNT_FLAG_RS) And r_Lg_Ship_Plan.Lg_Order_Review_Flag = '02'
          And r_Lgorder_Line.Make_Order_Line_Flag = 'Y')
        --20170828 hejy3 销司提货已结转总部时，结转前的发货取消时，需解锁款项
        Or (Nvl(r_Lg_Ship_Plan.Lg_Order_Review_Flag, '_') In ('01','02') --增加02状态判断，家用总部库评后转暖通的库评取消
          And r_Lgorder_Head.Hq_Lg_Order_Number Is Not Null
          And v_Lock_Amount_Flag = V_LOCK_AMOUNT_FLAG_S)
        --20180712 hejy3 增加送总部评审锁款处理
        or (v_Lock_Amount_Flag = V_LOCK_AMOUNT_FLAG_HQ and
            (nvl(r_Lg_Ship_Plan.Lg_Order_Review_Flag, '_') = '01' or
            (nvl(r_Lg_Ship_Plan.Lg_Order_Review_Flag, '_') = '02' and (r_Lgorder_Line.Make_Order_Line_Flag = 'Y' Or r_Lgorder_Head.Hq_Lg_Order_Number Is Not Null))))
          )
        And p_Trans_Sign_Flag = -1 And NVL(V_SKIP_CANCEL_AMOUNT,'N') = 'N' Then

        --modi by lizhen 2015-11-26 金额=（单价*数量*（100-折扣率-月返））/100
        --If r_Lgorder_Line.Project_Order_Type Is Null Then
        --正常价格列表金额
        v_Account_Amount  := (p_Trans_Order_Qty *
                             r_Lg_Ship_Plan.Item_Price *
                             (100 - Nvl(r_Lg_Ship_Plan.Discount_Rate, 0) -
                             Nvl(r_Lg_Ship_Plan.Month_Discount_Rate,0))) / 100;
        v_Discount_Amount := (p_Trans_Order_Qty *
                             r_Lg_Ship_Plan.Item_Price *
                             Nvl(r_Lg_Ship_Plan.Discount_Rate, 0)) / 100;
                               
        pkg_pln_pub.P_CUSTOMER_AMOUNT_PROCESS(IN_ENTITY_ID       => r_Lgorder_Head.Entity_Id,
                                              IN_ORDER_TYPE_ID   => r_Lgorder_Head.Order_Type_Id,
                                              IN_ORDER_TYPE_CODE => r_Lgorder_Head.Order_Type_Code,
                                              IN_CUSTOMER_ID     => r_Lgorder_Head.Customer_Id,
                                              IN_ACCOUNT_ID      => r_Lgorder_Head.Account_Id,
                                              IN_SALES_MAIN_TYPE => nvl(r_lgorder_LIne.Sales_Main_Type, v_Sales_Main_Type),
                                              IN_ACTION_TYPE     => 2,
                                              IN_SOURCE_TYPE     => '02',
                                              IN_ORDER_ID        => r_Lgorder_Head.Order_Head_Id,
                                              IN_PROJ_NUMBER     => null,
                                              IN_DISCOUNT_TYPE   => nvl(r_Lg_Ship_Plan.Discount_Type, v_Discount_Type_Common),
                                              IN_AMOUNT          => Round(v_Account_Amount, 2),
                                              IN_DIS_AMOUNT      => Round(v_Discount_Amount, 2),
                                              IN_RECORD_ERR      => 'N',
                                              IN_USER_CODE       => in_user_code,
                                              OUT_RESULT         => p_Result);
        if p_Result <> v_Success then
          v_Value := '取消发货处理客户款项失败(锁款方式:'||v_Lock_Amount_Flag||')！' || v_Nl || p_Result;
          Raise v_Base_Exception;
        end if;

      End If;
      
      END IF;
      --add by lizhen 2015-10-20 订单关闭物流取消发货，解锁批文锁定数量
      --If r_Lgorder_Head.Order_Head_State = '304' And r_Lgorder_Line.Project_Order_Line_Id Is Not Null Then
      --add by lizhen 2017-08-17中心评审提货订单结转总部后，取消中心评审发货时，释放中心评审发货对应的批文
      If (r_Lgorder_Head.Order_Head_State = '304' Or (Nvl(r_Lg_Ship_Plan.Lg_Order_Review_Flag, '_') = '01'
         And r_Lgorder_Head.Hq_Lg_Order_Number Is Not Null) or r_Lgorder_Line.Order_Line_State = 'CLOSED' or 
         (Nvl(r_Lg_Ship_Plan.Lg_Order_Review_Flag, '_') = '01'and (r_Lgorder_Head.Order_Head_State in('679', '381') Or 
         (Nvl(v_Hq_Review_Flag, 'N') = 'Y'And r_Lgorder_Head.Order_Head_State = '23') or (r_Lgorder_Head.Order_Head_State In ('20', '1455')
          And r_Lgorder_Head.Hq_Lg_Order_Number Is Not Null))) or (Nvl(r_Lg_Ship_Plan.Lg_Order_Review_Flag, '_') = '02'and nvl(r_Lgorder_Line.make_order_line_flag,'N') = 'Y'))
         And r_Lgorder_Line.Project_Order_Line_Id Is Not Null Then
        -- 价格申请解锁（提货订单评审驳回时），PriceApplyBO.unlock(‘批文明细ID’，'解锁数量’，‘关联单号’ )
        Pkg_Bd_Price.p_Apply_Unlock(r_Lgorder_Line.Project_Order_Line_Id, --批文明细ID
                                    Abs(p_Trans_Order_Qty), --解除锁定数量
                                    r_Lgorder_Head.Order_Number, --关联单号
                                    p_Result, --返回编码，1成功，0失败
                                    v_Value);
        If p_Result != 1 Then
          v_Value := '批文释放锁定数量失败：' || v_Value;
          Raise v_Base_Exception;
        Else
          p_Result := v_Success;
        End If;
      End If;
      
      IF (r_Lg_Ship_Plan.Lg_Order_Review_Flag = '01' AND (r_Lgorder_Head.Order_Head_State In ('679', '381')
        Or (Nvl(v_Hq_Review_Flag, 'N') = 'Y' And r_Lgorder_Head.Order_Head_State = '23')
        or (r_Lgorder_Head.Order_Head_State In ('20', '1455', '23') And r_Lgorder_Head.Hq_Lg_Order_Number Is Not Null))) or
        (r_Lg_Ship_Plan.Lg_Order_Review_Flag = '02' AND (r_Lgorder_Line.Make_Order_Line_Flag = 'Y' Or r_Lgorder_Head.Hq_Lg_Order_Number Is Not Null)) or
        r_Lgorder_Head.Order_Head_State = '304' or r_Lgorder_Head.Cancel_Flag = 'Y' or
        r_Lgorder_Line.Order_Line_State = 'CLOSED'
      THEN
        v_Operation_Type := '取消发货取消订单';
      END IF;

      --add by lizhen 2017-11-13总部提货订单取消发货通知单时更新销司款项
	  --add by houhs 如果是自动直发跳过总部款项
      if nvl(V_IS_CENTER_TRSF, 'N') = 'N' and (r_Lg_Ship_Plan.Is_Cusg_Flag = 'Y' OR r_Lg_Ship_Plan.Pick_Flag = 'Y') THEN
        p_Upd_Transfer_Lg_Order(In_Lg_Order_Id => r_Lgorder_Head.Order_Head_Id,
                                In_Lg_Line_Id  => p_Lgorder_Line_Id,
                                In_Qty         => p_Trans_Order_Qty,
                                In_User_Code   => in_user_code,
                                Out_Result     => p_Result,
                                IN_OPERATION_TYPE => v_Operation_Type,
                                IN_SKIP_LOCK      => V_SKIP_CANCEL_AMOUNT);
        If p_Result != v_Success Then
          v_Value := p_Result;
          Raise v_Base_Exception;
        End If;
      END IF;

      ----发货计划提货订单类型的，对应的计划订单是送审锁款，要锁定计划订单款项 lilh6 2017-11-14
      IF nvl(r_Order_Type.Is_Business_Control,'_') = 'share_ship_order'  THEN     
        FOR r_check_Amount IN (
          SELECT poh.account_id,
                 poh.customer_id,
                 poh.order_type_code,
                 poh.order_head_id,
                 poh.lock_amount_flag,
                 nvl(pol.sales_main_type,bi.sales_main_type) Sales_Main_Type,
                 sum(pol.item_price * p_Trans_Order_Qty * (100 - nvl(pol.discount_rate,0) - nvl(pol.ordered_discount_rate,0)) / 100) Affirm_Amount,
                 sum(pol.item_price * p_Trans_Order_Qty * nvl(pol.discount_rate,0) / 100) Discount_Amount
            FROM t_pln_order_line pol,
                 t_lg_ship_plan lsp,
                 t_Bd_Item Bi,
                 t_pln_order_head poh
           WHERE pol.order_line_id = lsp.origin_line_id
             AND lsp.ship_plan_id = p_Lg_Ship_Plan_Id
             AND pol.item_id = bi.item_id
             AND poh.order_head_id = pol.order_head_id
             AND poh.lock_amount_flag = 'S'
             GROUP BY poh.account_id,
                      poh.customer_id,
                      poh.order_type_code,
                      poh.order_head_id,
                      poh.lock_amount_flag,
                      nvl(pol.sales_main_type,bi.sales_main_type)
            ) LOOP
          If Nvl(r_Check_Amount.Affirm_Amount, 0) + Nvl(r_Check_Amount.Discount_Amount, 0) <> 0 THEN
            pkg_pln_pub.P_CUSTOMER_AMOUNT_PROCESS(IN_ENTITY_ID       => r_Lgorder_Head.Entity_Id,
                                                  IN_ORDER_TYPE_ID   => r_Lgorder_Head.Order_Type_Id,
                                                  IN_ORDER_TYPE_CODE => r_Lgorder_Head.Order_Type_Code,
                                                  IN_CUSTOMER_ID     => r_Check_Amount.Customer_Id,
                                                  IN_ACCOUNT_ID      => r_Check_Amount.Account_Id,
                                                  IN_SALES_MAIN_TYPE => r_Check_Amount.Sales_Main_Type,
                                                  IN_ACTION_TYPE     => 1,
                                                  IN_SOURCE_TYPE     => '02',
                                                  IN_ORDER_ID        => r_Check_Amount.Order_Head_Id,
                                                  IN_PROJ_NUMBER     => null,
                                                  IN_DISCOUNT_TYPE   => v_Discount_Type_Common,
                                                  IN_AMOUNT          => round(Nvl(r_Check_Amount.Affirm_Amount, 0), 2),
                                                  IN_DIS_AMOUNT      => round(Nvl(r_Check_Amount.Discount_Amount, 0), 2),
                                                  IN_RECORD_ERR      => 'N',
                                                  IN_USER_CODE       => in_user_code,
                                                  OUT_RESULT         => p_Result);
            if p_Result <> v_Success then
              v_Value := '取消发货（发货计划提货订单）处理客户款项失败！' || v_Nl || p_Result;
              Raise v_Base_Exception;
            end if;
            
          END IF;
        END LOOP;
      END IF;
      --增加发货计划评审的提货订单不能取消已发物流的数量
      If 1 = 1 Then 
        --MODI BY LIZHEN 2017-07-31制定发货计划物流取消后，不允许回写提货订单功能取消，
        -- Nvl(Upper(r_Order_Type.Is_Business_Control), '_') != 'SHARE_SHIP_ORDER' Then --ADD BY LIZHEN 2015-08-18
        --T+3提货订单，取消物流时，只更新减少行的已评审数量
        --T+3库存评审的，与正常提货订单取消一致。
        --modi by lizhen 2015-12-01 来源于提货订单库存评库的则进行库存占用释放
        --来源于计划订单的提货评审不进行库存释放
        If Nvl(r_Lg_Ship_Plan.Origin_Origin_Type, '_') != '02'
          And r_Lg_Ship_Plan.Origin_Origin_Line_Id Is Null
          And Nvl(r_Lg_Ship_Plan.Origin_Type, '_') In ('02', '03') Then
          --按多次评审，获取发货仓评审数量
          Select Sum(Ori.Affirm_Qty)
            Into v_Send_Inventory_Qty
            From t_Pln_Order_Review_Info Ori
           Where Ori.Origin_Order_Line_Id = r_Lgorder_Line.Order_Line_Id
             And Ori.Send_Inventory_Id = p_Send_Inventory_Id
             And Ori.Item_Id = r_Lgorder_Line.Item_Id;
          If p_Trans_Order_Qty > Nvl(v_Send_Inventory_Qty, 0) Then
            v_Value := '更新失败，取消评审数量（' || To_Char(p_Trans_Order_Qty) ||
                       '）大于行发货仓已评审数量（' ||
                       To_Char(Nvl(r_Lgorder_Line.Affirmed_Quantity, 0)) ||
                       '），发货仓库ID：' || To_Char(p_Send_Inventory_Id);
            Raise v_Base_Exception;
          End If;
          --提货订单
          If Nvl(r_Order_Type.Is_Lock_Inv_Flag, 'N') = 'Y' Then
            Pkg_Pln_Inv_Occupy.p_Affirm_Unoccupy_Stocks(p_Inventory_Id      => p_Send_Inventory_Id,
                                                        p_Item_Id           => r_Lgorder_Line.Item_Id,
                                                        p_Occupy_Qty        => p_Trans_Order_Qty,
                                                        p_Match_Pln_To_Wip  => 'A',
                                                        p_Action_Desc       => '取消提货订单评审数量',
                                                        p_Entity_Id         => r_Lgorder_Line.Entity_Id,
                                                        p_Origin_Type       => r_Order_Type.Order_Type_Name,
                                                        p_Origin_Head_Id    => r_Lgorder_Line.Order_Head_Id,
                                                        p_Origin_Number     => r_Lgorder_Head.Order_Number,
                                                        p_Origin_Line_Id    => r_Lgorder_Line.Order_Line_Id,
                                                        p_Source_Order_Type => r_Order_Type.Order_Type_Name,
                                                        p_Source_Head_Id    => r_Lgorder_Head.Order_Head_Id,
                                                        p_Source_Number     => r_Lgorder_Head.Order_Number,
                                                        p_Source_Line_Id    => r_Lgorder_Line.Order_Line_Id,
                                                        p_User_Code         => in_user_code,
                                                        p_Allow_No_Occupy   => 'N',
                                                        p_Result            => v_Err_Num,
                                                        p_Err_Msg           => v_Value);
            If v_Value <> v_Success Then
              v_Value := '释放库存占用失败。' || v_Nl || v_Value;
              Raise v_Base_Exception;
            End If;
          End If;
          Begin
              Insert Into t_Pln_Order_Review_Info
                (Entity_Id, --业务主体
                 Order_Review_Id, --订单评审记录ID
                 Lot_Num, --批次（用于记录订单评审第几次）
                 Order_Period, --订单周期（汇总的订单评审，记录订单周期）
                 Source_Order_Type_Id, --源订单类型ID
                 Order_Type_Id, --订单类型ID
                 Order_State, --订单状态（送审、汇总、库评、产地分解等）
                 Order_Type_Name, --订单类型名称
                 Order_Number, --订单号（单单评审，记录订单号）
                 Hq_Date, --总部评审日期
                 Hq_User, --总部评审人员
                 Remark, --备注
                 Created_By, --创建人
                 Creation_Date, --创建日期
                 Last_Updated_By, --最后修改人
                 Last_Update_Date, --最后修改日期
                 Pre_Field_01, --预留字段1
                 Pre_Field_02, --预留字段2
                 Pre_Field_03, --预留字段3
                 Pre_Field_04, --预留字段4
                 Pre_Field_05, --预留字段5
                 Pre_Field_06, --预留字段6
                 Origin_Order_Head_Id, --来源订单头ID
                 Origin_Order_Line_Id, --来源订单行ID
                 Item_Id, --产品ID
                 Item_Code, --产品编码
                 Item_Name, --产品描述
                 Affirm_Qty, --评审数量
                 Receive_Inventory_Id, --收货仓库ID
                 Send_Inventory_Id --发货仓库ID
                 )
              Values
                (r_Lgorder_Line.Entity_Id, --业务主体
                 s_Pln_Order_Review_Info.Nextval, --订单评审记录ID
                 (Select Count(1)
                    From t_Pln_Order_Review_Info Ri
                   Where Ri.Origin_Order_Head_Id = r_Lgorder_Head.Order_Head_Id
                     And Ri.Origin_Order_Line_Id = r_Lgorder_Line.Order_Line_Id) + 1, --批次（用于记录订单评审第几次）
                 Null, --订单周期（汇总的订单评审，记录订单周期）
                 r_Order_Type.Source_Order_Type_Id, --源订单类型ID
                 r_Order_Type.Order_Type_Id, --订单类型ID
                 r_Lgorder_Head.Order_Head_State, --订单状态（送审、汇总、库评、产地分解等）
                 r_Order_Type.Order_Type_Name, --订单类型名称
                 r_Lgorder_Head.Order_Number, --订单号（单单评审，记录订单号）
                 Trunc(Sysdate), --总部评审日期
                 in_user_code, --总部评审人员
                 r_Lgorder_Line.Remark, --备注
                 in_user_code, --创建人
                 Sysdate, --创建日期
                 in_user_code, --最后修改人
                 Sysdate, --最后修改日期
                 r_Lgorder_Head.Order_Head_State, --Pre_Field_01, --预留字段1(写入订单状态值)
                 Null, --Pre_Field_02, --预留字段2
                 Null, --Pre_Field_03, --预留字段3
                 Null, --Pre_Field_04, --预留字段4
                 Null, --Pre_Field_05, --预留字段5
                 Null, --Pre_Field_06, --预留字段6
                 r_Lgorder_Head.Order_Head_Id, --Origin_Order_Head_Id, --来源订单头ID
                 r_Lgorder_Line.Order_Line_Id, --Origin_Order_Line_Id, --来源订单行ID
                 r_Lgorder_Line.Item_Id, --Item_Id, --产品ID
                 r_Lgorder_Line.Item_Code, --Item_Code, --产品编码
                 r_Lgorder_Line.Item_Name, --Item_Name, --产品描述
                 p_Trans_Order_Qty * p_Trans_Sign_Flag, --Affirm_Qty --评审数量
                 r_Lgorder_Head.Inventory_To_Id, --收货仓库ID
                 p_Send_Inventory_Id --发货仓库ID
                 );
            Exception
              When Others Then
                v_Value := '插入评审记录信息失败，失败原因：' || Sqlerrm;
                Raise v_Base_Exception;
            End;
          
          --网批订单重新锁定库存
          If Nvl(r_Order_Type.Is_Lock_Inv_Flag, 'N') = 'Y' and ((r_Lg_Ship_Plan.Customer_Channel_Type IN (PKG_PLN_PUB.V_CUSTOMER_CHANNEL_TYPE_WP, PKG_PLN_PUB.V_CUSTOMER_CHANNEL_TYPE_SHARE)
            and r_Lgorder_Head.Fund_Check_Mode is not null and r_Lgorder_Head.Payment_Flag is not null) or r_Lg_Ship_Plan.Customer_Channel_Type=V_CUSTOMER_CHANNEL_TYPE_NIFFER)
            and r_Lgorder_Head.Order_Head_State <> '304' and nvl(r_Lgorder_Line.Order_Line_State,'_') <> 'CLOSED' Then
            if r_Lgorder_Line.Project_Order_Type is null and r_Lgorder_Head.Sys_Source = 'CIMS' then
              select count(1)
                into v_Count
                from t_pln_lg_order_line l
               where l.order_line_id = r_Lgorder_Line.Source_Line_Id
                 and l.project_order_type is null;
            else
              v_Count := 1;
            end if;
            
            v_lock_type := 'standard';
            if r_Lg_Ship_Plan.Customer_Channel_Type = PKG_PLN_PUB.V_CUSTOMER_CHANNEL_TYPE_SHARE then
              v_lock_type := 'share';
            end if;
            
            if v_Count > 0 then
              pkg_inv_lockin.P_LOCKIN_MAIN_BY_DISTRICT(IS_DISTRICT_CODE      => r_Lg_Ship_Plan.Consignee_Location_Code,
                                                       IS_ITEM_CODE          => r_Lg_Ship_Plan.Item_Code,
                                                       IS_ITEM_CLASS_CODE    => r_Lg_Ship_Plan.Sales_Main_Type,
                                                       IN_ENTITY_ID => r_Lg_Ship_Plan.Entity_Id,
                                                       IS_INVENTORY_CODE => r_Lg_Ship_Plan.Ship_Inventory_Code,
                                                       IS_SHARE_VENDOR_CODE => r_Lg_Ship_Plan.Share_Vendor_Code,
                                                       IN_LOCK_QTY           => p_Trans_Order_Qty,
                                                       IS_LOCK_TYPE          => v_lock_type,
                                                       IN_LOCK_LEVEL         => 0,
                                                       IS_DELIVERY_NUMBER    => r_Lg_Ship_Plan.Origin_Order_Num,
                                                       IS_ORDER_NUMBER       => r_Lg_Ship_Plan.Customer_Order_Number,
                                                       IS_CHILD_ORDER_NUMBER => r_Lg_Ship_Plan.Sys_Source_Order_Num,
                                                       IS_USER_CODE          => p_User_Code,
                                                       IS_sales_center_code     =>r_Lg_Ship_Plan.Sales_Center_Code,
                                                       OS_INVENTORY_LOCK     => V_INV_STR,
                                                       OS_MESSAGE            => v_Value,
                                                       OS_JSON_MSG => V_JSON_MSG);
              
              if v_Value = 'OK' then
                v_Value := v_Success;
              end if;
              
              If v_Value <> v_Success Then
                v_Value := '网批订单处理锁定占用！' || v_Nl || v_Value;
                Raise v_Base_Exception;
              End If;
            end if;
          end if;
        End If;

        If p_Trans_Sign_Flag = -1 Then --更新行表的已评审数量
          --20180320 hejy3 更新预约直发信息
          if r_Lg_Ship_Plan.Direct_Transport_Falg = 'Y' then
            update t_pln_lg_order_line l
               set l.direct_transport_qty = nvl(l.direct_transport_qty, 0) + p_Trans_Order_Qty * p_Trans_Sign_Flag,
                   l.last_updated_by = in_user_code,
                   l.last_update_date = sysdate,
                   l.version = nvl(l.version, 0) + 1
             where l.order_line_id = p_Lgorder_Line_Id
             returning l.direct_transport_qty into v_Affirmed_Qty;
            
            If Nvl(v_Affirmed_Qty, 0) < 0 Then
              v_Value := '更新失败，更新后的已预约直发数量为负数！' || v_Nl ||
                '更新后的已预约直发数量：' || To_Char(v_Affirmed_Qty);
              Raise v_Base_Exception;
            End If;
          else
            Update t_Pln_Lg_Order_Line Lol
               Set --add by lizhen 2015-11-30
                   Lol.Center_Affirmed_Qty = Decode(r_Lg_Ship_Plan.Lg_Order_Review_Flag,
                                                    '01',
                                                    Lol.Center_Affirmed_Qty +
                                                    p_Trans_Order_Qty *
                                                    p_Trans_Sign_Flag,
                                                    '04',
                                                    Lol.Center_Affirmed_Qty +
                                                    p_Trans_Order_Qty *
                                                    p_Trans_Sign_Flag,
                                                    Lol.Center_Affirmed_Qty),
                   Lol.Submit_Hq_Qty = Decode(r_Lg_Ship_Plan.Lg_Order_Review_Flag,
                                              '01',
                                              Case
                                                When (r_Lgorder_Head.Order_Head_State In ('1455')
                                                  --add by lizhen 2017-08-17未转总部的才回写数据
                                                  And r_Lgorder_Head.Hq_Lg_Order_Number Is Null)
                                                  --modi by lizhen 2016-01-11
                                                  Or (Nvl(v_Hq_Review_Flag, 'N') = 'N'
                                                  And r_Lgorder_Head.Order_Head_State = '23') Then
                                                 Nvl(Lol.Submit_Hq_Qty, 0) +
                                                 Abs(p_Trans_Order_Qty)
                                                Else
                                                 Lol.Submit_Hq_Qty
                                              End,
                                              Lol.Submit_Hq_Qty),
                   Lol.Hq_Affirmed_Qty     = Decode(r_Lg_Ship_Plan.Lg_Order_Review_Flag,
                                                    '02',
                                                    Lol.Hq_Affirmed_Qty +
                                                    p_Trans_Order_Qty *
                                                    p_Trans_Sign_Flag,
                                                    Lol.Hq_Affirmed_Qty),
                   Lol.Pln_Affirmed_Qty    = Decode(r_Lg_Ship_Plan.Lg_Order_Review_Flag,
                                                    '03',
                                                    Lol.Pln_Affirmed_Qty +
                                                    p_Trans_Order_Qty *
                                                    p_Trans_Sign_Flag,
                                                    Lol.Pln_Affirmed_Qty),
                   Lol.Cancel_Qty = Decode(r_Lg_Ship_Plan.Lg_Order_Review_Flag,
                                           '01',
                                           Case
                                             When r_Lgorder_Head.Order_Head_State In
                                                  ('679', '381')
                                              --modi by lizhen 2016-01-11
                                              Or (Nvl(v_Hq_Review_Flag, 'N') = 'Y'
                                              And r_Lgorder_Head.Order_Head_State = '23') Then
                                              Nvl(Lol.Cancel_Qty, 0) +
                                              Abs(p_Trans_Order_Qty)
                                             --add by lizhen 2017-08-17结转总部后，中心评审库存取消时更新取消数量
                                             When r_Lgorder_Head.Order_Head_State In ('20', '1455','23')
                                               And r_Lgorder_Head.Hq_Lg_Order_Number Is Not Null Then
                                               Nvl(Lol.Cancel_Qty, 0) + Abs(p_Trans_Order_Qty)
                                             Else
                                              Lol.Cancel_Qty
                                           End,
                                           '02',
                                           Case
                                             WHEN lol.make_order_line_flag = 'Y'Or r_Lgorder_Head.Hq_Lg_Order_Number Is Not Null Then
                                              Nvl(Lol.Cancel_Qty, 0) +
                                              Abs(p_Trans_Order_Qty)
                                             Else
                                              Lol.Cancel_Qty
                                           End,
                                           Lol.Cancel_Qty)
             Where Lol.Order_Line_Id = p_Lgorder_Line_Id;
            
            --二次发运更新直发数量
            /*if r_Lg_Ship_Plan.Lg_Order_Review_Flag = '04' \*and
              (r_Lgorder_Head.Lock_Amount_Flag = 'Y' or (r_Lgorder_Head.Lock_Amount_Flag = 'S' and v_Hq_Affirm_Lock_Full_Amount = 'Y'))*\
            then
              --判断是否齐套汇总结转总部的
              select count(1)
                into v_Count
                from t_pln_lg_order_head h
               where h.sys_source = 'CIMS'
                 and h.source_order_id = r_Lgorder_Head.Order_Head_Id;
              
              if v_Count > 0 then
                update t_pln_lg_order_line l
                   set l.transfer_hq_affirmed_qty = greatest(nvl(l.transfer_hq_affirmed_qty, 0) + p_Trans_Sign_Flag * p_Trans_Order_Qty, 0)
                 where l.order_line_id = p_Lgorder_Line_Id;
                 
                update t_pln_lg_order_line l
                   set l.sended_qty = greatest(nvl(l.sended_qty, 0) + p_Trans_Sign_Flag * p_Trans_Order_Qty, 0)
                 where l.order_line_id = p_Lgorder_Line_Id;
              end if;
            end if;*/
          end if;
          --add by huanghb12 20181126 更新预约已评审的数量Book_Affirmed_Qty
            if r_Lg_Ship_Plan.Book_Num_Cims is not null then
              --查询预约单头表
              select * into R_PLN_BOOK_HEADER
                from T_PLN_BOOK_HEADER h
                where h.book_num = r_Lg_Ship_Plan.Book_Num_Cims;
             --只针对提货订单明细预约的场景 
              select distinct L.Src_Type into V_Src_Type
                from T_PLN_BOOK_LINE L
                where L.header_id = R_PLN_BOOK_HEADER.HEADER_ID;
             if ('PLN_LG_ORDER' = V_Src_Type) then
                --提货订单明细预约的场景才回写提货订单行上
                update t_pln_lg_order_line l
                   set l.book_affirmed_qty = l.book_affirmed_qty + p_Trans_Sign_Flag * p_Trans_Order_Qty,
                       l.last_updated_by = in_user_code,
                       l.last_update_date = sysdate
                 where l.order_line_id = p_Lgorder_Line_Id;
               --更新预约单行表上的已评审数量             
                update T_PLN_BOOK_LINE bl
                  set bl.affirmed_quantity = bl.affirmed_quantity + p_Trans_Sign_Flag * p_Trans_Order_Qty,
                      bl.last_updated_by = in_user_code,
                      bl.last_update_date = sysdate
                  where ((Nvl(r_Lg_Ship_Plan.Origin_Origin_Type, '_') = '02' AND r_Lg_Ship_Plan.ORIGIN_ORIGIN_ORDER_CODE = bl.SRC_BILL_NUM)
                     OR (r_Lg_Ship_Plan.ORIGIN_TYPE = '02' AND r_Lg_Ship_Plan.ORIGIN_ORDER_NUM = bl.SRC_BILL_NUM))
                  and bl.header_id = R_PLN_BOOK_HEADER.Header_Id
                  and bl.item_code = r_Lg_Ship_Plan.Item_Code; 
              end if;
            end if;
            --end huanghb12
        End If;

        --更新行表的已评审数量
        if r_Lg_Ship_Plan.Direct_Transport_Falg = 'Y' then
          null;
        else
          --更新行表的已评审数量
          Update t_Pln_Lg_Order_Line Lol
             Set Lol.Affirmed_Quantity   = Nvl(Lol.Affirmed_Quantity, 0) +
                                           p_Trans_Order_Qty * p_Trans_Sign_Flag,
                 Lol.Last_Update_Date    = Sysdate,
                 Lol.Last_Updated_By     = in_user_code,
                 Lol.Version             = Nvl(Lol.Version, 0) + 1
           Where Lol.Order_Line_Id = p_Lgorder_Line_Id
          Returning Lol.Affirmed_Quantity Into v_Affirmed_Qty;

          --add by lizhen 2015-02-12 增加返回更新后的数量为负数量报异常
          If Nvl(v_Affirmed_Qty, 0) < 0 Then
            v_Value := '更新失败，更新后的已评审数量为负数！' || v_Nl ||
              '更新后的已评审数量：' || To_Char(v_Affirmed_Qty);
            Raise v_Base_Exception;
          End If;
        end if;
        
        --20170510 hejy3 再更新一次取消数量
        UPDATE T_PLN_LG_ORDER_LINE L
           SET L.CANCEL_QTY = DECODE(R_LGORDER_HEAD.ORDER_HEAD_STATE,
                                     304,
                                     DECODE(SIGN(NVL(L.Center_Affirm_Quantity, L.QUANTITY) - NVL(L.AFFIRMED_QUANTITY, 0)-
                                                 (nvl(l.transfer_hq_affirmed_qty, 0) - nvl(l.sended_qty, 0)) -
                                                 (nvl(l.direct_transport_qty, 0) - nvl(l.already_direct_transport_qty, 0))),
                                            1,
                                            NVL(L.Center_Affirm_Quantity, L.QUANTITY) - NVL(L.AFFIRMED_QUANTITY, 0)-
                                            (nvl(l.transfer_hq_affirmed_qty, 0) - nvl(l.sended_qty, 0)) -
                                            (nvl(l.direct_transport_qty, 0) - nvl(l.already_direct_transport_qty, 0)),
                                            --NVL(L.Center_Affirm_Quantity, L.QUANTITY)
                                            0
                                            ),
                                     DECODE(L.ORDER_LINE_STATE,
                                            'CLOSED',
                                            DECODE(SIGN(NVL(L.Center_Affirm_Quantity, L.QUANTITY) - NVL(L.AFFIRMED_QUANTITY, 0)-
                                                        (nvl(l.transfer_hq_affirmed_qty, 0) - nvl(l.sended_qty, 0)) -
                                                        (nvl(l.direct_transport_qty, 0) - nvl(l.already_direct_transport_qty, 0))),
                                                   1,
                                                   NVL(L.Center_Affirm_Quantity, L.QUANTITY) - NVL(L.AFFIRMED_QUANTITY, 0)-
                                                   (nvl(l.transfer_hq_affirmed_qty, 0) - nvl(l.sended_qty, 0)) -
                                                   (nvl(l.direct_transport_qty, 0) - nvl(l.already_direct_transport_qty, 0)),
                                                   --NVL(L.Center_Affirm_Quantity, L.QUANTITY)
                                                   0
                                                   ),
                                            L.CANCEL_QTY))
         WHERE L.ORDER_LINE_ID = P_LGORDER_LINE_ID;
         
        --add by huanghb12 2019-3-26 取消的时候，更新库存水位表中的已取消数量 
        --查询订单是否需要控制库存水位 huanghb12  'Y'-表示需要维护库存水位 'N'-表示不维护库存水位
        BEGIN
          SELECT NVL(OT.IS_INV_LEVEL_CONTROL,'N')
               INTO V_IS_INV_LEVEL_CONTROL
               FROM CIMS.T_PLN_ORDER_TYPE OT
              WHERE OT.ORDER_TYPE_ID = r_Lgorder_Head.Order_Type_Id--R_LG_ORDER.ORDER_TYPE_ID
                AND OT.ENTITY_ID = r_Lgorder_Head.ENTITY_ID;
           --最终取消数量     
           select nvl(l.cancel_qty,0)
             into v_cancel_qty_temp 
             from cims.T_PLN_LG_ORDER_LINE L
             where L.ORDER_LINE_ID = P_LGORDER_LINE_ID;
         EXCEPTION
           WHEN OTHERS THEN
              P_RESULT := '获取库存水位控制标志IS_INV_LEVEL_CONTROL参数失败！' || V_NL ||
                          SQLERRM;
              RAISE V_BASE_EXCEPTION;
         END;
         --如果本单据是库存水位控制，且收货仓id不为空，则需要更新库存水位表中的取消数量
         if V_IS_INV_LEVEL_CONTROL = 'Y' and r_Lgorder_Head.Inventory_To_Id is not null then
           --更新库存水位表中，累计取消评审数量 
            update cims.T_PLN_INV_LEVEL tl
              --执行取消，取消后的取消数量 -减去取消前的取消数量
              set tl.acc_cancel_quantity = nvl(tl.acc_cancel_quantity,0) + (v_cancel_qty_temp - nvl(r_Lgorder_Line.Cancel_Qty,0))
              where 1=1
              AND tl.INVENTORY_ID = r_Lgorder_Head.INVENTORY_TO_ID
              AND tl.ITEM_ID = r_Lgorder_Line.ITEM_ID
              AND tl.ENTITY_ID = r_Lgorder_Head.ENTITY_ID;
         end if;
        --end by huanghb12 

        --add by lizhen 2017-02-28 回写匹配计划订单关系行已发货数量信息
        If (Upper(r_Order_Type.Is_Business_Control) = 'MATCH_ORDER_SHIP'Or Upper(nvl(v_relation_type,'_')) = 'PLN_ORDER_TYPE')
          And r_Lg_Ship_Plan.Origin_Origin_Type = '02' 
          And r_Lg_Ship_Plan.Origin_Origin_Line_Id Is Not Null
          And r_Lg_Ship_Plan.Origin_Line_Id Is Not Null Then
          Update t_Pln_Lg_Relation Plr
             Set Plr.Ship_Qty         = Nvl(Plr.Ship_Qty, 0) +
                                        p_Trans_Order_Qty * p_Trans_Sign_Flag,
                 Plr.Last_Update_Date = Sysdate,
                 Plr.Last_Updated_By  = in_user_code
           Where Plr.Lg_Order_Line_Id = p_Lgorder_Line_Id
             And Plr.Order_Line_Id = r_Lg_Ship_Plan.Origin_Line_Id;
          --add by lizhen 2017-03-30 提货订单行关闭后更新计划订单匹配数量、提货订单匹配数量
          If r_Lgorder_Line.Order_Line_State = 'CLOSED' And p_Trans_Sign_Flag = -1 Then
           Update t_Pln_Lg_Relation Plr
              Set Plr.Match_Qty = Nvl(Plr.Match_Qty, 0) +
                                  p_Trans_Order_Qty * p_Trans_Sign_Flag
            Where Plr.Lg_Order_Line_Id = p_Lgorder_Line_Id
              And Plr.Order_Line_Id = r_Lg_Ship_Plan.Origin_Line_Id;
             
            --更新提货订单已匹配数量 
            Update t_Pln_Lg_Order_Line Lol
               Set Lol.To_Pln_Qty = Nvl(Lol.To_Pln_Qty, 0) +
                                    p_Trans_Order_Qty * p_Trans_Sign_Flag
             Where Lol.Order_Line_Id = p_Lgorder_Line_Id;
             
             Update t_Pln_Order_Line Pol
                Set Pol.Match_Qty = Nvl(Pol.Match_Qty, 0) +
                                    p_Trans_Order_Qty * p_Trans_Sign_Flag
              Where Pol.Order_Line_Id = r_Lg_Ship_Plan.Origin_Line_Id;
            Begin
              Insert Into t_Pln_Lg_Match_His
                (Entity_Id,
                 Match_His_Id,
                 Lg_Order_Head_Id,
                 Lg_Order_Line_Id,
                 Pln_Order_Head_Id,
                 Pln_Order_Line_Id,
                 Operation_Type,
                 Match_Qty,
                 Remark,
                 Creation_Date,
                 Created_By,
                 Last_Update_Date,
                 Last_Updated_By)
              Values
                (r_Lgorder_Head.Entity_Id,
                 s_Pln_Lg_Match_His.Nextval,
                 r_Lgorder_Line.Order_Head_Id,
                 r_Lgorder_Line.Order_Line_Id,
                 r_Lg_Ship_Plan.Origin_Order_Id,
                 r_Lg_Ship_Plan.Origin_Line_Id,
                 'AUTO_CANCEL_MATCH',
                 p_Trans_Order_Qty,
                 '已关闭提货订单行取消物流发货通知单时取消匹配数量',
                 Sysdate,
                 in_user_code,
                 Sysdate,
                 in_user_code);
            Exception
              When Others Then
                v_Value := '写入匹配历史记录表失败';
                Raise v_Base_Exception;
            End;
          End If;
        End If;
        
        --add by lilh6 2019-05-06 回写匹配数量
        If r_Lgorder_Line.Order_Line_State = 'CLOSED' And p_Trans_Sign_Flag = -1 And 
          Upper(r_Order_Type.Is_Business_Control) = 'SHARE_SHIP_ORDER'And r_Order_Type.Is_Dierect_Match = 'Y'Then
             
          --更新提货订单已匹配数量 
          Update t_Pln_Lg_Order_Line Lol
             Set Lol.To_Pln_Qty = Nvl(Lol.To_Pln_Qty, 0) +
                                  p_Trans_Order_Qty * p_Trans_Sign_Flag
           Where Lol.Order_Line_Id = p_Lgorder_Line_Id;
             
           Update t_Pln_Order_Line Pol
              Set Pol.Match_Qty = Nvl(Pol.Match_Qty, 0) +
                                  p_Trans_Order_Qty * p_Trans_Sign_Flag
            Where Pol.Order_Line_Id = r_Lg_Ship_Plan.Origin_Line_Id;
        End If;

        --add by lizhen 2015-10-19 提货订单关闭状态物流取消提货后，提货订单状态不改变
        If r_Lgorder_Head.Order_Head_State != '304' Then
          --更新头表的订单状态
          Update t_Pln_Lg_Order_Head Loh --381
             Set Loh.Order_Head_State =
                 (Case
                   --add by tangjz 2015-12-03 如果是样机订单的取消时，不更变当前单据状态
                   when r_Order_Type.Source_Order_Type_Id = 10 then
                     Loh.Order_Head_State
                   When
                    (Select Count(1)
                       From t_Pln_Lg_Order_Line Lol
                      Where Lol.Order_Head_Id = Loh.Order_Head_Id
                        and --Nvl(Lol.Center_Affirm_Quantity, Lol.Quantity)
                            case
                              when loh.order_head_state in ('20','2225','1455') and loh.hq_lg_order_head_id is null then
                                nvl(lol.quantity, 0)
                              else nvl(lol.center_affirm_quantity, lol.quantity)
                            end - Nvl(Lol.Cancel_Qty, 0) - Nvl(Lol.Affirmed_Quantity, 0) > 0) > 0 Then
                       --add by lizhen 2015-11-30 增加“中心评审”状态控制，如果是中心评审的取消时，不更变当前单据状态
                       --add by tangjz 2015-12-03 如果是样机订单的取消时，不更变当前单据状态
                       Case
                         When r_Lg_Ship_Plan.Lg_Order_Review_Flag IN ('01') or r_Order_Type.Source_Order_Type_Id = 10 Then
                           --modi by lizhen 2016-01-11 未送过总部评审的单据，更新到“中心发货”状态允许继续发货
                           Case
                             When Loh.Order_Head_State In ('679', '381') Or
                                  (Nvl(v_Hq_Review_Flag, 'N') = 'Y' And Loh.Order_Head_State = '23') Then
                             /*'381'--*/Loh.Order_Head_State
                             Else
                               '1455'
                           End
                         When r_Lg_Ship_Plan.Lg_Order_Review_Flag IN ( '04')Then
                           --modi by lilh6 2018-10-23 家用结转暖通后二次发运的取消，更新到“部分发货”状态允许继续发货
                           Case
                             When Loh.Order_Head_State In ('679', '381') Then
                             /*'381'--*/Loh.Order_Head_State
                             Else
                               '381'
                           End
                         Else
                          '381' --存在未评审完成的行，把头设置成部份评审状态
                       End
                    Else /*Loh.Order_Head_State*/'23' End), --hejy3 没有未发货完毕的行更新头状态为评审完毕
                 Loh.Last_Update_Date = Sysdate,
                 Loh.Last_Updated_By  = in_user_code,
                 Loh.Version = Nvl(Loh.Version, 0) + 1
           Where Loh.Order_Head_Id = r_Lgorder_Head.Order_Head_Id;
        End If;
      End If;
      --add by ex_dengjh 2017-4-10 释放总部分配量
      if p_Trans_Sign_Flag = -1 AND nvl(r_Lgorder_Line.Occupy_Assign_Qty,0) > 0 
        and ((r_Lgorder_Head.Order_Head_State in ('679','381','23') and r_Lg_Ship_Plan.Lg_Order_Review_Flag = '01')
        or ((r_Lgorder_Line.Make_Order_Line_Flag = 'Y'Or r_Lgorder_Head.Hq_Lg_Order_Number Is Not Null) and r_Lg_Ship_Plan.Lg_Order_Review_Flag = '02')
        or (r_Lgorder_Head.Order_Head_State = '304' or r_Lgorder_Line.Order_Line_State = 'CLOSED')
        ) then
        pkg_pln_lg_order.p_pln_assign_occupy(IN_ENTITY_ID     => r_Lgorder_Head.Entity_Id,
                                             IN_ORDER_HEAD_ID => r_Lgorder_Line.Order_Head_Id,
                                             IN_ORDER_LINE_ID => r_Lgorder_Line.Order_Line_Id,
                                             IN_ASSIGN_QTY    => p_Trans_Order_Qty,
                                             IN_ASSIGN_SIGN   => -1,
                                             IN_USER_CODE     => in_user_code,
                                             OUT_RESULT       => p_Result);
        if p_Result <> v_Success then
          v_Value := '释放总部分配量失败！' || v_Nl || p_Result; 
          Raise v_Base_Exception;
        end if;
      end if;
      
      IF p_Trans_Sign_Flag = -1 AND r_Lg_Ship_Plan.Lg_Order_Review_Flag = '04'
        AND r_Lgorder_Head.Order_Head_State <> '304'
        AND nvl(r_Lgorder_Line.Order_Line_State, 'NORMAL') <> 'CLOSED' THEN
        UPDATE T_PLN_LG_ORDER_LINE L
           SET L.AFFIRM_QUANTITY = p_Trans_Order_Qty,
               L.INV_ID = r_Lg_Ship_Plan.Ship_Inventory_Id,
               L.INV_CODE = r_Lg_Ship_Plan.Ship_Inventory_Code,
               L.INV_NAME = r_Lg_Ship_Plan.Ship_Inventory_Name
         WHERE L.ORDER_LINE_ID = p_Lgorder_Line_Id;
            
        --解锁二次发运预占用库存
        PKG_SO_TO_POX.P_LG_ORDER_PRE_INV_OCCUPY(IN_ENTITY_ID     => r_Lgorder_Head.Entity_Id,
                                                IN_ORDER_HEAD_ID => r_Lgorder_Head.Order_Head_Id,
                                                IN_ORDER_LINE_ID => r_Lgorder_Line.Order_Line_Id,
                                                IN_OCCUPY_SIGN   => 1,
                                                IN_USER_CODE     => in_user_code,
                                                OUT_RESULT       => p_Result);
        IF p_Result <> v_Success THEN
          v_Value := '加锁二次发运预占用库存失败。产品编码=' || r_Lg_Ship_Plan.Item_Code ||
                      '，仓库编码='||r_Lg_Ship_Plan.Ship_Inventory_Code || v_Nl || '系统提示：'|| p_Result;
          raise v_Base_Exception;
        END IF;
      END IF;
    end if;
    
    --红冲操作，且来源代销单的更新代销单的可补货数量
    If p_Trans_Sign_Flag = -1 And r_Lgorder_Head.Sys_Source = 'CIMSDX' Then
      --提货订单状态保持评审完毕，不变
      Update t_Pln_Lg_Order_Head h
         Set h.Order_Head_State = '23'
       Where h.Order_Number = r_Lgorder_Head.Order_Number;
      --更新取消数量
      Update t_pln_lg_order_line l
         Set l.cancel_qty = l.center_affirm_quantity - nvl(l.affirmed_quantity,0)
       Where l.order_line_id = r_Lgorder_Line.Order_Line_Id;
      
      
      --更新可补货数量
      p_Update_Dx_Make_Up_Qty(p_Dx_Order_Number => r_Lgorder_Head.Source_Order_Number,
                              p_Item_Code       => r_Lgorder_Line.Item_Code,
                              p_Qty          => p_Trans_Order_Qty,
                              p_Sign_Flag    => 1,
                              p_Operate_Type => '发货计划/发货通知单红冲增加可补货数量',
                              p_Operate_Number => p_Lg_Ship_Plan_Id,
                              p_User_Code    => p_User_Code,
                              p_Result       => p_Result);
      IF p_Result <> v_Success THEN
        v_Value := '发货计划/发货通知单红冲增加可补货数量失败，代销单号：' || r_Lgorder_Head.Source_Order_Number || '，产品编码：' || 
                   r_Lgorder_Line.Item_Code || v_Nl || '系统提示：'|| p_Result;
        raise v_Base_Exception;
      END IF;
    End If;
	
	
    --add by houhs at 20200423 如果是自动直发锁款的，最后去更新锁款标识为N
    IF V_AUTO_DIRECT = 'Y' AND p_Trans_Sign_Flag = -1 THEN
       Update t_pln_lg_order_line l
          Set l.is_lock_amount = 'N'
        Where l.order_line_id = r_Lgorder_Line.Order_Line_Id
          and NVL(l.is_lock_amount, 'N') in ('NT', 'Y');
       
       update CIMS.T_PLN_LG_ORDER_LINE L
          set l.is_lock_amount = 'N'
        where L.Order_Line_Id in
              (select tl.source_line_id
                 from cims.t_pln_lg_order_line tl, cims.t_pln_lg_order_head th
                where th.order_head_id = tl.order_head_id
                  and th.entity_id = tl.entity_id
                  and th.sys_source = 'CIMS'
                  and tl.order_line_id = r_Lgorder_Line.Order_Line_Id)
                  and NVL(l.is_lock_amount, 'N') in ('NT', 'Y');
       
       update cims.t_Pln_Order_Head h
          set h.amount_lock_flag = 'N', h.last_update_date = sysdate,h.cancl_direct = 'Y'
        where h.order_head_id in
              (SELECT L.ORDER_HEAD_ID
                 FROM t_Pln_Lg_Relation Lr, t_Pln_Order_Line l
                Where Lr.Order_Line_Id = l.Order_Line_Id
                  AND lr.lg_order_line_id = r_Lgorder_Line.Order_Line_Id);
    END IF;
    
    --记录预约直发历史
    if r_Lg_Ship_Plan.Direct_Transport_Falg = 'Y' then
      v_TRANSPORT_HIS.Cancel_Reason := r_Lg_Ship_Plan.Pre_Field_04;
      v_TRANSPORT_HIS.Entity_Id := r_Lgorder_Line.Entity_Id;
      v_TRANSPORT_HIS.Direct_Transport_His_Id := s_PLN_DIRECT_TRANSPORT_HIS.Nextval;
      v_TRANSPORT_HIS.Order_Head_Id := r_Lg_Ship_Plan.Origin_Order_Id;
      v_TRANSPORT_HIS.Order_Line_Id := r_Lg_Ship_Plan.Origin_Line_Id;
      v_TRANSPORT_HIS.Item_Id := r_Lgorder_Line.Item_Id;
      if r_Lg_Ship_Plan.Direct_Status = '01' then --发货
        v_TRANSPORT_HIS.Direct_Transport_Qty := 0;
        v_TRANSPORT_HIS.Direct_Transpor_Date := r_Lg_Ship_Plan.Direct_Transport_Date;
        v_TRANSPORT_HIS.Already_Direct_Transport_Qty := p_Trans_Sign_Flag * p_Trans_Order_Qty;
      else
        v_TRANSPORT_HIS.Direct_Transport_Qty := p_Trans_Sign_Flag * p_Trans_Order_Qty;
        v_TRANSPORT_HIS.Direct_Transpor_Date := r_Lg_Ship_Plan.Direct_Transport_Date;
        v_TRANSPORT_HIS.Already_Direct_Transport_Qty := 0;
      end if;
      v_TRANSPORT_HIS.Lg_Order_Head_Id := r_Lgorder_Line.Order_Head_Id;
      v_TRANSPORT_HIS.Lg_Order_Line_Id := r_Lgorder_Line.Order_Line_Id;
      v_TRANSPORT_HIS.Lg_Ship_Plan_Id := r_Lg_Ship_Plan.Ship_Plan_Id;
      v_TRANSPORT_HIS.Created_By := in_user_code;
      v_TRANSPORT_HIS.Creation_Date := sysdate;
      v_TRANSPORT_HIS.Last_Updated_By := in_user_code;
      v_TRANSPORT_HIS.Last_Update_Date := sysdate;
      
      insert into T_PLN_DIRECT_TRANSPORT_HIS
        (ENTITY_ID,
         DIRECT_TRANSPORT_HIS_ID,
         ORDER_HEAD_ID,
         ORDER_LINE_ID,
         ITEM_ID,
         DIRECT_TRANSPORT_QTY,
         DIRECT_TRANSPOR_DATE,
         ALREADY_DIRECT_TRANSPORT_QTY,
         LG_ORDER_HEAD_ID,
         LG_ORDER_LINE_ID,
         LG_SHIP_PLAN_ID,
         CREATED_BY,
         CREATION_DATE,
         LAST_UPDATED_BY,
         LAST_UPDATE_DATE,
         CANCEL_REASON)
       values
        (v_TRANSPORT_HIS.Entity_Id,
         v_TRANSPORT_HIS.Direct_Transport_His_Id,
         v_TRANSPORT_HIS.Order_Head_Id,
         v_TRANSPORT_HIS.Order_Line_Id,
         v_TRANSPORT_HIS.Item_Id,
         v_TRANSPORT_HIS.Direct_Transport_Qty,
         v_TRANSPORT_HIS.Direct_Transpor_Date,
         v_TRANSPORT_HIS.Already_Direct_Transport_Qty,
         v_TRANSPORT_HIS.Lg_Order_Head_Id,
         v_TRANSPORT_HIS.Lg_Order_Line_Id,
         v_TRANSPORT_HIS.Lg_Ship_Plan_Id,
         v_TRANSPORT_HIS.Created_By,
         v_TRANSPORT_HIS.Creation_Date,
         v_TRANSPORT_HIS.Last_Updated_By,
         v_TRANSPORT_HIS.Last_Update_Date,
         v_TRANSPORT_HIS.Cancel_Reason);
    end if;
  Exception
    When v_Base_Exception Then
      Rollback;
      p_Result := v_Value;
    When Others Then
      Rollback;
      p_Result := v_Value || '失败,错误信息:' || Sqlerrm;
      Return;
  End;

  -----------------------------------------------------------------------------
  -- AUTHOR  : 李振
  -- CREATED : 2014-07-14 11:05:52
  -- PURPOSE : 检查计划订单的订单周期是否正确
  -----------------------------------------------------------------------------
  Procedure p_Check_Period(p_Period_Id   In Number, --阶段ID：年ID、月ID、周ID
                           p_Period_Type In Varchar2, --阶段类型：年、月、周
                           p_Open_Flag   In Varchar2, --是否检查阶段打开状态：Y：要求已打开，N：要求未打开；O:没有作要求
                           p_Close_Flag  In Varchar2, --是否检查阶段关闭状态：Y：要求已关闭，N：要求未关闭；O:没有作要求
                           p_Carry_Flag  In Varchar2, --是否检查阶段结转状态：Y：要求已结转，N：要求未结转；O:没有作要求
                           p_Result      Out Varchar2 --返回结果：成功返回"SUCCESS"，失败返回原因
                           ) Is

    v_Parent_Period_Id Number Not Null := -1; --父阶段ID

    v_Message         Varchar2(50); --辅助结果
    v_Status          Varchar2(50); --辅助状态
    v_String          Varchar2(500); --辅助信息
    v_Set_Of_Books_Id Number; --财务账套ID
    v_Entity_Id       Number;
    v_p_Month_Id      Number Not Null := -1; --上月ID
    v_n_Month_Id      Number Not Null := -1; --下月ID
    v_Month_Id        Number;
    v_Month_Name      Varchar2(40); --本月名称

    v_Year_Id Number;
    v_year_name t_pln_order_period.period_code%type; --年名称

    v_p_Week_Id Number Not Null := -1; --上周ID
    v_n_Week_Id Number Not Null := -1; --下周ID
    v_Week_Id   Number Not Null := -1; --本周ID

    v_Week_Name        Varchar2(40); --本周名称
    v_Month_Edition    Number Not Null := -1; --本月版本号
    v_Month_Begin_Date Date; --月起始日期
    v_Month_End_Date   Date; --月终止日期
    v_Week_Edition     Number Not Null := -1; --本周版本号
    v_Week_Begin_Date  Date; --周起始日期
    v_Week_End_Date    Date; --周起始日期
    v_Pln_Order_Period_TN  Number;
  Begin
    p_Result := v_Success;

    v_Message := '检查计划阶段失败: ';
    v_String  := Substrb((v_Nl || '阶段ID：' || To_Char(p_Period_Id) || v_Nl ||
                         '阶段类型：' || p_Period_Type || v_Nl),
                         1,
                         500);

    v_Status := Substrb((v_Nl || '输入参数检查' || '：'), 1, 50);
    If p_Period_Id Is Null Or
       Nvl(p_Period_Type, v_Null) Not In ('年', '月', '周', 'T+3周期') Or
       Nvl(p_Open_Flag, v_Null) Not In ('Y', 'N', 'O') Or
       Nvl(p_Close_Flag, v_Null) Not In ('Y', 'N', 'O') Then
      p_Result := Substrb((v_Message || v_Status || '部分参数为空或错误。' ||
                          v_String),
                          1,
                          2000);
      Return;
    End If;
    v_Status := Substrb((v_Nl || '检查失败' || '：'), 1, 50);
    Begin
      Select Parent_Period_Id, Entity_Id
        Into v_Parent_Period_Id, v_Entity_Id
        From t_Pln_Order_Period
       Where Period_Id = p_Period_Id
         And Period_Type = p_Period_Type;
    Exception
      When Others Then
        p_Result := Substrb((v_Message || v_Status || '检查失败' || v_Nl ||
                            '请检查该阶段存在、阶段类型相符。' || v_String),
                            1,
                            2000);
        Return;
    End;
    Begin
      --获取T+N订单结转模式  add by lizhen 2015-07-15
      v_Pln_Order_Period_TN := To_Number(Pkg_Bd.f_Get_Parameter_Value('PLN_ORDER_PERIOD_TN',
                                                                      v_Entity_Id));
    Exception
      When Others Then
        p_Result := '获取主体参数失败，主体参数编码【PLN_ORDER_PERIOD_TN】！' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;

    v_Status := Substrb((v_Nl || '获取周、月、年' || '：'), 1, 50);
    --If p_Period_Type In  '周' Then -- modi by lizhen 2015-07-16
    If p_Period_Type In ('T+3周期', '周') Then
      v_Week_Id  := p_Period_Id;
      v_Month_Id := v_Parent_Period_Id;

      Select Parent_Period_Id
        Into v_Year_Id
        From t_Pln_Order_Period
       Where Period_Id = v_Month_Id;
    Elsif p_Period_Type = '月' Then
      v_Month_Id := p_Period_Id;
      v_Year_Id  := v_Parent_Period_Id;
    Elsif p_Period_Type = '年' Then
      v_Year_Id := p_Period_Id;
    End If;

    v_Status := Substrb((v_Nl || '检查周失败' || '：'), 1, 50);
    If p_Period_Type In ('周', 'T+3周期') Then
      Begin
        Select Period_Code,
               Prior_Period_Id,
               Next_Period_Id,
               Sale_Year_Week,
               Begin_Date,
               End_Date
          Into v_Week_Name,
               v_p_Week_Id,
               v_n_Week_Id,
               v_Week_Edition,
               v_Week_Begin_Date,
               v_Week_End_Date
          From t_Pln_Order_Period
         Where Period_Id = v_Week_Id
           And Entity_Id = v_Entity_Id
           And Nvl(Parent_Period_Id, -1) = v_Month_Id
           And Nvl(Period_Type, v_Null) In ('T+3周期', '周')  -- modi by lizhen 2015-07-16
           And Nvl(Sale_Year_Month, -1) In
               (1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12)
           --And Nvl(Sale_Year_Week, -1) In (0, 1, 2, 3, 4)  -- modi by lizhen 2015-07-16
           And Begin_Date Is Not Null
           And Begin_Date = Trunc(Begin_Date)
           And (Nvl(Sale_Year_Week, -1) = 0 And
               Begin_Date = Trunc(Begin_Date, 'MM') And
               End_Date = Trunc(Last_Day(Trunc(Begin_Date, 'MM'))) Or
               ((Period_Type = '周' And (Nvl(Sale_Year_Week, -1) = 1 And
               Begin_Date = Trunc(Begin_Date, 'MM') And
               End_Date = Trunc(Begin_Date, 'MM') + 6 Or
               Nvl(Sale_Year_Week, -1) = 2 And
               Begin_Date = Trunc(Begin_Date, 'MM') + 7 And
               End_Date = Trunc(Begin_Date, 'MM') + 7 + 6 Or
               Nvl(Sale_Year_Week, -1) = 3 And
               Begin_Date = Trunc(Begin_Date, 'MM') + 7 + 7 And
               End_Date = Trunc(Begin_Date, 'MM') + 7 + 7 + 6 Or
               Nvl(Sale_Year_Week, -1) = 4 And
               Begin_Date = Trunc(Begin_Date, 'MM') + 7 + 7 + 7 And
               End_Date = Trunc(Last_Day(Trunc(Begin_Date, 'MM')))))
               Or (Period_Type = 'T+3周期' And
               Begin_Date = Trunc(Begin_Date, 'MM') + (Nvl(Sale_Year_Week, 0) - 1) * v_Pln_Order_Period_TN  And
               End_Date = Decode(trunc(To_Char(Last_Day(Begin_Date), 'DD') / v_Pln_Order_Period_TN),
                                 Sale_Year_Week,
                                 Last_Day(Begin_Date),
                                 Trunc(Begin_Date, 'MM') + Nvl(Sale_Year_Week, 0) * v_Pln_Order_Period_TN - 1))) )
           And (Nvl(p_Open_Flag, v_Null) = 'O' Or
               Nvl(p_Open_Flag, v_Null) = 'Y' And Open_Date Is Not Null Or
               Nvl(p_Open_Flag, v_Null) = 'N' And Open_Date Is Null)
           And (Nvl(p_Close_Flag, v_Null) = 'O' Or
               Nvl(p_Close_Flag, v_Null) = 'Y' And Close_Date Is Not Null Or
               Nvl(p_Close_Flag, v_Null) = 'N' And Close_Date Is Null);
      Exception
        When Others Then
          --获取月、周名称
          begin
            select p.period_code
              into v_Month_Name
              from t_pln_order_period p
             where p.period_id = v_Month_Id;
          exception
            when others then
              null;
          end;
          
          begin
            select p.period_code
              into v_Week_Name
              from t_pln_order_period p
             where p.period_id = v_Week_Id;
          exception
            when others then
              null;
          end;
          
          Select v_Message || v_Status || v_Nl || '周阶段数据不存在，或者未打开。' ||
                 v_String || '月ID：' || To_Char(v_Month_Id) || '，' || v_Month_Name || v_Nl ||
                 '周ID：' || To_Char(v_Week_Id) || '，' || v_Week_Name || v_Nl
            Into p_Result
            From Dual;
          Return;
      End;
    End If;

    v_Status := Substrb((v_Nl || '检查月失败' || '：'), 1, 50);
    If p_Period_Type In ('周', '月', 'T+3周期') Then
      Begin
        Select Period_Code,
               Prior_Period_Id,
               Next_Period_Id,
               Sale_Year_Month,
               Begin_Date,
               End_Date
          Into v_Month_Name,
               v_p_Month_Id,
               v_n_Month_Id,
               v_Month_Edition,
               v_Month_Begin_Date,
               v_Month_End_Date
          From t_Pln_Order_Period
         Where Period_Id = v_Month_Id
           And Entity_Id = v_Entity_Id
           And Nvl(Parent_Period_Id, -1) = v_Year_Id
           And Nvl(Period_Type, v_Null) = '月'
           And Nvl(Sale_Year_Month, -1) In
               (1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12)
           And Begin_Date Is Not Null
           And Begin_Date = Trunc(Begin_Date, 'MM')
           And End_Date = Trunc(Last_Day(Begin_Date))
           And (p_Period_Type In ('周', 'T+3周期') And
               Begin_Date <= Nvl(v_Week_Begin_Date, Begin_Date - 1) And
               End_Date >= Nvl(v_Week_End_Date, End_Date + 1) And
               (Nvl(p_Open_Flag, v_Null) = 'O' Or
               Nvl(p_Open_Flag, v_Null) = 'N' Or
               Nvl(p_Open_Flag, v_Null) = 'Y' And Open_Date Is Not Null) And
               (Nvl(p_Close_Flag, v_Null) = 'O' Or
               Nvl(p_Close_Flag, v_Null) = 'Y' Or
               Nvl(p_Close_Flag, v_Null) = 'N' And Close_Date Is Null) Or
               p_Period_Type In ('月') And
               (Nvl(p_Open_Flag, v_Null) = 'O' Or
               Nvl(p_Open_Flag, v_Null) = 'Y' And Open_Date Is Not Null Or
               Nvl(p_Open_Flag, v_Null) = 'N' And Open_Date Is Null) And
               (Nvl(p_Close_Flag, v_Null) = 'O' Or
               Nvl(p_Close_Flag, v_Null) = 'Y' And Close_Date Is Not Null Or
               Nvl(p_Close_Flag, v_Null) = 'N' And Close_Date Is Null));
      Exception
        When Others Then
          --获取月、年名称
          begin
            select p.period_code
              into v_Month_Name
              from t_pln_order_period p
             where p.period_id = v_Month_Id;
          exception
            when others then
              null;
          end;
          
          begin
            select p.period_code
              into v_year_name
              from t_pln_order_period p
             where p.period_id = v_Year_Id;
          exception
            when others then
              null;
          end;
          
          Select v_Message || v_Status || '月阶段数据不存在，或者未打开。' || v_String || v_Nl ||
                 '年ID ：' || To_Char(v_Year_Id) || '，' || v_year_name || v_Nl || '月ID ：' ||
                 To_Char(v_Month_Id) || '，' || v_Month_Name
            Into p_Result
            From Dual;
          Return;
      End;
    End If;

    v_Status := Substrb((v_Nl || '检查年失败' || '：'), 1, 50);
    Begin
      Select Nvl(Period_Id, -1) /*,
                               100 - NVL(YEAR_RIGIDITY, 0),
                               100 - NVL(THREE_MONTH_RIGIDITY, 0),
                               100 - NVL(MONTH_RIGIDITY, -1)*/
        Into v_Week_Id /*,
                               V_YEAR_RIGIDITY,
                               V_MONTH_RIGIDITY,
                               V_WEEK_RIGIDITY*/
        From t_Pln_Order_Period
       Where Period_Id = v_Year_Id
         And Entity_Id = v_Entity_Id
         And Nvl(Parent_Period_Id, -1) = -1
         And Nvl(Period_Type, v_Null) = '年'
         And Begin_Date Is Not Null
         And Begin_Date = Trunc(Begin_Date, 'MM')
            --由于存在改变年度划分的情况，需取消该检查 AND END_DATE = TRUNC(LAST_DAY(ADD_MONTHS(BEGIN_DATE, 11)))
         And (p_Period_Type In ('周', '月', 'T+3周期') And
             Begin_Date <= Nvl(v_Month_Begin_Date, Begin_Date - 1) And
             End_Date >= Nvl(v_Month_End_Date, End_Date + 1) And
             (Nvl(p_Open_Flag, v_Null) = 'O' Or
             Nvl(p_Open_Flag, v_Null) = 'N' Or
             Nvl(p_Open_Flag, v_Null) = 'Y' And Open_Date Is Not Null) And
             (Nvl(p_Close_Flag, v_Null) = 'O' Or
             Nvl(p_Close_Flag, v_Null) = 'Y' Or
             Nvl(p_Close_Flag, v_Null) = 'N' And Close_Date Is Null) Or
             p_Period_Type In ('年') And
             (Nvl(p_Open_Flag, v_Null) = 'O' Or
             Nvl(p_Open_Flag, v_Null) = 'Y' And Open_Date Is Not Null Or
             Nvl(p_Open_Flag, v_Null) = 'N' And Open_Date Is Null));
    Exception
      When Others Then
        --获取年名称
        begin
          select p.period_code
            into v_year_name
            from t_pln_order_period p
           where p.period_id = v_Year_Id;
        exception
          when others then
            null;
        end;
        
        Select v_Message || v_Status || '年阶段数据不存在，或者未打开。' || v_String || v_Nl ||
               '年ID ：' || To_Char(v_Year_Id) || '，' || v_year_name
          Into p_Result
          From Dual;
        Return;
    End;
  Exception
    When Others Then
      p_Result := '失败：' || p_Result || v_Nl || Sqlerrm;
  End;

  -----------------------------------------------------------------------------------------
  --Anthor: Nicro.Li
  --Purpost: 根据单据类型获取默订周期
  -------------------------------------------------------------------------------------------
  Function f_Get_Default_Period(p_Order_Type_Id In Number, --单据类型ID
                                p_Entity_Id     In Number --主体ID
                                ) Return Number Is
    v_Send_By_Type        Varchar2(20);
    v_Advance_Period_Week Number; --提前周期
    v_Count               Number := 0;
  Begin
    Select Ot.Send_By_Type, Ot.Period_Week
      Into v_Send_By_Type, v_Advance_Period_Week
      From t_Pln_Order_Type Ot
     Where Ot.Order_Type_Id = p_Order_Type_Id
       And Ot.Entity_Id = p_Entity_Id;
    /*0 按周报送
    1 按月报送
    2 按月多次报送
    3 按年报送
    4 按周多次报送
    5 不定期报送
    6 按T+3周期报送
    7 按T+3周期多次报送 */
    For r_Period In (Select *
                       From t_Pln_Order_Period Pop
                      Where Pop.End_Date >= Trunc(Sysdate)
                        And ((Pop.Period_Type = '周' And
                            v_Send_By_Type In ('0', '4', '5')) Or
                            (Pop.Period_Type = '月' And
                            v_Send_By_Type In ('1', '2')) Or
                            (Pop.Period_Type = '年' And
                            v_Send_By_Type In ('3')) Or
                            --add by lizhen  增加T+3周期的获取
                            (Pop.Period_Type = 'T+3周期' And
                            v_Send_By_Type In ('6', '7'))
                            )
                        And Pop.Entity_Id = p_Entity_Id
                      Order By Pop.Period_Code) Loop
      If v_Count = v_Advance_Period_Week Then
        Return r_Period.Period_Id;
      End If;
      v_Count := v_Count + 1;
    End Loop;
    Return Null;
  Exception
    When Others Then
      Return Null;
  End;

  -----------------------------------------------------------------------------------------
  --Anthor: Nicro.Li
  --Purpost: 根据套件、散件,获取散件的配套基数
  -------------------------------------------------------------------------------------------
  Function f_Get_Item_Assembly_Base(p_Ass_Item_Id In Number,
                                    p_Sub_Item_Id In Number) Return Number Is

    v_Base_Qty Number;
  Begin
    Begin
      Select Nvl(Ias.Quantity, 1)
        Into v_Base_Qty
        From t_Bd_Item_Assemblies Bia, t_Bd_Item_Assemblies_Sub Ias
       Where Bia.Item_Assembly_Id = Ias.Item_Assembly_Id
         And Bia.Entity_Id = Ias.Entity_Id
         And Trunc(Sysdate) Between Bia.Begin_Date And
             Nvl(Bia.End_Date, Sysdate)
         And Trunc(Sysdate) Between Ias.Begin_Date And
             Nvl(Ias.End_Date, Trunc(Sysdate))
         And Bia.Item_Id = p_Ass_Item_Id
         And Ias.Item_Id = p_Sub_Item_Id;
    Exception
      When No_Data_Found Then
        Begin
          Select 1
            Into v_Base_Qty
            From t_Bd_Item Tbi
           Where Tbi.Item_Id = p_Sub_Item_Id
             And Not Exists
           (Select 1
                    From t_Bd_Item_Assemblies Bia
                   Where Bia.Item_Id = Tbi.Item_Id
                     And Trunc(Sysdate) Between Bia.Begin_Date And
                         Nvl(Bia.End_Date, Sysdate));
        Exception
          When Others Then
            v_Base_Qty := Null;
        End;
      When Others Then
        v_Base_Qty := Null;
    End;
    Return v_Base_Qty;
  Exception
    When Others Then
      Return Null;
  End;

  -----------------------------------------------------------------------------------------
  --Anthor: Nicro.Li
  --Purpost: 写入JOB错误历史表
  -------------------------------------------------------------------------------------------
  Procedure p_Write_Job_Log(p_Module_Code          In Varchar2,
                            p_Procedure_Name       In Varchar2,
                            p_Error_Msg            In Varchar2,
                            p_Source_Order_Head_Id In Number,
                            p_Source_Order_Line_Id In Number,
                            p_Item_Id              In Number,
                            p_Inventory_Id         In Number,
                            p_Quantity             In Number) Is
  Begin
    Insert Into t_Pln_Job_Error_Log
      (Job_Date,
       Module_Code,
       Procedure_Name,
       Error_Msg,
       Source_Order_Head_Id,
       Source_Order_Line_Id,
       Item_Id,
       Inventory_Id,
       Quantity) Values
      (Sysdate,
       p_Module_Code,
       p_Procedure_Name,
       p_Error_Msg,
       p_Source_Order_Head_Id,
       p_Source_Order_Line_Id,
       p_Item_Id,
       p_Inventory_Id,
       p_Quantity);
  Exception
    When Others Then
      Null;
  End;

  -----------------------------------------------------------------------------------------
  --Anthor: Nicro.Li
  --Create: 2015-03-23
  --Purpost: 检查产品凑整数量
  -------------------------------------------------------------------------------------------
  Procedure p_Check_Item_Rounding(p_Entity_Id In Number, --主体ID
                                  p_Item_Id   In Number, --产品ID
                                  p_Check_Qty In Number, --待检查数量
                                  p_Result    Out Varchar2) Is
    r_Bd_Item t_Bd_Item%Rowtype;
  Begin
    p_Result := v_Success;
    --检查是否录入中心评审数量
    Begin
      Select *
        Into r_Bd_Item
        From t_Bd_Item Bi
       Where Bi.Item_Id = p_Item_Id
         And Bi.Entity_Id = p_Entity_Id;
    Exception
      When Others Then
        p_Result := '获取产品属性失败！' || v_Nl || '产品ID：' || To_Char(p_Item_Id) || v_Nl ||
                    Sqlerrm;
        Raise v_Base_Exception;
    End;
    --增加凑整数量检查
    If Nvl(r_Bd_Item.Is_Rounding, 'N') = 'Y' Then
      If Nvl(r_Bd_Item.Rounding_Cnt, 0) = 0 Then
        p_Result := '产品设置凑整，但凑整数量为0。' || v_Nl || '产品编码：' ||
                    r_Bd_Item.Item_Code;
        Raise v_Base_Exception;
      End If;
      If Mod(p_Check_Qty, Nvl(r_Bd_Item.Rounding_Cnt, 0)) != 0 Then
        p_Result := '凑整数量检查失败，无法凑整。' ||v_nl|| '产品编码：' ||
                    r_Bd_Item.Item_Code  || ' 本次检查数量：' ||
                    To_Char(p_Check_Qty) || ' 产品凑整数：' ||
                    To_Char(r_Bd_Item.Rounding_Cnt)||'。';
        Raise v_Base_Exception;
      End If;
    End If;
  Exception
    When v_Base_Exception Then
      p_Result := p_Result;
    When Others Then
      p_Result := '检查产品凑整数失败！' || v_Nl || Sqlerrm;
  End;

  -----------------------------------------------------------------------------------------
  --Anthor: Nicro.Li
  --Create: 2015-04-16
  --Purpost: 检查产品产品产地生命周期
  -------------------------------------------------------------------------------------------
  Function p_Chk_Item_Prdc_Life_Cycle(p_Entity_Id         In Number, --主体ID
                                      p_Item_Id           In Number, --产品ID
                                      p_Producing_Area_Id In Number, --产地ID
                                      p_Order_Phase       In Varchar,  --订单检查阶段
                                      --计划订单类型PLN_ORDER，提货订单类型LG_ORDER，月预测MONTH_PLAN
                                      p_Type              In Varchar DEFAULT 'PLN_ORDER'   --订单类型t_Pln_Item_Life_Cycle.type  huanghb12
                                      ) Return Varchar2 Is
     v_Item_Code         Varchar2(100);
     v_Item_Life_Cycle   Varchar2(100);
     v_Order_Phase_Flag  Varchar2(100);
     v_Err_Msg           Varchar2(2000);
     v_Producing_Area_Name Varchar2(100);
     v_Check_Product_Type_Flag  Varchar2(100);
     v_Product_Type             Varchar2(100);
     v_Product_Form             t_Bd_Item.Productform%Type;
   Begin
     v_Item_Code := Null;
     If p_Type  = 'LG_ORDER'  then 
         Begin
           Select Nvl(Decode(p_Order_Phase,
                             v_Phase_Month_Submit, --Month_SUBMIT
                             Ilc.Is_Month_Flag,
                             v_Phase_Week_Submit, --'WEEK_SUBMIT',
                             Ilc.Is_Week_Flag,
                             v_Phase_Intf_Aps, --'INTF_APS',
                             Ilc.Is_Aps_Flag,
                             v_Phase_Order_Affirm, -- 'ORDER_AFFIRM' 校验生命周期 jiangwei29 20190523
                             Ilc.Can_Affirm_Flag,
                             'N'),
                      'N') Order_Phase_Flag,
                  Tbi.Item_Code,
                  Ucl.Code_Name,
                  Tbi.Producttype,   --add by lizhen 2016-01-15
                  Tbi.Productform  --add by lizhen 2017-04-27
             Into v_Order_Phase_Flag,
                  v_Item_Code,
                  v_Item_Life_Cycle,
                  v_Product_Type,  --add by lizhen 2016-01-15
                  v_Product_Form   --add by lizhen 2017-04-27
             From t_Bd_Item                 Tbi,
                  Up_Codelist               Ucl,
                  t_Pln_Item_Life_Cycle     Ilc
            Where Tbi.Productphase = Ilc.System_Status -- jiangwei29 20190523 
              And Tbi.Entity_Id = Ilc.Entity_Id(+)
              And Tbi.Productphase = Ucl.Code_Value(+)
              And Tbi.Entity_Id = p_Entity_Id
              And Tbi.Item_Id = p_Item_Id
              And Ucl.Codetype(+) = 'PLN_ITEM_PRODUCING_AREA_STATE'
              --增加条件t_Pln_Item_Life_Cycle，限制生命周期对应的订单类型huanghb12
              And Ilc.Type = p_Type ;
         Exception
           When No_Data_Found THEN
             SELECT I.ITEM_CODE
               INTO V_ITEM_CODE
               FROM T_BD_ITEM I
              WHERE I.ITEM_ID = P_ITEM_ID
                AND I.ENTITY_ID = p_Entity_Id;
           When Others Then
             v_Err_Msg := '【产品ID：' || To_Char(p_Item_Id) || '  产地ID：' ||
                          To_Char(p_Producing_Area_Id) || Sqlerrm || '】';
         End;     
     ELSE     
     Begin
       Select Nvl(Decode(p_Order_Phase,
                         v_Phase_Month_Submit, --Month_SUBMIT
                         Ilc.Is_Month_Flag,
                         v_Phase_Week_Submit, --'WEEK_SUBMIT',
                         Ilc.Is_Week_Flag,
                         v_Phase_Intf_Aps, --'INTF_APS',
                         Ilc.Is_Aps_Flag,
                         v_Phase_Order_Affirm, -- 'ORDER_AFFIRM' 校验生命周期 jiangwei29 20190523
                         Ilc.Can_Affirm_Flag,
                         'N'),
                  'N') Order_Phase_Flag,
              Tbi.Item_Code,
              Ucl.Code_Name,
              Ipa.Producing_Area_Name,
              Tbi.Producttype,   --add by lizhen 2016-01-15
              Tbi.Productform  --add by lizhen 2017-04-27
         Into v_Order_Phase_Flag,
              v_Item_Code,
              v_Item_Life_Cycle,
              v_Producing_Area_Name,
              v_Product_Type,  --add by lizhen 2016-01-15
              v_Product_Form   --add by lizhen 2017-04-27
         From t_Pln_Item_Producing_Area Ipa,
              t_Bd_Item                 Tbi,
              Up_Codelist               Ucl,
              t_Pln_Item_Life_Cycle     Ilc
        Where Ipa.State = Ilc.System_Status(+)
          And Decode(p_Order_Phase,v_Phase_Order_Affirm,Tbi.Productphase,Ilc.System_Status) = Ilc.System_Status -- jiangwei29 20190523 
          And Ipa.Entity_Id = Ilc.Entity_Id(+)
          And Tbi.Item_Id = Ipa.Item_Id
          And Tbi.Entity_Id = Ipa.Entity_Id
          And Ipa.State = Ucl.Code_Value(+)
          And Ipa.Entity_Id = p_Entity_Id
          And Ipa.Item_Id = p_Item_Id
          And Ipa.Producing_Area_Id = p_Producing_Area_Id
          And Ucl.Codetype(+) = 'PLN_ITEM_PRODUCING_AREA_STATE'
          And Trunc(Sysdate) Between Ipa.Begin_Date And Trunc(Nvl(Ipa.End_Date, Sysdate)) --modi by lizhen 2016-01-16
          --增加条件t_Pln_Item_Life_Cycle，限制生命周期对应的订单类型huanghb12
          And Ilc.Type = p_Type
          ;
     Exception
       When No_Data_Found THEN
         SELECT I.ITEM_CODE
           INTO V_ITEM_CODE
           FROM T_BD_ITEM I
          WHERE I.ITEM_ID = P_ITEM_ID
            AND I.ENTITY_ID = p_Entity_Id;
       When Others Then
         v_Err_Msg := '【产品ID：' || To_Char(p_Item_Id) || '  产地ID：' ||
                      To_Char(p_Producing_Area_Id) || Sqlerrm || '】';
     End;

     --add by lizhen 2016-01-15 产品型态为“DOMESTIC_MARKET_MAKE 内销定制"是否允许制单，不检查生命周期
     --add by lizhen 2017-04-27 产品型态为“INDORR_PRODUCT","OUTDORR_PRODUCT"，退市状态时，允许下单
     If Nvl(v_Order_Phase_Flag, 'N') != 'Y' Then
       Begin
         Select 'Y'
           Into v_Check_Product_Type_Flag
           From v_Up_Codelist c, t_Pln_Item_Producing_Area Ipa
          Where c.Codetype = 'PLN_ORDER_CREATE_CHECK_PRODUCTTYPE'
            And c.Enabled = 0
            And Ipa.Item_Id = p_Item_Id
            And Ipa.Producing_Area_Id = p_Producing_Area_Id
            And Trunc(Sysdate) Between Ipa.Begin_Date And
                Trunc(Nvl(Ipa.End_Date, Sysdate))
            And Nvl(Ipa.State, '_') = c.Code_Name
            And (c.Code_Value = Nvl(v_Product_Type, '_') Or
                c.Code_Value = v_Product_Form)  --add by lizhen 2017-04-27 产品来源属性控制允许下单
            And c.Entity_Id = p_Entity_Id;
       Exception
         When Others Then
           v_Check_Product_Type_Flag := 'N';
       End;
     End If;
     If v_Check_Product_Type_Flag = 'Y' Then
       v_Order_Phase_Flag := 'Y';
     End If;
     End If;
     If Nvl(v_Order_Phase_Flag, 'N') != 'Y' Then
        Return  '【产品编码：' || v_Item_Code || '  产地名称：' ||
                      v_Producing_Area_Name || '  生命周期状态：' ||
                      v_Item_Life_Cycle || '  】';
     Else
       Return v_Order_Phase_Flag;
     End If;
   Exception
     When v_Base_Exception Then
       Return v_Err_Msg;
     When Others Then
       Return '产品ID：【' || To_Char(p_Item_Id) || '】产地ID：' || To_Char(p_Producing_Area_Id)  || Sqlerrm;
   End;

  ----------------------------------------------------------------------
  ---- AUTHOR  : Nicro.Li
  -- CREATED : 2015-07-10
  -- PURPOSE : T+N订单模试下计算计划订单的下线齐套率
  ----------------------------------------------------------------------
  Procedure p_Count_Order_Neat_Set_Rate(p_Order_Head_id  In Number, --计划订单头ID
                                        p_Entity_Id       In Number, --主体ID
                                        p_User_Code       In Varchar2, --用户编码
                                        p_Result          Out Varchar2 --返回结果，成功返回“SUCCESS”，失败返回错误信息
                                        ) Is
    v_Supply_Sum_Qty        Number;
    v_Can_Product_Sum_Qty   Number;
    v_Neat_Set_Rete         Number;
    v_Pln_Is_Merge_Lg_Order Varchar2(100);
  Begin
    p_Result := v_Success;
    Begin
      v_Pln_Is_Merge_Lg_Order := Pkg_Bd.F_Get_Parameter_Value('PLN_IS_MERGE_LG_ORDER',
                                                              p_Entity_Id);
    Exception
      When Others Then
        p_Result := '获取主体参数【PLN_IS_MERGE_LG_ORDER】失败！' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;
    If v_Pln_Is_Merge_Lg_Order In ('TN_SUM', 'TN_SINGLE') Then
      Select Sum(Nvl(Ol.Inv_Affirm_Qty, 0) + Nvl(Ol.Can_Produce_Qty, 0) -
                 Nvl((Select Max(Nvl(Pod.Cancel_Qty, 0))
                    From t_Pln_Order_Detail Pod
                   Where Pod.Order_Line_Id = Ol.Order_Line_Id
                     And Pod.Entity_Id = Ol.Entity_Id), 0)
                 --modi by lizhen 2016-05-26 已入库的取消不纳入齐套率计算
                 /*-
                 Nvl(Ol.Cancel_Inv_Check_Qty, 0) -
                 Nvl(Ol.Cancel_Inv_In_Qty, 0)*/),
             Sum(Nvl(Ol.Supply_Qty, 0) + Nvl(Ol.Inv_Affirm_Qty, 0))
        Into v_Can_Product_Sum_Qty, v_Supply_Sum_Qty
        From t_Pln_Order_Line Ol
       Where Ol.Order_Head_Id = p_Order_Head_Id;
      Begin
        If Nvl(v_Can_Product_Sum_Qty, 0) != 0 Then
          Select Round(Nvl(v_Supply_Sum_Qty, 0) / Nvl(v_Can_Product_Sum_Qty, 1) * 100,
                       2)
            Into v_Neat_Set_Rete
            From Dual;
         Else
           v_Neat_Set_Rete := 0;
         End If;
      Exception
        When Others Then
          p_Result := '计算齐套率失败！' || v_Nl || Sqlcode;
          Raise v_Base_Exception;
      End;

      --更新订单头的齐套率
      Update t_Pln_Order_Head Oh
         Set Oh.Neat_Set_Rate    = Nvl(v_Neat_Set_Rete, 0),
             Oh.Last_Updated_By  = p_User_Code,
             Oh.Last_Update_Date = Sysdate
       Where Oh.Order_Head_Id = p_Order_Head_Id;

      Update t_Pln_Lg_Order_Line Ol
         Set Ol.Neat_Set_Rate    = Nvl(v_Neat_Set_Rete, 0),
             Ol.Last_Updated_By  = p_User_Code,
             Ol.Last_Update_Date = Sysdate
       Where Exists (Select 1
                From t_Pln_Lg_Relation Lr
               Where Lr.Lg_Order_Line_Id = Ol.Order_Line_Id
                 And Lr.Order_Head_Id = p_Order_Head_Id);

      --更新提货订单头显示整张提货订单的齐套率，行齐套率相加/总行数
      Update t_Pln_Lg_Order_Head Oh
         Set Oh.Neat_Set_Line    = Nvl((Select Sum(Nvl(Ol.Neat_Set_Rate, 0)) /
                                              Nvl(Count(*), 1)
                                         From t_Pln_Lg_Order_Line Ol
                                        Where Ol.Order_Head_Id = Oh.Order_Head_Id
                                        --add by lizhen 2016-05-25 只计算转T+3的订单行信息
                                          And Exists
                                        (Select 1
                                                 From t_Pln_Lg_Relation Lr
                                                Where Lr.Lg_Order_Line_Id = Ol.Order_Line_Id
                                                  --20160907 hejy3 计算所有T+3订单
                                                  /*And Lr.Order_Head_Id = p_Order_Head_Id*/
                                                  AND lr.lg_order_head_id = ol.order_head_id)),
                                       0),
             Oh.Version          = Nvl(Oh.Version, 1) + 1,
             Oh.Last_Updated_By  = p_User_Code,
             Oh.Last_Update_Date = Sysdate
       Where Exists (Select 1
                From t_Pln_Lg_Relation Lr
               Where Lr.Lg_Order_Head_Id = Oh.Order_Head_Id
                 And Lr.Order_Head_Id = p_Order_Head_Id);
    End If;
  Exception
    When v_Base_Exception Then
      p_Result := p_Result;
      Rollback;
    When Others Then
      p_Result := '计算计划订单的发货齐套率失败,错误信息' || Sqlerrm;
      Rollback;
  End;

  -----------------------------------------------------------------------------
  -- AUTHOR  : Nicro.Li
  -- CREATED : 2015-07-20
  -- PURPOSE : 订单送审前检查到款金额
  -----------------------------------------------------------------------------
  Procedure p_Submit_Check_Amount(p_Order_Type_Id   In Number, ----订单ID
                                  p_Customer_Id     In Number, --客户ID
                                  p_Account_Id      In Number, --账户ID
                                  p_Sales_Main_Type In Varchar2, --产品大类
                                  p_Amount          In Number, --金额
                                  p_Discount_Amount In Number, --折扣客
                                  p_Result          In Out Varchar2, --返回结果：SUCCESS——>过程执行完成；FAILURE——>中途抛错
                                  p_Message         Out Varchar2 --返回信息：这里的值初始为SUCCESS
                                  ) Is
    r_Order_Type       t_pln_order_type%Rowtype;
    v_Lg_No_Ship_Amount    Number;  --提货订单已评审未发货金额
    v_Lg_No_Ship_Discount_Amount  Number;
    v_Credit_Amount           Number;
    v_Credit_Discount_Amount  Number;
  Begin
    p_Result := v_Success;
    p_Message := v_Success;
    Begin
      Select *
        Into r_Order_Type
        From t_Pln_Order_Type Ot
       Where Ot.Order_Type_Id = p_Order_Type_Id;
    Exception
      When Others Then
        p_Result  := v_Failure;
        p_Message := '获取订单单据类败！单据类型ID：' || To_Char(p_Order_Type_Id) || v_Nl ||
                     Sqlerrm;
        Raise v_Base_Exception;
    End;
    If Nvl(r_Order_Type.Is_Submit_Chk_Amout, 'N') = 'N' Then
      Return;
    End If;
    Begin
      Select Sum((Decode(Loh.Order_Head_State,
                         '20',
                         Lol.Quantity,
                         Nvl(Lol.Center_Affirm_Quantity, Lol.Quantity)) -
                 --add by lizhen 2015-11-30 数据增加减去取消数量 Cancel_Qty
                 Nvl(Lol.Affirmed_Quantity, 0) - Nvl(Lol.Cancel_Qty, 0)) *
                 Decode(Lol.Project_Order_Line_Id,
                        Null,
                        Nvl(Lol.List_Price, 0),
                        Nvl(Lol.Apply_List_Price, 0)) *
                 (100 - Decode(Lol.Project_Order_Line_Id,
                               Null,
                               Nvl(Lol.Discount_Rate, 0),
                               Nvl(Lol.Apply_Discount_Rate, 0) -
                  nvl(lol.ordered_discount_rate,0))) / 100),
             Sum((Decode(Loh.Order_Head_State,
                         '20',
                         Lol.Quantity,
                         Nvl(Lol.Center_Affirm_Quantity, Lol.Quantity)) -
                 Nvl(Lol.Affirmed_Quantity, 0)) *
                 Decode(Lol.Project_Order_Line_Id,
                        Null,
                        Nvl(Lol.List_Price, 0),
                        Nvl(Lol.Apply_List_Price, 0)) *
                 Decode(Lol.Project_Order_Line_Id,
                        Null,
                        Nvl(Lol.Discount_Rate, 0),
                               Nvl(Lol.Apply_Discount_Rate, 0)))
        Into v_Lg_No_Ship_Amount, v_Lg_No_Ship_Discount_Amount
        From t_Pln_Lg_Order_Head Loh, t_Pln_Lg_Order_Line Lol
       Where Loh.Order_Head_Id = Lol.Order_Head_Id
         And Loh.Order_Head_State In ('20', '381', '679', '1455') --已送审、部份评审、已中心评审、中心发货
         --add by lizhen 2016-06-28 增加已关闭订单行取数功能
         And Nvl(Lol.Order_Line_State, 'NORMAL') != 'CLOSED'                                                      
         And Loh.Customer_Id = p_Customer_Id
         And Loh.Account_Id = p_Account_Id
         And Loh.Entity_Id = r_Order_Type.Entity_Id
         --送审锁款、资源送审锁款不计处提货送审未发货金额
         And Nvl(Loh.Lock_Amount_Flag, r_Order_Type.Chk_Cusg_Amount_Flag) Not In ('S', 'RS');
    Exception
      When No_Data_Found Then
        v_Lg_No_Ship_Amount := 0;
        v_Lg_No_Ship_Discount_Amount := 0;
      When Others Then
        p_Result := v_Failure;
        p_Message := '获取提货订单已送审未发货金额失败！' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;

    --获取客户账户的到款余额
    v_Credit_Amount := Pkg_Credit_Tools.Fun_Get_Amount(p_Entity_Id       => r_Order_Type.Entity_Id,
                                                       p_Customer_Id     => p_Customer_Id,
                                                       p_Account_Id      => p_Account_Id,
                                                       p_Sales_Main_Type => p_Sales_Main_Type,
                                                       p_Flag            => 1);

    If p_Amount > Nvl(v_Credit_Amount, 0) - Nvl(v_Lg_No_Ship_Amount, 0) Then
      If r_Order_Type.Is_Submit_Chk_Amout = 'A' Then
        p_Result := v_Failure;
        p_Message := '检查客户到款可用金额失败:本次提货金额【' || To_Char(p_Amount) || '】' ||
          '> 到款可提货金额【' || To_Char(Nvl(v_Credit_Amount, 0)) || '】' ||
          '- 提货订单已送审未提货金额【' || To_Char(Nvl(v_Lg_No_Ship_Amount, 0)) || '】';
      Else
        p_Result := v_Success;
        p_Message := '检查客户到款可用金额:本次提货金额【' || To_Char(p_Amount) || '】' ||
          '> 到款可提货金额【' || To_Char(Nvl(v_Credit_Amount, 0)) || '】' ||
          '- 提货订单已送审未提货金额【' || To_Char(Nvl(v_Lg_No_Ship_Amount, 0)) || '】' ||
          '，到款可提货余额不足，是否继续送审订单。';
      End If;
    End If;
    --获取客户账户的到款折扣余额
    v_Credit_Discount_Amount := Pkg_Credit_Tools.Fun_Get_Amount(p_Entity_Id       => r_Order_Type.Entity_Id,
                                                                p_Customer_Id     => p_Customer_Id,
                                                                p_Account_Id      => p_Account_Id,
                                                                p_Sales_Main_Type => p_Sales_Main_Type,
                                                                p_Flag            => 2);
    If p_Discount_Amount > Nvl(v_Credit_Discount_Amount, 0) - Nvl(v_Lg_No_Ship_Discount_Amount, 0)
      And p_Discount_Amount <> 0 Then
      If r_Order_Type.Is_Submit_Chk_Amout = 'A' Then
        p_Result := v_Failure;
        p_Message := '检查客户到款可用折扣金额失败:本次提货折扣金额【' || To_Char(p_Discount_Amount) || '】' ||
          '> 到款可提货折扣金额【' || To_Char(Nvl(v_Credit_Discount_Amount, 0)) || '】' ||
          '- 提货订单已送审未提货折扣金额【' || To_Char(Nvl(v_Lg_No_Ship_Discount_Amount, 0)) || '】';
      Else
        p_Result := v_Success;
        p_Message := '检查客户到款可用折扣金额:本次提货折扣金额【' || To_Char(p_Discount_Amount) || '】' ||
          '> 到款可提货折扣金额【' || To_Char(Nvl(v_Credit_Discount_Amount, 0)) || '】' ||
          '- 提货订单已送审未提货折扣金额【' || To_Char(Nvl(v_Lg_No_Ship_Discount_Amount, 0)) || '】' ||
          '，到款可提货折扣余额不足，是否继续送审订单。';
      End If;
    End If;
  Exception
    When v_Base_Exception Then
      p_Result  := v_Failure;
      p_Message := Substrb(p_Message, 1, 2000);
    When Others Then
      p_Result  := v_Failure;
      p_Message := p_Message || v_Nl || Sqlerrm;
  End;

  ---------------------------------------------------------------------------------
  -- Author  : NICRO.LI
  -- Created : 2015-08-26 09:49:18
  -- Purpose : 提货订单发货、取消发货时锁定独资主体到款
  ---------------------------------------------------------------------------------
  Procedure p_Ims_Lg_Carry_Lock_Cash(p_Lg_Order_Head_Id In Number, --提货订单头ID
                                     p_Lg_Order_Line_Id In Number, --提货订单行ID
                                     p_Entity_Id        In Number, --主体ID
                                     p_Transaction_Qty     In Number, --当前行发货数量
                                     p_Transaction_Flag    In Number, --下达事务类型：1：下达物流发货 -1：物流取消
                                     p_Result           Out Varchar2) Is
    /*Cursor c_Lock_Amount Is
      Select Nvl(p_Transaction_Qty, 0) *
             (Imsl.Apply_List_Price *
              (1 - Nvl(Imsl.Instant_Discount_Rate, 0) / 100) -
              Nvl(Imsl.Instant_Discount_Amount, 0)) *
             (1 - Nvl(Imsl.Ordered_Discount_Rate, 0) / 100 -
              Nvl(Imsl.Discount_Rate, 0) / 100) Affirm_Amount,
             Nvl(p_Transaction_Qty, 0) *
             (Imsl.Apply_List_Price *
              (1 - Nvl(Imsl.Instant_Discount_Rate, 0) / 100) -
              Nvl(Imsl.Instant_Discount_Amount, 0)) *
             Nvl(Imsl.Discount_Rate, 0) / 100 Discount_Amount,
             Lol.Source_Line_Id,
             Imsl.Discount_Type_Id,
             Nvl(Imsl.Control_Method, '按折扣') Control_Method,
             Nvl(Imsl.Biz_Source_Type, '-1') Biz_Source_Type,
             Nvl(Imsl.Biz_Source_Number, '-1') Biz_Source_Number,
             Imsh.Finance_Entity_Id,
             Imsh.Finance_Main_Entity_Id,
             Imsh.Customer_Id,
             Imsh.Order_Number,
             Imsh.Order_Id
        From t_Pln_Lg_Order_Line Lol,
             t_Pln_Lg_Order_Head Loh,
             t_Bd_Item           Bi,
             Ims_t_Lg_Order_Head Imsh,
             Ims_t_Lg_Order_Line Imsl
       Where Lol.Item_Id = Bi.Item_Id
         And Loh.Order_Head_Id = Lol.Order_Head_Id
         And Loh.Source_Order_Id = Imsh.Order_Id
         And Loh.Sys_Source = 'IMS'
         And Lol.Source_Line_Id = Imsl.Line_Id
         And Bi.Entity_Id = Lol.Entity_Id
         And Lol.Order_Head_Id = p_Lg_Order_Head_Id
         And Lol.Order_Line_Id = p_Lg_Order_Line_Id
         And Lol.Entity_Id = p_Entity_Id;

    r_Lock_Amount       c_Lock_Amount%Rowtype;*/
    v_Ims_Order_Head_Id Number;
    v_Lock_Type         Varchar2(100);
  Begin
    p_Result := v_Success;
    /*If p_Transaction_Flag Not In (1, -1) Then
      p_Result := '提货订单下达物流发货类型错误，传入参数只允许1、-1，当前参数值:' ||
                  To_Char(p_Transaction_Flag);
      Raise v_Base_Exception;
    End If;
    Select Decode(p_Transaction_Flag, 1, '加锁', -1, '解锁', '未知')
      Into v_Lock_Type
      From Dual;
    Begin
      Open c_Lock_Amount;
    Exception
      When Others Then
        p_Result := '未找到可加锁的独资主体物流订单！' || v_Nl ||
                 '提货订单头ID：' || To_Char(p_Lg_Order_Head_Id) || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;

    Loop
      Fetch c_Lock_Amount Into r_Lock_Amount;
      If c_Lock_Amount%Rowcount = 0 Then
        p_Result := '未找到可加锁的独资主体物流订单！' || v_Nl ||
                   '提货订单头ID：' || To_Char(p_Lg_Order_Head_Id) || v_Nl ||
                   '提货订单行ID：' || To_Char(p_Lg_Order_Line_Id);
        Raise v_Base_Exception;
      End If;
      Exit When c_Lock_Amount%Notfound;
      Pkg_Io_Cims_Ims.p_Cims_Lg_Carry_Lock_Cash(p_Opt_Type               => v_Lock_Type, --操作类型：加锁，解锁
                                                p_Amount                 => p_Transaction_Qty, --传入数量
                                                p_Lock_Type              => '到款', --锁定类型  （到款、运费、折扣、铺底）
                                                p_Discount_Type_Id       => r_Lock_Amount.Discount_Type_Id, --折扣类型
                                                p_Customer_Id            => r_Lock_Amount.Customer_Id, --客户
                                                p_Finance_Main_Entity_Id => r_Lock_Amount.Finance_Main_Entity_Id, --主主体id
                                                p_Finance_Entity_Id      => r_Lock_Amount.Finance_Entity_Id, --主体id
                                                p_Source_Type            => '跨主体物流订单', --上级来源类型
                                                p_Source_Head_Id         => r_Lock_Amount.Order_Id, --上级来源头id
                                                p_Source_Head_Code       => r_Lock_Amount.Order_Number, --上级来源头编码
                                                p_Source_Line_Id         => r_Lock_Amount.Source_Line_Id, --上级来源行id
                                                p_Control_Method         => r_Lock_Amount.Control_Method, --控制方式
                                                p_Biz_Source_Type        => r_Lock_Amount.Biz_Source_Type, --业务来源类型
                                                p_Biz_Source_Number      => r_Lock_Amount.Biz_Source_Number, --来源号
                                                p_User_Id                => 1, --用户id
                                                p_Module_Name            => 'PKG_PLN_INTF_PUB', --模块名称
                                                p_Action_Name            => '提货发货锁款', --操作
                                                p_Result                 => p_Result --返回结果
                                                );

      If p_Result <> v_Success Then
        Raise v_Base_Exception;
      Else
        p_Result := v_Success;
      End If;
    End Loop;
    Close c_Lock_Amount;*/
  Exception
    When v_Base_Exception Then
      Rollback;
      p_Result := '锁定独资主体锁定客户到款失败！' || v_Nl || p_Result;
    When Others Then
      Rollback;
      p_Result := '锁定独资主体锁定客户到款失败！' || v_Nl || p_Result || v_Nl || Sqlerrm;
  End;

  ---------------------------------------------------------------------------------
  -- Author  : 何加源
  -- Created : 2015-11-20
  -- Purpose : 写操作接口表
  ---------------------------------------------------------------------------------
  PROCEDURE P_WriteBack_Opt_Intf(p_Lg_Order_Head_Id In Number, --提货订单头ID
                                 p_Lg_Order_Line_Id In Number, --提货订单行ID
                                 p_Entity_Id        In NUMBER, --主体ID
                                 p_Opt_Type         IN VARCHAR2, --操作类型
                                 p_Transaction_Qty  IN NUMBER, --数量
                                 p_Deal_Money_Cims  IN VARCHAR2, --CIMS款项处理标志
                                 p_Deal_Money_Ims   IN VARCHAR2, --IMS款项处理标志
                                 p_User_Code        IN VARCHAR2, --操作用户
                                 p_Result           Out Varchar2)
  IS
  BEGIN
    p_Result := v_Success;
    pkg_pln_intf_ims.P_WriteBack_Opt_Intf(p_Lg_Order_Head_Id => p_Lg_Order_Head_Id,
                                          p_Lg_Order_Line_Id => p_Lg_Order_Line_Id,
                                          p_Entity_Id        => p_Entity_Id,
                                          p_Opt_Type         => p_Opt_Type,
                                          p_Transaction_Qty  => p_Transaction_Qty,
                                          p_Deal_Money_Cims  => p_Deal_Money_Cims,
                                          p_Deal_Money_Ims   => p_Deal_Money_Ims,
                                          p_User_Code        => p_User_Code,
                                          p_Result           => p_Result);
    /*IF p_Opt_Type IN ('关闭', '驳回') THEN
      INSERT INTO INTF_PLN_LG_ORDER_OPT
        (ENTITY_ID,
         INTF_OPT_ID,
         OPT_TYPE,
         ORDER_HEAD_ID,
         ORDER_LINE_ID,
         SYS_SOURCE,
         SOURCE_HEAD_ID,
         SOURCE_LINE_ID,
         OPT_QUANTITY,
         DEAL_MONEY,
         DEAL_FLAG,
         CREATED_BY,
         CREATION_DATE)
      SELECT p_Entity_Id,
             S_INTF_PLN_LG_ORDER_OPT.NEXTVAL,
             p_Opt_Type,
             H.order_head_id,
             p_Lg_Order_Line_Id,
             'CIMS',
             H.ORDER_HEAD_ID,
             p_Lg_Order_Line_Id,
             p_Transaction_Qty,
             p_Deal_Money_Cims,
             DECODE(p_Deal_Money_Cims, '不处理款项', 'C', 'N'),
             p_User_Code,
             SYSDATE
        FROM T_PLN_LG_ORDER_HEAD H
       WHERE H.ORDER_HEAD_ID = p_Lg_Order_Head_Id;

      INSERT INTO IMS_IO_LG_ORDER_OPT
        (IO_OPT_ID,
         OPT_TYPE,
         ORDER_HEAD_ID,
         ORDER_LINE_ID,
         SYS_SOURCE,
         SOURCE_HEAD_ID,
         SOURCE_LINE_ID,
         OPT_QUANTITY,
         DEAL_MONEY,
         DEAL_FLAG,
         CREATED_BY,
         CREATION_DATE)
      SELECT IMS_S_IO_LG_ORDER_OPT.NEXTVAL,
             p_Opt_Type,
             H.order_head_id,
             p_Lg_Order_Line_Id,
             H.SYS_SOURCE,
             Imsh.ORDER_ID,
             -1,
             p_Transaction_Qty,
             p_Deal_Money_ims,
             'N',
             p_User_Code,
             SYSDATE
        FROM T_PLN_LG_ORDER_HEAD H,
             Ims_t_Lg_Order_Head Imsh
       WHERE H.ORDER_HEAD_ID = p_Lg_Order_Head_Id
         AND H.SYS_SOURCE = 'IMS'
         AND H.SOURCE_ORDER_ID = Imsh.Order_Id;
    ELSE
      INSERT INTO INTF_PLN_LG_ORDER_OPT
        (ENTITY_ID,
         INTF_OPT_ID,
         OPT_TYPE,
         ORDER_HEAD_ID,
         ORDER_LINE_ID,
         SYS_SOURCE,
         SOURCE_HEAD_ID,
         SOURCE_LINE_ID,
         OPT_QUANTITY,
         DEAL_MONEY,
         DEAL_FLAG,
         CREATED_BY,
         CREATION_DATE)
      SELECT p_Entity_Id,
             S_INTF_PLN_LG_ORDER_OPT.NEXTVAL,
             p_Opt_Type,
             l.order_head_id,
             l.order_line_id,
             'CIMS',
             L.ORDER_HEAD_ID,
             L.ORDER_LINE_ID,
             p_Transaction_Qty,
             p_Deal_Money_Cims,
             DECODE(p_Deal_Money_Cims, '不处理款项', 'C', 'N'),
             p_User_Code,
             SYSDATE
        FROM T_PLN_LG_ORDER_LINE L
       WHERE L.ORDER_LINE_ID = p_Lg_Order_Line_Id;

      INSERT INTO IMS_IO_LG_ORDER_OPT
        (IO_OPT_ID,
         OPT_TYPE,
         ORDER_HEAD_ID,
         ORDER_LINE_ID,
         SYS_SOURCE,
         SOURCE_HEAD_ID,
         SOURCE_LINE_ID,
         OPT_QUANTITY,
         DEAL_MONEY,
         DEAL_FLAG,
         CREATED_BY,
         CREATION_DATE)
      SELECT IMS_S_IO_LG_ORDER_OPT.NEXTVAL,
             p_Opt_Type,
             l.order_head_id,
             l.order_line_id,
             H.SYS_SOURCE,
             Imsl.ORDER_ID,
             Imsl.LINE_ID,
             p_Transaction_Qty,
             p_Deal_Money_ims,
             'N',
             p_User_Code,
             SYSDATE
        FROM T_PLN_LG_ORDER_LINE L,
             T_PLN_LG_ORDER_HEAD H,
             Ims_t_Lg_Order_Line Imsl
       WHERE L.ORDER_LINE_ID = p_Lg_Order_Line_Id
         AND H.ORDER_HEAD_ID = L.ORDER_HEAD_ID
         AND H.ORDER_HEAD_ID = p_Lg_Order_Head_Id
         AND H.SYS_SOURCE = 'IMS'
         AND L.SOURCE_LINE_ID = Imsl.Line_Id;
    END IF;
  Exception
    When v_Base_Exception Then
      Rollback;
      p_Result := '回写提货订单操作接口表失败！' || v_Nl || p_Result;
    When Others Then
      Rollback;
      p_Result := '回写提货订单操作接口表失败！' || v_Nl || p_Result || v_Nl || Sqlerrm;*/
  END;

  ---------------------------------------------------------------------------------
  -- Author  : 何加源
  -- Created : 2015-11-20
  -- Purpose : CIMS操作接口处理
  ---------------------------------------------------------------------------------
  PROCEDURE P_Opt_Intf_Deal_Job(p_Lg_Order_Head_Id IN NUMBER DEFAULT -1, --提货订单头ID
                                p_Lg_Order_Line_Id In NUMBER DEFAULT -1, --提货订单行ID
                                p_Entity_Id        In NUMBER DEFAULT -1) --主体ID
  IS
    v_Action_Type t_pln_order_type.order_lg_type%TYPE;
    v_Is_Business_Control T_PLN_ORDER_TYPE.IS_BUSINESS_CONTROL%TYPE;
    v_Count NUMBER;
    v_Result VARCHAR2(4000);
    V_OPT_ID NUMBER;
    v_OS_ATTRIB01           Varchar2(1000);
    v_OS_ATTRIB02           Varchar2(1000);
  BEGIN
    FOR R_OPT_INTF IN (SELECT O.*
                         FROM INTF_PLN_LG_ORDER_OPT O
                        WHERE O.DEAL_FLAG IN ('N', 'E')
                          AND (O.ORDER_HEAD_ID = p_Lg_Order_Head_Id OR p_Lg_Order_Head_Id = -1)
                          AND (O.ORDER_LINE_ID = p_Lg_Order_Line_Id OR p_Lg_Order_Line_Id = -1)
                          AND (O.ENTITY_ID = p_Entity_Id OR p_Entity_Id = -1)
                        ORDER BY O.ORDER_HEAD_ID, O.CREATION_DATE) LOOP
        V_OPT_ID := R_OPT_INTF.INTF_OPT_ID;
        IF R_OPT_INTF.DEAL_MONEY = '解锁款项' THEN
          SELECT T.IS_BUSINESS_CONTROL, Decode(T.ORDER_LG_TYPE, Null, 2, '01', 2, '02', 40, '03', 33, 2)
            INTO v_Is_Business_Control, v_Action_Type
            FROM T_PLN_ORDER_TYPE T, T_PLN_LG_ORDER_HEAD H
           WHERE T.ORDER_TYPE_ID = H.ORDER_TYPE_ID
             AND H.ORDER_HEAD_ID = R_OPT_INTF.ORDER_HEAD_ID;

          For r_Check_Amount In (SELECT loh.order_head_id,
                                        loh.order_number,
                                        loh.account_id,
                                        loh.customer_id,
                                        loh.order_type_id,
                                        loh.order_type_code, --20160912 hejy3 订单类型编码
                                        loh.order_type_name,
                                        Lol.Discount_Type, --add by lizhen 2017-08-08
                                        --20170517 hejy3 按行营销大类
                                        --Bi.Sales_Main_Type,
                                        nvl(lol.sales_main_type, Bi.Sales_Main_Type) Sales_Main_Type,
                                        Decode(Lol.Project_Order_Type,
                                               Null,
                                               (abs(R_OPT_INTF.OPT_QUANTITY) *
                                               Nvl(Lol.List_Price, 0) * (100 -
                                               Nvl(Lol.Discount_Rate, 0) - nvl(lol.ordered_discount_rate,0))
                                               /*(100 - nvl(lol.ordered_discount_rate,0))*/) / 100,
                                               (abs(R_OPT_INTF.OPT_QUANTITY) *
                                               Nvl(Lol.Apply_List_Price, 0) *
                                               --modi by lizhen 2015-12-17
                                               /*(100 - Nvl(Lol.Apply_Discount_Rate,0)) * */
                                               (100 -  nvl(lol.ordered_discount_rate,0))) / 100) Apply_Amount,
                                        Decode(Lol.Project_Order_Type,
                                               Null,
                                               (abs(R_OPT_INTF.OPT_QUANTITY) *
                                               Nvl(Lol.List_Price, 0) *
                                               Nvl(Lol.Discount_Rate, 0)) / 100,
                                               (abs(R_OPT_INTF.OPT_QUANTITY) *
                                               Nvl(Lol.Apply_List_Price, 0) * 0
                                               /*Nvl(Lol.Apply_Discount_Rate, 0)*/) / 100) Discount_Amount
                                   From t_Pln_Lg_Order_Line Lol, t_Bd_Item Bi, t_pln_lg_order_head loh
                                  Where Lol.Item_Id = Bi.Item_Id
                                    And Bi.Entity_Id = Lol.Entity_Id
                                    And Lol.Order_Head_Id = loh.order_head_id
                                    AND lol.order_line_id = R_OPT_INTF.ORDER_LINE_ID) Loop
            pkg_pln_pub.P_CUSTOMER_AMOUNT_PROCESS(IN_ENTITY_ID       => R_OPT_INTF.Entity_Id,
                                                  IN_ORDER_TYPE_ID   => r_Check_Amount.order_type_id,
                                                  IN_ORDER_TYPE_CODE => r_Check_Amount.order_type_code,
                                                  IN_CUSTOMER_ID     => r_Check_Amount.Customer_Id,
                                                  IN_ACCOUNT_ID      => r_Check_Amount.Account_Id,
                                                  IN_SALES_MAIN_TYPE => r_Check_Amount.Sales_Main_Type,
                                                  IN_ACTION_TYPE     => 2,
                                                  IN_SOURCE_TYPE     => '02',
                                                  IN_ORDER_ID        => r_Check_Amount.Order_Head_Id,
                                                  IN_PROJ_NUMBER     => null,
                                                  IN_DISCOUNT_TYPE   => r_Check_Amount.Discount_Type,
                                                  IN_AMOUNT          => Round(Nvl(r_Check_Amount.Apply_Amount, 0), 2),
                                                  IN_DIS_AMOUNT      => Round(Nvl(r_Check_Amount.Discount_Amount, 0), 2),
                                                  IN_RECORD_ERR      => 'N',
                                                  IN_USER_CODE       => 'admin',
                                                  OUT_RESULT         => v_Result);
            
          End Loop;
          IF v_Result <> v_Success THEN
            ROLLBACK;

            UPDATE INTF_PLN_LG_ORDER_OPT O
               SET O.ERR_MSG = v_Result,
                   O.DEAL_FLAG = 'E'
             WHERE O.INTF_OPT_ID = R_OPT_INTF.INTF_OPT_ID;
          ELSE
            UPDATE INTF_PLN_LG_ORDER_OPT O
               SET O.ERR_MSG = v_Result,
                   O.DEAL_FLAG = 'Y'
             WHERE O.INTF_OPT_ID = R_OPT_INTF.INTF_OPT_ID;
          END IF;
          COMMIT;

        END IF;
    END LOOP;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      v_Result := '解锁资金失败：' || SQLERRM;
      UPDATE INTF_PLN_LG_ORDER_OPT O
         SET O.ERR_MSG = v_Result,
             O.DEAL_FLAG = 'E'
       WHERE O.INTF_OPT_ID = V_OPT_ID;
      COMMIT;
  END;

  ---------------------------------------------------------------------------------
  -- Author  : 何加源
  -- Created : 2016-1-22
  -- Purpose : 销司可报送型谱SKU检查
  ---------------------------------------------------------------------------------
  PROCEDURE P_PLN_CHECK_SC_SKU(p_Order_Head_Id   IN NUMBER, --订单头ID
                               p_Entity_Id       In NUMBER, --主体ID
                               p_Order_Type      IN VARCHAR2, --来源单据类型：PLN:计划 LG:提货 STP:月预测
                               p_Result          Out Varchar2)
  IS
    V_MTL_CODE VARCHAR2(4000);
  BEGIN
    p_Result := v_Success;
    IF p_Order_Type = 'PLN' THEN --计划订单
      SELECT SUBSTRB(TO_CHAR(wm_concat(L.ITEM_CODE)),1,4000) INTO V_MTL_CODE
        FROM T_PLN_ORDER_LINE L, T_PLN_ORDER_HEAD H
       WHERE L.ORDER_HEAD_ID = H.ORDER_HEAD_ID
         AND H.ORDER_HEAD_ID = p_Order_Head_Id
         AND NOT EXISTS (SELECT 1 FROM T_PLN_ITEM_DYN_ATTRIBUTE A, T_PLN_ITEM_SKU S
                          WHERE A.ITEM_ID = L.ITEM_ID
                            AND A.ENTITY_ID = L.ENTITY_ID
                            AND A.ITEM_DYNAMIC_ATTRIBUTE = '定制机型'
                            AND S.Is_Submit = 'Y'
                            AND SYSDATE BETWEEN A.BEGIN_DATE AND NVL(A.END_DATE, SYSDATE)
                            AND A.ENTITY_ID = S.ENTITY_ID
                            AND A.ITEM_ID = S.ITEM_ID
                            AND S.SALES_CENTER_ID = H.SALES_CENTER_ID);
    ELSIF p_Order_Type = 'LG' THEN --提货订单
      SELECT SUBSTRB(TO_CHAR(wm_concat(L.ITEM_CODE)),1,4000) INTO V_MTL_CODE
        FROM T_PLN_LG_ORDER_LINE L, T_PLN_LG_ORDER_HEAD H
       WHERE L.ORDER_HEAD_ID = H.ORDER_HEAD_ID
         AND H.ORDER_HEAD_ID = p_Order_Head_Id
         AND NOT EXISTS (SELECT 1 FROM T_PLN_ITEM_DYN_ATTRIBUTE A, T_PLN_ITEM_SKU S
                          WHERE A.ITEM_ID = L.ITEM_ID
                            AND A.ENTITY_ID = L.ENTITY_ID
                            AND A.ITEM_DYNAMIC_ATTRIBUTE = '定制机型'
                            AND S.Is_Submit = 'Y'
                            AND SYSDATE BETWEEN A.BEGIN_DATE AND NVL(A.END_DATE, SYSDATE)
                            AND A.ENTITY_ID = S.ENTITY_ID
                            AND A.ITEM_ID = S.ITEM_ID
                            AND S.SALES_CENTER_ID = H.SALES_CENTER_ID);
    ELSIF p_Order_Type = 'STP' THEN
      SELECT SUBSTRB(TO_CHAR(wm_concat(L.ITEM_CODE)),1,4000) INTO V_MTL_CODE
        FROM T_STP_MONTH_PLAN_LINES L, T_STP_MONTH_PLAN_HEAD H
       WHERE L.MONTH_PLAN_HEAD_ID = H.MONTH_PLAN_HEAD_ID
         AND H.MONTH_PLAN_HEAD_ID = p_Order_Head_Id
         AND NOT EXISTS (SELECT 1 FROM T_PLN_ITEM_DYN_ATTRIBUTE A, T_PLN_ITEM_SKU S
                          WHERE A.ITEM_ID = L.ITEM_ID
                            AND A.ENTITY_ID = L.ENTITY_ID
                            AND A.ITEM_DYNAMIC_ATTRIBUTE = '定制机型'
                            AND S.Is_Submit = 'Y'
                            AND SYSDATE BETWEEN A.BEGIN_DATE AND NVL(A.END_DATE, SYSDATE)
                            AND A.ENTITY_ID = S.ENTITY_ID
                            AND A.ITEM_ID = S.ITEM_ID
                            AND S.SALES_CENTER_ID = H.SALES_CENTER_ID);
    END IF;

    IF V_MTL_CODE IS NOT NULL THEN
      p_Result := '下列产品:' || v_Nl || V_MTL_CODE || v_Nl ||
                  '在订单产品型谱未定义或当前中心不可报送，请重新定义订单产品型谱或中心可报送型谱(SKU)后重新送审!';
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      NULL;
  END;

  ---------------------------------------------------------------------------------
  -- Author  : 何加源
  -- Created : 2016-2-1
  -- Purpose : 销司库存占比金额检查
  ---------------------------------------------------------------------------------
  PROCEDURE P_PLN_CHK_INV_COST_PROPORTION(p_Order_Head_Id   IN NUMBER, --订单头ID
                                          p_Entity_Id       In NUMBER, --主体ID
                                          p_Order_Type      IN VARCHAR2, --来源单据类型：PLN:计划 LG:提货
                                          p_Result          Out Varchar2)
  IS
    V_SALES_CENTER_ID NUMBER; --中心ID
    V_SALES_CENTER_CODE VARCHAR2(100); --中心编码
    V_COST_PROPORTION_SCALE NUMBER; --库存占比比例
    V_ORDER_AMOUNT NUMBER := 0; --当前单据金额
    V_ORDER_QTY NUMBER := 0; --当前单据数量 --hejy3 20170310
    V_SC_AMOUNT NUMBER := 0; --销司库存金额
    V_SC_QTY NUMBER := 0; --销司库存数量 --hejy3 20170310
    V_NOT_SUPPLY_AMOUNT NUMBER := 0; --销司未下线订单金额
    V_NOT_SUPPLY_QTY NUMBER := 0; --销司未下线订单数量 --hejy3 20170310
    V_NOT_CARRY_AMOUNT NUMBER := 0; --销司下线未提订单金额
    V_NOT_CARRY_QTY NUMBER := 0; --销司下线未提订单数量 --hejy3 20170310
    V_NOT_SO_AMOUNT NUMBER := 0; --销司下达物流未发货订单金额
    V_NOT_SO_QTY NUMBER := 0; --销司下达物流未发货订单数量 --hejy3 20170310
    V_SO_AMOUNT_TODAY NUMBER := 0; --总部对销司当前销售金额
    V_SO_QTY_TODAY NUMBER := 0; --总部对销司当前销售数量 --hejy3 20170310
    V_CURR_DATE DATE; --单据日期
    V_YEAR_ID NUMBER; --计划年度ID
    V_YEAR_CODE T_PLN_ORDER_PERIOD.PERIOD_CODE%TYPE;
    V_TASK_AMOUNT NUMBER; --销司年度销售任务金额
    V_TASK_QTY NUMBER; --销司年度销售任务数量 --hejy3 20170310
    V_EXPRESSION VARCHAR2(100); --库存金额计算公式
    V_CALIBER VARCHAR2(100); --统计口径
    V_TOTAL_INV_AMOUNT NUMBER; --总库存金额
    V_TOTAL_INV_QTY NUMBER; --总库存数量 --hejy3 20170310
    V_AMOUNT_TIP VARCHAR2(1000); --提示信息
    V_QTY_TIP VARCHAR2(1000); --数量提示信息 --hejy3 20170310
    V_OVER_AMOUNT NUMBER; --超出金额
    V_OVER_QTY NUMBER; --超出数量 --hejy3 20170310
    V_REMAIN_AMOUNT NUMBER; --剩余金额
    V_REMAIN_QTY NUMBER; --剩余数量 --hejy3 20170310
    V_TAX_RATE NUMBER; --20180409 hejy3 默认税率
  BEGIN
    p_Result := v_Success;
    
    --获取默认税率
    BEGIN
      V_TAX_RATE := TO_NUMBER(PKG_BD.F_GET_PARAMETER_VALUE('AR_VAT_RATE', p_Entity_Id));
    EXCEPTION
      WHEN OTHERS THEN
        p_Result := '获取系统默认税率失败！' || v_Nl ||
                    '请检查系统参数配置，系统参数编码【AR_VAT_RATE】' || v_Nl ||
                    '系统提示：' || sqlerrm || v_Nl ||
                    dbms_utility.format_error_backtrace;
        RETURN;
    END;
    
    IF V_TAX_RATE IS NULL THEN
      p_Result := '默认税率为空！' || v_Nl ||
                  '请检查系统参数配置，系统参数编码【AR_VAT_RATE】';
      RETURN;
    END IF;
    
    --获取中心ID，库存占比比例
    IF p_Order_Type = 'PLN' THEN
      SELECT H.SALES_CENTER_ID,
             H.SALES_CENTER_CODE,
             NVL(T.COST_PROPORTION_SCALE, 0),
             P.BEGIN_DATE,
             SUM(L.AMOUNT), --当前单据金额 F
             SUM(L.APPLY_QTY) --当前单据数量 F --hejy3 20170310
        INTO V_SALES_CENTER_ID,
             V_SALES_CENTER_CODE,
             V_COST_PROPORTION_SCALE,
             V_CURR_DATE,
             V_ORDER_AMOUNT,
             V_ORDER_QTY
        FROM T_PLN_ORDER_HEAD   H,
             T_PLN_ORDER_TYPE   T,
             T_PLN_ORDER_LINE   L,
             T_PLN_ORDER_PERIOD P
       WHERE H.ORDER_TYPE_ID = T.ORDER_TYPE_ID
         AND H.ORDER_HEAD_ID = L.ORDER_HEAD_ID
         AND H.ORDER_HEAD_ID = P_ORDER_HEAD_ID
         AND H.PERIOD_ID = P.PERIOD_ID
       GROUP BY H.SALES_CENTER_ID,
                H.SALES_CENTER_CODE,
                NVL(T.COST_PROPORTION_SCALE, 0),
                P.BEGIN_DATE;
    ELSE
      SELECT H.SALES_CENTER_ID,
             H.SALES_CENTER_CODE,
             NVL(T.COST_PROPORTION_SCALE, 0),
             TRUNC(SYSDATE),
             SUM(L.APPLY_AMOUNT), --当前单据金额 F
             SUM(L.QUANTITY) --当前单据数量 F --hejy3 20170310
        INTO V_SALES_CENTER_ID,
             V_SALES_CENTER_CODE,
             V_COST_PROPORTION_SCALE,
             V_CURR_DATE,
             V_ORDER_AMOUNT,
             V_ORDER_QTY
        FROM T_PLN_LG_ORDER_HEAD H,
             T_PLN_ORDER_TYPE    T,
             T_PLN_LG_ORDER_LINE L
       WHERE H.ORDER_TYPE_ID = T.ORDER_TYPE_ID
         AND H.ORDER_HEAD_ID = L.ORDER_HEAD_ID
         AND H.ORDER_HEAD_ID = P_ORDER_HEAD_ID
       GROUP BY H.SALES_CENTER_ID,
                H.SALES_CENTER_CODE,
                NVL(T.COST_PROPORTION_SCALE, 0);
    END IF;

    --获取当前年度
    BEGIN
      SELECT P.PERIOD_ID, P.PERIOD_CODE
        INTO V_YEAR_ID, V_YEAR_CODE
        FROM T_PLN_ORDER_PERIOD P
       WHERE P.ENTITY_ID = p_Entity_Id
         AND P.PERIOD_TYPE = '年'
         AND V_CURR_DATE BETWEEN P.BEGIN_DATE AND P.END_DATE;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        p_Result := '未维护当前单据日期【' || TO_CHAR(V_CURR_DATE, 'YYYY-MM-DD') || '】对应的计划年度' || v_Nl ||
                    '请通过【订单管理-订单基础数据维护-订单周期管理】菜单维护';
        RETURN;
      WHEN TOO_MANY_ROWS THEN
        p_Result := '当前单据日期【' || TO_CHAR(V_CURR_DATE, 'YYYY-MM-DD') || '】对应的计划年度重复' || v_Nl ||
                    '请检查【订单管理-订单基础数据维护-订单周期管理】菜单设置';
        RETURN;
    END;

    --获取库存金额计算公式
    --A+B+C+D+E+F
    --A+E+F
    BEGIN
      SELECT NVL(E.CODE_VALUE, NVL(C.CODE_VALUE, 'A+B+C+D+E+F')),
             NVL(E.ENTITY_CODE_NAME, NVL(C.CODE_NAME, 'AMOUNT'))
        INTO V_EXPRESSION, V_CALIBER
        FROM UP_CODELIST C, UP_CODELIST_ENTITY E
       WHERE C.ID = E.CODELIST_ID--(+)
         AND E.ENTITY_ID/*(+)*/ = p_Entity_Id
         AND C.CODETYPE = 'PLN_COST_PROPORTION_EXPRESSION';
    EXCEPTION
      WHEN OTHERS THEN
        V_EXPRESSION := 'A+B+C+D+E+F';
    END;

    IF INSTRB(V_EXPRESSION, 'A') > 0 THEN
      --获取销售公司期末库存金额 A
      --20180409 hejy3 使用系统配置的税率
      SELECT NVL(SUM(NVL(D.FINAL_QTY, 0) * NVL(D.LIST_PRICE, 0) * (1 + V_TAX_RATE / 100)), 0),
             NVL(SUM(NVL(D.FINAL_QTY, 0)), 0)
        INTO V_SC_AMOUNT,
             V_SC_QTY
        FROM T_PLN_SC_INV_DETAIL D
       WHERE D.ENTITY_ID = P_ENTITY_ID
         AND D.SALES_CENTER_ID = V_SALES_CENTER_ID;

      V_AMOUNT_TIP := '销售公司正品库存金额：' || TO_CHAR(V_SC_AMOUNT) || v_Nl;
      V_QTY_TIP := '销售公司正品库存数量：' || TO_CHAR(V_SC_QTY) || v_Nl;
    END IF;

    IF INSTRB(V_EXPRESSION, 'B') > 0 THEN
      --获取销售公司未下线订单金额(排产-工厂取消-已入库) B
      SELECT NVL(SUM((NVL(L.CAN_PRODUCE_QTY, 0) - NVL(R.ADJUST_QTY, 0) -
                 NVL(OD.SUPPLY_QTY, 0)) * L.ITEM_PRICE
                 * (100 - NVL(L.DISCOUNT_RATE, 0) - NVL(L.ORDERED_DISCOUNT_RATE, 0)) / 100), 0),
             NVL(SUM(NVL(L.CAN_PRODUCE_QTY, 0) - NVL(R.ADJUST_QTY, 0) - NVL(OD.SUPPLY_QTY, 0)), 0)
        INTO V_NOT_SUPPLY_AMOUNT,
             V_NOT_SUPPLY_QTY
        FROM T_PLN_ORDER_HEAD          H,
             T_PLN_ORDER_LINE          L,
             V_PLN_FULLY_FOLLOW_REPORT R,
             T_PLN_ORDER_PERIOD P,
             (SELECT D.ORDER_LINE_ID, MIN(NVL(D.SUPPLY_QTY, 0)) SUPPLY_QTY
                FROM CIMS.T_PLN_ORDER_DETAIL D
               WHERE NVL(D.REMARK, '_') <> 'PLM引入的配套关系错误，生成了错误的明细行，后台取消错误明细行'
                 AND D.ORDER_LINE_ID <> 257754
               GROUP BY D.ORDER_LINE_ID) OD
       WHERE H.ORDER_HEAD_ID = L.ORDER_HEAD_ID
         AND L.ORDER_LINE_ID = OD.ORDER_LINE_ID(+)
         AND L.ORDER_LINE_ID = R.ORDER_LINE_ID(+)
         --AND H.FORM_STATE NOT IN ('248','19','303','304','305','415') --排除已作废、制单、已退回、已关闭、已取消、已驳回
         AND H.FORM_STATE IN (32, 306) --只取已排产、已完成状态单据
         AND H.PERIOD_ID = P.PERIOD_ID
         AND P.PERIOD_TYPE IN ('周', 'T+3周期')
         AND NVL(L.CAN_PRODUCE_QTY, 0) - NVL(R.ADJUST_QTY, 0) - NVL(OD.SUPPLY_QTY, 0) > 0
         AND H.ENTITY_ID = P_ENTITY_ID
         AND H.SALES_CENTER_ID = V_SALES_CENTER_ID;

      V_AMOUNT_TIP := V_AMOUNT_TIP || '未下线订单金额：' || TO_CHAR(V_NOT_SUPPLY_AMOUNT) || v_Nl;
      V_QTY_TIP := V_QTY_TIP || '未下线订单数量：' || TO_CHAR(V_NOT_SUPPLY_QTY) || v_Nl;
    END IF;

    IF INSTRB(V_EXPRESSION, 'C') > 0 THEN
      --获取销售公司下线未提订单金额(已分配-已下达) C
      SELECT NVL(SUM((NVL(S.SHARE_QTY, 0) - NVL(S.CARRY_QTY, 0)) * NVL(L.ITEM_PRICE, 0)
                     * (100 - NVL(L.DISCOUNT_RATE, 0) - NVL(L.ORDERED_DISCOUNT_RATE, 0)) / 100), 0),
             NVL(SUM((NVL(S.SHARE_QTY, 0) - NVL(S.CARRY_QTY, 0))), 0)
        INTO V_NOT_CARRY_AMOUNT,
             V_NOT_CARRY_QTY
        FROM T_PLN_ORDER_SHARE_SHIPMENT S, T_PLN_ORDER_LINE L, T_PLN_ORDER_HEAD H
       WHERE S.ORIGIN_LINE_ID = L.ORDER_LINE_ID
         AND S.ORIGIN_HEAD_CODE = H.ORDER_NUMBER
         AND L.ORDER_HEAD_ID = H.ORDER_HEAD_ID
         AND NVL(S.SHARE_QTY, 0) - NVL(S.CARRY_QTY, 0) > 0
         AND S.ENTITY_ID = P_ENTITY_ID
         AND H.SALES_CENTER_ID = V_SALES_CENTER_ID;

      V_AMOUNT_TIP := V_AMOUNT_TIP || '下线未提订单金额：' || TO_CHAR(V_NOT_CARRY_AMOUNT) || v_Nl;
      V_QTY_TIP := V_QTY_TIP || '下线未提订单数量：' || TO_CHAR(V_NOT_CARRY_QTY) || v_Nl;
    END IF;

    IF INSTRB(V_EXPRESSION, 'D') > 0 THEN
      --获取销售公司提货订单下达物流未发货订单金额--分配承运商 D
      SELECT NVL(SUM(NVL(P.UNAFFIRM_QTY, 0) * NVL(P.ITEM_PRICE, 0)
                     * (100 - NVL(P.DISCOUNT_RATE, 0) - NVL(P.MONTH_DISCOUNT_RATE, 0)) / 100), 0),
             NVL(SUM(NVL(P.UNAFFIRM_QTY, 0)), 0)
        INTO V_NOT_SO_AMOUNT,
             V_NOT_SO_QTY
        FROM T_LG_SHIP_PLAN P
       WHERE P.ENTITY_ID = p_Entity_Id
         AND P.SALES_CENTER_ID = V_SALES_CENTER_ID
         AND P.STATUS = '00' --未分配
         AND NVL(P.UNAFFIRM_QTY, 0) > 0
         --AND P.ORIGIN_TYPE = '02'
         ; --来源提货订单

      --获取销售公司提货订单下达物流未发货订单金额--发货通知单未发货 D
      SELECT V_NOT_SO_AMOUNT + NVL(SUM((NVL(L.ITEM_QTY, 0) - NVL(L.CANCEL_QTY, 0) -
                     NVL(L.FACT_SHIP_QTY, 0)) * NVL(L.ITEM_PRICE, 0)
                     * (100 - NVL(L.DISCOUNT_RATE, 0) - NVL(L.MONTH_DISCOUNT_RATE, 0)) / 100), 0),
             V_NOT_SO_QTY + NVL(SUM((NVL(L.ITEM_QTY, 0) - NVL(L.CANCEL_QTY, 0) - NVL(L.FACT_SHIP_QTY, 0))), 0)
        INTO V_NOT_SO_AMOUNT,
             V_NOT_SO_QTY
        FROM T_LG_SHIP_DOC D, T_LG_SHIP_DOC_LINE L
       WHERE D.SHIP_DOC_ID = L.SHIP_DOC_ID
         AND D.ENTITY_ID = P_ENTITY_ID
         AND D.SALES_CENTER_ID = V_SALES_CENTER_ID
         AND D.DOC_STATUS = '00' --正常非红冲
         AND NVL(L.ITEM_QTY, 0) - NVL(L.CANCEL_QTY, 0) - NVL(L.FACT_SHIP_QTY, 0) > 0
         --AND L.ORIGIN_TYPE = '02'
         ; --来源提货订单

      V_AMOUNT_TIP := V_AMOUNT_TIP || '已下达物流未发货金额：' || TO_CHAR(V_NOT_SO_AMOUNT) || v_Nl;
      V_QTY_TIP := V_QTY_TIP || '已下达物流未发货数量：' || TO_CHAR(V_NOT_SO_QTY) || v_Nl;
    END IF;

    IF INSTRB(V_EXPRESSION, 'E') > 0 THEN
      --获取当天总部对销售公司的销售数量 E
      SELECT NVL(SUM(DECODE(H.BIZ_SRC_BILL_TYPE_CODE, '1001', 1, '1004', 1, -1) *
             NVL(L.ITEM_QTY, 0) * NVL(L.ITEM_PRICE, 0)
             * (100 - NVL(L.DISCOUNT_RATE, 0) - NVL(L.MONTH_DISCOUNT_RATE, 0)) / 100), 0),
             NVL(SUM(DECODE(H.BIZ_SRC_BILL_TYPE_CODE, '1001', 1, '1004', 1, -1) * NVL(L.ITEM_QTY, 0)), 0)
        INTO V_SO_AMOUNT_TODAY,
             V_SO_QTY_TODAY
        FROM T_SO_HEADER H, T_SO_LINE L
       WHERE H.SO_HEADER_ID = L.SO_HEADER_ID
         --AND H.ORIG_SO_NUM IS NULL --蓝单
         AND H.SO_DATE = TRUNC(SYSDATE)
         AND H.ENTITY_ID = P_ENTITY_ID
         AND H.SALES_CENTER_ID = V_SALES_CENTER_ID
         AND H.BIZ_SRC_BILL_TYPE_CODE IN ('1001', '1002', '1003', '1004');

      V_AMOUNT_TIP := V_AMOUNT_TIP || '总部对销司当天销售金额：' || TO_CHAR(V_SO_AMOUNT_TODAY) || v_Nl;
      V_QTY_TIP := V_QTY_TIP || '总部对销司当天销售数量：' || TO_CHAR(V_SO_QTY_TODAY) || v_Nl;
    END IF;

    V_AMOUNT_TIP := V_AMOUNT_TIP || '当前提交订单金额：' || TO_CHAR(V_ORDER_AMOUNT) || v_Nl;
    V_QTY_TIP := V_QTY_TIP || '当前提交订单数量：' || TO_CHAR(V_ORDER_QTY) || v_Nl;

    --获取销司本年销售任务 G
    BEGIN
      SELECT DECODE(NVL(SUM(L.YEAR_TASK_AMOUNT), 0), 0, NULL, SUM(L.YEAR_TASK_AMOUNT)),
             DECODE(NVL(SUM(L.YEAR_TASK_QTY), 0), 0, NULL, SUM(L.YEAR_TASK_QTY))
        INTO V_TASK_AMOUNT,
             V_TASK_QTY
        FROM T_STP_YEAR_SALES_TASK_HEAD H, T_STP_YEAR_SALES_TASK_LINES L
       WHERE H.YEAR_SALES_TASK_HEAD_ID = L.YEAR_SALES_TASK_HEAD_ID
         AND H.TASK_PERIOD = TO_CHAR(V_YEAR_ID)
         AND H.ENTITY_ID = p_Entity_Id
         AND L.SALES_CENTER_CODE = V_SALES_CENTER_CODE
         AND H.TASK_STATUS = '04' --已提交
         AND H.VER_SEQUENCE = (SELECT MAX(TH.VER_SEQUENCE) FROM T_STP_YEAR_SALES_TASK_HEAD TH
                                WHERE TH.ENTITY_ID = H.ENTITY_ID
                                  AND TH.TASK_PERIOD = H.TASK_PERIOD
                                  AND TH.TASK_NAME = H.TASK_NAME
                                  AND TH.TASK_STATUS = '04');

      IF (V_CALIBER = 'AMOUNT' AND V_TASK_AMOUNT IS NULL)
        OR (V_CALIBER = 'QUANTITY' AND V_TASK_QTY IS NULL) THEN
        RAISE v_Base_Exception;
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        p_Result := '未维护当前中心【' || V_SALES_CENTER_CODE || '】计划年度' || '【' || V_YEAR_CODE || '】的销售任务';
        RAISE v_Base_Exception;
    END;

    --计算库存占比
    IF V_CALIBER = 'AMOUNT' THEN
    V_TOTAL_INV_AMOUNT := V_SC_AMOUNT + V_NOT_SUPPLY_AMOUNT + V_NOT_CARRY_AMOUNT + V_NOT_SO_AMOUNT
                        + V_SO_AMOUNT_TODAY + V_ORDER_AMOUNT;
    IF V_TOTAL_INV_AMOUNT / NVL(V_TASK_AMOUNT, V_TOTAL_INV_AMOUNT) * 100 > V_COST_PROPORTION_SCALE THEN
      V_OVER_AMOUNT := V_TOTAL_INV_AMOUNT - NVL(V_TASK_AMOUNT, V_TOTAL_INV_AMOUNT) * V_COST_PROPORTION_SCALE / 100;
      V_REMAIN_AMOUNT := (V_TASK_AMOUNT * V_COST_PROPORTION_SCALE / 100) -
                      (V_SC_AMOUNT + V_NOT_SUPPLY_AMOUNT + V_NOT_CARRY_AMOUNT + V_NOT_SO_AMOUNT + V_SO_AMOUNT_TODAY);
      p_Result := '库存占比超过'||TO_CHAR(V_COST_PROPORTION_SCALE)||'%，不可提交订单，'||
                  '超出金额'||TO_CHAR(V_OVER_AMOUNT)||'，可报送金额'||TO_CHAR(V_REMAIN_AMOUNT)||'！'||v_Nl||
                  V_AMOUNT_TIP;
      RETURN;
    END IF;
    ELSIF V_CALIBER = 'QUANTITY' THEN
      V_TOTAL_INV_QTY := V_SC_QTY + V_NOT_SUPPLY_QTY + V_NOT_CARRY_QTY + V_NOT_SO_QTY
                          + V_SO_QTY_TODAY + V_ORDER_QTY;
      IF V_TOTAL_INV_QTY / NVL(V_TASK_QTY, V_TOTAL_INV_QTY) * 100 > V_COST_PROPORTION_SCALE THEN
        V_OVER_QTY := V_TOTAL_INV_QTY - TRUNC(NVL(V_TASK_QTY, V_TOTAL_INV_QTY) * V_COST_PROPORTION_SCALE / 100);
        V_REMAIN_QTY := TRUNC(V_TASK_QTY * V_COST_PROPORTION_SCALE / 100) -
                        (V_SC_QTY + V_NOT_SUPPLY_QTY + V_NOT_CARRY_QTY + V_NOT_SO_QTY + V_SO_QTY_TODAY);
        p_Result := '库存占比超过'||TO_CHAR(V_COST_PROPORTION_SCALE)||'%，不可提交订单，'||
                    '超出数量'||TO_CHAR(V_OVER_QTY)||'，可报送数量'||TO_CHAR(V_REMAIN_QTY)||'！'||v_Nl||
                    V_QTY_TIP;
        RETURN;
      END IF;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      NULL;
  END;
  
  -----------------------------------------------------------------------------
  -- AUTHOR  : Nicro.Li
  -- CREATED : 2016-04-09
  -- PURPOSE : 根据提货汇总头ID获取各汇总参数字段在汇总头表对应的值
  -----------------------------------------------------------------------------
  Function f_Get_T3para_Collect_Value(p_Entity_Id          In Number,
                                      p_Lg_Collect_Head_Id In Number, --提货订单汇总头ID
                                      p_Param_Code         In Varchar2 --参数字段编码
                                      ) Return Varchar2 Is
    v_Sql    Varchar2(2000);
    v_Index  Number := 1;
    v_Result Varchar2(1000);
  Begin
    For r_Para In (Select Ep.*
                     From t_Pln_Entity_Para Ep
                    Where Ep.Entity_Id = p_Entity_Id--13
                      And Ep.Para_Code Not In
                          ('PRODUCING_AREA_NAME',
                           'PRODUCING_AREA_CODE',
                           'PRODUCING_AREA_ID')
                    Order By Ep.Para_Sort) Loop
      If Instr(Upper(r_Para.Para_Code), Upper(p_Param_Code)) > 0 Then
        Exit;
      End If;
      v_Index := v_Index + 1;
    End Loop;
    v_Sql := ' Select lch.pre_field_' || Trim(To_Char(v_Index, '00')) ||
             ' From t_pln_lg_collect_head lch Where lch.collect_head_id = :1';
    Execute Immediate v_Sql
      Into v_Result
      Using p_Lg_Collect_Head_Id;
    Return v_Result;
  Exception When Others Then
      Return Null;
  End;

	-----------------------------------------------------------------------------
  -- AUTHOR  : Nicro.Li
  -- CREATED : 2017-10-31
  -- PURPOSE : 根据提货预约汇总头ID获取各新汇总参数字段在汇总头表对应的值
  -----------------------------------------------------------------------------
  Function f_Get_RcOrdPara_Collect_Value(In_Entity_Id          In Number,
                                         In_Head_Id            In Number, --提货订单汇总头ID
                                         In_Table_Alias        In Varchar2, --表别名
                                         In_Column_Code        In Varchar2 --字段编码
                                         ) Return Varchar2 Is
    v_Sql    Varchar2(2000);
    v_Index  Number := 1;
    v_Result Varchar2(1000);
  Begin
    For r_Para In (Select Ocp.*
                     From t_Pln_Ord_Collect_Param Ocp
                    Where Ocp.Entity_Id = In_Entity_Id --13
                      And Ocp.Param_Type = 'RC_COLLECT_TYPE'
                    Order By Ocp.Seq_Num) Loop
      If Upper(r_Para.Table_Alias) = Upper(In_Table_Alias) And
        Upper(r_Para.Column_Code) = Upper(In_Column_Code) Then
        Exit;
      End If;
      v_Index := v_Index + 1;
    End Loop;
    v_Sql := ' Select Rch.pre_field_' || Trim(To_Char(v_Index, '00')) ||
             ' From t_pln_Reservation_Coll_head rch Where rch.Reservation_head_id = :1';
    Execute Immediate v_Sql
      Into v_Result
      Using In_Head_Id;
    Return v_Result;
  Exception When Others Then
      Return Null;
  End;
    
  -----------------------------------------------------------------------------
  -- AUTHOR  : Nicro.Li
  -- CREATED : 2016-04-09
  -- PURPOSE : 根据主体获取提货订单当前周期期间开始日期与结束日期
  -----------------------------------------------------------------------------
  Procedure p_Get_CurrentPeriodDate(p_Entity_Id                 In Number, --主体ID
                                    IN_CAL_DATE   in date DEFAULT SYSDATE ,--默认日期                              
                                    p_Current_Period_Begin_Date Out Date, --开始日期
                                    p_Current_Period_End_Date Out Date   --结束日期
                                    ) Is    
    v_Current_Period_Begin_Day  Varchar2(32);
    v_Current_Period_End_Day    Varchar2(32);
    v_Current_Period_Begin_Date Date;
    v_Current_Period_End_Date   Date;   
    v_Pln_Of_Time_Month  Number;                           
  Begin
    --add by lizhen 2016-05-20
    --APS产能可视统计提货订单数据周期提前月数
    Begin
      v_Pln_Of_Time_Month := Pkg_Bd.f_Get_Parameter_Value('PLN_CAPACITY_AHEAD_OF_TIME_MONTH',
                                                                          p_Entity_Id);
    Exception
      When Others Then
        v_Pln_Of_Time_Month := 0;
    End;
    
    Begin
      Select Uc.Code_Value, Uc.Code_Name
        Into v_Current_Period_Begin_Day, v_Current_Period_End_Day
        From Up_Codelist Uc, Up_Codelist_Entity Uce
       Where Uc.Id = Uce.Codelist_Id
         And Uc.Codetype = 'plnLgOrderCurrentPeriodDay'
         And Uce.Entity_Id = p_Entity_Id
         And Uce.Enabled = 0
         And Uc.Enabled = 0;
    Exception
      When Others Then
        Null;
    End;
    If To_Number(To_Char(IN_CAL_DATE, 'DD')) >= To_Number(v_Current_Period_Begin_Day) Then
      Select To_Date(To_Char(IN_CAL_DATE, 'yyyy-mm') || '-' ||
                     v_Current_Period_Begin_Day,
                     'yyyy-mm-dd')
        Into v_Current_Period_Begin_Date
        From Dual;
    Else
      Select To_Date(To_Char(Add_Months(IN_CAL_DATE, -1), 'YYYY-MM') || '-' ||
                     v_Current_Period_Begin_Day,
                     'yyyy-mm-dd')
        Into v_Current_Period_Begin_Date
        From Dual;
    End If;
    If To_Number(To_Char(IN_CAL_DATE, 'DD')) > To_Number(v_Current_Period_End_Day) Then
      --add by lizhen 2017-09-06日期范围不当1~31日时（当前自然月），无31日的月份取当月最大日期
      If To_Number(To_Char(Last_Day(IN_CAL_DATE), 'DD')) = To_Number(v_Current_Period_End_Day) Then
        v_Current_Period_End_Date := Trunc(Last_Day(IN_CAL_DATE));
      Else
        Select To_Date(To_Char(Add_Months(IN_CAL_DATE, 1), 'YYYY-MM') || '-' ||
                       v_Current_Period_End_Day,
                       'yyyy-mm-dd')
          Into v_Current_Period_End_Date
          From Dual;
      End If;
    Else
      --add by lizhen 2017-09-06日期范围不当1~31日时（当前自然月），无31日的月份取当月最大日期
      If To_Number(To_Char(Last_Day(IN_CAL_DATE), 'DD')) < To_Number(v_Current_Period_End_Day) Then
        v_Current_Period_End_Date := Trunc(Last_Day(IN_CAL_DATE));
      Else
        Select To_Date(To_Char(IN_CAL_DATE, 'yyyy-mm') || '-' ||
                       v_Current_Period_End_Day,
                       'yyyy-mm-dd')
          Into v_Current_Period_End_Date
          From Dual;
      End If;
    End If;
    p_Current_Period_Begin_Date := Add_Months(v_current_Period_Begin_Date, -1*v_Pln_Of_Time_Month);
    p_Current_Period_End_Date := v_Current_Period_End_Date;
  Exception
    When Others Then
      p_Current_Period_Begin_Date := Null;
      p_Current_Period_End_Date := Null;
  End;
  
  -----------------------------------------------------------------------------
  -- AUTHOR  : Nicro.Li
  -- CREATED : 2016-04-05
  -- PURPOSE : 根据产品、单据送审类型获取产品的库存可用量（符合条件仓库的汇总）
  -----------------------------------------------------------------------------
  Function f_Get_Lgorder_Noship_Qty(p_Entity_Id         In Number, ----主体ID
                                    p_Item_Id           In Number, --产品ID
                                    p_Order_Submit_Type In Varchar2, --单据送审类型
                                    p_User_Code         In Varchar2, --用户编码
                                    IN_MRP_ORG_ID       IN NUMBER DEFAULT -1,--组织 ID
                                    IN_ITEM_CODE        IN VARCHAR2 DEFAULT '_'--产品编码
                                    ) Return Number Is
    v_Current_Period_Begin_Date Date;
    v_Current_Period_End_Date   Date;
    v_Lgorder_NoShip_Qty        Number;
    V_CAPACITY_MODEL            Varchar2(50);
    V_ENTITY_ID NUMBER;
  BEGIN
    IF p_Entity_Id = -1 THEN
  Begin
        SELECT O.ENTITY_ID
          INTO V_ENTITY_ID
          FROM T_INV_ORGANIZATION O
         WHERE O.ORGANIZATION_ID = IN_MRP_ORG_ID
           AND ROWNUM = 1;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          V_ENTITY_ID := p_Entity_Id;
      END;
    ELSE
      V_ENTITY_ID := p_Entity_Id;
    END IF;
    
    --获取主体产能可视模式
    BEGIN
      V_CAPACITY_MODEL := PKG_BD.F_GET_PARAMETER_VALUE('PLN_CAPACITY_MODEL',
                                                       /*P_ENTITY_ID*/V_ENTITY_ID);
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;
	  p_Get_CurrentPeriodDate(p_Entity_Id                 => /*p_Entity_Id*/V_ENTITY_ID, --主体ID
                            IN_CAL_DATE => trunc(sysdate),
                            p_Current_Period_Begin_Date => v_Current_Period_Begin_Date, --开始日期
                            p_Current_Period_End_Date   => v_Current_Period_End_Date   --结束日期
                            );
    
    if nvl(V_CAPACITY_MODEL,'APS') = 'APS-CIMS' then
      --若产能可视参数值为APS-CIMS，按照组织ID、产品编码获取未评审量
      Select Nvl(Sum(Case
                       When Loh.Order_Head_State In ('20', '2225') Then
                        Nvl(Lol.Quantity, 0)
                       When Loh.Order_Head_State = '1455' Then
                        Nvl(Lol.Quantity, 0) - Nvl(Lol.Affirmed_Quantity, 0)
                       When Loh.Order_Head_State In ('679', '381') Then
                        Nvl(Lol.Center_Affirm_Quantity, 0) -
                        Nvl(Lol.Hq_Affirmed_Qty, 0) -
                        Nvl(Lol.Center_Affirmed_Qty, 0) - Nvl(Lol.To_Pln_Qty, 0)
                       Else
                        0
                     End),
                 0)
        Into v_Lgorder_Noship_Qty
        From Cims.t_Pln_Lg_Order_Head  Loh,
             Cims.t_Pln_Lg_Order_Line  Lol,
             Cims.t_Pln_Order_Type     Pot,
             cims.t_pln_producing_area pa
       Where Loh.Order_Head_Id = Lol.Order_Head_Id
         And Loh.Order_Head_State In ('20', '1455', '679', '381', '2225')
         And Nvl(Lol.Order_Line_State, 'NORMAL') != 'CLOSED' --未关闭
         And Nvl(Loh.Aps_Capacity_State, 'N') != 'Q' --非排队订单
         AND UPPER(NVL(Pot.IS_BUSINESS_CONTROL, '_')) NOT IN
             ('PRO_ORDER', 'SC_LG_ORDER')
         And Lol.Item_Code = IN_ITEM_CODE
         And Pot.Order_Type_Id = Loh.Order_Type_Id
         And POT.Is_Pln_Capacity = 'Y'--(nvl(Pot.Lg_Order_Submit_Type, '_') = nvl(p_Order_Submit_Type, '_') OR )
         AND lol.producing_area_id = pa.producing_area_id--(+)
         AND pa.mrp_org_id = IN_MRP_ORG_ID
         --AND (pa.mrp_org_id(+) = IN_MRP_ORG_ID OR IN_MRP_ORG_ID = -1)
         And Loh.Order_Date Between v_Current_Period_Begin_Date AND
             v_Current_Period_End_Date;
    else
      Select Nvl(Sum(Case
                       When Loh.Order_Head_State In ('20', '2225') Then
                        Nvl(Lol.Quantity, 0)
                       When Loh.Order_Head_State = '1455' Then
                        Nvl(Lol.Quantity, 0) - Nvl(Lol.Affirmed_Quantity, 0)
                       When Loh.Order_Head_State In ('679', '381') Then
                        Nvl(Lol.Center_Affirm_Quantity, 0) - Nvl(Lol.Hq_Affirmed_Qty, 0) -
                        Nvl(Lol.Center_Affirmed_Qty, 0) - Nvl(Lol.To_Pln_Qty, 0)
                       Else
                        0
                     End),
                 0)
        Into v_Lgorder_Noship_Qty
        From Cims.t_Pln_Lg_Order_Head Loh,
             Cims.t_Pln_Lg_Order_Line Lol,
             Cims.t_Pln_Order_Type    Pot
       Where Loh.Order_Head_Id = Lol.Order_Head_Id
         And Loh.Order_Head_State In ('20', '1455', '679', '381', '2225')
         --add by lizhen 2016-06-28 已关闭订单行不讲发货信息
         And Nvl(Lol.Order_Line_State, 'NORMAL') != 'CLOSED'
         And Nvl(Loh.Aps_Capacity_State, 'N') != 'Q'  --add by lizhen 2016-07-27排队不计算
         And Loh.Entity_Id = /*p_Entity_Id*/V_ENTITY_ID
         And Lol.Item_Id = p_Item_Id
         And Pot.Order_Type_Id = Loh.Order_Type_Id
         And Pot.Lg_Order_Submit_Type = p_Order_Submit_Type
         And Loh.Order_Date Between v_Current_Period_Begin_Date And
             v_Current_Period_End_Date;
    end if;
    Return v_Lgorder_NoShip_Qty;
  Exception
    When Others Then
      Return 0;
  End;

  -----------------------------------------------------------------------------
  -- AUTHOR  : Nicro.Li
  -- CREATED : 2016-06-20
  -- PURPOSE : 根据产品、单据送审类型获取产品的库存可用量（符合条件仓库的汇总）
  -----------------------------------------------------------------------------
  Function f_Get_Item_Inv_Usable_Qty(p_Entity_Id         In Number, ----主体ID
                                     p_Item_Id           In Number, --产品ID
                                     p_Order_Submit_Type In Varchar2, --单据送审类型
                                     p_Sales_Center_Id   In Number, --营销中心ID
                                     p_User_Code         In Varchar2  --用户编码
                                     ) Return Number Is
    v_Sql                        Varchar2(4000);
    v_Item_Usable_Qty            Number;
    v_LgOrder_NoShip_Qty         Number;
  Begin
    If p_Order_Submit_Type = 'CENTER_TYPE' Then
      v_Sql := 'Select Nvl(Sum(Nvl(Pkg_Inv_Pub.f_Get_Item_Inv_Qoh(:1,
                                                        Inv.Inventory_Id,
                                                        :2,
                                                        :3,
                                                        2), --可用量
                         0)),
                 0) Item_Usable_Qty
        From (Select t.Inventory_Id, t.Inventory_Code, t.Inventory_Name
                From t_Inv_Inventories t
               Where t.Inventory_Type In (''01'')
                 And Nvl(t.Sales_Center_Flag, ''N'') = ''Y''
                 And Exists
                 (Select 1
                          From t_Inv_Inventories_Sales_Center Isa
                         Where Isa.Inventory_Id = t.Inventory_Id
                           And isa.unit_id = :4)
                 And t.Entity_Id = :5
                 And (Nvl((Select Min(Nvl(Ih.Quantity, 0) / Nvl(Ias.Quantity, 1))
                            From t_Inv_Onhand             Ih,
                                 t_Bd_Item_Assemblies     Ia,
                                 t_Bd_Item_Assemblies_Sub Ias
                           Where Ih.Inventory_Id(+) = t.Inventory_Id
                             And Ia.Item_Id = :6
                             And Ia.Item_Assembly_Id = Ias.Item_Assembly_Id
                             And Ih.Item_Id(+) = Ias.Item_Id),
                          0) > 0 Or Nvl((Select Nvl(Ih.Quantity, 0)
                                           From t_Inv_Onhand Ih
                                          Where Ih.Inventory_Id = t.Inventory_Id
                                            And Ih.Item_Id = :7),
                                         0) > 0)) Inv';
      Execute Immediate v_Sql Into v_Item_Usable_Qty
        Using p_Entity_Id, p_Item_Id, p_User_Code, p_Sales_Center_Id, p_Entity_Id, p_Item_Id, p_Item_Id;
    --Elsif p_Order_Submit_Type = 'HQ_TYPE' Then
    else
      v_Sql := 'Select Nvl(Sum(Nvl(Pkg_Inv_Pub.f_Get_Item_Inv_Qoh(:1,
                                                        Inv.Inventory_Id,
                                                        :2,
                                                        :3,
                                                        2), --可用量
                         0)),
                 0) Item_Usable_Qty
        From (Select t.Inventory_Id, t.Inventory_Code, t.Inventory_Name
                From t_Inv_Inventories t
               Where t.Inventory_Type In (''01'')
                 And Nvl(t.Base_Flag, ''N'') = ''Y''
                 And t.Entity_Id = :4
                 And (Nvl((Select Min(Nvl(Ih.Quantity, 0) / Nvl(Ias.Quantity, 1))
                            From t_Inv_Onhand             Ih,
                                 t_Bd_Item_Assemblies     Ia,
                                 t_Bd_Item_Assemblies_Sub Ias
                           Where Ih.Inventory_Id(+) = t.Inventory_Id
                             And Ia.Item_Id = :5
                             And Ia.Item_Assembly_Id = Ias.Item_Assembly_Id
                             And Ih.Item_Id(+) = Ias.Item_Id),
                          0) > 0 Or Nvl((Select Nvl(Ih.Quantity, 0)
                                           From t_Inv_Onhand Ih
                                          Where Ih.Inventory_Id = t.Inventory_Id
                                            And Ih.Item_Id = :6),
                                         0) > 0)) Inv';
      Execute Immediate v_Sql Into v_Item_Usable_Qty
        Using p_Entity_Id, p_Item_Id, p_User_Code, p_Entity_Id, p_Item_Id, p_Item_Id;
    End If;
    
    Return Nvl(v_Item_Usable_Qty, 0);
  Exception
    When v_Base_Exception Then
      Return 0;
  End;
  
  -----------------------------------------------------------------------------
  -- AUTHOR  : Nicro.Li
  -- CREATED : 2016-04-05
  -- PURPOSE : 根据产品、单据送审类型获取产品的库存可用量（符合条件仓库的汇总）+ 备货订单数量
  -----------------------------------------------------------------------------
  Function f_Get_Item_Usable_Qty(p_Entity_Id         In Number, ----主体ID
                                 p_Item_Id           In Number, --产品ID
                                 p_Order_Submit_Type In Varchar2, --单据送审类型
                                 p_Sales_Center_Id   In Number, --营销中心ID
                                 p_Lg_Order_Noship   In Varchar2, --是否扣减已评未发货数量  Y:扣减  N:不扣减
                                 p_User_Code         In Varchar2  --用户编码
                                 ) Return Number Is
    v_Sql                        Varchar2(4000);
    v_Item_Usable_Qty            Number;
    v_LgOrder_NoShip_Qty         Number;
  Begin
    /*If p_Order_Submit_Type Not In ('HQ_TYPE', 'CENTER_TYPE') Then
      Return 0;
    End If;*/
    If p_Order_Submit_Type = 'CENTER_TYPE' Then
      v_Item_Usable_Qty := f_Get_Item_Inv_Usable_Qty(p_Entity_Id         => p_Entity_Id, ----主体ID
                                                   p_Item_Id           => p_Item_Id, --产品ID
                                                   p_Order_Submit_Type => p_Order_Submit_Type, --单据送审类型
                                                   p_Sales_Center_Id   => p_Sales_Center_Id, --营销中心ID
                                                   p_User_Code         => p_User_Code --用户编码
                                                   );
    --Elsif p_Order_Submit_Type = 'HQ_TYPE' Then
    else
      v_Item_Usable_Qty := f_Get_Item_Inv_Usable_Qty(p_Entity_Id         => p_Entity_Id, ----主体ID
                                                     p_Item_Id           => p_Item_Id, --产品ID
                                                     p_Order_Submit_Type => p_Order_Submit_Type, --单据送审类型
                                                     p_Sales_Center_Id   => p_Sales_Center_Id, --营销中心ID
                                                     p_User_Code         => p_User_Code --用户编码
                                                     ) +
                         f_Get_Meet_An_Order_Qty(p_Entity_Id         => p_Entity_Id,
                                                 p_Item_Id           => p_Item_Id,
                                                 p_Order_Submit_Type => p_Order_Submit_Type);
    End If;
    If Nvl(p_Lg_Order_Noship, 'N') = 'Y' Then
      v_Lgorder_Noship_Qty := f_Get_Lgorder_Noship_Qty(p_Entity_Id => p_Entity_Id,
                                                      p_Item_Id   => p_Item_Id,
                                                      p_Order_Submit_Type => p_Order_Submit_Type, --单据送审类型
                                                      p_User_Code => p_User_Code);
      If Nvl(v_Item_Usable_Qty, 0) - Nvl(v_Lgorder_Noship_Qty, 0) > 0 Then
        Return Nvl(v_Item_Usable_Qty, 0) - Nvl(v_Lgorder_Noship_Qty, 0);
      Else
        Return 0;
      End If;
    Else
      Return Nvl(v_Item_Usable_Qty, 0);
    End If;
  Exception
    When v_Base_Exception Then
      Return 0;
  End;
  
  -----------------------------------------------------------------------------
  -- AUTHOR  : Nicro.Li
  -- CREATED : 2016-06-15
  -- PURPOSE : 根据产品、单据送审类型获取产品的备货订单未入库数量
  -----------------------------------------------------------------------------
  Function f_Get_Meet_An_Order_Qty(p_Entity_Id         In Number, ----主体ID
                                   p_Item_Id           In Number, --产品ID
                                   p_Order_Submit_Type In Varchar2 --单据送审类型
                                   ) Return Number Is
    v_Sql                   Varchar2(4000);
    v_Item_MeetAnOrder_Qty  Number;
    v_Current_Period_Begin_Date Date;
    v_Current_Period_End_Date   Date;   
    v_Pln_Of_Time_Month  Number;   
  Begin
    --APS产能可视统计提货订单数据周期提前月数
    Begin
      v_Pln_Of_Time_Month := Pkg_Bd.f_Get_Parameter_Value('PLN_CAPACITY_AHEAD_OF_TIME_MONTH',
                                                                          p_Entity_Id);
    Exception
      When Others Then
        v_Pln_Of_Time_Month := 0;
    End;
 
    p_Get_Currentperioddate(p_Entity_Id                 => p_Entity_Id,
                            IN_CAL_DATE => trunc(sysdate),
                            p_Current_Period_Begin_Date => v_Current_Period_Begin_Date,
                            p_Current_Period_End_Date   => v_Current_Period_End_Date);
    v_Current_Period_Begin_Date := Add_Months(v_Current_Period_Begin_Date, v_Pln_Of_Time_Month);
  
    If p_Order_Submit_Type = 'HQ_TYPE' Then
      Select Sum(Nvl(Pol.Can_Produce_Qty, 0) - Nvl(Pol.Supply_Qty, 0))
        Into v_Item_Meetanorder_Qty
        From t_Pln_Order_Head Poh, t_Pln_Order_Line Pol
       Where Poh.Order_Head_Id = Pol.Order_Head_Id
         And Poh.Entity_Id = p_Entity_Id
         And Poh.Form_State In ('23', '32')
         And Trunc(Poh.Refer_Date) Between v_Current_Period_Begin_Date And v_Current_Period_End_Date
         And Pol.Item_Id = p_Item_Id
         And Exists (Select Uc.Code_Value
                From v_Up_Codelist Uc
               Where Uc.Codetype = 'PLN_CAPACITY_MEET_AN_ORDER'
                 And Uc.Enabled = 0
                 And Uc.Code_Value = Poh.Order_Type_Id
                 And Uc.Entity_Id = Poh.Entity_Id);
    Else
      v_Item_MeetAnOrder_Qty := 0;
    End If;
    Return Nvl(v_Item_MeetAnOrder_Qty, 0);
  Exception
    When Others Then
      Return 0;
  End;
  
  ---------------------------------------------------------------------------------
  -- Author  : 李梁华
  -- Created : 2016-4-11
  -- Purpose : 特价机占比检查
 ---------------------------------------------------------------------------------
 PROCEDURE P_PLN_CHK_SP_ITEM(P_ORDER_HEAD_ID IN NUMBER, --订单头ID
                             P_ENTITY_ID     IN NUMBER, --主体ID
                             P_RESULT        OUT VARCHAR2) IS
   V_SP_PRICE_TYPE_ID          T_PLN_SP_PRICE_TYPE.SP_PRICE_TYPE_ID%TYPE; --占比类型Id
   V_SP_PRICE_TYPE_NAME        T_PLN_SP_PRICE_TYPE.SP_PRICE_TYPE_NAME%TYPE; --占比类型名称
   V_PROPORTION                T_PLN_SP_PRICE_TYPE.PROPORTION%TYPE; --占比比例
   V_CUSTOMER_CODE             T_PLN_LG_ORDER_HEAD.CUSTOMER_CODE%TYPE; --客户编码
   V_SP_ITEM_QUANTITY          NUMBER := 0; --一个月内占比类型下特价机数量
   V_SP_ITEM_TOTAL_QTY         NUMBER := 0; --一个月内占比类型下所有参与计算的产品数量总和
   V_PROPORTION_CALCULATE      NUMBER := 0; --计算特价机占比
   V_CURRENT_SP_ITEM_QUANTITY  NUMBER := 0; --当前订单的特价机数量
   V_CURRENT_SP_ITEM_TOTAL_QTY NUMBER := 0; --当前订单的参与计算的产品数量总和
   V_OVER_COUNT                NUMBER := 0; --超出占比数量
   V_BEGIN_DATE1               DATE; --产能可视计算起始时间
   V_BEGIN_DATE                DATE; --特价机订单统计的起始时间
   V_END_DATE                  DATE; --订单统计的终止时间
 
   --厨电特价推广增加,按金额统计 add by lilh6 16-8-23
   V_SP_ITEM_MONEY               NUMBER := 0; --一个月内占比类型下特价机金额
   V_SP_ITEM_TOTAL_MONEY         NUMBER := 0; --一个月内占比类型下所有参与计算的产品金额总和
   V_CURRENT_SP_ITEM_MONEY       NUMBER := 0; --当前订单的特价机金额
   V_CURRENT_SP_ITEM_TOTAL_MONEY NUMBER := 0; --当前订单的参与计算的产品金额总和
   V_SP_ITEM_TEMP                NUMBER := 0;
   V_SP_ITEM_TOTAL_TEMP          NUMBER := 0;
   V_CURRENT_SP_ITEM_TEMP        NUMBER := 0;
   V_CURRENT_SP_ITEM_TOTAL_TEMP  NUMBER := 0;
   V_CALCULATE_MODE              VARCHAR2(32); --计算方式
   V_MESSAGE                     VARCHAR2(32);
   V_CONTROL_TYPE                VARCHAR2(32); --特价机控制方式 中心：CENTER 客户：CUSTOMER
   TYPE V_PLN_SP_PRICE_TYPE_CURSOR IS REF CURSOR; --声明动态游标
   T_PLN_SP_PRICE_TYPE_CURSOR V_PLN_SP_PRICE_TYPE_CURSOR;
 
 BEGIN
   P_RESULT := V_SUCCESS;
   --获取计算模式
   BEGIN
     V_CALCULATE_MODE := PKG_BD.F_GET_PARAMETER_VALUE('PLN_SP_PRICE_TYPE_CALCULATE_MODE',
                                                      P_ENTITY_ID);
   EXCEPTION
     WHEN OTHERS THEN
       P_RESULT := '获取PLN_SP_PRICE_TYPE_CALCULATE_MODE参数失败！' || V_NL ||
                   SQLERRM;
       RAISE V_BASE_EXCEPTION;
   END;
   --获取时间范围
   P_GET_CURRENTPERIODDATE(P_ENTITY_ID, SYSDATE, V_BEGIN_DATE1, V_END_DATE);
   IF V_BEGIN_DATE1 IS NULL AND V_END_DATE IS NULL THEN
     SELECT TRUNC(SYSDATE, 'mm') INTO V_BEGIN_DATE FROM DUAL;
     SELECT TRUNC(LAST_DAY(SYSDATE)) INTO V_END_DATE FROM DUAL;
   ELSE
     SELECT ADD_MONTHS(V_BEGIN_DATE1,
                       (SELECT PKG_BD.F_GET_PARAMETER_VALUE('PLN_CAPACITY_AHEAD_OF_TIME_MONTH',
                                                            P_ENTITY_ID)
                          FROM DUAL))
       INTO V_BEGIN_DATE
       FROM DUAL;
   END IF;
   --获取控制参数
   BEGIN
     V_CONTROL_TYPE := PKG_BD.F_GET_PARAMETER_VALUE('PLN_SP_PRICE_TYPE_CONTROL',
                                                    P_ENTITY_ID);
   EXCEPTION
     WHEN OTHERS THEN
       P_RESULT := '获取PLN_SP_PRICE_TYPE_CONTROL参数失败！' || V_NL || SQLERRM;
       RAISE V_BASE_EXCEPTION;
   END;
 
   IF V_CONTROL_TYPE = 'CENTER' THEN
     BEGIN
       OPEN T_PLN_SP_PRICE_TYPE_CURSOR FOR
       --获取占比，客户（中心控制方式）
        'SELECT SPT.SP_PRICE_TYPE_ID,
            SPT.SP_PRICE_TYPE_NAME,
            SPT.PROPORTION,
            H.CUSTOMER_CODE
       FROM T_PLN_LG_ORDER_HEAD     H,
            T_CUSTOMER_CHANNEL_TYPE CCT,
            T_PLN_CUSGTYPE_SPTYPE_R R,
            T_PLN_SP_PRICE_TYPE     SPT
      WHERE CCT.INDUSTRY_TYPE = R.CUSG_CHANNEL_TYPE
        AND R.SP_PRICE_TYPE_ID = SPT.SP_PRICE_TYPE_ID
        AND CCT.CUSTOMER_CODE = H.CUSTOMER_CODE
        AND R.BEGIN_DATE <= SYSDATE
        AND (R.END_DATE >= SYSDATE OR R.END_DATE IS NULL)
        AND CCT.ACTIVE_FLAG = ''Active''
        AND H.ORDER_HEAD_ID = :1 AND H.ENTITY_ID = :2 AND SPT.SALES_CENTER_CODE IS NULL
        AND CCT.ENTITY_ID = H.ENTITY_ID
        AND SPT.ENTITY_ID IN
            (SELECT EE.ENTITY_ID
               FROM UP_CODELIST U, UP_CODELIST_ENTITY EE
              WHERE U.CODETYPE = ''plnMergeEntity''
                AND U.ID = EE.CODELIST_ID
                AND U.CODE_VALUE = :3)
        AND NOT EXISTS
      (SELECT 1
               FROM T_PLN_SP_CUST_EXP E
              WHERE E.SP_PRICE_TYPE_ID = SPT.SP_PRICE_TYPE_ID
                AND E.CUSTOMER_ID = H.CUSTOMER_ID
                AND NVL(E.ACTIVE_FLAG,''Y'') = ''Y''
                AND E.ENTITY_ID IN
                    (SELECT EE.ENTITY_ID
                       FROM UP_CODELIST U, UP_CODELIST_ENTITY EE
                      WHERE U.CODETYPE = ''plnMergeEntity''
                        AND U.ID = EE.CODELIST_ID
                        AND U.CODE_VALUE = :4))
          UNION ALL
     SELECT SPT.SP_PRICE_TYPE_ID,
            SPT.SP_PRICE_TYPE_NAME,
            SPT.PROPORTION,
            H.CUSTOMER_CODE
       FROM T_PLN_LG_ORDER_HEAD     H,
            T_CUSTOMER_CHANNEL_TYPE CCT,
            T_PLN_CUSGTYPE_SPTYPE_R R,
            T_PLN_SP_PRICE_TYPE     SPT
      WHERE CCT.INDUSTRY_TYPE = R.CUSG_CHANNEL_TYPE
        AND R.SP_PRICE_TYPE_ID = SPT.SP_PRICE_TYPE_ID
        AND CCT.CUSTOMER_CODE = H.CUSTOMER_CODE
        AND R.BEGIN_DATE <= SYSDATE
        AND (R.END_DATE >= SYSDATE OR R.END_DATE IS NULL)
        AND CCT.ACTIVE_FLAG = ''Active''
        AND H.ORDER_HEAD_ID = :5 AND H.ENTITY_ID = :6 AND SPT.SALES_CENTER_CODE = H.SALES_CENTER_CODE
        AND CCT.ENTITY_ID = H.ENTITY_ID
        AND SPT.ENTITY_ID IN
            (SELECT EE.ENTITY_ID
               FROM UP_CODELIST U, UP_CODELIST_ENTITY EE
              WHERE U.CODETYPE = ''plnMergeEntity''
                AND U.ID = EE.CODELIST_ID
                AND U.CODE_VALUE = :7)
        AND NOT EXISTS
      (SELECT 1
               FROM T_PLN_SP_CUST_EXP E
              WHERE E.SP_PRICE_TYPE_ID = SPT.SP_PRICE_TYPE_ID
                AND E.CUSTOMER_ID = H.CUSTOMER_ID
                AND NVL(E.ACTIVE_FLAG,''Y'') = ''Y''
                AND E.ENTITY_ID IN
                    (SELECT EE.ENTITY_ID
                       FROM UP_CODELIST U, UP_CODELIST_ENTITY EE
                      WHERE U.CODETYPE = ''plnMergeEntity''
                        AND U.ID = EE.CODELIST_ID
                        AND U.CODE_VALUE = :8))'
       using P_ORDER_HEAD_ID, P_ENTITY_ID, P_ENTITY_ID, P_ENTITY_ID,
             P_ORDER_HEAD_ID, P_ENTITY_ID, P_ENTITY_ID, P_ENTITY_ID;
     EXCEPTION
       WHEN OTHERS THEN
         P_RESULT := '获取客户占比类型失败！' || V_NL || SQLERRM;
         RAISE V_BASE_EXCEPTION;
     END;
   ELSIF V_CONTROL_TYPE = 'CUSTOMER' THEN
   BEGIN
       OPEN T_PLN_SP_PRICE_TYPE_CURSOR FOR
       --获取占比，客户（客户控制方式）
        'SELECT R.SP_PRICE_TYPE_ID,
            R.PRE_FIELD_01 SP_PRICE_TYPE_NAME,
            R.PROPORTION,
            H.CUSTOMER_CODE
       FROM T_PLN_LG_ORDER_HEAD H, T_PLN_CUSTOM_CONTROL_RELATION R
      WHERE H.ORDER_HEAD_ID = :1 AND H.ENTITY_ID = R.ENTITY_ID
        AND H.SALES_CENTER_CODE = R.SALES_CENTER_CODE
        AND H.CUSTOMER_CODE = R.CUSTOMER_CODE
        AND NOT EXISTS
      (SELECT 1
               FROM T_PLN_SP_CUST_EXP E
              WHERE E.SP_PRICE_TYPE_ID = R.SP_PRICE_TYPE_ID
                AND E.CUSTOMER_ID = H.CUSTOMER_ID
                AND NVL(E.ACTIVE_FLAG,''Y'') = ''Y''
                AND E.ENTITY_ID IN
                    (SELECT EE.ENTITY_ID
                       FROM UP_CODELIST U, UP_CODELIST_ENTITY EE
                      WHERE U.CODETYPE = ''plnMergeEntity''
                        AND U.ID = EE.CODELIST_ID
                        AND U.CODE_VALUE = :2))'
     using P_ORDER_HEAD_ID, P_ENTITY_ID;
   EXCEPTION
     WHEN OTHERS THEN
         P_RESULT := '获取客户占比类型失败！' || V_NL || SQLERRM;
       RAISE V_BASE_EXCEPTION;
   END;
   END IF;
     --OPEN T_PLN_SP_PRICE_TYPE_CURSOR;
   LOOP
     FETCH T_PLN_SP_PRICE_TYPE_CURSOR
       INTO V_SP_PRICE_TYPE_ID,
            V_SP_PRICE_TYPE_NAME,
            V_PROPORTION,
            V_CUSTOMER_CODE;
     EXIT WHEN T_PLN_SP_PRICE_TYPE_CURSOR%NOTFOUND;
     --统计特价机急数
     SELECT NVL(SUM(
                    --add by lizhen 2016-06-28 增加已关闭订单行取数功能
                    DECODE(NVL(L.ORDER_LINE_STATE, 'NORMAL'),
                           'CLOSED',
                           L.AFFIRMED_QUANTITY,
                           DECODE(H.ORDER_HEAD_STATE,
                                  304,
                                  L.AFFIRMED_QUANTITY,
                                  23,
                                  L.AFFIRMED_QUANTITY,
                                  381,
                                  NVL(L.CENTER_AFFIRMED_QTY, 0) +
                                  NVL(L.SUBMIT_HQ_QTY, 0),
                                  679,
                                  NVL(L.CENTER_AFFIRMED_QTY, 0) +
                                  NVL(L.SUBMIT_HQ_QTY, 0),
                                  20,
                                  L.QUANTITY,
                                  1455,
                                  L.CENTER_AFFIRM_QUANTITY,
                                  2225,
                                  L.QUANTITY,
                                  0))),
                0),
            NVL(SUM(
                    --add by lizhen 2016-06-28 增加已关闭订单行取数功能
                    NVL(DECODE(L.PROJECT_ORDER_NUMBER,
                               NULL,
                               L.LIST_PRICE,
                               L.APPLY_LIST_PRICE),
                        0) *
                    (1 - NVL(L.DISCOUNT_RATE, 0) / 100 -
                     NVL(L.ORDERED_DISCOUNT_RATE, 0) / 100) *
                    NVL((DECODE(NVL(L.ORDER_LINE_STATE, 'NORMAL'),
                                'CLOSED',
                                L.AFFIRMED_QUANTITY,
                                DECODE(H.ORDER_HEAD_STATE,
                                       304,
                                       L.AFFIRMED_QUANTITY,
                                       23,
                                       L.AFFIRMED_QUANTITY,
                                       381,
                                       NVL(L.CENTER_AFFIRMED_QTY, 0) +
                                       NVL(L.SUBMIT_HQ_QTY, 0),
                                       679,
                                       NVL(L.CENTER_AFFIRMED_QTY, 0) +
                                       NVL(L.SUBMIT_HQ_QTY, 0),
                                       20,
                                       L.QUANTITY,
                                       1455,
                                       L.CENTER_AFFIRM_QUANTITY,
                                       2225,
                                       L.QUANTITY,
                                       0))),
                        0)),
                0)
       INTO V_SP_ITEM_QUANTITY, V_SP_ITEM_MONEY
       FROM T_PLN_LG_ORDER_HEAD H,
            T_PLN_LG_ORDER_LINE L,
            T_PLN_ORDER_TYPE    T
      WHERE H.ORDER_HEAD_ID = L.ORDER_HEAD_ID
        AND H.ORDER_TYPE_ID = T.ORDER_TYPE_ID
        AND T.SOURCE_ORDER_TYPE_ID = 1
        AND H.CUSTOMER_CODE = V_CUSTOMER_CODE
        AND H.ENTITY_ID IN
            (SELECT E.ENTITY_ID
               FROM UP_CODELIST U, UP_CODELIST_ENTITY E
              WHERE U.CODETYPE = 'plnMergeEntity'
                AND U.ID = E.CODELIST_ID
                AND U.CODE_VALUE = TO_CHAR(P_ENTITY_ID))
        AND H.TO_CHECKUP_DATE >= V_BEGIN_DATE
        AND H.TO_CHECKUP_DATE < V_END_DATE + 1
        AND L.ITEM_ID IN (SELECT SPI.ITEM_ID
                            FROM T_PLN_SP_PRICE_ITEM SPI
                           WHERE SPI.SP_PRICE_TYPE_ID = V_SP_PRICE_TYPE_ID
                             AND SPI.SP_ITEM_FLAG = 'Y'
                             AND SPI.CALCULATE_FLAG = 'Y'
                             AND NVL(SPI.ACTIVE_FLAG,'Y') = 'Y');
     --统计当前订单的特价机数
       SELECT nvl(SUM(L.QUANTITY),0),
              nvl(SUM(NVL(DECODE(L.PROJECT_ORDER_NUMBER,
                           NULL,
                           L.LIST_PRICE,
                           L.APPLY_LIST_PRICE),
                    0) * (1 - NVL(L.DISCOUNT_RATE, 0) / 100 -
                          NVL(L.ORDERED_DISCOUNT_RATE, 0) / 100) *
                  L.QUANTITY),0)
       INTO V_CURRENT_SP_ITEM_QUANTITY, V_CURRENT_SP_ITEM_MONEY
       FROM T_PLN_LG_ORDER_HEAD H, T_PLN_LG_ORDER_LINE L
      WHERE H.ORDER_HEAD_ID = L.ORDER_HEAD_ID
        AND H.ORDER_HEAD_ID = P_ORDER_HEAD_ID
        AND L.ITEM_ID IN (SELECT SPI.ITEM_ID
                            FROM T_PLN_SP_PRICE_ITEM SPI
                           WHERE SPI.SP_PRICE_TYPE_ID = V_SP_PRICE_TYPE_ID
                             AND SPI.SP_ITEM_FLAG = 'Y'
                             AND SPI.CALCULATE_FLAG = 'Y'
                             AND NVL(SPI.ACTIVE_FLAG,'Y') = 'Y');
     --统计参与计算的产品数
     SELECT NVL(SUM(
                    --add by lizhen 2016-06-28 增加已关闭订单行取数功能
                    DECODE(NVL(L.ORDER_LINE_STATE, 'NORMAL'),
                           'CLOSED',
                           L.AFFIRMED_QUANTITY,
                           DECODE(H.ORDER_HEAD_STATE,
                                  304,
                                  L.AFFIRMED_QUANTITY,
                                  23,
                                  L.AFFIRMED_QUANTITY,
                                  381,
                                  NVL(L.CENTER_AFFIRMED_QTY, 0) +
                                  NVL(L.SUBMIT_HQ_QTY, 0),
                                  679,
                                  NVL(L.CENTER_AFFIRMED_QTY, 0) +
                                  NVL(L.SUBMIT_HQ_QTY, 0),
                                  20,
                                  L.QUANTITY,
                                  1455,
                                  L.CENTER_AFFIRM_QUANTITY,
                                  2225,
                                  L.QUANTITY,
                                  0))),
                0),
            NVL(SUM(
                    --add by lizhen 2016-06-28 增加已关闭订单行取数功能
                    NVL(DECODE(L.PROJECT_ORDER_NUMBER,
                               NULL,
                               L.LIST_PRICE,
                               L.APPLY_LIST_PRICE),
                        0) *
                    (1 - NVL(L.DISCOUNT_RATE, 0) / 100 -
                     NVL(L.ORDERED_DISCOUNT_RATE, 0) / 100) *
                    NVL((DECODE(NVL(L.ORDER_LINE_STATE, 'NORMAL'),
                                'CLOSED',
                                L.AFFIRMED_QUANTITY,
                                DECODE(H.ORDER_HEAD_STATE,
                                       304,
                                       L.AFFIRMED_QUANTITY,
                                       23,
                                       L.AFFIRMED_QUANTITY,
                                       381,
                                       NVL(L.CENTER_AFFIRMED_QTY, 0) +
                                       NVL(L.SUBMIT_HQ_QTY, 0),
                                       679,
                                       NVL(L.CENTER_AFFIRMED_QTY, 0) +
                                       NVL(L.SUBMIT_HQ_QTY, 0),
                                       20,
                                       L.QUANTITY,
                                       1455,
                                       L.CENTER_AFFIRM_QUANTITY,
                                       2225,
                                       L.QUANTITY,
                                       0))),
                        0)),
                0)
       INTO V_SP_ITEM_TOTAL_QTY, V_SP_ITEM_TOTAL_MONEY
       FROM T_PLN_LG_ORDER_HEAD H,
            T_PLN_LG_ORDER_LINE L,
            T_PLN_ORDER_TYPE    T
      WHERE H.ORDER_HEAD_ID = L.ORDER_HEAD_ID
        AND H.ORDER_TYPE_ID = T.ORDER_TYPE_ID
        AND T.SOURCE_ORDER_TYPE_ID = 1
        AND H.CUSTOMER_CODE = V_CUSTOMER_CODE
        AND H.ENTITY_ID IN
            (SELECT E.ENTITY_ID
               FROM UP_CODELIST U, UP_CODELIST_ENTITY E
              WHERE U.CODETYPE = 'plnMergeEntity'
                AND U.ID = E.CODELIST_ID
                AND U.CODE_VALUE = TO_CHAR(P_ENTITY_ID))
        AND H.TO_CHECKUP_DATE >= V_BEGIN_DATE
        AND H.TO_CHECKUP_DATE < V_END_DATE + 1
        AND L.ITEM_ID IN (SELECT SPI.ITEM_ID
                            FROM T_PLN_SP_PRICE_ITEM SPI
                           WHERE SPI.SP_PRICE_TYPE_ID = V_SP_PRICE_TYPE_ID
                             AND SPI.CALCULATE_FLAG = 'Y'
                             AND NVL(SPI.ACTIVE_FLAG,'Y') = 'Y');
     --统计当前订单参与计算的产品数
       SELECT nvl(SUM(L.QUANTITY),0),
              nvl(SUM(NVL(DECODE(L.PROJECT_ORDER_NUMBER,
                           NULL,
                           L.LIST_PRICE,
                           L.APPLY_LIST_PRICE),
                    0) * (1 - NVL(L.DISCOUNT_RATE, 0) / 100 -
                          NVL(L.ORDERED_DISCOUNT_RATE, 0) / 100) *
                  L.QUANTITY),0)
       INTO V_CURRENT_SP_ITEM_TOTAL_QTY, V_CURRENT_SP_ITEM_TOTAL_MONEY
       FROM T_PLN_LG_ORDER_HEAD H, T_PLN_LG_ORDER_LINE L
      WHERE H.ORDER_HEAD_ID = L.ORDER_HEAD_ID
        AND H.ORDER_HEAD_ID = P_ORDER_HEAD_ID
        AND L.ITEM_ID IN (SELECT SPI.ITEM_ID
                            FROM T_PLN_SP_PRICE_ITEM SPI
                           WHERE SPI.SP_PRICE_TYPE_ID = V_SP_PRICE_TYPE_ID
                             AND SPI.CALCULATE_FLAG = 'Y'
                             AND NVL(SPI.ACTIVE_FLAG,'Y') = 'Y');
   
     IF V_CALCULATE_MODE = 'QUANTITY' THEN
       V_SP_ITEM_TEMP               := V_SP_ITEM_QUANTITY;
       V_SP_ITEM_TOTAL_TEMP         := V_SP_ITEM_TOTAL_QTY;
       V_CURRENT_SP_ITEM_TEMP       := V_CURRENT_SP_ITEM_QUANTITY;
       V_CURRENT_SP_ITEM_TOTAL_TEMP := V_CURRENT_SP_ITEM_TOTAL_QTY;
       V_MESSAGE                    := '数量';
     ELSIF V_CALCULATE_MODE = 'MONEY' THEN
       V_SP_ITEM_TEMP               := V_SP_ITEM_MONEY;
       V_SP_ITEM_TOTAL_TEMP         := V_SP_ITEM_TOTAL_MONEY;
       V_CURRENT_SP_ITEM_TEMP       := V_CURRENT_SP_ITEM_MONEY;
       V_CURRENT_SP_ITEM_TOTAL_TEMP := V_CURRENT_SP_ITEM_TOTAL_MONEY;
       V_MESSAGE                    := '金额';
     END IF;
     IF (V_SP_ITEM_TOTAL_TEMP + V_CURRENT_SP_ITEM_TOTAL_TEMP) > 0 THEN
       V_PROPORTION_CALCULATE := ROUND(((V_SP_ITEM_TEMP +
                                       V_CURRENT_SP_ITEM_TEMP) /
                                       (V_SP_ITEM_TOTAL_TEMP +
                                       V_CURRENT_SP_ITEM_TOTAL_TEMP)) * 100,
                                       2);
       IF V_PROPORTION_CALCULATE > V_PROPORTION THEN
         V_OVER_COUNT := CEIL(((V_SP_ITEM_TEMP + V_CURRENT_SP_ITEM_TEMP) -
                              (V_SP_ITEM_TOTAL_TEMP +
                                V_CURRENT_SP_ITEM_TOTAL_TEMP) *
                                V_PROPORTION / 100) /
                              (1 - V_PROPORTION / 100));
         /*P_RESULT     := '特价机占比类型：' || V_SP_PRICE_TYPE_NAME || ' 计算的占比比例：' ||
         V_PROPORTION_CALCULATE || '% 大于控制的占比比例：' ||
         V_PROPORTION || '% 不允许提交！ 超出数量：' || V_OVER_COUNT;*/
         P_RESULT := '特价机占比类型：' || V_SP_PRICE_TYPE_NAME || ' 计算的占比比例：' ||
                     V_PROPORTION_CALCULATE || '% 大于控制的占比比例：' ||
                     V_PROPORTION || '% 不允许提交！' || CHR(10) || '(已提交特价机' ||
                     V_MESSAGE || TO_CHAR(V_SP_ITEM_TEMP) || ',当前订单计算特价机' ||
                     V_MESSAGE || TO_CHAR(V_CURRENT_SP_ITEM_TEMP) ||
                     ',已提交产品总' || V_MESSAGE ||
                     TO_CHAR(V_SP_ITEM_TOTAL_TEMP) || ',当前订单计算产品' ||
                     V_MESSAGE || TO_CHAR(V_CURRENT_SP_ITEM_TOTAL_TEMP) || ')';
         FOR LINE_INFO IN (SELECT *
                             FROM CIMS.T_PLN_LG_ORDER_LINE L
                            WHERE L.ORDER_HEAD_ID = P_ORDER_HEAD_ID
                              AND L.ENTITY_ID = P_ENTITY_ID
                              AND L.ITEM_ID IN
                                  (SELECT SPI.ITEM_ID
                                     FROM T_PLN_SP_PRICE_ITEM SPI
                                    WHERE SPI.SP_PRICE_TYPE_ID =
                                          V_SP_PRICE_TYPE_ID
                                      AND SPI.SP_ITEM_FLAG = 'Y'
                                      AND SPI.CALCULATE_FLAG = 'Y')) LOOP
           P_RESULT := P_RESULT || V_NL || '特价机产品编码：' ||
                       LINE_INFO.ITEM_CODE;
         END LOOP;
         RAISE V_BASE_EXCEPTION;
       END IF;
     END IF;
   END LOOP;
   CLOSE T_PLN_SP_PRICE_TYPE_CURSOR;
 EXCEPTION
   WHEN V_BASE_EXCEPTION THEN
     P_RESULT := P_RESULT;
     IF T_PLN_SP_PRICE_TYPE_CURSOR%ISOPEN THEN
       CLOSE T_PLN_SP_PRICE_TYPE_CURSOR;
     END IF;
 END;

  
  -----------------------------------------------------------------------------
  -- AUTHOR  : 吴林
  -- CREATED : 2016-04-12
  -- PURPOSE : 根据主体获取提货订单当前周期期间开始日期与结束日期
  -----------------------------------------------------------------------------
  FUNCTION F_GET_CURRENTPERIODDATE(I_ENTITY_ID   IN NUMBER, --主体ID
                                   I_OPTION_TYPE VARCHAR2 ---B 开始日期  E结束日期
                                   ) RETURN DATE IS
    V_CURRENT_PERIOD_BEGIN_DAY  VARCHAR2(32);
    V_CURRENT_PERIOD_END_DAY    VARCHAR2(32);
    V_CURRENT_PERIOD_BEGIN_DATE DATE;
    V_CURRENT_PERIOD_END_DATE   DATE;
    v_Pln_Of_Time_Month         Number;
  Begin
    --add by lizhen 2016-05-20
    --引APS产能可视是否自动提交APS产能可视处理请求
    Begin
      v_Pln_Of_Time_Month := Pkg_Bd.f_Get_Parameter_Value('PLN_CAPACITY_AHEAD_OF_TIME_MONTH',
                                                          I_Entity_Id);
    Exception
      When Others Then
        v_Pln_Of_Time_Month := 0;
    End;
    
    BEGIN
      SELECT UC.CODE_VALUE, UC.CODE_NAME
        INTO V_CURRENT_PERIOD_BEGIN_DAY, V_CURRENT_PERIOD_END_DAY
        FROM UP_CODELIST UC, UP_CODELIST_ENTITY UCE
       WHERE UC.ID = UCE.CODELIST_ID
         AND UC.CODETYPE = 'plnLgOrderCurrentPeriodDay'
         AND UCE.ENTITY_ID = I_ENTITY_ID
         AND UCE.ENABLED = 0
         AND UC.ENABLED = 0;
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;
    IF To_Number(TO_CHAR(SYSDATE, 'DD')) >= To_Number(V_CURRENT_PERIOD_BEGIN_DAY) THEN
      SELECT TO_DATE(TO_CHAR(SYSDATE, 'yyyy-mm') || '-' ||
                     V_CURRENT_PERIOD_BEGIN_DAY,
                     'yyyy-mm-dd')
        INTO V_CURRENT_PERIOD_BEGIN_DATE
        FROM DUAL;
    ELSE
      SELECT TO_DATE(TO_CHAR(ADD_MONTHS(SYSDATE, -1), 'YYYY-MM') || '-' ||
                     V_CURRENT_PERIOD_BEGIN_DAY,
                     'yyyy-mm-dd')
        INTO V_CURRENT_PERIOD_BEGIN_DATE
        FROM DUAL;
    END IF;
    IF To_Number(TO_CHAR(SYSDATE, 'DD')) > To_Number(V_CURRENT_PERIOD_END_DAY) Then
      --add by lizhen 2017-09-06日期范围不当1~31日时（当前自然月），无31日的月份取当月最大日期
      If To_Number(To_Char(Last_Day(SYSDATE), 'DD')) = To_Number(v_Current_Period_End_Day) Then
        v_Current_Period_End_Date := Trunc(Last_Day(SYSDATE));
      Else
        SELECT TO_DATE(TO_CHAR(ADD_MONTHS(SYSDATE, 1), 'YYYY-MM') || '-' ||
                       V_CURRENT_PERIOD_END_DAY,
                       'yyyy-mm-dd')
          INTO V_CURRENT_PERIOD_END_DATE
          FROM DUAL;
      End If;
    Else
      --add by lizhen 2017-09-06日期范围不当1~31日时（当前自然月），无31日的月份取当月最大日期
      If To_Number(To_Char(Last_Day(SYSDATE), 'DD')) < To_Number(v_Current_Period_End_Day) Then
        v_Current_Period_End_Date := Trunc(Last_Day(SYSDATE));
      Else
        SELECT TO_DATE(TO_CHAR(SYSDATE, 'yyyy-mm') || '-' ||
                     V_CURRENT_PERIOD_END_DAY,
                     'yyyy-mm-dd')
        INTO V_CURRENT_PERIOD_END_DATE
        FROM DUAL;
      End If;
    END IF;
    IF I_OPTION_TYPE = 'B' THEN
      RETURN Add_Months(V_CURRENT_PERIOD_BEGIN_DATE, -1*v_Pln_Of_Time_Month);
    ELSE
      RETURN V_CURRENT_PERIOD_END_DATE;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
     RETURN SYSDATE;
  END;
  
  -----------------------------------------------------------------------------
  -- AUTHOR  : Nicro.Li
  -- CREATED : 2016-08-11
  -- PURPOSE : 根据提货汇总头ID获取各新汇总参数字段在汇总头表对应的值
  -----------------------------------------------------------------------------
  Function f_Get_T3OrdPara_Collect_Value(p_Entity_Id          In Number,
                                         p_Lg_Collect_Head_Id In Number, --提货订单汇总头ID
                                         p_Table_Alias        In Varchar2, --表别名
                                         p_Column_Code        In Varchar2 --字段编码
                                         ) Return Varchar2 Is
    v_Sql    Varchar2(2000);
    v_Index  Number := 1;
    v_Result Varchar2(1000);
  Begin
    For r_Para In (Select Ocp.*
                     From t_Pln_Ord_Collect_Param Ocp
                    Where Ocp.Entity_Id = p_Entity_Id --13
                      And Ocp.Param_Type = 'T3_COLLECT_TYPE'
                    Order By Ocp.Seq_Num) Loop
      If Upper(r_Para.Table_Alias) = Upper(p_Table_Alias) And
        Upper(r_Para.Column_Code) = Upper(p_Column_Code) Then
        Exit;
      End If;
      v_Index := v_Index + 1;
    End Loop;
    v_Sql := ' Select lch.pre_field_' || Trim(To_Char(v_Index, '00')) ||
             ' From t_pln_lg_collect_head lch Where lch.collect_head_id = :1';
    Execute Immediate v_Sql
      Into v_Result
      Using p_Lg_Collect_Head_Id;
    Return v_Result;
  Exception When Others Then
      Return Null;
  End;
  
  -----------------------------------------------------------------------------
  -- AUTHOR  : hejy3
  -- CREATED : 2016-12-17
  -- PURPOSE : 下达校验客户账户、标准成本、批准供应商
  -----------------------------------------------------------------------------
  PROCEDURE P_CHK_ERP_COST_AND_SUPPLIER(P_ENTITY_ID       IN NUMBER, --主体ID
                                        P_SALES_CENTER_ID IN NUMBER, --中心ID
                                        P_CUSTOMER_ID     IN NUMBER, --客户ID
                                        P_ACCOUNT_ID      IN NUMBER, --账户ID
                                        P_INVENTORY_ID    IN NUMBER, --仓库ID
                                        P_ORDER_TYPE_ID   IN NUMBER, --单据类型ID
                                        P_ITEM_ID_LIST    IN VARCHAR2, --产品编码串，格式：ITEM_ID1,ITEM_ID2,...,ITEM_IDN
                                        P_RESULT          OUT VARCHAR2, --返回信息，成功返回'SUCCESS'，否则返回错误信息
                                        IN_BUSINESS_TYPE   IN VARCHAR2 DEFAULT '_'
                                        )
  IS
    V_ENTITY_CHK_COST_FLAG T_BD_PARAM_LIST.DEFAULT_VALUE%TYPE; --主体控制参数
    V_ORDER_TYPE_CHK_COST_FLAG T_PLN_ORDER_TYPE.CHK_ERP_COST_SUPP_FLAG%TYPE; --单据类型控制标志
    V_IS_MATERIAL VARCHAR2(10); --是否推广物料
    V_ENTITY_CUST_FLAG VARCHAR2(10); --20161124 hejy3 事业部标识
    V_CUST_CHECK_FLAG VARCHAR2(10); --20161124 hejy3 客户检查标识
    V_CUST_CHECK_MSG VARCHAR2(4000); --20161124 hejy3 客户检查信息
    V_ERR_NUM NUMBER; --错误号
    V_SALES_CENTER_CODE UP_ORG_UNIT.CODE%TYPE;
    V_SALES_CENTER_NAME UP_ORG_UNIT.NAME%TYPE;
    V_CUSTOMER_CODE T_CUSTOMER_HEADER.CUSTOMER_CODE%TYPE;
    V_CUSTOMER_NAME T_CUSTOMER_HEADER.CUSTOMER_NAME%TYPE;
    V_ACCOUNT_CODE T_CUSTOMER_ACCOUNT.ACCOUNT_CODE%TYPE;
    V_INVENTORY_CODE T_INV_INVENTORIES.INVENTORY_CODE%TYPE;
    V_INVENTORY_NAME T_INV_INVENTORIES.INVENTORY_NAME%TYPE;
    V_SUPPLY_OU_ID NUMBER; --供方OUID
    V_SUPPLY_OU_NAME VARCHAR2(1000); --供方OU名称
    V_SUPPER_REQ T_SO_SUPPLIER_REQUIRE_ENTITY%ROWTYPE;
    TYPE C_GET_ITEM IS REF CURSOR; --声明动态游标
    V_GET_ITEM C_GET_ITEM;
    R_GET_ITEM T_BD_ITEM%ROWTYPE;
    V_VENDOR_ID NUMBER;
    V_VENDOR_SITE_ID NUMBER;
    v_Item_Price number;
    v_Discount number;
    v_Month_Discount number;
    v_Cx_Flag varchar2(32);
    V_ORGANIZATION_ID T_INV_INVENTORIES.ORGANIZATION_ID%TYPE;
    V_ORGANIZATION_NAME T_INV_ORGANIZATION.ORGANIZATION_NAME%TYPE;
    V_ENTITY_FIN_SYS T_BD_PARAM_ENTITY.ENTITY_VALUE%TYPE := 'ERP';
    V_ERP_COST_RESULT NUMBER;
    V_CHK_SUPPLY_ERP_COST_FLAG T_BD_PARAM_LIST.DEFAULT_VALUE%TYPE; --校验供方ERP标准成本
  BEGIN
    P_RESULT := v_Success;
    --获取订单检查标准成本标志
    SELECT T.CHK_ERP_COST_SUPP_FLAG,
           DECODE(UPPER(T.IS_BUSINESS_CONTROL), 'PRO_ORDER', '''Y''', '''N''')
      INTO V_ORDER_TYPE_CHK_COST_FLAG, V_IS_MATERIAL
      FROM T_PLN_ORDER_TYPE T
     WHERE T.ORDER_TYPE_ID = P_ORDER_TYPE_ID;
     
    --获取是否检查ERP成本参数
    Begin
      V_ENTITY_CHK_COST_FLAG := Pkg_Bd.f_Get_Parameter_Value('inv_erp_item_cost',
                                                             P_ENTITY_ID);
    Exception
      When Others Then
        P_RESULT := '获取主体参数失败，主体参数编码【inv_erp_item_cost】！' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;
    
    --获取对接系统参数
    Begin
      V_ENTITY_FIN_SYS := Pkg_Bd.f_Get_Parameter_Value('PUB_FIN_SYS', P_ENTITY_ID);
    Exception
      When Others Then
        P_RESULT := '获取主体参数失败，主体参数编码【PUB_FIN_SYS】！' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;
    
    IF V_ENTITY_FIN_SYS <> 'ERP' THEN
      RETURN;
    END IF;
    
    --获取是否检查ERP成本参数
    Begin
      V_CHK_SUPPLY_ERP_COST_FLAG := Pkg_Bd.f_Get_Parameter_Value('PLN_ORDER_AFFIRM_CHECK_ERP_COST',
                                                             P_ENTITY_ID);
    Exception
      When Others Then
        P_RESULT := '获取主体参数失败，主体参数编码【PLN_ORDER_AFFIRM_CHECK_ERP_COST】！' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;
    
    --获取仓库编码和名称
    BEGIN
      SELECT I.INVENTORY_CODE, I.INVENTORY_NAME, I.ORGANIZATION_ID, O.ORGANIZATION_NAME
        INTO V_INVENTORY_CODE, V_INVENTORY_NAME, V_ORGANIZATION_ID, V_ORGANIZATION_NAME
        FROM T_INV_INVENTORIES I, T_INV_ORGANIZATION O
       WHERE I.INVENTORY_ID = P_INVENTORY_ID
         AND I.ORGANIZATION_ID = O.ORGANIZATION_ID
         AND O.ENTITY_ID = P_ENTITY_ID;
    EXCEPTION
      WHEN OTHERS THEN
        P_RESULT := '获取仓库信息失败，请检查仓库是否存在。仓库ID：' || TO_CHAR(P_INVENTORY_ID);
        RAISE v_Base_Exception;
    END;
    
    --校验供方成本
    if V_ENTITY_CHK_COST_FLAG = 'Y' AND V_CHK_SUPPLY_ERP_COST_FLAG = 'Y' then
      OPEN V_GET_ITEM FOR 'SELECT * FROM T_BD_ITEM I WHERE I.ITEM_ID IN (' || P_ITEM_ID_LIST || ')';
      LOOP
        FETCH V_GET_ITEM INTO R_GET_ITEM;
        EXIT WHEN V_GET_ITEM%NOTFOUND;
              
        FOR R_ITEM IN (
          SELECT BI.ITEM_CODE, BI.ITEM_NAME
            FROM T_BD_ITEM_ASSEMBLIES A,
                 T_BD_ITEM_ASSEMBLIES_SUB S,
                 T_BD_ITEM BI
           WHERE A.ITEM_ASSEMBLY_ID = S.ITEM_ASSEMBLY_ID
             AND S.ITEM_CODE = BI.ITEM_CODE
             AND S.ENTITY_ID = BI.ENTITY_ID
             AND A.ENTITY_ID = P_ENTITY_ID
             AND A.ITEM_CODE = R_GET_ITEM.ITEM_CODE
             AND A.ACTIVE_FLAG = 'Y'
             AND S.ACTIVE_FLAG = 'Y'
             AND BI.ACTIVE_FLAG = 'Y'
           UNION ALL
           SELECT BI.ITEM_CODE, BI.ITEM_NAME
             FROM T_BD_ITEM BI
            WHERE BI.ITEM_CODE = R_GET_ITEM.ITEM_CODE
              AND BI.ENTITY_ID = P_ENTITY_ID
              AND NOT EXISTS (SELECT 1 FROM T_BD_ITEM_ASSEMBLIES A
                               WHERE A.ENTITY_ID = BI.ENTITY_ID
                                 AND A.ITEM_CODE = BI.ITEM_CODE
                                 AND A.ACTIVE_FLAG = 'Y')
          ) LOOP
          V_ERP_COST_RESULT := PKG_PLN_PUB.F_CHK_ERP_STANDARD_COST(V_ORGANIZATION_ID, R_ITEM.ITEM_CODE);
          
          --没有成本
          IF V_ERP_COST_RESULT = 0 THEN
            P_RESULT := '失败：校验产品ERP标准成本！'|| v_Nl ||
                        '产品在ERP侧(组织：'|| V_ORGANIZATION_NAME ||')失效或者未维护冻结成本，请在ERP中维护产品的标准成本' || v_Nl ||
                        '产品：' || R_ITEM.ITEM_CODE || ' ' || R_ITEM.ITEM_NAME;
            Raise v_Base_Exception;
          END IF;
        END LOOP;
      END LOOP;
      CLOSE V_GET_ITEM;
      
    end if;
     
    --获取供方OU
    PKG_SO_INTF.P_SO_CUST_OU_INFO(P_ENTITY_ID       => P_ENTITY_ID,
                                  P_SALES_CENTER_ID => P_SALES_CENTER_ID,
                                  P_INV_ID          => P_INVENTORY_ID,
                                  P_IS_MATERIAL     => V_IS_MATERIAL,
                                  P_OU_ID           => V_SUPPLY_OU_ID,
                                  P_OU_NAME         => V_SUPPLY_OU_NAME,
                                  P_RESULT          => V_ERR_NUM,
                                  P_ERR_MSG         => P_RESULT);
    IF V_ERR_NUM <> 0 THEN
      P_RESULT := '失败：获取供方OU！'|| v_Nl ||
                  '中心：' || V_SALES_CENTER_CODE || ' ' || V_SALES_CENTER_NAME || v_Nl ||
                  '仓库：' || V_INVENTORY_CODE || ' ' || V_INVENTORY_NAME || v_Nl ||
                  '系统提示：' || P_RESULT;
      Raise v_Base_Exception;
    END IF;
    
    IF V_ORDER_TYPE_CHK_COST_FLAG = 'Y' THEN
	    --获取中心编码和名称
	    BEGIN
	      SELECT U.CODE, U.NAME
	        INTO V_SALES_CENTER_CODE, V_SALES_CENTER_NAME
	        FROM UP_ORG_UNIT U
	       WHERE U.UNIT_ID = P_SALES_CENTER_ID;
	    EXCEPTION
	      WHEN OTHERS THEN
	        P_RESULT := '获取中心信息失败，请检查中心是否存在。中心ID：' || TO_CHAR(P_SALES_CENTER_ID);
	        RAISE v_Base_Exception;
	    END;
	    
	    --获取客户编码和名称
	    BEGIN
	      SELECT H.CUSTOMER_CODE, H.CUSTOMER_NAME
	        INTO V_CUSTOMER_CODE, V_CUSTOMER_NAME
	        FROM T_CUSTOMER_HEADER H
	       WHERE H.CUSTOMER_ID = P_CUSTOMER_ID;
	    EXCEPTION
	      WHEN OTHERS THEN
	        P_RESULT := '获取客户信息失败，请检查客户是否存在。客户ID：' || TO_CHAR(P_CUSTOMER_ID);
	        RAISE v_Base_Exception;
	    END;
	    
	    --获取账户编码
	    BEGIN
	      SELECT A.ACCOUNT_CODE
	        INTO V_ACCOUNT_CODE
	        FROM T_CUSTOMER_ACCOUNT A
	       WHERE A.ACCOUNT_ID = P_ACCOUNT_ID;
	    EXCEPTION
	      WHEN OTHERS THEN
	        P_RESULT := '获取账户信息失败，请检查账户是否存在。账户ID：' || TO_CHAR(P_ACCOUNT_ID);
	        RAISE v_Base_Exception;
	    END;
	    
	    /*--获取仓库编码和名称
	    BEGIN
	      SELECT I.INVENTORY_CODE, I.INVENTORY_NAME
	        INTO V_INVENTORY_CODE, V_INVENTORY_NAME
	        FROM T_INV_INVENTORIES I
	       WHERE I.INVENTORY_ID = P_INVENTORY_ID;
	    EXCEPTION
	      WHEN OTHERS THEN
	        P_RESULT := '获取仓库信息失败，请检查仓库是否存在。仓库ID：' || TO_CHAR(P_INVENTORY_ID);
	        RAISE v_Base_Exception;
	    END;*/
	    
	    --检查是否内部户
	    pkg_so_intf.P_SO_ENTITY_CUST_INFO(P_ENTITY_ID        => P_ENTITY_ID,
	                                      P_CUSTOMER_ID      => P_CUSTOMER_ID,
	                                      P_ACCOUNT_ID       => P_ACCOUNT_ID,
	                                      P_SALES_CENTER_ID  => P_SALES_CENTER_ID,
	                                      P_INV_ID           => P_INVENTORY_ID,
	                                      P_CUST_CHECK_FLAG  => V_CUST_CHECK_FLAG,
	                                      P_CUST_CHECK_MSG   => V_CUST_CHECK_MSG,
	                                      P_ENTITY_CUST_FLAG => V_ENTITY_CUST_FLAG,
	                                      P_RESULT           => V_ERR_NUM,
	                                      P_ERR_MSG          => P_RESULT);
	    IF V_ERR_NUM <> 0 THEN
	      P_RESULT := '失败：校验客户账户资料！'|| v_Nl ||
	                  '客户：' || V_CUSTOMER_CODE || ' ' || V_CUSTOMER_NAME || v_Nl ||
	                  '账户：' || V_ACCOUNT_CODE || v_Nl ||
	                  '仓库：' || V_INVENTORY_CODE || ' ' || V_INVENTORY_NAME || v_Nl ||
	                  '系统提示：' || P_RESULT;
	      Raise v_Base_Exception;
	    ELSE
	      IF V_CUST_CHECK_FLAG = 'N' THEN
	        P_RESULT := '失败：校验客户账户有效性！'|| v_Nl ||
	                   '客户：' || V_CUSTOMER_CODE || ' ' || V_CUSTOMER_NAME || v_Nl ||
	                   '账户：' || V_ACCOUNT_CODE || v_Nl ||
	                   '系统提示：' || V_CUST_CHECK_MSG;
	        Raise v_Base_Exception;
	      END IF;
	          
	      --内部客户检查ERP标准成本
	      IF V_ENTITY_CUST_FLAG = 'Y' THEN
	        /*--获取是否检查ERP成本参数
	        Begin
	          V_ENTITY_CHK_COST_FLAG := Pkg_Bd.f_Get_Parameter_Value('inv_erp_item_cost',
	                                                                 P_ENTITY_ID);
	        Exception
	          When Others Then
	            P_RESULT := '获取主体参数失败，主体参数编码【inv_erp_item_cost】！' || v_Nl || Sqlerrm;
	            Raise v_Base_Exception;
	        End;*/
	          
	        --获取供方OU
	        /*PKG_SO_INTF.P_SO_CUST_OU_INFO(P_ENTITY_ID       => P_ENTITY_ID,
	                                      P_SALES_CENTER_ID => P_SALES_CENTER_ID,
	                                      P_INV_ID          => P_INVENTORY_ID,
	                                      P_IS_MATERIAL     => V_IS_MATERIAL,
	                                      P_OU_ID           => V_SUPPLY_OU_ID,
	                                      P_OU_NAME         => V_SUPPLY_OU_NAME,
	                                      P_RESULT          => V_ERR_NUM,
	                                      P_ERR_MSG         => P_RESULT);
	        IF V_ERR_NUM <> 0 THEN
	          P_RESULT := '失败：获取供方OU！'|| v_Nl ||
	                      '中心：' || V_SALES_CENTER_CODE || ' ' || V_SALES_CENTER_NAME || v_Nl ||
	                      '仓库：' || V_INVENTORY_CODE || ' ' || V_INVENTORY_NAME || v_Nl ||
	                      '系统提示：' || P_RESULT;
	          Raise v_Base_Exception;
	        END IF;*/
	            
	        --获取事业部供需关系配置
	        BEGIN
	          SELECT E.*
	            INTO V_SUPPER_REQ
	            FROM T_SO_SUPPLIER_REQUIRE_ENTITY E
	           WHERE E.SUPPLIER_ENTITY_ID = P_ENTITY_ID
	             AND E.REQUIREMENT_CUSTOMER_ID = P_CUSTOMER_ID
	             AND E.SUPPLIER_OU_ID = V_SUPPLY_OU_ID;
	        EXCEPTION
	          WHEN NO_DATA_FOUND THEN
	            P_RESULT := '失败：获取事业部供需关系配置！'|| v_Nl ||
	                        '需方客户：' || V_CUSTOMER_CODE || ' ' || V_CUSTOMER_NAME || v_Nl ||
	                        '供方OU：' || V_SUPPLY_OU_NAME || v_Nl ||
	                        '系统提示：没有维护事业部供需关系';
	            Raise v_Base_Exception;
	          WHEN TOO_MANY_ROWS THEN
	            P_RESULT := '失败：获取事业部供需关系配置！'|| v_Nl ||
	                        '需方客户：' || V_CUSTOMER_CODE || ' ' || V_CUSTOMER_NAME || v_Nl ||
	                        '供方OU：' || V_SUPPLY_OU_NAME || v_Nl ||
	                        '系统提示：存在多个事业部供需关系';
	            Raise v_Base_Exception;
	        END;
	        
	        --主体需检查且订单类型需检查才做检查
	        IF V_SUPPER_REQ.ICP_LG_RECEIVE_MODE IN (1, 2) --内部关联交易才做检查
	        THEN
	          BEGIN
	            SELECT R_VENDOR_ID, R_VENDOR_SITE_ID
	              INTO V_VENDOR_ID, V_VENDOR_SITE_ID
	              FROM APPS.CUX_ICP_BUSINESS_ALL@MDIMS2MDERP
	             WHERE R_VENDOR_NUM = V_SUPPER_REQ.SUPPLIER_VENDOR_CODE
	               AND SUPPLIER_SYSTEM = 'GERP'
	               AND REQUIREMENT_SYSTEM = 'GERP'
	               AND R_ORG_ID = V_SUPPER_REQ.REQUIREMENT_OU_ID
	               AND NVL(DISABLE_DATE, SYSDATE + 1) > SYSDATE;
	          EXCEPTION
	            WHEN OTHERS THEN
	              P_RESULT := '失败：获取需方ERP中供应商ID以及供应商地点报错！请在需方ERP中维护供应商信息' || V_NL ||
	                          '供应商：' || V_SUPPER_REQ.SUPPLIER_VENDOR_CODE || ' ' || V_SUPPER_REQ.SUPPLIER_OU_NAME || V_NL ||
	                          '需方OU：' || V_SUPPER_REQ.REQUIREMENT_OU_NAME || V_NL ||
	                          SQLERRM;
	              RAISE V_BASE_EXCEPTION;
	          END;
	
	          OPEN V_GET_ITEM FOR 'SELECT * FROM T_BD_ITEM I WHERE I.ITEM_ID IN (' || P_ITEM_ID_LIST || ')';
	          LOOP
	            FETCH V_GET_ITEM INTO R_GET_ITEM;
	            EXIT WHEN V_GET_ITEM%NOTFOUND;
	            
              FOR R_SUB IN (
                SELECT 'Y' ASS_ITEM_FLAG,
                       BI.*
                  FROM T_BD_ITEM_ASSEMBLIES A,
                       T_BD_ITEM_ASSEMBLIES_SUB S,
                       T_BD_ITEM BI
                 WHERE A.ITEM_ASSEMBLY_ID = S.ITEM_ASSEMBLY_ID
                   AND S.ITEM_CODE = BI.ITEM_CODE
                   AND S.ENTITY_ID = BI.ENTITY_ID
                   AND A.ENTITY_ID = P_ENTITY_ID
                   AND A.ITEM_CODE = R_GET_ITEM.ITEM_CODE
                   AND A.ACTIVE_FLAG = 'Y'
                   AND S.ACTIVE_FLAG = 'Y'
                   AND BI.ACTIVE_FLAG = 'Y'
                 UNION ALL
                 SELECT 'N' ASS_ITEM_FLAG,
                        BI.*
                   FROM T_BD_ITEM BI
                  WHERE BI.ITEM_CODE = R_GET_ITEM.ITEM_CODE
                    AND BI.ENTITY_ID = P_ENTITY_ID
                    AND NOT EXISTS (SELECT 1 FROM T_BD_ITEM_ASSEMBLIES A
                                     WHERE A.ITEM_CODE = BI.ITEM_CODE
                                       AND A.ENTITY_ID = BI.ENTITY_ID
                                       AND A.ACTIVE_FLAG = 'Y')
                ) LOOP
                --检查批准供应商产品
                BEGIN
                  SELECT '校验批准供应商有效产品' INTO P_RESULT
                    FROM APPS.MTL_SYSTEM_ITEMS@MDIMS2MDERP MI
                   WHERE MI.MUST_USE_APPROVED_VENDOR_FLAG = 'Y'
                     AND MI.SEGMENT1 = R_SUB.ITEM_CODE--R_GET_ITEM.ITEM_CODE
                     AND MI.ORGANIZATION_ID = V_SUPPER_REQ.REQUIREMENT_ORGANIZATION_ID
                     AND NOT EXISTS (SELECT 1
                            FROM APPS.PO_APPROVED_SUPPLIER_LIST@MDIMS2MDERP M
                           WHERE M.ITEM_ID = MI.INVENTORY_ITEM_ID
                             AND NVL(M.DISABLE_FLAG, 'N') = 'N'
                             AND M.VENDOR_ID = V_VENDOR_ID
                             AND (M.USING_ORGANIZATION_ID = -1 OR
                                 M.VENDOR_SITE_ID = V_VENDOR_SITE_ID));
  	              
                  P_RESULT := '失败：校验批准供应商有效产品(散件)失败！请在ERP中维护相关产品的批准供应商'|| v_Nl ||
                              '组织：'|| V_SUPPER_REQ.REQUIREMENT_ORGANIZATION_NAME || v_Nl ||
                              '供应商：' || V_SUPPER_REQ.SUPPLIER_VENDOR_CODE || ' ' || V_SUPPER_REQ.SUPPLIER_OU_NAME || v_Nl ||
                              '散件产品：' || R_SUB.ITEM_CODE || ' ' || R_SUB.ITEM_NAME || v_Nl ||
                              '套件产品：' || R_GET_ITEM.ITEM_CODE || ' ' || R_GET_ITEM.ITEM_NAME;
                  Raise v_Base_Exception;
                EXCEPTION
                WHEN NO_DATA_FOUND THEN
                    P_RESULT := v_Success; --没数据表示已维护
                END;
  	            
                --检查标准成本
                IF V_ENTITY_CHK_COST_FLAG = 'Y' AND V_ORDER_TYPE_CHK_COST_FLAG = 'Y' THEN
	              BEGIN
	                SELECT '校验产品ERP标准成本' INTO P_RESULT
	                  FROM T_BD_ITEM BI
	                 WHERE BI.ENTITY_ID = P_ENTITY_ID
	                   AND BI.ITEM_ID = R_SUB.ITEM_ID--R_GET_ITEM.ITEM_ID
	                   AND NOT EXISTS (SELECT 1
	                        FROM APPS.MTL_SYSTEM_ITEMS@MDIMS2MDERP M,
	                             APPS.CST_ITEM_COSTS@MDIMS2MDERP   CIC
	                       WHERE M.ORGANIZATION_ID = V_SUPPER_REQ.REQUIREMENT_ORGANIZATION_ID --需方组织ID
	                         AND M.SEGMENT1 = BI.ITEM_CODE
	                         AND NVL(M.CUSTOMER_ORDER_ENABLED_FLAG, 'N') = 'Y'
	                         AND NVL(M.CUSTOMER_ORDER_FLAG, 'N') = 'Y'
	                         AND NVL(M.SHIPPABLE_ITEM_FLAG, 'N') = 'Y'
	                         AND NVL(M.SO_TRANSACTIONS_FLAG, 'N') = 'Y'
	                         AND NVL(M.RETURNABLE_FLAG, 'N') = 'Y'
	                         AND M.ATP_COMPONENTS_FLAG = 'N'
	                         AND M.ATP_FLAG = 'N'
	                         AND M.INVENTORY_ITEM_STATUS_CODE != 'Inactive'
	                         AND CIC.INVENTORY_ITEM_ID = M.INVENTORY_ITEM_ID
	                         AND CIC.ORGANIZATION_ID = M.ORGANIZATION_ID
	                         AND CIC.COST_TYPE_ID = 1
	                         AND CIC.ITEM_COST <> 0);
	                             
	                P_RESULT := '失败：校验散件产品ERP标准成本！'|| v_Nl ||
	                            '散件产品在ERP侧(组织：'|| V_SUPPER_REQ.REQUIREMENT_ORGANIZATION_NAME ||')失效或者未维护冻结成本，请在ERP维护产品的标准成本' || v_Nl ||
	                            '散件产品：' || R_SUB.ITEM_CODE || ' ' || R_SUB.ITEM_NAME || v_Nl ||
                              '套件产品：' || R_GET_ITEM.ITEM_CODE || ' ' || R_GET_ITEM.ITEM_NAME;
	                Raise v_Base_Exception;
	              EXCEPTION
                WHEN NO_DATA_FOUND THEN
	                  P_RESULT := v_Success; --没数据表示已经维护标准成本
	              END;
	            END IF;
              
                --hejy3 校验散件价格
                if (R_SUB.Ass_Item_Flag = 'Y' AND IN_BUSINESS_TYPE = 'WP') OR NVL(IN_BUSINESS_TYPE, '_') <> 'WP' THEN
                  Begin
                    Pkg_Bd_Price.p_Get_Price(p_Acc_Id         => P_ACCOUNT_ID,
                                             p_Item_Code      => R_SUB.ITEM_CODE,
                                             p_Bill_Date      => To_Char(Sysdate, 'yyyymmdd'),
                                             p_Price_List_Id  => Null,
                                             p_Entity_Id      => P_ENTITY_ID,
                                             p_Price          => v_Item_Price,
                                             p_Discount       => v_Discount,
                                             p_Month_Discount => v_Month_Discount,
                                             p_Cx_Flag        => v_Cx_Flag);
                  Exception
                    When Others Then
                      v_Item_Price     := Null;
                      v_Discount       := 0;
                      v_Month_Discount := 0;
                      v_Cx_Flag        := 'N';
                  End;
                
                
                  if v_Item_Price is null then
                    P_RESULT := '失败：校验散件产品价格！'|| v_Nl ||
                                '散件产品未维护有效销售价格，请在价格管理中维护散件产品销售价格' || v_Nl ||
                                '散件产品：' || R_SUB.ITEM_CODE || ' ' || R_SUB.ITEM_NAME || v_Nl ||
                                '套件产品：' || R_GET_ITEM.ITEM_CODE || ' ' || R_GET_ITEM.ITEM_NAME;
                    Raise v_Base_Exception;
                  end if;
                END IF;
	            END LOOP;
            END LOOP;
	          CLOSE V_GET_ITEM;
	          
	          --校验批准供应商
	          
	        END IF;
	      END IF;
	    END IF;
    END IF;
  EXCEPTION
    WHEN v_Base_Exception THEN
      P_RESULT := '下达校验客户账户、标准成本、批准供应商' || v_Nl || P_RESULT;
    WHEN OTHERS THEN
      P_RESULT := '下达校验客户账户、标准成本、批准供应商' || v_Nl || P_RESULT || v_Nl || Sqlerrm;
  END;
  -----------------------------------------------------------------------------
  -- AUTHOR  : ex_dengjh
  -- CREATED : 2017-4-1
  -- PURPOSE : a．	按照主体ID，中心ID，产品编码获取总部月度分配量表的剩余分配量（总分配量-已占用分配量）
  -- Modify : 张开安，添加大小类分配，根据产品找到相应的大小类
  -----------------------------------------------------------------------------
  function F_GET_ITEM_MONTH_ASSIGN_QTY(IN_ENTITY_ID       in NUMBER, --主体ID
                                       IN_SALES_CENTER_ID in NUMBER, --中心ID
                                       IN_CUSTOMER_ID     IN NUMBER, --客户ID
                                       IN_ITEM_ID         in NUMBER --产品ID
                                       ) return number is
  
    v_qty                         number;
    v_Pln_Capacity_Advance_Period Number;
    v_Check_Date                  Date;
  Begin
    --add by lizhen 2017-09-06
    --获取系统参数产能可视订单周期提前期设置
    Begin
      v_Pln_Capacity_Advance_Period := Pkg_Bd.f_Get_Parameter_Value('PLN_CAPACITY_ADVANCE_PERIOD',
                                                                    IN_ENTITY_ID);
    Exception
      When Others Then
        v_Pln_Capacity_Advance_Period := 0;
    End;
    If v_Pln_Capacity_Advance_Period = 0 Then
      v_Check_Date := Trunc(Sysdate);
    Else
      Select Op.Begin_Date
        Into v_Check_Date
        From t_Pln_Order_Period Op
       Where Op.Period_Id =
             Pkg_Pln_Capacity.f_Get_Parameter_Month_Period(p_Entity_Id   => In_Entity_Id,
                                                           p_Period_Type => 'W',
                                                           p_Date        => Trunc(Sysdate));
    End If;
    --先检查总部是否有给中心分配量
    BEGIN
      SELECT A.ASSIGN_QTY
        INTO v_qty
        FROM T_PLN_HQ_MONTH_ASSIGN A
       WHERE A.ENTITY_ID = IN_ENTITY_ID
         AND A.SALES_CENTER_ID = IN_SALES_CENTER_ID
         AND A.ITEM_ID = IN_ITEM_ID
         AND A.CUSTOMER_ID IS NULL --客户ID为空
         AND v_Check_Date BETWEEN A.PERIOD_BEGIN_DATE AND A.PERIOD_END_DATE;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        v_qty := -1;
    END;
    -- 张开安 2018-05-03 对小类分配，没分配具体的产品
    BEGIN
      IF NVL(v_qty, -1) = -1 THEN
        SELECT A.ASSIGN_QTY
          INTO v_qty
          FROM T_PLN_HQ_MONTH_ASSIGN A
         WHERE A.ENTITY_ID = IN_ENTITY_ID
           AND A.SALES_CENTER_ID = IN_SALES_CENTER_ID
           AND A.ITEM_ID IS NULL
           AND EXISTS (SELECT 1
                  FROM t_bd_item bi
                 WHERE bi.active_flag = 'Y'
                   AND bi.entity_id = a.entity_id
                   AND bi.sales_main_type = a.sales_main_type
                   AND bi.sales_sub_type = a.sales_sub_type
                   AND bi.item_id = IN_ITEM_ID)
           AND A.CUSTOMER_ID IS NULL --客户ID为空
           AND v_Check_Date BETWEEN A.PERIOD_BEGIN_DATE AND
               A.PERIOD_END_DATE;
      END IF;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        v_qty := -1;
    END;
    -- 张开安 2018-05-03 对大类分配，没分配具体的小类、产品
    BEGIN
      IF NVL(v_qty, -1) = -1 THEN
        SELECT A.ASSIGN_QTY
          INTO v_qty
          FROM T_PLN_HQ_MONTH_ASSIGN A
         WHERE A.ENTITY_ID = IN_ENTITY_ID
           AND A.SALES_CENTER_ID = IN_SALES_CENTER_ID
           AND A.ITEM_ID IS NULL
           AND A.SALES_SUB_TYPE IS NULL
           AND EXISTS (SELECT 1
                  FROM t_bd_item bi
                 WHERE bi.active_flag = 'Y'
                   AND bi.entity_id = a.entity_id
                   AND bi.sales_main_type = a.sales_main_type
                   AND bi.item_id = IN_ITEM_ID)
           AND A.CUSTOMER_ID IS NULL --客户ID为空
           AND v_Check_Date BETWEEN A.PERIOD_BEGIN_DATE AND
               A.PERIOD_END_DATE;
      END IF;
    
      BEGIN
        SELECT A.ASSIGN_QTY - A.OCCUPY_QTY
          into v_qty
          FROM T_PLN_HQ_MONTH_ASSIGN A
         WHERE A.ENTITY_ID = IN_ENTITY_ID
           AND A.SALES_CENTER_ID = IN_SALES_CENTER_ID
           AND A.ITEM_ID = IN_ITEM_ID
           AND A.CUSTOMER_ID = IN_CUSTOMER_ID
           AND v_Check_Date BETWEEN A.PERIOD_BEGIN_DATE AND
               A.PERIOD_END_DATE;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          v_qty := 0;
      END;
    
      -- 张开安 2018-05-03 对小类分配，没分配具体的产品
      BEGIN
        IF NVL(v_qty, 0) = 0 THEN
          SELECT A.ASSIGN_QTY - A.OCCUPY_QTY
            INTO v_qty
            FROM T_PLN_HQ_MONTH_ASSIGN A
           WHERE A.ENTITY_ID = IN_ENTITY_ID
             AND A.SALES_CENTER_ID = IN_SALES_CENTER_ID
             AND A.ITEM_ID IS NULL
             AND EXISTS (SELECT 1
                    FROM t_bd_item bi
                   WHERE bi.active_flag = 'Y'
                     AND bi.entity_id = a.entity_id
                     AND bi.sales_main_type = a.sales_main_type
                     AND bi.sales_sub_type = a.sales_sub_type
                     AND bi.item_id = IN_ITEM_ID)
             AND A.CUSTOMER_ID = IN_CUSTOMER_ID
             AND v_Check_Date BETWEEN A.PERIOD_BEGIN_DATE AND
                 A.PERIOD_END_DATE;
        END IF;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          v_qty := 0;
      END;
      -- 张开安 2018-05-03 对大类分配，没分配具体的小类、产品
      BEGIN
        IF NVL(v_qty, 0) = 0 THEN
          SELECT A.ASSIGN_QTY - A.OCCUPY_QTY
            INTO v_qty
            FROM T_PLN_HQ_MONTH_ASSIGN A
           WHERE A.ENTITY_ID = IN_ENTITY_ID
             AND A.SALES_CENTER_ID = IN_SALES_CENTER_ID
             AND A.ITEM_ID IS NULL
             AND A.SALES_SUB_TYPE IS NULL
             AND EXISTS (SELECT 1
                    FROM t_bd_item bi
                   WHERE bi.active_flag = 'Y'
                     AND bi.entity_id = a.entity_id
                     AND bi.sales_main_type = a.sales_main_type
                     AND bi.item_id = IN_ITEM_ID)
             AND A.CUSTOMER_ID = IN_CUSTOMER_ID
             AND v_Check_Date BETWEEN A.PERIOD_BEGIN_DATE AND
                 A.PERIOD_END_DATE;
        END IF;
      
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          v_qty := 0;
      END;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        v_qty := 9999999999;
    END;
     return v_qty;
  exception
    when others then
      return 0;
  end;
  -----------------------------------------------------------------------------
  -- AUTHOR  : ex_dengjh
  -- CREATED : 2017-4-11
  -- PURPOSE : 按照传入主体、中心、产品、日期获取提货订单占用量
  -- Modify : 张开安，添加大小类分配，根据产品找到相应的大小类
  -----------------------------------------------------------------------------
  function F_GET_OCCUPY_ASSIGN_QTY(IN_ENTITY_ID       in NUMBER, --主体ID
                                   IN_SALES_CENTER_ID in NUMBER, --中心ID
                                   IN_CUSTOMER_ID     IN NUMBER, --客户ID
                                   IN_ITEM_ID         in NUMBER, --产品编码
                                   IN_SALES_MAIN_TYPE IN VARCHAR2, --大类，张开安2018-05-03添加
                                   IN_SALES_SUB_TYPE  IN VARCHAR2, --小类，张开安2018-05-03添加
                                   IN_BEGIN_DATE      in DATE, --期间起始日期
                                   IN_END_DATE        in DATE --期间结束日期
                                   ) return number is
    v_qty number;
  begin
    -- 张开安 2018-05-03 增加大小类分配，产品可以为空
    IF NVL(IN_ITEM_ID, 0) > 0 THEN
      SELECT SUM(/*CASE
                   WHEN H.ORDER_HEAD_STATE IN ('20', '2225', '1455') THEN
                    L.QUANTITY
                   WHEN H.ORDER_HEAD_STATE IN ('679', '381') THEN
                    NVL(L.CENTER_AFFIRM_QUANTITY, L.QUANTITY) -
                    NVL(L.CANCEL_QTY, 0)
                   WHEN H.ORDER_HEAD_STATE IN ('23', '304') THEN
                    NVL(L.AFFIRMED_QUANTITY, 0)
                   ELSE
                    0
                 END*/NVL(L.OCCUPY_ASSIGN_QTY, 0)) OCCUPY_QTY
        into v_qty
        FROM T_PLN_LG_ORDER_HEAD H, T_PLN_LG_ORDER_LINE L
       WHERE H.ORDER_HEAD_ID = L.ORDER_HEAD_ID
         AND H.ORDER_HEAD_STATE IN
             ('20', '2225', '1455', '679', '381', '23', '304') --已送审、中心发货、已中心评审、部分评审、评审完毕、已关闭
         AND H.ENTITY_ID = IN_ENTITY_ID
         AND H.SALES_CENTER_ID = IN_SALES_CENTER_ID
         AND H.CUSTOMER_ID = IN_CUSTOMER_ID
         AND L.ITEM_ID = IN_ITEM_ID
         AND H.TO_CHECKUP_DATE BETWEEN IN_BEGIN_DATE AND IN_END_DATE + 1
         AND EXISTS (SELECT 1
                FROM T_PLN_ORDER_TYPE T
               WHERE T.ORDER_TYPE_ID = H.ORDER_TYPE_ID
                 AND T.SOURCE_ORDER_TYPE_ID = 1 --提货订单
                 AND UPPER(NVL(T.IS_BUSINESS_CONTROL, '_')) NOT IN
                     ('PRO_ORDER', 'SC_LG_ORDER')); --非推广物料
      return nvl(v_qty, 0);
    END IF;
    -- 张开安 2018-05-03 产品为空，大小类都有值
    IF IN_SALES_SUB_TYPE IS NOT NULL THEN
      SELECT SUM(NVL(L.OCCUPY_ASSIGN_QTY, 0)) OCCUPY_QTY
        INTO v_qty
        FROM T_PLN_LG_ORDER_HEAD H, T_PLN_LG_ORDER_LINE L
       WHERE H.ORDER_HEAD_ID = L.ORDER_HEAD_ID
         AND H.ORDER_HEAD_STATE IN
             ('20', '2225', '1455', '679', '381', '23', '304') --已送审、中心发货、已中心评审、部分评审、评审完毕、已关闭
         AND H.ENTITY_ID = IN_ENTITY_ID
         AND H.SALES_CENTER_ID = IN_SALES_CENTER_ID
         AND H.CUSTOMER_ID = IN_CUSTOMER_ID
         AND EXISTS (SELECT 1
                FROM t_bd_item bi
               WHERE bi.active_flag = 'Y'
                 AND bi.entity_id = h.entity_id
                 AND bi.item_id = l.item_id
                 AND bi.sales_main_type = IN_SALES_MAIN_TYPE
                 AND bi.sales_sub_type = IN_SALES_SUB_TYPE)
         AND H.TO_CHECKUP_DATE BETWEEN IN_BEGIN_DATE AND IN_END_DATE + 1
         AND EXISTS (SELECT 1
                FROM T_PLN_ORDER_TYPE T
               WHERE T.ORDER_TYPE_ID = H.ORDER_TYPE_ID
                 AND T.SOURCE_ORDER_TYPE_ID = 1 --提货订单
                 AND UPPER(NVL(T.IS_BUSINESS_CONTROL, '_')) NOT IN
                     ('PRO_ORDER', 'SC_LG_ORDER')); --非推广物料
      return nvl(v_qty, 0);
    ELSE
      -- 张开安 2018-05-03 产品为空，小类为空，大类有值
      SELECT SUM(NVL(L.OCCUPY_ASSIGN_QTY, 0)) OCCUPY_QTY
        INTO v_qty
        FROM T_PLN_LG_ORDER_HEAD H, T_PLN_LG_ORDER_LINE L
       WHERE H.ORDER_HEAD_ID = L.ORDER_HEAD_ID
         AND H.ORDER_HEAD_STATE IN
             ('20', '2225', '1455', '679', '381', '23', '304') --已送审、中心发货、已中心评审、部分评审、评审完毕、已关闭
         AND H.ENTITY_ID = IN_ENTITY_ID
         AND H.SALES_CENTER_ID = IN_SALES_CENTER_ID
         AND H.CUSTOMER_ID = IN_CUSTOMER_ID
         AND EXISTS (SELECT 1
                FROM t_bd_item bi
               WHERE bi.active_flag = 'Y'
                 AND bi.entity_id = h.entity_id
                 AND bi.item_id = l.item_id
                 AND bi.sales_main_type = IN_SALES_MAIN_TYPE)
         AND H.TO_CHECKUP_DATE BETWEEN IN_BEGIN_DATE AND IN_END_DATE + 1
         AND EXISTS (SELECT 1
                FROM T_PLN_ORDER_TYPE T
               WHERE T.ORDER_TYPE_ID = H.ORDER_TYPE_ID
                 AND T.SOURCE_ORDER_TYPE_ID = 1 --提货订单
                 AND UPPER(NVL(T.IS_BUSINESS_CONTROL, '_')) NOT IN
                     ('PRO_ORDER', 'SC_LG_ORDER')); --非推广物料
      return nvl(v_qty, 0);
    END IF;
  exception
    when no_data_found then
      return 0;
  end;
  
  -----------------------------------------------------------------------------
  -- AUTHOR  : tanjz2
  -- CREATED : 2017-04-11
  -- PURPOSE : 校验定时是否满足齐套
  -----------------------------------------------------------------------------
  PROCEDURE P_CHK_CARLOADMEET(P_ORDER_HEAD_ID IN NUMBER, --订单ID
                              P_RESULT          OUT VARCHAR2 --返回信息，成功返回'SUCCESS'，否则返回错误信息
                              )
  is
  v_entity_id number;--主体
  v_standard_square number;--平方倍数
  v_standard_square_up number;--可上浮方数
  v_standard_square_dn number;--可下浮方数
  v_standard_square_char VARCHAR2(10);--平方倍数
  v_standard_square_up_char VARCHAR2(10);--可上浮方数
  v_standard_square_dn_char VARCHAR2(10);--可下浮方数
  v_total_volume number;--总体积
  v_item t_bd_item%rowtype;--产品
  v_remainder number;--余数
  begin
    --获取主体
    select h.entity_id into v_entity_id from t_pln_lg_order_head h where h.order_head_id = P_ORDER_HEAD_ID;
    --获取系统参数
    PKG_BD.P_GET_PARAMETER_VALUE('CARLOAD_STANDARD_SQUARE', v_entity_id, null, null, v_standard_square_char);
    PKG_BD.P_GET_PARAMETER_VALUE('CARLOAD_STANDARD_SQUARE_UP', v_entity_id, null, null, v_standard_square_up_char);
    PKG_BD.P_GET_PARAMETER_VALUE('CARLOAD_STANDARD_SQUARE_DN', v_entity_id, null, null, v_standard_square_dn_char);
    if v_standard_square_char is null then
      P_RESULT := '未配置系统参数CARLOAD_STANDARD_SQUARE，主体：'||v_entity_id;
      return;
    end if;
    if v_standard_square_up_char is null then
      P_RESULT := '未配置系统参数CARLOAD_STANDARD_SQUARE_UP，主体：'||v_entity_id;
      return;
    end if;
    if v_standard_square_dn_char is null then
      P_RESULT := '未配置系统参数CARLOAD_STANDARD_SQUARE_DN，主体：'||v_entity_id;
      return;
    end if;
    v_standard_square := to_number(v_standard_square_char, '9999999999');
    v_standard_square_up := to_number(v_standard_square_up_char, '9999999999');
    v_standard_square_dn := to_number(v_standard_square_dn_char, '9999999999');
    
    --计算总体积
    v_total_volume := 0;
    for cur_order_line in (select * from t_pln_lg_order_line l where l.order_head_id = P_ORDER_HEAD_ID) loop
      select nvl(i.packingsize,0) into v_item.packingsize from t_bd_item i where i.item_id = cur_order_line.item_id;
      if v_item.packingsize = 0 then
        P_RESULT := '该产品没有体积数据，产品编码：'||cur_order_line.item_code;
        return;
      end if;
      v_total_volume := v_total_volume + cur_order_line.quantity * v_item.packingsize;
    end loop;
    P_RESULT := '订单总方数不满足齐套标准';
    if v_total_volume >= v_standard_square - v_standard_square_dn then
      v_remainder := mod(v_total_volume, v_standard_square);
      if v_remainder <= v_standard_square_up or v_remainder >= v_standard_square - v_standard_square_dn then
        P_RESULT := 'SUCCESS';
      end if;
    end if;
  end;
  
  -----------------------------------------------------------------------------
  -- AUTHOR  : Nicro.Li
  -- CREATED : 2017-11-13
  -- PURPOSE : 提货订单为发货锁款时，加解锁销司订单客户款项，
  --   In_Lg_Line_Id值!= -1时，表示取消发货通知单并且解锁款项
  -----------------------------------------------------------------------------
  Procedure p_Upd_Transfer_Lg_Order(In_Lg_Order_Id In Number,  --总部提货订单头
                                    In_Lg_Line_Id  In Number,  --解锁款项时传入
                                    In_Qty         In Number, --当传入订单行ID为-1时，传入空值，否则传入发货通知单取消数量
                                    In_User_Code   In Varchar2,
                                    Out_Result     Out Varchar2, --处理结果，成功返回SUCCESS，否则返回错误信息
                                    IN_OPERATION_TYPE IN VARCHAR2 DEFAULT '评审', --处理类型
                                    IN_SKIP_LOCK   In Varchar2 DEFAULT 'N' -- 是否跳过锁款，默认为N add by houhs
                                    ) Is
    r_Lg_Order     t_Pln_Lg_Order_Head%Rowtype;
    v_Sc_Entity_Id                Number;
    v_Price_Apply_Use_Discount    Varchar2(60);
    v_Sc_Business_Control            Varchar2(60);
    v_Sc_Order_Type_Code          t_pln_order_type.order_type_code%Type;
    v_Sc_Order_Type_Id            t_pln_order_type.order_type_id%type;
    v_Sc_Account_Id               Number;
    v_Sc_Customer_Id              Number;
    v_Count                       Number;
    v_OS_ATTRIB01                 Varchar2(100);
    v_OS_ATTRIB02                 Varchar2(100);
    v_Action_Type                 Number;
    v_Transfer_Qty                Number;
    v_Sc_Lock_Amount_Flag            Varchar2(32);
    v_Hq_Affirm_Lock_Full_Amount t_bd_param_list.default_value%type := 'N';
    r_lg_ship_plan t_lg_ship_plan%rowtype;
    v_Log_Result   Varchar2(4000);
    v_Return_Msg varchar2(1000);
    v_Sc_Sys_Source t_pln_lg_order_head.sys_source%type; --来源主体单据来源系统
    v_Sc_Order_Head_Id t_pln_lg_order_head.source_order_id%type; --来源主体单据ID
    v_Sc_Direct_Send_Flag t_pln_lg_order_head.direct_send_flag%type; --来源主体单据来源单据直发标志
    v_Sc_Client_Carry_Flag t_pln_lg_order_head.client_carry_flag%type; --来源主体单据来源单据自提标志
    v_Sc_Order_Line_Id number; --来源主体订单来源订单行ID
    v_Sc_Customize_Flag t_pln_lg_order_head.customize_flag%type;
    V_ERR_NUM number;
  Begin
    Out_Result := v_Success;
	savepoint upTransfer;
    Begin
      Select *
        Into r_Lg_Order
        From t_Pln_Lg_Order_Head Oh
       Where Oh.Order_Head_Id = In_Lg_Order_Id;
    Exception
      When Others Then
        Out_Result := '【' || r_Lg_Order.Order_Type_Name || '】订单头锁定数据失败。' || v_Nl ||
                    Sqlerrm;
        Raise v_Base_Exception;
    End;
    --非发货锁款且来源不是CIMS的单据不处理锁款
    If Nvl(r_Lg_Order.Sys_Source, '_') != 'CIMS' Or Nvl(r_Lg_Order.Source_Order_Id, 0) = -1 Then
       Return;
    End If;
    
    Begin
      Select Loh.Entity_Id,
             Ot.Is_Business_Control,
             Ot.Order_Type_Code,
             loh.order_type_id,
             Loh.Account_Id,
             Loh.Customer_Id,
             nvl(Loh.Lock_Amount_Flag, ot.chk_cusg_amount_flag),
             Loh.Sys_Source,
             Loh.Order_Head_Id,
             Loh.Direct_Send_Flag,
             Loh.Client_Carry_Flag,
             loh.customize_flag
        Into v_Sc_Entity_Id,
             v_Sc_Business_Control,
             v_Sc_Order_Type_Code,
             v_Sc_Order_Type_Id,
             v_Sc_Account_Id,
             v_Sc_Customer_Id,
             v_Sc_Lock_Amount_Flag,
             v_Sc_Sys_Source,
             v_Sc_Order_Head_Id,
             v_Sc_Direct_Send_Flag,
             v_Sc_Client_Carry_Flag,
             v_Sc_Customize_Flag
        From t_Pln_Lg_Order_Head Loh, t_Pln_Order_Type Ot
       Where Loh.Order_Head_Id = r_Lg_Order.Source_Order_Id
         And Ot.Order_Type_Id = Loh.Order_Type_Id;
    Exception
      When Others Then
        Out_Result := '获取销司提货订单主体ID,单据类型失败！' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;
    
    --获取参数:销司订单总部评审锁全款
    Begin
      v_Hq_Affirm_Lock_Full_Amount := Pkg_Bd.f_Get_Parameter_Value('PLN_HQ_AFFIRM_LOCK_FULL_AMOUNT',
                                                         v_Sc_Entity_Id);
    Exception
      When Others Then
        OUT_RESULT := '获取销司订单总部评审锁全款参数PLN_HQ_AFFIRM_LOCK_FULL_AMOUNT参数失败！' || v_Nl ||
                      Sqlerrm;
        Raise v_Base_Exception;
    End;
    
    --销司提货订单非发货锁款时，不处理款项功能
    /*If Nvl(v_Lock_Amount_Flag, 'N') not in ('S', 'Y') Then
       Return;
    End If;*/
    v_Log_Result := substrb('02ID:'||to_char(r_Lg_Order.Source_Order_Id)||
                            '|HALFA:'||v_Hq_Affirm_Lock_Full_Amount||
                            '|LAF:'||v_Sc_Lock_Amount_Flag,1,4000);
    v_Log_Result := PKG_BD.F_ADD_ERROR_LOG(P_ERROR_FROM => 'Pkg_Pln_Pub.p_Upd_Transfer_Lg_Order',
                           P_ERROR_CODE => '-1',
                           P_ERROR_DESC => v_Log_Result);
    if v_Sc_Lock_Amount_Flag = V_LOCK_AMOUNT_FLAG_Y or
      (v_Sc_Lock_Amount_Flag = V_LOCK_AMOUNT_FLAG_S and v_Hq_Affirm_Lock_Full_Amount = 'Y') or
      v_Sc_Lock_Amount_Flag = V_LOCK_AMOUNT_FLAG_HQ or
      v_Sc_Customize_Flag = 'Y'
    then
    
    if IN_OPERATION_TYPE in ('送总部评审','驳回') and v_Sc_Lock_Amount_Flag <> V_LOCK_AMOUNT_FLAG_HQ then
      return;
    end if;

    Begin
      v_Price_Apply_Use_Discount := Pkg_Bd.f_Get_Parameter_Value('PLN_PRICE_APPLY_USE_DISCOUNT',
                                                          v_Sc_Entity_Id);
    Exception
      When Others Then
        v_Price_Apply_Use_Discount := 'N';
    End;
	
    --add by houhs 增加参数判断是否跳过锁款，自动直发直接跳过
    IF v_Sc_Customize_Flag = 'Y' AND IN_SKIP_LOCK = 'N' THEN
      --校验款项
      For r_Check_Amount In (--甲方
                             Select lol.entity_id,
                                    be.entity_name,
                                    h.customer_id,
                                    H.CUSTOMER_CODE,
                                    h.account_id,
                                    H.ACCOUNT_CODE,
                                    nvl(lol.sales_main_type, bi.sales_main_type) Sales_Main_Type,
                                    Nvl(Lol.Discount_Type, v_Discount_Type_Common) Discount_Type,
                                    Sum(Round(case
                                                when IN_OPERATION_TYPE = '评审' then
                                                  Nvl(Hqlol.Affirming_Qty, 0)
                                                else 0
                                              end
                                              * Decode(Lol.Project_Order_Type,
                                                   Null,
                                                   Nvl(Lol.List_Price, 0) * (100 - Nvl(Lol.Discount_Rate, 0) - Nvl(Lol.Ordered_Discount_Rate, 0)) / 100,
                                                   Nvl(Lol.Apply_List_Price, 0) *
                                                   (100 - decode(v_Price_Apply_Use_Discount, 'Y', nvl(Lol.Apply_Discount_Rate, 0), 0)
                                                     - Nvl(Lol.Ordered_Discount_Rate, 0)) / 100)
                                              * case
                                                  when lol.customize_flag = 'Y' then
                                                    0
                                                  when nvl(lol.customize_flag, 'N') = 'N' then
                                                    case
                                                      when v_Sc_Lock_Amount_Flag In (V_LOCK_AMOUNT_FLAG_S, V_LOCK_AMOUNT_FLAG_RS, V_LOCK_AMOUNT_FLAG_HQ) THEN
                                                        (100 - nvl(lol.down_pay_scale, 100)) / 100
                                                      when v_Sc_Lock_Amount_Flag in (V_LOCK_AMOUNT_FLAG_RT, V_LOCK_AMOUNT_FLAG_Y) THEN
                                                        1
                                                      else
                                                        0
                                                    end
                                                  else
                                                    0
                                                end,2)) apply_Amount,
                                    Sum(Round(case
                                                when IN_OPERATION_TYPE = '评审' then
                                                  Nvl(Hqlol.Affirming_Qty, 0)
                                                else 0
                                              end
                                              * Decode(Lol.Project_Order_Type,
                                                   Null,
                                                   Nvl(Lol.List_Price, 0) * Nvl(Lol.Discount_Rate, 0) / 100,
                                                   Nvl(Lol.Apply_List_Price, 0) *
                                                   decode(v_Price_Apply_Use_Discount, 'Y', nvl(Lol.Apply_Discount_Rate, 0), 0) / 100)
                                              *
                                              case
                                                when lol.customize_flag = 'Y' then
                                                  0
                                                when nvl(lol.customize_flag, 'N') = 'N' then
                                                  case
                                                    when v_Sc_Lock_Amount_Flag In (V_LOCK_AMOUNT_FLAG_S, V_LOCK_AMOUNT_FLAG_RS, V_LOCK_AMOUNT_FLAG_HQ) THEN
                                                      (100 - nvl(lol.down_pay_scale, 100)) / 100
                                                    when v_Sc_Lock_Amount_Flag in (V_LOCK_AMOUNT_FLAG_RT, V_LOCK_AMOUNT_FLAG_Y) THEN
                                                      1
                                                    else
                                                      0
                                                  end
                                                else
                                                  0
                                              end,2)) Discount_Amount
                               From t_pln_lg_order_head h,
                                    t_Pln_Lg_Order_Line Lol,
                                    t_Bd_Item           Bi,
                                    t_Pln_Lg_Order_Head Hqloh,
                                    t_Pln_Lg_Order_Line Hqlol,
                                    v_bd_entity be
                              Where h.order_head_id = lol.order_head_id
                                and Lol.Item_Id = Bi.Item_Id
                                And Bi.Entity_Id = Lol.Entity_Id
                                And Hqloh.Sys_Source = 'CIMS'
                                And Hqloh.Source_Order_Id = Lol.Order_Head_Id
                                And Hqlol.Source_Line_Id = Lol.Order_Line_Id
                                And Hqloh.Order_Head_Id = Hqlol.Order_Head_Id
                                And In_Lg_Line_Id = -1
                                And Hqloh.Order_Head_Id = In_Lg_Order_Id
                                and h.entity_id = be.entity_id
                              Group By lol.entity_id,
                                       be.entity_name,
                                       h.customer_id,
                                       h.customer_code,
                                       h.account_id,
                                       h.account_code,
                                       nvl(lol.sales_main_type, bi.sales_main_type),
                                       Nvl(Lol.Discount_Type, v_Discount_Type_Common)
                             Union All
                             Select lol.entity_id,
                                    be.entity_name,
                                    h.customer_id,
                                    H.CUSTOMER_CODE,
                                    h.account_id,
                                    H.ACCOUNT_CODE,
                                    nvl(lol.sales_main_type, bi.sales_main_type) Sales_Main_Type,
                                    Nvl(Lol.Discount_Type, v_Discount_Type_Common) Discount_Type,
                                    Sum(Round(Nvl(In_Qty, 0) *
                                              Decode(Lol.Project_Order_Type,
                                                     Null,
                                                     (Nvl(Lol.List_Price, 0) *
                                                     (100 - Nvl(Lol.Discount_Rate, 0) - Nvl(Lol.Ordered_Discount_Rate, 0))) / 100,
                                                     (Nvl(Lol.Apply_List_Price, 0) *
                                                     (100 - Decode(v_Price_Apply_Use_Discount,
                                                                   'Y',
                                                                   Nvl(Lol.Apply_Discount_Rate, 0),
                                                                   0)
                                                      - Nvl(Lol.Ordered_Discount_Rate, 0))) / 100) *
                                              case
                                                when lol.customize_flag = 'Y' then
                                                  case
                                                    when IN_OPERATION_TYPE = '取消发货' then
                                                      0
                                                    when IN_OPERATION_TYPE = '取消发货取消订单' then
                                                      -1
                                                    else
                                                      0
                                                  end
                                                when nvl(lol.customize_flag, 'N') = 'N' then
                                                  case
                                                    when v_Sc_Lock_Amount_Flag In (V_LOCK_AMOUNT_FLAG_S, V_LOCK_AMOUNT_FLAG_RS, V_LOCK_AMOUNT_FLAG_HQ) THEN
                                                      case
                                                        when IN_OPERATION_TYPE = '取消发货' then
                                                          -1 * (100 - nvl(lol.down_pay_scale, 100)) / 100
                                                        when IN_OPERATION_TYPE = '取消发货取消订单' then
                                                          -1
                                                        else
                                                          0
                                                      end
                                                    when v_Sc_Lock_Amount_Flag in (V_LOCK_AMOUNT_FLAG_RT, V_LOCK_AMOUNT_FLAG_Y) THEN
                                                      -1
                                                    else
                                                      0
                                                  end
                                                else
                                                  0
                                              end,
                                              2)) Amount,
                                    Sum(Round(Nvl(In_Qty, 0) *
                                              Decode(Lol.Project_Order_Type,
                                                     Null,
                                                     Nvl(Lol.List_Price, 0) * Nvl(Lol.Discount_Rate, 0) / 100,
                                                     Nvl(Lol.Apply_List_Price, 0) *
                                                      Decode(v_Price_Apply_Use_Discount,
                                                             'Y',
                                                             Nvl(Lol.Apply_Discount_Rate, 0),
                                                             0) / 100) *
                                              case
                                                when lol.customize_flag = 'Y' then
                                                  case
                                                    when IN_OPERATION_TYPE = '取消发货' then
                                                      0
                                                    when IN_OPERATION_TYPE = '取消发货取消订单' then
                                                      -1
                                                    else
                                                      0
                                                  end
                                                when nvl(lol.customize_flag, 'N') = 'N' then
                                                  case
                                                    when v_Sc_Lock_Amount_Flag In (V_LOCK_AMOUNT_FLAG_S, V_LOCK_AMOUNT_FLAG_RS, V_LOCK_AMOUNT_FLAG_HQ) THEN
                                                      case
                                                        when IN_OPERATION_TYPE = '取消发货' then
                                                          -1 * (100 - nvl(lol.down_pay_scale, 100)) / 100
                                                        when IN_OPERATION_TYPE = '取消发货取消订单' then
                                                          -1
                                                        else
                                                          0
                                                      end
                                                    when v_Sc_Lock_Amount_Flag in (V_LOCK_AMOUNT_FLAG_RT, V_LOCK_AMOUNT_FLAG_Y) THEN
                                                      -1
                                                    else
                                                      0
                                                  end
                                                else
                                                  0
                                              end,
                                              2)) Discount_Amount
                               From t_pln_lg_order_head h,
                                    t_Pln_Lg_Order_Line Lol,
                                    t_Bd_Item           Bi,
                                    t_Pln_Lg_Order_Head Hqloh,
                                    t_Pln_Lg_Order_Line Hqlol,
                                    v_bd_entity be
                              Where h.order_head_id = lol.order_head_id
                                and Lol.Item_Id = Bi.Item_Id
                                And Bi.Entity_Id = Lol.Entity_Id
                                and h.entity_id = be.entity_id
                                And Hqloh.Sys_Source = 'CIMS'
                                And Hqloh.Source_Order_Id = Lol.Order_Head_Id
                                And Hqlol.Source_Line_Id = Lol.Order_Line_Id
                                And Hqloh.Order_Head_Id = Hqlol.Order_Head_Id
                                And Hqlol.Order_Line_Id = In_Lg_Line_Id
                                And In_Lg_Line_Id != -1
                                And Hqloh.Order_Head_Id = In_Lg_Order_Id
                              Group By lol.entity_id,
                                      be.entity_name,
                                      h.customer_id,
                                      H.CUSTOMER_CODE,
                                      h.account_id,
                                      H.ACCOUNT_CODE,
                                      nvl(lol.sales_main_type, bi.sales_main_type),
                                      Nvl(Lol.Discount_Type, v_Discount_Type_Common)
                              ) Loop
        PKG_CREDIT_ACCOUNT_CONTROL.P_CREDIT_CHECK_AMOUNT(IN_ENTITY_ID       => r_Check_Amount.Entity_Id,
                                                         IN_CUSTOMER_ID     => r_Check_Amount.Customer_Id,
                                                         IN_ACCOUNT_ID      => r_Check_Amount.Account_Id,
                                                         IN_SALES_MAIN_TYPE => r_Check_Amount.Sales_Main_Type,
                                                         IN_PROJ_NUMBER     => null,
                                                         IN_AMOUNT_SUM      => r_Check_Amount.Apply_Amount,
                                                         IN_DISAMOUNT_SUM   => r_Check_Amount.Discount_Amount,
                                                         IN_DISCOUNT_TYPE   => r_Check_Amount.Discount_Type,
                                                         IN_USER_ACCOUNT    => In_User_Code,
                                                         OUT_RESULT         => V_ERR_NUM,
                                                         OUT_ERR_MSG        => Out_Result);
        IF V_ERR_NUM <> 0 THEN
          Out_Result := '订单总部评审发货校验客户款项失败！错误提示：'||v_Nl||Out_Result||v_Nl||
                      '事业部='||r_Check_Amount.entity_name||v_Nl||
                      '客户ID='||r_Check_Amount.Customer_Id||' 编码='||r_Check_Amount.customer_code||v_Nl||
                      '账户ID='||r_Check_Amount.Account_Id||' 编码='||r_Check_Amount.account_code||v_Nl||
                      '营销大类='||r_Check_Amount.Sales_Main_Type||v_Nl||
                      '折扣类型='||r_Check_Amount.Discount_Type;
          raise v_Base_Exception;
        END IF;
      End Loop;
      
      --锁定款项
      For r_Check_Amount In (--甲方
                             Select lol.entity_id,
                                    be.entity_name,
                                    h.customer_id,
                                    H.CUSTOMER_CODE,
                                    h.account_id,
                                    H.ACCOUNT_CODE,
                                    nvl(lol.sales_main_type, bi.sales_main_type) Sales_Main_Type,
                                    Nvl(Lol.Discount_Type, v_Discount_Type_Common) Discount_Type,
                                    decode(lol.customize_flag, 'Y', ah.project_code, null) project_code,
                                    decode(lol.customize_flag, 'Y', 100, lol.down_pay_scale) down_pay_scale,
                                    h.order_head_id order_id,
                                    h.order_number order_number,
                                    '02' src_type,
                                    Sum(Round(case
                                                when IN_OPERATION_TYPE = '评审' then
                                                  Nvl(Hqlol.Affirming_Qty, 0)
                                                else 0
                                              end
                                              * Decode(Lol.Project_Order_Type,
                                                   Null,
                                                   Nvl(Lol.List_Price, 0) * (100 - Nvl(Lol.Discount_Rate, 0) - Nvl(Lol.Ordered_Discount_Rate, 0)) / 100,
                                                   Nvl(Lol.Apply_List_Price, 0) *
                                                   (100 - decode(v_Price_Apply_Use_Discount, 'Y', nvl(Lol.Apply_Discount_Rate, 0), 0)
                                                     - Nvl(Lol.Ordered_Discount_Rate, 0)) / 100)
                                              *
                                              case
                                                when lol.customize_flag = 'Y' then
                                                  1
                                                when nvl(lol.customize_flag, 'N') = 'N' then
                                                  case
                                                    when v_Sc_Lock_Amount_Flag In (V_LOCK_AMOUNT_FLAG_S,
                                                                                V_LOCK_AMOUNT_FLAG_RS,
                                                                                V_LOCK_AMOUNT_FLAG_HQ,
                                                                                V_LOCK_AMOUNT_FLAG_RT,
                                                                                V_LOCK_AMOUNT_FLAG_Y) then
                                                      1
                                                    else
                                                      0
                                                  end
                                                else
                                                  0
                                              end,2)) apply_Amount,
                                    Sum(Round(case
                                                when IN_OPERATION_TYPE = '评审' then
                                                  Nvl(Hqlol.Affirming_Qty, 0)
                                                else 0
                                              end
                                              * Decode(Lol.Project_Order_Type,
                                                   Null,
                                                   Nvl(Lol.List_Price, 0) * Nvl(Lol.Discount_Rate, 0) / 100,
                                                   Nvl(Lol.Apply_List_Price, 0) *
                                                   decode(v_Price_Apply_Use_Discount, 'Y', nvl(Lol.Apply_Discount_Rate, 0), 0) / 100)
                                              *
                                              case
                                                when lol.customize_flag = 'Y' then
                                                  1
                                                when nvl(lol.customize_flag, 'N') = 'N' then
                                                  case
                                                    when v_Sc_Lock_Amount_Flag In (V_LOCK_AMOUNT_FLAG_S,
                                                                                V_LOCK_AMOUNT_FLAG_RS,
                                                                                V_LOCK_AMOUNT_FLAG_HQ,
                                                                                V_LOCK_AMOUNT_FLAG_RT,
                                                                                V_LOCK_AMOUNT_FLAG_Y) THEN
                                                      1
                                                    else
                                                      0
                                                  end
                                                else
                                                  0
                                              end,2)) Discount_Amount,
                                    Sum(Round(case
                                                when IN_OPERATION_TYPE = '评审' then
                                                  Nvl(Hqlol.Affirming_Qty, 0)
                                                else 0
                                              end
                                              * Decode(Lol.Project_Order_Type,
                                                   Null,
                                                   Nvl(Lol.List_Price, 0) * (100 - Nvl(Lol.Discount_Rate, 0) - Nvl(Lol.Ordered_Discount_Rate, 0)) / 100,
                                                   Nvl(Lol.Apply_List_Price, 0) *
                                                   (100 - decode(v_Price_Apply_Use_Discount, 'Y', nvl(Lol.Apply_Discount_Rate, 0), 0)
                                                     - Nvl(Lol.Ordered_Discount_Rate, 0)) / 100)
                                              *
                                              case
                                                when lol.customize_flag = 'Y' then
                                                  -1
                                                when nvl(lol.customize_flag, 'N') = 'N' and v_Sc_Lock_Amount_Flag In (V_LOCK_AMOUNT_FLAG_S,
                                                                                                                   V_LOCK_AMOUNT_FLAG_RS,
                                                                                                                   V_LOCK_AMOUNT_FLAG_HQ) then
                                                  -1 * nvl(lol.down_pay_scale, 100) / 100
                                                else
                                                  0
                                              end,2)) dp_apply_Amount,
                                    Sum(Round(case
                                                when IN_OPERATION_TYPE = '评审' then
                                                  Nvl(Hqlol.Affirming_Qty, 0)
                                                else 0
                                              end
                                              * Decode(Lol.Project_Order_Type,
                                                   Null,
                                                   Nvl(Lol.List_Price, 0) * Nvl(Lol.Discount_Rate, 0) / 100,
                                                   Nvl(Lol.Apply_List_Price, 0) *
                                                   decode(v_Price_Apply_Use_Discount, 'Y', nvl(Lol.Apply_Discount_Rate, 0), 0) / 100)
                                              *
                                              case
                                                when lol.customize_flag = 'Y' then
                                                  -1
                                                when nvl(lol.customize_flag, 'N') = 'N' and v_Sc_Lock_Amount_Flag In (V_LOCK_AMOUNT_FLAG_S,
                                                                                                                   V_LOCK_AMOUNT_FLAG_RS,
                                                                                                                   V_LOCK_AMOUNT_FLAG_HQ) then
                                                  -1 * nvl(lol.down_pay_scale, 100) / 100
                                                else
                                                  0
                                              end,2)) dp_Discount_Amount
                               From t_pln_lg_order_head h,
                                    t_Pln_Lg_Order_Line Lol,
                                    t_Pln_Lg_Order_Line hqLol,
                                    t_pln_lg_order_head hqloh,
                                    t_Bd_Item Bi,
                                    v_bd_entity be,
                                    t_pg_price_apply_head ah
                              Where lol.order_head_id = h.order_head_id
                                and Lol.Item_Id = Bi.Item_Id
                                And Bi.Entity_Id = Lol.Entity_Id
                                And hqLol.Order_Head_Id = In_Lg_Order_Id
                                And Hqloh.Sys_Source = 'CIMS'
                                And In_Lg_Line_Id = -1
                                And Hqloh.Source_Order_Id = Lol.Order_Head_Id
                                And Hqlol.Source_Line_Id = Lol.Order_Line_Id
                                And Hqloh.Order_Head_Id = Hqlol.Order_Head_Id
                                and h.entity_id = be.entity_id
                                and lol.entity_id = ah.entity_id(+)
                                and lol.project_order_number = ah.apply_code(+)
                              Group By lol.entity_id,
                                       be.entity_name,
                                       h.customer_id,
                                       h.customer_code,
                                       h.account_id,
                                       h.account_code,
                                       nvl(lol.sales_main_type, bi.sales_main_type),
                                       Nvl(Lol.Discount_Type, v_Discount_Type_Common),
                                       decode(lol.customize_flag, 'Y', ah.project_code, null),
                                       decode(lol.customize_flag, 'Y', 100, lol.down_pay_scale),
                                       h.order_head_id,
                                       h.order_number
                             Union All
                             Select lol.entity_id,
                                    be.entity_name,
                                    h.customer_id,
                                    H.CUSTOMER_CODE,
                                    h.account_id,
                                    H.ACCOUNT_CODE,
                                    nvl(lol.sales_main_type, bi.sales_main_type) Sales_Main_Type,
                                    Nvl(Lol.Discount_Type, v_Discount_Type_Common) Discount_Type,
                                    decode(lol.customize_flag, 'Y', ah.project_code, null) project_code,
                                    decode(lol.customize_flag, 'Y', 100, lol.down_pay_scale) down_pay_scale,
                                    h.order_head_id order_id,
                                    h.order_number order_number,
                                    '02' src_type,
                                    Sum(Round(Nvl(In_Qty, 0) *
                                              Decode(Lol.Project_Order_Type,
                                                     Null,
                                                     (Nvl(Lol.List_Price, 0) *
                                                     (100 - Nvl(Lol.Discount_Rate, 0) - Nvl(Lol.Ordered_Discount_Rate, 0))) / 100,
                                                     (Nvl(Lol.Apply_List_Price, 0) *
                                                     (100 - Decode(v_Price_Apply_Use_Discount,
                                                                   'Y',
                                                                   Nvl(Lol.Apply_Discount_Rate, 0),
                                                                   0)
                                                      - Nvl(Lol.Ordered_Discount_Rate, 0))) / 100) *
                                              case
                                                when lol.customize_flag = 'Y' then
                                                  case
                                                    when IN_OPERATION_TYPE = '取消发货' then
                                                      -1
                                                    when IN_OPERATION_TYPE = '取消发货取消订单' then
                                                      -1
                                                    else
                                                      0
                                                  end
                                                when nvl(lol.customize_flag, 'N') = 'N' then
                                                  case
                                                    when v_Sc_Lock_Amount_Flag In (V_LOCK_AMOUNT_FLAG_S, V_LOCK_AMOUNT_FLAG_RS, V_LOCK_AMOUNT_FLAG_HQ) THEN
                                                      case
                                                        when IN_OPERATION_TYPE = '取消发货' then
                                                          -1
                                                        when IN_OPERATION_TYPE = '取消发货取消订单' then
                                                          -1
                                                        else
                                                          0
                                                      end
                                                    when v_Sc_Lock_Amount_Flag in (V_LOCK_AMOUNT_FLAG_RT, V_LOCK_AMOUNT_FLAG_Y) THEN
                                                      -1
                                                    else
                                                      0
                                                  end
                                                else
                                                  0
                                              end,
                                              2)) apply_Amount,
                                    Sum(Round(Nvl(In_Qty, 0) *
                                              Decode(Lol.Project_Order_Type,
                                                     Null,
                                                     Nvl(Lol.List_Price, 0) * Nvl(Lol.Discount_Rate, 0) / 100,
                                                     Nvl(Lol.Apply_List_Price, 0) *
                                                      Decode(v_Price_Apply_Use_Discount,
                                                             'Y',
                                                             Nvl(Lol.Apply_Discount_Rate, 0),
                                                             0) / 100) *
                                              case
                                                when lol.customize_flag = 'Y' then
                                                  case
                                                    when IN_OPERATION_TYPE = '取消发货' then
                                                      -1
                                                    when IN_OPERATION_TYPE = '取消发货取消订单' then
                                                      -1
                                                    else
                                                      0
                                                  end
                                                when nvl(lol.customize_flag, 'N') = 'N' then
                                                  case
                                                    when v_Sc_Lock_Amount_Flag In (V_LOCK_AMOUNT_FLAG_S, V_LOCK_AMOUNT_FLAG_RS, V_LOCK_AMOUNT_FLAG_HQ) THEN
                                                      case
                                                        when IN_OPERATION_TYPE = '取消发货' then
                                                          -1
                                                        when IN_OPERATION_TYPE = '取消发货取消订单' then
                                                          -1
                                                        else
                                                          0
                                                      end
                                                    when v_Sc_Lock_Amount_Flag in (V_LOCK_AMOUNT_FLAG_RT, V_LOCK_AMOUNT_FLAG_Y) THEN
                                                      -1
                                                    else
                                                      0
                                                  end
                                                else
                                                  0
                                              end,
                                              2)) Discount_Amount,
                                    Sum(Round(Nvl(In_Qty, 0) *
                                              Decode(Lol.Project_Order_Type,
                                                     Null,
                                                     (Nvl(Lol.List_Price, 0) *
                                                     (100 - Nvl(Lol.Discount_Rate, 0) - Nvl(Lol.Ordered_Discount_Rate, 0))) / 100,
                                                     (Nvl(Lol.Apply_List_Price, 0) *
                                                     (100 - Decode(v_Price_Apply_Use_Discount,
                                                                   'Y',
                                                                   Nvl(Lol.Apply_Discount_Rate, 0),
                                                                   0)
                                                      - Nvl(Lol.Ordered_Discount_Rate, 0))) / 100) *
                                              case
                                                when lol.customize_flag = 'Y' then
                                                  case
                                                    when IN_OPERATION_TYPE = '取消发货' then
                                                      1
                                                    when IN_OPERATION_TYPE = '取消发货取消订单' then
                                                      0
                                                    else
                                                      0
                                                  end
                                                when nvl(lol.customize_flag, 'N') = 'N' then
                                                  case
                                                    when v_Sc_Lock_Amount_Flag In (V_LOCK_AMOUNT_FLAG_S, V_LOCK_AMOUNT_FLAG_RS, V_LOCK_AMOUNT_FLAG_HQ) THEN
                                                      case
                                                        when IN_OPERATION_TYPE = '取消发货' then
                                                          nvl(lol.down_pay_scale, 100) / 100
                                                        when IN_OPERATION_TYPE = '取消发货取消订单' then
                                                          0
                                                        else
                                                          0
                                                      end
                                                    when v_Sc_Lock_Amount_Flag in (V_LOCK_AMOUNT_FLAG_RT, V_LOCK_AMOUNT_FLAG_Y) THEN
                                                      -1
                                                    else
                                                      0
                                                  end
                                                else
                                                  0
                                              end,
                                              2)) dp_apply_Amount,
                                    Sum(Round(Nvl(In_Qty, 0) *
                                              Decode(Lol.Project_Order_Type,
                                                     Null,
                                                     Nvl(Lol.List_Price, 0) * Nvl(Lol.Discount_Rate, 0) / 100,
                                                     Nvl(Lol.Apply_List_Price, 0) *
                                                      Decode(v_Price_Apply_Use_Discount,
                                                             'Y',
                                                             Nvl(Lol.Apply_Discount_Rate, 0),
                                                             0) / 100) *
                                              case
                                                when lol.customize_flag = 'Y' then
                                                  case
                                                    when IN_OPERATION_TYPE = '取消发货' then
                                                      1
                                                    when IN_OPERATION_TYPE = '取消发货取消订单' then
                                                      0
                                                    else
                                                      0
                                                  end
                                                when nvl(lol.customize_flag, 'N') = 'N' then
                                                  case
                                                    when v_Sc_Lock_Amount_Flag In (V_LOCK_AMOUNT_FLAG_S, V_LOCK_AMOUNT_FLAG_RS, V_LOCK_AMOUNT_FLAG_HQ) THEN
                                                      case
                                                        when IN_OPERATION_TYPE = '取消发货' then
                                                          nvl(lol.down_pay_scale, 100) / 100
                                                        when IN_OPERATION_TYPE = '取消发货取消订单' then
                                                          0
                                                        else
                                                          0
                                                      end
                                                    when v_Sc_Lock_Amount_Flag in (V_LOCK_AMOUNT_FLAG_RT, V_LOCK_AMOUNT_FLAG_Y) THEN
                                                      -1
                                                    else
                                                      0
                                                  end
                                                else
                                                  0
                                              end,
                                              2)) dp_Discount_Amount
                               From t_pln_lg_order_head h,
                                    t_Pln_Lg_Order_Line Lol,
                                    t_Bd_Item           Bi,
                                    t_Pln_Lg_Order_Head Hqloh,
                                    t_Pln_Lg_Order_Line Hqlol,
                                    v_bd_entity be,
                                    t_pg_price_apply_head ah
                              Where h.order_head_id = lol.order_head_id
                                and Lol.Item_Id = Bi.Item_Id
                                And Bi.Entity_Id = Lol.Entity_Id
                                and h.entity_id = be.entity_id
                                And Hqloh.Sys_Source = 'CIMS'
                                And Hqloh.Source_Order_Id = Lol.Order_Head_Id
                                And Hqlol.Source_Line_Id = Lol.Order_Line_Id
                                And Hqloh.Order_Head_Id = Hqlol.Order_Head_Id
                                And Hqlol.Order_Line_Id = In_Lg_Line_Id
                                And In_Lg_Line_Id != -1
                                And Hqloh.Order_Head_Id = In_Lg_Order_Id
                                and lol.entity_id = ah.entity_id(+)
                                and lol.project_order_number = ah.apply_code(+)
                              Group By lol.entity_id,
                                      be.entity_name,
                                      h.customer_id,
                                      H.CUSTOMER_CODE,
                                      h.account_id,
                                      H.ACCOUNT_CODE,
                                      nvl(lol.sales_main_type, bi.sales_main_type),
                                      Nvl(Lol.Discount_Type, v_Discount_Type_Common),
                                      decode(lol.customize_flag, 'Y', ah.project_code, null),
                                      decode(lol.customize_flag, 'Y', 100, lol.down_pay_scale),
                                      h.order_head_id,
                                      h.order_number
                              ) Loop
        PKG_CREDIT_ACCOUNT_CONTROL.P_CREDIT_LOCK_DETAIL_HAND(IN_ENTITY_ID   => r_Check_Amount.Entity_Id,
                                                         IN_CUSTOMER_ID     => r_Check_Amount.Customer_Id,
                                                         IN_ACCOUNT_ID      => r_Check_Amount.Account_Id,
                                                         IN_SALES_MAIN_TYPE => r_Check_Amount.Sales_Main_Type,
                                                         IN_PROJ_NUMBER     => r_Check_Amount.project_code,
                                                         IN_AMOUNT_SUM      => r_Check_Amount.Apply_Amount,
                                                         IN_DISAMOUNT_SUM   => r_Check_Amount.Discount_Amount,
                                                         IN_DP_AMOUNT_SUM   => r_Check_Amount.dp_apply_Amount,
                                                         IN_DP_DISAMOUNT_SUM => r_Check_Amount.dp_Discount_Amount,
                                                         IN_DISCOUNT_TYPE   => r_Check_Amount.Discount_Type,
                                                         IN_ORDER_ID        => r_Check_Amount.order_id,
                                                         IN_ORDER_NUMBER    => r_Check_Amount.order_number,
                                                         IN_DOWNPAY_RATE    => r_Check_Amount.down_pay_scale,
                                                         IN_SRC_TYPE        => r_Check_Amount.src_type,
                                                         IN_USER_ACCOUNT    => in_User_Code,
                                                         OUT_RESULT         => V_ERR_NUM,
                                                         OUT_ERR_MSG        => out_Result);
        IF V_ERR_NUM <> 0 THEN
          out_Result := '订单总部评审发货处理客户款项失败！错误提示：'||v_Nl||out_Result||v_Nl||
                      '事业部='||r_Check_Amount.entity_name||v_Nl||
                      '客户ID='||r_Check_Amount.Customer_Id||' 编码='||r_Check_Amount.customer_code||v_Nl||
                      '账户ID='||r_Check_Amount.Account_Id||' 编码='||r_Check_Amount.account_code||v_Nl||
                      '营销大类='||r_Check_Amount.Sales_Main_Type||v_Nl||
                      '折扣类型='||r_Check_Amount.Discount_Type;
          raise v_Base_Exception;
        END IF;
      End Loop;
    ELSiF IN_SKIP_LOCK = 'N' THEN -- add by houhs 
    
    For r_Check_Amount In (Select Nvl(Lol.Sales_Main_Type, Bi.Sales_Main_Type) Sales_Main_Type, --Bi.Sales_Main_Type,
                                  Nvl(Lol.Discount_Type, v_Discount_Type_Common) Discount_Type, --add by lizhen 2017-04-20                                    
                                  Sum(Round(case
                                              when IN_OPERATION_TYPE = '评审' then
                                                Nvl(Hqlol.Affirming_Qty, 0)
                                              when IN_OPERATION_TYPE in ('送总部评审','驳回') then
                                                greatest(nvl(lol.Center_Affirm_Quantity,0)-nvl(lol.Center_Affirmed_Qty,0)-nvl(lol.Cancel_Qty,0)
                                                         -(nvl(lol.transfer_hq_affirmed_qty,0)-nvl(lol.sended_qty,0)),0)
                                              else 0
                                            end
                                             *
                                            Decode(Lol.Project_Order_Type,
                                                   Null,
                                                   (Nvl(Lol.List_Price, 0) *
                                                   (100 - Nvl(Lol.Discount_Rate, 0) - Nvl(Lol.Ordered_Discount_Rate, 0))) / 100,
                                                   (Nvl(Lol.Apply_List_Price, 0) *
                                                   (100 - Decode(v_Price_Apply_Use_Discount,
                                                                 'Y',
                                                                 Nvl(Lol.Apply_Discount_Rate, 0),
                                                                 0)
                                                    - Nvl(Lol.Ordered_Discount_Rate, 0))) / 100)*
                                                        --add by houhs 如果锁全款成功*0 不计算这部分 20200313
                                                        (Decode(Lol.Is_Lock_Amount,'Y',0,1)),
                                            2)) Amount,
                                  Sum(Round(case
                                              when IN_OPERATION_TYPE = '评审' then
                                                Nvl(Hqlol.Affirming_Qty, 0)
                                              when IN_OPERATION_TYPE in ('送总部评审','驳回') then
                                                greatest(nvl(lol.Center_Affirm_Quantity,0)-nvl(lol.Center_Affirmed_Qty,0)-nvl(lol.Cancel_Qty,0)
                                                         -(nvl(lol.transfer_hq_affirmed_qty,0)-nvl(lol.sended_qty,0)),0)
                                              else 0
                                            end
                                             *
                                            Decode(Lol.Project_Order_Type,
                                                   Null,
                                                   (Nvl(Lol.List_Price, 0) * Nvl(Lol.Discount_Rate, 0)) / 100,
                                                   Nvl(Lol.Apply_List_Price, 0) *
                                                    Decode(v_Price_Apply_Use_Discount,
                                                           'Y',
                                                           Nvl(Lol.Apply_Discount_Rate, 0),
                                                           0) / 100)*
                                                        --add by houhs 如果锁全款成功*0 不计算这部分 20200313
                                                        (Decode(Lol.Is_Lock_Amount,'Y',0,1)),
                                            2)) Discount_Amount
                             From t_Pln_Lg_Order_Line Lol,
                                  t_Bd_Item           Bi,
                                  t_Pln_Lg_Order_Head Hqloh,
                                  t_Pln_Lg_Order_Line Hqlol
                            Where Lol.Item_Id = Bi.Item_Id
                              And Bi.Entity_Id = Lol.Entity_Id
                              And Hqloh.Sys_Source = 'CIMS'
                              And Hqloh.Source_Order_Id = Lol.Order_Head_Id
                              And Hqlol.Source_Line_Id = Lol.Order_Line_Id
                              And Hqloh.Order_Head_Id = Hqlol.Order_Head_Id
                              And In_Lg_Line_Id = -1
                              And Hqloh.Order_Head_Id = In_Lg_Order_Id
                            Group By Nvl(Lol.Sales_Main_Type, Bi.Sales_Main_Type),
                                     Nvl(Lol.Discount_Type, v_Discount_Type_Common)
                           Union All
                           Select Nvl(Lol.Sales_Main_Type, Bi.Sales_Main_Type) Sales_Main_Type, --Bi.Sales_Main_Type,
                                  Nvl(Lol.Discount_Type, v_Discount_Type_Common) Discount_Type, --add by lizhen 2017-04-20                                    
                                  Sum(Round(Nvl(In_Qty, 0) *
                                            Decode(Lol.Project_Order_Type,
                                                   Null,
                                                   (Nvl(Lol.List_Price, 0) *
                                                   (100 - Nvl(Lol.Discount_Rate, 0) - Nvl(Lol.Ordered_Discount_Rate, 0))) / 100,
                                                   (Nvl(Lol.Apply_List_Price, 0) *
                                                   (100 - Decode(v_Price_Apply_Use_Discount,
                                                                 'Y',
                                                                 Nvl(Lol.Apply_Discount_Rate, 0),
                                                                 0)
                                                    - Nvl(Lol.Ordered_Discount_Rate, 0))) / 100)*
                                                        --add by houhs 如果锁全款成功*0 不计算这部分 20200313
                                                        (Decode(Lol.Is_Lock_Amount,'Y',0,1)),
                                            2)) Amount,
                                  Sum(Round(Nvl(In_Qty, 0) *
                                            Decode(Lol.Project_Order_Type,
                                                   Null,
                                                   Nvl(Lol.List_Price, 0) * Nvl(Lol.Discount_Rate, 0) / 100,
                                                   Nvl(Lol.Apply_List_Price, 0) *
                                                    Decode(v_Price_Apply_Use_Discount,
                                                           'Y',
                                                           Nvl(Lol.Apply_Discount_Rate, 0),
                                                           0) / 100)*
                                                        --add by houhs 如果锁全款成功*0 不计算这部分 20200313
                                                        (Decode(Lol.Is_Lock_Amount,'Y',0,1)),
                                            2)) Discount_Amount
                             From t_Pln_Lg_Order_Line Lol,
                                  t_Bd_Item           Bi,
                                  t_Pln_Lg_Order_Head Hqloh,
                                  t_Pln_Lg_Order_Line Hqlol
                            Where Lol.Item_Id = Bi.Item_Id
                              And Bi.Entity_Id = Lol.Entity_Id
                              And Hqloh.Sys_Source = 'CIMS'
                              And Hqloh.Source_Order_Id = Lol.Order_Head_Id
                              And Hqlol.Source_Line_Id = Lol.Order_Line_Id
                              And Hqloh.Order_Head_Id = Hqlol.Order_Head_Id
                              And Hqlol.Order_Line_Id = In_Lg_Line_Id
                              And In_Lg_Line_Id != -1
                              And Hqloh.Order_Head_Id = In_Lg_Order_Id
                            Group By Nvl(Lol.Sales_Main_Type, Bi.Sales_Main_Type),
                                     Nvl(Lol.Discount_Type, v_Discount_Type_Common)) Loop
    If In_Lg_Line_Id = -1 Then
      if v_Sc_Lock_Amount_Flag = V_LOCK_AMOUNT_FLAG_S then
        v_Action_Type := 28; --解锁订金，加锁款项
      elsif v_Sc_Lock_Amount_Flag = V_LOCK_AMOUNT_FLAG_Y then
        v_Action_Type := 1;  --锁定款项
      elsif v_Sc_Lock_Amount_Flag = V_LOCK_AMOUNT_FLAG_HQ then
        if IN_OPERATION_TYPE = '送总部评审' then
          v_Action_Type := 1; --锁订金
        elsif IN_OPERATION_TYPE = '评审' then
          if NVL(r_Lg_Order.Submit_To_Hq_Flag,'N') = 'N' then
            v_Action_Type := 1; --锁订金
          elsif r_Lg_Order.Submit_To_Hq_Flag = 'Y' then
            v_Action_Type := 28; --解锁订金锁全款
          end if;
        elsif IN_OPERATION_TYPE = '驳回' then
          if r_Lg_Order.Submit_To_Hq_Flag = 'Y' then
            v_Action_Type := 2; --解锁订金
          else
            v_Action_Type := null;
          end if;
        end if;
      end if;
    Else
      if v_Sc_Lock_Amount_Flag = V_LOCK_AMOUNT_FLAG_S then
        v_Action_Type := 29; --解锁款项，加锁订金
      elsif v_Sc_Lock_Amount_Flag = V_LOCK_AMOUNT_FLAG_Y then
        v_Action_Type := 2; --解锁款项
      elsif v_Sc_Lock_Amount_Flag = V_LOCK_AMOUNT_FLAG_HQ then
        v_Action_Type := 29;
      end if;
    End If;
    if v_Action_Type is not null then
      pkg_pln_pub.P_CUSTOMER_AMOUNT_PROCESS(IN_ENTITY_ID       => v_Sc_Entity_Id,
                                            IN_ORDER_TYPE_ID   => v_Sc_Order_Type_Id,
                                            IN_ORDER_TYPE_CODE => v_Sc_Order_Type_Code,
                                            IN_CUSTOMER_ID     => v_Sc_Customer_Id,
                                            IN_ACCOUNT_ID      => v_Sc_Account_Id,
                                            IN_SALES_MAIN_TYPE => r_Check_Amount.Sales_Main_Type,
                                            IN_ACTION_TYPE     => v_Action_Type,
                                            IN_SOURCE_TYPE     => '02',
                                            IN_ORDER_ID        => r_Lg_Order.Source_Order_Id,
                                            IN_PROJ_NUMBER     => null,
                                            IN_DISCOUNT_TYPE   => r_Check_Amount.Discount_Type,
                                            IN_AMOUNT          => round(Nvl(r_Check_Amount.Amount, 0), 2),
                                            IN_DIS_AMOUNT      => round(Nvl(r_Check_Amount.Discount_Amount, 0), 2),
                                            IN_RECORD_ERR      => 'N',
                                            IN_USER_CODE       => in_User_Code,
                                            OUT_RESULT         => Out_Result);
      if Out_Result <> v_Success then
        Raise v_Base_Exception;
      end if;
    end if;
    
    v_Action_Type := null;
    if v_Sc_Lock_Amount_Flag = V_LOCK_AMOUNT_FLAG_HQ then
      If In_Lg_Line_Id = -1 Then
        if IN_OPERATION_TYPE = '评审' and NVL(r_Lg_Order.Submit_To_Hq_Flag,'N') = 'N' then
          v_Action_Type := 28;
        end if;
      else
        if IN_OPERATION_TYPE = '取消发货取消订单' then
          v_Action_Type := 2;
        elsif IN_OPERATION_TYPE = '取消发货' and NVL(r_Lg_Order.Submit_To_Hq_Flag,'N') = 'N' then
          v_Action_Type := 2;
        end if;
      end if;
      
      if v_Action_Type is not null then
        pkg_pln_pub.P_CUSTOMER_AMOUNT_PROCESS(IN_ENTITY_ID       => v_Sc_Entity_Id,
                                              IN_ORDER_TYPE_ID   => v_Sc_Order_Type_Id,
                                              IN_ORDER_TYPE_CODE => v_Sc_Order_Type_Code,
                                              IN_CUSTOMER_ID     => v_Sc_Customer_Id,
                                              IN_ACCOUNT_ID      => v_Sc_Account_Id,
                                              IN_SALES_MAIN_TYPE => r_Check_Amount.Sales_Main_Type,
                                              IN_ACTION_TYPE     => v_Action_Type,
                                              IN_SOURCE_TYPE     => '02',
                                              IN_ORDER_ID        => r_Lg_Order.Source_Order_Id,
                                              IN_PROJ_NUMBER     => null,
                                              IN_DISCOUNT_TYPE   => r_Check_Amount.Discount_Type,
                                              IN_AMOUNT          => round(Nvl(r_Check_Amount.Amount, 0), 2),
                                              IN_DIS_AMOUNT      => round(Nvl(r_Check_Amount.Discount_Amount, 0), 2),
                                              IN_RECORD_ERR      => 'N',
                                              IN_USER_CODE       => in_User_Code,
                                              OUT_RESULT         => Out_Result);
        if Out_Result <> v_Success then
          Raise v_Base_Exception;
        end if;
      end if;
    End If;

    End Loop;
    END IF;
    
    if IN_OPERATION_TYPE in ('评审', '取消发货', '取消发货取消订单') then
      If In_Lg_Line_Id = -1 Then
        Update t_Pln_Lg_Order_Line Lol
           Set Lol.Transfer_Hq_Affirmed_Qty = Nvl(Lol.Transfer_Hq_Affirmed_Qty, 0) +
                                              NVL((Select Hqlol.Affirming_Qty
                                                 From t_Pln_Lg_Order_Head Hqloh,
                                                      t_Pln_Lg_Order_Line Hqlol
                                                Where Hqloh.Order_Head_Id = Hqlol.Order_Head_Id
                                                  And Hqloh.Order_Head_Id = In_Lg_Order_Id
                                                  And Hqlol.Source_Line_Id = Lol.Order_Line_Id
                                                  And Hqloh.Sys_Source = 'CIMS'),0),
               Lol.Last_Update_Date = Sysdate,
               Lol.Last_Updated_By = In_User_Code,
               Lol.Version = nvl(Lol.Version, 0) + 1
         Where Lol.Order_Line_Id In
               (Select Hqlol.Source_Line_Id
                  From t_Pln_Lg_Order_Head Hqloh, t_Pln_Lg_Order_Line Hqlol
                 Where Hqloh.Order_Head_Id = Hqlol.Order_Head_Id
                   And Hqloh.Order_Head_Id = In_Lg_Order_Id
                   And Hqloh.Sys_Source = 'CIMS'
                   AND Hqlol.Affirming_Qty > 0);

      Else
        Update t_Pln_Lg_Order_Line Lol
           Set Lol.Transfer_Hq_Affirmed_Qty = Nvl(Lol.Transfer_Hq_Affirmed_Qty,
                                                  0) - In_Qty,
               Lol.Last_Update_Date         = Sysdate,
               Lol.Last_Updated_By          = In_User_Code,
               Lol.Version = nvl(Lol.Version, 0) + 1
         Where Lol.Order_Line_Id In
               (Select Hqlol.Source_Line_Id
                  From t_Pln_Lg_Order_Head Hqloh, t_Pln_Lg_Order_Line Hqlol
                 Where Hqloh.Order_Head_Id = Hqlol.Order_Head_Id
                   And Hqloh.Order_Head_Id = In_Lg_Order_Id
                   and hqlol.order_line_id = In_Lg_Line_Id
                   And Hqloh.Sys_Source = 'CIMS')
        Returning Lol.Transfer_Hq_Affirmed_Qty Into v_Transfer_Qty;
        If Nvl(v_Transfer_Qty, 0) < 0 Then
          Out_Result := '取消发货数量时异常，销司结转发货数量更新后为负数。';
          Raise v_Base_Exception;
        End If;
      End If;
    End If;
    end if;
    
    if IN_OPERATION_TYPE in ('取消发货取消订单') then
      Update t_Pln_Lg_Order_Line Lol
         Set Lol.Cancel_Qty = Nvl(Lol.Cancel_Qty, 0) + In_Qty,
             Lol.Last_Update_Date         = Sysdate,
             Lol.Last_Updated_By          = In_User_Code,
             Lol.Version = nvl(Lol.Version, 0) + 1
       Where Lol.Order_Line_Id In
             (Select Hqlol.Source_Line_Id
                From t_Pln_Lg_Order_Head Hqloh, t_Pln_Lg_Order_Line Hqlol
               Where Hqloh.Order_Head_Id = Hqlol.Order_Head_Id
                 And Hqloh.Order_Head_Id = In_Lg_Order_Id
                 and hqlol.order_line_id = In_Lg_Line_Id
                 And Hqloh.Sys_Source = 'CIMS');
          
      --解锁销司批文
      for r_order_line in (
        select h.order_number, l.*
          from t_pln_lg_order_line l, t_pln_lg_order_head h
         where l.order_head_id = h.order_head_id
           and h.hq_lg_order_head_id = In_Lg_Order_Id
           and l.hq_lg_order_line_id = In_Lg_Line_Id
           and nvl(l.project_order_line_id, '-1') <> '-1'
        )
      loop
        -- 价格申请解锁（提货订单评审驳回时），PriceApplyBO.unlock(‘批文明细ID’，'解锁数量’，‘关联单号’ )
        Pkg_Bd_Price.p_Apply_Unlock(r_order_line.Project_Order_Line_Id, --批文明细ID
                                    In_Qty, --解除锁定数量
                                    r_order_line.Order_Number, --关联单号
                                    out_Result, --返回编码，1成功，0失败
                                    v_Return_Msg);
        If out_Result != 1 Then
          out_Result := '取消销司主体订单释放批文锁定数量失败！销司提货订单号=' || r_order_line.Order_Number ||
                        v_Nl || v_Return_Msg;
          Raise v_Base_Exception;
        Else
          Out_Result := v_Success;
        End If;
      end loop;
    End If;
    
    --若来源主体订单是来源CIMS其他主体结转生成的，需锁定源主体客户款项
    IF v_Sc_Sys_Source = 'CIMS' and (v_Sc_Direct_Send_Flag = 'Y' or v_Sc_Client_Carry_Flag = 'Y')
      --hejy3 非关联交易模式
      and nvl(r_Lg_Order.Sup_Req_Entity_Flag, 'N') <> 'Y'
      and IN_OPERATION_TYPE in ('评审', '取消发货', '取消发货取消订单') THEN
      IF In_Lg_Line_Id = -1 THEN
        v_Sc_Order_Line_Id := -1;
        --更新来源单据的待评审数量
        Update t_Pln_Lg_Order_Line Lol
           Set Lol.Affirming_Qty = NVL((Select Hqlol.Affirming_Qty
                                           From t_Pln_Lg_Order_Head Hqloh,
                                                t_Pln_Lg_Order_Line Hqlol
                                          Where Hqloh.Order_Head_Id = Hqlol.Order_Head_Id
                                            And Hqloh.Order_Head_Id = In_Lg_Order_Id
                                            And Hqlol.Source_Line_Id = Lol.Order_Line_Id
                                            And Hqloh.Sys_Source = 'CIMS'),0),
               Lol.Last_Update_Date = Sysdate,
               Lol.Last_Updated_By = In_User_Code,
               Lol.Version = nvl(Lol.Version, 0) + 1
         Where Lol.Order_Line_Id In
               (Select Hqlol.Source_Line_Id
                  From t_Pln_Lg_Order_Head Hqloh, t_Pln_Lg_Order_Line Hqlol
                 Where Hqloh.Order_Head_Id = Hqlol.Order_Head_Id
                   And Hqloh.Order_Head_Id = In_Lg_Order_Id
                   And Hqloh.Sys_Source = 'CIMS'
                   AND Hqlol.Affirming_Qty > 0);
      ELSE
        --取来源行ID
        SELECT OL.SOURCE_LINE_ID
          INTO v_Sc_Order_Line_Id
          FROM T_PLN_LG_ORDER_LINE OL
         WHERE OL.ORDER_LINE_ID = In_Lg_Line_Id;
      END IF;
      PKG_PLN_PUB.p_Upd_Transfer_Lg_Order(In_Lg_Order_Id    => v_Sc_Order_Head_Id,
                                          In_Lg_Line_Id     => v_Sc_Order_Line_Id,
                                          In_Qty            => In_Qty,
                                          In_User_Code      => In_User_Code,
                                          Out_Result        => Out_Result,
                                          IN_OPERATION_TYPE => IN_OPERATION_TYPE,
                                          IN_SKIP_LOCK      => IN_SKIP_LOCK);--add by houhs
      --更新来源单据的待评审数量为0
      Update t_Pln_Lg_Order_Line Lol
         Set Lol.Affirm_Quantity = null,
             Lol.Affirming_Qty = null,
             Lol.Last_Update_Date = Sysdate,
             Lol.Last_Updated_By = In_User_Code,
             Lol.Version = nvl(Lol.Version, 0) + 1
       Where Lol.Order_Line_Id In
             (Select Hqlol.Source_Line_Id
                From t_Pln_Lg_Order_Head Hqloh, t_Pln_Lg_Order_Line Hqlol
               Where Hqloh.Order_Head_Id = Hqlol.Order_Head_Id
                 And Hqloh.Order_Head_Id = In_Lg_Order_Id
                 And Hqloh.Sys_Source = 'CIMS');
    END IF;
  Exception
    When v_Base_Exception Then
      Out_Result := '更新来源主体提货锁款信息失败！' || v_Nl || Out_Result;
      Rollback to upTransfer;
    When Others Then
      Out_Result := '更新来源主体提货锁款信息失败！' || v_Nl || Out_Result || v_Nl || Sqlerrm;
      Rollback to upTransfer;
  End;
  
  -----------------------------------------------------------------------------
  -- AUTHOR  : hejy3
  -- CREATED : 2018-4-27
  -- PURPOSE : 检查ERP侧是否有维护标准成本，有维护返回1，否则返回0
  -----------------------------------------------------------------------------
  FUNCTION F_CHK_ERP_STANDARD_COST(IN_ORGANIZATION_ID IN NUMBER, --组织ID
                                   IN_ITEM_CODE       IN VARCHAR2 --产品
                                   ) RETURN NUMBER
  IS
    V_COUNT NUMBER;
  BEGIN
    SELECT COUNT(1) INTO V_COUNT
      FROM APPS.MTL_SYSTEM_ITEMS@MDIMS2MDERP M,
           APPS.CST_ITEM_COSTS@MDIMS2MDERP   CIC
     WHERE M.ORGANIZATION_ID = IN_ORGANIZATION_ID
       AND M.SEGMENT1 = IN_ITEM_CODE
       AND NVL(M.CUSTOMER_ORDER_ENABLED_FLAG, 'N') = 'Y'
       AND NVL(M.CUSTOMER_ORDER_FLAG, 'N') = 'Y'
       AND NVL(M.SHIPPABLE_ITEM_FLAG, 'N') = 'Y'
       AND NVL(M.SO_TRANSACTIONS_FLAG, 'N') = 'Y'
       AND NVL(M.RETURNABLE_FLAG, 'N') = 'Y'
       AND M.ATP_COMPONENTS_FLAG = 'N'
       AND M.ATP_FLAG = 'N'
       AND M.INVENTORY_ITEM_STATUS_CODE != 'Inactive'
       AND CIC.INVENTORY_ITEM_ID = M.INVENTORY_ITEM_ID
       AND CIC.ORGANIZATION_ID = M.ORGANIZATION_ID
       AND CIC.COST_TYPE_ID = 1
       AND CIC.ITEM_COST <> 0;
    
    IF V_COUNT > 0 THEN
      RETURN 1;
    ELSE
      RETURN 0;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN 0;
  END F_CHK_ERP_STANDARD_COST;
  
  -----------------------------------------------------------------------------
  -- AUTHOR  : hejy3
  -- CREATED : 2018-7-4
  -- PURPOSE : 款项处理过程
  -----------------------------------------------------------------------------
  PROCEDURE P_CUSTOMER_AMOUNT_PROCESS(IN_ENTITY_ID       IN NUMBER, --主体ID
                                      IN_ORDER_TYPE_ID   IN NUMBER, --单据类型ID
                                      IN_ORDER_TYPE_CODE IN VARCHAR2, --类型编码
                                      IN_CUSTOMER_ID     IN NUMBER, --客户ID
                                      IN_ACCOUNT_ID      IN NUMBER, --账户ID
                                      IN_SALES_MAIN_TYPE IN VARCHAR2, --营销大类
                                      IN_ACTION_TYPE     IN NUMBER, --动作标识
                                      IN_SOURCE_TYPE     IN NUMBER, --来源类型，取码表SO_SRC_TYPE
                                      IN_ORDER_ID        IN NUMBER, --订单ID
                                      IN_PROJ_NUMBER     IN VARCHAR2, --项目号
                                      IN_DISCOUNT_TYPE   IN VARCHAR2, --折扣类型
                                      IN_AMOUNT          IN NUMBER, --金额
                                      IN_DIS_AMOUNT      IN NUMBER, --折让金额
                                      IN_RECORD_ERR      IN VARCHAR2, --是否记录回款错误信息
                                      IN_USER_CODE       IN VARCHAR2, --操作用户
                                      OUT_RESULT         IN OUT VARCHAR2 --处理结果
                                      ) IS
    R_ORDER_TYPE T_PLN_ORDER_TYPE%ROWTYPE;
    V_RETURN_NUMBER NUMBER;
    V_ENTITY_NAME V_BD_ENTITY.entity_name%TYPE;
    v_OS_ATTRIB01           Varchar2(1000);
    v_OS_ATTRIB02           Varchar2(1000);
    V_AMOUNT_TIP            VARCHAR2(200);
    v_Action_Type number;
    v_Message varchar2(1000);
    R_CUST_ACC V_CUSTOMER_ACCOUNT_SALECENTER%ROWTYPE;
  BEGIN
    OUT_RESULT := v_Success;
    IF IN_ORDER_TYPE_ID <> -1 THEN
      BEGIN
        SELECT T.*
          INTO R_ORDER_TYPE
          FROM T_PLN_ORDER_TYPE T
         WHERE T.ORDER_TYPE_ID = IN_ORDER_TYPE_ID;
      EXCEPTION
        WHEN OTHERS THEN
          OUT_RESULT := '按单据类型ID查找单据类型失败，单据类型ID=' || TO_CHAR(IN_ORDER_TYPE_ID) || v_Nl ||
                        '系统提示：' || sqlerrm || v_Nl ||
                        dbms_utility.format_error_backtrace;
          Raise v_Base_Exception;
      END;
    END IF;
    
    SELECT E.entity_name
      INTO V_ENTITY_NAME
      FROM V_BD_ENTITY E
     WHERE E.entity_id = IN_ENTITY_ID;
    
    BEGIN
      SELECT S.*
        INTO R_CUST_ACC
        FROM V_CUSTOMER_ACCOUNT_SALECENTER S
       WHERE S.entity_id = IN_ENTITY_ID
         AND S.account_id = IN_ACCOUNT_ID;
    EXCEPTION
      WHEN OTHERS THEN
        OUT_RESULT := '按主体、账户ID查找客户账户信息失败，主体ID=' || TO_CHAR(IN_ENTITY_ID) || '，账户ID=' || TO_CHAR(IN_ACCOUNT_ID) || v_Nl ||
                      '系统提示：' || sqlerrm || v_Nl ||
                      dbms_utility.format_error_backtrace;
        Raise v_Base_Exception;
    END;
    
    V_AMOUNT_TIP := '事业部=' || V_ENTITY_NAME || ',产品大类=' || IN_SALES_MAIN_TYPE || ',折扣类型=' || IN_DISCOUNT_TYPE || v_Nl ||
                    '客户ID=' || TO_CHAR(R_CUST_ACC.customer_id) || ',编码=' || R_CUST_ACC.customer_code || v_Nl ||
                    '账户ID=' || TO_CHAR(R_CUST_ACC.account_id) || ',编码=' || R_CUST_ACC.account_code;
  
    If Nvl(IN_AMOUNT, 0) + Nvl(IN_DIS_AMOUNT, 0) <> 0 Then
      --检查并锁定资金
      If Nvl(Upper(r_Order_Type.Is_Business_Control), '_') <> 'PRO_ORDER' OR IN_ORDER_TYPE_ID = -1 Then
        Pkg_Credit_Account_Control.Prc_Credit_Order_Bill(p_Entity_Id       => IN_ENTITY_ID,
                                                         p_Action_Type     => IN_ACTION_TYPE,
                                                         p_Settlement_Sum  => Nvl(IN_AMOUNT, 0),
                                                         p_Discount_Sum    => Nvl(IN_DIS_AMOUNT, 0),
                                                         p_Sales_Main_Type => IN_SALES_MAIN_TYPE,
                                                         p_Account_Id      => IN_ACCOUNT_ID,
                                                         p_Customer_Id     => IN_CUSTOMER_ID,
                                                         p_Proj_Number     => IN_PROJ_NUMBER,
                                                         p_Order_Id        => IN_ORDER_ID,
                                                         P_ORDER_TYPE      => IN_ORDER_TYPE_CODE, --传入订单类型编码
                                                         p_Username        => IN_USER_CODE,
                                                         p_Result          => V_RETURN_NUMBER,
                                                         p_Err_Msg         => OUT_RESULT,
                                                         IS_DISCOUNT_TYPE  => IN_DISCOUNT_TYPE --折扣类型
                                                         );
        If OUT_RESULT <> v_Success Then
          if IN_RECORD_ERR = 'Y' then
            --add by lizhen 2017-09-25 订金不足时记录异常信息，供违约报表查询数据
            pkg_pln_lg_order.p_Insert_Review_Error(In_Lg_Order_Head   => IN_ORDER_ID,
                                  In_Sales_Main_Type => IN_SALES_MAIN_TYPE,
                                  In_Discount_Type   => IN_DISCOUNT_TYPE,
                                  In_Amount          => Nvl(IN_AMOUNT, 0),
                                  In_Discount_Amount => Nvl(IN_DIS_AMOUNT, 0),
                                  In_Error_Msg       => OUT_RESULT,
                                  In_User_Code       => IN_USER_CODE,
                                  Out_Result         => v_Message);
          end if;

          IF IN_ACTION_TYPE = 1 THEN
            OUT_RESULT := '检查并锁定金额失败！' || v_Nl || V_AMOUNT_TIP || v_Nl || OUT_RESULT;
          ELSIF IN_ACTION_TYPE = 2 THEN
            OUT_RESULT := '解锁金额失败！' || v_Nl || V_AMOUNT_TIP || v_Nl || OUT_RESULT;
          ELSIF IN_ACTION_TYPE = 28 THEN
            OUT_RESULT := '解锁订金加锁款项失败！' || v_Nl || V_AMOUNT_TIP || v_Nl || OUT_RESULT;
          ELSIF IN_ACTION_TYPE = 29 THEN
            OUT_RESULT := '解锁款项加锁订金失败！' || v_Nl || V_AMOUNT_TIP || v_Nl || OUT_RESULT;
          ELSE
            OUT_RESULT := '传入动作标识错误，接受的动作标识为(1、2、28、29)，当前动作标识为('||TO_CHAR(IN_ACTION_TYPE)||')';
          END IF;
          Raise v_Base_Exception;
        End If;
        
        If Nvl(IN_DISCOUNT_TYPE, v_Discount_Type_Common) = v_Discount_Type_Discount Then
          PKG_CREDIT_DIS.P_CHECK_DIS_AMOUNT(IN_ACTION_TYPE     => IN_ACTION_TYPE, --操作类型 与信用控制动作标识一致
                                            IN_ENTITY_ID       => IN_ENTITY_ID, --主体ID
                                            IN_ACCOUNT_ID      => IN_ACCOUNT_ID, --客户账户ID
                                            IS_SOURCE_TYPE     => IN_SOURCE_TYPE, --来源类型 取码表SO_SRC_TYPE
                                            IN_SOURCE_BILL_ID  => IN_ORDER_ID, --来源单据ID 取相应的单据头ID
                                            IS_SALES_MAIN_TYPE => IN_SALES_MAIN_TYPE, --营销大类
                                            IS_DISCOUNT_TYPE   => IN_DISCOUNT_TYPE, --折扣类型 取行上的折扣类型
                                            IN_AMOUNT          => IN_AMOUNT, --金额
                                            Is_User_Name       => IN_USER_CODE, --用户编码
                                            IS_ATTRIB01        => Null, --预留输入参数01
                                            IS_ATTRIB02        => Null, --预留输入参数02
                                            ON_RESULT          => V_RETURN_NUMBER, --成功则返回0，否则返回对应的出错代码
                                            OS_MESSAGE         => OUT_RESULT, --成功返回“SUCCESS”；失败返回出错信息
                                            OS_ATTRIB01        => v_OS_ATTRIB01, --预留输出参数01
                                            OS_ATTRIB02        => v_OS_ATTRIB02 --预留输出参数02
                                            );
          If OUT_RESULT <> v_Success Then
            if IN_RECORD_ERR = 'Y' then
              --add by lizhen 2017-09-25 订金不足时记录异常信息，供违约报表查询数据
              pkg_pln_lg_order.p_Insert_Review_Error(In_Lg_Order_Head   => IN_ORDER_ID,
                                    In_Sales_Main_Type => IN_SALES_MAIN_TYPE,
                                    In_Discount_Type   => IN_DISCOUNT_TYPE,
                                    In_Amount          => Nvl(IN_AMOUNT, 0),
                                    In_Discount_Amount => Nvl(IN_DIS_AMOUNT, 0),
                                    In_Error_Msg       => OUT_RESULT,
                                    In_User_Code       => IN_USER_CODE,
                                    Out_Result         => v_Message);
            end if;
            
            IF IN_ACTION_TYPE = 1 THEN
              OUT_RESULT := '折扣类型金额处理，检查并锁定金额失败！' || v_Nl || V_AMOUNT_TIP || v_Nl || OUT_RESULT;
            ELSIF IN_ACTION_TYPE = 2 THEN
              OUT_RESULT := '折扣类型金额处理，解锁金额失败！' || v_Nl || V_AMOUNT_TIP || v_Nl || OUT_RESULT;
            ELSIF IN_ACTION_TYPE = 28 THEN
              OUT_RESULT := '折扣类型金额处理，解锁订金加锁款项失败！' || v_Nl || V_AMOUNT_TIP || v_Nl || OUT_RESULT;
            ELSIF IN_ACTION_TYPE = 29 THEN
              OUT_RESULT := '折扣类型金额处理，解锁款项加锁订金失败！' || v_Nl || V_AMOUNT_TIP || v_Nl || OUT_RESULT;
            ELSE
              OUT_RESULT := '传入动作标识错误，接受的动作标识为(1、2、28、29)，当前动作标识为('||TO_CHAR(IN_ACTION_TYPE)||')';
            END IF;
            Raise v_Base_Exception;
          End If;
        End If;
      Else
        /*--推广物料提货订单提货类型
          01  销售提货
          02  物料领用
          03  资源领用*/
        IF IN_ACTION_TYPE = 1 THEN
          Select Decode(r_Order_Type.Order_Lg_Type,
                        Null,
                        1,
                        '01',
                        1,
                        '02',
                        40,
                        '03',
                        32,
                        1)
            Into v_Action_Type
            From Dual;
        ELSIF IN_ACTION_TYPE = 2 THEN
          Select Decode(r_Order_Type.Order_Lg_Type,
                        Null,
                        2,
                        '01',
                        2,
                        '02',
                        40,
                        '03',
                        33,
                        2)
            Into v_Action_Type
            From Dual;
        ELSIF IN_ACTION_TYPE IN (28, 29) THEN
          v_Action_Type := IN_ACTION_TYPE;
        else
          OUT_RESULT := '传入动作标识错误，接受的动作标识为(1、2、28、29)，当前动作标识为('||TO_CHAR(IN_ACTION_TYPE)||')';
          Raise v_Base_Exception;
        END IF;
        --推广物料资源送审锁款
        Pkg_Credit_Control_Pmt.Prc_Credit_Control_Pmt(p_Entity_Id       => IN_ENTITY_ID, --主ID体
                                                      p_Action_Type     => v_Action_Type, --动作标示（32：资源提货订单评审，33：资源提货订单取消  40:提货领用）
                                                      p_Settlement_Sum  => Nvl(IN_AMOUNT, 0), --结算金额
                                                      p_Discount_Sum    => Nvl(IN_DIS_AMOUNT, 0), --折扣金额
                                                      p_Sales_Main_Type => IN_SALES_MAIN_TYPE, --营销大类
                                                      p_Order_Id        => IN_ORDER_ID, --单据ID
                                                      p_Account_Id      => IN_ACCOUNT_ID, --账户ID
                                                      p_Customer_Id     => IN_CUSTOMER_ID, --客户ID
                                                      p_Proj_Number     => Null, --项目号
                                                      p_Created_Mode    => Null, --开单方式
                                                      p_Order_Type      => IN_ORDER_TYPE_CODE, --传入订单类型编码
                                                      p_Username        => IN_USER_CODE,
                                                      p_Result          => V_RETURN_NUMBER, --返回错误ID
                                                      p_Err_Msg         => OUT_RESULT--返回错误信息
                                                      );
        If OUT_RESULT <> v_Success Then
          IF IN_ACTION_TYPE = 1 THEN
            OUT_RESULT := '检查并锁定金额失败！' || v_Nl || V_AMOUNT_TIP || v_Nl || OUT_RESULT;
          ELSIF IN_ACTION_TYPE = 2 THEN
            OUT_RESULT := '解锁金额失败！' || v_Nl || V_AMOUNT_TIP || v_Nl || OUT_RESULT;
          ELSIF IN_ACTION_TYPE = 28 THEN
            OUT_RESULT := '解锁订金加锁款项失败！' || v_Nl || V_AMOUNT_TIP || v_Nl || OUT_RESULT;
          ELSIF IN_ACTION_TYPE = 29 THEN
            OUT_RESULT := '解锁款项加锁订金失败！' || v_Nl || V_AMOUNT_TIP || v_Nl || OUT_RESULT;
          END IF;
          Raise v_Base_Exception;
        End If;
      End If;
    End If;
  EXCEPTION
    When v_Base_Exception Then
      OUT_RESULT := Substrb(OUT_RESULT, 1, 3000);
      --Rollback;
    When Others Then
      OUT_RESULT := Substrb(OUT_RESULT || v_Nl || Sqlerrm, 1, 3000);
      --Rollback;
  END P_CUSTOMER_AMOUNT_PROCESS;
  -----------------------------------------------------------------------------
  -- AUTHOR  : huanghb12
  -- CREATED : 2018-9-18
  -- PURPOSE : 更新提货订单预排信息
  -----------------------------------------------------------------------------
  PROCEDURE P_UPD_LG_CONSIGNMENT_SINGLE(p_Walkthrough_Batch In Varchar2, --预排批次
                                        p_Opertation_Action In Varchar2, --预排批次 
                                        p_User_Code         In Varchar2, --用户
                                        p_Result            Out Varchar2 --返回结果
                                        ) IS
    V_ENTITY_ID NUMBER;
    V_PERIOD_DAY NUMBER;
  BEGIN
    p_Result := v_Success;
    --如果传入'预排'动作
    IF V_OPERATION_ACTION_WALKTHROUGH = p_Opertation_Action THEN
      BEGIN
        SELECT H.ENTITY_ID INTO V_ENTITY_ID
          FROM INTF_PLN_ORDER_WALKTHROUGH_REC R,
               T_PLN_LG_COLLECT_HEAD H
         WHERE R.WALKTHROUGH_BATCH = p_Walkthrough_Batch
           AND R.ORDER_NUMBER = H.COLLECT_NUMBER
           AND ROWNUM = 1;
      EXCEPTION
        WHEN OTHERS THEN
          V_ENTITY_ID := NULL;
      END;
      
      --获取T+3周期天数
      BEGIN
        SELECT TO_NUMBER(pkg_bd.F_GET_PARAMETER_VALUE('PLN_ORDER_PERIOD_TN',
                                                      V_ENTITY_ID,
                                                      NULL,
                                                      NULL))
          INTO V_PERIOD_DAY
          FROM dual;
      EXCEPTION
        WHEN OTHERS THEN
          V_PERIOD_DAY := 3;
      END;
    
      --将查询结果插入临时表
      INSERT INTO T_WALKTHROUGH_INFO_TMP
        (ID,
         ORDER_LINE_ID,
         WALKTHROUGH_DATE,
         CONSIGNMENT_PERIOD,
         ENTITY_ID,
         WALKTHROUGH_BATCH)
        
        SELECT S_T_WALKTHROUGH_INFO_TMP.NEXTVAL,
               ORDER_LINE_ID,
               WALKTHROUGH_DATE,
               CONSIGNMENT_PERIOD,
               ENTITY_ID,
               WALKTHROUGH_BATCH
          FROM (
        SELECT LCL.ORDER_LINE_ID,
               OWR.WALKTHROUGH_DATE,
               /*(SELECT POP.PERIOD_CODE
                  FROM T_PLN_ORDER_PERIOD POP
                 WHERE TRUNC(OWR.WALKTHROUGH_DATE) BETWEEN POP.BEGIN_DATE AND
                       POP.END_DATE
                   AND POP.PERIOD_TYPE = 'T+3周期'
                   AND POP.ENTITY_ID = LCL.ENTITY_ID)*/
               PKG_PLN_PUB.F_GET_PERIOD_CODE(V_PERIOD_DAY, TRUNC(OWR.WALKTHROUGH_DATE), 'T+3周期') CONSIGNMENT_PERIOD,
               LCL.ENTITY_ID,
               OWR.WALKTHROUGH_BATCH
          FROM INTF_PLN_ORDER_WALKTHROUGH_REC OWR,
               T_PLN_LG_COLLECT_HEAD          LCH,
               T_PLN_LG_COLLECT_LINE_WT       CLW,
               T_PLN_LG_COLLECT_LINE          LCL
         WHERE OWR.ORDER_LINE_ID = CLW.LINE_WT_ID
           AND CLW.COLLECT_HEAD_ID = LCH.COLLECT_HEAD_ID
           AND OWR.ORDER_NUMBER = LCH.COLLECT_NUMBER --增加单号关联
           AND LCL.ITEM_ID = CLW.ITEM_ID
           AND LCL.ITEM_CODE = CLW.ITEM_CODE
           AND LCL.MRP_ORG_CODE = CLW.MRP_ORG_CODE
           AND LCL.COLLECT_HEAD_ID = CLW.COLLECT_HEAD_ID
           AND LCH.BATCH_CODE = OWR.WALKTHROUGH_BATCH
           AND OWR.WALKTHROUGH_BATCH = p_Walkthrough_Batch
        UNION ALL
        SELECT --S_T_WALKTHROUGH_INFO_TMP.NEXTVAL,
               LCR.LG_ORDER_LINE_ID ORDER_LINE_ID,
               OWR.WALKTHROUGH_DATE,
               PKG_PLN_PUB.F_GET_PERIOD_CODE(V_PERIOD_DAY, TRUNC(OWR.WALKTHROUGH_DATE), 'T+3周期') CONSIGNMENT_PERIOD,
               LCL.ENTITY_ID,
               OWR.WALKTHROUGH_BATCH
          FROM INTF_PLN_ORDER_WALKTHROUGH_REC OWR,
               T_PLN_LG_WT_COLLECT_H          LCH,
               T_PLN_LG_WT_COLLECT_L          LCL,
               T_PLN_LG_COLLECT_R             LCR
         WHERE OWR.ORDER_LINE_ID = LCL.COLLECT_LINE_ID
           AND LCL.COLLECT_HEAD_ID = LCH.COLLECT_HEAD_ID
           AND LCL.COLLECT_LINE_ID = LCR.COLLECT_LINE_ID
           AND LCH.PRE_FIELD_17 = OWR.WALKTHROUGH_BATCH
           AND NVL(LCH.PRE_FIELD_20, '_') <> '计划订单'
           AND OWR.WALKTHROUGH_BATCH = p_Walkthrough_Batch);
           
      --只要是临时表中的数据，都是参与预排的产品,不管反馈的日期是否发生变化，所以预排次数都+1
      MERGE INTO CIMS.T_PLN_LG_ORDER_LINE TL
      USING (SELECT TMP.*
               FROM CIMS.T_WALKTHROUGH_INFO_TMP TMP
              WHERE TMP.WALKTHROUGH_BATCH = p_Walkthrough_Batch
                ) UT
      ON (UT.ORDER_LINE_ID = TL.ORDER_LINE_ID)
      WHEN MATCHED THEN
        UPDATE --更新预排信息
           SET TL.WALKTHROUGH_TIME        = nvl(TL.WALKTHROUGH_TIME,0) + 1, --更新参与预排次数
               TL.LAST_UPDATED_BY         = p_User_Code,
               TL.LAST_UPDATE_DATE        = SYSDATE,
               TL.VERSION                 = TL.VERSION + 1;      
         
      --首次预排日期不为空，预排反馈日期所在周期发生了变化
      MERGE INTO CIMS.T_PLN_LG_ORDER_LINE TL
      USING (SELECT TMP.*
               FROM CIMS.T_WALKTHROUGH_INFO_TMP TMP,
                    CIMS.T_PLN_LG_ORDER_LINE    TOL
              WHERE TMP.ORDER_LINE_ID = TOL.ORDER_LINE_ID
                AND TMP.WALKTHROUGH_BATCH = p_Walkthrough_Batch
                AND TOL.FIRST_WALKTHROUGH_DATE IS NOT NULL -- 首次预排日期不为空，说明预排过一次
                AND PKG_PLN_PUB.F_GET_PERIOD_CODE(V_PERIOD_DAY, TRUNC(TOL.LAST_WALKTHROUGH_DATE), 'T+3周期')
                    <> TMP.CONSIGNMENT_PERIOD --预排时间所在的周期与提货订单上最新预约时间所在的周期不一致
                /*AND EXISTS
              (SELECT 1
                       FROM T_PLN_ORDER_PERIOD POP
                      WHERE TRUNC(TOL.LAST_WALKTHROUGH_DATE) BETWEEN
                            POP.BEGIN_DATE AND POP.END_DATE
                        AND POP.PERIOD_TYPE = 'T+3周期'
                        AND POP.PERIOD_CODE <> TMP.CONSIGNMENT_PERIOD --预排时间所在的周期与提货订单上最新预约时间所在的周期不一致
                        AND POP.ENTITY_ID = TOL.ENTITY_ID)*/) UT
      ON (UT.ORDER_LINE_ID = TL.ORDER_LINE_ID)
      WHEN MATCHED THEN
        UPDATE --更新预排信息
           SET --TL.WALKTHROUGH_TIME        = TL.WALKTHROUGH_TIME + 1, --更新参与预排次数
               TL.WALKTHROUGH_CHANGE_TIME = TL.WALKTHROUGH_CHANGE_TIME + 1, --更新预排变更次数
               TL.ESTIMATE_DATE_CHG_TIME  = CASE
                                              WHEN TL.LAST_WALKTHROUGH_DATE < UT.WALKTHROUGH_DATE THEN
                                               TL.ESTIMATE_DATE_CHG_TIME + 1 --若反馈预排时间比最新预排时间晚，则客户交期变更次数+1
                                              ELSE
                                               TL.ESTIMATE_DATE_CHG_TIME --若反馈预排时间比最新预排时间提前或者不变，则客户交期变更次数不变
                                            END,
               TL.LAST_WALKTHROUGH_DATE   = UT.WALKTHROUGH_DATE, --更新最新预排日期
               TL.LAST_UPDATED_BY         = p_User_Code,
               TL.LAST_UPDATE_DATE        = SYSDATE,
               TL.VERSION                 = TL.VERSION + 1;
               
      --首次预排日期不为空，将预排反馈时间发生变化的其它情况，最新预排时间
      MERGE INTO CIMS.T_PLN_LG_ORDER_LINE TL
      USING (SELECT TMP.*
               FROM CIMS.T_WALKTHROUGH_INFO_TMP TMP,
                    CIMS.T_PLN_LG_ORDER_LINE    TOL
              WHERE TMP.ORDER_LINE_ID = TOL.ORDER_LINE_ID
                AND TMP.WALKTHROUGH_BATCH = p_Walkthrough_Batch
                AND TOL.FIRST_WALKTHROUGH_DATE IS NOT NULL -- 首次预排日期不为空，说明预排过一次
                AND TOL.LAST_UPDATE_DATE <> TMP.WALKTHROUGH_DATE --反馈的鱼排时间与最新预排时间不一致
                ) UT
      ON (UT.ORDER_LINE_ID = TL.ORDER_LINE_ID)
      WHEN MATCHED THEN
        UPDATE --更新预排信息
           SET --TL.WALKTHROUGH_TIME        = TL.WALKTHROUGH_TIME + 1, --更新参与预排次数
               TL.LAST_WALKTHROUGH_DATE   = UT.WALKTHROUGH_DATE, --更新最新预排日期
               TL.LAST_UPDATED_BY         = p_User_Code,
               TL.LAST_UPDATE_DATE        = SYSDATE,
               TL.VERSION                 = TL.VERSION + 1; 
               
      --首次预排日期为空
      MERGE INTO CIMS.T_PLN_LG_ORDER_LINE TL
      USING (SELECT TMP.*
               FROM T_WALKTHROUGH_INFO_TMP TMP
              WHERE TMP.WALKTHROUGH_BATCH = p_Walkthrough_Batch) UT
      ON (UT.ORDER_LINE_ID = TL.ORDER_LINE_ID)
      WHEN MATCHED THEN
        UPDATE --更新预排信息
           SET TL.LAST_WALKTHROUGH_DATE   = UT.WALKTHROUGH_DATE,
               TL.FIRST_WALKTHROUGH_DATE  = UT.WALKTHROUGH_DATE,
               --TL.WALKTHROUGH_TIME        = 1,
               TL.WALKTHROUGH_CHANGE_TIME = 0,
               TL.ESTIMATE_DATE_CHG_TIME  = 0,
               TL.CONSIGNMENT_PERIOD      = UT.CONSIGNMENT_PERIOD,
               TL.LAST_UPDATED_BY         = p_User_Code,
               TL.LAST_UPDATE_DATE        = SYSDATE,
               TL.VERSION                 = TL.VERSION + 1
         WHERE TL.FIRST_WALKTHROUGH_DATE IS NULL;
      
      --更新销司主体订单行的相应数据 19-12-2 lilh6
      MERGE INTO CIMS.T_PLN_LG_ORDER_LINE TL
      USING (Select tol.ORDER_LINE_ID,
                    tol.HQ_LG_ORDER_LINE_ID,
                    tol.FIRST_WALKTHROUGH_DATE,
                    tol.LAST_WALKTHROUGH_DATE,
                    tol.WALKTHROUGH_TIME,
                    tol.WALKTHROUGH_CHANGE_TIME,
                    tol.ESTIMATE_DATE_CHG_TIME,
                    tol.CONSIGNMENT_PERIOD
               FROM T_WALKTHROUGH_INFO_TMP TMP,
                    T_PLN_LG_ORDER_LINE    TOL
              WHERE TMP.WALKTHROUGH_BATCH = p_Walkthrough_Batch
                And TMP.ORDER_LINE_ID = TOL.ORDER_LINE_ID
                And tol.HQ_LG_ORDER_LINE_ID Is Not Null) UT
      ON (UT.HQ_LG_ORDER_LINE_ID = TL.ORDER_LINE_ID)
      WHEN MATCHED THEN
        UPDATE --更新预排信息
           SET TL.FIRST_WALKTHROUGH_DATE   = UT.FIRST_WALKTHROUGH_DATE,
               TL.LAST_WALKTHROUGH_DATE  = UT.LAST_WALKTHROUGH_DATE,
               TL.WALKTHROUGH_TIME = ut.WALKTHROUGH_TIME,
               TL.WALKTHROUGH_CHANGE_TIME      = UT.WALKTHROUGH_CHANGE_TIME,
               TL.ESTIMATE_DATE_CHG_TIME =  UT.ESTIMATE_DATE_CHG_TIME,
               TL.CONSIGNMENT_PERIOD        = ut.CONSIGNMENT_PERIOD,
               TL.LAST_UPDATED_BY         = p_User_Code,
               TL.LAST_UPDATE_DATE        = SYSDATE,
               TL.VERSION                 = TL.VERSION + 1;
         
      --删除临时表数据
      DELETE FROM T_WALKTHROUGH_INFO_TMP TMP
       WHERE TMP.WALKTHROUGH_BATCH = p_Walkthrough_Batch;
    ELSIF p_Opertation_Action = V_OPERATION_ACTION_PRODUCE THEN
      UPDATE T_PLN_LG_ORDER_LINE OL
         SET OL.INVSALE_RATIO_PROMPT = NULL,
             OL.DEMAND_FORECAST_PROMPT = NULL,
             OL.LINE_EFFECTIVE_FLAG = 'Y',
             OL.CAPACITY_INSUFFICIENT_FLAG = 'N',
             OL.LAST_UPDATE_DATE = SYSDATE,
             OL.VERSION = NVL(OL.VERSION, 0) + 1
       WHERE EXISTS (SELECT 1
                      FROM T_PLN_ORDER_COLLECT_RELATION CR, T_PLN_LG_RELATION R
                     WHERE CR.ORDER_COLLECT_HEAD_ID = TO_NUMBER(p_Walkthrough_Batch)
                       AND CR.ORDER_LINE_ID = R.ORDER_LINE_ID
                       AND R.LG_ORDER_LINE_ID = OL.ORDER_LINE_ID);
    END IF;
  Exception
    When Others Then
      p_Result := '更新订单行预排信息失败!' || Sqlerrm;
  END P_UPD_LG_CONSIGNMENT_SINGLE;
  
  -----------------------------------------------------------------------------
  -- AUTHOR  : hejy3
  -- CREATED : 2018-10-18
  -- PURPOSE : 获取订单周期
  -----------------------------------------------------------------------------
  FUNCTION F_GET_PERIOD_CODE(IN_PERIOD_DAY   IN NUMBER, --周期天数
                              IN_CAL_DATE    IN DATE, --日期
                              IN_PERIOD_TYPE IN VARCHAR2 --周期类型：T+3周期、周
                              ) RETURN VARCHAR2
  IS
    V_PERIOD_CODE VARCHAR2(50);
  BEGIN
    IF IN_PERIOD_TYPE = 'T+3周期' THEN
      IF IN_CAL_DATE IS NULL THEN
        V_PERIOD_CODE := NULL;
      ELSE
        SELECT case
                 when ceil(to_number(to_char(IN_CAL_DATE, 'dd')) / IN_PERIOD_DAY) >=
                   trunc(to_number(to_char(last_day(IN_CAL_DATE), 'dd')) / IN_PERIOD_DAY) then
                   to_char(IN_CAL_DATE, 'yyyy') || '年' ||
                   to_char(IN_CAL_DATE, 'mm') || '月' ||
                   lpad(to_char(trunc(to_number(to_char(last_day(IN_CAL_DATE), 'dd')) / IN_PERIOD_DAY)), 2, '0') || '周'
                 when mod(to_number(to_char(IN_CAL_DATE, 'dd')), IN_PERIOD_DAY) = 0 then
                   to_char(IN_CAL_DATE, 'yyyy') || '年' ||
                   to_char(IN_CAL_DATE, 'mm') || '月' ||
                   lpad(to_char(trunc(to_number(to_char(IN_CAL_DATE, 'dd')) / IN_PERIOD_DAY)), 2, '0') || '周'
                 else
                   to_char(IN_CAL_DATE, 'yyyy') || '年' ||
                   to_char(IN_CAL_DATE, 'mm') || '月' ||
                   lpad(to_char(trunc(to_number(to_char(IN_CAL_DATE, 'dd')) / IN_PERIOD_DAY) + 1), 2, '0') || '周'
               end
          INTO V_PERIOD_CODE
          FROM DUAL;
      END IF;
      RETURN V_PERIOD_CODE;
    END IF;
  END F_GET_PERIOD_CODE;
  
  -----------------------------------------------------------------------------
  -- AUTHOR  : hejy3
  -- CREATED : 2018-10-10
  -- PURPOSE : 记录订单评审出错信息
  -----------------------------------------------------------------------------
  PROCEDURE P_RECORD_LG_ORDER_REVIEW_LOG(IN_ENTITY_ID     IN NUMBER,
                                         IN_ORDER_HEAD_ID IN NUMBER,
                                         IN_REVIEW_SUMMARY IN VARCHAR2,
                                         IN_REVIEW_DETAIL IN VARCHAR2,
                                         IN_USER_CODE     IN VARCHAR2)
  IS
    pragma autonomous_transaction; --独立事务
  BEGIN
    --更新当天记录
    UPDATE T_PLN_ORDER_REVIEW_LOG L
       SET L.REVIEW_SUMMARY = IN_REVIEW_SUMMARY,
           L.REVIEW_DETIAL = SUBSTR(IN_REVIEW_DETAIL, 1, 1300),
           L.LAST_UPDATED_BY = IN_USER_CODE,
           L.LAST_UPDATE_DATE = SYSDATE
     WHERE L.REVIEW_DATE = TRUNC(SYSDATE)
       AND L.ENTITY_ID = IN_ENTITY_ID
       AND L.ORDER_HEAD_ID = IN_ORDER_HEAD_ID;
    
    --当天找不到记录则新增
    IF SQL%NOTFOUND THEN
      insert into t_pln_order_review_log
        (review_log_id,
         review_date,
         entity_id,
         order_head_id,
         review_summary,
         review_detial,
         created_by,
         creation_date,
         last_updated_by,
         last_update_date)
      values
        (s_pln_order_review_log.nextval,
         trunc(sysdate),
         IN_ENTITY_ID,
         IN_ORDER_HEAD_ID,
         IN_REVIEW_SUMMARY,
         SUBSTR(IN_REVIEW_DETAIL, 1, 1300),
         IN_USER_CODE,
         sysdate,
         IN_USER_CODE,
         sysdate);
    END IF;
    
    commit;
  EXCEPTION
    WHEN OTHERS THEN
      NULL;
  END P_RECORD_LG_ORDER_REVIEW_LOG;
  -----------------------------------------------------------------------------
  -- AUTHOR  : lilh6
  -- CREATED : 2019-3-4
  -- PURPOSE : 更新可补货数据，同时记录操作历史
  -----------------------------------------------------------------------------
  Procedure p_Update_Dx_Make_Up_Qty(p_Dx_Order_Number In Varchar2, --代销单号
                                    p_Item_Code       In Varchar2, --产品编码
                                    p_Qty             In Number, --数量
                                    p_Sign_Flag       In Number, --符号方向,增加传1，减少传-1
                                    p_Operate_Type    In Varchar2, --操作类型，写具体触发步骤
                                    p_Operate_Number  In Varchar2, --操作单号或id
                                    p_User_Code       In Varchar2, --用户
                                    p_Result          Out Varchar2 --返回结果
                                    ) Is
    r_Dx_Order_Line t_Pln_Dx_Order_Line%Rowtype; --代销单行
  Begin
    p_Result := v_Success;
    --获取代销单行
    Begin
      Select *
        Into r_Dx_Order_Line
        From t_Pln_Dx_Order_Line l
       Where l.Item_Code = p_Item_Code
         And l.Order_Head_Id =
             (Select h.Order_Head_Id
                From t_Pln_Dx_Order_Head h
               Where h.Order_Number = p_Dx_Order_Number);
    Exception
      When Others Then
        p_Result := '找不到代销单行信息，代销单号：' || p_Dx_Order_Number || '，产品编码：' ||
                    p_Item_Code || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;
  
    --判断符号方向
    If p_Sign_Flag <> 1 And p_Sign_Flag <> -1 Then
      p_Result := '符号方向错误，增加传1，减少传-1。当前符号方向：' || p_Sign_Flag;
      Raise v_Base_Exception;
    End If;
  
    If p_Result = v_Success Then
      --更新代销单行的可补货数量
      Update t_Pln_Dx_Order_Line l
         Set l.Make_Up_Qty      = Nvl(l.Make_Up_Qty, 0) +
                                  p_Qty * p_Sign_Flag,
             l.Last_Updated_By  = p_User_Code,
             l.Last_Update_Date = Sysdate,
             l.Version          = Nvl(l.Version, 0) + 1
       Where l.Order_Line_Id = r_Dx_Order_Line.Order_Line_Id;
      --写入历史记录
      Insert Into t_Pln_Dx_Makeup_Qty_His
        (Entity_Id,
         Id,
         order_number,
         Order_Head_Id, --代销单头id
         Order_Line_Id, --代销单行id
         Operate_Type, --操作类型，具体触发步骤
         Operate_Number, --操作单号或id
         Qty, --数量
         Created_By,
         Creation_Date,
         Last_Updated_By,
         Last_Update_Date)
      Values
        (r_Dx_Order_Line.Entity_Id,
         s_Pln_Dx_Makeup_Qty_His.Nextval,
         p_Dx_Order_Number,
         r_Dx_Order_Line.Order_Head_Id,
         r_Dx_Order_Line.Order_Line_Id,
         p_Operate_Type, --操作类型，具体触发步骤
         p_Operate_Number,
         p_Qty * p_Sign_Flag,
         p_User_Code,
         Sysdate,
         p_User_Code,
         Sysdate);
    End If;
  Exception
    When v_Base_Exception Then
      p_Result := p_Result;
      Rollback;
    When Others Then
      p_Result := '更新可补货数据，同时记录操作历史出错，错误信息' || Sqlerrm;
      Rollback;
  End p_Update_Dx_Make_Up_Qty;
  
  ----------------------------------------------------------------------------
  --是否定制机，且返回甲方客户、销司、代理商
  ----------------------------------------------------------------------------
  PROCEDURE P_GET_CUSTOMIZE_INFO(IN_ENTITY_ID         IN NUMBER,
                                 IN_PG_APPLY_CODE     IN VARCHAR2,
                                 IN_ITEM_CODE         IN VARCHAR2,
                                 OUT_CUSTOMIZE_FLAG   OUT VARCHAR2,
                                 OUT_ACCOUNT_ID       OUT NUMBER,
                                 OUT_SC_ACCOUNT_ID    OUT NUMBER,
                                 OUT_AGENT_ACCOUNT_ID OUT NUMBER)
  IS 
    V_PROJECT_CODE T_PG_PRICE_APPLY_HEAD.PROJECT_CODE%TYPE;
    V_ORI_BUSINESS_CODE INTF_PG_BUSINESS_BID.ORI_BUSINESS_CODE%TYPE;
    V_COUNT NUMBER;
    V_SALES_CENTER_ID NUMBER;
    V_FIRSTPART_ACCOUNTID NUMBER;
    V_HAVE_BID BOOLEAN := TRUE;
  BEGIN
    --按工程批文号找登录号
    BEGIN
      SELECT H.PROJECT_CODE,
             H.ACCOUNT_ID
        INTO V_PROJECT_CODE,
             OUT_ACCOUNT_ID
        FROM T_PG_PRICE_APPLY_HEAD H
       WHERE H.ENTITY_ID = IN_ENTITY_ID
         AND H.APPLY_CODE = IN_PG_APPLY_CODE;
    EXCEPTION
      WHEN OTHERS THEN
        OUT_CUSTOMIZE_FLAG := 'N';
        RETURN;
    END;
    
    --分配表
    BEGIN
      SELECT B.ORI_BUSINESS_CODE,
             B.FIRSTPART_ACCOUNTID
        INTO V_ORI_BUSINESS_CODE,
             V_FIRSTPART_ACCOUNTID
        FROM INTF_PG_BUSINESS_BID B
       WHERE B.PROJECT_CODE = V_PROJECT_CODE
         AND B.ENTITY_ID = IN_ENTITY_ID
         /*AND B.SOURCE_SYSTEM = 'CRM'*/;
    EXCEPTION
      WHEN OTHERS THEN
        V_HAVE_BID := FALSE;
        V_ORI_BUSINESS_CODE := NULL;
        V_FIRSTPART_ACCOUNTID := NULL;
    END;
    
    --是否存在询价单
    SELECT COUNT(1)
      INTO V_COUNT
      FROM T_PG_QUERY_PRICE P
     WHERE P.PROJECT_CODE = V_PROJECT_CODE--NVL(V_ORI_BUSINESS_CODE, V_PROJECT_CODE)
       AND P.ITEM_CODE = IN_ITEM_CODE;
    
    IF V_COUNT > 0 THEN
      OUT_CUSTOMIZE_FLAG := 'Y';
      
      --按来源登录查找代理商和销司
      IF V_HAVE_BID THEN --有分配信息
        --销司（总部甲方）
        IF V_PROJECT_CODE = V_ORI_BUSINESS_CODE THEN
          IF OUT_ACCOUNT_ID = V_FIRSTPART_ACCOUNTID THEN
            --取销司
            BEGIN
              SELECT R.HQ_ACCOUNT_ID
                INTO OUT_SC_ACCOUNT_ID
                FROM T_BD_CENTER_RELATION R,
                     V_CUSTOMER_ACCOUNT_SALECENTER S
               WHERE R.HQ_SALES_CENTER_ID = S.sales_center_id
                 AND S.account_id = OUT_ACCOUNT_ID
                 AND R.HQ_ENTITY_ID = IN_ENTITY_ID
                 AND ROWNUM = 1;
            EXCEPTION
              WHEN OTHERS THEN
                OUT_SC_ACCOUNT_ID := NULL;
            END;
          ELSE
            OUT_AGENT_ACCOUNT_ID := V_FIRSTPART_ACCOUNTID;
          END IF;
        ELSE
          --代理商
          BEGIN
            SELECT B.ACCOUNT_ID, B.SALES_CENTER_ID
              INTO OUT_AGENT_ACCOUNT_ID, V_SALES_CENTER_ID
              FROM T_PG_BUSINESS B
             WHERE B.PROJECT_CODE = V_ORI_BUSINESS_CODE;
          EXCEPTION
            WHEN OTHERS THEN
              OUT_AGENT_ACCOUNT_ID := NULL;
              V_SALES_CENTER_ID := NULL;
          END;

          BEGIN
            SELECT R.HQ_ACCOUNT_ID
              INTO OUT_SC_ACCOUNT_ID
              FROM T_BD_CENTER_RELATION R
             WHERE R.SC_SALES_CENTER_ID = V_SALES_CENTER_ID
               AND R.HQ_ENTITY_ID = IN_ENTITY_ID
               AND ROWNUM = 1;
          EXCEPTION
            WHEN OTHERS THEN
              OUT_SC_ACCOUNT_ID := NULL;
          END;
        END IF;
      END IF;
    ELSE
      OUT_CUSTOMIZE_FLAG := 'N';
    END IF;
  
  END P_GET_CUSTOMIZE_INFO;

  ------------------------------------------------------------------------------------------
  -- AUTHOR  : huanghb12
  -- CREATED : 2020-04-10
  -- PURPOSE : 校验失败的时候写入接口表sym_intf_cims_message_push，接口表的信息用于ccs发短信用
  ------------------------------------------------------------------------------------------
  Procedure p_Insert_cims_message_push(r_Lg_Order_Head          t_Pln_Lg_Order_Head%Rowtype,
                                  In_Sales_Main_Type Varchar2,
                                  In_Discount_Type   Varchar2,
                                  In_Amount          Number,
                                  In_Discount_Amount Number,
                                  In_Error_Msg       Varchar2,
                                  In_User_Code       Varchar2) Is
    Pragma Autonomous_Transaction; 
    v_Credit_Amount          Number; --可用到款余额
    v_credit_Group_Id        Number;
    v_Credit_Discount_Amount Number;--可用折让余额
    --r_Lg_Order_Head          t_Pln_Lg_Order_Head%Rowtype;
   
    v_msg Varchar2(4000);
  Begin
 
    /*Begin
      v_Pln_Down_Break_Contract := Pkg_Bd.f_Get_Parameter_Value('PLN_LG_DOWN_BREAK_CONTRACT',
                                                              r_Lg_Order_Head.Entity_Id);
    Exception
      When Others Then
        v_Pln_Down_Break_Contract := 'N';
    End;
    
    If v_Pln_Down_Break_Contract  = 'N' Then
      Return;
    End If;   */  

  --获取客户额度组
   begin
      v_credit_Group_Id := Pkg_Credit_Tools.FUN_GET_CREDITGROUPID (p_Entity_Id       => r_Lg_Order_Head.Entity_Id,
                                                                 p_Customer_Id     => r_Lg_Order_Head.Customer_Id,
                                                                 p_Sales_Main_Type => In_Sales_Main_Type,
                                                                 IN_ACCOUNT_ID      => r_Lg_Order_Head.Account_Id );
   Exception
    When Others Then
      v_credit_Group_Id := -1;
      v_msg := PKG_BD.F_ADD_ERROR_LOG('PKG_PLN_PUB.P_INSERT_CIMS_MESSAGE_PUSH',
                                                         sqlcode,
                                                         '获取额度组失败'||sqlerrm);
  End;
   
  
    --获取客户账户的到款余额
    begin
       v_Credit_Amount := Pkg_Credit_Tools.Fun_Get_Amount(p_Entity_Id       => r_Lg_Order_Head.Entity_Id,
                                                       p_Customer_Id     => r_Lg_Order_Head.Customer_Id,
                                                       p_Account_Id      => r_Lg_Order_Head.Account_Id,
                                                       p_Sales_Main_Type => In_Sales_Main_Type,
                                                       p_Flag            => 1,
                                                       Is_Discount_Type  => In_Discount_Type);
   Exception
    When Others Then
      v_Credit_Amount := 0;
      v_msg := PKG_BD.F_ADD_ERROR_LOG('PKG_PLN_PUB.P_INSERT_CIMS_MESSAGE_PUSH',
                                                         sqlcode,
                                                         '获取客户到款余额失败'||sqlerrm);
    End;
   
  
    --获取客户账户折扣余额
    v_Credit_Discount_Amount := Pkg_Credit_Tools.Fun_Get_Amount(p_Entity_Id       => r_Lg_Order_Head.Entity_Id,
                                                                p_Customer_Id     => r_Lg_Order_Head.Customer_Id,
                                                                p_Account_Id      => r_Lg_Order_Head.Account_Id,
                                                                p_Sales_Main_Type => In_Sales_Main_Type,
                                                                p_Flag            => 2,
                                                                Is_Discount_Type  => In_Discount_Type);
     
    INSERT INTO SYM_INTF_CIMS_MESSAGE_PUSH 
            ( ID,
              SUP_CAT_ID,
              SUP_CUST_CODE,
              SUP_CUST_NAME,
              BILL_DATE,
              BILL_IN_AMOUNT,
              CREATED_BY,
              CREATION_DATE,
              SUP_DEPT_CODE,
              SUP_DEPT_NAME,
              AVAILABLE_AMOUNT,
              SOURCE_TYPE, --来源类型
              DEPT_NAME    --额度组
            )
      VALUES(
           SYM_SQ_INTF_CIMS_MESSAGE_PUSH.NEXTVAL,                                 
           r_Lg_Order_Head.Entity_Id,       
           r_Lg_Order_Head.Customer_Code,
           r_Lg_Order_Head.Customer_Name,
           r_Lg_Order_Head.Order_Date,
           nvl(In_Amount,0), --  本次评审金额
           'CIMS',
           SYSDATE,
           r_Lg_Order_Head.Sales_Center_Code,
           r_Lg_Order_Head.Sales_Center_Name,
           (v_Credit_Amount+v_Credit_Discount_Amount), --  可提货金额 = 到款余额+折让余额
           1,               --调剂
           (select c.credit_group_name             --额度组名称
             from T_CREDIT_GROUP C
             where c.credit_group_id = nvl(v_credit_Group_Id,-1))
      );

    Commit;
  Exception
    When Others Then
    v_msg := PKG_BD.F_ADD_ERROR_LOG('PKG_PLN_PUB.P_INSERT_CIMS_MESSAGE_PUSH',
                                     sqlcode,
                                     '校验信息时候写入接口表失败'||',主体'||
                                     r_Lg_Order_Head.Entity_Id||',客户'||       
                                     r_Lg_Order_Head.Customer_Code||','|| 
                                     r_Lg_Order_Head.Customer_Name||',状态'||
                                     r_Lg_Order_Head.Order_Head_State||',大类'||  
                                     In_Sales_Main_Type||',折扣类型'|| 
                                     In_Discount_Type||',日期'|| 
                                     r_Lg_Order_Head.Order_Date|| ',评审金额'|| 
                                     In_Amount||','||  --  本次评审金额
                                     'CIMS'|| ','|| 
                                     SYSDATE|| ',中心'|| 
                                     r_Lg_Order_Head.Sales_Center_Code|| ','|| 
                                     r_Lg_Order_Head.Sales_Center_Name|| ',客户可用到款余额'|| 
                                     v_Credit_Amount||',客户折让余额'||   --  客户余额
                                     v_Credit_Discount_Amount||','||   --  客户折让余额
                                     1|| ',额度组'||                --调剂
                                     v_credit_Group_Id||','||
                                     sqlerrm
                                   );
  End;
End Pkg_Pln_Pub;
/

