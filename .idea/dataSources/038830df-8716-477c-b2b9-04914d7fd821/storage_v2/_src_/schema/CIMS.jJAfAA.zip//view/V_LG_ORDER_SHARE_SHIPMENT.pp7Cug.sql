create view V_LG_ORDER_SHARE_SHIPMENT as
select c.district_code,c.district_name,a."ENTITY_ID",a."ORDER_SHARE_ID",a."SALES_CENTER_ID",a."SALES_CENTER_CODE",a."SALES_CENTER_NAME",a."CUSTOMER_ID",a."CUSTOMER_CODE",a."CUSTOMER_NAME",a."ACCOUNT_ID",a."ACCOUNT_CODE",a."ACCOUNT_NAME",a."ITEM_ID",a."ITEM_CODE",a."ITEM_NAME",a."ITEM_UOM",a."UNIT_VOLUME",a."PRODUCING_AREA_ID",a."PRICE_LIST_ID",a."PRICE_SYSTEM_ID",a."DISCOUNT_TYPE_ID",a."SALES_ORDER_TYPE_ID",a."LIST_PRICE",a."DISCOUNT_RATE",a."ORDERED_DISCOUNT_RATE",a."SHARE_QTY",a."INV_SHARE_FLAG",a."SHAREING_QTY",a."CANCELING_QTY",a."CARRY_QTY",a."CARRYING_QTY",a."SO_ORDER_QTY",a."PLAN_SEND_DATE",a."ORIGIN_TYPE",a."ORIGIN_HEAD_ID",a."ORIGIN_HEAD_CODE",a."ORIGIN_LINE_ID",a."SOURCE_ORDER_SHARE_ID",a."INVENTORY_FROM_ID",a."INVENTORY_CODE_FROM",a."INVENTORY_DESC_FROM",a."INVENTORY_TO_ID",a."RCV_INV_CODE",a."RCV_INV_NAME",a."INVOICE_CONTRACT_ID",a."INVOICE_CONTRACT",a."INVOICE_TEL",a."INCEPT_ADDRESS_ID",a."CONSIGNEE_ID",a."CONSIGNEE_CODE",a."CONSIGNEE_NAME",a."CONSIGNEE_ADDRESS_NAME",a."CONSIGNEE_EXTEND_ADDR",a."CONSIGNEE_ADDRESS_CODE",a."CONSIGNEE_CONTACT_ID",a."CONSIGNEE_CONTRACT",a."CONSIGNEE_TEL",a."SHIP_MODE",a."IS_PICK_FLAG",a."IS_CUSG_FLAG",a."TRANSFER_CUST_ID",a."TRANSFER_CUST_CODE",a."TRANSFER_CUST_NAME",a."CLOSE_FLAG",a."RE_CAL_MARK",a."CARRY_ERROR_MSG",a."PROJECT_ORDER_TYPE",a."PROJECT_ORDER_NUMBER",a."APPLY_LIST_PRICE",a."APPLY_DISCOUNT_RATE",a."PROJECT_ORDER_LINE_ID",a."CREATED_BY",a."CREATION_DATE",a."LAST_UPDATED_BY",a."LAST_UPDATE_DATE",a."ORDER_RELATION_ID",a."REMARK",a."PRE_FIELD_01",a."PRE_FIELD_02",a."PRE_FIELD_03",a."PRE_FIELD_04",a."PRE_FIELD_05",a."PRE_FIELD_06"
from T_PLN_ORDER_SHARE_SHIPMENT a,T_INV_INVENTORIES b,T_BD_DISTRICT c
where a.INVENTORY_FROM_ID = b.inventory_id
and b.district_id = c.row_id
with read only
/

comment on table V_LG_ORDER_SHARE_SHIPMENT is '制定发货需求计划（原T_PLN4_WEEK_ORDER_SHARE）'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.DISTRICT_CODE is '地区编码'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.DISTRICT_NAME is '地区名称'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.ENTITY_ID is '业务主体'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.ORDER_SHARE_ID is '订单分配ID'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.SALES_CENTER_ID is '营销中心ID'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.SALES_CENTER_CODE is '营销中心编码'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.SALES_CENTER_NAME is '营销中心名称'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.CUSTOMER_ID is '客户ID'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.CUSTOMER_CODE is '客户编码'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.CUSTOMER_NAME is '客户名称'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.ACCOUNT_ID is '账户ID'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.ACCOUNT_CODE is '账户编码'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.ACCOUNT_NAME is '账户名称'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.ITEM_ID is '产品ID'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.ITEM_CODE is '产品编码'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.ITEM_NAME is '产品名称'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.ITEM_UOM is '产品单位'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.UNIT_VOLUME is '套件单位体积'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.PRODUCING_AREA_ID is '产地ID'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.PRICE_LIST_ID is '价格列表ID'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.PRICE_SYSTEM_ID is '价格体系ID'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.DISCOUNT_TYPE_ID is '折扣类型ID'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.SALES_ORDER_TYPE_ID is '销售单据类型（数据来源销售管理）'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.LIST_PRICE is '列表价格'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.DISCOUNT_RATE is '折扣率'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.ORDERED_DISCOUNT_RATE is '月返。从价格列表获取的折扣（荣事达洗衣机需求）'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.SHARE_QTY is '已分配数量'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.INV_SHARE_FLAG is '库存评审分配标志（该条记录是否来源库存评审）'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.SHAREING_QTY is '分配数量（总数量）'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.CANCELING_QTY is '待取消数量'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.CARRY_QTY is '已下达数量'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.CARRYING_QTY is '下达数量（总数量）'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.SO_ORDER_QTY is '已开单数量'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.PLAN_SEND_DATE is '计划发货日期'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.ORIGIN_TYPE is '来源类型（订单、调拨）'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.ORIGIN_HEAD_ID is '来源头ID（订单头ID）'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.ORIGIN_HEAD_CODE is '来源头编码（订单编码）'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.ORIGIN_LINE_ID is '来源行ID（订单行ID）'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.SOURCE_ORDER_SHARE_ID is '来源组织ID（调拨单生成后回写该字段）'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.INVENTORY_FROM_ID is '发货仓库ID'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.INVENTORY_CODE_FROM is '发货仓库编码'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.INVENTORY_DESC_FROM is '发货仓库名称'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.INVENTORY_TO_ID is '收货仓库ID（？调拨使用）'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.RCV_INV_CODE is '收货仓库编码（？调拨使用）'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.RCV_INV_NAME is '收货仓库名称（？调拨使用）'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.INVOICE_CONTRACT_ID is '开票单位联系人ID'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.INVOICE_CONTRACT is '开票单位联系人'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.INVOICE_TEL is '开票单位联系电话'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.INCEPT_ADDRESS_ID is '收货地点ID'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.CONSIGNEE_ID is '收货单位ID'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.CONSIGNEE_CODE is '收货单位编码'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.CONSIGNEE_NAME is '收货单位名称'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.CONSIGNEE_ADDRESS_NAME is '收货单位地址'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.CONSIGNEE_EXTEND_ADDR is '收货扩展地址（主要应用与工程机）'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.CONSIGNEE_ADDRESS_CODE is '收货单位地址编码（物流根据该编码选择承运商）'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.CONSIGNEE_CONTACT_ID is '收货单位联系人ID'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.CONSIGNEE_CONTRACT is '收货单位联系人'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.CONSIGNEE_TEL is '收货单位联系电话'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.SHIP_MODE is '发运方式（汽运、海运、空运、自提）'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.IS_PICK_FLAG is '是否自提（是否放在发运方式里？）'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.IS_CUSG_FLAG is '是否直发标志'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.TRANSFER_CUST_ID is '直发客户ID（从IMS获取）'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.TRANSFER_CUST_CODE is '直发客户编码'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.TRANSFER_CUST_NAME is '直发客户名称'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.CLOSE_FLAG is '单据关闭标志（Y：表示已分配数量已开完销售单据， N：未开完单据，C：分配数量为0的单据行）'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.RE_CAL_MARK is '重算财务单数量标志 0：不重算    1：需重算'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.CARRY_ERROR_MSG is '下达运力任务错误信息'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.PROJECT_ORDER_TYPE is '申请类型（原批文）'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.PROJECT_ORDER_NUMBER is '申请编码（原批文）'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.APPLY_LIST_PRICE is '申请价（原批文）'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.APPLY_DISCOUNT_RATE is '申请折扣（原批文）'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.PROJECT_ORDER_LINE_ID is '申请行ID（用于基础模块进行对应产品扣减）（原批文）'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.CREATED_BY is '创建人'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.CREATION_DATE is '创建日期'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.LAST_UPDATED_BY is '最后更新人'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.LAST_UPDATE_DATE is '最后更新时间'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.ORDER_RELATION_ID is '东芝订单关系行ID，主要用于回写已下达数量与已开单数据？'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.REMARK is '备注'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.PRE_FIELD_01 is '预留字段1'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.PRE_FIELD_02 is '预留字段2'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.PRE_FIELD_03 is '预留字段3'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.PRE_FIELD_04 is '预留字段4'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.PRE_FIELD_05 is '预留字段5'
/

comment on column V_LG_ORDER_SHARE_SHIPMENT.PRE_FIELD_06 is '预留字段6'
/

