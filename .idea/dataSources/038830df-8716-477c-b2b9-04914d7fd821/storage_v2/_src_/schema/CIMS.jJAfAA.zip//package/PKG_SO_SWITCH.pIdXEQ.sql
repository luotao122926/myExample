create PACKAGE PKG_SO_SWITCH IS
  /*----------------------------------------------------------------
  *         包：PKG_SO_SWITCH
  *   创建日期：2014-09-28
  *     创建者：廖丽章
  *   功能说明：1、数据切换-根据客户折让余额生成扣率折让单
  *
  *   过程成功：P_RESULT = 0
  *             P_ERR_MSG = 'SUCCESS';
  *
  *   过程失败：P_RESULT < -20000;
  *             P_ERR_MSG = 过程异常失败的提示信息
  *
  */ ----------------------------------------------------------------

  --临时生成扣率折让单（数据割接用）给空调
  PROCEDURE P_SO_DISCOUNT_GEN_TMP_KT(P_RESULT  OUT NUMBER, --返回错误ID
                                     P_ERR_MSG OUT VARCHAR2 --返回错误信息
                                     );

  --更新销售基础数据的序列号（数据割接用）给空调
  PROCEDURE P_SO_UPDATE_SEQUENCE_KT(P_RESULT  OUT NUMBER, --返回错误ID
                                    P_ERR_MSG OUT VARCHAR2 --返回错误信息
                                    );

  --临时生成扣率折让单（数据割接用）给厨电
  PROCEDURE P_SO_DISCOUNT_GEN_TMP_CD(P_RESULT  OUT NUMBER, --返回错误ID
                                     P_ERR_MSG OUT VARCHAR2 --返回错误信息
                                     );

  --更新销售基础数据的序列号（数据割接用）给厨电
  PROCEDURE P_SO_UPDATE_SEQUENCE_CD(P_RESULT  OUT NUMBER, --返回错误ID
                                    P_ERR_MSG OUT VARCHAR2 --返回错误信息
                                    );

  PROCEDURE 备注;
  FUNCTION FN_SIGN(PRM_STR VARCHAR2) RETURN VARCHAR2;
  PROCEDURE BD_PARAM;
  PROCEDURE P_MAKE_SQL(PRM_TABLE_NAME VARCHAR2);

END PKG_SO_SWITCH;
/

