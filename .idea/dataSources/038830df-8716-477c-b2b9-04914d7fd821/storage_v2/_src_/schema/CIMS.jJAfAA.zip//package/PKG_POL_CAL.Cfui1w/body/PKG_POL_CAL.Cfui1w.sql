create PACKAGE BODY PKG_POL_CAL AS

  TYPE STRING_ARRAY IS TABLE OF VARCHAR2(1000) INDEX BY BINARY_INTEGER;
  
  -----------------------------------------------------------------------------
  --      获取主体语义                                                       --
  -----------------------------------------------------------------------------
  PROCEDURE P_GET_ENTITY_SEMANTIC(IN_SEMANTIC_CODE          IN VARCHAR2  --语义编码
                                 ,IN_ENTITY_ID              IN NUMBER    --主体ID
                                 ,OS_SEMANTIC_TYPE          OUT VARCHAR2 --语义类型：SQL取值、计算公式
                                 ,OS_SEMANTIC_VAL           OUT VARCHAR2 --取值SQL
                                 ,OS_PRE_PROC_SQL           OUT VARCHAR2 --预处理SQL
                                 ,OS_QUERY_CODE             OUT VARCHAR2 --查询条件编码
                                 ,OS_FREEZE_QUERY_CODE      OUT VARCHAR2 --冻结明细查询条件编码
                                 ,OS_MESSAGE                OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
                                 ) IS
    S_GET_VAL_SQL        VARCHAR2(4000);
    S_GET_VAL_EXPRESSION VARCHAR2(240);
    S_PRE_PROC_SQL       VARCHAR2(4000);
  BEGIN
    OS_MESSAGE := 'OK';

    --取系统语义
    BEGIN
      SELECT S.SEMANTIC_TYPE
           , S.GET_VAL_SQL
           , S.GET_VAL_EXPRESSION
           , S.QUERY_CODE
           , S.PRE_PROC_SQL
           , S.FREEZE_QUERY_CODE
        INTO OS_SEMANTIC_TYPE
           , S_GET_VAL_SQL
           , S_GET_VAL_EXPRESSION
           , OS_QUERY_CODE
           , S_PRE_PROC_SQL
           , OS_FREEZE_QUERY_CODE
        FROM T_POL_SEMANTIC S
       WHERE S.SEMANTIC_CODE = IN_SEMANTIC_CODE
         AND S.ENTITY_ID = IN_ENTITY_ID;
      --判断语义类型
      IF (OS_SEMANTIC_TYPE = '1') THEN  --1:'SQL取值'
        OS_SEMANTIC_VAL := S_GET_VAL_SQL;
        OS_PRE_PROC_SQL := S_PRE_PROC_SQL;
      ELSE
        OS_SEMANTIC_VAL := S_GET_VAL_EXPRESSION;
      END IF;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        OS_MESSAGE := '没有定义系统语义(' ||IN_SEMANTIC_CODE || ')';
    END;

  END;

  -----------------------------------------------------------------------------
  --  检查数据库表达式的正确性，将[]内的内容转换成“1”，再执行
  --  出错则返回出错信息，否则返回“OK”   
  -----------------------------------------------------------------------------
  FUNCTION F_CHECK_EXPR
  (
    IS_EXPRESSION       IN  VARCHAR2     --EXCEL表达式
  )
  RETURN VARCHAR2
  IS
    S_CHAR VARCHAR2(3);
    S_STR VARCHAR2(1000);
    S_RESULT VARCHAR2(1000);
    N_INDEX NUMBER;
    N_COUNT NUMBER;
    B_IN_QUOTES BOOLEAN := FALSE;
    N_BEGIN NUMBER;
    N_CUR NUMBER;
    N_ROW NUMBER;
  BEGIN
    S_RESULT := 'OK';
    N_COUNT := LENGTH(IS_EXPRESSION);
    N_BEGIN := 1;
    S_STR := '';
    --循环字符串，查找分隔符，对取出的字符作相应的处理
    FOR N_INDEX IN 1..N_COUNT LOOP
      S_CHAR := SUBSTR(IS_EXPRESSION, N_INDEX, 1);
      IF S_CHAR = '''' THEN
        --引号则设置为引号内/外，在后面的处理中处理拼接
        B_IN_QUOTES := NOT B_IN_QUOTES;
      ELSIF NOT B_IN_QUOTES THEN
        --处理引号外的内容
        IF S_CHAR = '[' THEN
          --记录之前的内容
          S_STR := S_STR || SUBSTR(IS_EXPRESSION, N_BEGIN, N_INDEX-N_BEGIN);
        ELSIF S_CHAR = ']' THEN
          --将[]内的内容转换成1
          S_STR := S_STR || '1';
          --记录括号起始位置
          N_BEGIN := N_INDEX+1;
        END IF;
      END IF;
    END LOOP;
    IF N_BEGIN <= N_COUNT THEN
      --将最后的内容拼接到公式中
      S_STR := S_STR || SUBSTR(IS_EXPRESSION, N_BEGIN, N_COUNT-N_BEGIN+1);
    END IF;
    --执行公式
    BEGIN
      --打开光标
      N_CUR := DBMS_SQL.OPEN_CURSOR;
      --解析动态SQL语句
      DBMS_SQL.PARSE(N_CUR, 'SELECT ' || S_STR || ' FROM DUAL', DBMS_SQL.NATIVE);
      --执行语句
      N_ROW := DBMS_SQL.EXECUTE(N_CUR);
    EXCEPTION
      WHEN OTHERS THEN
        S_RESULT := '试算公式出错：' || SQLERRM;
    END;
    --关闭光标
    DBMS_SQL.CLOSE_CURSOR(N_CUR);
    
    RETURN S_RESULT;
  END F_CHECK_EXPR;

  -----------------------------------------------------------------------------
  --  政策算法定义检查过程：                                                 --
  -----------------------------------------------------------------------------
  PROCEDURE P_DEFINE_CHECK(IN_POLICY_ID          IN NUMBER     --政策ID
                          ,OS_MESSAGE            OUT VARCHAR2   --成功则返回“OK”，否则返回出错信息
                          ) IS
    --政策算法定义
    CURSOR C_DEFINE IS
      SELECT T.DEFINE_ID
            ,T.DEFINE_GROUP
            ,T.DEFINE_CODE
            ,T.DEFINE_NAME
            ,T.GET_VAL_TYPE
            ,T.PRIOR_LEVEL
            ,T.SEM_CODE
            ,T.SEM_EXP
            ,T.SEM_BEGIN_DATE
            ,T.SEM_END_DATE
            ,T.DETAIL_FLAG
            ,T.CAL_EXP
            ,T.CAL_DB_EXP
            ,T.MTL_TYPE
            ,T.CONDITION
            ,T.OUT_DATA_CODE
            ,T.COMMENTS
        FROM T_POL_POLICY_DEFINE T
       WHERE T.POLICY_ID = IN_POLICY_ID
       ORDER BY T.DEFINE_CODE;
    R_DEFINE C_DEFINE%ROWTYPE;
    N_COUNT      NUMBER;
    N_ENTITY_ID  NUMBER;
    S_RESULT_DEFINE_CODE VARCHAR2(32);
    S_MTL_FLAG   VARCHAR2(2);
    S_EXP        VARCHAR2(2000);
    S_DISCOUNT_PERIOD VARCHAR2(32);
    S_POL_USE_DIS_PERIOD VARCHAR2(5);
  BEGIN
    OS_MESSAGE := 'OK';
    
    --检查是否有定义应计返利对应的项目
    SELECT
      ENTITY_ID
     ,RESULT_DEFINE_CODE
     ,DISCOUNT_PERIOD
    INTO
      N_ENTITY_ID
     ,S_RESULT_DEFINE_CODE
     ,S_DISCOUNT_PERIOD
    FROM
      T_POL_POLICY
    WHERE
      POLICY_ID = IN_POLICY_ID;
    IF S_RESULT_DEFINE_CODE IS NULL THEN
      OS_MESSAGE := '应计返利对应的项目不能为空！';
    ELSE
      --检查是否存在对应的编码
      SELECT
        COUNT(*)
      INTO
        N_COUNT
      FROM
        T_POL_POLICY_DEFINE
      WHERE
        POLICY_ID = IN_POLICY_ID
        AND DEFINE_CODE = S_RESULT_DEFINE_CODE;
      IF (N_COUNT = 0) THEN
        OS_MESSAGE := '应计返利对应的项目不正确！';
      END IF;
    END IF;
    
    IF S_DISCOUNT_PERIOD IS NULL THEN
      PKG_BD.P_GET_PARAMETER_VALUE('POL_USE_DIS_PERIOD',N_ENTITY_ID,NULL,NULL,S_POL_USE_DIS_PERIOD);
      IF S_POL_USE_DIS_PERIOD = 'Y' THEN
        OS_MESSAGE := '算法分组对应的归属返利周期不能为空！';
      END IF;
    END IF;
    
    --检查是否存在重复项
    IF (OS_MESSAGE = 'OK') THEN
      SELECT COUNT(*)
        INTO N_COUNT
        FROM T_POL_POLICY_DEFINE D1,
             T_POL_POLICY_DEFINE D2
       WHERE D1.DEFINE_CODE = D2.DEFINE_CODE
         AND D1.DEFINE_ID <> D2.DEFINE_ID
         AND D1.POLICY_ID = IN_POLICY_ID
         AND D2.POLICY_ID = IN_POLICY_ID;
      IF (N_COUNT > 0) THEN
        OS_MESSAGE := '项目代码不允许重复！';
      END IF;
    END IF;
    
    --检查是否存在客户分类
    IF (OS_MESSAGE = 'OK') THEN
      SELECT COUNT(*)
        INTO N_COUNT
        FROM T_POL_POLICY_CUS_TYPE
       WHERE POLICY_ID = IN_POLICY_ID;
      IF (N_COUNT = 0) THEN
        --检查父政策是否存在客户分类
        SELECT
          COUNT(*)
        INTO
          N_COUNT
        FROM
          T_POL_POLICY P
          ,T_POL_POLICY_CUS_TYPE T
        WHERE
          P.PARENT_POLICY_ID = T.POLICY_ID
          AND P.POLICY_ID = IN_POLICY_ID;
        IF N_COUNT = 0 THEN
          OS_MESSAGE := '政策对应的客户分类未定义！';
        END IF;
      END IF;
    END IF;
    

    --循环检查每个算法项设置
    IF (OS_MESSAGE = 'OK') THEN
      FOR R_DEFINE IN C_DEFINE
      LOOP
        IF (OS_MESSAGE = 'OK') THEN

          --检查“语义”
          IF (R_DEFINE.GET_VAL_TYPE = '1') THEN
            --语义检查：存在商品分类，则检查是否存在对应的定义
            IF (R_DEFINE.SEM_CODE IS NULL) THEN
              --语义编码
              OS_MESSAGE := '“语义”项目的语义编码不允许为空！(项目代码=' || R_DEFINE.DEFINE_CODE || ')';
            ELSIF (R_DEFINE.SEM_EXP IS NULL) THEN
              --语义表达式
              OS_MESSAGE := '“语义”项目的语义表达式不允许为空！(项目代码=' || R_DEFINE.DEFINE_CODE || ')';
            ELSIF (R_DEFINE.SEM_BEGIN_DATE IS NULL) THEN
              --语义开始日期
              OS_MESSAGE := '“语义”项目的语义开始日期不允许为空！(项目代码=' || R_DEFINE.DEFINE_CODE || ')';
            ELSIF (R_DEFINE.SEM_END_DATE IS NULL) THEN
              --语义结束日期
              OS_MESSAGE := '“语义”项目的语义结束日期不允许为空！(项目代码=' || R_DEFINE.DEFINE_CODE || ')';
            ELSIF (R_DEFINE.SEM_BEGIN_DATE > R_DEFINE.SEM_END_DATE) THEN
              --语义日期范围
              OS_MESSAGE := '“语义”项目的语义开始日期不允许大于语义结束日期！(项目代码=' || R_DEFINE.DEFINE_CODE || ')';
            ELSIF R_DEFINE.MTL_TYPE IS NULL THEN
              --取语义
              SELECT
                MTL_FLAG
              INTO
                S_MTL_FLAG
              FROM
                T_POL_SEMANTIC
              WHERE
                SEMANTIC_CODE = R_DEFINE.SEM_CODE
                AND ENTITY_ID = N_ENTITY_ID;
              
              --语义要求有商品分类，则检查是否存在对应的分类数据
              IF S_MTL_FLAG = 'Y' THEN
                --检查是否有对应的分类
                SELECT
                  COUNT(*)
                INTO
                  N_COUNT
                FROM
                  T_POL_POLICY_MTL_TYPE
                WHERE
                  POLICY_ID = IN_POLICY_ID
                  AND ROWNUM = 1;
                IF N_COUNT = 0 THEN
                  OS_MESSAGE := '“语义”项目需定义商品分类，而未定义！(项目代码=' || R_DEFINE.DEFINE_CODE || ')';
                ELSE
                  OS_MESSAGE := '“语义”项目需选择商品取值分类，而未选择！(项目代码=' || R_DEFINE.DEFINE_CODE || ')';
                END IF;
              END IF;
              
            END IF;
          ELSIF (R_DEFINE.GET_VAL_TYPE = '2') THEN
            --检查“计算公式”，计算公式需能正常转换
            IF (R_DEFINE.CAL_EXP IS NULL) THEN
              OS_MESSAGE := '“计算公式”项目的计算公式不允许为空！(项目代码=' || R_DEFINE.DEFINE_CODE || ')';
            ELSE
              --检查是否能正常转换
              BEGIN
                S_EXP := F_GET_DB_EXPRESSION(R_DEFINE.CAL_EXP);
                OS_MESSAGE := F_CHECK_EXPR(S_EXP);
                IF OS_MESSAGE <> 'OK' THEN
                  OS_MESSAGE := '“计算公式”项目的计算公式定义不正确！(项目代码=' || R_DEFINE.DEFINE_CODE || ')' || OS_MESSAGE;
                END IF;
              EXCEPTION
                WHEN OTHERS THEN
                  OS_MESSAGE := '“计算公式”项目的计算公式定义不正确！(项目代码=' || R_DEFINE.DEFINE_CODE || ')' || SQLERRM;
              END;
            END IF;
          ELSIF (R_DEFINE.GET_VAL_TYPE = '3') THEN
            --检查“外部数据”
            IF (R_DEFINE.OUT_DATA_CODE IS NULL) THEN
              OS_MESSAGE := '“外部数据”项目的外部数据编码不允许为空！(项目代码=' || R_DEFINE.DEFINE_CODE || ')';
            END IF;
          END IF;

        ELSE
          EXIT;
        END IF;
      END LOOP;
    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      OS_MESSAGE := '政策算法定义检查过程出错！' || SQLERRM;
  END;

  -----------------------------------------------------------------------------
  --  根据台阶兑现标准生成计算公式：                                         --
  -----------------------------------------------------------------------------
  PROCEDURE P_CREATE_DEF_STD_EXP(IN_DEFINE_ID          IN NUMBER     --算法定义ID
                                ,IS_STD_STEP_FLAG      IN VARCHAR2   --是否区分台阶
                                ,OS_CAL_EXP           OUT VARCHAR2   --计算公式
                                ,OS_MESSAGE           OUT VARCHAR2   --成功则返回“OK”，否则返回出错信息
                                ) IS
    --台阶列表
    CURSOR C_STD_LIST IS
        SELECT PS.STD_ID
             , PS.CUSTOMER_TYPE
             , PS.BASE_QTY_DEF_ID
             , PS.SWITCH_STD_DEF_ID
             , PS.JUDGE_BEGIN_OPER
          FROM T_POL_POLICY_DEF_STD PS
         WHERE PS.DEFINE_ID = IN_DEFINE_ID
         ORDER BY PS.SORT_NUMBER;
    R_STD_LIST C_STD_LIST%ROWTYPE;
    --台阶标准值
    CURSOR C_STEP_STD(IN_STD_ID NUMBER) IS
      SELECT *
        FROM (SELECT PS.STEP01
                   , PS.STD01
                   , 1 SORT_NUM
                FROM T_POL_POLICY_DEF_STD PS
               WHERE PS.STD_ID = IN_STD_ID
                 AND PS.STEP01 IS NOT NULL
              UNION
              SELECT PS.STEP02
                   , PS.STD02
                   , 2 SORT_NUM
                FROM T_POL_POLICY_DEF_STD PS
               WHERE PS.STD_ID = IN_STD_ID
                 AND PS.STEP02 IS NOT NULL
              UNION
              SELECT PS.STEP03
                   , PS.STD03
                   , 3 SORT_NUM
                FROM T_POL_POLICY_DEF_STD PS
               WHERE PS.STD_ID = IN_STD_ID
                 AND PS.STEP03 IS NOT NULL
              UNION
              SELECT PS.STEP04
                   , PS.STD04
                   , 4 SORT_NUM
                FROM T_POL_POLICY_DEF_STD PS
               WHERE PS.STD_ID = IN_STD_ID
                 AND PS.STEP04 IS NOT NULL
              UNION
              SELECT PS.STEP05
                   , PS.STD05
                   , 5 SORT_NUM
                FROM T_POL_POLICY_DEF_STD PS
               WHERE PS.STD_ID = IN_STD_ID
                 AND PS.STEP05 IS NOT NULL
             )
       ORDER BY SORT_NUM;
    R_STEP_STD C_STEP_STD%ROWTYPE;

    N_POLICY_ID             NUMBER;
    S_DEFINE_CODE           VARCHAR2(40);
    S_GET_VAL_TYPE          VARCHAR2(40);
    N_STD_LIST_NUM          NUMBER;          --兑现标准游标计数
    S_BASE_QTY_DEF_CODE     VARCHAR2(40);    --基数  
    S_SWITCH_STD_DEF_CODE   VARCHAR2(40);    --判断基准
    S_GET_VAL_EXPRESSION    VARCHAR2(4000);   --计算公式（取值公式）
    S_GET_VAL_EXP_TEMP      VARCHAR2(4000);   --计算公式（取值公式）：临时－用于串联
  BEGIN
    OS_MESSAGE := 'OK';

    --政策算法定义信息
    BEGIN
      SELECT T.DEFINE_CODE
           , T.GET_VAL_TYPE
           , T.POLICY_ID
        INTO S_DEFINE_CODE
           , S_GET_VAL_TYPE
           , N_POLICY_ID
        FROM T_POL_POLICY_DEFINE T
       WHERE T.DEFINE_ID = IN_DEFINE_ID;
    EXCEPTION
      WHEN OTHERS THEN
        OS_MESSAGE := '读取政策算法定义信息出错！(项目ID=' || TO_CHAR(IN_DEFINE_ID) || ')';
    END;

    IF (OS_MESSAGE = 'OK') AND (S_GET_VAL_TYPE <> '2') THEN  --2:计算公式
      OS_MESSAGE := '算法定义项(' || S_DEFINE_CODE || ')的取值类型请设置为计算公式！';
    END IF;

    IF (OS_MESSAGE = 'OK') THEN
      --根据阶段、政策类型打开台阶兑现游标
      N_STD_LIST_NUM := 0;
      FOR R_STD_LIST IN C_STD_LIST
      LOOP
        --计数器
        N_STD_LIST_NUM := N_STD_LIST_NUM + 1;

        --基数信息
        IF (OS_MESSAGE = 'OK') THEN
          BEGIN
            SELECT T.DEFINE_CODE
              INTO S_BASE_QTY_DEF_CODE
              FROM T_POL_POLICY_DEFINE T
             WHERE T.DEFINE_ID = R_STD_LIST.BASE_QTY_DEF_ID;        
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              OS_MESSAGE := '请设置算法定义项(' || S_DEFINE_CODE || ')的兑现标准的基数！';
          END;
        END IF;

        --判断基准
        IF (OS_MESSAGE = 'OK') THEN
          BEGIN
            SELECT T.DEFINE_CODE
              INTO S_SWITCH_STD_DEF_CODE
              FROM T_POL_POLICY_DEFINE T
             WHERE T.DEFINE_ID = R_STD_LIST.SWITCH_STD_DEF_ID;        
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              S_SWITCH_STD_DEF_CODE := NULL;
          END;
        END IF;

        --区分台阶时，判断基准设置是否正确
        IF (OS_MESSAGE = 'OK') AND (IS_STD_STEP_FLAG = 'Y') AND (S_SWITCH_STD_DEF_CODE IS NULL) THEN
          OS_MESSAGE := '请设置算法定义项(' || S_DEFINE_CODE || ')的兑现标准的判断基准！';
        END IF;

        --获取不区分台阶的计算公式
        IF (OS_MESSAGE = 'OK') AND (IS_STD_STEP_FLAG = 'N') THEN
          S_GET_VAL_EXP_TEMP := NULL;
          BEGIN
            SELECT PS.STD01
              INTO S_GET_VAL_EXP_TEMP
              FROM T_POL_POLICY_DEF_STD PS
             WHERE PS.STD_ID = R_STD_LIST.STD_ID;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              S_GET_VAL_EXP_TEMP := NULL;
          END;

          IF (S_GET_VAL_EXP_TEMP IS NULL) THEN
            OS_MESSAGE := '请设置算法定义项(' || S_DEFINE_CODE || ')的兑现标准的[标准1]！';
          END IF;
        END IF;

        --获取区分台阶的计算公式
        IF (OS_MESSAGE = 'OK') AND (IS_STD_STEP_FLAG = 'Y') THEN
          --公式初始为 0
          S_GET_VAL_EXP_TEMP := '0';
          --循环获取台阶和标准
          FOR R_STEP_STD IN C_STEP_STD(R_STD_LIST.STD_ID)
          LOOP
            IF (OS_MESSAGE = 'OK') AND (R_STEP_STD.STD01 IS NULL) THEN
              OS_MESSAGE := '算法定义项(' || S_DEFINE_CODE || ')的兑现标准的台阶标准1为空！';
            END IF;
            IF (OS_MESSAGE = 'OK') THEN
              S_GET_VAL_EXP_TEMP := 'IF([' || S_SWITCH_STD_DEF_CODE || '] ' || R_STD_LIST.JUDGE_BEGIN_OPER || ' ' || TO_CHAR(R_STEP_STD.STEP01) || ', ' 
                     || TO_CHAR(R_STEP_STD.STD01) || ', ' || S_GET_VAL_EXP_TEMP || ')';
              --SELECT 'IF(' || '[' || V_SWITCH_STD_DEF_CODE || '] ' || R_STD_LIST.JUDGE_BEGIN_OPER || ' ' || TO_CHAR(R_STEP_STD.STEP01) || ', ' 
              --       || TO_CHAR(R_STEP_STD.STD01) || ', ' || V_GET_VAL_EXP_TEMP || ')'
              --  INTO V_GET_VAL_EXP_TEMP
              --  FROM DUAL;
            END IF;
          END LOOP;
        END IF;

        --公式为兑现标准*基数
        IF (OS_MESSAGE = 'OK') AND (S_BASE_QTY_DEF_CODE IS NOT NULL) THEN
          S_GET_VAL_EXP_TEMP := S_GET_VAL_EXP_TEMP || ' * [' || S_BASE_QTY_DEF_CODE || ']';
          --SELECT S_GET_VAL_EXP_TEMP || ' * ' || '[' || S_BASE_QTY_DEF_CODE || ']'
          --  INTO S_GET_VAL_EXP_TEMP
          --  FROM DUAL;
        END IF;

        --客户分类控制
        IF (OS_MESSAGE = 'OK') AND (R_STD_LIST.CUSTOMER_TYPE IS NOT NULL) THEN
          S_GET_VAL_EXP_TEMP := 'IF(([客户分类] = ''' || R_STD_LIST.CUSTOMER_TYPE || '''), (' 
                     || S_GET_VAL_EXP_TEMP || '), 0)';
          --SELECT 'IF(([客户分类] = ' || '''' || ' || ' || '''' || '''' || '''' || '''' || ' || '
          --           || '''' || R_STD_LIST.CUSTOMER_TYPE || '''' || ' || ' || '''' || '''' || '''' || '''' || ' || ' || '''' || '), (' 
          --          || S_GET_VAL_EXP_TEMP || '), 0)'
          --  INTO S_GET_VAL_EXP_TEMP
          --  FROM DUAL;
        END IF;

        --汇总最终公式
        IF (OS_MESSAGE = 'OK') THEN
          IF (N_STD_LIST_NUM = 1) THEN
            S_GET_VAL_EXPRESSION := '(' || S_GET_VAL_EXP_TEMP || ')';
          ELSE
            S_GET_VAL_EXPRESSION := S_GET_VAL_EXPRESSION || ' + (' || S_GET_VAL_EXP_TEMP || ')';
          END IF;
        END IF;

      END LOOP;
    END IF;

    IF (OS_MESSAGE = 'OK') AND (S_GET_VAL_EXPRESSION IS NOT NULL) THEN
      OS_CAL_EXP := S_GET_VAL_EXPRESSION;
    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      OS_MESSAGE := '根据台阶兑现标准生成计算公式过程出错！(项目ID=' || TO_CHAR(IN_DEFINE_ID) || ')' || SQLERRM;
  END;

/*原算算太复杂，改为直接采用递归计算
  -----------------------------------------------------------------------------
  --  函数解释过程：百分号                                                       --
  -----------------------------------------------------------------------------
  PROCEDURE P_EXP_PERCENT(IS_EXCEL_EXPRESS      IN VARCHAR2   --EXCEL公式
                         ,OS_DB_EXPRESS        OUT VARCHAR2   --ORACLE DB公式
                         ,OS_MESSAGE           OUT VARCHAR2   --成功则返回“OK”，否则返回出错信息
                         ) IS

    S_EXCEL_EXPRESS VARCHAR2(4000);
    N_PERCENT_INDEX       NUMBER;       --百分号的位置
    N_NUMBER_INDEX        NUMBER;       --数字的开始位置
    S_CHAR                VARCHAR2(2);
    N_CNT                 NUMBER;
    S_NUM_STR             VARCHAR2(4000);
    N_CHAR_ASCII          NUMBER;
    N_EXCEL_LEN           NUMBER;
    S_FIND_FLAG           VARCHAR2(2);
  BEGIN
    OS_MESSAGE := 'OK';
    S_EXCEL_EXPRESS := IS_EXCEL_EXPRESS;

    N_PERCENT_INDEX := INSTR(IS_EXCEL_EXPRESS, '%', 1, 1);
    N_EXCEL_LEN := LENGTH(S_EXCEL_EXPRESS);

    --循环表达式中的字符
    WHILE (OS_MESSAGE = 'OK') AND ( N_PERCENT_INDEX > 0) LOOP
      N_NUMBER_INDEX := N_PERCENT_INDEX;
      S_FIND_FLAG := 'N';
      --查找数字的开始位置
      FOR N_CNT IN REVERSE 1..(N_PERCENT_INDEX - 1) LOOP
        IF (N_NUMBER_INDEX = N_PERCENT_INDEX) AND (S_FIND_FLAG = 'N') THEN
          --获取百分号前的字符
          S_CHAR := SUBSTR(S_EXCEL_EXPRESS, N_CNT, 1);
          
          --判断是否数字
          N_CHAR_ASCII := NVL(ASCII(S_CHAR), 0);
          
          --若当前字符不为数字，则更新字符INDEX
          IF (N_CHAR_ASCII NOT IN (46, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57)) THEN
            N_NUMBER_INDEX := N_CNT + 1;
            S_FIND_FLAG := 'Y';
          END IF;
          --若第1 位字符也为数字，则更新字符INDEX 为1
          IF (N_CNT = 1) AND (N_NUMBER_INDEX = N_PERCENT_INDEX) THEN
            N_NUMBER_INDEX := 1;
          END IF;
        END IF;
      END LOOP;

      IF (OS_MESSAGE = 'OK') AND (N_NUMBER_INDEX = N_PERCENT_INDEX) THEN
        OS_MESSAGE := '公式中的百分号设置有误，不能转换为小数(' || S_EXCEL_EXPRESS || ')';
      END IF;

      --获取数字总字符
      IF (OS_MESSAGE = 'OK') THEN
        S_NUM_STR := SUBSTR(S_EXCEL_EXPRESS, N_NUMBER_INDEX, (N_PERCENT_INDEX - N_NUMBER_INDEX));
        --转换为数字，然后除以100
        BEGIN
          SELECT TO_CHAR(TO_NUMBER(S_NUM_STR)/100)
            INTO S_NUM_STR
            FROM DUAL;
          IF (INSTR(S_NUM_STR, '.', 1, 1) = 1) THEN
            S_NUM_STR := '0' || S_NUM_STR;
          END IF;
        EXCEPTION
          WHEN OTHERS THEN
            OS_MESSAGE := '百分数转换为小数时出错(' || S_NUM_STR || ')';
        END;
      END IF;
      --替换原来的字符
      IF (OS_MESSAGE = 'OK') THEN
        S_EXCEL_EXPRESS := SUBSTR(S_EXCEL_EXPRESS, 1, (N_NUMBER_INDEX - 1)) || S_NUM_STR || SUBSTR(S_EXCEL_EXPRESS, (N_PERCENT_INDEX + 1), (N_EXCEL_LEN - N_PERCENT_INDEX));
        --重新获取百分号定位
        N_PERCENT_INDEX := INSTR(S_EXCEL_EXPRESS, '%', 1, 1);
        N_EXCEL_LEN := LENGTH(S_EXCEL_EXPRESS);
      END IF;
    END LOOP;

    --替换原来的字符
    IF (OS_MESSAGE = 'OK') THEN
      OS_DB_EXPRESS := S_EXCEL_EXPRESS;
    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      OS_MESSAGE := '函数解释过程：百分号(' || IS_EXCEL_EXPRESS || ')出错！' || SQLERRM;
  END;

  -----------------------------------------------------------------------------
  --  函数解释过程：SUM                                                      --
  -----------------------------------------------------------------------------
  PROCEDURE P_EXP_SUM(IN_ITEM_ID            IN NUMBER   --EXCEL公式分解表ID
                     ,IS_USER_ID            IN VARCHAR2   --用户账号
                     ,OS_MESSAGE           OUT VARCHAR2   --成功则返回“OK”，否则返回出错信息
                     ) IS

    --需进行转义或组装的EXCEL公式
    CURSOR C_ITEM_TRAN IS
      SELECT T.DB_EXP DB_EXPRESS
        FROM T_POL_POLICY_DEF_ITEM T
       WHERE T.PARENT_ID = IN_ITEM_ID
       ORDER BY T.SORT_NUMBER ASC;
    R_ITEM_TRAN C_ITEM_TRAN%ROWTYPE;

    N_CON_CNT       NUMBER;          --参数值数量
    S_DB_EXPRESS    VARCHAR2(4000);  --转换后的公式语句
  BEGIN
    OS_MESSAGE := 'OK';
    --获取参数值
    IF (OS_MESSAGE = 'OK') THEN
      N_CON_CNT := 0;
      --循环表达式的子项，拼接成ORACLE的表达式
      FOR R_ITEM_TRAN IN C_ITEM_TRAN
      LOOP
        N_CON_CNT := N_CON_CNT + 1;
        --组合字符串
        IF (N_CON_CNT = 1) THEN
          S_DB_EXPRESS := '( (' || R_ITEM_TRAN.DB_EXPRESS || ')';
        ELSE
          S_DB_EXPRESS := S_DB_EXPRESS || ' + (' || R_ITEM_TRAN.DB_EXPRESS || ')';
        END IF;
      END LOOP;

      IF (N_CON_CNT > 0) THEN
        S_DB_EXPRESS := S_DB_EXPRESS || ' )';
      END IF;
    END IF;

    --处理函数
    IF (OS_MESSAGE = 'OK') THEN
      UPDATE T_POL_POLICY_DEF_ITEM T
         SET T.DB_EXP = S_DB_EXPRESS
            ,LAST_UPDATED_BY = IS_USER_ID
            ,LAST_UPDATE_DATE = SYSDATE
       WHERE T.ITEM_ID = IN_ITEM_ID;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      OS_MESSAGE := '函数解释过程：SUM(ITEM_ID=' || TO_CHAR(IN_ITEM_ID) || ')出错！' || SQLERRM;
  END;

  -----------------------------------------------------------------------------
  --  函数解释过程：MAX                                                      --
  -----------------------------------------------------------------------------
  PROCEDURE P_EXP_MAX(IN_ITEM_ID            IN NUMBER   --EXCEL公式分解表ID
                     ,IS_USER_ID            IN VARCHAR2   --用户账号
                     ,OS_MESSAGE           OUT VARCHAR2   --成功则返回“OK”，否则返回出错信息
                     ) IS

    --需进行转义或组装的EXCEL公式
    CURSOR C_ITEM_TRAN IS
      SELECT T.DB_EXP DB_EXPRESS
        FROM T_POL_POLICY_DEF_ITEM T
       WHERE T.PARENT_ID = IN_ITEM_ID
       ORDER BY T.SORT_NUMBER ASC;
    R_ITEM_TRAN C_ITEM_TRAN%ROWTYPE;

    N_CON_CNT       NUMBER;          --参数值数量
    S_DB_EXPRESS    VARCHAR2(4000);  --转换后的公式语句
  BEGIN
    OS_MESSAGE := 'OK';
    --获取参数值
    IF (OS_MESSAGE = 'OK') THEN
      N_CON_CNT := 0;
      --循环表达式的子项，拼接成ORACLE的表达式
      FOR R_ITEM_TRAN IN C_ITEM_TRAN
      LOOP
        N_CON_CNT := N_CON_CNT + 1;
        --组合字符串
        IF (N_CON_CNT = 1) THEN
          S_DB_EXPRESS := 'GREATEST( (' || R_ITEM_TRAN.DB_EXPRESS || ')';
        ELSE
          S_DB_EXPRESS := S_DB_EXPRESS || ', (' || R_ITEM_TRAN.DB_EXPRESS || ')';
        END IF;
      END LOOP;

      IF (N_CON_CNT > 0) THEN
        S_DB_EXPRESS := S_DB_EXPRESS || ' )';
      END IF;
    END IF;

    --处理函数
    IF (OS_MESSAGE = 'OK') THEN
      UPDATE T_POL_POLICY_DEF_ITEM T
         SET T.DB_EXP = S_DB_EXPRESS
            ,LAST_UPDATED_BY = IS_USER_ID
            ,LAST_UPDATE_DATE = SYSDATE
       WHERE T.ITEM_ID = IN_ITEM_ID;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      OS_MESSAGE := '函数解释过程：MAX(ITEM_ID=' || TO_CHAR(IN_ITEM_ID) || ')出错！' || SQLERRM;
  END;

  -----------------------------------------------------------------------------
  --  函数解释过程：MIN                                                      --
  -----------------------------------------------------------------------------
  PROCEDURE P_EXP_MIN(IN_ITEM_ID            IN NUMBER   --EXCEL公式分解表ID
                     ,IS_USER_ID            IN VARCHAR2   --用户账号
                     ,OS_MESSAGE           OUT VARCHAR2   --成功则返回“OK”，否则返回出错信息
                     ) IS

    --需进行转义或组装的EXCEL公式
    CURSOR C_ITEM_TRAN IS
      SELECT T.DB_EXP DB_EXPRESS
        FROM T_POL_POLICY_DEF_ITEM T
       WHERE T.PARENT_ID = IN_ITEM_ID
       ORDER BY T.SORT_NUMBER ASC;
    R_ITEM_TRAN C_ITEM_TRAN%ROWTYPE;

    N_CON_CNT       NUMBER;          --参数值数量
    S_DB_EXPRESS    VARCHAR2(4000);  --转换后的公式语句
  BEGIN
    OS_MESSAGE := 'OK';

    --获取参数值
    IF (OS_MESSAGE = 'OK') THEN
      N_CON_CNT := 0;
      --循环表达式的子项，拼接成ORACLE的表达式
      FOR R_ITEM_TRAN IN C_ITEM_TRAN
      LOOP
        N_CON_CNT := N_CON_CNT + 1;
        --组合字符串
        IF (N_CON_CNT = 1) THEN
          S_DB_EXPRESS := 'LEAST( (' || R_ITEM_TRAN.DB_EXPRESS || ')';
        ELSE
          S_DB_EXPRESS := S_DB_EXPRESS || ', (' || R_ITEM_TRAN.DB_EXPRESS || ')';
        END IF;
      END LOOP;

      IF (N_CON_CNT > 0) THEN
        S_DB_EXPRESS := S_DB_EXPRESS || ' )';
      END IF;
    END IF;

    --处理函数
    IF (OS_MESSAGE = 'OK') THEN
      UPDATE T_POL_POLICY_DEF_ITEM T
         SET T.DB_EXP = S_DB_EXPRESS
            ,LAST_UPDATED_BY = IS_USER_ID
            ,LAST_UPDATE_DATE = SYSDATE
       WHERE T.ITEM_ID = IN_ITEM_ID;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      OS_MESSAGE := '函数解释过程：MIN(ITEM_ID=' || TO_CHAR(IN_ITEM_ID) || ')出错！' || SQLERRM;
  END;

  -----------------------------------------------------------------------------
  --  函数解释过程：IF                                                       --
  -----------------------------------------------------------------------------
  PROCEDURE P_EXP_IF(IN_ITEM_ID            IN NUMBER   --EXCEL公式分解表ID
                     ,IS_USER_ID            IN VARCHAR2   --用户账号
                    ,OS_MESSAGE           OUT VARCHAR2   --成功则返回“OK”，否则返回出错信息
                    ) IS
    --需进行转义或组装的EXCEL公式
    CURSOR C_ITEM_TRAN IS
      SELECT T.DB_EXP DB_EXPRESS
        FROM T_POL_POLICY_DEF_ITEM T
       WHERE T.PARENT_ID = IN_ITEM_ID
       ORDER BY T.SORT_NUMBER ASC;
    R_ITEM_TRAN C_ITEM_TRAN%ROWTYPE;

    S_CON_1         VARCHAR2(4000);  --参数1
    S_CON_2         VARCHAR2(4000);  --参数2
    S_CON_3         VARCHAR2(4000);  --参数3
    N_CON_CNT       NUMBER;         --参数值数量
    S_DB_EXPRESS    VARCHAR2(4000);  --转换后的公式语句
  BEGIN
    OS_MESSAGE := 'OK';
    --获取参数值
    IF (OS_MESSAGE = 'OK') THEN
      N_CON_CNT := 0;
      
      --循环表达式的子项，获取参数
      FOR R_ITEM_TRAN IN C_ITEM_TRAN
      LOOP
        N_CON_CNT := N_CON_CNT + 1;
        --获取参数值
        IF (N_CON_CNT = 1) THEN
          S_CON_1 := R_ITEM_TRAN.DB_EXPRESS;
        ELSIF (N_CON_CNT = 2) THEN
          S_CON_2 := R_ITEM_TRAN.DB_EXPRESS;
        ELSIF (N_CON_CNT = 3) THEN
          S_CON_3 := R_ITEM_TRAN.DB_EXPRESS;
        ELSE 
          OS_MESSAGE := '函数解释过程：IF(' || TO_CHAR(IN_ITEM_ID) || ')的参数值个数有误！';
        END IF;
      END LOOP;
      IF (N_CON_CNT = 0) THEN
          OS_MESSAGE := '函数解释过程：IF(' || TO_CHAR(IN_ITEM_ID) || ')不存在参数值！';
      END IF;
    END IF;

    --校验参数值
    IF (OS_MESSAGE = 'OK') THEN
      IF (S_CON_1 IS NULL) THEN
        OS_MESSAGE := '函数解释过程：IF(' || TO_CHAR(IN_ITEM_ID) || ')的第一个参数值（判断表达式）不能为空！';
      END IF;
      IF (S_CON_2 IS NULL) THEN
        OS_MESSAGE := '函数解释过程：IF(' || TO_CHAR(IN_ITEM_ID) || ')的第二个参数值（TRUE的取值）不能为空！';
      END IF;
      IF (S_CON_3 IS NULL) THEN
        OS_MESSAGE := '函数解释过程：IF(' || TO_CHAR(IN_ITEM_ID) || ')的第三参数值（FASE的取值）不能为空！';
      END IF;
    END IF;

    --处理函数
    IF (OS_MESSAGE = 'OK') THEN
      S_DB_EXPRESS := 'DECODE((SELECT COUNT(1) FROM DUAL WHERE (' || S_CON_1 || ')), 1, (' 
                   || S_CON_2 || '), (' || S_CON_3 || '))';
      UPDATE T_POL_POLICY_DEF_ITEM T
         SET T.DB_EXP = S_DB_EXPRESS
            ,LAST_UPDATED_BY = IS_USER_ID
            ,LAST_UPDATE_DATE = SYSDATE
       WHERE T.ITEM_ID = IN_ITEM_ID;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      OS_MESSAGE := '函数解释过程：IF(ITEM_ID=' || TO_CHAR(IN_ITEM_ID) || ')出错！' || SQLERRM;
  END;

  -----------------------------------------------------------------------------
  --  函数解释过程：AND                                                      --
  -----------------------------------------------------------------------------
  PROCEDURE P_EXP_AND(IN_ITEM_ID            IN NUMBER   --EXCEL公式分解表ID
                     ,IS_USER_ID            IN VARCHAR2   --用户账号
                     ,OS_MESSAGE           OUT VARCHAR2   --成功则返回“OK”，否则返回出错信息
                     ) IS

    --需进行转义或组装的EXCEL公式
    CURSOR C_ITEM_TRAN IS
      SELECT T.DB_EXP DB_EXPRESS
        FROM T_POL_POLICY_DEF_ITEM T
       WHERE T.PARENT_ID = IN_ITEM_ID
       ORDER BY T.SORT_NUMBER ASC;
    R_ITEM_TRAN C_ITEM_TRAN%ROWTYPE;

    N_CON_CNT       NUMBER;          --参数值数量
    S_DB_EXPRESS    VARCHAR2(4000);  --转换后的公式语句
  BEGIN
    OS_MESSAGE := 'OK';

    --获取参数值
    IF (OS_MESSAGE = 'OK') THEN
      N_CON_CNT := 0;
      --循环表达式的子项，拼接成ORACLE的表达式
      FOR R_ITEM_TRAN IN C_ITEM_TRAN
      LOOP
        N_CON_CNT := N_CON_CNT + 1;
        --组合字符串
        IF (N_CON_CNT = 1) THEN
          S_DB_EXPRESS := '( (' || R_ITEM_TRAN.DB_EXPRESS || ')';
        ELSE
          S_DB_EXPRESS := S_DB_EXPRESS || ' AND (' || R_ITEM_TRAN.DB_EXPRESS || ')';
        END IF;
      END LOOP;

      IF (N_CON_CNT > 0) THEN
        S_DB_EXPRESS := S_DB_EXPRESS || ' )';
      END IF;
    END IF;

    --处理函数
    IF (OS_MESSAGE = 'OK') THEN
      UPDATE T_POL_POLICY_DEF_ITEM T
         SET T.DB_EXP = S_DB_EXPRESS
            ,LAST_UPDATED_BY = IS_USER_ID
            ,LAST_UPDATE_DATE = SYSDATE
       WHERE T.ITEM_ID = IN_ITEM_ID;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      OS_MESSAGE := '函数解释过程：AND(ITEM_ID=' || TO_CHAR(IN_ITEM_ID) || ')出错！' || SQLERRM;
  END;

  -----------------------------------------------------------------------------
  --  函数解释过程：OR                                                       --
  -----------------------------------------------------------------------------
  PROCEDURE P_EXP_OR(IN_ITEM_ID            IN NUMBER   --EXCEL公式分解表ID
                    ,IS_USER_ID            IN VARCHAR2   --用户账号
                    ,OS_MESSAGE           OUT VARCHAR2   --成功则返回“OK”，否则返回出错信息
                    ) IS

    --需进行转义或组装的EXCEL公式
    CURSOR C_ITEM_TRAN IS
      SELECT T.DB_EXP DB_EXPRESS
        FROM T_POL_POLICY_DEF_ITEM T
       WHERE T.PARENT_ID = IN_ITEM_ID
       ORDER BY T.SORT_NUMBER ASC;
    R_ITEM_TRAN C_ITEM_TRAN%ROWTYPE;

    N_CON_CNT       NUMBER;          --参数值数量
    S_DB_EXPRESS    VARCHAR2(4000);  --转换后的公式语句
  BEGIN
    OS_MESSAGE := 'OK';

    --获取参数值
    IF (OS_MESSAGE = 'OK') THEN
      N_CON_CNT := 0;
      --循环表达式的子项，拼接成ORACLE的表达式
      FOR R_ITEM_TRAN IN C_ITEM_TRAN
      LOOP
        N_CON_CNT := N_CON_CNT + 1;
        --组合字符串
        IF (N_CON_CNT = 1) THEN
          S_DB_EXPRESS := '( (' || R_ITEM_TRAN.DB_EXPRESS || ')';
        ELSE
          S_DB_EXPRESS := S_DB_EXPRESS || ' OR (' || R_ITEM_TRAN.DB_EXPRESS || ')';
        END IF;
      END LOOP;

      IF (N_CON_CNT > 0) THEN
        S_DB_EXPRESS := S_DB_EXPRESS || ' )';
      END IF;
    END IF;

    --处理函数
    IF (OS_MESSAGE = 'OK') THEN
      UPDATE T_POL_POLICY_DEF_ITEM T
         SET T.DB_EXP = S_DB_EXPRESS
            ,LAST_UPDATED_BY = IS_USER_ID
            ,LAST_UPDATE_DATE = SYSDATE
       WHERE T.ITEM_ID = IN_ITEM_ID;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      OS_MESSAGE := '函数解释过程：OR(ITEM_ID=' || TO_CHAR(IN_ITEM_ID) || ')出错！' || SQLERRM;
  END;

  -----------------------------------------------------------------------------
  --  EXCEL公式分解                                                          --
  -----------------------------------------------------------------------------
  PROCEDURE P_VAL_EXP_ANALYZE(IN_DEFINE_ID          IN NUMBER   --统计项ID
                             ,IS_EXCEL              IN VARCHAR2   --上层的EXCEL格式的输入公式
                             ,IN_LEVEL_NUMBER       IN NUMBER     --公式分解的上层层次
                             ,IN_PARENT_ID          IN NUMBER     --上层父公式ID
                             ,IS_USER_ID            IN VARCHAR2   --用户账号
                             ,OS_MESSAGE           OUT VARCHAR2   --成功则返回“OK”，否则返回出错信息
                             ) IS

    S_EXCEL               VARCHAR2(4000);
    S_EXPRESS_TYPE        VARCHAR2(240);
    N_ITEM_ID             NUMBER;
    N_EXCEL_LEN           NUMBER;
    N_CNT                 NUMBER;
    S_CHAR                VARCHAR2(4);
    S_CHAR_FIRST          VARCHAR2(4);
    S_CHAR_END            VARCHAR2(4);
    N_CHAR_TRAN_INDEX     NUMBER;       --运算符的位置：+、-、*、/
    N_CHAR_TRAN_INDEX_PRE NUMBER;       --上一运算符的位置：+、-、*、/
    N_LEVELS              NUMBER;       --根据公式的括号，记录当前的层次
    N_SORT_NUMBER         NUMBER;       --排列序号
    N_KUOHAO_INDEX        NUMBER;       --左括号的位置
    S_CHAR_NEXT           VARCHAR2(4);  --当符号为“>、<”时，记录下一符号
    S_CHAR_PRE            VARCHAR2(4);  --记录叶子节点的上一符号
    S_CHAR_PRE_LAST       VARCHAR2(4);  --记录叶子节点的上一符号(最后一个变量)
    S_STEP                VARCHAR2(40); --记录当前步骤，用于出错时记录出错位置
  BEGIN
    OS_MESSAGE := 'OK';

    --检查输入公式
    IF (OS_MESSAGE = 'OK') AND (IS_EXCEL IS NULL) THEN
      OS_MESSAGE := 'EXCEL公式分解(DEFINE_ID=' || TO_CHAR(IN_DEFINE_ID) || ')出错，EXCEL为空！';
    END IF;

    --计算P_EXCEL 的长度
    IF (OS_MESSAGE = 'OK') THEN
      --去掉回车
      S_EXCEL := REPLACE(IS_EXCEL, CHR(13), ' ');

      --去掉换行
      S_EXCEL := REPLACE(S_EXCEL, CHR(10), ' ');

      --去掉前后空格
      S_EXCEL := TRIM(S_EXCEL);

      N_EXCEL_LEN := LENGTH(S_EXCEL);

      S_CHAR_FIRST := SUBSTR(S_EXCEL, 1, 1);
      S_CHAR_END := SUBSTR(S_EXCEL, N_EXCEL_LEN, 1);
    END IF;

    --判断第一个和最后一个字符分别为左右括号的情况
    IF (OS_MESSAGE = 'OK') AND (S_CHAR_FIRST = '(') AND (S_CHAR_END = ')') THEN
      N_LEVELS := 0;
      FOR N_CNT IN 2..N_EXCEL_LEN-1 LOOP
        --判断去掉第一个和最后一个左右括号后，公式内的括号是否正常
        IF (N_LEVELS >= 0) THEN
          S_CHAR := SUBSTR(S_EXCEL, N_CNT, 1);

          --判断当前层数
          IF (S_CHAR = '(') THEN
            N_LEVELS := N_LEVELS + 1;
          ELSIF (S_CHAR = ')') THEN
            N_LEVELS := N_LEVELS - 1;
          END IF;
        END IF;
      END LOOP;
      --若去掉第一个和最后一个左右括号后公式正常，则调用递归
      IF (N_LEVELS >= 0) THEN
        S_STEP := '去掉前后括号后写计算项';
        SELECT S_POL_POLICY_DEF_ITEM.NEXTVAL
          INTO N_ITEM_ID
          FROM DUAL;

        INSERT INTO T_POL_POLICY_DEF_ITEM
          (ITEM_ID,
           DEFINE_ID,
           LEVEL_NUMBER,
           SORT_NUMBER,
           PARENT_ID,
           EXCEL_EXP,
           CREATED_BY,
           CREATION_DATE,
           LAST_UPDATED_BY,
           LAST_UPDATE_DATE)
        SELECT
           N_ITEM_ID,
           IN_DEFINE_ID,
           IN_LEVEL_NUMBER + 1,
           1,
           IN_PARENT_ID,
           TRIM(SUBSTR(S_EXCEL, 2, N_EXCEL_LEN - 2)),
           IS_USER_ID,
           SYSDATE,
           IS_USER_ID,
           SYSDATE
         FROM DUAL;

        P_VAL_EXP_ANALYZE(IN_DEFINE_ID
                         ,SUBSTR(S_EXCEL, 2, N_EXCEL_LEN - 2)
                         ,IN_LEVEL_NUMBER + 1
                         ,N_ITEM_ID
                         ,IS_USER_ID
                         ,OS_MESSAGE
                         );
      END IF;
    END IF;

    --若不能去掉第一个和最后一个字符时，则根据“+、-、*、/、>、<、=、>=、<=”分解公式
    IF (OS_MESSAGE = 'OK') AND (N_ITEM_ID IS NULL) THEN
      S_STEP := '根据符号写计算项';
      N_LEVELS := 0;
      N_SORT_NUMBER := 0;
      N_CHAR_TRAN_INDEX := 0;
      N_CHAR_TRAN_INDEX_PRE := 0;
      FOR N_CNT IN 1..N_EXCEL_LEN LOOP

        S_CHAR := SUBSTR(S_EXCEL, N_CNT, 1);

        --判断当前层数
        IF (S_CHAR = '(') THEN
          N_LEVELS := N_LEVELS + 1;
        ELSIF (S_CHAR = ')') THEN
          N_LEVELS := N_LEVELS - 1;
        END IF;

        --判断是否运算符
        IF (N_LEVELS = 0) AND S_CHAR IN ('+', '-', '*', '/', '>', '<', '=') THEN
          N_CHAR_TRAN_INDEX := N_CNT;
          S_CHAR_PRE := S_CHAR_PRE_LAST;
          S_CHAR_PRE_LAST := S_CHAR;
        END IF;

        --若括号层数已归0，并且当前存在运算符，则截取前一字符串调用递归分析过程
        IF (N_LEVELS = 0) AND (N_CHAR_TRAN_INDEX > 0) AND (N_CHAR_TRAN_INDEX > N_CHAR_TRAN_INDEX_PRE) THEN
          S_STEP := '括号层归0，存在运算符，写项';
          SELECT S_POL_POLICY_DEF_ITEM.NEXTVAL
            INTO N_ITEM_ID
            FROM DUAL;
          N_SORT_NUMBER := N_SORT_NUMBER + 1;

          INSERT INTO T_POL_POLICY_DEF_ITEM
            (ITEM_ID,
             DEFINE_ID,
             LEVEL_NUMBER,
             SORT_NUMBER,
             PARENT_ID,
             EXCEL_EXP,
             PRE_OPER,
             CREATED_BY,
             CREATION_DATE,
             LAST_UPDATED_BY,
             LAST_UPDATE_DATE)
          SELECT
             N_ITEM_ID,
             IN_DEFINE_ID,
             IN_LEVEL_NUMBER + 1,
             N_SORT_NUMBER,
             IN_PARENT_ID,
             TRIM(SUBSTR(S_EXCEL, N_CHAR_TRAN_INDEX_PRE + 1, N_CHAR_TRAN_INDEX - N_CHAR_TRAN_INDEX_PRE - 1)),
             S_CHAR_PRE,
             IS_USER_ID,
             SYSDATE,
             IS_USER_ID,
             SYSDATE
           FROM DUAL;    

          P_VAL_EXP_ANALYZE(IN_DEFINE_ID
                           ,SUBSTR(S_EXCEL, N_CHAR_TRAN_INDEX_PRE + 1, N_CHAR_TRAN_INDEX - N_CHAR_TRAN_INDEX_PRE - 1)
                           ,IN_LEVEL_NUMBER + 1
                           ,N_ITEM_ID
                           ,IS_USER_ID
                           ,OS_MESSAGE
                           );

          N_CHAR_TRAN_INDEX_PRE := N_CHAR_TRAN_INDEX;
          
          --当符号为“>、<”时，判断下一符号是否为“=”
          S_CHAR_NEXT := NULL;
          IF (S_CHAR = '>') OR (S_CHAR = '<') THEN
            S_CHAR_NEXT := SUBSTR(S_EXCEL, N_CNT + 1, 1);

            --若为“>=、<=”时，N_CHAR_TRAN_INDEX_PRE 增加1，跳到下一字符
            IF (S_CHAR_NEXT = '=') THEN
              N_CHAR_TRAN_INDEX_PRE := N_CHAR_TRAN_INDEX_PRE + 1;
            END IF;
          END IF;
        END IF;

        --若括号层数已归0，并且之前已处理1个或以上公式串，并且当前为最后的字符
        IF (N_LEVELS = 0) AND (N_CHAR_TRAN_INDEX_PRE > 0) AND (N_CNT = N_EXCEL_LEN) THEN
           S_STEP := '括号层归0,为最后字符,写项';
          SELECT S_POL_POLICY_DEF_ITEM.NEXTVAL
            INTO N_ITEM_ID
            FROM DUAL;
          N_SORT_NUMBER := N_SORT_NUMBER + 1;

          INSERT INTO T_POL_POLICY_DEF_ITEM
            (ITEM_ID,
             DEFINE_ID,
             LEVEL_NUMBER,
             SORT_NUMBER,
             PARENT_ID,
             EXCEL_EXP,
             PRE_OPER,
             CREATED_BY,
             CREATION_DATE,
             LAST_UPDATED_BY,
             LAST_UPDATE_DATE)
          SELECT
             N_ITEM_ID,
             IN_DEFINE_ID,
             IN_LEVEL_NUMBER + 1,
             N_SORT_NUMBER,
             IN_PARENT_ID,
             TRIM(SUBSTR(S_EXCEL, N_CHAR_TRAN_INDEX_PRE + 1, N_EXCEL_LEN - N_CHAR_TRAN_INDEX_PRE)),
             S_CHAR_PRE_LAST,
             IS_USER_ID,
             SYSDATE,
             IS_USER_ID,
             SYSDATE
           FROM DUAL;    

          P_VAL_EXP_ANALYZE(IN_DEFINE_ID
                           ,SUBSTR(S_EXCEL, N_CHAR_TRAN_INDEX_PRE + 1, N_EXCEL_LEN - N_CHAR_TRAN_INDEX_PRE)
                           ,IN_LEVEL_NUMBER + 1
                           ,N_ITEM_ID
                           ,IS_USER_ID
                           ,OS_MESSAGE
                           );
        END IF;

      END LOOP;
    END IF;

    --若不能“+、-、*、/”分解公式，则通过函数内的参数分解公式
    IF (OS_MESSAGE = 'OK') AND (N_ITEM_ID IS NULL) THEN
      --获取第一个左括号的位置
      N_KUOHAO_INDEX := INSTR(S_EXCEL, '(', 1, 1);

      --获取并校验函数名称
      IF (OS_MESSAGE = 'OK') AND (N_KUOHAO_INDEX > 0) THEN
        S_EXPRESS_TYPE := SUBSTR(S_EXCEL, 1, N_KUOHAO_INDEX - 1);

        IF (OS_MESSAGE = 'OK') AND (S_EXPRESS_TYPE IS NULL) THEN
          OS_MESSAGE := 'EXCEL公式分解(DEFINE_ID=' || TO_CHAR(IN_DEFINE_ID) || ')获取函数名时出错！';
        END IF;

      END IF;

      --获取函数参数，并调用分析递归过程
      IF (OS_MESSAGE = 'OK') THEN
        N_LEVELS := 0;
        N_SORT_NUMBER := 0;
        N_CHAR_TRAN_INDEX := 0;
        N_CHAR_TRAN_INDEX_PRE := N_KUOHAO_INDEX;
      
        FOR N_CNT IN (N_KUOHAO_INDEX + 1)..(N_EXCEL_LEN - 1) LOOP
          S_CHAR := SUBSTR(S_EXCEL, N_CNT, 1);

          --判断当前层数
          IF (S_CHAR = '(') THEN
            N_LEVELS := N_LEVELS + 1;
          ELSIF (S_CHAR = ')') THEN
            N_LEVELS := N_LEVELS - 1;
          ELSE
            N_LEVELS := N_LEVELS;
          END IF;

          --判断是否运算符
          IF (N_LEVELS = 0) AND (S_CHAR = ',') THEN
            N_CHAR_TRAN_INDEX := N_CNT;
          END IF;

          --若括号层数已归0，并且当前存在逗号，则截取前一字符串调用递归分析过程
          IF (N_LEVELS = 0) AND (N_CHAR_TRAN_INDEX > 0) AND (N_CHAR_TRAN_INDEX > N_CHAR_TRAN_INDEX_PRE) THEN
            S_STEP := '括号层归0，存在逗号，写项';
            SELECT S_POL_POLICY_DEF_ITEM.NEXTVAL
              INTO N_ITEM_ID
              FROM DUAL;
            N_SORT_NUMBER := N_SORT_NUMBER + 1;

            INSERT INTO T_POL_POLICY_DEF_ITEM
              (ITEM_ID,
               DEFINE_ID,
               LEVEL_NUMBER,
               SORT_NUMBER,
               PARENT_ID,
               EXCEL_EXP,
               CREATED_BY,
               CREATION_DATE,
               LAST_UPDATED_BY,
               LAST_UPDATE_DATE)
            SELECT
               N_ITEM_ID,
               IN_DEFINE_ID,
               IN_LEVEL_NUMBER + 1,
               N_SORT_NUMBER,
               IN_PARENT_ID,
               TRIM(SUBSTR(S_EXCEL, N_CHAR_TRAN_INDEX_PRE + 1, N_CHAR_TRAN_INDEX - N_CHAR_TRAN_INDEX_PRE - 1)),
               IS_USER_ID,
               SYSDATE,
               IS_USER_ID,
               SYSDATE
             FROM DUAL;    

            P_VAL_EXP_ANALYZE(IN_DEFINE_ID
                             ,SUBSTR(S_EXCEL, N_CHAR_TRAN_INDEX_PRE + 1, N_CHAR_TRAN_INDEX - N_CHAR_TRAN_INDEX_PRE - 1)
                             ,IN_LEVEL_NUMBER + 1
                             ,N_ITEM_ID
                             ,IS_USER_ID
                             ,OS_MESSAGE
                             );

            N_CHAR_TRAN_INDEX_PRE := N_CHAR_TRAN_INDEX;
          END IF;

          --若括号层数已归0，并且之前已处理1个或以上公式串，并且当前为最后的字符
          IF (N_LEVELS = 0) AND (N_CHAR_TRAN_INDEX_PRE > 0) AND (N_CNT = N_EXCEL_LEN - 1) THEN
            S_STEP := '括号层归0,为最后字符2,写项';
            SELECT S_POL_POLICY_DEF_ITEM.NEXTVAL
              INTO N_ITEM_ID
              FROM DUAL; 
            N_SORT_NUMBER := N_SORT_NUMBER + 1;

            INSERT INTO T_POL_POLICY_DEF_ITEM
              (ITEM_ID,
               DEFINE_ID,
               LEVEL_NUMBER,
               SORT_NUMBER,
               PARENT_ID,
               EXCEL_EXP,
               CREATED_BY,
               CREATION_DATE,
               LAST_UPDATED_BY,
               LAST_UPDATE_DATE)
            SELECT
               N_ITEM_ID,
               IN_DEFINE_ID,
               IN_LEVEL_NUMBER + 1,
               N_SORT_NUMBER,
               IN_PARENT_ID,
               TRIM(SUBSTR(S_EXCEL, N_CHAR_TRAN_INDEX_PRE + 1, N_EXCEL_LEN - N_CHAR_TRAN_INDEX_PRE - 1)),
               IS_USER_ID,
               SYSDATE,
               IS_USER_ID,
               SYSDATE
             FROM DUAL;    

            P_VAL_EXP_ANALYZE(IN_DEFINE_ID
                             ,SUBSTR(S_EXCEL, N_CHAR_TRAN_INDEX_PRE + 1, N_EXCEL_LEN - N_CHAR_TRAN_INDEX_PRE - 1)
                             ,IN_LEVEL_NUMBER + 1
                             ,N_ITEM_ID
                             ,IS_USER_ID
                             ,OS_MESSAGE
                             );
          END IF;

        END LOOP;
      END IF;

      --更新上层语句的函数类型
      IF (OS_MESSAGE = 'OK')THEN
        S_STEP := '更新上层语句的函数类型';
        UPDATE T_POL_POLICY_DEF_ITEM T
           SET T.EXP_OPERATOR = S_EXPRESS_TYPE
              ,LAST_UPDATED_BY = IS_USER_ID
              ,LAST_UPDATE_DATE = SYSDATE
         WHERE T.ITEM_ID = IN_PARENT_ID;
      END IF;
    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      OS_MESSAGE := 'EXCEL公式分解-' || S_STEP || '(DEFINE_ID=' || TO_CHAR(IN_DEFINE_ID) || ')！' || SQLERRM;
  END;

  -----------------------------------------------------------------------------
  --  EXCEL公式转换                                                          --
  -----------------------------------------------------------------------------
  PROCEDURE P_VAL_EXP_TRANSLATE(IN_DEFINE_ID          IN VARCHAR2   --竖放表ID
                               ,IS_USER_ID            IN VARCHAR2   --用户账号
                               ,OS_MESSAGE           OUT VARCHAR2   --成功则返回“OK”，否则返回出错信息
                               ) IS
    --叶子节点
    CURSOR C_ITEM_LEAF IS
      SELECT T.ITEM_ID
           , T.EXCEL_EXP
           , T.PRE_OPER
        FROM T_POL_POLICY_DEF_ITEM T
       WHERE T.DEFINE_ID = IN_DEFINE_ID
         AND NOT EXISTS(SELECT 1
                          FROM T_POL_POLICY_DEF_ITEM S
                         WHERE S.DEFINE_ID = T.DEFINE_ID
                           AND S.PARENT_ID = T.ITEM_ID);
    R_ITEM_LEAF C_ITEM_LEAF%ROWTYPE;
    --需进行转义或组装的EXCEL公式
    CURSOR C_ITEM_TRAN IS
      SELECT *
        FROM T_POL_POLICY_DEF_ITEM T
       WHERE T.DEFINE_ID = IN_DEFINE_ID
         AND EXISTS(SELECT 1
                      FROM T_POL_POLICY_DEF_ITEM S
                     WHERE S.DEFINE_ID = IN_DEFINE_ID
                       AND S.PARENT_ID = T.ITEM_ID)
       ORDER BY T.LEVEL_NUMBER DESC, T.PARENT_ID DESC, T.SORT_NUMBER DESC;
    R_ITEM_TRAN C_ITEM_TRAN%ROWTYPE;
    --子分解公式
    CURSOR C_ITEM_SUB(IN_PARENT_ID NUMBER) IS
      SELECT *
        FROM T_POL_POLICY_DEF_ITEM T
       WHERE T.PARENT_ID = IN_PARENT_ID
       ORDER BY T.SORT_NUMBER ASC;
    R_ITEM_SUB C_ITEM_SUB%ROWTYPE;

    S_DEFINE_CODE          VARCHAR2(40);
    S_EXCEL_EXPRESS        VARCHAR2(4000);
    S_DB_EXPRESS           VARCHAR2(4000);
    N_ITEM_ID              NUMBER;
    S_STEP                 VARCHAR2(40);
  BEGIN
    OS_MESSAGE := 'OK';

    --删除政策算法定义子项
    IF (OS_MESSAGE = 'OK') THEN
      S_STEP := '删除政策算法定义子项';
      DELETE 
        FROM T_POL_POLICY_DEF_ITEM T
       WHERE T.DEFINE_ID = IN_DEFINE_ID;
    END IF;

    --获取政策算法定义信息
    IF (OS_MESSAGE = 'OK') THEN
      S_STEP := '获取政策算法定义信息';
      SELECT T.DEFINE_CODE
           , T.CAL_EXP
        INTO S_DEFINE_CODE
           , S_EXCEL_EXPRESS
        FROM T_POL_POLICY_DEFINE T
       WHERE T.DEFINE_ID = IN_DEFINE_ID;
    END IF;

    --插入第一层子项
    IF (OS_MESSAGE = 'OK') THEN
      S_STEP := '插入第一层子项';
      SELECT S_POL_POLICY_DEF_ITEM.NEXTVAL
        INTO N_ITEM_ID
        FROM DUAL;

      INSERT INTO T_POL_POLICY_DEF_ITEM
        (ITEM_ID,
         DEFINE_ID,
         LEVEL_NUMBER,
         SORT_NUMBER,
         PARENT_ID,
         EXP_OPERATOR,
         EXCEL_EXP,
         DB_EXP,
         CREATED_BY,
         CREATION_DATE,
         LAST_UPDATED_BY,
         LAST_UPDATE_DATE)
      VALUES
        (N_ITEM_ID,
         IN_DEFINE_ID,
         1,
         1,
         NULL,
         NULL,
         TRIM(S_EXCEL_EXPRESS),
         NULL,
         IS_USER_ID,
         SYSDATE,
         IS_USER_ID,
         SYSDATE);
    END IF;

    --调用EXCEL公式分解过程
    IF (OS_MESSAGE = 'OK') THEN
      P_VAL_EXP_ANALYZE(IN_DEFINE_ID
                       ,S_EXCEL_EXPRESS
                       ,1
                       ,N_ITEM_ID
                       ,IS_USER_ID
                       ,OS_MESSAGE);
    END IF;

    --更新公式分解表的叶子节点的公式
    IF (OS_MESSAGE = 'OK') THEN
      --循环叶子节点，转换数值
      S_STEP := '循环叶子节点，转换数值';
      FOR R_ITEM_LEAF IN C_ITEM_LEAF
      LOOP
        IF (OS_MESSAGE = 'OK') THEN
          --如果叶子节点变量包含百分号，则转换为小数
          IF (INSTR(R_ITEM_LEAF.EXCEL_EXP, '%', 1, 1) > 0) THEN
            P_EXP_PERCENT(R_ITEM_LEAF.EXCEL_EXP
                         ,S_DB_EXPRESS
                         ,OS_MESSAGE);
          ELSE
            S_DB_EXPRESS := R_ITEM_LEAF.EXCEL_EXP;
          END IF;
          --如果叶子节点变量前面存在“-”符号，则自动增加括号
          IF (OS_MESSAGE = 'OK') AND (R_ITEM_LEAF.PRE_OPER = '-') THEN
            S_DB_EXPRESS := '(' || S_DB_EXPRESS || ')';
          END IF;
          --更新
          IF (OS_MESSAGE = 'OK') THEN
            UPDATE T_POL_POLICY_DEF_ITEM T
               SET T.DB_EXP = S_DB_EXPRESS
                  ,LAST_UPDATED_BY = IS_USER_ID
                  ,LAST_UPDATE_DATE = SYSDATE
             WHERE T.ITEM_ID = R_ITEM_LEAF.ITEM_ID;
          END IF;
        END IF;
      END LOOP;
    END IF;

    --更新需进行转义或组装的EXCEL公式
    IF (OS_MESSAGE = 'OK') THEN
      S_STEP := '更新EXCEL公式';
      FOR R_ITEM_TRAN IN C_ITEM_TRAN
      LOOP
        --处理函数：IF
        IF (OS_MESSAGE = 'OK') AND (R_ITEM_TRAN.EXP_OPERATOR = 'IF') THEN
          P_EXP_IF(R_ITEM_TRAN.ITEM_ID
                  ,IS_USER_ID
                  ,OS_MESSAGE);
        END IF;
        --处理函数：OR
        IF (OS_MESSAGE = 'OK') AND (R_ITEM_TRAN.EXP_OPERATOR = 'OR') THEN
          P_EXP_OR(R_ITEM_TRAN.ITEM_ID
                  ,IS_USER_ID
                  ,OS_MESSAGE);
        END IF;
        --处理函数：AND
        IF (OS_MESSAGE = 'OK') AND (R_ITEM_TRAN.EXP_OPERATOR = 'AND') THEN
          P_EXP_AND(R_ITEM_TRAN.ITEM_ID
                   ,IS_USER_ID
                   ,OS_MESSAGE);
        END IF;
        --处理函数：SUM
        IF (OS_MESSAGE = 'OK') AND (R_ITEM_TRAN.EXP_OPERATOR = 'SUM') THEN
          P_EXP_SUM(R_ITEM_TRAN.ITEM_ID
                   ,IS_USER_ID
                   ,OS_MESSAGE);
        END IF;
        --处理函数：MAX
        IF (OS_MESSAGE = 'OK') AND (R_ITEM_TRAN.EXP_OPERATOR = 'MAX') THEN
          P_EXP_MAX(R_ITEM_TRAN.ITEM_ID
                   ,IS_USER_ID
                   ,OS_MESSAGE);
        END IF;
        --处理函数：MIN
        IF (OS_MESSAGE = 'OK') AND (R_ITEM_TRAN.EXP_OPERATOR = 'MIN') THEN
          P_EXP_MIN(R_ITEM_TRAN.ITEM_ID
                   ,IS_USER_ID
                   ,OS_MESSAGE);
        END IF;

        --处理函数：空
        IF (OS_MESSAGE = 'OK') AND ((R_ITEM_TRAN.EXP_OPERATOR IS NULL)
                                OR (R_ITEM_TRAN.EXP_OPERATOR NOT IN ('IF', 'OR', 'AND', 'SUM', 'MAX', 'MIN'))) THEN
          S_DB_EXPRESS := R_ITEM_TRAN.EXCEL_EXP;
          --循环子项，将子项中的转换关系更新到当前项中
          FOR R_ITEM_SUB IN C_ITEM_SUB(R_ITEM_TRAN.ITEM_ID)
          LOOP
            --替换字符
            S_DB_EXPRESS := REPLACE(S_DB_EXPRESS, R_ITEM_SUB.EXCEL_EXP, R_ITEM_SUB.DB_EXP);
          END LOOP;

          --更新公式
          IF (OS_MESSAGE = 'OK') THEN
            UPDATE T_POL_POLICY_DEF_ITEM T
               SET T.DB_EXP = S_DB_EXPRESS
                  ,LAST_UPDATED_BY = IS_USER_ID
                  ,LAST_UPDATE_DATE = SYSDATE
             WHERE T.ITEM_ID = R_ITEM_TRAN.ITEM_ID;
          END IF;
        END IF;
      END LOOP;
    END IF;

    --更新算法表的公式
    IF (OS_MESSAGE = 'OK') THEN
      S_STEP := '更新算法表的公式';
      UPDATE T_POL_POLICY_DEFINE V
         SET V.CAL_DB_EXP = (SELECT T.DB_EXP
                               FROM T_POL_POLICY_DEF_ITEM T
                              WHERE V.DEFINE_ID = T.DEFINE_ID
                                AND T.LEVEL_NUMBER = 1)
            ,LAST_UPDATED_BY = IS_USER_ID
            ,LAST_UPDATE_DATE = SYSDATE
       WHERE V.DEFINE_ID = IN_DEFINE_ID;
    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      OS_MESSAGE := 'EXCEL公式转换-' || S_STEP || '(DEFINE_ID=' || TO_CHAR(IN_DEFINE_ID) || ')！' || SQLERRM;
  END;
*/
  -----------------------------------------------------------------------------
  --  分析参数   
  --按“,”分解成对应的数组内容输出
  -----------------------------------------------------------------------------
  PROCEDURE P_ANALYZE_PARAM
  (
    IS_PARAMS           IN  VARCHAR2     --参数字符串
    ,ON_COUNT           OUT NUMBER       --参数数量
    ,OS_PARAMS          OUT STRING_ARRAY --参数数组
  )
  IS
    S_CHAR VARCHAR2(3);
    N_INDEX NUMBER;
    N_COUNT NUMBER;
    N_BRACKET NUMBER := 0;
    N_BEGIN NUMBER;
  BEGIN
    N_COUNT := LENGTH(IS_PARAMS);
    N_BEGIN := 1;
    ON_COUNT := 0;
    --循环参数字符串，查找“,”，对于存在“(”，则找到对应的“)”后再找
    FOR N_INDEX IN 1..N_COUNT LOOP
      S_CHAR := SUBSTR(IS_PARAMS,N_INDEX,1);
      IF S_CHAR = '(' THEN
        N_BRACKET := N_BRACKET+1;
      ELSIF S_CHAR = ')' THEN
        N_BRACKET := N_BRACKET-1;
      ELSIF S_CHAR = ',' AND N_BRACKET = 0 THEN
        IF N_INDEX = N_BEGIN THEN
          --第一个为“,”，则认为无效
          RAISE_APPLICATION_ERROR(-20101, '参数“' || IS_PARAMS || '”无效');
          EXIT;
        ELSE
          --找到“,”，且不在括号中，则记录到输出参数数组中
          ON_COUNT := ON_COUNT+1;
          OS_PARAMS(ON_COUNT) := SUBSTR(IS_PARAMS, N_BEGIN, N_INDEX-N_BEGIN);
          N_BEGIN := N_INDEX+1;
        END IF;
      END IF;  
    END LOOP;
    --将剩余内容新增参数
    IF N_BEGIN <= N_COUNT THEN
      ON_COUNT := ON_COUNT+1;
      OS_PARAMS(ON_COUNT) := SUBSTR(IS_PARAMS, N_BEGIN, N_COUNT-N_BEGIN+1);
    ELSE
      RAISE_APPLICATION_ERROR(-20101, '参数“' || IS_PARAMS || '”无效');
    END IF;  
  END P_ANALYZE_PARAM;

  -----------------------------------------------------------------------------
  --  将百分比转换成小数输出   
  -----------------------------------------------------------------------------
  FUNCTION F_GET_PERCENT_VAL
  (
    IS_VALUE            IN  VARCHAR2     --包含%的值
  )
  RETURN VARCHAR2
  IS
    S_VALUE               VARCHAR2(100);
    N_CNT                 NUMBER;
    S_NUM                 VARCHAR2(100);
  BEGIN
    S_VALUE := IS_VALUE;
    N_CNT := LENGTH(S_VALUE);
    IF SUBSTR(S_VALUE, N_CNT, 1) = '%' THEN
      S_NUM := SUBSTR(S_VALUE, 1, N_CNT-1);
      --转换为数字，然后除以100
      BEGIN
        SELECT TO_CHAR(TO_NUMBER(S_NUM)/100)
          INTO S_VALUE
          FROM DUAL;
        IF (INSTR(S_VALUE, '.', 1, 1) = 1) THEN
          S_VALUE := '0' || S_VALUE;
        END IF;
      EXCEPTION
        WHEN OTHERS THEN
          RAISE_APPLICATION_ERROR(-20101, '百分数转换为小数时出错(' || IS_VALUE || ')');
      END;
    END IF;
    RETURN S_VALUE;
  END F_GET_PERCENT_VAL;

  -----------------------------------------------------------------------------
  --  将EXCEL表达式转换成数据库表达式   
  --  注意：传入参数要先去掉前后空格，并将“"”变为“''”
  -----------------------------------------------------------------------------
  FUNCTION F_EXPR_XLS2DB
  (
    IS_EXPRESSION       IN  VARCHAR2     --EXCEL表达式
  )
  RETURN VARCHAR2
  IS
    S_CHAR VARCHAR2(3);
    S_STR VARCHAR2(1000);
    S_FUN VARCHAR2(1000);
    S_RESULT VARCHAR2(4000);
    N_INDEX NUMBER;
    N_COUNT NUMBER;
    N_BRACKET NUMBER := 0;
    B_IN_QUOTES BOOLEAN := FALSE;
    N_BEGIN NUMBER;
    N_I NUMBER;
    N_PARAM_CNT NUMBER;
    S_PARAMS STRING_ARRAY;
  BEGIN
    N_COUNT := LENGTH(IS_EXPRESSION);
    N_BEGIN := 1;
    S_RESULT := '';
    S_FUN := NULL;
    --循环字符串，查找分隔符，对取出的字符作相应的处理
    FOR N_INDEX IN 1..N_COUNT LOOP
      S_CHAR := SUBSTR(IS_EXPRESSION, N_INDEX, 1);
      IF S_CHAR = '''' THEN
        --引号则设置为引号内/外，在后面的处理中处理拼接
        B_IN_QUOTES := NOT B_IN_QUOTES;
      ELSIF NOT B_IN_QUOTES THEN
        --处理引号外的内容
        IF N_BRACKET = 0 THEN
          --非括号内，则判断相关逻辑
          IF S_CHAR = '(' THEN
            --括号数+1
            N_BRACKET := N_BRACKET+1;
            --第一个左括号，且存在非分隔符，则判断是否约定函数，是则记录，否则报错
            IF N_INDEX = N_BEGIN THEN
              --前一个为分隔符号（非函数），则直接拼接
              S_RESULT := S_RESULT || S_CHAR;
            ELSE
              --记录函数名
              S_FUN := SUBSTR(IS_EXPRESSION, N_BEGIN, N_INDEX-N_BEGIN);
              /*不限制函数，可直接使用ORACLE的函数处理
              IF S_FUN NOT IN ('IF','AND','OR','SUM','MAX','MIN','ROUND','NVL') THEN
                --非约定的函数，则报错
                RAISE_APPLICATION_ERROR(-20101, '不能解释函数“' || S_STR || '”');
              END IF;
              */
            END IF;
            N_BEGIN := N_INDEX+1;
          ELSIF S_CHAR IN ('+','-','*','\','=','>','<',' ') THEN
            --分隔符，直接拼接
            IF N_BEGIN = N_INDEX THEN
              --第一个为“=”则去掉
              IF NOT (N_INDEX = 1 AND S_CHAR = '=') THEN
                --连续分隔符
                S_RESULT := S_RESULT || S_CHAR;
              END IF;
            ELSE
              S_STR := SUBSTR(IS_EXPRESSION, N_BEGIN, N_INDEX-N_BEGIN);
              S_RESULT := S_RESULT || F_GET_PERCENT_VAL(S_STR) || S_CHAR;
            END IF;
            N_BEGIN := N_INDEX+1;
          ELSIF S_CHAR = ')' THEN
            RAISE_APPLICATION_ERROR(-20101, '缺少左括号！');
          END IF;
        ELSIF S_CHAR = '(' THEN
          --括号数+1
          N_BRACKET := N_BRACKET+1;
        ELSIF S_CHAR = ')' THEN
          --括号数-1
          N_BRACKET := N_BRACKET-1; 
          IF N_BRACKET = 0 THEN
            --已到最外层括号，则处理括号内的内容
            S_STR := SUBSTR(IS_EXPRESSION, N_BEGIN, N_INDEX-N_BEGIN);
            N_BEGIN := N_INDEX+1;
            IF S_FUN IS NULL THEN
              --非函数，则递归分解括号内的内容
              S_RESULT := S_RESULT || F_EXPR_XLS2DB(S_STR) || S_CHAR;
            ELSE
              --函数，则获取对应的参数
              P_ANALYZE_PARAM(S_STR, N_PARAM_CNT, S_PARAMS);
              
              --根据函数处理拼接
              S_FUN := UPPER(S_FUN);
              IF S_FUN = 'IF' THEN
                IF N_PARAM_CNT = 3 THEN
                  S_RESULT := S_RESULT || 'CASE WHEN ' || F_EXPR_XLS2DB(S_PARAMS(1))
                    || ' THEN ' || F_EXPR_XLS2DB(S_PARAMS(2)) 
                    || ' ELSE ' || F_EXPR_XLS2DB(S_PARAMS(3))
                    || ' END';
                ELSE
                  RAISE_APPLICATION_ERROR(-20101, 'IF函数的参数只允许有3个！');
                END IF;
              ELSIF S_FUN = 'AND' OR S_FUN = 'OR' THEN
                IF N_PARAM_CNT < 2 THEN
                  RAISE_APPLICATION_ERROR(-20101, S_FUN || '函数的参数至少有2个！');
                ELSE
                  S_RESULT := S_RESULT || '(' || F_EXPR_XLS2DB(S_PARAMS(1));
                  FOR N_I IN 2..N_PARAM_CNT LOOP
                    S_RESULT := S_RESULT || ' ' || S_FUN || ' ' || F_EXPR_XLS2DB(S_PARAMS(N_I));
                  END LOOP;
                  S_RESULT := S_RESULT || ')';
                END IF;
              ELSIF S_FUN = 'SUM' THEN
                IF N_PARAM_CNT < 2 THEN
                  RAISE_APPLICATION_ERROR(-20101, S_FUN || '函数的参数至少有2个！');
                ELSE
                  S_RESULT := S_RESULT || '(' || F_EXPR_XLS2DB(S_PARAMS(1));
                  FOR N_I IN 2..N_PARAM_CNT LOOP
                    S_RESULT := S_RESULT || '+' || F_EXPR_XLS2DB(S_PARAMS(N_I));
                  END LOOP;
                  S_RESULT := S_RESULT || ')';
                END IF;
              ELSIF S_FUN = 'MAX' THEN
                IF N_PARAM_CNT < 2 THEN
                  RAISE_APPLICATION_ERROR(-20101, S_FUN || '函数的参数至少有2个！');
                ELSE
                  S_RESULT := S_RESULT || 'GREATEST(' || F_EXPR_XLS2DB(S_PARAMS(1));
                  FOR N_I IN 2..N_PARAM_CNT LOOP
                    S_RESULT := S_RESULT || ',' || F_EXPR_XLS2DB(S_PARAMS(N_I));
                  END LOOP;
                  S_RESULT := S_RESULT || ')';
                END IF;
              ELSIF S_FUN = 'MIN' THEN
                IF N_PARAM_CNT < 2 THEN
                  RAISE_APPLICATION_ERROR(-20101, S_FUN || '函数的参数至少有2个！');
                ELSE
                  S_RESULT := S_RESULT || 'LEAST(' || F_EXPR_XLS2DB(S_PARAMS(1));
                  FOR N_I IN 2..N_PARAM_CNT LOOP
                    S_RESULT := S_RESULT || ',' || F_EXPR_XLS2DB(S_PARAMS(N_I));
                  END LOOP;
                  S_RESULT := S_RESULT || ')';
                END IF;
              ELSE
                --其它函数直接使用原函数名处理
                S_RESULT := S_RESULT || S_FUN || '(' || F_EXPR_XLS2DB(S_PARAMS(1));
                FOR N_I IN 2..N_PARAM_CNT LOOP
                  S_RESULT := S_RESULT || ',' || F_EXPR_XLS2DB(S_PARAMS(N_I));
                END LOOP;
                S_RESULT := S_RESULT || ')';
              END IF;
              --将函数名清空
              S_FUN := NULL;
            END IF;
          END IF; 
        END IF;
      END IF;
      
    END LOOP;
    IF N_BRACKET > 0 THEN
      RAISE_APPLICATION_ERROR(-20101, '缺少右括号(' || TO_CHAR(N_BRACKET) || ')个！');
    END IF;
    IF N_BEGIN <= N_COUNT THEN
      --将最后的内容拼接到公式中
      S_RESULT := S_RESULT || F_GET_PERCENT_VAL(SUBSTR(IS_EXPRESSION, N_BEGIN, N_COUNT-N_BEGIN+1));
    END IF;
    RETURN S_RESULT;
  END F_EXPR_XLS2DB;

  -----------------------------------------------------------------------------
  --  将公式中的计算项更新为字段名                                                    --
  -----------------------------------------------------------------------------
  FUNCTION P_REPLACE_EXP_ITEM
  (
    IN_POLICY_ID              IN NUMBER     --政策ID
    ,IS_EXPRESS               IN VARCHAR2   --表达式
    ,IS_PREFIX                IN VARCHAR2   --字段前缀
  ) 
  RETURN VARCHAR2
  IS
    S_RESULT VARCHAR2(1000);
    S_FIELD  VARCHAR2(30);
    N_I      NUMBER := 0;
  BEGIN
    S_RESULT := IS_EXPRESS;

    --循环取出公式
    FOR R_DEFINE IN
    (
      SELECT
        DEFINE_CODE
        ,ROWNUM
      FROM
        T_POL_POLICY_DEFINE
      WHERE
        POLICY_ID = IN_POLICY_ID
      ORDER BY
        DEFINE_CODE
    )
    LOOP
      N_I := N_I + 1;
      --获取字段名
      S_FIELD := IS_PREFIX || TRIM(TO_CHAR(N_I,'00'));
      --更新公式
      S_RESULT := REPLACE(S_RESULT,'['||R_DEFINE.DEFINE_CODE||']',S_FIELD);
    END LOOP;
    
    RETURN S_RESULT;
  END P_REPLACE_EXP_ITEM;

  -----------------------------------------------------------------------------
  --  将EXCEL表达式转换成数据库表达式，并将计算项转换成指定字段名，用于产品明细结果计算  
  --  注意：传入参数要先去掉前后空格，并将“"”变为“''”
  -----------------------------------------------------------------------------
  FUNCTION F_EXPR_XLS2DB_VAL
  (
    IS_EXPRESSION       IN  VARCHAR2     --EXCEL表达式
    ,IN_POLICY_ID        IN  NUMBER       --政策ID
  )
  RETURN VARCHAR2
  IS
    S_CHAR VARCHAR2(3);
    S_STR VARCHAR2(1000);
    S_FUN VARCHAR2(1000);
    S_RESULT VARCHAR2(4000);
    N_INDEX NUMBER;
    N_COUNT NUMBER;
    N_BRACKET NUMBER := 0;
    B_IN_QUOTES BOOLEAN := FALSE;
    N_BEGIN NUMBER;
    N_I NUMBER;
    N_J NUMBER;
    N_PARAM_CNT NUMBER;
    S_PARAMS STRING_ARRAY;
    S_PARAMS_SUM STRING_ARRAY;
    S_PARAM VARCHAR2(1000);
    S_CONDITION VARCHAR2(2000);
  BEGIN
    N_COUNT := LENGTH(IS_EXPRESSION);
    N_BEGIN := 1;
    S_RESULT := '';
    S_FUN := NULL;
    --循环字符串，查找分隔符，对取出的字符作相应的处理
    FOR N_INDEX IN 1..N_COUNT LOOP
      S_CHAR := SUBSTR(IS_EXPRESSION, N_INDEX, 1);
      IF S_CHAR = '''' THEN
        --引号则设置为引号内/外，在后面的处理中处理拼接
        B_IN_QUOTES := NOT B_IN_QUOTES;
      ELSIF NOT B_IN_QUOTES THEN
        --处理引号外的内容
        IF N_BRACKET = 0 THEN
          --非括号内，则判断相关逻辑
          IF S_CHAR = '(' THEN
            --括号数+1
            N_BRACKET := N_BRACKET+1;
            --第一个左括号，且存在非分隔符，则判断是否约定函数，是则记录，否则报错
            IF N_INDEX = N_BEGIN THEN
              --前一个为分隔符号（非函数），则直接拼接
              S_RESULT := S_RESULT || S_CHAR;
            ELSE
              --记录函数名
              S_FUN := SUBSTR(IS_EXPRESSION, N_BEGIN, N_INDEX-N_BEGIN);
            END IF;
            N_BEGIN := N_INDEX+1;
          ELSIF S_CHAR IN ('+','-','*','\','=','>','<',' ') THEN
            --分隔符，直接拼接
            IF N_BEGIN = N_INDEX THEN
              --第一个为“=”则去掉
              IF NOT (N_INDEX = 1 AND S_CHAR = '=') THEN
                --连续分隔符
                S_RESULT := S_RESULT || S_CHAR;
              END IF;
            ELSE
              S_STR := SUBSTR(IS_EXPRESSION, N_BEGIN, N_INDEX-N_BEGIN);
              S_RESULT := S_RESULT || F_GET_PERCENT_VAL(S_STR) || S_CHAR;
            END IF;
            N_BEGIN := N_INDEX+1;
          END IF;
        ELSIF S_CHAR = '(' THEN
          --括号数+1
          N_BRACKET := N_BRACKET+1;
        ELSIF S_CHAR = ')' THEN
          --括号数-1
          N_BRACKET := N_BRACKET-1; 
          IF N_BRACKET = 0 THEN
            --已到最外层括号，则处理括号内的内容
            S_STR := SUBSTR(IS_EXPRESSION, N_BEGIN, N_INDEX-N_BEGIN);
            N_BEGIN := N_INDEX+1;
            IF S_FUN IS NULL THEN
              --非函数，则递归分解括号内的内容
              S_RESULT := S_RESULT || F_EXPR_XLS2DB(S_STR) || S_CHAR;
            ELSE
              --函数，则获取对应的参数
              P_ANALYZE_PARAM(S_STR, N_PARAM_CNT, S_PARAMS);
              
              --根据函数处理拼接
              S_FUN := UPPER(S_FUN);
              IF S_FUN = 'IF' THEN
                IF N_PARAM_CNT = 3 THEN
                  --将IF中第一个参数的计算项更新为汇总字段
                  S_PARAM := P_REPLACE_EXP_ITEM(IN_POLICY_ID,S_PARAMS(1),'SUM');
                  S_RESULT := S_RESULT || 'CASE WHEN ' || F_EXPR_XLS2DB(S_PARAM)
                    || ' THEN ' || F_EXPR_XLS2DB(S_PARAMS(2)) 
                    || ' ELSE ' || F_EXPR_XLS2DB(S_PARAMS(3))
                    || ' END';
                ELSE
                  RAISE_APPLICATION_ERROR(-20101, 'IF函数的参数只允许有3个！');
                END IF;
              ELSIF S_FUN = 'AND' OR S_FUN = 'OR' THEN
                IF N_PARAM_CNT < 2 THEN
                  RAISE_APPLICATION_ERROR(-20101, S_FUN || '函数的参数至少有2个！');
                ELSE
                  S_RESULT := S_RESULT || '(' || F_EXPR_XLS2DB(S_PARAMS(1));
                  FOR N_I IN 2..N_PARAM_CNT LOOP
                    S_RESULT := S_RESULT || ' ' || S_FUN || ' ' || F_EXPR_XLS2DB(S_PARAMS(N_I));
                  END LOOP;
                  S_RESULT := S_RESULT || ')';
                END IF;
              ELSIF S_FUN = 'SUM' THEN
                IF N_PARAM_CNT < 2 THEN
                  RAISE_APPLICATION_ERROR(-20101, S_FUN || '函数的参数至少有2个！');
                ELSE
                  S_RESULT := S_RESULT || '(' || F_EXPR_XLS2DB(S_PARAMS(1));
                  FOR N_I IN 2..N_PARAM_CNT LOOP
                    S_RESULT := S_RESULT || '+' || F_EXPR_XLS2DB(S_PARAMS(N_I));
                  END LOOP;
                  S_RESULT := S_RESULT || ')';
                END IF;
              ELSIF S_FUN = 'MAX' OR S_FUN = 'GREATEST' THEN
                IF N_PARAM_CNT < 2 THEN
                  RAISE_APPLICATION_ERROR(-20101, S_FUN || '函数的参数至少有2个！');
                ELSE
                  --将各参数转换成汇总值的参数清单
                  FOR N_I IN 1..N_PARAM_CNT LOOP
                    S_PARAM := P_REPLACE_EXP_ITEM(IN_POLICY_ID,S_PARAMS(N_I),'SUM');
                    S_PARAMS_SUM(N_I) := F_EXPR_XLS2DB(S_PARAM);
                  END LOOP;

                  --需转换成CASE的表达，使用汇总值判断，用明细值计算
                  S_RESULT := S_RESULT || 'CASE ';
                  FOR N_I IN 1..N_PARAM_CNT LOOP
                    --条件
                    S_CONDITION := '';
                    S_PARAM := S_PARAMS_SUM(N_I);
                    FOR N_J IN 1..N_PARAM_CNT LOOP
                      IF N_J <> N_I THEN
                        IF S_CONDITION IS NULL THEN
                          S_CONDITION := S_PARAM || '>=' || S_PARAMS_SUM(N_J);
                        ELSE
                          S_CONDITION := S_CONDITION || ' AND ' || S_PARAM || '>=' || S_PARAMS_SUM(N_J);
                        END IF;
                      END IF;
                    END LOOP;
                    --拼接内容
                    S_RESULT := S_RESULT || ' WHEN ' || S_CONDITION
                      || ' THEN ' || F_EXPR_XLS2DB(S_PARAMS(N_I));
                  END LOOP;
                  S_RESULT := S_RESULT || ' END';
                  /*
                  S_RESULT := S_RESULT || 'GREATEST(' || F_EXPR_XLS2DB(S_PARAMS(1));
                  FOR N_I IN 2..N_PARAM_CNT LOOP
                    S_RESULT := S_RESULT || ',' || F_EXPR_XLS2DB(S_PARAMS(N_I));
                  END LOOP;
                  S_RESULT := S_RESULT || ')';
                  */
                END IF;
              ELSIF S_FUN = 'MIN' OR S_FUN = 'LEAST' THEN
                IF N_PARAM_CNT < 2 THEN
                  RAISE_APPLICATION_ERROR(-20101, S_FUN || '函数的参数至少有2个！');
                ELSE
                  --将各参数转换成汇总值的参数清单
                  FOR N_I IN 1..N_PARAM_CNT LOOP
                    S_PARAM := P_REPLACE_EXP_ITEM(IN_POLICY_ID,S_PARAMS(N_I),'SUM');
                    S_PARAMS_SUM(N_I) := F_EXPR_XLS2DB(S_PARAM);
                  END LOOP;

                  --需转换成CASE的表达，使用汇总值判断，用明细值计算
                  S_RESULT := S_RESULT || 'CASE ';
                  FOR N_I IN 1..N_PARAM_CNT LOOP
                    --条件
                    S_CONDITION := '';
                    S_PARAM := S_PARAMS_SUM(N_I);
                    FOR N_J IN 1..N_PARAM_CNT LOOP
                      IF N_J <> N_I THEN
                        IF S_CONDITION IS NULL THEN
                          S_CONDITION := S_PARAM || '<=' || S_PARAMS_SUM(N_J);
                        ELSE
                          S_CONDITION := S_CONDITION || ' AND ' || S_PARAM || '<=' || S_PARAMS_SUM(N_J);
                        END IF;
                      END IF;
                    END LOOP;
                    --拼接内容
                    S_RESULT := S_RESULT || ' WHEN ' || S_CONDITION
                      || ' THEN ' || F_EXPR_XLS2DB(S_PARAMS(N_I));
                  END LOOP;
                  S_RESULT := S_RESULT || ' END';
                  /*
                  S_RESULT := S_RESULT || 'LEAST(' || F_EXPR_XLS2DB(S_PARAMS(1));
                  FOR N_I IN 2..N_PARAM_CNT LOOP
                    S_RESULT := S_RESULT || ',' || F_EXPR_XLS2DB(S_PARAMS(N_I));
                  END LOOP;
                  S_RESULT := S_RESULT || ')';
                  */
                END IF;
              ELSE
                --其它函数直接使用原函数名处理
                S_RESULT := S_RESULT || S_FUN || '(' || F_EXPR_XLS2DB(S_PARAMS(1));
                FOR N_I IN 2..N_PARAM_CNT LOOP
                  S_RESULT := S_RESULT || ',' || F_EXPR_XLS2DB(S_PARAMS(N_I));
                END LOOP;
                S_RESULT := S_RESULT || ')';
              END IF;
              --将函数名清空
              S_FUN := NULL;
            END IF;
          END IF; 
        END IF;
      END IF;
      
    END LOOP;
    IF N_BEGIN <= N_COUNT THEN
      --将最后的内容拼接到公式中
      S_RESULT := S_RESULT || F_GET_PERCENT_VAL(SUBSTR(IS_EXPRESSION, N_BEGIN, N_COUNT-N_BEGIN+1));
    END IF;
    RETURN S_RESULT;
  END F_EXPR_XLS2DB_VAL;

  -----------------------------------------------------------------------------
  --  将EXCEL表达式转换成数据库表达式 
  --  为优化性能，先将参数处理后再调用转换  
  -----------------------------------------------------------------------------
  FUNCTION F_GET_DB_EXPRESSION
  (
    IS_EXPRESSION       IN  VARCHAR2     --EXCEL表达式
  )
  RETURN VARCHAR2
  IS
    S_EXPRESSION VARCHAR2(2000);
  BEGIN
    --清空前后空格，并将“"”变为“''”
    S_EXPRESSION := REPLACE(IS_EXPRESSION,'"','''');
    --清除回车符
    S_EXPRESSION := REPLACE(S_EXPRESSION,CHR(13),'');
    S_EXPRESSION := REPLACE(S_EXPRESSION,CHR(10),'');
    --使用正常的公式处理转换
    RETURN F_EXPR_XLS2DB(TRIM(S_EXPRESSION));
  END F_GET_DB_EXPRESSION;
  
  -----------------------------------------------------------------------------
  --  在表达式中检查指定变量是否用于计算（非判断）   
  --  注意：传入参数要先去掉前后空格，并将“"”变为“''”
  -----------------------------------------------------------------------------
  FUNCTION F_GET_EXP_NO_IF
  (
    IS_EXPRESSION       IN  VARCHAR2     --EXCEL表达式
  )
  RETURN VARCHAR2
  IS
    S_CHAR VARCHAR2(3);
    S_STR VARCHAR2(1000);
    S_FUN VARCHAR2(1000);
    S_RESULT VARCHAR2(4000);
    N_INDEX NUMBER;
    N_COUNT NUMBER;
    N_BRACKET NUMBER := 0;
    B_IN_QUOTES BOOLEAN := FALSE;
    N_BEGIN NUMBER;
    N_I NUMBER;
    N_PARAM_CNT NUMBER;
    S_PARAMS STRING_ARRAY;
  BEGIN
    N_COUNT := LENGTH(IS_EXPRESSION);
    N_BEGIN := 1;
    S_RESULT := '';
    S_FUN := NULL;
    --循环字符串，查找分隔符，对取出的字符作相应的处理
    FOR N_INDEX IN 1..N_COUNT LOOP
      S_CHAR := SUBSTR(IS_EXPRESSION, N_INDEX, 1);
      IF S_CHAR = '''' THEN
        --引号则设置为引号内/外，在后面的处理中处理拼接
        B_IN_QUOTES := NOT B_IN_QUOTES;
      ELSIF NOT B_IN_QUOTES THEN
        --处理引号外的内容
        IF N_BRACKET = 0 THEN
          --非括号内，则判断相关逻辑
          IF S_CHAR = '(' THEN
            --括号数+1
            N_BRACKET := N_BRACKET+1;
            --第一个左括号，且存在非分隔符，则判断是否约定函数，是则记录，否则报错
            IF N_INDEX = N_BEGIN THEN
              --第一个为“=”则去掉
              IF NOT (N_INDEX = 1 AND S_CHAR = '=') THEN
                --前一个为分隔符号（非函数），则直接拼接
                S_RESULT := S_RESULT || S_CHAR;
              END IF;
            ELSE
              --记录函数名
              S_FUN := SUBSTR(IS_EXPRESSION, N_BEGIN, N_INDEX-N_BEGIN);
            END IF;
            N_BEGIN := N_INDEX+1;
          ELSIF S_CHAR IN ('+','-','*','\','=','>','<',' ') THEN
            --分隔符，直接拼接
            IF N_BEGIN = N_INDEX THEN
              --连续分隔符
              S_RESULT := S_RESULT || S_CHAR;
            ELSE
              S_STR := SUBSTR(IS_EXPRESSION, N_BEGIN, N_INDEX-N_BEGIN);
              S_RESULT := S_RESULT || F_GET_PERCENT_VAL(S_STR) || S_CHAR;
            END IF;
            N_BEGIN := N_INDEX+1;
          END IF;
        ELSIF S_CHAR = '(' THEN
          --括号数+1
          N_BRACKET := N_BRACKET+1;
        ELSIF S_CHAR = ')' THEN
          --括号数-1
          N_BRACKET := N_BRACKET-1; 
          IF N_BRACKET = 0 THEN
            --已到最外层括号，则处理括号内的内容
            S_STR := SUBSTR(IS_EXPRESSION, N_BEGIN, N_INDEX-N_BEGIN);
            N_BEGIN := N_INDEX+1;
            IF S_FUN IS NULL THEN
              --非函数，则递归分解括号内的内容
              S_RESULT := S_RESULT || F_EXPR_XLS2DB(S_STR) || S_CHAR;
            ELSE
              --函数，则获取对应的参数
              P_ANALYZE_PARAM(S_STR, N_PARAM_CNT, S_PARAMS);
              
              --根据函数处理拼接
              S_FUN := UPPER(S_FUN);
              IF S_FUN = 'IF' THEN
                IF N_PARAM_CNT = 3 THEN
                  S_RESULT := S_RESULT || 'CASE WHEN 1=1' --取消判断处理|| F_EXPR_XLS2DB(S_PARAMS(1))
                    || ' THEN ' || F_GET_EXP_NO_IF(S_PARAMS(2)) 
                    || ' ELSE ' || F_GET_EXP_NO_IF(S_PARAMS(3))
                    || ' END';
                ELSE
                  RAISE_APPLICATION_ERROR(-20101, 'IF函数的参数只允许有3个！');
                END IF;
              ELSIF S_FUN = 'AND' OR S_FUN = 'OR' THEN
                IF N_PARAM_CNT < 2 THEN
                  RAISE_APPLICATION_ERROR(-20101, S_FUN || '函数的参数至少有2个！');
                ELSE
                  S_RESULT := S_RESULT || '(' || F_GET_EXP_NO_IF(S_PARAMS(1));
                  FOR N_I IN 2..N_PARAM_CNT LOOP
                    S_RESULT := S_RESULT || ' ' || S_FUN || ' ' || F_GET_EXP_NO_IF(S_PARAMS(N_I));
                  END LOOP;
                  S_RESULT := S_RESULT || ')';
                END IF;
              ELSIF S_FUN = 'SUM' THEN
                IF N_PARAM_CNT < 2 THEN
                  RAISE_APPLICATION_ERROR(-20101, S_FUN || '函数的参数至少有2个！');
                ELSE
                  S_RESULT := S_RESULT || '(' || F_GET_EXP_NO_IF(S_PARAMS(1));
                  FOR N_I IN 2..N_PARAM_CNT LOOP
                    S_RESULT := S_RESULT || '+' || F_GET_EXP_NO_IF(S_PARAMS(N_I));
                  END LOOP;
                  S_RESULT := S_RESULT || ')';
                END IF;
              ELSIF S_FUN = 'MAX' THEN
                IF N_PARAM_CNT < 2 THEN
                  RAISE_APPLICATION_ERROR(-20101, S_FUN || '函数的参数至少有2个！');
                ELSE
                  S_RESULT := S_RESULT || 'GREATEST(' || F_GET_EXP_NO_IF(S_PARAMS(1));
                  FOR N_I IN 2..N_PARAM_CNT LOOP
                    S_RESULT := S_RESULT || ',' || F_GET_EXP_NO_IF(S_PARAMS(N_I));
                  END LOOP;
                  S_RESULT := S_RESULT || ')';
                END IF;
              ELSIF S_FUN = 'MIN' THEN
                IF N_PARAM_CNT < 2 THEN
                  RAISE_APPLICATION_ERROR(-20101, S_FUN || '函数的参数至少有2个！');
                ELSE
                  S_RESULT := S_RESULT || 'LEAST(' || F_GET_EXP_NO_IF(S_PARAMS(1));
                  FOR N_I IN 2..N_PARAM_CNT LOOP
                    S_RESULT := S_RESULT || ',' || F_GET_EXP_NO_IF(S_PARAMS(N_I));
                  END LOOP;
                  S_RESULT := S_RESULT || ')';
                END IF;
              ELSE
                --其它函数直接使用原函数名处理
                S_RESULT := S_RESULT || S_FUN || '(' || F_GET_EXP_NO_IF(S_PARAMS(1));
                FOR N_I IN 2..N_PARAM_CNT LOOP
                  S_RESULT := S_RESULT || ',' || F_GET_EXP_NO_IF(S_PARAMS(N_I));
                END LOOP;
                S_RESULT := S_RESULT || ')';
              END IF;
              --将函数名清空
              S_FUN := NULL;
            END IF;
          END IF; 
        END IF;
      END IF;
      
    END LOOP;
    IF N_BEGIN <= N_COUNT THEN
      --将最后的内容拼接到公式中
      S_RESULT := S_RESULT || F_GET_PERCENT_VAL(SUBSTR(IS_EXPRESSION, N_BEGIN, N_COUNT-N_BEGIN+1));
    END IF;
    RETURN S_RESULT;
  END F_GET_EXP_NO_IF;

  -----------------------------------------------------------------------------
  --  检查SQL中的SELECT语句是否包含定指的字段名   
  -----------------------------------------------------------------------------
  FUNCTION F_CHECK_SELECT_FIELD
  (
    IS_SQL       IN  VARCHAR2     --SQL语句
    ,IS_FIELD    IN  VARCHAR2     --要检查的字段名
  )
  RETURN BOOLEAN
  IS
    S_CHAR VARCHAR2(3);
    S_SQL VARCHAR2(4000);
    S_FIELD VARCHAR2(30);
    S_STR VARCHAR2(1000);
    N_INDEX NUMBER;
    N_COUNT NUMBER;
    N_BRACKET NUMBER := 0;
    B_IN_QUOTES BOOLEAN := FALSE;
    N_BEGIN NUMBER;
    B_FOUND BOOLEAN := FALSE;
  BEGIN
    S_SQL := UPPER(IS_SQL);
    S_FIELD := UPPER(IS_FIELD);
    N_COUNT := LENGTH(S_SQL);
    N_BEGIN := 1;
    --循环字符串，查找分隔符，对取出的字符作相应的处理
    FOR N_INDEX IN 1..N_COUNT LOOP
      S_CHAR := SUBSTR(IS_SQL, N_INDEX, 1);
      IF S_CHAR = '''' THEN
        --引号则设置为引号内/外，在后面的处理中处理拼接
        B_IN_QUOTES := NOT B_IN_QUOTES;
      ELSIF NOT B_IN_QUOTES THEN
        --处理引号外的内容
        IF N_BRACKET = 0 THEN
          --非括号内，则判断相关逻辑
          IF S_CHAR = '(' THEN
            --括号数+1
            N_BRACKET := N_BRACKET+1;
            N_BEGIN := N_INDEX+1;
          ELSIF S_CHAR IN ('+','-','*','\','=','>','<',' ',',','.') THEN
            --分隔符，直接拼接
            IF N_BEGIN < N_INDEX THEN
              S_STR := SUBSTR(S_SQL, N_BEGIN, N_INDEX-N_BEGIN);
              IF S_STR = S_FIELD THEN
                B_FOUND := TRUE;
                EXIT;
              ELSIF S_STR = 'FROM' THEN
                EXIT;
              END IF;
            END IF;
            N_BEGIN := N_INDEX+1;
          END IF;
        ELSIF S_CHAR = '(' THEN
          --括号数+1
          N_BRACKET := N_BRACKET+1;
        ELSIF S_CHAR = ')' THEN
          --括号数-1
          N_BRACKET := N_BRACKET-1; 
        END IF;
      END IF;
      
    END LOOP;

    RETURN B_FOUND;
  END F_CHECK_SELECT_FIELD;

  -----------------------------------------------------------------------------
  --  政策算法定义(计算公式)转换过程：                                       --
  -----------------------------------------------------------------------------
  PROCEDURE P_DEFINE_TRANC(IN_POLICY_ID          IN NUMBER   --政策ID
                          ,IS_USER_ID            IN VARCHAR2 --用户账号
                          ,OS_MESSAGE           OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
                          ) IS
    --政策算法定义(计算公式)
    /*
    CURSOR C_DEFINE_TRANC IS
      SELECT T.DEFINE_ID
           , T.DEFINE_GROUP
           , T.DEFINE_CODE
           , T.DEFINE_NAME
           , T.GET_VAL_TYPE
           , T.PRIOR_LEVEL
           , T.SEM_CODE
           , T.SEM_EXP
           , T.SEM_BEGIN_DATE
           , T.SEM_END_DATE
           , T.DETAIL_FLAG
           , T.CAL_EXP
           , T.CAL_DB_EXP
           , T.MTL_TYPE
           , T.CONDITION
           , T.COMMENTS
        FROM T_POL_POLICY_DEFINE T
       WHERE T.POLICY_ID = IN_POLICY_ID
         AND T.GET_VAL_TYPE = '2'
         AND T.CAL_EXP IS NOT NULL
       ORDER BY T.DEFINE_CODE;
    R_DEFINE_TRANC C_DEFINE_TRANC%ROWTYPE;
    */

    N_CNT                   NUMBER; --计数器
    N_UPDATE_CNT            NUMBER;
    PRAGMA AUTONOMOUS_TRANSACTION;  --采用自治事务，以便于计算过程出错后能记录公式转换内容
  BEGIN
    OS_MESSAGE := 'OK';

    --循环转换每个算法项设置
    /*
    IF (OS_MESSAGE = 'OK') THEN
      FOR R_DEFINE_TRANC IN C_DEFINE_TRANC
      LOOP
        --调用过程
        IF (OS_MESSAGE = 'OK') THEN
          P_VAL_EXP_TRANSLATE(R_DEFINE_TRANC.DEFINE_ID
                             ,IS_USER_ID
                             ,OS_MESSAGE);
        ELSE
          EXIT;
        END IF;
      END LOOP;
    END IF;
    */
    --将Excel表达式转换为数据库表达式，先将双引号转换成单引号
    UPDATE 
      T_POL_POLICY_DEFINE
    SET
      CAL_DB_EXP = F_GET_DB_EXPRESSION(CAL_EXP)
    WHERE
      POLICY_ID = IN_POLICY_ID
      AND GET_VAL_TYPE = '2'
      AND CAL_EXP IS NOT NULL;

    --处理优先级
    IF (OS_MESSAGE = 'OK') THEN
      --优先级全部初始为 1000
      UPDATE T_POL_POLICY_DEFINE
         SET PRIOR_LEVEL = 1000
            ,LAST_UPDATED_BY = IS_USER_ID
            ,LAST_UPDATE_DATE = SYSDATE
       WHERE POLICY_ID = IN_POLICY_ID;

      --语义的优先级为 1
      UPDATE T_POL_POLICY_DEFINE T
         SET T.PRIOR_LEVEL = 1
            ,LAST_UPDATED_BY = IS_USER_ID
            ,LAST_UPDATE_DATE = SYSDATE
       WHERE T.POLICY_ID = IN_POLICY_ID
         AND T.GET_VAL_TYPE IN ('1', '4', '3');  --'语义', '调整项', '外部数据'

      --根据公式定义，初始优先级
      N_UPDATE_CNT := 1;
      FOR N_CNT IN 2..999 LOOP
        IF (N_UPDATE_CNT > 0) THEN
          UPDATE T_POL_POLICY_DEFINE T
             SET T.PRIOR_LEVEL = N_CNT
                ,LAST_UPDATED_BY = IS_USER_ID
                ,LAST_UPDATE_DATE = SYSDATE
           WHERE T.POLICY_ID = IN_POLICY_ID
             AND T.PRIOR_LEVEL = 1000
             AND NOT EXISTS(SELECT 1
                              FROM T_POL_POLICY_DEFINE S
                             WHERE S.POLICY_ID = IN_POLICY_ID
                               AND S.PRIOR_LEVEL = 1000
                               AND INSTR(T.CAL_DB_EXP, '[' || S.DEFINE_CODE || ']', 1, 1) > 0 )
             AND NOT EXISTS(SELECT 1
                              FROM T_POL_POLICY_DEFINE S2
                             WHERE S2.POLICY_ID = IN_POLICY_ID
                               AND S2.PRIOR_LEVEL = 1000
                               AND INSTR(T.CAL_EXP,'[' || S2.DEFINE_CODE || ']', 1, 1) > 0 );
          N_UPDATE_CNT := SQL%ROWCOUNT;
        END IF;
      END LOOP;
    END IF;
    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      OS_MESSAGE := '政策计算公式转换过程出错！(POLICY_ID=' || TO_CHAR(IN_POLICY_ID) || ')' || SQLERRM;
  END;

  -----------------------------------------------------------------------------
  --  政策状态                                                               --
  -----------------------------------------------------------------------------
  PROCEDURE P_GET_POLICY_STATUS(IN_POLICY_ID              IN NUMBER   --政策ID
                               ,OS_STATUS                OUT VARCHAR2 --返回状态
                               ,OS_MESSAGE               OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
                               ) IS

    S_POLICY_STATUS      VARCHAR2(40);
  BEGIN
    OS_MESSAGE := 'OK';

    BEGIN
      --已返利
      SELECT '4'
        INTO S_POLICY_STATUS
        FROM T_POL_POLICY SP
       WHERE SP.POLICY_ID = IN_POLICY_ID
         AND NOT EXISTS(SELECT 1
                          FROM T_POL_POLICY_RESULT PR
                         WHERE SP.POLICY_ID = PR.POLICY_ID
                           AND PR.RESULT_DATE = SP.REPORT_DATE
                           AND NVL(PR.RECKON_AMOUNT, 0) + NVL(PR.ADJUST_AMOUNT, 0) - NVL(PR.REBATE_AMOUNT, 0) <> 0
                           AND PR.POLICY_ORDER_LINE_ID IS NULL
                       )
         AND EXISTS(SELECT 1
                      FROM T_POL_POLICY_RESULT PR2
                     WHERE SP.POLICY_ID = PR2.POLICY_ID
                       AND PR2.RESULT_DATE = SP.REPORT_DATE
                       AND NVL(PR2.RECKON_AMOUNT, 0) <> 0
                   );
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
      BEGIN
        --部分返利
        SELECT '1'
          INTO S_POLICY_STATUS
          FROM T_POL_POLICY SP
         WHERE SP.POLICY_ID = IN_POLICY_ID
           AND EXISTS(SELECT 1
                        FROM T_POL_POLICY_RESULT PR
                       WHERE SP.POLICY_ID = PR.POLICY_ID
                         AND PR.RESULT_DATE = SP.REPORT_DATE
                         AND PR.POLICY_ORDER_LINE_ID IS NOT NULL
                     );
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
        /*BEGIN
          --已审核
          SELECT '6'
            INTO S_POLICY_STATUS
            FROM T_POL_POLICY SP
           WHERE SP.POLICY_ID = IN_POLICY_ID
             AND NOT EXISTS(SELECT 1
                              FROM T_POL_POLICY_RESULT PR
                             WHERE SP.POLICY_ID = PR.POLICY_ID
                               AND PR.RESULT_DATE = SP.REPORT_DATE
                               AND NVL(PR.REBATE_AMOUNT, 0) <> 0
                            );
        EXCEPTION
          WHEN NO_DATA_FOUND THEN*/
            S_POLICY_STATUS := NULL;
        --END;
      END;
    END;
    OS_STATUS := S_POLICY_STATUS;
  EXCEPTION
    WHEN OTHERS THEN  
      OS_MESSAGE := '获取政策状态过程出错！' || SQLERRM;
  END;

  -----------------------------------------------------------------------------
  --  来源SQL计算明细结果                                                    --
  -----------------------------------------------------------------------------
  PROCEDURE P_GET_SQL_VALUE(IN_DEFINE_ID              IN NUMBER   --政策算法定义ID
                           ,ID_RESULT_DATE            IN DATE     --报表日期
                           ,IS_USER_ID                IN VARCHAR2 --用户账号
                           ,IS_PRE_CALC               IN VARCHAR2 --试算标识（Y/N）
                           ,OS_MESSAGE               OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
                           ) IS
    N_POLICY_ID              NUMBER;
    S_DEFINE_CODE            VARCHAR2(100);
    S_GET_VAL_TYPE           VARCHAR2(40);
    S_SEM_CODE               VARCHAR2(100);
    S_SEM_EXP                VARCHAR2(240);
    D_SEM_BEGIN_DATE         DATE;
    D_SEM_END_DATE           DATE;
    S_DETAIL_FLAG            VARCHAR2(1);
    S_MTL_TYPE               VARCHAR2(40);   --商品分类
    S_CONDITION              VARCHAR2(4000);
    S_CONDITION_SQL          VARCHAR2(4000); --限制条件SQL
    N_ENTITY_ID              NUMBER;         --主体ID

    N_CUR                    NUMBER;
    N_ROW                    NUMBER;
    S_SEMANTIC_VAL_0         VARCHAR2(4000);
    S_SEMANTIC_VAL_1         VARCHAR2(4000);
    S_SEMANTIC_VAL_2         VARCHAR2(4000);
    S_SEMANTIC_VAL_3         VARCHAR2(4000);

    S_SEMANTIC_TYPE          VARCHAR2(40);   --语义类型：SQL取值、计算公式
    S_SEMANTIC_VAL           VARCHAR2(4000); --取值SQL
    S_PRE_PROC_SQL           VARCHAR2(4000); --预处理SQL
    S_QUERY_CODE             VARCHAR2(40);   --查询条件编码
    S_FREEZE_QUERY_CODE      VARCHAR2(40);   --冻结明细查询条件编码
    S_PRE_CALCULATE_SQL      VARCHAR2(4000); --试算SQL
    
    N_FOUND_FREEZE_ORDER     NUMBER;
    S_FIELD                  VARCHAR2(40);
    S_FIELDS1                VARCHAR2(100);
    S_FIELDS2                VARCHAR2(100);
    S_FIELDS3                VARCHAR2(100);
    N_I                      NUMBER;
    S_SQL                    VARCHAR2(4000);
    S_STEP                   VARCHAR2(40);
  BEGIN
    OS_MESSAGE := 'OK';

    --政策算法定义信息
    S_STEP := '读取政策算法定义信息';
    SELECT T.POLICY_ID
         , T.DEFINE_CODE
         , T.GET_VAL_TYPE
         , T.SEM_CODE
         , T.SEM_EXP
         , T.SEM_BEGIN_DATE
         , T.SEM_END_DATE
         , T.DETAIL_FLAG
         , T.MTL_TYPE
         , T.CONDITION
         , T.CONDITION_SQL
      INTO N_POLICY_ID
         , S_DEFINE_CODE
         , S_GET_VAL_TYPE
         , S_SEM_CODE
         , S_SEM_EXP
         , D_SEM_BEGIN_DATE
         , D_SEM_END_DATE
         , S_DETAIL_FLAG
         , S_MTL_TYPE
         , S_CONDITION
         , S_CONDITION_SQL
      FROM T_POL_POLICY_DEFINE T
     WHERE T.DEFINE_ID = IN_DEFINE_ID;

    --政策信息
    S_STEP := '读取政策信息';
    SELECT SP.ENTITY_ID
      INTO N_ENTITY_ID
      FROM T_POL_POLICY SP
     WHERE SP.POLICY_ID = N_POLICY_ID;

    --获取语义信息
    S_STEP := '获取语义信息';
    P_GET_ENTITY_SEMANTIC(S_SEM_CODE          --语义编码
                         ,N_ENTITY_ID
                         ,S_SEMANTIC_TYPE     --语义类型：SQL取值、计算公式
                         ,S_SEMANTIC_VAL      --取值SQL
                         ,S_PRE_PROC_SQL      --预处理SQL
                         ,S_QUERY_CODE        --查询条件编码
                         ,S_FREEZE_QUERY_CODE --冻结明细查询条件编码
                         ,OS_MESSAGE);

    IF (OS_MESSAGE = 'OK') AND (S_SEMANTIC_TYPE = '计算公式') THEN
      OS_MESSAGE := '政策算法定义项目的语义暂时不支持计算公式！(项目ID=' || TO_CHAR(IN_DEFINE_ID) || ')';
    END IF;
    
    IF (OS_MESSAGE = 'OK' AND IS_PRE_CALC = 'Y') THEN
      S_STEP := '获取试算SQL';
      BEGIN
        SELECT S.PRE_CALCULATE_SQL
          INTO S_PRE_CALCULATE_SQL
          FROM CIMS.T_POL_SEMANTIC S
         WHERE S.SEMANTIC_CODE = S_SEM_CODE
           AND S.ENTITY_ID = N_ENTITY_ID;
           
        IF S_PRE_CALCULATE_SQL IS NULL THEN
          OS_MESSAGE := '语义('|| S_SEM_CODE || ')未定义试算SQL';
        ELSE
         S_SEMANTIC_VAL := S_PRE_CALCULATE_SQL;
        END IF;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          OS_MESSAGE := '根据语义编码和主体信息找不到对应的语义';
      END;
    END IF;

    /*统一在P_RESULT_INIT中处理
    --删除报表日期的冻结数据
    IF (OS_MESSAGE = 'OK') THEN
      S_STEP := '删除报表日期的冻结数据';
      DELETE
        FROM T_POL_POLICY_FREEZE T
       WHERE T.POLICY_ID = N_POLICY_ID
         AND T.DEFINE_ID = IN_DEFINE_ID;
    END IF;
    */

    --预处理SQL替换限制条件
    IF (OS_MESSAGE = 'OK' AND INSTR(S_PRE_PROC_SQL, '[P_CONDITION_SQL]', 1, 1) > 0
      AND IS_PRE_CALC <> 'Y') THEN
      IF (S_CONDITION_SQL IS NOT NULL) THEN
        S_PRE_PROC_SQL := REPLACE(S_PRE_PROC_SQL,'[P_CONDITION_SQL]','(' || S_CONDITION_SQL || ')');
      ELSE
        S_PRE_PROC_SQL := REPLACE(S_PRE_PROC_SQL,'[P_CONDITION_SQL]','1=1');
      END IF;
    END IF;

    --若预处理SQL存在商品分类参数，而语义项商品分类参数值为空，则将“:P_MTL_TYPE IS NULL” 改为“1=1”
    IF (OS_MESSAGE = 'OK' AND INSTR(S_PRE_PROC_SQL, ':P_MTL_TYPE IS NULL', 1, 1) > 0
      AND IS_PRE_CALC <> 'Y') THEN
      IF S_MTL_TYPE IS NULL THEN
        S_PRE_PROC_SQL := REPLACE(S_PRE_PROC_SQL,':P_MTL_TYPE IS NULL','1=1');
      ELSE
        S_PRE_PROC_SQL := REPLACE(S_PRE_PROC_SQL,':P_MTL_TYPE IS NULL OR','');
      END IF;
    END IF;

    --预执行语句
    IF (OS_MESSAGE = 'OK') AND (S_PRE_PROC_SQL IS NOT NULL) AND (IS_PRE_CALC <> 'Y') THEN
      S_STEP := '执行预处理语句';
      --记录SQL，出错时记录到跟踪表中
      S_SEMANTIC_VAL_0 := S_PRE_PROC_SQL; 
      --打开光标
      N_CUR := DBMS_SQL.OPEN_CURSOR;
      --解析动态SQL语句
      DBMS_SQL.PARSE(N_CUR, S_PRE_PROC_SQL, DBMS_SQL.NATIVE);
      --绑定输入参数
      IF INSTR(S_PRE_PROC_SQL, ':P_BEGIN_DATE', 1, 1) > 0 THEN
        DBMS_SQL.BIND_VARIABLE(N_CUR, ':P_BEGIN_DATE', D_SEM_BEGIN_DATE);
      END IF;
      IF INSTR(S_PRE_PROC_SQL, ':P_END_DATE', 1, 1) > 0 THEN
        DBMS_SQL.BIND_VARIABLE(N_CUR, ':P_END_DATE', D_SEM_END_DATE);
      END IF;
      IF INSTR(S_PRE_PROC_SQL, ':P_POLICY_ID', 1, 1) > 0 THEN
        DBMS_SQL.BIND_VARIABLE(N_CUR, ':P_POLICY_ID', N_POLICY_ID);
      END IF;
      IF INSTR(S_PRE_PROC_SQL, ':P_DEFINE_ID', 1, 1) > 0 THEN
        DBMS_SQL.BIND_VARIABLE(N_CUR, ':P_DEFINE_ID', IN_DEFINE_ID);
      END IF;
      IF INSTR(S_PRE_PROC_SQL, ':P_MTL_TYPE', 1, 1) > 0 THEN
        DBMS_SQL.BIND_VARIABLE(N_CUR, ':P_MTL_TYPE', S_MTL_TYPE);
      END IF;
      IF INSTR(S_PRE_PROC_SQL, ':P_RESULT_DATE', 1, 1) > 0 THEN
        DBMS_SQL.BIND_VARIABLE(N_CUR, ':P_RESULT_DATE', ID_RESULT_DATE);
      END IF;
      IF INSTR(S_PRE_PROC_SQL, ':P_ENTITY_ID', 1, 1) > 0 THEN
        DBMS_SQL.BIND_VARIABLE(N_CUR, ':P_ENTITY_ID', N_ENTITY_ID);
      END IF;
      IF INSTR(S_PRE_PROC_SQL, ':P_CONDITION_SQL', 1, 1) > 0 THEN
        DBMS_SQL.BIND_VARIABLE(N_CUR, ':P_CONDITION_SQL', S_CONDITION_SQL);
      END IF;
      --执行语句
      N_ROW := DBMS_SQL.EXECUTE(N_CUR);
      --关闭光标
      DBMS_SQL.CLOSE_CURSOR(N_CUR);
    END IF;

    --根据客户关系更新冻结明细表的目标客户ID
    IF (OS_MESSAGE = 'OK' AND IS_PRE_CALC <> 'Y') THEN
      --判断是否存在插入冻结明细T_POL_POLICY_FREEZE表
      N_FOUND_FREEZE_ORDER := INSTR(UPPER(S_PRE_PROC_SQL), 'T_POL_POLICY_FREEZE'); 
      --更新T_POL_POLICY_FREEZE表的目标客户ID
      IF (N_FOUND_FREEZE_ORDER > 0) THEN
        S_STEP := '更新冻结明细表目标客户';
        UPDATE T_POL_POLICY_FREEZE T
           SET T.TAR_ACCOUNT_ID = (SELECT CT.TAR_ACCOUNT_ID
                                      FROM T_POL_POLICY_CUS_TYPE_TMP CT
                                     WHERE CT.POLICY_ID = N_POLICY_ID
                                       AND CT.ACCOUNT_ID = T.ACCOUNT_ID)
         WHERE T.POLICY_ID = N_POLICY_ID
           AND T.DEFINE_ID = IN_DEFINE_ID;
           --AND T.FREEZE_DATE = ID_RESULT_DATE;
      END IF;
    END IF;

    --若不存在插入冻结明细，则在执行语句时处理限制条件
    IF (OS_MESSAGE = 'OK') AND (S_CONDITION_SQL IS NOT NULL)
      AND (S_FREEZE_QUERY_CODE IS NULL)
      AND (INSTR(S_SEMANTIC_VAL, ':P_CONDITION_SQL', 1, 1) = 0) THEN
      S_SEMANTIC_VAL := S_SEMANTIC_VAL || ' AND (' || S_CONDITION_SQL || ')';
    END IF;

    --若取值SQL存在商品分类参数，而语义项商品分类参数值为空，则将“:P_MTL_TYPE IS NULL” 改为“1=1”
    IF (OS_MESSAGE = 'OK' AND INSTR(S_SEMANTIC_VAL, ':P_MTL_TYPE IS NULL', 1, 1) > 0) THEN
      IF S_MTL_TYPE IS NULL THEN
        S_SEMANTIC_VAL := REPLACE(S_SEMANTIC_VAL,':P_MTL_TYPE IS NULL','1=1');
      ELSE
        S_SEMANTIC_VAL := REPLACE(S_SEMANTIC_VAL,':P_MTL_TYPE IS NULL OR','');
      END IF;
    END IF;

    --语义语句
    IF (OS_MESSAGE = 'OK') AND (S_SEMANTIC_VAL IS NOT NULL) THEN
      --取语义对应的动态分类
      S_FIELDS1 := '';
      S_FIELDS2 := '';
      S_FIELDS3 := '';
      S_SQL := UPPER(S_SEMANTIC_VAL);
      FOR N_I IN 1..5 LOOP
        --语义中存在对应的分类字段，则记录
        S_FIELD := 'TYPE0' || TO_CHAR(N_I);
        IF INSTR(S_SQL, S_FIELD) > 0 THEN
          S_FIELDS1 := S_FIELDS1 || ',' || S_FIELD;
          S_FIELDS2 := S_FIELDS2 || ',T_R_T.' || S_FIELD;
          S_FIELDS3 := S_FIELDS3 || ',T_RC_RCD.' || S_FIELD;
        END IF;
      END LOOP;
      
      S_STEP := '执行语义语句';
      --处理执行语句，将分类字段放到SQL中
      S_SEMANTIC_VAL_1 := 'INSERT INTO T_POL_POLICY_RESULT_DETAIL(DETAIL_ID, POLICY_ID, ACCOUNT_ID'
                     || S_FIELDS1
                     || ', RESULT_DATE, DEFINE_ID, RESULT_VALUE, VALUE_TYPE, CREATED_BY, CREATION_DATE, LAST_UPDATED_BY, LAST_UPDATE_DATE) '
                     || '  SELECT S_POL_POLICY_RESULT_DETAIL.NEXTVAL '
                     || '       , ' || TO_CHAR(N_POLICY_ID)
                     || '       , T_R_T.TAR_ACCOUNT_ID '
                     || S_FIELDS2
                     || '       , :P_RESULT_DATE '
                     || '       , ' || TO_CHAR(IN_DEFINE_ID)
                     || '       , NVL(T_R_T.RESULT_VALUE, 0) '
                     || '       , ' || '''' || '语义统计' || ''''
                     || '       , ''' || IS_USER_ID || ''' '
                     || '       , SYSDATE '
                     || '       , ''' || IS_USER_ID || ''' '
                     || '       , SYSDATE '
                     || '    FROM (SELECT T_PCT_PCRD.TAR_ACCOUNT_ID '
                     || S_FIELDS3
                     || '               , SUM(NVL(T_RC_RCD.' || S_SEM_EXP || ', 0)) RESULT_VALUE '
                     || '            FROM T_POL_POLICY_CUS_TYPE_TMP T_PCT_PCRD '
                     || '               , ( ';
      S_SEMANTIC_VAL_2 := S_SEMANTIC_VAL;
      S_SEMANTIC_VAL_3 := ' ) T_RC_RCD '
                     || '           WHERE T_PCT_PCRD.POLICY_ID = ' || TO_CHAR(N_POLICY_ID)
                     || '             AND T_PCT_PCRD.ACCOUNT_ID = T_RC_RCD.ACCOUNT_ID '
                     || '           GROUP BY T_PCT_PCRD.TAR_ACCOUNT_ID '
                     || S_FIELDS3
                     || '         ) T_R_T '
                     ;
      S_SEMANTIC_VAL_0 := S_SEMANTIC_VAL_1 || S_SEMANTIC_VAL_2 || S_SEMANTIC_VAL_3;
      --打开光标
      N_CUR := DBMS_SQL.OPEN_CURSOR;
      --解析动态SQL语句
      DBMS_SQL.PARSE(N_CUR, S_SEMANTIC_VAL_0, DBMS_SQL.NATIVE);
      --绑定输入参数
      IF INSTR(S_SEMANTIC_VAL_0, ':P_BEGIN_DATE', 1, 1) > 0 THEN
        DBMS_SQL.BIND_VARIABLE(N_CUR, ':P_BEGIN_DATE', D_SEM_BEGIN_DATE);
      END IF;
      IF INSTR(S_SEMANTIC_VAL_0, ':P_END_DATE', 1, 1) > 0 THEN
        DBMS_SQL.BIND_VARIABLE(N_CUR, ':P_END_DATE', D_SEM_END_DATE);
      END IF;
      IF INSTR(S_SEMANTIC_VAL_0, ':P_POLICY_ID', 1, 1) > 0 THEN
        DBMS_SQL.BIND_VARIABLE(N_CUR, ':P_POLICY_ID', N_POLICY_ID);
      END IF;
      IF INSTR(S_SEMANTIC_VAL_0, ':P_DEFINE_ID', 1, 1) > 0 THEN
        DBMS_SQL.BIND_VARIABLE(N_CUR, ':P_DEFINE_ID', IN_DEFINE_ID);
      END IF;
      IF INSTR(S_SEMANTIC_VAL_0, ':P_MTL_TYPE', 1, 1) > 0 THEN
        DBMS_SQL.BIND_VARIABLE(N_CUR, ':P_MTL_TYPE', S_MTL_TYPE);
      END IF;
      IF INSTR(S_SEMANTIC_VAL_0, ':P_RESULT_DATE', 1, 1) > 0 THEN
        DBMS_SQL.BIND_VARIABLE(N_CUR, ':P_RESULT_DATE', ID_RESULT_DATE);
      END IF;
      IF INSTR(S_SEMANTIC_VAL_0, ':P_ENTITY_ID', 1, 1) > 0 THEN
        DBMS_SQL.BIND_VARIABLE(N_CUR, ':P_ENTITY_ID', N_ENTITY_ID);
      END IF;
      IF INSTR(S_SEMANTIC_VAL_0, ':P_CONDITION_SQL', 1, 1) > 0 THEN
        DBMS_SQL.BIND_VARIABLE(N_CUR, ':P_CONDITION_SQL', S_CONDITION_SQL);
      END IF;
      --执行语句
      N_ROW := DBMS_SQL.EXECUTE(N_CUR);
      --关闭光标
      DBMS_SQL.CLOSE_CURSOR(N_CUR);
    END IF;

    /*统一在P_UPDATE_DETAIL中处理
    --语义补零
    IF (OS_MESSAGE = 'OK') THEN
      S_STEP := '语义补零';
      INSERT INTO T_POL_POLICY_RESULT_DETAIL
        (DETAIL_ID,
         POLICY_ID,
         RESULT_DATE,
         DEFINE_ID,
         RESULT_VALUE,
         VALUE_TYPE,
         CREATED_BY,
         CREATION_DATE,
         LAST_UPDATED_BY,
         LAST_UPDATE_DATE,
         ACCOUNT_ID)
      SELECT S_POL_POLICY_RESULT_DETAIL.NEXTVAL
           , N_POLICY_ID
           , ID_RESULT_DATE
           , IN_DEFINE_ID
           , 0
           , '语义补零'
           , IS_USER_ID
           , SYSDATE
           , IS_USER_ID
           , SYSDATE
           , S.TAR_ACCOUNT_ID
        FROM (SELECT DISTINCT T.TAR_ACCOUNT_ID
                FROM T_POL_POLICY_CUS_TYPE T
               WHERE T.POLICY_ID = N_POLICY_ID
                 AND NOT EXISTS(SELECT 1
                                  FROM T_POL_POLICY_RESULT_DETAIL RD
                                 WHERE RD.POLICY_ID = N_POLICY_ID
                                   AND RD.RESULT_DATE = ID_RESULT_DATE
                                   AND RD.DEFINE_ID = IN_DEFINE_ID
                                   AND RD.ACCOUNT_ID = T.TAR_ACCOUNT_ID)
             ) S;
    END IF;

    --更新报表明细结果的项目信息
    IF (OS_MESSAGE = 'OK') THEN
      S_STEP := '更新报表明细结果项目';
      UPDATE T_POL_POLICY_RESULT_DETAIL T
         SET (T.DEFINE_CODE
           ,  T.DEFINE_NAME
           ,  T.GET_VAL_TYPE
           ,  T.DETAIL_FLAG
           ,  T.MTL_TYPE)
           = (SELECT D.DEFINE_CODE
                   , D.DEFINE_NAME
                   , D.GET_VAL_TYPE
                   , D.DETAIL_FLAG
                   , D.MTL_TYPE
                FROM T_POL_POLICY_DEFINE D
               WHERE D.POLICY_ID = N_POLICY_ID
                 AND D.DEFINE_ID = IN_DEFINE_ID)
            ,LAST_UPDATED_BY = IS_USER_ID
            ,LAST_UPDATE_DATE = SYSDATE
       WHERE T.POLICY_ID = N_POLICY_ID
         AND T.DEFINE_ID = IN_DEFINE_ID
         AND T.RESULT_DATE = ID_RESULT_DATE;
    END IF;
    */

  EXCEPTION
    WHEN OTHERS THEN
      OS_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_POL_CAL.P_GET_SQL_VAL','100','来源SQL计算明细-' || S_STEP || '(项目ID=' || TO_CHAR(IN_DEFINE_ID) || ',项目代码=' || S_DEFINE_CODE || ')！SQL=' || S_SEMANTIC_VAL_0 || '！' || SQLERRM);
      OS_MESSAGE := '来源SQL计算明细-' || S_STEP || '(项目ID=' || TO_CHAR(IN_DEFINE_ID) || ',项目代码=' || S_DEFINE_CODE || ')！SQL=' || S_SEMANTIC_VAL_0 || '！' || SQLERRM;
  END;

  -----------------------------------------------------------------------------
  --  按公式取值的函数                                                       --
  -----------------------------------------------------------------------------
  PROCEDURE P_GET_FUN_VALUE(IN_DEFINE_ID              IN NUMBER   --政策算法定义ID
                           ,ID_RESULT_DATE            IN DATE     --报表日期
                           ,IS_USER_ID                IN VARCHAR2 --用户账号
                           ,OS_MESSAGE               OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
                           ) IS

    --客户列表(从合并关系中取)
    CURSOR C_CUSTOMER(IN_POLICY_ID NUMBER) IS
      SELECT DISTINCT RD.TAR_ACCOUNT_ID
           , RD.CUSTOMER_TYPE
        FROM T_POL_POLICY_CUS_TYPE_TMP RD
       WHERE RD.POLICY_ID = IN_POLICY_ID
       ORDER BY RD.TAR_ACCOUNT_ID;
    R_CUSTOMER C_CUSTOMER%ROWTYPE;
    --客户对应动态分类(从已计算的结果明细中取)
    CURSOR C_TYPE(IN_POLICY_ID NUMBER, IN_ACCOUNT_ID NUMBER) IS
      SELECT DISTINCT
             TYPE01
           , TYPE02
           , TYPE03
           , TYPE04
           , TYPE05
        FROM T_POL_POLICY_RESULT_DETAIL RD
       WHERE RD.POLICY_ID = IN_POLICY_ID
         AND RD.ACCOUNT_ID = IN_ACCOUNT_ID
         AND RD.RESULT_DATE = ID_RESULT_DATE
       ORDER BY RD.TYPE01
           , TYPE02
           , TYPE03
           , TYPE04
           , TYPE05;
    R_TYPE C_TYPE%ROWTYPE;
    --客户计算结果
    CURSOR C_RPT_VALUE(IN_POLICY_ID NUMBER, IN_ACCOUNT_ID NUMBER, IN_PRIOR_LEVEL NUMBER
      ,IS_TYPE01 VARCHAR2, IS_TYPE02 VARCHAR2, IS_TYPE03 VARCHAR2, IS_TYPE04 VARCHAR2, IS_TYPE05 VARCHAR2) IS
      SELECT DV.DEFINE_ID
           , DV.DEFINE_CODE
           , PRD.RESULT_VALUE
        FROM T_POL_POLICY_RESULT_DETAIL PRD
           , T_POL_POLICY_DEFINE DV
       WHERE PRD.POLICY_ID = IN_POLICY_ID
         AND PRD.ACCOUNT_ID = IN_ACCOUNT_ID
         AND PRD.RESULT_DATE = ID_RESULT_DATE
         AND PRD.DEFINE_ID = DV.DEFINE_ID
         AND DV.PRIOR_LEVEL < IN_PRIOR_LEVEL
         AND NVL(PRD.TYPE01,' ') = NVL(IS_TYPE01,' ')
         AND NVL(PRD.TYPE02,' ') = NVL(IS_TYPE02,' ')
         AND NVL(PRD.TYPE03,' ') = NVL(IS_TYPE03,' ')
         AND NVL(PRD.TYPE04,' ') = NVL(IS_TYPE04,' ')
         AND NVL(PRD.TYPE05,' ') = NVL(IS_TYPE05,' ')
       ORDER BY DV.DEFINE_ID;
    R_RPT_VALUE C_RPT_VALUE%ROWTYPE;

    N_POLICY_ID              NUMBER;
    S_DEFINE_CODE            VARCHAR2(100);
    S_DEFINE_NAME            VARCHAR2(100);
    S_GET_VAL_TYPE           VARCHAR2(40);
    S_CAL_EXP                VARCHAR2(4000);
    S_CAL_DB_EXP             VARCHAR2(4000);
    N_PRIOR_LEVEL            NUMBER;

    N_CUR                    NUMBER;
    N_ROW                    NUMBER;
    S_DB_EXPRESS             VARCHAR2(4000);
    S_SQL_EXPRESS            VARCHAR2(4000);
    S_VALUE                  VARCHAR2(100);
    N_RESULT                 NUMBER;
    S_MESSAGE                VARCHAR2(100);
    S_STEP                   VARCHAR2(40);
  BEGIN
    OS_MESSAGE := 'OK';

    --政策算法定义信息
    S_STEP := '读取政策算法定义信息';
    SELECT T.POLICY_ID
         , T.DEFINE_CODE
         , T.DEFINE_NAME
         , T.GET_VAL_TYPE
         , T.CAL_EXP
         , T.CAL_DB_EXP
         , T.PRIOR_LEVEL
      INTO N_POLICY_ID
         , S_DEFINE_CODE
         , S_DEFINE_NAME
         , S_GET_VAL_TYPE
         , S_CAL_EXP
         , S_CAL_DB_EXP
         , N_PRIOR_LEVEL
      FROM T_POL_POLICY_DEFINE T
     WHERE T.DEFINE_ID = IN_DEFINE_ID;

    /*统一在P_RESULT_INIT中处理
    --删除报表日期的结果明细
    S_STEP := '删除报表日期的结果明细';
    DELETE
      FROM T_POL_POLICY_RESULT_DETAIL T
     WHERE T.POLICY_ID = N_POLICY_ID
       AND T.DEFINE_ID = IN_DEFINE_ID
       AND T.RESULT_DATE = ID_RESULT_DATE;
    */

    --按客户循环计算项目计算结果值
    S_STEP := '按客户循环计算项目';
    FOR R_CUSTOMER IN C_CUSTOMER(N_POLICY_ID)
    LOOP
      IF (OS_MESSAGE = 'OK') THEN
        S_MESSAGE := 'OK';
        --处理计算公式
        S_DB_EXPRESS := ' SELECT ( ' || UPPER(S_CAL_DB_EXP) || ' ) FROM DUAL ';
        --替换客户分类
        IF (INSTR(S_DB_EXPRESS, '[客户分类]', 1, 1) > 0) AND (R_CUSTOMER.CUSTOMER_TYPE IS NOT NULL) THEN
          S_DB_EXPRESS := REPLACE(S_DB_EXPRESS, '[客户分类]', '''' || R_CUSTOMER.CUSTOMER_TYPE || '''');
        END IF;
        
        --循环客户对应的动态分类
        FOR R_TYPE IN C_TYPE(N_POLICY_ID,R_CUSTOMER.TAR_ACCOUNT_ID) 
        LOOP
          S_SQL_EXPRESS := S_DB_EXPRESS;
          --循环替换参数
          FOR R_RPT_VALUE IN C_RPT_VALUE(N_POLICY_ID, R_CUSTOMER.TAR_ACCOUNT_ID, N_PRIOR_LEVEL
            ,R_TYPE.TYPE01, R_TYPE.TYPE02, R_TYPE.TYPE03, R_TYPE.TYPE04, R_TYPE.TYPE05)
          LOOP
            IF (INSTR(S_SQL_EXPRESS, '[' || R_RPT_VALUE.DEFINE_CODE || ']', 1, 1) > 0)
               AND (R_RPT_VALUE.RESULT_VALUE IS NOT NULL) 
            THEN
              IF R_RPT_VALUE.RESULT_VALUE < 0 THEN
                --负数则外面加括号，避免两个“-”变为注释
                S_VALUE := '(' || TO_CHAR(R_RPT_VALUE.RESULT_VALUE) || ')';
              ELSE
                S_VALUE := TO_CHAR(R_RPT_VALUE.RESULT_VALUE);
              END IF;
              S_SQL_EXPRESS := REPLACE(S_SQL_EXPRESS, '[' || R_RPT_VALUE.DEFINE_CODE || ']', S_VALUE);
            END IF;
          END LOOP;
          IF (S_MESSAGE = 'OK') AND (INSTR(S_SQL_EXPRESS, '[', 1, 1) > 0) AND (INSTR(S_SQL_EXPRESS, ']', 1, 1) > 0) THEN
            S_MESSAGE := '公式表中存在未被解释项';
          END IF;
          IF (S_MESSAGE = 'OK') THEN
            --打开光标
            N_CUR := DBMS_SQL.OPEN_CURSOR;
            --解析动态SQL语句
            DBMS_SQL.PARSE(N_CUR, S_SQL_EXPRESS, DBMS_SQL.NATIVE);
            --定义输出列
            DBMS_SQL.DEFINE_COLUMN(N_CUR, 1, N_RESULT);
            BEGIN
              --执行语句
              N_ROW := DBMS_SQL.EXECUTE(N_CUR);
              --获取输出值
              IF DBMS_SQL.FETCH_ROWS(N_CUR) > 0 THEN
                DBMS_SQL.COLUMN_VALUE(N_CUR, 1, N_RESULT);
              END IF;
            EXCEPTION
              WHEN ZERO_DIVIDE THEN
                S_MESSAGE := '除0出错';
                N_RESULT := 0;
              WHEN OTHERS THEN
                S_MESSAGE := '获取公式值出错';
                N_RESULT := 0;
            END;
            --关闭光标
            DBMS_SQL.CLOSE_CURSOR(N_CUR);
          END IF;
          --插入计算值
          INSERT INTO T_POL_POLICY_RESULT_DETAIL
                ( DETAIL_ID
                , POLICY_ID
                , ACCOUNT_ID
                , RESULT_DATE
                , DEFINE_ID
                , DEFINE_CODE
                , DEFINE_NAME
                , GET_VAL_TYPE
                , CAL_EXP
                , RESULT_VALUE
                , VALUE_TYPE
                , DB_EXPRESS_ERR
                , CREATED_BY
                , CREATION_DATE
                , LAST_UPDATED_BY
                , LAST_UPDATE_DATE
                , TYPE01
                , TYPE02
                , TYPE03
                , TYPE04
                , TYPE05
                )       
          SELECT S_POL_POLICY_RESULT_DETAIL.NEXTVAL
                , N_POLICY_ID
                , R_CUSTOMER.TAR_ACCOUNT_ID
                , ID_RESULT_DATE
                , IN_DEFINE_ID
                , S_DEFINE_CODE
                , S_DEFINE_NAME
                , S_GET_VAL_TYPE
                , S_CAL_EXP
                , N_RESULT
                , '公式统计'
                , DECODE(S_MESSAGE, 'OK', NULL, NVL(S_MESSAGE, '') || ':' || S_DB_EXPRESS)
                , IS_USER_ID
                , SYSDATE
                , IS_USER_ID
                , SYSDATE
                , R_TYPE.TYPE01
                , R_TYPE.TYPE02
                , R_TYPE.TYPE03
                , R_TYPE.TYPE04
                , R_TYPE.TYPE05
           FROM DUAL;
        END LOOP;
      END IF;
    END LOOP;

  EXCEPTION
    WHEN OTHERS THEN
      OS_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_POL_CAL.P_GET_FUN_VALUE','100','按公式取值过程-' || S_STEP || '(项目ID=' || TO_CHAR(IN_DEFINE_ID) || ',项目代码=' || S_DEFINE_CODE || ')！公式=' || S_DB_EXPRESS || '！SQL=' || S_SQL_EXPRESS || '！' || SQLERRM);
      OS_MESSAGE := '按公式取值过程-' || S_STEP || '(项目ID=' || TO_CHAR(IN_DEFINE_ID) || ',项目代码=' || S_DEFINE_CODE || ')！公式=' || S_DB_EXPRESS  || '！SQL=' || S_SQL_EXPRESS || '！' || SQLERRM;
  END;

  -----------------------------------------------------------------------------
  --  按外部数据取值                                                         --
  -----------------------------------------------------------------------------
  PROCEDURE P_GET_OUT_DATA_VALUE(IN_DEFINE_ID              IN NUMBER   --政策算法定义ID
                                ,ID_RESULT_DATE            IN DATE     --报表日期
                                ,IS_USER_ID                IN VARCHAR2 --用户账号
                                ,OS_MESSAGE               OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
                                ) IS

    N_POLICY_ID              NUMBER;
    S_OUT_DATA_CODE          VARCHAR2(100);
    S_STEP                   VARCHAR2(40);
    S_DEFINE_CODE            VARCHAR2(100);
  BEGIN
    OS_MESSAGE := 'OK';

    --政策算法定义信息
    S_STEP := '政策算法定义信息';
    SELECT T.POLICY_ID
         , T.OUT_DATA_CODE
         , T.DEFINE_CODE
      INTO N_POLICY_ID
         , S_OUT_DATA_CODE
         , S_DEFINE_CODE
      FROM T_POL_POLICY_DEFINE T
     WHERE T.DEFINE_ID = IN_DEFINE_ID;

    /*统一在P_RESULT_INIT中处理
    --删除报表日期的结果明细
    S_STEP := '删除报表日期的结果明细';
    DELETE
      FROM T_POL_POLICY_RESULT_DETAIL T
     WHERE T.POLICY_ID = N_POLICY_ID
       AND T.DEFINE_ID = IN_DEFINE_ID
       AND T.RESULT_DATE = ID_RESULT_DATE;
    */

    --外部数据统计
    S_STEP := '外部数据统计';
    INSERT INTO T_POL_POLICY_RESULT_DETAIL
      (DETAIL_ID,
       POLICY_ID,
       RESULT_DATE,
       DEFINE_ID,
       RESULT_VALUE,
       VALUE_TYPE,
       CREATED_BY,
       CREATION_DATE,
       LAST_UPDATED_BY,
       LAST_UPDATE_DATE,
       ACCOUNT_ID,
       TYPE01,
       TYPE02,
       TYPE03,
       TYPE04,
       TYPE05)
    SELECT S_POL_POLICY_RESULT_DETAIL.NEXTVAL
         , N_POLICY_ID
         , ID_RESULT_DATE
         , IN_DEFINE_ID
         , T.OUT_DATA_VALUE
         , '外部数据统计'
         , IS_USER_ID
         , SYSDATE
         , IS_USER_ID
         , SYSDATE
         , T.TAR_ACCOUNT_ID
         , T.TYPE01
         , T.TYPE02
         , T.TYPE03
         , T.TYPE04
         , T.TYPE05
       FROM (SELECT CT.TAR_ACCOUNT_ID
                  , OD.TYPE01
                  , OD.TYPE02
                  , OD.TYPE03
                  , OD.TYPE04
                  , OD.TYPE05
                  , SUM(NVL(OD.DATA_VALUE, 0)) OUT_DATA_VALUE
               FROM T_POL_POLICY_OUT_DATA OD
                  , T_POL_POLICY_CUS_TYPE_TMP CT
              WHERE OD.OUT_DATA_TYPE = S_OUT_DATA_CODE
                AND CT.POLICY_ID = N_POLICY_ID
                AND OD.ACCOUNT_ID = CT.ACCOUNT_ID
              GROUP BY CT.TAR_ACCOUNT_ID
                  , OD.TYPE01
                  , OD.TYPE02
                  , OD.TYPE03
                  , OD.TYPE04
                  , OD.TYPE05
            ) T;

    /*统一在P_UPDATE_DETAIL中处理
    --外部数据补零
    S_STEP := '外部数据补零';
    INSERT INTO T_POL_POLICY_RESULT_DETAIL
      (DETAIL_ID,
       POLICY_ID,
       RESULT_DATE,
       DEFINE_ID,
       RESULT_VALUE,
       VALUE_TYPE,
       CREATED_BY,
       CREATION_DATE,
       LAST_UPDATED_BY,
       LAST_UPDATE_DATE,
       ACCOUNT_ID)
    SELECT S_POL_POLICY_RESULT_DETAIL.NEXTVAL
         , N_POLICY_ID
         , ID_RESULT_DATE
         , IN_DEFINE_ID
         , 0
         , '外部数据补零'
         , IS_USER_ID
         , SYSDATE
         , IS_USER_ID
         , SYSDATE
         , S.TAR_ACCOUNT_ID
      FROM (SELECT DISTINCT T.TAR_ACCOUNT_ID
              FROM T_POL_POLICY_CUS_TYPE T
             WHERE T.POLICY_ID = N_POLICY_ID
               AND NOT EXISTS(SELECT 1
                                FROM T_POL_POLICY_RESULT_DETAIL RD
                               WHERE RD.POLICY_ID = N_POLICY_ID
                                 AND RD.RESULT_DATE = ID_RESULT_DATE
                                 AND RD.DEFINE_ID = IN_DEFINE_ID
                                 AND RD.ACCOUNT_ID = T.TAR_ACCOUNT_ID)
           ) S;

    --更新报表明细结果的项目信息
    S_STEP := '更新报表明细结果的项目';
    UPDATE T_POL_POLICY_RESULT_DETAIL T
       SET (T.DEFINE_CODE
         ,  T.DEFINE_NAME
         ,  T.GET_VAL_TYPE)
         = (SELECT D.DEFINE_CODE
                 , D.DEFINE_NAME
                 , D.GET_VAL_TYPE
              FROM T_POL_POLICY_DEFINE D
             WHERE D.POLICY_ID = N_POLICY_ID
               AND D.DEFINE_ID = IN_DEFINE_ID)
          ,LAST_UPDATED_BY = IS_USER_ID
          ,LAST_UPDATE_DATE = SYSDATE
     WHERE T.POLICY_ID = N_POLICY_ID
       AND T.DEFINE_ID = IN_DEFINE_ID
       AND T.RESULT_DATE = ID_RESULT_DATE;
    */

  EXCEPTION
    WHEN OTHERS THEN
      OS_MESSAGE := '按外部数据取值-' || S_STEP || '(项目ID=' || TO_CHAR(IN_DEFINE_ID) || ',项目代码=' || S_DEFINE_CODE || ')！' || SQLERRM;
  END;

  -----------------------------------------------------------------------------
  --  按调整项取值                                                           --
  -----------------------------------------------------------------------------
  PROCEDURE P_GET_ADJUST_VALUE(IN_DEFINE_ID              IN NUMBER   --政策算法定义ID
                              ,ID_RESULT_DATE            IN DATE     --报表日期
                              ,IS_USER_ID                IN VARCHAR2 --用户账号
                              ,OS_MESSAGE               OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
                              ) IS

    N_POLICY_ID              NUMBER;
    S_DEFINE_CODE            VARCHAR2(100);
  BEGIN
    OS_MESSAGE := 'OK';

    --政策算法定义信息
    IF (OS_MESSAGE = 'OK') THEN
      BEGIN
        SELECT T.POLICY_ID
             , T.DEFINE_CODE
          INTO N_POLICY_ID
             , S_DEFINE_CODE
          FROM T_POL_POLICY_DEFINE T
         WHERE T.DEFINE_ID = IN_DEFINE_ID;
      EXCEPTION
        WHEN OTHERS THEN
          OS_MESSAGE := '读取政策算法定义信息出错！(项目ID=' || TO_CHAR(IN_DEFINE_ID) || ',项目代码=' || S_DEFINE_CODE || ')';
      END;
    END IF;

    /*统一在P_RESULT_INIT中处理
    --删除报表日期的结果明细
    IF (OS_MESSAGE = 'OK') THEN
      DELETE
        FROM T_POL_POLICY_RESULT_DETAIL T
       WHERE T.POLICY_ID = N_POLICY_ID
         AND T.DEFINE_ID = IN_DEFINE_ID
         AND T.RESULT_DATE = ID_RESULT_DATE;
    END IF;
    */

    --外部数据统计
    IF (OS_MESSAGE = 'OK') THEN
      INSERT INTO T_POL_POLICY_RESULT_DETAIL
        (DETAIL_ID,
         POLICY_ID,
         RESULT_DATE,
         DEFINE_ID,
         RESULT_VALUE,
         VALUE_TYPE,
         CREATED_BY,
         CREATION_DATE,
         LAST_UPDATED_BY,
         LAST_UPDATE_DATE,
         ACCOUNT_ID,
         TYPE01,
         TYPE02,
         TYPE03,
         TYPE04,
         TYPE05)
      SELECT S_POL_POLICY_RESULT_DETAIL.NEXTVAL
           , N_POLICY_ID
           , ID_RESULT_DATE
           , IN_DEFINE_ID
           , T.ADJUST_VALUE
           , '调整项统计'
           , IS_USER_ID
           , SYSDATE
           , IS_USER_ID
           , SYSDATE
           , T.TAR_ACCOUNT_ID
           , T.TYPE01
           , T.TYPE02
           , T.TYPE03
           , T.TYPE04
           , T.TYPE05
         FROM (SELECT CT.TAR_ACCOUNT_ID
                    , PA.TYPE01
                    , PA.TYPE02
                    , PA.TYPE03
                    , PA.TYPE04
                    , PA.TYPE05
                    , SUM(NVL(PA.DATA_VALUE, 0)) ADJUST_VALUE
                 FROM T_POL_POLICY_ADJUST PA
                    , T_POL_POLICY_CUS_TYPE_TMP CT
                WHERE PA.POLICY_ID = N_POLICY_ID
                  AND PA.DEFINE_ID = IN_DEFINE_ID
                  AND CT.POLICY_ID = N_POLICY_ID
                  AND PA.ACCOUNT_ID = CT.ACCOUNT_ID
                GROUP BY CT.TAR_ACCOUNT_ID
                    , PA.TYPE01
                    , PA.TYPE02
                    , PA.TYPE03
                    , PA.TYPE04
                    , PA.TYPE05
              ) T;
    END IF;

    /*统一在P_UPDATE_DETAIL中处理
    --调整项补零
    IF (OS_MESSAGE = 'OK') THEN
      INSERT INTO T_POL_POLICY_RESULT_DETAIL
        (DETAIL_ID,
         POLICY_ID,
         RESULT_DATE,
         DEFINE_ID,
         RESULT_VALUE,
         VALUE_TYPE,
         CREATED_BY,
         CREATION_DATE,
         LAST_UPDATED_BY,
         LAST_UPDATE_DATE,
         ACCOUNT_ID)
      SELECT S_POL_POLICY_RESULT_DETAIL.NEXTVAL
           , N_POLICY_ID
           , ID_RESULT_DATE
           , IN_DEFINE_ID
           , 0
           , '调整项补零'
           , IS_USER_ID
           , SYSDATE
           , IS_USER_ID
           , SYSDATE
           , S.TAR_ACCOUNT_ID
        FROM (SELECT DISTINCT T.TAR_ACCOUNT_ID
                FROM T_POL_POLICY_CUS_TYPE T
               WHERE T.POLICY_ID = N_POLICY_ID
                 AND NOT EXISTS(SELECT 1
                                  FROM T_POL_POLICY_RESULT_DETAIL RD
                                 WHERE RD.POLICY_ID = N_POLICY_ID
                                   AND RD.RESULT_DATE = ID_RESULT_DATE
                                   AND RD.DEFINE_ID = IN_DEFINE_ID
                                   AND RD.ACCOUNT_ID = T.TAR_ACCOUNT_ID)
             ) S;
    END IF;

    --更新报表明细结果的项目信息
    IF (OS_MESSAGE = 'OK') THEN
      UPDATE T_POL_POLICY_RESULT_DETAIL T
         SET (T.DEFINE_CODE
           ,  T.DEFINE_NAME
           ,  T.GET_VAL_TYPE)
           = (SELECT D.DEFINE_CODE
                   , D.DEFINE_NAME
                   , D.GET_VAL_TYPE
                FROM T_POL_POLICY_DEFINE D
               WHERE D.POLICY_ID = N_POLICY_ID
                 AND D.DEFINE_ID = IN_DEFINE_ID)
            ,LAST_UPDATED_BY = IS_USER_ID
            ,LAST_UPDATE_DATE = SYSDATE
       WHERE T.POLICY_ID = N_POLICY_ID
         AND T.DEFINE_ID = IN_DEFINE_ID
         AND T.RESULT_DATE = ID_RESULT_DATE;
    END IF;
    */

  EXCEPTION
    WHEN OTHERS THEN
      OS_MESSAGE := '调用按调整项取值过程出错(项目ID=' || TO_CHAR(IN_DEFINE_ID) || ',项目代码=' || S_DEFINE_CODE || ')！' || SQLERRM;
  END;

  -----------------------------------------------------------------------------
  --  政策计算结果初始化
  --将已存在的政策计算结果明细删除  
  --将对应的冻结数据删除                                                       
  -----------------------------------------------------------------------------
  PROCEDURE P_RESULT_INIT
  (
    IN_POLICY_ID          IN NUMBER    --政策ID
    ,ID_RESULT_DATE       IN DATE      --报表日期
    ,IS_USER_ID           IN VARCHAR2  --用户账号
    ,OS_MESSAGE          OUT VARCHAR2  --成功则返回“OK”，否则返回出错信息
  ) IS

    S_STEP                VARCHAR2(40);
    N_CNT                 NUMBER;
    N_PARENT_POLICY_ID    NUMBER;
  BEGIN
    OS_MESSAGE := 'OK';

    S_STEP := '删除计算结果明细';
    --删除计算结果明细
    DELETE FROM
      T_POL_POLICY_RESULT_DETAIL
     WHERE
       POLICY_ID = IN_POLICY_ID
       AND RESULT_DATE = ID_RESULT_DATE;
    
    S_STEP := '删除冻结数据';
    --删除冻结数据
    DELETE FROM
      T_POL_POLICY_FREEZE
    WHERE
      POLICY_ID = IN_POLICY_ID;
      
    --初始政策对应的客户分类信息
    S_STEP := '初始客户分类1';
    INSERT INTO T_POL_POLICY_CUS_TYPE_TMP
    (
      POLICY_ID
      ,ACCOUNT_ID
      ,TAR_ACCOUNT_ID
      ,CUSTOMER_TYPE
    )
    SELECT
      POLICY_ID
      ,ACCOUNT_ID
      ,TAR_ACCOUNT_ID
      ,CUSTOMER_TYPE
    FROM
      T_POL_POLICY_CUS_TYPE
    WHERE
      POLICY_ID = IN_POLICY_ID;
    
    --检查是否有数据
    SELECT
      COUNT(*)
    INTO
      N_CNT
    FROM
      T_POL_POLICY_CUS_TYPE_TMP;
      
    --没有客户分类，则从主政策中取客户分类
    IF N_CNT = 0 THEN
      SELECT
        PARENT_POLICY_ID
      INTO
        N_PARENT_POLICY_ID
      FROM
        T_POL_POLICY
      WHERE
        POLICY_ID = IN_POLICY_ID;
       
      S_STEP := '初始客户分类2';
      INSERT INTO T_POL_POLICY_CUS_TYPE_TMP
      (
        POLICY_ID
        ,ACCOUNT_ID
        ,TAR_ACCOUNT_ID
        ,CUSTOMER_TYPE
      )
      SELECT
        IN_POLICY_ID POLICY_ID
        ,ACCOUNT_ID
        ,TAR_ACCOUNT_ID
        ,CUSTOMER_TYPE
      FROM
        T_POL_POLICY_CUS_TYPE
      WHERE
        POLICY_ID = N_PARENT_POLICY_ID;
    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      OS_MESSAGE := S_STEP || '出错！(POLICY_ID=' || TO_CHAR(IN_POLICY_ID) || ')' || SQLERRM;
  END P_RESULT_INIT;

  -----------------------------------------------------------------------------
  --  政策计算结果明细信息更新
  --取出计算方法定义的相关信息进行更新
  --补充缺少的数据  
  -----------------------------------------------------------------------------
  PROCEDURE P_UPDATE_DETAIL
  (
    IN_POLICY_ID          IN NUMBER     --政策ID
    ,ID_RESULT_DATE       IN DATE     --报表日期
    ,IS_USER_ID           IN VARCHAR2 --用户账号
    ,OS_MESSAGE           OUT VARCHAR2   --成功则返回“OK”，否则返回出错信息
  ) IS
    S_STEP                  VARCHAR2(40);
  BEGIN
    OS_MESSAGE := 'OK';

    S_STEP := '更新计算义定信息';
    --更新计算义定信息
    UPDATE T_POL_POLICY_RESULT_DETAIL T
       SET (T.DEFINE_CODE
         ,  T.DEFINE_NAME
         ,  T.GET_VAL_TYPE
         ,  T.DETAIL_FLAG
         ,  T.MTL_TYPE)
         = (SELECT D.DEFINE_CODE
                 , D.DEFINE_NAME
                 , D.GET_VAL_TYPE
                 , D.DETAIL_FLAG
                 , D.MTL_TYPE
              FROM T_POL_POLICY_DEFINE D
             WHERE D.POLICY_ID = IN_POLICY_ID
               AND D.DEFINE_ID = T.DEFINE_ID)
          ,LAST_UPDATED_BY = IS_USER_ID
          ,LAST_UPDATE_DATE = SYSDATE
     WHERE T.POLICY_ID = IN_POLICY_ID
       AND T.RESULT_DATE = ID_RESULT_DATE;
    
    S_STEP := '补充数据为0内容';
    --补充数据为0内容
    --接客户、分类，与政策计算方法定义的内容按笛卡尔积与现有存在的数据比较，不存在则插入
    INSERT INTO T_POL_POLICY_RESULT_DETAIL
    (
      DETAIL_ID,
      POLICY_ID,
      RESULT_DATE,
      DEFINE_ID,
      DEFINE_CODE,
      DEFINE_NAME,
      GET_VAL_TYPE,
      DETAIL_FLAG,
      MTL_TYPE,
      VALUE_TYPE,
      RESULT_VALUE,
      CREATED_BY,
      CREATION_DATE,
      LAST_UPDATED_BY,
      LAST_UPDATE_DATE,
      ACCOUNT_ID,
      TYPE01,
      TYPE02,
      TYPE03,
      TYPE04,
      TYPE05
    )
    SELECT
      S_POL_POLICY_RESULT_DETAIL.NEXTVAL DETAIL_ID,
      IN_POLICY_ID POLICY_ID,
      ID_RESULT_DATE RESULT_DATE,
      D.DEFINE_ID,
      D.DEFINE_CODE,
      D.DEFINE_NAME,
      D.GET_VAL_TYPE,
      D.DETAIL_FLAG,
      D.MTL_TYPE,
      DECODE(D.GET_VAL_TYPE,'1','语义补零','3','外部数据补零','4','调整项补零') VALUE_TYPE,
      0 RESULT_VALUE,
      IS_USER_ID CREATED_BY,
      SYSDATE CREATION_DATE,
      IS_USER_ID LAST_UPDATED_BY,
      SYSDATE LAST_UPDATE_DATE,
      D.ACCOUNT_ID,
      D.TYPE01,
      D.TYPE02,
      D.TYPE03,
      D.TYPE04,
      D.TYPE05
    FROM
      (
        SELECT
          RD.ACCOUNT_ID
          ,RD.TYPE01
          ,RD.TYPE02
          ,RD.TYPE03
          ,RD.TYPE04
          ,RD.TYPE05
          ,PD.DEFINE_ID
          ,PD.DEFINE_CODE
          ,PD.DEFINE_NAME
          ,PD.GET_VAL_TYPE
          ,PD.DETAIL_FLAG
          ,PD.MTL_TYPE
        FROM
          (
            SELECT DISTINCT
              ACCOUNT_ID
              ,TYPE01
              ,TYPE02
              ,TYPE03
              ,TYPE04
              ,TYPE05
            FROM
              T_POL_POLICY_RESULT_DETAIL
            WHERE
              POLICY_ID = IN_POLICY_ID
              AND RESULT_DATE = ID_RESULT_DATE
          ) RD
          ,T_POL_POLICY_DEFINE PD
        WHERE
          PD.POLICY_ID = IN_POLICY_ID
           AND PD.GET_VAL_TYPE <> '2'
      ) D
      ,T_POL_POLICY_RESULT_DETAIL PRD
    WHERE
      D.ACCOUNT_ID = PRD.ACCOUNT_ID(+)
      AND D.DEFINE_ID = PRD.DEFINE_ID(+)
      AND NVL(D.TYPE01,' ') = NVL(PRD.TYPE01(+),' ')
      AND NVL(D.TYPE02,' ') = NVL(PRD.TYPE02(+),' ')
      AND NVL(D.TYPE03,' ') = NVL(PRD.TYPE03(+),' ')
      AND NVL(D.TYPE04,' ') = NVL(PRD.TYPE04(+),' ')
      AND NVL(D.TYPE05,' ') = NVL(PRD.TYPE05(+),' ')
      AND PRD.RESULT_DATE(+) = ID_RESULT_DATE
      AND PRD.ACCOUNT_ID IS NULL;

  EXCEPTION
    WHEN OTHERS THEN
      OS_MESSAGE := S_STEP || '出错！(POLICY_ID=' || TO_CHAR(IN_POLICY_ID) || ')' || SQLERRM;
  END P_UPDATE_DETAIL;

  -----------------------------------------------------------------------------
  --  政策结果明细计算过程                                                   --
  -----------------------------------------------------------------------------
  PROCEDURE P_POLICY_CAL_DETAIL(IN_POLICY_ID              IN NUMBER   --政策ID
                               ,ID_RESULT_DATE            IN DATE     --报表日期
                               ,IS_USER_ID                IN VARCHAR2 --用户账号
                               ,IS_PRE_CALC               IN VARCHAR2 --试算标识（Y/N）
                               ,OS_MESSAGE               OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
                               ) IS
    --政策计算项目(非公式)
    CURSOR C_DEFINE_LIST1 IS
      SELECT PD.DEFINE_ID
           , PD.DEFINE_CODE
           , PD.DEFINE_NAME
           , PD.GET_VAL_TYPE
           , PD.PRIOR_LEVEL
        FROM T_POL_POLICY_DEFINE PD
       WHERE PD.POLICY_ID = IN_POLICY_ID
         AND PD.GET_VAL_TYPE <> '2'
       ORDER BY PD.PRIOR_LEVEL, PD.DEFINE_CODE;
    R_DEFINE_LIST1 C_DEFINE_LIST1%ROWTYPE;

    --政策计算项目(公式)
    CURSOR C_DEFINE_LIST2 IS
      SELECT PD.DEFINE_ID
           , PD.DEFINE_CODE
           , PD.DEFINE_NAME
           , PD.GET_VAL_TYPE
           , PD.PRIOR_LEVEL
        FROM T_POL_POLICY_DEFINE PD
       WHERE PD.POLICY_ID = IN_POLICY_ID
         AND PD.GET_VAL_TYPE = '2'
       ORDER BY PD.PRIOR_LEVEL, PD.DEFINE_CODE;
    R_DEFINE_LIST2 C_DEFINE_LIST2%ROWTYPE;

    S_POLICY_STATUS          VARCHAR2(40);   --政策状态
    N_ENTITY_ID              NUMBER;         --主体ID
    S_STEP                   VARCHAR2(240);
  BEGIN
    OS_MESSAGE := 'OK';

    --获取政策信息
    S_STEP := '获取政策信息';
    IF (OS_MESSAGE = 'OK') THEN
      BEGIN
        SELECT PP.STATUS, PP.ENTITY_ID
          INTO S_POLICY_STATUS, N_ENTITY_ID
          FROM T_POL_POLICY PP, T_POL_POLICY CP
         WHERE PP.POLICY_ID = CP.BI_POLICY_ID
           AND CP.POLICY_ID = IN_POLICY_ID;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          OS_MESSAGE := '获取政策表信息失败(POLICY_ID=' || TO_CHAR(IN_POLICY_ID) || ')！';
      END;
    END IF;

    --检查政策表状态，需为：'已审核', '已返利', '部分返利'，'已录入'
    IF (OS_MESSAGE = 'OK') AND (S_POLICY_STATUS NOT IN ('6', '4', '1', '5')) THEN 
      OS_MESSAGE := '政策申请状态为已录入、已审核、已部分返利、已返利才允许计算返利，其他状态不允许计算返利！';
    END IF;

    SAVEPOINT SP_POLICY_CAL_DETAIL;

    /*统一在P_RESULT_INIT中处理
    --删除报表日期的结果明细
    IF (OS_MESSAGE = 'OK') THEN
      DELETE
        FROM T_POL_POLICY_RESULT_DETAIL T
       WHERE T.POLICY_ID = IN_POLICY_ID
         AND T.RESULT_DATE = ID_RESULT_DATE;
    END IF;
    */

    --循环计算表的结果值（非公式）
    IF (OS_MESSAGE = 'OK') THEN
      FOR R_DEFINE_LIST1 IN C_DEFINE_LIST1
      LOOP
        IF (R_DEFINE_LIST1.GET_VAL_TYPE = '1') THEN  --语义
          --执行语义     
          S_STEP := '执行语义:' || NVL(R_DEFINE_LIST1.DEFINE_CODE, '空');
          P_GET_SQL_VALUE(R_DEFINE_LIST1.DEFINE_ID
                         ,ID_RESULT_DATE
                         ,IS_USER_ID
                         ,IS_PRE_CALC
                         ,OS_MESSAGE);
        ELSIF (R_DEFINE_LIST1.GET_VAL_TYPE = '3') THEN  --外部数据
          --执行外部数据
          S_STEP := '执行外部数据:' || NVL(R_DEFINE_LIST1.DEFINE_CODE, '空');
          P_GET_OUT_DATA_VALUE(R_DEFINE_LIST1.DEFINE_ID
                              ,ID_RESULT_DATE
                              ,IS_USER_ID
                              ,OS_MESSAGE);
        ELSIF (R_DEFINE_LIST1.GET_VAL_TYPE = '4') THEN  --调整项
          --执行调整项
          S_STEP := '执行调整项:' || NVL(R_DEFINE_LIST1.DEFINE_CODE, '空');
          P_GET_ADJUST_VALUE(R_DEFINE_LIST1.DEFINE_ID
                            ,ID_RESULT_DATE
                            ,IS_USER_ID
                            ,OS_MESSAGE);
        END IF;
        IF (OS_MESSAGE <> 'OK') THEN
          EXIT;
        END IF;
      END LOOP;
    END IF;

    --根据写入结果明细表中的动态分类，补充其它不存在的行
    IF (OS_MESSAGE = 'OK') THEN
      P_UPDATE_DETAIL(IN_POLICY_ID
                     ,ID_RESULT_DATE
                     ,IS_USER_ID
                     ,OS_MESSAGE);
    END IF;

    --循环计算表的结果值（公式）
    IF (OS_MESSAGE = 'OK') THEN
      FOR R_DEFINE_LIST2 IN C_DEFINE_LIST2
      LOOP
        --执行计算公式
        S_STEP := '执行计算公式:' || NVL(R_DEFINE_LIST2.DEFINE_CODE, '空');
        P_GET_FUN_VALUE(R_DEFINE_LIST2.DEFINE_ID
                       ,ID_RESULT_DATE
                       ,IS_USER_ID
                       ,OS_MESSAGE);
        IF (OS_MESSAGE <> 'OK') THEN
          EXIT;
        END IF;
      END LOOP;
    END IF;

    IF (OS_MESSAGE <> 'OK') THEN
      ROLLBACK TO SAVEPOINT SP_POLICY_CAL_DETAIL;
    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK TO SAVEPOINT SP_POLICY_CAL_DETAIL;
      OS_MESSAGE := '调用政策结果明细计算过程出错！(POLICY_ID=' || TO_CHAR(IN_POLICY_ID) || ',' || S_STEP || ')' || SQLERRM;
  END;

  -----------------------------------------------------------------------------
  --  将分解后产品明细的四舍五入差异放到最大的金额中                                                    --
  -----------------------------------------------------------------------------
  PROCEDURE P_SET_ITEM_DETAIL_DEF
  (
    IN_POLICY_ID              IN NUMBER   --政策ID
    ,IN_DEFINE_ID             IN NUMBER   --政策算法定义ID
    ,IS_DEFINE_CODE           IN VARCHAR2 --政策算法定义编码
    ,ID_RESULT_DATE           IN DATE     --报表日期
    ,OS_MESSAGE               OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  ) IS
  BEGIN
    OS_MESSAGE := 'OK';

    --将四舍五入的差异金额更新到最大金额中
    --循环取出有差异的数据
    FOR R_RESULT_DEF IN
    (
      SELECT
        D.ACCOUNT_ID
        ,D.RESULT_VALUE - T.SUM_VALUE DEF_VALUE
        ,T.MAX_VALUE
      FROM
        T_POL_POLICY_RESULT_DETAIL D
        ,(
          SELECT
            ACCOUNT_ID
            ,SUM(VALUE) SUM_VALUE
            ,MAX(VALUE) MAX_VALUE
          FROM
            T_POL_RESULT_ITEM_DETAIL_TMP
          WHERE
            DEFINE_CODE = IS_DEFINE_CODE
          GROUP BY
            ACCOUNT_ID
        ) T
      WHERE
        D.ACCOUNT_ID = T.ACCOUNT_ID
        AND D.POLICY_ID = IN_POLICY_ID
        AND D.RESULT_DATE = ID_RESULT_DATE
        AND D.DEFINE_ID = IN_DEFINE_ID
        AND D.RESULT_VALUE <> T.SUM_VALUE
    )
    LOOP
      --更新取大值的产品明细中
      UPDATE
        T_POL_RESULT_ITEM_DETAIL_TMP
      SET
        VALUE = VALUE+R_RESULT_DEF.DEF_VALUE
      WHERE
        ACCOUNT_ID = R_RESULT_DEF.ACCOUNT_ID
        AND DEFINE_CODE = IS_DEFINE_CODE
        AND VALUE = R_RESULT_DEF.MAX_VALUE
        AND ROWNUM = 1;
    END LOOP;

  EXCEPTION
    WHEN OTHERS THEN
      OS_MESSAGE := '处理四舍五入差异' || '(项目ID=' || TO_CHAR(IN_DEFINE_ID) || ',项目代码=' || IS_DEFINE_CODE || ')！' || SQLERRM;
  END P_SET_ITEM_DETAIL_DEF;

  -----------------------------------------------------------------------------
  --  对包含产品的语义写计算结果产品明细                                     --
  -----------------------------------------------------------------------------
  PROCEDURE P_SET_ITEM_DETAIL_SEM_SQL
  (
    IN_DEFINE_ID              IN NUMBER   --政策算法定义ID
    ,IN_ENTITY_ID             IN NUMBER   --主体ID
    ,ID_RESULT_DATE           IN DATE     --报表日期
    ,IS_USER_ID               IN VARCHAR2 --用户账号
    ,OS_MESSAGE               OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  ) IS
    N_POLICY_ID              NUMBER;
    S_DEFINE_CODE            VARCHAR2(100);
    S_GET_VAL_TYPE           VARCHAR2(40);
    S_SEM_CODE               VARCHAR2(100);
    S_SEM_EXP                VARCHAR2(240);
    D_SEM_BEGIN_DATE         DATE;
    D_SEM_END_DATE           DATE;
    S_DETAIL_FLAG            VARCHAR2(1);
    S_MTL_TYPE               VARCHAR2(40);
    S_CONDITION              VARCHAR2(4000);
    S_CONDITION_SQL          VARCHAR2(4000);

    N_CUR                    NUMBER;
    N_ROW                    NUMBER;
    S_SEMANTIC_VAL_0         VARCHAR2(4000);
    S_SEMANTIC_VAL_1         VARCHAR2(4000);
    S_SEMANTIC_VAL_2         VARCHAR2(4000);
    S_SEMANTIC_VAL_3         VARCHAR2(4000);

    S_SEMANTIC_TYPE          VARCHAR2(40); --语义类型：SQL取值、计算公式
    S_SEMANTIC_VAL           VARCHAR2(4000); --语义值
    S_PRE_PROC_SQL           VARCHAR2(4000); --预执行语句
    S_QUERY_CODE             VARCHAR2(40); --查询条件编码
    S_FREEZE_QUERY_CODE      VARCHAR2(40); --冻结明细查询条件编码
    S_STEP                   VARCHAR2(40);
  BEGIN
    OS_MESSAGE := 'OK';

    --政策算法定义信息
    S_STEP := '读取政策算法定义信息';
    SELECT T.POLICY_ID
         , T.DEFINE_CODE
         , T.GET_VAL_TYPE
         , T.SEM_CODE
         , T.SEM_EXP
         , T.SEM_BEGIN_DATE
         , T.SEM_END_DATE
         , T.DETAIL_FLAG
         , T.MTL_TYPE
         , T.CONDITION
         , T.CONDITION_SQL
      INTO N_POLICY_ID
         , S_DEFINE_CODE
         , S_GET_VAL_TYPE
         , S_SEM_CODE
         , S_SEM_EXP
         , D_SEM_BEGIN_DATE
         , D_SEM_END_DATE
         , S_DETAIL_FLAG
         , S_MTL_TYPE
         , S_CONDITION
         , S_CONDITION_SQL
      FROM T_POL_POLICY_DEFINE T
     WHERE T.DEFINE_ID = IN_DEFINE_ID;

    --获取语义信息
    S_STEP := '获取语义信息';
    P_GET_ENTITY_SEMANTIC(S_SEM_CODE
                         ,IN_ENTITY_ID
                         ,S_SEMANTIC_TYPE
                         ,S_SEMANTIC_VAL
                         ,S_PRE_PROC_SQL
                         ,S_QUERY_CODE
                         ,S_FREEZE_QUERY_CODE
                         ,OS_MESSAGE);

    IF (OS_MESSAGE = 'OK') AND (S_SEMANTIC_TYPE = '计算公式') THEN
      OS_MESSAGE := '政策算法定义项目的语义暂时不支持计算公式！(项目ID=' || TO_CHAR(IN_DEFINE_ID) || ')';
    END IF;

    --由于之前在计算结果时已执行过预处理，故不需再执行预处理，直接使用取值SQL生成产品明细信息
    --若不存在插入冻结明细，则在执行语句时处理限制条件
    IF (OS_MESSAGE = 'OK') AND (S_CONDITION_SQL IS NOT NULL)
      AND ((S_FREEZE_QUERY_CODE IS NULL))
      AND (INSTR(S_SEMANTIC_VAL, ':P_CONDITION_SQL', 1, 1) = 0) THEN
      S_SEMANTIC_VAL := S_SEMANTIC_VAL || ' AND (' || S_CONDITION_SQL || ')';
    END IF;

    --若存在商品分类参数，而商品分类参数值非空，则将“:P_MTL_TYPE IS NULL” 改为“1=1”
    IF (OS_MESSAGE = 'OK' AND INSTR(S_SEMANTIC_VAL, ':P_MTL_TYPE IS NULL', 1, 1) > 0) THEN
      IF S_MTL_TYPE IS NULL THEN
        S_SEMANTIC_VAL := REPLACE(S_SEMANTIC_VAL,':P_MTL_TYPE IS NULL','1=1');
      ELSE
        S_SEMANTIC_VAL := REPLACE(S_SEMANTIC_VAL,':P_MTL_TYPE IS NULL OR','');
      END IF;
    END IF;

    --语义语句
    IF (OS_MESSAGE = 'OK') AND (S_SEMANTIC_VAL IS NOT NULL) THEN
      S_STEP := '执行语义语句';
      --处理执行语句，将分类字段放到SQL中
      S_SEMANTIC_VAL_1 := 'INSERT INTO T_POL_RESULT_ITEM_DETAIL_TMP(ACCOUNT_ID, ITEM_ID, DEFINE_CODE, VALUE)'
                     || '  SELECT T_R_T.TAR_ACCOUNT_ID'
                     || '       , T_R_T.ITEM_ID,''' || S_DEFINE_CODE || ''''
                     || '       , ROUND(NVL(T_R_T.RESULT_VALUE, 0),2)'
                     || '    FROM (SELECT T_PCT_PCRD.TAR_ACCOUNT_ID'
                     || '               , ITEM_ID'
                     || '               , ROUND(SUM(NVL(T_RC_RCD.' || S_SEM_EXP || ', 0)),2) RESULT_VALUE'
                     || '            FROM T_POL_POLICY_CUS_TYPE_TMP T_PCT_PCRD'
                     || '               , (';
      S_SEMANTIC_VAL_2 := S_SEMANTIC_VAL;
      S_SEMANTIC_VAL_3 := ' ) T_RC_RCD'
                     || '           WHERE T_PCT_PCRD.POLICY_ID = ' || TO_CHAR(N_POLICY_ID)
                     || '             AND T_PCT_PCRD.ACCOUNT_ID = T_RC_RCD.ACCOUNT_ID'
                     || '           GROUP BY T_PCT_PCRD.TAR_ACCOUNT_ID, T_RC_RCD.ITEM_ID'
                     || '           HAVING ROUND(SUM(NVL(T_RC_RCD.' || S_SEM_EXP || ', 0)),2) <> 0'
                     || '         ) T_R_T'
                     ;
      S_SEMANTIC_VAL_0 := S_SEMANTIC_VAL_1 || S_SEMANTIC_VAL_2 || S_SEMANTIC_VAL_3;
      --打开光标
      N_CUR := DBMS_SQL.OPEN_CURSOR;
      --解析动态SQL语句
      DBMS_SQL.PARSE(N_CUR, S_SEMANTIC_VAL_0, DBMS_SQL.NATIVE);
      --绑定输入参数
      IF INSTR(S_SEMANTIC_VAL_0, ':P_BEGIN_DATE', 1, 1) > 0 THEN
        DBMS_SQL.BIND_VARIABLE(N_CUR, ':P_BEGIN_DATE', D_SEM_BEGIN_DATE);
      END IF;
      IF INSTR(S_SEMANTIC_VAL_0, ':P_END_DATE', 1, 1) > 0 THEN
        DBMS_SQL.BIND_VARIABLE(N_CUR, ':P_END_DATE', D_SEM_END_DATE);
      END IF;
      IF INSTR(S_SEMANTIC_VAL_0, ':P_POLICY_ID', 1, 1) > 0 THEN
        DBMS_SQL.BIND_VARIABLE(N_CUR, ':P_POLICY_ID', N_POLICY_ID);
      END IF;
      IF INSTR(S_SEMANTIC_VAL_0, ':P_DEFINE_ID', 1, 1) > 0 THEN
        DBMS_SQL.BIND_VARIABLE(N_CUR, ':P_DEFINE_ID', IN_DEFINE_ID);
      END IF;
      IF INSTR(S_SEMANTIC_VAL_0, ':P_MTL_TYPE', 1, 1) > 0 THEN
        DBMS_SQL.BIND_VARIABLE(N_CUR, ':P_MTL_TYPE', S_MTL_TYPE);
      END IF;
      IF INSTR(S_SEMANTIC_VAL_0, ':P_RESULT_DATE', 1, 1) > 0 THEN
        DBMS_SQL.BIND_VARIABLE(N_CUR, ':P_RESULT_DATE', ID_RESULT_DATE);
      END IF;
      IF INSTR(S_SEMANTIC_VAL_0, ':P_ENTITY_ID', 1, 1) > 0 THEN
        DBMS_SQL.BIND_VARIABLE(N_CUR, ':P_ENTITY_ID', IN_ENTITY_ID);
      END IF;
      IF INSTR(S_SEMANTIC_VAL_0, ':P_CONDITION_SQL', 1, 1) > 0 THEN
        DBMS_SQL.BIND_VARIABLE(N_CUR, ':P_CONDITION_SQL', S_CONDITION_SQL);
      END IF;
      --执行语句
      N_ROW := DBMS_SQL.EXECUTE(N_CUR);
      --关闭光标
      DBMS_SQL.CLOSE_CURSOR(N_CUR);
    END IF;
    
    IF OS_MESSAGE = 'OK' THEN
      --处理四舍五入差异
      S_STEP := '处理差异';
      P_SET_ITEM_DETAIL_DEF(N_POLICY_ID,IN_DEFINE_ID,S_DEFINE_CODE,ID_RESULT_DATE,OS_MESSAGE);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      OS_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_POL_CAL.P_SET_ITEM_DETAIL_SEM_SQL','100','SQL计算产品明细-' || S_STEP || '(项目ID=' || TO_CHAR(IN_DEFINE_ID) || ',项目代码=' || S_DEFINE_CODE || ')！SQL=' || S_SEMANTIC_VAL_0 || '！' || SQLERRM);
      OS_MESSAGE := 'SQL计算产品明细-' || S_STEP || '(项目ID=' || TO_CHAR(IN_DEFINE_ID) || ',项目代码=' || S_DEFINE_CODE || ')！SQL=' || S_SEMANTIC_VAL_0 || '！' || SQLERRM;
  END P_SET_ITEM_DETAIL_SEM_SQL;

  -----------------------------------------------------------------------------
  --  取政策的日期范围 
  --  对于存在父政策，则取父政策的日期范围，否则取当前政策的日期范围
  -----------------------------------------------------------------------------
  /*暂不使用政策日期
  PROCEDURE P_GET_POLICY_DATE
  (
    IN_POLICY_ID   IN  NUMBER       --政策ID
    ,OD_BEGIN_DATE OUT DATE         --起始日期
    ,OD_END_DATE   OUT DATE         --终止日期
  )
  IS
    N_PARENT_POLICY_ID    NUMBER;
  BEGIN
    --无起止日期，则取政策申请的日期范围
    SELECT
      BEGIN_DATE
      ,END_DATE
      ,PARENT_POLICY_ID
    INTO
      OD_BEGIN_DATE
      ,OD_END_DATE
      ,N_PARENT_POLICY_ID
    FROM
      T_POL_POLICY
    WHERE
      POLICY_ID = IN_POLICY_ID;
    IF N_PARENT_POLICY_ID IS NOT NULL THEN
      --存在父政策，则以父政策的起始日期、终止日期为准
      SELECT
        BEGIN_DATE
        ,END_DATE
      INTO
        OD_BEGIN_DATE
        ,OD_END_DATE
      FROM
        T_POL_POLICY
      WHERE
        POLICY_ID = N_PARENT_POLICY_ID;
    END IF; 
  END P_GET_POLICY_DATE;
  */

  -----------------------------------------------------------------------------
  --  取用于分解产品计算结果的汇总数 
  --  为了优化性能，第一次取数据时，将SQL对应的数据写入临时表（T_POL_ITEM_SPLIT_TMP）
  --  存在临时表数据，则直接取临时表的内容统计
  -----------------------------------------------------------------------------
  PROCEDURE P_GET_SPLIT_SUM
  (
    IN_POLICY_ID   IN  NUMBER       --政策ID
    ,IN_ENTITY_ID  IN  NUMBER       --主体ID
    ,ID_BEGIN_DATE IN  DATE         --起始日期
    ,ID_END_DATE   IN  DATE         --终止日期
    ,ON_SUM        OUT NUMBER       --输出分摊语义对应的汇总值
    ,OS_MESSAGE    OUT VARCHAR2     --成功则返回“OK”，否则返回出错信息
  )
  IS
    S_SPLIT_SEM_CODE VARCHAR2(40);
    N_SEMANTIC_ID    NUMBER;
    D_BILL_DATE      DATE;
    S_SQL            VARCHAR2(4000);
    S_SUM_FIELD      VARCHAR2(30);
    N_CUR            NUMBER;
    N_ROW            NUMBER;
    N_CNT            NUMBER := 0;
    B_TMP_NULL       BOOLEAN;
    S_STEP           VARCHAR2(40);
  BEGIN
    OS_MESSAGE := 'OK';
    --检查产品拆分临时表是否有数据
    SELECT
      COUNT(*)
    INTO
      N_CNT
    FROM
      T_POL_ITEM_SPLIT_TMP
    WHERE
      ROWNUM = 1;
    B_TMP_NULL := (N_CNT = 0);

    --从系统参数获取用于分摊的语义
    S_STEP := '获取分摊语义参数';
    S_SPLIT_SEM_CODE := PKG_BD.F_GET_PARAMETER_VALUE('POL_SPLIT_SEM_CODE',IN_ENTITY_ID);
    --获取语义对应的SQL
    S_STEP := '获取语义对应的SQL';
    SELECT
      SEMANTIC_ID
      ,GET_VAL_SQL
    INTO
      N_SEMANTIC_ID
      ,S_SQL
     FROM
       T_POL_SEMANTIC
     WHERE
       SEMANTIC_CODE = S_SPLIT_SEM_CODE
       AND ENTITY_ID = IN_ENTITY_ID;
      
    --获取分摊语义字段名
    S_STEP := '获取分摊语义字段名';
    SELECT
      FIELD_CODE
    INTO
      S_SUM_FIELD
    FROM
      T_POL_SEMANTIC_LINE
    WHERE
      SEMANTIC_ID = N_SEMANTIC_ID
      AND ROWNUM = 1;
      
    /*可能会取到较多无效时间范围，故改为每天检查
    --获取语义最大的时间范围
    S_STEP := '取时间范围';
    SELECT
      MIN(SEM_BEGIN_DATE)
      ,MAX(SEM_END_DATE)
    INTO
      D_SEM_BEGIN_DATE
      ,D_SEM_END_DATE
    FROM
      T_POL_POLICY_DEFINE
    WHERE
      POLICY_ID = IN_POLICY_ID;
      
    --获取政策的时间范围
    P_GET_POLICY_DATE(IN_POLICY_ID,D_BEGIN_DATE,D_END_DATE);
      
    --取最大的时间范围作为临时表记录数据的时间范围
    IF D_SEM_BEGIN_DATE < D_BEGIN_DATE THEN
      D_BEGIN_DATE := D_SEM_BEGIN_DATE;
    END IF;
    IF D_SEM_END_DATE > D_END_DATE THEN
      D_END_DATE := D_SEM_END_DATE;
    END IF;
    */
      
    S_STEP := '写产品分摊临时表';
    --拼接成SUM的SQL
    S_SQL := 'INSERT INTO T_POL_ITEM_SPLIT_TMP (BILL_DATE,ITEM_ID,VALUE) '
      || 'SELECT :P_BILL_DATE,ITEM_ID,' ||  S_SUM_FIELD || ' FROM (' || S_SQL
      || ')';

    --打开光标
    N_CUR := DBMS_SQL.OPEN_CURSOR;
    --解析动态SQL语句
    DBMS_SQL.PARSE(N_CUR, S_SQL, DBMS_SQL.NATIVE);
    DBMS_SQL.BIND_VARIABLE(N_CUR, ':P_ENTITY_ID', IN_ENTITY_ID);
    D_BILL_DATE := ID_BEGIN_DATE; 
    IF B_TMP_NULL THEN
      WHILE D_BILL_DATE <= ID_END_DATE
      LOOP
        --绑定输入参数
        DBMS_SQL.BIND_VARIABLE(N_CUR, ':P_BILL_DATE', D_BILL_DATE);
        --执行语句
        N_ROW := DBMS_SQL.EXECUTE(N_CUR);
        D_BILL_DATE := D_BILL_DATE+1;
      END LOOP;
    ELSE
      WHILE D_BILL_DATE <= ID_END_DATE
      LOOP
        --检查是否存在于临时表
        SELECT
          COUNT(*)
        INTO
          N_CNT
        FROM
          T_POL_ITEM_SPLIT_TMP
        WHERE
          BILL_DATE = D_BILL_DATE
          AND ROWNUM = 1;
        --不存在则新增
        IF N_CNT = 0 THEN
          --绑定输入参数
          DBMS_SQL.BIND_VARIABLE(N_CUR, ':P_BILL_DATE', D_BILL_DATE);
          --执行语句
          N_ROW := DBMS_SQL.EXECUTE(N_CUR);
        END IF;
        D_BILL_DATE := D_BILL_DATE+1;
      END LOOP;
    END IF;
    
    --关闭光标
    DBMS_SQL.CLOSE_CURSOR(N_CUR);
    
    --从产品拆分临时表中取汇总值
    S_STEP := '获取分摊语义汇总值';
    SELECT
      SUM(VALUE)
    INTO
      ON_SUM
    FROM
      T_POL_ITEM_SPLIT_TMP
    WHERE
      BILL_DATE BETWEEN ID_BEGIN_DATE AND ID_END_DATE;
  EXCEPTION
    WHEN OTHERS THEN
      IF N_CUR <> 0 THEN
        DBMS_SQL.CLOSE_CURSOR(N_CUR);
      END IF;
      OS_MESSAGE := '获取分摊语义-' || S_STEP || '：' || SQLERRM;
  END P_GET_SPLIT_SUM;
  
  -----------------------------------------------------------------------------
  --  对不能分解到产品的数据按写指定语义分解产品明细                                                    --
  -----------------------------------------------------------------------------
  PROCEDURE P_SET_ITEM_DETAIL_SPLIT
  (
    IN_DEFINE_ID              IN NUMBER   --政策算法定义ID
    ,IN_ENTITY_ID             IN NUMBER   --主体ID
    ,ID_RESULT_DATE           IN DATE     --报表日期
    ,IS_USER_ID               IN VARCHAR2 --用户账号
    ,OS_MESSAGE               OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  ) IS
    N_POLICY_ID              NUMBER;
    S_DEFINE_CODE            VARCHAR2(100);
    D_SEM_BEGIN_DATE         DATE;
    D_SEM_END_DATE           DATE;
    S_DETAIL_FLAG            VARCHAR2(1);
    S_MTL_TYPE               VARCHAR2(100);
    N_PARENT_POLICY_ID       NUMBER;

    N_CUR                    NUMBER;
    N_ROW                    NUMBER;

    N_SPLIT_SUM              NUMBER;
    S_SQL                    VARCHAR2(4000);
    S_STEP                   VARCHAR2(40);
  BEGIN
    OS_MESSAGE := 'OK';

    --政策算法定义信息
    S_STEP := '取政策算法定义信息';
    SELECT T.POLICY_ID
         , T.DEFINE_CODE
         , T.SEM_BEGIN_DATE
         , T.SEM_END_DATE
         , T.DETAIL_FLAG
         , T.MTL_TYPE
      INTO N_POLICY_ID
         , S_DEFINE_CODE
         , D_SEM_BEGIN_DATE
         , D_SEM_END_DATE
         , S_DETAIL_FLAG
         , S_MTL_TYPE
      FROM T_POL_POLICY_DEFINE T
     WHERE T.DEFINE_ID = IN_DEFINE_ID;
    
    --无起止日期，则取归属返利周期的日期范围
    IF D_SEM_BEGIN_DATE IS NULL OR D_SEM_END_DATE IS NULL THEN
      S_STEP := '取归属返利周期信息';
      SELECT
        TO_DATE(DISCOUNT_PERIOD || '-01','YYYY-MM-DD')
      INTO
        D_SEM_BEGIN_DATE
      FROM
        T_POL_POLICY
      WHERE
        POLICY_ID = N_POLICY_ID;
      D_SEM_END_DATE := ADD_MONTHS(D_SEM_BEGIN_DATE,1)-1;
      --P_GET_POLICY_DATE(N_POLICY_ID,D_SEM_BEGIN_DATE,D_SEM_END_DATE);
    END IF;

    --获取汇总语义
    S_STEP := '获取汇总值';
    P_GET_SPLIT_SUM(N_POLICY_ID,IN_ENTITY_ID,D_SEM_BEGIN_DATE,D_SEM_END_DATE,N_SPLIT_SUM,OS_MESSAGE);

    --取计算结算明细，按分解语义写入产品结果明细表
    IF OS_MESSAGE = 'OK' THEN
      IF NVL(N_SPLIT_SUM,0) = 0 THEN
        OS_MESSAGE := '分摊语义在' || TO_CHAR(D_SEM_BEGIN_DATE,'YYYY-MM-DD') || '到' || TO_CHAR(D_SEM_END_DATE,'YYYY-MM-DD') || '期间没有数据，不能处理分摊！';
      ELSE
        S_STEP := '写产品结果明细临时表';
        S_SQL := 'INSERT INTO T_POL_RESULT_ITEM_DETAIL_TMP(ACCOUNT_ID, ITEM_ID, DEFINE_CODE, VALUE)'
          || ' SELECT D.ACCOUNT_ID, S.ITEM_ID,''' || S_DEFINE_CODE || ''' DEFINE_CODE'
          || '   ,ROUND(D.RESULT_VALUE*S.VALUE/' || TO_CHAR(N_SPLIT_SUM) || ',2) VALUE'
          || ' FROM T_POL_POLICY_RESULT_DETAIL D'
          || '   ,('
          || '     SELECT ITEM_ID,SUM(VALUE) VALUE'
          || '     FROM T_POL_ITEM_SPLIT_TMP'
          || '     WHERE BILL_DATE BETWEEN :P_BEGIN_DATE AND :P_END_DATE'
          || '     GROUP BY ITEM_ID'
          || '   ) S'
          || ' WHERE D.POLICY_ID = :P_POLICY_ID'
          || '   AND D.RESULT_DATE = :P_RESULT_DATE'
          || '   AND D.DEFINE_ID = :P_DEFINE_ID'
          || '   AND ROUND(D.RESULT_VALUE*S.VALUE/' || TO_CHAR(N_SPLIT_SUM) || ',2) <> 0';
        --打开光标
        N_CUR := DBMS_SQL.OPEN_CURSOR;
        --解析动态SQL语句
        DBMS_SQL.PARSE(N_CUR, S_SQL, DBMS_SQL.NATIVE);
        --绑定输入参数
        IF INSTR(S_SQL, ':P_BEGIN_DATE', 1, 1) > 0 THEN
          DBMS_SQL.BIND_VARIABLE(N_CUR, ':P_BEGIN_DATE', D_SEM_BEGIN_DATE);
        END IF;
        IF INSTR(S_SQL, ':P_END_DATE', 1, 1) > 0 THEN
          DBMS_SQL.BIND_VARIABLE(N_CUR, ':P_END_DATE', D_SEM_END_DATE);
        END IF;
        IF INSTR(S_SQL, ':P_POLICY_ID', 1, 1) > 0 THEN
          DBMS_SQL.BIND_VARIABLE(N_CUR, ':P_POLICY_ID', N_POLICY_ID);
        END IF;
        IF INSTR(S_SQL, ':P_DEFINE_ID', 1, 1) > 0 THEN
          DBMS_SQL.BIND_VARIABLE(N_CUR, ':P_DEFINE_ID', IN_DEFINE_ID);
        END IF;
        IF INSTR(S_SQL, ':P_MTL_TYPE', 1, 1) > 0 THEN
          DBMS_SQL.BIND_VARIABLE(N_CUR, ':P_MTL_TYPE', S_MTL_TYPE);
        END IF;
        IF INSTR(S_SQL, ':P_RESULT_DATE', 1, 1) > 0 THEN
          DBMS_SQL.BIND_VARIABLE(N_CUR, ':P_RESULT_DATE', ID_RESULT_DATE);
        END IF;
        IF INSTR(S_SQL, ':P_ENTITY_ID', 1, 1) > 0 THEN
          DBMS_SQL.BIND_VARIABLE(N_CUR, ':P_ENTITY_ID', IN_ENTITY_ID);
        END IF;
        --执行语句
        N_ROW := DBMS_SQL.EXECUTE(N_CUR);
        --关闭光标
        DBMS_SQL.CLOSE_CURSOR(N_CUR);
      END IF;
    END IF;
    
    IF OS_MESSAGE = 'OK' THEN
      --处理四舍五入差异
      S_STEP := '处理差异';
      P_SET_ITEM_DETAIL_DEF(N_POLICY_ID,IN_DEFINE_ID,S_DEFINE_CODE,ID_RESULT_DATE,OS_MESSAGE);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      OS_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_POL_CAL.P_SET_ITEM_DETAIL_SPLIT','100','按指定算法分解明细-' || S_STEP || '(项目ID=' || TO_CHAR(IN_DEFINE_ID) || ',项目代码=' || S_DEFINE_CODE || ')！SQL=' || S_SQL || '！' || SQLERRM);
      OS_MESSAGE := '按指定算法分解明细-' || S_STEP || '(项目ID=' || TO_CHAR(IN_DEFINE_ID) || ',项目代码=' || S_DEFINE_CODE || ')！SQL=' || S_SQL || '！' || SQLERRM;
  END P_SET_ITEM_DETAIL_SPLIT;

  -----------------------------------------------------------------------------
  --  将政策计算结果调整值分解到产品明细计算结果数据中
  --  分解方法：根据应计返利金额的占比分解
  -----------------------------------------------------------------------------
  PROCEDURE P_SET_ITEM_DETAIL_SPLIT_ADJUST
  (
    IN_POLICY_CHK_ID          IN NUMBER   --政策计算结果审批ID
    ,IN_POLICY_ID             IN NUMBER   --政策ID
    ,IS_USER_ID               IN VARCHAR2 --用户账号
    ,OS_MESSAGE               OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  ) IS
    N_ENTITY_ID              NUMBER;
    D_RESULT_DATE            DATE;
    D_NEXT_RESULT_DATE       DATE;
    S_STEP                   VARCHAR2(40);
    N_CNT                    NUMBER;
  BEGIN
    OS_MESSAGE := 'OK';
    
    --获取计算结果日期
    S_STEP := '获取计算结果日期';
    SELECT
      RESULT_DATE
    INTO
      D_RESULT_DATE
    FROM
      T_POL_POLICY_RESULT
    WHERE
      RESULT_CHK_ID = IN_POLICY_CHK_ID
      AND ROWNUM = 1;

    --写产品结果明细表
    S_STEP := '写产品结果明细表';
    UPDATE
      T_POL_POLICY_RESULT_ITEM I
    SET
      I.ADJUST_AMOUNT =
      (
        SELECT
          ROUND(R.ADJUST_AMOUNT*I.RECKON_AMOUNT/R.RECKON_AMOUNT,2)
        FROM
          T_POL_POLICY_RESULT R
        WHERE
          R.RESULT_ID = I.RESULT_ID
      )
    WHERE
      I.POLICY_ID = IN_POLICY_ID
      AND I.RESULT_DATE = D_RESULT_DATE
      AND I.RECKON_AMOUNT <> 0
      AND EXISTS(
        SELECT
          1
        FROM
          T_POL_POLICY_RESULT R
        WHERE
          R.RESULT_ID = I.RESULT_ID
          AND NVL(R.ADJUST_AMOUNT,0) <> 0
          AND NVL(R.RECKON_AMOUNT,0) <> 0
      );

    --将四舍五入的差异金额更新到最大金额中
    --循环取出有差异的数据
    IF OS_MESSAGE = 'OK' THEN
      S_STEP := '处理差异';
      FOR R_RESULT_DEF IN
      (
        SELECT
          R.RESULT_ID
          ,R.ACCOUNT_ID
          ,NVL(R.ADJUST_AMOUNT,0) - T.SUM_AMOUNT DEF_AMOUNT
          ,T.MAX_AMOUNT
        FROM
          T_POL_POLICY_RESULT R
          ,(
            SELECT
              ACCOUNT_ID
              ,SUM(NVL(ADJUST_AMOUNT,0)) SUM_AMOUNT
              ,MAX(NVL(ADJUST_AMOUNT,0)) MAX_AMOUNT
            FROM
              T_POL_POLICY_RESULT_ITEM
            WHERE
              POLICY_ID = IN_POLICY_ID
              AND RESULT_DATE = D_RESULT_DATE
            GROUP BY
              ACCOUNT_ID
          ) T
        WHERE
          R.ACCOUNT_ID = T.ACCOUNT_ID
          AND R.RESULT_CHK_ID = IN_POLICY_CHK_ID
          AND NVL(R.ADJUST_AMOUNT,0) <> T.SUM_AMOUNT
      )
      LOOP
        --更新取大值的产品明细中
        UPDATE
          T_POL_POLICY_RESULT_ITEM
        SET
          ADJUST_AMOUNT = NVL(ADJUST_AMOUNT,0)+R_RESULT_DEF.DEF_AMOUNT
          ,LAST_UPDATED_BY = IS_USER_ID
          ,LAST_UPDATE_DATE = SYSDATE
        WHERE
          RESULT_ID = R_RESULT_DEF.RESULT_ID
          AND ACCOUNT_ID = R_RESULT_DEF.ACCOUNT_ID
          AND NVL(ADJUST_AMOUNT,0) = R_RESULT_DEF.MAX_AMOUNT
          AND ROWNUM = 1;

      END LOOP;
    END IF;
      
    --更新产品明细计算结果中的实际返利金额，不更新已返利
    IF OS_MESSAGE = 'OK' THEN
      S_STEP := '更新实际返利';
      UPDATE
        T_POL_POLICY_RESULT_ITEM
      SET
        RESULT_AMOUNT = NVL(RECKON_AMOUNT,0)+NVL(ADJUST_AMOUNT,0)
        ,LAST_UPDATED_BY = IS_USER_ID
        ,LAST_UPDATE_DATE = SYSDATE
      WHERE
        POLICY_ID = IN_POLICY_ID
        AND RESULT_DATE = D_RESULT_DATE;
    END IF;

    --对于存在下一计算结果，则更新对应的已返利金额
    --可能有多个计算结果，对后面所有的日期处理更新
    IF OS_MESSAGE = 'OK' THEN
      S_STEP := '更新下一计算结果';
      --更新已返利金额
      UPDATE
        T_POL_POLICY_RESULT_ITEM I_C
      SET
        REBATE_AMOUNT =
        (
          SELECT
            I_P.RESULT_AMOUNT
          FROM
            T_POL_POLICY_RESULT_ITEM I_P
          WHERE
            I_P.POLICY_ID = IN_POLICY_ID
            AND I_P.RESULT_DATE = D_RESULT_DATE
            AND I_P.ACCOUNT_ID = I_C.ACCOUNT_ID
            AND I_P.ITEM_ID = I_C.ITEM_ID
        )
      WHERE
        POLICY_ID = IN_POLICY_ID
        AND RESULT_DATE > D_RESULT_DATE;
    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      OS_MESSAGE := '分摊调整值-' || S_STEP || '(审批ID=' || TO_CHAR(IN_POLICY_CHK_ID) || ')！' || SQLERRM;

  END P_SET_ITEM_DETAIL_SPLIT_ADJUST;


  -----------------------------------------------------------------------------
  --  将产品明细结果临时表内容转换成产品明细结果表                                                    --
  -----------------------------------------------------------------------------
  PROCEDURE P_TO_ITEM_DETAIL
  (
    IN_POLICY_ID              IN NUMBER   --政策算法定义ID
    ,ID_RESULT_DATE           IN DATE     --报表日期
    ,IS_USER_ID               IN VARCHAR2 --用户账号
    ,OS_MESSAGE               OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  ) IS
    N_CUR                    NUMBER;
    N_ROW                    NUMBER;
    N_I                      NUMBER := 0;
    S_SQL                    VARCHAR2(4000);
    D_PRIOR_DATE             DATE;  --上次运算的日期
    S_STEP                   VARCHAR2(40);
  BEGIN
    OS_MESSAGE := 'OK';

    --更新临时表中的列序号
    S_STEP := '更新临时表中的列序号';
    FOR R_DEFINE IN
    (
      SELECT
        DEFINE_CODE
      FROM
        T_POL_POLICY_DEFINE
      WHERE
        POLICY_ID = IN_POLICY_ID
      ORDER BY
        DEFINE_CODE
    )
    LOOP
      N_I := N_I + 1;
      UPDATE
        T_POL_RESULT_ITEM_DETAIL_TMP
      SET
        ORDER_NO = N_I
      WHERE
        DEFINE_CODE =  R_DEFINE.DEFINE_CODE;
    END LOOP;
    
    --按序号插入正式表
    S_STEP := '按序号插入正式表';
    INSERT INTO T_POL_POLICY_RESULT_ITEM
    (
      POLICY_RESULT_ITEM_ID
      ,POLICY_ID
      ,RESULT_DATE
      ,ACCOUNT_ID
      ,ITEM_ID
      ,CUSTOMER_TYPE
      ,RESULT_ID
      ,VALUE01
      ,VALUE02
      ,VALUE03
      ,VALUE04
      ,VALUE05
      ,VALUE06
      ,VALUE07
      ,VALUE08
      ,VALUE09
      ,VALUE10
      ,VALUE11
      ,VALUE12
      ,VALUE13
      ,VALUE14
      ,VALUE15
      ,VALUE16
      ,VALUE17
      ,VALUE18
      ,VALUE19
      ,VALUE20
      ,CREATED_BY
      ,CREATION_DATE
      ,LAST_UPDATED_BY
      ,LAST_UPDATE_DATE
    )
    SELECT
      S_POL_POLICY_RESULT_ITEM.NEXTVAL POLICY_RESULT_ITEM_ID
      ,IN_POLICY_ID POLICY_ID
      ,ID_RESULT_DATE RESULT_DATE
      ,T.ACCOUNT_ID
      ,T.ITEM_ID
      ,(
        SELECT
          T.CUSTOMER_TYPE
        FROM
          T_POL_POLICY_CUS_TYPE T
        WHERE
          T.POLICY_ID = IN_POLICY_ID
          AND T.TAR_ACCOUNT_ID = R.ACCOUNT_ID
          AND ROWNUM = 1
      ) CUSTOMER_TYPE
      ,R.RESULT_ID
      ,T.VALUE01
      ,T.VALUE02
      ,T.VALUE03
      ,T.VALUE04
      ,T.VALUE05
      ,T.VALUE06
      ,T.VALUE07
      ,T.VALUE08
      ,T.VALUE09
      ,T.VALUE10
      ,T.VALUE11
      ,T.VALUE12
      ,T.VALUE13
      ,T.VALUE14
      ,T.VALUE15
      ,T.VALUE16
      ,T.VALUE17
      ,T.VALUE18
      ,T.VALUE19
      ,T.VALUE20
      ,IS_USER_ID CREATED_BY
      ,SYSDATE CREATION_DATE
      ,IS_USER_ID LAST_UPDATED_BY
      ,SYSDATE LAST_UPDATE_DATE
    FROM
      T_POL_POLICY_RESULT R
      ,(
        SELECT
          ACCOUNT_ID
          ,ITEM_ID
          ,SUM(DECODE(ORDER_NO,1,VALUE,0)) VALUE01
          ,SUM(DECODE(ORDER_NO,2,VALUE,0)) VALUE02
          ,SUM(DECODE(ORDER_NO,3,VALUE,0)) VALUE03
          ,SUM(DECODE(ORDER_NO,4,VALUE,0)) VALUE04
          ,SUM(DECODE(ORDER_NO,5,VALUE,0)) VALUE05
          ,SUM(DECODE(ORDER_NO,6,VALUE,0)) VALUE06
          ,SUM(DECODE(ORDER_NO,7,VALUE,0)) VALUE07
          ,SUM(DECODE(ORDER_NO,8,VALUE,0)) VALUE08
          ,SUM(DECODE(ORDER_NO,9,VALUE,0)) VALUE09
          ,SUM(DECODE(ORDER_NO,10,VALUE,0)) VALUE10
          ,SUM(DECODE(ORDER_NO,11,VALUE,0)) VALUE11
          ,SUM(DECODE(ORDER_NO,12,VALUE,0)) VALUE12
          ,SUM(DECODE(ORDER_NO,13,VALUE,0)) VALUE13
          ,SUM(DECODE(ORDER_NO,14,VALUE,0)) VALUE14
          ,SUM(DECODE(ORDER_NO,15,VALUE,0)) VALUE15
          ,SUM(DECODE(ORDER_NO,16,VALUE,0)) VALUE16
          ,SUM(DECODE(ORDER_NO,17,VALUE,0)) VALUE17
          ,SUM(DECODE(ORDER_NO,18,VALUE,0)) VALUE18
          ,SUM(DECODE(ORDER_NO,19,VALUE,0)) VALUE19
          ,SUM(DECODE(ORDER_NO,20,VALUE,0)) VALUE20
        FROM
          T_POL_RESULT_ITEM_DETAIL_TMP
        GROUP BY
          ACCOUNT_ID
          ,ITEM_ID
      ) T
    WHERE
      R.ACCOUNT_ID = T.ACCOUNT_ID
      AND R.POLICY_ID = IN_POLICY_ID
      AND R.RESULT_DATE = ID_RESULT_DATE;  

    --更新汇总值
    S_STEP := '更新汇总值';
    N_I := 0;
    FOR R_DEFINE IN
    (
      SELECT
        DEFINE_ID
        ,DEFINE_CODE
      FROM
        T_POL_POLICY_DEFINE
      WHERE
        POLICY_ID = IN_POLICY_ID
      ORDER BY
        DEFINE_CODE
    )
    LOOP
      N_I := N_I + 1;
      --将汇总值更新到产品明细结果表中
      S_SQL := 'UPDATE T_POL_POLICY_RESULT_ITEM I'
        || ' SET SUM' || TRIM(TO_CHAR(N_I,'00')) || '='
        || '   (SELECT RESULT_VALUE'
        || '    FROM T_POL_POLICY_RESULT_DETAIL D'
        || '    WHERE D.POLICY_ID = :P_POLICY_ID'
        || '      AND D.RESULT_DATE = :P_RESULT_DATE'
        || '      AND D.DEFINE_ID = :P_DEFINE_ID'
        || '      AND D.RESULT_ID = I.RESULT_ID)'
        || ' WHERE I.POLICY_ID = :P_POLICY_ID'
        || '   AND I.RESULT_DATE = :P_RESULT_DATE';
      --打开光标
      N_CUR := DBMS_SQL.OPEN_CURSOR;
      --解析动态SQL语句
      DBMS_SQL.PARSE(N_CUR, S_SQL, DBMS_SQL.NATIVE);
      --绑定输入参数
      DBMS_SQL.BIND_VARIABLE(N_CUR, ':P_POLICY_ID', IN_POLICY_ID);
      DBMS_SQL.BIND_VARIABLE(N_CUR, ':P_DEFINE_ID', R_DEFINE.DEFINE_ID);
      DBMS_SQL.BIND_VARIABLE(N_CUR, ':P_RESULT_DATE', ID_RESULT_DATE);
      --执行语句
      N_ROW := DBMS_SQL.EXECUTE(N_CUR);
      --关闭光标
      DBMS_SQL.CLOSE_CURSOR(N_CUR);
    END LOOP;
    
    --获取上一次运行的日期（必须是已返利）
    BEGIN
      SELECT
        MAX(R.RESULT_DATE)
      INTO
        D_PRIOR_DATE
      FROM
        T_POL_POLICY_RESULT R
      WHERE
        R.POLICY_ID = IN_POLICY_ID
        AND R.RESULT_DATE < ID_RESULT_DATE
        AND R.POLICY_ORDER_LINE_ID IS NOT NULL;
      
      --存在上一次运行日期，则更新已返利金额
      --将前一次的总返利金额更新到当前计算结果中的已返利金额
      S_STEP := '更新已返利金额';
      UPDATE
        T_POL_POLICY_RESULT_ITEM I_C
      SET
        REBATE_AMOUNT =
        (
          SELECT
            I_P.RESULT_AMOUNT
          FROM
            T_POL_POLICY_RESULT_ITEM I_P
          WHERE
            I_P.POLICY_ID = IN_POLICY_ID
            AND I_P.RESULT_DATE = D_PRIOR_DATE
            AND I_P.ACCOUNT_ID = I_C.ACCOUNT_ID
            AND I_P.ITEM_ID = I_C.ITEM_ID
        )
      WHERE
        POLICY_ID = IN_POLICY_ID
        AND RESULT_DATE = ID_RESULT_DATE;
      
      --补充不存在的数据
      S_STEP := '补充不存在的数据';
      INSERT INTO T_POL_POLICY_RESULT_ITEM
      (
        POLICY_RESULT_ITEM_ID
        ,POLICY_ID
        ,RESULT_DATE
        ,ACCOUNT_ID
        ,ITEM_ID
        ,CUSTOMER_TYPE
        ,RESULT_ID
        ,CREATED_BY
        ,CREATION_DATE
        ,LAST_UPDATED_BY
        ,LAST_UPDATE_DATE
      )
      SELECT
        S_POL_POLICY_RESULT_ITEM.NEXTVAL POLICY_RESULT_ITEM_ID
        ,IN_POLICY_ID POLICY_ID
        ,ID_RESULT_DATE RESULT_DATE
        ,I_P.ACCOUNT_ID
        ,I_P.ITEM_ID
        ,(
          SELECT
            T.CUSTOMER_TYPE
          FROM
            T_POL_POLICY_CUS_TYPE T
          WHERE
            T.POLICY_ID = IN_POLICY_ID
            AND T.TAR_ACCOUNT_ID = R.ACCOUNT_ID
            AND ROWNUM = 1
        ) CUSTOMER_TYPE
        ,R.RESULT_ID
        ,IS_USER_ID CREATED_BY
        ,SYSDATE CREATION_DATE
        ,IS_USER_ID LAST_UPDATED_BY
        ,SYSDATE LAST_UPDATE_DATE
      FROM
        T_POL_POLICY_RESULT R
        ,T_POL_POLICY_RESULT_ITEM I_C
        ,T_POL_POLICY_RESULT_ITEM I_P
      WHERE
        R.ACCOUNT_ID = I_P.ACCOUNT_ID
        AND R.POLICY_ID = IN_POLICY_ID
        AND R.RESULT_DATE = ID_RESULT_DATE
        AND I_P.POLICY_ID = IN_POLICY_ID
        AND I_P.RESULT_DATE = D_PRIOR_DATE
        AND I_C.POLICY_ID(+) = IN_POLICY_ID
        AND I_C.RESULT_DATE(+) = ID_RESULT_DATE
        AND I_P.ACCOUNT_ID = I_C.ACCOUNT_ID(+)
        AND I_P.ITEM_ID = I_C.ITEM_ID(+)
        AND I_C.ITEM_ID IS NULL;  
      
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        --不存在上一次运行日期，则不处理
        NULL;
    END;

  EXCEPTION
    WHEN OTHERS THEN
      IF (S_STEP = '更新汇总值') THEN
         OS_MESSAGE := '生成产品结果明细-' || S_STEP || '(政策ID=' || TO_CHAR(IN_POLICY_ID) || ')！SQL=' || S_SQL || '！' || SQLERRM;
      ELSE
         OS_MESSAGE := '生成产品结果明细-' || S_STEP || '(政策ID=' || TO_CHAR(IN_POLICY_ID) || ')！' || SQLERRM;
      END IF;
  END P_TO_ITEM_DETAIL;

  -----------------------------------------------------------------------------
  --  设置产品明细结果中的公式值                                                    --
  -----------------------------------------------------------------------------
  PROCEDURE P_SET_ITEM_DETAIL_EXP_VAL
  (
    IN_POLICY_ID              IN NUMBER   --政策算法定义ID
    ,ID_RESULT_DATE           IN DATE     --报表日期
    ,IS_USER_ID               IN VARCHAR2 --用户账号
    ,OS_MESSAGE               OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  ) IS
    S_RESULT_DEFINE_CODE     VARCHAR2(40);
    S_FIELD                  VARCHAR2(30) := NULL;
    S_WHERE                  VARCHAR2(200);
    N_CUR                    NUMBER;
    N_ROW                    NUMBER;
    S_EXP                    VARCHAR2(1000);
    S_SQL                    VARCHAR2(4000);
    S_STEP                   VARCHAR2(40);
    N_I                      NUMBER;
    N_DEF_AMOUNT             NUMBER;
    N_MAX_AMOUNT             NUMBER;
  BEGIN
    OS_MESSAGE := 'OK';

    --取出应计返利金额的项编码
    S_STEP := '取出应计返利';
    SELECT
      RESULT_DEFINE_CODE
    INTO
      S_RESULT_DEFINE_CODE
    FROM
      T_POL_POLICY
    WHERE
      POLICY_ID = IN_POLICY_ID;
    
    S_WHERE := ' WHERE POLICY_ID = ' || TO_CHAR(IN_POLICY_ID)
      || ' AND RESULT_DATE = TO_DATE(''' || TO_CHAR(ID_RESULT_DATE,'YYYY-MM-DD') || ''',''YYYY-MM-DD'')';
    
    --循环取出公式
    S_STEP := '循环取出公式';
    FOR R_DEFINE IN
    (
      SELECT
        DEFINE_CODE
        ,CAL_EXP
      FROM
        T_POL_POLICY_DEFINE
      WHERE
        POLICY_ID = IN_POLICY_ID
        AND GET_VAL_TYPE = '2'
      ORDER BY
        PRIOR_LEVEL
        ,DEFINE_CODE
    )
    LOOP
      --取编码对应的序号
      SELECT
        COUNT(*)
      INTO
        N_I
      FROM
        T_POL_POLICY_DEFINE
      WHERE
        POLICY_ID = IN_POLICY_ID
        AND DEFINE_CODE <= R_DEFINE.DEFINE_CODE;
      
      --解释公式
      S_STEP := '解释公式，编码:' || R_DEFINE.DEFINE_CODE;
      --清空前后空格，并将“"”变为“''”
      S_EXP := REPLACE(R_DEFINE.CAL_EXP,'"','''');
      --清除回车符
      S_EXP := REPLACE(S_EXP,CHR(13),'');
      S_EXP := REPLACE(S_EXP,CHR(10),'');
      --更新公式中的项对应的字段名
      S_EXP := F_EXPR_XLS2DB_VAL(S_EXP,IN_POLICY_ID);
      S_EXP := P_REPLACE_EXP_ITEM(IN_POLICY_ID,S_EXP,'VALUE');
      --处理客户分类
      S_EXP := REPLACE(S_EXP,'[客户分类]','CUSTOMER_TYPE');
      S_STEP := '执行公式，编码:' || R_DEFINE.DEFINE_CODE;
      --按公式更新数据
      S_SQL := 'UPDATE T_POL_POLICY_RESULT_ITEM'
        || ' SET VALUE' || TRIM(TO_CHAR(N_I,'00'))
        || ' = (' || S_EXP || ')'
        || S_WHERE;
      --执行更新语句
      N_CUR := DBMS_SQL.OPEN_CURSOR;
      DBMS_SQL.PARSE(N_CUR, S_SQL, DBMS_SQL.NATIVE);
      N_ROW := DBMS_SQL.EXECUTE(N_CUR);
      DBMS_SQL.CLOSE_CURSOR(N_CUR);
      IF R_DEFINE.DEFINE_CODE = S_RESULT_DEFINE_CODE THEN
        S_FIELD := 'VALUE' || TRIM(TO_CHAR(N_I,'00'));
      END IF;
    END LOOP;
    
    --对于公式中不包含应计返利项，则直接获取
    IF S_FIELD IS NULL THEN
      S_STEP := '获取应计返利字段';
      SELECT
        COUNT(*)
      INTO
        N_I
      FROM
        T_POL_POLICY_DEFINE
      WHERE
        POLICY_ID = IN_POLICY_ID
        AND DEFINE_CODE <= S_RESULT_DEFINE_CODE;
      S_FIELD := 'VALUE' || TRIM(TO_CHAR(N_I,'00'));
    END IF;
    
    --更新应计返利金额
    S_STEP := '更新应计返利金额';
    S_SQL := 'UPDATE T_POL_POLICY_RESULT_ITEM'
      || ' SET RECKON_AMOUNT=ROUND(' || S_FIELD || ',2)'
      || ',RESULT_AMOUNT=ROUND(' || S_FIELD || ',2)'
      || ',LAST_UPDATED_BY=''' || IS_USER_ID || ''''
      || ',LAST_UPDATE_DATE=SYSDATE'
      || S_WHERE;
    N_CUR := DBMS_SQL.OPEN_CURSOR;
    DBMS_SQL.PARSE(N_CUR, S_SQL, DBMS_SQL.NATIVE);
    N_ROW := DBMS_SQL.EXECUTE(N_CUR);
    DBMS_SQL.CLOSE_CURSOR(N_CUR);

    --将四舍五入的差异金额更新到最大金额中
    --循环取出有差异的数据
    IF OS_MESSAGE = 'OK' THEN
      S_STEP := '处理差异';
      FOR R_RESULT_DEF IN
      (
        SELECT
          R.RESULT_ID
          ,R.ACCOUNT_ID
          ,T.SUM_AMOUNT
          ,R.RECKON_AMOUNT - T.SUM_AMOUNT DEF_AMOUNT
          ,T.MAX_AMOUNT
        FROM
          T_POL_POLICY_RESULT R
          ,(
            SELECT
              ACCOUNT_ID
              ,SUM(RECKON_AMOUNT) SUM_AMOUNT
              ,MAX(RECKON_AMOUNT) MAX_AMOUNT
            FROM
              T_POL_POLICY_RESULT_ITEM
            WHERE
              POLICY_ID = IN_POLICY_ID
              AND RESULT_DATE = ID_RESULT_DATE
            GROUP BY
              ACCOUNT_ID
          ) T
        WHERE
          R.ACCOUNT_ID = T.ACCOUNT_ID
          AND R.POLICY_ID = IN_POLICY_ID
          AND R.RESULT_DATE = ID_RESULT_DATE
          AND R.RECKON_AMOUNT <> T.SUM_AMOUNT
          AND T.SUM_AMOUNT <> 0
      )
      LOOP
        N_DEF_AMOUNT := R_RESULT_DEF.DEF_AMOUNT;
        N_MAX_AMOUNT := R_RESULT_DEF.MAX_AMOUNT;
        --对于差异金额大于或等于1，则按金额比例分摊
        IF N_DEF_AMOUNT >= 1 OR N_DEF_AMOUNT <= -1 THEN
          UPDATE
            T_POL_POLICY_RESULT_ITEM
          SET
            RECKON_AMOUNT = RECKON_AMOUNT+ROUND(N_DEF_AMOUNT*RECKON_AMOUNT/R_RESULT_DEF.SUM_AMOUNT,2)
          WHERE
            RESULT_ID = R_RESULT_DEF.RESULT_ID
            AND ACCOUNT_ID = R_RESULT_DEF.ACCOUNT_ID
            AND NVL(RECKON_AMOUNT,0) <> 0;
          
          --取出更新后的剩余差异，及最大值
          SELECT
            R.RECKON_AMOUNT - T.SUM_AMOUNT DEF_AMOUNT
            ,T.MAX_AMOUNT
          INTO
            N_DEF_AMOUNT
            ,N_MAX_AMOUNT
          FROM
            T_POL_POLICY_RESULT R
            ,(
              SELECT
                ACCOUNT_ID
                ,SUM(RECKON_AMOUNT) SUM_AMOUNT
                ,MAX(RECKON_AMOUNT) MAX_AMOUNT
              FROM
                T_POL_POLICY_RESULT_ITEM
              WHERE
                POLICY_ID = IN_POLICY_ID
                AND RESULT_DATE = ID_RESULT_DATE
                AND ACCOUNT_ID = R_RESULT_DEF.ACCOUNT_ID
            ) T
          WHERE
            R.ACCOUNT_ID = R_RESULT_DEF.ACCOUNT_ID
            AND R.POLICY_ID = IN_POLICY_ID
            AND R.RESULT_DATE = ID_RESULT_DATE;
            
        END IF;
        --将剩余差额更新到最大值的产品明细中
        IF N_DEF_AMOUNT <> 0 THEN
          UPDATE
            T_POL_POLICY_RESULT_ITEM
          SET
            RECKON_AMOUNT = RECKON_AMOUNT+N_DEF_AMOUNT
          WHERE
            RESULT_ID = R_RESULT_DEF.RESULT_ID
            AND ACCOUNT_ID = R_RESULT_DEF.ACCOUNT_ID
            AND RECKON_AMOUNT = N_MAX_AMOUNT
            AND ROWNUM = 1;
        END IF;
        --重新更新实际返利金额
        UPDATE
          T_POL_POLICY_RESULT_ITEM
        SET
          RESULT_AMOUNT = RECKON_AMOUNT
          ,LAST_UPDATED_BY = IS_USER_ID
          ,LAST_UPDATE_DATE = SYSDATE
        WHERE
          RESULT_ID = R_RESULT_DEF.RESULT_ID
          AND ACCOUNT_ID = R_RESULT_DEF.ACCOUNT_ID
          AND NVL(RECKON_AMOUNT,0) <> NVL(RESULT_AMOUNT,0);

      END LOOP;
      
    END IF;
      
  EXCEPTION
    WHEN OTHERS THEN
      OS_MESSAGE := '设置产品明细结果中的公式值-' || S_STEP || '(政策ID=' || TO_CHAR(IN_POLICY_ID) || ')！' || SQLERRM;
  END P_SET_ITEM_DETAIL_EXP_VAL;

  -----------------------------------------------------------------------------
  --  设置报表定义                                                   --
  -----------------------------------------------------------------------------
  PROCEDURE P_SET_RPT_DEFINE
  (
    IN_POLICY_ID              IN NUMBER   --政策算法定义ID
    ,IS_USER_ID               IN VARCHAR2 --用户账号
    ,OS_MESSAGE               OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  ) IS
    N_RPT_USER_DEFINE_ID     NUMBER;
    S_RPT_CODE               VARCHAR2(40);
    S_RPT_NAME               VARCHAR2(300);
    N_CNT                    NUMBER;
    N_NEW_CNT                NUMBER;
    N_I                      NUMBER;
    S_SQL                    VARCHAR2(4000);
    S_STEP                   VARCHAR2(40);
    B_CHANGED                BOOLEAN;
  BEGIN
    OS_MESSAGE := 'OK';

    S_RPT_CODE := 'POL' || TO_CHAR(IN_POLICY_ID); 
    --检查是否存在对应的定义
    S_STEP := '检查报表定义';
    BEGIN
      SELECT
        RPT_USER_DEFINE_ID
      INTO
        N_RPT_USER_DEFINE_ID
      FROM
        T_BD_RPT_USER_DEFINE
      WHERE
        RPT_CODE = S_RPT_CODE;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        N_RPT_USER_DEFINE_ID := 0;
    END;
    
    --获取政策名称
    S_STEP := '获取政策名称';
    SELECT
      NVL(P2.POLICY_NUMBER,P1.POLICY_NUMBER) || ' ' || DECODE(P1.CALCULATE_GROUP_NAME,NULL,NULL,'—' || P1.CALCULATE_GROUP_NAME)
    INTO
      S_RPT_NAME
    FROM
      T_POL_POLICY P1
      ,T_POL_POLICY P2
    WHERE
      P1.PARENT_POLICY_ID = P2.POLICY_ID(+)
      AND P1.POLICY_ID = IN_POLICY_ID;
    
    --存在对应定义，则检查是否一致
    IF N_RPT_USER_DEFINE_ID > 0 THEN
      --取出报表定义的项数
      S_STEP := '取报表定义项数';
      SELECT
        COUNT(*)
      INTO
        N_CNT
      FROM
        T_BD_RPT_USER_DEFINE_FIELD
      WHERE
        RPT_USER_DEFINE_ID = N_RPT_USER_DEFINE_ID
        AND ORDER_CODE >= '11';
      
      --取出政策算法中的项数
      S_STEP := '取算法定义项数';
      SELECT
        COUNT(*)
      INTO
        N_NEW_CNT
      FROM
        T_POL_POLICY_DEFINE
      WHERE
        POLICY_ID = IN_POLICY_ID;
      
      --报表项数相同则检查内容是否一致
      IF N_CNT = N_NEW_CNT THEN
        S_STEP := '检查内容一致性';
        SELECT
          COUNT(*)
        INTO
          N_CNT
        FROM
          T_BD_RPT_USER_DEFINE_FIELD F
          ,(
            SELECT
              ROWNUM ROW_NUM
              ,DEFINE_NAME
            FROM
              (
                SELECT
                  DEFINE_NAME
                FROM
                  T_POL_POLICY_DEFINE
                WHERE
                  POLICY_ID = IN_POLICY_ID
                ORDER BY
                  DEFINE_CODE
              )
          ) D
        WHERE
          F.RPT_FIELD_NAME = 'VALUE' || TRIM(TO_CHAR(D.ROW_NUM,'00'))
          AND F.RPT_FIELD_ALIAS = D.DEFINE_NAME
          AND F.RPT_USER_DEFINE_ID = N_RPT_USER_DEFINE_ID
          AND F.ORDER_CODE >= '11';
        B_CHANGED := (N_CNT <> N_NEW_CNT);
      ELSE
        B_CHANGED := TRUE;
      END IF;
    ELSE
      B_CHANGED := TRUE;
    END IF;
      
    --不一致则删除现有定义
    IF B_CHANGED THEN
      IF N_RPT_USER_DEFINE_ID > 0 THEN
        S_STEP := '删除现有定义';
        DELETE FROM
          T_BD_RPT_USER_DEFINE_PARAM
        WHERE
          RPT_USER_DEFINE_ID = N_RPT_USER_DEFINE_ID;
        DELETE FROM
          T_BD_RPT_USER_DEFINE_FIELD
        WHERE
          RPT_USER_DEFINE_ID = N_RPT_USER_DEFINE_ID;
      END IF;
      --获取报表SQL
      S_STEP := '获取报表SQL';
      S_SQL := 'SELECT R.CUSTOMER_CODE,R.CUSTOMER_NAME,R.SALES_CENTER_CODE,R.SALES_CENTER_NAME,R.ACCOUNT_ID,I.ITEM_CODE,I.ITEM_NAME,RI.RECKON_AMOUNT,RI.ADJUST_AMOUNT,RI.RESULT_AMOUNT';
      N_I := 0;
      FOR R_FIELD IN
      (
        SELECT
          DEFINE_CODE
        FROM
          T_POL_POLICY_DEFINE
        WHERE
          POLICY_ID = IN_POLICY_ID
        ORDER BY
          DEFINE_CODE
      )
      LOOP
        N_I := N_I + 1;
        S_SQL := S_SQL || ',RI.VALUE' || TRIM(TO_CHAR(N_I,'00'));
      END LOOP;
      S_SQL := S_SQL || ' FROM T_POL_POLICY_RESULT R,T_POL_POLICY_RESULT_ITEM RI,T_BD_ITEM I'
        || ' WHERE R.RESULT_ID = RI.RESULT_ID'
        || ' AND RI.ITEM_ID = I.ITEM_ID'
        || ' AND R.POLICY_ID = ' || TO_CHAR(IN_POLICY_ID)
        || ' AND {# R.RESULT_DATE = TO_DATE($resultDate,''YYYY-MM-DD'') #}'
        || ' AND {# R.ACCOUNT_ID = $accountId #}';
      
      --插入新的报表定义
      IF N_RPT_USER_DEFINE_ID = 0 THEN
        --获取序列值
        S_STEP := '获取序列值';
        SELECT
          S_BD_RPT_USER_DEFINE.NEXTVAL
        INTO
          N_RPT_USER_DEFINE_ID
        FROM
          DUAL;

        S_STEP := '插入报表定义';
        INSERT INTO T_BD_RPT_USER_DEFINE
        (
          RPT_USER_DEFINE_ID
          ,RPT_CODE
          ,RPT_NAME
          ,RPT_TITLE
          ,RPT_SQL
          ,QUERY_CODE
          ,CAN_MODIFY_FLAG
          ,CREATED_BY
          ,CREATION_DATE
          ,LAST_UPDATED_BY
          ,LAST_UPDATE_DATE
          ,VERSION
          ,SOURCE_BILL_ID
        )
        VALUES
        (
          N_RPT_USER_DEFINE_ID --RPT_USER_DEFINE_ID
          ,S_RPT_CODE --RPT_CODE
          ,S_RPT_NAME --RPT_NAME
          ,S_RPT_NAME --RPT_TITLE
          ,S_SQL --RPT_SQL
          ,NULL --QUERY_CODE
          ,'N' --CAN_MODIFY_FLAG
          ,IS_USER_ID --CREATED_BY
          ,SYSDATE --CREATION_DATE
          ,IS_USER_ID --LAST_UPDATED_BY
          ,SYSDATE --LAST_UPDATE_DATE
          ,'0' --VERSION
          ,IN_POLICY_ID --SOURCE_BILL_ID
        );
      ELSE
        --更新报表定义
        S_STEP := '更新报表定义';
        UPDATE
          T_BD_RPT_USER_DEFINE
        SET
          RPT_CODE = S_RPT_CODE
          ,RPT_NAME = S_RPT_NAME
          ,RPT_TITLE = S_RPT_NAME
          ,RPT_SQL = S_SQL
          ,LAST_UPDATED_BY = IS_USER_ID
          ,LAST_UPDATE_DATE = SYSDATE
        WHERE
          RPT_USER_DEFINE_ID = N_RPT_USER_DEFINE_ID;
      END IF;
      
      --插入报表参数（固定内容，从约定的ID中复制）
      INSERT INTO T_BD_RPT_USER_DEFINE_PARAM
      (
        RPT_PARAM_ID
        ,RPT_USER_DEFINE_ID
        ,RPT_PARAM_CODE
        ,RPT_PARAM_NAME
        ,DATA_TYPE
        ,CREATED_BY
        ,CREATION_DATE
        ,LAST_UPDATED_BY
        ,LAST_UPDATE_DATE
        ,VERSION
      )
      SELECT
        S_BD_RPT_USER_DEFINE_PARAM.NEXTVAL RPT_PARAM_ID
        ,N_RPT_USER_DEFINE_ID RPT_USER_DEFINE_ID
        ,RPT_PARAM_CODE
        ,RPT_PARAM_NAME
        ,DATA_TYPE
        ,IS_USER_ID CREATED_BY
        ,SYSDATE CREATION_DATE
        ,IS_USER_ID LAST_UPDATED_BY
        ,SYSDATE LAST_UPDATE_DATE
        ,0 VERSION
      FROM
        T_BD_RPT_USER_DEFINE_PARAM
      WHERE
        RPT_USER_DEFINE_ID = 0;
      
      --插入报表定义项（固定内容，从约定的ID中复制）
      S_STEP := '写报表固定内容';
      INSERT INTO T_BD_RPT_USER_DEFINE_FIELD
      (
        RPT_FIELD_ID
        ,RPT_USER_DEFINE_ID
        ,ORDER_CODE
        ,RPT_FIELD_NAME
        ,RPT_FIELD_ALIAS
        ,RPT_FIELD_SIZE
        ,RPT_FIELD_GROUP
        ,DATA_TYPE
        ,DISPLAY_FORMAT
        ,CREATED_BY
        ,CREATION_DATE
        ,LAST_UPDATED_BY
        ,LAST_UPDATE_DATE
        ,VERSION
      )
      SELECT
        S_BD_RPT_USER_DEFINE_FIELD.NEXTVAL RPT_FIELD_ID
        ,N_RPT_USER_DEFINE_ID RPT_USER_DEFINE_ID
        ,ORDER_CODE
        ,RPT_FIELD_NAME
        ,RPT_FIELD_ALIAS
        ,RPT_FIELD_SIZE
        ,RPT_FIELD_GROUP
        ,DATA_TYPE
        ,DISPLAY_FORMAT
        ,IS_USER_ID CREATED_BY
        ,SYSDATE CREATION_DATE
        ,IS_USER_ID LAST_UPDATED_BY
        ,SYSDATE LAST_UPDATE_DATE
        ,0 VERSION
      FROM
        T_BD_RPT_USER_DEFINE_FIELD
      WHERE
        RPT_USER_DEFINE_ID = 0;
      
      --补充算法定义的项
      S_STEP := '补充算法定义的项';
      INSERT INTO T_BD_RPT_USER_DEFINE_FIELD
      (
        RPT_FIELD_ID
        ,RPT_USER_DEFINE_ID
        ,ORDER_CODE
        ,RPT_FIELD_NAME
        ,RPT_FIELD_ALIAS
        ,RPT_FIELD_SIZE
        ,RPT_FIELD_GROUP
        ,DATA_TYPE
        ,DISPLAY_FORMAT
        ,CREATED_BY
        ,CREATION_DATE
        ,LAST_UPDATED_BY
        ,LAST_UPDATE_DATE
        ,VERSION
      )
      SELECT
        S_BD_RPT_USER_DEFINE_FIELD.NEXTVAL RPT_FIELD_ID
        ,N_RPT_USER_DEFINE_ID RPT_USER_DEFINE_ID
        ,TO_CHAR(ROWNUM+10) ORDER_CODE
        ,'VALUE' || TRIM(TO_CHAR(ROWNUM,'00'))  RPT_FIELD_NAME
        ,RPT_FIELD_ALIAS
        ,80 RPT_FIELD_SIZE
        ,NULL RPT_FIELD_GROUP
        ,'N' DATA_TYPE
        ,'#,###' DISPLAY_FORMAT
        ,IS_USER_ID CREATED_BY
        ,SYSDATE CREATION_DATE
        ,IS_USER_ID LAST_UPDATED_BY
        ,SYSDATE LAST_UPDATE_DATE
        ,0 VERSION
      FROM
        (
          SELECT
            DEFINE_CODE
            ,DEFINE_NAME RPT_FIELD_ALIAS
          FROM
            T_POL_POLICY_DEFINE
          WHERE
            POLICY_ID = IN_POLICY_ID
          ORDER BY
            DEFINE_CODE
        );
    END IF;
    

  EXCEPTION
    WHEN OTHERS THEN
      OS_MESSAGE := '设置自定义报表-' || S_STEP || '(政策ID=' || TO_CHAR(IN_POLICY_ID) || ')！' || SQLERRM;
  END P_SET_RPT_DEFINE;

  -----------------------------------------------------------------------------
  --  生成产品明细计算结果                                                   --
  -----------------------------------------------------------------------------
  PROCEDURE P_POLICY_CAL_ITEM_DETAIL(
    IN_POLICY_ID               IN  NUMBER   --政策ID
    ,ID_RESULT_DATE            IN  DATE     --报表日期
    ,IN_ENTITY_ID              IN  NUMBER   --主体ID
    ,IS_USER_ID                IN  VARCHAR2 --用户账号
    ,OS_MESSAGE                OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  )
  IS
    --政策计算项目(非公式)
    CURSOR C_DEFINE_LIST1 IS
      SELECT PD.DEFINE_ID
           , PD.DEFINE_CODE
           , PD.DEFINE_NAME
           , PD.GET_VAL_TYPE
           , PD.PRIOR_LEVEL
        FROM T_POL_POLICY_DEFINE PD
       WHERE PD.POLICY_ID = IN_POLICY_ID
         AND PD.GET_VAL_TYPE <> '2'
       ORDER BY PD.PRIOR_LEVEL, PD.DEFINE_CODE;
    R_DEFINE_LIST1 C_DEFINE_LIST1%ROWTYPE;

    N_CNT NUMBER;
    B_TO_ITEM BOOLEAN := FALSE;
    B_HAVE_EXP BOOLEAN := FALSE;
    S_STR VARCHAR2(4000);
    S_CAL_ITEM_LIST VARCHAR2(500);  --记录用于计算产品明细的项目
    S_STEP VARCHAR2(60);
  BEGIN
    OS_MESSAGE := 'OK';
    --检查是否存在分解语义参数
    SELECT
      COUNT(*)
    INTO
      N_CNT
    FROM
      T_BD_PARAM_LIST L
      ,T_BD_PARAM_ENTITY E
    WHERE
      L.PARAM_LIST_ID = E.PARAM_LIST_ID
      AND L.PARAM_CODE = 'POL_SPLIT_SEM_CODE'
      AND E.ENTITY_ID = IN_ENTITY_ID;
    
    --存在主体参数才处理产品明细计算结果
    IF N_CNT > 0 THEN
      SAVEPOINT SP_POLICY_CAL_ITEM_DETAIL;
      --1）	按政策ID、统计日期删除原有产品明细计算结果（T_POL_POLICY_RESULT_ITEM），只删除未生成审批记录的数据。
      S_STEP := '删除原有产品明细计算结果';
      DELETE FROM
        T_POL_POLICY_RESULT_ITEM I
      WHERE
        POLICY_ID = IN_POLICY_ID
        AND NOT EXISTS(
          SELECT
            1
          FROM
            T_POL_POLICY_RESULT R
          WHERE
            R.RESULT_ID = I.RESULT_ID
            AND R.RESULT_CHK_ID IS NOT NULL
        );
          
      --2）	根据政策ID参数获取对应的算法定义，从算法定义（T_POL_POLICY_DEFINE）中检查是否存在有产品的语义，且该语义应用到运算公式中，处理后续步骤。
      --循环取出算法中的语义，记录有产品明细的语义
      S_STEP := '检查是否需生成产品明细';
      FOR C_DEFINE IN
      (
        SELECT
          D.DEFINE_CODE
          ,S.GET_VAL_SQL
        FROM
          T_POL_POLICY_DEFINE D
          ,T_POL_SEMANTIC S
        WHERE
          D.SEM_CODE = S.SEMANTIC_CODE
          AND D.POLICY_ID = IN_POLICY_ID
          AND D.GET_VAL_TYPE = '1'
          AND S.ENTITY_ID = IN_ENTITY_ID
      )
      LOOP
        --检查是否存在产品信息，存在则检查是否应用于计算
        IF F_CHECK_SELECT_FIELD(C_DEFINE.GET_VAL_SQL,'ITEM_ID') THEN
          S_CAL_ITEM_LIST := S_CAL_ITEM_LIST || '[' || C_DEFINE.DEFINE_CODE || ']';
          IF NOT B_TO_ITEM THEN
            --循环取出包含当前语义值的公式，检查是否用于计算（非只用于判断）
            FOR C_DEF IN
            (
              SELECT
                CAL_EXP
              FROM
                T_POL_POLICY_DEFINE
              WHERE
                POLICY_ID = IN_POLICY_ID
                AND GET_VAL_TYPE = '2'
            )
            LOOP
              S_STR := C_DEF.CAL_EXP;
              S_STR := REPLACE(S_STR,CHR(13),'');
              S_STR := REPLACE(S_STR,CHR(10),'');
              S_STR := F_GET_EXP_NO_IF(TRIM(S_STR));
              --检查包含产品明细的项是否存在于计算公式中
              IF INSTR(S_STR,'['||C_DEFINE.DEFINE_CODE||']') > 0 THEN
                B_TO_ITEM := TRUE;
                EXIT;
              END IF;
              B_HAVE_EXP := TRUE;
            END LOOP;
            IF NOT B_HAVE_EXP THEN
              --没有定义公式，则认为要分摊产品明细
              B_TO_ITEM := TRUE;
            END IF;
          END IF;
        END IF;
      END LOOP;
      
      --需分解到产品明细，则处理产品明细计算结算的生成
      IF B_TO_ITEM THEN
        S_STEP := '生成产品计算结果临时表';
        --3）	按算法优先级顺序，循环取出算法项，处理非公式计算。
        FOR R_DEFINE_LIST1 IN C_DEFINE_LIST1
        LOOP
          IF R_DEFINE_LIST1.GET_VAL_TYPE = '1' AND INSTR(S_CAL_ITEM_LIST,'['||R_DEFINE_LIST1.DEFINE_CODE||']') > 0 THEN  --语义
            --a）	对于存在产品的语义，则按账户、产品汇总生成产品计算结果内容临时表T_POL_RESULT_ITEM_DETAIL_TMP；
            P_SET_ITEM_DETAIL_SEM_SQL(R_DEFINE_LIST1.DEFINE_ID,IN_ENTITY_ID,ID_RESULT_DATE,IS_USER_ID,OS_MESSAGE);
          ELSE
            --b）	对于不存在产品的语义(或：外部数据、调整项)，则取出主体参数“POL_SHARE_ITEM_SEMANTIC”对应的值，再从语义表中获取SQL，拼接成更新产品计算结果表内容。
            P_SET_ITEM_DETAIL_SPLIT(R_DEFINE_LIST1.DEFINE_ID,IN_ENTITY_ID,ID_RESULT_DATE,IS_USER_ID,OS_MESSAGE);
          END IF;
          EXIT WHEN OS_MESSAGE <> 'OK';
        END LOOP;
        
        --4）  将产品明细临时表内容转到产品明细结果表中。 
        IF OS_MESSAGE = 'OK' THEN
          S_STEP := '生成产品计算结果正式表';
          P_TO_ITEM_DETAIL(IN_POLICY_ID,ID_RESULT_DATE,IS_USER_ID,OS_MESSAGE); 
        END IF;
        
        --5）  按算法优先级顺序，循环取出算法项，处理公式计算。  
        IF OS_MESSAGE = 'OK' THEN 
          S_STEP := '更新公式值';
          P_SET_ITEM_DETAIL_EXP_VAL(IN_POLICY_ID,ID_RESULT_DATE,IS_USER_ID,OS_MESSAGE);
        END IF;
        
        --6）	检查当前算法分组的算法定义与报表定义是否一致，不一致则更新报表定义。
        IF OS_MESSAGE = 'OK' THEN 
          S_STEP := '更新报表定义';
          P_SET_RPT_DEFINE(IN_POLICY_ID,IS_USER_ID,OS_MESSAGE);
        END IF;

      END IF;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK TO SAVEPOINT SP_POLICY_CAL_ITEM_DETAIL;
      OS_MESSAGE := '调用生成产品明细计算结果过程出错！(POLICY_ID=' || TO_CHAR(IN_POLICY_ID) || ',' || S_STEP || ')' || SQLERRM;
  END P_POLICY_CAL_ITEM_DETAIL;

  -----------------------------------------------------------------------------
  --  政策计算结果明细信息更新
  --取出计算方法定义的相关信息进行更新
  --补充缺少的数据  
  -----------------------------------------------------------------------------
  PROCEDURE P_UPDATE_RESULT_VAL
  (
    IN_POLICY_ID          IN NUMBER    --政策ID
    ,ID_RESULT_DATE       IN DATE      --报表日期
    ,IS_USER_ID           IN VARCHAR2  --用户账号
    ,OS_MESSAGE          OUT VARCHAR2  --成功则返回“OK”，否则返回出错信息
  ) IS
    S_SQL       VARCHAR2(4000);
    N_INDEX     NUMBER := 0;
    N_CUR       NUMBER;
    N_ROW       NUMBER;
  BEGIN
    OS_MESSAGE := 'OK';
    
    S_SQL := 'UPDATE T_POL_POLICY_RESULT SET ';
    --循环取算法定义
    FOR R_DEFINE IN
    (
      SELECT
        DEFINE_ID
      FROM
        T_POL_POLICY_DEFINE
      WHERE
        POLICY_ID = IN_POLICY_ID
      ORDER BY
        DEFINE_CODE
    )
    LOOP
      N_INDEX := N_INDEX+1;
      --拼接更新语句
      S_SQL := 'UPDATE T_POL_POLICY_RESULT R SET VALUE' || TRIM(TO_CHAR(N_INDEX,'00'))
        || '=(SELECT RESULT_VALUE FROM T_POL_POLICY_RESULT_DETAIL D WHERE D.POLICY_ID =' || TO_CHAR(IN_POLICY_ID)
        || ' AND D.DEFINE_ID=' || TO_CHAR(R_DEFINE.DEFINE_ID) 
        || ' AND D.ACCOUNT_ID=R.ACCOUNT_ID' 
        || ' AND RESULT_DATE=TO_DATE(''' || TO_CHAR(ID_RESULT_DATE,'YYYY-MM-DD') || ''',''YYYY-MM-DD'')'
        || ' AND NVL(D.TYPE01,'' '')=NVL(R.TYPE01,'' '')'
        || ' AND NVL(D.TYPE02,'' '')=NVL(R.TYPE02,'' '')'
        || ' AND NVL(D.TYPE03,'' '')=NVL(R.TYPE03,'' '')'
        || ' AND NVL(D.TYPE04,'' '')=NVL(R.TYPE04,'' '')'
        || ' AND NVL(D.TYPE05,'' '')=NVL(R.TYPE05,'' '')'
        || ') WHERE POLICY_ID=' || TO_CHAR(IN_POLICY_ID)
        || ' AND RESULT_DATE=TO_DATE(''' || TO_CHAR(ID_RESULT_DATE,'YYYY-MM-DD') || ''',''YYYY-MM-DD'')';

      --执行更新语句
      N_CUR := DBMS_SQL.OPEN_CURSOR;
      DBMS_SQL.PARSE(N_CUR, S_SQL, DBMS_SQL.NATIVE);
      N_ROW := DBMS_SQL.execute(N_CUR);
      DBMS_SQL.CLOSE_CURSOR(N_CUR);
    END LOOP;

  EXCEPTION
    WHEN OTHERS THEN
      OS_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_POL_CAL.P_UPDATE_RESULT_VAL','100','更新计算列出错！(INDEX=' || TO_CHAR(N_INDEX) || ')！SQL=' || S_SQL || '！' || SQLERRM);
      OS_MESSAGE := '更新计算列出错！(INDEX=' || TO_CHAR(N_INDEX) || ')！SQL=' || S_SQL || '！' || SQLERRM;
  END P_UPDATE_RESULT_VAL;

  -----------------------------------------------------------------------------
  --  汇总政策结果计算过程
  --  程序逻辑：将报表结果明细表中的数据，按客户转换为政策报表的数据
  --  需按账户（客户+中心）处理数据汇总                                      
  -----------------------------------------------------------------------------
  PROCEDURE P_POLICY_CAL_SUM(IN_POLICY_ID              IN NUMBER   --政策ID
                            ,ID_RESULT_DATE            IN DATE     --报表日期
                            ,IS_RESULT_DEFINE_CODE     IN VARCHAR2 --应计返利项目代码
                            ,IS_USER_ID                IN VARCHAR2 --用户账号
                            ,OS_REPORT_ERR_MSG        OUT VARCHAR2 --报表出错信息，没有出错则为NULL
                            ,OS_MESSAGE               OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
                            ) IS
    --报表明细
    CURSOR C_RESULT_DETAIL IS
      SELECT T.ACCOUNT_ID
           , T.DEFINE_CODE
           , T.DB_EXPRESS_ERR
        FROM T_POL_POLICY_RESULT_DETAIL T
       WHERE T.POLICY_ID = IN_POLICY_ID
         AND T.RESULT_DATE = ID_RESULT_DATE
       ORDER BY T.ACCOUNT_ID, T.DEFINE_CODE;
    R_RESULT_DETAIL C_RESULT_DETAIL%ROWTYPE;

    N_MAX_RESULT_ID           NUMBER;
    N_ACCOUNT_ID              NUMBER;
    S_ERROR_DESC              VARCHAR2(4000);
    S_STEP                    VARCHAR2(40);
  BEGIN
    OS_MESSAGE := 'OK';
    SAVEPOINT SP_POLICY_CAL_SUM;

    --删除已返利金额为0，并且客户分类中不存在的客户
    S_STEP := '删除已返利金额为0的客户';
    DELETE
      FROM T_POL_POLICY_RESULT T
     WHERE T.POLICY_ID = IN_POLICY_ID
       AND T.RESULT_DATE = ID_RESULT_DATE
       AND NVL(T.REBATE_AMOUNT, 0) = 0
       AND NOT EXISTS(
         SELECT
           1
         FROM
           T_POL_POLICY_RESULT_DETAIL D
         WHERE
           D.POLICY_ID = IN_POLICY_ID
           AND D.RESULT_DATE = ID_RESULT_DATE
           AND D.ACCOUNT_ID = T.ACCOUNT_ID
           AND NVL(D.TYPE01,' ') = NVL(T.TYPE01,' ')
           AND NVL(D.TYPE02,' ') = NVL(T.TYPE02,' ')
           AND NVL(D.TYPE03,' ') = NVL(T.TYPE03,' ')
           AND NVL(D.TYPE04,' ') = NVL(T.TYPE04,' ')
           AND NVL(D.TYPE05,' ') = NVL(T.TYPE05,' ')
       );
       --AND NOT EXISTS(SELECT 1
       --                 FROM T_POL_POLICY_CUS_TYPE R
       --                WHERE T.POLICY_ID = R.POLICY_ID
       --                  AND T.ACCOUNT_ID = R.TAR_ACCOUNT_ID
       --              );

    --若已存在报表日期的记录，则清空应计返利金额
    S_STEP := '清空应计返利金额';
    UPDATE T_POL_POLICY_RESULT T
       SET T.RECKON_AMOUNT = NULL
         , T.ERROR_DESC = NULL
         , LAST_UPDATED_BY = IS_USER_ID
         , LAST_UPDATE_DATE = SYSDATE
     WHERE T.POLICY_ID = IN_POLICY_ID
       AND T.RESULT_DATE = ID_RESULT_DATE;

    --查找政策报表的最大ID值
    S_STEP := '取序列';
    SELECT S_POL_POLICY_RESULT.NEXTVAL
      INTO N_MAX_RESULT_ID
      FROM DUAL;

    --插入不存在报表日期的空记录
    S_STEP := '插入不存在报表日期的空记录';
    INSERT INTO T_POL_POLICY_RESULT
      (RESULT_ID,
       POLICY_ID,
       CUSTOMER_ID,
       CUSTOMER_CODE,
       CUSTOMER_NAME,
       SALES_CENTER_ID,
       SALES_CENTER_CODE,
       SALES_CENTER_NAME,
       ACCOUNT_ID,
       ACCOUNT_CODE,
       RESULT_DATE,
       CREATED_BY,
       CREATION_DATE,
       LAST_UPDATED_BY,
       LAST_UPDATE_DATE,
       TYPE01,
       TYPE02,
       TYPE03,
       TYPE04,
       TYPE05)
    SELECT S_POL_POLICY_RESULT.NEXTVAL
         , IN_POLICY_ID
         , C.CUSTOMER_ID
         , C.CUSTOMER_CODE
         , C.CUSTOMER_NAME
         , NVL(CEN.UNIT_ID, -1)
         , CEN.CODE
         , CEN.NAME
         , A.ACCOUNT_ID
         , A.ACCOUNT_CODE
         , ID_RESULT_DATE
         , IS_USER_ID
         , SYSDATE
         , IS_USER_ID
         , SYSDATE
         , PRD.TYPE01
         , PRD.TYPE02
         , PRD.TYPE03
         , PRD.TYPE04
         , PRD.TYPE05
      FROM T_POL_POLICY P
         , (SELECT DISTINCT ACCOUNT_ID
                 , TYPE01
                 , TYPE02
                 , TYPE03
                 , TYPE04
                 , TYPE05
              FROM T_POL_POLICY_RESULT_DETAIL
             WHERE POLICY_ID = IN_POLICY_ID
               AND RESULT_DATE = ID_RESULT_DATE) PRD
         , T_CUSTOMER_ACCOUNT A
         , T_CUSTOMER_ORG O
         , T_CUSTOMER_ACC_ORG_RELATION R
         , T_CUSTOMER_HEADER C
         , UP_ORG_UNIT CEN
     WHERE P.POLICY_ID = IN_POLICY_ID
       AND PRD.ACCOUNT_ID = A.ACCOUNT_ID
       AND R.ACCOUNT_ID = A.ACCOUNT_ID
       AND R.CUSTOMER_ORG_ID = O.CUSTOMER_ORG_ID
       AND A.CUSTOMER_ID = C.CUSTOMER_ID
       AND O.SALES_CENTER_ID = CEN.UNIT_ID(+)
       AND NOT EXISTS(SELECT 1
                        FROM T_POL_POLICY_RESULT R
                       WHERE R.POLICY_ID = P.POLICY_ID
                         AND R.ACCOUNT_ID = PRD.ACCOUNT_ID
                         AND R.RESULT_DATE = ID_RESULT_DATE
                         AND NVL(R.TYPE01,' ') = NVL(PRD.TYPE01,' ')
                         AND NVL(R.TYPE02,' ') = NVL(PRD.TYPE02,' ')
                         AND NVL(R.TYPE03,' ') = NVL(PRD.TYPE03,' ')
                         AND NVL(R.TYPE04,' ') = NVL(PRD.TYPE04,' ')
                         AND NVL(R.TYPE05,' ') = NVL(PRD.TYPE05,' '));
      
    --新插入的记录，获取上一次报表的调整金额、调整原因、已返利金额，并更新
    S_STEP := '获取上一次报表的调整金额';
    UPDATE T_POL_POLICY_RESULT T
       SET (T.ADJUST_AMOUNT, T.ADJUST_REASON, T.REBATE_AMOUNT, T.LAST_UPDATED_BY, LAST_UPDATE_DATE) 
         = (SELECT T2.ADJUST_AMOUNT, T2.ADJUST_REASON, DECODE(T2.POLICY_ORDER_LINE_ID,NULL,T2.REBATE_AMOUNT,NVL(T2.RECKON_AMOUNT,0) + NVL(T2.ADJUST_AMOUNT,0)), IS_USER_ID, SYSDATE
              FROM T_POL_POLICY_RESULT T2
             WHERE T2.POLICY_ID = IN_POLICY_ID
               AND T2.RESULT_DATE = (SELECT MAX(T3.RESULT_DATE)
                                       FROM T_POL_POLICY_RESULT T3
                                      WHERE T3.POLICY_ID = IN_POLICY_ID
                                        AND T3.RESULT_DATE < T.RESULT_DATE
                                        AND T3.ACCOUNT_ID = T.ACCOUNT_ID
                                    )
               AND T2.ACCOUNT_ID = T.ACCOUNT_ID
               AND NVL(T2.TYPE01,' ') = NVL(T.TYPE01,' ')
               AND NVL(T2.TYPE02,' ') = NVL(T.TYPE02,' ')
               AND NVL(T2.TYPE03,' ') = NVL(T.TYPE03,' ')
               AND NVL(T2.TYPE04,' ') = NVL(T.TYPE04,' ')
               AND NVL(T2.TYPE05,' ') = NVL(T.TYPE05,' ')
           )
     WHERE T.POLICY_ID = IN_POLICY_ID
       AND T.RESULT_DATE = ID_RESULT_DATE
       AND T.RESULT_ID > N_MAX_RESULT_ID;
      
    --更新报表明细的RESULT_ID
    S_STEP := '更新报表的RESULT_ID';
    UPDATE T_POL_POLICY_RESULT_DETAIL D
       SET D.RESULT_ID = (
                           SELECT R.RESULT_ID
                             FROM T_POL_POLICY_RESULT R
                            WHERE R.POLICY_ID = D.POLICY_ID
                              AND R.RESULT_DATE = D.RESULT_DATE
                              AND R.ACCOUNT_ID = D.ACCOUNT_ID
                              AND NVL(R.TYPE01,' ') = NVL(D.TYPE01,' ')
                              AND NVL(R.TYPE02,' ') = NVL(D.TYPE02,' ')
                              AND NVL(R.TYPE03,' ') = NVL(D.TYPE03,' ')
                              AND NVL(R.TYPE04,' ') = NVL(D.TYPE04,' ')
                              AND NVL(R.TYPE05,' ') = NVL(D.TYPE05,' ')
                         )
          ,LAST_UPDATED_BY = IS_USER_ID
          ,LAST_UPDATE_DATE = SYSDATE
     WHERE D.POLICY_ID = IN_POLICY_ID
       AND D.RESULT_DATE = ID_RESULT_DATE; 

    --更新报表的应计返利金额
    S_STEP := '更新报表的应计返利金额';
    UPDATE T_POL_POLICY_RESULT R
       SET R.RECKON_AMOUNT = (SELECT SUM(ROUND(D.RESULT_VALUE,2))
                                FROM T_POL_POLICY_RESULT_DETAIL D
                               WHERE D.POLICY_ID = R.POLICY_ID
                                 AND D.RESULT_DATE = R.RESULT_DATE
                                 AND D.DEFINE_CODE = IS_RESULT_DEFINE_CODE
                                 AND D.ACCOUNT_ID = R.ACCOUNT_ID
                                 AND D.RESULT_ID = R.RESULT_ID
                             )
     WHERE R.POLICY_ID = IN_POLICY_ID
       AND R.RESULT_DATE = ID_RESULT_DATE;

    --更新报表的限额 LIMIT_AMOUNT = RECKON_AMOUNT - REBATE_AMOUNT
    S_STEP := '更新报表的限额、总额';
    UPDATE T_POL_POLICY_RESULT R
       SET R.LIMIT_AMOUNT = RECKON_AMOUNT + NVL(ADJUST_AMOUNT,0) - NVL(REBATE_AMOUNT,0)
          ,TOTAL_AMOUNT = RECKON_AMOUNT + NVL(ADJUST_AMOUNT,0)
          ,RUN_REBATE_AMOUNT = RECKON_AMOUNT + NVL(ADJUST_AMOUNT,0) - NVL(REBATE_AMOUNT,0)
          ,LAST_UPDATED_BY = IS_USER_ID
          ,LAST_UPDATE_DATE = SYSDATE
     WHERE R.POLICY_ID = IN_POLICY_ID
       AND R.RESULT_DATE = ID_RESULT_DATE;

    --更新动态数值字段,循环政策算法定义，动态更新计算值到结果表中
    P_UPDATE_RESULT_VAL(IN_POLICY_ID,ID_RESULT_DATE,IS_USER_ID,OS_MESSAGE);
    
    IF OS_MESSAGE = 'OK' THEN
      --更新报表的出错信息
      S_STEP := '更新报表的出错信息';
      N_ACCOUNT_ID := NULL;
      --循环明细表，拼接客户对应的出错信息
      FOR R_RESULT_DETAIL IN C_RESULT_DETAIL
      LOOP
        IF (N_ACCOUNT_ID = R_RESULT_DETAIL.ACCOUNT_ID) THEN
          --同一客户，则继续拼接出错信息
          IF (R_RESULT_DETAIL.DB_EXPRESS_ERR IS NOT NULL) THEN
            S_ERROR_DESC := SUBSTR(NVL(S_ERROR_DESC, '') || '; ' || NVL(R_RESULT_DETAIL.DB_EXPRESS_ERR, ''), 1, 4000);
          END IF;
        ELSE
          --不同一客户，则保存之前客户的错误信息
          IF (N_ACCOUNT_ID IS NOT NULL) THEN
            UPDATE T_POL_POLICY_RESULT T
               SET T.ERROR_DESC = S_ERROR_DESC
                  ,LAST_UPDATED_BY = IS_USER_ID
                  ,LAST_UPDATE_DATE = SYSDATE
             WHERE T.POLICY_ID = IN_POLICY_ID
               AND T.RESULT_DATE = ID_RESULT_DATE
               AND T.ACCOUNT_ID = N_ACCOUNT_ID;
          END IF;
          --开始记录下一出错信息
          IF (R_RESULT_DETAIL.DB_EXPRESS_ERR IS NOT NULL) THEN
            S_ERROR_DESC := SUBSTR(NVL(R_RESULT_DETAIL.DB_EXPRESS_ERR, ''), 1, 4000);
          END IF;     
        END IF;
        --更新为当前客户
        IF (R_RESULT_DETAIL.DB_EXPRESS_ERR IS NOT NULL) THEN
          N_ACCOUNT_ID := R_RESULT_DETAIL.ACCOUNT_ID;
        END IF;
      END LOOP;

      --记录最后一个客户的错误信息
      IF (N_ACCOUNT_ID IS NOT NULL) THEN
        UPDATE T_POL_POLICY_RESULT T
           SET T.ERROR_DESC = S_ERROR_DESC
              ,LAST_UPDATED_BY = IS_USER_ID
              ,LAST_UPDATE_DATE = SYSDATE
         WHERE T.POLICY_ID = IN_POLICY_ID
           AND T.RESULT_DATE = ID_RESULT_DATE
           AND T.ACCOUNT_ID = N_ACCOUNT_ID;
        OS_REPORT_ERR_MSG := S_ERROR_DESC;
      ELSE
        OS_REPORT_ERR_MSG := NULL;
      END IF;
    END IF;

    IF (OS_MESSAGE <> 'OK') THEN
      ROLLBACK TO SAVEPOINT SP_POLICY_CAL_SUM;
    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK TO SAVEPOINT SP_POLICY_CAL_SUM;
      OS_MESSAGE := '政策结果汇总计算-' || S_STEP || '(POLICY_ID=' || TO_CHAR(IN_POLICY_ID) || ')出错：' || SQLERRM;
  END;

  -----------------------------------------------------------------------------
  --  政策结果计算过程                                                       --
  -----------------------------------------------------------------------------
  PROCEDURE P_POLICY_CALCULATE(IN_POLICY_ID              IN NUMBER   --政策ID
                              ,ID_RESULT_DATE            IN DATE     --报表日期
                              ,IS_USER_ID                IN VARCHAR2 --用户账号
                              ,IS_PRE_CALC               IN VARCHAR2 --试算标识（Y/N）
                              ,ON_PRE_CALC_AMOUNT       OUT NUMBER   --试算结果金额
                              ,OS_MESSAGE               OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
                              ) IS
    S_RESULT_DEFINE_CODE VARCHAR2(40);
    S_POLICY_NEW_STATUS VARCHAR2(40);
    S_RESULT_CHK_NUM VARCHAR2(32);
    S_REPORT_ERR_MSG VARCHAR2(4000);
    S_CALCULATE_GROUP_NAME VARCHAR2(100);
    
    N_RESULT_CHK_ID NUMBER;
    S_AUDIT_STATE VARCHAR2(32);
    N_ENTITY_ID NUMBER;
    N_CNT NUMBER;
    N_CNT_SEM_CAT1  NUMBER;
    N_CNT_SEM_CAT2  NUMBER;
    D_MAX_PRE_DATE DATE; --上次执行计算日期
  BEGIN
    OS_MESSAGE := 'OK';
    SAVEPOINT SP_POLICY_CALCULATE;

    --锁定记录，防止一条记录被多次操作。
    BEGIN
      SELECT RESULT_DEFINE_CODE
            ,ENTITY_ID
            ,CALCULATE_GROUP_NAME
        INTO S_RESULT_DEFINE_CODE
            ,N_ENTITY_ID
            ,S_CALCULATE_GROUP_NAME
        FROM T_POL_POLICY
       WHERE POLICY_ID = IN_POLICY_ID
         FOR UPDATE NOWAIT; 
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        OS_MESSAGE := '锁定政策不成功，请稍后再试！';
    END;
    
    --检查算法定义是否正确
    IF (OS_MESSAGE = 'OK') THEN
      P_DEFINE_CHECK(IN_POLICY_ID,OS_MESSAGE);
    END IF;

    --上次计算的结果不是'已作废'或者'已转返利'，不允许执行计算
    IF (OS_MESSAGE = 'OK') THEN
      BEGIN
        SELECT MAX(R.RESULT_DATE)
          INTO D_MAX_PRE_DATE
          FROM T_POL_POLICY_RESULT R
         WHERE R.POLICY_ID = IN_POLICY_ID
           AND R.RESULT_DATE < ID_RESULT_DATE;

        IF (D_MAX_PRE_DATE IS NOT NULL) THEN
          SELECT T2.RESULT_CHK_NUM
                ,T2.AUDIT_STATE
            INTO S_RESULT_CHK_NUM
                ,S_AUDIT_STATE
            FROM T_POL_POLICY_RESULT     T1
                ,T_POL_POLICY_RESULT_CHK T2
           WHERE T1.POLICY_ID = IN_POLICY_ID
             AND T1.RESULT_DATE = D_MAX_PRE_DATE
             AND T1.POLICY_ID = T2.POLICY_ID
             AND T1.RESULT_CHK_ID = T2.RESULT_CHK_ID
             AND ROWNUM = 1;
          IF (NOT (S_AUDIT_STATE = '2' OR S_AUDIT_STATE = '4')) THEN
            OS_MESSAGE := TO_CHAR(D_MAX_PRE_DATE, 'YYYY-MM-DD') || '已存在对应的计算结果(审批号:' || S_RESULT_CHK_NUM || ')不是‘已作废’或者‘已返利’，不能进行计算，请前先完成处理(作废或者转返利)！';
          END IF;
        END IF;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          NULL;
      END;
    END IF;

    --检查存在审批信息时是否允许执行重算
    IF (OS_MESSAGE = 'OK') THEN
      BEGIN
        SELECT T2.RESULT_CHK_ID
              ,T2.RESULT_CHK_NUM
              ,T2.AUDIT_STATE
          INTO N_RESULT_CHK_ID
              ,S_RESULT_CHK_NUM
              ,S_AUDIT_STATE
          FROM T_POL_POLICY_RESULT     T1
              ,T_POL_POLICY_RESULT_CHK T2
         WHERE T1.POLICY_ID = IN_POLICY_ID
          AND T1.RESULT_DATE = ID_RESULT_DATE
          AND T1.POLICY_ID = T2.POLICY_ID
          AND T1.RESULT_CHK_ID = T2.RESULT_CHK_ID
          AND ROWNUM = 1;
          
        IF (S_AUDIT_STATE = '5' OR S_AUDIT_STATE = '2') THEN --已录入、已作废状态，先删除政策结果和审批记录，然后重新计算
          DELETE FROM T_POL_POLICY_RESULT
           WHERE RESULT_CHK_ID = N_RESULT_CHK_ID;
          DELETE FROM T_POL_POLICY_RESULT_CHK
           WHERE RESULT_CHK_ID = N_RESULT_CHK_ID;
        ELSIF (S_AUDIT_STATE = '3') THEN --已驳回，不允许重复计算
          OS_MESSAGE := '当天已存在对应的计算结果(审批号:' || S_RESULT_CHK_NUM || ')已驳回，不能重算！如需重算请先作废对应的计算结果！';
        ELSIF (S_AUDIT_STATE = '8') THEN --已送审，不允许重复计算
          OS_MESSAGE := '当天已存在对应的计算结果(审批号:' || S_RESULT_CHK_NUM || ')已送审，不能重算！如需重算请先作废对应的计算结果！';
        ELSIF (S_AUDIT_STATE = '6') THEN --已审核，不允许重复计算
          OS_MESSAGE := '当天已存在对应的计算结果(审批号:' || S_RESULT_CHK_NUM || ')已审核，不能重算！如需重算请先作废对应的计算结果！';
        ELSIF (S_AUDIT_STATE = '4') THEN --已返利，不允许重复计算
          OS_MESSAGE := '当天已存在对应的计算结果(审批号:' || S_RESULT_CHK_NUM || ')已返利，不能重算！';
        END IF;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          NULL;
      END;
    END IF;
    
    --转换算法定义公式项的表达式（将Excel表达式转换为数据库表达式）
    IF (OS_MESSAGE = 'OK') THEN
      --采用自治事物，保证在其它过程出错的情况下公式转换内容得以保持
      P_DEFINE_TRANC(IN_POLICY_ID
                    ,IS_USER_ID
                    ,OS_MESSAGE);
    END IF;

    --初始计算结果数据
    IF (OS_MESSAGE = 'OK') THEN
      P_RESULT_INIT(IN_POLICY_ID
                   ,ID_RESULT_DATE
                   ,IS_USER_ID
                   ,OS_MESSAGE);
    END IF;

    --执行明细计算
    IF (OS_MESSAGE = 'OK') THEN
      P_POLICY_CAL_DETAIL(IN_POLICY_ID
                         ,ID_RESULT_DATE
                         ,IS_USER_ID
                         ,IS_PRE_CALC
                         ,OS_MESSAGE);
    END IF;

    --执行汇总计算
    IF (OS_MESSAGE = 'OK') THEN
      P_POLICY_CAL_SUM(IN_POLICY_ID
                      ,ID_RESULT_DATE
                      ,S_RESULT_DEFINE_CODE
                      ,IS_USER_ID
                      ,S_REPORT_ERR_MSG
                      ,OS_MESSAGE);
    END IF;
    
    --试算处理过程结束，统计试算结果金额
    IF (OS_MESSAGE = 'OK' AND IS_PRE_CALC = 'Y') THEN
      SELECT SUM(R.RECKON_AMOUNT)
        INTO ON_PRE_CALC_AMOUNT
        FROM T_POL_POLICY_RESULT R
       WHERE R.POLICY_ID = IN_POLICY_ID
         AND R.RESULT_DATE = ID_RESULT_DATE;
    END IF;

    --获取政策状态
    IF (OS_MESSAGE = 'OK' AND IS_PRE_CALC <> 'Y') THEN
      P_GET_POLICY_STATUS(IN_POLICY_ID
                         ,S_POLICY_NEW_STATUS
                         ,OS_MESSAGE);
    END IF;
    
    --生成产品明细结果
    IF (OS_MESSAGE = 'OK' AND IS_PRE_CALC <> 'Y') THEN
      P_POLICY_CAL_ITEM_DETAIL(IN_POLICY_ID,ID_RESULT_DATE,N_ENTITY_ID,IS_USER_ID,OS_MESSAGE);
    END IF;

    --更新政策表的报表日期
    IF (OS_MESSAGE = 'OK' AND IS_PRE_CALC <> 'Y') THEN
      /**
      * add by liangym2 政策计算根据算法语义的语义类型SEMANTIC_CATAGORY（码表：SEMANTIC_CATEGORY）
      */
      SELECT COUNT(DECODE(S.SEMANTIC_CATAGORY, '1', S.SEMANTIC_CATAGORY))
            ,COUNT(DECODE(S.SEMANTIC_CATAGORY, '2', S.SEMANTIC_CATAGORY))
        INTO N_CNT_SEM_CAT1, N_CNT_SEM_CAT2
        FROM T_POL_POLICY_DEFINE PD
       INNER JOIN T_POL_SEMANTIC S
          ON (S.SEMANTIC_CODE = PD.SEM_CODE AND N_ENTITY_ID = S.ENTITY_ID)
       WHERE PD.POLICY_ID = IN_POLICY_ID
         AND PD.GET_VAL_TYPE <> '2';

      --检查是否有计算结算，没有则于界面中显示“根据算法执行计算没有数据！”
      SELECT
        COUNT(*)
      INTO
        N_CNT
      FROM
        T_POL_POLICY_RESULT
      WHERE
        POLICY_ID = IN_POLICY_ID;

      --Success:成功;  Error:出错
      UPDATE T_POL_POLICY T
         SET T.REPORT_DATE = ID_RESULT_DATE
           , T.STATUS = NVL(S_POLICY_NEW_STATUS, T.STATUS)
           , T.REPORT_STATUS = DECODE(S_REPORT_ERR_MSG, NULL, 'Success', 'Error') 
           , T.REPORT_ERR_MSG = NVL(S_REPORT_ERR_MSG, DECODE(N_CNT, 0, '根据算法执行计算没有数据！', NULL))
           , T.CCS_STAT = (CASE WHEN 0 < N_CNT_SEM_CAT1 THEN 'Y' ELSE 'N' END)--分销统计
           , T.MMP_STAT = (CASE WHEN 0 < N_CNT_SEM_CAT2 THEN 'Y' ELSE 'N' END)--MMP统计
           , T.LAST_UPDATED_BY = IS_USER_ID
           , T.LAST_UPDATE_DATE = SYSDATE
           , T.VERSION = T.VERSION + 1
       WHERE T.POLICY_ID = IN_POLICY_ID;
 
      --更新返利申请单的计算预计兑现金额
      UPDATE T_POL_ORDER_HEADERS H
         SET EXPECTED_CASH_AMOUNT =
             (SELECT SUM(R.RECKON_AMOUNT)
                FROM T_POL_POLICY_RESULT R
               WHERE R.POLICY_ID = IN_POLICY_ID)
            ,LAST_UPDATED_BY      = IS_USER_ID
            ,LAST_UPDATE_DATE     = SYSDATE
            ,VERSION              = VERSION + 1
       WHERE H.POLICY_ID = IN_POLICY_ID;
    ELSIF (OS_MESSAGE <> 'OK') THEN
      ROLLBACK TO SAVEPOINT SP_POLICY_CALCULATE;
    END IF;
    
    --试算结束全部回滚
    IF IS_PRE_CALC = 'Y' THEN
      ROLLBACK TO SAVEPOINT SP_POLICY_CALCULATE;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK TO SAVEPOINT SP_POLICY_CALCULATE;
      OS_MESSAGE := '调用政策(' || S_CALCULATE_GROUP_NAME || ')计算过程出错：' || SQLERRM;
  END;
  
  -----------------------------------------------------------------------------
  --  政策申请金额计算过程                                                   --
  -----------------------------------------------------------------------------
  PROCEDURE P_POL_AMOUNT_CAL(IS_SEMANTIC_CODE          IN VARCHAR2 --语义编码
                            ,IS_CONDITION_SQL          IN VARCHAR2 --限制条件
                            ,IN_POLICY_ID              IN NUMBER --政策ID
                            ,IN_ENTITY_ID              IN NUMBER --主体ID
                            ,ON_AMOUNT                OUT NUMBER   --计算金额
                            ,OS_MESSAGE               OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
                            )
  IS
    N_CUR          NUMBER;
    S_STEP         VARCHAR2(40);
    S_PRE_PROC_SQL VARCHAR2(4000);
    S_GET_VAL_SQL  VARCHAR2(4000);
    N_ROW          NUMBER;
  BEGIN
    OS_MESSAGE := 'OK';
    
    --获取语义SQL
    S_STEP := '获取语义SQL';
    SELECT
      PRE_PROC_SQL
      ,GET_VAL_SQL
    INTO
      S_PRE_PROC_SQL
      ,S_GET_VAL_SQL
    FROM
      T_POL_SEMANTIC
    WHERE SEMANTIC_CODE = IS_SEMANTIC_CODE
      AND ENTITY_ID = IN_ENTITY_ID;
    
    --预执行语句
    IF (S_PRE_PROC_SQL IS NOT NULL) THEN
      S_STEP := '执行预处理语句';
      --打开光标
      N_CUR := DBMS_SQL.OPEN_CURSOR;
      --解析动态SQL语句
      DBMS_SQL.PARSE(N_CUR, S_PRE_PROC_SQL, DBMS_SQL.NATIVE);
      --绑定输入参数
      IF INSTR(S_PRE_PROC_SQL, ':P_POLICY_ID', 1, 1) > 0 THEN
        DBMS_SQL.BIND_VARIABLE(N_CUR, ':P_POLICY_ID', IN_POLICY_ID);
      END IF;
      IF INSTR(S_PRE_PROC_SQL, ':P_ENTITY_ID', 1, 1) > 0 THEN
        DBMS_SQL.BIND_VARIABLE(N_CUR, ':P_ENTITY_ID', IN_ENTITY_ID);
      END IF;
      IF INSTR(S_PRE_PROC_SQL, ':P_CONDITION_SQL', 1, 1) > 0 THEN
        DBMS_SQL.BIND_VARIABLE(N_CUR, ':P_CONDITION_SQL', IS_CONDITION_SQL);
      END IF;
      --执行语句
      N_ROW := DBMS_SQL.EXECUTE(N_CUR);
      --关闭光标
      DBMS_SQL.CLOSE_CURSOR(N_CUR);
    END IF;

    --拼接限制条件
    IF (IS_CONDITION_SQL IS NOT NULL) AND INSTR(S_GET_VAL_SQL, ':P_CONDITION_SQL', 1, 1) = 0 THEN
      S_GET_VAL_SQL := S_GET_VAL_SQL || ' AND (' || IS_CONDITION_SQL || ')';
    END IF;
    
    --执行SQL
    S_STEP := '执行SQL';
    N_CUR := DBMS_SQL.OPEN_CURSOR;
    DBMS_SQL.PARSE(N_CUR,S_GET_VAL_SQL,DBMS_SQL.NATIVE);
    --绑定输入参数
    IF INSTR(S_PRE_PROC_SQL, ':P_POLICY_ID', 1, 1) > 0 THEN
      DBMS_SQL.BIND_VARIABLE(N_CUR, ':P_POLICY_ID', IN_POLICY_ID);
    END IF;
    IF INSTR(S_GET_VAL_SQL, ':P_ENTITY_ID', 1, 1) > 0 THEN
      DBMS_SQL.BIND_VARIABLE(N_CUR, ':P_ENTITY_ID', IN_ENTITY_ID);
    END IF;
    IF INSTR(S_GET_VAL_SQL, ':P_CONDITION_SQL', 1, 1) > 0 THEN
      DBMS_SQL.BIND_VARIABLE(N_CUR, ':P_CONDITION_SQL', IS_CONDITION_SQL);
    END IF;
    --定义列
    DBMS_SQL.DEFINE_COLUMN(N_CUR, 1, ON_AMOUNT);
    --执行动态SQL
    N_ROW := DBMS_SQL.EXECUTE(N_CUR);
    --获取列值
    IF DBMS_SQL.FETCH_ROWS(N_CUR) = 0 THEN
      ON_AMOUNT := 0;
    ELSE
      DBMS_SQL.COLUMN_VALUE(N_CUR, 1, ON_AMOUNT);
    END IF;
    DBMS_SQL.CLOSE_CURSOR(N_CUR);
    
  EXCEPTION
    WHEN OTHERS THEN
      OS_MESSAGE := '调用金额计算过程-' || S_STEP ||'：' || SQLERRM;
  END P_POL_AMOUNT_CAL;

  -----------------------------------------------------------------------------
  --  政策计算审批结果生成Y单行
  --对于审批结果中存在多个拆分金额，则按拆分金额生成Y单行
  -----------------------------------------------------------------------------
  PROCEDURE P_TO_POL_ORDER_LINE
  (
    IN_POLICY_CHK_ID      IN NUMBER   --政策计算结果审批ID
    ,IN_POLICY_ORDER_ID   IN NUMBER   --政策申请ID
    ,IS_DISCOUNT_METHOD   IN VARCHAR2 --折让方式
    ,IS_REF_MODEL         IN VARCHAR2 --涉及机型
    ,IS_SALES_MAIN_TYPE   IN VARCHAR2 --营销大类
    ,IN_ENTITY_ID         IN NUMBER   --主体ID
    ,IS_USER_ID           IN VARCHAR2 --用户账号
    ,OS_MESSAGE           OUT VARCHAR2   --成功则返回“OK”，否则返回出错信息
  ) IS
    N_LINE_NUMBER NUMBER;
    N_ITEM_ID   NUMBER;
    S_ITEM_CODE VARCHAR2(100);
    S_ITEM_NAME VARCHAR2(300);
    S_DEFAULTUNIT VARCHAR2(40);
    S_SQL1      VARCHAR2(4000);
    S_SQL2      VARCHAR2(4000);
    S_SQL3      VARCHAR2(4000);
    S_SQL4      VARCHAR2(4000);
    S_SQL       VARCHAR2(4000);
    N_INDEX     NUMBER := 0;
    S_INDEX     VARCHAR2(2);
    N_CUR       NUMBER;
    N_ROW       NUMBER;
    S_STEP      VARCHAR2(40);
  BEGIN
    OS_MESSAGE := 'OK';
    SAVEPOINT SP_TO_POL_ORDER_LINE;
    
    --检查是否存在拆分金额与总金额不一致的行
    S_STEP := '检查拆分金额';
    BEGIN
      SELECT
        '存在拆分金额与本次返利金额不一致的行(客户编码：' || CUSTOMER_CODE
        || ';中心编码：' || SALES_CENTER_CODE || ')'
      INTO
        OS_MESSAGE
      FROM
        T_POL_POLICY_RESULT
      WHERE
        RESULT_CHK_ID = IN_POLICY_CHK_ID
        AND NVL(RECKON_AMOUNT,0) + NVL(ADJUST_AMOUNT,0) - NVL(REBATE_AMOUNT,0)
          <> (NVL(SPLIT_DISCOUNT_AMOUNT_01,0)+NVL(SPLIT_DISCOUNT_AMOUNT_02,0)
          +NVL(SPLIT_DISCOUNT_AMOUNT_03,0)+NVL(SPLIT_DISCOUNT_AMOUNT_04,0)
          +NVL(SPLIT_DISCOUNT_AMOUNT_05,0)+NVL(SPLIT_DISCOUNT_AMOUNT_06,0)
          +NVL(SPLIT_DISCOUNT_AMOUNT_07,0)+NVL(SPLIT_DISCOUNT_AMOUNT_08,0)
          +NVL(SPLIT_DISCOUNT_AMOUNT_09,0)+NVL(SPLIT_DISCOUNT_AMOUNT_10,0)
          +NVL(SPLIT_DISCOUNT_AMOUNT_11,0)+NVL(SPLIT_DISCOUNT_AMOUNT_12,0)
          +NVL(SPLIT_DISCOUNT_AMOUNT_13,0)+NVL(SPLIT_DISCOUNT_AMOUNT_14,0)
          +NVL(SPLIT_DISCOUNT_AMOUNT_15,0)+NVL(SPLIT_DISCOUNT_AMOUNT_16,0)
          +NVL(SPLIT_DISCOUNT_AMOUNT_17,0)+NVL(SPLIT_DISCOUNT_AMOUNT_18,0)
          +NVL(SPLIT_DISCOUNT_AMOUNT_19,0)+NVL(SPLIT_DISCOUNT_AMOUNT_20,0)
          )
        AND (NVL(SPLIT_DISCOUNT_AMOUNT_01,0)+NVL(SPLIT_DISCOUNT_AMOUNT_02,0)
          +NVL(SPLIT_DISCOUNT_AMOUNT_03,0)+NVL(SPLIT_DISCOUNT_AMOUNT_04,0)
          +NVL(SPLIT_DISCOUNT_AMOUNT_05,0)+NVL(SPLIT_DISCOUNT_AMOUNT_06,0)
          +NVL(SPLIT_DISCOUNT_AMOUNT_07,0)+NVL(SPLIT_DISCOUNT_AMOUNT_08,0)
          +NVL(SPLIT_DISCOUNT_AMOUNT_09,0)+NVL(SPLIT_DISCOUNT_AMOUNT_10,0)
          +NVL(SPLIT_DISCOUNT_AMOUNT_11,0)+NVL(SPLIT_DISCOUNT_AMOUNT_12,0)
          +NVL(SPLIT_DISCOUNT_AMOUNT_13,0)+NVL(SPLIT_DISCOUNT_AMOUNT_14,0)
          +NVL(SPLIT_DISCOUNT_AMOUNT_15,0)+NVL(SPLIT_DISCOUNT_AMOUNT_16,0)
          +NVL(SPLIT_DISCOUNT_AMOUNT_17,0)+NVL(SPLIT_DISCOUNT_AMOUNT_18,0)
          +NVL(SPLIT_DISCOUNT_AMOUNT_19,0)+NVL(SPLIT_DISCOUNT_AMOUNT_20,0)
          ) <> 0
        AND ROWNUM = 1;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        NULL;
    END;
    
    --取Y单中的最大行号
    IF OS_MESSAGE = 'OK' THEN
      S_STEP := '取Y单中的最大行号';
      SELECT NVL(MAX(LINE_NUMBER),0)
        INTO N_LINE_NUMBER
        FROM T_POL_ORDER_LINES
       WHERE POLICY_ORDER_ID = IN_POLICY_ORDER_ID;
    END IF;

    --取默认商品
    IF OS_MESSAGE = 'OK' THEN
      S_STEP := '取默认商品';
      FOR C_ITEM_INFO in 
      (
        SELECT * 
        FROM T_BD_ITEM T 
        WHERE T.ENTITY_ID = IN_ENTITY_ID
          AND T.IS_VIRTUAL = 'Y'
          AND ITEM_CODE IN ('Z0000000000001','Z0000000000002')
      )
      loop
        if C_ITEM_INFO.Item_Code = 'Z0000000000001' and IS_DISCOUNT_METHOD IN (4,5) then
          N_ITEM_ID := C_ITEM_INFO.Item_Id;
          S_ITEM_CODE := C_ITEM_INFO.Item_Code;
          S_ITEM_NAME := C_ITEM_INFO.Item_Name;
          S_DEFAULTUNIT := C_ITEM_INFO.Defaultunit;
        elsif C_ITEM_INFO.Item_Code = 'Z0000000000002' and IS_DISCOUNT_METHOD IN (1,2,3,6,7) then
          N_ITEM_ID := C_ITEM_INFO.Item_Id;
          S_ITEM_CODE := C_ITEM_INFO.Item_Code;
          S_ITEM_NAME := C_ITEM_INFO.Item_Name;
          S_DEFAULTUNIT := C_ITEM_INFO.Defaultunit;
        end if;           
      end loop; 
    END IF;   
    
    --按总金额生成Y单行,对于无拆分金额，则标记不为需拆分，否则标记为拆分
    IF OS_MESSAGE = 'OK' THEN
      S_STEP := '按总金额生成Y单行';
      INSERT INTO T_POL_ORDER_LINES
      (
         LINE_ID
        ,LINE_NUMBER
        ,POLICY_ORDER_ID
        ,LINE_AMOUNT
        ,CHANGED_CASH_FLAG
        ,ITEM_ID
        ,ITEM_CODE
        ,ITEM_NAME
        ,UOM_CODE
        ,QUANTITY
        ,LIST_PRICE
        ,CUSTOMER_ID
        ,CUSTOMER_CODE
        ,CUSTOMER_NAME
        ,SALES_CENTER_ID
        ,SALES_CENTER_CODE
        ,SALES_CENTER_NAME
        ,ACCOUNT_ID
        ,ACCOUNT_CODE
        ,DISCOUNT_METHOD
        ,CHECK_FLAG
        ,REMARK
        ,CREATED_BY
        ,CREATION_DATE
        ,LAST_UPDATED_BY
        ,LAST_UPDATE_DATE
        ,LIMIT_AMOUNT
        ,OU_ID
        ,REF_MODEL
        ,RESULT_CHK_ID
        ,POLICY_ID
        ,CALCULATE_GROUP_NAME
        ,CALCULATE_GROUP_TYPE
        ,DISCOUNT_PERIOD
        ,SALES_MAIN_TYPE
        ,SPLIT_ORDER
      )
      SELECT
         S_POLICY_Y_LINES.NEXTVAL LINE_ID  --S_POL_ORDER_LINES
        ,N_LINE_NUMBER+ROWNUM LINE_NUMBER
        ,IN_POLICY_ORDER_ID POLICY_ORDER_ID
        ,PR.LINE_AMOUNT LINE_AMOUNT
        ,'N' CHANGED_CASH_FLAG
        ,N_ITEM_ID ITEM_ID
        ,S_ITEM_CODE ITEM_CODE
        ,S_ITEM_NAME ITEM_NAME
        ,S_DEFAULTUNIT UOM_CODE
        ,1 QUANTITY
        ,PR.LINE_AMOUNT LIST_PRICE
        ,PR.CUSTOMER_ID
        ,PR.CUSTOMER_CODE
        ,PR.CUSTOMER_NAME
        ,PR.SALES_CENTER_ID
        ,PR.SALES_CENTER_CODE
        ,PR.SALES_CENTER_NAME
        ,PR.ACCOUNT_ID
        ,PR.ACCOUNT_CODE
        ,IS_DISCOUNT_METHOD DISCOUNT_METHOD
        ,'N' CHECK_FLAG
        ,NVL((SELECT RE.NOTE
			  FROM T_POL_POLICY_RESULT RE
			  WHERE RE.RESULT_CHK_ID = IN_POLICY_CHK_ID
			  AND RE.NOTE IS NOT NULL
			  AND RE.ACCOUNT_ID=PR.ACCOUNT_ID
			  AND ROWNUM = 1),PR.DISCOUNT_REMARK) AS REMARK --导入的备注，按分销计算的，只取第一条备注)
        ,IS_USER_ID CREATED_BY
        ,SYSDATE CREATION_DATE
        ,IS_USER_ID LAST_UPDATED_BY
        ,SYSDATE LAST_UPDATE_DATE
        ,PR.LIMIT_AMOUNT
        ,PR.OU_ID
        ,IS_REF_MODEL
        ,IN_POLICY_CHK_ID RESULT_CHK_ID
        ,PR.POLICY_ID
        ,PR.CALCULATE_GROUP_NAME
        ,PR.CALCULATE_GROUP_TYPE
        ,PR.DISCOUNT_PERIOD
        ,IS_SALES_MAIN_TYPE SALES_MAIN_TYPE --将头表营销大类带到行表上 2017-10-27
        ,SPLIT_ORDER
      FROM
        (
          SELECT
             R.CUSTOMER_ID
            ,R.CUSTOMER_CODE
            ,R.CUSTOMER_NAME
            ,R.SALES_CENTER_ID
            ,R.SALES_CENTER_CODE
            ,R.SALES_CENTER_NAME
            ,R.ACCOUNT_ID
            ,R.ACCOUNT_CODE
            ,PC.OU_ID
            ,P.POLICY_ID
            ,P.CALCULATE_GROUP_NAME
            ,P.CALCULATE_GROUP_TYPE
            ,NVL(PC.DISCOUNT_PERIOD,P.DISCOUNT_PERIOD) DISCOUNT_PERIOD
            ,PC.DISCOUNT_REMARK
            ,SUM(R.LIMIT_AMOUNT) LIMIT_AMOUNT
            ,SUM(NVL(R.RECKON_AMOUNT,0) + NVL(R.ADJUST_AMOUNT,0) - NVL(R.REBATE_AMOUNT,0)) LINE_AMOUNT
            ,CASE
              WHEN (NVL(R.SPLIT_DISCOUNT_AMOUNT_01,0) = 0
                AND NVL(R.SPLIT_DISCOUNT_AMOUNT_02,0) = 0
                AND NVL(R.SPLIT_DISCOUNT_AMOUNT_03,0) = 0
                AND NVL(R.SPLIT_DISCOUNT_AMOUNT_04,0) = 0
                AND NVL(R.SPLIT_DISCOUNT_AMOUNT_05,0) = 0
                AND NVL(R.SPLIT_DISCOUNT_AMOUNT_06,0) = 0
                AND NVL(R.SPLIT_DISCOUNT_AMOUNT_07,0) = 0
                AND NVL(R.SPLIT_DISCOUNT_AMOUNT_08,0) = 0
                AND NVL(R.SPLIT_DISCOUNT_AMOUNT_09,0) = 0
                AND NVL(R.SPLIT_DISCOUNT_AMOUNT_10,0) = 0
                AND NVL(R.SPLIT_DISCOUNT_AMOUNT_11,0) = 0
                AND NVL(R.SPLIT_DISCOUNT_AMOUNT_12,0) = 0
                AND NVL(R.SPLIT_DISCOUNT_AMOUNT_13,0) = 0
                AND NVL(R.SPLIT_DISCOUNT_AMOUNT_14,0) = 0
                AND NVL(R.SPLIT_DISCOUNT_AMOUNT_15,0) = 0
                AND NVL(R.SPLIT_DISCOUNT_AMOUNT_16,0) = 0
                AND NVL(R.SPLIT_DISCOUNT_AMOUNT_17,0) = 0
                AND NVL(R.SPLIT_DISCOUNT_AMOUNT_18,0) = 0
                AND NVL(R.SPLIT_DISCOUNT_AMOUNT_19,0) = 0
                AND NVL(R.SPLIT_DISCOUNT_AMOUNT_20,0) = 0)
              THEN
                'N'
              ELSE
                'Y'
            END SPLIT_ORDER
          FROM
            T_POL_POLICY_RESULT R,
            T_POL_POLICY_RESULT_CHK PC,
            T_POL_POLICY P
          WHERE R.RESULT_CHK_ID = IN_POLICY_CHK_ID
            AND R.POLICY_ID = P.POLICY_ID
            AND NVL(RECKON_AMOUNT,0) + NVL(ADJUST_AMOUNT,0) - NVL(REBATE_AMOUNT,0) <> 0
            AND R.RESULT_CHK_ID = PC.RESULT_CHK_ID(+)
          GROUP BY
             R.CUSTOMER_ID
            ,R.CUSTOMER_CODE
            ,R.CUSTOMER_NAME
            ,R.SALES_CENTER_ID
            ,R.SALES_CENTER_CODE
            ,R.SALES_CENTER_NAME
            ,R.ACCOUNT_ID-- 客户id相同合并
            ,R.ACCOUNT_CODE
            ,PC.OU_ID
            ,P.POLICY_ID
            ,P.CALCULATE_GROUP_NAME
            ,P.CALCULATE_GROUP_TYPE
            ,NVL(PC.DISCOUNT_PERIOD,P.DISCOUNT_PERIOD)
            ,PC.DISCOUNT_REMARK
            ,CASE
              WHEN (NVL(R.SPLIT_DISCOUNT_AMOUNT_01,0) = 0
                AND NVL(R.SPLIT_DISCOUNT_AMOUNT_02,0) = 0
                AND NVL(R.SPLIT_DISCOUNT_AMOUNT_03,0) = 0
                AND NVL(R.SPLIT_DISCOUNT_AMOUNT_04,0) = 0
                AND NVL(R.SPLIT_DISCOUNT_AMOUNT_05,0) = 0
                AND NVL(R.SPLIT_DISCOUNT_AMOUNT_06,0) = 0
                AND NVL(R.SPLIT_DISCOUNT_AMOUNT_07,0) = 0
                AND NVL(R.SPLIT_DISCOUNT_AMOUNT_08,0) = 0
                AND NVL(R.SPLIT_DISCOUNT_AMOUNT_09,0) = 0
                AND NVL(R.SPLIT_DISCOUNT_AMOUNT_10,0) = 0
                AND NVL(R.SPLIT_DISCOUNT_AMOUNT_11,0) = 0
                AND NVL(R.SPLIT_DISCOUNT_AMOUNT_12,0) = 0
                AND NVL(R.SPLIT_DISCOUNT_AMOUNT_13,0) = 0
                AND NVL(R.SPLIT_DISCOUNT_AMOUNT_14,0) = 0
                AND NVL(R.SPLIT_DISCOUNT_AMOUNT_15,0) = 0
                AND NVL(R.SPLIT_DISCOUNT_AMOUNT_16,0) = 0
                AND NVL(R.SPLIT_DISCOUNT_AMOUNT_17,0) = 0
                AND NVL(R.SPLIT_DISCOUNT_AMOUNT_18,0) = 0
                AND NVL(R.SPLIT_DISCOUNT_AMOUNT_19,0) = 0
                AND NVL(R.SPLIT_DISCOUNT_AMOUNT_20,0) = 0)
              THEN
                'N'
              ELSE
                'Y'
            END
        ) PR;
    END IF;
    
    --对于存在拆分金额，则循环取出拆分金额，生成Y单行
    IF OS_MESSAGE = 'OK' THEN
      S_STEP := '按拆分金额生成Y单行';
      S_SQL1 := 'INSERT INTO T_POL_ORDER_LINES
      (
         LINE_ID
        ,LINE_NUMBER
        ,POLICY_ORDER_ID
        ,LINE_AMOUNT
        ,CHANGED_CASH_FLAG
        ,ITEM_ID
        ,ITEM_CODE
        ,ITEM_NAME
        ,UOM_CODE
        ,QUANTITY
        ,LIST_PRICE
        ,CUSTOMER_ID
        ,CUSTOMER_CODE
        ,CUSTOMER_NAME
        ,SALES_CENTER_ID
        ,SALES_CENTER_CODE
        ,SALES_CENTER_NAME
        ,ACCOUNT_ID
        ,ACCOUNT_CODE
        ,DISCOUNT_METHOD
        ,CHECK_FLAG
        ,REMARK
        ,CREATED_BY
        ,CREATION_DATE
        ,LAST_UPDATED_BY
        ,LAST_UPDATE_DATE
        ,LIMIT_AMOUNT
        ,OU_ID
        ,REF_MODEL
        ,RESULT_CHK_ID
        ,POLICY_ID
        ,CALCULATE_GROUP_NAME
        ,CALCULATE_GROUP_TYPE
        ,DISCOUNT_PERIOD
        ,SALES_MAIN_TYPE
        ,SPLIT_ORDER
        ,SPLIT_ORDER_ID
      )
      SELECT
         S_POLICY_Y_LINES.NEXTVAL
        ,ROWNUM+';
      S_SQL2 := ',' || TO_CHAR(IN_POLICY_ORDER_ID)
        || ',PR.LINE_AMOUNT
        ,''N'''
        || ',' || TO_CHAR(N_ITEM_ID)
        || ',''' || S_ITEM_CODE || ''''
        || ',''' || S_ITEM_NAME || ''''
        || ',''' || S_DEFAULTUNIT || ''''
        || ',1
        ,PR.LINE_AMOUNT
        ,PR.CUSTOMER_ID
        ,PR.CUSTOMER_CODE
        ,PR.CUSTOMER_NAME
        ,PR.SALES_CENTER_ID
        ,PR.SALES_CENTER_CODE
        ,PR.SALES_CENTER_NAME
        ,PR.ACCOUNT_ID
        ,PR.ACCOUNT_CODE'
        || ',''' || IS_DISCOUNT_METHOD || '''
        ,''N''
        ,PR.DISCOUNT_REMARK'
        || ',''' || IS_USER_ID || '''
        ,SYSDATE'
        || ',''' || IS_USER_ID || '''
        ,SYSDATE
        ,PR.LIMIT_AMOUNT
        ,PR.OU_ID'
        || ',''' || IS_REF_MODEL || ''''
        || ',' || TO_CHAR(IN_POLICY_CHK_ID)
        || ',PR.POLICY_ID
        ,PR.CALCULATE_GROUP_NAME
        ,PR.CALCULATE_GROUP_TYPE
        ,PR.DISCOUNT_PERIOD'
        || ',''' || IS_SALES_MAIN_TYPE || ''''
        || ',''N''
        ,PR.SPLIT_ORDER_ID
      FROM
        (
          SELECT
             R.CUSTOMER_ID
            ,R.CUSTOMER_CODE
            ,R.CUSTOMER_NAME
            ,R.SALES_CENTER_ID
            ,R.SALES_CENTER_CODE
            ,R.SALES_CENTER_NAME
            ,R.ACCOUNT_ID
            ,R.ACCOUNT_CODE
            ,PC.OU_ID
            ,P.POLICY_ID
            ,P.CALCULATE_GROUP_NAME
            ,P.CALCULATE_GROUP_TYPE
            ,NVL(PC.DISCOUNT_PERIOD,P.DISCOUNT_PERIOD) DISCOUNT_PERIOD
            ,NVL(R.NOTE,PC.DISCOUNT_REMARK) AS DISCOUNT_REMARK
            ,L.LINE_ID SPLIT_ORDER_ID
            ,R.LIMIT_AMOUNT
            ,R.SPLIT_DISCOUNT_AMOUNT_';
      S_SQL3 := ' LINE_AMOUNT
          FROM
            T_POL_POLICY_RESULT R,
            T_POL_POLICY_RESULT_CHK PC,
            T_POL_POLICY P,
            T_POL_ORDER_LINES L
          WHERE R.RESULT_CHK_ID = ' || TO_CHAR(IN_POLICY_CHK_ID)
        ||' AND R.POLICY_ID = P.POLICY_ID
            AND R.RESULT_CHK_ID = PC.RESULT_CHK_ID
            AND R.ACCOUNT_ID = L.ACCOUNT_ID
            AND L.RESULT_CHK_ID = ' || TO_CHAR(IN_POLICY_CHK_ID)
        ||' AND L.POLICY_ORDER_ID = ' || TO_CHAR(IN_POLICY_ORDER_ID)
        ||' AND L.SPLIT_ORDER = ''Y''
            AND NVL(R.SPLIT_DISCOUNT_AMOUNT_';
      S_SQL4 := ',0)<> 0) PR';
   
      --循环取出20个字段，分别写Y单行
      FOR N_INDEX IN 1..20
      LOOP
        SELECT NVL(MAX(LINE_NUMBER),0)
          INTO N_LINE_NUMBER
          FROM T_POL_ORDER_LINES
         WHERE POLICY_ORDER_ID = IN_POLICY_ORDER_ID;
        --序号转成字符
        S_INDEX := TRIM(TO_CHAR(N_INDEX,'00'));
        S_SQL := S_SQL1 || TO_CHAR(N_LINE_NUMBER) || S_SQL2 || S_INDEX || S_SQL3 || S_INDEX || S_SQL4;
           dbms_output.put_line(S_SQL);
        --执行插入语句
        N_CUR := DBMS_SQL.OPEN_CURSOR;
        DBMS_SQL.PARSE(N_CUR, S_SQL, DBMS_SQL.NATIVE);
        N_ROW := DBMS_SQL.execute(N_CUR);
        DBMS_SQL.CLOSE_CURSOR(N_CUR);
      END LOOP;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK TO SAVEPOINT SP_TO_POL_ORDER_LINE;
      OS_MESSAGE := '写政策申请行-' || S_STEP || '出错！(INDEX=' || TO_CHAR(N_INDEX) || ')' || SQLERRM;
  END P_TO_POL_ORDER_LINE;

  -----------------------------------------------------------------------------
  --      确认报表结果                                                --
  --程序逻辑：
  --1、对单个报表结果进行确认返利，
  --2、根据政策对应Y单，生成Y单行，并执行返利操作
  --3、回写相应的Y单据行ID，及返利单信息
  --4、检查政策的结果是否已返利完毕，若是，则修改政策状态为已返利，否则为部分返利
  -----------------------------------------------------------------------------
  PROCEDURE P_AFFIRM_RESULT(IN_POLICY_CHK_ID          IN NUMBER   --政策审批ID
                           ,IS_USER_ID                IN VARCHAR2 --用户账号
                           ,OS_MESSAGE               OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
                           ) IS
    --报表明细
    CURSOR C_ORDER_LINES(IN_POLICY_ORDER_ID NUMBER) IS
      SELECT L.LINE_ID
        FROM T_POL_ORDER_LINES L
       WHERE L.POLICY_ORDER_ID = IN_POLICY_ORDER_ID
         AND L.RESULT_CHK_ID IS NOT NULL  --by sushu 2016-09-08
         AND L.RESULT_CHK_ID = IN_POLICY_CHK_ID
         AND NVL(L.CHANGED_CASH_FLAG,'N') = 'N'
         AND NVL(L.SPLIT_ORDER,'N') = 'N';
    R_ORDER_LINES C_ORDER_LINES%ROWTYPE;
    
    TYPE C_ITEM_INFO IS REF CURSOR;
    
    N_POLICY_ID               NUMBER;
    N_PARENT_POLICY_ID        NUMBER; --主政策ID
    S_AUDIT_STATE             VARCHAR2(40);
    N_POLICY_ORDER_ID         NUMBER;
    S_DISCOUNT_METHOD         VARCHAR2(30);
    V_DISCOUNT_METHOD         VARCHAR2(30); --返利结果审批上的折让方式
    S_CLOSE_FLAG              VARCHAR2(2);
    S_POLICY_ORDER_NUMBER     VARCHAR2(100);
    N_ENTITY_ID               NUMBER;
    S_POLICY_NEW_STATUS       VARCHAR2(40);
    P_SPLIT_ORDER_FLAG        VARCHAR2(10); --拆单标识
    V_CONFIRM_FALG            VARCHAR2(2);  --返利确认标志 by tianmzh
    V_SALES_MAIN_TYPE         VARCHAR2(32); --营销大类
    N_DEF_AMOUNT              NUMBER;
    S_CUR_DIS_PERIOD          VARCHAR2(32);
    S_DISCOUNT_PERIOD         VARCHAR2(32);
    V_DISCOUNT_PERIOD         VARCHAR2(32); --返利结果审批上的归属返利周期
    S_1_DIS_PERIOD            VARCHAR2(32);
    S_12_DIS_PERIOD           VARCHAR2(32);

    S_STEP                    VARCHAR2(40);
    N_RESULT_SUM              NUMBER;
    N_POLICY_AMOUNT           NUMBER;
    V_REF_MODEL               VARCHAR2(500);
    N_LINE_AMOUNT             NUMBER; --Y单行金额
  BEGIN
    OS_MESSAGE := 'OK';
    SAVEPOINT SP_AFFIRM_RESULT;

    --锁定记录，防止一条记录被多次操作。
    BEGIN
      S_STEP := '锁定记录';
      SELECT POLICY_ID
            ,AUDIT_STATE
            ,ENTITY_ID --add by tianmzh
            ,CONFIRM_FLAG
            ,DISCOUNT_METHOD
            ,DISCOUNT_PERIOD
        INTO N_POLICY_ID
            ,S_AUDIT_STATE
            ,N_ENTITY_ID --add by tianmzh
            ,V_CONFIRM_FALG
            ,V_DISCOUNT_METHOD
            ,V_DISCOUNT_PERIOD
        FROM T_POL_POLICY_RESULT_CHK
       WHERE RESULT_CHK_ID = IN_POLICY_CHK_ID
         FOR UPDATE NOWAIT; 
      IF S_AUDIT_STATE <> '6' THEN  --6:已审核
        OS_MESSAGE := '政策计算结果非“已审核”状态，不能返利！';
      END IF;
      --ADD BY tianmzh 2016-12-17
      IF V_CONFIRM_FALG = 'Y' THEN
        OS_MESSAGE := '政策计算结果已经确认返利，不能重复操作！';
      END IF;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        ROLLBACK TO SAVEPOINT SP_AFFIRM_RESULT;
        OS_MESSAGE := '锁定政策计算结算不成功，请稍后再试！';
    END;
    
    N_PARENT_POLICY_ID := N_POLICY_ID;
    
    --取政策信息
    IF OS_MESSAGE = 'OK' THEN
      S_STEP := '取政策信息';
      SELECT
        DISCOUNT_PERIOD
        ,NVL(PARENT_POLICY_ID,N_POLICY_ID)
      INTO
        S_DISCOUNT_PERIOD
        ,N_PARENT_POLICY_ID
      FROM
        T_POL_POLICY
      WHERE
        POLICY_ID = N_POLICY_ID;
      
      --存在父政策则取父政策的信息
      IF N_POLICY_ID <> N_PARENT_POLICY_ID THEN
        SELECT
          DISCOUNT_PERIOD
        INTO
          S_DISCOUNT_PERIOD
        FROM
          T_POL_POLICY
        WHERE
          POLICY_ID = N_PARENT_POLICY_ID;
      END IF;
    END IF;
        
    --取出是否政策算法指定政策资源的参数
    IF OS_MESSAGE = 'OK' THEN
      IF PKG_BD.F_GET_PARAMETER_VALUE('POL_CAL_TO_SOURCE',N_ENTITY_ID) = 'Y' THEN
        --按政策算法对应的资源行获取Y单
        S_STEP := '按政策资源取Y单';
        BEGIN
          SELECT
            H.POLICY_ORDER_ID
            ,H.DISCOUNT_METHOD
            ,H.CLOSE_FLAG
            ,H.POLICY_ORDER_NUMBER
            ,H.REF_MODEL
            ,H.SALES_MAIN_TYPE
            ,H.POLICY_AMOUNT --Y单政策申请金额
          INTO
            N_POLICY_ORDER_ID
            ,S_DISCOUNT_METHOD
            ,S_CLOSE_FLAG
            ,S_POLICY_ORDER_NUMBER
            ,V_REF_MODEL
            ,V_SALES_MAIN_TYPE
            ,N_POLICY_AMOUNT
          FROM
            T_POL_POLICY P
            ,T_POL_POLICY_SOURCE PS
            ,T_POL_ORDER_HEADERS H
          WHERE
            P.POLICY_SOURCE_ID = PS.POLICY_SOURCE_ID
            AND PS.POLICY_ORDER_NUMBER = H.POLICY_ORDER_NUMBER
            AND P.POLICY_ID = N_POLICY_ID
            AND H.ENTITY_ID = N_ENTITY_ID;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            --没有对应的数据则提示
            OS_MESSAGE := '未定义算法对应的政策资源，或政策申请未生成对应的返利申请！';
        END;
      ELSE
        --按父政策ID获取Y单
        S_STEP := '按父政策取Y单';
        BEGIN
          SELECT
            H.POLICY_ORDER_ID
            ,H.DISCOUNT_METHOD
            ,H.CLOSE_FLAG
            ,H.POLICY_ORDER_NUMBER
            ,H.REF_MODEL
            ,H.SALES_MAIN_TYPE
            ,H.POLICY_AMOUNT --Y单政策申请金额
          INTO
            N_POLICY_ORDER_ID
            ,S_DISCOUNT_METHOD
            ,S_CLOSE_FLAG
            ,S_POLICY_ORDER_NUMBER
            ,V_REF_MODEL
            ,V_SALES_MAIN_TYPE
            ,N_POLICY_AMOUNT
          FROM
            T_POL_ORDER_HEADERS H
          WHERE
            H.POLICY_ID = N_PARENT_POLICY_ID;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            --没有对应的数据则提示
            OS_MESSAGE := '政策申请未生成对应的返利申请！';
        END;
      END IF;
    END IF;

    IF OS_MESSAGE = 'OK' AND S_CLOSE_FLAG = 'Y' THEN
      OS_MESSAGE := '对应的Y单（' || S_POLICY_ORDER_NUMBER || '）已关闭，不能处理政策兑现！';
    END IF;
    
    
    
    IF V_DISCOUNT_METHOD IS NOT NULL THEN
      S_DISCOUNT_METHOD := V_DISCOUNT_METHOD;
    END IF;
    
    IF OS_MESSAGE = 'OK' THEN
      S_STEP := '获取兑现金额';
      SELECT SUM(NVL(RECKON_AMOUNT,0) + NVL(ADJUST_AMOUNT,0) - NVL(REBATE_AMOUNT,0))
        INTO N_RESULT_SUM
        FROM T_POL_POLICY_RESULT R
       WHERE R.RESULT_CHK_ID = IN_POLICY_CHK_ID;
      
      SELECT NVL(SUM(NVL(L.LINE_AMOUNT,0)),0)
        INTO N_LINE_AMOUNT
        FROM T_POL_ORDER_HEADERS H, T_POL_ORDER_LINES L
       WHERE H.POLICY_ORDER_ID = L.POLICY_ORDER_ID
         AND NVL(L.SPLIT_ORDER, 'N') = 'N'
         AND H.POLICY_ORDER_ID = N_POLICY_ORDER_ID;
      IF N_POLICY_AMOUNT > 0 AND N_RESULT_SUM > (N_POLICY_AMOUNT - N_LINE_AMOUNT) THEN
        OS_MESSAGE := '自动计算兑现金额【'||TO_CHAR(N_RESULT_SUM)||'】大于返利申请单（Y单）可用剩余金额【'||TO_CHAR(N_POLICY_AMOUNT - N_LINE_AMOUNT)||'】，请调整本次兑现金额或追加预算金额！';
      END IF;
    END IF;
    
    --获取主体参数，厨电主体需要拆单
    IF OS_MESSAGE = 'OK' THEN
      S_STEP := '取拆单标识';
      SELECT PB.ENTITY_VALUE
        INTO P_SPLIT_ORDER_FLAG
        FROM T_BD_PARAM_LIST PA, T_BD_PARAM_entity PB
       WHERE PA.PARAM_LIST_ID = PB.PARAM_LIST_ID
         AND PA.PARAM_CODE = 'SPLIT_ORDER_FLAG'
         AND PB.ENTITY_ID = N_ENTITY_ID;
    END IF;
           
    --取出计算结果，插入Y单行，由于增加动态分类，需处理汇总
    IF OS_MESSAGE = 'OK' THEN
      S_STEP := '取出计算结果，插入Y单行';
      P_TO_POL_ORDER_LINE(IN_POLICY_CHK_ID,N_POLICY_ORDER_ID,S_DISCOUNT_METHOD,V_REF_MODEL,V_SALES_MAIN_TYPE,N_ENTITY_ID,IS_USER_ID,OS_MESSAGE);
    END IF;  
    
    IF OS_MESSAGE = 'OK' THEN
      IF P_SPLIT_ORDER_FLAG = 'N' OR P_SPLIT_ORDER_FLAG IS NULL THEN
      --循环Y单行，生成返利单
        S_STEP := '循环Y单行，生成返利单';
        FOR R_ORDER_LINES IN C_ORDER_LINES(N_POLICY_ORDER_ID) LOOP
          --生成返利单
          PKG_POL_POLICY.P_POLICY_Y_TO_F(IN_POLICY_CHK_ID, N_PARENT_POLICY_ID, R_ORDER_LINES.LINE_ID, 
                                         N_ENTITY_ID, IS_USER_ID, OS_MESSAGE);
          IF (OS_MESSAGE <> 'OK') THEN
            EXIT;
          END IF;
        END LOOP;
      ELSE         
        --厨电拆单
        S_STEP := '厨电拆单';
        OS_MESSAGE := F_SPLIT_ORDER(IN_POLICY_CHK_ID, N_POLICY_ORDER_ID, N_PARENT_POLICY_ID, N_ENTITY_ID, IS_USER_ID);     
      END IF;
    END IF;
        
    --执行更新
    IF (OS_MESSAGE = 'OK') THEN
      /*于转返利后不更新已转返利金额，保持原有信息，可通过POLICY_ORDER_LINE_ID判断是否已转返利
      --更新报表结果
      S_STEP := '更新报表结果';
      UPDATE T_POL_POLICY_RESULT T
         SET T.REBATE_AMOUNT = NVL(RECKON_AMOUNT,0) + NVL(ADJUST_AMOUNT,0)
            ,LAST_UPDATED_BY = IS_USER_ID
            ,LAST_UPDATE_DATE = SYSDATE
       WHERE T.RESULT_CHK_ID = IN_POLICY_CHK_ID
         AND NVL(RUN_REBATE_AMOUNT,0) <> 0;
      */
      
      --更新结果表中的Y单行ID
      UPDATE T_POL_POLICY_RESULT R
         SET POLICY_ORDER_LINE_ID =
             (SELECT L.LINE_ID
                FROM T_POL_ORDER_LINES L
               WHERE L.POLICY_ORDER_ID = N_POLICY_ORDER_ID
                 AND L.ACCOUNT_ID = R.ACCOUNT_ID
                 AND L.RESULT_CHK_ID = IN_POLICY_CHK_ID
                 AND L.SPLIT_ORDER_ID IS NULL)
            ,VERSION              = VERSION + 1
       WHERE R.RESULT_CHK_ID = IN_POLICY_CHK_ID;
      
      --更新产品计算结果明细中的调整金额
      S_STEP := '更新产品明细调整金额';
      P_SET_ITEM_DETAIL_SPLIT_ADJUST(IN_POLICY_CHK_ID,N_POLICY_ID,IS_USER_ID,OS_MESSAGE);
    END IF;
    
    IF (OS_MESSAGE = 'OK') THEN      
      --获取政策状态
      S_STEP := '获取政策状态';
      P_GET_POLICY_STATUS(N_POLICY_ID
                         ,S_POLICY_NEW_STATUS
                         ,OS_MESSAGE
                         );
    END IF;
    IF (OS_MESSAGE = 'OK') THEN
      --更新政策状态
      --1:部分返利
      S_STEP := '更新政策状态';
      UPDATE T_POL_POLICY T
         SET T.STATUS = NVL(S_POLICY_NEW_STATUS, '1')  
            ,LAST_UPDATED_BY = IS_USER_ID
            ,LAST_UPDATE_DATE = SYSDATE
            ,VERSION = VERSION + 1
       WHERE T.POLICY_ID = N_POLICY_ID;
         
      --更新已兑现金额、剩余金额 20170103
      S_STEP := '更新已兑现金额';
      UPDATE T_POL_ORDER_HEADERS PH
         SET PH.HAD_CASH_AMOUNT =
             (SELECT SUM(NVL(PL.LINE_AMOUNT, 0))
                FROM T_POL_ORDER_LINES PL
               WHERE PL.POLICY_ORDER_ID = PH.POLICY_ORDER_ID
                 AND NVL(PL.CHANGED_CASH_FLAG, 'N') = 'Y'
                 AND NVL(PL.SPLIT_ORDER, 'N') = 'N')
       WHERE PH.POLICY_ORDER_ID = N_POLICY_ORDER_ID; 
      UPDATE T_POL_ORDER_HEADERS PH
         SET PH.REMAINING_AMOUNT = PH.POLICY_AMOUNT - NVL(PH.HAD_CASH_AMOUNT, 0)
            ,VERSION             = VERSION + 1
       WHERE PH.POLICY_ORDER_ID = N_POLICY_ORDER_ID;
      
      --取出差异金额
      BEGIN
        SELECT
          NVL(REMAINING_AMOUNT,0) - NVL(UNUSE_AMOUNT_1_11,0) - NVL(UNUSE_AMOUNT_12,0)
          - NVL(UNUSE_AMOUNT_1_CUR,0) - NVL(UNUSE_AMOUNT_NEXT,0)
          ,NVL(CUR_DIS_PERIOD,TO_CHAR(SYSDATE-10,'YYYY-MM'))
        INTO
          N_DEF_AMOUNT
          ,S_CUR_DIS_PERIOD
        FROM
          T_POL_ORDER_HEADERS
        WHERE
          POLICY_ORDER_ID = N_POLICY_ORDER_ID
          AND
          (
            UNUSE_AMOUNT_1_11 IS NOT NULL
            OR UNUSE_AMOUNT_12 IS NOT NULL
            OR UNUSE_AMOUNT_1_CUR IS NOT NULL
            OR UNUSE_AMOUNT_NEXT IS NOT NULL
          );
        
        IF V_DISCOUNT_PERIOD IS NOT NULL THEN
          S_DISCOUNT_PERIOD := V_DISCOUNT_PERIOD;
        END IF;
        
        S_1_DIS_PERIOD := SUBSTR(S_CUR_DIS_PERIOD,1,5) || '01';
        S_12_DIS_PERIOD := TO_CHAR(TO_NUMBER(SUBSTR(S_CUR_DIS_PERIOD,1,4))-1) || '-12';
        --对于已录入4个未返利金额字段，则按归属返利周期处理更新
        IF S_DISCOUNT_PERIOD >= S_1_DIS_PERIOD AND S_DISCOUNT_PERIOD <= S_CUR_DIS_PERIOD THEN
          --同一周期，则更新当前金额
          UPDATE
            T_POL_ORDER_HEADERS
          SET
            UNUSE_AMOUNT_1_CUR = NVL(UNUSE_AMOUNT_1_CUR,0) + N_DEF_AMOUNT
          WHERE
            POLICY_ORDER_ID = N_POLICY_ORDER_ID;
        ELSIF S_DISCOUNT_PERIOD = S_12_DIS_PERIOD THEN
          --上年12月周期
          UPDATE
            T_POL_ORDER_HEADERS
          SET
            UNUSE_AMOUNT_12 = NVL(UNUSE_AMOUNT_12,0) + N_DEF_AMOUNT
          WHERE
            POLICY_ORDER_ID = N_POLICY_ORDER_ID;
        ELSIF S_DISCOUNT_PERIOD < S_12_DIS_PERIOD THEN
          --上年11月前周期
          UPDATE
            T_POL_ORDER_HEADERS
          SET
            UNUSE_AMOUNT_1_11 = NVL(UNUSE_AMOUNT_1_11,0) + N_DEF_AMOUNT
          WHERE
            POLICY_ORDER_ID = N_POLICY_ORDER_ID;
        ELSE
          --后面周期
          UPDATE
            T_POL_ORDER_HEADERS
          SET
            UNUSE_AMOUNT_NEXT = NVL(UNUSE_AMOUNT_NEXT,0) + N_DEF_AMOUNT
          WHERE
            POLICY_ORDER_ID = N_POLICY_ORDER_ID;
        END IF;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          --找不到则不处理更新
          NULL;
      END;
    END IF;
    
    --add by tianmzh  2016-12-07 start
    IF OS_MESSAGE = 'OK' THEN
      --更新政策结果审批表：返利确认人、确认时间、确认标志
      S_STEP := '更新审批表';
      UPDATE T_POL_POLICY_RESULT_CHK TC
         SET TC.CONFIRMED_BY = IS_USER_ID,
             TC.CONFIRM_DATE = SYSDATE,
             TC.CONFIRM_FLAG = 'Y',
             TC.AUDIT_STATE = '4', --更新状态为"已返利"
             TC.VERSION = TC.VERSION + 1
       WHERE TC.RESULT_CHK_ID = IN_POLICY_CHK_ID;
    END IF;
    --add by tianmzh  2016-12-07 end
    
    IF OS_MESSAGE <> 'OK' THEN
      ROLLBACK TO SAVEPOINT SP_AFFIRM_RESULT;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK TO SAVEPOINT SP_AFFIRM_RESULT;
      OS_MESSAGE := '确认报表结果-' || S_STEP || SQLERRM;
  END;
  
  ------厨电拆单（自动计算转返利）
  FUNCTION F_SPLIT_ORDER( P_POLICY_CHK_ID    NUMBER   --政策审批ID
                         ,P_POLICY_ORDER_ID  NUMBER   --返利申请ID
                         ,P_POLICY_ID       NUMBER
                         ,P_ENTITY_ID       NUMBER
                         ,P_USER            VARCHAR2
                        ) RETURN VARCHAR2 IS                    
    F_MULTIPLE_AMOUNT NUMBER;   --整数倍
    F_REMAINDER_AMOUNT NUMBER;  --余数
    I NUMBER;
    OS_MESSAGE VARCHAR2(4000);
       
    CURSOR C_POLICY_LINES IS
     SELECT *
       FROM CIMS.T_POL_ORDER_LINES PA
      WHERE PA.POLICY_ORDER_ID = P_POLICY_ORDER_ID
       AND NVL(PA.CHANGED_CASH_FLAG,'N') = 'N'
       AND NVL(PA.SPLIT_ORDER,'N') = 'N'
       AND PA.RESULT_CHK_ID = P_POLICY_CHK_ID;  --by sushu 2016-09-08
     R_POLICY_LINE C_POLICY_LINES%ROWTYPE;
          
  BEGIN
    
    FOR R IN C_POLICY_LINES LOOP
      --行金额小于限额
      IF R.LINE_AMOUNT - R.LIMIT_AMOUNT > 0 THEN 
        SELECT MOD(R.LINE_AMOUNT, R.LIMIT_AMOUNT) 
          INTO F_REMAINDER_AMOUNT
          FROM DUAL;
        
         SELECT TRUNC(R.LINE_AMOUNT/R.LIMIT_AMOUNT, 0)
           INTO F_MULTIPLE_AMOUNT
           FROM DUAL;
           
         --更新拆单标识为Y
         UPDATE T_POL_ORDER_LINES T SET T.SPLIT_ORDER = 'Y' WHERE T.LINE_ID = R.LINE_ID;
           
         I := 1;
         BEGIN 
           LOOP 
             I := I + 1;
             --循环插入Y单行表
             INSERT INTO T_POL_ORDER_LINES(
                LINE_ID 
               ,LINE_NUMBER 
               ,POLICY_ORDER_ID 
               ,LINE_AMOUNT 
               ,CHANGED_CASH_FLAG 
               ,CHOICE_FLAG 
               ,ITEM_ID 
               ,ITEM_CODE 
               ,ITEM_NAME 
               ,UOM_CODE 
               ,QUANTITY 
               ,LIST_PRICE 
               ,CUSTOMER_ID 
               ,CUSTOMER_CODE 
               ,CUSTOMER_NAME 
               ,ACCOUNT_ID 
               ,ACCOUNT_CODE 
               ,DISCOUNT_ORDER_NUMBER 
               ,DISCOUNT_METHOD 
               ,CHECK_FLAG 
               ,REMARK 
               ,CREATED_BY 
               ,CREATION_DATE 
               ,LAST_UPDATED_BY 
               ,LAST_UPDATE_DATE 
               ,OLD_DISCOUNT_NUMBER 
               ,ORDER_TYPE_ID 
               ,SALES_CENTER_ID 
               ,SALES_CENTER_CODE
               ,SALES_CENTER_NAME  
               ,VERSION 
               ,OU_ID 
               ,LIMIT_AMOUNT
               ,SPLIT_ORDER 
               ,SPLIT_ORDER_ID
               ,RESULT_CHK_ID
               ,SALES_MAIN_TYPE
               ,DISCOUNT_PERIOD
               ,CALCULATE_GROUP_NAME
               ,CALCULATE_GROUP_TYPE
               ,POLICY_ID
               ,REF_MODEL
             )VALUES(S_POLICY_Y_LINES.NEXTVAL
                 ,R.LINE_NUMBER
                 ,R.POLICY_ORDER_ID
                 ,R.LIMIT_AMOUNT 
                 ,R.CHANGED_CASH_FLAG
                 ,R.CHOICE_FLAG 
                 ,R.ITEM_ID
                 ,R.ITEM_CODE
                 ,R.ITEM_NAME
                 ,R.UOM_CODE
                 ,R.QUANTITY
                 ,R.LIMIT_AMOUNT
                 ,R.CUSTOMER_ID
                 ,R.CUSTOMER_CODE
                 ,R.CUSTOMER_NAME 
                 ,R.ACCOUNT_ID 
                 ,R.ACCOUNT_CODE 
                 ,R.DISCOUNT_ORDER_NUMBER 
                 ,R.DISCOUNT_METHOD 
                 ,R.CHECK_FLAG 
                 ,R.REMARK 
                 ,R.CREATED_BY 
                 ,R.CREATION_DATE 
                 ,R.LAST_UPDATED_BY 
                 ,R.LAST_UPDATE_DATE 
                 ,R.OLD_DISCOUNT_NUMBER 
                 ,R.ORDER_TYPE_ID 
                 ,R.SALES_CENTER_ID 
                 ,R.SALES_CENTER_CODE
                 ,R.SALES_CENTER_NAME  
                 ,R.VERSION 
                 ,R.OU_ID 
                 ,R.LIMIT_AMOUNT
                 ,'N' 
                 ,R.LINE_ID
                 ,R.RESULT_CHK_ID
                 ,R.SALES_MAIN_TYPE
                 ,R.DISCOUNT_PERIOD
                 ,R.CALCULATE_GROUP_NAME
                 ,R.CALCULATE_GROUP_TYPE
                 ,R.POLICY_ID
                 ,R.REF_MODEL
             );
             
             IF I > F_MULTIPLE_AMOUNT THEN
               EXIT;
             END IF;
             
           END LOOP;           
         END;   
         
         --如果余数不等于0，还需要在Y单行表写入一条记录
         IF F_REMAINDER_AMOUNT > 0 THEN 
            INSERT INTO T_POL_ORDER_LINES(
                LINE_ID 
               ,LINE_NUMBER 
               ,POLICY_ORDER_ID 
               ,LINE_AMOUNT 
               ,CHANGED_CASH_FLAG 
               ,CHOICE_FLAG 
               ,ITEM_ID 
               ,ITEM_CODE 
               ,ITEM_NAME 
               ,UOM_CODE 
               ,QUANTITY 
               ,LIST_PRICE 
               ,CUSTOMER_ID 
               ,CUSTOMER_CODE 
               ,CUSTOMER_NAME 
               ,ACCOUNT_ID 
               ,ACCOUNT_CODE 
               ,DISCOUNT_ORDER_NUMBER 
               ,DISCOUNT_METHOD 
               ,CHECK_FLAG 
               ,REMARK 
               ,CREATED_BY 
               ,CREATION_DATE 
               ,LAST_UPDATED_BY 
               ,LAST_UPDATE_DATE 
               ,OLD_DISCOUNT_NUMBER 
               ,ORDER_TYPE_ID 
               ,SALES_CENTER_ID 
               ,SALES_CENTER_CODE
               ,SALES_CENTER_NAME  
               ,VERSION 
               ,OU_ID 
               ,LIMIT_AMOUNT
               ,SPLIT_ORDER 
               ,SPLIT_ORDER_ID
               ,RESULT_CHK_ID
               ,SALES_MAIN_TYPE
               ,DISCOUNT_PERIOD
               ,CALCULATE_GROUP_NAME
               ,CALCULATE_GROUP_TYPE
               ,POLICY_ID
               ,REF_MODEL
            )VALUES(S_POLICY_Y_LINES.NEXTVAL
                 ,R.LINE_NUMBER
                 ,R.POLICY_ORDER_ID
                 ,F_REMAINDER_AMOUNT  --余数 
                 ,R.CHANGED_CASH_FLAG
                 ,R.CHOICE_FLAG 
                 ,R.ITEM_ID
                 ,R.ITEM_CODE
                 ,R.ITEM_NAME
                 ,R.UOM_CODE
                 ,R.QUANTITY
                 ,F_REMAINDER_AMOUNT   --余数
                 ,R.CUSTOMER_ID
                 ,R.CUSTOMER_CODE
                 ,R.CUSTOMER_NAME 
                 ,R.ACCOUNT_ID 
                 ,R.ACCOUNT_CODE 
                 ,R.DISCOUNT_ORDER_NUMBER 
                 ,R.DISCOUNT_METHOD 
                 ,R.CHECK_FLAG 
                 ,R.REMARK 
                 ,R.CREATED_BY 
                 ,R.CREATION_DATE 
                 ,R.LAST_UPDATED_BY 
                 ,R.LAST_UPDATE_DATE 
                 ,R.OLD_DISCOUNT_NUMBER 
                 ,R.ORDER_TYPE_ID 
                 ,R.SALES_CENTER_ID 
                 ,R.SALES_CENTER_CODE
                 ,R.SALES_CENTER_NAME  
                 ,R.VERSION 
                 ,R.OU_ID 
                 ,R.LIMIT_AMOUNT  --余数
                 ,'N' 
                 ,R.LINE_ID
                 ,R.RESULT_CHK_ID
                 ,R.SALES_MAIN_TYPE
                 ,R.DISCOUNT_PERIOD
                 ,R.CALCULATE_GROUP_NAME
                 ,R.CALCULATE_GROUP_TYPE
                 ,R.POLICY_ID
                 ,R.REF_MODEL
            );
         END IF;
      END IF;
    END LOOP; 
    
    
    FOR SP IN (SELECT * FROM T_POL_ORDER_LINES T 
                WHERE T.POLICY_ORDER_ID = P_POLICY_ORDER_ID 
                  AND NVL(T.SPLIT_ORDER,'N') = 'N'
                  AND NVL(T.CHANGED_CASH_FLAG,'N') = 'N'
                  AND T.RESULT_CHK_ID IS NOT NULL) 
    LOOP
        OS_MESSAGE := 'OK';
        PKG_POL_POLICY.P_POLICY_Y_TO_F(P_POLICY_CHK_ID, P_POLICY_ID, SP.LINE_ID, 
                                      P_ENTITY_ID, P_USER, OS_MESSAGE);
        IF (OS_MESSAGE <> 'OK') THEN
           EXIT;
        END IF;
    END LOOP; 
    
    RETURN OS_MESSAGE;
  END F_SPLIT_ORDER;

  -----------------------------------------------------------------------------
  --  政策邮件通知过程                                                       --
  -----------------------------------------------------------------------------
  PROCEDURE P_POLICY_MAIL(IN_POLICY_ID              IN NUMBER   --政策ID
                         ,OS_MESSAGE               OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
                         ) IS
    --报表明细
    CURSOR C_RESULT_LIST(IN_RESULT_DATE DATE) IS
      SELECT T.ACCOUNT_ID
        FROM T_POL_POLICY_RESULT T
       WHERE T.POLICY_ID = IN_POLICY_ID
         AND T.RESULT_DATE = IN_RESULT_DATE
         AND EXISTS(SELECT 1
                      FROM T_POL_POLICY_MAIL M
                     WHERE T.POLICY_ID = M.POLICY_ID
                       AND T.CUSTOMER_ID = M.CUSTOMER_ID
                       AND M.ENABLED_FLAG = 'Y'
                   )
       ORDER BY T.CUSTOMER_ID;
    R_RESULT_LIST            C_RESULT_LIST%ROWTYPE;

    S_REPORT_STATUS          VARCHAR2(40);
    D_REPORT_DATE            DATE;
  BEGIN
    OS_MESSAGE := 'OK';
    SAVEPOINT SP_POLICY_MAIL;
    --获取政策信息
    IF (OS_MESSAGE = 'OK') THEN
      BEGIN
        SELECT P.REPORT_STATUS
              ,P.REPORT_DATE
          INTO S_REPORT_STATUS
              ,D_REPORT_DATE
          FROM T_POL_POLICY P
         WHERE P.POLICY_ID = IN_POLICY_ID;
      EXCEPTION
        WHEN OTHERS THEN
          OS_MESSAGE := '获取政策信息出错！' || TO_CHAR(IN_POLICY_ID);
      END;
    END IF;
    --判断报表状态
    IF (NVL(S_REPORT_STATUS, 'NULL') <> 'Success') THEN
      OS_MESSAGE := '政策报表状态不为“成功”，不允许发送邮件！';
    END IF;
    --获取报表结果信息，发送邮件
    IF (OS_MESSAGE = 'OK') THEN
      FOR R_RESULT_LIST IN C_RESULT_LIST(D_REPORT_DATE) LOOP
        OS_MESSAGE := F_POLICY_SEND_EMAIL(IN_POLICY_ID, D_REPORT_DATE, R_RESULT_LIST.ACCOUNT_ID);
        IF OS_MESSAGE <> 'OK' THEN
          EXIT;
        END IF;
      END LOOP;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK TO SAVEPOINT SP_POLICY_MAIL;
      OS_MESSAGE := '政策邮件通知:' || SQLERRM;
  END;

  -----------------------------------------------------------------------------
  --  根据SQL取值函数（字符串），内部调用，不处理异常                                                        --
  -----------------------------------------------------------------------------
  FUNCTION F_GET_SQL_STR(IS_SQL                     VARCHAR2 --SQL脚本
                        ,IN_POLICY_ID               NUMBER --单据ID
                        ,IN_ENTITY_ID               NUMBER --主体ID
                        ,ID_REPORT_DATE             DATE   --统计日期
                        ,IN_ACCOUNT_ID              NUMBER --账户ID
                        ) RETURN VARCHAR2 IS
    N_CUR    NUMBER;
    N_ROW    NUMBER;
    S_RESULT VARCHAR2(4000);
  BEGIN
    --打开光标
    N_CUR := DBMS_SQL.OPEN_CURSOR;
    --解析动态SQL语句
    DBMS_SQL.PARSE(N_CUR, IS_SQL, DBMS_SQL.NATIVE);
    --绑定输入参数
    IF INSTR(IS_SQL, ':P_POLICY_ID', 1, 1) > 0 THEN
      DBMS_SQL.BIND_VARIABLE(N_CUR, ':P_POLICY_ID', IN_POLICY_ID);
    END IF;
    IF INSTR(IS_SQL, ':P_BILL_ID', 1, 1) > 0 THEN
      DBMS_SQL.BIND_VARIABLE(N_CUR, ':P_BILL_ID', IN_POLICY_ID);
    END IF;
    IF INSTR(IS_SQL, ':P_ENTITY_ID', 1, 1) > 0 THEN
      DBMS_SQL.BIND_VARIABLE(N_CUR, ':P_ENTITY_ID', IN_ENTITY_ID);
    END IF;
    IF INSTR(IS_SQL, ':P_REPORT_DATE', 1, 1) > 0 THEN
      DBMS_SQL.BIND_VARIABLE(N_CUR, ':P_REPORT_DATE', ID_REPORT_DATE);
    END IF;
    IF INSTR(IS_SQL, ':P_ACCOUNT_ID', 1, 1) > 0 THEN
      DBMS_SQL.BIND_VARIABLE(N_CUR, ':P_ACCOUNT_ID', IN_ACCOUNT_ID);
    END IF;
  
    --定义输出列
    DBMS_SQL.DEFINE_COLUMN(N_CUR, 1, S_RESULT, 4000);
    N_ROW := DBMS_SQL.EXECUTE(N_CUR);
    --获取输出值
    IF DBMS_SQL.FETCH_ROWS(N_CUR) > 0 THEN
      DBMS_SQL.COLUMN_VALUE(N_CUR, 1, S_RESULT);
    ELSE
      S_RESULT := '';
    END IF;
    --关闭光标
    DBMS_SQL.CLOSE_CURSOR(N_CUR);
    
    RETURN S_RESULT;
  END F_GET_SQL_STR;

  -----------------------------------------------------------------------------
  --  根据SQL取表格函数（字符串），内部调用，不处理异常                                                        --
  -----------------------------------------------------------------------------
  FUNCTION F_GET_SQL_TAB(IS_SQL                     VARCHAR2 --SQL脚本
                        ,IN_POLICY_ID               NUMBER --单据ID
                        ,IN_ENTITY_ID               NUMBER --主体ID
                        ,ID_REPORT_DATE             DATE   --统计日期
                        ,IN_ACCOUNT_ID              NUMBER --账户ID
                        ,IN_COLUMN_CNT              NUMBER --列数
                        ) RETURN VARCHAR2 IS
    TYPE STR_TAB IS VARRAY(20) OF VARCHAR2(1000);
    N_CUR    NUMBER;
    N_ROW    NUMBER;
    N_I      NUMBER;
    S_RESULT VARCHAR2(4000);
    S_VALUE  VARCHAR2(1000);
    S_ROW    VARCHAR2(1000);
    SA_COL   STR_TAB := STR_TAB('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
  BEGIN
    --打开光标
    N_CUR := DBMS_SQL.OPEN_CURSOR;
    --解析动态SQL语句
    DBMS_SQL.PARSE(N_CUR, IS_SQL, DBMS_SQL.NATIVE);
    --绑定输入参数
    IF INSTR(IS_SQL, ':P_POLICY_ID', 1, 1) > 0 THEN
      DBMS_SQL.BIND_VARIABLE(N_CUR, ':P_POLICY_ID', IN_POLICY_ID);
    END IF;
    IF INSTR(IS_SQL, ':P_BILL_ID', 1, 1) > 0 THEN
      DBMS_SQL.BIND_VARIABLE(N_CUR, ':P_BILL_ID', IN_POLICY_ID);
    END IF;
    IF INSTR(IS_SQL, ':P_ENTITY_ID', 1, 1) > 0 THEN
      DBMS_SQL.BIND_VARIABLE(N_CUR, ':P_ENTITY_ID', IN_ENTITY_ID);
    END IF;
    IF INSTR(IS_SQL, ':P_REPORT_DATE', 1, 1) > 0 THEN
      DBMS_SQL.BIND_VARIABLE(N_CUR, ':P_REPORT_DATE', ID_REPORT_DATE);
    END IF;
    IF INSTR(IS_SQL, ':P_ACCOUNT_ID', 1, 1) > 0 THEN
      DBMS_SQL.BIND_VARIABLE(N_CUR, ':P_ACCOUNT_ID', IN_ACCOUNT_ID);
    END IF;
  
    --定义输出列
    FOR N_I IN 1..IN_COLUMN_CNT
    LOOP
      DBMS_SQL.DEFINE_COLUMN(N_CUR, N_I, SA_COL(N_I), 1000);
    END LOOP;
    N_ROW := DBMS_SQL.EXECUTE(N_CUR);
    --获取输出值,表格本来带有<tr><td>[spl]</td></tr>
    --表格格式：<td>字段1</td><td>字段2</td><td>字段N</td></tr><tr><td>字段1</td><td>字段2</td><td>字段N</td>
    LOOP
      EXIT WHEN DBMS_SQL.FETCH_ROWS(N_CUR) <= 0;
      FOR N_I IN 1..IN_COLUMN_CNT
      LOOP
        DBMS_SQL.COLUMN_VALUE(N_CUR, N_I, SA_COL(N_I));
        S_VALUE := SA_COL(N_I);
        --处理转义
        IF S_VALUE IS NULL THEN
          S_VALUE := '&nbsp;';
        END IF;
        IF N_I = 1 THEN
          S_ROW := '<td>' || S_VALUE || '</td>'; 
        ELSE
          S_ROW := S_ROW || '<td>' || S_VALUE || '</td>';
        END IF;
      END LOOP;
      IF S_RESULT IS NULL THEN
        S_RESULT := S_ROW;
      ELSE
        S_RESULT := S_RESULT || '</tr><tr>' || S_ROW;
      END IF;
    END LOOP;
    
    --关闭光标
    DBMS_SQL.CLOSE_CURSOR(N_CUR);
    
    RETURN S_RESULT;
  END F_GET_SQL_TAB;

  -----------------------------------------------------------------------------
  --  根据政策ID、账户ID取收件人邮箱，用“;”分隔，内部调用，不处理异常                                                        --
  -----------------------------------------------------------------------------
  FUNCTION F_GET_MAIL_LIST(IN_POLICY_ID               NUMBER --单据ID
                          ,IN_ACCOUNT_ID              NUMBER --账户ID
                          ) RETURN VARCHAR2 IS
    S_RESULT VARCHAR2(4000);
  BEGIN
    --循环取邮箱
    FOR R_MAIL IN
    (
      SELECT DISTINCT
        M.E_MAIL
      FROM
        T_POL_POLICY_MAIL M
        ,T_CUSTOMER_ACCOUNT A
      WHERE
        M.CUSTOMER_ID = A.CUSTOMER_ID
        AND M.POLICY_ID = IN_POLICY_ID
        AND A.ACCOUNT_ID = IN_ACCOUNT_ID
    )
    LOOP
      IF S_RESULT IS NULL THEN
        S_RESULT := R_MAIL.E_MAIL;
      ELSE
        S_RESULT := S_RESULT || ';' || R_MAIL.E_MAIL;
      END IF;
    END LOOP;
    
    RETURN S_RESULT;
  END F_GET_MAIL_LIST;

  -----------------------------------------------------------------------------
  --  根据政策ID、账户ID取收件人邮箱，用“;”分隔，内部调用                                                        --
  -----------------------------------------------------------------------------
  FUNCTION F_GET_MAIL_REV_LIST
  (
    IN_MAIL_TEMPLATE_ID   IN    NUMBER --邮件模板ID
    ,IN_BILL_ID           IN    NUMBER --单据ID
    ,IN_ACCOUNT_ID        IN    NUMBER --账户ID
    ,IN_ENTITY_ID         IN    NUMBER --主体ID
    ,OS_MESSAGE           OUT   VARCHAR2 --返回出错信息
  ) RETURN VARCHAR2 IS
    S_SQL    VARCHAR2(20000);
    N_CUR    NUMBER;
    N_ROW    NUMBER;
    S_MAIL_ADDR VARCHAR2(4000);
    S_RESULT VARCHAR2(4000);
  BEGIN
    OS_MESSAGE := 'OK';
    --取模板定义的收件人SQL
    SELECT
      UPPER(MAIL_ADDR_SQL)
    INTO
      S_SQL
    FROM
      T_POL_EMAIL_TEMPLET
    WHERE
      TEMPLATE_ID = IN_MAIL_TEMPLATE_ID;
    
    --打开光标
    N_CUR := DBMS_SQL.OPEN_CURSOR;
    --解析动态SQL语句
    DBMS_SQL.PARSE(N_CUR, S_SQL, DBMS_SQL.NATIVE);
    --绑定输入参数
    IF INSTR(S_SQL, ':P_BILL_ID', 1, 1) > 0 THEN
      DBMS_SQL.BIND_VARIABLE(N_CUR, ':P_BILL_ID', IN_BILL_ID);
    END IF;
    IF INSTR(S_SQL, ':P_ENTITY_ID', 1, 1) > 0 THEN
      DBMS_SQL.BIND_VARIABLE(N_CUR, ':P_ENTITY_ID', IN_ENTITY_ID);
    END IF;
    IF INSTR(S_SQL, ':P_ACCOUNT_ID', 1, 1) > 0 THEN
      DBMS_SQL.BIND_VARIABLE(N_CUR, ':P_ACCOUNT_ID', IN_ACCOUNT_ID);
    END IF;
  
    --定义输出列
    DBMS_SQL.DEFINE_COLUMN(N_CUR, 1, S_MAIL_ADDR, 4000);
    N_ROW := DBMS_SQL.execute(N_CUR);
    --获取输出值
    S_RESULT := NULL;
    LOOP
      EXIT WHEN DBMS_SQL.FETCH_ROWS(N_CUR) <= 0;
      DBMS_SQL.COLUMN_VALUE(N_CUR, 1, S_MAIL_ADDR);
      IF S_RESULT IS NULL THEN
        S_RESULT := S_MAIL_ADDR;
      ELSE
        S_RESULT := S_RESULT || ';' || S_MAIL_ADDR;
      END IF;
    END LOOP;
    --关闭光标
    DBMS_SQL.CLOSE_CURSOR(N_CUR);
    RETURN S_RESULT;
  EXCEPTION
    --异常处理
    WHEN OTHERS THEN
      IF DBMS_SQL.IS_OPEN(N_CUR) THEN
        DBMS_SQL.CLOSE_CURSOR(N_CUR);
      END IF;
      OS_MESSAGE := 'SQL取值出错：' || SQLERRM;
      RETURN S_RESULT;
  END F_GET_MAIL_REV_LIST;

  -----------------------------------------------------------------------------
  --  取邮件标题，内部调用，不处理异常                                                        --
  -----------------------------------------------------------------------------
  FUNCTION F_GET_MAIL_TITLE(
    IN_MAIL_TEMPLATE_ID        NUMBER --邮件模板ID
    ,IS_MESSAGE_HEADER          VARCHAR2 --邮件标题
    ,IN_POLICY_ID              NUMBER --单据ID
    ,IN_ACCOUNT_ID             NUMBER --账户ID
    ,IN_ENTITY_ID              NUMBER --主体ID
    ,ID_REPORT_DATE            DATE --报表日期
  )
  RETURN VARCHAR2
  IS
    S_VALUE  VARCHAR2(200);
    S_MESSAGE_HEADER VARCHAR2(4000);
  BEGIN
    S_MESSAGE_HEADER := IS_MESSAGE_HEADER;
    --循环取邮件标题
    FOR R_DETAIL IN
    (
      SELECT
        SQL_SIGN
        ,SQL_SENTENCE
      FROM
        T_POL_EMAIL_TEMPLET_DETAIL
      WHERE
        TEMPLATE_ID = IN_MAIL_TEMPLATE_ID
        AND IS_USEFORTORC = 'T'
        AND INSTR(S_MESSAGE_HEADER,SQL_SIGN) > 0
    )
    LOOP
      S_VALUE := F_GET_SQL_STR(R_DETAIL.SQL_SENTENCE, IN_POLICY_ID, IN_ENTITY_ID, ID_REPORT_DATE, IN_ACCOUNT_ID);
      S_MESSAGE_HEADER := REPLACE(S_MESSAGE_HEADER, R_DETAIL.SQL_SIGN, S_VALUE); 
    END LOOP;
    
    RETURN S_MESSAGE_HEADER;
  END F_GET_MAIL_TITLE;

  -----------------------------------------------------------------------------
  --  取邮件内容，内部调用，不处理异常                                                        --
  -----------------------------------------------------------------------------
  FUNCTION F_GET_MAIL_CONTENT(
    IN_MAIL_TEMPLATE_ID        NUMBER --邮件模板ID
    ,IS_EMAIL_CONTENT          VARCHAR2 --邮件模板内容
    ,IN_POLICY_ID              NUMBER --单据ID
    ,IN_ACCOUNT_ID             NUMBER --账户ID
    ,IN_ENTITY_ID              NUMBER --主体ID
    ,ID_REPORT_DATE            DATE --报表日期
  )
  RETURN VARCHAR2
  IS
    S_VALUE  VARCHAR2(4000);
    N_COL_CNT NUMBER;
    N_I       NUMBER;
    S_EMAIL_CONTENT VARCHAR2(4000);
  BEGIN
    S_EMAIL_CONTENT := IS_EMAIL_CONTENT;
    --循环取邮件内容
    FOR R_DETAIL IN
    (
      SELECT
        SQL_SIGN
        ,SQL_SENTENCE
        ,IS_USEFORLIST
      FROM
        T_POL_EMAIL_TEMPLET_DETAIL
      WHERE
        TEMPLATE_ID = IN_MAIL_TEMPLATE_ID
        AND IS_USEFORTORC = 'C'
        AND INSTR(S_EMAIL_CONTENT,SQL_SIGN) > 0
    )
    LOOP
      IF R_DETAIL.IS_USEFORLIST = 'Y' THEN
        --列表方式需循环SQL取出的内容，拼接生成内容
        --为了减少程序改动，现通过模板中的约定标识符格式[XXX,N]，其中N表示列数
        N_I := INSTR(R_DETAIL.SQL_SIGN, ',');
        IF N_I = 0 THEN
          N_COL_CNT := 4;  --没有“,”则默认为4
        ELSE
          S_VALUE := SUBSTR(R_DETAIL.SQL_SIGN ,N_I+1, LENGTH(R_DETAIL.SQL_SIGN)-N_I-1);
          N_COL_CNT := TO_NUMBER(S_VALUE);
        END IF;
        S_VALUE := F_GET_SQL_TAB(R_DETAIL.SQL_SENTENCE, IN_POLICY_ID, IN_ENTITY_ID, ID_REPORT_DATE, IN_ACCOUNT_ID,N_COL_CNT);
      ELSE
        S_VALUE := F_GET_SQL_STR(R_DETAIL.SQL_SENTENCE, IN_POLICY_ID, IN_ENTITY_ID, ID_REPORT_DATE, IN_ACCOUNT_ID);
      END IF;
      S_EMAIL_CONTENT := REPLACE(S_EMAIL_CONTENT, '<td>' || R_DETAIL.SQL_SIGN || '</td>', S_VALUE); 
    END LOOP;
    
    RETURN S_EMAIL_CONTENT;
  END F_GET_MAIL_CONTENT;

  -----------------------------------------------------------------------------
  --  政策发邮件过程，成功则返回OK，否则返回出错信息                         --
  --  临时保留，于切换后检查是否有使用，没有使用则删除
  -----------------------------------------------------------------------------
  FUNCTION F_POLICY_SEND_EMAIL
  (
     IS_POLICY_ID    IN VARCHAR2  --政策ID
     ,ID_REPORT_DATE IN DATE      --报表日期
     ,IS_ACCOUNT_ID  IN VARCHAR2  --帐户ID
  )
  RETURN VARCHAR2
  IS
  --LANGUAGE JAVA
  --NAME 'com.midea.ims.policymanage.PolicyMailOpera.policyToMail(java.lang.String,java.util.Date,java.lang.String) return java.lang.String';
    S_RESULT VARCHAR2(4000);
  BEGIN
    P_POLICY_SEND_EMAIL(IS_POLICY_ID,ID_REPORT_DATE,IS_ACCOUNT_ID,S_RESULT);
    RETURN S_RESULT;
  END F_POLICY_SEND_EMAIL;

  -----------------------------------------------------------------------------
  --  政策发邮件过程，成功则返回OK，否则返回出错信息                         --
  --  由于JAVA需使用字符串处理，暂时使用字符串参数，以后再改成数值参数
  --  为了减少程序改动，现通过模板中的约定标识符格式[XXX,N]，其中N表示列数
  -----------------------------------------------------------------------------
  PROCEDURE P_POLICY_SEND_EMAIL
  (
     IS_POLICY_ID    IN VARCHAR2  --政策ID
     ,ID_REPORT_DATE IN DATE      --报表日期
     ,IS_ACCOUNT_ID  IN VARCHAR2  --帐户ID
     ,OS_MESSAGE     OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  )
  IS
    N_POLICY_ID        NUMBER;
    N_ACCOUNT_ID       NUMBER;
    N_MAIL_TEMPLATE_ID NUMBER;
    N_ENTITY_ID        NUMBER;
    N_I                NUMBER;
    N_COL_CNT          NUMBER;
    S_MSG              VARCHAR2(4000);
    S_MESSAGE_HEADER   VARCHAR2(4000);
    S_EMAIL_CONTENT    VARCHAR2(4000);
    S_VALUE            VARCHAR2(4000);
    S_MAIL_LIST        VARCHAR2(4000);
    S_USER_ID          VARCHAR2(32);
    S_STEP             VARCHAR2(40);
  BEGIN
    --OS_MESSAGE := F_POLICY_SEND_EMAIL(IS_POLICY_ID,ID_REPORT_DATE,IS_ACCOUNT_ID);
    OS_MESSAGE := 'OK';
    N_POLICY_ID := TO_NUMBER(IS_POLICY_ID);
    N_ACCOUNT_ID := TO_NUMBER(IS_ACCOUNT_ID);
    SAVEPOINT SP_POLICY_SEND_EMAIL;

    --获取发邮件模板
    S_STEP := '获取发邮件模板';
    SELECT
      MAIL_TEMPLATE_ID
      ,ENTITY_ID
    INTO
      N_MAIL_TEMPLATE_ID
      ,N_ENTITY_ID
    FROM
      T_POL_POLICY
    WHERE
      POLICY_ID = N_POLICY_ID;
      
    --取邮件标题、内容的定义
    S_STEP := '取邮件标题、内容定义';
    SELECT
      MESSAGE_HEADER
      ,EMAIL_CONTENT
    INTO
      S_MESSAGE_HEADER
      ,S_EMAIL_CONTENT
    FROM  
      T_POL_EMAIL_TEMPLET
    WHERE
      TEMPLATE_ID = N_MAIL_TEMPLATE_ID;
    
    --循环模板明细，更新邮件标题
    S_STEP := '更新邮件主题';
    FOR R_DETAIL IN
    (
      SELECT
        SQL_SIGN
        ,SQL_SENTENCE
      FROM
        T_POL_EMAIL_TEMPLET_DETAIL
      WHERE
        TEMPLATE_ID = N_MAIL_TEMPLATE_ID
        AND IS_USEFORTORC = 'T'
        AND INSTR(S_MESSAGE_HEADER,SQL_SIGN) > 0
    )
    LOOP
      S_STEP := '获取主题值' || R_DETAIL.SQL_SIGN;
      S_VALUE := F_GET_SQL_STR(R_DETAIL.SQL_SENTENCE, N_POLICY_ID, N_ENTITY_ID, ID_REPORT_DATE, N_ACCOUNT_ID);
      S_MESSAGE_HEADER := REPLACE(S_MESSAGE_HEADER, R_DETAIL.SQL_SIGN, S_VALUE); 
    END LOOP;
    
    --循环模板明细，更新邮件内容
    S_STEP := '更新邮件内容';
    FOR R_DETAIL IN
    (
      SELECT
        SQL_SIGN
        ,SQL_SENTENCE
        ,IS_USEFORLIST
      FROM
        T_POL_EMAIL_TEMPLET_DETAIL
      WHERE
        TEMPLATE_ID = N_MAIL_TEMPLATE_ID
        AND IS_USEFORTORC = 'C'
        AND INSTR(S_EMAIL_CONTENT,SQL_SIGN) > 0
    )
    LOOP
      IF R_DETAIL.IS_USEFORLIST = 'Y' THEN
        --列表方式需循环SQL取出的内容，拼接生成内容
        --为了减少程序改动，现通过模板中的约定标识符格式[XXX,N]，其中N表示列数
        S_STEP := '获取表格内容' || R_DETAIL.SQL_SIGN;
        N_I := INSTR(R_DETAIL.SQL_SIGN, ',');
        IF N_I = 0 THEN
          N_COL_CNT := 4;  --没有“,”则默认为4
        ELSE
          S_VALUE := SUBSTR(R_DETAIL.SQL_SIGN ,N_I+1, LENGTH(R_DETAIL.SQL_SIGN)-N_I-1);
          N_COL_CNT := TO_NUMBER(S_VALUE);
        END IF;
        S_VALUE := F_GET_SQL_TAB(R_DETAIL.SQL_SENTENCE, N_POLICY_ID, N_ENTITY_ID, ID_REPORT_DATE, N_ACCOUNT_ID,N_COL_CNT);
      ELSE
        S_STEP := '获取内容值' || R_DETAIL.SQL_SIGN;
        S_VALUE := F_GET_SQL_STR(R_DETAIL.SQL_SENTENCE, N_POLICY_ID, N_ENTITY_ID, ID_REPORT_DATE, N_ACCOUNT_ID);
      END IF;
      S_EMAIL_CONTENT := REPLACE(S_EMAIL_CONTENT, '<td>' || R_DETAIL.SQL_SIGN || '</td>', S_VALUE); 
    END LOOP;

    --取政策后台自动处理用户
    BEGIN
      S_USER_ID := PKG_BD.F_GET_PARAMETER_VALUE('POLICY_AUTO_USER',N_ENTITY_ID);
      OS_MESSAGE := 'OK';
    EXCEPTION
      WHEN OTHERS THEN
        OS_MESSAGE := '取参数POLICY_AUTO_USER出错:' || SQLERRM;
        S_MSG := PKG_BD.F_ADD_ERROR_LOG('PKG_POL_CAL.P_POLICY_SEND_EMAIL', NULL, OS_MESSAGE);
    END;

    --写发邮件信息表
    IF OS_MESSAGE = 'OK' THEN
      S_STEP := '获取邮件列表';
      S_MAIL_LIST := F_GET_MAIL_LIST(N_POLICY_ID, N_ACCOUNT_ID);
      S_STEP := '写发邮件信息';
      INSERT INTO T_POL_SEND_EMAIL
      (
        SEND_ID
        ,ENTITY_ID
        ,RECIPIENT_EMAIL
        ,MESSAGE_HEADER
        ,EMAIL_CONTENT
        ,SEND_STATE
        ,CREATED_BY
        ,CREATION_DATE
        ,LAST_UPDATED_BY
        ,LAST_UPDATE_DATE
      )
      VALUES
      (
        S_POL_SEND_EMAIL.NEXTVAL  --SEND_ID
        ,N_ENTITY_ID  --ENTITY_ID
        ,S_MAIL_LIST  --RECIPIENT_EMAIL
        ,S_MESSAGE_HEADER  --MESSAGE_HEADER
        ,S_EMAIL_CONTENT  --EMAIL_CONTENT
        ,'01'  --SEND_STATE  发送状态，状态：01 待发送、02 已发送、03 发送失败，从CODELIST中获取。
        ,S_USER_ID  --CREATED_BY
        ,SYSDATE  --CREATION_DATE
        ,S_USER_ID  --LAST_UPDATED_BY
        ,SYSDATE  --LAST_UPDATE_DATE
      );
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK TO SAVEPOINT SP_POLICY_SEND_EMAIL;
      OS_MESSAGE := '政策发邮件-' || S_STEP || SQLERRM;
  END P_POLICY_SEND_EMAIL;

  -----------------------------------------------------------------------------
  --  根据参数处理发邮件过程，由前台P_PUB_SEND_EMAIL调用   
  -- 测试邮件服务器：http://10.16.7.197/
  -- 测试邮箱：cimssystem / zXU2J4                                    --
  -----------------------------------------------------------------------------
  PROCEDURE P_SEND_EMAIL
  (
    IN_TEMPLATE_ID      IN  VARCHAR2    --发邮件模板ID
    ,IS_CONTENT_SQL     IN  VARCHAR2    --邮件内容SQL
    ,IS_MESSAGE_HEADER  IN  VARCHAR2    --邮件标题
    ,IS_EMAIL_CONTENT   IN  VARCHAR2    --邮件内容
    ,IS_MAIL_LIST       IN  VARCHAR2    --收件人邮箱清单，用“;”作为分隔符
    ,IN_BILL_ID         IN  NUMBER      --单据ID
    ,IN_ACCOUNT_ID      IN  NUMBER      --账户ID
    ,IN_ENTITY_ID       IN  NUMBER      --主体ID
    ,ID_REPORT_DATE     IN  DATE        --报表日期
  )
  IS
    S_MSG VARCHAR2(4000);
    S_MAIL_TITLE VARCHAR2(4000); --转换后的邮件标题
    S_MAIL_CONTENT VARCHAR2(4000); --转换后的邮件内容
    S_MAIL_LIST VARCHAR2(4000);  --收件人列表
    S_STEP VARCHAR2(40);
    N_CNT NUMBER;
  BEGIN
    S_MSG := 'OK';
    --通过动态光标检查是否有记录
    S_STEP := '检查是否有数据(' || TO_CHAR(IN_TEMPLATE_ID) || ')';
    N_CNT := F_GET_SQL_VALUE('SELECT COUNT(*) FROM (' || IS_CONTENT_SQL || ')',IN_BILL_ID,IN_ENTITY_ID,S_MSG);
      
    IF N_CNT > 0 THEN 
      --有记录则处理发邮件
      --取邮件标题
      S_STEP := '取邮件标题(' || TO_CHAR(IN_TEMPLATE_ID) || ')';
      S_MAIL_TITLE := F_GET_MAIL_TITLE(IN_TEMPLATE_ID ,IS_MESSAGE_HEADER, IN_BILL_ID, IN_ACCOUNT_ID, IN_ENTITY_ID, ID_REPORT_DATE);
        
      --取邮件内容
      S_STEP := '取邮件内容(' || TO_CHAR(IN_TEMPLATE_ID) || ')';
      S_MAIL_CONTENT := F_GET_MAIL_CONTENT(IN_TEMPLATE_ID ,IS_EMAIL_CONTENT, IN_BILL_ID, IN_ACCOUNT_ID, IN_ENTITY_ID, ID_REPORT_DATE);
        
      S_MAIL_LIST := IS_MAIL_LIST;
      IF S_MAIL_LIST = 'AUTO' THEN
        --取收件人列表
        S_MAIL_LIST := F_GET_MAIL_REV_LIST(IN_TEMPLATE_ID, IN_BILL_ID, IN_ACCOUNT_ID, IN_ENTITY_ID,S_MSG);
      END IF;
      
      --写发送邮件信息
      S_STEP := '写发送邮件信息(' || TO_CHAR(IN_TEMPLATE_ID) || ')';
      INSERT INTO T_POL_SEND_EMAIL
      (
        SEND_ID
        ,ENTITY_ID
        ,RECIPIENT_EMAIL
        ,MESSAGE_HEADER
        ,EMAIL_CONTENT
        ,SEND_STATE
        ,CREATED_BY
        ,CREATION_DATE
        ,LAST_UPDATED_BY
        ,LAST_UPDATE_DATE
      )
      VALUES
      (
        S_POL_SEND_EMAIL.NEXTVAL  --SEND_ID
        ,IN_ENTITY_ID  --ENTITY_ID
        ,S_MAIL_LIST  --RECIPIENT_EMAIL
        ,S_MAIL_TITLE  --MESSAGE_HEADER
        ,S_MAIL_CONTENT  --EMAIL_CONTENT
        ,'01'  --SEND_STATE  发送状态，状态：01 待发送、02 已发送、03 发送失败，从CODELIST中获取。
        ,'program'  --CREATED_BY
        ,SYSDATE  --CREATION_DATE
        ,'program'  --LAST_UPDATED_BY
        ,SYSDATE  --LAST_UPDATE_DATE
      );
      COMMIT;
    END IF;
      
    IF S_MSG <> 'OK' AND S_MSG <> 'SUCCESS' THEN
      S_MSG := PKG_BD.F_ADD_ERROR_LOG('PKG_POL_CAL.P_AUTO_SEND_EMAIL', NULL, substrb(S_MSG, 1, 800));
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      --若失败，则写入错误信息
      ROLLBACK;
      S_MSG := PKG_BD.F_ADD_ERROR_LOG('PKG_POL_CAL.P_PUB_SEND_EMAIL', NULL, substrb(S_STEP || SQLERRM || dbms_utility.format_error_backtrace, 1, 800));
  END P_SEND_EMAIL;

  -----------------------------------------------------------------------------
  --  根据参数处理发邮件过程，由前台JOB调用   
  -- 测试邮件服务器：http://10.16.7.197/
  -- 测试邮箱：cimssystem / zXU2J4                                    --
  -----------------------------------------------------------------------------
  PROCEDURE P_PUB_SEND_EMAIL
  (
    IS_TEMPLET_NAME     IN  VARCHAR2    --发邮件模板名称
    ,IS_MAIL_LIST       IN  VARCHAR2    --收件人邮箱清单，用“;”作为分隔符
  )
  IS
    N_TEMPLATE_ID NUMBER;  --模板ID
    S_MESSAGE_HEADER VARCHAR2(4000); --邮件标题
    S_EMAIL_CONTENT VARCHAR2(4000); --邮件内容
    S_CONTENT_SQL VARCHAR2(4000);
    S_DATA_SQL VARCHAR2(4000);
    S_MSG VARCHAR2(4000);
    S_STEP VARCHAR2(40);
    N_CUR NUMBER;
    N_ROW NUMBER;
    N_BILL_ID NUMBER;
    N_ENTITY_ID NUMBER;
  BEGIN
    
    BEGIN  
      --循环获取要自动发邮件的模板
      SELECT
        TEMPLATE_ID
        ,MESSAGE_HEADER
        ,EMAIL_CONTENT
        ,DATA_SQL
      INTO
        N_TEMPLATE_ID
        ,S_MESSAGE_HEADER
        ,S_EMAIL_CONTENT
        ,S_DATA_SQL
      FROM
        T_POL_EMAIL_TEMPLET
      WHERE
        TEMPLATE_NAME = IS_TEMPLET_NAME
        AND TRUNC(SYSDATE) BETWEEN BEGIN_DATE AND NVL(END_DATE,TRUNC(SYSDATE));
      S_MSG := 'OK';
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        S_MSG := '模板不存在：' || IS_TEMPLET_NAME;
    END;
    
    --取出邮件内容对应的SQL，检查是否有数据，标识约定为[sqlContent]
    S_STEP := '检查是否有数据(' || TO_CHAR(N_TEMPLATE_ID) || ')';
    SELECT
      SQL_SENTENCE
    INTO
      S_CONTENT_SQL
    FROM
      T_POL_EMAIL_TEMPLET_DETAIL
    WHERE
      TEMPLATE_ID = N_TEMPLATE_ID
      AND IS_USEFORTORC = 'C'
      AND SQL_SIGN LIKE '[sqlContent%]';

    IF S_DATA_SQL IS NULL THEN
      --无取数据SQL则只执行一次
      P_SEND_EMAIL(N_TEMPLATE_ID,S_CONTENT_SQL,S_MESSAGE_HEADER,S_EMAIL_CONTENT,IS_MAIL_LIST,0,0,0,NULL);
    ELSE
      BEGIN
        --有取数据SQL则循环SQL内容处理执行
        --打开光标
        N_CUR := DBMS_SQL.OPEN_CURSOR;
        --解析动态SQL语句
        DBMS_SQL.PARSE(N_CUR, S_DATA_SQL, DBMS_SQL.NATIVE);
      
        --定义输出列
        DBMS_SQL.DEFINE_COLUMN(N_CUR, 1, N_BILL_ID);
        DBMS_SQL.DEFINE_COLUMN(N_CUR, 2, N_ENTITY_ID);
        N_ROW := DBMS_SQL.execute(N_CUR);
        --获取数据，循环调用发邮件处理
        LOOP
          EXIT WHEN DBMS_SQL.FETCH_ROWS(N_CUR) <= 0;
          DBMS_SQL.COLUMN_VALUE(N_CUR, 1, N_BILL_ID);
          DBMS_SQL.COLUMN_VALUE(N_CUR, 2, N_ENTITY_ID);
          P_SEND_EMAIL(N_TEMPLATE_ID,S_CONTENT_SQL,S_MESSAGE_HEADER,S_EMAIL_CONTENT,IS_MAIL_LIST,N_BILL_ID,0,N_ENTITY_ID,NULL);
        END LOOP;
        --关闭光标
        DBMS_SQL.CLOSE_CURSOR(N_CUR);
      EXCEPTION
        WHEN OTHERS THEN
          S_MSG := '取邮件数据出错：' || SQLERRM;
          IF DBMS_SQL.IS_OPEN(N_CUR) THEN
            DBMS_SQL.CLOSE_CURSOR(N_CUR);
          END IF;
      END;
    END IF;
      
    IF S_MSG <> 'OK' AND S_MSG <> 'SUCCESS' THEN
      S_MSG := PKG_BD.F_ADD_ERROR_LOG('PKG_POL_CAL.P_PUB_SEND_EMAIL', NULL, substrb(S_MSG, 1, 800));
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      --若失败，则写入错误信息
      ROLLBACK;
      S_MSG := PKG_BD.F_ADD_ERROR_LOG('PKG_POL_CAL.P_PUB_SEND_EMAIL', NULL, substrb(S_STEP || SQLERRM || dbms_utility.format_error_backtrace, 1, 800));
  END P_PUB_SEND_EMAIL;

  -----------------------------------------------------------------------------
  --  自动根据SQL发邮件过程，由JOB调用                                       --
  -----------------------------------------------------------------------------
  PROCEDURE P_AUTO_SEND_EMAIL
  IS
    S_MAIL_LIST VARCHAR2(128);
    S_MAIL_TITLE VARCHAR2(4000);
    S_MAIL_CONTENT VARCHAR2(4000);
    S_SQL VARCHAR2(4000);
    N_CUR NUMBER;
    N_ROW NUMBER;
    N_CNT NUMBER;
    S_MSG VARCHAR2(1000);
    S_STEP VARCHAR2(40);
  BEGIN
    --根据系统参数获取要收邮件的邮箱清单
    S_STEP := '获取收邮箱';
    S_MAIL_LIST := PKG_BD.F_GET_PARAMETER_VALUE('SYSTEM_MGR_MAIL',NULL);
      
    --循环获取要自动发邮件的模板
    FOR R_MAIL IN
    (
      SELECT
        TEMPLATE_ID
        ,MESSAGE_HEADER
        ,EMAIL_CONTENT
      FROM
        T_POL_EMAIL_TEMPLET
      WHERE
        TEMPLATE_NAME LIKE '自动发邮件%'
        AND TRUNC(SYSDATE) BETWEEN BEGIN_DATE AND NVL(END_DATE,TRUNC(SYSDATE))
    )
    LOOP
      --取出邮件内容对应的SQL，检查是否有数据，标识约定为[sqlContent]
      S_STEP := '检查是否有数据(' || TO_CHAR(R_MAIL.TEMPLATE_ID) || ')';
      SELECT
        SQL_SENTENCE
      INTO
        S_SQL
      FROM
        T_POL_EMAIL_TEMPLET_DETAIL
      WHERE
        TEMPLATE_ID = R_MAIL.TEMPLATE_ID
        AND IS_USEFORTORC = 'C'
        AND SQL_SIGN LIKE '[sqlContent%]';
     
      --通过动态光标检查是否有记录
      N_CNT := F_GET_SQL_VALUE('SELECT COUNT(*) FROM (' || S_SQL || ')',0,0,S_MSG);
      
      IF N_CNT > 0 THEN 
        --有记录则处理发邮件
        --取邮件标题
        S_STEP := '取邮件标题(' || TO_CHAR(R_MAIL.TEMPLATE_ID) || ')';
        S_MAIL_TITLE := F_GET_MAIL_TITLE(R_MAIL.TEMPLATE_ID ,R_MAIL.MESSAGE_HEADER, 0, 0, 0, NULL);
        
        --取邮件内容
        S_STEP := '取邮件内容(' || TO_CHAR(R_MAIL.TEMPLATE_ID) || ')';
        S_MAIL_CONTENT := F_GET_MAIL_CONTENT(R_MAIL.TEMPLATE_ID ,R_MAIL.EMAIL_CONTENT, 0, 0, 0, NULL);
        
        --写发送邮件信息
        S_STEP := '写发送邮件信息(' || TO_CHAR(R_MAIL.TEMPLATE_ID) || ')';
        INSERT INTO T_POL_SEND_EMAIL
        (
          SEND_ID
          ,ENTITY_ID
          ,RECIPIENT_EMAIL
          ,MESSAGE_HEADER
          ,EMAIL_CONTENT
          ,SEND_STATE
          ,CREATED_BY
          ,CREATION_DATE
          ,LAST_UPDATED_BY
          ,LAST_UPDATE_DATE
        )
        VALUES
        (
          S_POL_SEND_EMAIL.NEXTVAL  --SEND_ID
          ,0  --ENTITY_ID
          ,S_MAIL_LIST  --RECIPIENT_EMAIL
          ,S_MAIL_TITLE  --MESSAGE_HEADER
          ,S_MAIL_CONTENT  --EMAIL_CONTENT
          ,'01'  --SEND_STATE  发送状态，状态：01 待发送、02 已发送、03 发送失败，从CODELIST中获取。
          ,'program'  --CREATED_BY
          ,SYSDATE  --CREATION_DATE
          ,'program'  --LAST_UPDATED_BY
          ,SYSDATE  --LAST_UPDATE_DATE
        );
        COMMIT;
      END IF;
      
      IF S_MSG <> 'SUCCESS' THEN
        S_MSG := PKG_BD.F_ADD_ERROR_LOG('PKG_POL_CAL.P_AUTO_SEND_EMAIL', NULL, substrb(S_MSG, 1, 800));
      END IF;
    END LOOP;
  EXCEPTION
    WHEN OTHERS THEN
      --若失败，则写入错误信息
      ROLLBACK;
      S_MSG := PKG_BD.F_ADD_ERROR_LOG('PKG_POL_CAL.P_AUTO_SEND_EMAIL', NULL, substrb(S_STEP || SQLERRM || dbms_utility.format_error_backtrace, 1, 800));
  END P_AUTO_SEND_EMAIL;

  -----------------------------------------------------------------------------
  --  政策计算调用过程，完成后调用邮件通知                                   --
  -----------------------------------------------------------------------------
  PROCEDURE P_POLICY_CAL_JOB_D(IN_ENTITY_ID              IN NUMBER   --主主体ID
                            ,ID_RESULT_DATE            IN DATE     --报表日期
                            ) IS

    --待计算政策列表
    --政策状态：5	已录入; 7	已关闭; 4	已返利; 1	已部分返利; 2	已作废; 3	已驳回; 6	已审核; 8	已送审
    --报表状态：Recalulate 需重算
    CURSOR C_POLICY_LIST IS
        SELECT P.POLICY_ID
             , P.MAIL_RATE
             , P.REPORT_RATE
             , P.REPORT_STATUS
          FROM T_POL_POLICY P
              ,T_POL_TYPE T
         WHERE P.POLICY_TYPE_ID = T.APPLY_TYPE_ID
           AND NVL(P.AUTO_FLAG, 'N') = 'Y'
           --AND T.IS_AUTO_FLG = 'Y'
           AND P.ENTITY_ID = IN_ENTITY_ID
           AND (  (TRUNC(SYSDATE)-1 BETWEEN P.BEGIN_DATE AND NVL(P.END_DATE, TRUNC(SYSDATE))
                   AND P.STATUS IN ('6', '1', '4', '5'))  --政策表状态，需为：'已审核', '已返利', '部分返利'，'已录入'
               OR (P.REPORT_STATUS = 'Recalulate') );
    R_POLICY_LIST C_POLICY_LIST%ROWTYPE;
    
    S_MESSAGE   VARCHAR2(4000);
    S_MSG       VARCHAR2(255);
    S_MAIL_FLAG VARCHAR2(1);
    S_NOW_DATE  VARCHAR2(30);
    S_CAL_FLAG  VARCHAR2(1);
    S_NOW_DAY   VARCHAR2(30);
    S_USER_ID   VARCHAR2(32);
    D_RESULT_DATE DATE;
    PRE_CALC_AMOUNT NUMBER;
  BEGIN

    --取政策后台自动处理用户
    BEGIN
      S_USER_ID := PKG_BD.F_GET_PARAMETER_VALUE('POLICY_AUTO_USER',IN_ENTITY_ID);
      S_MESSAGE := 'OK';
    EXCEPTION
      WHEN OTHERS THEN
        S_MESSAGE := '取参数POLICY_AUTO_USER出错:' || SQLERRM;
        S_MSG := PKG_BD.F_ADD_ERROR_LOG('PKG_POL_CAL.P_POLICY_CAL_JOB', NULL, S_MESSAGE);
    END;
    
    IF S_MESSAGE = 'OK' THEN
      --报表日期为空，则取昨天
      IF ID_RESULT_DATE IS NULL THEN
        D_RESULT_DATE := TRUNC(SYSDATE)-1;
      ELSE
        D_RESULT_DATE := ID_RESULT_DATE;
      END IF;
      --循环要计算的政策
      FOR R_POLICY_LIST IN C_POLICY_LIST
      LOOP
        S_MESSAGE := 'OK';
        --判断是否需计算
        S_CAL_FLAG := 'N';
        IF (S_MESSAGE = 'OK') THEN
          --获取报表日期的星期序号
          S_NOW_DATE := TO_CHAR(D_RESULT_DATE,'D');
          --获取报表日期下一日的日数
          S_NOW_DAY := TO_CHAR(D_RESULT_DATE + 1,'DD');
          --判断报表计算频率设置
          IF (R_POLICY_LIST.REPORT_RATE = 'Everyday' OR R_POLICY_LIST.REPORT_RATE IS NULL) THEN  --每天
            S_CAL_FLAG := 'Y';
          ELSIF (R_POLICY_LIST.REPORT_RATE = 'Sunday') AND (S_NOW_DATE = '1') THEN  --每周日
            S_CAL_FLAG := 'Y';
          ELSIF (R_POLICY_LIST.REPORT_RATE = 'Monday') AND (S_NOW_DATE = '2') THEN  --每周一
            S_CAL_FLAG := 'Y';
          ELSIF (R_POLICY_LIST.REPORT_RATE = 'Tuesday') AND (S_NOW_DATE = '3') THEN  --每周二
            S_CAL_FLAG := 'Y';
          ELSIF (R_POLICY_LIST.REPORT_RATE = 'Wednesday') AND (S_NOW_DATE = '4') THEN  --每周三
            S_CAL_FLAG := 'Y';
          ELSIF (R_POLICY_LIST.REPORT_RATE = 'Thursday') AND (S_NOW_DATE = '5') THEN  --每周四
            S_CAL_FLAG := 'Y';
          ELSIF (R_POLICY_LIST.REPORT_RATE = 'Friday') AND (S_NOW_DATE = '6') THEN  --每周五
            S_CAL_FLAG := 'Y';
          ELSIF (R_POLICY_LIST.REPORT_RATE = 'Saturday') AND (S_NOW_DATE = '7') THEN  --每周六
            S_CAL_FLAG := 'Y';
          --ELSIF (R_POLICY_LIST.REPORT_RATE = '每月末') AND (S_NOW_DAY = '01') THEN
          --  S_CAL_FLAG := 'Y';
          END IF;
          --若为“需重算“，则不管频率设置
          IF (R_POLICY_LIST.REPORT_STATUS = 'Recalulate') THEN
            S_CAL_FLAG := 'Y';
          END IF;
        END IF;
        --调用政策计算过程，用户需业务指定，临时用CIMS
        IF (S_MESSAGE = 'OK') AND (S_CAL_FLAG = 'Y') THEN
          P_POLICY_CALCULATE(R_POLICY_LIST.POLICY_ID
                            ,D_RESULT_DATE
                            ,S_USER_ID
                            ,'N'
                            ,PRE_CALC_AMOUNT
                            ,S_MESSAGE);
        END IF;
        --若成功，则提交事务
        IF (S_MESSAGE = 'OK') THEN
          COMMIT;
        ELSE
        --若失败，则写入错误信息
          ROLLBACK;
          --写入政策错误信息        
          UPDATE T_POL_POLICY T
             SET T.REPORT_STATUS = 'Error'
               , T.REPORT_ERR_MSG = SUBSTR(S_MESSAGE, 1, 4000)
               , T.LAST_UPDATED_BY = S_USER_ID
               , T.LAST_UPDATE_DATE = SYSDATE
           WHERE T.POLICY_ID = R_POLICY_LIST.POLICY_ID;
          --写入公共错误日志表
          S_MSG := PKG_BD.F_ADD_ERROR_LOG('PKG_POL_CAL.P_POLICY_CALCULATE', NULL, S_MESSAGE);
          COMMIT;
        END IF;
        
        --判断是否需提交邮件
        S_MAIL_FLAG := 'N';
        IF (S_MESSAGE = 'OK') THEN
          S_NOW_DATE := TO_CHAR(D_RESULT_DATE,'D'); 
          IF (R_POLICY_LIST.MAIL_RATE = 'Everyday') THEN  --每天
            S_MAIL_FLAG := 'Y';
          ELSIF (R_POLICY_LIST.MAIL_RATE = 'Sunday') AND (S_NOW_DATE = '1') THEN  --每周日
            S_MAIL_FLAG := 'Y';
          ELSIF (R_POLICY_LIST.MAIL_RATE = 'Monday') AND (S_NOW_DATE = '2') THEN  --每周一
            S_MAIL_FLAG := 'Y';
          ELSIF (R_POLICY_LIST.MAIL_RATE = 'Tuesday') AND (S_NOW_DATE = '3') THEN  --每周二
            S_MAIL_FLAG := 'Y';
          ELSIF (R_POLICY_LIST.MAIL_RATE = 'Wednesday') AND (S_NOW_DATE = '4') THEN  --每周三
            S_MAIL_FLAG := 'Y';
          ELSIF (R_POLICY_LIST.MAIL_RATE = 'Thursday') AND (S_NOW_DATE = '5') THEN  --每周四
            S_MAIL_FLAG := 'Y';
          ELSIF (R_POLICY_LIST.MAIL_RATE = 'Friday') AND (S_NOW_DATE = '6') THEN  --每周五
            S_MAIL_FLAG := 'Y';
          ELSIF (R_POLICY_LIST.MAIL_RATE = 'Saturday') AND (S_NOW_DATE = '7') THEN  --每周六
            S_MAIL_FLAG := 'Y';
          END IF;
        END IF;
        --提交邮件通知
        IF (S_MESSAGE = 'OK') AND (S_MAIL_FLAG = 'Y') THEN
          P_POLICY_MAIL(R_POLICY_LIST.POLICY_ID
                       ,S_MESSAGE);
          --若成功，则提交事务
          IF (S_MESSAGE = 'OK') THEN
            COMMIT;
          ELSE
            --若失败，则写入错误信息
            ROLLBACK;
            S_MSG := PKG_BD.F_ADD_ERROR_LOG('PKG_POL_CAL.P_POLICY_MAIL', NULL, S_MESSAGE);
          END IF;
        END IF;
      END LOOP;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      --若失败，则写入错误信息
      ROLLBACK;
      S_MSG := PKG_BD.F_ADD_ERROR_LOG('PKG_POL_CAL.P_POLICY_CAL_JOB', NULL, SQLERRM);
  END;

  -----------------------------------------------------------------------------
  --  政策计算调用过程，完成后调用邮件通知，指定日期为昨天                                   --
  -----------------------------------------------------------------------------
  PROCEDURE P_POLICY_CAL_JOB(IN_ENTITY_ID              IN NUMBER   --主主体ID
                            ) IS
  BEGIN
    P_POLICY_CAL_JOB_D(IN_ENTITY_ID,NULL);
  END P_POLICY_CAL_JOB;
  
  -----------------------------------------------------------------------------
  --  政策计算调用过程：马上重算。不执行邮件通知                             --
  -----------------------------------------------------------------------------
  PROCEDURE P_POLICY_CAL_JOB_NOW_D(IN_ENTITY_ID              IN NUMBER   --主体ID
                                ,ID_RESULT_DATE            IN DATE     --报表日期
                                ) IS

    --待计算政策列表
    CURSOR C_POLICY_LIST IS
        SELECT P.POLICY_ID
          FROM T_POL_POLICY P
         WHERE P.ENTITY_ID = IN_ENTITY_ID
           AND (P.REPORT_STATUS = 'Recalulate');  --需重算
    R_POLICY_LIST C_POLICY_LIST%ROWTYPE;
    
    S_MESSAGE   VARCHAR2(4000);
    S_MSG       VARCHAR2(255);
    S_USER_ID   VARCHAR2(32);
    D_RESULT_DATE DATE;
    PRE_CALC_AMOUNT NUMBER;
  BEGIN

    --取政策后台自动处理用户
    BEGIN
      S_USER_ID := PKG_BD.F_GET_PARAMETER_VALUE('POLICY_AUTO_USER',IN_ENTITY_ID);
      S_MESSAGE := 'OK';
    EXCEPTION
      WHEN OTHERS THEN
        S_MESSAGE := '取参数POLICY_AUTO_USER出错:' || SQLERRM;
        S_MSG := PKG_BD.F_ADD_ERROR_LOG('PKG_POL_CAL.P_POLICY_CAL_JOB_NOW', NULL, S_MESSAGE);
    END;
    
    IF S_MESSAGE = 'OK' THEN
      --报表日期为空，则取昨天
      IF ID_RESULT_DATE IS NULL THEN
        D_RESULT_DATE := TRUNC(SYSDATE)-1;
      ELSE
        D_RESULT_DATE := ID_RESULT_DATE;
      END IF;
      --循环要重算的政策
      FOR R_POLICY_LIST IN C_POLICY_LIST
      LOOP
        S_MESSAGE := 'OK';
        --调用过程
        P_POLICY_CALCULATE(R_POLICY_LIST.POLICY_ID
                          ,D_RESULT_DATE
                          ,'CIMS'
                          ,'N'
                          ,PRE_CALC_AMOUNT
                          ,S_MESSAGE);
        --若成功，则提交事务
        IF (S_MESSAGE = 'OK') THEN
          COMMIT;
        ELSE
        --若失败，则写入错误信息
          ROLLBACK;
          --写入政策错误信息        
          UPDATE T_POL_POLICY T
             SET T.REPORT_STATUS = 'Error'
               , T.REPORT_ERR_MSG = SUBSTR(S_MESSAGE, 1, 4000)
               , T.LAST_UPDATED_BY = 'CIMS'
               , T.LAST_UPDATE_DATE = SYSDATE
           WHERE T.POLICY_ID = R_POLICY_LIST.POLICY_ID;
          --写入公共错误日志表
          S_MSG := PKG_BD.F_ADD_ERROR_LOG('PKG_POL_CAL.P_POLICY_CALCULATE', NULL, S_MESSAGE);
          COMMIT;
        END IF;
      END LOOP;
    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      --若失败，则写入错误信息
      ROLLBACK;
      S_MSG := PKG_BD.F_ADD_ERROR_LOG('PKG_POL_CAL.P_POLICY_CAL_JOB_NOW', NULL, SQLERRM);
  END;

  -----------------------------------------------------------------------------
  --  政策计算调用过程：马上重算。不执行邮件通知，指定日期为昨天                             --
  -----------------------------------------------------------------------------
  PROCEDURE P_POLICY_CAL_JOB_NOW(IN_ENTITY_ID              IN NUMBER   --主体ID
                                ) IS
  BEGIN
    P_POLICY_CAL_JOB_NOW_D(IN_ENTITY_ID, NULL);
  END P_POLICY_CAL_JOB_NOW;
  
  -----------------------------------------------------------------------------
  --  政策申请，计算工程机申请金额及返利金额           --
  -----------------------------------------------------------------------------
  PROCEDURE P_POLICY_CAL_PG(P_ENTITY_ID              IN NUMBER   --主体ID
                            ,P_POLICY_ID          IN NUMBER     --政策ID
                            ,P_CAL_TYPE           IN VARCHAR2  --计算类型，申请金额/返利金额
                            ,P_CONDITION_SQL      IN VARCHAR2 DEFAULT NULL--条件脚本
                            ,P_APPLY_AMOUNT      OUT NUMBER    --申请金额
                            ,P_USER_ID            IN VARCHAR2   --用户账号
                            ,P_MESSAGE           OUT VARCHAR2   --成功则返回“OK”，否则返回出错信息
                                ) IS
    V_AMOUNT_CONDITION_SQL VARCHAR2(2000);
    V_PG_SQL VARCHAR2(2000);
    N_CUR    NUMBER;
    N_ROW    NUMBER;
    N_RESULT NUMBER;
    V_ACC_ID  NUMBER;  --账户ID
    V_BILL_DATE    VARCHAR2(10);   --单据日期
    V_PRICE_LIST_ID NUMBER;--价格列表ID
    V_MESSAGE VARCHAR2(200);
    V_SUBSIDY_STD NUMBER;--补贴标准
    V_SUM_APPLY_QTY NUMBER;
    V_SALES_CENTER_ID NUMBER;
    V_PG_DISCOUNT_CAL_TYPE VARCHAR2(200);
    V_SUM_INSTALL_QTY NUMBER;
    V_ACCOUNT_ID NUMBER;
  BEGIN
    P_MESSAGE := 'OK';
    /*
    --根据状态处理申请金额或返利金额
    --获取政策信息
    IF (P_MESSAGE = 'OK') THEN
      BEGIN
        SELECT PL.AMOUNT_CONDITION_SQL, PY.ACCOUNT_ID, 
               TO_CHAR(PY.ORDER_DATE, 'YYYYMMDD'), PY.SALES_CENTER_ID, PY.ACCOUNT_ID
          INTO V_AMOUNT_CONDITION_SQL, V_ACC_ID, V_BILL_DATE, V_SALES_CENTER_ID, V_ACCOUNT_ID
          FROM T_POL_POLICY PY
              ,T_POL_TYPE PT
              ,T_POL_POLICY_LINE PL
           WHERE PY.POLICY_ID = P_POLICY_ID
             AND PY.POLICY_TYPE_ID = PT.APPLY_TYPE_ID
             AND PY.ENTITY_ID = P_ENTITY_ID
             AND PY.POLICY_ID = PL.POLICY_ID
             AND PT.PG_APPLY_FLAG = 'Y';
      EXCEPTION
        WHEN OTHERS THEN
          P_MESSAGE := '获取政策信息出错！' || TO_CHAR(P_POLICY_ID);
      END;
    END IF;
    
    IF P_CAL_TYPE = 'APPLY' THEN
    
      --申请金额需要删除已经产生的历史记录
      DELETE FROM t_pol_policy_pg_subsidy_detail PD
       WHERE PD.POLICY_ID = P_POLICY_ID;
      
      --1、先从工程机表获取数据
      IF P_CONDITION_SQL IS NOT NULL THEN
        V_PG_SQL := 'SELECT APPLY_ID FROM V_CIMS_PG_APPLY_V2 '||
                    ' WHERE '|| P_CONDITION_SQL;
      ELSE        
        V_PG_SQL := 'SELECT PA.APPLY_ID FROM V_CIMS_PG_APPLY_V2 PA'||
                    ' WHERE '|| V_AMOUNT_CONDITION_SQL;
      END IF;
      
      V_PG_SQL    := UPPER(V_PG_SQL);
      --打开光标
      N_CUR := DBMS_SQL.OPEN_CURSOR;
      --解析动态SQL语句
      DBMS_SQL.PARSE(N_CUR, V_PG_SQL, DBMS_SQL.NATIVE);
      --绑定输入参数
      IF INSTR(V_PG_SQL, ':P_POLICY_ID', 1, 1) > 0 THEN
        DBMS_SQL.BIND_VARIABLE(N_CUR,
                               ':P_POLICY_ID',
                               P_POLICY_ID);
      END IF;
      IF INSTR(V_PG_SQL, ':P_ENTITY_ID', 1, 1) > 0 THEN
        DBMS_SQL.BIND_VARIABLE(N_CUR,
                               ':P_ENTITY_ID',
                               P_ENTITY_ID);
      END IF;
    
      --定义输出列
      DBMS_SQL.DEFINE_COLUMN(N_CUR, 1, N_RESULT);
      N_ROW := DBMS_SQL.execute(N_CUR);
          
      LOOP         
        EXIT WHEN DBMS_SQL.FETCH_ROWS(N_CUR)<=0; --FETCH_ROWS在结果集中移动游标，如果未抵达末尾，返回1。                  
        DBMS_SQL.COLUMN_VALUE(N_CUR, 1, N_RESULT); --将当前行的查询结果写入上面定义的列中。                    

        insert into t_pol_policy_pg_subsidy_detail
          (detail_id,
           policy_id,
           apply_id,
           apply_date,
           apply_code,
           user_firm,
           --item_id,
           item_code,
           item_desc,
           uom_code,
           apply_qty,
           sales_price,
           sales_amount,
           po_price,
           po_amount,
           loss_price,
           loss_amount,
           subsidy_std,
           subsidy_amount,
           install_qty,
           ratio,
           entity_id,
           created_by,
           creation_date,
           last_updated_by,
           last_update_date,
           account_id
           )
          SELECT s_pol_pg_subsidy_detail.nextval,
                 P_POLICY_ID,
                 N_RESULT,
                 PA.APPLY_DATE,
                 PA.APPLY_CODE,
                 PA.USER_FIRM,
                 --PAL.MATERIAL_ID,
                 PAL.MATERIAL_CODE,
                 PAL.DESCRIPTION,
                 DECODE(PAL.UOM_CODE, '台', 'Tai', '套', 'Set'),
                 PAL.LAST_QUANTITY,
                 PAL.OVER_PRICE,
                 NVL(PAL.LAST_QUANTITY, 0) * NVL(PAL.OVER_PRICE, 0),
                 0,
                 0,
                 0,
                 0,
                 0,
                 0,
                 0,
                 1,  --比率默认为1
                 P_ENTITY_ID,
                 P_USER_ID,
                 SYSDATE,
                 P_USER_ID,
                 SYSDATE,
                 V_ACCOUNT_ID
            FROM 
                 V_CIMS_PG_APPLY_V2 PA,
                 (SELECT PL.APPLY_ID, PL.MATERIAL_ID, PL.MATERIAL_CODE,
                         PL.DESCRIPTION, PL.UOM_CODE, SUM(PL.LAST_QUANTITY) LAST_QUANTITY,
                         MAX(PL.OVER_PRICE) OVER_PRICE
                   FROM 
                    V_CIMS_PG_APPLY_LINE_V2 PL
                  WHERE PL.APPLY_ID =  N_RESULT
                  GROUP BY PL.APPLY_ID, PL.MATERIAL_ID, PL.MATERIAL_CODE, PL.DESCRIPTION, PL.UOM_CODE
                  ) PAL
           WHERE PA.APPLY_ID = PAL.APPLY_ID
             AND PA.APPLY_ID = N_RESULT
              ;
           
      END LOOP;      
      dbms_sql.close_cursor(N_CUR); --关闭游标
      
      --2、获取价格列表的价格
      BEGIN
        PKG_BD_PRICE.P_GET_PRICE_LIST_ID(P_ENTITY_ID,
                            V_ACC_ID,
                            V_BILL_DATE,
                            V_PRICE_LIST_ID,
                            V_MESSAGE
                            );
        EXCEPTION 
          WHEN OTHERS THEN
            P_MESSAGE := '无配置中心价格列表！' || TO_CHAR(P_POLICY_ID);
      END;
      IF V_PRICE_LIST_ID <> 0 THEN
        UPDATE T_POL_POLICY_PG_SUBSIDY_DETAIL PD
          SET PD.PO_PRICE = (SELECT BL.LIST_PRICE 
                                       FROM T_BD_PRICE_LIST BP,
                                           T_BD_PRICE_LINE BL
                                      WHERE BP.PRICE_LIST_ID = V_PRICE_LIST_ID
                                        and BP.PRICE_LIST_ID = BL.PRICE_LIST_ID
                                        AND BL.ITEM_CODE = PD.ITEM_CODE
                                        AND TRUNC(SYSDATE) BETWEEN BL.BEGIN_DATE AND NVL(BL.END_DATE, TRUNC(SYSDATE)+1)
                                      
                            )
         WHERE PD.POLICY_ID = P_POLICY_ID;
      END IF;
      
      --更新比率, 柜机、挂机为2
      UPDATE T_POL_POLICY_PG_SUBSIDY_DETAIL PD
         SET PD.RATIO = DECODE(PD.UOM_CODE, 'Tai', 0.5, 'Set', 1) * 
                       NVL((SELECT UC.CODE_VALUE
                          FROM T_BD_ITEM BI,
                               UP_CODELIST UC
                         WHERE BI.ITEM_CODE = PD.ITEM_CODE
                           AND BI.ENTITY_ID = P_ENTITY_ID
                           AND BI.SALES_SUB_TYPE = UC.CODE_NAME
                           AND UC.CODETYPE = 'ITEM_RATIO'), 1)
         WHERE PD.POLICY_ID = P_POLICY_ID; 
      
      --汇总采购金额
      UPDATE T_POL_POLICY_PG_SUBSIDY_DETAIL PD
         SET PD.PO_AMOUNT = NVL(PD.PO_PRICE, 0) * NVL(PD.APPLY_QTY, 0), --* NVL(PD.RATIO, 1)
             PD.LOSS_PRICE = NVL(PD.SALES_PRICE, 0) - NVL(PD.PO_PRICE, 0),
             PD.LOSS_AMOUNT = (NVL(PD.SALES_PRICE, 0) - NVL(PD.PO_PRICE, 0)) * NVL(PD.APPLY_QTY, 0) --* NVL(PD.RATIO, 1) --计算亏损金额
       WHERE PD.POLICY_ID = P_POLICY_ID; 

      SELECT SUM(NVL(PD.APPLY_QTY, 0) * NVL(PD.RATIO, 1))  --补贴标准按 申请数量乘以 倍率 计算，补贴金额保持不变
        INTO V_SUM_APPLY_QTY
        FROM T_POL_POLICY_PG_SUBSIDY_DETAIL PD
        WHERE PD.POLICY_ID = P_POLICY_ID;
         
      --获取兑现标准
      IF V_SUM_APPLY_QTY <> 0 THEN
        BEGIN
          SELECT PSL.SUBSIDY_STD
            INTO V_SUBSIDY_STD
            FROM T_POL_POLICY_PG_STD_RELA PSR,
                 T_POL_POLICY_PG_STD_LINE PSL
            WHERE PSR.SALES_CENTER_ID = V_SALES_CENTER_ID
              AND PSR.ENTITY_ID = P_ENTITY_ID
              AND PSR.STD_ID = PSL.STD_ID
              AND V_SUM_APPLY_QTY >= PSL.BEGIN_QTY
              AND V_SUM_APPLY_QTY < NVL(PSL.END_QTY, V_SUM_APPLY_QTY +1)
              AND TRUNC(SYSDATE) BETWEEN PSR.BEGIN_DATE AND NVL(PSR.END_DATE, TRUNC(SYSDATE)+1);
         EXCEPTION 
           WHEN OTHERS THEN
            P_MESSAGE := '无配置中心与补贴标准关系，无法获取补贴标准！' || TO_CHAR(P_POLICY_ID);
        END;
      ELSE
        P_MESSAGE := '申请金额为0，无法获取补贴标准！' || TO_CHAR(P_POLICY_ID);
      END IF;
      
      --计算亏损金额
      UPDATE T_POL_POLICY_PG_SUBSIDY_DETAIL PD
         SET PD.SUBSIDY_STD = NVL(V_SUBSIDY_STD, 0)--,
             --PD.SUBSIDY_AMOUNT =  NVL(PD.SUBSIDY_STD, NVL(V_SUBSIDY_STD, 0)) * PD.APPLY_QTY * NVL(PD.RATIO, 1)
       WHERE PD.POLICY_ID = P_POLICY_ID; 
      
      -- 亏损金额 < 补贴标准 以亏损金额为准 亏损金额 > 补贴标准， 以补贴标准为准
      UPDATE T_POL_POLICY_PG_SUBSIDY_DETAIL PD
         SET PD.SUBSIDY_STD = DECODE(SIGN(PD.LOSS_PRICE), 1, 0,   --亏损金额为0， 不补贴
                                                          -1, DECODE(SIGN(PD.SUBSIDY_STD + PD.LOSS_PRICE), --亏损金额为负数
                                                                     1, ABS(PD.LOSS_PRICE), --补贴标准+亏损金额 > 0, 补贴亏损金额
                                                                     -1, PD.SUBSIDY_STD,    --补贴标准+亏损金额 < 0, 补贴补贴标准
                                                                     0, PD.SUBSIDY_STD),   -- 0 , 0
                                                          0)
       WHERE PD.POLICY_ID = P_POLICY_ID; 

      --计算亏损金额
      UPDATE T_POL_POLICY_PG_SUBSIDY_DETAIL PD
         SET PD.SUBSIDY_AMOUNT =  NVL(PD.SUBSIDY_STD,0) * PD.APPLY_QTY --* NVL(PD.RATIO, 1) --补贴金额按补贴标准 * 申请数量
       WHERE PD.POLICY_ID = P_POLICY_ID; 
              
    ELSIF P_CAL_TYPE = 'DISCOUNT'THEN
      BEGIN
        PKG_BD.P_GET_PARAMETER_VALUE
                  ('PG_DISCOUNT_CAL_TYPE',
                   P_ENTITY_ID,
                   null,
                   null,
                   V_PG_DISCOUNT_CAL_TYPE
                  );
        EXCEPTION 
          WHEN OTHERS THEN
            P_MESSAGE :='无配置系统参数：PG_DISCOUNT_CAL_TYPE！' || TO_CHAR(P_POLICY_ID);
      END;
      --若是销售，以开单金额更新安装数量
      IF V_PG_DISCOUNT_CAL_TYPE = 'SALE' THEN
        UPDATE T_POL_POLICY_PG_SUBSIDY_DETAIL PD
           SET PD.INSTALL_QTY = (SELECT SUM(PAL.ALREADY_PICK_QUANTITY)
                                    FROM 
                                       V_CIMS_PG_APPLY_V2 PA,
                                       V_CIMS_PG_APPLY_LINE_V2 PAL
                                  WHERE PA.APPLY_ID = PAL.APPLY_ID
                                    AND PA.APPLY_ID = PD.APPLY_ID
                                    AND PD.ITEM_CODE = PAL.MATERIAL_CODE
                                )
         WHERE PD.POLICY_ID = P_POLICY_ID; 
         
       
         
      --若是安装，以开单金额更新安装数量
      ELSIF V_PG_DISCOUNT_CAL_TYPE = 'INSTALL' THEN 
        UPDATE T_POL_POLICY_PG_SUBSIDY_DETAIL PD
           SET PD.INSTALL_QTY = NVL((SELECT SUM(PS.QUANTITY)
                                    FROM 
                                       INTF_POL_CSS_INSTALL_CARD_SUM PS
                                  WHERE PS.APPLY_CODE = PD.APPLY_CODE
                                    AND PS.MATERIAL_CODE = PD.ITEM_CODE
                                ),0)
         WHERE PD.POLICY_ID = P_POLICY_ID;         
      END IF;  
      
      SELECT SUM(NVL(PD.INSTALL_QTY, 0) * NVL(PD.RATIO, 1))  --安装数量 * 倍率
        INTO V_SUM_INSTALL_QTY
        FROM T_POL_POLICY_PG_SUBSIDY_DETAIL PD
        WHERE PD.POLICY_ID = P_POLICY_ID;
         
      V_SUBSIDY_STD := 0;
      
      --获取兑现标准
      IF V_SUM_INSTALL_QTY <> 0 THEN
        BEGIN
          SELECT PSL.SUBSIDY_STD
            INTO V_SUBSIDY_STD
            FROM T_POL_POLICY_PG_STD_RELA PSR,
                 T_POL_POLICY_PG_STD_LINE PSL
            WHERE PSR.SALES_CENTER_ID = V_SALES_CENTER_ID
              AND PSR.ENTITY_ID = P_ENTITY_ID
              AND PSR.STD_ID = PSL.STD_ID
              AND V_SUM_INSTALL_QTY >= PSL.BEGIN_QTY
              AND V_SUM_INSTALL_QTY < NVL(PSL.END_QTY, V_SUM_INSTALL_QTY +1)
              AND TRUNC(SYSDATE) BETWEEN PSR.BEGIN_DATE AND NVL(PSR.END_DATE, TRUNC(SYSDATE)+1);
         EXCEPTION 
           WHEN OTHERS THEN
            V_SUBSIDY_STD := 0;
            P_MESSAGE := '无配置中心与补贴标准关系，无法获取补贴标准！' || TO_CHAR(P_POLICY_ID);
        END;
      ELSE
        P_MESSAGE := '兑现数量为0，无法获取补贴标准！' || TO_CHAR(P_POLICY_ID);
      END IF;
      
      --计算补贴标准
      UPDATE T_POL_POLICY_PG_SUBSIDY_DETAIL PD
         SET PD.ACTUAL_SUBSIDY_STD = NVL(V_SUBSIDY_STD, 0)--,
             --PD.ACTUAL_SUBSIDY_AMOUNT =  NVL(PD.SUBSIDY_STD, NVL(V_SUBSIDY_STD, 0)) * PD.INSTALL_QTY * NVL(PD.RATIO, 1)
       WHERE PD.POLICY_ID = P_POLICY_ID;       
      
      UPDATE T_POL_POLICY_PG_SUBSIDY_DETAIL PD
         SET PD.ACTUAL_SUBSIDY_STD = DECODE(SIGN(PD.LOSS_PRICE), 1, 0,   --亏损金额为0， 不补贴
                                                          -1, DECODE(SIGN(PD.ACTUAL_SUBSIDY_STD + PD.LOSS_PRICE), --亏损金额为负数
                                                                     1, ABS(PD.LOSS_PRICE), --补贴标准+亏损金额 > 0, 补贴亏损金额
                                                                     -1, PD.ACTUAL_SUBSIDY_STD,    --补贴标准+亏损金额 < 0, 补贴补贴标准
                                                                     0, PD.ACTUAL_SUBSIDY_STD),   -- 0 , 0
                                                          0)
       WHERE PD.POLICY_ID = P_POLICY_ID; 

      --计算实际补贴金额
      UPDATE T_POL_POLICY_PG_SUBSIDY_DETAIL PD
         SET PD.ACTUAL_SUBSIDY_AMOUNT =  NVL(PD.ACTUAL_SUBSIDY_STD, 0) * PD.APPLY_QTY --* NVL(PD.RATIO, 1)
       WHERE PD.POLICY_ID = P_POLICY_ID;  
              
    END IF;   
    */
       
  END P_POLICY_CAL_PG;
  
  -----------------------------------------------------------------------------
  --  政策申请金额，计算工程机申请金额及返利金额， 前台语义使用           --
  -----------------------------------------------------------------------------  
  FUNCTION F_POLICY_CAL_PG(P_ENTITY_ID              IN NUMBER   --主体ID
                            ,P_POLICY_ID          IN NUMBER     --政策ID
                            ,P_CAL_TYPE           IN VARCHAR2  --计算类型，APPLY/DISCOUNT    
                            ,P_CONDITION_SQL      IN VARCHAR2 DEFAULT NULL--条件脚本                  
                            )RETURN VARCHAR2 
                            IS
    V_APPLY_AMOUNT NUMBER;
    V_MESSAGE VARCHAR2(2000);
  BEGIN
    P_POLICY_CAL_PG(P_ENTITY_ID,
                    P_POLICY_ID,
                    P_CAL_TYPE,
                    P_CONDITION_SQL,
                    V_APPLY_AMOUNT,
                    1,
                    V_MESSAGE
                   );  
    RETURN V_MESSAGE;
  END F_POLICY_CAL_PG;

  -----------------------------------------------------------------------------
  --  统计SQL取值函数                                                        --
  -----------------------------------------------------------------------------
  FUNCTION F_GET_SQL_VALUE(P_SQL                    VARCHAR2 --SQL脚本
                          ,
                           P_POLICY_ID               NUMBER --单据ID
                          ,
                           P_ENTITY_ID               NUMBER --主体ID
                          ,
                           P_RESULT                 OUT VARCHAR2 --返回信息:1.SUCCESS：正确执行；2.其他：执行失败
                           ) RETURN NUMBER IS
    V_SQL    VARCHAR2(20000);
    N_CUR    NUMBER;
    N_ROW    NUMBER;
    N_RESULT NUMBER;
  BEGIN
    V_SQL    := UPPER(P_SQL);
    P_RESULT := 'SUCCESS';
    --打开光标
    N_CUR := DBMS_SQL.OPEN_CURSOR;
    --解析动态SQL语句
    DBMS_SQL.PARSE(N_CUR, V_SQL, DBMS_SQL.NATIVE);
    --绑定输入参数
    IF INSTR(V_SQL, ':P_POLICY_ID', 1, 1) > 0 THEN
      DBMS_SQL.BIND_VARIABLE(N_CUR, ':P_POLICY_ID', P_POLICY_ID);
    END IF;
    IF INSTR(V_SQL, ':P_BILL_ID', 1, 1) > 0 THEN
      DBMS_SQL.BIND_VARIABLE(N_CUR, ':P_BILL_ID', P_POLICY_ID);
    END IF;
    IF INSTR(V_SQL, ':P_ENTITY_ID', 1, 1) > 0 THEN
      DBMS_SQL.BIND_VARIABLE(N_CUR, ':P_ENTITY_ID', P_ENTITY_ID);
    END IF;
  
    --定义输出列
    DBMS_SQL.DEFINE_COLUMN(N_CUR, 1, N_RESULT);
    N_ROW := DBMS_SQL.execute(N_CUR);
    --获取输出值
    IF DBMS_SQL.fetch_rows(N_CUR) > 0 THEN
      DBMS_SQL.column_value(N_CUR, 1, N_RESULT);
    ELSE
      N_RESULT := 0;
    END IF;
    --关闭光标
    DBMS_SQL.CLOSE_CURSOR(N_CUR);
    RETURN N_RESULT;
  EXCEPTION
    --异常处理
    WHEN OTHERS THEN
      IF DBMS_SQL.IS_OPEN(N_CUR) THEN
        DBMS_SQL.CLOSE_CURSOR(N_CUR);
      END IF;
      P_RESULT := 'SQL取值出错：' || SQLERRM;
      RETURN 0;
  END;
  
  
   ------------Y转F拆单（手工转返利）
   PROCEDURE P_Y2F_SPLIT(P_LIMIT            IN NUMBER    --限额
                        ,P_LINE_ID          IN NUMBER    --行ID
                        ,P_MESSAGE          OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
                        ,P_LINE_ID_NEW      OUT NUMBER   ---返回新的行ID
                       ) IS    
    BEGIN
       P_MESSAGE := 'OK';
       
       SELECT S_POLICY_Y_LINES.NEXTVAL INTO P_LINE_ID_NEW FROM DUAL;
       
       INSERT INTO T_POL_ORDER_LINES
         (LINE_ID
         ,LINE_NUMBER
         ,POLICY_ORDER_ID
         ,LINE_AMOUNT
         ,CHANGED_CASH_FLAG
         ,CHOICE_FLAG
         ,ITEM_ID
         ,ITEM_CODE
         ,ITEM_NAME
         ,UOM_CODE
         ,QUANTITY
         ,LIST_PRICE
         ,CUSTOMER_ID
         ,CUSTOMER_CODE
         ,CUSTOMER_NAME
         ,ACCOUNT_ID
         ,ACCOUNT_CODE
         ,DISCOUNT_ORDER_NUMBER
         ,DISCOUNT_METHOD
         ,CHECK_FLAG
         ,REMARK
         ,CREATED_BY
         ,CREATION_DATE
         ,LAST_UPDATED_BY
         ,LAST_UPDATE_DATE
         ,OLD_DISCOUNT_NUMBER
         ,ORDER_TYPE_ID
         ,SALES_CENTER_ID
         ,SALES_CENTER_CODE
         ,SALES_CENTER_NAME
         ,VERSION
         ,OU_ID
         ,LIMIT_AMOUNT
         ,SPLIT_ORDER
         ,SPLIT_ORDER_ID
         ,SALES_MAIN_TYPE
         ,DISCOUNT_PERIOD
         ,CALCULATE_GROUP_NAME
         ,CALCULATE_GROUP_TYPE
         ,POLICY_ID
         ,REF_MODEL
         ,TERMINAL_ID
         ,TERMINAL_CODE
         ,TERMINAL_NAME)
         SELECT P_LINE_ID_NEW
               ,LINE_NUMBER
               ,POLICY_ORDER_ID
               ,P_LIMIT
               ,CHANGED_CASH_FLAG
               ,CHOICE_FLAG
               ,ITEM_ID
               ,ITEM_CODE
               ,ITEM_NAME
               ,UOM_CODE
               ,QUANTITY
               ,P_LIMIT
               ,CUSTOMER_ID
               ,CUSTOMER_CODE
               ,CUSTOMER_NAME
               ,ACCOUNT_ID
               ,ACCOUNT_CODE
               ,DISCOUNT_ORDER_NUMBER
               ,DISCOUNT_METHOD
               ,CHECK_FLAG
               ,REMARK
               ,CREATED_BY
               ,CREATION_DATE
               ,LAST_UPDATED_BY
               ,LAST_UPDATE_DATE
               ,OLD_DISCOUNT_NUMBER
               ,ORDER_TYPE_ID
               ,SALES_CENTER_ID
               ,SALES_CENTER_CODE
               ,SALES_CENTER_NAME
               ,VERSION
               ,OU_ID
               ,P_LIMIT
               ,'N'
               ,LINE_ID
               ,SALES_MAIN_TYPE
               ,DISCOUNT_PERIOD
               ,CALCULATE_GROUP_NAME
               ,CALCULATE_GROUP_TYPE
               ,POLICY_ID
               ,REF_MODEL
               ,TERMINAL_ID
               ,TERMINAL_CODE
               ,TERMINAL_NAME
           FROM T_POL_ORDER_LINES T
          WHERE T.LINE_ID = P_LINE_ID;                
    END;
    
    
     ----检查客户、账户及营销大类的关系
   PROCEDURE P_CHECK_CUST_ACCT_SALE(P_POLICY_CHK_ID  IN NUMBER
                                   ,P_ENTITY_ID      IN NUMBER
                                   ,P_MESSAGE      OUT VARCHAR2
                                     )IS
                                     
     CURSOR C_RESULT_DETAIL IS
      SELECT T.ACCOUNT_ID
           , T.CUSTOMER_ID
           , T.SALES_MAIN_TYPE
        FROM T_POL_POLICY_RESULT T
       WHERE T.RESULT_CHK_ID = P_POLICY_CHK_ID;
       
    R_RESULT_DETAIL C_RESULT_DETAIL%ROWTYPE; 
                                     
     BEGIN
       P_MESSAGE := 'SUCCESS';
       
        OPEN C_RESULT_DETAIL;
          LOOP
          FETCH C_RESULT_DETAIL
          INTO R_RESULT_DETAIL;

          EXIT WHEN C_RESULT_DETAIL%NOTFOUND;
          
          PKG_CUST_CHECK.PKG_CUST_ACC_CHECK(P_ENTITY_ID, R_RESULT_DETAIL.CUSTOMER_ID, 
                                R_RESULT_DETAIL.ACCOUNT_ID, R_RESULT_DETAIL.SALES_MAIN_TYPE, P_MESSAGE);
                                
          IF P_MESSAGE <> 'SUCCESS' THEN 
            RETURN;
          END IF;
          
          END LOOP;        
     END;

  -----------------------------------------------------------------------------
  --  政策申请，计算工程机申请金额                                           --
  -----------------------------------------------------------------------------
  PROCEDURE P_POLICY_CAL_PG_APPLY(P_ENTITY_ID     IN NUMBER --主体ID
                           ,P_POLICY_ID     IN NUMBER --政策ID
                           ,P_USER_ID       IN VARCHAR2 --用户账号
                           ,P_APPLY_AMOUNT  OUT NUMBER --申请金额
                           ,P_MESSAGE       OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
                            ) IS
    V_ACCOUNT_ID NUMBER; --账户ID
    V_BILL_DATE VARCHAR2(10); --单据日期
    V_SALES_CENTER_ID NUMBER; --营销中心ID
    V_PROJECT_CODE VARCHAR2(300); --工程机项目编码
    V_PROJECT_CODES TYPE_SPLIT; --工程机项目编码数组
    V_STD_NAME VARCHAR2(100); --补贴标准名称
    V_PRICE_LIST_ID NUMBER; --价格列表ID
    V_SUBSIDY_STD NUMBER; --补贴标准
    V_SUBSIDY_PCT NUMBER; --补贴比例
    V_SUM_APPLY_QTY NUMBER; --折算数量
    
    V_TOTAL_SUBSIDY_ID NUMBER; --合计信息行ID
    V_ENTITY_VALUE VARCHAR2(100); --主体大单取数参数值
    V_MESSAGE VARCHAR2(200);
  BEGIN
    P_MESSAGE := 'OK';
    
    --获取政策信息
    IF (P_MESSAGE = 'OK') THEN
      BEGIN
        SELECT TO_CHAR(PY.ORDER_DATE, 'YYYYMMDD')
              ,PY.SALES_CENTER_ID
              ,PY.ACCOUNT_ID
              ,PY.PROJECT_CODE
              ,UP.CODE_NAME
          INTO V_BILL_DATE
              ,V_SALES_CENTER_ID
              ,V_ACCOUNT_ID
              ,V_PROJECT_CODE
              ,V_STD_NAME
          FROM T_POL_POLICY PY, V_UP_CODELIST UP
         WHERE PY.POLICY_ID = P_POLICY_ID
           AND PY.ENTITY_ID = P_ENTITY_ID
           AND PY.ENTITY_ID = UP.ENTITY_ID
           AND PY.DISCOUNT_ITEM = UP.CODE_VALUE
           AND UP.CODETYPE = 'POL_DISCOUNT_ITEM';
      EXCEPTION
        WHEN OTHERS THEN
          P_MESSAGE := '获取政策信息出错！' || SQLERRM;
      END;
    END IF;
    
    --将字符串拆分成数组
    V_PROJECT_CODES := PKG_POL_CAL.F_SPLIT_STR(V_PROJECT_CODE, ',');
    
    IF (P_MESSAGE <> 'OK') THEN
      ROLLBACK;
      RETURN;
    END IF;
    
    --申请金额需要删除已经产生的历史记录
    DELETE FROM T_POL_POLICY_PG_SUBSIDY_DETAIL PD
     WHERE PD.POLICY_ID = P_POLICY_ID;
    
    --从价格批文视图获取数据插入大单资源补贴标准明细表
    INSERT INTO T_POL_POLICY_PG_SUBSIDY_DETAIL
      (DETAIL_ID
      ,POLICY_ID
      ,APPLY_ID
      ,APPLY_DATE
      ,APPLY_CODE
      ,USER_FIRM
      ,ITEM_CODE
      ,ITEM_DESC
      ,UOM_CODE
      ,APPLY_QTY
      ,SALES_PRICE
      ,SALES_AMOUNT
      ,PO_PRICE
      ,PO_AMOUNT
      ,LOSS_PRICE
      ,LOSS_AMOUNT
      ,SUBSIDY_STD
      ,SUBSIDY_AMOUNT
      ,INSTALL_QTY
      ,RATIO
      ,ENTITY_ID
      ,CREATED_BY
      ,CREATION_DATE
      ,LAST_UPDATED_BY
      ,LAST_UPDATE_DATE
      ,ACCOUNT_ID)
      SELECT S_POL_PG_SUBSIDY_DETAIL.NEXTVAL
            ,P_POLICY_ID
            ,V.PRICE_APPLY_ID
            ,V.APPLY_DATE
            ,V.APPLY_CODE
            ,V.USER_FIRM
            ,V.ITEM_CODE
            ,V.ITEM_NAME
            ,V.ITEM_UOM
            ,V.APPLY_CNT
            ,V.APPLY_PRICE
            ,NVL(V.APPLY_CNT, 0) * NVL(V.APPLY_PRICE, 0)
            ,0
            ,0
            ,0
            ,0
            ,0
            ,0
            ,0
            ,1 --比率默认为1
            ,P_ENTITY_ID
            ,P_USER_ID
            ,SYSDATE
            ,P_USER_ID
            ,SYSDATE
            ,V_ACCOUNT_ID
        FROM V_BD_PRICE_APPLY_PG V
       WHERE V.PROJECT_CODE IN
             (SELECT COLUMN_VALUE FROM TABLE(V_PROJECT_CODES))
         AND V.APPLY_TYPE = 'PG';
    
    --直接获取参数定义中定义的价格列表Id   
    V_ENTITY_VALUE := PKG_BD.F_GET_OLD_PARAM_VALUE('POL_CAL_BIG_DEAL_MANAGE', P_ENTITY_ID); 
    V_PRICE_LIST_ID := 0;
    BEGIN
      IF TO_NUMBER(V_ENTITY_VALUE) > 0 THEN
        SELECT A.PRICE_LIST_ID
          INTO V_PRICE_LIST_ID
          FROM T_BD_PRICE_LIST A
         WHERE A.PRICE_LIST_ID = V_ENTITY_VALUE
           AND A.ENTITY_ID = P_ENTITY_ID
           AND A.ACTIVE_FLAG = 'Y';
      END IF;
    EXCEPTION
      --无数据则继续查价格体系
      WHEN NO_DATA_FOUND THEN
        V_PRICE_LIST_ID := 0;
      WHEN OTHERS THEN
        P_MESSAGE := '查找价格列表出错！' || TO_CHAR(P_POLICY_ID);
    END;
  
    --如果参数中没有获取，则从价格体系中获取价格列表的价格
    IF V_PRICE_LIST_ID = 0 THEN 
      BEGIN
        PKG_BD_PRICE.P_GET_PRICE_LIST_ID(P_ENTITY_ID,
                         V_ACCOUNT_ID,
                         V_BILL_DATE,
                         V_PRICE_LIST_ID,
                         V_MESSAGE);
      EXCEPTION 
        WHEN OTHERS THEN
          P_MESSAGE := '无配置中心价格列表！' || TO_CHAR(P_POLICY_ID);
      END;
    END IF;     
    IF (P_MESSAGE <> 'OK') THEN
      ROLLBACK;
      RETURN;
    END IF;  

    IF V_PRICE_LIST_ID <> 0 THEN
      UPDATE T_POL_POLICY_PG_SUBSIDY_DETAIL PD
         SET PD.PO_PRICE =
             (SELECT BL.LIST_PRICE
                FROM T_BD_PRICE_LINE BL
               WHERE BL.PRICE_LIST_ID = V_PRICE_LIST_ID
                 AND BL.ITEM_CODE = PD.ITEM_CODE
                 AND TRUNC(SYSDATE) BETWEEN BL.BEGIN_DATE AND
                     NVL(BL.END_DATE, TRUNC(SYSDATE) + 1))
       WHERE PD.POLICY_ID = P_POLICY_ID;
    END IF;
      
    --更新比率, 柜机、天花机为2
    UPDATE T_POL_POLICY_PG_SUBSIDY_DETAIL PD
       SET PD.RATIO = DECODE(PD.UOM_CODE, 'Tai', 0.5, 'Set', 1, 'Ea', 1) *
                      NVL((SELECT UC.CODE_VALUE
                            FROM T_BD_ITEM BI, UP_CODELIST UC
                           WHERE BI.ITEM_CODE = PD.ITEM_CODE
                             AND BI.ENTITY_ID = P_ENTITY_ID
                             AND BI.SALES_SUB_TYPE = UC.CODE_NAME
                             AND UC.CODETYPE = 'ITEM_RATIO'),
                          1)
     WHERE PD.POLICY_ID = P_POLICY_ID;
     
    --更新折算数量
    UPDATE T_POL_POLICY_PG_SUBSIDY_DETAIL PD
       SET PD.CONVERT_QTY = PD.APPLY_QTY * PD.RATIO
     WHERE PD.POLICY_ID = P_POLICY_ID;
      
    --计算采购金额、单台盈亏、总盈亏
    UPDATE T_POL_POLICY_PG_SUBSIDY_DETAIL PD
       SET PD.PO_AMOUNT = NVL(PD.PO_PRICE, 0) * NVL(PD.APPLY_QTY, 0), --* NVL(PD.RATIO, 1) --计算采购金额
           PD.LOSS_PRICE = NVL(PD.SALES_PRICE, 0) - NVL(PD.PO_PRICE, 0), --计算单台盈亏
           PD.LOSS_AMOUNT = (NVL(PD.SALES_PRICE, 0) - NVL(PD.PO_PRICE, 0)) * NVL(PD.APPLY_QTY, 0) --* NVL(PD.RATIO, 1) --计算总盈亏
     WHERE PD.POLICY_ID = P_POLICY_ID; 

    SELECT SUM(NVL(PD.APPLY_QTY, 0) * NVL(PD.RATIO, 1)) --补贴标准按 申请数量乘以 倍率 计算，补贴金额保持不变
      INTO V_SUM_APPLY_QTY
      FROM T_POL_POLICY_PG_SUBSIDY_DETAIL PD
     WHERE PD.POLICY_ID = P_POLICY_ID;
         
    --获取兑现标准
    IF V_SUM_APPLY_QTY <> 0 THEN
      BEGIN
        SELECT NVL(PSL.SUBSIDY_STD, 0), NVL(PSL.SUBSIDY_PCT, 0)
          INTO V_SUBSIDY_STD, V_SUBSIDY_PCT
          FROM T_POL_POLICY_PG_STD      PS
              ,T_POL_POLICY_PG_STD_RELA PSR
              ,T_POL_POLICY_PG_STD_LINE PSL
         WHERE PS.STD_NAME = V_STD_NAME
           AND PS.STD_ID = PSR.STD_ID
           AND PSR.STD_ID = PSL.STD_ID
           AND PSR.SALES_CENTER_ID = V_SALES_CENTER_ID
           AND PSR.ENTITY_ID = P_ENTITY_ID
           AND V_SUM_APPLY_QTY >= PSL.BEGIN_QTY
           AND V_SUM_APPLY_QTY < NVL(PSL.END_QTY, V_SUM_APPLY_QTY + 1)
           AND TRUNC(SYSDATE) BETWEEN PSR.BEGIN_DATE AND
               NVL(PSR.END_DATE, TRUNC(SYSDATE) + 1);
       EXCEPTION 
         WHEN OTHERS THEN
          P_MESSAGE := '无配置中心与补贴标准关系，无法获取补贴标准！' || TO_CHAR(P_POLICY_ID);
      END;
    ELSE
      P_MESSAGE := '折算数量为0，无法获取补贴标准！' || TO_CHAR(P_POLICY_ID);
    END IF;
      
    IF (P_MESSAGE <> 'OK') THEN
      ROLLBACK;
      RETURN;
    END IF;
      
    /* 计算补贴标准
    *    盈亏金额 < 0：
    *     |盈亏金额| < 补贴标准， 补贴标准更新为 |盈亏金额|
    *     |盈亏金额| > 补贴标准， 补贴标准不变
    *    盈亏金额 >= 0：
    *     补贴标准 = 0
    */
    UPDATE T_POL_POLICY_PG_SUBSIDY_DETAIL PD
       SET PD.SUBSIDY_STD =
              DECODE(SIGN(PD.LOSS_PRICE),
                 1, 0, --盈亏金额为正数, 补贴标准为0
                -1, DECODE(SIGN(V_SUBSIDY_STD + PD.LOSS_PRICE), --盈亏金额为负数
                       1, ABS(PD.LOSS_PRICE), --补贴标准+盈亏金额 > 0, 补贴|盈亏金额|
                      -1, V_SUBSIDY_STD,      --补贴标准+盈亏金额 < 0, 补贴补贴标准
                       0, V_SUBSIDY_STD),     --补贴标准+盈亏金额 = 0, 补贴补贴标准
                 0)
     WHERE PD.POLICY_ID = P_POLICY_ID;
     
    --更新补贴金额
    UPDATE T_POL_POLICY_PG_SUBSIDY_DETAIL PD
       SET PD.SUBSIDY_AMOUNT = PD.SUBSIDY_STD * PD.APPLY_QTY
     WHERE PD.POLICY_ID = P_POLICY_ID;
     
    --插入合计信息行
    SELECT S_POL_PG_SUBSIDY_DETAIL.NEXTVAL
      INTO V_TOTAL_SUBSIDY_ID
      FROM DUAL; 
    INSERT INTO T_POL_POLICY_PG_SUBSIDY_DETAIL
      (DETAIL_ID
      ,POLICY_ID
      ,APPLY_QTY
      ,CONVERT_QTY
      ,SALES_AMOUNT
      ,PO_AMOUNT
      ,LOSS_AMOUNT
      ,SUBSIDY_AMOUNT
      ,SUBSIDY_PCT
      ,SUBSIDY_PCT_AMOUNT
      ,SUBSIDY_PCT_BASE
      ,TOTAL_SUBSIDY_AMOUNT
      ,ENTITY_ID
      ,CREATED_BY
      ,CREATION_DATE
      ,LAST_UPDATED_BY
      ,LAST_UPDATE_DATE)
      SELECT V_TOTAL_SUBSIDY_ID
            ,P_POLICY_ID
            ,SUM(PD.APPLY_QTY)
            ,SUM(PD.CONVERT_QTY)
            ,SUM(PD.SALES_AMOUNT)
            ,SUM(PD.PO_AMOUNT)
            ,SUM(PD.LOSS_AMOUNT)
            ,SUM(PD.SUBSIDY_AMOUNT)
            ,0
            ,0
            ,0
            ,SUM(PD.SUBSIDY_AMOUNT)
            ,P_ENTITY_ID
            ,P_USER_ID
            ,SYSDATE
            ,P_USER_ID
            ,SYSDATE
        FROM T_POL_POLICY_PG_SUBSIDY_DETAIL PD
       WHERE PD.POLICY_ID = P_POLICY_ID;     
    
    --如果按补贴标准补贴后任然亏损，按 |亏损总额|*补贴比例 追加补贴
    IF V_SUBSIDY_PCT <> 0 THEN
       UPDATE T_POL_POLICY_PG_SUBSIDY_DETAIL PD
          SET PD.SUBSIDY_PCT = V_SUBSIDY_PCT
             ,PD.SUBSIDY_PCT_BASE = 0 - (PD.SUBSIDY_AMOUNT + PD.LOSS_AMOUNT)
             ,PD.SUBSIDY_PCT_AMOUNT = (0 - (PD.SUBSIDY_AMOUNT + PD.LOSS_AMOUNT)) * V_SUBSIDY_PCT / 100
        WHERE PD.DETAIL_ID = V_TOTAL_SUBSIDY_ID
          AND PD.SUBSIDY_AMOUNT + PD.LOSS_AMOUNT < 0;
    END IF;

    --计算合计金额、实际金额
    UPDATE T_POL_POLICY_PG_SUBSIDY_DETAIL PD
       SET PD.TOTAL_SUBSIDY_AMOUNT  = PD.SUBSIDY_AMOUNT +
                                      PD.SUBSIDY_PCT_AMOUNT
          ,PD.ACTUAL_SUBSIDY_AMOUNT = PD.SUBSIDY_AMOUNT +
                                      PD.SUBSIDY_PCT_AMOUNT
     WHERE PD.DETAIL_ID = V_TOTAL_SUBSIDY_ID;
      
    --如果 整单盈利，实际补贴金额 = 0
    UPDATE T_POL_POLICY_PG_SUBSIDY_DETAIL PD
       SET PD.ACTUAL_SUBSIDY_AMOUNT = 0
     WHERE PD.DETAIL_ID = V_TOTAL_SUBSIDY_ID
       AND PD.LOSS_AMOUNT >= 0;
      
    --如果 整单亏损、合计补贴金额 > |亏损金额|，实际补贴金额 = |亏损金额|
    UPDATE T_POL_POLICY_PG_SUBSIDY_DETAIL PD
       SET PD.ACTUAL_SUBSIDY_AMOUNT = ABS(PD.LOSS_AMOUNT)
     WHERE PD.DETAIL_ID = V_TOTAL_SUBSIDY_ID
       AND PD.LOSS_AMOUNT < 0
       AND ABS(PD.LOSS_AMOUNT) < PD.TOTAL_SUBSIDY_AMOUNT;
       
    --返回实际补贴金额
    SELECT PD.ACTUAL_SUBSIDY_AMOUNT
      INTO P_APPLY_AMOUNT
      FROM T_POL_POLICY_PG_SUBSIDY_DETAIL PD
     WHERE PD.DETAIL_ID = V_TOTAL_SUBSIDY_ID;
   
  END P_POLICY_CAL_PG_APPLY;

  -----------------------------------------------------------------------------
  --  政策申请，计算中央空调运费                                          --
  -----------------------------------------------------------------------------
  PROCEDURE P_POLICY_CAL_TRANS_FEE(P_ENTITY_ID IN NUMBER, --主体ID
                                   P_POLICY_ID IN NUMBER, --政策ID
                                   P_DEFINE_ID IN NUMBER, --算法定义ID
                                   P_USER_ID   IN VARCHAR2, --用户账号
                                   P_MESSAGE   OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
                                   ) AS
    N_FREE_AMOUNT       NUMBER; --免运费起始金额(大于该金额免运费)
    N_SHIP_PROPORTION   NUMBER; --运费比例
    N_ORDER_AMOUNT      NUMBER; --订单免运费起始金额(大于该金额免运费)
    v_exist_id number; --存在的政策id
  BEGIN
    BEGIN
      SELECT TO_NUMBER(PF.ENTITY_VALUE)
        INTO N_FREE_AMOUNT
        FROM T_BD_PARAM_LIST PD, T_BD_PARAM_ENTITY PF
       WHERE PD.PARAM_CODE = 'FREE_SHIP_AMOUNT'
         AND PD.PARAM_LIST_ID = PF.PARAM_LIST_ID
         AND PF.ENTITY_ID = P_ENTITY_ID;
       
      SELECT TO_NUMBER(PF.ENTITY_VALUE)
        INTO N_SHIP_PROPORTION
        FROM T_BD_PARAM_LIST PD, T_BD_PARAM_ENTITY PF
       WHERE PD.PARAM_CODE = 'SHIP_PROPORTION'
         AND PD.PARAM_LIST_ID = PF.PARAM_LIST_ID
         AND PF.ENTITY_ID = P_ENTITY_ID;
       
      SELECT TO_NUMBER(PF.ENTITY_VALUE)
        INTO N_ORDER_AMOUNT
        FROM T_BD_PARAM_LIST PD, T_BD_PARAM_ENTITY PF
       WHERE PD.PARAM_CODE = 'FREE_ORDER_AMOUNT'
         AND PD.PARAM_LIST_ID = PF.PARAM_LIST_ID
         AND PF.ENTITY_ID = P_ENTITY_ID;
       
    EXCEPTION 
      WHEN OTHERS THEN 
        N_FREE_AMOUNT := 0;
        N_SHIP_PROPORTION  := 0;
        N_ORDER_AMOUNT  := 0;
    END;
    
    --明细行设置货值：ITEM_PRICE * ITEM_QTY
    UPDATE T_POL_POLICY_FREEZE PA
       SET PA.NUM_11 = PA.NUM_08 * PA.NUM_07 --货值
     WHERE PA.POLICY_ID = P_POLICY_ID
       AND PA.DEFINE_ID = P_DEFINE_ID
       AND PA.NUM_09 = P_ENTITY_ID --ENTITY_ID
     ;
  
    --明细行设置运费：ITEM_PRICE * FACT_SHIP_QTY(实际发货数量) * 运费比例
    UPDATE T_POL_POLICY_FREEZE PA
       SET PA.NUM_10 =
            PA.NUM_08 * PA.NUM_06 * N_SHIP_PROPORTION --运费           
     WHERE PA.POLICY_ID = P_POLICY_ID
       AND PA.DEFINE_ID = P_DEFINE_ID
       AND PA.NUM_06 > 0 --FACT_SHIP_QTY
       AND PA.NUM_09 = P_ENTITY_ID --ENTITY_ID
       AND PA.NUM_08 * PA.NUM_06 < N_FREE_AMOUNT --实际货值 < 免运费起始金额
     ;                   
      --设置提货单总金额
      UPDATE T_POL_POLICY_FREEZE PA
       SET PA.NUM_13 =( select  SUM(PB.LIST_PRICE * PB.QUANTITY) AMOUNT
              FROM t_pln_lg_order_Line pb
             WHERE PB.ORDER_HEAD_ID =pa.num_02 
             GROUP BY PB.ORDER_HEAD_ID 
              )
     WHERE  PA.POLICY_ID = P_POLICY_ID
       AND PA.DEFINE_ID = P_DEFINE_ID
       AND PA.num_09 = P_ENTITY_ID -- ENTITY_ID 
               ;
  --按客户、创建日期、收货单位名称和地址汇总，总货值 >= 免运费起始金额，免运费
    UPDATE T_POL_POLICY_FREEZE PA
       SET PA.NUM_10 = 0
     WHERE PA.POLICY_ID = P_POLICY_ID
       AND PA.DEFINE_ID = P_DEFINE_ID
       AND PA.NUM_09 = P_ENTITY_ID --ENTITY_ID
       AND (PA.ACCOUNT_ID, PA.DATE_01, PA.LVCHR_01, PA.LVCHR_02) IN
           (SELECT PF.ACCOUNT_ID, PF.DATE_01, PF.LVCHR_01, PF.LVCHR_02 --,PF.LVCHR_09, PF.LVCHR_01, PF.LVCHR_02, SUM(PF.NUM_11)
              FROM T_POL_POLICY_FREEZE PF
             WHERE PF.NUM_09 = P_ENTITY_ID
               AND PF.POLICY_ID = P_POLICY_ID
               AND PF.DEFINE_ID = P_DEFINE_ID
             GROUP BY PF.ACCOUNT_ID, PF.DATE_01, PF.LVCHR_01, PF.LVCHR_02
            HAVING SUM(PF.NUM_11) >= N_FREE_AMOUNT);
 
  --将政策id放入参数 ,判断当前计算的政策是否是中央的两个政策
      begin 
        v_exist_id:=0;
       select ph.policy_id into  v_exist_id
                  from cims.t_pol_policy ph
                 where ph.policy_number in
                       ('ZC总1118082200001', 'ZC总2417092900001')  and ph.policy_id=P_POLICY_ID   ; 
       EXCEPTION 
          WHEN OTHERS THEN 
            v_exist_id := 0; 
        END;                
                        
  if   v_exist_id >0 then 
     --按客户、创建日期、收货单位名称和地址汇总，总货值 >= 免运费起始金额，免运费
     --中央的合并计算
    update t_pol_policy_freeze pa
       set pa.num_10 = 0
     where pa.policy_id in
           (select ph.policy_id
              from cims.t_pol_policy ph
             where ph.policy_number in
                   ('ZC总1118082200001', 'ZC总2417092900001'))
       and pa.define_id in
           (select ph.define_id
              from cims.t_pol_policy_define ph, cims.t_pol_policy po
             where po.policy_number in
                   ('ZC总1118082200001', 'ZC总2417092900001')
               and ph.policy_id = po.policy_id)
       and (pa.lvchr_03, pa.date_01, pa.lvchr_01, pa.lvchr_02) in
           (select pf.lvchr_03, pf.date_01, pf.lvchr_01, pf.lvchr_02 --,  PF.lvchr_09, PF.LVCHR_01, PF.LVCHR_02, SUM(PF.NUM_11)
              from t_pol_policy_freeze pf
             where pf.policy_id in
                   (select ph.policy_id
                      from cims.t_pol_policy ph
                     where ph.policy_number in
                           ('ZC总1118082200001', 'ZC总2417092900001'))
               and pf.define_id in
                   (select ph.define_id
                      from cims.t_pol_policy_define ph, cims.t_pol_policy po
                     where po.policy_number in
                           ('ZC总1118082200001', 'ZC总2417092900001')
                       and ph.policy_id = po.policy_id)
             group by pf.lvchr_03, pf.date_01, pf.lvchr_01, pf.lvchr_02
            having sum(pf.num_11) >= n_free_amount);
            
         end if;   
    --同一订单多次发运，订单金额 NUM_13 > 订单免运费起始金额，免运费
    UPDATE T_POL_POLICY_FREEZE PA
       SET PA.NUM_10 = 0
     WHERE  PA.POLICY_ID = P_POLICY_ID
       AND PA.DEFINE_ID = P_DEFINE_ID
       AND PA.num_09 = P_ENTITY_ID -- ENTITY_ID
        and NUM_13 > N_ORDER_AMOUNT    
        and num_12 < 4 ;


  END P_POLICY_CAL_TRANS_FEE;
  
  ----------------------------------------------------------------------
  -- 拆分字符串为数组
  ----------------------------------------------------------------------
  FUNCTION F_SPLIT_STR(AS_STR IN VARCHAR2, AS_SPLIT_STR IN VARCHAR2)
    RETURN TYPE_SPLIT AS
    LS_STR   TYPE_SPLIT := TYPE_SPLIT();
    V_SY_STR VARCHAR2(32767);
    V_STR    VARCHAR2(1000);
  BEGIN
    IF TRIM(AS_STR) IS NULL OR TRIM(AS_SPLIT_STR) IS NULL THEN
      RETURN LS_STR;
    END IF;
  
    V_SY_STR := AS_STR;
    IF INSTR(V_SY_STR, AS_SPLIT_STR) = 0 THEN
      LS_STR.EXTEND;
      LS_STR(LS_STR.COUNT) := V_SY_STR;
      RETURN LS_STR;
    END IF;
  
    LOOP
      IF INSTR(V_SY_STR, AS_SPLIT_STR) = 0 THEN
        V_STR := V_SY_STR;
        LS_STR.EXTEND;
        LS_STR(LS_STR.COUNT) := V_STR;
        EXIT;
      END IF;
    
      V_STR := SUBSTR(V_SY_STR, 1, INSTR(V_SY_STR, AS_SPLIT_STR) - 1);
      LS_STR.EXTEND;
      LS_STR(LS_STR.COUNT) := V_STR;
      V_SY_STR := SUBSTR(V_SY_STR, INSTR(V_SY_STR, AS_SPLIT_STR) + 1);
    
      IF V_SY_STR IS NULL THEN
        EXIT;
      END IF;
    END LOOP;
  
    RETURN LS_STR;
  END;

END PKG_POL_CAL;
/

