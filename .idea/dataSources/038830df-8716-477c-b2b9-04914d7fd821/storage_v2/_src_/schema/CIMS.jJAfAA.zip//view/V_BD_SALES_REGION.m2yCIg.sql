create view V_BD_SALES_REGION as
select t.unit_id sales_region_id, --区域ID
       t.code sales_region_code,  --区域编码
       t.name sales_region_name, --区域名称
       t.type_code,     --单位编码（事业部：BU,营销区域：SR ，营销中心：SC）
       t.entity_id,     --主体ID
       t.created_by,
       t.creation_date,
       t.last_updated_by,
       t.last_update_date
  from up_org_unit t
  where t.type_code = 'SR'
 order by t.unit_id
/

