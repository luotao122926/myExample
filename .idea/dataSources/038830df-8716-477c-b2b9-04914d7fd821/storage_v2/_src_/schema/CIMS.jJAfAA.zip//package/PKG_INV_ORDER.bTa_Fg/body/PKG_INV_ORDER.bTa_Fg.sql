create PACKAGE BODY      PKG_INV_ORDER AS
  -----------------------------------------------------------------------------
  --处理中转单订单入库完成主过程
  -----------------------------------------------------------------------------
  PROCEDURE P_INV_ORDER_MAIN
  (
    P_PO_HEADER_ID       IN T_INV_PO_HEADERS.PO_ID%TYPE,--中转单头ID
    P_RESULT         IN OUT NUMBER, --返回错误ID
    P_ERR_MSG        IN OUT VARCHAR2 --返回错误信息
  ) IS

  V_EXC_DATE T_INV_PO_HEADERS.EXEC_TIME%TYPE;--执行时间

  BEGIN
    P_RESULT  := 0;
    P_ERR_MSG := 'SUCCESS';
    SELECT PH.EXEC_TIME INTO V_EXC_DATE FROM CIMS.T_INV_PO_HEADERS PH WHERE PH.PO_ID = P_PO_HEADER_ID 
      AND PH.EXEC_TIME IS NOT NULL AND PH.SOURCE_TYPE = '工单入库';
     
    IF V_EXC_DATE IS NULL THEN RETURN;--执行时间为空不做处理
    END IF;

    FOR R_ORDER_LINE IN (
        SELECT PR.LG_ORDER_LINE_ID,PR.ORDER_LINE_ID FROM CIMS.T_INV_PO_LINES_DETAIL PD,
          CIMS.T_PLN_ORDER_LINE      POL,
          CIMS.T_PLN_LG_RELATION     PR
          WHERE PD.ORDER_LINE_ID = POL.ORDER_LINE_ID AND POL.ORDER_LINE_ID = PR.ORDER_LINE_ID 
            AND POL.CAN_PRODUCE_QTY = NVL(POL.SUPPLY_QTY,0)+NVL(POL.CHECK_ADJUST_QTY,0) 
            AND PD.PO_HEAD_ID = P_PO_HEADER_ID
      ) LOOP

      P_UPDATE_LG_ORDER_LINE(R_ORDER_LINE.LG_ORDER_LINE_ID,V_EXC_DATE,P_RESULT,P_ERR_MSG);

    END LOOP;
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      P_RESULT  := -1;
      P_ERR_MSG := '更新提货订单入库完成时间出错：' || SUBSTR(SQLERRM,1,100);
  END;

  -----------------------------------------------------------------------------
  --更新提货订单行入库完成时间
  -----------------------------------------------------------------------------
  PROCEDURE P_UPDATE_LG_ORDER_LINE
  (
    P_ORDER_LINE_ID IN T_PLN_LG_ORDER_LINE.ORDER_LINE_ID%TYPE,--提货订单行ID
    P_COMPLETE_DATE IN DATE, --入库完成时间
    P_RESULT         IN OUT NUMBER, --返回错误ID
    P_ERR_MSG        IN OUT VARCHAR2 --返回错误信息
  ) IS
  
  BEGIN
    UPDATE CIMS.T_PLN_LG_ORDER_LINE POL SET POL.COMPLETE_DATE = P_COMPLETE_DATE 
      WHERE POL.ORDER_LINE_ID = P_ORDER_LINE_ID AND POL.COMPLETE_DATE IS NULL;
  EXCEPTION
    WHEN OTHERS THEN
      P_RESULT  := -1;
      P_ERR_MSG := '更新提货订单入库完成时间出错：' || SUBSTR(SQLERRM,1,100);
  END;
END PKG_INV_ORDER;
/

