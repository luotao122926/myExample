create PACKAGE PKG_BD_PRICE AS
  V_NL CONSTANT VARCHAR2(2) := CHR(13) || CHR(10); --换行 
  /*取价函数*/
  function F_GET_PRICE(P_ACC_ID        t_customer_account.account_id%type, --账户ID
                       P_ITEM_CODE     t_bd_item.item_code%type, --产品编码
                       P_BILL_DATE     VARCHAR2, --单据日期
                       P_PRICE_LIST_ID t_bd_price_list.price_list_id%type, --价格列表ID
                       P_ENTITY_ID     up_org_unit.ENTITY_ID%type --业务主体ID
                       ) --
   return NUMBER;

  /*取价过程,入口过程，正品*/
  procedure P_GET_PRICE(P_ACC_ID         IN t_customer_account.account_id%type, --账户ID
                        P_ITEM_CODE      IN t_bd_item.item_code%type, --产品编码
                        P_BILL_DATE      IN VARCHAR2, --单据日期 YYYYMMDD
                        P_PRICE_LIST_ID  IN t_bd_price_list.price_list_id%type, --价格列表ID
                        P_ENTITY_ID      IN up_org_unit.ENTITY_ID%type, --业务主体ID
                        P_PRICE          out NUMBER, --返回价格
                        P_DISCOUNT       out NUMBER, --返回折扣率
                        P_MONTH_DISCOUNT out NUMBER, --返回月返
                        P_CX_FLAG        out VARCHAR2 --返回是否促销机
                        );
  -------------------------------------------------------------------------------
  /*
    *   创建日期：2017-07-27
    *     创建者：liangym2
  p_get_price  *   功能说明：取价格行后台接口方法
    */
  -------------------------------------------------------------------------------
  procedure P_GET_PRICE_LINE(IN_ACC_ID         IN t_customer_account.account_id%type, --账户ID
                             IS_ITEM_CODE      IN t_bd_item.item_code%type, --产品编码
                             IS_BILL_DATE      IN VARCHAR2, --单据日期,YYYYMMDD
                             IN_PRICE_LIST_ID  IN t_bd_price_list.price_list_id%type, --价格列表ID
                             IN_ENTITY_ID      IN up_org_unit.ENTITY_ID%type, --业务主体ID
                             ON_PRICE          out NUMBER, --返回价格
                             ON_DISCOUNT       out NUMBER, --返回折扣率
                             ON_MONTH_DISCOUNT out NUMBER, --返回月返
                             OS_CX_FLAG        out VARCHAR2, --返回是否促销机
                             OS_COMPE_ATTR     OUT VARCHAR2 --价格行的竞争属性
                             );
  /*取价过程,入口过程，优惠品*/
  procedure P_GET_PRICE_YH(P_ACC_ID         IN t_customer_account.account_id%type, --账户ID
                           P_ITEM_CODE      IN t_bd_item.item_code%type, --产品编码
                           P_BILL_DATE      IN VARCHAR2, --单据日期 YYYYMMDD
                           P_PRICE_LIST_ID  IN t_bd_price_list.price_list_id%type, --价格列表ID
                           P_ENTITY_ID      IN up_org_unit.ENTITY_ID%type, --业务主体ID
                           P_PRICE          out NUMBER, --返回价格
                           P_DISCOUNT       out NUMBER, --返回折扣率
                           P_MONTH_DISCOUNT out NUMBER, --返回月返
                           P_CX_FLAG        out VARCHAR2 --返回是否促销机
                           );

  /*取价格列表行过程,入口过程，优惠品*/
  procedure P_GET_PRICE_LINE_YH(IN_ACC_ID         IN t_customer_account.account_id%type, --账户ID
                                IS_ITEM_CODE      IN t_bd_item.item_code%type, --产品编码
                                IS_BILL_DATE      IN VARCHAR2, --单据日期 YYYYMMDD
                                IN_PRICE_LIST_ID  IN t_bd_price_list.price_list_id%type, --价格列表ID
                                IN_ENTITY_ID      IN up_org_unit.ENTITY_ID%type, --业务主体ID
                                ON_PRICE          out NUMBER, --返回价格
                                ON_DISCOUNT       out NUMBER, --返回折扣率
                                ON_MONTH_DISCOUNT out NUMBER, --返回月返
                                OS_CX_FLAG        out VARCHAR2, --返回是否促销机
                                OS_COMPE_ATTR     OUT VARCHAR2 --价格行的竞争属性
                                );

  /*家用取价过程,正品*/
  procedure P_GET_PRICE_10(P_ENTITY_ID      IN NUMBER,
                           P_ACC_ID         IN t_customer_account.account_id%type, --账户ID
                           P_ITEM_CODE      IN t_bd_item.item_code%type, --产品编码
                           P_BILL_DATE      IN VARCHAR2, --单据日期
                           P_PRICE_LIST_ID  IN t_bd_price_list.price_list_id%type, --价格列表ID
                           P_PRICE          out NUMBER, --返回价格
                           P_DISCOUNT       out NUMBER, --返回折扣率
                           P_MONTH_DISCOUNT out NUMBER, --返回月返
                           P_CX_FLAG        out VARCHAR2, --返回是否促销机
                           ON_PRICE_LINE_ID OUT NUMBER --
                           );
  /*家用取价过程,优惠品*/
  procedure P_GET_PRICE_10_YH(P_ENTITY_ID      IN NUMBER,
                              P_ACC_ID         IN t_customer_account.account_id%type, --账户ID
                              P_ITEM_CODE      IN t_bd_item.item_code%type, --产品编码
                              P_BILL_DATE      IN VARCHAR2, --单据日期
                              P_PRICE_LIST_ID  IN t_bd_price_list.price_list_id%type, --价格列表ID
                              P_PRICE          out NUMBER, --返回价格
                              P_DISCOUNT       out NUMBER, --返回折扣率
                              P_MONTH_DISCOUNT out NUMBER, --返回月返
                              P_CX_FLAG        out VARCHAR2, --返回是否促销机
                              ON_PRICE_LINE_ID OUT NUMBER --
                              );
  /*厨电取价过程,正品*/
  procedure P_GET_PRICE_14(P_ENTITY_ID      IN NUMBER,
                           P_ACC_ID         IN t_customer_account.account_id%type, --账户ID
                           P_ITEM_CODE      IN t_bd_item.item_code%type, --产品编码
                           P_BILL_DATE      IN VARCHAR2, --单据日期
                           P_PRICE_LIST_ID  IN t_bd_price_list.price_list_id%type, --价格列表ID
                           P_PRICE          out NUMBER, --返回价格
                           P_DISCOUNT       out NUMBER, --返回折扣率
                           P_MONTH_DISCOUNT out NUMBER, --返回月返
                           P_CX_FLAG        out VARCHAR2, --返回是否促销机
                           ON_PRICE_LINE_ID OUT NUMBER --
                           );
  /*厨电取价过程，优惠品*/
  procedure P_GET_PRICE_14_YH(P_ENTITY_ID      IN NUMBER,
                              P_ACC_ID         IN t_customer_account.account_id%type, --账户ID
                              P_ITEM_CODE      IN t_bd_item.item_code%type, --产品编码
                              P_BILL_DATE      IN VARCHAR2, --单据日期
                              P_PRICE_LIST_ID  IN t_bd_price_list.price_list_id%type, --价格列表ID
                              P_PRICE          out NUMBER, --返回价格
                              P_DISCOUNT       out NUMBER, --返回折扣率
                              P_MONTH_DISCOUNT out NUMBER, --返回月返
                              P_CX_FLAG        out VARCHAR2, --返回是否促销机
                              ON_PRICE_LINE_ID OUT NUMBER --
                              );

  /*家用主体，根据价格列表进行取价错误描述*/
  procedure P_G_PRICE_DESC_FROM_LIST_10(P_ENTITY_ID     IN NUMBER,
                                        P_ITEM_CODE     IN t_bd_item.item_code%type, --产品编码
                                        P_BILL_DATE     IN DATE, --单据日期
                                        P_PRICE_LIST_ID IN t_bd_price_list.price_list_id%type, --价格列表ID
                                        P_DESC          out VARCHAR2 --返回
                                        );

  /*厨电主体，根据价格列表进行取价错误描述
  --产品竞争属性  COMMON:常规机  PROMOTION:促销机
  */
  procedure P_G_PRICE_DESC_FROM_LIST_14(P_ENTITY_ID     IN NUMBER,
                                        P_ITEM_CODE     IN t_bd_item.item_code%type, --产品编码
                                        P_BILL_DATE     IN DATE, --单据日期
                                        P_CUSR_TYPE     IN t_bd_price_type.price_type%type, --取价类型
                                        P_PRICE_LIST_ID IN t_bd_price_list.price_list_id%type, --价格列表ID
                                        P_DESC          out VARCHAR2 --返回价格
                                        );

  /*根据价格列表进行取价（家用）*/
  procedure P_GET_PRICE_FROM_LIST_10(P_ENTITY_ID      IN NUMBER,
                                     P_ITEM_CODE      IN t_bd_item.item_code%type, --产品编码
                                     P_BILL_DATE      IN VARCHAR2, --单据日期
                                     P_PRICE_LIST_ID  IN t_bd_price_list.price_list_id%type, --价格列表ID
                                     P_PRICE          out NUMBER, --返回价格
                                     P_MONTH_DISCOUNT out NUMBER, --返回月返
                                     P_CX_FLAG        out VARCHAR2, --返回是否促销机
                                     ON_PRICE_LINE_ID OUT NUMBER --
                                     );

  /*家用主体，根据价格列表进行取价*/
  procedure P_GET_PRICE_FROM_LIST_10(P_ENTITY_ID      IN NUMBER,
                                     P_ITEM_CODE      IN t_bd_item.item_code%type, --产品编码
                                     P_BILL_DATE      IN DATE, --单据日期
                                     P_PRICE_LIST_ID  IN t_bd_price_list.price_list_id%type, --价格列表ID
                                     P_PRICE          out NUMBER, --返回价格
                                     P_MONTH_DISCOUNT out NUMBER, --返回月返
                                     P_CX_FLAG        out VARCHAR2, --返回是否促销机
                                     ON_PRICE_LINE_ID OUT NUMBER --
                                     );

  /*厨电主体，根据价格列表进行取价
  --产品竞争属性  COMMON:常规机  PROMOTION:促销机
  */
  procedure P_GET_PRICE_FROM_LIST_14(P_ENTITY_ID      IN NUMBER,
                                     P_ITEM_CODE      IN t_bd_item.item_code%type, --产品编码
                                     P_BILL_DATE      IN DATE, --单据日期
                                     P_CUSR_TYPE      IN t_bd_price_type.price_type%type, --取价类型
                                     P_PRICE_LIST_ID  IN t_bd_price_list.price_list_id%type, --价格列表ID
                                     P_PRICE          out NUMBER, --返回价格
                                     P_MONTH_DISCOUNT out NUMBER, --返回月返
                                     P_CX_FLAG        out VARCHAR2, --返回是否促销机
                                     ON_PRICE_LINE_ID OUT NUMBER --
                                     );

  /*根据价格列表进行取价（厨电）*/
  procedure P_GET_PRICE_FROM_LIST_14(P_ENTITY_ID      IN NUMBER,
                                     P_ITEM_CODE      IN t_bd_item.item_code%type, --产品编码
                                     P_BILL_DATE      IN VARCHAR2, --单据日期
                                     P_CUSR_TYPE      IN t_bd_price_type.price_type%type, --取价类型
                                     P_PRICE_LIST_ID  IN t_bd_price_list.price_list_id%type, --价格列表ID
                                     P_PRICE          out NUMBER, --返回价格
                                     P_MONTH_DISCOUNT out NUMBER, --返回月返
                                     P_CX_FLAG        out VARCHAR2, --返回是否促销机
                                     ON_PRICE_LINE_ID OUT NUMBER --
                                     );

  procedure P_MONTH_ITEM_COST
  -- 生成指定月份的销售成本
  (P_MONTH       in varchar2, --年月：如:201407
   P_RETURN_CODE out varchar2, --返回编码
   P_RETURN_MSG  out varchar2); --返回提示信息

  procedure P_APPLY_LOCK
  -- 价格申请锁（提货订单评审时），PriceApplyBO.lock(‘批文明细ID’，‘占用数量’，‘关联单号’ )
  (P_APPLY_DETAIL_ID in T_BD_PRICE_APPLY_DETAIL.APPLY_DETAIL_ID%TYPE, --批文明细ID
   P_LOCK_CNT        IN NUMBER, --锁定数量
   P_BILL_NO         IN VARCHAR2, -- 关联单号
   P_RETURN_CODE     out varchar2, --返回编码，1成功，0失败
   P_RETURN_MSG      out varchar2); --返回提示信息

  procedure P_APPLY_UNLOCK
  -- 价格申请解锁（提货订单评审驳回时），PriceApplyBO.unlock(‘批文明细ID’，'解锁数量’，‘关联单号’ )
  (P_APPLY_DETAIL_ID in T_BD_PRICE_APPLY_DETAIL.APPLY_DETAIL_ID%TYPE, --批文明细ID
   P_UNLOCK_CNT      IN NUMBER, --解除锁定数量
   P_BILL_NO         IN VARCHAR2, -- 关联单号
   P_RETURN_CODE     out varchar2, --返回编码，1成功，0失败
   P_RETURN_MSG      out varchar2); --返回提示信息

  procedure P_APPLY_EXECUTE
  -- 价格申请执行（生成销售单时），PriceApplyBO.execute(‘批文明细ID’，‘占用数量’，‘关联单号’ ,'更新锁标识')，
  (P_APPLY_DETAIL_ID in T_BD_PRICE_APPLY_DETAIL.APPLY_DETAIL_ID%TYPE, --批文明细ID
   P_EXE_CNT         IN NUMBER, --执行数量
   P_BILL_NO         IN VARCHAR2, -- 关联单号
   P_UPDATE_LOCK     IN VARCHAR2, --更新锁标识为Y，则需要解锁
   P_RETURN_CODE     out varchar2, --返回编码，1成功，0失败
   P_RETURN_MSG      out varchar2); --返回提示信息

  procedure P_APPLY_UNEXECUTE
  -- 价格申请红冲（销售单红冲时），PriceApplyBO.unexecute(‘批文明细ID’，‘占用数量’，‘关联单号’,'更新锁标识' )，
  (P_APPLY_DETAIL_ID in T_BD_PRICE_APPLY_DETAIL.APPLY_DETAIL_ID%TYPE, --批文明细ID
   P_UNEXE_CNT       IN NUMBER, --红冲数量
   P_BILL_NO         IN VARCHAR2, -- 关联单号
   P_UPDATE_LOCK     IN VARCHAR2, --更新锁标识为Y，则需要解锁
   P_RETURN_CODE     out varchar2, --返回编码，1成功，0失败
   P_RETURN_MSG      out varchar2); --返回提示信息

  -----------------------------------------------------------------------------
  --  取价格列表ID           --
  -----------------------------------------------------------------------------
  PROCEDURE P_GET_PRICE_LIST_ID(P_ENTITY_ID     IN NUMBER,
                                P_ACC_ID        IN t_customer_account.account_id%type, --账户ID
                                P_BILL_DATE     IN VARCHAR2, --单据日期
                                P_PRICE_LIST_ID OUT NUMBER, --价格列表ID
                                P_MESSAGE       out VARCHAR2 --返回是否促销机
                                );

  -----------------------------------------------------------------------------
  --  取价格列表ID   根据中心        --add by wangcong
  -----------------------------------------------------------------------------
  PROCEDURE P_GET_PRICE_LIST_ID_CENTER(P_ENTITY_ID         IN NUMBER,
                                       P_SALES_CENTER_CODE IN T_BD_PRICE_SYSTEM_ORG.SALES_CENTER_CODE%TYPE, --中心CODE
                                       P_BILL_DATE         IN VARCHAR2, --单据日期
                                       P_ITEM_CODE         IN T_BD_PRICE_LINE.ITEM_CODE%TYPE, --产品编码
                                       P_PRICE             OUT NUMBER, --价格
                                       P_MONTH_DISCOUNT    OUT NUMBER, --月返
                                       P_MESSAGE           OUT VARCHAR2 --返回提示信息
                                       );

  -----------------------------------------------------------------------------
  --  价格列表同步（从总部主体同步到对应的销售公司主体）
  -----------------------------------------------------------------------------
  PROCEDURE P_SYN_PRICE_LIST(ON_RESULT  OUT NUMBER, --成功则返回0，否则返回对应的出错代码。
                             OS_MESSAGE OUT VARCHAR2 --成功返回“SUCCESS”；失败返回出错信息。
                             );
  ----------------------------------------------------------------------                           
  -- Author  : huanghb12
  -- Created : 2018/04/20 16:34:40
  -- Purpose : 检查临时表INTF_BD_PRICE_LINE_TMP数据的有效性     
  ----------------------------------------------------------------------
  PROCEDURE P_CHECK_ITEM_INFO_FROM_ERP(P_POST_DATE IN VARCHAR2, P_RESULT OUT VARCHAR2);
  /*取价格列表行过程,入口过程，优惠品，返回价格列表头行 ID*/
  procedure P_GET_PRICE_LINE_YH_BACKID(IN_ACC_ID         IN t_customer_account.account_id%type, --账户ID
                                IS_ITEM_CODE      IN t_bd_item.item_code%type, --产品编码
                                IS_BILL_DATE      IN VARCHAR2, --单据日期 YYYYMMDD
                                IN_PRICE_LIST_ID  IN t_bd_price_list.price_list_id%type, --价格列表ID
                                IN_ENTITY_ID      IN up_org_unit.ENTITY_ID%type, --业务主体ID
                                ON_PRICE          out NUMBER, --返回价格
                                ON_DISCOUNT       out NUMBER, --返回折扣率
                                ON_MONTH_DISCOUNT out NUMBER, --返回月返
                                OS_CX_FLAG        out VARCHAR2, --返回是否促销机
                                OS_COMPE_ATTR     OUT VARCHAR2 --价格行的竞争属性
                                ,price_list_id out NUMBER, 
                                price_line_id out NUMBER
                                );
  -------------------------------------------------------------------------------
  /*
    *   创建日期：2017-07-27
    *     创建者：liangym2
  p_get_price  *   功能说明：取价格行后台接口方法
    */
  -------------------------------------------------------------------------------
  procedure P_GET_PRICE_LINE_BACKID(IN_ACC_ID         IN t_customer_account.account_id%type, --账户ID
                             IS_ITEM_CODE      IN t_bd_item.item_code%type, --产品编码
                             IS_BILL_DATE      IN VARCHAR2, --单据日期,YYYYMMDD
                             IN_PRICE_LIST_ID  IN t_bd_price_list.price_list_id%type, --价格列表ID
                             IN_ENTITY_ID      IN up_org_unit.ENTITY_ID%type, --业务主体ID
                             ON_PRICE          out NUMBER, --返回价格
                             ON_DISCOUNT       out NUMBER, --返回折扣率
                             ON_MONTH_DISCOUNT out NUMBER, --返回月返
                             OS_CX_FLAG        out VARCHAR2, --返回是否促销机
                             OS_COMPE_ATTR     OUT VARCHAR2, --价格行的竞争属性
                             price_list_id out number,
                             price_line_id out number
                             ) ;
  ----------------------------------------------------------------------                           
  -- Author  : lilh6
  -- Created : 2019-06-12
  -- Purpose : 根据选配项定价获取定制机价格     
  ----------------------------------------------------------------------
  procedure P_GET_PRICE_C2M(IN_ACC_ID         IN t_customer_account.account_id%type, --账户ID
                             IS_ITEM_CODE      IN t_bd_item.item_code%type, --产品编码
                             IS_BILL_DATE      IN VARCHAR2, --单据日期,YYYYMMDD
                             IN_PRICE_LIST_ID  IN t_bd_price_list.price_list_id%type, --价格列表ID
                             IN_ENTITY_ID      IN up_org_unit.ENTITY_ID%type, --业务主体ID
                             ON_PRICE          out NUMBER, --返回价格
                             ON_DISCOUNT       out NUMBER, --返回折扣率
                             ON_MONTH_DISCOUNT out NUMBER, --返回月返
                             OS_CX_FLAG        out VARCHAR2, --返回是否促销机
                             OS_COMPE_ATTR     OUT VARCHAR2 --价格行的竞争属性
                             );

END PKG_BD_PRICE;
/

