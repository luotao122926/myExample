create package body PKG_CREDIT_LIMIT is

  PROCEDURE 以下为内部调用的过程 IS
  BEGIN
    NULL;
  END;

  /*
  *   获取客户账户-订金配置
  */
  PROCEDURE P_GET_ACCOUNT_DOWN_PAY(P_ENTITY_ID        NUMBER, --主体ID
                                   P_CUSTOMER_ID      NUMBER, --客户ID
                                   P_ACCOUNT_ID       NUMBER, --账户ID
                                   P_DOWN_PAY_RATIO   OUT NUMBER, --订金比例
                                   P_ORDER_TOP_AMOUNT OUT NUMBER, --订单提货金额上限
                                   P_MESS             OUT VARCHAR2 --返回信息，成功返回SUCCESS，失败返回错误信息
                                   ) IS
  BEGIN
    P_MESS := 'SUCCESS';
    SELECT C.AMOUNT_SCALE, C.ORDER_TOP_AMOUNT
      INTO P_DOWN_PAY_RATIO, P_ORDER_TOP_AMOUNT
      FROM CIMS.T_CREDIT_DOWN_PAY_ACCOUNT C
     WHERE C.ENTITY_ID = P_ENTITY_ID
       AND C.CUSTOMER_ID = P_CUSTOMER_ID
       AND C.ACCOUNT_ID = P_ACCOUNT_ID
          --有效的：系统日期在开始日期、结束日期之间
       AND C.BEGIN_DATE <= TRUNC(SYSDATE, 'DD')
       AND (C.END_DATE IS NULL OR C.END_DATE >= TRUNC(SYSDATE, 'DD'));
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      P_DOWN_PAY_RATIO   := NULL;
      P_ORDER_TOP_AMOUNT := NULL;
    WHEN OTHERS THEN
      P_DOWN_PAY_RATIO   := NULL;
      P_ORDER_TOP_AMOUNT := NULL;
      P_MESS             := PKG_BD.F_ADD_ERROR_LOG('PKG_CREDIT_LIMIT.P_GET_ACCOUNT_DOWN_PAY',
                                                   SQLCODE,
                                                   SUBSTR('根据主体（' ||
                                                          P_ENTITY_ID ||
                                                          '）、客户（' ||
                                                          P_CUSTOMER_ID ||
                                                          '）、账户（' ||
                                                          P_ACCOUNT_ID ||
                                                          '）获取按账户配置-订金比例、提货金额上限异常！请检查！' ||
                                                          SQLERRM,
                                                          1,
                                                          240) || SQLERRM);
  END;

  /*
  *   获取客户信用等级-订金配置
  */
  PROCEDURE P_GET_CREDIT_LEVEL_DOWN_PAY(P_ENTITY_ID        NUMBER, --主体ID
                                        P_CUSTOMER_ID      NUMBER, --客户ID
                                        P_DOWN_PAY_RATIO   OUT NUMBER, --订金比例
                                        P_ORDER_TOP_AMOUNT OUT NUMBER, --订单提货金额上限
                                        P_MESS             OUT VARCHAR2 --返回信息，成功返回SUCCESS，失败返回错误信息
                                        ) IS
    V_CUST_CREDIT_LEVEL CIMS.T_CUSTOMER_SALES_MAIN_TYPE.CUSTOM_CREDIT_LEVEL%TYPE; --客户信用等级
    V_MESS              VARCHAR2(1000); --提示信息
  BEGIN
    P_MESS := 'SUCCESS';
    BEGIN
      V_MESS := '）获取客户最高信用等级异常！请检查！';
      SELECT MIN(NVL(T.CUSTOM_CREDIT_LEVEL, 0))
        INTO V_CUST_CREDIT_LEVEL
        FROM CIMS.T_CUSTOMER_SALES_MAIN_TYPE T
       WHERE T.ENTITY_ID = P_ENTITY_ID
         AND T.CUSTOM_ID = P_CUSTOMER_ID
         AND NVL(T.ACTIVE_FLAG, 'Inactive') = 'Active';
      V_MESS := '）获取按客户信用等级配置-订金比例、提货金额上限异常！请检查！';
      SELECT L.AMOUNT_SCALE, L.ORDER_TOP_AMOUNT
        INTO P_DOWN_PAY_RATIO, P_ORDER_TOP_AMOUNT
        FROM CIMS.T_CREDIT_DOWN_PAY_LEVEL L
       WHERE L.ENTITY_ID = P_ENTITY_ID
         AND L.CUSTOM_CREDIT_LEVEL = V_CUST_CREDIT_LEVEL
            --有效的：系统日期在开始日期、结束日期之间
         AND L.BEGIN_DATE <= TRUNC(SYSDATE, 'DD')
         AND (L.END_DATE IS NULL OR L.END_DATE >= TRUNC(SYSDATE, 'DD'));
    EXCEPTION
      --获取信用等级为空，则返回NULL
      WHEN NO_DATA_FOUND THEN
        P_DOWN_PAY_RATIO   := NULL;
        P_ORDER_TOP_AMOUNT := NULL;
      WHEN OTHERS THEN
        P_DOWN_PAY_RATIO   := NULL;
        P_ORDER_TOP_AMOUNT := NULL;
        P_MESS             := PKG_BD.F_ADD_ERROR_LOG('PKG_CREDIT_LIMIT.P_GET_CREDIT_LEVEL_DOWN_PAY',
                                                     SQLCODE,
                                                     SUBSTR('根据主体（' ||
                                                            P_ENTITY_ID ||
                                                            '）、客户（' ||
                                                            P_CUSTOMER_ID ||
                                                            V_MESS ||
                                                            SQLERRM,
                                                            1,
                                                            240) || SQLERRM);
    END;
  END;

  /*
  *   获取系统参数-订金配置
  */
  PROCEDURE P_GET_SYS_PARAM_DOWN_PAY(P_ENTITY_ID        NUMBER, --主体ID
                                     P_DOWN_PAY_RATIO   OUT NUMBER, --订金比例
                                     P_ORDER_TOP_AMOUNT OUT NUMBER, --订单提货金额上限
                                     P_MESS             OUT VARCHAR2 --返回信息，成功返回SUCCESS，失败返回错误信息
                                     ) IS
    V_NUM1 NUMBER := 0; --系统参数配置记录数
    V_NUM2 NUMBER := 0; --系统参数配置记录数
  BEGIN
    P_MESS := 'SUCCESS';
    --当没有配置系统参数时，直接返回NULL，
    SELECT COUNT(*)
      INTO V_NUM1
      FROM T_BD_PARAM_LIST PL
     WHERE PL.PARAM_CODE = 'CREDIT_DOWN_PAY_SCALE'
       AND PL.ACTIVE_FLAG = 'Y';
    IF V_NUM1 > 0 THEN
      --获取系统参数，订金比例
      PKG_BD.P_GET_PARAMETER_VALUE(P_CONFIG_CODE => 'CREDIT_DOWN_PAY_SCALE',
                                   P_ENTITY_ID   => P_ENTITY_ID,
                                   P_UNIT_ID     => '',
                                   P_CUSTOMER_ID => '',
                                   P_PARAM_VALUE => P_DOWN_PAY_RATIO);
    ELSE
      P_DOWN_PAY_RATIO := NULL;
    END IF;
  
    --当没有配置系统参数时，直接返回NULL，
    SELECT COUNT(*)
      INTO V_NUM2
      FROM T_BD_PARAM_LIST PL
     WHERE PL.PARAM_CODE = 'CREDIT_ORDER_TOP_AMOUNT'
       AND PL.ACTIVE_FLAG = 'Y';
    IF V_NUM2 > 0 THEN
      --获取系统参数，提货金额上限
      PKG_BD.P_GET_PARAMETER_VALUE(P_CONFIG_CODE => 'CREDIT_ORDER_TOP_AMOUNT',
                                   P_ENTITY_ID   => P_ENTITY_ID,
                                   P_UNIT_ID     => '',
                                   P_CUSTOMER_ID => '',
                                   P_PARAM_VALUE => P_ORDER_TOP_AMOUNT);
    ELSE
      P_ORDER_TOP_AMOUNT := NULL;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      P_DOWN_PAY_RATIO   := NULL;
      P_ORDER_TOP_AMOUNT := NULL;
      P_MESS             := PKG_BD.F_ADD_ERROR_LOG('PKG_CREDIT_LIMIT.P_GET_SYS_PARAM_DOWN_PAY',
                                                   SQLCODE,
                                                   SUBSTR('根据主体（' ||
                                                          P_ENTITY_ID ||
                                                          '）获取系统参数配置-订金比例、提货金额上限异常！请检查！' ||
                                                          SQLERRM,
                                                          1,
                                                          240) || SQLERRM);
  END;

  /*
  * 更新客户额度表：订金比例、提货金额上限、修改人
  */
  PROCEDURE P_UPDATE_OR_CREATE_ODER_LIMIT(IN_ENTITY_ID   NUMBER, --主体ID
                                          IN_CUSTOMER_ID NUMBER, --客户ID
                                          IN_ACCOUNT_ID  NUMBER, --账户ID
                                          IN_UPDATED_BY  VARCHAR2, --修改人
                                          IN_RATIO       NUMBER, --订金比例
                                          IN_TOP_AMOUNT  NUMBER, --订单提货金额上限
                                          P_MESS         OUT VARCHAR2 --返回信息，成功返回SUCCESS，失败返回错误信息
                                          ) IS
    V_LIMIT_ID NUMBER; --已存在的客户额度表主键ID
  BEGIN
    P_MESS := 'SUCCESS';
    BEGIN
      SELECT M.ACCOUNT_LIMIT_ID
        INTO V_LIMIT_ID
        FROM CIMS.T_CREDIT_ACCOUNT_LIMIT M
       WHERE M.ENTITY_ID = IN_ENTITY_ID
         AND M.CUSTOMER_ID = IN_CUSTOMER_ID
         AND M.ACCOUNT_ID = IN_ACCOUNT_ID;
      -- 判断是否存在额度表中
      IF V_LIMIT_ID IS NOT NULL THEN
        BEGIN
          --更新原有数据的订金比例、提货金额上限、最后更新人、最后更新日期
          UPDATE T_CREDIT_ACCOUNT_LIMIT M
             SET DOWN_PAY_RATE      = IN_RATIO,
                 ORDER_LIMIT_AMOUNT = IN_TOP_AMOUNT,
                 LAST_UPDATED_BY    = IN_UPDATED_BY,
                 LAST_UPDATE_DATE   = SYSDATE
           WHERE M.ACCOUNT_LIMIT_ID = V_LIMIT_ID;
        EXCEPTION
          WHEN OTHERS THEN
            P_MESS := PKG_BD.F_ADD_ERROR_LOG('PKG_CREDIT_LIMIT.P_UPDATE_OR_CREATE_ODER_LIMIT',
                                             SQLCODE,
                                             SUBSTR('更新客户额度表T_CREDIT_ACCOUNT_LIMIT异常！请联系管理员！' ||
                                                    SQLERRM,
                                                    1,
                                                    240) || SQLERRM);
        END;
      END IF;
    EXCEPTION
      -- 不存在额度表中，则插入一条新记录
      WHEN NO_DATA_FOUND THEN
        BEGIN
          INSERT INTO T_CREDIT_ACCOUNT_LIMIT
            (ACCOUNT_LIMIT_ID,
             CUSTOMER_ID,
             CUSTOMER_CODE,
             CUSTOMER_NAME,
             SALES_CENTER_ID,
             SALES_CENTER_CODE,
             SALES_CENTER_NAME,
             ACCOUNT_ID,
             ACCOUNT_CODE,
             DOWN_PAY_RATE,
             ORDER_LIMIT_AMOUNT,
             ORDER_USED_AMOUNT,
             ENTITY_ID,
             CREATED_BY,
             CREATION_DATE,
             LAST_UPDATED_BY,
             LAST_UPDATE_DATE)
            SELECT S_CREDIT_ACCOUNT_LIMIT.NEXTVAL,
                   --客户ID
                   IN_CUSTOMER_ID,
                   --客户编码
                   V.CUSTOMER_CODE,
                   --客户名称
                   V.CUSTOMER_NAME,
                   --中心ID
                   V.SALES_CENTER_ID,
                   --中心编码
                   V.SALES_CENTER_CODE,
                   --中心名称
                   V.SALES_CENTER_NAME,
                   --账户ID
                   IN_ACCOUNT_ID,
                   --账户编码
                   V.ACCOUNT_CODE,
                   --订金比例
                   IN_RATIO,
                   --提货金额上限
                   IN_TOP_AMOUNT,
                   --订单已使用金额
                   0,
                   --主体ID
                   IN_ENTITY_ID,
                   --创建人
                   IN_UPDATED_BY,
                   --创建时间
                   SYSDATE,
                   --修改人
                   IN_UPDATED_BY,
                   --修改时间
                   SYSDATE
              FROM CIMS.V_CUSTOMER_ACCOUNT_SALECENTER V
             WHERE V.ENTITY_ID = IN_ENTITY_ID
               AND V.CUSTOMER_ID = IN_CUSTOMER_ID
               AND V.ACCOUNT_ID = IN_ACCOUNT_ID
               AND V.ACTIVE_FLAG = 'Active'
               AND V.ACCOUNT_STATUS = '1'
               AND V.ORGACTIVE_FLAG = 'Active';
        EXCEPTION
          WHEN OTHERS THEN
            P_MESS := PKG_BD.F_ADD_ERROR_LOG('PKG_CREDIT_LIMIT.P_UPDATE_OR_CREATE_ODER_LIMIT',
                                             SQLCODE,
                                             SUBSTR('插入客户额度表T_CREDIT_ACCOUNT_LIMIT异常！请联系管理员！' ||
                                                    SQLERRM,
                                                    1,
                                                    240) || SQLERRM);
        END;
      WHEN OTHERS THEN
        P_MESS := PKG_BD.F_ADD_ERROR_LOG('PKG_CREDIT_LIMIT.P_UPDATE_OR_CREATE_ODER_LIMIT',
                                         SQLCODE,
                                         SUBSTR('根据主体ID=' || IN_ENTITY_ID ||
                                                '、客户ID=' || IN_CUSTOMER_ID ||
                                                '、账户=' || IN_ACCOUNT_ID ||
                                                '，查询客户额度表T_CREDIT_ACCOUNT_LIMIT异常！请联系管理员！' ||
                                                SQLERRM,
                                                1,
                                                240) || SQLERRM);
    END;
  END;

  PROCEDURE 以下为订金的过程 IS
  BEGIN
    NULL;
  END;

  ----------------------------------------------------------------------------------------------------
  /*   
  *  获取订金比例、提货金额上限
  *    1、优先根据账户ID获取客户账户订金配置；
  *    2、若第1步获取不到，则根据客户ID获取客户最高信用等级，然后获取客户信用等级订金配置；
  *    3、若第2步获取不到，则根据系统参数，获取订金配置；
  */
  ----------------------------------------------------------------------------------------------------
  PROCEDURE P_GET_DOWN_PAY_CFG(IN_ENTITY_ID        NUMBER, --主体ID
                               IN_CUSTOMER_ID      NUMBER, --客户ID
                               IN_ACCOUNT_ID       NUMBER, --账户ID
                               ON_DOWN_PAY_AMOUNT  OUT NUMBER, --订金比例
                               ON_ORDER_TOP_AMOUNT OUT NUMBER, --订单提货金额上限
                               OS_MESSAGE          OUT VARCHAR2 --成功返回“SUCCESS”；失败返回出错信息。
                               ) IS
  BEGIN
    OS_MESSAGE := 'SUCCESS';
    IF IN_ENTITY_ID IS NULL THEN
      OS_MESSAGE := '入参主体ID不能为空！';
      RAISE V_BIZ_EXCEPTION;
    ELSIF IN_CUSTOMER_ID IS NULL THEN
      OS_MESSAGE := '入参客户ID不能为空！';
      RAISE V_BIZ_EXCEPTION;
    ELSIF IN_ACCOUNT_ID IS NULL THEN
      OS_MESSAGE := '入参账户ID不能为空！';
      RAISE V_BIZ_EXCEPTION;
    END IF;
    BEGIN
      --第 1 步：获取账户-订金配置
      P_GET_ACCOUNT_DOWN_PAY(P_ENTITY_ID        => IN_ENTITY_ID,
                             P_CUSTOMER_ID      => IN_CUSTOMER_ID,
                             P_ACCOUNT_ID       => IN_ACCOUNT_ID,
                             P_DOWN_PAY_RATIO   => ON_DOWN_PAY_AMOUNT,
                             P_ORDER_TOP_AMOUNT => ON_ORDER_TOP_AMOUNT,
                             P_MESS             => OS_MESSAGE);
      --当订金比例、提货金额上限都为空时，返回信息=SUCCES。继续获取
      IF OS_MESSAGE = 'SUCCESS' AND ON_DOWN_PAY_AMOUNT IS NULL AND
         ON_ORDER_TOP_AMOUNT IS NULL THEN
        --第 2 步：获取客户信用等级-订金配置
        P_GET_CREDIT_LEVEL_DOWN_PAY(P_ENTITY_ID        => IN_ENTITY_ID,
                                    P_CUSTOMER_ID      => IN_CUSTOMER_ID,
                                    P_DOWN_PAY_RATIO   => ON_DOWN_PAY_AMOUNT,
                                    P_ORDER_TOP_AMOUNT => ON_ORDER_TOP_AMOUNT,
                                    P_MESS             => OS_MESSAGE);
        IF OS_MESSAGE = 'SUCCESS' AND ON_DOWN_PAY_AMOUNT IS NULL AND
           ON_ORDER_TOP_AMOUNT IS NULL THEN
          --第 3 步：获取系统参数-订金配置
          P_GET_SYS_PARAM_DOWN_PAY(P_ENTITY_ID        => IN_ENTITY_ID,
                                   P_DOWN_PAY_RATIO   => ON_DOWN_PAY_AMOUNT,
                                   P_ORDER_TOP_AMOUNT => ON_ORDER_TOP_AMOUNT,
                                   P_MESS             => OS_MESSAGE);
        END IF;
      END IF;
    EXCEPTION
      WHEN V_BIZ_EXCEPTION THEN
        OS_MESSAGE := '传入参数错误：获取订金比例、提货金额上限，' || OS_MESSAGE;
      WHEN OTHERS THEN
        OS_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_CREDIT_LIMIT.P_GET_DOWN_PAY_CFG',
                                             SQLCODE,
                                             SUBSTR('根据主体（' || IN_ENTITY_ID ||
                                                    '）、客户（' ||
                                                    IN_CUSTOMER_ID ||
                                                    '）、账户（' || IN_ACCOUNT_ID ||
                                                    '）获取订金比例、提货金额上限异常！请检查！' ||
                                                    SQLERRM,
                                                    1,
                                                    240) || SQLERRM);
    END;
  END;

  ----------------------------------------------------------------------------------------------------
  /*
  *  获取订单可提货金额
  *    1） 根据传入的客户ID、账户ID、主体ID，查询客户账户额度表；
  *    2） 如果查询到相应参数的一条记录，得到订单提货金额上限（A：取字段ORDER_LIMIT_AMOUNT）、订单未提货金额（B：取字段ORDER_USED_AMOUNT，名称亦为已使用订单金额），返回订单可提货金额C=A-B；
  *    3） 如果查询到多条记录，报错；
  *    4） 如果没有记录，返回空值NULL。
  */
  ----------------------------------------------------------------------------------------------------
  FUNCTION FUN_GET_ORDER_AMOUNT(IN_ENTITY_ID   NUMBER, --主体ID
                                IN_CUSTOMER_ID NUMBER, --客户ID
                                IN_ACCOUNT_ID  NUMBER --账户ID
                                ) RETURN NUMBER IS
    V_ORDER_AMOUNT NUMBER;
  BEGIN
    --当订单提货金额上限为空时，返回NULL。
    SELECT M.ORDER_LIMIT_AMOUNT - NVL(M.ORDER_USED_AMOUNT, 0)
      INTO V_ORDER_AMOUNT
      FROM CIMS.T_CREDIT_ACCOUNT_LIMIT M
     WHERE M.ENTITY_ID = IN_ENTITY_ID
       AND M.CUSTOMER_ID = IN_CUSTOMER_ID
       AND M.ACCOUNT_ID = IN_ACCOUNT_ID;
    RETURN V_ORDER_AMOUNT;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      RETURN NULL;
    WHEN OTHERS THEN
      V_ERROR_INFO := PKG_BD.F_ADD_ERROR_LOG('PKG_CREDIT_LIMIT.FUN_GET_ORDER_AMOUNT',
                                             SQLCODE,
                                             SUBSTR('根据主体ID=' ||
                                                    IN_ENTITY_ID || '、客户ID=' ||
                                                    IN_CUSTOMER_ID || '、账户=' ||
                                                    IN_ACCOUNT_ID ||
                                                    '，查询订单可提货金额异常！请检查！' ||
                                                    SQLERRM,
                                                    1,
                                                    240) || SQLERRM);
    
  END;

  ----------------------------------------------------------------------------------------------------
  /*
  *  更新客户账户额度表（订金-账户配置）
  *    1） 客户账户订金配置新增记录，更新额度表；
  *    2） 客户账户订金配置修改记录，更新额度表；
  *    3） CRM推送处理自动创建有效账户时，更新额度表；
  *    实现步骤：
  *       1、获取按账户配置的订金比例、订单提货金额上限；
  *       2、获取成功，则判断客户额度表中是否存在该配置；获取失败，则不更新，也不插入；
  *       3、若额度表中存在，则更新订金比例、订单提货金额上限；
  *       4、若额度表中不存在，则获取客户、账户、中心信息，插入一条新记录到额度表。
  */
  ----------------------------------------------------------------------------------------------------
  PROCEDURE P_SET_ORDER_LIMIT_AMOUNT_ACC(IN_ENTITY_ID   NUMBER, --主体ID
                                         IN_CUSTOMER_ID NUMBER, --客户ID
                                         IN_ACCOUNT_ID  NUMBER, --账户ID
                                         IN_UPDATED_BY  VARCHAR2, --修改人
                                         OS_MESSAGE     OUT VARCHAR2 --成功返回“SUCCESS”；失败返回出错信息。
                                         ) IS
    V_RATIO      NUMBER; --订金比例
    V_TOP_AMOUNT NUMBER; --提货金额上限
  
  BEGIN
    OS_MESSAGE := 'SUCCESS';
    -- 获取账户-订金配置
    P_GET_DOWN_PAY_CFG(IN_ENTITY_ID        => IN_ENTITY_ID,
                       IN_CUSTOMER_ID      => IN_CUSTOMER_ID,
                       IN_ACCOUNT_ID       => IN_ACCOUNT_ID,
                       ON_DOWN_PAY_AMOUNT  => V_RATIO, --订金比例
                       ON_ORDER_TOP_AMOUNT => V_TOP_AMOUNT, --订单提货金额上限
                       OS_MESSAGE          => OS_MESSAGE);
    IF OS_MESSAGE = 'SUCCESS' THEN
      --更新或插入客户额度表
      P_UPDATE_OR_CREATE_ODER_LIMIT(IN_ENTITY_ID   => IN_ENTITY_ID, --主体ID
                                    IN_CUSTOMER_ID => IN_CUSTOMER_ID, --客户ID
                                    IN_ACCOUNT_ID  => IN_ACCOUNT_ID, --账户ID
                                    IN_UPDATED_BY  => IN_UPDATED_BY, --修改人
                                    IN_RATIO       => V_RATIO, --订金比例
                                    IN_TOP_AMOUNT  => V_TOP_AMOUNT, --订单提货金额上限
                                    P_MESS         => OS_MESSAGE);
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      OS_MESSAGE   := '订金-账户配置：更新订金比例、提货金额上限异常，请检查！';
      V_ERROR_INFO := PKG_BD.F_ADD_ERROR_LOG('PKG_CREDIT_LIMIT.P_SET_ORDER_LIMIT_AMOUNT_ACC',
                                             SQLCODE,
                                             SUBSTR('根据主体ID=' ||
                                                    IN_ENTITY_ID || '、客户ID=' ||
                                                    IN_CUSTOMER_ID || '、账户=' ||
                                                    IN_ACCOUNT_ID ||
                                                    '，更新订金比例、提货金额上限异常！请检查！' ||
                                                    SQLERRM,
                                                    1,
                                                    240) || SQLERRM);
    
  END;

  ----------------------------------------------------------------------------------------------------
  /*
  *  更新客户账户额度表（订金-信用等级配置）
  *    1） 客户信用等级订金配置新增记录，更新额度表；
  *    2） 客户信用等级订金配置修改记录，更新额度表；
  *    实现步骤：
  *       1、获取按信用等级配置的订金比例、订单提货金额上限；
  *       2、获取成功，则判断客户额度表中是否存在该配置；获取失败，则不更新，也不插入；
  *       3、若额度表中存在，则更新订金比例、订单提货金额上限；
  *       4、若额度表中不存在，则获取客户、账户、中心信息，插入一条新记录到额度表。
  */
  ----------------------------------------------------------------------------------------------------
  PROCEDURE P_SET_ORDER_LIMIT_AMOUNT_CUS(IN_ENTITY_ID    NUMBER, --主体ID
                                         IN_CREDIT_LEVEL NUMBER, --客户信用等级
                                         IN_UPDATED_BY   VARCHAR2, --修改人
                                         OS_MESSAGE      OUT VARCHAR2 --成功返回“SUCCESS”；失败返回出错信息。
                                         ) IS
    V_DOWN_PAY_RAIO    NUMBER; --订金比例
    V_ORDER_TOP_AMOUNT NUMBER; --订单提货金额上限
  
    CURSOR C_CUST_ACC_INFO IS
      SELECT A.ACCOUNT_ID, A.CUSTOMER_ID
        FROM CIMS.T_CUSTOMER_ACCOUNT A
       WHERE A.ENTITY_ID = IN_ENTITY_ID
         AND A.ACTIVE_FLAG = 'Y'
         AND EXISTS (SELECT TT.CUSTOM_ID
                FROM CIMS.T_CUSTOMER_SALES_MAIN_TYPE TT
               WHERE TT.ENTITY_ID = IN_ENTITY_ID
                 AND A.CUSTOMER_ID = TT.CUSTOM_ID
                 AND TT.ACTIVE_FLAG = 'Active'
               GROUP BY TT.CUSTOM_ID
              HAVING MIN(TT.CUSTOM_CREDIT_LEVEL) = IN_CREDIT_LEVEL)
         AND NOT EXISTS (SELECT PA.ACCOUNT_ID
                FROM T_CREDIT_DOWN_PAY_ACCOUNT PA
               WHERE PA.ENTITY_ID = A.ENTITY_ID
                 AND PA.ACCOUNT_ID = A.ACCOUNT_ID
                 AND PA.CUSTOMER_ID = A.CUSTOMER_ID);
    R_CUST_ACC_INFO C_CUST_ACC_INFO%ROWTYPE;
  BEGIN
    FOR R_CUST_ACC_INFO IN C_CUST_ACC_INFO LOOP
      BEGIN
        --获取订金比例、订单提货额度上限
        P_GET_DOWN_PAY_CFG(IN_ENTITY_ID        => IN_ENTITY_ID, --主体ID
                           IN_CUSTOMER_ID      => R_CUST_ACC_INFO.CUSTOMER_ID, --客户ID
                           IN_ACCOUNT_ID       => R_CUST_ACC_INFO.ACCOUNT_ID, --账户ID
                           ON_DOWN_PAY_AMOUNT  => V_DOWN_PAY_RAIO, --订金比例
                           ON_ORDER_TOP_AMOUNT => V_ORDER_TOP_AMOUNT, --订单提货金额上限
                           OS_MESSAGE          => OS_MESSAGE --成功返回“SUCCESS”；失败返回出错信息。
                           );
        IF OS_MESSAGE = 'SUCCESS' THEN
          --更新或插入客户额度表
          P_UPDATE_OR_CREATE_ODER_LIMIT(IN_ENTITY_ID   => IN_ENTITY_ID, --主体ID
                                        IN_CUSTOMER_ID => R_CUST_ACC_INFO.CUSTOMER_ID, --客户ID
                                        IN_ACCOUNT_ID  => R_CUST_ACC_INFO.ACCOUNT_ID, --账户ID
                                        IN_UPDATED_BY  => IN_UPDATED_BY, --修改人
                                        IN_RATIO       => V_DOWN_PAY_RAIO, --订金比例
                                        IN_TOP_AMOUNT  => V_ORDER_TOP_AMOUNT, --订单提货金额上限
                                        P_MESS         => OS_MESSAGE);
        END IF;
      END;
    END LOOP;
  EXCEPTION
    WHEN OTHERS THEN
      OS_MESSAGE   := '订金-信用等级配置：更新订金比例、提货金额上限异常，请检查！';
      V_ERROR_INFO := PKG_BD.F_ADD_ERROR_LOG('PKG_CREDIT_LIMIT.P_SET_ORDER_LIMIT_AMOUNT_CUS',
                                             SQLCODE,
                                             SUBSTR('根据主体=' || IN_ENTITY_ID ||
                                                    '、客户信用等级=' ||
                                                    IN_CREDIT_LEVEL ||
                                                    '，更新订金比例、提货金额上限异常！请检查！' ||
                                                    SQLERRM,
                                                    1,
                                                    240) || SQLERRM);
  END;

  ----------------------------------------------------------------------------------------------------
  /*
  *  更新客户账户额度表：订金比例、订单提货金额（订金-系统参数配置）
  */
  ----------------------------------------------------------------------------------------------------
  PROCEDURE P_SET_ORDER_LIMIT_AMOUNT_ENT(IN_ENTITY_ID  NUMBER, --主体ID
                                         IN_UPDATED_BY VARCHAR2, --修改人
                                         OS_MESSAGE    OUT VARCHAR2 --成功返回“SUCCESS”；失败返回出错信息。
                                         ) IS
  
    V_DOWN_PAY_RAIO    NUMBER; --订金比例
    V_ORDER_TOP_AMOUNT NUMBER; --订单提货金额上限
    --需要获取
    CURSOR C_CUST_INFO IS
      SELECT A.ACCOUNT_ID, A.CUSTOMER_ID
        FROM CIMS.T_CUSTOMER_ACCOUNT A
       WHERE A.ENTITY_ID = IN_ENTITY_ID
         AND A.ACTIVE_FLAG = 'Y'
         AND NOT EXISTS (SELECT TT.CUSTOM_ID, L.CUSTOM_CREDIT_LEVEL
                FROM CIMS.T_CUSTOMER_SALES_MAIN_TYPE TT,
                     CIMS.T_CREDIT_DOWN_PAY_LEVEL    L
               WHERE A.CUSTOMER_ID = TT.CUSTOM_ID
                 AND TT.ENTITY_ID = L.ENTITY_ID
                 AND TT.ACTIVE_FLAG = 'Active'
                 AND L.ENTITY_ID = IN_ENTITY_ID
                 AND L.BEGIN_DATE <= TRUNC(SYSDATE, 'DD')
                 AND (L.END_DATE IS NULL OR
                     L.END_DATE >= TRUNC(SYSDATE, 'DD'))
               GROUP BY TT.CUSTOM_ID, L.CUSTOM_CREDIT_LEVEL
              HAVING MIN(TT.CUSTOM_CREDIT_LEVEL) = L.CUSTOM_CREDIT_LEVEL)
         AND NOT EXISTS (SELECT PA.ACCOUNT_ID
                FROM T_CREDIT_DOWN_PAY_ACCOUNT PA
               WHERE PA.ENTITY_ID = A.ENTITY_ID
                 AND PA.ACCOUNT_ID = A.ACCOUNT_ID
                 AND PA.CUSTOMER_ID = A.CUSTOMER_ID);
    R_CUST_INFO C_CUST_INFO%ROWTYPE;
  BEGIN
    FOR R_CUST_INFO IN C_CUST_INFO LOOP
      BEGIN
        --获取订金比例、订单提货额度上限
        P_GET_DOWN_PAY_CFG(IN_ENTITY_ID        => IN_ENTITY_ID, --主体ID
                           IN_CUSTOMER_ID      => R_CUST_INFO.CUSTOMER_ID, --客户ID
                           IN_ACCOUNT_ID       => R_CUST_INFO.ACCOUNT_ID, --账户ID
                           ON_DOWN_PAY_AMOUNT  => V_DOWN_PAY_RAIO, --订金比例
                           ON_ORDER_TOP_AMOUNT => V_ORDER_TOP_AMOUNT, --订单提货金额上限
                           OS_MESSAGE          => OS_MESSAGE --成功返回“SUCCESS”；失败返回出错信息。
                           );
        IF OS_MESSAGE = 'SUCCESS' THEN
          --更新或插入客户额度表
          P_UPDATE_OR_CREATE_ODER_LIMIT(IN_ENTITY_ID   => IN_ENTITY_ID, --主体ID
                                        IN_CUSTOMER_ID => R_CUST_INFO.CUSTOMER_ID, --客户ID
                                        IN_ACCOUNT_ID  => R_CUST_INFO.ACCOUNT_ID, --账户ID
                                        IN_UPDATED_BY  => IN_UPDATED_BY, --修改人
                                        IN_RATIO       => V_DOWN_PAY_RAIO, --订金比例
                                        IN_TOP_AMOUNT  => V_ORDER_TOP_AMOUNT, --订单提货金额上限
                                        P_MESS         => OS_MESSAGE);
        END IF;
      END;
    END LOOP;
  EXCEPTION
    WHEN OTHERS THEN
      OS_MESSAGE   := '订金-系统参数配置：更新订金比例、提货金额上限异常，请检查！';
      V_ERROR_INFO := PKG_BD.F_ADD_ERROR_LOG('PKG_CREDIT_LIMIT.P_SET_ORDER_LIMIT_AMOUNT_CUS',
                                             SQLCODE,
                                             SUBSTR('根据系统参数（主体=' ||
                                                    IN_ENTITY_ID ||
                                                    '），更新订金比例、提货金额上限异常！请检查！' ||
                                                    SQLERRM,
                                                    1,
                                                    240) || SQLERRM);
  END;

  --更新客户账户额度表：订金比例、订单提货金额（订金-账户、信用等级、系统参数配置，补充更新）
  /*  
  1、查询账户配置表，
  2、存在账户表中，但不存在额度表中，插入额度表；
  3、存在账户表中，存在额度表中，比较订金比例、提货金额上限是否相同，不同则更新额度表；
  4、查询信用等级配置表，不存在账户配置表中
  */
  PROCEDURE P_SET_ORDER_LIMIT_AMOUNT_ALL(P_ENTITY_ID  NUMBER, --主体ID
                                         P_UPDATED_BY VARCHAR2, --修改人
                                         P_MESSAGE    OUT VARCHAR2 --成功返回“SUCCESS”；失败返回出错信息。
                                         ) IS
    V_SYS_DOWN_PAY_RAIO    NUMBER; --订金比例
    V_SYS_ORDER_TOP_AMOUNT NUMBER; --订单提货金额上限
  
    --存在账户配置表中，存在额度表中但是订金比例/提货金额上限不同，或者不存在客户账户额度表中； 
    CURSOR C_DOWN_PAY_ACC_INFO IS
      SELECT T.CUSTOMER_ID,
             T.ACCOUNT_ID,
             T.AMOUNT_SCALE,
             T.ORDER_TOP_AMOUNT
        FROM CIMS.T_CREDIT_DOWN_PAY_ACCOUNT T,
             CIMS.T_CREDIT_ACCOUNT_LIMIT    LT
       WHERE T.ENTITY_ID = P_ENTITY_ID
            --有效的：系统日期在开始日期、结束日期之间
         AND T.BEGIN_DATE <= TRUNC(SYSDATE, 'DD')
         AND (T.END_DATE IS NULL OR T.END_DATE >= TRUNC(SYSDATE, 'DD'))
         AND LT.ENTITY_ID = T.ENTITY_ID
         AND LT.CUSTOMER_ID = T.CUSTOMER_ID
         AND LT.ACCOUNT_ID = T.ACCOUNT_ID
         AND (NVL(T.ORDER_TOP_AMOUNT, -1) <> NVL(LT.ORDER_LIMIT_AMOUNT, -1) OR
             NVL(T.AMOUNT_SCALE, -1) <> NVL(LT.DOWN_PAY_RATE, -1))
      UNION ALL
      SELECT CUSTOMER_ID, ACCOUNT_ID, AMOUNT_SCALE, ORDER_TOP_AMOUNT
        FROM CIMS.T_CREDIT_DOWN_PAY_ACCOUNT T
       WHERE T.ENTITY_ID = P_ENTITY_ID
            --有效的：系统日期在开始日期、结束日期之间
         AND T.BEGIN_DATE <= TRUNC(SYSDATE, 'DD')
         AND (T.END_DATE IS NULL OR T.END_DATE >= TRUNC(SYSDATE, 'DD'))
            --不存在客户账户额度表中
         AND NOT EXISTS (SELECT T.CUSTOMER_ID
                FROM CIMS.T_CREDIT_ACCOUNT_LIMIT LT
               WHERE LT.CUSTOMER_ID = T.CUSTOMER_ID
                 AND LT.ACCOUNT_ID = T.ACCOUNT_ID
                 AND LT.ENTITY_ID = T.ENTITY_ID);
    R_DOWN_PAY_ACC_INFO C_DOWN_PAY_ACC_INFO%ROWTYPE;
  
    --存在客户信用等级配置表中，存在额度表中但是订金比例/提货金额上限不同，或者不存在客户账户额度表中； 
    CURSOR C_DOWN_PAY_CUST_INFO IS
      SELECT M.CUSTOMER_ID,
             M.ACCOUNT_ID,
             M.AMOUNT_SCALE,
             M.ORDER_TOP_AMOUNT
        FROM (SELECT A.ACCOUNT_ID,
                     A.CUSTOMER_ID,
                     L.AMOUNT_SCALE,
                     L.ORDER_TOP_AMOUNT
                FROM CIMS.T_CUSTOMER_ACCOUNT      A,
                     CIMS.T_CREDIT_DOWN_PAY_LEVEL L
               WHERE A.ENTITY_ID = P_ENTITY_ID
                 AND A.ACTIVE_FLAG = 'Y'
                 AND L.ENTITY_ID = A.ENTITY_ID
                 AND L.BEGIN_DATE <= TRUNC(SYSDATE, 'DD')
                 AND (L.END_DATE IS NULL OR
                     L.END_DATE >= TRUNC(SYSDATE, 'DD'))
                 AND EXISTS (SELECT TT.CUSTOM_ID
                        FROM CIMS.T_CUSTOMER_SALES_MAIN_TYPE TT
                       WHERE TT.ENTITY_ID = P_ENTITY_ID
                         AND A.CUSTOMER_ID = TT.CUSTOM_ID
                         AND TT.ACTIVE_FLAG = 'Active'
                       GROUP BY TT.CUSTOM_ID
                      HAVING MIN(TT.CUSTOM_CREDIT_LEVEL) = L.CUSTOM_CREDIT_LEVEL)
                 AND NOT EXISTS
               (SELECT PA.ACCOUNT_ID
                        FROM T_CREDIT_DOWN_PAY_ACCOUNT PA
                       WHERE PA.ENTITY_ID = A.ENTITY_ID
                         AND PA.ACCOUNT_ID = A.ACCOUNT_ID
                         AND PA.CUSTOMER_ID = A.CUSTOMER_ID)) M,
             CIMS.T_CREDIT_ACCOUNT_LIMIT LT
       WHERE LT.ENTITY_ID = P_ENTITY_ID
         AND LT.CUSTOMER_ID = M.CUSTOMER_ID
         AND LT.ACCOUNT_ID = M.ACCOUNT_ID
         AND (NVL(M.ORDER_TOP_AMOUNT, -1) <> NVL(LT.ORDER_LIMIT_AMOUNT, -1) OR
             NVL(M.AMOUNT_SCALE, -1) <> NVL(LT.DOWN_PAY_RATE, -1))
      UNION ALL
      SELECT M.CUSTOMER_ID,
             M.ACCOUNT_ID,
             M.AMOUNT_SCALE,
             M.ORDER_TOP_AMOUNT
        FROM (SELECT A.ACCOUNT_ID,
                     A.CUSTOMER_ID,
                     L.AMOUNT_SCALE,
                     L.ORDER_TOP_AMOUNT
                FROM CIMS.T_CUSTOMER_ACCOUNT      A,
                     CIMS.T_CREDIT_DOWN_PAY_LEVEL L
               WHERE A.ENTITY_ID = P_ENTITY_ID
                 AND A.ACTIVE_FLAG = 'Y'
                 AND L.ENTITY_ID = A.ENTITY_ID
                 AND L.BEGIN_DATE <= TRUNC(SYSDATE, 'DD')
                 AND (L.END_DATE IS NULL OR
                     L.END_DATE >= TRUNC(SYSDATE, 'DD'))
                 AND EXISTS (SELECT TT.CUSTOM_ID
                        FROM CIMS.T_CUSTOMER_SALES_MAIN_TYPE TT
                       WHERE TT.ENTITY_ID = P_ENTITY_ID
                         AND A.CUSTOMER_ID = TT.CUSTOM_ID
                         AND TT.ACTIVE_FLAG = 'Active'
                       GROUP BY TT.CUSTOM_ID
                      HAVING MIN(TT.CUSTOM_CREDIT_LEVEL) = L.CUSTOM_CREDIT_LEVEL)
                 AND NOT EXISTS
               (SELECT PA.ACCOUNT_ID
                        FROM T_CREDIT_DOWN_PAY_ACCOUNT PA
                       WHERE PA.ENTITY_ID = A.ENTITY_ID
                         AND PA.ACCOUNT_ID = A.ACCOUNT_ID
                         AND PA.CUSTOMER_ID = A.CUSTOMER_ID)) M
       WHERE NOT EXISTS (SELECT LT.CUSTOMER_ID
                FROM CIMS.T_CREDIT_ACCOUNT_LIMIT LT
               WHERE LT.CUSTOMER_ID = M.CUSTOMER_ID
                 AND LT.ACCOUNT_ID = M.ACCOUNT_ID
                 AND LT.ENTITY_ID = P_ENTITY_ID);
    R_DOWN_PAY_CUST_INFO C_DOWN_PAY_CUST_INFO%ROWTYPE;
  
    --存在系统参数配置表中，存在额度表中但是订金比例/提货金额上限不同，或者不存在客户账户额度表中； 
    CURSOR C_DOWN_PAY_SYS_INFO IS
      SELECT N.CUSTOMER_ID, N.ACCOUNT_ID
        FROM (SELECT A.ACCOUNT_ID, A.CUSTOMER_ID
                FROM CIMS.T_CUSTOMER_ACCOUNT A
               WHERE A.ENTITY_ID = P_ENTITY_ID
                 AND A.ACTIVE_FLAG = 'Y'
                 AND NOT EXISTS
               (SELECT TT.CUSTOM_ID, L.CUSTOM_CREDIT_LEVEL
                        FROM CIMS.T_CUSTOMER_SALES_MAIN_TYPE TT,
                             CIMS.T_CREDIT_DOWN_PAY_LEVEL    L
                       WHERE A.CUSTOMER_ID = TT.CUSTOM_ID
                         AND TT.ENTITY_ID = L.ENTITY_ID
                         AND TT.ACTIVE_FLAG = 'Active'
                         AND L.ENTITY_ID = P_ENTITY_ID
                         AND L.BEGIN_DATE <= TRUNC(SYSDATE, 'DD')
                         AND (L.END_DATE IS NULL OR
                             L.END_DATE >= TRUNC(SYSDATE, 'DD'))
                       GROUP BY TT.CUSTOM_ID, L.CUSTOM_CREDIT_LEVEL
                      HAVING MIN(TT.CUSTOM_CREDIT_LEVEL) = L.CUSTOM_CREDIT_LEVEL)
                 AND NOT EXISTS
               (SELECT PA.ACCOUNT_ID
                        FROM T_CREDIT_DOWN_PAY_ACCOUNT PA
                       WHERE PA.ENTITY_ID = A.ENTITY_ID
                         AND PA.ACCOUNT_ID = A.ACCOUNT_ID
                         AND PA.CUSTOMER_ID = A.CUSTOMER_ID)) N,
             CIMS.T_CREDIT_ACCOUNT_LIMIT LT
       WHERE LT.ENTITY_ID = P_ENTITY_ID
         AND LT.CUSTOMER_ID = N.CUSTOMER_ID
         AND LT.ACCOUNT_ID = N.ACCOUNT_ID
         AND (NVL(V_SYS_ORDER_TOP_AMOUNT, -1) <>
             NVL(LT.ORDER_LIMIT_AMOUNT, -1) OR
             NVL(V_SYS_DOWN_PAY_RAIO, -1) <> NVL(LT.DOWN_PAY_RATE, -1))
      UNION ALL
      SELECT N.CUSTOMER_ID, N.ACCOUNT_ID
        FROM (SELECT A.ACCOUNT_ID, A.CUSTOMER_ID
                FROM CIMS.T_CUSTOMER_ACCOUNT A
               WHERE A.ENTITY_ID = P_ENTITY_ID
                 AND A.ACTIVE_FLAG = 'Y'
                 AND NOT EXISTS
               (SELECT TT.CUSTOM_ID, L.CUSTOM_CREDIT_LEVEL
                        FROM CIMS.T_CUSTOMER_SALES_MAIN_TYPE TT,
                             CIMS.T_CREDIT_DOWN_PAY_LEVEL    L
                       WHERE A.CUSTOMER_ID = TT.CUSTOM_ID
                         AND TT.ENTITY_ID = L.ENTITY_ID
                         AND TT.ACTIVE_FLAG = 'Active'
                         AND L.ENTITY_ID = P_ENTITY_ID
                         AND L.BEGIN_DATE <= TRUNC(SYSDATE, 'DD')
                         AND (L.END_DATE IS NULL OR
                             L.END_DATE >= TRUNC(SYSDATE, 'DD'))
                       GROUP BY TT.CUSTOM_ID, L.CUSTOM_CREDIT_LEVEL
                      HAVING MIN(TT.CUSTOM_CREDIT_LEVEL) = L.CUSTOM_CREDIT_LEVEL)
                 AND NOT EXISTS
               (SELECT PA.ACCOUNT_ID
                        FROM T_CREDIT_DOWN_PAY_ACCOUNT PA
                       WHERE PA.ENTITY_ID = A.ENTITY_ID
                         AND PA.ACCOUNT_ID = A.ACCOUNT_ID
                         AND PA.CUSTOMER_ID = A.CUSTOMER_ID)) N
       WHERE NOT EXISTS (SELECT LT.CUSTOMER_ID
                FROM CIMS.T_CREDIT_ACCOUNT_LIMIT LT
               WHERE LT.CUSTOMER_ID = N.CUSTOMER_ID
                 AND LT.ACCOUNT_ID = N.ACCOUNT_ID
                 AND LT.ENTITY_ID = P_ENTITY_ID);
    R_DOWN_PAY_SYS_INFO C_DOWN_PAY_SYS_INFO%ROWTYPE;
  
  BEGIN
    P_MESSAGE := 'SUCCESS';
    --第一步：更新信用额度表-账户
    FOR R_DOWN_PAY_ACC_INFO IN C_DOWN_PAY_ACC_INFO LOOP
      BEGIN
        P_UPDATE_OR_CREATE_ODER_LIMIT(IN_ENTITY_ID   => P_ENTITY_ID,
                                      IN_CUSTOMER_ID => R_DOWN_PAY_ACC_INFO.CUSTOMER_ID, --客户ID
                                      IN_ACCOUNT_ID  => R_DOWN_PAY_ACC_INFO.ACCOUNT_ID, --账户ID
                                      IN_UPDATED_BY  => P_UPDATED_BY, --修改人
                                      IN_RATIO       => R_DOWN_PAY_ACC_INFO.AMOUNT_SCALE, --订金比例
                                      IN_TOP_AMOUNT  => R_DOWN_PAY_ACC_INFO.ORDER_TOP_AMOUNT, --订单提货金额上限
                                      P_MESS         => P_MESSAGE --返回信息，成功返回SUCCESS，失败返回错误信息
                                      );
      END;
    END LOOP;
    
    --第二步：更新信用额度表-信用等级
    FOR R_DOWN_PAY_CUST_INFO IN C_DOWN_PAY_CUST_INFO LOOP
      BEGIN
        --会存在一种情况：获取到的客户、中心、账户失效，则不会更新/插入信用额度表，并且不会报错抛出异常
        P_UPDATE_OR_CREATE_ODER_LIMIT(IN_ENTITY_ID   => P_ENTITY_ID,
                                      IN_CUSTOMER_ID => R_DOWN_PAY_CUST_INFO.CUSTOMER_ID, --客户ID
                                      IN_ACCOUNT_ID  => R_DOWN_PAY_CUST_INFO.ACCOUNT_ID, --账户ID
                                      IN_UPDATED_BY  => P_UPDATED_BY, --修改人
                                      IN_RATIO       => R_DOWN_PAY_CUST_INFO.AMOUNT_SCALE, --订金比例
                                      IN_TOP_AMOUNT  => R_DOWN_PAY_CUST_INFO.ORDER_TOP_AMOUNT, --订单提货金额上限
                                      P_MESS         => P_MESSAGE --返回信息，成功返回SUCCESS，失败返回错误信息
                                      );
        IF P_MESSAGE <> 'SUCCESS' THEN
          RAISE V_BIZ_EXCEPTION;
        END IF;
      END;
    END LOOP;
    --第三步：更新信用额度表-系统参数
    --获取系统参数配置：订金比例、订单提货额度上限
    P_GET_SYS_PARAM_DOWN_PAY(P_ENTITY_ID        => P_ENTITY_ID,
                             P_DOWN_PAY_RATIO   => V_SYS_DOWN_PAY_RAIO,
                             P_ORDER_TOP_AMOUNT => V_SYS_ORDER_TOP_AMOUNT,
                             P_MESS             => P_MESSAGE);
    IF P_MESSAGE <> 'SUCCESS' THEN
      RAISE V_BIZ_EXCEPTION;
    END IF;
    FOR R_DOWN_PAY_SYS_INFO IN C_DOWN_PAY_SYS_INFO LOOP
      BEGIN
        P_UPDATE_OR_CREATE_ODER_LIMIT(IN_ENTITY_ID   => P_ENTITY_ID,
                                      IN_CUSTOMER_ID => R_DOWN_PAY_SYS_INFO.CUSTOMER_ID, --客户ID
                                      IN_ACCOUNT_ID  => R_DOWN_PAY_SYS_INFO.ACCOUNT_ID, --账户ID
                                      IN_UPDATED_BY  => P_UPDATED_BY, --修改人
                                      IN_RATIO       => V_SYS_DOWN_PAY_RAIO, --订金比例
                                      IN_TOP_AMOUNT  => V_SYS_ORDER_TOP_AMOUNT, --订单提货金额上限
                                      P_MESS         => P_MESSAGE --返回信息，成功返回SUCCESS，失败返回错误信息
                                      );
        IF P_MESSAGE <> 'SUCCESS' THEN
          RAISE V_BIZ_EXCEPTION;
        END IF;
      END;
    END LOOP;
    COMMIT;
  EXCEPTION
    WHEN V_BIZ_EXCEPTION THEN
      ROLLBACK;
      P_MESSAGE := '订金-配置遗漏补充：更新额度表异常。' || P_MESSAGE;
    WHEN OTHERS THEN
      ROLLBACK;
      P_MESSAGE    := '订金-配置遗漏补充：更新额度表，订金比例、提货金额上限异常，请检查！';
      V_ERROR_INFO := PKG_BD.F_ADD_ERROR_LOG('PKG_CREDIT_LIMIT.P_SET_ORDER_LIMIT_AMOUNT_CUS',
                                             SQLCODE,
                                             SUBSTR('更新订金比例、提货金额上限异常（主体=' ||
                                                    P_ENTITY_ID ||
                                                    '）！请检查！' ||
                                                    SQLERRM,
                                                    1,
                                                    240) || SQLERRM);
  END;
end PKG_CREDIT_LIMIT;
/

