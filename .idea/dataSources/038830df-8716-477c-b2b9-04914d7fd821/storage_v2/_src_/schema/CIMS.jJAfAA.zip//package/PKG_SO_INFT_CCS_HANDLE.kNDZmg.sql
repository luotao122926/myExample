create PACKAGE PKG_SO_INFT_CCS_HANDLE IS
  -------------------------------------------------------------------------------
  --CCS跟CIMS销售管理模块的接口核心处理过程包

  V_BIZ_SRC_RETURN_APPLY                   CONSTANT CHAR(4) := '1011';             --退货申请单
  V_DEFAULT_USER_CCS                       CONSTANT CHAR(3) := 'CCS';              --默认制单人CCS
  V_RETURN_APPLY_STATUS_SUBMIT             CONSTANT CHAR(2) := '11';               --退货申请单提交审核
  V_STATUS_INIT                            CONSTANT CHAR(2) :='01';                --接口表状态 01 初始化 02处理成功 03 处理失败
  V_STATUS_SUCESS                          CONSTANT CHAR(2) :='02';                --接口表状态 01 初始化 02处理成功 03 处理失败
  V_STATUS_FAIL                            CONSTANT CHAR(2) :='03';                --接口表状态 01 初始化 02处理成功 03 处理失败
  V_ARG_ITEM_PRICE_SET_TYPE                CONSTANT VARCHAR2(32) :='SO_ITEM_PRICE_SET_TYPE'; --主体参数：开单时产品价格设置方式
  V_SO_ITEM_PRICE_PRICE_LIST               CONSTANT VARCHAR2(20) :='PRICE_LIST';   --产品价格从价格列表获取
  V_SO_ITEM_PRICE_OPERATOR_SET             CONSTANT VARCHAR2(20) :='OPERATOR_SET'; --产品价格由业务人员制单时制定

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-06-15
  *     创建者：周建刚
  *   功能说明：根据退货申请接口头表生成退货申请头数据
  */  
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_CREATE_APPLY_HEADER(P_SO_APPLY_HEADER_INTF IN      INTF_SO_RETURN_APPLY_HEADER%ROWTYPE, --退货申请接口头记录
                               R_SO_RETURN_APPLY_HEADER     IN OUT  T_SO_RETURN_APPLY_HEADER%ROWTYPE,    --申请单据头
                               P_RESULT                     IN OUT  NUMBER,
                               P_ERR_MSG                    IN OUT  VARCHAR2                           --返回错误
                               );
  
  -------------------------------------------------------------------------------                    
  /*
  *   创建日期：2015-06-16
  *     创建者：周建刚
  *   功能说明：根据退货申请接口行表生成退货申请行数据
  */  
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_CREATE_APPLY_LINE(
                               R_SO_RETURN_APPLY_HEADER     IN OUT   T_SO_RETURN_APPLY_HEADER%ROWTYPE,  --申请单据头
                               R_INTF_SO_RETURN_APPLY_LINE  IN       INTF_SO_RETURN_APPLY_LINE%ROWTYPE,
                               P_RETURN_TOTAL_AMOUNT        IN OUT   NUMBER,      --退货金额                    
                               P_RESULT                     IN OUT   NUMBER,
                               P_ERR_MSG                    IN OUT   VARCHAR2
                               );
                               
  -------------------------------------------------------------------------------                    
  /*
  *   创建日期：2015-06-19
  *     创建者：周建刚
  *   功能说明：根据退货申请接口行表生成退货申请行明细数据
  */  
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_CREATE_APPLY_LINE_DETAIL(
                               R_SO_RETURN_APPLY_HEADER     IN OUT   T_SO_RETURN_APPLY_HEADER%ROWTYPE,  --申请单据头
                               R_SO_RETURN_APPLY_LINE       IN       T_SO_RETURN_APPLY_LINE%ROWTYPE,               
                               P_RESULT                     IN OUT   NUMBER,
                               P_ERR_MSG                    IN OUT   VARCHAR2
                               );
                               
  -------------------------------------------------------------------------------                    
  /*
  *   创建日期：2015-06-19
  *     创建者：周建刚
  *   功能说明：创建退货申请行明细数据
  */  
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_GEN_APPLY_LINE_DETAIL(
                               R_SO_RETURN_APPLY_LINE_DETAIL     IN T_SO_RETURN_APPLY_LINE_DETAIL%ROWTYPE ,            
                               P_RESULT                          IN OUT   NUMBER,
                               P_ERR_MSG                         IN OUT   VARCHAR2
                               );

  -------------------------------------------------------------------------------                    
  /*
  *   创建日期：2015-07-22
  *     创建者：周建刚
  *   功能说明：根据附件接口表数据，更新退货申请单的附件ID
  */  
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_RETURNAPPLY_APPENDIX(P_SO_APPLY_HEADER_INTF IN      INTF_SO_RETURN_APPLY_HEADER%ROWTYPE, --退货申请接口头记录
                               R_SO_RETURN_APPLY_HEADER             IN OUT  T_SO_RETURN_APPLY_HEADER%ROWTYPE,    --申请单据头
                               P_RESULT                             IN OUT  NUMBER,
                               P_ERR_MSG                            IN OUT  VARCHAR2                           --返回错误
                               );
                               
END;
/

