create PACKAGE BODY PKG_SO_SWITCH IS
  /*----------------------------------------------------------------
  *         包：PKG_SO_SWITCH
  *   创建日期：2014-09-28
  *     创建者：廖丽章
  *   功能说明：1、数据切换-根据客户折让余额生成扣率折让单
  *
  *   过程成功：P_RESULT = 0
  *             P_ERR_MSG = 'SUCCESS';
  *
  *   过程失败：P_RESULT < -20000;
  *             P_ERR_MSG = 过程异常失败的提示信息
  *
  */ ----------------------------------------------------------------

  --临时生成扣率折让单（数据割接用）空调
  PROCEDURE P_SO_DISCOUNT_GEN_TMP_KT(P_RESULT  OUT NUMBER, --返回错误ID
                                     P_ERR_MSG OUT VARCHAR2 --返回错误信息
                                     ) IS
    --折让余额（正的）
    CURSOR C_SO_DISCOUNT IS
      SELECT *
        FROM T_SO_TMP_DISCOUNT
       WHERE (GEN_FLAG IS NULL OR GEN_FLAG = 'N')
         AND DISCOUNT_AMOUNT > 0;
    R_SO_DISCOUNT C_SO_DISCOUNT%ROWTYPE;
  
    /*
    --账户、客户、销售中心信息游标     
    CURSOR C_CUST_ACCOUNT IS
      SELECT * FROM V_CUST_ACCOUNT
      WHERE ACCOUNT_ID = P_ACCOUNT_ID 
        AND ENTITY_ID  = P_ENTITY_ID;
    */
    V_CUSTOMER_ID       T_CUSTOMER_HEADER.CUSTOMER_ID%TYPE;
    V_CUSTOMER_NAME     T_CUSTOMER_HEADER.CUSTOMER_NAME%TYPE;
    V_CUSTOMER_CODE     T_CUSTOMER_HEADER.CUSTOMER_CODE%TYPE;
    V_ACCOUNT_ID        T_CUSTOMER_ACCOUNT.ACCOUNT_ID%TYPE;
    V_ACCOUNT_CODE      T_CUSTOMER_ACCOUNT.ACCOUNT_CODE%TYPE;
    V_ACCOUNT_NAME      T_CUSTOMER_ACCOUNT.ACCOUNT_NAME%TYPE;
    V_SALES_CENTER_ID   V_CUST_ACCOUNT.SALES_CENTER_ID%TYPE;
    V_SALES_CENTER_CODE V_CUST_ACCOUNT.SALES_CENTER_CODE%TYPE;
    V_SALES_CENTER_NAME V_CUST_ACCOUNT.SALES_CENTER_NAME%TYPE;
  
    --营销大类编码需要根据每个环境的实际编码来修改
    V_SALES_MAIN_TYPE      T_SO_HEADER.SALES_MAIN_TYPE%TYPE := 'KT';
    V_SALES_MAIN_TYPE_NAME T_SO_HEADER.SALES_MAIN_TYPE_NAME%TYPE := '空调';
  
    V_ENTITY_ID     T_SO_HEADER.ENTITY_ID%TYPE := '10';
    V_PAYMENT_SRC   T_SO_HEADER.PAYMENT_SRC%TYPE := '3'; --'上年度结转资源';
    V_DISCOUNT_ITEM T_SO_HEADER.DISCOUNT_ITEM%TYPE := '5'; --其他录入
    V_DISCOUNT_MODE T_SO_HEADER.DISCOUNT_MODE%TYPE := '1';
    V_SALES_YEAR_ID NUMBER := 2014;
  
    V_SO_NUM       T_SO_HEADER.SO_NUM%TYPE;
    V_SO_HEADER_ID NUMBER;
    V_SO_LINE_ID   NUMBER;
  
    --错误信息
    V_ERR_MSG VARCHAR2(4000) := '';
  
    --虚拟产品
    CURSOR C_ITEM_INFO IS
      SELECT *
        FROM T_BD_ITEM
       WHERE IS_VIRTUAL = 'Y'
            --AND SALES_MAIN_TYPE = V_SALES_MAIN_TYPE
         AND ROWNUM = 1;
    R_ITEM_INFO C_ITEM_INFO%ROWTYPE;
  
    --业务单据类型扩展属性，这行扩展属性可用于控制一些业务逻辑。
    V_BILL_TYPE_ID NUMBER;
    CURSOR C_SO_BILL_TYPE_EXTEND IS
      SELECT *
        FROM V_SO_BILL_TYPE_EXTEND
       WHERE SRC_TYPE_CODE = '1009' --扣率折让单
         AND ENTITY_ID = V_ENTITY_ID
         AND (TRUNC(SYSDATE) BETWEEN BEGIN_DATE AND NVL(END_DATE, SYSDATE))
         AND ROWNUM = 1;
    R_SO_BILL_TYPE_EXTEND C_SO_BILL_TYPE_EXTEND%ROWTYPE;
  
    ----------余额小于0的，生成扣率折让红冲单（如果找不到原单，则不填写原单号字段）-------------
    --折让余额（负的）
    CURSOR C_SO_DISCOUNT_RED IS
      SELECT *
        FROM T_SO_TMP_DISCOUNT
       WHERE (GEN_FLAG IS NULL OR GEN_FLAG = 'N')
         AND DISCOUNT_AMOUNT < 0;
    R_SO_DISCOUNT_RED C_SO_DISCOUNT%ROWTYPE;
  
    --扣率折让红冲
    CURSOR C_SO_BILL_TYPE_EXTEND_RED IS
      SELECT *
        FROM V_SO_BILL_TYPE_EXTEND
       WHERE SRC_TYPE_CODE = '1010' --扣率折让红冲单
         AND ENTITY_ID = V_ENTITY_ID
         AND (TRUNC(SYSDATE) BETWEEN BEGIN_DATE AND NVL(END_DATE, SYSDATE))
         AND ROWNUM = 1;
    R_SO_BILL_TYPE_EXTEND_RED C_SO_BILL_TYPE_EXTEND_RED%ROWTYPE;
  
  BEGIN
    --初始返回值
    P_RESULT  := 0;
    P_ERR_MSG := 'SUCCESS';
  
    --获取虚拟产品        
    OPEN C_ITEM_INFO;
    FETCH C_ITEM_INFO
      INTO R_ITEM_INFO;
    CLOSE C_ITEM_INFO;
  
    --得到单据扩展类型属性
    OPEN C_SO_BILL_TYPE_EXTEND;
    FETCH C_SO_BILL_TYPE_EXTEND
      INTO R_SO_BILL_TYPE_EXTEND;
    CLOSE C_SO_BILL_TYPE_EXTEND;
  
    FOR R_SO_DISCOUNT IN C_SO_DISCOUNT LOOP
      V_ERR_MSG           := '';
      V_SO_NUM            := '';
      V_CUSTOMER_CODE     := R_SO_DISCOUNT.CUSTOMER_CODE;
      V_SALES_CENTER_CODE := R_SO_DISCOUNT.SALES_CENTER_CODE;
    
      BEGIN
        IF (V_SALES_CENTER_CODE IS NULL) THEN
          SELECT DISTINCT CA.CUSTOMER_ID,
                          CA.CUSTOMER_CODE,
                          CA.CUSTOMER_NAME,
                          CA.ACCOUNT_ID,
                          CA.ACCOUNT_CODE,
                          CA.ACCOUNT_NAME,
                          CA.SALES_CENTER_ID,
                          CA.SALES_CENTER_CODE,
                          CA.SALES_CENTER_NAME
            INTO V_CUSTOMER_ID,
                 V_CUSTOMER_CODE,
                 V_CUSTOMER_NAME,
                 V_ACCOUNT_ID,
                 V_ACCOUNT_CODE,
                 V_ACCOUNT_NAME,
                 V_SALES_CENTER_ID,
                 V_SALES_CENTER_CODE,
                 V_SALES_CENTER_NAME
            FROM (SELECT T.*, ROWNUM
                    FROM V_CUST_ACCOUNT T
                   ORDER BY ACCOUNT_ID, SALES_CENTER_ID) CA
           WHERE CA.CUSTOMER_CODE = V_CUSTOMER_CODE
             AND CA.ENTITY_ID = V_ENTITY_ID
                --AND CA.SALES_MAIN_TYPE_CODE = V_SALES_MAIN_TYPE
             AND ROWNUM = 1;
        ELSE
          SELECT DISTINCT CA.CUSTOMER_ID,
                          CA.CUSTOMER_CODE,
                          CA.CUSTOMER_NAME,
                          CA.ACCOUNT_ID,
                          CA.ACCOUNT_CODE,
                          CA.ACCOUNT_NAME,
                          CA.SALES_CENTER_ID,
                          CA.SALES_CENTER_CODE,
                          CA.SALES_CENTER_NAME
            INTO V_CUSTOMER_ID,
                 V_CUSTOMER_CODE,
                 V_CUSTOMER_NAME,
                 V_ACCOUNT_ID,
                 V_ACCOUNT_CODE,
                 V_ACCOUNT_NAME,
                 V_SALES_CENTER_ID,
                 V_SALES_CENTER_CODE,
                 V_SALES_CENTER_NAME
            FROM (SELECT T.*, ROWNUM
                    FROM V_CUST_ACCOUNT T
                   ORDER BY ACCOUNT_ID, SALES_CENTER_ID) CA
           WHERE CA.CUSTOMER_CODE = V_CUSTOMER_CODE
             AND CA.SALES_CENTER_CODE = V_SALES_CENTER_CODE
             AND CA.ENTITY_ID = V_ENTITY_ID
                --AND CA.SALES_MAIN_TYPE_CODE = V_SALES_MAIN_TYPE
             AND ROWNUM = 1;
        END IF;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          --没数据
          V_ERR_MSG := '客户[' || R_SO_DISCOUNT.CUSTOMER_CODE || ',' ||
                       R_SO_DISCOUNT.CUSTOMER_NAME ||
                       ']在V_CUST_ACCOUNT视图里不存在，' || '或不属于营销中心[' ||
                       R_SO_DISCOUNT.SALES_CENTER_CODE || ',' ||
                       R_SO_DISCOUNT.SALES_CENTER_NAME || ']';
        WHEN OTHERS THEN
          --抛出异常
          V_ERR_MSG := '获取客户、账户、营销中心信息发生异常：' || SQLERRM;
      END;
    
      IF (V_ACCOUNT_ID IS NULL) OR (V_SALES_CENTER_ID IS NULL) THEN
        --账户或营销中心没找到
        V_ERR_MSG := V_ERR_MSG || '客户[' || R_SO_DISCOUNT.CUSTOMER_CODE || ',' ||
                     R_SO_DISCOUNT.CUSTOMER_NAME || ']对应的账户或营销中心不存在。';
      END IF;
    
      --销售单据号
      BEGIN
        --单据号前缀（用于单据号生成，取事业部2位编码）：用主体ID
        V_SO_NUM := PKG_BD.F_GET_BILL_NO('SO_NUM',
                                         V_ENTITY_ID,
                                         V_ENTITY_ID,
                                         NULL);
      EXCEPTION
        WHEN OTHERS THEN
          V_ERR_MSG := V_ERR_MSG || 'PKG_BD.F_GET_BILL_NO函数生成销售单据号出错：' ||
                       SQLERRM;
      END;
    
      IF LENGTH(V_ERR_MSG) > 0 THEN
        UPDATE T_SO_TMP_DISCOUNT
           SET ERR_MSG = V_ERR_MSG, GEN_FLAG = 'N'
         WHERE ID = R_SO_DISCOUNT.ID;
      ELSE
        SELECT S_SO_HEADER.NEXTVAL INTO V_SO_HEADER_ID FROM DUAL;
        SELECT S_SO_LINE.NEXTVAL INTO V_SO_LINE_ID FROM DUAL;
      
        INSERT INTO T_SO_HEADER
          (SO_HEADER_ID,
           ENTITY_ID,
           SALES_YEAR_ID,
           BILL_TYPE_ID,
           BILL_TYPE_CODE,
           BILL_TYPE_NAME,
           BIZ_SRC_BILL_TYPE_ID,
           BIZ_SRC_BILL_TYPE_CODE,
           BIZ_SRC_BILL_TYPE_NAME,
           SO_NUM,
           SO_STATUS,
           SO_DATE,
           SALES_MAIN_TYPE,
           SALES_MAIN_TYPE_NAME,
           CUSTOMER_ID,
           CUSTOMER_CODE,
           CUSTOMER_NAME,
           ACCOUNT_ID,
           ACCOUNT_CODE,
           ACCOUNT_NAME,
           SALES_CENTER_ID,
           SALES_CENTER_CODE,
           SALES_CENTER_NAME,
           LIST_AMOUNT,
           SETTLE_AMOUNT,
           DISCOUNT_AMOUNT,
           REBATE_YEAR,
           PAYMENT_SRC,
           DISCOUNT_ITEM,
           DISCOUNT_MODE,
           CREATED_MODE,
           CREATED_BY,
           CREATION_DATE,
           LAST_UPDATED_BY,
           LAST_UPDATE_DATE,
           REMARK)
        VALUES
          (V_SO_HEADER_ID,
           V_ENTITY_ID,
           V_SALES_YEAR_ID,
           R_SO_BILL_TYPE_EXTEND.BILL_TYPE_ID,
           R_SO_BILL_TYPE_EXTEND.BILL_TYPE_CODE,
           R_SO_BILL_TYPE_EXTEND.BILL_TYPE_NAME,
           R_SO_BILL_TYPE_EXTEND.SRC_TYPE_ID,
           R_SO_BILL_TYPE_EXTEND.SRC_TYPE_CODE,
           R_SO_BILL_TYPE_EXTEND.SRC_TYPE_NAME,
           V_SO_NUM,
           '10',
           TRUNC(SYSDATE),
           V_SALES_MAIN_TYPE,
           V_SALES_MAIN_TYPE_NAME,
           V_CUSTOMER_ID,
           V_CUSTOMER_CODE,
           V_CUSTOMER_NAME,
           V_ACCOUNT_ID,
           V_ACCOUNT_CODE,
           V_ACCOUNT_NAME,
           V_SALES_CENTER_ID,
           V_SALES_CENTER_CODE,
           V_SALES_CENTER_NAME,
           R_SO_DISCOUNT.DISCOUNT_AMOUNT, --LIST_AMOUNT,
           R_SO_DISCOUNT.DISCOUNT_AMOUNT, --SETTLE_AMOUNT,
           R_SO_DISCOUNT.DISCOUNT_AMOUNT, --DISCOUNT_AMOUNT,
           '2014',
           V_PAYMENT_SRC,
           V_DISCOUNT_ITEM,
           V_DISCOUNT_MODE,
           '20', --制单方式：10-自动，20-人工。
           'SYS',
           SYSDATE,
           'SYS',
           SYSDATE,
           '本单据为数据切换生成的扣率折让单#' || TRUNC(SYSDATE));
      
        --生成销售单据行
        INSERT INTO T_SO_LINE
          (SO_LINE_ID,
           SO_LINE_NUM,
           SO_HEADER_ID,
           ENTITY_ID,
           SRC_HEADER_ID,
           SRC_LINE_ID,
           ITEM_ID,
           ITEM_CODE,
           ITEM_NAME,
           ITEM_PRICE_LIST_ID,
           ITEM_PRICE,
           ITEM_UOM,
           ITEM_QTY,
           ITEM_IS_SET,
           --RECEIVED_QTY,
           --REVERSAL_QTY,
           --REVERSAL_AMOUNT,
           --RETURN_QTY,
           --RETURN_RECEIVED_QTY,
           --RETURN_FLAG,
           DISCOUNT_RATE,
           MONTH_DISCOUNT_RATE,
           PROJECT_TYPE_CODE,
           PROJECT_ID,
           PROJECT_NUM,
           PROJECT_PRICE,
           ITEM_SETTLE_PRICE,
           ITEM_SETTLE_AMOUNT,
           DISCOUNT_AMOUNT,
           ITEM_LIST_AMOUNT,
           MONTH_DISCOUNT_AMOUNT,
           PROJECT_AMOUNT,
           SETTLE_TYPE_CODE,
           SETTLE_TYPE_NAME,
           ITEM_VOLUME,
           ITEM_WEIGHT,
           SHIP_DOC_LINE_ID,
           ORIGIN_SHIP_PLAN_ID,
           REMARK,
           CREATED_BY,
           CREATION_DATE,
           LAST_UPDATED_BY,
           LAST_UPDATE_DATE)
        VALUES
          (V_SO_LINE_ID, --销售单据行ID
           1, --V_SO_LINE_NUM, --销售单据行号
           V_SO_HEADER_ID, --销售单据头ID
           V_ENTITY_ID, --主体ID
           NULL, --来源头ID
           NULL, --来源行ID
           R_ITEM_INFO.ITEM_ID, --产品ID
           R_ITEM_INFO.ITEM_CODE, --产品编码
           R_ITEM_INFO.ITEM_NAME, --产品名称
           NULL, --产品价格列表
           R_SO_DISCOUNT.DISCOUNT_AMOUNT, --产品价格
           R_ITEM_INFO.DEFAULTUNIT, --R_ITEM_INFO.ITEM_UOM, --产品单位
           1, --产品数量
           'N', --产品是否为套件：Y-是，N-否
           --P_SO_LINE.RECEIVED_QTY, --签收数量
           --P_SO_LINE.REVERSAL_QTY, --已红冲数量，在对销售单据进行红冲后，回写红冲数量到原销售单据
           --P_SO_LINE.REVERSAL_AMOUNT, --已红冲金额，在对折让单据进行红冲后，回写红冲金额到原折让单的本字段
           --P_SO_LINE.RETURN_QTY, --退货单生成时回写退货数量到原销售单据
           --P_SO_LINE.RETURN_RECEIVED_QTY, --退货签收数量
           --P_SO_LINE.RETURN_FLAG, --是否已全退标识
           100, --折扣率
           0, --月返
           NULL, --批文类型编码：LIMIT-限量批文，PG-工程机批文
           NULL, --批文ID
           NULL, --批文编号
           NULL, --批文价格
           R_SO_DISCOUNT.DISCOUNT_AMOUNT, --产品结算价格        
           R_SO_DISCOUNT.DISCOUNT_AMOUNT, --结算金额=产品数量*产品结算价格        
           R_SO_DISCOUNT.DISCOUNT_AMOUNT, --扣率折让金额=产品数量*产品价格*(扣率折让/100)
           R_SO_DISCOUNT.DISCOUNT_AMOUNT, --列表金额
           0, --月返金额=产品数量*产品价格*(月返/100)
           NULL, --批文金额=产品数量*批文价格             
           R_SO_BILL_TYPE_EXTEND.SETTLE_TYPE_CODE, --结算类型编码
           R_SO_BILL_TYPE_EXTEND.SETTLE_TYPE_NAME, --结算类型名
           NULL, --R_ITEM_INFO.ITEM_VOLUME,
           NULL, --R_ITEM_INFO.ITEM_WEIGHT,
           NULL, --发货通知单行ID
           NULL, --来源计划ID：订单计划ID
           '数据切换生成的扣率折让单行#' || TRUNC(SYSDATE),
           'SYS',
           SYSDATE,
           'SYS',
           SYSDATE);
      
        --明细行
        INSERT INTO T_SO_LINE_DETAIL
          (SO_LINE_DETAIL_ID,
           SO_LINE_DETAIL_NUM,
           SO_LINE_ID,
           SO_HEADER_ID,
           ENTITY_ID,
           ITEM_ID,
           ITEM_CODE,
           ITEM_NAME,
           ITEM_QTY,
           ITEM_UOM,
           ITEM_PRICE,
           ITEM_SETTLE_PRICE,
           COMPONENT_ID,
           COMPONENT_CODE,
           COMPONENT_NAME,
           COMPONENT_QTY,
           COMPONENT_PRICE,
           COMPONENT_SETTLE_PRICE,
           COMPONENT_UOM,
           REMARK,
           CREATED_BY,
           CREATION_DATE,
           LAST_UPDATED_BY,
           LAST_UPDATE_DATE)
        VALUES
          (S_SO_LINE_DETAIL.NEXTVAL, --明细行ID
           1, --明细行号
           V_SO_LINE_ID, --行ID
           V_SO_HEADER_ID, --头ID
           V_ENTITY_ID, --主体ID
           R_ITEM_INFO.ITEM_ID, --产品ID
           R_ITEM_INFO.ITEM_CODE, --产品编码
           R_ITEM_INFO.ITEM_NAME, --产品名称
           1, --产品数量
           R_ITEM_INFO.DEFAULTUNIT, --产品单位
           R_SO_DISCOUNT.DISCOUNT_AMOUNT, --产品价格            
           R_SO_DISCOUNT.DISCOUNT_AMOUNT, --产品结算价格
           R_ITEM_INFO.ITEM_ID, --散件ID
           R_ITEM_INFO.ITEM_CODE, --散件编码
           R_ITEM_INFO.ITEM_NAME, --散件名称
           1, --散件数量，取套件的数量。
           R_SO_DISCOUNT.DISCOUNT_AMOUNT, --散件价格,
           R_SO_DISCOUNT.DISCOUNT_AMOUNT, --散件结算价格
           R_ITEM_INFO.DEFAULTUNIT, --散件单位
           NULL, --备注
           'SYS',
           SYSDATE,
           'SYS',
           SYSDATE);
      
        --审核扣率折让单
        UPDATE T_SO_HEADER
           SET AUDIT_BY         = 'SYS', --审核人
               AUDIT_FLAG       = 'Y', --审核标识，Y-已审核，N-未审核
               AUDIT_DATE       = SYSDATE, --审核日期
               SO_STATUS        = '11', --单据状态：10制单，11-已审核，12-已结算
               LAST_UPDATED_BY  = 'SYS',
               LAST_UPDATE_DATE = SYSDATE
         WHERE SO_HEADER_ID = V_SO_HEADER_ID;
      
        --做信用控制（苏冬渊说数据切换，不需要）
        --更新折让余额临时表状态
        UPDATE T_SO_TMP_DISCOUNT
           SET ERR_MSG  = '生成扣率折让单成功，单据号：' || V_SO_NUM || '！',
               GEN_FLAG = 'Y'
         WHERE ID = R_SO_DISCOUNT.ID;
      END IF;
    
    END LOOP;
  
    ----------生成扣率折让红冲单-------------
    OPEN C_SO_BILL_TYPE_EXTEND_RED;
    FETCH C_SO_BILL_TYPE_EXTEND_RED
      INTO R_SO_BILL_TYPE_EXTEND_RED;
    CLOSE C_SO_BILL_TYPE_EXTEND_RED;
  
    DECLARE
      V_SO_ORIG_ID      NUMBER;
      V_SO_ORIG_NUM     VARCHAR2(32);
      V_SO_ORIG_LINE_ID NUMBER;
    
      --找原单，如果找不到就没有原单
      CURSOR C_SO_ORIG IS
        SELECT *
          FROM T_SO_HEADER T
         WHERE T.BIZ_SRC_BILL_TYPE_CODE = '1009'
           AND T.CUSTOMER_CODE = V_CUSTOMER_CODE
           AND T.SALES_CENTER_CODE = V_SALES_CENTER_CODE
           AND ROWNUM = 1;
      R_SO_ORIG C_SO_ORIG%ROWTYPE;
    
    BEGIN
    
      FOR R_SO_DISCOUNT_RED IN C_SO_DISCOUNT_RED LOOP
        V_ERR_MSG           := '';
        V_SO_NUM            := '';
        V_CUSTOMER_CODE     := R_SO_DISCOUNT_RED.CUSTOMER_CODE;
        V_SALES_CENTER_CODE := R_SO_DISCOUNT_RED.SALES_CENTER_CODE;
      
        BEGIN
          IF (V_SALES_CENTER_CODE IS NULL) THEN
            SELECT DISTINCT CA.CUSTOMER_ID,
                            CA.CUSTOMER_CODE,
                            CA.CUSTOMER_NAME,
                            CA.ACCOUNT_ID,
                            CA.ACCOUNT_CODE,
                            CA.ACCOUNT_NAME,
                            CA.SALES_CENTER_ID,
                            CA.SALES_CENTER_CODE,
                            CA.SALES_CENTER_NAME
              INTO V_CUSTOMER_ID,
                   V_CUSTOMER_CODE,
                   V_CUSTOMER_NAME,
                   V_ACCOUNT_ID,
                   V_ACCOUNT_CODE,
                   V_ACCOUNT_NAME,
                   V_SALES_CENTER_ID,
                   V_SALES_CENTER_CODE,
                   V_SALES_CENTER_NAME
              FROM (SELECT T.*, ROWNUM
                      FROM V_CUST_ACCOUNT T
                     ORDER BY ACCOUNT_ID, SALES_CENTER_ID) CA
             WHERE CA.CUSTOMER_CODE = V_CUSTOMER_CODE
               AND CA.ENTITY_ID = V_ENTITY_ID
                  --AND CA.SALES_MAIN_TYPE_CODE = V_SALES_MAIN_TYPE
               AND ROWNUM = 1;
          ELSE
            SELECT DISTINCT CA.CUSTOMER_ID,
                            CA.CUSTOMER_CODE,
                            CA.CUSTOMER_NAME,
                            CA.ACCOUNT_ID,
                            CA.ACCOUNT_CODE,
                            CA.ACCOUNT_NAME,
                            CA.SALES_CENTER_ID,
                            CA.SALES_CENTER_CODE,
                            CA.SALES_CENTER_NAME
              INTO V_CUSTOMER_ID,
                   V_CUSTOMER_CODE,
                   V_CUSTOMER_NAME,
                   V_ACCOUNT_ID,
                   V_ACCOUNT_CODE,
                   V_ACCOUNT_NAME,
                   V_SALES_CENTER_ID,
                   V_SALES_CENTER_CODE,
                   V_SALES_CENTER_NAME
              FROM (SELECT T.*, ROWNUM
                      FROM V_CUST_ACCOUNT T
                     ORDER BY ACCOUNT_ID, SALES_CENTER_ID) CA
             WHERE CA.CUSTOMER_CODE = V_CUSTOMER_CODE
               AND CA.SALES_CENTER_CODE = V_SALES_CENTER_CODE
               AND CA.ENTITY_ID = V_ENTITY_ID
                  --AND CA.SALES_MAIN_TYPE_CODE = V_SALES_MAIN_TYPE
               AND ROWNUM = 1;
          END IF;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            --没数据
            V_ERR_MSG := '客户[' || R_SO_DISCOUNT_RED.CUSTOMER_CODE || ',' ||
                         R_SO_DISCOUNT_RED.CUSTOMER_NAME ||
                         ']在V_CUST_ACCOUNT视图里不存在，' || '或不属于营销中心[' ||
                         R_SO_DISCOUNT_RED.SALES_CENTER_CODE || ',' ||
                         R_SO_DISCOUNT_RED.SALES_CENTER_NAME || ']';
          WHEN OTHERS THEN
            --抛出异常
            V_ERR_MSG := '获取客户、账户、营销中心信息发生异常：' || SQLERRM;
        END;
      
        -----------
        IF (V_ACCOUNT_ID IS NULL) OR (V_SALES_CENTER_ID IS NULL) THEN
          --账户或营销中心没找到
          V_ERR_MSG := V_ERR_MSG || '客户[' ||
                       R_SO_DISCOUNT_RED.CUSTOMER_CODE || ',' ||
                       R_SO_DISCOUNT_RED.CUSTOMER_NAME || ']对应的账户或营销中心不存在。';
        END IF;
      
        --销售单据号
        BEGIN
          --单据号前缀（用于单据号生成，取事业部2位编码）：用主体ID
          V_SO_NUM := PKG_BD.F_GET_BILL_NO('SO_NUM',
                                           V_ENTITY_ID,
                                           V_ENTITY_ID,
                                           NULL);
        EXCEPTION
          WHEN OTHERS THEN
            V_ERR_MSG := V_ERR_MSG || 'PKG_BD.F_GET_BILL_NO函数生成销售单据号出错：' ||
                         SQLERRM;
        END;
      
        IF LENGTH(V_ERR_MSG) > 0 THEN
          UPDATE T_SO_TMP_DISCOUNT
             SET ERR_MSG = V_ERR_MSG, GEN_FLAG = 'N'
           WHERE ID = R_SO_DISCOUNT_RED.ID;
        ELSE
          --取原单
          OPEN C_SO_ORIG;
          FETCH C_SO_ORIG
            INTO R_SO_ORIG;
          CLOSE C_SO_ORIG;
        
          IF (R_SO_ORIG.SO_HEADER_ID IS NOT NULL) THEN
            V_SO_ORIG_ID  := R_SO_ORIG.SO_HEADER_ID;
            V_SO_ORIG_NUM := R_SO_ORIG.SO_NUM;
          
            SELECT SO_LINE_ID
              INTO V_SO_ORIG_LINE_ID
              FROM T_SO_LINE
             WHERE SO_HEADER_ID = V_SO_ORIG_ID
               AND ROWNUM = 1;
          END IF;
        
          SELECT S_SO_HEADER.NEXTVAL INTO V_SO_HEADER_ID FROM DUAL;
          SELECT S_SO_LINE.NEXTVAL INTO V_SO_LINE_ID FROM DUAL;
        
          INSERT INTO T_SO_HEADER
            (SO_HEADER_ID,
             ENTITY_ID,
             SALES_YEAR_ID,
             BILL_TYPE_ID,
             BILL_TYPE_CODE,
             BILL_TYPE_NAME,
             BIZ_SRC_BILL_TYPE_ID,
             BIZ_SRC_BILL_TYPE_CODE,
             BIZ_SRC_BILL_TYPE_NAME,
             SO_NUM,
             SO_STATUS,
             SO_DATE,
             ORIG_SO_NUM,
             SALES_MAIN_TYPE,
             SALES_MAIN_TYPE_NAME,
             CUSTOMER_ID,
             CUSTOMER_CODE,
             CUSTOMER_NAME,
             ACCOUNT_ID,
             ACCOUNT_CODE,
             ACCOUNT_NAME,
             SALES_CENTER_ID,
             SALES_CENTER_CODE,
             SALES_CENTER_NAME,
             LIST_AMOUNT,
             SETTLE_AMOUNT,
             DISCOUNT_AMOUNT,
             REBATE_YEAR,
             PAYMENT_SRC,
             DISCOUNT_ITEM,
             DISCOUNT_MODE,
             CREATED_MODE,
             CREATED_BY,
             CREATION_DATE,
             LAST_UPDATED_BY,
             LAST_UPDATE_DATE,
             REMARK)
          VALUES
            (V_SO_HEADER_ID,
             V_ENTITY_ID,
             V_SALES_YEAR_ID,
             R_SO_BILL_TYPE_EXTEND_RED.BILL_TYPE_ID,
             R_SO_BILL_TYPE_EXTEND_RED.BILL_TYPE_CODE,
             R_SO_BILL_TYPE_EXTEND_RED.BILL_TYPE_NAME,
             R_SO_BILL_TYPE_EXTEND_RED.SRC_TYPE_ID,
             R_SO_BILL_TYPE_EXTEND_RED.SRC_TYPE_CODE,
             R_SO_BILL_TYPE_EXTEND_RED.SRC_TYPE_NAME,
             V_SO_NUM,
             '10',
             TRUNC(SYSDATE),
             V_SO_ORIG_NUM,
             V_SALES_MAIN_TYPE,
             V_SALES_MAIN_TYPE_NAME,
             V_CUSTOMER_ID,
             V_CUSTOMER_CODE,
             V_CUSTOMER_NAME,
             V_ACCOUNT_ID,
             V_ACCOUNT_CODE,
             V_ACCOUNT_NAME,
             V_SALES_CENTER_ID,
             V_SALES_CENTER_CODE,
             V_SALES_CENTER_NAME,
             ABS(R_SO_DISCOUNT_RED.DISCOUNT_AMOUNT), --LIST_AMOUNT,
             ABS(R_SO_DISCOUNT_RED.DISCOUNT_AMOUNT), --SETTLE_AMOUNT,
             ABS(R_SO_DISCOUNT_RED.DISCOUNT_AMOUNT), --DISCOUNT_AMOUNT,
             '2014',
             V_PAYMENT_SRC,
             V_DISCOUNT_ITEM,
             V_DISCOUNT_MODE,
             '20', --制单方式：10-自动，20-人工。
             'SYS',
             SYSDATE,
             'SYS',
             SYSDATE,
             '本单据为数据切换生成的扣率折让红冲单#' || TRUNC(SYSDATE));
        
          DBMS_OUTPUT.PUT_LINE(V_CUSTOMER_CODE || ',item_price=' ||
                               R_SO_DISCOUNT_RED.DISCOUNT_AMOUNT);
        
          --生成销售单据行
          INSERT INTO T_SO_LINE
            (SO_LINE_ID,
             SO_LINE_NUM,
             SO_HEADER_ID,
             ENTITY_ID,
             SRC_HEADER_ID,
             SRC_LINE_ID,
             ITEM_ID,
             ITEM_CODE,
             ITEM_NAME,
             ITEM_PRICE_LIST_ID,
             ITEM_PRICE,
             ITEM_UOM,
             ITEM_QTY,
             ITEM_IS_SET,
             --RECEIVED_QTY,
             --REVERSAL_QTY,
             --REVERSAL_AMOUNT,
             --RETURN_QTY,
             --RETURN_RECEIVED_QTY,
             --RETURN_FLAG,
             DISCOUNT_RATE,
             MONTH_DISCOUNT_RATE,
             PROJECT_TYPE_CODE,
             PROJECT_ID,
             PROJECT_NUM,
             PROJECT_PRICE,
             ITEM_SETTLE_PRICE,
             ITEM_SETTLE_AMOUNT,
             DISCOUNT_AMOUNT,
             ITEM_LIST_AMOUNT,
             MONTH_DISCOUNT_AMOUNT,
             PROJECT_AMOUNT,
             SETTLE_TYPE_CODE,
             SETTLE_TYPE_NAME,
             ITEM_VOLUME,
             ITEM_WEIGHT,
             SHIP_DOC_LINE_ID,
             ORIGIN_SHIP_PLAN_ID,
             REMARK,
             CREATED_BY,
             CREATION_DATE,
             LAST_UPDATED_BY,
             LAST_UPDATE_DATE)
          VALUES
            (V_SO_LINE_ID, --销售单据行ID
             1, --V_SO_LINE_NUM, --销售单据行号
             V_SO_HEADER_ID, --销售单据头ID
             V_ENTITY_ID, --主体ID
             V_SO_ORIG_ID, --来源头ID
             V_SO_ORIG_LINE_ID, --来源行ID
             R_ITEM_INFO.ITEM_ID, --产品ID
             R_ITEM_INFO.ITEM_CODE, --产品编码
             R_ITEM_INFO.ITEM_NAME, --产品名称
             NULL, --产品价格列表
             ABS(R_SO_DISCOUNT_RED.DISCOUNT_AMOUNT), --产品价格
             R_ITEM_INFO.DEFAULTUNIT, --R_ITEM_INFO.ITEM_UOM, --产品单位
             1, --产品数量
             'N', --产品是否为套件：Y-是，N-否
             --P_SO_LINE.RECEIVED_QTY, --签收数量
             --P_SO_LINE.REVERSAL_QTY, --已红冲数量，在对销售单据进行红冲后，回写红冲数量到原销售单据
             --P_SO_LINE.REVERSAL_AMOUNT, --已红冲金额，在对折让单据进行红冲后，回写红冲金额到原折让单的本字段
             --P_SO_LINE.RETURN_QTY, --退货单生成时回写退货数量到原销售单据
             --P_SO_LINE.RETURN_RECEIVED_QTY, --退货签收数量
             --P_SO_LINE.RETURN_FLAG, --是否已全退标识
             100, --折扣率
             0, --月返
             NULL, --批文类型编码：LIMIT-限量批文，PG-工程机批文
             NULL, --批文ID
             NULL, --批文编号
             NULL, --批文价格
             ABS(R_SO_DISCOUNT_RED.DISCOUNT_AMOUNT), --产品结算价格        
             ABS(R_SO_DISCOUNT_RED.DISCOUNT_AMOUNT), --结算金额=产品数量*产品结算价格        
             ABS(R_SO_DISCOUNT_RED.DISCOUNT_AMOUNT), --扣率折让金额=产品数量*产品价格*(扣率折让/100)
             ABS(R_SO_DISCOUNT_RED.DISCOUNT_AMOUNT), --列表金额
             0, --月返金额=产品数量*产品价格*(月返/100)
             NULL, --批文金额=产品数量*批文价格             
             R_SO_BILL_TYPE_EXTEND_RED.SETTLE_TYPE_CODE, --结算类型编码
             R_SO_BILL_TYPE_EXTEND_RED.SETTLE_TYPE_NAME, --结算类型名
             NULL, --R_ITEM_INFO.ITEM_VOLUME,
             NULL, --R_ITEM_INFO.ITEM_WEIGHT,
             NULL, --发货通知单行ID
             NULL, --来源计划ID：订单计划ID
             '数据切换生成的扣率折让红冲单行#' || TRUNC(SYSDATE),
             'SYS',
             SYSDATE,
             'SYS',
             SYSDATE);
        
          --明细行
          INSERT INTO T_SO_LINE_DETAIL
            (SO_LINE_DETAIL_ID,
             SO_LINE_DETAIL_NUM,
             SO_LINE_ID,
             SO_HEADER_ID,
             ENTITY_ID,
             ITEM_ID,
             ITEM_CODE,
             ITEM_NAME,
             ITEM_QTY,
             ITEM_UOM,
             ITEM_PRICE,
             ITEM_SETTLE_PRICE,
             COMPONENT_ID,
             COMPONENT_CODE,
             COMPONENT_NAME,
             COMPONENT_QTY,
             COMPONENT_PRICE,
             COMPONENT_SETTLE_PRICE,
             COMPONENT_UOM,
             REMARK,
             CREATED_BY,
             CREATION_DATE,
             LAST_UPDATED_BY,
             LAST_UPDATE_DATE)
          VALUES
            (S_SO_LINE_DETAIL.NEXTVAL, --明细行ID
             1, --明细行号
             V_SO_LINE_ID, --行ID
             V_SO_HEADER_ID, --头ID
             V_ENTITY_ID, --主体ID
             R_ITEM_INFO.ITEM_ID, --产品ID
             R_ITEM_INFO.ITEM_CODE, --产品编码
             R_ITEM_INFO.ITEM_NAME, --产品名称
             1, --产品数量
             R_ITEM_INFO.DEFAULTUNIT, --产品单位
             ABS(R_SO_DISCOUNT_RED.DISCOUNT_AMOUNT), --产品价格            
             ABS(R_SO_DISCOUNT_RED.DISCOUNT_AMOUNT), --产品结算价格
             R_ITEM_INFO.ITEM_ID, --散件ID
             R_ITEM_INFO.ITEM_CODE, --散件编码
             R_ITEM_INFO.ITEM_NAME, --散件名称
             1, --散件数量，取套件的数量。
             ABS(R_SO_DISCOUNT_RED.DISCOUNT_AMOUNT), --散件价格,
             ABS(R_SO_DISCOUNT_RED.DISCOUNT_AMOUNT), --散件结算价格
             R_ITEM_INFO.DEFAULTUNIT, --散件单位
             NULL, --备注
             'SYS',
             SYSDATE,
             'SYS',
             SYSDATE);
        
          --审核扣率折让单
          UPDATE T_SO_HEADER
             SET AUDIT_BY         = 'SYS', --审核人
                 AUDIT_FLAG       = 'Y', --审核标识，Y-已审核，N-未审核
                 AUDIT_DATE       = SYSDATE, --审核日期
                 SO_STATUS        = '11', --单据状态：10制单，11-已审核，12-已结算
                 LAST_UPDATED_BY  = 'SYS',
                 LAST_UPDATE_DATE = SYSDATE
           WHERE SO_HEADER_ID = V_SO_HEADER_ID;
        
          --做信用控制（苏冬渊说数据切换，不需要）
          --更新折让余额临时表状态
          UPDATE T_SO_TMP_DISCOUNT
             SET ERR_MSG  = '生成扣率折让红冲单成功，单据号：' || V_SO_NUM || '！',
                 GEN_FLAG = 'Y'
           WHERE ID = R_SO_DISCOUNT_RED.ID;
        END IF;
        -----------
      END LOOP;
    
    END;
  
    COMMIT;
  
  EXCEPTION
    WHEN OTHERS THEN
      P_RESULT  := -29001;
      P_ERR_MSG := '临时生成扣率折让单发生异常：' || SQLERRM;
      --UPDATE T_SO_TMP_DISCOUNT SET ERR_MSG = P_ERR_MSG, GEN_FLAG='N' WHERE ID = R_SO_DISCOUNT.ID;
    --COMMIT;
  END;

  --更新销售基础数据的序列号（数据割接用）空调
  PROCEDURE P_SO_UPDATE_SEQUENCE_KT(P_RESULT  OUT NUMBER, --返回错误ID
                                    P_ERR_MSG OUT VARCHAR2 --返回错误信息
                                    ) IS
    V_MAX_SRC_ID NUMBER := 0;
    V_MAX_REL_ID NUMBER := 0;
  
    V_TMP_ID NUMBER;
  
  BEGIN
    --初始返回值
    P_RESULT  := 0;
    P_ERR_MSG := 'SUCCESS';
  
    BEGIN
      SELECT MAX(SRC_TYPE_ID) INTO V_MAX_SRC_ID FROM T_SO_SRC_TYPE;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        V_MAX_SRC_ID := 0;
      WHEN OTHERS THEN
        V_MAX_SRC_ID := 0;
    END;
  
    IF V_MAX_SRC_ID > 0 THEN
      FOR I IN 1 .. V_MAX_SRC_ID LOOP
        SELECT S_SO_SRC_TYPE.NEXTVAL INTO V_TMP_ID FROM DUAL;
      END LOOP;
    END IF;
  
    -------
    BEGIN
      SELECT MAX(BILL_RELATION_ID)
        INTO V_MAX_REL_ID
        FROM T_SO_BILL_TYPE_RELATION;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        V_MAX_REL_ID := 0;
      WHEN OTHERS THEN
        V_MAX_REL_ID := 0;
    END;
  
    IF V_MAX_REL_ID > 0 THEN
      FOR I IN 1 .. V_MAX_REL_ID LOOP
        SELECT S_SO_BILL_TYPE_RELATION.NEXTVAL INTO V_TMP_ID FROM DUAL;
      END LOOP;
    END IF;
  
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      P_RESULT  := -29003;
      P_ERR_MSG := '更新销售基础数据的序列号发生异常：' || SQLERRM;
      COMMIT;
  END;

  --临时生成扣率折让单（数据割接用）给厨电
  PROCEDURE P_SO_DISCOUNT_GEN_TMP_CD(P_RESULT  OUT NUMBER, --返回错误ID
                                     P_ERR_MSG OUT VARCHAR2 --返回错误信息
                                     ) AS
    --折让余额（正的）
    CURSOR C_SO_DISCOUNT IS
      SELECT *
        FROM T_SO_TMP_DISCOUNT
       WHERE (GEN_FLAG IS NULL OR GEN_FLAG = 'N')
         AND DISCOUNT_AMOUNT > 0;
    R_SO_DISCOUNT C_SO_DISCOUNT%ROWTYPE;
  
    /*
    --账户、客户、销售中心信息游标     
    CURSOR C_CUST_ACCOUNT IS
      SELECT * FROM V_CUST_ACCOUNT
      WHERE ACCOUNT_ID = P_ACCOUNT_ID 
        AND ENTITY_ID  = P_ENTITY_ID;
    */
    V_CUSTOMER_ID       T_CUSTOMER_HEADER.CUSTOMER_ID%TYPE;
    V_CUSTOMER_NAME     T_CUSTOMER_HEADER.CUSTOMER_NAME%TYPE;
    V_CUSTOMER_CODE     T_CUSTOMER_HEADER.CUSTOMER_CODE%TYPE;
    V_ACCOUNT_ID        T_CUSTOMER_ACCOUNT.ACCOUNT_ID%TYPE;
    V_ACCOUNT_CODE      T_CUSTOMER_ACCOUNT.ACCOUNT_CODE%TYPE;
    V_ACCOUNT_NAME      T_CUSTOMER_ACCOUNT.ACCOUNT_NAME%TYPE;
    V_SALES_CENTER_ID   V_CUST_ACCOUNT.SALES_CENTER_ID%TYPE;
    V_SALES_CENTER_CODE V_CUST_ACCOUNT.SALES_CENTER_CODE%TYPE;
    V_SALES_CENTER_NAME V_CUST_ACCOUNT.SALES_CENTER_NAME%TYPE;
  
    --营销大类编码需要根据每个环境的实际编码来修改
    V_SALES_MAIN_TYPE      T_SO_HEADER.SALES_MAIN_TYPE%TYPE := 'KT';
    V_SALES_MAIN_TYPE_NAME T_SO_HEADER.SALES_MAIN_TYPE_NAME%TYPE := '空调';
  
    V_ENTITY_ID     T_SO_HEADER.ENTITY_ID%TYPE := '14';
    V_PAYMENT_SRC   T_SO_HEADER.PAYMENT_SRC%TYPE := '3'; --'上年度结转资源';
    V_DISCOUNT_ITEM T_SO_HEADER.DISCOUNT_ITEM%TYPE := '5'; --其他录入
    V_DISCOUNT_MODE T_SO_HEADER.DISCOUNT_MODE%TYPE := '1';
    V_SALES_YEAR_ID NUMBER := 2015;
  
    V_SO_NUM       T_SO_HEADER.SO_NUM%TYPE;
    V_SO_HEADER_ID NUMBER;
    V_SO_LINE_ID   NUMBER;
  
    --错误信息
    V_ERR_MSG VARCHAR2(4000) := '';
  
    --虚拟产品
    CURSOR C_ITEM_INFO IS
      SELECT *
        FROM T_BD_ITEM
       WHERE IS_VIRTUAL = 'Y'
            --AND SALES_MAIN_TYPE = V_SALES_MAIN_TYPE
         AND ROWNUM = 1;
    R_ITEM_INFO C_ITEM_INFO%ROWTYPE;
  
    --业务单据类型扩展属性，这行扩展属性可用于控制一些业务逻辑。
    V_BILL_TYPE_ID NUMBER;
    CURSOR C_SO_BILL_TYPE_EXTEND IS
      SELECT *
        FROM V_SO_BILL_TYPE_EXTEND
       WHERE SRC_TYPE_CODE = '1009' --扣率折让单
         AND ENTITY_ID = V_ENTITY_ID
         AND (TRUNC(SYSDATE) BETWEEN BEGIN_DATE AND NVL(END_DATE, SYSDATE))
         AND ROWNUM = 1;
    R_SO_BILL_TYPE_EXTEND C_SO_BILL_TYPE_EXTEND%ROWTYPE;
  
    ----------余额小于0的，生成扣率折让红冲单（如果找不到原单，则不填写原单号字段）-------------
    --折让余额（负的）
    CURSOR C_SO_DISCOUNT_RED IS
      SELECT *
        FROM T_SO_TMP_DISCOUNT
       WHERE (GEN_FLAG IS NULL OR GEN_FLAG = 'N')
         AND DISCOUNT_AMOUNT < 0;
    R_SO_DISCOUNT_RED C_SO_DISCOUNT%ROWTYPE;
  
    --扣率折让红冲
    CURSOR C_SO_BILL_TYPE_EXTEND_RED IS
      SELECT *
        FROM V_SO_BILL_TYPE_EXTEND
       WHERE SRC_TYPE_CODE = '1010' --扣率折让红冲单
         AND ENTITY_ID = V_ENTITY_ID
         AND (TRUNC(SYSDATE) BETWEEN BEGIN_DATE AND NVL(END_DATE, SYSDATE))
         AND ROWNUM = 1;
    R_SO_BILL_TYPE_EXTEND_RED C_SO_BILL_TYPE_EXTEND_RED%ROWTYPE;
  
  BEGIN
    --初始返回值
    P_RESULT  := 0;
    P_ERR_MSG := 'SUCCESS';
  
    --获取虚拟产品        
    OPEN C_ITEM_INFO;
    FETCH C_ITEM_INFO
      INTO R_ITEM_INFO;
    CLOSE C_ITEM_INFO;
  
    --得到单据扩展类型属性
    OPEN C_SO_BILL_TYPE_EXTEND;
    FETCH C_SO_BILL_TYPE_EXTEND
      INTO R_SO_BILL_TYPE_EXTEND;
    CLOSE C_SO_BILL_TYPE_EXTEND;
  
    FOR R_SO_DISCOUNT IN C_SO_DISCOUNT LOOP
      V_ERR_MSG           := '';
      V_SO_NUM            := '';
      V_CUSTOMER_CODE     := R_SO_DISCOUNT.CUSTOMER_CODE;
      V_SALES_CENTER_CODE := R_SO_DISCOUNT.SALES_CENTER_CODE;
    
      BEGIN
        IF (V_SALES_CENTER_CODE IS NULL) THEN
          SELECT DISTINCT CA.CUSTOMER_ID,
                          CA.CUSTOMER_CODE,
                          CA.CUSTOMER_NAME,
                          CA.ACCOUNT_ID,
                          CA.ACCOUNT_CODE,
                          CA.ACCOUNT_NAME,
                          CA.SALES_CENTER_ID,
                          CA.SALES_CENTER_CODE,
                          CA.SALES_CENTER_NAME
            INTO V_CUSTOMER_ID,
                 V_CUSTOMER_CODE,
                 V_CUSTOMER_NAME,
                 V_ACCOUNT_ID,
                 V_ACCOUNT_CODE,
                 V_ACCOUNT_NAME,
                 V_SALES_CENTER_ID,
                 V_SALES_CENTER_CODE,
                 V_SALES_CENTER_NAME
            FROM (SELECT T.*, ROWNUM
                    FROM V_CUST_ACCOUNT T
                   ORDER BY ACCOUNT_ID, SALES_CENTER_ID) CA
           WHERE CA.CUSTOMER_CODE = V_CUSTOMER_CODE
             AND CA.ENTITY_ID = V_ENTITY_ID
                --AND CA.SALES_MAIN_TYPE_CODE = V_SALES_MAIN_TYPE
             AND ROWNUM = 1;
        ELSE
          SELECT DISTINCT CA.CUSTOMER_ID,
                          CA.CUSTOMER_CODE,
                          CA.CUSTOMER_NAME,
                          CA.ACCOUNT_ID,
                          CA.ACCOUNT_CODE,
                          CA.ACCOUNT_NAME,
                          CA.SALES_CENTER_ID,
                          CA.SALES_CENTER_CODE,
                          CA.SALES_CENTER_NAME
            INTO V_CUSTOMER_ID,
                 V_CUSTOMER_CODE,
                 V_CUSTOMER_NAME,
                 V_ACCOUNT_ID,
                 V_ACCOUNT_CODE,
                 V_ACCOUNT_NAME,
                 V_SALES_CENTER_ID,
                 V_SALES_CENTER_CODE,
                 V_SALES_CENTER_NAME
            FROM (SELECT T.*, ROWNUM
                    FROM V_CUST_ACCOUNT T
                   ORDER BY ACCOUNT_ID, SALES_CENTER_ID) CA
           WHERE CA.CUSTOMER_CODE = V_CUSTOMER_CODE
             AND CA.SALES_CENTER_CODE = V_SALES_CENTER_CODE
             AND CA.ENTITY_ID = V_ENTITY_ID
                --AND CA.SALES_MAIN_TYPE_CODE = V_SALES_MAIN_TYPE
             AND ROWNUM = 1;
        END IF;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          --没数据
          V_ERR_MSG := '客户[' || R_SO_DISCOUNT.CUSTOMER_CODE || ',' ||
                       R_SO_DISCOUNT.CUSTOMER_NAME ||
                       ']在V_CUST_ACCOUNT视图里不存在，' || '或不属于营销中心[' ||
                       R_SO_DISCOUNT.SALES_CENTER_CODE || ',' ||
                       R_SO_DISCOUNT.SALES_CENTER_NAME || ']';
        WHEN OTHERS THEN
          --抛出异常
          V_ERR_MSG := '获取客户、账户、营销中心信息发生异常：' || SQLERRM;
      END;
    
      IF (V_ACCOUNT_ID IS NULL) OR (V_SALES_CENTER_ID IS NULL) THEN
        --账户或营销中心没找到
        V_ERR_MSG := V_ERR_MSG || '客户[' || R_SO_DISCOUNT.CUSTOMER_CODE || ',' ||
                     R_SO_DISCOUNT.CUSTOMER_NAME || ']对应的账户或营销中心不存在。';
      END IF;
    
      --销售单据号
      BEGIN
        --单据号前缀（用于单据号生成，取事业部2位编码）：用主体ID
        V_SO_NUM := PKG_BD.F_GET_BILL_NO('SO_NUM',
                                         V_ENTITY_ID,
                                         V_ENTITY_ID,
                                         NULL);
      EXCEPTION
        WHEN OTHERS THEN
          V_ERR_MSG := V_ERR_MSG || 'PKG_BD.F_GET_BILL_NO函数生成销售单据号出错：' ||
                       SQLERRM;
      END;
    
      IF LENGTH(V_ERR_MSG) > 0 THEN
        UPDATE T_SO_TMP_DISCOUNT
           SET ERR_MSG = V_ERR_MSG, GEN_FLAG = 'N'
         WHERE ID = R_SO_DISCOUNT.ID;
      ELSE
        SELECT S_SO_HEADER.NEXTVAL INTO V_SO_HEADER_ID FROM DUAL;
        SELECT S_SO_LINE.NEXTVAL INTO V_SO_LINE_ID FROM DUAL;
      
        INSERT INTO T_SO_HEADER
          (SO_HEADER_ID,
           ENTITY_ID,
           SALES_YEAR_ID,
           BILL_TYPE_ID,
           BILL_TYPE_CODE,
           BILL_TYPE_NAME,
           BIZ_SRC_BILL_TYPE_ID,
           BIZ_SRC_BILL_TYPE_CODE,
           BIZ_SRC_BILL_TYPE_NAME,
           SO_NUM,
           SO_STATUS,
           SO_DATE,
           SALES_MAIN_TYPE,
           SALES_MAIN_TYPE_NAME,
           CUSTOMER_ID,
           CUSTOMER_CODE,
           CUSTOMER_NAME,
           ACCOUNT_ID,
           ACCOUNT_CODE,
           ACCOUNT_NAME,
           SALES_CENTER_ID,
           SALES_CENTER_CODE,
           SALES_CENTER_NAME,
           LIST_AMOUNT,
           SETTLE_AMOUNT,
           DISCOUNT_AMOUNT,
           REBATE_YEAR,
           PAYMENT_SRC,
           DISCOUNT_ITEM,
           DISCOUNT_MODE,
           CREATED_MODE,
           CREATED_BY,
           CREATION_DATE,
           LAST_UPDATED_BY,
           LAST_UPDATE_DATE,
           REMARK)
        VALUES
          (V_SO_HEADER_ID,
           V_ENTITY_ID,
           V_SALES_YEAR_ID,
           R_SO_BILL_TYPE_EXTEND.BILL_TYPE_ID,
           R_SO_BILL_TYPE_EXTEND.BILL_TYPE_CODE,
           R_SO_BILL_TYPE_EXTEND.BILL_TYPE_NAME,
           R_SO_BILL_TYPE_EXTEND.SRC_TYPE_ID,
           R_SO_BILL_TYPE_EXTEND.SRC_TYPE_CODE,
           R_SO_BILL_TYPE_EXTEND.SRC_TYPE_NAME,
           V_SO_NUM,
           '10',
           TRUNC(SYSDATE),
           V_SALES_MAIN_TYPE,
           V_SALES_MAIN_TYPE_NAME,
           V_CUSTOMER_ID,
           V_CUSTOMER_CODE,
           V_CUSTOMER_NAME,
           V_ACCOUNT_ID,
           V_ACCOUNT_CODE,
           V_ACCOUNT_NAME,
           V_SALES_CENTER_ID,
           V_SALES_CENTER_CODE,
           V_SALES_CENTER_NAME,
           R_SO_DISCOUNT.DISCOUNT_AMOUNT, --LIST_AMOUNT,
           R_SO_DISCOUNT.DISCOUNT_AMOUNT, --SETTLE_AMOUNT,
           R_SO_DISCOUNT.DISCOUNT_AMOUNT, --DISCOUNT_AMOUNT,
           '2014',
           V_PAYMENT_SRC,
           V_DISCOUNT_ITEM,
           V_DISCOUNT_MODE,
           '20', --制单方式：10-自动，20-人工。
           'SYS',
           SYSDATE,
           'SYS',
           SYSDATE,
           '本单据为数据切换生成的扣率折让单#' || TRUNC(SYSDATE));
      
        --生成销售单据行
        INSERT INTO T_SO_LINE
          (SO_LINE_ID,
           SO_LINE_NUM,
           SO_HEADER_ID,
           ENTITY_ID,
           SRC_HEADER_ID,
           SRC_LINE_ID,
           ITEM_ID,
           ITEM_CODE,
           ITEM_NAME,
           ITEM_PRICE_LIST_ID,
           ITEM_PRICE,
           ITEM_UOM,
           ITEM_QTY,
           ITEM_IS_SET,
           --RECEIVED_QTY,
           --REVERSAL_QTY,
           --REVERSAL_AMOUNT,
           --RETURN_QTY,
           --RETURN_RECEIVED_QTY,
           --RETURN_FLAG,
           DISCOUNT_RATE,
           MONTH_DISCOUNT_RATE,
           PROJECT_TYPE_CODE,
           PROJECT_ID,
           PROJECT_NUM,
           PROJECT_PRICE,
           ITEM_SETTLE_PRICE,
           ITEM_SETTLE_AMOUNT,
           DISCOUNT_AMOUNT,
           ITEM_LIST_AMOUNT,
           MONTH_DISCOUNT_AMOUNT,
           PROJECT_AMOUNT,
           SETTLE_TYPE_CODE,
           SETTLE_TYPE_NAME,
           ITEM_VOLUME,
           ITEM_WEIGHT,
           SHIP_DOC_LINE_ID,
           ORIGIN_SHIP_PLAN_ID,
           REMARK,
           CREATED_BY,
           CREATION_DATE,
           LAST_UPDATED_BY,
           LAST_UPDATE_DATE)
        VALUES
          (V_SO_LINE_ID, --销售单据行ID
           1, --V_SO_LINE_NUM, --销售单据行号
           V_SO_HEADER_ID, --销售单据头ID
           V_ENTITY_ID, --主体ID
           NULL, --来源头ID
           NULL, --来源行ID
           R_ITEM_INFO.ITEM_ID, --产品ID
           R_ITEM_INFO.ITEM_CODE, --产品编码
           R_ITEM_INFO.ITEM_NAME, --产品名称
           NULL, --产品价格列表
           R_SO_DISCOUNT.DISCOUNT_AMOUNT, --产品价格
           R_ITEM_INFO.DEFAULTUNIT, --R_ITEM_INFO.ITEM_UOM, --产品单位
           1, --产品数量
           'N', --产品是否为套件：Y-是，N-否
           --P_SO_LINE.RECEIVED_QTY, --签收数量
           --P_SO_LINE.REVERSAL_QTY, --已红冲数量，在对销售单据进行红冲后，回写红冲数量到原销售单据
           --P_SO_LINE.REVERSAL_AMOUNT, --已红冲金额，在对折让单据进行红冲后，回写红冲金额到原折让单的本字段
           --P_SO_LINE.RETURN_QTY, --退货单生成时回写退货数量到原销售单据
           --P_SO_LINE.RETURN_RECEIVED_QTY, --退货签收数量
           --P_SO_LINE.RETURN_FLAG, --是否已全退标识
           100, --折扣率
           0, --月返
           NULL, --批文类型编码：LIMIT-限量批文，PG-工程机批文
           NULL, --批文ID
           NULL, --批文编号
           NULL, --批文价格
           R_SO_DISCOUNT.DISCOUNT_AMOUNT, --产品结算价格        
           R_SO_DISCOUNT.DISCOUNT_AMOUNT, --结算金额=产品数量*产品结算价格        
           R_SO_DISCOUNT.DISCOUNT_AMOUNT, --扣率折让金额=产品数量*产品价格*(扣率折让/100)
           R_SO_DISCOUNT.DISCOUNT_AMOUNT, --列表金额
           0, --月返金额=产品数量*产品价格*(月返/100)
           NULL, --批文金额=产品数量*批文价格             
           R_SO_BILL_TYPE_EXTEND.SETTLE_TYPE_CODE, --结算类型编码
           R_SO_BILL_TYPE_EXTEND.SETTLE_TYPE_NAME, --结算类型名
           NULL, --R_ITEM_INFO.ITEM_VOLUME,
           NULL, --R_ITEM_INFO.ITEM_WEIGHT,
           NULL, --发货通知单行ID
           NULL, --来源计划ID：订单计划ID
           '数据切换生成的扣率折让单行#' || TRUNC(SYSDATE),
           'SYS',
           SYSDATE,
           'SYS',
           SYSDATE);
      
        --明细行
        INSERT INTO T_SO_LINE_DETAIL
          (SO_LINE_DETAIL_ID,
           SO_LINE_DETAIL_NUM,
           SO_LINE_ID,
           SO_HEADER_ID,
           ENTITY_ID,
           ITEM_ID,
           ITEM_CODE,
           ITEM_NAME,
           ITEM_QTY,
           ITEM_UOM,
           ITEM_PRICE,
           ITEM_SETTLE_PRICE,
           COMPONENT_ID,
           COMPONENT_CODE,
           COMPONENT_NAME,
           COMPONENT_QTY,
           COMPONENT_PRICE,
           COMPONENT_SETTLE_PRICE,
           COMPONENT_UOM,
           REMARK,
           CREATED_BY,
           CREATION_DATE,
           LAST_UPDATED_BY,
           LAST_UPDATE_DATE)
        VALUES
          (S_SO_LINE_DETAIL.NEXTVAL, --明细行ID
           1, --明细行号
           V_SO_LINE_ID, --行ID
           V_SO_HEADER_ID, --头ID
           V_ENTITY_ID, --主体ID
           R_ITEM_INFO.ITEM_ID, --产品ID
           R_ITEM_INFO.ITEM_CODE, --产品编码
           R_ITEM_INFO.ITEM_NAME, --产品名称
           1, --产品数量
           R_ITEM_INFO.DEFAULTUNIT, --产品单位
           R_SO_DISCOUNT.DISCOUNT_AMOUNT, --产品价格            
           R_SO_DISCOUNT.DISCOUNT_AMOUNT, --产品结算价格
           R_ITEM_INFO.ITEM_ID, --散件ID
           R_ITEM_INFO.ITEM_CODE, --散件编码
           R_ITEM_INFO.ITEM_NAME, --散件名称
           1, --散件数量，取套件的数量。
           R_SO_DISCOUNT.DISCOUNT_AMOUNT, --散件价格,
           R_SO_DISCOUNT.DISCOUNT_AMOUNT, --散件结算价格
           R_ITEM_INFO.DEFAULTUNIT, --散件单位
           NULL, --备注
           'SYS',
           SYSDATE,
           'SYS',
           SYSDATE);
      
        --审核扣率折让单
        UPDATE T_SO_HEADER
           SET AUDIT_BY         = 'SYS', --审核人
               AUDIT_FLAG       = 'Y', --审核标识，Y-已审核，N-未审核
               AUDIT_DATE       = SYSDATE, --审核日期
               SO_STATUS        = '11', --单据状态：10制单，11-已审核，12-已结算
               LAST_UPDATED_BY  = 'SYS',
               LAST_UPDATE_DATE = SYSDATE
         WHERE SO_HEADER_ID = V_SO_HEADER_ID;
      
        --做信用控制（苏冬渊说数据切换，不需要）
        --更新折让余额临时表状态
        UPDATE T_SO_TMP_DISCOUNT
           SET ERR_MSG  = '生成扣率折让单成功，单据号：' || V_SO_NUM || '！',
               GEN_FLAG = 'Y'
         WHERE ID = R_SO_DISCOUNT.ID;
      END IF;
    
    END LOOP;
  
    ----------生成扣率折让红冲单-------------
    OPEN C_SO_BILL_TYPE_EXTEND_RED;
    FETCH C_SO_BILL_TYPE_EXTEND_RED
      INTO R_SO_BILL_TYPE_EXTEND_RED;
    CLOSE C_SO_BILL_TYPE_EXTEND_RED;
  
    DECLARE
      V_SO_ORIG_ID      NUMBER;
      V_SO_ORIG_NUM     VARCHAR2(32);
      V_SO_ORIG_LINE_ID NUMBER;
    
      --找原单，如果找不到就没有原单
      CURSOR C_SO_ORIG IS
        SELECT *
          FROM T_SO_HEADER T
         WHERE T.BIZ_SRC_BILL_TYPE_CODE = '1009'
           AND T.CUSTOMER_CODE = V_CUSTOMER_CODE
           AND T.SALES_CENTER_CODE = V_SALES_CENTER_CODE
           AND ROWNUM = 1;
      R_SO_ORIG C_SO_ORIG%ROWTYPE;
    
    BEGIN
    
      FOR R_SO_DISCOUNT_RED IN C_SO_DISCOUNT_RED LOOP
        V_ERR_MSG           := '';
        V_SO_NUM            := '';
        V_CUSTOMER_CODE     := R_SO_DISCOUNT_RED.CUSTOMER_CODE;
        V_SALES_CENTER_CODE := R_SO_DISCOUNT_RED.SALES_CENTER_CODE;
      
        BEGIN
          IF (V_SALES_CENTER_CODE IS NULL) THEN
            SELECT DISTINCT CA.CUSTOMER_ID,
                            CA.CUSTOMER_CODE,
                            CA.CUSTOMER_NAME,
                            CA.ACCOUNT_ID,
                            CA.ACCOUNT_CODE,
                            CA.ACCOUNT_NAME,
                            CA.SALES_CENTER_ID,
                            CA.SALES_CENTER_CODE,
                            CA.SALES_CENTER_NAME
              INTO V_CUSTOMER_ID,
                   V_CUSTOMER_CODE,
                   V_CUSTOMER_NAME,
                   V_ACCOUNT_ID,
                   V_ACCOUNT_CODE,
                   V_ACCOUNT_NAME,
                   V_SALES_CENTER_ID,
                   V_SALES_CENTER_CODE,
                   V_SALES_CENTER_NAME
              FROM (SELECT T.*, ROWNUM
                      FROM V_CUST_ACCOUNT T
                     ORDER BY ACCOUNT_ID, SALES_CENTER_ID) CA
             WHERE CA.CUSTOMER_CODE = V_CUSTOMER_CODE
               AND CA.ENTITY_ID = V_ENTITY_ID
                  --AND CA.SALES_MAIN_TYPE_CODE = V_SALES_MAIN_TYPE
               AND ROWNUM = 1;
          ELSE
            SELECT DISTINCT CA.CUSTOMER_ID,
                            CA.CUSTOMER_CODE,
                            CA.CUSTOMER_NAME,
                            CA.ACCOUNT_ID,
                            CA.ACCOUNT_CODE,
                            CA.ACCOUNT_NAME,
                            CA.SALES_CENTER_ID,
                            CA.SALES_CENTER_CODE,
                            CA.SALES_CENTER_NAME
              INTO V_CUSTOMER_ID,
                   V_CUSTOMER_CODE,
                   V_CUSTOMER_NAME,
                   V_ACCOUNT_ID,
                   V_ACCOUNT_CODE,
                   V_ACCOUNT_NAME,
                   V_SALES_CENTER_ID,
                   V_SALES_CENTER_CODE,
                   V_SALES_CENTER_NAME
              FROM (SELECT T.*, ROWNUM
                      FROM V_CUST_ACCOUNT T
                     ORDER BY ACCOUNT_ID, SALES_CENTER_ID) CA
             WHERE CA.CUSTOMER_CODE = V_CUSTOMER_CODE
               AND CA.SALES_CENTER_CODE = V_SALES_CENTER_CODE
               AND CA.ENTITY_ID = V_ENTITY_ID
                  --AND CA.SALES_MAIN_TYPE_CODE = V_SALES_MAIN_TYPE
               AND ROWNUM = 1;
          END IF;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            --没数据
            V_ERR_MSG := '客户[' || R_SO_DISCOUNT_RED.CUSTOMER_CODE || ',' ||
                         R_SO_DISCOUNT_RED.CUSTOMER_NAME ||
                         ']在V_CUST_ACCOUNT视图里不存在，' || '或不属于营销中心[' ||
                         R_SO_DISCOUNT_RED.SALES_CENTER_CODE || ',' ||
                         R_SO_DISCOUNT_RED.SALES_CENTER_NAME || ']';
          WHEN OTHERS THEN
            --抛出异常
            V_ERR_MSG := '获取客户、账户、营销中心信息发生异常：' || SQLERRM;
        END;
      
        -----------
        IF (V_ACCOUNT_ID IS NULL) OR (V_SALES_CENTER_ID IS NULL) THEN
          --账户或营销中心没找到
          V_ERR_MSG := V_ERR_MSG || '客户[' ||
                       R_SO_DISCOUNT_RED.CUSTOMER_CODE || ',' ||
                       R_SO_DISCOUNT_RED.CUSTOMER_NAME || ']对应的账户或营销中心不存在。';
        END IF;
      
        --销售单据号
        BEGIN
          --单据号前缀（用于单据号生成，取事业部2位编码）：用主体ID
          V_SO_NUM := PKG_BD.F_GET_BILL_NO('SO_NUM',
                                           V_ENTITY_ID,
                                           V_ENTITY_ID,
                                           NULL);
        EXCEPTION
          WHEN OTHERS THEN
            V_ERR_MSG := V_ERR_MSG || 'PKG_BD.F_GET_BILL_NO函数生成销售单据号出错：' ||
                         SQLERRM;
        END;
      
        IF LENGTH(V_ERR_MSG) > 0 THEN
          UPDATE T_SO_TMP_DISCOUNT
             SET ERR_MSG = V_ERR_MSG, GEN_FLAG = 'N'
           WHERE ID = R_SO_DISCOUNT_RED.ID;
        ELSE
          --取原单
          OPEN C_SO_ORIG;
          FETCH C_SO_ORIG
            INTO R_SO_ORIG;
          CLOSE C_SO_ORIG;
        
          IF (R_SO_ORIG.SO_HEADER_ID IS NOT NULL) THEN
            V_SO_ORIG_ID  := R_SO_ORIG.SO_HEADER_ID;
            V_SO_ORIG_NUM := R_SO_ORIG.SO_NUM;
          
            SELECT SO_LINE_ID
              INTO V_SO_ORIG_LINE_ID
              FROM T_SO_LINE
             WHERE SO_HEADER_ID = V_SO_ORIG_ID
               AND ROWNUM = 1;
          END IF;
        
          SELECT S_SO_HEADER.NEXTVAL INTO V_SO_HEADER_ID FROM DUAL;
          SELECT S_SO_LINE.NEXTVAL INTO V_SO_LINE_ID FROM DUAL;
        
          INSERT INTO T_SO_HEADER
            (SO_HEADER_ID,
             ENTITY_ID,
             SALES_YEAR_ID,
             BILL_TYPE_ID,
             BILL_TYPE_CODE,
             BILL_TYPE_NAME,
             BIZ_SRC_BILL_TYPE_ID,
             BIZ_SRC_BILL_TYPE_CODE,
             BIZ_SRC_BILL_TYPE_NAME,
             SO_NUM,
             SO_STATUS,
             SO_DATE,
             ORIG_SO_NUM,
             SALES_MAIN_TYPE,
             SALES_MAIN_TYPE_NAME,
             CUSTOMER_ID,
             CUSTOMER_CODE,
             CUSTOMER_NAME,
             ACCOUNT_ID,
             ACCOUNT_CODE,
             ACCOUNT_NAME,
             SALES_CENTER_ID,
             SALES_CENTER_CODE,
             SALES_CENTER_NAME,
             LIST_AMOUNT,
             SETTLE_AMOUNT,
             DISCOUNT_AMOUNT,
             REBATE_YEAR,
             PAYMENT_SRC,
             DISCOUNT_ITEM,
             DISCOUNT_MODE,
             CREATED_MODE,
             CREATED_BY,
             CREATION_DATE,
             LAST_UPDATED_BY,
             LAST_UPDATE_DATE,
             REMARK)
          VALUES
            (V_SO_HEADER_ID,
             V_ENTITY_ID,
             V_SALES_YEAR_ID,
             R_SO_BILL_TYPE_EXTEND_RED.BILL_TYPE_ID,
             R_SO_BILL_TYPE_EXTEND_RED.BILL_TYPE_CODE,
             R_SO_BILL_TYPE_EXTEND_RED.BILL_TYPE_NAME,
             R_SO_BILL_TYPE_EXTEND_RED.SRC_TYPE_ID,
             R_SO_BILL_TYPE_EXTEND_RED.SRC_TYPE_CODE,
             R_SO_BILL_TYPE_EXTEND_RED.SRC_TYPE_NAME,
             V_SO_NUM,
             '10',
             TRUNC(SYSDATE),
             V_SO_ORIG_NUM,
             V_SALES_MAIN_TYPE,
             V_SALES_MAIN_TYPE_NAME,
             V_CUSTOMER_ID,
             V_CUSTOMER_CODE,
             V_CUSTOMER_NAME,
             V_ACCOUNT_ID,
             V_ACCOUNT_CODE,
             V_ACCOUNT_NAME,
             V_SALES_CENTER_ID,
             V_SALES_CENTER_CODE,
             V_SALES_CENTER_NAME,
             ABS(R_SO_DISCOUNT_RED.DISCOUNT_AMOUNT), --LIST_AMOUNT,
             ABS(R_SO_DISCOUNT_RED.DISCOUNT_AMOUNT), --SETTLE_AMOUNT,
             ABS(R_SO_DISCOUNT_RED.DISCOUNT_AMOUNT), --DISCOUNT_AMOUNT,
             '2014',
             V_PAYMENT_SRC,
             V_DISCOUNT_ITEM,
             V_DISCOUNT_MODE,
             '20', --制单方式：10-自动，20-人工。
             'SYS',
             SYSDATE,
             'SYS',
             SYSDATE,
             '本单据为数据切换生成的扣率折让红冲单#' || TRUNC(SYSDATE));
        
          DBMS_OUTPUT.PUT_LINE(V_CUSTOMER_CODE || ',item_price=' ||
                               R_SO_DISCOUNT_RED.DISCOUNT_AMOUNT);
        
          --生成销售单据行
          INSERT INTO T_SO_LINE
            (SO_LINE_ID,
             SO_LINE_NUM,
             SO_HEADER_ID,
             ENTITY_ID,
             SRC_HEADER_ID,
             SRC_LINE_ID,
             ITEM_ID,
             ITEM_CODE,
             ITEM_NAME,
             ITEM_PRICE_LIST_ID,
             ITEM_PRICE,
             ITEM_UOM,
             ITEM_QTY,
             ITEM_IS_SET,
             --RECEIVED_QTY,
             --REVERSAL_QTY,
             --REVERSAL_AMOUNT,
             --RETURN_QTY,
             --RETURN_RECEIVED_QTY,
             --RETURN_FLAG,
             DISCOUNT_RATE,
             MONTH_DISCOUNT_RATE,
             PROJECT_TYPE_CODE,
             PROJECT_ID,
             PROJECT_NUM,
             PROJECT_PRICE,
             ITEM_SETTLE_PRICE,
             ITEM_SETTLE_AMOUNT,
             DISCOUNT_AMOUNT,
             ITEM_LIST_AMOUNT,
             MONTH_DISCOUNT_AMOUNT,
             PROJECT_AMOUNT,
             SETTLE_TYPE_CODE,
             SETTLE_TYPE_NAME,
             ITEM_VOLUME,
             ITEM_WEIGHT,
             SHIP_DOC_LINE_ID,
             ORIGIN_SHIP_PLAN_ID,
             REMARK,
             CREATED_BY,
             CREATION_DATE,
             LAST_UPDATED_BY,
             LAST_UPDATE_DATE)
          VALUES
            (V_SO_LINE_ID, --销售单据行ID
             1, --V_SO_LINE_NUM, --销售单据行号
             V_SO_HEADER_ID, --销售单据头ID
             V_ENTITY_ID, --主体ID
             V_SO_ORIG_ID, --来源头ID
             V_SO_ORIG_LINE_ID, --来源行ID
             R_ITEM_INFO.ITEM_ID, --产品ID
             R_ITEM_INFO.ITEM_CODE, --产品编码
             R_ITEM_INFO.ITEM_NAME, --产品名称
             NULL, --产品价格列表
             ABS(R_SO_DISCOUNT_RED.DISCOUNT_AMOUNT), --产品价格
             R_ITEM_INFO.DEFAULTUNIT, --R_ITEM_INFO.ITEM_UOM, --产品单位
             1, --产品数量
             'N', --产品是否为套件：Y-是，N-否
             --P_SO_LINE.RECEIVED_QTY, --签收数量
             --P_SO_LINE.REVERSAL_QTY, --已红冲数量，在对销售单据进行红冲后，回写红冲数量到原销售单据
             --P_SO_LINE.REVERSAL_AMOUNT, --已红冲金额，在对折让单据进行红冲后，回写红冲金额到原折让单的本字段
             --P_SO_LINE.RETURN_QTY, --退货单生成时回写退货数量到原销售单据
             --P_SO_LINE.RETURN_RECEIVED_QTY, --退货签收数量
             --P_SO_LINE.RETURN_FLAG, --是否已全退标识
             100, --折扣率
             0, --月返
             NULL, --批文类型编码：LIMIT-限量批文，PG-工程机批文
             NULL, --批文ID
             NULL, --批文编号
             NULL, --批文价格
             ABS(R_SO_DISCOUNT_RED.DISCOUNT_AMOUNT), --产品结算价格        
             ABS(R_SO_DISCOUNT_RED.DISCOUNT_AMOUNT), --结算金额=产品数量*产品结算价格        
             ABS(R_SO_DISCOUNT_RED.DISCOUNT_AMOUNT), --扣率折让金额=产品数量*产品价格*(扣率折让/100)
             ABS(R_SO_DISCOUNT_RED.DISCOUNT_AMOUNT), --列表金额
             0, --月返金额=产品数量*产品价格*(月返/100)
             NULL, --批文金额=产品数量*批文价格             
             R_SO_BILL_TYPE_EXTEND_RED.SETTLE_TYPE_CODE, --结算类型编码
             R_SO_BILL_TYPE_EXTEND_RED.SETTLE_TYPE_NAME, --结算类型名
             NULL, --R_ITEM_INFO.ITEM_VOLUME,
             NULL, --R_ITEM_INFO.ITEM_WEIGHT,
             NULL, --发货通知单行ID
             NULL, --来源计划ID：订单计划ID
             '数据切换生成的扣率折让红冲单行#' || TRUNC(SYSDATE),
             'SYS',
             SYSDATE,
             'SYS',
             SYSDATE);
        
          --明细行
          INSERT INTO T_SO_LINE_DETAIL
            (SO_LINE_DETAIL_ID,
             SO_LINE_DETAIL_NUM,
             SO_LINE_ID,
             SO_HEADER_ID,
             ENTITY_ID,
             ITEM_ID,
             ITEM_CODE,
             ITEM_NAME,
             ITEM_QTY,
             ITEM_UOM,
             ITEM_PRICE,
             ITEM_SETTLE_PRICE,
             COMPONENT_ID,
             COMPONENT_CODE,
             COMPONENT_NAME,
             COMPONENT_QTY,
             COMPONENT_PRICE,
             COMPONENT_SETTLE_PRICE,
             COMPONENT_UOM,
             REMARK,
             CREATED_BY,
             CREATION_DATE,
             LAST_UPDATED_BY,
             LAST_UPDATE_DATE)
          VALUES
            (S_SO_LINE_DETAIL.NEXTVAL, --明细行ID
             1, --明细行号
             V_SO_LINE_ID, --行ID
             V_SO_HEADER_ID, --头ID
             V_ENTITY_ID, --主体ID
             R_ITEM_INFO.ITEM_ID, --产品ID
             R_ITEM_INFO.ITEM_CODE, --产品编码
             R_ITEM_INFO.ITEM_NAME, --产品名称
             1, --产品数量
             R_ITEM_INFO.DEFAULTUNIT, --产品单位
             ABS(R_SO_DISCOUNT_RED.DISCOUNT_AMOUNT), --产品价格            
             ABS(R_SO_DISCOUNT_RED.DISCOUNT_AMOUNT), --产品结算价格
             R_ITEM_INFO.ITEM_ID, --散件ID
             R_ITEM_INFO.ITEM_CODE, --散件编码
             R_ITEM_INFO.ITEM_NAME, --散件名称
             1, --散件数量，取套件的数量。
             ABS(R_SO_DISCOUNT_RED.DISCOUNT_AMOUNT), --散件价格,
             ABS(R_SO_DISCOUNT_RED.DISCOUNT_AMOUNT), --散件结算价格
             R_ITEM_INFO.DEFAULTUNIT, --散件单位
             NULL, --备注
             'SYS',
             SYSDATE,
             'SYS',
             SYSDATE);
        
          --审核扣率折让单
          UPDATE T_SO_HEADER
             SET AUDIT_BY         = 'SYS', --审核人
                 AUDIT_FLAG       = 'Y', --审核标识，Y-已审核，N-未审核
                 AUDIT_DATE       = SYSDATE, --审核日期
                 SO_STATUS        = '11', --单据状态：10制单，11-已审核，12-已结算
                 LAST_UPDATED_BY  = 'SYS',
                 LAST_UPDATE_DATE = SYSDATE
           WHERE SO_HEADER_ID = V_SO_HEADER_ID;
        
          --做信用控制（苏冬渊说数据切换，不需要）
          --更新折让余额临时表状态
          UPDATE T_SO_TMP_DISCOUNT
             SET ERR_MSG  = '生成扣率折让红冲单成功，单据号：' || V_SO_NUM || '！',
                 GEN_FLAG = 'Y'
           WHERE ID = R_SO_DISCOUNT_RED.ID;
        END IF;
        -----------
      END LOOP;
    
    END;
  
    COMMIT;
  
  EXCEPTION
    WHEN OTHERS THEN
      P_RESULT  := -29001;
      P_ERR_MSG := '临时生成扣率折让单发生异常：' || SQLERRM;
      --UPDATE T_SO_TMP_DISCOUNT SET ERR_MSG = P_ERR_MSG, GEN_FLAG='N' WHERE ID = R_SO_DISCOUNT.ID;
    --COMMIT;
  END;

  --更新销售基础数据的序列号（数据割接用）给厨电
  PROCEDURE P_SO_UPDATE_SEQUENCE_CD(P_RESULT  OUT NUMBER, --返回错误ID
                                    P_ERR_MSG OUT VARCHAR2 --返回错误信息
                                    ) AS
    V_MAX_SRC_ID NUMBER := 0;
    V_MAX_REL_ID NUMBER := 0;
  
    V_TMP_ID NUMBER;
  
  BEGIN
    --初始返回值
    P_RESULT  := 0;
    P_ERR_MSG := 'SUCCESS';
  
    BEGIN
      SELECT MAX(SRC_TYPE_ID) INTO V_MAX_SRC_ID FROM T_SO_SRC_TYPE;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        V_MAX_SRC_ID := 0;
      WHEN OTHERS THEN
        V_MAX_SRC_ID := 0;
    END;
  
    IF V_MAX_SRC_ID > 0 THEN
      FOR I IN 1 .. V_MAX_SRC_ID LOOP
        SELECT S_SO_SRC_TYPE.NEXTVAL INTO V_TMP_ID FROM DUAL;
      END LOOP;
    END IF;
  
    -------
    BEGIN
      SELECT MAX(BILL_RELATION_ID)
        INTO V_MAX_REL_ID
        FROM T_SO_BILL_TYPE_RELATION;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        V_MAX_REL_ID := 0;
      WHEN OTHERS THEN
        V_MAX_REL_ID := 0;
    END;
  
    IF V_MAX_REL_ID > 0 THEN
      FOR I IN 1 .. V_MAX_REL_ID LOOP
        SELECT S_SO_BILL_TYPE_RELATION.NEXTVAL INTO V_TMP_ID FROM DUAL;
      END LOOP;
    END IF;
  
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      P_RESULT  := -29003;
      P_ERR_MSG := '更新销售基础数据的序列号发生异常：' || SQLERRM;
      COMMIT;
  END;

  PROCEDURE 备注 AS
  BEGIN
    NULL;
    /*
    
    --常用代码更新
    
    --销售单据类型扩展表
    --select s_so_type_extend.nextval from dual
    select * from cims.T_SO_TYPE_EXTEND@dev;
    --select * from cims.T_SO_TYPE_EXTEND@zs;
    
    --业务单据源类型表 s_so_src_type 
    --没变化，不更新
    select * from cims.T_SO_SRC_TYPE@dev;
    --select * from cims.T_SO_SRC_TYPE@zs;
    
    --=业务单据配置表(T_INV_BILL_CONFIG)
    select * from T_INV_BILL_CONFIG
    
    --ERP订单类型配置 s_so_erp_type_relation 
    --select s_so_erp_type_relation.nextval from dual
    select * from cims.T_SO_ERP_TYPE_RELATION@Dev;
    --select * from cims.T_SO_ERP_TYPE_RELATION@zs;
    
    
    --业务单据类型与源类型关系表
    
    select * from cims.T_SO_BILL_TYPE_RELATION@Dev;
    --select * from cims.T_SO_BILL_TYPE_RELATION@zs;
    
    --代码表，快码表
    select * from cims.up_codelist@dev a WHERE a.codetype_name LIKE '%销售%';
    --select * from cims.up_codelist@zs a WHERE a.codetype_name LIKE '%销售%';
    */
  
  END;

  FUNCTION FN_SIGN(PRM_STR VARCHAR2) RETURN VARCHAR2 AS
  BEGIN
    RETURN '''' || PRM_STR || '''';
  END;

  PROCEDURE BD_PARAM AS
    V_SQL        VARCHAR2(4000);
    N_PARENT_SEQ NUMBER;
    N_SUB_SEQ    NUMBER;
    V_USER       VARCHAR2(20);
  BEGIN
    V_USER := 'admin';
  
    DBMS_OUTPUT.PUT_LINE('DECLARE');
    DBMS_OUTPUT.PUT_LINE('');
    DBMS_OUTPUT.PUT_LINE('N_PARENT_SEQ NUMBER;');
    DBMS_OUTPUT.PUT_LINE('N_SUB_SEQ    NUMBER;');
    DBMS_OUTPUT.PUT_LINE('');
    DBMS_OUTPUT.PUT_LINE('BEGIN');
    DBMS_OUTPUT.PUT_LINE('');
    FOR REC IN (SELECT A.PARAM_CODE
                  FROM T_BD_PARAM_LIST A
                 WHERE A.MODULE_CODE = 'sales'
                 GROUP BY A.PARAM_CODE) LOOP
      FOR REC1 IN (SELECT *
                     FROM T_BD_PARAM_LIST A
                    WHERE A.MODULE_CODE = 'sales'
                      AND A.PARAM_CODE = REC.PARAM_CODE) LOOP
        --N_PARENT_SEQ := SEQ_BD_ROW_ID.NEXTVAL;
        DBMS_OUTPUT.PUT_LINE('N_PARENT_SEQ := SEQ_BD_ROW_ID.NEXTVAL;');
        V_SQL := 'INSERT INTO T_BD_PARAM_LIST(PARAM_LIST_ID,MODULE_CODE,PARAM_CODE,PARAM_NAME,PARAM_DESC,DEFAULT_VALUE,ENTITY_FLAG,ACTIVE_FLAG,CREATED_BY,CREATED_DATE,LAST_UPDATED_BY,LAST_UPDATE_DATE)' ||
                 CHR(10) || 'values( N_PARENT_SEQ,' ||
                 PKG_SO_SWITCH.FN_SIGN(REC1.MODULE_CODE) || ',' ||
                 PKG_SO_SWITCH.FN_SIGN(REC1.PARAM_CODE) || ',' ||
                 PKG_SO_SWITCH.FN_SIGN(REC1.PARAM_NAME) || ',' ||
                 PKG_SO_SWITCH.FN_SIGN(REC1.PARAM_DESC) || ',' ||
                 PKG_SO_SWITCH.FN_SIGN(REC1.DEFAULT_VALUE) || ',' ||
                 PKG_SO_SWITCH.FN_SIGN(REC1.ENTITY_FLAG) || ',' ||
                 PKG_SO_SWITCH.FN_SIGN(REC1.ACTIVE_FLAG) || ',' ||
                 PKG_SO_SWITCH.FN_SIGN(V_USER) || ',sysdate,' ||
                 PKG_SO_SWITCH.FN_SIGN(V_USER) || ',sysdate);' || CHR(10);
        DBMS_OUTPUT.PUT_LINE('--' || REC.PARAM_CODE);
        DBMS_OUTPUT.PUT_LINE(V_SQL);
        FOR REC2 IN (SELECT *
                       FROM T_BD_PARAM_ENTITY A
                      WHERE A.PARAM_LIST_ID = REC1.PARAM_LIST_ID) LOOP
          --N_SUB_SEQ := SEQ_BD_ROW_ID.NEXTVAL;
          DBMS_OUTPUT.PUT_LINE('N_SUB_SEQ := SEQ_BD_ROW_ID.NEXTVAL;');
          V_SQL := 'INSERT INTO T_BD_PARAM_ENTITY(PARAM_ENTITY_ID,PARAM_LIST_ID,ENTITY_ID,ENTITY_VALUE,PARAM_DESC,ORG_CUST_FLAG,ACTIVE_FLAG,CREATED_BY,CREATED_DATE,LAST_UPDATED_BY,LAST_UPDATE_DATE)' ||
                   CHR(10) || 'VALUES( N_SUB_SEQ ,N_PARENT_SEQ,' ||
                   REC2.ENTITY_ID || ',' ||
                   PKG_SO_SWITCH.FN_SIGN(REC2.ENTITY_VALUE) || ',' ||
                   PKG_SO_SWITCH.FN_SIGN(REC2.PARAM_DESC) || ',' ||
                   PKG_SO_SWITCH.FN_SIGN(REC2.ORG_CUST_FLAG) || ',' ||
                   PKG_SO_SWITCH.FN_SIGN(REC2.ACTIVE_FLAG) || ',' ||
                   PKG_SO_SWITCH.FN_SIGN(V_USER) || ',sysdate,' ||
                   PKG_SO_SWITCH.FN_SIGN(V_USER) || ',sysdate);' || CHR(10);
        
          DBMS_OUTPUT.PUT_LINE(V_SQL);
        END LOOP;
        DBMS_OUTPUT.PUT_LINE(CHR(10));
      END LOOP;
    END LOOP;
    DBMS_OUTPUT.PUT_LINE('END;' || CHR(10) || '/');
  END;
  PROCEDURE P_MAKE_SQL(PRM_TABLE_NAME VARCHAR2) AS
    V_SQL  VARCHAR2(4000);
    V_TMP1 VARCHAR2(2000);
    V_TMP2 VARCHAR2(2000);
  BEGIN
    --PRM_TABLE_NAME := 'T_SO_BILL_TYPE_RELATION';
  
    V_SQL := 'INSERT INTO ' || PRM_TABLE_NAME || '(';
    FOR REC IN (SELECT A.TABLE_NAME,
                       A.COLUMN_NAME,
                       A.DATA_TYPE,
                       A.COLUMN_ID,
                       FN_SIGN((CASE
                                 WHEN A.DATA_TYPE LIKE '%CHAR%' THEN
                                  '||FN_SIGN(' || A.COLUMN_NAME || ')||'
                                 WHEN A.DATA_TYPE = 'NUMBER' THEN
                                  '||' || A.COLUMN_NAME || '||'
                                 WHEN A.DATA_TYPE = 'DATE' THEN
                                  '||''SYSDATE''||'
                                 ELSE
                                  '错误'
                               END)) AS TXT
                  FROM USER_TAB_COLUMNS A
                 WHERE A.TABLE_NAME = PRM_TABLE_NAME
                 ORDER BY A.COLUMN_ID) LOOP
      IF REC.COLUMN_ID = 1 THEN
        V_TMP1 := V_TMP1 || REC.COLUMN_NAME;
      ELSE
        V_TMP1 := V_TMP1 || ',' || REC.COLUMN_NAME;
      END IF;
    END LOOP;
    V_SQL := V_SQL || V_TMP1 || ') VALUES (';
  
    FOR REC IN (SELECT A.TABLE_NAME,
                       A.COLUMN_NAME,
                       A.DATA_TYPE,
                       A.COLUMN_ID,
                       FN_SIGN((CASE
                                 WHEN A.DATA_TYPE LIKE '%CHAR%' THEN
                                  '||FN_SIGN(' || A.COLUMN_NAME || ')||'
                                 WHEN A.DATA_TYPE = 'NUMBER' THEN
                                  '||' || A.COLUMN_NAME || '||'
                                 WHEN A.DATA_TYPE = 'DATE' THEN
                                  '||''SYSDATE''||'
                                 ELSE
                                  '错误'
                               END)) AS TXT
                  FROM USER_TAB_COLUMNS A
                 WHERE A.TABLE_NAME = PRM_TABLE_NAME
                 ORDER BY A.COLUMN_ID) LOOP
      IF REC.COLUMN_ID = 1 THEN
      
        V_TMP2 := V_TMP2 || REC.TXT;
      ELSE
        V_TMP2 := V_TMP2 || ',' || REC.TXT;
      END IF;
    END LOOP;
    V_SQL := V_SQL || V_TMP2 || ');';
    DBMS_OUTPUT.PUT_LINE('SELECT ' || FN_SIGN(V_SQL) || ' FROM ' ||
                         PRM_TABLE_NAME || ';');
  END;
END PKG_SO_SWITCH;
/

