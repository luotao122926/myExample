create view V_BD_ITEM_CODELIST_CSS as
select codetype,
       codetype_name,
       code_value,
       code_name,
       code_order,
       last_updated_by,
       last_update_date
  from T_BD_ITEM_codelist c
 where c.codetype in ('GE_MPL_PRODUCT_FORM', 'GE_MPL_BRAND')
/

