create PACKAGE PKG_INTF_REPAIR is

  -- Author  : zengxiangsheng
  -- Created : 2015/11/18 9:16:00

  -- 自动修复程序-入口(JOB调度入口)
  procedure p_intf_deal_repair;

  -- desc:纠正SO接口错误信息(重置状态或修复单据状态为成功)，依赖ERP的dblink
  procedure p_intf_oe_repair;

  -- desc:库存事务接口状态修复
  procedure p_intf_inv_repair;

END PKG_INTF_REPAIR;
/

