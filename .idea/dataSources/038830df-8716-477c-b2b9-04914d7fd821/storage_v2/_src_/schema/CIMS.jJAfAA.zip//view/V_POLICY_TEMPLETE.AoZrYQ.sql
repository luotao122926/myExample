create view V_POLICY_TEMPLETE as
select a.policy_id||b.policy_templete_id as id,
       a.policy_id,
       b."POLICY_TEMPLETE_ID",b."POLICY_TYPE_ID",b."SERIAL_NO",b."POLICY_ITEM",b."POLICY_ITEM_TYPE",b."GET_VAL_TYPE",b."SEMANTIC_CODE",b."GET_VAL_EXPRESSION",b."PUBLIC_FLAG",b."CREATED_BY",b."CREATION_DATE",b."LAST_UPDATED_BY",b."LAST_UPDATE_DATE"       
 from T_POL_POLICY a,
      T_POL_POLICY_TEMPLETE b
   where a.policy_type_id = b.policy_type_id
/

