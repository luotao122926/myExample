create PACKAGE BODY      PKG_CUSTOMER_INTF_NC IS
  --V_NL CONSTANT VARCHAR2(2) := CHR(13) || CHR(10); --换行

  PROCEDURE P_CUSTOMER_INTF_NC_PROC(IN_PAGE_SIZE IN NUMBER, --
                                    OS_MESSAGE   OUT VARCHAR2 --成功则返回“SUCCESS”，否则返回出错信息
                                    ) IS
    V_COUNT             NUMBER;
  BEGIN
    
    BEGIN
      DELETE FROM INTF_NC_CUSTOMER_BANK IB
             WHERE NOT EXISTS (SELECT 1 FROM INTF_NC_CUSTOMER_HEADER IH WHERE IH.NC_CUSTOMER_HEADER_ID = IB.NC_CUSTOMER_HEADER_ID);
    EXCEPTION WHEN OTHERS THEN
      NULL;
    END;
    
    FOR ET IN (SELECT V.ENTITY_ID
                 FROM V_BD_ENTITY V
                WHERE 'NC' = PKG_BD.F_GET_PARAMETER_VALUE('PUB_FIN_SYS',
                                                          V.ENTITY_ID,
                                                          NULL,
                                                          NULL)) LOOP
      V_COUNT := 0;
      FOR LI IN (SELECT *
                   FROM (--SELECT * FROM (
                           --
                           SELECT DISTINCT D.DEPT_ID             AS ENTITY_ID,
                                                 D.CUSTOMER_ID,
                                                 D.PRE_FIELD_01        AS I_CUSTOMER_ID,
                                                 H.LAST_INTERFACE_DATE,
                                                 H.LAST_UPDATE_DATE
                                   FROM T_CUSTOMER_DEPT    D,
                                        INTF_CUSTOMER_DEPT CD,
                                        T_CUSTOMER_HEADER  H
                                  WHERE CD.SIEBEL_ID = D.SIEBEL_ID
                                    AND D.CUSTOMER_ID = H.CUSTOMER_ID
                                    AND D.ACTIVE_FLAG IN
                                        ('Active', 'Inactive', 'Freezing')
                                    AND D.DEPT_ID = ET.ENTITY_ID
                                    AND NOT EXISTS
                                  (SELECT 1
                                           FROM INTF_NC_CUSTOMER_HEADER I
                                          WHERE I.CUSTOMER_ID = H.CUSTOMER_ID
                                            AND I.ENTITY_ID = ET.ENTITY_ID
                                            AND I.LAST_UPDATE_DATE >=
                                                GREATEST(H.LAST_INTERFACE_DATE,
                                                         NVL(H.LAST_UPDATE_DATE,
                                                             H.CREATION_DATE),
                                                         H.CREATION_DATE))
                                 UNION
                                 SELECT DISTINCT BK.ENTITY_ID           AS ENTITY_ID,
                                                 BK.CUSTOMER_ID,
                                                 IB.PRE_FIELD_01        AS I_CUSTOMER_ID,
                                                 BK.LAST_INTERFACE_DATE,
                                                 BK.LAST_UPDATE_DATE
                                   FROM T_CUSTOMER_BANK    BK,
                                        INTF_CUSTOMER_BANK IB
                                 --,INTF_CUSTOMER_DEPT D
                                  WHERE BK.SIEBEL_BANK_ID = IB.SIEBEL_BANK_ID
                                       --AND D.SIEBEL_ID = IB.PARENT_ID
                                    AND BK.ACTIVE_FLAG IN
                                        ('Active', 'Inactive', 'Freezing')
                                    AND BK.ENTITY_ID = ET.ENTITY_ID
                                    AND NOT EXISTS
                                  (SELECT 1
                                           FROM INTF_NC_CUSTOMER_BANK NB
                                          WHERE NB.CUSTOMER_BANK_ID =
                                                BK.BANK_ID
                                            AND NB.LAST_UPDATE_DATE >=
                                                GREATEST(BK.LAST_INTERFACE_DATE,
                                                         NVL(BK.LAST_UPDATE_DATE,
                                                             BK.CREATION_DATE),
                                                         BK.CREATION_DATE))) DT
                          WHERE EXISTS (SELECT 1 FROM T_CUSTOMER_ORG CO
                     WHERE CO.ENTITY_ID = DT.ENTITY_ID
                       AND CO.CUSTOMER_ID = DT.CUSTOMER_ID
                       AND 'Active' = CO.ACTIVE_FLAG)
                          ORDER BY LAST_INTERFACE_DATE, LAST_UPDATE_DATE
                          --) WHERE ROWNUM <= IN_PAGE_SIZE
                          --
                  ) LOOP
        IF V_COUNT >= IN_PAGE_SIZE THEN
          EXIT;
        END IF;
        BEGIN
          P_CUSTOMER_INTF_NC_PROC(LI.ENTITY_ID,
                                  LI.I_CUSTOMER_ID,
                                  LI.CUSTOMER_ID,
                                  OS_MESSAGE);
          IF 'SUCCESS' = OS_MESSAGE THEN
            V_COUNT := (1 + V_COUNT);
            COMMIT;
          END IF;
        EXCEPTION
          WHEN OTHERS THEN
            OS_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('P_CUSTOMER_INTF_NC_PROC',
                                              SQLCODE,
                                              dbms_utility.format_error_backtrace || SQLERRM);
        END;
      END LOOP;
    END LOOP;
  END P_CUSTOMER_INTF_NC_PROC;

  PROCEDURE P_CUSTOMER_INTF_NC_PROC(IN_ENTITY_ID        IN NUMBER, --主体ID，相应主体系统参数PUB_FIN_SYS为NC
                                    IN_INTF_CUSTOMER_ID IN NUMBER, --客户头接口表ID
                                    IN_CUSTOMER_ID      IN VARCHAR2, --客户头正式表ID
                                    OS_MESSAGE          OUT VARCHAR2 --成功则返回“SUCCESS”，否则返回出错信息
                                    ) IS
    V_COUNT             NUMBER;
    VR_CUSTOMER_H       T_CUSTOMER_HEADER%ROWTYPE;
    VN_NC_CUSTOMER_H_ID NUMBER;
    --pragma autonomous_transaction;
    VR_COOPERATION_MODEL T_CUSTOMER_BRAND.COOPERATION_MODEL%TYPE;
    VT_NC_ORG_ID         T_AR_OU_RELATION.NC_ORG_ID%TYPE;
    VT_NC_ORG_CODE       T_AR_OU_RELATION.NC_ORG_CODE%TYPE;
    VV_MSG               VARCHAR2(500);
  BEGIN
    OS_MESSAGE := NULL;
  
    --客户接口NC事务控制点
    SAVEPOINT SAVEPOINT_CUST_NC;
    BEGIN
      SELECT COUNT(0)
        INTO V_COUNT
        FROM T_CUSTOMER_DEPT D
      /*INNER JOIN UP_ORG_UNIT U ON (D.DEPT_ID = U.ENTITY_ID
      AND D.DEPT_CODE = U.CODE
      AND (U.TYPE_CODE = 'BU' OR U.TYPE_CODE = 'MC')
      --AND U.IS_ENABLED = ''
      )*/
       WHERE D.CUSTOMER_ID = TO_NUMBER(IN_CUSTOMER_ID)
         AND (D.ACTIVE_FLAG = 'Active' OR D.ACTIVE_FLAG = 'Freezing')
         AND (D.DEPT_CUSTOMER_STATUS = 'Active' OR
             D.DEPT_CUSTOMER_STATUS = 'Freezing')
         AND D.DEPT_ID = IN_ENTITY_ID
      /*AND 'NC' = PKG_BD.F_GET_PARAMETER_VALUE('PUB_FIN_SYS',
      D.DEPT_ID,
      NULL,
      NULL)*/
      ;
      IF 1 = V_COUNT THEN
        --OS_MESSAGE := 'SUCCESS';
      --ELSE
        SELECT *
          INTO VR_CUSTOMER_H
          FROM T_CUSTOMER_HEADER H
         WHERE H.CUSTOMER_ID = TO_NUMBER(IN_CUSTOMER_ID);
      
        SELECT (SELECT COOPERATION_MODEL
                  FROM (SELECT T.LAST_UPDATE_DATE, T.COOPERATION_MODEL
                          FROM T_CUSTOMER_BRAND T
                         WHERE T.CUSTOMER_ID = TO_NUMBER(IN_CUSTOMER_ID)
                           AND T.ENTITY_ID = IN_ENTITY_ID
                           AND 'Active' = T.ACTIVE_FLAG
                         ORDER BY T.LAST_UPDATE_DATE
                        --最早的
                        )
                 WHERE 1 = ROWNUM)
          INTO VR_COOPERATION_MODEL
          FROM DUAL;
      
        IF VR_COOPERATION_MODEL IS NULL THEN
          ROLLBACK TO SAVEPOINT_CUST_NC;
          OS_MESSAGE := '客户经营品牌大类无法获取[IN_ENTITY_ID=' || IN_ENTITY_ID ||
                        ',CUSTID=' || IN_CUSTOMER_ID || ']';
          /*OS_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('P_CUSTOMER_INTF_NC_PROC',
                                              SQLCODE,
                                              dbms_utility.format_error_backtrace || SQLERRM);*/
          RETURN;
        END IF;
      
        /*
        SELECT O.ENTITY_ID,
                            O.CUSTOMER_ID,
                            O.SALES_CENTER_ID,
                            O.SALES_CENTER_CODE,
                            MAX(ANO.NC_ORG_ID) AS NC_ORG_ID,
                            MAX(ANO.NC_ORG_CODE) AS NC_ORG_CODE
                       FROM T_CUSTOMER_ORG O
                      INNER JOIN T_AR_OU_RELATION ANO
                         ON (ANO.ENTITY_ID = O.ENTITY_ID AND
                            ANO.SALES_CENTER_ID = O.SALES_CENTER_ID)
                      WHERE O.ENTITY_ID = IN_ENTITY_ID
                        AND O.CUSTOMER_ID = IN_CUSTOMER_ID
                        AND 'Active' = O.ACTIVE_FLAG
                        AND ANO.NC_ORG_ID IS NOT NULL
                        AND ANO.NC_ORG_CODE IS NOT NULL
                      GROUP BY O.ENTITY_ID,
                               O.CUSTOMER_ID,
                               O.SALES_CENTER_ID,
                               O.SALES_CENTER_CODE
                     HAVING COUNT(DISTINCT ANO.RELATION_ID) = 1*/
        FOR ORG IN (SELECT O.ENTITY_ID,
                           O.CUSTOMER_ID,
                           O.SALES_CENTER_ID,
                           O.SALES_CENTER_CODE
                      FROM T_CUSTOMER_ORG O
                     WHERE O.ENTITY_ID = IN_ENTITY_ID
                       AND O.CUSTOMER_ID = TO_NUMBER(IN_CUSTOMER_ID)
                       AND 'Active' = O.ACTIVE_FLAG
                       --
                       ) LOOP
        
          BEGIN
            PKG_AR_COMMON.P_GET_NCORG_BY_ID(ORG.ENTITY_ID,
                                            ORG.SALES_CENTER_ID,
                                            VT_NC_ORG_CODE,
                                            VV_MSG);
          EXCEPTION
            WHEN OTHERS THEN
              BEGIN
                PKG_AR_COMMON.P_GET_NCORG_BY_ID(ORG.ENTITY_ID,
                                                ORG.SALES_CENTER_ID,
                                                VT_NC_ORG_CODE,
                                                VV_MSG);
              EXCEPTION
                WHEN OTHERS THEN
                  ROLLBACK TO SAVEPOINT_CUST_NC;
                  OS_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('P_CUSTOMER_INTF_NC_PROC',
                                              SQLCODE,
                                              dbms_utility.format_error_backtrace || SQLERRM);
                  OS_MESSAGE := '营销中心ID:' || ORG.SALES_CENTER_ID ||
                                '调用PKG_AR_COMMON.P_GET_NCORG_BY_ID获取对应的NC组织关系报错！' ||
                                SQLERRM;
              END;
          END;
        
          IF VV_MSG = 'SUCCESS' AND VT_NC_ORG_CODE IS NOT NULL THEN
            VT_NC_ORG_ID := VT_NC_ORG_CODE;
            --删除重复的数据，避免重复引入
            DELETE FROM INTF_NC_CUSTOMER_HEADER IH
             WHERE IH.CUSTOMER_ID = TO_NUMBER(IN_CUSTOMER_ID)
               AND IH.PK_ORG = VT_NC_ORG_CODE
               AND 'N' = IH.INTF_STATUS;
          
            SELECT SEQ_INTF_NC_CUSTOMER_HEADER.NEXTVAL
              INTO VN_NC_CUSTOMER_H_ID
              FROM DUAL;
            BEGIN
            INSERT INTO INTF_NC_CUSTOMER_HEADER
              (NC_CUSTOMER_HEADER_ID,
               ENTITY_ID,
               CUSTOMER_ID,
               CUSTOMER_CODE,
               CUSTOMER_NAME,
               INTF_STATUS,
               SOURCE_CODE,
               CREATED_BY,
               LAST_UPDATED_BY,
               CREATION_DATE,
               LAST_UPDATE_DATE,
               PK_CUSTCLASS, --客户基本分类编码
               CUSTPROP, --客户类型
               SHORTNAME, --客户简称
               MNECODE, --助记码
               ISFREECUST, --是否散户
               PK_COUNTRY, --客户地区
               ISSUPPLIER, --是否供应商
               PK_SUPPLIER, --对应供应商编码
               TEL1, --电话,
               FAX1, --传真
               PK_ORG,
               ORG_ID)
            VALUES
              (VN_NC_CUSTOMER_H_ID,
               ORG.ENTITY_ID,
               TO_NUMBER(IN_CUSTOMER_ID),
               VR_CUSTOMER_H.CUSTOMER_CODE,
               VR_CUSTOMER_H.CUSTOMER_NAME,
               'N',
               'NC',
               VR_CUSTOMER_H.CREATED_BY,
               VR_CUSTOMER_H.LAST_UPDATE_BY,
               --梁颜明 2018-3-28 取最后更新日期作为创建日期
               NVL(NVL(VR_CUSTOMER_H.LAST_UPDATE_DATE,
                            VR_CUSTOMER_H.CREATION_DATE),VR_CUSTOMER_H.LAST_INTERFACE_DATE),
               --VR_CUSTOMER_H.CREATION_DATE,
               GREATEST(VR_CUSTOMER_H.LAST_INTERFACE_DATE,
                        VR_CUSTOMER_H.CREATION_DATE,
                        NVL(VR_CUSTOMER_H.LAST_UPDATE_DATE,
                            VR_CUSTOMER_H.CREATION_DATE)),
               VR_COOPERATION_MODEL, --必填，客户分类编码
               '0', --必填，0=外部单位，1=内部单位
               VR_CUSTOMER_H.CUSTOMER_SHORT_NAME,
               VR_CUSTOMER_H.CUSTOMER_CODE,
               'N', --NC默认：N，Y=是，N=否
               NULL,
               VR_CUSTOMER_H.CUSTOMER_IS_VENDOR,
               VR_CUSTOMER_H.CUSTOMER_VENDOR_CODE,
               VR_CUSTOMER_H.CUSTOMER_PHONES,
               VR_CUSTOMER_H.CUSTOMER_FAX,
               VT_NC_ORG_CODE,
               VT_NC_ORG_ID);
          
            INSERT INTO INTF_NC_CUSTOMER_BANK
              (NC_CUSTOMER_BANK_ID,
               ENTITY_ID,
               NC_CUSTOMER_HEADER_ID,
               CUSTOMER_BANK_ID,
               INTF_STATUS,
               SOURCE_CODE,
               CREATED_BY,
               LAST_UPDATED_BY,
               CREATION_DATE,
               LAST_UPDATE_DATE,
               PK_CUST,
               ACCNUM,
               ACCNAME,
               PK_BANKTYPE,
               ACCOUNTPROPERTY,
               PK_ORG,
               CODE,
               NAME,
               MNECODE,
               ORG_ID,
               ubank_no --add by liangym2 添加银行联行号
               )
              SELECT SEQ_INTF_NC_CUSTOMER_BANK.NEXTVAL,
                     B.ENTITY_ID,
                     VN_NC_CUSTOMER_H_ID,
                     B.BANK_ID,
                     'N',
                     'NC',
                     B.CREATED_BY,
                     B.LAST_UPDATE_BY,
                     --梁颜明 2018-3-28 取最后更新日期作为创建日期
                     NVL(NVL(B.LAST_UPDATE_DATE,B.CREATION_DATE),B.LAST_INTERFACE_DATE),
                     --B.CREATION_DATE,
                     GREATEST(B.LAST_INTERFACE_DATE,
                              B.CREATION_DATE,
                              NVL(B.LAST_UPDATE_DATE, B.CREATION_DATE)),
                     B.CUSTOMER_CODE,
                     B.BANK_ACCOUNT,
                     B.ACCOUNTS_NAME,
                     B.BANK,
                     '0',
                     VT_NC_ORG_CODE, --客户所属组织
                     NULL, --账户编码
                     B.ACCOUNTS_NAME, --账户名称
                     B.BANK_ACCOUNT, --助记码
                     VT_NC_ORG_ID,
                     B.PRE_FIELD_02 --add by liangym2 添加银行联行号
                FROM T_CUSTOMER_BANK B
               WHERE B.CUSTOMER_ID = TO_NUMBER(IN_CUSTOMER_ID)
                 AND B.ENTITY_ID = IN_ENTITY_ID
                 AND EXISTS
               (SELECT 1
                        FROM INTF_CUSTOMER_BANK IB
                       WHERE IB.SIEBEL_BANK_ID = B.SIEBEL_BANK_ID
                         AND IB.PRE_FIELD_01 = TO_CHAR(IN_INTF_CUSTOMER_ID)
                         AND IB.RESPONSETYPE = 'N'
                         AND IB.RESPNOSECODE = '000000'
                         AND IB.RESPONSEMESSAGE = 'SUCCESS');
            --删除重复的数据，避免重复引入
            DELETE FROM INTF_NC_CUSTOMER_BANK IB
             WHERE IB.NC_CUSTOMER_HEADER_ID <> VN_NC_CUSTOMER_H_ID
               AND IB.PK_ORG = VT_NC_ORG_CODE
               AND 'N' = IB.INTF_STATUS
               AND EXISTS
             (SELECT 1
                      FROM INTF_NC_CUSTOMER_BANK B
                     WHERE B.NC_CUSTOMER_HEADER_ID = VN_NC_CUSTOMER_H_ID
                       AND B.CUSTOMER_BANK_ID = IB.CUSTOMER_BANK_ID
                       AND B.PK_ORG = IB.PK_ORG);
          
            OS_MESSAGE := 'SUCCESS';
            
          	EXCEPTION WHEN OTHERS THEN
              OS_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('P_CUSTOMER_INTF_NC_PROC',
                                              SQLCODE,
                                              dbms_utility.format_error_backtrace || SQLERRM);
            END;
          END IF;
        
        END LOOP;
        --COMMIT;
      
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        ROLLBACK TO SAVEPOINT_CUST_NC
        --
        ;
        OS_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('P_CUSTOMER_INTF_NC_PROC',
                                              SQLCODE,
                                              dbms_utility.format_error_backtrace || SQLERRM);
    END;
  END P_CUSTOMER_INTF_NC_PROC;

END PKG_CUSTOMER_INTF_NC;
/

