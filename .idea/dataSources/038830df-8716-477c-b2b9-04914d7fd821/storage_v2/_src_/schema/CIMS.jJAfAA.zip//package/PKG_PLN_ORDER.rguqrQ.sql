create Package Pkg_Pln_Order Is

  -- AUTHOR  : NICRO.LI
  -- CREATED : 2014-07-14 11:09:06
  -- PURPOSE : 订单处理过程

  -----------------------------------------------------------------------------
  -- AUTHOR  : NICRO.LI
  -- CREATED : 2014-07-14 11:05:52
  -- PURPOSE : 检查送审的订单行 (商品如果没有在当前生产产地维护则返回提示)
  -----------------------------------------------------------------------------
  Procedure p_Chk_Order_Line_Mtl_Producing(p_Order_Head_Id In Number, ----订单ID
                                           p_Result        Out Varchar2 --返回结果：成功返回"SUCCESS"，失败返回原因
                                           );

  -----------------------------------------------------------------------------
  -- AUTHOR  : NICRO.LI
  -- CREATED : 2014-07-16 11:05:52
  -- PURPOSE : 初始化计划阶段
  -----------------------------------------------------------------------------
  Procedure p_Init_Order_Period(p_Year_Code In Varchar2, --计划年度编码
                                p_Entity_Id In Number, --主体ID
                                p_User_Code In Varchar2, --用户ID
                                p_Result    Out Number,
                                p_Err_Msg   Out Varchar2 --返回结果：成功返回"SUCCESS"，失败返回原因
                                );

  -----------------------------------------------------------------------------
  ---- AUTHOR  : NICRO.LI
  -- CREATED : 2017-01-04 11:05:52
  -- PURPOSE : 订单退回，主要用于产能占用订单的退回
  -----------------------------------------------------------------------------
  Procedure p_Back_Order(p_Order_Head_Id      In Number, ----订单头ID(如果没有则需传入-1)
                         p_Operation_Action   In Varchar2, --订单当前操作类型
                         p_User_Code          In Varchar2, ----用户编码
                         p_Result             In Out Varchar2, ----退回原因,/返回结果
                         p_Order_Collect_Flag In Varchar2 Default 'N' --是否为汇总订单
                         );

  -----------------------------------------------------------------------------
  -- AUTHOR  : NICRO.LI
  -- CREATED : 2014-07-14 11:05:52
  -- PURPOSE : 订单流程处理公共入口过程
  -----------------------------------------------------------------------------
  Procedure p_Order_Operate(p_Order_Head_Id    In Number, ----单据头ID（订单头ID、汇总头ID、提货订单头ID）
                            p_Order_Type_Id    In Number, --单据类型ID
                            p_Operation_Action In Varchar2, --当前单据动作
                            p_User_Code        In Varchar2, ----用户ID
                            p_Result           In Out VARCHAR2 --返回结果：成功返回"SUCCESS"，失败返回原因
                            );

  ---------------------------------------------------------------------------------------
  ---- AUTHOR  : NICRO.LI
  -- CREATED : 2014-07-16 11:05:52
  -- PURPOSE : 发货计划订单取消订单数量
  -----------------------------------------------------------------------------
  Procedure p_Order_Cancel(p_Entity_Id    In Number, --主主体ID,
                           p_Order_Shares In Varchar2, --商品行ID列表
                           p_User_Code    In Varchar2, --用户ID
                           p_Result       In Out Varchar2);


  -----------------------------------------------------------------------------
  ---- AUTHOR  :zhangchucai
  -- CREATED : 2014-10-27
  -- PURPOSE : 第四周排产
  -----------------------------------------------------------------------------
  Procedure p_Order_Last_Week_Single(p_produncing_id in number, --产地Id
                                      p_Sales_center_id in number, --营销中心Id
                                      p_order_type_id in number, --订单类型Id
                                      p_period_id     in number, --周期Id
                                      p_main_type_sys in varchar2,--订单大类参数
                                      p_sub_type_sys  in varchar2,-- 订单小类参数
                                      p_main_type     in varchar2,--订单大类
                                      p_sub_type      in varchar2,-- 订单小类
                                      p_entity_id     in number, --主体Id
                                      p_user_name     in varchar2, --用户
                                      p_result in out varchar2);
  -----------------------------------------------------------------------------
  -- AUTHOR  : NICRO.LI
  -- CREATED : 2014-07-14 11:05:52
  -- PURPOSE : 从月、增补订单生成周排产，库存评审数量评审到周订单
  -- p_Result: 成功把回SUCCESS。
  -----------------------------------------------------------------------------
  Procedure p_Import_Order_Inv_Review(p_Sales_Center_Id    In Number, --中心ID
                                      p_Dest_Period_Id     In Number, --周排产订单周期ID
                                      p_Dest_Order_Type_Id In Number, --目标单据类型ID(目前是周排产订单）
                                      p_Dest_Order_Head_Id In Number, --目标单据头ID
                                      p_Entity_Id          In Number, --主体ID
                                      p_User_Code          In Varchar2, ----用户编码
                                      p_Result             In Out Varchar2 --返回结果：成功返回"SUCCESS"，失败返回原因
                                      );

  -----------------------------------------------------------------------------
  -- AUTHOR  : 张楚材
  -- CREATED : 2014-11-12 11:05:52
  -- PURPOSE : 根据月(M+1)、月(M+2)、月增补批量生成所有销售公司周排产第4周订单
  -- p_Result: 成功把回SUCCESS。
  -----------------------------------------------------------------------------
  Procedure p_Create_Order_Last_Week_All(p_Order_Type_Id In Number, --订单类型Id
                                         p_Period_Id     In Number, --周期Id
                                         p_main_type_sys in varchar2,--订单大类参数
                                         p_sub_type_sys  in varchar2,-- 订单小类参数
                                         p_main_type     in varchar2,--订单大类
                                         p_sub_type      in varchar2,-- 订单小类
                                         p_Entity_Id     In Number, --主体Id
                                         p_User_Name     In Varchar2, --用户
                                         p_Result        In Out Varchar2);

 -----------------------------------------------------------------------------
  -- AUTHOR  : 李振
  -- CREATED : 2015-02-10 11:05:52
  -- PURPOSE : 检查产品在产地是否生产，是返回：SUCCESS  否：返回异常信息
  -----------------------------------------------------------------------------
  Procedure p_Check_Item_ProducingArea(p_Order_Head_Id      In Number, ----订单ID、汇总单头ID
                                       p_Order_Collect_Type In Number, --汇总订单标识：1：汇总  2：单单
                                       p_User_Code          In Varchar2, ----用户ID
                                       p_Result             In Out Varchar2 --返回结果：成功返回"SUCCESS"，失败返回原因
                                       );

  -----------------------------------------------------------------------------
  -- AUTHOR  : 唐家智
  -- CREATED : 2015-07-10 10:06:52
  -- PURPOSE : 取消计划订单和提货订单关联关系，成功返回：SUCCESS  失败：返回异常信息
  -----------------------------------------------------------------------------
  Procedure p_Cancel_LgPlnRela(p_Relation_Id_List   In Varchar2, --计划订单行、提货订单行 关系表主键id列表
                               p_User_Code  In Varchar2, --用户编码
                               p_Entity_Id  In Number, --主体Id
                               p_Result     In Out Varchar2 --返回结果：成功返回"SUCCESS"，失败返回原因
                               );

  -----------------------------------------------------------------------------
  -- AUTHOR  : 李振
  -- CREATED : 2015-08-29
  -- PURPOSE : 提货订单关闭时，同步取消计划订单
  -----------------------------------------------------------------------------
  Procedure p_Lg_Close_Cancel_Order(p_Order_Head_Id    In Number, --订单ID
                                    p_User_Code        In Varchar2, ----用户ID
                                    p_Result           In Out Varchar2, --返回结果：成功返回SUCCESS，失败返回原因
                                    p_Close_Line_Flag  In Varchar2 Default 'N' --是否关闭订单行 --add by lizhen 2016-06-14
                                    );
 -----------------------------------------------------------------------------
  -- AUTHOR  : 李振
  -- CREATED : 2015-08-29
  -- PURPOSE : 提货订单关闭时，同步取消计划订单
  -----------------------------------------------------------------------------

  -----------------------------------------------------------------------------
  -- AUTHOR  : xuhongjiu
  -- CREATED : 2015-12-3
  -- PURPOSE : 订单调整审核操作
  -----------------------------------------------------------------------------
  Procedure p_Adjust_Order_Review(p_Order_Head_Id    In Number, ----调整订单头ID
                                 p_User_Code        In Varchar2, ----用户编码
                                 p_Result           Out Varchar2 ----返回结果：成功返回"SUCCESS"，失败返回原因
                                 );

  -----------------------------------------------------------------------------
  -- AUTHOR  : lilh6
  -- CREATED : 2018-7-4
  -- PURPOSE : 解锁提货订单对应的T+3订单
  -----------------------------------------------------------------------------
  Procedure P_CANCEL_T3_ORDER(p_Order_Head_Id IN NUMBER, --提货订单头id
                              P_USER_CODE     IN VARCHAR2, --产品
                              p_Result        In Out Varchar2 --返回结果：成功返回SUCCESS，失败返回原因
                              );
End Pkg_Pln_Order;
/

