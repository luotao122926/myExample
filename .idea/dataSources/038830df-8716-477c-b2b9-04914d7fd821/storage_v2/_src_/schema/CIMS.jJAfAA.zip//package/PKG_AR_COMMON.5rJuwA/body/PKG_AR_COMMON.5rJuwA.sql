create PACKAGE BODY      PKG_AR_COMMON IS

  /*
  *校验出票人银行账户、第一收款人银行账户、票据号格式
  *暂不校验票据分号格式
  *出票人银行账户长度<38
  */
  FUNCTION F_VALIDATE_FORMAT(P_CASH_RECEIPT_CODE          T_AR_CASH_RECEIPT_HEADERS.CASH_RECEIPT_CODE%TYPE, --收款单号（收款）
                             P_FIRST_RECEIPT_BANK_ACCOUNT T_AR_CASH_RECEIPT_HEADERS.FIRST_RECEIPT_BANK_ACCOUNT%TYPE, --第一收款人银行账户（收款）
                             P_DRAWER_BANK_ACCOUNT        T_AR_CASH_RECEIPT_HEADERS.DRAWER_BANK_ACCOUNT%TYPE, --出票人银行账户（收款）
                             P_CASH_CODE                  T_AR_CASH_RECEIPT_HEADERS.CASH_CODE%TYPE --票据号（收款）
                             ) RETURN VARCHAR2 AS
    V_MESSAGE VARCHAR2(1000);

  BEGIN
    V_MESSAGE := 'SUCCESS';
    --校验第一收款人银行账号格式：字母、数字、中划线
    IF P_FIRST_RECEIPT_BANK_ACCOUNT IS NOT NULL AND
       REGEXP_SUBSTR(P_FIRST_RECEIPT_BANK_ACCOUNT, '[0-9a-zA-Z\-]*') <>
       P_FIRST_RECEIPT_BANK_ACCOUNT THEN
      V_MESSAGE := '收款单' || P_CASH_RECEIPT_CODE || '的第一收款人银行账户格式不正确';
      RETURN V_MESSAGE;
    END IF;
    --校验出票人银行账号格式：字母、数字、中划线
    IF P_DRAWER_BANK_ACCOUNT IS NOT NULL AND
       REGEXP_SUBSTR(P_DRAWER_BANK_ACCOUNT, '[0-9a-zA-Z\-]*') <>
       P_DRAWER_BANK_ACCOUNT THEN
      V_MESSAGE := '收款单' || P_CASH_RECEIPT_CODE || '的出票人银行账户格式不正确';
      RETURN V_MESSAGE;
    END IF;
    --出票人银行账户长度<38
    IF P_DRAWER_BANK_ACCOUNT IS NOT NULL AND
       LENGTH(P_DRAWER_BANK_ACCOUNT) >= 38 THEN
      V_MESSAGE := '收款单' || P_CASH_RECEIPT_CODE || '的出票人银行账户长度不正确，必须小于38';
      RETURN V_MESSAGE;
    END IF;
    --校验票据号格式：数字
    IF P_CASH_CODE IS NOT NULL AND
       REGEXP_SUBSTR(P_CASH_CODE, '[0-9]*') <> P_CASH_CODE THEN
      V_MESSAGE := '收款单' || P_CASH_RECEIPT_CODE || '的票据号格式不正确';
      RETURN V_MESSAGE;
    END IF;
    RETURN V_MESSAGE;
  END;

  /*
  *校验票据号长度
  */
  FUNCTION F_VALIDATE_CODE_LEN(P_CASH_RECEIPT_CODE T_AR_CASH_RECEIPT_HEADERS.CASH_RECEIPT_CODE%TYPE, --收款单号（收款）
                               P_CODE_LEN          T_AR_RECEIPT_METHODS.CASH_CODE_LENGTH%TYPE, --票据号长度（收款方法）
                               P_CASH_CODE         T_AR_CASH_RECEIPT_HEADERS.CASH_CODE%TYPE --票据号（收款）
                               ) RETURN VARCHAR2 AS
    V_MESSAGE VARCHAR2(1000);
  BEGIN
    V_MESSAGE := 'SUCCESS';
    --校验票据号长度（收款方法配置）
    IF P_CODE_LEN IS NOT NULL THEN
      --电汇收款方法没有票据号
      IF P_CODE_LEN = 0 AND P_CASH_CODE IS NOT NULL THEN
        V_MESSAGE := '收款单' || P_CASH_RECEIPT_CODE || '的票据号长度不为0';
      ELSIF P_CODE_LEN > 0 AND P_CASH_CODE IS NULL THEN
        V_MESSAGE := '收款单' || P_CASH_RECEIPT_CODE || '的票据号为空';
      ELSIF P_CASH_CODE IS NOT NULL AND P_CODE_LEN > 0 AND
            LENGTH(P_CASH_CODE) <> P_CODE_LEN THEN
        V_MESSAGE := '收款单' || P_CASH_RECEIPT_CODE || '的票据号长度为' ||
                     P_CODE_LEN;
      END IF;
    END IF;
    RETURN V_MESSAGE;
  END;

  /*
  *校验票据期限：到期日期>当天 、 到期日期>=出票日期  、 到期日期-出票日期>票据期限
  */
  FUNCTION F_VALIDATE_CODE_DATE_TERM(P_CASH_RECEIPT_CODE T_AR_CASH_RECEIPT_HEADERS.CASH_RECEIPT_CODE%TYPE, --收款单号（收款）
                                     P_DUE_DATE          T_AR_CASH_RECEIPT_HEADERS.DUE_DATE%TYPE, --票据到期日（收款）
                                     P_CASH_DATE         T_AR_CASH_RECEIPT_HEADERS.CASH_DATE%TYPE, --出票日期（收款）
                                     P_DATE_TERM         T_AR_RECEIPT_METHODS.CASH_DATE_TERM%TYPE --票据期限（收款方法）
                                     ) RETURN VARCHAR2 AS
    V_MESSAGE      VARCHAR2(1000);
    V_CURRENT_DATE DATE;
  BEGIN
    V_MESSAGE := 'SUCCESS';
    --当前系统日期
    BEGIN
      SELECT TRUNC(SYSDATE) INTO V_CURRENT_DATE FROM DUAL;
    EXCEPTION
      WHEN OTHERS THEN
        V_MESSAGE := '获取当前系统日期异常，请联系管理员';
        RETURN V_MESSAGE;
    END;
    IF P_DATE_TERM IS NULL THEN
      IF P_DUE_DATE < V_CURRENT_DATE THEN
        V_MESSAGE := '收款单' || P_CASH_RECEIPT_CODE || '的到期日期不能小于当天';
      ELSIF P_DUE_DATE <= P_CASH_DATE THEN
        V_MESSAGE := '收款单' || P_CASH_RECEIPT_CODE || '的到期日期不能小于等于出票日期';
      END IF;
    ELSE
      IF P_DUE_DATE < V_CURRENT_DATE THEN
        V_MESSAGE := '收款单' || P_CASH_RECEIPT_CODE || '的到期日期不能小于当天';
      ELSIF P_DUE_DATE IS NULL OR P_CASH_DATE IS NULL THEN
        V_MESSAGE := '收款单' || P_CASH_RECEIPT_CODE || '的出票日期/到期日期不能为空';
      ELSIF P_DUE_DATE - P_CASH_DATE > P_DATE_TERM THEN
        V_MESSAGE := '收款单' || P_CASH_RECEIPT_CODE || '的到期日期-出票日期>票据期限';
      END IF;
    END IF;
    RETURN V_MESSAGE;
  END;

  /*
  *校验票据是否重复
  */
  FUNCTION F_VALIDATE_CODE_REPEAT(P_CASH_RECEIPT_CODE T_AR_CASH_RECEIPT_HEADERS.CASH_RECEIPT_CODE%TYPE, --收款单号（收款）
                                  P_CASH_CODE         T_AR_CASH_RECEIPT_HEADERS.CASH_CODE%TYPE, --票据号（收款）
                                  P_SUB_CASH_CODE     T_AR_CASH_RECEIPT_HEADERS.SUB_CASH_CODE%TYPE, --票据分号（收款）
                                  P_UNITE_FLAG        T_AR_CASH_RECEIPT_HEADERS.UNITE_FLAG%TYPE, --合并导入标志（收款）
                                  P_CASH_RECEIPT_ID   T_AR_CASH_RECEIPT_HEADERS.CASH_RECEIPT_ID%TYPE --收款单ID
                                  ) RETURN VARCHAR2 AS
    V_MESSAGE          VARCHAR2(1000);
    V_CODE_REPEAT_FLAG NUMBER;
    V_SUB_CODE_SUM     NUMBER;
  BEGIN
    V_MESSAGE := 'SUCCESS';
    --校验票据号是否重复（合并导入、已冲销、冲销原单、已引接口的票据号，允许重复，）
    BEGIN
      SELECT COUNT(*)
        INTO V_CODE_REPEAT_FLAG --票据号重复数
        FROM CIMS.T_AR_CASH_RECEIPT_HEADERS
       WHERE CASH_CODE = P_CASH_CODE
         AND CASH_RECEIPT_ID <> P_CASH_RECEIPT_ID
         AND RECEIPT_STATUS_ID NOT IN (2, 16) --作废、已冲销
         AND WRITEOFF_RECEIPT_CODE IS NULL --冲销原单号不为空，即冲销后生成的已确认状态的收款单
         AND INTO_GTMS_STATUS IS NULL --未引资金
         AND INTO_ERP_STATUS IS NULL; --未引ERP
    EXCEPTION
      WHEN OTHERS THEN
        V_MESSAGE := '获取数据异常，请联系管理员';
        RETURN V_MESSAGE;
    END;

    --非合并导入
    IF P_UNITE_FLAG IS NULL OR P_UNITE_FLAG <> 'Y' THEN
      IF V_CODE_REPEAT_FLAG > 0 THEN
        V_MESSAGE := '收款单' || P_CASH_RECEIPT_CODE || '的票据号重复';
      END IF;
    ELSE
      V_CODE_REPEAT_FLAG := V_CODE_REPEAT_FLAG + 1;
      --解析票据分号，判断票据总数与票据分号中的总数是否一致，暂不校验票据分号格式
      SELECT TO_NUMBER(SUBSTR(P_SUB_CASH_CODE,
                              INSTR(P_SUB_CASH_CODE, '-', 1, 1) + 1,
                              LENGTH(P_SUB_CASH_CODE) -
                              INSTR(P_SUB_CASH_CODE, '-', 1, 2)))
        INTO V_SUB_CODE_SUM
        FROM DUAL;
      IF V_CODE_REPEAT_FLAG > 0 AND V_SUB_CODE_SUM <> V_CODE_REPEAT_FLAG THEN
        V_MESSAGE := '票据号' || P_CASH_CODE || '下的收款单（子票据）录入不全，或票据总数不正确';
      END IF;
    END IF;
    RETURN V_MESSAGE;
  END;

  /*
  *获取客户下营销大类的到款余额
  */
  PROCEDURE P_GET_CUST_AMOUT(P_ENTITY_ID            IN NUMBER, --主体ID
                             P_CUSTOMER_ID          IN NUMBER, --客户ID
                             P_ACCOUNT_ID           IN NUMBER, --账户ID
                             P_RECEIPT_METHOD_ID    IN NUMBER, --收款方法ID
                             P_SALES_MAIN_TYPE_CODE IN VARCHAR2, --营销大类编码
                             P_VERIFY_AMOUNT        OUT NUMBER, --客户到款余额
                             P_MESSAGE              OUT VARCHAR2) IS
    V_RECEIPT_METHOD_ID NUMBER; --收款方法ID
    V_CREDIT_GROUP_ID   NUMBER; --额度组ID
    V_OUT_TURNFEE       NUMBER; --转出方法ID
    V_IN_TURNFEE        NUMBER; --转入方法ID
  BEGIN
    P_MESSAGE           := 'SUCCESS';
    V_RECEIPT_METHOD_ID := P_RECEIPT_METHOD_ID;
    BEGIN
      SELECT OUT_TURNFEE, IN_TURNFEE
        INTO V_OUT_TURNFEE, V_IN_TURNFEE
        FROM CIMS.T_AR_RECEIPT_METHODS M
       WHERE M.RECEIPT_METHOD_ID = P_RECEIPT_METHOD_ID;
    EXCEPTION
      WHEN OTHERS THEN
        P_MESSAGE := '收款方法（' || P_RECEIPT_METHOD_ID || '）数据异常，请联系管理员';
        RAISE V_BIZ_EXCEPTION;
    END;

    --如果方法为转款，则方法ID为：转款方法配置的转出方法ID
    IF V_IN_TURNFEE IS NOT NULL AND V_OUT_TURNFEE IS NOT NULL THEN
      V_RECEIPT_METHOD_ID := V_OUT_TURNFEE;
    END IF;
    --获取额度组ID
    SELECT FUN_GET_CREDITGROUPID(P_ENTITY_ID,
                                 P_CUSTOMER_ID,
                                 P_SALES_MAIN_TYPE_CODE)
      INTO V_CREDIT_GROUP_ID
      FROM DUAL;
    IF V_CREDIT_GROUP_ID = -1 THEN
      P_MESSAGE := '营销大类（' || P_SALES_MAIN_TYPE_CODE ||
                   '）没有配置额度组信息，请先维护额度组';
      RAISE V_BIZ_EXCEPTION;
    END IF;
    BEGIN
      --获取客户可用到款余额
      SELECT DECODE(TM.ATTRIBUTE1,
                    1,
                    V.RECEIVED_BALANCE_AMOUNT - V.LOCK_RECEIVED_AMOUNT,
                    2,
                    V.RECEIVED_BALANCE_AMOUNT - V.LOCK_RECEIVED_AMOUNT +
                    TEMP_DELAYPAY_AMOUNT,
                    0)
        INTO P_VERIFY_AMOUNT
        FROM INTF_SALES_ACCOUNT_AMOUNT V, CIMS.T_AR_RECEIPT_METHODS TM
       WHERE V.ENTITY_ID = P_ENTITY_ID
         AND V.CUSTOMER_ID = P_CUSTOMER_ID
         AND V.ACCOUNT_ID = P_ACCOUNT_ID
         AND V.CREDIT_GROUP_ID = V_CREDIT_GROUP_ID
         AND TM.RECEIPT_METHOD_ID = V_RECEIPT_METHOD_ID;
    EXCEPTION
      WHEN OTHERS THEN
        P_MESSAGE := '根据额度组（' || V_CREDIT_GROUP_ID || '）获取不到客户到款余额，请联系管理员';
        RAISE V_BIZ_EXCEPTION;
    END;
  EXCEPTION
    WHEN V_BIZ_EXCEPTION THEN
      P_MESSAGE := '获取客户到款余额：' || P_MESSAGE;
    WHEN OTHERS THEN
      P_MESSAGE := '获取客户到款余额异常，请联系管理员！';
      P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_BOND.P_GET_CUST_AMOUT',
                                          SQLCODE,
                                          P_MESSAGE ||
                                          SUBSTR(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE,
                                                 1,
                                                 100) || SQLERRM);
  END;

  /*
  *校验客户-OU是否对应，且有效
  */
  FUNCTION F_VALIDATE_CUST_OU(P_CUSTOMER_ID NUMBER, --客户ID
                              P_ERP_OU_ID   NUMBER --账户ID
                              ) RETURN VARCHAR2 AS
    V_MESSAGE      VARCHAR2(1000);
    V_CUS_OU_COUNT NUMBER;
  BEGIN
    SELECT COUNT(*)
      INTO V_CUS_OU_COUNT
      FROM CIMS.T_CUSTOMER_OU T
     WHERE T.ACTIVE_FLAG = 'Active'
       AND T.CUSTOMER_ID = P_CUSTOMER_ID
       AND T.ERPOU = P_ERP_OU_ID;
    IF V_CUS_OU_COUNT <> 1 THEN
      V_MESSAGE := '客户（' || P_CUSTOMER_ID || '）与ERP_OU（' || P_ERP_OU_ID ||
                   '）没有对应或者失效';
    ELSE
      V_MESSAGE := 'SUCCESS';
    END IF;
    RETURN V_MESSAGE;
  END;

  /*
  *校验客户-账户-主体是否一一对应，且有效
  */
  FUNCTION F_VALIDATE_CUST_ACC(P_ENTITY_ID     NUMBER,
                               P_CUSTOMER_CODE VARCHAR2,
                               P_ACCOUNT_CODE  VARCHAR2) RETURN VARCHAR2 AS
    V_MESSAGE        VARCHAR2(1000);
    V_CUST_ACC_COUNT NUMBER;
  BEGIN
    BEGIN
      SELECT COUNT(A.CUSTOMER_ID)
        INTO V_CUST_ACC_COUNT
        FROM V_AR_WRITE_OFF_CUST_ACCOUNT A
       WHERE A.CUSTOMER_CODE = P_CUSTOMER_CODE
         AND A.ACCOUNT_CODE = P_ACCOUNT_CODE
         AND A.ENTITY_ID = P_ENTITY_ID
         AND A.ACCOUNT_STATUS = '1'
         AND A.ACTIVE_FLAG = 'Active';
    EXCEPTION
      WHEN OTHERS THEN
        V_MESSAGE := '主体（' || P_ENTITY_ID || '）、客户（' || P_CUSTOMER_CODE ||
                     '）、账户（' || P_ACCOUNT_CODE || '）状态无效，或者没有一一对应';
        RETURN V_MESSAGE;
    END;
    IF V_CUST_ACC_COUNT <> 1 THEN
      V_MESSAGE := '主体（' || P_ENTITY_ID || '）、客户（' || P_CUSTOMER_CODE ||
                   '）、账户（' || P_ACCOUNT_CODE || '）状态无效，或者没有一一对应';
    ELSE
      V_MESSAGE := 'SUCCESS';
    END IF;
    RETURN V_MESSAGE;
  END;

  /*
  *校验客户-中心-主体是否一一对应，且有效
  */
  FUNCTION F_VALIDATE_CUST_CENTER(P_ENTITY_ID         NUMBER,
                                  P_CUSTOMER_CODE     VARCHAR2,
                                  P_SALES_CENTER_CODE VARCHAR2)
    RETURN VARCHAR2 AS
    V_MESSAGE        VARCHAR2(1000);
    V_CUST_CEN_COUNT NUMBER;
  BEGIN
    BEGIN
      SELECT COUNT(O.CUSTOMER_ID)
        INTO V_CUST_CEN_COUNT
        FROM T_CUSTOMER_ORG O, T_CUSTOMER_HEADER H
       WHERE O.CUSTOMER_CODE = H.CUSTOMER_CODE
         AND O.CUSTOMER_CODE = P_CUSTOMER_CODE
         AND O.SALES_CENTER_CODE = P_SALES_CENTER_CODE
         AND O.ENTITY_ID = P_ENTITY_ID
         AND O.ACTIVE_FLAG = 'Active'
         AND H.ACTIVE_FLAG = 'Active';
    EXCEPTION
      WHEN OTHERS THEN
        V_MESSAGE := '主体（' || P_ENTITY_ID || '）、客户（' || P_CUSTOMER_CODE ||
                     '）、营销中心（' || P_SALES_CENTER_CODE || '）状态无效，或者没有一一对应';
        RETURN V_MESSAGE;
    END;
    IF V_CUST_CEN_COUNT <> 1 THEN
      V_MESSAGE := '主体（' || P_ENTITY_ID || '）、客户（' || P_CUSTOMER_CODE ||
                   '）、营销中心（' || P_SALES_CENTER_CODE || '）状态无效，或者没有一一对应';
    ELSE
      V_MESSAGE := 'SUCCESS';
    END IF;
    RETURN V_MESSAGE;
  END;

  /*
  * 校验客户是否为提前开票客户（应收发票配置中，是否提前开票Y/N，Y-不引发票池；N-引发票池）
  */
  FUNCTION F_VALIDATE_IS_ADVANCE_CUSTOMER(P_ENTITY_ID       NUMBER,
                                          P_CUSTOMER_ID     NUMBER,
                                          P_SALES_CENTER_ID NUMBER)
    RETURN VARCHAR2 AS
    V_MESSAGE       VARCHAR2(1000);
    V_ADVANCE_COUNT NUMBER;
  BEGIN
    BEGIN
      SELECT COUNT(C.AR_CONF_ID)
        INTO V_ADVANCE_COUNT
        FROM T_AR_CONF C
       WHERE C.CUSTOMER_ID = P_CUSTOMER_ID
         AND C.SALES_CENTER_ID = P_SALES_CENTER_ID
         AND C.ENTITY_ID = P_ENTITY_ID
         AND NVL(C.IS_ADVANCE_FLAG, 'N') = 'N';
    EXCEPTION
      WHEN OTHERS THEN
        V_MESSAGE := '主体（' || P_ENTITY_ID || '）、客户（' || P_CUSTOMER_ID ||
                     '）、营销中心（' || P_SALES_CENTER_ID || '）获取提前开票客户异常';
        RETURN V_MESSAGE;
    END;
    IF V_ADVANCE_COUNT <> 0 THEN
      V_MESSAGE := '主体（' || P_ENTITY_ID || '）、客户（' || P_CUSTOMER_ID ||
                   '）、营销中心（' || P_SALES_CENTER_ID || '）不是提前开票客户';
    ELSE
      V_MESSAGE := 'SUCCESS';
    END IF;
    RETURN V_MESSAGE;
  END;

  /*
  *校验客户-中心-账户-主体是否一一对应，且有效
  */
  FUNCTION F_VALIDATE_CUST_CENTER_ACC(P_ENTITY_ID         NUMBER,
                                      P_CUSTOMER_CODE     VARCHAR2,
                                      P_SALES_CENTER_CODE VARCHAR2,
                                      P_ACCOUNT_CODE      VARCHAR2)
    RETURN VARCHAR2 AS
    V_MESSAGE           VARCHAR2(1000);
    V_CUS_CEN_ACC_COUNT NUMBER;
  BEGIN
    BEGIN
      SELECT COUNT(*)
        INTO V_CUS_CEN_ACC_COUNT
        FROM CIMS.V_CUSTOMER_ACCOUNT_SALECENTER V2
       WHERE V2.CUSTOMER_CODE = P_CUSTOMER_CODE
         AND V2.SALES_CENTER_CODE = P_SALES_CENTER_CODE
         AND V2.ACCOUNT_CODE = P_ACCOUNT_CODE
         AND V2.ENTITY_ID = P_ENTITY_ID
         AND V2.ACTIVE_FLAG = 'Active'
         AND V2.ACCOUNT_STATUS = '1'
         AND V2.ORGACTIVE_FLAG = 'Active';
    EXCEPTION
      WHEN OTHERS THEN
        V_MESSAGE := '主体（' || P_ENTITY_ID || '）、客户（' || P_CUSTOMER_CODE ||
                     '）、营销中心（' || P_SALES_CENTER_CODE || '）、账户（' ||
                     P_ACCOUNT_CODE || '）状态无效，或者没有一一对应';
        RETURN V_MESSAGE;
    END;
    IF V_CUS_CEN_ACC_COUNT <> 1 THEN
      V_MESSAGE := '主体（' || P_ENTITY_ID || '）、客户（' || P_CUSTOMER_CODE ||
                   '）、营销中心（' || P_SALES_CENTER_CODE || '）、账户（' ||
                   P_ACCOUNT_CODE || '）状态无效，或者没有一一对应';
    ELSE
      V_MESSAGE := 'SUCCESS';
    END IF;
    RETURN V_MESSAGE;
  END;

  /*
  *校验营销大类是否有效，是否属于客户
  */
  FUNCTION F_VALIDATE_CUST_ITEM_CLASS(P_ENTITY_ID            NUMBER,
                                      P_CUSTOMER_CODE        VARCHAR2,
                                      P_SALES_MAIN_TYPE_CODE VARCHAR2)
    RETURN VARCHAR2 AS
    V_MESSAGE               VARCHAR2(1000);
    V_SALES_MAIN_TYPE_COUNT NUMBER;
    V_SALES_LOOP_COUNT      NUMBER;
    --获取客户下有效营销大类
    CURSOR C_SALES_MAIN_TYPE IS
      SELECT T2.ITEM_CLASS_ID SALES_MAIN_TYPE_ID,
             T1.SALES_MAIN_TYPE_CODE,
             T1.SALES_MAIN_TYPE_NAME
        FROM T_CUSTOMER_SALES_MAIN_TYPE T1, T_BD_ITEM_CLASS T2
       WHERE T1.SALES_MAIN_TYPE_CODE = T2.CLASS_CODE
         AND T1.ENTITY_ID = T2.ENTITY_ID
         AND T1.ACTIVE_FLAG = 'Active'
         AND T2.ACTIVE_FLAG = 'Y'
         AND T1.ENTITY_ID = P_ENTITY_ID
         AND T1.CUSTOM_CODE = P_CUSTOMER_CODE;
    SALES_MAIN_TYPE_ROW C_SALES_MAIN_TYPE%ROWTYPE; --有效营销大类游标行数据
  BEGIN
    SELECT COUNT(*)
      INTO V_SALES_MAIN_TYPE_COUNT
      FROM T_CUSTOMER_SALES_MAIN_TYPE T1, T_BD_ITEM_CLASS T2
     WHERE T1.SALES_MAIN_TYPE_CODE = T2.CLASS_CODE
       AND T1.ENTITY_ID = T2.ENTITY_ID
       AND T1.ACTIVE_FLAG = 'Active'
       AND T2.ACTIVE_FLAG = 'Y'
       AND T1.ENTITY_ID = P_ENTITY_ID
       AND T1.CUSTOM_CODE = P_CUSTOMER_CODE;

    IF V_SALES_MAIN_TYPE_COUNT > 0 THEN
      --判断营销大类是否有效，是否属于收款的客户
      V_SALES_LOOP_COUNT := 0;
      FOR SALES_MAIN_TYPE_ROW IN C_SALES_MAIN_TYPE LOOP
        V_SALES_LOOP_COUNT := V_SALES_LOOP_COUNT + 1;
        IF P_SALES_MAIN_TYPE_CODE =
           SALES_MAIN_TYPE_ROW.SALES_MAIN_TYPE_CODE THEN
          V_MESSAGE := 'SUCCESS';
          EXIT;
        ELSE
          IF V_SALES_LOOP_COUNT = V_SALES_MAIN_TYPE_COUNT THEN
            V_MESSAGE := '营销大类（' || P_SALES_MAIN_TYPE_CODE ||
                         '）不是有效的或不属于客户（' || P_CUSTOMER_CODE || '）';
          END IF;
        END IF;
      END LOOP;
    ELSE
      V_MESSAGE := '客户（' || P_CUSTOMER_CODE || '）下的营销大类为空或无效';
    END IF;
    RETURN V_MESSAGE;
  END;

  /*
  *校验主体-OU是否一一对应
  */
  FUNCTION F_VALIDATE_ENTITY_OU(P_ENTITY_ID NUMBER, P_ERP_OU_ID NUMBER)
    RETURN VARCHAR2 AS
    V_MESSAGE  VARCHAR2(1000);
    V_OU_COUNT NUMBER;
  BEGIN
    SELECT COUNT(ID)
      INTO V_OU_COUNT
      FROM CIMS.V_UP_CODELIST V
     WHERE V.CODETYPE = 'ar_ou_id'
       AND V.ENTITY_ID = P_ENTITY_ID
       AND V.CODE_VALUE = P_ERP_OU_ID;
    IF V_OU_COUNT <> 1 THEN
      V_MESSAGE := '根据ERP_OU（' || P_ERP_OU_ID || '）和主体（' || P_ENTITY_ID ||
                   '）没有一一对应';
    ELSE
      V_MESSAGE := 'SUCCESS';
    END IF;
    RETURN V_MESSAGE;
  END;

  /*
  *校验主体-收款方法/转款方法是否一一对应,配置是否正确
  */
  FUNCTION F_VALIDATE_ENTITY_METHOD(P_ENTITY_ID     NUMBER,
                                    P_METHOD_ID     NUMBER,
                                    P_BUSINESS_TYPE VARCHAR2,
                                    P_IN_ENTITY_ID  NUMBER) RETURN VARCHAR2 AS
    V_MESSAGE                    VARCHAR2(1000);
    V_METHOD                     NUMBER; --收款方法ID
    V_METHOD_NAME                T_AR_RECEIPT_METHODS.RECEIPT_METHOD_NAME%TYPE; --收款方法名称
    V_INTO_BAN_FLAG              T_AR_RECEIPT_METHODS.INTO_ERP_FLAG%TYPE; --是否引入资金
    V_PAY_MENT_MODE              T_AR_RECEIPT_METHODS.PAY_MENT_MODE%TYPE; --资金结算方式
    V_INTO_ERP_FLAG              T_AR_RECEIPT_METHODS.INTO_ERP_FLAG%TYPE; --是否引入ERP
    V_ERP_HANDLE                 T_AR_RECEIPT_METHODS.ERP_HANDLE%TYPE; --引入ERP方式
    V_ERP_RECEIPT_METHOD_NAME    T_AR_RECEIPT_METHODS.ERP_RECEIPT_METHOD_NAME%TYPE; --ERP收款方法名称
    V_ERP_AR_NAME                T_AR_RECEIPT_METHODS.ERP_AR_NAME%TYPE; --AR事物处理类型
    V_BUSINESS_TYPE              T_AR_RECEIPT_METHODS.BUSINESS_TYPE%TYPE; --业务分类
    V_IN_TURNFEE_NAME            T_AR_RECEIPT_METHODS.IN_TURNFEE_NAME%TYPE; --转款转入方法名称
    V_OUT_TURNFEE_NAME           T_AR_RECEIPT_METHODS.OUT_TURNFEE_NAME%TYPE; --转款转出方法名称
    V_IN_INTO_BAN_FLAG           T_AR_RECEIPT_METHODS.INTO_BAN_FLAG%TYPE; --转款转入-引资金标志
    V_IN_INTO_ERP_FLAG           T_AR_RECEIPT_METHODS.INTO_ERP_FLAG%TYPE; --转款转入-引ERP标志
    V_IN_ERP_HANDLE              T_AR_RECEIPT_METHODS.ERP_HANDLE%TYPE; --转款转入-引入ERP方式
    V_IN_ERP_RECEIPT_METHOD_NAME T_AR_RECEIPT_METHODS.ERP_RECEIPT_METHOD_NAME%TYPE; --转款转入-ERP收款方法名称
    V_OUT_INTO_BAN_FLAG          T_AR_RECEIPT_METHODS.INTO_BAN_FLAG%TYPE; --转款转出-引资金标志
    V_OUT_INTO_ERP_FLAG          T_AR_RECEIPT_METHODS.INTO_ERP_FLAG%TYPE; --转款转出-引ERP标志
    V_OUT_ERP_HANDLE             T_AR_RECEIPT_METHODS.ERP_HANDLE%TYPE; --转款转出-引入ERP方式
    V_OUT_ERP_AR_NAME            T_AR_RECEIPT_METHODS.ERP_AR_NAME%TYPE; --转款转出-引入ERP方式

  BEGIN
    BEGIN
      SELECT M.RECEIPT_METHOD_ID,
             M.RECEIPT_METHOD_NAME,
             M.INTO_BAN_FLAG,
             M.PAY_MENT_MODE,
             M.INTO_ERP_FLAG,
             M.ERP_HANDLE,
             M.ERP_RECEIPT_METHOD_NAME,
             M.ERP_AR_NAME,
             M.BUSINESS_TYPE,
             M.IN_TURNFEE_NAME,
             M.OUT_TURNFEE_NAME
        INTO V_METHOD,
             V_METHOD_NAME,
             V_INTO_BAN_FLAG,
             V_PAY_MENT_MODE,
             V_INTO_ERP_FLAG,
             V_ERP_HANDLE,
             V_ERP_RECEIPT_METHOD_NAME,
             V_ERP_AR_NAME,
             V_BUSINESS_TYPE,
             V_IN_TURNFEE_NAME,
             V_OUT_TURNFEE_NAME
        FROM CIMS.T_AR_RECEIPT_METHODS M
       WHERE M.RECEIPT_METHOD_ID = P_METHOD_ID
         AND M.BUSINESS_TYPE = P_BUSINESS_TYPE
         AND M.ENTITY_ID = P_ENTITY_ID;
    EXCEPTION
      WHEN OTHERS THEN
        V_MESSAGE := '收款方法（RECEIPT_METHOD_ID=' || P_METHOD_ID ||
                     '）数据异常，请联系管理员';
        RETURN V_MESSAGE;
    END;

    IF V_METHOD IS NULL THEN
      V_MESSAGE := '收款方法（' || P_METHOD_ID || '）、主体（' || P_ENTITY_ID ||
                   '）、业务分类（' || P_BUSINESS_TYPE || '）没有对应';
    ELSE
      --引入资金
      IF V_INTO_BAN_FLAG = 'Y' AND V_PAY_MENT_MODE IS NULL THEN
        V_MESSAGE := '收款方法' || V_METHOD_NAME || '配置：引入资金，资金结算方式不能为空';
      ELSE
        V_MESSAGE := 'SUCCESS';
      END IF;
      --引入ERP
      IF V_INTO_ERP_FLAG = 'Y' THEN
        IF V_ERP_HANDLE IS NULL THEN
          V_MESSAGE := '收款方法' || V_METHOD_NAME || '配置：引入ERP，ERP处理方式不能为空';
        ELSIF V_ERP_HANDLE = '1' AND V_ERP_RECEIPT_METHOD_NAME IS NULL THEN
          V_MESSAGE := '收款方法' || V_METHOD_NAME ||
                       '配置：引入ERP，ERP处理方式为收款，ERP收款方法不能为空';
        ELSIF V_ERP_HANDLE = '2' AND V_ERP_AR_NAME IS NULL THEN
          V_MESSAGE := '收款方法' || V_METHOD_NAME ||
                       '配置：引入ERP，ERP处理方式为发票，AR事物处理类型不能为空';
        ELSE
          V_MESSAGE := 'SUCCESS';
        END IF;
      ELSE
        V_MESSAGE := 'SUCCESS';
      END IF;
      --转款校验：转款转入-引ERP收款；转款转出-引ERP AR发票
      IF V_BUSINESS_TYPE = '3' OR V_BUSINESS_TYPE = '6' THEN
        IF V_INTO_BAN_FLAG = 'Y' OR V_INTO_ERP_FLAG = 'Y' THEN
          V_MESSAGE := '转款方法' || V_METHOD_NAME || '(主体=' || P_ENTITY_ID ||
                       ')配置有误，请联系管理员';
        END IF;
        IF V_IN_TURNFEE_NAME IS NOT NULL OR V_OUT_TURNFEE_NAME IS NOT NULL THEN
          --转入
          BEGIN
            SELECT M1.INTO_BAN_FLAG,
                   M1.INTO_ERP_FLAG,
                   M1.ERP_HANDLE,
                   M1.ERP_RECEIPT_METHOD_NAME
              INTO V_IN_INTO_BAN_FLAG,
                   V_IN_INTO_ERP_FLAG,
                   V_IN_ERP_HANDLE,
                   V_IN_ERP_RECEIPT_METHOD_NAME
              FROM CIMS.T_AR_RECEIPT_METHODS M1
             WHERE M1.RECEIPT_METHOD_NAME = V_IN_TURNFEE_NAME
               AND M1.ENTITY_ID =
                   DECODE(P_IN_ENTITY_ID, NULL, P_ENTITY_ID, P_IN_ENTITY_ID);
          EXCEPTION
            WHEN OTHERS THEN
              V_MESSAGE := '转款方法（' || V_METHOD_NAME ||
                           '）对应的转款-转入/转出方法数据异常，请联系管理员';
              RETURN V_MESSAGE;
          END;
          --转出
          BEGIN
            SELECT M2.INTO_BAN_FLAG,
                   M2.INTO_ERP_FLAG,
                   M2.ERP_HANDLE,
                   M2.ERP_AR_NAME
              INTO V_OUT_INTO_BAN_FLAG,
                   V_OUT_INTO_ERP_FLAG,
                   V_OUT_ERP_HANDLE,
                   V_OUT_ERP_AR_NAME
              FROM CIMS.T_AR_RECEIPT_METHODS M2
             WHERE M2.RECEIPT_METHOD_NAME = V_OUT_TURNFEE_NAME
               AND M2.ENTITY_ID = P_ENTITY_ID;
          EXCEPTION
            WHEN OTHERS THEN
              V_MESSAGE := '收款方法（RECEIPT_METHOD_ID=' || P_METHOD_ID ||
                           '）对应的转款-转入/转出方法数据异常，请联系管理员';
              RETURN V_MESSAGE;
          END;
          IF V_IN_INTO_BAN_FLAG = 'Y' OR V_OUT_INTO_BAN_FLAG = 'Y' THEN
            V_MESSAGE := '收款方法（' || V_METHOD_NAME ||
                         '）配置有误：转款、跨主体转款、跨OU转款业务不引资金';
          ELSIF TRUE <> (V_IN_INTO_ERP_FLAG = 'Y' AND V_IN_ERP_HANDLE = '1' AND
                V_IN_ERP_RECEIPT_METHOD_NAME IS NOT NULL) THEN
            V_MESSAGE := '收款方法（' || V_IN_TURNFEE_NAME ||
                         '）配置有误：转款-转入业务引ERP收款';
          ELSIF TRUE <>
                (V_OUT_INTO_ERP_FLAG = 'Y' AND V_OUT_ERP_HANDLE = '2' AND
                V_OUT_ERP_AR_NAME IS NOT NULL) THEN
            V_MESSAGE := '收款方法（' || V_IN_TURNFEE_NAME ||
                         '）配置有误：转款-转出业务引ERPAR发票';
          ELSE
            V_MESSAGE := 'SUCCESS';
          END IF;
        END IF;
      END IF;
    END IF;
    RETURN V_MESSAGE;
  END;

  /*
  * 校验附件是否上传
  */
  FUNCTION F_VALIDATE_APPENDIX(P_RECEIPT_METHOD_ID IN NUMBER,
                               P_APPENDIX_ID       IN VARCHAR2)
    RETURN VARCHAR2 AS

    V_APPENDIX_FLAG  VARCHAR2(32); --附件上传标志
    V_APPENDIX_COUNT NUMBER; --附件数据总数
    V_MESSAGE        VARCHAR2(1000);
  BEGIN
    V_MESSAGE := 'SUCCESS';

    SELECT TM.APPENDIX_FLAG
      INTO V_APPENDIX_FLAG
      FROM CIMS.T_AR_RECEIPT_METHODS TM
     WHERE TM.RECEIPT_METHOD_ID = P_RECEIPT_METHOD_ID;

    IF V_APPENDIX_FLAG = 'Y' THEN
      SELECT COUNT(*)
        INTO V_APPENDIX_COUNT
        FROM CIMS.MDP_BUSINESS_FILE M
       WHERE M.BUSINESS_ID = P_APPENDIX_ID;
      IF V_APPENDIX_COUNT = 0 THEN
        V_MESSAGE := '必须上传附件';
      END IF;
    END IF;
    RETURN V_MESSAGE;
  END;

  /*
  * 校验ERP收款方银行账户
  */
  PROCEDURE P_VALIDATE_ERP_RECEIPT_BANK(P_ERP_OU_ID               IN NUMBER, --ERP_OU_ID
                                        P_ERP_RECEIPT_METHOD_NAME IN VARCHAR2, --ERP收款方法名称
                                        P_BANK_ACCOUNT_NAME       IN VARCHAR2, --ATTRIBUTE7   账户
                                        P_BANK_ACCOUNT_CODE       IN VARCHAR2, --ATTRIBUTE13  账号
                                        P_CODE_LEN                IN VARCHAR2, --票据号长度
                                        P_RECEIPT_ENTRY_CODE      IN VARCHAR2, --是否可录入
                                        P_INTO_FLAG               IN VARCHAR2, --引入ERP/资金标志
                                        P_ERP_RECEIPT_METHOD_ID   OUT NUMBER, --ERP使用
                                        P_ERP_BANK_ACCT_USE_ID    OUT NUMBER, --ERP使用
                                        P_ERP_BANK_ACCTOUNT_ID    OUT NUMBER, --资金使用
                                        P_ERP_BANK_ACCTOUNT_NAME  OUT VARCHAR2, --资金使用
                                        P_MESSAGE                 OUT VARCHAR2 --成功则返回“SUCCESS”，否则返回出错信息
                                        ) IS
    --ERP收款方法信息（ERP、资金都使用）
    CURSOR C_ERP_METHODS IS
      SELECT *
        FROM CIMS.INTF_AR_RECEIPT_METHOD
       WHERE RECEIPT_METHOD_NAME = P_ERP_RECEIPT_METHOD_NAME
         AND ORG_ID = P_ERP_OU_ID
         AND BANK_ACCOUNT_NAME =
            --ATTRIBUTE7电汇收款-银行账户名称 ，不为空时，判断是否为电汇/电票
             DECODE(P_BANK_ACCOUNT_NAME,
                    NULL,
                    BANK_ACCOUNT_NAME,
                    --不可录入（资金过来的电票/电汇、转款/跨主体转款生成的收款单、IMS/EMS过来的单据）
                    DECODE(P_RECEIPT_ENTRY_CODE,
                           --票据号长度为0，电汇
                           'N',
                           DECODE(P_CODE_LEN,
                                  0,
                                  P_BANK_ACCOUNT_NAME,
                                  BANK_ACCOUNT_NAME),
                           BANK_ACCOUNT_NAME)) 
           AND BANK_ACCOUNT =
            --ATTRIBUTE7电汇收款-银行账户名称 ，不为空时，判断是否为电汇/电票
             DECODE(P_BANK_ACCOUNT_CODE,
                    NULL,
                    BANK_ACCOUNT,
                    --不可录入（资金过来的电票/电汇、转款/跨主体转款生成的收款单、IMS/EMS过来的单据）
                    DECODE(P_RECEIPT_ENTRY_CODE,
                           --票据号长度为0，电汇
                           'N',
                           DECODE(P_CODE_LEN,
                                  0,
                                  P_BANK_ACCOUNT_CODE,
                                  BANK_ACCOUNT),
                           BANK_ACCOUNT));
    ERP_METHODS_ROW C_ERP_METHODS%ROWTYPE; --ERP收款方法信息行数据
    V_ERP_COUNT     NUMBER;
  BEGIN
    P_MESSAGE   := 'SUCCESS';
    V_ERP_COUNT := 0;
    FOR ERP_METHODS_ROW IN C_ERP_METHODS LOOP
      V_ERP_COUNT              := V_ERP_COUNT + 1;
      P_ERP_RECEIPT_METHOD_ID  := ERP_METHODS_ROW.RECEIPT_METHOD_ID;
      P_ERP_BANK_ACCT_USE_ID   := ERP_METHODS_ROW.REMIT_BANK_ACCT_USE_ID;
      P_ERP_BANK_ACCTOUNT_ID   := ERP_METHODS_ROW.BANK_ACCOUNT_ID;
      P_ERP_BANK_ACCTOUNT_NAME := ERP_METHODS_ROW.BANK_ACCOUNT_NAME;
    END LOOP;
    IF V_ERP_COUNT > 1 AND P_BANK_ACCOUNT_NAME IS NOT NULL THEN
      P_MESSAGE := '根据收款方法（' || P_ERP_RECEIPT_METHOD_NAME || '）、OU(' ||
                   P_ERP_OU_ID || ')、银行账户名称（' || P_BANK_ACCOUNT_NAME ||
                   '），获取到多个ERP收款方银行账号';
    ELSIF V_ERP_COUNT < 1 AND P_BANK_ACCOUNT_NAME IS NOT NULL THEN
      P_MESSAGE := '根据收款方法（' || P_ERP_RECEIPT_METHOD_NAME || '）、OU(' ||
                   P_ERP_OU_ID || ')、银行账户名称（' || P_BANK_ACCOUNT_NAME ||
                   '），获取不到ERP收款方银行账号';
    ELSIF V_ERP_COUNT > 1 AND P_BANK_ACCOUNT_NAME IS NULL THEN
      P_MESSAGE := '根据收款方法（' || P_ERP_RECEIPT_METHOD_NAME || '）、OU(' ||
                   P_ERP_OU_ID || ') ，获取到多个ERP收款方银行账号';
    ELSIF V_ERP_COUNT < 1 AND P_BANK_ACCOUNT_NAME IS NULL THEN
      P_MESSAGE := '根据收款方法（' || P_ERP_RECEIPT_METHOD_NAME || '）、OU(' ||
                   P_ERP_OU_ID || ')，获取不到ERP收款方银行账号';
    ELSE
      IF P_INTO_FLAG = 'erp' THEN
        IF P_ERP_RECEIPT_METHOD_ID IS NULL OR
           P_ERP_BANK_ACCT_USE_ID IS NULL THEN
          P_MESSAGE := 'ERP收款方银行账号ID和ERP收款方法ID不能为空';
        END IF;
      ELSIF P_INTO_FLAG = 'gtsp' THEN
        IF P_ERP_RECEIPT_METHOD_ID IS NULL OR
           P_ERP_BANK_ACCTOUNT_ID IS NULL OR
           P_ERP_BANK_ACCTOUNT_NAME IS NULL THEN
          P_MESSAGE := 'ERP收款方银行账号ID、收款方银行账户名称、ERP收款方法ID不能为空';
        END IF;
      ELSE
        IF P_ERP_RECEIPT_METHOD_ID IS NULL OR
           P_ERP_BANK_ACCT_USE_ID IS NULL OR P_ERP_BANK_ACCTOUNT_ID IS NULL OR
           P_ERP_BANK_ACCTOUNT_NAME IS NULL THEN
          P_MESSAGE := 'ERP收款方银行账号ID、收款方银行账户名称、ERP收款方法ID不能为空';
        END IF;
      END IF;
    END IF;
  END;

  /*
  * 校验客户银行账户
  */
  PROCEDURE P_VALIDATE_CUSTOMER_BANK(P_ENTITY_ID         IN NUMBER,
                                     P_CUSTOMER_ID       IN NUMBER,
                                     P_CUST_BANK_ACCOUNT OUT VARCHAR2,
                                     P_CUST_BANK         OUT VARCHAR2,
                                     P_MESSAGE           OUT VARCHAR2) IS
    --客户银行信息（资金使用）
    CURSOR C_CUSTOM_BANKS IS
      SELECT T.*
        FROM CIMS.T_CUSTOMER_BANK T
       WHERE T.CUSTOMER_ID = P_CUSTOMER_ID
         AND T.ENTITY_ID = P_ENTITY_ID
         AND T.ACTIVE_FLAG = 'Active'
       ORDER BY T.SSA_PRIMARY_FIELD DESC;

    CUSTOM_BANKS_ROW C_CUSTOM_BANKS%ROWTYPE; --客户银行信息行数据
    V_CUS_BANK_COUNT NUMBER; --客户银行信息
  BEGIN
    V_CUS_BANK_COUNT := 0;
    FOR CUSTOM_BANKS_ROW IN C_CUSTOM_BANKS LOOP
      V_CUS_BANK_COUNT := V_CUS_BANK_COUNT + 1;
      --客户银行账号和名称
      IF CUSTOM_BANKS_ROW.BANK IS NOT NULL AND
         CUSTOM_BANKS_ROW.BANK_ACCOUNT IS NOT NULL THEN
        P_CUST_BANK_ACCOUNT := CUSTOM_BANKS_ROW.BANK_ACCOUNT;
        P_CUST_BANK         := CUSTOM_BANKS_ROW.BANK;
        P_MESSAGE           := 'SUCCESS';
        EXIT;
      END IF;
    END LOOP;
    IF V_CUS_BANK_COUNT < 1 THEN
      P_MESSAGE := '根据客户（' || P_CUSTOMER_ID || '）获取不到的客户银行';
    END IF;
  END;

  /*
  * 收款单确认校验
  *校验：ERP收款方银行账户、客户银行、账套ID
  */
  PROCEDURE P_VALIDATE_RECEIPT_CONFIRM(P_ENTITY_ID               IN T_AR_CASH_RECEIPT_HEADERS.ENTITY_ID%TYPE, --主体ID（收款单）
                                       P_CUSTOMER_ID             IN T_AR_CASH_RECEIPT_HEADERS.CUSTOMER_ID%TYPE, --客户ID（收款单）
                                       P_ERP_OU_ID               IN T_AR_CASH_RECEIPT_HEADERS.ERP_OU_ID%TYPE, --ERP_OU_ID
                                       P_CASH_CODE_LENGTH        IN T_AR_RECEIPT_METHODS.CASH_CODE_LENGTH%TYPE, --票据号长度（收款方法）
                                       P_RECEIPT_ENTRY_CODE      IN T_AR_RECEIPT_METHODS.RECEIPT_ENTRY_CODE%TYPE, --是否可录入（收款方法）
                                       P_INTO_ERP_FLAG           IN T_AR_RECEIPT_METHODS.INTO_ERP_FLAG%TYPE, --引入ERP标志（收款方法）
                                       P_INTO_BAN_FLAG           IN T_AR_RECEIPT_METHODS.INTO_BAN_FLAG%TYPE, --引入资金标志（收款方法）
                                       P_ERP_HANDLE              IN T_AR_RECEIPT_METHODS.ERP_HANDLE%TYPE, --引入ERP方式：发票、收款（收款方法）
                                       P_ERP_RECEIPT_METHOD_NAME IN T_AR_RECEIPT_METHODS.ERP_RECEIPT_METHOD_NAME%TYPE, --ERP收款方法名称（收款方法）
                                       P_ATTRIBUTE7              IN T_AR_CASH_RECEIPT_HEADERS.ATTRIBUTE7%TYPE, --ERP收款方银行账户名称（资金使用，对应收款单ATTRIBUTE7）
                                       P_BANK_ACCOUNT_CODE       IN VARCHAR2, --ATTRIBUTE13  账号
                                       P_REFUND_APPLY_ID         IN NUMBER,
                                       P_ERP_RECEIPT_METHOD_ID   OUT T_AR_RECEIPT_METHODS.ERP_RECEIPT_METHOD_ID%TYPE, --ERP收款方法ID（ERP使用）
                                       P_ERP_BANK_ACCT_USE_ID    OUT INTF_AR_RECEIPT_METHOD.REMIT_BANK_ACCT_USE_ID%TYPE, --ERP收款方银行账户ID（ERP使用）
                                       P_ERP_BANK_ACCOUNT_ID     OUT INTF_AR_RECEIPT_METHOD.BANK_ACCOUNT_ID%TYPE, --收款方银行账户ID（资金使用）
                                       P_ERP_BANK_ACCOUNT_NAME   OUT INTF_AR_RECEIPT_METHOD.BANK_ACCOUNT_NAME%TYPE, --ERP收款方银行账户名称（资金使用，对应收款单ATTRIBUTE7）
                                       P_CUST_BANK_ACCOUNT       OUT T_CUSTOMER_BANK.BANK_ACCOUNT%TYPE, --客户银行账户（资金使用）
                                       P_CUST_BANK               OUT T_CUSTOMER_BANK.BANK%TYPE, --客户银行名称  （资金使用）
                                       P_SET_OUT_ID              OUT T_INV_ORGANIZATION.SET_OF_BOOKS_ID%TYPE, --账套ID   （ERP发票使用）
                                       P_MESSAGE                 OUT VARCHAR2) IS
    V_INTO_FLAG VARCHAR2(10); --引入系统标志（ERP、GTSP、ERPGTSP）
  BEGIN
    P_MESSAGE := 'SUCCESS';
    --引ERP收款，引资金
    IF P_INTO_ERP_FLAG = 'Y' AND P_ERP_HANDLE = '1' AND
       P_INTO_BAN_FLAG = 'Y' THEN
      V_INTO_FLAG := 'erpgtsp';
      --引ERP收款，不引资金
    ELSIF P_INTO_ERP_FLAG = 'Y' AND P_ERP_HANDLE = '1' AND
          P_INTO_BAN_FLAG <> 'Y' THEN
      V_INTO_FLAG := 'erp';
      --引资金，不引ERP收款
    ELSIF ((P_INTO_ERP_FLAG = 'Y' AND P_ERP_HANDLE <> '1') OR
          P_INTO_ERP_FLAG <> 'Y') AND P_INTO_BAN_FLAG = 'Y' THEN
      V_INTO_FLAG := 'gtsp';
    END IF;
    
    --引ERP收款检查ERP收款方法对应的银行账户
    IF V_INTO_FLAG IS NOT NULL AND  P_ERP_HANDLE = '1'  THEN
      --引ERP/资金，校验ERP收款方银行
      P_VALIDATE_ERP_RECEIPT_BANK(P_ERP_OU_ID,
                                  P_ERP_RECEIPT_METHOD_NAME,
                                  P_ATTRIBUTE7,
                                  P_BANK_ACCOUNT_CODE,
                                  P_CASH_CODE_LENGTH,
                                  P_RECEIPT_ENTRY_CODE,
                                  V_INTO_FLAG,
                                  P_ERP_RECEIPT_METHOD_ID,
                                  P_ERP_BANK_ACCT_USE_ID,
                                  P_ERP_BANK_ACCOUNT_ID,
                                  P_ERP_BANK_ACCOUNT_NAME,
                                  P_MESSAGE);
    END IF;
    --引ERP发票，校验账套ID
    IF P_MESSAGE = 'SUCCESS' AND P_INTO_ERP_FLAG = 'Y' AND
       P_ERP_HANDLE = '2' THEN
      P_GET_SET_BOOK_ID(P_ERP_OU_ID, P_SET_OUT_ID, P_MESSAGE);
    END IF;
    --引资金，校验客户银行
    IF P_MESSAGE = 'SUCCESS' AND P_INTO_BAN_FLAG = 'Y' AND P_REFUND_APPLY_ID IS NOT NULL THEN
      P_VALIDATE_CUSTOMER_BANK(P_ENTITY_ID,
                               P_CUSTOMER_ID,
                               P_CUST_BANK_ACCOUNT,
                               P_CUST_BANK,
                               P_MESSAGE);
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_AUTO_CONFIRM.P_VALIDATE_CONFIRM',
                                          SQLCODE,
                                          SUBSTR(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE,
                                                 1,
                                                 100) || SQLERRM);
  END;

  /*
  * 获取账套ID
  */
  PROCEDURE P_GET_SET_BOOK_ID(P_ERP_OU_ID NUMBER,
                              P_BOOK_ID   OUT NUMBER,
                              P_MESSAGE   OUT VARCHAR2) IS
  BEGIN
    SELECT DISTINCT SET_OF_BOOKS_ID
      INTO P_BOOK_ID
      FROM T_INV_ORGANIZATION
     WHERE OPERATING_UNIT = P_ERP_OU_ID;
    IF P_BOOK_ID IS NULL THEN
      P_MESSAGE := '根据ERP_OU（' || P_ERP_OU_ID || '）获取不到账套ID，请联系管理员';
    ELSE
      P_MESSAGE := 'SUCCESS';
    END IF;
  END;

  /*
  * 收款单引入ERP收款接口表
  */
  PROCEDURE P_INSERT_ERP_RECEIPT(P_CASH_RECEIPT_ID       IN NUMBER, --收款头ID
                                 P_ERP_RECEIPT_METHOD_ID IN NUMBER, --ERP收款方法ID
                                 P_ERP_BANK_ACCT_USE_ID  IN NUMBER, --ERP收款方银行账户ID
                                 P_MESSAGE               OUT VARCHAR2 --成功则返回“SUCCESS”，否则返回出错信息
                                 ) IS
    --收款头、收款方法
    CURSOR C_RECEIPT_HEADERS IS
      SELECT TH.*,
             T.RECEIPT_METHOD_NAME,
             NVL(T.RECEIPT_ENTRY_CODE, 'N') RECEIPT_ENTRY_CODE,
             NVL(T.RECEIPT_CLASS_CODE, 'N') RECEIPT_CLASS_CODE,
             NVL(T.INTO_ERP_FLAG, 'N') INTO_ERP_FLAG,
             NVL(T.INTO_BAN_FLAG, 'N') INTO_BAN_FLAG,
             T.TYPE METHOD_TYPE,
             NVL(T.IS_EFFECTIVE, 'N') IS_EFFECTIVE,
             T.RECEIPT_TYPE,
             T.BUSINESS_TYPE,
             T.CASH_CODE_LENGTH,
             T.ERP_RECEIPT_METHOD_ID,
             T.PAY_MENT_MODE,
             T.ERP_HANDLE,
             T.CASH_DATE_TERM,
             T.RECEIPT_REQUIRE,
             T.ERP_AR_ID,
             T.ERP_RECEIPT_METHOD_NAME,
             T.ERP_AR_NAME
        FROM CIMS.T_AR_CASH_RECEIPT_HEADERS TH, CIMS.T_AR_RECEIPT_METHODS T
       WHERE TH.RECEIPT_STATUS_ID = '3'
         AND TH.CASH_RECEIPT_ID = P_CASH_RECEIPT_ID
         AND TH.RECEIPT_METHOD_ID = T.RECEIPT_METHOD_ID
            --AND T.BUSINESS_TYPE IN ('1', '4', '5')
         AND NVL(T.INTO_ERP_FLAG, 'N') = 'Y'
         AND NVL(T.IS_EFFECTIVE, 'N') = 'Y'
         AND T.ERP_HANDLE = '1'
         AND T.ERP_RECEIPT_METHOD_NAME IS NOT NULL;
    HEAD_ROW C_RECEIPT_HEADERS%ROWTYPE; --收款头游标行数据
    V_COUNT  NUMBER;
    V_RELATED_TRANSACTION_NO VARCHAR2(200);
  BEGIN
    P_MESSAGE := 'SUCCESS';
    BEGIN
      SELECT COUNT(TH.CASH_RECEIPT_ID)
        INTO V_COUNT
        FROM CIMS.T_AR_CASH_RECEIPT_HEADERS TH, CIMS.T_AR_RECEIPT_METHODS T
       WHERE TH.RECEIPT_STATUS_ID = '3'
         AND TH.CASH_RECEIPT_ID = P_CASH_RECEIPT_ID
         AND TH.RECEIPT_METHOD_ID = T.RECEIPT_METHOD_ID
            --AND T.BUSINESS_TYPE IN ('1', '4', '5')
         AND NVL(T.INTO_ERP_FLAG, 'N') = 'Y'
         AND NVL(T.IS_EFFECTIVE, 'N') = 'Y'
         AND T.ERP_HANDLE = '1'
         AND T.ERP_RECEIPT_METHOD_NAME IS NOT NULL;
    END;
    V_COUNT := 0;
    FOR HEAD_ROW IN C_RECEIPT_HEADERS LOOP
      V_COUNT := V_COUNT + 1;
     
      IF HEAD_ROW.Attribute3='ECM' THEN
         V_RELATED_TRANSACTION_NO := HEAD_ROW.Attribute14;
      ELSE
         V_RELATED_TRANSACTION_NO := HEAD_ROW.ATTRIBUTE4;
      END IF;
      
      INSERT INTO INTF_AR_CASH_RECEIPT
        (
         --主键
         TRX_ID,
         --单据日期
         RECEIPT_DATE,
         --OU_ID
         ORG_ID,
         --接口状态，固定写N
         INTF_STATUS,
         --币种
         CURRENCY_CODE,
         --金额
         AMOUNT,
         --收款单据编号
         RECEIPT_NUMBER,
         --来源编号（填收款单据编号）
         SOURCE_NUM,
         --总账日期
         GL_DATE,
         --票据到期日期
         MATURITY_DATE,
         --客户编码
         CUSTOMER_NUMBER,
         --ERP收款方法ID
         RECEIPT_METHOD_ID,
         --收款方银行账户ID
         REMITTANCE_BANK_ACCOUNT_ID,
         --固定写CREATE_CASH
         CALLING_API,
         --备注
         COMMENTS,
         --票据号
         ATTRIBUTE1,
         --收款来源，固定写IMS
         ATTRIBUTE2,
         --出纳流水号（资金回单号）
         ATTRIBUTE9,
         --来源单号
         ATTRIBUTE11,
         --关联交易号
         ATTRIBUTE10,
         --预算项目
         ATTRIBUTE4
         )
      VALUES
        (S_INTF_AR_CASH_RECEIPT.NEXTVAL,
         HEAD_ROW.CASH_RECEIPT_DATE,
         HEAD_ROW.ERP_OU_ID,
         'N',
         HEAD_ROW.CURRENCY_CODE,
         HEAD_ROW.AMOUNT,
         HEAD_ROW.CASH_RECEIPT_CODE,
         HEAD_ROW.CASH_RECEIPT_CODE,
         HEAD_ROW.GL_DATE,
         HEAD_ROW.DUE_DATE,
         HEAD_ROW.CUSTOMER_CODE,
         P_ERP_RECEIPT_METHOD_ID,
         P_ERP_BANK_ACCT_USE_ID,
         'CREATE_CASH',
         HEAD_ROW.REMAEK,
         HEAD_ROW.CASH_CODE,
         HEAD_ROW.ATTRIBUTE3,
         HEAD_ROW.GTMS_RECEIPT_CODE,
         V_RELATED_TRANSACTION_NO,
         HEAD_ROW.ATTRIBUTE9,
         HEAD_ROW.Budget_Item_Name
         );
    END LOOP;
    IF V_COUNT = 0 THEN
      P_MESSAGE := '获取不到收款单数据，请联系管理员';
      RAISE V_BIZ_EXCEPTION;
    END IF;
  EXCEPTION
    WHEN V_BIZ_EXCEPTION THEN
      P_MESSAGE := '引入ERP失败：' || P_MESSAGE;
    WHEN OTHERS THEN
      P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_BOND.P_INSERT_ERP_RECEIPT',
                                          SQLCODE,
                                          P_MESSAGE || SQLERRM);
  END;

  /*
  * 收款单引入AR发票接口表
  */
  PROCEDURE P_INSERT_AR_INVOICE(P_CASH_RECEIPT_ID IN NUMBER, --收款头ID
                                P_SET_OF_BOOKS_ID IN NUMBER, --账套ID
                                P_MESSAGE         OUT VARCHAR2 --成功则返回“SUCCESS”，否则返回出错信息
                                ) IS
    --收款头、收款方法
    CURSOR C_RECEIPT_HEADERS IS
      SELECT TH.*,
             T.RECEIPT_METHOD_NAME,
             NVL(T.RECEIPT_ENTRY_CODE, 'N') RECEIPT_ENTRY_CODE,
             NVL(T.RECEIPT_CLASS_CODE, 'N') RECEIPT_CLASS_CODE,
             NVL(T.INTO_ERP_FLAG, 'N') INTO_ERP_FLAG,
             NVL(T.INTO_BAN_FLAG, 'N') INTO_BAN_FLAG,
             T.TYPE METHOD_TYPE,
             NVL(T.IS_EFFECTIVE, 'N') IS_EFFECTIVE,
             T.RECEIPT_TYPE,
             T.BUSINESS_TYPE,
             T.CASH_CODE_LENGTH,
             T.ERP_RECEIPT_METHOD_ID,
             T.PAY_MENT_MODE,
             T.ERP_HANDLE,
             T.CASH_DATE_TERM,
             T.RECEIPT_REQUIRE,
             T.ERP_AR_ID,
             T.ERP_RECEIPT_METHOD_NAME,
             T.ERP_AR_NAME
        FROM CIMS.T_AR_CASH_RECEIPT_HEADERS TH, CIMS.T_AR_RECEIPT_METHODS T
       WHERE TH.RECEIPT_STATUS_ID = '3'
         AND TH.CASH_RECEIPT_ID = P_CASH_RECEIPT_ID
         AND TH.RECEIPT_METHOD_ID = T.RECEIPT_METHOD_ID
            --AND T.BUSINESS_TYPE IN ('1', '4', '5')
         AND NVL(T.INTO_ERP_FLAG, 'N') = 'Y'
         AND NVL(T.IS_EFFECTIVE, 'N') = 'Y'
         AND T.ERP_HANDLE = '2'
         AND T.ERP_AR_NAME IS NOT NULL;
    HEAD_ROW   C_RECEIPT_HEADERS%ROWTYPE; --收款头游标行数据
    V_AR_COUNT NUMBER;
    V_RELATED_TRANSACTION_NO VARCHAR2(200);
  BEGIN
    P_MESSAGE  := 'SUCCESS';
    V_AR_COUNT := 0;
    FOR HEAD_ROW IN C_RECEIPT_HEADERS LOOP
      V_AR_COUNT := V_AR_COUNT + 1;
      
      IF HEAD_ROW.Attribute3='ECM' THEN
         V_RELATED_TRANSACTION_NO := HEAD_ROW.Attribute14;
      ELSE
         V_RELATED_TRANSACTION_NO := HEAD_ROW.ATTRIBUTE4;
      END IF;
      
      INSERT INTO INTF_AR_INVOICE
        (TRX_ID,
         INTF_STATUS,
         ORG_ID,
         CUSTOMER_NUMBER,
         CUSTOMER_BILL_TO,
         TERM_NAME,
         SOURCE_NUM,
         SOURCE_LINE_NUM,
         LINE_TYPE,
         DESCRIPTION,
         QUANTITY,
         AMOUNT,
         CUST_TRX_TYPE_NAME,
         CURRENCY_CODE,
         TRX_DATE,
         GL_DATE,
         TRX_NUMBER,
         AGING_DATE,
         COMMENTS,
         REFERENCE,
         BATCH_SOURCE_NAME,
         TAX_RATE_CODE,
         LINE_NUMBER,
         QUANTITY_ORDERED,
         UNIT_SELLING_PRICE,
         UNIT_STANDARD_PRICE,
         ATTRIBUTE6,
         HEADER_ATTRIBUTE6,
         SET_OF_BOOKS_ID,
      --   ATTRIBUTE11,
         HEADER_ATTRIBUTE11  --中转关联交易号
         )
      VALUES
        (S_INTF_AR_INVOICE.NEXTVAL,
         'N',
         HEAD_ROW.ERP_OU_ID,
         HEAD_ROW.CUSTOMER_CODE,
         '默认',
         '立即',
         HEAD_ROW.CASH_RECEIPT_CODE,
         '1',
         'LINE',
         '无',
         1,
         ABS(HEAD_ROW.AMOUNT),
         HEAD_ROW.ERP_AR_NAME,
         'CNY',
         HEAD_ROW.CASH_RECEIPT_DATE,
         HEAD_ROW.GL_DATE,
         HEAD_ROW.CASH_RECEIPT_CODE,
         HEAD_ROW.CASH_RECEIPT_DATE,
         HEAD_ROW.REMAEK,
         HEAD_ROW.CASH_RECEIPT_CODE,
         'IMS非订单导入',
         'VAT0_OUT',
         1,
         1,
         ABS(HEAD_ROW.AMOUNT),
         ABS(HEAD_ROW.AMOUNT),
         TO_CHAR(HEAD_ROW.CASH_RECEIPT_DATE,'yyyy-mm-dd'),
         TO_CHAR(HEAD_ROW.CASH_RECEIPT_DATE,'yyyy-mm-dd'),
         P_SET_OF_BOOKS_ID,
        -- HEAD_ROW.ATTRIBUTE4,
         V_RELATED_TRANSACTION_NO
         );
    END LOOP;
    IF V_AR_COUNT = 0 THEN
      P_MESSAGE := '查询收款单为空';
      RAISE V_BIZ_EXCEPTION;
    END IF;
  EXCEPTION
    WHEN V_BIZ_EXCEPTION THEN
      P_MESSAGE := '引入AR发票失败：' || P_MESSAGE;
    WHEN OTHERS THEN
      P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_BOND.P_INSERT_AR_INVOICE',
                                          SQLCODE,
                                          P_MESSAGE || SQLERRM);
  END;

  /*
  *收款单引入资金接口表，纸票在途登记
  */
  PROCEDURE P_INSERT_GTSP_RECEIPT(P_CASH_RECEIPT_ID       IN NUMBER, --收款头ID
                                  P_CUST_BANK_ACCOUNT     IN VARCHAR2, --客户银行账户
                                  P_CUST_BANK             IN VARCHAR2, --客户银行名称
                                  P_ERP_RECEIPT_METHOD_ID IN NUMBER, --ERP收款方法ID
                                  P_ERP_BANK_ACCOUNT_ID   IN NUMBER, --ERP收款方银行账户ID
                                  P_ERP_BANK_ACCOUNT_NAME IN VARCHAR2, --ERP收款方银行账户名称
                                  P_MESSAGE               OUT VARCHAR2 --成功则返回“SUCCESS”，否则返回出错信息
                                  ) IS
    --收款头表数据
    CURSOR C_RECEIPT_HEAD IS
      SELECT TH.*,
             T.RECEIPT_METHOD_NAME,
             NVL(T.RECEIPT_ENTRY_CODE, 'N') RECEIPT_ENTRY_CODE,
             NVL(T.RECEIPT_CLASS_CODE, 'N') RECEIPT_CLASS_CODE,
             NVL(T.INTO_ERP_FLAG, 'N') INTO_ERP_FLAG,
             NVL(T.INTO_BAN_FLAG, 'N') INTO_BAN_FLAG,
             T.TYPE METHOD_TYPE,
             NVL(T.IS_EFFECTIVE, 'N') IS_EFFECTIVE,
             T.RECEIPT_TYPE,
             T.BUSINESS_TYPE,
             T.CASH_CODE_LENGTH,
             T.ERP_RECEIPT_METHOD_ID,
             T.PAY_MENT_MODE,
             T.ERP_HANDLE,
             T.CASH_DATE_TERM,
             T.RECEIPT_REQUIRE,
             T.ERP_AR_ID,
             T.ERP_RECEIPT_METHOD_NAME,
             T.ERP_AR_NAME
        FROM CIMS.T_AR_CASH_RECEIPT_HEADERS TH, CIMS.T_AR_RECEIPT_METHODS T
       WHERE TH.RECEIPT_STATUS_ID = '3'
            --AND T.BUSINESS_TYPE IN ('1', '4', '5')
         AND (NVL(T.INTO_ERP_FLAG, 'N') = 'Y' OR
             NVL(T.INTO_BAN_FLAG, 'N') = 'Y')
         AND TH.RECEIPT_METHOD_ID = T.RECEIPT_METHOD_ID
         AND TH.ENTITY_ID = T.ENTITY_ID
         AND NVL(T.IS_EFFECTIVE, 'N') = 'Y'
         AND TH.CASH_RECEIPT_ID = P_CASH_RECEIPT_ID;

    HEAD_ROW     C_RECEIPT_HEAD%ROWTYPE; --收款头游标行数据
    V_HEAD_COUNT NUMBER; --收款头数据总数

  BEGIN
    P_MESSAGE    := 'SUCCESS';
    V_HEAD_COUNT := 0;
    FOR HEAD_ROW IN C_RECEIPT_HEAD LOOP
      V_HEAD_COUNT := V_HEAD_COUNT + 1;
      --插入资金接口
      INSERT INTO CIMS.INTF_GTSP_CIMS_TRAVEL_REGISTER
        (ID,
         --报文种类（资金状态：04，纸票在途登记报文）
         BUSINESSTYPE,
         --明细个数
         ITEMRECNUM,
         --系统导入日期
         INPUTDATE,
         --系统导出日期
         OUTPUTDATE,
         --来源系统编码
         SOURCESYSTEMCODE,
         --收款单据编号
         RECIVECODE,
         --付款方编码（即客户编码）
         PAYMENTCODE,
         --付款方名称（客户名称）
         PAYMENTNAME,
         --收款单头ID
         ATTRIBUTE1,
         --付款方银行账号（客户银行账号）
         PAYBANKACCOUT,
         --付款方银行名称（客户银行名称）
         PAYBANKNAME,
         --出票人
         DRAWEROFBILL,
         --出票银行
         DRAWERBANKACOUNT,
         --出票银行名称
         DRAWERBANKNAME,
         --上手背书人
         LASTENDORSER,
         --付款票据金额
         BILLPAYAMOUNT,
         --币种
         CURRENCY,
         --票据类型（纸票/电票）
         BILLTYPE,
         --结算方式
         PAYMENTMODE,
         --ERP收款方法ID
         RECIVEMETHOD,
         --ERP收款方银行账号
         RECIVEBANKACCOUT,
         --收款账号（ERP收款方银行账户名称）
         RECIVEACCOUT,
         --收款单位编号（ERP_OU_ID）
         RECIVEUNITCODE,
         --第一收款人
         FIRSTRECIVENAME,
         --第一收款人银行
         FIRSTRECIVEBANK,
         --第一收款人开户银行账户
         FIRSTRECIVEBANKCCCOUT,
         --出票日期
         DATEOFDRAFT,
         --到期日期
         DATEOFMATURITY,
         --票据号
         BILLNO,
         --承兑银行号
         ACCEPTANCEBANKNO,
         --预算项目
         BUDGETITEM,
         --状态:04. IMS-纸票在途登记；
         STATUS,
         --ERP_OU_ID
         OUID,
         --预算项目
         ATTRIBUTE2,
         --自动确认标志
         ATTRIBUTE3)
      VALUES
        (S_INTF_GTS_IMS_TRAVEL_REGISTER.NEXTVAL,
         '04',
         1,
         SYSDATE,
         SYSDATE,
         'CIMS',
         HEAD_ROW.CASH_RECEIPT_CODE,
         HEAD_ROW.CUSTOMER_CODE,
         HEAD_ROW.CUSTOMER_NAME,
         TO_CHAR(HEAD_ROW.CASH_RECEIPT_ID),
         P_CUST_BANK_ACCOUNT,
         P_CUST_BANK,
         HEAD_ROW.DRAWER,
         HEAD_ROW.DRAWER_BANK_ACCOUNT,
         HEAD_ROW.DRAWER_BANK,
         HEAD_ROW.BACK_WRITE_NAME,
         HEAD_ROW.AMOUNT,
         HEAD_ROW.CURRENCY_CODE,
         DECODE(HEAD_ROW.RECEIPT_ENTRY_CODE, 'Y', '纸票', '电票'),
         HEAD_ROW.PAY_MENT_MODE,
         TO_CHAR(P_ERP_RECEIPT_METHOD_ID),
         TO_CHAR(P_ERP_BANK_ACCOUNT_ID),
         P_ERP_BANK_ACCOUNT_NAME,
         HEAD_ROW.ERP_OU_ID,
         HEAD_ROW.FIRST_RECEIPT_NAME,
         HEAD_ROW.FIRST_RECEIPT_BANK,
         HEAD_ROW.FIRST_RECEIPT_BANK_ACCOUNT,
         HEAD_ROW.CASH_DATE,
         HEAD_ROW.DUE_DATE,
         HEAD_ROW.CASH_CODE,
         HEAD_ROW.ACCEPTANCE_BANK_NAME,
         HEAD_ROW.BUDGET_ITEM_NAME,
         '04',
         HEAD_ROW.ERP_OU_ID,
         HEAD_ROW.BUDGET_ITEM_NAME,
         'auto');
    END LOOP;
    IF V_HEAD_COUNT < 1 THEN
      P_MESSAGE := '收款数据有误，请联系管理员';
      RAISE V_BIZ_EXCEPTION;
    END IF;
  EXCEPTION
    WHEN V_BIZ_EXCEPTION THEN
      P_MESSAGE := '收款确认引入资金纸票在途登记失败：' || P_MESSAGE;
    WHEN OTHERS THEN
      P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_BOND.P_INSERT_GTSP_RECEIPT',
                                          SQLCODE,
                                          P_MESSAGE || SQLERRM);
  END;
  
  
                                    
  /*
  * 收款单冲销插入ERP冲销接口表
  */
  PROCEDURE P_INSERT_AR_REVERSE(P_CASH_RECEIPT_ID IN NUMBER, --收款头ID
                                P_MESSAGE         OUT VARCHAR2 --成功则返回“SUCCESS”，否则返回出错信息
                                ) IS
    --收款头、收款方法
    CURSOR C_RECEIPT_HEADERS IS
      SELECT TH.*
        FROM CIMS.T_AR_CASH_RECEIPT_HEADERS TH
           , CIMS.T_AR_RECEIPT_METHODS T
       WHERE TH.RECEIPT_STATUS_ID = '3'
         AND TH.CASH_RECEIPT_ID = P_CASH_RECEIPT_ID
         AND TH.RECEIPT_METHOD_ID = T.RECEIPT_METHOD_ID
            --AND T.BUSINESS_TYPE IN ('1', '4', '5')
         AND NVL(T.INTO_ERP_FLAG, 'N') = 'Y'
         AND NVL(T.IS_EFFECTIVE, 'N') = 'Y'
         AND T.ERP_HANDLE = '1'
         AND T.ERP_RECEIPT_METHOD_NAME IS NOT NULL;
    HEAD_ROW C_RECEIPT_HEADERS%ROWTYPE; --收款头游标行数据
    V_COUNT  NUMBER;
  BEGIN
    P_MESSAGE := 'SUCCESS';
    V_COUNT := 0;
    FOR HEAD_ROW IN C_RECEIPT_HEADERS LOOP
      V_COUNT := V_COUNT + 1;
      INSERT INTO INTF_AR_RECEIPT_REVERSE
        (
         --OU_ID
         ORG_ID,
         --接口状态，固定写N
         INTF_STATUS,
         --收款单据编号
         RECEIPT_NUMBER,
         --冲销原因，固定写“WRONG INVOICE”
         REVERSAL_REASON_CODE,
         --冲销备注
         REVERSAL_COMMENTS,
         --来源系统编码
         SOURCE_CODE,
         --总账日期
         REVERSAL_GL_DATE,
         --冲销日期
         REVERSAL_DATE,
         --固定写 “冲销付款”
         REVERSAL_CATEGORY_NAME,
         --固定写 “冲销付款”
         REVERSAL_REASON_NAME,
         TRX_ID
         )VALUES(
         HEAD_ROW.ERP_OU_ID,
         'N',
         HEAD_ROW.WRITEOFF_RECEIPT_CODE,
         'WRONG INVOICE',
         HEAD_ROW.REMAEK,
         'CIMS',
         HEAD_ROW.GL_DATE,
         HEAD_ROW.REVIEWED_DATE,
         '冲销付款',
         '冲销付款', 
         S_INTF_AR_RECEIPT_REVERSE.NEXTVAL
      );
    END LOOP;
    IF V_COUNT = 0 THEN
      P_MESSAGE := '获取不到收款单数据，请联系管理员';
      RAISE V_BIZ_EXCEPTION;
    END IF;
  EXCEPTION
    WHEN V_BIZ_EXCEPTION THEN
      P_MESSAGE := '冲销引入ERP失败：' || P_MESSAGE;
    WHEN OTHERS THEN
      P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_BOND.P_INSERT_AR_REVERSE',
                                          SQLCODE,
                                          P_MESSAGE || SQLERRM);
  END;
                                           
  
  

  /*
  * 校验收款单（三方）的分款是否已经完全解付，若完全解付，则返回“SUCCESS”，否则返回错误信息
  */
  PROCEDURE P_VALIDATE_RECEIPT_SOLUPAY(P_CASH_RECEIPT_CODE VARCHAR2, --收款单号
                                       P_SUPOR_SYSTEM      VARCHAR2, --发起冲销系统（IMS、GTSP、CCS）
                                       P_MESSAGE           OUT VARCHAR2 --成功则返回“SUCCESS”，否则返回出错信息
                                       ) IS
    V_RECEIPT_TYPE         VARCHAR2(2); --收款类型（1--承兑、2--现汇、3-承兑（三方））
    V_CASH_RECEIPT_ID      NUMBER; --收款单头ID
    V_LINE_COUNT           NUMBER; --收款行总数
    V_CASH_RECEIPT_LINE_ID NUMBER; --收款单行ID
    V_LINE_AMOUNT          NUMBER; --收款单行金额
    V_SOLU_AMOUNT          NUMBER; --收款单行解付金额
    CURSOR C_RECEIPT_LINE IS
      SELECT L.CASH_RECEIPT_LINES_ID, L.AMOUNT
        FROM CIMS.T_AR_CASH_RECEIPT_LINES L
       WHERE L.CASH_RECEIPT_ID = V_CASH_RECEIPT_ID;
    LINE_ROW C_RECEIPT_LINE%ROWTYPE; --收款行数据
  BEGIN
    IF P_SUPOR_SYSTEM = 'GTSP' OR P_SUPOR_SYSTEM = 'C-IMS' THEN
      BEGIN
        SELECT NVL(V.RECEIPT_TYPE, 0), V.CASH_RECEIPT_ID
          INTO V_RECEIPT_TYPE, V_CASH_RECEIPT_ID
          FROM CIMS.V_AR_CASH_RECEIPT_HEADERS V
         WHERE V.CASH_RECEIPT_CODE = P_CASH_RECEIPT_CODE;
      EXCEPTION
        WHEN OTHERS THEN
          P_MESSAGE := '收款单（' || P_CASH_RECEIPT_CODE ||
                       '）数据异常，未查询到收款单，请联系管理员';
      END;
      IF V_RECEIPT_TYPE IS NULL OR V_CASH_RECEIPT_ID IS NULL THEN
        P_MESSAGE := '收款单（' || P_CASH_RECEIPT_CODE ||
                     '）数据异常，未查询到收款单，请联系管理员';
      ELSIF V_RECEIPT_TYPE = 0 THEN
        P_MESSAGE := '收款单（' || P_CASH_RECEIPT_CODE || '）数据异常，没有收款类型，请联系管理员';
      ELSIF V_RECEIPT_TYPE <> 3 THEN
        P_MESSAGE := 'SUCCESS';
      ELSE
        V_LINE_COUNT := 0;
        P_MESSAGE    := 'SUCCESS';
        FOR LINE_ROW IN C_RECEIPT_LINE LOOP
          V_LINE_COUNT           := V_LINE_COUNT + 1;
          V_CASH_RECEIPT_LINE_ID := LINE_ROW.CASH_RECEIPT_LINES_ID;
          V_LINE_AMOUNT          := LINE_ROW.AMOUNT;
          BEGIN
            SELECT SUM(T.SOLUTION_PAY_AMOUNT)
              INTO V_SOLU_AMOUNT
              FROM CIMS.T_AR_ACCE_SOLU_PAY T
             WHERE T.CASH_RECEIPT_LINES_ID = V_CASH_RECEIPT_LINE_ID
             --统计的解付明细不包括未复核状态（即没有触发信控的解付明细申请）
               AND T.SOLUTION_PAY_STATUS IN (2, 3);
          EXCEPTION
            WHEN OTHERS THEN
              P_MESSAGE := '收款单（' || P_CASH_RECEIPT_CODE || '）数据异常，请联系管理员';
          END;
          --2015-12-30修改，部分解付时不允许冲销，未解付或者完全解付时允许冲销
          IF V_SOLU_AMOUNT IS NOT NULL AND V_SOLU_AMOUNT <> 0 AND V_LINE_AMOUNT <> V_SOLU_AMOUNT THEN
            P_MESSAGE := '收款单（' || P_CASH_RECEIPT_CODE ||
                         '）分款未完全解付，不允许整单冲销';
            EXIT;
          END IF;
        END LOOP;
        IF V_LINE_COUNT < 1 THEN
          P_MESSAGE := '收款单（' || P_CASH_RECEIPT_CODE ||
                       '）数据异常，没有分款明细，请联系管理员';
        END IF;
      END IF;
    ELSE
      P_MESSAGE := 'SUCCESS';
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      P_MESSAGE := '校验收款单（三方）是否已经完全解付失败，请联系管理员！';
      P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_COMMON.F_VALIDATE_RECEIPT_SOLUPAY',
                                          SQLCODE,
                                          P_MESSAGE ||
                                          SUBSTR(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE,
                                                 1,
                                                 100) || SQLERRM);
  END;

  /*
  * 查询已汇状态的收款单重复票据数
  */
  PROCEDURE P_ERP_CASH_CODE_SUM(P_ENTITY_ID       NUMBER, --主体ID
                                P_CASH_CODE       VARCHAR2, --票据号
                                P_CASH_RECEIPT_ID NUMBER, --收款单ID
                                P_COUNT           OUT NUMBER, --返回重复记录数，0为没有
                                P_MESSAGE         OUT VARCHAR2 --查询异常返回错误信息，否则返回'SUCCESS'
                                ) IS
    V_CHECK_FLAG VARCHAR2(2); --校验统计标志：1-区分主体，统计子票据；2-区分主体，统计合并票据；3-不区分主体，统计子票据；4-不区分主体，统计合并票据
  BEGIN
    P_COUNT := 0;
    IF P_CASH_CODE IS NULL THEN
      P_MESSAGE := '校验入库票据号重复：票据号不能为空';
    END IF;
    BEGIN
      PKG_BD.P_GET_PARAMETER_VALUE('ar_erp_code_flag',
                                   P_ENTITY_ID,
                                   '',
                                   '',
                                   V_CHECK_FLAG);
    EXCEPTION
      WHEN OTHERS THEN
        P_MESSAGE := '校验入库票据号重复：获取统计方式系统参数异常，请联系管理员';
    END;
    IF V_CHECK_FLAG IS NULL THEN
      P_MESSAGE := '校验入库票据号重复：统计方式系统参数异常，请联系管理员';
    ELSIF V_CHECK_FLAG = '1' THEN
      --统计方式=1，区分主体，统计子票据
      IF P_ENTITY_ID IS NULL THEN
        P_MESSAGE := '校验入库票据号重复：主体不能为空';
      ELSE
        BEGIN
          SELECT COUNT(H.CASH_CODE)
            INTO P_COUNT
            FROM CIMS.T_AR_CASH_RECEIPT_HEADERS H
           WHERE H.ENTITY_ID = P_ENTITY_ID
             AND H.CASH_CODE = P_CASH_CODE
                --单据状态ID = 6 ；单据状态为已汇，表示资金已入库；5-已审核；3-已确认；
             AND H.RECEIPT_STATUS_ID in('3','5', '6')
             AND NVL(H.CASH_RECEIPT_ID, 0) <> NVL(P_CASH_RECEIPT_ID, 0);
        EXCEPTION
          WHEN OTHERS THEN
            P_MESSAGE := '收款单（票据号' || P_CASH_CODE || '）数据异常，请联系管理员';
        END;
        P_MESSAGE := 'SUCCESS';
      END IF;
    ELSIF V_CHECK_FLAG = '2' THEN
      --统计方式=2，区分主体，统计合并后的票据
      IF P_ENTITY_ID IS NULL THEN
        P_MESSAGE := '校验入库票据号重复：主体不能为空';
      ELSE
        BEGIN
          SELECT SUM(CODESUM)
            INTO P_COUNT
            FROM (SELECT DISTINCT H.CASH_CODE,
                                  COUNT(H.SUB_CASH_CODE) CODESUM
                    FROM CIMS.T_AR_CASH_RECEIPT_HEADERS H
                   WHERE H.ENTITY_ID = P_ENTITY_ID
                     AND H.UNITE_FLAG = 'Y'
                     AND H.CASH_CODE = P_CASH_CODE
                     AND H.RECEIPT_STATUS_ID in('3','5', '6')
                     AND NVL(H.CASH_RECEIPT_ID, 0) <>
                         NVL(P_CASH_RECEIPT_ID, 0)
                   GROUP BY H.CASH_CODE, H.SUB_CASH_CODE
                  UNION ALL
                  SELECT DISTINCT H.CASH_CODE, COUNT(H.CASH_CODE) CODESUM
                    FROM CIMS.T_AR_CASH_RECEIPT_HEADERS H
                   WHERE H.ENTITY_ID = P_ENTITY_ID
                     AND NVL(H.UNITE_FLAG, 'N') <> 'Y'
                     AND H.CASH_CODE = P_CASH_CODE
                     AND H.RECEIPT_STATUS_ID in('3','5', '6')
                     AND NVL(H.CASH_RECEIPT_ID, 0) <>
                         NVL(P_CASH_RECEIPT_ID, 0)
                   GROUP BY H.CASH_CODE)
           GROUP BY CASH_CODE;
        EXCEPTION
          WHEN OTHERS THEN
            P_MESSAGE := '收款单（票据号' || P_CASH_CODE || '）数据异常，请联系管理员';
        END;
        P_MESSAGE := 'SUCCESS';
      END IF;
    ELSIF V_CHECK_FLAG = '3' THEN
      --统计方式=3，不区分主体，统计子票据
      BEGIN
        SELECT COUNT(H.CASH_CODE)
          INTO P_COUNT
          FROM CIMS.T_AR_CASH_RECEIPT_HEADERS H
         WHERE H.CASH_CODE = P_CASH_CODE
           AND H.RECEIPT_STATUS_ID in('3','5', '6')
           AND NVL(H.CASH_RECEIPT_ID, 0) <> NVL(P_CASH_RECEIPT_ID, 0);
      EXCEPTION
        WHEN OTHERS THEN
          P_MESSAGE := '收款单（票据号' || P_CASH_CODE || '）数据异常，请联系管理员';
      END;
      P_MESSAGE := 'SUCCESS';
    ELSIF V_CHECK_FLAG = '4' THEN
      --统计方式=4，不区分主体，统计合并后的票据
      BEGIN
        SELECT SUM(CODESUM)
          INTO P_COUNT
          FROM (SELECT DISTINCT H.CASH_CODE, COUNT(H.SUB_CASH_CODE) CODESUM
                  FROM CIMS.T_AR_CASH_RECEIPT_HEADERS H
                 WHERE H.UNITE_FLAG = 'Y'
                   AND H.CASH_CODE = P_CASH_CODE
                   AND H.RECEIPT_STATUS_ID in('3','5', '6')
                   AND NVL(H.CASH_RECEIPT_ID, 0) <>
                       NVL(P_CASH_RECEIPT_ID, 0)
                 GROUP BY H.CASH_CODE, H.SUB_CASH_CODE
                UNION ALL
                SELECT DISTINCT H.CASH_CODE, COUNT(H.CASH_CODE) CODESUM
                  FROM CIMS.T_AR_CASH_RECEIPT_HEADERS H
                 WHERE NVL(H.UNITE_FLAG, 'N') <> 'Y'
                   AND H.CASH_CODE = P_CASH_CODE
                   AND H.RECEIPT_STATUS_ID in('3','5', '6')
                   AND NVL(H.CASH_RECEIPT_ID, 0) <>
                       NVL(P_CASH_RECEIPT_ID, 0)
                 GROUP BY H.CASH_CODE)
         GROUP BY CASH_CODE;
      EXCEPTION
        WHEN OTHERS THEN
          P_MESSAGE := '收款单（票据号' || P_CASH_CODE || '）数据异常，请联系管理员';
      END;
      P_MESSAGE := 'SUCCESS';
    ELSE
      P_MESSAGE := '校验入库票据号重复：校验统计方式有误，请联系管理员';
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_COMMON.P_ERP_CASH_CODE_SUM',
                                          SQLCODE,
                                          P_MESSAGE ||
                                          SUBSTR(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE,
                                                 1,
                                                 100) || SQLERRM);
  END;
  
    /*
  * 根据中心编码查询NC组织
  */
  PROCEDURE P_GET_NCORG_BY_CODE(P_ENTITY_ID          IN  NUMBER,   --主体ID
                                P_SALES_CENTER_CODE  IN  VARCHAR2, --营销中心编码
                                P_NC_ORG_CODE        OUT VARCHAR2, --返回NC组织编码
                                P_MESSAGE            OUT VARCHAR2 --查询异常返回错误信息，否则返回'SUCCESS'
                                )IS

     V_NC_ORG_CODE VARCHAR2(100);
 BEGIN 
     P_MESSAGE := 'SUCCESS';
     SELECT
          NC_ORG_CODE 
     INTO V_NC_ORG_CODE
     FROM   
         (SELECT 
              NC_ORG_CODE 
           FROM 
              T_AR_OU_RELATION T
          WHERE T.ENTITY_ID = P_ENTITY_ID
           AND T.SALES_CENTER_CODE = P_SALES_CENTER_CODE 
           ORDER BY IS_DEFAULT DESC)
       WHERE ROWNUM=1;   
       P_NC_ORG_CODE :=  V_NC_ORG_CODE;
 EXCEPTION      
     WHEN NO_DATA_FOUND THEN
         P_MESSAGE := '营销中心编码:'||P_SALES_CENTER_CODE||'对应的NC组织关系未配置';
 END;   
                                
  /*
  * 根据中心ID查询NC组织
  */
  PROCEDURE P_GET_NCORG_BY_ID(P_ENTITY_ID          IN  NUMBER,   --主体ID
                                P_SALES_CENTER_ID  IN  NUMBER,   --营销中心编码
                                P_NC_ORG_CODE        OUT VARCHAR2, --返回NC组织编码
                                P_MESSAGE            OUT VARCHAR2 --查询异常返回错误信息，否则返回'SUCCESS'
                                )IS
     V_NC_ORG_CODE VARCHAR2(100);
 BEGIN 
     P_MESSAGE := 'SUCCESS';
     SELECT
          NC_ORG_CODE 
     INTO V_NC_ORG_CODE
     FROM   
         (SELECT 
              NC_ORG_CODE 
           FROM 
              T_AR_OU_RELATION T
          WHERE T.ENTITY_ID = P_ENTITY_ID
           AND T.SALES_CENTER_ID = P_SALES_CENTER_ID 
           ORDER BY IS_DEFAULT DESC)
       WHERE ROWNUM=1;   
       P_NC_ORG_CODE :=  V_NC_ORG_CODE;
 EXCEPTION      
     WHEN NO_DATA_FOUND THEN
          P_MESSAGE := '营销中心ID:'||P_SALES_CENTER_ID||'对应的NC组织关系未配置';
 END;         
  
  
END PKG_AR_COMMON;
/

