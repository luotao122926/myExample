create view INTF_CREDIT_TERMS as
Select V.ENTITY_ID,
       V.CUSTOMER_ID,
       V.CUSTOMER_CODE,
       V.CUSTOMER_NAME,
       V.SALES_CENTER_ID,
       V.SALES_CENTER_CODE,
       V.SALES_CENTER_NAME,
       V.SALES_MAIN_TYPE_ID,
       --V.SALES_MAIN_TYPE_NAME,
       NVL(CR.HQ_ITEM_CLASS_NAME, V.SALES_MAIN_TYPE_NAME) AS SALES_MAIN_TYPE_NAME,
       NVL(CR.HQ_ITEM_CLASS_CODE, V.SALES_MAIN_TYPE_CODE) AS SALES_MAIN_TYPE_CODE,
       CR.SC_ITEM_BRAND,
       V.CUSTOM_LEVEL,
       V.CUSTOM_CREDIT_LEVEL,
       V.CREDIT_LINE,
       V.REQUIS_AMOUNT,
       V.USER_DELAYPAY,
       V.REMAINDER_AMOUNT
  From V_CREDIT_TERMS V
  LEFT JOIN (SELECT DISTINCT SC_ENTITY_ID,
                             SC_ITEM_CLASS_CODE,
                             --实际需要转换给CCS的是总部经营品牌HQ_ITEM_BRAND，但是由于最初沟通已确定为SC_ITEM_BRAND，不再更改
                             HQ_ITEM_BRAND AS SC_ITEM_BRAND,
                             HQ_ITEM_CLASS_NAME,
                             HQ_ITEM_CLASS_CODE
               FROM T_BD_ITEM_CLASS_RELATION
               --时间范围有效
              WHERE SYSDATE >= BEGIN_DATE
                AND (END_DATE IS NULL OR SYSDATE <= END_DATE)
                AND SALE_TYPE = 'M') CR
    ON (CR.SC_ENTITY_ID = V.ENTITY_ID AND
       CR.SC_ITEM_CLASS_CODE = V.SALES_MAIN_TYPE_CODE) With Read Only
/

comment on column INTF_CREDIT_TERMS.ENTITY_ID is '业务主体ID'
/

comment on column INTF_CREDIT_TERMS.CUSTOMER_ID is '客户ID'
/

comment on column INTF_CREDIT_TERMS.CUSTOMER_CODE is '客户编码'
/

comment on column INTF_CREDIT_TERMS.CUSTOMER_NAME is '客户名称'
/

comment on column INTF_CREDIT_TERMS.SALES_CENTER_ID is '营销中心ID'
/

comment on column INTF_CREDIT_TERMS.SALES_CENTER_CODE is '营销中心编码'
/

comment on column INTF_CREDIT_TERMS.SALES_CENTER_NAME is '营销中心名称'
/

comment on column INTF_CREDIT_TERMS.SALES_MAIN_TYPE_ID is '营销大类ID'
/

comment on column INTF_CREDIT_TERMS.SALES_MAIN_TYPE_NAME is '营销大类名称'
/

comment on column INTF_CREDIT_TERMS.SALES_MAIN_TYPE_CODE is '营销大类编码'
/

comment on column INTF_CREDIT_TERMS.SC_ITEM_BRAND is '销司品牌'
/

comment on column INTF_CREDIT_TERMS.CUSTOM_LEVEL is '客户等级'
/

comment on column INTF_CREDIT_TERMS.CUSTOM_CREDIT_LEVEL is '信用等级'
/

comment on column INTF_CREDIT_TERMS.CREDIT_LINE is '信用额度'
/

comment on column INTF_CREDIT_TERMS.REQUIS_AMOUNT is '调整额度'
/

comment on column INTF_CREDIT_TERMS.USER_DELAYPAY is '已使用铺底'
/

comment on column INTF_CREDIT_TERMS.REMAINDER_AMOUNT is '剩余可用额度'
/

