create PACKAGE      PKG_INV_BILL_MONTH AS
/******************************************************************************
   NAME:       PKG_INV_BILL_MONTH
   PURPOSE:

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        2014/9/5             1. Created this package.
******************************************************************************/

  PROCEDURE P_INV_BILL_MONTH (
    in_entity_id        IN  NUMBER,        --经营主体ID
    in_operator_by        IN  VARCHAR2,        --操作人员u
    in_bill_flag        IN  NUMBER,        --结账标识  1:结账  0:反结账
    in_period_id        IN  NUMBER,        --会计期间(当in_bill_flag=1时，表示结账会计期间)
    on_err_code            OUT NUMBER,     --错误码  default:0
    os_err_desc         OUT VARCHAR2    --错误描述 default:空
);


PROCEDURE P_FREEZE_TRANSMIT_RECEIVE (
     IV_RECEIVE_DATE   IN VARCHAR2 --日期
    ,IN_ENTITY_ID      IN NUMBER --主体
    ,OS_MESSAGE       OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
);

--样机产品收发存月冻结
PROCEDURE P_FREEZE_PRO_TRANSMIT_RECEIVE (
     IV_RECEIVE_DATE   IN VARCHAR2 --日期
    ,P_RESULT       OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
);

END PKG_INV_BILL_MONTH;
/

