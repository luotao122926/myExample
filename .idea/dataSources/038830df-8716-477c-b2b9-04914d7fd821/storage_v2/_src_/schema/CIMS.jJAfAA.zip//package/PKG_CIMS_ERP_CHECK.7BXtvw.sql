create PACKAGE      PKG_CIMS_ERP_Check is

  --CIMS-ERP库存对账
  procedure p_inv_check(p_begin_date date,p_end_date date);
  --插入ERP中没有库存事务的单据
  Procedure P_Inv_ERP_No_Trans;
  --设置对账成功、失败信息
  procedure p_Set_Check_Mess;
  --对当月的账务
  procedure p_month_inv_check;

END PKG_CIMS_ERP_Check;
/

