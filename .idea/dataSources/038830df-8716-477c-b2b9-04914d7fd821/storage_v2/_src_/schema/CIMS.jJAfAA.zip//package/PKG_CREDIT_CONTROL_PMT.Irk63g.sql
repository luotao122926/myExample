create package PKG_CREDIT_CONTROL_PMT is

  TYPE CUR_SALES_ACCOUNT_AMOUNT IS TABLE OF T_SALES_ACCOUNT_AMOUNT%ROWTYPE INDEX BY BINARY_INTEGER;
  TYPE CUR_SALES_ACCOUNT_MX_AMOUNT IS TABLE OF T_SALES_ACCOUNT_MX_AMOUNT%ROWTYPE INDEX BY BINARY_INTEGER;

  PROCEDURE 以下推广物料信用控制;

  PROCEDURE PRC_CREDIT_CONTROL_PMT( P_ENTITY_ID           IN NUMBER,--主ID体
                                    P_ACTION_TYPE         IN VARCHAR2, ----动作标示（28：资源提货订单评审，29：资源提货订单取消，30：资源发放单,31:资源返利单，32：资源返利单红冲）
                                    P_Settlement_SUM      IN NUMBER, --结算金额
                                    P_Discount_SUM        IN NUMBER, --折扣金额
                                    P_SALES_MAIN_TYPE     IN VARCHAR2, --营销大类
                                    P_ORDER_ID            IN NUMBER, --单据ID
                                    P_ACCOUNT_ID          IN NUMBER, --账户ID
                                    P_CUSTOMER_ID         IN NUMBER, --客户ID
                                    P_PROJ_NUMBER         IN VARCHAR2, --项目号
                                    P_CREATED_MODE         IN NUMBER,   --开单方式
                                    P_ORDER_TYPE          IN VARCHAR2, --单据类型
                                    P_USERNAME            IN VARCHAR2 ,
                                    P_RESULT              IN OUT NUMBER, --返回错误ID
                                    P_ERR_MSG             IN OUT VARCHAR2 --返回错误信息
                                    );
  PROCEDURE 资源资金校验 ;

  PROCEDURE PRC_CREDIT_VERIFICATION(P_ENTITY_ID            IN NUMBER, --主体ID
                                    P_ACTION_TYPE          IN NUMBER, --动作标示
                                    P_Settlement_SUM       IN NUMBER, --结算金额
                                    P_Discount_SUM         IN NUMBER, --折扣金额
                                    P_ORDER_ID             IN NUMBER, --单据ID
                                    P_SALES_MAIN_TYPE      IN VARCHAR2, --营销大类
                                    P_ACCOUNT_ID           IN NUMBER, --账户ID
                                    P_CUSTOMER_ID          IN NUMBER, --客户ID
                                    P_PROJ_NUMBER          IN VARCHAR2, --项目号
                                    P_RESULT               IN OUT NUMBER, --返回错误ID
                                    P_ERR_MSG              IN OUT VARCHAR2, --返回错误信息
                                    P_ORDER_TYPE        IN VARCHAR2 DEFAULT NULL
                                    ) ;

  PROCEDURE PRC_CREDIT_VERIFICATION_IMPL( P_ACTION_TYPE          IN NUMBER, --动作标示
                                          P_Settlement_SUM       IN NUMBER, --结算金额
                                          P_Discount_SUM         IN NUMBER, --折扣金额
                                          P_ORDER_ID             IN NUMBER, --单据ID
                                          P_SALES_ACCOUNT_AMOUNT CUR_SALES_ACCOUNT_AMOUNT ,
                                          P_AMOUNT_CRTL_FLAG     IN VARCHAR2, --金额控制方式
                                          P_DISCONT_CRTL_FLAG    IN VARCHAR2, --折扣控制方式
                                          P_RESULT            IN OUT NUMBER, --返回错误ID
                                          P_ERR_MSG           IN OUT VARCHAR2, --返回错误信息
                                          P_ORDER_TYPE        IN VARCHAR2 DEFAULT NULL
                                          ) ;

  PROCEDURE 资源款项更新 ;

  PROCEDURE PRC_CREDIT_FUND_UPDATE(P_ENTITY_ID     IN NUMBER, --主体ID
                                   P_ACTION_TYPE     IN NUMBER, --动作标示
                                   P_Settlement_SUM  IN NUMBER, --结算金额
                                   P_Discount_SUM    IN NUMBER, --折扣金额
                                   P_SALES_MAIN_TYPE IN VARCHAR2, --营销大类
                                   P_ACCOUNT_ID      IN NUMBER, --账户ID
                                   P_CUSTOMER_ID     IN NUMBER, --客户ID
                                   P_PROJ_NUMBER     IN VARCHAR2, --项目号
                                   P_ORDER_ID   IN NUMBER, --单据ID
                                   P_ORDER_TYPE IN VARCHAR2, --单据类型
                                   P_USERNAME   IN VARCHAR2,
                                   P_RESULT     IN OUT NUMBER, --返回错误ID
                                   P_ERR_MSG    IN OUT VARCHAR2 --返回错误信息
                                   );

  PROCEDURE 订单检查不锁款调用 ;


  Procedure PRC_CREDIT_ORDER_PMT_CHECK(P_ENTITY_ID               IN NUMBER, --主体ID
                                    P_ACTION_TYPE          IN NUMBER, --动作标示
                                    P_Settlement_SUM       IN NUMBER, --结算金额
                                    P_Discount_SUM         IN NUMBER, --折让金额
                                    P_SALES_MAIN_TYPE   IN VARCHAR2, --营销大类
                                    P_ACCOUNT_ID           IN NUMBER, --账户ID
                                    P_CUSTOMER_ID          IN NUMBER, --客户ID
                                    P_PROJ_NUMBER          IN VARCHAR2, --项目号
                                    P_ORDER_ID             IN NUMBER,   --单据ID
                                    P_RESULT            IN OUT NUMBER, --返回错误ID
                                    P_ERR_MSG           IN OUT VARCHAR2, --返回错误信息
                                    P_ORDER_TYPE        IN VARCHAR2 DEFAULT NULL
                            ) ;
end;
/

