create PACKAGE PKG_BD_ITEM  AS

  --TYPE MSG_VARRAY_TYPE IS VARRAY(1) OF VARCHAR2(1000);
  -----------------------------------------------------------------------------
  --处理配套仓库商品(通用商品配套算法，支持150个数量字段)
  --根据T_MTL_SUBASSEMBLIES2MTL的内容写到中单处理临时表（T_INV_MATCHING_IN_BUFFER），并通过T_INV_MATCHING_BUFFER输出配套结果
  --将配套结果写入T_MTL_SUBASS2MTL_RESULT
  -----------------------------------------------------------------------------
  PROCEDURE P_MATCHING_MTL_150
  (
    P_TRANSACTION_ID         IN NUMBER, --事务ID
    P_ENTITY_ID IN NUMBER,--主主体ID
    P_MESSAGE                OUT VARCHAR2--返回信息(OK表示执行成功)
  );

  -----------------------------------------------------------------------------
  --处理配套仓库商品(通用商品配套算法，支持150个数量字段)
  --根据T_MTL_SUBASSEMBLIES2MTL的内容写到中单处理临时表（T_INV_MATCHING_IN_BUFFER），并通过T_INV_MATCHING_BUFFER输出配套结果
  --将配套结果写入T_MTL_SUBASS2MTL_RESULT
  --对于多优先级配套时，按优先级配套，剩余散件放到下一优先级处理配套
  -----------------------------------------------------------------------------
  PROCEDURE P_MATCHING_MTL_L1_150
  (
    P_TRANSACTION_ID         IN NUMBER, --事务ID
    P_ENTITY_ID IN NUMBER,--主主体ID
    P_MESSAGE                OUT VARCHAR2--返回信息(OK表示执行成功)
  );

  -----------------------------------------------------------------------------
  --对指定的数量类型处理配套，根据T_INV_MATCHING_IN_BUFFER的内容，写到T_INV_MATCHING_BUFFER
  -----------------------------------------------------------------------------
  PROCEDURE P_MATCHING_PROC
  (
    P_QUANTITY_TYPE NUMBER, --数量类型
    P_PROC_LEVEL    VARCHAR2, --处理优先级,-1表示不需处理优先级
    P_ENTITY_ID NUMBER, --主主体ID
    P_MESSAGE   OUT VARCHAR2--返回信息(OK表示执行成功)
  );

  -----------------------------------------------------------------------------
  --根据重新配套数据，更新未匹配数量
  --为了便于处理，将临时配套处理采用统一的级别“_TEMP”来处理。
  --, '_TEMP', V_I, P_MESSAGE
  -----------------------------------------------------------------------------
  PROCEDURE P_UPDATE_UNMATCH_QTY
  (
    P_PRIOR_LEVEL            IN VARCHAR2, --前一配套优先级
    P_TEMP_LEVEL             IN VARCHAR2, --临时配套优先级
    P_QUANTITY_TYPE          IN NUMBER,   --数量类型(1..150)
    P_MESSAGE                OUT VARCHAR2 --返回信息(OK表示执行成功)
   );

  -----------------------------------------------------------------------------
  --初始化套件体积
  -----------------------------------------------------------------------------
  PROCEDURE P_INIT_PACKSIZE
  (
    P_MAIN_CODE    IN t_bd_item.item_code%type,  --套件编码
    P_ENTITY_ID    IN t_bd_item.entity_id%type   --主体ID
   );

  -----------------------------------------------------------------------------
  --初始化套件关系
  -----------------------------------------------------------------------------
  PROCEDURE P_INSERT_ASSEMB
  (
    P_MAIN_CODE    t_bd_item.item_code%type,  --套件编码
    P_ENTITY_ID    t_bd_item.entity_id%type   --主体ID
   );

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-11-04
  *   创建者：
  *   功能说明：产品接口历史表数据 同步至 产品接口表、产品正式表,调用主过程
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SYC_ITEM_MAIN(P_ITEM_CODE t_bd_item.item_code%type, --产品编码，如果为空则同步所有未同步的记录
                       P_RESULT    IN OUT NUMBER, --返回错误ID
                       P_ERR_MSG   IN OUT VARCHAR2 --返回错误信息
                       );
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-11-04
  *   创建者：
  *   功能说明：判断产品符合接收条件
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SYC_ITEM_CONDITIONS(P_INTF_BD_ITEM_HIS IN INTF_BD_ITEM_HIS.ID%TYPE, --产品接口历史行记录
                                  V_ENTITY_VARRAY    IN OUT PKG_SO_PUB.TYPE_ARRAY,  --返回符合条件主体，逗号隔开
                                  P_RESULT           IN OUT NUMBER, --返回错误ID
                                  P_ERR_MSG          IN OUT VARCHAR2 --返回错误信息
                                  );
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-11-05
  *   功能说明：产品信息检验，P_RESULT: 0 成功，负数为失败
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SYC_ITEM_CHECK(P_INTF_BD_ITEM_HIS IN OUT intf_bd_item_his%ROWTYPE, --产品接口历史行记录
                             P_RESULT  IN OUT NUMBER, --返回错误ID
                             P_ERR_MSG IN OUT VARCHAR2 --返回错误信息
                             );
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-11-05
  *   功能说明：产品信息检验(共性字段部分)，P_RESULT: 0 成功，负数为失败
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SYC_ITEM_CHECK_BASE(P_INTF_BD_ITEM_HIS IN OUT intf_bd_item_his%ROWTYPE, --产品接口历史行记录
                             P_RESULT  IN OUT NUMBER, --返回错误ID
                             P_ERR_MSG IN OUT VARCHAR2 --返回错误信息
                             );
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-12-01
  *   功能说明：获取产品使能标识  T_BD_ITEM_PRODUCT_PHASE
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SYC_ITEM_PHASE(P_INTF_BD_ITEM_HIS IN OUT intf_bd_item_his%ROWTYPE, --产品接口历史行记录
                                   P_RESULT           IN OUT NUMBER, --返回错误ID
                                   P_ERR_MSG          IN OUT VARCHAR2 --返回错误信息
                                   );
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-11-05
  *   功能说明：生成产品接口记录
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SYC_ITEM_INSERT_INTF(P_INTF_BD_ITEM_HIS IN OUT intf_bd_item_his%ROWTYPE, --产品接口历史行记录
                                   P_ENTITY_ID        IN VARCHAR2, --主体编码
                                   P_INTF_BD_ITEM_ID  IN OUT NUMBER, --产品接口表记录ID
                                   P_RESULT           IN OUT NUMBER, --返回错误ID
                                   P_ERR_MSG          IN OUT VARCHAR2 --返回错误信息
                                   );
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-11-05
  *   功能说明：更新产品接口记录
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SYC_ITEM_UPDATE_INTF(P_INTF_BD_ITEM_HIS IN OUT intf_bd_item_his%ROWTYPE, --产品接口历史行记录
                                   P_ENTITY_ID        IN VARCHAR2, --主体编码
                                   P_INTF_BD_ITEM_ID  IN OUT NUMBER, --产品接口表记录ID
                                   P_RESULT           IN OUT NUMBER, --返回错误ID
                                   P_ERR_MSG          IN OUT VARCHAR2 --返回错误信息
                                   );
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-11-05
  *   功能说明：更新产品接口正式表记录
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SYC_ITEM_UPDATE(P_INTF_BD_ITEM_HIS IN OUT intf_bd_item_his%ROWTYPE, --产品接口历史行记录
                              P_ENTITY_ID        IN VARCHAR2, --主体编码
                              P_RESULT           IN OUT NUMBER, --返回错误ID
                              P_ERR_MSG          IN OUT VARCHAR2 --返回错误信息
                              );
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-11-05
  *   功能说明：生成产品产地生命周期接口记录
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SYC_ITEM_INSERT_CD(P_INTF_BD_ITEM_HIS IN OUT intf_bd_item_his%ROWTYPE, --产品接口历史行记录
                                 P_ENTITY_ID        IN VARCHAR2, --主体编码
                                 P_RESULT           IN OUT NUMBER, --返回错误ID
                                 P_ERR_MSG          IN OUT VARCHAR2 --返回错误信息
                                 );
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-11-05
  *   功能说明：更新产品产地生命周期接口记录
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SYC_ITEM_UPDATE_CD(P_INTF_BD_ITEM_HIS IN OUT intf_bd_item_his%ROWTYPE, --产品接口历史行记录
                                 P_ENTITY_ID        IN VARCHAR2, --主体编码
                                 P_RESULT           IN OUT NUMBER, --返回错误ID
                                 P_ERR_MSG          IN OUT VARCHAR2 --返回错误信息
                                 );
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-11-05
  *   创建者：
  *   功能说明：产品配套关系接口历史表数据 同步至 接口表,调用主过程
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SYC_ITEM_ASSEMB_MAIN(P_ITEM_CODE t_bd_item.item_code%type, --产品编码，如果为空则同步所有未同步的记录
                       P_RESULT    IN OUT NUMBER, --返回错误ID
                       P_ERR_MSG   IN OUT VARCHAR2 --返回错误信息
                       );
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-11-04
  *   创建者：
  *   功能说明：判断产品配套关系符合接收条件的主体
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SYC_ITEM_ASSEMB_CONDITIONS(P_INTF_ITEMASSEMB_HIS IN INTF_BD_ITEM_ASSEMBLIES_HIS.ID%TYPE, --产品接口历史行记录
                                  V_ENTITY_VARRAY    IN OUT PKG_SO_PUB.TYPE_ARRAY,  --返回符合条件主体，逗号隔开
                                  P_RESULT           IN OUT NUMBER, --返回错误ID
                                  P_ERR_MSG          IN OUT VARCHAR2 --返回错误信息
                                  );

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-11-05
  *   功能说明：生成产品配套接口记录
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SYC_ITEM_ASSEMB_INSERT_INTF(P_INTF_ITEM_ASSEMB_HIS IN OUT INTF_BD_ITEM_ASSEMBLIES_HIS%ROWTYPE, --产品配套接口历史行记录
                                   P_ENTITY_ID        IN NUMBER, --主体编码
                                   P_RESULT           IN OUT NUMBER, --返回错误ID
                                   P_ERR_MSG          IN OUT VARCHAR2 --返回错误信息
                                   );
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-11-05
  *   功能说明：更新产品配套接口记录
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SYC_ITEM_ASSEMB_UPDATE_INTF(P_INTF_ITEM_ASSEMB_HIS IN OUT INTF_BD_ITEM_ASSEMBLIES_HIS%ROWTYPE, --产品配套接口历史行记录
                                   P_ENTITY_ID        IN NUMBER, --主体编码
                                   P_RESULT           IN OUT NUMBER, --返回错误ID
                                   P_ERR_MSG          IN OUT VARCHAR2 --返回错误信息
                                   );

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2017-1-18
  *   功能说明：引入正式表规则校验
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_ITEM_CHECK_RULE(     P_ENTITY_ID        IN NUMBER, --主体编码
                                   P_ORGANIZATION_ID  IN NUMBER, --组织ID
                                   P_ITEM_CODE        IN VARCHAR2, --产品编码
                                   P_RESULT           IN OUT NUMBER, --返回错误ID
                                   P_ERR_MSG          IN OUT VARCHAR2 --返回错误信息
                                   );

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2017-05-15
  *   功能说明：销司主体同步总部主体产品
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SYC_ITEM_ENTITY(     P_ENTITY_ID        IN NUMBER, --销司主体ID
                                   P_RESULT           IN OUT NUMBER, --返回错误ID
                                   P_ERR_MSG          IN OUT VARCHAR2 --返回错误信息
                                   );
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2017-05-15
  *   功能说明：生成产品表记录
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SYC_ITEM_INSERT(P_BD_ITEM IN T_BD_ITEM%ROWTYPE, --产品记录
                                    P_RESULT         IN OUT NUMBER, --返回错误ID
                                    P_ERR_MSG        IN OUT VARCHAR2 --返回错误信息
                                    );

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2017-05-15
  *   功能说明：更新产品表记录
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SYC_ITEM_UPDATE(P_BD_ITEM IN T_BD_ITEM%ROWTYPE, --产品记录
                                    P_RESULT         IN OUT NUMBER, --返回错误ID
                                    P_ERR_MSG        IN OUT VARCHAR2 --返回错误信息
                                    );

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2017-05-15
  *   功能说明：生成产品套机表记录
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SYC_ITEM_ASSEMB_INSERT(P_BD_ITEM_ASSEMBLIES IN T_BD_ITEM_ASSEMBLIES%ROWTYPE, --产品套机记录
                                    P_RESULT         IN OUT NUMBER, --返回错误ID
                                    P_ERR_MSG        IN OUT VARCHAR2 --返回错误信息
                                    );

  

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2017-05-15
  *   功能说明：生成产品散件表记录
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SYC_ITEM_ASSEMB_SUB_INSERT(P_BD_ITEM_ASSEMBLIES_SUB IN T_BD_ITEM_ASSEMBLIES_SUB%ROWTYPE, --产品套机记录
                                    P_RESULT         IN OUT NUMBER, --返回错误ID
                                    P_ERR_MSG        IN OUT VARCHAR2 --返回错误信息
                                    );

  
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2018-04-19
  *   功能说明：生成产品套散关系
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SYC_ITEM_ASSEMB_RELATE(P_ITEM_CODE IN VARCHAR2, --产品套机
                                    P_SRC_ENTITY_ID IN NUMBER, --来源主体
                                    P_TARGET_ENTITY_ID IN NUMBER, --目标主体
                                    P_RESULT         IN OUT NUMBER, --返回错误ID
                                    P_ERR_MSG        IN OUT VARCHAR2 --返回错误信息
                                    );

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2018-01-29
  *     创建者：周建刚
  *   功能说明：根据接口表 INTF_BD_ITEM_CMDM 更新产品正式表记录
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SYC_ITEM_UPDATE_CMDM(
                                  P_RESULT           IN OUT NUMBER, --返回错误ID
                                  P_ERR_MSG          IN OUT VARCHAR2 --返回错误信息
                                  );

  -- Author  : ZHOULY2
  -- Created : 2018/09/05 10:49:20
  -- Purpose : 检查产品引入是否存在及套散件保存
  ----------------------------------------------------------------------
  PROCEDURE P_CHECK_BD_ITEM_IMPORT(P_ENTITY_ID   IN NUMBER,
                                
                                   P_RESULT_CODE OUT VARCHAR2,
                                   P_RESULT_MSG  OUT VARCHAR2);
  ----------------------------------------------------------------------
  -- Author  : ZHOULY2
  -- Created : 2018/09/05 10:49:20
  -- Purpose : 保存或更新t_bd_item
  ----------------------------------------------------------------------
  PROCEDURE P_CHECK_BD_ITEM_IMPORT_SAVE(P_ENTITY_ID   IN NUMBER,
                                        P_SQL         IN VARCHAR2,
                                        P_RESULT_CODE OUT VARCHAR2,
                                        P_RESULT_MSG  OUT VARCHAR2);
  ----------------------------------------------------------------------
  -------------------------------------------------------------------------------
  /*
    *   创建日期：2018-10-08
    *   功能说明：预测新品生成产品产地关系
    */
  -------------------------------------------------------------------------------
  PROCEDURE P_VIRSUAL_ITEM_PRODUCT_AREA(IN_ENTITY_ID       IN NUMBER, --主体ID
                              P_SOURCE_ITEM_CODE IN VARCHAR2, --来源产品编码
                              P_NEW_ITEM_CODE    IN VARCHAR2, --预测新品编码
                              P_RESULT           IN OUT NUMBER, --返回错误ID
                              P_ERR_MSG          IN OUT VARCHAR2 --返回错误信息
                              );
END PKG_BD_ITEM;
/

