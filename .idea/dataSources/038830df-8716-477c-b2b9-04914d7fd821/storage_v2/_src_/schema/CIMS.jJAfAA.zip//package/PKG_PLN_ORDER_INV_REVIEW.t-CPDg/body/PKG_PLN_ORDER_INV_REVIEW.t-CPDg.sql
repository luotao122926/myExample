create Package Body      Pkg_Pln_Order_Inv_Review Is

  v_Nl Constant Varchar2(2) := Chr(13) || Chr(10); --换行
  --FLAG常量定义
  v_True    Constant Varchar2(2) := 'Y';
  v_False   Constant Varchar2(2) := 'N';
  v_Result  Constant Number := 0; --成功返回
  v_Success Constant Varchar2(10) := 'SUCCESS';
  v_Base_Exception Exception; --自定义异常

  --------------------------------------------------------------------------------------------
  -- Author  : 李振
  -- Created : 2014-07-02 11:05:52
  -- Purpose : 计划订单管理 订单汇总功能库存评审自动库存评审
  --
  --------------------------------------------------------------------------------------------
  Procedure p_Auto_Inv_Review(p_Collect_Head_Id In Number, --汇总订单头ID
                              p_Inv_Review_Type In Number, --库存评审类型：1：汇总库存评审 2：计划订单库存评审 3:汇总库存评审(选择了具体汇总行和订单信息) lilh6 2017-8-22
                              p_Entity_Id       In Number, --主体ID
                              p_User_Code       In Varchar2, --用户ID
                              p_Result          Out Number, --错误返回值
                              p_Err_Msg         Out Varchar2) Is
    Cursor c_Collect_Head Is
      Select *
        From t_Pln_Order_Collect_Head Och
       Where Och.Coll_Ord_Head_Id = p_Collect_Head_Id
         And Och.Form_State = '282' -- '已汇总'
         And Och.Entity_Id = p_Entity_Id
         For Update Nowait;
    r_Collect_Head c_Collect_Head%Rowtype;

    Cursor c_Collect_Line Is
      SELECT *
        FROM T_PLN_ORDER_COLLECT_LINE OCL
       WHERE OCL.COLL_ORD_HEAD_ID = P_COLLECT_HEAD_ID
         AND OCL.ENTITY_ID = P_ENTITY_ID
         AND OCL.IS_INV_CHK = 'Y'
         --lilh6 2017-8-22 增加汇总类型判断，为3的要过滤掉没选择的汇总行
         AND (P_INV_REVIEW_TYPE <> 3 OR
             (P_INV_REVIEW_TYPE = 3 AND EXISTS
              (SELECT 1
                  FROM T_PLN_AUTO_INV_REVIEW_INFO I
                 WHERE I.COLLECT_HEAD_ID = P_COLLECT_HEAD_ID
                   AND I.COLLECT_LINE_ID = OCL.COLL_ORD_LINE_ID
                   AND I.INV_CHECKED_FLAG = 'N')));  --为N表示还没有用作自动库存评审
    r_Collect_Line c_Collect_Line%Rowtype;
    v_Return       Number;
    v_Msg          Varchar2(2000);
  Begin
    p_Result  := v_Result;
    p_Err_Msg := v_Success;
    If p_Collect_Head_Id Is Null Or p_Collect_Head_Id Is Null Then
      p_Result  := -21000;
      p_Err_Msg := '传入参数错误，参数不许为空：P_COLLECT_HEAD_ID=' ||
                   To_Char(p_Collect_Head_Id) || '，P_ENTITY_ID=' ||
                   To_Char(p_Entity_Id);
      Raise v_Base_Exception;
    End If;
    --单单库存评审，自动评审
    If p_Inv_Review_Type = 2 Then
      p_Single_Auto_Inv_Review(p_Collect_Head_Id => p_Collect_Head_Id,
                               p_Coolect_Line_Id => -1,
                               p_Inv_Review_Type => p_Inv_Review_Type, --库存评审类型：1：汇总库存评审 2：计划订单库存评审 3:汇总库存评审(选择了具体汇总行和订单信息)
                               p_Entity_Id       => p_Entity_Id,
                               p_User_Code       => p_User_Code,
                               p_Result          => v_Return,
                               p_Err_Msg         => v_Msg);
      If v_Return <> v_Result Then
        p_Result  := -21000;
        p_Err_Msg := v_Msg;
        Raise v_Base_Exception;
      End If;
    Else
      --订单汇总自动库存评审处理
      Open c_Collect_Head;
      Fetch c_Collect_Head
        Into r_Collect_Head;
      If c_Collect_Head%Notfound Then
        p_Result  := -21000;
        p_Err_Msg := '锁定订单汇总头表数据失败，订单头ID：P_COLLECT_HEAD_ID=' ||
                     To_Char(p_Collect_Head_Id) || '。';
        Raise v_Base_Exception;
      End If;

      --开始循环行表数据
      Open c_Collect_Line;
      Loop
        Fetch c_Collect_Line
          Into r_Collect_Line;
        --无数据或者异常时退出循环
        Exit When c_Collect_Line%Notfound Or p_Result <> v_Result;
        p_Single_Auto_Inv_Review(p_Collect_Head_Id => r_Collect_Line.Coll_Ord_Head_Id,
                                 p_Coolect_Line_Id => r_Collect_Line.Coll_Ord_Line_Id,
                                 p_Inv_Review_Type => p_Inv_Review_Type, --库存评审类型：1：汇总库存评审 2：计划订单库存评审 3:汇总库存评审(选择了具体汇总行和订单信息)
                                 p_Entity_Id       => p_Entity_Id,
                                 p_User_Code       => p_User_Code,
                                 p_Result          => v_Return,
                                 p_Err_Msg         => v_Msg);
        If v_Return <> v_Result Then
          p_Result  := -21000;
          p_Err_Msg := v_Msg;
          Raise v_Base_Exception;
        End If;
      End Loop;
      Close c_Collect_Head;
      --add by lizhen 2015-04-15 自动评审完成后更新标志为Y
      Update t_Pln_Order_Collect_Line Cl
         Set Cl.Is_Inv_Chk = 'Y'
       Where Cl.Coll_Ord_Head_Id = p_Collect_Head_Id;

       --lilh6 2017-08-22 自动评审完成后更新标志为Y
       UPDATE T_PLN_AUTO_INV_REVIEW_INFO i
          SET i.inv_checked_flag = 'Y'
        WHERE i.collect_head_id = p_Collect_Head_Id
          AND I.INV_CHECKED_FLAG = 'N';

    End If;
    --程序错误，回滚数据
    If p_Result <> v_Result Then
      Rollback;
    End If;
  Exception
    When v_Base_Exception Then
      p_Result  := -21000;
      p_Err_Msg := '异常过程：Pkg_Pln_Order_Inv_Review.p_Auto_Inv_Review'
        || v_Nl ||  '错误：' || p_Err_Msg;
      Rollback;
    When Others Then
      p_Result  := -21000;
      p_Err_Msg := '异常过程：Pkg_Pln_Order_Inv_Review.p_Auto_Inv_Review'
        || v_Nl ||  '错误：' || Sqlerrm;
      Rollback;
  End;

  --------------------------------------------------------------------------------------------
  -- Author  : 李振
  -- Created : 2014-07-02 11:05:52
  -- Purpose : 计划订单管理 订单汇总功能单行库存评审自动库存评审
  --           库存评审类型=2时，P_COLLECT_HEAD_ID传入计划订单头ID
  --------------------------------------------------------------------------------------------
  Procedure p_Single_Auto_Inv_Review(p_Collect_Head_Id In Number, --汇总订单头ID
                                     p_Coolect_Line_Id In Number, --汇总订行头ID
                                     p_Inv_Review_Type In Number, --库存评审类型：1：汇总库存评审 2：计划订单库存评审
                                     p_Entity_Id       In Number, --主体ID
                                     p_User_Code       In Varchar2,
                                     p_Result          Out Number,
                                     p_Err_Msg         Out Varchar2) Is
    v_pln_auto_inv_review varchar2(32);  --lilh6 2017-7-14 T+3自动库存评审模式
    Cursor c_Order Is
    SELECT *
      FROM (SELECT POL.ITEM_ID,
                   POL.ITEM_CODE,
                   POL.ITEM_DESC,
                   POL.PRODUCING_AREA_ID,
                   POH.CUSTOMER_ID,
                   POH.CUSTOMER_CODE,
                   POH.CUSTOMER_NAME,
                   POL.ORDER_LINE_ID,
                   POL.ORDER_HEAD_ID,
                   POH.ORDER_NUMBER,
                   DECODE(NVL(POL.ADJUST_QTY, 0),
                          0,
                          NVL(POL.CENTER_CHECK_QTY, POL.APPLY_QTY),
                          POL.ADJUST_QTY) - NVL(POL.INV_AFFIRM_QTY, 0) APPLY_QTY,
                   POH.ORDER_TYPE_NAME,
                   POH.SALES_CENTER_ID,
                   POH.SALES_CENTER_CODE,
                   POH.SALES_CENTER_NAME,
                   --lilh6 2017-7-14 获取T+3订单对应的提货订单的最早的送总部评审时间
                   NVL((SELECT MIN(LOH.CENTER_CHECKUP_DATE)
                         FROM T_PLN_LG_ORDER_HEAD LOH, T_PLN_LG_RELATION R
                        WHERE R.ORDER_LINE_ID = POL.ORDER_LINE_ID
                          AND R.LG_ORDER_HEAD_ID = LOH.ORDER_HEAD_ID
                          AND V_PLN_AUTO_INV_REVIEW = 'Y'),
                       SYSDATE) CENTER_CHECKUP_DATE
              FROM T_PLN_ORDER_COLLECT_LINE     OCL,
                   T_PLN_ORDER_HEAD             POH,
                   T_PLN_ORDER_LINE             POL,
                   T_PLN_ORDER_COLLECT_RELATION OOR
             WHERE OOR.COLL_ORD_LINE_ID = OCL.COLL_ORD_LINE_ID
               AND OOR.ORDER_LINE_ID = POL.ORDER_LINE_ID
               AND POH.ORDER_HEAD_ID = POL.ORDER_HEAD_ID
                  --And Poh.Form_State In ('281', '282', '25') --'已汇总'
               AND OCL.COLL_ORD_HEAD_ID = P_COLLECT_HEAD_ID
               AND OCL.COLL_ORD_LINE_ID = P_COOLECT_LINE_ID
               AND OCL.ENTITY_ID = P_ENTITY_ID
               AND (P_INV_REVIEW_TYPE = 1 OR --lilh6 2017-8-22 增加汇总类型判断，为3的要过滤掉没选择的订单
                   (P_INV_REVIEW_TYPE = 3 AND EXISTS
                    (SELECT 1
                        FROM T_PLN_AUTO_INV_REVIEW_INFO I
                       WHERE I.COLLECT_HEAD_ID = P_COLLECT_HEAD_ID
                         AND I.COLLECT_LINE_ID = P_COOLECT_LINE_ID
                         AND (I.ORDER_HEAD_ID = POL.ORDER_HEAD_ID AND
                             I.ORDER_LINE_ID = POL.ORDER_LINE_ID OR
                             (I.ORDER_HEAD_ID IS NULL AND
                             I.ORDER_LINE_ID IS NULL))
                         AND I.INV_CHECKED_FLAG = 'N')))
            UNION ALL
            SELECT POL.ITEM_ID,
                   POL.ITEM_CODE,
                   POL.ITEM_DESC,
                   POL.PRODUCING_AREA_ID,
                   POH.CUSTOMER_ID,
                   POH.CUSTOMER_CODE,
                   POH.CUSTOMER_NAME,
                   POL.ORDER_LINE_ID,
                   POL.ORDER_HEAD_ID,
                   POH.ORDER_NUMBER,
                   DECODE(NVL(POL.ADJUST_QTY, 0),
                          0,
                          NVL(POL.CENTER_CHECK_QTY, POL.APPLY_QTY),
                          POL.ADJUST_QTY) - NVL(POL.INV_AFFIRM_QTY, 0) APPLY_QTY,
                   POH.ORDER_TYPE_NAME,
                   POH.SALES_CENTER_ID,
                   POH.SALES_CENTER_CODE,
                   POH.SALES_CENTER_NAME,
                   SYSDATE CENTER_CHECKUP_DATE
              FROM T_PLN_ORDER_HEAD POH, T_PLN_ORDER_LINE POL
             WHERE POH.ORDER_HEAD_ID = POL.ORDER_HEAD_ID
                  --And Poh.Form_State = '20' --'已送审'
               AND P_INV_REVIEW_TYPE = 2
               AND POH.ENTITY_ID = P_ENTITY_ID
               AND POH.ORDER_HEAD_ID = P_COLLECT_HEAD_ID) A
     ORDER BY CENTER_CHECKUP_DATE, PRODUCING_AREA_ID, APPLY_QTY;
    R_ORDER C_ORDER%ROWTYPE;

    CURSOR C_PLN_PRODUCING_ARAE IS
      SELECT ARI.INVENTORY_ID,
             II.INVENTORY_CODE,
             II.INVENTORY_NAME,
             II.SALES_CENTER_FLAG,
             II.BASE_FLAG,
             MIN(PCP.PRODUCING_AREA_PRIORITY) PRIORITY,
             II.ENTITY_ID
        FROM T_PLN_CUSTOMER_PRIORITY       PCP,
             T_PLN_PRDC_AREA_RCV_INVENTORY ARI,
             T_PLN_PRODUCING_AREA          PPA,
             T_INV_INVENTORIES             II
       WHERE PCP.SALES_CENTER_ID = 0
         AND PCP.ENTITY_ID = 0
         AND ARI.PRODUCING_AREA_ID = PCP.PRODUCING_AREA_ID
         AND ARI.ENTITY_ID = PCP.ENTITY_ID
         AND PCP.ITEM_ID IS NULL
         AND PPA.PRODUCING_AREA_ID = PCP.PRODUCING_AREA_ID
         AND II.INVENTORY_ID = ARI.INVENTORY_ID
         AND II.BASE_FLAG = 'Y'
         AND II.INVENTORY_TYPE IN ('01')
         AND TRUNC(SYSDATE) BETWEEN ARI.BEGIN_DATE AND
             TRUNC(NVL(ARI.END_DATE, SYSDATE))
       GROUP BY ARI.INVENTORY_ID,
                II.INVENTORY_CODE,
                II.INVENTORY_NAME,
                II.ENTITY_ID,
                II.SALES_CENTER_FLAG,
                II.BASE_FLAG;

    Type c_Get_Pln_Producing_Arae Is Ref Cursor; --声明动态游标
    v_Pln_Producing_Arae c_Get_Pln_Producing_Arae;

    r_Pln_Producing_Arae c_Pln_Producing_Arae%Rowtype;

    v_Producing_Area_Id   Varchar2(400);
    v_Item_Inv_Onhand_Qty Number;
    v_Line_Inv_Affirm_Qty Number;
    v_Item_Occpuy_Qty     Number;
    v_Usable_Occupy_Qty   Number; --当前库评数量
    v_Return              Number;
    v_Msg                 Varchar2(2000);
    v_Action_Type         Varchar2(100);
    v_Pln_Wip_Ord_Match   Varchar2(10);
    v_Is_Rounding          Varchar2(10);
    v_Rounding_Count       Number;
    v_Rounding_Mod_Qty     Number;
  Begin
    p_Result  := v_Result;
    p_Err_Msg := v_Success;
    --获取工单与订单是否完全匹配参数
    v_Pln_Wip_Ord_Match := Pkg_Bd.f_Get_Parameter_Value('PLN_WIP_ORD_MATCH',
                                                        p_Entity_Id);
    --获取T+3订单自动库存评审逻辑 Y按中心送总部评审时间先后自动库存评审； N 按原来方式
    v_pln_auto_inv_review := Pkg_Bd.f_Get_Parameter_Value('PLN_AUTO_INV_REVIEW_MODEL',
                                                        p_Entity_Id);
    Open c_Order;
    Loop
      Fetch c_Order
        Into r_Order;
      Exit When c_Order%Notfound Or p_Result <> v_Result;
      /*v_Producing_Area_Id := Pkg_Pln_Pub.f_Get_Cen_Prod_Area_List(r_Order.Sales_Center_Id,
                                                                  r_Order.Item_Id,
                                                                  p_Entity_Id,
                                                                  p_User_Code);
      If Nvl(Length(v_Producing_Area_Id), 0) = 0 Then
        p_Result  := -21000;
        p_Err_Msg := '获取中心、商品对应的产地失败，中心编码：' || r_Order.Sales_Center_Code ||
                     '，商品编码：' || r_Order.Item_Code;
        Raise v_Base_Exception;
      End If;*/
      --add by lizhen 2015-03-26 获取产品凑整信息
      Begin
        Select Bi.Is_Rounding, Bi.Rounding_Cnt
          Into v_Is_Rounding, v_Rounding_Count
          From t_Bd_Item Bi
         Where Bi.Item_Code = r_Order.Item_Code
           And Bi.Entity_Id = p_Entity_Id;
      Exception
        When Others Then
          p_Result := '获取产品凑整信息失败！' || v_Nl || '产品编码：' ||
                      r_Order.Item_Code || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
      End;
      If Nvl(v_Is_Rounding, 'N') = 'Y' And
         Nvl(v_Rounding_Count, 0) = 0 Then
        p_Result := '产品设置凑整，但凑整数量为0。' || v_Nl ||
          '产品编码：' || r_Order.Item_Code;
        Raise v_Base_Exception;
      End If;

      --打开产地信息游标
      Begin
        Open v_Pln_Producing_Arae For 'Select *
           From (Select Pai.Inventory_Id,
                         Ii.Inventory_Code,
                         Ii.Inventory_Name,
                         Ii.Sales_Center_Flag,
                         Ii.Base_Flag,
                         Rank() Over(Order By Min(Pcp.Producing_Area_Priority) * Min(Pai.Priority)) Priority,
                         Ii.Entity_Id
                    From t_Pln_Customer_Priority        Pcp,
                         v_Pln_Producing_Area_Inventory Pai,
                         t_Pln_Producing_Area           Ppa,
                         t_Inv_Inventories              Ii
                   Where Pai.Entity_Id = ' || To_Char(p_Entity_Id) || '
                     And Nvl(Pai.Sales_Center_Id, Pcp.Sales_Center_Id(+)) = ' || To_Char(r_Order.Sales_Center_Id) || '
                     And Pai.Producing_Area_Id = Pcp.Producing_Area_Id(+)
                     And Pai.Entity_Id = Pcp.Entity_Id(+)
                     And Pcp.Item_Id(+) Is Null
                     And Pcp.Sales_Center_Id(+) = ' || To_Char(r_Order.Sales_Center_Id) || '
                     And Trunc(Sysdate) Between Pcp.Begin_Date(+) And
                         Trunc(Nvl(Pcp.End_Date(+), Sysdate))
                     And Ppa.Producing_Area_Id = Pai.Producing_Area_Id
                     And Ii.Inventory_Id = Pai.Inventory_Id
                     /*add by lizhen 2017-06-26增加客户OU组织过滤仓库*/
                     And ''Y'' = Pkg_Inv_Pub.f_Get_Custimer_Inv_Org(Ii.Entity_Id, ' || To_Char(r_Order.Customer_Id) || ', II.Organization_Id)
                     And Ii.Base_Flag = ''Y''
                     And Ii.Inventory_Type In (''01'')
                     And Trunc(Sysdate) Between Pai.Begin_Date And
                         Trunc(Nvl(Pai.End_Date, Sysdate))
                    /*过滤中心与电商的关系*/
                     And (Pai.Inv_Type = ''EC_BASE_INV'' And Exists
                          (Select 1
                             From Cims.t_Pln_Prdc_Area_Ec_Inventory Aei
                            Where Aei.Sales_Center_Id = ' || To_Char(r_Order.Sales_Center_Id) || '
                              And Aei.Inventory_Id = Pai.Inventory_Id
                              And Aei.Producing_Area_Id = Pai.Producing_Area_Id) Or
                          Pai.Inv_Type = ''BASE_INV''
                          /* add by ex_liangcx 2019-11-26 增加最高优先级产地过滤仓库*/
        and exists
        (SELECT 1
           FROM T_Pln_Prdc_Area_Rcv_Inventory ari
          where ari.inventory_id = pai.inventory_id
            and ari.producing_area_id in
                (select t.producing_area_id
                   from T_Pln_Item_Producing_Area t
                  where t.item_id = ' || To_Char(r_Order.Item_Id)
                  || 'and t.producing_area_priority =
                        (select min(ipa.producing_area_priority)
                           from T_Pln_Item_Producing_Area ipa
                          where ipa.item_code = t.item_code
              and sysdate < nvl(ipa.end_date, sysdate) + 1
                          and sysdate >= ipa.begin_date))))
              AND II.DOCKING_SYSTEM <> ''VIRTUAL''
                   Group By Pai.Inventory_Id,
                            Ii.Inventory_Code,
                            Ii.Inventory_Name,
                            Ii.Entity_Id,
                            Ii.Sales_Center_Flag,
                            Ii.Base_Flag) Inv
          Where Pkg_Inv_Pub.f_Get_Item_Inv_Qoh(p_Entity_Id    => ' || To_Char(p_Entity_Id) ||
                                             ',p_Inventory_Id => Inv.Inventory_Id
                                              ,p_Item_Id      => ' || To_Char(r_Order.Item_Id) ||
                                             ',p_User_Code    => ''' || p_User_Code || '''' ||
                                             ',p_Get_Qoh_Type => 2) > 0
          Order By Priority';
      Exception
        When No_Data_Found Then
          Null;
        When Others Then
          p_Result  := -21000;
          p_Err_Msg := '查询中心辐射产地对应仓库信息失败。' || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
      End;

      Loop
        Fetch v_Pln_Producing_Arae
          Into r_Pln_Producing_Arae;
        Exit When v_Pln_Producing_Arae%Notfound;
        --重新查询订单行可库评审数量 = 订单申请数量 - 订单已库评数量
        Begin
          --modi by lizhen 2015-02-04 数量由原来的APPLY_QTY字段改为CHECK_QTY
          Select Nvl(Ol.center_check_qty, Ol.Apply_Qty) - Nvl(Ol.Inv_Affirm_Qty, 0)
            Into v_Line_Inv_Affirm_Qty
            From t_Pln_Order_Line Ol
           Where Ol.Order_Line_Id = r_Order.Order_Line_Id;
        Exception
          When Others Then
            p_Result  := -21000;
            p_Err_Msg := '获取订单行可库存评审数量失败，订单行ID：' ||
                         To_Char(r_Order.Order_Line_Id) || v_Nl || Sqlerrm;
            Raise v_Base_Exception;
        End;
        v_Item_Inv_Onhand_Qty := Pkg_Inv_Pub.f_Get_Item_Inv_Qoh(p_Entity_Id    => p_Entity_Id,
                                                                p_Inventory_Id => r_Pln_Producing_Arae.Inventory_Id,
                                                                p_Item_Id      => r_Order.Item_Id,
                                                                p_User_Code    => p_User_Code,
                                                                p_Get_Qoh_Type => 2);

        v_Usable_Occupy_Qty := Least(nvl(v_Item_Inv_Onhand_Qty, 0),
                                     nvl(v_Line_Inv_Affirm_Qty, 0));
        --add by lizhen 2015-03-26 检查产品凑整数量
        Select Mod(v_Usable_Occupy_Qty,
                   Decode(Nvl(v_Is_Rounding, 'N'), 'Y', v_Rounding_Count, 1))
          Into v_Rounding_Mod_Qty
          From Dual;
        v_Usable_Occupy_Qty := v_Usable_Occupy_Qty - Nvl(v_Rounding_Mod_Qty, 0);
        If v_Usable_Occupy_Qty > 0 Then
          Update t_Pln_Order_Inv_Review Ir
             Set Ir.Affirm_Qty       = Nvl(Ir.Affirm_Qty, 0) +
                                       v_Usable_Occupy_Qty,
                 Ir.Last_Updated_By  = p_User_Code,
                 Ir.Last_Update_Date = Sysdate
           Where Ir.Order_Head_Id = r_Order.Order_Head_Id
             And Ir.Order_Line_Id = r_Order.Order_Line_Id
             And Ir.Inventory_Id = r_Pln_Producing_Arae.Inventory_Id
             And Ir.Item_Id = r_Order.Item_Id;
          If Sql%Notfound Then
            Begin
              Insert Into t_Pln_Order_Inv_Review
                (Entity_Id, --主体ID
                 Order_Inv_Id,
                 Order_Line_Id, --订单行ID
                 Order_Head_Id, --订单头ID
                 Head_Id, --汇总头ID
                 Line_Id, --汇总行ID
                 Inventory_Id, --仓库ID
                 Inventory_Code, --仓库编码
                 Inventory_Name, --仓库名称
                 Item_Id, --产品ID
                 Item_Code, --产品编码
                 Item_Name, --产品描述
                 Affirm_Type, --评审类型  单单，汇总
                 Affirm_Qty, --评审数量
                 Cancel_Qty, --取消数量
                 Cancel_Flag, --取消标志
                 Affirming_Qty, --待库评数量
                 Created_By, --创建人
                 Creation_Date, --创建日期
                 Last_Updated_By, --最后修改人
                 Last_Update_Date, --最后修改日期
                 Remark,
                 Pre_Field_01,
                 Pre_Field_02,
                 Pre_Field_03,
                 Pre_Field_04,
                 Pre_Field_05,
                 Pre_Field_06)
                Select p_Entity_Id, -- ENTITY_ID, --主体ID
                       s_Pln_Order_Inv_Review.Nextval,
                       r_Order.Order_Line_Id, --ORDER_LINE_ID, --订单行ID
                       r_Order.Order_Head_Id, --ORDER_HEAD_ID --订单头ID
                       Decode(p_Inv_Review_Type, 2, -1, p_Collect_Head_Id), --COLL_HEAD_ID, --汇总头ID
                       Decode(p_Inv_Review_Type, 2, -1, p_Coolect_Line_Id), --COLL_LINE_ID, --汇总行ID
                       r_Pln_Producing_Arae.Inventory_Id, -- INVENTORY_ID, --仓库ID
                       r_Pln_Producing_Arae.Inventory_Code, --INVENTORY_CODE, --仓库编码
                       r_Pln_Producing_Arae.Inventory_Name, --INVENTORY_NAME, --仓库名称
                       r_Order.Item_Id, --ITEM_ID, --产品ID
                       r_Order.Item_Code, --ITEM_CODE, --产品编码
                       r_Order.Item_Desc, --ITEM_DESC, --产品描述
                       Decode(p_Inv_Review_Type, 2, '单单', '汇总'), --AFFIRM_TYPE, --评审类型  单单，汇总
                       v_Usable_Occupy_Qty, --AFFIRM_QTY, --评审数量
                       0 Cancel_Qty, --取消数量
                       v_False, -- CANCEL_FLAG, --取消标志
                       Null,  --待评审数量
                       p_User_Code, --CREATED_BY, --创建人
                       Sysdate, --CREATION_DATE, --创建日期
                       p_User_Code, --LAST_UPDATED_BY, --最后修改人
                       Sysdate, --LAST_UPDATE_DATE, --最后修改日期
                       Null Remark,
                       Null Pre_Field_01,
                       Null Pre_Field_02,
                       Null Pre_Field_03,
                       Null Pre_Field_04,
                       Null Pre_Field_05,
                       Null Pre_Field_06
                  From Dual;
            Exception
              When Others Then
                p_Result  := -21000;
                p_Err_Msg := '插入订单库存评审明细表失败。' || v_Nl || Sqlerrm;
                Raise v_Base_Exception;
            End;
          End If;

          Begin
            Select Decode(p_Inv_Review_Type,
                          1,
                          '汇总订单库存评审',
                          r_Order.Order_Type_Name || '库存评审')
              Into v_Action_Type
              From Dual;

            Pkg_Pln_Inv_Occupy.p_Affirm_Occupy_Stocks(p_Inventory_Id     => r_Pln_Producing_Arae.Inventory_Id, --仓库ID
                                                      p_Item_Id          => r_Order.Item_Id, --产品ID
                                                      p_Occupy_Qty       => v_Usable_Occupy_Qty, --占用数量
                                                      p_Match_Pln_To_Wip => 'Y', --工单与订单完全匹配标志 Y:完全匹配  N:非完全匹配
                                                      --P_OPERATION_TYPE    =>, --操作类型(1:库存评审  2:中转入库  3:销售开单  4:杂项(含：41:破损调拨、42:盘盈亏、43:采购退货))
                                                      p_Action_Desc       => v_Action_Type, --单据操作描述 例：中转单据执行、中转红冲单执行
                                                      p_Entity_Id         => p_Entity_Id, --主体ID
                                                      p_Origin_Type       => r_Order.Order_Type_Name, --来源类型
                                                      p_Origin_Head_Id    => r_Order.Order_Head_Id, --来源头ID
                                                      p_Origin_Number     => r_Order.Order_Number, --来源头编码
                                                      p_Origin_Line_Id    => r_Order.Order_Line_Id, --来源行ID
                                                      p_Source_Order_Type => r_Order.Order_Type_Name, --事务来源单据类型
                                                      p_Source_Head_Id    => r_Order.Order_Head_Id, --事务来源头ID
                                                      p_Source_Number     => r_Order.Order_Number, --事务来源头编码
                                                      p_Source_Line_Id    => r_Order.Order_Line_Id, --事务来源行ID
                                                      p_User_Code         => p_User_Code, --用户ID
                                                      p_Result            => v_Return, --返回错误ID
                                                      p_Err_Msg           => v_Msg --返回错误信息
                                                      );
            If v_Return <> v_Result Then
              p_Result  := -21000;
              p_Err_Msg := '库存占用失败，仓库编码：' ||
                           r_Pln_Producing_Arae.Inventory_Code || '，产品编码：' ||
                           r_Order.Item_Code || '，库存占用数量：' ||
                           To_Char(v_Usable_Occupy_Qty) || '。' || v_Nl ||
                           v_Msg;
              Raise v_Base_Exception;
            End If;
          Exception
            When Others Then
              p_Result  := -21000;
              p_Err_Msg := '库存占用失败，仓库编码：' ||
                           r_Pln_Producing_Arae.Inventory_Code || '，产品编码：' ||
                           r_Order.Item_Code || '，库存占用数量：' ||
                           To_Char(v_Usable_Occupy_Qty);
              Raise v_Base_Exception;
          End;

          --更新行表库存评审数量
          Update t_Pln_Order_Line l
             Set l.Inv_Affirm_Qty   = Nvl(l.Inv_Affirm_Qty, 0) +
                                      v_Usable_Occupy_Qty,
                 l.Check_Qty        = Decode(Nvl(l.Adjust_Qty, 0),
                                             0,
                                             Nvl(l.center_check_qty, l.Apply_Qty),
                                             l.Adjust_Qty) -
                                      (Nvl(l.Inv_Affirm_Qty, 0) +
                                       v_Usable_Occupy_Qty),
                 l.Can_Produce_Qty  = Decode(Nvl(l.Adjust_Qty, 0),
                                             0,
                                             Nvl(l.center_check_qty, l.Apply_Qty),
                                             l.Adjust_Qty) -
                                      (Nvl(l.Inv_Affirm_Qty, 0) +
                                       v_Usable_Occupy_Qty),
                 l.Last_Updated_By  = p_User_Code,
                 l.Last_Update_Date = Sysdate
           Where l.Order_Line_Id = r_Order.Order_Line_Id;
        End If;
        /*--更新排产数量后再做
        If p_Err_Msg = v_Success Then
          pkg_pln_shares.p_Auto_Create_Share(p_Pln_Order_Line_Id => r_Order.Order_Line_Id, --订单行ID
                                             p_Inventory_Id      => r_Pln_Producing_Arae.Inventory_Id, --仓库ID(财务仓)
                                             p_Trans_Sign_Flag   => 1, --生成发货计划方向，1：生成发货计划  -1：取消发货计划
                                             p_Trans_Share_Qty   => v_Usable_Occupy_Qty, --分配数量（只传正数）
                                             p_Entity_Id         => p_Entity_Id, --主体ID
                                             p_Pln_Wip_Ord_Match => v_Pln_Wip_Ord_Match, --工单与订单新匹配模式
                                             p_User_Code         => p_User_Code,
                                             p_Result            => p_Err_Msg);
          If p_Err_Msg <> v_Success Then
             Raise v_Base_Exception;
          End If;
        End If; */
      End Loop;
    End Loop;
    If p_Result <> v_Result Then
      Rollback;
      p_Result  := -21000;
      p_Err_Msg := p_Err_Msg || v_Nl || Sqlerrm;
    End If;
  Exception
    When v_Base_Exception Then
      p_Result  := -21000;
      p_Err_Msg := p_Err_Msg || v_Nl || Sqlerrm;

    When Others Then
      p_Result  := -21000;
      p_Err_Msg := '失败：' || v_Nl || Sqlerrm;
  End;

  --------------------------------------------------------------------------------------------
  -- Author  : 李振
  -- Created : 2014-07-08 11:05:52
  -- Purpose : 计划订单管理 计划订单库存评审库存锁定检查现有量
  -- Return:  R_RESULT返回值： 0：无错误    -21000：程序错误中断处理
  --          R_ERR_MSG: SUCCESS:无错误     其它（信息）：程序错误信息说明
  --------------------------------------------------------------------------------------------
  Procedure p_Item_Usable_Onhand_Check(p_Head_Id         In Number, --汇总订单头ID
                                       p_Line_Id         In Number, --汇总订行头ID
                                       p_Inv_Review_Type In Number, --库存评审类型：1：汇总库存评审 2：计划订单库存评审
                                       p_Entity_Id       In Number, --主体ID
                                       p_Result          Out Varchar2) Is
    Cursor c_Inv_Review Is
      Select *
        From t_Pln_Order_Inv_Review Osa
       Where ((p_Inv_Review_Type = 1 And Osa.Head_Id = p_Head_Id And
             Osa.Line_Id = p_Line_Id) Or
             (p_Inv_Review_Type = 2 And Osa.Order_Head_Id = p_Head_Id And
             Osa.Order_Line_Id = p_Line_Id))
         And Osa.Entity_Id = p_Entity_Id
         And Osa.Affirming_Qty Is Not Null;
    r_Inv_Review c_Inv_Review%Rowtype;

    v_Item_Onhand_Qty     Number := 0;
    v_Line_Apply_Qty      Number := 0;
    v_Line_Inv_Affirm_Qty Number := 0;
    v_Sum_Inv_Review_Qty  Number := 0;
    v_Order_Type_Id       t_Pln_Order_Type.Order_Type_Id%Type;
    v_Match_Pln_To_Wip    Varchar2(10); --订单与工单中转匹配方式
  Begin
    p_Result := v_Success;
    --检查库存评审商品的库存可用量
    Open c_Inv_Review;
    Loop
      Fetch c_Inv_Review
        Into r_Inv_Review;
      Exit When c_Inv_Review%Notfound;
      v_Item_Onhand_Qty := Pkg_Inv_Pub.f_Get_Item_Inv_Qoh(p_Entity_Id         => p_Entity_Id,
                                                          p_Inventory_Id      => r_Inv_Review.Inventory_Id,
                                                          p_Item_Id           => r_Inv_Review.Item_Id,
                                                          p_User_Code         => r_Inv_Review.Created_By,
                                                          p_Get_Qoh_Type      => 2,
                                                          p_Count_Occoup_Flag => 'Y');

      If v_Item_Onhand_Qty + Nvl(r_Inv_Review.Affirm_Qty, 0) < r_Inv_Review.Affirming_Qty Then
        p_Result := '商品编码：' || r_Inv_Review.Item_Code || '，仓库编码：' ||
                    r_Inv_Review.Item_Code || '，库存可用量(' ||
                    To_Char(v_Item_Onhand_Qty) || ')小于本次库存评审数量(' ||
                    To_Char(r_Inv_Review.Affirm_Qty) || ')' || v_Nl;
        Raise v_Base_Exception;
      End If;
      --检查订单行表的已库存评库量+本次评审量，是否超过申请数量
      Begin
        Select Decode(Nvl(Ol.Adjust_Qty, 0), 0, Ol.Apply_Qty, Ol.Adjust_Qty),
               Nvl(Ol.Inv_Affirm_Qty, 0)
          Into v_Line_Apply_Qty, v_Line_Inv_Affirm_Qty
          From t_Pln_Order_Line Ol
         Where Ol.Order_Line_Id = r_Inv_Review.Order_Line_Id;
      Exception
        When Others Then
          p_Result := '获取订单行失败，订单行ID：' ||
                      To_Char(r_Inv_Review.Order_Line_Id) || v_Nl ||
                      Sqlerrm;
          Raise v_Base_Exception;
      End;
      --非本次库评的库存评审数量
      Select Sum(Oir.Affirm_Qty)
        Into v_Line_Inv_Affirm_Qty
        From t_Pln_Order_Inv_Review Oir
       Where Oir.Order_Line_Id = r_Inv_Review.Order_Line_Id
         And oir.affirming_qty Is Null
         And Oir.Entity_Id = p_Entity_Id;
      --本次评审数量
      Select Sum(Oir.Affirming_Qty)
        Into v_Sum_Inv_Review_Qty
        From t_Pln_Order_Inv_Review Oir
       Where Oir.Order_Line_Id = r_Inv_Review.Order_Line_Id
         And Oir.Entity_Id = p_Entity_Id;

      If v_Line_Apply_Qty - Nvl(v_Line_Inv_Affirm_Qty, 0) <
         v_Sum_Inv_Review_Qty Then
        p_Result := '订单行ID：' || To_Char(r_Inv_Review.Order_Line_Id) ||
                    '，本次库存评审数量（' || To_Char(v_Sum_Inv_Review_Qty) ||
                    '）大于订单行可库存评审数量（' ||
                    To_Char(v_Line_Apply_Qty -
                            Nvl(v_Line_Inv_Affirm_Qty, 0)) || '）';
        Raise v_Base_Exception;
      End If;
    End Loop;
    Close c_Inv_Review;
    If p_Result <> v_Success Then
      Raise v_Base_Exception;
    End If;
  Exception
    When v_Base_Exception Then
      p_Result := p_Result;
      Rollback;
    When Others Then
      p_Result := p_Result || v_Nl || Sqlerrm;
      Rollback;
  End;

  --------------------------------------------------------------------------------------------
  -- Author  : 李振
  -- Created : 2014-07-08 11:05:52
  -- Purpose : 计划订单管理 计划订单库存评审库存锁定处理
  -- Return:  R_RESULT返回值： 0：无错误    -21000：程序错误中断处理
  --          R_ERR_MSG: SUCCESS:无错误     其它（信息）：程序错误信息说明
  --------------------------------------------------------------------------------------------
  Procedure p_Inv_Review_Lock(p_Head_Id         In Number, --汇总订单头ID
                              p_Line_Id         In Number, --汇总订行头ID
                              p_Inv_Review_Type In Number, --库存评审类型：1：汇总库存评审 2：计划订单库存评审
                              p_Entity_Id       In Number, --主体ID
                              p_User_Code       In Varchar2,
                              p_Result          Out Number,
                              p_Err_Msg         Out Varchar2) Is
    Cursor c_Inv_Review Is
      Select *
        From t_Pln_Order_Inv_Review Osa
       Where ((p_Inv_Review_Type = 1 And Osa.Head_Id = p_Head_Id And
             Osa.Line_Id = p_Line_Id) Or
             (p_Inv_Review_Type = 2 And Osa.Order_Head_Id = p_Head_Id And
             Osa.Order_Line_Id = p_Line_Id))
         And Osa.Entity_Id = p_Entity_Id
         And Osa.Affirming_Qty Is Not Null
         For Update Nowait;
    r_Inv_Review c_Inv_Review%Rowtype;

    v_Order_Type_Id      t_Pln_Order_Type.Order_Type_Id%Type;
    v_Current_Affirm_Qty Number; --本次库存占用数量
    v_Match_Pln_To_Wip   Varchar2(10); --订单与工单中转匹配方式
    v_Order_Type_Name    t_Pln_Order_Type.Order_Type_Name%Type;
    v_Order_Number       t_Pln_Order_Head.Order_Number%Type;
    v_Form_State         Varchar(10);
    v_Flow_Id            Number;
    v_Count              Number;
    v_Is_Chk_Rounding    Varchar2(10);
    v_Rounding_Count       Number;
    v_Rounding_Mod_Qty     Number;
  Begin
    p_Result           := v_Result;
    p_Err_Msg          := v_Success;

    -- add by zhangcc
    If p_Inv_Review_Type = 1 Then
      Begin
        --add by lizhen 增加订单单据类类型奏整检查
        Select Oh.Form_State, Ot.Flow_Id, Ot.Is_Count
          Into v_Form_State, v_Flow_Id, v_Is_Chk_Rounding
          From t_Pln_Order_Collect_Head Oh, t_Pln_Order_Type Ot
         Where Oh.Coll_Ord_Head_Id = p_Head_Id
           And Ot.Order_Type_Id = Oh.Order_Type_Id;
      Exception
        When Others Then
          p_Result := '获取汇总订单头失败，汇总头ID：' || To_Char(p_Head_Id) || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
      End;
      --add by lizhen 2015-02-03 检查当前订单状态是否可以做库存评
      --防止并发问题
      Select Count(1)
        Into v_Count
        From t_Pln_Flow_Status Fs
       Where Fs.Flow_Id = v_Flow_Id
         And To_Char(Fs.Curr_Status_Id) = Trim(v_Form_State)
         And Fs.Next_Status_Id = 26;
      If Nvl(v_Form_State, '_') != '26' And v_Count = 0 Then
        p_Err_Msg := '汇总订单头状态已不在库存评审范围内。' || v_Nl || '汇总订单头Id:' ||
                     p_Head_Id || v_Nl || '汇总订单头状态:' || v_Form_State;
        Raise v_Base_Exception;
      End If;
    End If;
    If p_Inv_Review_Type = 2 Then
      Begin
        Select Th.Form_State, Ot.Flow_Id
          Into v_Form_State, v_Flow_Id
          From t_Pln_Order_Head Th, t_Pln_Order_Type Ot
         Where Th.Order_Head_Id = p_Head_Id
           And Ot.Order_Type_Id = Th.Order_Type_Id
           And Ot.Entity_Id = Th.Entity_Id;
      Exception
        When Others Then
          p_Result := '获取订单头失败，订单头ID：' || To_Char(p_Head_Id) || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
      End;
      --add by lizhen 2015-02-03 检查当前订单状态是否可以做库存评
      --防止并发问题
      Select Count(1)
        Into v_Count
        From t_Pln_Flow_Status Fs
       Where Fs.Flow_Id = v_Flow_Id
         And To_Char(Fs.Curr_Status_Id) = Trim(v_Form_State)
         And Fs.Next_Status_Id = 26;
      If Nvl(v_Form_State, '_') != '26' And v_Count = 0 Then
        p_Err_Msg := '计划订单头状态已不在库存评审范围内。' || v_Nl || '计划订单头Id:' ||
                     p_Head_Id || v_Nl || '计划订单头状态:' || v_Form_State;
        Raise v_Base_Exception;
      End If;
    End If;
    ---
    v_Match_Pln_To_Wip := Pkg_Bd.f_Get_Parameter_Value('PLN_WIP_ORD_MATCH',
                                                       p_Entity_Id);
    --检查库存评审商品的库存可用量
    Begin
      p_Item_Usable_Onhand_Check(p_Head_Id         => p_Head_Id, --汇总订单头ID
                                 p_Line_Id         => p_Line_Id, --汇总订行头ID
                                 p_Inv_Review_Type => p_Inv_Review_Type, --库存评审类型：1：汇总库存评审 2：计划订单库存评审
                                 p_Entity_Id       => p_Entity_Id, --主体ID
                                 p_Result          => p_Err_Msg);
      If p_Err_Msg <> v_Success Then
        p_Result := -21000;
        Raise v_Base_Exception;
      End If;
    Exception
      When Others Then
        p_Result  := -21000;
        p_Err_Msg := '检查商品库存可用量失败！' || v_Nl || p_Err_Msg;
        Raise v_Base_Exception;
    End;

    /*If p_Result = v_Result Then
      --处理订单库存评审时，先清空已有评审数量
      Update t_Pln_Order_Line Ol
         Set Ol.Inv_Affirm_Qty = 0
       Where Ol.Order_Line_Id In
             (Select Osa.Order_Line_Id
                From t_Pln_Order_Inv_Review Osa
               Where ((p_Inv_Review_Type = 1 And Osa.Head_Id = p_Head_Id And
                     Osa.Line_Id = p_Line_Id) Or
                     (p_Inv_Review_Type = 2 And
                     Osa.Order_Head_Id = p_Head_Id And
                     Osa.Order_Line_Id = p_Line_Id))
                 And Osa.Entity_Id = p_Entity_Id);
    End If;*/
    Begin
      Open c_Inv_Review;
    Exception
      When Others Then
        p_Err_Msg := '获取库存评审行数据失败，订单行ID：' || To_Char(p_Line_Id) || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;
    Loop
      Fetch c_Inv_Review
        Into r_Inv_Review;
      Exit When c_Inv_Review%Notfound Or p_Result <> v_Result;
      If Nvl(v_Is_Chk_Rounding, 'N') = 'Y' Then
        --add by lizhen 2015-03-26 检查产品凑整信息
        Pkg_Pln_Pub.p_Check_Item_Rounding(p_Entity_Id => p_Entity_Id,
                                          p_Item_Id   => r_Inv_Review.Item_Id,
                                          p_Check_Qty => r_Inv_Review.Affirming_Qty,
                                          p_Result    => p_Err_Msg);
        If p_Err_Msg != v_Success Then
          p_Result  := -21000;
          Raise v_Base_Exception;
        End If;
      End If;
      Begin
        --获取订单单号、订单类型名称
        Select Poh.Order_Number, Pot.Order_Type_Name
          Into v_Order_Number, v_Order_Type_Name
          From t_Pln_Order_Head Poh, t_Pln_Order_Type Pot
         Where Pot.Order_Type_Id = Poh.Order_Type_Id
           And Poh.Entity_Id = p_Entity_Id
           And Poh.Order_Head_Id = r_Inv_Review.Order_Head_Id;
      Exception
        When Others Then
          p_Result  := -21000;
          p_Err_Msg := '获取订单单号失败，订单头ID：' || r_Inv_Review.Order_Head_Id;
          Raise v_Base_Exception;
      End;

      v_Current_Affirm_Qty := Nvl(r_Inv_Review.Affirming_Qty, 0) -
                              Nvl(r_Inv_Review.Affirm_Qty, 0);

      If v_Current_Affirm_Qty <> 0 Then
        --处理库存占用数据
        Begin
          Pkg_Pln_Inv_Occupy.p_Affirm_Occupy_Stocks(p_Inventory_Id      => r_Inv_Review.Inventory_Id, --仓库ID
                                                    p_Item_Id           => r_Inv_Review.Item_Id, --产品ID
                                                    p_Occupy_Qty        => v_Current_Affirm_Qty, --占用数量
                                                    p_Match_Pln_To_Wip  => v_Match_Pln_To_Wip, --工单与订单完全匹配标志 Y:完全匹配  N:非完全匹配
                                                    p_Action_Desc       => v_Order_Type_Name ||
                                                                           '库存评审', --单据操作描述 例：中转单据执行、中转红冲单执行
                                                    p_Entity_Id         => p_Entity_Id, --主体ID
                                                    p_Origin_Type       => '', --来源类型
                                                    p_Origin_Head_Id    => r_Inv_Review.Order_Head_Id, --来源头ID
                                                    p_Origin_Number     => v_Order_Number, --来源头编码
                                                    p_Origin_Line_Id    => r_Inv_Review.Order_Line_Id, --来源行ID
                                                    p_Source_Order_Type => v_Order_Type_Name, --事务来源单据类型
                                                    p_Source_Head_Id    => r_Inv_Review.Order_Head_Id, --事务来源头ID
                                                    p_Source_Number     => v_Order_Number, --事务来源头编码
                                                    p_Source_Line_Id    => r_Inv_Review.Order_Line_Id, --事务来源行ID
                                                    p_User_Code         => p_User_Code, --用户ID
                                                    p_Result            => p_Result, --返回错误ID
                                                    p_Err_Msg           => p_Err_Msg --返回错误信息
                                                    );
          If p_Result <> v_Result Then
            p_Result := -21000;
            Raise v_Base_Exception;
          End If;

          If p_Result = v_Result Then
            --更新订单库存评审表库存评审数量
            Update t_Pln_Order_Inv_Review Ir
               Set Ir.Affirm_Qty       = Ir.Affirming_Qty,
                   Ir.Last_Updated_By  = p_User_Code,
                   Ir.Last_Update_Date = Sysdate
             Where Ir.Order_Inv_Id = r_Inv_Review.Order_Inv_Id;

            Update t_Pln_Order_Inv_Review Ir
               Set Ir.Affirming_Qty = Null
             Where Ir.Order_Inv_Id = r_Inv_Review.Order_Inv_Id;
          End If;

          If p_Result = v_Result Then
            --更新订单行的库存评审数量
            Update t_Pln_Order_Line Ol
               Set Ol.Inv_Affirm_Qty   = Nvl(Ol.Inv_Affirm_Qty, 0) +
                                         Nvl(v_Current_Affirm_Qty, 0),
                   Ol.Check_Qty        = Decode(Nvl(Ol.Adjust_Qty, 0),
                                                0,
                                                Nvl(Ol.center_check_qty, Ol.Apply_Qty),
                                                Ol.Adjust_Qty) -
                                         (Nvl(Ol.Inv_Affirm_Qty, 0) +
                                          Nvl(v_Current_Affirm_Qty, 0)),
                   Ol.Can_Produce_Qty  = Decode(Nvl(Ol.Adjust_Qty, 0),
                                                0,
                                                Nvl(Ol.center_check_qty, Ol.Apply_Qty),
                                                Ol.Adjust_Qty) -
                                         (Nvl(Ol.Inv_Affirm_Qty, 0) +
                                          Nvl(v_Current_Affirm_Qty, 0)),
                   Ol.Last_Updated_By  = p_User_Code,
                   Ol.Last_Update_Date = Sysdate
             Where Ol.Order_Line_Id = r_Inv_Review.Order_Line_Id;
          End If;
        Exception
          When Others Then
            p_Result  := -21000;
            p_Err_Msg := '调用PKG_PLN_INV_OCCUPY.P_AFFIRM_OCCUPY_STOCKS处理占用失败！' || v_Nl ||
                         p_Err_Msg;
            Raise v_Base_Exception;
        End;
        /*--更新已排产数量后再生成分配行数信息
        --分配行生成放到订单排产后
        If p_Err_Msg = v_Success Then
            pkg_pln_shares.p_Auto_Create_Share(p_Pln_Order_Line_Id => r_Inv_Review.Order_Line_Id, --订单行ID
                                               p_Inventory_Id      => r_Inv_Review.Inventory_Id, --仓库ID(财务仓)
                                               p_Trans_Sign_Flag   => Sign(v_Current_Affirm_Qty), --生成发货计划方向，1：生成发货计划  -1：取消发货计划
                                               p_Trans_Share_Qty   => Abs(v_Current_Affirm_Qty), --分配数量（只传正数）
                                               p_Entity_Id         => p_Entity_Id, --主体ID
                                               p_Pln_Wip_Ord_Match => v_Match_Pln_To_Wip, --工单与订单新匹配模式
                                               p_User_Code         => p_User_Code,
                                               p_Result            => p_Err_Msg);
            If p_Err_Msg <> v_Success Then
               Raise v_Base_Exception;
            End If;
          End If;*/
      End If;
    End Loop;
    Close c_Inv_Review;
    --过程处理错误，报错误及回滚数据
    If p_Result <> v_Result Then
      p_Result := -21000;
      Rollback;
    End If;
  Exception
    When v_Base_Exception Then
      p_Result  := -21000;
      p_Err_Msg := '异常过程：Pkg_Pln_Order_Inv_Review.p_Inv_Review_Lock'
        || v_Nl || p_Err_Msg || v_Nl || Sqlerrm;
      Rollback;
    When Others Then
      p_Result  := -21000;
      p_Err_Msg := '异常过程：Pkg_Pln_Order_Inv_Review.p_Inv_Review_Lock'
        || v_Nl || replace(p_Err_Msg, v_Success, '') || v_Nl || Sqlerrm;
      Rollback;
  End;

  --------------------------------------------------------------------------------------------
  -- Author  : 李振
  -- Created : 2017-02-08 11:05:52
  -- Purpose : 计划订单管理 计划订单库存评审库存锁定处理
  --           T+3计划订单删除提货订单行信息时，解锁订单的库存占用数量
  -- Return:  R_RESULT返回值： 0：无错误    -21000：程序错误中断处理
  --          R_ERR_MSG: SUCCESS:无错误     其它（信息）：程序错误信息说明
  --------------------------------------------------------------------------------------------
  Procedure p_Inv_Review_Del_UnLock(p_Head_Id         In Number, --汇总订单头ID
                                    p_Line_Id         In Number, --汇总订行头ID
                                    p_Inv_Review_Type In Number, --库存评审类型：1：汇总库存评审 2：计划订单库存评审
                                    p_Entity_Id       In Number, --主体ID
                                    p_User_Code       In Varchar2,
                                    p_Result          Out Number,
                                    p_Err_Msg         Out Varchar2) Is
    Cursor c_Inv_Review Is
      Select *
        From t_Pln_Order_Inv_Review Osa
       Where ((p_Inv_Review_Type = 1 And Osa.Head_Id = p_Head_Id And
             Osa.Line_Id = p_Line_Id) Or
             (p_Inv_Review_Type = 2 And Osa.Order_Head_Id = p_Head_Id And
             Osa.Order_Line_Id = p_Line_Id))
         And Osa.Entity_Id = p_Entity_Id
         And Osa.Affirming_Qty Is Not Null
         For Update Nowait;
    r_Inv_Review c_Inv_Review%Rowtype;

    v_Order_Type_Id      t_Pln_Order_Type.Order_Type_Id%Type;
    v_Current_Affirm_Qty Number; --本次库存占用数量
    v_Match_Pln_To_Wip   Varchar2(10); --订单与工单中转匹配方式
    v_Order_Type_Name    t_Pln_Order_Type.Order_Type_Name%Type;
    v_Order_Number       t_Pln_Order_Head.Order_Number%Type;
    v_Form_State         Varchar(10);
    v_Flow_Id            Number;
    v_Count              Number;
    v_Is_Chk_Rounding    Varchar2(10);
    v_Rounding_Count       Number;
    v_Rounding_Mod_Qty     Number;
  Begin
    p_Result           := v_Result;
    p_Err_Msg          := v_Success;

    -- add by zhangcc
    If p_Inv_Review_Type = 1 Then
      Begin
        --add by lizhen 增加订单单据类类型奏整检查
        Select Oh.Form_State, Ot.Flow_Id, Ot.Is_Count
          Into v_Form_State, v_Flow_Id, v_Is_Chk_Rounding
          From t_Pln_Order_Collect_Head Oh, t_Pln_Order_Type Ot
         Where Oh.Coll_Ord_Head_Id = p_Head_Id
           And Ot.Order_Type_Id = Oh.Order_Type_Id;
      Exception
        When Others Then
          p_Result := '获取汇总订单头失败，汇总头ID：' || To_Char(p_Head_Id) || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
      End;
      --add by lizhen 2015-02-03 检查当前订单状态是否可以做库存评
      --防止并发问题
      /*Select Count(1)
        Into v_Count
        From t_Pln_Flow_Status Fs
       Where Fs.Flow_Id = v_Flow_Id
         And To_Char(Fs.Curr_Status_Id) = Trim(v_Form_State)
         And Fs.Next_Status_Id = 26;
      If Nvl(v_Form_State, '_') != '26' And v_Count = 0 Then
        p_Err_Msg := '汇总订单头状态已不在库存评审范围内。' || v_Nl || '汇总订单头Id:' ||
                     p_Head_Id || v_Nl || '汇总订单头状态:' || v_Form_State;
        Raise v_Base_Exception;
      End If;*/
    End If;
    If p_Inv_Review_Type = 2 Then
      Begin
        Select Th.Form_State, Ot.Flow_Id
          Into v_Form_State, v_Flow_Id
          From t_Pln_Order_Head Th, t_Pln_Order_Type Ot
         Where Th.Order_Head_Id = p_Head_Id
           And Ot.Order_Type_Id = Th.Order_Type_Id
           And Ot.Entity_Id = Th.Entity_Id;
      Exception
        When Others Then
          p_Result := '获取订单头失败，订单头ID：' || To_Char(p_Head_Id) || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
      End;
      --add by lizhen 2015-02-03 检查当前订单状态是否可以做库存评
      --防止并发问题
      /*Select Count(1)
        Into v_Count
        From t_Pln_Flow_Status Fs
       Where Fs.Flow_Id = v_Flow_Id
         And To_Char(Fs.Curr_Status_Id) = Trim(v_Form_State)
         And Fs.Next_Status_Id = 26;
      If Nvl(v_Form_State, '_') != '26' And v_Count = 0 Then
        p_Err_Msg := '计划订单头状态已不在库存评审范围内。' || v_Nl || '计划订单头Id:' ||
                     p_Head_Id || v_Nl || '计划订单头状态:' || v_Form_State;
        Raise v_Base_Exception;
      End If;*/
    End If;
    ---
    v_Match_Pln_To_Wip := Pkg_Bd.f_Get_Parameter_Value('PLN_WIP_ORD_MATCH',
                                                       p_Entity_Id);
    --检查库存评审商品的库存可用量
    Begin
      p_Item_Usable_Onhand_Check(p_Head_Id         => p_Head_Id, --汇总订单头ID
                                 p_Line_Id         => p_Line_Id, --汇总订行头ID
                                 p_Inv_Review_Type => p_Inv_Review_Type, --库存评审类型：1：汇总库存评审 2：计划订单库存评审
                                 p_Entity_Id       => p_Entity_Id, --主体ID
                                 p_Result          => p_Err_Msg);
      If p_Err_Msg <> v_Success Then
        p_Result := -21000;
        Raise v_Base_Exception;
      End If;
    Exception
      When Others Then
        p_Result  := -21000;
        p_Err_Msg := '检查商品库存可用量失败！' || v_Nl || p_Err_Msg;
        Raise v_Base_Exception;
    End;

    /*If p_Result = v_Result Then
      --处理订单库存评审时，先清空已有评审数量
      Update t_Pln_Order_Line Ol
         Set Ol.Inv_Affirm_Qty = 0
       Where Ol.Order_Line_Id In
             (Select Osa.Order_Line_Id
                From t_Pln_Order_Inv_Review Osa
               Where ((p_Inv_Review_Type = 1 And Osa.Head_Id = p_Head_Id And
                     Osa.Line_Id = p_Line_Id) Or
                     (p_Inv_Review_Type = 2 And
                     Osa.Order_Head_Id = p_Head_Id And
                     Osa.Order_Line_Id = p_Line_Id))
                 And Osa.Entity_Id = p_Entity_Id);
    End If;*/
    Begin
      Open c_Inv_Review;
    Exception
      When Others Then
        p_Err_Msg := '获取库存评审行数据失败，订单行ID：' || To_Char(p_Line_Id) || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;
    Loop
      Fetch c_Inv_Review
        Into r_Inv_Review;
      Exit When c_Inv_Review%Notfound Or p_Result <> v_Result;
      If Nvl(v_Is_Chk_Rounding, 'N') = 'Y' Then
        --add by lizhen 2015-03-26 检查产品凑整信息
        Pkg_Pln_Pub.p_Check_Item_Rounding(p_Entity_Id => p_Entity_Id,
                                          p_Item_Id   => r_Inv_Review.Item_Id,
                                          p_Check_Qty => r_Inv_Review.Affirming_Qty,
                                          p_Result    => p_Err_Msg);
        If p_Err_Msg != v_Success Then
          p_Result  := -21000;
          Raise v_Base_Exception;
        End If;
      End If;
      Begin
        --获取订单单号、订单类型名称
        Select Poh.Order_Number, Pot.Order_Type_Name
          Into v_Order_Number, v_Order_Type_Name
          From t_Pln_Order_Head Poh, t_Pln_Order_Type Pot
         Where Pot.Order_Type_Id = Poh.Order_Type_Id
           And Poh.Entity_Id = p_Entity_Id
           And Poh.Order_Head_Id = r_Inv_Review.Order_Head_Id;
      Exception
        When Others Then
          p_Result  := -21000;
          p_Err_Msg := '获取订单单号失败，订单头ID：' || r_Inv_Review.Order_Head_Id;
          Raise v_Base_Exception;
      End;

      v_Current_Affirm_Qty := Nvl(r_Inv_Review.Affirming_Qty, 0) -
                              Nvl(r_Inv_Review.Affirm_Qty, 0);

      If v_Current_Affirm_Qty <> 0 Then
        --处理库存占用数据
        Begin
          Pkg_Pln_Inv_Occupy.p_Affirm_Occupy_Stocks(p_Inventory_Id      => r_Inv_Review.Inventory_Id, --仓库ID
                                                    p_Item_Id           => r_Inv_Review.Item_Id, --产品ID
                                                    p_Occupy_Qty        => v_Current_Affirm_Qty, --占用数量
                                                    p_Match_Pln_To_Wip  => v_Match_Pln_To_Wip, --工单与订单完全匹配标志 Y:完全匹配  N:非完全匹配
                                                    p_Action_Desc       => v_Order_Type_Name ||
                                                                           '库存评审', --单据操作描述 例：中转单据执行、中转红冲单执行
                                                    p_Entity_Id         => p_Entity_Id, --主体ID
                                                    p_Origin_Type       => '', --来源类型
                                                    p_Origin_Head_Id    => r_Inv_Review.Order_Head_Id, --来源头ID
                                                    p_Origin_Number     => v_Order_Number, --来源头编码
                                                    p_Origin_Line_Id    => r_Inv_Review.Order_Line_Id, --来源行ID
                                                    p_Source_Order_Type => v_Order_Type_Name, --事务来源单据类型
                                                    p_Source_Head_Id    => r_Inv_Review.Order_Head_Id, --事务来源头ID
                                                    p_Source_Number     => v_Order_Number, --事务来源头编码
                                                    p_Source_Line_Id    => r_Inv_Review.Order_Line_Id, --事务来源行ID
                                                    p_User_Code         => p_User_Code, --用户ID
                                                    p_Result            => p_Result, --返回错误ID
                                                    p_Err_Msg           => p_Err_Msg --返回错误信息
                                                    );
          If p_Result <> v_Result Then
            p_Result := -21000;
            Raise v_Base_Exception;
          End If;

          If p_Result = v_Result Then
            --更新订单库存评审表库存评审数量
            Update t_Pln_Order_Inv_Review Ir
               Set Ir.Affirm_Qty       = Ir.Affirming_Qty,
                   Ir.Last_Updated_By  = p_User_Code,
                   Ir.Last_Update_Date = Sysdate
             Where Ir.Order_Inv_Id = r_Inv_Review.Order_Inv_Id;

            Update t_Pln_Order_Inv_Review Ir
               Set Ir.Affirming_Qty = Null
             Where Ir.Order_Inv_Id = r_Inv_Review.Order_Inv_Id;
          End If;

          If p_Result = v_Result Then
            --更新订单行的库存评审数量
            Update t_Pln_Order_Line Ol
               Set Ol.Inv_Affirm_Qty   = Nvl(Ol.Inv_Affirm_Qty, 0) +
                                         Nvl(v_Current_Affirm_Qty, 0),
                   Ol.Check_Qty        = Decode(Nvl(Ol.Adjust_Qty, 0),
                                                0,
                                                Nvl(Ol.center_check_qty, Ol.Apply_Qty),
                                                Ol.Adjust_Qty) -
                                         (Nvl(Ol.Inv_Affirm_Qty, 0) +
                                          Nvl(v_Current_Affirm_Qty, 0)),
                   Ol.Can_Produce_Qty  = Decode(Nvl(Ol.Adjust_Qty, 0),
                                                0,
                                                Nvl(Ol.center_check_qty, Ol.Apply_Qty),
                                                Ol.Adjust_Qty) -
                                         (Nvl(Ol.Inv_Affirm_Qty, 0) +
                                          Nvl(v_Current_Affirm_Qty, 0)),
                   Ol.Last_Updated_By  = p_User_Code,
                   Ol.Last_Update_Date = Sysdate
             Where Ol.Order_Line_Id = r_Inv_Review.Order_Line_Id;
          End If;
        Exception
          When Others Then
            p_Result  := -21000;
            p_Err_Msg := '调用PKG_PLN_INV_OCCUPY.P_AFFIRM_OCCUPY_STOCKS处理占用失败！' || v_Nl ||
                         p_Err_Msg;
            Raise v_Base_Exception;
        End;
        /*--更新已排产数量后再生成分配行数信息
        --分配行生成放到订单排产后
        If p_Err_Msg = v_Success Then
            pkg_pln_shares.p_Auto_Create_Share(p_Pln_Order_Line_Id => r_Inv_Review.Order_Line_Id, --订单行ID
                                               p_Inventory_Id      => r_Inv_Review.Inventory_Id, --仓库ID(财务仓)
                                               p_Trans_Sign_Flag   => Sign(v_Current_Affirm_Qty), --生成发货计划方向，1：生成发货计划  -1：取消发货计划
                                               p_Trans_Share_Qty   => Abs(v_Current_Affirm_Qty), --分配数量（只传正数）
                                               p_Entity_Id         => p_Entity_Id, --主体ID
                                               p_Pln_Wip_Ord_Match => v_Match_Pln_To_Wip, --工单与订单新匹配模式
                                               p_User_Code         => p_User_Code,
                                               p_Result            => p_Err_Msg);
            If p_Err_Msg <> v_Success Then
               Raise v_Base_Exception;
            End If;
          End If;*/
      End If;
    End Loop;
    Close c_Inv_Review;
    --过程处理错误，报错误及回滚数据
    If p_Result <> v_Result Then
      p_Result := -21000;
      Rollback;
    End If;
  Exception
    When v_Base_Exception Then
      p_Result  := -21000;
      p_Err_Msg := '异常过程：Pkg_Pln_Order_Inv_Review.p_Inv_Review_Lock'
        || v_Nl || p_Err_Msg || v_Nl || Sqlerrm;
      Rollback;
    When Others Then
      p_Result  := -21000;
      p_Err_Msg := '异常过程：Pkg_Pln_Order_Inv_Review.p_Inv_Review_Lock'
        || v_Nl || replace(p_Err_Msg, v_Success, '') || v_Nl || Sqlerrm;
      Rollback;
  End;

End Pkg_Pln_Order_Inv_Review;
/

