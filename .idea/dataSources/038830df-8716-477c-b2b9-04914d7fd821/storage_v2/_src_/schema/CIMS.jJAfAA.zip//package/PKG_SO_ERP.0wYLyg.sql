create PACKAGE      PKG_SO_ERP IS
  /*----------------------------------------------------------------
  *         包：PKG_SO_ERP
  *   创建日期：2014-08-16
  *     创建者：廖丽章
  *   功能说明：1、与ERP系统通过DBLINK对接的相关过程，例如：回写AR发票号到CIMS的销售单表等
  *
  *   过程成功：P_RESULT = 0
  *             P_ERR_MSG = 'SUCCESS';
  *
  *   过程失败：P_RESULT < -20000;SO_RECNT_INFO
  *             P_ERR_MSG = 过程异常失败的提示信息
  *
  */ ----------------------------------------------------------------
--alter table T_SO_RECONCILIATION add return_mode varchar(2);
--alter table T_SO_RECONCILIATION add erp_logist_header_id number; req_header_id 
--alter table T_SO_RECONCILIATION add orig_so_num varchar(32);
--alter table T_SO_RECONCILIATION add push_or_pull varchar(10);
  --定义对账信息记录集
  TYPE SO_RECNT_INFO IS RECORD(
    RECNT_ID               T_SO_RECONCILIATION.RECNT_ID%TYPE,
    SO_HEADER_ID           T_SO_RECONCILIATION.SO_HEADER_ID%TYPE,
    SO_NUM                 T_SO_RECONCILIATION.SO_NUM%TYPE,
    ERP_OU_ID              T_SO_RECONCILIATION.ERP_OU_ID%TYPE,
    BILL_TYPE_NAME         T_SO_RECONCILIATION.BILL_TYPE_NAME%TYPE,
    BIZ_SRC_BILL_TYPE_CODE T_SO_RECONCILIATION.BIZ_SRC_BILL_TYPE_CODE%TYPE,
    ENTITY_ID              T_SO_RECONCILIATION.ENTITY_ID%TYPE,
    RETURN_MODE            T_SO_RECONCILIATION.RETURN_MODE%TYPE,
    ERP_LOGIST_HEADER_ID   T_SO_RECONCILIATION.Erp_Logist_Header_Id%TYPE,
    ORIG_SO_NUM            T_SO_RECONCILIATION.ORIG_SO_NUM%TYPE,
    PUSH_OR_PULL           T_SO_RECONCILIATION.PUSH_OR_PULL%TYPE
    );

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-08-16
  *     创建者：廖丽章
  *   功能说明：回写ERP AR发票信息到财务单
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_UPDATE_SO_ARINVOICE(P_ENTITY_ID IN NUMBER,
                                  P_EXPIRY_DATE IN VARCHAR2,
                                  P_RESULT  OUT NUMBER, --返回错误ID
                                  P_ERR_MSG OUT VARCHAR2 --返回错误信息
                                  );

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-12-10
  *     创建者：廖丽章
  *   功能说明：销售对账过程，CIMS系统销售单与ERP系统销售订单对账
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_RECONCILIATION(P_USER_CODE IN VARCHAR2, --操作用户编码
                                P_RESULT    OUT NUMBER, --返回错误ID
                                P_ERR_MSG   OUT VARCHAR2 --返回错误信息
                                );

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-12-10
  *     创建者：廖丽章
  *   功能说明：销售对账处理
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_RECONCILIATION_PROCESS(P_SO_RECNT_INFO IN SO_RECNT_INFO, --销售对账记录
                                        P_RECNT_FLAG    IN VARCHAR2, --对帐类型标识：A审核对账，S结算对账
                                        P_USER_CODE     IN VARCHAR2, --操作用户编码
                                        P_RESULT        OUT NUMBER, --返回错误ID
                                        P_ERR_MSG       OUT VARCHAR2 --返回错误信息
                                        );

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-01-22
  *     创建者：陈武杰
  *   功能说明：重算销售对账处理
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_RE_RECONCILIATION_PROCESS(P_SO_RECNT_INFO IN SO_RECNT_INFO, --销售对账记录
                                           P_RECNT_FLAG    IN VARCHAR2, --对帐类型标识：A审核对账，S结算对账
                                           P_USER_CODE     IN VARCHAR2, --操作用户编码
                                           P_RESULT        OUT NUMBER, --返回错误ID
                                           P_ERR_MSG       OUT VARCHAR2 --返回错误信息
                                           );
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-01-22
  *     创建者：陈武杰
  *   功能说明：重算销售对账过程
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_RE_RECONCILIATION(P_USER_CODE IN VARCHAR2, --操作用户编码
                                   P_RESULT    OUT NUMBER, --返回错误ID
                                   P_ERR_MSG   OUT VARCHAR2 --返回错误信息
                                   );

  PROCEDURE P_SO_JIESUAN(P_SO_HEADER_ID IN NUMBER, --销售对账记录
                         P_RECNT_FLAG   IN VARCHAR2, --对帐类型标识：A审核对账，S结算对账
                         P_ERP_QTY      OUT NUMBER,
                         P_ERP_AMOUNT   OUT NUMBER,
                         P_RESULT       OUT NUMBER, --返回错误ID
                         P_ERR_MSG      OUT VARCHAR2 --返回错误信息
                         );
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-05-04
  *     创建者：申广延
  *   功能说明：子库转移ERP对账
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_COMP2ERP_SUBINV(P_SO_RECNT_INFO IN SO_RECNT_INFO, --销售对账记录
            	                             P_COUNT_LINE    OUT NUMBER,
                                           P_QTY           OUT NUMBER,
                                           P_RESULT        OUT NUMBER, --返回错误ID
                                           P_ERR_MSG       OUT VARCHAR2 --返回错误信息
                                           );  
                                           
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-05-04
  *     创建者：申广延
  *   功能说明：PO对账
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_COMP2ERP_PO(P_SO_RECNT_INFO IN SO_RECNT_INFO, --销售对账记录
                                           P_QTY           OUT NUMBER,
                                           P_RESULT        OUT NUMBER, --返回错误ID
                                           P_ERR_MSG       OUT VARCHAR2 --返回错误信息
                                           ); 
                                           
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-05-04
  *     创建者：申广延
  *   功能说明：SO对账
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_COMP2ERP_SO(P_SO_RECNT_INFO IN SO_RECNT_INFO, --销售对账记录
                                           P_RECNT_FLAG    IN VARCHAR2, --对帐类型标识：A审核对账，S结算对账
                                           P_USER_CODE     IN VARCHAR2, --操作用户编码
                                           P_SO_QTY     OUT NUMBER, --数量
                                           P_SO_AMOUNT  OUT NUMBER, --金额                                           
                                           P_RESULT        OUT NUMBER, --返回错误ID
                                           P_ERR_MSG       OUT VARCHAR2 --返回错误信息
                                           );      
                                                                                                                                                   
    -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-05-04
  *     创建者：申广延
  *   功能说明：销售单统计-拉式
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_HEADER_CAL_PULL(P_SO_RECNT_INFO IN SO_RECNT_INFO, --销售对账记录
                                           P_ENTRY_QTY     OUT NUMBER,--入库总数量
                                           P_TOTAL_QTY     OUT NUMBER,--总数量
                                           P_TOTAL_AMOUNT   OUT NUMBER,--总金额
                                           P_RESULT        OUT NUMBER, --返回错误ID
                                           P_ERR_MSG       OUT VARCHAR2 --返回错误信息
                                           ); 
    -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-05-04
  *     创建者：申广延
  *   功能说明：销售单统计-推式
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_HEADER_CAL_PUSH(P_SO_RECNT_INFO IN SO_RECNT_INFO, --销售对账记录
                                           P_TOTAL_QTY     OUT NUMBER,--总数量
                                           P_TOTAL_AMOUNT   OUT NUMBER,--总金额
                                           P_RESULT        OUT NUMBER, --返回错误ID
                                           P_ERR_MSG       OUT VARCHAR2 --返回错误信息
                                        );
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-05-05
  *     创建者：申广延
  *   功能说明：销售对账处理
  */
  -------------------------------------------------------------------------------                                           
  PROCEDURE P_SO_COM2ERP_PROCESS(P_SO_RECNT_INFO IN SO_RECNT_INFO, --销售对账记录
                                        P_RECNT_FLAG    IN VARCHAR2, --对帐类型标识：A审核对账，S结算对账
                                        P_USER_CODE     IN VARCHAR2, --操作用户编码
                                        P_UPDATE_FLAG   IN VARCHAR2, --回写标志，'Y'回写，测试用''                                        
                                        P_RESULT        OUT NUMBER, --返回错误ID
                                        P_ERR_MSG       OUT VARCHAR2 --返回错误信息
                                        );   
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-5-5
  *     创建者：申广延
  *   功能说明：销售对账过程，CIMS系统销售单与ERP系统销售订单对账
  *             1)把需要引入到ERP系统的审核通过且未对账财务单添加到销售对账表（T_SO_RECONCILIATION），已添加到该表的记录不重复添加。
  *             2)从对账表中取未审核对账的记录，与ERP系统进行审核对账，并记录对账结果。
  *             3)从对账表中取未结算对账的记录，与ERP系统进行结算对账，并记录对账结果。
  *             4)回写销售单据头表的对账标识和对账时间。
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_COM2ERP_MAIN(P_ENTITY_ID              IN NUMBER, --主体ID
                              P_PAGE_SIZE              IN NUMBER, --单次处理单据数（分页）
                              P_LASTUPDATE_INTERVAL    IN NUMBER, --具体当前日期的间隔范围
                              P_USER_CODE              IN VARCHAR2, --操作用户编码
                              P_RESULT                 OUT NUMBER, --返回错误ID
                              P_ERR_MSG                OUT VARCHAR2 --返回错误信息
                              );

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-05-05
  *     创建者：申广延
  *   功能说明：取销售单
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_GET_HEADER(P_SO_NUM IN NUMBER, --销售单号
                                        P_SO_RECNT_INFO OUT SO_RECNT_INFO, --操作用户编码
                                        P_RESULT        OUT NUMBER, --返回错误ID
                                        P_ERR_MSG       OUT VARCHAR2 --返回错误信息
                                        );                                           
  -------------------------------------------------------------------------------
  /*
  *   TEST
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_COM2ERP_TEST(P_SO_NUM IN VARCHAR2, --销售单号
                                        P_RECNT_FLAG    IN VARCHAR2, --对帐类型标识：A审核对账，S结算对账
                                        P_USER_CODE     IN VARCHAR2, --操作用户编码
                                        P_RESULT        OUT NUMBER, --返回错误ID
                                        P_ERR_MSG       OUT VARCHAR2 --返回错误信息
                                        ) ;
                                        
   -------------------------------------------------------------------------------
  /*
  *   单挑记录对账
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_COM2ERP_SINGLE(P_SO_NUM IN VARCHAR2, --销售单号
                                        P_RECNT_FLAG    IN VARCHAR2, --对帐类型标识：A审核对账，S结算对账
                                        P_USER_CODE     IN VARCHAR2, --操作用户编码
                                        P_RESULT        OUT NUMBER, --返回错误ID
                                        P_ERR_MSG       OUT VARCHAR2 --返回错误信息
                                        ) ;                                      
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-5-5
  *     创建者：申广延
  *   功能说明：销售重新对账
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_RECOM2ERP_MAIN(P_USER_CODE IN VARCHAR2, --操作用户编码
                                P_RESULT    OUT NUMBER, --返回错误ID
                                P_ERR_MSG   OUT VARCHAR2 --返回错误信息
                                );                                                                                                           
END PKG_SO_ERP;
/

