create Package      Pkg_Inv_Pub Is

  v_True    Constant Varchar2(2) := 'Y';
  v_False   Constant Varchar2(2) := 'N';

  -- Author  : NICRO.LI
  -- Created : 2014-08-12 19:53:48
  -- Purpose : 库存模块公共函数包

  -----------------------------------------------------------------------------
  -- Author: NICRO.LI
  --Purpose: 取得库存周期                                                    --
  -----------------------------------------------------------------------------
  Function f_Get_Inv_Period(p_Entity_Id In Number, --主体ID
                            p_Date      In Date, --日期
                            p_Condition In Number --周期状态
                            ) Return Number;

  -----------------------------------------------------------------------------
  --  取得库存周期                                                           --
  --  库存周期四个日期BEGIN_DATE,END_DATE,STATUS, CLOSE_DATE之间的取值       --
  --  P_CONDITION：0：关闭   1：打开    2：结账
  -----------------------------------------------------------------------------
  Procedure p_Get_Inv_Period(p_Entity_Id     In Number, --主体ID
                             p_Date          In Date, --日期
                             p_Condition     In Number, --周期状态
                             p_Inv_Period_Id Out Number,
                             p_Result        Out Varchar2);

  --------------------------------------------------------------------------
  --Anthor: Nicro.Li
  --Purpose:获取某产品指定仓库的库存情况
  --参数说明：p_get_qoh_type
  --  1：库存在手量
  --  2：库存可用量
  --  3：库存占用量
  --------------------------------------------------------------------------
  Function f_Get_Item_Inv_Qoh(p_Entity_Id         In Number, --主体ID
                               p_Inventory_Id      In Number, --指定仓库
                               p_Item_Id           In Number, --指定产品
                               p_User_Code         In Varchar2, --用户ID
                               p_get_qoh_type      In Number,  --1: 库存在手量   2：库存可用量  3：库存占用量 4:非中转采购未执行
                               p_Count_Occoup_Flag In Varchar2 Default v_True --可用量是否计算库存占用，Y：计算，N：不计算
                               ) Return Number;

  --------------------------------------------------------------------------
  --Anthor: Nicro.Li
  --Purpose:获取某产品指定仓库的 库存在手量：p_Qoh_Qty
  --                             库存可用量：p_Usable_Qoh_Qty
  --                             库存占用量：p_Occupy_Qty
  --------------------------------------------------------------------------
  Procedure p_Get_Item_Inv_Qoh(p_Entity_Id         In Number, --主体ID
                               p_Inventory_Id      In Number, --指定仓库
                               p_Item_Id           In Number, --指定产品
                               p_User_Code         In Varchar2, --用户ID
                               p_Qoh_Qty           Out Number, --返回的库存在手量，出错返回NULL
                               p_Usable_Qoh_Qty    Out Number, --返回库存可用量，出错返回NULL
                               p_Occupy_Qty        Out Number, --返回库存占用量，出错返回NULL
                               p_Result            Out Varchar2, --返回值
                               p_Count_Occoup_Flag In Varchar2 Default 'Y' --可用量是否计算库存占用，Y：计算，N：不计算
                               );
                               
                               
  --------------------------------------------------------------------------
  --Anthor: Nicro.Li
  --Created: 2017-06-21
  --Purpose:参数库存组织ID是否为客户所属OU对应的库存组织
  --返回值说明：Y: 表示客户允许评审组织对应的仓库    N: 表示不允许评审，无权限  
  --------------------------------------------------------------------------
  Function f_Get_Custimer_Inv_Org(In_Entity_Id         In Number, --主体ID
                                  In_Customer_Id       In Number, --客户ID
                                  In_Organization_Id   In Number --组织ID
                                  ) Return Varchar2;
                                  
                                  
  -----------------------------------------------------------------------------
  -- Author: guibr
  --Purpose: 取得大类所在的主体                                                  --
  -----------------------------------------------------------------------------
  Function f_Get_Entity_Classcode(P_SALES_MAIN_TYPE In VARCHAR2 --营销大类编码
                            ) Return Number;                                
                                  
                                  
       ------------------------------------------------------------
  /*    根据主体和区域编码，找到覆盖该区域(本节点 + 父节点)所有的仓库,32主体下，如果传入的中心不为空，则只展示该中心下的仓库                  */
  -- add by huanghb12 2019-2-20
  ------------------------------------------------------------
  FUNCTION F_GET_AREA_INV_LIST(P_ENTITY_ID     IN NUMBER, --主体ID
                               P_DISTRICT_CODE IN VARCHAR2, --指定行政区域编码
                                P_SALES_CENTER_CODE IN VARCHAR2 Default null
                               )
  RETURN TBL_INV_INVENTORY 
  PIPELINED;
   ------------------------------------------------------------                                
                                  
End Pkg_Inv_Pub;
/

