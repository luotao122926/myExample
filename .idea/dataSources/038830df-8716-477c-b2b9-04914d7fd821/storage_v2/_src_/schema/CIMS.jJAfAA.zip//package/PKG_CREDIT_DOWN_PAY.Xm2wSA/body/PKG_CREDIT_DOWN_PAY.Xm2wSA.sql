create PACKAGE BODY PKG_CREDIT_DOWN_PAY IS

  /**
  *订金锁定，用于动作标识1/29
  *1适用于锁款类型为送审锁款的订单送审或评审时（也是送审锁款类型）调整差额为正数
  *的场景（还有锁款类型为发货锁款的订单评审的场景，但不锁订金）
  *29表示取消发货通知单时，如果是做过T+3订单评审的订单
  *，或者是订单已关闭，且是送审锁款的订单，须进行解锁款项锁订金的操作
  **/
  PROCEDURE P_LOCK_DOWN_PAY_AMOUNT(IN_ORDER_ID        IN NUMBER, --提货订单ID
                                   IS_ORDER_TYPE      IN VARCHAR2, --提货订单单据类型
                                   IS_SALES_MAIN_TYPE IN VARCHAR2, --营销大类
                                   IN_LOCK_AMOUNT     IN NUMBER, --锁定金额
                                   IN_ENTITY_ID       IN NUMBER, --主体ID
                                   IN_CUSTOMER_ID     IN NUMBER, --客户ID
                                   IN_ACCOUNT_ID      IN NUMBER, --账户ID
                                   IN_DOWN_PAY_RATE   IN NUMBER, --订金比例
                                   IS_ACTION_TYPE     IN VARCHAR2, --动作标识
                                   IS_USER_ACCOUNT    IN VARCHAR2, --用户账号
                                   OS_MESSAGE         OUT VARCHAR2, --成功返回SUCCESS，失败返回出错信息
                                   IS_DISCOUNT_TYPE    IN VARCHAR2 DEFAULT NULL--折让方式
                                   ) IS
    V_DOWN_PAY_AMOUNT    NUMBER; --锁定订金
    V_CREDIT_GROUP_ID    NUMBER;
    VR_PLN_LG_ORDER_HEAD T_PLN_LG_ORDER_HEAD%ROWTYPE;
    VR_PLN_ORDER_HEAD T_PLN_ORDER_HEAD%ROWTYPE;
    V_SRC_SOURCE_TYPE_ID NUMBER;
    V_ORDER_NUMBER   VARCHAR2(50); --订单号
  BEGIN
    --获取单据原类型
    SELECT T.SOURCE_ORDER_TYPE_ID
      INTO V_SRC_SOURCE_TYPE_ID
      FROM T_PLN_ORDER_TYPE T
     WHERE T.ENTITY_ID = IN_ENTITY_ID
       AND T.ORDER_TYPE_CODE = IS_ORDER_TYPE;
    
    IF V_SRC_SOURCE_TYPE_ID = 1 THEN
      SELECT *
        INTO VR_PLN_LG_ORDER_HEAD
        FROM T_PLN_LG_ORDER_HEAD
       WHERE ORDER_HEAD_ID = IN_ORDER_ID
         FOR UPDATE WAIT 3;
      
      V_ORDER_NUMBER := VR_PLN_LG_ORDER_HEAD.ORDER_NUMBER;
    ELSIF V_SRC_SOURCE_TYPE_ID = 0 THEN
      SELECT *
        INTO VR_PLN_ORDER_HEAD
        FROM T_PLN_ORDER_HEAD H
       WHERE H.ORDER_HEAD_ID = IN_ORDER_ID
         FOR UPDATE WAIT 3;
      V_ORDER_NUMBER := VR_PLN_ORDER_HEAD.ORDER_NUMBER;
    END IF;
    --按比例计算锁定订金
    V_DOWN_PAY_AMOUNT := (IN_LOCK_AMOUNT * IN_DOWN_PAY_RATE) / 100;
  --2017-4-22 获取额度组增加账户ID liangym2
    V_CREDIT_GROUP_ID := PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(IN_ENTITY_ID,
                                                                IN_CUSTOMER_ID,
                                                                IS_SALES_MAIN_TYPE,IN_ACCOUNT_ID);
    IF 0 <> V_DOWN_PAY_AMOUNT THEN
      --增加客户款项明细锁定到款金额
      UPDATE T_SALES_ACCOUNT_MX_AMOUNT T
         SET T.LOCK_RECEIVED_AMOUNT = T.LOCK_RECEIVED_AMOUNT +
                                      V_DOWN_PAY_AMOUNT,
             T.LAST_UPDATED_BY      = IS_USER_ACCOUNT,
             T.LAST_UPDATE_DATE     = SYSDATE
       WHERE T.ENTITY_ID = IN_ENTITY_ID
         AND T.CUSTOMER_ID = IN_CUSTOMER_ID
         AND T.ACCOUNT_ID = IN_ACCOUNT_ID
         AND T.SALES_MAIN_TYPE = IS_SALES_MAIN_TYPE;
      IF V_SRC_SOURCE_TYPE_ID = 1 THEN
        --提货订单头增加锁定订金
        UPDATE T_PLN_LG_ORDER_HEAD T
           SET T.DOWN_PAY_AMOUNT = NVL(T.DOWN_PAY_AMOUNT, 0) +
                                   V_DOWN_PAY_AMOUNT
         WHERE T.ORDER_HEAD_ID = IN_ORDER_ID;
      ELSIF V_SRC_SOURCE_TYPE_ID = 0 THEN
        UPDATE T_PLN_ORDER_HEAD H
           SET H.DOWN_PAY_AMOUNT = NVL(H.DOWN_PAY_AMOUNT, 0) + V_DOWN_PAY_AMOUNT
         WHERE H.ORDER_HEAD_ID = IN_ORDER_ID;
      END IF;
      --增加客户款项锁定到款金额
      UPDATE T_SALES_ACCOUNT_AMOUNT T
         SET T.LOCK_RECEIVED_AMOUNT = T.LOCK_RECEIVED_AMOUNT +
                                      V_DOWN_PAY_AMOUNT,
             T.LAST_UPDATED_BY      = IS_USER_ACCOUNT,
             T.LAST_UPDATE_DATE     = SYSDATE
       WHERE T.ENTITY_ID = IN_ENTITY_ID
         AND T.CUSTOMER_ID = IN_CUSTOMER_ID
         AND T.ACCOUNT_ID = IN_ACCOUNT_ID
         AND NVL(T.CREDIT_GROUP_ID, -1) = NVL(V_CREDIT_GROUP_ID, -1);
    END IF;
  
    INSERT INTO T_SALES_AMOUNT_TRANS
      (TRANS_ID, --事务ID
       ENTITY_ID, --主体ID
       SALES_YEAR_ID, --销售年度ID
       CUSTOMER_ID, --客户ID
       ACCOUNT_ID, --账户ID
       CREDIT_GROUP_ID, --额度组ID
       PROJ_NUMBER, --项目号
       SALES_MAIN_TYPE, --营销大类ID
       ORDER_ID, --单据ID
       ORDER_TYPE, --单据类型
       ORDER_NUM, --单据号
       ACTION_FLAG, --动作标识
       TRANS_ACTION, --事务动作（1：增加；2：减少；3：变更）
       AMOUNT_NAME, --款项名称
       AMOUNT, --金额
       DUE_FLAG, --处理标识（1：成功；2：失败）
       CREATED_BY, --创建人
       CREATION_DATE, --创建日期
       LAST_UPDATED_BY, --最后修改人
       LAST_UPDATE_DATE, --最后修改日期
       PRE_FIELD_01,
       PRE_FIELD_02,
       PRE_FIELD_03,
       PRE_FIELD_04,
       PRE_FIELD_05,
       PRE_FIELD_06)
    VALUES
      (S_SALES_AMOUNT_TRANS.NEXTVAL, --事务ID
       IN_ENTITY_ID, --主体ID
       NULL, --销售年度ID
       IN_CUSTOMER_ID, --客户ID
       IN_ACCOUNT_ID, --账户ID
       V_CREDIT_GROUP_ID, --额度组ID
       NULL, --项目号
       IS_SALES_MAIN_TYPE, --营销大类
       IN_ORDER_ID, --单据ID
       IS_ORDER_TYPE, --单据类型
       V_ORDER_NUMBER, --
       IS_ACTION_TYPE, --动作标识
       1, --事务动作（1：增加；2：减少；3：变更）
       '锁定到款金额(订金)', --款项名称
       V_DOWN_PAY_AMOUNT, --金额
       '1', --处理标识（1：成功；2：失败）
       IS_USER_ACCOUNT, --创建人
       SYSDATE, --创建日期
       /*NVL(VR_PLN_LG_ORDER_HEAD.LAST_UPDATED_BY,
           VR_PLN_LG_ORDER_HEAD.CREATED_BY)*/
       IS_USER_ACCOUNT, --最后修改人
       /*NVL(VR_PLN_LG_ORDER_HEAD.LAST_UPDATE_DATE,
           VR_PLN_LG_ORDER_HEAD.CREATION_DATE)*/
       SYSDATE, --最后修改日期
       --IS_USER_ACCOUNT, --最后修改人
       --SYSDATE, --最后修改日期
       NULL,
       NULL,
       NULL,
       NULL,
       NULL,
       NULL);
    OS_MESSAGE := V_SUCCESS;
    --EXCEPTION WHEN OTHERS THEN
      --OS_MESSAGE := '订金锁定异常，请了解！'|| V_NL || SQLERRM ;
  END P_LOCK_DOWN_PAY_AMOUNT;

  /**
  *折扣订金锁定，用于动作标识1/29
  *1适用于锁款类型为送审锁款的订单送审或评审时（也是送审锁款类型）调整差额为正数
  *的场景（还有锁款类型为发货锁款的订单评审的场景，但不锁订金）
  *29表示取消发货通知单时，如果是做过T+3订单评审的订单
  *，或者是订单已关闭，且是送审锁款的订单，须进行解锁款项锁订金的操作
  **/
  PROCEDURE P_LOCK_DP_DIS_AMOUNT(IN_ORDER_ID        IN NUMBER, --提货订单ID
                                   IS_ORDER_TYPE      IN VARCHAR2, --提货订单单据类型
                                   IS_SALES_MAIN_TYPE IN VARCHAR2, --营销大类
                                   IN_LOCK_AMOUNT     IN NUMBER, --锁定金额
                                   IN_ENTITY_ID       IN NUMBER, --主体ID
                                   IN_CUSTOMER_ID     IN NUMBER, --客户ID
                                   IN_ACCOUNT_ID      IN NUMBER, --账户ID
                                   IN_DOWN_PAY_RATE   IN NUMBER, --订金比例
                                   IS_ACTION_TYPE     IN VARCHAR2, --动作标识
                                   IS_USER_ACCOUNT    IN VARCHAR2, --用户账号
                                   OS_MESSAGE         OUT VARCHAR2, --成功返回SUCCESS，失败返回出错信息
                                   IS_DISCOUNT_TYPE    IN VARCHAR2 DEFAULT NULL--折让方式
                                   ) IS
    V_DOWN_PAY_AMOUNT    NUMBER; --锁定折扣订金
    V_CREDIT_GROUP_ID    NUMBER;
    VR_PLN_LG_ORDER_HEAD T_PLN_LG_ORDER_HEAD%ROWTYPE;
    VR_PLN_ORDER_HEAD T_PLN_ORDER_HEAD%ROWTYPE;
    V_SRC_SOURCE_TYPE_ID NUMBER;
    V_ORDER_NUMBER   VARCHAR2(50); --订单号
  BEGIN
    --获取单据原类型
    SELECT T.SOURCE_ORDER_TYPE_ID
      INTO V_SRC_SOURCE_TYPE_ID
      FROM T_PLN_ORDER_TYPE T
     WHERE T.ENTITY_ID = IN_ENTITY_ID
       AND T.ORDER_TYPE_CODE = IS_ORDER_TYPE;
    
    IF V_SRC_SOURCE_TYPE_ID = 1 THEN
      SELECT *
        INTO VR_PLN_LG_ORDER_HEAD
        FROM T_PLN_LG_ORDER_HEAD
       WHERE ORDER_HEAD_ID = IN_ORDER_ID
         FOR UPDATE WAIT 3;
      V_ORDER_NUMBER := VR_PLN_LG_ORDER_HEAD.ORDER_NUMBER;
    ELSIF V_SRC_SOURCE_TYPE_ID = 0 THEN
      SELECT *
        INTO VR_PLN_ORDER_HEAD
        FROM T_PLN_ORDER_HEAD H
       WHERE H.ORDER_HEAD_ID = IN_ORDER_ID
         FOR UPDATE WAIT 3;
      V_ORDER_NUMBER := VR_PLN_ORDER_HEAD.ORDER_NUMBER;
    END IF;
    --按比例计算锁定订金
    V_DOWN_PAY_AMOUNT := (IN_LOCK_AMOUNT * IN_DOWN_PAY_RATE) / 100;
  --2017-4-22 获取额度组增加账户ID liangym2
    V_CREDIT_GROUP_ID := PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(IN_ENTITY_ID,
                                                                IN_CUSTOMER_ID,
                                                                IS_SALES_MAIN_TYPE,IN_ACCOUNT_ID);
    IF 0 <> V_DOWN_PAY_AMOUNT THEN
      --增加客户款项明细锁定到款金额
      UPDATE T_SALES_ACCOUNT_MX_AMOUNT T
         SET T.LOCK_DISCOUNT_AMOUNT = T.LOCK_DISCOUNT_AMOUNT +
                                      V_DOWN_PAY_AMOUNT,
             T.LAST_UPDATED_BY      = IS_USER_ACCOUNT,
             T.LAST_UPDATE_DATE     = SYSDATE
       WHERE T.ENTITY_ID = IN_ENTITY_ID
         AND T.CUSTOMER_ID = IN_CUSTOMER_ID
         AND T.ACCOUNT_ID = IN_ACCOUNT_ID
         AND T.SALES_MAIN_TYPE = IS_SALES_MAIN_TYPE;
      
      IF V_SRC_SOURCE_TYPE_ID = 1 THEN
        --提货订单头增加锁定折扣订金
        UPDATE T_PLN_LG_ORDER_HEAD T
           SET T.DOWN_PAY_DIS_AMOUNT = NVL(T.DOWN_PAY_DIS_AMOUNT, 0) +
                                   V_DOWN_PAY_AMOUNT
         WHERE T.ORDER_HEAD_ID = IN_ORDER_ID;
      ELSIF V_SRC_SOURCE_TYPE_ID = 0 THEN
        UPDATE T_PLN_ORDER_HEAD H
           SET H.DOWN_PAY_DIS_AMOUNT = NVL(H.DOWN_PAY_DIS_AMOUNT, 0) +
                                   V_DOWN_PAY_AMOUNT
         WHERE H.ORDER_HEAD_ID = IN_ORDER_ID;
      END IF;
      --增加客户款项锁定到款金额
      UPDATE T_SALES_ACCOUNT_AMOUNT T
         SET T.LOCK_DISCOUNT_AMOUNT = T.LOCK_DISCOUNT_AMOUNT +
                                      V_DOWN_PAY_AMOUNT,
             T.LAST_UPDATED_BY      = IS_USER_ACCOUNT,
             T.LAST_UPDATE_DATE     = SYSDATE
       WHERE T.ENTITY_ID = IN_ENTITY_ID
         AND T.CUSTOMER_ID = IN_CUSTOMER_ID
         AND T.ACCOUNT_ID = IN_ACCOUNT_ID
         AND NVL(T.CREDIT_GROUP_ID, -1) = NVL(V_CREDIT_GROUP_ID, -1);
    END IF;
  
    INSERT INTO T_SALES_AMOUNT_TRANS
      (TRANS_ID, --事务ID
       ENTITY_ID, --主体ID
       SALES_YEAR_ID, --销售年度ID
       CUSTOMER_ID, --客户ID
       ACCOUNT_ID, --账户ID
       CREDIT_GROUP_ID, --额度组ID
       PROJ_NUMBER, --项目号
       SALES_MAIN_TYPE, --营销大类ID
       ORDER_ID, --单据ID
       ORDER_TYPE, --单据类型
       ORDER_NUM, --单据号
       ACTION_FLAG, --动作标识
       TRANS_ACTION, --事务动作（1：增加；2：减少；3：变更）
       AMOUNT_NAME, --款项名称
       AMOUNT, --金额
       DUE_FLAG, --处理标识（1：成功；2：失败）
       CREATED_BY, --创建人
       CREATION_DATE, --创建日期
       LAST_UPDATED_BY, --最后修改人
       LAST_UPDATE_DATE, --最后修改日期
       PRE_FIELD_01,
       PRE_FIELD_02,
       PRE_FIELD_03,
       PRE_FIELD_04,
       PRE_FIELD_05,
       PRE_FIELD_06)
    VALUES
      (S_SALES_AMOUNT_TRANS.NEXTVAL, --事务ID
       IN_ENTITY_ID, --主体ID
       NULL, --销售年度ID
       IN_CUSTOMER_ID, --客户ID
       IN_ACCOUNT_ID, --账户ID
       V_CREDIT_GROUP_ID, --额度组ID
       NULL, --项目号
       IS_SALES_MAIN_TYPE, --营销大类
       IN_ORDER_ID, --单据ID
       IS_ORDER_TYPE, --单据类型
       V_ORDER_NUMBER, --
       IS_ACTION_TYPE, --动作标识
       1, --事务动作（1：增加；2：减少；3：变更）
       '锁定折让金额(订金)', --款项名称
       V_DOWN_PAY_AMOUNT, --金额
       '1', --处理标识（1：成功；2：失败）
       IS_USER_ACCOUNT, --创建人
       SYSDATE, --创建日期
       /*NVL(VR_PLN_LG_ORDER_HEAD.LAST_UPDATED_BY,
           VR_PLN_LG_ORDER_HEAD.CREATED_BY)*/
       IS_USER_ACCOUNT, --最后修改人
       /*NVL(VR_PLN_LG_ORDER_HEAD.LAST_UPDATE_DATE,
           VR_PLN_LG_ORDER_HEAD.CREATION_DATE)*/
       SYSDATE, --最后修改日期
       --IS_USER_ACCOUNT, --最后修改人
       --SYSDATE, --最后修改日期
       NULL,
       NULL,
       NULL,
       NULL,
       NULL,
       NULL);
    OS_MESSAGE := V_SUCCESS;
    --EXCEPTION WHEN OTHERS THEN
      --OS_MESSAGE := '折扣订金锁定异常，请了解！'|| V_NL || SQLERRM ;
  END P_LOCK_DP_DIS_AMOUNT;

  /**
  *订单提货额度锁定、对于动作标识1，调用锁订金或锁款成功之后，调用
  **/
  PROCEDURE P_LOCK_ORDER_AMOUNT(IN_ORDER_ID     IN NUMBER, --提货订单ID
                                IS_ORDER_TYPE   IN VARCHAR2, --提货订单单据类型
                                IN_LOCK_AMOUNT  IN NUMBER, --锁定金额，相当于订单送审时的结算金额
                                IN_ENTITY_ID    IN NUMBER, --主体ID
                                IN_CUSTOMER_ID  IN NUMBER, --客户ID
                                IN_ACCOUNT_ID   IN NUMBER, --账户ID
                                IS_USER_ACCOUNT IN VARCHAR2, --用户账号
                                OS_MESSAGE      OUT VARCHAR2 --成功返回SUCCESS，失败返回出错信息
                                ) IS
    VR_CREDIT_ACCOUNT_LIMIT T_CREDIT_ACCOUNT_LIMIT%ROWTYPE;
    VN_ORDER_TOP_AMOUNT     NUMBER;
    VN_CNT                  NUMBER;
  BEGIN
    BEGIN
      SELECT *
        INTO VR_CREDIT_ACCOUNT_LIMIT
        FROM T_CREDIT_ACCOUNT_LIMIT T
       WHERE T.ENTITY_ID = IN_ENTITY_ID
         AND T.CUSTOMER_ID = IN_CUSTOMER_ID
         AND T.ACCOUNT_ID = IN_ACCOUNT_ID
         FOR UPDATE WAIT 3 --
      ;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        SELECT COUNT(0)
          INTO VN_CNT
          FROM T_BD_PARAM_LIST PL
         WHERE PL.PARAM_CODE = 'CREDIT_ORDER_TOP_AMOUNT'
           AND PL.ACTIVE_FLAG = 'Y';
        IF 0 >= VN_CNT THEN
          OS_MESSAGE := V_SUCCESS;
        ELSE
          PKG_BD.P_GET_PARAMETER_VALUE(P_CONFIG_CODE => 'CREDIT_ORDER_TOP_AMOUNT',
                                       P_ENTITY_ID   => IN_ENTITY_ID,
                                       P_UNIT_ID     => '',
                                       P_CUSTOMER_ID => '',
                                       P_PARAM_VALUE => VN_ORDER_TOP_AMOUNT);
          IF VN_ORDER_TOP_AMOUNT IS NULL THEN
            OS_MESSAGE := V_SUCCESS;
          ELSE
            OS_MESSAGE := '客户账户额度[T_CREDIT_ACCOUNT_LIMIT]找不到ENTITY_ID=' ||
                          IN_ENTITY_ID || '，CUSTOMER_ID=' || IN_CUSTOMER_ID ||
                          '，ACCOUNT_ID=' || IN_ACCOUNT_ID ||
                          '的记录，相应的主体已配置“订单提货上限”的系统参数CREDIT_ORDER_TOP_AMOUNT，参数值=' ||
                          VN_ORDER_TOP_AMOUNT;
          END IF;
        END IF;
        RETURN;
    END;
    --增加订单提货额度已使用金额
    UPDATE T_CREDIT_ACCOUNT_LIMIT T
       SET T.ORDER_USED_AMOUNT = NVL(T.ORDER_USED_AMOUNT,0) + NVL(IN_LOCK_AMOUNT,0),
           T.LAST_UPDATED_BY   = IS_USER_ACCOUNT,
           T.LAST_UPDATE_DATE  = SYSDATE
     WHERE T.ACCOUNT_LIMIT_ID = VR_CREDIT_ACCOUNT_LIMIT.ACCOUNT_LIMIT_ID;
    INSERT INTO T_CREDIT_ACCOUNT_LIMIT_HIS
      (ACCOUNT_LIMIT_HIS_ID, --账户额度历史id
       CUSTOMER_ID, --客户id
       CUSTOMER_CODE, --客户编码
       CUSTOMER_NAME, --客户名称
       SALES_CENTER_ID, --营销中心id
       SALES_CENTER_CODE, --营销中心编码
       SALES_CENTER_NAME, --营销中心名称
       ACCOUNT_ID, --账户id
       ACCOUNT_CODE, --账户编码
       DOWN_PAY_RATE, --订金比例
       ORDER_LIMIT_AMOUNT, --订单提货额度上限
       ORDER_USED_AMOUNT, --已使用订单金额
       ENTITY_ID, --经营主体id
       SOURCE_TYPE, --来源类型
       SOURCE_BILL_ID, --来源单据id
       SOURCE_BILL_NUM, --来源单据号
       OPERATE_DESC, --操作描述
       CREATED_BY, --创建人
       CREATION_DATE, --创建日期
       LAST_UPDATED_BY, --最后更新人
       LAST_UPDATE_DATE --最后更新日期
       )
      SELECT S_CREDIT_ACCOUNT_LIMIT_HIS.NEXTVAL,
             VR_CREDIT_ACCOUNT_LIMIT.CUSTOMER_ID,
             VR_CREDIT_ACCOUNT_LIMIT.CUSTOMER_CODE,
             VR_CREDIT_ACCOUNT_LIMIT.CUSTOMER_NAME,
             VR_CREDIT_ACCOUNT_LIMIT.SALES_CENTER_ID,
             VR_CREDIT_ACCOUNT_LIMIT.SALES_CENTER_CODE,
             VR_CREDIT_ACCOUNT_LIMIT.SALES_CENTER_NAME,
             VR_CREDIT_ACCOUNT_LIMIT.ACCOUNT_ID,
             VR_CREDIT_ACCOUNT_LIMIT.ACCOUNT_CODE,
             VR_CREDIT_ACCOUNT_LIMIT.DOWN_PAY_RATE,
             VR_CREDIT_ACCOUNT_LIMIT.ORDER_LIMIT_AMOUNT,
             IN_LOCK_AMOUNT,
             VR_CREDIT_ACCOUNT_LIMIT.ENTITY_ID,
             IS_ORDER_TYPE,
             IN_ORDER_ID,
             (SELECT ORDER_NUMBER
                FROM T_PLN_LG_ORDER_HEAD
               WHERE ORDER_HEAD_ID = IN_ORDER_ID),
             '订单提货额度锁定',
             NVL(VR_CREDIT_ACCOUNT_LIMIT.LAST_UPDATED_BY,
                 VR_CREDIT_ACCOUNT_LIMIT.CREATED_BY),
             NVL(VR_CREDIT_ACCOUNT_LIMIT.LAST_UPDATE_DATE,
                 VR_CREDIT_ACCOUNT_LIMIT.CREATION_DATE),
             IS_USER_ACCOUNT,
             SYSDATE
        FROM DUAL;
    OS_MESSAGE := V_SUCCESS;
    EXCEPTION WHEN OTHERS THEN
      OS_MESSAGE := '订单提货额度锁定异常，请了解！'|| V_NL || SQLERRM ;
  END P_LOCK_ORDER_AMOUNT;

  /**
  *订金释放，用于动作标识2/28
  
  **/
  PROCEDURE P_UNLOCK_DOWN_PAY_AMOUNT(IN_ORDER_ID        IN NUMBER, --提货订单ID
                                     IS_ORDER_TYPE      IN VARCHAR2, --提货订单单据类型
                                     IS_SALES_MAIN_TYPE IN VARCHAR2, --营销大类
                                     IN_UNLOCK_AMOUNT   IN NUMBER, --锁定金额
                                     IN_ENTITY_ID       IN NUMBER, --主体ID
                                     IN_CUSTOMER_ID     IN NUMBER, --客户ID
                                     IN_ACCOUNT_ID      IN NUMBER, --账户ID
                                     IN_DOWN_PAY_RATE   IN NUMBER, --订金比例
                                     IS_ACTION_TYPE     IN VARCHAR2, --动作标识
                                     IS_USER_ACCOUNT    IN VARCHAR2, --用户账号
                                     OS_MESSAGE         OUT VARCHAR2, --成功返回SUCCESS，失败返回出错信息
                                     IS_DISCOUNT_TYPE    IN VARCHAR2 DEFAULT NULL--折让方式
                                     ) IS
    V_DOWN_PAY_AMOUNT        NUMBER; --释放订金
    V_DOWN_PAY_AMOUNT_BYRATE NUMBER; --按比例计算的释放订金
    V_CREDIT_GROUP_ID        NUMBER;
    VR_PLN_LG_ORDER_HEAD     T_PLN_LG_ORDER_HEAD%ROWTYPE;
    VR_PLN_ORDER_HEAD T_PLN_ORDER_HEAD%ROWTYPE;
    V_ORDER_NUMBER VARCHAR2(50);
    V_SRC_SOURCE_TYPE_ID NUMBER;
    V_ORDER_DOWN_PAY_AMOUNT NUMBER;
  BEGIN
    --获取订单源类型
    SELECT T.SOURCE_ORDER_TYPE_ID
      INTO V_SRC_SOURCE_TYPE_ID
      FROM T_PLN_ORDER_TYPE T
     WHERE T.ENTITY_ID = IN_ENTITY_ID
       AND T.ORDER_TYPE_CODE = IS_ORDER_TYPE;
    
    IF V_SRC_SOURCE_TYPE_ID = 1 THEN
      SELECT *
        INTO VR_PLN_LG_ORDER_HEAD
        FROM T_PLN_LG_ORDER_HEAD
       WHERE ORDER_HEAD_ID = IN_ORDER_ID
         FOR UPDATE WAIT 3;
      V_ORDER_NUMBER := VR_PLN_LG_ORDER_HEAD.ORDER_NUMBER;
      V_ORDER_DOWN_PAY_AMOUNT := VR_PLN_LG_ORDER_HEAD.DOWN_PAY_AMOUNT;
    ELSIF V_SRC_SOURCE_TYPE_ID = 0 THEN
      SELECT *
        INTO VR_PLN_ORDER_HEAD
        FROM T_PLN_ORDER_HEAD H
       WHERE H.ORDER_HEAD_ID = IN_ORDER_ID
         FOR UPDATE WAIT 3;
      V_ORDER_NUMBER := VR_PLN_ORDER_HEAD.Order_Number;
      V_ORDER_DOWN_PAY_AMOUNT := VR_PLN_ORDER_HEAD.DOWN_PAY_AMOUNT;
    END IF;
    --如果订金为空或者小于0，不用释放订金，直接返回成功
    IF 0 = NVL(/*VR_PLN_LG_ORDER_HEAD.DOWN_PAY_AMOUNT*/V_ORDER_DOWN_PAY_AMOUNT, 0) THEN
      OS_MESSAGE := V_SUCCESS;
      RETURN;
    END IF;
    --按比例计算释放订金
    V_DOWN_PAY_AMOUNT_BYRATE := (IN_UNLOCK_AMOUNT * IN_DOWN_PAY_RATE) / 100;
    V_DOWN_PAY_AMOUNT := V_DOWN_PAY_AMOUNT_BYRATE;
    --释放订金跟当前订金取最小值，
    /*V_DOWN_PAY_AMOUNT := LEAST(V_DOWN_PAY_AMOUNT_BYRATE,
                               VR_PLN_LG_ORDER_HEAD.DOWN_PAY_AMOUNT);*/
  --2017-4-22 获取额度组增加账户ID liangym2
    V_CREDIT_GROUP_ID := PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(IN_ENTITY_ID,
                                                                IN_CUSTOMER_ID,
                                                                IS_SALES_MAIN_TYPE,IN_ACCOUNT_ID);
    IF 0 <> V_DOWN_PAY_AMOUNT THEN
      --减少客户款项明细锁定到款金额
      UPDATE T_SALES_ACCOUNT_MX_AMOUNT T
         SET T.LOCK_RECEIVED_AMOUNT = T.LOCK_RECEIVED_AMOUNT -
                                      V_DOWN_PAY_AMOUNT,
             T.LAST_UPDATED_BY      = IS_USER_ACCOUNT,
             T.LAST_UPDATE_DATE     = SYSDATE
       WHERE T.ENTITY_ID = IN_ENTITY_ID
         AND T.CUSTOMER_ID = IN_CUSTOMER_ID
         AND T.ACCOUNT_ID = IN_ACCOUNT_ID
         AND T.SALES_MAIN_TYPE = IS_SALES_MAIN_TYPE;
      
      IF V_SRC_SOURCE_TYPE_ID = 1 THEN
        --提货订单头减少锁定订金
        UPDATE T_PLN_LG_ORDER_HEAD T
           SET T.DOWN_PAY_AMOUNT = NVL(T.DOWN_PAY_AMOUNT, 0) -
                                   V_DOWN_PAY_AMOUNT
         WHERE T.ORDER_HEAD_ID = IN_ORDER_ID;
      ELSIF V_SRC_SOURCE_TYPE_ID = 0 THEN
        UPDATE T_PLN_ORDER_HEAD H
           SET H.DOWN_PAY_AMOUNT = NVL(H.DOWN_PAY_AMOUNT, 0) - V_DOWN_PAY_AMOUNT
         WHERE H.ORDER_HEAD_ID = IN_ORDER_ID;
      END IF;
      --减少客户款项锁定到款金额
      UPDATE T_SALES_ACCOUNT_AMOUNT T
         SET T.LOCK_RECEIVED_AMOUNT = T.LOCK_RECEIVED_AMOUNT -
                                      V_DOWN_PAY_AMOUNT,
             T.LAST_UPDATED_BY      = IS_USER_ACCOUNT,
             T.LAST_UPDATE_DATE     = SYSDATE
       WHERE T.ENTITY_ID = IN_ENTITY_ID
         AND T.CUSTOMER_ID = IN_CUSTOMER_ID
         AND T.ACCOUNT_ID = IN_ACCOUNT_ID
         AND NVL(T.CREDIT_GROUP_ID, -1) = NVL(V_CREDIT_GROUP_ID, -1);
    END IF;
  
    INSERT INTO T_SALES_AMOUNT_TRANS
      (TRANS_ID, --事务ID
       ENTITY_ID, --主体ID
       SALES_YEAR_ID, --销售年度ID
       CUSTOMER_ID, --客户ID
       ACCOUNT_ID, --账户ID
       CREDIT_GROUP_ID, --额度组ID
       PROJ_NUMBER, --项目号
       SALES_MAIN_TYPE, --营销大类ID
       ORDER_ID, --单据ID
       ORDER_TYPE, --单据类型
       ORDER_NUM, --单据号
       ACTION_FLAG, --动作标识
       TRANS_ACTION, --事务动作（1：增加；2：减少；3：变更）
       AMOUNT_NAME, --款项名称
       AMOUNT, --金额
       DUE_FLAG, --处理标识（1：成功；2：失败）
       CREATED_BY, --创建人
       CREATION_DATE, --创建日期
       LAST_UPDATED_BY, --最后修改人
       LAST_UPDATE_DATE, --最后修改日期
       PRE_FIELD_01,
       PRE_FIELD_02,
       PRE_FIELD_03,
       PRE_FIELD_04,
       PRE_FIELD_05,
       PRE_FIELD_06)
    VALUES
      (S_SALES_AMOUNT_TRANS.NEXTVAL, --事务ID
       IN_ENTITY_ID, --主体ID
       NULL, --销售年度ID
       IN_CUSTOMER_ID, --客户ID
       IN_ACCOUNT_ID, --账户ID
       V_CREDIT_GROUP_ID, --额度组ID
       NULL, --项目号
       IS_SALES_MAIN_TYPE, --营销大类
       IN_ORDER_ID, --单据ID
       IS_ORDER_TYPE, --单据类型
       V_ORDER_NUMBER, --
       IS_ACTION_TYPE, --动作标识
       2, --事务动作（1：增加；2：减少；3：变更）
       '锁定到款金额(订金)', --款项名称
       V_DOWN_PAY_AMOUNT, --金额
       '1', --处理标识（1：成功；2：失败）
       IS_USER_ACCOUNT, --创建人
       SYSDATE, --创建日期
       /*NVL(VR_PLN_LG_ORDER_HEAD.LAST_UPDATED_BY,
           VR_PLN_LG_ORDER_HEAD.CREATED_BY)*/
       IS_USER_ACCOUNT, --最后修改人
       /*NVL(VR_PLN_LG_ORDER_HEAD.LAST_UPDATE_DATE,
           VR_PLN_LG_ORDER_HEAD.CREATION_DATE)*/
       SYSDATE, --最后修改日期
       --IS_USER_ACCOUNT, --最后修改人
       --SYSDATE, --最后修改日期
       V_DOWN_PAY_AMOUNT_BYRATE,
       NULL,
       NULL,
       NULL,
       NULL,
       NULL);
    OS_MESSAGE := V_SUCCESS;
    --EXCEPTION WHEN OTHERS THEN
      --OS_MESSAGE := '订金释放异常，请了解！'|| V_NL || SQLERRM ;
  END P_UNLOCK_DOWN_PAY_AMOUNT;

  /**
  *折扣订金释放，用于动作标识2/28
  
  **/
  PROCEDURE P_UNLOCK_DP_DIS_AMOUNT(IN_ORDER_ID        IN NUMBER, --提货订单ID
                                     IS_ORDER_TYPE      IN VARCHAR2, --提货订单单据类型
                                     IS_SALES_MAIN_TYPE IN VARCHAR2, --营销大类
                                     IN_UNLOCK_AMOUNT   IN NUMBER, --锁定金额
                                     IN_ENTITY_ID       IN NUMBER, --主体ID
                                     IN_CUSTOMER_ID     IN NUMBER, --客户ID
                                     IN_ACCOUNT_ID      IN NUMBER, --账户ID
                                     IN_DOWN_PAY_RATE   IN NUMBER, --订金比例
                                     IS_ACTION_TYPE     IN VARCHAR2, --动作标识
                                     IS_USER_ACCOUNT    IN VARCHAR2, --用户账号
                                     OS_MESSAGE         OUT VARCHAR2, --成功返回SUCCESS，失败返回出错信息
                                     IS_DISCOUNT_TYPE    IN VARCHAR2 DEFAULT NULL--折让方式
                                     ) IS
    V_DOWN_PAY_AMOUNT        NUMBER; --释放订金
    V_DOWN_PAY_AMOUNT_BYRATE NUMBER; --按比例计算的释放订金
    V_CREDIT_GROUP_ID        NUMBER;
    VR_PLN_LG_ORDER_HEAD     T_PLN_LG_ORDER_HEAD%ROWTYPE;
    VR_PLN_ORDER_HEAD T_PLN_ORDER_HEAD%ROWTYPE;
    V_ORDER_NUMBER VARCHAR2(50);
    V_SRC_SOURCE_TYPE_ID NUMBER;
    V_ORDER_DOWN_PAY_DISAMOUNT NUMBER;
  BEGIN
    --获取订单源类型
    SELECT T.SOURCE_ORDER_TYPE_ID
      INTO V_SRC_SOURCE_TYPE_ID
      FROM T_PLN_ORDER_TYPE T
     WHERE T.ENTITY_ID = IN_ENTITY_ID
       AND T.ORDER_TYPE_CODE = IS_ORDER_TYPE;
     
    IF V_SRC_SOURCE_TYPE_ID = 1 THEN
      SELECT *
        INTO VR_PLN_LG_ORDER_HEAD
        FROM T_PLN_LG_ORDER_HEAD
       WHERE ORDER_HEAD_ID = IN_ORDER_ID
         FOR UPDATE WAIT 3;
      V_ORDER_NUMBER := VR_PLN_LG_ORDER_HEAD.ORDER_NUMBER;
      V_ORDER_DOWN_PAY_DISAMOUNT := VR_PLN_LG_ORDER_HEAD.DOWN_PAY_DIS_AMOUNT;
    ELSIF V_SRC_SOURCE_TYPE_ID = 0 THEN
      SELECT *
        INTO VR_PLN_ORDER_HEAD
        FROM T_PLN_ORDER_HEAD H
       WHERE H.ORDER_HEAD_ID = IN_ORDER_ID
         FOR UPDATE WAIT 3;
      V_ORDER_NUMBER := VR_PLN_ORDER_HEAD.ORDER_NUMBER;
      V_ORDER_DOWN_PAY_DISAMOUNT := VR_PLN_ORDER_HEAD.DOWN_PAY_DIS_AMOUNT;
    END IF;
    --如果订金为空或者小于0，不用释放订金，直接返回成功
    IF 0 = NVL(/*VR_PLN_LG_ORDER_HEAD.DOWN_PAY_DIS_AMOUNT*/V_ORDER_DOWN_PAY_DISAMOUNT, 0) THEN
      OS_MESSAGE := V_SUCCESS;
      RETURN;
    END IF;
    --按比例计算释放订金
    V_DOWN_PAY_AMOUNT_BYRATE := (IN_UNLOCK_AMOUNT * IN_DOWN_PAY_RATE) / 100;
    V_DOWN_PAY_AMOUNT := V_DOWN_PAY_AMOUNT_BYRATE;
    --释放订金跟当前订金取最小值，
    /*V_DOWN_PAY_AMOUNT := LEAST(V_DOWN_PAY_AMOUNT_BYRATE,
                               VR_PLN_LG_ORDER_HEAD.DOWN_PAY_DIS_AMOUNT);*/
  --2017-4-22 获取额度组增加账户ID liangym2
    V_CREDIT_GROUP_ID := PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(IN_ENTITY_ID,
                                                                IN_CUSTOMER_ID,
                                                                IS_SALES_MAIN_TYPE,IN_ACCOUNT_ID);
    IF 0 <> V_DOWN_PAY_AMOUNT THEN
      --减少客户款项明细锁定到款金额
      UPDATE T_SALES_ACCOUNT_MX_AMOUNT T
         SET T.LOCK_DISCOUNT_AMOUNT = T.LOCK_DISCOUNT_AMOUNT -
                                      V_DOWN_PAY_AMOUNT,
             T.LAST_UPDATED_BY      = IS_USER_ACCOUNT,
             T.LAST_UPDATE_DATE     = SYSDATE
       WHERE T.ENTITY_ID = IN_ENTITY_ID
         AND T.CUSTOMER_ID = IN_CUSTOMER_ID
         AND T.ACCOUNT_ID = IN_ACCOUNT_ID
         AND T.SALES_MAIN_TYPE = IS_SALES_MAIN_TYPE;
      
      IF V_SRC_SOURCE_TYPE_ID = 1 THEN
        --提货订单头减少锁定订金
        UPDATE T_PLN_LG_ORDER_HEAD T
           SET T.DOWN_PAY_DIS_AMOUNT = NVL(T.DOWN_PAY_DIS_AMOUNT, 0) -
                                   V_DOWN_PAY_AMOUNT
         WHERE T.ORDER_HEAD_ID = IN_ORDER_ID;
      ELSIF V_SRC_SOURCE_TYPE_ID = 0 THEN
        UPDATE T_PLN_ORDER_HEAD H
           SET H.DOWN_PAY_DIS_AMOUNT = NVL(H.DOWN_PAY_DIS_AMOUNT, 0) -
                                     V_DOWN_PAY_AMOUNT
         WHERE H.ORDER_HEAD_ID = IN_ORDER_ID;
      END IF;
      --减少客户款项锁定到款金额
      UPDATE T_SALES_ACCOUNT_AMOUNT T
         SET T.LOCK_DISCOUNT_AMOUNT = T.LOCK_DISCOUNT_AMOUNT -
                                      V_DOWN_PAY_AMOUNT,
             T.LAST_UPDATED_BY      = IS_USER_ACCOUNT,
             T.LAST_UPDATE_DATE     = SYSDATE
       WHERE T.ENTITY_ID = IN_ENTITY_ID
         AND T.CUSTOMER_ID = IN_CUSTOMER_ID
         AND T.ACCOUNT_ID = IN_ACCOUNT_ID
         AND NVL(T.CREDIT_GROUP_ID, -1) = NVL(V_CREDIT_GROUP_ID, -1);
    END IF;
  
    INSERT INTO T_SALES_AMOUNT_TRANS
      (TRANS_ID, --事务ID
       ENTITY_ID, --主体ID
       SALES_YEAR_ID, --销售年度ID
       CUSTOMER_ID, --客户ID
       ACCOUNT_ID, --账户ID
       CREDIT_GROUP_ID, --额度组ID
       PROJ_NUMBER, --项目号
       SALES_MAIN_TYPE, --营销大类ID
       ORDER_ID, --单据ID
       ORDER_TYPE, --单据类型
       ORDER_NUM, --单据号
       ACTION_FLAG, --动作标识
       TRANS_ACTION, --事务动作（1：增加；2：减少；3：变更）
       AMOUNT_NAME, --款项名称
       AMOUNT, --金额
       DUE_FLAG, --处理标识（1：成功；2：失败）
       CREATED_BY, --创建人
       CREATION_DATE, --创建日期
       LAST_UPDATED_BY, --最后修改人
       LAST_UPDATE_DATE, --最后修改日期
       PRE_FIELD_01,
       PRE_FIELD_02,
       PRE_FIELD_03,
       PRE_FIELD_04,
       PRE_FIELD_05,
       PRE_FIELD_06)
    VALUES
      (S_SALES_AMOUNT_TRANS.NEXTVAL, --事务ID
       IN_ENTITY_ID, --主体ID
       NULL, --销售年度ID
       IN_CUSTOMER_ID, --客户ID
       IN_ACCOUNT_ID, --账户ID
       V_CREDIT_GROUP_ID, --额度组ID
       NULL, --项目号
       IS_SALES_MAIN_TYPE, --营销大类
       IN_ORDER_ID, --单据ID
       IS_ORDER_TYPE, --单据类型
       V_ORDER_NUMBER, --
       IS_ACTION_TYPE, --动作标识
       2, --事务动作（1：增加；2：减少；3：变更）
       '锁定折让金额(订金)', --款项名称
       V_DOWN_PAY_AMOUNT, --金额
       '1', --处理标识（1：成功；2：失败）
       IS_USER_ACCOUNT, --创建人
       SYSDATE, --创建日期
       /*NVL(VR_PLN_LG_ORDER_HEAD.LAST_UPDATED_BY,
           VR_PLN_LG_ORDER_HEAD.CREATED_BY)*/
       IS_USER_ACCOUNT, --最后修改人
       /*NVL(VR_PLN_LG_ORDER_HEAD.LAST_UPDATE_DATE,
           VR_PLN_LG_ORDER_HEAD.CREATION_DATE)*/
       SYSDATE, --最后修改日期
       --IS_USER_ACCOUNT, --最后修改人
       --SYSDATE, --最后修改日期
       V_DOWN_PAY_AMOUNT_BYRATE,
       NULL,
       NULL,
       NULL,
       NULL,
       NULL);
    OS_MESSAGE := V_SUCCESS;
    --EXCEPTION WHEN OTHERS THEN
      --OS_MESSAGE := '折扣订金释放异常，请了解！'|| V_NL || SQLERRM ;
  END P_UNLOCK_DP_DIS_AMOUNT;

  /**
  *订单提货额度锁定释放
  *发货通知单进行确认生成销售单时，或者提货订单驳回、关闭时，对订单提货额度的占用进行释放
  **/
  PROCEDURE P_UNLOCK_ORDER_AMOUNT(IN_ORDER_ID   IN NUMBER, --提货订单ID，或发货通知单来源与提货订单的计划订单ID
                                  IS_ORDER_TYPE IN VARCHAR2,
                                  --提货订单单据类型，或发货通知单来源与提货订单的计划订单类型
                                  IN_UNLOCK_AMOUNT IN NUMBER, --释放金额
                                  IS_USER_ACCOUNT  IN VARCHAR2, --用户账号
                                  OS_MESSAGE       OUT VARCHAR2 --成功返回SUCCESS，失败返回出错信息
                                  ) IS
    VR_CREDIT_ACCOUNT_LIMIT T_CREDIT_ACCOUNT_LIMIT%ROWTYPE;
    VR_PLN_LG_ORDER_HEAD    T_PLN_LG_ORDER_HEAD%ROWTYPE;
    VR_PLN_ORDER_HEAD       T_PLN_ORDER_HEAD%ROWTYPE;
    VN_UNLOCK_AMOUNT        NUMBER;
  BEGIN
    BEGIN
      SELECT OH.*
        INTO VR_PLN_LG_ORDER_HEAD
        FROM T_PLN_LG_ORDER_HEAD OH
       WHERE OH.ORDER_HEAD_ID = IN_ORDER_ID
         AND OH.ORDER_TYPE_CODE = IS_ORDER_TYPE;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        BEGIN
          FOR LI IN (SELECT OH.ORDER_HEAD_ID LG_ORDER_HEAD_ID,
                            PH.ORDER_HEAD_ID ORDER_HEAD_ID
                       FROM T_PLN_LG_ORDER_HEAD OH, T_PLN_ORDER_HEAD PH
                      WHERE PH.ORDER_HEAD_ID = IN_ORDER_ID
                        AND PH.ORDER_TYPE_CODE = IS_ORDER_TYPE
                        AND PH.ENTITY_ID = OH.ENTITY_ID
                        AND EXISTS
                      (SELECT 1
                               FROM T_LG_SHIP_DOC_LINE DL, T_LG_SHIP_DOC SD
                              WHERE (DL.SHIP_DOC_ID = SD.SHIP_DOC_ID AND
                                    OH.ENTITY_ID = SD.ENTITY_ID AND
                                    DL.ORIGIN_ORIGIN_TYPE = '02' --来源类型(01：计划订单 02：提货订单 03 ：调拨订单 04：促销品 05：备货订单)
                                    AND OH.ORDER_HEAD_ID =
                                    DL.ORIGIN_ORIGIN_HEAD_ID AND
                                    OH.ORDER_NUMBER =
                                    DL.ORIGIN_ORIGIN_DOC_CODE AND
                                    DL.ORIGIN_TYPE = '01' --T+3属于计划订单
                                    AND
                                    DL.ORIGIN_ORDER_ID = PH.ORDER_HEAD_ID))) LOOP
            VR_PLN_LG_ORDER_HEAD.ORDER_HEAD_ID := LI.LG_ORDER_HEAD_ID;
            VR_PLN_ORDER_HEAD.ORDER_HEAD_ID    := LI.ORDER_HEAD_ID;
          END LOOP;
          SELECT *
            INTO VR_PLN_LG_ORDER_HEAD
            FROM T_PLN_LG_ORDER_HEAD
           WHERE ORDER_HEAD_ID = VR_PLN_LG_ORDER_HEAD.ORDER_HEAD_ID;
          SELECT *
            INTO VR_PLN_ORDER_HEAD
            FROM T_PLN_ORDER_HEAD
           WHERE ORDER_HEAD_ID = VR_PLN_ORDER_HEAD.ORDER_HEAD_ID;
        
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            OS_MESSAGE := V_SUCCESS;
            /*OS_MESSAGE := '释放订单提货额度不成功，传入的提货订单ID、提货订单类型(' || IN_ORDER_ID || '、' ||
                          IS_ORDER_TYPE || ')有误，无法获取到数据';*/
            RETURN;
        END;
    END;
  
    BEGIN
      SELECT *
        INTO VR_CREDIT_ACCOUNT_LIMIT
        FROM T_CREDIT_ACCOUNT_LIMIT T
       WHERE T.ENTITY_ID = VR_PLN_LG_ORDER_HEAD.ENTITY_ID
         AND T.CUSTOMER_ID = VR_PLN_LG_ORDER_HEAD.CUSTOMER_ID
         AND T.ACCOUNT_ID = VR_PLN_LG_ORDER_HEAD.ACCOUNT_ID
         FOR UPDATE WAIT 3 --
      ;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        OS_MESSAGE := V_SUCCESS;
        RETURN;
      WHEN TOO_MANY_ROWS THEN
        OS_MESSAGE := V_SUCCESS;
        --OS_MESSAGE := 'T_CREDIT_ACCOUNT_LIMIT存在多条';--建一个唯一索引吧
        RETURN;
    END;
    --如果订单提货已使用额度为空或者小于0，不用释放，直接返回成功
    IF 0 = NVL(VR_CREDIT_ACCOUNT_LIMIT.ORDER_USED_AMOUNT, 0) THEN
      OS_MESSAGE := V_SUCCESS; --使用自治事务记录
      RETURN;
    END IF;
    VN_UNLOCK_AMOUNT := LEAST(IN_UNLOCK_AMOUNT,
                              VR_CREDIT_ACCOUNT_LIMIT.ORDER_USED_AMOUNT);
  
    --减少订单提货额度已使用金额
    UPDATE T_CREDIT_ACCOUNT_LIMIT T
       SET T.ORDER_USED_AMOUNT = NVL(T.ORDER_USED_AMOUNT,0) - NVL(VN_UNLOCK_AMOUNT,0),
           T.LAST_UPDATED_BY   = IS_USER_ACCOUNT,
           T.LAST_UPDATE_DATE  = SYSDATE
     WHERE T.ACCOUNT_LIMIT_ID = VR_CREDIT_ACCOUNT_LIMIT.ACCOUNT_LIMIT_ID;
    INSERT INTO T_CREDIT_ACCOUNT_LIMIT_HIS
      (ACCOUNT_LIMIT_HIS_ID, --账户额度历史id
       CUSTOMER_ID, --客户id
       CUSTOMER_CODE, --客户编码
       CUSTOMER_NAME, --客户名称
       SALES_CENTER_ID, --营销中心id
       SALES_CENTER_CODE, --营销中心编码
       SALES_CENTER_NAME, --营销中心名称
       ACCOUNT_ID, --账户id
       ACCOUNT_CODE, --账户编码
       DOWN_PAY_RATE, --订金比例
       ORDER_LIMIT_AMOUNT, --订单提货额度上限
       ORDER_USED_AMOUNT, --已使用订单金额
       ENTITY_ID, --经营主体id
       SOURCE_TYPE, --来源类型
       SOURCE_BILL_ID, --来源单据id
       SOURCE_BILL_NUM, --来源单据号
       OPERATE_DESC, --操作描述
       CREATED_BY, --创建人
       CREATION_DATE, --创建日期
       LAST_UPDATED_BY, --最后更新人
       LAST_UPDATE_DATE --最后更新日期
       )
      SELECT S_CREDIT_ACCOUNT_LIMIT_HIS.NEXTVAL,
             VR_CREDIT_ACCOUNT_LIMIT.CUSTOMER_ID,
             VR_CREDIT_ACCOUNT_LIMIT.CUSTOMER_CODE,
             VR_CREDIT_ACCOUNT_LIMIT.CUSTOMER_NAME,
             VR_CREDIT_ACCOUNT_LIMIT.SALES_CENTER_ID,
             VR_CREDIT_ACCOUNT_LIMIT.SALES_CENTER_CODE,
             VR_CREDIT_ACCOUNT_LIMIT.SALES_CENTER_NAME,
             VR_CREDIT_ACCOUNT_LIMIT.ACCOUNT_ID,
             VR_CREDIT_ACCOUNT_LIMIT.ACCOUNT_CODE,
             VR_CREDIT_ACCOUNT_LIMIT.DOWN_PAY_RATE,
             VR_CREDIT_ACCOUNT_LIMIT.ORDER_LIMIT_AMOUNT,
             -VN_UNLOCK_AMOUNT,
             VR_CREDIT_ACCOUNT_LIMIT.ENTITY_ID,
             IS_ORDER_TYPE,
             IN_ORDER_ID,
             NVL(VR_PLN_ORDER_HEAD.ORDER_NUMBER,
                 VR_PLN_LG_ORDER_HEAD.ORDER_NUMBER),
             '订单提货额度释放',
             NVL(VR_CREDIT_ACCOUNT_LIMIT.LAST_UPDATED_BY,
                 VR_CREDIT_ACCOUNT_LIMIT.CREATED_BY),
             NVL(VR_CREDIT_ACCOUNT_LIMIT.LAST_UPDATE_DATE,
                 VR_CREDIT_ACCOUNT_LIMIT.CREATION_DATE),
             IS_USER_ACCOUNT,
             SYSDATE
        FROM DUAL;
    OS_MESSAGE := V_SUCCESS;
    EXCEPTION WHEN OTHERS THEN
      OS_MESSAGE := '订单提货额度锁定释放异常，请了解！'|| V_NL || SQLERRM ;
  END P_UNLOCK_ORDER_AMOUNT;

  /***
  *客户订单提货额度校验
  */
  PROCEDURE PRC_ORDER_AMOUNT_VERIFICATION(IN_ENTITY_ID         IN NUMBER, --主体ID
                                          IN_ACTION_TYPE       IN NUMBER, --动作标示
                                          IN_CUSTOMER_ID       IN NUMBER, --客户ID
                                          IN_ACCOUNT_ID        IN NUMBER, --账户ID
                                          IN_SETTLEMENT_AMOUNT IN NUMBER, --结算金额
                                          ON_RESULT            IN OUT NUMBER, --返回错误ID
                                          OS_ERR_MSG           IN OUT VARCHAR2 --返回错误信息
                                          ) IS
    VN_CREDIT_ACCOUNT_LIMIT T_CREDIT_ACCOUNT_LIMIT.ORDER_LIMIT_AMOUNT%TYPE;
    VN_ORDER_USED_AMOUNT    T_CREDIT_ACCOUNT_LIMIT.ORDER_USED_AMOUNT%TYPE;
  BEGIN
    ON_RESULT  := V_SEC_RESULT;
    OS_ERR_MSG := V_SUCCESS;
    BEGIN
      SELECT T.ORDER_LIMIT_AMOUNT, NVL(T.ORDER_USED_AMOUNT, 0)
        INTO VN_CREDIT_ACCOUNT_LIMIT, VN_ORDER_USED_AMOUNT
        FROM T_CREDIT_ACCOUNT_LIMIT T
       WHERE T.ENTITY_ID = IN_ENTITY_ID
         AND T.CUSTOMER_ID = IN_CUSTOMER_ID
         AND T.ACCOUNT_ID = IN_ACCOUNT_ID;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        PRC_CREDIT_LIMIT_HAVE_PARAM(IN_ENTITY_ID,IN_CUSTOMER_ID,IN_ACCOUNT_ID
        ,VN_CREDIT_ACCOUNT_LIMIT,VN_CREDIT_ACCOUNT_LIMIT,VN_CREDIT_ACCOUNT_LIMIT
        ,VN_CREDIT_ACCOUNT_LIMIT,OS_ERR_MSG);
        IF OS_ERR_MSG <> V_SUCCESS THEN
          ON_RESULT  := V_SEC_RESULT;
          OS_ERR_MSG := V_SUCCESS;
          RETURN;
        END IF;
        PRC_CREDIT_ACC_LIMIT_UPDATE(IN_ENTITY_ID,IN_CUSTOMER_ID,IN_ACCOUNT_ID,
        'PRC_ORDER_AMOUNT_VERIFICATION',OS_ERR_MSG, 1);
        IF OS_ERR_MSG <> V_SUCCESS THEN
          ON_RESULT  := -20000;
          OS_ERR_MSG := '订单可提货额度校验不成功：无法获取、初始化客户账户额度：' || OS_ERR_MSG;
        ELSE
          BEGIN
            SELECT T.ORDER_LIMIT_AMOUNT, NVL(T.ORDER_USED_AMOUNT, 0)
              INTO VN_CREDIT_ACCOUNT_LIMIT, VN_ORDER_USED_AMOUNT
              FROM T_CREDIT_ACCOUNT_LIMIT T
             WHERE T.ENTITY_ID = IN_ENTITY_ID
               AND T.CUSTOMER_ID = IN_CUSTOMER_ID
               AND T.ACCOUNT_ID = IN_ACCOUNT_ID;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              ON_RESULT  := -20000;
              OS_ERR_MSG := '订单可提货额度校验异常：无法获取、初始化客户账户额度!';
          END;
        END IF;
    END;
    IF ON_RESULT <> V_SEC_RESULT OR OS_ERR_MSG <> V_SUCCESS THEN
      RETURN;
    END IF;
  
    IF VN_CREDIT_ACCOUNT_LIMIT IS NULL THEN
      ON_RESULT  := V_SEC_RESULT;
      OS_ERR_MSG := V_SUCCESS;
      RETURN;
    END IF;
    IF IN_ACTION_TYPE IN (1, 28) AND
       (VN_CREDIT_ACCOUNT_LIMIT - VN_ORDER_USED_AMOUNT) <
       IN_SETTLEMENT_AMOUNT THEN
      ON_RESULT  := -20000;
      OS_ERR_MSG := '订单送审校验不通过!';
      OS_ERR_MSG := OS_ERR_MSG || V_NL || '【原因：客户提货订单可提货额度(' ||
                    (VN_CREDIT_ACCOUNT_LIMIT - VN_ORDER_USED_AMOUNT) ||
                    ')小于当前订单需要锁定的提货金额(' || IN_SETTLEMENT_AMOUNT || ')，可在“信用管理-信用报表查询-客户账户额度查询”查询，在“信用管理-信用基础数据-订金配置-按账户”进行配置（提货订单可提货额度可修改）！';
    ELSIF IN_ACTION_TYPE = 2 AND
          VN_ORDER_USED_AMOUNT < IN_SETTLEMENT_AMOUNT THEN
      ON_RESULT  := -20000;
      OS_ERR_MSG := '取消订单校验不通过!';
      OS_ERR_MSG := OS_ERR_MSG || V_NL || '【原因：客户订单已使用提货金额：' ||
                    VN_ORDER_USED_AMOUNT || '小于因当前订单关闭或驳回取消的提货金额(' ||
                    IN_SETTLEMENT_AMOUNT || ')，可在“信用管理-信用报表查询-客户账户额度查询”查询，在“信用管理-信用基础数据-订金配置-按账户”进行配置（提货订单可提货额度设置为空时，即可以对此不做校验）！';
    END IF;
  END PRC_ORDER_AMOUNT_VERIFICATION;

  PROCEDURE PRC_DOWN_PAY_VERIFICATION(IN_ENTITY_ID            IN NUMBER, --主体ID
                                      IN_ACTION_TYPE          IN NUMBER, --动作标示
                                      IN_CUSTOMER_ID          IN NUMBER, --客户ID
                                      IN_ACCOUNT_ID           IN NUMBER, --账户ID
                                      IN_SETTLEMENT_AMOUNT    IN NUMBER, --结算金额
                                      IN_DISCOUNT_AMOUNT      IN NUMBER, --折扣金额
                                      IN_AMOUNT_SUM           IN NUMBER, --金额控制金额
                                      IN_DISCOUNT_SUM         IN NUMBER, --折扣控制金额
                                      IS_DISCOUNT_CTRL_FLAG   IN VARCHAR2, --折扣控制方式
                                      IN_CHK_DIS_AMOUNT       IN NUMBER, --合并折让余额
                                      IN_DOWN_PAY_SCALE       IN NUMBER, --订金比例
                                      IN_SRC_ORDER_ID         IN NUMBER,--单据ID
                                      IS_SRC_ORDER_NUM        IN VARCHAR2,--单据号
                                      IS_SRC_ORDER_TYPE       IN VARCHAR2,--单据类型
                                      IN_DOWN_PAY_AMOUNT      IN NUMBER,--订金
                                      IN_DP_DIS_AMOUNT        IN NUMBER,--折扣订金
                                      IN_LOCK_RECEIVED_AMOUNT IN NUMBER, --锁定到款金额
                                      IN_LOCK_DISCOUNT_AMOUNT IN NUMBER, --锁定折扣金额
                                      IN_ORDER_VERIFY_FLAG    IN NUMBER, -- 订单提货额度检查 1检查提货额度以及订金 2检查提货额度、不检查订金 3检查订金、不检查提货额度
                                      ON_RESULT               IN OUT NUMBER, --返回错误ID
                                      OS_ERR_MSG              IN OUT VARCHAR2 --返回错误信息
                                      ) IS
    VN_DOWN_PAY_AMOUNT NUMBER;
  BEGIN
    IF IN_ORDER_VERIFY_FLAG IN (1, 2) THEN
      PRC_ORDER_AMOUNT_VERIFICATION(IN_ENTITY_ID,
                                    IN_ACTION_TYPE,
                                    IN_CUSTOMER_ID,
                                    IN_ACCOUNT_ID,
                                    IN_SETTLEMENT_AMOUNT,
                                    ON_RESULT,
                                    OS_ERR_MSG);
      IF ON_RESULT <> V_SEC_RESULT THEN
        RETURN;
      END IF;
    END IF;
    IF 2 = IN_ORDER_VERIFY_FLAG THEN
      RETURN;
    END IF;
    IF OS_ERR_MSG IS NULL THEN
      OS_ERR_MSG := '';
    END IF;
    IF IN_ACTION_TYPE = 1 THEN
      --送审锁款，且订金比例大于0，按比例计算要锁定的订金，判断可用到款余额是否小于订金
      VN_DOWN_PAY_AMOUNT := (IN_DOWN_PAY_SCALE * IN_Settlement_AMOUNT) / 100;
      IF 0 = IN_DOWN_PAY_SCALE OR ((IN_AMOUNT_SUM + IN_CHK_DIS_AMOUNT) >= VN_DOWN_PAY_AMOUNT) THEN
        ON_RESULT  := V_SEC_RESULT;
        OS_ERR_MSG := V_SUCCESS;
      ELSE
        ON_RESULT  := -20000;
        OS_ERR_MSG := OS_ERR_MSG || '订单评审校验不通过!';
        IF IN_DISCOUNT_SUM >= 0 THEN
          OS_ERR_MSG := OS_ERR_MSG || V_NL || '【原因：客户可用到款余额(' ||
                        IN_AMOUNT_SUM || ')小于待锁订金(' || VN_DOWN_PAY_AMOUNT ||
                        '（订金比例：' || IN_DOWN_PAY_SCALE || '%）)！';
        ELSE
          OS_ERR_MSG := OS_ERR_MSG || V_NL || '【原因：客户可用到款余额(' ||
                        IN_AMOUNT_SUM || ')+折让余额(' ||
                        (IN_DISCOUNT_SUM - 0.05) || ')小于待锁订金(' ||
                        VN_DOWN_PAY_AMOUNT || '（订金比例：' || IN_DOWN_PAY_SCALE ||
                        '%）)！';
        END IF;
      END IF;
      --仍按原来的逻辑，根据折让金额控制标识对折让金额进行校验
      /*IF IS_DISCOUNT_CTRL_FLAG = '0' AND
         (IN_Discount_AMOUNT > IN_DISCOUNT_SUM) THEN
        --若折扣金额大于（折让余额-锁定折让金额+冻结折让金额）
        ON_RESULT := -20000;
        IF OS_ERR_MSG IS NULL THEN
          OS_ERR_MSG := '订单评审校验不通过!';
        END IF;
        OS_ERR_MSG := OS_ERR_MSG || V_NL || '【原因：客户可用折让余额(' ||
                      IN_DISCOUNT_SUM || ')小于订单折让金额(' || IN_Discount_AMOUNT ||
                      '%)！';
      END IF;*/
      IF IS_DISCOUNT_CTRL_FLAG = '0' THEN
        VN_DOWN_PAY_AMOUNT := (IN_DOWN_PAY_SCALE * IN_Discount_AMOUNT) / 100;
        IF (VN_DOWN_PAY_AMOUNT > IN_DISCOUNT_SUM) THEN
          --若折扣金额大于（折让余额-锁定折让金额+冻结折让金额）
          ON_RESULT := -20000;
          IF OS_ERR_MSG IS NULL THEN
            OS_ERR_MSG := '订单评审校验不通过!';
          END IF;
          OS_ERR_MSG := OS_ERR_MSG || V_NL || '【原因：客户可用折让余额(' ||
                        IN_DISCOUNT_SUM || ')小于待锁折扣订金(' || VN_DOWN_PAY_AMOUNT ||
                        ')（订金比例：' || IN_DOWN_PAY_SCALE ||
                        '%）！';
        END IF;
      END IF;
    ELSIF IN_ACTION_TYPE = 2 THEN
      --送审锁款，且订金比例大于0，按比例计算要锁定的订金，判断锁定到款金额是否小于订金
      VN_DOWN_PAY_AMOUNT := (IN_DOWN_PAY_SCALE * IN_Settlement_AMOUNT) / 100;
      IF IN_LOCK_RECEIVED_AMOUNT >= VN_DOWN_PAY_AMOUNT THEN
        ON_RESULT  := V_SEC_RESULT;
        OS_ERR_MSG := V_SUCCESS;
      ELSE
        ON_RESULT  := -20000;
        OS_ERR_MSG := OS_ERR_MSG || '取消订单校验不通过!';
        OS_ERR_MSG := OS_ERR_MSG || V_NL || '【原因：客户款项锁定到款金额(' ||
                      IN_LOCK_RECEIVED_AMOUNT || ')小于释放订金(' ||
                      VN_DOWN_PAY_AMOUNT || '（订金比例：' || IN_DOWN_PAY_SCALE ||
                      '%）)！';
      END IF;
      --仍按原来的逻辑，根据折让金额控制标识对折让金额进行校验
      /*IF IS_DISCOUNT_CTRL_FLAG = '0' AND
         (IN_LOCK_DISCOUNT_AMOUNT < IN_DISCOUNT_AMOUNT) THEN
        --若锁定折扣金额小于折扣金额
        ON_RESULT := -20000;
        IF OS_ERR_MSG IS NULL THEN
          OS_ERR_MSG := '取消订单校验不通过!';
        END IF;
        OS_ERR_MSG := OS_ERR_MSG || V_NL || '【原因：客户订单锁定折扣金额(' ||
                      IN_LOCK_DISCOUNT_AMOUNT || ')小于待释放的订单折让金额(' ||
                      IN_Discount_AMOUNT || ')！';
      END IF;*/
      IF IS_DISCOUNT_CTRL_FLAG = '0' THEN
        VN_DOWN_PAY_AMOUNT := (IN_DOWN_PAY_SCALE * IN_DISCOUNT_AMOUNT) / 100;
        IF (IN_LOCK_DISCOUNT_AMOUNT < VN_DOWN_PAY_AMOUNT) THEN
          --若锁定折扣金额小于折扣金额
          ON_RESULT := -20000;
          IF OS_ERR_MSG IS NULL THEN
            OS_ERR_MSG := '取消订单校验不通过!';
          END IF;
          OS_ERR_MSG := OS_ERR_MSG || V_NL || '【原因：客户款项锁定折让金额(' ||
                        IN_LOCK_DISCOUNT_AMOUNT || ')小于待释放的折扣订金(' ||
                        VN_DOWN_PAY_AMOUNT || ')（订金比例：' || IN_DOWN_PAY_SCALE ||
                        '%）)！';
        END IF;
      END IF;
    ELSIF IN_ACTION_TYPE = 28 THEN
      --送审锁款，且订金比例大于0，按按比例计算要释放的订金
      --，将释放订金加上可用到款余额，判断是否小于锁定款项
      VN_DOWN_PAY_AMOUNT := (IN_DOWN_PAY_SCALE * IN_Settlement_AMOUNT) / 100;
      IF (VN_DOWN_PAY_AMOUNT + IN_AMOUNT_SUM + IN_CHK_DIS_AMOUNT) >=
         IN_Settlement_AMOUNT Or IN_DOWN_PAY_SCALE = 100 THEN
        ON_RESULT  := V_SEC_RESULT;
        OS_ERR_MSG := V_SUCCESS;
      ELSE
        ON_RESULT  := -20000;
        OS_ERR_MSG := OS_ERR_MSG || '生成发货通知单-解锁订金锁款-校验不通过!';
        IF IN_DISCOUNT_SUM >= 0 THEN
          /*OS_ERR_MSG := OS_ERR_MSG || V_NL || '【原因：客户可用到款余额+解锁订金(' ||
                        IN_AMOUNT_SUM || '+' || VN_DOWN_PAY_AMOUNT || '=' ||
                        (VN_DOWN_PAY_AMOUNT + IN_AMOUNT_SUM) || ')小于锁款金额(' ||
                        IN_Settlement_AMOUNT || '（订金比例：' ||
                        IN_DOWN_PAY_SCALE || '%）)！';*/
          OS_ERR_MSG := OS_ERR_MSG || V_NL || '校验公式：(' || IN_Settlement_AMOUNT || '-' || VN_DOWN_PAY_AMOUNT || ')>' || IN_AMOUNT_SUM;
          OS_ERR_MSG := OS_ERR_MSG || '即“【评审发货按100%比例锁定的总金额】-【按订金比例已锁定的订金】”不能大于【客户款项可用到款金额】';
          
          OS_ERR_MSG := OS_ERR_MSG || V_NL || '问题详解（若校验公式已理解且无疑惑请忽略方括号内容）：【目前订单的订金比例是' || IN_DOWN_PAY_SCALE || '%，送审时订单的锁定到款金额为' ||
                        IN_DOWN_PAY_AMOUNT || '（订金）'
                        || (CASE WHEN 0 < IN_DP_DIS_AMOUNT THEN '、锁定折扣金额为' || IN_DP_DIS_AMOUNT || '（折扣订金）' ELSE NULL END)
                        || '，不含本次所选择评审行的订金：' || VN_DOWN_PAY_AMOUNT
                        || '，剩余未评审的订金应该是：' || (IN_DOWN_PAY_AMOUNT - VN_DOWN_PAY_AMOUNT)
                        || '。此次评审发货，须按100%比例进行锁定的总金额：' || IN_Settlement_AMOUNT || '（即评审发货所选择订单行的总金额'
                        || (CASE WHEN 0 < IN_DISCOUNT_AMOUNT THEN '，不含折扣部分：' || IN_DISCOUNT_AMOUNT ELSE NULL END) || '）'
                        || '但此金额减去相应比例的订金：（' || IN_Settlement_AMOUNT || '-' || VN_DOWN_PAY_AMOUNT || '=' || (IN_Settlement_AMOUNT - VN_DOWN_PAY_AMOUNT)
                        || '），大于客户款项可用到款金额：' || IN_AMOUNT_SUM || '，不足以抵消此金额，不允许发货';
        ELSE
          /*OS_ERR_MSG := OS_ERR_MSG || V_NL || '【原因：客户可用到款余额+解锁订金+折让余额(' ||
                        IN_AMOUNT_SUM || '+' || VN_DOWN_PAY_AMOUNT || '+' ||
                        (IN_DISCOUNT_SUM - 0.05) || '=' ||
                        (VN_DOWN_PAY_AMOUNT + IN_AMOUNT_SUM +
                        IN_CHK_DIS_AMOUNT) || ')小于锁款金额(' ||
                        IN_Settlement_AMOUNT || ')（订金比例：' ||
                        IN_DOWN_PAY_SCALE || '%）)！';*/
          OS_ERR_MSG := OS_ERR_MSG || V_NL || '问题校验公式：(' || IN_Settlement_AMOUNT || '-' || VN_DOWN_PAY_AMOUNT
                                   || ')>(' || IN_AMOUNT_SUM || '+' || (IN_DISCOUNT_SUM-0.05) || ')';
          OS_ERR_MSG := OS_ERR_MSG || '即“【评审发货按100%比例锁定的总金额】-【按订金比例已锁定的订金】”不能大于“【客户款项可用到款金额】+【折扣余额】”';
          
          OS_ERR_MSG := OS_ERR_MSG || V_NL || '问题详解（若校验公式已理解且无疑惑请忽略方括号内容）：【目前订单的订金比例是' || IN_DOWN_PAY_SCALE || '%，送审时订单的锁定到款金额为' ||
                        IN_DOWN_PAY_AMOUNT || '（订金）'
                        || (CASE WHEN 0 < IN_DP_DIS_AMOUNT THEN '、锁定折扣金额为' || IN_DP_DIS_AMOUNT || '（折扣订金）' ELSE NULL END)
                        || '，不含本次所选择评审行的订金：' || VN_DOWN_PAY_AMOUNT
                        || '，剩余未评审的订金应该是：' || (IN_DOWN_PAY_AMOUNT - VN_DOWN_PAY_AMOUNT)
                        || '。此次评审发货，须按100%比例进行锁定的总金额：' || IN_Settlement_AMOUNT || '（即评审发货所选择订单行的总金额'
                        || (CASE WHEN 0 < IN_DISCOUNT_AMOUNT THEN '，不含折扣部分：' || IN_DISCOUNT_AMOUNT ELSE NULL END) || '）'
                        || '但此金额减去相应比例的订金：（' || IN_Settlement_AMOUNT || '-' || VN_DOWN_PAY_AMOUNT || '=' || (IN_Settlement_AMOUNT - VN_DOWN_PAY_AMOUNT)
                        || '），大于客户款项可用到款金额（' || IN_AMOUNT_SUM || '）+折扣余额（' || (IN_DISCOUNT_SUM-0.05) || '），不足以抵消此金额，不允许发货';
        END IF;
      END IF;
      --P_ACTION_TYPE = 28实际上是原来P_ACTION_TYPE = 1的逻辑
      --仍按原来的逻辑，根据折让金额控制标识对折让金额进行校验
      /*IF IS_DISCOUNT_CTRL_FLAG = '0' AND
         (IN_DISCOUNT_AMOUNT > IN_DISCOUNT_SUM) THEN
        --若折扣金额大于（折让余额-锁定折让金额+冻结折让金额）
        ON_RESULT := -20000;
        IF OS_ERR_MSG IS NULL THEN
          OS_ERR_MSG := '生成发货通知单-解锁订金锁款-校验不通过!';
        END IF;
        OS_ERR_MSG := OS_ERR_MSG || V_NL || '【原因：客户可用折让余额(' ||
                      IN_DISCOUNT_SUM || ')小于订单折让金额(' || IN_DISCOUNT_AMOUNT || ')！';
      END IF;*/
      IF IS_DISCOUNT_CTRL_FLAG = '0' THEN
        --送审锁款，且订金比例大于0，按按比例计算要释放的订金
        --，将释放订金加上可用到款余额，判断是否小于锁定款项
        VN_DOWN_PAY_AMOUNT := (IN_DOWN_PAY_SCALE * IN_DISCOUNT_AMOUNT) / 100;
        IF IN_DISCOUNT_AMOUNT > (VN_DOWN_PAY_AMOUNT + IN_DISCOUNT_SUM) THEN
          --若折扣金额大于（折让余额-锁定折让金额+冻结折让金额）
          ON_RESULT := -20000;
          IF OS_ERR_MSG IS NULL THEN
            OS_ERR_MSG := '生成发货通知单-解锁订金锁款-校验不通过!';
          END IF;
          /*OS_ERR_MSG := OS_ERR_MSG || V_NL || '【原因：客户可用折让余额+待解锁折扣订金(' ||
                        IN_DISCOUNT_SUM || '+' || VN_DOWN_PAY_AMOUNT || '=' ||
                        (VN_DOWN_PAY_AMOUNT + IN_DISCOUNT_SUM) || ')小于锁定折扣金额(' ||
                        IN_DISCOUNT_AMOUNT || '（订金比例：' ||
                        IN_DOWN_PAY_SCALE || '%）)！';*/
          OS_ERR_MSG := OS_ERR_MSG || V_NL || '校验公式：(' || IN_DISCOUNT_AMOUNT || '-' || VN_DOWN_PAY_AMOUNT || ')>' || IN_DISCOUNT_SUM;
          OS_ERR_MSG := OS_ERR_MSG || '即“【评审发货按100%比例锁定的总折扣金额】-【按订金比例已锁定的折扣订金】”不能大于【客户款项可用折扣金额】';
          
          OS_ERR_MSG := OS_ERR_MSG || V_NL || '问题详解（若校验公式已理解且无疑惑请忽略方括号内容）：【目前订单的订金比例是' || IN_DOWN_PAY_SCALE || '%，送审时订单的锁定折扣金额为' ||
                        IN_DP_DIS_AMOUNT || '（折扣订金）' || '，不含本次所选择评审行的折扣订金：' || VN_DOWN_PAY_AMOUNT
                        || '，剩余未评审的折扣订金应该是：' || (IN_DP_DIS_AMOUNT - VN_DOWN_PAY_AMOUNT)
                        || '。此次评审发货，须按100%比例进行锁定的总折扣金额：' || IN_DISCOUNT_AMOUNT
                        || '（即评审发货所选择订单行的总金额' || '，乘以相应的扣率（折扣/100））'
                        || '但此金额减去相应比例的折扣订金：（' || IN_DISCOUNT_AMOUNT || '-' || VN_DOWN_PAY_AMOUNT || '=' || (IN_DISCOUNT_AMOUNT - VN_DOWN_PAY_AMOUNT)
                        || '），大于客户款项可用折扣金额：' || IN_DISCOUNT_SUM || '，不足以抵消此金额，不允许发货';
        END IF;
      END IF;
    END IF;
  END PRC_DOWN_PAY_VERIFICATION;

  /**
  *
  */
  PROCEDURE PRC_CREDIT_LIMIT_HAVE_PARAM(IN_ENTITY_ID          IN NUMBER, --主体ID
                                        IN_CUSTOMER_ID        IN NUMBER, --客户ID
                                        IN_ACCOUNT_ID         IN NUMBER, --账户ID
                                        ON_DOWN_PAY_RATIO_E   OUT NUMBER,
                                        ON_ORDER_TOP_AMOUNT_E OUT NUMBER,
                                        ON_DOWN_PAY_RATIO     OUT NUMBER,
                                        ON_ORDER_TOP_AMOUNT   OUT NUMBER,
                                        OS_MESSAGE            OUT VARCHAR2) IS
    VN_CNT1 NUMBER;
    VN_CNT2 NUMBER;
  BEGIN
  
    SELECT COUNT(0)
      INTO VN_CNT1
      FROM T_BD_PARAM_LIST PL
     WHERE PL.PARAM_CODE = 'CREDIT_DOWN_PAY_SCALE'
       AND PL.ACTIVE_FLAG = 'Y';
  
    SELECT COUNT(0)
      INTO VN_CNT2
      FROM T_BD_PARAM_LIST PL
     WHERE PL.PARAM_CODE = 'CREDIT_ORDER_TOP_AMOUNT'
       AND PL.ACTIVE_FLAG = 'Y';
  
    IF 0 >= VN_CNT1 OR 0 >= VN_CNT2 THEN
      OS_MESSAGE := 'FAILURE';
      RETURN;
    END IF;
  
    IF 0 < VN_CNT1 THEN
      PKG_BD.P_GET_PARAMETER_VALUE(P_CONFIG_CODE => 'CREDIT_DOWN_PAY_SCALE',
                                   P_ENTITY_ID   => IN_ENTITY_ID,
                                   P_UNIT_ID     => '',
                                   P_CUSTOMER_ID => '',
                                   P_PARAM_VALUE => ON_DOWN_PAY_RATIO);
      ON_DOWN_PAY_RATIO_E := ON_DOWN_PAY_RATIO;
    END IF;
    IF ON_DOWN_PAY_RATIO IS NULL THEN
      WITH T AS
       (SELECT MAX(C.AMOUNT_SCALE) AS M_A
          FROM T_CREDIT_DOWN_PAY_ACCOUNT C
         WHERE C.ENTITY_ID = IN_ENTITY_ID
           AND (IN_CUSTOMER_ID IS NULL OR C.CUSTOMER_ID = IN_CUSTOMER_ID)
           AND (IN_ACCOUNT_ID IS NULL OR IN_ACCOUNT_ID = C.ACCOUNT_ID)
           AND SYSDATE >= C.BEGIN_DATE
           AND (C.END_DATE IS NULL AND C.END_DATE >= SYSDATE)
           AND C.AMOUNT_SCALE IS NOT NULL
        --AND 1 = ROWNUM
        UNION ALL
        SELECT MAX(C.AMOUNT_SCALE) AS M_A
          FROM T_CREDIT_DOWN_PAY_LEVEL C
         WHERE C.ENTITY_ID = IN_ENTITY_ID
           AND SYSDATE >= C.BEGIN_DATE
           AND (C.END_DATE IS NULL AND C.END_DATE >= SYSDATE)
           AND C.AMOUNT_SCALE IS NOT NULL
        --AND 1 = ROWNUM
        )
      SELECT MAX(M_A) INTO ON_DOWN_PAY_RATIO FROM T;
    /*SELECT COUNT(0)
        INTO ON_DOWN_PAY_RATIO
        FROM DUAL
       WHERE EXISTS (
              --
              SELECT MAX(C.AMOUNT_SCALE) AS M_A
                FROM T_CREDIT_DOWN_PAY_ACCOUNT C
               WHERE C.ENTITY_ID = IN_ENTITY_ID
                 AND (IN_CUSTOMER_ID IS NULL OR C.CUSTOMER_ID = IN_CUSTOMER_ID)
                 AND (IN_ACCOUNT_ID IS NULL OR IN_ACCOUNT_ID = C.ACCOUNT_ID)
                 AND SYSDATE >= C.BEGIN_DATE
                 AND (C.END_DATE IS NULL AND C.END_DATE >= SYSDATE)
                 AND C.AMOUNT_SCALE IS NOT NULL
                 AND 1 = ROWNUM) --
          OR EXISTS
       (
              --
              SELECT MAX(C.AMOUNT_SCALE) AS M_A
                FROM T_CREDIT_DOWN_PAY_LEVEL C
               WHERE C.ENTITY_ID = IN_ENTITY_ID
                 AND SYSDATE >= C.BEGIN_DATE
                 AND (C.END_DATE IS NULL AND C.END_DATE >= SYSDATE)
                 AND C.AMOUNT_SCALE IS NOT NULL
                 AND 1 = ROWNUM);
      IF 0 = ON_DOWN_PAY_RATIO THEN
        ON_DOWN_PAY_RATIO := NULL;
      END IF;*/
    END IF;
  
    IF 0 < VN_CNT2 THEN
      PKG_BD.P_GET_PARAMETER_VALUE(P_CONFIG_CODE => 'CREDIT_ORDER_TOP_AMOUNT',
                                   P_ENTITY_ID   => IN_ENTITY_ID,
                                   P_UNIT_ID     => '',
                                   P_CUSTOMER_ID => '',
                                   P_PARAM_VALUE => ON_ORDER_TOP_AMOUNT);
      ON_ORDER_TOP_AMOUNT_E := ON_ORDER_TOP_AMOUNT;
    END IF;
    IF ON_ORDER_TOP_AMOUNT IS NULL THEN
      WITH T AS
       (SELECT MAX(C.ORDER_TOP_AMOUNT) AS M_A
          FROM T_CREDIT_DOWN_PAY_ACCOUNT C
         WHERE C.ENTITY_ID = IN_ENTITY_ID
           AND (IN_CUSTOMER_ID IS NULL OR C.CUSTOMER_ID = IN_CUSTOMER_ID)
           AND (IN_ACCOUNT_ID IS NULL OR IN_ACCOUNT_ID = C.ACCOUNT_ID)
           AND SYSDATE >= C.BEGIN_DATE
           AND (C.END_DATE IS NULL AND C.END_DATE >= SYSDATE)
           AND C.ORDER_TOP_AMOUNT IS NOT NULL
        --AND 1 = ROWNUM
        UNION ALL
        SELECT MAX(C.ORDER_TOP_AMOUNT) AS M_A
          FROM T_CREDIT_DOWN_PAY_LEVEL C
         WHERE C.ENTITY_ID = IN_ENTITY_ID
           AND SYSDATE >= C.BEGIN_DATE
           AND (C.END_DATE IS NULL AND C.END_DATE >= SYSDATE)
           AND C.ORDER_TOP_AMOUNT IS NOT NULL
        --AND 1 = ROWNUM
        )
      SELECT MAX(M_A) INTO ON_ORDER_TOP_AMOUNT FROM T;
    /*SELECT COUNT(0)
        INTO ON_ORDER_TOP_AMOUNT
        FROM DUAL
       WHERE EXISTS
       (
              --
              SELECT MAX(C.ORDER_TOP_AMOUNT) AS M_A
                FROM T_CREDIT_DOWN_PAY_ACCOUNT C
               WHERE C.ENTITY_ID = IN_ENTITY_ID
                 AND (IN_CUSTOMER_ID IS NULL OR
                     C.CUSTOMER_ID = IN_CUSTOMER_ID)
                 AND (IN_ACCOUNT_ID IS NULL OR IN_ACCOUNT_ID = C.ACCOUNT_ID)
                 AND SYSDATE >= C.BEGIN_DATE
                 AND (C.END_DATE IS NULL AND C.END_DATE >= SYSDATE)
                 AND C.ORDER_TOP_AMOUNT IS NOT NULL
                 AND 1 = ROWNUM) --
          OR EXISTS
       (
              --
              SELECT MAX(C.ORDER_TOP_AMOUNT) AS M_A
                FROM T_CREDIT_DOWN_PAY_LEVEL C
               WHERE C.ENTITY_ID = IN_ENTITY_ID
                 AND SYSDATE >= C.BEGIN_DATE
                 AND (C.END_DATE IS NULL AND C.END_DATE >= SYSDATE)
                 AND C.ORDER_TOP_AMOUNT IS NOT NULL
                 AND 1 = ROWNUM) --
      ;
      IF 0 = ON_ORDER_TOP_AMOUNT THEN
        ON_ORDER_TOP_AMOUNT := NULL;
      END IF;*/
    END IF;
  
    IF ON_DOWN_PAY_RATIO IS NULL AND ON_ORDER_TOP_AMOUNT IS NULL THEN
      OS_MESSAGE := 'FAILURE';
    ELSE
      OS_MESSAGE := V_SUCCESS;
    END IF;
  
  END PRC_CREDIT_LIMIT_HAVE_PARAM;

  /**
  *客户账户额度重算(订单可提货金额上限、订金比例) 订单提货金额如何重算
  */
  PROCEDURE PRC_CREDIT_ACC_LIMIT_RERUN(IN_ENTITY_ID  IN NUMBER, --主体ID
                                       ID_NOW_STAMP  IN DATE,
                                       IN_UPDATED_BY IN VARCHAR2, --
                                       OS_MESSAGE    OUT VARCHAR2,
    IN_CUSTOMER_ID IN  NUMBER DEFAULT NULL,--客户ID，可以为空
    IN_ACCOUNT_ID  IN  NUMBER DEFAULT NULL--账户ID，可以为空
                                       ) IS
    VN_CNT              NUMBER;
    VN_ORDER_TOP_AMOUNT NUMBER;
    VN_CNT1             NUMBER;
  BEGIN
    PRC_CREDIT_LIMIT_HAVE_PARAM(IN_ENTITY_ID,
                                IN_CUSTOMER_ID,
                                IN_ACCOUNT_ID,
                                VN_CNT,
                                VN_ORDER_TOP_AMOUNT,
                                VN_CNT,
                                VN_CNT1,
                                OS_MESSAGE);
    IF OS_MESSAGE = V_SUCCESS AND VN_ORDER_TOP_AMOUNT IS NOT NULL THEN
      FOR A IN (SELECT AL.*
                  FROM T_CREDIT_ACCOUNT_LIMIT AL
                 WHERE AL.ENTITY_ID = IN_ENTITY_ID) LOOP
        PRC_UP_ORDER_USED_UNSO_AMOUNT(A.ENTITY_ID,
                                      A.CUSTOMER_ID,
                                      A.ACCOUNT_ID,
                                      A.ORDER_USED_AMOUNT,
                                      IN_UPDATED_BY,
                                      A.ORDER_USED_AMOUNT);
      END LOOP;
    END IF;
    IF OS_MESSAGE = V_SUCCESS AND VN_CNT IS NOT NULL THEN
      SELECT COUNT(0) INTO VN_CNT1 FROM UP_CODELIST C,UP_CODELIST_ENTITY CE
      WHERE CE.CODELIST_ID = C.ID
      AND CE.ENTITY_ID = IN_ENTITY_ID
      AND NVL(CE.ENABLED,'0')='0'
      AND C.CODETYPE = 'temp_all_free'--临时自由码表
      AND C.CODE_VALUE = '临时提货订单头订金重算开关'
      AND C.CODE_NAME = '临时提货订单头订金重算开关'
      AND C.ENTITY_FLAG = 'Y'
      AND C.ENABLED = '0';
      IF 0 < VN_CNT1 THEN
        FOR U IN (SELECT A.ORDER_HEAD_ID,
                         A.DOWN_PAY_AMOUNT,
                         NVL(SUM((A.DOWN_PAY_SCALE / 100) *
                                 ROUND(CASE
                                         --20200314 家用直发锁款调整
                                         WHEN NVL(B.IS_LOCK_AMOUNT, 'N') = 'Y' THEN
                                           0
                                         WHEN A.LOCK_AMOUNT_FLAG IN ('S','HQ') AND A.DOWN_PAY_SCALE > 0 THEN
                                         --add by lizhen 2015-11-30 T+3订单回写取消数量，并会释放款项，所以取消数量重算时不计入锁款
                                         --(NVL(B.Quantity,0)- nvl(B.AFFIRMED_QUANTITY,0) - Nvl(B.Cancel_Qty, 0))
                                         --MODI BY LIZHEN 2016-05-12 增加已引APS产能可视状态(2225)数据计算锁款
                                          (CASE
                                            WHEN NVL(B.IS_LOCK_AMOUNT, 'N') = 'NT' THEN
                                              NVL(B.CENTER_AFFIRM_QUANTITY, 0) - NVL(B.CANCEL_QTY, 0)
                                            WHEN A.ORDER_HEAD_STATE IN ('20', '2225', '1455') THEN
                                             NVL(B.QUANTITY, 0) - NVL(B.AFFIRMED_QUANTITY, 0) -
                                             NVL(B.CANCEL_QTY, 0)
                                            WHEN A.ORDER_HEAD_STATE IN ('381', '679') THEN
                                             NVL(B.CENTER_AFFIRM_QUANTITY, 0) - NVL(B.AFFIRMED_QUANTITY, 0) -
                                             NVL(B.CANCEL_QTY, 0)
                                            ELSE
                                             0
                                          END) * DECODE(B.PROJECT_ORDER_TYPE,
                                                        NULL,
                                                        NVL(B.LIST_PRICE, 0),
                                                        NVL(B.APPLY_LIST_PRICE, 0))
                                         --add by lizhen 2015-11-30 增加月返计算
                                          * (100 - DECODE(B.PROJECT_ORDER_TYPE,
                                                          NULL,
                                                          NVL(B.DISCOUNT_RATE, 0),
                                                          NVL(B.APPLY_DISCOUNT_RATE, 0)) -
                                          NVL(B.ORDERED_DISCOUNT_RATE, 0)) / 100
                                         WHEN A.LOCK_AMOUNT_FLAG IN ('S','HQ') AND A.DOWN_PAY_SCALE = 0 THEN
                                          0
                                         ELSE
                                          0
                                       END,
                                       2)),
                             0) AS AMOUNT
                    FROM CIMS.T_PLN_LG_ORDER_HEAD A
                   INNER JOIN CIMS.T_PLN_LG_ORDER_LINE B
                      ON (A.ORDER_HEAD_ID = B.ORDER_HEAD_ID)
                   WHERE A.DOWN_PAY_SCALE > 0
                     --AND A.DOWN_PAY_AMOUNT IS NULL
                     AND A.ENTITY_ID = IN_ENTITY_ID
                     AND (IN_CUSTOMER_ID IS NULL OR IN_CUSTOMER_ID = A.CUSTOMER_ID)
                     AND (IN_ACCOUNT_ID IS NULL OR IN_ACCOUNT_ID = A.ACCOUNT_ID)
                     AND 1 = FUN_JUDGE_OCCUPY_ORDER_LIMIT(IN_ENTITY_ID, A.ORDER_TYPE_CODE)
                   GROUP BY A.ORDER_HEAD_ID, A.DOWN_PAY_AMOUNT) LOOP
          UPDATE CIMS.T_PLN_LG_ORDER_HEAD T
             SET T.DOWN_PAY_AMOUNT = U.AMOUNT
           WHERE T.ORDER_HEAD_ID = U.ORDER_HEAD_ID AND U.AMOUNT <> NVL(T.DOWN_PAY_AMOUNT,0);
        END LOOP;
      END IF;
    END IF;
    FOR A IN (SELECT T.ENTITY_ID,
                     T.CUSTOMER_ID,
                     T.ACCOUNT_ID,
                     T.AMOUNT_SCALE,
                     T.ORDER_TOP_AMOUNT
                FROM T_CREDIT_DOWN_PAY_ACCOUNT T
               WHERE T.ENTITY_ID = NVL(IN_ENTITY_ID, T.ENTITY_ID)
                     AND (IN_CUSTOMER_ID IS NULL OR IN_CUSTOMER_ID = T.CUSTOMER_ID)
                     AND (IN_ACCOUNT_ID IS NULL OR IN_ACCOUNT_ID = T.ACCOUNT_ID)
                    --
                 AND ID_NOW_STAMP BETWEEN T.BEGIN_DATE AND
                     1 + TRUNC(ID_NOW_STAMP)
                         ) LOOP
      PKG_CREDIT_LIMIT.P_SET_ORDER_LIMIT_AMOUNT_ACC(IN_ENTITY_ID   => IN_ENTITY_ID,
                                                    IN_CUSTOMER_ID => A.CUSTOMER_ID,
                                                    IN_ACCOUNT_ID  => A.ACCOUNT_ID,
                                                    IN_UPDATED_BY  => IN_UPDATED_BY,
                                                    OS_MESSAGE     => OS_MESSAGE);
      IF OS_MESSAGE <> V_SUCCESS THEN
        RETURN;
      END IF;
    END LOOP;
    FOR A IN (SELECT T.ENTITY_ID, T.CUSTOM_CREDIT_LEVEL
                FROM T_CREDIT_DOWN_PAY_LEVEL T
               WHERE T.ENTITY_ID = NVL(IN_ENTITY_ID, T.ENTITY_ID)
                     --AND (IN_CUSTOMER_ID IS NULL OR IN_CUSTOMER_ID = T.CUSTOMER_ID)
                     --AND (IN_ACCOUNT_ID IS NULL OR IN_ACCOUNT_ID = T.ACCOUNT_ID)
                    --
                 AND ID_NOW_STAMP BETWEEN T.BEGIN_DATE AND
                     1 + TRUNC(ID_NOW_STAMP)
                 AND EXISTS
               (SELECT 1
                        FROM T_CREDIT_DOWN_PAY_LEVEL T1
                       WHERE T1.ENTITY_ID = T.ENTITY_ID
                         AND T1.CUSTOM_CREDIT_LEVEL = T.CUSTOM_CREDIT_LEVEL
                            --
                         AND T1.END_DATE < ID_NOW_STAMP)) LOOP
      PKG_CREDIT_LIMIT.P_SET_ORDER_LIMIT_AMOUNT_CUS(IN_ENTITY_ID    => IN_ENTITY_ID,
                                                    IN_CREDIT_LEVEL => A.CUSTOM_CREDIT_LEVEL,
                                                    IN_UPDATED_BY   => IN_UPDATED_BY,
                                                    OS_MESSAGE      => OS_MESSAGE);
      IF OS_MESSAGE <> V_SUCCESS THEN
        RETURN;
      END IF;
    END LOOP;
    OS_MESSAGE := V_SUCCESS;
  END PRC_CREDIT_ACC_LIMIT_RERUN;

  FUNCTION FUN_JUDGE_OCCUPY_ORDER_AMOUNT
  --确定提货订单是否需要占用提货额度
  (P_ORDER_ID   NUMBER, --提货订单ID 可以为空 P_ORDER_ID、P_ORDER_HEAD不可以都为空
   P_ORDER_HEAD T_PLN_LG_ORDER_HEAD%ROWTYPE DEFAULT NULL --提货订单ROW 可以为空 P_ORDER_ID、P_ORDER_HEAD不可以都为空
   ) RETURN NUMBER IS
    --返回1需要占用提货额度
    VR_ORDER_HEAD T_PLN_LG_ORDER_HEAD%ROWTYPE := P_ORDER_HEAD;
  BEGIN
    IF P_ORDER_ID IS NULL AND VR_ORDER_HEAD.ORDER_HEAD_ID IS NULL THEN
      --RETURN 0;
      RAISE V_BASE_EXCEPTION;
    END IF;
    IF VR_ORDER_HEAD.ORDER_HEAD_ID IS NULL THEN
      SELECT ENTITY_ID, ORDER_TYPE_CODE
        INTO VR_ORDER_HEAD.ENTITY_ID, VR_ORDER_HEAD.ORDER_TYPE_CODE
        FROM T_PLN_LG_ORDER_HEAD
       WHERE ORDER_HEAD_ID = P_ORDER_ID;
    END IF;
    RETURN FUN_JUDGE_OCCUPY_ORDER_LIMIT(VR_ORDER_HEAD.ENTITY_ID,
                                        VR_ORDER_HEAD.ORDER_TYPE_CODE);
  END FUN_JUDGE_OCCUPY_ORDER_AMOUNT;

  /*
  *确定相应主体的订单类型是否需要占用提货额度，需要返回1，否则返回0
  */
  FUNCTION FUN_JUDGE_OCCUPY_ORDER_LIMIT(IN_ENTITY_ID       NUMBER, --主体ID
                                        IS_ORDER_TYPE_CODE VARCHAR2 --订单类型编码
                                        ) RETURN NUMBER IS
    VN_CNT NUMBER;
  BEGIN
    SELECT COUNT(0)
      INTO VN_CNT
      FROM T_PLN_ORDER_TYPE T
     WHERE T.ENTITY_ID = IN_ENTITY_ID
       AND T.ORDER_TYPE_CODE = IS_ORDER_TYPE_CODE
       AND T.SOURCE_ORDER_TYPE_ID = 1 --提货订单
          --提货类型（01:销售提货、02:物料领用、03:资源领用）快码：plnOrderLgType
       AND NOT EXISTS
     (
            --中心备货提货订单
            SELECT UCL.CODE_NAME
              FROM UP_CODELIST UCL, UP_CODELIST_ENTITY UCLE
             WHERE UCL.CODETYPE = 'PLG_LGORDER_CENTER_TRANSFER'
               AND UCL.ID = UCLE.CODELIST_ID
               AND UCL.ENABLED = 0
               AND UCL.CODE_VALUE = TO_CHAR(T.ORDER_TYPE_ID)
               AND UCLE.ENTITY_ID = T.ENTITY_ID
            --
            )
       AND ('PRO_ORDER' <> UPPER(NVL(T.IS_BUSINESS_CONTROL, '_')) OR
           ('PRO_ORDER' = UPPER(NVL(T.IS_BUSINESS_CONTROL, '_')) AND
           '01' = NVL(T.ORDER_LG_TYPE, '01')))
    --
    ;
    /*IF 1 < VN_CNT THEN
      RAISE V_BASE_EXCEPTION;
    END IF;*/
    IF 0 < VN_CNT THEN
      RETURN 1;
    END IF;
    RETURN 0;
  END FUN_JUDGE_OCCUPY_ORDER_LIMIT;

  /**
  *客户信用等级、账户修改时更新客户账户额度（或插入）
  */
  PROCEDURE PRC_CREDIT_ACC_LIMIT_UPDATE(IN_ENTITY_ID   NUMBER, --主体ID
                                        IN_CUSTOMER_ID NUMBER, --客户ID
                                        IN_ACCOUNT_ID  NUMBER, --账户ID
                                        IN_UPDATED_BY  VARCHAR2, --修改人
                                        OS_MESSAGE     OUT VARCHAR2, --客户ID
                                        IN_ONLY_UPDATE IN  NUMBER DEFAULT NULL) IS
    VN_ORDER_TOP_AMOUNT NUMBER;
    VN_DOWN_PAY_RATIO   NUMBER;
  BEGIN
    IF IN_ONLY_UPDATE IS NULL OR 1 <> IN_ONLY_UPDATE THEN
      PRC_CREDIT_LIMIT_HAVE_PARAM(IN_ENTITY_ID,IN_CUSTOMER_ID,IN_ACCOUNT_ID
      ,VN_DOWN_PAY_RATIO,VN_ORDER_TOP_AMOUNT,VN_DOWN_PAY_RATIO,VN_ORDER_TOP_AMOUNT,OS_MESSAGE);
      IF OS_MESSAGE <> V_SUCCESS THEN
        OS_MESSAGE := V_SUCCESS;
        RETURN;
      END IF;
    END IF;
  
    IF IN_ACCOUNT_ID IS NOT NULL THEN
      PKG_CREDIT_LIMIT.P_SET_ORDER_LIMIT_AMOUNT_ACC(IN_ENTITY_ID   => IN_ENTITY_ID,
                                                    IN_CUSTOMER_ID => IN_CUSTOMER_ID,
                                                    IN_ACCOUNT_ID  => IN_ACCOUNT_ID,
                                                    IN_UPDATED_BY  => IN_UPDATED_BY,
                                                    OS_MESSAGE     => OS_MESSAGE);
      IF OS_MESSAGE <> V_SUCCESS THEN
        RETURN;
      END IF;
      MERGE INTO T_CREDIT_ACCOUNT_LIMIT UT
      USING (SELECT CO.SALES_CENTER_ID,
                    CO.SALES_CENTER_CODE,
                    CO.SALES_CENTER_NAME
               FROM T_CUSTOMER_ACCOUNT          CA,
                    T_CUSTOMER_ACC_ORG_RELATION AR,
                    T_CUSTOMER_ORG              CO
              WHERE CA.ACCOUNT_ID = AR.ACCOUNT_ID
                AND AR.CUSTOMER_ORG_ID = CO.CUSTOMER_ORG_ID
                AND CA.ACCOUNT_ID = IN_ACCOUNT_ID
                AND CA.ENTITY_ID = IN_ENTITY_ID
                AND CA.CUSTOMER_ID = IN_CUSTOMER_ID) MT
      ON (UT.ENTITY_ID = IN_ENTITY_ID AND UT.CUSTOMER_ID = IN_CUSTOMER_ID AND UT.ACCOUNT_ID = IN_ACCOUNT_ID)
      WHEN MATCHED THEN
        UPDATE
           SET UT.SALES_CENTER_ID   = MT.SALES_CENTER_ID,
               UT.SALES_CENTER_CODE = MT.SALES_CENTER_CODE,
               UT.SALES_CENTER_NAME = MT.SALES_CENTER_NAME;
      IF VN_ORDER_TOP_AMOUNT IS NOT NULL THEN
        PRC_UP_ORDER_USED_UNSO_AMOUNT(IN_ENTITY_ID
        ,IN_CUSTOMER_ID,IN_ACCOUNT_ID,NULL,IN_UPDATED_BY,VN_ORDER_TOP_AMOUNT);
      END IF;
    
    ELSE
      FOR A IN (SELECT CA.ACCOUNT_ID
                  FROM T_CUSTOMER_ACCOUNT CA
                 WHERE CA.ENTITY_ID = IN_ENTITY_ID
                   AND CA.CUSTOMER_ID = IN_CUSTOMER_ID) LOOP
        PKG_CREDIT_LIMIT.P_SET_ORDER_LIMIT_AMOUNT_ACC(IN_ENTITY_ID   => IN_ENTITY_ID,
                                                      IN_CUSTOMER_ID => IN_CUSTOMER_ID,
                                                      IN_ACCOUNT_ID  => A.ACCOUNT_ID,
                                                      IN_UPDATED_BY  => IN_UPDATED_BY,
                                                      OS_MESSAGE     => OS_MESSAGE);
        IF OS_MESSAGE <> V_SUCCESS THEN
          RETURN;
        END IF;
        IF VN_ORDER_TOP_AMOUNT IS NOT NULL THEN
          PRC_UP_ORDER_USED_UNSO_AMOUNT(IN_ENTITY_ID
          ,IN_CUSTOMER_ID,A.ACCOUNT_ID,NULL,IN_UPDATED_BY,VN_DOWN_PAY_RATIO);
        END IF;
      END LOOP;
    END IF;
    OS_MESSAGE := V_SUCCESS;
  END PRC_CREDIT_ACC_LIMIT_UPDATE;

  PROCEDURE PRC_UP_ORDER_USED_UNSO_AMOUNT
  --获取并更新账户的订单已使用提货额度（未生成销售单），如果有变化，记录历史
  (IN_ENTITY_ID        IN NUMBER, --主体ID
   IN_CUSTOMER_ID      IN NUMBER, --客户ID
   IN_ACCOUNT_ID       IN NUMBER, --账户ID
   IN_USED_UNSO_AMOUNT IN NUMBER, --更新前的订单已使用提货额度，可以为空
   IN_UPDATED_BY       IN VARCHAR2, --修改人
   ON_USED_UNSO_AMOUNT OUT NUMBER --更新后的订单已使用提货额度
   ) IS
    VT_USED_UNSO_AMOUNT     T_CREDIT_ACCOUNT_LIMIT.ORDER_USED_AMOUNT%TYPE;
    VR_CREDIT_ACCOUNT_LIMIT T_CREDIT_ACCOUNT_LIMIT%ROWTYPE;
  BEGIN
    BEGIN
      SELECT *
        INTO VR_CREDIT_ACCOUNT_LIMIT
        FROM T_CREDIT_ACCOUNT_LIMIT T
       WHERE T.ENTITY_ID = IN_ENTITY_ID
         AND T.CUSTOMER_ID = IN_CUSTOMER_ID
         AND T.ACCOUNT_ID = IN_ACCOUNT_ID;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.put_line(IN_ENTITY_ID);
        DBMS_OUTPUT.put_line(IN_CUSTOMER_ID);
        DBMS_OUTPUT.put_line(IN_ACCOUNT_ID);
        RETURN;
    END;
    SELECT FUN_GET_ORDER_S_UNSHIP_AMOUNT(IN_ENTITY_ID,
                                         IN_CUSTOMER_ID,
                                         IN_ACCOUNT_ID) +
           FUN_GET_ORDER_SHIP_UNSO_AMOUNT(IN_ENTITY_ID,
                                          IN_CUSTOMER_ID,
                                          IN_ACCOUNT_ID)
      INTO VT_USED_UNSO_AMOUNT
      FROM DUAL;
  
    UPDATE T_CREDIT_ACCOUNT_LIMIT
       SET ORDER_USED_AMOUNT = VT_USED_UNSO_AMOUNT,
           LAST_UPDATED_BY   = IN_UPDATED_BY,
           LAST_UPDATE_DATE  = SYSDATE
     WHERE ACCOUNT_LIMIT_ID = VR_CREDIT_ACCOUNT_LIMIT.ACCOUNT_LIMIT_ID
       AND NVL(IN_USED_UNSO_AMOUNT, ORDER_USED_AMOUNT) <>
           VT_USED_UNSO_AMOUNT;
    IF 1 = SQL%ROWCOUNT THEN
      ON_USED_UNSO_AMOUNT := VT_USED_UNSO_AMOUNT;
    
      INSERT INTO T_CREDIT_ACCOUNT_LIMIT_HIS
        (ACCOUNT_LIMIT_HIS_ID, --账户额度历史id
         CUSTOMER_ID, --客户id
         CUSTOMER_CODE, --客户编码
         CUSTOMER_NAME, --客户名称
         SALES_CENTER_ID, --营销中心id
         SALES_CENTER_CODE, --营销中心编码
         SALES_CENTER_NAME, --营销中心名称
         ACCOUNT_ID, --账户id
         ACCOUNT_CODE, --账户编码
         DOWN_PAY_RATE, --订金比例
         ORDER_LIMIT_AMOUNT, --订单提货额度上限
         ORDER_USED_AMOUNT, --已使用订单金额
         ENTITY_ID, --经营主体id
         SOURCE_TYPE, --来源类型
         SOURCE_BILL_ID, --来源单据id
         SOURCE_BILL_NUM, --来源单据号
         OPERATE_DESC, --操作描述
         CREATED_BY, --创建人
         CREATION_DATE, --创建日期
         LAST_UPDATED_BY, --最后更新人
         LAST_UPDATE_DATE --最后更新日期
         )
        SELECT S_CREDIT_ACCOUNT_LIMIT_HIS.NEXTVAL,
               VR_CREDIT_ACCOUNT_LIMIT.CUSTOMER_ID,
               VR_CREDIT_ACCOUNT_LIMIT.CUSTOMER_CODE,
               VR_CREDIT_ACCOUNT_LIMIT.CUSTOMER_NAME,
               VR_CREDIT_ACCOUNT_LIMIT.SALES_CENTER_ID,
               VR_CREDIT_ACCOUNT_LIMIT.SALES_CENTER_CODE,
               VR_CREDIT_ACCOUNT_LIMIT.SALES_CENTER_NAME,
               VR_CREDIT_ACCOUNT_LIMIT.ACCOUNT_ID,
               VR_CREDIT_ACCOUNT_LIMIT.ACCOUNT_CODE,
               VR_CREDIT_ACCOUNT_LIMIT.DOWN_PAY_RATE,
               VR_CREDIT_ACCOUNT_LIMIT.ORDER_LIMIT_AMOUNT,
               VT_USED_UNSO_AMOUNT, --已使用订单金额
               VR_CREDIT_ACCOUNT_LIMIT.ENTITY_ID,
               NULL, --来源类型
               NULL, --来源单据ID
               NULL, --来源单据号
               '订单已提货金额更新',
               NVL(VR_CREDIT_ACCOUNT_LIMIT.LAST_UPDATED_BY,
                   VR_CREDIT_ACCOUNT_LIMIT.CREATED_BY),
               NVL(VR_CREDIT_ACCOUNT_LIMIT.LAST_UPDATE_DATE,
                   VR_CREDIT_ACCOUNT_LIMIT.CREATION_DATE),
               IN_UPDATED_BY,
               SYSDATE
          FROM DUAL;
    END IF;
  END PRC_UP_ORDER_USED_UNSO_AMOUNT;

  FUNCTION FUN_GET_ORDER_S_UNSHIP_AMOUNT
  --获取账户的订单已使用提货额度（已送审未评审）
  (IN_ENTITY_ID   NUMBER, --主体ID
   IN_CUSTOMER_ID NUMBER, --客户ID
   IN_ACCOUNT_ID  NUMBER --账户ID
   ) RETURN NUMBER IS
    VN_UNSHIP_AMOUNT NUMBER; --非已中心评审、部分评审、已送审未发货的金额
  BEGIN
    SELECT SUM( --ROUND(
               (CASE
                 WHEN H.ORDER_HEAD_STATE IN ('679', '381') THEN --679 --已中心评审381 --部分评审
                  (NVL(L.CENTER_AFFIRM_QUANTITY, 0) --中心评审数量
                  - NVL(L.AFFIRMED_QUANTITY, 0) --已评审数量
                  - NVL(L.CANCEL_QTY, 0) --
                  )
                 WHEN H.ORDER_HEAD_STATE IS NOT NULL THEN --为空调拨申请
                  (NVL(L.QUANTITY, 0) --申请数量
                  - NVL(L.AFFIRMED_QUANTITY, 0) --已评审数量
                  - NVL(L.CANCEL_QTY, 0) --
                  )
                 ELSE
                  0
               END) * DECODE(L.PROJECT_ORDER_TYPE,
                             NULL,
                             NVL(L.LIST_PRICE, 0),
                             NVL(L.APPLY_LIST_PRICE, 0)) *
               (100 - DECODE(L.PROJECT_ORDER_TYPE,
                             NULL,
                             NVL(L.DISCOUNT_Rate, 0),
                             --月返计算
                             NVL(L.APPLY_DISCOUNT_RATE, 0)) -
               NVL(L.ORDERED_DISCOUNT_RATE, 0)) / 100
               --
               --,2)--
               )
      INTO VN_UNSHIP_AMOUNT
      FROM T_PLN_LG_ORDER_LINE L
     INNER JOIN T_PLN_LG_ORDER_HEAD H
        ON (H.ORDER_HEAD_ID = L.ORDER_HEAD_ID)
     WHERE H.ENTITY_ID = IN_ENTITY_ID
       AND H.CUSTOMER_ID = IN_CUSTOMER_ID
       AND H.ACCOUNT_ID = IN_ACCOUNT_ID
       AND H.ORDER_HEAD_STATE NOT IN ('304', '19', '415', '23') ----304关闭 19制单 20已送审 415已驳回 23评审完毕
          --H.ORDER_HEAD_STATE IN ('20', '381', '679', '1455', '2225')--23 评审完毕
       AND (L.ORDER_LINE_STATE IS NULL OR L.ORDER_LINE_STATE <> 'CLOSED')
       AND 1 = FUN_JUDGE_OCCUPY_ORDER_LIMIT(H.ENTITY_ID, H.ORDER_TYPE_CODE);
    RETURN NVL(VN_UNSHIP_AMOUNT, 0);
  END FUN_GET_ORDER_S_UNSHIP_AMOUNT;

  FUNCTION FUN_GET_ORDER_SHIP_UNSO_AMOUNT
  --获取账户的订单已使用提货额度（已评审（发货）、未生成销售单）
  (IN_ENTITY_ID   NUMBER, --主体ID
   IN_CUSTOMER_ID NUMBER, --客户ID
   IN_ACCOUNT_ID  NUMBER --账户ID
   ) RETURN NUMBER IS
    VN_PLAN_AMOUNT NUMBER; --
    VN_SHIP_AMOUNT NUMBER; --
  BEGIN
    SELECT SUM( --ROUND(
               --订单提货额度锁定不判断锁款方式
               (SP.UNAFFIRM_QTY * SP.ITEM_PRICE *
               (100 - NVL(SP.DISCOUNT_RATE, 0) -
               NVL(SP.MONTH_DISCOUNT_RATE, 0)) / 100)
               --
               --,2)--
               )
      INTO VN_PLAN_AMOUNT
      FROM T_PLN_LG_ORDER_HEAD OH
     INNER JOIN T_LG_SHIP_PLAN SP
        ON (((SP.ORIGIN_ORIGIN_TYPE = '02' --来源类型(01：计划订单 02：提货订单 03 ：调拨订单 04：促销品 05：备货订单)
           AND OH.ORDER_HEAD_ID = SP.ORIGIN_ORIGIN_HEAD_ID AND
           OH.ORDER_NUMBER = SP.ORIGIN_ORIGIN_ORDER_CODE) OR
           (SP.ORIGIN_ORIGIN_TYPE IS NULL AND SP.ORIGIN_TYPE = '02' --来源类型(01：计划订单 02：提货订单 03 ：调拨订单 04：促销品 05：备货订单)
           AND OH.ORDER_HEAD_ID = SP.ORIGIN_ORDER_ID AND
           OH.ORDER_NUMBER = SP.ORIGIN_ORDER_NUM)) AND
           OH.ENTITY_ID = SP.ENTITY_ID)
     WHERE OH.ENTITY_ID = IN_ENTITY_ID
       AND OH.CUSTOMER_ID = IN_CUSTOMER_ID
       AND OH.ACCOUNT_ID = IN_ACCOUNT_ID
       AND SP.STATUS <> '03' --撤销单据没有锁款
       AND SP.STATUS <> '02' --已确认，确认则生成发货通知单。部分确认的话，则拆单，生成两个发运计划
       AND 1 =
           FUN_JUDGE_OCCUPY_ORDER_LIMIT(OH.ENTITY_ID, OH.ORDER_TYPE_CODE)
       AND SP.UNAFFIRM_QTY <> 0
       AND SP.ITEM_PRICE <> 0
       AND 100 >
           (NVL(SP.DISCOUNT_RATE, 0) + NVL(SP.MONTH_DISCOUNT_RATE, 0));
    SELECT SUM( --ROUND(
               --订单提货额度锁定不判断锁款方式
               ((DL.ITEM_QTY - NVL(DL.FACT_SHIP_QTY, 0) -
               NVL(DL.CANCEL_QTY, 0)) * DL.ITEM_PRICE *
               (100 - NVL(DL.DISCOUNT_RATE, 0) -
               NVL(DL.MONTH_DISCOUNT_RATE, 0)) / 100)
               --
               --,2)--
               )
      INTO VN_SHIP_AMOUNT
      FROM T_PLN_LG_ORDER_HEAD OH
     INNER JOIN T_LG_SHIP_DOC_LINE DL
        ON ((DL.ORIGIN_ORIGIN_TYPE = '02' --来源类型(01：计划订单 02：提货订单 03 ：调拨订单 04：促销品 05：备货订单)
           AND OH.ORDER_HEAD_ID = DL.ORIGIN_ORIGIN_HEAD_ID AND
           OH.ORDER_NUMBER = DL.ORIGIN_ORIGIN_DOC_CODE) OR
           (DL.ORIGIN_ORIGIN_TYPE IS NULL AND DL.ORIGIN_TYPE = '02' --来源类型(01：计划订单 02：提货订单 03 ：调拨订单 04：促销品 05：备货订单)
           AND OH.ORDER_HEAD_ID = DL.ORIGIN_ORDER_ID AND
           OH.ORDER_NUMBER = DL.ORIGIN_ORDER_NUM))
     INNER JOIN T_LG_SHIP_DOC SD
        ON (DL.SHIP_DOC_ID = SD.SHIP_DOC_ID AND OH.ENTITY_ID = SD.ENTITY_ID)
     WHERE OH.ENTITY_ID = IN_ENTITY_ID
       AND OH.CUSTOMER_ID = IN_CUSTOMER_ID
       AND OH.ACCOUNT_ID = IN_ACCOUNT_ID
       AND SD.DOC_STATUS <> '01' --单据状态 00正常 01红冲
       AND 1 =
           FUN_JUDGE_OCCUPY_ORDER_LIMIT(OH.ENTITY_ID, OH.ORDER_TYPE_CODE)
       AND DL.ITEM_QTY > (NVL(DL.FACT_SHIP_QTY, 0) - NVL(DL.CANCEL_QTY, 0))
       AND DL.ITEM_PRICE <> 0
       AND 100 >
           (NVL(DL.DISCOUNT_RATE, 0) + NVL(DL.MONTH_DISCOUNT_RATE, 0));
  
    RETURN NVL(VN_PLAN_AMOUNT, 0) + NVL(VN_SHIP_AMOUNT, 0);
  END FUN_GET_ORDER_SHIP_UNSO_AMOUNT;

end PKG_CREDIT_DOWN_PAY;
/

