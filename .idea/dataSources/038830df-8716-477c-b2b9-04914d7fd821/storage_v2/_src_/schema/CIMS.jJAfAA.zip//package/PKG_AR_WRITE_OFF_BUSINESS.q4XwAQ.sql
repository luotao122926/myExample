create PACKAGE      PKG_AR_WRITE_OFF_BUSINESS AS


  --------------------------------------------------------------------------
  --Author: guibr
  --Created: 2018-12-11 
  --业务核销  倒推业务账龄
  --------------------------------------------------------------------------
  Procedure P_AR_WRITE_OFF_BUSINESS_MAIN(
                                 IN_ENTITY_ID IN  NUMBER,  --主体 
                                   P_MATCH_DATE IN VARCHAR2, 
                                 P_RESULT  OUT VARCHAR2,-- 失败时返回异常消息
                                 P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，失败返回“ERROR”
      ); --返回值   
      
      
    --------------------------------------------------------------------------
  --Author: guibr
  --Created: 2018-12-11
  --业务核销  插入账龄明细
  --------------------------------------------------------------------------
  Procedure P_AR_WRITE_OFF_BUSINESS_DETAIL(
                                 IN_ENTITY_ID IN  NUMBER,  --主体 
                                 P_CUSTOMER_ID IN  NUMBER,  --客户ID
                                 P_ACCOUNT_ID IN  NUMBER,  --账户ID
                                   P_MATCH_DATE IN VARCHAR2, 
                                 P_RANGE_DATE  IN DATE,  
                                 P_AGE_MOUNT IN  NUMBER,
                                 P_AR_SALE_MAIN_TYPE  IN  PKG_AR_WRITE_OFF.AR_SALE_MAIN_TYPE,
                                 P_RESULT  OUT VARCHAR2,-- 失败时返回异常消息
                                 P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，失败返回“ERROR”
      );
      
      
      --冻结账龄日报表
  PROCEDURE P_AR_AGE_DISCOUNT_FREEZE
  (
      IN_ENTITY_ID IN  NUMBER,  --主体 
      P_MATCH_DATE IN VARCHAR2, --核销日期。默认取TRUNC(SYSDATE - 1,'DD')
      P_RESULT  OUT VARCHAR2,
      P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  );  
            
       

END PKG_AR_WRITE_OFF_BUSINESS;
/

