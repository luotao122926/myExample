create PACKAGE      PKG_POL_POLICY IS

  -----------------------------------------------------------------------------
  -- 确认政策                                                            --
  -----------------------------------------------------------------------------
  PROCEDURE P_AFFIRM_POLICY(P_POLICY_ID    IN NUMBER   --政策ID
                           ,P_USER_ID      IN NUMBER   --用户ID
                           ,P_MESSAGE      OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
                           ,P_ORDER_NUMBER OUT VARCHAR2);

  --------------------------------------------------------------------------
  -- 生成Y单头表
  ---------------------------------------------------------------------------
  PROCEDURE P_CREATE_ORDER_HEADERS(P_POLICY_ID    IN NUMBER     ---政策ID
                                  ,P_USER_ID      IN NUMBER     ---用户ID
                                  ,P_ENTITY_ID    IN NUMBER     --主体ID
                                  ,P_MESSAGE      OUT VARCHAR2  ---成功则返回“OK”，否则返回出错信息
                                  ,P_ORDER_NUMBER OUT VARCHAR2);


  PROCEDURE P_POLICY_Y_TO_F(P_POLICY_CHK_ID          IN NUMBER, --政策审批ID
                            p_policy_id              IN NUMBER, ---政策ID
                            p_y_line_id              IN NUMBER, --Y单行ID
                            P_ENTITY_ID              IN NUMBER, --主体ID
                            p_User_Id                IN VARCHAR2, --用户ID
                            p_Message                IN OUT VARCHAR2 --返回结果：成功返回"SUCCESS"，失败返回原因
                            );


  -----------------------------------------------------------------------------
  -- 释放预算(关闭Y单)&占用预算(取消关闭Y单)                            --
  -----------------------------------------------------------------------------
  PROCEDURE P_CLOSE_BUDGET(P_POLICY_ORDER_ID        IN NUMBER   --政策ID
                          ,P_USER_ID                IN NUMBER   --用户ID
                          ,P_ISCLOSE                IN VARCHAR2 --是否关闭
                          ,P_MESSAGE               OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
                          );

  --计算返利报表
  PROCEDURE P_AUTO_CAL_DISCOUNT_REPORT(p_message out varchar2);


  --检查预算节点是否存在
  PROCEDURE P_CHECK_BUDGET_NODE( P_DATA_FLOW_ID  IN NUMBER
                                ,P_ENTITY_ID     IN NUMBER
                                ,P_BUDGET_SEGMENT_1_ID IN NUMBER
                                ,P_BUDGET_SEGMENT_2_ID IN NUMBER
                                ,P_BUDGET_SEGMENT_3_ID IN NUMBER
                                ,P_BUDGET_SEGMENT_4_ID IN NUMBER
                                ,P_BUDGET_SEGMENT_5_ID IN NUMBER
                                ,P_BUDGET_SEGMENT_6_ID IN NUMBER
                                ,P_MESSAGE  OUT VARCHAR2);


  --更新F单行上的产品信息
  PROCEDURE P_UPDATE_DIS_LINE_FOR_ITEM( P_LINE_ID  IN NUMBER
                                       ,P_ITEM_ID  IN NUMBER
                                       ,P_ITEM_CODE IN VARCHAR2
                                       ,P_ITEM_NAME IN VARCHAR2
                                       ,P_LAST_UPDATE_BY IN VARCHAR2
                                       ,P_LAST_UPDATE_DATE IN DATE
                                       ,P_MESSAGE  OUT VARCHAR2);


  --梁颜明，20161226增加的存储过程：作废或关闭政策
  PROCEDURE P_DISCARD_POLICY( IN_POLICY_ID  IN NUMBER
                              ,IS_DISCARD_BY IN VARCHAR2
                              ,IS_ACTION      IN  VARCHAR2    --R驳回（旧的工作流回调）、D作废、C关闭政策使用
                              ,OS_MESSAGE  OUT VARCHAR2);


  --政策提交时的占用预算
  PROCEDURE P_OCCUPY_BUDGET( P_POLICY_ID  IN NUMBER
                            ,P_DIRECTION  IN VARCHAR2
                            ,P_FLAG       IN VARCHAR2
                            ,P_MESSAGE  OUT VARCHAR2);



  --政策提交时检查预算
  PROCEDURE P_CHECK_BUDGET( P_POLICY_ID  IN NUMBER
                            ,P_MESSAGE  OUT VARCHAR2);


  --Y转F工作流结束生成F单
  PROCEDURE P_CREATE_DISCOUNT_ORDER( P_POLICY_ORDER_ID  IN NUMBER
                                     ,P_APP_CODE        IN VARCHAR2
                                     ,P_MESSAGE  OUT VARCHAR2);

  --获取返利单备注相关信息
  PROCEDURE P_GET_CONTACT_REMARK( P_POLICY_ORDER_ID  IN NUMBER,
                                  P_POLICY_NAME  OUT VARCHAR2,
                                  P_POLICY_MAIN_TYPE OUT VARCHAR2,
                                  P_POLICY_NUMBER  OUT VARCHAR2);

  --销售折让获取备注
  FUNCTION F_GET_REMARK(P_DIS_ORDER_ID    IN NUMBER  --返利兑现ID
                         ) RETURN VARCHAR2;

  --根据工程机登录号查询可用资源
  PROCEDURE P_QUERY_RESOURCE(P_PROJECT_CODE IN VARCHAR2,
                             P_DISCOUNT_METHOD IN VARCHAR2,
                             P_AMOUNT OUT NUMBER,
                             P_MESSAGE OUT VARCHAR2);

  --财务接口生成Y单、F单信息
  PROCEDURE P_FINANCE_INTERFACE(P_INTF_ID IN NUMBER,
                                P_ENTITY_ID IN NUMBER,
                                P_ORDER_NUMBER OUT VARCHAR2,
                                P_DISCOUNT_NUMBER OUT VARCHAR2,
                                P_MESSAGE OUT VARCHAR2);

  --查询政策申请金额
  PROCEDURE P_QUERY_POLICY_AMOUNT(P_POLICY_ID IN NUMBER,
                                  P_AMOUNT OUT NUMBER,
                                  P_MESSAGE OUT VARCHAR2);

  --返利单作废
  PROCEDURE P_CANCEL_DISCOUNT(P_DISCOUNT_NUMBER IN VARCHAR2,
                              P_USER_ACCOUNT IN VARCHAR2,
                              P_ENTITY_ID IN NUMBER,
                              P_MESSAGE OUT VARCHAR2);

  --查询行金额
  PROCEDURE P_GET_LINE_AMOUNT(P_DISCOUNT_LINE_ID IN NUMBER,
                              P_AMOUNT OUT VARCHAR2);

  --Y单数据  数据割接
/*  PROCEDURE P_DATA_CUTOVER(P_DATA_FLOW_ID    IN NUMBER
                          ,P_ENTITY_ID       IN NUMBER
                          ,P_MESSAGE OUT VARCHAR2);    */
  
  --更新Y单4项未返利金额
  PROCEDURE P_UPDATE_Y_UNUSED_AMOUNT(S_CUR_DIS_PERIOD  IN VARCHAR2
                                    ,R_DISCOUNT_PERIOD IN VARCHAR2
                                    ,R_POLICY_ORDER_ID IN NUMBER
                                    ,AMOUNT IN NUMBER);
  
  --从模板政策引入客户分类、商品分类
  PROCEDURE P_IMPORT_CUS_MTL_TYPE(IN_SRC_POLICY_ID  IN NUMBER
                                 ,IN_TRGT_POLICY_ID IN NUMBER
                                 ,IS_USER_ID        IN VARCHAR2
                                 ,OS_MESSAGE        OUT VARCHAR2);
                                 
  --根据EMS接口表数据生成返利单
  PROCEDURE P_EMS_INTF_TO_DISCOUNT_ORDER(IS_ORDER_DATE IN VARCHAR2
                                        ,OS_MESSAGE    OUT VARCHAR2);

END PKG_POL_POLICY;
/

