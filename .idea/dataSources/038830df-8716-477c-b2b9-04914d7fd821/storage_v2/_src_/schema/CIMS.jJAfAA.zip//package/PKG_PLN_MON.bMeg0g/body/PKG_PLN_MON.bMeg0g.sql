create PACKAGE BODY PKG_PLN_MON IS

  V_NL      CONSTANT VARCHAR2(2) := CHR(13) || CHR(10); --换行
  V_NULL    CONSTANT VARCHAR2(4) := 'NULL'; --空值
  V_TRUE    CONSTANT VARCHAR2(2) := 'Y';
  V_FALSE   CONSTANT VARCHAR2(2) := 'N';
  V_RESULT  CONSTANT NUMBER := 0; --成功返回
  V_SUCCESS CONSTANT VARCHAR2(10) := 'SUCCESS';
  V_BASE_EXCEPTION EXCEPTION; --自定义异常
  -----------------------------------------------------------------------------
  -- AUTHOR  : 唐家智
  -- CREATED : 2015-07-10 10:06:52
  -- PURPOSE : 月计划汇总
  -----------------------------------------------------------------------------
  PROCEDURE P_COLLECT_MONTHPLAN(P_SALES_CENTER_CODE IN VARCHAR2, --计划订单行、提货订单行 关系表主键id列表
                                P_PLAN_TYPE         IN VARCHAR2, --月计划类型
                                P_PLAN_PERIOD       IN VARCHAR2, --月计划周期
                                --p_hqIsCustomer In Varchar2,--总部是否根据客户汇总  Y 是  N否
                                P_SALES_MAIN_TYPE IN VARCHAR2, --营销大类
                                P_USER_CODE       IN VARCHAR2, --用户编码
                                P_ENTITY_ID       IN NUMBER, --主体Id
                                P_RESULT          IN OUT Varchar2, --返回结果：成功返回"SUCCESS"，失败返回原因
                                P_MPLN_HEAD_SEQUENCE IN OUT Varchar2 --返回汇总生成的单号，失败时为空
                                ) IS
    V_ISSUMMARY NUMBER := 0; --月计划是否已汇总
    V_ISHQ      NUMBER := 0; --是否为总部
    -- v_IsByMainType varchar2(2) := v_True;--否按照营销大类汇总
    V_MPLN_HEAD_ID           NUMBER; --月计划头自增主键
    V_MPLN_HEAD_SEQUENCE     VARCHAR2(100); --月计划头序列号
    V_SALESCENTER_ROW        UP_ORG_UNIT%ROWTYPE; --营销中心
    V_SALES_MAIN_TYPE        VARCHAR2(100); --营销大类
    V_SALES_SUB_TYPE         VARCHAR2(100); --营销大类
    V_MPLN_HEAD_SAVE_COUNT   NUMBER := 0; --写入的月计划头数量统计
    V_COLLECT_MODE           T_BD_PARAM_ENTITY.ENTITY_VALUE%TYPE;
    V_SEND_BY_TYPE           T_PLN_ORDER_TYPE.SEND_BY_TYPE%TYPE;
    V_SALES_MAIN_TYPE_FILTER VARCHAR2(2); --月预测是否控制大类必填，根据此参数判断汇总时是否根据大类汇总 lilh6 17-4-12
    R_ORDER_TYPE             T_PLN_ORDER_TYPE%Rowtype;
    v_plan_mode              varchar2(32);
  
  BEGIN
    P_RESULT := V_SUCCESS;
    P_MPLN_HEAD_SEQUENCE := '';
  
    --获取月计划汇总方式
    BEGIN
      SELECT PKG_BD.F_GET_PARAMETER_VALUE('PLN_MONTH_PLAN_COLLECT_TYPE',
                                          P_ENTITY_ID,
                                          NULL,
                                          NULL)
        INTO V_COLLECT_MODE
        FROM DUAL;
    EXCEPTION
      WHEN OTHERS THEN
        V_COLLECT_MODE := 'SC';
    END;
  
    ---月预测是否控制大类必填，根据此参数判断汇总时是否根据大类汇总 lilh6 17-4-12
    BEGIN
      V_SALES_MAIN_TYPE_FILTER := PKG_BD.F_GET_PARAMETER_VALUE('PLAN_SALES_MAIN_TYPE_FILTER',
                                                               P_ENTITY_ID);
    EXCEPTION
      WHEN OTHERS THEN
        P_RESULT := '获取PLAN_SALES_MAIN_TYPE_FILTER参数失败！' || V_NL || SQLERRM;
        RAISE V_BASE_EXCEPTION;
    END;
    
    --获取订单类型 lilh6 2018-9-20
    Select *
      Into R_ORDER_TYPE
      From t_Pln_Order_Type Ot
     Where ot.order_type_id = p_Plan_Type;
    
    --获取月计划类型的报送类型
    BEGIN
      SELECT t.send_by_type
        INTO v_send_by_type
        FROM t_Pln_Order_Type t
       WHERE t.order_type_id = p_Plan_Type;
    EXCEPTION
      WHEN OTHERS THEN
        v_send_by_type := 1;
    END;
    
    IF v_send_by_type NOT IN (2,5,4,7) THEN
      --验证月计划是否已经汇总
      SELECT COUNT(1)
        INTO V_ISSUMMARY
        FROM T_STP_MONTH_PLAN_HEAD T
       WHERE T.SALES_CENTER_CODE = P_SALES_CENTER_CODE
         AND T.PLAN_TYPE = P_PLAN_TYPE
         AND T.PLAN_PERIOD = P_PLAN_PERIOD
         AND T.ENTITY_ID = P_ENTITY_ID
         AND (V_SALES_MAIN_TYPE_FILTER = 'N' OR --增加大类是否必填参数判断，大类不用填时会存在大类为空的情况 lilh6 17-4-12
             (V_SALES_MAIN_TYPE_FILTER = 'Y' And Instr(',' || P_SALES_MAIN_TYPE || ',', ',' || T.SALES_MAIN_TYPE || ',') > 0))
            --AND t.sales_main_type = nvl(P_SALES_MAIN_TYPE, t.sales_main_type)
         AND T.CUSTOMER_CODE IS NULL
         AND T.PLAN_STATUS NOT IN ('06');
      IF V_ISSUMMARY > 0 THEN
        P_RESULT := '已经存在有效的月计划，若需重新汇总，请先关闭当前中心、类型、周期、营销大类的月计划。';
        RAISE V_BASE_EXCEPTION;
      END IF;
    END IF;
    
    --验证总部是否已经汇总当前条件的月计划
    SELECT COUNT(1)
      INTO V_ISSUMMARY
      FROM T_STP_MONTH_PLAN_HEAD T, UP_CODELIST U
     WHERE T.SALES_CENTER_CODE = U.CODE_VALUE
       AND T.PLAN_TYPE = P_PLAN_TYPE
       AND T.PLAN_PERIOD = P_PLAN_PERIOD
       AND T.ENTITY_ID = P_ENTITY_ID
       AND T.CUSTOMER_CODE IS NULL
       AND U.CODETYPE = 'HQ_SALES_CENTER_CODE'
       AND (V_SALES_MAIN_TYPE_FILTER = 'N' OR --增加大类是否必填参数判断，大类不用填时会存在大类为空的情况 lilh6 17-4-12
           (V_SALES_MAIN_TYPE_FILTER = 'Y' And Instr(',' || P_SALES_MAIN_TYPE || ',', ',' || T.SALES_MAIN_TYPE || ',') > 0
           ))
          --AND t.sales_main_type = nvl(P_SALES_MAIN_TYPE, t.sales_main_type)
       AND U.ENABLED = '0'
       AND T.PLAN_STATUS NOT IN ('06');
    IF V_ISSUMMARY > 0 THEN
      P_RESULT := '总部当月存在有效的月计划，若需重新汇总，请先关闭当前类型、周期和营销大类的总部月计划';
      RAISE V_BASE_EXCEPTION;
    END IF;
  
    --判断改营销中心是否是总部
    SELECT COUNT(1)
      INTO V_ISHQ
      FROM UP_CODELIST T
     WHERE T.CODETYPE = 'HQ_SALES_CENTER_CODE'
       AND T.CODE_VALUE = P_SALES_CENTER_CODE
       AND T.ENABLED = '0';
    --判断是总部汇总还是中心汇总
    If V_ISHQ > 0 Then
      v_plan_mode := 'HQ_COLLECT'; --总部汇总
    Else
      v_plan_mode := 'SC_COLLECT'; --中心汇总
    End If;
    --获取营销中心信息
    SELECT T.NAME, T.CODE, T.UNIT_ID
      INTO V_SALESCENTER_ROW.NAME,
           V_SALESCENTER_ROW.CODE,
           V_SALESCENTER_ROW.UNIT_ID
      FROM UP_ORG_UNIT T
     WHERE T.CODE = P_SALES_CENTER_CODE;
  
    --判断主体是否按照营销大类汇总
    -- select nvl(a.entity_value, v_False) into v_IsByMainType from T_BD_PARAM_ENTITY a,T_BD_PARAM_LIST b where a.param_list_id = b.param_list_id and a.entity_id = p_Entity_Id and b.param_code = 'ITEM_SALES_MAIN_TYPE_FILTER' and a.active_flag = v_True;
    
    FOR R_H IN (SELECT DISTINCT MPH.SALES_MAIN_TYPE
                  FROM T_STP_MONTH_PLAN_HEAD MPH
                 WHERE MPH.ENTITY_ID = P_ENTITY_ID
                   AND MPH.PLAN_TYPE = P_PLAN_TYPE
                   AND MPH.PLAN_PERIOD = P_PLAN_PERIOD
                   AND (V_SALES_MAIN_TYPE_FILTER = 'N' OR
                       (V_SALES_MAIN_TYPE_FILTER = 'Y' And Instr(',' || P_SALES_MAIN_TYPE || ',', ',' || MPH.SALES_MAIN_TYPE || ',') > 0))
                      --AND mph.sales_main_type = nvl(P_SALES_MAIN_TYPE, mph.sales_main_type)
                   AND MPH.PLAN_STATUS = '04'
                   AND ((V_ISHQ > 0 AND V_COLLECT_MODE = 'SC' AND
                       MPH.CUSTOMER_CODE IS NULL) OR
                       (V_ISHQ > 0 AND V_COLLECT_MODE = 'DL' AND
                       MPH.CUSTOMER_CODE IS NOT NULL) OR
                       (V_ISHQ = 0 AND
                       MPH.SALES_CENTER_CODE = P_SALES_CENTER_CODE AND
                       MPH.CUSTOMER_CODE IS NOT NULL))
                
                ) LOOP
      --生成主键id
      SELECT S_STP_MONTH_PLAN_HEAD.NEXTVAL INTO V_MPLN_HEAD_ID FROM DUAL;
      --生成月计划序列号
      PKG_BD.P_GET_BILL_NO('stpMonthPlanNo',
                           NULL,
                           P_ENTITY_ID,
                           NULL,
                           V_MPLN_HEAD_SEQUENCE);
      --写入月计划头数据
      INSERT INTO T_STP_MONTH_PLAN_HEAD
        (MONTH_PLAN_HEAD_ID,
         ENTITY_ID,
         PLAN_SEQUENCE,
         PLAN_TYPE,
         PLAN_PERIOD,
         PLAN_STATUS,
         CREATED_BY,
         CREATION_DATE,
         LAST_UPDATED_BY,
         LAST_UPDATE_DATE,
         SALES_CENTER_CODE,
         SALES_CENTER_NAME,
         SALES_MAIN_TYPE,
         SALES_CENTER_ID,
         SYS_SOURCE,
         plan_mode)
      VALUES
        (V_MPLN_HEAD_ID,
         P_ENTITY_ID,
         V_MPLN_HEAD_SEQUENCE,
         P_PLAN_TYPE,
         P_PLAN_PERIOD,
         '01',
         P_USER_CODE,
         SYSDATE,
         P_USER_CODE,
         SYSDATE,
         V_SALESCENTER_ROW.CODE,
         V_SALESCENTER_ROW.NAME,
         R_H.SALES_MAIN_TYPE,
         V_SALESCENTER_ROW.UNIT_ID,
         decode(nvl(R_ORDER_TYPE.Is_Business_Control,'_'),'collect','CIMS_COLLECT',Null),
         v_plan_mode);
      --记录写入数量
      V_MPLN_HEAD_SAVE_COUNT := V_MPLN_HEAD_SAVE_COUNT + 1;
      P_MPLN_HEAD_SEQUENCE := P_MPLN_HEAD_SEQUENCE || V_MPLN_HEAD_SEQUENCE || ';'; --记录汇总生成的单号
      
      --更新汇总预测号字段，参与汇总的预测都更新 lilh6 2018-10-22
      Update t_Stp_Month_Plan_Head h
         Set h.hq_plan_sequence = V_MPLN_HEAD_SEQUENCE,
             h.last_updated_by = P_USER_CODE,
             h.last_update_date = Sysdate,
             h.version = nvl(h.version,0) + 1
       Where (v_Sales_Main_Type_Filter = 'N' Or
             (v_Sales_Main_Type_Filter = 'Y' And
             h.Sales_Main_Type = r_h.Sales_Main_Type))
         And h.Entity_Id = p_Entity_Id
         And h.Plan_Type = p_Plan_Type
         And h.Plan_Period = p_Plan_Period
         And h.Plan_Status = '04'
         And h.month_plan_head_id <> V_MPLN_HEAD_ID --排除生成的数据
         And ((v_Ishq > 0 And v_Collect_Mode = 'SC' And
             h.Customer_Code Is Null) Or
             (v_Ishq > 0 And v_Collect_Mode = 'DL' And
             h.Customer_Code Is Not Null) Or
             (v_Ishq = 0 And h.Sales_Center_Code = p_Sales_Center_Code And
             h.Customer_Code Is Not Null));	
    
      --新增行数据
      --增加行数据_预计分销金额 jiangwei29_2018-03-11
      INSERT INTO T_STP_MONTH_PLAN_LINES
        (MONTH_PLAN_LINE_ID,
         MONTH_PLAN_HEAD_ID,
         ENTITY_ID,
         ITEM_CODE,
         ITEM_NAME,
         SALES_MAIN_TYPE,
         SALES_SUB_TYPE,
         MONTH_PLAN_QTY,
         PRODUCING_AREA_CODE,
         PRODUCING_AREA_NAME,
         CREATED_BY,
         CREATION_DATE,
         LAST_UPDATED_BY,
         LAST_UPDATE_DATE,
         ITEM_ID,
         SOURCE_MODE,
         CURRENT_STOCK,
         EXPECTED_STOCK_EOM,
         MONTHLY_AVERAGE_SALES,
         M1_MONTHLY_AVERAGE_SALES,
         M1_MONTHLY_AVERAGE_AMOUNT,--M+1 预计分销金额
         MONTH_PLAN_AMOUNT,
         M1_STOCK_EOM,
         M2_MONTHLY_AVERAGE_SALES,
         M2_MONTHLY_AVERAGE_AMOUNT,--M+2 预计分销金额
         M2_MONTH_PLAN_QTY,
         M2_MONTH_PLAN_AMOUNT,
         M2_STOCK_EOM,
         M3_MONTHLY_AVERAGE_SALES,
         M3_MONTHLY_AVERAGE_AMOUNT,--M+3 预计分销金额
         M3_MONTH_PLAN_QTY,
         M3_MONTH_PLAN_AMOUNT,
         M3_STOCK_EOM,
         PRE_FIELD_03,  --汇总新品是否为全新品标识记录在计划行备用字段3上  jiangwei29 2019-7-19
         M1_MONTH_REQUIRE_QTY,    --M+2月中心提报需求（原始）  add by houhs at 2019-10-23
         M2_MONTH_REQUIRE_QTY,    --M+2月中心提报需求（原始）  add by houhs at 2019-10-23
         M3_MONTH_REQUIRE_QTY     --M+3月中心提报需求（原始）  add by houhs at 2019-10-23
         )
        SELECT S_STP_MONTH_PLAN_LINES.NEXTVAL,
               MONTH_PLAN_HEAD_ID,
               ENTITY_ID,
               ITEM_CODE,
               ITEM_NAME,
               SALES_MAIN_TYPE,
               SALES_SUB_TYPE,
               MONTH_PLAN_QTY,
               PRODUCING_AREA_CODE,
               PRODUCING_AREA_NAME,
               CREATED_BY,
               CREATION_DATE,
               LAST_UPDATED_BY,
               LAST_UPDATE_DATE,
               ITEM_ID,
               decode(nvl(R_ORDER_TYPE.Is_Business_Control,'_'),'collect','collect',''), --collect模式的才写collect
               CURRENT_STOCK,
               EXPECTED_STOCK_EOM,
               MONTHLY_AVERAGE_SALES,
               M1_MONTHLY_AVERAGE_SALES,
               M1_MONTHLY_AVERAGE_AMOUNT,--M+1 预计分销金额
               MONTH_PLAN_AMOUNT,
               M1_STOCK_EOM,
               M2_MONTHLY_AVERAGE_SALES,
               M2_MONTHLY_AVERAGE_AMOUNT,--M+2 预计分销金额
               M2_MONTH_PLAN_QTY,
               M2_MONTH_PLAN_AMOUNT,
               M2_STOCK_EOM,
               M3_MONTHLY_AVERAGE_SALES,
               M3_MONTHLY_AVERAGE_AMOUNT,--M+3 预计分销金额
               M3_MONTH_PLAN_QTY,
               M3_MONTH_PLAN_AMOUNT,
               M3_STOCK_EOM,
               Is_Brand_New,
               MONTH_PLAN_QTY,  --add by houhs at 2019-10-23 增加月中心提报数量
               M2_MONTH_PLAN_QTY,
               M3_MONTH_PLAN_QTY
          FROM (SELECT V_MPLN_HEAD_ID AS MONTH_PLAN_HEAD_ID,
                       P_ENTITY_ID AS ENTITY_ID,
                       BI.ITEM_CODE,
                       BI.ITEM_NAME,
                       bi.SALES_MAIN_TYPE,
                       BI.SALES_SUB_TYPE,
                       SUM(L.MONTH_PLAN_QTY) MONTH_PLAN_QTY,
                       L.PRODUCING_AREA_CODE,
                       L.PRODUCING_AREA_NAME,
                       P_USER_CODE AS CREATED_BY,
                       SYSDATE AS CREATION_DATE,
                       P_USER_CODE AS LAST_UPDATED_BY,
                       SYSDATE AS LAST_UPDATE_DATE,
                       L.ITEM_ID,
                       sum(l.current_stock) CURRENT_STOCK,
                       sum(l.expected_stock_eom) EXPECTED_STOCK_EOM,
                       sum(l.monthly_average_sales) MONTHLY_AVERAGE_SALES,
                       sum(l.m1_monthly_average_sales) M1_MONTHLY_AVERAGE_SALES,
                       sum(l.m1_monthly_average_amount) M1_MONTHLY_AVERAGE_AMOUNT, -- M+1分销总金额
                       sum(l.month_plan_amount) MONTH_PLAN_AMOUNT,
                       sum(l.m1_stock_eom) M1_STOCK_EOM,
                       sum(l.m2_monthly_average_sales) M2_MONTHLY_AVERAGE_SALES,
                       sum(l.m2_monthly_average_amount) M2_MONTHLY_AVERAGE_AMOUNT, -- M+2分销总金额
                       sum(l.m2_month_plan_qty) M2_MONTH_PLAN_QTY,
                       sum(l.m2_month_plan_amount) M2_MONTH_PLAN_AMOUNT,
                       sum(l.m2_stock_eom) M2_STOCK_EOM,
                       sum(l.m3_monthly_average_sales) M3_MONTHLY_AVERAGE_SALES,
                       sum(l.m3_monthly_average_amount) M3_MONTHLY_AVERAGE_AMOUNT, -- M+3分销总金额
                       sum(l.m3_month_plan_qty) M3_MONTH_PLAN_QTY,
                       sum(l.m3_month_plan_amount) M3_MONTH_PLAN_AMOUNT,
                       sum(l.m3_stock_eom) M3_STOCK_EOM,
                       BI.Is_Brand_New  --汇总增加新品是否为全新品标识  jiangwei29 2019-7-19
                  FROM T_STP_MONTH_PLAN_LINES L,
                       T_STP_MONTH_PLAN_HEAD  H,
                       T_BD_ITEM              BI
                 WHERE L.MONTH_PLAN_HEAD_ID = H.MONTH_PLAN_HEAD_ID
                   AND L.ITEM_ID = BI.ITEM_ID
                   AND (V_SALES_MAIN_TYPE_FILTER = 'N' OR
                       (V_SALES_MAIN_TYPE_FILTER = 'Y' AND
                       H.SALES_MAIN_TYPE = R_H.SALES_MAIN_TYPE))
                      --AND H.SALES_MAIN_TYPE = R_H.SALES_MAIN_TYPE
                   AND H.ENTITY_ID = P_ENTITY_ID
                   AND H.PLAN_TYPE = P_PLAN_TYPE
                   AND H.PLAN_PERIOD = P_PLAN_PERIOD
                   AND H.PLAN_STATUS = '04'
                   AND ((V_ISHQ > 0 AND V_COLLECT_MODE = 'SC' AND
                       H.CUSTOMER_CODE IS NULL) OR
                       (V_ISHQ > 0 AND V_COLLECT_MODE = 'DL' AND
                       H.CUSTOMER_CODE IS NOT NULL) OR
                       (V_ISHQ = 0 AND
                       H.SALES_CENTER_CODE = P_SALES_CENTER_CODE AND
                       H.CUSTOMER_CODE IS NOT NULL))
                 GROUP BY BI.ITEM_CODE,
                          BI.ITEM_NAME,
                          bi.SALES_MAIN_TYPE,
                          BI.SALES_SUB_TYPE,
                          L.PRODUCING_AREA_CODE,
                          L.PRODUCING_AREA_NAME,
                          L.ITEM_ID,
                          BI.Is_Brand_New);
    END LOOP;
  
    /*--分组查询结果,定义游标
    declare
        cursor v_mpln_cursor is
        SELECT MPH.SALES_MAIN_TYPE,
               MPL.ITEM_ID,
               MPL.ITEM_CODE,
               MPL.ITEM_NAME,
               MPL.PRODUCING_AREA_CODE,
               MPL.PRODUCING_AREA_NAME,
               --MPL.SALES_SUB_TYPE,
               SUM(MPL.MONTH_PLAN_QTY) MONTH_PLAN_QTY
          FROM T_STP_MONTH_PLAN_HEAD MPH, T_STP_MONTH_PLAN_LINES MPL
         WHERE MPH.MONTH_PLAN_HEAD_ID = MPL.MONTH_PLAN_HEAD_ID
           AND MPH.ENTITY_ID = p_Entity_Id
           AND MPH.PLAN_TYPE = p_Plan_Type
           AND MPH.PLAN_PERIOD = p_Plan_Period
           AND MPH.PLAN_STATUS = '04'
           --如果是总部,则查询客户为空的月计划     如果不是总部,则按照中心查询
           AND (
                 (v_IsHQ>0 AND v_collect_mode='SC' AND MPH.CUSTOMER_CODE IS NULL)
                 OR (v_IsHQ>0 AND v_collect_mode='DL' AND MPH.CUSTOMER_CODE IS NOT NULL)
                 OR (v_IsHQ=0 AND MPH.SALES_CENTER_CODE = p_Sales_Center_Code AND MPH.CUSTOMER_CODE IS NOT NULL)
               )
         GROUP BY
         MPH.SALES_MAIN_TYPE,
                  MPL.ITEM_ID,
                  MPL.ITEM_CODE,
                  MPL.ITEM_NAME,
                  MPL.PRODUCING_AREA_CODE,
                  MPL.PRODUCING_AREA_NAME\*,
                  MPL.SALES_SUB_TYPE*\
         ORDER BY MPH.SALES_MAIN_TYPE DESC;
    v_mpln  v_mpln_cursor%rowtype;
    
    begin
      for v_mpln in v_mpln_cursor loop
        if v_sales_main_type is null or v_sales_main_type!=v_mpln.SALES_MAIN_TYPE then
          v_sales_main_type := v_mpln.SALES_MAIN_TYPE;
          --生成主键id
          select S_STP_MONTH_PLAN_HEAD.NEXTVAL into v_mpln_head_id from dual;
          --生成月计划序列号
          PKG_BD.P_GET_BILL_NO('stpMonthPlanNo', null, p_Entity_Id, null, v_mpln_head_sequence);
          --写入月计划头数据
          insert into T_STP_MONTH_PLAN_HEAD
          (MONTH_PLAN_HEAD_ID, ENTITY_ID, PLAN_SEQUENCE, PLAN_TYPE, PLAN_PERIOD, PLAN_STATUS, CREATED_BY, CREATION_DATE, LAST_UPDATED_BY, LAST_UPDATE_DATE, SALES_CENTER_CODE, SALES_CENTER_NAME, SALES_MAIN_TYPE, SALES_CENTER_ID)
          values
          (v_mpln_head_id, p_Entity_Id, v_mpln_head_sequence, p_Plan_Type, p_Plan_Period, '01', p_User_Code, sysdate, p_User_Code, sysdate, v_salesCenter_row.Code, v_salesCenter_row.Name, v_sales_main_type, v_salesCenter_row.Unit_Id);
          --记录写入数量
          v_mpln_head_save_count := v_mpln_head_save_count + 1;
        end if;
    
        BEGIN
          SELECT i.sales_sub_type
            INTO v_sales_sub_type
            FROM t_Bd_Item i
           WHERE i.entity_id = p_Entity_Id
             AND i.item_id = v_mpln.itEM_ID;
        END;
    
        --写入月计划行数据
        insert into
        T_STP_MONTH_PLAN_LINES
        (MONTH_PLAN_LINE_ID, MONTH_PLAN_HEAD_ID, ENTITY_ID, ITEM_CODE, ITEM_NAME, SALES_MAIN_TYPE, SALES_SUB_TYPE, MONTH_PLAN_QTY, PRODUCING_AREA_CODE, PRODUCING_AREA_NAME, CREATED_BY, CREATION_DATE, LAST_UPDATED_BY, LAST_UPDATE_DATE, ITEM_ID)
        values
        (S_STP_MONTH_PLAN_LINES.NEXTVAL, v_mpln_head_id, p_Entity_Id, v_mpln.ITEM_CODE, v_mpln.ITEM_NAME, v_sales_main_type, v_sales_sub_type, v_mpln.MONTH_PLAN_QTY, v_mpln.PRODUCING_AREA_CODE, v_mpln.PRODUCING_AREA_NAME, p_User_Code, sysdate, p_User_Code, sysdate, v_mpln.ITEM_ID);
      end loop;*/
  
    IF V_MPLN_HEAD_SAVE_COUNT = 0 THEN
      P_RESULT := '当前汇总条件无数据。';
      P_MPLN_HEAD_SEQUENCE := '';
      RAISE V_BASE_EXCEPTION;
    END IF;
    --end;
  EXCEPTION
    WHEN V_BASE_EXCEPTION THEN
      NULL;
  END;
  
  -----------------------------------------------------------------------------
  -- AUTHOR  : ex_zhangcc
  -- CREATED : 2015-12-19
  -- PURPOSE : 月计划汇总退回
  -----------------------------------------------------------------------------
  PROCEDURE P_BACK_MONTHPLAN(P_MONTH_HEAD_ID IN NUMBER, --头ID
                             P_USER_CODE     IN VARCHAR2, -- 用户编码
                             P_RESULT        OUT VARCHAR2 --返回结果
                             ) IS
    R_MONTH_HEAD T_STP_MONTH_PLAN_HEAD%ROWTYPE;
    V_COUNT      NUMBER;
    V_NUM        VARCHAR2(100);
    v_msg        VARCHAR2(4000);
  BEGIN
    P_RESULT := V_SUCCESS;
    BEGIN
      SELECT *
        INTO R_MONTH_HEAD
        FROM T_STP_MONTH_PLAN_HEAD H
       WHERE H.MONTH_PLAN_HEAD_ID = P_MONTH_HEAD_ID
         AND H.PLAN_STATUS = '04'
         FOR UPDATE NOWAIT;
    EXCEPTION
      WHEN OTHERS THEN
        P_RESULT := '锁定月计划失败，当前预测不是已审核状态，不允许操作！';
        RAISE V_BASE_EXCEPTION;
    END;
  
    --跨主体结转的月预测，判断总部主体的的计划是否有效，有效则不允许退回 lilh6 2017-4-13
    IF R_MONTH_HEAD.TARGET_PLAN_HEAD_ID IS NOT NULL Then
      --只结转了1个主体
      If R_MONTH_HEAD.TARGET_PLAN_HEAD_ID <> -1 Then
        SELECT COUNT(0)
          INTO V_COUNT
          FROM T_STP_MONTH_PLAN_HEAD H
         WHERE H.MONTH_PLAN_HEAD_ID = R_MONTH_HEAD.TARGET_PLAN_HEAD_ID
           AND H.PLAN_STATUS <> '06';
        IF V_COUNT > 0 THEN
          SELECT H.PLAN_SEQUENCE
            INTO V_NUM
            FROM T_STP_MONTH_PLAN_HEAD H
           WHERE H.MONTH_PLAN_HEAD_ID = R_MONTH_HEAD.TARGET_PLAN_HEAD_ID
             AND H.PLAN_STATUS <> '06';
          P_RESULT := '该月预测已提交并结转到总部主体，对应预测号' || V_NUM ||
                      ',因此不能退回！如需取消请到总部主体关闭';
          RAISE V_BASE_EXCEPTION;
        END IF;
      Else
        P_RESULT := '该月预测已提交并结转到多个总部主体，因此不能退回！如需取消请到总部主体关闭，然后再关闭销司主体预测重新报送';
        RAISE V_BASE_EXCEPTION;
      End If;
      
    END IF;
  
    --如果客户名称不为空标示表示客户计划退回
    IF R_MONTH_HEAD.CUSTOMER_NAME IS NOT NULL THEN
      --查询改中心是否已经汇总
      SELECT COUNT(0)
        INTO V_COUNT
        FROM T_STP_MONTH_PLAN_HEAD H
       WHERE H.ENTITY_ID = R_MONTH_HEAD.ENTITY_ID
         AND H.SALES_CENTER_CODE = R_MONTH_HEAD.SALES_CENTER_CODE --中心编码
         AND H.PLAN_TYPE = R_MONTH_HEAD.PLAN_TYPE --计划类型
         AND H.PLAN_PERIOD = R_MONTH_HEAD.PLAN_PERIOD --计划周期
         AND H.SALES_MAIN_TYPE = R_MONTH_HEAD.SALES_MAIN_TYPE --营销大类
         AND H.CUSTOMER_CODE IS NULL -- 客户为空
         AND H.PLAN_STATUS <> '06'; --非关闭状态
      IF V_COUNT > 0 THEN
        P_RESULT := '中心已存在制单或送审的月预测,不能退回!';
        RAISE V_BASE_EXCEPTION;
      ELSE
        UPDATE T_STP_MONTH_PLAN_HEAD H
           SET H.PLAN_STATUS      = '01',
               H.LAST_UPDATED_BY  = P_USER_CODE,
               H.LAST_UPDATE_DATE = SYSDATE
         WHERE H.MONTH_PLAN_HEAD_ID = P_MONTH_HEAD_ID;
      END IF;
    ELSE
      --如果为空表示为为总部中心汇总
      --如果是引aps的总部中心则不允许退回
      SELECT COUNT(1)
        INTO V_COUNT
        FROM UP_CODELIST T
       WHERE T.CODETYPE = 'HQ_SALES_CENTER_CODE'
         AND T.CODE_VALUE = R_MONTH_HEAD.SALES_CENTER_CODE
         AND T.ENABLED = '0';
      IF V_COUNT > 0 THEN
        P_RESULT := '报送中心为总部,不允许进行退回操作!';
        RAISE V_BASE_EXCEPTION;
      END IF;
      --总部中心已汇总
      SELECT COUNT(0)
        INTO V_COUNT
        FROM T_STP_MONTH_PLAN_HEAD H, UP_CODELIST T
       WHERE H.ENTITY_ID = R_MONTH_HEAD.ENTITY_ID
            --  and  h.sales_center_code=r_month_head.sales_center_code --中心编码
         AND H.PLAN_TYPE = R_MONTH_HEAD.PLAN_TYPE --计划类型
         AND H.PLAN_PERIOD = R_MONTH_HEAD.PLAN_PERIOD --计划周期
         AND H.SALES_MAIN_TYPE = R_MONTH_HEAD.SALES_MAIN_TYPE --营销大类
         AND H.CUSTOMER_CODE IS NULL -- 客户为空
         AND H.PLAN_STATUS <> '06' --非关闭状态
         AND T.CODE_VALUE = H.SALES_CENTER_CODE
         AND T.CODETYPE = 'HQ_SALES_CENTER_CODE'
         --AND T.CODE_VALUE = R_MONTH_HEAD.SALES_CENTER_CODE
         AND T.ENABLED = '0';
      IF V_COUNT > 0 THEN
        P_RESULT := '存在制单或已送审总部月计划,不允许退回!';
        RAISE V_BASE_EXCEPTION;
      ELSE
        UPDATE T_STP_MONTH_PLAN_HEAD H
           SET H.PLAN_STATUS      = '01',
               H.LAST_UPDATED_BY  = P_USER_CODE,
               H.LAST_UPDATE_DATE = SYSDATE
         WHERE H.MONTH_PLAN_HEAD_ID = P_MONTH_HEAD_ID;
      END IF;
    END IF;
   --ccs驳回
   IF R_MONTH_HEAD.SYS_SOURCE='CCS' AND R_MONTH_HEAD.Source_Order_Head_Id IS NOT NULL THEN
      PK_CIMS_CCS.PRO_CCS_CIMS_PREDICT_REJECT(R_MONTH_HEAD.Source_Order_Head_Id,'cims驳回',v_msg);
      IF v_msg!='SUCCESS' THEN
        P_RESULT := '驳回ccs出错：'||v_msg;
        RAISE V_BASE_EXCEPTION;
      END IF;  
   END IF;
  COMMIT;
  EXCEPTION
    WHEN V_BASE_EXCEPTION THEN
      P_RESULT := P_RESULT || V_NL ||
                  SUBSTR(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, 1, 200);
    WHEN OTHERS THEN
      P_RESULT := SUBSTR(SQLERRM, 200) || V_NL ||
                  SUBSTR(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, 200);
  END;
  -----------------------------------------------------------------------------
  -- AUTHOR  : lilh6
  -- CREATED : 2017-4-10
  -- PURPOSE : 月计划跨主体结转                          
  ------------------------------------------------------------------------------------ 
  PROCEDURE P_CREATE_DOMESTIC_FORCAST(P_MONTH_HEAD_ID IN NUMBER, --头ID
                                      P_USER_CODE     IN VARCHAR2, -- 用户编码
                                      P_RESULT        OUT VARCHAR2 --返回结果
                                      ) IS
    R_STP_MONTH_PLAN_HEAD T_STP_MONTH_PLAN_HEAD%ROWTYPE; --月预测
    V_ENTITY_ID           T_STP_MONTH_PLAN_HEAD.ENTITY_ID%TYPE; --目标主体ID
    V_SALES_CENTER_ID     T_STP_MONTH_PLAN_HEAD.SALES_CENTER_ID%TYPE; --目标主体中心ID
    V_SALES_CENTER_CODE   T_STP_MONTH_PLAN_HEAD.SALES_CENTER_CODE%TYPE; --目标主体中心编码
    V_SALES_CENTER_NAME   T_STP_MONTH_PLAN_HEAD.SALES_CENTER_NAME%TYPE; --目标主体中心名称
    V_PLAN_SEQUENCE       T_STP_MONTH_PLAN_HEAD.PLAN_SEQUENCE%TYPE; --目标主体预测计划号
    V_PLAN_TYPE           T_STP_MONTH_PLAN_HEAD.PLAN_TYPE%TYPE; --目标主体月预测类型
    V_PLAN_PERIOD         T_STP_MONTH_PLAN_HEAD.PLAN_PERIOD%TYPE; --目标主体订单周期
    V_SALES_MAIN_TYPE_H   T_STP_MONTH_PLAN_HEAD.SALES_MAIN_TYPE%TYPE; --目标主体营销大类
    V_MONTH_PLAN_HEAD_ID  T_STP_MONTH_PLAN_HEAD.MONTH_PLAN_HEAD_ID%TYPE; --月预测头ID
    V_MONTH_PLAN_LINE_ID  T_STP_MONTH_PLAN_LINES.MONTH_PLAN_LINE_ID%TYPE; --月预测行ID
    V_ITEM_CODE           T_STP_MONTH_PLAN_LINES.ITEM_CODE%TYPE; --产品编码
    V_ITEM_ID             T_STP_MONTH_PLAN_LINES.ITEM_ID%TYPE; --产品id
    V_ITEM_NAME           T_STP_MONTH_PLAN_LINES.ITEM_NAME%TYPE; --产品名称
    V_SALES_MAIN_TYPE     T_STP_MONTH_PLAN_LINES.SALES_MAIN_TYPE%TYPE; --营销大类
    V_SALES_SUB_TYPE      T_STP_MONTH_PLAN_LINES.SALES_SUB_TYPE%TYPE; --营销小类
    V_PRODUCING_AREA_CODE T_STP_MONTH_PLAN_LINES.PRODUCING_AREA_CODE%TYPE; --产地编码
    V_PRODUCING_AREA_NAME T_STP_MONTH_PLAN_LINES.PRODUCING_AREA_NAME%TYPE; --产地名称
    V_VALUE               VARCHAR2(1000);
    V_COUNT               NUMBER;
    V_IS_SALES_MAIN_TYPE  VARCHAR2(32);
    V_PERIOD_CODE         VARCHAR2(40);
    V_HQ_PLAN_SEQUENCE    T_STP_MONTH_PLAN_HEAD.PLAN_SEQUENCE%TYPE; --总部主体预测计划号
    v_to_hq_count         Number; --结转几个总部主体
  
  BEGIN
    P_RESULT := V_SUCCESS;
    v_to_hq_count := 0;
    BEGIN
      V_VALUE := '没有查询到有效数据,锁定月计划失败!';
      SELECT *
        INTO R_STP_MONTH_PLAN_HEAD
        FROM T_STP_MONTH_PLAN_HEAD H
       WHERE H.MONTH_PLAN_HEAD_ID = P_MONTH_HEAD_ID
         FOR UPDATE NOWAIT;
    EXCEPTION
      WHEN OTHERS THEN
        P_RESULT := V_VALUE || V_NL || SQLERRM;
        RAISE V_BASE_EXCEPTION;
    END;
    
    --根据优先的主体，分配好哪些行结转哪个主体
    For r_entity In (
      Select e.Code_Value
       From Up_Codelist t, Up_Codelist_Entity e
      Where t.Id = e.Codelist_Id
        And t.Codetype = 'T_STP_PRIOR_ENTITY'
        And e.Entity_Id = R_STP_MONTH_PLAN_HEAD.Entity_Id
      Order By t.Code_Order Asc) Loop
      --根据产品，先记录行的结转主体
      Update t_Stp_Month_Plan_Lines l
        Set l.hq_entity_id = r_entity.code_value,
            l.last_update_date = Sysdate
      Where l.Month_Plan_Head_Id = P_MONTH_HEAD_ID
        And l.hq_entity_id Is Null
        And Exists (Select 1
               From Cims.t_Bd_Item i
              Where i.Item_Code = l.Item_Code
                And i.Entity_Id = r_entity.code_value);
    End Loop;
    
    For r_line_entity In(
      Select distinct l.Hq_Entity_Id
        From t_Stp_Month_Plan_Lines l
       Where l.Month_Plan_Head_Id = p_Month_Head_Id
      )Loop
      V_ENTITY_ID := r_line_entity.Hq_Entity_Id; --总部主体id
      v_to_hq_count := v_to_hq_count + 1;
      
      --已跨主体结转过有效的预测，不允许重复结转
      IF R_STP_MONTH_PLAN_HEAD.TARGET_PLAN_HEAD_ID IS NOT Null And R_STP_MONTH_PLAN_HEAD.TARGET_PLAN_HEAD_ID <> -1 THEN
        Begin
          Select h.plan_sequence
            INTO V_HQ_PLAN_SEQUENCE
            FROM T_STP_MONTH_PLAN_HEAD H
           WHERE H.MONTH_PLAN_HEAD_ID =
                 R_STP_MONTH_PLAN_HEAD.TARGET_PLAN_HEAD_ID
             AND H.PLAN_STATUS <> '06';
          IF V_HQ_PLAN_SEQUENCE Is Not Null THEN
            P_RESULT := '已存在有效的结转的总部主体月预测，不能重复提交！总部主体预测号：' || V_HQ_PLAN_SEQUENCE;
            RAISE V_BASE_EXCEPTION;
          END IF;
        Exception
          When Others Then
            Null;
        End;
        
      END IF;
    
      --获取目标主体的主体，中心等相关信息
      BEGIN
        SELECT R.HQ_ENTITY_ID,
               R.HQ_SALES_CENTER_ID,
               R.HQ_SALES_CENTER_CODE,
               R.HQ_SALES_CENTER_NAME
          INTO V_ENTITY_ID,
               V_SALES_CENTER_ID,
               V_SALES_CENTER_CODE,
               V_SALES_CENTER_NAME
          FROM T_BD_CENTER_RELATION R
         WHERE R.SC_SALES_CENTER_CODE =
               R_STP_MONTH_PLAN_HEAD.SALES_CENTER_CODE
           AND R.SC_ENTITY_ID = R_STP_MONTH_PLAN_HEAD.ENTITY_ID
           And r.hq_entity_id = V_ENTITY_ID --已知总部主体id
           AND ROWNUM = 1;
      EXCEPTION
        WHEN OTHERS THEN
          P_RESULT := '获取跨主体关系失败，请检查中心是否维护跨主体关系！';
          RAISE V_BASE_EXCEPTION;
      END;
    
      --获取目标主体单据类型
      BEGIN
        SELECT OTR.TRANSFER_ORDER_TYPE_ID
          INTO V_PLAN_TYPE
          FROM T_PLN_ORDER_TYPE_RELA OTR
         WHERE OTR.RELATION_TYPE = 'LG_ORDER'
           AND OTR.SOURCE_ENTITY_ID = R_STP_MONTH_PLAN_HEAD.ENTITY_ID
           AND OTR.SOURCE_ORDER_TYPE_ID = R_STP_MONTH_PLAN_HEAD.PLAN_TYPE
           AND OTR.TRANSFER_ENTITY_ID = V_ENTITY_ID;
      EXCEPTION
        WHEN OTHERS THEN
          P_RESULT := '获取跨主体单据类型关系失败，请检查是否维护跨主体单据类型关系！';
          RAISE V_BASE_EXCEPTION;
      END;

      --营销大类是否必填
      BEGIN
        V_IS_SALES_MAIN_TYPE := PKG_BD.F_GET_PARAMETER_VALUE('PLAN_SALES_MAIN_TYPE_FILTER',
                                                             R_STP_MONTH_PLAN_HEAD.ENTITY_ID);
      EXCEPTION
        WHEN OTHERS THEN
          P_RESULT := '获取PLAN_SALES_MAIN_TYPE_FILTER参数失败！' || V_NL || SQLERRM;
          RAISE V_BASE_EXCEPTION;
      END;
      
      --获取目标主体营销大类
      IF V_IS_SALES_MAIN_TYPE = 'Y' THEN
        BEGIN
          SELECT DISTINCT ICR.HQ_ITEM_CLASS_CODE
            INTO V_SALES_MAIN_TYPE_H
            FROM T_BD_ITEM_CLASS_RELATION ICR
           WHERE ICR.SALE_TYPE = 'M'
             AND ICR.SC_ENTITY_ID = R_STP_MONTH_PLAN_HEAD.ENTITY_ID
             AND ICR.HQ_ENTITY_ID = V_ENTITY_ID
             AND ICR.SC_ITEM_CLASS_CODE = R_STP_MONTH_PLAN_HEAD.SALES_MAIN_TYPE;
        EXCEPTION
          WHEN OTHERS THEN
            P_RESULT := '获取目标主体大类失败，请检查大类对应关系！';
            RAISE V_BASE_EXCEPTION;
        END;
      END IF;  
      --获取目标主体订单周期
      BEGIN
        SELECT P.PERIOD_ID, P.PERIOD_CODE
          INTO V_PLAN_PERIOD, V_PERIOD_CODE
          FROM T_PLN_ORDER_PERIOD P
         WHERE P.ENTITY_ID = V_ENTITY_ID
           AND P.PERIOD_CODE =
               (SELECT POP.PERIOD_CODE
                  FROM T_PLN_ORDER_PERIOD POP
                 WHERE POP.PERIOD_ID = R_STP_MONTH_PLAN_HEAD.PLAN_PERIOD);
      EXCEPTION
        WHEN OTHERS THEN
          P_RESULT := '获取目标主体订单周期失败，请检查订单周期是否创建！';
          RAISE V_BASE_EXCEPTION;
      END;
    
      --检查重复报送
      IF P_RESULT = V_SUCCESS THEN
        SELECT COUNT(1)
          INTO V_COUNT
          FROM T_STP_MONTH_PLAN_HEAD H
         WHERE H.ENTITY_ID = V_ENTITY_ID
           AND H.PLAN_TYPE = V_PLAN_TYPE
           AND H.PLAN_PERIOD = V_PLAN_PERIOD
           AND (V_IS_SALES_MAIN_TYPE = 'N' OR
               (V_IS_SALES_MAIN_TYPE = 'Y' AND
               H.SALES_MAIN_TYPE =
               NVL(V_SALES_MAIN_TYPE_H, H.SALES_MAIN_TYPE)))
           AND H.CUSTOMER_CODE IS Null
           And h.sales_center_code = V_SALES_CENTER_CODE
           AND H.PLAN_STATUS IN ('04', '01');
        IF V_COUNT > 0 THEN
          P_RESULT := '总部主体下中心[' || V_SALES_CENTER_NAME || ']在周期[' ||
                      V_PERIOD_CODE || ']已经提交过月预测，不能重复提交。';
          RAISE V_BASE_EXCEPTION;
        END IF;
      END IF;
    
      ------开始生成目标主体的月预测头信息
      --生成目标主体计划单号
      IF P_RESULT = V_SUCCESS THEN
        BEGIN
          PKG_BD.P_GET_BILL_NO(P_BILL_TYPE  => 'stpMonthPlanNo',
                               P_PREFIX_ADD => NULL,
                               P_ENTITY_ID  => V_ENTITY_ID,
                               P_USER_ID    => NULL,
                               P_BILL_NO    => V_PLAN_SEQUENCE);
          IF NVL(V_PLAN_SEQUENCE, '_') = '_' THEN
            P_RESULT := '根据stpMonthPlanNo编码规则获取计划号失败！';
            RAISE V_BASE_EXCEPTION;
          END IF;
        EXCEPTION
          WHEN OTHERS THEN
            P_RESULT := '根据stpMonthPlanNo编码规则获取计划号失败！' || V_NL || SQLERRM;
            RAISE V_BASE_EXCEPTION;
        END;
      
        --新增月预测头
        BEGIN
          SELECT S_STP_MONTH_PLAN_HEAD.NEXTVAL
            INTO V_MONTH_PLAN_HEAD_ID
            FROM DUAL;
          V_VALUE := '开始插入月预测头表信息：';
          INSERT INTO T_STP_MONTH_PLAN_HEAD
            (MONTH_PLAN_HEAD_ID, --月预测头id
             ENTITY_ID, --主体id
             PLAN_SEQUENCE, --月预测计划号
             PLAN_NAME, --月预测名称
             PLAN_TYPE, --月预测类型
             PLAN_PERIOD, --月预测周期
             PLAN_STATUS, --月预测状态
             plan_mode,
             SYS_SOURCE,
             SOURCE_ORDER_HEAD_ID,
             SOURCE_ORDER_NUMBER,
             CREATED_BY, --创建人
             CREATION_DATE, --创建日期
             LAST_UPDATED_BY, --最后更新人
             LAST_UPDATE_DATE, --最后更新日期
             SALES_MAIN_TYPE, --营销大类
             SALES_CENTER_CODE, --中心编码
             SALES_CENTER_NAME, --中心名称
             REMARK, --备注
             SALES_CENTER_ID, --中心id
             VERSION) --版本号
          VALUES
            (V_MONTH_PLAN_HEAD_ID, --月预测头id
             V_ENTITY_ID, --主体id
             V_PLAN_SEQUENCE, --月预测计划号
             '跨主体结转月预测', --月预测名称
             V_PLAN_TYPE, --月预测类型
             V_PLAN_PERIOD, --月预测周期
             '04', --月预测状态
             R_STP_MONTH_PLAN_HEAD.Plan_Mode,
             'CIMS',
             R_STP_MONTH_PLAN_HEAD.MONTH_PLAN_HEAD_ID,
             R_STP_MONTH_PLAN_HEAD.PLAN_SEQUENCE,
             P_USER_CODE, --创建人
             SYSDATE, --创建日期
             P_USER_CODE, --最后更新人
             SYSDATE, --最后更新日期
             V_SALES_MAIN_TYPE_H, --营销大类
             V_SALES_CENTER_CODE, --中心编码
             V_SALES_CENTER_NAME, --中心名称
             R_STP_MONTH_PLAN_HEAD.REMARK, --备注
             V_SALES_CENTER_ID, --中心id
             1); --版本号
        
          --更新原有数据
          Update t_Stp_Month_Plan_Head h
             Set h.Target_Plan_Head_Id = Case
                                           When v_To_Hq_Count = 1 Then
                                            v_Month_Plan_Head_Id
                                           Else
                                            -1
                                         End, --更新目标月预测头id
                 h.Plan_Status         = '04', --更新状态为已审核
                 h.Last_Updated_By     = p_User_Code,
                 h.Last_Update_Date    = Sysdate,
                 h.To_Aps_Msg          = Null
           Where h.Month_Plan_Head_Id = p_Month_Head_Id;
        EXCEPTION
          WHEN OTHERS THEN
            P_RESULT := V_VALUE || '，失败。' || V_NL || SQLERRM;
            RAISE V_BASE_EXCEPTION;
        END;
      END IF;
    
      ---开始处理月预测行数据
      --开始插入数据
      IF P_RESULT = V_SUCCESS THEN
        BEGIN
          /*SELECT S_STP_MONTH_PLAN_LINES.NEXTVAL
            INTO V_MONTH_PLAN_LINE_ID
            FROM DUAL;*/
          V_VALUE := '开始插入月预测行表数据';
          INSERT INTO T_STP_MONTH_PLAN_LINES
            (MONTH_PLAN_LINE_ID, --月预测行id
             MONTH_PLAN_HEAD_ID, --月预测头id
             ENTITY_ID, --主体
             ITEM_CODE, --产品编码
             ITEM_NAME, --产品名称
             SALES_MAIN_TYPE, --营销大类
             SALES_SUB_TYPE, --营销小类
             MONTH_PLAN_QTY, --月预测数量
             PRODUCING_AREA_CODE, --产地编码
             PRODUCING_AREA_NAME, --产地名称
             PRICE, --价格
             CREATED_BY, --创建人
             CREATION_DATE, --创建日期
             LAST_UPDATED_BY, --最后更新人
             LAST_UPDATE_DATE, --最后更新日期
             ITEM_ID, --产品id
             VERSION, --版本号
             MONTH_PLAN_AMOUNT,
             current_stock,
             expected_stock_eom,
             monthly_average_sales,
             m1_monthly_average_sales,
             m1_monthly_average_amount,
             m1_stock_eom,
             m1_stocktopin_ratio,
             m1_abnormal_hints,
             m2_monthly_average_sales,
             m2_monthly_average_amount,
             m2_month_plan_qty,
             m2_month_plan_amount,
             m2_stock_eom,
             m2_stocktopin_ratio,
             m2_abnormal_hints,
             m3_monthly_average_sales,
             m3_monthly_average_amount,
             m3_month_plan_qty,
             m3_month_plan_amount,
             m3_stock_eom,
             m3_stocktopin_ratio,
             m3_abnormal_hints,
             source_mode,
             PRE_FIELD_03   --新品是否为全新品标识, 记录在月计划行备用字段3上  jiangwei29 2019-7-19
             )
            SELECT S_STP_MONTH_PLAN_LINES.NEXTVAL,
                   V_MONTH_PLAN_HEAD_ID,
                   V_ENTITY_ID,
                   T.ITEM_CODE,
                   T.ITEM_NAME,
                   T.SALES_MAIN_TYPE,
                   T.SALES_SUB_TYPE,
                   L.MONTH_PLAN_QTY,
                   L.PRODUCING_AREA_CODE,
                   L.PRODUCING_AREA_NAME,
                   L.PRICE,
                   P_USER_CODE,
                   SYSDATE,
                   P_USER_CODE,
                   SYSDATE,
                   T.ITEM_ID,
                   1,
                   l.month_plan_amount,
                   l.current_stock,
                   l.expected_stock_eom,
                   l.monthly_average_sales,
                   l.m1_monthly_average_sales,
                   l.m1_monthly_average_amount,
                   l.m1_stock_eom,
                   l.m1_stocktopin_ratio,
                   l.m1_abnormal_hints,
                   l.m2_monthly_average_sales,
                   l.m2_monthly_average_amount,
                   l.m2_month_plan_qty,
                   l.m2_month_plan_amount,
                   l.m2_stock_eom,
                   l.m2_stocktopin_ratio,
                   l.m2_abnormal_hints,
                   l.m3_monthly_average_sales,
                   l.m3_monthly_average_amount,
                   l.m3_month_plan_qty,
                   l.m3_month_plan_amount,
                   l.m3_stock_eom,
                   l.m3_stocktopin_ratio,
                   l.m3_abnormal_hints,
                   l.source_mode,
                   T.Is_Brand_New  --销司汇总总部, 取总部主体的是否全新品的标识  jiangwei29 2019-7-19
              FROM T_STP_MONTH_PLAN_LINES L, T_BD_ITEM T
             WHERE T.ITEM_CODE = L.ITEM_CODE
               AND T.ENTITY_ID = V_ENTITY_ID
               AND L.MONTH_PLAN_HEAD_ID = P_MONTH_HEAD_ID;
        
          --更新目标预测行id
          Update t_Stp_Month_Plan_Lines l
             Set l.Target_Plan_Line_Id =
                 (Select Mpl.Month_Plan_Line_Id
                    From t_Stp_Month_Plan_Lines Mpl
                   Where Mpl.Month_Plan_Head_Id = v_Month_Plan_Head_Id
                     And Mpl.Item_Code = l.Item_Code
                     And nvl(mpl.source_mode,'_') = nvl(l.source_mode,'_')
                     And Nvl(Mpl.Producing_Area_Code, '_') =
                         Nvl(l.Producing_Area_Code, '_')),
                 l.Last_Updated_By     = p_User_Code,
                 l.Last_Update_Date    = Sysdate
           Where l.Month_Plan_Head_Id = p_Month_Head_Id;
          
          /*FOR R_LINES IN (SELECT *
                            FROM T_STP_MONTH_PLAN_LINES MPL
                           WHERE MPL.MONTH_PLAN_HEAD_ID = V_MONTH_PLAN_HEAD_ID) LOOP
            UPDATE T_STP_MONTH_PLAN_LINES L
               SET L.TARGET_PLAN_LINE_ID = R_LINES.MONTH_PLAN_LINE_ID,
                   L.LAST_UPDATED_BY     = P_USER_CODE,
                   L.LAST_UPDATE_DATE    = SYSDATE
             WHERE L.MONTH_PLAN_HEAD_ID = P_MONTH_HEAD_ID
               AND L.ITEM_CODE = R_LINES.ITEM_CODE;
          END LOOP;*/
        EXCEPTION
          WHEN OTHERS THEN
            P_RESULT := V_VALUE || '失败。' || V_NL || SQLERRM;
            RAISE V_BASE_EXCEPTION;
        END;
      END IF;
      
    End Loop;
    
  
    
  EXCEPTION
    WHEN V_BASE_EXCEPTION THEN
      ROLLBACK;
      P_RESULT := P_RESULT;
  END; 
    -----------------------------------------------------------------------------
  -- AUTHOR  : lilh6
  -- CREATED : 2018-9-27
  -- PURPOSE : 计算单价，库存，未满足量，开单未提量                          
  ------------------------------------------------------------------------------------       
   Procedure p_Calculate_Monthplan(p_Month_Head_Id In Number, --头ID
                                  p_Result        Out Varchar2 --返回结果
                                  ) Is
                                  
    --使用游标保存多行，根据id查询月计划行 add by houhs at 20191024
    cursor c_Stp_Month_Plan_line is
      select *
        from t_Stp_Month_Plan_Lines tl
       where tl.month_plan_head_id = p_Month_Head_Id;                              
    
    v_Value                   Varchar2(1000);
    r_Stp_Month_Plan_Head     t_Stp_Month_Plan_Head%Rowtype; --月预测
    v_Get_Price_Sql           Varchar2(4000); --取价sql
    v_Get_Undelivered_Qty_Sql Varchar2(4000); --获取开单未发数量sql
    v_Get_Unsatisfied_Qty_Sql Varchar2(4000); --获取未满足数量sql
    v_Get_Current_Stock_Sql   Varchar2(4000); --获取当前库存sql
    v_Update_Sql              Varchar2(4000); --更新sql
    s_Semantic_Type     Varchar2(40); --语义类型：SQL取值、计算公式
    s_Pre_Proc_Sql      Varchar2(4000); --预处理SQL
    s_Query_Code        Varchar2(40); --查询条件编码
    s_Freeze_Query_Code Varchar2(40); --冻结明细查询条件编码
    v_Message           Varchar2(4000);
    v_Ratio_Flag   VARCHAR2(32); --获取系统参数PLN_STP_SKU_RATIO判断，判断是否按SKU存销比控制预测报送
    r_Stp_Month_Plan_line  c_Stp_Month_Plan_line%rowtype; --记录游标计划行信息 add by houhs at 20191024
    v_Current_Stock_Ccs  Number; --当前渠道库存 add by houhs at 20191024
    v_Monthly_Sales_Ccs  Number; --CCS本月已分销
    v_T3_Not_Inv_In   Number; --当前结转T+3订单未入库数
    v_Monthly_Sales_Ccs_After Number; --后续预计分销
    v_M1_Sku_Ratio  Number;  --M+1月存销比
    v_M1_Sku_Ratio_Standard  Number;  --M+1月标准存销比
    v_M1_Sku_Require_Qty_Edit Number; --M+1月需求修正
    v_M2_Sku_Ratio  Number;  --M+2月存销比
    v_M2_Sku_Ratio_Standard  Number;  --M+2月标准存销比
    v_M2_Sku_Require_Qty_Edit Number; --M+21月需求修正
    v_M3_Sku_Ratio  Number;  --M+3月存销比
    v_M3_Sku_Ratio_Standard  Number;  --M+3月标准存销比
    v_M3_Sku_Require_Qty_Edit Number; --M+3月需求修正
    v_Month_Ratio   Number; --当月剩余天数比例
    v_Current_Month Number; --当前月份
    v_Month_Ratio_Get VARCHAR2(32); --对应月份的表准存销比
    v_Eom_Stock_Ccs_All Number; --M月底全渠道库存
    v_Count Number; --判断是否存在数据
    v_Select_Sql Varchar2(4000); --查询sql
    v_Ratio_Config Number;  --配置系统计算系数

  Begin
    p_Result := v_Success;
    Begin
      v_Value := '没有查询到有效数据,获取月计划失败!';
      Select *
        Into r_Stp_Month_Plan_Head
        From t_Stp_Month_Plan_Head h
       Where h.Month_Plan_Head_Id = p_Month_Head_Id;
    Exception
      When Others Then
        p_Result := v_Value || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;
    
    --更新开始计算时间
    Update t_Stp_Month_Plan_Head h
       Set h.Calculate_Begin_Time = Sysdate, h.Last_Update_Date = Sysdate
     Where h.Month_Plan_Head_Id = p_Month_Head_Id;
     Commit;

    Begin
      --获取预测取价引APS语义信息
      v_Value := '获取预测取价引APS语义信息';
      Pkg_Pol_Cal.p_Get_Entity_Semantic('预测取价引APS', --语义编码
                                        r_Stp_Month_Plan_Head.Entity_Id,
                                        s_Semantic_Type, --语义类型：SQL取值、计算公式
                                        v_Get_Price_Sql, --取值SQL
                                        s_Pre_Proc_Sql, --预处理SQL
                                        s_Query_Code, --查询条件编码
                                        s_Freeze_Query_Code, --冻结明细查询条件编码
                                        v_Message);
      If v_Message <> 'OK' Then
        p_Result := v_Message;
        Raise v_Base_Exception;
      End If;
    Exception
      When Others Then
        p_Result := v_Value || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;

    Begin
      --获取预测取未满足量语义信息
      v_Value := '获取预测取未满足量语义信息';
      Pkg_Pol_Cal.p_Get_Entity_Semantic('预测取未满足量', --语义编码
                                        r_Stp_Month_Plan_Head.Entity_Id,
                                        s_Semantic_Type, --语义类型：SQL取值、计算公式
                                        v_Get_Unsatisfied_Qty_Sql, --取值SQL
                                        s_Pre_Proc_Sql, --预处理SQL
                                        s_Query_Code, --查询条件编码
                                        s_Freeze_Query_Code, --冻结明细查询条件编码
                                        v_Message);
      If v_Message <> 'OK' Then
        p_Result := v_Message;
        Raise v_Base_Exception;
      End If;
    Exception
      When Others Then
        p_Result := v_Value || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;

    Begin
      --获取预测取开单未发量语义信息
      v_Value := '获取预测取开单未发量语义信息';
      Pkg_Pol_Cal.p_Get_Entity_Semantic('预测取开单未发量', --语义编码
                                        r_Stp_Month_Plan_Head.Entity_Id,
                                        s_Semantic_Type, --语义类型：SQL取值、计算公式
                                        v_Get_Undelivered_Qty_Sql, --取值SQL
                                        s_Pre_Proc_Sql, --预处理SQL
                                        s_Query_Code, --查询条件编码
                                        s_Freeze_Query_Code, --冻结明细查询条件编码
                                        v_Message);
      If v_Message <> 'OK' Then
        p_Result := v_Message;
        Raise v_Base_Exception;
      End If;
    Exception
      When Others Then
        p_Result := v_Value || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;

    Begin
      --获取预测取库存语义信息
      v_Value := '获取预测取库存语义信息';
      Pkg_Pol_Cal.p_Get_Entity_Semantic('预测取库存', --语义编码
                                        r_Stp_Month_Plan_Head.Entity_Id,
                                        s_Semantic_Type, --语义类型：SQL取值、计算公式
                                        v_Get_Current_Stock_Sql, --取值SQL
                                        s_Pre_Proc_Sql, --预处理SQL
                                        s_Query_Code, --查询条件编码
                                        s_Freeze_Query_Code, --冻结明细查询条件编码
                                        v_Message);
      If v_Message <> 'OK' Then
        p_Result := v_Message;
        Raise v_Base_Exception;
      End If;
    Exception
      When Others Then
        p_Result := v_Value || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;

    --更新老品编码
    Update t_Stp_Month_Plan_Lines l
       Set (l.Old_Item_Id, l.Old_Item_Code, l.Old_Item_Name) =
           (Select T2.Item_Id, T2.Item_Code, T2.Item_Name
              From t_Bd_Item T1, t_Bd_Item T2
             Where T1.Entity_Id = T2.Entity_Id
               And T1.Entity_Id = l.Entity_Id
               And T1.Item_Id = l.Item_Id
               And ((T1.Source_Item_Code Is Not Null And
                   T1.Source_Item_Code = T2.Item_Code) Or
                   (T1.Source_Item_Code Is Null And T1.Item_Id = T2.Item_Id)))
     Where l.Month_Plan_Head_Id = p_Month_Head_Id;

    --开始更新数据
    If p_Result = v_Success Then
      v_Update_Sql := 'Update t_Stp_Month_Plan_Lines mpl Set mpl.To_Aps_Price = Nvl((' ||
                      v_Get_Price_Sql ||
                      '),0),Mpl.Unsatisfied_Qty    = Nvl((' ||
                      v_Get_Unsatisfied_Qty_Sql ||
                      '),0),Mpl.Undelivered_Qty    = Nvl((' ||
                      v_Get_Undelivered_Qty_Sql ||
                      '),0),Mpl.Current_Stock_Cims = Nvl((' ||
                      v_Get_Current_Stock_Sql ||
                      '),0) Where Mpl.Month_Plan_Head_Id = :1';
      --执行更新脚本
      Begin
        Execute Immediate v_Update_Sql
          Using p_Month_Head_Id;
      Exception
        When Others Then
          p_Result := '更新预测行上的引aps单价、库存、开单未提、未满足数失败！' || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
      End;
      Commit;
    End If;
    
    --add by houhs at 20191024 获取系统参数，来判断是否
    
    IF p_Result = v_Success THEN
       --查询系统参数
       BEGIN
          v_value := '获取存销比控制预测报送参数';
          PKG_BD.P_GET_PARAMETER_VALUE('PLN_STP_SKU_RATIO',
                                       r_Stp_Month_Plan_Head.ENTITY_ID,
                                       Null,
                                       Null,
                                       v_Ratio_Flag);
       EXCEPTION
         WHEN OTHERS THEN
           p_Result := v_Value || '失败。' || v_nl || SQLERRM;
        Raise v_Base_Exception;
       END;
     END IF;
     
     --按SKU存销比控制预测报送 add by houhs at 20191024 
     IF p_Result = v_Success THEN
        IF nvl(v_Ratio_Flag,'N') = 'Y' THEN
         
           --获取当月剩余天数比例
           IF p_Result = v_Success THEN
             BEGIN
            v_value := '获取当月剩余天数比例';
             SELECT (1 - (to_number(to_char(trunc(SYSDATE), 'DD'))-1) /
                    to_number(to_char(last_day(trunc(SYSDATE)), 'DD'))) Month_Ratio
                 INTO v_Month_Ratio   
               from dual;
               EXCEPTION
                  WHEN OTHERS THEN
                    p_Result := v_Value || '失败。' || V_NL || SQLERRM;
                     Raise v_Base_Exception;
              END;
            END IF;
            
            --获取当月剩余天数比例
           IF p_Result = v_Success THEN
            BEGIN
            v_value := '获取当月份';
            SELECT to_number(to_char(trunc(SYSDATE), 'MM')) 
                   INTO v_Current_Month
            from dual;
               EXCEPTION
                  WHEN OTHERS THEN
                    p_Result := v_Value || '失败。' || V_NL || SQLERRM;
                 Raise v_Base_Exception;
              END;
            END IF;
            
            
            --获取配置系数
           IF p_Result = v_Success THEN
            BEGIN
            v_value := '获取配置系数';
             PKG_BD.P_GET_PARAMETER_VALUE('PLN_SKU_RATIO_CONFIG',
                                       r_Stp_Month_Plan_Head.ENTITY_ID,
                                       Null,
                                       Null,
                                       v_Ratio_Config);
               EXCEPTION
                  WHEN OTHERS THEN
                    p_Result := v_Value || '失败。' || V_NL || SQLERRM;
                 Raise v_Base_Exception;
              END;
            END IF;
        

          --单行处理数据
        open c_Stp_Month_Plan_line;
        loop
          fetch c_Stp_Month_Plan_line
            into r_Stp_Month_Plan_line;
          exit when c_Stp_Month_Plan_line%notfound or p_Result <> v_Success;  
          
          --获取当前渠道库存
          IF p_Result = v_Success THEN
           BEGIN
            v_value := '获取当前渠道库存';
             Select Sum(Pc.Bill_Qty) Bill_Qty
               INTO v_Current_Stock_Ccs
               From Cims.Intf_Pol_Inv_Current Pc
              Where Pc.Entity_Id = r_Stp_Month_Plan_line.Entity_Id
                And Pc.Inv_Type = '正品仓'
                And Pc.Inv_Date >= Sysdate - 2
                And Pc.Item_Code = r_Stp_Month_Plan_line.Item_Code;
              EXCEPTION
                WHEN OTHERS THEN
                   v_Current_Stock_Ccs := 0;
            END;
          END IF;
          
          --获取CCS本月已分销数据
          IF p_Result = v_Success THEN
            BEGIN
            v_value := '获取CCS本月已分销数据';
               Select Sum(Pc.Bill_Qty) Bill_Qty
               INTO v_Monthly_Sales_Ccs
               From Cims.Intf_Pol_Out_Bill_Confirm Pc
              Where To_Char(Pc.Confirm_Date, 'YYYY-MM') =
                    To_Char(Sysdate, 'YYYY-MM')
                And Pc.Entity_Id = r_Stp_Month_Plan_line.Entity_Id
                And Pc.Item_Code = r_Stp_Month_Plan_line.Item_Code;
              EXCEPTION
                WHEN OTHERS THEN
                 v_Monthly_Sales_Ccs := 0;
            END;
          END IF;
          
          --获取当前结转T+3订单未入库数
          IF p_Result = v_Success THEN
            BEGIN
            v_value := '获取当前结转T+3订单未入库数';
             Select Sum(NVL(Tl.Can_Produce_Qty, 0) - NVL(Tl.Supply_Qty，0)) T3_Not_Inv_In
               INTO v_T3_Not_Inv_In
               From Cims.t_Pln_Order_Head Th, Cims.t_Pln_Order_Line Tl
              Where Th.Order_Head_Id = Tl.Order_Head_Id
                And Th.Entity_Id = r_Stp_Month_Plan_line.Entity_Id
                And Tl.Item_Code = r_Stp_Month_Plan_line.Item_Code
                And Th.Order_Type_Name = 'T+3订单'
                And Th.Form_State = '32'
                And Th.Creation_Date >= Sysdate - 60;
              EXCEPTION
                WHEN OTHERS THEN
                 v_T3_Not_Inv_In := 0;
            END;
          END IF;
          
          --获取后续预计分销、M月底全渠道库存、M+1月存销比、M+2月存销比、M+3月存销比
          IF p_Result = v_Success THEN
            BEGIN
            v_value := '获取后续预计分销、M月底全渠道库存、M+1月存销比、M+2月存销比、M+3月存销比';
            v_Monthly_Sales_Ccs_After := NVL(v_Monthly_Sales_Ccs,0)*NVL(v_Month_Ratio,0)*NVL(v_Ratio_Config,1.5);
            v_Eom_Stock_Ccs_All := NVL(v_Current_Stock_Ccs,0)+NVL(r_Stp_Month_Plan_line.Current_Stock_Cims,0) +NVL(v_T3_Not_Inv_In,0)-NVL(v_Monthly_Sales_Ccs_After,0);
            IF r_Stp_Month_Plan_line.M1_Month_Require_Qty IS NOT NULL AND r_Stp_Month_Plan_line.M1_Month_Require_Qty <> 0 THEN
              v_M1_Sku_Ratio := NVL(v_Eom_Stock_Ccs_All,0)/NVL(r_Stp_Month_Plan_line.M1_Month_Require_Qty,0);
            ELSE
              v_M1_Sku_Ratio := 0;
            END IF;
            IF r_Stp_Month_Plan_line.M2_Month_Require_Qty IS NOT NULL AND r_Stp_Month_Plan_line.M2_Month_Require_Qty <> 0 THEN
              v_M2_Sku_Ratio := NVL(v_Eom_Stock_Ccs_All,0)/NVL(r_Stp_Month_Plan_line.M2_Month_Require_Qty,0);
            ELSE
              v_M2_Sku_Ratio := 0;
            END IF;
            IF r_Stp_Month_Plan_line.M3_Month_Require_Qty IS NOT NULL AND r_Stp_Month_Plan_line.M3_Month_Require_Qty <> 0 THEN
              v_M3_Sku_Ratio := NVL(v_Eom_Stock_Ccs_All,0)/NVL(r_Stp_Month_Plan_line.M3_Month_Require_Qty,0);
            ELSE
              v_M3_Sku_Ratio := 0;
            END IF;
              EXCEPTION
                WHEN OTHERS THEN
                  p_Result := v_Value || '失败。' || V_NL || SQLERRM;
               Raise v_Base_Exception;
            END;
          END IF;
          
          --获取M+1月存销比、需求修正
          IF p_Result = v_Success THEN
            IF v_Current_Month+1 < 10 THEN
              v_Month_Ratio_Get := 'MONTH_RATIO_0' || to_char(v_Current_Month+1);
            ELSIF v_Current_Month+1 >= 10 And v_Current_Month+1 <= 12 THEN
              v_Month_Ratio_Get := 'MONTH_RATIO_' || to_char(v_Current_Month+1);
            ELSE 
              v_Month_Ratio_Get := 'MONTH_RATIO_0' || to_char(v_Current_Month-11);
            END IF;
            BEGIN
            v_value := '获取M+1月存销比';
            v_Select_Sql := 'Select Tr.' || v_Month_Ratio_Get 
                || ' From Cims.t_Stp_Sku_Ratio Tr Where  Tr.Entity_Id = ' || r_Stp_Month_Plan_line.Entity_Id
                || '  And Tr.Item_Code =  ''' || r_Stp_Month_Plan_line.Item_Code || '''';

                BEGIN EXECUTE IMMEDIATE v_Select_Sql INTO v_M1_Sku_Ratio_Standard;  
                 EXCEPTION
                WHEN OTHERS THEN
                  v_M1_Sku_Ratio_Standard := 0;
               END; 
             END; 
          END IF;
          
          IF p_Result = v_Success THEN
            v_value := '获取M+1月需求修正';
            IF NVL(v_M1_Sku_Ratio,0) >= NVL(v_M1_Sku_Ratio_Standard,0) THEN
              v_M1_Sku_Require_Qty_Edit := 0;
            ELSE 
              v_M1_Sku_Require_Qty_Edit := (NVL(v_M1_Sku_Ratio_Standard,0) - NVL(v_M1_Sku_Ratio,0))*NVL(r_Stp_Month_Plan_line.M1_Month_Require_Qty,0);
            END IF;
          END IF;
          
          
          --获取M+2月存销比、需求修正
          IF p_Result = v_Success THEN
            IF v_Current_Month+2 < 10 THEN
              v_Month_Ratio_Get := 'MONTH_RATIO_0' || to_char(v_Current_Month+2);
            ELSIF v_Current_Month+2 >= 10 And v_Current_Month+2 <= 12 THEN
              v_Month_Ratio_Get := 'MONTH_RATIO_' || to_char(v_Current_Month+2);
            ELSE 
              v_Month_Ratio_Get := 'MONTH_RATIO_0' || to_char(v_Current_Month-10);
            END IF;
            BEGIN
            v_value := '获取M+2月存销比';
               v_Select_Sql := 'Select Tr.' || v_Month_Ratio_Get 
                || ' From Cims.t_Stp_Sku_Ratio Tr Where  Tr.Entity_Id = ' || r_Stp_Month_Plan_line.Entity_Id
                || '  And Tr.Item_Code = ''' || r_Stp_Month_Plan_line.Item_Code || '''';

                BEGIN EXECUTE IMMEDIATE v_Select_Sql INTO v_M2_Sku_Ratio_Standard;  
                 EXCEPTION
                WHEN OTHERS THEN
                  v_M2_Sku_Ratio_Standard := 0;
               END; 
            END; 
          END IF;
          
          IF p_Result = v_Success THEN
            v_value := '获取M+2月需求修正';
            IF NVL(v_M2_Sku_Ratio,0) >= NVL(v_M2_Sku_Ratio_Standard,0) THEN
              v_M2_Sku_Require_Qty_Edit := 0;
            ELSE  
              v_M2_Sku_Require_Qty_Edit := (NVL(v_M2_Sku_Ratio_Standard,0) - NVL(v_M2_Sku_Ratio,0))*NVL(r_Stp_Month_Plan_line.M2_Month_Require_Qty,0);
            END IF;
          END IF;
          
          
          
          --获取M+3月存销比、需求修正
          IF p_Result = v_Success THEN
            IF v_Current_Month+3 < 10 THEN
              v_Month_Ratio_Get := 'MONTH_RATIO_0' || to_char(v_Current_Month+3);
            ELSIF v_Current_Month+3 >= 10 And v_Current_Month+3 <= 12 THEN
              v_Month_Ratio_Get := 'MONTH_RATIO_' || to_char(v_Current_Month+3);
            ELSE 
              v_Month_Ratio_Get := 'MONTH_RATIO_0' || to_char(v_Current_Month-9);
            END IF;
            BEGIN
            v_value := '获取M+3月存销比';
            v_Select_Sql := 'Select Tr.' || v_Month_Ratio_Get 
                || ' From Cims.t_Stp_Sku_Ratio Tr Where  Tr.Entity_Id = ' || r_Stp_Month_Plan_line.Entity_Id
                || '  And Tr.Item_Code = ''' || r_Stp_Month_Plan_line.Item_Code  || '''';

                BEGIN EXECUTE IMMEDIATE v_Select_Sql INTO v_M3_Sku_Ratio_Standard;  
                 EXCEPTION
                   WHEN OTHERS THEN
                     v_M3_Sku_Ratio_Standard := 0;
               END; 
             END; 
          END IF;
          
          IF p_Result = v_Success THEN
            v_value := '获取M+3月需求修正';
            IF NVL(v_M3_Sku_Ratio,0) >= NVL(v_M3_Sku_Ratio_Standard,0) THEN
              v_M3_Sku_Require_Qty_Edit := 0;
            ELSE 
              v_M3_Sku_Require_Qty_Edit := (NVL(v_M3_Sku_Ratio_Standard,0) - NVL(v_M3_Sku_Ratio,0))*NVL(r_Stp_Month_Plan_line.M1_Month_Require_Qty,0);
            END IF;
           END IF;
          
          IF p_Result = v_Success THEN
            BEGIN
              v_value := '更新预测计划行信息';
               UPDATE t_Stp_Month_Plan_Lines tl
                 SET tl.Current_Stock_Ccs         = v_Current_Stock_Ccs, --获取当前渠道库存
                     tl.Current_Stock_Ccs_All     = v_Current_Stock_Ccs + NVL(r_Stp_Month_Plan_line.Current_Stock_Cims,0), --当前全渠道库存
                     tl.Monthly_Sales_Ccs         = v_Monthly_Sales_Ccs, --CCS本月已分销
                     tl.T3_Not_Inv_In             = v_T3_Not_Inv_In, --当前结转T+3订单未入库数
                     tl.Monthly_Sales_Ccs_After   = v_Monthly_Sales_Ccs_After, --后续预计分销
                     tl.Eom_Stock_Ccs_All         = v_Eom_Stock_Ccs_All, --M月底全渠道库存
                     tl.M1_Sku_Ratio              = v_M1_Sku_Ratio, --M+1月存销比
                     tl.M1_Sku_Ratio_Standard     = v_M1_Sku_Ratio_Standard, --M+1月标准存销比
                     tl.M1_Month_Require_Qty_Edit = v_M1_Sku_Require_Qty_Edit, --M+1月需求修正
                     tl.M2_Sku_Ratio              = v_M2_Sku_Ratio, --M+2月存销比
                     tl.M2_Sku_Ratio_Standard     = v_M2_Sku_Ratio_Standard, --M+2月标准存销比
                     tl.M2_Month_Require_Qty_Edit = v_M2_Sku_Require_Qty_Edit, --M+2月需求修正
                     tl.M3_Sku_Ratio              = v_M3_Sku_Ratio, --M+3月存销比
                     tl.M3_Sku_Ratio_Standard     = v_M3_Sku_Ratio_Standard, --M+3月标准存销比
                     tl.M3_Month_Require_Qty_Edit = v_M3_Sku_Require_Qty_Edit, --M+3月需求修正
                     tl.M1_Expected_Stock_Qty     = tl.M1_MONTH_REQUIRE_QTY, --M+1月预计出库
                     tl.M1_Eom_Stock_Ccs_All      = v_Eom_Stock_Ccs_All + v_M1_Sku_Require_Qty_Edit - NVL(tl.M1_MONTH_REQUIRE_QTY,0), --M+1月底全渠道库存
                     tl.M2_Expected_Stock_Qty     = tl.M2_Month_Require_Qty, --M+2月预计出库
                     tl.M2_Eom_Stock_Ccs_All      = v_Eom_Stock_Ccs_All + v_M1_Sku_Require_Qty_Edit -NVL(tl.M1_MONTH_REQUIRE_QTY,0) + v_M2_Sku_Require_Qty_Edit - NVL(tl.M2_Month_Require_Qty,0) --M+2月底全渠道库存
               WHERE tl.month_plan_line_id = r_Stp_Month_Plan_line.Month_Plan_Line_Id;
            EXCEPTION
                WHEN OTHERS THEN
                  p_Result := v_Value || '失败。' || V_NL || SQLERRM;
               Raise v_Base_Exception;
            END;
           END IF;
          
         end loop; --行数据循环结束

        END IF;
      END IF;
    

    --更新预测头上计算结果
    If p_Result = v_Success Then
      Update t_Stp_Month_Plan_Head h
         Set h.Calculate_Reslut = 'SUCCESS',
             h.Last_Update_Date = Sysdate,
             h.calculate_end_time = Sysdate,
             h.Version          = Nvl(h.Version, 0) + 1
       Where h.Month_Plan_Head_Id = p_Month_Head_Id;
    End If;

  Exception
    When v_Base_Exception Then
      Rollback;
      p_Result := p_Result ||
                  Substr(Dbms_Utility.Format_Error_Backtrace, 1, 200);
      --更新报错信息
      Update t_Stp_Month_Plan_Head h
         Set h.Calculate_Reslut = Substr(p_Result, 1, 3500),
             h.Last_Update_Date = Sysdate,
             h.calculate_end_time = Sysdate,
             h.Version          = Nvl(h.Version, 0) + 1
       Where h.Month_Plan_Head_Id = p_Month_Head_Id;
      Commit;
  End p_Calculate_Monthplan;
  -----------------------------------------------------------------------------
  -- AUTHOR  : lilh6
  -- CREATED : 2018-10-18
  -- PURPOSE : 月预测产品生命周期检查                          
  ------------------------------------------------------------------------------------       
  Procedure p_Mon_Chk_Item_Prdc_Life_Cycle(p_Month_Head_Id In Number, --头ID
                                           p_Order_Phase   In Varchar2, --订单检查阶段
                                           p_Result        Out Varchar2 --返回结果
                                           ) Is
    v_Value               Varchar2(1000);
    v_Item_Life_Cycle     Varchar2(10);
    r_Stp_Month_Plan_Head t_Stp_Month_Plan_Head%Rowtype; --月预测
    v_Producing_Area_Id   Number;
    v_Message             Varchar2(4000);
    v_is_producing_area  varchar2(32);
  
  Begin
    p_Result := v_Success;
    Begin
      v_Value := '没有查询到有效数据,获取月计划失败!';
      Select *
        Into r_Stp_Month_Plan_Head
        From t_Stp_Month_Plan_Head h
       Where h.Month_Plan_Head_Id = p_Month_Head_Id;
    Exception
      When Others Then
        p_Result := v_Value;
        Raise v_Base_Exception;
    End;
    --获取系统参数，释放检查生命周期
    Begin
      v_Value           := '获取PLN_ITEM_LIFE_CYCLE参数失败!';
      v_Item_Life_Cycle := Pkg_Bd.f_Get_Parameter_Value('PLN_ITEM_LIFE_CYCLE',
                                                        r_Stp_Month_Plan_Head.Entity_Id);
    Exception
      When Others Then
        p_Result := v_Value;
        Raise v_Base_Exception;
    End;
    --获取系统参数，判断行上是否有产地
    Begin
      v_Value           := '获取PLN_STP_MONTH_PRODUCE参数失败!';
      v_is_producing_area := Pkg_Bd.f_Get_Parameter_Value('PLN_STP_MONTH_PRODUCE',
                                                        r_Stp_Month_Plan_Head.Entity_Id);
    Exception
      When Others Then
        p_Result := v_Value;
        Raise v_Base_Exception;
    End;
  
    If p_Result = v_Success And v_Item_Life_Cycle = 'Y'And v_is_producing_area = 'Y' Then
      For r_Lines In (Select *
                        From t_Stp_Month_Plan_Lines l
                       Where l.Month_Plan_Head_Id = p_Month_Head_Id) Loop
        Begin
          Select Pa.Producing_Area_Id
            Into v_Producing_Area_Id
            From t_Pln_Producing_Area Pa
           Where Pa.Producing_Area_Code = r_Lines.Producing_Area_Code
             And Pa.Entity_Id = r_Lines.Entity_Id;
          --调用函数，校验产品的生命周期
          v_Value := Null;
          v_Value := Pkg_Pln_Pub.p_Chk_Item_Prdc_Life_Cycle(r_Lines.Entity_Id,
                                                            r_Lines.Item_Id,
                                                            v_Producing_Area_Id,
                                                            --检查是否允许引入APS
                                                            p_Order_Phase,
                                                            --增加一个参数：月预测计划订单类型
                                                            'MONTH_PLAN');
          If v_Value != 'Y' Then
            --如果检测不通过则，抛出异常
            Raise v_Base_Exception;
          End If;
        Exception
          When Others Then
            p_Result := v_Value || '，按生命周期控制，不允许报送！';
            Raise v_Base_Exception;
        End;
      End Loop;
    End If;
  Exception
    When v_Base_Exception Then
      p_Result := '失败信息：' || p_Result || v_Nl || '系统提示：' || Sqlerrm;
  End p_Mon_Chk_Item_Prdc_Life_Cycle;
  
  -----------------------------------------------------------------------------
  -- AUTHOR  : lilh6
  -- CREATED : 2018-11-29
  -- PURPOSE : 没有客户的中心、总部预测取价                  
  ------------------------------------------------------------------------------------                              
 Procedure p_Get_Center_Item_Price(p_Sales_Center_Code In Varchar2, --中心编码
                                   p_Item_Code         In Varchar2, --产品编码
                                   p_Entity_Id         In Number, --主体id
                                   p_Price             Out Number, --返回价格
                                   p_Result            Out Varchar2 --返回结果
                                   ) Is
   v_Price_List_Id Number;
 
 Begin
   p_Result := v_Success;
   Begin
     --获取中心价格列表id
     Select Pso.Price_List_Id
       Into v_Price_List_Id
       From Cims.t_Bd_Price_System Ps, Cims.t_Bd_Price_System_Org Pso
      Where Ps.Price_System_Id = Pso.Price_System_Id
        And Ps.Entity_Id = p_Entity_Id
        And Ps.Price_Type = 'C'
        And Ps.Active_Flag = 'Y'
        And Pso.Sales_Center_Code = p_Sales_Center_Code
        And Sysdate Between Ps.Begin_Date And Nvl(Ps.End_Date, Sysdate);
   Exception
     When Others Then
       --中心价格列表获取不到，则获取价格体系上的价格列表
       Begin
         Select Ps.Bu_Price_List_Id
           Into v_Price_List_Id
           From Cims.t_Bd_Price_System Ps
          Where Ps.Entity_Id = p_Entity_Id
            And Ps.Price_Type = 'C'
            And Ps.Active_Flag = 'Y'
            And Sysdate Between Ps.Begin_Date And Nvl(Ps.End_Date, Sysdate);
       Exception
         When Others Then
           v_Price_List_Id := Null;
       End;
   End;
   --价格列表id不为空，表示成功获取到中心对应的价格列表，获取产品价格
   If v_Price_List_Id Is Not Null Then
     Begin
       Select l.List_Price
         Into p_Price
         From Cims.t_Bd_Price_Line l
        Where l.Price_List_Id = v_Price_List_Id
          And l.Item_Code = p_Item_Code
          And l.Begin_Date <= Sysdate
          And Nvl(l.End_Date, Sysdate) >= Sysdate
          And l.Active_Flag = 'Y';
     Exception
       When Others Then
         p_Price := Null;
     End;
   End If;
   --价格列表id为空或者价格为空，则取获取新品价格
   If v_Price_List_Id Is Null Or p_Price Is Null Then
     Begin
        Select t.Standard_Rate
          Into p_Price
          From t_Pln_Item_Property t
         Where t.Item_Code = p_Item_Code
           And t.New_Product_Flag = 'Y'
           And t.Entity_Id = p_Entity_Id;
      Exception
        When Others Then
          p_Price := Null;
      End;
   End If;
 Exception
   When v_Base_Exception Then
     p_Result := '获取中心价格失败。' || subStr(dbms_utility.format_error_backtrace,1,200) || v_Nl  || '系统提示：' || Sqlerrm;
 End p_Get_Center_Item_Price;
END PKG_PLN_MON;
/

