create view V_BD_USER_BILLTYPE_PRIV as
select distinct b."USER_ID",b."USER_CODE",b."USER_NAME",b."BILL_TYPE_ID",b."BILL_TYPE_CODE",b."BILL_TYPE_NAME",b."ENTITY_ID"
  from (select uu.user_id, --用户ID
               uu.account user_code, --用户编码
               uu.name user_name, --用户名称
               bt.bill_type_id, --单据类型ID
               bt.bill_type_code, --单据类型编码
               bt.bill_type_name, --单据类型名称
               et.entity_id --主体id
          from up_org_user uu,
               (select * from v_bd_bill_types) bt,
               (select u.unit_id entity_id,
                       u.code    entity_code,
                       u.name    entity_name
                  from up_org_unit u
                 where u.type_code = 'BU'
                   and u.active_flag = 'T') et
         where bt.entity_id = et.entity_id
        minus
        --用户独立授权的限制访问的单据类型
        select dbt.user_id,
               uu.account user_code,
               uu.name user_name,
               bt.bill_type_id, --单据类型ID
               bt.bill_type_code, --单据类型编码
               bt.bill_type_name, --单据类型名称
               dbt.entity_id
          from t_bd_datapriv_billtype dbt,
               v_bd_bill_types        bt,
               up_org_user            uu
         where dbt.billtype_id = bt.bill_type_id
           and dbt.user_id = uu.user_id
           and dbt.active_flag = 'Y' --有效记录
        ) b
/

