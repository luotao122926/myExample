create PACKAGE BODY      PKG_SO_INTF IS
  /*----------------------------------------------------------------
  *         包：PKG_SO_INTF
  *   创建日期：2014-09-16
  *     创建者：廖丽章
  *   功能说明：1、销售单据与外部系统对接相关业务处理。
  *
  *   过程成功：P_RESULT = 0
  *             P_ERR_MSG = 'SUCCESS';
  *
  *   过程失败：P_RESULT < -20000;
  *             P_ERR_MSG = 过程异常失败的提示信息
  *
  */
  ----------------------------------------------------------------
  V_RESULT  CONSTANT NUMBER := 0; --成功返回
  V_SUCCESS CONSTANT VARCHAR2(10) := 'SUCCESS';
  V_RETURNABLE_QTY NUMBER := 0; --可退货数量
  
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-09-17
  *     创建者：陈宇佳
  *   功能说明：子库接口转移
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_INV_TRANSFER(P_ENTITY_ID    IN NUMBER, --主体ID
                              P_SO_HEADER_ID IN NUMBER, --销售单据头ID
                              P_RESULT       OUT NUMBER, --返回错误ID
                              P_ERR_MSG      OUT VARCHAR2 --返回错误信息
                              ) IS
    --销售单据头信息游标
    CURSOR C_SO_HEADER IS
      SELECT *
        FROM T_SO_HEADER
       WHERE SO_HEADER_ID = P_SO_HEADER_ID
         AND ENTITY_ID = P_ENTITY_ID;
    --销售单据头信息记录
    R_SO_HEADER C_SO_HEADER%ROWTYPE;
  
    --销售单据行明细信息游标
    CURSOR C_SO_LINE_DETAIL IS
      SELECT *
        FROM T_SO_LINE_DETAIL
       WHERE SO_HEADER_ID = P_SO_HEADER_ID
         AND ENTITY_ID = P_ENTITY_ID;
    --销售单据行明细记录集
    R_SO_LINE_DETAIL C_SO_LINE_DETAIL%ROWTYPE;
  
    --库存组织编码
    V_INV_ORG_CODE T_INV_ORGANIZATION.ORGANIZATION_CODE%TYPE;
  
    --来源子库编码（仓库编码）
    V_SRC_INV_CODE T_INV_INVENTORIES.INVENTORY_CODE%TYPE;
  
    --目标子库编码
    V_TARGET_INV_CODE T_INV_INVENTORIES.INVENTORY_CODE%TYPE;
  
    --子库转移的事务处理类型
    V_TRANSACTION_TYPE VARCHAR2(80) := '2'; --'Subinventory Transfer';
  
    --仓库ID、编码、名称
    V_INV_ID   T_INV_INVENTORIES.INVENTORY_ID%TYPE;
    V_INV_CODE T_INV_INVENTORIES.INVENTORY_CODE%TYPE;
    V_INV_NAME T_INV_INVENTORIES.INVENTORY_NAME%TYPE;
  
    --子库转移头ID
    V_TRANS_HEAD_ID NUMBER;
    --接口编号
    V_DATA_SOURCE VARCHAR2(20) := 'ERP-IMS-023';
  
    --推拉式标记
    V_PUSH_OR_PULL VARCHAR2(50);
    
    --已经写入的子库转移次数
    V_SO_TRANSFER_COUNT NUMBER := 0;
    --当前操作是否为第二次子库转移
    V_IS_SECOND_TRANSFER VARCHAR2(2) := 'N';
    --是否可以直接做第二次子库转移
    V_IS_SECOND_TRANSFER_ENABLE VARCHAR2(2) := 'N';
    V_ICP_LG_RECEIVE_MODE              VARCHAR(32);
    --库存事务日期：第一步为单据日期；第二步为PO接收日期
    V_TRANSACTION_DATE INTF_INV_TRANSACTION.TRANSACTION_DATE%TYPE;
    V_INTF_SYSTEM_TYPE VARCHAR2(32);--财务接口对接系统标识 ERP：美的现有ERP系统；NC：用友NC财务系统。
  BEGIN
    P_RESULT  := V_RESULT;
    P_ERR_MSG := V_SUCCESS;
    
    PKG_BD.P_GET_PARAMETER_VALUE(PKG_SO_PUB.V_INTF_SYSTEM_TYPE,
                                 P_ENTITY_ID,
                                 NULL,
                                 NULL,
                                 V_INTF_SYSTEM_TYPE);

    IF(V_INTF_SYSTEM_TYPE = PKG_SO_PUB.V_INTF_SYSTEM_TYPE_NC) THEN
      RETURN;
    END IF;

    --获取销售单头信息
    OPEN C_SO_HEADER;
    FETCH C_SO_HEADER
      INTO R_SO_HEADER;
    CLOSE C_SO_HEADER;
    
    --库存事务日期默认为单据日期
    V_TRANSACTION_DATE := R_SO_HEADER.SO_DATE;
    
    --判断是否可以做第二次子库转移:存在第一次子库转移记录，物流签收标识为 Y，签收日期不为空  add by zhoujg3 2016-09-21
    SELECT COUNT(1)
      INTO V_SO_TRANSFER_COUNT
      FROM INTF_INV_TRANSACTION_HEAD H
     WHERE EXISTS (SELECT 1 FROM T_SO_HEADER SO
      WHERE H.ENTITY_ID = SO.ENTITY_ID AND H.ORDER_NUM = SO.SO_NUM AND SO.ENTITY_ID = P_ENTITY_ID AND SO.SO_HEADER_ID = P_SO_HEADER_ID);
  
    IF (V_SO_TRANSFER_COUNT >= 2) THEN
        P_ERR_MSG := '单据[' ||
                     R_SO_HEADER.SO_NUM || ']子库转移次数不可超过[2]次，请检查！';
        RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
    ELSIF (V_SO_TRANSFER_COUNT = 1) THEN
      IF (NVL(R_SO_HEADER.ERP_LOGIST_RECEIVE_FLAG,PKG_SO_PUB.V_NO) = PKG_SO_PUB.V_NO
            OR R_SO_HEADER.ERP_LOGIST_RECEIVE_DATE IS NULL) THEN
        P_ERR_MSG := '单据[' ||
                     R_SO_HEADER.SO_NUM || ']对应关联物流未签收确认，不可做第[2]次子库转移，请检查！';
        RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      END IF;
      
      --中间仓、未结算仓相同无需做CIMS库存事务、子库转移的第二步
      IF (NVL(R_SO_HEADER.ENTITY_CUST_FLAG,PKG_SO_PUB.V_NO) = PKG_SO_PUB.V_NO) THEN
        P_ERR_MSG := '单据[' || R_SO_HEADER.SO_NUM || ']对应的非内部关联交易客户[' || R_SO_HEADER.CUSTOMER_CODE || ',' || R_SO_HEADER.CUSTOMER_NAME 
          || ']无需做CIMS库存事务、子库转移的第二步，请核实！';
        RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      END IF;
      
      --中间仓、未结算仓相同无需做CIMS库存事务、子库转移的第二步
      IF (R_SO_HEADER.MIDDLE_INV_CODE = R_SO_HEADER.NOSETTLED_INVENTORY_CODE) THEN
        P_ERR_MSG := '单据[' || R_SO_HEADER.SO_NUM || ']的中间仓[' || R_SO_HEADER.MIDDLE_INV_CODE 
          || ']、未结算仓[' || R_SO_HEADER.NOSETTLED_INVENTORY_CODE 
          || ']相同无需做CIMS库存事务和子库转移的第二步，请核实！';
        RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      END IF;
      
      V_IS_SECOND_TRANSFER := PKG_SO_PUB.V_YES;
      
      --库存事务日期默认为单据日期
      V_TRANSACTION_DATE := R_SO_HEADER.ERP_LOGIST_RECEIVE_DATE;
    ELSIF (V_SO_TRANSFER_COUNT = 0) THEN
      V_IS_SECOND_TRANSFER := PKG_SO_PUB.V_NO;
      
      --内部客户
      IF (NVL(R_SO_HEADER.ENTITY_CUST_FLAG,PKG_SO_PUB.V_NO) = PKG_SO_PUB.V_YES) THEN
          BEGIN
             --根据供方业务主体、供方OU、需方客户 对应的'关联物流接收模式'； 
             SELECT T.ICP_LG_RECEIVE_MODE INTO V_ICP_LG_RECEIVE_MODE
                FROM T_SO_SUPPLIER_REQUIRE_ENTITY T
               WHERE T.SUPPLIER_ENTITY_ID = R_SO_HEADER.ENTITY_ID 
                  and T.SUPPLIER_OU_ID = R_SO_HEADER.ERP_OU_ID
                  and T.REQUIREMENT_CUSTOMER_ID = R_SO_HEADER.CUSTOMER_ID;           
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              P_ERR_MSG := '事业部客户[' || R_SO_HEADER.CUSTOMER_CODE || ',' || R_SO_HEADER.CUSTOMER_NAME || ']在供需关系T_SO_SUPPLIER_REQUIRE_ENTITY中未进行配置[ICP_LG_RECEIVE_MODE]！'
              || '主体[' || R_SO_HEADER.ENTITY_ID || '],OU[' || R_SO_HEADER.ERP_OU_ID || '],客户ID[' || R_SO_HEADER.CUSTOMER_ID || ']';
              RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
            WHEN OTHERS THEN
              P_ERR_MSG := '事业部客户[' || R_SO_HEADER.CUSTOMER_CODE || ','  || R_SO_HEADER.CUSTOMER_NAME || ']在供需关系T_SO_SUPPLIER_REQUIRE_ENTITY中未进行配置[ICP_LG_RECEIVE_MODE]！' 
              || '主体[' || R_SO_HEADER.ENTITY_ID || '],OU[' || R_SO_HEADER.ERP_OU_ID || '],客户ID[' || R_SO_HEADER.CUSTOMER_ID || ']' || SQLERRM;
              RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
          END;
          
          --销售红冲单、退货单、退货红冲单可直接更新关联物流对应PO签收信息
          IF (R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE = PKG_SO_PUB.V_BIZ_SRC_BILL_RETURN
                OR R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE = PKG_SO_PUB.V_BIZ_SRC_BILL_SO_RED
                OR R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE = PKG_SO_PUB.V_BIZ_SRC_BILL_RETURN_RED) THEN
              UPDATE T_SO_HEADER H
                SET H.ERP_LOGIST_RECEIVE_FLAG = PKG_SO_PUB.V_YES,
                    H.ERP_LOGIST_RECEIVE_DATE = TRUNC(SYSDATE)
              WHERE H.ENTITY_ID = P_ENTITY_ID
                AND H.SO_HEADER_ID = P_SO_HEADER_ID;
              
              V_IS_SECOND_TRANSFER_ENABLE := PKG_SO_PUB.V_YES;
          END IF;
      END IF;
    END IF;
  
    BEGIN
      V_PUSH_OR_PULL := R_SO_HEADER.TRX_MODE;  
      IF V_PUSH_OR_PULL IS NULL THEN           
        PKG_BD.P_GET_PARAMETER_VALUE(PKG_SO_PUB.V_ARG_SO_AR_PUSH_OR_PULL,
                                     R_SO_HEADER.ENTITY_ID,
                                     NULL,
                                     NULL,
                                     V_PUSH_OR_PULL);
      END IF;                                   
    EXCEPTION
      WHEN OTHERS THEN
        P_ERR_MSG := 'SO_AR_PUSH_OR_PULL主体参数,主体id:' ||
                     R_SO_HEADER.ENTITY_ID || '的参数设置异常，请检查。' || SQLERRM;
        RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
    END;
    /*
               单据类型       来源子库    目标子库
    外部客户   销售单         发货仓      中间仓  
    外部客户   销售红冲单     中间仓      发货仓  
    外部客户   退货单         中间仓      收货仓  
    外部客户   退货红冲单     收货仓      中间仓
	                          
               单据类型       来源子库    目标子库
    内部客户   销售单(1)      发货仓      中间仓  
    内部客户   销售单(2)      中间仓      未结仓  
    内部客户   销售红冲单(1)  未结仓      中间仓  
    内部客户   销售红冲单(2)  中间仓      发货仓  
    内部客户   退货单(1)      未结仓      中间仓  
    内部客户   退货单(2)      中间仓      收货仓  
    内部客户   退货红冲单(1)  收货仓      中间仓	
    内部客户   退货红冲单(2)  中间仓      未结仓
    */
    IF (NVL(R_SO_HEADER.ENTITY_CUST_FLAG,PKG_SO_PUB.V_NO) = PKG_SO_PUB.V_NO) THEN --外部普通客户
      IF (R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE = PKG_SO_PUB.V_BIZ_SRC_BILL_SO) THEN
        --销售单据
        V_INV_ID          := R_SO_HEADER.SHIP_INV_ID;
        V_INV_CODE        := R_SO_HEADER.SHIP_INV_CODE;
        V_INV_NAME        := R_SO_HEADER.SHIP_INV_NAME;

        --第一次子库转移：发出仓->中间仓
        V_SRC_INV_CODE    := R_SO_HEADER.SHIP_INV_CODE; --发货正品仓
        V_TARGET_INV_CODE := R_SO_HEADER.MIDDLE_INV_CODE; --发货商品仓
      ELSIF (R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE =
            PKG_SO_PUB.V_BIZ_SRC_BILL_SO_RED) THEN
        --销售红冲单
        V_INV_ID          := R_SO_HEADER.MIDDLE_INV_ID;
        V_INV_CODE        := R_SO_HEADER.MIDDLE_INV_CODE;
        V_INV_NAME        := R_SO_HEADER.MIDDLE_INV_NAME;

        --子库转移：中间仓->发出仓
        V_SRC_INV_CODE    := R_SO_HEADER.MIDDLE_INV_CODE; 
        V_TARGET_INV_CODE := R_SO_HEADER.SHIP_INV_CODE;
      ELSIF (R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE =
            PKG_SO_PUB.V_BIZ_SRC_BILL_RETURN) THEN
        --退货单 
        V_INV_ID          := R_SO_HEADER.MIDDLE_INV_ID;
        V_INV_CODE        := R_SO_HEADER.MIDDLE_INV_CODE;
        V_INV_NAME        := R_SO_HEADER.MIDDLE_INV_NAME;

        --子库转移：中间仓->收货仓
        V_SRC_INV_CODE    := R_SO_HEADER.MIDDLE_INV_CODE;
        V_TARGET_INV_CODE := R_SO_HEADER.CONSIGNEE_INV_CODE;
      ELSIF (R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE =
            PKG_SO_PUB.V_BIZ_SRC_BILL_RETURN_RED) THEN
        --退货红冲单
        V_INV_ID          := R_SO_HEADER.CONSIGNEE_INV_ID;
        V_INV_CODE        := R_SO_HEADER.CONSIGNEE_INV_CODE;
        V_INV_NAME        := R_SO_HEADER.CONSIGNEE_INV_NAME;

        --子库转移：收货仓->中间仓
        V_SRC_INV_CODE    := R_SO_HEADER.CONSIGNEE_INV_CODE;
        V_TARGET_INV_CODE := R_SO_HEADER.MIDDLE_INV_CODE;
      ELSE
        P_ERR_MSG := R_SO_HEADER.BILL_TYPE_NAME || '[' || R_SO_HEADER.SO_NUM ||']不需要进行子库转移！';
        RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      END IF;
    ELSIF (R_SO_HEADER.ENTITY_CUST_FLAG = PKG_SO_PUB.V_YES) THEN --内部关联交易客户
      IF (R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE = PKG_SO_PUB.V_BIZ_SRC_BILL_SO) THEN
        --销售单据
        V_INV_ID          := R_SO_HEADER.SHIP_INV_ID;
        V_INV_CODE        := R_SO_HEADER.SHIP_INV_CODE;
        V_INV_NAME        := R_SO_HEADER.SHIP_INV_NAME;

        IF (V_IS_SECOND_TRANSFER = PKG_SO_PUB.V_YES) THEN
          --第二次子库转移：中间仓->未结算仓
          V_SRC_INV_CODE    := R_SO_HEADER.MIDDLE_INV_CODE; 
          V_TARGET_INV_CODE := R_SO_HEADER.NOSETTLED_INVENTORY_CODE;
        ELSE
          --第一次子库转移：发出仓->中间仓
          V_SRC_INV_CODE    := R_SO_HEADER.SHIP_INV_CODE; --发货正品仓
          V_TARGET_INV_CODE := R_SO_HEADER.MIDDLE_INV_CODE; --发货商品仓
        END IF;
      ELSIF (R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE =
            PKG_SO_PUB.V_BIZ_SRC_BILL_SO_RED) THEN
        --销售红冲单
        V_INV_ID          := R_SO_HEADER.MIDDLE_INV_ID;
        V_INV_CODE        := R_SO_HEADER.MIDDLE_INV_CODE;
        V_INV_NAME        := R_SO_HEADER.MIDDLE_INV_NAME;

        IF (V_IS_SECOND_TRANSFER = PKG_SO_PUB.V_YES) THEN
          --第二次子库转移：中间仓->发出仓
          V_SRC_INV_CODE    := R_SO_HEADER.MIDDLE_INV_CODE; 
          V_TARGET_INV_CODE := R_SO_HEADER.SHIP_INV_CODE;
        ELSE
          --第一次子库转移：未结算仓->中间仓
          V_SRC_INV_CODE    := R_SO_HEADER.NOSETTLED_INVENTORY_CODE;
          V_TARGET_INV_CODE := R_SO_HEADER.MIDDLE_INV_CODE;
        END IF;
      ELSIF (R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE =
            PKG_SO_PUB.V_BIZ_SRC_BILL_RETURN) THEN
        --退货单 
        V_INV_ID          := R_SO_HEADER.MIDDLE_INV_ID;
        V_INV_CODE        := R_SO_HEADER.MIDDLE_INV_CODE;
        V_INV_NAME        := R_SO_HEADER.MIDDLE_INV_NAME;

        IF (V_IS_SECOND_TRANSFER = PKG_SO_PUB.V_YES) THEN
          --第二次子库转移：中间仓->收货仓
          V_SRC_INV_CODE    := R_SO_HEADER.MIDDLE_INV_CODE;
          V_TARGET_INV_CODE := R_SO_HEADER.CONSIGNEE_INV_CODE;
        ELSE
          --第一次子库转移：未结算仓->中间仓
          V_SRC_INV_CODE    := R_SO_HEADER.NOSETTLED_INVENTORY_CODE;
          V_TARGET_INV_CODE := R_SO_HEADER.MIDDLE_INV_CODE;
        END IF;
      ELSIF (R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE =
            PKG_SO_PUB.V_BIZ_SRC_BILL_RETURN_RED) THEN
        --退货红冲单
        V_INV_ID          := R_SO_HEADER.CONSIGNEE_INV_ID;
        V_INV_CODE        := R_SO_HEADER.CONSIGNEE_INV_CODE;
        V_INV_NAME        := R_SO_HEADER.CONSIGNEE_INV_NAME;

        IF (V_IS_SECOND_TRANSFER = PKG_SO_PUB.V_YES) THEN
          --第二次子库转移：中间仓->未结算仓
          V_SRC_INV_CODE    := R_SO_HEADER.MIDDLE_INV_CODE; 
          V_TARGET_INV_CODE := R_SO_HEADER.NOSETTLED_INVENTORY_CODE;
        ELSE
          --第一次子库转移：收货仓->中间仓
          V_SRC_INV_CODE    := R_SO_HEADER.CONSIGNEE_INV_CODE;
          V_TARGET_INV_CODE := R_SO_HEADER.MIDDLE_INV_CODE;
        END IF;
      ELSE
        P_ERR_MSG := R_SO_HEADER.BILL_TYPE_NAME || '[' || R_SO_HEADER.SO_NUM ||']不需要进行子库转移！';
        RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      END IF;
    ELSE
      P_ERR_MSG := '单据[' || R_SO_HEADER.SO_NUM || ']的事业部标识[' || R_SO_HEADER.ENTITY_CUST_FLAG ||']有误，请核实！';
      RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
    END IF;
    
    IF (V_SRC_INV_CODE IS NULL) THEN
      P_ERR_MSG := '单据[' || R_SO_HEADER.SO_NUM || ']子库转移的来源仓不可为空！';
      RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
    END IF;
  
    IF (V_TARGET_INV_CODE IS NULL) THEN
      P_ERR_MSG := '单据[' || R_SO_HEADER.SO_NUM || ']子库转移的目标仓不可为空！';
      RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
    END IF;
  
    BEGIN
      --获取ERP OU ID、ERP OU名称、ERP子库ID、ERP子库编码、
      SELECT INV_ORG.ORGANIZATION_CODE --仓库对应的库存组织编码
        INTO V_INV_ORG_CODE
        FROM T_INV_INVENTORIES INV, T_INV_ORGANIZATION INV_ORG
       WHERE INV.ORGANIZATION_ID = INV_ORG.ORGANIZATION_ID
         AND INV.ORGANIZATION_CODE = INV_ORG.ORGANIZATION_CODE
         AND INV.ENTITY_ID = INV_ORG.ENTITY_ID
         AND INV.INVENTORY_ID = V_INV_ID
         AND INV.ENTITY_ID = R_SO_HEADER.ENTITY_ID
         AND ROWNUM = 1;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        P_ERR_MSG := '仓库[' || V_INV_CODE || '|' || V_INV_NAME ||
                     ']未设置对应的库存组织！';
        RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      WHEN OTHERS THEN
        P_ERR_MSG := '获取仓库[' || V_INV_CODE || '|' || V_INV_NAME ||
                     '对应的库存组织发生异常：' || SQLERRM;
        RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
    END;
  
    SELECT S_INTF_INV_TRANSACTION_HEAD.NEXTVAL
      INTO V_TRANS_HEAD_ID
      FROM DUAL;
  
    --子库转移头表
    INSERT INTO INTF_INV_TRANSACTION_HEAD
      (ID,
       INTERFACE_NUM,
       ORDER_NUM,
       ESB_SERIAL_NUM,
       SOURCE_ORDER_TYPE,
       POST_DATE,
       STATUS,
       RETRANSMISSION_NUMBER,
       ENTITY_ID, --主体ID add by chen.wj 20150213 应增祥胜要求增加
       SUBINVENTORY, --子库编码add by chen.wj 20150213 应增祥胜要求增加来源子库编码
       ORDER_STEP,--库存事务步骤标识：1 第一次库存事务；2 第二次库存事务
       CREATION_DATE
       )
    VALUES
      (V_TRANS_HEAD_ID,
       V_DATA_SOURCE,
       R_SO_HEADER.SO_NUM,
       NULL,
       R_SO_HEADER.BILL_TYPE_NAME,
       SYSDATE,
       'N',
       0,
       P_ENTITY_ID,
       V_SRC_INV_CODE,
       DECODE(V_IS_SECOND_TRANSFER,PKG_SO_PUB.V_NO,1,PKG_SO_PUB.V_YES,2,1),
       SYSDATE);
  
    FOR R_SO_LINE_DETAIL IN C_SO_LINE_DETAIL LOOP
      INSERT INTO INTF_INV_TRANSACTION
        (ID, --1
         SOURCE_CODE, --2来源系统代码（可留空，在接口调用时赋值）
         SOURCE_NUM, --3来源编号（销售单据号）
         -- SOURCE_LINE_NUM, --4来源行编号（销售单据行明细ID）
         ESB_SERIAL_NUM, --5ESB流水号（留空）
         ESB_DATA_SOURCE, --6ESB数据来源（留空）
         ORGANIZATION_CODE, --7库存组织编码
         ITEM_NUMBER, --8物料编码
         SUBINVENTORY, --9来源子库编码
         TRANSACTION_TYPE, --10事务处理类型名称（子库转移的事务处理类型：Subinventory Transfer）
         TRANSACTION_QUANTITY, --11事务处理数量（物料数量）
         TRANSACTION_DATE, --12事务处理日期（系统当前日期）
         LOCATOR, --13货位编码（留空）
         TRANSACTION_UOM, --14事务处理单位（物料单位）
         TRANSFER_SUBINVENTORY, --15目标子库编码
         TRANSFER_LOCATOR, --16目标货位编码（留空）
         TRANS_LOT_NUMBER, --17批次号,有批次物料使用（留空）
         STATUS, --18状态
         HEADER_ID, --19
         SOURCE_LINE_ID,
         SOURCE_LINE_DETAIL_ID
         )
      VALUES
        (S_INTF_GERP_CIMS_TRANSACTION.NEXTVAL, --1
         'CIMS', --2来源系统代码（可留空，在接口调用时赋值）
         R_SO_HEADER.SO_NUM, --3来源编号（销售单据号）
         --4TO_CHAR(R_SO_LINE_DETAIL.SO_LINE_DETAIL_ID),
         NULL, --5
         'ERP-IMS-023', --6ESB流水号（留空）
         V_INV_ORG_CODE, --7 库存组织编码
         R_SO_LINE_DETAIL.COMPONENT_CODE, --8
         V_SRC_INV_CODE, --9  来源子库编码
         V_TRANSACTION_TYPE, --10
         R_SO_LINE_DETAIL.COMPONENT_QTY, --11
         V_TRANSACTION_DATE,
         NULL, --13
         R_SO_LINE_DETAIL.COMPONENT_UOM, --14
         V_TARGET_INV_CODE, --15 目标子库编码
         NULL, --16
         NULL, --17
         'N', --18
         V_TRANS_HEAD_ID, --19
         R_SO_LINE_DETAIL.SO_LINE_ID,
         R_SO_LINE_DETAIL.SO_LINE_DETAIL_ID
         );
    END LOOP;
    
    IF (V_IS_SECOND_TRANSFER_ENABLE = PKG_SO_PUB.V_YES) THEN
       P_SO_INV_TRANSFER(P_ENTITY_ID,P_SO_HEADER_ID,P_RESULT,P_ERR_MSG);
       PKG_SO_PUB.P_EXCEPTION_THROWS(P_RESULT);
    END IF;
      
    --第二次子库转移同时调用CIMS的库存事务第二步
    IF (V_IS_SECOND_TRANSFER = PKG_SO_PUB.V_YES) THEN
       P_SO_INV_TRANSACTION(R_SO_HEADER.ENTITY_ID,
                           '30',
                           R_SO_HEADER.ERP_LOGIST_RECEIVE_DATE,
                           R_SO_HEADER.SO_HEADER_ID,
                           P_RESULT,
                           P_ERR_MSG);
       PKG_SO_PUB.P_EXCEPTION_THROWS(P_RESULT);
    END IF;
    
  EXCEPTION
    WHEN PKG_SO_PUB.V_BIZ_EXCEPTION THEN
      P_RESULT  := -27001;
      P_ERR_MSG := '子库转移处理出错：' || P_ERR_MSG;
    WHEN OTHERS THEN
      P_RESULT  := -27001;
      P_ERR_MSG := '子库转移处理发生异常，异常信息：' || SQLERRM;
  END;
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2017-01-11
  *     创建者：周建刚
  *   功能说明：子库接口转移-人工修复数据专用，使用前请咨询周建刚
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_INV_TRANSFER_ADMIN(P_ENTITY_ID    IN NUMBER, --主体ID
                              P_SO_HEADER_ID IN NUMBER, --销售单据头ID
                              P_RESULT       OUT NUMBER, --返回错误ID
                              P_ERR_MSG      OUT VARCHAR2 --返回错误信息
                              ) IS
    --销售单据头信息游标
    CURSOR C_SO_HEADER IS
      SELECT *
        FROM T_SO_HEADER
       WHERE SO_HEADER_ID = P_SO_HEADER_ID
         AND ENTITY_ID = P_ENTITY_ID;
    --销售单据头信息记录
    R_SO_HEADER C_SO_HEADER%ROWTYPE;
  
    --销售单据行明细信息游标
    CURSOR C_SO_LINE_DETAIL IS
      SELECT *
        FROM T_SO_LINE_DETAIL
       WHERE SO_HEADER_ID = P_SO_HEADER_ID
         AND ENTITY_ID = P_ENTITY_ID;
    --销售单据行明细记录集
    R_SO_LINE_DETAIL C_SO_LINE_DETAIL%ROWTYPE;
  
    --库存组织编码
    V_INV_ORG_CODE T_INV_ORGANIZATION.ORGANIZATION_CODE%TYPE;
  
    --来源子库编码（仓库编码）
    V_SRC_INV_CODE T_INV_INVENTORIES.INVENTORY_CODE%TYPE;
  
    --目标子库编码
    V_TARGET_INV_CODE T_INV_INVENTORIES.INVENTORY_CODE%TYPE;
  
    --子库转移的事务处理类型
    V_TRANSACTION_TYPE VARCHAR2(80) := '2'; --'Subinventory Transfer';
  
    --仓库ID、编码、名称
    V_INV_ID   T_INV_INVENTORIES.INVENTORY_ID%TYPE;
    V_INV_CODE T_INV_INVENTORIES.INVENTORY_CODE%TYPE;
    V_INV_NAME T_INV_INVENTORIES.INVENTORY_NAME%TYPE;
  
    --子库转移头ID
    V_TRANS_HEAD_ID NUMBER;
    --接口编号
    V_DATA_SOURCE VARCHAR2(20) := 'ERP-IMS-023';
  
    --推拉式标记
    V_PUSH_OR_PULL VARCHAR2(50);
    
    --已经写入的子库转移次数
    V_SO_TRANSFER_COUNT NUMBER := 0;
    --当前操作是否为第二次子库转移
    V_IS_SECOND_TRANSFER VARCHAR2(2) := 'N';
    --库存事务日期：第一步为单据日期；第二步为PO接收日期
    V_TRANSACTION_DATE INTF_INV_TRANSACTION.TRANSACTION_DATE%TYPE;
  BEGIN
    P_RESULT  := V_RESULT;
    P_ERR_MSG := V_SUCCESS;

    --获取销售单头信息
    OPEN C_SO_HEADER;
    FETCH C_SO_HEADER
      INTO R_SO_HEADER;
    CLOSE C_SO_HEADER;
    
    --库存事务日期默认为单据日期
    V_TRANSACTION_DATE := R_SO_HEADER.SO_DATE;
    
    --判断是否可以做第二次子库转移:存在第一次子库转移记录，物流签收标识为 Y，签收日期不为空  add by zhoujg3 2016-09-21
    SELECT COUNT(1)
      INTO V_SO_TRANSFER_COUNT
      FROM INTF_INV_TRANSACTION_HEAD H
     WHERE EXISTS (SELECT 1 FROM T_SO_HEADER SO
      WHERE H.ENTITY_ID = SO.ENTITY_ID AND H.ORDER_NUM = SO.SO_NUM AND SO.ENTITY_ID = P_ENTITY_ID AND SO.SO_HEADER_ID = P_SO_HEADER_ID);
  
    IF (V_SO_TRANSFER_COUNT >= 2) THEN
        P_ERR_MSG := '单据[' ||
                     R_SO_HEADER.SO_NUM || ']子库转移次数不可超过[2]次，请检查！';
        RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
    END IF;
  
    BEGIN
      V_PUSH_OR_PULL := R_SO_HEADER.TRX_MODE;  
      IF V_PUSH_OR_PULL IS NULL THEN           
        PKG_BD.P_GET_PARAMETER_VALUE(PKG_SO_PUB.V_ARG_SO_AR_PUSH_OR_PULL,
                                     R_SO_HEADER.ENTITY_ID,
                                     NULL,
                                     NULL,
                                     V_PUSH_OR_PULL);
      END IF;                                   
    EXCEPTION
      WHEN OTHERS THEN
        P_ERR_MSG := 'SO_AR_PUSH_OR_PULL主体参数,主体id:' ||
                     R_SO_HEADER.ENTITY_ID || '的参数设置异常，请检查。' || SQLERRM;
        RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
    END;
    /*
               单据类型       来源子库    目标子库
    外部客户   销售单         发货仓      中间仓  
    外部客户   销售红冲单     中间仓      发货仓  
    外部客户   退货单         中间仓      收货仓  
    外部客户   退货红冲单     收货仓      中间仓
    */
    IF (NVL(R_SO_HEADER.ENTITY_CUST_FLAG,PKG_SO_PUB.V_NO) = PKG_SO_PUB.V_NO
       AND (R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE = PKG_SO_PUB.V_BIZ_SRC_BILL_SO_RED
       OR R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE = PKG_SO_PUB.V_BIZ_SRC_BILL_RETURN
       OR R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE = PKG_SO_PUB.V_BIZ_SRC_BILL_RETURN_RED)) THEN
      IF (R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE =
            PKG_SO_PUB.V_BIZ_SRC_BILL_SO_RED) THEN
        --销售红冲单
        V_INV_ID          := R_SO_HEADER.MIDDLE_INV_ID;
        V_INV_CODE        := R_SO_HEADER.MIDDLE_INV_CODE;
        V_INV_NAME        := R_SO_HEADER.MIDDLE_INV_NAME;

        --子库转移：中间仓->发出仓
        V_SRC_INV_CODE    := R_SO_HEADER.MIDDLE_INV_CODE; 
        V_TARGET_INV_CODE := R_SO_HEADER.SHIP_INV_CODE;
      ELSIF (R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE =
            PKG_SO_PUB.V_BIZ_SRC_BILL_RETURN) THEN
        --退货单 
        V_INV_ID          := R_SO_HEADER.MIDDLE_INV_ID;
        V_INV_CODE        := R_SO_HEADER.MIDDLE_INV_CODE;
        V_INV_NAME        := R_SO_HEADER.MIDDLE_INV_NAME;

        --子库转移：中间仓->收货仓
        V_SRC_INV_CODE    := R_SO_HEADER.MIDDLE_INV_CODE;
        V_TARGET_INV_CODE := R_SO_HEADER.CONSIGNEE_INV_CODE;
      ELSIF (R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE =
            PKG_SO_PUB.V_BIZ_SRC_BILL_RETURN_RED) THEN
        --退货红冲单
        V_INV_ID          := R_SO_HEADER.CONSIGNEE_INV_ID;
        V_INV_CODE        := R_SO_HEADER.CONSIGNEE_INV_CODE;
        V_INV_NAME        := R_SO_HEADER.CONSIGNEE_INV_NAME;

        --子库转移：收货仓->中间仓
        V_SRC_INV_CODE    := R_SO_HEADER.CONSIGNEE_INV_CODE;
        V_TARGET_INV_CODE := R_SO_HEADER.MIDDLE_INV_CODE;
      
      END IF;
    END IF;
    
    IF (V_SRC_INV_CODE IS NULL) THEN
      P_ERR_MSG := '单据[' || R_SO_HEADER.SO_NUM || ']子库转移的来源仓不可为空！';
      RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
    END IF;
  
    IF (V_TARGET_INV_CODE IS NULL) THEN
      P_ERR_MSG := '单据[' || R_SO_HEADER.SO_NUM || ']子库转移的目标仓不可为空！';
      RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
    END IF;
  
    BEGIN
      --获取ERP OU ID、ERP OU名称、ERP子库ID、ERP子库编码、
      SELECT INV_ORG.ORGANIZATION_CODE --仓库对应的库存组织编码
        INTO V_INV_ORG_CODE
        FROM T_INV_INVENTORIES INV, T_INV_ORGANIZATION INV_ORG
       WHERE INV.ORGANIZATION_ID = INV_ORG.ORGANIZATION_ID
         AND INV.ORGANIZATION_CODE = INV_ORG.ORGANIZATION_CODE
         AND INV.ENTITY_ID = INV_ORG.ENTITY_ID
         AND INV.INVENTORY_ID = V_INV_ID
         AND INV.ENTITY_ID = R_SO_HEADER.ENTITY_ID
         AND ROWNUM = 1;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        P_ERR_MSG := '仓库[' || V_INV_CODE || '|' || V_INV_NAME ||
                     ']未设置对应的库存组织！';
        RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      WHEN OTHERS THEN
        P_ERR_MSG := '获取仓库[' || V_INV_CODE || '|' || V_INV_NAME ||
                     '对应的库存组织发生异常：' || SQLERRM;
        RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
    END;
  
    SELECT S_INTF_INV_TRANSACTION_HEAD.NEXTVAL
      INTO V_TRANS_HEAD_ID
      FROM DUAL;
  
    --子库转移头表
    INSERT INTO INTF_INV_TRANSACTION_HEAD
      (ID,
       INTERFACE_NUM,
       ORDER_NUM,
       ESB_SERIAL_NUM,
       SOURCE_ORDER_TYPE,
       POST_DATE,
       STATUS,
       RETRANSMISSION_NUMBER,
       ENTITY_ID, --主体ID add by chen.wj 20150213 应增祥胜要求增加
       SUBINVENTORY, --子库编码add by chen.wj 20150213 应增祥胜要求增加来源子库编码
       ORDER_STEP,--库存事务步骤标识：1 第一次库存事务；2 第二次库存事务
       CREATION_DATE
       )
    VALUES
      (V_TRANS_HEAD_ID,
       V_DATA_SOURCE,
       R_SO_HEADER.SO_NUM,
       NULL,
       R_SO_HEADER.BILL_TYPE_NAME,
       SYSDATE,
       'N',
       0,
       P_ENTITY_ID,
       V_SRC_INV_CODE || ' ',
       DECODE(V_IS_SECOND_TRANSFER,PKG_SO_PUB.V_NO,1,PKG_SO_PUB.V_YES,2,1),
       SYSDATE);
  
    FOR R_SO_LINE_DETAIL IN C_SO_LINE_DETAIL LOOP
      INSERT INTO INTF_INV_TRANSACTION
        (ID, --1
         SOURCE_CODE, --2来源系统代码（可留空，在接口调用时赋值）
         SOURCE_NUM, --3来源编号（销售单据号）
         -- SOURCE_LINE_NUM, --4来源行编号（销售单据行明细ID）
         ESB_SERIAL_NUM, --5ESB流水号（留空）
         ESB_DATA_SOURCE, --6ESB数据来源（留空）
         ORGANIZATION_CODE, --7库存组织编码
         ITEM_NUMBER, --8物料编码
         SUBINVENTORY, --9来源子库编码
         TRANSACTION_TYPE, --10事务处理类型名称（子库转移的事务处理类型：Subinventory Transfer）
         TRANSACTION_QUANTITY, --11事务处理数量（物料数量）
         TRANSACTION_DATE, --12事务处理日期（系统当前日期）
         LOCATOR, --13货位编码（留空）
         TRANSACTION_UOM, --14事务处理单位（物料单位）
         TRANSFER_SUBINVENTORY, --15目标子库编码
         TRANSFER_LOCATOR, --16目标货位编码（留空）
         TRANS_LOT_NUMBER, --17批次号,有批次物料使用（留空）
         STATUS, --18状态
         HEADER_ID, --19
         SOURCE_LINE_ID,
         SOURCE_LINE_DETAIL_ID
         )
      VALUES
        (S_INTF_GERP_CIMS_TRANSACTION.NEXTVAL, --1
         'CIMS', --2来源系统代码（可留空，在接口调用时赋值）
         R_SO_HEADER.SO_NUM, --3来源编号（销售单据号）
         --4TO_CHAR(R_SO_LINE_DETAIL.SO_LINE_DETAIL_ID),
         NULL, --5
         'ERP-IMS-023', --6ESB流水号（留空）
         V_INV_ORG_CODE, --7 库存组织编码
         R_SO_LINE_DETAIL.COMPONENT_CODE, --8
         V_SRC_INV_CODE, --9  来源子库编码
         V_TRANSACTION_TYPE, --10
         R_SO_LINE_DETAIL.COMPONENT_QTY, --11
         V_TRANSACTION_DATE,
         NULL, --13
         R_SO_LINE_DETAIL.COMPONENT_UOM, --14
         V_TARGET_INV_CODE, --15 目标子库编码
         NULL, --16
         NULL, --17
         'N', --18
         V_TRANS_HEAD_ID, --19
         R_SO_LINE_DETAIL.SO_LINE_ID,
         R_SO_LINE_DETAIL.SO_LINE_DETAIL_ID
         );
    END LOOP;
  EXCEPTION
    WHEN PKG_SO_PUB.V_BIZ_EXCEPTION THEN
      P_RESULT  := -27001;
      P_ERR_MSG := '子库转移处理出错：' || P_ERR_MSG;
    WHEN OTHERS THEN
      P_RESULT  := -27001;
      P_ERR_MSG := '子库转移处理发生异常，异常信息：' || SQLERRM;
  END;
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-02-05
  *     创建者：陈武杰
  *   功能说明：子库转移回调
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_INV_TRANSFER_WIRTE_BACK(IN_TRANSACTION_ID INTF_INV_TRANSACTION_HEAD.ID%TYPE --headerId  update by guibr
                                         --P_SO_HEADER_ID IN NUMBER --销售单头ID
                                         --P_RESULT       OUT NUMBER, --返回错误ID
                                         --P_ERR_MSG      OUT VARCHAR2 --返回错误信息
                                         ) AS
    --PRAGMA AUTONOMOUS_TRANSACTION; --自治事务
    V_PULL_MODE    NUMBER;
    V_SO_NUM       T_SO_HEADER.SO_NUM%TYPE;
    P_RESULT       NUMBER;
    P_ERR_MSG      VARCHAR2(2000);
    P_SO_HEADER_ID NUMBER;
    V_ENTITY_CUST_FLAG VARCHAR2(2);
    V_COUNT NUMBER;
    --R_SO_HEADER T_SO_HEADER%ROWTYPE;
  BEGIN
    P_RESULT  := V_RESULT;
    P_ERR_MSG := V_SUCCESS;
    /*
        ---1错误,0非拉式,1销售,2红冲,3源单退回,4反向销售,5拉式其他单据类型
        V_PULL_MODE := PKG_SO_PUB.F_PULL_MODE(V_SO_NUM);
    */
    BEGIN
      /*SELECT *
       INTO R_SO_HEADER
       FROM T_SO_HEADER
      WHERE SO_HEADER_ID = P_SO_HEADER_ID;*/
    
      SELECT SO_HEADER_ID,NVL(ENTITY_CUST_FLAG,'N')
        INTO P_SO_HEADER_ID,V_ENTITY_CUST_FLAG
        FROM T_SO_HEADER
       WHERE SO_NUM = (SELECT ORDER_NUM
                         FROM CIMS.INTF_INV_TRANSACTION_HEAD A
                        WHERE A.Id = IN_TRANSACTION_ID); --update by guibr
      /**
      --如果是事业部客户，则返回，add by xiongpl 2015-8-6
      IF V_ENTITY_CUST_FLAG ='Y' THEN
         RETURN;
      END IF;
      */
      --子库转移成功，而且不包括已经生成RMA
      SELECT B.SO_NUM, PKG_SO_PUB.F_PULL_MODE(B.SO_NUM) ---1错误,0非拉式,1销售,2红冲,3源单退回,4反向销售,5拉式其他单据类型
        INTO V_SO_NUM, V_PULL_MODE
        FROM INTF_INV_TRANSACTION_HEAD A, T_SO_HEADER B
       WHERE A.ORDER_NUM = B.SO_NUM
         AND B.SO_HEADER_ID = P_SO_HEADER_ID
         AND ROWNUM = 1
            --AND A.STATUS = 'S'
            --AND NVL(A.ERROR_FLAG, 'N') = 'N'--因为触发这个方法的时候就是成功状态的
         /* edit by chen.wj 20150504 子库转移和SO生成没有顺序，不用该条件
         AND NOT EXISTS (SELECT 1
                FROM INTF_OE_HEADERS_IFACE_ALL C
               WHERE C.ORDER_NUMBER = B.SO_NUM)*/;
    
    EXCEPTION
      WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20123,
                                'SO_HEADER_ID[' || P_SO_HEADER_ID ||
                                ']P_SO_INV_TRANSFER_WIRTE_BACK，获取SO_NUM错误：' ||
                                SQLERRM,
                                FALSE);
    END;
    -- -1错误,0非拉式,1销售,2红冲,3源单退回,4反向销售,5源单退货红冲，6拉式其他单据类型
    IF V_PULL_MODE IN (2, 3, 4) THEN
      --判断是否已经存在SO记录
      SELECT COUNT(1)
       INTO V_COUNT
       FROM INTF_OE_HEADERS_IFACE_ALL H
        WHERE H.ORDER_NUMBER = V_SO_NUM
        AND H.ORIG_SYS_DOCUMENT_REF = '' || P_SO_HEADER_ID;
        
      IF V_COUNT = 0 THEN
        --红冲、退货、反向销售要调用RMA生成
        PKG_SO_BIZ.P_SO_TO_ERP(P_SO_HEADER_ID, 'GEN', P_RESULT, P_ERR_MSG);
        IF P_RESULT <> 0 THEN
          RAISE_APPLICATION_ERROR(-20123,
                                  'SO_HEADER_ID[' || P_SO_HEADER_ID ||
                                  ']P_SO_INV_TRANSFER_WIRTE_BACK，RMA生成错误：' ||
                                  P_ERR_MSG,
                                  FALSE);
        END IF;
      END IF;
      --COMMIT;
    END IF;
  
  EXCEPTION
    WHEN OTHERS THEN
      --ROLLBACK;
      PKG_SO_RT.P_TABLE_ACTION_LOG(P_TABLE_NAME     => 'P_SO_INV_TRANSFER_WIRTE_BACK',
                                   P_ACTION_REMARKS => '子库转移回调',
                                   P_PK             => P_SO_HEADER_ID,
                                   P_ISERR          => 1, --是否出错，1出错，0未出错
                                   P_MSG            => SQLERRM);
    
      RAISE_APPLICATION_ERROR(-20123,
                              '子库转移回调错误：' || SQLERRM,
                              FALSE);
  END;
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-09-24
  *     创建者：周建刚
  *   功能说明：更新退货申请单产品签收数量。根据A3、库位等退货签收接口更新退货申请明细行的产品签收数量
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_UPDATE_RECEIVEDQTY(P_RECEIVE_TYPE    IN VARCHAR2, --签收来源：A3签收，A3；库位签收，CIMS；AUDIT_DIRECT_CREATE,无实际物流，退货申请审核通过直接开退货单
                                    P_BILL_NUM        IN VARCHAR2, --退货申请单号
                                    P_SOURCE_BILL_NUM IN VARCHAR2, --源单号。库位签收时会传递库位单号，A3签收时固定传递"-1"
                                    P_RESULT          OUT NUMBER, --返回错误ID
                                    P_ERR_MSG         OUT VARCHAR2 --返回错误信息
                                    ) IS
  
    --A3接口返回产品签收信息游标(未转退货单行明细的记录)
    CURSOR C_SO_RETURN_RECEIVE IS
      SELECT T.*
        FROM T_SO_RETURN_RECEIVE T
       WHERE T.BILL_NUM = P_BILL_NUM
         AND (T.TO_DETAIL_FLAG IS NULL OR T.TO_DETAIL_FLAG != 'Y')
         AND NVL(T.SOURCE_BILL_NUM, '-1') = P_SOURCE_BILL_NUM;
    --A3接口返回产品签收信息游标信息记录
    R_SO_RETURN_RECEIVE C_SO_RETURN_RECEIVE%ROWTYPE;
    V_APPLY_HEADER_ID   NUMBER := 0; -- 退货申请单ID
    V_LG_FLAG           VARCHAR2(32) := ''; -- 有无实际物流标识，N 无实际物流、Y 有实际物流
    V_RECEIVED_QTY      NUMBER := 0; -- 签收数量
    V_COMPONENT_QTY     NUMBER := 0; -- 申请数量
    V_PO_RELATION_FLAG  T_SO_RETURN_APPLY_HEADER.PO_RELATION_FLAG%TYPE;
    
    V_APPLY_LINE_ID     T_SO_RETURN_APPLY_LINE_DETAIL.APPLY_LINE_ID%TYPE;
    V_RECEIVE_DOC_CODE  T_SO_RETURN_RECEIVE.RECEIVE_DOC_CODE%TYPE;
    R_SALESRTN_LINES    INTF_SALESRTN_LINES%ROWTYPE;
  BEGIN
    P_RESULT  := V_RESULT;
    P_ERR_MSG := V_SUCCESS;
  
    SELECT T.APPLY_HEADER_ID, T.LG_FLAG,NVL(T.PO_RELATION_FLAG,PKG_SO_PUB.V_NO)
      INTO V_APPLY_HEADER_ID, V_LG_FLAG,V_PO_RELATION_FLAG
      FROM T_SO_RETURN_APPLY_HEADER T
     WHERE T.BILL_NUM = P_BILL_NUM;
  
    IF (V_LG_FLAG IS NULL OR V_LG_FLAG = 'Y') THEN
      -- 有实际物流，根据A3或库位签收的请求更新签收数量
      --获取销售单头信息
      OPEN C_SO_RETURN_RECEIVE;
      LOOP
        FETCH C_SO_RETURN_RECEIVE
          INTO R_SO_RETURN_RECEIVE;
        EXIT WHEN C_SO_RETURN_RECEIVE%NOTFOUND;
        
        V_RECEIVE_DOC_CODE := R_SO_RETURN_RECEIVE.RECEIVE_DOC_CODE;

        SELECT NVL(D.RECEIVED_QTY, 0), D.COMPONENT_QTY,D.APPLY_LINE_ID
          INTO V_RECEIVED_QTY, V_COMPONENT_QTY,V_APPLY_LINE_ID
          FROM T_SO_RETURN_APPLY_LINE_DETAIL D
         WHERE D.APPLY_LINE_DETAIL_ID =
               R_SO_RETURN_RECEIVE.APPLY_LINE_DETAIL_ID
           AND D.APPLY_HEADER_ID = V_APPLY_HEADER_ID;
             
        --根据采购关系的不同来决定差异处理方式
        --无采购关系的退货申请签收时的处理方式：按照实际签收数量给客户开退货单，差异部分无需处理。
        IF (PKG_SO_PUB.V_YES <> V_PO_RELATION_FLAG) THEN

          -- 签收数量不能大于申请数量
          IF V_RECEIVED_QTY > V_COMPONENT_QTY THEN
            P_ERR_MSG := P_RECEIVE_TYPE ||
                         '签收(A3签收，A3；库位签收，CIMS；AUDIT_DIRECT_CREATE,审核通过即开单),[' ||
                         P_BILL_NUM || '] 产品[' ||
                         R_SO_RETURN_RECEIVE.ITEM_CODE || ']签收数量异常(签收数量[' ||
                         V_RECEIVED_QTY || '] > 申请数量[' || V_COMPONENT_QTY ||
                         ']),请核实！';
            RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
          END IF;
        
          --已签收数量 + 本次签收数量 不能大于申请数量
          IF (V_RECEIVED_QTY + NVL(R_SO_RETURN_RECEIVE.RECEIVED_QTY, 0)) >
             V_COMPONENT_QTY THEN
            P_ERR_MSG := P_RECEIVE_TYPE ||
                         '签收(A3签收，A3；库位签收，CIMS；AUDIT_DIRECT_CREATE,审核通过即开单),[' ||
                         P_BILL_NUM || '] 产品[' ||
                         R_SO_RETURN_RECEIVE.ITEM_CODE || ']签收数量异常(已签收数量[' ||
                         V_RECEIVED_QTY || '] + 本次签收数量[' ||
                         NVL(R_SO_RETURN_RECEIVE.RECEIVED_QTY, 0) ||
                         '] > 申请数量[' || V_COMPONENT_QTY || ']),请核实！';
            RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
          END IF;
        
          --根据申请头ID、行明细ID、产品编码更新退货申请行明细已签收数量
          UPDATE T_SO_RETURN_APPLY_LINE_DETAIL T
             SET T.RECEIVED_QTY =
                 (NVL(T.RECEIVED_QTY, 0) +
                 NVL(R_SO_RETURN_RECEIVE.RECEIVED_QTY, 0))
           WHERE T.COMPONENT_CODE = R_SO_RETURN_RECEIVE.ITEM_CODE
             AND T.APPLY_HEADER_ID = V_APPLY_HEADER_ID
             AND T.APPLY_LINE_DETAIL_ID =
                 R_SO_RETURN_RECEIVE.APPLY_LINE_DETAIL_ID;

        ELSE 

          --更新发货通知单（明细）行签收信息，以便给承运商开全陪单
          UPDATE CIMS.INTF_SALESRTN_LINES L
             SET L.RECEIVED_QTY     = NVL(L.RECEIVED_QTY, 0) +
                                      NVL(R_SO_RETURN_RECEIVE.RECEIVED_QTY, 0),
                 L.LAST_UPDATE_DATE = SYSDATE
           WHERE L.SALESRTN_BS_LINES_ID = R_SO_RETURN_RECEIVE.APPLY_LINE_DETAIL_ID
             AND EXISTS (SELECT 1 FROM CIMS.INTF_SALESRTN_HEADERS H WHERE H.SALESRTN_HEADERS_ID = L.SALESRTN_HEADERS_ID
             AND H.BILL_NUM = P_BILL_NUM AND H.RECEIVE_DOC_CODE = R_SO_RETURN_RECEIVE.RECEIVE_DOC_CODE);

        END IF;
        
        UPDATE T_SO_RETURN_RECEIVE T
           SET T.TO_DETAIL_FLAG = 'Y'
         WHERE T.RTN_RECV_ID = R_SO_RETURN_RECEIVE.RTN_RECV_ID;
        
        UPDATE CIMS.INTF_SALESRTN_HEADERS H
           SET H.RECEIVE_FLAG     = PKG_SO_PUB.V_YES,
               H.RECEIVE_DATE     = SYSDATE,
               H.LAST_UPDATE_DATE = SYSDATE
         WHERE H.BILL_NUM = P_BILL_NUM
           AND H.RECEIVE_DOC_CODE = R_SO_RETURN_RECEIVE.RECEIVE_DOC_CODE;
         
      END LOOP;
      CLOSE C_SO_RETURN_RECEIVE;
    
      --P_SO_RTN_DIFF_TO_VENDER(P_BILL_NUM,V_RECEIVE_DOC_CODE,P_RESULT,P_ERR_MSG);
    
    ELSIF V_LG_FLAG = 'N' THEN
      -- 退货申请无实际物流，直接将签收数量更新和已开退货单数量为散件退货申请数量
      UPDATE T_SO_RETURN_APPLY_LINE_DETAIL D
         SET D.RECEIVED_QTY = NVL(D.COMPONENT_QTY, 0)
       WHERE D.APPLY_HEADER_ID = V_APPLY_HEADER_ID;

    END IF;
    
    --跨主体退货申请更新收货通知单行（套件）的签收数量
    IF (PKG_SO_PUB.V_YES = V_PO_RELATION_FLAG) THEN
      
      /**
      有采购关系的退货申请签收时的处理方式：客户都是按照全部完好签收[T_SO_RETURN_APPLY_LINE_DETAIL]，差异部分给承运商（安得）开全陪单[INTF_SALESRTN_LINES]
      根据申请头ID、行明细ID、产品编码更新退货申请行明细已签收数量
      */
      UPDATE T_SO_RETURN_APPLY_LINE_DETAIL T
         SET T.RECEIVED_QTY    =
             (NVL(T.RECEIVED_QTY, 0) +
             (SELECT L.RETURN_QTY
                 FROM CIMS.INTF_SALESRTN_LINES L
                WHERE EXISTS
                (SELECT 1
                         FROM CIMS.INTF_SALESRTN_HEADERS H
                        WHERE H.SALESRTN_HEADERS_ID = L.SALESRTN_HEADERS_ID
                          AND H.BILL_NUM = P_BILL_NUM
                          AND H.RECEIVE_DOC_CODE =
                              R_SO_RETURN_RECEIVE.RECEIVE_DOC_CODE)
                  AND L.COMPONENT_CODE = T.COMPONENT_CODE
                  AND L.SALESRTN_BS_LINES_ID = T.APPLY_LINE_DETAIL_ID)),
             T.LAST_UPDATE_DATE = SYSDATE
       WHERE EXISTS (SELECT 1
                FROM CIMS.T_SO_RETURN_APPLY_HEADER RH
               WHERE RH.APPLY_HEADER_ID = T.APPLY_HEADER_ID
                 AND RH.PO_RELATION_FLAG = 'Y'
                 AND RH.BILL_NUM = P_BILL_NUM)
         AND T.APPLY_HEADER_ID = V_APPLY_HEADER_ID;

      FOR REC IN (
                SELECT LS.*
                  FROM CIMS.INTF_SALESRTN_LINES_SET LS
                 WHERE EXISTS
                 (SELECT 1
                          FROM CIMS.INTF_SALESRTN_HEADERS H
                         WHERE LS.SALESRTN_HEADERS_ID = H.SALESRTN_HEADERS_ID
                           AND H.BILL_NUM = P_BILL_NUM
                           AND H.RECEIVE_DOC_CODE = V_RECEIVE_DOC_CODE)
                  ) LOOP  
      
        IF (REC.ITEM_UOM = 'Set') THEN
          
          /**
          更新收货通知单行（套件）签收信息(‘顶格’计算套件，10套件，8台散件1，7台散件2：签收套件设置为8，
          以便求差额计算承运商全陪。全陪套机 2套，1台散件2)
          */
          UPDATE CIMS.INTF_SALESRTN_LINES_SET LS
             SET LS.LAST_UPDATE_DATE = SYSDATE,
                 LS.RECEIVE_QTY     =
                 (SELECT MAX(NVL(D.RECEIVED_QTY, 0) / S.QUANTITY)
                    FROM CIMS.V_BD_ITEM_ASSEMBLIES_SUB S,
                         CIMS.INTF_SALESRTN_LINES      D
                   WHERE S.ACTIVE_FLAG = 'Y'
                     AND S.ASSEMBLE_ACTIVE_FLAG = 'Y'
                     AND S.ENTITY_ID = REC.ENTITY_ID
                     AND S.ITEM_CODE = REC.ITEM_CODE
                     AND S.ITEM_CODE = D.ITEM_CODE
                     AND S.ENTITY_ID = D.ENTITY_ID
                     AND EXISTS
                   (SELECT 1
                            FROM CIMS.INTF_SALESRTN_HEADERS H
                           WHERE D.SALESRTN_HEADERS_ID = H.SALESRTN_HEADERS_ID
                             AND H.BILL_NUM = P_BILL_NUM
                             AND H.RECEIVE_DOC_CODE = V_RECEIVE_DOC_CODE))
           WHERE LS.SALESRTN_LINES_SET_ID = REC.SALESRTN_LINES_SET_ID;
        
        ELSE
        
          --更新收货通知单行（套件）签收信息
          UPDATE CIMS.INTF_SALESRTN_LINES_SET LS
             SET LS.LAST_UPDATE_DATE = SYSDATE,
                 LS.RECEIVE_QTY     =
                 (SELECT NVL(D.RECEIVED_QTY, 0)
                    FROM CIMS.INTF_SALESRTN_LINES      D
                   WHERE D.ENTITY_ID = REC.ENTITY_ID
                     AND D.ITEM_CODE = REC.ITEM_CODE
                     AND EXISTS
                   (SELECT 1
                            FROM CIMS.INTF_SALESRTN_HEADERS H
                           WHERE D.SALESRTN_HEADERS_ID = H.SALESRTN_HEADERS_ID
                             AND H.BILL_NUM = P_BILL_NUM
                             AND H.RECEIVE_DOC_CODE = V_RECEIVE_DOC_CODE))
           WHERE LS.SALESRTN_LINES_SET_ID = REC.SALESRTN_LINES_SET_ID;
           
        END IF;
      END LOOP;
      
    END IF;
  
    --P_SO_UPDATE_GEN_SO_FLAG(V_APPLY_HEADER_ID,P_RESULT,P_ERR_MSG);
  EXCEPTION
    WHEN PKG_SO_PUB.V_BIZ_EXCEPTION THEN
      P_RESULT := -28030;
    WHEN OTHERS THEN
      P_RESULT  := -28866;
      P_ERR_MSG := P_RECEIVE_TYPE ||
                   '签收(A3签收，A3；库位签收，CIMS；AUDIT_DIRECT_CREATE,审核通过即开单),[' ||
                   P_BILL_NUM || ',' || P_SOURCE_BILL_NUM || ']更新退货申请行明细产品签收数量发生异常！';
  END;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-01-22
  *     创建者：周建刚
  *   功能说明：根据退货申请单ID更新退货申请单产品行签收数量、退货申请单开单标识
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_UPDATE_GEN_SO_FLAG(P_APPLY_HEADER_ID IN NUMBER, --退货申请单ID
                                    P_RESULT          OUT NUMBER, --返回错误ID
                                    P_ERR_MSG         OUT VARCHAR2 --返回错误信息
                                    ) IS
  
    --行明细产品签收信息游标
    CURSOR C_SO_RETURN_APPLY_LINE_DETAIL IS
      SELECT T.*
        FROM T_SO_RETURN_APPLY_LINE_DETAIL T
       WHERE T.APPLY_HEADER_ID = P_APPLY_HEADER_ID
       ORDER BY T.ITEM_CODE;
    --行明细产品签收信息记录
    R_SO_RETURN_APPLY_LINE_DETAIL C_SO_RETURN_APPLY_LINE_DETAIL%ROWTYPE;
    
    R_SO_RETURN_APPLY_HEADER T_SO_RETURN_APPLY_HEADER%ROWTYPE;

    --行产品签收信息游标
    CURSOR C_SO_RETURN_APPLY_LINE IS
      SELECT T.*
        FROM T_SO_RETURN_APPLY_LINE T
       WHERE T.APPLY_HEADER_ID = P_APPLY_HEADER_ID
       ORDER BY T.ITEM_CODE;
    --行产品签收信息记录
    R_SO_RETURN_APPLY_LINE C_SO_RETURN_APPLY_LINE%ROWTYPE;
  
    V_TO_SO_RETURN_QTY_TOTAL    NUMBER := 0; -- 已开退货单总数(行明细)
    V_RECEIVED_QTY_TOTAL        NUMBER := 0; -- 签收总数(行明细)
    V_COMPONENT_QTY_TOTAL       NUMBER := 0; -- 申请总数(行明细)
    V_LINE_RECEIVED_QTY_MIN     NUMBER := 0; -- 已签收最小数(行)
    V_LINE_TO_SO_RETURN_QTY_MIN NUMBER := 0; -- 已开退货单最小数(行)
    V_LOOP_INDEX                NUMBER := 0; -- 行循环临时变量
  
  BEGIN
    P_RESULT  := V_RESULT;
    P_ERR_MSG := V_SUCCESS;
    
    SELECT H.*
      INTO R_SO_RETURN_APPLY_HEADER
      FROM CIMS.T_SO_RETURN_APPLY_HEADER H
     WHERE H.APPLY_HEADER_ID = P_APPLY_HEADER_ID;
  
    -- 更新退货申请单开单标识 begin
    OPEN C_SO_RETURN_APPLY_LINE_DETAIL;
    LOOP
      FETCH C_SO_RETURN_APPLY_LINE_DETAIL
        INTO R_SO_RETURN_APPLY_LINE_DETAIL;
      EXIT WHEN C_SO_RETURN_APPLY_LINE_DETAIL%NOTFOUND;
    
      V_TO_SO_RETURN_QTY_TOTAL := V_TO_SO_RETURN_QTY_TOTAL +
                                  NVL(R_SO_RETURN_APPLY_LINE_DETAIL.TO_SO_RETURN_QTY,
                                      0);
      V_RECEIVED_QTY_TOTAL     := V_RECEIVED_QTY_TOTAL +
                                  NVL(R_SO_RETURN_APPLY_LINE_DETAIL.RECEIVED_QTY,
                                      0);
      V_COMPONENT_QTY_TOTAL    := V_COMPONENT_QTY_TOTAL +
                                  NVL(R_SO_RETURN_APPLY_LINE_DETAIL.COMPONENT_QTY,
                                      0);
    
    END LOOP;
    CLOSE C_SO_RETURN_APPLY_LINE_DETAIL;
  
    IF V_TO_SO_RETURN_QTY_TOTAL = 0 THEN
      UPDATE T_SO_RETURN_APPLY_HEADER H
         SET H.GEN_SO_FLAG = '0', H.GEN_SO_DATE = SYSDATE
       WHERE H.APPLY_HEADER_ID = P_APPLY_HEADER_ID;
    ELSE
      IF (V_RECEIVED_QTY_TOTAL = V_TO_SO_RETURN_QTY_TOTAL AND
         V_RECEIVED_QTY_TOTAL = V_COMPONENT_QTY_TOTAL) THEN
        --退货申请单产品都签收入库后，设置单据状态为：已关闭
        UPDATE T_SO_RETURN_APPLY_HEADER H
           SET H.GEN_SO_FLAG = '2', H.GEN_SO_DATE = SYSDATE, H.BILL_STATUS = '13'
         WHERE H.APPLY_HEADER_ID = P_APPLY_HEADER_ID;
      ELSE
        UPDATE T_SO_RETURN_APPLY_HEADER H
           SET H.GEN_SO_FLAG = '1', H.GEN_SO_DATE = SYSDATE
         WHERE H.APPLY_HEADER_ID = P_APPLY_HEADER_ID;
      END IF;
    END IF;
    -- 更新退货申请单开单标识 end
  
    -- 更新退货申请行产品签收数量、已开退货单数量 begin
    OPEN C_SO_RETURN_APPLY_LINE;
    LOOP
      FETCH C_SO_RETURN_APPLY_LINE
        INTO R_SO_RETURN_APPLY_LINE;
      EXIT WHEN C_SO_RETURN_APPLY_LINE%NOTFOUND;
      V_LOOP_INDEX := 0;
      -- 获取行产品签收数量、已开退货单数量最小值。
      OPEN C_SO_RETURN_APPLY_LINE_DETAIL;
      LOOP
        FETCH C_SO_RETURN_APPLY_LINE_DETAIL
          INTO R_SO_RETURN_APPLY_LINE_DETAIL;
        EXIT WHEN C_SO_RETURN_APPLY_LINE_DETAIL%NOTFOUND;
      
        IF R_SO_RETURN_APPLY_LINE.ITEM_CODE =
           R_SO_RETURN_APPLY_LINE_DETAIL.ITEM_CODE THEN
          V_LOOP_INDEX := V_LOOP_INDEX + 1;
        
          IF V_LOOP_INDEX = 1 THEN
            V_LINE_RECEIVED_QTY_MIN     := NVL(R_SO_RETURN_APPLY_LINE_DETAIL.RECEIVED_QTY,
                                               0);
            V_LINE_TO_SO_RETURN_QTY_MIN := NVL(R_SO_RETURN_APPLY_LINE_DETAIL.TO_SO_RETURN_QTY,
                                               0);
          ELSE
            -- 取行明细的散件签收数量最小值
            IF (V_LINE_RECEIVED_QTY_MIN >
               NVL(R_SO_RETURN_APPLY_LINE_DETAIL.RECEIVED_QTY, 0)) THEN
            
              V_LINE_RECEIVED_QTY_MIN := NVL(R_SO_RETURN_APPLY_LINE_DETAIL.RECEIVED_QTY,
                                             0);
            END IF;
          
            -- 取行明细的散件已开退货单数量最小值
            IF (V_LINE_TO_SO_RETURN_QTY_MIN >
               NVL(R_SO_RETURN_APPLY_LINE_DETAIL.TO_SO_RETURN_QTY, 0)) THEN
              V_LINE_TO_SO_RETURN_QTY_MIN := NVL(R_SO_RETURN_APPLY_LINE_DETAIL.TO_SO_RETURN_QTY,
                                                 0);
            END IF;
          END IF;
        END IF;
      
      END LOOP;
      CLOSE C_SO_RETURN_APPLY_LINE_DETAIL;
    
      UPDATE T_SO_RETURN_APPLY_LINE LINE
         SET LINE.TO_SO_RETURN_QTY = V_LINE_TO_SO_RETURN_QTY_MIN
       WHERE LINE.APPLY_LINE_ID = R_SO_RETURN_APPLY_LINE.APPLY_LINE_ID;
      UPDATE T_SO_RETURN_APPLY_LINE LINE
         SET LINE.RECEIVED_QTY = V_LINE_RECEIVED_QTY_MIN
       WHERE LINE.APPLY_LINE_ID = R_SO_RETURN_APPLY_LINE.APPLY_LINE_ID;

    END LOOP;
    -- 更新退货申请行产品签收数量、已开退货单数量 end
    CLOSE C_SO_RETURN_APPLY_LINE;
  
  EXCEPTION
    WHEN PKG_SO_PUB.V_BIZ_EXCEPTION THEN
      P_RESULT  := -28030;
      P_ERR_MSG := '根据退货申请单ID更新退货申请单产品行签收数量、退货申请单开单标识';
    WHEN OTHERS THEN
      P_RESULT  := -28866;
      P_ERR_MSG := '根据退货申请单ID更新退货申请单产品行签收数量、退货申请单开单标识发生异常！';
  END;
  -------------------------------------------------------------------------------                                               
  /*
  *   创建日期：2015-01-13
  *   创建者：周建刚
  *   功能说明：[退货找源单]根据主体ID、客户、账户、产品获取对应的可退货的原销售单号
      厨房电器（小电）退货找源单的业务逻辑：
    1、根据退货单的客户、营销中心、退货产品、是否已全退（T_SO_LINE表的RETURN_FLAG='Y'），查找最新的销售单，如果能够找到且一张销售单上的可退货产品数量(产品数量-已退货的数量)足够退货，则直接取这张单作为源单；如果一张销售单上的可退货产品数量不够退货，则需从另外一张补够，以此类推；如果最终全部销售单的可退货产品数量都不足够退货，则需要分单（拆分为有源单和无源单）。
    2、找到源单后，需要记录到退货产品来源单表（T_SO_RETURN_ITEM_SRC），同时更新销售单行表（T_SO_LINE）已退货数量字段（RETURN_QTY）、是否已全退字段（RETURN_FLAG），以便下次找源单时，把已全部退货（RETURN_FLAG='Y'）的销售单排除掉。
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_FETCH_RETURN_SRC(P_RETURN_APPLY_BILLNUM IN VARCHAR2, --退货申请单号
                                  P_ENTITY_ID            IN NUMBER, --主体ID
                                  P_ACCOUNT_CODE         IN VARCHAR2, --账户编码
                                  P_CUSTOMER_CODE        IN VARCHAR2, --客户编码
                                  P_ERP_SUBINV_CODE      IN VARCHAR2, --ERP库存组织
                                  P_STATUS               IN VARCHAR2, --源单状态标识： 已签收  RECEIVED; 已开票  INVOICED
                                  P_ITEM_CODE            IN VARCHAR2, --产品编码
                                  P_ITEM_RETURN_QTY      IN NUMBER, --退货数量
                                  P_USER_CODE            IN VARCHAR2, --操作用户编码
                                  P_ENTITY_CUST_FLAG     IN VARCHAR2,--事业部客户标识
                                  P_CUSTOMER_CHANNEL_TYPE IN VARCHAR2,--经营渠道类型,网批类型的源单只能给网批退货使用
                                  P_TRX_MODE             IN VARCHAR2,--营销模式标识：PUSH 推式，PULL 拉式
                                  P_FACTORY_OU_ID        IN NUMBER,  --工厂OU ID
                                  P_ERP_OU_ID            IN NUMBER,  --客户OU ID
                                  P_RETURN_SRC_SO_NUM    IN VARCHAR2,--退货单源单（指定退货源单场景）
                                  P_RETURNABLE_QTY       OUT NUMBER, --可退货数量
                                  P_SO_LINE_ID           OUT VARCHAR2, --源单号
                                  P_RESULT               OUT NUMBER, --返回错误ID
                                  P_ERR_MSG              OUT VARCHAR2 --返回错误信息
                                  ) IS
    --可退货数量
    V_RETURNABLE_QTY NUMBER := 0;
    --记录已经找到的可退货产品数量，临时变量
    V_RETURNABLE_TEMP_QTY NUMBER := 0;
    --源单号
    V_SO_LINE_ID VARCHAR2(4000) := '';

  BEGIN
    P_RESULT  := V_RESULT;
    P_ERR_MSG := V_SUCCESS;
    
    --判定是否指定源单退货的场景
    IF (P_RETURN_SRC_SO_NUM IS NOT NULL AND LENGTH(P_RETURN_SRC_SO_NUM) > 0) THEN
        
      FOR REC IN (
                  SELECT H.SO_NUM,
                         H.SO_HEADER_ID,
                         H.ENTITY_ID,
                         L.SO_LINE_ID,
                         H.BILL_TYPE_ID,
                         NVL(H.RECEIVE_FLAG, 'N') RECEIVE_FLAG,
                         NVL(H.INVOICE_NUM_LIST, '-') INVOICE_NUM_LIST,
                         L.ITEM_ID,
                         L.ITEM_CODE,
                         L.ITEM_NAME,
                         (NVL(L.ITEM_QTY, 0) - NVL(L.REVERSAL_QTY, 0) -
                         NVL(L.RETURN_QTY, 0)) AS RETURNABLE_QTY
                    FROM T_SO_HEADER H, T_SO_LINE L
                   WHERE H.SO_HEADER_ID = L.SO_HEADER_ID
                     AND ((H.TRX_MODE = 'PUSH' AND H.ERP_OU_ID = P_ERP_OU_ID)
                         OR (H.TRX_MODE = 'PULL' AND H.ERP_OU_ID = P_ERP_OU_ID AND H.FACTORY_OU_ID = P_FACTORY_OU_ID))
                     AND NVL(H.RECEIVE_FLAG, 'N') = 'Y' --为了差异签收开退货单与人工开退货单找到相同的源单，添加了源单必须是‘已签收’状态，2016-02-27 zhoujg3
                     AND NVL(L.RETURN_FLAG, 'N') = 'N'
                     /*AND L.RECEIVED_DATE IS NOT NULL*/
                     AND (NVL(L.ITEM_QTY, 0) - NVL(L.REVERSAL_QTY, 0) - NVL(L.RETURN_QTY, 0)) > 0
                     /**
                      源单关联物流处理成功判定(退货会取对应源单的关联物流信息)
                      1、推式事业部关联交易客户 ERP_LOGIST_HEADER_ID2 不为空
                      2、拉式外部客户  ERP_LOGIST_HEADER_ID 不为空
                      3、拉式事业部关联交易客户  ERP_LOGIST_HEADER_ID , ERP_LOGIST_HEADER_ID2 都不为空
                     */
                     AND ((H.TRX_MODE = 'PUSH' AND NVL(H.ENTITY_CUST_FLAG,'N') = 'Y' AND H.ERP_LOGIST_HEADER_ID2 IS NOT NULL)
                      OR (H.TRX_MODE = 'PULL' AND NVL(H.ENTITY_CUST_FLAG,'N') = 'N' AND H.ERP_LOGIST_HEADER_ID IS NOT NULL)
                      OR (H.TRX_MODE = 'PULL' AND NVL(H.ENTITY_CUST_FLAG,'N') = 'Y' AND H.ERP_LOGIST_HEADER_ID2 IS NOT NULL AND H.ERP_LOGIST_HEADER_ID IS NOT NULL)) 
                     AND H.SO_STATUS = '12'
                     AND NVL(H.INVOICE_NUM_LIST,'-') != '-' --源单规则统一为：已结算开票(主体参数SO_RETURN_FETCH_SRC_STATUS 不再起作用)  add by zhoujg3   2015-09-11
                     AND NVL(H.ENTITY_CUST_FLAG,'N') = P_ENTITY_CUST_FLAG
                     AND DECODE(NVL(H.CUSTOMER_CHANNEL_TYPE,'O'),'15','15','O') = DECODE(NVL(P_CUSTOMER_CHANNEL_TYPE,'O'),'15','15','O')
                     AND H.TRX_MODE = P_TRX_MODE
                     AND H.ERP_SUBINV_CODE = P_ERP_SUBINV_CODE
                     AND L.ITEM_CODE = P_ITEM_CODE
                     AND H.ACCOUNT_CODE = P_ACCOUNT_CODE
                     AND H.CUSTOMER_CODE = P_CUSTOMER_CODE
                     AND H.BIZ_SRC_BILL_TYPE_CODE = PKG_SO_PUB.V_BIZ_SRC_BILL_SO
                     AND H.ENTITY_ID = P_ENTITY_ID
                     AND H.SO_NUM IN (P_RETURN_SRC_SO_NUM)
                   ORDER BY H.CREATION_DATE DESC
                              ) LOOP

        -- 记录已经找到的可退货产品数量
        V_RETURNABLE_TEMP_QTY := V_RETURNABLE_QTY;
        V_RETURNABLE_QTY := V_RETURNABLE_QTY +
                            REC.RETURNABLE_QTY;
        -- 记录所有找到的源单行ID
        V_SO_LINE_ID := V_SO_LINE_ID || REC.SO_NUM || ',' ||
                        REC.SO_LINE_ID || ';';
          
          -- 找到的源单还不足：产品退货数量[P_ITEM_RETURN_QTY]大于等于当前找到的可退货产品数量[V_RETURNABLE_QTY]
          IF (V_RETURNABLE_QTY < P_ITEM_RETURN_QTY) THEN
            UPDATE T_SO_LINE LINE
               SET LINE.RETURN_QTY =
                   (NVL(LINE.RETURN_QTY, 0) +
                   REC.RETURNABLE_QTY),
                   LINE.RETURN_FLAG = 'Y'
             WHERE LINE.SO_LINE_ID = REC.SO_LINE_ID;
            
            -- 找到源单后，需要记录到退货产品来源单表（T_SO_RETURN_ITEM_SRC）
            INSERT INTO T_SO_RETURN_ITEM_SRC
              (SRC_ID,
               RETURN_APPLY_BILL_NUM,
               ENTITY_ID,
               SO_LINE_ID,
               RETURN_SRC_BILL_TYPE_ID,
               RETURN_SRC_BILL_ID,
               RETURN_SRC_BILL_NUM,
               ITEM_ID,
               ITEM_CODE,
               ITEM_NAME,
               RETURN_ITEM_AMOUNT,
               CREATED_BY,
               CREATION_DATE,
               LAST_UPDATED_BY,
               LAST_UPDATE_DATE,
               TO_RETURN_BILL_FLAG)
            VALUES
              (S_SO_RETURN_ITEM_SRC.NEXTVAL,
               P_RETURN_APPLY_BILLNUM,
               REC.ENTITY_ID,
               REC.SO_LINE_ID,
               REC.BILL_TYPE_ID,
               REC.SO_HEADER_ID,
               REC.SO_NUM,
               REC.ITEM_ID,
               REC.ITEM_CODE,
               REC.ITEM_NAME,
               REC.RETURNABLE_QTY,
               P_USER_CODE,
               SYSDATE,
               P_USER_CODE,
               SYSDATE,
               PKG_SO_PUB.V_NO);
            
            -- 找到足够的源单：产品退货数量[P_ITEM_RETURN_QTY]小于当前找到的可退货产品数量[V_RETURNABLE_QTY]
          ELSIF (V_RETURNABLE_QTY >= P_ITEM_RETURN_QTY) THEN
            UPDATE T_SO_LINE LINE
               SET LINE.RETURN_QTY =
                   (NVL(LINE.RETURN_QTY, 0) +
                   (P_ITEM_RETURN_QTY - V_RETURNABLE_TEMP_QTY))
             WHERE LINE.SO_LINE_ID = REC.SO_LINE_ID;
            V_RETURNABLE_QTY := P_ITEM_RETURN_QTY;
            
            -- 找到源单后，需要记录到退货产品来源单表（T_SO_RETURN_ITEM_SRC）
            INSERT INTO T_SO_RETURN_ITEM_SRC
              (SRC_ID,
               RETURN_APPLY_BILL_NUM,
               ENTITY_ID,
               SO_LINE_ID,
               RETURN_SRC_BILL_TYPE_ID,
               RETURN_SRC_BILL_ID,
               RETURN_SRC_BILL_NUM,
               ITEM_ID,
               ITEM_CODE,
               ITEM_NAME,
               RETURN_ITEM_AMOUNT,
               CREATED_BY,
               CREATION_DATE,
               LAST_UPDATED_BY,
               LAST_UPDATE_DATE,
               TO_RETURN_BILL_FLAG)
            VALUES
              (S_SO_RETURN_ITEM_SRC.NEXTVAL,
               P_RETURN_APPLY_BILLNUM,
               REC.ENTITY_ID,
               REC.SO_LINE_ID,
               REC.BILL_TYPE_ID,
               REC.SO_HEADER_ID,
               REC.SO_NUM,
               REC.ITEM_ID,
               REC.ITEM_CODE,
               REC.ITEM_NAME,
               (P_ITEM_RETURN_QTY - V_RETURNABLE_TEMP_QTY),
               P_USER_CODE,
               SYSDATE,
               P_USER_CODE,
               SYSDATE,
               PKG_SO_PUB.V_NO);
            
          EXIT;
        END IF;

        
      END LOOP;
    
    ELSE
      
      FOR REC IN (
                  SELECT H.SO_NUM,
                         H.SO_HEADER_ID,
                         H.ENTITY_ID,
                         L.SO_LINE_ID,
                         H.BILL_TYPE_ID,
                         NVL(H.RECEIVE_FLAG, 'N') RECEIVE_FLAG,
                         NVL(H.INVOICE_NUM_LIST, '-') INVOICE_NUM_LIST,
                         L.ITEM_ID,
                         L.ITEM_CODE,
                         L.ITEM_NAME,
                         (NVL(L.ITEM_QTY, 0) - NVL(L.REVERSAL_QTY, 0) -
                         NVL(L.RETURN_QTY, 0)) AS RETURNABLE_QTY
                    FROM T_SO_HEADER H, T_SO_LINE L
                   WHERE H.SO_HEADER_ID = L.SO_HEADER_ID
                     AND ((H.TRX_MODE = 'PUSH' AND H.ERP_OU_ID = P_ERP_OU_ID)
                         OR (H.TRX_MODE = 'PULL' AND H.ERP_OU_ID = P_ERP_OU_ID AND H.FACTORY_OU_ID = P_FACTORY_OU_ID))
                     AND NVL(H.RECEIVE_FLAG, 'N') = 'Y' --为了差异签收开退货单与人工开退货单找到相同的源单，添加了源单必须是‘已签收’状态，2016-02-27 zhoujg3
                     AND NVL(L.RETURN_FLAG, 'N') = 'N'
                     AND L.RECEIVED_DATE IS NOT NULL
                     AND (NVL(L.ITEM_QTY, 0) - NVL(L.REVERSAL_QTY, 0) - NVL(L.RETURN_QTY, 0)) > 0
                     /**
                      源单关联物流处理成功判定(退货会取对应源单的关联物流信息)
                      1、推式事业部关联交易客户 ERP_LOGIST_HEADER_ID2 不为空
                      2、拉式外部客户  ERP_LOGIST_HEADER_ID 不为空
                      3、拉式事业部关联交易客户  ERP_LOGIST_HEADER_ID , ERP_LOGIST_HEADER_ID2 都不为空
                     */
                     AND ((H.TRX_MODE = 'PUSH' AND NVL(H.ENTITY_CUST_FLAG,'N') = 'Y' AND H.ERP_LOGIST_HEADER_ID2 IS NOT NULL)
                      OR (H.TRX_MODE = 'PULL' AND NVL(H.ENTITY_CUST_FLAG,'N') = 'N' AND H.ERP_LOGIST_HEADER_ID IS NOT NULL)
                      OR (H.TRX_MODE = 'PULL' AND NVL(H.ENTITY_CUST_FLAG,'N') = 'Y' AND H.ERP_LOGIST_HEADER_ID2 IS NOT NULL AND H.ERP_LOGIST_HEADER_ID IS NOT NULL)) 
                     AND H.SO_STATUS = '12'
                     AND NVL(H.INVOICE_NUM_LIST,'-') != '-' --源单规则统一为：已结算开票(主体参数SO_RETURN_FETCH_SRC_STATUS 不再起作用)  add by zhoujg3   2015-09-11
                     AND NVL(H.ENTITY_CUST_FLAG,'N') = P_ENTITY_CUST_FLAG
                     AND DECODE(NVL(H.CUSTOMER_CHANNEL_TYPE,'O'),'15','15','O') = DECODE(NVL(P_CUSTOMER_CHANNEL_TYPE,'O'),'15','15','O')
                     AND H.TRX_MODE = P_TRX_MODE
                     AND H.ERP_SUBINV_CODE = P_ERP_SUBINV_CODE
                     AND L.ITEM_CODE = P_ITEM_CODE
                     AND H.ACCOUNT_CODE = P_ACCOUNT_CODE
                     AND H.CUSTOMER_CODE = P_CUSTOMER_CODE
                     AND H.BIZ_SRC_BILL_TYPE_CODE = PKG_SO_PUB.V_BIZ_SRC_BILL_SO
                     AND H.ENTITY_ID = P_ENTITY_ID
                   ORDER BY H.CREATION_DATE DESC
                              ) LOOP

        -- 记录已经找到的可退货产品数量
        V_RETURNABLE_TEMP_QTY := V_RETURNABLE_QTY;
        V_RETURNABLE_QTY := V_RETURNABLE_QTY +
                            REC.RETURNABLE_QTY;
        -- 记录所有找到的源单行ID
        V_SO_LINE_ID := V_SO_LINE_ID || REC.SO_NUM || ',' ||
                        REC.SO_LINE_ID || ';';
          
          -- 找到的源单还不足：产品退货数量[P_ITEM_RETURN_QTY]大于等于当前找到的可退货产品数量[V_RETURNABLE_QTY]
          IF (V_RETURNABLE_QTY < P_ITEM_RETURN_QTY) THEN
            UPDATE T_SO_LINE LINE
               SET LINE.RETURN_QTY =
                   (NVL(LINE.RETURN_QTY, 0) +
                   REC.RETURNABLE_QTY),
                   LINE.RETURN_FLAG = 'Y'
             WHERE LINE.SO_LINE_ID = REC.SO_LINE_ID;
            
            -- 找到源单后，需要记录到退货产品来源单表（T_SO_RETURN_ITEM_SRC）
            INSERT INTO T_SO_RETURN_ITEM_SRC
              (SRC_ID,
               RETURN_APPLY_BILL_NUM,
               ENTITY_ID,
               SO_LINE_ID,
               RETURN_SRC_BILL_TYPE_ID,
               RETURN_SRC_BILL_ID,
               RETURN_SRC_BILL_NUM,
               ITEM_ID,
               ITEM_CODE,
               ITEM_NAME,
               RETURN_ITEM_AMOUNT,
               CREATED_BY,
               CREATION_DATE,
               LAST_UPDATED_BY,
               LAST_UPDATE_DATE,
               TO_RETURN_BILL_FLAG)
            VALUES
              (S_SO_RETURN_ITEM_SRC.NEXTVAL,
               P_RETURN_APPLY_BILLNUM,
               REC.ENTITY_ID,
               REC.SO_LINE_ID,
               REC.BILL_TYPE_ID,
               REC.SO_HEADER_ID,
               REC.SO_NUM,
               REC.ITEM_ID,
               REC.ITEM_CODE,
               REC.ITEM_NAME,
               REC.RETURNABLE_QTY,
               P_USER_CODE,
               SYSDATE,
               P_USER_CODE,
               SYSDATE,
               PKG_SO_PUB.V_NO);
            
            -- 找到足够的源单：产品退货数量[P_ITEM_RETURN_QTY]小于当前找到的可退货产品数量[V_RETURNABLE_QTY]
          ELSIF (V_RETURNABLE_QTY >= P_ITEM_RETURN_QTY) THEN
            UPDATE T_SO_LINE LINE
               SET LINE.RETURN_QTY =
                   (NVL(LINE.RETURN_QTY, 0) +
                   (P_ITEM_RETURN_QTY - V_RETURNABLE_TEMP_QTY))
             WHERE LINE.SO_LINE_ID = REC.SO_LINE_ID;
            V_RETURNABLE_QTY := P_ITEM_RETURN_QTY;
            
            -- 找到源单后，需要记录到退货产品来源单表（T_SO_RETURN_ITEM_SRC）
            INSERT INTO T_SO_RETURN_ITEM_SRC
              (SRC_ID,
               RETURN_APPLY_BILL_NUM,
               ENTITY_ID,
               SO_LINE_ID,
               RETURN_SRC_BILL_TYPE_ID,
               RETURN_SRC_BILL_ID,
               RETURN_SRC_BILL_NUM,
               ITEM_ID,
               ITEM_CODE,
               ITEM_NAME,
               RETURN_ITEM_AMOUNT,
               CREATED_BY,
               CREATION_DATE,
               LAST_UPDATED_BY,
               LAST_UPDATE_DATE,
               TO_RETURN_BILL_FLAG)
            VALUES
              (S_SO_RETURN_ITEM_SRC.NEXTVAL,
               P_RETURN_APPLY_BILLNUM,
               REC.ENTITY_ID,
               REC.SO_LINE_ID,
               REC.BILL_TYPE_ID,
               REC.SO_HEADER_ID,
               REC.SO_NUM,
               REC.ITEM_ID,
               REC.ITEM_CODE,
               REC.ITEM_NAME,
               (P_ITEM_RETURN_QTY - V_RETURNABLE_TEMP_QTY),
               P_USER_CODE,
               SYSDATE,
               P_USER_CODE,
               SYSDATE,
               PKG_SO_PUB.V_NO);
            
          EXIT;
        END IF;

        
      END LOOP;
    
    END IF;


    P_RETURNABLE_QTY := V_RETURNABLE_QTY;
    P_SO_LINE_ID     := V_SO_LINE_ID;
  EXCEPTION
    WHEN OTHERS THEN
      P_RETURNABLE_QTY := 0;
      P_SO_LINE_ID     := '';
      P_RESULT         := -28866;
      P_ERR_MSG        := '主体=' || P_ENTITY_ID || ',客户编码=' ||
                          P_CUSTOMER_CODE || ',账户=' || P_ACCOUNT_CODE || ',ERP库存组织=' || P_ERP_SUBINV_CODE || ',产品编码=' || P_ITEM_CODE ||
                          ',退货数量=' || P_ITEM_RETURN_QTY || ',操作用户编码=' || P_USER_CODE || ',指定源单[' || P_RETURN_SRC_SO_NUM || '],退货找源单时发生异常！' || SQLERRM;
  END;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2017-06-14
  *     创建者：周建刚
  *   功能说明：[退货找源单]退货申请审核是校验是否有足够的源单可退货
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_FETCH_RETURN_SRC_CHECK(P_ENTITY_ID      IN NUMBER, --主体ID
                                        P_ACCOUNT_CODE         IN VARCHAR2, --账户编码
                                        P_CUSTOMER_CODE        IN VARCHAR2, --客户编码
                                        P_ERP_SUBINV_CODE      IN VARCHAR2, --ERP库存组织
                                        P_ITEM_CODE            IN VARCHAR2, --产品编码
                                        P_USER_CODE            IN VARCHAR2, --操作用户编码
                                        P_ENTITY_CUST_FLAG     IN VARCHAR2,--事业部客户标识
                                        P_CUSTOMER_CHANNEL_TYPE IN VARCHAR2,--经营渠道类型,网批类型的源单只能给网批退货使用
                                        P_TRX_MODE             IN VARCHAR2,--营销模式标识：PUSH 推式，PULL 拉式
                                        P_RETURN_SRC_SO_NUM    IN VARCHAR2,--退货单源单（指定退货源单场景）
                                        P_RETURNABLE_QTY       OUT NUMBER, --可退货数量
                                        P_RESULT               OUT NUMBER, --返回错误ID
                                        P_ERR_MSG              OUT VARCHAR2 --返回错误信息
                                        ) IS
                                        
    V_RECEICE_COUNT  NUMBER :=0;

  BEGIN
    P_RESULT         := V_RESULT;
    P_ERR_MSG        := V_SUCCESS;
    P_RETURNABLE_QTY := 0;
        
    --判定是否指定源单退货的场景
    IF (P_RETURN_SRC_SO_NUM IS NOT NULL AND LENGTH(P_RETURN_SRC_SO_NUM) > 0) THEN
    
      SELECT NVL(SUM((NVL(L.ITEM_QTY, 0) - NVL(L.REVERSAL_QTY, 0) -
             NVL(L.RETURN_QTY, 0))),0) INTO P_RETURNABLE_QTY
        FROM T_SO_HEADER H, T_SO_LINE L
       WHERE H.SO_HEADER_ID = L.SO_HEADER_ID
         AND NVL(H.RECEIVE_FLAG, 'N') = 'Y' --为了差异签收开退货单与人工开退货单找到相同的源单，添加了源单必须是‘已签收’状态，2016-02-27 zhoujg3
         AND NVL(L.RETURN_FLAG, 'N') = 'N'
         /*AND L.RECEIVED_DATE IS NOT NULL*/
         AND (NVL(L.ITEM_QTY, 0) - NVL(L.REVERSAL_QTY, 0) - NVL(L.RETURN_QTY, 0)) > 0
         /**
          源单关联物流处理成功判定(退货会取对应源单的关联物流信息)
          1、推式事业部关联交易客户 ERP_LOGIST_HEADER_ID2 不为空
          2、拉式外部客户  ERP_LOGIST_HEADER_ID 不为空
          3、拉式事业部关联交易客户  ERP_LOGIST_HEADER_ID , ERP_LOGIST_HEADER_ID2 都不为空
         */
         AND ((H.TRX_MODE = 'PUSH' AND NVL(H.ENTITY_CUST_FLAG,'N') = 'Y' AND H.ERP_LOGIST_HEADER_ID2 IS NOT NULL)
          OR (H.TRX_MODE = 'PULL' AND NVL(H.ENTITY_CUST_FLAG,'N') = 'N' AND H.ERP_LOGIST_HEADER_ID IS NOT NULL)
          OR (H.TRX_MODE = 'PULL' AND NVL(H.ENTITY_CUST_FLAG,'N') = 'Y' AND H.ERP_LOGIST_HEADER_ID2 IS NOT NULL AND H.ERP_LOGIST_HEADER_ID IS NOT NULL)) 
         AND H.SO_STATUS = '12'
         AND NVL(H.INVOICE_NUM_LIST,'-') != '-' --源单规则统一为：已结算开票(主体参数SO_RETURN_FETCH_SRC_STATUS 不再起作用)  add by zhoujg3   2015-09-11
         AND NVL(H.ENTITY_CUST_FLAG,'N') = P_ENTITY_CUST_FLAG
         AND DECODE(NVL(H.CUSTOMER_CHANNEL_TYPE,'O'),'15','15','O') = DECODE(NVL(P_CUSTOMER_CHANNEL_TYPE,'O'),'15','15','O')
         AND H.TRX_MODE = P_TRX_MODE
         AND H.ERP_SUBINV_CODE = P_ERP_SUBINV_CODE
         AND L.ITEM_CODE = P_ITEM_CODE
         AND H.ACCOUNT_CODE = P_ACCOUNT_CODE
         AND H.CUSTOMER_CODE = P_CUSTOMER_CODE
         AND H.BIZ_SRC_BILL_TYPE_CODE = PKG_SO_PUB.V_BIZ_SRC_BILL_SO
         AND H.ENTITY_ID = P_ENTITY_ID
         AND H.SO_NUM IN (NVL(P_RETURN_SRC_SO_NUM,H.SO_NUM));
    
    ELSE
    
      SELECT NVL(SUM((NVL(NVL(L.RECEIVED_QTY,L.ITEM_QTY), 0) - NVL(L.REVERSAL_QTY, 0) -
             NVL(L.RETURN_QTY, 0))),0) INTO P_RETURNABLE_QTY
        FROM T_SO_HEADER H, T_SO_LINE L
       WHERE H.SO_HEADER_ID = L.SO_HEADER_ID
         AND NVL(H.RECEIVE_FLAG, 'N') = 'Y' --为了差异签收开退货单与人工开退货单找到相同的源单，添加了源单必须是‘已签收’状态，2016-02-27 zhoujg3
         AND NVL(L.RETURN_FLAG, 'N') = 'N'
         AND L.RECEIVED_DATE IS NOT NULL
         AND (NVL(NVL(L.RECEIVED_QTY,L.ITEM_QTY), 0) - NVL(L.REVERSAL_QTY, 0) - NVL(L.RETURN_QTY, 0)) > 0
         /**
          源单关联物流处理成功判定(退货会取对应源单的关联物流信息)
          1、推式事业部关联交易客户 ERP_LOGIST_HEADER_ID2 不为空
          2、拉式外部客户  ERP_LOGIST_HEADER_ID 不为空
          3、拉式事业部关联交易客户  ERP_LOGIST_HEADER_ID , ERP_LOGIST_HEADER_ID2 都不为空
         */
         AND ((H.TRX_MODE = 'PUSH' AND NVL(H.ENTITY_CUST_FLAG,'N') = 'Y' AND H.ERP_LOGIST_HEADER_ID2 IS NOT NULL)
          OR (H.TRX_MODE = 'PULL' AND NVL(H.ENTITY_CUST_FLAG,'N') = 'N' AND H.ERP_LOGIST_HEADER_ID IS NOT NULL)
          OR (H.TRX_MODE = 'PULL' AND NVL(H.ENTITY_CUST_FLAG,'N') = 'Y' AND H.ERP_LOGIST_HEADER_ID2 IS NOT NULL AND H.ERP_LOGIST_HEADER_ID IS NOT NULL)) 
         AND H.SO_STATUS = '12'
         AND NVL(H.INVOICE_NUM_LIST,'-') != '-' --源单规则统一为：已结算开票(主体参数SO_RETURN_FETCH_SRC_STATUS 不再起作用)  add by zhoujg3   2015-09-11
         AND NVL(H.ENTITY_CUST_FLAG,'N') = P_ENTITY_CUST_FLAG
         AND DECODE(NVL(H.CUSTOMER_CHANNEL_TYPE,'O'),'15','15','O') = DECODE(NVL(P_CUSTOMER_CHANNEL_TYPE,'O'),'15','15','O')
         AND H.TRX_MODE = P_TRX_MODE
         AND H.ERP_SUBINV_CODE = P_ERP_SUBINV_CODE
         AND L.ITEM_CODE = P_ITEM_CODE
         AND H.ACCOUNT_CODE = P_ACCOUNT_CODE
         AND H.CUSTOMER_CODE = P_CUSTOMER_CODE
         AND H.BIZ_SRC_BILL_TYPE_CODE = PKG_SO_PUB.V_BIZ_SRC_BILL_SO
         AND H.ENTITY_ID = P_ENTITY_ID;
       
    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      P_RETURNABLE_QTY := -1;
      P_RESULT         := -28866;
      P_ERR_MSG        := '主体=' || P_ENTITY_ID || ',客户编码=' ||
                          P_CUSTOMER_CODE || ',账户=' || P_ACCOUNT_CODE || ',ERP库存组织=' || P_ERP_SUBINV_CODE || ',产品编码=' || P_ITEM_CODE ||
                          ',营销模式=' || P_TRX_MODE || ',事业部属性=' || P_ENTITY_CUST_FLAG || ',操作用户编码=' || P_USER_CODE || ',指定源单[' || P_RETURN_SRC_SO_NUM || '],退货获取可退货源单数量时发生异常！' || SQLERRM;
  END;
  

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2019-03-13
  *     创建者：周建刚
  *   功能说明：更新签收日期
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_UPDATE_RECEIVE_DATE(P_SO_NUM               IN VARCHAR2,
                                     P_RECEIVE_DATE         IN VARCHAR2,
                                     P_RESULT               OUT NUMBER, --返回错误ID
                                     P_ERR_MSG              OUT VARCHAR2 --返回错误信息
                                     ) IS

  BEGIN
    P_RESULT         := V_RESULT;
    P_ERR_MSG        := V_SUCCESS;
    
    UPDATE CIMS.T_SO_LINE L
       SET L.RECEIVED_DATE    = TO_DATE(P_RECEIVE_DATE, 'yyyy-MM-dd'),
           L.LAST_UPDATE_DATE = SYSDATE
     WHERE EXISTS (SELECT 1
              FROM CIMS.T_SO_HEADER H
             WHERE H.SO_HEADER_ID = L.SO_HEADER_ID
               AND H.SO_NUM = P_SO_NUM);
  EXCEPTION
    WHEN OTHERS THEN
      P_RESULT         := -28866;
      P_ERR_MSG        := '更新单据[' || P_SO_NUM || '],签收信息发生异常！' || SQLERRM;
      
  END;
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-01-29
  *     创建者：周建刚
  *   功能说明：根据蓝单单号获取对应的红冲单信息
  *     返回值：
  */
  -------------------------------------------------------------------------------
  FUNCTION F_RED_SO_NUM_INFO(P_SO_NUM IN VARCHAR2) RETURN VARCHAR2 IS
    V_SO_NUM T_SO_HEADER.SO_NUM%TYPE := '';
    --财务单头表收信息游标
    CURSOR C_SO_HEADER IS
      SELECT T.*
        FROM T_SO_HEADER T
       WHERE T.ORIG_SO_NUM = P_SO_NUM
         AND (T.BIZ_SRC_BILL_TYPE_CODE = PKG_SO_PUB.V_BIZ_SRC_BILL_SO_RED OR
             T.BIZ_SRC_BILL_TYPE_CODE =
             PKG_SO_PUB.V_BIZ_SRC_BILL_RETURN_RED OR
             T.BIZ_SRC_BILL_TYPE_CODE =
             PKG_SO_PUB.V_BIZ_SRC_BILL_SO_DISCOUNT_RED OR
             T.BIZ_SRC_BILL_TYPE_CODE =
             PKG_SO_PUB.V_BIZ_SRC_BILL_DISCOUNT_RED OR
             T.BIZ_SRC_BILL_TYPE_CODE = PKG_SO_PUB.V_BIZ_SRC_BILL_RATE_RED);
    --财务单头表信息记录
    R_SO_HEADER C_SO_HEADER%ROWTYPE;
  
  BEGIN
    OPEN C_SO_HEADER;
    LOOP
      FETCH C_SO_HEADER
        INTO R_SO_HEADER;
      EXIT WHEN C_SO_HEADER%NOTFOUND;
    
      V_SO_NUM := V_SO_NUM || '被' || R_SO_HEADER.SO_NUM || '红冲,';
    END LOOP;
    CLOSE C_SO_HEADER;
  
    RETURN V_SO_NUM;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      V_SO_NUM := '';
      RETURN V_SO_NUM;
    WHEN OTHERS THEN
      RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
  END;
  
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2016-08-18
  *     创建者：周建刚
  *   功能说明：1、判断客户是否为内部关联交易客户
  *             2、校验客户、账户是否有效；Y 客户、账户为正常；N 为客户或账户失效、不存在等
  *             3、事业部客户标识 P_ENTITY_CUST_FLAG : Y 内部客户；N 普通客户
  *   使用说明：
  *             1、P_RESULT = 0  校验和判断功能处理成功。 
  *                   [P_CUST_CHECK_FLAG]  Y 客户、账户为正常；N 为客户或账户失效、不存在等，具体异常信息提示查看P_CUST_CHECK_MSG
  *                   [P_ENTITY_CUST_FLAG] Y 内部客户；N 普通客户
  *             2、P_RESULT != 0 校验和判断功能处理失败。具体错误信息查看P_ERR_MSG，此时 无需关注 P_CUST_CHECK_FLAG ,P_ENTITY_CUST_FLAG 的具体值。
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_ENTITY_CUST_INFO(P_ENTITY_ID            IN NUMBER,    --主体ID
                                  P_CUSTOMER_ID          IN NUMBER,    --客户ID
                                  P_ACCOUNT_ID           IN NUMBER,    --账户ID
                                  P_SALES_CENTER_ID      IN NUMBER,    --营销中心ID
                                  P_INV_ID               IN NUMBER,    --仓库ID
                                  P_CUST_CHECK_FLAG      OUT VARCHAR2, --客户、账户校验结果标识: Y 为正常，N 为客户或账户失效、不存在等
                                  P_CUST_CHECK_MSG       OUT VARCHAR2, --与P_CUST_CHECK_FLAG，对应的校验结果提示
                                  P_ENTITY_CUST_FLAG     OUT VARCHAR2, --事业部客户标识: N 普通客户，Y 内部关联交易客户
                                  P_RESULT               OUT NUMBER,   --返回错误ID
                                  P_ERR_MSG              OUT VARCHAR2  --返回错误信息
                                  ) IS
    --客户头表信息记录
    R_CUSTOMER_HEADER T_CUSTOMER_HEADER%ROWTYPE;
    --客户、账户、营销中心信息记录
    R_CUSTOMER_ACCOUNT_SALECENTER V_CUSTOMER_ACCOUNT_SALECENTER%ROWTYPE;
  BEGIN
    P_RESULT  := V_RESULT;
    P_ERR_MSG := V_SUCCESS;

    -- 校验客户、账户、中心是否有效
    P_SO_ENTITY_CUST_CHECK(P_ENTITY_ID,P_CUSTOMER_ID,P_ACCOUNT_ID,P_SALES_CENTER_ID,
                           P_CUST_CHECK_FLAG,P_CUST_CHECK_MSG,P_RESULT,P_ERR_MSG);    
    PKG_SO_PUB.P_EXCEPTION_THROWS(P_RESULT);
    
    SELECT T.* INTO R_CUSTOMER_HEADER
      FROM T_CUSTOMER_HEADER T
     WHERE T.CUSTOMER_ID = P_CUSTOMER_ID;
     
    SELECT S.* INTO R_CUSTOMER_ACCOUNT_SALECENTER
      FROM V_CUSTOMER_ACCOUNT_SALECENTER S
     WHERE S.ENTITY_ID = P_ENTITY_ID
       AND S.CUSTOMER_ID = P_CUSTOMER_ID
       AND S.ACCOUNT_ID = P_ACCOUNT_ID
       AND S.SALES_CENTER_ID = P_SALES_CENTER_ID;
         
    -- 内部关联交易客户，配置信息校验
    IF (PKG_SO_PUB.V_YES = R_CUSTOMER_HEADER.CUSTOMER_IS_INTERNAL) THEN
        P_SO_GET_ENTITY_CUST_FLAG(P_ENTITY_ID,P_INV_ID,R_CUSTOMER_ACCOUNT_SALECENTER.CUSTOMER_CODE,
                                  R_CUSTOMER_ACCOUNT_SALECENTER.SALES_CENTER_CODE,P_ENTITY_CUST_FLAG,P_RESULT,P_ERR_MSG);
        PKG_SO_PUB.P_EXCEPTION_THROWS(P_RESULT);
    ELSE 
      P_ENTITY_CUST_FLAG := PKG_SO_PUB.V_NO;
    END IF;
  EXCEPTION
    WHEN PKG_SO_PUB.V_BIZ_EXCEPTION THEN
      P_RESULT  := -28866;
      P_ERR_MSG := '校验主体、客户、账户、仓库时发生异常！主体[' || P_ENTITY_ID || '],客户[' ||
                          P_CUSTOMER_ID || '],账户[' || P_ACCOUNT_ID || '],中心[' || P_SALES_CENTER_ID || '],仓库[' || P_INV_ID || ']' || P_ERR_MSG;
    WHEN OTHERS THEN
      P_RESULT  := -28866;
      P_ERR_MSG := '校验主体、客户、账户、仓库时发生异常！主体[' || P_ENTITY_ID || '],客户[' ||
                          P_CUSTOMER_ID || '],账户[' || P_ACCOUNT_ID || '],中心[' || P_SALES_CENTER_ID || '],仓库[' || P_INV_ID || ']' || SQLERRM;
  END;
  
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2016-11-30
  *     创建者：周建刚
  *   功能说明：获取信息营销OU（客户OU）
                1、推式：根据仓库取客户OU信息
                2、拉式：根据仓库取工厂OU，从工厂OU和营销OU配置关系表取对应的营销OU。
  *             3、推拉结合：根据营销中心编码取财务管理的默认营销OU。如果没有对应配置信息，则根据仓库取工厂OU，从工厂OU和营销OU配置关系表取对应的营销OU。
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_CUST_OU_INFO(P_ENTITY_ID            IN NUMBER,    --主体ID
                              P_SALES_CENTER_ID      IN NUMBER,    --营销中心ID
                              P_INV_ID               IN NUMBER,    --仓库ID
                              P_IS_MATERIAL          IN VARCHAR2,  --是否推广物料。N：不是推广物料单据，Y：是推广物料单据
                              P_OU_ID                OUT NUMBER,   --营销OU（客户OU）ID
                              P_OU_NAME              OUT VARCHAR2, --营销OU（客户OU）名称
                              P_RESULT               OUT NUMBER,   --返回错误ID
                              P_ERR_MSG              OUT VARCHAR2  --返回错误信息
                              ) IS
    V_ERP_OU_ID       NUMBER;       --ERP的OU ID
    V_ERP_OU_NAME     VARCHAR2(240);--ERP的OU名称
    V_FACTORY_OU_ID   NUMBER;
    --V_FACTORY_OU_NAME VARCHAR2(240);
    V_ERP_SUBINV_CODE VARCHAR2(100);--ERP的子库编码
    V_PUSH_OR_PULL    VARCHAR2(32); --营销模式
    R_ORG_UNIT UP_ORG_UNIT%ROWTYPE;
  BEGIN
      P_RESULT  := V_RESULT;
      P_ERR_MSG := V_SUCCESS;
    
      BEGIN
        PKG_BD.P_GET_PARAMETER_VALUE(PKG_SO_PUB.V_ARG_SO_AR_PUSH_OR_PULL,
                                     P_ENTITY_ID,
                                     NULL,
                                     NULL,
                                     V_PUSH_OR_PULL);
      EXCEPTION
        WHEN OTHERS THEN
          P_ERR_MSG := 'SO_AR_PUSH_OR_PULL主体参数,主体id:' ||
                       P_ENTITY_ID || '的参数设置异常，请检查。' ||
                       SQLERRM;
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      END;
      V_PUSH_OR_PULL := TRIM(V_PUSH_OR_PULL);
      IF V_PUSH_OR_PULL NOT IN ('PULL','PUSH','MIXED') THEN
         P_ERR_MSG := 'SO_AR_PUSH_OR_PULL主体参数,参数值:' ||
                       V_PUSH_OR_PULL || ',不在PULL、PUSH、MIXED范围内,请检查。' ||
                       SQLERRM;
         RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      END IF;
  
      --根据仓库获取对应OU信息
      BEGIN
        --获取ERP OU ID、ERP OU名称、ERP子库ID、ERP子库编码、
        SELECT INV_ORG.OPERATING_UNIT, --ERP OU ID
               INV_ORG.OPERATING_UNIT_NAME, --ERP OU名称
               INV_ORG.ORGANIZATION_CODE
          INTO V_ERP_OU_ID,
               V_ERP_OU_NAME,
               V_ERP_SUBINV_CODE
          FROM T_INV_INVENTORIES INV, T_INV_ORGANIZATION INV_ORG
         WHERE INV.ORGANIZATION_ID = INV_ORG.ORGANIZATION_ID
           AND INV.ORGANIZATION_CODE = INV_ORG.ORGANIZATION_CODE
           AND INV.ENTITY_ID = INV_ORG.ENTITY_ID
           AND INV.INVENTORY_ID = P_INV_ID
           AND INV.ENTITY_ID = P_ENTITY_ID
           AND ROWNUM = 1;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          P_ERR_MSG := '仓库[' || P_INV_ID || ']未设置对应的ERP OU信息！';
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
        WHEN OTHERS THEN
          P_ERR_MSG := '获取仓库[' || P_INV_ID || ']对应的ERP OU信息发生异常：' ||
                       SQLERRM;
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      END;
      
      --根据营销中心ID查询营销中心信息
      BEGIN
        SELECT T.*
          INTO R_ORG_UNIT
          FROM UP_ORG_UNIT T
         WHERE T.UNIT_ID = P_SALES_CENTER_ID AND T.ENTITY_ID = P_ENTITY_ID AND ROWNUM = 1;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          P_ERR_MSG := '查询组织表UP_ORG_UNIT失败，未获取到数据！营销中心ID[' || P_SALES_CENTER_ID || '],主体[' || P_ENTITY_ID || ']请核实！';
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
        WHEN OTHERS THEN
          P_ERR_MSG := '查询组织表UP_ORG_UNIT发生异常！营销中心ID[' || P_SALES_CENTER_ID || '],主体[' || P_ENTITY_ID || ']请核实！' ||
                       SQLERRM;
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      END;
      
      --关联交易模式为推拉结合混合模块 同时 财务仓对应库存组织编码以S开头（即营销组织） 则为推式，否则为拉式
      IF V_PUSH_OR_PULL = 'MIXED' THEN
         IF SUBSTR(V_ERP_SUBINV_CODE,1,1)='S' THEN
            V_PUSH_OR_PULL := 'PUSH';  --推式
         ELSE
            V_PUSH_OR_PULL := 'PULL';  --拉式
         END IF;
         
        --混合模式下营销中心必须设置默认OU
        BEGIN
          SELECT R.ERP_OU_ID,R.ERP_OU_NAME
             INTO V_ERP_OU_ID, V_ERP_OU_NAME
             FROM T_AR_OU_RELATION R
             WHERE R.ENTITY_ID = P_ENTITY_ID
             AND R.SALES_CENTER_ID = P_SALES_CENTER_ID
             AND (TRUNC(SYSDATE) BETWEEN R.EFFECTIVE_TIAME AND R.FAILURE_TIME);
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            V_ERP_OU_ID := NULL;
            V_ERP_OU_NAME := NULL;
            P_RESULT  := -28866;
            P_ERR_MSG := '主体[' || P_ENTITY_ID || ']的营销中心[' ||
                         P_SALES_CENTER_ID || ',' || R_ORG_UNIT.CODE || ',' || R_ORG_UNIT.NAME || ']未设置默认OU或者设置已经过期失效，请核实！营销中心默认OU设置，对应菜单：财务管理/收款配置/默认OU配置。';
            RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
          WHEN OTHERS THEN
            V_ERP_OU_ID := NULL;
            V_ERP_OU_NAME := NULL;
            P_RESULT  := -28866;
            P_ERR_MSG := '主体[' || P_ENTITY_ID || ']的营销中心[' ||
                         P_SALES_CENTER_ID || ',' || R_ORG_UNIT.CODE || ',' || R_ORG_UNIT.NAME || ']获取默认OU出错！' || SQLERRM;
            RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
        END;
      END IF;

      IF (V_PUSH_OR_PULL ='PULL' AND P_IS_MATERIAL <> PKG_SO_PUB.V_YES) THEN
        V_FACTORY_OU_ID   := V_ERP_OU_ID;
        --V_FACTORY_OU_NAME := V_ERP_OU_NAME;
        
        BEGIN
          /**
            拉式模式下，获取营销OU信息
            步骤一：根据财务管理/收款配置/默认OU配置: 营销中心查找默认的OU
            步骤二：如果步骤一中没有找到，则从销售管理/基础数据/关联交易供需OU配置：根据供方OU查找到需方OU
          */
          BEGIN
            SELECT R.ERP_OU_ID,R.ERP_OU_NAME
               INTO V_ERP_OU_ID, V_ERP_OU_NAME
               FROM T_AR_OU_RELATION R
               WHERE R.ENTITY_ID = P_ENTITY_ID
               AND R.SALES_CENTER_ID = P_SALES_CENTER_ID
               AND (TRUNC(SYSDATE) BETWEEN R.EFFECTIVE_TIAME AND R.FAILURE_TIME);
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              V_ERP_OU_ID := NULL;
              V_ERP_OU_NAME := NULL;
              DBMS_OUTPUT.PUT_LINE('主体[' || P_ENTITY_ID || ']的营销中心[' ||
                           P_SALES_CENTER_ID || ']不存在默认OU！');
            WHEN OTHERS THEN
              V_ERP_OU_ID := NULL;
              V_ERP_OU_NAME := NULL;
              DBMS_OUTPUT.PUT_LINE('主体[' || P_ENTITY_ID || ']的营销中心[' ||
                           P_SALES_CENTER_ID || ']获取默认OU出错！');
          END;

          --工厂OU和ERP OU
          --拉式正向销售，供方：工厂OU，取需方：内销OU
          IF (V_ERP_OU_ID IS NULL AND V_ERP_OU_NAME IS NULL) THEN
              SELECT T.REQUIREMENT_OU_ID,   --ERP OU  内销
                     T.REQUIREMENT_OU_NAME --ERP OU  内销
                INTO V_ERP_OU_ID, V_ERP_OU_NAME
                FROM T_SO_SUPPLIER_REQUIREMENT T
               WHERE T.ENTITY_ID = P_ENTITY_ID
                 AND T.SUPPLIER_OU_ID = V_FACTORY_OU_ID --供方工厂OU，找需方内销OU
                 AND T.TRADE_MODE_CODE = PKG_SO_PUB.V_SO_TRX_MODE_003; --拉式成品销售
          END IF;

          IF (V_ERP_OU_ID IS NULL AND V_ERP_OU_NAME IS NULL) THEN
            P_ERR_MSG := '营销 OU信息为空！';
            RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
          END IF;
          
        EXCEPTION
          WHEN PKG_SO_PUB.V_BIZ_EXCEPTION THEN
            P_RESULT  := -28866;
            P_ERR_MSG := '拉式模式下，获取营销OU信息失败：' || P_ERR_MSG;
            RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
          WHEN OTHERS THEN
            P_ERR_MSG := '根据主体[' || P_ENTITY_ID || '],营销中心[' || P_SALES_CENTER_ID || '],仓库[' || P_INV_ID || ']获取对应的营销 OU信息发生异常：' || SQLERRM;
            RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
        END;
      END IF;
  
      P_OU_ID   := V_ERP_OU_ID; --营销OU（客户OU）ID
      P_OU_NAME := V_ERP_OU_NAME; --营销OU（客户OU）名称
  EXCEPTION
    WHEN PKG_SO_PUB.V_BIZ_EXCEPTION THEN
      P_RESULT  := -28866;
      P_ERR_MSG := '根据主体[' || P_ENTITY_ID || '],营销中心[' || P_SALES_CENTER_ID || '],仓库[' || P_INV_ID || ']获取对应的营销 OU信息，出错：' || P_ERR_MSG;
    WHEN OTHERS THEN
      P_RESULT  := -28866;
      P_ERR_MSG := '根据主体[' || P_ENTITY_ID || '],营销中心[' || P_SALES_CENTER_ID || '],仓库[' || P_INV_ID || ']获取对应的营销 OU信息发生异常：' || SQLERRM;
  END;
  
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2017-11-08
  *     创建者：周建刚
  *   功能说明：获取信息工厂OU（仓库OU）、营销OU（客户OU）、营销模式（推式、拉式）
                1、推式：根据仓库取客户OU信息
                2、拉式：根据仓库取工厂OU，从工厂OU和营销OU配置关系表取对应的营销OU。
  *             3、推拉结合：根据营销中心编码取财务管理的默认营销OU。如果没有对应配置信息，则根据仓库取工厂OU，从工厂OU和营销OU配置关系表取对应的营销OU。
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_ALL_OU_INFO(P_ENTITY_ID            IN NUMBER,    --主体ID
                             P_SALES_CENTER_ID      IN NUMBER,    --营销中心ID
                             P_INV_ID               IN NUMBER,    --仓库ID
                             P_IS_MATERIAL          IN VARCHAR2,  --是否推广物料。N：不是推广物料单据，Y：是推广物料单据
                             P_FACTORY_OU_ID        OUT NUMBER,   --工厂OU（仓库OU）ID
                             P_FACTORY_OU_NAME      OUT VARCHAR2, --工厂OU（仓库OU）名称
                             P_CUST_OU_ID           OUT NUMBER,   --营销OU（客户OU）ID
                             P_CUST_OU_NAME         OUT VARCHAR2, --营销OU（客户OU）名称
                             P_TRX_MODE             OUT VARCHAR2, --营销模式（推式、拉式）
                             P_RESULT               OUT NUMBER,   --返回错误ID
                             P_ERR_MSG              OUT VARCHAR2  --返回错误信息
                             ) IS
    V_ERP_OU_ID       NUMBER;       --ERP的OU ID
    V_ERP_OU_NAME     VARCHAR2(240);--ERP的OU名称
    V_FACTORY_OU_ID   NUMBER;
    --V_FACTORY_OU_NAME VARCHAR2(240);
    V_ERP_SUBINV_CODE VARCHAR2(100);--ERP的子库编码
    V_PUSH_OR_PULL    VARCHAR2(32); --营销模式
  BEGIN
      P_RESULT  := V_RESULT;
      P_ERR_MSG := V_SUCCESS;
    
      BEGIN
        PKG_BD.P_GET_PARAMETER_VALUE(PKG_SO_PUB.V_ARG_SO_AR_PUSH_OR_PULL,
                                     P_ENTITY_ID,
                                     NULL,
                                     NULL,
                                     V_PUSH_OR_PULL);
      EXCEPTION
        WHEN OTHERS THEN
          P_ERR_MSG := 'SO_AR_PUSH_OR_PULL主体参数,主体id:' ||
                       P_ENTITY_ID || '的参数设置异常，请检查。' ||
                       SQLERRM;
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      END;
      V_PUSH_OR_PULL := TRIM(V_PUSH_OR_PULL);
      IF V_PUSH_OR_PULL NOT IN ('PULL','PUSH','MIXED') THEN
         P_ERR_MSG := 'SO_AR_PUSH_OR_PULL主体参数,参数值:' ||
                       V_PUSH_OR_PULL || ',不在PULL、PUSH、MIXED范围内,请检查。' ||
                       SQLERRM;
         RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      END IF;
  
      --根据仓库获取对应OU信息
      BEGIN
        --获取ERP OU ID、ERP OU名称、ERP子库ID、ERP子库编码、
        SELECT INV_ORG.OPERATING_UNIT, --ERP OU ID
               INV_ORG.OPERATING_UNIT_NAME, --ERP OU名称
               INV_ORG.ORGANIZATION_CODE
          INTO V_ERP_OU_ID,
               V_ERP_OU_NAME,
               V_ERP_SUBINV_CODE
          FROM T_INV_INVENTORIES INV, T_INV_ORGANIZATION INV_ORG
         WHERE INV.ORGANIZATION_ID = INV_ORG.ORGANIZATION_ID
           AND INV.ORGANIZATION_CODE = INV_ORG.ORGANIZATION_CODE
           AND INV.ENTITY_ID = INV_ORG.ENTITY_ID
           AND INV.INVENTORY_ID = P_INV_ID
           AND INV.ENTITY_ID = P_ENTITY_ID
           AND ROWNUM = 1;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          P_ERR_MSG := '仓库[' || P_INV_ID || ']未设置对应的ERP OU信息！';
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
        WHEN OTHERS THEN
          P_ERR_MSG := '获取仓库[' || P_INV_ID || ']对应的ERP OU信息发生异常：' ||
                       SQLERRM;
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      END;
      
      P_FACTORY_OU_ID    := V_ERP_OU_ID;     --工厂OU（仓库OU）ID
      P_FACTORY_OU_NAME  := V_ERP_OU_NAME;   --工厂OU（仓库OU）名称
      
      --关联交易模式为推拉结合混合模块 同时 财务仓对应库存组织编码以S开头（即营销组织） 则为推式，否则为拉式
      IF V_PUSH_OR_PULL = 'MIXED' THEN
         IF SUBSTR(V_ERP_SUBINV_CODE,1,1)='S' THEN
            V_PUSH_OR_PULL := 'PUSH';  --推式
         ELSE
            V_PUSH_OR_PULL := 'PULL';  --拉式
         END IF;
      END IF;
      
      P_TRX_MODE := V_PUSH_OR_PULL;

      IF (V_PUSH_OR_PULL ='PULL' AND P_IS_MATERIAL <> PKG_SO_PUB.V_YES) THEN
        V_FACTORY_OU_ID   := V_ERP_OU_ID;
        --V_FACTORY_OU_NAME := V_ERP_OU_NAME;
        
        BEGIN
          /**
            拉式模式下，获取营销OU信息
            步骤一：根据财务管理/收款配置/默认OU配置: 营销中心查找默认的OU
            步骤二：如果步骤一中没有找到，则从销售管理/基础数据/关联交易供需OU配置：根据供方OU查找到需方OU
          */
          BEGIN
            SELECT R.ERP_OU_ID,R.ERP_OU_NAME
               INTO V_ERP_OU_ID, V_ERP_OU_NAME
               FROM T_AR_OU_RELATION R
               WHERE R.ENTITY_ID = P_ENTITY_ID
               AND R.SALES_CENTER_ID = P_SALES_CENTER_ID
               AND (TRUNC(SYSDATE) BETWEEN R.EFFECTIVE_TIAME AND R.FAILURE_TIME);
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              V_ERP_OU_ID := NULL;
              V_ERP_OU_NAME := NULL;
              DBMS_OUTPUT.PUT_LINE('主体[' || P_ENTITY_ID || ']的营销中心[' ||
                           P_SALES_CENTER_ID || ']不存在默认OU！');
            WHEN OTHERS THEN
              V_ERP_OU_ID := NULL;
              V_ERP_OU_NAME := NULL;
              DBMS_OUTPUT.PUT_LINE('主体[' || P_ENTITY_ID || ']的营销中心[' ||
                           P_SALES_CENTER_ID || ']获取默认OU出错！');
          END;

          --工厂OU和ERP OU
          --拉式正向销售，供方：工厂OU，取需方：内销OU
          IF (V_ERP_OU_ID IS NULL AND V_ERP_OU_NAME IS NULL) THEN
              SELECT T.REQUIREMENT_OU_ID,   --ERP OU  内销
                     T.REQUIREMENT_OU_NAME --ERP OU  内销
                INTO V_ERP_OU_ID, V_ERP_OU_NAME
                FROM T_SO_SUPPLIER_REQUIREMENT T
               WHERE T.ENTITY_ID = P_ENTITY_ID
                 AND T.SUPPLIER_OU_ID = V_FACTORY_OU_ID --供方工厂OU，找需方内销OU
                 AND T.TRADE_MODE_CODE = PKG_SO_PUB.V_SO_TRX_MODE_003; --拉式成品销售
          END IF;

          IF (V_ERP_OU_ID IS NULL AND V_ERP_OU_NAME IS NULL) THEN
            P_ERR_MSG := '营销 OU信息为空！';
            RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
          END IF;
          
        EXCEPTION
          WHEN PKG_SO_PUB.V_BIZ_EXCEPTION THEN
            P_RESULT  := -28866;
            P_ERR_MSG := '拉式模式下，获取营销OU信息失败：' || P_ERR_MSG;
            RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
          WHEN OTHERS THEN
            P_ERR_MSG := '根据主体[' || P_ENTITY_ID || '],营销中心[' || P_SALES_CENTER_ID || '],仓库[' || P_INV_ID || ']获取对应的营销 OU信息发生异常：' || SQLERRM;
            RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
        END;
      END IF;

      P_CUST_OU_ID   := V_ERP_OU_ID; --营销OU（客户OU）ID
      P_CUST_OU_NAME := V_ERP_OU_NAME; --营销OU（客户OU）名称
  EXCEPTION
    WHEN PKG_SO_PUB.V_BIZ_EXCEPTION THEN
      P_RESULT  := -28866;
      P_ERR_MSG := '根据主体[' || P_ENTITY_ID || '],营销中心[' || P_SALES_CENTER_ID || '],仓库[' || P_INV_ID || ']获取对应的营销 OU信息，出错：' || P_ERR_MSG;
    WHEN OTHERS THEN
      P_RESULT  := -28866;
      P_ERR_MSG := '根据主体[' || P_ENTITY_ID || '],营销中心[' || P_SALES_CENTER_ID || '],仓库[' || P_INV_ID || ']获取对应的营销 OU信息发生异常：' || SQLERRM;
  END;
  -------------------------------------------------------------------------------
  /*
  /*
  *   创建日期：2016-10-12
  *     创建者：周建刚
  *   功能说明：1、校验客户、账户是否有效；Y 为正常，N 为客户或账户失效、不存在等
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_ENTITY_CUST_CHECK(P_ENTITY_ID            IN NUMBER,    --主体ID
                                  P_CUSTOMER_ID          IN NUMBER,    --客户ID
                                  P_ACCOUNT_ID           IN NUMBER,    --账户ID
                                  P_SALES_CENTER_ID      IN NUMBER,    --营销中心ID
                                  P_CUST_CHECK_FLAG      OUT VARCHAR2, --客户、账户校验结果标识: Y 为正常，N 为客户或账户失效、不存在等
                                  P_CUST_CHECK_MSG       OUT VARCHAR2, --与P_CUST_CHECK_FLAG，对应的校验结果提示
                                  P_RESULT               OUT NUMBER,   --返回错误ID
                                  P_ERR_MSG              OUT VARCHAR2  --返回错误信息
                                  ) IS
    --客户头表信息记录
    R_CUSTOMER_HEADER T_CUSTOMER_HEADER%ROWTYPE;
    --客户、事业部信息
    R_CUSTOMER_DEPT T_CUSTOMER_DEPT%ROWTYPE;
    --客户、账户、营销中心信息记录
    R_CUSTOMER_ACCOUNT_SALECENTER V_CUSTOMER_ACCOUNT_SALECENTER%ROWTYPE;
  BEGIN
    P_RESULT  := V_RESULT;
    P_ERR_MSG := V_SUCCESS;
    P_CUST_CHECK_FLAG  := PKG_SO_PUB.V_YES; --默认客户、账户正常可用
    P_CUST_CHECK_MSG   := '客户、账户正常可用';
    
    --获取客户信息
    BEGIN
      SELECT T.* INTO R_CUSTOMER_HEADER
        FROM T_CUSTOMER_HEADER T
       WHERE T.CUSTOMER_ID = P_CUSTOMER_ID;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        P_ERR_MSG := '客户[' || P_CUSTOMER_ID || ']在客户信息表T_CUSTOMER_HEADER中不存在。';
        RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      WHEN OTHERS THEN
        P_ERR_MSG := '客户[' || P_CUSTOMER_ID || ']获取客户信息发生异常：' || SQLERRM;
        RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
    END;
    
    --获取客户、事业部信息
    BEGIN
      SELECT D.* INTO R_CUSTOMER_DEPT
        FROM T_CUSTOMER_DEPT D,UP_ORG_UNIT U
       WHERE 'Active' = D.ACTIVE_FLAG
         AND U.CODE = D.DEPT_CODE
         AND U.ENTITY_ID = D.DEPT_ID
         AND (U.TYPE_CODE = 'MC' OR U.TYPE_CODE = 'BU')
         AND D.DEPT_ID = P_ENTITY_ID
         AND D.CUSTOMER_ID = P_CUSTOMER_ID
         AND ROWNUM = 1;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        P_CUST_CHECK_FLAG  := PKG_SO_PUB.V_NO;
        P_CUST_CHECK_MSG := '事业部[' || P_ENTITY_ID || '],客户[' || P_CUSTOMER_ID || ',' || R_CUSTOMER_HEADER.CUSTOMER_CODE || ']对应关系不存在。';
        P_ERR_MSG := P_CUST_CHECK_MSG;
        RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      WHEN OTHERS THEN
        P_CUST_CHECK_FLAG  := PKG_SO_PUB.V_NO;
        P_CUST_CHECK_MSG := '事业部[' || P_ENTITY_ID || '],客户[' || P_CUSTOMER_ID || ',' || R_CUSTOMER_HEADER.CUSTOMER_CODE || ']获取客户事业部信息发生异常：' || SQLERRM;
        P_ERR_MSG := P_CUST_CHECK_MSG;
        RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
    END;
    
    IF ('Active' <> R_CUSTOMER_DEPT.DEPT_CUSTOMER_STATUS OR 'Active' <> R_CUSTOMER_DEPT.ACTIVE_FLAG) THEN
        P_CUST_CHECK_FLAG  := PKG_SO_PUB.V_NO;
        P_CUST_CHECK_MSG := '事业部[' || P_ENTITY_ID || '],客户[' || P_CUSTOMER_ID || ']对应关系已经失效！';
    END IF;
    
    --获取客户、账户、营销中心信息记录
    BEGIN
      SELECT S.* INTO R_CUSTOMER_ACCOUNT_SALECENTER
        FROM V_CUSTOMER_ACCOUNT_SALECENTER S
       WHERE S.ENTITY_ID = P_ENTITY_ID
         AND S.CUSTOMER_ID = P_CUSTOMER_ID
         AND S.ACCOUNT_ID = P_ACCOUNT_ID
         AND S.SALES_CENTER_ID = P_SALES_CENTER_ID;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        P_CUST_CHECK_FLAG  := PKG_SO_PUB.V_NO;
        P_CUST_CHECK_MSG := '主体[' || P_ENTITY_ID || '],客户[' || P_CUSTOMER_ID || ',' || R_CUSTOMER_HEADER.CUSTOMER_CODE || '],账户[' || P_ACCOUNT_ID || '],营销中心[' || P_SALES_CENTER_ID || ']对应关系不存！';
        P_ERR_MSG := P_CUST_CHECK_MSG;
        RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      WHEN OTHERS THEN
        P_CUST_CHECK_FLAG  := PKG_SO_PUB.V_NO;
        P_CUST_CHECK_MSG := '主体[' || P_ENTITY_ID || '],客户[' || P_CUSTOMER_ID || ',' || R_CUSTOMER_HEADER.CUSTOMER_CODE || '],账户[' || P_ACCOUNT_ID || '],营销中心[' || P_SALES_CENTER_ID || ']获取客户、账户、中心信息发生异常：' || SQLERRM;
        P_ERR_MSG := P_CUST_CHECK_MSG;
        RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
    END;
    
    IF ('Active' <> R_CUSTOMER_ACCOUNT_SALECENTER.ORGACTIVE_FLAG) THEN
        P_CUST_CHECK_FLAG  := PKG_SO_PUB.V_NO;
        P_CUST_CHECK_MSG := '主体[' || P_ENTITY_ID || '],客户[' || P_CUSTOMER_ID || ',' || R_CUSTOMER_HEADER.CUSTOMER_CODE || '],账户[' || P_ACCOUNT_ID || '],营销中心[' || P_SALES_CENTER_ID || ']对应关系中[组织状态]已经失效！';
    END IF;
    
    IF ('1' <> R_CUSTOMER_ACCOUNT_SALECENTER.ACCOUNT_STATUS) THEN
        P_CUST_CHECK_FLAG  := PKG_SO_PUB.V_NO;
        P_CUST_CHECK_MSG := '主体[' || P_ENTITY_ID || '],客户[' || P_CUSTOMER_ID || ',' || R_CUSTOMER_HEADER.CUSTOMER_CODE || '],账户[' || P_ACCOUNT_ID || '],营销中心[' || P_SALES_CENTER_ID || ']对应关系中[账户]已经失效！';
    END IF;
  
  EXCEPTION
    WHEN PKG_SO_PUB.V_BIZ_EXCEPTION THEN
      P_RESULT  := -28866;
      P_ERR_MSG := '主体[' || P_ENTITY_ID || '],判断客户[' || P_CUSTOMER_ID || ']、账户[' || P_ACCOUNT_ID || ']、中心[' || P_SALES_CENTER_ID || ']是否有效出错：' || P_ERR_MSG;
    WHEN OTHERS THEN
      P_RESULT  := -28866;
      P_ERR_MSG := '主体[' || P_ENTITY_ID || '],判断客户[' || P_CUSTOMER_ID || ']、账户[' || P_ACCOUNT_ID || ']、中心[' || P_SALES_CENTER_ID || ']是否有效，发生异常：' || SQLERRM;
  END;
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2016-10-12
  *     创建者：周建刚
  *   功能说明：1、判断客户是否为内部关联交易客户
                      (1)根据仓库、推拉模式主体参数获取到对应的营销OU
                      (2)根据供方主体、营销OU、需方客户获取对应的事业部供需配置信息
                      (3)P_ENTITY_CUST_FLAG 事业部客户标识: N 普通客户，Y 内部关联交易客户
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_GET_ENTITY_CUST_FLAG(P_ENTITY_ID            IN NUMBER,    --主体ID
                                      P_INV_ID               IN NUMBER,    --仓库ID
                                      P_CUSTOMER_CODE        IN VARCHAR2,  --客户编码
                                      P_SALES_CENTER_CODE    IN VARCHAR2,  --营销中心编码
                                      P_ENTITY_CUST_FLAG     OUT VARCHAR2, --事业部客户标识: N 普通客户，Y 内部关联交易客户
                                      P_RESULT               OUT NUMBER,   --返回错误ID
                                      P_ERR_MSG              OUT VARCHAR2  --返回错误信息
                                  ) IS
    V_PUSH_OR_PULL    VARCHAR2(32);
    --仓库的OU ID
    V_INV_ERP_OU_ID NUMBER;
    --ERP的OU ID
    V_ERP_OU_ID NUMBER;
    --ERP的子库编码
    V_ERP_SUBINV_CODE VARCHAR2(100);
    --关联交易配置信息记录
    R_SO_SUPPLIER_REQUIRE_ENTITY T_SO_SUPPLIER_REQUIRE_ENTITY%ROWTYPE;
    V_TRX_INV_CONF_TOTAL NUMBER; --内部客户关联交易仓配置记录
    
    --是否推广物料标识
    V_IS_MATERIAL CHAR(1) := 'N';
    V_INTF_SYSTEM_TYPE VARCHAR2(32);--财务接口对接系统标识 ERP：美的现有ERP系统；NC：用友NC财务系统。
  BEGIN
    P_RESULT  := V_RESULT;
    P_ERR_MSG := V_SUCCESS;
    P_ENTITY_CUST_FLAG := PKG_SO_PUB.V_NO;  --默认为普通客户
    
    V_IS_MATERIAL := PKG_SO_PUB.F_INVENTORY_IS_MATERIAL(P_INV_ID);
    IF (V_IS_MATERIAL = PKG_SO_PUB.V_YES) THEN
      P_ENTITY_CUST_FLAG := PKG_SO_PUB.V_NO;
      RETURN;
    END IF;
    
    PKG_BD.P_GET_PARAMETER_VALUE(PKG_SO_PUB.V_INTF_SYSTEM_TYPE,
                                 P_ENTITY_ID,
                                 NULL,
                                 NULL,
                                 V_INTF_SYSTEM_TYPE);

    IF(V_INTF_SYSTEM_TYPE IS NOT NULL AND V_INTF_SYSTEM_TYPE = PKG_SO_PUB.V_INTF_SYSTEM_TYPE_NC) THEN
      P_ENTITY_CUST_FLAG := PKG_SO_PUB.V_NO;
      RETURN;
    END IF;
    
    BEGIN
      --获取ERP OU ID、ERP OU名称、ERP子库ID、ERP子库编码、
      SELECT INV_ORG.OPERATING_UNIT, --ERP OU ID
             INV_ORG.ORGANIZATION_CODE --ERP子库存组织编码，取发货仓库/收货仓库对应的库存组织编码
        INTO V_INV_ERP_OU_ID,
             V_ERP_SUBINV_CODE
        FROM T_INV_INVENTORIES INV, T_INV_ORGANIZATION INV_ORG
       WHERE INV.ORGANIZATION_ID = INV_ORG.ORGANIZATION_ID
         AND INV.ORGANIZATION_CODE = INV_ORG.ORGANIZATION_CODE
         AND INV.ENTITY_ID = INV_ORG.ENTITY_ID
         AND INV.ENTITY_ID = P_ENTITY_ID
         AND INV.INVENTORY_ID = P_INV_ID
         AND ROWNUM = 1;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        P_ERR_MSG := '仓库[' || P_INV_ID || ']未设置对应的库存组织！';
        RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      WHEN OTHERS THEN
        P_ERR_MSG := '获取仓库[' || P_INV_ID || ']对应的ERP OU信息发生异常：' || SQLERRM;
        RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
    END;  
    
    V_ERP_OU_ID := V_INV_ERP_OU_ID;
  
    BEGIN
      PKG_BD.P_GET_PARAMETER_VALUE(PKG_SO_PUB.V_ARG_SO_AR_PUSH_OR_PULL,
                                   P_ENTITY_ID,
                                   NULL,
                                   NULL,
                                   V_PUSH_OR_PULL);
    EXCEPTION
      WHEN OTHERS THEN
        P_ERR_MSG := 'SO_AR_PUSH_OR_PULL主体参数,主体[' ||
                     P_ENTITY_ID || ']的参数设置异常，请检查。' || SQLERRM;
        RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
    END;
    V_PUSH_OR_PULL := TRIM(V_PUSH_OR_PULL);
    IF V_PUSH_OR_PULL NOT IN ('PULL','PUSH','MIXED') THEN
       P_ERR_MSG := 'SO_AR_PUSH_OR_PULL主体参数,参数值:' ||
                     V_PUSH_OR_PULL || ',不在PULL、PUSH、MIXED范围内,请检查。' ||
                     SQLERRM;
       RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
    END IF;
      
    --关联交易模式为推拉结合混合模块 同时 财务仓对应库存组织编码以S开头（即营销组织） 则为推式，否则为拉式
    IF V_PUSH_OR_PULL='MIXED' THEN
       IF SUBSTR(V_ERP_SUBINV_CODE,1,1)='S' THEN
          V_PUSH_OR_PULL := 'PUSH';  --推式
       ELSE
          V_PUSH_OR_PULL := 'PULL';  --拉式
       END IF;
    END IF;
      
    IF (V_PUSH_OR_PULL = 'PULL') THEN
      BEGIN
        /**
        拉式模式下，自动补全关联交易中供需双方OU信息
        步骤一：根据财务管理/收款配置/默认OU配置: 营销中心查找默认的OU
        步骤二：如果步骤一中没有找到，则从销售管理/基础数据/关联交易供需OU配置：根据供方OU查找到需方OU
        */
        BEGIN
          SELECT R.ERP_OU_ID
            INTO V_ERP_OU_ID
            FROM T_AR_OU_RELATION R
           WHERE R.ENTITY_ID = P_ENTITY_ID
             AND R.SALES_CENTER_CODE = P_SALES_CENTER_CODE
             AND (TRUNC(SYSDATE) BETWEEN R.EFFECTIVE_TIAME AND R.FAILURE_TIME);
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            V_ERP_OU_ID := NULL;
            DBMS_OUTPUT.PUT_LINE('主体[' || P_ENTITY_ID || ']的营销中心[' ||
                         P_SALES_CENTER_CODE || ']不存在默认OU！');
          WHEN OTHERS THEN
            V_ERP_OU_ID := NULL;
            DBMS_OUTPUT.PUT_LINE('主体[' || P_ENTITY_ID || ']的营销中心[' ||
                         P_SALES_CENTER_CODE || ']获取默认OU出错！');
        END;

        --工厂OU和ERP OU 交互
        --反向销售，需方工厂OU取供方内销OU
        --拉式正向销售，供方：工厂OU，取需方：内销OU
        --拉式反向销售，需方：工厂OU，取供方：内销OU
        IF (V_ERP_OU_ID IS NULL) THEN
            --拉式正向销售，供方：工厂OU，取需方：内销OU
            SELECT T.REQUIREMENT_OU_ID --ERP OU  内销
              INTO V_ERP_OU_ID
              FROM T_SO_SUPPLIER_REQUIREMENT T
             WHERE T.ENTITY_ID = P_ENTITY_ID
               AND T.SUPPLIER_OU_ID = V_INV_ERP_OU_ID --供方工厂OU，找需方内销OU
               AND T.TRADE_MODE_CODE = PKG_SO_PUB.V_SO_TRX_MODE_003; --拉式成品销售
        END IF;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          P_ERR_MSG := '主体[' || P_ENTITY_ID || '],工厂 OU[' || V_INV_ERP_OU_ID ||
                       '],交易模式编码[' || PKG_SO_PUB.V_SO_TRX_MODE_003 || ']未设置对应的ERP OU！';
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
        WHEN OTHERS THEN
          P_ERR_MSG := '主体[' || P_ENTITY_ID || '],工厂 OU[' || V_INV_ERP_OU_ID ||
                       ',交易模式编码[' || PKG_SO_PUB.V_SO_TRX_MODE_003 || ']对应的ERP OU信息发生异常：' || SQLERRM;
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      END;
    END IF;
      
    --获取客户信息
    BEGIN
      SELECT T.* INTO R_SO_SUPPLIER_REQUIRE_ENTITY
        FROM T_SO_SUPPLIER_REQUIRE_ENTITY T
       WHERE T.SUPPLIER_ENTITY_ID = P_ENTITY_ID
         AND T.SUPPLIER_OU_ID = V_ERP_OU_ID
         AND T.REQUIREMENT_CUSTOMER_CODE = P_CUSTOMER_CODE;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        P_ERR_MSG := '主体[' || P_ENTITY_ID || '],供方OU[' || V_ERP_OU_ID || '],客户[' || P_CUSTOMER_CODE || ']在事业部供需关系配置中不存在！';
        RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      WHEN OTHERS THEN
        P_ERR_MSG := '主体[' || P_ENTITY_ID || '],供方OU[' || V_ERP_OU_ID || '],客户[' || P_CUSTOMER_CODE || ']获取事业部供需关系配置发生异常：' || SQLERRM;
        RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
    END;
        
    IF (R_SO_SUPPLIER_REQUIRE_ENTITY.ICP_LG_RECEIVE_MODE IS NOT NULL
       AND (R_SO_SUPPLIER_REQUIRE_ENTITY.ICP_LG_RECEIVE_MODE = '1' OR R_SO_SUPPLIER_REQUIRE_ENTITY.ICP_LG_RECEIVE_MODE = '2')) THEN
      P_ENTITY_CUST_FLAG := PKG_SO_PUB.V_YES;
    END IF;
  
    IF (P_ENTITY_CUST_FLAG = PKG_SO_PUB.V_YES) THEN
      BEGIN
        SELECT NVL(COUNT(1),0) INTO V_TRX_INV_CONF_TOTAL
          FROM CIMS.T_SO_ENTITY_CUST_TRX_INV_CONF C
         WHERE C.REQUIREMENT_CUSTOMER_CODE = P_CUSTOMER_CODE
           AND C.SUPPLIER_OU_ID = V_INV_ERP_OU_ID
           AND C.ENTITY_ID = P_ENTITY_ID;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          P_ERR_MSG := '主体[' || P_ENTITY_ID || '],供方OU[' || V_ERP_OU_ID || '],事业部客户[' || P_CUSTOMER_CODE || ']在跨事业部关联交易仓配置中不存在！';
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
        WHEN OTHERS THEN
          P_ERR_MSG := '主体[' || P_ENTITY_ID || '],供方OU[' || V_ERP_OU_ID || '],事业部客户[' || P_CUSTOMER_CODE || ']获取跨事业部关联交易仓配置发生异常：' || SQLERRM;
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      END;
      
      IF (V_TRX_INV_CONF_TOTAL = 0) THEN
          P_ERR_MSG := '主体[' || P_ENTITY_ID || '],供方OU[' || V_ERP_OU_ID || '],事业部客户[' || P_CUSTOMER_CODE || ']未在跨事业部关联交易仓中配置！';
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      END IF;
    END IF;

  EXCEPTION
    WHEN PKG_SO_PUB.V_BIZ_EXCEPTION THEN
      P_RESULT  := -28866;
      P_ERR_MSG := '主体[' || P_ENTITY_ID || '],仓库[' || P_INV_ID || '],营销中心[' || P_SALES_CENTER_CODE || '],判断客户[' || P_CUSTOMER_CODE || ']是否为内部关联交易客户，出错：' || P_ERR_MSG;
    WHEN OTHERS THEN
      P_RESULT  := -28866;
      P_ERR_MSG := '主体[' || P_ENTITY_ID || '],仓库[' || P_INV_ID || '],营销中心[' || P_SALES_CENTER_CODE || '],判断客户[' || P_CUSTOMER_CODE || ']是否为内部关联交易客户，发生异常：' || SQLERRM;
  END;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2016-10-17
  *     创建者：周建刚
  *   功能说明：1、根据财务单号，返回财务单客户对应的事业部标识( N 普通客户，Y 内部关联交易客户)
                      (1)内部客户 T_CUSTOMER_HEADER.CUSTOMER_IS_INTERNAL='Y'
                      (2)内部关联交易客户 T_SO_SUPPLIER_REQUIRE_ENTITY.ICP_LG_RECEIVE_MODE 为1或2的客户为内部关联交易客户。
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_ENTITY_CUST_FLAG_BY_NUM(P_ENTITY_ID            IN NUMBER,    --主体ID
                                         P_SO_NUM               IN VARCHAR2,  --单据号
                                         P_ENTITY_CUST_FLAG     OUT VARCHAR2, --事业部客户标识: N 普通客户，Y 内部关联交易客户
                                         P_RESULT               OUT NUMBER,   --返回错误ID
                                         P_ERR_MSG              OUT VARCHAR2  --返回错误信息
                                     ) IS
    R_SO_HEADER T_SO_HEADER%ROWTYPE;                                  --财务单头信息表
    R_CUSTOMER_HEADER T_CUSTOMER_HEADER%ROWTYPE;                      --客户头表信息记录
    R_SO_SUPPLIER_REQUIRE_ENTITY T_SO_SUPPLIER_REQUIRE_ENTITY%ROWTYPE;--关联交易配置信息记录
    V_INTF_SYSTEM_TYPE VARCHAR2(32);--财务接口对接系统标识 ERP：美的现有ERP系统；NC：用友NC财务系统。
  BEGIN
    P_RESULT  := V_RESULT;
    P_ERR_MSG := V_SUCCESS;
    P_ENTITY_CUST_FLAG := PKG_SO_PUB.V_NO;  --默认为普通客户
    
    BEGIN
      SELECT H.* INTO R_SO_HEADER
       FROM T_SO_HEADER H
       WHERE H.ENTITY_ID = P_ENTITY_ID
       AND H.SO_NUM = P_SO_NUM;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        P_ERR_MSG := '根据主体[' || P_ENTITY_ID || '],单号[' || P_SO_NUM || ']未查询到对应单据，请核实单号是否正确！';
        RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      WHEN OTHERS THEN
        P_ERR_MSG := '根据主体[' || P_ENTITY_ID || '],单号[' || P_SO_NUM || ']查询对应单据发生异常：' || SQLERRM;
        RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
    END;  
    
    IF (R_SO_HEADER.IS_MATERIAL = PKG_SO_PUB.V_YES) THEN
        --推广物料单据统一不走事业部关联交易
        P_ENTITY_CUST_FLAG := PKG_SO_PUB.V_NO;
      RETURN;
    END IF;
    
    PKG_BD.P_GET_PARAMETER_VALUE(PKG_SO_PUB.V_INTF_SYSTEM_TYPE,
                                 R_SO_HEADER.ENTITY_ID,
                                 NULL,
                                 NULL,
                                 V_INTF_SYSTEM_TYPE);

    IF(V_INTF_SYSTEM_TYPE IS NOT NULL AND V_INTF_SYSTEM_TYPE = PKG_SO_PUB.V_INTF_SYSTEM_TYPE_NC) THEN
      P_ENTITY_CUST_FLAG := PKG_SO_PUB.V_NO;
      RETURN;
    END IF;
    
    IF R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE NOT IN
       (PKG_SO_PUB.V_BIZ_SRC_BILL_SO,PKG_SO_PUB.V_BIZ_SRC_BILL_SO_RED,
        PKG_SO_PUB.V_BIZ_SRC_BILL_RETURN,PKG_SO_PUB.V_BIZ_SRC_BILL_RETURN_RED) THEN
        --除销售、退货、销售红冲、退货红冲等需要关联交易，其它单据类型并不涉及。按照普通客户处理。
        P_ENTITY_CUST_FLAG := PKG_SO_PUB.V_NO;
      RETURN;
    END IF;

    BEGIN
      SELECT H.* INTO R_CUSTOMER_HEADER
       FROM T_CUSTOMER_HEADER H
       WHERE H.CUSTOMER_CODE = R_SO_HEADER.CUSTOMER_CODE
       AND H.CUSTOMER_ID = R_SO_HEADER.CUSTOMER_ID;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        P_ERR_MSG := '根据客户[' || R_SO_HEADER.CUSTOMER_ID || ',' || R_SO_HEADER.CUSTOMER_CODE || '],未查询到对应客户信息，请核实客户ID、编码是否正确！';
        RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      WHEN OTHERS THEN
        P_ERR_MSG := '根据客户[' || R_SO_HEADER.CUSTOMER_ID || ',' || R_SO_HEADER.CUSTOMER_CODE || '],未查询到对应客户信息发生异常：' || SQLERRM;
        RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
    END;
    
    IF (R_CUSTOMER_HEADER.CUSTOMER_IS_INTERNAL = PKG_SO_PUB.V_NO) THEN
      P_ENTITY_CUST_FLAG := PKG_SO_PUB.V_NO;
    ELSE
      --获取客户信息
      BEGIN
        SELECT T.* INTO R_SO_SUPPLIER_REQUIRE_ENTITY
          FROM T_SO_SUPPLIER_REQUIRE_ENTITY T
         WHERE T.SUPPLIER_ENTITY_ID = R_SO_HEADER.ENTITY_ID
           AND T.SUPPLIER_OU_ID = R_SO_HEADER.ERP_OU_ID
           AND T.REQUIREMENT_CUSTOMER_CODE = R_SO_HEADER.CUSTOMER_CODE;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          P_ERR_MSG := '主体[' || R_SO_HEADER.ENTITY_ID || '],供方OU[' || R_SO_HEADER.ERP_OU_ID || '],需方客户[' || R_SO_HEADER.CUSTOMER_CODE || ']在事业部供需关系配置中不存！';
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
        WHEN OTHERS THEN
          P_ERR_MSG := '根据主体[' || R_SO_HEADER.ENTITY_ID || '],供方OU[' || R_SO_HEADER.ERP_OU_ID || '],需方客户[' || R_SO_HEADER.CUSTOMER_CODE || ']获取对应事业部供需关系配置发生异常：' || SQLERRM;
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      END;
          
      IF (R_SO_SUPPLIER_REQUIRE_ENTITY.ICP_LG_RECEIVE_MODE IS NOT NULL
         AND (R_SO_SUPPLIER_REQUIRE_ENTITY.ICP_LG_RECEIVE_MODE = '1' OR R_SO_SUPPLIER_REQUIRE_ENTITY.ICP_LG_RECEIVE_MODE = '2')) THEN
        P_ENTITY_CUST_FLAG := PKG_SO_PUB.V_YES;
      END IF;
    END IF;

  EXCEPTION
    WHEN PKG_SO_PUB.V_BIZ_EXCEPTION THEN
      P_RESULT  := -28866;
      P_ERR_MSG := '判断客户是否为内部关联交易客户出错：' || P_ERR_MSG;
    WHEN OTHERS THEN
      P_RESULT  := -28866;
      P_ERR_MSG := '判断客户是否为内部关联交易客户出错：' || SQLERRM;
  END;
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2016-09-22
  *     创建者：周建刚
  *   功能说明：更新销售单的ERP签收标识、签收日期，并做第二步子库转移。
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_UP_ERP_LOGIST_RECEIVE(P_RESULT   OUT NUMBER, --返回错误ID
                                    P_ERR_MSG  OUT VARCHAR2 --返回错误信息
                                    ) IS

    V_START_DATE  DATE;
  BEGIN
    P_RESULT  := V_RESULT;
    P_ERR_MSG := V_SUCCESS;
    V_START_DATE := TRUNC(SYSDATE - 30);

    FOR REC IN (SELECT SO.* FROM CIMS.T_SO_HEADER SO
       WHERE SO.BIZ_SRC_BILL_TYPE_CODE IN (PKG_SO_PUB.V_BIZ_SRC_BILL_SO,PKG_SO_PUB.V_BIZ_SRC_BILL_SO_RED,PKG_SO_PUB.V_BIZ_SRC_BILL_RETURN,PKG_SO_PUB.V_BIZ_SRC_BILL_RETURN_RED)
       AND EXISTS (SELECT 1
        FROM INTF_CUX_ICP_LOGIST_REQ_HEADER T
       WHERE 'G' || SO.SO_NUM = T.REQUIREMENT_ORDER_NUM
         AND NVL(T.ERP_LOGIST_RECEIVE_FLAG,PKG_SO_PUB.V_NO) = PKG_SO_PUB.V_YES
         AND T.ERP_LOGIST_RECEIVE_DATE IS NOT NULL
         AND T.REQUIREMENT_ORDER_TYPE = '03')
       AND NVL(SO.ERP_LOGIST_RECEIVE_FLAG,PKG_SO_PUB.V_NO) = PKG_SO_PUB.V_NO
       AND SO.ERP_LOGIST_RECEIVE_DATE IS NULL
                 AND SO.ENTITY_CUST_FLAG = PKG_SO_PUB.V_YES
         
                 AND SO.LAST_UPDATE_DATE > V_START_DATE
                ) LOOP

      BEGIN
        SAVEPOINT SUCCESS_FLAG;
        --定时更新财务单签收信息JOB
        UPDATE CIMS.T_SO_HEADER SO
           SET SO.ERP_LOGIST_RECEIVE_FLAG = 'Y',
               SO.ERP_LOGIST_RECEIVE_DATE =
               (SELECT TRUNC(LR.ERP_LOGIST_RECEIVE_DATE)
                  FROM CIMS.INTF_CUX_ICP_LOGIST_REQ_HEADER LR
                 WHERE 'G' || SO.SO_NUM = LR.REQUIREMENT_ORDER_NUM
                   AND ROWNUM = 1)
         WHERE SO.SO_NUM = REC.SO_NUM;
        
        --调用子库转移接口
        P_SO_INV_TRANSFER(REC.ENTITY_ID, REC.SO_HEADER_ID, P_RESULT, P_ERR_MSG);
        PKG_SO_PUB.P_EXCEPTION_THROWS(P_RESULT);
      EXCEPTION
        WHEN OTHERS THEN
          ROLLBACK TO SUCCESS_FLAG;
          PKG_SO_RT.P_TABLE_ACTION_LOG('PKG_SO_INTF.P_UPDATE_ERP_LOGIST_RECEIVE', --操作表名称
                             '更新销售单的ERP签收标识、签收日期，并做第二步子库转移。', --操作说明
                             REC.SO_NUM, --关键主键
                             1, --是否出错，1出错，0未出错
                             '更新ERP物流签收信息并调用子库转移发生异常，异常信息：' || P_ERR_MSG || SQLERRM --错误信息
                             );
          P_RESULT  := V_RESULT;
          P_ERR_MSG := V_SUCCESS;
          GOTO HEADER;
      END;
      <<HEADER>>
      NULL;
    END LOOP;

  EXCEPTION
    WHEN PKG_SO_PUB.V_BIZ_EXCEPTION THEN
      P_RESULT  := -27001;
      P_ERR_MSG := '更新ERP物流签收信息并调用子库转移处理出错：' || P_ERR_MSG;
    WHEN OTHERS THEN
      P_RESULT  := -27001;
      P_ERR_MSG := '更新ERP物流签收信息并调用子库转移发生异常，异常信息：' || SQLERRM;
  
  END;
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2016-10-18
  *     创建者：周建刚
  *   功能说明：财务单（制单、审核）触发仓储库存事务接口(CIMS库存事务接口)
  *             一、外部客户(只触发一次库存事务)
  *                (1)正向只触发第一次库存事务
  *                (2)反向只触发第二次库存事务
  *             二、内部客户(需要做两次库存事务，根据单据正反向区分触发时点。)V_SO_STATUS: '10' 第一次库存事务;'30' 第二次库存事务
  *                (1)正向：制单时触发第一次，关联交易平台PO接收后触发第二次。
  *                (2)反向：制单时同时依次触发第一次、第二次库存事务。
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_INV_TRANSACTION(P_ENTITY_ID          IN T_INV_TRANSACTION_HISTORY.ENTITY_ID%TYPE,--经营主体ID
                                 P_SO_STATUS          IN T_SO_HEADER.SO_STATUS%TYPE,--单据状态
                                 P_TRANSACTION_DATE   IN T_INV_TRANSACTION_HISTORY.TRANSACTION_DATE%TYPE,
                                 P_BUSINESS_HEADER_ID IN T_INV_TRANSACTION_HISTORY.BUSINESS_HEADER_ID%TYPE,--业务单据头ID
                                 P_RESULT             OUT NUMBER, --返回错误ID
                                 P_ERR_MSG            OUT VARCHAR2 --返回错误信息
                                ) IS
    R_SO_HEADER T_SO_HEADER%ROWTYPE;
    V_SO_STATUS T_SO_HEADER.SO_STATUS%TYPE := '10';--单据状态
  BEGIN
    P_RESULT  := V_RESULT;
    P_ERR_MSG := V_SUCCESS;
    
    BEGIN
      SELECT H.* INTO R_SO_HEADER
       FROM T_SO_HEADER H
       WHERE H.ENTITY_ID = P_ENTITY_ID
       AND H.SO_HEADER_ID = P_BUSINESS_HEADER_ID;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        P_ERR_MSG := '根据主体[' || P_ENTITY_ID || '],单ID[' || P_BUSINESS_HEADER_ID || ']未查询到对应单据，请核实数据是否正确！';
        RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      WHEN OTHERS THEN
        P_ERR_MSG := '根据主体[' || P_ENTITY_ID || '],单ID[' || P_BUSINESS_HEADER_ID || ']查询对应单据发生异常：' || SQLERRM;
        RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
    END;
    
    V_SO_STATUS := NVL(P_SO_STATUS,R_SO_HEADER.SO_STATUS);
    /**
        外部客户仅需做一次库存事务，制单是触发。
        正向： 10 ；反向： 30
    */
    IF (NVL(R_SO_HEADER.ENTITY_CUST_FLAG, PKG_SO_PUB.V_NO) = PKG_SO_PUB.V_NO) THEN
      --外部客户直接更新签收标识
      UPDATE T_SO_HEADER H
        SET H.ERP_LOGIST_RECEIVE_FLAG = PKG_SO_PUB.V_YES,
            H.ERP_LOGIST_RECEIVE_DATE = TRUNC(SYSDATE)
      WHERE H.ENTITY_ID = R_SO_HEADER.ENTITY_ID
        AND H.SO_HEADER_ID = R_SO_HEADER.SO_HEADER_ID;
                
      IF (R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE = PKG_SO_PUB.V_BIZ_SRC_BILL_SO
        OR R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE = PKG_SO_PUB.V_BIZ_SRC_BILL_RETURN_RED) THEN
        --正向只触发第一次库存事务
        PKG_INV_TRANSACTION.INV_TRANSACTION_TOTAL_DEAL(
          R_SO_HEADER.ENTITY_ID,R_SO_HEADER.BILL_TYPE_ID,
          '10',R_SO_HEADER.SO_DATE,R_SO_HEADER.SO_HEADER_ID,
          0,PKG_SO_PUB.V_TYPE_FLAG_SO,P_RESULT,P_ERR_MSG);
        PKG_SO_PUB.P_EXCEPTION_THROWS(P_RESULT);
      ELSIF (R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE = PKG_SO_PUB.V_BIZ_SRC_BILL_SO_RED
        OR R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE = PKG_SO_PUB.V_BIZ_SRC_BILL_RETURN) THEN
        --反向只触发第二次库存事务
        PKG_INV_TRANSACTION.INV_TRANSACTION_TOTAL_DEAL(
          R_SO_HEADER.ENTITY_ID, R_SO_HEADER.BILL_TYPE_ID,
          '30', R_SO_HEADER.SO_DATE,R_SO_HEADER.SO_HEADER_ID,
          0,PKG_SO_PUB.V_TYPE_FLAG_SO,P_RESULT,P_ERR_MSG);
        PKG_SO_PUB.P_EXCEPTION_THROWS(P_RESULT);
      END IF;
    ELSIF (NVL(R_SO_HEADER.ENTITY_CUST_FLAG, PKG_SO_PUB.V_NO) = PKG_SO_PUB.V_YES) THEN
      /**
        内部客户需要做两次库存事务，根据单据正反向区分触发时点。
        正向：制单是触发第一次，关联交易平台PO接收后触发第二次。
        反向：制单时同时依次触发第一次、第二次库存事务。
      */
      IF (R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE = PKG_SO_PUB.V_BIZ_SRC_BILL_SO) THEN
        IF (V_SO_STATUS = PKG_SO_PUB.V_CREATED) THEN
          --正向触发第一次库存事务
          PKG_INV_TRANSACTION.INV_TRANSACTION_TOTAL_DEAL(
            R_SO_HEADER.ENTITY_ID, R_SO_HEADER.BILL_TYPE_ID,
            '10', R_SO_HEADER.SO_DATE,R_SO_HEADER.SO_HEADER_ID,
            0,PKG_SO_PUB.V_TYPE_FLAG_SO,P_RESULT,P_ERR_MSG);
          PKG_SO_PUB.P_EXCEPTION_THROWS(P_RESULT);
          /**
          --内部关联交易异步物流在PO接收后触发跟同步模式保持一致
          BEGIN
             --根据供方业务主体、供方OU、需方客户 对应的'关联物流接收模式'； 
             SELECT T.ICP_LG_RECEIVE_MODE INTO V_ICP_LG_RECEIVE_MODE
                FROM T_SO_SUPPLIER_REQUIRE_ENTITY T
               WHERE T.SUPPLIER_ENTITY_ID = R_SO_HEADER.ENTITY_ID 
                  and T.SUPPLIER_OU_ID = R_SO_HEADER.ERP_OU_ID
                  and T.REQUIREMENT_CUSTOMER_ID = R_SO_HEADER.CUSTOMER_ID;           
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              P_ERR_MSG := '事业部客户[' || R_SO_HEADER.CUSTOMER_CODE || ',' || R_SO_HEADER.CUSTOMER_NAME || ']在供需关系中未进行配置接收模式[ICP_LG_RECEIVE_MODE]！'
              || '主体[' || R_SO_HEADER.ENTITY_ID || '],OU[' || R_SO_HEADER.ERP_OU_ID || '],客户ID[' || R_SO_HEADER.CUSTOMER_ID || ']';
              RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
            WHEN OTHERS THEN
              P_ERR_MSG := '事业部客户[' || R_SO_HEADER.CUSTOMER_CODE || ','  || R_SO_HEADER.CUSTOMER_NAME || ']在供需关系中未进行配置接收模式[ICP_LG_RECEIVE_MODE]！' 
              || '主体[' || R_SO_HEADER.ENTITY_ID || '],OU[' || R_SO_HEADER.ERP_OU_ID || '],客户ID[' || R_SO_HEADER.CUSTOMER_ID || ']' || SQLERRM;
              RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
          END;
      
          --无需关联交易PO接收，则直接触发第二次库存事务
          IF (V_ICP_LG_RECEIVE_MODE != '2') THEN
            PKG_INV_TRANSACTION.INV_TRANSACTION_TOTAL_DEAL(
              R_SO_HEADER.ENTITY_ID, R_SO_HEADER.BILL_TYPE_ID,
              '30', R_SO_HEADER.SO_DATE,R_SO_HEADER.SO_HEADER_ID,
              0,PKG_SO_PUB.V_TYPE_FLAG_SO,P_RESULT,P_ERR_MSG);
            PKG_SO_PUB.P_EXCEPTION_THROWS(P_RESULT);
          END IF;
          */
        ELSIF (V_SO_STATUS = '30' AND R_SO_HEADER.ERP_LOGIST_RECEIVE_FLAG = PKG_SO_PUB.V_YES) THEN
          --正向关联交易平台PO接收后触发第二次库存事务
          PKG_INV_TRANSACTION.INV_TRANSACTION_TOTAL_DEAL(
            R_SO_HEADER.ENTITY_ID, R_SO_HEADER.BILL_TYPE_ID,
            '30', NVL(P_TRANSACTION_DATE,R_SO_HEADER.SO_DATE),R_SO_HEADER.SO_HEADER_ID,
            0,PKG_SO_PUB.V_TYPE_FLAG_SO,P_RESULT,P_ERR_MSG);
          PKG_SO_PUB.P_EXCEPTION_THROWS(P_RESULT);
        END IF;
      ELSIF (R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE = PKG_SO_PUB.V_BIZ_SRC_BILL_SO_RED
        OR R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE = PKG_SO_PUB.V_BIZ_SRC_BILL_RETURN
        OR R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE = PKG_SO_PUB.V_BIZ_SRC_BILL_RETURN_RED) THEN
        --反向触发第一次库存事务
        PKG_INV_TRANSACTION.INV_TRANSACTION_TOTAL_DEAL(
          R_SO_HEADER.ENTITY_ID, R_SO_HEADER.BILL_TYPE_ID,
          '10', R_SO_HEADER.SO_DATE,R_SO_HEADER.SO_HEADER_ID,
          0,PKG_SO_PUB.V_TYPE_FLAG_SO,P_RESULT,P_ERR_MSG);
        PKG_SO_PUB.P_EXCEPTION_THROWS(P_RESULT);
        
        --反向触发第二次库存事务
        PKG_INV_TRANSACTION.INV_TRANSACTION_TOTAL_DEAL(
          R_SO_HEADER.ENTITY_ID, R_SO_HEADER.BILL_TYPE_ID,
          '30', R_SO_HEADER.SO_DATE,R_SO_HEADER.SO_HEADER_ID,
          0,PKG_SO_PUB.V_TYPE_FLAG_SO,P_RESULT,P_ERR_MSG);
        PKG_SO_PUB.P_EXCEPTION_THROWS(P_RESULT);
        
        UPDATE T_SO_HEADER H
          SET H.ERP_LOGIST_RECEIVE_FLAG = PKG_SO_PUB.V_YES,
              H.ERP_LOGIST_RECEIVE_DATE = TRUNC(SYSDATE)
        WHERE H.ENTITY_ID = R_SO_HEADER.ENTITY_ID
          AND H.SO_HEADER_ID = R_SO_HEADER.SO_HEADER_ID;
      END IF;
    END IF;
    
  EXCEPTION
    WHEN PKG_SO_PUB.V_BIZ_EXCEPTION THEN
      P_RESULT  := -27001;
      P_ERR_MSG := '库存事务处理出错：' || P_ERR_MSG
       || ' 主要入参：主体[' || P_ENTITY_ID || '],状态[' || P_SO_STATUS || '],日期['|| P_TRANSACTION_DATE || '],单据[' || P_BUSINESS_HEADER_ID || ']。';
    WHEN OTHERS THEN
      P_RESULT  := -27001;
      P_ERR_MSG := '库存事务发生异常，异常信息：' || SQLERRM
       || ' 主要入参：主体[' || P_ENTITY_ID || '],状态[' || P_SO_STATUS || '],日期['|| P_TRANSACTION_DATE || '],单据[' || P_BUSINESS_HEADER_ID || ']。';
  END;
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2016-12-12
  *     创建者：周建刚
  *   功能说明：根据运输合同的签收信息，更新财务单的签收信息。
  *             情形一：运输合同‘已执行’，但是对应的销售单不是‘已签收’
                情形二：内部事业部客户对应的运输合同‘已确认’、而且有差异，
                则自动更新销售单为‘已签收’(家用主体，解决有差异情况而且没有没有人工差异确认功能，
                运输合同一直都是‘已确认’状态)
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_UP_LG_CONTRACT_RECEIVE(
                                 P_RESULT             OUT NUMBER,  --返回错误ID
                                 P_ERR_MSG            OUT VARCHAR2 --返回错误信息
                                ) IS

  BEGIN
    P_RESULT  := V_RESULT;
    P_ERR_MSG := V_SUCCESS;
    
    --情形一[销售单-头]：运输合同‘已执行’(已经完成了自动签收确认或人工差异确认)，但是对应的销售单不是‘已签收’
    UPDATE CIMS.T_SO_HEADER H
       SET H.RECEIVE_FLAG     = 'Y',
           H.RECEIVE_DATE     = TO_DATE(TO_CHAR(NVL((SELECT SC.RECEIVE_DATE
                                                      FROM CIMS.T_LG_CONTRACT      SC,
                                                           CIMS.T_LG_CONTRACT_LINE SL
                                                     WHERE SC.CONTRACT_ID = SL.CONTRACT_ID
                                                       AND SC.BILLS_STATUS = '02' --'已执行'
                                                       AND SC.RECEIVE_DATE IS NOT NULL
                                                       AND SL.FACT_RECEIVE_QTY IS NOT NULL
                                                       AND SL.SO_DOC_NUM = H.SO_NUM
                                                       AND NVL(H.RECEIVE_FLAG,'N') != 'Y'
                                                       AND ROWNUM = 1),
                                                    H.AUDIT_DATE),
                                                'yyyy-MM-dd'),
                                        'yyyy-MM-dd'),
           H.LAST_UPDATE_DATE = SYSDATE
     WHERE EXISTS (SELECT 1
              FROM CIMS.T_LG_CONTRACT C, CIMS.T_LG_CONTRACT_LINE L
             WHERE C.CONTRACT_ID = L.CONTRACT_ID
               AND C.BILLS_STATUS = '02'          --'已执行'
               AND C.RECEIVE_DATE IS NOT NULL     --签收日期不为空
               AND L.FACT_RECEIVE_QTY IS NOT NULL --签收数量不为空
               AND L.SO_DOC_NUM = H.SO_NUM)
               AND H.RECEIVE_DATE IS NULL
               AND H.BIZ_SRC_BILL_TYPE_CODE = PKG_SO_PUB.V_BIZ_SRC_BILL_SO
               AND H.CREATED_BY = 'LG'
               AND NVL(H.RECEIVE_FLAG, 'N') != 'Y';

     /**
      情形二（内部事业部客户且没有人工差异确认功能）：内部事业部客户对应的运输合同‘已确认’、而且有差异，
      则自动更新销售单为‘已签收’(家用主体，解决有差异情况而且没有没有人工差异确认功能，
      运输合同一直都是‘已确认’状态)
      */
      /**
      UPDATE CIMS.T_SO_HEADER H
         SET H.RECEIVE_FLAG     = 'Y',
             H.RECEIVE_DATE     = TO_DATE(TO_CHAR(NVL((SELECT C.RECEIVE_DATE
                                                        FROM CIMS.T_LG_CONTRACT C, CIMS.T_LG_CONTRACT_LINE L
                                                       WHERE C.CONTRACT_ID = L.CONTRACT_ID
                                                         AND NVL(L.FACT_SHIP_QTY,0) > NVL(L.FACT_RECEIVE_QTY,0)
                                                         AND C.BILLS_STATUS = '01'            --'已确认'
                                                         AND C.ENTITY_ID = 10                 -- (家用没有人工差异确认功能，需后台更新财务单标识)
                                                         AND C.RECEIVE_DATE IS NOT NULL       --签收日期不为空
                                                         AND L.FACT_RECEIVE_QTY IS NOT NULL   --签收数量不为空
                                                         AND L.SO_DOC_NUM = H.SO_NUM
                                                         AND H.RECEIVE_DATE IS NULL
                                                         AND NVL(H.RECEIVE_FLAG, 'N') != 'Y'
                                                         AND NVL(H.ENTITY_CUST_FLAG, 'N') = 'Y'
                                                         AND ROWNUM = 1),
                                                      H.AUDIT_DATE),
                                                  'yyyy-MM-dd'),
                                          'yyyy-MM-dd'),
             H.LAST_UPDATE_DATE = SYSDATE
       WHERE EXISTS (SELECT 1
                FROM CIMS.T_LG_CONTRACT C, CIMS.T_LG_CONTRACT_LINE L
               WHERE C.CONTRACT_ID = L.CONTRACT_ID
                 AND NVL(L.FACT_SHIP_QTY,0) > NVL(L.FACT_RECEIVE_QTY,0)
                 AND C.BILLS_STATUS = '01'            --'已确认'
                 AND C.ENTITY_ID = 10                 -- (家用没有人工差异确认功能，需后台更新财务单标识)
                 AND C.RECEIVE_DATE IS NOT NULL       --签收日期不为空
                 AND L.FACT_RECEIVE_QTY IS NOT NULL   --签收数量不为空
                 AND L.SO_DOC_NUM = H.SO_NUM)                 
                 AND H.RECEIVE_DATE IS NULL
                 AND H.BIZ_SRC_BILL_TYPE_CODE = PKG_SO_PUB.V_BIZ_SRC_BILL_SO
                 AND H.CREATED_BY = 'LG'
                 AND NVL(H.RECEIVE_FLAG, 'N') != 'Y'
                 AND NVL(H.ENTITY_CUST_FLAG, 'N') = 'Y';
     */
  EXCEPTION
    WHEN OTHERS THEN
      P_RESULT  := -27001;
      P_ERR_MSG := '更新销售单签收信息，发生异常：' || SQLERRM;
  END;
  
  -------------------------------------------------------------------------------  
  /*
  *   创建日期：2017-06-14
  *     创建者：周建刚
  *   功能说明：通用错误日志记录功能
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_TABLE_ACTION_LOG(P_TABLE_NAME     VARCHAR2, --操作表名称
                               P_ACTION_REMARKS VARCHAR2, --操作说明
                               P_PK             VARCHAR2, --关键主键
                               P_ISERR          NUMBER, --是否出错，1出错，0未出错
                               P_MSG            VARCHAR2 --错误信息
                               ) AS
    PRAGMA AUTONOMOUS_TRANSACTION; --自治事务
  BEGIN
    INSERT INTO T_SO_TABLE_ACTION_LOG
      (ID, TABLE_NAME, ACTION_REMARKS, PK_NUM, ISERR, MSG, CREATED)
    VALUES
      (SYS_GUID(),
       P_TABLE_NAME,
       P_ACTION_REMARKS,
       P_PK,
       P_ISERR,
       P_MSG,
       SYSDATE);
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      NULL;
  END;
  
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2017-06-15
  *     创建者：周建刚
  *   功能说明：根据销售单号更新对已经的运输合同签收系统标识.
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_UPDATE_RECEIVE_SYSTEM(P_SO_NUM               IN VARCHAR2,  --单据号
                                       P_USER_CODE            IN VARCHAR2, --操作用户编码
                                       P_RESULT               OUT NUMBER,   --返回错误ID
                                       P_ERR_MSG              OUT VARCHAR2  --返回错误信息
                                       ) IS
    
  BEGIN
    P_RESULT  := V_RESULT;
    P_ERR_MSG := V_SUCCESS;
    
    UPDATE T_SO_HEADER H
       SET H.RECEIVE_SYSTEM =
           (SELECT NVL(T.RECEIVE_SYSTEM,'')
              FROM T_LG_CONTRACT T
             WHERE T.CONTRACT_CODE = H.CONTRACT_CODE
               AND ROWNUM = 1),
           H.LAST_UPDATED_BY = NVL(P_USER_CODE,PKG_SO_PUB.V_CREATED_BY_SYS),
           H.LAST_UPDATE_DATE = SYSDATE
     WHERE H.CONTRACT_CODE IS NOT NULL AND H.SO_NUM = P_SO_NUM;
    
  EXCEPTION
    WHEN OTHERS THEN
      P_RESULT  := -27001;
      P_ERR_MSG := '更新销售单[' || P_SO_NUM || ']的签收系统标识发生异常！' || SQLERRM;
  END;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2018-02-28
  *     创建者：周建刚
  *   功能说明：自动补全单据状态
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_AUTO_COMPLETION(P_RESULT               OUT NUMBER,   --返回错误ID
                                 P_ERR_MSG              OUT VARCHAR2  --返回错误信息
                                 ) IS
    
  BEGIN
    P_RESULT  := V_RESULT;
    P_ERR_MSG := V_SUCCESS;
    
    --来自ECM的空开票申请单据(没有对应财务单据的开票申请)
    UPDATE CIMS.T_AR_INVOICE_APPLY_HEADER I
       SET I.INVOICE_APPLY_STATUS = '12'
     WHERE NOT EXISTS (SELECT 1
              FROM CIMS.T_SO_HEADER H
             WHERE H.INVOICE_APPLY_ID = I.INVOICE_APPLY_ID
               AND H.ENTITY_ID = I.ENTITY_ID
               AND H.CREATION_DATE > SYSDATE - 90)
       AND I.SOURCE_CODE = 'ECM'
       AND I.INVOICE_APPLY_STATUS = '11';
    
    UPDATE CIMS.T_AR_INVOICE_APPLY_HEADER I
       SET I.INVOICE_APPLY_STATUS = '12'
     WHERE EXISTS (SELECT 1
              FROM CIMS.T_SO_HEADER H
             WHERE H.INVOICE_APPLY_ID = I.INVOICE_APPLY_ID
               AND H.SO_STATUS = '12'
               AND H.ENTITY_ID = I.ENTITY_ID
               AND H.CREATION_DATE > SYSDATE - 90)
       AND I.INVOICE_APPLY_STATUS = '11';
    
    --退货申请开单状态标识、单据状态更新
    --全部签收
    UPDATE CIMS.T_SO_RETURN_APPLY_HEADER RH
       SET RH.BILL_STATUS      = '13',
           RH.GEN_SO_FLAG      = '2',
           RH.LAST_UPDATE_DATE = SYSDATE
     WHERE EXISTS (SELECT 1
              FROM (SELECT RT.BILL_NUM
                      FROM (SELECT H.BILL_NUM AS "BILL_NUM",
                                   SUM(D.COMPONENT_QTY) AS R_TT
                              FROM CIMS.T_SO_RETURN_APPLY_HEADER      H,
                                   CIMS.T_SO_RETURN_APPLY_LINE_DETAIL D
                             WHERE H.APPLY_HEADER_ID = D.APPLY_HEADER_ID
                               AND EXISTS
                             (SELECT 1
                                      FROM CIMS.T_SO_HEADER SO
                                     WHERE SO.SRC_BILL_NUM = H.BILL_NUM)
                               AND H.GEN_SO_FLAG = '0'
                             GROUP BY H.BILL_NUM) RT,
                           (SELECT RH.BILL_NUM AS "BILL_NUM",
                                   SUM(D.COMPONENT_QTY) AS SO_TT
                              FROM CIMS.T_SO_HEADER              H,
                                   CIMS.T_SO_LINE_DETAIL         D,
                                   CIMS.T_SO_RETURN_APPLY_HEADER RH
                             WHERE H.SO_HEADER_ID = D.SO_HEADER_ID
                               AND H.BIZ_SRC_BILL_TYPE_CODE = '1003'
                               AND H.SRC_BILL_NUM = RH.BILL_NUM
                               AND RH.GEN_SO_FLAG = '0'
                             GROUP BY RH.BILL_NUM) ST
                     WHERE RT.BILL_NUM = ST.BILL_NUM
                       AND RT.R_TT = ST.SO_TT) T
             WHERE T.BILL_NUM = RH.BILL_NUM
               AND RH.GEN_SO_FLAG = '0');
    
    --部分签收
    UPDATE CIMS.T_SO_RETURN_APPLY_HEADER RH
       SET RH.GEN_SO_FLAG = '1', RH.LAST_UPDATE_DATE = SYSDATE
     WHERE EXISTS (SELECT 1
              FROM (SELECT RT.BILL_NUM
                      FROM (SELECT H.BILL_NUM AS "BILL_NUM",
                                   SUM(D.COMPONENT_QTY) AS R_TT
                              FROM CIMS.T_SO_RETURN_APPLY_HEADER      H,
                                   CIMS.T_SO_RETURN_APPLY_LINE_DETAIL D
                             WHERE H.APPLY_HEADER_ID = D.APPLY_HEADER_ID
                               AND EXISTS
                             (SELECT 1
                                      FROM CIMS.T_SO_HEADER SO
                                     WHERE SO.SRC_BILL_NUM = H.BILL_NUM)
                               AND H.GEN_SO_FLAG = '0'
                             GROUP BY H.BILL_NUM) RT,
                           (SELECT RH.BILL_NUM AS "BILL_NUM",
                                   SUM(D.COMPONENT_QTY) AS SO_TT
                              FROM CIMS.T_SO_HEADER              H,
                                   CIMS.T_SO_LINE_DETAIL         D,
                                   CIMS.T_SO_RETURN_APPLY_HEADER RH
                             WHERE H.SO_HEADER_ID = D.SO_HEADER_ID
                               AND H.BIZ_SRC_BILL_TYPE_CODE = '1003'
                               AND H.SRC_BILL_NUM = RH.BILL_NUM
                               AND RH.GEN_SO_FLAG = '0'
                             GROUP BY RH.BILL_NUM) ST
                     WHERE RT.BILL_NUM = ST.BILL_NUM
                       AND RT.R_TT != ST.SO_TT) T
             WHERE T.BILL_NUM = RH.BILL_NUM
               AND RH.GEN_SO_FLAG = '0');
    
    /**
    FOR REC IN (SELECT H.*
                  FROM CIMS.T_SO_HEADER H
                 WHERE EXISTS (SELECT 1
                          FROM CIMS.T_SO_HEADER_ECM_INTF T
                         WHERE T.INTF_LABEL = 'UPDATE_INVOICE_INFO'
                           AND T.PROCESS_FLAG = 'Y'
                           AND T.INVOICE_NUM_LIST IS NOT NULL
                           AND H.SO_NUM = T.SO_NUM)
                   AND NOT EXISTS (SELECT 1
                          FROM CIMS.T_SO_HEADER_ECM_INTF T
                         WHERE T.INTF_LABEL = 'UPDATE_INVOICE_INFO'
                           AND T.PROCESS_FLAG = 'N'
                           AND T.INVOICE_NUM_LIST IS NOT NULL
                           AND H.SO_NUM = T.SO_NUM)
                   AND H.CREATED_BY = 'ECM'
                   AND H.SO_STATUS = '12'
                   AND H.INVOICE_TYPE = '4'
                   AND H.INVOICE_NUM_LIST IS NULL
                   AND H.CREATION_DATE > SYSDATE - 7) LOOP
      
        UPDATE CIMS.T_SO_HEADER_ECM_INTF INTF
           SET INTF.PROCESS_FLAG = 'N', INTF.LAST_UPDATE_DATE = SYSDATE
         WHERE INTF.PROCESS_FLAG = 'Y'
           AND INTF.SO_INTF_ID =
               (SELECT I.SO_INTF_ID
                  FROM (SELECT T.*
                          FROM CIMS.T_SO_HEADER_ECM_INTF T
                         WHERE T.INTF_LABEL = 'UPDATE_INVOICE_INFO'
                           AND T.PROCESS_FLAG = 'Y'
                           AND T.SO_NUM = REC.SO_NUM
                         ORDER BY T.CREATION_DATE DESC) I
                 WHERE ROWNUM = 1);
    
    END LOOP;
    */
    
  EXCEPTION
    WHEN OTHERS THEN
      P_RESULT  := -27001;
      P_ERR_MSG := '自动补全单据状态发生异常！' || SQLERRM;
  END;
                                 
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2018-02-28
  *     创建者：周建刚
  *   功能说明：自动签收（仅供无需物流发货和签收的场景，不涉及差异处理）
                设置销售单头已签收、签收日期=当前日期；销售单行签收数量=产品数量（无差异签收），签收日期=当前日期
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_AUTO_RECEIVE(P_SO_HEADER_ID         IN NUMBER, --销售单据头ID
                              P_RESULT               OUT NUMBER,   --返回错误ID
                              P_ERR_MSG              OUT VARCHAR2  --返回错误信息
                              ) IS
    R_SO_HEADER T_SO_HEADER%ROWTYPE;
  BEGIN
    P_RESULT  := V_RESULT;
    P_ERR_MSG := V_SUCCESS;
    
    BEGIN
      SELECT H.* INTO R_SO_HEADER
       FROM T_SO_HEADER H
       WHERE H.SO_HEADER_ID = P_SO_HEADER_ID;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        P_ERR_MSG := '根据ID[' || P_SO_HEADER_ID || ']未查询到对应单据，请核实数据是否正确！';
        RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      WHEN OTHERS THEN
        P_ERR_MSG := '根据ID[' || P_SO_HEADER_ID || ']查询对应单据发生异常：' || SQLERRM;
        RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
    END;
    
    IF (NVL(R_SO_HEADER.RECEIVE_FLAG,PKG_SO_PUB.V_NO) = PKG_SO_PUB.V_YES) THEN
       P_RESULT  := -27001;
       P_ERR_MSG := '单据[' || R_SO_HEADER.SO_NUM || ']已经签收，请勿重复操作！';
       PKG_SO_PUB.P_EXCEPTION_THROWS(P_RESULT);
    END IF;
    
    UPDATE T_SO_HEADER H
       SET H.RECEIVE_SYSTEM   = 'CIMS',
           H.RECEIVE_FLAG     = PKG_SO_PUB.V_YES,
           H.RECEIVE_DATE     = SYSDATE,
           H.LAST_UPDATE_DATE = SYSDATE
     WHERE H.SO_HEADER_ID = P_SO_HEADER_ID;
    
    UPDATE T_SO_LINE L
       SET L.RECEIVED_QTY     = L.ITEM_QTY,
           L.RECEIVED_DATE    = SYSDATE,
           L.LAST_UPDATE_DATE = SYSDATE
     WHERE L.SO_HEADER_ID = P_SO_HEADER_ID;
    
  EXCEPTION
    WHEN OTHERS THEN
      P_RESULT  := -27001;
      P_ERR_MSG := '销售单[' || P_SO_HEADER_ID || ']自动签收发生异常！' || P_ERR_MSG || SQLERRM;
  END;
  
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2018-12-21
  *     创建者：周建刚
  *   功能说明：销售开单时校验销售单的单据类型配置是否完整。
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_CHECK_BILL_TYPE_CONFIG(P_ENTITY_ID            IN NUMBER,   --主体ID
                                        P_BILL_TYPE_ID         IN NUMBER,   --单据ID
                                        P_SALES_CENTER_ID      IN NUMBER,   --营销中心ID
                                        P_INV_ID               IN NUMBER,   --仓库ID
                                        P_OU_ID                IN NUMBER,   --营销ID
                                        P_RESULT               OUT NUMBER,  --返回错误ID
                                        P_ERR_MSG              OUT VARCHAR2 --返回错误信息
                                        ) IS
    V_OU_ID                NUMBER;       --营销OU（客户OU）ID
    V_OU_NAME              VARCHAR2(240); --营销OU（客户OU）名称
    --ERP订单类型ID
    V_ORDER_TYPE_ID NUMBER;
    --ERP订单类型编码
    V_ORDER_TYPE VARCHAR2(40);
    --销售单据类型的数量（如果存在，取单据类型，否则取销售单据源类型）
    V_SO_COUNT NUMBER;
    --业务单据类型扩展属性，这行扩展属性可用于控制一些业务逻辑。
    --业务单据类型扩展属性记录
    R_SO_BILL_TYPE_EXTEND V_SO_BILL_TYPE_EXTEND%ROWTYPE;
    
    V_SO_BILL_TYPE_CONFIG_CHECK  VARCHAR2(32);   --检查销售单据类型配置是否完整。
    
    V_INTF_SYSTEM_TYPE VARCHAR2(32);--财务接口对接系统标识 ERP：美的现有ERP系统；NC：用友NC财务系统。
    
  BEGIN
    P_RESULT  := V_RESULT;
    P_ERR_MSG := V_SUCCESS;
    
    --系统参数：SO_BILL_TYPE_CHECK，检查销售单据类型配置是否完整。
    PKG_BD.P_GET_PARAMETER_VALUE(PKG_SO_PUB.V_SO_BILL_TYPE_CONFIG_CHECK,
                                 P_ENTITY_ID,
                                 NULL,
                                 NULL,
                                 V_SO_BILL_TYPE_CONFIG_CHECK);
    
    --对接系统为NC,则无需写ERP接口表
    IF (V_SO_BILL_TYPE_CONFIG_CHECK = PKG_SO_PUB.V_NO) THEN
      RETURN;
    END IF;

    BEGIN
      --获取业务单据类型扩展属性
      SELECT T.* INTO R_SO_BILL_TYPE_EXTEND
        FROM V_SO_BILL_TYPE_EXTEND T
       WHERE T.BILL_TYPE_ID = P_BILL_TYPE_ID
         AND T.ENTITY_ID = P_ENTITY_ID
         AND (TRUNC(SYSDATE) BETWEEN T.BEGIN_DATE AND NVL(T.END_DATE, SYSDATE));
    EXCEPTION
      WHEN OTHERS THEN
        P_RESULT  := -28866;
        P_ERR_MSG := '销售单据类型[' || P_BILL_TYPE_ID || ']没有业务单据类型扩展配置信息，请配置！菜单路径：销售管理/基础数据/业务单据类型扩展配置';
        RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
    END;
    
    PKG_BD.P_GET_PARAMETER_VALUE(PKG_SO_PUB.V_INTF_SYSTEM_TYPE,
                                 P_ENTITY_ID,
                                 NULL,
                                 NULL,
                                 V_INTF_SYSTEM_TYPE);
    
    IF (V_INTF_SYSTEM_TYPE <> PKG_SO_PUB.V_INTF_SYSTEM_TYPE_ERP) THEN
      RETURN;
    END IF;
    
    /**
    * 1001 销售单;1002 销售红冲单;1003 退货单;1004 退货红冲单;
    * 1005 销售折让单;1006 反向销售折让单;1007 折让证明单;1008 反向折让证明单
    */
    IF (NVL(R_SO_BILL_TYPE_EXTEND.SRC_TYPE_CODE,'-') = '1001'
        OR NVL(R_SO_BILL_TYPE_EXTEND.SRC_TYPE_CODE,'-') = '1002'
        OR NVL(R_SO_BILL_TYPE_EXTEND.SRC_TYPE_CODE,'-') = '1003'
        OR NVL(R_SO_BILL_TYPE_EXTEND.SRC_TYPE_CODE,'-') = '1004'
        ) THEN

      --校验销售单类型是否配置了对应的ERP订单类型。
      PKG_SO_INTF.P_SO_CUST_OU_INFO(
                                    P_ENTITY_ID,          --主体ID
                                    P_SALES_CENTER_ID,    --营销中心ID
                                    P_INV_ID,             --仓库ID
                                    R_SO_BILL_TYPE_EXTEND.PROMOTION_FLAY,--是否推广物料。N：不是推广物料单据，Y：是推广物料单据
                                    V_OU_ID,              --营销OU（客户OU）ID
                                    V_OU_NAME,            --营销OU（客户OU）名称
                                    P_RESULT,             --返回错误ID
                                    P_ERR_MSG             --返回错误信息
                                    );
      
      IF P_RESULT < 0 THEN
        RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      END IF;
        
      --优先取销售单据类型，销售单据类型为空时再取单源类型(龙鸿文)
      SELECT COUNT(1)
        INTO V_SO_COUNT
        FROM V_SO_TYPE_EXTEND_RELATION
       WHERE BILL_TYPE_ID = P_BILL_TYPE_ID
         AND ORG_ID = V_OU_ID
         AND ENTITY_ID = P_ENTITY_ID
         AND ROWNUM = 1;
      IF V_SO_COUNT > 0 THEN
         --获取对应的ERP订单类型
         SELECT TRANSACTION_TYPE_ID, NAME
           INTO V_ORDER_TYPE_ID, V_ORDER_TYPE
           FROM V_SO_TYPE_EXTEND_RELATION
          WHERE BILL_TYPE_ID = P_BILL_TYPE_ID
            AND ORG_ID = V_OU_ID
            AND ENTITY_ID = P_ENTITY_ID
            AND ROWNUM = 1;
      ELSE
         --获取对应的ERP订单类型(源类型)
         BEGIN
           SELECT TRANSACTION_TYPE_ID, NAME
             INTO V_ORDER_TYPE_ID, V_ORDER_TYPE
             FROM V_SO_ERP_TYPE_RELATION
            WHERE SRC_TYPE_ID = R_SO_BILL_TYPE_EXTEND.SRC_TYPE_ID
              AND ORG_ID = V_OU_ID
              AND ENTITY_ID = P_ENTITY_ID
              AND ROWNUM = 1;
         EXCEPTION
           WHEN NO_DATA_FOUND THEN
             P_ERR_MSG := '销售单据类型[' || P_BILL_TYPE_ID || '],销售单据源类型[' || R_SO_BILL_TYPE_EXTEND.SRC_TYPE_ID || ',' || R_SO_BILL_TYPE_EXTEND.SRC_TYPE_CODE || ',' || R_SO_BILL_TYPE_EXTEND.SRC_TYPE_NAME
                        || ']没有配置对应的ERP订单类型或ERP订单类型不属于当前OU[' ||
                          V_OU_ID || ',' || V_OU_NAME || ']';
             RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
           WHEN OTHERS THEN
             P_ERR_MSG := '获取对应的ERP订单类型发生异常：' || SQLERRM;
             RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
         END;
      END IF;
    ELSIF (NVL(R_SO_BILL_TYPE_EXTEND.SRC_TYPE_CODE,'-') = '1005'
        OR NVL(R_SO_BILL_TYPE_EXTEND.SRC_TYPE_CODE,'-') = '1006'
        OR NVL(R_SO_BILL_TYPE_EXTEND.SRC_TYPE_CODE,'-') = '1007'
        OR NVL(R_SO_BILL_TYPE_EXTEND.SRC_TYPE_CODE,'-') = '1008') THEN

      --优先取销售单据类型，销售单据类型为空时再取单源类型(龙鸿文)
      SELECT COUNT(1)
        INTO V_SO_COUNT
        FROM V_SO_TYPE_EXTEND_RELATION
       WHERE BILL_TYPE_ID = P_BILL_TYPE_ID
         AND ORG_ID = P_OU_ID
         AND ENTITY_ID = P_ENTITY_ID
         AND ROWNUM = 1;
      IF V_SO_COUNT > 0 THEN
         --获取对应的ERP订单类型
         SELECT TRANSACTION_TYPE_ID, NAME
           INTO V_ORDER_TYPE_ID, V_ORDER_TYPE
           FROM V_SO_TYPE_EXTEND_RELATION
          WHERE BILL_TYPE_ID = P_BILL_TYPE_ID
            AND ORG_ID = P_OU_ID
            AND ENTITY_ID = P_ENTITY_ID
            AND ROWNUM = 1;
      ELSE
         --获取对应的ERP订单类型(源类型)
         BEGIN
           SELECT TRANSACTION_TYPE_ID, NAME
             INTO V_ORDER_TYPE_ID, V_ORDER_TYPE
             FROM V_SO_ERP_TYPE_RELATION
            WHERE SRC_TYPE_ID = R_SO_BILL_TYPE_EXTEND.SRC_TYPE_ID
              AND ORG_ID = P_OU_ID
              AND ENTITY_ID = P_ENTITY_ID
              AND ROWNUM = 1;
         EXCEPTION
           WHEN NO_DATA_FOUND THEN
             P_ERR_MSG := '销售单据类型[' || P_BILL_TYPE_ID || '],销售单据源类型[' || R_SO_BILL_TYPE_EXTEND.SRC_TYPE_ID || ',' || R_SO_BILL_TYPE_EXTEND.SRC_TYPE_CODE || ',' || R_SO_BILL_TYPE_EXTEND.SRC_TYPE_NAME
                        || ']没有配置对应的ERP订单类型或ERP订单类型不属于当前OU[' ||
                          P_OU_ID || ']';
             RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
           WHEN OTHERS THEN
             P_ERR_MSG := '获取对应的ERP订单类型发生异常：' || SQLERRM;
             RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
         END;
      END IF;
    END IF;
          
  EXCEPTION
    WHEN PKG_SO_PUB.V_BIZ_EXCEPTION THEN
      P_RESULT  := -28000;
      P_ERR_MSG := '校验失败！' || P_ERR_MSG;
    WHEN OTHERS THEN
      P_RESULT  := -27001;
      P_ERR_MSG := '销售开单，校验单据类型配置是否完整发生异常！单据[' || P_BILL_TYPE_ID || '],主体['
       || P_ENTITY_ID || '],中心[' || P_SALES_CENTER_ID || '],仓库[' || P_INV_ID || ']' || P_ERR_MSG || SQLERRM;
  END;
  
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2019-01-16
  *     创建者：周建刚
  *   功能说明：判定客户、中心对应的转采购关系。
  *       查询：跨主体关系 T_BD_CENTER_RELATION , 事业部供需关系 T_SO_SUPPLIER_REQUIRE_ENTITY
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_CHECK_PO_RELATION_CONFIG(P_ENTITY_ID            IN NUMBER,     --主体ID
                                          P_CUSTOMER_CODE        IN VARCHAR2,   --客户编码
                                          P_SALES_CENTER_CODE    IN VARCHAR2,   --营销中心编码
                                          P_INV_CODE             IN VARCHAR2,   --仓库编码
                                          P_PO_RELATION_FLAG     OUT VARCHAR2,  --采购关系标识
                                          P_RESULT               OUT NUMBER,    --返回错误ID
                                          P_ERR_MSG              OUT VARCHAR2   --返回错误信息
                                          ) IS 
    V_CONFIG_COUNT NUMBER :=0;
    
    R_INV_INVENTORIES T_INV_INVENTORIES%ROWTYPE;
    
    V_INTF_SYSTEM_TYPE VARCHAR2(32);--财务接口对接系统标识 ERP：美的现有ERP系统；NC：用友NC财务系统。
    
    R_BD_CENTER_RELATION T_BD_CENTER_RELATION%ROWTYPE;
    
    V_SO_RETURN_PO_RELATION_FLAG VARCHAR2(32);
  BEGIN
    P_RESULT  := V_RESULT;
    P_ERR_MSG := V_SUCCESS;
    P_PO_RELATION_FLAG := PKG_SO_PUB.V_NO;
    
    PKG_BD.P_GET_PARAMETER_VALUE(PKG_SO_PUB.V_INTF_SYSTEM_TYPE,
                                 P_ENTITY_ID,
                                 NULL,
                                 NULL,
                                 V_INTF_SYSTEM_TYPE);
    
    IF (V_INTF_SYSTEM_TYPE = PKG_SO_PUB.V_INTF_SYSTEM_TYPE_NC) THEN
      RETURN;
    END IF;
    
    --跨主体采购关系新模式，系统控制参数。
    PKG_BD.P_GET_PARAMETER_VALUE('SO_RETURN_PO_RELATION_FLAG',
                                 P_ENTITY_ID,
                                 NULL,
                                 NULL,
                                 V_SO_RETURN_PO_RELATION_FLAG);
    
    IF (V_SO_RETURN_PO_RELATION_FLAG <> PKG_SO_PUB.V_YES) THEN
      RETURN;
    END IF;
    
    IF (P_INV_CODE IS NULL) THEN
      RETURN;
    END IF;
    
    BEGIN
      SELECT I.*
        INTO R_INV_INVENTORIES
        FROM CIMS.T_INV_INVENTORIES I
       WHERE I.INVENTORY_CODE = P_INV_CODE
         AND I.ENTITY_ID = P_ENTITY_ID;
         
      IF (R_INV_INVENTORIES.DOCKING_SYSTEM != 'A3') THEN
        RETURN;
      END IF;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        P_RESULT  := -28866;
        P_ERR_MSG := '查询跨主体关系(采购关系)出现错误，仓库不存在！主体[' || P_ENTITY_ID || '],仓库[' || P_INV_CODE || ']';
        RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      WHEN OTHERS THEN
        P_RESULT  := -28866;
        P_ERR_MSG := '查询跨主体关系(采购关系)发生异常！' || SQLERRM;
        RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
    END;
    
    BEGIN
      SELECT R.*
        INTO R_BD_CENTER_RELATION
        FROM T_BD_CENTER_RELATION R
       WHERE TRUNC(SYSDATE) BETWEEN R.BEGIN_DATE AND
             NVL(R.END_DATE, SYSDATE)
         AND R.HQ_ENTITY_ID = P_ENTITY_ID
         AND R.HQ_CUSTOMER_CODE = P_CUSTOMER_CODE
         AND R.HQ_SALES_CENTER_CODE = P_SALES_CENTER_CODE
         AND R.SC_ENTITY_ID NOT IN (35,36)   --集团工程业务公司,高端品牌公司
         AND ROWNUM = 1;
      
      PKG_BD.P_GET_PARAMETER_VALUE(PKG_SO_PUB.V_INTF_SYSTEM_TYPE,
                                   R_BD_CENTER_RELATION.SC_ENTITY_ID,
                                   NULL,
                                   NULL,
                                   V_INTF_SYSTEM_TYPE);
      
      IF (V_INTF_SYSTEM_TYPE = PKG_SO_PUB.V_INTF_SYSTEM_TYPE_NC) THEN
        /**
        --跨主体关系(采购关系)
        SELECT COUNT(1)
          INTO V_CONFIG_COUNT
          FROM T_BD_CENTER_RELATION R
         WHERE TRUNC(SYSDATE) BETWEEN R.BEGIN_DATE AND
               NVL(R.END_DATE, SYSDATE)
           AND R.HQ_ENTITY_ID = P_ENTITY_ID
           AND R.HQ_CUSTOMER_CODE = P_CUSTOMER_CODE
           AND R.HQ_SALES_CENTER_CODE = P_SALES_CENTER_CODE;
        */
        P_PO_RELATION_FLAG := 'Y';
      END IF;
      
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        NULL;
        /**
        BEGIN
          SELECT COUNT(1)
            INTO V_CONFIG_COUNT
            FROM T_SO_SUPPLIER_REQUIRE_ENTITY C
           WHERE C.SUPPLIER_ENTITY_ID = P_ENTITY_ID
             AND C.REQUIREMENT_CUSTOMER_CODE = P_CUSTOMER_CODE;
        
          IF (V_CONFIG_COUNT > 0) THEN
            P_PO_RELATION_FLAG := 'Y';
          END IF;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            NULL;
          WHEN OTHERS THEN
            P_RESULT  := -28866;
            P_ERR_MSG := '查询事业部供需关系出现错误！主体[' || P_ENTITY_ID || '],主体[' || P_CUSTOMER_CODE || ']';
            RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
        END;
        */

      WHEN PKG_SO_PUB.V_BIZ_EXCEPTION THEN
        RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      WHEN OTHERS THEN
        
        P_RESULT  := -28866;
        P_ERR_MSG := '查询跨主体关系(采购关系)出现错误！主体[' || P_ENTITY_ID || '],主体[' || P_CUSTOMER_CODE || '],中心[' || P_SALES_CENTER_CODE || ']';
        RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
    END;
    
  EXCEPTION
    WHEN PKG_SO_PUB.V_BIZ_EXCEPTION THEN
      P_RESULT  := -28000;
      P_ERR_MSG := '校验失败！' || P_ERR_MSG;
    WHEN OTHERS THEN
      P_RESULT  := -27001;
      P_ERR_MSG := '判定客户、中心对应的转采购关系发生异常！客户[' || P_CUSTOMER_CODE || '],中心[' || P_SALES_CENTER_CODE || ']' || '],仓库[' || P_INV_CODE || ']' || P_ERR_MSG || SQLERRM;
  END;
  
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2019-01-24
  *     创建者：周建刚
  *   功能说明：退货申请签收差异给承运商开全陪单
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_RTN_DIFF_TO_VENDER(P_BILL_NUM         IN VARCHAR2,   --退货申请单号
                                    P_RECEIVE_DOC_CODE IN VARCHAR2,--收货通知单
                                    P_RESULT          OUT NUMBER,  --返回错误ID
                                    P_ERR_MSG         OUT VARCHAR2 --返回错误信息
                                    ) IS 

    V_DIFF_COUNT NUMBER := 0;
    R_BD_ITEM_ASSEMBLIES_SUB V_BD_ITEM_ASSEMBLIES_SUB%ROWTYPE;
    
    R_SO_RETURN_APPLY_HEADER T_SO_RETURN_APPLY_HEADER%ROWTYPE;
    C_SO_BILL_TYPE_EXTEND V_SO_BILL_TYPE_EXTEND%ROWTYPE;
    
    --销售单据接口头记录
    R_SO_INFT_HEADER T_SO_HEADER_INTERFACE%ROWTYPE;
    --销售单据接口行记录
    R_SO_INFT_LINE T_SO_LINE_INTERFACE%ROWTYPE;
    
    TYPE SO_LINE_INTF_COMPONENT_ARRAY IS TABLE OF T_SO_LINE_INTERFACE%ROWTYPE INDEX BY BINARY_INTEGER;
    SO_LINE_INTF_COM_ARRAY               SO_LINE_INTF_COMPONENT_ARRAY;
    SO_LINE_INTF_COM_ARRAY_MERGE         SO_LINE_INTF_COMPONENT_ARRAY;
    --循环计数器
    V_COUNT NUMBER := 1;
    
    V_COMPONENT_CODE VARCHAR2(100);
    
    R_BD_ITEM T_BD_ITEM%ROWTYPE;
  BEGIN
    P_RESULT  := V_RESULT;
    P_ERR_MSG := V_SUCCESS;
    SO_LINE_INTF_COM_ARRAY.DELETE;
    
    SELECT T.*
      INTO R_SO_RETURN_APPLY_HEADER
      FROM CIMS.T_SO_RETURN_APPLY_HEADER T
     WHERE T.BILL_NUM = P_BILL_NUM;
    
    IF (PKG_SO_PUB.V_YES <> NVL(R_SO_RETURN_APPLY_HEADER.PO_RELATION_FLAG,PKG_SO_PUB.V_NO)) THEN
      RETURN;
    END IF;
    
    --计算散件差异总计
    SELECT COUNT(1)
      INTO V_DIFF_COUNT
      FROM CIMS.INTF_SALESRTN_LINES LS
     WHERE LS.RETURN_QTY > NVL(LS.RECEIVED_QTY, 0)
       AND EXISTS
     (SELECT 1
              FROM CIMS.INTF_SALESRTN_HEADERS H
             WHERE H.SALESRTN_HEADERS_ID = LS.SALESRTN_HEADERS_ID
               AND H.BILL_NUM = R_SO_RETURN_APPLY_HEADER.BILL_NUM
               AND H.RECEIVE_DOC_CODE = P_RECEIVE_DOC_CODE);
    
    --判定签收是否有差异
    IF (V_DIFF_COUNT < 1) THEN
      RETURN;
    END IF;

    R_SO_INFT_HEADER.ENTITY_ID             := R_SO_RETURN_APPLY_HEADER.ENTITY_ID;
    R_SO_INFT_HEADER.SHIP_INV_ID           := R_SO_RETURN_APPLY_HEADER.RECEIVE_INV_ID;
    R_SO_INFT_HEADER.SO_DATE               := TRUNC(SYSDATE);
    R_SO_INFT_HEADER.SALES_MAIN_TYPE       := R_SO_RETURN_APPLY_HEADER.SALES_MAIN_TYPE;
    R_SO_INFT_HEADER.SALES_MAIN_TYPE_NAME  := R_SO_RETURN_APPLY_HEADER.SALES_MAIN_TYPE_NAME;
    R_SO_INFT_HEADER.REMARK                := '退货申请[' || R_SO_RETURN_APPLY_HEADER.BILL_NUM || ']签收差异给承运商开全陪单。';
    R_SO_INFT_HEADER.CREATED_MODE          := 30;
    R_SO_INFT_HEADER.CREATION_DATE         := SYSDATE;
    R_SO_INFT_HEADER.CREATED_BY            := PKG_SO_PUB.V_CREATED_BY_SYS;
    R_SO_INFT_HEADER.LAST_UPDATE_DATE      := R_SO_INFT_HEADER.CREATION_DATE;
    R_SO_INFT_HEADER.LAST_UPDATED_BY       := R_SO_INFT_HEADER.CREATED_BY;
    R_SO_INFT_HEADER.RECEIVE_FLAG          := PKG_SO_PUB.V_YES;
    R_SO_INFT_HEADER.RECEIVE_DATE          := R_SO_INFT_HEADER.CREATION_DATE;
    R_SO_INFT_HEADER.SRC_TYPE              := PKG_SO_PUB.V_SRC_TYPE_13;
    R_SO_INFT_HEADER.SRC_BILL_NUM          := R_SO_RETURN_APPLY_HEADER.BILL_NUM;
    R_SO_INFT_HEADER.SRC_BILL_TYPE_ID      := R_SO_RETURN_APPLY_HEADER.BILL_TYPE_ID;
    R_SO_INFT_HEADER.SRC_BILL_TYPE_CODE    := R_SO_RETURN_APPLY_HEADER.BILL_TYPE_CODE;
    R_SO_INFT_HEADER.SRC_BILL_TYPE_NAME    := R_SO_RETURN_APPLY_HEADER.BILL_TYPE_NAME;
    R_SO_INFT_HEADER.SRC_BILL_ID           := R_SO_RETURN_APPLY_HEADER.APPLY_HEADER_ID;
    R_SO_INFT_HEADER.RAW_SRC_TYPE          := PKG_SO_PUB.V_SRC_TYPE_13;
    R_SO_INFT_HEADER.RAW_SRC_BILL_NUM      := R_SO_RETURN_APPLY_HEADER.BILL_NUM;
    R_SO_INFT_HEADER.RAW_SRC_BILL_TYPE_ID  := R_SO_RETURN_APPLY_HEADER.BILL_TYPE_ID;
    R_SO_INFT_HEADER.RAW_SRC_BILL_TYPE_CODE:= R_SO_RETURN_APPLY_HEADER.BILL_TYPE_CODE;
    R_SO_INFT_HEADER.RAW_SRC_BILL_TYPE_NAME:= R_SO_RETURN_APPLY_HEADER.BILL_TYPE_NAME;
    R_SO_INFT_HEADER.SRC_BILL_ID           := R_SO_RETURN_APPLY_HEADER.APPLY_HEADER_ID;
    
    SELECT T.BILL_TYPE_ID,
           T.BILL_TYPE_CODE,
           T.BILL_TYPE_NAME,
           T.SRC_TYPE_ID,
           T.SRC_TYPE_CODE,
           T.SRC_TYPE_NAME
      INTO R_SO_INFT_HEADER.BILL_TYPE_ID,
           R_SO_INFT_HEADER.BILL_TYPE_CODE,
           R_SO_INFT_HEADER.BILL_TYPE_NAME,
           R_SO_INFT_HEADER.BIZ_SRC_BILL_TYPE_ID,
           R_SO_INFT_HEADER.BIZ_SRC_BILL_TYPE_CODE,
           R_SO_INFT_HEADER.BIZ_SRC_BILL_TYPE_NAME
      FROM CIMS.V_SO_BILL_TYPE_EXTEND T
     WHERE T.BILL_TYPE_CODE = '1020'
       AND T.SRC_TYPE_CODE = PKG_SO_PUB.V_BIZ_SRC_BILL_SO
       AND T.ENTITY_ID = R_SO_INFT_HEADER.ENTITY_ID;
                                                      
    --查询承运商编码和名称
    BEGIN
      --获取默认承运商
      R_SO_INFT_HEADER.VENDOR_ID := PKG_BD.F_GET_PARAMETER_VALUE(P_CONFIG_CODE => 'lgDefaultVendor', --参数配置编码
                                                               P_ENTITY_ID   => R_SO_INFT_HEADER.ENTITY_ID, --业务主体ID
                                                               P_UNIT_ID     => NULL, --中心ID
                                                               P_CUSTOMER_ID => NULL --客户ID
                                                               );
      
      SELECT V.VENDOR_ID,V.VENDOR_CODE, V.VENDOR_NAME
        INTO R_SO_INFT_HEADER.CUSTOMER_ID,R_SO_INFT_HEADER.CUSTOMER_CODE,R_SO_INFT_HEADER.CUSTOMER_NAME
        FROM T_LG_VENDOR_INFO_HEAD V
       WHERE V.VENDOR_ID = R_SO_INFT_HEADER.VENDOR_ID;
       
      --优先按照对应承运商编码、营销中心编码、主体查询，没有则安排承运商编码、主体查询
      BEGIN
        SELECT CA.CUSTOMER_ID,
               CA.CUSTOMER_CODE,
               CA.CUSTOMER_NAME,
               CA.ACCOUNT_ID,
               CA.ACCOUNT_CODE,
               CA.SALES_CENTER_ID,
               CA.SALES_CENTER_CODE,
               CA.SALES_CENTER_NAME
          INTO R_SO_INFT_HEADER.CUSTOMER_ID,
               R_SO_INFT_HEADER.CUSTOMER_CODE,
               R_SO_INFT_HEADER.CUSTOMER_NAME,
               R_SO_INFT_HEADER.ACCOUNT_ID,
               R_SO_INFT_HEADER.ACCOUNT_CODE,
               R_SO_INFT_HEADER.SALES_CENTER_ID,
               R_SO_INFT_HEADER.SALES_CENTER_CODE,
               R_SO_INFT_HEADER.SALES_CENTER_NAME
          FROM T_CUSTOMER_HEADER CR, V_CUST_ACCOUNT CA
         WHERE CR.CUSTOMER_ID = CA.CUSTOMER_ID
           AND CR.CUSTOMER_IS_VENDOR = PKG_SO_PUB.V_YES
           AND CA.SALES_CENTER_CODE = R_SO_RETURN_APPLY_HEADER.SALES_CENTER_CODE
           AND CR.CUSTOMER_VENDOR_CODE = R_SO_INFT_HEADER.CUSTOMER_CODE
           AND CA.ENTITY_ID = R_SO_INFT_HEADER.ENTITY_ID
           AND ROWNUM = 1;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          
          IF (R_SO_INFT_HEADER.ACCOUNT_CODE IS NULL) THEN
            SELECT CA.CUSTOMER_ID,
                   CA.CUSTOMER_CODE,
                   CA.CUSTOMER_NAME,
                   CA.ACCOUNT_ID,
                   CA.ACCOUNT_CODE,
                   CA.SALES_CENTER_ID,
                   CA.SALES_CENTER_CODE,
                   CA.SALES_CENTER_NAME
              INTO R_SO_INFT_HEADER.CUSTOMER_ID,
                   R_SO_INFT_HEADER.CUSTOMER_CODE,
                   R_SO_INFT_HEADER.CUSTOMER_NAME,
                   R_SO_INFT_HEADER.ACCOUNT_ID,
                   R_SO_INFT_HEADER.ACCOUNT_CODE,
                   R_SO_INFT_HEADER.SALES_CENTER_ID,
                   R_SO_INFT_HEADER.SALES_CENTER_CODE,
                   R_SO_INFT_HEADER.SALES_CENTER_NAME
              FROM T_CUSTOMER_HEADER CR, V_CUST_ACCOUNT CA
             WHERE CR.CUSTOMER_ID = CA.CUSTOMER_ID
               AND CR.CUSTOMER_IS_VENDOR = PKG_SO_PUB.V_YES
               AND CR.CUSTOMER_VENDOR_CODE = R_SO_INFT_HEADER.CUSTOMER_CODE
               AND CA.ENTITY_ID = R_SO_INFT_HEADER.ENTITY_ID
               AND ROWNUM = 1;
          END IF;
            
        WHEN OTHERS THEN
          R_SO_INFT_HEADER.ACCOUNT_CODE := NULL;
          P_RESULT  := -28000;
          P_ERR_MSG := '获取承运商[' || R_SO_INFT_HEADER.VENDOR_ID || ']中心、账户信息时发生错误' || SQLERRM;
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      END;

    EXCEPTION
      WHEN OTHERS THEN
        P_RESULT  := -28000;
        P_ERR_MSG := '获取承运商信息发生异常' || SQLERRM;
        RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
    END;
    
    BEGIN
      --获取地址信息
      SELECT T.ADDRESS_ID, T.PROVINCE, T.CITY, T.AREA, T.TOWNS, T.ADDRESS
        INTO R_SO_INFT_HEADER.CONSIGNEE_ADDRESS_ID,
             R_SO_INFT_HEADER.CONSIGNEE_PROVINCE_CODE,
             R_SO_INFT_HEADER.CONSIGNEE_CITY_CODE,
             R_SO_INFT_HEADER.CONSIGNEE_DISTRICT_CODE,
             R_SO_INFT_HEADER.CONSIGNEE_TOWN_CODE,
             R_SO_INFT_HEADER.CONSIGNEE_ADDRESS
        FROM V_CUSTOMER_ADDRESS T
       WHERE T.ADDRESS_TYPE = 'ShipTo'
         AND T.ACTIVE_FLAG = 'Active'
         AND T.ACCOUNT_CODE = R_SO_INFT_HEADER.ACCOUNT_CODE
         AND T.ENTITY_ID = R_SO_INFT_HEADER.ENTITY_ID
         AND ROWNUM = 1
       ORDER BY T.IS_MAIN DESC;
    EXCEPTION
      WHEN OTHERS THEN
      P_RESULT  := -28000;
      P_ERR_MSG := '获取客户[' || R_SO_INFT_HEADER.CUSTOMER_NAME || '],账户[' || R_SO_INFT_HEADER.ACCOUNT_CODE || ']地址信息发生错误' || SQLERRM;
      RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
    END;
    
    --生成销售单据接口头记录
    PKG_SO_BIZ.P_SO_CREATE_INTF_HEADER(R_SO_INFT_HEADER,
                                       R_SO_INFT_HEADER.CREATED_BY,
                                       P_RESULT,
                                       P_ERR_MSG);
    --根据P_RESULT判断是否抛出异常
    PKG_SO_PUB.P_EXCEPTION_THROWS(P_RESULT);
    
    --差异计算第一步：套件差异
    FOR REC IN (SELECT LS.*
                  FROM CIMS.INTF_SALESRTN_LINES_SET LS
                 WHERE EXISTS (SELECT 1
                          FROM CIMS.INTF_SALESRTN_HEADERS H
                         WHERE H.SALESRTN_HEADERS_ID = LS.SALESRTN_HEADERS_ID
                           AND H.BILL_NUM = R_SO_RETURN_APPLY_HEADER.BILL_NUM
                           AND H.RECEIVE_DOC_CODE = P_RECEIVE_DOC_CODE)
                   AND LS.RETURN_QTY > NVL(LS.RECEIVE_QTY, 0)
                ) LOOP
                
      SELECT I.*
        INTO R_BD_ITEM
        FROM CIMS.T_BD_ITEM I
       WHERE I.ENTITY_ID = REC.ENTITY_ID
         AND I.ITEM_CODE = REC.ITEM_CODE
         AND ROWNUM = 1;
      
      --差异直接给承运商开全陪单
      R_SO_INFT_LINE.ENTITY_ID                 := R_SO_INFT_HEADER.ENTITY_ID;
      R_SO_INFT_LINE.SO_HEADER_INTERFACE_ID    := R_SO_INFT_HEADER.SO_HEADER_INTERFACE_ID;
      R_SO_INFT_LINE.CREATED_BY                := R_SO_INFT_HEADER.CREATED_BY;
      R_SO_INFT_LINE.CREATION_DATE             := R_SO_INFT_HEADER.CREATION_DATE;
      R_SO_INFT_LINE.LAST_UPDATED_BY           := R_SO_INFT_LINE.CREATED_BY;
      R_SO_INFT_LINE.LAST_UPDATE_DATE          := R_SO_INFT_LINE.CREATION_DATE;
      R_SO_INFT_LINE.ITEM_ID     := R_BD_ITEM.ITEM_ID;
      R_SO_INFT_LINE.ITEM_CODE   := REC.ITEM_CODE;
      R_SO_INFT_LINE.ITEM_NAME   := REC.ITEM_NAME;
      R_SO_INFT_LINE.ITEM_UOM    := REC.ITEM_UOM;
      R_SO_INFT_LINE.ITEM_QTY    := REC.RETURN_QTY - NVL(REC.RECEIVE_QTY,0);
      
      --设置产品价格
      P_SO_SET_ITEM_PRICE(R_SO_INFT_HEADER,  --销售单据接口头记录
                          R_SO_INFT_LINE,    --销售单据接口行记录
                          P_RESULT,          --返回错误ID
                          P_ERR_MSG          --返回错误信息
                          );
      --根据P_RESULT判断是否抛出异常
      PKG_SO_PUB.P_EXCEPTION_THROWS(P_RESULT);
      
      --生成销售单据接口行记录
      PKG_SO_BIZ.P_SO_CREATE_INTF_LINE(R_SO_INFT_LINE,
                                       R_SO_INFT_LINE.CREATED_BY,
                                       P_RESULT,
                                       P_ERR_MSG);
      PKG_SO_PUB.P_EXCEPTION_THROWS(P_RESULT);
    
    END LOOP;
    
    --差异计算第二步：未配套的差异散件
    FOR REC IN (SELECT DS.COMPONENT_ID,DS.COMPONENT_CODE,DS.COMPONENT_NAME,
                       SUM(NVL(DS.RETURN_QTY,0) - NVL(DS.RECEIVED_QTY,0) - (NVL(LS.RETURN_QTY,0)-NVL(LS.RECEIVE_QTY,0)) * NVL(S.QUANTITY,0)) DIFF_COMPONENT_QTY
                  FROM CIMS.INTF_SALESRTN_LINES_SET LS,
                       CIMS.INTF_SALESRTN_LINES DS, 
                       CIMS.V_BD_ITEM_ASSEMBLIES_SUB S
                 WHERE EXISTS (SELECT 1
                          FROM CIMS.INTF_SALESRTN_HEADERS H
                         WHERE H.SALESRTN_HEADERS_ID = LS.SALESRTN_HEADERS_ID
                           AND H.BILL_NUM = R_SO_RETURN_APPLY_HEADER.BILL_NUM
                           AND H.RECEIVE_DOC_CODE = P_RECEIVE_DOC_CODE)
                   AND EXISTS (SELECT 1 FROM CIMS.INTF_SALESRTN_HEADERS H
                    WHERE DS.SALESRTN_HEADERS_ID = H.SALESRTN_HEADERS_ID
                      AND H.BILL_NUM = R_SO_RETURN_APPLY_HEADER.BILL_NUM
                      AND H.RECEIVE_DOC_CODE = P_RECEIVE_DOC_CODE)
                   AND LS.ITEM_CODE = DS.ITEM_CODE
                   AND S.ITEM_CODE = LS.ITEM_CODE
                   AND S.ENTITY_ID = LS.ENTITY_ID
                   AND S.SUB_ITEM_CODE = DS.COMPONENT_CODE
                   AND LS.ITEM_UOM = 'Set'
                   AND S.ACTIVE_FLAG = 'Y'
                   AND S.ASSEMBLE_ACTIVE_FLAG = 'Y'
                   AND (NVL(DS.RETURN_QTY,0) - NVL(DS.RECEIVED_QTY,0) - (NVL(LS.RETURN_QTY,0)-NVL(LS.RECEIVE_QTY,0)) * NVL(S.QUANTITY,0)) > 0
                   GROUP BY DS.COMPONENT_ID,DS.COMPONENT_CODE,DS.COMPONENT_NAME
                ) LOOP
                
      SELECT I.*
        INTO R_BD_ITEM
        FROM CIMS.T_BD_ITEM I
       WHERE I.ENTITY_ID = R_SO_INFT_HEADER.ENTITY_ID
         AND I.ITEM_CODE = REC.COMPONENT_CODE
         AND ROWNUM = 1;
      
      --差异直接给承运商开全陪单
      R_SO_INFT_LINE.ENTITY_ID                 := R_SO_INFT_HEADER.ENTITY_ID;
      R_SO_INFT_LINE.SO_HEADER_INTERFACE_ID    := R_SO_INFT_HEADER.SO_HEADER_INTERFACE_ID;
      R_SO_INFT_LINE.CREATED_BY                := R_SO_INFT_HEADER.CREATED_BY;
      R_SO_INFT_LINE.CREATION_DATE             := R_SO_INFT_HEADER.CREATION_DATE;
      R_SO_INFT_LINE.LAST_UPDATED_BY           := R_SO_INFT_LINE.CREATED_BY;
      R_SO_INFT_LINE.LAST_UPDATE_DATE          := R_SO_INFT_LINE.CREATION_DATE;
      R_SO_INFT_LINE.ITEM_ID     := R_BD_ITEM.ITEM_ID;
      R_SO_INFT_LINE.ITEM_CODE   := R_BD_ITEM.ITEM_CODE;
      R_SO_INFT_LINE.ITEM_NAME   := R_BD_ITEM.ITEM_NAME;
      R_SO_INFT_LINE.ITEM_UOM    := R_BD_ITEM.DEFAULTUNIT;
      R_SO_INFT_LINE.ITEM_QTY    := REC.DIFF_COMPONENT_QTY;
      
      --设置产品价格
      P_SO_SET_ITEM_PRICE(R_SO_INFT_HEADER,  --销售单据接口头记录
                          R_SO_INFT_LINE,    --销售单据接口行记录
                          P_RESULT,          --返回错误ID
                          P_ERR_MSG          --返回错误信息
                          );
      --根据P_RESULT判断是否抛出异常
      PKG_SO_PUB.P_EXCEPTION_THROWS(P_RESULT);
      
      --生成销售单据接口行记录
      PKG_SO_BIZ.P_SO_CREATE_INTF_LINE(R_SO_INFT_LINE,
                                       R_SO_INFT_LINE.CREATED_BY,
                                       P_RESULT,
                                       P_ERR_MSG);
      PKG_SO_PUB.P_EXCEPTION_THROWS(P_RESULT);

    END LOOP;

    --开销售单
    PKG_SO_BIZ.P_SO_GENERATE(R_SO_INFT_HEADER.SO_HEADER_INTERFACE_ID,R_SO_INFT_HEADER.CREATED_BY,P_RESULT,P_ERR_MSG);
    PKG_SO_PUB.P_EXCEPTION_THROWS(P_RESULT);

    --记录退货申请对应的收货通知单号
    UPDATE CIMS.T_SO_HEADER SH
       SET SH.SHIP_DOC_CODE = P_RECEIVE_DOC_CODE,
           SH.LAST_UPDATE_DATE = SYSDATE
     WHERE SH.BIZ_SRC_BILL_TYPE_CODE = PKG_SO_PUB.V_BIZ_SRC_BILL_SO
       AND EXISTS
     (SELECT 1
              FROM T_SO_HEADER_RELATION  R,
                   T_SO_HEADER_INTERFACE SHI
             WHERE R.SO_HEADER_ID = SH.SO_HEADER_ID
               AND R.SO_HEADER_INTF_ID = SHI.SO_HEADER_INTERFACE_ID
               AND SHI.SO_HEADER_INTERFACE_ID = R_SO_INFT_HEADER.SO_HEADER_INTERFACE_ID);
     
  EXCEPTION
    WHEN PKG_SO_PUB.V_BIZ_EXCEPTION THEN
      P_RESULT  := -28000;
      P_ERR_MSG := '退货申请签收差异给承运商开全陪单失败！' || P_ERR_MSG;
    WHEN OTHERS THEN
      P_RESULT  := -27001;
      P_ERR_MSG := '退货申请[' || P_BILL_NUM || ']签收差异给承运商开全陪单发生异常！' || SQLERRM;
  END;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2019-01-24
  *     创建者：周建刚
  *   功能说明：设置产品价格
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_SET_ITEM_PRICE(R_SO_INFT_HEADER  IN OUT T_SO_HEADER_INTERFACE%ROWTYPE, --销售单据接口头记录
                                R_SO_INFT_LINE    IN OUT T_SO_LINE_INTERFACE%ROWTYPE,   --销售单据接口行记录
                                P_RESULT          OUT NUMBER, --返回错误ID
                                P_ERR_MSG         OUT VARCHAR2 --返回错误信息
                                ) IS 
    --是否促销机(临时变量)
    TMP_CX_FLAG             VARCHAR2(10);
    V_ITEM_PRICE            NUMBER;
    V_DISCOUNT_RATE         NUMBER;
    V_MONTH_DISCOUNT_RATE   NUMBER;
  BEGIN
    P_RESULT  := V_RESULT;
    P_ERR_MSG := V_SUCCESS;
    
    PKG_BD_PRICE.P_GET_PRICE(R_SO_INFT_HEADER.ACCOUNT_ID,
                             R_SO_INFT_LINE.ITEM_CODE,
                             TO_CHAR(R_SO_INFT_HEADER.SO_DATE,'YYYYMMDD'),
                             NULL,
                             R_SO_INFT_LINE.ENTITY_ID,
                             V_ITEM_PRICE,
                             V_DISCOUNT_RATE,
                             V_MONTH_DISCOUNT_RATE,
                             TMP_CX_FLAG);
                                 
    R_SO_INFT_LINE.ITEM_PRICE            := V_ITEM_PRICE;
    R_SO_INFT_LINE.DISCOUNT_RATE         := NVL(V_DISCOUNT_RATE,0);
    R_SO_INFT_LINE.MONTH_DISCOUNT_RATE   := NVL(V_MONTH_DISCOUNT_RATE,0);
        
    IF R_SO_INFT_LINE.ITEM_PRICE IS NULL THEN
      P_ERR_MSG := '客户[' || R_SO_INFT_HEADER.CUSTOMER_CODE || ',' || R_SO_INFT_HEADER.CUSTOMER_NAME || '],账户[' || R_SO_INFT_HEADER.ACCOUNT_CODE || '],产品[' || R_SO_INFT_LINE.ITEM_CODE ||
                   ']价格为空！';
      RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
    END IF;
        
    --产品结算价格=产品价格*(100 - 折扣率 - 月返率)/100
    R_SO_INFT_LINE.ITEM_SETTLE_PRICE := ROUND((R_SO_INFT_LINE.ITEM_PRICE * (100 - R_SO_INFT_LINE.DISCOUNT_RATE -
                           R_SO_INFT_LINE.MONTH_DISCOUNT_RATE) / 100),PKG_SO_PUB.V_DEFAULT_PRECISE_SCALE);
      
  EXCEPTION
    WHEN PKG_SO_PUB.V_BIZ_EXCEPTION THEN
      P_RESULT  := -28000;
      P_ERR_MSG := '获取产品[' || R_SO_INFT_LINE.ITEM_CODE || ',' || R_SO_INFT_LINE.ITEM_NAME || ']价格出现异常！' || P_ERR_MSG;
    WHEN OTHERS THEN
      P_RESULT  := -28000;
      P_ERR_MSG := '调用PKG_BD_PRICE.P_GET_PRICE过程(入参-账户ID[' ||
                   R_SO_INFT_HEADER.ACCOUNT_ID || '],产品[' || R_SO_INFT_LINE.ITEM_CODE ||
                   '],单据日期[' ||
                   TO_CHAR(R_SO_INFT_HEADER.SO_DATE, 'YYYYMMDD') ||
                   '],主体ID[' || R_SO_INFT_LINE.ENTITY_ID || '])获取产品的价格出错：' ||
                   SQLERRM;
  END;

  -------------------------------------------------------------------------------  
END PKG_SO_INTF;
/

