create Package Body PKG_SL_IO_A3 Is

-----------------------------------------------------------------------------
  --  同步A3仓库实体仓信息                                                   --
  -----------------------------------------------------------------------------
  PROCEDURE P_SL_INVENTORY(
    IN_ENTITY_ID   IN  NUMBER,  --主体ID
    OS_MESSAGE   OUT VARCHAR2   --成功则返回“OK”，否则返回出错信息
  ) IS
   S_USER_ID VARCHAR2(100);
  
  BEGIN
    OS_MESSAGE := 'OK';
    S_USER_ID := PKG_BD.F_GET_PARAMETER_VALUE('SL_AUTO_USER',IN_ENTITY_ID);
    MERGE INTO T_SL_INVENTORY O
    USING(SELECT  SITE_CODE,
                     SITE_NAME,
                     STORAGE_NUM,
                     STORAGE_NAME,
                     STIRGE_ADDR,
                     LINKMAN,
                     CONTACT_PHONE
             FROM  A3_C_IMS_WAREHOUSE
             GROUP BY SITE_CODE,
                      SITE_NAME,
                      STORAGE_NUM,
                      STORAGE_NAME,
                      STIRGE_ADDR,
                      LINKMAN,
                      CONTACT_PHONE
      ) B
      ON (B.STORAGE_NUM = O.SOURCE_INV_CODE)
      WHEN MATCHED THEN
               UPDATE SET O.FACT_INV_CODE = B.STORAGE_NUM,
                          O.DESCRIPTION = B.STORAGE_NAME,
                          O.SITE_CODE = B.SITE_CODE,
                          O.SITE_NAME = B.SITE_NAME,
                          O.ADDRIESS = B.STIRGE_ADDR,
                          O.CONTACTS_NAME = B.LINKMAN,
                          O.CONTACTS_PHONES = B.CONTACT_PHONE,
                          O.LAST_UPDATED_BY= S_USER_ID,
                          O.LAST_UPDATE_DATE= SYSDATE
      WHEN NOT MATCHED THEN
               INSERT (FACT_INV_ID,FACT_INV_CODE,DESCRIPTION,ADDRIESS,
                       SITE_CODE,SITE_NAME,SOURCE_SYSTEM,SOURCE_INV_CODE,BEGIN_DATE,
                       CREATED_BY,CREATION_DATE,LAST_UPDATED_BY,LAST_UPDATE_DATE,CONTACTS_NAME,CONTACTS_PHONES)
               VALUES (S_SL_INVENTORY.NEXTVAL,B.STORAGE_NUM,B.STORAGE_NAME,B.STIRGE_ADDR,
                       B.SITE_CODE,B.SITE_NAME,'A3',B.STORAGE_NUM,SYSDATE,
                       S_USER_ID,SYSDATE,S_USER_ID,SYSDATE,B.LINKMAN,B.CONTACT_PHONE);
        --- 更新重复编码
        UPDATE T_SL_INVENTORY SET FACT_INV_CODE = 'A3'||FACT_INV_CODE
        WHERE FACT_INV_CODE IN
        (SELECT FACT_INV_CODE FROM T_SL_INVENTORY
            GROUP BY FACT_INV_CODE HAVING COUNT(1)>1)
        AND SOURCE_SYSTEM='A3' AND FACT_INV_CODE NOT LIKE 'A3%';
      --提交
      COMMIT;
  EXCEPTION
     WHEN NO_DATA_FOUND THEN
       NULL;
     WHEN OTHERS THEN
       OS_MESSAGE := SUBSTR(SQLERRM(SQLCODE), 1, 256);
       ROLLBACK;
  END P_SL_INVENTORY;

END PKG_SL_IO_A3;
/

