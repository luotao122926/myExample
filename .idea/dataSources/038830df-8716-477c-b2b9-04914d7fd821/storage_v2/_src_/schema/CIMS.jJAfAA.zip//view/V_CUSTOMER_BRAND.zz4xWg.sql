create view V_CUSTOMER_BRAND as
select BRAND_ID,
       ENTITY_ID,
       CUSTOMER_ID,
       CUSTOMER_CODE,
       DEPT_ID,
       DEPT_CODE,
       BRAND_CODE,
       CUSTOMER_LEVEL,
       CUSTOMER_CREDIT_LEVEL,
       CREDIT_LINE,
       COOPERATION_MODEL,
       ACTIVE_FLAG,
       CREATED_BY,
       CREATION_DATE,
       LAST_UPDATE_DATE,
       LAST_UPDATE_BY,
       LAST_INTERFACE_DATE,
       SIEBEL_BRAND_ID,
       SIEBEL_CUSTOMER_ID,
       PRE_FIELD_01,
       PRE_FIELD_02,
       PRE_FIELD_03,
       PRE_FIELD_04,
       PRE_FIELD_05,
       PRE_FIELD_06
  from T_CUSTOMER_BRAND with read only
/

comment on column V_CUSTOMER_BRAND.BRAND_ID is '品牌ID'
/

comment on column V_CUSTOMER_BRAND.ENTITY_ID is '主体ID'
/

comment on column V_CUSTOMER_BRAND.CUSTOMER_ID is '客户ID'
/

comment on column V_CUSTOMER_BRAND.CUSTOMER_CODE is '客户编码'
/

comment on column V_CUSTOMER_BRAND.DEPT_ID is '事业部ID'
/

comment on column V_CUSTOMER_BRAND.DEPT_CODE is '事业部编码'
/

comment on column V_CUSTOMER_BRAND.BRAND_CODE is '经营品牌'
/

comment on column V_CUSTOMER_BRAND.CUSTOMER_LEVEL is '客户等级'
/

comment on column V_CUSTOMER_BRAND.CUSTOMER_CREDIT_LEVEL is '客户信用等级'
/

comment on column V_CUSTOMER_BRAND.CREDIT_LINE is '信用额度'
/

comment on column V_CUSTOMER_BRAND.COOPERATION_MODEL is '合作类型(代理商/直营商/直销商/OEM商/销售公司)'
/

comment on column V_CUSTOMER_BRAND.ACTIVE_FLAG is '是否有效(Y/N)'
/

comment on column V_CUSTOMER_BRAND.CREATED_BY is '创建人'
/

comment on column V_CUSTOMER_BRAND.CREATION_DATE is '创建日期'
/

comment on column V_CUSTOMER_BRAND.LAST_UPDATE_DATE is '最后修改时间'
/

comment on column V_CUSTOMER_BRAND.LAST_UPDATE_BY is '最后修改人'
/

comment on column V_CUSTOMER_BRAND.LAST_INTERFACE_DATE is '最后同步时间'
/

comment on column V_CUSTOMER_BRAND.SIEBEL_BRAND_ID is '主数据客户经营品牌ID'
/

comment on column V_CUSTOMER_BRAND.SIEBEL_CUSTOMER_ID is '主数据客户ID'
/

comment on column V_CUSTOMER_BRAND.PRE_FIELD_01 is '预留字段1'
/

comment on column V_CUSTOMER_BRAND.PRE_FIELD_02 is '预留字段2'
/

comment on column V_CUSTOMER_BRAND.PRE_FIELD_03 is '预留字段3'
/

comment on column V_CUSTOMER_BRAND.PRE_FIELD_04 is '预留字段4'
/

comment on column V_CUSTOMER_BRAND.PRE_FIELD_05 is '预留字段5'
/

comment on column V_CUSTOMER_BRAND.PRE_FIELD_06 is '预留字段6'
/

