create package body      PKG_CREDIT_TOOLS is

  LG_LINE_STATE_NORMAL CONSTANT VARCHAR2(10) := 'NORMAL';
  LG_LINE_STATE_CLOSED CONSTANT VARCHAR2(10) := 'CLOSED';
  --------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-30
  *     创建者：苏冬渊
  *   功能说明：字符串分割，输出LIST，下标从1开始
  *   返回结果：1：成功，2：失败
  *
  */
  -------------------------------------------------------------------------------
  /*FUNCTION FUN_SPLIT(P_STRING IN VARCHAR2, P_FLAG IN VARCHAR2) RETURN STR_LIST IS
    J         INT := 0;
    I         INT := 1;
    LEN       INT := 0;
    LEN1      INT := 0;
    STR       VARCHAR2(4000);
    S_LIST    STR_LIST;
  BEGIN
    LEN  := LENGTH(P_STRING);
    LEN1 := LENGTH(P_FLAG);

    WHILE J < LEN LOOP
      J := INSTR(P_STRING, P_FLAG, I);

      IF J = 0 THEN
        J   := LEN;
        STR := SUBSTR(P_STRING, I);
        --S_LIST.EXTEND;
        S_LIST(S_LIST.COUNT) := STR;

        IF I >= LEN THEN
          EXIT;
        END IF;
      ELSE
        STR := SUBSTR(P_STRING, I, J - I);
        I   := J + LEN1;
        --S_LIST.EXTEND;
        S_LIST(S_LIST.COUNT) := STR;
      END IF;
    END LOOP;

    RETURN S_LIST;
  END; */

  FUNCTION FUN_SPLIT(P_STR IN VARCHAR2, P_DELIMITER IN VARCHAR2) RETURN STR_LIST IS
    J         INT := 0;
    I         INT := 1;
    LEN       INT := 0;
    LEN1      INT := 0;
    STR       VARCHAR2(4000);
    STR_SPLIT STR_LIST := STR_LIST();
  BEGIN
    LEN  := LENGTH(P_STR);
    LEN1 := LENGTH(P_DELIMITER);

    WHILE J < LEN LOOP
      J := INSTR(P_STR, P_DELIMITER, I);

      IF J = 0 THEN
        J   := LEN;
        STR := SUBSTR(P_STR, I);
        STR_SPLIT.EXTEND;
        STR_SPLIT(STR_SPLIT.COUNT) := STR;

        IF I >= LEN THEN
          EXIT;
        END IF;
      ELSE
        STR := SUBSTR(P_STR, I, J - I);
        I   := J + LEN1;
        STR_SPLIT.EXTEND;
        STR_SPLIT(STR_SPLIT.COUNT) := STR;
      END IF;
    END LOOP;

    RETURN STR_SPLIT;
  END FUN_SPLIT;
  --------------------------------------------------------------------------------
  /*
  *   创建日期：2014-08-25
  *     创建者：苏冬渊
  *   功能说明：根据客户ID，营销大类编码，获取所对应的额度组
  * CREDIT_USE_DEFAULT_GROUP:
  * A 按之前额度组关系获取额度组 如果是销司 配置成A 只会默认额度组
  * Y 只会获取到默认额度组
  * N 只会获取到非默认额度组
  *   返回结果：额度组ID
  *
  */
  -------------------------------------------------------------------------------
  FUNCTION FUN_GET_CREDITGROUPID(P_ENTITY_ID       Number,
                                 P_CUSTOMER_ID     NUMBER,
                                 P_SALES_MAIN_TYPE varchar2,
                                 IN_ACCOUNT_ID     NUMBER DEFAULT NULL --2017-4-20 增加账户ID参数，默认为空
                                 ) RETURN NUMBER IS
    V_CREDIT_GROUP_ID NUMBER := 0;
    V_COUNT           NUMBER := 0;
    VS_PARAM_VALUE    VARCHAR2(50); --CREDIT_USE_DEFAULT_GROUP 系统参数值
  BEGIN
    IF 0 < IN_ACCOUNT_ID THEN
      SELECT F_GET_PARAM_VALUE_ENTITY_PRIOR('CREDIT_USE_DEFAULT_GROUP',
                                          P_ENTITY_ID,
                                          CO.SALES_CENTER_ID,
                                          A.CUSTOMER_ID)
        INTO VS_PARAM_VALUE
        FROM T_CUSTOMER_ACCOUNT A
       INNER JOIN T_CUSTOMER_ACC_ORG_RELATION AR
          ON (AR.ACCOUNT_ID = A.ACCOUNT_ID)
       INNER JOIN T_CUSTOMER_ORG CO
          ON (CO.CUSTOMER_ORG_ID = AR.CUSTOMER_ORG_ID)
       WHERE A.ACCOUNT_ID = IN_ACCOUNT_ID
         AND A.ENTITY_ID = P_ENTITY_ID;
    
    END IF;
    IF VS_PARAM_VALUE IS NULL OR 'NULL' = UPPER(VS_PARAM_VALUE) OR 'A' = VS_PARAM_VALUE THEN
      --如果参数值为空 或者 等于 A，按之前方式取额度组
      
   --1、根据营销大类ID，客户ID，获取额度组。检查是否是特殊额度组。
    BEGIN
      SELECT nvl(C.CREDIT_GROUP_ID, -1)
        INTO V_CREDIT_GROUP_ID
        FROM T_CREDIT_GROUP_CUST         A,
             T_CREDIT_CATEGORY_GROUP_REL B,
             T_CREDIT_GROUP              C
       WHERE B.CREDIT_GROUP_ID = A.CREDIT_GROUP_ID
         AND B.CREDIT_GROUP_ID = C.CREDIT_GROUP_ID
         AND A.CUSTOMER_ID = P_CUSTOMER_ID
         AND B.SALES_MAIN_TYPE = P_SALES_MAIN_TYPE
         And C.ENTITY_ID = P_ENTITY_ID ;
    EXCEPTION WHEN NO_DATA_FOUND THEN
       --该客户该大类没有存在特殊额度组中，检查该客户是否有其他大类存在特殊额度组
       SELECT COUNT(1)
         INTO V_COUNT
         FROM T_CREDIT_GROUP_CUST         A,
              T_CREDIT_CATEGORY_GROUP_REL B,
              T_CREDIT_GROUP              C
        WHERE B.CREDIT_GROUP_ID = A.CREDIT_GROUP_ID
          AND B.CREDIT_GROUP_ID = C.CREDIT_GROUP_ID
          AND A.CUSTOMER_ID = P_CUSTOMER_ID
          And C.ENTITY_ID = P_ENTITY_ID ;
          --V_COUNT>0,该客户有其他大类存在特殊额度组
          IF V_COUNT > 0 THEN
            V_CREDIT_GROUP_ID := -2 ;
          END IF ;
    WHEN OTHERS THEN
       V_CREDIT_GROUP_ID := -1 ;
    END ;
    --2、该客户不存在任何营销大类在特殊额度组中，所以查询普通额度组。
    IF V_CREDIT_GROUP_ID = 0 THEN
        BEGIN
           SELECT nvl(B.CREDIT_GROUP_ID, -1)
             INTO V_CREDIT_GROUP_ID
             FROM T_CREDIT_CATEGORY_GROUP_REL A, T_CREDIT_GROUP B
            WHERE A.CREDIT_GROUP_ID = B.CREDIT_GROUP_ID
              AND A.SALES_MAIN_TYPE = P_SALES_MAIN_TYPE
              And B.ENTITY_ID = P_ENTITY_ID
              AND (B.DEFAULT_FLAG IS NULL OR B.DEFAULT_FLAG = '1');
        EXCEPTION WHEN OTHERS THEN
          V_CREDIT_GROUP_ID := -1 ;
        END;
     END IF ;
    --2017-4-20 根据系统参数CREDIT_USE_DEFAULT_GROUP 获取额度组
    ELSIF 'Y' = VS_PARAM_VALUE THEN
      --参数值等于Y 取默认额度组
      BEGIN
           SELECT nvl(B.CREDIT_GROUP_ID, -1)
             INTO V_CREDIT_GROUP_ID
             FROM T_CREDIT_CATEGORY_GROUP_REL A, T_CREDIT_GROUP B
            WHERE A.CREDIT_GROUP_ID = B.CREDIT_GROUP_ID
              AND A.SALES_MAIN_TYPE = P_SALES_MAIN_TYPE
              And B.ENTITY_ID = P_ENTITY_ID
              AND (B.DEFAULT_FLAG IS NULL OR B.DEFAULT_FLAG = '1');
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
                BEGIN
                   SELECT nvl(B.CREDIT_GROUP_ID, -1)
                     INTO V_CREDIT_GROUP_ID
                     FROM T_CREDIT_CATEGORY_GROUP_REL A, T_CREDIT_GROUP B
                    WHERE A.CREDIT_GROUP_ID = B.CREDIT_GROUP_ID
                      AND A.SALES_MAIN_TYPE = P_SALES_MAIN_TYPE
                      And B.ENTITY_ID = P_ENTITY_ID
                      AND B.DEFAULT_FLAG = '2';
               EXCEPTION WHEN OTHERS THEN
                  V_CREDIT_GROUP_ID := -1 ;
               END;
          WHEN OTHERS THEN
             V_CREDIT_GROUP_ID := -1 ;
        END;
    ELSIF 'N' = VS_PARAM_VALUE THEN
      --参数值等于N 取非默认额度组
      BEGIN
           SELECT nvl(B.CREDIT_GROUP_ID, -1)
             INTO V_CREDIT_GROUP_ID
             FROM T_CREDIT_CATEGORY_GROUP_REL A, T_CREDIT_GROUP B
            WHERE A.CREDIT_GROUP_ID = B.CREDIT_GROUP_ID
              AND A.SALES_MAIN_TYPE = P_SALES_MAIN_TYPE
              And B.ENTITY_ID = P_ENTITY_ID
              AND B.DEFAULT_FLAG = '2';
        EXCEPTION WHEN OTHERS THEN
          V_CREDIT_GROUP_ID := -1 ;
        END;
    END IF;
    RETURN V_CREDIT_GROUP_ID ;
  END;
  --------------------------------------------------------------------------------
  /*
  *   创建日期：2014-08-25
  *     创建者：苏冬渊
  *   功能说明：获取客户可用到款金额，可用扣率折让总金额
      参数说明：P_FLAG：1-获取 可提货金额 2-获取 可用扣率折让金额
  *   返回结果：可提货金额  可用扣率折让金额
  *   公式：
        到款余额 = 到款金额 - 销售金额
        可用到款余额 = 到款金额 - 销售金额 + 铺底额度 + 临时额度  - 锁定到款金额
        扣率折让余额 = 扣率折让金额 - 核销扣率折让金额
        可用扣率折让余额 = 扣率折让金额 - 核销扣率折让金额 + 冻结扣率折让金额 - 锁定扣率折让金额
        可提货金额 = 到款余额 + 铺底额度 + 临时额度  - 锁定到款金额 + 扣率折让余额 + 冻结扣率折让金额 - 锁定扣率折让金额
  */
  -------------------------------------------------------------------------------
    FUNCTION FUN_GET_AMOUNT(P_ENTITY_ID   NUMBER,
                          P_CUSTOMER_ID NUMBER,
                          P_ACCOUNT_ID  NUMBER,
                          P_SALES_MAIN_TYPE VARCHAR2,
                          P_FLAG    NUMBER, --1 可用提货余额；2 可用折让余额；3 可提货额度；4 到款余额
                          IS_DISCOUNT_TYPE     VARCHAR2 DEFAULT 'ALL'--ALL代表常规、折让合并 空或COMMON代表常规 其他代表折让到款
                          ) RETURN NUMBER IS
   V_AMOUNT_SUM NUMBER := 0;
   V_GREDIT_GROUP_ID NUMBER ;
   CUR_SALES_ACCOUNT_AMOUNT T_SALES_ACCOUNT_AMOUNT%ROWTYPE ;
    --20160913 hejy3 可提货额度获取
    V_ORDER_LIMIT_AMOUNT NUMBER;
    V_ORDER_USED_AMOUNT NUMBER;
    
    VN_SALES_AMOUNT     NUMBER;--add by liangym2 20170816 销售金额
    VN_LOCK_RECEIVED_AMOUNT NUMBER;--add by liangym2 20170816 锁款金额
    
    VN_DIS_RECEIPT_AMOUNT   NUMBER;--add by liangym2 20170816 折让上账金额
    VN_DIS_SALES_AMOUNT     NUMBER;--add by liangym2 20170816 折让销售金额
    VN_DIS_LOCK_AMOUNT      NUMBER;--add by liangym2 20170816 折让锁款金额
    VN_DIS_RECEIVED_AMOUNT  NUMBER;--add by liangym2 20171030 折让到款金额
    
    VN_RECEIVED_AMOUNT NUMBER;--add by liangym2 20171030 到款金额
    
    V_SALES_MAIN_TYPE VARCHAR2(32);
  BEGIN
    V_SALES_MAIN_TYPE := P_SALES_MAIN_TYPE;
    IF V_SALES_MAIN_TYPE IS NULL THEN
     V_SALES_MAIN_TYPE := PKG_BD.F_GET_PARAMETER_VALUE('ar_default_sale_main_write_off', P_ENTITY_ID);
    END IF;
  
    IF P_FLAG = 3 THEN --20160913 hejy3 可提货额度获取
      BEGIN
        SELECT L.ORDER_LIMIT_AMOUNT, NVL(L.ORDER_USED_AMOUNT, 0)
          INTO V_ORDER_LIMIT_AMOUNT, V_ORDER_USED_AMOUNT
          FROM T_CREDIT_ACCOUNT_LIMIT L
         WHERE L.ENTITY_ID = P_ENTITY_ID
           AND L.CUSTOMER_ID = P_CUSTOMER_ID
           AND L.ACCOUNT_ID = P_ACCOUNT_ID;
      EXCEPTION
        WHEN OTHERS THEN
          V_ORDER_LIMIT_AMOUNT := NULL;
      END;
      
      IF V_ORDER_LIMIT_AMOUNT IS NULL THEN
        V_AMOUNT_SUM := NULL; --返回空值
      ELSE
        V_AMOUNT_SUM := V_ORDER_LIMIT_AMOUNT - V_ORDER_USED_AMOUNT;
      END IF;
    ELSE
      --2017-4-22 获取额度组增加账户ID liangym2
      V_GREDIT_GROUP_ID := FUN_GET_CREDITGROUPID(P_ENTITY_ID,P_CUSTOMER_ID,V_SALES_MAIN_TYPE,P_ACCOUNT_ID);
      IF IS_DISCOUNT_TYPE IS NULL OR IS_DISCOUNT_TYPE IN ('COMMON','ALL') THEN
      BEGIN
      SELECT T.*
        INTO CUR_SALES_ACCOUNT_AMOUNT
        FROM T_SALES_ACCOUNT_AMOUNT T
       WHERE T.ENTITY_ID = P_ENTITY_ID
         AND T.CUSTOMER_ID = P_CUSTOMER_ID
         AND T.ACCOUNT_ID = P_ACCOUNT_ID
         AND T.CREDIT_GROUP_ID = V_GREDIT_GROUP_ID;
      EXCEPTION WHEN OTHERS THEN
        V_AMOUNT_SUM := 0 ;
        RETURN V_AMOUNT_SUM;
      END ;
      END IF;
      IF IS_DISCOUNT_TYPE IS NULL OR IS_DISCOUNT_TYPE <> 'ALL' THEN
        BEGIN
          SELECT SUM(NVL(T.RECEIPT_AMOUNT,0)),SUM(NVL(T.SALES_AMOUNT,0)),SUM(NVL(T.LOCK_AMOUNT,0)),SUM(NVL(T.RECEIVED_AMOUNT,0))
           INTO VN_DIS_RECEIPT_AMOUNT,VN_DIS_SALES_AMOUNT,VN_DIS_LOCK_AMOUNT,VN_DIS_RECEIVED_AMOUNT
          FROM T_CREDIT_DISCOUNT_AMOUNT T WHERE
          T.ENTITY_ID = P_ENTITY_ID
          AND T.CUSTOMER_ID = P_CUSTOMER_ID
          AND T.ACCOUNT_ID = P_ACCOUNT_ID
          AND (IS_DISCOUNT_TYPE IS NULL OR IS_DISCOUNT_TYPE = 'COMMON' OR IS_DISCOUNT_TYPE = T.DISCOUNT_TYPE)
          AND V_GREDIT_GROUP_ID = PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(P_ENTITY_ID,T.CUSTOMER_ID,T.SALES_MAIN_TYPE,T.ACCOUNT_ID);
        EXCEPTION WHEN OTHERS THEN
          VN_DIS_RECEIPT_AMOUNT := 0 ;
          VN_DIS_SALES_AMOUNT := 0 ;
          VN_DIS_LOCK_AMOUNT  := 0;
          VN_DIS_RECEIVED_AMOUNT := 0;
        END ;
      END IF;
      
      VN_DIS_RECEIPT_AMOUNT := NVL(VN_DIS_RECEIPT_AMOUNT,0);
      VN_DIS_SALES_AMOUNT := NVL(VN_DIS_SALES_AMOUNT,0);
      VN_DIS_LOCK_AMOUNT := NVL(VN_DIS_LOCK_AMOUNT,0);
      VN_DIS_RECEIVED_AMOUNT := NVL(VN_DIS_RECEIVED_AMOUNT,0);

      IF P_FLAG = 1 THEN --获取可用到款金额
        IF IS_DISCOUNT_TYPE NOT IN ('COMMON','ALL') THEN
          V_AMOUNT_SUM := ( NVL(VN_DIS_RECEIPT_AMOUNT,0) + NVL(VN_DIS_RECEIVED_AMOUNT,0)
          - NVL(VN_DIS_SALES_AMOUNT,0)
          - NVL(VN_DIS_LOCK_AMOUNT,0) );
        ELSE
          VN_SALES_AMOUNT := CUR_SALES_ACCOUNT_AMOUNT.SALES_AMOUNT;
          VN_RECEIVED_AMOUNT := CUR_SALES_ACCOUNT_AMOUNT.Received_Amount;
          VN_LOCK_RECEIVED_AMOUNT := CUR_SALES_ACCOUNT_AMOUNT.LOCK_RECEIVED_AMOUNT;
          IF IS_DISCOUNT_TYPE IS NULL OR IS_DISCOUNT_TYPE = 'COMMON' THEN
            VN_SALES_AMOUNT := (VN_SALES_AMOUNT + VN_DIS_RECEIPT_AMOUNT - VN_DIS_SALES_AMOUNT);
            VN_LOCK_RECEIVED_AMOUNT := (VN_LOCK_RECEIVED_AMOUNT - VN_DIS_LOCK_AMOUNT);
            VN_RECEIVED_AMOUNT := (VN_RECEIVED_AMOUNT - VN_DIS_RECEIVED_AMOUNT);
          END IF;
        V_AMOUNT_SUM := VN_RECEIVED_AMOUNT
                      - VN_SALES_AMOUNT
                      - VN_LOCK_RECEIVED_AMOUNT
                      + CUR_SALES_ACCOUNT_AMOUNT.DELAYPAY_AMOUNT
                      + CUR_SALES_ACCOUNT_AMOUNT.TEMP_DELAYPAY_AMOUNT
                      --ADD BY LIANGYM2 可用到款金额 加上美的付内容
                      + CUR_SALES_ACCOUNT_AMOUNT.MPAY_STREAM_AMOUNT
                      - CUR_SALES_ACCOUNT_AMOUNT.MPAY_CASH_AMOUNT/*
                      + CUR_SALES_ACCOUNT_AMOUNT.DISCOUNT_AMOUNT
                      - CUR_SALES_ACCOUNT_AMOUNT.Applied_Discount_Amount
                      + CUR_SALES_ACCOUNT_AMOUNT.Freeze_Discount_Amount
                      - CUR_SALES_ACCOUNT_AMOUNT.Lock_Discount_Amount */;
        END IF;
      ELSIF P_FLAG = 2 THEN --获取可用扣率折让金额
        IF IS_DISCOUNT_TYPE IS NULL OR IS_DISCOUNT_TYPE IN ('COMMON','ALL') THEN
          V_AMOUNT_SUM := CUR_SALES_ACCOUNT_AMOUNT.DISCOUNT_AMOUNT
                     - CUR_SALES_ACCOUNT_AMOUNT.APPLIED_DISCOUNT_AMOUNT
                     - CUR_SALES_ACCOUNT_AMOUNT.LOCK_DISCOUNT_AMOUNT
                     + CUR_SALES_ACCOUNT_AMOUNT.FREEZE_DISCOUNT_AMOUNT ;
        ELSE V_AMOUNT_SUM := 0 ;
        END IF;
      ELSIF P_FLAG = 4 THEN --获取到款余额
        IF IS_DISCOUNT_TYPE NOT IN ('COMMON','ALL') THEN
          V_AMOUNT_SUM := ( NVL(VN_DIS_RECEIPT_AMOUNT,0) + NVL(VN_DIS_RECEIVED_AMOUNT,0)
          - NVL(VN_DIS_SALES_AMOUNT,0));
        ELSE
          VN_SALES_AMOUNT := CUR_SALES_ACCOUNT_AMOUNT.SALES_AMOUNT;
          VN_RECEIVED_AMOUNT := CUR_SALES_ACCOUNT_AMOUNT.Received_Amount;
          IF IS_DISCOUNT_TYPE IS NULL OR IS_DISCOUNT_TYPE = 'COMMON' THEN
            VN_SALES_AMOUNT := (VN_SALES_AMOUNT + VN_DIS_RECEIPT_AMOUNT - VN_DIS_SALES_AMOUNT);
            VN_RECEIVED_AMOUNT := (VN_RECEIVED_AMOUNT - VN_DIS_RECEIVED_AMOUNT);
          END IF;
          V_AMOUNT_SUM := VN_RECEIVED_AMOUNT - VN_SALES_AMOUNT;
        END IF;
      ELSE
        V_AMOUNT_SUM := 0 ;
      END IF ;
    END IF;
    RETURN V_AMOUNT_SUM;
  END;

  --------------------------------------------------------------------------------
  /*
  *   创建日期：2014-08-28
  *     创建者：苏冬渊
  *   功能说明：获取二级代码的值或者名称
      参数说明：P_FLAG：1-获取 code_value 2-获取 code_name
  *   返回结果：code_value code_name
  *
  */
  -------------------------------------------------------------------------------
  FUNCTION FUN_GET_CODELIST(P_CODE_ID   VARCHAR2,
                            P_CODE_TYPE VARCHAR2,
                            P_FLAG      NUMBER
                            ) RETURN VARCHAR2 IS
   V_RESULT VARCHAR2(200) := '0';
  BEGIN
    IF P_FLAG = 1 THEN
      BEGIN
      SELECT T.CODE_VALUE INTO V_RESULT FROM UP_CODELIST T WHERE
      T.CODE_VALUE = P_CODE_ID AND T.CODETYPE = P_CODE_TYPE AND ROWNUM =1 ;
      EXCEPTION WHEN OTHERS THEN
        V_RESULT := '-1' ;
      END ;
    ELSIF P_FLAG = 2 THEN
      BEGIN
      SELECT T.Code_Name INTO V_RESULT FROM UP_CODELIST T WHERE
      T.CODE_VALUE = P_CODE_ID AND T.CODETYPE = P_CODE_TYPE AND ROWNUM =1 ;
      EXCEPTION WHEN OTHERS THEN
        V_RESULT := '-1' ;
      END ;
    ELSE
      V_RESULT := '-1' ;
    END IF ;
    RETURN V_RESULT;
  END;

  --------------------------------------------------------------------------------
  /*
  *   创建日期：2014-10-27
  *     创建者：苏冬渊
  *   功能说明：获取客户前12个月的销售总额
                单个客户：获取该客户下所经营所有品类的销售总额
                客户组：获取客户组下所有客户所有品类的销售总额
      参数说明：
  *   返回结果：
  *
  */
  -------------------------------------------------------------------------------
  FUNCTION FUN_GET_SALES_AMOUNT(P_ENTITY_ID NUMBER,
                                P_CUSTOMER_ID NUMBER,
                                P_SALES_MAIN_TYPE VARCHAR2,
                                IN_ACCOUNT_ID     NUMBER DEFAULT NULL --2017-5-5 增加账户ID参数，默认为空
                                ) RETURN NUMBER IS
   V_RESULT NUMBER := 0 ;
   --V_CUST_GROUP_ID t_credit_cust_group_rel.cust_group_id%type := 0 ;
   V_settle_amount     v_credit_contact_amount_so.settle_amount%TYPE := 0 ;
   V_settle_amount_old v_credit_contact_amount_so.settle_amount%TYPE := 0 ;
   entityGroupCode Varchar2(100) ;
  Begin
    --获取主体组编码
     entityGroupCode := pkg_bd.F_GET_PARAMETER_VALUE('ar_entity_group',P_ENTITY_ID,null,null);
     --销售公司模式，取结算日期
     If entityGroupCode = 'XSGS' Then

        BEGIN
          SELECT nvl(SUM(T.settle_amount), 0)
            INTO V_settle_amount
            FROM v_credit_contact_amount_so T,v_so_bill_type v
           WHERE T.customer_id = P_CUSTOMER_ID
             AND T.entity_id = P_ENTITY_ID
             AND T.sales_main_type = P_SALES_MAIN_TYPE
             AND T.settle_date >= ADD_MONTHS(trunc(SYSDATE,'mm'),-12)
             AND T.settle_date <= trunc(SYSDATE,'mm') - 1
             --过滤源类型是扣率折让单和反向扣率折让单（龙鸿文）
             AND T.bill_type_id = V.BILL_TYPE_ID
             AND T.entity_id = V.ENTITY_ID
             AND T.biz_src_bill_type_code not in ('1009','1010');
        EXCEPTION WHEN OTHERS THEN
          V_settle_amount := 0 ;
        END ;

        BEGIN
            SELECT nvl(SUM(T.Amount), 0)
              INTO V_settle_amount_old
              FROM T_POL_SALES_DATA T
             WHERE T.customer_id = P_CUSTOMER_ID
               AND T.entity_id = P_ENTITY_ID
               AND EXISTS (SELECT 1 FROM T_BD_ITEM A
                               WHERE A.sales_main_type = P_SALES_MAIN_TYPE
                                 AND A.ITEM_ID = T.ITEM_ID)
               AND TO_DATE(T.SALES_MONTH,'YYYYMM') >= ADD_MONTHS(trunc(SYSDATE,'mm'),-12)
               AND TO_DATE(T.SALES_MONTH,'YYYYMM') <= trunc(SYSDATE,'mm') - 1
               And t.stat_caliber = '按结算日期' ;

        EXCEPTION WHEN OTHERS THEN
          V_settle_amount_old := 0 ;
        END ;
      --经销商模式，取单据日期
      Elsif entityGroupCode = 'JXS' Then
        BEGIN
          SELECT nvl(SUM(T.settle_amount), 0)
            INTO V_settle_amount
            FROM v_credit_contact_amount_so T,v_so_bill_type v
           WHERE T.customer_id = P_CUSTOMER_ID
             AND T.entity_id = P_ENTITY_ID
             AND T.sales_main_type = P_SALES_MAIN_TYPE
             AND T.BILL_DATE >= ADD_MONTHS(trunc(SYSDATE,'mm'),-12)
             AND T.BILL_DATE <= trunc(SYSDATE,'mm') - 1
             --过滤源类型是扣率折让单和反向扣率折让单（龙鸿文）
             AND T.bill_type_id = V.BILL_TYPE_ID
             AND T.entity_id = V.ENTITY_ID
             AND T.biz_src_bill_type_code not in ('1009','1010');
        EXCEPTION WHEN OTHERS THEN
          V_settle_amount := 0 ;
        END ;

        BEGIN
            SELECT nvl(SUM(T.Amount), 0)
              INTO V_settle_amount_old
              FROM T_POL_SALES_DATA T
             WHERE T.customer_id = P_CUSTOMER_ID
               AND T.entity_id = P_ENTITY_ID
               AND EXISTS (SELECT 1 FROM T_BD_ITEM A
                               WHERE A.sales_main_type = P_SALES_MAIN_TYPE
                                 AND A.ITEM_ID = T.ITEM_ID)
               AND TO_DATE(T.SALES_MONTH,'YYYYMM') >= ADD_MONTHS(trunc(SYSDATE,'mm'),-12)
               AND TO_DATE(T.SALES_MONTH,'YYYYMM') <= trunc(SYSDATE,'mm') - 1
               And t.stat_caliber = '按单据日期' ;

        EXCEPTION WHEN OTHERS THEN
          V_settle_amount_old := 0 ;
        END ;
      End If ;
    V_RESULT := ROUND(V_settle_amount + V_settle_amount_old,2) ;
    --V_RESULT := 3095001432.4 ; 3.0950014324E9
    RETURN V_RESULT ;
  END;

  --------------------------------------------------------------------------------
  /*
  *   创建日期：2014-11-22
  *     创建者：苏冬渊
  *   功能说明：获取客户营销大类上的调整额度
      参数说明：
  *   返回结果：
  *
  */
  -------------------------------------------------------------------------------
  FUNCTION FUN_GET_ADJ_AMOUNT(P_ENTITY_ID NUMBER,
                                P_CUSTOMER_ID NUMBER,
                                P_SALES_MAIN_TYPE VARCHAR2,
                                IN_ACCOUNT_ID     NUMBER DEFAULT NULL --2017-4-25 增加账户ID参数，默认为空
                                ) RETURN NUMBER IS
   V_RESULT NUMBER := 0 ;
   --V_CUST_GROUP_ID t_credit_cust_group_rel.cust_group_id%type := 0 ;
   V_adj_amount t_credit_adj_requis.adj_amount%TYPE := 0 ;
  BEGIN

      BEGIN
        SELECT nvl(SUM(T.Adj_Amount), 0)
          INTO V_adj_amount
          FROM t_credit_adj_requis T
         WHERE T.customer_id = P_CUSTOMER_ID
           AND T.entity_id = P_ENTITY_ID
           AND T.sales_main_type = P_SALES_MAIN_TYPE
           --2017 04 25 梁颜明 增加账户ID
           AND (
           ((IN_ACCOUNT_ID IS NULL OR 0 >= IN_ACCOUNT_ID)-- AND (T.ACCOUNT_ID IS NULL OR 0 >= T.ACCOUNT_ID)
           --
           )
           --OR (0 < IN_ACCOUNT_ID AND T.ACCOUNT_ID = IN_ACCOUNT_ID)
           )
           AND T.BILL_STATUS = '3'
           AND trunc(SYSDATE) BETWEEN T.BEGIN_DATE AND NVL(NVL(T.DUE_TIME,T.END_DATE),trunc(SYSDATE)) ;
      EXCEPTION WHEN OTHERS THEN
        V_adj_amount := 0 ;
      END ;
    V_RESULT := ROUND(V_adj_amount,2) ;
    RETURN V_RESULT ;
  END;

  --------------------------------------------------------------------------------
  /*
  *   创建日期：2015-07-30
  *     创建者：梁颜明
  *   功能说明：获取客户营销大类上的已使用的三方铺底额度（生效的、制单、送审）
  * ，与FUN_GET_USE_DELAY对应，不包括驳回
      参数说明：
  *   返回结果：
  *
  */
  -------------------------------------------------------------------------------
  FUNCTION FUN_GET_THREEDELAY_AMOUNT(P_ENTITY_ID       NUMBER,
                                    P_CUSTOMER_ID     NUMBER,
                                    P_SALES_MAIN_TYPE VARCHAR2,
                                    IN_ACCOUNT_ID     NUMBER DEFAULT NULL --2017-4-25 增加账户ID参数，默认为空
                                )
    RETURN NUMBER IS
    V_RESULT NUMBER := 0;
  BEGIN
    SELECT nvl(SUM(decode(T.Bill_Status,
                          '3',
                          nvl(T.APPROVAL_AMOUNT, T.REQUIS_AMOUNT),
                          T.REQUIS_AMOUNT)),
               0)
      Into V_RESULT
      From T_CREDIT_DELAYPAY T
     WHERE T.ENTITY_ID = P_ENTITY_ID
       AND T.CUSTOMER_ID = P_CUSTOMER_ID
       AND T.SALES_MAIN_TYPE = P_SALES_MAIN_TYPE
           --2017 04 25 梁颜明 增加账户ID
           AND (
           ((IN_ACCOUNT_ID IS NULL OR 0 >= IN_ACCOUNT_ID)-- AND (T.ACCOUNT_ID IS NULL OR 0 >= T.ACCOUNT_ID)
           --
           )
           OR (0 < IN_ACCOUNT_ID AND T.ACCOUNT_ID = IN_ACCOUNT_ID)
           )
           
          --与FUN_GET_USE_DELAY对应，不包括驳回
       And T.BILL_STATUS In ('1', '2', '3')
       And T.Delaypay_Type = 3
       And trunc(SYSDATE) BETWEEN T.Requis_Date AND
           NVL(NVL(T.DUE_TIME, nvl(t.delay_date, T.END_DATE)),
               trunc(SYSDATE));
    --And NVL(T.END_DATE,Sysdate) <= Sysdate ;
    return V_RESULT;
  END;

  --------------------------------------------------------------------------------
  /*
  *   创建日期：2015-01-01
  *     创建者：苏冬渊
  *   功能说明：获取客户营销大类上的已使用铺底额度
      参数说明：
  *   返回结果：
  *
  */
  -------------------------------------------------------------------------------
  FUNCTION FUN_GET_USE_DELAY(P_ENTITY_ID NUMBER,
                             P_CUSTOMER_ID NUMBER,
                             P_SALES_MAIN_TYPE VARCHAR2,
                             IN_ACCOUNT_ID     NUMBER DEFAULT NULL --2017-4-25 增加账户ID参数，默认为空
                             ) RETURN NUMBER IS
   V_RESULT NUMBER := 0 ;
   --V_CUST_GROUP_ID T_CREDIT_CUST_GROUP_REL.CUST_GROUP_ID%TYPE ;
   V_USED_AMOUNT NUMBER := 0 ;
   V_USING_AMOUNT NUMBER := 0 ;
  BEGIN
      /*-- 根据客户ID获取客户组ID
      BEGIN
        SELECT A.CUST_GROUP_ID
          INTO V_CUST_GROUP_ID
          FROM T_CREDIT_CUST_GROUP A, T_CREDIT_CUST_GROUP_REL B
         WHERE A.CUST_GROUP_ID = B.CUST_GROUP_ID
           AND B.CUSTOMER_ID = P_CUSTOMER_ID ;
      EXCEPTION WHEN OTHERS THEN
        V_CUST_GROUP_ID := -1 ;
      END ;
      --根据客户组ID，客户ID获取客户可用额度
      --1、无客户组的客户
      IF V_CUST_GROUP_ID = 0 OR V_CUST_GROUP_ID = -1 THEN*/
        --获取已生效的客户铺底金额
        BEGIN
          SELECT nvl(SUM(T.delaypay_amount),0)
              Into V_USED_AMOUNT
              FROM T_SALES_ACCOUNT_MX_AMOUNT T
             WHERE T.ENTITY_ID = P_ENTITY_ID
               AND T.CUSTOMER_ID = P_CUSTOMER_ID
               AND T.SALES_MAIN_TYPE = P_SALES_MAIN_TYPE
           --2017 04 25 梁颜明 增加账户ID
           AND (
           ((IN_ACCOUNT_ID IS NULL OR 0 >= IN_ACCOUNT_ID)-- AND (T.ACCOUNT_ID IS NULL OR 0 >= T.ACCOUNT_ID)
           --
           )
           OR (0 < IN_ACCOUNT_ID AND T.ACCOUNT_ID = IN_ACCOUNT_ID)
           )
           
               ;
        EXCEPTION WHEN OTHERS THEN
           V_USED_AMOUNT := 0 ;
        END ;
        --获取制单，送审阶段的已使用的信用额度
        BEGIN
          SELECT nvl(SUM(T.REQUIS_AMOUNT),0)
              Into V_USING_AMOUNT
              From T_CREDIT_DELAYPAY T
             WHERE T.ENTITY_ID = P_ENTITY_ID
               AND T.CUSTOMER_ID = P_CUSTOMER_ID
               AND T.SALES_MAIN_TYPE = P_SALES_MAIN_TYPE
           --2017 04 25 梁颜明 增加账户ID
           AND (
           ((IN_ACCOUNT_ID IS NULL OR 0 >= IN_ACCOUNT_ID)-- AND (T.ACCOUNT_ID IS NULL OR 0 >= T.ACCOUNT_ID)
           --
           )
           OR (0 < IN_ACCOUNT_ID AND T.ACCOUNT_ID = IN_ACCOUNT_ID)
           )
           
               And T.BILL_STATUS In ('1','2')
               And T.BILL_TYPE_ID IN ('1','2')
               And trunc(SYSDATE) BETWEEN T.Requis_Date AND NVL(NVL(T.DUE_TIME,nvl(t.delay_date,T.END_DATE)),trunc(SYSDATE)) ;
               --And NVL(T.END_DATE,Sysdate) <= Sysdate ;
        EXCEPTION WHEN OTHERS THEN
           V_USING_AMOUNT := 0 ;
        END ;
     --2、存在客户组的客户
      /*ELSE
        --获取已生效的客户铺底金额
        BEGIN
          SELECT nvl(SUM(T.delaypay_amount),0)
              Into V_USED_AMOUNT
              FROM T_SALES_ACCOUNT_MX_AMOUNT T
             WHERE T.ENTITY_ID = P_ENTITY_ID
               AND T.CUSTOMER_ID In
                 (SELECT A.customer_id
                    FROM T_CREDIT_CUST_GROUP_REL A
                   WHERE A.CUST_GROUP_ID = V_CUST_GROUP_ID)
               AND T.SALES_MAIN_TYPE = P_SALES_MAIN_TYPE ;
        EXCEPTION WHEN OTHERS THEN
           V_USED_AMOUNT := 0 ;
        END ;
        --获取制单，送审阶段的已使用的信用额度
        BEGIN
          SELECT nvl(SUM(T.REQUIS_AMOUNT),0)
              Into V_USING_AMOUNT
              From T_CREDIT_DELAYPAY T
             WHERE T.ENTITY_ID = P_ENTITY_ID
               AND T.CUSTOMER_ID In
                 (SELECT A.customer_id
                    FROM T_CREDIT_CUST_GROUP_REL A
                   WHERE A.CUST_GROUP_ID = V_CUST_GROUP_ID)
               AND T.SALES_MAIN_TYPE = P_SALES_MAIN_TYPE
               And T.BILL_STATUS In ('1','2')
               And T.BILL_TYPE_ID = '1'
               And trunc(SYSDATE) BETWEEN T.Requis_Date AND NVL(NVL(T.DUE_TIME,nvl(t.delay_date,T.END_DATE)),trunc(SYSDATE)) ;
              -- And NVL(T.END_DATE,Sysdate) <= Sysdate ;
        EXCEPTION WHEN OTHERS THEN
           V_USING_AMOUNT := 0 ;
        END ;

      END IF ; */
    V_RESULT := ROUND((V_USED_AMOUNT+V_USING_AMOUNT),2) ;
    RETURN V_RESULT ;
  END;

  --------------------------------------------------------------------------------
  /*
  *   创建日期：2014-11-22
  *     创建者：苏冬渊
  *   功能说明：获取客户营销大类上的可用信用额度，存在客户组需要取客户组的总可用额度
      参数说明：
  *   返回结果：
  *
  */
  -------------------------------------------------------------------------------
  FUNCTION FUN_GET_DELAY_CU_AMOUNT(P_ENTITY_ID NUMBER,
                                   P_CUSTOMER_ID NUMBER,
                                   P_SALES_MAIN_TYPE VARCHAR2,
                                   IN_ACCOUNT_ID     NUMBER DEFAULT NULL --2017-5-5 增加账户ID参数，默认为空
                                   ) RETURN NUMBER IS
   V_RESULT NUMBER := 0 ;
   V_CAN_USE_DELAY_AMOUNT NUMBER := 0 ;
   --V_CREDIT_GROUP_ID T_CREDIT_CUST_GROUP_REL.CUST_GROUP_ID%TYPE ;
   V_CUST_GROUP_ID T_CREDIT_CUST_GROUP_REL.CUST_GROUP_ID%TYPE ;
   V_ADJ_AMOUNT NUMBER := 0 ;
   V_USE_AMOUNT NUMBER := 0 ;
   V_CREDIT_LINE NUMBER := 0 ;
  BEGIN
     -- 根据客户ID获取客户组ID
      BEGIN
        /*SELECT * FROM (
        SELECT PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(
        P_ENTITY_ID,P_CUSTOMER_ID,P_SALES_MAIN_TYPE,IN_ACCOUNT_ID) AS ID FROM DUAL
        )
        ;*/
        SELECT A.CUST_GROUP_ID
          INTO V_CUST_GROUP_ID
          FROM T_CREDIT_CUST_GROUP A, T_CREDIT_CUST_GROUP_REL B
         WHERE A.CUST_GROUP_ID = B.CUST_GROUP_ID
           AND B.CUSTOMER_ID = P_CUSTOMER_ID ;
      EXCEPTION WHEN OTHERS THEN
        V_CUST_GROUP_ID := -1 ;
      END ;
      --根据客户组ID，客户ID获取客户可用额度
      --1、无客户组的客户
      IF V_CUST_GROUP_ID = 0 OR V_CUST_GROUP_ID = -1 THEN
        --信用额度、调整额度、已使用额度
        BEGIN
          SELECT SUM(T.remainder_amount),SUM(T.requis_amount),SUM(T.user_delaypay)
            INTO V_CREDIT_LINE,V_ADJ_AMOUNT,V_USE_AMOUNT
            FROM V_CREDIT_TERMS T
           WHERE T.customer_id = P_CUSTOMER_ID
             AND T.entity_id = P_ENTITY_ID
             AND T.sales_main_type_code = P_SALES_MAIN_TYPE
             AND (
             (T.ACCOUNT_ID = IN_ACCOUNT_ID)
             OR ((T.ACCOUNT_ID IS NULL OR 0 >= T.ACCOUNT_ID) AND (IN_ACCOUNT_ID IS NULL OR 0 >= IN_ACCOUNT_ID))
             )
             ;
        EXCEPTION WHEN OTHERS THEN
           V_CREDIT_LINE := 0 ;
           V_ADJ_AMOUNT := 0 ;
           V_USE_AMOUNT := 0 ;
        END ;
     --2、存在客户组的客户
      ELSE
         --信用额度、调整额度、已使用额度
        BEGIN
          SELECT SUM(T.remainder_amount),
                 SUM(T.requis_amount),
                 SUM(T.user_delaypay)
            INTO V_CREDIT_LINE, V_ADJ_AMOUNT, V_USE_AMOUNT
            FROM V_CREDIT_TERMS T
           WHERE EXISTS
                 (SELECT 1
                    FROM T_CREDIT_CUST_GROUP_REL A
                   WHERE T.customer_id = A.customer_id AND A.CUST_GROUP_ID = V_CUST_GROUP_ID)
             AND T.entity_id = P_ENTITY_ID
             AND T.sales_main_type_code = P_SALES_MAIN_TYPE
             AND (
             (T.ACCOUNT_ID = IN_ACCOUNT_ID)
             OR (0 < IN_ACCOUNT_ID AND T.customer_id <> IN_ACCOUNT_ID AND T.ACCOUNT_ID > 0)
             OR ((T.ACCOUNT_ID IS NULL OR 0 >= T.ACCOUNT_ID) AND (IN_ACCOUNT_ID IS NULL OR 0 >= IN_ACCOUNT_ID))
             )
             ;
        EXCEPTION WHEN OTHERS THEN
           V_CREDIT_LINE := 0 ;
           V_ADJ_AMOUNT := 0 ;
           V_USE_AMOUNT := 0 ;
        END ;
      END IF ;
    V_CAN_USE_DELAY_AMOUNT := V_CREDIT_LINE ;
    --V_CAN_USE_DELAY_AMOUNT := V_CREDIT_LINE + V_ADJ_AMOUNT - V_USE_AMOUNT ;
    V_RESULT := ROUND(V_CAN_USE_DELAY_AMOUNT,2) ;
    RETURN V_RESULT ;
  END;
  --------------------------------------------------------------------------------
  /*
  *   创建日期：2014-12-10
  *     创建者：苏冬渊
  *   功能说明：根据传进来的三方承兑到款单据ID获取该单据下对应营销大类的未分解金额
      参数说明：
          P_FLAG = 1 : 求三方承兑总金额
          P_FLAG = 2 ：求三方承兑已解付金额
          P_FLAG = 3 : 求未解付金额
          P_FLAG = 4 : 求未解付金额(P_CASH_RECEIPT_ID:表示票据号)
  *   返回结果：
  *
  */
  -------------------------------------------------------------------------------
  FUNCTION FUN_GET_THREE_AMOUNT(P_CASH_RECEIPT_ID NUMBER,
                                        P_SALES_MAIN_TYPE VARCHAR2,
                                        P_FLAG NUMBER,
                                        IS_DISCOUNT_TYPE    IN VARCHAR2 DEFAULT NULL--折让方式
                                        ) RETURN NUMBER IS
   V_RESULT NUMBER := 0 ;
   V_CASH_RECEIPT_ID Number ;
   V_AR_AMOUNT1     T_AR_CASH_RECEIPT_HEADERS.AMOUNT%TYPE := 0 ; --三方承兑总金额
   V_AR_AMOUNT2     T_AR_CASH_RECEIPT_HEADERS.AMOUNT%TYPE := 0 ; --已解付金额
   V_AR_AMOUNT3     T_AR_CASH_RECEIPT_HEADERS.AMOUNT%TYPE := 0 ; --已铺底金额
  BEGIN
     IF P_FLAG = 1 THEN
      --三方承兑单据该营销大类下总金额
       BEGIN
         SELECT nvl(SUM(T.AMOUNT),0)
           INTO V_AR_AMOUNT1
           FROM T_AR_CASH_RECEIPT_LINES T
          WHERE T.CASH_RECEIPT_ID = P_CASH_RECEIPT_ID
            AND T.SALES_MAIN_TYPE_CODE = P_SALES_MAIN_TYPE ;
       EXCEPTION WHEN OTHERS THEN
         V_AR_AMOUNT1 := 0 ;
       END ;
       V_RESULT := V_AR_AMOUNT1 ;

     ELSIF P_FLAG = 2 THEN
       --三方承兑单据该营销大类下  已解付金额
       BEGIN
         SELECT nvl(SUM(T.SOLUTION_PAY_AMOUNT),0)
           INTO V_AR_AMOUNT2
           FROM T_AR_ACCE_SOLU_PAY T
          WHERE EXISTS
          (SELECT 1
                   FROM T_AR_CASH_RECEIPT_LINES A
                  WHERE A.CASH_RECEIPT_LINES_ID = T.CASH_RECEIPT_LINES_ID
                    AND A.CASH_RECEIPT_ID = P_CASH_RECEIPT_ID
                    AND A.SALES_MAIN_TYPE_CODE = P_SALES_MAIN_TYPE)
            And T.SOLUTION_PAY_STATUS <> '1' ;

        EXCEPTION WHEN OTHERS THEN
             V_AR_AMOUNT2 := 0 ;
        END ;

        V_RESULT := V_AR_AMOUNT2 ;

      ELSIF P_FLAG = 3 THEN
        --三方承兑单据该营销大类下总金额
         BEGIN
           SELECT nvl(SUM(T.AMOUNT),0)
             INTO V_AR_AMOUNT1
             FROM T_AR_CASH_RECEIPT_LINES T
            WHERE T.CASH_RECEIPT_ID = P_CASH_RECEIPT_ID
              AND T.SALES_MAIN_TYPE_CODE = P_SALES_MAIN_TYPE ;
         EXCEPTION WHEN OTHERS THEN
           V_AR_AMOUNT1 := 0 ;
         END ;

         --三方承兑单据该营销大类下  已解付金额
         BEGIN
           SELECT NVL(sum(t.SOLUTION_PAY_AMOUNT),0)
             INTO V_AR_AMOUNT2
             FROM T_AR_ACCE_SOLU_PAY T
            WHERE EXISTS
            (SELECT 1
                     FROM T_AR_CASH_RECEIPT_LINES A
                    WHERE A.CASH_RECEIPT_LINES_ID = T.CASH_RECEIPT_LINES_ID
                      AND A.CASH_RECEIPT_ID = P_CASH_RECEIPT_ID
                      AND A.SALES_MAIN_TYPE_CODE = P_SALES_MAIN_TYPE)
              And T.SOLUTION_PAY_STATUS <> '1' ;
         EXCEPTION WHEN OTHERS THEN
               V_AR_AMOUNT2 := 0 ;
         END ;
         V_RESULT := V_AR_AMOUNT1 - V_AR_AMOUNT2  ;
         IF V_RESULT < 0 THEN
           V_RESULT := 0 ;
         END IF ;

        ELSIF P_FLAG = 4 Then
         --根据传进来的cash_code 获取投ID
        /* Begin
           Select t.cash_receipt_id Into V_CASH_RECEIPT_ID
           From T_AR_CASH_RECEIPT_HEADERS t Where t.cash_code = '' || P_CASH_RECEIPT_ID ;
         Exception When Others Then
            V_CASH_RECEIPT_ID := 0 ;
         End ;*/
         V_CASH_RECEIPT_ID := P_CASH_RECEIPT_ID;
        --三方承兑单据该营销大类下总金额
         BEGIN
           SELECT nvl(SUM(T.AMOUNT),0)
             INTO V_AR_AMOUNT1
             FROM T_AR_CASH_RECEIPT_LINES T
            WHERE T.CASH_RECEIPT_ID = V_CASH_RECEIPT_ID
              AND T.SALES_MAIN_TYPE_CODE = P_SALES_MAIN_TYPE ;
         EXCEPTION WHEN OTHERS THEN
           V_AR_AMOUNT1 := 0 ;
         END ;

         --三方承兑单据该营销大类下  已解付金额
         BEGIN
           SELECT NVL(sum(t.SOLUTION_PAY_AMOUNT),0)
             INTO V_AR_AMOUNT2
             FROM T_AR_ACCE_SOLU_PAY T
            WHERE EXISTS
            (SELECT 1
                     FROM T_AR_CASH_RECEIPT_LINES A
                    WHERE A.CASH_RECEIPT_LINES_ID = T.CASH_RECEIPT_LINES_ID
                      AND A.CASH_RECEIPT_ID = V_CASH_RECEIPT_ID
                      AND A.SALES_MAIN_TYPE_CODE = P_SALES_MAIN_TYPE)
              And T.SOLUTION_PAY_STATUS <> '1' ;
         EXCEPTION WHEN OTHERS THEN
               V_AR_AMOUNT2 := 0 ;
         END ;

         --该三方承兑票据已使用铺底金额
         IF IS_DISCOUNT_TYPE IS NULL OR IS_DISCOUNT_TYPE = 'COMMON' THEN
         BEGIN
           SELECT NVL(Sum(nvl(t.approval_amount,t.requis_amount)),0)
             INTO V_AR_AMOUNT3
             FROM t_credit_delaypay T
            Where t.moneyorder_number = (Select a.cash_code From t_ar_cash_receipt_headers a Where a.cash_receipt_id = V_CASH_RECEIPT_ID)
              And t.sales_main_type = P_SALES_MAIN_TYPE
              And t.due_by Is Null
              And t.bill_status Not In ('5','6');
         EXCEPTION WHEN OTHERS THEN
               V_AR_AMOUNT3 := 0 ;
         END ;
         END IF;

         V_RESULT := V_AR_AMOUNT1 - V_AR_AMOUNT2 - V_AR_AMOUNT3 ;
         IF V_RESULT < 0 THEN
           V_RESULT := 0 ;
         END IF ;

        END IF ;

        V_RESULT := ROUND(V_RESULT,2) ;

    RETURN V_RESULT ;
  END;


  --------------------------------------------------------------------------------
  /*
  *   创建日期：2015-04-23
  *     创建者：苏冬渊
  *   功能说明：根据主体、铺底单据类型、铺底类型获取铺底期限、年利率、逾期年利率
      参数说明：
          P_FLAG = 1 : 获取铺底期限
          P_FLAG = 2 ：获取年利率
          P_FLAG = 3 : 获取逾期年利率
  *   返回结果：
  *
  */
  -------------------------------------------------------------------------------
  FUNCTION FUN_GET_CONFIG_INFO(P_ENTITY_ID NUMBER,
                               P_BILL_TYPE_ID Number,
                               P_DELAYPAY_TYPE Number,
                               P_FLAG NUMBER) RETURN NUMBER IS
   V_RESULT NUMBER := 0 ;
   V_SQL Varchar2(400) ;
   V_SQL1 Varchar2(400) ;
   BEGIN
     V_SQL := 'SELECT ' ;
     Select DECODE(P_FLAG,1,'T.DEADLINE ',2,'T.YEAR_RATE ',3,'T.OVERDUE_YEAR_RATE ') Into V_SQL1 From DUAL ;
     V_SQL := V_SQL || V_SQL1 ;

     V_SQL1 := 'FROM T_CREDIT_DELAYPAY_CONFIGUE T WHERE T.ENTITY_ID = ' || P_ENTITY_ID
             ||' AND T.BILL_TYPE_ID = '|| P_BILL_TYPE_ID
             ||' AND T.DELAYPAY_TYPE = ' || P_DELAYPAY_TYPE
             ||' AND ROWNUM = 1 ' ;

     V_SQL := V_SQL || V_SQL1 ;
     Begin
       Execute Immediate V_SQL Into V_RESULT ;
     Exception When Others Then
       V_RESULT := 0 ;
     End ;
    RETURN V_RESULT ;
  END;
  
   --------------------------------------------------------------------------------------
  /*add by wangcong
  *传入起止日期，计算起止时间内的销售金额
  *用于信用额度计算
  *
  */
  FUNCTION FUN_GET_SALES_AMOUNT_BY_DATE(P_ENTITY_ID NUMBER,
                                P_CUSTOMER_ID NUMBER,
                                P_BEGIN_DATE VARCHAR2,
                                P_END_DATE VARCHAR2,
                                P_SALES_MAIN_TYPE VARCHAR2,
                                IN_ACCOUNT_ID     NUMBER DEFAULT NULL --2017-5-2 增加账户ID参数，默认为空
                                ) RETURN NUMBER IS
   V_RESULT NUMBER := 0 ;
   --V_CUST_GROUP_ID t_credit_cust_group_rel.cust_group_id%type := 0 ;
   V_settle_amount     v_credit_contact_amount_so.settle_amount%TYPE := 0 ;
   V_settle_amount_old v_credit_contact_amount_so.settle_amount%TYPE := 0 ;
   
   V_BEGIN_DATE DATE := TO_DATE(P_BEGIN_DATE,'YYYYMMDD');
   V_END_DATE DATE := TO_DATE(P_END_DATE,'YYYYMMDD');
   V_BEGIN_MONTH DATE := trunc(TO_DATE(P_BEGIN_DATE,'YYYYMMDD'),'MM');
   V_END_MONTH DATE := trunc(TO_DATE(P_END_DATE,'YYYYMMDD'),'MM');
   
   
  Begin
        BEGIN
         SELECT nvl(SUM(D.list_amount),0)
           INTO V_settle_amount
           FROM V_CREDIT_CONTACT_AMOUNT_SO D
         WHERE D.CUSTOMER_ID = P_CUSTOMER_ID
           AND D.BILL_DATE BETWEEN V_BEGIN_DATE AND
               V_END_DATE
           AND D.BIZ_SRC_BILL_TYPE_CODE IN ('1001','1002','1003','1004')
           AND D.ENTITY_ID = P_ENTITY_ID
           AND D.sales_main_type = P_SALES_MAIN_TYPE
           --2017 5 2 梁颜明 增加账户ID
           AND (
           ((IN_ACCOUNT_ID IS NULL OR 0 >= IN_ACCOUNT_ID)-- AND (D.ACCOUNT_ID IS NULL OR 0 >= D.ACCOUNT_ID)
           --
           )
           OR (0 < IN_ACCOUNT_ID AND D.ACCOUNT_ID = IN_ACCOUNT_ID)
           )
           ;
        EXCEPTION WHEN OTHERS THEN
          V_settle_amount := 0 ;
        END ;

        BEGIN
            SELECT nvl(SUM(T.LIST_AMOUNT),0)
              INTO V_settle_amount_old
              FROM T_POL_SALES_DATA T
             WHERE T.customer_id = P_CUSTOMER_ID
               AND T.entity_id = P_ENTITY_ID
               AND TO_DATE(T.SALES_MONTH,'YYYYMM') >= V_BEGIN_MONTH
               AND TO_DATE(T.SALES_MONTH,'YYYYMM') <= V_END_MONTH
               And t.stat_caliber = '按单据日期' 
               AND t.Sales_Main_Type = P_SALES_MAIN_TYPE
               --2017 5 2 梁颜明 增加账户ID
               AND (
               ((IN_ACCOUNT_ID IS NULL OR 0 >= IN_ACCOUNT_ID)-- AND (T.ACCOUNT_ID IS NULL OR 0 >= T.ACCOUNT_ID)
               --
               )
               OR (0 < IN_ACCOUNT_ID AND T.ACCOUNT_ID = IN_ACCOUNT_ID)
               );

        EXCEPTION WHEN OTHERS THEN
          V_settle_amount_old := 0 ;
        END ;
    V_RESULT := ROUND(V_settle_amount + V_settle_amount_old,2) ;
    --V_RESULT := 3095001432.4 ; 3.0950014324E9
    RETURN V_RESULT ;
  END;           
  
   /*add by wangcong
  *用于信用可用额度计算
  *
  */
  FUNCTION FUN_GET_CAN_USE_AMOUNT(P_ENTITY_ID NUMBER,
                                P_CUSTOMER_ID NUMBER,
                                P_CUSTOMER_CREDIT NUMBER,
                                P_LAST_YEAR_AMOUNT NUMBER,
                                P_THIS_YEAR_AMOUNT NUMBER,
                                P_COOPER_DATE NUMBER,
                                P_TWELVE_AMOUNT NUMBER,
                                P_SALES_MAIN_TYPE VARCHAR2,
                                IN_ACCOUNT_ID     NUMBER DEFAULT NULL --2017-4-25 增加账户ID参数，默认为空
                                ) RETURN NUMBER IS  
    V_RESULT NUMBER := 0; 
    V_LAST_YEAR_SCALE NUMBER := 0;--上年度额度比例
    V_THIS_YEAR_SCALE NUMBER := 0;--本年度额度比例
    V_COOPER_DATE NUMBER := 0;--合作年限
    V_TWELVE_AMOUNT NUMBER := 0;--前12个月销售金额
    V_IF_CONTROL_BY_TYPE VARCHAR2(24);--是否按品类控制
    --V_SALES_MAIN_TYPE VARCHAR2(24);
    V_CREDIT_AMOUNT NUMBER := 0;
    V_ADJ_AMOUNT NUMBER := 0;
    V_USE_DELAY NUMBER := 0;
    V_THREEDELAY_AMOUNT NUMBER :=0;
    R_SALES_MAIN_TYPE VARCHAR2(24);
    V_LAST_YEAR_AMOUNT NUMBER := 0;
    V_THIS_YEAR_AMOUNT NUMBER := 0;
    V_CUSTOMER_CREDIT NUMBER := 0;
    V_TWELVE_AMOUNT_UNION NUMBER := 0;
     
    
    CURSOR C_SALES_MAIN_TYPE IS 
           SELECT T.SALES_MAIN_TYPE_CODE 
           FROM T_CREDIT_CUSTOMER T 
           WHERE T.CUSTOMER_ID = P_CUSTOMER_ID 
           AND T.ENTITY_ID = P_ENTITY_ID
           --2017 04 25 梁颜明 增加账户ID
           AND (
           ((IN_ACCOUNT_ID IS NULL OR 0 >= IN_ACCOUNT_ID) AND (T.ACCOUNT_ID IS NULL OR 0 >= T.ACCOUNT_ID))
           OR (0 < IN_ACCOUNT_ID AND T.ACCOUNT_ID = IN_ACCOUNT_ID)
           )
           ;    
    BEGIN
      --获取客户要求的合作期限和销售金额,上年和本年的额度比例
      --modify by liangym2 2018-2-10 取最大的才是合理的
      BEGIN
       SELECT COORERATION_DATE,LAST_TWELVE_AMOUNT,currentyear_proportion,lastyear_proportion into V_COOPER_DATE,
              V_TWELVE_AMOUNT,
              V_THIS_YEAR_SCALE,
              V_LAST_YEAR_SCALE
       FROM (select nvl(max(t.COORERATION_DATE), 0) AS COORERATION_DATE,
              nvl(max(t.LAST_TWELVE_AMOUNT), 0) AS LAST_TWELVE_AMOUNT,
              nvl(max(t.currentyear_proportion), 0) AS currentyear_proportion,
              nvl(max(t.lastyear_proportion), 0) AS lastyear_proportion
         from t_credit_rating_customer t
         INNER JOIN T_CUSTOMER_COOPERATE_MODEL CM
         ON (CM.ENTITY_ID = P_ENTITY_ID AND T.ENTITY_ID = P_ENTITY_ID
         AND CM.CUSTOMER_ID = P_CUSTOMER_ID AND 'Active' = CM.ACTIVE_FLAG
         AND CM.COOPERATION_MODEL = T.MIDEA_MARKET_MODE
         AND (IN_ACCOUNT_ID IS NULL OR 0 >= IN_ACCOUNT_ID
         OR EXISTS (SELECT 1 FROM T_CUSTOMER_ACCOUNT CA WHERE CA.ACCOUNT_ID = IN_ACCOUNT_ID
         AND CA.CUSTOMER_ID = P_CUSTOMER_ID AND CA.SALES_CENTER_ID = CM.SALES_CENTER_ID))
         )
         ) WHERE 1 = ROWNUM
        /*where t.midea_market_mode in
              (select cb.cooperation_model
                 from t_customer_brand cb
                where cb.customer_id = P_CUSTOMER_ID
                  and cb.entity_id = P_ENTITY_ID
                  and cb.active_flag = 'Active')
          and t.entity_id = P_ENTITY_ID*/;
         EXCEPTION WHEN OTHERS THEN
           V_COOPER_DATE :=0;
           V_TWELVE_AMOUNT :=0;
           V_THIS_YEAR_SCALE := 0;
           V_LAST_YEAR_SCALE := 0;
          END;
          
          --每年1/2/3月份本年度信用额度比例直接为0 2017-01-05
          IF 4 > EXTRACT(MONTH FROM SYSDATE) THEN
            V_THIS_YEAR_SCALE := 0;
          END IF;
          
          IF P_COOPER_DATE<V_COOPER_DATE THEN
            V_RESULT := 0;
            RETURN V_RESULT;
          END IF;
          
          --获取是否按品类控制
          pkg_bd.P_GET_PARAMETER_VALUE('if_control_by_type',P_ENTITY_ID,NULL,NULL,V_IF_CONTROL_BY_TYPE);
        
          IF V_IF_CONTROL_BY_TYPE = 'Y' THEN
            --按品类控制
            IF P_TWELVE_AMOUNT<V_TWELVE_AMOUNT THEN 
              V_RESULT:=0;
              RETURN V_RESULT;
            END IF;
            
            IF V_LAST_YEAR_SCALE=0 AND V_THIS_YEAR_SCALE=0 THEN
              --上年度和本年度额度比例为0 取客户等级额度
              V_CREDIT_AMOUNT := P_CUSTOMER_CREDIT;
            ELSIF V_LAST_YEAR_SCALE=0 AND V_THIS_YEAR_SCALE<>0 THEN
              --本年度额度比例不为0 取本年度和客户等级额度的最小值
              SELECT LEAST(P_CUSTOMER_CREDIT,P_THIS_YEAR_AMOUNT) INTO V_CREDIT_AMOUNT FROM DUAL;
            ELSIF V_LAST_YEAR_SCALE<>0 AND V_THIS_YEAR_SCALE=0 THEN
              --上年度额度比例不为0 取上年度和客户等级额度的最小值
              SELECT LEAST(P_CUSTOMER_CREDIT,P_LAST_YEAR_AMOUNT) INTO V_CREDIT_AMOUNT FROM DUAL;
            ELSIF V_LAST_YEAR_SCALE<>0 AND V_THIS_YEAR_SCALE<>0 THEN
              --上年度和本年度额度比例不为0 取上年度 本年度 客户等级额度最小值
              SELECT LEAST(P_CUSTOMER_CREDIT,P_LAST_YEAR_AMOUNT,P_THIS_YEAR_AMOUNT) INTO V_CREDIT_AMOUNT FROM DUAL;
            END IF;
              
            V_ADJ_AMOUNT := PKG_CREDIT_TOOLS.FUN_GET_ADJ_AMOUNT(P_ENTITY_ID,P_CUSTOMER_ID,P_SALES_MAIN_TYPE,IN_ACCOUNT_ID);
            V_USE_DELAY := PKG_CREDIT_TOOLS.FUN_GET_USE_DELAY(P_ENTITY_ID,P_CUSTOMER_ID,P_SALES_MAIN_TYPE,IN_ACCOUNT_ID);
            V_THREEDELAY_AMOUNT := PKG_CREDIT_TOOLS.FUN_GET_THREEDELAY_AMOUNT(P_ENTITY_ID,P_CUSTOMER_ID,P_SALES_MAIN_TYPE,IN_ACCOUNT_ID);
            
           
          ELSIF V_IF_CONTROL_BY_TYPE = 'N' THEN
            --不按品类控制
            SELECT SUM(NVL(T.CREDIT_LINE, 0)),
                    SUM(NVL(T.LASTYEAR_CREDIT_LINE, 0)),
                    SUM(NVL(T.THISYEAR_CREDIT_LINE, 0)),
                    SUM(NVL(T.TWELVE_AMOUNT,0))
               INTO V_CUSTOMER_CREDIT,V_LAST_YEAR_AMOUNT,V_THIS_YEAR_AMOUNT,V_TWELVE_AMOUNT_UNION
                --2017 04 25 梁颜明 增加账户ID
               FROM T_CREDIT_CUSTOMER T
              WHERE T.CUSTOMER_ID = P_CUSTOMER_ID
                AND T.ENTITY_ID = P_ENTITY_ID
                AND (
                ((IN_ACCOUNT_ID IS NULL OR 0 >= IN_ACCOUNT_ID) AND (T.ACCOUNT_ID IS NULL OR 0 >= T.ACCOUNT_ID))
                OR (0 < IN_ACCOUNT_ID AND T.ACCOUNT_ID = IN_ACCOUNT_ID)
                )
                ;
                
            IF V_TWELVE_AMOUNT_UNION<V_TWELVE_AMOUNT THEN
              V_RESULT:=0;
              RETURN V_RESULT;
            END IF;
              
            Open C_SALES_MAIN_TYPE;
            LOOP
               FETCH C_SALES_MAIN_TYPE
               INTO R_SALES_MAIN_TYPE;
            EXIT WHEN C_SALES_MAIN_TYPE%NOTFOUND;
            
            BEGIN
              V_ADJ_AMOUNT := V_ADJ_AMOUNT+PKG_CREDIT_TOOLS.FUN_GET_ADJ_AMOUNT(P_ENTITY_ID,P_CUSTOMER_ID,R_SALES_MAIN_TYPE,IN_ACCOUNT_ID);
              V_USE_DELAY := V_USE_DELAY+PKG_CREDIT_TOOLS.FUN_GET_USE_DELAY(P_ENTITY_ID,P_CUSTOMER_ID,R_SALES_MAIN_TYPE,IN_ACCOUNT_ID);
              V_THREEDELAY_AMOUNT := V_THREEDELAY_AMOUNT+PKG_CREDIT_TOOLS.FUN_GET_THREEDELAY_AMOUNT(P_ENTITY_ID,P_CUSTOMER_ID,R_SALES_MAIN_TYPE,IN_ACCOUNT_ID);
            END;
            END LOOP;
            
              
            IF V_LAST_YEAR_SCALE=0 AND V_THIS_YEAR_SCALE=0 THEN
              --上年度和本年度额度比例为0 取客户等级额度
              V_CREDIT_AMOUNT := V_CUSTOMER_CREDIT;
            ELSIF V_LAST_YEAR_SCALE=0 AND V_THIS_YEAR_SCALE<>0 THEN
              --本年度额度比例不为0 取本年度和客户等级额度的最小值
              SELECT LEAST(V_CUSTOMER_CREDIT,V_THIS_YEAR_AMOUNT) INTO V_CREDIT_AMOUNT FROM DUAL;
            ELSIF V_LAST_YEAR_SCALE<>0 AND V_THIS_YEAR_SCALE=0 THEN
              --上年度额度比例不为0 取上年度和客户等级额度的最小值
              SELECT LEAST(V_CUSTOMER_CREDIT,V_LAST_YEAR_AMOUNT) INTO V_CREDIT_AMOUNT FROM DUAL;
            ELSIF V_LAST_YEAR_SCALE<>0 AND V_THIS_YEAR_SCALE<>0 THEN
              --上年度和本年度额度比例不为0 取上年度 本年度 客户等级额度最小值
              SELECT LEAST(V_CUSTOMER_CREDIT,V_LAST_YEAR_AMOUNT,V_THIS_YEAR_AMOUNT) INTO V_CREDIT_AMOUNT FROM DUAL;
            END IF;
          END IF;
          
          V_RESULT := ROUND((V_CREDIT_AMOUNT+V_ADJ_AMOUNT-V_USE_DELAY+V_THREEDELAY_AMOUNT),2);
          RETURN V_RESULT;
      END;               

  --------------------------------------------------------------------------------
  /*
  *   创建日期：2016-6-6
  *   创建者：肖旭
  *   功能说明：获取客户的调整额度
  */
  --------------------------------------------------------------------------------
  FUNCTION FUN_GET_CUST_ADJ_AMOUNT
  (
    P_ENTITY_ID   NUMBER,
    P_CUSTOMER_ID NUMBER,
    IN_ACCOUNT_ID     NUMBER DEFAULT NULL --2017-5-5 增加账户ID参数，默认为空
  ) RETURN NUMBER IS
    V_RESULT     NUMBER := 0;
    V_ADJ_AMOUNT T_CREDIT_ADJ_REQUIS.ADJ_AMOUNT%TYPE := 0;
  BEGIN
    BEGIN
      SELECT NVL(SUM(T.ADJ_AMOUNT), 0)
        INTO V_ADJ_AMOUNT
        FROM T_CREDIT_ADJ_REQUIS T
       WHERE T.CUSTOMER_ID = P_CUSTOMER_ID
         AND T.ENTITY_ID = P_ENTITY_ID
         AND T.BILL_STATUS = '3'
         AND TRUNC(SYSDATE) BETWEEN T.BEGIN_DATE AND
             NVL(NVL(T.DUE_TIME, T.END_DATE), TRUNC(SYSDATE));
    EXCEPTION
      WHEN OTHERS THEN
        V_ADJ_AMOUNT := 0;
    END;
    V_RESULT := ROUND(V_ADJ_AMOUNT, 2);
    RETURN V_RESULT;
  END;

  --------------------------------------------------------------------------------
  /*
  *   创建日期：2016-6-7
  *   创建者：肖旭
  *   功能说明：获取客户已使用的铺底额度（生效、制单、送审）
  */
  --------------------------------------------------------------------------------
  FUNCTION FUN_GET_CUST_USE_DELAY
  (
    P_ENTITY_ID   NUMBER,
    P_CUSTOMER_ID NUMBER,
    IN_ACCOUNT_ID NUMBER DEFAULT NULL --2017-5-5 增加账户ID参数，默认为空
  ) RETURN NUMBER IS
    V_RESULT       NUMBER := 0;
    V_USED_AMOUNT  NUMBER := 0;
    V_USING_AMOUNT NUMBER := 0;
  BEGIN
    --获取已生效的客户铺底金额
    BEGIN
      SELECT NVL(SUM(T.DELAYPAY_AMOUNT), 0)
        INTO V_USED_AMOUNT
        FROM T_SALES_ACCOUNT_MX_AMOUNT T
       WHERE T.ENTITY_ID = P_ENTITY_ID
         AND T.CUSTOMER_ID = P_CUSTOMER_ID;
    EXCEPTION
      WHEN OTHERS THEN
        V_USED_AMOUNT := 0;
    END;
    --获取制单，送审阶段的已使用的信用额度
    BEGIN
      SELECT NVL(SUM(T.REQUIS_AMOUNT), 0)
        INTO V_USING_AMOUNT
        FROM T_CREDIT_DELAYPAY T
       WHERE T.ENTITY_ID = P_ENTITY_ID
         AND T.CUSTOMER_ID = P_CUSTOMER_ID
         AND T.BILL_STATUS IN ('1', '2')
         AND T.BILL_TYPE_ID IN ('1', '2')
         AND TRUNC(SYSDATE) BETWEEN T.REQUIS_DATE AND
             NVL(NVL(T.DUE_TIME, NVL(T.DELAY_DATE, T.END_DATE)), TRUNC(SYSDATE));
    EXCEPTION
      WHEN OTHERS THEN
        V_USING_AMOUNT := 0;
    END;
    V_RESULT := ROUND((V_USED_AMOUNT + V_USING_AMOUNT), 2);
    RETURN V_RESULT;
  END;

  --------------------------------------------------------------------------------
  /*
  *   创建日期：2016-6-7
  *   创建者：肖旭
  *   功能说明：获取客户已使用的三方铺底额度（生效、制单、送审）
  */
  --------------------------------------------------------------------------------
  FUNCTION FUN_GET_CUST_THREEDELAY_AMOUNT
  (
    P_ENTITY_ID   NUMBER,
    P_CUSTOMER_ID NUMBER,
    IN_ACCOUNT_ID NUMBER DEFAULT NULL --2017-5-5 增加账户ID参数，默认为空
  ) RETURN NUMBER IS
    V_RESULT NUMBER := 0;
  BEGIN
    SELECT NVL(SUM(DECODE(T.BILL_STATUS, '3', NVL(T.APPROVAL_AMOUNT, T.REQUIS_AMOUNT), T.REQUIS_AMOUNT)), 0)
      INTO V_RESULT
      FROM T_CREDIT_DELAYPAY T
     WHERE T.ENTITY_ID = P_ENTITY_ID
       AND T.CUSTOMER_ID = P_CUSTOMER_ID
       AND T.BILL_STATUS IN ('1', '2', '3')
       AND T.DELAYPAY_TYPE = 3
       AND TRUNC(SYSDATE) BETWEEN T.REQUIS_DATE AND
           NVL(NVL(T.DUE_TIME, NVL(T.DELAY_DATE, T.END_DATE)), TRUNC(SYSDATE));
    RETURN V_RESULT;
  END;
  
  --------------------------------------------------------------------------------
  /*
  *   创建日期：2016-6-7
  *   创建者：tianmzh
  *   功能说明：获取起止日期内实际铺底金额
  */
  --------------------------------------------------------------------------------
  FUNCTION FUN_GET_DELAY_AMOUNT_BY_DATE(P_ENTITY_ID            NUMBER,
                                        P_CUSTOMER_ID          NUMBER,
                                        P_SALES_MAIN_TYPE_CODE VARCHAR2,
                                        P_BEGIN_DATE           VARCHAR2,
                                        P_END_DATE             VARCHAR2,
                                        IN_ACCOUNT_ID     NUMBER DEFAULT NULL --2017-5-2 增加账户ID参数，默认为空
                                        )
    RETURN NUMBER IS
    V_BEGIN_DATE DATE := TO_DATE(P_BEGIN_DATE, 'YYYYMMDD');
    V_END_DATE   DATE := TO_DATE(P_END_DATE, 'YYYYMMDD');
  
  BEGIN
    RETURN FUN_GET_DELAY_AMOUNT_BY_DATE(P_ENTITY_ID,
                                        P_CUSTOMER_ID,
                                        P_SALES_MAIN_TYPE_CODE,
                                        V_BEGIN_DATE,
                                        V_END_DATE,
                                        IN_ACCOUNT_ID);
  END FUN_GET_DELAY_AMOUNT_BY_DATE;

  --------------------------------------------------------------------------------
  /*
  *   创建日期：2016-8-23
  *   创建者：liangym2
  *   功能说明：获取起止日期内实际铺底金额
  */
  --------------------------------------------------------------------------------
  FUNCTION FUN_GET_DELAY_AMOUNT_BY_DATE(P_ENTITY_ID            NUMBER,
                                        P_CUSTOMER_ID          NUMBER,
                                        P_SALES_MAIN_TYPE_CODE VARCHAR2,
                                        P_BEGIN_DATE           DATE,
                                        P_END_DATE             DATE,
                                        IN_ACCOUNT_ID     NUMBER DEFAULT NULL --2017-5-2 增加账户ID参数，默认为空
                                        )
    RETURN NUMBER IS
    V_DELAY_AMOUNT T_CREDIT_DELAYPAY.APPROVAL_AMOUNT%TYPE := 0;
  
  BEGIN
    BEGIN
      SELECT NVL(SUM(T.APPROVAL_AMOUNT), 0)
        INTO V_DELAY_AMOUNT
        FROM CIMS.T_CREDIT_DELAYPAY T
       WHERE T.ENTITY_ID = P_ENTITY_ID
         AND T.CUSTOMER_ID = P_CUSTOMER_ID
         AND T.SALES_MAIN_TYPE = P_SALES_MAIN_TYPE_CODE
            --单据状态为：已审、强制到期
         AND T.BILL_STATUS IN (3, 6)
         AND T.BILL_TYPE_ID IN(1,2,4)--只包含常规铺底、超额铺底、循环铺底
         AND T.BILL_DATE BETWEEN P_BEGIN_DATE AND P_END_DATE
           --2017 5 2 梁颜明 增加账户ID
           AND (
           ((IN_ACCOUNT_ID IS NULL OR 0 >= IN_ACCOUNT_ID)-- AND (T.ACCOUNT_ID IS NULL OR 0 >= T.ACCOUNT_ID)
           --
           )
           OR (0 < IN_ACCOUNT_ID AND T.ACCOUNT_ID = IN_ACCOUNT_ID)
           )
         ;
    EXCEPTION
      WHEN OTHERS THEN
        V_DELAY_AMOUNT := 0;
    END;
    RETURN V_DELAY_AMOUNT;
  END FUN_GET_DELAY_AMOUNT_BY_DATE;

  /*add by LIANGYM2
  *传入起止日期，计算起止时间内的销售金额
  *用于信用额度计算
  *
  */
  FUNCTION FUN_GET_SALES_AMOUNT_BY_DATE(P_ENTITY_ID       NUMBER,
                                        P_CUSTOMER_ID     NUMBER,
                                        P_BEGIN_DATE      DATE,
                                        P_END_DATE        DATE,
                                        P_SALES_MAIN_TYPE VARCHAR2,
                                        IN_ACCOUNT_ID     NUMBER DEFAULT NULL --2017-5-2 增加账户ID参数，默认为空
                                        )
    RETURN NUMBER IS
    V_RESULT            NUMBER := 0;
    V_settle_amount     v_credit_contact_amount_so.settle_amount%TYPE := 0;
    V_settle_amount_old v_credit_contact_amount_so.settle_amount%TYPE := 0;
  
    V_BEGIN_MONTH DATE := TRUNC(P_BEGIN_DATE, 'MM');
    V_END_MONTH   DATE := TRUNC(P_END_DATE, 'MM');
   entityGroupCode Varchar2(100) ;
  
  Begin
    BEGIN
    --获取主体组编码
     entityGroupCode := pkg_bd.F_GET_PARAMETER_VALUE('ar_entity_group',P_ENTITY_ID,null,null);
    
      SELECT NVL(SUM(BILL_TYPE.PLUS_MINUS_FLAG * SO_HEADER.LIST_AMOUNT), 0)
        INTO V_settle_amount
        FROM T_SO_HEADER                SO_HEADER,
             T_CUSTOMER_HEADER          CUS_HEADER,
             T_CUSTOMER_SALES_MAIN_TYPE CUS_MAIN_TYPE,
             V_SO_BILL_TYPE_EXTEND      BILL_TYPE
       WHERE SO_HEADER.CUSTOMER_ID = CUS_HEADER.CUSTOMER_ID
         AND CUS_HEADER.CUSTOMER_ID = CUS_MAIN_TYPE.CUSTOM_ID
         AND SO_HEADER.SALES_MAIN_TYPE = CUS_MAIN_TYPE.SALES_MAIN_TYPE_CODE
         AND SO_HEADER.ENTITY_ID = CUS_MAIN_TYPE.ENTITY_ID
         AND SO_HEADER.BILL_TYPE_ID = BILL_TYPE.BILL_TYPE_ID(+)
         AND SO_HEADER.CUSTOMER_ID = P_CUSTOMER_ID
         AND SO_HEADER.SO_DATE BETWEEN P_BEGIN_DATE AND P_END_DATE
         AND SO_HEADER.BIZ_SRC_BILL_TYPE_CODE IN
             ('1001', '1002', '1003', '1004')
         AND SO_HEADER.ENTITY_ID = P_ENTITY_ID
         AND SO_HEADER.SALES_MAIN_TYPE = P_SALES_MAIN_TYPE
           --2017 5 2 梁颜明 增加账户ID
           AND (
           ((IN_ACCOUNT_ID IS NULL OR 0 >= IN_ACCOUNT_ID)-- AND (SO_HEADER.ACCOUNT_ID IS NULL OR 0 >= SO_HEADER.ACCOUNT_ID)
           --
           )
           OR (0 < IN_ACCOUNT_ID AND SO_HEADER.ACCOUNT_ID = IN_ACCOUNT_ID)
           )
         ;
    EXCEPTION
      WHEN OTHERS THEN
        V_settle_amount := 0;
    END;
  
    BEGIN
      --2017-9-20优先取列表金额，空的话再取结算金额
      SELECT nvl(SUM(NVL(T.LIST_AMOUNT,T.AMOUNT)), 0)
        INTO V_settle_amount_old
        FROM T_POL_SALES_DATA T
       WHERE T.customer_id = P_CUSTOMER_ID
         AND T.entity_id = P_ENTITY_ID
         AND TO_DATE(T.SALES_MONTH, 'YYYYMM') >= V_BEGIN_MONTH
         AND TO_DATE(T.SALES_MONTH, 'YYYYMM') <= V_END_MONTH
         And t.stat_caliber = DECODE(entityGroupCode,'XSGS','按结算日期','JXS','按单据日期')
         --T_BD_ITEM A
         AND t.Sales_Main_Type = P_SALES_MAIN_TYPE
           --2017 5 2 梁颜明 增加账户ID
           AND (
           ((IN_ACCOUNT_ID IS NULL OR 0 >= IN_ACCOUNT_ID)-- AND (T.ACCOUNT_ID IS NULL OR 0 >= T.ACCOUNT_ID)
           --
           )
           OR (0 < IN_ACCOUNT_ID AND T.ACCOUNT_ID = IN_ACCOUNT_ID)
           )
         ;
    
    EXCEPTION
      WHEN OTHERS THEN
        V_settle_amount_old := 0;
    END;
    V_RESULT := ROUND(V_settle_amount + V_settle_amount_old, 2);
    --V_RESULT := 3095001432.4 ; 3.0950014324E9
    RETURN V_RESULT;
  END FUN_GET_SALES_AMOUNT_BY_DATE; 
  
  --------------------------------------------------------------------------------
  /*
  *   创建日期：2016-6-7
  *   创建者：tianmzh
  *   功能说明：获取起止日期内账户维度，销售金额
  */
  --------------------------------------------------------------------------------
  FUNCTION FUN_GET_SALES_AMOUNT_BY_ACC(P_ENTITY_ID   NUMBER,
                                       P_CUSTOMER_ID NUMBER,
                                       P_BEGIN_DATE  VARCHAR2,
                                       P_END_DATE    VARCHAR2,
                                       P_ACCOUNT_ID  NUMBER) RETURN NUMBER IS
    V_RESULT            NUMBER := 0;
    V_SETTLE_AMOUNT     V_CREDIT_CONTACT_AMOUNT_SO.SETTLE_AMOUNT%TYPE := 0;
    V_SETTLE_AMOUNT_OLD V_CREDIT_CONTACT_AMOUNT_SO.SETTLE_AMOUNT%TYPE := 0;
  
    V_BEGIN_DATE  DATE := TO_DATE(P_BEGIN_DATE, 'YYYYMMDD');
    V_END_DATE    DATE := TO_DATE(P_END_DATE, 'YYYYMMDD');
    V_BEGIN_MONTH DATE := TRUNC(TO_DATE(P_BEGIN_DATE, 'YYYYMMDD'), 'MM');
    V_END_MONTH   DATE := TRUNC(TO_DATE(P_END_DATE, 'YYYYMMDD'), 'MM');
   entityGroupCode Varchar2(100) ;
  
  BEGIN
    --获取主体组编码
     entityGroupCode := pkg_bd.F_GET_PARAMETER_VALUE('ar_entity_group',P_ENTITY_ID,null,null);
     
    BEGIN
      SELECT NVL(SUM(D.LIST_AMOUNT), 0)
        INTO V_SETTLE_AMOUNT
        FROM V_CREDIT_CONTACT_AMOUNT_SO D
       WHERE D.CUSTOMER_ID = P_CUSTOMER_ID
         AND D.BILL_DATE BETWEEN V_BEGIN_DATE AND V_END_DATE
         AND D.BIZ_SRC_BILL_TYPE_CODE IN ('1001', '1002', '1003', '1004')
         AND D.ENTITY_ID = P_ENTITY_ID
         AND D.ACCOUNT_ID = P_ACCOUNT_ID;
    EXCEPTION
      WHEN OTHERS THEN
        V_SETTLE_AMOUNT := 0;
    END;
  
    BEGIN
      --2017-9-20优先取列表金额，空的话再取结算金额
      SELECT NVL(SUM(NVL(T.LIST_AMOUNT,0)), 0)
        INTO V_SETTLE_AMOUNT_OLD
        FROM T_POL_SALES_DATA T
       WHERE T.CUSTOMER_ID = P_CUSTOMER_ID
         AND T.ENTITY_ID = P_ENTITY_ID
         AND TO_DATE(T.SALES_MONTH, 'YYYYMM') >= V_BEGIN_MONTH
         AND TO_DATE(T.SALES_MONTH, 'YYYYMM') <= V_END_MONTH
         AND T.STAT_CALIBER = DECODE(entityGroupCode,'XSGS','按结算日期','JXS','按单据日期')
         AND T.ACCOUNT_ID = P_ACCOUNT_ID;
    
    EXCEPTION
      WHEN OTHERS THEN
        V_SETTLE_AMOUNT_OLD := 0;
    END;
    V_RESULT := ROUND(V_SETTLE_AMOUNT + V_SETTLE_AMOUNT_OLD, 2);
    RETURN V_RESULT;
  END;
  
  --------------------------------------------------------------------------------
  /*
  *   创建日期：2017-6-7
  *     创建者：梁颜明
  *   功能说明：根据客户ID，营销大类编码，系统参数值，获取所对应的额度组
  * CREDIT_USE_DEFAULT_GROUP:
  * A 按之前额度组关系获取额度组 如果是销司 配置成A 只会默认额度组
  * Y 只会获取到默认额度组
  * N 只会获取到非默认额度组
  *   返回结果：额度组ID
  *
  */
  -------------------------------------------------------------------------------
  FUNCTION F_GET_CREDITGROUPID_BY_PARAM(IN_ENTITY_ID       Number,
                                 IN_CUSTOMER_ID     NUMBER,
                                 IS_SALES_MAIN_TYPE varchar2,
                                 IS_PARAM_VALUE    VARCHAR2
                                 ) RETURN NUMBER IS
    V_CREDIT_GROUP_ID NUMBER := 0;
    V_COUNT           NUMBER := 0;
  BEGIN
    IF IS_PARAM_VALUE IS NULL OR 'NULL' = UPPER(IS_PARAM_VALUE) OR 'A' = IS_PARAM_VALUE THEN
      --如果参数值为空 或者 等于 A，按之前方式取额度组
      
   --1、根据营销大类ID，客户ID，获取额度组。检查是否是特殊额度组。
    BEGIN
      SELECT nvl(C.CREDIT_GROUP_ID, -1)
        INTO V_CREDIT_GROUP_ID
        FROM T_CREDIT_GROUP_CUST         A,
             T_CREDIT_CATEGORY_GROUP_REL B,
             T_CREDIT_GROUP              C
       WHERE B.CREDIT_GROUP_ID = A.CREDIT_GROUP_ID
         AND B.CREDIT_GROUP_ID = C.CREDIT_GROUP_ID
         AND A.CUSTOMER_ID = IN_CUSTOMER_ID
         AND B.SALES_MAIN_TYPE = IS_SALES_MAIN_TYPE
         And C.ENTITY_ID = IN_ENTITY_ID ;
    EXCEPTION WHEN NO_DATA_FOUND THEN
       --该客户该大类没有存在特殊额度组中，检查该客户是否有其他大类存在特殊额度组
       SELECT COUNT(1)
         INTO V_COUNT
         FROM T_CREDIT_GROUP_CUST         A,
              T_CREDIT_CATEGORY_GROUP_REL B,
              T_CREDIT_GROUP              C
        WHERE B.CREDIT_GROUP_ID = A.CREDIT_GROUP_ID
          AND B.CREDIT_GROUP_ID = C.CREDIT_GROUP_ID
          AND A.CUSTOMER_ID = IN_CUSTOMER_ID
          And C.ENTITY_ID = IN_ENTITY_ID ;
          --V_COUNT>0,该客户有其他大类存在特殊额度组
          IF V_COUNT > 0 THEN
            V_CREDIT_GROUP_ID := -2 ;
          END IF ;
    WHEN OTHERS THEN
       V_CREDIT_GROUP_ID := -1 ;
    END ;
    --2、该客户不存在任何营销大类在特殊额度组中，所以查询普通额度组。
    IF V_CREDIT_GROUP_ID = 0 THEN
        BEGIN
           SELECT nvl(B.CREDIT_GROUP_ID, -1)
             INTO V_CREDIT_GROUP_ID
             FROM T_CREDIT_CATEGORY_GROUP_REL A, T_CREDIT_GROUP B
            WHERE A.CREDIT_GROUP_ID = B.CREDIT_GROUP_ID
              AND A.SALES_MAIN_TYPE = IS_SALES_MAIN_TYPE
              And B.ENTITY_ID = IN_ENTITY_ID
              AND (B.DEFAULT_FLAG IS NULL OR B.DEFAULT_FLAG = '1');
        EXCEPTION WHEN OTHERS THEN
          V_CREDIT_GROUP_ID := -1 ;
        END;
     END IF ;
    --2017-4-20 根据系统参数CREDIT_USE_DEFAULT_GROUP 获取额度组
    ELSIF 'Y' = IS_PARAM_VALUE THEN
      --参数值等于Y 取默认额度组
      BEGIN
           SELECT nvl(B.CREDIT_GROUP_ID, -1)
             INTO V_CREDIT_GROUP_ID
             FROM T_CREDIT_CATEGORY_GROUP_REL A, T_CREDIT_GROUP B
            WHERE A.CREDIT_GROUP_ID = B.CREDIT_GROUP_ID
              AND A.SALES_MAIN_TYPE = IS_SALES_MAIN_TYPE
              And B.ENTITY_ID = IN_ENTITY_ID
              AND (B.DEFAULT_FLAG IS NULL OR B.DEFAULT_FLAG = '1');
        EXCEPTION WHEN OTHERS THEN
          V_CREDIT_GROUP_ID := -1 ;
        END;
    ELSIF 'N' = IS_PARAM_VALUE THEN
      --参数值等于N 取非默认额度组
      BEGIN
           SELECT nvl(B.CREDIT_GROUP_ID, -1)
             INTO V_CREDIT_GROUP_ID
             FROM T_CREDIT_CATEGORY_GROUP_REL A, T_CREDIT_GROUP B
            WHERE A.CREDIT_GROUP_ID = B.CREDIT_GROUP_ID
              AND A.SALES_MAIN_TYPE = IS_SALES_MAIN_TYPE
              And B.ENTITY_ID = IN_ENTITY_ID
              AND B.DEFAULT_FLAG = '2';
        EXCEPTION WHEN OTHERS THEN
          V_CREDIT_GROUP_ID := -1 ;
        END;
    END IF;
    RETURN V_CREDIT_GROUP_ID ;
  END F_GET_CREDITGROUPID_BY_PARAM;

  --取系统参数值(按范围取旧值表)
  function F_GET_OLD_PARAM_VALUE
  (
   P_CONFIG_CODE    t_bd_param_list.param_code%type,  --参数配置编码
   P_ENTITY_ID      up_org_unit.ENTITY_ID%type, --业务主体ID
   P_UNIT_ID        up_org_unit.Unit_Id%type default null, --中心ID
   P_CUSTOMER_ID    t_customer_header.customer_id%type default null, --客户ID, --中心ID
   IN_SCOPE         number default 0 --取旧值表范围，0取中心、客户旧值表
   ) --
   return varchar2 is

    LS_PARAM_VALUE t_bd_param_list.default_value%type;
    paramList t_bd_param_list%ROWTYPE ;
    paramEntity t_bd_param_entity%ROWTYPE ;
    entityDetail T_BD_PARAM_ENTITY_OLD_DETAIL%ROWTYPE ;
    LSE_NUM number;--记录是否查询到系统参数

  begin
    select count(0) into LSE_NUM from t_bd_param_list pl where pl.param_code=P_CONFIG_CODE and pl.active_flag='Y';

    if LSE_NUM = 0 then
        RAISE_APPLICATION_ERROR(-20001, '编码为'||P_CONFIG_CODE||'的系统参数没找到');
    end if;

    select pl.* into paramList from t_bd_param_list pl where pl.param_code=P_CONFIG_CODE and pl.active_flag='Y';

    --1、如果与主体无关，取默认值
    if (paramList.Entity_Flag is null or paramList.Entity_Flag = 'N') then
      LS_PARAM_VALUE := paramList.Default_Value;
      return LS_PARAM_VALUE;
    end if;

    --2、如果与主体相关，但与中心客户无关，取主体参数值
    begin
      select pe.* into paramEntity from t_bd_param_entity pe
         where pe.param_list_id=paramList.Param_List_Id
            and pe.entity_id = P_ENTITY_ID
            and pe.active_flag='Y';
      if (paramEntity.Org_Cust_Flag is null or paramEntity.Org_Cust_Flag = 'N') then
        LS_PARAM_VALUE := paramEntity.Entity_Value;
        return LS_PARAM_VALUE;
      end if;
    exception
        when NO_DATA_FOUND then
        LS_PARAM_VALUE := paramList.Default_Value;
        return LS_PARAM_VALUE;
    end;

    --3、如果与主体相关，且与中心客户有关，取中心客户参数值
    --3.1 如果参数中既传了中心，又传了客户
    if (P_UNIT_ID is not null and P_CUSTOMER_ID is not null) then

      begin
        select ed.* into entityDetail from T_BD_PARAM_ENTITY_OLD_DETAIL ed
           where ed.param_entity_id=paramEntity.Param_Entity_Id
              and ed.entity_id =  P_ENTITY_ID
              and ed.sales_center_id = P_UNIT_ID
              and ed.customer_id = P_CUSTOMER_ID
              and ed.active_flag = 'Y';
      exception
        when NO_DATA_FOUND then
        --3.1.1 如果没找到，则找中心的配置
        BEGIN
          select ed.* into entityDetail from T_BD_PARAM_ENTITY_OLD_DETAIL ed
             where ed.param_entity_id=paramEntity.Param_Entity_Id
                and ed.entity_id =  P_ENTITY_ID
                and ed.sales_center_id = P_UNIT_ID
                and (ed.customer_id is null or ed.customer_id <= 0)
                and ed.active_flag = 'Y';
        EXCEPTION WHEN NO_DATA_FOUND THEN
           LS_PARAM_VALUE := paramEntity.Entity_Value;
           return LS_PARAM_VALUE;
        END ;
      end;
      LS_PARAM_VALUE := entityDetail.Param_Value;

    else
    --3.2 如果参数中只传了中心
      BEGIN
        select ed.* into entityDetail from T_BD_PARAM_ENTITY_OLD_DETAIL ed
           where ed.param_entity_id=paramEntity.Param_Entity_Id
              and ed.entity_id =  P_ENTITY_ID
              and ed.sales_center_id = P_UNIT_ID
              and ed.active_flag = 'Y'
              and (ed.customer_id is null or ed.customer_id <= 0);
        LS_PARAM_VALUE := entityDetail.Param_Value;
      EXCEPTION WHEN NO_DATA_FOUND THEN
        LS_PARAM_VALUE := paramEntity.Entity_Value;
        return LS_PARAM_VALUE;
      END;
    end if;

    return LS_PARAM_VALUE;

/*    exception
       when others then
        LS_PARAM_VALUE := 'error';
  */
  END F_GET_OLD_PARAM_VALUE;
  
  --取系统参数值(找不到就返回主体系统参数)
  function F_GET_PARAM_VALUE_ENTITY_PRIOR(P_CONFIG_CODE t_bd_param_list.param_code%type, --参数配置编码
                                          P_ENTITY_ID   up_org_unit.ENTITY_ID%type, --业务主体ID
                                          P_UNIT_ID     up_org_unit.Unit_Id%type default null, --中心ID
                                          P_CUSTOMER_ID t_customer_header.customer_id%type default null --客户ID
                                          ) --
   return varchar2 is

    LS_PARAM_VALUE t_bd_param_list.default_value%type;
    paramList      t_bd_param_list%ROWTYPE;
    paramEntity    t_bd_param_entity%ROWTYPE;
    entityDetail   t_bd_param_entity_detail%ROWTYPE;
    LSE_NUM        number; --记录是否查询到系统参数

  begin
    select count(0)
      into LSE_NUM
      from t_bd_param_list pl
     where pl.param_code = P_CONFIG_CODE
       and pl.active_flag = 'Y';

    if LSE_NUM = 0 then
      RAISE_APPLICATION_ERROR(-20001,
                              '编码为' || P_CONFIG_CODE || '的系统参数没找到');
    end if;

    select pl.*
      into paramList
      from t_bd_param_list pl
     where pl.param_code = P_CONFIG_CODE
       and pl.active_flag = 'Y';

    --1、如果与主体无关，取默认值
    if (paramList.Entity_Flag is null or paramList.Entity_Flag = 'N') then
      LS_PARAM_VALUE := paramList.Default_Value;
      return LS_PARAM_VALUE;
    end if;

    --2、如果与主体相关，但与中心客户无关，取主体参数值
    begin
      select pe.*
        into paramEntity
        from t_bd_param_entity pe
       where pe.param_list_id = paramList.Param_List_Id
         and pe.entity_id = P_ENTITY_ID
         and pe.active_flag = 'Y';
      if (paramEntity.Org_Cust_Flag is null or
         paramEntity.Org_Cust_Flag = 'N') then
        LS_PARAM_VALUE := paramEntity.Entity_Value;
        return LS_PARAM_VALUE;
      end if;
    exception
      when NO_DATA_FOUND then
        LS_PARAM_VALUE := paramList.Default_Value;
        return LS_PARAM_VALUE;
    end;

    --3、如果与主体相关，且与中心客户有关，取中心客户参数值
    --3.1 如果参数中既传了中心，又传了客户
    if (P_UNIT_ID is not null and P_CUSTOMER_ID is not null) then
    
      begin
        select ed.*
          into entityDetail
          from t_bd_param_entity_detail ed
         where ed.param_entity_id = paramEntity.Param_Entity_Id
           and ed.entity_id = P_ENTITY_ID
           and ed.sales_center_id = P_UNIT_ID
           and ed.customer_id = P_CUSTOMER_ID
           and ed.active_flag = 'Y';
      exception
        when NO_DATA_FOUND then
          --3.1.1 如果没找到，则找中心的配置
          BEGIN
            select ed.*
              into entityDetail
              from t_bd_param_entity_detail ed
             where ed.param_entity_id = paramEntity.Param_Entity_Id
               and ed.entity_id = P_ENTITY_ID
               and ed.sales_center_id = P_UNIT_ID
               and (ed.customer_id is null or ed.customer_id <= 0)
               and ed.active_flag = 'Y';
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              LS_PARAM_VALUE := paramEntity.Entity_Value;
              return LS_PARAM_VALUE;
          END;
      end;
      LS_PARAM_VALUE := entityDetail.Param_Value;
    
    else
      --3.2 如果参数中只传了中心
      BEGIN
        select ed.*
          into entityDetail
          from t_bd_param_entity_detail ed
         where ed.param_entity_id = paramEntity.Param_Entity_Id
           and ed.entity_id = P_ENTITY_ID
           and ed.sales_center_id = P_UNIT_ID
           and ed.active_flag = 'Y'
           and (ed.customer_id is null or ed.customer_id <= 0);
        LS_PARAM_VALUE := entityDetail.Param_Value;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          LS_PARAM_VALUE := paramEntity.Entity_Value;
          return LS_PARAM_VALUE;
      END;
    end if;

    return LS_PARAM_VALUE;

    /*    exception
         when others then
          LS_PARAM_VALUE := 'error';
    */
  END F_GET_PARAM_VALUE_ENTITY_PRIOR;
  
  FUNCTION F_GET_SALES_ACCOUNT_AMOUNT(IN_ENTITY_ID       NUMBER,
                                      IN_CUSTOMER_ID     NUMBER,
                                      IN_ACCOUNT_ID      NUMBER,
                                      IN_CREDIT_GROUP_ID NUMBER,
                                      IS_SALES_MAIN_TYPE   VARCHAR2,
                                      IS_DISCOUNT_TYPE   VARCHAR2) RETURN TAB_SALES_DIS_AMOUNT_FREEZE
    PIPELINED AS
    V_CUSTOMER_AMOUNT_ROW OBJ_SALES_DIS_AMOUNT_FREEZE;
    V_CUSTOMER_DIS_AMOUNT_ROW OBJ_SALES_DIS_AMOUNT_FREEZE;
  
    CURSOR C_CUSTOMER_AMOUNT IS
    SELECT A.*,ACC.ACCOUNT_STATUS,ACC.ACCOUNT_STATUS AS ACCOUNT_STATUS_CNAME
    ,CO.SALES_CENTER_ID,CO.SALES_CENTER_CODE,CO.SALES_CENTER_NAME FROM T_SALES_ACCOUNT_AMOUNT A
    INNER JOIN T_CUSTOMER_ACCOUNT ACC ON (ACC.ACCOUNT_ID = A.ACCOUNT_ID)
    INNER JOIN T_CUSTOMER_ACC_ORG_RELATION AR ON (AR.ACCOUNT_ID = A.ACCOUNT_ID)
    INNER JOIN T_CUSTOMER_ORG CO ON (CO.CUSTOMER_ORG_ID = AR.CUSTOMER_ORG_ID)
    WHERE A.ENTITY_ID = IN_ENTITY_ID
    AND A.CUSTOMER_ID = IN_CUSTOMER_ID
    AND A.ACCOUNT_ID = IN_ACCOUNT_ID
    AND A.CREDIT_GROUP_ID = IN_CREDIT_GROUP_ID
    ;
    
    VR_CREDIT_GROUP T_CREDIT_GROUP%ROWTYPE;
    CURSOR C_CUSTOMER_AMOUNT_MX IS
    SELECT A.*,A.ACCOUNT_AMOUNT_MX_ID AS ACCOUNT_AMOUNT_ID,ACC.ACCOUNT_STATUS,ACC.ACCOUNT_STATUS AS ACCOUNT_STATUS_CNAME
    ,CO.SALES_CENTER_ID,CO.SALES_CENTER_CODE,CO.SALES_CENTER_NAME FROM T_SALES_ACCOUNT_MX_AMOUNT A
    INNER JOIN T_CUSTOMER_ACCOUNT ACC ON (ACC.ACCOUNT_ID = A.ACCOUNT_ID)
    INNER JOIN T_CUSTOMER_ACC_ORG_RELATION AR ON (AR.ACCOUNT_ID = A.ACCOUNT_ID)
    INNER JOIN T_CUSTOMER_ORG CO ON (CO.CUSTOMER_ORG_ID = AR.CUSTOMER_ORG_ID)
    WHERE A.ENTITY_ID = IN_ENTITY_ID
    AND A.CUSTOMER_ID = IN_CUSTOMER_ID
    AND A.ACCOUNT_ID = IN_ACCOUNT_ID
    AND A.SALES_MAIN_TYPE = IS_SALES_MAIN_TYPE
    ;
    --TYPE_CUR SYS_REFCURSOR;
    R_CUSTOMER_AMOUNT C_CUSTOMER_AMOUNT%ROWTYPE;

    V_RECEIVED_AMOUNT         T_SALES_ACCOUNT_MX_AMOUNT.RECEIVED_AMOUNT%TYPE := 0 ;             --到款金额
    V_RECEIVED_AMOUNT_FREEZE  T_SALES_ACCOUNT_MX_AMOUNT.RECEIVED_AMOUNT%TYPE := 0 ;             --到款金额 冻结金额
    V_SALES_AMOUNT            T_SALES_ACCOUNT_MX_AMOUNT.SALES_AMOUNT%TYPE := 0 ;                --销售金额
    V_SALES_AMOUNT_FREEZE     T_SALES_ACCOUNT_MX_AMOUNT.SALES_AMOUNT%TYPE := 0 ;                --销售金额  冻结金额
    V_LOCK_RECEIVED_AMOUNT    T_SALES_ACCOUNT_MX_AMOUNT.LOCK_RECEIVED_AMOUNT%TYPE := 0 ;        --锁定到款金额
    V_DELAYPAY_AMOUNT         T_SALES_ACCOUNT_MX_AMOUNT.DELAYPAY_AMOUNT%TYPE := 0 ;             --铺底金额
    V_TEMP_DELAYPAY_AMOUNT    T_SALES_ACCOUNT_MX_AMOUNT.TEMP_DELAYPAY_AMOUNT%TYPE := 0 ;        --临时铺底金额
    V_DISCOUNT_AMOUNT         T_SALES_ACCOUNT_MX_AMOUNT.DISCOUNT_AMOUNT%TYPE := 0 ;             --折让金额
    V_APPLIED_DISCOUNT_AMOUNT T_SALES_ACCOUNT_MX_AMOUNT.APPLIED_DISCOUNT_AMOUNT%TYPE := 0 ;     --核销折让金额
    V_FREEZE_DISCOUNT_AMOUNT  T_SALES_ACCOUNT_MX_AMOUNT.FREEZE_DISCOUNT_AMOUNT%TYPE := 0 ;      --冻结折让金额
    V_LOCK_DISCOUNT_AMOUNT    T_SALES_ACCOUNT_MX_AMOUNT.LOCK_DISCOUNT_AMOUNT%TYPE := 0 ;        --锁定折让金额
    V_DISPAY_AMOUNT           T_SALES_ACCOUNT_MX_AMOUNT.DISPAY_AMOUNT%TYPE := 0 ;               --未解付金额
    V_THREE_NOT_PAY           T_SALES_ACCOUNT_MX_AMOUNT.THREE_NOT_PAY%TYPE := 0 ;               --三方承兑未解付金额
    --ADD BY 苏冬渊 2015-08-26
    V_RESOURCE_AMOUNT         T_SALES_ACCOUNT_MX_AMOUNT.RESOURCE_AMOUNT%Type := 0 ;
    V_LOCK_RESOURCE_AMOUNT    T_SALES_ACCOUNT_MX_AMOUNT.Lock_Resource_Amount%Type := 0 ;
    V_TRANSACTION_AMOUNT      T_SALES_ACCOUNT_MX_AMOUNT.TRANSACTION_AMOUNT%Type := 0 ;

    /*V_LOCK_RECEIVED_AMOUNT_FHCX    T_SALES_ACCOUNT_MX_AMOUNT.LOCK_RECEIVED_AMOUNT%TYPE := 0 ;        --发货通知单撤销的金额
    V_LOCK_DISCOUNT_AMOUNT_FHCX    T_SALES_ACCOUNT_MX_AMOUNT.LOCK_DISCOUNT_AMOUNT%TYPE := 0 ;        --发货通知单撤销的折让金额*/

    V_LOCK_RECEIVED_AMOUNT_SHIP    T_SALES_ACCOUNT_MX_AMOUNT.LOCK_RECEIVED_AMOUNT%TYPE := 0 ;        --发运计划未下达锁定的金额
    V_LOCK_DISCOUNT_AMOUNT_SHIP    T_SALES_ACCOUNT_MX_AMOUNT.LOCK_DISCOUNT_AMOUNT%TYPE := 0 ;        --发运计划未下达锁定的折扣
    V_LOCK_RECEIVED_AMOUNT_DOC    T_SALES_ACCOUNT_MX_AMOUNT.LOCK_RECEIVED_AMOUNT%TYPE := 0 ;        --发货通知单未生成财务单的索款
    V_LOCK_DISCOUNT_AMOUNT_DOC    T_SALES_ACCOUNT_MX_AMOUNT.LOCK_DISCOUNT_AMOUNT%TYPE := 0 ;        --发货通知单未生成财务单的折扣

    --add by 苏冬渊 2015-08-26
    V_LOCK_RESOURCE_AMOUNT_SHIP  T_SALES_ACCOUNT_MX_AMOUNT.Lock_Resource_Amount%TYPE := 0 ;  --发运计划未下达锁定的资源
    V_LOCK_RESOURCE_AMOUNT_DOC   T_SALES_ACCOUNT_MX_AMOUNT.Lock_Resource_Amount%TYPE := 0 ;  --发运通知单未生成财务单锁定的资源

    V_LOCK_RESOURCE_AMOUNT_SS    T_SALES_ACCOUNT_MX_AMOUNT.Lock_Resource_Amount%TYPE := 0 ;  --送审锁款方式下未评审造成锁定资源
    V_LOCK_RECEIVED_AMOUNT_SS    T_SALES_ACCOUNT_MX_AMOUNT.Lock_Received_Amount%TYPE := 0 ;  --送审锁款方式下未评审造成锁定到款
    V_LOCK_DISCOUNT_AMOUNT_SS    T_SALES_ACCOUNT_MX_AMOUNT.LOCK_DISCOUNT_AMOUNT%TYPE := 0 ;  --送审锁款方式下未评审造成锁定折扣

    --ADD BY LIZHEN 2015-12-07 计划订单送锁款金额
    V_LOCK_RESOURCE_AMOUNT_PLN   T_SALES_ACCOUNT_MX_AMOUNT.Lock_Resource_Amount%TYPE := 0 ;  --送审锁款方式下未评审造成锁定资源
    V_LOCK_RECEIVED_AMOUNT_PLN   T_SALES_ACCOUNT_MX_AMOUNT.Lock_Received_Amount%TYPE := 0 ;  --送审锁款方式下未评审造成锁定到款
    V_LOCK_DISCOUNT_AMOUNT_PLN   T_SALES_ACCOUNT_MX_AMOUNT.LOCK_DISCOUNT_AMOUNT%TYPE := 0 ;  --送审锁款方式下未评审造成锁定折扣
    
    V_LOCK_RECEIVED_AMOUNT_PLN_DP   T_SALES_ACCOUNT_MX_AMOUNT.Lock_Received_Amount%TYPE := 0 ;  --计划订单送审锁款方式下未评审造成锁定订金
    V_LOCK_DISCOUNT_AMOUNT_PLN_DP   T_SALES_ACCOUNT_MX_AMOUNT.LOCK_DISCOUNT_AMOUNT%TYPE := 0 ;  --计划订单送审锁款方式下未评审造成锁定折扣订金
    
    V_LOCK_RECEIVED_AMOUNT_SS_DP T_SALES_ACCOUNT_MX_AMOUNT.Lock_Received_Amount%TYPE := 0 ;  --送审锁款方式下未评审造成锁定订金
    --add by liangym2 2017-7-17
    V_LOCK_DISCOUNT_AMOUNT_SS_DP T_SALES_ACCOUNT_MX_AMOUNT.LOCK_DISCOUNT_AMOUNT%TYPE := 0 ;  --送审锁款方式下未评审造成锁定折扣订金
    --add by liangym2 2017-7-19
    V_LOCK_RECEIVED_AMOUNT_T_SHIP T_SALES_ACCOUNT_MX_AMOUNT.LOCK_RECEIVED_AMOUNT%TYPE := 0 ;  --制定发货需求计划下达（直发客户） 锁款 未发货
    V_LOCK_DISCOUNT_AMOUNT_T_SHIP T_SALES_ACCOUNT_MX_AMOUNT.LOCK_DISCOUNT_AMOUNT%TYPE := 0 ;  --制定发货需求计划下达（直发客户） 折扣锁款 未发货
    V_LOCK_RECEIVED_AMOUNT_T_DOC T_SALES_ACCOUNT_MX_AMOUNT.LOCK_RECEIVED_AMOUNT%TYPE := 0 ;  --制定发货需求计划下达（直发客户） 锁款 发货未确认
    V_LOCK_DISCOUNT_AMOUNT_T_DOC T_SALES_ACCOUNT_MX_AMOUNT.LOCK_DISCOUNT_AMOUNT%TYPE := 0 ;  --制定发货需求计划下达（直发客户） 折扣锁款 发货未确认
    V_FREEZE_DELAY_AMOUNT  T_SALES_ACCOUNT_MX_AMOUNT.FREEZE_DELAY_AMOUNT%TYPE := 0 ;      --冻结铺底金额、冻结保证金 2017-10-11 梁颜明
    VS_ACCOUNT_STATUS_CNAME VARCHAR2(100);
    VS_ACCOUNT_CODE         T_CUSTOMER_ACCOUNT.ACCOUNT_CODE%TYPE;
    
    VN_SHIP_LOCK_AMOUNT_TRANSFER NUMBER; --直发代理商发货计划锁款
    VN_DOC_LOCK_AMOUNT_TRANSFER  NUMBER; --直发代理商发货通知单锁款
    VN_SHIP_LOCK_AMOUNT          NUMBER; --常规发货计划锁款
    VN_DOC_LOCK_AMOUNT           NUMBER; --常规发货通知单锁款
    VN_PLN_LOCK_AMOUNT           NUMBER; --送审锁款方式已经送审未生成发货计划的锁款，全款部分
    VN_PLN_DP_LOCK_AMOUNT        NUMBER; --送审锁款方式已经送审未生成发货计划的锁款，订金部分
    VN_LOCK_AMOUNT               NUMBER;
    --VN_REC_LOCK_AMOUNT           NUMBER;
    
    V_LOCK_RECEIVED_AMOUNT_PS    T_SALES_ACCOUNT_MX_AMOUNT.Lock_Received_Amount%TYPE := 0 ;  --针对已结转总部主体且发货锁款的提货订单重算锁款 锁定到款
    V_LOCK_DISCOUNT_AMOUNT_PS    T_SALES_ACCOUNT_MX_AMOUNT.LOCK_DISCOUNT_AMOUNT%TYPE := 0 ;  --针对已结转总部主体且发货锁款的提货订单重算锁款 锁定折扣
    VN_PLN_LOCK_AMOUNT_PS           NUMBER; --针对已结转总部主体且发货锁款的提货订单重算锁款
    
    VN_PLN_LOCK_AMOUNT_HQ T_SALES_ACCOUNT_MX_AMOUNT.LOCK_RECEIVED_AMOUNT%TYPE := 0;
    VN_PLN_DP_LOCK_AMOUNT_HQ T_SALES_ACCOUNT_MX_AMOUNT.LOCK_RECEIVED_AMOUNT%TYPE := 0;
    
    V_LOCK_RECEIVED_AMOUNT_HQ T_SALES_ACCOUNT_MX_AMOUNT.LOCK_RECEIVED_AMOUNT%TYPE := 0;
    V_LOCK_DISCOUNT_AMOUNT_HQ T_SALES_ACCOUNT_MX_AMOUNT.LOCK_DISCOUNT_AMOUNT%TYPE := 0;
    V_LOCK_RESOURCE_AMOUNT_HQ T_SALES_ACCOUNT_MX_AMOUNT.LOCK_RESOURCE_AMOUNT%TYPE := 0;
    V_LOCK_RECEIVED_AMOUNT_HQ_DP T_SALES_ACCOUNT_MX_AMOUNT.LOCK_RECEIVED_AMOUNT%TYPE := 0;
    V_LOCK_DISCOUNT_AMOUNT_HQ_DP T_SALES_ACCOUNT_MX_AMOUNT.LOCK_DISCOUNT_AMOUNT%TYPE := 0;
    
    V_LOCK_RECEIVED_AMOUNT_NEW T_SALES_ACCOUNT_MX_AMOUNT.LOCK_RECEIVED_AMOUNT%TYPE := 0;
    V_LOCK_DISCOUNT_AMOUNT_NEW T_SALES_ACCOUNT_MX_AMOUNT.LOCK_DISCOUNT_AMOUNT%TYPE := 0;
    V_LOCK_RESOURCE_AMOUNT_NEW T_SALES_ACCOUNT_MX_AMOUNT.LOCK_RESOURCE_AMOUNT%TYPE := 0;
    V_LOCK_RECEIVED_AMOUNT_NEW_DP T_SALES_ACCOUNT_MX_AMOUNT.LOCK_RECEIVED_AMOUNT%TYPE := 0;
    V_LOCK_DISCOUNT_AMOUNT_NEW_DP T_SALES_ACCOUNT_MX_AMOUNT.LOCK_DISCOUNT_AMOUNT%TYPE := 0;
    
    CURSOR CUR_SO_DIS(P_ENTITY_ID   NUMBER,
                      P_CUSTOMER_ID NUMBER,
                      P_ACCOUNT_ID  NUMBER,
                      P_CREDIT_GROUP_ID NUMBER,
                      P_SALES_MAIN_TYPE VARCHAR2,
                      P_DISCOUNT_TYPE   VARCHAR2) IS
      SELECT t.entity_id,
             t.customer_id,
             t.account_id,
             --t.sales_main_type,
             2 as amount_type,
             --T.discount_type,
             sum(NVL(t.settle_amount,0)) as settle_amount
             ,SUM((CASE WHEN T.FUND_CTRL_MODE = 'Y' AND T.writeoff_receipt_flag = 'Y' THEN
             NVL(T.SETTLE_AMOUNT,0) WHEN T.FUND_CTRL_MODE = 'Y' AND T.writeoff_receipt_flag = 'N' THEN
             NVL(T.SETTLE_AMOUNT,0)-NVL(T.SOLUTION_PAY_AMOUNT,0) ELSE 0 END)) AS LOCK_RECEIVED_AMOUNT
      FROM V_CREDIT_CONTACT_AMOUNT_AR T
      WHERE t.entity_id = P_ENTITY_ID
         and t.customer_id = P_CUSTOMER_ID
         and t.account_id = P_ACCOUNT_ID
            --and t.sales_main_type = P_SALES_MAIN_TYPE
         --and t.discount_type <> 'COMMON'
         AND T.discount_type = P_DISCOUNT_TYPE
         /*AND (T.discount_type = P_DISCOUNT_TYPE
         OR (P_DISCOUNT_TYPE IN ('COMMON','ALL') AND T.discount_type IS NULL) )
         AND (P_DISCOUNT_TYPE = 'COMMON'--P_DISCOUNT_TYPE IN ('ALL','COMMON')
         OR T.discount_type = P_DISCOUNT_TYPE)*/
         AND (P_SALES_MAIN_TYPE IS NULL OR T.SALES_MAIN_TYPE = P_SALES_MAIN_TYPE)
         AND (P_CREDIT_GROUP_ID IS NULL OR 0 >= P_CREDIT_GROUP_ID
             OR P_CREDIT_GROUP_ID = PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(
             P_ENTITY_ID,P_CUSTOMER_ID,T.SALES_MAIN_TYPE,P_ACCOUNT_ID) )
         and 'Y' = t.settle_flag
       group by t.entity_id,
                t.customer_id,
                t.account_id
                --,t.sales_main_type
                --,t.discount_type
      union all
      select t.entity_id,
             t.customer_id,
             t.account_id,
             --t.sales_main_type,
             (case
               when t.src_type_code in ('1005', '1006', '1007', '1008') then
                0
               when t.src_type_code not in ('1009', '1010') then
                1
               else
                null
             end) as amount_type,
             --T.discount_type,
             sum(t.settle_amount) as settle_amount,
             0 as LOCK_RECEIVED_AMOUNT
        from V_CREDIT_CONTACT_AMOUNT_SO t
       where t.entity_id = P_ENTITY_ID
         and t.customer_id = P_CUSTOMER_ID
         and t.account_id = P_ACCOUNT_ID
         --and t.discount_type <> 'COMMON'
         AND T.discount_type = P_DISCOUNT_TYPE
         /*AND (T.discount_type = P_DISCOUNT_TYPE
         OR (P_DISCOUNT_TYPE IN ('COMMON','ALL') AND T.discount_type IS NULL) )
         AND (P_DISCOUNT_TYPE = 'COMMON'--P_DISCOUNT_TYPE IN ('ALL','COMMON')
         OR T.discount_type = P_DISCOUNT_TYPE)*/
         and 'Y' = t.settle_flag
         and t.SRC_TYPE_CODE not in ('1009', '1010')
         AND (P_SALES_MAIN_TYPE IS NULL OR T.SALES_MAIN_TYPE = P_SALES_MAIN_TYPE)
         AND (P_CREDIT_GROUP_ID IS NULL OR 0 >= P_CREDIT_GROUP_ID
             OR P_CREDIT_GROUP_ID = PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(
             P_ENTITY_ID,P_CUSTOMER_ID,T.SALES_MAIN_TYPE,P_ACCOUNT_ID) )
       group by t.entity_id,
                t.customer_id,
                t.account_id,
                --t.sales_main_type,
                (case
                  when t.src_type_code in ('1005', '1006', '1007', '1008') then
                   0
                  when t.src_type_code not in ('1009', '1010') then
                   1
                  else
                   null
                end)
                --,t.discount_type
                ;
    V_CUR_SO_DIS CUR_SO_DIS%ROWTYPE;
    VCT_DIS_RECEIPT_AMOUNT V_CUR_SO_DIS.settle_amount%TYPE;--折让到款 上账金额
    VCT_DIS_SALES_AMOUNT V_CUR_SO_DIS.settle_amount%TYPE;--折让到款 销售金额
    VCT_DIS_RECEIVED_AMOUNT V_CUR_SO_DIS.settle_amount%TYPE;--折让到款  到款金额
  BEGIN
    --customer_account_status
    SELECT A.ACCOUNT_CODE,(SELECT CL.CODE_NAME FROM UP_CODELIST CL WHERE CL.CODETYPE='customer_account_status'
    AND CL.CODE_VALUE = A.ACCOUNT_STATUS) INTO VS_ACCOUNT_CODE,VS_ACCOUNT_STATUS_CNAME FROM T_CUSTOMER_ACCOUNT A
    WHERE A.ENTITY_ID = IN_ENTITY_ID AND A.ACCOUNT_ID = IN_ACCOUNT_ID;
    
    IF IS_SALES_MAIN_TYPE IS NOT NULL THEN
      SELECT * INTO VR_CREDIT_GROUP FROM T_CREDIT_GROUP CG
      WHERE CG.ENTITY_ID = IN_ENTITY_ID AND CG.CREDIT_GROUP_ID = PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(
             IN_ENTITY_ID,IN_CUSTOMER_ID,IS_SALES_MAIN_TYPE,IN_ACCOUNT_ID);
      OPEN C_CUSTOMER_AMOUNT_MX;
    ELSE
      SELECT * INTO VR_CREDIT_GROUP FROM T_CREDIT_GROUP CG
      WHERE CG.ENTITY_ID = IN_ENTITY_ID AND CG.CREDIT_GROUP_ID = IN_CREDIT_GROUP_ID;
      OPEN C_CUSTOMER_AMOUNT;
    END IF;
    
    LOOP
      --<<HERE>>
      IF IS_SALES_MAIN_TYPE IS NOT NULL THEN
        FETCH C_CUSTOMER_AMOUNT_MX INTO R_CUSTOMER_AMOUNT;
        EXIT WHEN C_CUSTOMER_AMOUNT_MX%NOTFOUND;
      ELSE
        FETCH C_CUSTOMER_AMOUNT INTO R_CUSTOMER_AMOUNT;
        EXIT WHEN C_CUSTOMER_AMOUNT%NOTFOUND;
      END IF;
      
      V_CUSTOMER_AMOUNT_ROW := OBJ_SALES_DIS_AMOUNT_FREEZE(R_CUSTOMER_AMOUNT.ACCOUNT_AMOUNT_ID
,R_CUSTOMER_AMOUNT.ENTITY_ID
,R_CUSTOMER_AMOUNT.CREDIT_GROUP_ID
,R_CUSTOMER_AMOUNT.PROJ_NUMBER
,R_CUSTOMER_AMOUNT.CUSTOMER_ID
,R_CUSTOMER_AMOUNT.CUSTOMER_CODE
,R_CUSTOMER_AMOUNT.CUSTOMER_NAME
,R_CUSTOMER_AMOUNT.ACCOUNT_ID
,R_CUSTOMER_AMOUNT.ACCOUNT_CODE
,R_CUSTOMER_AMOUNT.ACCOUNT_NAME
,R_CUSTOMER_AMOUNT.ACCOUNT_STATUS
,NULL
--,'ALL'
,R_CUSTOMER_AMOUNT.SALES_YEAR_ID
,R_CUSTOMER_AMOUNT.RECEIVED_AMOUNT
,R_CUSTOMER_AMOUNT.SALES_AMOUNT
,R_CUSTOMER_AMOUNT.LOCK_RECEIVED_AMOUNT
,R_CUSTOMER_AMOUNT.DELAYPAY_AMOUNT
,R_CUSTOMER_AMOUNT.TEMP_DELAYPAY_AMOUNT
,R_CUSTOMER_AMOUNT.DISCOUNT_AMOUNT
,R_CUSTOMER_AMOUNT.APPLIED_DISCOUNT_AMOUNT
,R_CUSTOMER_AMOUNT.FREEZE_DISCOUNT_AMOUNT
,R_CUSTOMER_AMOUNT.FREEZE_DELAY_AMOUNT
,R_CUSTOMER_AMOUNT.LOCK_DISCOUNT_AMOUNT
,R_CUSTOMER_AMOUNT.DISPAY_AMOUNT
,R_CUSTOMER_AMOUNT.THREE_NOT_PAY
,R_CUSTOMER_AMOUNT.RESOURCE_AMOUNT
,R_CUSTOMER_AMOUNT.LOCK_RESOURCE_AMOUNT
,R_CUSTOMER_AMOUNT.TRANSACTION_AMOUNT
,0
--,R_CUSTOMER_AMOUNT.RESOURCE_LEFT_AMOUNT
,R_CUSTOMER_AMOUNT.MPAY_STREAM_AMOUNT
,R_CUSTOMER_AMOUNT.MPAY_CASH_AMOUNT
,R_CUSTOMER_AMOUNT.AMOUNT_CRTL_FLAG
,R_CUSTOMER_AMOUNT.DISCONT_CRTL_FLAG
,R_CUSTOMER_AMOUNT.CREATION_DATE
,R_CUSTOMER_AMOUNT.CREATED_BY
,R_CUSTOMER_AMOUNT.LAST_UPDATE_DATE
,R_CUSTOMER_AMOUNT.LAST_UPDATED_BY
,R_CUSTOMER_AMOUNT.PRE_FIELD_01
,R_CUSTOMER_AMOUNT.PRE_FIELD_02
,R_CUSTOMER_AMOUNT.PRE_FIELD_03
,R_CUSTOMER_AMOUNT.PRE_FIELD_04
,R_CUSTOMER_AMOUNT.PRE_FIELD_05
,R_CUSTOMER_AMOUNT.PRE_FIELD_06
,NULL
--,R_CUSTOMER_AMOUNT.FREEZE_DATE
,R_CUSTOMER_AMOUNT.SALES_CENTER_ID
,R_CUSTOMER_AMOUNT.SALES_CENTER_CODE
,R_CUSTOMER_AMOUNT.SALES_CENTER_NAME
,0
--,R_CUSTOMER_AMOUNT.AMOUNT_ZERO
,VS_ACCOUNT_STATUS_CNAME,NULL,VR_CREDIT_GROUP.CREDIT_GROUP_NAME,NULL,'异常');

      V_CUSTOMER_DIS_AMOUNT_ROW := V_CUSTOMER_AMOUNT_ROW;
      --V_CUSTOMER_DIS_AMOUNT_ROW.FLAG := '异常';
      V_CUSTOMER_DIS_AMOUNT_ROW.DISCOUNT_TYPE := (CASE WHEN IS_DISCOUNT_TYPE IS NULL
      OR IS_DISCOUNT_TYPE IN ('COMMON','ALL') THEN 'DISCOUNT' ELSE IS_DISCOUNT_TYPE END)
      ;
      SELECT CL.CODE_NAME INTO V_CUSTOMER_DIS_AMOUNT_ROW.DISCOUNT_TYPE_NAME
      FROM UP_CODELIST CL WHERE CL.CODETYPE='DISCOUNT_TYPE'
      AND CL.CODE_VALUE = V_CUSTOMER_DIS_AMOUNT_ROW.DISCOUNT_TYPE;
      
      /*DBMS_OUTPUT.put_line(NVL(V_CUSTOMER_AMOUNT_ROW.DISCOUNT_TYPE,'NULL')
      || 'DIS:' || V_CUSTOMER_DIS_AMOUNT_ROW.DISCOUNT_TYPE);*/
      
      SELECT NVL(SUM(DA.RECEIPT_AMOUNT+DA.RECEIVED_AMOUNT),0),
      NVL(SUM(DA.SALES_AMOUNT),0),
      NVL(SUM(DA.LOCK_AMOUNT),0) INTO
      V_CUSTOMER_DIS_AMOUNT_ROW.RECEIVED_AMOUNT,
      V_CUSTOMER_DIS_AMOUNT_ROW.SALES_AMOUNT,
      V_CUSTOMER_DIS_AMOUNT_ROW.LOCK_RECEIVED_AMOUNT
      FROM T_CREDIT_DISCOUNT_AMOUNT DA
      WHERE DA.ENTITY_ID = IN_ENTITY_ID
      AND DA.CUSTOMER_ID = IN_CUSTOMER_ID
      AND DA.ACCOUNT_ID = IN_ACCOUNT_ID
      AND DA.DISCOUNT_TYPE = V_CUSTOMER_DIS_AMOUNT_ROW.DISCOUNT_TYPE
      AND (IS_SALES_MAIN_TYPE IS NULL OR DA.SALES_MAIN_TYPE = IS_SALES_MAIN_TYPE)
      AND (IN_CREDIT_GROUP_ID IS NULL OR 0 >= IN_CREDIT_GROUP_ID
      OR IN_CREDIT_GROUP_ID = PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(
      IN_ENTITY_ID,IN_CUSTOMER_ID,DA.SALES_MAIN_TYPE,IN_ACCOUNT_ID) )
      ;
      /*DBMS_OUTPUT.put_line('到款金额 ' || V_CUSTOMER_AMOUNT_ROW.RECEIVED_AMOUNT
      || 'DIS:' || V_CUSTOMER_DIS_AMOUNT_ROW.RECEIVED_AMOUNT);
      DBMS_OUTPUT.put_line('销售金额 ' || V_CUSTOMER_AMOUNT_ROW.SALES_AMOUNT
      || 'DIS:' || V_CUSTOMER_DIS_AMOUNT_ROW.SALES_AMOUNT);
      DBMS_OUTPUT.put_line('锁定到款金额 ' || V_CUSTOMER_AMOUNT_ROW.LOCK_RECEIVED_AMOUNT
      || 'DIS:' || V_CUSTOMER_DIS_AMOUNT_ROW.LOCK_RECEIVED_AMOUNT);*/
      
      --V_CUSTOMER_DIS_AMOUNT_ROW.RECEIVED_AMOUNT := 0;
      --V_CUSTOMER_DIS_AMOUNT_ROW.Sales_Amount := 0;
      --V_CUSTOMER_DIS_AMOUNT_ROW.Lock_Received_Amount := 0;
      V_CUSTOMER_DIS_AMOUNT_ROW.Delaypay_Amount := 0;
      V_CUSTOMER_DIS_AMOUNT_ROW.Temp_Delaypay_Amount := 0;
      V_CUSTOMER_DIS_AMOUNT_ROW.Discount_Amount := 0;
      V_CUSTOMER_DIS_AMOUNT_ROW.Applied_Discount_Amount := 0;
      V_CUSTOMER_DIS_AMOUNT_ROW.Freeze_Discount_Amount := 0;
      V_CUSTOMER_DIS_AMOUNT_ROW.FREEZE_DELAY_AMOUNT := 0;
      V_CUSTOMER_DIS_AMOUNT_ROW.Lock_Discount_Amount := 0;
      V_CUSTOMER_DIS_AMOUNT_ROW.Three_Not_Pay := 0;
      V_CUSTOMER_DIS_AMOUNT_ROW.Resource_Amount := 0;
      V_CUSTOMER_DIS_AMOUNT_ROW.Lock_Resource_Amount := 0;
      V_CUSTOMER_DIS_AMOUNT_ROW.Transaction_Amount := 0;
      
      --制定发货需求计划下达（直发客户）未生成发货通知单
        SELECT SUM(NVL(ROUND(
                             --锁定代理商到款(未确认数量*直发列表价*(100-直发扣率-直发月返)/100)
                             NVL(TP.UNAFFIRM_QTY, 0) *
                             NVL(TP.TRANSFER_LIST_PRICE, 0) *
                             (100 - NVL(TP.TRANSFER_DISCOUNT_RATE, 0) -
                              NVL(TP.TRANSFER_MONTH_DISCOUNT_RATE, 0)) / 100,
                             2),
                       0))
          INTO VN_SHIP_LOCK_AMOUNT_TRANSFER
          FROM T_LG_SHIP_PLAN TP
         WHERE TP.TRANSFER_ENTITY_ID = IN_ENTITY_ID
           AND TP.TRANSFER_CUSTOMER_ID = IN_CUSTOMER_ID
           AND TP.TRANSFER_ACCOUNT_ID = IN_ACCOUNT_ID
           --AND TP.TRANSFER_ITEM_MAIN_TYPE = DL.SALES_MAIN_TYPE
           --AND TP.TRANSFER_DISCOUNT_TYPE = DL.DISCOUNT_TYPE
           --AND TP.TRANSFER_DISCOUNT_TYPE <> 'COMMON'
           AND TP.TRANSFER_DISCOUNT_TYPE = V_CUSTOMER_DIS_AMOUNT_ROW.DISCOUNT_TYPE
           
           AND (IS_SALES_MAIN_TYPE IS NULL OR TP.TRANSFER_ITEM_MAIN_TYPE = IS_SALES_MAIN_TYPE)
           AND (IN_CREDIT_GROUP_ID IS NULL OR 0 >= IN_CREDIT_GROUP_ID
             OR IN_CREDIT_GROUP_ID = PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(
             IN_ENTITY_ID,IN_CUSTOMER_ID,TP.TRANSFER_ITEM_MAIN_TYPE,IN_ACCOUNT_ID) )
             
           AND TP.STATUS <> '03' --撤销单据没有锁款
           AND TP.STATUS <> '02'
              --已确认，确认则生成发货通知单。部分确认的话，则拆单，生成两个发运计划
           AND TP.TRANSFER_LOCK_AMOUNT_FLAG = 'Y';
      
        --制定发货需求计划下达（直发客户） 发货通知单未生成销售单
        SELECT SUM(NVL(ROUND( --锁定代理商到款((产品数量-已取消数量-已转采购数量)*直发列表价*(100-直发扣率-直发月返)/100)
                             (NVL(B.ITEM_QTY, 0) - NVL(B.CANCEL_QTY, 0) -
                             NVL(B.TRANSFER_TO_POX_QTY, 0)) *
                             NVL(b.TRANSFER_LIST_PRICE, 0) *
                             (100 - NVL(b.TRANSFER_DISCOUNT_RATE, 0) -
                             NVL(b.TRANSFER_MONTH_DISCOUNT_RATE, 0)) / 100,
                             2),
                       0))
          INTO VN_DOC_LOCK_AMOUNT_TRANSFER
          FROM t_lg_ship_doc      a, --发货通知单头
               t_lg_ship_doc_line b --发货通知单行
        --单据源类型
         WHERE a.ship_doc_id = b.ship_doc_id
           AND A.TRANSFER_ENTITY_ID = IN_ENTITY_ID
           AND A.TRANSFER_CUSTOMER_ID = IN_CUSTOMER_ID
           AND A.TRANSFER_ACCOUNT_ID = IN_ACCOUNT_ID
           --AND B.TRANSFER_ITEM_MAIN_TYPE = DL.SALES_MAIN_TYPE
           --AND B.TRANSFER_DISCOUNT_TYPE = DL.DISCOUNT_TYPE
           --AND B.TRANSFER_DISCOUNT_TYPE <> 'COMMON'
           AND B.TRANSFER_DISCOUNT_TYPE = V_CUSTOMER_DIS_AMOUNT_ROW.DISCOUNT_TYPE
           
           AND (IS_SALES_MAIN_TYPE IS NULL OR B.TRANSFER_ITEM_MAIN_TYPE = IS_SALES_MAIN_TYPE)
           AND (IN_CREDIT_GROUP_ID IS NULL OR 0 >= IN_CREDIT_GROUP_ID
             OR IN_CREDIT_GROUP_ID = PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(
             IN_ENTITY_ID,IN_CUSTOMER_ID,B.TRANSFER_ITEM_MAIN_TYPE,IN_ACCOUNT_ID) )
             
           AND A.DOC_STATUS <> '01' --单据状态 00正常 01红冲
           AND B.TRANSFER_LOCK_AMOUNT_FLAG = 'Y';
      
        --优化后 ： 2、已下达发运计划但未生成发货通知锁款
        SELECT SUM(NVL(ROUND(CASE
                               --20200314 家用直发锁款调整
                               when tp.origin_type = '01' and nvl(tp.direct_transport_falg, 'N') = 'Y' and 
                                 (select nvl(h.amount_lock_flag, 'N')
                                    from t_pln_order_head h
                                   where h.order_head_id = tp.origin_order_id) = 'NT'
                                 then
                                   0
                               WHEN tP.lock_amount_flag IN ('S', 'Y','HQ') THEN
                               --未确认数量*单价*(100-折扣-月返)/100
                                NVL(tP.unaffirm_qty, 0) * NVL(tP.item_price, 0) *
                                (100 - NVL(tP.discount_rate, 0) -
                                 NVL(tP.month_discount_rate, 0)) / 100
                               ELSE
                                0
                             END,
                             2),
                       0))
          INTO VN_SHIP_LOCK_AMOUNT
          FROM t_lg_ship_plan tp
         WHERE TP.ENTITY_ID = IN_ENTITY_ID
           AND TP.CUSTOMER_ID = IN_CUSTOMER_ID
           AND TP.ACCOUNT_CODE = VS_ACCOUNT_CODE
           --AND TP.SALES_MAIN_TYPE = DL.SALES_MAIN_TYPE
           --AND TP.DISCOUNT_TYPE = DL.DISCOUNT_TYPE
           --AND TP.DISCOUNT_TYPE <> 'COMMON'
           AND TP.DISCOUNT_TYPE = V_CUSTOMER_DIS_AMOUNT_ROW.DISCOUNT_TYPE
           
           AND (IS_SALES_MAIN_TYPE IS NULL OR TP.SALES_MAIN_TYPE = IS_SALES_MAIN_TYPE)
           AND (IN_CREDIT_GROUP_ID IS NULL OR 0 >= IN_CREDIT_GROUP_ID
             OR IN_CREDIT_GROUP_ID = PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(
             IN_ENTITY_ID,IN_CUSTOMER_ID,TP.SALES_MAIN_TYPE,IN_ACCOUNT_ID) )
             
           AND tp.status <> '03' --撤销单据没有锁款
           AND tp.status <> '02'
           AND NVL(TP.CUSTOMIZE_FLAG, 'N') = 'N'
              --已确认，确认则生成发货通知单。部分确认的话，则拆单，生成两个发运计划
           AND tp.lock_amount_flag IN ('S', 'Y', 'RS', 'RT','HQ');
      
        --3、已生成发货通知未生成销售单锁款
        SELECT SUM(NVL(ROUND(CASE
                               --20200314 家用直发锁款调整
                               when b.origin_type = '01' and nvl(a.direct_transport_falg, 'N') = 'Y' and 
                                 (select nvl(h.amount_lock_flag, 'N')
                                    from t_pln_order_head h
                                   where h.order_head_id = b.origin_order_id) = 'NT'
                                 then
                                   0
                               WHEN b.lock_amount_flag IN ('S', 'Y','HQ') THEN
                               --(ITEM_QTY产品数量 - FACT_SHIP_QTY实际发货数量 - CANCEL_QTY累积取消数量)*单价*(100-折扣-月返)/100
                                (NVL(b.item_qty, 0) - NVL(b.fact_ship_qty, 0) -
                                NVL(b.cancel_qty, 0)) * NVL(b.item_price, 0) *
                                (100 - NVL(b.discount_rate, 0) -
                                NVL(b.month_discount_rate, 0)) / 100
                               ELSE
                                0
                             END,
                             2),
                       0))
          INTO VN_DOC_LOCK_AMOUNT
          FROM t_lg_ship_doc      a, --发货通知单头
               t_lg_ship_doc_line b --发货通知单行
        --,t_inv_bill_types   bill_type, --业务单据类型
        --t_inv_source_types source_type
        --单据源类型
         WHERE a.ship_doc_id = b.ship_doc_id
           AND A.ENTITY_ID = IN_ENTITY_ID
           AND A.CUSTOMER_ID = IN_CUSTOMER_ID
           AND A.ACCOUNT_CODE = VS_ACCOUNT_CODE
           --AND B.SALES_MAIN_TYPE = DL.SALES_MAIN_TYPE
           --AND B.DISCOUNT_TYPE = DL.DISCOUNT_TYPE
           --AND B.DISCOUNT_TYPE <> 'COMMON'
           AND B.DISCOUNT_TYPE = V_CUSTOMER_DIS_AMOUNT_ROW.DISCOUNT_TYPE
           
           AND (IS_SALES_MAIN_TYPE IS NULL OR B.SALES_MAIN_TYPE = IS_SALES_MAIN_TYPE)
           AND (IN_CREDIT_GROUP_ID IS NULL OR 0 >= IN_CREDIT_GROUP_ID
             OR IN_CREDIT_GROUP_ID = PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(
             IN_ENTITY_ID,IN_CUSTOMER_ID,B.SALES_MAIN_TYPE,IN_ACCOUNT_ID) )
             
           AND a.doc_status <> '01' --单据状态 00正常 01红冲
           AND NVL(A.CUSTOMIZE_FLAG, 'N') = 'N'
              --AND b.sales_order_type_id = bill_type.bill_type_id(+)
              --AND bill_type.source_type_id = source_type.source_type_id
           AND b.lock_amount_flag IN ('S', 'Y', 'RS', 'RT','HQ');
      
        --1、送审锁款：已经送审未下达发运计划的锁款
        --1.1、提货订单
        --1.1、提货订单--新2
        SELECT SUM(NVL(ROUND(CASE
                               WHEN nvl(l.order_line_state,LG_LINE_STATE_NORMAL)=LG_LINE_STATE_CLOSED THEN
                                 0
                               --20200314 家用直发锁款调整
                               WHEN (H.lock_amount_flag = 'S' AND
                                    NOT (NVL(H.DOWN_PAY_SCALE, -1) >= 0)) 
                                    OR NVL(l.IS_LOCK_AMOUNT, 'N') = 'Y' THEN
                                (CASE
                                --2016-09-13 tianmzh修改，增加'2225'，显示产能可视状态('2225'提货订单金额。
                                  WHEN H.order_head_state IN ('20', '1455', '2225') and nvl(l.order_line_state,LG_LINE_STATE_NORMAL)<>LG_LINE_STATE_CLOSED THEN
                                  --ADD YBY LIANGYM2 2017-6-18 已送审状态下销司主体结转到总部主体 Center_Affirm_Quantity可能发生变化
                                   NVL(decode(h.hq_lg_order_head_id,null,l.quantity,NVL(L.center_affirm_quantity, L.quantity)), 0) -
                                   NVL(L.affirmed_quantity, 0) - NVL(L.cancel_qty, 0)
                                   -(NVL(L.transfer_hq_affirmed_qty,0)-NVL(L.SENDED_QTY,0))
                                   -(nvl(l.direct_transport_qty,0)-nvl(l.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                  WHEN H.order_head_state IN ('381', '679') and nvl(l.order_line_state,LG_LINE_STATE_NORMAL)<>LG_LINE_STATE_CLOSED THEN
                                   NVL(L.center_affirm_quantity, 0) -
                                   NVL(L.affirmed_quantity, 0) - NVL(L.cancel_qty, 0)
                                   -(NVL(L.transfer_hq_affirmed_qty,0)-NVL(L.SENDED_QTY,0))
                                   -(nvl(l.direct_transport_qty,0)-nvl(l.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                  ELSE
                                   0
                                END)
                               ELSE
                                0
                             END
                             * DECODE(L.project_order_type,
                                              NULL,
                                              NVL(L.list_price, 0),
                                              NVL(L.apply_list_price, 0))
                               --add by lizhen 2015-11-30 增加月返计算
                                * (100 - DECODE(L.project_order_type,
                                                NULL,
                                                NVL(L.discount_rate, 0),
                                                NVL(L.apply_discount_rate, 0)) -
                                NVL(L.ordered_discount_rate, 0)) / 100,
                             2),
                       0)),
               SUM((H.DOWN_PAY_SCALE / 100) *
                   NVL(ROUND(CASE
                               --20200314 家用直发锁款调整
                               WHEN nvl(l.order_line_state,LG_LINE_STATE_NORMAL)=LG_LINE_STATE_CLOSED 
                                 OR NVL(l.IS_LOCK_AMOUNT, 'N') = 'Y' THEN
                                 0
                               WHEN H.lock_amount_flag = 'S' AND H.DOWN_PAY_SCALE > 0 THEN
                                (CASE
                                  WHEN NVL(l.IS_LOCK_AMOUNT, 'N') = 'NT' THEN
                                    NVL(l.CENTER_AFFIRM_QUANTITY, 0) - NVL(l.CANCEL_QTY, 0)
                                --2016-09-13 tianmzh修改，增加'2225'，显示产能可视状态('2225'提货订单金额。
                                  WHEN H.order_head_state IN ('20', '1455', '2225') and nvl(l.order_line_state,LG_LINE_STATE_NORMAL)<>LG_LINE_STATE_CLOSED THEN
                                  --ADD YBY LIANGYM2 2017-6-18 已送审状态下销司主体结转到总部主体 Center_Affirm_Quantity可能发生变化
                                   NVL(NVL(L.center_affirm_quantity, L.quantity), 0) -
                                   NVL(L.affirmed_quantity, 0) - NVL(L.cancel_qty, 0)
                                    - (NVL(l.transfer_hq_affirmed_qty,0)-NVL(l.SENDED_QTY,0)) --20180105 hejy3 增加订金发货锁全款处理
                                    -(nvl(l.direct_transport_qty,0)-nvl(l.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                  WHEN H.order_head_state IN ('381', '679') and nvl(l.order_line_state,LG_LINE_STATE_NORMAL)<>LG_LINE_STATE_CLOSED THEN
                                   NVL(L.center_affirm_quantity, 0) -
                                   NVL(L.affirmed_quantity, 0) - NVL(L.cancel_qty, 0)
                                   - (NVL(l.transfer_hq_affirmed_qty,0)-NVL(l.SENDED_QTY,0))
                                   -(nvl(l.direct_transport_qty,0)-nvl(l.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                  ELSE
                                   0
                                END) * DECODE(L.project_order_type,
                                              NULL,
                                              NVL(L.list_price, 0),
                                              NVL(L.apply_list_price, 0))
                               --add by lizhen 2015-11-30 增加月返计算
                                * (100 - DECODE(L.project_order_type,
                                                NULL,
                                                NVL(L.discount_rate, 0),
                                                NVL(L.apply_discount_rate, 0)) -
                                NVL(L.ordered_discount_rate, 0)) / 100
                               ELSE
                                0
                             END,
                             2),
                       0))
          INTO VN_PLN_LOCK_AMOUNT, VN_PLN_DP_LOCK_AMOUNT
          FROM t_pln_lg_order_head h --物流订单头表
         INNER JOIN t_pln_lg_order_line l --物流订单行表
            ON (H.ORDER_HEAD_ID = L.ORDER_HEAD_ID --AND
               --NVL(l.order_line_state, 'NORMAL') <> 'CLOSED'-- AND L.DISCOUNT_TYPE <> 'COMMON'
               AND L.DISCOUNT_TYPE = V_CUSTOMER_DIS_AMOUNT_ROW.DISCOUNT_TYPE
               --AND L.DISCOUNT_TYPE = DL.DISCOUNT_TYPE
               )
         WHERE H.ENTITY_ID = IN_ENTITY_ID
           AND H.CUSTOMER_ID = IN_CUSTOMER_ID
           AND H.ACCOUNT_ID = IN_ACCOUNT_ID
           AND h.order_head_state IN
              --2016-09-13 tianmzh修改，增加'2225'，显示产能可视状态('2225'提货订单金额。
               ('20', '23', '381', '679', '1455', '2225', '304')
           AND h.lock_amount_flag IN ('S', 'RS')
           --and NVL(H.sales_main_type, L.sales_main_type) = dl.sales_main_type
           
           AND (IS_SALES_MAIN_TYPE IS NULL OR L.sales_main_type  = IS_SALES_MAIN_TYPE)
           AND (IN_CREDIT_GROUP_ID IS NULL OR 0 >= IN_CREDIT_GROUP_ID
             OR IN_CREDIT_GROUP_ID = PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(
             IN_ENTITY_ID,IN_CUSTOMER_ID,L.sales_main_type ,IN_ACCOUNT_ID) )
           AND NVL(H.CUSTOMIZE_FLAG, 'N') = 'N'             
        --and h.order_head_state IS NOT NULL
        --AND H.lock_amount_flag IS NOT NULL
        ;
        
      --hejy3 送总部评审锁款
        SELECT SUM(NVL(ROUND(CASE
                               WHEN nvl(l.order_line_state,LG_LINE_STATE_NORMAL)=LG_LINE_STATE_CLOSED THEN
                                 0
                               --20200314 家用直发锁款调整
                               WHEN NOT (NVL(H.DOWN_PAY_SCALE, -1) >= 0) 
                                 OR NVL(l.IS_LOCK_AMOUNT, 'N') = 'Y' THEN
                                (CASE
                                --2016-09-13 tianmzh修改，增加'2225'，显示产能可视状态('2225'提货订单金额。
                                  WHEN (H.order_head_state IN ('20', '1455', '2225') and ha.SUBMIT_TO_HQ_FLAG = 'Y')
                                    or h.SUBMIT_TO_HQ_FLAG = 'Y' THEN
                                  --ADD YBY LIANGYM2 2017-6-18 已送审状态下销司主体结转到总部主体 Center_Affirm_Quantity可能发生变化
                                   NVL(L.center_affirm_quantity, 0) - NVL(L.affirmed_quantity, 0) - NVL(L.cancel_qty, 0)
                                   -(NVL(L.transfer_hq_affirmed_qty,0)-NVL(L.SENDED_QTY,0))
                                   -(nvl(l.direct_transport_qty,0)-nvl(l.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                  ELSE
                                   0
                                END)
                               ELSE
                                0
                             END
                             * DECODE(L.project_order_type,
                                              NULL,
                                              NVL(L.list_price, 0),
                                              NVL(L.apply_list_price, 0))
                               --add by lizhen 2015-11-30 增加月返计算
                                * (100 - DECODE(L.project_order_type,
                                                NULL,
                                                NVL(L.discount_rate, 0),
                                                NVL(L.apply_discount_rate, 0)) -
                                NVL(L.ordered_discount_rate, 0)) / 100,
                             2),
                       0)),
               SUM((H.DOWN_PAY_SCALE / 100) *
                   NVL(ROUND(CASE
                               --20200314 家用直发锁款调整
                               WHEN nvl(l.order_line_state,LG_LINE_STATE_NORMAL)=LG_LINE_STATE_CLOSED 
                                 OR NVL(l.IS_LOCK_AMOUNT, 'N') = 'Y' THEN
                                 0
                               WHEN H.DOWN_PAY_SCALE > 0 THEN
                                (CASE
                                  WHEN NVL(l.IS_LOCK_AMOUNT, 'N') = 'NT' THEN
                                    NVL(l.CENTER_AFFIRM_QUANTITY, 0) - NVL(l.CANCEL_QTY, 0)
                                --2016-09-13 tianmzh修改，增加'2225'，显示产能可视状态('2225'提货订单金额。
                                  WHEN (H.order_head_state IN ('20', '1455', '2225') and ha.SUBMIT_TO_HQ_FLAG = 'Y')
                                    or h.SUBMIT_TO_HQ_FLAG = 'Y' THEN
                                  --ADD YBY LIANGYM2 2017-6-18 已送审状态下销司主体结转到总部主体 Center_Affirm_Quantity可能发生变化
                                   NVL(L.center_affirm_quantity, 0) - NVL(L.affirmed_quantity, 0) - NVL(L.cancel_qty, 0)
                                   -(NVL(L.transfer_hq_affirmed_qty,0)-NVL(L.SENDED_QTY,0))
                                   -(nvl(l.direct_transport_qty,0)-nvl(l.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                  ELSE
                                   0
                                END) * DECODE(L.project_order_type,
                                              NULL,
                                              NVL(L.list_price, 0),
                                              NVL(L.apply_list_price, 0))
                               --add by lizhen 2015-11-30 增加月返计算
                                * (100 - DECODE(L.project_order_type,
                                                NULL,
                                                NVL(L.discount_rate, 0),
                                                NVL(L.apply_discount_rate, 0)) -
                                NVL(L.ordered_discount_rate, 0)) / 100
                               ELSE
                                0
                             END,
                             2),
                       0))
          INTO VN_PLN_LOCK_AMOUNT_HQ, VN_PLN_DP_LOCK_AMOUNT_HQ
          FROM t_pln_lg_order_head h --物流订单头表
         INNER JOIN t_pln_lg_order_line l --物流订单行表
            ON (H.ORDER_HEAD_ID = L.ORDER_HEAD_ID --AND
               --NVL(l.order_line_state, 'NORMAL') <> 'CLOSED'-- AND L.DISCOUNT_TYPE <> 'COMMON'
               AND L.DISCOUNT_TYPE = V_CUSTOMER_DIS_AMOUNT_ROW.DISCOUNT_TYPE
               --AND L.DISCOUNT_TYPE = DL.DISCOUNT_TYPE
               )
          LEFT JOIN t_pln_lg_order_head ha
            ON (ha.order_head_id = h.hq_lg_order_head_id)
         WHERE H.ENTITY_ID = IN_ENTITY_ID
           AND H.CUSTOMER_ID = IN_CUSTOMER_ID
           AND H.ACCOUNT_ID = IN_ACCOUNT_ID
           AND h.order_head_state IN
              --2016-09-13 tianmzh修改，增加'2225'，显示产能可视状态('2225'提货订单金额。
               ('20', '23', '381', '679', '1455', '2225', '304')
           AND h.lock_amount_flag IN ('HQ')
           AND (IS_SALES_MAIN_TYPE IS NULL OR L.sales_main_type  = IS_SALES_MAIN_TYPE)
           AND (IN_CREDIT_GROUP_ID IS NULL OR 0 >= IN_CREDIT_GROUP_ID
             OR IN_CREDIT_GROUP_ID = PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(
             IN_ENTITY_ID,IN_CUSTOMER_ID,L.sales_main_type ,IN_ACCOUNT_ID) )
           AND NVL(H.CUSTOMIZE_FLAG, 'N') = 'N'
        ;
        
      --针对已结转总部主体且发货锁款的提货订单重算锁款
      --锁定客户到款((跨主体总部评审数量-已评审数量+申请数量-送总部评审数量-已取消数量)*价格*(100-扣率-月返)/100)
      
      SELECT SUM(NVL(ROUND(CASE WHEN NVL(L.IS_LOCK_AMOUNT, 'N') <> 'NT' THEN
                                (NVL(L.transfer_hq_affirmed_qty,0)-NVL(L.SENDED_QTY,0)) * DECODE(L.project_order_type,
                                              NULL,
                                              NVL(L.list_price, 0),
                                              NVL(L.apply_list_price, 0))
                               --add by lizhen 2015-11-30 增加月返计算
                                * (100 - DECODE(L.project_order_type,
                                                NULL,
                                                NVL(L.discount_rate, 0),
                                                NVL(L.apply_discount_rate, 0)) -
                                NVL(L.ordered_discount_rate, 0)) / 100
                               ELSE 0 END
                             ,2),
                       0))
          INTO VN_PLN_LOCK_AMOUNT_PS
          FROM t_pln_lg_order_head h --物流订单头表
         INNER JOIN t_pln_lg_order_line l --物流订单行表
            ON (H.ORDER_HEAD_ID = L.ORDER_HEAD_ID --AND
               --NVL(l.order_line_state, 'NORMAL') <> 'CLOSED'-- AND L.DISCOUNT_TYPE <> 'COMMON'
               AND L.DISCOUNT_TYPE = V_CUSTOMER_DIS_AMOUNT_ROW.DISCOUNT_TYPE
               --AND L.DISCOUNT_TYPE = DL.DISCOUNT_TYPE
               )
         WHERE H.ENTITY_ID = IN_ENTITY_ID
           AND H.CUSTOMER_ID = IN_CUSTOMER_ID
           AND H.ACCOUNT_ID = IN_ACCOUNT_ID
           AND h.order_head_state IN
              --2016-09-13 tianmzh修改，增加'2225'，显示产能可视状态('2225'提货订单金额。
               ('20', '23', '381', '679', '1455', '2225', '304')
           AND L.TRANSFER_HQ_AFFIRMED_QTY > 0
           AND NVL(H.CUSTOMIZE_FLAG, 'N') = 'N'
           --and h.HQ_LG_ORDER_HEAD_ID is not null
           --AND h.lock_amount_flag = 'Y'
           
           AND (IS_SALES_MAIN_TYPE IS NULL OR L.sales_main_type  = IS_SALES_MAIN_TYPE)
           AND (IN_CREDIT_GROUP_ID IS NULL OR 0 >= IN_CREDIT_GROUP_ID
             OR IN_CREDIT_GROUP_ID = PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(
             IN_ENTITY_ID,IN_CUSTOMER_ID,L.sales_main_type ,IN_ACCOUNT_ID) )
        ;
      
      SELECT NVL(SUM(D.LOCKED_AMOUNT), 0), NVL(SUM(D.LOCKED_DOWNPAY_AMOUNT), 0)
        INTO V_LOCK_RECEIVED_AMOUNT_NEW, V_LOCK_RECEIVED_AMOUNT_NEW_DP
        FROM T_CREDIT_LOCK_AMOUNT_DETAIL D
       WHERE D.ENTITY_ID = IN_ENTITY_ID
         AND D.CUSTOMER_ID = IN_CUSTOMER_ID
         AND D.ACCOUNT_ID = IN_ACCOUNT_ID
         AND (IS_SALES_MAIN_TYPE IS NULL OR D.SALES_MAIN_TYPE = IS_SALES_MAIN_TYPE)
         AND (IN_CREDIT_GROUP_ID IS NULL OR 0 >= IN_CREDIT_GROUP_ID
             OR IN_CREDIT_GROUP_ID = D.CREDIT_GROUP_ID);
      
      VN_LOCK_AMOUNT := ( NVL(VN_PLN_LOCK_AMOUNT, 0) +
                          NVL(VN_SHIP_LOCK_AMOUNT, 0) +
                          NVL(VN_DOC_LOCK_AMOUNT, 0) +
                          NVL(VN_SHIP_LOCK_AMOUNT_TRANSFER, 0) +
                          NVL(VN_DOC_LOCK_AMOUNT_TRANSFER, 0) +
                          NVL(VN_PLN_DP_LOCK_AMOUNT, 0) +
                          NVL(VN_PLN_LOCK_AMOUNT_PS,0) +
                          NVL(VN_PLN_LOCK_AMOUNT_HQ, 0) +
                          NVL(VN_PLN_DP_LOCK_AMOUNT_HQ, 0) +
                          NVL(V_LOCK_RECEIVED_AMOUNT_NEW, 0) +
                          NVL(V_LOCK_RECEIVED_AMOUNT_NEW_DP, 0));
      VCT_DIS_RECEIPT_AMOUNT := 0;
      VCT_DIS_SALES_AMOUNT := 0;
      VCT_DIS_RECEIVED_AMOUNT := 0;
      FOR CL IN CUR_SO_DIS(IN_ENTITY_ID,IN_CUSTOMER_ID,IN_ACCOUNT_ID
        ,IN_CREDIT_GROUP_ID,IS_SALES_MAIN_TYPE,V_CUSTOMER_DIS_AMOUNT_ROW.DISCOUNT_TYPE) LOOP
        IF 0 = CL.AMOUNT_TYPE THEN
          --(VCT_DIS_RECEIPT_AMOUNT + CL.SETTLE_AMOUNT); 销售折让是冲减销售，上账取正向，所以是减去
          VCT_DIS_RECEIPT_AMOUNT := (VCT_DIS_RECEIPT_AMOUNT - CL.SETTLE_AMOUNT);
        ELSIF 1 = CL.AMOUNT_TYPE THEN
          VCT_DIS_SALES_AMOUNT := (VCT_DIS_SALES_AMOUNT + CL.SETTLE_AMOUNT);
        ELSIF 2 = CL.AMOUNT_TYPE THEN
          VCT_DIS_RECEIVED_AMOUNT := (VCT_DIS_RECEIVED_AMOUNT + CL.SETTLE_AMOUNT);
          VN_LOCK_AMOUNT := (VN_LOCK_AMOUNT + CL.LOCK_RECEIVED_AMOUNT);
        END IF;
      END LOOP;
      
      IF VN_LOCK_AMOUNT <> V_CUSTOMER_DIS_AMOUNT_ROW.LOCK_RECEIVED_AMOUNT
        OR VCT_DIS_SALES_AMOUNT <> V_CUSTOMER_DIS_AMOUNT_ROW.SALES_AMOUNT
        OR (VCT_DIS_RECEIPT_AMOUNT + VCT_DIS_RECEIVED_AMOUNT) <> V_CUSTOMER_DIS_AMOUNT_ROW.RECEIVED_AMOUNT THEN
        
      PIPE ROW(V_CUSTOMER_DIS_AMOUNT_ROW);
      V_CUSTOMER_DIS_AMOUNT_ROW.RECEIVED_AMOUNT := (VCT_DIS_RECEIPT_AMOUNT + VCT_DIS_RECEIVED_AMOUNT);
      V_CUSTOMER_DIS_AMOUNT_ROW.Sales_Amount := VCT_DIS_SALES_AMOUNT;
      V_CUSTOMER_DIS_AMOUNT_ROW.Lock_Received_Amount := VN_LOCK_AMOUNT;
      V_CUSTOMER_DIS_AMOUNT_ROW.FLAG := '重算理论值';
      PIPE ROW(V_CUSTOMER_DIS_AMOUNT_ROW);
      
      END IF;
                          
      IF IS_DISCOUNT_TYPE IS NULL OR IS_DISCOUNT_TYPE IN ('COMMON','ALL') THEN
      
      --BEGIN
          SELECT NVL(SUM(CASE
                       WHEN T.Business_ID = 'ar' THEN
                        NVL(T.SETTLE_AMOUNT, 0)
                       ELSE
                        0
                     END),0) V_RECEIVED_AMOUNT, --收款金额
                     
                  NVL(SUM(CASE
                       WHEN T.Business_ID = 'ar' AND T.CREATION_DATE < Trunc(Sysdate) THEN
                        NVL(T.SETTLE_AMOUNT, 0)
                       ELSE
                        0
                     END),0) V_RECEIVED_AMOUNT_FREEZE, --收款金额   冻结金额  
                     
                 --销售明细表中，扣率折让单和扣率折让红冲单不对销售金额产生影响
                 NVL(SUM(CASE
                       WHEN T.BUSINESS_ID = 'so' AND
                            --T.BILL_TYPE_ID NOT IN (76, 77) THEN
                            --T.BILL_TYPE_CODE NOT IN (/*1024,1025,1026,1027,*/1028,1029) THEN
                            t.src_type_code Not In ('1009','1010') Then
                        NVL(T.SETTLE_AMOUNT, 0)
                       ELSE
                        0
                     END),0) V_SALES_AMOUNT, --销售金额
                     
                NVL(SUM(CASE
                       WHEN T.BUSINESS_ID = 'so' AND
                            T.CREATION_DATE < Trunc(Sysdate)   AND
                            t.src_type_code Not In ('1009','1010') Then
                        NVL(T.SETTLE_AMOUNT, 0)
                       ELSE
                        0
                     END),0) V_SALES_AMOUNT_FREEZE, --销售金额  冻结金额     
                     
                 NVL(SUM(CASE T.BUSINESS_ID
                        WHEN 'ar' Then
                           --(CASE WHEN T.FUND_CTRL_MODE = 'Y' THEN --是否为承兑
                           --mod by sudy 2015-12-26 到款模块三方承兑冲销改变了方式，由之前不生成冲销单改成生成产冲销单据
                           --重算需要调整，将冲销单据剔除掉
                           /*(CASE WHEN T.FUND_CTRL_MODE = 'Y' And t.SETTLE_AMOUNT >= 0 THEN --是否为承兑
                          NVL(T.SETTLE_AMOUNT,0)-NVL(T.SOLUTION_PAY_AMOUNT,0) ELSE 0 END)*/

                          --mod by 龙鸿文 2016-1-11 区分三方承兑单据是否被冲销(T.writeoff_receipt_flag = 'Y')
                          (CASE
                           WHEN T.FUND_CTRL_MODE = 'Y' AND T.writeoff_receipt_flag = 'Y' THEN
                                NVL(T.SETTLE_AMOUNT,0)
                           WHEN T.FUND_CTRL_MODE = 'Y' AND T.writeoff_receipt_flag = 'N' THEN
                                NVL(T.SETTLE_AMOUNT,0)-NVL(T.SOLUTION_PAY_AMOUNT,0)
                           ELSE 0 END)

                        /*WHEN 'so' THEN
                           --销售单,特批销售单,工程买断销售单
                          (CASE WHEN T.BILL_TYPE_CODE IN (1020,1022,1023) AND T.CREATED_MODE = 10 THEN
                            (-1) * NVL(T.SETTLE_AMOUNT,0) ELSE 0 END)
                        WHEN 'order' THEN
                           NVL(T.SETTLE_AMOUNT,0)*/
                        ELSE 0 END),0) V_LOCK_RECEIVED_AMOUNT, --锁定到款金额
                  NVL(SUM(CASE T.BUSINESS_ID
                         WHEN 'delay' THEN
                            (CASE WHEN T.BILL_TYPE_ID IN (1,2,4) THEN NVL(T.SETTLE_AMOUNT,0) ELSE 0 END)
                         ELSE 0 END),0) V_DELAYPAY_AMOUNT, --铺底金额
                  NVL(SUM(CASE T.BUSINESS_ID
                         WHEN 'delay' THEN
                            (CASE WHEN T.BILL_TYPE_ID = 3 AND T.SRC_TYPE <> 8 THEN NVL(T.SETTLE_AMOUNT,0) ELSE 0 END)
                         ELSE 0 END),0) V_TEMP_DELAYPAY_AMOUNT, --临时铺底金额
                  NVL(SUM(CASE T.BUSINESS_ID
                         WHEN 'so' THEN
                           --(CASE WHEN T.BILL_TYPE_CODE IN (1028,1029) THEN NVL(T.DISCOUNT_AMOUNT,0) ELSE 0 END)
                           (CASE WHEN T.src_type_code IN ('1009','1010') THEN NVL(T.DISCOUNT_AMOUNT,0) ELSE 0 END)
                         ELSE 0 END),0) V_DISCOUNT_AMOUNT, --扣率折让金额
                  NVL(SUM(CASE T.BUSINESS_ID
                         WHEN 'so' THEN
                           --(CASE WHEN T.BILL_TYPE_CODE IN (1020,1021,1022,1023,1031,1032) THEN NVL(T.DISCOUNT_AMOUNT,0) ELSE 0 END)
                           (CASE WHEN T.src_type_code IN ('1001','1002','1003','1004') THEN NVL(T.DISCOUNT_AMOUNT,0) ELSE 0 END)
                         ELSE 0 END),0) V_APPLIED_DISCOUNT_AMOUNT,  --核销扣率折让金额
                 NVL(SUM(CASE T.BUSINESS_ID
                         WHEN 'delay' THEN
                            (CASE WHEN T.BILL_TYPE_ID = 3 AND T.SRC_TYPE = 8 THEN -NVL(T.SETTLE_AMOUNT,0) ELSE 0 END)
                         ELSE 0 END),0) V_FREEZE_DISCOUNT_AMOUNT, --冻结扣率折让金额
                 NVL(SUM(CASE T.BUSINESS_ID
                         WHEN 'delay' THEN
                            (CASE WHEN T.BILL_TYPE_ID = 3 AND T.SRC_TYPE = 10 THEN -NVL(T.SETTLE_AMOUNT,0) ELSE 0 END)
                         ELSE 0 END),0) V_FREEZE_DELAY_AMOUNT, --冻结保证金、冻结铺底
                 /*NVL(SUM(CASE T.BUSINESS_ID
                        WHEN 'so' THEN
                           (CASE WHEN T.BILL_TYPE_CODE IN (1020,1022,1023) AND T.CREATED_MODE = 10 THEN
                          (-1) * NVL(T.DISCOUNT_AMOUNT,0) ELSE 0 END)
                        WHEN 'order' THEN
                           NVL(T.DISCOUNT_AMOUNT,0)
                        ELSE 0 END),0)  V_LOCK_DISCOUNT_AMOUNT, --锁定扣率折让金额*/
                 NVL(SUM(CASE T.BUSINESS_ID
                         WHEN 'ar' THEN
                           (CASE WHEN T.DRAFT_FLAG = 'Y' And t.SETTLE_AMOUNT >= 0 THEN
                           NVL(T.SETTLE_AMOUNT,0)-NVL(T.SOLUTION_PAY_AMOUNT,0) ELSE 0 END)
                         ELSE 0 END),0) V_DISPAY_AMOUNT,
                 NVL(SUM(CASE T.BUSINESS_ID
                         WHEN 'ar' THEN
                           (CASE WHEN T.FUND_CTRL_MODE = 'Y' THEN
                           NVL(T.SETTLE_AMOUNT,0)-NVL(T.SOLUTION_PAY_AMOUNT,0) ELSE 0 END)
                         ELSE 0 END),0) V_THREE_NOT_PAY
            INTO
                V_RECEIVED_AMOUNT    ,
                V_RECEIVED_AMOUNT_FREEZE,
                V_SALES_AMOUNT        ,
                V_SALES_AMOUNT_FREEZE ,
                V_LOCK_RECEIVED_AMOUNT   ,
                V_DELAYPAY_AMOUNT        ,
                V_TEMP_DELAYPAY_AMOUNT   ,
                V_DISCOUNT_AMOUNT        ,
                V_APPLIED_DISCOUNT_AMOUNT ,
                V_FREEZE_DISCOUNT_AMOUNT  ,
                V_FREEZE_DELAY_AMOUNT ,
               -- V_LOCK_DISCOUNT_AMOUNT    ,
                V_DISPAY_AMOUNT           ,
                V_THREE_NOT_PAY
            FROM V_CREDIT_CONTACT_AMOUNT T
           WHERE T.SETTLE_FLAG = 'Y'
             AND T.CUSTOMER_ID = IN_CUSTOMER_ID
             AND T.ACCOUNT_ID = IN_ACCOUNT_ID
             AND (IS_SALES_MAIN_TYPE IS NULL OR T.SALES_MAIN_TYPE = IS_SALES_MAIN_TYPE)
             AND (IN_CREDIT_GROUP_ID IS NULL OR 0 >= IN_CREDIT_GROUP_ID
             OR IN_CREDIT_GROUP_ID = PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(
             IN_ENTITY_ID,IN_CUSTOMER_ID,T.SALES_MAIN_TYPE,IN_ACCOUNT_ID) )
             AND T.ENTITY_ID = IN_ENTITY_ID ;
      /*EXCEPTION WHEN OTHERS THEN
        GOTO HERE ;
      END ;*/
      --dbms_output.put_line(R_CUSTOMER_AMOUNT.Lock_Received_Amount);
      --dbms_output.put_line(V_LOCK_RECEIVED_AMOUNT);

      /** MODIFY BY SUDY 2014-01-04
       *  物流模块发运计划之后，在产生发货通知单的阶段可以进行撤销，
       *  此部分撤销会营销到锁款金额以及锁定折让金额
       *  但是目前物流模块发运计划与发货通知单之间并没有直接的关系，
       *  所以重算款项根据客户去汇总发货通知单的撤销金额
       */
      /*Begin
          Select NVL(Sum(NVL(B.THIS_CANCEL_QTY,b.item_qty) * NVL(B.ITEM_PRICE,0) * (1-Nvl(B.DISCOUNT_RATE,0))),0),
                 NVL(Sum(NVL(B.THIS_CANCEL_QTY,b.item_qty) * NVL(B.ITEM_PRICE,0) * Nvl(B.DISCOUNT_RATE,0)),0)
            Into V_LOCK_RECEIVED_AMOUNT_FHCX,
                 V_LOCK_DISCOUNT_AMOUNT_FHCX
          From CIMS.t_lg_ship_doc A,CIMS.t_lg_ship_doc_line B,
               T_INV_BILL_TYPES           bill_type,  --业务单据类型
               T_INV_SOURCE_TYPES         source_type  --单据源类型
         Where A.SHIP_DOC_ID = B.SHIP_DOC_ID
           And A.DOC_STATUS = '01' --单据状态 00正常 01红冲
           And A.CUSTOMER_ID = IN_CUSTOMER_ID
           And A.ACCOUNT_CODE = I.ACCOUNT_CODE
           --And B.SALES_MAIN_TYPE = I.SALES_MAIN_TYPE
           And A.ENTITY_ID = IN_ENTITY_ID
           and B.sales_order_type_id = bill_type.bill_type_id(+)
           and bill_type.source_type_id = source_type.source_type_id
           AND source_type.SOURCE_TYPE_CODE <> '1008';
       Exception When Others Then
          V_LOCK_RECEIVED_AMOUNT_FHCX := 0 ;
          V_LOCK_DISCOUNT_AMOUNT_FHCX := 0 ;
          ROLLBACK TO SAVEPOINT_KXMX ;
          GOTO HERE ;
       End ;*/

       /** 锁定到款金额 以及 锁定折扣金额，重算方式变化
        *  更改原因：销售单生成之后，可以手动改扣率，造成从销售单取锁款金额不准确
        *  更改方案：锁定到款金额 以及 锁定折扣金额 直接从发运计划表，发货通知单表取
        *            1、发运计划表未下达的数量部分
                     2、发货通知单单未生成财务单的数量部分
        */
      /*--发运计划未下达数量产生的锁款
      Begin
        Select nvl(Sum(Nvl(T.Unaffirm_Qty,0) * Nvl(T.Item_Price,0) * (1-nvl(t.discount_rate,0))),0),
               nvl(Sum(nvl(t.unaffirm_qty,0) * nvl(t.item_price,0) * nvl(t.discount_rate,0)),0)
          Into V_LOCK_RECEIVED_AMOUNT_SHIP,
               V_LOCK_DISCOUNT_AMOUNT_SHIP
          From T_Lg_Ship_Plan t,
               T_INV_BILL_TYPES           bill_type,  --业务单据类型
               T_INV_SOURCE_TYPES         source_type  --单据源类型
         Where T.Entity_Id = IN_ENTITY_ID
           And T.Customer_Id = IN_CUSTOMER_ID
           And T.Account_Code = I.Account_Code
           And T.Sales_Main_Type = I.Sales_Main_Type
           And t.status <> '03' --撤销单据没有锁款
           And t.status <> '02' --已确认，确认则生成发货通知单。部分确认的话，则拆单，生成两个发运计划
           and t.sales_order_type_id = bill_type.bill_type_id(+)
           and bill_type.source_type_id = source_type.source_type_id
           AND source_type.SOURCE_TYPE_CODE <> '1008'
           --不包含促销品
           And t.origin_type <> '04' ;
      Exception When Others Then
        V_LOCK_RECEIVED_AMOUNT_SHIP := 0 ;
        V_LOCK_DISCOUNT_AMOUNT_SHIP := 0 ;
        ROLLBACK TO SAVEPOINT_KXMX ;
        GOTO HERE ;
      End ;

      --发货通知单未生成财务单产生的锁款
      Begin
          Select nvl(Sum((NVL(B.Item_Qty,0)- nvl(b.fact_ship_qty,0)-nvl(b.cancel_qty,0)) * NVL(B.ITEM_PRICE,0) * (1-Nvl(B.DISCOUNT_RATE,0))),0),
                 nvl(Sum((NVL(B.Item_Qty,0)- nvl(b.fact_ship_qty,0)-nvl(b.cancel_qty,0)) * NVL(B.ITEM_PRICE,0) * Nvl(B.DISCOUNT_RATE,0)),0)
            Into V_LOCK_RECEIVED_AMOUNT_DOC,
                 V_LOCK_DISCOUNT_AMOUNT_DOC
          From CIMS.t_lg_ship_doc A,CIMS.t_lg_ship_doc_line B,
               T_INV_BILL_TYPES           bill_type,  --业务单据类型
               T_INV_SOURCE_TYPES         source_type  --单据源类型
         Where A.SHIP_DOC_ID = B.SHIP_DOC_ID
           And A.DOC_STATUS <> '01' --单据状态 00正常 01红冲
           And A.CUSTOMER_ID = IN_CUSTOMER_ID
           And A.ACCOUNT_CODE = I.ACCOUNT_CODE
           And B.SALES_MAIN_TYPE = I.SALES_MAIN_TYPE
           And A.ENTITY_ID = IN_ENTITY_ID
           and B.sales_order_type_id = bill_type.bill_type_id(+)
           and bill_type.source_type_id = source_type.source_type_id
           AND source_type.SOURCE_TYPE_CODE <> '1008'
           --不包含促销品
           And b.origin_type <> '04' ;

       Exception When Others Then
          V_LOCK_RECEIVED_AMOUNT_DOC := 0 ;
          V_LOCK_DISCOUNT_AMOUNT_DOC := 0 ;
          ROLLBACK TO SAVEPOINT_KXMX ;
          GOTO HERE ;
       End ;*/


       /** modify by 苏冬渊 2015-08-26
        *  由于订单增加送审锁款，所以以上的锁款重算规则需要改动。
        *  以下为修改的过程
        */
      --发运计划未下达数量产生的锁款
      --Begin
        Select nvl(Sum(round(
                       Case 
                         --20200314 家用直发锁款调整
                         when t.origin_type = '01' and nvl(t.direct_transport_falg, 'N') = 'Y' and 
                           (select nvl(h.amount_lock_flag, 'N')
                              from t_pln_order_head h
                             where h.order_head_id = t.origin_order_id) = 'NT'
                           then
                             0
                         When t.lock_amount_flag In ('S','Y','HQ') Then
                        --add by lizhen 2015-11-30 增加月返计算
                        Nvl(T.Unaffirm_Qty,0) * Nvl(T.Item_Price,0) * (100-nvl(t.discount_rate,0) - Nvl(t.month_discount_rate, 0))/100
                       Else 0 End
                       ,2)
                       ),0),
               nvl(Sum(round(
                       Case
                         --20200314 家用直发锁款调整
                         when t.origin_type = '01' and nvl(t.direct_transport_falg, 'N') = 'Y' and 
                           (select nvl(h.amount_lock_flag, 'N')
                              from t_pln_order_head h
                             where h.order_head_id = t.origin_order_id) = 'NT'
                           then
                             0
                         When t.lock_amount_flag In ('S','Y','HQ') Then
                        nvl(t.unaffirm_qty,0) * nvl(t.item_price,0) * nvl(t.discount_rate,0)/100
                       Else 0 End
                       ,2)
                       ),0),
               nvl(Sum(round(
                       Case When t.lock_amount_flag In ('RS','RT') Then
                        --add by lizhen 2015-11-30 增加月返计算
                        Nvl(T.Unaffirm_Qty,0) * Nvl(T.Item_Price,0) * (100-nvl(t.discount_rate,0)- Nvl(t.month_discount_rate, 0))/100
                       Else 0 End
                       ,2)
                       ),0)
          Into V_LOCK_RECEIVED_AMOUNT_SHIP,
               V_LOCK_DISCOUNT_AMOUNT_SHIP,
               V_LOCK_RESOURCE_AMOUNT_SHIP
          From T_Lg_Ship_Plan t,
               T_INV_BILL_TYPES           bill_type,  --业务单据类型
               T_INV_SOURCE_TYPES         source_type  --单据源类型
               --,T_CUSTOMER_ACCOUNT A
         Where T.Entity_Id = IN_ENTITY_ID
           And T.Customer_Id = IN_CUSTOMER_ID
           --AND A.ENTITY_ID = T.ENTITY_ID AND A.ACCOUNT_CODE = T.ACCOUNT_CODE And A.ACCOUNT_ID = IN_ACCOUNT_ID
           AND T.ACCOUNT_CODE = VS_ACCOUNT_CODE
           AND (IS_SALES_MAIN_TYPE IS NULL OR T.SALES_MAIN_TYPE = IS_SALES_MAIN_TYPE)
           AND (IN_CREDIT_GROUP_ID IS NULL OR 0 >= IN_CREDIT_GROUP_ID
             OR IN_CREDIT_GROUP_ID = PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(
             IN_ENTITY_ID,IN_CUSTOMER_ID,T.SALES_MAIN_TYPE,IN_ACCOUNT_ID) )
           And t.status <> '03' --撤销单据没有锁款
           And t.status <> '02' --已确认，确认则生成发货通知单。部分确认的话，则拆单，生成两个发运计划
           and t.sales_order_type_id = bill_type.bill_type_id(+)
           and bill_type.source_type_id = source_type.source_type_id
           AND NVL(T.CUSTOMIZE_FLAG, 'N') = 'N'
           --梁颜明 2016-11-30 SOURCE_TYPE_CODE
           --=1008是计划订单确认下达选择调拨单类型，不应该被过滤
           --AND (0 >= V_CNT OR source_type.SOURCE_TYPE_CODE <> '1008')
           --不包含促销品
           --And t.origin_type <> '04'
           --锁款标志:到款锁定标志：S:送审锁款 Y:发货锁定到款 N:不锁定到款 RS:资源送审锁定到款  RT:资源提货锁定到款（标志来源单据类型）
           And t.lock_amount_flag In ('S','Y','RS','RT','HQ');
      /*Exception When Others Then
        GOTO HERE;
      End ;*/

      --发货通知单未生成财务单产生的锁款
      --Begin
          Select nvl(Sum(round(
                         Case 
                           --20200314 家用直发锁款调整
                           when b.origin_type = '01' and nvl(a.direct_transport_falg, 'N') = 'Y' and 
                             (select nvl(h.amount_lock_flag, 'N')
                                from t_pln_order_head h
                               where h.order_head_id = b.origin_order_id) = 'NT'
                             then
                               0
                           When b.lock_amount_flag In ('S','Y','HQ') Then
                          --add by lizhen 2015-11-30 增加月返计算
                          (NVL(B.Item_Qty,0)- nvl(b.fact_ship_qty,0)-nvl(b.cancel_qty,0)) * NVL(B.ITEM_PRICE,0) * (100-Nvl(B.DISCOUNT_RATE,0) - Nvl(b.month_discount_rate, 0))/100
                         Else 0 End
                         ,2)
                        ),0),
                 nvl(Sum(round(
                         Case 
                           --20200314 家用直发锁款调整
                           when b.origin_type = '01' and nvl(a.direct_transport_falg, 'N') = 'Y' and 
                             (select nvl(h.amount_lock_flag, 'N')
                                from t_pln_order_head h
                               where h.order_head_id = b.origin_order_id) = 'NT'
                             then
                               0
                           When b.lock_amount_flag In ('S','Y','HQ') Then
                          (NVL(B.Item_Qty,0)- nvl(b.fact_ship_qty,0)-nvl(b.cancel_qty,0)) * NVL(B.ITEM_PRICE,0) * Nvl(B.DISCOUNT_RATE,0)/100
                         Else 0 End
                         ,2)
                        ),0),
                 nvl(Sum(round(
                         Case When b.lock_amount_flag In ('RS','RT') Then
                          --add by lizhen 2015-11-30 增加月返计算
                          (NVL(B.Item_Qty,0)- nvl(b.fact_ship_qty,0)-nvl(b.cancel_qty,0)) * NVL(B.ITEM_PRICE,0) * (100-Nvl(B.DISCOUNT_RATE,0) - Nvl(b.month_discount_rate, 0))/100
                         Else 0 End
                         ,2)
                        ),0)
            Into V_LOCK_RECEIVED_AMOUNT_DOC,
                 V_LOCK_DISCOUNT_AMOUNT_DOC,
                 V_LOCK_RESOURCE_AMOUNT_DOC
          From CIMS.t_lg_ship_doc A,CIMS.t_lg_ship_doc_line B,
               T_INV_BILL_TYPES           bill_type,  --业务单据类型
               T_INV_SOURCE_TYPES         source_type  --单据源类型
               --,T_CUSTOMER_ACCOUNT ACC
         Where A.SHIP_DOC_ID = B.SHIP_DOC_ID
           --AND ACC.ENTITY_ID = A.ENTITY_ID AND ACC.ACCOUNT_CODE = A.ACCOUNT_CODE And ACC.ACCOUNT_ID = IN_ACCOUNT_ID
           And A.DOC_STATUS <> '01' --单据状态 00正常 01红冲
           And A.CUSTOMER_ID = IN_CUSTOMER_ID
           AND A.ACCOUNT_CODE = VS_ACCOUNT_CODE
           AND (IS_SALES_MAIN_TYPE IS NULL OR B.SALES_MAIN_TYPE = IS_SALES_MAIN_TYPE)
           AND (IN_CREDIT_GROUP_ID IS NULL OR 0 >= IN_CREDIT_GROUP_ID
             OR IN_CREDIT_GROUP_ID = PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(
             IN_ENTITY_ID,IN_CUSTOMER_ID,B.SALES_MAIN_TYPE,IN_ACCOUNT_ID) )
           And A.ENTITY_ID = IN_ENTITY_ID
           and B.sales_order_type_id = bill_type.bill_type_id(+)
           and bill_type.source_type_id = source_type.source_type_id
           AND NVL(A.CUSTOMIZE_FLAG, 'N') = 'N'
           --梁颜明 2016-11-30 SOURCE_TYPE_CODE
           --=1008是计划订单确认下达选择调拨单类型，不应该被过滤
           --AND (0 >= V_CNT OR source_type.SOURCE_TYPE_CODE <> '1008')
           --不包含促销品
           --And b.origin_type <> '04'
           --锁款标志:到款锁定标志：S:送审锁款 Y:发货锁定到款 N:不锁定到款 RS:资源送审锁定到款  RT:资源提货锁定到款（标志来源单据类型）
           And b.lock_amount_flag In ('S','Y','RS','RT','HQ');

       /*Exception When Others Then
          GOTO HERE ;
       End ;*/
       
      --Begin
          --制定发货需求计划下达（直发客户） 发货计划未确认（未生成发货通知单）
          SELECT  NVL(SUM(ROUND(
                 --锁定代理商到款(未确认数量*直发列表价*(100-直发扣率-直发月返)/100)
                 NVL(TP.UNAFFIRM_QTY, 0) * NVL(TP.TRANSFER_LIST_PRICE, 0) *
                 (100 - NVL(TP.TRANSFER_DISCOUNT_RATE, 0) -
                  NVL(TP.TRANSFER_MONTH_DISCOUNT_RATE, 0)) / 100,
                 2)),
                   0),
               NVL(SUM(ROUND(NVL(TP.UNAFFIRM_QTY, 0) * NVL(TP.TRANSFER_LIST_PRICE, 0) *
                         NVL(TP.TRANSFER_DISCOUNT_RATE, 0) / 100,
                         2)),
                   0) INTO V_LOCK_RECEIVED_AMOUNT_T_SHIP,V_LOCK_DISCOUNT_AMOUNT_T_SHIP
          FROM T_LG_SHIP_PLAN TP
         WHERE TP.TRANSFER_ENTITY_ID = IN_ENTITY_ID
           AND TP.TRANSFER_ACCOUNT_ID = IN_ACCOUNT_ID
           AND TP.TRANSFER_CUSTOMER_ID = IN_CUSTOMER_ID
           AND TP.STATUS <> '03'--撤销单据没有锁款
           AND TP.STATUS <> '02'--已确认，确认则生成发货通知单。部分确认的话，则拆单，生成两个发运计划
           --AND TP.STATUS IN ('00', '01') --撤销单据没有锁款
           AND TP.TRANSFER_LOCK_AMOUNT_FLAG = 'Y'
           AND (IS_SALES_MAIN_TYPE IS NULL OR TP.TRANSFER_ITEM_MAIN_TYPE = IS_SALES_MAIN_TYPE)
           AND (IN_CREDIT_GROUP_ID IS NULL OR 0 >= IN_CREDIT_GROUP_ID
             OR IN_CREDIT_GROUP_ID = PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(
             IN_ENTITY_ID,IN_CUSTOMER_ID,TP.TRANSFER_ITEM_MAIN_TYPE,IN_ACCOUNT_ID) )
           ;

       /*Exception When Others Then
          GOTO HERE ;
       End ;
       
      Begin*/
          --制定发货需求计划下达（直发客户） 发货通知单未生成销售单
          SELECT  NVL(SUM(ROUND( --锁定代理商到款((产品数量-已取消数量-已转采购数量)*直发列表价*(100-直发扣率-直发月返)/100)
                           (NVL(B.ITEM_QTY, 0) - NVL(B.CANCEL_QTY, 0) -
                           NVL(B.TRANSFER_TO_POX_QTY, 0)) *
                           NVL(B.TRANSFER_LIST_PRICE, 0) *
                           (100 - NVL(B.TRANSFER_DISCOUNT_RATE, 0) -
                           NVL(B.TRANSFER_MONTH_DISCOUNT_RATE, 0)) / 100,
                           2)),
                     0) LOCKED_AMOUNT,
                 NVL(SUM(ROUND((NVL(B.ITEM_QTY, 0) - NVL(B.FACT_SHIP_QTY, 0) -
                           NVL(B.CANCEL_QTY, 0) - NVL(B.TRANSFER_TO_POX_QTY, 0)) *
                           NVL(B.TRANSFER_LIST_PRICE, 0) *
                           NVL(B.TRANSFER_DISCOUNT_RATE, 0) / 100,
                           2)),
                     0) INTO V_LOCK_RECEIVED_AMOUNT_T_DOC,V_LOCK_DISCOUNT_AMOUNT_T_DOC
          FROM T_LG_SHIP_DOC A --发货通知单头
           INNER JOIN T_LG_SHIP_DOC_LINE B
              ON (A.SHIP_DOC_ID = B.SHIP_DOC_ID) --发货通知单行
         WHERE A.DOC_STATUS <> '01' --单据状态 00正常 01红冲
         AND B.TRANSFER_LOCK_AMOUNT_FLAG = 'Y'
         AND A.TRANSFER_ENTITY_ID = IN_ENTITY_ID
         AND A.TRANSFER_ACCOUNT_ID = IN_ACCOUNT_ID
         AND A.TRANSFER_CUSTOMER_ID = IN_CUSTOMER_ID
         AND (IS_SALES_MAIN_TYPE IS NULL OR B.TRANSFER_ITEM_MAIN_TYPE = IS_SALES_MAIN_TYPE)
         AND (IN_CREDIT_GROUP_ID IS NULL OR 0 >= IN_CREDIT_GROUP_ID
             OR IN_CREDIT_GROUP_ID = PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(
             IN_ENTITY_ID,IN_CUSTOMER_ID,B.TRANSFER_ITEM_MAIN_TYPE,IN_ACCOUNT_ID) )
           ;
       /*Exception When Others Then
          GOTO HERE ;
       End ;*/


      --送审锁款方式下，已经送审未评审产生的锁款
      --Begin
          Select nvl(Sum(round(
                         Case
                           when nvl(b.order_line_state,LG_LINE_STATE_NORMAL)=LG_LINE_STATE_CLOSED then
                             0
                           --20200314 家用直发锁款调整
                           When (a.lock_amount_flag = 'S' AND NOT(NVL(A.DOWN_PAY_SCALE,-1) >= 0)) 
                             OR NVL(B.IS_LOCK_AMOUNT, 'N') = 'Y' Then
                          --add by lizhen 2015-11-30 T+3订单回写取消数量，并会释放款项，所以取消数量重算时不计入锁款
                          --(NVL(B.Quantity,0)- nvl(B.AFFIRMED_QUANTITY,0) - Nvl(B.Cancel_Qty, 0))
                          --MODI BY LIZHEN 2016-05-12 增加已引APS产能可视状态(2225)数据计算锁款
                          --ADD YBY LIANGYM2 2017-6-18 已送审状态下销司主体结算到总部主体 Center_Affirm_Quantity可能发生变化
                          (Case When a.order_head_state In ('20', '2225', '1455') and nvl(b.order_line_state,LG_LINE_STATE_NORMAL)<>LG_LINE_STATE_CLOSED Then
                                  NVL(DECODE(A.HQ_LG_ORDER_HEAD_ID,NULL,B.QUANTITY,0,B.QUANTITY,B.CENTER_AFFIRM_QUANTITY), 0)- nvl(B.AFFIRMED_QUANTITY,0) - Nvl(B.Cancel_Qty, 0)
                                  -(NVL(b.transfer_hq_affirmed_qty,0)-nvl(b.sended_qty,0))
                                  -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                When a.order_head_state In ('381', '679') and nvl(b.order_line_state,LG_LINE_STATE_NORMAL)<>LG_LINE_STATE_CLOSED Then
                                  NVL(B.Center_Affirm_Quantity, 0)- nvl(B.AFFIRMED_QUANTITY,0) - Nvl(B.Cancel_Qty, 0)
                                  -(NVL(b.transfer_hq_affirmed_qty,0)-nvl(b.sended_qty,0))
                                  -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                Else 0 End)
                          --20180105 hejy3 增加订金发货锁全款处理
                          /*when a.lock_amount_flag = 'S' AND A.DOWN_PAY_SCALE >= 0 THEN
                            NVL(b.transfer_hq_affirmed_qty,0)-nvl(b.sended_qty,0)*/
                         Else 0 End
                           * DECODE(B.PROJECT_ORDER_TYPE,NULL,NVL(B.List_Price,0),NVL(B.APPLY_LIST_PRICE,0))
                              --add by lizhen 2015-11-30 增加月返计算
                              * (100-DECODE(B.PROJECT_ORDER_TYPE,NULL,Nvl(B.Discount_Rate,0),NVL(B.APPLY_DISCOUNT_RATE,0)) - Nvl(b.ordered_discount_rate, 0))/100
                         ,2)
                        ),0),
                 nvl(Sum(round(
                         Case
                           when nvl(b.order_line_state,LG_LINE_STATE_NORMAL)=LG_LINE_STATE_CLOSED then
                             0
                           --20200314 家用直发锁款调整
                           When (a.lock_amount_flag = 'S' AND NOT(NVL(A.DOWN_PAY_SCALE,-1) >= 0)) 
                             OR NVL(B.IS_LOCK_AMOUNT, 'N') = 'Y' Then
                          --add by lizhen 2015-11-30 T+3订单回写取消数量，并会释放款项，所以取消数量重算时不计入锁款
                          --(NVL(B.Quantity,0)- nvl(B.AFFIRMED_QUANTITY,0) - Nvl(B.cancel_qty, 0))
                          --MODI BY LIZHEN 2016-05-12 增加已引APS产能可视状态(2225)数据计算锁款
                          (Case When a.order_head_state In ('20', '2225', '1455') and nvl(b.order_line_state,LG_LINE_STATE_NORMAL)<>LG_LINE_STATE_CLOSED Then
                                  NVL(DECODE(A.HQ_LG_ORDER_HEAD_ID,NULL,B.QUANTITY,0,B.QUANTITY,B.CENTER_AFFIRM_QUANTITY), 0)- nvl(B.AFFIRMED_QUANTITY,0) - Nvl(B.Cancel_Qty, 0)
                                  -(NVL(b.transfer_hq_affirmed_qty,0)-nvl(b.sended_qty,0))
                                  -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                When a.order_head_state In ('381', '679') and nvl(b.order_line_state,LG_LINE_STATE_NORMAL)<>LG_LINE_STATE_CLOSED Then
                                  NVL(B.Center_Affirm_Quantity, 0)- nvl(B.AFFIRMED_QUANTITY,0) - Nvl(B.Cancel_Qty, 0)
                                  -(NVL(b.transfer_hq_affirmed_qty,0)-nvl(b.sended_qty,0))
                                  -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                Else 0 End)
                         --20180105 hejy3 增加订金发货锁全款处理
                          /*when a.lock_amount_flag = 'S' AND A.DOWN_PAY_SCALE >= 0 THEN
                            NVL(b.transfer_hq_affirmed_qty,0)-nvl(b.sended_qty,0)*/
                         Else 0 End
                           * DECODE(B.PROJECT_ORDER_TYPE,NULL,NVL(B.List_Price,0),NVL(B.APPLY_LIST_PRICE,0))
                            * DECODE(B.PROJECT_ORDER_TYPE,NULL,Nvl(B.Discount_Rate,0),NVL(B.APPLY_DISCOUNT_RATE,0))/100
                         ,2)
                        ),0),
                 nvl(Sum(round(
                         Case
                           when nvl(b.order_line_state,LG_LINE_STATE_NORMAL)=LG_LINE_STATE_CLOSED then
                             0
                           When a.lock_amount_flag = 'RS' Then
                          --add by lizhen 2015-11-30 T+3订单回写取消数量，并会释放款项，所以取消数量重算时不计入锁款
                          --(NVL(B.Quantity,0)- nvl(B.AFFIRMED_QUANTITY,0) - Nvl(B.Cancel_Qty, 0))
                          --MODI BY LIZHEN 2016-05-12 增加已引APS产能可视状态(2225)数据计算锁款
                          (Case When a.order_head_state In ('20', '2225', '1455') and nvl(b.order_line_state,LG_LINE_STATE_NORMAL)<>LG_LINE_STATE_CLOSED Then
                                  NVL(DECODE(A.HQ_LG_ORDER_HEAD_ID,NULL,B.QUANTITY,0,B.QUANTITY,B.CENTER_AFFIRM_QUANTITY), 0)- nvl(B.AFFIRMED_QUANTITY,0) - Nvl(B.Cancel_Qty, 0)
                                  -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                When a.order_head_state In ('381', '679') and nvl(b.order_line_state,LG_LINE_STATE_NORMAL)<>LG_LINE_STATE_CLOSED Then
                                  NVL(B.Center_Affirm_Quantity, 0)- nvl(B.AFFIRMED_QUANTITY,0) - Nvl(B.Cancel_Qty, 0)
                                  -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                Else 0 End)
                            * DECODE(B.PROJECT_ORDER_TYPE,NULL,NVL(B.List_Price,0),NVL(B.APPLY_LIST_PRICE,0))
                            --add by lizhen 2015-11-30 增加月返计算
                            * (100-DECODE(B.PROJECT_ORDER_TYPE,Null,Nvl(B.Discount_Rate,0),NVL(B.APPLY_DISCOUNT_RATE,0))- Nvl(b.ordered_discount_rate, 0))/100
                         Else 0 End
                         ,2)
                        ),0),
                        --2016-09-13 add by liangym2 锁款拆成全额以及订金部分 V_LOCK_RECEIVED_AMOUNT_SS_DP
               nvl(Sum((A.DOWN_PAY_SCALE / 100) * round(Case
                               --20200314 家用直发锁款调整
                               when nvl(b.order_line_state,LG_LINE_STATE_NORMAL)=LG_LINE_STATE_CLOSED 
                                 OR NVL(B.IS_LOCK_AMOUNT, 'N') = 'Y' then
                                 0
                               When a.lock_amount_flag = 'S' AND A.DOWN_PAY_SCALE > 0 Then
                               --add by lizhen 2015-11-30 T+3订单回写取消数量，并会释放款项，所以取消数量重算时不计入锁款
                               --(NVL(B.Quantity,0)- nvl(B.AFFIRMED_QUANTITY,0) - Nvl(B.Cancel_Qty, 0))
                               --MODI BY LIZHEN 2016-05-12 增加已引APS产能可视状态(2225)数据计算锁款
                                (Case
                                  WHEN NVL(B.IS_LOCK_AMOUNT, 'N') = 'NT' THEN
                                    NVL(B.CENTER_AFFIRM_QUANTITY, 0) - NVL(B.CANCEL_QTY, 0)
                                  When a.order_head_state In ('20', '2225', '1455') and nvl(b.order_line_state,LG_LINE_STATE_NORMAL)<>LG_LINE_STATE_CLOSED Then
                                   NVL(DECODE(A.HQ_LG_ORDER_HEAD_ID,NULL,B.QUANTITY,0,B.QUANTITY,B.CENTER_AFFIRM_QUANTITY), 0) - nvl(B.AFFIRMED_QUANTITY, 0) -
                                   Nvl(B.Cancel_Qty, 0) - (NVL(B.transfer_hq_affirmed_qty,0)-NVL(B.SENDED_QTY,0)) --20180105 hejy3 增加订金发货锁全款处理
                                   -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                  When a.order_head_state In ('381', '679') and nvl(b.order_line_state,LG_LINE_STATE_NORMAL)<>LG_LINE_STATE_CLOSED Then
                                   NVL(B.Center_Affirm_Quantity, 0) - nvl(B.AFFIRMED_QUANTITY, 0) - Nvl(B.Cancel_Qty, 0)
                                   - (NVL(B.transfer_hq_affirmed_qty,0)-NVL(B.SENDED_QTY,0))
                                   -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                  Else
                                   0
                                End) * DECODE(B.PROJECT_ORDER_TYPE,
                                              NULL,
                                              NVL(B.List_Price, 0),
                                              NVL(B.APPLY_LIST_PRICE, 0))
                               --add by lizhen 2015-11-30 增加月返计算
                                * (100 - DECODE(B.PROJECT_ORDER_TYPE,
                                                NULL,
                                                Nvl(B.Discount_Rate, 0),
                                                NVL(B.APPLY_DISCOUNT_RATE, 0)) -
                                Nvl(b.ordered_discount_rate, 0)) / 100
                               WHEN a.lock_amount_flag = 'S' AND A.DOWN_PAY_SCALE = 0 THEN
                                 0
                               Else 0 End
                         ,2)
                        ),0),
                 nvl(Sum((A.DOWN_PAY_SCALE / 100) * round(
                         Case
                           --20200314 家用直发锁款调整
                           when nvl(b.order_line_state,LG_LINE_STATE_NORMAL)=LG_LINE_STATE_CLOSED 
                             OR NVL(B.IS_LOCK_AMOUNT, 'N') = 'Y' then
                             0
                           When a.lock_amount_flag = 'S' AND A.DOWN_PAY_SCALE > 0 Then
                          --add by lizhen 2015-11-30 T+3订单回写取消数量，并会释放款项，所以取消数量重算时不计入锁款
                          --(NVL(B.Quantity,0)- nvl(B.AFFIRMED_QUANTITY,0) - Nvl(B.cancel_qty, 0))
                          --MODI BY LIZHEN 2016-05-12 增加已引APS产能可视状态(2225)数据计算锁款
                          --如果订单头状态为20,1455,2225，而且订单头的hq_lg_order_head_id不为空，则取中心评审数量
                          --如果订单头状态为20,1455,2225，而且订单头的hq_lg_order_head_id为空，则取申请数量
                          --NVL(B.Center_Affirm_Quantity,B.Quantity)
                          (Case 
                            WHEN NVL(B.IS_LOCK_AMOUNT, 'N') = 'NT' THEN
                              NVL(B.CENTER_AFFIRM_QUANTITY, 0) - NVL(B.CANCEL_QTY, 0)
                            When a.order_head_state In ('20', '2225', '1455') and nvl(b.order_line_state,LG_LINE_STATE_NORMAL)<>LG_LINE_STATE_CLOSED Then
                                  NVL(DECODE(A.HQ_LG_ORDER_HEAD_ID,NULL,B.QUANTITY,0,B.QUANTITY,B.CENTER_AFFIRM_QUANTITY), 0)- nvl(B.AFFIRMED_QUANTITY,0) - Nvl(B.Cancel_Qty, 0)
                                 - (NVL(B.transfer_hq_affirmed_qty,0)-NVL(B.SENDED_QTY,0)) --20180105 hejy3 增加订金发货锁全款处理
                                 -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                When a.order_head_state In ('381', '679') and nvl(b.order_line_state,LG_LINE_STATE_NORMAL)<>LG_LINE_STATE_CLOSED Then
                                  NVL(B.Center_Affirm_Quantity, 0)- nvl(B.AFFIRMED_QUANTITY,0) - Nvl(B.Cancel_Qty, 0)
                                  - (NVL(B.transfer_hq_affirmed_qty,0)-NVL(B.SENDED_QTY,0))
                                  -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                Else 0 End)
                            * DECODE(B.PROJECT_ORDER_TYPE,NULL,NVL(B.List_Price,0),NVL(B.APPLY_LIST_PRICE,0))
                            * DECODE(B.PROJECT_ORDER_TYPE,NULL,Nvl(B.Discount_Rate,0),NVL(B.APPLY_DISCOUNT_RATE,0))/100
                         Else 0 End
                         ,2)
                        ),0)
            Into
                 V_LOCK_RECEIVED_AMOUNT_SS ,
                 V_LOCK_DISCOUNT_AMOUNT_SS ,
                 V_LOCK_RESOURCE_AMOUNT_SS,
                 V_LOCK_RECEIVED_AMOUNT_SS_DP,
                 V_LOCK_DISCOUNT_AMOUNT_SS_DP
          From CIMS.t_Pln_Lg_Order_Head A,CIMS.t_Pln_Lg_Order_Line B
         Where a.order_head_id = b.order_head_id
           --modi by lizhen 2015-11-30 增加中心发货状态单据
           --MODI BY LIZHEN 2016-05-12 增加已引APS产能可视状态数据计算锁款
           And a.order_head_state In ('20', '23', '381', '679', '1455', '2225', '304')
           And a.entity_id = IN_ENTITY_ID
           And a.customer_id = IN_CUSTOMER_ID
           And a.account_id = IN_ACCOUNT_ID
           --And Nvl(b.order_line_state, 'NORMAL') <> 'CLOSED' --ADD BY LIZHEN 2016-06-20已关闭行不计算
           --And Nvl(a.sales_main_type, b.sales_main_type) = i.sales_main_type --add by lizhen 2015-09-03
           AND (IS_SALES_MAIN_TYPE IS NULL OR B.SALES_MAIN_TYPE = IS_SALES_MAIN_TYPE)
           AND (IN_CREDIT_GROUP_ID IS NULL OR 0 >= IN_CREDIT_GROUP_ID
             OR IN_CREDIT_GROUP_ID = PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(
             IN_ENTITY_ID,IN_CUSTOMER_ID,B.SALES_MAIN_TYPE,IN_ACCOUNT_ID) )
           AND NVL(A.CUSTOMIZE_FLAG, 'N') = 'N'
           And a.lock_amount_flag In ('S','RS');
       
      --hejy3 送总部评审锁款方式
      --Begin
          Select nvl(Sum(round(
                         Case
                           when nvl(b.order_line_state,LG_LINE_STATE_NORMAL)=LG_LINE_STATE_CLOSED then
                             0
                           --20200314 家用直发锁款调整
                           When NOT(NVL(A.DOWN_PAY_SCALE,-1) >= 0) 
                             OR NVL(B.IS_LOCK_AMOUNT, 'N') = 'Y' Then
                          (Case When (a.order_head_state In ('20', '2225', '1455') and ha.SUBMIT_TO_HQ_FLAG = 'Y')
                                 or a.SUBMIT_TO_HQ_FLAG = 'Y' Then
                                  NVL(B.CENTER_AFFIRM_QUANTITY, 0)- nvl(B.AFFIRMED_QUANTITY,0) - Nvl(B.Cancel_Qty, 0)
                                  -(NVL(b.transfer_hq_affirmed_qty,0)-nvl(b.sended_qty,0))
                                  -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                Else 0 End)
                         Else 0 End
                           * DECODE(B.PROJECT_ORDER_TYPE,NULL,NVL(B.List_Price,0),NVL(B.APPLY_LIST_PRICE,0))
                              --add by lizhen 2015-11-30 增加月返计算
                              * (100-DECODE(B.PROJECT_ORDER_TYPE,NULL,Nvl(B.Discount_Rate,0),NVL(B.APPLY_DISCOUNT_RATE,0)) - Nvl(b.ordered_discount_rate, 0))/100
                         ,2)
                        ),0),
                 nvl(Sum(round(
                         Case
                           when nvl(b.order_line_state,LG_LINE_STATE_NORMAL)=LG_LINE_STATE_CLOSED then
                             0
                           --20200314 家用直发锁款调整
                           When NOT(NVL(A.DOWN_PAY_SCALE,-1) >= 0) 
                             OR NVL(B.IS_LOCK_AMOUNT, 'N') = 'Y' Then
                          (Case When (a.order_head_state In ('20', '2225', '1455') and ha.SUBMIT_TO_HQ_FLAG = 'Y')
                                 or a.SUBMIT_TO_HQ_FLAG = 'Y' Then
                                  NVL(B.CENTER_AFFIRM_QUANTITY, 0)- nvl(B.AFFIRMED_QUANTITY,0) - Nvl(B.Cancel_Qty, 0)
                                  -(NVL(b.transfer_hq_affirmed_qty,0)-nvl(b.sended_qty,0))
                                  -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                Else 0 End)
                         Else 0 End
                           * DECODE(B.PROJECT_ORDER_TYPE,NULL,NVL(B.List_Price,0),NVL(B.APPLY_LIST_PRICE,0))
                            * DECODE(B.PROJECT_ORDER_TYPE,NULL,Nvl(B.Discount_Rate,0),NVL(B.APPLY_DISCOUNT_RATE,0))/100
                         ,2)
                        ),0),
                 0,
                        --2016-09-13 add by liangym2 锁款拆成全额以及订金部分 V_LOCK_RECEIVED_AMOUNT_SS_DP
               nvl(Sum((A.DOWN_PAY_SCALE / 100) * round(Case
                               --20200314 家用直发锁款调整
                               when nvl(b.order_line_state,LG_LINE_STATE_NORMAL)=LG_LINE_STATE_CLOSED 
                                 OR NVL(B.IS_LOCK_AMOUNT, 'N') = 'Y' then
                                 0
                               When A.DOWN_PAY_SCALE > 0 Then
                               (Case 
                                 WHEN NVL(B.IS_LOCK_AMOUNT, 'N') = 'NT' THEN
                                   NVL(B.CENTER_AFFIRM_QUANTITY, 0) - NVL(B.CANCEL_QTY, 0)
                                 When (a.order_head_state In ('20', '2225', '1455') and ha.SUBMIT_TO_HQ_FLAG = 'Y')
                                 or a.SUBMIT_TO_HQ_FLAG = 'Y' Then
                                  NVL(B.CENTER_AFFIRM_QUANTITY, 0)- nvl(B.AFFIRMED_QUANTITY,0) - Nvl(B.Cancel_Qty, 0)
                                  -(NVL(b.transfer_hq_affirmed_qty,0)-nvl(b.sended_qty,0))
                                  -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                Else 0 End) * DECODE(B.PROJECT_ORDER_TYPE,
                                              NULL,
                                              NVL(B.List_Price, 0),
                                              NVL(B.APPLY_LIST_PRICE, 0))
                               --add by lizhen 2015-11-30 增加月返计算
                                * (100 - DECODE(B.PROJECT_ORDER_TYPE,
                                                NULL,
                                                Nvl(B.Discount_Rate, 0),
                                                NVL(B.APPLY_DISCOUNT_RATE, 0)) -
                                Nvl(b.ordered_discount_rate, 0)) / 100
                               WHEN A.DOWN_PAY_SCALE = 0 THEN
                                 0
                               Else 0 End
                         ,2)
                        ),0),
                 nvl(Sum((A.DOWN_PAY_SCALE / 100) * round(
                         Case
                           --20200314 家用直发锁款调整
                           when nvl(b.order_line_state,LG_LINE_STATE_NORMAL)=LG_LINE_STATE_CLOSED 
                             OR NVL(B.IS_LOCK_AMOUNT, 'N') = 'Y' then
                             0
                           When A.DOWN_PAY_SCALE > 0 Then
                          (Case
                             WHEN NVL(B.IS_LOCK_AMOUNT, 'N') = 'NT' THEN
                               NVL(B.CENTER_AFFIRM_QUANTITY, 0) - NVL(B.CANCEL_QTY, 0) 
                             When (a.order_head_state In ('20', '2225', '1455') and ha.SUBMIT_TO_HQ_FLAG = 'Y')
                                 or a.SUBMIT_TO_HQ_FLAG = 'Y' Then
                                  NVL(B.CENTER_AFFIRM_QUANTITY, 0)- nvl(B.AFFIRMED_QUANTITY,0) - Nvl(B.Cancel_Qty, 0)
                                  -(NVL(b.transfer_hq_affirmed_qty,0)-nvl(b.sended_qty,0))
                                  -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                Else 0 End)
                            * DECODE(B.PROJECT_ORDER_TYPE,NULL,NVL(B.List_Price,0),NVL(B.APPLY_LIST_PRICE,0))
                            * DECODE(B.PROJECT_ORDER_TYPE,NULL,Nvl(B.Discount_Rate,0),NVL(B.APPLY_DISCOUNT_RATE,0))/100
                         Else 0 End
                         ,2)
                        ),0)
            Into
                 V_LOCK_RECEIVED_AMOUNT_HQ ,
                 V_LOCK_DISCOUNT_AMOUNT_HQ ,
                 V_LOCK_RESOURCE_AMOUNT_HQ,
                 V_LOCK_RECEIVED_AMOUNT_HQ_DP,
                 V_LOCK_DISCOUNT_AMOUNT_HQ_DP
          From CIMS.t_Pln_Lg_Order_Head A,CIMS.t_Pln_Lg_Order_Line B,CIMS.t_Pln_Lg_Order_Head HA
         Where a.order_head_id = b.order_head_id
           --modi by lizhen 2015-11-30 增加中心发货状态单据
           --MODI BY LIZHEN 2016-05-12 增加已引APS产能可视状态数据计算锁款
           And a.order_head_state In ('20', '23', '381', '679', '1455', '2225', '304')
           And a.entity_id = IN_ENTITY_ID
           And a.customer_id = IN_CUSTOMER_ID
           And a.account_id = IN_ACCOUNT_ID
           AND A.HQ_LG_ORDER_HEAD_ID = HA.ORDER_HEAD_ID(+)
           --And Nvl(b.order_line_state, 'NORMAL') <> 'CLOSED' --ADD BY LIZHEN 2016-06-20已关闭行不计算
           --And Nvl(a.sales_main_type, b.sales_main_type) = i.sales_main_type --add by lizhen 2015-09-03
           AND (IS_SALES_MAIN_TYPE IS NULL OR B.SALES_MAIN_TYPE = IS_SALES_MAIN_TYPE)
           AND (IN_CREDIT_GROUP_ID IS NULL OR 0 >= IN_CREDIT_GROUP_ID
             OR IN_CREDIT_GROUP_ID = PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(
             IN_ENTITY_ID,IN_CUSTOMER_ID,B.SALES_MAIN_TYPE,IN_ACCOUNT_ID) )
           AND NVL(A.CUSTOMIZE_FLAG, 'N') = 'N'
           And a.lock_amount_flag In ('HQ');

       /*Exception When Others Then
          GOTO HERE ;
       End ;*/
       
       --针对已结转总部主体且发货锁款的提货订单锁款
      --Begin
      --锁定客户到款((跨主体总部评审数量-已评审数量+申请数量-送总部评审数量-已取消数量)*价格*(100-扣率-月返)/100)
          Select nvl(Sum(round(
                         Case When NVL(B.IS_LOCK_AMOUNT, 'N') <> 'NT' Then
                          (NVL(B.transfer_hq_affirmed_qty,0)-NVL(B.SENDED_QTY,0))
                              * DECODE(B.PROJECT_ORDER_TYPE,NULL,NVL(B.List_Price,0),NVL(B.APPLY_LIST_PRICE,0))
                              --add by lizhen 2015-11-30 增加月返计算
                              * (100-DECODE(B.PROJECT_ORDER_TYPE,NULL,Nvl(B.Discount_Rate,0),NVL(B.APPLY_DISCOUNT_RATE,0)) - Nvl(b.ordered_discount_rate, 0))/100
                         Else 0 End
                         ,2)
                        ),0),
                 nvl(Sum(round(Case When NVL(B.IS_LOCK_AMOUNT, 'N') <> 'NT' Then
                          (NVL(B.transfer_hq_affirmed_qty,0)-NVL(B.SENDED_QTY,0))
                            * DECODE(B.PROJECT_ORDER_TYPE,NULL,NVL(B.List_Price,0),NVL(B.APPLY_LIST_PRICE,0))
                            * DECODE(B.PROJECT_ORDER_TYPE,NULL,Nvl(B.Discount_Rate,0),NVL(B.APPLY_DISCOUNT_RATE,0))/100
                         Else 0 End
                         ,2)
                        ),0)
            Into
                 V_LOCK_RECEIVED_AMOUNT_PS ,
                 V_LOCK_DISCOUNT_AMOUNT_PS
          From CIMS.t_Pln_Lg_Order_Head A,CIMS.t_Pln_Lg_Order_Line B
         Where a.order_head_id = b.order_head_id
           And a.order_head_state In ('20', '23', '381', '679', '1455', '2225', '304')
           And a.entity_id = IN_ENTITY_ID
           And a.customer_id = IN_CUSTOMER_ID
           And a.account_id = IN_ACCOUNT_ID
           --And Nvl(b.order_line_state, 'NORMAL') <> 'CLOSED'
           AND (IS_SALES_MAIN_TYPE IS NULL OR B.SALES_MAIN_TYPE = IS_SALES_MAIN_TYPE)
           AND (IN_CREDIT_GROUP_ID IS NULL OR 0 >= IN_CREDIT_GROUP_ID
             OR IN_CREDIT_GROUP_ID = PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(
             IN_ENTITY_ID,IN_CUSTOMER_ID,B.SALES_MAIN_TYPE,IN_ACCOUNT_ID) )
           AND B.TRANSFER_HQ_AFFIRMED_QTY > 0
           AND NVL(A.CUSTOMIZE_FLAG, 'N') = 'N'
           --AND A.HQ_LG_ORDER_HEAD_ID IS NOT NULL
           --And a.lock_amount_flag = 'Y'
           ;

       --add by lizhen 2015-12-07 增加计划订单送审锁款，未下达到物流的金额
       --UPDATE BY LHW 2016-03-04
       --Begin
            Select Nvl(Sum(round(
                        (Case
                           when nvl(poh.down_pay_scale, -1) < 0 then
                             Case
                              When Poh.Form_State Not In
                                   ('23', '32', '248', '303', '304', '306') Then
                               Nvl(Pol.Apply_Qty, 0) - Nvl(Pol.Carry_Qty, 0) - Nvl(Pol.Cancel_Inv_Check_Qty, 0)
                                 - Nvl(Pol.Cancel_Inv_In_Qty, 0)
                              When Poh.Form_State In ('23', '32') Then
                               Nvl(Pol.Can_Produce_Qty, 0) + Nvl(Pol.Inv_Affirm_Qty, 0)
                               - Nvl(Pol.Carry_Qty, 0) - Nvl(Pol.Cancel_Inv_Check_Qty, 0)
                               - Nvl(Pol.Cancel_Inv_In_Qty, 0)
                              Else
                               0
                             End
                           else
                             0
                         end
                    ) * Pol.Item_Price *
                    (100 - Nvl(Pol.Discount_Rate, 0) -
                    Nvl(Pol.Ordered_Discount_Rate, 0)) / 100
                    ,2)
                    ), 0) Lock_Amount,
                Nvl(Sum(round(
                    (Case
                       when nvl(poh.down_pay_scale, -1) < 0 then
                         Case
                          When Poh.Form_State Not In
                               ('23', '32', '248', '303', '304') Then--, '306' 306是已完成状态，不锁款，暂时不改动
                           Nvl(Pol.Apply_Qty, 0) - Nvl(Pol.Carry_Qty, 0) - Nvl(Pol.Cancel_Inv_Check_Qty, 0)
                           - Nvl(Pol.Cancel_Inv_Check_Qty, 0)
                          When Poh.Form_State In ('23', '32', '306') Then--306是已完成状态，不锁款，暂时不改动
                           Nvl(Pol.Can_Produce_Qty, 0) + Nvl(Pol.Inv_Affirm_Qty, 0)
                           - Nvl(Pol.Carry_Qty, 0) - Nvl(Pol.Cancel_Inv_Check_Qty, 0)
                           - Nvl(Pol.Cancel_Inv_Check_Qty, 0)
                          Else
                           0
                         End
                       else
                         0
                     end
                    ) * Pol.Item_Price *
                    Nvl(Pol.Discount_Rate, 0) / 100
                    ,2)
                    ), 0) Lock_Discount_Amount,
                    0 Lock_Resource_Amount,
                Nvl(Sum((poh.down_pay_scale/100)*round(
                        (case
                           when poh.down_pay_scale > 0 then
                             Case
                              When Poh.Form_State Not In
                                   ('23', '32', '248', '303', '304', '306') Then
                               Nvl(Pol.Apply_Qty, 0) - Nvl(Pol.Carry_Qty, 0) - Nvl(Pol.Cancel_Inv_Check_Qty, 0)
                                 - Nvl(Pol.Cancel_Inv_In_Qty, 0)
                              When Poh.Form_State In ('23', '32') Then
                               Nvl(Pol.Can_Produce_Qty, 0) + Nvl(Pol.Inv_Affirm_Qty, 0)
                               - Nvl(Pol.Carry_Qty, 0) - Nvl(Pol.Cancel_Inv_Check_Qty, 0)
                               - Nvl(Pol.Cancel_Inv_In_Qty, 0)
                              Else
                               0
                             End
                           else
                             0
                         end
                         ) * Pol.Item_Price *
                    (100 - Nvl(Pol.Discount_Rate, 0) -
                    Nvl(Pol.Ordered_Discount_Rate, 0)) / 100
                    ,2)
                    ), 0) Lock_Downpay_Amount,
                Nvl(Sum((poh.down_pay_scale/100)*round(
                    (case
                       when poh.down_pay_scale > 0 then
                         Case
                          When Poh.Form_State Not In
                               ('23', '32', '248', '303', '304') Then--, '306' 306是已完成状态，不锁款，暂时不改动
                           Nvl(Pol.Apply_Qty, 0) - Nvl(Pol.Carry_Qty, 0) - Nvl(Pol.Cancel_Inv_Check_Qty, 0)
                           - Nvl(Pol.Cancel_Inv_Check_Qty, 0)
                          When Poh.Form_State In ('23', '32', '306') Then--306是已完成状态，不锁款，暂时不改动
                           Nvl(Pol.Can_Produce_Qty, 0) + Nvl(Pol.Inv_Affirm_Qty, 0)
                           - Nvl(Pol.Carry_Qty, 0) - Nvl(Pol.Cancel_Inv_Check_Qty, 0)
                           - Nvl(Pol.Cancel_Inv_Check_Qty, 0)
                          Else
                           0
                         End
                       else
                         0
                     end
                    ) * Pol.Item_Price *
                    Nvl(Pol.Discount_Rate, 0) / 100
                    ,2)
                    ), 0) Lock_Downpay_Disamount
          Into
            V_LOCK_RECEIVED_AMOUNT_PLN,
            V_LOCK_DISCOUNT_AMOUNT_PLN,
            V_LOCK_RESOURCE_AMOUNT_PLN,
            V_LOCK_RECEIVED_AMOUNT_PLN_DP,
            V_LOCK_DISCOUNT_AMOUNT_PLN_DP
           From t_Pln_Order_Head Poh,
                t_Pln_Order_Line Pol,
                t_Pln_Order_Type Pot
          Where Pot.Order_Type_Id = Poh.Order_Type_Id
            And Poh.Order_Head_Id = Pol.Order_Head_Id
            And Nvl(Poh.Lock_Amount_Flag, 'N') = 'S'
            And Poh.Form_State Not In ('19', '248', '303', '304', '305')
            And Poh.entity_id = IN_ENTITY_ID
            And Poh.customer_id = IN_CUSTOMER_ID
            And Poh.account_id = IN_ACCOUNT_ID
            --2017-05-18 梁颜明 锁款大类取订单行 如果为空 则取产品大类
            AND (IS_SALES_MAIN_TYPE IS NULL
            OR POL.SALES_MAIN_TYPE = IS_SALES_MAIN_TYPE
            OR (POL.SALES_MAIN_TYPE IS NULL
            AND EXISTS (SELECT 1 FROM t_Bd_Item BI
            WHERE Bi.Item_Id = Pol.Item_Id
            And Bi.Entity_Id = IN_ENTITY_ID
            AND Bi.sales_main_type = IS_SALES_MAIN_TYPE)
            )
            )
            AND (IN_CREDIT_GROUP_ID IS NULL OR 0 >= IN_CREDIT_GROUP_ID
             OR (POL.SALES_MAIN_TYPE IS NOT NULL
             AND IN_CREDIT_GROUP_ID = PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(
             IN_ENTITY_ID,IN_CUSTOMER_ID,POL.SALES_MAIN_TYPE,IN_ACCOUNT_ID)
             ) OR (
             POL.SALES_MAIN_TYPE IS NULL
            AND EXISTS (SELECT 1 FROM t_Bd_Item BI
            WHERE Bi.Item_Id = Pol.Item_Id
            And Bi.Entity_Id = IN_ENTITY_ID
            AND IN_CREDIT_GROUP_ID = PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(
             IN_ENTITY_ID,IN_CUSTOMER_ID,BI.SALES_MAIN_TYPE,IN_ACCOUNT_ID))
            )
            
            )
            ;
       /*Exception
         When Others Then
           GOTO HERE ;
       End;*/

      --从政策转资源返利单，获取资源金额
      --Begin
         Select nvl(sum(b.discount_amount),0)
           Into V_RESOURCE_AMOUNT
          From T_Pol_Discount_Order a, T_Pol_Discount_Lines b
         Where A.Discount_Order_Id = B.Discount_Order_Id
           And A.Discount_Method = '7' --折让方式：7：政策转资源
           And A.Status = '9' --已确认
           And A.ORDER_TYPE_ID In (1, 2) --1：返利单 2：红冲单
           And A.ENTITY_ID = IN_ENTITY_ID
           And A.CUSTOMER_ID = IN_CUSTOMER_ID
           And A.ACCOUNT_ID = IN_ACCOUNT_ID
           And (IS_SALES_MAIN_TYPE IS NULL OR A.SALES_MAIN_TYPE = IS_SALES_MAIN_TYPE)
           AND (IN_CREDIT_GROUP_ID IS NULL OR 0 >= IN_CREDIT_GROUP_ID
             OR IN_CREDIT_GROUP_ID = PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(
             IN_ENTITY_ID,IN_CUSTOMER_ID,A.SALES_MAIN_TYPE,IN_ACCOUNT_ID) )
           ;

       /*Exception When Others Then
          GOTO HERE ;
       End ;*/


       --从政策转资源返利单，获取资源金额
       --Begin
         Select nvl(Sum(t.approval_amount_total),0)
           Into V_TRANSACTION_AMOUNT
          From T_PMT_COLLAR_SEND_HEAD t
         Where t.order_type = '03' --资源发放单
           --And t.status = '' --发放单状态
           And t.ENTITY_ID = IN_ENTITY_ID
           And t.CUSTOMER_ID = IN_CUSTOMER_ID
           And t.ACCOUNT_ID = IN_ACCOUNT_ID
           And (IS_SALES_MAIN_TYPE IS NULL OR t.SALES_MAIN_TYPE = IS_SALES_MAIN_TYPE)
           AND (IN_CREDIT_GROUP_ID IS NULL OR 0 >= IN_CREDIT_GROUP_ID
             OR IN_CREDIT_GROUP_ID = PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(
             IN_ENTITY_ID,IN_CUSTOMER_ID,T.SALES_MAIN_TYPE,IN_ACCOUNT_ID) )
           ;

       /*Exception When Others Then
          GOTO HERE ;
       End ;*/
      
      SELECT NVL(SUM(D.LOCKED_AMOUNT), 0),
             NVL(SUM(D.LOCKED_DOWNPAY_AMOUNT), 0),
             0,
             NVL(SUM(D.LOCKED_DOWNPAY_AMOUNT), 0),
             NVL(SUM(D.LOCKED_DIS_DP_AMOUNT), 0)
        INTO V_LOCK_RECEIVED_AMOUNT_NEW,
             V_LOCK_DISCOUNT_AMOUNT_NEW,
             V_LOCK_RESOURCE_AMOUNT_NEW,
             V_LOCK_RECEIVED_AMOUNT_NEW_DP,
             V_LOCK_DISCOUNT_AMOUNT_NEW_DP
        FROM T_CREDIT_LOCK_AMOUNT_DETAIL D
       WHERE D.ENTITY_ID = IN_ENTITY_ID
         AND D.CUSTOMER_ID = IN_CUSTOMER_ID
         AND D.ACCOUNT_ID = IN_ACCOUNT_ID
         AND (IS_SALES_MAIN_TYPE IS NULL OR D.SALES_MAIN_TYPE = IS_SALES_MAIN_TYPE)
         AND (IN_CREDIT_GROUP_ID IS NULL OR 0 >= IN_CREDIT_GROUP_ID
             OR IN_CREDIT_GROUP_ID = D.CREDIT_GROUP_ID);

      V_RECEIVED_AMOUNT := ROUND(V_RECEIVED_AMOUNT,2) ;
      V_SALES_AMOUNT := ROUND(V_SALES_AMOUNT,2) ;
      --V_LOCK_RECEIVED_AMOUNT := ROUND((V_LOCK_RECEIVED_AMOUNT - V_LOCK_RECEIVED_AMOUNT_FHCX),2);
      --V_LOCK_RECEIVED_AMOUNT := ROUND((V_LOCK_RECEIVED_AMOUNT + V_LOCK_RECEIVED_AMOUNT_SHIP + V_LOCK_RECEIVED_AMOUNT_DOC),2) ;
      V_LOCK_RECEIVED_AMOUNT := ROUND((V_LOCK_RECEIVED_AMOUNT + V_LOCK_RECEIVED_AMOUNT_SHIP
                                     + V_LOCK_RECEIVED_AMOUNT_DOC + V_LOCK_RECEIVED_AMOUNT_SS
                                     + V_LOCK_RECEIVED_AMOUNT_PS
                                     --2016-09-13 add by liangym2 锁款拆成全额以及订金部分
                                     + V_LOCK_RECEIVED_AMOUNT_SS_DP
                                     --2017-07-19 add by liangym2 重算增加制定发货计划（直发客户）部分
                                     + V_LOCK_RECEIVED_AMOUNT_T_SHIP + V_LOCK_RECEIVED_AMOUNT_T_DOC
                                     --ADD BY LIZHEN 2015-12-07 增加计划订单送审金额
                                     + V_LOCK_RECEIVED_AMOUNT_PLN + V_LOCK_RECEIVED_AMOUNT_PLN_DP
                                     + V_LOCK_RECEIVED_AMOUNT_HQ + V_LOCK_RECEIVED_AMOUNT_HQ_DP
                                     + V_LOCK_RECEIVED_AMOUNT_NEW + V_LOCK_RECEIVED_AMOUNT_NEW_DP),2) ;
      V_DELAYPAY_AMOUNT := ROUND(V_DELAYPAY_AMOUNT,2);
      V_TEMP_DELAYPAY_AMOUNT := ROUND(V_TEMP_DELAYPAY_AMOUNT,2);
      V_DISCOUNT_AMOUNT := ROUND(V_DISCOUNT_AMOUNT,2) ;
      V_APPLIED_DISCOUNT_AMOUNT := ROUND(V_APPLIED_DISCOUNT_AMOUNT,2);
      V_FREEZE_DISCOUNT_AMOUNT := ROUND(V_FREEZE_DISCOUNT_AMOUNT,2) ;
      V_FREEZE_DELAY_AMOUNT := ROUND(V_FREEZE_DELAY_AMOUNT,2) ;
      --V_LOCK_DISCOUNT_AMOUNT := ROUND((V_LOCK_DISCOUNT_AMOUNT_SHIP + V_LOCK_DISCOUNT_AMOUNT_DOC),2);
      V_LOCK_DISCOUNT_AMOUNT := ROUND((V_LOCK_DISCOUNT_AMOUNT_SHIP + V_LOCK_DISCOUNT_AMOUNT_DOC
                                      +V_LOCK_DISCOUNT_AMOUNT_SS
                                      + V_LOCK_DISCOUNT_AMOUNT_PS
                                     --2017-07-17 add by liangym2 锁定折扣金额拆成全额以及折扣订金部分
                                     + V_LOCK_DISCOUNT_AMOUNT_SS_DP
                                     --2017-07-19 add by liangym2 重算增加制定发货计划（直发客户）部分
                                     + V_LOCK_DISCOUNT_AMOUNT_T_SHIP + V_LOCK_DISCOUNT_AMOUNT_T_DOC
                                      --ADD BY LIZHEN 2015-12-07 增加计划订单送审折扣金额
                                      + V_LOCK_DISCOUNT_AMOUNT_PLN + V_LOCK_DISCOUNT_AMOUNT_PLN_DP
                                      + V_LOCK_DISCOUNT_AMOUNT_HQ + V_LOCK_DISCOUNT_AMOUNT_HQ_DP
                                      + V_LOCK_DISCOUNT_AMOUNT_NEW + V_LOCK_DISCOUNT_AMOUNT_NEW_DP),2);
      V_THREE_NOT_PAY := ROUND(V_THREE_NOT_PAY,2) ;
      --add by 苏冬渊 2015-08-26 资源金额
      V_RESOURCE_AMOUNT := round(V_RESOURCE_AMOUNT,2) ;
      V_LOCK_RESOURCE_AMOUNT := ROUND(V_LOCK_RESOURCE_AMOUNT_SHIP + V_LOCK_RESOURCE_AMOUNT_DOC + V_LOCK_RESOURCE_AMOUNT_SS
                                --ADD BY LIZHEN 2015-12-07 增加计划订单资源金额
                                + V_LOCK_RESOURCE_AMOUNT_PLN
                                + V_LOCK_RESOURCE_AMOUNT_HQ
                                + V_LOCK_RESOURCE_AMOUNT_NEW,2) ;
      V_TRANSACTION_AMOUNT := Round(V_TRANSACTION_AMOUNT,2) ;
     
      IF R_CUSTOMER_AMOUNT.RECEIVED_AMOUNT <> V_RECEIVED_AMOUNT
        OR R_CUSTOMER_AMOUNT.Sales_Amount <> V_SALES_AMOUNT
        OR R_CUSTOMER_AMOUNT.Lock_Received_Amount <> V_LOCK_RECEIVED_AMOUNT
        OR R_CUSTOMER_AMOUNT.Delaypay_Amount <> V_DELAYPAY_AMOUNT
        OR R_CUSTOMER_AMOUNT.Temp_Delaypay_Amount <> V_TEMP_DELAYPAY_AMOUNT
        OR R_CUSTOMER_AMOUNT.Discount_Amount <> V_DISCOUNT_AMOUNT
        OR R_CUSTOMER_AMOUNT.Applied_Discount_Amount <> V_APPLIED_DISCOUNT_AMOUNT
        OR R_CUSTOMER_AMOUNT.Freeze_Discount_Amount <> V_FREEZE_DISCOUNT_AMOUNT
        OR R_CUSTOMER_AMOUNT.FREEZE_DELAY_AMOUNT <> V_FREEZE_DELAY_AMOUNT
        OR R_CUSTOMER_AMOUNT.Lock_Discount_Amount <> V_LOCK_DISCOUNT_AMOUNT
        OR R_CUSTOMER_AMOUNT.Three_Not_Pay <> V_THREE_NOT_PAY
        OR R_CUSTOMER_AMOUNT.Resource_Amount <> V_RESOURCE_AMOUNT
        OR R_CUSTOMER_AMOUNT.Lock_Resource_Amount <> V_LOCK_RESOURCE_AMOUNT
        OR R_CUSTOMER_AMOUNT.Transaction_Amount <> V_TRANSACTION_AMOUNT THEN
      
      PIPE ROW(V_CUSTOMER_AMOUNT_ROW);
      V_CUSTOMER_AMOUNT_ROW.RECEIVED_AMOUNT := V_RECEIVED_AMOUNT;
      V_CUSTOMER_AMOUNT_ROW.Sales_Amount := V_SALES_AMOUNT;
      V_CUSTOMER_AMOUNT_ROW.Lock_Received_Amount := V_LOCK_RECEIVED_AMOUNT;
      V_CUSTOMER_AMOUNT_ROW.Delaypay_Amount := V_DELAYPAY_AMOUNT;
      V_CUSTOMER_AMOUNT_ROW.Temp_Delaypay_Amount := V_TEMP_DELAYPAY_AMOUNT;
      V_CUSTOMER_AMOUNT_ROW.Discount_Amount := V_DISCOUNT_AMOUNT;
      V_CUSTOMER_AMOUNT_ROW.Applied_Discount_Amount := V_APPLIED_DISCOUNT_AMOUNT;
      V_CUSTOMER_AMOUNT_ROW.Freeze_Discount_Amount := V_FREEZE_DISCOUNT_AMOUNT;
      V_CUSTOMER_AMOUNT_ROW.FREEZE_DELAY_AMOUNT := V_FREEZE_DELAY_AMOUNT;
      V_CUSTOMER_AMOUNT_ROW.Lock_Discount_Amount := V_LOCK_DISCOUNT_AMOUNT;
      V_CUSTOMER_AMOUNT_ROW.Three_Not_Pay := V_THREE_NOT_PAY;
      V_CUSTOMER_AMOUNT_ROW.Resource_Amount := V_RESOURCE_AMOUNT;
      V_CUSTOMER_AMOUNT_ROW.Lock_Resource_Amount := V_LOCK_RESOURCE_AMOUNT;
      V_CUSTOMER_AMOUNT_ROW.Transaction_Amount := V_TRANSACTION_AMOUNT;
      V_CUSTOMER_AMOUNT_ROW.FLAG := '重算理论值';
      PIPE ROW(V_CUSTOMER_AMOUNT_ROW);
      
      END IF ;
      
      END IF;
      -- END OF IF IS_DISCOUNT_TYPE IS NULL OR IS_DISCOUNT_TYPE IN ('COMMON','ALL') THEN
      
    END LOOP;
    
    IF IS_SALES_MAIN_TYPE IS NOT NULL THEN
      CLOSE C_CUSTOMER_AMOUNT_MX;
    ELSE
      CLOSE C_CUSTOMER_AMOUNT;
    END IF;
    
  END F_GET_SALES_ACCOUNT_AMOUNT;
    
  ----------------------------------------------------------------------
  -- Author  : liangym2
  -- Created : 2018-11-16
  -- Purpose : 查询客户款项可提货金额、可用到款金额、到款余额、折让余额、可用折让余额
  ----------------------------------------------------------------------
  FUNCTION F_GET_AMOUNT(IN_ENTITY_ID       NUMBER, --主体ID，不能为空
                        IN_CUSTOMER_ID     NUMBER, --客户ID，不能为空
                        IN_ACCOUNT_ID      NUMBER, --账户ID，可以为空
                        IS_SALES_MAIN_TYPE VARCHAR2, --营销大类，可以为空
                        IN_CREDIT_GROUP_ID NUMBER, --额度组ID，可以为空,
                        IN_FLAG            NUMBER, --1 可用到款金额；2 可用折让金额；3 可提货额度；4 到款余额
                        IS_DISCOUNT_TYPE   VARCHAR2 DEFAULT 'ALL' --ALL代表常规、折让合并 空或COMMON代表常规 其他代表折让到款
                        )
   RETURN NUMBER IS
    VN_PICKUP_AMOUNT           NUMBER; --返回可提货金额
    VN_AVL_RCV_AMOUNT          NUMBER; --返回可用到款金额
    VN_RCV_BALANCE_AMOUNT      NUMBER; --返回到款余额
    VN_AVL_DISCOUNT_AMOUNT     NUMBER; --返回可用折让余额
    VN_DISCOUNT_BALANCE_AMOUNT NUMBER; --返回折让余额
    
    VN_DIS_RECEIPT_AMOUNT   NUMBER;--add by liangym2 20181120 折让上账金额
    VN_DIS_SALES_AMOUNT     NUMBER;--add by liangym2 20181120 折让销售金额
    VN_DIS_LOCK_AMOUNT      NUMBER;--add by liangym2 20181120 折让锁款金额
    VN_DIS_RECEIVED_AMOUNT  NUMBER;--add by liangym2 20181120 折让到款金额
  BEGIN
    VN_PICKUP_AMOUNT           := 0;
    VN_AVL_RCV_AMOUNT          := 0;
    VN_RCV_BALANCE_AMOUNT      := 0;
    VN_AVL_DISCOUNT_AMOUNT     := 0;
    VN_DISCOUNT_BALANCE_AMOUNT := 0;
  
    IF IS_DISCOUNT_TYPE IS NULL OR IS_DISCOUNT_TYPE IN ('COMMON','ALL') THEN
      IF IS_SALES_MAIN_TYPE IS NULL THEN
        --不传大类
        SELECT SUM(T.RECEIVED_AMOUNT-T.SALES_AMOUNT),SUM(T.DISCOUNT_AMOUNT-T.APPLIED_DISCOUNT_AMOUNT)
        --
        ,SUM(T.RECEIVED_AMOUNT-T.SALES_AMOUNT+T.TEMP_DELAYPAY_AMOUNT+T.DELAYPAY_AMOUNT
        -T.LOCK_RECEIVED_AMOUNT+T.MPAY_STREAM_AMOUNT-T.MPAY_CASH_AMOUNT)
        ,SUM(T.DISCOUNT_AMOUNT-T.APPLIED_DISCOUNT_AMOUNT+T.FREEZE_DISCOUNT_AMOUNT-T.LOCK_DISCOUNT_AMOUNT)
        --
        --,
        --
        INTO VN_RCV_BALANCE_AMOUNT,
           VN_DISCOUNT_BALANCE_AMOUNT
           --
          ,
           VN_AVL_RCV_AMOUNT,
           VN_AVL_DISCOUNT_AMOUNT
        --
        --,ON_PICKUP_AMOUNT
        --
        FROM T_SALES_ACCOUNT_AMOUNT T
        WHERE T.ENTITY_ID = IN_ENTITY_ID AND T.CUSTOMER_ID = IN_CUSTOMER_ID
        AND (IN_ACCOUNT_ID IS NULL OR 0 >= IN_ACCOUNT_ID OR IN_ACCOUNT_ID = T.ACCOUNT_ID)
        AND (IN_CREDIT_GROUP_ID IS NULL OR 0 >= IN_CREDIT_GROUP_ID OR IN_CREDIT_GROUP_ID = T.CREDIT_GROUP_ID)
        ;
      ELSE
        SELECT SUM(T.RECEIVED_AMOUNT-T.SALES_AMOUNT),SUM(T.DISCOUNT_AMOUNT-T.APPLIED_DISCOUNT_AMOUNT)
        --
        ,SUM(T.RECEIVED_AMOUNT-T.SALES_AMOUNT+T.TEMP_DELAYPAY_AMOUNT+T.DELAYPAY_AMOUNT
        -T.LOCK_RECEIVED_AMOUNT+T.MPAY_STREAM_AMOUNT-T.MPAY_CASH_AMOUNT)
        ,SUM(T.DISCOUNT_AMOUNT-T.APPLIED_DISCOUNT_AMOUNT+T.FREEZE_DISCOUNT_AMOUNT-T.LOCK_DISCOUNT_AMOUNT)
        --
        --,
        --
        INTO VN_RCV_BALANCE_AMOUNT,
           VN_DISCOUNT_BALANCE_AMOUNT
           --
          ,
           VN_AVL_RCV_AMOUNT,
           VN_AVL_DISCOUNT_AMOUNT
        --
        --,ON_PICKUP_AMOUNT
        --
        FROM T_SALES_ACCOUNT_MX_AMOUNT T
        WHERE T.ENTITY_ID = IN_ENTITY_ID AND T.CUSTOMER_ID = IN_CUSTOMER_ID
        AND (IN_ACCOUNT_ID IS NULL OR 0 >= IN_ACCOUNT_ID OR IN_ACCOUNT_ID = T.ACCOUNT_ID)
        AND (IS_SALES_MAIN_TYPE IS NULL OR IS_SALES_MAIN_TYPE = T.SALES_MAIN_TYPE)
        AND (IN_CREDIT_GROUP_ID IS NULL OR 0 >= IN_CREDIT_GROUP_ID
        OR IN_CREDIT_GROUP_ID = FUN_GET_CREDITGROUPID(T.ENTITY_ID,T.CUSTOMER_ID,T.SALES_MAIN_TYPE,T.ACCOUNT_ID))
        ;
      END IF;
      
    VN_PICKUP_AMOUNT := (VN_AVL_RCV_AMOUNT + VN_AVL_DISCOUNT_AMOUNT);
    END IF;
    
    --
      IF IS_DISCOUNT_TYPE IS NULL OR IS_DISCOUNT_TYPE <> 'ALL' THEN
        --总款不会进来
        BEGIN
          SELECT SUM(NVL(T.RECEIPT_AMOUNT,0)),SUM(NVL(T.SALES_AMOUNT,0)),SUM(NVL(T.LOCK_AMOUNT,0)),SUM(NVL(T.RECEIVED_AMOUNT,0))
           INTO VN_DIS_RECEIPT_AMOUNT,VN_DIS_SALES_AMOUNT,VN_DIS_LOCK_AMOUNT,VN_DIS_RECEIVED_AMOUNT
          FROM T_CREDIT_DISCOUNT_AMOUNT T
          WHERE T.ENTITY_ID = IN_ENTITY_ID
       AND T.CUSTOMER_ID = IN_CUSTOMER_ID
       AND (IN_ACCOUNT_ID IS NULL OR 0 >= IN_ACCOUNT_ID OR
           IN_ACCOUNT_ID = T.ACCOUNT_ID)
       AND (IS_SALES_MAIN_TYPE IS NULL OR
           IS_SALES_MAIN_TYPE = T.SALES_MAIN_TYPE)
       AND (IN_CREDIT_GROUP_ID IS NULL OR 0 >= IN_CREDIT_GROUP_ID OR
           IN_CREDIT_GROUP_ID =
           FUN_GET_CREDITGROUPID(T.ENTITY_ID,
                                  T.CUSTOMER_ID,
                                  T.SALES_MAIN_TYPE,
                                  T.ACCOUNT_ID))
          AND (IS_DISCOUNT_TYPE IS NULL OR IS_DISCOUNT_TYPE = 'COMMON' OR IS_DISCOUNT_TYPE = T.DISCOUNT_TYPE)
          ;
        EXCEPTION WHEN OTHERS THEN
          VN_DIS_RECEIPT_AMOUNT := 0 ;
          VN_DIS_SALES_AMOUNT := 0 ;
          VN_DIS_LOCK_AMOUNT  := 0;
          VN_DIS_RECEIVED_AMOUNT := 0;
        END ;
      VN_DIS_RECEIPT_AMOUNT := NVL(VN_DIS_RECEIPT_AMOUNT,0);
      VN_DIS_SALES_AMOUNT := NVL(VN_DIS_SALES_AMOUNT,0);
      VN_DIS_LOCK_AMOUNT := NVL(VN_DIS_LOCK_AMOUNT,0);
      VN_DIS_RECEIVED_AMOUNT := NVL(VN_DIS_RECEIVED_AMOUNT,0);
      END IF;
  
    IF IS_DISCOUNT_TYPE NOT IN ('COMMON','ALL') THEN
      --折让到款方式
      VN_PICKUP_AMOUNT           := (VN_DIS_RECEIPT_AMOUNT + VN_DIS_RECEIVED_AMOUNT - VN_DIS_SALES_AMOUNT - VN_DIS_LOCK_AMOUNT);
      VN_AVL_RCV_AMOUNT          := (VN_DIS_RECEIPT_AMOUNT + VN_DIS_RECEIVED_AMOUNT - VN_DIS_SALES_AMOUNT - VN_DIS_LOCK_AMOUNT);
      VN_RCV_BALANCE_AMOUNT      := (VN_DIS_RECEIPT_AMOUNT + VN_DIS_RECEIVED_AMOUNT - VN_DIS_SALES_AMOUNT);
      VN_AVL_DISCOUNT_AMOUNT     := 0;
      VN_DISCOUNT_BALANCE_AMOUNT := 0;
    ELSIF IS_DISCOUNT_TYPE IS NULL OR 'COMMON' = IS_DISCOUNT_TYPE THEN
      --常规到款
      VN_PICKUP_AMOUNT := (VN_PICKUP_AMOUNT - (VN_DIS_RECEIPT_AMOUNT + VN_DIS_RECEIVED_AMOUNT - VN_DIS_SALES_AMOUNT - VN_DIS_LOCK_AMOUNT));
      VN_AVL_RCV_AMOUNT := (VN_AVL_RCV_AMOUNT - (VN_DIS_RECEIPT_AMOUNT + VN_DIS_RECEIVED_AMOUNT - VN_DIS_SALES_AMOUNT - VN_DIS_LOCK_AMOUNT));
      VN_RCV_BALANCE_AMOUNT := (VN_RCV_BALANCE_AMOUNT - (VN_DIS_RECEIPT_AMOUNT + VN_DIS_RECEIVED_AMOUNT - VN_DIS_SALES_AMOUNT));
    END IF;
    
    
    IF 1 = IN_FLAG THEN
      RETURN VN_AVL_RCV_AMOUNT;
    ELSIF 2 = IN_FLAG THEN
      RETURN VN_AVL_DISCOUNT_AMOUNT;
    ELSIF 3 = IN_FLAG THEN
      RETURN VN_PICKUP_AMOUNT;
    ELSIF 4 = IN_FLAG THEN
      RETURN VN_RCV_BALANCE_AMOUNT;
    END IF;
  END F_GET_AMOUNT;
  
  ----------------------------------------------------------------------
  -- Author  : liangym2
  -- Created : 2018-09-18
  -- Purpose : 查询客户款项可提货金额、可用到款金额、到款余额、折让余额、可用折让余额
  ----------------------------------------------------------------------
  PROCEDURE P_GET_AMOUNT(IN_ENTITY_ID               IN NUMBER, --主体ID，不能为空
                         IN_CUSTOMER_ID             IN NUMBER, --客户ID，不能为空
                         IN_ACCOUNT_ID              IN NUMBER, --账户ID，可以为空
                         IS_SALES_MAIN_TYPE         IN VARCHAR2, --营销大类，可以为空
                         IN_CREDIT_GROUP_ID         NUMBER, --额度组ID，可以为空
                         ON_PICKUP_AMOUNT           IN OUT NUMBER, --返回可提货金额
                         ON_AVL_RCV_AMOUNT          IN OUT NUMBER, --返回可用到款金额
                         ON_RCV_BALANCE_AMOUNT      IN OUT NUMBER, --返回到款余额
                         ON_AVL_DISCOUNT_AMOUNT     IN OUT NUMBER, --返回可用折让余额
                         ON_DISCOUNT_BALANCE_AMOUNT IN OUT NUMBER, --返回折让余额
                         IS_DISCOUNT_TYPE           IN VARCHAR2 DEFAULT 'ALL' --ALL代表常规、折让合并 空或COMMON代表常规 其他代表折让到款
                         ) IS
    
    VN_DIS_RECEIPT_AMOUNT   NUMBER;--add by liangym2 20181120 折让上账金额
    VN_DIS_SALES_AMOUNT     NUMBER;--add by liangym2 20181120 折让销售金额
    VN_DIS_LOCK_AMOUNT      NUMBER;--add by liangym2 20181120 折让锁款金额
    VN_DIS_RECEIVED_AMOUNT  NUMBER;--add by liangym2 20181120 折让到款金额
  BEGIN
    ON_PICKUP_AMOUNT           := 0;
    ON_AVL_RCV_AMOUNT          := 0;
    ON_RCV_BALANCE_AMOUNT      := 0;
    ON_AVL_DISCOUNT_AMOUNT     := 0;
    ON_DISCOUNT_BALANCE_AMOUNT := 0;
    
    IF IS_DISCOUNT_TYPE IS NULL OR IS_DISCOUNT_TYPE IN ('COMMON','ALL') THEN
      IF IS_SALES_MAIN_TYPE IS NULL THEN
        --不传大类
        SELECT SUM(T.RECEIVED_AMOUNT-T.SALES_AMOUNT),SUM(T.DISCOUNT_AMOUNT-T.APPLIED_DISCOUNT_AMOUNT)
        --
        ,SUM(T.RECEIVED_AMOUNT-T.SALES_AMOUNT+T.TEMP_DELAYPAY_AMOUNT+T.DELAYPAY_AMOUNT
        -T.LOCK_RECEIVED_AMOUNT+T.MPAY_STREAM_AMOUNT-T.MPAY_CASH_AMOUNT)
        ,SUM(T.DISCOUNT_AMOUNT-T.APPLIED_DISCOUNT_AMOUNT+T.FREEZE_DISCOUNT_AMOUNT-T.LOCK_DISCOUNT_AMOUNT)
        --
        --,
        --
        INTO ON_RCV_BALANCE_AMOUNT,ON_DISCOUNT_BALANCE_AMOUNT
        --
        ,ON_AVL_RCV_AMOUNT,ON_AVL_DISCOUNT_AMOUNT
        --
        --,ON_PICKUP_AMOUNT
        --
        FROM T_SALES_ACCOUNT_AMOUNT T
        WHERE T.ENTITY_ID = IN_ENTITY_ID AND T.CUSTOMER_ID = IN_CUSTOMER_ID
        AND (IN_ACCOUNT_ID IS NULL OR 0 >= IN_ACCOUNT_ID OR IN_ACCOUNT_ID = T.ACCOUNT_ID)
        AND (IN_CREDIT_GROUP_ID IS NULL OR 0 >= IN_CREDIT_GROUP_ID OR IN_CREDIT_GROUP_ID = T.CREDIT_GROUP_ID)
        ;
      ELSE
        SELECT SUM(T.RECEIVED_AMOUNT-T.SALES_AMOUNT),SUM(T.DISCOUNT_AMOUNT-T.APPLIED_DISCOUNT_AMOUNT)
        --
        ,SUM(T.RECEIVED_AMOUNT-T.SALES_AMOUNT+T.TEMP_DELAYPAY_AMOUNT+T.DELAYPAY_AMOUNT
        -T.LOCK_RECEIVED_AMOUNT+T.MPAY_STREAM_AMOUNT-T.MPAY_CASH_AMOUNT)
        ,SUM(T.DISCOUNT_AMOUNT-T.APPLIED_DISCOUNT_AMOUNT+T.FREEZE_DISCOUNT_AMOUNT-T.LOCK_DISCOUNT_AMOUNT)
        --
        --,
        --
        INTO ON_RCV_BALANCE_AMOUNT,ON_DISCOUNT_BALANCE_AMOUNT
        --
        ,ON_AVL_RCV_AMOUNT,ON_AVL_DISCOUNT_AMOUNT
        --
        --,ON_PICKUP_AMOUNT
        --
        FROM T_SALES_ACCOUNT_MX_AMOUNT T
        WHERE T.ENTITY_ID = IN_ENTITY_ID AND T.CUSTOMER_ID = IN_CUSTOMER_ID
        AND (IN_ACCOUNT_ID IS NULL OR 0 >= IN_ACCOUNT_ID OR IN_ACCOUNT_ID = T.ACCOUNT_ID)
        AND (IS_SALES_MAIN_TYPE IS NULL OR IS_SALES_MAIN_TYPE = T.SALES_MAIN_TYPE)
        AND (IN_CREDIT_GROUP_ID IS NULL OR 0 >= IN_CREDIT_GROUP_ID
        OR IN_CREDIT_GROUP_ID = FUN_GET_CREDITGROUPID(T.ENTITY_ID,T.CUSTOMER_ID,T.SALES_MAIN_TYPE,T.ACCOUNT_ID))
        ;
      END IF;
      
    ON_PICKUP_AMOUNT := (ON_AVL_RCV_AMOUNT + ON_AVL_DISCOUNT_AMOUNT);
    END IF;
    
    --
      IF IS_DISCOUNT_TYPE IS NULL OR IS_DISCOUNT_TYPE <> 'ALL' THEN
        --总款不会进来
        BEGIN
          SELECT SUM(NVL(T.RECEIPT_AMOUNT,0)),SUM(NVL(T.SALES_AMOUNT,0)),SUM(NVL(T.LOCK_AMOUNT,0)),SUM(NVL(T.RECEIVED_AMOUNT,0))
           INTO VN_DIS_RECEIPT_AMOUNT,VN_DIS_SALES_AMOUNT,VN_DIS_LOCK_AMOUNT,VN_DIS_RECEIVED_AMOUNT
          FROM T_CREDIT_DISCOUNT_AMOUNT T
          WHERE T.ENTITY_ID = IN_ENTITY_ID
       AND T.CUSTOMER_ID = IN_CUSTOMER_ID
       AND (IN_ACCOUNT_ID IS NULL OR 0 >= IN_ACCOUNT_ID OR
           IN_ACCOUNT_ID = T.ACCOUNT_ID)
       AND (IS_SALES_MAIN_TYPE IS NULL OR
           IS_SALES_MAIN_TYPE = T.SALES_MAIN_TYPE)
       AND (IN_CREDIT_GROUP_ID IS NULL OR 0 >= IN_CREDIT_GROUP_ID OR
           IN_CREDIT_GROUP_ID =
           FUN_GET_CREDITGROUPID(T.ENTITY_ID,
                                  T.CUSTOMER_ID,
                                  T.SALES_MAIN_TYPE,
                                  T.ACCOUNT_ID))
          AND (IS_DISCOUNT_TYPE IS NULL OR IS_DISCOUNT_TYPE = 'COMMON' OR IS_DISCOUNT_TYPE = T.DISCOUNT_TYPE)
          ;
        EXCEPTION WHEN OTHERS THEN
          VN_DIS_RECEIPT_AMOUNT := 0 ;
          VN_DIS_SALES_AMOUNT := 0 ;
          VN_DIS_LOCK_AMOUNT  := 0;
          VN_DIS_RECEIVED_AMOUNT := 0;
        END ;
      VN_DIS_RECEIPT_AMOUNT := NVL(VN_DIS_RECEIPT_AMOUNT,0);
      VN_DIS_SALES_AMOUNT := NVL(VN_DIS_SALES_AMOUNT,0);
      VN_DIS_LOCK_AMOUNT := NVL(VN_DIS_LOCK_AMOUNT,0);
      VN_DIS_RECEIVED_AMOUNT := NVL(VN_DIS_RECEIVED_AMOUNT,0);
      END IF;
  
    IF IS_DISCOUNT_TYPE NOT IN ('COMMON','ALL') THEN
      --折让到款方式
      ON_PICKUP_AMOUNT           := (VN_DIS_RECEIPT_AMOUNT + VN_DIS_RECEIVED_AMOUNT - VN_DIS_SALES_AMOUNT - VN_DIS_LOCK_AMOUNT);
      ON_AVL_RCV_AMOUNT          := (VN_DIS_RECEIPT_AMOUNT + VN_DIS_RECEIVED_AMOUNT - VN_DIS_SALES_AMOUNT - VN_DIS_LOCK_AMOUNT);
      ON_RCV_BALANCE_AMOUNT      := (VN_DIS_RECEIPT_AMOUNT + VN_DIS_RECEIVED_AMOUNT - VN_DIS_SALES_AMOUNT);
      ON_AVL_DISCOUNT_AMOUNT     := 0;
      ON_DISCOUNT_BALANCE_AMOUNT := 0;
    ELSIF IS_DISCOUNT_TYPE IS NULL OR 'COMMON' = IS_DISCOUNT_TYPE THEN
      --常规到款
      ON_PICKUP_AMOUNT := (ON_PICKUP_AMOUNT - (VN_DIS_RECEIPT_AMOUNT + VN_DIS_RECEIVED_AMOUNT - VN_DIS_SALES_AMOUNT - VN_DIS_LOCK_AMOUNT));
      ON_AVL_RCV_AMOUNT := (ON_AVL_RCV_AMOUNT - (VN_DIS_RECEIPT_AMOUNT + VN_DIS_RECEIVED_AMOUNT - VN_DIS_SALES_AMOUNT - VN_DIS_LOCK_AMOUNT));
      ON_RCV_BALANCE_AMOUNT := (ON_RCV_BALANCE_AMOUNT - (VN_DIS_RECEIPT_AMOUNT + VN_DIS_RECEIVED_AMOUNT - VN_DIS_SALES_AMOUNT));
    END IF;
  
  EXCEPTION
    WHEN OTHERS THEN
      NULL;
  END P_GET_AMOUNT;

end PKG_CREDIT_TOOLS;
/

