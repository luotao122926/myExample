create view V_SO_TRX_LINES as
SELECT --发票行视图
 TL.TRX_LINE_ID,
 TL.ENTITY_ID,
 TL.IDTRX_ID,
 TL.CREATION_DATE,
 TL.LAST_UPDATE_DATE,
 /* --采用新逻辑，正式发布时决定是否清空这段代码
 nvl(tl.material_name,mat.description) material_name,--物料品名+型号
 nvl(tl.material_code,mat.material_code) material_code,--物料编码
 tl.MATERIAL_MODEL, --物料型号
 nvl(tl.material_unit,mat.uom_code) material_unit, --物料单位
 */
 TL.ITEM_NAME,
 --物料品名+型号
 TL.ITEM_CODE, --物料编码
 TL.ITEM_MODEL, --物料型号
 TL.ITEM_UNIT, --物料单位
 TL.QUANTITY,
 TL.PRICE,
 TL.DISCOUNT,
 TL.TRX_RATE,
 ROUND(TL.PRICE * (1 - (NVL(TL.DISCOUNT, 0) / 100)) * TL.QUANTITY, 2) MATERIAL_TRX_AMOUNT, --含税发票行总价
 ROUND(TL.PRICE * (1 - (NVL(TL.DISCOUNT, 0) / 100)) * TL.QUANTITY /
       (1 + TL.TRX_RATE / 100),
       2) MATERIAL_AMOUNT --不含税发票行总价
/* --采用新逻辑，正式发布时决定是否清空这段代码
  from t_mtl_material mat,
       t_so_trx_lines tl
 where mat.material_id = tl.material_id
   and mat.finance_entity_id = tl.finance_entity_id
*/
  FROM T_SO_TRX_LINES TL
/

