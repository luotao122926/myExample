create PACKAGE      PKG_BD_IO_PDM IS

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-04-21
  *     创建者：杨福伟
  *   功能说明：PDM产品同步于CIMS
  */
  -------------------------------------------------------------------------------
  procedure P_SYNC_PDM_ITEM(P_ENTITY      number, --主体
                            P_USER        varchar2, --用户
                            P_RETURN_CODE out varchar2, --返回编码
                            P_RETURN_MSG  out varchar2 --返回提示信息
                            );
END PKG_BD_IO_PDM;
/

