create view V_LG_CONTRACT as
(
SELECT T1.CONTRACT_ID,
       T1.ENTITY_ID,
       T1.CONTRACT_CODE,
       T1.BILLS_STATUS,
       T1.VEHICLE_INFO_ID,
       T1.SALES_CENTER_ID,
       T1.SHIP_WAY,
       T1.LOAD_VEHICLE_TYPE,
       T1.CUSTOMER_ORDER_NUMBER,
       T1.SALES_CENTER_CODE,
       T1.SALES_CENTER_NAME,
       T1.SHIP_TYPE,
       T1.CUSTOMER_ID,
       T1.CUSTOMER_CODE,
       T1.CUSTOMER_NAME,
       T1.ACCOUNT_CODE,
       T1.CUSTOMER_CONTACTS,
       T1.CUSTOMER_CONTACTS_PHONES,
       T1.SHIP_COMPANY,
       T1.SHIP_TO_LOCATION_ID,
       T1.SHIP_TO_LOCATION_CODE,
       T1.SHIP_TO_LOCATION,
       T1.SHIP_INVENTORY_ID,
       T1.SHIP_INVENTORY_CODE,
       T1.SHIP_INVENTORY_NAME,
       T1.CONSIGNEE_INVENTORY_ID,
       T1.CONSIGNEE_INVENTORY_CODE,
       T1.CONSIGNEE_INVENTORY_NAME,
       T1.CONSIGNEE_ADDR,
       T1.CONSIGNEE_LOCATION_ID,
       T1.CONSIGNEE_LOCATION_CODE,
       T1.CONSIGNEE_LOCATION,
       T1.CONSIGNEE_COMPANY_ID,
       T1.CONSIGNEE_COMPANY_CODE,
       T1.CONSIGNEE_COMPANY_NAME,
       T1.CONSIGNEE_COMPANY_ADDR,
       T1.CONSIGNEE_COMPANY_CONTACT_ID,
       T1.CONSIGNEE_COMPANY_CONTRACT,
       T1.CONSIGNEE_COMPANY_TEL,
       T1.REQUIRE_SHIP_DATE,
       T1.FACT_SHIP_DATE,
       T1.REQUIRE_ARRIVE_DATE,
       T1.FACT_ARRIVE_DATE,
       T1.DROP_SHIP_FLAG,
       T1.DISTANCE,
       T1.FREIGHT,
       T1.TAX_AMOUNT,
       T1.TAX_RATE,
       T1.FREIGHT_NO_TAX,
       T1.ORIGIN_SHIP_CHARGES,
       T1.ADJUST_SHIP_CHARGES,
       T1.FREIGHT_ADJUST_REASON,
       T1.PRICE_UNIT,
       T1.TOTAL_VOLUME,
       T1.TOTAL_WEIGHT,
       T1.TOTAL_AMOUNT,
       T1.WEIGHT_UNIT,
       T1.VOL_UNIT,
       T1.PRINT_FLAG,
       T1.PRINT_TIMES,
       T1.PRINT_DATE,
       T1.RECEIVE_FLAG,
       T1.RECEIVE_DATE,
       T1.RECEIVE_BY_NAME,
       T1.BACK_FLAG,
       T1.BACK_DATE,
       T1.LOCK_FLAG,
       T1.JUDGEMAR_CODE,
       T1.INSURANCE_FLAG,
       T1.INSURACE_ID,
       T1.INSURACE_CODE,
       T1.INSURACE_NAME,
       T1.RISK_AMOUNT,
       T1.INSURANCE,
       T1.COMPENSATION_AMOUNT,
       T1.COMPENSATION_REASON,
       T1.COMPENSATION_DATE,
       T1.CLAIM_VENDOR_CODE,
       T1.CLAIM_VENDOR_NAME,
       T1.BREAK_CLAIMANT_AMOUNT,
       T1.BREAK_CLAIMANT_REASON,
       T1.BREAK_CLAIMANT_DATE,
       T1.DAMAGE_CLAIMANT_AMOUNT,
       T1.DAMAGE_CLAIMANT_REASON,
       T1.DAMAGE_CLAIMANT_DATE,
       T1.BREAK_CLAIM_DATE,
       T1.DAMAGE_CLAIM_DATE,
       T1.DAMAGE_INC_DEC_CODE,
       T1.BREAK_INC_DEC_CODE,
       T1.CONTRACT_TYPE,
       T1.ORIGIN_CONTRACT_CODE,
       T1.FREIGHT_BATCH_FLAG,
       T1.INSUANCE_BATCH_FLAG,
       T1.FREIGHT_BATCH_NUM,
       T1.INSURANCE_BATCH_NUM,
       T1.SEND_FLAG,
       T1.VENDOR_FLAG,
       T1.VENDOR_ERROR_MESSAGE,
       T1.IMPORT_VENDOR_TIME,
       T1.CONTRACT_DATE,
       T1.REG_CARRIAGE_FLAG,
       T1.REG_INSURANCE_FLAG,
       T1.PROMOTION_PRODUCT_VOL,
       T1.CREATED_BY,
       T1.CREATION_DATE,
       T1.LAST_UPDATED_BY,
       T1.LAST_UPDATE_DATE,
       T1.REMARK,
       T2.VEHICLE_NUM,
       T2.SHIP_DATE,
       T2.VEHICLE_BRAND_NUM,
       T2.CHAUFFEUR,
       T2.CHAUFFEUR_TEL,
       T2.CHAUFFEUR_IDENTITY_NUM,
       T2.SEAL_NUM,
       T2.SEAL_DATE,
       T2.SEAL_BY,
       T2.SIGN_SEAL_NUM,
       T2.SIGN_SEAL_DATE,
       T2.SIGN_SEAL_BY,
       T2.SEAL_STATUS,
       (select d.vendor_id from cims.t_lg_ship_doc d,cims.t_lg_ship_doc_line l,cims.t_lg_contract_line e where d.ship_doc_id = l.ship_doc_id
       and l.ship_doc_line_id = e.ship_doc_line_id and d.entity_id = t1.entity_id and e.contract_id = t1.contract_id and rownum = 1) vendor_id,
       (select d.vendor_code from cims.t_lg_ship_doc d,cims.t_lg_ship_doc_line l,cims.t_lg_contract_line e where d.ship_doc_id = l.ship_doc_id
       and l.ship_doc_line_id = e.ship_doc_line_id and d.entity_id = t1.entity_id and e.contract_id = t1.contract_id and rownum = 1) vendor_code,
       (select d.vendor_name from cims.t_lg_ship_doc d,cims.t_lg_ship_doc_line l,cims.t_lg_contract_line e where d.ship_doc_id = l.ship_doc_id
       and l.ship_doc_line_id = e.ship_doc_line_id and d.entity_id = t1.entity_id and e.contract_id = t1.contract_id and rownum = 1) vendor_name,
       T2.VENDOR_CONTACT,
       T2.VENDOR_TEL,
       T2.CARRIER_NAME,
       T1.RECEIVE_SYSTEM,
       T1.TRANSFER_CUSTOMER_CODE,
        TRANSFER_CUSTOMER_NAME,
       T1.Difference_Confirm_Date
  FROM cims.T_LG_CONTRACT      T1,
       cims.T_LG_VEHICLE_INFO  T2
 WHERE T1.VEHICLE_INFO_ID = T2.VEHICLE_INFO_ID)
/

comment on column V_LG_CONTRACT.CONTRACT_ID is '运输合同ID'
/

comment on column V_LG_CONTRACT.ENTITY_ID is '主体ID'
/

comment on column V_LG_CONTRACT.CONTRACT_CODE is '合同号 HT2014070800001'
/

comment on column V_LG_CONTRACT.BILLS_STATUS is '单据状态 00生成 01已发货 02已签收 03已回单 04签收确认 05已结算'
/

comment on column V_LG_CONTRACT.VEHICLE_INFO_ID is '排车信息ID'
/

comment on column V_LG_CONTRACT.SALES_CENTER_ID is '营销中心ID'
/

comment on column V_LG_CONTRACT.SHIP_WAY is '运输方式 01：汽运 02：海运 03：铁运 04:空运 05：其他'
/

comment on column V_LG_CONTRACT.LOAD_VEHICLE_TYPE is '装车类型'
/

comment on column V_LG_CONTRACT.CUSTOMER_ORDER_NUMBER is '客户订单号'
/

comment on column V_LG_CONTRACT.SALES_CENTER_CODE is '营销中心编码'
/

comment on column V_LG_CONTRACT.SALES_CENTER_NAME is '营销中心名称'
/

comment on column V_LG_CONTRACT.SHIP_TYPE is '发货类型 00 工厂发货 01省内发货 02异地调拨 03直发超市'
/

comment on column V_LG_CONTRACT.CUSTOMER_ID is '客户id'
/

comment on column V_LG_CONTRACT.CUSTOMER_CODE is '客户编码'
/

comment on column V_LG_CONTRACT.CUSTOMER_NAME is '客户名称，同时也代表开票单位'
/

comment on column V_LG_CONTRACT.ACCOUNT_CODE is '账户编码'
/

comment on column V_LG_CONTRACT.CUSTOMER_CONTACTS is '客户联系人'
/

comment on column V_LG_CONTRACT.CUSTOMER_CONTACTS_PHONES is '客户联系人电话'
/

comment on column V_LG_CONTRACT.SHIP_COMPANY is '发货单位'
/

comment on column V_LG_CONTRACT.SHIP_TO_LOCATION_ID is '发货地点ID'
/

comment on column V_LG_CONTRACT.SHIP_TO_LOCATION_CODE is '发货地点编码'
/

comment on column V_LG_CONTRACT.SHIP_TO_LOCATION is '发货地点'
/

comment on column V_LG_CONTRACT.SHIP_INVENTORY_ID is '通过发货仓库ID 到 仓库设置(T_INV_INVENTORIES)表中获取 地区ID，再通过发货地点ID、收货地点ID 获取线路及承运商信息
'
/

comment on column V_LG_CONTRACT.SHIP_INVENTORY_CODE is '发货仓库编码'
/

comment on column V_LG_CONTRACT.SHIP_INVENTORY_NAME is '发货仓库名称'
/

comment on column V_LG_CONTRACT.CONSIGNEE_INVENTORY_ID is '收货仓库ID'
/

comment on column V_LG_CONTRACT.CONSIGNEE_INVENTORY_CODE is '收货仓库编码'
/

comment on column V_LG_CONTRACT.CONSIGNEE_INVENTORY_NAME is '收货仓库名称'
/

comment on column V_LG_CONTRACT.CONSIGNEE_ADDR is '收货地址'
/

comment on column V_LG_CONTRACT.CONSIGNEE_LOCATION_ID is '收货地点id'
/

comment on column V_LG_CONTRACT.CONSIGNEE_LOCATION_CODE is '收货地点编码'
/

comment on column V_LG_CONTRACT.CONSIGNEE_LOCATION is '收货地点'
/

comment on column V_LG_CONTRACT.CONSIGNEE_COMPANY_ID is '收货单位ID'
/

comment on column V_LG_CONTRACT.CONSIGNEE_COMPANY_CODE is '收货单位编码'
/

comment on column V_LG_CONTRACT.CONSIGNEE_COMPANY_NAME is '收货单位名称'
/

comment on column V_LG_CONTRACT.CONSIGNEE_COMPANY_ADDR is '收货单位地址'
/

comment on column V_LG_CONTRACT.CONSIGNEE_COMPANY_CONTACT_ID is '收货单位联系人ID'
/

comment on column V_LG_CONTRACT.CONSIGNEE_COMPANY_CONTRACT is '收货单位联系人'
/

comment on column V_LG_CONTRACT.CONSIGNEE_COMPANY_TEL is '收货单位联系电话'
/

comment on column V_LG_CONTRACT.REQUIRE_SHIP_DATE is '要求发货时间'
/

comment on column V_LG_CONTRACT.FACT_SHIP_DATE is '实际发货时间 接收发货确认的日期'
/

comment on column V_LG_CONTRACT.REQUIRE_ARRIVE_DATE is '要求到货时间'
/

comment on column V_LG_CONTRACT.FACT_ARRIVE_DATE is '实际到货时间'
/

comment on column V_LG_CONTRACT.DROP_SHIP_FLAG is '直发标识'
/

comment on column V_LG_CONTRACT.DISTANCE is '公里数'
/

comment on column V_LG_CONTRACT.FREIGHT is '运费'
/

comment on column V_LG_CONTRACT.TAX_AMOUNT is '税额'
/

comment on column V_LG_CONTRACT.TAX_RATE is '税率'
/

comment on column V_LG_CONTRACT.FREIGHT_NO_TAX is '运费（不含税）'
/

comment on column V_LG_CONTRACT.ORIGIN_SHIP_CHARGES is '原始运费'
/

comment on column V_LG_CONTRACT.ADJUST_SHIP_CHARGES is '调整运费'
/

comment on column V_LG_CONTRACT.FREIGHT_ADJUST_REASON is '运费调整原因'
/

comment on column V_LG_CONTRACT.PRICE_UNIT is '体积计量单位'
/

comment on column V_LG_CONTRACT.TOTAL_VOLUME is '产品总体积'
/

comment on column V_LG_CONTRACT.TOTAL_WEIGHT is '产品总重量'
/

comment on column V_LG_CONTRACT.TOTAL_AMOUNT is '产品总价值'
/

comment on column V_LG_CONTRACT.WEIGHT_UNIT is '重量计量单位 吨、千克'
/

comment on column V_LG_CONTRACT.VOL_UNIT is '体积计量单位,立方米、立方分米'
/

comment on column V_LG_CONTRACT.PRINT_FLAG is '打印标识 Y是N否'
/

comment on column V_LG_CONTRACT.PRINT_TIMES is '打印次数'
/

comment on column V_LG_CONTRACT.PRINT_DATE is '打印日期'
/

comment on column V_LG_CONTRACT.RECEIVE_FLAG is '是否已签收'
/

comment on column V_LG_CONTRACT.RECEIVE_DATE is '签收日期'
/

comment on column V_LG_CONTRACT.RECEIVE_BY_NAME is '签收人姓名'
/

comment on column V_LG_CONTRACT.BACK_FLAG is '回单标记'
/

comment on column V_LG_CONTRACT.BACK_DATE is '回单日期'
/

comment on column V_LG_CONTRACT.LOCK_FLAG is '锁定标志'
/

comment on column V_LG_CONTRACT.JUDGEMAR_CODE is '定损单号'
/

comment on column V_LG_CONTRACT.INSURANCE_FLAG is '是否购买保险'
/

comment on column V_LG_CONTRACT.INSURACE_ID is '保险商ID'
/

comment on column V_LG_CONTRACT.INSURACE_CODE is '保险商编码'
/

comment on column V_LG_CONTRACT.INSURACE_NAME is '保险商'
/

comment on column V_LG_CONTRACT.RISK_AMOUNT is '投保金额'
/

comment on column V_LG_CONTRACT.INSURANCE is '保险费'
/

comment on column V_LG_CONTRACT.COMPENSATION_AMOUNT is '理赔金额'
/

comment on column V_LG_CONTRACT.COMPENSATION_REASON is '理赔原因'
/

comment on column V_LG_CONTRACT.COMPENSATION_DATE is '理赔日期'
/

comment on column V_LG_CONTRACT.CLAIM_VENDOR_CODE is '指承运商'
/

comment on column V_LG_CONTRACT.CLAIM_VENDOR_NAME is '指承运商'
/

comment on column V_LG_CONTRACT.BREAK_CLAIMANT_AMOUNT is '对承运商索赔金额（机器损坏）'
/

comment on column V_LG_CONTRACT.BREAK_CLAIMANT_REASON is '对承运商索赔原因（机器损坏）'
/

comment on column V_LG_CONTRACT.BREAK_CLAIMANT_DATE is '对承运商索赔日期（机器损坏）'
/

comment on column V_LG_CONTRACT.DAMAGE_CLAIMANT_AMOUNT is '对承运商索赔金额（包装破损）'
/

comment on column V_LG_CONTRACT.DAMAGE_CLAIMANT_REASON is '对承运商索赔原因（包装破损）'
/

comment on column V_LG_CONTRACT.DAMAGE_CLAIMANT_DATE is '对承运商索赔日期（包装破损）'
/

comment on column V_LG_CONTRACT.BREAK_CLAIM_DATE is '索赔结算日期（机器损坏）'
/

comment on column V_LG_CONTRACT.DAMAGE_CLAIM_DATE is '索赔结算日期（包装破损）'
/

comment on column V_LG_CONTRACT.DAMAGE_INC_DEC_CODE is '费用增减单号（包装破损）'
/

comment on column V_LG_CONTRACT.BREAK_INC_DEC_CODE is '费用增减单号（合同违约）'
/

comment on column V_LG_CONTRACT.CONTRACT_TYPE is '合同类型  00：正常 01： 红冲 '
/

comment on column V_LG_CONTRACT.ORIGIN_CONTRACT_CODE is '原运输合同号 合同冲销时记录'
/

comment on column V_LG_CONTRACT.FREIGHT_BATCH_FLAG is '保险费结算批号是否为空 0：空1：非空'
/

comment on column V_LG_CONTRACT.INSUANCE_BATCH_FLAG is '保险费结算批号是否为空 0：空1：非空'
/

comment on column V_LG_CONTRACT.FREIGHT_BATCH_NUM is '运费费用结算批ID'
/

comment on column V_LG_CONTRACT.INSURANCE_BATCH_NUM is '保险费用结算批ID'
/

comment on column V_LG_CONTRACT.SEND_FLAG is '运输合同是否成功引入 A3'
/

comment on column V_LG_CONTRACT.VENDOR_FLAG is '引承运商接口标志'
/

comment on column V_LG_CONTRACT.VENDOR_ERROR_MESSAGE is '引承运商错误信息'
/

comment on column V_LG_CONTRACT.IMPORT_VENDOR_TIME is '引承运商时间'
/

comment on column V_LG_CONTRACT.CONTRACT_DATE is '生成日期'
/

comment on column V_LG_CONTRACT.REG_CARRIAGE_FLAG is '登记运费标志'
/

comment on column V_LG_CONTRACT.REG_INSURANCE_FLAG is '登记保险费标志'
/

comment on column V_LG_CONTRACT.PROMOTION_PRODUCT_VOL is '推广物料体积'
/

comment on column V_LG_CONTRACT.CREATED_BY is '创建人'
/

comment on column V_LG_CONTRACT.CREATION_DATE is '创建日期'
/

comment on column V_LG_CONTRACT.LAST_UPDATED_BY is '最后修改人'
/

comment on column V_LG_CONTRACT.LAST_UPDATE_DATE is '最后修改日期'
/

comment on column V_LG_CONTRACT.REMARK is '备注'
/

comment on column V_LG_CONTRACT.VEHICLE_NUM is '排车编号'
/

comment on column V_LG_CONTRACT.SHIP_DATE is '发货日期'
/

comment on column V_LG_CONTRACT.VEHICLE_BRAND_NUM is '车牌号码'
/

comment on column V_LG_CONTRACT.CHAUFFEUR is '司机姓名'
/

comment on column V_LG_CONTRACT.CHAUFFEUR_TEL is '司机电话'
/

comment on column V_LG_CONTRACT.CHAUFFEUR_IDENTITY_NUM is '司机身份证号'
/

comment on column V_LG_CONTRACT.SEAL_NUM is '铅封编号'
/

comment on column V_LG_CONTRACT.SEAL_DATE is '铅封时间'
/

comment on column V_LG_CONTRACT.SEAL_BY is '铅封人'
/

comment on column V_LG_CONTRACT.SIGN_SEAL_NUM is '签收铅封编号'
/

comment on column V_LG_CONTRACT.SIGN_SEAL_DATE is '签收铅封时间'
/

comment on column V_LG_CONTRACT.SIGN_SEAL_BY is '签收铅封人员'
/

comment on column V_LG_CONTRACT.SEAL_STATUS is '铅封状态'
/

comment on column V_LG_CONTRACT.VENDOR_ID is '承运单位id'
/

comment on column V_LG_CONTRACT.VENDOR_CODE is '承运商编码'
/

comment on column V_LG_CONTRACT.VENDOR_NAME is '承运商名称'
/

comment on column V_LG_CONTRACT.VENDOR_CONTACT is '承运商联系人'
/

comment on column V_LG_CONTRACT.VENDOR_TEL is '承运商电话'
/

comment on column V_LG_CONTRACT.CARRIER_NAME is '下属承运商'
/

comment on column V_LG_CONTRACT.RECEIVE_SYSTEM is '签收系统'
/

comment on column V_LG_CONTRACT.TRANSFER_CUSTOMER_CODE is '直发客户编码'
/

comment on column V_LG_CONTRACT.TRANSFER_CUSTOMER_NAME is '直发客户名称'
/

