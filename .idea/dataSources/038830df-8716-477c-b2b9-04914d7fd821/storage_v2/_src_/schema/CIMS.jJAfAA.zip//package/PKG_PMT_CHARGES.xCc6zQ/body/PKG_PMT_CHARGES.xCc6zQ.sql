create PACKAGE BODY PKG_PMT_CHARGES IS
  ----------------------------------------------------------------------
  -- Author  : liangym2
  -- Created : 2018-04-03
  --add by liangym2 对字符串按指定字节数长度截取，避免SUBSTRB函数的乱码问题
  ----------------------------------------------------------------------
  FUNCTION F_TRUNCB_VARCHAR
  --
  (IS_STR  VARCHAR2, --
   IN_BLEN          NUMBER
   ) RETURN VARCHAR2 IS
   V_C VARCHAR2(4000);--不允许超过4000
   VN_BLEN  NUMBER := IN_BLEN;
  BEGIN
    IF VN_BLEN > 4000 THEN
      VN_BLEN := 4000;--超过4000无意义，最大为4000
    END IF;
    IF IS_STR IS NULL THEN
      RETURN IS_STR;--为空直接返回
    END IF;
    --字符长度等于字节数长度，直接使用SUBSTR
    IF LENGTH(IS_STR) >= LENGTHB(IS_STR) THEN
      RETURN SUBSTR(IS_STR,1,IN_BLEN);
    END IF;
    --字节数长度小于等于指定的长度，直接返回
    IF VN_BLEN >= LENGTHB(IS_STR) THEN
      RETURN IS_STR;
    END IF;
    V_C := '';
    --循环每个字符，进行拼接，当超过指定的字节数，返回
    FOR I IN 1 .. LENGTH(IS_STR) LOOP
      IF V_C IS NULL THEN
        IF VN_BLEN < LENGTHB(SUBSTR(IS_STR,I,1)) THEN
           RETURN V_C;
        END IF;
      ELSIF VN_BLEN < LENGTHB(V_C || SUBSTR(IS_STR,I,1)) THEN
        RETURN V_C;
      END IF;
      V_C := (V_C || SUBSTR(IS_STR,I,1));
    END LOOP;
    RETURN V_C;
  END;
  
  ----------------------------------------------------------------------
  -- Author  : LIANGYM2
  -- Created : 2016-10-19
  -- Purpose : 推广物料结算批预付款检查
  ----------------------------------------------------------------------
  PROCEDURE P_CHECK_EC_LOAN_INFO(IN_ACCOUNT_HEAD_ID IN NUMBER, --推广物料结算批ID,
                                 OS_RESULT          OUT VARCHAR2, --返回错误码
                                 OS_RESULT_MSG      OUT VARCHAR2, --返回错误信息
                                 IR_ACCOUNT_HEAD    IN T_PMT_ACCOUNT_HEAD%ROWTYPE DEFAULT NULL,
                                 IS_PUB_FIN_SYS     IN VARCHAR2 DEFAULT NULL) IS
    V_PMT_ACCOUNT_HEAD    T_PMT_ACCOUNT_HEAD%ROWTYPE; --推广物料结算批头表
    VR_EMS_CIMS_LM_LOAN_V EMS_CIMS_LM_LOAN_V%ROWTYPE;
    VR_EMS_COMPANY_V      EMS_COMPANY_V%ROWTYPE;
    VN_CNT                VARCHAR2(4000);
    VT_SOURCE_VENDOR_ID   T_LG_VENDOR_INFO_HEAD.SOURCE_VENDOR_ID%TYPE;
  BEGIN
    OS_RESULT          := '1';
    OS_RESULT_MSG      := 'SUCCESS';
    V_PMT_ACCOUNT_HEAD := IR_ACCOUNT_HEAD;
    IF IN_ACCOUNT_HEAD_ID IS NULL AND
       V_PMT_ACCOUNT_HEAD.ACCOUNT_HEAD_ID IS NULL THEN
      OS_RESULT     := '1006';
      OS_RESULT_MSG := '调用参数不能都为空！';
      RETURN;
    END IF;
    IF V_PMT_ACCOUNT_HEAD.ACCOUNT_HEAD_ID IS NULL THEN
      SELECT *
        INTO V_PMT_ACCOUNT_HEAD
        FROM T_PMT_ACCOUNT_HEAD
       WHERE ACCOUNT_HEAD_ID = IN_ACCOUNT_HEAD_ID;
    END IF;
    /*IF V_PMT_ACCOUNT_HEAD.EC_LOAN_INFO_ID IS NULL THEN
      IF V_PMT_ACCOUNT_HEAD.EC_LOAN_REPAY_AMOUNT IS NOT NULL THEN
        OS_RESULT     := '1006';
        OS_RESULT_MSG := '预付款核销金额不为空，预付款单号（ID）不能为空！';
      END IF;
      RETURN;
    ELSIF V_PMT_ACCOUNT_HEAD.EC_LOAN_REPAY_AMOUNT IS NULL THEN
      OS_RESULT     := '1006';
      OS_RESULT_MSG := '预付款单号（ID）不为空，预付款核销金额不能为空！';
      RETURN;
    ELSIF V_PMT_ACCOUNT_HEAD.EC_LOAN_REPAY_AMOUNT <= 0 THEN
      OS_RESULT     := '1006';
      OS_RESULT_MSG := '预付款单号（ID）不为空，预付款核销金额不能为空！';
      RETURN;
    ELSIF V_PMT_ACCOUNT_HEAD.EC_LOAN_REPAY_AMOUNT > V_PMT_ACCOUNT_HEAD.ACCOUNT_AMOUNT THEN
      OS_RESULT     := '1006';
      OS_RESULT_MSG := '预付款单号（ID）不为空，预付款核销金额' || V_PMT_ACCOUNT_HEAD.EC_LOAN_REPAY_AMOUNT
      || '不能大于结算批票面含税金额' || V_PMT_ACCOUNT_HEAD.ACCOUNT_AMOUNT;
      RETURN;
    ELSIF V_PMT_ACCOUNT_HEAD.EC_LOAN_INFO_CODE IS NULL THEN
      OS_RESULT     := '1006';
      OS_RESULT_MSG := '预付款ID不为空，预付款单号不能为空！';
      RETURN;
    END IF;*/
    
    IF V_PMT_ACCOUNT_HEAD.EC_LOAN_REPAY_AMOUNT IS NOT NULL AND V_PMT_ACCOUNT_HEAD.EC_LOAN_REPAY_AMOUNT > V_PMT_ACCOUNT_HEAD.ACCOUNT_AMOUNT THEN
      OS_RESULT     := '1006';
      OS_RESULT_MSG := '预付款核销金额' || V_PMT_ACCOUNT_HEAD.EC_LOAN_REPAY_AMOUNT
                       || '不能大于结算批票面含税金额' || V_PMT_ACCOUNT_HEAD.ACCOUNT_AMOUNT;
      RETURN;
    END IF;
    
    --add by tangjz2  2019-07-24 预付款单修改为多条
    FOR LOAN_INFOS IN (SELECT * FROM T_PMT_ACCOUNT_LOAN_INFO A WHERE A.ACCOUNT_HEAD_ID = IN_ACCOUNT_HEAD_ID) LOOP
      SELECT V.LOAN_INFO_CODE,
         V.APPROVE_AMOUNT,
         V.ALREADY_REPAY_AMOUNT,
         V.VENDOR_ID,
         VH.SOURCE_VENDOR_ID,
         V.VENDOR_SITE_ID,
         ECV.COMPANY_ID,
         ECV.OU_ID,
         MAX(ECV.START_DATE) AS START_DATE,
         MAX(DECODE(ECV.END_DATE, NULL, 1 + TRUNC(SYSDATE), ECV.END_DATE)) AS END_DATE,
         LISTAGG(AH.ACCOUNT_NUM, ',') WITHIN GROUP(ORDER BY AH.ACCOUNT_HEAD_ID) AS CNT,
         (CASE
           WHEN V.BIZ_STATUS IN ('PAID', 'PART_REPAY') THEN
            1
           ELSE
            0
         END) AS BIZ_STATUS
      INTO VR_EMS_CIMS_LM_LOAN_V.LOAN_INFO_CODE,
           VR_EMS_CIMS_LM_LOAN_V.APPROVE_AMOUNT,
           VR_EMS_CIMS_LM_LOAN_V.ALREADY_REPAY_AMOUNT,
           VR_EMS_CIMS_LM_LOAN_V.VENDOR_ID,
           VT_SOURCE_VENDOR_ID,
           VR_EMS_CIMS_LM_LOAN_V.VENDOR_SITE_ID,
           VR_EMS_COMPANY_V.COMPANY_ID,
           VR_EMS_COMPANY_V.OU_ID,
           VR_EMS_COMPANY_V.START_DATE,
           VR_EMS_COMPANY_V.END_DATE,
           VN_CNT,
           VR_EMS_CIMS_LM_LOAN_V.BIZ_STATUS
      FROM EMS_CIMS_LM_LOAN_V V
     INNER JOIN T_LG_VENDOR_INFO_HEAD VH
        ON (VH.VENDOR_ID = V_PMT_ACCOUNT_HEAD.VENDOR_ID)
      LEFT JOIN EMS_COMPANY_V ECV
        ON (ECV.COMPANY_ID = V.COMPANY_ID
        AND (
        (ECV.PROXY_USER = 'gerp_io' AND (IS_PUB_FIN_SYS IS NULL OR 'NC' <> IS_PUB_FIN_SYS) )
        OR ('NC' = IS_PUB_FIN_SYS AND 'MIDEAXS_NC' = UPPER(ECV.PROXY_USER) )
        )
        )
      LEFT JOIN T_PMT_ACCOUNT_HEAD AH
        ON (AH.EC_LOAN_INFO_ID = V.LOAN_INFO_ID AND
           AH.STATUS NOT IN ('00', '01', '07', '08') AND
           AH.ACCOUNT_HEAD_ID <> V_PMT_ACCOUNT_HEAD.ACCOUNT_HEAD_ID)
     WHERE V.LOAN_INFO_ID = LOAN_INFOS.EC_LOAN_INFO_ID
     GROUP BY V.LOAN_INFO_CODE,
              V.APPROVE_AMOUNT,
              V.ALREADY_REPAY_AMOUNT,
              V.VENDOR_ID,
              VH.SOURCE_VENDOR_ID,
              V.VENDOR_SITE_ID,
              V.BIZ_STATUS,
              ECV.COMPANY_ID,
              ECV.OU_ID;
      IF V_PMT_ACCOUNT_HEAD.EC_LOAN_INFO_CODE <>
         VR_EMS_CIMS_LM_LOAN_V.LOAN_INFO_CODE THEN
        OS_RESULT     := '1006';
        OS_RESULT_MSG := '结算批的预付款单号' || V_PMT_ACCOUNT_HEAD.EC_LOAN_INFO_CODE ||
                         '与结算批的预付款单ID：' || V_PMT_ACCOUNT_HEAD.EC_LOAN_INFO_ID ||
                         '对应EMS的预付款单号' ||
                         VR_EMS_CIMS_LM_LOAN_V.LOAN_INFO_CODE || '不一致';
        RETURN;
      ELSIF VT_SOURCE_VENDOR_ID <> VR_EMS_CIMS_LM_LOAN_V.VENDOR_ID THEN
        OS_RESULT     := '1006';
        OS_RESULT_MSG := '结算批的供应商ID：' || V_PMT_ACCOUNT_HEAD.VENDOR_ID ||
                         '来源于SRM的供应商ID：' || VT_SOURCE_VENDOR_ID ||
                         '，与结算批的预付款单ID：' ||
                         V_PMT_ACCOUNT_HEAD.EC_LOAN_INFO_ID || '对应EMS的供应商ID：' ||
                         VR_EMS_CIMS_LM_LOAN_V.VENDOR_ID || '不一致';
        RETURN;
      ELSIF V_PMT_ACCOUNT_HEAD.VENDOR_SITE_ID <>
            VR_EMS_CIMS_LM_LOAN_V.VENDOR_SITE_ID THEN
        OS_RESULT     := '1006';
        OS_RESULT_MSG := '结算批的供应商地点ID：' || V_PMT_ACCOUNT_HEAD.VENDOR_SITE_ID ||
                         '与结算批的预付款单ID：' || V_PMT_ACCOUNT_HEAD.EC_LOAN_INFO_ID ||
                         '对应EMS的供应商地点ID：' ||
                         VR_EMS_CIMS_LM_LOAN_V.VENDOR_SITE_ID || '不一致';
        RETURN;
      ELSIF V_PMT_ACCOUNT_HEAD.ACCOUNT_UNIT_ID <> VR_EMS_COMPANY_V.OU_ID THEN
        OS_RESULT     := '1006';
        OS_RESULT_MSG := '结算批的入账单位ID：' || V_PMT_ACCOUNT_HEAD.ACCOUNT_UNIT_ID ||
                         '与结算批的预付款单ID：' || V_PMT_ACCOUNT_HEAD.EC_LOAN_INFO_ID ||
                         '对应EMS的入账单位ID：' || VR_EMS_COMPANY_V.OU_ID || '不一致';
        RETURN;
      ELSIF 1 <> VR_EMS_CIMS_LM_LOAN_V.BIZ_STATUS THEN
        OS_RESULT     := '1006';
        OS_RESULT_MSG := '结算批的预付款单号' || V_PMT_ACCOUNT_HEAD.EC_LOAN_INFO_CODE ||
                         '在EMS状态不可核销';
        RETURN;
      ELSIF VR_EMS_COMPANY_V.START_DATE IS NULL THEN
        OS_RESULT     := '1006';
        OS_RESULT_MSG := '结算批的预付款单ID：' || V_PMT_ACCOUNT_HEAD.EC_LOAN_INFO_ID ||
                         '对应EMS的公司ID' || VR_EMS_COMPANY_V.COMPANY_ID ||
                         '的有效起始日期为空';
        RETURN;
      ELSIF SYSDATE < VR_EMS_COMPANY_V.START_DATE THEN
        OS_RESULT     := '1006';
        OS_RESULT_MSG := '结算批的预付款单ID： ' || V_PMT_ACCOUNT_HEAD.EC_LOAN_INFO_ID ||
                         '对应EMS的公司ID：' || VR_EMS_COMPANY_V.COMPANY_ID ||
                         '的有效起始日期还没到';
        RETURN;
      ELSIF SYSDATE > VR_EMS_COMPANY_V.END_DATE THEN
        OS_RESULT     := '1006';
        OS_RESULT_MSG := '结算批的预付款单ID：' || V_PMT_ACCOUNT_HEAD.EC_LOAN_INFO_ID ||
                         '对应EMS的公司ID：' || VR_EMS_COMPANY_V.COMPANY_ID ||
                         '的有效终止日期已经到期';
        RETURN;
      ELSIF VR_EMS_CIMS_LM_LOAN_V.APPROVE_AMOUNT IS NULL THEN
        OS_RESULT     := '1006';
        OS_RESULT_MSG := '结算批的预付款单ID：' || V_PMT_ACCOUNT_HEAD.EC_LOAN_INFO_ID ||
                         '的批准金额为空';
        RETURN;
      ELSIF V_PMT_ACCOUNT_HEAD.EC_LOAN_INFO_CODE <>
            VR_EMS_CIMS_LM_LOAN_V.LOAN_INFO_CODE THEN
        OS_RESULT     := '1006';
        OS_RESULT_MSG := '结算批的预付款本次核销金额：' ||
                         V_PMT_ACCOUNT_HEAD.EC_LOAN_REPAY_AMOUNT ||
                         '不能大于预付款单' || V_PMT_ACCOUNT_HEAD.EC_LOAN_INFO_CODE ||
                         '的剩余核销金额：' ||
                         (VR_EMS_CIMS_LM_LOAN_V.APPROVE_AMOUNT -
                         NVL(VR_EMS_CIMS_LM_LOAN_V.ALREADY_REPAY_AMOUNT, 0));
        RETURN;
      ELSIF VN_CNT IS NOT NULL THEN
        OS_RESULT     := '1006';
        OS_RESULT_MSG := '预付款单' || V_PMT_ACCOUNT_HEAD.EC_LOAN_INFO_CODE ||
                         '存在在途的结算批：' || VN_CNT;
        RETURN;
      END IF;
    END LOOP;
    
  END P_CHECK_EC_LOAN_INFO;

  ----------------------------------------------------------------------
  -- Author  : liyuanji
  -- Created : 2015-01-15
  -- Purpose : 推广物料采购支付（EMS）
  ----------------------------------------------------------------------
Procedure P_CHARGES_PAYMENT(i_Account_Head_Id In Number, --推广物料结算批ID
                            i_Account         In Varchar2, --登录账号
                            o_Result          Out Varchar2, --返回错误码
                            o_Result_Msg      Out Varchar2 --返回错误信息
                            ) Is
  v_Pmt_Account_Head     t_Pmt_Account_Head%Rowtype; --推广物料结算批头表
  v_Invoice_Amount       Number; --发票汇总金额
  v_Invoice_Tax_Amount   Number; --发票汇总税额
  v_Ems_Io_Ec_Fee_Reim_h Ems_Io_Ec_Fee_Reim_h%Rowtype; --EMS报销支付头表
  v_Ems_Io_Ec_Fee_Loan   Ems_Io_Ec_Fee_Loan%Rowtype; --EMS预付款接口表
  v_Fee_Budget_Seq       Ems_Io_Ec_Fee_Reim_h.Io_Fee_Reim_Id%Type; --EMS报销支付头表序列
  v_Sysdate              Date; --系统当前时间
  v_Ems_Io_Ec_Fee_Budget Ems_Io_Ec_Fee_Budget%Rowtype; --EMS报销支付行表
  v_Ems_Io_Ec_Fee_Tax    Ems_Io_Ec_Fee_Tax%Rowtype; --EMS报销支付接口税明细表
  v_Fee_Budgetio_Seq     Ems_Io_Ec_Fee_Budget.Io_Fee_Budget_Id%Type; --EMS报销支付行表序列
  v_ems_io_attach_file_Seq Ems_Io_Attach_File.IO_ORDER_ID%Type; --EMS文件表序列
  v_ems_io_attach_file   Ems_Io_Attach_File%Rowtype; --EMS文件表
  --V_BUDGET_ORG_CODE      T_POL_SALES_ORG_RELATION.BUDGET_ORG_CODE%TYPE; --预算组织编码
  v_Ems_Io_Ec_Fee_Budget_Po Ems_Io_Ec_Fee_Budget_Po%Rowtype; --PO匹配明细表
  v_Cnt                     Number; --
  v_Sys_Id                  Mdp_Workflow_Form.Sys_Id%Type; --工作流对接系统ID
  v_Source_Order_Url        Ems_Io_Ec_Fee_Reim_h.Source_Order_Url%Type;
  v_Source_Order_Url_Pre    Varchar2(30);
  --V_SOURCE_ORDER_URL1       EMS_IO_EC_FEE_REIM_H.SOURCE_ORDER_URL%TYPE;
  v_Order_Head_Id               t_Pmt_Order_Header.Order_Head_Id%Type;
  v_Mdp_Workflow_Form           Mdp_Workflow_Form%Rowtype;
  Vt_Vendor_Id                  t_Lg_Vendor_Info_Head.Vendor_Id%Type;
  Vt_Vendor_Operating_Id        t_Lg_Vendor_Info_Line.Operating_Unit%Type;
  Vt_Vendor_Site_Code           t_Lg_Vendor_Info_Line.Vendor_Site_Code%Type;
  Vt_Ems_Loan_Ss_Cv             Ems_Io_Ec_Fee_Loan.Source_Order_Type%Type;
  Vt_Ems_Fee_Type_Code          Ems_Cims_Fee_Type_v.Fee_Type_Code%Type;
  v_Pmt_Account_Ems_Remark_Flag Varchar2(10); -- 校验备注信息是否写入接口表 by sushu 2017-03-02
  Vt_Settle_Amount              t_Pmt_Account_Head.Settle_Amount%Type; --结算申请金额
  Vt_Tax_Payment_Amount         t_Pmt_Account_Head.Tax_Payment_Amount%Type; --完税凭证金额
  Vt_Project_Type               t_Pmt_Account_Head.Project_Type%Type; --项目类型
  Vt_Payment_Project_Type       t_Pmt_Account_Head.Project_Type%Type;
  --完税凭证 项目类型 实际并无完税凭证的项目类型 只是为了通过此码表关联到 完税凭证的税率类型
  Vt_Payment_Fee_Type_Code Ems_Cims_Fee_Type_v.Fee_Type_Code%Type; --完税凭证的税率类型
  Vv_Tax_Attribute1        Varchar2(50) := 'TAX';
  Vv_Pub_Fin_Sys           t_Bd_Param_List.Default_Value%Type; --对接财务系统 by liangym2 2017-5-31
  Vt_Sales_Center_Id       t_Pmt_Order_Header.Sales_Center_Id%Type; --营销中心ID add by liangym2 2017-6-5
  Vt_Budget_Node_Id1       Ems_Io_Ec_Fee_Budget.Budget_Node_Id%Type; --产品差异预算单元ID add by liangym2 2017-6-5
  Vt_Budget_Node_Id2       Ems_Io_Ec_Fee_Budget.Budget_Node_Id%Type; --PO匹配行预算单元ID add by liangym2 2017-6-5
  Vs_Sc_Name               Mdp_Workflow_Form.Url%Type := 'ims';
  Vs_Dc_Name               Mdp_Workflow_Form.Url%Type := 'promotionmanage';
  Vs_Vw_Name               Mdp_Workflow_Form.Url%Type := 'promotionOrderAccountAdd';
  V_EMS_IO_EC_HT_L_S       NUMBER; -- 法务合同主键 add by ex_zhangka 2018-08-18
  V_CONTRACT_BARCODE       VARCHAR2(108);
  V_RECEIPT_METHOD_NAME    VARCHAR2(300);
  V_ZKK_AMOUNT             NUMBER;

Begin
  o_Result     := '1';
  o_Result_Msg := '引入EMS成功';

  --通过结算批头ID查询结算批信息
  Begin
    Select *
      Into v_Pmt_Account_Head
      From t_Pmt_Account_Head
     Where Account_Head_Id = i_Account_Head_Id
       For Update Nowait;
    --
    If 'TG' = v_Pmt_Account_Head.Order_Type Then
      Select Order_Head_Id,
             Vendor_Id,
             Nvl(Vendor_Operating_Id, Finance_Operating_Id),
             Deliver_Site
      
        Into v_Order_Head_Id,
             Vt_Vendor_Id,
             Vt_Vendor_Operating_Id,
             Vt_Vendor_Site_Code
      
        From (Select Order_Head_Id,
                     Vendor_Id,
                     Vendor_Operating_Id,
                     Finance_Operating_Id,
                     Deliver_Site
                From t_Pmt_Order_Header Oh
               Where Entity_Id = v_Pmt_Account_Head.Entity_Id
                 And Exists
               (Select 1
                        From t_Pmt_Account_Line l
                       Where l.Account_Head_Id =
                             v_Pmt_Account_Head.Account_Head_Id
                         And l.Order_Head_Id = Oh.Order_Head_Id
                         And l.Entity_Id = v_Pmt_Account_Head.Entity_Id)
               Order By Order_Head_Id)
       Where 1 = Rownum;
    Elsif 'SC' = v_Pmt_Account_Head.Order_Type Then
      Select Order_Head_Id,
             Vendor_Id,
             Nvl(Vendor_Operating_Id, Finance_Operating_Id),
             Deliver_Site
      
        Into v_Order_Head_Id,
             Vt_Vendor_Id,
             Vt_Vendor_Operating_Id,
             Vt_Vendor_Site_Code
      
        From (Select Quotation_Id As Order_Head_Id,
                     Oh.Vendor_Id As Vendor_Id,
                     --报价单头 无供应商经营单位ID（包括FINANCE_OPERATING_ID）、供应商地点，故取验收单头
                     Nvl(v_Pmt_Account_Head.Vendor_Unit_Id,
                         v_Pmt_Account_Head.Account_Unit_Id) As Vendor_Operating_Id,
                     Cast(Null As Numeric) As Finance_Operating_Id,
                     v_Pmt_Account_Head.Vendor_Site_Code As Deliver_Site
                From t_Pmt_Quotation_Head Oh
               Where Entity_Id = v_Pmt_Account_Head.Entity_Id
                 And Exists
               (Select 1
                        From t_Pmt_Account_Line l
                       Where l.Account_Head_Id =
                             v_Pmt_Account_Head.Account_Head_Id
                         And l.Order_Head_Id = Oh.Quotation_Id
                         And l.Entity_Id = v_Pmt_Account_Head.Entity_Id)
               Order By Quotation_Id)
       Where 1 = Rownum;
    Elsif 'PO' = v_Pmt_Account_Head.Order_Type Then
      Select Order_Head_Id,
             Vendor_Id,
             Nvl(Vendor_Operating_Id, Finance_Operating_Id),
             Deliver_Site
      
        Into v_Order_Head_Id,
             Vt_Vendor_Id,
             Vt_Vendor_Operating_Id,
             Vt_Vendor_Site_Code
      
        From (Select Oh.PO_ID as Order_Head_Id,
                     Oh.Vendor_Id,
                     Oh.Vendor_Operating_Id,
                     Oh.Finance_Operating_Id,
                     Oh.Vendor_Site_Code As Deliver_Site
                From t_inv_po_headers Oh
               Where Entity_Id = v_Pmt_Account_Head.Entity_Id
                 And Exists
               (Select 1
                        From t_Pmt_Account_Line l
                       Where l.Account_Head_Id =
                             v_Pmt_Account_Head.Account_Head_Id
                         And l.Order_Head_Id = Oh.PO_ID
                         And l.Entity_Id = v_Pmt_Account_Head.Entity_Id)
               Order By Order_Head_Id)
       Where 1 = Rownum;
    End If;
  
  Exception
    When Others Then
      o_Result     := '1001';
      o_Result_Msg := '结算批信息不存在！';
      Return;
  End;

  If '05' = v_Pmt_Account_Head.Status Then
    o_Result     := '1001';
    o_Result_Msg := '结算批信息已引入EMS，请勿重复付款！';
    Return;
  End If;

  If '07' = v_Pmt_Account_Head.Status Then
    o_Result     := '1001';
    o_Result_Msg := '结算批在EMS已结算成功，不允许引入EMS！';
    Return;
  End If;

  If '04' <> v_Pmt_Account_Head.Status And
     '06' <> v_Pmt_Account_Head.Status Then
    o_Result     := '1001';
    o_Result_Msg := '结算批不是已匹配、EMS驳回状态，不允许引入EMS！';
    Return;
  End If;

  Select Count(0)
    Into v_Cnt
    From t_Lg_Vendor_Info_Head T0, t_Lg_Vendor_Info_Line T1
   Where T0.Vendor_Id = T1.Vendor_Id
     And T0.Entity_Id = v_Pmt_Account_Head.Entity_Id
     And T0.Vendor_Id = Vt_Vendor_Id
     And T1.Operating_Unit = Vt_Vendor_Operating_Id
     And T1.Vendor_Site_Code = Vt_Vendor_Site_Code
     And T1.Status = 'FAILURE'
     And T1.Oper_Type = '01'
     And Nvl(T1.Vendor_Site_Code, '地点') Not In ('非贸易型', '押金质保金');

  If 0 < v_Cnt Then
    o_Result     := '1002';
    o_Result_Msg := '结算批对应的供应商已失效！';
    Return;
  End If;

  Select Count(Distinct t.Sys_Id), Max(t.Sys_Id)
    Into v_Cnt, v_Sys_Id
    From Mdp_Workflow_Form t
   Where t.Url Like '/ims/promotionmanage/%'
      Or t.Url Like 'ims/promotionmanage/%'
      Or t.Url Like '//ims/promotionmanage/%';
  v_Source_Order_Url := 'http://cims.midea.com/cims';
  If 1 = v_Cnt Then
    If v_Sys_Id = 'CimsUAT2' Then
      v_Source_Order_Url_Pre := 'cimsuat2';
      v_Source_Order_Url     := 'http://cimsuat2.midea.com/cims';
    Elsif v_Sys_Id = 'CimsUatTwo' Then
      v_Source_Order_Url_Pre := 'cimsuat1';
      v_Source_Order_Url     := 'http://cimsuat1.midea.com/cims';
    Elsif v_Sys_Id = 'CimsUAT' Then
      v_Source_Order_Url_Pre := 'vercims';
      v_Source_Order_Url     := 'http://vercims.midea.com/cims';
    End If;
  End If;
  --V_SOURCE_ORDER_URL1 := V_SOURCE_ORDER_URL;
  v_Source_Order_Url := v_Source_Order_Url || '/';
  v_Source_Order_Url := v_Source_Order_Url || Vs_Sc_Name;
  v_Source_Order_Url := v_Source_Order_Url || '/';
  v_Source_Order_Url := v_Source_Order_Url || Vs_Dc_Name;
  v_Source_Order_Url := v_Source_Order_Url || '/';
  v_Source_Order_Url := v_Source_Order_Url || Vs_Vw_Name;
  v_Source_Order_Url := v_Source_Order_Url ||
                        '-view.jsp?operMode=view&formInstanceId=';
  v_Source_Order_Url := v_Source_Order_Url || i_Account_Head_Id ||
                        '&orderId=' || v_Order_Head_Id;
  v_Source_Order_Url := v_Source_Order_Url || '&ENTITYID=' ||
                        v_Pmt_Account_Head.Entity_Id;
  If v_Source_Order_Url_Pre Is Not Null Then
    v_Source_Order_Url := v_Source_Order_Url || '&urlPrefix=' ||
                          v_Source_Order_Url_Pre;
  End If;

  --SELECT * FROM T_BD_FLOW_TEMPLATE_CONFIG T WHERE T.TEMPLATE_FORM_ID = AND T.ENTITY_ID = V_PMT_ACCOUNT_HEAD.ENTITY_ID
  --AND 'Y' = T.ACTIVE_FLAG AND T.TYPE_CODE = '';

  /*
  *
  flowTemplateId
  flowDefinitionId
  processInstanceId
  */
  Begin
    Select *
      Into v_Mdp_Workflow_Form
      From Mdp_Workflow_Form t
     Where t.Url Like '/' || Vs_Sc_Name || '/' || Vs_Dc_Name || '/' ||
           Vs_Vw_Name || '-view.jsp%'
       And 1 = Rownum;
    v_Source_Order_Url := v_Source_Order_Url || '&sysId=' ||
                          v_Mdp_Workflow_Form.Sys_Id;
    v_Source_Order_Url := v_Source_Order_Url || '&modelId=' ||
                          v_Mdp_Workflow_Form.Model_Id;
    v_Source_Order_Url := v_Source_Order_Url || '&templateFormId=' ||
                          v_Mdp_Workflow_Form.Template_Form_Id;
    --V_SOURCE_ORDER_URL := V_SOURCE_ORDER_URL || '&flowDefinitionId=Cims';
  Exception
    When Others Then
      Null;
  End;

  /* BEGIN
    SELECT * INTO V_MDP_WORKFLOW_FORM FROM MDP_WORKFLOW_FORM t
    WHERE t.URL LIKE '/ims/promotionmanage/promotionOrderViewer-view.jsp%' and 1 = ROWNUM;
    V_SOURCE_ORDER_URL1 := V_SOURCE_ORDER_URL1 || '&sysId=' || V_MDP_WORKFLOW_FORM.Sys_Id;
    V_SOURCE_ORDER_URL1 := V_SOURCE_ORDER_URL1 || '&modelId=' || V_MDP_WORKFLOW_FORM.Model_Id;
    V_SOURCE_ORDER_URL1 := V_SOURCE_ORDER_URL1 || '&templateFormId=' || V_MDP_WORKFLOW_FORM.Template_Form_Id;
    
    V_SOURCE_ORDER_URL := V_SOURCE_ORDER_URL || '&sysId1=' || V_MDP_WORKFLOW_FORM.Sys_Id;
    V_SOURCE_ORDER_URL := V_SOURCE_ORDER_URL || '&modelId1=' || V_MDP_WORKFLOW_FORM.Model_Id;
    V_SOURCE_ORDER_URL := V_SOURCE_ORDER_URL || '&templateFormId1=' || V_MDP_WORKFLOW_FORM.Template_Form_Id;
  EXCEPTION
    WHEN OTHERS THEN
      NULL;
  END;*/

  --判断结算批状态（发票匹配）
  If v_Pmt_Account_Head.Status <> '04' Then
    --O_RESULT     := '1002';
    --O_RESULT_MSG := '当前结算批不能引入EMS，请检查结算批状态！';
    --RETURN;
    --测试使用
    Null;
  
  End If;

  --通过结算批编码查询结算批对应发票信息的汇总金额和税额--add by liangym2 2018-2-5 start
  If 'SC' = v_Pmt_Account_Head.Order_Type Then
    v_Invoice_Amount := v_Pmt_Account_Head.Balance_Has_Rate;
  Else
    --add by liangym2 2018-2-5 end
    Begin
      Select Nvl(Sum(Invoice_Amount), 0), Nvl(Sum(Tax_Amount), 0)
        Into v_Invoice_Amount, v_Invoice_Tax_Amount
        From t_Pmt_Receipt_Info
       Where Account_Num = v_Pmt_Account_Head.Account_Num;
    Exception
      When Others Then
        Null;
    End;
  
    --判断结算批对应的发票是否存在
    If v_Invoice_Amount = 0 Then
    
      o_Result     := '1003';
      o_Result_Msg := '结算批对应的发票金额为0，请检查！';
      Return;
    End If;
  
    --add by liangym2 2018-2-5 start
  End If;
  --add by liangym2 2018-2-5 end

  --判断结算批信息金额跟发票信息是否一致
  /*  IF V_PMT_ACCOUNT_HEAD.BALANCE_HAS_RATE <> V_INVOICE_AMOUNT THEN
  
     O_RESULT     := '1004';
     O_RESULT_MSG := '结算批金额与发票信息不一致，请检查！';
     RETURN;
   END IF;
  */

  --判断结算批信息税额跟发票信息是否一致
  /*   IF (V_PMT_ACCOUNT_HEAD.BALANCE_HAS_RATE -
     V_PMT_ACCOUNT_HEAD.Balance_No_Rate) <> V_INVOICE_TAX_AMOUNT THEN
  
    O_RESULT     := '1005';
    O_RESULT_MSG := '结算批税额与发票信息不一致，请检查！';
    RETURN;
  END IF;
  
  */

  --头表序列
  v_Fee_Budget_Seq := Ems_Io_Ec_Fee_Reim_h_s.Nextval;
  --获取系统当前时间
  v_Sysdate := Sysdate;
  --构建报销支付头表
  v_Ems_Io_Ec_Fee_Reim_h.Io_Fee_Reim_Id  := v_Fee_Budget_Seq; --接口主键ID
  v_Ems_Io_Ec_Fee_Reim_h.Apply_Ldap_Code := i_Account; --申请人LDAP编码
  v_Ems_Io_Ec_Fee_Reim_h.Reim_Date       := v_Sysdate; --报销日期

  --获取公司ID(获取入账单位ID) ---正式的时候打开注释

  --获取对接财务系统 by liangym2
  Begin
    Pkg_Bd.p_Get_Parameter_Value('PUB_FIN_SYS',
                                 v_Pmt_Account_Head.Entity_Id,
                                 Null,
                                 Null,
                                 Vv_Pub_Fin_Sys);
  Exception
    When Others Then
      v_Ems_Io_Ec_Fee_Reim_h.Is_Offer := 'N'; --默认值
  End;
  --这里用到的是ACCOUNT_UNIT_ID，不是VENDOR_UNIT_ID，对于验收单是否设置，如何取值，请了解view的源码
  Begin
    If 'NC' = Vv_Pub_Fin_Sys Then
      Select Company_Id
        Into v_Ems_Io_Ec_Fee_Reim_h.Company_Id
        From Ems_Company_v
       Where Ou_Id = v_Pmt_Account_Head.Account_Unit_Id
         And Upper(Proxy_User) = 'MIDEAXS_NC'; ----add by 梁颜明
    Else
      Select Company_Id
        Into v_Ems_Io_Ec_Fee_Reim_h.Company_Id
        From Ems_Company_v
       Where Ou_Id = v_Pmt_Account_Head.Account_Unit_Id
         And Proxy_User = 'gerp_io'; ----add by 梁颜明
    End If;
  Exception
    When Others Then
      o_Result     := '1006';
      o_Result_Msg := '公司ID不存在！';
      Return;
  End;

  p_Check_Ec_Loan_Info(i_Account_Head_Id, o_Result, o_Result_Msg, NULL, Vv_Pub_Fin_Sys);
  If o_Result <> '1' Then
    Return;
  End If;

  --  v_Ems_Io_Ec_Fee_Reim_h.Company_Id        := '12919'; ---测试用 公司ID
  v_Ems_Io_Ec_Fee_Reim_h.Currency_Code := 'CNY'; --币种
  Vt_Settle_Amount                     := v_Pmt_Account_Head.Settle_Amount;
  If Vt_Settle_Amount Is Null Then
    Vt_Settle_Amount := v_Pmt_Account_Head.Account_Amount;
  End If;
  v_Ems_Io_Ec_Fee_Reim_h.Apply_Reim_Amount := Vt_Settle_Amount; --结算金额
  v_Ems_Io_Ec_Fee_Reim_h.Pay_Amount        := Vt_Settle_Amount; --结算金额

  If v_Pmt_Account_Head.Remark Is Null Then
    If 'SC' = v_Pmt_Account_Head.Order_Type Then
      v_Ems_Io_Ec_Fee_Reim_h.Reason_Desc := '市场费用验收';
    Elsif 'PO' = v_Pmt_Account_Head.Order_Type Then
      v_Ems_Io_Ec_Fee_Reim_h.Reason_Desc := '采购单结算';
    Else
      v_Ems_Io_Ec_Fee_Reim_h.Reason_Desc := '推广物料采购结算';
    End If;
  Else
    v_Ems_Io_Ec_Fee_Reim_h.Reason_Desc := v_Pmt_Account_Head.Remark; --摘要
  End If;

  --获取供应商地点ID 暂时取第一行 正式的时候打开

  v_Ems_Io_Ec_Fee_Reim_h.Vendor_Site_Id := v_Pmt_Account_Head.Vendor_Site_Id;

  --测试
  --  v_Ems_Io_Ec_Fee_Reim_h.Vendor_Site_Id := '214347'; --测试用

  v_Ems_Io_Ec_Fee_Reim_h.Receiver     := v_Pmt_Account_Head.Bank_Account_Name; --收款方
  v_Ems_Io_Ec_Fee_Reim_h.Bank_Name    := v_Pmt_Account_Head.Deposit_Bank; --开户银行
  v_Ems_Io_Ec_Fee_Reim_h.Bank_Account := v_Pmt_Account_Head.Bank_Account; --开户银行
  v_Ems_Io_Ec_Fee_Reim_h.Ubank_No     := v_Pmt_Account_Head.Ubank_No; --联行号

  --判断联行号是否为空
  If v_Ems_Io_Ec_Fee_Reim_h.Ubank_No Is Null Then
  
    o_Result     := '1011';
    o_Result_Msg := '结算批对应的联行号不存在！';
    Return;
  
  End If;

  --add by liangym2 PAYMENT_METHOD默认等于PAYMENT_TYPE 不用写死转换
  v_Ems_Io_Ec_Fee_Reim_h.Payment_Method := v_Pmt_Account_Head.Payment_Type;
  ----add by 10.24 支付类型传入到EMS中
  --电汇
  If v_Pmt_Account_Head.Payment_Type = '01' Then
  
    --v_Ems_Io_Ec_Fee_Reim_h.Payment_Method := 'CASH';
    v_Ems_Io_Ec_Fee_Reim_h.Payment_Method := 'WIRE';
  
    --纸质承兑汇票
  Elsif v_Pmt_Account_Head.Payment_Type = '02' Then
  
    v_Ems_Io_Ec_Fee_Reim_h.Payment_Method := 'CHENGDUI';
  
    --电子承兑汇票
  Elsif v_Pmt_Account_Head.Payment_Type = '03' Then
  
    v_Ems_Io_Ec_Fee_Reim_h.Payment_Method := 'EFTCD';
  
  End If;

  --获取EMS的EC操盘值 add by 11.16
  Begin
    Pkg_Bd.p_Get_Parameter_Value('isOffer',
                                 v_Pmt_Account_Head.Entity_Id,
                                 Null,
                                 Null,
                                 v_Ems_Io_Ec_Fee_Reim_h.Is_Offer);
  Exception
    When Others Then
      v_Ems_Io_Ec_Fee_Reim_h.Is_Offer := 'N'; --默认值
  End;

  --获取供应商 省、市、供应商ID  正式库打开数据

  Begin
    Select Province, City, Source_Vendor_Id
      Into v_Ems_Io_Ec_Fee_Reim_h.Province,
           v_Ems_Io_Ec_Fee_Reim_h.City,
           v_Ems_Io_Ec_Fee_Reim_h.Vendor_Id
      From t_Lg_Vendor_Info_Head
     Where Vendor_Id = v_Pmt_Account_Head.Vendor_Id;
  Exception
    When Others Then
      o_Result     := '1008';
      o_Result_Msg := '供应商省、市信息不存在！';
      Return;
  End;

  --  v_Ems_Io_Ec_Fee_Reim_h.Province  := '广东省';  --测试用数据
  --  v_Ems_Io_Ec_Fee_Reim_h.City      := '佛山市';  --测试用数据
  --  v_Ems_Io_Ec_Fee_Reim_h.Vendor_Id := '1520';    --测试用数据

  v_Ems_Io_Ec_Fee_Reim_h.Order_Type             := 'TY'; --单据类型
  v_Ems_Io_Ec_Fee_Reim_h.Created_Ldap_Code      := i_Account; --创建人LDAP编码
  v_Ems_Io_Ec_Fee_Reim_h.Creation_Date          := v_Sysdate; --创建日期
  v_Ems_Io_Ec_Fee_Reim_h.Last_Updated_Ldap_Code := i_Account; --最后更新人LDAP编码
  v_Ems_Io_Ec_Fee_Reim_h.Last_Update_Date       := v_Sysdate; --最后更新日期
  v_Ems_Io_Ec_Fee_Reim_h.Ou_Id                  := v_Pmt_Account_Head.Account_Unit_Id; --OU_ID
  v_Ems_Io_Ec_Fee_Reim_h.Pay_Type               := 'NORMAL_PAY'; --支付类型
  v_Ems_Io_Ec_Fee_Reim_h.Source_System          := 'CIMS'; --来源系统
  --
  v_Ems_Io_Ec_Fee_Reim_h.Source_Order_Id   := v_Pmt_Account_Head.Account_Head_Id; --来源单据ID
  v_Ems_Io_Ec_Fee_Reim_h.Source_Order_Code := v_Pmt_Account_Head.Account_Num; --来源单据编码
  v_Ems_Io_Ec_Fee_Reim_h.Source_Order_Url  := v_Source_Order_Url; --来源单据URL
  v_Ems_Io_Ec_Fee_Reim_h.Conn_Trans_Id     := Null; --推广物料没有关联交易ID
  v_Ems_Io_Ec_Fee_Reim_h.Sensitive_Info    := Null; --备注信息 by sushu 2017-02-10
  If 'SC' = v_Pmt_Account_Head.Order_Type Then
    v_Ems_Io_Ec_Fee_Reim_h.Source_Order_Type := '20'; --来源单据类型 00运费01保险费02中转装卸费03下线装卸费04出入库装卸费05仓储费 20市场费用
  Else
    v_Ems_Io_Ec_Fee_Reim_h.Source_Order_Type := '10'; --来源单据类型 00运费01保险费02中转装卸费03下线装卸费04出入库装卸费05仓储费 10推广物料采购结算费
  End If;
  
  v_Ems_Io_Ec_Fee_Reim_h.Attribute11 := v_Pmt_Account_Head.Is_Transfer_Amount;
  v_Ems_Io_Ec_Fee_Reim_h.Entity_Id := v_Pmt_Account_Head.Entity_Id;
  v_Ems_Io_Ec_Fee_Reim_h.Customer_Id := v_Pmt_Account_Head.Customer_Id;
  v_Ems_Io_Ec_Fee_Reim_h.Account_Id := v_Pmt_Account_Head.Account_Id;
  V_ZKK_AMOUNT := NULL;
  if v_Ems_Io_Ec_Fee_Reim_h.Attribute11 = 'Y' then
    V_ZKK_AMOUNT := v_Pmt_Account_Head.Account_Amount;
  end if;
  
  --获取收款方法 add by tangjz2  2019-09-03
  if v_Ems_Io_Ec_Fee_Reim_h.Attribute11 = 'Y' then
    --获取默认的收款方法名称
    Pkg_Bd.p_Get_Parameter_Value('PMT_ACCOUNT_RECEIPT_METHOD',
                                 v_Pmt_Account_Head.Entity_Id,
                                 Null,
                                 Null,
                                 V_RECEIPT_METHOD_NAME);  
  
    begin
       select a.receipt_method_id into v_Ems_Io_Ec_Fee_Reim_h.Receipt_Method_Id 
       from t_ar_receipt_methods a where a.receipt_method_name = V_RECEIPT_METHOD_NAME --'推广费用转到款' 
       and a.entity_id = v_Ems_Io_Ec_Fee_Reim_h.Entity_Id and a.is_effective = 'Y';
     Exception
       When Others Then
       o_Result     := '1111';
       o_Result_Msg := '当前主体' || v_Ems_Io_Ec_Fee_Reim_h.Entity_Id  || '未配置名称为【'|| V_RECEIPT_METHOD_NAME || '】的收款方法';
       Return;
    end; 
  end if;

  --根据系统参数PMT_ACCOUNT_EMS_REMARK判断备注信息是否写入接口表 by sushu 2017-03-02
  Begin
    v_Pmt_Account_Ems_Remark_Flag := Pkg_Bd.f_Get_Parameter_Value('PMT_ACCOUNT_EMS_REMARK',
                                                                  v_Pmt_Account_Head.Entity_Id);
    If (v_Pmt_Account_Ems_Remark_Flag = 'Y') Then
      v_Ems_Io_Ec_Fee_Reim_h.Sensitive_Info := v_Pmt_Account_Head.Remark;
    End If;
  Exception
    When Others Then
      o_Result     := '1111';
      o_Result_Msg := '获取系统参数PMT_ACCOUNT_EMS_REMARK的值失败';
      Return;
  End;

  If v_Pmt_Account_Head.Ec_Loan_Repay_Amount Is Null or v_Pmt_Account_Head.Ec_Loan_Repay_Amount = 0 Then
    If 0 = v_Pmt_Account_Head.Current_Pay_Amount Then
      --本次付款金额为0
      v_Ems_Io_Ec_Fee_Reim_h.Pay_Amount := 0; --本次付款金额
    End If;
    --add by tangjz2  2020-04-30 如果是逆向结算批，本次付款金额为0
    if v_Pmt_Account_Head.Is_Red = 'Y' then
      v_Ems_Io_Ec_Fee_Reim_h.Pay_Amount := 0;
    end if;
    Insert Into Ems_Io_Ec_Fee_Reim_h
      (Io_Fee_Reim_Id,
       Apply_Ldap_Code,
       Reim_Date,
       Company_Id,
       Currency_Code,
       Apply_Reim_Amount,
       Pay_Amount,
       Reason_Desc,
       Vendor_Site_Id,
       Receiver,
       Bank_Name,
       Bank_Account,
       Ubank_No,
       Payment_Method,
       Is_Offer,
       Province,
       City,
       Vendor_Id,
       Order_Type,
       Created_Ldap_Code,
       Creation_Date,
       Last_Updated_Ldap_Code,
       Last_Update_Date,
       Ou_Id,
       Pay_Type,
       Source_System,
       Source_Order_Type,
       Source_Order_Id,
       Source_Order_Code,
       Source_Order_Url,
       Conn_Trans_Id,
       Sensitive_Info
       ,Attribute11  --是否转到款
       ,Entity_Id  
       ,Customer_Id  
       ,Account_Id  
       ,Receipt_Method_Id  --收款方法ID（默认推广费用转到款）
       ,ZKK_AMOUNT
       ) --备注信息 by sushu 2017-02-10
    Values
      (v_Ems_Io_Ec_Fee_Reim_h.Io_Fee_Reim_Id,
       v_Ems_Io_Ec_Fee_Reim_h.Apply_Ldap_Code,
       v_Ems_Io_Ec_Fee_Reim_h.Reim_Date,
       v_Ems_Io_Ec_Fee_Reim_h.Company_Id,
       v_Ems_Io_Ec_Fee_Reim_h.Currency_Code,
       v_Ems_Io_Ec_Fee_Reim_h.Apply_Reim_Amount,
       v_Ems_Io_Ec_Fee_Reim_h.Pay_Amount,
       v_Ems_Io_Ec_Fee_Reim_h.Reason_Desc,
       v_Ems_Io_Ec_Fee_Reim_h.Vendor_Site_Id,
       v_Ems_Io_Ec_Fee_Reim_h.Receiver,
       v_Ems_Io_Ec_Fee_Reim_h.Bank_Name,
       v_Ems_Io_Ec_Fee_Reim_h.Bank_Account,
       v_Ems_Io_Ec_Fee_Reim_h.Ubank_No,
       v_Ems_Io_Ec_Fee_Reim_h.Payment_Method,
       v_Ems_Io_Ec_Fee_Reim_h.Is_Offer,
       v_Ems_Io_Ec_Fee_Reim_h.Province,
       v_Ems_Io_Ec_Fee_Reim_h.City,
       v_Ems_Io_Ec_Fee_Reim_h.Vendor_Id,
       v_Ems_Io_Ec_Fee_Reim_h.Order_Type,
       v_Ems_Io_Ec_Fee_Reim_h.Created_Ldap_Code,
       v_Ems_Io_Ec_Fee_Reim_h.Creation_Date,
       v_Ems_Io_Ec_Fee_Reim_h.Last_Updated_Ldap_Code,
       v_Ems_Io_Ec_Fee_Reim_h.Last_Update_Date,
       v_Ems_Io_Ec_Fee_Reim_h.Ou_Id,
       v_Ems_Io_Ec_Fee_Reim_h.Pay_Type,
       v_Ems_Io_Ec_Fee_Reim_h.Source_System,
       v_Ems_Io_Ec_Fee_Reim_h.Source_Order_Type,
       v_Ems_Io_Ec_Fee_Reim_h.Source_Order_Id,
       v_Ems_Io_Ec_Fee_Reim_h.Source_Order_Code,
       v_Ems_Io_Ec_Fee_Reim_h.Source_Order_Url,
       v_Ems_Io_Ec_Fee_Reim_h.Conn_Trans_Id,
       v_Ems_Io_Ec_Fee_Reim_h.Sensitive_Info
       ,v_Ems_Io_Ec_Fee_Reim_h.Attribute11
       ,v_Ems_Io_Ec_Fee_Reim_h.Entity_Id
       ,v_Ems_Io_Ec_Fee_Reim_h.Customer_Id
       ,v_Ems_Io_Ec_Fee_Reim_h.Account_Id
       ,v_Ems_Io_Ec_Fee_Reim_h.Receipt_Method_Id 
       ,V_ZKK_AMOUNT
       ); --备注信息 by sushu 2017-02-10
    /*ELSIF V_PMT_ACCOUNT_HEAD.EC_LOAN_REPAY_AMOUNT > V_EMS_IO_EC_FEE_REIM_H.PAY_AMOUNT THEN
    O_RESULT     := '1008';
    O_RESULT_MSG := '供应商省、市信息不存在！';
    RETURN;*/
  Else
    /*IF 0 = V_PMT_ACCOUNT_HEAD.CURRENT_PAY_AMOUNT THEN--本次付款金额为0
      V_EMS_IO_EC_FEE_REIM_H.PAY_AMOUNT           := 0; --本次付款金额
    END IF;*/
    --本次付款金额必须小于或等于报销金额-核销合计
    v_Ems_Io_Ec_Fee_Reim_h.Pay_Amount := v_Ems_Io_Ec_Fee_Reim_h.Pay_Amount -
                                         v_Pmt_Account_Head.Ec_Loan_Repay_Amount; --本次付款金额
    --add by tangjz2  2020-04-30 如果是逆向结算批，本次付款金额为0
    if v_Pmt_Account_Head.Is_Red = 'Y' then
      v_Ems_Io_Ec_Fee_Reim_h.Pay_Amount := 0;
    end if;
    Insert Into Ems_Io_Ec_Fee_Reim_h
      (Io_Fee_Reim_Id,
       Apply_Ldap_Code,
       Reim_Date,
       Company_Id,
       Currency_Code,
       Apply_Reim_Amount,
       Pay_Amount,
       Reason_Desc,
       Vendor_Site_Id,
       Receiver,
       Bank_Name,
       Bank_Account,
       Ubank_No,
       Payment_Method,
       Is_Offer,
       Province,
       City,
       Vendor_Id,
       Order_Type,
       Created_Ldap_Code,
       Creation_Date,
       Last_Updated_Ldap_Code,
       Last_Update_Date,
       Ou_Id,
       Pay_Type,
       Source_System,
       Source_Order_Type,
       Source_Order_Id,
       Source_Order_Code,
       Source_Order_Url,
       Conn_Trans_Id,
       Sensitive_Info
       ,Attribute11  --是否转到款
       ,Entity_Id  
       ,Customer_Id  
       ,Account_Id  
       ,Receipt_Method_Id  --收款方法ID（默认推广费用转到款）
       ,ZKK_AMOUNT
       ) --备注信息 by sushu 2017-02-10
    Values
      (v_Ems_Io_Ec_Fee_Reim_h.Io_Fee_Reim_Id,
       v_Ems_Io_Ec_Fee_Reim_h.Apply_Ldap_Code,
       v_Ems_Io_Ec_Fee_Reim_h.Reim_Date,
       v_Ems_Io_Ec_Fee_Reim_h.Company_Id,
       v_Ems_Io_Ec_Fee_Reim_h.Currency_Code,
       v_Ems_Io_Ec_Fee_Reim_h.Apply_Reim_Amount,
       v_Ems_Io_Ec_Fee_Reim_h.Pay_Amount,
       v_Ems_Io_Ec_Fee_Reim_h.Reason_Desc,
       v_Ems_Io_Ec_Fee_Reim_h.Vendor_Site_Id,
       v_Ems_Io_Ec_Fee_Reim_h.Receiver,
       v_Ems_Io_Ec_Fee_Reim_h.Bank_Name,
       v_Ems_Io_Ec_Fee_Reim_h.Bank_Account,
       v_Ems_Io_Ec_Fee_Reim_h.Ubank_No,
       v_Ems_Io_Ec_Fee_Reim_h.Payment_Method,
       v_Ems_Io_Ec_Fee_Reim_h.Is_Offer,
       v_Ems_Io_Ec_Fee_Reim_h.Province,
       v_Ems_Io_Ec_Fee_Reim_h.City,
       v_Ems_Io_Ec_Fee_Reim_h.Vendor_Id,
       v_Ems_Io_Ec_Fee_Reim_h.Order_Type,
       v_Ems_Io_Ec_Fee_Reim_h.Created_Ldap_Code,
       v_Ems_Io_Ec_Fee_Reim_h.Creation_Date,
       v_Ems_Io_Ec_Fee_Reim_h.Last_Updated_Ldap_Code,
       v_Ems_Io_Ec_Fee_Reim_h.Last_Update_Date,
       v_Ems_Io_Ec_Fee_Reim_h.Ou_Id,
       v_Ems_Io_Ec_Fee_Reim_h.Pay_Type,
       v_Ems_Io_Ec_Fee_Reim_h.Source_System,
       v_Ems_Io_Ec_Fee_Reim_h.Source_Order_Type,
       v_Ems_Io_Ec_Fee_Reim_h.Source_Order_Id,
       v_Ems_Io_Ec_Fee_Reim_h.Source_Order_Code,
       v_Ems_Io_Ec_Fee_Reim_h.Source_Order_Url,
       v_Ems_Io_Ec_Fee_Reim_h.Conn_Trans_Id,
       v_Ems_Io_Ec_Fee_Reim_h.Sensitive_Info
       ,v_Ems_Io_Ec_Fee_Reim_h.Attribute11
       ,v_Ems_Io_Ec_Fee_Reim_h.Entity_Id
       ,v_Ems_Io_Ec_Fee_Reim_h.Customer_Id
       ,v_Ems_Io_Ec_Fee_Reim_h.Account_Id
       ,v_Ems_Io_Ec_Fee_Reim_h.Receipt_Method_Id 
       ,V_ZKK_AMOUNT
       ); --备注信息 by sushu 2017-02-10
  
    --v_Ems_Io_Ec_Fee_Loan.Io_Fee_Loan_Id := Ems_Io_Ec_Fee_Loan_s.Nextval; --
    v_Ems_Io_Ec_Fee_Loan.Io_Fee_Reim_Id := v_Fee_Budget_Seq; --头主键ID
  
    Select Max(Ce.Code_Value)
      Into Vt_Ems_Loan_Ss_Cv
      From Up_Codelist c, Up_Codelist_Entity Ce
     Where Ce.Codelist_Id = c.Id
       And Ce.Entity_Id = v_Pmt_Account_Head.Entity_Id
       And Nvl(Ce.Enabled, '0') = '0'
       And c.Codetype = 'pmt_ems_io_ec_loan_source'
       And c.Entity_Flag = 'Y'
       And c.Enabled = '0'
       And Ce.Enabled = '0';
    If Vt_Ems_Loan_Ss_Cv Is Null Then
      v_Ems_Io_Ec_Fee_Loan.Source_System     := 'CIMS'; --来源系统
      v_Ems_Io_Ec_Fee_Loan.Source_Order_Type := 'PAYMENT'; --来源单据类型 跟头上一致
    Else
      v_Ems_Io_Ec_Fee_Loan.Source_System     := Substr(Vt_Ems_Loan_Ss_Cv,
                                                       1,
                                                       Instr(Vt_Ems_Loan_Ss_Cv,
                                                             ',') - 1);
      v_Ems_Io_Ec_Fee_Loan.Source_Order_Type := Substr(Vt_Ems_Loan_Ss_Cv,
                                                       1 + Instr(Vt_Ems_Loan_Ss_Cv,
                                                                 ','));
    End If;
    v_Ems_Io_Ec_Fee_Loan.Source_Order_Id        := v_Pmt_Account_Head.Account_Head_Id; --来源单据ID
    v_Ems_Io_Ec_Fee_Loan.Source_Order_Code      := v_Pmt_Account_Head.Account_Num; --来源单据编码
    v_Ems_Io_Ec_Fee_Loan.Created_Ldap_Code      := i_Account; --创建人LDAP编码
    v_Ems_Io_Ec_Fee_Loan.Creation_Date          := v_Sysdate; --创建日期
    v_Ems_Io_Ec_Fee_Loan.Last_Updated_Ldap_Code := i_Account; --最后更新人LDAP编码
    v_Ems_Io_Ec_Fee_Loan.Last_Update_Date       := v_Sysdate; --最后更新日期
    
    --add by tangjz2  2019-07-24 预付款单修改为多条
    FOR LOAN_INFOS IN (SELECT * FROM T_PMT_ACCOUNT_LOAN_INFO A WHERE A.ACCOUNT_HEAD_ID = I_ACCOUNT_HEAD_ID) LOOP
      --预付款单ID
      v_Ems_Io_Ec_Fee_Loan.Loan_Info_Id := LOAN_INFOS.Ec_Loan_Info_Id;
      --预付款本次核销金额
      v_Ems_Io_Ec_Fee_Loan.Repay_Amount := LOAN_INFOS.Ec_Loan_Repay_Amount;
      v_Ems_Io_Ec_Fee_Loan.Io_Fee_Loan_Id := Ems_Io_Ec_Fee_Loan_s.Nextval;
          
      Insert Into Ems_Io_Ec_Fee_Loan
        (Io_Fee_Loan_Id,
         Io_Fee_Reim_Id,
         Source_System,
         Source_Order_Type,
         Source_Order_Id,
         Source_Order_Code,
         Created_Ldap_Code,
         Creation_Date,
         Last_Updated_Ldap_Code,
         Last_Update_Date,
         Loan_Info_Id,
         Repay_Amount)
      Values
        (v_Ems_Io_Ec_Fee_Loan.Io_Fee_Loan_Id,
         v_Ems_Io_Ec_Fee_Loan.Io_Fee_Reim_Id,
         v_Ems_Io_Ec_Fee_Loan.Source_System,
         v_Ems_Io_Ec_Fee_Loan.Source_Order_Type,
         v_Ems_Io_Ec_Fee_Loan.Source_Order_Id,
         v_Ems_Io_Ec_Fee_Loan.Source_Order_Code,
         v_Ems_Io_Ec_Fee_Loan.Created_Ldap_Code,
         v_Ems_Io_Ec_Fee_Loan.Creation_Date,
         v_Ems_Io_Ec_Fee_Loan.Last_Updated_Ldap_Code,
         v_Ems_Io_Ec_Fee_Loan.Last_Update_Date,
         v_Ems_Io_Ec_Fee_Loan.Loan_Info_Id,
         v_Ems_Io_Ec_Fee_Loan.Repay_Amount);
    END LOOP;
   
  End If;
  
  --写入转到款明细   add by tangjz2   2019-09-03
  if v_Ems_Io_Ec_Fee_Reim_h.Attribute11 = 'Y' then
    insert into ems_io_ec_fee_zkk(
      EMS_IO_EC_FEE_ZKK_ID
      ,IO_FEE_REIM_ID
      ,SALES_MAIN_TYPE_ID
      ,SALES_MAIN_TYPE_NAME
      ,AMOUNT
    ) values (
      ems_io_ec_fee_zkk_s.nextval
      ,v_Ems_Io_Ec_Fee_Reim_h.Io_Fee_Reim_Id
      ,v_Pmt_Account_Head.Sales_Main_Type_Id
      ,v_Pmt_Account_Head.Sales_Main_Type_Name
      ,v_Pmt_Account_Head.Account_Amount
    );
  end if;
  
  --根据结算批ID查询附件并写入接口表ems_io_attach_file
  Select count(a.file_id) into v_Cnt from cims.MDP_BUSINESS_FILE a 
    join Intf_Upload_Fileinfo u on u.file_id = a.file_id
    where a.business_id = ('PMT'|| i_Account_Head_Id)  
    and a.file_id like 'pmtOrderAccountAdd%';
  if v_Cnt>0 then
    For files In (
    select a.*,u.file_all_url from cims.MDP_BUSINESS_FILE a 
    join Intf_Upload_Fileinfo u on u.file_id = a.file_id
    where a.business_id = ('PMT'|| i_Account_Head_Id)  
    and a.file_id like 'pmtOrderAccountAdd%')
    loop
    v_ems_io_attach_file_Seq                  := ems_io_attach_file_s.Nextval; --获取对应的序列
    v_ems_io_attach_file.IO_ATTACH_FILE_ID    := v_ems_io_attach_file_Seq;--主键ID
    v_ems_io_attach_file.IO_ORDER_ID          := v_Ems_Io_Ec_Fee_Reim_h.Io_Fee_Reim_Id;--IOEC头表正式表ID
    v_ems_io_attach_file.ORDER_TYPE           := 'EC_FEE_REIM_H';--正式表单据类型
    v_ems_io_attach_file.FILE_PATH            := files.file_all_url;--文件路径（换成美云路径）
    v_ems_io_attach_file.DISPLAY_NAME         := files.file_name || '.' || files.file_type;--显示名称
    v_ems_io_attach_file.SAVED_NAME           := files.file_name;--保存文件名
    v_ems_io_attach_file.FILE_SIZE	          := files.file_size;--文件大小
    v_ems_io_attach_file.FILE_TYPE            := files.file_type;--文件类型
    v_ems_io_attach_file.CREATED_LDAP_CODE    := i_Account;
    v_ems_io_attach_file.CREATION_DATE        := v_Sysdate;--创建时间
    v_ems_io_attach_file.URL_TYPE             := 'HTTP_FULL_URL';
    v_ems_io_attach_file.SOURCE_SYSTEM        := 'CIMS';--附件来源系统
    v_ems_io_attach_file.SOURCE_ORDER_ID      := v_Pmt_Account_Head.Account_Head_Id; --来源单据ID
    v_ems_io_attach_file.SOURCE_ORDER_CODE    := v_Pmt_Account_Head.Account_Num; --来源单据编码
    v_ems_io_attach_file.SOURCE_ORDER_LINE_ID := v_Pmt_Account_Head.Account_Head_Id; --来源单据行ID(与头ID一致)
    
    If 'SC' = v_Pmt_Account_Head.Order_Type Then
       v_ems_io_attach_file.SOURCE_ORDER_TYPE := '20'; --来源单据类型 跟头上一致
    Else
       v_ems_io_attach_file.SOURCE_ORDER_TYPE := '10'; --来源单据类型 跟头上一致
    End If;
    
    Insert Into ems_io_attach_file
      (IO_ATTACH_FILE_ID,
       IO_ORDER_ID,
       ORDER_TYPE,
       FILE_PATH,
       DISPLAY_NAME,
       SAVED_NAME,
       FILE_SIZE,
       FILE_TYPE,
       CREATED_LDAP_CODE,
       CREATION_DATE,
       URL_TYPE,
       SOURCE_SYSTEM,
       SOURCE_ORDER_TYPE,
       SOURCE_ORDER_ID,
       SOURCE_ORDER_CODE,
       SOURCE_ORDER_LINE_ID)
    Values
      (v_ems_io_attach_file.IO_ATTACH_FILE_ID,
       v_ems_io_attach_file.IO_ORDER_ID,
       v_ems_io_attach_file.ORDER_TYPE,
       v_ems_io_attach_file.FILE_PATH,
       v_ems_io_attach_file.DISPLAY_NAME,
       v_ems_io_attach_file.SAVED_NAME,
       v_ems_io_attach_file.FILE_SIZE,
       v_ems_io_attach_file.FILE_TYPE,
       v_ems_io_attach_file.CREATED_LDAP_CODE,
       v_ems_io_attach_file.CREATION_DATE,
       v_ems_io_attach_file.URL_TYPE,
       v_ems_io_attach_file.SOURCE_SYSTEM,
       v_ems_io_attach_file.SOURCE_ORDER_TYPE,
       v_ems_io_attach_file.SOURCE_ORDER_ID,
       v_ems_io_attach_file.SOURCE_ORDER_CODE,
       v_ems_io_attach_file.SOURCE_ORDER_LINE_ID
       );   
       End Loop;
  end if;    
  --费用类型
  /*
   select fee_type_id
     INTO V_EMS_IO_EC_FEE_BUDGET.FEE_TYPE_ID
     from EMS_CIMS_FEE_TYPE_V
    where is_tax = 'Y'
      and fee_type_code = 'TAX001';
  */

  --ADD BY LIANGYM2 2017 6-5 PO匹配行预算单元ID从系统参数PMT_ACCOUNT_PO_BUDGET_NODE_ID、PMT_ACCOUNT_IPV_BUDGET_NODE_ID获取
  --IF 'NC' = VV_PUB_FIN_SYS THEN

  If 'TG' = v_Pmt_Account_Head.Order_Type Then
    If v_Pmt_Account_Head.Order_Num Is Not Null Then
      Select (Select Oh.Sales_Center_Id
                From t_Pmt_Order_Header Oh
               Where Oh.Entity_Id = v_Pmt_Account_Head.Entity_Id
                 And Oh.Order_Num = v_Pmt_Account_Head.Order_Num)
        Into Vt_Sales_Center_Id
        From Dual;
    else 
      begin 
        select a.unit_id into Vt_Sales_Center_Id from up_org_unit a where a.code = v_Pmt_Account_Head.Account_Unit_Code and a.entity_id = v_Pmt_Account_Head.Entity_Id;
        exception 
          when no_data_found then
          Vt_Sales_Center_Id := null;
      end;
    End If;
  
    --获取PO匹配行预算单元ID
    Begin
      Pkg_Bd.p_Get_Parameter_Value('PMT_ACCOUNT_PO_BUDGET_NODE_ID',
                                   v_Pmt_Account_Head.Entity_Id,
                                   Vt_Sales_Center_Id,
                                   Null,
                                   Vt_Budget_Node_Id2);
    Exception
      When Others Then
        Null; --默认值
    End;
  
    --获取IPV行预算单元ID，如果异常、或者为空时VT_BUDGET_NODE_ID2不为空，取VT_BUDGET_NODE_ID2
    Begin
      Pkg_Bd.p_Get_Parameter_Value('PMT_ACCOUNT_IPV_BUDGET_NODE_ID',
                                   v_Pmt_Account_Head.Entity_Id,
                                   Vt_Sales_Center_Id,
                                   Null,
                                   Vt_Budget_Node_Id1);
      If Vt_Budget_Node_Id1 Is Null And Vt_Budget_Node_Id2 Is Not Null Then
        Vt_Budget_Node_Id1 := Vt_Budget_Node_Id2;
      End If;
    Exception
      When Others Then
        Vt_Budget_Node_Id1 := Vt_Budget_Node_Id2; --默认值
    End;
    /*ELSIF 'SC' = V_PMT_ACCOUNT_HEAD.ORDER_TYPE AND V_PMT_ACCOUNT_HEAD.ORDER_NUM IS NOT NULL THEN
     --获取PO匹配行预算单元ID
     SELECT LJ.SALES_CENTER_ID,LJ.BUDGET_NODE_ID INTO VT_SALES_CENTER_ID,VT_BUDGET_NODE_ID2
     FROM DUAL LEFT JOIN (SELECT OH.SALES_CENTER_ID,OH.BUDGET_NODE_ID
     FROM T_PMT_QUOTATION_HEAD OH WHERE OH.ENTITY_ID = V_PMT_ACCOUNT_HEAD.ENTITY_ID
     AND OH.QUOTATION_NO = V_PMT_ACCOUNT_HEAD.ORDER_NUM AND 1 = ROWNUM) LJ ON (LJ.SALES_CENTER_ID > 0)
     ;
    
    --获取IPV行预算单元ID
    VT_BUDGET_NODE_ID1 := VT_BUDGET_NODE_ID2;*/
  End If;

  --END IF;

  --遍历费用行对应的PO信息 用头ID查询
  For c_Pmt_Account_Line In (Select *
                               From t_Pmt_Account_Line t
                              Where t.Account_Head_Id =
                                    v_Pmt_Account_Head.Account_Head_Id
                                And t.Total_Amount <> 0) Loop
  
    v_Fee_Budgetio_Seq                            := Ems_Io_Ec_Fee_Budget_s.Nextval; --获取费用对应的序列
    v_Ems_Io_Ec_Fee_Budget.Io_Fee_Budget_Id       := v_Fee_Budgetio_Seq; --行主键ID
    v_Ems_Io_Ec_Fee_Budget.Io_Fee_Reim_Id         := v_Fee_Budget_Seq; --头主键ID
    v_Ems_Io_Ec_Fee_Budget.Apply_Reim_Amount      := c_Pmt_Account_Line.Total_Amount; --申请报销金额(不含税费用总额)
    v_Ems_Io_Ec_Fee_Budget.Currency_Code          := 'CNY'; --币种
    v_Ems_Io_Ec_Fee_Budget.Conversion_Rate        := 1; --汇率
    v_Ems_Io_Ec_Fee_Budget.Reason_Desc            := '费用支付'; --事由
    v_Ems_Io_Ec_Fee_Budget.Fee_Happend_Date       := v_Sysdate; --费用发生日期
    v_Ems_Io_Ec_Fee_Budget.Recorded_Company_Id    := v_Ems_Io_Ec_Fee_Reim_h.Company_Id; --入账单位(与头公司ID一致)
    v_Ems_Io_Ec_Fee_Budget.Imp_Erp_Type           := 'AP'; --导ERP类型
    v_Ems_Io_Ec_Fee_Budget.Created_Ldap_Code      := i_Account; --创建人LDAPCODE
    v_Ems_Io_Ec_Fee_Budget.Creation_Date          := v_Sysdate; --创建日期
    v_Ems_Io_Ec_Fee_Budget.Last_Updated_Ldap_Code := i_Account; --最后更新人LDAP编码
    v_Ems_Io_Ec_Fee_Budget.Last_Update_Date       := v_Sysdate; --最后更新日期
    v_Ems_Io_Ec_Fee_Budget.Source_System          := 'CIMS'; --来源系统
    --
    v_Ems_Io_Ec_Fee_Budget.Source_Order_Id      := v_Pmt_Account_Head.Account_Head_Id; --来源单据ID
    v_Ems_Io_Ec_Fee_Budget.Source_Order_Code    := v_Pmt_Account_Head.Account_Num; --来源单据编码
    v_Ems_Io_Ec_Fee_Budget.Source_Order_Line_Id := v_Pmt_Account_Head.Account_Head_Id; --来源单据行ID(与头ID一致)
    If 'SC'<> v_Pmt_Account_Head.Order_Type Then --市场物料类型的，Ems_Io_Ec_Fee_Budget的预算行ATTRIBUTE14字段，留空 lilh6 18-7-25
      v_Ems_Io_Ec_Fee_Budget.Attribute14          := 'PO_MATCH'; --PO匹配行
    Else
      v_Ems_Io_Ec_Fee_Budget.Attribute14          := Null; --PO匹配行
    End If;
    v_Ems_Io_Ec_Fee_Budget.Budget_Node_Id       := Vt_Budget_Node_Id2; --预算单元ID add by liangym2 2017-6-5
    v_Ems_Io_Ec_Fee_Budget.Fee_Apply_Id         := Null;
    v_Ems_Io_Ec_Fee_Budget.Fee_Apply_l_Id       := Null;
    /*
    ORDER_STATUS  SUBMITED
    ORDER_TYPE  TY
    BIZ_STATUS  UNAPPROVED
    */
    If 'SC' = v_Pmt_Account_Head.Order_Type Then
      v_Ems_Io_Ec_Fee_Budget.Source_Order_Type := '20'; --来源单据类型 跟头上一致
      Begin
        Select Budget_Node_Id, Fee_Apply_Id, Fee_Apply_l_Id
          Into v_Ems_Io_Ec_Fee_Budget.Budget_Node_Id,
               v_Ems_Io_Ec_Fee_Budget.Fee_Apply_Id,
               v_Ems_Io_Ec_Fee_Budget.Fee_Apply_l_Id
          From (Select Budget_Node_Id,
                       Fee_Apply_Id,
                       Fee_Apply_l_Id,
                       Rank() Over(Order By Fee_Apply_Id Desc) As Rn
                  From Ems_Cims_Ea_Apply_l_v
                 Where Source_System = 'CIMS'
                   And Source_Order_Type = 'SCBJ'
                   And Source_Order_Id = to_char(c_Pmt_Account_Line.Order_Head_Id)
                   And Source_Order_Line_Id = to_char(c_Pmt_Account_Line.Inv_Detail))
         Where 1 = Rn;
      Exception
        When No_Data_Found Then
          o_Result     := '1001';
          o_Result_Msg := '报价单:' || c_Pmt_Account_Line.Po_Num || '，物料编码：' ||
                          c_Pmt_Account_Line.Pmt_Code || '(对应报价单行ID：' ||
                          c_Pmt_Account_Line.Inv_Detail ||
                          ')，在EMS的EA单行表找不到记录';
          Return;
        When Too_Many_Rows Then
          o_Result     := '1001';
          o_Result_Msg := '报价单:' || c_Pmt_Account_Line.Po_Num || '，物料编码：' ||
                          c_Pmt_Account_Line.Pmt_Code || '(对应报价单行ID：' ||
                          c_Pmt_Account_Line.Inv_Detail ||
                          ')，在EMS的EA单行表找不到多行记录';
          Return;
      End;
    Else
      v_Ems_Io_Ec_Fee_Budget.Source_Order_Type := '10'; --来源单据类型 跟头上一致
    End If;
  
    Insert Into Ems_Io_Ec_Fee_Budget
      (Io_Fee_Budget_Id,
       Io_Fee_Reim_Id,
       Apply_Reim_Amount,
       Currency_Code,
       Conversion_Rate,
       Reason_Desc,
       Fee_Happend_Date,
       Recorded_Company_Id,
       Imp_Erp_Type,
       Created_Ldap_Code,
       Creation_Date,
       Last_Updated_Ldap_Code,
       Last_Update_Date,
       Source_System,
       Source_Order_Type,
       Source_Order_Id,
       Source_Order_Code,
       Source_Order_Line_Id,
       Attribute14,
       Budget_Node_Id --预算单元ID add by liangym2 2017-6-5
      ,
       Fee_Apply_Id,
       Fee_Apply_l_Id)
    Values
      (v_Ems_Io_Ec_Fee_Budget.Io_Fee_Budget_Id,
       v_Ems_Io_Ec_Fee_Budget.Io_Fee_Reim_Id,
       v_Ems_Io_Ec_Fee_Budget.Apply_Reim_Amount,
       v_Ems_Io_Ec_Fee_Budget.Currency_Code,
       v_Ems_Io_Ec_Fee_Budget.Conversion_Rate,
       v_Ems_Io_Ec_Fee_Budget.Reason_Desc,
       v_Ems_Io_Ec_Fee_Budget.Fee_Happend_Date,
       v_Ems_Io_Ec_Fee_Budget.Recorded_Company_Id,
       v_Ems_Io_Ec_Fee_Budget.Imp_Erp_Type,
       v_Ems_Io_Ec_Fee_Budget.Created_Ldap_Code,
       v_Ems_Io_Ec_Fee_Budget.Creation_Date,
       v_Ems_Io_Ec_Fee_Budget.Last_Updated_Ldap_Code,
       v_Ems_Io_Ec_Fee_Budget.Last_Update_Date,
       v_Ems_Io_Ec_Fee_Budget.Source_System,
       v_Ems_Io_Ec_Fee_Budget.Source_Order_Type,
       v_Ems_Io_Ec_Fee_Budget.Source_Order_Id,
       v_Ems_Io_Ec_Fee_Budget.Source_Order_Code,
       v_Ems_Io_Ec_Fee_Budget.Source_Order_Line_Id,
       v_Ems_Io_Ec_Fee_Budget.Attribute14,
       v_Ems_Io_Ec_Fee_Budget.Budget_Node_Id --预算单元ID add by liangym2 2017-6-5
      ,
       v_Ems_Io_Ec_Fee_Budget.Fee_Apply_Id,
       v_Ems_Io_Ec_Fee_Budget.Fee_Apply_l_Id);
  
    --构建EMS报销接口行PO匹配明细
    --市场物料的不写Ems_Io_Ec_Fee_Budget_Po表 lilh6 18-7-25
    If v_Pmt_Account_Head.Order_Type <> 'SC' Then
      v_Ems_Io_Ec_Fee_Budget_Po.Io_Fee_Budget_Id := v_Fee_Budgetio_Seq; --行id
      v_Ems_Io_Ec_Fee_Budget_Po.Io_Fee_Reim_Id   := v_Fee_Budget_Seq; --头id
      v_Ems_Io_Ec_Fee_Budget_Po.Budget_Po_Id     := Ems_Io_Ec_Fee_Budget_Po_s.Nextval; --匹配明细id
      v_Ems_Io_Ec_Fee_Budget_Po.Po_Header_No     := c_Pmt_Account_Line.Po_Header_Num; --PO头
      v_Ems_Io_Ec_Fee_Budget_Po.Po_Line_No       := c_Pmt_Account_Line.Po_Lines_Num; --PO行
      v_Ems_Io_Ec_Fee_Budget_Po.Receive_No       := c_Pmt_Account_Line.Po_Received_Header_Num; --PO接收头
      v_Ems_Io_Ec_Fee_Budget_Po.Receive_Line_No  := c_Pmt_Account_Line.Po_Received_Lines_Num; --PO接收行
      v_Ems_Io_Ec_Fee_Budget_Po.Item_Code        := c_Pmt_Account_Line.Pmt_Code; --物料编码
      If 'SC' = v_Pmt_Account_Head.Order_Type or  'PO' = v_Pmt_Account_Head.Order_Type Then
        v_Ems_Io_Ec_Fee_Budget_Po.Amount := c_Pmt_Account_Line.Qty; --开票数量
      Else
        v_Ems_Io_Ec_Fee_Budget_Po.Amount := c_Pmt_Account_Line.Storaged_Qty; --开票数量
      End If;
      v_Ems_Io_Ec_Fee_Budget_Po.Price := c_Pmt_Account_Line.Price; --价格
    
      Insert Into Ems_Io_Ec_Fee_Budget_Po
        (Io_Fee_Budget_Id,
         Io_Fee_Reim_Id,
         Budget_Po_Id,
         Po_Header_No,
         Po_Line_No,
         Receive_No,
         Receive_Line_No,
         Item_Code,
         Amount,
         Price)
      Values
        (v_Ems_Io_Ec_Fee_Budget_Po.Io_Fee_Budget_Id,
         v_Ems_Io_Ec_Fee_Budget_Po.Io_Fee_Reim_Id,
         v_Ems_Io_Ec_Fee_Budget_Po.Budget_Po_Id,
         v_Ems_Io_Ec_Fee_Budget_Po.Po_Header_No,
         v_Ems_Io_Ec_Fee_Budget_Po.Po_Line_No,
         v_Ems_Io_Ec_Fee_Budget_Po.Receive_No,
         v_Ems_Io_Ec_Fee_Budget_Po.Receive_Line_No,
         v_Ems_Io_Ec_Fee_Budget_Po.Item_Code,
         v_Ems_Io_Ec_Fee_Budget_Po.Amount,
         v_Ems_Io_Ec_Fee_Budget_Po.Price);
    End If;
  End Loop;

  --遍历费用行对应的价差信息 用头ID查询
  For c_Pmt_Account_Head In (Select *
                               From t_Pmt_Account_Head t
                              Where t.Account_Head_Id =
                                    v_Pmt_Account_Head.Account_Head_Id
                                And 0 <> (Nvl(t.Difference_Amount, 0) +
                                    Nvl(t.Deductions_Amount, 0)
                                    --2016-09-23成本差异为0不插入EMS
                                    )) Loop
  
    v_Fee_Budgetio_Seq                            := Ems_Io_Ec_Fee_Budget_s.Nextval; --获取费用对应的序列
    v_Ems_Io_Ec_Fee_Budget.Io_Fee_Budget_Id       := v_Fee_Budgetio_Seq; --行主键ID
    v_Ems_Io_Ec_Fee_Budget.Io_Fee_Reim_Id         := v_Fee_Budget_Seq; --头主键ID
    v_Ems_Io_Ec_Fee_Budget.Apply_Reim_Amount      := c_Pmt_Account_Head.Difference_Amount +
                                                     Nvl(c_Pmt_Account_Head.Deductions_Amount,
                                                         0); --价差金额 2016-3-9修改 将税额差异与扣款金额合计一起引入EMS
    v_Ems_Io_Ec_Fee_Budget.Currency_Code          := 'CNY'; --币种
    v_Ems_Io_Ec_Fee_Budget.Conversion_Rate        := 1; --汇率
    v_Ems_Io_Ec_Fee_Budget.Reason_Desc            := '费用支付'; --事由
    v_Ems_Io_Ec_Fee_Budget.Fee_Happend_Date       := v_Sysdate; --费用发生日期
    v_Ems_Io_Ec_Fee_Budget.Recorded_Company_Id    := v_Ems_Io_Ec_Fee_Reim_h.Company_Id; --入账单位(与头公司ID一致)
    v_Ems_Io_Ec_Fee_Budget.Imp_Erp_Type           := 'AP'; --导ERP类型
    v_Ems_Io_Ec_Fee_Budget.Created_Ldap_Code      := i_Account; --创建人LDAPCODE
    v_Ems_Io_Ec_Fee_Budget.Creation_Date          := v_Sysdate; --创建日期
    v_Ems_Io_Ec_Fee_Budget.Last_Updated_Ldap_Code := i_Account; --最后更新人LDAP编码
    v_Ems_Io_Ec_Fee_Budget.Last_Update_Date       := v_Sysdate; --最后更新日期
    v_Ems_Io_Ec_Fee_Budget.Source_System          := 'CIMS'; --来源系统
    --
    v_Ems_Io_Ec_Fee_Budget.Source_Order_Id      := v_Pmt_Account_Head.Account_Head_Id; --来源单据ID
    v_Ems_Io_Ec_Fee_Budget.Source_Order_Code    := v_Pmt_Account_Head.Account_Num; --来源单据编码
    v_Ems_Io_Ec_Fee_Budget.Source_Order_Line_Id := v_Pmt_Account_Head.Account_Head_Id; --来源单据行ID(与头ID一致)
    If 'SC'<> v_Pmt_Account_Head.Order_Type Then --市场物料类型的，Ems_Io_Ec_Fee_Budget的预算行ATTRIBUTE14字段，留空 lilh6 18-7-25
      v_Ems_Io_Ec_Fee_Budget.Attribute14          := 'IPV'; --发票价差行
    Else
      v_Ems_Io_Ec_Fee_Budget.Attribute14          := Null; --发票价差行
    End If;
    
	-- v_Ems_Io_Ec_Fee_Budget.Budget_Node_Id       := Vt_Budget_Node_Id1; --预算单元ID add by liangym2 2017-6-5
	
    If 'SC'<> v_Pmt_Account_Head.Order_Type Then -- 张开安 2018-08-27 
       v_Ems_Io_Ec_Fee_Budget.Budget_Node_Id       := Vt_Budget_Node_Id1;
    Else
       select budget_node_id
         into v_Ems_Io_Ec_Fee_Budget.Budget_Node_Id
         from Ems_Io_Ec_Fee_Budget
        where Io_Fee_Reim_Id = v_Ems_Io_Ec_Fee_Budget.Io_Fee_Reim_Id
          and rownum = 1
          and budget_node_id is not null;
    End If;    

    v_Ems_Io_Ec_Fee_Budget.Fee_Apply_Id         := Null;
    v_Ems_Io_Ec_Fee_Budget.Fee_Apply_l_Id       := Null;
    If 'SC' = v_Pmt_Account_Head.Order_Type Then
      v_Ems_Io_Ec_Fee_Budget.Source_Order_Type := '20'; --来源单据类型 跟头上一致
    Else
      v_Ems_Io_Ec_Fee_Budget.Source_Order_Type := '10'; --来源单据类型 跟头上一致
    End If;
  
    Insert Into Ems_Io_Ec_Fee_Budget
      (Io_Fee_Budget_Id,
       Io_Fee_Reim_Id,
       Apply_Reim_Amount,
       Currency_Code,
       Conversion_Rate,
       Reason_Desc,
       Fee_Happend_Date,
       Recorded_Company_Id,
       Imp_Erp_Type,
       Created_Ldap_Code,
       Creation_Date,
       Last_Updated_Ldap_Code,
       Last_Update_Date,
       Source_System,
       Source_Order_Type,
       Source_Order_Id,
       Source_Order_Code,
       Source_Order_Line_Id,
       Attribute14,
       Budget_Node_Id --预算单元ID add by liangym2 2017-6-5
      ,
       Fee_Apply_Id,
       Fee_Apply_l_Id)
    Values
      (v_Ems_Io_Ec_Fee_Budget.Io_Fee_Budget_Id,
       v_Ems_Io_Ec_Fee_Budget.Io_Fee_Reim_Id,
       v_Ems_Io_Ec_Fee_Budget.Apply_Reim_Amount,
       v_Ems_Io_Ec_Fee_Budget.Currency_Code,
       v_Ems_Io_Ec_Fee_Budget.Conversion_Rate,
       v_Ems_Io_Ec_Fee_Budget.Reason_Desc,
       v_Ems_Io_Ec_Fee_Budget.Fee_Happend_Date,
       v_Ems_Io_Ec_Fee_Budget.Recorded_Company_Id,
       v_Ems_Io_Ec_Fee_Budget.Imp_Erp_Type,
       v_Ems_Io_Ec_Fee_Budget.Created_Ldap_Code,
       v_Ems_Io_Ec_Fee_Budget.Creation_Date,
       v_Ems_Io_Ec_Fee_Budget.Last_Updated_Ldap_Code,
       v_Ems_Io_Ec_Fee_Budget.Last_Update_Date,
       v_Ems_Io_Ec_Fee_Budget.Source_System,
       v_Ems_Io_Ec_Fee_Budget.Source_Order_Type,
       v_Ems_Io_Ec_Fee_Budget.Source_Order_Id,
       v_Ems_Io_Ec_Fee_Budget.Source_Order_Code,
       v_Ems_Io_Ec_Fee_Budget.Source_Order_Line_Id,
       v_Ems_Io_Ec_Fee_Budget.Attribute14,
       v_Ems_Io_Ec_Fee_Budget.Budget_Node_Id --预算单元ID add by liangym2 2017-6-5
      ,
       v_Ems_Io_Ec_Fee_Budget.Fee_Apply_Id,
       v_Ems_Io_Ec_Fee_Budget.Fee_Apply_l_Id);
  
  End Loop;

  --获取税行对应的费用类型 CODE值需要配置
  --2017-1-9 ADD BY LIANGYM 使用系统参数配置

  /*SELECT COUNT(0) INTO V_CNT FROM T_PMT_RECEIPT_INFO T
  WHERE T.ACCOUNT_NUM = V_PMT_ACCOUNT_HEAD.ACCOUNT_NUM;*/

  --IF 0 < V_CNT THEN

  Vt_Project_Type := v_Pmt_Account_Head.Project_Type;

  If Vt_Project_Type Is Null Then
    Select Cl_n.Code_Value
      Into Vt_Project_Type
      From v_Up_Codelist Cl_n
     Where Cl_n.Codetype = 'PMT_ACCOUNT_PROJECT_TYPE'
       And (Cl_n.Entity_Id Is Null Or
           Cl_n.Entity_Id = v_Pmt_Account_Head.Entity_Id)
       And (1 = Cl_n.Code_Order)
       And 0 = Cl_n.Enabled;
  End If;

  Select (Select (Case
                   When Cl.Code_Value <> Cl.Code_Name Then
                    Cl.Code_Name
                   Else
                    Cl.Code_Value
                 End)
            From v_Up_Codelist Cl
           Where Cl.Codetype = 'PMT_EMS_FEE_TYPE_CODE'
             And (Cl.Entity_Id Is Null Or
                 Cl.Entity_Id = v_Pmt_Account_Head.Entity_Id)
             And Cl.Filter = Vt_Project_Type
             And 0 = Cl.Enabled)
    Into Vt_Ems_Fee_Type_Code
    From Dual;

  Vv_Tax_Attribute1 := 'TAX';
  If Vt_Ems_Fee_Type_Code Is Null Then
    Vv_Tax_Attribute1 := Null;
    Begin
      Pkg_Bd.p_Get_Parameter_Value('PMT_EMS_FEE_TYPE_CODE',
                                   v_Pmt_Account_Head.Entity_Id,
                                   Null,
                                   Null,
                                   Vt_Ems_Fee_Type_Code);
    Exception
      When Others Then
        Vt_Ems_Fee_Type_Code := 'TS0010'; --默认值
    End;
  End If;

  --FEE_TYPE_ID 发票税额 FEE_TYPE_ID
  Begin
    Select Count(Decode(Is_Tax, 'Y', 0)), Fee_Type_Id
      Into v_Cnt, v_Ems_Io_Ec_Fee_Budget.Fee_Type_Id
      From Ems_Cims_Fee_Type_v t
     Where t.Fee_Type_Code = Vt_Ems_Fee_Type_Code 
     --and t.fee_type_tree_id > 0  生产不能加
     Group By Fee_Type_Id;
  Exception
    When No_Data_Found Then
      o_Result     := '1006';
      o_Result_Msg := 'EMS税票费用类型编码' || Vt_Ems_Fee_Type_Code || '不存在';
      Return;
    When Others Then
      o_Result     := '1006';
      o_Result_Msg := 'EMS税票费用类型编码' || Vt_Ems_Fee_Type_Code ||
                      '存在多条ID不同的记录';
      Return;
  End;
  If 0 = v_Cnt Then
    o_Result     := '1006';
    o_Result_Msg := 'EMS税票费用类型编码' || Vt_Ems_Fee_Type_Code || '已失效';
    Return;
  Elsif 1 < v_Cnt Then
    o_Result     := '1006';
    o_Result_Msg := 'EMS税票费用类型编码' || Vt_Ems_Fee_Type_Code || '存在多条有效的记录';
    Return;
  End If;

  --构建报销支付行表（税行）
  v_Fee_Budgetio_Seq                      := Ems_Io_Ec_Fee_Budget_s.Nextval; --获取费用对应的序列
  v_Ems_Io_Ec_Fee_Budget.Io_Fee_Budget_Id := v_Fee_Budgetio_Seq; --行主键ID
  v_Ems_Io_Ec_Fee_Budget.Io_Fee_Reim_Id   := v_Fee_Budget_Seq; --头主键ID
  v_Ems_Io_Ec_Fee_Budget.Budget_Node_Id   := Null; --预算单元ID 不需要填写

  v_Ems_Io_Ec_Fee_Budget.Apply_Reim_Amount := v_Pmt_Account_Head.Balance_Has_Rate -
                                              v_Pmt_Account_Head.Balance_No_Rate; --2016-3-9修改  票面金额实际已经去除了差异金额
  --  V_PMT_ACCOUNT_HEAD.DIFFERENCE_AMOUNT; --申请报销金额（税金） add by liyuanji 20150724
  v_Ems_Io_Ec_Fee_Budget.Currency_Code          := 'CNY'; --币种
  v_Ems_Io_Ec_Fee_Budget.Conversion_Rate        := 1; --汇率
  v_Ems_Io_Ec_Fee_Budget.Reason_Desc            := '税金'; --事由
  v_Ems_Io_Ec_Fee_Budget.Fee_Happend_Date       := v_Sysdate; --费用发生日期
  v_Ems_Io_Ec_Fee_Budget.Recorded_Company_Id    := v_Ems_Io_Ec_Fee_Reim_h.Company_Id; --入账单位(与头公司ID一致)
  v_Ems_Io_Ec_Fee_Budget.Imp_Erp_Type           := 'AP'; --导ERP类型
  v_Ems_Io_Ec_Fee_Budget.Created_Ldap_Code      := i_Account; --创建人LDAPCODE
  v_Ems_Io_Ec_Fee_Budget.Creation_Date          := v_Sysdate; --创建日期
  v_Ems_Io_Ec_Fee_Budget.Last_Updated_Ldap_Code := i_Account; --最后更新人LDAP编码
  v_Ems_Io_Ec_Fee_Budget.Last_Update_Date       := v_Sysdate; --最后更新日期
  v_Ems_Io_Ec_Fee_Budget.Source_System          := 'CIMS'; --来源系统
  --
  v_Ems_Io_Ec_Fee_Budget.Source_Order_Id      := v_Pmt_Account_Head.Account_Head_Id; --来源单据ID
  v_Ems_Io_Ec_Fee_Budget.Source_Order_Code    := v_Pmt_Account_Head.Account_Num; --来源单据编码
  v_Ems_Io_Ec_Fee_Budget.Source_Order_Line_Id := v_Pmt_Account_Head.Account_Head_Id; --来源单据行ID(与头ID一致/推广物料写的是行id)
  v_Ems_Io_Ec_Fee_Budget.Attribute14          := Null; --税行为空
  If 'SC' = v_Pmt_Account_Head.Order_Type Then
    v_Ems_Io_Ec_Fee_Budget.Source_Order_Type := '20'; --来源单据类型 跟头上一致
  Else
    v_Ems_Io_Ec_Fee_Budget.Source_Order_Type := '10'; --来源单据类型 跟头上一致
  End If;

  Insert Into Ems_Io_Ec_Fee_Budget
    (Io_Fee_Budget_Id,
     Io_Fee_Reim_Id,
     Budget_Node_Id,
     Fee_Type_Id,
     Apply_Reim_Amount,
     Currency_Code,
     Conversion_Rate,
     Reason_Desc,
     Fee_Happend_Date,
     Recorded_Company_Id,
     Imp_Erp_Type,
     Created_Ldap_Code,
     Creation_Date,
     Last_Updated_Ldap_Code,
     Last_Update_Date,
     Source_System,
     Source_Order_Type,
     Source_Order_Id,
     Source_Order_Code,
     Source_Order_Line_Id,
     Attribute14)
  Values
    (v_Ems_Io_Ec_Fee_Budget.Io_Fee_Budget_Id,
     v_Ems_Io_Ec_Fee_Budget.Io_Fee_Reim_Id,
     v_Ems_Io_Ec_Fee_Budget.Budget_Node_Id,
     v_Ems_Io_Ec_Fee_Budget.Fee_Type_Id,
     v_Ems_Io_Ec_Fee_Budget.Apply_Reim_Amount,
     v_Ems_Io_Ec_Fee_Budget.Currency_Code,
     v_Ems_Io_Ec_Fee_Budget.Conversion_Rate,
     v_Ems_Io_Ec_Fee_Budget.Reason_Desc,
     v_Ems_Io_Ec_Fee_Budget.Fee_Happend_Date,
     v_Ems_Io_Ec_Fee_Budget.Recorded_Company_Id,
     v_Ems_Io_Ec_Fee_Budget.Imp_Erp_Type,
     v_Ems_Io_Ec_Fee_Budget.Created_Ldap_Code,
     v_Ems_Io_Ec_Fee_Budget.Creation_Date,
     v_Ems_Io_Ec_Fee_Budget.Last_Updated_Ldap_Code,
     v_Ems_Io_Ec_Fee_Budget.Last_Update_Date,
     v_Ems_Io_Ec_Fee_Budget.Source_System,
     v_Ems_Io_Ec_Fee_Budget.Source_Order_Type,
     v_Ems_Io_Ec_Fee_Budget.Source_Order_Id,
     v_Ems_Io_Ec_Fee_Budget.Source_Order_Code,
     v_Ems_Io_Ec_Fee_Budget.Source_Order_Line_Id,
     v_Ems_Io_Ec_Fee_Budget.Attribute14);

  --遍历结算批对应的发票信息 用批号还是批ID查询
  For c_Pmt_Receipt In (Select *
                          From t_Pmt_Receipt_Info t
                         Where t.Account_Num =
                               v_Pmt_Account_Head.Account_Num) Loop
  
    --构建报销支付接口税明细
    v_Ems_Io_Ec_Fee_Tax.Io_Fee_Tax_Id    := Ems_Io_Ec_Fee_Tax_s.Nextval; --主键ID
    v_Ems_Io_Ec_Fee_Tax.Io_Fee_Budget_Id := v_Fee_Budgetio_Seq; --接口表预算来源行ID
  
    v_Ems_Io_Ec_Fee_Tax.Attribute1 := Vv_Tax_Attribute1;
  
    v_Ems_Io_Ec_Fee_Tax.Tax_Amount      := c_Pmt_Receipt.Tax_Amount; --税额 保留两位小数
    v_Ems_Io_Ec_Fee_Tax.Tax_Receipt_Num := c_Pmt_Receipt.Invoice_Num; --税票号
    v_Ems_Io_Ec_Fee_Tax.Invoice_Maker   := v_Pmt_Account_Head.Vendor_Name; --开票方
    v_Ems_Io_Ec_Fee_Tax.Invoice_Date    := c_Pmt_Receipt.Invoice_Date; --开票日期
  
    v_Ems_Io_Ec_Fee_Tax.Created_Ldap_Code      := i_Account; --创建人LDAPCODE
    v_Ems_Io_Ec_Fee_Tax.Creation_Date          := v_Sysdate; --创建日期
    v_Ems_Io_Ec_Fee_Tax.Last_Updated_Ldap_Code := i_Account; --最后更新人LDAP编码
    v_Ems_Io_Ec_Fee_Tax.Last_Update_Date       := v_Sysdate; --最后更新日期
    v_Ems_Io_Ec_Fee_Tax.Source_System          := 'CIMS'; --来源系统
    v_Ems_Io_Ec_Fee_Tax.Source_Order_Id        := v_Pmt_Account_Head.Account_Head_Id; --来源单据ID
    v_Ems_Io_Ec_Fee_Tax.Source_Order_Code      := v_Pmt_Account_Head.Account_Num; --来源单据编码
    v_Ems_Io_Ec_Fee_Tax.Source_Order_Line_Id   := c_Pmt_Receipt.Receipt_Match_Id; --来源单据行ID
  
    Insert Into Ems_Io_Ec_Fee_Tax
      (Io_Fee_Tax_Id,
       Io_Fee_Budget_Id,
       Tax_Amount,
       Tax_Receipt_Num,
       Created_Ldap_Code,
       Creation_Date,
       Last_Updated_Ldap_Code,
       Last_Update_Date,
       Source_System,
       Source_Order_Id,
       Source_Order_Code,
       Source_Order_Line_Id,
       Invoice_Maker,
       Invoice_Date,
       Attribute1)
    Values
      (v_Ems_Io_Ec_Fee_Tax.Io_Fee_Tax_Id,
       v_Ems_Io_Ec_Fee_Tax.Io_Fee_Budget_Id,
       v_Ems_Io_Ec_Fee_Tax.Tax_Amount,
       v_Ems_Io_Ec_Fee_Tax.Tax_Receipt_Num,
       v_Ems_Io_Ec_Fee_Tax.Created_Ldap_Code,
       v_Ems_Io_Ec_Fee_Tax.Creation_Date,
       v_Ems_Io_Ec_Fee_Tax.Last_Updated_Ldap_Code,
       v_Ems_Io_Ec_Fee_Tax.Last_Update_Date,
       v_Ems_Io_Ec_Fee_Tax.Source_System,
       v_Ems_Io_Ec_Fee_Tax.Source_Order_Id,
       v_Ems_Io_Ec_Fee_Tax.Source_Order_Code,
       v_Ems_Io_Ec_Fee_Tax.Source_Order_Line_Id,
       v_Ems_Io_Ec_Fee_Tax.Invoice_Maker,
       v_Ems_Io_Ec_Fee_Tax.Invoice_Date,
       v_Ems_Io_Ec_Fee_Tax.Attribute1);
  
  End Loop;

  --END IF;

  Vt_Tax_Payment_Amount := v_Pmt_Account_Head.Tax_Payment_Amount;
  If Vt_Tax_Payment_Amount Is Not Null And 0 < Vt_Tax_Payment_Amount Then
    Select Cl_n.Code_Value
      Into Vt_Payment_Project_Type
      From v_Up_Codelist Cl_n
     Where Cl_n.Codetype = 'PMT_ACCOUNT_PROJECT_TYPE'
       And (Cl_n.Entity_Id Is Null Or
           Cl_n.Entity_Id = v_Pmt_Account_Head.Entity_Id)
       And (-1 = Cl_n.Code_Order) -- AND 0 = CL_N.ENABLED
    ;
  
    Select Cl.Code_Value
      Into Vt_Payment_Fee_Type_Code
      From v_Up_Codelist Cl
     Where Cl.Codetype = 'PMT_EMS_FEE_TYPE_CODE'
       And (Cl.Entity_Id Is Null Or
           Cl.Entity_Id = v_Pmt_Account_Head.Entity_Id)
       And Cl.Filter = Vt_Payment_Project_Type
       And 0 = Cl.Enabled;
  
    --FEE_TYPE_ID 完税凭证 FEE_TYPE_ID
    Begin
      Select Count(Decode(Is_Tax, 'Y', 0)), Fee_Type_Id
        Into v_Cnt, v_Ems_Io_Ec_Fee_Budget.Fee_Type_Id
        From Ems_Cims_Fee_Type_v t
       Where t.Fee_Type_Code = Vt_Payment_Fee_Type_Code 
       --and t.fee_type_tree_id > 0  生产不能加
       Group By Fee_Type_Id;
    Exception
      When No_Data_Found Then
        o_Result     := '1006';
        o_Result_Msg := 'EMS税票费用类型编码' || Vt_Payment_Fee_Type_Code || '不存在';
        Return;
      When Others Then
        o_Result     := '1006';
        o_Result_Msg := 'EMS税票费用类型编码' || Vt_Payment_Fee_Type_Code ||
                        '存在多条ID不同的记录';
        Return;
    End;
    If 0 = v_Cnt Then
      o_Result     := '1006';
      o_Result_Msg := 'EMS税票费用类型编码' || Vt_Payment_Fee_Type_Code || '已失效';
      Return;
    Elsif 1 < v_Cnt Then
      o_Result     := '1006';
      o_Result_Msg := 'EMS税票费用类型编码' || Vt_Payment_Fee_Type_Code ||
                      '存在多条有效的记录';
      Return;
    End If;
  
    --构建报销支付行表（税行）
    v_Fee_Budgetio_Seq                      := Ems_Io_Ec_Fee_Budget_s.Nextval; --获取费用对应的序列
    v_Ems_Io_Ec_Fee_Budget.Io_Fee_Budget_Id := v_Fee_Budgetio_Seq; --行主键ID
    v_Ems_Io_Ec_Fee_Budget.Io_Fee_Reim_Id   := v_Fee_Budget_Seq; --头主键ID
    v_Ems_Io_Ec_Fee_Budget.Budget_Node_Id   := Null; --预算单元ID 不需要填写
  
    /*BEGIN
      SELECT NVL(SUM(PAYMENT_AMOUNT), 0)
        INTO VT_TAX_PAYMENT_AMOUNT
        FROM T_PMT_PAYMENT_INFO
       WHERE ACCOUNT_ID = V_PMT_ACCOUNT_HEAD.ACCOUNT_ID;
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;*/
    v_Ems_Io_Ec_Fee_Budget.Apply_Reim_Amount := Vt_Tax_Payment_Amount;
    --  V_PMT_ACCOUNT_HEAD.DIFFERENCE_AMOUNT; --申请报销金额（税金） add by liyuanji 20150724
    v_Ems_Io_Ec_Fee_Budget.Currency_Code          := 'CNY'; --币种
    v_Ems_Io_Ec_Fee_Budget.Conversion_Rate        := 1; --汇率
    v_Ems_Io_Ec_Fee_Budget.Reason_Desc            := '完税凭证'; --事由
    v_Ems_Io_Ec_Fee_Budget.Fee_Happend_Date       := v_Sysdate; --费用发生日期
    v_Ems_Io_Ec_Fee_Budget.Recorded_Company_Id    := v_Ems_Io_Ec_Fee_Reim_h.Company_Id; --入账单位(与头公司ID一致)
    v_Ems_Io_Ec_Fee_Budget.Imp_Erp_Type           := 'AP'; --导ERP类型
    v_Ems_Io_Ec_Fee_Budget.Created_Ldap_Code      := i_Account; --创建人LDAPCODE
    v_Ems_Io_Ec_Fee_Budget.Creation_Date          := v_Sysdate; --创建日期
    v_Ems_Io_Ec_Fee_Budget.Last_Updated_Ldap_Code := i_Account; --最后更新人LDAP编码
    v_Ems_Io_Ec_Fee_Budget.Last_Update_Date       := v_Sysdate; --最后更新日期
    v_Ems_Io_Ec_Fee_Budget.Source_System          := 'CIMS'; --来源系统
    --
    v_Ems_Io_Ec_Fee_Budget.Source_Order_Id      := v_Pmt_Account_Head.Account_Head_Id; --来源单据ID
    v_Ems_Io_Ec_Fee_Budget.Source_Order_Code    := v_Pmt_Account_Head.Account_Num; --来源单据编码
    v_Ems_Io_Ec_Fee_Budget.Source_Order_Line_Id := v_Pmt_Account_Head.Account_Head_Id; --来源单据行ID(与头ID一致/推广物料写的是行id)
    v_Ems_Io_Ec_Fee_Budget.Attribute14          := Null; --税行为空
    If 'SC' = v_Pmt_Account_Head.Order_Type Then
      v_Ems_Io_Ec_Fee_Budget.Source_Order_Type := '20'; --来源单据类型 跟头上一致
    Else
      v_Ems_Io_Ec_Fee_Budget.Source_Order_Type := '10'; --来源单据类型 跟头上一致
    End If;
  
    Insert Into Ems_Io_Ec_Fee_Budget
      (Io_Fee_Budget_Id,
       Io_Fee_Reim_Id,
       Budget_Node_Id,
       Fee_Type_Id,
       Apply_Reim_Amount,
       Currency_Code,
       Conversion_Rate,
       Reason_Desc,
       Fee_Happend_Date,
       Recorded_Company_Id,
       Imp_Erp_Type,
       Created_Ldap_Code,
       Creation_Date,
       Last_Updated_Ldap_Code,
       Last_Update_Date,
       Source_System,
       Source_Order_Type,
       Source_Order_Id,
       Source_Order_Code,
       Source_Order_Line_Id,
       Attribute14)
    Values
      (v_Ems_Io_Ec_Fee_Budget.Io_Fee_Budget_Id,
       v_Ems_Io_Ec_Fee_Budget.Io_Fee_Reim_Id,
       v_Ems_Io_Ec_Fee_Budget.Budget_Node_Id,
       v_Ems_Io_Ec_Fee_Budget.Fee_Type_Id,
       v_Ems_Io_Ec_Fee_Budget.Apply_Reim_Amount,
       v_Ems_Io_Ec_Fee_Budget.Currency_Code,
       v_Ems_Io_Ec_Fee_Budget.Conversion_Rate,
       v_Ems_Io_Ec_Fee_Budget.Reason_Desc,
       v_Ems_Io_Ec_Fee_Budget.Fee_Happend_Date,
       v_Ems_Io_Ec_Fee_Budget.Recorded_Company_Id,
       v_Ems_Io_Ec_Fee_Budget.Imp_Erp_Type,
       v_Ems_Io_Ec_Fee_Budget.Created_Ldap_Code,
       v_Ems_Io_Ec_Fee_Budget.Creation_Date,
       v_Ems_Io_Ec_Fee_Budget.Last_Updated_Ldap_Code,
       v_Ems_Io_Ec_Fee_Budget.Last_Update_Date,
       v_Ems_Io_Ec_Fee_Budget.Source_System,
       v_Ems_Io_Ec_Fee_Budget.Source_Order_Type,
       v_Ems_Io_Ec_Fee_Budget.Source_Order_Id,
       v_Ems_Io_Ec_Fee_Budget.Source_Order_Code,
       v_Ems_Io_Ec_Fee_Budget.Source_Order_Line_Id,
       v_Ems_Io_Ec_Fee_Budget.Attribute14);
  
    --遍历结算批对应的完税凭证信息
    For c_Pmt_Payment In (Select *
                            From t_Pmt_Payment_Info t
                           Where t.Account_Id =
                                 v_Pmt_Account_Head.Account_Head_Id) Loop
    
      --构建报销支付接口税明细
      v_Ems_Io_Ec_Fee_Tax.Io_Fee_Tax_Id    := Ems_Io_Ec_Fee_Tax_s.Nextval; --主键ID
      v_Ems_Io_Ec_Fee_Tax.Io_Fee_Budget_Id := v_Fee_Budgetio_Seq; --接口表预算来源行ID
      v_Ems_Io_Ec_Fee_Tax.Attribute1       := 'PAY';
    
      v_Ems_Io_Ec_Fee_Tax.Tax_Amount := c_Pmt_Payment.Payment_Amount;
      --完税凭证金额 保留两位小数
      v_Ems_Io_Ec_Fee_Tax.Tax_Receipt_Num := c_Pmt_Payment.Payment_Num; --完税凭证好
      v_Ems_Io_Ec_Fee_Tax.Remark          := c_Pmt_Payment.Payment_Depart_Name; --完税凭证征收机关
      v_Ems_Io_Ec_Fee_Tax.Invoice_Date    := c_Pmt_Payment.Payment_Date; --完税凭证日期
      v_Ems_Io_Ec_Fee_Tax.Invoice_Maker   := Null;
    
      v_Ems_Io_Ec_Fee_Tax.Created_Ldap_Code      := i_Account; --创建人LDAPCODE
      v_Ems_Io_Ec_Fee_Tax.Creation_Date          := v_Sysdate; --创建日期
      v_Ems_Io_Ec_Fee_Tax.Last_Updated_Ldap_Code := i_Account; --最后更新人LDAP编码
      v_Ems_Io_Ec_Fee_Tax.Last_Update_Date       := v_Sysdate; --最后更新日期
      v_Ems_Io_Ec_Fee_Tax.Source_System          := 'CIMS'; --来源系统
      v_Ems_Io_Ec_Fee_Tax.Source_Order_Id        := v_Pmt_Account_Head.Account_Head_Id; --来源单据ID
      v_Ems_Io_Ec_Fee_Tax.Source_Order_Code      := v_Pmt_Account_Head.Account_Num; --来源单据编码
      v_Ems_Io_Ec_Fee_Tax.Source_Order_Line_Id   := c_Pmt_Payment.Payment_Id; --来源单据行ID
    
      Insert Into Ems_Io_Ec_Fee_Tax
        (Io_Fee_Tax_Id,
         Io_Fee_Budget_Id,
         Tax_Amount,
         Tax_Receipt_Num,
         Created_Ldap_Code,
         Creation_Date,
         Last_Updated_Ldap_Code,
         Last_Update_Date,
         Source_System,
         Source_Order_Id,
         Source_Order_Code,
         Source_Order_Line_Id,
         --INVOICE_MAKER,
         Invoice_Date,
         Attribute1,
         Remark)
      Values
        (v_Ems_Io_Ec_Fee_Tax.Io_Fee_Tax_Id,
         v_Ems_Io_Ec_Fee_Tax.Io_Fee_Budget_Id,
         v_Ems_Io_Ec_Fee_Tax.Tax_Amount,
         v_Ems_Io_Ec_Fee_Tax.Tax_Receipt_Num,
         v_Ems_Io_Ec_Fee_Tax.Created_Ldap_Code,
         v_Ems_Io_Ec_Fee_Tax.Creation_Date,
         v_Ems_Io_Ec_Fee_Tax.Last_Updated_Ldap_Code,
         v_Ems_Io_Ec_Fee_Tax.Last_Update_Date,
         v_Ems_Io_Ec_Fee_Tax.Source_System,
         v_Ems_Io_Ec_Fee_Tax.Source_Order_Id,
         v_Ems_Io_Ec_Fee_Tax.Source_Order_Code,
         v_Ems_Io_Ec_Fee_Tax.Source_Order_Line_Id,
         --V_EMS_IO_EC_FEE_TAX.INVOICE_MAKER,
         v_Ems_Io_Ec_Fee_Tax.Invoice_Date,
         v_Ems_Io_Ec_Fee_Tax.Attribute1,
         v_Ems_Io_Ec_Fee_Tax.Remark);
    
    End Loop;
  End If;
  
  -- 法务合同信息写到EMS，2018-08-21 张开安 添加
/*  FOR C_PMT_LEGAL_CANTRACT IN (SELECT * FROM T_PMT_LEGAL_CONTRACT WHERE ACCOUNT_HEAD_ID = I_ACCOUNT_HEAD_ID) LOOP
    V_EMS_IO_EC_HT_L_S := EMS_IO_EC_HT_L_S.NEXTVAL;
    V_CONTRACT_BARCODE := C_PMT_LEGAL_CANTRACT.CONTRACT_BARCODE;
    INSERT INTO EMS_IO_EC_HT_L
    (EC_HT_L_ID, IO_FEE_REIM_ID, CONTRACT_BARCODE)
    VALUES
    (V_EMS_IO_EC_HT_L_S, v_Ems_Io_Ec_Fee_Reim_h.Io_Fee_Reim_Id, V_CONTRACT_BARCODE);
  END LOOP;*/
   INSERT INTO EMS_IO_HT_L
     (IO_CONTRACT_ID,
      IO_ORDER_ID,
      ORDER_TYPE,
      CONTRACT_BARCODE,
      CONTRACT_NUM,
      CONTRACT_NAME,
      CONTRACT_PARTY_A,
      CONTRACT_PARTY_B,
      CONTRACT_OPERATOR,
      CONTRACT_OPERATOR_NAME,
      CREATED_LDAP_CODE,
      CREATION_DATE,
      SOURCE_ORDER_CODE,
      SOURCE_ORDER_ID,
      SOURCE_ORDER_TYPE,
      SOURCE_SYSTEM,
      VALID_DATE,
      INVALID_DATE,
      ORDER_SOURCE_SYSTEM)
     SELECT EMS_IO_HT_L_S.NEXTVAL,
            V_EMS_IO_EC_FEE_REIM_H.IO_FEE_REIM_ID,
            'EC',
            TLC.CONTRACT_BARCODE,
            TLC.CONTRACT_CODE,
            TLC.CONTRACT_NAME,
            TLC.CONTRACT_PARTY_A,
            TLC.CONTRACT_PARTY_B,
            TLC.CONTRACT_UNDER_SIGNED,
            I_ACCOUNT,
            I_ACCOUNT,
            SYSDATE,
            TLC.CONTRACT_CODE,
            TLC.CONTRACT_ID,
            V_EMS_IO_EC_FEE_BUDGET.SOURCE_ORDER_TYPE,
            'CIMS',
            TLC.CONTRACT_BEGIN_DATE,
            TLC.CONTRACT_END_DATE,
            'CIMS'
       FROM T_PMT_LEGAL_CONTRACT TLC
      WHERE TLC.ACCOUNT_HEAD_ID = I_ACCOUNT_HEAD_ID;
  

  --回写结算批状态
  Update t_Pmt_Account_Head
     Set Ems_Flag          = '00',
         Import_Ems_Time   = Sysdate,
         Status            = '05', --引EMS
         Last_Updated_By   = i_Account,
         Last_Updated_Date = Sysdate,
         Ems_Error_Message = '引入接口，等待EMS处理，操作MIP账号：' || i_Account
   Where Account_Head_Id = i_Account_Head_Id;

Exception
  When Others Then
    o_Result     := '0';
    o_Result_Msg := '引入EMS失败！' || Substr(Sqlerrm(Sqlcode), 1, 256);
    Return;
End;

  ----------------------------------------------------------------------
  -- AUTHOR  : liyuanji
  -- CREATED : 2015-01-20
  -- PURPOSE : 获取推广物料采购EMS接口处理结果
  ----------------------------------------------------------------------
  PROCEDURE P_CHARGES_STATUS(O_RESULT     OUT VARCHAR2, --返回错误码
                             O_RESULT_MSG OUT VARCHAR2 --返回错误信息
                             ) IS
  
    V_EMS_IO_EC_FEE_REIM_H EMS_IO_EC_FEE_REIM_H%ROWTYPE; --EMS报销支付头表
    VT_ERR_MSG           T_PMT_ACCOUNT_HEAD.EMS_ERROR_MESSAGE%TYPE;  
  
  BEGIN
    O_RESULT     := '1';
    O_RESULT_MSG := '执行成功';
  
    --获取获取推广物料引用EMS接口状态
    FOR C_PMT_ACCOUNT_HEAD IN (SELECT /*+DRIVING_SITE(T)*/
                                A.ACCOUNT_HEAD_ID,
                                A.ACCOUNT_NUM,
                                A.ENTITY_ID,
                                MAX(T.IO_FEE_REIM_ID) AS IO_FEE_REIM_ID
                                 FROM EMS_IO_EC_FEE_REIM_H T,
                                      T_PMT_ACCOUNT_HEAD   A
                                WHERE T.SOURCE_ORDER_ID = to_char(A.ACCOUNT_HEAD_ID)
                                  AND T.SOURCE_SYSTEM = 'CIMS'
                                  AND T.SOURCE_ORDER_TYPE in ('10','20') --推广物料自定义传入type
                                  AND A.EMS_FLAG = '00'
                                GROUP BY A.ACCOUNT_HEAD_ID,A.ACCOUNT_NUM,A.ENTITY_ID) LOOP
    
      BEGIN  
      
        --查询EMS接口处理结果，优先取成功的数据
        BEGIN
          SELECT *
            INTO V_EMS_IO_EC_FEE_REIM_H
          FROM EMS_IO_EC_FEE_REIM_H
           WHERE SOURCE_ORDER_ID = to_char(C_PMT_ACCOUNT_HEAD.ACCOUNT_HEAD_ID)
             AND SOURCE_SYSTEM = 'CIMS'
             AND SOURCE_ORDER_TYPE in ('10','20')
             AND REIM_CREATED_FLAG = 'Y' 
             AND SYNC_STATUS = 'Processed' AND ROWNUM = 1;
        EXCEPTION 
          WHEN NO_DATA_FOUND THEN
             --取最新数据
             SELECT *
                INTO V_EMS_IO_EC_FEE_REIM_H
             FROM EMS_IO_EC_FEE_REIM_H
             WHERE IO_FEE_REIM_ID = C_PMT_ACCOUNT_HEAD.IO_FEE_REIM_ID;
        END;
        
       
         
        --状态查询写入接口表
        INSERT INTO INTF_PMT_EMS_STATUS(
          ID,
          BILL_TYPE,
          BILL_ID,
          BILL_NO,
          FEE_CODE,
          SYNC_STATUS,
          REFUSE_FLAG,
          CREATED_FLAG,
          ORDER_STATUS,
          ERROR_DATE,
          ERROR_REASON,
          BIZ_STATUS,
          CREATED_BY,
          CREATION_DATE,
          LAST_UPDATED_BY,
          LAST_UPDATE_DATE,
          ENTITY_ID,
          RUN_STEP
        ) 
        VALUES (
          S_INTF_PMT_EMS_STATUS.NEXTVAL,
          'YS',
          C_PMT_ACCOUNT_HEAD.ACCOUNT_HEAD_ID,
          C_PMT_ACCOUNT_HEAD.ACCOUNT_NUM,
          NULL,
          V_EMS_IO_EC_FEE_REIM_H.SYNC_STATUS,
          V_EMS_IO_EC_FEE_REIM_H.REFUSE_FLAG,
          V_EMS_IO_EC_FEE_REIM_H.REIM_CREATED_FLAG,
          NULL,
          NULL,
          V_EMS_IO_EC_FEE_REIM_H.ERROR_REASON,
          NULL,
          'admin',
          sysdate,
          'admin',
          sysdate,
          C_PMT_ACCOUNT_HEAD.ENTITY_ID,
          'PKG_PMT_CHARGES.P_CHARGES_STATUS'
        );
          
      
        --判断结算批数据处理成功/失败
        IF V_EMS_IO_EC_FEE_REIM_H.REIM_CREATED_FLAG = 'Y' AND
           V_EMS_IO_EC_FEE_REIM_H.SYNC_STATUS = 'Processed' THEN
          --EMS生成单据成功 更新结算批状态
          UPDATE T_PMT_ACCOUNT_HEAD
             SET EMS_FLAG          = '01',
                 EMS_ERROR_MESSAGE = 'EMS生成EC单据成功，CIMS引入操作账号：' ||
                                     LAST_UPDATED_BY
           WHERE ACCOUNT_HEAD_ID = C_PMT_ACCOUNT_HEAD.ACCOUNT_HEAD_ID;
        
        ELSIF V_EMS_IO_EC_FEE_REIM_H.REFUSE_FLAG = 'Y' AND
              V_EMS_IO_EC_FEE_REIM_H.SYNC_STATUS = 'Error' AND
              NVL(V_EMS_IO_EC_FEE_REIM_H.REIM_CREATED_FLAG, 'N') = 'N' THEN
          --EMS生成单据失败 更新结算批状态
          UPDATE T_PMT_ACCOUNT_HEAD
             SET EMS_FLAG          = '02',
                 STATUS            = '06',
                 EMS_ERROR_MESSAGE = F_TRUNCB_VARCHAR(V_EMS_IO_EC_FEE_REIM_H.ERROR_REASON,512)
           WHERE ACCOUNT_HEAD_ID = C_PMT_ACCOUNT_HEAD.ACCOUNT_HEAD_ID;
        END IF;
      
      EXCEPTION
        WHEN OTHERS THEN
          BEGIN
            VT_ERR_MSG := '获取结算批（验收单）EMS接口处理结果异常：' || SQLCODE || ' ' || SQLERRM;
            UPDATE T_PMT_ACCOUNT_HEAD SET
            EMS_ERROR_MESSAGE = F_TRUNCB_VARCHAR(DECODE(EMS_ERROR_MESSAGE,NULL,'',EMS_ERROR_MESSAGE)
            || VT_ERR_MSG,512)
            WHERE ACCOUNT_HEAD_ID = C_PMT_ACCOUNT_HEAD.ACCOUNT_HEAD_ID;
          EXCEPTION
          WHEN OTHERS THEN
            NULL;
          END;
      END;
    
    END LOOP;
  
  EXCEPTION
    WHEN OTHERS THEN
      O_RESULT     := '0';
      O_RESULT_MSG := '执行失败！' || SUBSTR(SQLERRM(SQLCODE), 1, 256);
      RETURN;
  END;
  ----------------------------------------------------------------------
  -- AUTHOR  : liyuanji
  -- CREATED : 2015-01-21
  -- PURPOSE : 获取推广物料采购结算批支付结果
  ----------------------------------------------------------------------
  PROCEDURE P_CHARGES_PAYMENT_RESULT(O_RESULT     OUT VARCHAR2, --返回错误码
                                     O_RESULT_MSG OUT VARCHAR2 --返回错误信息
                                     ) IS
  
    V_EMS_CIMS_EC_FEE_REIM EMS_CIMS_EC_FEE_REIM%ROWTYPE; --EMS支付头表
    VT_ERR_MSG           T_PMT_ACCOUNT_HEAD.EMS_ERROR_MESSAGE%TYPE;  
  
  BEGIN
    O_RESULT     := '1';
    O_RESULT_MSG := '执行成功';
  
    --获取推广物料结算批引用EMS接口状态
    FOR C_PMT_ACCOUNT_HEAD IN (SELECT /*+DRIVING_SITE(T)*/
                                A.ACCOUNT_HEAD_ID,
                                A.ACCOUNT_NUM,
                                A.ENTITY_ID,
                                MAX(T.FEE_REIM_ID) AS FEE_REIM_ID
                               --
                               --,LISTAGG(T.FEE_REIM_CODE, ',') WITHIN GROUP(ORDER BY T.FEE_REIM_ID) AS FEE_REIM_CODE,
                               --COUNT(T.FEE_REIM_ID) AS CNT
                                 FROM EMS_CIMS_EC_FEE_REIM T,
                                      T_PMT_ACCOUNT_HEAD   A
                                WHERE T.SOURCE_ORDER_ID = to_char(A.ACCOUNT_HEAD_ID)
                                  AND T.SOURCE_SYSTEM = 'CIMS'
                                  AND T.SOURCE_ORDER_TYPE in ('10','20') --推广物料自定义传入type
                                  AND A.EMS_FLAG = '01'
                                  AND A.STATUS = '05'
                                GROUP BY A.ACCOUNT_HEAD_ID,A.ACCOUNT_NUM,A.ENTITY_ID) LOOP
    
      BEGIN
        
        --查询EMS支付处理结果，优先取最新的数据
        SELECT * INTO V_EMS_CIMS_EC_FEE_REIM FROM EMS_CIMS_EC_FEE_REIM
                                                  WHERE FEE_REIM_ID = C_PMT_ACCOUNT_HEAD.FEE_REIM_ID;
        /*BEGIN
          --优先取成功的数据，优先取成功的数据
          SELECT * INTO V_EMS_CIMS_EC_FEE_REIM FROM EMS_CIMS_EC_FEE_REIM
                                               WHERE SOURCE_ORDER_ID = to_char(C_PMT_ACCOUNT_HEAD.ACCOUNT_HEAD_ID)
                                               AND SOURCE_SYSTEM = 'CIMS'
                                               AND SOURCE_ORDER_TYPE in ('10','20')
                                               AND ORDER_STATUS = 'AUDITED' 
                                               AND BIZ_STATUS = 'PAID'
                                               AND ROWNUM = 1;
        EXCEPTION 
          WHEN NO_DATA_FOUND THEN
             SELECT * INTO V_EMS_CIMS_EC_FEE_REIM FROM EMS_CIMS_EC_FEE_REIM
                                                  WHERE FEE_REIM_ID = C_PMT_ACCOUNT_HEAD.FEE_REIM_ID;
        END;*/
        
        --状态查询写入接口表
        INSERT INTO INTF_PMT_EMS_STATUS(
          ID,
          BILL_TYPE,
          BILL_ID,
          BILL_NO,
          FEE_CODE,
          SYNC_STATUS,
          REFUSE_FLAG,
          CREATED_FLAG,
          ORDER_STATUS,
          ERROR_DATE,
          ERROR_REASON,
          BIZ_STATUS,
          CREATED_BY,
          CREATION_DATE,
          LAST_UPDATED_BY,
          LAST_UPDATE_DATE,
          ENTITY_ID,
          RUN_STEP
        ) 
        VALUES (
          S_INTF_PMT_EMS_STATUS.NEXTVAL,
          'YS',
          C_PMT_ACCOUNT_HEAD.ACCOUNT_HEAD_ID,
          C_PMT_ACCOUNT_HEAD.ACCOUNT_NUM,
          V_EMS_CIMS_EC_FEE_REIM.FEE_REIM_CODE,
          NULL,
          NULL,
          NULL,
          V_EMS_CIMS_EC_FEE_REIM.ORDER_STATUS,
          NULL,
          NULL,
          V_EMS_CIMS_EC_FEE_REIM.BIZ_STATUS,
          'admin',
          sysdate,
          'admin',
          sysdate,
          C_PMT_ACCOUNT_HEAD.ENTITY_ID,
          'PKG_PMT_CHARGES.P_CHARGES_PAYMENT_RESULT'
        );
      
        --判断结算批数据处理成功/失败
        IF V_EMS_CIMS_EC_FEE_REIM.ORDER_STATUS = 'AUDITED' THEN
          --EMS单据处理成功 更新结算批状态07结算完成
          UPDATE T_PMT_ACCOUNT_HEAD
             SET STATUS            = DECODE(V_EMS_CIMS_EC_FEE_REIM.BIZ_STATUS,
                                            'PAID',
                                            '07',
                                            STATUS),
                 ERP_PAY_AMOUNT            = DECODE(V_EMS_CIMS_EC_FEE_REIM.BIZ_STATUS,
                                            'PAID',
                                            V_EMS_CIMS_EC_FEE_REIM.ERP_PAY_AMOUNT,
                                            ERP_PAY_AMOUNT),
                 EMS_ERROR_MESSAGE = F_TRUNCB_VARCHAR('最新EC单号：' ||
                                     V_EMS_CIMS_EC_FEE_REIM.FEE_REIM_CODE ||
                                     '，单据状态：审核通过，是否结算：' ||
                                     DECODE(V_EMS_CIMS_EC_FEE_REIM.BIZ_STATUS,
                                            'PAID',
                                            '结算完成',
                                            'CREATED',
                                            '待结算',
                                            'PART_PAID',
                                            '部分结算',
                                            '未知'),512)
           WHERE ACCOUNT_HEAD_ID = C_PMT_ACCOUNT_HEAD.ACCOUNT_HEAD_ID;
        
        ELSIF V_EMS_CIMS_EC_FEE_REIM.ORDER_STATUS IN ('DRAFT', 'DISABLED') THEN
          --EMS单据驳回 更新结算批状态06EMS驳回
          UPDATE T_PMT_ACCOUNT_HEAD
             SET STATUS            = '06',
                 EMS_ERROR_MESSAGE = F_TRUNCB_VARCHAR('最新EC单号：' ||
                                     V_EMS_CIMS_EC_FEE_REIM.FEE_REIM_CODE ||
                                     '，单据状态：' || DECODE(V_EMS_CIMS_EC_FEE_REIM.ORDER_STATUS,
                                                        'DRAFT',
                                                        '驳回',
                                                        '作废'),512)
           WHERE ACCOUNT_HEAD_ID = C_PMT_ACCOUNT_HEAD.ACCOUNT_HEAD_ID;
        
        ELSIF 'SUBMITED' = V_EMS_CIMS_EC_FEE_REIM.ORDER_STATUS THEN
          --EMS单据驳回 更新结算批状态06EMS驳回
          UPDATE T_PMT_ACCOUNT_HEAD
             SET EMS_ERROR_MESSAGE = F_TRUNCB_VARCHAR('最新EC单号：' ||
                                     V_EMS_CIMS_EC_FEE_REIM.FEE_REIM_CODE ||
                                     '，单据状态：在途未审核，CIMS引入操作账号：' ||
                                     LAST_UPDATED_BY,512)
           WHERE ACCOUNT_HEAD_ID = C_PMT_ACCOUNT_HEAD.ACCOUNT_HEAD_ID;
        END IF;
        /*
               AUDITED  CREATED
        AUDITED PAID
        AUDITED PART_PAID
        DISABLED  DISABLED
        DISABLED  UNCREATE
        DRAFT UNCREATE
        DRAFT CREATED
        SUBMITED  UNCREATE
        SUBMITED  CREATED*/
      
      EXCEPTION
        WHEN OTHERS THEN
          BEGIN
            VT_ERR_MSG := '获取结算批（验收单）支付结果异常：' || SQLCODE || ' ' || SQLERRM;
            UPDATE T_PMT_ACCOUNT_HEAD SET
            EMS_ERROR_MESSAGE = F_TRUNCB_VARCHAR(DECODE(EMS_ERROR_MESSAGE,NULL,'',EMS_ERROR_MESSAGE)
            || VT_ERR_MSG,512)
            WHERE ACCOUNT_HEAD_ID = C_PMT_ACCOUNT_HEAD.ACCOUNT_HEAD_ID;
          EXCEPTION
          WHEN OTHERS THEN
            NULL;
          END;
      END;
    
    END LOOP;
  
  EXCEPTION
    WHEN OTHERS THEN
      O_RESULT     := '0';
      O_RESULT_MSG := '执行失败！' || SUBSTR(SQLERRM(SQLCODE), 1, 256);
      RETURN;
  END;
  
  ----------------------------------------------------------------------
  -- Author  : liyuanji
  -- Created : 2015-01-15
  -- Purpose : 推广物料采购支付（EMS）
  ----------------------------------------------------------------------
Procedure P_CHARGES_PAYMENT_CONTRACT(i_Account_Head_Id In Number, --推广物料结算批ID
                                     i_Account         In Varchar2, --登录账号
                                     o_Result          Out Varchar2, --返回错误码
                                     o_Result_Msg      Out Varchar2 --返回错误信息
                                     ) Is
  v_Ems_Io_Ec_Fee_Reim_h Ems_Io_Ec_Fee_Reim_h%Rowtype; --EMS报销支付头表
  V_EMS_IO_EC_HT_L_S     NUMBER; -- 法务合同主键 add by ex_zhangka 2019-02-27
  V_CONTRACT_BARCODE     VARCHAR2(108);
Begin
  o_Result     := '1';
  o_Result_Msg := '引入EMS成功';
  begin
    SELECT IO_FEE_REIM_ID
      INTO V_EMS_IO_EC_FEE_REIM_H.IO_FEE_REIM_ID
      FROM EMS_IO_EC_FEE_REIM_H
     WHERE SOURCE_ORDER_ID = to_char(I_ACCOUNT_HEAD_ID)
       AND Source_System = 'CIMS'
       AND ROWNUM = 1;
  Exception
    When NO_DATA_FOUND Then
      o_Result     := '9999';
      o_Result_Msg := 'EMS报销支付头表未找到此单据记录，保存法务合同信息无效！' ||
                      Substr(Sqlerrm(Sqlcode), 1, 256);
      Return;
  End;
  FOR C_PMT_LEGAL_CANTRACT IN (SELECT *
                                 FROM T_PMT_LEGAL_CONTRACT
                                WHERE ACCOUNT_HEAD_ID = I_ACCOUNT_HEAD_ID) LOOP
  
    V_CONTRACT_BARCODE := C_PMT_LEGAL_CANTRACT.CONTRACT_BARCODE;
    V_EMS_IO_EC_HT_L_S := EMS_IO_EC_HT_L_S.NEXTVAL;
  
    INSERT INTO EMS_IO_EC_HT_L
      (EC_HT_L_ID, IO_FEE_REIM_ID, CONTRACT_BARCODE)
    VALUES
      (V_EMS_IO_EC_HT_L_S,
       V_EMS_IO_EC_FEE_REIM_H.IO_FEE_REIM_ID,
       V_CONTRACT_BARCODE);
  
  END LOOP;

  --回写结算批状态
  Update t_Pmt_Account_Head
     Set Ems_Flag          = '00',
         Import_Ems_Time   = Sysdate,
         Status            = '05', --引EMS
         Last_Updated_By   = i_Account,
         Last_Updated_Date = Sysdate,
         Ems_Error_Message = '引入接口，等待EMS处理，操作MIP账号：' || i_Account
   Where Account_Head_Id = i_Account_Head_Id;

Exception
  When Others Then
    o_Result     := '0';
    o_Result_Msg := '引入EMS失败！' || Substr(Sqlerrm(Sqlcode), 1, 256);
    Return;
End;

END PKG_PMT_CHARGES;
/

