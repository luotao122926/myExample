create type        SYS_PLSQL_109638_DUMMY_1 as table of number;
/

