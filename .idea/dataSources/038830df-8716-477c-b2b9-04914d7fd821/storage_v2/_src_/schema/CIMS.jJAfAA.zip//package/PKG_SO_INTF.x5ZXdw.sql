create PACKAGE      PKG_SO_INTF IS
  /*----------------------------------------------------------------
  *         包：PKG_SO_INTF
  *   创建日期：2014-09-16
  *     创建者：廖丽章
  *   功能说明：1、销售单据与外部系统对接相关业务处理
  *
  *   过程成功：P_RESULT = 0
  *             P_ERR_MSG = 'SUCCESS';
  *
  *   过程失败：P_RESULT < -20000;
  *             P_ERR_MSG = 过程异常失败的提示信息
  *
  */ ----------------------------------------------------------------
  
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-09-17
  *     创建者：陈宇佳
  *   功能说明：子库接口转移
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_INV_TRANSFER(P_ENTITY_ID    IN NUMBER, --主体ID
                              P_SO_HEADER_ID IN NUMBER, --销售单据头ID
                              P_RESULT       OUT NUMBER, --返回错误ID
                              P_ERR_MSG      OUT VARCHAR2 --返回错误信息
                              );
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2017-01-11
  *     创建者：周建刚
  *   功能说明：子库接口转移-人工修复数据专用，使用前请咨询周建刚
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_INV_TRANSFER_ADMIN(P_ENTITY_ID    IN NUMBER, --主体ID
                              P_SO_HEADER_ID IN NUMBER, --销售单据头ID
                              P_RESULT       OUT NUMBER, --返回错误ID
                              P_ERR_MSG      OUT VARCHAR2 --返回错误信息
                              );                                                          
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-02-05
  *     创建者：陈武杰
  *   功能说明：子库转移回调
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_INV_TRANSFER_WIRTE_BACK(IN_TRANSACTION_ID INTF_INV_TRANSACTION_HEAD.ID%TYPE --headerId  update by guibr    ESB流水号
                                         
                                         --P_SO_HEADER_ID IN NUMBER --销售单头ID
                                         --P_RESULT       OUT NUMBER, --返回错误ID
                                         --P_ERR_MSG      OUT VARCHAR2 --返回错误信息
                                         );
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-09-24
  *     创建者：周建刚
  *   功能说明：更新退货申请单产品签收数量。根据A3退货签收接口更新退货申请明细行的产品签收数量
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_UPDATE_RECEIVEDQTY(P_RECEIVE_TYPE    IN VARCHAR2, --签收来源：A3签收，A3；库位签收，CIMS；AUDIT_DIRECT_CREATE,无实际物流，退货申请审核通过直接开退货单
                                    P_BILL_NUM        IN VARCHAR2, --退货申请单号
                                    P_SOURCE_BILL_NUM IN VARCHAR2, --源单号。库位签收时会传递库位单号，A3签收时固定传递"-1"
                                    P_RESULT          OUT NUMBER, --返回错误ID
                                    P_ERR_MSG         OUT VARCHAR2 --返回错误信息
                                    );

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-01-22
  *     创建者：周建刚
  *   功能说明：根据退货申请单ID更新退货申请单产品行签收数量、退货申请单开单标识
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_UPDATE_GEN_SO_FLAG(P_APPLY_HEADER_ID IN NUMBER, --退货申请单ID
                                    P_RESULT          OUT NUMBER, --返回错误ID
                                    P_ERR_MSG         OUT VARCHAR2 --返回错误信息
                                    );

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-01-13
  *     创建者：周建刚
  *   功能说明：[退货找源单]根据主体ID、客户、产品获取对应的可退货的原销售单号
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_FETCH_RETURN_SRC(P_RETURN_APPLY_BILLNUM IN VARCHAR2, --退货申请单号
                                  P_ENTITY_ID            IN NUMBER, --主体ID
                                  P_ACCOUNT_CODE         IN VARCHAR2, --账户编码
                                  P_CUSTOMER_CODE        IN VARCHAR2, --客户编码
                                  P_ERP_SUBINV_CODE      IN VARCHAR2, --ERP库存组织
                                  P_STATUS               IN VARCHAR2, --源单状态标识： 已签收  RECEIVED; 已开票  INVOICED
                                  P_ITEM_CODE            IN VARCHAR2, --产品编码
                                  P_ITEM_RETURN_QTY      IN NUMBER, --退货数量
                                  P_USER_CODE            IN VARCHAR2, --操作用户编码
                                  P_ENTITY_CUST_FLAG     IN VARCHAR2,--事业部客户标识
                                  P_CUSTOMER_CHANNEL_TYPE IN VARCHAR2,--经营渠道类型,网批类型的源单只能给网批退货使用
                                  P_TRX_MODE             IN VARCHAR2,--营销模式标识：PUSH 推式，PULL 拉式
                                  P_FACTORY_OU_ID        IN NUMBER,  --工厂OU ID
                                  P_ERP_OU_ID            IN NUMBER,  --客户OU ID
                                  P_RETURN_SRC_SO_NUM    IN VARCHAR2,--退货单源单（指定退货源单场景）
                                  P_RETURNABLE_QTY       OUT NUMBER, --可退货数量
                                  P_SO_LINE_ID           OUT VARCHAR2, --源单号
                                  P_RESULT               OUT NUMBER, --返回错误ID
                                  P_ERR_MSG              OUT VARCHAR2 --返回错误信息
                                  );

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2017-06-14
  *     创建者：周建刚
  *   功能说明：[退货找源单]退货申请审核是校验是否有足够的源单可退货
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_FETCH_RETURN_SRC_CHECK(P_ENTITY_ID            IN NUMBER, --主体ID
                                  P_ACCOUNT_CODE         IN VARCHAR2, --账户编码
                                  P_CUSTOMER_CODE        IN VARCHAR2, --客户编码
                                  P_ERP_SUBINV_CODE      IN VARCHAR2, --ERP库存组织
                                  P_ITEM_CODE            IN VARCHAR2, --产品编码
                                  P_USER_CODE            IN VARCHAR2, --操作用户编码
                                  P_ENTITY_CUST_FLAG     IN VARCHAR2,--事业部客户标识
                                  P_CUSTOMER_CHANNEL_TYPE IN VARCHAR2,--经营渠道类型,网批类型的源单只能给网批退货使用
                                  P_TRX_MODE             IN VARCHAR2,--营销模式标识：PUSH 推式，PULL 拉式
                                  P_RETURN_SRC_SO_NUM    IN VARCHAR2,--退货单源单（指定退货源单场景）
                                  P_RETURNABLE_QTY       OUT NUMBER, --可退货数量
                                  P_RESULT               OUT NUMBER, --返回错误ID
                                  P_ERR_MSG              OUT VARCHAR2 --返回错误信息
                                  );

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2019-03-13
  *     创建者：周建刚
  *   功能说明：更新签收日期
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_UPDATE_RECEIVE_DATE(P_SO_NUM               IN VARCHAR2,
                                     P_RECEIVE_DATE         IN VARCHAR2,
                                     P_RESULT               OUT NUMBER, --返回错误ID
                                     P_ERR_MSG              OUT VARCHAR2 --返回错误信息
                                     );
                                  
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-01-29
  *     创建者：周建刚
  *   功能说明：根据蓝单单号获取对应的红冲单信息
  *     返回值：
  */
  -------------------------------------------------------------------------------
  FUNCTION F_RED_SO_NUM_INFO(P_SO_NUM IN VARCHAR2) RETURN VARCHAR2;
  
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2016-08-18
  *     创建者：周建刚
  *   功能说明：1、判断客户是否为内部关联交易客户
                2、校验客户、账户是否有效； Y 为正常，N 为客户或账户失效、不存在等
  *             3、事业部客户标识 P_ENTITY_CUST_FLAG : Y 内部客户；N 普通客户
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_ENTITY_CUST_INFO(P_ENTITY_ID            IN NUMBER,    --主体ID
                                  P_CUSTOMER_ID          IN NUMBER,    --客户ID
                                  P_ACCOUNT_ID           IN NUMBER,    --账户ID
                                  P_SALES_CENTER_ID      IN NUMBER,    --营销中心ID
                                  P_INV_ID               IN NUMBER,    --仓库ID
                                  P_CUST_CHECK_FLAG      OUT VARCHAR2, --客户、账户校验结果标识: Y 为正常，N 为客户或账户失效、不存在等
                                  P_CUST_CHECK_MSG       OUT VARCHAR2, --与P_CUST_CHECK_FLAG，对应的校验结果提示
                                  P_ENTITY_CUST_FLAG     OUT VARCHAR2, --事业部客户标识: N 普通客户，Y 内部关联交易客户
                                  P_RESULT               OUT NUMBER,   --返回错误ID
                                  P_ERR_MSG              OUT VARCHAR2  --返回错误信息
                                  );
                                  
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2016-11-30
  *     创建者：周建刚
  *   功能说明：获取信息营销OU（客户OU）
                1、推式：根据仓库取客户OU信息
                2、拉式：根据仓库取工厂OU，从工厂OU和营销OU配置关系表取对应的营销OU。
  *             3、推拉结合：根据营销中心编码取财务管理的默认营销OU。如果没有对应配置信息，则根据仓库取工厂OU，从工厂OU和营销OU配置关系表取对应的营销OU。
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_CUST_OU_INFO(P_ENTITY_ID            IN NUMBER,    --主体ID
                              P_SALES_CENTER_ID      IN NUMBER,    --营销中心ID
                              P_INV_ID               IN NUMBER,    --仓库ID
                              P_IS_MATERIAL          IN VARCHAR2,  --是否推广物料。N：不是推广物料单据，Y：是推广物料单据
                              P_OU_ID                OUT NUMBER,   --营销OU（客户OU）ID
                              P_OU_NAME              OUT VARCHAR2, --营销OU（客户OU）名称
                              P_RESULT               OUT NUMBER,   --返回错误ID
                              P_ERR_MSG              OUT VARCHAR2  --返回错误信息
                              );
  
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2017-11-08
  *     创建者：周建刚
  *   功能说明：获取信息工厂OU（仓库OU）、营销OU（客户OU）、营销模式（推式、拉式）
                1、推式：根据仓库取客户OU信息
                2、拉式：根据仓库取工厂OU，从工厂OU和营销OU配置关系表取对应的营销OU。
  *             3、推拉结合：根据营销中心编码取财务管理的默认营销OU。如果没有对应配置信息，则根据仓库取工厂OU，从工厂OU和营销OU配置关系表取对应的营销OU。
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_ALL_OU_INFO(P_ENTITY_ID            IN NUMBER,    --主体ID
                             P_SALES_CENTER_ID      IN NUMBER,    --营销中心ID
                             P_INV_ID               IN NUMBER,    --仓库ID
                             P_IS_MATERIAL          IN VARCHAR2,  --是否推广物料。N：不是推广物料单据，Y：是推广物料单据
                             P_FACTORY_OU_ID        OUT NUMBER,   --工厂OU（仓库OU）ID
                             P_FACTORY_OU_NAME      OUT VARCHAR2, --工厂OU（仓库OU）名称
                             P_CUST_OU_ID           OUT NUMBER,   --营销OU（客户OU）ID
                             P_CUST_OU_NAME         OUT VARCHAR2, --营销OU（客户OU）名称
                             P_TRX_MODE             OUT VARCHAR2, --营销模式（推式、拉式）
                             P_RESULT               OUT NUMBER,   --返回错误ID
                             P_ERR_MSG              OUT VARCHAR2  --返回错误信息
                             );
                             
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2016-10-12
  *     创建者：周建刚
  *   功能说明：1、校验客户、账户是否有效；Y 为正常，N 为客户或账户失效、不存在等
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_ENTITY_CUST_CHECK(P_ENTITY_ID            IN NUMBER,    --主体ID
                                  P_CUSTOMER_ID          IN NUMBER,    --客户ID
                                  P_ACCOUNT_ID           IN NUMBER,    --账户ID
                                  P_SALES_CENTER_ID      IN NUMBER,    --营销中心ID
                                  P_CUST_CHECK_FLAG      OUT VARCHAR2, --客户、账户校验结果标识: Y 为正常，N 为客户或账户失效、不存在等
                                  P_CUST_CHECK_MSG       OUT VARCHAR2, --与P_CUST_CHECK_FLAG，对应的校验结果提示
                                  P_RESULT               OUT NUMBER,   --返回错误ID
                                  P_ERR_MSG              OUT VARCHAR2  --返回错误信息
                                  );
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2016-10-12
  *     创建者：周建刚
  *   功能说明：1、判断客户是否为内部关联交易客户
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_GET_ENTITY_CUST_FLAG(P_ENTITY_ID            IN NUMBER,    --主体ID
                                      P_INV_ID               IN NUMBER,    --仓库ID
                                      P_CUSTOMER_CODE        IN VARCHAR2,  --客户编码
                                      P_SALES_CENTER_CODE    IN VARCHAR2,  --营销中心编码
                                      P_ENTITY_CUST_FLAG     OUT VARCHAR2, --事业部客户标识: N 普通客户，Y 内部关联交易客户
                                      P_RESULT               OUT NUMBER,   --返回错误ID
                                      P_ERR_MSG              OUT VARCHAR2  --返回错误信息
                                  );
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2016-10-17
  *     创建者：周建刚
  *   功能说明：1、根据财务单号，返回财务单客户对应的事业部标识( N 普通客户，Y 内部关联交易客户)
                      (1)内部客户 T_CUSTOMER_HEADER.CUSTOMER_IS_INTERNAL='Y'
                      (2)内部关联交易客户 T_SO_SUPPLIER_REQUIRE_ENTITY.ICP_LG_RECEIVE_MODE 为1或2的客户为内部关联交易客户。
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_ENTITY_CUST_FLAG_BY_NUM(P_ENTITY_ID            IN NUMBER,    --主体ID
                                         P_SO_NUM               IN VARCHAR2,  --单据号
                                         P_ENTITY_CUST_FLAG     OUT VARCHAR2, --事业部客户标识: N 普通客户，Y 内部关联交易客户
                                         P_RESULT               OUT NUMBER,   --返回错误ID
                                         P_ERR_MSG              OUT VARCHAR2  --返回错误信息
                                     );
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2016-09-22
  *     创建者：周建刚
  *   功能说明：更新销售单的ERP签收标识、签收日期，并做第二步子库转移。
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_UP_ERP_LOGIST_RECEIVE(P_RESULT   OUT NUMBER, --返回错误ID
                                    P_ERR_MSG  OUT VARCHAR2 --返回错误信息
                                    );

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2016-10-18
  *     创建者：周建刚
  *   功能说明：财务单（制单、审核）触发仓储库存事务接口
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_INV_TRANSACTION(P_ENTITY_ID          IN T_INV_TRANSACTION_HISTORY.ENTITY_ID%TYPE,--经营主体ID
                                 P_SO_STATUS          IN T_SO_HEADER.SO_STATUS%TYPE,--单据状态
                                 P_TRANSACTION_DATE   IN T_INV_TRANSACTION_HISTORY.TRANSACTION_DATE%TYPE,--业务日期
                                 P_BUSINESS_HEADER_ID IN T_INV_TRANSACTION_HISTORY.BUSINESS_HEADER_ID%TYPE,--业务单据头ID
                                 P_RESULT             OUT NUMBER, --返回错误ID
                                 P_ERR_MSG            OUT VARCHAR2 --返回错误信息
                                );
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2016-12-12
  *     创建者：周建刚
  *   功能说明：根据运输合同的签收信息，更新财务单的签收信息。
  *             情形一：运输合同‘已执行’，但是对应的销售单不是‘已签收’
                情形二：内部事业部客户对应的运输合同‘已确认’、而且有差异，
                则自动更新销售单为‘已签收’(家用主体，解决有差异情况而且没有没有人工差异确认功能，
                运输合同一直都是‘已确认’状态)
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_UP_LG_CONTRACT_RECEIVE(
                                 P_RESULT             OUT NUMBER, --返回错误ID
                                 P_ERR_MSG            OUT VARCHAR2 --返回错误信息
                                );

  ------------------------------------------------------------------------------- 
  /*
  *   创建日期：2017-06-14
  *     创建者：周建刚
  *   功能说明：通用错误日志记录功能
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_TABLE_ACTION_LOG(P_TABLE_NAME     VARCHAR2, --操作表名称
                               P_ACTION_REMARKS VARCHAR2, --操作说明
                               P_PK             VARCHAR2, --关键主键
                               P_ISERR          NUMBER, --是否出错，1出错，0未出错
                               P_MSG            VARCHAR2 --错误信息
                               );
                               
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2017-06-15
  *     创建者：周建刚
  *   功能说明：根据销售单号更新对已经的运输合同签收系统标识.
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_UPDATE_RECEIVE_SYSTEM(P_SO_NUM               IN VARCHAR2,  --单据号
                                       P_USER_CODE            IN VARCHAR2, --操作用户编码
                                       P_RESULT               OUT NUMBER,   --返回错误ID
                                       P_ERR_MSG              OUT VARCHAR2  --返回错误信息
                                       );
                                       
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2018-02-28
  *     创建者：周建刚
  *   功能说明：自动补全单据状态
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_AUTO_COMPLETION(P_RESULT               OUT NUMBER,   --返回错误ID
                                 P_ERR_MSG              OUT VARCHAR2  --返回错误信息
                                 );
                                       
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2018-02-28
  *     创建者：周建刚
  *   功能说明：自动签收（仅供无需物流发货和签收的场景，不涉及差异处理）
                设置销售单头已签收、签收日期=当前日期；销售单行签收数量=产品数量（无差异签收），签收日期=当前日期
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_AUTO_RECEIVE(P_SO_HEADER_ID         IN NUMBER, --销售单据头ID
                              P_RESULT               OUT NUMBER,   --返回错误ID
                              P_ERR_MSG              OUT VARCHAR2  --返回错误信息
                              );
                                       
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2018-12-21
  *     创建者：周建刚
  *   功能说明：销售开单时校验销售单的单据类型配置是否完整。
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_CHECK_BILL_TYPE_CONFIG(P_ENTITY_ID            IN NUMBER,   --主体ID
                                        P_BILL_TYPE_ID         IN NUMBER,   --单据ID
                                        P_SALES_CENTER_ID      IN NUMBER,   --营销中心ID
                                        P_INV_ID               IN NUMBER,   --仓库ID
                                        P_OU_ID                IN NUMBER,   --营销ID
                                        P_RESULT               OUT NUMBER,  --返回错误ID
                                        P_ERR_MSG              OUT VARCHAR2 --返回错误信息
                                        );
                                       
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2019-01-16
  *     创建者：周建刚
  *   功能说明：判定客户、中心对应的转采购关系。
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_CHECK_PO_RELATION_CONFIG(P_ENTITY_ID            IN NUMBER,     --主体ID
                                          P_CUSTOMER_CODE        IN VARCHAR2,   --客户编码
                                          P_SALES_CENTER_CODE    IN VARCHAR2,   --营销中心编码
                                          P_INV_CODE             IN VARCHAR2,   --仓库编码
                                          P_PO_RELATION_FLAG     OUT VARCHAR2,  --采购关系标识
                                          P_RESULT               OUT NUMBER,    --返回错误ID
                                          P_ERR_MSG              OUT VARCHAR2   --返回错误信息
                                          );
  
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2019-01-24
  *     创建者：周建刚
  *   功能说明：退货申请签收差异给承运商开全陪单
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_RTN_DIFF_TO_VENDER(P_BILL_NUM         IN VARCHAR2,   --退货申请单号
                                    P_RECEIVE_DOC_CODE IN VARCHAR2,--收货通知单
                                    P_RESULT          OUT NUMBER,  --返回错误ID
                                    P_ERR_MSG         OUT VARCHAR2 --返回错误信息
                                    );
  
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2019-01-24
  *     创建者：周建刚
  *   功能说明：设置产品价格
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_SET_ITEM_PRICE(R_SO_INFT_HEADER  IN OUT T_SO_HEADER_INTERFACE%ROWTYPE, --销售单据接口头记录
                                R_SO_INFT_LINE    IN OUT T_SO_LINE_INTERFACE%ROWTYPE,   --销售单据接口行记录
                                P_RESULT          OUT NUMBER, --返回错误ID
                                P_ERR_MSG         OUT VARCHAR2 --返回错误信息
                                );                    
                                    
  -------------------------------------------------------------------------------  
END PKG_SO_INTF;
/

