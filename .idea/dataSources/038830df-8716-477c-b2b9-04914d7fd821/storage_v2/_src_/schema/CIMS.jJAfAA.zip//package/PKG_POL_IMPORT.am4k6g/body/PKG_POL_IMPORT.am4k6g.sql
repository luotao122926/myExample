create PACKAGE BODY PKG_POL_IMPORT AS
  v_Nl      Constant Varchar2(2) := Chr(13) || Chr(10); --换行
  v_Success Constant Varchar2(10) := 'SUCCESS';
  
  -----------------------------------------------------------------------------
  -- Author  : liangym2
  -- Created : 2018/04/12 18:18:40
  --  外部零售补贴标准导入临时表检查：
  -----------------------------------------------------------------------------
  PROCEDURE P_CHECK_EXT_RETAIL_SUB(IN_ENTITY_ID IN NUMBER --主体ID
                                   ,IOS_BILL_NO  IN OUT VARCHAR2 --导入批次号
                                   ,OS_MESSAGE   OUT VARCHAR2 --成功则返回“SUCCESS”，否则返回出错信息
                                   ) IS
    VN_ENTITY_ID NUMBER := IN_ENTITY_ID;
    VN_CNT       NUMBER;
  BEGIN
    -- D:ER13201804170001 此段代码用于从正式表复制数据进行调试 不调试就注释
    IF 1 = INSTR(IOS_BILL_NO, 'D:') THEN
      IOS_BILL_NO := SUBSTR(IOS_BILL_NO, 3);
      INSERT INTO T_POL_EXT_RETAIL_SUB_GTMP
        (RETAIL_SUBSIDIES_ID,
         ENTITY_ID,
         ENTITY_NAME,
         CUSTOMER_ID,
         CUSTOMER_CODE,
         CUSTOMER_NAME,
         CUSTOMER_CLASSIFICATION,
         SALES_CENTER_ID,
         SALES_CENTER_CODE,
         SALES_CENTER_NAME,
         POLICY_ID,
         POLICY_NUM,
         ITEM_ID,
         ITEM_CODE,
         ITEM_NAME,
         ITEM_TYPE,
         ITEM_MODEL,
         ITEM_POSITIONING,
         TERMINAL_ID,
         TERMINAL_CODE,
         TERMINAL_NAME,
         SUBSIDY_STAGE,
         SUBSIDY_STANDARD,
         BEGIN_DATE,
         END_DATE,
         REMARK,
         CREATED_BY,
         CREATION_DATE,
         LAST_UPDATED_BY,
         LAST_UPDATE_DATE,
         VERSION_NUM,
         ACCOUNT_ID,
         IMPORT_DATE,
         IMPORT_BATCH_CODE,
         CAL_POLICY_ID,
         CALCULATE_GROUP_NAME)
        select rn,
               0,
               (SELECT CL.CODE_NAME
                  FROM V_UP_CODELIST CL
                 WHERE CL.CODETYPE = 'BD_ENTITY_ID'
                   AND CL.CODE_VALUE = T.ENTITY_ID
                   AND (CL.ENTITY_ID IS NULL OR CL.ENTITY_ID = T.ENTITY_ID)),
               0,
               CUSTOMER_CODE,
               CUSTOMER_NAME,
               (SELECT CL.CODE_NAME
                  FROM V_UP_CODELIST CL
                 WHERE CL.CODETYPE = 'pol_cust_classification'
                   AND CL.CODE_VALUE = T.CUSTOMER_CLASSIFICATION
                   AND (CL.ENTITY_ID IS NULL OR CL.ENTITY_ID = T.ENTITY_ID)),
               0,
               SALES_CENTER_CODE,
               SALES_CENTER_NAME,
               0,
               POLICY_NUM,
               0,
               ITEM_CODE,
               ITEM_NAME,
               (SELECT CL.CODE_NAME
                  FROM V_UP_CODELIST CL
                 WHERE CL.CODETYPE = 'pol_product_type'
                   AND CL.CODE_VALUE = T.ITEM_TYPE
                   AND (CL.ENTITY_ID IS NULL OR CL.ENTITY_ID = T.ENTITY_ID)),
               ITEM_MODEL,
               (SELECT CL.CODE_NAME
                  FROM V_UP_CODELIST CL
                 WHERE CL.CODETYPE = 'ITEM_PRODUCT_POSITION'
                   AND CL.CODE_VALUE = T.ITEM_POSITIONING
                   AND (CL.ENTITY_ID IS NULL OR CL.ENTITY_ID = T.ENTITY_ID)),
               0,
               TERMINAL_CODE,
               TERMINAL_NAME,
               (SELECT CL.CODE_NAME
                  FROM V_UP_CODELIST CL
                 WHERE CL.CODETYPE = 'pol_subsidy_stage'
                   AND CL.CODE_VALUE = T.SUBSIDY_STAGE
                   AND (CL.ENTITY_ID IS NULL OR CL.ENTITY_ID = T.ENTITY_ID)),
               SUBSIDY_STANDARD,
               BEGIN_DATE,
               END_DATE,
               REMARK,
               CREATED_BY,
               CREATION_DATE,
               LAST_UPDATED_BY,
               LAST_UPDATE_DATE,
               VERSION_NUM,
               ACCOUNT_ID,
               IMPORT_DATE,
               IMPORT_BATCH_CODE,
               CAL_POLICY_ID,
               CALCULATE_GROUP_NAME
          from (select rownum as rn, N.*
                  from T_POL_EXT_RETAIL_SUBSIDIES N
                 where N.import_batch_code = IOS_BILL_NO
                 order by N.retail_subsidies_id) T;
      IOS_BILL_NO := NULL;
    END IF;
    BEGIN
      --UPDATE T_POL_EXT_RETAIL_SUB_GTMP T SET T.ERROR_INFO = ' ';
      --更新主体
      UPDATE T_POL_EXT_RETAIL_SUB_GTMP T
         SET T.ENTITY_ID = NVL((SELECT NVL(CL.CODE_VALUE, '0')
                                 FROM V_UP_CODELIST CL
                                WHERE CL.CODETYPE = 'BD_ENTITY_ID'
                                  AND CL.CODE_NAME = T.ENTITY_NAME),
                               0);
      UPDATE T_POL_EXT_RETAIL_SUB_GTMP T
         SET T.ERROR_INFO = NVL(T.ERROR_INFO,' ') ||
                            DECODE(T.ERROR_INFO, NULL, NULL, '；') || '主体“' ||
                            T.ENTITY_NAME || '”不存在'
       WHERE T.ENTITY_ID IS NULL
          OR T.ENTITY_ID = 0;
      --更新中心ID，中心名称
      MERGE INTO T_POL_EXT_RETAIL_SUB_GTMP MT
      USING (SELECT T.RETAIL_SUBSIDIES_ID, U.UNIT_ID, U.NAME
               FROM UP_ORG_UNIT U, T_POL_EXT_RETAIL_SUB_GTMP T
              WHERE U.ENTITY_ID = T.ENTITY_ID
                AND U.CODE = T.SALES_CENTER_CODE
                AND 'T' = U.IS_ENABLED) UT
      ON (UT.RETAIL_SUBSIDIES_ID = MT.RETAIL_SUBSIDIES_ID)
      WHEN MATCHED THEN
        UPDATE
           SET MT.SALES_CENTER_ID   = UT.UNIT_ID,
               MT.SALES_CENTER_NAME = UT.NAME;
      UPDATE T_POL_EXT_RETAIL_SUB_GTMP T
         SET T.ERROR_INFO = NVL(T.ERROR_INFO,' ') ||
                            DECODE(T.ERROR_INFO, NULL, NULL, '；') || '中心编码“' ||
                            T.SALES_CENTER_CODE || '”' ||
                            DECODE(T.SALES_CENTER_NAME,
                                   NULL,
                                   NULL,
                                   '、“' || T.SALES_CENTER_NAME || '”') ||
                            '无效或不存在'
       WHERE (T.SALES_CENTER_ID IS NULL OR T.SALES_CENTER_ID = 0)
         AND T.SALES_CENTER_CODE IS NOT NULL
         AND T.ENTITY_ID > 0;
      --更新客户ID，客户名称
      MERGE INTO T_POL_EXT_RETAIL_SUB_GTMP MT
      USING (SELECT T.RETAIL_SUBSIDIES_ID, H.CUSTOMER_ID, H.CUSTOMER_NAME
               FROM T_CUSTOMER_HEADER H, T_POL_EXT_RETAIL_SUB_GTMP T
              WHERE H.CUSTOMER_CODE = T.CUSTOMER_CODE) UT
      ON (UT.RETAIL_SUBSIDIES_ID = MT.RETAIL_SUBSIDIES_ID)
      WHEN MATCHED THEN
        UPDATE
           SET MT.CUSTOMER_ID   = UT.CUSTOMER_ID,
               MT.CUSTOMER_NAME = UT.CUSTOMER_NAME;
      UPDATE T_POL_EXT_RETAIL_SUB_GTMP T
         SET T.ERROR_INFO = NVL(T.ERROR_INFO,' ') ||
                            DECODE(T.ERROR_INFO, NULL, NULL, '；') || '客户编码“' ||
                            T.CUSTOMER_CODE || '”' ||
                            DECODE(T.CUSTOMER_NAME,
                                   NULL,
                                   NULL,
                                   '、“' || T.CUSTOMER_NAME || '”') ||
                            '无效或不存在'
       WHERE (T.CUSTOMER_ID IS NULL OR T.CUSTOMER_ID = 0)
         AND T.CUSTOMER_CODE IS NOT NULL;
      --更新账户ID
      UPDATE T_POL_EXT_RETAIL_SUB_GTMP T
         SET (T.ACCOUNT_ID) = NVL((SELECT V.ACCOUNT_ID
                                    FROM V_CUSTOMER_ACCOUNT_SALECENTER V
                                   WHERE V.ENTITY_ID = T.ENTITY_ID
                                     AND V.CUSTOMER_ID = T.CUSTOMER_ID
                                     AND V.SALES_CENTER_ID =
                                         T.SALES_CENTER_ID
                                     AND V.ACCOUNT_STATUS = 1),
                                  0);
      UPDATE T_POL_EXT_RETAIL_SUB_GTMP T
         SET T.ERROR_INFO = NVL(T.ERROR_INFO,' ') ||
                            DECODE(T.ERROR_INFO, NULL, NULL, '；') || '客户编码“' ||
                            T.CUSTOMER_CODE || '”' || '、中心编码“' ||
                            T.SALES_CENTER_CODE || '”不存在有效账户'
       WHERE (T.ACCOUNT_ID IS NULL OR T.ACCOUNT_ID = 0)
         AND T.CUSTOMER_CODE IS NOT NULL
         AND T.SALES_CENTER_CODE IS NOT NULL
         AND T.ENTITY_ID > 0;
      --更新产品ID、产品名称、产品描述
      MERGE INTO T_POL_EXT_RETAIL_SUB_GTMP MT
      USING (SELECT T.RETAIL_SUBSIDIES_ID,
                    BI.ITEM_ID,
                    BI.ITEM_NAME,
                    BI.PRODUCTMODEL
               FROM T_BD_ITEM BI, T_POL_EXT_RETAIL_SUB_GTMP T
              WHERE BI.ENTITY_ID = T.ENTITY_ID
                AND BI.ITEM_CODE = T.ITEM_CODE) UT
      ON (UT.RETAIL_SUBSIDIES_ID = MT.RETAIL_SUBSIDIES_ID)
      WHEN MATCHED THEN
        UPDATE
           SET MT.ITEM_ID    = UT.ITEM_ID,
               MT.ITEM_NAME  = UT.ITEM_NAME,
               MT.ITEM_MODEL = UT.PRODUCTMODEL;
      UPDATE T_POL_EXT_RETAIL_SUB_GTMP T
         SET T.ERROR_INFO = NVL(T.ERROR_INFO,' ') ||
                            DECODE(T.ERROR_INFO, NULL, NULL, '；') || '产品编码“' ||
                            T.ITEM_CODE || '”' ||
                            DECODE(T.ITEM_MODEL,
                                   NULL,
                                   NULL,
                                   '、“' || T.ITEM_MODEL || '”') || '不存在'
       WHERE (T.ITEM_ID IS NULL OR T.ITEM_ID = 0)
         AND T.ITEM_CODE IS NOT NULL
         AND T.ENTITY_ID > 0;
      --更新门店名称
      MERGE INTO T_POL_EXT_RETAIL_SUB_GTMP MT
      USING (SELECT T.RETAIL_SUBSIDIES_ID, TM.TERMINAL_ID, TM.TERMINAL_NAME
               FROM T_PRO_TERMINAL TM, T_POL_EXT_RETAIL_SUB_GTMP T
              WHERE --TM.ENTITY_ID = T.ENTITY_ID AND 
              TM.TERMINAL_CODE = T.TERMINAL_CODE) UT
      ON (UT.RETAIL_SUBSIDIES_ID = MT.RETAIL_SUBSIDIES_ID)
      WHEN MATCHED THEN
        UPDATE
           SET MT.TERMINAL_ID   = UT.TERMINAL_ID,
               MT.TERMINAL_NAME = UT.TERMINAL_NAME;
      UPDATE T_POL_EXT_RETAIL_SUB_GTMP T
         SET T.ERROR_INFO = NVL(T.ERROR_INFO,' ') ||
                            DECODE(T.ERROR_INFO, NULL, NULL, '；') || '门店编码“' ||
                            T.TERMINAL_CODE || '”' ||
                            DECODE(T.TERMINAL_NAME,
                                   NULL,
                                   NULL,
                                   '、“' || T.TERMINAL_NAME || '”') || '不存在'
       WHERE (T.TERMINAL_ID IS NULL OR T.TERMINAL_ID = 0)
         AND T.TERMINAL_CODE IS NOT NULL
      --AND T.ENTITY_ID > 0
      --
      ;
    
      --更新政策ID、政策ID（算法分组）
      --T_POL_EXT_RETAIL_SUB_TEMP
      MERGE INTO T_POL_EXT_RETAIL_SUB_GTMP MT
      USING (SELECT T.RETAIL_SUBSIDIES_ID,
                    NVL(P.PARENT_POLICY_ID, P.POLICY_ID) AS POLICY_ID,
                    P.POLICY_ID AS CAL_POLICY_ID,
                    --polPolicyNum
                    --select t.query_language from up_quicksearch_config t where t.name='polPolicyNum'
                    P.SALES_CENTER_ID AS PO_SALES_CENTER_ID
               FROM T_POL_POLICY P, T_POL_EXT_RETAIL_SUB_GTMP T
              WHERE P.ENTITY_ID = T.ENTITY_ID
                AND P.POLICY_NUMBER LIKE T.POLICY_NUM || '%'
                AND P.CALCULATE_GROUP_NAME = T.CALCULATE_GROUP_NAME
                AND T.POLICY_NUM IS NOT NULL) UT
      ON (UT.RETAIL_SUBSIDIES_ID = MT.RETAIL_SUBSIDIES_ID)
      WHEN MATCHED THEN
        UPDATE
           SET MT.POLICY_ID          = UT.POLICY_ID,
               MT.CAL_POLICY_ID      = UT.CAL_POLICY_ID,
               MT.PO_SALES_CENTER_ID = UT.PO_SALES_CENTER_ID;
      UPDATE T_POL_EXT_RETAIL_SUB_GTMP T
         SET T.ERROR_INFO = NVL(T.ERROR_INFO,' ') ||
                            DECODE(T.ERROR_INFO, NULL, NULL, '；') || '政策编码“' ||
                            T.POLICY_NUM || '”' || '、政策算法分组“' ||
                            T.CALCULATE_GROUP_NAME || '”不存在符合条件的有效的政策申请'
       WHERE (T.POLICY_ID IS NULL OR T.POLICY_ID = 0)
         AND T.POLICY_NUM IS NOT NULL
         AND T.CALCULATE_GROUP_NAME IS NOT NULL
         AND T.ENTITY_ID > 0;
      UPDATE T_POL_EXT_RETAIL_SUB_GTMP T
         SET T.ERROR_INFO = NVL(T.ERROR_INFO,' ') ||
                            DECODE(T.ERROR_INFO, NULL, NULL, '；') || '政策编码为何可以为空'
       WHERE (T.POLICY_NUM IS NULL
         --OR T.CALCULATE_GROUP_NAME IS NULL
         --
         )
         AND T.ENTITY_ID > 0;
      --更新客户分类
      MERGE INTO T_POL_EXT_RETAIL_SUB_GTMP MT
      USING (SELECT T.RETAIL_SUBSIDIES_ID,
                    CL.CODE_VALUE,
                    T.CUSTOMER_CLASSIFICATION AS CUSTOMER_CLASSIFICATION1
               FROM V_UP_CODELIST CL
              RIGHT JOIN T_POL_EXT_RETAIL_SUB_GTMP T
                 ON ( --
                     CL.CODETYPE = 'pol_cust_classification' AND
                     CL.CODE_NAME = T.CUSTOMER_CLASSIFICATION AND
                     (CL.ENTITY_ID IS NULL OR CL.ENTITY_ID = T.ENTITY_ID)
                    --
                    )
              WHERE T.CUSTOMER_CLASSIFICATION IS NOT NULL) UT
      ON (UT.RETAIL_SUBSIDIES_ID = MT.RETAIL_SUBSIDIES_ID)
      WHEN MATCHED THEN
        UPDATE
           SET MT.CUSTOMER_CLASSIFICATION = NVL(UT.CODE_VALUE,
                                                MT.CUSTOMER_CLASSIFICATION),
               MT.ERROR_INFO              = NVL(MT.ERROR_INFO,' ') || (CASE
                                              WHEN UT.CODE_VALUE IS NOT NULL THEN
                                               NULL
                                              ELSE
                                               DECODE(MT.ERROR_INFO, NULL, NULL, '；') || '客户分类“' ||
                                               MT.CUSTOMER_CLASSIFICATION || '”不存在'
                                            END);
      --更新产品类型
      MERGE INTO T_POL_EXT_RETAIL_SUB_GTMP MT
      USING (SELECT T.RETAIL_SUBSIDIES_ID,
                    CL.CODE_VALUE,
                    T.ITEM_TYPE AS ITEM_TYPE1
               FROM V_UP_CODELIST CL
              RIGHT JOIN T_POL_EXT_RETAIL_SUB_GTMP T
                 ON ( --
                     CL.CODETYPE = 'pol_product_type' AND
                     CL.CODE_NAME = T.ITEM_TYPE AND
                     (CL.ENTITY_ID IS NULL OR CL.ENTITY_ID = T.ENTITY_ID)
                    --
                    )
              WHERE T.ITEM_TYPE IS NOT NULL) UT
      ON (UT.RETAIL_SUBSIDIES_ID = MT.RETAIL_SUBSIDIES_ID)
      WHEN MATCHED THEN
        UPDATE
           SET MT.ITEM_TYPE  = NVL(UT.CODE_VALUE, MT.ITEM_TYPE),
               MT.ERROR_INFO = NVL(MT.ERROR_INFO,' ') || (CASE
                                 WHEN UT.CODE_VALUE IS NOT NULL THEN
                                  NULL
                                 ELSE
                                  DECODE(MT.ERROR_INFO, NULL, NULL, '；') || '产品类型“' || MT.ITEM_TYPE ||
                                  '”不存在'
                               END);
      --更新补贴阶段
      MERGE INTO T_POL_EXT_RETAIL_SUB_GTMP MT
      USING (SELECT T.RETAIL_SUBSIDIES_ID,
                    CL.CODE_VALUE,
                    T.SUBSIDY_STAGE AS SUBSIDY_STAGE1
               FROM V_UP_CODELIST CL
              RIGHT JOIN T_POL_EXT_RETAIL_SUB_GTMP T
                 ON ( --
                     CL.CODETYPE = 'pol_subsidy_stage' AND
                     CL.CODE_NAME = T.SUBSIDY_STAGE AND
                     (CL.ENTITY_ID IS NULL OR CL.ENTITY_ID = T.ENTITY_ID)
                    --
                    )
              WHERE T.SUBSIDY_STAGE IS NOT NULL) UT
      ON (UT.RETAIL_SUBSIDIES_ID = MT.RETAIL_SUBSIDIES_ID)
      WHEN MATCHED THEN
        UPDATE
           SET MT.ERROR_INFO    = NVL(MT.ERROR_INFO,' ') || (CASE
                                    WHEN UT.CODE_VALUE IS NOT NULL THEN
                                     NULL
                                    ELSE
                                     DECODE(MT.ERROR_INFO, NULL, NULL, '；') || '补贴阶段“' ||
                                     MT.SUBSIDY_STAGE || '”不存在'
                                  END),
               MT.SUBSIDY_STAGE = NVL(UT.CODE_VALUE, MT.SUBSIDY_STAGE);
      --更新产品定位
      MERGE INTO T_POL_EXT_RETAIL_SUB_GTMP MT
      USING (SELECT T.RETAIL_SUBSIDIES_ID,
                    CL.CODE_VALUE,
                    T.ITEM_POSITIONING AS ITEM_POSITIONING1
               FROM V_UP_CODELIST CL
              RIGHT JOIN T_POL_EXT_RETAIL_SUB_GTMP T
                 ON ( --
                     CL.CODETYPE = 'ITEM_PRODUCT_POSITION' AND
                     CL.CODE_NAME = T.ITEM_POSITIONING AND
                     (CL.ENTITY_ID IS NULL OR CL.ENTITY_ID = T.ENTITY_ID)
                    --
                    )
              WHERE T.ITEM_POSITIONING IS NOT NULL) UT
      ON (UT.RETAIL_SUBSIDIES_ID = MT.RETAIL_SUBSIDIES_ID)
      WHEN MATCHED THEN
        UPDATE
           SET MT.ITEM_POSITIONING = NVL(UT.CODE_VALUE, MT.ITEM_POSITIONING),
               MT.ERROR_INFO       = NVL(MT.ERROR_INFO,' ') || (CASE
                                       WHEN UT.CODE_VALUE IS NOT NULL THEN
                                        NULL
                                       ELSE
                                        DECODE(MT.ERROR_INFO, NULL, NULL, '；') || '产品定位“' ||
                                        MT.ITEM_POSITIONING || '”不存在'
                                     END);
      --中心编码、客户编码、（门店编码）、政策编码、算法分组、产品编码、开始日期、终止日期
      UPDATE T_POL_EXT_RETAIL_SUB_GTMP MT
         SET MT.ERROR_INFO = NVL(MT.ERROR_INFO,' ') ||
                             DECODE(MT.ERROR_INFO, NULL, NULL, '；') ||
                             '存在重复数据：中心编码、客户编码、（门店编码）、政策编码、算法分组、产品编码、开始日期、终止日期的组合必须唯一；'
       WHERE MT.RETAIL_SUBSIDIES_ID IN
             (SELECT DISTINCT MIN_RETAIL_SUBSIDIES_ID
                FROM (SELECT T.ENTITY_ID,
                             T.SALES_CENTER_ID,
                             T.CUSTOMER_ID,
                             T.TERMINAL_ID,
                             T.POLICY_NUM,
                             T.CALCULATE_GROUP_NAME,
                             T.ITEM_ID,
                             T.BEGIN_DATE,
                             T.END_DATE,
                             MIN(T.RETAIL_SUBSIDIES_ID) AS MIN_RETAIL_SUBSIDIES_ID
                        FROM T_POL_EXT_RETAIL_SUB_GTMP T
                       WHERE (T.ERROR_INFO IS NULL OR T.ERROR_INFO = ' ')
                       GROUP BY T.ENTITY_ID,
                                T.SALES_CENTER_ID,
                                T.CUSTOMER_ID,
                                T.TERMINAL_ID,
                                T.POLICY_NUM,
                                T.CALCULATE_GROUP_NAME,
                                T.ITEM_ID,
                                T.BEGIN_DATE,
                                T.END_DATE
                      HAVING COUNT(0) > 1));
    
      /*UPDATE T_POL_EXT_RETAIL_SUBSIDIES T
         SET T.ENTITY_ID = 0
       WHERE T.ENTITY_ID IS NULL
          OR 0 > T.ENTITY_ID;
      UPDATE T_POL_EXT_RETAIL_SUBSIDIES T
         SET T.SALES_CENTER_ID = DECODE(T.SALES_CENTER_CODE,
                                        NULL,
                                        0,
                                        (CASE
                                          WHEN 0 > T.SALES_CENTER_ID THEN
                                           0
                                          ELSE
                                           NVL(T.SALES_CENTER_ID, 0)
                                        END)),
             T.CUSTOMER_ID = DECODE(T.CUSTOMER_CODE,
                                    NULL,
                                    0,
                                    (CASE
                                      WHEN 0 > T.CUSTOMER_ID THEN
                                       0
                                      ELSE
                                       NVL(T.CUSTOMER_ID, 0)
                                    END)),
             T.TERMINAL_ID = DECODE(T.TERMINAL_CODE,
                                    NULL,
                                    0,
                                    (CASE
                                      WHEN 0 > T.TERMINAL_ID THEN
                                       0
                                      ELSE
                                       NVL(T.TERMINAL_ID, 0)
                                    END)),
             T.POLICY_ID = DECODE(T.POLICY_NUM,
                                  NULL,
                                  0,
                                  (CASE
                                    WHEN 0 > T.POLICY_ID THEN
                                     0
                                    ELSE
                                     NVL(T.POLICY_ID, 0)
                                  END)),
             T.CAL_POLICY_ID = DECODE(T.CALCULATE_GROUP_NAME,
                                      NULL,
                                      0,
                                      (CASE
                                        WHEN 0 > T.CAL_POLICY_ID THEN
                                         0
                                        ELSE
                                         NVL(T.CAL_POLICY_ID, 0)
                                      END)),
             T.ITEM_ID = DECODE(T.ITEM_CODE,
                                NULL,
                                0,
                                (CASE
                                  WHEN 0 > T.ITEM_ID THEN
                                   0
                                  ELSE
                                   NVL(T.ITEM_ID, 0)
                                END))
       WHERE T.SALES_CENTER_CODE IS NULL
          OR T.SALES_CENTER_ID IS NULL
          OR 0 > T.SALES_CENTER_ID
          OR T.CUSTOMER_CODE IS NULL
          OR T.CUSTOMER_ID IS NULL
          OR 0 > T.CUSTOMER_ID
          OR T.TERMINAL_CODE IS NULL
          OR T.TERMINAL_ID IS NULL
          OR 0 > T.TERMINAL_ID
          OR T.POLICY_NUM IS NULL
          OR T.POLICY_ID IS NULL
          OR 0 > T.POLICY_ID
          OR T.CALCULATE_GROUP_NAME IS NULL
          OR T.CAL_POLICY_ID IS NULL
          OR 0 > T.CAL_POLICY_ID
          OR T.ITEM_CODE IS NULL
          OR T.ITEM_ID IS NULL
          OR 0 > T.ITEM_ID;
    
      UPDATE T_POL_EXT_RETAIL_SUB_GTMP T
         SET T.ENTITY_ID = 0
       WHERE T.ENTITY_ID IS NULL
          OR 0 > T.ENTITY_ID;
      UPDATE T_POL_EXT_RETAIL_SUB_GTMP T
         SET T.SALES_CENTER_ID = DECODE(T.SALES_CENTER_CODE,
                                        NULL,
                                        0,
                                        (CASE
                                          WHEN 0 > T.SALES_CENTER_ID THEN
                                           0
                                          ELSE
                                           NVL(T.SALES_CENTER_ID, 0)
                                        END)),
             T.CUSTOMER_ID = DECODE(T.CUSTOMER_CODE,
                                    NULL,
                                    0,
                                    (CASE
                                      WHEN 0 > T.CUSTOMER_ID THEN
                                       0
                                      ELSE
                                       NVL(T.CUSTOMER_ID, 0)
                                    END)),
             T.TERMINAL_ID = DECODE(T.TERMINAL_CODE,
                                    NULL,
                                    0,
                                    (CASE
                                      WHEN 0 > T.TERMINAL_ID THEN
                                       0
                                      ELSE
                                       NVL(T.TERMINAL_ID, 0)
                                    END)),
             T.POLICY_ID = DECODE(T.POLICY_NUM,
                                  NULL,
                                  0,
                                  (CASE
                                    WHEN 0 > T.POLICY_ID THEN
                                     0
                                    ELSE
                                     NVL(T.POLICY_ID, 0)
                                  END)),
             T.CAL_POLICY_ID = DECODE(T.CALCULATE_GROUP_NAME,
                                      NULL,
                                      0,
                                      (CASE
                                        WHEN 0 > T.CAL_POLICY_ID THEN
                                         0
                                        ELSE
                                         NVL(T.CAL_POLICY_ID, 0)
                                      END)),
             T.ITEM_ID = DECODE(T.ITEM_CODE,
                                NULL,
                                0,
                                (CASE
                                  WHEN 0 > T.ITEM_ID THEN
                                   0
                                  ELSE
                                   NVL(T.ITEM_ID, 0)
                                END))
       WHERE T.SALES_CENTER_CODE IS NULL
          OR T.SALES_CENTER_ID IS NULL
          OR 0 > T.SALES_CENTER_ID
          OR T.CUSTOMER_CODE IS NULL
          OR T.CUSTOMER_ID IS NULL
          OR 0 > T.CUSTOMER_ID
          OR T.TERMINAL_CODE IS NULL
          OR T.TERMINAL_ID IS NULL
          OR 0 > T.TERMINAL_ID
          OR T.POLICY_NUM IS NULL
          OR T.POLICY_ID IS NULL
          OR 0 > T.POLICY_ID
          OR T.CALCULATE_GROUP_NAME IS NULL
          OR T.CAL_POLICY_ID IS NULL
          OR 0 > T.CAL_POLICY_ID
          OR T.ITEM_CODE IS NULL
          OR T.ITEM_ID IS NULL
          OR 0 > T.ITEM_ID;*/
    
      MERGE INTO T_POL_EXT_RETAIL_SUB_GTMP MT
      USING (SELECT DISTINCT R.RETAIL_SUBSIDIES_ID
               FROM T_POL_EXT_RETAIL_SUBSIDIES L
              INNER JOIN T_POL_EXT_RETAIL_SUB_GTMP R
                 ON (R.ENTITY_ID = L.ENTITY_ID AND
                    NVL(R.SALES_CENTER_ID,0) = NVL(L.SALES_CENTER_ID,0) AND
                    NVL(R.CUSTOMER_ID,0) = NVL(L.CUSTOMER_ID,0) AND
                    NVL(R.TERMINAL_ID,0) = NVL(L.TERMINAL_ID,0) AND
                    NVL(R.POLICY_ID,0) = NVL(L.POLICY_ID,0) AND
                    R.CALCULATE_GROUP_NAME = L.CALCULATE_GROUP_NAME AND
                    R.ITEM_ID = L.ITEM_ID AND
                    (
                    --
                     (R.BEGIN_DATE < L.BEGIN_DATE AND
                     R.END_DATE > L.END_DATE)
                    --
                     OR (L.BEGIN_DATE < R.BEGIN_DATE AND
                     L.END_DATE > R.END_DATE)
                    --
                     OR (R.BEGIN_DATE BETWEEN L.BEGIN_DATE AND L.END_DATE)
                    --
                     OR (R.END_DATE BETWEEN L.BEGIN_DATE AND L.END_DATE)
                    --
                     OR (L.BEGIN_DATE BETWEEN R.BEGIN_DATE AND R.END_DATE)
                    --
                     OR (L.END_DATE BETWEEN R.BEGIN_DATE AND R.END_DATE)
                    --
                    ) AND (R.ERROR_INFO IS NULL OR R.ERROR_INFO = ' '))
             --
             ) UT
      ON (UT.RETAIL_SUBSIDIES_ID = MT.RETAIL_SUBSIDIES_ID)
      WHEN MATCHED THEN
        UPDATE
           SET MT.ERROR_INFO = NVL(MT.ERROR_INFO,' ') ||
                               DECODE(MT.ERROR_INFO, NULL, NULL, '；') ||
                               '与已导入的数据存在重复：中心编码、客户编码、（门店编码）、政策编码、算法分组、产品编码，同一个组合，开始日期、终止日期不能交叉（当然加上开始日期、终止日期的组合必须唯一）；';
      /*UPDATE T_POL_EXT_RETAIL_SUB_GTMP MT
        SET MT.ERROR_INFO = MT.ERROR_INFO ||
                            DECODE(MT.ERROR_INFO, NULL, NULL, '；') ||
                            '存在重复数据：中心编码、客户编码、（门店编码）、政策编码、算法分组、产品编码、开始日期、终止日期的组合必须唯一；'
      WHERE MT.ERROR_INFO IS NULL AND EXISTS (SELECT 1 FROM T_POL_EXT_RETAIL_SUBSIDIES T
      
      );*/
      UPDATE T_POL_EXT_RETAIL_SUB_GTMP T SET T.ERROR_INFO = TRIM(T.ERROR_INFO);
      
      SELECT COUNT(0) INTO VN_CNT FROM T_POL_EXT_RETAIL_SUB_GTMP T
      WHERE T.ERROR_INFO IS NOT NULL;
      IF 0 < VN_CNT THEN
        OS_MESSAGE := '共有' || VN_CNT || '条数据校验有错误';
        UPDATE T_POL_EXT_RETAIL_SUB_GTMP T
           SET T.ERROR_INFO = (CASE
                                WHEN 1 = INSTR(T.ERROR_INFO, '；') THEN
                                 SUBSTR(T.ERROR_INFO, 2)
                                ELSE
                                 T.ERROR_INFO
                              END);
        --SELECT * BULK COLLECT INTO OT_ERR_INFO FROM (SELECT ERROR_INFO FROM T_POL_EXT_RETAIL_SUB_GTMP ORDER BY RETAIL_SUBSIDIES_ID);
        --把判断是否有错误之前更新客户分类、产品类型、补贴阶段、产品定位为code_value，恢复为CODE_NAME
        /*UPDATE T_POL_EXT_RETAIL_SUB_GTMP T
           SET T.ERROR_INFO = (CASE
                                WHEN 1 = INSTR(T.ERROR_INFO, '；') THEN
                                 SUBSTR(T.ERROR_INFO, 2)
                                ELSE
                                 T.ERROR_INFO
                              END),
               T.CUSTOMER_CLASSIFICATION = NVL((SELECT CL.CODE_NAME
                                                 FROM V_UP_CODELIST CL
                                                WHERE CL.CODETYPE =
                                                      'pol_cust_classification'
                                                  AND CL.CODE_VALUE <>
                                                      CL.CODE_NAME
                                                  AND LENGTH(T.CUSTOMER_CLASSIFICATION) =
                                                      LENGTHB(T.CUSTOMER_CLASSIFICATION)
                                                  AND CL.CODE_VALUE =
                                                      T.CUSTOMER_CLASSIFICATION
                                                  AND (CL.ENTITY_ID IS NULL OR
                                                      CL.ENTITY_ID =
                                                      T.ENTITY_ID)),
                                               T.CUSTOMER_CLASSIFICATION),
               T.ITEM_TYPE               = NVL((SELECT CL.CODE_NAME
                                                 FROM V_UP_CODELIST CL
                                                WHERE CL.CODETYPE =
                                                      'pol_product_type'
                                                  AND CL.CODE_VALUE <>
                                                      CL.CODE_NAME
                                                  AND LENGTH(T.ITEM_TYPE) =
                                                      LENGTHB(T.ITEM_TYPE)
                                                  AND CL.CODE_VALUE =
                                                      T.ITEM_TYPE
                                                  AND (CL.ENTITY_ID IS NULL OR
                                                      CL.ENTITY_ID =
                                                      T.ENTITY_ID)),
                                               T.ITEM_TYPE),
               T.SUBSIDY_STAGE           = NVL((SELECT CL.CODE_NAME
                                                 FROM V_UP_CODELIST CL
                                                WHERE CL.CODETYPE =
                                                      'pol_subsidy_stage'
                                                  AND CL.CODE_VALUE <>
                                                      CL.CODE_NAME
                                                  AND LENGTH(T.SUBSIDY_STAGE) =
                                                      LENGTHB(T.SUBSIDY_STAGE)
                                                  AND CL.CODE_VALUE =
                                                      T.SUBSIDY_STAGE
                                                  AND (CL.ENTITY_ID IS NULL OR
                                                      CL.ENTITY_ID =
                                                      T.ENTITY_ID)),
                                               T.SUBSIDY_STAGE),
               T.ITEM_POSITIONING        = NVL((SELECT CL.CODE_NAME
                                                 FROM V_UP_CODELIST CL
                                                WHERE CL.CODETYPE =
                                                      'ITEM_PRODUCT_POSITION'
                                                  AND CL.CODE_VALUE <>
                                                      CL.CODE_NAME
                                                  AND LENGTH(T.ITEM_POSITIONING) =
                                                      LENGTHB(T.ITEM_POSITIONING)
                                                  AND CL.CODE_VALUE =
                                                      T.ITEM_POSITIONING
                                                  AND (CL.ENTITY_ID IS NULL OR
                                                      CL.ENTITY_ID =
                                                      T.ENTITY_ID)),
                                               T.ITEM_POSITIONING);*/
      ELSE
        OS_MESSAGE := 'SUCCESS';
      END IF;
      --没有错误的校验，返回成功
      /*SELECT NVL('' || (SELECT SUM(1)
                          FROM T_POL_EXT_RETAIL_SUB_GTMP T
                         WHERE T.ERROR_INFO IS NOT NULL),
                 'SUCCESS')
        INTO OS_MESSAGE
        FROM DUAL;*/
      IF 'SUCCESS' = OS_MESSAGE THEN
        --如果没有错误，更新导入批次号，并输出
        SELECT COUNT(0) INTO VN_CNT FROM T_POL_EXT_RETAIL_SUB_GTMP T;
        IF IOS_BILL_NO IS NULL THEN
          IF VN_ENTITY_ID IS NULL OR VN_ENTITY_ID <= 0 THEN
            --如果没有传主体ID，取第一个为主体ID
            SELECT T.ENTITY_ID
              INTO VN_ENTITY_ID
              FROM T_POL_EXT_RETAIL_SUB_GTMP T
             WHERE T.ENTITY_ID > 0
               AND 1 = ROWNUM;
          END IF;
          BEGIN
            PKG_BD.P_GET_BILL_NO(P_BILL_TYPE  => 'polExtRetImport',
                                 P_PREFIX_ADD => NULL,
                                 P_ENTITY_ID  => VN_ENTITY_ID,
                                 P_USER_ID    => NULL,
                                 P_BILL_NO    => IOS_BILL_NO,
                                 P_WAIT_BY    => NULL);
           EXCEPTION WHEN OTHERS THEN
            SELECT S_POL_EXT_RETAIL_SUBSIDIES.NEXTVAL INTO IOS_BILL_NO FROM DUAL;
          END;
          IF IOS_BILL_NO IS NULL THEN
            OS_MESSAGE := '检查外部零售补贴标准临时表异常：无法获取导入批次号';
            RETURN;
          END IF;
          /*UPDATE T_POL_EXT_RETAIL_SUB_GTMP T
             SET T.SALES_CENTER_ID = DECODE(T.SALES_CENTER_CODE,
                                            NULL,
                                            NULL,
                                            (CASE
                                              WHEN 0 > T.SALES_CENTER_ID THEN
                                               0
                                              ELSE
                                               T.SALES_CENTER_ID
                                            END)),
                 T.CUSTOMER_ID = DECODE(T.CUSTOMER_CODE,
                                        NULL,
                                        NULL,
                                        (CASE
                                          WHEN 0 > T.CUSTOMER_ID THEN
                                           0
                                          ELSE
                                           T.CUSTOMER_ID
                                        END)),
                 T.TERMINAL_ID = DECODE(T.TERMINAL_CODE,
                                        NULL,
                                        NULL,
                                        (CASE
                                          WHEN 0 > T.TERMINAL_ID THEN
                                           0
                                          ELSE
                                           T.TERMINAL_ID
                                        END)),
                 T.POLICY_ID = DECODE(T.POLICY_NUM,
                                      NULL,
                                      NULL,
                                      (CASE
                                        WHEN 0 > T.POLICY_ID THEN
                                         0
                                        ELSE
                                         T.POLICY_ID
                                      END)),
                 T.CAL_POLICY_ID = DECODE(T.CALCULATE_GROUP_NAME,
                                          NULL,
                                          NULL,
                                          (CASE
                                            WHEN 0 > T.CAL_POLICY_ID THEN
                                             0
                                            ELSE
                                             T.CAL_POLICY_ID
                                          END)),
                 T.ITEM_ID = DECODE(T.ITEM_CODE,
                                    NULL,
                                    NULL,
                                    (CASE
                                      WHEN 0 > T.ITEM_ID THEN
                                       0
                                      ELSE
                                       T.ITEM_ID
                                    END)),
                 T.ENTITY_ID = DECODE(T.ENTITY_NAME,
                                    NULL,
                                    NULL,
                                    (CASE
                                      WHEN 0 > T.ENTITY_ID THEN
                                       0
                                      ELSE
                                       T.ENTITY_ID
                                    END))
           WHERE T.SALES_CENTER_CODE IS NULL
                --OR T.SALES_CENTER_ID IS NULL
              OR 0 > T.SALES_CENTER_ID
              OR T.CUSTOMER_CODE IS NULL
                --OR T.CUSTOMER_ID IS NULL
              OR 0 > T.CUSTOMER_ID
              OR T.TERMINAL_CODE IS NULL
                --OR T.TERMINAL_ID IS NULL
              OR 0 > T.TERMINAL_ID
              OR T.POLICY_NUM IS NULL
                --OR T.POLICY_ID IS NULL
              OR 0 > T.POLICY_ID
              OR T.CALCULATE_GROUP_NAME IS NULL
                --OR T.CAL_POLICY_ID IS NULL
              OR 0 > T.CAL_POLICY_ID
              OR T.ITEM_CODE IS NULL
                --OR T.ITEM_ID IS NULL
              OR 0 > T.ITEM_ID
              OR T.ENTITY_NAME IS NULL
                --OR T.ENTITY_ID IS NULL
              OR 0 > T.ENTITY_ID;
          UPDATE T_POL_EXT_RETAIL_SUBSIDIES T
             SET T.SALES_CENTER_ID = DECODE(T.SALES_CENTER_CODE,
                                            NULL,
                                            NULL,
                                            (CASE
                                              WHEN 0 > T.SALES_CENTER_ID THEN
                                               0
                                              ELSE
                                               T.SALES_CENTER_ID
                                            END)),
                 T.CUSTOMER_ID = DECODE(T.CUSTOMER_CODE,
                                        NULL,
                                        NULL,
                                        (CASE
                                          WHEN 0 > T.CUSTOMER_ID THEN
                                           0
                                          ELSE
                                           T.CUSTOMER_ID
                                        END)),
                 T.TERMINAL_ID = DECODE(T.TERMINAL_CODE,
                                        NULL,
                                        NULL,
                                        (CASE
                                          WHEN 0 > T.TERMINAL_ID THEN
                                           0
                                          ELSE
                                           T.TERMINAL_ID
                                        END)),
                 T.POLICY_ID = DECODE(T.POLICY_NUM,
                                      NULL,
                                      NULL,
                                      (CASE
                                        WHEN 0 > T.POLICY_ID THEN
                                         0
                                        ELSE
                                         T.POLICY_ID
                                      END)),
                 T.CAL_POLICY_ID = DECODE(T.CALCULATE_GROUP_NAME,
                                          NULL,
                                          NULL,
                                          (CASE
                                            WHEN 0 > T.CAL_POLICY_ID THEN
                                             0
                                            ELSE
                                             T.CAL_POLICY_ID
                                          END)),
                 T.ITEM_ID = DECODE(T.ITEM_CODE,
                                    NULL,
                                    NULL,
                                    (CASE
                                      WHEN 0 > T.ITEM_ID THEN
                                       0
                                      ELSE
                                       T.ITEM_ID
                                    END)),
                 T.ENTITY_ID = (CASE
                                      WHEN 0 > T.ENTITY_ID THEN
                                       0
                                      ELSE
                                       T.ENTITY_ID
                                    END)
           WHERE T.SALES_CENTER_CODE IS NULL
                --OR T.SALES_CENTER_ID IS NULL
              OR 0 > T.SALES_CENTER_ID
              OR T.CUSTOMER_CODE IS NULL
                --OR T.CUSTOMER_ID IS NULL
              OR 0 > T.CUSTOMER_ID
              OR T.TERMINAL_CODE IS NULL
                --OR T.TERMINAL_ID IS NULL
              OR 0 > T.TERMINAL_ID
              OR T.POLICY_NUM IS NULL
                --OR T.POLICY_ID IS NULL
              OR 0 > T.POLICY_ID
              OR T.CALCULATE_GROUP_NAME IS NULL
                --OR T.CAL_POLICY_ID IS NULL
              OR 0 > T.CAL_POLICY_ID
              OR T.ITEM_CODE IS NULL
                --OR T.ITEM_ID IS NULL
              OR 0 > T.ITEM_ID
              --OR T.ENTITY_NAME IS NULL
                --OR T.ENTITY_ID IS NULL
              OR 0 > T.ENTITY_ID;*/
          INSERT INTO T_POL_EXT_RETAIL_SUBSIDIES
            (RETAIL_SUBSIDIES_ID,
             ENTITY_ID,
             --ENTITY_NAME,
             CUSTOMER_ID,
             CUSTOMER_CODE,
             CUSTOMER_NAME,
             CUSTOMER_CLASSIFICATION,
             SALES_CENTER_ID,
             SALES_CENTER_CODE,
             SALES_CENTER_NAME,
             POLICY_ID,
             POLICY_NUM,
             ITEM_ID,
             ITEM_CODE,
             ITEM_NAME,
             ITEM_TYPE,
             ITEM_MODEL,
             ITEM_POSITIONING,
             TERMINAL_ID,
             TERMINAL_CODE,
             TERMINAL_NAME,
             SUBSIDY_STAGE,
             SUBSIDY_STANDARD,
             BEGIN_DATE,
             END_DATE,
             REMARK,
             CREATED_BY,
             CREATION_DATE,
             LAST_UPDATED_BY,
             LAST_UPDATE_DATE,
             VERSION_NUM,
             ACCOUNT_ID,
             IMPORT_DATE,
             IMPORT_BATCH_CODE,
             CAL_POLICY_ID,
             CALCULATE_GROUP_NAME,
             PO_SALES_CENTER_ID)
            SELECT S_POL_EXT_RETAIL_SUBSIDIES.NEXTVAL,
                   ENTITY_ID,
                   --ENTITY_NAME,
                   CUSTOMER_ID,
                   CUSTOMER_CODE,
                   CUSTOMER_NAME,
                   CUSTOMER_CLASSIFICATION,
                   SALES_CENTER_ID,
                   SALES_CENTER_CODE,
                   SALES_CENTER_NAME,
                   POLICY_ID,
                   POLICY_NUM,
                   ITEM_ID,
                   ITEM_CODE,
                   ITEM_NAME,
                   ITEM_TYPE,
                   ITEM_MODEL,
                   ITEM_POSITIONING,
                   TERMINAL_ID,
                   TERMINAL_CODE,
                   TERMINAL_NAME,
                   SUBSIDY_STAGE,
                   SUBSIDY_STANDARD,
                   BEGIN_DATE,
                   END_DATE,
                   REMARK,
                   CREATED_BY,
                   SYSDATE,
                   LAST_UPDATED_BY,
                   LAST_UPDATE_DATE,
                   VERSION_NUM,
                   ACCOUNT_ID,
                   SYSDATE,
                   IOS_BILL_NO,
                   CAL_POLICY_ID,
                   CALCULATE_GROUP_NAME,
                   PO_SALES_CENTER_ID
              FROM T_POL_EXT_RETAIL_SUB_GTMP;
        
        END IF;
      END IF;
    
    EXCEPTION
      WHEN OTHERS THEN
        OS_MESSAGE := 'EXC:检查外部零售补贴标准临时表异常：' || dbms_utility.format_error_backtrace || ',异常消息：' || SQLERRM
        || V_NL || '，主体ID：' || VN_ENTITY_ID || '，临时表记录个数：' || VN_CNT;
        /*OS_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_POL_IMPORT.P_CHECK_EXT_RETAIL_SUB', SQLCODE,
                'EXC:检查外部零售补贴标准临时表异常，异常消息：' || dbms_utility.format_error_backtrace || SQLERRM);*/
        --OS_MESSAGE := 'EXC:检查外部零售补贴标准临时表异常：' || SQLERRM;
    END;
  END P_CHECK_EXT_RETAIL_SUB;
  
  -----------------------------------------------------------------------------
  -- Author  : liangym2
  -- Created : 2018/04/12 18:18:40
  --  外部零售补贴标准插入临时表：                                                   --
  -----------------------------------------------------------------------------
  PROCEDURE P_INSERT_EXT_RETAIL_SUB_TMP(ITAB_LIST IN TAB_IMPORT_COLS --导入数据集合
                                        --对ITAB_LIST的某些字段非空性检查，由java后台实现，避免多次TABLE(ITAB_LIST)
                                        ,IN_ENTITY_ID IN NUMBER --主体ID
                                        ,IOS_BILL_NO  IN OUT VARCHAR2 --导入批次号
                                        ,OS_MESSAGE   OUT VARCHAR2 --成功则返回“SUCCESS”，否则返回出错信息
                                        ) IS
    VN_CNT NUMBER;
  BEGIN
    BEGIN
      INSERT INTO T_POL_EXT_RETAIL_SUB_GTMP
        (RETAIL_SUBSIDIES_ID,
         ENTITY_ID,
         ENTITY_NAME,
         CUSTOMER_ID,
         CUSTOMER_CODE,
         CUSTOMER_NAME,
         CUSTOMER_CLASSIFICATION,
         SALES_CENTER_ID,
         SALES_CENTER_CODE,
         SALES_CENTER_NAME,
         POLICY_ID,
         POLICY_NUM,
         ITEM_ID,
         ITEM_CODE,
         ITEM_NAME,
         ITEM_TYPE,
         ITEM_MODEL,
         ITEM_POSITIONING,
         TERMINAL_ID,
         TERMINAL_CODE,
         TERMINAL_NAME,
         SUBSIDY_STAGE,
         SUBSIDY_STANDARD,
         BEGIN_DATE,
         END_DATE,
         REMARK,
         CREATED_BY,
         CREATION_DATE,
         LAST_UPDATED_BY,
         LAST_UPDATE_DATE,
         VERSION_NUM,
         ACCOUNT_ID,
         IMPORT_DATE,
         IMPORT_BATCH_CODE,
         CAL_POLICY_ID,
         CALCULATE_GROUP_NAME)
      --T_POL_EXT_RETAIL_SUB_GTMP 字段顺序以“描述”为准
        SELECT ROWNUM,
               NVL(ENTITY_ID, 0),
               NVL(ENTITY_NAME, '' || ENTITY_ID),
               CUSTOMER_ID,
               CUSTOMER_CODE,
               CUSTOMER_NAME,
               VC_NORMAL_S1, --CUSTOMER_CLASSIFICATION 客户分类
               SALES_CENTER_ID,
               SALES_CENTER_CODE,
               SALES_CENTER_NAME,
               NULL, --POLICY_ID
               VC_NORMAL_S2, --POLICY_NUM 政策编码
               NVL(ITEM_ID, 0),
               ITEM_CODE,
               NVL(ITEM_NAME, NVL(PRODUCTMODEL, ITEM_CODE)),
               VC_NORMAL_S3, --ITEM_TYPE 产品类型（码表pol_product_type）
               PRODUCTMODEL, --ITEM_MODEL
               VC_LONG1, --ITEM_POSITIONING 产品定位（码表ITEM_PRODUCT_POSITION）
               TERMINAL_ID,
               TERMINAL_CODE,
               TERMINAL_NAME,
               VC_NORMAL_S4, --SUBSIDY_STAGE 补贴阶段
               TO_NUMBER(VC_NORMAL_S5), --SUBSIDY_STANDARD 补贴标准
               DATE1,
               DATE2,
               --TO_DATE(VC_NORMAL_S7, 'YYYYMMDD'), --BEGIN_DATE
               --TO_DATE(VC_NORMAL_S8, 'YYYYMMDD'), --END_DATE
               VC_LONG2, --REMARK
               CREATED_BY,
               SYSDATE,
               LAST_UPDATED_BY,
               (CASE
                 WHEN LAST_UPDATED_BY IS NULL THEN
                  NULL
                 ELSE
                  SYSDATE
               END), --LAST_UPDATE_DATE
               --T_POL_EXT_RETAIL_SUB_GTMP 字段顺序以“描述”为准
               NULL, --VERSION_NUM
               NVL(ACCOUNT_ID, 0),
               NULL, --IMPORT_DATE
               VC_NORMAL_S6, --IMPORT_BATCH_CODE 导入批次号
               NULL, --CAL_POLICY_ID
               VC_NORMAL_M1 --CALCULATE_GROUP_NAME 政策算法分组名称
          FROM TABLE(ITAB_LIST) T;
      SELECT COUNT(0) INTO VN_CNT FROM T_POL_EXT_RETAIL_SUB_GTMP T
      WHERE T.POLICY_NUM IS NULL;
      OS_MESSAGE := 'SUCCESS';
      IF 0 < VN_CNT THEN
        OS_MESSAGE := 'EXC:插入外部零售补贴标准临时表异常，共有' || VN_CNT || '条政策编码为空';
      ELSE
        OS_MESSAGE := 'SUCCESS';
      END IF;
      
    EXCEPTION
      WHEN OTHERS THEN
        OS_MESSAGE := 'EXC:插入外部零售补贴标准临时表异常：' || SQLERRM;
    END;
  END P_INSERT_EXT_RETAIL_SUB_TMP;
  
  ----------------------------------------------------------------------
  -- Author  : huanghb12
  -- Created : 2018/04/12 16:34:40
  -- Purpose : 检查临时表T_POL_EXT_RETAIL_TMP数据的有效性     
  ----------------------------------------------------------------------
  PROCEDURE P_CHECK_EXTRETAIL_IMPORT(P_ENTITY_ID   IN NUMBER
                                    ,P_IMPORT_CODE IN VARCHAR2
                                    ,P_RESULT      OUT VARCHAR2) IS
   V_VALUE VARCHAR2(500); --存储信息
  
   V_ENTITY_ID NUMBER := P_ENTITY_ID;
   V_IMPORT_CODE VARCHAR2(32) := P_IMPORT_CODE;
  BEGIN
    P_RESULT := V_SUCCESS; --处理成功
        
    --更新主体
    UPDATE T_POL_EXT_RETAIL_TMP T
       SET T.ENTITY_ID = NVL((SELECT NVL(CL.CODE_VALUE, '0')
                               FROM V_UP_CODELIST CL
                              WHERE CL.CODETYPE = 'BD_ENTITY_ID'
                                AND CL.CODE_NAME = T.ENTITY_NAME),
                             0);
    UPDATE T_POL_EXT_RETAIL_TMP T
       SET T.ERROR_INFO = T.ERROR_INFO ||
                          DECODE(T.ERROR_INFO, NULL, NULL, '；') || '主体“' ||
                          T.ENTITY_NAME || '”不存在'
     WHERE T.ENTITY_ID IS NULL
        OR T.ENTITY_ID = 0;
       
    --更新中心ID，中心名称
    MERGE INTO T_POL_EXT_RETAIL_TMP MT
    USING (SELECT T.ID, U.UNIT_ID, U.NAME
             FROM UP_ORG_UNIT U, T_POL_EXT_RETAIL_TMP T
            WHERE U.ENTITY_ID = T.ENTITY_ID
              AND U.CODE = T.SALES_CENTER_CODE
              AND 'T' = U.IS_ENABLED) UT
    ON (UT.ID = MT.ID)
    WHEN MATCHED THEN
      UPDATE
         SET MT.SALES_CENTER_ID   = UT.UNIT_ID,
             MT.SALES_CENTER_NAME = UT.NAME;
    UPDATE T_POL_EXT_RETAIL_TMP T
       SET T.ERROR_INFO = T.ERROR_INFO ||
                          DECODE(T.ERROR_INFO, NULL, NULL, '；') || '中心编码“' ||
                          T.SALES_CENTER_CODE || '”' ||
                          DECODE(T.SALES_CENTER_NAME,
                                 NULL,
                                 NULL,
                                 '、“' || T.SALES_CENTER_NAME || '”') ||
                          '无效或不存在'
     WHERE (T.SALES_CENTER_ID IS NULL OR T.SALES_CENTER_ID = 0)
       AND T.SALES_CENTER_CODE IS NOT NULL
       AND T.ENTITY_ID > 0;
      
    --更新客户ID，客户名称，账户ID
    MERGE INTO T_POL_EXT_RETAIL_TMP MT
    USING (SELECT T.ID, V.CUSTOMER_ID, V.CUSTOMER_NAME, V.ACCOUNT_ID
             FROM V_CUSTOMER_ACCOUNT_SALECENTER V, T_POL_EXT_RETAIL_TMP T
            WHERE V.CUSTOMER_CODE = T.CUSTOMER_CODE
            AND V.SALES_CENTER_ID = T.SALES_CENTER_ID
            AND V.ACCOUNT_STATUS = 1
            AND V.ENTITY_ID = T.ENTITY_ID) UT
    ON (UT.ID = MT.ID)
    WHEN MATCHED THEN
      UPDATE
         SET MT.CUSTOMER_ID   = UT.CUSTOMER_ID,
             MT.CUSTOMER_NAME = UT.CUSTOMER_NAME,
             MT.ACCOUNT_ID = UT.ACCOUNT_ID;
    UPDATE T_POL_EXT_RETAIL_TMP T
       SET T.ERROR_INFO = T.ERROR_INFO ||
                          DECODE(T.ERROR_INFO, NULL, NULL, '；') || '客户编码“' ||
                          T.CUSTOMER_CODE || '”' ||
                          DECODE(T.CUSTOMER_NAME,
                                 NULL,
                                 NULL,
                                 '、“' || T.CUSTOMER_NAME || '”') || '无效或不存在或者关联的账户已失效'
     WHERE (T.CUSTOMER_ID IS NULL OR T.CUSTOMER_ID = 0)
       AND T.CUSTOMER_CODE IS NOT NULL;
         
    --更新客户分类
    MERGE INTO T_POL_EXT_RETAIL_TMP MT
    USING (SELECT T.ID, CL.CODE_VALUE
             FROM V_UP_CODELIST CL
            RIGHT JOIN T_POL_EXT_RETAIL_TMP T
               ON (CL.CODETYPE = 'pol_cust_classification' AND
                   CL.CODE_NAME = T.CUSTOMER_CLASSIFICATION AND
                   (CL.ENTITY_ID IS NULL OR CL.ENTITY_ID = T.ENTITY_ID))
          ) UT
    ON (UT.ID = MT.ID)
    WHEN MATCHED THEN
      UPDATE
         SET MT.CUSTOMER_CLASSIFICATION = NVL(UT.CODE_VALUE, MT.CUSTOMER_CLASSIFICATION),
             MT.ERROR_INFO              = MT.ERROR_INFO || (
                                          CASE
                                            WHEN UT.CODE_VALUE IS NOT NULL THEN
                                             NULL
                                            WHEN MT.CUSTOMER_CLASSIFICATION IS NULL THEN
                                              NULL
                                            ELSE
                                             DECODE(MT.ERROR_INFO, NULL, NULL, '；') || '客户分类“' ||
                                             MT.CUSTOMER_CLASSIFICATION || '”不存在'
                                          END);
      
    --更新产品类型
    MERGE INTO T_POL_EXT_RETAIL_TMP MT
    USING (SELECT T.ID, CL.CODE_VALUE
             FROM V_UP_CODELIST CL
            RIGHT JOIN T_POL_EXT_RETAIL_TMP T
               ON (CL.CODETYPE = 'pol_product_type' AND
                   CL.CODE_NAME = T.ITEM_TYPE AND
                   (CL.ENTITY_ID IS NULL OR CL.ENTITY_ID = T.ENTITY_ID))
          ) UT
    ON (UT.ID = MT.ID)
    WHEN MATCHED THEN
      UPDATE
         SET MT.ITEM_TYPE  = NVL(UT.CODE_VALUE, MT.ITEM_TYPE),
             MT.ERROR_INFO = MT.ERROR_INFO || (
                             CASE
                               WHEN UT.CODE_VALUE IS NOT NULL THEN
                                NULL
                               WHEN MT.ITEM_TYPE IS NULL THEN
                                NULL
                               ELSE
                                DECODE(MT.ERROR_INFO, NULL, NULL, '；') || '产品类型“' || MT.ITEM_TYPE ||
                                '”不存在'
                             END);
                             
    --更新数据来源
    MERGE INTO T_POL_EXT_RETAIL_TMP MT
    USING (SELECT T.ID, CL.CODE_VALUE
             FROM V_UP_CODELIST CL
            RIGHT JOIN T_POL_EXT_RETAIL_TMP T
               ON (CL.CODETYPE = 'pol_data_source_type' AND
                   CL.CODE_NAME = T.DATA_SOURCE_TYPE AND
                   (CL.ENTITY_ID IS NULL OR CL.ENTITY_ID = T.ENTITY_ID))
          ) UT
    ON (UT.ID = MT.ID)
    WHEN MATCHED THEN
      UPDATE
         SET MT.DATA_SOURCE_TYPE  = NVL(UT.CODE_VALUE, MT.DATA_SOURCE_TYPE),
             MT.ERROR_INFO = MT.ERROR_INFO || (
                             CASE
                               WHEN UT.CODE_VALUE IS NOT NULL THEN
                                NULL
                               ELSE
                                DECODE(MT.ERROR_INFO, NULL, NULL, '；') || '数据来源“' || MT.ITEM_TYPE ||
                                '”不存在'
                             END);
      
    --更新产品定位
    MERGE INTO T_POL_EXT_RETAIL_TMP MT
    USING (SELECT T.ID, CL.CODE_VALUE
             FROM V_UP_CODELIST CL
            RIGHT JOIN T_POL_EXT_RETAIL_TMP T
               ON (CL.CODETYPE = 'ITEM_PRODUCT_POSITION' AND
                   CL.CODE_NAME = T.ITEM_POSITIONING AND
                   (CL.ENTITY_ID IS NULL OR CL.ENTITY_ID = T.ENTITY_ID))
          ) UT
    ON (UT.ID = MT.ID)
    WHEN MATCHED THEN
      UPDATE
         SET MT.ITEM_POSITIONING = NVL(UT.CODE_VALUE, MT.ITEM_POSITIONING),
             MT.ERROR_INFO       = MT.ERROR_INFO || (
                                   CASE
                                     WHEN UT.CODE_VALUE IS NOT NULL THEN
                                      NULL
                                     WHEN MT.ITEM_POSITIONING IS NULL THEN
                                      NULL
                                     ELSE
                                      DECODE(MT.ERROR_INFO, NULL, NULL, '；') || '产品定位“' ||
                                      MT.ITEM_POSITIONING || '”不存在'
                                   END);
     
    --更新产品ID、产品名称、产品描述
    MERGE INTO T_POL_EXT_RETAIL_TMP MT
    USING (SELECT T.ID,
                  BI.ITEM_ID,
                  BI.ITEM_NAME,
                  BI.PRODUCTMODEL
             FROM T_BD_ITEM BI, T_POL_EXT_RETAIL_TMP T
            WHERE BI.ENTITY_ID = T.ENTITY_ID
              AND BI.ITEM_CODE = T.ITEM_CODE) UT
    ON (UT.ID = MT.ID)
    WHEN MATCHED THEN
      UPDATE
         SET MT.ITEM_ID    = UT.ITEM_ID,
             MT.ITEM_NAME  = UT.ITEM_NAME,
             MT.ITEM_MODEL = UT.PRODUCTMODEL;
    UPDATE T_POL_EXT_RETAIL_TMP T
       SET T.ERROR_INFO = T.ERROR_INFO ||
                          DECODE(T.ERROR_INFO, NULL, NULL, '；') || '产品编码“' ||
                          T.ITEM_CODE || '”' ||
                          DECODE(T.ITEM_MODEL,
                                 NULL,
                                 NULL,
                                 '、“' || T.ITEM_MODEL || '”') || '不存在'
     WHERE (T.ITEM_ID IS NULL OR T.ITEM_ID = 0)
       AND T.ITEM_CODE IS NOT NULL
       AND T.ENTITY_ID > 0;
       
    --更新门店名称
    MERGE INTO T_POL_EXT_RETAIL_TMP MT
    USING (SELECT T.ID, TM.TERMINAL_ID, TM.TERMINAL_NAME
             FROM T_PRO_TERMINAL TM, T_POL_EXT_RETAIL_TMP T
            WHERE TM.TERMINAL_CODE = T.TERMINAL_CODE) UT
    ON (UT.ID = MT.ID)
    WHEN MATCHED THEN
      UPDATE
         SET MT.TERMINAL_ID   = UT.TERMINAL_ID,
             MT.TERMINAL_NAME = UT.TERMINAL_NAME;
    UPDATE T_POL_EXT_RETAIL_TMP T
       SET T.ERROR_INFO = T.ERROR_INFO ||
                          DECODE(T.ERROR_INFO, NULL, NULL, '；') || '门店编码“' ||
                          T.TERMINAL_CODE || '”' ||
                          DECODE(T.TERMINAL_NAME,
                                 NULL,
                                 NULL,
                                 '、“' || T.TERMINAL_NAME || '”') || '不存在'
     WHERE (T.TERMINAL_ID IS NULL OR T.TERMINAL_ID = 0)
       AND T.TERMINAL_CODE IS NOT NULL; --输入的门店CODE可为空，但是不为空的时候需要如上验证
         
    --初始化校验不通过的字段，这些字段都是必填字段
    UPDATE T_POL_EXT_RETAIL_TMP T
       SET T.ENTITY_ID = 0
     WHERE T.ENTITY_ID IS NULL
        OR 0 > T.ENTITY_ID;
          
    UPDATE T_POL_EXT_RETAIL_TMP T
       SET T.SALES_CENTER_ID = 0
     WHERE T.ENTITY_ID IS NULL
        OR 0 > T.SALES_CENTER_ID;
          
    UPDATE T_POL_EXT_RETAIL_TMP T
       SET T.CUSTOMER_ID = 0
     WHERE T.CUSTOMER_ID IS NULL
        OR 0 > T.CUSTOMER_ID;
      
    UPDATE T_POL_EXT_RETAIL_TMP T
       SET T.ITEM_ID = 0
     WHERE 0 > T.ITEM_ID;
       
    UPDATE T_POL_EXT_RETAIL_TMP T
       SET T.ROW_FLAG = 'N'
     WHERE T.ERROR_INFO IS NOT NULL;
       
    --唯一性验证
    MERGE INTO T_POL_EXT_RETAIL_TMP MT
    USING (SELECT DISTINCT RT.ID
             FROM T_POL_EXT_RETAIL R,T_POL_EXT_RETAIL_TMP RT
             WHERE 1 = 1
                AND R.ITEM_ID = RT.ITEM_ID
                AND R.RETAIL_DATE = RT.RETAIL_DATE
                AND R.CUSTOMER_ID = RT.CUSTOMER_ID
                AND R.SALES_CENTER_ID = RT.SALES_CENTER_ID
                AND R.DATA_SOURCE_TYPE = RT.DATA_SOURCE_TYPE
                AND R.ENTITY_ID = RT.ENTITY_ID
                AND ((RT.TERMINAL_ID IS NOT NULL AND R.TERMINAL_ID = RT.TERMINAL_ID) OR
                    (RT.TERMINAL_ID IS NULL))
                AND ((RT.ITEM_TYPE IS NOT NULL AND R.ITEM_TYPE = RT.ITEM_TYPE) OR
                    (RT.ITEM_TYPE IS NULL))
                AND RT.ROW_FLAG IS NULL              
          ) UT
    ON (UT.ID = MT.ID)
    WHEN MATCHED THEN
      UPDATE
         SET MT.ERROR_INFO = MT.ERROR_INFO ||
                             DECODE(MT.ERROR_INFO, NULL, NULL, '；') ||
                             '数据库中存在重复数据：中心编码、客户编码、（门店编码、产品类型）、数据来源类型、产品编码、日期的组合不能重复；',
             MT.ROW_FLAG = 'N';

    --没有错误的校验，返回成功
    SELECT NVL('' || (SELECT SUM(1)
                        FROM T_POL_EXT_RETAIL_TMP T
                       WHERE T.ROW_FLAG = 'N'),
               'SUCCESS')
      INTO P_RESULT
      FROM DUAL;
    
    --如果所有的验证的都通过，则将临时表中的数据全部保存到正式表中
    IF P_RESULT = V_SUCCESS THEN
      V_VALUE := '开始向正式表插入数据';
      BEGIN
        INSERT INTO CIMS.T_POL_EXT_RETAIL 
          (RETAIL_ID,  ---- NUMBER NOT NULL ENABLE, 
           ENTITY_ID,  ---- NUMBER, 
           CUSTOMER_ID,  ---- NUMBER, 
           CUSTOMER_CODE,  ---- VARCHAR2(100), 
           CUSTOMER_NAME,  ---- VARCHAR2(300), 
           CUSTOMER_CLASSIFICATION,  ---- VARCHAR2(32), 
           SALES_CENTER_ID,  ---- NUMBER, 
           SALES_CENTER_CODE,  ---- VARCHAR2(100), 
           SALES_CENTER_NAME,  ---- VARCHAR2(100), 
           TERMINAL_ID,  ---- NUMBER, 
           TERMINAL_CODE,  ---- VARCHAR2(100), 
           TERMINAL_NAME,  ---- VARCHAR2(500), 
           ITEM_TYPE,  ---- VARCHAR2(40), 
           DATA_SOURCE_TYPE,  ---- VARCHAR2(32), 
           ITEM_ID,  ---- NUMBER, 
           ITEM_CODE,  ---- VARCHAR2(100), 
           ITEM_NAME,  ---- VARCHAR2(240), 
           ITEM_MODEL,  ---- VARCHAR2(500), 
           ITEM_POSITIONING,  ---- VARCHAR2(500), 
           RETAIL_DATE,  ---- DATE, 
           SALES_QTY,  ---- NUMBER, 
           REMARK,  ---- VARCHAR2(500), 
           CREATED_BY,  ---- VARCHAR2(32), 
           CREATION_DATE,  ---- DATE, 
           LAST_UPDATED_BY,  ---- VARCHAR2(32), 
           LAST_UPDATE_DATE,  ---- DATE, 
           VERSION_NUM,  ---- NUMBER, 
           ACCOUNT_ID,  ---- NUMBER, 
           IMPORT_DATE,  ---- DATE, 
           IMPORT_BATCH_CODE,  ---- VARCHAR2(32), 
           SYSTEM_SOURCE,    ---- VARCHAR2(32), 
           ITEM_UINT_PRICE,  ---- NUMBER, 
           ITEM_RETAIL_PRICE  ---- NUMBER
          )SELECT 
              S_POL_EXT_RETAIL.NEXTVAL,
              ENTITY_ID,  ---- NUMBER, 
              CUSTOMER_ID,  ---- NUMBER, 
              CUSTOMER_CODE,  ---- VARCHAR2(100), 
              CUSTOMER_NAME,  ---- VARCHAR2(300), 
              CUSTOMER_CLASSIFICATION,  ---- VARCHAR2(32), 
              SALES_CENTER_ID,  ---- NUMBER, 
              SALES_CENTER_CODE,  ---- VARCHAR2(100), 
              SALES_CENTER_NAME,  ---- VARCHAR2(100), 
              TERMINAL_ID,  ---- NUMBER, 
              TERMINAL_CODE,  ---- VARCHAR2(100), 
              TERMINAL_NAME,  ---- VARCHAR2(500), 
              ITEM_TYPE,  ---- VARCHAR2(40), 
              DATA_SOURCE_TYPE,  ---- VARCHAR2(32), 
              ITEM_ID,  ---- NUMBER, 
              ITEM_CODE,  ---- VARCHAR2(100), 
              ITEM_NAME,  ---- VARCHAR2(240), 
              ITEM_MODEL,  ---- VARCHAR2(500), 
              ITEM_POSITIONING,  ---- VARCHAR2(500), 
              RETAIL_DATE,  ---- DATE, 
              SALES_QTY,  ---- NUMBER, 
              REMARK,  ---- VARCHAR2(500), 
              CREATED_BY,  ---- VARCHAR2(32), 
              CREATION_DATE,  ---- DATE, 
              LAST_UPDATED_BY,  ---- VARCHAR2(32), 
              LAST_UPDATE_DATE,  ---- DATE, 
              0,                ---- VERSION_NUM  NUMBER, 
              ACCOUNT_ID,  ---- NUMBER, 
              IMPORT_DATE,  ---- DATE, 
              IMPORT_BATCH_CODE,  ---- VARCHAR2(32), 
              SYSTEM_SOURCE,  ---- VARCHAR2(32), 
              ITEM_UINT_PRICE,  ---- NUMBER, 
              ITEM_RETAIL_PRICE  ---- NUMBER
           FROM T_POL_EXT_RETAIL_TMP;
      EXCEPTION
        WHEN OTHERS THEN
          P_RESULT := V_VALUE || '失败。' || V_NL || SQLERRM; 
      END;
    END IF;    
  EXCEPTION  --抓取整个范围的异常
    WHEN OTHERS THEN
      P_RESULT := '失败：' || P_RESULT || V_NL || SQLERRM;
  END; 
  
  ----------------------------------------------------------------------
  -- Author  : zhouly2
  -- Created : 2018/07/14 11:30:40
  -- Purpose : 划拨行明细导入检查
  ----------------------------------------------------------------------
  PROCEDURE P_CHECK_TRANSFER_LINES_IMPORT(P_HEADER_ID   IN NUMBER,
                                          P_TYPE        IN VARCHAR2,
                                          P_USER_CODE IN VARCHAR2,
                                          P_RESULT_CODE OUT VARCHAR2,
                                          P_RESULT_MSG  OUT VARCHAR2) IS
    V_RESULT_CODE       VARCHAR2(10);
    V_ERROR_COUNT       NUMBER; --错误数
    V_COUNT1            NUMBER;
    V_COUNT2            NUMBER;
    V_SO_NUM1           VARCHAR2(4000);
    V_SO_NUM2           VARCHAR2(4000);
    V_CHECK_CENTER_FLAG VARCHAR2(10) := 'N';
     
    CURSOR CUR_HEADER_CHECK IS
      SELECT A.ENTITY_VALUE
        FROM T_BD_PARAM_ENTITY    A,
             T_BD_PARAM_LIST      B,
             T_SO_TRANSFER_HEADER HEAD
       WHERE A.ENTITY_ID = HEAD.ENTITY_ID
         AND A.PARAM_LIST_ID = B.PARAM_LIST_ID
         AND B.PARAM_CODE = 'so_transfer_header_check_center'
         AND HEAD.TRANSFER_HEADER_ID = P_HEADER_ID
         AND ROWNUM = 1;
    --查找渠道类型
    CURSOR CUR_CHANNEL_TYPE(C_ITEM_CODE VARCHAR2) IS
      SELECT B.CHANNEL_TYPE
        FROM T_BD_ITEM ITEM
       INNER JOIN T_PG_PRODUCT_LINE_DETAIL A
          ON ITEM.SALES_MAIN_TYPE = A.SALES_MAIN_TYPE_CODE
         AND ITEM.SALES_SUB_TYPE = A.SALES_SUB_TYPE_CODE
        LEFT JOIN T_PG_PRODUCT_LINE B
          ON A.PRODUCTLINE_ID = B.PRODUCTLINE_ID
       WHERE ITEM.ITEM_CODE = C_ITEM_CODE;
  BEGIN
    P_RESULT_CODE := 'Y';
    P_RESULT_MSG  := '';
    V_ERROR_COUNT := 0;
    --查询系统参数是否要校验送货中心与所填一致
    OPEN CUR_HEADER_CHECK;
    FETCH CUR_HEADER_CHECK
      INTO V_CHECK_CENTER_FLAG;
    CLOSE CUR_HEADER_CHECK;
    --校验必填字段
    --查询是否有这个单
  
    IF V_CHECK_CENTER_FLAG = '' THEN
      P_RESULT_MSG := '未找到是否检查中心的系统参数';
    END IF;
  
    --将销售单的数据更新过来
    IF P_TYPE = '0' THEN
     MERGE INTO T_SO_TRANSFER_LINE_TMP TMP
     USING (SELECT T.SO_HEADER_ID,
                   T.SO_NUM,
                   t.so_date,
                   T.SALES_CENTER_ID,
                   T.SALES_CENTER_CODE,
                   T.SALES_CENTER_NAME,
                   T.CUSTOMER_ID,
                   T.CUSTOMER_CODE,
                   T.CUSTOMER_NAME,
                   T.ENTITY_ID,
                   T.BELONG_TO_RATE,
                   T.BILL_TYPE_ID,
                   T.SETTLE_AMOUNT
              FROM T_SO_HEADER T
            
            ) SO
     --TSOTRANSFERLINESOTYPE可划拨的单据类型
     ON (SO.SO_NUM = TMP.SO_NUM AND TMP.ENTITY_ID = SO.ENTITY_ID
     -- AND SO.BELONG_TO_RATE IS NULL 
     AND SO.BILL_TYPE_ID IN (SELECT A.CODE_VALUE
                               FROM V_UP_CODELIST A
                              WHERE A.CODETYPE = 'tSoTransferLineSoType'
                                AND A.ENTITY_ID = TMP.ENTITY_ID))
     WHEN MATCHED THEN
       UPDATE
          SET TMP.SO_HEADER_ID      = SO.SO_HEADER_ID,
              TMP.So_Date      = SO.so_date,
              TMP.SALES_CENTER_ID   = SO.SALES_CENTER_ID,
              TMP.SALES_CENTER_CODE = SO.SALES_CENTER_CODE,
              TMP.SALES_CENTER_NAME = SO.SALES_CENTER_NAME,
              TMP.BELONG_TO_PRICE  =
              (TMP.BELONG_TO_RATE * TMP.ITEM_BUYOUT_PRICE / 100);
     --更新错误行
     UPDATE T_SO_TRANSFER_LINE_TMP A
        SET A.ERROR = '无法找到对应的销售单:' || A.SO_NUM || '；'
      WHERE A.SALES_CENTER_ID IS NULL
        AND A.TRANSFER_HEADER_ID = P_HEADER_ID;
     --检查划拨权限
     UPDATE T_SO_TRANSFER_LINE_TMP LINE
        SET LINE.ERROR = LINE.ERROR || '您没有权限划拨此销售单;'
      WHERE LINE.SO_NUM NOT IN
            (SELECT DISTINCT TMP.SO_NUM
               FROM T_SO_HEADER H, T_PG_AREA_ORG ORG, T_SO_TRANSFER_LINE_TMP TMP,T_SO_TRANSFER_HEADER HEAD
              WHERE 1 = 1
                AND ORG.ENTITY_ID = H.ENTITY_ID
                AND ORG.DISTRICT_CODE = H.CONSIGNEE_CITY_CODE
                AND ORG.ORG_CODE = HEAD.BELONG_TO_CENTER_CODE
                AND TMP.TRANSFER_HEADER_ID = HEAD.TRANSFER_HEADER_ID
                AND TMP.SO_NUM = H.SO_NUM
                AND EXISTS (SELECT 1
                       FROM V_BD_USER_ORG_PRIV V
                      WHERE V.USER_CODE = P_USER_CODE
                        AND( V.UNIT_CODE = ORG.ORG_CODE or v.UNIT_CODE=h.sales_center_code)--从别人那里划，自己划给别人
                        AND V.ENTITY_ID = H.ENTITY_ID));
      --检查重复
       UPDATE T_SO_TRANSFER_LINE_TMP LINE
         SET LINE.ERROR =  LINE.ERROR||'销售单号+产品编码重复;'
       WHERE LINE.ITEM_CODE || LINE.SO_NUM IN
             (SELECT A.ITEM_CODE || A.SO_NUM
                FROM T_SO_TRANSFER_LINE_TMP A
               WHERE A.ITEM_CODE IS NOT NULL   
               GROUP BY A.ITEM_CODE, A.SO_NUM
              HAVING COUNT(1) > 1);
       --检查同一张单的一致性
        UPDATE T_SO_TRANSFER_LINE_TMP LINE
         SET LINE.ERROR =LINE.ERROR|| '同一张单的划拨比例，划入中心，划入客户必须一致;'
       WHERE  LINE.SO_NUM IN
        (SELECT X.SO_NUM FROM 
            (SELECT  M.SO_NUM FROM (
              SELECT A.SO_NUM,
                     A.BELONG_TO_CENTER_CODE,
                     A.BELONG_TO_CUSTOMER_CODE,
                     A.BELONG_TO_RATE
                FROM T_SO_TRANSFER_LINE A
               WHERE A.TRANSFER_HEADER_ID = P_HEADER_ID
                AND (A.SO_NUM,A.ITEM_CODE,A.TRANSFER_HEADER_ID) NOT IN
                     (SELECT TMP.SO_NUM,TMP.ITEM_CODE,TMP.TRANSFER_HEADER_ID FROM T_SO_TRANSFER_LINE_TMP TMP)
              UNION
              SELECT LINE.SO_NUM,
                     LINE.BELONG_TO_CENTER_CODE,
                     LINE.BELONG_TO_CUSTOMER_CODE,
                     LINE.BELONG_TO_RATE
                FROM T_SO_TRANSFER_LINE_TMP LINE) M
               GROUP BY M.SO_NUM,
                        M.BELONG_TO_CENTER_CODE,
                        M.BELONG_TO_CUSTOMER_CODE,
                        M.BELONG_TO_RATE)X GROUP BY X.SO_NUM HAVING COUNT(1) > 1) ;     
      --检查是否是自主划拨
      UPDATE T_SO_TRANSFER_LINE_TMP LINE SET LINE.ADD_TYPE = '2';
      --自主划拨的设置为1
      UPDATE T_SO_TRANSFER_LINE_TMP LINE
         SET LINE.ADD_TYPE = '1'
       WHERE LINE.TRANSFER_LINE_ID IN
             (SELECT LINE.TRANSFER_LINE_ID
                FROM T_SO_TRANSFER_LINE_TMP LINE, T_SO_TRANSFER_HEADER HEAD
               WHERE LINE.TRANSFER_HEADER_ID = HEAD.TRANSFER_HEADER_ID
                 AND HEAD.BELONG_TO_CENTER_CODE = LINE.SALES_CENTER_CODE);
      --检查是否正在划拨
      MERGE INTO T_SO_TRANSFER_LINE_TMP TMP
      USING (SELECT distinct A.SO_NUM, HEAD.TRANSFER_CODE
               FROM T_SO_TRANSFER_LINE A
               LEFT JOIN T_SO_TRANSFER_HEADER HEAD
                 ON HEAD.TRANSFER_HEADER_ID = A.TRANSFER_HEADER_ID
              WHERE HEAD.STATUS IN ('0', '1' ) -- 已送审 --可重复划拨
                AND HEAD.TRANSFER_TYPE = '0') SO
      ON (SO.SO_NUM = TMP.SO_NUM AND TMP.SO_NUM NOT IN (SELECT SO_NUM
                                                          FROM T_SO_TRANSFER_LINE A
                                                         WHERE A.TRANSFER_HEADER_ID =
                                                               TMP.TRANSFER_HEADER_ID))--之前已经存了的不校验
      WHEN MATCHED THEN
        UPDATE
           SET TMP.ERROR = '此销售单已存在于划拨单:' || SO.TRANSFER_CODE || '中；';
       --检查产品是否划全
           FOR I IN (SELECT DISTINCT  TMP.SO_NUM FROM T_SO_TRANSFER_LINE_TMP TMP) LOOP
            SELECT COUNT(1)    ,TO_CHAR(WMSYS.WM_CONCAT(LINE.ITEM_CODE)  ) INTO V_COUNT1, V_SO_NUM1
             FROM T_SO_HEADER            HEAD,
                  T_SO_LINE              LINE      
            WHERE HEAD.SO_HEADER_ID = LINE.SO_HEADER_ID AND HEAD.SO_NUM=I.SO_NUM   ;
         SELECT COUNT(1), TO_CHAR(WMSYS.WM_CONCAT(M.ITEM_CODE)  )    INTO V_COUNT2, V_SO_NUM2
           FROM (SELECT TMP.ITEM_CODE
                   FROM T_SO_TRANSFER_LINE_TMP TMP
                  WHERE TMP.SO_NUM = I.SO_NUM
                 UNION
                 SELECT LINE.ITEM_CODE
                   FROM T_SO_TRANSFER_LINE LINE
                  WHERE LINE.SO_NUM =  I.SO_NUM
                    AND LINE.TRANSFER_HEADER_ID = P_HEADER_ID) M ;
            IF V_COUNT2<>V_COUNT1   THEN
              UPDATE T_SO_TRANSFER_LINE_TMP TMP SET TMP.ERROR=TMP.ERROR||'分部间划拨的销售单必须所有型号一起保存，销售单产品编码有：'||V_SO_NUM1||',保存的有：'||V_SO_NUM2
              WHERE TMP.SO_NUM=I.SO_NUM
              AND TMP.ERROR IS NULL
              ;
            END IF;
           END LOOP;    
           
      --分部间划拨 
      --查询划拨中心与送货地址中心是否匹配
      IF V_CHECK_CENTER_FLAG = 'Y' THEN
        MERGE INTO T_SO_TRANSFER_LINE_TMP TMP
        USING (SELECT T.SO_HEADER_ID,
                      T.SO_NUM,
                      T.SALES_CENTER_ID,
                      T.SALES_CENTER_CODE,
                      T.SALES_CENTER_NAME,
                      T.CUSTOMER_ID,
                      T.CUSTOMER_CODE,
                      T.CUSTOMER_NAME,
                      T.ENTITY_ID,
                      ORG.ORG_CODE, --送货地址中心   
                      ORG.ORG_NAME,
                      ORG.UNIT_ID    
                 FROM T_SO_HEADER T
                 LEFT JOIN T_PG_AREA_ORG ORG
                   ON ORG.DISTRICT_CODE = T.CONSIGNEE_CITY_CODE
                  AND ORG.ENTITY_ID = T.ENTITY_ID
                WHERE ORG.ORG_CODE <> T.SALES_CENTER_CODE --必须两个中心不一致
               ) SO
        ON (TMP.ENTITY_ID = SO.ENTITY_ID AND SO.SO_NUM = TMP.SO_NUM 
        AND  SO.ORG_CODE = TMP.BELONG_TO_CENTER_CODE    AND TMP.SALES_CENTER_ID IS NOT NULL  AND TMP.ADD_TYPE='2'
        )
        WHEN MATCHED THEN
          UPDATE
             SET TMP.CUSTOMER_CODE = SO.CUSTOMER_CODE,
                 TMP.CUSTOMER_NAME = SO.CUSTOMER_NAME,
                 TMP.CUSTOMER_ID   = SO.CUSTOMER_ID,
                 TMP.BELONG_TO_CENTER_NAME = SO.ORG_NAME,
                 TMP.BELONG_TO_CENTER_ID = SO.UNIT_ID
                 ;  
        --自主模式
         MERGE INTO T_SO_TRANSFER_LINE_TMP TMP
        USING (SELECT T.SO_HEADER_ID,
                      T.SO_NUM,
                      T.SALES_CENTER_ID,
                      T.SALES_CENTER_CODE,
                      T.SALES_CENTER_NAME,
                      T.CUSTOMER_ID,
                      T.CUSTOMER_CODE,
                      T.CUSTOMER_NAME,
                      T.ENTITY_ID,
                      ORG.ORG_CODE, --送货地址中心   
                      ORG.ORG_NAME,
                      ORG.UNIT_ID        
                 FROM T_SO_HEADER T
                 LEFT JOIN T_PG_AREA_ORG ORG
                   ON ORG.DISTRICT_CODE = T.CONSIGNEE_CITY_CODE
                  AND ORG.ENTITY_ID = T.ENTITY_ID
                WHERE ORG.ORG_CODE = T.SALES_CENTER_CODE  --本中心的单据
               ) SO
        ON (TMP.ENTITY_ID = SO.ENTITY_ID AND SO.SO_NUM = TMP.SO_NUM 
        AND  SO.ORG_CODE = TMP.SALES_CENTER_CODE  AND TMP.SALES_CENTER_ID IS NOT NULL  AND TMP.ADD_TYPE='1'
        )
        WHEN MATCHED THEN
          UPDATE
             SET TMP.CUSTOMER_CODE = SO.CUSTOMER_CODE,
                 TMP.CUSTOMER_NAME = SO.CUSTOMER_NAME,
                 TMP.CUSTOMER_ID   = SO.CUSTOMER_ID;  
          --更新错误行
      UPDATE T_SO_TRANSFER_LINE_TMP A
         SET A.ERROR = A.ERROR || '送货地址中心与划拨中心不匹配;'
       WHERE A.CUSTOMER_ID IS NULL
         AND A.ADD_TYPE = '2'
         AND A.TRANSFER_HEADER_ID = P_HEADER_ID;
      UPDATE T_SO_TRANSFER_LINE_TMP A
         SET A.ERROR = A.ERROR || '找不到本中心的销售单;'
       WHERE A.CUSTOMER_ID IS NULL
         AND A.ADD_TYPE = '1'
         AND A.TRANSFER_HEADER_ID = P_HEADER_ID;
      ELSE
      
        --不用校验中心
        MERGE INTO T_SO_TRANSFER_LINE_TMP TMP
        USING (SELECT T.SO_HEADER_ID,
                      T.SO_NUM,
                      T.SALES_CENTER_ID,
                      T.SALES_CENTER_CODE,
                      T.SALES_CENTER_NAME,
                      T.CUSTOMER_ID,
                      T.CUSTOMER_CODE,
                      T.CUSTOMER_NAME,
                      T.ENTITY_ID
                 FROM T_SO_HEADER T) SO
        ON (TMP.ENTITY_ID = SO.ENTITY_ID AND SO.SO_NUM = TMP.SO_NUM AND TMP.SALES_CENTER_ID IS NOT NULL)
        WHEN MATCHED THEN
          UPDATE
             SET TMP.CUSTOMER_CODE = SO.CUSTOMER_CODE,
                 TMP.CUSTOMER_NAME = SO.CUSTOMER_NAME,
                 TMP.CUSTOMER_ID   = SO.CUSTOMER_ID;
          --更新错误行
      UPDATE T_SO_TRANSFER_LINE_TMP A
         SET A.ERROR = A.ERROR || '找不到销售单;'
       WHERE A.CUSTOMER_ID IS NULL
         AND A.TRANSFER_HEADER_ID = P_HEADER_ID;        
      END IF;
       --更新自主划拨中心信息
     MERGE INTO T_SO_TRANSFER_LINE_TMP TMP
     USING (SELECT DISTINCT T.SALES_CENTER_ID , 
                            T.SALES_CENTER_NAME,
                            T.ENTITY_ID,
                            T.SALES_CENTER_CODE
              FROM V_CUSTOMER_ACCOUNT_SALECENTER T) CUS
     ON ( TMP.ADD_TYPE='1' AND TMP.ENTITY_ID = CUS.ENTITY_ID AND CUS.SALES_CENTER_CODE = TMP.BELONG_TO_CENTER_CODE)
     WHEN MATCHED THEN
       UPDATE
          SET TMP.BELONG_TO_CENTER_NAME = CUS.SALES_CENTER_NAME,
              TMP.BELONG_TO_CENTER_ID   = CUS.SALES_CENTER_ID;
     --更新错误行
     UPDATE T_SO_TRANSFER_LINE_TMP A
        SET A.ERROR = A.ERROR || '无法找到对应的划拨中心;'
      WHERE A.BELONG_TO_CENTER_ID IS NULL
        AND A.ADD_TYPE='1'
        AND A.TRANSFER_HEADER_ID = P_HEADER_ID;	  
       
	     --更新划拨客户信息
     MERGE INTO T_SO_TRANSFER_LINE_TMP TMP
     USING (SELECT DISTINCT T.CUSTOMER_ID,
                            T.CUSTOMER_CODE,
                            T.CUSTOMER_NAME,
                            T.ENTITY_ID,
                            T.SALES_CENTER_CODE
              FROM V_CUSTOMER_ACCOUNT_SALECENTER T) CUS
     ON (TMP.BELONG_TO_CUSTOMER_CODE IS NOT NULL AND TMP.ENTITY_ID = CUS.ENTITY_ID AND CUS.CUSTOMER_CODE = TMP.BELONG_TO_CUSTOMER_CODE AND CUS.SALES_CENTER_CODE = TMP.BELONG_TO_CENTER_CODE)
     WHEN MATCHED THEN
       UPDATE
          SET TMP.BELONG_TO_CUSTOMER_NAME = CUS.CUSTOMER_NAME,
              TMP.BELONG_TO_CUSTOMER_ID   = CUS.CUSTOMER_ID;
     --更新错误行
     UPDATE T_SO_TRANSFER_LINE_TMP A
        SET A.ERROR = A.ERROR || '无法找到对应的划拨客户;'
      WHERE A.BELONG_TO_CUSTOMER_ID IS NULL
        AND A.BELONG_TO_CUSTOMER_CODE IS NOT NULL
        AND A.TRANSFER_HEADER_ID = P_HEADER_ID;	
     --更新产品信息
      MERGE INTO T_SO_TRANSFER_LINE_TMP TMP
      USING (SELECT T.SO_HEADER_ID,
                    T.SO_NUM,
                    T.SALES_CENTER_ID,
                    T.SALES_CENTER_CODE,
                    T.SALES_CENTER_NAME,
                    T.ENTITY_ID,
                    LINE.SO_LINE_ID,
                    LINE.ITEM_ID,
                    LINE.ITEM_CODE,
                    LINE.ITEM_NAME,
                    LINE.ITEM_QTY,
                    ITEM.CHANNEL_TYPE
               FROM T_SO_LINE LINE
               LEFT JOIN T_BD_ITEM ITEM
                 ON LINE.ITEM_CODE = ITEM.ITEM_CODE
                AND ITEM.ENTITY_ID = LINE.ENTITY_ID
               LEFT JOIN T_SO_HEADER T
                 ON T.SO_HEADER_ID = LINE.SO_HEADER_ID
               LEFT JOIN T_PG_AREA_ORG ORG
                 ON ORG.DISTRICT_CODE = T.CONSIGNEE_CITY_CODE
                AND ORG.ENTITY_ID = T.ENTITY_ID) SO
      ON (TMP.ENTITY_ID = SO.ENTITY_ID AND SO.SO_NUM = TMP.SO_NUM AND SO.ITEM_CODE = TMP.ITEM_CODE AND SO.SALES_CENTER_CODE = TMP.SALES_CENTER_CODE AND TMP.SO_HEADER_ID IS NOT NULL)
      WHEN MATCHED THEN
        UPDATE
           SET TMP.SO_LINE_ID        = SO.SO_LINE_ID, 
               TMP.ITEM_ID           = SO.ITEM_ID,
               TMP.ITEM_NAME         = SO.ITEM_NAME,
               TMP.ITEM_QTY          = SO.ITEM_QTY; 
      UPDATE T_SO_TRANSFER_LINE_TMP A
         SET A.ERROR = A.ERROR || '无法找到对应的产品编码:' || A.ITEM_CODE
       WHERE A.ITEM_ID IS NULL
         AND A.TRANSFER_HEADER_ID = P_HEADER_ID;   
    ELSIF P_TYPE = '1' THEN
      --自己划拨自己的单据
      MERGE INTO T_SO_TRANSFER_LINE_TMP TMP
      USING (SELECT T.SO_HEADER_ID,
                    T.SO_NUM,
                    t.so_date,
                    T.SALES_CENTER_ID,
                    T.SALES_CENTER_CODE,
                    T.SALES_CENTER_NAME,
                    T.CUSTOMER_ID,
                    T.CUSTOMER_CODE,
                    T.CUSTOMER_NAME,
                    T.ENTITY_ID,
                    T.BELONG_TO_CENTER_CODE
               FROM T_SO_HEADER T) SO
      ON (SO.SO_NUM = TMP.SO_NUM AND TMP.ENTITY_ID = SO.ENTITY_ID AND TMP.SALES_CENTER_CODE = SO.SALES_CENTER_CODE)
      WHEN MATCHED THEN
        UPDATE
           SET TMP.SO_HEADER_ID      = SO.SO_HEADER_ID,
               tmp.so_date=so.so_date,
               TMP.SALES_CENTER_ID   = SO.SALES_CENTER_ID,
               TMP.SALES_CENTER_NAME = SO.SALES_CENTER_NAME;
       --划入中心划拨别人的单据        
      MERGE INTO T_SO_TRANSFER_LINE_TMP TMP
      USING (SELECT T.SO_HEADER_ID,
                    T.SO_NUM,
                    T.SALES_CENTER_ID,
                    T.SALES_CENTER_CODE,
                    T.SALES_CENTER_NAME,
                    T.CUSTOMER_ID,
                    T.CUSTOMER_CODE,
                    T.CUSTOMER_NAME,
                    T.ENTITY_ID,
                    T.BELONG_TO_CENTER_CODE,
                    T.BELONG_TO_CENTER_NAME,
                    T.BELONG_TO_CENTER_ID
               FROM T_SO_HEADER T) SO
      ON (SO.SO_NUM = TMP.SO_NUM AND TMP.ENTITY_ID = SO.ENTITY_ID AND (TMP.SALES_CENTER_CODE = SO.BELONG_TO_CENTER_CODE))
      WHEN MATCHED THEN
        UPDATE
           SET TMP.SO_HEADER_ID          = SO.SO_HEADER_ID,
               TMP.SALES_CENTER_ID       = SO.SALES_CENTER_ID,
               --TMP.SALES_CENTER_CODE   = SO.SALES_CENTER_CODE,
               TMP.SALES_CENTER_NAME     = SO.SALES_CENTER_NAME,
               TMP.BELONG_TO_CENTER_ID   = SO.BELONG_TO_CENTER_ID,
               TMP.BELONG_TO_CENTER_CODE = SO.BELONG_TO_CENTER_CODE,
               TMP.BELONG_TO_CENTER_NAME = SO.BELONG_TO_CENTER_NAME;
      --更新中心编码
      UPDATE T_SO_TRANSFER_LINE_TMP A
         SET A.SALES_CENTER_CODE =
             (SELECT SO.SALES_CENTER_CODE
                FROM T_SO_HEADER SO
               WHERE SO.SO_HEADER_ID = A.SO_HEADER_ID) WHERE A.SO_HEADER_ID IS NOT NULL;
      --更新错误行
      UPDATE T_SO_TRANSFER_LINE_TMP A
         SET A.ERROR = '无法找到对应的销售单:' || A.SO_NUM || '，中心编码：' ||
                       A.SALES_CENTER_CODE || ';'
       WHERE A.SALES_CENTER_ID IS NULL
         AND A.TRANSFER_HEADER_ID = P_HEADER_ID;
      --检查调整类型，更新类型为码表值
      UPDATE T_SO_TRANSFER_LINE_TMP TMP
         SET TMP.ERROR = '调整后渠道类型不存在;'
       WHERE TMP.TRANSFER_CHANNEL_TYPE NOT IN
             (SELECT A.CODE_NAME
                FROM UP_CODELIST A
               WHERE A.CODETYPE = 'CHANNEL_TYPE'
              UNION ALL
              SELECT A.CODE_VALUE
                FROM UP_CODELIST A
               WHERE A.CODETYPE = 'CHANNEL_TYPE');
      --检查重复
      UPDATE T_SO_TRANSFER_LINE_TMP LINE
         SET LINE.ERROR = '销售单号+产品编码重复;'
       WHERE LINE.ITEM_CODE || LINE.SO_NUM IN
             (SELECT A.ITEM_CODE || A.SO_NUM
                FROM T_SO_TRANSFER_LINE_TMP A
               WHERE A.ITEM_CODE IS NOT NULL
              
               GROUP BY A.ITEM_CODE, A.SO_NUM
              HAVING COUNT(1) > 1);
    
      UPDATE T_SO_TRANSFER_LINE_TMP TMP
         SET TMP.TRANSFER_CHANNEL_TYPE =
             (SELECT A.CODE_VALUE
                FROM UP_CODELIST A
               WHERE A.CODETYPE = 'CHANNEL_TYPE'
                 AND A.CODE_NAME = TMP.TRANSFER_CHANNEL_TYPE)
       WHERE TMP.TRANSFER_CHANNEL_TYPE IN
             (SELECT A.CODE_NAME
                FROM UP_CODELIST A
               WHERE A.CODETYPE = 'CHANNEL_TYPE');
      --渠道划拨--待添加产品原渠道类型
      MERGE INTO T_SO_TRANSFER_LINE_TMP TMP
      USING (SELECT T.SO_HEADER_ID,
                    T.SO_NUM,
                    T.SALES_CENTER_ID,
                    T.SALES_CENTER_CODE,
                    T.SALES_CENTER_NAME,
                    T.CUSTOMER_ID,
                    T.CUSTOMER_CODE,
                    T.CUSTOMER_NAME,
                    T.BELONG_TO_CENTER_CODE,
                    T.ENTITY_ID,
                    LINE.SO_LINE_ID,
                    LINE.ITEM_ID,
                    LINE.ITEM_CODE,
                    LINE.ITEM_NAME,
                    LINE.ITEM_QTY,
                    ITEM.CHANNEL_TYPE
               FROM T_SO_LINE LINE
               LEFT JOIN T_BD_ITEM ITEM
                 ON LINE.ITEM_CODE = ITEM.ITEM_CODE
                AND ITEM.ENTITY_ID = LINE.ENTITY_ID
               LEFT JOIN T_SO_HEADER T
                 ON T.SO_HEADER_ID = LINE.SO_HEADER_ID
               LEFT JOIN T_PG_AREA_ORG ORG
                 ON ORG.DISTRICT_CODE = T.CONSIGNEE_CITY_CODE
                AND ORG.ENTITY_ID = T.ENTITY_ID) SO
      ON (TMP.ENTITY_ID = SO.ENTITY_ID AND SO.SO_NUM = TMP.SO_NUM AND SO.ITEM_CODE = TMP.ITEM_CODE AND  (TMP.SALES_CENTER_CODE = SO.SALES_CENTER_CODE OR TMP.SALES_CENTER_CODE=SO.BELONG_TO_CENTER_CODE) AND TMP.SO_HEADER_ID IS NOT NULL)
      WHEN MATCHED THEN
        UPDATE
           SET TMP.SO_LINE_ID        = SO.SO_LINE_ID,
               TMP.CUSTOMER_CODE     = SO.CUSTOMER_CODE,
               TMP.CUSTOMER_NAME     = SO.CUSTOMER_NAME,
               TMP.CUSTOMER_ID       = SO.CUSTOMER_ID,
               TMP.ITEM_ID           = SO.ITEM_ID,
               TMP.ITEM_NAME         = SO.ITEM_NAME,
               TMP.ITEM_QTY          = SO.ITEM_QTY,
               TMP.ITEM_CHANNEL_TYPE = SO.CHANNEL_TYPE; --原产品类型
      UPDATE T_SO_TRANSFER_LINE_TMP A
         SET A.ERROR = A.ERROR || '无法找到对应的产品编码:' || A.ITEM_CODE
       WHERE A.ITEM_ID IS NULL
         AND A.TRANSFER_HEADER_ID = P_HEADER_ID;
    END IF;
  
    --查询出错信息,错误的是一些更新字段为空
    SELECT COUNT(1)
      INTO V_ERROR_COUNT
      FROM T_SO_TRANSFER_LINE_TMP A
     WHERE A.ERROR IS NOT NULL
       AND A.TRANSFER_HEADER_ID = P_HEADER_ID;
  
    IF (V_ERROR_COUNT > 0) THEN
      P_RESULT_CODE := 'N';
    ELSE
      --增量插入    
      MERGE INTO T_SO_TRANSFER_LINE A
      USING T_SO_TRANSFER_LINE_TMP B
      ON (A.TRANSFER_HEADER_ID = B.TRANSFER_HEADER_ID AND A.SO_NUM = B.SO_NUM AND NVL(A.ITEM_CODE, '-') = NVL(B.ITEM_CODE, '-'))
      WHEN MATCHED THEN
        UPDATE
           SET A.TRANSFER_TYPE           = B.TRANSFER_TYPE,
               A.SO_HEADER_ID            = B.SO_HEADER_ID,
               A.SO_LINE_ID              = B.SO_LINE_ID,
                A.so_date              = B.so_date,
               A.ITEM_ID                 = B.ITEM_ID,
               A.ITEM_NAME               = B.ITEM_NAME,
               A.ITEM_QTY                = B.ITEM_QTY,
               A.ITEM_BUYOUT_PRICE       = B.ITEM_BUYOUT_PRICE,
               A.ITEM_LINE_CODE          = B.ITEM_LINE_CODE,
               A.ITEM_CHANNEL_TYPE       = B.ITEM_CHANNEL_TYPE,
               A.TRANSFER_CHANNEL_TYPE   = B.TRANSFER_CHANNEL_TYPE,
               A.ALL_BUYOUT_PRICE        = B.ALL_BUYOUT_PRICE,
               A.BELONG_TO_RATE          = B.BELONG_TO_RATE,
               A.BELONG_TO_PRICE         = B.BELONG_TO_PRICE,
               A.BELONG_TO_CENTER_CODE   = B.BELONG_TO_CENTER_CODE,
               A.BELONG_TO_CENTER_NAME   = B.BELONG_TO_CENTER_NAME,
               A.BELONG_TO_CENTER_ID     = B.BELONG_TO_CENTER_ID,
               A.BELONG_TO_CUSTOMER_CODE = B.BELONG_TO_CUSTOMER_CODE,
               A.BELONG_TO_CUSTOMER_NAME = B.BELONG_TO_CUSTOMER_NAME,
               A.BELONG_TO_CUSTOMER_ID   = B.BELONG_TO_CUSTOMER_ID,
               A.SALES_CENTER_CODE       = B.SALES_CENTER_CODE,
               A.SALES_CENTER_NAME       = B.SALES_CENTER_NAME,
               A.SALES_CENTER_ID         = B.SALES_CENTER_ID,
               A.CUSTOMER_CODE           = B.CUSTOMER_CODE,
               A.CUSTOMER_NAME           = B.CUSTOMER_NAME,
               A.CUSTOMER_ID             = B.CUSTOMER_ID,
               A.LAST_UPDATED_BY = B.LAST_UPDATED_BY,
               A.LAST_UPDATE_DATE = B.LAST_UPDATE_DATE,
               A.ENTITY_ID = B.ENTITY_ID
      WHEN NOT MATCHED THEN
        INSERT
          (A.TRANSFER_LINE_ID,
           A.TRANSFER_HEADER_ID,
           A.TRANSFER_TYPE,
           A.SO_HEADER_ID,
           A.SO_NUM,
           a.so_date,
           A.SO_LINE_ID,
           A.ITEM_ID,
           A.ITEM_CODE,
           A.ITEM_NAME,
           A.ITEM_QTY,
           A.ITEM_BUYOUT_PRICE,
           A.ITEM_LINE_CODE,
           A.ITEM_CHANNEL_TYPE,
           A.TRANSFER_CHANNEL_TYPE,
           A.ALL_BUYOUT_PRICE,
           A.BELONG_TO_RATE,
           A.BELONG_TO_PRICE,
           A.BELONG_TO_CENTER_CODE,
           A.BELONG_TO_CENTER_NAME,
           A.BELONG_TO_CENTER_ID,
           A.BELONG_TO_CUSTOMER_CODE,
           A.BELONG_TO_CUSTOMER_NAME,
           A.BELONG_TO_CUSTOMER_ID,
           A.SALES_CENTER_CODE,
           A.SALES_CENTER_NAME,
           A.SALES_CENTER_ID,
           A.CUSTOMER_CODE,
           A.CUSTOMER_NAME,
           A.CUSTOMER_ID,
           A.CREATED_BY,
           A.CREATION_DATE,
           A.ENTITY_ID
           )
        VALUES
          (S_SO_TRANSFER_LINE.NEXTVAL,
           B.TRANSFER_HEADER_ID,
           B.TRANSFER_TYPE,
           B.SO_HEADER_ID,
           B.SO_NUM,
           b.so_date,
           B.SO_LINE_ID,
           B.ITEM_ID,
           B.ITEM_CODE,
           B.ITEM_NAME,
           B.ITEM_QTY,
           B.ITEM_BUYOUT_PRICE,
           B.ITEM_LINE_CODE,
           B.ITEM_CHANNEL_TYPE,
           B.TRANSFER_CHANNEL_TYPE,
           B.ALL_BUYOUT_PRICE,
           B.BELONG_TO_RATE,
           B.BELONG_TO_PRICE,
           B.BELONG_TO_CENTER_CODE,
           B.BELONG_TO_CENTER_NAME,
           B.BELONG_TO_CENTER_ID,
           B.BELONG_TO_CUSTOMER_CODE,
           B.BELONG_TO_CUSTOMER_NAME,
           B.BELONG_TO_CUSTOMER_ID,
           B.SALES_CENTER_CODE,
           B.SALES_CENTER_NAME,
           B.SALES_CENTER_ID,
           B.CUSTOMER_CODE,
           B.CUSTOMER_NAME,
           B.CUSTOMER_ID,
           B.CREATED_BY,
           B.CREATION_DATE,
           B.ENTITY_ID);
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
	   ROLLBACK;
      P_RESULT_CODE := 'N';
      P_RESULT_MSG  := '检查划拨明细出错：' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE ||
                       ',异常消息：' || SQLERRM;  
  END P_CHECK_TRANSFER_LINES_IMPORT;
  
END PKG_POL_IMPORT;
/

