create Package      Pkg_Pln_Pub Is

  --add by lizhen 增加订单产品生命周期检查阶段
  v_Phase_Month_Submit   Constant Varchar2(100) := 'MONTH_SUBMIT';
  v_Phase_Week_Submit    Constant Varchar2(100) := 'WEEK_SUBMIT';
  v_Phase_Intf_Aps       Constant Varchar2(100) := 'INTF_APS';
  v_Phase_Order_Affirm   Constant Varchar2(100) := 'ORDER_AFFIRM';
  
  LG_REVIEW_LOG_AMOUNT   CONSTANT VARCHAR2(100) := 'AMOUNT';
  LG_REVIEW_LOG_REMAIN_AREA CONSTANT VARCHAR2(100) := 'REMAIN_AREA';
  LG_REVIEW_LOG_OTHERS CONSTANT VARCHAR2(100) := 'OTHERS';
  
  V_LOCK_AMOUNT_FLAG_S CONSTANT VARCHAR2(10) := 'S'; --送审锁款
  V_LOCK_AMOUNT_FLAG_RS CONSTANT VARCHAR2(10) := 'RS'; --资源送审锁款
  V_LOCK_AMOUNT_FLAG_Y CONSTANT VARCHAR2(10) := 'Y'; --发货锁款
  V_LOCK_AMOUNT_FLAG_RT CONSTANT VARCHAR2(10) := 'RT'; --资源提货锁款
  V_LOCK_AMOUNT_FLAG_HQ CONSTANT VARCHAR2(10) := 'HQ'; --送总部评审锁款
  
  v_Discount_Type_Common Varchar2(32) := 'COMMON'; --常规到款
  v_Discount_Type_Discount Varchar2(32) := 'DISCOUNT';  --折让到款
  
  ----------------------------------------------------------------
  --经营渠道类型
  V_CUSTOMER_CHANNEL_TYPE_WP constant varchar2(32) := '15'; --网批
  V_CUSTOMER_CHANNEL_TYPE_DX constant varchar2(32) := '16'; --代销
  V_CUSTOMER_CHANNEL_TYPE_NIFFER constant varchar2(32) := '17'; --售后换货
  V_CUSTOMER_CHANNEL_TYPE_SHARE constant varchar2(32) := '18'; --售后换货
  ----------------------------------------------------------------
  ----------------------------------------------------------------
  --款项校验模式
  FUND_CHECK_MODE_ORDER CONSTANT VARCHAR2(32) := 'ORDER'; --订单
  FUND_CHECK_MODE_CREDIT CONSTANT VARCHAR2(32) := 'CREDIT'; --信用
  ----------------------------------------------------------------
  ----------------------------------------------------------------
  --支付标志
  PAYMENT_FLAG_COMPLETE CONSTANT VARCHAR2(32) := 'COMPLETED'; --支付完成
  PAYMENT_FLAG_NOPAY CONSTANT VARCHAR2(32) := 'NOPAY'; --未支付
  ----------------------------------------------------------------
  
  ----------------------------------------------------------------
  --物流处理类型
  LPT_OWN_EXPENSES CONSTANT VARCHAR2(32) := 'OWN_EXPENSES'; --自费配送
  ----------------------------------------------------------------

  --------------------------------------------------------------------------------------------
  -- Author  : 李振
  -- Created : 2014-07-02 11:05:52
  -- Purpose : 计划订单管理公用函数包
  --------------------------------------------------------------------------------------------

  --------------------------------------------------------------------------------------------
  -- Author  : 李振
  -- Created : 2014-07-02 11:05:52
  -- Purpose : 获取营销中心的最优产地，默认考虑商品最优物流成本
  --           P_ITEM_ID传入为空时，只取营销中心的最优产的
  -- RETURN  ：只返回一个最优产地
  --------------------------------------------------------------------------------------------
  Function f_Get_Cen_Prod_Area_Priority(p_Sales_Center_Id In Number,
                                        p_Item_Id         In Number,
                                        p_Entity_Id       In Number,
                                        p_User_Code       In Varchar2)
    Return Number;

  --------------------------------------------------------------------------------------------
  -- Author  : 李振
  -- Created : 2015-04-20
  -- Purpose : 获取产品的最优产地，先取中心的优先级
  --------------------------------------------------------------------------------------------
  Function f_Get_Item_Prod_Area_Priority(p_Entity_Id       In Number,
                                         p_Sales_Center_Id In Number,
                                         p_Item_Id         In Number,
                                         p_Item_Life_Cycle In Varchar2 Default 'Y')
    Return Number;

  --------------------------------------------------------------------------------------------
  -- Author  : 李振
  -- Created : 2014-07-02 11:05:52
  -- Purpose : 获取营销中心的最优产地，默认考虑商品最优物流成本
  --           P_ITEM_ID传入为空时，只取营销中心的最优产的
  -- RETURN : 返回中心或产品对应的所有列表。例：产地1,产地2,产地3
  --------------------------------------------------------------------------------------------
  Function f_Get_Cen_Prod_Area_List(p_Sales_Center_Id In Number,
                                    p_Item_Id         In Number,
                                    p_Entity_Id       In Number,
                                    p_User_Code       In Varchar2)
    Return Varchar2;

  ------------------------------------------------------------
  -- Author  : 李振
  -- Created : 2014-07-02 11:05:52
  -- Purpose : 获取订单、汇总订单的下一状态
  --     返回：状态流程配置行ID  *
  ------------------------------------------------------------
  Function f_Get_Order_Next_Status(p_Period         In Number,
                                   p_Order_Type_Id  In Number,
                                   p_Curr_State     In Varchar2,
                                   p_Operate_Action In Varchar2)
    Return Number;

  ------------------------------------------------------------
  -- Author  : 李振
  -- Created : 2014-07-02 11:05:52
  -- Purpose : 获取订单、汇总订单的下一状态
  ------------------------------------------------------------
  Procedure p_Get_Order_Next_Status(p_Order_Type_Id    In Number, --单据类型ID
                                    p_Curr_State       In Varchar2, --单据当前状态
                                    p_Curr_Action      In Varchar2, --单据当前动作
                                    p_Can_Option_Flag  In Varchar2, --是否使用可选流程
                                    p_Next_Excute_Step In Out Number, --下一流程ID
                                    p_Nextauto_Excute  In Out Varchar2, --下一流程是否自动执行
                                    p_Next_State       In Out Varchar2, --下一流程状态
                                    p_Next_Action      In Out Varchar2,
                                    p_Result           In Out Varchar2);

  ------------------------------------------------------------
  /*  根据流程ID，  获取订单、汇总订单的下一状态                  */
  --P_CAN_OPTION_FLAG默认传“N"，需要取Y时，有业务逻辑里面判断
  ------------------------------------------------------------
  Procedure p_Get_Flow_Next_Status(p_Flow_Id          In Number, --单据类型ID
                                   p_Curr_State       In Varchar2, --单据当前状态
                                   p_Curr_Action      In Varchar2, --单据当前动作
                                   p_Can_Option_Flag  In Varchar2, --是否使用可选流程
                                   p_Next_Excute_Step In Out Number, --下一流程ID
                                   p_Nextauto_Excute  In Out Varchar2, --下一流程是否自动执行
                                   p_Next_State       In Out Varchar2, --下一流程状态
                                   p_Next_Action      In Out Varchar2,
                                   p_Result           In Out Varchar2);

  --------------------------------------------------------------------------------------------
  -- Author  : 李振
  -- Created : 2014-07-02 11:05:52
  -- Purpose : 生成单类型编码规则
  --------------------------------------------------------------------------------------------
  Function f_Create_Order_Type_Code(p_Source_Order_Type_Id In Number,
                                    p_Entity_Id            In Number)
    Return Varchar2;

  --------------------------------------------------------------------------------------------
  -- Author  : 李振
  -- Created : 2014-07-02 11:05:52
  -- Purpose : 生成产地信息编码: 主体ID(转16进制补允成2位）+ ROW_COUNT
  --------------------------------------------------------------------------------------------
  Function f_Get_Producing_Area_Code(p_Entity_Id In Number) Return Varchar2;

  --------------------------------------------------------------------------------------------
  -- Author  : 李振
  -- Created : 2014-07-02 11:05:52
  -- Purpose : 生成订单单据号（计划订单，提货订单）
  --------------------------------------------------------------------------------------------
  Procedure p_Create_Order_Number(p_Order_Number_Type In Varchar2, --单据号生成规格（基础数据设置）
                                  p_Period_Id         In Number, --周期ID（提货订单传0)
                                  p_Sales_Center_Id   In Number, --营销中心ID
                                  p_Entity_Id         In Number, --主体ID
                                  p_Order_Number      Out Varchar2 --返回单据号
                                  );
  -----------------------------------------------------------------------------------------
  --Anthor: Nicro.Li
  --Purpose: 更新下达数量
  -----------------------------------------------------------------------------------------
  Procedure p_Upd_Pln_Carry_Qty(p_Order_Share_Id   In Number, --行ID
                                p_Trans_Carry_Qty  In Number, --下达数量
                                p_Trans_Sign_Flag  In Number, --符号方向,下达传1  取消下达传-1
                                p_Entity_Id        In Number, --主体ID
                                p_User_Code        In Varchar2, --用户编码
                                p_Result           Out Varchar2, --成功返回'SUCCESS' 否则返回错误信息
                                p_Lg_Ship_Plan_Id  In Number Default Null, --运力任务计划行ID
                                p_Cusg_Ord_Plan_Id In Number Default Null --直发客户行ID
                                );

  -----------------------------------------------------------------------------------------
  --Anthor: Nicro.Li
  --Purpost: 更新开单数量
  -------------------------------------------------------------------------------------------
  Procedure p_Upd_Pln_So_Order_Qty(p_Order_Share_Id   In Number, --行ID
                                   p_So_Order_Line_Id In Number,  --销售单行ID add by lizhen 2016-02-26
                                   p_Trans_Order_Qty  In Number, --开单数量
                                   p_Trans_Sign_Flag  In Number, --符号方向,开单：1  红冲：-1
                                   p_Entity_Id        In Number, --主体ID
                                   p_User_Code        In Varchar2, --用户编码
                                   p_Result           Out Varchar2, --成功返回'SUCCESS' 否则返回错误信息
                                   p_Cusg_Ord_Plan_Id In Number Default Null --直发客户行ID
                                   );

  -----------------------------------------------------------------------------------------
  --Anthor: Nicro.Li
  --Purpost: 关闭运力任务，更新提货订单、调拨申请的已评审数量
  -------------------------------------------------------------------------------------------
  Procedure p_Upd_Lgorder_Affirm_Qty(p_Lgorder_Line_Id   In Number, --行ID
                                     p_Send_Inventory_Id In Number, --发货仓库ID
                                     p_Trans_Order_Qty   In Number, --运力任务取消数量
                                     p_Trans_Sign_Flag   In Number, --符号方向,开单：1  红冲：-1
                                     p_Entity_Id         In Number, --主体ID
                                     p_User_Code         In Varchar2, --用户编码
                                     p_Result            Out Varchar2, --成功返回'SUCCESS' 否则返回错误信息
                                     p_Lg_Ship_Plan_Id  In Number Default Null --运力任务计划行ID ADD BY LIZHEN 2015-08-18
                                     );

  -----------------------------------------------------------------------------
  -- AUTHOR  : 李振
  -- CREATED : 2014-07-14 11:05:52
  -- PURPOSE : 检查计划订单的订单周期是否正确
  -----------------------------------------------------------------------------
  Procedure p_Check_Period(p_Period_Id   In Number, --阶段ID：年ID、月ID、周ID
                           p_Period_Type In Varchar2, --阶段类型：年、月、周
                           p_Open_Flag   In Varchar2, --是否检查阶段打开状态：Y：要求已打开，N：要求未打开；O:没有作要求
                           p_Close_Flag  In Varchar2, --是否检查阶段关闭状态：Y：要求已关闭，N：要求未关闭；O:没有作要求
                           p_Carry_Flag  In Varchar2, --是否检查阶段结转状态：Y：要求已结转，N：要求未结转；O:没有作要求
                           p_Result      Out Varchar2 --返回结果：成功返回"SUCCESS"，失败返回原因
                           );
  -----------------------------------------------------------------------------------------
  --Anthor: Nicro.Li
  --Purpost: 根据单据类型获取默订周期
  -------------------------------------------------------------------------------------------
  Function f_Get_Default_Period(p_Order_Type_Id In Number, --单据类型ID
                                p_Entity_Id     In Number --主体ID
                                ) Return Number;
  -----------------------------------------------------------------------------------------
  --Anthor: Nicro.Li
  --Purpost: 根据套件、散件,获取散件的配套基数
  -------------------------------------------------------------------------------------------
  Function f_Get_Item_Assembly_Base(p_Ass_Item_Id In Number,
                                    p_Sub_Item_Id In Number) Return Number;

  -----------------------------------------------------------------------------------------
  --Anthor: Nicro.Li
  --Purpost: 写入JOB错误历史表
  -------------------------------------------------------------------------------------------
  Procedure p_Write_Job_Log(p_Module_Code          In Varchar2,
                            p_Procedure_Name       In Varchar2,
                            p_Error_Msg            In Varchar2,
                            p_Source_Order_Head_Id In Number,
                            p_Source_Order_Line_Id In Number,
                            p_Item_Id              In Number,
                            p_Inventory_Id         In Number,
                            p_Quantity             In Number);

-----------------------------------------------------------------------------------------
  --Anthor: Nicro.Li
  --Create: 2015-03-23
  --Purpost: 检查产品奏整数量
  -------------------------------------------------------------------------------------------
  Procedure p_Check_Item_Rounding(p_Entity_Id In Number,  --主体ID
                                  p_Item_Id   In Number,  --产品ID
                                  p_Check_Qty In Number, --待检查数量
                                  p_Result    Out Varchar2);

  -----------------------------------------------------------------------------------------
  --Anthor: Nicro.Li
  --Create: 2015-04-16
  --Purpost: 检查产品产品产地生命周期
  -------------------------------------------------------------------------------------------
  Function p_Chk_Item_Prdc_Life_Cycle(p_Entity_Id         In Number, --主体ID
                                      p_Item_Id           In Number, --产品ID
                                      p_Producing_Area_Id In Number, --产地ID
                                      p_Order_Phase       In Varchar,  --订单检查阶段
                                      --计划订单类型PLN_ORDER，提货订单类型LG_ORDER，月预测MONTH_PLAN
                                      p_Type              In Varchar DEFAULT 'PLN_ORDER'   --订单类型 huanghb12
                                      ) Return Varchar2;

  ----------------------------------------------------------------------
  ---- AUTHOR  : Nicro.Li
  -- CREATED : 2015-07-10
  -- PURPOSE : T+N订单模试下计算计划订单的下线齐套率
  ----------------------------------------------------------------------
  Procedure p_Count_Order_Neat_Set_Rate(p_Order_Head_id  In Number, --计划订单头ID
                                        p_Entity_Id       In Number, --主体ID
                                        p_User_Code       In Varchar2, --用户编码
                                        p_Result          Out Varchar2 --返回结果，成功返回“SUCCESS”，失败返回错误信息
                                        );

  -----------------------------------------------------------------------------
  -- AUTHOR  : Nicro.Li
  -- CREATED : 2015-07-20
  -- PURPOSE : 订单送审前检查到款金额
  -----------------------------------------------------------------------------
  Procedure p_Submit_Check_Amount(p_Order_Type_Id   In Number, ----订单ID
                                  p_Customer_Id     In Number, --客户ID
                                  p_Account_Id      In Number, --账户ID
                                  p_Sales_Main_Type In Varchar2, --产品大类
                                  p_Amount          In Number, --金额
                                  p_Discount_Amount In Number, --折扣客
                                  p_Result          In Out Varchar2, --返回结果：SUCCESS——>过程执行完成；FAILURE——>中途抛错
                                  p_Message         Out Varchar2 --返回信息：这里的值初始为SUCCESS
                                  );
  ---------------------------------------------------------------------------------
  -- Author  : NICRO.LI
  -- Created : 2015-08-26 09:49:18
  -- Purpose : 提货订单发货、取消发货时锁定独资主体到款
  ---------------------------------------------------------------------------------
  Procedure p_Ims_Lg_Carry_Lock_Cash(p_Lg_Order_Head_Id In Number, --提货订单头ID
                                     p_Lg_Order_Line_Id In Number, --提货订单行ID
                                     p_Entity_Id        In Number, --主体ID
                                     p_Transaction_Qty     In Number, --当前行发货数量
                                     p_Transaction_Flag    In Number, --下达事务类型：1：下达物流发货 -1：物流取消
                                     p_Result           Out Varchar2);

  ---------------------------------------------------------------------------------
  -- Author  : 何加源
  -- Created : 2015-11-20
  -- Purpose : 写操作接口表
  ---------------------------------------------------------------------------------
  PROCEDURE P_WriteBack_Opt_Intf(p_Lg_Order_Head_Id In Number, --提货订单头ID
                                 p_Lg_Order_Line_Id In Number, --提货订单行ID
                                 p_Entity_Id        In NUMBER, --主体ID
                                 p_Opt_Type         IN VARCHAR2, --操作类型
                                 p_Transaction_Qty  IN NUMBER, --数量
                                 p_Deal_Money_Cims  IN VARCHAR2, --CIMS款项处理标志
                                 p_Deal_Money_Ims   IN VARCHAR2, --IMS款项处理标志
                                 p_User_Code        IN VARCHAR2, --操作用户
                                 p_Result           Out Varchar2);

  ---------------------------------------------------------------------------------
  -- Author  : 何加源
  -- Created : 2015-11-20
  -- Purpose : CIMS操作接口处理
  ---------------------------------------------------------------------------------
  PROCEDURE P_Opt_Intf_Deal_Job(p_Lg_Order_Head_Id IN NUMBER DEFAULT -1, --提货订单头ID
                                p_Lg_Order_Line_Id In NUMBER DEFAULT -1, --提货订单行ID
                                p_Entity_Id        In NUMBER DEFAULT -1); --主体ID

  ---------------------------------------------------------------------------------
  -- Author  : 何加源
  -- Created : 2016-1-22
  -- Purpose : 销司可报送型谱SKU检查
  ---------------------------------------------------------------------------------
  PROCEDURE P_PLN_CHECK_SC_SKU(p_Order_Head_Id   IN NUMBER, --订单头ID
                               p_Entity_Id       In NUMBER, --主体ID
                               p_Order_Type      IN VARCHAR2, --来源单据类型：PLN:计划 LG:提货 STP:月预测
                               p_Result          Out Varchar2);

  ---------------------------------------------------------------------------------
  -- Author  : 何加源
  -- Created : 2016-2-1
  -- Purpose : 销司库存占比金额检查
  ---------------------------------------------------------------------------------
  PROCEDURE P_PLN_CHK_INV_COST_PROPORTION(p_Order_Head_Id   IN NUMBER, --订单头ID
                                          p_Entity_Id       In NUMBER, --主体ID
                                          p_Order_Type      IN VARCHAR2, --来源单据类型：PLN:计划 LG:提货
                                          p_Result          Out Varchar2);

  -----------------------------------------------------------------------------
  -- AUTHOR  : Nicro.Li
  -- CREATED : 2016-04-09
  -- PURPOSE : 根据提货汇总头ID获取各汇总参数字段在汇总头表对应的值
  -----------------------------------------------------------------------------
  Function f_Get_T3para_Collect_Value(p_Entity_Id          In Number,
                                      p_Lg_Collect_Head_Id In Number, --提货订单汇总头ID
                                      p_Param_Code         In Varchar2 --参数字段编码
                                      ) Return Varchar2;
                                      
  -----------------------------------------------------------------------------
  -- AUTHOR  : Nicro.Li
  -- CREATED : 2017-10-31
  -- PURPOSE : 根据提货预约汇总头ID获取各新汇总参数字段在汇总头表对应的值
  -----------------------------------------------------------------------------
  Function f_Get_RcOrdPara_Collect_Value(In_Entity_Id          In Number,
                                         In_Head_Id            In Number, --提货订单汇总头ID
                                         In_Table_Alias        In Varchar2, --表别名
                                         In_Column_Code        In Varchar2 --字段编码
                                         ) Return Varchar2;
                                      
  -----------------------------------------------------------------------------
  -- AUTHOR  : Nicro.Li
  -- CREATED : 2016-04-09
  -- PURPOSE : 根据主体获取提货订单当前周期期间开始日期与结束日期
  -----------------------------------------------------------------------------
  Procedure p_Get_CurrentPeriodDate(p_Entity_Id                 In Number, --主体ID
                                    IN_CAL_DATE   in date DEFAULT SYSDATE ,--默认日期                            
                                    p_Current_Period_Begin_Date Out Date, --开始日期
                                    p_Current_Period_End_Date Out Date   --结束日期
                                    );
                                                                            
  -----------------------------------------------------------------------------
  -- AUTHOR  : Nicro.Li
  -- CREATED : 2016-04-05
  -- PURPOSE : 根据产品、单据送审类型获取产品的库存可用量（符合条件仓库的汇总）
  -----------------------------------------------------------------------------                                      
  Function f_Get_Lgorder_Noship_Qty(p_Entity_Id         In Number, ----主体ID
                                    p_Item_Id           In Number, --产品ID
                                    p_Order_Submit_Type In Varchar2, --单据送审类型
                                    p_User_Code         In Varchar2, --用户编码
                                    IN_MRP_ORG_ID       IN NUMBER DEFAULT -1,--组织 ID
                                    IN_ITEM_CODE        IN VARCHAR2 DEFAULT '_'--产品编码
                                    ) Return Number;
                                    
  -----------------------------------------------------------------------------
  -- AUTHOR  : Nicro.Li
  -- CREATED : 2016-06-20
  -- PURPOSE : 根据产品、单据送审类型获取产品的库存可用量（符合条件仓库的汇总）
  -----------------------------------------------------------------------------
  Function f_Get_Item_Inv_Usable_Qty(p_Entity_Id         In Number, ----主体ID
                                     p_Item_Id           In Number, --产品ID
                                     p_Order_Submit_Type In Varchar2, --单据送审类型
                                     p_Sales_Center_Id   In Number, --营销中心ID
                                     p_User_Code         In Varchar2  --用户编码
                                     ) Return Number;
                                     
  -----------------------------------------------------------------------------
  -- AUTHOR  : Nicro.Li
  -- CREATED : 2016-04-05
  -- PURPOSE : 根据产品、单据送审类型获取产品的库存可用量（符合条件仓库的汇总）
  -----------------------------------------------------------------------------
  Function f_Get_Item_Usable_Qty(p_Entity_Id         In Number, ----主体ID
                                 p_Item_Id           In Number, --产品ID
                                 p_Order_Submit_Type In Varchar2, --仓库类型
                                 p_Sales_Center_Id   In Number, --营销中心ID
                                 p_Lg_Order_Noship   In Varchar2, --是否扣减已评未发货数量  Y:扣减  N:不扣减
                                 p_User_Code         In Varchar2) Return Number ;                                       
  
  -----------------------------------------------------------------------------
  -- AUTHOR  : Nicro.Li
  -- CREATED : 2016-06-15
  -- PURPOSE : 根据产品、单据送审类型获取产品的备货订单未入库数量
  -----------------------------------------------------------------------------
  Function f_Get_Meet_An_Order_Qty(p_Entity_Id         In Number, ----主体ID
                                   p_Item_Id           In Number, --产品ID
                                   p_Order_Submit_Type In Varchar2 --单据送审类型
                                   ) Return Number;
                                   
  ---------------------------------------------------------------------------------
  -- Author  : 李梁华
  -- Created : 2016-4-11
  -- Purpose : 特价机占比检查
  ---------------------------------------------------------------------------------
  PROCEDURE P_PLN_CHK_SP_ITEM(p_Order_Head_Id   IN NUMBER, --订单头ID
                               p_Entity_Id       In NUMBER, --主体ID
                               p_Result          Out Varchar2);   
  -----------------------------------------------------------------------------
  -- AUTHOR  : 吴林
  -- CREATED : 2016-04-12
  -- PURPOSE : 根据主体获取提货订单当前周期期间开始日期与结束日期
  -----------------------------------------------------------------------------
  FUNCTION F_GET_CURRENTPERIODDATE(I_ENTITY_ID   IN NUMBER, --主体ID
                                   I_OPTION_TYPE VARCHAR2 ---B 开始日期  E结束日期
                                   ) RETURN DATE;
  
  -----------------------------------------------------------------------------
  -- AUTHOR  : Nicro.Li
  -- CREATED : 2016-08-11
  -- PURPOSE : 根据提货汇总头ID获取各新汇总参数字段在汇总头表对应的值
  -----------------------------------------------------------------------------
  Function f_Get_T3OrdPara_Collect_Value(p_Entity_Id          In Number,
                                         p_Lg_Collect_Head_Id In Number, --提货订单汇总头ID
                                         p_Table_Alias        In Varchar2, --表别名
                                         p_Column_Code        In Varchar2 --字段编码
                                         ) Return Varchar2;
                                         
  -----------------------------------------------------------------------------
  -- AUTHOR  : hejy3
  -- CREATED : 2016-12-17
  -- PURPOSE : 下达校验客户账户、标准成本、批准供应商
  -----------------------------------------------------------------------------
  PROCEDURE P_CHK_ERP_COST_AND_SUPPLIER(P_ENTITY_ID       IN NUMBER, --主体ID
                                        P_SALES_CENTER_ID IN NUMBER, --中心ID
                                        P_CUSTOMER_ID     IN NUMBER, --客户ID
                                        P_ACCOUNT_ID      IN NUMBER, --账户ID
                                        P_INVENTORY_ID    IN NUMBER, --仓库ID
                                        P_ORDER_TYPE_ID   IN NUMBER, --单据类型ID
                                        P_ITEM_ID_LIST    IN VARCHAR2, --产品编码串，格式：ITEM_ID1,ITEM_ID2,...,ITEM_IDN
                                        P_RESULT          OUT VARCHAR2, --返回信息，成功返回'SUCCESS'，否则返回错误信息
                                        IN_BUSINESS_TYPE   IN VARCHAR2 DEFAULT '_'
                                        );    
  -----------------------------------------------------------------------------
  -- AUTHOR  : ex_dengjh
  -- CREATED : 2017-4-1
  -- PURPOSE : a．	按照主体ID，中心ID，产品编码获取总部月度分配量表的剩余分配量（总分配量-已占用分配量）
  -----------------------------------------------------------------------------
  function F_GET_ITEM_MONTH_ASSIGN_QTY(IN_ENTITY_ID       in NUMBER, --主体ID
                                       IN_SALES_CENTER_ID in NUMBER, --中心ID
                                       IN_CUSTOMER_ID     IN NUMBER, --客户ID
                                       IN_ITEM_ID         in NUMBER --产品ID
                                       ) return number;
  -----------------------------------------------------------------------------
  -- AUTHOR  : ex_dengjh
  -- CREATED : 2017-4-11
  -- PURPOSE : 按照传入主体、中心、产品、日期获取提货订单占用量
  -----------------------------------------------------------------------------
  function F_GET_OCCUPY_ASSIGN_QTY(IN_ENTITY_ID       in NUMBER, --主体ID
                                   IN_SALES_CENTER_ID in NUMBER, --中心ID
                                   IN_CUSTOMER_ID     IN NUMBER, --客户ID
                                   IN_ITEM_ID         in NUMBER, --产品编码
                                   IN_SALES_MAIN_TYPE IN VARCHAR2, --大类，张开安2018-05-03添加
                                   IN_SALES_SUB_TYPE  IN VARCHAR2, --小类，张开安2018-05-03添加
                                   IN_BEGIN_DATE      in DATE, --期间起始日期
                                   IN_END_DATE        in DATE --期间结束日期
                                   ) return number;
  -----------------------------------------------------------------------------
  -- AUTHOR  : tanjz2
  -- CREATED : 2017-04-11
  -- PURPOSE : 校验定时是否满足齐套
  -----------------------------------------------------------------------------
  PROCEDURE P_CHK_CARLOADMEET(P_ORDER_HEAD_ID   IN NUMBER, --订单ID
                              P_RESULT          OUT VARCHAR2 --返回信息，成功返回'SUCCESS'，否则返回错误信息
                              ); 
  
  -----------------------------------------------------------------------------
  -- AUTHOR  : Nicro.Li
  -- CREATED : 2017-11-13
  -- PURPOSE : 提货订单为发货锁款时，加解锁销司订单客户款项，
  --   In_Lg_Line_Id值!= -1时，表示取消发货通知单并且解锁款项
  -----------------------------------------------------------------------------
  Procedure p_Upd_Transfer_Lg_Order(In_Lg_Order_Id In Number,  --总部提货订单头
                                    In_Lg_Line_Id  In Number,  --解锁款项时传入
                                    In_Qty         In Number, --当传入订单行ID为-1时，传入空值，否则传入发货通知单取消数量
                                    In_User_Code   In Varchar2,
                                    Out_Result     Out Varchar2, --处理结果，成功返回SUCCESS，否则返回错误信息
                                    IN_OPERATION_TYPE IN VARCHAR2 DEFAULT '评审', --处理类型
									IN_SKIP_LOCK   In Varchar2 DEFAULT 'N' -- 是否跳过锁款，默认为N add by houhs
                                    );
                                    
  -----------------------------------------------------------------------------
  -- AUTHOR  : hejy3
  -- CREATED : 2018-4-27
  -- PURPOSE : 检查ERP侧是否有维护标准成本，有维护返回1，否则返回0
  -----------------------------------------------------------------------------
  FUNCTION F_CHK_ERP_STANDARD_COST(IN_ORGANIZATION_ID IN NUMBER, --组织ID
                                   IN_ITEM_CODE       IN VARCHAR2 --产品
                                   ) return number;
  
  -----------------------------------------------------------------------------
  -- AUTHOR  : hejy3
  -- CREATED : 2018-7-4
  -- PURPOSE : 款项处理过程
  -----------------------------------------------------------------------------
  PROCEDURE P_CUSTOMER_AMOUNT_PROCESS(IN_ENTITY_ID       IN NUMBER, --主体ID
                                      IN_ORDER_TYPE_ID   IN NUMBER, --单据类型ID
                                      IN_ORDER_TYPE_CODE IN VARCHAR2, --类型编码
                                      IN_CUSTOMER_ID     IN NUMBER, --客户ID
                                      IN_ACCOUNT_ID      IN NUMBER, --账户ID
                                      IN_SALES_MAIN_TYPE IN VARCHAR2, --营销大类
                                      IN_ACTION_TYPE     IN NUMBER, --动作标识
                                      IN_SOURCE_TYPE     IN NUMBER, --来源类型，取码表SO_SRC_TYPE
                                      IN_ORDER_ID        IN NUMBER, --订单ID
                                      IN_PROJ_NUMBER     IN VARCHAR2, --项目号
                                      IN_DISCOUNT_TYPE   IN VARCHAR2, --折扣类型
                                      IN_AMOUNT          IN NUMBER, --金额
                                      IN_DIS_AMOUNT      IN NUMBER, --折让金额
                                      IN_RECORD_ERR      IN VARCHAR2, --是否记录回款错误信息
                                      IN_USER_CODE       IN VARCHAR2, --操作用户
                                      OUT_RESULT         IN OUT VARCHAR2 --处理结果
                                      );
  
  -----------------------------------------------------------------------------
  -- AUTHOR  : huanghb12
  -- CREATED : 2018-9-18
  -- PURPOSE : 更新提货订单预排信息
  -----------------------------------------------------------------------------
  PROCEDURE P_UPD_LG_CONSIGNMENT_SINGLE(p_Walkthrough_Batch In Varchar2, --预排批次
                                        p_Opertation_Action In Varchar2, --预排批次 
                                        p_User_Code         In Varchar2, --用户
                                        p_Result            Out Varchar2 --返回结果
                                        );
  
  -----------------------------------------------------------------------------
  -- AUTHOR  : hejy3
  -- CREATED : 2018-10-18
  -- PURPOSE : 获取订单周期
  -----------------------------------------------------------------------------
  FUNCTION F_GET_PERIOD_CODE(IN_PERIOD_DAY  IN NUMBER, --周期天数
                              IN_CAL_DATE    IN DATE, --日期
                              IN_PERIOD_TYPE IN VARCHAR2 --周期类型：T+3周期、周
                              ) RETURN VARCHAR2;
                              
  -----------------------------------------------------------------------------
  -- AUTHOR  : hejy3
  -- CREATED : 2018-10-10
  -- PURPOSE : 记录订单评审出错信息
  -----------------------------------------------------------------------------
  PROCEDURE P_RECORD_LG_ORDER_REVIEW_LOG(IN_ENTITY_ID     IN NUMBER,
                                         IN_ORDER_HEAD_ID IN NUMBER,
                                         IN_REVIEW_SUMMARY IN VARCHAR2,
                                         IN_REVIEW_DETAIL IN VARCHAR2,
                                         IN_USER_CODE     IN VARCHAR2);
                                         
  -----------------------------------------------------------------------------
  -- AUTHOR  : lilh6
  -- CREATED : 2019-3-4
  -- PURPOSE : 更新可补货数据，同时记录操作历史
  -----------------------------------------------------------------------------
  Procedure p_Update_Dx_Make_Up_Qty(p_Dx_Order_Number In Varchar2, --代销单号
                                    p_Item_Code       In Varchar2, --产品编码
                                    p_Qty             In Number, --数量
                                    p_Sign_Flag       In Number, --符号方向,增加传1，减少传-1
                                    p_Operate_Type    In Varchar2, --操作类型，写具体触发步骤
                                    p_Operate_Number  In Varchar2, --操作单号或id
                                    p_User_Code       In Varchar2, --用户
                                    p_Result          Out Varchar2 --返回结果
                                    );
  
  ----------------------------------------------------------------------------
  --是否定制机，且返回甲方客户、销司、代理商
  ----------------------------------------------------------------------------
  PROCEDURE P_GET_CUSTOMIZE_INFO(IN_ENTITY_ID         IN NUMBER,
                                 IN_PG_APPLY_CODE     IN VARCHAR2,
                                 IN_ITEM_CODE         IN VARCHAR2,
                                 OUT_CUSTOMIZE_FLAG   OUT VARCHAR2,
                                 OUT_ACCOUNT_ID       OUT NUMBER,
                                 OUT_SC_ACCOUNT_ID    OUT NUMBER,
                                 OUT_AGENT_ACCOUNT_ID OUT NUMBER);
    ------------------------------------------------------------------------------------------
  -- AUTHOR  : huanghb12
  -- CREATED : 2020-04-10
  -- PURPOSE : 校验失败的时候写入接口表sym_intf_cims_message_push，接口表的信息用于ccs发短信用
  ------------------------------------------------------------------------------------------
  Procedure p_Insert_cims_message_push(r_Lg_Order_Head t_Pln_Lg_Order_Head%Rowtype,
                                  In_Sales_Main_Type Varchar2,
                                  In_Discount_Type   Varchar2,
                                  In_Amount          Number,
                                  In_Discount_Amount Number,
                                  In_Error_Msg       Varchar2,
                                  In_User_Code       Varchar2); 
End Pkg_Pln_Pub;
/

