create PACKAGE BODY PKG_PLN_REPORT IS

  -- Private type declarations
  FUNCTION F_GET_LG_CONTRACT_PROGRESS(P_LG_ORDER_LINE_ID IN NUMBER,
                                      P_LG_ORDER_HEAD_ID IN NUMBER)
    RETURN TBL_LG_CONTRACT_PROGRESS
    PIPELINED IS
    R_LG_CONTRACT_PROGRESS OBJ_LG_CONTRACT_PROGRESS;
  BEGIN
    FOR R_LG IN (
                 SELECT A.CONTRACT_CODE,
                        A.SO_CONTRACT_CODE,
                        A.RECEIVE_FLAG,
                        A.FACT_SHIP_DATE,
                        MIN(A.CL_FACT_SHIP_QTY) CL_FACT_SHIP_QTY,
                        MIN(A.TOTAL_VOLUME) TOTAL_VOLUME,
                        A.RECEIVE_DATE,
                        MIN(AFFIRM_QTY/NVL(B.QUANTITY,1)) AFFIRM_QTY,
                        MIN(DIFF_QTY/NVL(B.QUANTITY,1)) DIFF_QTY,
                        A.ORIGIN_TYPE,
                        A.ORIGIN_ORDER_ID,
                        A.ORIGIN_ORDER_NUM,
                        A.ORIGIN_LINE_ID,
                        A.SHIP_DOC_LINE_ID,
                        A.ENTITY_ID
                   FROM (
                     SELECT C.CONTRACT_CODE,
                            CL.SO_DOC_NUM SO_CONTRACT_CODE,
                            C.RECEIVE_FLAG,
                            C.FACT_SHIP_DATE,
                            --MIN(SL.ITEM_QTY) CL_FACT_SHIP_QTY,
                            SL.ITEM_QTY CL_FACT_SHIP_QTY,
                            --MIN(SL.ITEM_QTY * SL.ITEM_VOLUME) TOTAL_VOLUME,
                            (SL.ITEM_QTY * SL.ITEM_VOLUME) TOTAL_VOLUME,
                            C.RECEIVE_DATE,
                            /*MIN(NVL(CL.AFFIRM_QTY, 0) /
                                PKG_PLN_PUB.F_GET_ITEM_ASSEMBLY_BASE(P_ASS_ITEM_ID => SL.ITEM_ID,
                                                                     P_SUB_ITEM_ID => SUBBI.ITEM_ID)) AFFIRM_QTY,*/
                            NVL(CL.AFFIRM_QTY, 0) AFFIRM_QTY,
                            /*MIN(NVL(CL.DIFF_QTY, 0) /
                                PKG_PLN_PUB.F_GET_ITEM_ASSEMBLY_BASE(P_ASS_ITEM_ID => SL.ITEM_ID,
                                                                     P_SUB_ITEM_ID => SUBBI.ITEM_ID)) DIFF_QTY,*/
                            NVL(CL.DIFF_QTY, 0) DIFF_QTY,
                            CL.ORIGIN_ORIGIN_TYPE ORIGIN_TYPE,
                            CL.ORIGIN_ORIGIN_HEAD_ID ORIGIN_ORDER_ID,
                            CL.ORIGIN_ORIGIN_DOC_CODE ORIGIN_ORDER_NUM,
                            CL.ORIGIN_ORIGIN_LINE_ID ORIGIN_LINE_ID,
                            CL.SHIP_DOC_LINE_ID,
                            C.ENTITY_ID,
                            SL.ITEM_ID ASS_ITEM_ID,
                            CL.ITEM_CODE SUB_ITEM_CODE
                     --Into r_Lg_Contract_Progress
                       FROM CIMS.T_LG_CONTRACT      C,
                            CIMS.T_LG_CONTRACT_LINE CL,
                            CIMS.T_SO_HEADER        SH,
                            CIMS.T_SO_LINE          SL/*,
                            CIMS.T_BD_ITEM          SUBBI*/
                      WHERE C.CONTRACT_ID = CL.CONTRACT_ID
                        AND CL.SO_DOC_ID = SH.SO_HEADER_ID
                        AND CL.SHIP_DOC_LINE_ID = SL.SHIP_DOC_LINE_ID
                        AND SH.SO_HEADER_ID = SL.SO_HEADER_ID
                        AND NVL(CL.ORIGIN_ORIGIN_TYPE, '_') = '02'
                        /*AND SUBBI.ITEM_CODE = CL.ITEM_CODE
                        AND SUBBI.ENTITY_ID = C.ENTITY_ID*/
                        AND CL.ORIGIN_ORIGIN_HEAD_ID = P_LG_ORDER_HEAD_ID
                        AND CL.ORIGIN_ORIGIN_LINE_ID = P_LG_ORDER_LINE_ID
                      /*GROUP BY C.CONTRACT_CODE,
                               CL.SO_DOC_NUM,
                               C.RECEIVE_FLAG,
                               C.FACT_SHIP_DATE,
                               C.RECEIVE_DATE,
                               CL.ORIGIN_ORIGIN_TYPE,
                               CL.ORIGIN_ORIGIN_HEAD_ID,
                               CL.ORIGIN_ORIGIN_DOC_CODE,
                               CL.ORIGIN_ORIGIN_LINE_ID,
                               CL.SHIP_DOC_LINE_ID,
                               C.ENTITY_ID*/
                     UNION ALL
                     SELECT C.CONTRACT_CODE,
                            CL.SO_DOC_NUM SO_CONTRACT_CODE,
                            C.RECEIVE_FLAG,
                            C.FACT_SHIP_DATE,
                            --MIN(SL.ITEM_QTY) CL_FACT_SHIP_QTY,
                            SL.ITEM_QTY CL_FACT_SHIP_QTY,
                            --MIN(SL.ITEM_QTY * SL.ITEM_VOLUME) TOTAL_VOLUME,
                            (SL.ITEM_QTY * SL.ITEM_VOLUME) TOTAL_VOLUME,
                            C.RECEIVE_DATE,
                            /*MIN(NVL(CL.AFFIRM_QTY, 0) /
                                PKG_PLN_PUB.F_GET_ITEM_ASSEMBLY_BASE(P_ASS_ITEM_ID => SL.ITEM_ID,
                                                                     P_SUB_ITEM_ID => SUBBI.ITEM_ID)) AFFIRM_QTY,*/
                            NVL(CL.AFFIRM_QTY, 0) AFFIRM_QTY,
                            /*MIN(NVL(CL.DIFF_QTY, 0) /
                                PKG_PLN_PUB.F_GET_ITEM_ASSEMBLY_BASE(P_ASS_ITEM_ID => SL.ITEM_ID,
                                                                     P_SUB_ITEM_ID => SUBBI.ITEM_ID)) DIFF_QTY,*/
                            NVL(CL.DIFF_QTY, 0) DIFF_QTY,
                            CL.ORIGIN_TYPE,
                            CL.ORIGIN_ORDER_ID,
                            CL.ORIGIN_ORDER_NUM,
                            CL.ORIGIN_LINE_ID,
                            CL.SHIP_DOC_LINE_ID,
                            C.ENTITY_ID,
                            SL.ITEM_ID ASS_ITEM_ID,
                            CL.ITEM_CODE SUB_ITEM_CODE
                     --Into r_Lg_Contract_Progress
                       FROM CIMS.T_LG_CONTRACT      C,
                            CIMS.T_LG_CONTRACT_LINE CL,
                            CIMS.T_SO_HEADER        SH,
                            CIMS.T_SO_LINE          SL/*,
                            CIMS.T_BD_ITEM          SUBBI*/
                      WHERE C.CONTRACT_ID = CL.CONTRACT_ID
                        AND CL.SO_DOC_ID = SH.SO_HEADER_ID
                        AND CL.SHIP_DOC_LINE_ID = SL.SHIP_DOC_LINE_ID
                        AND SH.SO_HEADER_ID = SL.SO_HEADER_ID
                        AND NVL(CL.ORIGIN_TYPE, '_') = '02'
                        /*AND SUBBI.ITEM_CODE = CL.ITEM_CODE
                        AND SUBBI.ENTITY_ID = C.ENTITY_ID*/
                        AND CL.ORIGIN_ORDER_ID = P_LG_ORDER_HEAD_ID
                        AND CL.ORIGIN_LINE_ID = P_LG_ORDER_LINE_ID
                      /*GROUP BY C.CONTRACT_CODE,
                               CL.SO_DOC_NUM,
                               C.RECEIVE_FLAG,
                               C.FACT_SHIP_DATE,
                               C.RECEIVE_DATE,
                               CL.ORIGIN_TYPE,
                               CL.ORIGIN_ORDER_ID,
                               CL.ORIGIN_ORDER_NUM,
                               CL.ORIGIN_LINE_ID,
                               CL.SHIP_DOC_LINE_ID,
                               CL.SHIP_DOC_LINE_ID,
                               C.ENTITY_ID*/
                   ) A,(SELECT S.ENTITY_ID,
                              S.ITEM_ID ASS_ITEM_ID,
                              S.ITEM_CODE ASS_ITEM_CODE,
                              S.ITEM_NAME ASS_ITEM_NAME,
                              S.SUB_ITEM_ID,
                              S.SUB_ITEM_CODE,
                              S.SUB_ITEM_NAME,
                              S.QUANTITY
                         FROM CIMS.V_BD_ITEM_ASSEMBLIES_SUB S
                        WHERE S.ASSEMBLE_ACTIVE_FLAG = 'Y'
                          AND S.ACTIVE_FLAG = 'Y') B
                 WHERE A.ENTITY_ID = B.ENTITY_ID(+)
                   AND A.ASS_ITEM_ID = B.ASS_ITEM_ID(+)
                   AND A.SUB_ITEM_CODE = B.SUB_ITEM_CODE(+)
                 GROUP BY A.CONTRACT_CODE,
                          A.SO_CONTRACT_CODE,
                          A.RECEIVE_FLAG,
                          A.FACT_SHIP_DATE,
                          A.RECEIVE_DATE,
                          A.ORIGIN_TYPE,
                          A.ORIGIN_ORDER_ID,
                          A.ORIGIN_ORDER_NUM,
                          A.ORIGIN_LINE_ID,
                          A.SHIP_DOC_LINE_ID,
                          A.ENTITY_ID
                 UNION ALL
                 --转过T+3的自提
                 SELECT NULL CONTRACT_CODE,
                        SH.SO_NUM SO_CONTRACT_CODE,
                        SH.RECEIVE_FLAG,
                        SH.SHIP_DATE FACT_SHIP_DATE,
                        SL.ITEM_QTY CL_FACT_SHIP_QTY,
                        SL.ITEM_QTY * SL.ITEM_VOLUME TOTAL_VOLUME,
                        SH.RECEIVE_DATE,
                        NULL AFFIRM_QTY,
                        NULL DIFF_QTY,
                        SH.ORIGIN_ORIGIN_TYPE ORIGIN_TYPE,
                        SL.LG_ORDER_HEAD_ID ORIGIN_ORDER_ID,
                        SL.LG_ORDER_NUMBER ORIGIN_ORDER_NUM,
                        SL.LG_ORDER_HEAD_LINE_ID ORIGIN_LINE_ID,
                        SL.SHIP_DOC_LINE_ID,
                        SH.ENTITY_ID
                   FROM CIMS.T_SO_HEADER SH, CIMS.T_SO_LINE SL
                  WHERE SH.SO_HEADER_ID = SL.SO_HEADER_ID
                    AND SH.SELF_PICK_FLAG = 'Y'
                    AND SL.LG_ORDER_HEAD_ID = P_LG_ORDER_HEAD_ID
                    AND SL.LG_ORDER_HEAD_LINE_ID = P_LG_ORDER_LINE_ID
                 
                 UNION ALL
                 --没转T+3
                 SELECT NULL CONTRACT_CODE,
                        SH.SO_NUM SO_CONTRACT_CODE,
                        SH.RECEIVE_FLAG,
                        SH.SHIP_DATE FACT_SHIP_DATE,
                        SL.ITEM_QTY CL_FACT_SHIP_QTY,
                        SL.ITEM_QTY * SL.ITEM_VOLUME TOTAL_VOLUME,
                        SH.RECEIVE_DATE,
                        NULL AFFIRM_QTY,
                        NULL DIFF_QTY,
                        SH.RAW_SRC_TYPE ORIGIN_TYPE,
                        SL.RAW_SRC_HEADER_ID ORIGIN_ORDER_ID,
                        SH.RAW_SRC_BILL_NUM ORIGIN_ORDER_NUM,
                        SL.RAW_SRC_LINE_ID ORIGIN_LINE_ID,
                        SL.SHIP_DOC_LINE_ID,
                        SH.ENTITY_ID
                   FROM CIMS.T_SO_HEADER SH, CIMS.T_SO_LINE SL
                  WHERE SH.SO_HEADER_ID = SL.SO_HEADER_ID
                    AND SH.SELF_PICK_FLAG = 'Y'
                    AND SL.RAW_SRC_HEADER_ID = P_LG_ORDER_HEAD_ID
                    AND SL.RAW_SRC_LINE_ID = P_LG_ORDER_LINE_ID) LOOP
      R_LG_CONTRACT_PROGRESS := OBJ_LG_CONTRACT_PROGRESS(R_LG.CONTRACT_CODE,
                                                         R_LG.SO_CONTRACT_CODE,
                                                         R_LG.RECEIVE_FLAG,
                                                         R_LG.FACT_SHIP_DATE,
                                                         R_LG.CL_FACT_SHIP_QTY,
                                                         R_LG.TOTAL_VOLUME,
                                                         R_LG.RECEIVE_DATE,
                                                         R_LG.AFFIRM_QTY,
                                                         R_LG.DIFF_QTY,
                                                         R_LG.ORIGIN_TYPE,
                                                         R_LG.ORIGIN_ORDER_ID,
                                                         R_LG.ORIGIN_ORDER_NUM,
                                                         R_LG.ORIGIN_LINE_ID,
                                                         R_LG.SHIP_DOC_LINE_ID,
                                                         R_LG.ENTITY_ID);
      PIPE ROW(R_LG_CONTRACT_PROGRESS);
    END LOOP;
    RETURN; -- Tbl_Lg_Contract_Progress(r_Lg_Contract_Progress);
  EXCEPTION
    WHEN OTHERS THEN
      NULL;
  END;

  ------------------------------------------------------------------------
  -- Author  : NICRO.LI
  -- Created : 2016-07-26 17:42:02
  -- Purpose : 返回运输线路数据
  -------------------------------------------------------------------------
  FUNCTION F_GET_LG_TRANSPORT_LINE(P_BEGIN_AREA_CODE IN VARCHAR2,
                                   P_END_AREA_CODE   IN VARCHAR2)
    RETURN TAB_LG_TRANSPORT_LINE IS
  
    R_LG_TRANSPORT_LINE     TAB_LG_TRANSPORT_LINE;
    R_LG_TRANSPORT_LINE_LMS T_LG_TRANSPORT_LINE_LMS%ROWTYPE;
    V_COUNT                 NUMBER;
    V_BEGIN_AREA_CODE       VARCHAR2(32);
    V_END_AREA_CODE         VARCHAR2(32);
  BEGIN
  
    --获取起始区域是否存在运输线路
    V_BEGIN_AREA_CODE := P_BEGIN_AREA_CODE;
    V_END_AREA_CODE   := P_END_AREA_CODE;
    FOR I IN 1 .. 3 LOOP
      SELECT COUNT(1)
        INTO V_COUNT
        FROM T_LG_TRANSPORT_LINE_LMS TLL
       WHERE TLL.BEGIN_AREA_CODE = V_BEGIN_AREA_CODE
         AND TLL.END_AREA_CODE = V_END_AREA_CODE
         AND NVL(TLL.TRANSPORT_LINE_TYPE, 'DEFAULT') = 'DEFAULT'
         AND TLL.VALID_STATE = 'Y';
      IF NVL(V_COUNT, 0) <= 0 THEN
        BEGIN
          SELECT TBDP.DISTRICT_CODE
            INTO V_BEGIN_AREA_CODE
            FROM T_BD_DISTRICT TBD, T_BD_DISTRICT TBDP
           WHERE TBD.DISTRICT_CODE = V_BEGIN_AREA_CODE
             AND TBD.PAR_ROW_ID = TBDP.ROW_ID
             --AND TBD.ACTIVE_FLAG = 'Y'
             --AND TBDP.ACTIVE_FLAG = 'Y'
             ;
        EXCEPTION
          WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20001,
                                    '获取上一级区域信息失败！' || CHR(10) || CHR(13) ||
                                    '区域编码：' || V_BEGIN_AREA_CODE);
        END;
      ELSE
        GOTO GETTRANSPORTLINE;
        EXIT;
      END IF;
    END LOOP;
  
    --获取起始区域是否存在运输线路
    V_BEGIN_AREA_CODE := P_BEGIN_AREA_CODE;
    V_END_AREA_CODE   := P_END_AREA_CODE;
    FOR I IN 1 .. 3 LOOP
      SELECT COUNT(1)
        INTO V_COUNT
        FROM T_LG_TRANSPORT_LINE_LMS TLL
       WHERE TLL.BEGIN_AREA_CODE = V_BEGIN_AREA_CODE
         AND TLL.END_AREA_CODE = V_END_AREA_CODE
         AND NVL(TLL.TRANSPORT_LINE_TYPE, 'DEFAULT') = 'DEFAULT'
         AND TLL.VALID_STATE = 'Y';
      IF NVL(V_COUNT, 0) <= 0 THEN
        BEGIN
          SELECT TBDP.DISTRICT_CODE
            INTO V_END_AREA_CODE
            FROM T_BD_DISTRICT TBD, T_BD_DISTRICT TBDP
           WHERE TBD.DISTRICT_CODE = V_END_AREA_CODE
             AND TBD.PAR_ROW_ID = TBDP.ROW_ID
             --AND TBD.ACTIVE_FLAG = 'Y'
             --AND TBDP.ACTIVE_FLAG = 'Y'
             ;
        EXCEPTION
          WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20001,
                                    '获取上一级区域信息失败！' || CHR(10) || CHR(13) ||
                                    '区域编码：' || V_END_AREA_CODE);
        END;
      ELSE
        GOTO GETTRANSPORTLINE;
        EXIT;
      END IF;
    END LOOP;
  
    --获取起始区域是否存在运输线路
    V_BEGIN_AREA_CODE := P_BEGIN_AREA_CODE;
    V_END_AREA_CODE   := P_END_AREA_CODE;
    FOR I IN 1 .. 3 LOOP
      SELECT COUNT(1)
        INTO V_COUNT
        FROM T_LG_TRANSPORT_LINE_LMS TLL
       WHERE TLL.BEGIN_AREA_CODE = V_BEGIN_AREA_CODE
         AND TLL.END_AREA_CODE = V_END_AREA_CODE
         AND NVL(TLL.TRANSPORT_LINE_TYPE, 'DEFAULT') = 'DEFAULT'
         AND TLL.VALID_STATE = 'Y';
      IF NVL(V_COUNT, 0) <= 0 THEN
        BEGIN
          SELECT TBDP.DISTRICT_CODE
            INTO V_BEGIN_AREA_CODE
            FROM T_BD_DISTRICT TBD, T_BD_DISTRICT TBDP
           WHERE TBD.DISTRICT_CODE = V_BEGIN_AREA_CODE
             AND TBD.PAR_ROW_ID = TBDP.ROW_ID
             --AND TBD.ACTIVE_FLAG = 'Y'
             --AND TBDP.ACTIVE_FLAG = 'Y'
             ;
        EXCEPTION
          WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20001,
                                    '获取上一级区域信息失败！' || CHR(10) || CHR(13) ||
                                    '区域编码：' || V_BEGIN_AREA_CODE);
        END;
      
        BEGIN
          SELECT TBDP.DISTRICT_CODE
            INTO V_END_AREA_CODE
            FROM T_BD_DISTRICT TBD, T_BD_DISTRICT TBDP
           WHERE TBD.DISTRICT_CODE = V_END_AREA_CODE
             AND TBD.PAR_ROW_ID = TBDP.ROW_ID
             --AND TBD.ACTIVE_FLAG = 'Y'
             --AND TBDP.ACTIVE_FLAG = 'Y'
             ;
        EXCEPTION
          WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20001,
                                    '获取上一级区域信息失败！' || CHR(10) || CHR(13) ||
                                    '区域编码：' || V_END_AREA_CODE);
        END;
      ELSE
        GOTO GETTRANSPORTLINE;
        EXIT;
      END IF;
    END LOOP;
  
    <<GETTRANSPORTLINE>>
    SELECT COUNT(1)
      INTO V_COUNT
      FROM T_LG_TRANSPORT_LINE_LMS TLL
     WHERE TLL.END_AREA_CODE = V_END_AREA_CODE
       AND TLL.BEGIN_AREA_CODE = V_BEGIN_AREA_CODE
       AND NVL(TLL.TRANSPORT_LINE_TYPE, 'DEFAULT') = 'DEFAULT'
       AND TLL.VALID_STATE = 'Y';
    IF NVL(V_COUNT, 0) <= 0 OR NVL(V_COUNT, 0) > 1 THEN
      RAISE_APPLICATION_ERROR(-20001,
                              '获取运输线路失败！' || CHR(10) || CHR(13) ||
                              '起始区域编码：' || V_BEGIN_AREA_CODE || CHR(10) ||
                              CHR(13) || '终止区域编码：' || V_END_AREA_CODE ||
                              CHR(10) || CHR(13) ||
                              '未找到对应的运输线路信息或者存在多行有效的线路信息');
    END IF;
  
    FOR R_TRANSPORT_LINE IN (SELECT *
                               FROM T_LG_TRANSPORT_LINE_LMS TLL
                              WHERE TLL.END_AREA_CODE = V_END_AREA_CODE
                                AND TLL.BEGIN_AREA_CODE = V_BEGIN_AREA_CODE
                                AND NVL(TLL.TRANSPORT_LINE_TYPE, 'DEFAULT') = 'DEFAULT'
                                AND TLL.VALID_STATE = 'Y') LOOP
      R_LG_TRANSPORT_LINE := TAB_LG_TRANSPORT_LINE(OBJ_LG_TRANSPORT_LINE(R_TRANSPORT_LINE.ENTITY_ID,
                                                                         R_TRANSPORT_LINE.TRANSPORT_LINE_ID,
                                                                         R_TRANSPORT_LINE.TRANSPORT_LINE_CODE,
                                                                         R_TRANSPORT_LINE.TRANSPORT_LINE_NAME,
                                                                         R_TRANSPORT_LINE.BEGIN_AREA_ID,
                                                                         R_TRANSPORT_LINE.BEGIN_AREA_CODE,
                                                                         R_TRANSPORT_LINE.BEGIN_AREA_NAME,
                                                                         P_BEGIN_AREA_CODE,
                                                                         R_TRANSPORT_LINE.END_AREA_ID,
                                                                         R_TRANSPORT_LINE.END_AREA_CODE,
                                                                         R_TRANSPORT_LINE.END_AREA_NAME,
                                                                         P_END_AREA_CODE,
                                                                         R_TRANSPORT_LINE.MIN_TRANSPORT_VOLUME,
                                                                         R_TRANSPORT_LINE.MAX_TRANSPORT_VOLUME,
                                                                         R_TRANSPORT_LINE.TRANSPORT_MILEAGE,
                                                                         R_TRANSPORT_LINE.SHIP_MODE,
                                                                         R_TRANSPORT_LINE.VALID_STATE,
                                                                         R_TRANSPORT_LINE.TRANSPORT_LINE_DAYS,
                                                                         R_TRANSPORT_LINE.INTEGRAL_TRANSPORT_DAYS,
                                                                         R_TRANSPORT_LINE.SCATTE_TRANSPORT_DAYS,
                                                                         R_TRANSPORT_LINE.Assemble_Line,
                                                                         R_TRANSPORT_LINE.Assemble_Line_Name,
                                                                         R_TRANSPORT_LINE.TRANSPORT_LINE_TYPE,
                                                                         R_TRANSPORT_LINE.PRESCRIPTION,
                                                                         R_TRANSPORT_LINE.PRESCRIPTION_NAME));
    END LOOP;
    RETURN R_LG_TRANSPORT_LINE;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;

  ------------------------------------------------------------------------
  -- Author  : NICRO.LI
  -- Created : 2017-12-1 17:42:02
  -- Purpose : 返回运输线路数据，通过主体过滤数据
  -------------------------------------------------------------------------
  FUNCTION F_GET_LG_TRANSPORT_LINE_NEW(IN_BEGIN_AREA_CODE IN VARCHAR2,
                                       IN_END_AREA_CODE   IN VARCHAR2,
                                       IN_ENTITY_ID       IN NUMBER)
    RETURN TAB_LG_TRANSPORT_LINE IS
  
    R_LG_TRANSPORT_LINE     TAB_LG_TRANSPORT_LINE;
    R_LG_TRANSPORT_LINE_LMS T_LG_TRANSPORT_LINE_LMS%ROWTYPE;
    V_COUNT                 NUMBER;
    V_BEGIN_AREA_CODE       VARCHAR2(32);
    V_END_AREA_CODE         VARCHAR2(32);
  BEGIN
  
    /*--获取起始区域是否存在运输线路
    --1、发货区域上溯，收货区域不变
    V_BEGIN_AREA_CODE := IN_BEGIN_AREA_CODE;
    V_END_AREA_CODE   := IN_END_AREA_CODE;
    FOR I IN 1 .. 3 LOOP
      SELECT COUNT(1)
        INTO V_COUNT
        FROM T_LG_TRANSPORT_LINE_LMS TLL
       WHERE TLL.BEGIN_AREA_CODE = V_BEGIN_AREA_CODE
         AND TLL.END_AREA_CODE = V_END_AREA_CODE
         And TLL.ENTITY_ID = IN_ENTITY_ID
         AND NVL(TLL.TRANSPORT_LINE_TYPE, 'DEFAULT') = 'DEFAULT'
         AND TLL.VALID_STATE = 'Y';
      IF NVL(V_COUNT, 0) <= 0 THEN
        BEGIN
          SELECT TBDP.DISTRICT_CODE
            INTO V_BEGIN_AREA_CODE
            FROM T_BD_DISTRICT TBD, T_BD_DISTRICT TBDP
           WHERE TBD.DISTRICT_CODE = V_BEGIN_AREA_CODE
             AND TBD.PAR_ROW_ID = TBDP.ROW_ID
             --AND TBD.ACTIVE_FLAG = 'Y'
             --AND TBDP.ACTIVE_FLAG = 'Y'
             ;
        EXCEPTION
          WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20001,
                                    '获取上一级区域信息失败！' || CHR(10) || CHR(13) ||
                                    '区域编码：' || V_BEGIN_AREA_CODE);
        END;
      ELSE
        GOTO GETTRANSPORTLINE;
        EXIT;
      END IF;
    END LOOP;
  
    --获取起始区域是否存在运输线路
    --1、发货区域不变，收货区域上溯
    V_BEGIN_AREA_CODE := IN_BEGIN_AREA_CODE;
    V_END_AREA_CODE   := IN_END_AREA_CODE;
    FOR I IN 1 .. 3 LOOP
      SELECT COUNT(1)
        INTO V_COUNT
        FROM T_LG_TRANSPORT_LINE_LMS TLL
       WHERE TLL.BEGIN_AREA_CODE = V_BEGIN_AREA_CODE
         AND TLL.END_AREA_CODE = V_END_AREA_CODE
         AND TLL.ENTITY_ID = IN_ENTITY_ID
         AND NVL(TLL.TRANSPORT_LINE_TYPE, 'DEFAULT') = 'DEFAULT'
         AND TLL.VALID_STATE = 'Y';
      IF NVL(V_COUNT, 0) <= 0 THEN
        BEGIN
          SELECT TBDP.DISTRICT_CODE
            INTO V_END_AREA_CODE
            FROM T_BD_DISTRICT TBD, T_BD_DISTRICT TBDP
           WHERE TBD.DISTRICT_CODE = V_END_AREA_CODE
             AND TBD.PAR_ROW_ID = TBDP.ROW_ID
             --AND TBD.ACTIVE_FLAG = 'Y'
             --AND TBDP.ACTIVE_FLAG = 'Y'
             ;
        EXCEPTION
          WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20001,
                                    '获取上一级区域信息失败！' || CHR(10) || CHR(13) ||
                                    '区域编码：' || V_END_AREA_CODE);
        END;
      ELSE
        GOTO GETTRANSPORTLINE;
        EXIT;
      END IF;
    END LOOP;
  
    --获取起始区域是否存在运输线路
    --发货区域上级不变，收货区域上溯
    V_BEGIN_AREA_CODE := IN_BEGIN_AREA_CODE;
    V_END_AREA_CODE   := IN_END_AREA_CODE;
    
    BEGIN
      SELECT TBDP.DISTRICT_CODE
        INTO V_BEGIN_AREA_CODE
        FROM T_BD_DISTRICT TBD, T_BD_DISTRICT TBDP
       WHERE TBD.DISTRICT_CODE = V_BEGIN_AREA_CODE
         AND TBD.PAR_ROW_ID = TBDP.ROW_ID
         --AND TBD.ACTIVE_FLAG = 'Y'
         --AND TBDP.ACTIVE_FLAG = 'Y'
         ;
    EXCEPTION
      WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20001,
                                '获取上一级区域信息失败！' || CHR(10) || CHR(13) ||
                                '区域编码：' || V_BEGIN_AREA_CODE);
    END;
    
    FOR I IN 1 .. 3 LOOP
      SELECT COUNT(1)
        INTO V_COUNT
        FROM T_LG_TRANSPORT_LINE_LMS TLL
       WHERE TLL.BEGIN_AREA_CODE = V_BEGIN_AREA_CODE
         AND TLL.END_AREA_CODE = V_END_AREA_CODE
         AND TLL.ENTITY_ID = IN_ENTITY_ID
         AND NVL(TLL.TRANSPORT_LINE_TYPE, 'DEFAULT') = 'DEFAULT'
         AND TLL.VALID_STATE = 'Y';
      IF NVL(V_COUNT, 0) <= 0 THEN
        \*BEGIN
          SELECT TBDP.DISTRICT_CODE
            INTO V_BEGIN_AREA_CODE
            FROM T_BD_DISTRICT TBD, T_BD_DISTRICT TBDP
           WHERE TBD.DISTRICT_CODE = V_BEGIN_AREA_CODE
             AND TBD.PAR_ROW_ID = TBDP.ROW_ID
             --AND TBD.ACTIVE_FLAG = 'Y'
             --AND TBDP.ACTIVE_FLAG = 'Y'
             ;
        EXCEPTION
          WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20001,
                                    '获取上一级区域信息失败！' || CHR(10) || CHR(13) ||
                                    '区域编码：' || V_BEGIN_AREA_CODE);
        END;*\
      
        BEGIN
          SELECT TBDP.DISTRICT_CODE
            INTO V_END_AREA_CODE
            FROM T_BD_DISTRICT TBD, T_BD_DISTRICT TBDP
           WHERE TBD.DISTRICT_CODE = V_END_AREA_CODE
             AND TBD.PAR_ROW_ID = TBDP.ROW_ID
             --AND TBD.ACTIVE_FLAG = 'Y'
             --AND TBDP.ACTIVE_FLAG = 'Y'
             ;
        EXCEPTION
          WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20001,
                                    '获取上一级区域信息失败！' || CHR(10) || CHR(13) ||
                                    '区域编码：' || V_END_AREA_CODE);
        END;
      ELSE
        GOTO GETTRANSPORTLINE;
        EXIT;
      END IF;
    END LOOP;
    
    --获取起始区域是否存在运输线路
    --发货区域上溯，收货区域上级不变
    V_BEGIN_AREA_CODE := IN_BEGIN_AREA_CODE;
    V_END_AREA_CODE   := IN_END_AREA_CODE;
    
    BEGIN
      SELECT TBDP.DISTRICT_CODE
        INTO V_END_AREA_CODE
        FROM T_BD_DISTRICT TBD, T_BD_DISTRICT TBDP
       WHERE TBD.DISTRICT_CODE = V_END_AREA_CODE
         AND TBD.PAR_ROW_ID = TBDP.ROW_ID
         --AND TBD.ACTIVE_FLAG = 'Y'
         --AND TBDP.ACTIVE_FLAG = 'Y'
         ;
    EXCEPTION
      WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20001,
                                '获取上一级区域信息失败！' || CHR(10) || CHR(13) ||
                                '区域编码：' || V_END_AREA_CODE);
    END;
    
    FOR I IN 1 .. 3 LOOP
      SELECT COUNT(1)
        INTO V_COUNT
        FROM T_LG_TRANSPORT_LINE_LMS TLL
       WHERE TLL.BEGIN_AREA_CODE = V_BEGIN_AREA_CODE
         AND TLL.END_AREA_CODE = V_END_AREA_CODE
         AND TLL.ENTITY_ID = IN_ENTITY_ID
         AND NVL(TLL.TRANSPORT_LINE_TYPE, 'DEFAULT') = 'DEFAULT'
         AND TLL.VALID_STATE = 'Y';
      IF NVL(V_COUNT, 0) <= 0 THEN
        BEGIN
          SELECT TBDP.DISTRICT_CODE
            INTO V_BEGIN_AREA_CODE
            FROM T_BD_DISTRICT TBD, T_BD_DISTRICT TBDP
           WHERE TBD.DISTRICT_CODE = V_BEGIN_AREA_CODE
             AND TBD.PAR_ROW_ID = TBDP.ROW_ID
             --AND TBD.ACTIVE_FLAG = 'Y'
             --AND TBDP.ACTIVE_FLAG = 'Y'
             ;
        EXCEPTION
          WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20001,
                                    '获取上一级区域信息失败！' || CHR(10) || CHR(13) ||
                                    '区域编码：' || V_BEGIN_AREA_CODE);
        END;
      
        \*BEGIN
          SELECT TBDP.DISTRICT_CODE
            INTO V_END_AREA_CODE
            FROM T_BD_DISTRICT TBD, T_BD_DISTRICT TBDP
           WHERE TBD.DISTRICT_CODE = V_END_AREA_CODE
             AND TBD.PAR_ROW_ID = TBDP.ROW_ID
             --AND TBD.ACTIVE_FLAG = 'Y'
             --AND TBDP.ACTIVE_FLAG = 'Y'
             ;
        EXCEPTION
          WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20001,
                                    '获取上一级区域信息失败！' || CHR(10) || CHR(13) ||
                                    '区域编码：' || V_END_AREA_CODE);
        END;*\
      ELSE
        GOTO GETTRANSPORTLINE;
        EXIT;
      END IF;
    END LOOP;
    
    --获取起始区域是否存在运输线路
    --发货区域上2级不变，收货区域上溯
    V_BEGIN_AREA_CODE := IN_BEGIN_AREA_CODE;
    V_END_AREA_CODE   := IN_END_AREA_CODE;

    BEGIN
      SELECT BD.DISTRICT_CODE
        INTO V_BEGIN_AREA_CODE
        FROM T_BD_DISTRICT TBD, T_BD_DISTRICT TBDP, T_BD_DISTRICT BD
       WHERE TBD.DISTRICT_CODE = V_BEGIN_AREA_CODE
         AND TBD.PAR_ROW_ID = TBDP.ROW_ID
         AND TBDP.PAR_ROW_ID = BD.ROW_ID
         --AND TBD.ACTIVE_FLAG = 'Y'
         --AND TBDP.ACTIVE_FLAG = 'Y'
         ;
    EXCEPTION
      WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20001,
                                '获取上一级区域信息失败！' || CHR(10) || CHR(13) ||
                                '区域编码：' || V_BEGIN_AREA_CODE);
    END;

    FOR I IN 1 .. 3 LOOP
      SELECT COUNT(1)
        INTO V_COUNT
        FROM T_LG_TRANSPORT_LINE_LMS TLL
       WHERE TLL.BEGIN_AREA_CODE = V_BEGIN_AREA_CODE
         AND TLL.END_AREA_CODE = V_END_AREA_CODE
         AND TLL.ENTITY_ID = IN_ENTITY_ID
         AND NVL(TLL.TRANSPORT_LINE_TYPE, 'DEFAULT') = 'DEFAULT'
         AND TLL.VALID_STATE = 'Y';
      IF NVL(V_COUNT, 0) <= 0 THEN
        \*BEGIN
          SELECT TBDP.DISTRICT_CODE
            INTO V_BEGIN_AREA_CODE
            FROM T_BD_DISTRICT TBD, T_BD_DISTRICT TBDP
           WHERE TBD.DISTRICT_CODE = V_BEGIN_AREA_CODE
             AND TBD.PAR_ROW_ID = TBDP.ROW_ID
             --AND TBD.ACTIVE_FLAG = 'Y'
             --AND TBDP.ACTIVE_FLAG = 'Y'
             ;
        EXCEPTION
          WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20001,
                                    '获取上一级区域信息失败！' || CHR(10) || CHR(13) ||
                                    '区域编码：' || V_BEGIN_AREA_CODE);
        END;*\

        BEGIN
          SELECT TBDP.DISTRICT_CODE
            INTO V_END_AREA_CODE
            FROM T_BD_DISTRICT TBD, T_BD_DISTRICT TBDP
           WHERE TBD.DISTRICT_CODE = V_END_AREA_CODE
             AND TBD.PAR_ROW_ID = TBDP.ROW_ID
             --AND TBD.ACTIVE_FLAG = 'Y'
             --AND TBDP.ACTIVE_FLAG = 'Y'
             ;
        EXCEPTION
          WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20001,
                                    '获取上一级区域信息失败！' || CHR(10) || CHR(13) ||
                                    '区域编码：' || V_END_AREA_CODE);
        END;
      ELSE
        GOTO GETTRANSPORTLINE;
        EXIT;
      END IF;
    END LOOP;

    --获取起始区域是否存在运输线路
    --发货区域上溯，收货区域上2级不变
    V_BEGIN_AREA_CODE := IN_BEGIN_AREA_CODE;
    V_END_AREA_CODE   := IN_END_AREA_CODE;

    BEGIN
      SELECT BD.DISTRICT_CODE
        INTO V_END_AREA_CODE
        FROM T_BD_DISTRICT TBD, T_BD_DISTRICT TBDP, T_BD_DISTRICT BD
       WHERE TBD.DISTRICT_CODE = V_END_AREA_CODE
         AND TBD.PAR_ROW_ID = TBDP.ROW_ID
         AND TBDP.PAR_ROW_ID = BD.ROW_ID
         --AND TBD.ACTIVE_FLAG = 'Y'
         --AND TBDP.ACTIVE_FLAG = 'Y'
         ;
    EXCEPTION
      WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20001,
                                '获取上一级区域信息失败！' || CHR(10) || CHR(13) ||
                                '区域编码：' || V_END_AREA_CODE);
    END;

    FOR I IN 1 .. 3 LOOP
      SELECT COUNT(1)
        INTO V_COUNT
        FROM T_LG_TRANSPORT_LINE_LMS TLL
       WHERE TLL.BEGIN_AREA_CODE = V_BEGIN_AREA_CODE
         AND TLL.END_AREA_CODE = V_END_AREA_CODE
         AND TLL.ENTITY_ID = IN_ENTITY_ID
         AND NVL(TLL.TRANSPORT_LINE_TYPE, 'DEFAULT') = 'DEFAULT'
         AND TLL.VALID_STATE = 'Y';
      IF NVL(V_COUNT, 0) <= 0 THEN
        BEGIN
          SELECT TBDP.DISTRICT_CODE
            INTO V_BEGIN_AREA_CODE
            FROM T_BD_DISTRICT TBD, T_BD_DISTRICT TBDP
           WHERE TBD.DISTRICT_CODE = V_BEGIN_AREA_CODE
             AND TBD.PAR_ROW_ID = TBDP.ROW_ID
             --AND TBD.ACTIVE_FLAG = 'Y'
             --AND TBDP.ACTIVE_FLAG = 'Y'
             ;
        EXCEPTION
          WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20001,
                                    '获取上一级区域信息失败！' || CHR(10) || CHR(13) ||
                                    '区域编码：' || V_BEGIN_AREA_CODE);
        END;

        \*BEGIN
          SELECT TBDP.DISTRICT_CODE
            INTO V_END_AREA_CODE
            FROM T_BD_DISTRICT TBD, T_BD_DISTRICT TBDP
           WHERE TBD.DISTRICT_CODE = V_END_AREA_CODE
             AND TBD.PAR_ROW_ID = TBDP.ROW_ID
             --AND TBD.ACTIVE_FLAG = 'Y'
             --AND TBDP.ACTIVE_FLAG = 'Y'
             ;
        EXCEPTION
          WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20001,
                                    '获取上一级区域信息失败！' || CHR(10) || CHR(13) ||
                                    '区域编码：' || V_END_AREA_CODE);
        END;*\
      ELSE
        GOTO GETTRANSPORTLINE;
        EXIT;
      END IF;
    END LOOP;
  
    <<GETTRANSPORTLINE>>
    SELECT COUNT(1)
      INTO V_COUNT
      FROM T_LG_TRANSPORT_LINE_LMS TLL
     WHERE TLL.END_AREA_CODE = V_END_AREA_CODE
       AND TLL.BEGIN_AREA_CODE = V_BEGIN_AREA_CODE
       AND TLL.ENTITY_ID = IN_ENTITY_ID
       AND NVL(TLL.TRANSPORT_LINE_TYPE, 'DEFAULT') = 'DEFAULT'
       AND TLL.VALID_STATE = 'Y';
    IF NVL(V_COUNT, 0) <= 0 OR NVL(V_COUNT, 0) > 1 THEN
      RAISE_APPLICATION_ERROR(-20001,
                              '获取运输线路失败！' || CHR(10) || CHR(13) ||
                              '起始区域编码：' || V_BEGIN_AREA_CODE || CHR(10) ||
                              CHR(13) || '终止区域编码：' || V_END_AREA_CODE ||
                              CHR(10) || CHR(13) ||
                              '未找到对应的运输线路信息或者存在多行有效的线路信息');
    END IF;
  
    FOR R_TRANSPORT_LINE IN (SELECT *
                               FROM T_LG_TRANSPORT_LINE_LMS TLL
                              WHERE TLL.END_AREA_CODE = V_END_AREA_CODE
                                AND TLL.BEGIN_AREA_CODE = V_BEGIN_AREA_CODE
                                AND TLL.ENTITY_ID = IN_ENTITY_ID
                                AND NVL(TLL.TRANSPORT_LINE_TYPE, 'DEFAULT') = 'DEFAULT'
                                AND TLL.VALID_STATE = 'Y') LOOP
      R_LG_TRANSPORT_LINE := TAB_LG_TRANSPORT_LINE(OBJ_LG_TRANSPORT_LINE(R_TRANSPORT_LINE.ENTITY_ID,
                                                                         R_TRANSPORT_LINE.TRANSPORT_LINE_ID,
                                                                         R_TRANSPORT_LINE.TRANSPORT_LINE_CODE,
                                                                         R_TRANSPORT_LINE.TRANSPORT_LINE_NAME,
                                                                         R_TRANSPORT_LINE.BEGIN_AREA_ID,
                                                                         R_TRANSPORT_LINE.BEGIN_AREA_CODE,
                                                                         R_TRANSPORT_LINE.BEGIN_AREA_NAME,
                                                                         IN_BEGIN_AREA_CODE,
                                                                         R_TRANSPORT_LINE.END_AREA_ID,
                                                                         R_TRANSPORT_LINE.END_AREA_CODE,
                                                                         R_TRANSPORT_LINE.END_AREA_NAME,
                                                                         IN_END_AREA_CODE,
                                                                         R_TRANSPORT_LINE.MIN_TRANSPORT_VOLUME,
                                                                         R_TRANSPORT_LINE.MAX_TRANSPORT_VOLUME,
                                                                         R_TRANSPORT_LINE.TRANSPORT_MILEAGE,
                                                                         R_TRANSPORT_LINE.SHIP_MODE,
                                                                         R_TRANSPORT_LINE.VALID_STATE,
                                                                         R_TRANSPORT_LINE.TRANSPORT_LINE_DAYS,
                                                                         R_TRANSPORT_LINE.INTEGRAL_TRANSPORT_DAYS,
                                                                         R_TRANSPORT_LINE.SCATTE_TRANSPORT_DAYS,
                                                                         R_TRANSPORT_LINE.ASSEMBLE_LINE,
                                                                         R_TRANSPORT_LINE.ASSEMBLE_LINE_NAME,
                                                                         R_TRANSPORT_LINE.TRANSPORT_LINE_TYPE,
                                                                         R_TRANSPORT_LINE.PRESCRIPTION,
                                                                         R_TRANSPORT_LINE.PRESCRIPTION_NAME));
    END LOOP;
    RETURN R_LG_TRANSPORT_LINE;*/
    RETURN PKG_PLN_REPORT.F_GET_LG_TRANSPORT_LINE_PROD(IN_BEGIN_AREA_CODE, IN_END_AREA_CODE, NULL, IN_ENTITY_ID);
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;
  
  ------------------------------------------------------------------------
  -- Author  : hejy3
  -- Created : 2018-11-28
  -- Purpose : 返回集拼运输线路数据，通过主体过滤数据
  -------------------------------------------------------------------------
  FUNCTION F_GET_LG_TRANSPORT_LINE_PROD(IN_BEGIN_AREA_CODE IN VARCHAR2,
                                        IN_END_AREA_CODE   IN VARCHAR2,
                                        IN_TRANSPORT_LINE_TYPE IN VARCHAR2,
                                        IN_ENTITY_ID       IN NUMBER)
    RETURN TAB_LG_TRANSPORT_LINE IS
    R_LG_TRANSPORT_LINE     TAB_LG_TRANSPORT_LINE;
    R_LG_TRANSPORT_LINE_LMS T_LG_TRANSPORT_LINE_LMS%ROWTYPE;
    V_COUNT                 NUMBER;
    V_BEGIN_AREA_CODE       VARCHAR2(32);
    V_END_AREA_CODE         VARCHAR2(32);
    V_TRANSPORT_LINE_TYPE   VARCHAR2(32);
    V_PRESCRIPTION          VARCHAR2(32);
  BEGIN
    IF IN_TRANSPORT_LINE_TYPE IS NOT NULL THEN
      V_TRANSPORT_LINE_TYPE := 'TRANSPORT_PRODUCT';
      V_PRESCRIPTION := IN_TRANSPORT_LINE_TYPE;
    ELSE
      V_TRANSPORT_LINE_TYPE := 'DEFAULT';
      V_PRESCRIPTION := NULL;
    END IF;
    --获取起始区域是否存在运输线路
    --1、发货区域上溯，收货区域不变
    V_BEGIN_AREA_CODE := IN_BEGIN_AREA_CODE;
    V_END_AREA_CODE   := IN_END_AREA_CODE;
    FOR I IN 1 .. 3 LOOP
      SELECT COUNT(1)
        INTO V_COUNT
        FROM T_LG_TRANSPORT_LINE_LMS TLL
       WHERE TLL.BEGIN_AREA_CODE = V_BEGIN_AREA_CODE
         AND TLL.END_AREA_CODE = V_END_AREA_CODE
         And TLL.ENTITY_ID = IN_ENTITY_ID
         AND TLL.TRANSPORT_LINE_TYPE = V_TRANSPORT_LINE_TYPE
         AND NVL(TLL.PRESCRIPTION, '_') = NVL(V_PRESCRIPTION, '_')
         AND TLL.VALID_STATE = 'Y';
      IF NVL(V_COUNT, 0) <= 0 THEN
        BEGIN
          SELECT TBDP.DISTRICT_CODE
            INTO V_BEGIN_AREA_CODE
            FROM T_BD_DISTRICT TBD, T_BD_DISTRICT TBDP
           WHERE TBD.DISTRICT_CODE = V_BEGIN_AREA_CODE
             AND TBD.PAR_ROW_ID = TBDP.ROW_ID
             ;
        EXCEPTION
          WHEN OTHERS THEN
            /*RAISE_APPLICATION_ERROR(-20001,
                                    '获取上一级区域信息失败！' || CHR(10) || CHR(13) ||
                                    '区域编码：' || V_BEGIN_AREA_CODE);*/
            NULL;
        END;
      ELSE
        GOTO GETTRANSPORTLINE;
        EXIT;
      END IF;
    END LOOP;
  
    --获取起始区域是否存在运输线路
    --1、发货区域不变，收货区域上溯
    V_BEGIN_AREA_CODE := IN_BEGIN_AREA_CODE;
    V_END_AREA_CODE   := IN_END_AREA_CODE;
    FOR I IN 1 .. 3 LOOP
      SELECT COUNT(1)
        INTO V_COUNT
        FROM T_LG_TRANSPORT_LINE_LMS TLL
       WHERE TLL.BEGIN_AREA_CODE = V_BEGIN_AREA_CODE
         AND TLL.END_AREA_CODE = V_END_AREA_CODE
         AND TLL.ENTITY_ID = IN_ENTITY_ID
         AND TLL.TRANSPORT_LINE_TYPE = V_TRANSPORT_LINE_TYPE
         AND NVL(TLL.PRESCRIPTION, '_') = NVL(V_PRESCRIPTION, '_')
         AND TLL.VALID_STATE = 'Y';
      IF NVL(V_COUNT, 0) <= 0 THEN
        BEGIN
          SELECT TBDP.DISTRICT_CODE
            INTO V_END_AREA_CODE
            FROM T_BD_DISTRICT TBD, T_BD_DISTRICT TBDP
           WHERE TBD.DISTRICT_CODE = V_END_AREA_CODE
             AND TBD.PAR_ROW_ID = TBDP.ROW_ID
             ;
        EXCEPTION
          WHEN OTHERS THEN
            /*RAISE_APPLICATION_ERROR(-20001,
                                    '获取上一级区域信息失败！' || CHR(10) || CHR(13) ||
                                    '区域编码：' || V_END_AREA_CODE);*/
            NULL;
        END;
      ELSE
        GOTO GETTRANSPORTLINE;
        EXIT;
      END IF;
    END LOOP;
  
    --获取起始区域是否存在运输线路
    --发货区域上级不变，收货区域上溯
    V_BEGIN_AREA_CODE := IN_BEGIN_AREA_CODE;
    V_END_AREA_CODE   := IN_END_AREA_CODE;
    
    BEGIN
      SELECT TBDP.DISTRICT_CODE
        INTO V_BEGIN_AREA_CODE
        FROM T_BD_DISTRICT TBD, T_BD_DISTRICT TBDP
       WHERE TBD.DISTRICT_CODE = V_BEGIN_AREA_CODE
         AND TBD.PAR_ROW_ID = TBDP.ROW_ID
         ;
    EXCEPTION
      WHEN OTHERS THEN
        /*RAISE_APPLICATION_ERROR(-20001,
                                '获取上一级区域信息失败！' || CHR(10) || CHR(13) ||
                                '区域编码：' || V_BEGIN_AREA_CODE);*/
        NULL;
    END;
    
    FOR I IN 1 .. 3 LOOP
      SELECT COUNT(1)
        INTO V_COUNT
        FROM T_LG_TRANSPORT_LINE_LMS TLL
       WHERE TLL.BEGIN_AREA_CODE = V_BEGIN_AREA_CODE
         AND TLL.END_AREA_CODE = V_END_AREA_CODE
         AND TLL.ENTITY_ID = IN_ENTITY_ID
         AND TLL.TRANSPORT_LINE_TYPE = V_TRANSPORT_LINE_TYPE
         AND NVL(TLL.PRESCRIPTION, '_') = NVL(V_PRESCRIPTION, '_')
         AND TLL.VALID_STATE = 'Y';
      IF NVL(V_COUNT, 0) <= 0 THEN
        BEGIN
          SELECT TBDP.DISTRICT_CODE
            INTO V_END_AREA_CODE
            FROM T_BD_DISTRICT TBD, T_BD_DISTRICT TBDP
           WHERE TBD.DISTRICT_CODE = V_END_AREA_CODE
             AND TBD.PAR_ROW_ID = TBDP.ROW_ID
             ;
        EXCEPTION
          WHEN OTHERS THEN
            /*RAISE_APPLICATION_ERROR(-20001,
                                    '获取上一级区域信息失败！' || CHR(10) || CHR(13) ||
                                    '区域编码：' || V_END_AREA_CODE);*/
            NULL;
        END;
      ELSE
        GOTO GETTRANSPORTLINE;
        EXIT;
      END IF;
    END LOOP;
    
    --获取起始区域是否存在运输线路
    --发货区域上溯，收货区域上级不变
    V_BEGIN_AREA_CODE := IN_BEGIN_AREA_CODE;
    V_END_AREA_CODE   := IN_END_AREA_CODE;
    
    BEGIN
      SELECT TBDP.DISTRICT_CODE
        INTO V_END_AREA_CODE
        FROM T_BD_DISTRICT TBD, T_BD_DISTRICT TBDP
       WHERE TBD.DISTRICT_CODE = V_END_AREA_CODE
         AND TBD.PAR_ROW_ID = TBDP.ROW_ID
         ;
    EXCEPTION
      WHEN OTHERS THEN
        /*RAISE_APPLICATION_ERROR(-20001,
                                '获取上一级区域信息失败！' || CHR(10) || CHR(13) ||
                                '区域编码：' || V_END_AREA_CODE);*/
        NULL;
    END;
    
    FOR I IN 1 .. 3 LOOP
      SELECT COUNT(1)
        INTO V_COUNT
        FROM T_LG_TRANSPORT_LINE_LMS TLL
       WHERE TLL.BEGIN_AREA_CODE = V_BEGIN_AREA_CODE
         AND TLL.END_AREA_CODE = V_END_AREA_CODE
         AND TLL.ENTITY_ID = IN_ENTITY_ID
         AND TLL.TRANSPORT_LINE_TYPE = V_TRANSPORT_LINE_TYPE
         AND NVL(TLL.PRESCRIPTION, '_') = NVL(V_PRESCRIPTION, '_')
         AND TLL.VALID_STATE = 'Y';
      IF NVL(V_COUNT, 0) <= 0 THEN
        BEGIN
          SELECT TBDP.DISTRICT_CODE
            INTO V_BEGIN_AREA_CODE
            FROM T_BD_DISTRICT TBD, T_BD_DISTRICT TBDP
           WHERE TBD.DISTRICT_CODE = V_BEGIN_AREA_CODE
             AND TBD.PAR_ROW_ID = TBDP.ROW_ID
             ;
        EXCEPTION
          WHEN OTHERS THEN
            /*RAISE_APPLICATION_ERROR(-20001,
                                    '获取上一级区域信息失败！' || CHR(10) || CHR(13) ||
                                    '区域编码：' || V_BEGIN_AREA_CODE);*/
            NULL;
        END;
      ELSE
        GOTO GETTRANSPORTLINE;
        EXIT;
      END IF;
    END LOOP;
    
    --获取起始区域是否存在运输线路
    --发货区域上2级不变，收货区域上溯
    V_BEGIN_AREA_CODE := IN_BEGIN_AREA_CODE;
    V_END_AREA_CODE   := IN_END_AREA_CODE;

    BEGIN
      SELECT BD.DISTRICT_CODE
        INTO V_BEGIN_AREA_CODE
        FROM T_BD_DISTRICT TBD, T_BD_DISTRICT TBDP, T_BD_DISTRICT BD
       WHERE TBD.DISTRICT_CODE = V_BEGIN_AREA_CODE
         AND TBD.PAR_ROW_ID = TBDP.ROW_ID
         AND TBDP.PAR_ROW_ID = BD.ROW_ID
         ;
    EXCEPTION
      WHEN OTHERS THEN
        /*RAISE_APPLICATION_ERROR(-20001,
                                '获取上一级区域信息失败！' || CHR(10) || CHR(13) ||
                                '区域编码：' || V_BEGIN_AREA_CODE);*/
        NULL;
    END;

    FOR I IN 1 .. 3 LOOP
      SELECT COUNT(1)
        INTO V_COUNT
        FROM T_LG_TRANSPORT_LINE_LMS TLL
       WHERE TLL.BEGIN_AREA_CODE = V_BEGIN_AREA_CODE
         AND TLL.END_AREA_CODE = V_END_AREA_CODE
         AND TLL.ENTITY_ID = IN_ENTITY_ID
         AND TLL.TRANSPORT_LINE_TYPE = V_TRANSPORT_LINE_TYPE
         AND NVL(TLL.PRESCRIPTION, '_') = NVL(V_PRESCRIPTION, '_')
         AND TLL.VALID_STATE = 'Y';
      IF NVL(V_COUNT, 0) <= 0 THEN
        BEGIN
          SELECT TBDP.DISTRICT_CODE
            INTO V_END_AREA_CODE
            FROM T_BD_DISTRICT TBD, T_BD_DISTRICT TBDP
           WHERE TBD.DISTRICT_CODE = V_END_AREA_CODE
             AND TBD.PAR_ROW_ID = TBDP.ROW_ID
             ;
        EXCEPTION
          WHEN OTHERS THEN
            /*RAISE_APPLICATION_ERROR(-20001,
                                    '获取上一级区域信息失败！' || CHR(10) || CHR(13) ||
                                    '区域编码：' || V_END_AREA_CODE);*/
           NULL;
        END;
      ELSE
        GOTO GETTRANSPORTLINE;
        EXIT;
      END IF;
    END LOOP;

    --获取起始区域是否存在运输线路
    --发货区域上溯，收货区域上2级不变
    V_BEGIN_AREA_CODE := IN_BEGIN_AREA_CODE;
    V_END_AREA_CODE   := IN_END_AREA_CODE;

    BEGIN
      SELECT BD.DISTRICT_CODE
        INTO V_END_AREA_CODE
        FROM T_BD_DISTRICT TBD, T_BD_DISTRICT TBDP, T_BD_DISTRICT BD
       WHERE TBD.DISTRICT_CODE = V_END_AREA_CODE
         AND TBD.PAR_ROW_ID = TBDP.ROW_ID
         AND TBDP.PAR_ROW_ID = BD.ROW_ID
         ;
    EXCEPTION
      WHEN OTHERS THEN
        /*RAISE_APPLICATION_ERROR(-20001,
                                '获取上一级区域信息失败！' || CHR(10) || CHR(13) ||
                                '区域编码：' || V_END_AREA_CODE);*/
        NULL;
    END;

    FOR I IN 1 .. 3 LOOP
      SELECT COUNT(1)
        INTO V_COUNT
        FROM T_LG_TRANSPORT_LINE_LMS TLL
       WHERE TLL.BEGIN_AREA_CODE = V_BEGIN_AREA_CODE
         AND TLL.END_AREA_CODE = V_END_AREA_CODE
         AND TLL.ENTITY_ID = IN_ENTITY_ID
         AND TLL.TRANSPORT_LINE_TYPE = V_TRANSPORT_LINE_TYPE
         AND NVL(TLL.PRESCRIPTION, '_') = NVL(V_PRESCRIPTION, '_')
         AND TLL.VALID_STATE = 'Y';
      IF NVL(V_COUNT, 0) <= 0 THEN
        BEGIN
          SELECT TBDP.DISTRICT_CODE
            INTO V_BEGIN_AREA_CODE
            FROM T_BD_DISTRICT TBD, T_BD_DISTRICT TBDP
           WHERE TBD.DISTRICT_CODE = V_BEGIN_AREA_CODE
             AND TBD.PAR_ROW_ID = TBDP.ROW_ID
             ;
        EXCEPTION
          WHEN OTHERS THEN
            /*RAISE_APPLICATION_ERROR(-20001,
                                    '获取上一级区域信息失败！' || CHR(10) || CHR(13) ||
                                    '区域编码：' || V_BEGIN_AREA_CODE);*/
            NULL;
        END;
      ELSE
        GOTO GETTRANSPORTLINE;
        EXIT;
      END IF;
    END LOOP;
  
    <<GETTRANSPORTLINE>>
    SELECT COUNT(1)
      INTO V_COUNT
      FROM T_LG_TRANSPORT_LINE_LMS TLL
     WHERE TLL.END_AREA_CODE = V_END_AREA_CODE
       AND TLL.BEGIN_AREA_CODE = V_BEGIN_AREA_CODE
       AND TLL.ENTITY_ID = IN_ENTITY_ID
       AND TLL.TRANSPORT_LINE_TYPE = V_TRANSPORT_LINE_TYPE
       AND NVL(TLL.PRESCRIPTION, '_') = NVL(V_PRESCRIPTION, '_')
       AND TLL.VALID_STATE = 'Y';
    IF (NVL(V_COUNT, 0) <= 0 OR NVL(V_COUNT, 0) > 1) AND IN_TRANSPORT_LINE_TYPE = 'DEFAULT' THEN
      RAISE_APPLICATION_ERROR(-20001,
                              '获取运输线路失败！' || CHR(10) || CHR(13) ||
                              '起始区域编码：' || V_BEGIN_AREA_CODE || CHR(10) ||
                              CHR(13) || '终止区域编码：' || V_END_AREA_CODE ||
                              CHR(10) || CHR(13) ||
                              '未找到对应的运输线路信息或者存在多行有效的线路信息');
    END IF;
  
    FOR R_TRANSPORT_LINE IN (SELECT *
                               FROM T_LG_TRANSPORT_LINE_LMS TLL
                              WHERE TLL.END_AREA_CODE = V_END_AREA_CODE
                                AND TLL.BEGIN_AREA_CODE = V_BEGIN_AREA_CODE
                                AND TLL.ENTITY_ID = IN_ENTITY_ID
                                AND TLL.TRANSPORT_LINE_TYPE = V_TRANSPORT_LINE_TYPE
                                AND NVL(TLL.PRESCRIPTION, '_') = NVL(V_PRESCRIPTION, '_')
                                AND TLL.VALID_STATE = 'Y') LOOP
      R_LG_TRANSPORT_LINE := TAB_LG_TRANSPORT_LINE(OBJ_LG_TRANSPORT_LINE(R_TRANSPORT_LINE.ENTITY_ID,
                                                                         R_TRANSPORT_LINE.TRANSPORT_LINE_ID,
                                                                         R_TRANSPORT_LINE.TRANSPORT_LINE_CODE,
                                                                         R_TRANSPORT_LINE.TRANSPORT_LINE_NAME,
                                                                         R_TRANSPORT_LINE.BEGIN_AREA_ID,
                                                                         R_TRANSPORT_LINE.BEGIN_AREA_CODE,
                                                                         R_TRANSPORT_LINE.BEGIN_AREA_NAME,
                                                                         IN_BEGIN_AREA_CODE,
                                                                         R_TRANSPORT_LINE.END_AREA_ID,
                                                                         R_TRANSPORT_LINE.END_AREA_CODE,
                                                                         R_TRANSPORT_LINE.END_AREA_NAME,
                                                                         IN_END_AREA_CODE,
                                                                         R_TRANSPORT_LINE.MIN_TRANSPORT_VOLUME,
                                                                         R_TRANSPORT_LINE.MAX_TRANSPORT_VOLUME,
                                                                         R_TRANSPORT_LINE.TRANSPORT_MILEAGE,
                                                                         R_TRANSPORT_LINE.SHIP_MODE,
                                                                         R_TRANSPORT_LINE.VALID_STATE,
                                                                         R_TRANSPORT_LINE.TRANSPORT_LINE_DAYS,
                                                                         R_TRANSPORT_LINE.INTEGRAL_TRANSPORT_DAYS,
                                                                         R_TRANSPORT_LINE.SCATTE_TRANSPORT_DAYS,
                                                                         R_TRANSPORT_LINE.ASSEMBLE_LINE,
                                                                         R_TRANSPORT_LINE.ASSEMBLE_LINE_NAME,
                                                                         R_TRANSPORT_LINE.TRANSPORT_LINE_TYPE,
                                                                         R_TRANSPORT_LINE.PRESCRIPTION,
                                                                         R_TRANSPORT_LINE.PRESCRIPTION_NAME));
    END LOOP;
    RETURN R_LG_TRANSPORT_LINE;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;

  ------------------------------------------------------------------------
  -- Author  : lilh6
  -- Created : 2018-12-26
  -- Purpose : 返回下线直发仓库信息，通过产地，中心，主体过滤数据
  -------------------------------------------------------------------------
  Function f_Get_Lg_Transport_Line_Inv(In_Producing_Area_Id In Number,
                                       In_Sales_Center_Code In Varchar2,
                                       In_End_Area_Code     In Varchar2,
                                       In_Entity_Id         In Number)
    Return Tab_Lg_Transport_Line Is
    r_Lg_Transport_Line Tab_Lg_Transport_Line;
    v_Begin_Area_Code   Varchar2(32);
  Begin
    Select t.District_Code
      Into v_Begin_Area_Code
      From (Select Dr.Inventory_Id,
                   Dr.Inventory_Code,
                   Dr.Inventory_Name,
                   Ii.District_Id
              From t_Pln_Inv_Direct_Relation Dr,
                   t_Inv_Inventories         Ii,
                   t_Inv_Organization        Io
             Where Dr.Producing_Area_Id = In_Producing_Area_Id
               And Dr.Entity_Id = In_Entity_Id
               And Dr.Inventory_Id = Ii.Inventory_Id
               And Sysdate Between Dr.Begin_Date And
                   Nvl(Dr.End_Date, Sysdate + 1)
               And Ii.Organization_Id = Io.Organization_Id
               And Ii.Entity_Id = Io.Entity_Id
               And Io.Operating_Unit =
                   (Select Distinct Io.Operating_Unit
                      From t_Pln_Prdc_Area_Ec_Inventory Aei,
                           t_Inv_Inventories            Ii,
                           t_Inv_Organization           Io
                     Where Aei.Producing_Area_Id = In_Producing_Area_Id
                       And Aei.Entity_Id = In_Entity_Id
                       And Aei.Sales_Center_Code = In_Sales_Center_Code
                       And Aei.Workorder_Flag = 'Y'
                       And Sysdate Between Aei.Begin_Date And
                           Nvl(Aei.End_Date, Sysdate + 1)
                       And Aei.Inventory_Id = Ii.Inventory_Id
                       And Ii.Organization_Id = Io.Organization_Id
                       And Io.Entity_Id = Ii.Entity_Id)
            Union All
            Select Dr.Inventory_Id,
                   Dr.Inventory_Code,
                   Dr.Inventory_Name,
                   Ii.District_Id
              From t_Pln_Inv_Direct_Relation Dr,
                   t_Inv_Inventories         Ii,
                   t_Inv_Organization        Io
             Where Dr.Producing_Area_Id = In_Producing_Area_Id
               And Dr.Entity_Id = In_Entity_Id
               And Dr.Inventory_Id = Ii.Inventory_Id
               And Sysdate Between Dr.Begin_Date And
                   Nvl(Dr.End_Date, Sysdate + 1)
               And Ii.Organization_Id = Io.Organization_Id
               And Ii.Entity_Id = Io.Entity_Id
               And Io.Operating_Unit =
                   (Select Distinct Io.Operating_Unit
                      From t_Pln_Prdc_Area_Rcv_Inventory Ari,
                           t_Inv_Inventories             Ii,
                           t_Inv_Organization            Io
                     Where Ari.Producing_Area_Id = In_Producing_Area_Id
                       And Ari.Entity_Id = In_Entity_Id
                       And Ari.Workorder_Flag = 'Y'
                       And Ari.Is_Default_Inv = 'Y'
                       And Sysdate Between Ari.Begin_Date And
                           Nvl(Ari.End_Date, Sysdate + 1)
                       And Ari.Inventory_Id = Ii.Inventory_Id
                       And Ii.Organization_Id = Io.Organization_Id
                       And Io.Entity_Id = Ii.Entity_Id)) r,
           t_Bd_District t
     Where t.Row_Id = r.District_Id
       And Rownum = 1;
  
    Return Pkg_Pln_Report.f_Get_Lg_Transport_Line_Prod(v_Begin_Area_Code,
                                                       In_End_Area_Code,
                                                       Null,
                                                       In_Entity_Id);
  Exception
    When Others Then
      Return Null;
  End;
  
END PKG_PLN_REPORT;
/

