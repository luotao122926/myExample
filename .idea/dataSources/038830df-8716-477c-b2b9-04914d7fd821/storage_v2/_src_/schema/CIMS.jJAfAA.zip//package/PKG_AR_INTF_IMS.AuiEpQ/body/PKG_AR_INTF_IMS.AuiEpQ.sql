create PACKAGE BODY PKG_AR_INTF_IMS IS

  -- 到款接口表数据插入业务表
  PROCEDURE P_PURCHASEFEETURNFEE_IMS(P_REFUND_APPLY_ID in number, --批处理ID
                                     P_MESSAGE         out varchar2 --成功则返回“SUCCESS”，否则返回出错信息
                                     ) is
    PRAGMA AUTONOMOUS_TRANSACTION;
    --通过批处理ID以游标方式获取要处理的数据
    CURSOR C_PURCHASEFEE IS
      SELECT *
        FROM intf_ar_cash_receipt_headers
       WHERE intf_ar_cash_receipt_headers.refund_apply_id =
             P_REFUND_APPLY_ID
         and intf_ar_cash_receipt_headers.status = '01';

    PURCHASEFEE_ROW         C_PURCHASEFEE%ROWTYPE; --游标行数据
    DATACOUNT               number; --数据数量
    DATACOUNT1              number; --用于校验RECEIPT_METHOD_ID
    DATACOUNT3              number; --用于校验ACCOUNT_ID、CUSTOMER_ID、ENTITY_ID是否存在
    V_CASH_RECEIPT_ID       number; --收款单据ID
    V_CASH_RECEIPT_LINES_ID number; --收款单据行ID
    V_CASH_RECEIPT_CODE     varchar2(32); --收款单据号
    V_SALES_CENTER_ID       number; --营销中心ID
    V_BIZ_EXCEPTION EXCEPTION; --自定义业务异常

    V_DEFLAUT_SALE_MAIN_TYPE_COUNT  NUMBER;
    V_DEFLAUT_SALE_MAIN_TYPE_CODE   VARCHAR2(50);

  BEGIN
    P_MESSAGE := '执行处理';
    --获取接口表数据数量
    select count(*)
      INTO DATACOUNT
      from intf_ar_cash_receipt_headers t
     where t.refund_apply_id = P_REFUND_APPLY_ID
       and t.status = '01';

    if (DATACOUNT > 0) THEN
      BEGIN
        --FOR I IN 1 .. DATACOUNT LOOP
        FOR PURCHASEFEE_ROW IN C_PURCHASEFEE LOOP
          --校验承兑银行号是否为空
          if (PURCHASEFEE_ROW.Acceptance_Bank_Name is null) THEN
            --更新接口表状态为03：校验失败
            P_MESSAGE := '校验失败,承兑银行号为空！';
            UPDATE intf_ar_cash_receipt_headers
               SET STATUS = '03', ERROR_INFO = P_MESSAGE
             WHERE CASH_RECEIPT_ID = PURCHASEFEE_ROW.CASH_RECEIPT_ID
               and refund_apply_id = P_REFUND_APPLY_ID;

            UPDATE INTF_AR_CASH_RECEIPT_LINES
               SET STATUS = '03', ERROR_INFO = P_MESSAGE
             WHERE CASH_RECEIPT_ID = PURCHASEFEE_ROW.CASH_RECEIPT_ID;
          else
            --校验AMOUNT是否是负数
            if (PURCHASEFEE_ROW.Amount < 0) THEN
              --更新接口表状态为03：校验失败
              P_MESSAGE := '校验失败,AMOUNT是负数！';
              UPDATE intf_ar_cash_receipt_headers
                 SET STATUS = '03', ERROR_INFO = P_MESSAGE
               WHERE CASH_RECEIPT_ID = PURCHASEFEE_ROW.CASH_RECEIPT_ID
                 and refund_apply_id = P_REFUND_APPLY_ID;

              UPDATE INTF_AR_CASH_RECEIPT_LINES
                 SET STATUS = '03', ERROR_INFO = P_MESSAGE
               WHERE CASH_RECEIPT_ID = PURCHASEFEE_ROW.CASH_RECEIPT_ID;

            else

              --校验ACCOUNT_ID、CUSTOMER_ID、ENTITY_ID是否存在
              select count(*)
                INTO DATACOUNT3
                from V_CUST_ACCOUNT t
               where t.account_id = PURCHASEFEE_ROW.Account_Id
                 and t.customer_id = PURCHASEFEE_ROW.Customer_Id
                 and t.entity_id = PURCHASEFEE_ROW.Entity_Id;

              if (DATACOUNT3 = 0) THEN
                --更新接口表状态为03：校验失败
                P_MESSAGE := '校验失败,ACCOUNT_ID、CUSTOMER_ID、ENTITY_ID值错误！';
                UPDATE intf_ar_cash_receipt_headers
                   SET STATUS = '03', ERROR_INFO = P_MESSAGE
                 WHERE CASH_RECEIPT_ID = PURCHASEFEE_ROW.CASH_RECEIPT_ID
                   and refund_apply_id = P_REFUND_APPLY_ID;

                UPDATE INTF_AR_CASH_RECEIPT_LINES
                   SET STATUS = '03', ERROR_INFO = P_MESSAGE
                 WHERE CASH_RECEIPT_ID = PURCHASEFEE_ROW.CASH_RECEIPT_ID;

              else
                --校验RECEIPT_METHOD_ID
                select count(*)
                  INTO DATACOUNT1
                  from V_AR_RECEIPT_METHODS t
                 where t.receipt_method_id =
                       PURCHASEFEE_ROW.RECEIPT_METHOD_ID
                   and t.entity_id = PURCHASEFEE_ROW.Entity_Id;

                if (DATACOUNT1 = 0) THEN
                  --更新接口表状态为03：校验失败
                  P_MESSAGE := '校验失败,RECEIPT_METHOD_ID值错误！';
                  UPDATE intf_ar_cash_receipt_headers
                     SET STATUS = '03', ERROR_INFO = P_MESSAGE
                   WHERE CASH_RECEIPT_ID = PURCHASEFEE_ROW.CASH_RECEIPT_ID
                     and refund_apply_id = P_REFUND_APPLY_ID;

                  UPDATE INTF_AR_CASH_RECEIPT_LINES
                     SET STATUS = '03', ERROR_INFO = P_MESSAGE
                   WHERE CASH_RECEIPT_ID = PURCHASEFEE_ROW.CASH_RECEIPT_ID;

                else
                  --检验CASH_CODE长度，只能等于16
                  if (length(PURCHASEFEE_ROW.CASH_CODE) >= 30) THEN
                    --更新接口表状态为03：校验失败
                    P_MESSAGE := '校验失败,CASH_CODE长度错误！';
                    UPDATE intf_ar_cash_receipt_headers
                       SET STATUS = '03', ERROR_INFO = P_MESSAGE
                     WHERE CASH_RECEIPT_ID =
                           PURCHASEFEE_ROW.CASH_RECEIPT_ID
                       and refund_apply_id = P_REFUND_APPLY_ID;

                    UPDATE INTF_AR_CASH_RECEIPT_LINES
                       SET STATUS = '03', ERROR_INFO = P_MESSAGE
                     WHERE CASH_RECEIPT_ID =
                           PURCHASEFEE_ROW.CASH_RECEIPT_ID;

                  else
                    --收款单据号
                    BEGIN
                      V_CASH_RECEIPT_CODE := PKG_BD.F_GET_BILL_NO('ARARCODE',
                                                                  null,
                                                                  PURCHASEFEE_ROW.Entity_Id,
                                                                  null);
                    EXCEPTION
                      WHEN OTHERS THEN
                        P_MESSAGE := '取收款单据号失败！';
                        RAISE V_BIZ_EXCEPTION;
                    END;

                    --获取收款单据ID
                    SELECT S_AR_CASH_RECEIPT_HEADERS.NEXTVAL
                      INTO V_CASH_RECEIPT_ID
                      FROM DUAL;

                    --获取收款单据行ID
                    SELECT S_AR_CASH_RECEIPT_LINES.NEXTVAL
                      INTO V_CASH_RECEIPT_LINES_ID
                      FROM DUAL;

                    --获取营销中心ID
                    SELECT distinct w.sales_center_id
                      INTO V_SALES_CENTER_ID
                      FROM v_cust_account w
                     WHERE w.account_id = PURCHASEFEE_ROW.ACCOUNT_ID
                       and w.ENTITY_ID = PURCHASEFEE_ROW.ENTITY_ID;

                    --遍历收款接口表数据，插入收款头表
                    INSERT INTO T_AR_CASH_RECEIPT_HEADERS
                      (CASH_RECEIPT_ID,
                       RECEIPT_METHOD_ID,
                       RECEIPT_STATUS_ID,
                       ACCOUNT_ID,
                       CASH_RECEIPT_CODE,
                       CASH_RECEIPT_DATE,
                       GL_DATE,
                       AMOUNT,
                       CURRENCY_CODE,
                       CASH_CODE,
                       CASH_DATE,
                       DUE_DATE,
                       DRAWER,
                       DRAWER_BANK_ACCOUNT,
                       DRAWER_BANK,
                       BACK_WRITE_NAME,
                       FIRST_RECEIPT_NAME,
                       FIRST_RECEIPT_BANK_ACCOUNT,
                       FIRST_RECEIPT_BANK,
                       ACCEPTANCE_BANK_NAME,
                       BUDGET_ITEM_NAME,
                       CREATED_BY,
                       CREATION_DATE,
                       REMAEK,
                       SALES_CENTER_ID,
                       CUSTOMER_ID,
                       CUSTOMER_CODE,
                       CUSTOMER_NAME,
                       ACCOUNT_CODE,
                       ACCOUNT_NAME,
                       ERP_OU_ID,
                       ERP_OU_NAME,
                       ENTITY_ID,
                       ATTRIBUTE3,
                       SOURCE_TYPE)
                    VALUES
                      (V_CASH_RECEIPT_ID,
                       PURCHASEFEE_ROW.RECEIPT_METHOD_ID,
                       '1', --制单状态
                       PURCHASEFEE_ROW.ACCOUNT_ID,
                       V_CASH_RECEIPT_CODE,
                       NVL(PURCHASEFEE_ROW.CASH_RECEIPT_DATE, SYSDATE),
                       NVL(PURCHASEFEE_ROW.GL_DATE, SYSDATE),
                       PURCHASEFEE_ROW.AMOUNT,
                       PURCHASEFEE_ROW.CURRENCY_CODE,
                       PURCHASEFEE_ROW.CASH_CODE,
                       PURCHASEFEE_ROW.CASH_DATE,
                       PURCHASEFEE_ROW.DUE_DATE,
                       PURCHASEFEE_ROW.DRAWER,
                       PURCHASEFEE_ROW.DRAWER_BANK_ACCOUNT,
                       PURCHASEFEE_ROW.DRAWER_BANK,
                       PURCHASEFEE_ROW.BACK_WRITE_NAME,
                       PURCHASEFEE_ROW.FIRST_RECEIPT_NAME,
                       PURCHASEFEE_ROW.FIRST_RECEIPT_BANK_ACCOUNT,
                       PURCHASEFEE_ROW.FIRST_RECEIPT_BANK,
                       PURCHASEFEE_ROW.ACCEPTANCE_BANK_NAME,
                       NVL((select t.budgetitemcode
                          from intf_gtsp_budget_project t
                         where t.attribute1 = 'Y'),'0314'),
                       PURCHASEFEE_ROW.CREATED_BY,
                       PURCHASEFEE_ROW.CREATION_DATE,
                       PURCHASEFEE_ROW.REMAEK,
                       V_SALES_CENTER_ID,
                       (select distinct w.CUSTOMER_ID
                          from v_cust_account w
                         where w.account_id = PURCHASEFEE_ROW.ACCOUNT_ID
                           and w.ENTITY_ID = PURCHASEFEE_ROW.ENTITY_ID),
                       (select distinct w.CUSTOMER_CODE
                          from v_cust_account w
                         where w.account_id = PURCHASEFEE_ROW.ACCOUNT_ID
                           and w.ENTITY_ID = PURCHASEFEE_ROW.ENTITY_ID),
                       (select distinct w.CUSTOMER_NAME
                          from v_cust_account w
                         where w.account_id = PURCHASEFEE_ROW.ACCOUNT_ID
                           and w.ENTITY_ID = PURCHASEFEE_ROW.ENTITY_ID),
                       (select distinct w.ACCOUNT_CODE
                          from v_cust_account w
                         where w.account_id = PURCHASEFEE_ROW.ACCOUNT_ID
                           and w.ENTITY_ID = PURCHASEFEE_ROW.ENTITY_ID),
                       (select distinct w.ACCOUNT_NAME
                          from v_cust_account w
                         where w.account_id = PURCHASEFEE_ROW.ACCOUNT_ID
                           and w.ENTITY_ID = PURCHASEFEE_ROW.ENTITY_ID),
                       (select distinct t.erp_ou_id
                          from T_AR_OU_RELATION t
                         where t.entity_id = PURCHASEFEE_ROW.ENTITY_ID
                           and t.sales_center_id = V_SALES_CENTER_ID),
                       (select distinct t.erp_ou_name
                          from T_AR_OU_RELATION t
                         where t.entity_id = PURCHASEFEE_ROW.ENTITY_ID
                           and t.sales_center_id = V_SALES_CENTER_ID),
                       PURCHASEFEE_ROW.ENTITY_ID,
                       'IMS',
                       PURCHASEFEE_ROW.SOURCE_TYPE);

                    --根据CASH_RECEIPT_ID，插入收款行表
                    SELECT COUNT(*) INTO V_DEFLAUT_SALE_MAIN_TYPE_COUNT FROM CIMS.INTF_AR_CASH_RECEIPT_LINES L
                    WHERE L.CASH_RECEIPT_ID = PURCHASEFEE_ROW.CASH_RECEIPT_ID;
                    IF V_DEFLAUT_SALE_MAIN_TYPE_COUNT > 0 THEN
                    	FOR PURCHASEFEE_LINE_ROW IN (SELECT * FROM CIMS.INTF_AR_CASH_RECEIPT_LINES L WHERE L.CASH_RECEIPT_ID = PURCHASEFEE_ROW.CASH_RECEIPT_ID) LOOP
                        INSERT INTO T_AR_CASH_RECEIPT_LINES
                        (CASH_RECEIPT_LINES_ID,
                         CASH_RECEIPT_ID,
                         AMOUNT,
                         REMARK,
                         SALES_MAIN_TYPE_ID,
                         SALES_MAIN_TYPE_CODE,
                         SALES_MAIN_TYPE_NAME,
                         BRAND_CODE,
                         ENTITY_ID)
                      VALUES
                        (V_CASH_RECEIPT_LINES_ID,
                         V_CASH_RECEIPT_ID,
                         PURCHASEFEE_LINE_ROW.AMOUNT,
                         PURCHASEFEE_LINE_ROW.REMARK,
                         PURCHASEFEE_LINE_ROW.SALES_MAIN_TYPE_ID,
                         PURCHASEFEE_LINE_ROW.SALES_MAIN_TYPE_CODE,
                         PURCHASEFEE_LINE_ROW.SALES_MAIN_TYPE_NAME,
                         'brand_enum_set1',
                         PURCHASEFEE_ROW.ENTITY_ID);
                      END LOOP;
                    ELSE
                      -- 获取默认营销大类
                      V_DEFLAUT_SALE_MAIN_TYPE_CODE := PKG_BD.F_GET_PARAMETER_VALUE('ar_default_sale_main_write_off', PURCHASEFEE_ROW.ENTITY_ID, NULL, NULL);
                      IF V_DEFLAUT_SALE_MAIN_TYPE_CODE IS NULL THEN
                        P_MESSAGE := '主体:'||PURCHASEFEE_ROW.ENTITY_ID||'未配置默认营销大类(ar_default_sale_main_write_off)，请联系管理员';
                        RAISE V_BIZ_EXCEPTION;
                      END IF;
                      INSERT INTO T_AR_CASH_RECEIPT_LINES
                      (CASH_RECEIPT_LINES_ID,
                       CASH_RECEIPT_ID,
                       AMOUNT,
                       REMARK,
                       SALES_MAIN_TYPE_ID,
                       SALES_MAIN_TYPE_CODE,
                       SALES_MAIN_TYPE_NAME,
                       BRAND_CODE,
                       ENTITY_ID)
                    VALUES
                      (V_CASH_RECEIPT_LINES_ID,
                       V_CASH_RECEIPT_ID,
                       PURCHASEFEE_ROW.AMOUNT,
                       PURCHASEFEE_ROW.REMAEK,
                       (select t.item_class_id
                          from t_bd_item_class t
                         where t.class_code = V_DEFLAUT_SALE_MAIN_TYPE_CODE
                               AND t.ENTITY_ID = PURCHASEFEE_ROW.ENTITY_ID
                               AND T.CLASS_TYPE = 'M' AND T.ACTIVE_FLAG = 'Y'),
                       V_DEFLAUT_SALE_MAIN_TYPE_CODE,
                       (select t.class_name
                          from t_bd_item_class t
                         where t.class_code = V_DEFLAUT_SALE_MAIN_TYPE_CODE
                               AND t.ENTITY_ID = PURCHASEFEE_ROW.ENTITY_ID
                               AND T.CLASS_TYPE = 'M' AND T.ACTIVE_FLAG = 'Y'),
                       'brand_enum_set1',
                       PURCHASEFEE_ROW.ENTITY_ID);
                    END IF;


                    /**INSERT INTO T_AR_CASH_RECEIPT_LINES
                      (CASH_RECEIPT_LINES_ID,
                       CASH_RECEIPT_ID,
                       AMOUNT,
                       REMARK,
                       SALES_MAIN_TYPE_ID,
                       SALES_MAIN_TYPE_CODE,
                       SALES_MAIN_TYPE_NAME,
                       BRAND_CODE,
                       ENTITY_ID)
                    VALUES
                      (V_CASH_RECEIPT_LINES_ID,
                       V_CASH_RECEIPT_ID,
                       PURCHASEFEE_ROW.AMOUNT,
                       PURCHASEFEE_ROW.REMAEK,
                       (select t.item_class_id
                          from t_bd_item_class t
                         where t.class_code = 'KT'),
                       'KT',
                       (select t.class_name
                          from t_bd_item_class t
                         where t.class_code = 'KT'),
                       'brand_enum_set1',
                       PURCHASEFEE_ROW.ENTITY_ID);**/

                    --更新接口表状态为04：成功
                    P_MESSAGE := 'SUCCESS';
                    UPDATE intf_ar_cash_receipt_headers
                       SET CASH_RECEIPT_CODE = V_CASH_RECEIPT_CODE,
                           STATUS            = '04',
                           ERROR_INFO        = P_MESSAGE
                     WHERE CASH_RECEIPT_ID =
                           PURCHASEFEE_ROW.CASH_RECEIPT_ID
                       and refund_apply_id = P_REFUND_APPLY_ID;

                    UPDATE INTF_AR_CASH_RECEIPT_LINES
                       SET STATUS = '04', ERROR_INFO = P_MESSAGE
                     WHERE CASH_RECEIPT_ID =
                           PURCHASEFEE_ROW.CASH_RECEIPT_ID;

                  end if;

                end if;

              end if;

            end if;

          end if;

        END LOOP;
        --异常处理
      EXCEPTION
        WHEN OTHERS THEN

          ROLLBACK;
          --记录出错信息
          P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_INTF_IMS.P_PURCHASEFEETURNFEE_IMS',
                                              SQLCODE,
                                              '插入收款头表失败！：' || SQLERRM);

          --更新接口表状态为03：失败
          UPDATE intf_ar_cash_receipt_headers
             SET STATUS = '03', ERROR_INFO = P_MESSAGE
           WHERE refund_apply_id = P_REFUND_APPLY_ID;

          RAISE V_BIZ_EXCEPTION;
      END;

      COMMIT;

    end if;
  EXCEPTION
    WHEN OTHERS THEN
      COMMIT;

  END;

  -- 退款接口表数据插入业务表
  PROCEDURE P_DISCOUNTPAYAPPLY_IMS(P_REFUND_APPLY_ID in number, --退款申请ID
                                   P_MESSAGE         out varchar2 --成功则返回“处理成功”，否则返回出错信息
                                   ) is
    PRAGMA AUTONOMOUS_TRANSACTION;
    CURSOR C_DISCOUNTPAYAPPLY IS
      SELECT *
        FROM intf_ar_refund_apply_headers
       WHERE intf_ar_refund_apply_headers.REFUND_APPLY_ID =
             P_REFUND_APPLY_ID;

    CURSOR C_PURCHASEFEE IS
      SELECT *
        FROM intf_ar_cash_receipt_headers
       WHERE intf_ar_cash_receipt_headers.REFUND_APPLY_ID =
             P_REFUND_APPLY_ID;

    PURCHASEFEE_ROW         C_PURCHASEFEE%ROWTYPE;
    DISCOUNTPAYAPPLY_ROW    C_DISCOUNTPAYAPPLY%ROWTYPE;
    DATACOUNT               number; --数据数量
    DATACOUNT1              number; --数据数量1
    DATACOUNT2              number; --用于校验RECEIPT_METHOD_ID
    DATACOUNT3              number; --用于校验ACCOUNT_ID、CUSTOMER_ID、ENTITY_ID是否存在
    V_REFUND_APPLY_ID       number; --退款申请ID
    V_REFUND_APPLY_LINES_ID number; --退款申请行ID
    V_REFUND_APPLY_CODE     varchar2(32); --退款申请编号
    V_CASH_RECEIPT_ID       number; --收款单据ID
    V_CASH_RECEIPT_LINES_ID number; --收款单据行ID
    V_CASH_RECEIPT_CODE     varchar2(32); --收款单据号
    --V_STATUS                    varchar2(2); --处理状态:01未处理，02校验通过，03校验失败，处理成功
    P_MESSAGE1 varchar2(32); --收款表处理状态说明
    V_BIZ_EXCEPTION EXCEPTION; --自定义业务异常

    V_DEFLAUT_SALE_MAIN_TYPE_CODE   VARCHAR2(50);
    V_AUTO_CONFIRM_REFUND_AMOUNT   number; --add by huanghb12 自动确认网批类型退款单的阈值

  BEGIN
    P_MESSAGE := '执行处理';
    --获取接口表数据数量
    select count(*)
      INTO DATACOUNT
      from intf_ar_refund_apply_headers t
     where t.REFUND_APPLY_ID = P_REFUND_APPLY_ID
       and t.status in ('01', '04');

    if (DATACOUNT > 0) THEN
      BEGIN
        --FOR I IN 1 .. DATACOUNT LOOP
        FOR DISCOUNTPAYAPPLY_ROW IN C_DISCOUNTPAYAPPLY LOOP
          --校验是否是网批项目的退款单，如果是就不校验账户，需要用户自己填写
          if ('15' <> DISCOUNTPAYAPPLY_ROW.ATTRIBUTE5) AND 
            (DISCOUNTPAYAPPLY_ROW.Receipt_Bank_Account is null or
             DISCOUNTPAYAPPLY_ROW.Receipt_Bank_Bank is null or
             DISCOUNTPAYAPPLY_ROW.Receipt_Bank_Code is null) THEN
            --更新接口表状态为03：校验失败
            P_MESSAGE := '校验失败,收款人开户银行信息为空！';
            UPDATE intf_ar_refund_apply_headers
               SET STATUS = '03', ERROR_INFO = P_MESSAGE
             WHERE refund_apply_id = P_REFUND_APPLY_ID;

            UPDATE INTF_AR_CASH_RECEIPT_HEADERS
               SET STATUS = '03', ERROR_INFO = P_MESSAGE
             WHERE refund_apply_id = P_REFUND_APPLY_ID;
          else
            --校验AMOUNT是否是正数
            if (DISCOUNTPAYAPPLY_ROW.Amount >= 0) THEN
              --更新接口表状态为03：校验失败
              P_MESSAGE := '校验失败,AMOUNT是正数！';
              UPDATE intf_ar_refund_apply_headers
                 SET STATUS = '03', ERROR_INFO = P_MESSAGE
               WHERE refund_apply_id = P_REFUND_APPLY_ID;

              UPDATE INTF_AR_CASH_RECEIPT_HEADERS
                 SET STATUS = '03', ERROR_INFO = P_MESSAGE
               WHERE refund_apply_id = P_REFUND_APPLY_ID;

            else
              --校验ACCOUNT_ID、CUSTOMER_ID、ENTITY_ID是否存在
              select count(*)
                INTO DATACOUNT3
                from V_CUST_ACCOUNT t
               where t.account_id = DISCOUNTPAYAPPLY_ROW.Account_Id
                 and t.entity_id = DISCOUNTPAYAPPLY_ROW.Entity_Id;

              if (DATACOUNT3 = 0) THEN
                --更新接口表状态为03：校验失败
                P_MESSAGE := '校验失败,ACCOUNT_ID、CUSTOMER_ID、ENTITY_ID值错误！';
                UPDATE intf_ar_refund_apply_headers
                   SET STATUS = '03', ERROR_INFO = P_MESSAGE
                 WHERE refund_apply_id = P_REFUND_APPLY_ID;

                UPDATE INTF_AR_CASH_RECEIPT_HEADERS
                   SET STATUS = '03', ERROR_INFO = P_MESSAGE
                 WHERE refund_apply_id = P_REFUND_APPLY_ID;

              else
                --校验RECEIPT_METHOD_ID
                select count(*)
                  INTO DATACOUNT2
                  from V_AR_RECEIPT_METHODS t
                 where t.receipt_method_id =
                       DISCOUNTPAYAPPLY_ROW.RECEIPT_METHOD_ID
                   and t.entity_id = DISCOUNTPAYAPPLY_ROW.Entity_Id;

                if (DATACOUNT2 = 0) THEN
                  --更新接口表状态为03：校验失败
                  P_MESSAGE := '校验失败,RECEIPT_METHOD_ID值错误！';
                  UPDATE intf_ar_refund_apply_headers
                     SET STATUS = '03', ERROR_INFO = P_MESSAGE
                   WHERE refund_apply_id = P_REFUND_APPLY_ID;

                  UPDATE INTF_AR_CASH_RECEIPT_HEADERS
                     SET STATUS = '03', ERROR_INFO = P_MESSAGE
                   WHERE refund_apply_id = P_REFUND_APPLY_ID;

                else
                  --检验CASH_CODE长度，只能等于16
                  if (length(PURCHASEFEE_ROW.CASH_CODE) >= 30) THEN
                    --更新接口表状态为03：校验失败
                    P_MESSAGE := '校验失败,CASH_CODE长度错误！';
                    UPDATE intf_ar_cash_receipt_headers
                       SET STATUS = '03', ERROR_INFO = P_MESSAGE
                     WHERE CASH_RECEIPT_ID =
                           PURCHASEFEE_ROW.CASH_RECEIPT_ID
                       and refund_apply_id = P_REFUND_APPLY_ID;

                    UPDATE INTF_AR_CASH_RECEIPT_LINES
                       SET STATUS = '03', ERROR_INFO = P_MESSAGE
                     WHERE CASH_RECEIPT_ID =
                           PURCHASEFEE_ROW.CASH_RECEIPT_ID;

                  else
                    --根据状态值Status分两类处理
                    --V_STATUS := DISCOUNTPAYAPPLY_ROW.Status;
                    if (DISCOUNTPAYAPPLY_ROW.Status = '01') THEN
                      --退款申请编号
                      BEGIN
                        V_REFUND_APPLY_CODE := PKG_BD.F_GET_BILL_NO('ARRECODE',
                                                                    null,
                                                                    DISCOUNTPAYAPPLY_ROW.Entity_Id,
                                                                    null);
                      EXCEPTION
                        WHEN OTHERS THEN
                          P_MESSAGE := '取退款申请编号失败！';
                          RAISE V_BIZ_EXCEPTION;
                      END;

                      --获取退款申请ID
                      SELECT S_AR_REFUND_APPLY_HEADERS.NEXTVAL
                        INTO V_REFUND_APPLY_ID
                        FROM DUAL;

                      --获取退款申请行ID
                      SELECT S_AR_REFUND_APPLY_LINES.NEXTVAL
                        INTO V_REFUND_APPLY_LINES_ID
                        FROM DUAL;

                      --遍历退款申请头接口表数据，插入退款申请头表
                      INSERT INTO T_AR_REFUND_APPLY_HEADERS
                        (REFUND_APPLY_ID,
                         RECEIPT_METHOD_ID,
                         RECEIPT_STATUS_ID,
                         ACCOUNT_ID,
                         REFUND_APPLY_CODE,
                         CASH_RECEIPT_DATE,
                         GL_DATE,
                         AMOUNT,
                         CURRENCY_CODE,
                         CASH_CODE,
                         RECEIPT_BANK_ACCOUNT,
                         RECEIPT_BANK_BANK,
                         RECEIPT_BANK_CODE,
                         CASH_RECEIPT_CREATED_BY,
                         CASH_RECEIPT_CREATION_BY_TIME,
                         UPDATED_BY,
                         UPDATED_DATE,
                         BUDGET_ITEM_CODE,
                         REMAEK,
                         CUSTOMER_ID,
                         CUSTOMER_CODE,
                         CUSTOMER_NAME,
                         ACCOUNT_CODE,
                         ACCOUNT_NAME,
                         SALES_CENTER_ID,
                         ERP_OU_ID,
                         ERP_OU_NAME,
                         ATTRIBUTE3,
                         ATTRIBUTE4,--add by huanghb12 2019-2-26 网批项目 销售单号
                         ATTRIBUTE5,--add by huanghb12 2019-2-26 网批项目退款单标记-15
                         SYS_SOURCE,--add by huanghb12 2019-2-27
                         SYS_SOURCE_ORDER_NUM,--add by huanghb12 2019-2-27
                         ENTITY_ID)

                      VALUES
                        (V_REFUND_APPLY_ID,
                         DISCOUNTPAYAPPLY_ROW.RECEIPT_METHOD_ID,
                         '1', --制单状态
                         DISCOUNTPAYAPPLY_ROW.ACCOUNT_ID,
                         V_REFUND_APPLY_CODE,
                         NVL(DISCOUNTPAYAPPLY_ROW.Cash_Receipt_Creation_By_Time,
                             SYSDATE),
                         SYSDATE,
                         DISCOUNTPAYAPPLY_ROW.AMOUNT,
                         DISCOUNTPAYAPPLY_ROW.CURRENCY_CODE,
                         DISCOUNTPAYAPPLY_ROW.CASH_CODE,
                         DISCOUNTPAYAPPLY_ROW.RECEIPT_BANK_ACCOUNT,
                         DISCOUNTPAYAPPLY_ROW.RECEIPT_BANK_BANK,
                         DISCOUNTPAYAPPLY_ROW.RECEIPT_BANK_CODE,
                         DISCOUNTPAYAPPLY_ROW.CASH_RECEIPT_CREATED_BY,
                         DISCOUNTPAYAPPLY_ROW.CASH_RECEIPT_CREATION_BY_TIME,
                         DISCOUNTPAYAPPLY_ROW.CASH_RECEIPT_CREATED_BY,
                         sysdate,
                         (select t.budgetitemcode
                            from intf_gtsp_budget_project t
                           where t.attribute1 = 'Y'),
                         DISCOUNTPAYAPPLY_ROW.REMAEK,
                         (select distinct w.CUSTOMER_ID
                            from v_cust_account w
                           where w.account_id =
                                 DISCOUNTPAYAPPLY_ROW.ACCOUNT_ID
                             and w.ENTITY_ID =
                                 DISCOUNTPAYAPPLY_ROW.ENTITY_ID),
                         (select distinct w.CUSTOMER_CODE
                            from v_cust_account w
                           where w.account_id =
                                 DISCOUNTPAYAPPLY_ROW.ACCOUNT_ID
                             and w.ENTITY_ID =
                                 DISCOUNTPAYAPPLY_ROW.ENTITY_ID),
                         (select distinct w.CUSTOMER_NAME
                            from v_cust_account w
                           where w.account_id =
                                 DISCOUNTPAYAPPLY_ROW.ACCOUNT_ID
                             and w.ENTITY_ID =
                                 DISCOUNTPAYAPPLY_ROW.ENTITY_ID),
                         (select distinct w.ACCOUNT_CODE
                            from v_cust_account w
                           where w.account_id =
                                 DISCOUNTPAYAPPLY_ROW.ACCOUNT_ID
                             and w.ENTITY_ID =
                                 DISCOUNTPAYAPPLY_ROW.ENTITY_ID),
                         (select distinct w.ACCOUNT_NAME
                            from v_cust_account w
                           where w.account_id =
                                 DISCOUNTPAYAPPLY_ROW.ACCOUNT_ID
                             and w.ENTITY_ID =
                                 DISCOUNTPAYAPPLY_ROW.ENTITY_ID),
                         (select distinct w.SALES_CENTER_ID
                            from v_cust_account w
                           where w.account_id =
                                 DISCOUNTPAYAPPLY_ROW.ACCOUNT_ID
                             and w.ENTITY_ID =
                                 DISCOUNTPAYAPPLY_ROW.ENTITY_ID),
                         (select distinct t.erp_ou_id
                            from T_AR_OU_RELATION t
                           where t.entity_id =
                                 DISCOUNTPAYAPPLY_ROW.ENTITY_ID
                             and t.sales_center_id =
                                 (select distinct w.SALES_CENTER_ID
                                    from v_cust_account w
                                   where w.account_id =
                                         DISCOUNTPAYAPPLY_ROW.ACCOUNT_ID
                                     and w.ENTITY_ID =
                                         DISCOUNTPAYAPPLY_ROW.ENTITY_ID)),
                         (select distinct t.erp_ou_name
                            from T_AR_OU_RELATION t
                           where t.entity_id =
                                 DISCOUNTPAYAPPLY_ROW.ENTITY_ID
                             and t.sales_center_id =
                                 (select distinct w.SALES_CENTER_ID
                                    from v_cust_account w
                                   where w.account_id =
                                         DISCOUNTPAYAPPLY_ROW.ACCOUNT_ID
                                     and w.ENTITY_ID =
                                         DISCOUNTPAYAPPLY_ROW.ENTITY_ID)),
                         'IMS',
                         DISCOUNTPAYAPPLY_ROW.ATTRIBUTE4,--add by huanghb12 2019-2-26 网批项目 销售单号
                         DISCOUNTPAYAPPLY_ROW.ATTRIBUTE5, --add by huanghb12 网批项目
                         DISCOUNTPAYAPPLY_ROW.SYS_SOURCE,--add by huanghb12 2019-2-27 系统来源（单据源自从哪个系统） CCS、CIMS
                         DISCOUNTPAYAPPLY_ROW.SYS_SOURCE_ORDER_NUM,--add by huanghb12 2019-2-27 外部系统单据号
                         DISCOUNTPAYAPPLY_ROW.ENTITY_ID);

                      -- 获取默认营销大类
                      V_DEFLAUT_SALE_MAIN_TYPE_CODE := PKG_BD.F_GET_PARAMETER_VALUE('ar_default_sale_main_write_off', DISCOUNTPAYAPPLY_ROW.ENTITY_ID, NULL, NULL);
                      IF V_DEFLAUT_SALE_MAIN_TYPE_CODE IS NULL THEN
                        P_MESSAGE := '主体:'||DISCOUNTPAYAPPLY_ROW.ENTITY_ID||'未配置默认营销大类(ar_default_sale_main_write_off)，请联系管理员';
                        RAISE V_BIZ_EXCEPTION;
                      END IF;
                      --根据REFUND_APPLY_ID，插入退款申请行表
                      INSERT INTO T_AR_REFUND_APPLY_LINES
                        (REFUND_APPLY_LINES_ID,
                         REFUND_APPLY_ID,
                         AMOUNT,
                         REMARK,
                         SALES_MAIN_TYPE_ID,
                         SALES_MAIN_TYPE_CODE,
                         SALES_MAIN_TYPE_NAME,
                         BRAND_CODE,
                         ENTITY_ID)
                      VALUES
                        (V_REFUND_APPLY_LINES_ID,
                         V_REFUND_APPLY_ID,
                         DISCOUNTPAYAPPLY_ROW.AMOUNT,
                         DISCOUNTPAYAPPLY_ROW.REMAEK,
                         (select t.item_class_id
                          from t_bd_item_class t
                         where t.class_code = V_DEFLAUT_SALE_MAIN_TYPE_CODE
                               AND t.ENTITY_ID = DISCOUNTPAYAPPLY_ROW.ENTITY_ID
                               AND T.CLASS_TYPE = 'M' AND T.ACTIVE_FLAG = 'Y'),
                       V_DEFLAUT_SALE_MAIN_TYPE_CODE,
                       (select t.class_name
                          from t_bd_item_class t
                         where t.class_code = V_DEFLAUT_SALE_MAIN_TYPE_CODE
                               AND t.ENTITY_ID = DISCOUNTPAYAPPLY_ROW.ENTITY_ID
                               AND T.CLASS_TYPE = 'M' AND T.ACTIVE_FLAG = 'Y'),
                       'brand_enum_set1',
                         DISCOUNTPAYAPPLY_ROW.ENTITY_ID);

                      --更新接口表状态为04：成功
                      P_MESSAGE := 'SUCCESS';
                      UPDATE intf_ar_refund_apply_headers
                         SET REFUND_APPLY_CODE = V_REFUND_APPLY_CODE,
                             STATUS            = '04',
                             ERROR_INFO        = P_MESSAGE
                       WHERE REFUND_APPLY_ID =
                             DISCOUNTPAYAPPLY_ROW.Refund_Apply_Id;                      
                      --处理收款表start

                      P_MESSAGE1 := '执行处理';
                      --获取接口表数据数量
                      select count(*)
                        INTO DATACOUNT1
                        from intf_ar_cash_receipt_headers t
                       where t.REFUND_APPLY_ID = P_REFUND_APPLY_ID;

                      if (DATACOUNT1 > 0) THEN
                        BEGIN
                          --FOR I IN 1 .. DATACOUNT LOOP
                          FOR PURCHASEFEE_ROW IN C_PURCHASEFEE LOOP
                            --收款单据号
                            BEGIN
                              V_CASH_RECEIPT_CODE := PKG_BD.F_GET_BILL_NO('ARARCODE',
                                                                          null,
                                                                          PURCHASEFEE_ROW.Entity_Id,
                                                                          null);
                            EXCEPTION
                              WHEN OTHERS THEN
                                P_MESSAGE1 := '取收款单据号失败！';
                                RAISE V_BIZ_EXCEPTION;
                            END;

                            --获取收款单据ID
                            SELECT S_AR_CASH_RECEIPT_HEADERS.NEXTVAL
                              INTO V_CASH_RECEIPT_ID
                              FROM DUAL;

                            --获取收款单据行ID
                            SELECT S_AR_CASH_RECEIPT_LINES.NEXTVAL
                              INTO V_CASH_RECEIPT_LINES_ID
                              FROM DUAL;

                            --遍历收款接口表数据，插入收款头表
                            INSERT INTO T_AR_CASH_RECEIPT_HEADERS
                              (CASH_RECEIPT_ID,
                               RECEIPT_METHOD_ID,
                               RECEIPT_STATUS_ID,
                               ACCOUNT_ID,
                               CASH_RECEIPT_CODE,
                               CASH_RECEIPT_DATE,
                               GL_DATE,
                               AMOUNT,
                               CURRENCY_CODE,
                               CASH_CODE,
                               CASH_DATE,
                               DUE_DATE,
                               DRAWER,
                               DRAWER_BANK_ACCOUNT,
                               DRAWER_BANK,
                               BACK_WRITE_NAME,
                               FIRST_RECEIPT_NAME,
                               FIRST_RECEIPT_BANK_ACCOUNT,
                               FIRST_RECEIPT_BANK,
                               ACCEPTANCE_BANK_NAME,
                               BUDGET_ITEM_NAME,
                               CREATED_BY,
                               CREATION_DATE,
                               REMAEK,
                               CUSTOMER_ID,
                               CUSTOMER_CODE,
                               CUSTOMER_NAME,
                               ACCOUNT_CODE,
                               ACCOUNT_NAME,
                               SALES_CENTER_ID,
                               ENTITY_ID,
                               ATTRIBUTE3,
                               ERP_OU_ID,
                               ERP_OU_NAME,
                               SOURCE_TYPE/*,
                               REFUND_APPLY_ID*/)

                            VALUES
                              (V_CASH_RECEIPT_ID,
                               PURCHASEFEE_ROW.RECEIPT_METHOD_ID,
                               '1', --制单状态
                               PURCHASEFEE_ROW.ACCOUNT_ID,
                               V_CASH_RECEIPT_CODE,
                               NVL(PURCHASEFEE_ROW.CASH_RECEIPT_DATE,
                                   SYSDATE),
                               NVL(PURCHASEFEE_ROW.GL_DATE, SYSDATE),
                               PURCHASEFEE_ROW.AMOUNT,
                               PURCHASEFEE_ROW.CURRENCY_CODE,
                               PURCHASEFEE_ROW.CASH_CODE,
                               PURCHASEFEE_ROW.CASH_DATE,
                               PURCHASEFEE_ROW.DUE_DATE,
                               PURCHASEFEE_ROW.DRAWER,
                               PURCHASEFEE_ROW.DRAWER_BANK_ACCOUNT,
                               PURCHASEFEE_ROW.DRAWER_BANK,
                               PURCHASEFEE_ROW.BACK_WRITE_NAME,
                               PURCHASEFEE_ROW.FIRST_RECEIPT_NAME,
                               PURCHASEFEE_ROW.FIRST_RECEIPT_BANK_ACCOUNT,
                               PURCHASEFEE_ROW.FIRST_RECEIPT_BANK,
                               PURCHASEFEE_ROW.ACCEPTANCE_BANK_NAME,
                               NVL((select t.budgetitemcode
                                      from intf_gtsp_budget_project t
                                     where t.attribute1 = 'Y'),'0314'),
                               PURCHASEFEE_ROW.CREATED_BY,
                               PURCHASEFEE_ROW.CREATION_DATE,
                               PURCHASEFEE_ROW.REMAEK,
                               (select distinct w.CUSTOMER_ID
                                  from v_cust_account w
                                 where w.account_id =
                                       PURCHASEFEE_ROW.ACCOUNT_ID
                                   and w.ENTITY_ID =
                                       PURCHASEFEE_ROW.ENTITY_ID),
                               (select distinct w.CUSTOMER_CODE
                                  from v_cust_account w
                                 where w.account_id =
                                       PURCHASEFEE_ROW.ACCOUNT_ID
                                   and w.ENTITY_ID =
                                       PURCHASEFEE_ROW.ENTITY_ID),
                               (select distinct w.CUSTOMER_NAME
                                  from v_cust_account w
                                 where w.account_id =
                                       PURCHASEFEE_ROW.ACCOUNT_ID
                                   and w.ENTITY_ID =
                                       PURCHASEFEE_ROW.ENTITY_ID),
                               (select distinct w.ACCOUNT_CODE
                                  from v_cust_account w
                                 where w.account_id =
                                       PURCHASEFEE_ROW.ACCOUNT_ID
                                   and w.ENTITY_ID =
                                       PURCHASEFEE_ROW.ENTITY_ID),
                               (select distinct w.ACCOUNT_NAME
                                  from v_cust_account w
                                 where w.account_id =
                                       PURCHASEFEE_ROW.ACCOUNT_ID
                                   and w.ENTITY_ID =
                                       PURCHASEFEE_ROW.ENTITY_ID),
                               (select distinct w.SALES_CENTER_ID
                                  from v_cust_account w
                                 where w.account_id =
                                       PURCHASEFEE_ROW.ACCOUNT_ID
                                   and w.ENTITY_ID =
                                       PURCHASEFEE_ROW.ENTITY_ID),
                               PURCHASEFEE_ROW.ENTITY_ID,
                               'IMS',
                               (select distinct t.erp_ou_id
                                  from T_AR_OU_RELATION t
                                 where t.entity_id =
                                       PURCHASEFEE_ROW.ENTITY_ID
                                   and t.sales_center_id =
                                       (select distinct w.SALES_CENTER_ID
                                          from v_cust_account w
                                         where w.account_id =
                                               PURCHASEFEE_ROW.ACCOUNT_ID
                                           and w.ENTITY_ID =
                                               PURCHASEFEE_ROW.ENTITY_ID)),
                               (select distinct t.erp_ou_name
                                  from T_AR_OU_RELATION t
                                 where t.entity_id =
                                       PURCHASEFEE_ROW.ENTITY_ID
                                   and t.sales_center_id =
                                       (select distinct w.SALES_CENTER_ID
                                          from v_cust_account w
                                         where w.account_id =
                                               PURCHASEFEE_ROW.ACCOUNT_ID
                                           and w.ENTITY_ID =
                                               PURCHASEFEE_ROW.ENTITY_ID)),
                               PURCHASEFEE_ROW.SOURCE_TYPE/*,
                               V_REFUND_APPLY_ID*/);

                            -- 获取默认营销大类
                            V_DEFLAUT_SALE_MAIN_TYPE_CODE := PKG_BD.F_GET_PARAMETER_VALUE('ar_default_sale_main_write_off', PURCHASEFEE_ROW.ENTITY_ID, NULL, NULL);
                            IF V_DEFLAUT_SALE_MAIN_TYPE_CODE IS NULL THEN
                              P_MESSAGE := '主体:'||PURCHASEFEE_ROW.ENTITY_ID||'未配置默认营销大类(ar_default_sale_main_write_off)，请联系管理员';
                              RAISE V_BIZ_EXCEPTION;
                            END IF;
                            --根据CASH_RECEIPT_ID，插入收款行表
                            INSERT INTO T_AR_CASH_RECEIPT_LINES
                              (CASH_RECEIPT_LINES_ID,
                               CASH_RECEIPT_ID,
                               AMOUNT,
                               REMARK,
                               SALES_MAIN_TYPE_ID,
                               SALES_MAIN_TYPE_CODE,
                               SALES_MAIN_TYPE_NAME,
                               BRAND_CODE,
                               ENTITY_ID)
                            VALUES
                              (V_CASH_RECEIPT_LINES_ID,
                               V_CASH_RECEIPT_ID,
                               PURCHASEFEE_ROW.AMOUNT,
                               PURCHASEFEE_ROW.REMAEK,
                               (select t.item_class_id
                                  from t_bd_item_class t
                                 where t.class_code = V_DEFLAUT_SALE_MAIN_TYPE_CODE
                               AND t.ENTITY_ID = PURCHASEFEE_ROW.ENTITY_ID
                               AND T.CLASS_TYPE = 'M' AND T.ACTIVE_FLAG = 'Y'),
                               V_DEFLAUT_SALE_MAIN_TYPE_CODE,
                               (select t.class_name
                                  from t_bd_item_class t
                                 where t.class_code = V_DEFLAUT_SALE_MAIN_TYPE_CODE
                               AND t.ENTITY_ID = PURCHASEFEE_ROW.ENTITY_ID
                               AND T.CLASS_TYPE = 'M' AND T.ACTIVE_FLAG = 'Y'),
                               'brand_enum_set1',
                               PURCHASEFEE_ROW.ENTITY_ID);

                            --更新接口表状态为04：成功
                            P_MESSAGE1 := 'SUCCESS';
                            UPDATE intf_ar_cash_receipt_headers
                               SET CASH_RECEIPT_CODE = V_CASH_RECEIPT_CODE,
                                   STATUS            = '04',
                                   ERROR_INFO        = P_MESSAGE1
                             WHERE CASH_RECEIPT_ID =
                                   PURCHASEFEE_ROW.CASH_RECEIPT_ID;

                          END LOOP;
                        EXCEPTION
                          WHEN OTHERS THEN

                            ROLLBACK;
                            --记录出错信息
                            P_MESSAGE1 := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_INTF_IMS.P_DISCOUNTPAYAPPLY_IMS',
                                                                 SQLCODE,
                                                                 '插入收款头表失败！：' ||
                                                                 SQLERRM);

                            --更新接口表状态为03：失败
                            UPDATE intf_ar_cash_receipt_headers
                               SET STATUS = '03', ERROR_INFO = P_MESSAGE1
                             WHERE CASH_RECEIPT_ID =
                                   PURCHASEFEE_ROW.CASH_RECEIPT_ID
                               and STATUS = '01';

                            RAISE V_BIZ_EXCEPTION;
                        END;

                        COMMIT;

                      end if;

                      --处理收款表end

                    elsif (DISCOUNTPAYAPPLY_ROW.Status = '04') THEN

                      FOR PURCHASEFEE_ROW IN C_PURCHASEFEE LOOP

                        if (PURCHASEFEE_ROW.Status = '01') THEN

                          --处理收款表start

                          P_MESSAGE1 := '执行处理';

                          BEGIN

                            --收款单据号
                            BEGIN
                              V_CASH_RECEIPT_CODE := PKG_BD.F_GET_BILL_NO('ARARCODE',
                                                                          null,
                                                                          PURCHASEFEE_ROW.Entity_Id,
                                                                          null);
                            EXCEPTION
                              WHEN OTHERS THEN
                                P_MESSAGE1 := '取收款单据号失败！';
                                RAISE V_BIZ_EXCEPTION;
                            END;

                            --获取收款单据ID
                            SELECT S_AR_CASH_RECEIPT_HEADERS.NEXTVAL
                              INTO V_CASH_RECEIPT_ID
                              FROM DUAL;

                            --获取收款单据行ID
                            SELECT S_AR_CASH_RECEIPT_LINES.NEXTVAL
                              INTO V_CASH_RECEIPT_LINES_ID
                              FROM DUAL;

                            --遍历收款接口表数据，插入收款头表
                            INSERT INTO T_AR_CASH_RECEIPT_HEADERS
                              (CASH_RECEIPT_ID,
                               RECEIPT_METHOD_ID,
                               RECEIPT_STATUS_ID,
                               ACCOUNT_ID,
                               CASH_RECEIPT_CODE,
                               CASH_RECEIPT_DATE,
                               GL_DATE,
                               AMOUNT,
                               CURRENCY_CODE,
                               CASH_CODE,
                               CASH_DATE,
                               DUE_DATE,
                               DRAWER,
                               DRAWER_BANK_ACCOUNT,
                               DRAWER_BANK,
                               BACK_WRITE_NAME,
                               FIRST_RECEIPT_NAME,
                               FIRST_RECEIPT_BANK_ACCOUNT,
                               FIRST_RECEIPT_BANK,
                               ACCEPTANCE_BANK_NAME,
                               BUDGET_ITEM_NAME,
                               CREATED_BY,
                               CREATION_DATE,
                               REMAEK,
                               CUSTOMER_ID,
                               CUSTOMER_CODE,
                               CUSTOMER_NAME,
                               ACCOUNT_CODE,
                               ACCOUNT_NAME,
                               SALES_CENTER_ID,
                               ENTITY_ID,
                               ATTRIBUTE3,
                               ERP_OU_ID,
                               ERP_OU_NAME,
                               SOURCE_TYPE/*,
                               REFUND_APPLY_ID*/)

                            VALUES
                              (V_CASH_RECEIPT_ID,
                               PURCHASEFEE_ROW.RECEIPT_METHOD_ID,
                               '1', --制单状态
                               PURCHASEFEE_ROW.ACCOUNT_ID,
                               V_CASH_RECEIPT_CODE,
                               NVL(PURCHASEFEE_ROW.CASH_RECEIPT_DATE,
                                   SYSDATE),
                               NVL(PURCHASEFEE_ROW.GL_DATE, SYSDATE),
                               PURCHASEFEE_ROW.AMOUNT,
                               PURCHASEFEE_ROW.CURRENCY_CODE,
                               PURCHASEFEE_ROW.CASH_CODE,
                               PURCHASEFEE_ROW.CASH_DATE,
                               PURCHASEFEE_ROW.DUE_DATE,
                               PURCHASEFEE_ROW.DRAWER,
                               PURCHASEFEE_ROW.DRAWER_BANK_ACCOUNT,
                               PURCHASEFEE_ROW.DRAWER_BANK,
                               PURCHASEFEE_ROW.BACK_WRITE_NAME,
                               PURCHASEFEE_ROW.FIRST_RECEIPT_NAME,
                               PURCHASEFEE_ROW.FIRST_RECEIPT_BANK_ACCOUNT,
                               PURCHASEFEE_ROW.FIRST_RECEIPT_BANK,
                               PURCHASEFEE_ROW.ACCEPTANCE_BANK_NAME,
                               NVL((select t.budgetitemcode
                                      from intf_gtsp_budget_project t
                                     where t.attribute1 = 'Y'),'0314'),
                               PURCHASEFEE_ROW.CREATED_BY,
                               PURCHASEFEE_ROW.CREATION_DATE,
                               PURCHASEFEE_ROW.REMAEK,
                               (select distinct w.CUSTOMER_ID
                                  from v_cust_account w
                                 where w.account_id =
                                       PURCHASEFEE_ROW.ACCOUNT_ID
                                   and w.ENTITY_ID =
                                       PURCHASEFEE_ROW.ENTITY_ID),
                               (select distinct w.CUSTOMER_CODE
                                  from v_cust_account w
                                 where w.account_id =
                                       PURCHASEFEE_ROW.ACCOUNT_ID
                                   and w.ENTITY_ID =
                                       PURCHASEFEE_ROW.ENTITY_ID),
                               (select distinct w.CUSTOMER_NAME
                                  from v_cust_account w
                                 where w.account_id =
                                       PURCHASEFEE_ROW.ACCOUNT_ID
                                   and w.ENTITY_ID =
                                       PURCHASEFEE_ROW.ENTITY_ID),
                               (select distinct w.ACCOUNT_CODE
                                  from v_cust_account w
                                 where w.account_id =
                                       PURCHASEFEE_ROW.ACCOUNT_ID
                                   and w.ENTITY_ID =
                                       PURCHASEFEE_ROW.ENTITY_ID),
                               (select distinct w.ACCOUNT_NAME
                                  from v_cust_account w
                                 where w.account_id =
                                       PURCHASEFEE_ROW.ACCOUNT_ID
                                   and w.ENTITY_ID =
                                       PURCHASEFEE_ROW.ENTITY_ID),
                               (select distinct w.SALES_CENTER_ID
                                  from v_cust_account w
                                 where w.account_id =
                                       PURCHASEFEE_ROW.ACCOUNT_ID
                                   and w.ENTITY_ID =
                                       PURCHASEFEE_ROW.ENTITY_ID),
                               PURCHASEFEE_ROW.ENTITY_ID,
                               'IMS',
                               (select distinct t.erp_ou_id
                                  from T_AR_OU_RELATION t
                                 where t.entity_id =
                                       PURCHASEFEE_ROW.ENTITY_ID
                                   and t.sales_center_id =
                                       (select distinct w.SALES_CENTER_ID
                                          from v_cust_account w
                                         where w.account_id =
                                               PURCHASEFEE_ROW.ACCOUNT_ID
                                           and w.ENTITY_ID =
                                               PURCHASEFEE_ROW.ENTITY_ID)),
                               (select distinct t.erp_ou_name
                                  from T_AR_OU_RELATION t
                                 where t.entity_id =
                                       PURCHASEFEE_ROW.ENTITY_ID
                                   and t.sales_center_id =
                                       (select distinct w.SALES_CENTER_ID
                                          from v_cust_account w
                                         where w.account_id =
                                               PURCHASEFEE_ROW.ACCOUNT_ID
                                           and w.ENTITY_ID =
                                               PURCHASEFEE_ROW.ENTITY_ID)),
                               PURCHASEFEE_ROW.SOURCE_TYPE/*,
                               P_REFUND_APPLY_ID*/);

                            -- 获取默认营销大类
                            V_DEFLAUT_SALE_MAIN_TYPE_CODE := PKG_BD.F_GET_PARAMETER_VALUE('ar_default_sale_main_write_off', PURCHASEFEE_ROW.ENTITY_ID, NULL, NULL);
                            IF V_DEFLAUT_SALE_MAIN_TYPE_CODE IS NULL THEN
                              P_MESSAGE := '主体:'||PURCHASEFEE_ROW.ENTITY_ID||'未配置默认营销大类(ar_default_sale_main_write_off)，请联系管理员';
                              RAISE V_BIZ_EXCEPTION;
                            END IF;
                            --根据CASH_RECEIPT_ID，插入收款行表
                            INSERT INTO T_AR_CASH_RECEIPT_LINES
                              (CASH_RECEIPT_LINES_ID,
                               CASH_RECEIPT_ID,
                               AMOUNT,
                               REMARK,
                               SALES_MAIN_TYPE_ID,
                               SALES_MAIN_TYPE_CODE,
                               SALES_MAIN_TYPE_NAME,
                               BRAND_CODE,
                               ENTITY_ID)
                            VALUES
                              (V_CASH_RECEIPT_LINES_ID,
                               V_CASH_RECEIPT_ID,
                               PURCHASEFEE_ROW.AMOUNT,
                               PURCHASEFEE_ROW.REMAEK,
                               (select t.item_class_id
                                  from t_bd_item_class t
                                 where t.class_code = V_DEFLAUT_SALE_MAIN_TYPE_CODE
                                       AND t.ENTITY_ID = PURCHASEFEE_ROW.ENTITY_ID
                                       AND T.CLASS_TYPE = 'M' AND T.ACTIVE_FLAG = 'Y'),
                               V_DEFLAUT_SALE_MAIN_TYPE_CODE,
                               (select t.class_name
                                  from t_bd_item_class t
                                 where t.class_code = V_DEFLAUT_SALE_MAIN_TYPE_CODE
                                       AND t.ENTITY_ID = PURCHASEFEE_ROW.ENTITY_ID
                                       AND T.CLASS_TYPE = 'M' AND T.ACTIVE_FLAG = 'Y'),
                               'brand_enum_set1',
                               PURCHASEFEE_ROW.ENTITY_ID);

                            --更新接口表状态为04：成功
                            P_MESSAGE1 := 'SUCCESS';
                            UPDATE intf_ar_cash_receipt_headers
                               SET CASH_RECEIPT_CODE = V_CASH_RECEIPT_CODE,
                                   STATUS            = '04',
                                   ERROR_INFO        = P_MESSAGE1
                             WHERE CASH_RECEIPT_ID =
                                   PURCHASEFEE_ROW.CASH_RECEIPT_ID;

                            P_MESSAGE := 'SUCCESS';
                            UPDATE intf_ar_refund_apply_headers
                               SET ERROR_INFO = P_MESSAGE
                             WHERE REFUND_APPLY_ID =
                                   DISCOUNTPAYAPPLY_ROW.Refund_Apply_Id;

                          EXCEPTION
                            WHEN OTHERS THEN

                              ROLLBACK;
                              --记录出错信息
                              P_MESSAGE1 := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_INTF_IMS.P_DISCOUNTPAYAPPLY_IMS',
                                                                   SQLCODE,
                                                                   '插入收款头表失败！：' ||
                                                                   SQLERRM);

                              --更新接口表状态为03：失败
                              UPDATE intf_ar_cash_receipt_headers
                                 SET STATUS = '03', ERROR_INFO = P_MESSAGE1
                               WHERE CASH_RECEIPT_ID =
                                     PURCHASEFEE_ROW.CASH_RECEIPT_ID;

                              RAISE V_BIZ_EXCEPTION;
                          END;

                          COMMIT;

                          --处理收款表end

                        end if;

                      END LOOP;

                    end if;

                  end if;

                end if;

              end if;

            end if;

          end if;

        END LOOP;

      EXCEPTION
        WHEN OTHERS THEN

          ROLLBACK;
          --记录出错信息
          P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_INTF_IMS.P_DISCOUNTPAYAPPLY_IMS',
                                              SQLCODE,
                                              '插入退款申请头表失败！：' || SQLERRM);

          --更新接口表状态为03：失败
          UPDATE intf_ar_refund_apply_headers
             SET STATUS = '03', ERROR_INFO = P_MESSAGE
           WHERE REFUND_APPLY_ID = P_REFUND_APPLY_ID
             and STATUS = '01';

          UPDATE intf_ar_cash_receipt_headers
             SET STATUS = '03', ERROR_INFO = P_MESSAGE
           WHERE REFUND_APPLY_ID = P_REFUND_APPLY_ID
             and STATUS = '01';

          RAISE V_BIZ_EXCEPTION;
      END;

      COMMIT;
    end if;

  EXCEPTION
    WHEN OTHERS THEN
      COMMIT;
  END;

END PKG_AR_INTF_IMS;
/

