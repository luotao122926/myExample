create package PKG_CREDIT_THREE_PAY is

  --------------------------------------------------------------------------------
  /*
  *   创建日期：2015-07-29
  *     创建者：梁颜明
  *   功能说明：三方承兑解付、冲销更新三方铺底的实际铺底金额
  *    因为不限制三方承兑收款必须申请三方铺底，如果没有有效的三方铺底，也返回成功
  
      19：三方承兑解付
      20：三方承兑解付冲销
  */
  -------------------------------------------------------------------------------
  PROCEDURE PRC_CREDIT_TREEDELAYPAY_UPDATE(P_ENTITY_ID       IN NUMBER, --主体ID
                                           P_ACTION_TYPE     IN NUMBER, --动作标示
                                           P_SALES_MAIN_TYPE IN VARCHAR2, --营销大类
                                           P_ACCOUNT_ID      IN NUMBER, --账户ID
                                           P_CUSTOMER_ID     IN NUMBER, --客户ID
                                           P_ORDER_ID        IN NUMBER, --单据ID
                                           P_USERNAME        IN VARCHAR2,
                                           P_RESULT          IN OUT NUMBER, --返回错误ID
                                           P_ERR_MSG         IN OUT VARCHAR2 --返回错误信息                          
                                           );
end;
/

