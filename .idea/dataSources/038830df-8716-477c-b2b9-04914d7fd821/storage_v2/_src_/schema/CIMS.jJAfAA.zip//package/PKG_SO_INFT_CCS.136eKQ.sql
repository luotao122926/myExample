create PACKAGE      PKG_SO_INFT_CCS IS
  -------------------------------------------------------------------------------
  --CCS跟CIMS销售管理模块的接口处理过程包

  V_BIZ_SRC_RETURN_APPLY                   CONSTANT CHAR(4) := '1011';             --退货申请单
  V_DEFAULT_USER_CCS                       CONSTANT CHAR(3) := 'CCS';              --默认制单人CCS
  V_RETURN_APPLY_STATUS_SUBMIT             CONSTANT CHAR(2) := '11';               --退货申请单提交审核
  V_STATUS_INIT                            CONSTANT CHAR(2) :='01';                --接口表状态 01 初始化 02处理成功 03 处理失败
  V_STATUS_SUCESS                          CONSTANT CHAR(2) :='02';                --接口表状态 01 初始化 02处理成功 03 处理失败
  V_STATUS_FAIL                            CONSTANT CHAR(2) :='03';                --接口表状态 01 初始化 02处理成功 03 处理失败
  V_ARG_ITEM_PRICE_SET_TYPE                CONSTANT VARCHAR2(32) :='SO_ITEM_PRICE_SET_TYPE'; --主体参数：开单时产品价格设置方式
  V_SO_ITEM_PRICE_PRICE_LIST               CONSTANT VARCHAR2(20) :='PRICE_LIST';   --产品价格从价格列表获取
  V_SO_ITEM_PRICE_OPERATOR_SET             CONSTANT VARCHAR2(20) :='OPERATOR_SET'; --产品价格有业务人员制单时制定
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-06-11
  *     创建者：周建刚
  *   功能说明：引入退货申请单到CIMS (目前用在CCS 、电商)
      退货申请引入步骤：（1）直接写CIMS的接口表；（2）然后调用该储存过程的方法，在CIMS生成退货申请单。
  */  
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_GEN_RETURN_APPLY_ENTRY(
                                    P_APPLY_HEADER_ID         IN  NUMBER, --退货申请单接口表头ID
                                    P_SYS_SOURCE              IN VARCHAR2,--系统编码
                                    P_RESULT                  OUT NUMBER,
                                    P_ERR_MSG                 OUT VARCHAR2
                               );

END;
/

