create view V_CUSTOMER_DEPT as
select ID,
       DEPT_ID,
       DEPT_CODE,
       CUSTOMER_ID,
       CUSTOMER_CODE,
       CUSTOMER_SHORT_NAME,
       DEPT_CUSTOM_LEVEL,
       CUSTOMER_MARKET_HIERARCHY,
       DEPT_CUSTOMER_STATUS,
       CUSTOMER_ACTIVE_DATE,
       CUSTOMER_END_DATE,
       CREATED_BY,
       CREATION_DATE,
       LAST_UPDATE_DATE,
       LAST_UPDATE_BY,
       LAST_INTERFACE_DATE,
       YEAR_SCALE,
       BAKE_YEAR_REAL_SCALE,
       SIEBEL_ID,
       SIEBEL_CUSTOMER_ID,
       ACTIVE_FLAG,
       PRE_FIELD_01,
       PRE_FIELD_02,
       PRE_FIELD_03,
       PRE_FIELD_04,
       PRE_FIELD_05,
       PRE_FIELD_06
  from T_CUSTOMER_DEPT with read only
/

comment on column V_CUSTOMER_DEPT.ID is 'ID'
/

comment on column V_CUSTOMER_DEPT.DEPT_ID is '事业部ID'
/

comment on column V_CUSTOMER_DEPT.DEPT_CODE is '事业部编码'
/

comment on column V_CUSTOMER_DEPT.CUSTOMER_ID is '客户ID'
/

comment on column V_CUSTOMER_DEPT.CUSTOMER_CODE is '客户编码'
/

comment on column V_CUSTOMER_DEPT.CUSTOMER_SHORT_NAME is '客户简称'
/

comment on column V_CUSTOMER_DEPT.DEPT_CUSTOM_LEVEL is '事业部客户等级'
/

comment on column V_CUSTOMER_DEPT.CUSTOMER_MARKET_HIERARCHY is '市场层级'
/

comment on column V_CUSTOMER_DEPT.DEPT_CUSTOMER_STATUS is '事业部客户状态'
/

comment on column V_CUSTOMER_DEPT.CUSTOMER_ACTIVE_DATE is '生效时间'
/

comment on column V_CUSTOMER_DEPT.CUSTOMER_END_DATE is '失效时间'
/

comment on column V_CUSTOMER_DEPT.CREATED_BY is '创建人'
/

comment on column V_CUSTOMER_DEPT.CREATION_DATE is '创建日期'
/

comment on column V_CUSTOMER_DEPT.LAST_UPDATE_DATE is '最后修改时间'
/

comment on column V_CUSTOMER_DEPT.LAST_UPDATE_BY is '最后修改人'
/

comment on column V_CUSTOMER_DEPT.LAST_INTERFACE_DATE is '最后同步时间'
/

comment on column V_CUSTOMER_DEPT.YEAR_SCALE is '年度规模(万元)'
/

comment on column V_CUSTOMER_DEPT.BAKE_YEAR_REAL_SCALE is '上一年实际完成'
/

comment on column V_CUSTOMER_DEPT.SIEBEL_ID is '主数据事业部信息ID'
/

comment on column V_CUSTOMER_DEPT.SIEBEL_CUSTOMER_ID is '主数据客户ID'
/

comment on column V_CUSTOMER_DEPT.ACTIVE_FLAG is '是否有效(Y/N)'
/

comment on column V_CUSTOMER_DEPT.PRE_FIELD_01 is '预留字段1'
/

comment on column V_CUSTOMER_DEPT.PRE_FIELD_02 is '预留字段2'
/

comment on column V_CUSTOMER_DEPT.PRE_FIELD_03 is '预留字段3'
/

comment on column V_CUSTOMER_DEPT.PRE_FIELD_04 is '预留字段4'
/

comment on column V_CUSTOMER_DEPT.PRE_FIELD_05 is '预留字段5'
/

comment on column V_CUSTOMER_DEPT.PRE_FIELD_06 is '预留字段6'
/

