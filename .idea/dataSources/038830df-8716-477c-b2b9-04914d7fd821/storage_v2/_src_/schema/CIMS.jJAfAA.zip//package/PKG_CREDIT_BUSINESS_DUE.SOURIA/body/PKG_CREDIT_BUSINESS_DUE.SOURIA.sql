create package body      PKG_CREDIT_BUSINESS_DUE is

  PROCEDURE 新客户初始化信用信息 is
  begin
    null;
  end;
  --------------------------------------------------------------------------------
  /*
  *   创建日期：2014-08-08
  *     创建者：苏冬渊
  *   功能说明：客户模块从主数据引进客户信息的时候，维护信用模块的客户组信息
  *   返回结果：0:成功，-20000：失败
  *
  */
  -------------------------------------------------------------------------------
  PROCEDURE PRC_CREDIT_CUSTOMER_INIT(P_ENTITY_ID       IN NUMBER, --主体ID
                                     P_CUSTOMER_ID     IN NUMBER, --客户ID
                                     P_USERNAME        IN VARCHAR2, --登录用户名
                                     P_RESULT          OUT NUMBER ,
                                     P_ERR_MSG         OUT VARCHAR2
                                     ) IS
    V_CUST_GROUP_ID NUMBER; --客户组ID
    V_COUNT         NUMBER;
    entityGroupCode Varchar2(100) ;
  BEGIN
    P_RESULT := V_SEC_RESULT ;
    P_ERR_MSG:= V_SUCCESS ;

    --获取主体组编码
    entityGroupCode := pkg_bd.F_GET_PARAMETER_VALUE('ar_entity_group',P_ENTITY_ID,null,null);

    IF P_CUSTOMER_ID IS NULL OR P_ENTITY_ID IS Null THEN
      P_RESULT  := -20000;
      P_ERR_MSG := '传入参数有问题，客户ID不能都为空！';
      RETURN;
    END IF;
    --检查该客户是否存在客户组信息
    SELECT COUNT(1)
      INTO V_COUNT
      FROM T_CREDIT_CUST_GROUP_REL A,T_CREDIT_CUST_GROUP B
     WHERE A.CUST_GROUP_ID = B.CUST_GROUP_ID
       AND B.ENTITY_ID = P_ENTITY_ID
       AND A.CUSTOMER_ID = P_CUSTOMER_ID
       AND NVL(B.ACTIVE_FLAG,'1') = '1' ;

   IF V_COUNT <= 0 AND entityGroupCode = 'XSGS' THEN --10：家用
   --若不存在客户组信息，家用空调事业部将客户信息放入默认客户组
    BEGIN
      INSERT INTO T_CREDIT_CUST_GROUP_REL
        (REL_ID, --           NUMBER not null,
         CUST_GROUP_ID, --    NUMBER,
         CUSTOMER_ID, --     NUMBER,
         CREATION_DATE, --    DATE,
         CREATED_BY, --     VARCHAR2(32),
         BEGIN_DATE, --     DATE,
         END_DATE, --     DATE,
         LAST_UPDATED_BY, -- VARCHAR2(32),
         LAST_UPDATE_DATE, -- DATE,
         ACTIVE_FLAG --    VARCHAR2(2),
         )
      VALUES
        (S_CREDIT_CUST_GROUP_REL.Nextval,
         0, --默认客户组ID为0
         P_CUSTOMER_ID,
         SYSDATE,
         P_USERNAME,
         SYSDATE,
         NULL,
         P_USERNAME,
         SYSDATE,
         '1') ;
     EXCEPTION WHEN OTHERS THEN
       P_RESULT  := -20000;
       P_ERR_MSG := '插入客户与客户组关系信息出错！请了解！';
       RETURN;
     END ;
   ELSIF V_COUNT <= 0 AND entityGroupCode = 'JXS' THEN --14：厨电
    BEGIN
      SELECT S_CREDIT_CUST_GROUP.NEXTVAL INTO V_CUST_GROUP_ID FROM DUAL ;
      --生成客户组信息（厨电事业部，每个客户作为一个客户组）
      INSERT INTO T_CREDIT_CUST_GROUP
        (CUST_GROUP_ID, --    NUMBER not null,
         ENTITY_ID, --        NUMBER,
         CUST_GROUP_CODE, -- VARCHAR2(100),
         CUST_GROUP_NAME, --  VARCHAR2(100),
         CREATION_DATE, --    DATE,
         CREATED_BY, --       VARCHAR2(32),
         BEGIN_DATE, --DATE,
         END_DATE, --        DATE,
         UPDATE_BY, --        VARCHAR2(32),
         UPDATE_DATE, --     DATE,
         CREDIT_RATING_ID, -- 信用等级ID（废弃不用）
         ACTIVE_FLAG --      VARCHAR2(2),
         )
      VALUES
        (V_CUST_GROUP_ID,
         P_ENTITY_ID,
         V_CUST_GROUP_ID,
         (SELECT t.CUSTOMER_NAME
            FROM T_CUSTOMER_HEADER t
           WHERE T.CUSTOMER_ID = P_CUSTOMER_ID),
         SYSDATE,
         P_USERNAME,
         SYSDATE,
         NULL,
         P_USERNAME,
         SYSDATE,
         NULL,
         '1' --生效
         );

     INSERT INTO T_CREDIT_CUST_GROUP_REL
        (REL_ID, --           NUMBER not null,
         CUST_GROUP_ID, --    NUMBER,
         CUSTOMER_ID, --     NUMBER,
         CREATION_DATE, --    DATE,
         CREATED_BY, --     VARCHAR2(32),
         BEGIN_DATE, --     DATE,
         END_DATE, --     DATE,
         LAST_UPDATED_BY, -- VARCHAR2(32),
         LAST_UPDATE_DATE, -- DATE,
         ACTIVE_FLAG --    VARCHAR2(2),
         )
      VALUES
        (S_CREDIT_CUST_GROUP_REL.NEXTVAL,
         V_CUST_GROUP_ID,
         P_CUSTOMER_ID,
         SYSDATE,
         P_USERNAME,
         SYSDATE,
         NULL,
         P_USERNAME,
         SYSDATE,
         '1') ;
   EXCEPTION WHEN OTHERS THEN
       P_RESULT  := -20000;
       P_ERR_MSG := '生成客户组信息，客户组与客户信息出错！请了解！';
       RETURN;
   END ;
   END IF ;
  END;
  --------------------------------------------------------------------------------
  /*
  *   创建日期：2014-08-08
  *     创建者：苏冬渊
  *   功能说明：客户模块从主数据引进客户与营销大类关系的时候，
               维护信用模块的客户款项明细信息
  *   返回结果：0:成功，-20000：失败
  *
  */
  -------------------------------------------------------------------------------
  PROCEDURE PRC_CREDIT_CUST_CATEGORY_INIT(P_ENTITY_ID       IN NUMBER, --主体ID
                                     P_CUSTOMER_ID     IN NUMBER, --客户ID
                                     P_SALES_MAIN_TYPE IN VARCHAR2, --营销大类编码
                                     P_PROJ_NUMBER     IN VARCHAR2, --项目号
                                     P_USERNAME        IN VARCHAR2, --登录用户名
                                     P_RESULT          OUT NUMBER ,
                                     P_ERR_MSG         OUT VARCHAR2
                                     ) IS
    V_COUNT         NUMBER;
    V_CUSTOMER_CODE T_CUSTOMER_HEADER.CUSTOMER_CODE%TYPE ;
    V_CUSTOMER_NAME T_CUSTOMER_HEADER.CUSTOMER_NAME%TYPE ;
  BEGIN
    P_RESULT := V_SEC_RESULT ;
    P_ERR_MSG:= V_SUCCESS ;
    IF P_CUSTOMER_ID IS NULL OR P_ENTITY_ID IS Null THEN
      P_RESULT  := -20000;
      P_ERR_MSG := '传入参数有问题，客户ID不能都为空！';
      RETURN;
    END IF;

   --若不存在客户款项明细信息，那么根据客户账户初始化该营销大类的款项明细信息
    FOR I IN (SELECT * FROM T_CUSTOMER_ACCOUNT T WHERE T.ENTITY_ID = P_ENTITY_ID
       AND T.CUSTOMER_ID = P_CUSTOMER_ID AND nvl(T.ACCOUNT_STATUS,'1') = '1') LOOP
    --检查是否存在客户该账户下的款项明细信息
    SELECT COUNT(1)
      INTO V_COUNT
      FROM T_SALES_ACCOUNT_MX_AMOUNT A
     WHERE A.ENTITY_ID = P_ENTITY_ID
       AND A.CUSTOMER_ID = P_CUSTOMER_ID
       AND A.ACCOUNT_ID = I.ACCOUNT_ID
       AND A.SALES_MAIN_TYPE = P_SALES_MAIN_TYPE
       --AND NVL(A.PROJ_NUMBER,'-1') = NVL(P_PROJ_NUMBER,'-1')
       AND nvl(A.ACTIVE_FLAG,'1') = '1' ;
    IF V_COUNT <= 0 THEN
      --根据客户ID获取客户编码以及客户名称
      BEGIN
        SELECT T.CUSTOMER_CODE, T.CUSTOMER_NAME
          INTO V_CUSTOMER_CODE, V_CUSTOMER_NAME
          FROM T_CUSTOMER_HEADER T
         WHERE T.CUSTOMER_ID = I.CUSTOMER_ID
           AND upper(NVL(T.ACTIVE_FLAG, 'Active')) = 'ACTIVE' ;
      EXCEPTION WHEN OTHERS THEN
        P_RESULT  := -20000;
        P_ERR_MSG := '根据客户ID获取客户信息出错！请了解！'|| V_NL || SQLERRM ;
        RETURN;
      END ;
      --初始化款项明细信息
      BEGIN
        INSERT INTO t_sales_account_mx_amount   --账户款项明细信息表
            ( account_amount_mx_id,   --账户款项明细ID
              entity_id,   --经营主体ID
              proj_number,   --项目号
              customer_id,   --客户ID
              customer_code,   --客户编码
              customer_name,   --客户名称
              account_id,   --账户ID
              account_code,   --账户编码
              account_name,   --账户名称
              sales_main_type,   --营销大类
              sales_year_id,   --销售年度ID
              received_amount,   --到款金额
              sales_amount,   --销售金额
              lock_received_amount,   --锁定到款金额
              delaypay_amount,   --铺底额度
              temp_delaypay_amount,   --临时额度
              discount_amount,   --折让金额
              applied_discount_amount,   --核销折让金额
              freeze_discount_amount,   --冻结折让金额
              lock_discount_amount,   --锁定折让金额
              dispay_amount,   --未解付金额
              creation_date,   --创建日期
              created_by,   --创建人
              last_update_date,   --修改日期
              last_updated_by,   --修改人
              three_not_pay )  --三方承兑未解付金额
       VALUES
            ( S_sales_account_mx_amount.Nextval,   --账户款项明细ID
              P_ENTITY_ID,   --经营主体ID
              P_PROJ_NUMBER,   --项目号
              P_CUSTOMER_ID,   --客户ID
              V_CUSTOMER_CODE,   --客户编码
              V_CUSTOMER_NAME,   --客户名称
              I.ACCOUNT_ID,   --账户ID
              I.ACCOUNT_CODE,   --账户编码
              I.ACCOUNT_NAME,   --账户名称
              P_SALES_MAIN_TYPE,   --营销大类
              NULL,   --销售年度ID
              0,   --到款金额
              0,   --销售金额
              0,   --锁定到款金额
              0,   --铺底额度
              0,   --临时额度
              0,   --折让金额
              0,   --核销折让金额
              0,   --冻结折让金额
              0,   --锁定折让金额
              0,   --未解付金额
              SYSDATE,   --创建日期
              P_USERNAME,   --创建人
              SYSDATE,   --修改日期
              P_USERNAME,   --修改人
              0); --三方承兑未解付金额 ;
       EXCEPTION WHEN OTHERS THEN
         P_RESULT  := -20000;
         P_ERR_MSG := '插入客户款项明细信息出错！请了解！' || V_NL || SQLERRM;
         RETURN;
       END ;
       --初始化款项日冻结信息
       /*BEGIN
         INSERT INTO t_sales_amount_freeze   --账户款项信息表
            ( cust_amount_id,   --款项ID
              entity_id,   --经营主体ID
              proj_number,   --项目号
              freeze_date,   --冻结日期
              customer_id,   --客户ID
              customer_code,   --客户编码
              customer_name,   --客户名称
              account_id,   --客户账户ID
              account_code,   --账户编码
              account_name,   --账户名称
              sales_center_code,   --营销中心编码
              sales_center_name,   --营销中心名称
              sales_year_id,   --销售年度ID
              sales_year_name,   --销售年度名称
              sales_main_type,   --营销大类
              received_amount,   --到款金额
              sales_amount,   --销售金额
              lock_received_amount,   --锁定到款金额
              delaypay_amount,   --铺底额度
              temp_delaypay_amount,   --临时额度
              discount_amount,   --折让金额
              applied_discount_amount,   --核销折让金额
              freeze_discount_amount,   --冻结折让金额
              lock_discount_amount,   --锁定折让金额
              dispay_amount,   --未解付金额
              created_by,   --创建人
              creation_date,   --创建日期
              last_updated_by,   --修改人
              last_update_date,   --修改日期
              three_not_pay )  --三方承兑未解付金额
       VALUES
            ( s_sales_amount_freeze.nextval ,   --款项ID
              P_ENTITY_ID,   --经营主体ID
              P_PROJ_NUMBER,   --项目号
              SYSDATE,   --冻结日期
              P_CUSTOMER_ID,   --客户ID
              V_CUSTOMER_CODE,   --客户编码
              V_CUSTOMER_NAME,   --客户名称
              I.ACCOUNT_ID,   --客户账户ID
              I.ACCOUNT_CODE,   --账户编码
              I.ACCOUNT_NAME,   --账户名称
              PKG_CREDIT_INTF_DUE.FUN_GET_SALES_CENTER_INTO(I.ENTITY_ID,I.CUSTOMER_ID,I.ACCOUNT_ID,2),   --营销中心编码
              PKG_CREDIT_INTF_DUE.FUN_GET_SALES_CENTER_INTO(I.ENTITY_ID,I.CUSTOMER_ID,I.ACCOUNT_ID,3),   --营销中心名称
              null,   --销售年度ID
              null,   --销售年度名称
              P_SALES_MAIN_TYPE,   --营销大类
              0,   --到款金额
              0,   --销售金额
              0,   --锁定到款金额
              0,   --铺底额度
              0,   --临时额度
              0,   --折让金额
              0,   --核销折让金额
              0,   --冻结折让金额
              0,   --锁定折让金额
              0,   --未解付金额
              SYSDATE,   --创建日期
              P_USERNAME,   --创建人
              SYSDATE,   --修改日期
              P_USERNAME,   --修改人
              0 ); --三方承兑未解付金额
       EXCEPTION WHEN OTHERS THEN
         P_RESULT  := -20000;
         P_ERR_MSG := '插入客户款项日冻结信息出错！请了解！' || V_NL || SQLERRM;
         RETURN;
       END ;*/
     END IF ;
   END LOOP ;
  END;
  --------------------------------------------------------------------------------
  /*
  *   创建日期：2014-08-08
  *     创建者：苏冬渊
  *   功能说明：客户模块根据客户模块将客户与营销大类关系失效的时候，
               维护信用模块的客户款项明细信息，将其置为失效状态
               之后需要重算款项信息
  *   返回结果：0:成功，-20000：失败
  *
  */
  -------------------------------------------------------------------------------
  /*PROCEDURE PRC_CREDIT_CUST_CATEGORY_DEL(P_ENTITY_ID       IN NUMBER, --主体ID
                                     P_CUSTOMER_ID     IN NUMBER, --客户ID
                                     P_SALES_MAIN_TYPE IN VARCHAR2, --营销大类编码
                                     --P_PROJ_NUMBER     IN VARCHAR2, --项目号
                                     P_USERNAME        IN VARCHAR2, --登录用户名
                                     P_RESULT          OUT NUMBER ,
                                     P_ERR_MSG         OUT VARCHAR2
                                     ) IS
    V_CREDIT_GROUP_ID NUMBER ;
    C_t_sales_account_amount t_sales_account_amount%ROWTYPE ;
  BEGIN
    P_RESULT := V_SEC_RESULT ;
    P_ERR_MSG:= V_SUCCESS ;
    IF P_CUSTOMER_ID IS NULL OR P_ENTITY_ID IS Null  THEN
      P_RESULT  := -20000;
      P_ERR_MSG := '传入参数有问题，客户ID不能都为空！';
      RETURN;
    END IF;

   --将该客户该营销大类下的款项明细信息全部置为失效
   BEGIN
     UPDATE T_SALES_ACCOUNT_MX_AMOUNT T SET T.ACTIVE_FLAG = '2' WHERE
     T.ENTITY_ID = P_ENTITY_ID
     AND T.CUSTOMER_ID = P_CUSTOMER_ID
     AND T.SALES_MAIN_TYPE = P_SALES_MAIN_TYPE
     AND T.ACTIVE_FLAG = '1' ;
   EXCEPTION WHEN OTHERS THEN
     P_RESULT  := -20000;
     P_ERR_MSG := '更新款项明细有效状态出错！'||V_NL|| sqlerrm ;
     RETURN;
   END ;

   V_CREDIT_GROUP_ID := PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(P_CUSTOMER_ID,P_SALES_MAIN_TYPE);
   IF V_CREDIT_GROUP_ID <> -1 THEN
     FOR I IN (SELECT T.ROWID,T.* FROM T_SALES_ACCOUNT_AMOUNT T WHERE T.CUSTOMER_ID =
       P_CUSTOMER_ID AND T.CREDIT_GROUP_ID = V_CREDIT_GROUP_ID AND T.ACTIVE_FLAG = '1') LOOP
    --根据客户款项目明细信息汇总客户款项信息,放进游标
     BEGIN
      SELECT P_ENTITY_ID,
             V_CREDIT_GROUP_ID,
             NULL,
             T.CUSTOMER_ID,
             T.CUSTOMER_CODE,
             T.CUSTOMER_NAME,
             T.ACCOUNT_ID,
             T.ACCOUNT_CODE,
             T.ACCOUNT_NAME,
             NULL,
             SUM(T.received_amount),
             SUM(T.sales_amount),
             SUM(T.lock_received_amount),
             SUM(T.delaypay_amount),
             SUM(T.temp_delaypay_amount),
             SUM(T.discount_amount),
             SUM(T.applied_discount_amount),
             SUM(T.freeze_discount_amount),
             SUM(T.lock_discount_amount),
             SUM(T.dispay_amount),
             '0',
             '0',
             SYSDATE,
             P_USERNAME,
             SYSDATE,
             P_USERNAME,
             SUM(T.three_not_pay)
        INTO c_t_sales_account_amount.entity_id, --经营主体ID
             c_t_sales_account_amount.credit_group_id, --额度组ID
             c_t_sales_account_amount.proj_number, --项目号
             c_t_sales_account_amount.customer_id, --客户ID
             c_t_sales_account_amount.customer_code, --客户编码
             c_t_sales_account_amount.customer_name, --客户名称
             c_t_sales_account_amount.account_id, --账户ID
             c_t_sales_account_amount.account_code, --账户编码
             c_t_sales_account_amount.account_name, --账户名称
             c_t_sales_account_amount.sales_year_id, --销售年度ID
             c_t_sales_account_amount.received_amount, --到款金额
             c_t_sales_account_amount.sales_amount, --销售金额
             c_t_sales_account_amount.lock_received_amount, --锁定到款金额
             c_t_sales_account_amount.delaypay_amount, --铺底额度
             c_t_sales_account_amount.temp_delaypay_amount, --临时额度
             c_t_sales_account_amount.discount_amount, --折让金额
             c_t_sales_account_amount.applied_discount_amount, --核销折让金额
             c_t_sales_account_amount.freeze_discount_amount, --冻结折让金额
             c_t_sales_account_amount.lock_discount_amount, --锁定折让金额
             c_t_sales_account_amount.dispay_amount, --未解付金额
             c_t_sales_account_amount.amount_crtl_flag, --金额控制(0:开启，-1:关闭，默认0)
             c_t_sales_account_amount.discont_crtl_flag, --折让控制(0:开启，-1:关闭，默认0)
             c_t_sales_account_amount.creation_date, --创建日期
             c_t_sales_account_amount.created_by, --创建人
             c_t_sales_account_amount.last_update_date, --修改日期
             c_t_sales_account_amount.last_updated_by, --修改人
             c_t_sales_account_amount.three_not_pay
        FROM T_SALES_ACCOUNT_MX_AMOUNT T
       WHERE T.ENTITY_ID = P_ENTITY_ID
         AND T.CUSTOMER_ID = P_CUSTOMER_ID
         AND T.ACCOUNT_ID = I.ACCOUNT_ID
         AND EXISTS
       (SELECT 1
                FROM T_CREDIT_CATEGORY_GROUP_REL S,T_CREDIT_GROUP M
               WHERE S.CREDIT_GROUP_ID = M.CREDIT_GROUP_ID
                 AND S.CREDIT_GROUP_ID = V_CREDIT_GROUP_ID
                 AND S.SALES_MAIN_TYPE = T.SALES_MAIN_TYPE
                 AND NVL(M.CREDIT_GROUP_STAT,'1') = '1')
       GROUP BY T.CUSTOMER_ID,
                T.CUSTOMER_CODE,
                T.CUSTOMER_NAME,
                T.ACCOUNT_ID,
                T.ACCOUNT_CODE,
                T.ACCOUNT_NAME ;
    EXCEPTION WHEN OTHERS THEN
      P_RESULT  := -20000;
      P_ERR_MSG := '汇总客户额度组款项信息出错！'|| SQLCODE || '   ' || SQLERRM ;
      RETURN;
    END ;

    BEGIN
       UPDATE t_sales_account_amount A
          SET A.received_amount         = c_t_sales_account_amount.received_amount, --到款金额
              A.sales_amount            = c_t_sales_account_amount.sales_amount, --销售金额
              A.lock_received_amount    = c_t_sales_account_amount.lock_received_amount, --锁定到款金额
              A.delaypay_amount         = c_t_sales_account_amount.delaypay_amount, --铺底额度
              A.temp_delaypay_amount    = c_t_sales_account_amount.temp_delaypay_amount, --临时额度
              A.discount_amount         = c_t_sales_account_amount.discount_amount, --折让金额
              A.applied_discount_amount = c_t_sales_account_amount.applied_discount_amount, --核销折让金额
              A.freeze_discount_amount  = c_t_sales_account_amount.freeze_discount_amount, --冻结折让金额
              A.lock_discount_amount    = c_t_sales_account_amount.lock_discount_amount, --锁定折让金额
              A.dispay_amount           = c_t_sales_account_amount.dispay_amount, --未解付金额
              A.creation_date           = c_t_sales_account_amount.creation_date, --创建日期
              A.created_by              = c_t_sales_account_amount.created_by, --创建人
              A.last_update_date        = c_t_sales_account_amount.last_update_date, --修改日期
              A.last_updated_by         = c_t_sales_account_amount.last_updated_by, --修改人
              A.three_not_pay           = c_t_sales_account_amount.three_not_pay
        WHERE \*A.ENTITY_ID = P_ENTITY_ID
          AND A.CUSTOMER_ID = P_CUSTOMER_ID
          AND A.ACCOUNT_ID = I.ACCOUNT_ID
          AND A.CREDIT_GROUP_ID = P_CREDIT_GROUP_ID
          AND*\ A.ROWID = I.ROWID;
     EXCEPTION WHEN OTHERS THEN
         P_RESULT  := -20000;
         P_ERR_MSG := '更新客户款项信息出错！请了解！' || V_NL || SQLERRM ;
         RETURN;
     END ;
   END LOOP ;
  ELSE
   P_RESULT  := -20000;
   P_ERR_MSG := '该客户在该营销大类下没有对应的额度组，请到额度组模块维护！';
   RETURN;
  END IF ;

  END;*/

  PROCEDURE 额度组维护模块 is
  begin
    null;
  end;
  --------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-30
  *     创建者：苏冬渊
  *   功能说明：检查额度组保存时候，营销大类是否重复的校验
  *   返回结果：0：成功，非0：失败
  *
  */
  -------------------------------------------------------------------------------
  FUNCTION FUN_GET_SALESTYPE_CHECK(P_ENTITY_ID Number ,
                                   P_CREDIT_GROUP_ID NUMBER,
                                   P_DEFAULT_FLAG    VARCHAR2)
    RETURN VARCHAR2 IS
    V_STR   VARCHAR2(1000) := '';
    V_COUNT NUMBER;
    TYPE CUR_CREDIT_CATEGORY_TYPE IS RECORD(
      V_CREDIT_GROUP_ID   T_CREDIT_GROUP.CREDIT_GROUP_ID%TYPE,
      V_CREDIT_GROUP_NUM  T_CREDIT_GROUP.CREDIT_GROUP_NUM%TYPE,
      V_CREDIT_GROUP_NAME T_CREDIT_GROUP.CREDIT_GROUP_NAME%TYPE,
      V_SALES_MAIN_TYPE   T_CREDIT_CATEGORY_GROUP_REL.SALES_MAIN_TYPE%TYPE);
    C_CREDIT_CATEGORY_TYPE CUR_CREDIT_CATEGORY_TYPE;
    V_CUSTOMER_CODE T_CUSTOMER_HEADER.CUSTOMER_CODE%TYPE ;
    VT_PUB_FIN_SYS  T_BD_PARAM_LIST.DEFAULT_VALUE%TYPE;
  BEGIN
    SELECT PKG_BD.F_GET_PARAMETER_VALUE('PUB_FIN_SYS',G.ENTITY_ID,NULL,NULL)
    INTO VT_PUB_FIN_SYS
    FROM T_CREDIT_GROUP G WHERE G.CREDIT_GROUP_ID = P_CREDIT_GROUP_ID;
    VT_PUB_FIN_SYS := NVL(VT_PUB_FIN_SYS,'ERP');
    --1、默认状态为是
    IF P_DEFAULT_FLAG = '1' OR 'NC' = VT_PUB_FIN_SYS THEN
      --默认
      --判断是否存在客户信息，若存在，提示请先删除客户信息
      SELECT COUNT(1)
        INTO V_COUNT
        FROM T_CREDIT_GROUP_CUST T
       WHERE T.Credit_Group_Id = P_CREDIT_GROUP_ID;
      IF V_COUNT > 0 THEN
        IF 'NC' = VT_PUB_FIN_SYS THEN
          V_STR := '1:额度组已存在客户信息，保存前请先删除客户信息！';
        ELSE
          V_STR := '1:额度组存在客户信息，保存成默认额度组前请先删除客户信息！';
        END IF;
        GOTO HERE;
      END IF;
      --判断营销大类是否重复
      FOR I IN (SELECT *
                  FROM T_CREDIT_CATEGORY_GROUP_REL T
                 WHERE T.Credit_Group_Id = P_CREDIT_GROUP_ID) LOOP
        BEGIN
          SELECT A.CREDIT_GROUP_ID,
                 A.CREDIT_GROUP_NUM,
                 A.CREDIT_GROUP_NAME,
                 B.SALES_MAIN_TYPE
            INTO C_CREDIT_CATEGORY_TYPE.V_CREDIT_GROUP_ID,
                 C_CREDIT_CATEGORY_TYPE.V_CREDIT_GROUP_NUM,
                 C_CREDIT_CATEGORY_TYPE.V_CREDIT_GROUP_NAME,
                 C_CREDIT_CATEGORY_TYPE.V_SALES_MAIN_TYPE
            FROM T_CREDIT_GROUP A, T_CREDIT_CATEGORY_GROUP_REL B
           WHERE A.CREDIT_GROUP_ID = B.CREDIT_GROUP_ID
             AND B.CREDIT_GROUP_ID <> I.CREDIT_GROUP_ID --非当前选中额度组
             AND A.DEFAULT_FLAG = P_DEFAULT_FLAG --默认状态
             AND B.SALES_MAIN_TYPE = I.SALES_MAIN_TYPE
             And A.ENTITY_ID = P_ENTITY_ID
             AND ROWNUM = 1;

          --若存在数据，则说明有营销大类重复
          V_STR := '2:该额度组与额度组(' ||
                   C_CREDIT_CATEGORY_TYPE.V_CREDIT_GROUP_NAME || ')的营销大类（' ||
                   C_CREDIT_CATEGORY_TYPE.V_SALES_MAIN_TYPE || ')重复！';
          GOTO HERE;
        EXCEPTION
          WHEN OTHERS THEN
            NULL;
        END;
      END LOOP;
      --默认状态为否
    ELSIF P_DEFAULT_FLAG = '2' THEN
      SELECT COUNT(1)
        INTO V_COUNT
        FROM T_CREDIT_GROUP_CUST T
       WHERE T.Credit_Group_Id = P_CREDIT_GROUP_ID;

       IF V_COUNT = 0 THEN
          --默认状态从默认改为否，检查该额度组下是否存在不依赖于特殊客户的营销大类
          SELECT COUNT(1)
            INTO V_COUNT
            FROM T_CREDIT_CATEGORY_GROUP_REL T
          WHERE T.CREDIT_GROUP_ID = P_CREDIT_GROUP_ID;
          IF V_COUNT > 0 THEN
            V_STR := '4:该额度组存在不依赖于特殊客户的营销大类，在修改为特殊额度组之前，请先删除额度组下的营销大类！';
            GOTO HERE;
          END IF ;
      END IF;

      --判断营销大类是否重复
      FOR I IN (SELECT T.*,N.CUSTOMER_ID
                  FROM T_CREDIT_CATEGORY_GROUP_REL T,T_CREDIT_GROUP_CUST N
                 WHERE T.Credit_Group_Id = P_CREDIT_GROUP_ID
                   AND T.CREDIT_GROUP_ID = N.CREDIT_GROUP_ID) LOOP
        BEGIN
          SELECT A.CREDIT_GROUP_ID,
                 A.CREDIT_GROUP_NUM,
                 A.CREDIT_GROUP_NAME,
                 B.SALES_MAIN_TYPE
            INTO C_CREDIT_CATEGORY_TYPE.V_CREDIT_GROUP_ID,
                 C_CREDIT_CATEGORY_TYPE.V_CREDIT_GROUP_NUM,
                 C_CREDIT_CATEGORY_TYPE.V_CREDIT_GROUP_NAME,
                 C_CREDIT_CATEGORY_TYPE.V_SALES_MAIN_TYPE
            FROM T_CREDIT_GROUP A, T_CREDIT_CATEGORY_GROUP_REL B,T_CREDIT_GROUP_CUST C
           WHERE A.CREDIT_GROUP_ID = B.CREDIT_GROUP_ID
             AND A.CREDIT_GROUP_ID = C.CREDIT_GROUP_ID
             AND C.CUSTOMER_ID = I.CUSTOMER_ID
             AND B.CREDIT_GROUP_ID <> I.CREDIT_GROUP_ID --非当前选中额度组
             AND A.DEFAULT_FLAG = P_DEFAULT_FLAG --默认状态为否
             AND B.SALES_MAIN_TYPE = I.SALES_MAIN_TYPE
             And A.ENTITY_ID = P_ENTITY_ID
             AND ROWNUM = 1;

          SELECT CUSTOMER_CODE
            INTO V_CUSTOMER_CODE
            FROM T_CUSTOMER_HEADER T
           WHERE T.CUSTOMER_ID = I.CUSTOMER_ID;
          --若存在数据，则说明有营销大类重复
          V_STR := '4:该额度组与额度组(' ||
                   C_CREDIT_CATEGORY_TYPE.V_CREDIT_GROUP_NAME || ')的营销大类（' ||
                   C_CREDIT_CATEGORY_TYPE.V_SALES_MAIN_TYPE || ')重复！客户编码为：' || V_CUSTOMER_CODE;
          GOTO HERE;
        EXCEPTION
          WHEN OTHERS THEN
            NULL;
        END;
      END LOOP;
    END IF;
    V_STR := '0:校验通过';
    <<HERE>>
    RETURN V_STR;
  END;

  --------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-30
  *     创建者：苏冬渊
  *   功能说明：检查营销大类与额度组关系保存时候，营销大类是否重复的校验
  *   返回结果：0：成功，非0：失败
  *
  */
  -------------------------------------------------------------------------------
  FUNCTION FUN_GET_SALESTYPE_CHECK_INFO(P_ENTITY_ID Number ,
                                        P_CREDIT_GROUP_ID NUMBER,
                                        P_SALESTYPE_STR   varchar2)
    RETURN VARCHAR2 IS
    V_STR          VARCHAR2(1000) := '';
    V_COUNT        NUMBER;
    V_DEFAULT_FLAG T_CREDIT_GROUP.DEFAULT_FLAG%TYPE;
    S_List         PKG_CREDIT_TOOLS.STR_LIST;

    TYPE CUR_CREDIT_CATEGORY_TYPE IS RECORD(
      V_CREDIT_GROUP_ID   T_CREDIT_GROUP.CREDIT_GROUP_ID%TYPE,
      V_CREDIT_GROUP_NUM  T_CREDIT_GROUP.CREDIT_GROUP_NUM%TYPE,
      V_CREDIT_GROUP_NAME T_CREDIT_GROUP.CREDIT_GROUP_NAME%TYPE,
      V_SALES_MAIN_TYPE   T_CREDIT_CATEGORY_GROUP_REL.SALES_MAIN_TYPE%TYPE);

    C_CREDIT_CATEGORY_TYPE CUR_CREDIT_CATEGORY_TYPE;
    V_CUSTOMER_CODE T_CUSTOMER_HEADER.CUSTOMER_CODE%TYPE ;
    VT_PUB_FIN_SYS  T_BD_PARAM_LIST.DEFAULT_VALUE%TYPE;
  BEGIN
    --根据额度组获取默认状态，之所以不从页面往后传，是因为页面的默认状态可能没有保存
    --这时候会以数据库的为准
    BEGIN
      SELECT T.DEFAULT_FLAG,PKG_BD.F_GET_PARAMETER_VALUE('PUB_FIN_SYS',T.ENTITY_ID,NULL,NULL)
        INTO V_DEFAULT_FLAG,VT_PUB_FIN_SYS
        FROM T_CREDIT_GROUP T
       WHERE T.Credit_Group_Id = P_CREDIT_GROUP_ID
         And T.ENTITY_ID = P_ENTITY_ID ;
    EXCEPTION
      WHEN OTHERS THEN
        V_STR := '1:获取额度组信息出错，请先保存额度组信息！';
        GOTO HERE;
    END;
    VT_PUB_FIN_SYS := NVL(VT_PUB_FIN_SYS,'ERP');
    --获取营销大类信息
    S_List := PKG_CREDIT_TOOLS.FUN_SPLIT(P_SALESTYPE_STR, ',');
    --如果额度组默认状态为否
    IF V_DEFAULT_FLAG = '1' OR 'NC' = VT_PUB_FIN_SYS THEN
      --循环遍历传进来的营销大类
      FOR I IN 1 .. S_List.COUNT LOOP
        --判断营销大类是否重复
        BEGIN
          SELECT A.CREDIT_GROUP_ID,
                 A.CREDIT_GROUP_NUM,
                 A.CREDIT_GROUP_NAME,
                 B.SALES_MAIN_TYPE
            INTO C_CREDIT_CATEGORY_TYPE.V_CREDIT_GROUP_ID,
                 C_CREDIT_CATEGORY_TYPE.V_CREDIT_GROUP_NUM,
                 C_CREDIT_CATEGORY_TYPE.V_CREDIT_GROUP_NAME,
                 C_CREDIT_CATEGORY_TYPE.V_SALES_MAIN_TYPE
            FROM T_CREDIT_GROUP A, T_CREDIT_CATEGORY_GROUP_REL B
           WHERE A.CREDIT_GROUP_ID = B.CREDIT_GROUP_ID
             AND B.CREDIT_GROUP_ID <> P_CREDIT_GROUP_ID --非当前选中额度组
             AND A.DEFAULT_FLAG = V_DEFAULT_FLAG --默认状态
             AND B.SALES_MAIN_TYPE = S_List(I)
             And a.entity_id = P_ENTITY_ID
             AND ROWNUM = 1 ;

          --若存在数据，则说明有营销大类重复
          V_STR := '3:该额度组与额度组(' ||
                   C_CREDIT_CATEGORY_TYPE.V_CREDIT_GROUP_NAME || ')的营销大类（' ||
                   C_CREDIT_CATEGORY_TYPE.V_SALES_MAIN_TYPE || ')重复！';
          GOTO HERE;
        EXCEPTION
          WHEN OTHERS THEN
            NULL;
        END;
      END LOOP;
    ELSIF V_DEFAULT_FLAG = '2' THEN
      SELECT COUNT(1)
        INTO V_COUNT
        FROM T_CREDIT_GROUP_CUST T
       WHERE T.Credit_Group_Id = P_CREDIT_GROUP_ID;
      IF V_COUNT = 0 THEN
        V_STR := '2:该额度组为特殊额度组，请先添加客户与额度组关系信息！';
        GOTO HERE;
      END IF ;

      --循环遍历传进来的营销大类
      FOR I IN 1 .. S_List.COUNT LOOP
        FOR J IN (SELECT T.* FROM T_CREDIT_GROUP_CUST T
                      WHERE T.CREDIT_GROUP_ID <> P_CREDIT_GROUP_ID) LOOP
        --判断营销大类是否重复
        BEGIN
          SELECT A.CREDIT_GROUP_ID,
                 A.CREDIT_GROUP_NUM,
                 A.CREDIT_GROUP_NAME,
                 B.SALES_MAIN_TYPE
            INTO C_CREDIT_CATEGORY_TYPE.V_CREDIT_GROUP_ID,
                 C_CREDIT_CATEGORY_TYPE.V_CREDIT_GROUP_NUM,
                 C_CREDIT_CATEGORY_TYPE.V_CREDIT_GROUP_NAME,
                 C_CREDIT_CATEGORY_TYPE.V_SALES_MAIN_TYPE
            FROM T_CREDIT_GROUP A, T_CREDIT_CATEGORY_GROUP_REL B,T_CREDIT_GROUP_CUST C
           WHERE A.CREDIT_GROUP_ID = B.CREDIT_GROUP_ID
             AND A.CREDIT_GROUP_ID = C.CREDIT_GROUP_ID
             AND B.CREDIT_GROUP_ID <> P_CREDIT_GROUP_ID --非当前选中额度组
             AND C.CUSTOMER_ID = J.CUSTOMER_ID
             AND A.DEFAULT_FLAG = V_DEFAULT_FLAG --默认状态
             AND B.SALES_MAIN_TYPE = S_List(I)
             And a.entity_id = P_ENTITY_ID
             AND ROWNUM = 1 ;

        SELECT CUSTOMER_CODE
            INTO V_CUSTOMER_CODE
            FROM T_CUSTOMER_HEADER T
           WHERE T.CUSTOMER_ID = J.CUSTOMER_ID;
          --若存在数据，则说明有营销大类重复
          V_STR := '3:该额度组与额度组(' ||
                   C_CREDIT_CATEGORY_TYPE.V_CREDIT_GROUP_NAME || ')的营销大类（' ||
                   C_CREDIT_CATEGORY_TYPE.V_SALES_MAIN_TYPE || ')重复！特殊客户编码为：' || V_CUSTOMER_CODE;
          GOTO HERE;
        EXCEPTION
          WHEN OTHERS THEN
            /*V_STR := '4:检查营销大类是否存在出错！' || V_NL || SQLERRM ;
            GOTO HERE;*/
            NULL ;
        END;
        END LOOP ;
      END LOOP;

      END IF;
   -- END IF;
    V_STR := '0:校验通过';
    <<HERE>>
    RETURN V_STR;
  END;

  --------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-30
  *     创建者：苏冬渊
  *   功能说明：检查客户信息与额度组关系保存时候，是否已经存在
  *   返回结果：0：成功，非0：失败
  *
  */
  -------------------------------------------------------------------------------
  FUNCTION FUN_GET_CUSTOMER_CHECK(P_CREDIT_GROUP_ID NUMBER,
                                  P_CUSTOMER_STR    varchar2) RETURN VARCHAR2 IS
    V_STR          VARCHAR2(1000) := '';
    V_COUNT        NUMBER;
    V_DEFAULT_FLAG T_CREDIT_GROUP.DEFAULT_FLAG%TYPE;
    S_List         PKG_CREDIT_TOOLS.STR_LIST;
    V_CUSTOMER_CODE T_CUSTOMER_HEADER.CUSTOMER_CODE%TYPE ;
  BEGIN
    --根据额度组获取默认状态，之所以不从页面往后传，是因为页面的默认状态可能没有保存
    --这时候会以数据库的为准
    BEGIN
      SELECT T.DEFAULT_FLAG
        INTO V_DEFAULT_FLAG
        FROM T_CREDIT_GROUP T
       WHERE T.Credit_Group_Id = P_CREDIT_GROUP_ID
         AND T.DEFAULT_FLAG = '2';
    EXCEPTION
      WHEN OTHERS THEN
        V_STR := '1:选中的额度组信息，并不是特殊客户的额度组，不能增加客户信息与额度组关系！';
        GOTO HERE;
    END;

    --获取客户ID信息
    S_List := PKG_CREDIT_TOOLS.FUN_SPLIT(P_CUSTOMER_STR, ',');
    --循环遍历传进来的客户信息
    FOR I IN 1 .. S_List.COUNT LOOP
      --判断客户信息是否已经存在
      BEGIN
        SELECT COUNT(1)
          INTO V_COUNT
          FROM t_Credit_Group_Cust A
         WHERE A.CREDIT_GROUP_ID = P_CREDIT_GROUP_ID
           AND A.CUSTOMER_ID = S_List(I);

        SELECT T.CUSTOMER_CODE INTO V_CUSTOMER_CODE FROM T_CUSTOMER_HEADER T WHERE T.CUSTOMER_ID = S_List(I) ;
        IF V_COUNT > 0 THEN
          --若存在数据，则说明有特殊客户重复
          V_STR := '2:该额度组已经存在客户编码为'|| V_CUSTOMER_CODE ||'的客户信息，请了解！';
          GOTO HERE;
        END IF;
      EXCEPTION
        WHEN OTHERS THEN
          NULL;
      END;
    END LOOP;

    V_STR := '0:校验通过';
    <<HERE>>
    RETURN V_STR;
  END;

  --------------------------------------------------------------------------------
  /*
  *   创建日期：2014-10-29
  *     创建者：苏冬渊
  *   功能说明：检查客户信息与额度组关系删除时候，是否删除将额度组相关的客户关系全部删除
                若是，则将跟额度组相关的营销大类全部删除，否则只删除选择的客户关系
  *   返回结果：0：成功，非0：失败
  *
  */
  -------------------------------------------------------------------------------
  FUNCTION FUN_GET_CUSTOMER_DEL_CHECK(P_CREDIT_GROUP_ID NUMBER,
                                      P_CUSTOMER_STR    varchar2) RETURN NUMBER IS
    V_COUNT        NUMBER;
  BEGIN

    /*
    SELECT COUNT(1) INTO V_COUNT
      FROM T_CREDIT_GROUP_CUST T
     WHERE T.CREDIT_GROUP_ID = P_CREDIT_GROUP_ID
       AND INSTR(P_CUSTOMER_STR, T.CUSTOMER_ID) = 0;
       P_CUSTOMER_STR在T_CREDIT_GROUP_CUST匹配
       1、部分匹配、部分不匹配：返回大于0
       2、全部不匹配：返回大于0
       3、全部匹配：返回0
    */
    SELECT COUNT(0) INTO V_COUNT
      FROM (SELECT REGEXP_SUBSTR(T.C, '[^,]{1,}', 1, LEVEL) AS LI
              FROM (SELECT P_CUSTOMER_STR C FROM DUAL) T
            CONNECT BY LEVEL <= (1 + LENGTH(REGEXP_REPLACE(T.C, '[^,]', '')))
             ORDER BY LEVEL)
     WHERE NOT EXISTS (SELECT 1
              FROM T_CREDIT_GROUP_CUST T
             WHERE T.CREDIT_GROUP_ID = P_CREDIT_GROUP_ID
               AND T.CUSTOMER_ID = TO_NUMBER(LI))
     AND EXISTS (SELECT 1
              FROM T_CREDIT_GROUP_CUST T
             WHERE T.CREDIT_GROUP_ID = P_CREDIT_GROUP_ID);

    RETURN V_COUNT;
  EXCEPTION WHEN OTHERS THEN
   V_COUNT := -1 ;
   RETURN V_COUNT ;
  END;
  --------------------------------------------------------------------------------
  /*
  *   创建日期：2014-08-08
  *     创建者：苏冬渊
  *   功能说明：额度组维护模块，
                1、额度组内营销大类增加减少时进行客户款项新增或者变更
                   维护信用模块的客户款项信息
                2、维护额度组与营销大类关系
  *   返回结果：0:成功，-20000：失败
  */
  -------------------------------------------------------------------------------
  PROCEDURE PRC_CREDIT_SALES_TYPE_SAVE(P_ENTITY_ID         IN NUMBER, --主体ID
                                       P_CREDIT_GROUP_ID   IN NUMBER, --客户额度组ID
                                       P_salesTypeStr     IN VARCHAR2, --营销大类字符串
                                       P_USERNAME        IN VARCHAR2, --登录用户名
   --PROCEDURE PRC_CREDIT_SALES_TYPE_SAVE(
                                       P_RESULT          OUT NUMBER ,
                                       P_ERR_MSG         OUT VARCHAR2
                                     ) IS
    V_COUNT         NUMBER;
    --P_ENTITY_ID NUMBER;
    --P_CREDIT_GROUP_ID NUMBER;
    --P_salesTypeStr VARCHAR2(100);
    --P_USERNAME VARCHAR2(100);
    C_T_CREDIT_CATEGORY_GROUP_REL T_CREDIT_CATEGORY_GROUP_REL%ROWTYPE ;
    S_LIST PKG_CREDIT_TOOLS.STR_LIST ;
  BEGIN
    --P_ENTITY_ID := '14';
    --P_CREDIT_GROUP_ID := '375';
    --P_salesTypeStr := 'CJ';
    --P_USERNAME := '甘家荣';
    P_RESULT := V_SEC_RESULT ;
    P_ERR_MSG:= V_SUCCESS ;
    IF P_CREDIT_GROUP_ID IS NULL  THEN
      P_RESULT  := -20000;
      P_ERR_MSG := '传入参数有问题，P_CREDIT_GROUP_ID额度组ID不能为空！';
      RETURN;
    END IF;

   --分解
   S_LIST := PKG_CREDIT_TOOLS.FUN_SPLIT(P_salesTypeStr,',');
   --存储额度组与营销大类关系
   FOR I IN 1 .. S_LIST.COUNT LOOP
     BEGIN
       --C_T_CREDIT_CATEGORY_GROUP_REL.REL_ID = S_CREDIT_CATEGORY_GROUP_REL.NEXTVAL ;
       C_T_CREDIT_CATEGORY_GROUP_REL.CREDIT_GROUP_ID := P_CREDIT_GROUP_ID ;
       C_T_CREDIT_CATEGORY_GROUP_REL.SALES_MAIN_TYPE := S_LIST(I) ;
       C_T_CREDIT_CATEGORY_GROUP_REL.CREATED_BY := P_USERNAME ;
       C_T_CREDIT_CATEGORY_GROUP_REL.CREATION_DATE := SYSDATE ;
       C_T_CREDIT_CATEGORY_GROUP_REL.LAST_UPDATED_BY := P_USERNAME ;
       C_T_CREDIT_CATEGORY_GROUP_REL.LAST_UPDATE_DATE := SYSDATE ;

       SELECT COUNT(1) INTO V_COUNT
           FROM T_CREDIT_CATEGORY_GROUP_REL T
         WHERE T.CREDIT_GROUP_ID = P_CREDIT_GROUP_ID
           AND T.SALES_MAIN_TYPE = S_LIST(I) ;

       IF V_COUNT <= 0 THEN --V_COUNT <= 0 不存在，则新增
          C_T_CREDIT_CATEGORY_GROUP_REL.REL_ID := S_CREDIT_CATEGORY_GROUP_REL.NEXTVAL ;
          INSERT INTO T_CREDIT_CATEGORY_GROUP_REL
          VALUES C_T_CREDIT_CATEGORY_GROUP_REL;
       ELSIF V_COUNT = 1 THEN
          UPDATE T_CREDIT_CATEGORY_GROUP_REL T
             SET T.CREATED_BY       = C_T_CREDIT_CATEGORY_GROUP_REL.CREATED_BY,
                 T.CREATION_DATE    = C_T_CREDIT_CATEGORY_GROUP_REL.CREATION_DATE,
                 T.LAST_UPDATED_BY  = C_T_CREDIT_CATEGORY_GROUP_REL.LAST_UPDATED_BY,
                 T.LAST_UPDATE_DATE = C_T_CREDIT_CATEGORY_GROUP_REL.LAST_UPDATE_DATE
           WHERE T.CREDIT_GROUP_ID = P_CREDIT_GROUP_ID
             AND T.SALES_MAIN_TYPE = S_LIST(I);
       END IF ;
     EXCEPTION WHEN OTHERS THEN
      P_RESULT  := -20000;
      P_ERR_MSG := '维护营销大类与额度组关系表信息出错！' || V_NL || SQLERRM ;
      RETURN;
     END ;
   END LOOP;

   prc_credit_amount_save(p_entity_id => p_entity_id,
                          p_credit_group_id => p_credit_group_id,
                          p_username => p_username,
                          p_result => p_result,
                          p_err_msg => p_err_msg);

  END;
  --------------------------------------------------------------------------------
  /*
  *   创建日期：2014-08-08
  *     创建者：苏冬渊
  *   功能说明：额度组维护模块，额度组内营销大类增加减少时进行客户款项新增或者变更
               维护信用模块的客户款项信息
  *   返回结果：0:成功，-20000：失败
  *
  */
  -------------------------------------------------------------------------------
  PROCEDURE PRC_CREDIT_AMOUNT_SAVE(P_ENTITY_ID         IN NUMBER, --主体ID
                                   P_CREDIT_GROUP_ID   IN NUMBER, --客户额度组ID
                                   P_USERNAME        IN VARCHAR2, --登录用户名
                                   P_RESULT          OUT NUMBER ,
                                   P_ERR_MSG         OUT VARCHAR2
                                     ) IS

    --V_COUNT         NUMBER;
    --C_t_sales_account_amount t_sales_account_amount%ROWTYPE ;
    R_CREDIT_GROUP T_CREDIT_GROUP%ROWTYPE ;
   /* S_LIST PKG_CREDIT_TOOLS.STR_LIST ;
    C_T_CREDIT_CATEGORY_GROUP_REL T_CREDIT_CATEGORY_GROUP_REL%ROWTYPE ;*/
  BEGIN

    P_RESULT := V_SEC_RESULT ;
    P_ERR_MSG:= V_SUCCESS ;

    IF P_CREDIT_GROUP_ID IS NULL  THEN
      P_RESULT  := -20000;
      P_ERR_MSG := '传入参数有问题，P_CREDIT_GROUP_ID额度组ID不能为空！';
      RETURN;
    END IF;

    --根据额度组ID获取额度组信息
    BEGIN
      SELECT T.*
        INTO R_CREDIT_GROUP
        FROM T_CREDIT_GROUP T
       WHERE T.CREDIT_GROUP_ID = P_CREDIT_GROUP_ID;
    EXCEPTION WHEN OTHERS THEN
      P_RESULT  := -20000;
      P_ERR_MSG := '根据额度组ID获取额度组信息出错！'|| V_NL ||SQLERRM ;
      RETURN;
    END ;

    BEGIN
    --额度组营销大类修改,先删除之前额度组存在的客户款项信息
    INSERT INTO T_SALES_ACCOUNT_AMOUNT_DEL_LOG
              (ACCOUNT_AMOUNT_ID,
               ENTITY_ID,
               CREDIT_GROUP_ID,
               PROJ_NUMBER,
               CUSTOMER_ID,
               CUSTOMER_CODE,
               CUSTOMER_NAME,
               ACCOUNT_ID,
               ACCOUNT_CODE,
               ACCOUNT_NAME,
               SALES_YEAR_ID,
               RECEIVED_AMOUNT,
               SALES_AMOUNT,
               LOCK_RECEIVED_AMOUNT,
               DELAYPAY_AMOUNT,
               TEMP_DELAYPAY_AMOUNT,
               DISCOUNT_AMOUNT,
               APPLIED_DISCOUNT_AMOUNT,
               FREEZE_DISCOUNT_AMOUNT,
               LOCK_DISCOUNT_AMOUNT,
               DISPAY_AMOUNT,
               AMOUNT_CRTL_FLAG,
               DISCONT_CRTL_FLAG,
               CREATION_DATE,
               CREATED_BY,
               LAST_UPDATE_DATE,
               LAST_UPDATED_BY,
               PRE_FIELD_01,
               PRE_FIELD_02,
               PRE_FIELD_03,
               PRE_FIELD_04,
               PRE_FIELD_05,
               PRE_FIELD_06,
               THREE_NOT_PAY,
               ACTIVE_FLAG,
               RESOURCE_AMOUNT,
               LOCK_RESOURCE_AMOUNT,
               TRANSACTION_AMOUNT,
               RECEIVABLE_CRTL_FLAG
               )
              SELECT ACCOUNT_AMOUNT_ID,
                     ENTITY_ID,
                     CREDIT_GROUP_ID,
                     PROJ_NUMBER,
                     CUSTOMER_ID,
                     CUSTOMER_CODE,
                     CUSTOMER_NAME,
                     ACCOUNT_ID,
                     ACCOUNT_CODE,
                     ACCOUNT_NAME,
                     SALES_YEAR_ID,
                     RECEIVED_AMOUNT,
                     SALES_AMOUNT,
                     LOCK_RECEIVED_AMOUNT,
                     DELAYPAY_AMOUNT,
                     TEMP_DELAYPAY_AMOUNT,
                     DISCOUNT_AMOUNT,
                     APPLIED_DISCOUNT_AMOUNT,
                     FREEZE_DISCOUNT_AMOUNT,
                     LOCK_DISCOUNT_AMOUNT,
                     DISPAY_AMOUNT,
                     AMOUNT_CRTL_FLAG,
                     DISCONT_CRTL_FLAG,
                     CREATION_DATE,
                     CREATED_BY,
                     LAST_UPDATE_DATE,
                     LAST_UPDATED_BY,
                     PRE_FIELD_01,
                     PRE_FIELD_02,
                     PRE_FIELD_03,
                     PRE_FIELD_04,
                     PRE_FIELD_05,
                     PRE_FIELD_06,
                     THREE_NOT_PAY,
                     ACTIVE_FLAG,
                     RESOURCE_AMOUNT,
                     LOCK_RESOURCE_AMOUNT,
                     TRANSACTION_AMOUNT,
                     RECEIVABLE_CRTL_FLAG
                FROM T_SALES_ACCOUNT_AMOUNT
               WHERE ENTITY_ID = P_ENTITY_ID
               AND CREDIT_GROUP_ID = P_CREDIT_GROUP_ID;
    DELETE T_SALES_ACCOUNT_AMOUNT T WHERE T.ENTITY_ID = P_ENTITY_ID
    AND T.CREDIT_GROUP_ID = P_CREDIT_GROUP_ID;

    INSERT INTO T_SALES_ACCOUNT_AMOUNT(
      account_amount_id,
      entity_id,
      credit_group_id,
      proj_number,
      customer_id,
      customer_code,
      customer_name,
      account_id,
      account_code,
      account_name,
      sales_year_id,
      received_amount,
      sales_amount,
      lock_received_amount,
      delaypay_amount,
      temp_delaypay_amount,
      discount_amount,
      applied_discount_amount,
      freeze_discount_amount,
      lock_discount_amount,
      dispay_amount,
      amount_crtl_flag,
      discont_crtl_flag,
      creation_date,
      created_by,
      last_update_date,
      last_updated_by,
      three_not_pay,
      active_flag,
      RESOURCE_AMOUNT,
      LOCK_RESOURCE_AMOUNT,
      TRANSACTION_AMOUNT
      --,RECEIVABLE_CRTL_FLAG
      ,MPAY_STREAM_AMOUNT
      ,MPAY_CASH_AMOUNT
    ) SELECT s_sales_account_amount.nextval account_amount_id,B.* FROM
      (SELECT
      T.ENTITY_ID entity_id,
      PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(T.ENTITY_ID,T.CUSTOMER_ID,t.sales_main_type,t.account_id) credit_group_id,
      NULL proj_number,
      T.CUSTOMER_ID customer_id,
      T.CUSTOMER_CODE customer_code,
      --T.CUSTOMER_NAME customer_name,
      (Select customer_name From t_customer_header Where customer_id = t.customer_id) customer_name,
      T.ACCOUNT_ID account_id,
      T.ACCOUNT_CODE account_code,
      T.ACCOUNT_NAME account_name,
      NULL sales_year_id,
      SUM(T.RECEIVED_AMOUNT) received_amount,
      SUM(T.SALES_AMOUNT) sales_amount,
      SUM(T.LOCK_RECEIVED_AMOUNT) lock_received_amount,
      SUM(T.DELAYPAY_AMOUNT) delaypay_amount,
      SUM(T.TEMP_DELAYPAY_AMOUNT) temp_delaypay_amount,
      SUM(T.DISCOUNT_AMOUNT) discount_amount,
      SUM(T.APPLIED_DISCOUNT_AMOUNT) applied_discount_amount,
      SUM(T.FREEZE_DISCOUNT_AMOUNT) freeze_discount_amount,
      SUM(T.LOCK_DISCOUNT_AMOUNT) lock_discount_amount,
      SUM(T.DISPAY_AMOUNT) dispay_amount,
      '0' amount_crtl_flag,
      '0' discont_crtl_flag,
      SYSDATE creation_date,
      P_USERNAME created_by,
      SYSDATE last_update_date,
      P_USERNAME last_updated_by,
      SUM(T.THREE_NOT_PAY) three_not_pay,
      '1' active_flag,
      SUM(T.RESOURCE_AMOUNT) AS RESOURCE_AMOUNT,
      SUM(T.LOCK_RESOURCE_AMOUNT) AS LOCK_RESOURCE_AMOUNT,
      SUM(T.TRANSACTION_AMOUNT) AS TRANSACTION_AMOUNT
      --,MAX(T.RECEIVABLE_CRTL_FLAG) AS RECEIVABLE_CRTL_FLAG
      ,SUM(T.MPAY_STREAM_AMOUNT) AS MPAY_STREAM_AMOUNT,
      SUM(T.MPAY_CASH_AMOUNT) AS MPAY_CASH_AMOUNT
      FROM T_SALES_ACCOUNT_MX_AMOUNT T
      WHERE T.ENTITY_ID = P_ENTITY_ID
        /*AND PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(T.ENTITY_ID,T.CUSTOMER_ID,t.sales_main_type,t.account_id) > 0
        AND EXISTS(SELECT 1 FROM T_CREDIT_CATEGORY_GROUP_REL C
                           WHERE C.CREDIT_GROUP_ID =
                           PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(T.ENTITY_ID,T.CUSTOMER_ID,t.sales_main_type,t.account_id))*/
        GROUP BY T.ENTITY_ID,
        PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(T.ENTITY_ID,T.CUSTOMER_ID,t.sales_main_type,t.account_id),
        T.CUSTOMER_ID,
        T.CUSTOMER_CODE,
        T.ACCOUNT_ID,
        T.ACCOUNT_CODE,
        T.ACCOUNT_NAME) B
        ,(SELECT DISTINCT G.CREDIT_GROUP_ID FROM T_CREDIT_CATEGORY_GROUP_REL R,T_CREDIT_GROUP G
        WHERE G.CREDIT_GROUP_ID = R.CREDIT_GROUP_ID AND G.ENTITY_ID = P_ENTITY_ID) C
        WHERE B.CREDIT_GROUP_ID = C.CREDIT_GROUP_ID
        AND B.CREDIT_GROUP_ID = P_CREDIT_GROUP_ID
        ;
    EXCEPTION WHEN OTHERS THEN
      P_RESULT  := -20000;
      P_ERR_MSG := '从客户款项明细更新客户款项信息出错！'|| V_NL ||SQLERRM ;
      RETURN;
    END ;
  END;
  
  
  
    --------------------------------------------------------------------------------
  /*
  *   创建日期：2019-11-07
  *     创建者：guibr
  *   功能说明：按客户调整客户额度组维护模块
  *   返回结果：0:成功，-20000：失败
  *
  */
  -------------------------------------------------------------------------------
  PROCEDURE PRC_CREDIT_AMOUNT_RELOAD(P_ENTITY_ID         IN NUMBER, --主体ID
                                    P_CUSTOMER_ID        IN NUMBER, --客户ID
                                    P_ACCOUNT_ID         IN NUMBER, --账户ID
                                    P_USERNAME           IN VARCHAR2, --登录用户名
                                    P_RESULT          OUT NUMBER ,
                                    P_ERR_MSG         OUT VARCHAR2
                                  ) IS
                                  
    BEGIN
        P_RESULT := V_SEC_RESULT ;
        P_ERR_MSG:= V_SUCCESS ;
             --额度组营销大类修改,先删除之前额度组存在的客户款项信息
        INSERT INTO T_SALES_ACCOUNT_AMOUNT_DEL_LOG
                  (ACCOUNT_AMOUNT_ID,
                   ENTITY_ID,
                   CREDIT_GROUP_ID,
                   PROJ_NUMBER,
                   CUSTOMER_ID,
                   CUSTOMER_CODE,
                   CUSTOMER_NAME,
                   ACCOUNT_ID,
                   ACCOUNT_CODE,
                   ACCOUNT_NAME,
                   SALES_YEAR_ID,
                   RECEIVED_AMOUNT,
                   SALES_AMOUNT,
                   LOCK_RECEIVED_AMOUNT,
                   DELAYPAY_AMOUNT,
                   TEMP_DELAYPAY_AMOUNT,
                   DISCOUNT_AMOUNT,
                   APPLIED_DISCOUNT_AMOUNT,
                   FREEZE_DISCOUNT_AMOUNT,
                   LOCK_DISCOUNT_AMOUNT,
                   DISPAY_AMOUNT,
                   AMOUNT_CRTL_FLAG,
                   DISCONT_CRTL_FLAG,
                   CREATION_DATE,
                   CREATED_BY,
                   LAST_UPDATE_DATE,
                   LAST_UPDATED_BY,
                   PRE_FIELD_01,
                   PRE_FIELD_02,
                   PRE_FIELD_03,
                   PRE_FIELD_04,
                   PRE_FIELD_05,
                   PRE_FIELD_06,
                   THREE_NOT_PAY,
                   ACTIVE_FLAG,
                   RESOURCE_AMOUNT,
                   LOCK_RESOURCE_AMOUNT,
                   TRANSACTION_AMOUNT,
                   RECEIVABLE_CRTL_FLAG
                   )
                  SELECT ACCOUNT_AMOUNT_ID,
                         ENTITY_ID,
                         CREDIT_GROUP_ID,
                         PROJ_NUMBER,
                         CUSTOMER_ID,
                         CUSTOMER_CODE,
                         CUSTOMER_NAME,
                         ACCOUNT_ID,
                         ACCOUNT_CODE,
                         ACCOUNT_NAME,
                         SALES_YEAR_ID,
                         RECEIVED_AMOUNT,
                         SALES_AMOUNT,
                         LOCK_RECEIVED_AMOUNT,
                         DELAYPAY_AMOUNT,
                         TEMP_DELAYPAY_AMOUNT,
                         DISCOUNT_AMOUNT,
                         APPLIED_DISCOUNT_AMOUNT,
                         FREEZE_DISCOUNT_AMOUNT,
                         LOCK_DISCOUNT_AMOUNT,
                         DISPAY_AMOUNT,
                         AMOUNT_CRTL_FLAG,
                         DISCONT_CRTL_FLAG,
                         CREATION_DATE,
                         CREATED_BY,
                         LAST_UPDATE_DATE,
                         LAST_UPDATED_BY,
                         PRE_FIELD_01,
                         PRE_FIELD_02,
                         PRE_FIELD_03,
                         PRE_FIELD_04,
                         PRE_FIELD_05,
                         PRE_FIELD_06,
                         THREE_NOT_PAY,
                         ACTIVE_FLAG,
                         RESOURCE_AMOUNT,
                         LOCK_RESOURCE_AMOUNT,
                         TRANSACTION_AMOUNT,
                         RECEIVABLE_CRTL_FLAG
                    FROM T_SALES_ACCOUNT_AMOUNT
                   WHERE ENTITY_ID = P_ENTITY_ID
                   AND CUSTOMER_ID = P_CUSTOMER_ID
                   AND ACCOUNT_ID =  P_ACCOUNT_ID;
                   
        DELETE T_SALES_ACCOUNT_AMOUNT T WHERE T.ENTITY_ID =P_ENTITY_ID
                   AND T.CUSTOMER_ID = P_CUSTOMER_ID
                   AND T.ACCOUNT_ID =  P_ACCOUNT_ID;

        INSERT INTO T_SALES_ACCOUNT_AMOUNT(
          account_amount_id,
          entity_id,
          credit_group_id,
          proj_number,
          customer_id,
          customer_code,
          customer_name,
          account_id,
          account_code,
          account_name,
          sales_year_id,
          received_amount,
          sales_amount,
          lock_received_amount,
          delaypay_amount,
          temp_delaypay_amount,
          discount_amount,
          applied_discount_amount,
          freeze_discount_amount,
          lock_discount_amount,
          dispay_amount,
          amount_crtl_flag,
          discont_crtl_flag,
          creation_date,
          created_by,
          last_update_date,
          last_updated_by,
          three_not_pay,
          active_flag,
          RESOURCE_AMOUNT,
          LOCK_RESOURCE_AMOUNT,
          TRANSACTION_AMOUNT
          --,RECEIVABLE_CRTL_FLAG
          ,MPAY_STREAM_AMOUNT
          ,MPAY_CASH_AMOUNT
        ) SELECT s_sales_account_amount.nextval account_amount_id,B.* FROM
          (SELECT
          T.ENTITY_ID entity_id,
          PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(T.ENTITY_ID,T.CUSTOMER_ID,t.sales_main_type,t.account_id) credit_group_id,
          NULL proj_number,
          T.CUSTOMER_ID customer_id,
          T.CUSTOMER_CODE customer_code,
          (Select customer_name From t_customer_header Where customer_id = t.customer_id) customer_name,
          T.ACCOUNT_ID account_id,
          T.ACCOUNT_CODE account_code,
          T.ACCOUNT_NAME account_name,
          NULL sales_year_id,
          SUM(T.RECEIVED_AMOUNT) received_amount,
          SUM(T.SALES_AMOUNT) sales_amount,
          SUM(T.LOCK_RECEIVED_AMOUNT) lock_received_amount,
          SUM(T.DELAYPAY_AMOUNT) delaypay_amount,
          SUM(T.TEMP_DELAYPAY_AMOUNT) temp_delaypay_amount,
          SUM(T.DISCOUNT_AMOUNT) discount_amount,
          SUM(T.APPLIED_DISCOUNT_AMOUNT) applied_discount_amount,
          SUM(T.FREEZE_DISCOUNT_AMOUNT) freeze_discount_amount,
          SUM(T.LOCK_DISCOUNT_AMOUNT) lock_discount_amount,
          SUM(T.DISPAY_AMOUNT) dispay_amount,
          '0' amount_crtl_flag,
          '0' discont_crtl_flag,
          SYSDATE creation_date,
          P_USERNAME created_by,
          SYSDATE last_update_date,
          P_USERNAME last_updated_by,
          SUM(T.THREE_NOT_PAY) three_not_pay,
          '1' active_flag,
          SUM(T.RESOURCE_AMOUNT) AS RESOURCE_AMOUNT,
          SUM(T.LOCK_RESOURCE_AMOUNT) AS LOCK_RESOURCE_AMOUNT,
          SUM(T.TRANSACTION_AMOUNT) AS TRANSACTION_AMOUNT
          --,MAX(T.RECEIVABLE_CRTL_FLAG) AS RECEIVABLE_CRTL_FLAG
          ,SUM(T.MPAY_STREAM_AMOUNT) AS MPAY_STREAM_AMOUNT,
          SUM(T.MPAY_CASH_AMOUNT) AS MPAY_CASH_AMOUNT
          FROM T_SALES_ACCOUNT_MX_AMOUNT T
          WHERE T.ENTITY_ID = P_ENTITY_ID
                   AND T.CUSTOMER_ID = P_CUSTOMER_ID
                   AND T.ACCOUNT_ID =  P_ACCOUNT_ID
            GROUP BY T.ENTITY_ID,
            PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(T.ENTITY_ID,T.CUSTOMER_ID,t.sales_main_type,t.account_id),
            T.CUSTOMER_ID,
            T.CUSTOMER_CODE,
            T.ACCOUNT_ID,
            T.ACCOUNT_CODE,
            T.ACCOUNT_NAME) B;
     EXCEPTION WHEN OTHERS THEN
         P_RESULT  := -20000;
         P_ERR_MSG := '维护营销大类与额度组关系表信息出错！' || SQLERRM ;       
     END;
     
     
     
    --------------------------------------------------------------------------------
  /*
  *   创建日期：2019-11-07
  *     创建者：guibr
  *   功能说明：找出客户错误额度组重新计算客户款项
  *   返回结果：0:成功，-20000：失败
  *
  */
  -------------------------------------------------------------------------------
  PROCEDURE PRC_CREDIT_GROUP_ERROR_REP(P_ENTITY_ID         IN NUMBER, --主体ID
                                    P_USERNAME           IN VARCHAR2, --登录用户名
                                    P_RESULT          OUT NUMBER ,
                                    P_ERR_MSG         OUT VARCHAR2
                                  ) IS
     S_CHILD_RESULT NUMBER; 
     S_CHILD_ERR_MSG VARCHAR2(10000);                    
                                  
  BEGIN
      P_RESULT := V_SEC_RESULT ;
      P_ERR_MSG:= V_SUCCESS ;   
      FOR 
          CREDIT_HEADER_ROW 
      IN( 
               SELECT DISTINCT ENTITY_ID,CUSTOMER_ID,ACCOUNT_ID  FROM (
                      SELECT
                            T.ENTITY_ID ENTITY_ID,
                            PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(T.ENTITY_ID,T.CUSTOMER_ID,T.SALES_MAIN_TYPE,T.ACCOUNT_ID) CREDIT_GROUP_ID,
                            T.CUSTOMER_ID CUSTOMER_ID,
                            T.CUSTOMER_CODE CUSTOMER_CODE,
                            T.ACCOUNT_ID ACCOUNT_ID,
                            T.ACCOUNT_CODE ACCOUNT_CODE
                        FROM CIMS.T_SALES_ACCOUNT_MX_AMOUNT T
                        WHERE T.ENTITY_ID = P_ENTITY_ID
                        GROUP BY T.ENTITY_ID,
                           PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(T.ENTITY_ID,T.CUSTOMER_ID,T.SALES_MAIN_TYPE,T.ACCOUNT_ID),
                           T.CUSTOMER_ID,
                           T.CUSTOMER_CODE,
                           T.ACCOUNT_ID,
                           T.ACCOUNT_CODE
                       MINUS
                       SELECT SA.ENTITY_ID
                             ,SA.CREDIT_GROUP_ID
                             ,SA.CUSTOMER_ID
                             ,SA.CUSTOMER_CODE
                             ,SA.ACCOUNT_ID
                             ,SA.ACCOUNT_CODE
                       FROM CIMS.T_SALES_ACCOUNT_AMOUNT SA 
                       WHERE SA.ENTITY_ID =  P_ENTITY_ID   
                ) WHERE CREDIT_GROUP_ID>0
         )LOOP
           BEGIN   
                PRC_CREDIT_AMOUNT_RELOAD(CREDIT_HEADER_ROW.ENTITY_ID
                                         ,CREDIT_HEADER_ROW.CUSTOMER_ID
                                         ,CREDIT_HEADER_ROW.ACCOUNT_ID
                                         ,P_USERNAME
                                         ,S_CHILD_RESULT
                                         ,S_CHILD_ERR_MSG
                                        );          
           END;
        END LOOP;  
   EXCEPTION WHEN OTHERS THEN
        P_RESULT  := -20000;
        P_ERR_MSG := '维护额度组关系表信息出错！' || SQLERRM ;       
   END;   
     
     
end PKG_CREDIT_BUSINESS_DUE;
/

