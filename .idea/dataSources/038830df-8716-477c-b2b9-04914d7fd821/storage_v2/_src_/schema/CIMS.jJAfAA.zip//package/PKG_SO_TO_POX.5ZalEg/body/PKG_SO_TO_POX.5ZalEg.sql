create PACKAGE BODY      PKG_SO_TO_POX IS
  V_BASE_EXCEPTION EXCEPTION; --自定义异常
  V_NL                       CONSTANT VARCHAR2(2) := CHR(13) || CHR(10); --换行
  V_SUCCESS                  CONSTANT VARCHAR2(10) := 'SUCCESS';
  V_ACTIVE                   CONSTANT VARCHAR2(10) := 'Active';
  V_ACCOUNT_ACTIVE           CONSTANT VARCHAR2(10) := '1';
  V_TRUE                     CONSTANT VARCHAR2(10) := 'T';
  V_YES                      CONSTANT VARCHAR2(10) := 'Y';
  V_NO                       CONSTANT VARCHAR2(10) := 'N';
  V_INVENTORY_CATEGORY_01    CONSTANT VARCHAR2(10) := '01'; --关联仓
  V_INV_DOCKING_SYSTEM_A3    CONSTANT VARCHAR2(10) := 'A3'; --安得托管
  V_VENDOR_MAIN_TYPE_00      CONSTANT VARCHAR2(10) := '00'; --内部供应商
  SO_BILL_CODE_SO_TC         CONSTANT VARCHAR2(10) := '1049'; --电商销售单类型
  APPLY_STATUS_30            CONSTANT VARCHAR2(10) := '30'; --价格批文状态：审批通过
  DISCOUNT_TYPE_COMMON       CONSTANT VARCHAR2(10) := 'COMMON'; --常规到款折扣类型
  DISCOUNT_TYPE_DISCOUNT     CONSTANT VARCHAR2(10) := 'DISCOUNT'; --折扣类型
  SP_CONSIGNEE_ADDR          CONSTANT VARCHAR2(240) := '自提'; --自提地址
  SP_CONSIGNEE_ADDR_ID       CONSTANT NUMBER := -1; --自提地址ID
  SP_CONSIGNEE_ADDR_CODE     CONSTANT VARCHAR2(100) := '000000'; --自提收货地点编码
  SP_CONSIGNEE_CONTRACT_ID   CONSTANT NUMBER := -1; --自提地址ID
  SP_CONSIGNEE_CONTRACT_NAME CONSTANT VARCHAR2(100) := '/'; --自提收货联系人
  SP_CONSIGNEE_CONTRACT_TEL  CONSTANT VARCHAR2(100) := '/'; --自提收货联系电话
  TRSF_BILL_TYPE_1055        CONSTANT VARCHAR2(100) := '1055'; --状态调整调拨单据类型
  CLAIM_BILL_TYPE_1020       CONSTANT VARCHAR2(100) := '1020'; --全赔单据类型
  INVENTORY_TYPE_04          CONSTANT VARCHAR2(100) := '04'; --仓库类型：破损仓
  INVENTORY_TYPE_07          CONSTANT VARCHAR2(100) := '07'; --仓库类型：在途仓
  INVENTORY_TYPE_03          CONSTANT VARCHAR2(100) := '03'; --仓库类型：残次品仓
  V_SO_SRC_TYPE_31           CONSTANT VARCHAR2(10) := '31'; --销售单的来源类型：销售转采购
  
  V_LOCK_AMOUNT_FLAG_S CONSTANT VARCHAR2(10) := 'S'; --送审锁款
  V_LOCK_AMOUNT_FLAG_RS CONSTANT VARCHAR2(10) := 'RS'; --资源送审锁款
  V_LOCK_AMOUNT_FLAG_Y CONSTANT VARCHAR2(10) := 'Y'; --发货锁款
  V_LOCK_AMOUNT_FLAG_RT CONSTANT VARCHAR2(10) := 'RT'; --资源提货锁款
  V_LOCK_AMOUNT_FLAG_HQ CONSTANT VARCHAR2(10) := 'HQ'; --送总部评审锁款
  ---------------------------------------------------------
  --从销售单生成采购单
  ---------------------------------------------------------
  PROCEDURE P_SO_TO_POX_USEPARAM(IN_ENTITY_ID  IN NUMBER, --主体ID
                                 IN_PARAM_ID   IN NUMBER, --转采购参数表ID
                                 IN_USER_CODE  IN VARCHAR2, --操作用户
                                 OUT_PO_NUMBER OUT VARCHAR2, --采购单号
                                 OUT_RESULT    IN OUT VARCHAR2) IS
    R_PARAM_HEAD                  T_SO_TO_SUPP_PARAM_HEAD%ROWTYPE;
    R_SO_HEAD                     T_SO_HEADER%ROWTYPE;
    R_SO_LINE                     T_SO_LINE%ROWTYPE;
    V_IN_PARAM                    VARCHAR2(4000);
    R_PO_HEAD                     T_INV_PO_HEADERS%ROWTYPE;
    R_PO_LINE                     T_INV_PO_LINES%ROWTYPE;
    R_PO_ASS_LINE                 T_INV_PO_ASSEMBLE_LINES%ROWTYPE;
    R_PO_SUB_LINE                 T_INV_PO_ASSEMBLE_LINES%ROWTYPE; --用于写散件
    V_SALES_CENTER_CODE           UP_ORG_UNIT.CODE%TYPE; --中心编码
    V_SALES_CENTER_NAME           UP_ORG_UNIT.NAME%TYPE; --中心名称
    V_BILL_TYPE_NAME              T_INV_BILL_TYPES.BILL_TYPE_NAME%TYPE; --采购单据类型名称
    V_INV_DOCKING_SYSTEM          T_INV_INVENTORIES.DOCKING_SYSTEM%TYPE; --仓库所属单位
    V_ASS_ITEM_CODE               T_BD_ITEM.ITEM_CODE%TYPE; --套件编码
    V_FLAG                        VARCHAR2(1) := V_NO;
    V_ASS_FLAG                    VARCHAR2(1) := V_NO;
    V_PO_LINE_ID                  NUMBER;
    OUT_ERR_NUM                   NUMBER;
    V_INV_CTRL                    T_BD_PARAM_ENTITY.ENTITY_VALUE%TYPE := 'Y';
    V_MAX_REJECTED_QTY            NUMBER;
    V_MIN_REJECTED_QTY            NUMBER;
    V_1                           NUMBER;
    V_2                           NUMBER;
    V_3                           VARCHAR2(1000);
    V_4                           VARCHAR2(1000);
    V_ALL_REJECTED                VARCHAR2(1) := V_NO; --判断是否全部拒收，全部拒收不生成采购单
    V_CANCEL_QTY                  NUMBER := 0;
    V_CANCEL_AMOUNT               NUMBER;
    V_CANCEL_DIS_AMOUNT           NUMBER;
    R_CUSTOMER_ACCOUNT_SALECENTER V_CUSTOMER_ACCOUNT_SALECENTER%ROWTYPE;
    V_OS_ATTRIB01                 VARCHAR2(1000);
    V_OS_ATTRIB02                 VARCHAR2(1000);
    V_RESULT                      VARCHAR2(10);
    V_SUB_ITEM_QUANTITY_SCALE     NUMBER;
    V_TAX_RATE NUMBER; --20180409 hejy3 默认税率
    V_PO_ASS_LINE_PRICE NUMBER; --20180426 hejy3 套件行价格
    V_COUNT             NUMBER;
  BEGIN
    OUT_RESULT := V_SUCCESS;
    SAVEPOINT SP_SO_TO_POX_USEPARAM;
  
    --锁定转采购参数表数据
    V_IN_PARAM := '转采购参数表ID=' || TO_CHAR(IN_PARAM_ID);
    BEGIN
      SELECT *
        INTO R_PARAM_HEAD
        FROM T_SO_TO_SUPP_PARAM_HEAD H
       WHERE H.PARAM_ID = IN_PARAM_ID
         FOR UPDATE NOWAIT;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        OUT_RESULT := '传入参数有误，找不到转采购的数据！';
      WHEN OTHERS THEN
        OUT_RESULT := '锁定销售转采购的数据失败，可能有其他人正在操作，请稍后重试！';
    END;
  
    IF OUT_RESULT = V_SUCCESS THEN
      --锁定来源销售单
      V_IN_PARAM := '销售单ID=' || TO_CHAR(R_PARAM_HEAD.SOURCE_ORDER_ID) ||
                    ',销售单号=' || R_PARAM_HEAD.SOURCE_ORDER_NUMBER;
      BEGIN
        SELECT H.*
          INTO R_SO_HEAD
          FROM T_SO_HEADER H
         WHERE H.SO_HEADER_ID = R_PARAM_HEAD.SOURCE_ORDER_ID
           FOR UPDATE NOWAIT;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          OUT_RESULT := '找不到转采购的销售单！';
        WHEN OTHERS THEN
          OUT_RESULT := '锁定转采购的销售失败，可能有其他人正在操作，请稍后重试！';
      END;
    END IF;
  
    IF OUT_RESULT = V_SUCCESS THEN
      R_PO_HEAD.SOURCE_TYPE      := '销售转采购';
      R_PO_HEAD.SOURCE_ORDER_ID  := R_PARAM_HEAD.SOURCE_ORDER_ID;
      R_PO_HEAD.SOURCE_ORDER_NUM := R_PARAM_HEAD.SOURCE_ORDER_NUMBER;
      R_PO_HEAD.INPUT_NUM        := R_PARAM_HEAD.SOURCE_ORDER_NUMBER;
      R_PO_HEAD.SOURCE_SYSTEM    := 'CIMS';
      R_PO_HEAD.REMARK           := R_PARAM_HEAD.REMARK || '[来源单号：' ||
                                    R_PARAM_HEAD.SOURCE_ORDER_NUMBER || ']';
      R_PO_HEAD.ENTITY_ID        := R_PARAM_HEAD.ENTITY_ID;
    END IF;
  
    --20170727 hejy3 增加非直发非安得接收销售单仓库控制参数
    BEGIN
      V_INV_CTRL := PKG_BD.F_GET_PARAMETER_VALUE('SO_TO_PO_INV_CONCTRL',
                                                 IN_ENTITY_ID,
                                                 NULL,
                                                 NULL);
    EXCEPTION
      WHEN OTHERS THEN
        OUT_RESULT := '获取参数失败，参数编码：SO_TO_PO_INV_CONCTRL';
    END;

    --检查是否已完成转采购
    IF OUT_RESULT = V_SUCCESS THEN
      V_IN_PARAM := '销售单号=' || R_PARAM_HEAD.SOURCE_ORDER_NUMBER;
      IF R_SO_HEAD.TO_SUPP_FLAG = 'Y' THEN
        OUT_RESULT := '当前销售单已完成转采购，请刷新数据！';
      END IF;
      
      --按来源单号检查是否已存在采购单
      SELECT COUNT(1)
        INTO V_COUNT
        FROM T_INV_PO_HEADERS H
       WHERE H.SOURCE_TYPE = R_PO_HEAD.SOURCE_TYPE
         AND H.SOURCE_ORDER_NUM = R_PARAM_HEAD.SOURCE_ORDER_NUMBER;
      
      IF V_COUNT > 0 THEN
        OUT_RESULT := '当前销售单已完成转采购，请刷新数据！';
      END IF;
    END IF;
  
    --检查采购单据类型有效性
    IF OUT_RESULT = V_SUCCESS THEN
      V_IN_PARAM := '采购单据类型ID=' || TO_CHAR(R_PARAM_HEAD.PO_TYPE_ID);
      BEGIN
        SELECT B.BILL_TYPE_ID, B.BILL_TYPE_CODE, B.BILL_TYPE_NAME
          INTO R_PO_HEAD.PO_TYPE_ID, R_PO_HEAD.PO_TYPE, V_BILL_TYPE_NAME
          FROM T_INV_BILL_TYPES B
         WHERE B.BILL_TYPE_ID = R_PARAM_HEAD.PO_TYPE_ID
           AND SYSDATE BETWEEN B.BEGIN_DATE AND
               NVL(B.END_DATE, SYSDATE + 1);
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          OUT_RESULT := '采购入库单据类型不存在或已失效，请检查业务单据类型设置！';
      END;
    END IF;
  
    --检查单据类型关系
    IF OUT_RESULT = V_SUCCESS THEN
      V_IN_PARAM := '源单据类型=' || R_SO_HEAD.BILL_TYPE_NAME || ',源单据类型ID=' ||
                    TO_CHAR(R_SO_HEAD.BILL_TYPE_ID) || '目标单据类型=' ||
                    V_BILL_TYPE_NAME || ',目标单据类型ID=' ||
                    TO_CHAR(R_PARAM_HEAD.PO_TYPE_ID);
      BEGIN
        SELECT V_SUCCESS
          INTO OUT_RESULT
          FROM T_PLN_ORDER_TYPE_RELA R
         WHERE R.RELATION_TYPE = 'SO_TO_POX'
           AND R.SOURCE_ORDER_TYPE_ID = R_SO_HEAD.BILL_TYPE_ID
           AND R.SOURCE_ENTITY_ID = R_SO_HEAD.ENTITY_ID
           AND R.TRANSFER_ORDER_TYPE_ID = R_PO_HEAD.PO_TYPE_ID
           AND R.TRANSFER_ENTITY_ID = R_PARAM_HEAD.ENTITY_ID;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          OUT_RESULT := '未设置源单据类型(销售单类型)与目标单据类型(采购入库单据类型)关系，请检查转采购的单据类型关系设置！';
      END;
    END IF;
  
    --检查采购中心有效性
    IF OUT_RESULT = V_SUCCESS THEN
      V_IN_PARAM := '中心ID=' || TO_CHAR(R_PARAM_HEAD.SALES_CENTER_ID) ||
                    ',编码=' || R_PARAM_HEAD.SALES_CENTER_CODE || ',名称=' ||
                    R_PARAM_HEAD.SALES_CENTER_NAME;
      BEGIN
        SELECT U.UNIT_ID, U.CODE, U.NAME
          INTO R_PO_HEAD.SALES_CENTER_ID,
               R_PO_HEAD.SALES_CENTER_CODE,
               R_PO_HEAD.SALES_CENTER_NAME
          FROM UP_ORG_UNIT U
         WHERE U.UNIT_ID = R_PARAM_HEAD.SALES_CENTER_ID
           AND U.IS_ENABLED = V_TRUE
           AND U.ACTIVE_FLAG = V_TRUE;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          OUT_RESULT := '采购入库中心不存在或已失效，请检查中心设置';
      END;
    END IF;
  
    --检查采购入库仓库有效性
    IF OUT_RESULT = V_SUCCESS THEN
      V_IN_PARAM := '仓库ID=' || TO_CHAR(R_PARAM_HEAD.FINANCE_INV_ID) ||
                    ',仓库编码=' || R_PARAM_HEAD.FINANCE_INV_CODE || ',仓库名称=' ||
                    R_PARAM_HEAD.FINANCE_INV_NAME;
      BEGIN
        SELECT I.INVENTORY_ID,
               I.INVENTORY_CODE,
               I.INVENTORY_NAME,
               O.OPERATING_UNIT,
               O.ORGANIZATION_ID,
               I.DOCKING_SYSTEM
          INTO R_PO_HEAD.INV_FINANCE_ID,
               R_PO_HEAD.INV_FINANCE_CODE,
               R_PO_HEAD.INV_FINANCE_NAME,
               R_PO_HEAD.FINANCE_OPERATING_ID,
               R_PO_HEAD.FINANCE_ORGANIZATION_ID,
               V_INV_DOCKING_SYSTEM
          FROM T_INV_INVENTORIES I, T_INV_ORGANIZATION O
         WHERE I.INVENTORY_ID = R_PARAM_HEAD.FINANCE_INV_ID
           AND I.PURCHASE_FLAG = V_YES --可采购
           AND I.INVENTORY_CATEGORY = V_INVENTORY_CATEGORY_01 --关联仓
           AND I.ORGANIZATION_ID = O.ORGANIZATION_ID(+)
           AND I.ENTITY_ID = O.ENTITY_ID(+)
           AND SYSDATE BETWEEN I.BEGIN_DATE AND
               NVL(I.END_DATE, SYSDATE + 1);
      EXCEPTION
        WHEN OTHERS THEN
          OUT_RESULT := '采购入库仓库不存在或已失效，请检查仓库设置！' || V_NL ||
                        '仓库需满足条件：采购标志=Y，仓库类别=关联仓';
      END;
    END IF;
  
    --根据销售单的安得接收标识控制入库仓库
    IF OUT_RESULT = V_SUCCESS THEN
      --20171025 hejy3 退货单转采购
      IF R_PARAM_HEAD.RETURN_BILL_FLAG = V_YES THEN
        IF V_INV_DOCKING_SYSTEM = V_INV_DOCKING_SYSTEM_A3 THEN
          OUT_RESULT := '退货单转采购不能入库到安得托管仓库，请检查仓库属性设置或重新选择仓库！';
        END IF;
      ELSE
        IF R_PARAM_HEAD.ANNTO_RECEIVE_FLAG = V_YES AND V_INV_DOCKING_SYSTEM <> V_INV_DOCKING_SYSTEM_A3 THEN
          OUT_RESULT := '当前销售单由安得接收，采购入库仓库需为安得托管仓库，请检查仓库属性设置！';
        ELSIF (NVL(R_PARAM_HEAD.ANNTO_RECEIVE_FLAG, V_NO) <> V_YES AND NVL(R_SO_HEAD.SELF_PICK_FLAG, V_NO) <> V_YES AND
          (NVL(R_PARAM_HEAD.DIRECT_SEND_FLAG, V_NO) <> V_YES AND V_INV_CTRL = V_YES AND V_INV_DOCKING_SYSTEM = V_INV_DOCKING_SYSTEM_A3))
          OR
          (NVL(R_PARAM_HEAD.ANNTO_RECEIVE_FLAG, V_NO) <> V_YES AND NVL(R_PARAM_HEAD.DIRECT_SEND_FLAG, V_NO) = V_YES
          AND V_INV_DOCKING_SYSTEM = V_INV_DOCKING_SYSTEM_A3) THEN
          OUT_RESULT := '当前销售单非安得接收，不能入库到安得托管仓库，请检查仓库属性设置！';
        END IF;
      END IF;
    END IF;
  
    --检查用户中心仓库权限关系
    IF OUT_RESULT = V_SUCCESS THEN
      V_IN_PARAM := '中心编码=' || R_PO_HEAD.SALES_CENTER_CODE || ',名称=' ||
                    R_PO_HEAD.SALES_CENTER_NAME || '仓库编码=' ||
                    R_PO_HEAD.INV_FINANCE_CODE || ',名称=' ||
                    R_PO_HEAD.INV_FINANCE_NAME;
      BEGIN
        SELECT V_SUCCESS
          INTO OUT_RESULT
          FROM V_BD_USER_INV_PRIV P
         WHERE P.USER_CODE = IN_USER_CODE
           --AND P."UNIT_ID" = R_PO_HEAD.SALES_CENTER_ID
           AND P."INVENTORY_ID" = R_PO_HEAD.INV_FINANCE_ID
           AND EXISTS (SELECT 1 FROM T_INV_INVENTORIES_SALES_CENTER C
                        WHERE C.INVENTORY_ID = P.INVENTORY_ID
                          AND C.UNIT_ID = R_PO_HEAD.SALES_CENTER_ID);
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          OUT_RESULT := '中心和入库仓库不匹配，或者当前用户没有操作入库仓库的权限，请检查权限设置！';
      END;
    END IF;
  
    --检查供应商
    IF OUT_RESULT = V_SUCCESS THEN
      V_IN_PARAM := '供应商ID=' || TO_CHAR(R_PARAM_HEAD.VENDOR_ID) || ',编码=' ||
                    R_PARAM_HEAD.VENDOR_CODE || ',名称=' ||
                    R_PARAM_HEAD.VENDOR_NAME;
      BEGIN
        SELECT V.VENDOR_ID,
               V.VENDOR_CODE,
               V.VENDOR_NAME,
               V.OPERATING_UNIT,
               V.ORGANIZATION_ID,
               V.VENDOR_SITE_CODE
          INTO R_PO_HEAD.VENDOR_ID,
               R_PO_HEAD.VENDOR_CODE,
               R_PO_HEAD.VENDOR_NAME,
               R_PO_HEAD.VENDOR_OPERATING_ID,
               R_PO_HEAD.VENDOR_ORGANIZATION_ID,
               R_PO_HEAD.VENDOR_SITE_CODE
          FROM V_INV_VENDOR_VIEW V
         WHERE V.VENDOR_ID = R_PARAM_HEAD.VENDOR_ID
              --AND V.vendor_main_type = V_VENDOR_MAIN_TYPE_00 --内部供应商
           AND ROWNUM = 1;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          OUT_RESULT := '供应商不存在或已失效，请检查供应商设置！';
      END;
    END IF;
  
    IF OUT_RESULT = V_SUCCESS THEN
      V_IN_PARAM := NULL;
      IF R_PARAM_HEAD.PO_BILL_DATE IS NULL THEN
        OUT_RESULT := '采购单据日期不能为空！';
      ELSE
        R_PO_HEAD.BILLED_DATE := R_PARAM_HEAD.PO_BILL_DATE;
      END IF;
    END IF;
  
    --检查产品数量，必须满足产品数量=实收正品数+实收破损数+短少数+拒收数才能转采购
    IF OUT_RESULT = V_SUCCESS THEN
      V_IN_PARAM := '销售单号=' || R_PARAM_HEAD.SOURCE_ORDER_NUMBER;
      SELECT TO_CHAR(WM_CONCAT('产品=' || L.SUB_ITEM_CODE || ',实收正品数=' ||
                               TO_CHAR(NVL(L.FACT_REV_GOOD_QTY, 0)) ||
                               ',实收破损数=' || TO_CHAR(NVL(L.FACT_REV_SHATTER_QTY, 0)) ||
                               ',实收残次品数=' || TO_CHAR(NVL(L.FACT_REV_DEFECTIVE_QTY, 0)) ||
                               ',短少数=' || TO_CHAR(NVL(L.MISSING_QTY, 0)) ||
                               ',拒收数=' || TO_CHAR(NVL(L.REJECTED_QTY, 0)) || V_NL))
        INTO OUT_RESULT
        FROM T_SO_TO_SUPP_PARAM_LINE L
       WHERE L.PARAM_ID = IN_PARAM_ID
         AND L.ITEM_QTY - NVL(L.CANCEL_QTY, 0) >
             NVL(L.FACT_REV_GOOD_QTY, 0) + NVL(L.FACT_REV_SHATTER_QTY, 0) +
             NVL(L.FACT_REV_DEFECTIVE_QTY, 0) + 
             NVL(L.MISSING_QTY, 0) + NVL(L.REJECTED_QTY, 0);
      IF OUT_RESULT IS NULL THEN
        OUT_RESULT := V_SUCCESS;
      END IF;
    END IF;
  
    --更新销售单明细行的数量
    IF OUT_RESULT = V_SUCCESS THEN
      V_IN_PARAM := '更新销售单明细行的数量出错';
      IF NVL(R_SO_HEAD.ANNTO_RECEIVE_FLAG, 'N') <> 'Y' THEN
        --非安得接收才更新
        UPDATE T_SO_LINE_DETAIL D
           SET (D.FACT_RECEIVE_QTY,
                D.FACT_REV_GOOD_QTY,
                D.FACT_REV_SHATTER_QTY,
                D.FACT_REV_DEFECTIVE_QTY,
                D.MISSING_QTY,
                D.REJECTED_QTY) =
               (SELECT L.FACT_RECEIVE_QTY,
                       L.FACT_REV_GOOD_QTY,
                       L.FACT_REV_SHATTER_QTY,
                       L.FACT_REV_DEFECTIVE_QTY,
                       L.MISSING_QTY,
                       L.REJECTED_QTY
                  FROM T_SO_TO_SUPP_PARAM_LINE L
                 WHERE L.PARAM_ID = IN_PARAM_ID
                   AND L.SOURCE_LINE_ID = D.SO_LINE_ID
                   AND L.SUB_ITEM_CODE = D.COMPONENT_CODE)
         WHERE D.SO_HEADER_ID = R_SO_HEAD.SO_HEADER_ID;
      ELSE --更新短少和拒收数
        UPDATE T_SO_LINE_DETAIL D
           SET (D.MISSING_QTY, D.REJECTED_QTY) =
               (SELECT L.MISSING_QTY, L.REJECTED_QTY
                  FROM T_SO_TO_SUPP_PARAM_LINE L
                 WHERE L.PARAM_ID = IN_PARAM_ID
                   AND L.SOURCE_LINE_ID = D.SO_LINE_ID
                   AND L.SUB_ITEM_CODE = D.COMPONENT_CODE)
         WHERE D.SO_HEADER_ID = R_SO_HEAD.SO_HEADER_ID;
      END IF;
    END IF;
  
    --更新发货通知单直发转采购数量
    IF OUT_RESULT = V_SUCCESS THEN
      V_IN_PARAM := '更新发货通知单直发转采购数量出错';
      UPDATE T_LG_SHIP_DOC_LINE L
         SET L.TRANSFER_TO_POX_QTY = NVL(L.TRANSFER_TO_POX_QTY, 0) +
                                     (SELECT (SPL.ITEM_QTY - NVL(SPL.CANCEL_QTY, 0))/NVL(SPL.SUB_ITEM_QTY_SCALE,1)
                                        FROM CIMS.T_SO_TO_SUPP_PARAM_LINE SPL,
                                             CIMS.T_SO_LINE               SL
                                       WHERE SPL.PARAM_ID = IN_PARAM_ID
                                         AND SL.SO_LINE_ID = SPL.SOURCE_LINE_ID
                                         AND SL.SHIP_DOC_LINE_ID = L.SHIP_DOC_LINE_ID
                                         AND ROWNUM = 1),
             L.LAST_UPDATED_BY     = IN_USER_CODE,
             L.LAST_UPDATE_DATE    = SYSDATE
       WHERE L.SHIP_DOC_LINE_ID IN
             (SELECT SL.SHIP_DOC_LINE_ID
                FROM T_SO_LINE SL
               WHERE SL.SO_HEADER_ID = R_PARAM_HEAD.SOURCE_ORDER_ID);
    END IF;
    --判断是否全部拒收
    --现在调整为拒收的数量也要写入采购单，所以全拒收直接为否，不用判断 lilh6 2019-11-22
    /*IF OUT_RESULT = V_SUCCESS THEN
      V_IN_PARAM := '判断是否全部拒收出错';
      BEGIN
        SELECT '非全部拒收'
          INTO OUT_RESULT
          FROM T_SO_TO_SUPP_PARAM_LINE L
         WHERE L.PARAM_ID = IN_PARAM_ID
           AND L.ITEM_QTY > NVL(L.REJECTED_QTY, 0)
           AND rownum = 1;
        IF OUT_RESULT <> '非全部拒收' THEN
          V_ALL_REJECTED := V_YES;
        END IF;
        OUT_RESULT := V_SUCCESS;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          V_ALL_REJECTED := V_YES;
          OUT_RESULT := V_SUCCESS;      
      END;

    END IF;*/
    
    --更新行的散件配比数量
    V_IN_PARAM := '更新转采购明细行的散件配比数量';
    UPDATE CIMS.T_SO_TO_SUPP_PARAM_LINE L
       SET L.SUB_ITEM_QTY_SCALE = NVL((SELECT S.QUANTITY
                                     FROM CIMS.V_BD_ITEM_ASSEMBLIES_SUB S
                                    WHERE S.ENTITY_ID = L.ENTITY_ID
                                      AND S.ITEM_CODE = L.ASS_ITEM_CODE
                                      AND S.SUB_ITEM_CODE = L.SUB_ITEM_CODE
                                      AND S.ASSEMBLE_ACTIVE_FLAG = 'Y'
                                      AND S.ACTIVE_FLAG = 'Y'), 1)
     WHERE L.PARAM_ID = IN_PARAM_ID;
  
    IF OUT_RESULT = V_SUCCESS THEN
      R_PO_HEAD.PO_STATUS        := '10'; --制单状态
      R_PO_HEAD.PRICE_LIST_ID    := 0;
      R_PO_HEAD.CREATED_BY       := IN_USER_CODE;
      R_PO_HEAD.CREATION_DATE    := SYSDATE;
      R_PO_HEAD.LAST_UPDATED_BY  := IN_USER_CODE;
      R_PO_HEAD.LAST_UPDATE_DATE := SYSDATE;
      R_PO_HEAD.CLOSE_FLAG       := 'N';
    END IF;
  
    --按照转采购产品明细行大类进行拆单
    IF OUT_RESULT = V_SUCCESS AND V_ALL_REJECTED = V_NO THEN
      FOR R_ITEM_TYPE IN (SELECT DISTINCT NVL(L.ASS_ITEM_MAIN_TYPE,
                                              BI.SALES_MAIN_TYPE) SALES_MAIN_TYPE
                            FROM T_SO_TO_SUPP_PARAM_LINE L, T_BD_ITEM BI
                           WHERE L.PARAM_ID = IN_PARAM_ID
                             AND L.ENTITY_ID = BI.ENTITY_ID
                             AND L.ASS_ITEM_CODE = BI.ITEM_CODE) LOOP
        V_IN_PARAM                := '营销大类=' || R_ITEM_TYPE.SALES_MAIN_TYPE;
        R_PO_HEAD.SALES_MAIN_TYPE := R_ITEM_TYPE.SALES_MAIN_TYPE;
      
        --获取采购单号
        PKG_BD.P_GET_BILL_NO(P_BILL_TYPE  => 'invPONum',
                             P_PREFIX_ADD => NULL,
                             P_ENTITY_ID  => R_PO_HEAD.ENTITY_ID,
                             P_USER_ID    => NULL,
                             P_BILL_NO    => R_PO_HEAD.PO_NUM);
        IF R_PO_HEAD.PO_NUM IS NULL THEN
          OUT_RESULT := '生成采购单号失败，编码规则编号[invPONum]';
        END IF;
      
        IF OUT_RESULT = V_SUCCESS THEN
          IF OUT_PO_NUMBER IS NULL THEN
            OUT_PO_NUMBER := R_PO_HEAD.PO_NUM;
          ELSE
            OUT_PO_NUMBER := OUT_PO_NUMBER || ',' || R_PO_HEAD.PO_NUM;
          END IF;
          --获取采购单据ID
          SELECT S_INV_PO_HEADERS.NEXTVAL INTO R_PO_HEAD.PO_ID FROM DUAL;
        END IF;
      
        IF OUT_RESULT = V_SUCCESS THEN
          BEGIN
            --插入采购单头表
            INSERT INTO T_INV_PO_HEADERS
              (PO_ID,
               ENTITY_ID,
               PO_TYPE_ID,
               PO_TYPE,
               PO_NUM,
               BILLED_DATE,
               PO_STATUS,
               SALES_MAIN_TYPE,
               INV_FINANCE_ID,
               INV_FINANCE_CODE,
               INV_FINANCE_NAME,
               VENDOR_ID,
               VENDOR_CODE,
               VENDOR_NAME,
               SALES_CENTER_ID,
               SALES_CENTER_CODE,
               SALES_CENTER_NAME,
               PRICE_LIST_ID,
               CREATED_BY,
               CREATION_DATE,
               REMARK,
               LAST_UPDATED_BY,
               LAST_UPDATE_DATE,
               SOURCE_TYPE,
               SOURCE_ORDER_ID,
               SOURCE_ORDER_NUM,
               SOURCE_SYSTEM,
               VENDOR_OPERATING_ID,
               VENDOR_ORGANIZATION_ID,
               VENDOR_SITE_CODE,
               FINANCE_OPERATING_ID,
               FINANCE_ORGANIZATION_ID,
               CLOSE_FLAG,
               INPUT_NUM)
            VALUES
              (R_PO_HEAD.PO_ID,
               R_PO_HEAD.ENTITY_ID,
               R_PO_HEAD.PO_TYPE_ID,
               R_PO_HEAD.PO_TYPE,
               R_PO_HEAD.PO_NUM,
               R_PO_HEAD.BILLED_DATE,
               R_PO_HEAD.PO_STATUS,
               R_PO_HEAD.SALES_MAIN_TYPE,
               R_PO_HEAD.INV_FINANCE_ID,
               R_PO_HEAD.INV_FINANCE_CODE,
               R_PO_HEAD.INV_FINANCE_NAME,
               R_PO_HEAD.VENDOR_ID,
               R_PO_HEAD.VENDOR_CODE,
               R_PO_HEAD.VENDOR_NAME,
               R_PO_HEAD.SALES_CENTER_ID,
               R_PO_HEAD.SALES_CENTER_CODE,
               R_PO_HEAD.SALES_CENTER_NAME,
               R_PO_HEAD.PRICE_LIST_ID,
               R_PO_HEAD.CREATED_BY,
               R_PO_HEAD.CREATION_DATE,
               R_PO_HEAD.REMARK,
               R_PO_HEAD.LAST_UPDATED_BY,
               R_PO_HEAD.LAST_UPDATE_DATE,
               R_PO_HEAD.SOURCE_TYPE,
               R_PO_HEAD.SOURCE_ORDER_ID,
               R_PO_HEAD.SOURCE_ORDER_NUM,
               R_PO_HEAD.SOURCE_SYSTEM,
               R_PO_HEAD.VENDOR_OPERATING_ID,
               R_PO_HEAD.VENDOR_ORGANIZATION_ID,
               R_PO_HEAD.VENDOR_SITE_CODE,
               R_PO_HEAD.FINANCE_OPERATING_ID,
               R_PO_HEAD.FINANCE_ORGANIZATION_ID,
               R_PO_HEAD.CLOSE_FLAG,
               R_PO_HEAD.INPUT_NUM);
          EXCEPTION
            WHEN OTHERS THEN
              OUT_RESULT := '插入采购单头失败！' || V_NL || '系统提示：' || SQLERRM;
          END;
        END IF;
      
        IF OUT_RESULT = V_SUCCESS THEN
          R_PO_LINE.PO_LINE_NUM := 0;
          V_ASS_ITEM_CODE       := '_';
          --处理采购单据行
          FOR R_PARAM_LINE IN (SELECT L.*
                                 FROM T_SO_TO_SUPP_PARAM_LINE L,
                                      T_BD_ITEM               BI
                                WHERE L.PARAM_ID = IN_PARAM_ID
                                  AND L.ENTITY_ID = BI.ENTITY_ID
                                  AND L.ASS_ITEM_CODE = BI.ITEM_CODE
                                  AND NVL(L.ASS_ITEM_MAIN_TYPE,
                                          BI.SALES_MAIN_TYPE) =
                                      R_PO_HEAD.SALES_MAIN_TYPE
                                  AND L.ITEM_QTY - NVL(L.CANCEL_QTY, 0) > 0
                                ORDER BY L.ASS_ITEM_CODE) LOOP
            --检查是否已存在当前产品编码的采购单行
            BEGIN
              SELECT L.PO_LINE_ID
                INTO V_PO_LINE_ID
                FROM T_INV_PO_LINES L
               WHERE L.PO_ID = R_PO_HEAD.PO_ID
                 AND L.ITEM_CODE = R_PARAM_LINE.SUB_ITEM_CODE;
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                V_PO_LINE_ID := NULL;
            END;
          
            --存在则更新数量
            IF V_PO_LINE_ID IS NOT NULL THEN
              UPDATE T_INV_PO_LINES L
                 SET L.BILLED_QTY = L.BILLED_QTY + R_PARAM_LINE.ITEM_QTY -
                                    NVL(R_PARAM_LINE.CANCEL_QTY, 0)
               WHERE L.PO_LINE_ID = V_PO_LINE_ID;
            ELSE
              --不存在则插入
              R_PO_LINE.BILLED_QTY       := R_PARAM_LINE.ITEM_QTY -
                                              NVL(R_PARAM_LINE.CANCEL_QTY,
                                                  0);
              --数量大于0才处理
              IF R_PO_LINE.BILLED_QTY > 0 THEN
                --检查产品是否有效
                V_IN_PARAM := '产品编码=' || R_PARAM_LINE.SUB_ITEM_CODE || ',名称=' ||
                              R_PARAM_LINE.SUB_ITEM_NAME;
                BEGIN
                  SELECT I.ITEM_ID,
                         I.ITEM_CODE,
                         I.ITEM_NAME,
                         I.DEFAULTUNIT,
                         I.BARCODE
                    INTO R_PO_LINE.ITEM_ID,
                         R_PO_LINE.ITEM_CODE,
                         R_PO_LINE.ITEM_NAME,
                         R_PO_LINE.UOM_CODE,
                         R_PO_LINE.ITEM_BAR_CODE
                    FROM T_BD_ITEM I
                   WHERE I.ENTITY_ID = R_PARAM_LINE.ENTITY_ID
                     AND I.ITEM_CODE = R_PARAM_LINE.SUB_ITEM_CODE
                     AND I.ACTIVE_FLAG = V_YES;
                EXCEPTION
                  WHEN NO_DATA_FOUND THEN
                    OUT_RESULT := '产品不存在或已失效，请检查产品属性设置！';
                END;
              
                IF OUT_RESULT = V_SUCCESS THEN
                  --获取产品价格
                  BEGIN
                    SELECT NVL(L.ITEM_SETTLE_PRICE, L.ITEM_PRICE)
                      INTO R_PO_LINE.ITEM_PRICE
                      FROM T_SO_LINE L
                     WHERE L.SO_LINE_ID = R_PARAM_LINE.SOURCE_LINE_ID;
                  
                  EXCEPTION
                    WHEN NO_DATA_FOUND THEN
                      R_PO_LINE.ITEM_PRICE := 0;
                  END;
                END IF;
              
                IF OUT_RESULT = V_SUCCESS THEN
                  SELECT S_INV_PO_LINES.NEXTVAL
                    INTO R_PO_LINE.PO_LINE_ID
                    FROM DUAL;
                  R_PO_LINE.PO_LINE_NUM      := R_PO_LINE.PO_LINE_NUM + 1;
                  
                  R_PO_LINE.CREATED_BY       := IN_USER_CODE;
                  R_PO_LINE.CREATION_DATE    := SYSDATE;
                  R_PO_LINE.LAST_UPDATED_BY  := IN_USER_CODE;
                  R_PO_LINE.LAST_UPDATE_DATE := SYSDATE;
                END IF;
              
                --插入采购单行
                V_IN_PARAM := NULL;
                BEGIN
                  INSERT INTO T_INV_PO_LINES
                    (PO_LINE_ID,
                     PO_ID,
                     PO_LINE_NUM,
                     ITEM_ID,
                     ITEM_CODE,
                     ITEM_NAME,
                     ITEM_BAR_CODE,
                     UOM_CODE,
                     ITEM_PRICE,
                     BILLED_QTY,
                     CREATED_BY,
                     CREATION_DATE,
                     LAST_UPDATED_BY,
                     LAST_UPDATE_DATE)
                  VALUES
                    (R_PO_LINE.PO_LINE_ID,
                     R_PO_HEAD.PO_ID,
                     R_PO_LINE.PO_LINE_NUM,
                     R_PO_LINE.ITEM_ID,
                     R_PO_LINE.ITEM_CODE,
                     R_PO_LINE.ITEM_NAME,
                     R_PO_LINE.ITEM_BAR_CODE,
                     R_PO_LINE.UOM_CODE,
                     R_PO_LINE.ITEM_PRICE,
                     R_PO_LINE.BILLED_QTY,
                     R_PO_LINE.CREATED_BY,
                     R_PO_LINE.CREATION_DATE,
                     R_PO_LINE.LAST_UPDATED_BY,
                     R_PO_LINE.LAST_UPDATE_DATE);
                EXCEPTION
                  WHEN OTHERS THEN
                    OUT_RESULT := '新增采购单行失败！' || V_NL || '系统提示：' || SQLERRM;
                END;
              END IF;
            END IF;
          
            --插入采购套件行
            IF OUT_RESULT = V_SUCCESS THEN
              --IF V_ASS_ITEM_CODE <> R_PARAM_LINE.ASS_ITEM_CODE OR V_FLAG = V_NO THEN
              IF V_ASS_ITEM_CODE <> R_PARAM_LINE.ASS_ITEM_CODE THEN
                  --V_ASS_FLAG      := V_NO;
                V_ASS_ITEM_CODE := R_PARAM_LINE.ASS_ITEM_CODE;
                
                --检查套件产品是否有效
                V_IN_PARAM := '产品编码=' || R_PARAM_LINE.ASS_ITEM_CODE ||
                              ',名称=' || R_PARAM_LINE.ASS_ITEM_NAME;
                BEGIN
                  SELECT I.ITEM_ID, I.ITEM_CODE, I.ITEM_NAME, I.DEFAULTUNIT
                    INTO R_PO_ASS_LINE.ITEM_ID,
                         R_PO_ASS_LINE.ITEM_CODE,
                         R_PO_ASS_LINE.ITEM_NAME,
                         R_PO_ASS_LINE.ITEM_UOM_CODE
                    FROM T_BD_ITEM I
                   WHERE I.ENTITY_ID = R_PARAM_LINE.ENTITY_ID
                     AND I.ITEM_CODE = R_PARAM_LINE.ASS_ITEM_CODE
                     AND I.ACTIVE_FLAG = V_YES;
                EXCEPTION
                  WHEN NO_DATA_FOUND THEN
                    OUT_RESULT := '套件产品不存在或已失效，请检查产品属性设置！';
                END;
              
                IF OUT_RESULT = V_SUCCESS THEN
                  R_PO_ASS_LINE.ENTITY_ID    := R_PARAM_LINE.ENTITY_ID;
                  R_PO_ASS_LINE.PO_HEADER_ID := R_PO_HEAD.PO_ID;
                  --R_PO_ASS_LINE.LIST_PRICE := ROUND(R_PO_LINE.ITEM_PRICE / 1.17, 4); --不含税价格
                  BEGIN
                    SELECT NVL(L.ITEM_SETTLE_PRICE, L.ITEM_PRICE), --20180409 hejy3 使用系统配置税率
                           L.TAX_RATE
                      INTO V_PO_ASS_LINE_PRICE, V_TAX_RATE
                      FROM T_SO_LINE L
                     WHERE L.SO_LINE_ID = R_PARAM_LINE.SOURCE_LINE_ID;
                  EXCEPTION
                    WHEN NO_DATA_FOUND THEN
                      R_PO_ASS_LINE.LIST_PRICE := 0;
                  END;
                  
                  IF V_TAX_RATE IS NULL THEN
                    OUT_RESULT := '销售单产品行税率为空，请联系运维人员处理。产品编码=' || R_PO_ASS_LINE.ITEM_CODE;
                    RAISE V_BASE_EXCEPTION;
                  ELSE
                    R_PO_ASS_LINE.LIST_PRICE := ROUND(V_PO_ASS_LINE_PRICE / (1 + V_TAX_RATE / 100), 4);
                  END IF;
                
                  R_PO_ASS_LINE.SOURCE_LINE_ID   := R_PARAM_LINE.SOURCE_LINE_ID;
                  R_PO_ASS_LINE.CREATED_BY       := IN_USER_CODE;
                  R_PO_ASS_LINE.CREATION_DATE    := SYSDATE;
                  R_PO_ASS_LINE.LAST_UPDATED_BY  := IN_USER_CODE;
                  R_PO_ASS_LINE.LAST_UPDATE_DATE := SYSDATE;
                  SELECT S_INV_PO_ASSEMBLE_LINES.NEXTVAL
                    INTO R_PO_ASS_LINE.ASSEMBLE_LINE_ID
                    FROM DUAL;
                END IF;
              
                V_IN_PARAM := NULL;
                --判断套件是不是写入过，写入过就无需在写。还要判断套件数量大于0
                --IF V_ASS_FLAG = V_NO THEN
                  R_PO_ASS_LINE.ITEM_QTY := (R_PARAM_LINE.ITEM_QTY -
                                            NVL(R_PARAM_LINE.CANCEL_QTY, 0))/nvl(R_PARAM_LINE.SUB_ITEM_QTY_SCALE,1);
                --END IF;
                
                If R_PO_ASS_LINE.ITEM_QTY > 0 THEN
                  BEGIN
                    INSERT INTO T_INV_PO_ASSEMBLE_LINES
                      (ENTITY_ID,
                       ASSEMBLE_LINE_ID,
                       PO_HEADER_ID,
                       ITEM_ID,
                       ITEM_CODE,
                       ITEM_NAME,
                       ITEM_UOM_CODE,
                       ITEM_QTY,
                       LIST_PRICE,
                       SOURCE_LINE_ID,
                       CREATED_BY,
                       CREATION_DATE,
                       LAST_UPDATED_BY,
                       LAST_UPDATE_DATE)
                    VALUES
                      (R_PO_ASS_LINE.ENTITY_ID,
                       R_PO_ASS_LINE.ASSEMBLE_LINE_ID,
                       R_PO_ASS_LINE.PO_HEADER_ID,
                       R_PO_ASS_LINE.ITEM_ID,
                       R_PO_ASS_LINE.ITEM_CODE,
                       R_PO_ASS_LINE.ITEM_NAME,
                       R_PO_ASS_LINE.ITEM_UOM_CODE,
                       R_PO_ASS_LINE.ITEM_QTY,
                       R_PO_ASS_LINE.LIST_PRICE,
                       R_PO_ASS_LINE.SOURCE_LINE_ID,
                       R_PO_ASS_LINE.CREATED_BY,
                       R_PO_ASS_LINE.CREATION_DATE,
                       R_PO_ASS_LINE.LAST_UPDATED_BY,
                       R_PO_ASS_LINE.LAST_UPDATE_DATE);
                    V_ASS_FLAG := V_YES;
                  EXCEPTION
                    WHEN OTHERS THEN
                      OUT_RESULT := '插入采购单套件行表失败！' || V_NL || '系统提示：' ||
                                    SQLERRM;
                  END;
                
                  /*--更新发货通知单直发转采购数量
                  UPDATE T_LG_SHIP_DOC_LINE L
                     SET L.TRANSFER_TO_POX_QTY = NVL(L.TRANSFER_TO_POX_QTY,
                                                     0) +
                                                 R_PARAM_LINE.ITEM_QTY -
                                                 NVL(R_PARAM_LINE.CANCEL_QTY,
                                                     0),
                         L.LAST_UPDATED_BY     = IN_USER_CODE,
                         L.LAST_UPDATE_DATE    = SYSDATE
                   WHERE L.SHIP_DOC_LINE_ID =
                         (SELECT SL.SHIP_DOC_LINE_ID
                            FROM T_SO_LINE SL
                           WHERE SL.SO_LINE_ID = R_PARAM_LINE.SOURCE_LINE_ID);*/
                END IF;
              END IF;
            END IF;
          
            IF OUT_RESULT = V_SUCCESS THEN
              UPDATE T_SO_TO_SUPP_PARAM_LINE L
                 SET L.PO_HEAD_ID = R_PO_HEAD.PO_ID,
                     L.PO_NUM     = R_PO_HEAD.PO_NUM
               WHERE L.PARAM_LINE_ID = R_PARAM_LINE.PARAM_LINE_ID;
            END IF;
          
            IF OUT_RESULT <> V_SUCCESS THEN
              EXIT;
            END IF;
          END LOOP;
        END IF;
      
      --插入采购单NC接口 改在执行后调用
      /*IF OUT_RESULT = v_Success THEN
                                  V_IN_PARAM := '采购单ID='||TO_CHAR(R_PO_HEAD.PO_ID)||',采购单号='||R_PO_HEAD.PO_NUM;
                                  PKG_INV_NC.P_INSERT_INTF_PO_ORDER(SOURCE_HEADER_ID => R_PO_HEAD.PO_ID,
                                                                    P_RESULT         => OUT_ERR_NUM,
                                                                    P_ERR_MSG        => OUT_RESULT);
                                END IF;*/
      END LOOP;
    END IF;
  
    --差异处理
    IF OUT_RESULT = V_SUCCESS AND R_SO_HEAD.TRANSFER_ACCOUNT_ID IS NOT NULL AND
       R_PARAM_HEAD.CUSTOMER_LG_ORDER IS NULL THEN
      V_ASS_ITEM_CODE := '_';
      FOR R_PARAM_LINE1 IN (SELECT *
                              FROM T_SO_TO_SUPP_PARAM_LINE L
                             WHERE L.PARAM_ID = IN_PARAM_ID
                             ORDER BY L.ASS_ITEM_CODE,
                                      CEIL((NVL(L.FACT_REV_SHATTER_QTY, 0) +
                                      NVL(L.MISSING_QTY, 0) +
                                      NVL(L.REJECTED_QTY, 0))/NVL(L.SUB_ITEM_QTY_SCALE,1)) DESC) LOOP
        IF V_ASS_ITEM_CODE <> R_PARAM_LINE1.ASS_ITEM_CODE THEN
          --每个套件编码只插入行
          V_ASS_ITEM_CODE := R_PARAM_LINE1.ASS_ITEM_CODE;
          IF CEIL((NVL(R_PARAM_LINE1.FACT_REV_SHATTER_QTY, 0) +
             NVL(R_PARAM_LINE1.MISSING_QTY, 0) +
             NVL(R_PARAM_LINE1.REJECTED_QTY, 0))/NVL(R_PARAM_LINE1.SUB_ITEM_QTY_SCALE,1)) > 0 AND
             R_PARAM_HEAD.DIRECT_SEND_FLAG = 'Y' THEN
             V_CANCEL_QTY := CEIL((NVL(R_PARAM_LINE1.FACT_REV_SHATTER_QTY, 0) +
                                   NVL(R_PARAM_LINE1.MISSING_QTY, 0) +
                                   NVL(R_PARAM_LINE1.REJECTED_QTY, 0))/NVL(R_PARAM_LINE1.SUB_ITEM_QTY_SCALE,1));
          ELSIF R_PARAM_HEAD.DIRECT_SEND_FLAG = 'N' THEN
            V_CANCEL_QTY := CEIL(R_PARAM_LINE1.ITEM_QTY/NVL(R_PARAM_LINE1.SUB_ITEM_QTY_SCALE,1));
          END IF;
          --取消数量>0才处理
          IF V_CANCEL_QTY > 0 THEN
            BEGIN
              --获取销售单行
              SELECT *
                INTO R_SO_LINE
                FROM T_SO_LINE L
               WHERE L.SO_HEADER_ID = R_SO_HEAD.SO_HEADER_ID
                 AND L.ITEM_CODE = R_PARAM_LINE1.ASS_ITEM_CODE;
              --获取直发客户的相关信息
              SELECT *
                INTO R_CUSTOMER_ACCOUNT_SALECENTER
                FROM V_CUSTOMER_ACCOUNT_SALECENTER T
               WHERE T.ACCOUNT_ID = R_SO_HEAD.TRANSFER_ACCOUNT_ID
                 AND T.ENTITY_ID = R_SO_HEAD.TRANSFER_ENTITY_ID;
              --按取消数量解锁
              SELECT R_SO_LINE.TRANSFER_LIST_PRICE *
                     (100 - NVL(R_PARAM_LINE1.CUST_SO_DISCOUNT_RATE, 0) -
                     NVL(R_PARAM_LINE1.CUST_SO_MONTH_DIS_RATE, 0)) *
                     V_CANCEL_QTY / 100,
                     R_SO_LINE.TRANSFER_LIST_PRICE * NVL(R_PARAM_LINE1.CUST_SO_DISCOUNT_RATE, 0) *
                     V_CANCEL_QTY / 100
                INTO V_CANCEL_AMOUNT, V_CANCEL_DIS_AMOUNT
                FROM DUAL;
              
              pkg_pln_pub.P_CUSTOMER_AMOUNT_PROCESS(IN_ENTITY_ID       => R_PARAM_LINE1.ENTITY_ID,
                                                    IN_ORDER_TYPE_ID   => -1,
                                                    IN_ORDER_TYPE_CODE => R_SO_HEAD.RAW_SRC_BILL_TYPE_CODE,
                                                    IN_CUSTOMER_ID     => R_CUSTOMER_ACCOUNT_SALECENTER.CUSTOMER_ID,
                                                    IN_ACCOUNT_ID      => R_CUSTOMER_ACCOUNT_SALECENTER.ACCOUNT_ID,
                                                    IN_SALES_MAIN_TYPE => R_PARAM_LINE1.ASS_ITEM_MAIN_TYPE,
                                                    IN_ACTION_TYPE     => 2,
                                                    IN_SOURCE_TYPE     => '01',
                                                    IN_ORDER_ID        => R_SO_HEAD.RAW_SRC_BILL_ID,
                                                    IN_PROJ_NUMBER     => null,
                                                    IN_DISCOUNT_TYPE   => NVL(R_PARAM_LINE1.DISCOUNT_TYPE, DISCOUNT_TYPE_COMMON),
                                                    IN_AMOUNT          => ROUND(V_CANCEL_AMOUNT, 2),
                                                    IN_DIS_AMOUNT      => ROUND(V_CANCEL_DIS_AMOUNT, 2),
                                                    IN_RECORD_ERR      => 'N',
                                                    IN_USER_CODE       => IN_USER_CODE,
                                                    OUT_RESULT         => OUT_RESULT);
              if OUT_RESULT <> V_SUCCESS then
                OUT_RESULT := '销售转采购（差异数量取消订单）处理客户款项失败！' || V_NL ||
                               OUT_RESULT;
              end if;
              /*V_IN_PARAM := '营销大类=' || R_PARAM_LINE1.ASS_ITEM_MAIN_TYPE || V_NL ||
                            '客户ID=' ||
                            TO_CHAR(R_CUSTOMER_ACCOUNT_SALECENTER.CUSTOMER_ID) ||
                            ',客户编码=' ||
                            R_CUSTOMER_ACCOUNT_SALECENTER.CUSTOMER_CODE || V_NL ||
                            '账户ID=' ||
                            TO_CHAR(R_CUSTOMER_ACCOUNT_SALECENTER.ACCOUNT_ID) ||
                            ',账户编码=' ||
                            R_CUSTOMER_ACCOUNT_SALECENTER.ACCOUNT_CODE;
              PKG_CREDIT_ACCOUNT_CONTROL.PRC_CREDIT_ORDER_BILL(R_PARAM_LINE1.ENTITY_ID, --主体ID
                                                               2, --动作(取消信用占用）
                                                               ROUND(V_CANCEL_AMOUNT,
                                                                     2), --结算金额
                                                               ROUND(V_CANCEL_DIS_AMOUNT,
                                                                     2), --折让金额
                                                               --20170517 hejy3 按行营销大类
                                                               --v_Sales_Main_Type,
                                                               R_PARAM_LINE1.ASS_ITEM_MAIN_TYPE,
                                                               R_CUSTOMER_ACCOUNT_SALECENTER.ACCOUNT_ID, --账户ID
                                                               R_CUSTOMER_ACCOUNT_SALECENTER.CUSTOMER_ID, --客户ID
                                                               NULL, --项目编码
                                                               R_SO_HEAD.RAW_SRC_BILL_ID, --单据头ID
                                                               --r_Lgorder_Head.Order_Type_Name, --单据类型名
                                                               R_SO_HEAD.RAW_SRC_BILL_TYPE_CODE, --20160912 hejy3 传入订单类型编码
                                                               IN_USER_CODE,
                                                               OUT_ERR_NUM,
                                                               OUT_RESULT,
                                                               NVL(R_PARAM_LINE1.DISCOUNT_TYPE,
                                                                   'COMMON') --add lizhen 2017-08-08
                                                               );
              IF OUT_RESULT = V_SUCCESS THEN
                IF NVL(R_PARAM_LINE1.DISCOUNT_TYPE, 'COMMON') !=
                   'COMMON' THEN
                  V_IN_PARAM := '营销大类=' || R_PARAM_LINE1.ASS_ITEM_MAIN_TYPE || V_NL ||
                                '客户ID=' ||
                                TO_CHAR(R_CUSTOMER_ACCOUNT_SALECENTER.CUSTOMER_ID) ||
                                ',客户编码=' ||
                                R_CUSTOMER_ACCOUNT_SALECENTER.CUSTOMER_CODE || V_NL ||
                                '账户ID=' || TO_CHAR(R_CUSTOMER_ACCOUNT_SALECENTER.ACCOUNT_ID) ||
                                ',账户编码=' ||
                                R_CUSTOMER_ACCOUNT_SALECENTER.ACCOUNT_CODE || V_NL ||
                                '折扣类型=' ||
                                R_PARAM_LINE1.DISCOUNT_TYPE;
                  PKG_CREDIT_DIS.P_CHECK_DIS_AMOUNT(IN_ACTION_TYPE     => 2, --操作类型 与信用控制动作标识一致
                                                    IN_ENTITY_ID       => R_PARAM_LINE1.ENTITY_ID, --主体ID
                                                    IN_ACCOUNT_ID      => R_CUSTOMER_ACCOUNT_SALECENTER.ACCOUNT_ID, --客户账户ID
                                                    IS_SOURCE_TYPE     => '01', --来源类型 取码表SO_SRC_TYPE
                                                    IN_SOURCE_BILL_ID  => R_SO_HEAD.RAW_SRC_BILL_ID, --来源单据ID 取相应的单据头ID
                                                    IS_SALES_MAIN_TYPE => R_PARAM_LINE1.ASS_ITEM_MAIN_TYPE, --营销大类
                                                    IS_DISCOUNT_TYPE   => NVL(R_PARAM_LINE1.DISCOUNT_TYPE,
                                                                              'COMMON'), --折扣类型 取行上的折扣类型
                                                    IN_AMOUNT          => ROUND(V_CANCEL_AMOUNT,
                                                                                2), --金额
                                                    IS_USER_NAME       => IN_USER_CODE, --用户编码
                                                    IS_ATTRIB01        => NULL, --预留输入参数01
                                                    IS_ATTRIB02        => NULL, --预留输入参数02
                                                    ON_RESULT          => OUT_ERR_NUM, --成功则返回0，否则返回对应的出错代码
                                                    OS_MESSAGE         => OUT_RESULT, --成功返回“SUCCESS”；失败返回出错信息
                                                    OS_ATTRIB01        => V_OS_ATTRIB01, --预留输出参数01
                                                    OS_ATTRIB02        => V_OS_ATTRIB02 --预留输出参数02
                                                    );
                  IF OUT_RESULT <> V_SUCCESS THEN
                    OUT_RESULT := '差异数量取消订单，检查并解锁折扣类型金额失败，请检查折扣类型余额是否足够！' || V_NL ||
                                  OUT_RESULT;
                  END IF;
                END IF;
              ELSE
                OUT_RESULT := '差异数量取消订单，检查并锁定客户款项失败，请检查客户余款是否足够！' || V_NL ||
                              OUT_RESULT;
              END IF;*/
            
              --批文锁定处理
              IF OUT_RESULT = V_SUCCESS AND
                 R_SO_LINE.TRANSFER_PRICE_LINE_ID IS NOT NULL THEN
                V_IN_PARAM := '单据号=' || R_SO_HEAD.RAW_SRC_BILL_NUM || V_NL ||
                              '产品编码=' || R_PARAM_LINE1.ASS_ITEM_CODE || V_NL ||
                              '批文行ID=' ||
                              TO_CHAR(R_SO_LINE.TRANSFER_PRICE_LINE_ID);
                PKG_BD_PRICE.P_APPLY_UNLOCK(P_APPLY_DETAIL_ID => R_SO_LINE.TRANSFER_PRICE_LINE_ID, --批文明细ID
                                            P_UNLOCK_CNT      => V_CANCEL_QTY, --解除锁定数量
                                            P_BILL_NO         => R_SO_HEAD.RAW_SRC_BILL_NUM, --关联单号
                                            P_RETURN_CODE     => V_RESULT, --返回编码，1成功，0失败
                                            P_RETURN_MSG      => OUT_RESULT);
                IF V_RESULT = '1' THEN
                  OUT_RESULT := V_SUCCESS;
                END IF;
              END IF;
            
            END;
          END IF;
          
        END IF;
      
      END LOOP;
    END IF;
  
    IF OUT_RESULT <> V_SUCCESS THEN
      OUT_PO_NUMBER := NULL; --出错把单号串置成空
      RAISE V_BASE_EXCEPTION;
    ELSE
      IF OUT_PO_NUMBER IS NOT NULL THEN
        UPDATE T_SO_TO_SUPP_PARAM_HEAD H
           SET --H.TO_SUPP_MSG = H.TO_SUPP_MSG || '；采购单号：' || OUT_PO_NUMBER
               H.TO_SUPP_MSG = '采购单号：' || OUT_PO_NUMBER
         WHERE H.PARAM_ID = R_PARAM_HEAD.PARAM_ID;
      
        UPDATE T_SO_HEADER H
           SET H.TO_SUPP_FLAG = 'Y',
               --H.TO_SUPP_MSG  = H.TO_SUPP_MSG || '；采购单号：' || OUT_PO_NUMBER
               H.TO_SUPP_MSG  = '采购单号：' || OUT_PO_NUMBER,
               H.LAST_UPDATED_BY = IN_USER_CODE,
               H.LAST_UPDATE_DATE = SYSDATE
         WHERE H.SO_HEADER_ID = R_PARAM_HEAD.SOURCE_ORDER_ID;
      ELSE
        UPDATE T_SO_HEADER H
           SET H.TO_SUPP_FLAG = 'Y',
               H.LAST_UPDATED_BY = IN_USER_CODE,
               H.LAST_UPDATE_DATE = SYSDATE
         WHERE H.SO_HEADER_ID = R_PARAM_HEAD.SOURCE_ORDER_ID;
      END IF;
    END IF;
  EXCEPTION
    WHEN V_BASE_EXCEPTION THEN
      ROLLBACK TO SAVEPOINT SP_SO_TO_POX_USEPARAM;
      OUT_RESULT := '生成采购单出错，错误提示：' || OUT_RESULT || V_NL || V_IN_PARAM;
    WHEN OTHERS THEN
      ROLLBACK TO SAVEPOINT SP_SO_TO_POX_USEPARAM;
      OUT_RESULT := '生成采购单出错，错误提示：' || SQLERRM || V_NL || V_IN_PARAM;
  END P_SO_TO_POX_USEPARAM;

  ---------------------------------------------------------
  --生成代理商客户的销售单
  --销售单为自提，或直发且非安得接收
  ---------------------------------------------------------
  PROCEDURE P_TO_CUST_SO_USEPARAM(IN_ENTITY_ID  IN NUMBER, --主体ID
                                  IN_PARAM_ID   IN NUMBER, --转采购参数表ID
                                  IN_USER_CODE  IN VARCHAR2, --操作用户
                                  OUT_SO_NUMBER OUT VARCHAR2, --销售单号
                                  OUT_RESULT    IN OUT VARCHAR2) IS
    R_PARAM_HEAD                T_SO_TO_SUPP_PARAM_HEAD%ROWTYPE;
    R_PLN_LG_ORDER              T_PLN_LG_ORDER_HEAD%ROWTYPE;
    R_PLN_LG_LINE               T_PLN_LG_ORDER_LINE%ROWTYPE;
    R_SO_HEAD                   T_SO_HEADER%ROWTYPE; --总部销售单
    R_CUST_SO_HEAD_INTF         T_SO_HEADER_INTERFACE%ROWTYPE; --客户销售单接口
    R_CUST_SO_LINE_INTF         T_SO_LINE_INTERFACE%ROWTYPE; --客户销售单接口行
    V_IN_PARAM                  VARCHAR2(4000);
    V_DISTRICT_CODE             T_BD_DISTRICT.DISTRICT_CODE%TYPE; --区域编码
    V_COUNT                     NUMBER;
    V_ASS_ITEM_CODE             T_SO_TO_SUPP_PARAM_LINE.ASS_ITEM_CODE%TYPE;
    OUT_ERR_NUM                 NUMBER;
    V_RESULT                    VARCHAR2(10);
    V_TRANSFER_PRICE_LINE_ID    T_SO_LINE.TRANSFER_PRICE_LINE_ID%TYPE;
    V_SUM_AMOUNT                NUMBER; --销售金额
    V_SUM_DIS_AMOUNT            NUMBER; --销售折让金额
    V_OS_ATTRIB01               VARCHAR2(1000);
    V_OS_ATTRIB02               VARCHAR2(1000);
    V_INV_ITEM_USABLE_QTY       NUMBER;
    V_USABLE_ITEM_QOH_QTY       NUMBER; --产品可用量
    V_LG_ORDER_NEXT_STATE       NUMBER; --提货订单下一状态
    V_SUM_LG_ORDER_QTY          NUMBER;
    V_SUM_LG_ORDER_AFFIRMED_QTY NUMBER;
    V_SUM_LG_ORDER_CANCEL_QTY   NUMBER;
  
    V_CANCEL_AMOUNT            NUMBER;
    V_CANCEL_DIS_AMOUNT        NUMBER;
    V_DIFF_QTY                 NUMBER;
    V_PRICE_APPLY_USE_DISCOUNT T_BD_PARAM_LIST.DEFAULT_VALUE%TYPE := 'N'; --20170710 hejy3 价格批文开单使用折扣
    
    TYPE TR_SPLIT_ORDER IS RECORD
    (SALES_MAIN_TYPE VARCHAR2(32),
     DISCOUNT_TYPE VARCHAR2(50),
     SUM_AMOUNT NUMBER,
     SUM_DIS_AMOUNT NUMBER);
    TYPE TT_SPLIT_ORDER IS TABLE OF TR_SPLIT_ORDER INDEX BY VARCHAR2(100);
    TV_SPLIT_ORDER TT_SPLIT_ORDER;
    V_TABLE_INDEX VARCHAR2(100);
    TYPE TP_SO_INTF_ID IS TABLE OF Number Index By Binary_Integer;
    TV_SO_INTF_ID TP_SO_INTF_ID;
    V_SALES_MAIN_TYPE VARCHAR2(100);
    V_DISCOUNT_TYPE VARCHAR2(100);
    v_Hq_Affirm_Lock_Full_Amount t_bd_param_list.default_value%type := 'N';
    V_ACTION_TYPE NUMBER;
  BEGIN
    OUT_RESULT := V_SUCCESS;
    SAVEPOINT SP_TO_CUST_SO_USEPARAM;
  
    --锁定转采购参数表数据
    V_IN_PARAM := '转采购参数表ID=' || TO_CHAR(IN_PARAM_ID);
    BEGIN
      SELECT *
        INTO R_PARAM_HEAD
        FROM T_SO_TO_SUPP_PARAM_HEAD H
       WHERE H.PARAM_ID = IN_PARAM_ID;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        OUT_RESULT := '传入参数有误，找不到转采购的数据！';
    END;
  
    --获取来源销售单
    IF OUT_RESULT = V_SUCCESS THEN
      V_IN_PARAM := '销售单ID=' || TO_CHAR(R_PARAM_HEAD.SOURCE_ORDER_ID) ||
                    ',销售单号=' || R_PARAM_HEAD.SOURCE_ORDER_NUMBER;
      BEGIN
        SELECT H.*
          INTO R_SO_HEAD
          FROM T_SO_HEADER H
         WHERE H.SO_HEADER_ID = R_PARAM_HEAD.SOURCE_ORDER_ID;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          OUT_RESULT := '找不到转采购的销售单！';
      END;
    END IF;
  
    --自提，直发且非安得接收才处理
    IF OUT_RESULT = V_SUCCESS THEN
      IF (R_SO_HEAD.DIRECT_SHIP_FLAG = V_YES AND
         NVL(R_SO_HEAD.ANNTO_RECEIVE_FLAG, V_NO) <> V_YES) OR
         R_SO_HEAD.SELF_PICK_FLAG = V_YES THEN
        IF R_PARAM_HEAD.CUSTOMER_LG_ORDER IS NOT NULL THEN
          V_IN_PARAM := '客户提货订单号=' || R_PARAM_HEAD.CUSTOMER_LG_ORDER;
          BEGIN
            SELECT H.*
              INTO R_PLN_LG_ORDER
              FROM T_PLN_LG_ORDER_HEAD H
             WHERE H.ENTITY_ID = R_PARAM_HEAD.ENTITY_ID
               AND H.ORDER_NUMBER = R_PARAM_HEAD.CUSTOMER_LG_ORDER;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              OUT_RESULT := '无效客户提货订单，请检查';
          END;
        ELSE
          R_PLN_LG_ORDER := NULL;
        END IF;
      
        --20170710 hejy3 获取价格批文开单使用折扣参数
        BEGIN
          V_PRICE_APPLY_USE_DISCOUNT := PKG_BD.F_GET_PARAMETER_VALUE('PLN_PRICE_APPLY_USE_DISCOUNT',
                                                                     R_PARAM_HEAD.ENTITY_ID);
        EXCEPTION
          WHEN OTHERS THEN
            V_PRICE_APPLY_USE_DISCOUNT := 'N';
        END;
        
        --获取参数:销司订单总部评审锁全款
        Begin
          v_Hq_Affirm_Lock_Full_Amount := Pkg_Bd.f_Get_Parameter_Value('PLN_HQ_AFFIRM_LOCK_FULL_AMOUNT',
                                                             R_PARAM_HEAD.Entity_Id);
        Exception
          When Others Then
            OUT_RESULT := '获取销司订单总部评审锁全款参数PLN_HQ_AFFIRM_LOCK_FULL_AMOUNT参数失败！' || v_Nl ||
                          Sqlerrm;
            Raise v_Base_Exception;
        End;
      
        --检查发货仓库是否可销售
        IF OUT_RESULT = V_SUCCESS THEN
          V_IN_PARAM := '仓库ID=' || TO_CHAR(R_PARAM_HEAD.FINANCE_INV_ID) ||
                        ',编码=' || R_PARAM_HEAD.FINANCE_INV_CODE || ',名称=' ||
                        R_PARAM_HEAD.FINANCE_INV_NAME;
          BEGIN
            SELECT I.INVENTORY_ID
              INTO R_CUST_SO_HEAD_INTF.SHIP_INV_ID
              FROM T_INV_INVENTORIES I
             WHERE I.INVENTORY_ID = R_PARAM_HEAD.FINANCE_INV_ID
               AND I.SALES_FLAG = V_YES --可销售
               AND I.INVENTORY_CATEGORY = V_INVENTORY_CATEGORY_01 --关联仓
               AND SYSDATE BETWEEN I.BEGIN_DATE AND
                   NVL(I.END_DATE, SYSDATE + 1);
          EXCEPTION
            WHEN OTHERS THEN
              OUT_RESULT := '销售发货仓库不存在或已失效，请检查仓库设置！' || V_NL ||
                            '仓库需满足条件：销售标志=Y，仓库类别=关联仓';
          END;
        END IF;
      
        --检查客户
        IF OUT_RESULT = V_SUCCESS THEN
          V_IN_PARAM := '客户ID=' ||
                        TO_CHAR(R_PARAM_HEAD.TRANSFER_CUSTOMER_ID) ||
                        ',编码=' || R_PARAM_HEAD.TRANSFER_CUSTOMER_CODE ||
                        ',名称=' || R_PARAM_HEAD.TRANSFER_CUSTOMER_NAME;
          BEGIN
            SELECT H.CUSTOMER_ID, H.CUSTOMER_CODE, H.CUSTOMER_NAME
              INTO R_CUST_SO_HEAD_INTF.CUSTOMER_ID,
                   R_CUST_SO_HEAD_INTF.CUSTOMER_CODE,
                   R_CUST_SO_HEAD_INTF.CUSTOMER_NAME
              FROM T_CUSTOMER_HEADER H
             WHERE H.CUSTOMER_ID = R_PARAM_HEAD.TRANSFER_CUSTOMER_ID
               AND H.ACTIVE_FLAG = V_ACTIVE;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              OUT_RESULT := '客户不存在或已失效，请检查客户设置！';
          END;
        END IF;
      
        --检查客户账户关系
        IF OUT_RESULT = V_SUCCESS THEN
          V_IN_PARAM := '账户ID=' ||
                        TO_CHAR(R_PARAM_HEAD.TRANSFER_ACCOUNT_ID) || ',编码=' ||
                        R_PARAM_HEAD.TRANSFER_ACCOUNT_CODE || V_NL ||
                        '中心ID=' || TO_CHAR(R_PARAM_HEAD.SALES_CENTER_ID) ||
                        ',编码=' || R_PARAM_HEAD.SALES_CENTER_CODE || ',名称=' ||
                        R_PARAM_HEAD.SALES_CENTER_NAME || V_NL || '客户ID=' ||
                        TO_CHAR(R_PARAM_HEAD.TRANSFER_CUSTOMER_ID) ||
                        ',编码=' || R_PARAM_HEAD.TRANSFER_CUSTOMER_CODE ||
                        ',名称=' || R_PARAM_HEAD.TRANSFER_CUSTOMER_NAME;
          BEGIN
            SELECT S.ACCOUNT_ID,
                   S.ACCOUNT_CODE,
                   S.ACCOUNT_NAME,
                   S.SALES_CENTER_ID,
                   S.SALES_CENTER_CODE,
                   S.SALES_CENTER_NAME
              INTO R_CUST_SO_HEAD_INTF.ACCOUNT_ID,
                   R_CUST_SO_HEAD_INTF.ACCOUNT_CODE,
                   R_CUST_SO_HEAD_INTF.ACCOUNT_NAME,
                   R_CUST_SO_HEAD_INTF.SALES_CENTER_ID,
                   R_CUST_SO_HEAD_INTF.SALES_CENTER_CODE,
                   R_CUST_SO_HEAD_INTF.SALES_CENTER_NAME
              FROM V_CUSTOMER_ACCOUNT_SALECENTER S
             WHERE S.ACCOUNT_ID = R_PARAM_HEAD.TRANSFER_ACCOUNT_ID
               AND S.SALES_CENTER_ID = R_PARAM_HEAD.SALES_CENTER_ID
               AND S.CUSTOMER_ID = R_PARAM_HEAD.TRANSFER_CUSTOMER_ID
               AND S.ENTITY_ID = R_PARAM_HEAD.ENTITY_ID
               AND S.ACTIVE_FLAG = V_ACTIVE
               AND S.ACCOUNT_STATUS = V_ACCOUNT_ACTIVE;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              OUT_RESULT := '中心客户账户关系不存在或已失效，请检查账户设置！';
          END;
        END IF;
      
        --获取省市区县编码
        IF OUT_RESULT = V_SUCCESS THEN
          R_CUST_SO_HEAD_INTF.CONSIGNEE_ADDRESS_ID := R_SO_HEAD.CONSIGNEE_ADDRESS_ID;
          R_CUST_SO_HEAD_INTF.CONSIGNEE_ADDRESS  := R_PARAM_HEAD.CONSIGNEE_ADDR;
          R_CUST_SO_HEAD_INTF.CONSIGNEE_CONTRACT := R_PARAM_HEAD.CONSIGNEE_CONTRACT;
          R_CUST_SO_HEAD_INTF.CONSIGNEE_TEL      := R_PARAM_HEAD.CONSIGNEE_CONTRACT_TEL;
          --获取区域编码
          V_IN_PARAM := '区域ID=' || TO_CHAR(R_PARAM_HEAD.CONSIGNEE_ADD_ID);
          BEGIN
            SELECT D.DISTRICT_CODE
              INTO V_DISTRICT_CODE
              FROM T_BD_DISTRICT D
             WHERE D.ROW_ID = R_PARAM_HEAD.CONSIGNEE_ADD_ID;
          EXCEPTION
            WHEN OTHERS THEN
              OUT_RESULT := '收货区域不存在，请检查区域设置！';
          END;
          --省
          R_CUST_SO_HEAD_INTF.CONSIGNEE_PROVINCE_CODE := PKG_SO_PUB.F_GET_DISTRICT(V_DISTRICT_CODE,
                                                                                   2);
          --市
          R_CUST_SO_HEAD_INTF.CONSIGNEE_CITY_CODE := PKG_SO_PUB.F_GET_DISTRICT(V_DISTRICT_CODE,
                                                                               3);
          --区
          R_CUST_SO_HEAD_INTF.CONSIGNEE_DISTRICT_CODE := PKG_SO_PUB.F_GET_DISTRICT(V_DISTRICT_CODE,
                                                                                   4);
          --县
          R_CUST_SO_HEAD_INTF.CONSIGNEE_TOWN_CODE := PKG_SO_PUB.F_GET_DISTRICT(V_DISTRICT_CODE,
                                                                               5);
        END IF;
      
        --检查同一个套件行是否存在不同的销售单类型、折扣类型、批文
        IF OUT_RESULT = V_SUCCESS THEN
          SELECT COUNT(1)
            INTO V_COUNT
            FROM (SELECT COUNT(ASS_ITEM_CODE)
                    FROM (SELECT DISTINCT L.ASS_ITEM_CODE,
                                          L.SO_BILL_TYPE_ID,
                                          L.DISCOUNT_TYPE,
                                          L.PRICE_APPLY_TYPE,
                                          L.PRICE_APPLY_ID
                            FROM T_SO_TO_SUPP_PARAM_LINE L
                           WHERE L.PARAM_ID = IN_PARAM_ID)
                   GROUP BY ASS_ITEM_CODE
                  HAVING COUNT(ASS_ITEM_CODE) > 1);
        
          IF V_COUNT > 0 THEN
            OUT_RESULT := '同一个套件行存在不同的销售单类型、折扣类型、批文，请重新选择！';
          END IF;
        END IF;
      
        IF OUT_RESULT = V_SUCCESS THEN
          R_CUST_SO_HEAD_INTF.ENTITY_ID              := R_PARAM_HEAD.ENTITY_ID;
          R_CUST_SO_HEAD_INTF.SO_DATE                := TRUNC(SYSDATE);
          R_CUST_SO_HEAD_INTF.SRC_TYPE               := V_SO_SRC_TYPE_31; --'12'; --来源财务单
          R_CUST_SO_HEAD_INTF.SRC_BILL_TYPE_ID       := R_SO_HEAD.BILL_TYPE_ID;
          R_CUST_SO_HEAD_INTF.SRC_BILL_TYPE_CODE     := R_SO_HEAD.BILL_TYPE_CODE;
          R_CUST_SO_HEAD_INTF.SRC_BILL_TYPE_NAME     := R_SO_HEAD.BILL_TYPE_NAME;
          R_CUST_SO_HEAD_INTF.SRC_BILL_ID            := R_SO_HEAD.SO_HEADER_ID;
          R_CUST_SO_HEAD_INTF.SRC_BILL_NUM           := R_SO_HEAD.SO_NUM;
          R_CUST_SO_HEAD_INTF.CUST_ORDER_NUM         := R_PLN_LG_ORDER.CUSTOMER_ORDER_NUMBER;
          R_CUST_SO_HEAD_INTF.CUST_ORDER_DATE        := R_PLN_LG_ORDER.CUSTOMER_ORDER_DATE;
          R_CUST_SO_HEAD_INTF.SELF_PICK_FLAG         := R_SO_HEAD.SELF_PICK_FLAG;
          R_CUST_SO_HEAD_INTF.SHIP_WAY               := R_PARAM_HEAD.SHIP_MODE;
          R_CUST_SO_HEAD_INTF.SHIP_FLAG              := R_SO_HEAD.SHIP_FLAG;
          R_CUST_SO_HEAD_INTF.SHIP_DATE              := R_SO_HEAD.SHIP_DATE;
          R_CUST_SO_HEAD_INTF.REMARK                 := SUBSTRB(R_SO_HEAD.REMARK || ';' ||
                                                                R_PARAM_HEAD.REMARK ||
                                                                '[总部销售单：' ||
                                                                R_SO_HEAD.SO_NUM || ']',
                                                                1,
                                                                500);
          R_CUST_SO_HEAD_INTF.RAW_SRC_TYPE           := V_SO_SRC_TYPE_31; --'12';
          R_CUST_SO_HEAD_INTF.RAW_SRC_BILL_TYPE_ID   := R_SO_HEAD.BILL_TYPE_ID;
          R_CUST_SO_HEAD_INTF.RAW_SRC_BILL_TYPE_CODE := R_SO_HEAD.BILL_TYPE_CODE;
          R_CUST_SO_HEAD_INTF.RAW_SRC_BILL_ID        := R_SO_HEAD.SO_HEADER_ID;
          R_CUST_SO_HEAD_INTF.RAW_SRC_BILL_NUM       := R_SO_HEAD.SO_NUM;
          R_CUST_SO_HEAD_INTF.RAW_SRC_BILL_TYPE_NAME := R_SO_HEAD.BILL_TYPE_NAME;
          --R_CUST_SO_HEAD_INTF.RECEIVE_FLAG := V_YES;
          --R_CUST_SO_HEAD_INTF.RECEIVE_DATE := SYSDATE;
          --有来源客户提货单号的记录来源客户提货单号
          IF R_PLN_LG_ORDER.ORDER_HEAD_ID IS NOT NULL THEN
            R_CUST_SO_HEAD_INTF.ORIGIN_ORIGIN_TYPE       := '02';
            R_CUST_SO_HEAD_INTF.ORIGIN_ORIGIN_HEAD_ID    := R_PLN_LG_ORDER.ORDER_HEAD_ID;
            R_CUST_SO_HEAD_INTF.ORIGIN_ORIGIN_ORDER_CODE := R_PLN_LG_ORDER.ORDER_NUMBER;
            R_CUST_SO_HEAD_INTF.CUSTOMER_CHANNEL_TYPE    := R_PLN_LG_ORDER.CUSTOMER_CHANNEL_TYPE;
            --工程信息记录 lilh6 2018-5-8
            R_CUST_SO_HEAD_INTF.Proj_Reg_Code            := R_PLN_LG_ORDER.Proj_Reg_Code; --CIMS项目登陆号
            R_CUST_SO_HEAD_INTF.Ccs_Proj_Reg_Code        := R_PLN_LG_ORDER.Ccs_Proj_Reg_Code;  --CCS项目登陆号
            R_CUST_SO_HEAD_INTF.Project_Flag             := R_PLN_LG_ORDER.Project_Order_Flag;  --工程机标识
            --直发自提标志
            IF R_PLN_LG_ORDER.DIRECT_SEND_FLAG = 'Y' THEN
              R_CUST_SO_HEAD_INTF.DIRECT_SHIP_FLAG := 'Y';
            ELSIF R_PLN_LG_ORDER.CLIENT_CARRY_FLAG = 'Y' THEN
              R_CUST_SO_HEAD_INTF.SELF_PICK_FLAG := 'Y';
            END IF;
            
            R_CUST_SO_HEAD_INTF.FUND_CHECK_MODE := R_PLN_LG_ORDER.FUND_CHECK_MODE;
            R_CUST_SO_HEAD_INTF.LG_PROCESS_TYPE := R_PLN_LG_ORDER.LG_PROCESS_TYPE;
            R_CUST_SO_HEAD_INTF.SYS_SOURCE := R_PLN_LG_ORDER.SYS_SOURCE;
            
            SELECT CASE
                     WHEN R_PLN_LG_ORDER.SYS_ORIGIN = 'CCS' THEN
                       R_PLN_LG_ORDER.ORIGIN_ORDER_NUMBER
                     WHEN R_PLN_LG_ORDER.SYS_SOURCE = 'CCS' THEN
                       R_PLN_LG_ORDER.SOURCE_ORDER_NUMBER
                     ELSE
                       NULL
                   END
              INTO R_CUST_SO_HEAD_INTF.SYS_SOURCE_ORDER_NUM
              FROM DUAL;
          ELSE
            R_CUST_SO_HEAD_INTF.ORIGIN_ORIGIN_TYPE       := NULL;
            R_CUST_SO_HEAD_INTF.ORIGIN_ORIGIN_HEAD_ID    := NULL;
            R_CUST_SO_HEAD_INTF.ORIGIN_ORIGIN_ORDER_CODE := NULL;
            R_CUST_SO_HEAD_INTF.CUSTOMER_CHANNEL_TYPE    := NULL;
          END IF;
        END IF;
      
        --销售单接口行
        --按照营销大类、销售单类型、折扣类型、批文拆单
        IF OUT_RESULT = V_SUCCESS THEN
          FOR R_SPLIT IN (SELECT DISTINCT NVL(L.ASS_ITEM_MAIN_TYPE,
                                              BI.SALES_MAIN_TYPE) SALES_MAIN_TYPE,
                                          L.SO_BILL_TYPE_ID,
                                          NVL(L.DISCOUNT_TYPE, 'COMMON') DISCOUNT_TYPE,
                                          L.PRICE_APPLY_TYPE,
                                          L.PRICE_APPLY_ID,
                                          L.PRICE_APPLY_CODE
                            FROM T_SO_TO_SUPP_PARAM_LINE L, T_BD_ITEM BI
                           WHERE L.ENTITY_ID = BI.ENTITY_ID
                             AND L.ASS_ITEM_CODE = BI.ITEM_CODE
                             AND L.PARAM_ID = IN_PARAM_ID) LOOP
            --检查是否需要处理
            SELECT COUNT(1)
              INTO V_COUNT
              FROM (SELECT L.ASS_ITEM_CODE,
                           MIN(floor(L.FACT_REV_GOOD_QTY/NVL(L.SUB_ITEM_QTY_SCALE,1))) MIN_FACT_REV_GOOD_QTY
                      FROM T_SO_TO_SUPP_PARAM_LINE L, T_BD_ITEM BI
                     WHERE L.ENTITY_ID = BI.ENTITY_ID
                       AND L.ASS_ITEM_CODE = BI.ITEM_CODE
                       AND L.PARAM_ID = IN_PARAM_ID
                       AND NVL(L.ASS_ITEM_MAIN_TYPE, BI.SALES_MAIN_TYPE) =
                           R_SPLIT.SALES_MAIN_TYPE
                       AND L.SO_BILL_TYPE_ID = R_SPLIT.SO_BILL_TYPE_ID
                       AND NVL(L.DISCOUNT_TYPE, 'COMMON') =
                           NVL(R_SPLIT.DISCOUNT_TYPE, 'COMMON')
                       AND NVL(L.PRICE_APPLY_TYPE, '_') =
                           NVL(R_SPLIT.PRICE_APPLY_TYPE, '_')
                       AND NVL(L.PRICE_APPLY_ID, 0) =
                           NVL(R_SPLIT.PRICE_APPLY_ID, 0)
                     GROUP BY L.ASS_ITEM_CODE)
             WHERE MIN_FACT_REV_GOOD_QTY > 0;
          
            IF V_COUNT > 0 THEN
              R_CUST_SO_HEAD_INTF.DISCOUNT_TYPE := R_SPLIT.DISCOUNT_TYPE;
            
              --检查营销大类
              IF OUT_RESULT = V_SUCCESS THEN
                V_IN_PARAM := '营销大类=' || R_SPLIT.SALES_MAIN_TYPE;
                BEGIN
                  SELECT C.CLASS_CODE, C.CLASS_NAME
                    INTO R_CUST_SO_HEAD_INTF.SALES_MAIN_TYPE,
                         R_CUST_SO_HEAD_INTF.SALES_MAIN_TYPE_NAME
                    FROM T_BD_ITEM_CLASS C
                   WHERE C.CLASS_CODE = R_SPLIT.SALES_MAIN_TYPE
                     AND C.CLASS_TYPE = 'M'
                     AND C.ACTIVE_FLAG = V_YES
                     AND C.ENTITY_ID = R_PARAM_HEAD.ENTITY_ID;
                EXCEPTION
                  WHEN NO_DATA_FOUND THEN
                    OUT_RESULT := '营销大类不存在或已失效，请检查营销分类设置！';
                END;
              END IF;
            
              --检查销售单类型
              IF OUT_RESULT = V_SUCCESS THEN
                V_IN_PARAM := '销售单类型ID=' ||
                              TO_CHAR(R_SPLIT.SO_BILL_TYPE_ID);
                BEGIN
                  SELECT T.BILL_TYPE_ID, T.BILL_TYPE_CODE, T.BILL_TYPE_NAME
                    INTO R_CUST_SO_HEAD_INTF.BILL_TYPE_ID,
                         R_CUST_SO_HEAD_INTF.BILL_TYPE_CODE,
                         R_CUST_SO_HEAD_INTF.BILL_TYPE_NAME
                    FROM V_SO_BILL_TYPE T
                   WHERE T.BILL_TYPE_ID = R_SPLIT.SO_BILL_TYPE_ID
                     AND T.BILL_TYPE_CODE NOT IN (SO_BILL_CODE_SO_TC) --非电商销售单
                     AND NVL(T.REVERSAL_BILL_FLAG, 'N') = 'N' --非红冲单据类型
                     AND SYSDATE BETWEEN T.BEGIN_DATE AND
                         NVL(T.END_DATE, SYSDATE + 1)
                     AND T.SRC_TYPE_CODE = '1001'; --销售出库单
                EXCEPTION
                  WHEN NO_DATA_FOUND THEN
                    OUT_RESULT := '销售单据类型不存在或已失效，请检查单据类型设置！' || V_NL ||
                                  '销售单据类型需满足条件：非电商销售单，非红冲单据类型，单据源类型为销售单(1001)';
                END;
              END IF;
            
              --若价格批文类型不为空，则检查价格批文
              IF OUT_RESULT = V_SUCCESS AND
                 R_SPLIT.PRICE_APPLY_TYPE IS NOT NULL AND NVL(R_SPLIT.PRICE_APPLY_ID, -1) <> -1 THEN
                V_IN_PARAM := '价格批文类型=' || R_SPLIT.PRICE_APPLY_TYPE ||
                              ',价格批文ID=' || TO_CHAR(R_SPLIT.PRICE_APPLY_ID);
                BEGIN
                  SELECT A.APPLY_TYPE, A.PRICE_APPLY_ID, A.APPLY_CODE
                    INTO R_CUST_SO_HEAD_INTF.PROJECT_TYPE_CODE,
                         R_CUST_SO_HEAD_INTF.PROJECT_ID,
                         R_CUST_SO_HEAD_INTF.PROJECT_NUM
                    FROM T_BD_PRICE_APPLY A
                   WHERE A.APPLY_TYPE = R_SPLIT.PRICE_APPLY_TYPE
                     AND A.PRICE_APPLY_ID = R_SPLIT.PRICE_APPLY_ID
                     AND A.APPLY_STATUS = APPLY_STATUS_30
                  /*AND SYSDATE BETWEEN A.BEGIN_DATE AND NVL(A.END_DATE, SYSDATE + 1)*/
                  ;
                EXCEPTION
                  WHEN NO_DATA_FOUND THEN
                    OUT_RESULT := '价格批文无效，请检查价格批文是否已审批通过或在有效期内！';
                END;
              ELSE
                R_CUST_SO_HEAD_INTF.PROJECT_TYPE_CODE := R_SPLIT.PRICE_APPLY_TYPE;
                R_CUST_SO_HEAD_INTF.PROJECT_ID        := R_SPLIT.PRICE_APPLY_ID;
                R_CUST_SO_HEAD_INTF.PROJECT_NUM       := R_SPLIT.PRICE_APPLY_CODE;
              END IF;
            
              --插入销售单接口头表
              IF OUT_RESULT = V_SUCCESS THEN
                V_IN_PARAM := '插入销售单接口头表';
                PKG_SO_BIZ.P_SO_CREATE_INTF_HEADER(P_SO_INTF_HEADER => R_CUST_SO_HEAD_INTF,
                                                   P_USER_CODE      => IN_USER_CODE,
                                                   P_RESULT         => OUT_ERR_NUM,
                                                   P_ERR_MSG        => OUT_RESULT);
              END IF;
            
              --处理销售接口行
              IF OUT_RESULT = V_SUCCESS THEN
                V_TABLE_INDEX := R_SPLIT.SALES_MAIN_TYPE || ',' || R_SPLIT.DISCOUNT_TYPE;
                V_ASS_ITEM_CODE  := '_';
                V_SUM_AMOUNT     := 0;
                V_SUM_DIS_AMOUNT := 0;
                FOR R_PARAM_LINE IN (SELECT L.*
                                       FROM T_SO_TO_SUPP_PARAM_LINE L,
                                            T_BD_ITEM               BI
                                      WHERE L.ENTITY_ID = BI.ENTITY_ID
                                        AND L.ASS_ITEM_CODE = BI.ITEM_CODE
                                        AND L.PARAM_ID = IN_PARAM_ID
                                        AND NVL(L.ASS_ITEM_MAIN_TYPE, BI.SALES_MAIN_TYPE) = R_SPLIT.SALES_MAIN_TYPE
                                        AND L.SO_BILL_TYPE_ID = R_SPLIT.SO_BILL_TYPE_ID
                                        AND L.DISCOUNT_TYPE = R_SPLIT.DISCOUNT_TYPE
                                        AND NVL(L.PRICE_APPLY_TYPE, '_') = NVL(R_SPLIT.PRICE_APPLY_TYPE, '_')
                                        AND NVL(L.PRICE_APPLY_ID, 0) = NVL(R_SPLIT.PRICE_APPLY_ID, 0)
                                      ORDER BY L.ASS_ITEM_CODE,
                                               FLOOR(NVL(L.FACT_REV_GOOD_QTY, 0)/NVL(L.SUB_ITEM_QTY_SCALE,1))) --按套件编码、实收数量从小到大排序，只处理第一行数据（实收数量最小）
                 LOOP
                  --不同的套件编码需新增销售接口行
                  IF V_ASS_ITEM_CODE <> R_PARAM_LINE.ASS_ITEM_CODE THEN
                    V_ASS_ITEM_CODE := R_PARAM_LINE.ASS_ITEM_CODE;
                    IF FLOOR(R_PARAM_LINE.FACT_REV_GOOD_QTY/NVL(R_PARAM_LINE.SUB_ITEM_QTY_SCALE,1)) > 0 THEN
                      --实收大于0才处理
                      R_CUST_SO_LINE_INTF.ENTITY_ID              := R_CUST_SO_HEAD_INTF.ENTITY_ID;
                      R_CUST_SO_LINE_INTF.SO_HEADER_INTERFACE_ID := R_CUST_SO_HEAD_INTF.SO_HEADER_INTERFACE_ID;
                    
                      --转采购过程已检查产品，直接获取
                      SELECT BI.ITEM_ID,
                             BI.ITEM_CODE,
                             BI.ITEM_NAME,
                             BI.DEFAULTUNIT,
                             BI.PACKINGSIZE,
                             BI.GROSSWEIGHT
                        INTO R_CUST_SO_LINE_INTF.ITEM_ID,
                             R_CUST_SO_LINE_INTF.ITEM_CODE,
                             R_CUST_SO_LINE_INTF.ITEM_NAME,
                             R_CUST_SO_LINE_INTF.ITEM_UOM,
                             R_CUST_SO_LINE_INTF.ITEM_VOLUME,
                             R_CUST_SO_LINE_INTF.ITEM_WEIGHT
                        FROM T_BD_ITEM BI
                       WHERE BI.ENTITY_ID = R_CUST_SO_LINE_INTF.ENTITY_ID
                         AND BI.ITEM_CODE = R_PARAM_LINE.ASS_ITEM_CODE;
                    
                      R_CUST_SO_LINE_INTF.ITEM_QTY   := FLOOR(R_PARAM_LINE.FACT_REV_GOOD_QTY/NVL(R_PARAM_LINE.SUB_ITEM_QTY_SCALE,1)); --产品数量取实收数量
                      R_CUST_SO_LINE_INTF.ITEM_PRICE := R_PARAM_LINE.CUST_SO_LIST_PRICE;
                    
                      V_IN_PARAM := '产品编码=' || R_PARAM_LINE.ASS_ITEM_CODE ||
                                    ',折扣=' ||
                                    TO_CHAR(R_PARAM_LINE.CUST_SO_DISCOUNT_RATE) ||
                                    ',月返=' ||
                                    TO_CHAR(R_PARAM_LINE.CUST_SO_MONTH_DIS_RATE);
                      IF NVL(R_PARAM_LINE.CUST_SO_DISCOUNT_RATE, 0) +
                         NVL(R_PARAM_LINE.CUST_SO_MONTH_DIS_RATE, 0) < 0 OR
                         NVL(R_PARAM_LINE.CUST_SO_DISCOUNT_RATE, 0) +
                         NVL(R_PARAM_LINE.CUST_SO_MONTH_DIS_RATE, 0) > 100 THEN
                        OUT_RESULT := '折扣+月返需在0~100之间';
                      ELSE
                        R_CUST_SO_LINE_INTF.DISCOUNT_RATE       := R_PARAM_LINE.CUST_SO_DISCOUNT_RATE;
                        R_CUST_SO_LINE_INTF.MONTH_DISCOUNT_RATE := R_PARAM_LINE.CUST_SO_MONTH_DIS_RATE;
                      END IF;
                    
                      --价格批文
                      IF OUT_RESULT = V_SUCCESS AND
                         R_PARAM_LINE.PRICE_APPLY_TYPE IS NOT Null AND NVL(R_PARAM_LINE.PRICE_APPLY_ID, -1) <> -1 THEN
                        R_CUST_SO_LINE_INTF.PROJECT_TYPE_CODE := R_PARAM_LINE.PRICE_APPLY_TYPE;
                        R_CUST_SO_LINE_INTF.PROJECT_ID        := R_PARAM_LINE.PRICE_APPLY_ID;
                        R_CUST_SO_LINE_INTF.PROJECT_NUM       := R_PARAM_LINE.PRICE_APPLY_CODE;
                        R_CUST_SO_LINE_INTF.PROJECT_PRICE     := R_PARAM_LINE.CUST_SO_LIST_PRICE;
                        R_CUST_SO_LINE_INTF.PROJECT_LINE_ID   := R_PARAM_LINE.PRICE_APPLY_LINE_ID;
                      
                        SELECT L.TRANSFER_PRICE_LINE_ID
                          INTO V_TRANSFER_PRICE_LINE_ID
                          FROM T_SO_LINE L
                         WHERE L.SO_LINE_ID = R_PARAM_LINE.SOURCE_LINE_ID;
                      
                        --自提、无客户提货订单来源、来源销售单行无相关批文信息，需先锁定批文数量
                        IF /*R_CUST_SO_HEAD_INTF.SELF_PICK_FLAG = V_YES
                                                  AND*/
                         R_PLN_LG_ORDER.ORDER_HEAD_ID IS NULL AND
                         V_TRANSFER_PRICE_LINE_ID IS NULL THEN
                          V_IN_PARAM := '批文行ID=' ||
                                        TO_CHAR(R_PARAM_LINE.PRICE_APPLY_LINE_ID) ||
                                        ',批文号=' ||
                                        R_PARAM_LINE.PRICE_APPLY_CODE ||
                                        ',产品=' ||
                                        R_PARAM_LINE.ASS_ITEM_CODE;
                          PKG_BD_PRICE.P_APPLY_LOCK(P_APPLY_DETAIL_ID => R_PARAM_LINE.PRICE_APPLY_LINE_ID,
                                                    P_LOCK_CNT        => R_CUST_SO_LINE_INTF.ITEM_QTY,
                                                    P_BILL_NO         => R_SO_HEAD.SO_NUM,
                                                    P_RETURN_CODE     => V_RESULT,
                                                    P_RETURN_MSG      => OUT_RESULT);
                          IF V_RESULT = '1' THEN
                            --返回1表示成功
                            OUT_RESULT := V_SUCCESS;
                          END IF;
                        END IF;
                      ELSE
                        R_CUST_SO_LINE_INTF.PROJECT_TYPE_CODE := R_PARAM_LINE.PRICE_APPLY_TYPE;
                        R_CUST_SO_LINE_INTF.PROJECT_ID        := R_PARAM_LINE.PRICE_APPLY_ID;
                        R_CUST_SO_LINE_INTF.PROJECT_NUM       := R_PARAM_LINE.PRICE_APPLY_CODE;
                        R_CUST_SO_LINE_INTF.PROJECT_PRICE     := R_PARAM_LINE.CUST_SO_LIST_PRICE;
                        R_CUST_SO_LINE_INTF.PROJECT_LINE_ID   := R_PARAM_LINE.PRICE_APPLY_LINE_ID;
                      END IF;
                    
                      IF OUT_RESULT = V_SUCCESS THEN
                        R_CUST_SO_LINE_INTF.ITEM_SETTLE_PRICE  := R_CUST_SO_LINE_INTF.ITEM_PRICE *
                                                                  (100 -
                                                                  NVL(R_CUST_SO_LINE_INTF.DISCOUNT_RATE,
                                                                       0) -
                                                                  NVL(R_CUST_SO_LINE_INTF.MONTH_DISCOUNT_RATE,
                                                                       0)) / 100;
                        R_CUST_SO_LINE_INTF.ITEM_SETTLE_AMOUNT := R_CUST_SO_LINE_INTF.ITEM_QTY *
                                                                  R_CUST_SO_LINE_INTF.ITEM_SETTLE_PRICE;
                        V_SUM_AMOUNT                           := V_SUM_AMOUNT +
                                                                  R_CUST_SO_LINE_INTF.ITEM_SETTLE_AMOUNT;
                        R_CUST_SO_LINE_INTF.DISCOUNT_AMOUNT    := R_CUST_SO_LINE_INTF.ITEM_QTY *
                                                                  R_CUST_SO_LINE_INTF.ITEM_PRICE *
                                                                  NVL(R_CUST_SO_LINE_INTF.DISCOUNT_RATE,
                                                                      0) / 100;
                        V_SUM_DIS_AMOUNT                       := V_SUM_DIS_AMOUNT +
                                                                  R_CUST_SO_LINE_INTF.DISCOUNT_AMOUNT;
                        R_CUST_SO_LINE_INTF.ITEM_LIST_AMOUNT   := R_CUST_SO_LINE_INTF.ITEM_QTY *
                                                                  R_CUST_SO_LINE_INTF.ITEM_PRICE;
                      
                        R_CUST_SO_LINE_INTF.SRC_HEADER_ID     := R_CUST_SO_HEAD_INTF.RAW_SRC_BILL_ID;
                        R_CUST_SO_LINE_INTF.SRC_LINE_ID       := R_PARAM_LINE.SOURCE_LINE_ID;
                        R_CUST_SO_LINE_INTF.RAW_SRC_HEADER_ID := R_CUST_SO_HEAD_INTF.RAW_SRC_BILL_ID;
                        R_CUST_SO_LINE_INTF.RAW_SRC_LINE_ID   := R_PARAM_LINE.SOURCE_LINE_ID;
                      
                        IF R_PLN_LG_ORDER.ORDER_HEAD_ID IS NOT NULL THEN
                          R_CUST_SO_LINE_INTF.LG_ORDER_HEAD_ID := R_PLN_LG_ORDER.ORDER_HEAD_ID;
                          R_CUST_SO_LINE_INTF.LG_ORDER_NUMBER  := R_PLN_LG_ORDER.ORDER_NUMBER;
                        
                          BEGIN
                            SELECT L.*
                              INTO R_PLN_LG_LINE
                              FROM T_PLN_LG_ORDER_LINE L
                             WHERE L.ORDER_HEAD_ID =
                                   R_PLN_LG_ORDER.ORDER_HEAD_ID
                               AND L.ITEM_CODE =
                                   R_CUST_SO_LINE_INTF.ITEM_CODE
                               AND NVL(L.SHARE_VENDOR_TYPE, '_') <> 'AGENT';
                          
                            R_CUST_SO_LINE_INTF.LG_ORDER_LINE_ID := R_PLN_LG_LINE.ORDER_LINE_ID;
                          
                            --更新提货订单行评审数量
                            UPDATE T_PLN_LG_ORDER_LINE L
                               SET L.CENTER_AFFIRMED_QTY = NVL(L.CENTER_AFFIRMED_QTY,
                                                               0) +
                                                           R_CUST_SO_LINE_INTF.ITEM_QTY,
                                   L.AFFIRMED_QUANTITY   = NVL(L.AFFIRMED_QUANTITY,
                                                               0) +
                                                           R_CUST_SO_LINE_INTF.ITEM_QTY,
                                   --L.SENDED_QTY = DECODE(R_PLN_LG_ORDER.LOCK_AMOUNT_FLAG, 'Y', NVL(L.SENDED_QTY, 0) + R_CUST_SO_LINE_INTF.ITEM_QTY, L.SENDED_QTY),
                                   L.SENDED_QTY = CASE
                                                    WHEN R_PLN_LG_ORDER.LOCK_AMOUNT_FLAG IN (V_LOCK_AMOUNT_FLAG_Y, V_LOCK_AMOUNT_FLAG_HQ) THEN
                                                      NVL(L.SENDED_QTY, 0) + R_CUST_SO_LINE_INTF.ITEM_QTY
                                                    WHEN R_PLN_LG_ORDER.LOCK_AMOUNT_FLAG = V_LOCK_AMOUNT_FLAG_S AND v_Hq_Affirm_Lock_Full_Amount = 'Y' THEN
                                                      NVL(L.SENDED_QTY, 0) + R_CUST_SO_LINE_INTF.ITEM_QTY
                                                    ELSE
                                                      L.SENDED_QTY
                                                    END,
                                   --L.CANCEL_QTY = NVL(L.CANCEL_QTY, 0) + NVL(R_PARAM_LINE.ITEM_QTY, 0) - NVL(R_CUST_SO_LINE_INTF.ITEM_QTY, 0),
                                   L.LAST_UPDATED_BY  = IN_USER_CODE,
                                   L.LAST_UPDATE_DATE = SYSDATE,
                                   L.VERSION = NVL(L.VERSION, 0) + 1
                             WHERE L.ORDER_LINE_ID =
                                   R_CUST_SO_LINE_INTF.LG_ORDER_LINE_ID;
                          
                            --按取消数量解锁
                            /*IF NVL(R_PARAM_LINE.ITEM_QTY, 0) - NVL(R_CUST_SO_LINE_INTF.ITEM_QTY, 0) > 0 THEN
                              V_CANCEL_AMOUNT := R_CUST_SO_LINE_INTF.ITEM_SETTLE_PRICE * (NVL(R_PARAM_LINE.ITEM_QTY, 0) - NVL(R_CUST_SO_LINE_INTF.ITEM_QTY, 0));
                              V_CANCEL_DIS_AMOUNT := (NVL(R_PARAM_LINE.ITEM_QTY, 0) - NVL(R_CUST_SO_LINE_INTF.ITEM_QTY, 0)) * R_CUST_SO_LINE_INTF.ITEM_PRICE *
                                                               NVL(R_CUST_SO_LINE_INTF.DISCOUNT_RATE, 0) / 100;
                              IF OUT_RESULT = v_Success THEN
                                V_IN_PARAM := '营销大类='||R_PLN_LG_LINE.SALES_MAIN_TYPE||v_Nl||
                                              '客户ID='||TO_CHAR(R_PLN_LG_ORDER.CUSTOMER_ID)||
                                              ',客户编码='||R_PLN_LG_ORDER.CUSTOMER_CODE||v_Nl||
                                              '账户ID='||TO_CHAR(R_PLN_LG_ORDER.ACCOUNT_ID)||
                                              ',账户编码='||R_PLN_LG_ORDER.ACCOUNT_CODE;
                                Pkg_Credit_Account_Control.Prc_Credit_Order_Bill(R_PLN_LG_ORDER.Entity_Id, --主体ID
                                                                                 2, --动作(取消信用占用）
                                                                                 Round(V_CANCEL_AMOUNT, 2), --结算金额
                                                                                 Round(V_CANCEL_DIS_AMOUNT, 2), --折让金额
                                                                                 --20170517 hejy3 按行营销大类
                                                                                 --v_Sales_Main_Type,
                                                                                 R_PLN_LG_LINE.SALES_MAIN_TYPE,
                                                                                 R_PLN_LG_ORDER.Account_Id, --账户ID
                                                                                 R_PLN_LG_ORDER.Customer_Id, --客户ID
                                                                                 Null, --项目编码
                                                                                 R_PLN_LG_ORDER.Order_Head_Id, --单据头ID
                                                                                 --r_Lgorder_Head.Order_Type_Name, --单据类型名
                                                                                 R_PLN_LG_ORDER.Order_Type_Code, --20160912 hejy3 传入订单类型编码
                                                                                 IN_USER_CODE,
                                                                                 OUT_ERR_NUM,
                                                                                 OUT_RESULT,
                                                                                 Nvl(R_PLN_LG_LINE.Discount_Type, 'COMMON') --add lizhen 2017-08-08
                                                                                 );
                                --add by lizhen 2017-04-20 折扣类型款项释放处理
                                IF OUT_RESULT = v_Success THEN
                                  If Nvl(R_PLN_LG_LINE.Discount_Type, 'COMMON') != 'COMMON' Then
                                    V_IN_PARAM := '营销大类='||R_PLN_LG_LINE.SALES_MAIN_TYPE||v_Nl||
                                                  '客户ID='||TO_CHAR(R_PLN_LG_ORDER.CUSTOMER_ID)||
                                                  ',客户编码='||R_PLN_LG_ORDER.CUSTOMER_CODE||v_Nl||
                                                  '账户ID='||TO_CHAR(R_PLN_LG_ORDER.ACCOUNT_ID)||
                                                  ',账户编码='||R_PLN_LG_ORDER.ACCOUNT_CODE||v_Nl||
                                                  '折扣类型='||R_PLN_LG_LINE.DISCOUNT_TYPE;
                                    Pkg_Credit_Dis.p_Check_Dis_Amount(In_Action_Type     => 2, --操作类型 与信用控制动作标识一致
                                                                      In_Entity_Id       => R_PLN_LG_ORDER.Entity_Id, --主体ID
                                                                      In_Account_Id      => R_PLN_LG_ORDER.Account_Id, --客户账户ID
                                                                      Is_Source_Type     => '02', --来源类型 取码表SO_SRC_TYPE
                                                                      In_Source_Bill_Id  => R_PLN_LG_ORDER.Order_Head_Id, --来源单据ID 取相应的单据头ID
                                                                      Is_Sales_Main_Type => R_PLN_LG_LINE.Sales_Main_Type, --营销大类
                                                                      Is_Discount_Type   => Nvl(R_PLN_LG_LINE.Discount_Type, 'COMMON'), --折扣类型 取行上的折扣类型
                                                                      In_Amount          => Round(V_CANCEL_AMOUNT, 2), --金额
                                                                      Is_User_Name       => IN_USER_CODE, --用户编码
                                                                      Is_Attrib01        => Null, --预留输入参数01
                                                                      Is_Attrib02        => Null, --预留输入参数02
                                                                      On_Result          => OUT_ERR_NUM, --成功则返回0，否则返回对应的出错代码
                                                                      Os_Message         => OUT_RESULT, --成功返回“SUCCESS”；失败返回出错信息
                                                                      Os_Attrib01        => v_Os_Attrib01, --预留输出参数01
                                                                      Os_Attrib02        => v_Os_Attrib02 --预留输出参数02
                                                                      );
                                    IF OUT_RESULT <> v_Success THEN
                                      OUT_RESULT := '检查并锁定折扣类型金额失败，请检查折扣类型余额是否足够！' || v_Nl ||
                                                    OUT_RESULT;
                                    END IF;
                                  End If;
                                else
                                  OUT_RESULT := '检查并锁定客户款项失败，请检查客户余款是否足够！' || v_Nl ||
                                             OUT_RESULT;
                                end if;
                              END IF;
                              
                              --批文锁定处理
                              IF OUT_RESULT = v_Success AND R_PLN_LG_LINE.PROJECT_ORDER_TYPE IS NOT NULL THEN
                                V_IN_PARAM := '单据号='||R_PLN_LG_ORDER.ORDER_NUMBER||v_Nl||
                                              '批文号='||R_PLN_LG_LINE.PROJECT_ORDER_NUMBER||v_Nl||
                                              '产品编码='||R_PLN_LG_LINE.ITEM_CODE||v_Nl||
                                              '批文行ID='||TO_CHAR(R_PLN_LG_LINE.Project_Order_Line_Id);
                                Pkg_Bd_Price.p_Apply_Unlock(P_APPLY_DETAIL_ID => R_PLN_LG_LINE.Project_Order_Line_Id, --批文明细ID
                                                            P_UNLOCK_CNT => NVL(R_PARAM_LINE.ITEM_QTY, 0) - NVL(R_CUST_SO_LINE_INTF.ITEM_QTY, 0), --解除锁定数量
                                                            P_BILL_NO => R_PLN_LG_ORDER.Order_Number, --关联单号
                                                            P_RETURN_CODE => V_Result, --返回编码，1成功，0失败
                                                            P_RETURN_MSG => OUT_RESULT);
                                If V_Result = '1' Then
                                  OUT_RESULT := v_Success;
                                End If;
                              END IF;
                            END IF;*/
                          
                            BEGIN
                              V_IN_PARAM := '写入评审明细';
                              INSERT INTO T_PLN_ORDER_REVIEW_INFO
                                (ENTITY_ID, --业务主体
                                 ORDER_REVIEW_ID, --订单评审记录ID
                                 LOT_NUM, --批次（用于记录订单评审第几次）
                                 ORDER_PERIOD, --订单周期（汇总的订单评审，记录订单周期）
                                 SOURCE_ORDER_TYPE_ID, --源订单类型ID
                                 ORDER_TYPE_ID, --订单类型ID
                                 ORDER_STATE, --订单状态（送审、汇总、库评、产地分解等）
                                 ORDER_TYPE_NAME, --订单类型名称
                                 ORDER_NUMBER, --订单号（单单评审，记录订单号）
                                 HQ_DATE, --总部评审日期
                                 HQ_USER, --总部评审人员
                                 REMARK, --备注
                                 CREATED_BY, --创建人
                                 CREATION_DATE, --创建日期
                                 LAST_UPDATED_BY, --最后修改人
                                 LAST_UPDATE_DATE, --最后修改日期
                                 PRE_FIELD_01, --预留字段1
                                 PRE_FIELD_02, --预留字段2
                                 PRE_FIELD_03, --预留字段3
                                 PRE_FIELD_04, --预留字段4
                                 PRE_FIELD_05, --预留字段5
                                 PRE_FIELD_06, --预留字段6
                                 ORIGIN_ORDER_HEAD_ID, --来源订单头ID
                                 ORIGIN_ORDER_LINE_ID, --来源订单行ID
                                 ITEM_ID, --产品ID
                                 ITEM_CODE, --产品编码
                                 ITEM_NAME, --产品描述
                                 AFFIRM_QTY, --评审数量
                                 RECEIVE_INVENTORY_ID, --收货仓库ID
                                 SEND_INVENTORY_ID, --发货仓库ID
                                 IS_CANCEL_DIRECT_SEND,
                                 CHECKUP_CONTENT, --评审意见  add by lilh6 160909
                                 CUSTOMER_ORDER_NUMBER, --客户订单号 add by lilh6 160909
                                 CONSIGNEE_ADDR_NAME --收货地址 add by lilh6 160920
                                 )
                              VALUES
                                (R_PLN_LG_ORDER.ENTITY_ID, --业务主体
                                 S_PLN_ORDER_REVIEW_INFO.NEXTVAL, --订单评审记录ID
                                 (SELECT COUNT(1)
                                    FROM T_PLN_ORDER_REVIEW_INFO RI
                                   WHERE RI.ORIGIN_ORDER_HEAD_ID =
                                         R_PLN_LG_ORDER.ORDER_HEAD_ID
                                     AND RI.ORIGIN_ORDER_LINE_ID =
                                         R_PLN_LG_LINE.ORDER_LINE_ID) + 1, --批次（用于记录订单评审第几次）
                                 NULL, --订单周期（汇总的订单评审，记录订单周期）
                                 1, --源订单类型ID
                                 R_PLN_LG_ORDER.ORDER_TYPE_ID, --订单类型ID
                                 R_PLN_LG_ORDER.ORDER_HEAD_STATE, --订单状态（送审、汇总、库评、产地分解等）
                                 R_PLN_LG_ORDER.ORDER_TYPE_NAME, --订单类型名称
                                 R_PLN_LG_ORDER.ORDER_NUMBER, --订单号（单单评审，记录订单号）
                                 TRUNC(SYSDATE), --总部评审日期
                                 IN_USER_CODE, --总部评审人员
                                 '销售转采购生成销售单回写评审数量', --备注
                                 IN_USER_CODE, --创建人
                                 SYSDATE, --创建日期
                                 IN_USER_CODE, --最后修改人
                                 SYSDATE, --最后修改日期
                                 NULL, --Pre_Field_01, --预留字段1
                                 NULL, --Pre_Field_02, --预留字段2
                                 NULL, --Pre_Field_03, --预留字段3
                                 NULL, --Pre_Field_04, --预留字段4
                                 NULL, --Pre_Field_05, --预留字段5
                                 NULL, --Pre_Field_06, --预留字段6
                                 R_PLN_LG_ORDER.ORDER_HEAD_ID, --Origin_Order_Head_Id, --来源订单头ID
                                 R_PLN_LG_LINE.ORDER_LINE_ID, --Origin_Order_Line_Id, --来源订单行ID
                                 R_PLN_LG_LINE.ITEM_ID, --Item_Id, --产品ID
                                 R_PLN_LG_LINE.ITEM_CODE, --Item_Code, --产品编码
                                 R_PLN_LG_LINE.ITEM_NAME, --Item_Name, --产品描述
                                 R_CUST_SO_LINE_INTF.ITEM_QTY, --Affirm_Qty --评审数量
                                 NULL, --收货仓库ID
                                 R_CUST_SO_HEAD_INTF.SHIP_INV_ID, --发货仓库ID
                                 'N', --add by xuhongjiu 2016-05-05
                                 R_PLN_LG_ORDER.CHECKUP_CONTENT, --评审意见 add by lilh6 160909
                                 R_PLN_LG_ORDER.CUSTOMER_ORDER_NUMBER, --客户订单号 add by lilh6 160909
                                 R_CUST_SO_HEAD_INTF.CONSIGNEE_ADDRESS --收货地址 add by lilh6 160920
                                 );
                            EXCEPTION
                              WHEN OTHERS THEN
                                OUT_RESULT := '插入评审记录信息失败，失败原因：' || SQLERRM;
                            END;
                          EXCEPTION
                            WHEN NO_DATA_FOUND THEN
                              R_CUST_SO_LINE_INTF.LG_ORDER_LINE_ID := NULL;
                          END;
                        ELSE
                          R_CUST_SO_LINE_INTF.LG_ORDER_HEAD_ID := NULL;
                          R_CUST_SO_LINE_INTF.LG_ORDER_NUMBER  := NULL;
                          R_CUST_SO_LINE_INTF.LG_ORDER_LINE_ID := NULL;
                        END IF;
                        --SELECT S_SO_LINE_INTERFACE.NEXTVAL INTO R_CUST_SO_LINE_INTF.SO_LINE_INTERFACE_ID FROM DUAL;
                      END IF;
                    
                      --检查库存可用量
                      IF OUT_RESULT = V_SUCCESS THEN
                        V_IN_PARAM := '产品编码=' ||
                                      R_CUST_SO_LINE_INTF.ITEM_CODE ||
                                      '，仓库编码=' ||
                                      R_PARAM_HEAD.FINANCE_INV_CODE;
                        --获取产品仓库的可用量
                        V_USABLE_ITEM_QOH_QTY := PKG_INV_PUB.F_GET_ITEM_INV_QOH(P_ENTITY_ID    => R_CUST_SO_HEAD_INTF.ENTITY_ID,
                                                                                P_INVENTORY_ID => R_CUST_SO_HEAD_INTF.SHIP_INV_ID,
                                                                                P_ITEM_ID      => R_CUST_SO_LINE_INTF.ITEM_ID,
                                                                                P_USER_CODE    => IN_USER_CODE,
                                                                                P_GET_QOH_TYPE => 2);
                        IF V_USABLE_ITEM_QOH_QTY <
                           R_CUST_SO_LINE_INTF.ITEM_QTY THEN
                          OUT_RESULT := '库存可用量无法满足本次占用数。库存可用量=' ||
                                        TO_CHAR(V_USABLE_ITEM_QOH_QTY) ||
                                        '，本次占用数量' ||
                                        TO_CHAR(R_CUST_SO_LINE_INTF.ITEM_QTY);
                        END IF;
                      END IF;
                    
                      --做库存占用
                      IF OUT_RESULT = V_SUCCESS THEN
                        V_IN_PARAM := '库存占用。产品编码=' ||
                                      R_CUST_SO_LINE_INTF.ITEM_CODE ||
                                      '，仓库编码=' ||
                                      R_PARAM_HEAD.FINANCE_INV_CODE;
                        PKG_PLN_INV_OCCUPY.P_AFFIRM_OCCUPY_STOCKS(P_INVENTORY_ID      => R_CUST_SO_HEAD_INTF.SHIP_INV_ID,
                                                                  P_ITEM_ID           => R_CUST_SO_LINE_INTF.ITEM_ID,
                                                                  P_OCCUPY_QTY        => R_CUST_SO_LINE_INTF.ITEM_QTY,
                                                                  P_MATCH_PLN_TO_WIP  => 'A',
                                                                  P_ACTION_DESC       => '销售单' ||
                                                                                         R_PARAM_HEAD.SOURCE_ORDER_NUMBER ||
                                                                                         '转采购生成发运计划',
                                                                  P_ENTITY_ID         => R_CUST_SO_HEAD_INTF.ENTITY_ID,
                                                                  P_ORIGIN_TYPE       => '销售转采购',
                                                                  P_ORIGIN_HEAD_ID    => R_CUST_SO_HEAD_INTF.SRC_BILL_ID,
                                                                  P_ORIGIN_NUMBER     => R_CUST_SO_HEAD_INTF.SRC_BILL_NUM,
                                                                  P_ORIGIN_LINE_ID    => R_CUST_SO_LINE_INTF.SRC_LINE_ID,
                                                                  P_SOURCE_ORDER_TYPE => R_SO_HEAD.BILL_TYPE_NAME,
                                                                  P_SOURCE_HEAD_ID    => R_SO_HEAD.SO_HEADER_ID,
                                                                  P_SOURCE_NUMBER     => R_SO_HEAD.SO_NUM,
                                                                  P_SOURCE_LINE_ID    => R_PARAM_LINE.SOURCE_LINE_ID,
                                                                  P_USER_CODE         => IN_USER_CODE,
                                                                  P_RESULT            => OUT_ERR_NUM,
                                                                  P_ERR_MSG           => OUT_RESULT);
                      END IF;
                    
                      --插入接口行
                      IF OUT_RESULT = V_SUCCESS THEN
                        V_IN_PARAM := '插入销售单接口行表';
                        PKG_SO_BIZ.P_SO_CREATE_INTF_LINE(P_SO_INTF_LINE => R_CUST_SO_LINE_INTF,
                                                         P_USER_CODE    => IN_USER_CODE,
                                                         P_RESULT       => OUT_ERR_NUM,
                                                         P_ERR_MSG      => OUT_RESULT);
                      END IF; --插入接口行end
                    END IF; --实收数量大于0end
                  END IF; --不同套件编码end
                
                  IF OUT_RESULT <> V_SUCCESS THEN
                    EXIT;
                  END IF;
                END LOOP; --处理接口行end
              END IF; --处理接口行end
            
              --如果是自提、无来源客户提货订单、转采购销售单无直发客户，需先做款项锁定处理
              /*IF OUT_RESULT = V_SUCCESS THEN
                IF \*R_CUST_SO_HEAD_INTF.SELF_PICK_FLAG = V_YES
                                  AND*\
                 R_PLN_LG_ORDER.ORDER_HEAD_ID IS NULL AND
                 R_SO_HEAD.TRANSFER_ACCOUNT_ID IS NULL THEN
                  V_IN_PARAM := '营销大类=' ||
                                R_CUST_SO_HEAD_INTF.SALES_MAIN_TYPE || V_NL ||
                                '客户ID=' ||
                                TO_CHAR(R_CUST_SO_HEAD_INTF.CUSTOMER_ID) ||
                                ',客户编码=' ||
                                R_CUST_SO_HEAD_INTF.CUSTOMER_CODE || V_NL ||
                                '账户ID=' ||
                                TO_CHAR(R_CUST_SO_HEAD_INTF.ACCOUNT_ID) ||
                                ',账户编码=' ||
                                R_CUST_SO_HEAD_INTF.ACCOUNT_CODE;
                  --调用信用控制过程
                  PKG_CREDIT_ACCOUNT_CONTROL.PRC_CREDIT_ORDER_BILL(P_ENTITY_ID       => R_CUST_SO_HEAD_INTF.ENTITY_ID,
                                                                   P_ACTION_TYPE     => 1, --锁定信用
                                                                   P_SETTLEMENT_SUM  => V_SUM_AMOUNT,
                                                                   P_DISCOUNT_SUM    => V_SUM_DIS_AMOUNT,
                                                                   P_SALES_MAIN_TYPE => R_CUST_SO_HEAD_INTF.SALES_MAIN_TYPE,
                                                                   P_ACCOUNT_ID      => R_CUST_SO_HEAD_INTF.ACCOUNT_ID,
                                                                   P_CUSTOMER_ID     => R_CUST_SO_HEAD_INTF.CUSTOMER_ID,
                                                                   P_PROJ_NUMBER     => NULL,
                                                                   P_ORDER_ID        => R_SO_HEAD.SO_HEADER_ID,
                                                                   P_ORDER_TYPE      => R_SO_HEAD.BILL_TYPE_NAME,
                                                                   P_USERNAME        => IN_USER_CODE,
                                                                   P_RESULT          => OUT_ERR_NUM,
                                                                   P_ERR_MSG         => OUT_RESULT,
                                                                   IS_DISCOUNT_TYPE  => R_CUST_SO_HEAD_INTF.DISCOUNT_TYPE --ADD BY LIZHEN 2017-08-08
                                                                   );
                  --折扣类型处理
                  IF OUT_RESULT = V_SUCCESS THEN
                    IF R_CUST_SO_HEAD_INTF.DISCOUNT_TYPE =
                       DISCOUNT_TYPE_DISCOUNT THEN
                      V_IN_PARAM := '营销大类=' ||
                                    R_CUST_SO_HEAD_INTF.SALES_MAIN_TYPE || V_NL ||
                                    '客户ID=' ||
                                    TO_CHAR(R_CUST_SO_HEAD_INTF.CUSTOMER_ID) ||
                                    ',客户编码=' ||
                                    R_CUST_SO_HEAD_INTF.CUSTOMER_CODE || V_NL ||
                                    '账户ID=' ||
                                    TO_CHAR(R_CUST_SO_HEAD_INTF.ACCOUNT_ID) ||
                                    ',账户编码=' ||
                                    R_CUST_SO_HEAD_INTF.ACCOUNT_CODE || V_NL ||
                                    '折扣类型=' ||
                                    R_CUST_SO_HEAD_INTF.DISCOUNT_TYPE;
                      PKG_CREDIT_DIS.P_CHECK_DIS_AMOUNT(IN_ACTION_TYPE     => 1,
                                                        IN_ENTITY_ID       => R_CUST_SO_HEAD_INTF.ENTITY_ID,
                                                        IN_ACCOUNT_ID      => R_CUST_SO_HEAD_INTF.ACCOUNT_ID,
                                                        IS_SOURCE_TYPE     => '12', --快码 SO_SRC_TYPE
                                                        IN_SOURCE_BILL_ID  => R_SO_HEAD.SO_HEADER_ID,
                                                        IS_SALES_MAIN_TYPE => R_CUST_SO_HEAD_INTF.SALES_MAIN_TYPE,
                                                        IS_DISCOUNT_TYPE   => R_CUST_SO_HEAD_INTF.DISCOUNT_TYPE,
                                                        IN_AMOUNT          => V_SUM_AMOUNT,
                                                        IS_USER_NAME       => IN_USER_CODE,
                                                        IS_ATTRIB01        => NULL,
                                                        IS_ATTRIB02        => NULL,
                                                        ON_RESULT          => OUT_ERR_NUM,
                                                        OS_MESSAGE         => OUT_RESULT,
                                                        OS_ATTRIB01        => V_OS_ATTRIB01,
                                                        OS_ATTRIB02        => V_OS_ATTRIB02);
                      IF OUT_RESULT <> V_SUCCESS THEN
                        OUT_RESULT := '检查并锁定折扣类型金额失败，请检查折扣类型余额是否足够！' || V_NL ||
                                      OUT_RESULT;
                      END IF;
                    END IF;
                  ELSE
                    OUT_RESULT := '检查并锁定客户款项失败，请检查客户余款是否足够！' || V_NL ||
                                  OUT_RESULT;
                  END IF;
                END IF;
              END IF;*/
            
              --如果有来源提货订单且送审锁款的，需按订金做款项处理
              /*IF OUT_RESULT = V_SUCCESS AND
                 R_PLN_LG_ORDER.LOCK_AMOUNT_FLAG = 'S' THEN
                IF NVL(V_SUM_AMOUNT, 0) + NVL(V_SUM_DIS_AMOUNT, 0) <> 0 THEN
                  V_IN_PARAM := '营销大类=' ||
                                R_CUST_SO_HEAD_INTF.SALES_MAIN_TYPE || V_NL ||
                                '客户ID=' ||
                                TO_CHAR(R_CUST_SO_HEAD_INTF.CUSTOMER_ID) ||
                                ',客户编码=' ||
                                R_CUST_SO_HEAD_INTF.CUSTOMER_CODE || V_NL ||
                                '账户ID=' ||
                                TO_CHAR(R_CUST_SO_HEAD_INTF.ACCOUNT_ID) ||
                                ',账户编码=' ||
                                R_CUST_SO_HEAD_INTF.ACCOUNT_CODE;
                  PKG_CREDIT_ACCOUNT_CONTROL.PRC_CREDIT_ORDER_BILL(P_ENTITY_ID       => R_CUST_SO_HEAD_INTF.ENTITY_ID,
                                                                   P_ACTION_TYPE     => 28,
                                                                   P_SETTLEMENT_SUM  => NVL(V_SUM_AMOUNT,
                                                                                            0),
                                                                   P_DISCOUNT_SUM    => NVL(V_SUM_DIS_AMOUNT,
                                                                                            0),
                                                                   P_SALES_MAIN_TYPE => R_CUST_SO_HEAD_INTF.SALES_MAIN_TYPE,
                                                                   P_ACCOUNT_ID      => R_CUST_SO_HEAD_INTF.ACCOUNT_ID,
                                                                   P_CUSTOMER_ID     => R_CUST_SO_HEAD_INTF.CUSTOMER_ID,
                                                                   P_PROJ_NUMBER     => NULL,
                                                                   P_ORDER_ID        => R_PLN_LG_ORDER.ORDER_HEAD_ID,
                                                                   P_ORDER_TYPE      => R_PLN_LG_ORDER.ORDER_TYPE_CODE,
                                                                   P_USERNAME        => IN_USER_CODE,
                                                                   P_RESULT          => OUT_ERR_NUM,
                                                                   P_ERR_MSG         => OUT_RESULT,
                                                                   IS_DISCOUNT_TYPE  => R_CUST_SO_HEAD_INTF.DISCOUNT_TYPE --ADD BY LIZHEN 2017-08-08
                                                                   );
                  IF OUT_RESULT <> V_SUCCESS THEN
                    OUT_RESULT := '解锁订金，检查并锁定资金失败！' || V_NL || OUT_RESULT;
                  END IF;
                
                  --20170731 折让到款折扣类型处理
                  IF OUT_RESULT = V_SUCCESS THEN
                    IF R_CUST_SO_HEAD_INTF.DISCOUNT_TYPE =
                       DISCOUNT_TYPE_DISCOUNT THEN
                      V_IN_PARAM := '营销大类=' ||
                                    R_CUST_SO_HEAD_INTF.SALES_MAIN_TYPE || V_NL ||
                                    '客户ID=' ||
                                    TO_CHAR(R_CUST_SO_HEAD_INTF.CUSTOMER_ID) ||
                                    ',客户编码=' ||
                                    R_CUST_SO_HEAD_INTF.CUSTOMER_CODE || V_NL ||
                                    '账户ID=' ||
                                    TO_CHAR(R_CUST_SO_HEAD_INTF.ACCOUNT_ID) ||
                                    ',账户编码=' ||
                                    R_CUST_SO_HEAD_INTF.ACCOUNT_CODE || V_NL ||
                                    '折扣类型=' ||
                                    R_CUST_SO_HEAD_INTF.DISCOUNT_TYPE;
                      PKG_CREDIT_DIS.P_CHECK_DIS_AMOUNT(IN_ACTION_TYPE     => 28,
                                                        IN_ENTITY_ID       => R_CUST_SO_HEAD_INTF.ENTITY_ID,
                                                        IN_ACCOUNT_ID      => R_CUST_SO_HEAD_INTF.ACCOUNT_ID,
                                                        IS_SOURCE_TYPE     => '02', --'12', --快码 SO_SRC_TYPE
                                                        IN_SOURCE_BILL_ID  => R_PLN_LG_ORDER.ORDER_HEAD_ID, --R_SO_HEAD.SO_HEADER_ID,
                                                        IS_SALES_MAIN_TYPE => R_CUST_SO_HEAD_INTF.SALES_MAIN_TYPE,
                                                        IS_DISCOUNT_TYPE   => R_CUST_SO_HEAD_INTF.DISCOUNT_TYPE,
                                                        IN_AMOUNT          => V_SUM_AMOUNT,
                                                        IS_USER_NAME       => IN_USER_CODE,
                                                        IS_ATTRIB01        => NULL,
                                                        IS_ATTRIB02        => NULL,
                                                        ON_RESULT          => OUT_ERR_NUM,
                                                        OS_MESSAGE         => OUT_RESULT,
                                                        OS_ATTRIB01        => V_OS_ATTRIB01,
                                                        OS_ATTRIB02        => V_OS_ATTRIB02);
                      IF OUT_RESULT <> V_SUCCESS THEN
                        OUT_RESULT := '订金处理，折扣类型金额处理失败，请检查折扣类型余额是否足够！' || V_NL ||
                                      OUT_RESULT;
                      END IF;
                    END IF;
                  END IF;
                END IF;
              END IF;*/
            
              --调用销售接口处理过程
              /*IF OUT_RESULT = V_SUCCESS THEN
                V_IN_PARAM := '调用销售单接口过程生成销售单';
                PKG_SO_BIZ.P_SO_GENERATE(P_SO_HEADER_INTERFACE_ID => R_CUST_SO_HEAD_INTF.SO_HEADER_INTERFACE_ID,
                                         P_USER_CODE              => IN_USER_CODE,
                                         P_RESULT                 => OUT_ERR_NUM,
                                         P_ERR_MSG                => OUT_RESULT);
              
                IF OUT_ERR_NUM = 0 THEN
                  --返回0为成功
                  OUT_RESULT := V_SUCCESS;
                END IF;
              END IF;*/
            
              IF OUT_RESULT = v_Success THEN
                IF NOT TV_SPLIT_ORDER.EXISTS(V_TABLE_INDEX) THEN
                  TV_SPLIT_ORDER(V_TABLE_INDEX).SALES_MAIN_TYPE := R_SPLIT.SALES_MAIN_TYPE;
                  TV_SPLIT_ORDER(V_TABLE_INDEX).DISCOUNT_TYPE := R_SPLIT.DISCOUNT_TYPE;
                  TV_SPLIT_ORDER(V_TABLE_INDEX).SUM_AMOUNT := V_SUM_AMOUNT;
                  TV_SPLIT_ORDER(V_TABLE_INDEX).SUM_DIS_AMOUNT := V_SUM_DIS_AMOUNT;
                ELSE
                  TV_SPLIT_ORDER(V_TABLE_INDEX).SUM_AMOUNT := TV_SPLIT_ORDER(V_TABLE_INDEX).SUM_AMOUNT + V_SUM_AMOUNT;
                  TV_SPLIT_ORDER(V_TABLE_INDEX).SUM_DIS_AMOUNT := TV_SPLIT_ORDER(V_TABLE_INDEX).SUM_DIS_AMOUNT + V_SUM_DIS_AMOUNT;
                END IF;
                
                TV_SO_INTF_ID(R_CUST_SO_HEAD_INTF.SO_HEADER_INTERFACE_ID) := R_CUST_SO_HEAD_INTF.SO_HEADER_INTERFACE_ID;
              END IF;
            
              IF OUT_RESULT <> V_SUCCESS THEN
                EXIT;
              END IF;
            END IF;
          END LOOP; --拆单end
          
          --拆单完毕，进行款项处理和生成销售单
          IF OUT_RESULT = V_SUCCESS THEN
            V_TABLE_INDEX := TV_SPLIT_ORDER.FIRST;
            LOOP
              EXIT WHEN V_TABLE_INDEX IS NULL;
              V_SALES_MAIN_TYPE := TV_SPLIT_ORDER(V_TABLE_INDEX).SALES_MAIN_TYPE;
              V_DISCOUNT_TYPE := TV_SPLIT_ORDER(V_TABLE_INDEX).DISCOUNT_TYPE;
              V_SUM_AMOUNT := TV_SPLIT_ORDER(V_TABLE_INDEX).SUM_AMOUNT;
              V_SUM_DIS_AMOUNT := TV_SPLIT_ORDER(V_TABLE_INDEX).SUM_DIS_AMOUNT;
              --如果是自提、无来源客户提货订单、转采购销售单无直发客户，需先做款项锁定处理
              IF R_PLN_LG_ORDER.ORDER_HEAD_ID IS NULL AND R_SO_HEAD.TRANSFER_ACCOUNT_ID IS NULL THEN
                pkg_pln_pub.P_CUSTOMER_AMOUNT_PROCESS(IN_ENTITY_ID       => R_PARAM_HEAD.ENTITY_ID,
                                                      IN_ORDER_TYPE_ID   => -1,
                                                      IN_ORDER_TYPE_CODE => R_SO_HEAD.BILL_TYPE_NAME,
                                                      IN_CUSTOMER_ID     => R_PARAM_HEAD.TRANSFER_CUSTOMER_ID,
                                                      IN_ACCOUNT_ID      => R_PARAM_HEAD.TRANSFER_ACCOUNT_ID,
                                                      IN_SALES_MAIN_TYPE => V_SALES_MAIN_TYPE,
                                                      IN_ACTION_TYPE     => 1,
                                                      IN_SOURCE_TYPE     => '12',
                                                      IN_ORDER_ID        => R_SO_HEAD.SO_HEADER_ID,
                                                      IN_PROJ_NUMBER     => null,
                                                      IN_DISCOUNT_TYPE   => V_DISCOUNT_TYPE,
                                                      IN_AMOUNT          => round(V_SUM_AMOUNT, 2),
                                                      IN_DIS_AMOUNT      => round(V_SUM_DIS_AMOUNT, 2),
                                                      IN_RECORD_ERR      => 'N',
                                                      IN_USER_CODE       => IN_USER_CODE,
                                                      OUT_RESULT         => OUT_RESULT);
                IF OUT_RESULT <> V_SUCCESS THEN
                  OUT_RESULT := '销售转采购（无来源客户提货订单、转采购销售单无直发客户）处理客户款项失败！' || V_NL || OUT_RESULT;
                END IF;
                /*V_IN_PARAM := '营销大类=' || V_SALES_MAIN_TYPE || V_NL ||
                              '客户ID=' || TO_CHAR(R_PARAM_HEAD.TRANSFER_CUSTOMER_ID) ||
                              ',客户编码=' || R_PARAM_HEAD.TRANSFER_CUSTOMER_CODE || V_NL ||
                              '账户ID=' || TO_CHAR(R_PARAM_HEAD.TRANSFER_ACCOUNT_ID) ||
                              ',账户编码=' || R_PARAM_HEAD.TRANSFER_ACCOUNT_CODE;
                --调用信用控制过程
                PKG_CREDIT_ACCOUNT_CONTROL.PRC_CREDIT_ORDER_BILL(P_ENTITY_ID       => R_PARAM_HEAD.ENTITY_ID,
                                                                 P_ACTION_TYPE     => 1, --锁定信用
                                                                 P_SETTLEMENT_SUM  => round(V_SUM_AMOUNT, 2),
                                                                 P_DISCOUNT_SUM    => round(V_SUM_DIS_AMOUNT, 2),
                                                                 P_SALES_MAIN_TYPE => V_SALES_MAIN_TYPE,
                                                                 P_ACCOUNT_ID      => R_PARAM_HEAD.TRANSFER_ACCOUNT_ID,
                                                                 P_CUSTOMER_ID     => R_PARAM_HEAD.TRANSFER_CUSTOMER_ID,
                                                                 P_PROJ_NUMBER     => NULL,
                                                                 P_ORDER_ID        => R_SO_HEAD.SO_HEADER_ID,
                                                                 P_ORDER_TYPE      => R_SO_HEAD.BILL_TYPE_NAME,
                                                                 P_USERNAME        => IN_USER_CODE,
                                                                 P_RESULT          => OUT_ERR_NUM,
                                                                 P_ERR_MSG         => OUT_RESULT,
                                                                 IS_DISCOUNT_TYPE  => V_DISCOUNT_TYPE --ADD BY LIZHEN 2017-08-08
                                                                 );
                --折扣类型处理
                IF OUT_RESULT = V_SUCCESS THEN
                  IF V_DISCOUNT_TYPE = DISCOUNT_TYPE_DISCOUNT THEN
                    V_IN_PARAM := '营销大类=' || V_SALES_MAIN_TYPE || V_NL ||
                                  '客户ID=' || TO_CHAR(R_PARAM_HEAD.TRANSFER_CUSTOMER_ID) ||
                                  ',客户编码=' || R_PARAM_HEAD.TRANSFER_CUSTOMER_CODE || V_NL ||
                                  '账户ID=' || TO_CHAR(R_PARAM_HEAD.TRANSFER_ACCOUNT_ID) ||
                                  ',账户编码=' || R_PARAM_HEAD.TRANSFER_ACCOUNT_CODE || V_NL ||
                                  '折扣类型=' || V_DISCOUNT_TYPE;
                    PKG_CREDIT_DIS.P_CHECK_DIS_AMOUNT(IN_ACTION_TYPE     => 1,
                                                      IN_ENTITY_ID       => R_PARAM_HEAD.ENTITY_ID,
                                                      IN_ACCOUNT_ID      => R_PARAM_HEAD.TRANSFER_ACCOUNT_ID,
                                                      IS_SOURCE_TYPE     => '12', --快码 SO_SRC_TYPE
                                                      IN_SOURCE_BILL_ID  => R_SO_HEAD.SO_HEADER_ID,
                                                      IS_SALES_MAIN_TYPE => V_SALES_MAIN_TYPE,
                                                      IS_DISCOUNT_TYPE   => V_DISCOUNT_TYPE,
                                                      IN_AMOUNT          => round(V_SUM_AMOUNT, 2),
                                                      IS_USER_NAME       => IN_USER_CODE,
                                                      IS_ATTRIB01        => NULL,
                                                      IS_ATTRIB02        => NULL,
                                                      ON_RESULT          => OUT_ERR_NUM,
                                                      OS_MESSAGE         => OUT_RESULT,
                                                      OS_ATTRIB01        => V_OS_ATTRIB01,
                                                      OS_ATTRIB02        => V_OS_ATTRIB02);
                    IF OUT_RESULT <> V_SUCCESS THEN
                      OUT_RESULT := '检查并锁定折扣类型金额失败，请检查折扣类型余额是否足够！' || V_NL || OUT_RESULT;
                    END IF;
                  END IF;
                ELSE
                  OUT_RESULT := '检查并锁定客户款项失败，请检查客户余款是否足够！' || V_NL || OUT_RESULT;
                END IF;*/
              END IF;
              
              --如果有来源提货订单且送审锁款的，需按订金做款项处理
              IF OUT_RESULT = V_SUCCESS AND R_PLN_LG_ORDER.LOCK_AMOUNT_FLAG = V_LOCK_AMOUNT_FLAG_S AND NVL(v_Hq_Affirm_Lock_Full_Amount, 'N') <> 'Y' THEN
                pkg_pln_pub.P_CUSTOMER_AMOUNT_PROCESS(IN_ENTITY_ID       => R_PARAM_HEAD.ENTITY_ID,
                                                      IN_ORDER_TYPE_ID   => R_PLN_LG_ORDER.ORDER_TYPE_ID,
                                                      IN_ORDER_TYPE_CODE => R_PLN_LG_ORDER.ORDER_TYPE_CODE,
                                                      IN_CUSTOMER_ID     => R_PARAM_HEAD.TRANSFER_CUSTOMER_ID,
                                                      IN_ACCOUNT_ID      => R_PARAM_HEAD.TRANSFER_ACCOUNT_ID,
                                                      IN_SALES_MAIN_TYPE => V_SALES_MAIN_TYPE,
                                                      IN_ACTION_TYPE     => 28,
                                                      IN_SOURCE_TYPE     => '02',
                                                      IN_ORDER_ID        => R_PLN_LG_ORDER.ORDER_HEAD_ID,
                                                      IN_PROJ_NUMBER     => null,
                                                      IN_DISCOUNT_TYPE   => V_DISCOUNT_TYPE,
                                                      IN_AMOUNT          => round(V_SUM_AMOUNT, 2),
                                                      IN_DIS_AMOUNT      => round(V_SUM_DIS_AMOUNT, 2),
                                                      IN_RECORD_ERR      => 'N',
                                                      IN_USER_CODE       => IN_USER_CODE,
                                                      OUT_RESULT         => OUT_RESULT);
                IF OUT_RESULT <> V_SUCCESS THEN
                  OUT_RESULT := '销售转采购（有来源提货订单直发生成销售单）处理客户款项失败！' || V_NL || OUT_RESULT;
                END IF;
                /*IF NVL(V_SUM_AMOUNT, 0) + NVL(V_SUM_DIS_AMOUNT, 0) <> 0 THEN
                  V_IN_PARAM := '营销大类=' || V_SALES_MAIN_TYPE || V_NL ||
                                '客户ID=' || TO_CHAR(R_PARAM_HEAD.TRANSFER_CUSTOMER_ID) ||
                                ',客户编码=' || R_PARAM_HEAD.TRANSFER_CUSTOMER_CODE || V_NL ||
                                '账户ID=' || TO_CHAR(R_PARAM_HEAD.TRANSFER_ACCOUNT_ID) ||
                                ',账户编码=' || R_PARAM_HEAD.TRANSFER_ACCOUNT_CODE;
                  PKG_CREDIT_ACCOUNT_CONTROL.PRC_CREDIT_ORDER_BILL(P_ENTITY_ID       => R_PARAM_HEAD.ENTITY_ID,
                                                                   P_ACTION_TYPE     => 28,
                                                                   P_SETTLEMENT_SUM  => round(NVL(V_SUM_AMOUNT, 0), 2),
                                                                   P_DISCOUNT_SUM    => round(NVL(V_SUM_DIS_AMOUNT, 0), 2),
                                                                   P_SALES_MAIN_TYPE => V_SALES_MAIN_TYPE,
                                                                   P_ACCOUNT_ID      => R_PARAM_HEAD.TRANSFER_ACCOUNT_ID,
                                                                   P_CUSTOMER_ID     => R_PARAM_HEAD.TRANSFER_CUSTOMER_ID,
                                                                   P_PROJ_NUMBER     => NULL,
                                                                   P_ORDER_ID        => R_PLN_LG_ORDER.ORDER_HEAD_ID,
                                                                   P_ORDER_TYPE      => R_PLN_LG_ORDER.ORDER_TYPE_CODE,
                                                                   P_USERNAME        => IN_USER_CODE,
                                                                   P_RESULT          => OUT_ERR_NUM,
                                                                   P_ERR_MSG         => OUT_RESULT,
                                                                   IS_DISCOUNT_TYPE  => V_DISCOUNT_TYPE --ADD BY LIZHEN 2017-08-08
                                                                   );
                  IF OUT_RESULT <> V_SUCCESS THEN
                    OUT_RESULT := '解锁订金，检查并锁定资金失败！' || V_NL || OUT_RESULT;
                  END IF;
                
                  --20170731 折让到款折扣类型处理
                  IF OUT_RESULT = V_SUCCESS THEN
                    IF V_DISCOUNT_TYPE = DISCOUNT_TYPE_DISCOUNT THEN
                      V_IN_PARAM := '营销大类=' || V_SALES_MAIN_TYPE || V_NL ||
                                    '客户ID=' || TO_CHAR(R_PARAM_HEAD.TRANSFER_CUSTOMER_ID) ||
                                    ',客户编码=' || R_PARAM_HEAD.TRANSFER_CUSTOMER_CODE || V_NL ||
                                    '账户ID=' || TO_CHAR(R_PARAM_HEAD.TRANSFER_ACCOUNT_ID) ||
                                    ',账户编码=' || R_PARAM_HEAD.TRANSFER_ACCOUNT_CODE || V_NL ||
                                    '折扣类型=' || V_DISCOUNT_TYPE;
                      PKG_CREDIT_DIS.P_CHECK_DIS_AMOUNT(IN_ACTION_TYPE     => 28,
                                                        IN_ENTITY_ID       => R_PARAM_HEAD.ENTITY_ID,
                                                        IN_ACCOUNT_ID      => R_PARAM_HEAD.TRANSFER_ACCOUNT_ID,
                                                        IS_SOURCE_TYPE     => '02', --'12', --快码 SO_SRC_TYPE
                                                        IN_SOURCE_BILL_ID  => R_PLN_LG_ORDER.ORDER_HEAD_ID, --R_SO_HEAD.SO_HEADER_ID,
                                                        IS_SALES_MAIN_TYPE => V_SALES_MAIN_TYPE,
                                                        IS_DISCOUNT_TYPE   => V_DISCOUNT_TYPE,
                                                        IN_AMOUNT          => round(V_SUM_AMOUNT, 2),
                                                        IS_USER_NAME       => IN_USER_CODE,
                                                        IS_ATTRIB01        => NULL,
                                                        IS_ATTRIB02        => NULL,
                                                        ON_RESULT          => OUT_ERR_NUM,
                                                        OS_MESSAGE         => OUT_RESULT,
                                                        OS_ATTRIB01        => V_OS_ATTRIB01,
                                                        OS_ATTRIB02        => V_OS_ATTRIB02);
                      IF OUT_RESULT <> V_SUCCESS THEN
                        OUT_RESULT := '订金处理，折扣类型金额处理失败，请检查折扣类型余额是否足够！' || V_NL ||
                                      OUT_RESULT;
                      END IF;
                    END IF;
                  END IF;
                END IF;*/
              END IF;
              
              IF OUT_RESULT = v_Success THEN
                V_TABLE_INDEX := TV_SPLIT_ORDER.NEXT(V_TABLE_INDEX);
              ELSE
                EXIT;
              END IF;
            END LOOP;
          END IF;
          
          --调用销售接口处理过程
          IF OUT_RESULT = V_SUCCESS THEN
            IF TV_SO_INTF_ID.COUNT > 0 THEN --hejy3 有数据才处理
              FOR V_SO_INTF_ID IN TV_SO_INTF_ID.FIRST .. TV_SO_INTF_ID.LAST LOOP
                V_IN_PARAM := '调用销售单接口过程生成销售单';
                PKG_SO_BIZ.P_SO_GENERATE(P_SO_HEADER_INTERFACE_ID => TV_SO_INTF_ID(V_SO_INTF_ID),
                                         P_USER_CODE              => IN_USER_CODE,
                                         P_RESULT                 => OUT_ERR_NUM,
                                         P_ERR_MSG                => OUT_RESULT);
                  
                IF OUT_ERR_NUM = 0 THEN
                  --返回0为成功
                  OUT_RESULT := V_SUCCESS;
                END IF;
                
                IF OUT_RESULT <> v_Success THEN
                  EXIT;
                END IF;
              END LOOP;
            END IF;
          END IF;
        END IF;
      
        --按差异数量取消来源提货订单
        IF OUT_RESULT = V_SUCCESS AND
           R_PLN_LG_ORDER.ORDER_HEAD_ID IS NOT NULL THEN
          V_ASS_ITEM_CODE := '_';
          FOR R_PARAM_LINE IN (SELECT L.*
                                 FROM T_SO_TO_SUPP_PARAM_LINE L
                                WHERE L.PARAM_ID = IN_PARAM_ID
                                ORDER BY L.ASS_ITEM_CODE,
                                         CEIL((NVL(L.FACT_REV_SHATTER_QTY, 0) +
                                         NVL(L.MISSING_QTY, 0) +
                                         NVL(L.REJECTED_QTY, 0))/NVL(L.SUB_ITEM_QTY_SCALE,1)) DESC) --按套件编码、实收数量从小到大排序，只处理第一行数据（实收数量最小）
           LOOP
            IF V_ASS_ITEM_CODE <> R_PARAM_LINE.ASS_ITEM_CODE THEN
              V_ASS_ITEM_CODE := R_PARAM_LINE.ASS_ITEM_CODE;
              IF CEIL((NVL(R_PARAM_LINE.FACT_REV_SHATTER_QTY, 0) +
                 NVL(R_PARAM_LINE.MISSING_QTY, 0) +
                 NVL(R_PARAM_LINE.REJECTED_QTY, 0))/NVL(R_PARAM_LINE.SUB_ITEM_QTY_SCALE,1)) > 0 THEN
                --实收破损数+短少数+拒收数大于0才处理
                V_DIFF_QTY := CEIL((NVL(R_PARAM_LINE.FACT_REV_SHATTER_QTY, 0) +
                              NVL(R_PARAM_LINE.MISSING_QTY, 0) +
                              NVL(R_PARAM_LINE.REJECTED_QTY, 0))/NVL(R_PARAM_LINE.SUB_ITEM_QTY_SCALE,1));
              
                BEGIN
                  SELECT L.*
                    INTO R_PLN_LG_LINE
                    FROM T_PLN_LG_ORDER_LINE L
                   WHERE L.ORDER_HEAD_ID = R_PLN_LG_ORDER.ORDER_HEAD_ID
                     AND L.ITEM_CODE = R_PARAM_LINE.ASS_ITEM_CODE
                     AND NVL(L.SHARE_VENDOR_TYPE, '_') <> 'AGENT';
                
                  --更新提货订单行评审数量
                  UPDATE T_PLN_LG_ORDER_LINE L
                     SET L.TRANSFER_HQ_AFFIRMED_QTY =
                          CASE
                            WHEN R_PLN_LG_ORDER.LOCK_AMOUNT_FLAG IN (V_LOCK_AMOUNT_FLAG_Y, V_LOCK_AMOUNT_FLAG_HQ) THEN
                              GREATEST(NVL(L.TRANSFER_HQ_AFFIRMED_QTY, 0) - V_DIFF_QTY, NVL(L.SENDED_QTY, 0))
                            WHEN R_PLN_LG_ORDER.LOCK_AMOUNT_FLAG = V_LOCK_AMOUNT_FLAG_S AND v_Hq_Affirm_Lock_Full_Amount = 'Y' THEN
                              GREATEST(NVL(L.TRANSFER_HQ_AFFIRMED_QTY, 0) - V_DIFF_QTY, NVL(L.SENDED_QTY, 0))
                            ELSE
                              L.TRANSFER_HQ_AFFIRMED_QTY
                           END,
                         L.CANCEL_QTY       = NVL(L.CANCEL_QTY, 0) +
                                              V_DIFF_QTY,
                         L.LAST_UPDATED_BY  = IN_USER_CODE,
                         L.LAST_UPDATE_DATE = SYSDATE,
                         L.VERSION = NVL(L.VERSION, 0) + 1
                   WHERE L.ORDER_LINE_ID = R_PLN_LG_LINE.ORDER_LINE_ID;
                
                  --按取消数量解锁
                  SELECT DECODE(R_PLN_LG_LINE.PROJECT_ORDER_TYPE,
                                NULL,
                                R_PLN_LG_LINE.LIST_PRICE *
                                (100 - NVL(R_PARAM_LINE.CUST_SO_DISCOUNT_RATE, 0) -
                                NVL(R_PARAM_LINE.CUST_SO_MONTH_DIS_RATE, 0)),
                                R_PLN_LG_LINE.APPLY_LIST_PRICE *
                                (100 - DECODE(V_PRICE_APPLY_USE_DISCOUNT,
                                              'Y',
                                              NVL(R_PARAM_LINE.CUST_SO_DISCOUNT_RATE,
                                                  0),
                                              0) -
                                NVL(R_PARAM_LINE.CUST_SO_MONTH_DIS_RATE, 0))) *
                         V_DIFF_QTY / 100,
                         DECODE(R_PLN_LG_LINE.PROJECT_ORDER_TYPE,
                                NULL,
                                R_PLN_LG_LINE.LIST_PRICE *
                                NVL(R_PARAM_LINE.CUST_SO_DISCOUNT_RATE, 0),
                                R_PLN_LG_LINE.APPLY_LIST_PRICE *
                                DECODE(V_PRICE_APPLY_USE_DISCOUNT,
                                       'Y',
                                       NVL(R_PARAM_LINE.CUST_SO_DISCOUNT_RATE,
                                           0),
                                       0)) * V_DIFF_QTY / 100
                    INTO V_CANCEL_AMOUNT, V_CANCEL_DIS_AMOUNT
                    FROM DUAL;
                  
                  IF OUT_RESULT = V_SUCCESS AND R_PLN_LG_ORDER.CUSTOMIZE_FLAG = 'Y' THEN
                    --校验款项
                    For r_Check_Amount In (--甲方
                                           Select lol.entity_id,
                                                  be.entity_name,
                                                  h.customer_id,
                                                  H.CUSTOMER_CODE,
                                                  h.account_id,
                                                  H.ACCOUNT_CODE,
                                                  nvl(lol.Sales_Main_Type, bi.sales_main_type) Sales_Main_Type,
                                                  Nvl(R_PARAM_LINE.DISCOUNT_TYPE, DISCOUNT_TYPE_COMMON) Discount_Type,                                    
                                                  Sum(Round(V_CANCEL_AMOUNT,2)) apply_Amount,
                                                  Sum(Round(V_CANCEL_DIS_AMOUNT,2)) Discount_Amount
                                             From t_Pln_Lg_Order_Line Lol,
                                                  t_Bd_Item Bi,
                                                  t_pln_lg_order_head h,
                                                  v_bd_entity be
                                            Where lol.order_head_id = h.order_head_id
                                              and Lol.Item_Id = Bi.Item_Id
                                              And Bi.Entity_Id = Lol.Entity_Id
                                              And Lol.Order_Head_Id = R_PLN_LG_LINE.Order_Head_Id
                                              And Lol.Entity_Id = R_PLN_LG_LINE.Entity_Id
                                              and h.entity_id = be.entity_id
                                              and lol.order_line_id = R_PLN_LG_LINE.Order_Line_Id
                                            Group By lol.entity_id,
                                                     be.entity_name,
                                                     h.customer_id,
                                                     h.customer_code,
                                                     h.account_id,
                                                     h.account_code,
                                                     nvl(lol.Sales_Main_Type, bi.sales_main_type),
                                                     Nvl(R_PARAM_LINE.DISCOUNT_TYPE, DISCOUNT_TYPE_COMMON)
                                            ) Loop
                      PKG_CREDIT_ACCOUNT_CONTROL.P_CREDIT_CHECK_AMOUNT(IN_ENTITY_ID       => r_Check_Amount.Entity_Id,
                                                                       IN_CUSTOMER_ID     => r_Check_Amount.Customer_Id,
                                                                       IN_ACCOUNT_ID      => r_Check_Amount.Account_Id,
                                                                       IN_SALES_MAIN_TYPE => r_Check_Amount.Sales_Main_Type,
                                                                       IN_PROJ_NUMBER     => null,
                                                                       IN_AMOUNT_SUM      => r_Check_Amount.Apply_Amount,
                                                                       IN_DISAMOUNT_SUM   => r_Check_Amount.Discount_Amount,
                                                                       IN_DISCOUNT_TYPE   => r_Check_Amount.Discount_Type,
                                                                       IN_USER_ACCOUNT    => IN_USER_CODE,
                                                                       OUT_RESULT         => OUT_ERR_NUM,
                                                                       OUT_ERR_MSG        => OUT_RESULT);
                      IF OUT_ERR_NUM <> 0 THEN
                        OUT_RESULT := '销售转采购（差异数量取消订单）校验客户款项失败！错误提示：'||v_Nl||OUT_RESULT||v_Nl||
                                    '事业部='||r_Check_Amount.entity_name||v_Nl||
                                    '客户ID='||r_Check_Amount.Customer_Id||' 编码='||r_Check_Amount.customer_code||v_Nl||
                                    '账户ID='||r_Check_Amount.Account_Id||' 编码='||r_Check_Amount.account_code||v_Nl||
                                    '营销大类='||r_Check_Amount.Sales_Main_Type||v_Nl||
                                    '折扣类型='||r_Check_Amount.Discount_Type;
                        --raise v_Base_Exception;
                        EXIT;
                      END IF;
                    End Loop;
                    
                    IF OUT_RESULT = V_SUCCESS THEN
                      --锁定款项
                      For r_Check_Amount In (--甲方
                                             Select lol.entity_id,
                                                    be.entity_name,
                                                    h.customer_id,
                                                    H.CUSTOMER_CODE,
                                                    h.account_id,
                                                    H.ACCOUNT_CODE,
                                                    nvl(lol.sales_main_type, bi.sales_main_type) Sales_Main_Type,
                                                    Nvl(r_param_line.Discount_Type, Discount_Type_Common) Discount_Type,
                                                    decode(lol.customize_flag, 'Y', ah.project_code, null) project_code,
                                                    decode(lol.customize_flag, 'Y', 100, lol.down_pay_scale) down_pay_scale,
                                                    h.order_head_id order_id,
                                                    h.order_number order_number,
                                                    '02' src_type,
                                                    Sum(Round(V_CANCEL_AMOUNT,2)) apply_Amount,
                                                    Sum(Round(V_CANCEL_DIS_AMOUNT,2)) Discount_Amount,
                                                    0 dp_apply_Amount,
                                                    0 dp_Discount_Amount
                                               From t_Pln_Lg_Order_Line Lol,
                                                    t_Bd_Item Bi,
                                                    t_pln_lg_order_head h,
                                                    v_bd_entity be,
                                                    t_pg_price_apply_head ah
                                              Where lol.order_head_id = h.order_head_id
                                                and Lol.Item_Id = Bi.Item_Id
                                                And Bi.Entity_Id = Lol.Entity_Id
                                                And Lol.Order_Head_Id = R_PLN_LG_LINE.Order_Head_Id
                                                And Lol.Entity_Id = R_PLN_LG_LINE.Entity_Id
                                                and h.entity_id = be.entity_id
                                                and lol.entity_id = ah.entity_id(+)
                                                and lol.project_order_number = ah.apply_code(+)
                                                and lol.order_line_id = R_PLN_LG_LINE.Order_Line_Id
                                              Group By lol.entity_id,
                                                       be.entity_name,
                                                       h.customer_id,
                                                       h.customer_code,
                                                       h.account_id,
                                                       h.account_code,
                                                       nvl(lol.sales_main_type, bi.sales_main_type),
                                                       Nvl(r_param_line.Discount_Type, Discount_Type_Common),
                                                       decode(lol.customize_flag, 'Y', ah.project_code, null),
                                                       decode(lol.customize_flag, 'Y', 100, lol.down_pay_scale),
                                                       h.order_head_id,
                                                       h.order_number
                                              ) Loop
                        PKG_CREDIT_ACCOUNT_CONTROL.P_CREDIT_LOCK_DETAIL_HAND(IN_ENTITY_ID   => r_Check_Amount.Entity_Id,
                                                                         IN_CUSTOMER_ID     => r_Check_Amount.Customer_Id,
                                                                         IN_ACCOUNT_ID      => r_Check_Amount.Account_Id,
                                                                         IN_SALES_MAIN_TYPE => r_Check_Amount.Sales_Main_Type,
                                                                         IN_PROJ_NUMBER     => r_Check_Amount.project_code,
                                                                         IN_AMOUNT_SUM      => r_Check_Amount.Apply_Amount,
                                                                         IN_DISAMOUNT_SUM   => r_Check_Amount.Discount_Amount,
                                                                         IN_DP_AMOUNT_SUM   => r_Check_Amount.dp_apply_Amount,
                                                                         IN_DP_DISAMOUNT_SUM => r_Check_Amount.dp_Discount_Amount,
                                                                         IN_DISCOUNT_TYPE   => r_Check_Amount.Discount_Type,
                                                                         IN_ORDER_ID        => r_Check_Amount.order_id,
                                                                         IN_ORDER_NUMBER    => r_Check_Amount.order_number,
                                                                         IN_DOWNPAY_RATE    => r_Check_Amount.down_pay_scale,
                                                                         IN_SRC_TYPE        => r_Check_Amount.src_type,
                                                                         IN_USER_ACCOUNT    => IN_USER_CODE,
                                                                         OUT_RESULT         => OUT_ERR_NUM,
                                                                         OUT_ERR_MSG        => OUT_RESULT);
                        IF OUT_ERR_NUM <> 0 THEN
                          OUT_RESULT := '销售转采购（差异数量取消订单）处理客户款项失败！错误提示：'||v_Nl||OUT_RESULT||v_Nl||
                                      '事业部='||r_Check_Amount.entity_name||v_Nl||
                                      '客户ID='||r_Check_Amount.Customer_Id||' 编码='||r_Check_Amount.customer_code||v_Nl||
                                      '账户ID='||r_Check_Amount.Account_Id||' 编码='||r_Check_Amount.account_code||v_Nl||
                                      '营销大类='||r_Check_Amount.Sales_Main_Type||v_Nl||
                                      '折扣类型='||r_Check_Amount.Discount_Type;
                          --raise v_Base_Exception;
                          EXIT;
                        END IF;
                      End Loop;
                    END IF;
                  END IF;
                  
                  IF OUT_RESULT = V_SUCCESS AND R_PLN_LG_ORDER.LOCK_AMOUNT_FLAG IN (V_LOCK_AMOUNT_FLAG_Y, V_LOCK_AMOUNT_FLAG_HQ, V_LOCK_AMOUNT_FLAG_S)
                    AND NVL(R_PLN_LG_ORDER.CUSTOMIZE_FLAG, 'N') = 'N' THEN
                    IF R_PLN_LG_ORDER.LOCK_AMOUNT_FLAG IN (V_LOCK_AMOUNT_FLAG_HQ) OR
                      (R_PLN_LG_ORDER.LOCK_AMOUNT_FLAG = V_LOCK_AMOUNT_FLAG_S AND v_Hq_Affirm_Lock_Full_Amount = 'Y') THEN
                      V_ACTION_TYPE := 29;
                      PKG_PLN_PUB.P_CUSTOMER_AMOUNT_PROCESS(IN_ENTITY_ID       => R_PLN_LG_ORDER.ENTITY_ID,
                                                            IN_ORDER_TYPE_ID   => R_PLN_LG_ORDER.ORDER_TYPE_ID,
                                                            IN_ORDER_TYPE_CODE => R_PLN_LG_ORDER.ORDER_TYPE_CODE,
                                                            IN_CUSTOMER_ID     => R_PLN_LG_ORDER.CUSTOMER_ID,
                                                            IN_ACCOUNT_ID      => R_PLN_LG_ORDER.ACCOUNT_ID,
                                                            IN_SALES_MAIN_TYPE => R_PLN_LG_LINE.SALES_MAIN_TYPE,
                                                            IN_ACTION_TYPE     => V_ACTION_TYPE,
                                                            IN_SOURCE_TYPE     => '02',
                                                            IN_ORDER_ID        => R_PLN_LG_ORDER.ORDER_HEAD_ID,
                                                            IN_PROJ_NUMBER     => NULL,
                                                            IN_DISCOUNT_TYPE   => NVL(R_PARAM_LINE.DISCOUNT_TYPE, DISCOUNT_TYPE_COMMON),
                                                            IN_AMOUNT          => ROUND(V_CANCEL_AMOUNT, 2),
                                                            IN_DIS_AMOUNT      => ROUND(V_CANCEL_DIS_AMOUNT, 2),
                                                            IN_RECORD_ERR      => 'N',
                                                            IN_USER_CODE       => IN_USER_CODE,
                                                            OUT_RESULT         => OUT_RESULT);
                    END IF;
                    
                    IF OUT_RESULT = V_SUCCESS THEN
                      V_ACTION_TYPE := 2;
                      PKG_PLN_PUB.P_CUSTOMER_AMOUNT_PROCESS(IN_ENTITY_ID       => R_PLN_LG_ORDER.ENTITY_ID,
                                                            IN_ORDER_TYPE_ID   => R_PLN_LG_ORDER.ORDER_TYPE_ID,
                                                            IN_ORDER_TYPE_CODE => R_PLN_LG_ORDER.ORDER_TYPE_CODE,
                                                            IN_CUSTOMER_ID     => R_PLN_LG_ORDER.CUSTOMER_ID,
                                                            IN_ACCOUNT_ID      => R_PLN_LG_ORDER.ACCOUNT_ID,
                                                            IN_SALES_MAIN_TYPE => R_PLN_LG_LINE.SALES_MAIN_TYPE,
                                                            IN_ACTION_TYPE     => V_ACTION_TYPE,
                                                            IN_SOURCE_TYPE     => '02',
                                                            IN_ORDER_ID        => R_PLN_LG_ORDER.ORDER_HEAD_ID,
                                                            IN_PROJ_NUMBER     => NULL,
                                                            IN_DISCOUNT_TYPE   => NVL(R_PARAM_LINE.DISCOUNT_TYPE, DISCOUNT_TYPE_COMMON),
                                                            IN_AMOUNT          => ROUND(V_CANCEL_AMOUNT, 2),
                                                            IN_DIS_AMOUNT      => ROUND(V_CANCEL_DIS_AMOUNT, 2),
                                                            IN_RECORD_ERR      => 'N',
                                                            IN_USER_CODE       => IN_USER_CODE,
                                                            OUT_RESULT         => OUT_RESULT);
                    END IF;
                    
                    IF OUT_RESULT <> V_SUCCESS THEN
                      OUT_RESULT := '销售转采购（差异数量取消订单）处理客户款项失败！' || V_NL || OUT_RESULT;
                    END IF;
                  END IF;
                
                  --批文锁定处理
                  IF OUT_RESULT = V_SUCCESS AND
                     R_PLN_LG_LINE.PROJECT_ORDER_TYPE IS NOT Null And nvl(r_pln_lg_line.price_apply_id,-1) <> -1 THEN
                    V_IN_PARAM := '单据号=' || R_PLN_LG_ORDER.ORDER_NUMBER || V_NL ||
                                  '批文号=' ||
                                  R_PLN_LG_LINE.PROJECT_ORDER_NUMBER || V_NL ||
                                  '产品编码=' || R_PLN_LG_LINE.ITEM_CODE || V_NL ||
                                  '批文行ID=' ||
                                  TO_CHAR(R_PLN_LG_LINE.PROJECT_ORDER_LINE_ID);
                    PKG_BD_PRICE.P_APPLY_UNLOCK(P_APPLY_DETAIL_ID => R_PLN_LG_LINE.PROJECT_ORDER_LINE_ID, --批文明细ID
                                                P_UNLOCK_CNT      => V_DIFF_QTY, --解除锁定数量
                                                P_BILL_NO         => R_PLN_LG_ORDER.ORDER_NUMBER, --关联单号
                                                P_RETURN_CODE     => V_RESULT, --返回编码，1成功，0失败
                                                P_RETURN_MSG      => OUT_RESULT);
                    IF V_RESULT = '1' THEN
                      OUT_RESULT := V_SUCCESS;
                    END IF;
                  END IF;
                
                  IF OUT_RESULT = V_SUCCESS THEN
                    BEGIN
                      V_IN_PARAM := '写入评审明细';
                      INSERT INTO T_PLN_ORDER_REVIEW_INFO
                        (ENTITY_ID, --业务主体
                         ORDER_REVIEW_ID, --订单评审记录ID
                         LOT_NUM, --批次（用于记录订单评审第几次）
                         ORDER_PERIOD, --订单周期（汇总的订单评审，记录订单周期）
                         SOURCE_ORDER_TYPE_ID, --源订单类型ID
                         ORDER_TYPE_ID, --订单类型ID
                         ORDER_STATE, --订单状态（送审、汇总、库评、产地分解等）
                         ORDER_TYPE_NAME, --订单类型名称
                         ORDER_NUMBER, --订单号（单单评审，记录订单号）
                         HQ_DATE, --总部评审日期
                         HQ_USER, --总部评审人员
                         REMARK, --备注
                         CREATED_BY, --创建人
                         CREATION_DATE, --创建日期
                         LAST_UPDATED_BY, --最后修改人
                         LAST_UPDATE_DATE, --最后修改日期
                         PRE_FIELD_01, --预留字段1
                         PRE_FIELD_02, --预留字段2
                         PRE_FIELD_03, --预留字段3
                         PRE_FIELD_04, --预留字段4
                         PRE_FIELD_05, --预留字段5
                         PRE_FIELD_06, --预留字段6
                         ORIGIN_ORDER_HEAD_ID, --来源订单头ID
                         ORIGIN_ORDER_LINE_ID, --来源订单行ID
                         ITEM_ID, --产品ID
                         ITEM_CODE, --产品编码
                         ITEM_NAME, --产品描述
                         AFFIRM_QTY, --评审数量
                         RECEIVE_INVENTORY_ID, --收货仓库ID
                         SEND_INVENTORY_ID, --发货仓库ID
                         IS_CANCEL_DIRECT_SEND,
                         CHECKUP_CONTENT, --评审意见  add by lilh6 160909
                         CUSTOMER_ORDER_NUMBER, --客户订单号 add by lilh6 160909
                         CONSIGNEE_ADDR_NAME --收货地址 add by lilh6 160920
                         )
                      VALUES
                        (R_PLN_LG_ORDER.ENTITY_ID, --业务主体
                         S_PLN_ORDER_REVIEW_INFO.NEXTVAL, --订单评审记录ID
                         (SELECT COUNT(1)
                            FROM T_PLN_ORDER_REVIEW_INFO RI
                           WHERE RI.ORIGIN_ORDER_HEAD_ID =
                                 R_PLN_LG_ORDER.ORDER_HEAD_ID
                             AND RI.ORIGIN_ORDER_LINE_ID =
                                 R_PLN_LG_LINE.ORDER_LINE_ID) + 1, --批次（用于记录订单评审第几次）
                         NULL, --订单周期（汇总的订单评审，记录订单周期）
                         1, --源订单类型ID
                         R_PLN_LG_ORDER.ORDER_TYPE_ID, --订单类型ID
                         R_PLN_LG_ORDER.ORDER_HEAD_STATE, --订单状态（送审、汇总、库评、产地分解等）
                         R_PLN_LG_ORDER.ORDER_TYPE_NAME, --订单类型名称
                         R_PLN_LG_ORDER.ORDER_NUMBER, --订单号（单单评审，记录订单号）
                         TRUNC(SYSDATE), --总部评审日期
                         IN_USER_CODE, --总部评审人员
                         '销售转采购生成销售单，差异数量回写订单取消数量', --备注
                         IN_USER_CODE, --创建人
                         SYSDATE, --创建日期
                         IN_USER_CODE, --最后修改人
                         SYSDATE, --最后修改日期
                         NULL, --Pre_Field_01, --预留字段1
                         NULL, --Pre_Field_02, --预留字段2
                         NULL, --Pre_Field_03, --预留字段3
                         NULL, --Pre_Field_04, --预留字段4
                         NULL, --Pre_Field_05, --预留字段5
                         NULL, --Pre_Field_06, --预留字段6
                         R_PLN_LG_ORDER.ORDER_HEAD_ID, --Origin_Order_Head_Id, --来源订单头ID
                         R_PLN_LG_LINE.ORDER_LINE_ID, --Origin_Order_Line_Id, --来源订单行ID
                         R_PLN_LG_LINE.ITEM_ID, --Item_Id, --产品ID
                         R_PLN_LG_LINE.ITEM_CODE, --Item_Code, --产品编码
                         R_PLN_LG_LINE.ITEM_NAME, --Item_Name, --产品描述
                         (-1) * V_DIFF_QTY, --Affirm_Qty --评审数量
                         NULL, --收货仓库ID
                         NULL, --发货仓库ID
                         'N', --add by xuhongjiu 2016-05-05
                         R_PLN_LG_ORDER.CHECKUP_CONTENT, --评审意见 add by lilh6 160909
                         R_PLN_LG_ORDER.CUSTOMER_ORDER_NUMBER, --客户订单号 add by lilh6 160909
                         R_PLN_LG_ORDER.CONSIGNEE_ADDR_NAME --收货地址 add by lilh6 160920
                         );
                    EXCEPTION
                      WHEN OTHERS THEN
                        OUT_RESULT := '插入评审记录信息失败，失败原因：' || SQLERRM;
                    END;
                  END IF;
                EXCEPTION
                  WHEN NO_DATA_FOUND THEN
                    NULL;
                END;
              END IF; --实收破损数+短少数大于0才处理end
            END IF;
          
            IF OUT_RESULT <> V_SUCCESS THEN
              EXIT;
            END IF;
          END LOOP;
        END IF;
      
        --更新提货订单状态
        IF OUT_RESULT = V_SUCCESS THEN
          IF R_PLN_LG_ORDER.ORDER_HEAD_ID IS NOT NULL THEN
            SELECT SUM(NVL(L.CENTER_AFFIRM_QUANTITY, L.QUANTITY)),
                   SUM(L.AFFIRMED_QUANTITY),
                   SUM(L.CANCEL_QTY)
              INTO V_SUM_LG_ORDER_QTY,
                   V_SUM_LG_ORDER_AFFIRMED_QTY,
                   V_SUM_LG_ORDER_CANCEL_QTY
              FROM T_PLN_LG_ORDER_LINE L
             WHERE L.ORDER_HEAD_ID = R_PLN_LG_ORDER.ORDER_HEAD_ID
               AND NVL(L.ORDER_LINE_STATE, 'NORMAL') <> 'CLOSED';
          
            IF NVL(V_SUM_LG_ORDER_AFFIRMED_QTY, 0) +
               NVL(V_SUM_LG_ORDER_CANCEL_QTY, 0) >= V_SUM_LG_ORDER_QTY THEN
              V_LG_ORDER_NEXT_STATE := 23;
            ELSIF NVL(V_SUM_LG_ORDER_AFFIRMED_QTY, 0) = 0 THEN
              V_LG_ORDER_NEXT_STATE := R_PLN_LG_ORDER.ORDER_HEAD_STATE;
            ELSE
              V_LG_ORDER_NEXT_STATE := 1455;
            END IF;
          
            UPDATE T_PLN_LG_ORDER_HEAD H
               SET H.ORDER_HEAD_STATE = V_LG_ORDER_NEXT_STATE,
                   H.CENTER_CHECKUP_DATE = SYSDATE,
                   H.LAST_UPDATED_BY  = IN_USER_CODE,
                   H.LAST_UPDATE_DATE = SYSDATE
             WHERE H.ORDER_HEAD_ID = R_PLN_LG_ORDER.ORDER_HEAD_ID;
          END IF;
        END IF;
      
        --获取销售单号
        IF OUT_RESULT = V_SUCCESS THEN
          /*SELECT TO_CHAR(WM_CONCAT(H.SO_NUM))
            INTO OUT_SO_NUMBER
            FROM T_SO_HEADER H
           WHERE H.RAW_SRC_TYPE = V_SO_SRC_TYPE_31
             AND H.RAW_SRC_BILL_ID = R_SO_HEAD.SO_HEADER_ID
             AND H.RAW_SRC_BILL_NUM = R_SO_HEAD.SO_NUM;*/
          
          FOR R_SO IN (
            SELECT H.SO_HEADER_ID, H.SO_NUM, H.RECEIVE_FLAG
              FROM T_SO_HEADER H
             WHERE H.RAW_SRC_TYPE = V_SO_SRC_TYPE_31
               AND H.RAW_SRC_BILL_ID = R_SO_HEAD.SO_HEADER_ID
               AND H.RAW_SRC_BILL_NUM = R_SO_HEAD.SO_NUM
            ) LOOP
            --非自动转采购的自动签收
            IF NVL(R_PARAM_HEAD.AUTO_RUN_FLAG, 'N') <> 'Y' AND NVL(R_SO.RECEIVE_FLAG, 'N') <> 'Y' THEN
              PKG_SO_INTF.P_SO_AUTO_RECEIVE(P_SO_HEADER_ID => R_SO.SO_HEADER_ID,
                                            P_RESULT       => V_COUNT,
                                            P_ERR_MSG      => OUT_RESULT);
              IF OUT_RESULT <> V_SUCCESS THEN
                EXIT;
              END IF;
            END IF;
            
            IF OUT_SO_NUMBER IS NULL THEN
              OUT_SO_NUMBER := R_SO.SO_NUM;
            ELSE
              OUT_SO_NUMBER := OUT_SO_NUMBER || ',' || R_SO.SO_NUM;
            END IF;
          END LOOP;
        END IF;
      END IF; --自提，直发且非安得接收才处理end
    END IF;
  
    IF OUT_RESULT <> V_SUCCESS THEN
      OUT_SO_NUMBER := NULL; --出错把单号串置成空
      RAISE V_BASE_EXCEPTION;
    ELSE
      IF OUT_SO_NUMBER IS NOT NULL THEN
        UPDATE T_SO_TO_SUPP_PARAM_HEAD H
           SET H.TO_SUPP_MSG = H.TO_SUPP_MSG || '；销售单号：' || OUT_SO_NUMBER
         WHERE H.PARAM_ID = R_PARAM_HEAD.PARAM_ID;
      
        UPDATE T_SO_HEADER H
           SET H.TO_SUPP_MSG = H.TO_SUPP_MSG || '；销售单号：' || OUT_SO_NUMBER
         WHERE H.SO_HEADER_ID = R_PARAM_HEAD.SOURCE_ORDER_ID;
      END IF;
    END IF;
  EXCEPTION
    WHEN V_BASE_EXCEPTION THEN
      ROLLBACK TO SAVEPOINT SP_TO_CUST_SO_USEPARAM;
      OUT_RESULT := '生成客户销售单出错，错误提示：' || OUT_RESULT || V_NL || V_IN_PARAM;
    WHEN OTHERS THEN
      ROLLBACK TO SAVEPOINT SP_TO_CUST_SO_USEPARAM;
      OUT_RESULT := '生成客户销售单出错，错误提示：' || SQLERRM || V_NL || V_IN_PARAM;
  END P_TO_CUST_SO_USEPARAM;

  ---------------------------------------------------------
  --生成代理商客户的发运计划
  --销售单为直发且安得接收
  ---------------------------------------------------------
  PROCEDURE P_TO_CUST_SHIP_PLAN_USEPARAM(IN_ENTITY_ID   IN NUMBER, --主体ID
                                         IN_PARAM_ID    IN NUMBER, --转采购参数表ID
                                         IN_USER_CODE   IN VARCHAR2, --操作用户
                                         OUT_SHIP_BATCH OUT NUMBER, --发运批次ID
                                         OUT_RESULT     IN OUT VARCHAR2) IS
    R_PARAM_HEAD                T_SO_TO_SUPP_PARAM_HEAD%ROWTYPE;
    R_PLN_LG_ORDER              T_PLN_LG_ORDER_HEAD%ROWTYPE;
    R_PLN_LG_LINE               T_PLN_LG_ORDER_LINE%ROWTYPE;
    R_SO_HEAD                   T_SO_HEADER%ROWTYPE; --总部销售单
    V_IN_PARAM                  VARCHAR2(4000);
    R_INTF_LG_SHIP_PLAN         INTF_LG_SHIP_PLAN%ROWTYPE;
    V_ASS_ITEM_CODE             T_SO_TO_SUPP_PARAM_LINE.ASS_ITEM_CODE%TYPE;
    V_ITEM_ID                   T_BD_ITEM.ITEM_ID%TYPE;
    OUT_ERR_NUM                 NUMBER;
    V_USABLE_ITEM_QOH_QTY       NUMBER;
    V_COUNT                     NUMBER;
    V_LG_ORDER_NEXT_STATE       NUMBER; --提货订单下一状态
    V_SUM_LG_ORDER_QTY          NUMBER;
    V_SUM_LG_ORDER_AFFIRMED_QTY NUMBER;
    V_SUM_LG_ORDER_CANCEL_QTY   NUMBER;
    V_SUM_AMOUNT                NUMBER;
    V_SUM_DIS_AMOUNT            NUMBER;
    V_TRANSFER_PRICE_LINE_ID    NUMBER;
    V_RESULT                    VARCHAR2(10);
    V_OS_ATTRIB01               VARCHAR2(1000);
    V_OS_ATTRIB02               VARCHAR2(1000);
  
    V_CANCEL_QTY               NUMBER;
    V_CANCEL_AMOUNT            NUMBER;
    V_CANCEL_DIS_AMOUNT        NUMBER;
    V_PRICE_APPLY_USE_DISCOUNT T_BD_PARAM_LIST.DEFAULT_VALUE%TYPE := 'N'; --20170710 hejy3 价格批文开单使用折扣
    
    TYPE TR_SPLIT_ORDER IS RECORD
    (SALES_MAIN_TYPE VARCHAR2(32),
     DISCOUNT_TYPE VARCHAR2(50),
     SUM_AMOUNT NUMBER,
     SUM_DIS_AMOUNT NUMBER);
    TYPE TT_SPLIT_ORDER IS TABLE OF TR_SPLIT_ORDER INDEX BY VARCHAR2(100);
    TV_SPLIT_ORDER TT_SPLIT_ORDER;
    V_TABLE_INDEX VARCHAR2(100);
    V_SALES_MAIN_TYPE VARCHAR2(100);
    V_DISCOUNT_TYPE VARCHAR2(100);
    v_Hq_Affirm_Lock_Full_Amount t_bd_param_list.default_value%type := 'N';
    V_ACTION_TYPE NUMBER;
  BEGIN
    OUT_RESULT := V_SUCCESS;
    SAVEPOINT SP_TO_CUST_SHIP_PLAN_USEPARAM;
  
    --锁定转采购参数表数据
    V_IN_PARAM := '转采购参数表ID=' || TO_CHAR(IN_PARAM_ID);
    BEGIN
      SELECT *
        INTO R_PARAM_HEAD
        FROM T_SO_TO_SUPP_PARAM_HEAD H
       WHERE H.PARAM_ID = IN_PARAM_ID;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        OUT_RESULT := '传入参数有误，找不到转采购的数据！';
    END;
  
    --获取来源销售单
    IF OUT_RESULT = V_SUCCESS THEN
      V_IN_PARAM := '销售单ID=' || TO_CHAR(R_PARAM_HEAD.SOURCE_ORDER_ID) ||
                    ',销售单号=' || R_PARAM_HEAD.SOURCE_ORDER_NUMBER;
      BEGIN
        SELECT H.*
          INTO R_SO_HEAD
          FROM T_SO_HEADER H
         WHERE H.SO_HEADER_ID = R_PARAM_HEAD.SOURCE_ORDER_ID;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          OUT_RESULT := '找不到转采购的销售单！';
      END;
    END IF;
  
    IF OUT_RESULT = V_SUCCESS THEN
      --直发且安得接收才处理
      IF R_SO_HEAD.DIRECT_SHIP_FLAG = V_YES Or
         R_SO_HEAD.Self_Pick_Flag = V_YES THEN
        IF R_PARAM_HEAD.CUSTOMER_LG_ORDER IS NOT NULL THEN
          V_IN_PARAM := '客户提货订单号=' || R_PARAM_HEAD.CUSTOMER_LG_ORDER;
          BEGIN
            SELECT H.*
              INTO R_PLN_LG_ORDER
              FROM T_PLN_LG_ORDER_HEAD H
             WHERE H.ENTITY_ID = R_PARAM_HEAD.ENTITY_ID
               AND H.ORDER_NUMBER = R_PARAM_HEAD.CUSTOMER_LG_ORDER;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              OUT_RESULT := '无效客户提货订单，请检查';
          END;
        ELSE
          R_PLN_LG_ORDER := NULL;
        END IF;
      
        --20170710 hejy3 获取价格批文开单使用折扣参数
        BEGIN
          V_PRICE_APPLY_USE_DISCOUNT := PKG_BD.F_GET_PARAMETER_VALUE('PLN_PRICE_APPLY_USE_DISCOUNT',
                                                                     R_PARAM_HEAD.ENTITY_ID);
        EXCEPTION
          WHEN OTHERS THEN
            V_PRICE_APPLY_USE_DISCOUNT := 'N';
        END;
        
        --获取参数:销司订单总部评审锁全款
        Begin
          v_Hq_Affirm_Lock_Full_Amount := Pkg_Bd.f_Get_Parameter_Value('PLN_HQ_AFFIRM_LOCK_FULL_AMOUNT',
                                                             R_PARAM_HEAD.Entity_Id);
        Exception
          When Others Then
            OUT_RESULT := '获取销司订单总部评审锁全款参数PLN_HQ_AFFIRM_LOCK_FULL_AMOUNT参数失败！' || v_Nl ||
                          Sqlerrm;
            Raise v_Base_Exception;
        End;
      
        --检查是否需要处理
        SELECT COUNT(1)
          INTO V_COUNT
          FROM (SELECT L.ASS_ITEM_CODE,
                       MIN(FLOOR(L.FACT_REV_GOOD_QTY/NVL(L.SUB_ITEM_QTY_SCALE,1))) MIN_FACT_REV_GOOD_QTY
                  FROM T_SO_TO_SUPP_PARAM_LINE L
                 WHERE L.PARAM_ID = IN_PARAM_ID
                 GROUP BY L.ASS_ITEM_CODE)
         WHERE MIN_FACT_REV_GOOD_QTY > 0;
      
        IF V_COUNT > 0 THEN
          --检查发货仓库是否可销售
          IF OUT_RESULT = V_SUCCESS THEN
            V_IN_PARAM := '仓库ID=' || TO_CHAR(R_PARAM_HEAD.FINANCE_INV_ID) ||
                          ',编码=' || R_PARAM_HEAD.FINANCE_INV_CODE || ',名称=' ||
                          R_PARAM_HEAD.FINANCE_INV_NAME;
            BEGIN
              SELECT I.INVENTORY_ID
                INTO R_INTF_LG_SHIP_PLAN.SHIP_INVENTORY_ID
                FROM T_INV_INVENTORIES I
               WHERE I.INVENTORY_ID = R_PARAM_HEAD.FINANCE_INV_ID
                 AND I.SALES_FLAG = V_YES --可销售
                 AND I.INVENTORY_CATEGORY = V_INVENTORY_CATEGORY_01 --关联仓
                 AND SYSDATE BETWEEN I.BEGIN_DATE AND
                     NVL(I.END_DATE, SYSDATE + 1);
            EXCEPTION
              WHEN OTHERS THEN
                OUT_RESULT := '发货仓库不存在或已失效，请检查仓库设置！' || V_NL ||
                              '仓库需满足条件：销售标志=Y，仓库类别=关联仓';
            END;
          END IF;
        
          --检查客户
          IF OUT_RESULT = V_SUCCESS THEN
            V_IN_PARAM := '客户ID=' ||
                          TO_CHAR(R_PARAM_HEAD.TRANSFER_CUSTOMER_ID) ||
                          ',编码=' || R_PARAM_HEAD.TRANSFER_CUSTOMER_CODE ||
                          ',名称=' || R_PARAM_HEAD.TRANSFER_CUSTOMER_NAME;
            BEGIN
              SELECT H.CUSTOMER_ID,
                     H.CUSTOMER_CODE,
                     H.CUSTOMER_NAME,
                     --H.CUSTOMER_ID,
                     R_SO_HEAD.CONSIGNEE_ADDRESS_ID,
                     H.CUSTOMER_CODE,
                     H.CUSTOMER_NAME
                INTO R_INTF_LG_SHIP_PLAN.CUSTOMER_ID,
                     R_INTF_LG_SHIP_PLAN.CUSTOMER_CODE,
                     R_INTF_LG_SHIP_PLAN.CUSTOMER_NAME,
                     R_INTF_LG_SHIP_PLAN.CONSIGNEE_COMPANY_ID,
                     R_INTF_LG_SHIP_PLAN.CONSIGNEE_COMPANY_CODE,
                     R_INTF_LG_SHIP_PLAN.CONSIGNEE_COMPANY_NAME
                FROM T_CUSTOMER_HEADER H
               WHERE H.CUSTOMER_ID = R_PARAM_HEAD.TRANSFER_CUSTOMER_ID
                 AND H.ACTIVE_FLAG = V_ACTIVE;
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                OUT_RESULT := '客户不存在或已失效，请检查客户设置！';
            END;
          END IF;
        
          --检查客户账户关系
          IF OUT_RESULT = V_SUCCESS THEN
            V_IN_PARAM := '账户ID=' ||
                          TO_CHAR(R_PARAM_HEAD.TRANSFER_ACCOUNT_ID) ||
                          ',编码=' || R_PARAM_HEAD.TRANSFER_ACCOUNT_CODE || V_NL ||
                          '中心ID=' || TO_CHAR(R_PARAM_HEAD.SALES_CENTER_ID) ||
                          ',编码=' || R_PARAM_HEAD.SALES_CENTER_CODE ||
                          ',名称=' || R_PARAM_HEAD.SALES_CENTER_NAME || V_NL ||
                          '客户ID=' ||
                          TO_CHAR(R_PARAM_HEAD.TRANSFER_CUSTOMER_ID) ||
                          ',编码=' || R_PARAM_HEAD.TRANSFER_CUSTOMER_CODE ||
                          ',名称=' || R_PARAM_HEAD.TRANSFER_CUSTOMER_NAME;
            BEGIN
              SELECT S.ACCOUNT_CODE,
                     S.SALES_CENTER_ID,
                     S.SALES_CENTER_CODE,
                     S.SALES_CENTER_NAME
                INTO R_INTF_LG_SHIP_PLAN.ACCOUNT_CODE,
                     R_INTF_LG_SHIP_PLAN.SALES_CENTER_ID,
                     R_INTF_LG_SHIP_PLAN.SALES_CENTER_CODE,
                     R_INTF_LG_SHIP_PLAN.SALES_CENTER_NAME
                FROM V_CUSTOMER_ACCOUNT_SALECENTER S
               WHERE S.ACCOUNT_ID = R_PARAM_HEAD.TRANSFER_ACCOUNT_ID
                 AND S.SALES_CENTER_ID = R_PARAM_HEAD.SALES_CENTER_ID
                 AND S.CUSTOMER_ID = R_PARAM_HEAD.TRANSFER_CUSTOMER_ID
                 AND S.ENTITY_ID = R_PARAM_HEAD.ENTITY_ID
                 AND S.ACTIVE_FLAG = V_ACTIVE
                 AND S.ACCOUNT_STATUS = V_ACCOUNT_ACTIVE;
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                OUT_RESULT := '中心客户账户关系不存在或已失效，请检查账户设置！';
            END;
          END IF;
        
          IF OUT_RESULT = V_SUCCESS THEN
            R_INTF_LG_SHIP_PLAN.ENTITY_ID := R_PARAM_HEAD.ENTITY_ID;
            IF R_PLN_LG_ORDER.ORDER_HEAD_ID IS NOT NULL THEN
              R_INTF_LG_SHIP_PLAN.ORIGIN_ORIGIN_TYPE       := '02';
              R_INTF_LG_SHIP_PLAN.ORIGIN_ORIGIN_ORDER_CODE := R_PLN_LG_ORDER.ORDER_NUMBER;
              R_INTF_LG_SHIP_PLAN.ORIGIN_ORIGIN_HEAD_ID    := R_PLN_LG_ORDER.ORDER_HEAD_ID;
              R_INTF_LG_SHIP_PLAN.SHIP_TYPE                := R_PLN_LG_ORDER.SHIP_TYPE;
              R_INTF_LG_SHIP_PLAN.CUSTOMER_ORDER_NUMBER    := R_PLN_LG_ORDER.CUSTOMER_ORDER_NUMBER;
              R_INTF_LG_SHIP_PLAN.CUSTOMER_CHANNEL_TYPE    := R_PLN_LG_ORDER.CUSTOMER_CHANNEL_TYPE;
              R_INTF_LG_SHIP_PLAN.LG_ORDER_NUMBER          := R_PLN_LG_ORDER.ORDER_NUMBER;
              R_INTF_LG_SHIP_PLAN.IS_CUSG_FLAG := 'N';
              R_INTF_LG_SHIP_PLAN.PICK_FLAG := 'N';
              --直发自提标志
              IF R_PLN_LG_ORDER.DIRECT_SEND_FLAG = 'Y' THEN
                R_INTF_LG_SHIP_PLAN.IS_CUSG_FLAG := 'Y';
                R_INTF_LG_SHIP_PLAN.PICK_FLAG := 'N';
              ELSIF R_PLN_LG_ORDER.CLIENT_CARRY_FLAG = 'Y' THEN
                R_INTF_LG_SHIP_PLAN.PICK_FLAG := 'Y';
                R_INTF_LG_SHIP_PLAN.IS_CUSG_FLAG := 'N';
              END IF;
            ELSE
              R_INTF_LG_SHIP_PLAN.SHIP_TYPE := R_PARAM_HEAD.SHIP_MODE;
            
              R_INTF_LG_SHIP_PLAN.ORIGIN_ORIGIN_TYPE       := NULL;
              R_INTF_LG_SHIP_PLAN.ORIGIN_ORIGIN_ORDER_CODE := NULL;
              R_INTF_LG_SHIP_PLAN.ORIGIN_ORIGIN_HEAD_ID    := NULL;
              --R_INTF_LG_SHIP_PLAN.SHIP_TYPE := NULL;
              R_INTF_LG_SHIP_PLAN.CUSTOMER_ORDER_NUMBER := NULL;
              R_INTF_LG_SHIP_PLAN.CUSTOMER_CHANNEL_TYPE := NULL;
              R_INTF_LG_SHIP_PLAN.LG_ORDER_NUMBER       := NULL;
            END IF;
            R_INTF_LG_SHIP_PLAN.ORIGIN_TYPE       := V_SO_SRC_TYPE_31; --来源类型为31，后续销售开单时根据这个类型需解锁库存
            R_INTF_LG_SHIP_PLAN.ORIGIN_ORDER_NUM  := R_SO_HEAD.SO_NUM;
            R_INTF_LG_SHIP_PLAN.ORIGIN_ORDER_ID   := R_SO_HEAD.SO_HEADER_ID;
            R_INTF_LG_SHIP_PLAN.SHIP_WAY          := R_PARAM_HEAD.SHIP_MODE;
            R_INTF_LG_SHIP_PLAN.LOAD_VEHICLE_TYPE := '01'; --01整车 02零担
            R_INTF_LG_SHIP_PLAN.SETTLEMENT_TYPE   := '00'; --一般结算类型
            IF NVL(R_INTF_LG_SHIP_PLAN.CUSTOMER_CHANNEL_TYPE, '_') <> '15' THEN
              R_INTF_LG_SHIP_PLAN.PICK_FLAG         := V_YES; --转采购生成的发货通知单默认均为自提
            END IF;
            --R_INTF_LG_SHIP_PLAN.PICK_FLAG := V_NO;
            --20170825 hejy3 销售转采购生成的自提发货通知单地址取销售单的地址
            /*R_INTF_LG_SHIP_PLAN.CONSIGNEE_LOCATION_CODE := SP_CONSIGNEE_ADDR_CODE;
            R_INTF_LG_SHIP_PLAN.CONSIGNEE_ADDR := SP_CONSIGNEE_ADDR;
            R_INTF_LG_SHIP_PLAN.CONSIGNEE_COMPANY_ADDR := SP_CONSIGNEE_ADDR;
            R_INTF_LG_SHIP_PLAN.CONSIGNEE_COMPANY_CONTACT_ID := SP_CONSIGNEE_CONTRACT_ID;
            R_INTF_LG_SHIP_PLAN.CONSIGNEE_COMPANY_CONTRACT := SP_CONSIGNEE_CONTRACT_NAME;
            R_INTF_LG_SHIP_PLAN.CONSIGNEE_COMPANY_TEL := SP_CONSIGNEE_CONTRACT_TEL;*/
            SELECT NVL(NVL(NVL(R_SO_HEAD.CONSIGNEE_TOWN_CODE,R_SO_HEAD.CONSIGNEE_DISTRICT_CODE),
                           R_SO_HEAD.CONSIGNEE_CITY_CODE),
                       R_SO_HEAD.CONSIGNEE_PROVINCE_CODE)
              INTO R_INTF_LG_SHIP_PLAN.CONSIGNEE_LOCATION_CODE
              FROM DUAL;
          
            R_INTF_LG_SHIP_PLAN.CONSIGNEE_ADDR               := R_PARAM_HEAD.CONSIGNEE_ADDR;
            R_INTF_LG_SHIP_PLAN.CONSIGNEE_COMPANY_ADDR       := R_PARAM_HEAD.CONSIGNEE_ADDR;
            R_INTF_LG_SHIP_PLAN.CONSIGNEE_COMPANY_CONTACT_ID := 0;
            R_INTF_LG_SHIP_PLAN.CONSIGNEE_COMPANY_CONTRACT   := R_PARAM_HEAD.CONSIGNEE_CONTRACT;
            R_INTF_LG_SHIP_PLAN.CONSIGNEE_COMPANY_TEL        := R_PARAM_HEAD.CONSIGNEE_CONTRACT_TEL;
          
            R_INTF_LG_SHIP_PLAN.SHIP_INFO_DATE       := TRUNC(SYSDATE);
            R_INTF_LG_SHIP_PLAN.REQUIRE_SHIP_DATE    := TRUNC(SYSDATE);
            R_INTF_LG_SHIP_PLAN.REQUIRE_ARRIVE_DATE  := TRUNC(SYSDATE);
            --R_INTF_LG_SHIP_PLAN.IS_CUSG_FLAG         := 'N';
            R_INTF_LG_SHIP_PLAN.STATUS               := '00'; --状态 00：未同步 01：已同步
            R_INTF_LG_SHIP_PLAN.CREATED_BY           := IN_USER_CODE;
            R_INTF_LG_SHIP_PLAN.CREATION_DATE        := SYSDATE;
            R_INTF_LG_SHIP_PLAN.LAST_UPDATED_BY      := IN_USER_CODE;
            R_INTF_LG_SHIP_PLAN.LAST_UPDATE_DATE     := SYSDATE;
            R_INTF_LG_SHIP_PLAN.LOCK_AMOUNT_FLAG     := V_YES;
            R_INTF_LG_SHIP_PLAN.LG_ORDER_REVIEW_FLAG := '04';
            R_INTF_LG_SHIP_PLAN.ORDER_HEAD_REMARKS   := SUBSTRB(R_SO_HEAD.REMARK || ';' || R_PARAM_HEAD.REMARK,
                                                                1,
                                                                240);
            R_INTF_LG_SHIP_PLAN.REMARK               := SUBSTRB(R_SO_HEAD.REMARK || ';' ||
                                                                R_PARAM_HEAD.REMARK ||
                                                                '[总部销售单:' ||
                                                                R_PARAM_HEAD.SOURCE_ORDER_NUMBER || ']',
                                                                1,
                                                                240);
          
            --获取物流批次号
            SELECT S_INTF_LG_BATCH_NUM.NEXTVAL
              INTO R_INTF_LG_SHIP_PLAN.BATCH_DEAL_NUM
              FROM DUAL;
            OUT_SHIP_BATCH := R_INTF_LG_SHIP_PLAN.BATCH_DEAL_NUM;
          END IF;
        
          IF OUT_RESULT = V_SUCCESS THEN
            V_ASS_ITEM_CODE := '_';
            FOR R_PARAM_LINE IN (SELECT *
                                   FROM T_SO_TO_SUPP_PARAM_LINE L
                                  WHERE L.PARAM_ID = IN_PARAM_ID
                                  ORDER BY L.ASS_ITEM_CODE,
                                           FLOOR(NVL(L.FACT_REV_GOOD_QTY, 0)/NVL(L.SUB_ITEM_QTY_SCALE,1))) LOOP
              IF V_ASS_ITEM_CODE <> R_PARAM_LINE.ASS_ITEM_CODE THEN
                --每个套件编码只插入行
                V_ASS_ITEM_CODE := R_PARAM_LINE.ASS_ITEM_CODE;
                IF FLOOR(R_PARAM_LINE.FACT_REV_GOOD_QTY/NVL(R_PARAM_LINE.SUB_ITEM_QTY_SCALE,1)) > 0 THEN
                  --实收正品数大于0才处理
                  --获取套件信息
                  SELECT NVL(R_PARAM_LINE.ASS_ITEM_MAIN_TYPE,
                             BI.SALES_MAIN_TYPE),
                         BI.ITEM_ID,
                         BI.ITEM_CODE,
                         BI.ITEM_NAME,
                         BI.DEFAULTUNIT
                    INTO R_INTF_LG_SHIP_PLAN.SALES_MAIN_TYPE,
                         V_ITEM_ID,
                         R_INTF_LG_SHIP_PLAN.ITEM_CODE,
                         R_INTF_LG_SHIP_PLAN.ITEM_DESC,
                         R_INTF_LG_SHIP_PLAN.ITEM_UOM
                    FROM T_BD_ITEM BI
                   WHERE BI.ENTITY_ID = R_PARAM_LINE.ENTITY_ID
                     AND BI.ITEM_CODE = R_PARAM_LINE.ASS_ITEM_CODE;
                
                  IF OUT_RESULT = V_SUCCESS THEN
                    R_INTF_LG_SHIP_PLAN.ORIGIN_LINE_ID      := R_PARAM_LINE.SOURCE_LINE_ID;
                    R_INTF_LG_SHIP_PLAN.ITEM_QTY            := FLOOR(R_PARAM_LINE.FACT_REV_GOOD_QTY/NVL(R_PARAM_LINE.SUB_ITEM_QTY_SCALE,1));
                    R_INTF_LG_SHIP_PLAN.ITEM_PRICE          := R_PARAM_LINE.CUST_SO_LIST_PRICE;
                    R_INTF_LG_SHIP_PLAN.MONTH_DISCOUNT_RATE := R_PARAM_LINE.CUST_SO_MONTH_DIS_RATE;
                    R_INTF_LG_SHIP_PLAN.DISCOUNT_RATE       := R_PARAM_LINE.CUST_SO_DISCOUNT_RATE;
                    R_INTF_LG_SHIP_PLAN.DISCOUNT_TYPE       := R_PARAM_LINE.DISCOUNT_TYPE;
                    V_SUM_AMOUNT                            := R_INTF_LG_SHIP_PLAN.ITEM_QTY *
                                                               R_INTF_LG_SHIP_PLAN.ITEM_PRICE *
                                                               (100 -
                                                               NVL(R_INTF_LG_SHIP_PLAN.DISCOUNT_RATE,
                                                                    0) -
                                                               NVL(R_INTF_LG_SHIP_PLAN.MONTH_DISCOUNT_RATE,
                                                                    0)) / 100;
                    V_SUM_DIS_AMOUNT                        := R_INTF_LG_SHIP_PLAN.ITEM_QTY *
                                                               R_INTF_LG_SHIP_PLAN.ITEM_PRICE *
                                                               NVL(R_INTF_LG_SHIP_PLAN.DISCOUNT_RATE,
                                                                   0) / 100;
                  END IF;
                
                  --获取提货订单来源行
                  IF OUT_RESULT = V_SUCCESS THEN
                    IF R_PLN_LG_ORDER.ORDER_HEAD_ID IS NOT NULL THEN
                      BEGIN
                        SELECT L.*
                          INTO R_PLN_LG_LINE
                          FROM T_PLN_LG_ORDER_LINE L
                         WHERE L.ORDER_HEAD_ID =
                               R_PLN_LG_ORDER.ORDER_HEAD_ID
                           AND L.ITEM_CODE = R_INTF_LG_SHIP_PLAN.ITEM_CODE
                           AND NVL(L.SHARE_VENDOR_TYPE, '_') <> 'AGENT';
                      
                        R_INTF_LG_SHIP_PLAN.ORIGIN_ORIGIN_LINE_ID := R_PLN_LG_LINE.ORDER_LINE_ID;
                      
                        --更新提货订单行评审数量
                        UPDATE T_PLN_LG_ORDER_LINE L
                           SET L.CENTER_AFFIRMED_QTY = NVL(L.CENTER_AFFIRMED_QTY,
                                                           0) +
                                                       R_INTF_LG_SHIP_PLAN.ITEM_QTY,
                               L.AFFIRMED_QUANTITY   = NVL(L.AFFIRMED_QUANTITY,
                                                           0) +
                                                       R_INTF_LG_SHIP_PLAN.ITEM_QTY,
                               --L.SENDED_QTY = DECODE(R_PLN_LG_ORDER.LOCK_AMOUNT_FLAG, 'Y', NVL(L.SENDED_QTY, 0) + R_PARAM_LINE.FACT_REV_GOOD_QTY, L.SENDED_QTY),
                               L.SENDED_QTY = CASE
                                                WHEN R_PLN_LG_ORDER.LOCK_AMOUNT_FLAG IN (V_LOCK_AMOUNT_FLAG_Y, V_LOCK_AMOUNT_FLAG_HQ) THEN
                                                  NVL(L.SENDED_QTY, 0) + R_INTF_LG_SHIP_PLAN.ITEM_QTY
                                                WHEN R_PLN_LG_ORDER.LOCK_AMOUNT_FLAG = V_LOCK_AMOUNT_FLAG_S AND v_Hq_Affirm_Lock_Full_Amount = 'Y' THEN
                                                  NVL(L.SENDED_QTY, 0) + R_INTF_LG_SHIP_PLAN.ITEM_QTY
                                                ELSE
                                                  L.SENDED_QTY
                                              END,
                               --L.CANCEL_QTY = NVL(L.CANCEL_QTY, 0) + NVL(R_PARAM_LINE.ITEM_QTY, 0) - NVL(R_PARAM_LINE.FACT_REV_GOOD_QTY, 0),
                               L.LAST_UPDATED_BY  = IN_USER_CODE,
                               L.LAST_UPDATE_DATE = SYSDATE,
                               L.VERSION = NVL(L.VERSION, 0) + 1
                         WHERE L.ORDER_LINE_ID =
                               R_INTF_LG_SHIP_PLAN.ORIGIN_ORIGIN_LINE_ID;
                      
                        BEGIN
                          V_IN_PARAM := '写入评审明细';
                          INSERT INTO T_PLN_ORDER_REVIEW_INFO
                            (ENTITY_ID, --业务主体
                             ORDER_REVIEW_ID, --订单评审记录ID
                             LOT_NUM, --批次（用于记录订单评审第几次）
                             ORDER_PERIOD, --订单周期（汇总的订单评审，记录订单周期）
                             SOURCE_ORDER_TYPE_ID, --源订单类型ID
                             ORDER_TYPE_ID, --订单类型ID
                             ORDER_STATE, --订单状态（送审、汇总、库评、产地分解等）
                             ORDER_TYPE_NAME, --订单类型名称
                             ORDER_NUMBER, --订单号（单单评审，记录订单号）
                             HQ_DATE, --总部评审日期
                             HQ_USER, --总部评审人员
                             REMARK, --备注
                             CREATED_BY, --创建人
                             CREATION_DATE, --创建日期
                             LAST_UPDATED_BY, --最后修改人
                             LAST_UPDATE_DATE, --最后修改日期
                             PRE_FIELD_01, --预留字段1
                             PRE_FIELD_02, --预留字段2
                             PRE_FIELD_03, --预留字段3
                             PRE_FIELD_04, --预留字段4
                             PRE_FIELD_05, --预留字段5
                             PRE_FIELD_06, --预留字段6
                             ORIGIN_ORDER_HEAD_ID, --来源订单头ID
                             ORIGIN_ORDER_LINE_ID, --来源订单行ID
                             ITEM_ID, --产品ID
                             ITEM_CODE, --产品编码
                             ITEM_NAME, --产品描述
                             AFFIRM_QTY, --评审数量
                             RECEIVE_INVENTORY_ID, --收货仓库ID
                             SEND_INVENTORY_ID, --发货仓库ID
                             IS_CANCEL_DIRECT_SEND,
                             CHECKUP_CONTENT, --评审意见  add by lilh6 160909
                             CUSTOMER_ORDER_NUMBER, --客户订单号 add by lilh6 160909
                             CONSIGNEE_ADDR_NAME --收货地址 add by lilh6 160920
                             )
                          VALUES
                            (R_PLN_LG_ORDER.ENTITY_ID, --业务主体
                             S_PLN_ORDER_REVIEW_INFO.NEXTVAL, --订单评审记录ID
                             (SELECT COUNT(1)
                                FROM T_PLN_ORDER_REVIEW_INFO RI
                               WHERE RI.ORIGIN_ORDER_HEAD_ID =
                                     R_PLN_LG_ORDER.ORDER_HEAD_ID
                                 AND RI.ORIGIN_ORDER_LINE_ID =
                                     R_PLN_LG_LINE.ORDER_LINE_ID) + 1, --批次（用于记录订单评审第几次）
                             NULL, --订单周期（汇总的订单评审，记录订单周期）
                             1, --源订单类型ID
                             R_PLN_LG_ORDER.ORDER_TYPE_ID, --订单类型ID
                             R_PLN_LG_ORDER.ORDER_HEAD_STATE, --订单状态（送审、汇总、库评、产地分解等）
                             R_PLN_LG_ORDER.ORDER_TYPE_NAME, --订单类型名称
                             R_PLN_LG_ORDER.ORDER_NUMBER, --订单号（单单评审，记录订单号）
                             TRUNC(SYSDATE), --总部评审日期
                             IN_USER_CODE, --总部评审人员
                             '销售转采购生成发运计划回写评审数量', --备注
                             IN_USER_CODE, --创建人
                             SYSDATE, --创建日期
                             IN_USER_CODE, --最后修改人
                             SYSDATE, --最后修改日期
                             NULL, --Pre_Field_01, --预留字段1
                             NULL, --Pre_Field_02, --预留字段2
                             NULL, --Pre_Field_03, --预留字段3
                             NULL, --Pre_Field_04, --预留字段4
                             NULL, --Pre_Field_05, --预留字段5
                             NULL, --Pre_Field_06, --预留字段6
                             R_PLN_LG_ORDER.ORDER_HEAD_ID, --Origin_Order_Head_Id, --来源订单头ID
                             R_PLN_LG_LINE.ORDER_LINE_ID, --Origin_Order_Line_Id, --来源订单行ID
                             R_PLN_LG_LINE.ITEM_ID, --Item_Id, --产品ID
                             R_PLN_LG_LINE.ITEM_CODE, --Item_Code, --产品编码
                             R_PLN_LG_LINE.ITEM_NAME, --Item_Name, --产品描述
                             R_INTF_LG_SHIP_PLAN.ITEM_QTY, --Affirm_Qty --评审数量
                             NULL, --收货仓库ID
                             R_INTF_LG_SHIP_PLAN.SHIP_INVENTORY_ID, --发货仓库ID
                             'N', --add by xuhongjiu 2016-05-05
                             R_PLN_LG_ORDER.CHECKUP_CONTENT, --评审意见 add by lilh6 160909
                             R_PLN_LG_ORDER.CUSTOMER_ORDER_NUMBER, --客户订单号 add by lilh6 160909
                             R_INTF_LG_SHIP_PLAN.CONSIGNEE_ADDR --收货地址 add by lilh6 160920
                             );
                        EXCEPTION
                          WHEN OTHERS THEN
                            OUT_RESULT := '插入评审记录信息失败，失败原因：' || SQLERRM;
                        END;
                      EXCEPTION
                        WHEN NO_DATA_FOUND THEN
                          R_INTF_LG_SHIP_PLAN.ORIGIN_ORIGIN_LINE_ID := NULL;
                      END;
                    ELSE
                      R_INTF_LG_SHIP_PLAN.ORIGIN_ORIGIN_LINE_ID := NULL;
                    END IF;
                  END IF;
                
                  --检查营销大类
                  IF OUT_RESULT = V_SUCCESS THEN
                    V_IN_PARAM := '营销大类=' ||
                                  R_INTF_LG_SHIP_PLAN.SALES_MAIN_TYPE;
                    BEGIN
                      SELECT C.CLASS_CODE
                        INTO R_INTF_LG_SHIP_PLAN.SALES_MAIN_TYPE
                        FROM T_BD_ITEM_CLASS C
                       WHERE C.CLASS_CODE =
                             R_INTF_LG_SHIP_PLAN.SALES_MAIN_TYPE
                         AND C.CLASS_TYPE = 'M'
                         AND C.ACTIVE_FLAG = V_YES
                         AND C.ENTITY_ID = R_PARAM_HEAD.ENTITY_ID;
                    EXCEPTION
                      WHEN NO_DATA_FOUND THEN
                        OUT_RESULT := '营销大类不存在或已失效，请检查营销分类设置！';
                    END;
                  END IF;
                
                  --检查销售单类型
                  IF OUT_RESULT = V_SUCCESS THEN
                    V_IN_PARAM := '销售单类型ID=' ||
                                  TO_CHAR(R_PARAM_LINE.SO_BILL_TYPE_ID);
                    BEGIN
                      SELECT T.BILL_TYPE_ID
                        INTO R_INTF_LG_SHIP_PLAN.SALES_ORDER_TYPE_ID
                        FROM V_SO_BILL_TYPE T
                       WHERE T.BILL_TYPE_ID = R_PARAM_LINE.SO_BILL_TYPE_ID
                         AND T.BILL_TYPE_CODE NOT IN (SO_BILL_CODE_SO_TC) --非电商销售单
                         AND NVL(T.REVERSAL_BILL_FLAG, 'N') = 'N' --非红冲单据类型
                         AND SYSDATE BETWEEN T.BEGIN_DATE AND
                             NVL(T.END_DATE, SYSDATE + 1)
                         AND T.SRC_TYPE_CODE = '1001'; --销售出库单
                    EXCEPTION
                      WHEN NO_DATA_FOUND THEN
                        OUT_RESULT := '单据类型不存在或已失效，请检查单据类型设置！' || V_NL ||
                                      '单据类型需满足条件：非电商销售单，非红冲单据类型，单据源类型为销售单(1001)';
                    END;
                  END IF;
                
                  --若价格批文类型不为空，则检查价格批文
                  IF OUT_RESULT = V_SUCCESS AND
                     R_PARAM_LINE.PRICE_APPLY_TYPE IS NOT Null AND NVL(R_PARAM_LINE.PRICE_APPLY_ID, -1) <> -1 THEN
                    V_IN_PARAM := '价格批文类型=' ||
                                  R_PARAM_LINE.PRICE_APPLY_TYPE ||
                                  ',价格批文ID=' ||
                                  TO_CHAR(R_PARAM_LINE.PRICE_APPLY_ID) ||
                                  ',价格批文号=' ||
                                  R_PARAM_LINE.PRICE_APPLY_CODE;
                    BEGIN
                      SELECT A.APPLY_TYPE, A.PRICE_APPLY_ID, A.APPLY_CODE
                        INTO R_INTF_LG_SHIP_PLAN.PROJECT_ORDER_TYPE,
                             R_INTF_LG_SHIP_PLAN.PROJECT_ORDER_HEAD_ID,
                             R_INTF_LG_SHIP_PLAN.PROJECT_ORDER_NUMBER
                        FROM T_BD_PRICE_APPLY A
                       WHERE A.APPLY_TYPE = R_PARAM_LINE.PRICE_APPLY_TYPE
                         AND A.PRICE_APPLY_ID = R_PARAM_LINE.PRICE_APPLY_ID
                         AND A.APPLY_STATUS = APPLY_STATUS_30
                      /*AND SYSDATE BETWEEN A.BEGIN_DATE AND NVL(A.END_DATE, SYSDATE + 1)*/
                      ;
                    
                      R_INTF_LG_SHIP_PLAN.PROJECT_ORDER_LINE_ID := R_PARAM_LINE.PRICE_APPLY_LINE_ID;
                      R_INTF_LG_SHIP_PLAN.APPLY_LIST_PRICE      := R_PARAM_LINE.CUST_SO_LIST_PRICE;
                      R_INTF_LG_SHIP_PLAN.APPLY_DISCOUNT_RATE   := R_PARAM_LINE.CUST_SO_DISCOUNT_RATE;
                    EXCEPTION
                      WHEN NO_DATA_FOUND THEN
                        OUT_RESULT := '价格批文无效，请检查价格批文是否已审批通过或在有效期内！';
                    END;
                  
                    IF OUT_RESULT = V_SUCCESS THEN
                      SELECT L.TRANSFER_PRICE_LINE_ID
                        INTO V_TRANSFER_PRICE_LINE_ID
                        FROM T_SO_LINE L
                       WHERE L.SO_LINE_ID = R_PARAM_LINE.SOURCE_LINE_ID;
                    
                      --无客户提货订单来源、来源销售单行无相关批文信息，需先锁定批文数量
                      IF R_PLN_LG_ORDER.ORDER_HEAD_ID IS NULL AND
                         V_TRANSFER_PRICE_LINE_ID IS NULL THEN
                        V_IN_PARAM := '批文行ID=' ||
                                      TO_CHAR(R_PARAM_LINE.PRICE_APPLY_LINE_ID) ||
                                      ',批文号=' ||
                                      R_PARAM_LINE.PRICE_APPLY_CODE ||
                                      ',产品=' || R_PARAM_LINE.ASS_ITEM_CODE;
                        PKG_BD_PRICE.P_APPLY_LOCK(P_APPLY_DETAIL_ID => R_PARAM_LINE.PRICE_APPLY_LINE_ID,
                                                  P_LOCK_CNT        => R_INTF_LG_SHIP_PLAN.ITEM_QTY,
                                                  P_BILL_NO         => R_SO_HEAD.SO_NUM,
                                                  P_RETURN_CODE     => V_RESULT,
                                                  P_RETURN_MSG      => OUT_RESULT);
                        IF V_RESULT = '1' THEN
                          --返回1表示成功
                          OUT_RESULT := V_SUCCESS;
                        END IF;
                      END IF;
                    END IF;
                  ELSE
                    R_INTF_LG_SHIP_PLAN.PROJECT_ORDER_TYPE    := R_PARAM_LINE.PRICE_APPLY_TYPE;
                    R_INTF_LG_SHIP_PLAN.PROJECT_ORDER_HEAD_ID := R_PARAM_LINE.PRICE_APPLY_ID;
                    R_INTF_LG_SHIP_PLAN.PROJECT_ORDER_NUMBER  := R_PARAM_LINE.PRICE_APPLY_CODE;
                    R_INTF_LG_SHIP_PLAN.PROJECT_ORDER_LINE_ID := R_PARAM_LINE.PRICE_APPLY_LINE_ID;
                    R_INTF_LG_SHIP_PLAN.APPLY_LIST_PRICE      := R_PARAM_LINE.CUST_SO_LIST_PRICE;
                    R_INTF_LG_SHIP_PLAN.APPLY_DISCOUNT_RATE   := R_PARAM_LINE.CUST_SO_DISCOUNT_RATE;
                  END IF;
                
                  IF OUT_RESULT = v_Success THEN
                    V_TABLE_INDEX := R_INTF_LG_SHIP_PLAN.SALES_MAIN_TYPE || ',' || R_INTF_LG_SHIP_PLAN.DISCOUNT_TYPE;
                    IF NOT TV_SPLIT_ORDER.EXISTS(V_TABLE_INDEX) THEN
                      TV_SPLIT_ORDER(V_TABLE_INDEX).SALES_MAIN_TYPE := R_INTF_LG_SHIP_PLAN.SALES_MAIN_TYPE;
                      TV_SPLIT_ORDER(V_TABLE_INDEX).DISCOUNT_TYPE := R_INTF_LG_SHIP_PLAN.DISCOUNT_TYPE;
                      TV_SPLIT_ORDER(V_TABLE_INDEX).SUM_AMOUNT := V_SUM_AMOUNT;
                      TV_SPLIT_ORDER(V_TABLE_INDEX).SUM_DIS_AMOUNT := V_SUM_DIS_AMOUNT;
                    ELSE
                      TV_SPLIT_ORDER(V_TABLE_INDEX).SUM_AMOUNT := TV_SPLIT_ORDER(V_TABLE_INDEX).SUM_AMOUNT + V_SUM_AMOUNT;
                      TV_SPLIT_ORDER(V_TABLE_INDEX).SUM_DIS_AMOUNT := TV_SPLIT_ORDER(V_TABLE_INDEX).SUM_DIS_AMOUNT + V_SUM_DIS_AMOUNT;
                    END IF;
                  END IF;
                
                  --检查库存可用量
                  IF OUT_RESULT = V_SUCCESS THEN
                    V_IN_PARAM := '产品编码=' || R_INTF_LG_SHIP_PLAN.ITEM_CODE ||
                                  '，仓库编码=' || R_PARAM_HEAD.FINANCE_INV_CODE;
                    --获取产品仓库的可用量
                    V_USABLE_ITEM_QOH_QTY := PKG_INV_PUB.F_GET_ITEM_INV_QOH(P_ENTITY_ID    => R_INTF_LG_SHIP_PLAN.ENTITY_ID,
                                                                            P_INVENTORY_ID => R_INTF_LG_SHIP_PLAN.SHIP_INVENTORY_ID,
                                                                            P_ITEM_ID      => V_ITEM_ID,
                                                                            P_USER_CODE    => IN_USER_CODE,
                                                                            P_GET_QOH_TYPE => 2);
                    IF V_USABLE_ITEM_QOH_QTY < R_INTF_LG_SHIP_PLAN.ITEM_QTY THEN
                      OUT_RESULT := '库存可用量无法满足本次占用数。库存可用量=' ||
                                    TO_CHAR(V_USABLE_ITEM_QOH_QTY) ||
                                    '，本次占用数量' ||
                                    TO_CHAR(R_INTF_LG_SHIP_PLAN.ITEM_QTY);
                    END IF;
                  END IF;
                
                  --做库存占用
                  IF OUT_RESULT = V_SUCCESS THEN
                    V_IN_PARAM := '库存占用。产品编码=' ||
                                  R_INTF_LG_SHIP_PLAN.ITEM_CODE || '，仓库编码=' ||
                                  R_PARAM_HEAD.FINANCE_INV_CODE;
                    PKG_PLN_INV_OCCUPY.P_AFFIRM_OCCUPY_STOCKS(P_INVENTORY_ID      => R_INTF_LG_SHIP_PLAN.SHIP_INVENTORY_ID,
                                                              P_ITEM_ID           => V_ITEM_ID,
                                                              P_OCCUPY_QTY        => R_INTF_LG_SHIP_PLAN.ITEM_QTY,
                                                              P_MATCH_PLN_TO_WIP  => 'A',
                                                              P_ACTION_DESC       => '销售单' ||
                                                                                     R_PARAM_HEAD.SOURCE_ORDER_NUMBER ||
                                                                                     '转采购生成发运计划',
                                                              P_ENTITY_ID         => R_INTF_LG_SHIP_PLAN.ENTITY_ID,
                                                              P_ORIGIN_TYPE       => '销售转采购',
                                                              P_ORIGIN_HEAD_ID    => R_INTF_LG_SHIP_PLAN.ORIGIN_ORDER_ID,
                                                              P_ORIGIN_NUMBER     => R_INTF_LG_SHIP_PLAN.ORIGIN_ORDER_NUM,
                                                              P_ORIGIN_LINE_ID    => R_INTF_LG_SHIP_PLAN.ORIGIN_LINE_ID,
                                                              P_SOURCE_ORDER_TYPE => R_SO_HEAD.BILL_TYPE_NAME,
                                                              P_SOURCE_HEAD_ID    => R_SO_HEAD.SO_HEADER_ID,
                                                              P_SOURCE_NUMBER     => R_SO_HEAD.SO_NUM,
                                                              P_SOURCE_LINE_ID    => R_PARAM_LINE.SOURCE_LINE_ID,
                                                              P_USER_CODE         => IN_USER_CODE,
                                                              P_RESULT            => OUT_ERR_NUM,
                                                              P_ERR_MSG           => OUT_RESULT);
                  END IF;
                
                  --插入发运计划接口表
                  IF OUT_RESULT = V_SUCCESS THEN
                    V_IN_PARAM := '插入发运计划接口表';
                    SELECT S_INTF_LG_SHIP_PLAN.NEXTVAL
                      INTO R_INTF_LG_SHIP_PLAN.SHIP_PLAN_ID
                      FROM DUAL;
                    BEGIN
                      INSERT INTO INTF_LG_SHIP_PLAN
                        (SHIP_PLAN_ID,
                         ENTITY_ID,
                         SALES_MAIN_TYPE,
                         ITEM_CODE,
                         ITEM_DESC,
                         ITEM_UOM,
                         ITEM_QTY,
                         ITEM_PRICE,
                         CUSTOMER_ID,
                         CUSTOMER_CODE,
                         CUSTOMER_NAME,
                         ACCOUNT_CODE,
                         CUSTOMER_CONTACTS,
                         CUSTOMER_CONTACTS_PHONES,
                         ORIGIN_ORIGIN_TYPE,
                         ORIGIN_ORIGIN_ORDER_CODE,
                         ORIGIN_ORIGIN_HEAD_ID,
                         ORIGIN_ORIGIN_LINE_ID,
                         ORIGIN_TYPE,
                         ORIGIN_ORDER_NUM,
                         ORIGIN_ORDER_ID,
                         ORIGIN_LINE_ID,
                         SHIP_WAY,
                         SHIP_TYPE,
                         LOAD_VEHICLE_TYPE,
                         SHIP_INVENTORY_ID,
                         SALES_ORDER_TYPE_ID,
                         SETTLEMENT_TYPE,
                         CONSIGNEE_LOCATION_CODE,
                         CONSIGNEE_ADDR,
                         CONSIGNEE_COMPANY_ID,
                         CONSIGNEE_COMPANY_CODE,
                         CONSIGNEE_COMPANY_NAME,
                         CONSIGNEE_COMPANY_ADDR,
                         CONSIGNEE_COMPANY_CONTACT_ID,
                         CONSIGNEE_COMPANY_CONTRACT,
                         CONSIGNEE_COMPANY_TEL,
                         SALES_CENTER_ID,
                         SALES_CENTER_CODE,
                         SALES_CENTER_NAME,
                         SHIP_INFO_DATE,
                         REQUIRE_SHIP_DATE,
                         REQUIRE_ARRIVE_DATE,
                         PICK_FLAG,
                         IS_CUSG_FLAG,
                         STATUS,
                         MONTH_DISCOUNT_RATE,
                         DISCOUNT_RATE,
                         REMARK,
                         CREATED_BY,
                         CREATION_DATE,
                         LAST_UPDATED_BY,
                         LAST_UPDATE_DATE,
                         CUSTOMER_ORDER_NUMBER,
                         BATCH_DEAL_NUM,
                         PROJECT_ORDER_TYPE,
                         PROJECT_ORDER_NUMBER,
                         PROJECT_ORDER_HEAD_ID,
                         PROJECT_ORDER_LINE_ID,
                         APPLY_LIST_PRICE,
                         APPLY_DISCOUNT_RATE,
                         ORDER_HEAD_REMARKS,
                         LG_ORDER_NUMBER,
                         CUSTOMER_CHANNEL_TYPE,
                         LOCK_AMOUNT_FLAG,
                         LG_ORDER_REVIEW_FLAG,
                         DISCOUNT_TYPE)
                      VALUES
                        (R_INTF_LG_SHIP_PLAN.SHIP_PLAN_ID,
                         R_INTF_LG_SHIP_PLAN.ENTITY_ID,
                         R_INTF_LG_SHIP_PLAN.SALES_MAIN_TYPE,
                         R_INTF_LG_SHIP_PLAN.ITEM_CODE,
                         R_INTF_LG_SHIP_PLAN.ITEM_DESC,
                         R_INTF_LG_SHIP_PLAN.ITEM_UOM,
                         R_INTF_LG_SHIP_PLAN.ITEM_QTY,
                         R_INTF_LG_SHIP_PLAN.ITEM_PRICE,
                         R_INTF_LG_SHIP_PLAN.CUSTOMER_ID,
                         R_INTF_LG_SHIP_PLAN.CUSTOMER_CODE,
                         R_INTF_LG_SHIP_PLAN.CUSTOMER_NAME,
                         R_INTF_LG_SHIP_PLAN.ACCOUNT_CODE,
                         R_INTF_LG_SHIP_PLAN.CUSTOMER_CONTACTS,
                         R_INTF_LG_SHIP_PLAN.CUSTOMER_CONTACTS_PHONES,
                         R_INTF_LG_SHIP_PLAN.ORIGIN_ORIGIN_TYPE,
                         R_INTF_LG_SHIP_PLAN.ORIGIN_ORIGIN_ORDER_CODE,
                         R_INTF_LG_SHIP_PLAN.ORIGIN_ORIGIN_HEAD_ID,
                         R_INTF_LG_SHIP_PLAN.ORIGIN_ORIGIN_LINE_ID,
                         R_INTF_LG_SHIP_PLAN.ORIGIN_TYPE,
                         R_INTF_LG_SHIP_PLAN.ORIGIN_ORDER_NUM,
                         R_INTF_LG_SHIP_PLAN.ORIGIN_ORDER_ID,
                         R_INTF_LG_SHIP_PLAN.ORIGIN_LINE_ID,
                         R_INTF_LG_SHIP_PLAN.SHIP_WAY,
                         R_INTF_LG_SHIP_PLAN.SHIP_TYPE,
                         R_INTF_LG_SHIP_PLAN.LOAD_VEHICLE_TYPE,
                         R_INTF_LG_SHIP_PLAN.SHIP_INVENTORY_ID,
                         R_INTF_LG_SHIP_PLAN.SALES_ORDER_TYPE_ID,
                         R_INTF_LG_SHIP_PLAN.SETTLEMENT_TYPE,
                         R_INTF_LG_SHIP_PLAN.CONSIGNEE_LOCATION_CODE,
                         R_INTF_LG_SHIP_PLAN.CONSIGNEE_ADDR,
                         R_INTF_LG_SHIP_PLAN.CONSIGNEE_COMPANY_ID,
                         R_INTF_LG_SHIP_PLAN.CONSIGNEE_COMPANY_CODE,
                         R_INTF_LG_SHIP_PLAN.CONSIGNEE_COMPANY_NAME,
                         R_INTF_LG_SHIP_PLAN.CONSIGNEE_COMPANY_ADDR,
                         R_INTF_LG_SHIP_PLAN.CONSIGNEE_COMPANY_CONTACT_ID,
                         R_INTF_LG_SHIP_PLAN.CONSIGNEE_COMPANY_CONTRACT,
                         R_INTF_LG_SHIP_PLAN.CONSIGNEE_COMPANY_TEL,
                         R_INTF_LG_SHIP_PLAN.SALES_CENTER_ID,
                         R_INTF_LG_SHIP_PLAN.SALES_CENTER_CODE,
                         R_INTF_LG_SHIP_PLAN.SALES_CENTER_NAME,
                         R_INTF_LG_SHIP_PLAN.SHIP_INFO_DATE,
                         R_INTF_LG_SHIP_PLAN.REQUIRE_SHIP_DATE,
                         R_INTF_LG_SHIP_PLAN.REQUIRE_ARRIVE_DATE,
                         R_INTF_LG_SHIP_PLAN.PICK_FLAG,
                         R_INTF_LG_SHIP_PLAN.IS_CUSG_FLAG,
                         R_INTF_LG_SHIP_PLAN.STATUS,
                         R_INTF_LG_SHIP_PLAN.MONTH_DISCOUNT_RATE,
                         R_INTF_LG_SHIP_PLAN.DISCOUNT_RATE,
                         R_INTF_LG_SHIP_PLAN.REMARK,
                         R_INTF_LG_SHIP_PLAN.CREATED_BY,
                         R_INTF_LG_SHIP_PLAN.CREATION_DATE,
                         R_INTF_LG_SHIP_PLAN.LAST_UPDATED_BY,
                         R_INTF_LG_SHIP_PLAN.LAST_UPDATE_DATE,
                         R_INTF_LG_SHIP_PLAN.CUSTOMER_ORDER_NUMBER,
                         R_INTF_LG_SHIP_PLAN.BATCH_DEAL_NUM,
                         R_INTF_LG_SHIP_PLAN.PROJECT_ORDER_TYPE,
                         R_INTF_LG_SHIP_PLAN.PROJECT_ORDER_NUMBER,
                         R_INTF_LG_SHIP_PLAN.PROJECT_ORDER_HEAD_ID,
                         R_INTF_LG_SHIP_PLAN.PROJECT_ORDER_LINE_ID,
                         R_INTF_LG_SHIP_PLAN.APPLY_LIST_PRICE,
                         R_INTF_LG_SHIP_PLAN.APPLY_DISCOUNT_RATE,
                         R_INTF_LG_SHIP_PLAN.ORDER_HEAD_REMARKS,
                         R_INTF_LG_SHIP_PLAN.LG_ORDER_NUMBER,
                         R_INTF_LG_SHIP_PLAN.CUSTOMER_CHANNEL_TYPE,
                         R_INTF_LG_SHIP_PLAN.LOCK_AMOUNT_FLAG,
                         R_INTF_LG_SHIP_PLAN.LG_ORDER_REVIEW_FLAG,
                         R_INTF_LG_SHIP_PLAN.DISCOUNT_TYPE);
                    EXCEPTION
                      WHEN OTHERS THEN
                        OUT_RESULT := '插入发运计划接口表失败！' || V_NL || '系统提示：' ||
                                      SQLERRM;
                    END;
                  END IF;
                END IF; --实收正品数大于0才处理end
              END IF;
            
              IF OUT_RESULT <> V_SUCCESS THEN
                EXIT;
              END IF;
            END LOOP;
          END IF;
          
          --拆单完毕，进行款项处理和生成销售单
          IF OUT_RESULT = V_SUCCESS THEN
            V_TABLE_INDEX := TV_SPLIT_ORDER.FIRST;
            LOOP
              EXIT WHEN V_TABLE_INDEX IS NULL;
              V_SALES_MAIN_TYPE := TV_SPLIT_ORDER(V_TABLE_INDEX).SALES_MAIN_TYPE;
              V_DISCOUNT_TYPE := TV_SPLIT_ORDER(V_TABLE_INDEX).DISCOUNT_TYPE;
              V_SUM_AMOUNT := TV_SPLIT_ORDER(V_TABLE_INDEX).SUM_AMOUNT;
              V_SUM_DIS_AMOUNT := TV_SPLIT_ORDER(V_TABLE_INDEX).SUM_DIS_AMOUNT;
              --如果是自提、无来源客户提货订单、转采购销售单无直发客户，需先做款项锁定处理
              IF R_PLN_LG_ORDER.ORDER_HEAD_ID IS NULL AND R_SO_HEAD.TRANSFER_ACCOUNT_ID IS NULL THEN
                PKG_PLN_PUB.P_CUSTOMER_AMOUNT_PROCESS(IN_ENTITY_ID       => R_PARAM_HEAD.ENTITY_ID,
                                                      IN_ORDER_TYPE_ID   => -1,
                                                      IN_ORDER_TYPE_CODE => R_SO_HEAD.BILL_TYPE_NAME,
                                                      IN_CUSTOMER_ID     => R_PARAM_HEAD.TRANSFER_CUSTOMER_ID,
                                                      IN_ACCOUNT_ID      => R_PARAM_HEAD.TRANSFER_ACCOUNT_ID,
                                                      IN_SALES_MAIN_TYPE => V_SALES_MAIN_TYPE,
                                                      IN_ACTION_TYPE     => 1,
                                                      IN_SOURCE_TYPE     => '12',
                                                      IN_ORDER_ID        => R_SO_HEAD.SO_HEADER_ID,
                                                      IN_PROJ_NUMBER     => NULL,
                                                      IN_DISCOUNT_TYPE   => V_DISCOUNT_TYPE,
                                                      IN_AMOUNT          => round(V_SUM_AMOUNT, 2),
                                                      IN_DIS_AMOUNT      => round(V_SUM_DIS_AMOUNT, 2),
                                                      IN_RECORD_ERR      => 'N',
                                                      IN_USER_CODE       => IN_USER_CODE,
                                                      OUT_RESULT         => OUT_RESULT);
                IF OUT_RESULT <> V_SUCCESS THEN
                  OUT_RESULT := '销售转采购（无来源客户提货订单、转采购销售单无直发客户）处理款项失败！' || V_NL || OUT_RESULT;
                END IF;
              END IF;
              
              --如果有来源提货订单且送审锁款的，需按订金做款项处理
              IF OUT_RESULT = V_SUCCESS AND R_PLN_LG_ORDER.LOCK_AMOUNT_FLAG = V_LOCK_AMOUNT_FLAG_S AND NVL(v_Hq_Affirm_Lock_Full_Amount, 'N') <> 'Y' THEN
                PKG_PLN_PUB.P_CUSTOMER_AMOUNT_PROCESS(IN_ENTITY_ID       => R_PARAM_HEAD.ENTITY_ID,
                                                      IN_ORDER_TYPE_ID   => R_PLN_LG_ORDER.ORDER_TYPE_ID,
                                                      IN_ORDER_TYPE_CODE => R_PLN_LG_ORDER.ORDER_TYPE_CODE,
                                                      IN_CUSTOMER_ID     => R_PLN_LG_ORDER.CUSTOMER_ID,
                                                      IN_ACCOUNT_ID      => R_PLN_LG_ORDER.ACCOUNT_ID,
                                                      IN_SALES_MAIN_TYPE => V_SALES_MAIN_TYPE,
                                                      IN_ACTION_TYPE     => 28,
                                                      IN_SOURCE_TYPE     => '02',
                                                      IN_ORDER_ID        => R_PLN_LG_ORDER.ORDER_HEAD_ID,
                                                      IN_PROJ_NUMBER     => NULL,
                                                      IN_DISCOUNT_TYPE   => V_DISCOUNT_TYPE,
                                                      IN_AMOUNT          => round(NVL(V_SUM_AMOUNT, 0), 2),
                                                      IN_DIS_AMOUNT      => round(NVL(V_SUM_DIS_AMOUNT, 0), 2),
                                                      IN_RECORD_ERR      => 'N',
                                                      IN_USER_CODE       => IN_USER_CODE,
                                                      OUT_RESULT         => OUT_RESULT);
                IF OUT_RESULT <> V_SUCCESS THEN
                  OUT_RESULT := '销售转采购（有来源提货订单直发生成发货通知单）处理客户款项失败！' || V_NL || OUT_RESULT;
                END IF;                
              END IF;
              
              IF OUT_RESULT = v_Success THEN
                V_TABLE_INDEX := TV_SPLIT_ORDER.NEXT(V_TABLE_INDEX);
              ELSE
                EXIT;
              END IF;
            END LOOP;
          END IF;
        END IF;
      
        --差异数量处理
        IF OUT_RESULT = V_SUCCESS AND
           R_PLN_LG_ORDER.ORDER_HEAD_ID IS NOT NULL THEN
          V_ASS_ITEM_CODE := '_';
          FOR R_PARAM_LINE IN (SELECT *
                                 FROM T_SO_TO_SUPP_PARAM_LINE L
                                WHERE L.PARAM_ID = IN_PARAM_ID
                                ORDER BY L.ASS_ITEM_CODE,
                                         CEIL((NVL(L.FACT_REV_SHATTER_QTY, 0) +
                                         NVL(L.MISSING_QTY, 0) +
                                         NVL(L.REJECTED_QTY, 0))/NVL(L.SUB_ITEM_QTY_SCALE,1)) DESC) LOOP
            IF V_ASS_ITEM_CODE <> R_PARAM_LINE.ASS_ITEM_CODE THEN
              --每个套件编码只插入行
              V_ASS_ITEM_CODE := R_PARAM_LINE.ASS_ITEM_CODE;
              IF CEIL((NVL(R_PARAM_LINE.FACT_REV_SHATTER_QTY, 0) +
                 NVL(R_PARAM_LINE.MISSING_QTY, 0) +
                 NVL(R_PARAM_LINE.REJECTED_QTY, 0))/NVL(R_PARAM_LINE.SUB_ITEM_QTY_SCALE,1)) > 0 THEN
                V_CANCEL_QTY := CEIL((NVL(R_PARAM_LINE.FACT_REV_SHATTER_QTY, 0) +
                                NVL(R_PARAM_LINE.MISSING_QTY, 0) +
                                NVL(R_PARAM_LINE.REJECTED_QTY, 0))/NVL(R_PARAM_LINE.SUB_ITEM_QTY_SCALE,1));
                --获取提货订单来源行
                BEGIN
                  SELECT L.*
                    INTO R_PLN_LG_LINE
                    FROM T_PLN_LG_ORDER_LINE L
                   WHERE L.ORDER_HEAD_ID = R_PLN_LG_ORDER.ORDER_HEAD_ID
                     AND L.ITEM_CODE = R_PARAM_LINE.ASS_ITEM_CODE
                     AND NVL(L.SHARE_VENDOR_TYPE, '_') <> 'AGENT';
                
                  --更新提货订单行评审数量
                  UPDATE T_PLN_LG_ORDER_LINE L
                     SET L.TRANSFER_HQ_AFFIRMED_QTY =
                          CASE
                            WHEN R_PLN_LG_ORDER.LOCK_AMOUNT_FLAG IN (V_LOCK_AMOUNT_FLAG_Y, V_LOCK_AMOUNT_FLAG_HQ) THEN
                              GREATEST(NVL(L.TRANSFER_HQ_AFFIRMED_QTY, 0) - V_CANCEL_QTY, NVL(L.SENDED_QTY, 0))
                            WHEN R_PLN_LG_ORDER.LOCK_AMOUNT_FLAG = V_LOCK_AMOUNT_FLAG_S AND v_Hq_Affirm_Lock_Full_Amount = 'Y' THEN
                              GREATEST(NVL(L.TRANSFER_HQ_AFFIRMED_QTY, 0) - V_CANCEL_QTY, NVL(L.SENDED_QTY, 0))
                            ELSE
                              L.TRANSFER_HQ_AFFIRMED_QTY
                          END,
                         L.CANCEL_QTY       = NVL(L.CANCEL_QTY, 0) +
                                              V_CANCEL_QTY,
                         L.LAST_UPDATED_BY  = IN_USER_CODE,
                         L.LAST_UPDATE_DATE = SYSDATE,
                         L.VERSION = NVL(L.VERSION, 0) + 1
                   WHERE L.ORDER_LINE_ID = R_PLN_LG_LINE.ORDER_LINE_ID;
                
                  --按取消数量解锁
                  SELECT DECODE(R_PLN_LG_LINE.PROJECT_ORDER_TYPE,
                                NULL,
                                R_PLN_LG_LINE.LIST_PRICE *
                                (100 - NVL(R_PARAM_LINE.CUST_SO_DISCOUNT_RATE, 0) -
                                NVL(R_PARAM_LINE.CUST_SO_MONTH_DIS_RATE, 0)),
                                R_PLN_LG_LINE.APPLY_LIST_PRICE *
                                (100 - DECODE(V_PRICE_APPLY_USE_DISCOUNT,
                                              'Y',
                                              NVL(R_PARAM_LINE.CUST_SO_DISCOUNT_RATE,
                                                  0),
                                              0) -
                                NVL(R_PARAM_LINE.CUST_SO_MONTH_DIS_RATE, 0))) *
                         V_CANCEL_QTY / 100,
                         DECODE(R_PLN_LG_LINE.PROJECT_ORDER_TYPE,
                                NULL,
                                R_PLN_LG_LINE.LIST_PRICE *
                                NVL(R_PARAM_LINE.CUST_SO_DISCOUNT_RATE, 0),
                                R_PLN_LG_LINE.APPLY_LIST_PRICE *
                                DECODE(V_PRICE_APPLY_USE_DISCOUNT,
                                       'Y',
                                       NVL(R_PARAM_LINE.CUST_SO_DISCOUNT_RATE,
                                           0),
                                       0)) * V_CANCEL_QTY / 100
                    INTO V_CANCEL_AMOUNT, V_CANCEL_DIS_AMOUNT
                    FROM DUAL;
                  
                  IF OUT_RESULT = V_SUCCESS AND R_PLN_LG_ORDER.CUSTOMIZE_FLAG = 'Y' THEN
                    --校验款项
                    For r_Check_Amount In (--甲方
                                           Select lol.entity_id,
                                                  be.entity_name,
                                                  h.customer_id,
                                                  H.CUSTOMER_CODE,
                                                  h.account_id,
                                                  H.ACCOUNT_CODE,
                                                  nvl(lol.Sales_Main_Type, bi.sales_main_type) Sales_Main_Type,
                                                  Nvl(R_PARAM_LINE.DISCOUNT_TYPE, DISCOUNT_TYPE_COMMON) Discount_Type,                                    
                                                  Sum(Round(V_CANCEL_AMOUNT,2)) apply_Amount,
                                                  Sum(Round(V_CANCEL_DIS_AMOUNT,2)) Discount_Amount
                                             From t_Pln_Lg_Order_Line Lol,
                                                  t_Bd_Item Bi,
                                                  t_pln_lg_order_head h,
                                                  v_bd_entity be
                                            Where lol.order_head_id = h.order_head_id
                                              and Lol.Item_Id = Bi.Item_Id
                                              And Bi.Entity_Id = Lol.Entity_Id
                                              And Lol.Order_Head_Id = R_PLN_LG_LINE.Order_Head_Id
                                              And Lol.Entity_Id = R_PLN_LG_LINE.Entity_Id
                                              and h.entity_id = be.entity_id
                                              and lol.order_line_id = R_PLN_LG_LINE.Order_Line_Id
                                            Group By lol.entity_id,
                                                     be.entity_name,
                                                     h.customer_id,
                                                     h.customer_code,
                                                     h.account_id,
                                                     h.account_code,
                                                     nvl(lol.Sales_Main_Type, bi.sales_main_type),
                                                     Nvl(R_PARAM_LINE.DISCOUNT_TYPE, DISCOUNT_TYPE_COMMON)
                                            ) Loop
                      PKG_CREDIT_ACCOUNT_CONTROL.P_CREDIT_CHECK_AMOUNT(IN_ENTITY_ID       => r_Check_Amount.Entity_Id,
                                                                       IN_CUSTOMER_ID     => r_Check_Amount.Customer_Id,
                                                                       IN_ACCOUNT_ID      => r_Check_Amount.Account_Id,
                                                                       IN_SALES_MAIN_TYPE => r_Check_Amount.Sales_Main_Type,
                                                                       IN_PROJ_NUMBER     => null,
                                                                       IN_AMOUNT_SUM      => r_Check_Amount.Apply_Amount,
                                                                       IN_DISAMOUNT_SUM   => r_Check_Amount.Discount_Amount,
                                                                       IN_DISCOUNT_TYPE   => r_Check_Amount.Discount_Type,
                                                                       IN_USER_ACCOUNT    => IN_USER_CODE,
                                                                       OUT_RESULT         => OUT_ERR_NUM,
                                                                       OUT_ERR_MSG        => OUT_RESULT);
                      IF OUT_ERR_NUM <> 0 THEN
                        OUT_RESULT := '销售转采购（差异数量取消订单）校验客户款项失败！错误提示：'||v_Nl||OUT_RESULT||v_Nl||
                                    '事业部='||r_Check_Amount.entity_name||v_Nl||
                                    '客户ID='||r_Check_Amount.Customer_Id||' 编码='||r_Check_Amount.customer_code||v_Nl||
                                    '账户ID='||r_Check_Amount.Account_Id||' 编码='||r_Check_Amount.account_code||v_Nl||
                                    '营销大类='||r_Check_Amount.Sales_Main_Type||v_Nl||
                                    '折扣类型='||r_Check_Amount.Discount_Type;
                        --raise v_Base_Exception;
                        EXIT;
                      END IF;
                    End Loop;
                    
                    IF OUT_RESULT = V_SUCCESS THEN
                      --锁定款项
                      For r_Check_Amount In (--甲方
                                             Select lol.entity_id,
                                                    be.entity_name,
                                                    h.customer_id,
                                                    H.CUSTOMER_CODE,
                                                    h.account_id,
                                                    H.ACCOUNT_CODE,
                                                    nvl(lol.sales_main_type, bi.sales_main_type) Sales_Main_Type,
                                                    Nvl(r_param_line.Discount_Type, Discount_Type_Common) Discount_Type,
                                                    decode(lol.customize_flag, 'Y', ah.project_code, null) project_code,
                                                    decode(lol.customize_flag, 'Y', 100, lol.down_pay_scale) down_pay_scale,
                                                    h.order_head_id order_id,
                                                    h.order_number order_number,
                                                    '02' src_type,
                                                    Sum(Round(V_CANCEL_AMOUNT,2)) apply_Amount,
                                                    Sum(Round(V_CANCEL_DIS_AMOUNT,2)) Discount_Amount,
                                                    0 dp_apply_Amount,
                                                    0 dp_Discount_Amount
                                               From t_Pln_Lg_Order_Line Lol,
                                                    t_Bd_Item Bi,
                                                    t_pln_lg_order_head h,
                                                    v_bd_entity be,
                                                    t_pg_price_apply_head ah
                                              Where lol.order_head_id = h.order_head_id
                                                and Lol.Item_Id = Bi.Item_Id
                                                And Bi.Entity_Id = Lol.Entity_Id
                                                And Lol.Order_Head_Id = R_PLN_LG_LINE.Order_Head_Id
                                                And Lol.Entity_Id = R_PLN_LG_LINE.Entity_Id
                                                and h.entity_id = be.entity_id
                                                and lol.entity_id = ah.entity_id(+)
                                                and lol.project_order_number = ah.apply_code(+)
                                                and lol.order_line_id = R_PLN_LG_LINE.Order_Line_Id
                                              Group By lol.entity_id,
                                                       be.entity_name,
                                                       h.customer_id,
                                                       h.customer_code,
                                                       h.account_id,
                                                       h.account_code,
                                                       nvl(lol.sales_main_type, bi.sales_main_type),
                                                       Nvl(r_param_line.Discount_Type, Discount_Type_Common),
                                                       decode(lol.customize_flag, 'Y', ah.project_code, null),
                                                       decode(lol.customize_flag, 'Y', 100, lol.down_pay_scale),
                                                       h.order_head_id,
                                                       h.order_number
                                              ) Loop
                        PKG_CREDIT_ACCOUNT_CONTROL.P_CREDIT_LOCK_DETAIL_HAND(IN_ENTITY_ID   => r_Check_Amount.Entity_Id,
                                                                         IN_CUSTOMER_ID     => r_Check_Amount.Customer_Id,
                                                                         IN_ACCOUNT_ID      => r_Check_Amount.Account_Id,
                                                                         IN_SALES_MAIN_TYPE => r_Check_Amount.Sales_Main_Type,
                                                                         IN_PROJ_NUMBER     => r_Check_Amount.project_code,
                                                                         IN_AMOUNT_SUM      => r_Check_Amount.Apply_Amount,
                                                                         IN_DISAMOUNT_SUM   => r_Check_Amount.Discount_Amount,
                                                                         IN_DP_AMOUNT_SUM   => r_Check_Amount.dp_apply_Amount,
                                                                         IN_DP_DISAMOUNT_SUM => r_Check_Amount.dp_Discount_Amount,
                                                                         IN_DISCOUNT_TYPE   => r_Check_Amount.Discount_Type,
                                                                         IN_ORDER_ID        => r_Check_Amount.order_id,
                                                                         IN_ORDER_NUMBER    => r_Check_Amount.order_number,
                                                                         IN_DOWNPAY_RATE    => r_Check_Amount.down_pay_scale,
                                                                         IN_SRC_TYPE        => r_Check_Amount.src_type,
                                                                         IN_USER_ACCOUNT    => IN_USER_CODE,
                                                                         OUT_RESULT         => OUT_ERR_NUM,
                                                                         OUT_ERR_MSG        => OUT_RESULT);
                        IF OUT_ERR_NUM <> 0 THEN
                          OUT_RESULT := '销售转采购（差异数量取消订单）处理客户款项失败！错误提示：'||v_Nl||OUT_RESULT||v_Nl||
                                      '事业部='||r_Check_Amount.entity_name||v_Nl||
                                      '客户ID='||r_Check_Amount.Customer_Id||' 编码='||r_Check_Amount.customer_code||v_Nl||
                                      '账户ID='||r_Check_Amount.Account_Id||' 编码='||r_Check_Amount.account_code||v_Nl||
                                      '营销大类='||r_Check_Amount.Sales_Main_Type||v_Nl||
                                      '折扣类型='||r_Check_Amount.Discount_Type;
                          --raise v_Base_Exception;
                          EXIT;
                        END IF;
                      End Loop;
                    END IF;
                  END IF;
                  
                  IF OUT_RESULT = V_SUCCESS AND R_PLN_LG_ORDER.LOCK_AMOUNT_FLAG IN (V_LOCK_AMOUNT_FLAG_Y, V_LOCK_AMOUNT_FLAG_HQ, V_LOCK_AMOUNT_FLAG_S) 
                    AND NVL(R_PLN_LG_ORDER.CUSTOMIZE_FLAG, 'N') = 'N' THEN
                    IF R_PLN_LG_ORDER.LOCK_AMOUNT_FLAG IN (V_LOCK_AMOUNT_FLAG_HQ) OR
                      (R_PLN_LG_ORDER.LOCK_AMOUNT_FLAG = V_LOCK_AMOUNT_FLAG_S AND v_Hq_Affirm_Lock_Full_Amount = 'Y') THEN
                      V_ACTION_TYPE := 29;
                      PKG_PLN_PUB.P_CUSTOMER_AMOUNT_PROCESS(IN_ENTITY_ID       => R_PLN_LG_ORDER.ENTITY_ID,
                                                            IN_ORDER_TYPE_ID   => R_PLN_LG_ORDER.ORDER_TYPE_ID,
                                                            IN_ORDER_TYPE_CODE => R_PLN_LG_ORDER.ORDER_TYPE_CODE,
                                                            IN_CUSTOMER_ID     => R_PLN_LG_ORDER.CUSTOMER_ID,
                                                            IN_ACCOUNT_ID      => R_PLN_LG_ORDER.ACCOUNT_ID,
                                                            IN_SALES_MAIN_TYPE => R_PLN_LG_LINE.SALES_MAIN_TYPE,
                                                            IN_ACTION_TYPE     => V_ACTION_TYPE,
                                                            IN_SOURCE_TYPE     => '02',
                                                            IN_ORDER_ID        => R_PLN_LG_ORDER.ORDER_HEAD_ID,
                                                            IN_PROJ_NUMBER     => NULL,
                                                            IN_DISCOUNT_TYPE   => NVL(R_PARAM_LINE.DISCOUNT_TYPE, DISCOUNT_TYPE_COMMON),
                                                            IN_AMOUNT          => ROUND(V_CANCEL_AMOUNT, 2),
                                                            IN_DIS_AMOUNT      => ROUND(V_CANCEL_DIS_AMOUNT, 2),
                                                            IN_RECORD_ERR      => 'N',
                                                            IN_USER_CODE       => IN_USER_CODE,
                                                            OUT_RESULT         => OUT_RESULT);
                    END IF;
                    
                    IF OUT_RESULT = V_SUCCESS THEN
                      V_ACTION_TYPE := 2;
                      PKG_PLN_PUB.P_CUSTOMER_AMOUNT_PROCESS(IN_ENTITY_ID       => R_PLN_LG_ORDER.ENTITY_ID,
                                                            IN_ORDER_TYPE_ID   => R_PLN_LG_ORDER.ORDER_TYPE_ID,
                                                            IN_ORDER_TYPE_CODE => R_PLN_LG_ORDER.ORDER_TYPE_CODE,
                                                            IN_CUSTOMER_ID     => R_PLN_LG_ORDER.CUSTOMER_ID,
                                                            IN_ACCOUNT_ID      => R_PLN_LG_ORDER.ACCOUNT_ID,
                                                            IN_SALES_MAIN_TYPE => R_PLN_LG_LINE.SALES_MAIN_TYPE,
                                                            IN_ACTION_TYPE     => V_ACTION_TYPE,
                                                            IN_SOURCE_TYPE     => '02',
                                                            IN_ORDER_ID        => R_PLN_LG_ORDER.ORDER_HEAD_ID,
                                                            IN_PROJ_NUMBER     => NULL,
                                                            IN_DISCOUNT_TYPE   => NVL(R_PARAM_LINE.DISCOUNT_TYPE, DISCOUNT_TYPE_COMMON),
                                                            IN_AMOUNT          => ROUND(V_CANCEL_AMOUNT, 2),
                                                            IN_DIS_AMOUNT      => ROUND(V_CANCEL_DIS_AMOUNT, 2),
                                                            IN_RECORD_ERR      => 'N',
                                                            IN_USER_CODE       => IN_USER_CODE,
                                                            OUT_RESULT         => OUT_RESULT);
                    END IF;
                    
                    IF OUT_RESULT <> V_SUCCESS THEN
                      OUT_RESULT := '销售转采购（差异数量取消订单）处理客户款项失败！' || V_NL || OUT_RESULT;
                    END IF;
                  END IF;
                
                  --批文锁定处理
                  IF OUT_RESULT = V_SUCCESS AND
                     R_PLN_LG_LINE.PROJECT_ORDER_TYPE IS NOT Null And nvl(r_pln_lg_line.price_apply_id,-1) <> -1 THEN
                    V_IN_PARAM := '单据号=' || R_PLN_LG_ORDER.ORDER_NUMBER || V_NL ||
                                  '批文号=' ||
                                  R_PLN_LG_LINE.PROJECT_ORDER_NUMBER || V_NL ||
                                  '产品编码=' || R_PLN_LG_LINE.ITEM_CODE || V_NL ||
                                  '批文行ID=' ||
                                  TO_CHAR(R_PLN_LG_LINE.PROJECT_ORDER_LINE_ID);
                    PKG_BD_PRICE.P_APPLY_UNLOCK(P_APPLY_DETAIL_ID => R_PLN_LG_LINE.PROJECT_ORDER_LINE_ID, --批文明细ID
                                                P_UNLOCK_CNT      => V_CANCEL_QTY, --解除锁定数量
                                                P_BILL_NO         => R_PLN_LG_ORDER.ORDER_NUMBER, --关联单号
                                                P_RETURN_CODE     => V_RESULT, --返回编码，1成功，0失败
                                                P_RETURN_MSG      => OUT_RESULT);
                    IF V_RESULT = '1' THEN
                      OUT_RESULT := V_SUCCESS;
                    END IF;
                  END IF;
                
                  IF OUT_RESULT = V_SUCCESS THEN
                    BEGIN
                      V_IN_PARAM := '写入评审明细';
                      INSERT INTO T_PLN_ORDER_REVIEW_INFO
                        (ENTITY_ID, --业务主体
                         ORDER_REVIEW_ID, --订单评审记录ID
                         LOT_NUM, --批次（用于记录订单评审第几次）
                         ORDER_PERIOD, --订单周期（汇总的订单评审，记录订单周期）
                         SOURCE_ORDER_TYPE_ID, --源订单类型ID
                         ORDER_TYPE_ID, --订单类型ID
                         ORDER_STATE, --订单状态（送审、汇总、库评、产地分解等）
                         ORDER_TYPE_NAME, --订单类型名称
                         ORDER_NUMBER, --订单号（单单评审，记录订单号）
                         HQ_DATE, --总部评审日期
                         HQ_USER, --总部评审人员
                         REMARK, --备注
                         CREATED_BY, --创建人
                         CREATION_DATE, --创建日期
                         LAST_UPDATED_BY, --最后修改人
                         LAST_UPDATE_DATE, --最后修改日期
                         PRE_FIELD_01, --预留字段1
                         PRE_FIELD_02, --预留字段2
                         PRE_FIELD_03, --预留字段3
                         PRE_FIELD_04, --预留字段4
                         PRE_FIELD_05, --预留字段5
                         PRE_FIELD_06, --预留字段6
                         ORIGIN_ORDER_HEAD_ID, --来源订单头ID
                         ORIGIN_ORDER_LINE_ID, --来源订单行ID
                         ITEM_ID, --产品ID
                         ITEM_CODE, --产品编码
                         ITEM_NAME, --产品描述
                         AFFIRM_QTY, --评审数量
                         RECEIVE_INVENTORY_ID, --收货仓库ID
                         SEND_INVENTORY_ID, --发货仓库ID
                         IS_CANCEL_DIRECT_SEND,
                         CHECKUP_CONTENT, --评审意见  add by lilh6 160909
                         CUSTOMER_ORDER_NUMBER, --客户订单号 add by lilh6 160909
                         CONSIGNEE_ADDR_NAME --收货地址 add by lilh6 160920
                         )
                      VALUES
                        (R_PLN_LG_ORDER.ENTITY_ID, --业务主体
                         S_PLN_ORDER_REVIEW_INFO.NEXTVAL, --订单评审记录ID
                         (SELECT COUNT(1)
                            FROM T_PLN_ORDER_REVIEW_INFO RI
                           WHERE RI.ORIGIN_ORDER_HEAD_ID =
                                 R_PLN_LG_ORDER.ORDER_HEAD_ID
                             AND RI.ORIGIN_ORDER_LINE_ID =
                                 R_PLN_LG_LINE.ORDER_LINE_ID) + 1, --批次（用于记录订单评审第几次）
                         NULL, --订单周期（汇总的订单评审，记录订单周期）
                         1, --源订单类型ID
                         R_PLN_LG_ORDER.ORDER_TYPE_ID, --订单类型ID
                         R_PLN_LG_ORDER.ORDER_HEAD_STATE, --订单状态（送审、汇总、库评、产地分解等）
                         R_PLN_LG_ORDER.ORDER_TYPE_NAME, --订单类型名称
                         R_PLN_LG_ORDER.ORDER_NUMBER, --订单号（单单评审，记录订单号）
                         TRUNC(SYSDATE), --总部评审日期
                         IN_USER_CODE, --总部评审人员
                         '销售转采购生成发运计划，差异数量回写订单取消数量', --备注
                         IN_USER_CODE, --创建人
                         SYSDATE, --创建日期
                         IN_USER_CODE, --最后修改人
                         SYSDATE, --最后修改日期
                         NULL, --Pre_Field_01, --预留字段1
                         NULL, --Pre_Field_02, --预留字段2
                         NULL, --Pre_Field_03, --预留字段3
                         NULL, --Pre_Field_04, --预留字段4
                         NULL, --Pre_Field_05, --预留字段5
                         NULL, --Pre_Field_06, --预留字段6
                         R_PLN_LG_ORDER.ORDER_HEAD_ID, --Origin_Order_Head_Id, --来源订单头ID
                         R_PLN_LG_LINE.ORDER_LINE_ID, --Origin_Order_Line_Id, --来源订单行ID
                         R_PLN_LG_LINE.ITEM_ID, --Item_Id, --产品ID
                         R_PLN_LG_LINE.ITEM_CODE, --Item_Code, --产品编码
                         R_PLN_LG_LINE.ITEM_NAME, --Item_Name, --产品描述
                         (-1) * V_CANCEL_QTY, --Affirm_Qty --评审数量
                         NULL, --收货仓库ID
                         NULL, --发货仓库ID
                         'N', --add by xuhongjiu 2016-05-05
                         R_PLN_LG_ORDER.CHECKUP_CONTENT, --评审意见 add by lilh6 160909
                         R_PLN_LG_ORDER.CUSTOMER_ORDER_NUMBER, --客户订单号 add by lilh6 160909
                         R_PLN_LG_ORDER.CONSIGNEE_ADDR_NAME --收货地址 add by lilh6 160920
                         );
                    EXCEPTION
                      WHEN OTHERS THEN
                        OUT_RESULT := '插入评审记录信息失败，失败原因：' || SQLERRM;
                    END;
                  END IF;
                EXCEPTION
                  WHEN NO_DATA_FOUND THEN
                    NULL;
                END;
              END IF; --实收正品数大于0才处理end
            END IF;
          
            IF OUT_RESULT <> V_SUCCESS THEN
              EXIT;
            END IF;
          END LOOP;
        END IF;
      
        --更新提货订单状态
        IF R_PLN_LG_ORDER.ORDER_HEAD_ID IS NOT NULL THEN
          SELECT SUM(NVL(L.CENTER_AFFIRM_QUANTITY, L.QUANTITY)),
                 SUM(L.AFFIRMED_QUANTITY),
                 SUM(L.CANCEL_QTY)
            INTO V_SUM_LG_ORDER_QTY,
                 V_SUM_LG_ORDER_AFFIRMED_QTY,
                 V_SUM_LG_ORDER_CANCEL_QTY
            FROM T_PLN_LG_ORDER_LINE L
           WHERE L.ORDER_HEAD_ID = R_PLN_LG_ORDER.ORDER_HEAD_ID
             AND NVL(L.ORDER_LINE_STATE, 'NORMAL') <> 'CLOSED';
        
          IF NVL(V_SUM_LG_ORDER_AFFIRMED_QTY, 0) +
             NVL(V_SUM_LG_ORDER_CANCEL_QTY, 0) >= V_SUM_LG_ORDER_QTY THEN
            V_LG_ORDER_NEXT_STATE := 23;
          ELSIF NVL(V_SUM_LG_ORDER_AFFIRMED_QTY, 0) = 0 THEN
            V_LG_ORDER_NEXT_STATE := R_PLN_LG_ORDER.ORDER_HEAD_STATE;
          ELSE
            V_LG_ORDER_NEXT_STATE := 1455;
          END IF;
        
          UPDATE T_PLN_LG_ORDER_HEAD H
             SET H.ORDER_HEAD_STATE = V_LG_ORDER_NEXT_STATE,
                 H.CENTER_CHECKUP_DATE = SYSDATE,
                 H.LAST_UPDATED_BY  = IN_USER_CODE,
                 H.LAST_UPDATE_DATE = SYSDATE
           WHERE H.ORDER_HEAD_ID = R_PLN_LG_ORDER.ORDER_HEAD_ID;
        END IF;
      END IF;
    END IF;
  
    IF OUT_RESULT <> V_SUCCESS THEN
      OUT_SHIP_BATCH := NULL; --出错置成空
      RAISE V_BASE_EXCEPTION;
    END IF;
  EXCEPTION
    WHEN V_BASE_EXCEPTION THEN
      ROLLBACK TO SAVEPOINT SP_TO_CUST_SHIP_PLAN_USEPARAM;
      OUT_RESULT := '生成客户发运计划/发货通知单出错，错误提示：' || OUT_RESULT || V_NL ||
                    V_IN_PARAM;
    WHEN OTHERS THEN
      ROLLBACK TO SAVEPOINT SP_TO_CUST_SHIP_PLAN_USEPARAM;
      OUT_RESULT := '生成客户发运计划/发货通知单出错，错误提示：' || SQLERRM || V_NL ||
                    V_IN_PARAM;
  END P_TO_CUST_SHIP_PLAN_USEPARAM;

  ---------------------------------------------------------
  --提货订单二次发运库存占用
  ---------------------------------------------------------
  PROCEDURE P_LG_ORDER_PRE_INV_OCCUPY(IN_ENTITY_ID     IN NUMBER, --主体ID
                                      IN_ORDER_HEAD_ID IN NUMBER, --提货订单ID
                                      IN_ORDER_LINE_ID IN NUMBER, --提货订单行ID
                                      IN_OCCUPY_SIGN   IN NUMBER, --占用类型，1 占用，-1 释放
                                      IN_USER_CODE     IN VARCHAR2, --操作用户
                                      OUT_RESULT       IN OUT VARCHAR2) IS
    R_PLN_LG_HEAD            T_PLN_LG_ORDER_HEAD%ROWTYPE;
    V_ORIGIN_TYPE            T_PLN_ORDER_INV_OCCUPY.ORIGIN_TYPE%TYPE; --锁定类型
    V_ERR_NUM                NUMBER; --错误号
    V_COUNT                  NUMBER;
    V_INV_ITEM_USABLE_QTY    NUMBER; --库存可用量
    V_PLN_WIP_ORD_MATCH_FLAG VARCHAR2(100);
  BEGIN
    OUT_RESULT := V_SUCCESS;
    --获取提货订单
    SELECT H.*
      INTO R_PLN_LG_HEAD
      FROM T_PLN_LG_ORDER_HEAD H
     WHERE H.ORDER_HEAD_ID = IN_ORDER_HEAD_ID;
  
    BEGIN
      V_PLN_WIP_ORD_MATCH_FLAG := PKG_BD.F_GET_PARAMETER_VALUE(P_CONFIG_CODE => 'PLN_WIP_ORD_MATCH',
                                                               P_ENTITY_ID   => R_PLN_LG_HEAD.ENTITY_ID);
    EXCEPTION
      WHEN OTHERS THEN
        OUT_RESULT := '获取PLN_WIP_ORD_MATCH主体参数失败！' || V_NL || SQLERRM;
    END;
  
    IF OUT_RESULT = V_SUCCESS AND IN_OCCUPY_SIGN NOT IN (1, -1) THEN
      OUT_RESULT := '传入参数无效，占用类型必须为1或-1！';
    END IF;
  
    IF OUT_RESULT = V_SUCCESS THEN
      V_ORIGIN_TYPE := '二次发运';
      FOR R_LINE IN (SELECT L.*
                       FROM T_PLN_LG_ORDER_LINE L
                      WHERE L.ORDER_HEAD_ID = R_PLN_LG_HEAD.ORDER_HEAD_ID
                        AND L.ORDER_LINE_ID = IN_ORDER_LINE_ID
                        AND NVL(L.AFFIRM_QUANTITY, 0) > 0) LOOP
      
        IF IN_OCCUPY_SIGN = 1 THEN
          --获取库存可用量
          V_INV_ITEM_USABLE_QTY := PKG_INV_PUB.F_GET_ITEM_INV_QOH(P_ENTITY_ID         => R_PLN_LG_HEAD.ENTITY_ID,
                                                                  P_INVENTORY_ID      => R_LINE.INV_ID,
                                                                  P_ITEM_ID           => R_LINE.ITEM_ID,
                                                                  P_USER_CODE         => IN_USER_CODE,
                                                                  P_GET_QOH_TYPE      => 2,
                                                                  P_COUNT_OCCOUP_FLAG => V_PLN_WIP_ORD_MATCH_FLAG);
        
          --检查可用量是否足够                                                        
          IF V_INV_ITEM_USABLE_QTY < NVL(R_LINE.AFFIRM_QUANTITY, 0) THEN
            OUT_RESULT := '产品编码：' || R_LINE.ITEM_CODE || '，仓库编码：' ||
                          R_LINE.INV_CODE || '，库存可用量无法满足本次预占用数。库存可用量(' ||
                          TO_CHAR(V_INV_ITEM_USABLE_QTY) || ') < 本次预占用数量(' ||
                          TO_CHAR(R_LINE.AFFIRM_QUANTITY) || ')';
          END IF;
        END IF;
      
        IF OUT_RESULT = V_SUCCESS THEN
          --插入预占用历史
          BEGIN
            INSERT INTO T_PLN_LG_PRE_INV_OCC_HIS
              (ENTITY_ID,
               PRE_INV_OCC_HIS_ID,
               ORDER_HEAD_ID,
               ORDER_NUMBER,
               ORDER_LINE_ID,
               INV_ID,
               ITEM_ID,
               QUANTITY,
               OPT_TYPE,
               VERSION,
               CREATED_BY,
               CREATION_DATE,
               LAST_UPDATED_BY,
               LAST_UPDATE_DATE)
            VALUES
              (R_PLN_LG_HEAD.ENTITY_ID,
               S_PLN_LG_PRE_INV_OCC_HIS.NEXTVAL,
               R_PLN_LG_HEAD.ORDER_HEAD_ID,
               R_PLN_LG_HEAD.ORDER_NUMBER,
               R_LINE.ORDER_LINE_ID,
               R_LINE.INV_ID,
               R_LINE.ITEM_ID,
               IN_OCCUPY_SIGN * R_LINE.AFFIRM_QUANTITY,
               DECODE(IN_OCCUPY_SIGN,
                      1,
                      '二次发运占用',
                      -1,
                      '二次发运释放占用'),
               1,
               IN_USER_CODE,
               SYSDATE,
               IN_USER_CODE,
               SYSDATE);
          EXCEPTION
            WHEN OTHERS THEN
              OUT_RESULT := '插入预占用历史表失败！' || V_NL || '系统提示：' || SQLERRM;
          END;
        END IF;
      
        IF OUT_RESULT = V_SUCCESS THEN
          IF IN_OCCUPY_SIGN = 1 THEN
            --执行预占用库存
            PKG_PLN_INV_OCCUPY.P_AFFIRM_OCCUPY_STOCKS(P_INVENTORY_ID      => R_LINE.INV_ID,
                                                      P_ITEM_ID           => R_LINE.ITEM_ID,
                                                      P_OCCUPY_QTY        => R_LINE.AFFIRM_QUANTITY,
                                                      P_MATCH_PLN_TO_WIP  => 'A',
                                                      P_ACTION_DESC       => '提货订单二次发运库存预占用',
                                                      P_ENTITY_ID         => R_PLN_LG_HEAD.ENTITY_ID,
                                                      P_ORIGIN_TYPE       => V_ORIGIN_TYPE,
                                                      P_ORIGIN_HEAD_ID    => R_PLN_LG_HEAD.ORDER_HEAD_ID,
                                                      P_ORIGIN_NUMBER     => R_PLN_LG_HEAD.ORDER_NUMBER,
                                                      P_ORIGIN_LINE_ID    => R_LINE.ORDER_LINE_ID,
                                                      P_SOURCE_ORDER_TYPE => R_PLN_LG_HEAD.ORDER_TYPE_NAME,
                                                      P_SOURCE_HEAD_ID    => R_PLN_LG_HEAD.ORDER_HEAD_ID,
                                                      P_SOURCE_NUMBER     => R_PLN_LG_HEAD.ORDER_NUMBER,
                                                      P_SOURCE_LINE_ID    => R_LINE.ORDER_LINE_ID,
                                                      P_USER_CODE         => IN_USER_CODE,
                                                      P_RESULT            => V_ERR_NUM,
                                                      P_ERR_MSG           => OUT_RESULT);
          ELSE
            --执行库存释放
            PKG_PLN_INV_OCCUPY.P_AFFIRM_UNOCCUPY_STOCKS(P_INVENTORY_ID      => R_LINE.INV_ID,
                                                        P_ITEM_ID           => R_LINE.ITEM_ID,
                                                        P_OCCUPY_QTY        => R_LINE.AFFIRM_QUANTITY,
                                                        P_MATCH_PLN_TO_WIP  => 'A',
                                                        P_ACTION_DESC       => '提货订单二次发运库存预占用释放',
                                                        P_ENTITY_ID         => R_PLN_LG_HEAD.ENTITY_ID,
                                                        P_ORIGIN_TYPE       => V_ORIGIN_TYPE,
                                                        P_ORIGIN_HEAD_ID    => R_PLN_LG_HEAD.ORDER_HEAD_ID,
                                                        P_ORIGIN_NUMBER     => R_PLN_LG_HEAD.ORDER_NUMBER,
                                                        P_ORIGIN_LINE_ID    => R_LINE.ORDER_LINE_ID,
                                                        P_SOURCE_ORDER_TYPE => R_PLN_LG_HEAD.ORDER_TYPE_NAME,
                                                        P_SOURCE_HEAD_ID    => R_PLN_LG_HEAD.ORDER_HEAD_ID,
                                                        P_SOURCE_NUMBER     => R_PLN_LG_HEAD.ORDER_NUMBER,
                                                        P_SOURCE_LINE_ID    => R_LINE.ORDER_LINE_ID,
                                                        P_USER_CODE         => IN_USER_CODE,
                                                        P_ALLOW_NO_OCCUPY   => 'N',
                                                        P_RESULT            => V_ERR_NUM,
                                                        P_ERR_MSG           => OUT_RESULT);
          END IF;
        END IF;
      
        IF OUT_RESULT = V_SUCCESS THEN
          --二次发运评审明细
          UPDATE T_PLN_LG_ORDER_SHIP_REVIEW R
             SET R.REVIEW_QTY       = NVL(R.REVIEW_QTY, 0) +
                                      IN_OCCUPY_SIGN *
                                      R_LINE.AFFIRM_QUANTITY,
                 R.LAST_UPDATED_BY  = IN_USER_CODE,
                 R.LAST_UPDATE_DATE = SYSDATE
           WHERE R.ORDER_LINE_ID = R_LINE.ORDER_LINE_ID
             AND R.SHIP_INVENTORY_ID = R_LINE.INV_ID
             AND R.REVIEW_TYPE = 'SECOND_SEND_PRE_OCCUPY';
        
          --找不到则新增
          IF SQL%NOTFOUND AND IN_OCCUPY_SIGN = 1 THEN
            BEGIN
              INSERT INTO T_PLN_LG_ORDER_SHIP_REVIEW
                (ENTITY_ID,
                 SHIP_REVIEW_ID,
                 REVIEW_BATCH_ID,
                 ORDER_LINE_ID,
                 ORDER_HEAD_ID,
                 ITEM_ID,
                 ITEM_CODE,
                 ITEM_NAME,
                 REVIEW_TYPE,
                 REVIEW_QTY,
                 SHIP_INVENTORY_ID,
                 SHIP_INVENTORY_CODE,
                 SHIP_INVENTORY_NAME,
                 REVIEW_STATUS,
                 CREATED_BY,
                 CREATION_DATE,
                 LAST_UPDATED_BY,
                 LAST_UPDATE_DATE,
                 REMARK,
                 VERSION,
                 LG_ORDER_NUMBER)
              VALUES
                (R_LINE.ENTITY_ID,
                 S_PLN_LG_ORDER_SHIP_REVIEW.NEXTVAL,
                 1,
                 R_LINE.ORDER_LINE_ID,
                 R_LINE.ORDER_HEAD_ID,
                 R_LINE.ITEM_ID,
                 R_LINE.ITEM_CODE,
                 R_LINE.ITEM_NAME,
                 'SECOND_SEND_PRE_OCCUPY',
                 R_LINE.AFFIRM_QUANTITY,
                 R_LINE.INV_ID,
                 R_LINE.INV_CODE,
                 R_LINE.INV_NAME,
                 'Y',
                 IN_USER_CODE,
                 SYSDATE,
                 IN_USER_CODE,
                 SYSDATE,
                 NULL,
                 1,
                 R_PLN_LG_HEAD.ORDER_NUMBER);
            EXCEPTION
              WHEN OTHERS THEN
                OUT_RESULT := '插入二次发运评审明细失败！' || V_NL || '系统提示：' || SQLERRM;
            END;
          END IF;
        END IF;
      
        IF OUT_RESULT = V_SUCCESS THEN
          --更新提货订单行预占用数量
          UPDATE T_PLN_LG_ORDER_LINE L
             SET L.LOCK_INV_PRE     = NVL(L.LOCK_INV_PRE, 0) +
                                      IN_OCCUPY_SIGN *
                                      R_LINE.AFFIRM_QUANTITY,
                 L.AFFIRM_QUANTITY  = NULL,
                 L.INV_ID           = 0,
                 L.INV_CODE         = NULL,
                 L.INV_NAME         = NULL,
                 L.LAST_UPDATED_BY  = IN_USER_CODE,
                 L.LAST_UPDATE_DATE = SYSDATE,
                 L.VERSION = NVL(L.VERSION, 0) + 1
           WHERE L.ORDER_LINE_ID = R_LINE.ORDER_LINE_ID;
        
          --设置订单头的预占用标志
          /*UPDATE T_PLN_LG_ORDER_HEAD H
            SET H.PRE_INV_OCCUPY_FLAG = DECODE(SIGN((SELECT COUNT(1) FROM T_PLN_LG_ORDER_LINE L
                                                     WHERE L.ORDER_HEAD_ID = H.ORDER_HEAD_ID
                                                       AND L.LOCK_INV_PRE > 0)),
                                               1, 'Y', 'N'),
                H.LAST_UPDATED_BY = IN_USER_CODE,
                H.LAST_UPDATE_DATE = SYSDATE
          WHERE H.ORDER_HEAD_ID = IN_ORDER_HEAD_ID;*/
        END IF;
      
        IF OUT_RESULT <> V_SUCCESS THEN
          EXIT; --退出循环
        END IF;
      END LOOP;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      OUT_RESULT := '预占用失败！系统提示：' || SQLERRM;
  END P_LG_ORDER_PRE_INV_OCCUPY;

  ---------------------------------------------------------
  --生成预占用数据，用于提货订单二次发运
  --销售单为非直发，但是有来源客户提货订单
  ---------------------------------------------------------
  PROCEDURE P_PRE_INV_OCCUPY_USEPARAM(IN_ENTITY_ID IN NUMBER, --主体ID
                                      IN_PARAM_ID  IN NUMBER, --转采购参数表ID
                                      IN_USER_CODE IN VARCHAR2, --操作用户
                                      OUT_RESULT   IN OUT VARCHAR2) IS
    R_PARAM_HEAD        T_SO_TO_SUPP_PARAM_HEAD%ROWTYPE;
    R_PLN_LG_ORDER      T_PLN_LG_ORDER_HEAD%ROWTYPE;
    R_SO_HEAD           T_SO_HEADER%ROWTYPE; --总部销售单
    V_IN_PARAM          VARCHAR2(4000);
    V_ASS_ITEM_CODE     T_SO_TO_SUPP_PARAM_LINE.ASS_ITEM_CODE%TYPE;
    V_REMAIN_REV_QTY    NUMBER;
    V_CURR_ORDER_QTY    NUMBER;
    V_CURR_LOCK_QTY     NUMBER;
    V_COUNT             NUMBER;
    V_SECOND_SEND_ORDER VARCHAR2(4000) := '可做二次发运订单：';
  
    V_REMAIN_DIFF_QTY   NUMBER;
    V_CURR_CANCEL_QTY   NUMBER;
    V_CANCEL_AMOUNT     NUMBER;
    V_CANCEL_DIS_AMOUNT NUMBER;
    OUT_ERR_NUM         NUMBER;
    V_OS_ATTRIB01       VARCHAR2(1000);
    V_OS_ATTRIB02       VARCHAR2(1000);
    V_RESULT            VARCHAR2(10);
  BEGIN
    OUT_RESULT := V_SUCCESS;
    SAVEPOINT SP_PRE_INV_OCCUPY_USEPARAM;
  
    --锁定转采购参数表数据
    V_IN_PARAM := '转采购参数表ID=' || TO_CHAR(IN_PARAM_ID);
    BEGIN
      SELECT *
        INTO R_PARAM_HEAD
        FROM T_SO_TO_SUPP_PARAM_HEAD H
       WHERE H.PARAM_ID = IN_PARAM_ID;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        OUT_RESULT := '传入参数有误，找不到转采购的数据！';
    END;
  
    --获取来源销售单
    IF OUT_RESULT = V_SUCCESS THEN
      V_IN_PARAM := '销售单ID=' || TO_CHAR(R_PARAM_HEAD.SOURCE_ORDER_ID) ||
                    ',销售单号=' || R_PARAM_HEAD.SOURCE_ORDER_NUMBER;
      BEGIN
        SELECT H.*
          INTO R_SO_HEAD
          FROM T_SO_HEADER H
         WHERE H.SO_HEADER_ID = R_PARAM_HEAD.SOURCE_ORDER_ID;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          OUT_RESULT := '找不到转采购的销售单！';
      END;
    END IF;
  
    IF OUT_RESULT = V_SUCCESS THEN
      IF (NVL(R_SO_HEAD.DIRECT_SHIP_FLAG, V_NO) <> V_YES AND
         NVL(R_SO_HEAD.SELF_PICK_FLAG, V_NO) <> V_YES) OR
         --20171201 hejy3 自提二次发运
        (nvl(R_SO_HEAD.Self_Pick_Flag, V_NO) = V_YES and nvl(R_PARAM_HEAD.Pick_Need_Second_Send, V_NO) = V_YES)
      THEN
        V_ASS_ITEM_CODE := '_';
        --循环入库的产品
        FOR R_PARAM_LINE IN (SELECT *
                               FROM T_SO_TO_SUPP_PARAM_LINE L
                              WHERE L.PARAM_ID = IN_PARAM_ID
                              ORDER BY L.ASS_ITEM_CODE,
                                       FLOOR(NVL(L.FACT_REV_GOOD_QTY, 0)/NVL(L.SUB_ITEM_QTY_SCALE,1))) LOOP
          IF OUT_RESULT = V_SUCCESS THEN
            IF V_ASS_ITEM_CODE <> R_PARAM_LINE.ASS_ITEM_CODE THEN
              V_ASS_ITEM_CODE := R_PARAM_LINE.ASS_ITEM_CODE;
              IF FLOOR(R_PARAM_LINE.FACT_REV_GOOD_QTY/NVL(R_PARAM_LINE.SUB_ITEM_QTY_SCALE,1)) > 0 THEN
                --实收正品数大于0才处理
                V_REMAIN_REV_QTY := FLOOR(R_PARAM_LINE.FACT_REV_GOOD_QTY/NVL(R_PARAM_LINE.SUB_ITEM_QTY_SCALE,1));
                
                --先按匹配关系获取
                FOR R_LG_ORDER_LINE IN (SELECT H.ORDER_NUMBER, L.*
                                          FROM T_PLN_LG_ORDER_HEAD H,
                                               T_PLN_LG_ORDER_LINE L
                                         WHERE H.HQ_LG_ORDER_HEAD_ID = NVL(R_SO_HEAD.ORIGIN_ORIGIN_HEAD_ID, R_SO_HEAD.RAW_SRC_BILL_ID)
                                           AND H.ORDER_HEAD_ID = L.ORDER_HEAD_ID
                                           AND L.ITEM_CODE = R_PARAM_LINE.ASS_ITEM_CODE
                                           AND NVL(L.SHARE_VENDOR_TYPE, '_') <> 'AGENT'
                                           AND NVL(L.CENTER_AFFIRM_QUANTITY, L.QUANTITY) -
                                               NVL(L.CENTER_AFFIRMED_QTY, 0) -
                                               NVL(L.HQ_AFFIRMED_QTY, 0) -
                                               NVL(L.CANCEL_QTY, 0) -
                                               NVL(L.LOCK_INV_PRE, 0) > 0
                                           AND NVL(L.ORDER_LINE_STATE, 'NORMAL') <> 'CLOSED' --行未关闭
                                           AND H.ORDER_HEAD_STATE <> '304' --单未关闭
                                           AND EXISTS (SELECT 1 FROM T_PLN_SHIP_SCORDER_MATCH SM
                                                        WHERE SM.SC_LG_ORDER_HEAD_ID = H.ORDER_HEAD_ID
                                                          AND SM.MATCH_TYPE = 'SHIP_DOC'
                                                          AND SM.SHIP_DOC_ID = R_SO_HEAD.SHIP_DOC_ID)
                                         ORDER BY H.TO_CHECKUP_DATE) --按送审时间从前往后排序
                 LOOP
                  --当前订单可占用量=申请量-中心库评量-总部库评量-已预占用量
                  V_CURR_ORDER_QTY := NVL(R_LG_ORDER_LINE.CENTER_AFFIRM_QUANTITY,
                                          R_LG_ORDER_LINE.QUANTITY) -
                                      NVL(R_LG_ORDER_LINE.CENTER_AFFIRMED_QTY,
                                          0) - NVL(R_LG_ORDER_LINE.HQ_AFFIRMED_QTY,
                                                   0) -
                                      NVL(R_LG_ORDER_LINE.CANCEL_QTY, 0) -
                                      NVL(R_LG_ORDER_LINE.LOCK_INV_PRE, 0);
                
                  IF V_CURR_ORDER_QTY <= V_REMAIN_REV_QTY THEN
                    V_CURR_LOCK_QTY := V_CURR_ORDER_QTY;
                  ELSE
                    V_CURR_LOCK_QTY := V_REMAIN_REV_QTY;
                  END IF;
                  V_REMAIN_REV_QTY := V_REMAIN_REV_QTY - V_CURR_LOCK_QTY;
                
                  IF V_CURR_LOCK_QTY > 0 THEN
                    IF INSTR(V_SECOND_SEND_ORDER,
                             R_LG_ORDER_LINE.ORDER_NUMBER) <= 0 THEN
                      IF V_SECOND_SEND_ORDER = '可做二次发运订单：' THEN
                        V_SECOND_SEND_ORDER := V_SECOND_SEND_ORDER ||
                                               R_LG_ORDER_LINE.ORDER_NUMBER;
                      ELSE
                        V_SECOND_SEND_ORDER := V_SECOND_SEND_ORDER || ',' ||
                                               R_LG_ORDER_LINE.ORDER_NUMBER;
                      END IF;
                    END IF;
                  
                    UPDATE T_PLN_LG_ORDER_LINE L
                       SET L.AFFIRM_QUANTITY = V_CURR_LOCK_QTY,
                           L.INV_ID          = R_PARAM_HEAD.FINANCE_INV_ID,
                           L.INV_CODE        = R_PARAM_HEAD.FINANCE_INV_CODE,
                           L.INV_NAME        = R_PARAM_HEAD.FINANCE_INV_NAME
                     WHERE L.ORDER_LINE_ID = R_LG_ORDER_LINE.ORDER_LINE_ID;
                  
                    --做预占用
                    PKG_SO_TO_POX.P_LG_ORDER_PRE_INV_OCCUPY(IN_ENTITY_ID     => R_PARAM_HEAD.ENTITY_ID,
                                                            IN_ORDER_HEAD_ID => R_LG_ORDER_LINE.ORDER_HEAD_ID,
                                                            IN_ORDER_LINE_ID => R_LG_ORDER_LINE.ORDER_LINE_ID,
                                                            IN_OCCUPY_SIGN   => 1,
                                                            IN_USER_CODE     => IN_USER_CODE,
                                                            OUT_RESULT       => OUT_RESULT);
                  END IF;
                
                  IF OUT_RESULT <> V_SUCCESS OR V_REMAIN_REV_QTY <= 0 THEN
                    EXIT;
                  END IF;
                END LOOP;
                
                --按来源客户提货订单循环处理
                FOR R_LG_ORDER_LINE IN (SELECT H.ORDER_NUMBER, L.*
                                          FROM T_PLN_LG_ORDER_HEAD H,
                                               T_PLN_LG_ORDER_LINE L
                                         WHERE H.HQ_LG_ORDER_HEAD_ID =
                                               NVL(R_SO_HEAD.ORIGIN_ORIGIN_HEAD_ID,
                                                   R_SO_HEAD.RAW_SRC_BILL_ID)
                                           AND H.ORDER_HEAD_ID =
                                               L.ORDER_HEAD_ID
                                           AND L.ITEM_CODE =
                                               R_PARAM_LINE.ASS_ITEM_CODE
                                           AND NVL(L.SHARE_VENDOR_TYPE, '_') <> 'AGENT'
                                           AND NVL(L.CENTER_AFFIRM_QUANTITY,
                                                   L.QUANTITY) -
                                               NVL(L.CENTER_AFFIRMED_QTY, 0) -
                                               NVL(L.HQ_AFFIRMED_QTY, 0) -
                                               NVL(L.CANCEL_QTY, 0) -
                                               NVL(L.LOCK_INV_PRE, 0) > 0
                                           AND NVL(L.ORDER_LINE_STATE,
                                                   'NORMAL') <> 'CLOSED' --行未关闭
                                           AND H.ORDER_HEAD_STATE <> '304' --单未关闭
                                         ORDER BY H.TO_CHECKUP_DATE) --按送审时间从前往后排序
                 LOOP
                  --当前订单可占用量=申请量-中心库评量-总部库评量-已预占用量
                  V_CURR_ORDER_QTY := NVL(R_LG_ORDER_LINE.CENTER_AFFIRM_QUANTITY,
                                          R_LG_ORDER_LINE.QUANTITY) -
                                      NVL(R_LG_ORDER_LINE.CENTER_AFFIRMED_QTY,
                                          0) - NVL(R_LG_ORDER_LINE.HQ_AFFIRMED_QTY,
                                                   0) -
                                      NVL(R_LG_ORDER_LINE.CANCEL_QTY, 0) -
                                      NVL(R_LG_ORDER_LINE.LOCK_INV_PRE, 0);
                
                  IF V_CURR_ORDER_QTY <= V_REMAIN_REV_QTY THEN
                    V_CURR_LOCK_QTY := V_CURR_ORDER_QTY;
                  ELSE
                    V_CURR_LOCK_QTY := V_REMAIN_REV_QTY;
                  END IF;
                  V_REMAIN_REV_QTY := V_REMAIN_REV_QTY - V_CURR_LOCK_QTY;
                
                  IF V_CURR_LOCK_QTY > 0 THEN
                    IF INSTR(V_SECOND_SEND_ORDER,
                             R_LG_ORDER_LINE.ORDER_NUMBER) <= 0 THEN
                      IF V_SECOND_SEND_ORDER = '可做二次发运订单：' THEN
                        V_SECOND_SEND_ORDER := V_SECOND_SEND_ORDER ||
                                               R_LG_ORDER_LINE.ORDER_NUMBER;
                      ELSE
                        V_SECOND_SEND_ORDER := V_SECOND_SEND_ORDER || ',' ||
                                               R_LG_ORDER_LINE.ORDER_NUMBER;
                      END IF;
                    END IF;
                  
                    UPDATE T_PLN_LG_ORDER_LINE L
                       SET L.AFFIRM_QUANTITY = V_CURR_LOCK_QTY,
                           L.INV_ID          = R_PARAM_HEAD.FINANCE_INV_ID,
                           L.INV_CODE        = R_PARAM_HEAD.FINANCE_INV_CODE,
                           L.INV_NAME        = R_PARAM_HEAD.FINANCE_INV_NAME
                     WHERE L.ORDER_LINE_ID = R_LG_ORDER_LINE.ORDER_LINE_ID;
                  
                    --做预占用
                    PKG_SO_TO_POX.P_LG_ORDER_PRE_INV_OCCUPY(IN_ENTITY_ID     => R_PARAM_HEAD.ENTITY_ID,
                                                            IN_ORDER_HEAD_ID => R_LG_ORDER_LINE.ORDER_HEAD_ID,
                                                            IN_ORDER_LINE_ID => R_LG_ORDER_LINE.ORDER_LINE_ID,
                                                            IN_OCCUPY_SIGN   => 1,
                                                            IN_USER_CODE     => IN_USER_CODE,
                                                            OUT_RESULT       => OUT_RESULT);
                  END IF;
                
                  IF OUT_RESULT <> V_SUCCESS OR V_REMAIN_REV_QTY <= 0 THEN
                    EXIT;
                  END IF;
                END LOOP; --按来源客户提货订单循环处理end
              END IF; --实收正品数大于0才处理end
            END IF;
          END IF;
          IF OUT_RESULT <> V_SUCCESS THEN
            EXIT;
          END IF;
        END LOOP; --循环入库的产品end
      
        IF OUT_RESULT = V_SUCCESS THEN
          --差异处理
          V_ASS_ITEM_CODE := '_';
          --循环入库的产品
          FOR R_PARAM_LINE IN (SELECT *
                                 FROM T_SO_TO_SUPP_PARAM_LINE L
                                WHERE L.PARAM_ID = IN_PARAM_ID
                                ORDER BY L.ASS_ITEM_CODE,
                                         CEIL((NVL(L.FACT_REV_SHATTER_QTY, 0) +
                                         NVL(L.MISSING_QTY, 0) +
                                         NVL(L.REJECTED_QTY, 0))/NVL(L.SUB_ITEM_QTY_SCALE,1)) DESC) LOOP
            IF OUT_RESULT = V_SUCCESS THEN
              IF V_ASS_ITEM_CODE <> R_PARAM_LINE.ASS_ITEM_CODE THEN
                V_ASS_ITEM_CODE := R_PARAM_LINE.ASS_ITEM_CODE;
                IF CEIL((NVL(R_PARAM_LINE.FACT_REV_SHATTER_QTY, 0) +
                   NVL(R_PARAM_LINE.MISSING_QTY, 0) +
                   NVL(R_PARAM_LINE.REJECTED_QTY, 0))/NVL(R_PARAM_LINE.SUB_ITEM_QTY_SCALE,1)) > 0 THEN
                  --实收破损数+短少数+拒收数大于0才处理
                  V_REMAIN_DIFF_QTY := CEIL((NVL(R_PARAM_LINE.FACT_REV_SHATTER_QTY, 0) +
                                       NVL(R_PARAM_LINE.MISSING_QTY, 0) +
                                       NVL(R_PARAM_LINE.REJECTED_QTY, 0))/NVL(R_PARAM_LINE.SUB_ITEM_QTY_SCALE,1));
                  --按来源客户提货订单循环处理
                  FOR R_LG_ORDER_LINE IN (SELECT H.ORDER_NUMBER          AS HEAD_ORDER_NUMBER,
                                                 H.CUSTOMER_ID           AS HEAD_CUSTOMER_ID,
                                                 H.CUSTOMER_CODE         AS HEAD_CUSTOMER_CODE,
                                                 H.ACCOUNT_ID            AS HEAD_ACCOUNT_ID,
                                                 H.ACCOUNT_CODE          AS HEAD_ACCOUNT_CODE,
                                                 H.ORDER_TYPE_ID         AS HEAD_ORDER_TYPE_ID,
                                                 H.ORDER_TYPE_CODE       AS HEAD_ORDER_TYPE_CODE,
                                                 H.ORDER_TYPE_NAME       AS HEAD_ORDER_TYPE_NAME,
                                                 H.ORDER_HEAD_STATE      AS HEAD_ORDER_HEAD_STATE,
                                                 H.CHECKUP_CONTENT       AS HEAD_CHECKUP_CONTENT,
                                                 H.CUSTOMER_ORDER_NUMBER AS HEAD_CUSTOMER_ORDER_NUMBER,
                                                 H.CONSIGNEE_ADDR_NAME   AS HEAD_CONSIGNEE_ADDR_NAME,
                                                 H.LOCK_AMOUNT_FLAG      AS HEAD_LOCK_AMOUNT_FLAG,
                                                 H.CUSTOMIZE_FLAG        AS HEAD_CUSTOMIZE_FLAG,
                                                 L.*
                                            FROM T_PLN_LG_ORDER_HEAD H,
                                                 T_PLN_LG_ORDER_LINE L
                                           WHERE H.HQ_LG_ORDER_HEAD_ID =
                                                 NVL(R_SO_HEAD.ORIGIN_ORIGIN_HEAD_ID,
                                                     R_SO_HEAD.RAW_SRC_BILL_ID)
                                             AND H.ORDER_HEAD_ID =
                                                 L.ORDER_HEAD_ID
                                             AND L.ITEM_CODE =
                                                 R_PARAM_LINE.ASS_ITEM_CODE
                                             AND NVL(L.SHARE_VENDOR_TYPE, '_') <> 'AGENT'
                                             AND NVL(L.CENTER_AFFIRM_QUANTITY,
                                                     L.QUANTITY) -
                                                 NVL(L.CENTER_AFFIRMED_QTY,
                                                     0) -
                                                 NVL(L.HQ_AFFIRMED_QTY, 0) -
                                                 NVL(L.CANCEL_QTY, 0) -
                                                 NVL(L.LOCK_INV_PRE, 0) > 0
                                             AND NVL(L.ORDER_LINE_STATE,
                                                     'NORMAL') <> 'CLOSED' --行未关闭
                                             AND H.ORDER_HEAD_STATE <> '304' --单未关闭
                                           ORDER BY H.TO_CHECKUP_DATE) --按送审时间从前往后排序
                   LOOP
                    --当前订单可取消量=申请量-中心库评量-总部库评量-已预占用量
                    V_CURR_ORDER_QTY := NVL(R_LG_ORDER_LINE.CENTER_AFFIRM_QUANTITY,
                                            R_LG_ORDER_LINE.QUANTITY) -
                                        NVL(R_LG_ORDER_LINE.CENTER_AFFIRMED_QTY,
                                            0) - NVL(R_LG_ORDER_LINE.HQ_AFFIRMED_QTY,
                                                     0) -
                                        NVL(R_LG_ORDER_LINE.CANCEL_QTY, 0) -
                                        NVL(R_LG_ORDER_LINE.LOCK_INV_PRE, 0);
                  
                    IF V_CURR_ORDER_QTY <= V_REMAIN_DIFF_QTY THEN
                      V_CURR_CANCEL_QTY := V_CURR_ORDER_QTY;
                    ELSE
                      V_CURR_CANCEL_QTY := V_REMAIN_DIFF_QTY;
                    END IF;
                    V_REMAIN_DIFF_QTY := V_REMAIN_DIFF_QTY -
                                         V_CURR_CANCEL_QTY;
                  
                    --取消处理
                    IF V_CURR_CANCEL_QTY > 0 THEN
                      --款项处理
                      SELECT ROUND(DECODE(R_LG_ORDER_LINE.PROJECT_ORDER_TYPE,
                                          NULL,
                                          NVL(R_LG_ORDER_LINE.LIST_PRICE, 0) *
                                          (100 - NVL(R_LG_ORDER_LINE.DISCOUNT_RATE,
                                                     0) -
                                           NVL(R_LG_ORDER_LINE.ORDERED_DISCOUNT_RATE,
                                               0)),
                                          NVL(R_LG_ORDER_LINE.APPLY_LIST_PRICE,
                                              0) * (100 - NVL(R_LG_ORDER_LINE.APPLY_DISCOUNT_RATE,
                                                              0) -
                                                    NVL(R_LG_ORDER_LINE.ORDERED_DISCOUNT_RATE,
                                                        0))) *
                                   NVL(V_CURR_CANCEL_QTY, 0) / 100,
                                   2),
                             ROUND(DECODE(R_LG_ORDER_LINE.PROJECT_ORDER_TYPE,
                                          NULL,
                                          NVL(R_LG_ORDER_LINE.LIST_PRICE, 0) *
                                          NVL(R_LG_ORDER_LINE.DISCOUNT_RATE,
                                              0),
                                          NVL(R_LG_ORDER_LINE.APPLY_LIST_PRICE,
                                              0) * NVL(R_LG_ORDER_LINE.APPLY_DISCOUNT_RATE,
                                                       0)) *
                                   NVL(V_CURR_CANCEL_QTY, 0) / 100,
                                   2)
                        INTO V_CANCEL_AMOUNT, V_CANCEL_DIS_AMOUNT
                        FROM DUAL;
                      
                      IF OUT_RESULT = V_SUCCESS AND R_LG_ORDER_LINE.HEAD_CUSTOMIZE_FLAG = 'Y' THEN
                        --校验款项
                        For r_Check_Amount In (--甲方
                                               Select lol.entity_id,
                                                      be.entity_name,
                                                      h.customer_id,
                                                      H.CUSTOMER_CODE,
                                                      h.account_id,
                                                      H.ACCOUNT_CODE,
                                                      nvl(lol.Sales_Main_Type, bi.sales_main_type) Sales_Main_Type,
                                                      Nvl(lol.DISCOUNT_TYPE, DISCOUNT_TYPE_COMMON) Discount_Type,                                    
                                                      Sum(Round(V_CANCEL_AMOUNT
                                                                * case
                                                                    when lol.customize_flag = 'Y' then
                                                                      -1
                                                                    when nvl(lol.customize_flag, 'N') = 'N' then
                                                                      case
                                                                        when h.lock_amount_flag in (V_LOCK_AMOUNT_FLAG_S, V_LOCK_AMOUNT_FLAG_RS) 
                                                                          or (h.lock_amount_flag = V_LOCK_AMOUNT_FLAG_HQ and hqh.submit_to_hq_flag = 'Y') then
                                                                          -1 * nvl(lol.down_pay_scale, 100) / 100
                                                                        when h.lock_amount_flag in (V_LOCK_AMOUNT_FLAG_Y, V_LOCK_AMOUNT_FLAG_RT) then
                                                                          0
                                                                        else
                                                                          0
                                                                      end
                                                                    else
                                                                      0
                                                                  end,2)) apply_Amount,
                                                      Sum(Round(V_CANCEL_DIS_AMOUNT
                                                                *
                                                                case
                                                                  when lol.customize_flag = 'Y' then
                                                                    -1
                                                                  when nvl(lol.customize_flag, 'N') = 'N' then
                                                                    case
                                                                      when h.lock_amount_flag in (V_LOCK_AMOUNT_FLAG_S, V_LOCK_AMOUNT_FLAG_RS) 
                                                                        or (h.lock_amount_flag = V_LOCK_AMOUNT_FLAG_HQ and hqh.submit_to_hq_flag = 'Y') then
                                                                        -1 * nvl(lol.down_pay_scale, 100) / 100
                                                                      when h.lock_amount_flag in (V_LOCK_AMOUNT_FLAG_Y, V_LOCK_AMOUNT_FLAG_RT) then
                                                                        0
                                                                      else
                                                                        0
                                                                    end
                                                                  else
                                                                    0
                                                                end,2)) Discount_Amount
                                                 From t_Pln_Lg_Order_Line Lol,
                                                      t_Bd_Item Bi,
                                                      t_pln_lg_order_head h,
                                                      v_bd_entity be,
                                                      t_pln_lg_order_head hqh
                                                Where lol.order_head_id = h.order_head_id
                                                  and Lol.Item_Id = Bi.Item_Id
                                                  And Bi.Entity_Id = Lol.Entity_Id
                                                  And Lol.Order_Head_Id = R_LG_ORDER_LINE.Order_Head_Id
                                                  And Lol.Entity_Id = R_LG_ORDER_LINE.Entity_Id
                                                  and h.entity_id = be.entity_id
                                                  and lol.order_line_id = R_LG_ORDER_LINE.Order_Line_Id
                                                  and h.hq_lg_order_head_id = hqh.order_head_id
                                                Group By lol.entity_id,
                                                         be.entity_name,
                                                         h.customer_id,
                                                         h.customer_code,
                                                         h.account_id,
                                                         h.account_code,
                                                         nvl(lol.Sales_Main_Type, bi.sales_main_type),
                                                         Nvl(lol.DISCOUNT_TYPE, DISCOUNT_TYPE_COMMON)
                                                ) Loop
                          PKG_CREDIT_ACCOUNT_CONTROL.P_CREDIT_CHECK_AMOUNT(IN_ENTITY_ID       => r_Check_Amount.Entity_Id,
                                                                           IN_CUSTOMER_ID     => r_Check_Amount.Customer_Id,
                                                                           IN_ACCOUNT_ID      => r_Check_Amount.Account_Id,
                                                                           IN_SALES_MAIN_TYPE => r_Check_Amount.Sales_Main_Type,
                                                                           IN_PROJ_NUMBER     => null,
                                                                           IN_AMOUNT_SUM      => r_Check_Amount.Apply_Amount,
                                                                           IN_DISAMOUNT_SUM   => r_Check_Amount.Discount_Amount,
                                                                           IN_DISCOUNT_TYPE   => r_Check_Amount.Discount_Type,
                                                                           IN_USER_ACCOUNT    => IN_USER_CODE,
                                                                           OUT_RESULT         => OUT_ERR_NUM,
                                                                           OUT_ERR_MSG        => OUT_RESULT);
                          IF OUT_ERR_NUM <> 0 THEN
                            OUT_RESULT := '销售转采购（转二次发运差异数量取消订单）校验客户款项失败！错误提示：'||v_Nl||OUT_RESULT||v_Nl||
                                        '事业部='||r_Check_Amount.entity_name||v_Nl||
                                        '客户ID='||r_Check_Amount.Customer_Id||' 编码='||r_Check_Amount.customer_code||v_Nl||
                                        '账户ID='||r_Check_Amount.Account_Id||' 编码='||r_Check_Amount.account_code||v_Nl||
                                        '营销大类='||r_Check_Amount.Sales_Main_Type||v_Nl||
                                        '折扣类型='||r_Check_Amount.Discount_Type;
                            --raise v_Base_Exception;
                            EXIT;
                          END IF;
                        End Loop;
                        
                        IF OUT_RESULT = V_SUCCESS THEN
                          --锁定款项
                          For r_Check_Amount In (--甲方
                                                 Select lol.entity_id,
                                                        be.entity_name,
                                                        h.customer_id,
                                                        H.CUSTOMER_CODE,
                                                        h.account_id,
                                                        H.ACCOUNT_CODE,
                                                        nvl(lol.sales_main_type, bi.sales_main_type) Sales_Main_Type,
                                                        Nvl(lol.Discount_Type, Discount_Type_Common) Discount_Type,
                                                        decode(lol.customize_flag, 'Y', ah.project_code, null) project_code,
                                                        decode(lol.customize_flag, 'Y', 100, lol.down_pay_scale) down_pay_scale,
                                                        h.order_head_id order_id,
                                                        h.order_number order_number,
                                                        '02' src_type,
                                                        0 apply_Amount,
                                                        0 Discount_Amount,
                                                        Sum(Round(V_CANCEL_AMOUNT
                                                                  * case
                                                                      when lol.customize_flag = 'Y' then
                                                                        -1
                                                                      when nvl(lol.customize_flag, 'N') = 'N' then
                                                                        case
                                                                          when h.lock_amount_flag in (V_LOCK_AMOUNT_FLAG_S, V_LOCK_AMOUNT_FLAG_RS) 
                                                                            or (h.lock_amount_flag = V_LOCK_AMOUNT_FLAG_HQ and hqh.submit_to_hq_flag = 'Y') then
                                                                            -1 * nvl(lol.down_pay_scale, 100) / 100
                                                                          when h.lock_amount_flag in (V_LOCK_AMOUNT_FLAG_Y, V_LOCK_AMOUNT_FLAG_RT) then
                                                                            0
                                                                          else
                                                                            0
                                                                        end
                                                                      else
                                                                        0
                                                                    end,2)) dp_apply_Amount,
                                                        Sum(Round(V_CANCEL_DIS_AMOUNT
                                                                  *
                                                                  case
                                                                    when lol.customize_flag = 'Y' then
                                                                      -1
                                                                    when nvl(lol.customize_flag, 'N') = 'N' then
                                                                      case
                                                                        when h.lock_amount_flag in (V_LOCK_AMOUNT_FLAG_S, V_LOCK_AMOUNT_FLAG_RS) 
                                                                          or (h.lock_amount_flag = V_LOCK_AMOUNT_FLAG_HQ and hqh.submit_to_hq_flag = 'Y') then
                                                                          -1 * nvl(lol.down_pay_scale, 100) / 100
                                                                        when h.lock_amount_flag in (V_LOCK_AMOUNT_FLAG_Y, V_LOCK_AMOUNT_FLAG_RT) then
                                                                          0
                                                                        else
                                                                          0
                                                                      end
                                                                    else
                                                                      0
                                                                  end,2)) dp_Discount_Amount
                                                   From t_Pln_Lg_Order_Line Lol,
                                                        t_Bd_Item Bi,
                                                        t_pln_lg_order_head h,
                                                        v_bd_entity be,
                                                        t_pg_price_apply_head ah,
                                                        t_pln_lg_order_head hqh
                                                  Where lol.order_head_id = h.order_head_id
                                                    and Lol.Item_Id = Bi.Item_Id
                                                    And Bi.Entity_Id = Lol.Entity_Id
                                                    And Lol.Order_Head_Id = R_LG_ORDER_LINE.Order_Head_Id
                                                    And Lol.Entity_Id = R_LG_ORDER_LINE.Entity_Id
                                                    and h.entity_id = be.entity_id
                                                    and lol.entity_id = ah.entity_id(+)
                                                    and lol.project_order_number = ah.apply_code(+)
                                                    and h.hq_lg_order_head_id = hqh.order_head_id
                                                    and lol.order_line_id = R_LG_ORDER_LINE.Order_Line_Id
                                                  Group By lol.entity_id,
                                                           be.entity_name,
                                                           h.customer_id,
                                                           h.customer_code,
                                                           h.account_id,
                                                           h.account_code,
                                                           nvl(lol.sales_main_type, bi.sales_main_type),
                                                           Nvl(lol.Discount_Type, Discount_Type_Common),
                                                           decode(lol.customize_flag, 'Y', ah.project_code, null),
                                                           decode(lol.customize_flag, 'Y', 100, lol.down_pay_scale),
                                                           h.order_head_id,
                                                           h.order_number
                                                  ) Loop
                            PKG_CREDIT_ACCOUNT_CONTROL.P_CREDIT_LOCK_DETAIL_HAND(IN_ENTITY_ID   => r_Check_Amount.Entity_Id,
                                                                             IN_CUSTOMER_ID     => r_Check_Amount.Customer_Id,
                                                                             IN_ACCOUNT_ID      => r_Check_Amount.Account_Id,
                                                                             IN_SALES_MAIN_TYPE => r_Check_Amount.Sales_Main_Type,
                                                                             IN_PROJ_NUMBER     => r_Check_Amount.project_code,
                                                                             IN_AMOUNT_SUM      => r_Check_Amount.Apply_Amount,
                                                                             IN_DISAMOUNT_SUM   => r_Check_Amount.Discount_Amount,
                                                                             IN_DP_AMOUNT_SUM   => r_Check_Amount.dp_apply_Amount,
                                                                             IN_DP_DISAMOUNT_SUM => r_Check_Amount.dp_Discount_Amount,
                                                                             IN_DISCOUNT_TYPE   => r_Check_Amount.Discount_Type,
                                                                             IN_ORDER_ID        => r_Check_Amount.order_id,
                                                                             IN_ORDER_NUMBER    => r_Check_Amount.order_number,
                                                                             IN_DOWNPAY_RATE    => r_Check_Amount.down_pay_scale,
                                                                             IN_SRC_TYPE        => r_Check_Amount.src_type,
                                                                             IN_USER_ACCOUNT    => IN_USER_CODE,
                                                                             OUT_RESULT         => OUT_ERR_NUM,
                                                                             OUT_ERR_MSG        => OUT_RESULT);
                            IF OUT_ERR_NUM <> 0 THEN
                              OUT_RESULT := '销售转采购（转二次发运差异数量取消订单）处理客户款项失败！错误提示：'||v_Nl||OUT_RESULT||v_Nl||
                                          '事业部='||r_Check_Amount.entity_name||v_Nl||
                                          '客户ID='||r_Check_Amount.Customer_Id||' 编码='||r_Check_Amount.customer_code||v_Nl||
                                          '账户ID='||r_Check_Amount.Account_Id||' 编码='||r_Check_Amount.account_code||v_Nl||
                                          '营销大类='||r_Check_Amount.Sales_Main_Type||v_Nl||
                                          '折扣类型='||r_Check_Amount.Discount_Type;
                              --raise v_Base_Exception;
                              EXIT;
                            END IF;
                          End Loop;
                        END IF;
                      END IF;
                    
                      --按取消数量解锁
                      IF OUT_RESULT = V_SUCCESS THEN
                        IF R_LG_ORDER_LINE.HEAD_LOCK_AMOUNT_FLAG IN (V_LOCK_AMOUNT_FLAG_S, V_LOCK_AMOUNT_FLAG_HQ) 
                          AND NVL(R_LG_ORDER_LINE.HEAD_CUSTOMIZE_FLAG, 'N') = 'N' THEN
                          PKG_PLN_PUB.P_CUSTOMER_AMOUNT_PROCESS(IN_ENTITY_ID       => R_LG_ORDER_LINE.ENTITY_ID,
                                                                IN_ORDER_TYPE_ID   => R_LG_ORDER_LINE.HEAD_ORDER_TYPE_ID,
                                                                IN_ORDER_TYPE_CODE => R_LG_ORDER_LINE.HEAD_ORDER_TYPE_CODE,
                                                                IN_CUSTOMER_ID     => R_LG_ORDER_LINE.HEAD_CUSTOMER_ID,
                                                                IN_ACCOUNT_ID      => R_LG_ORDER_LINE.HEAD_ACCOUNT_ID,
                                                                IN_SALES_MAIN_TYPE => R_LG_ORDER_LINE.SALES_MAIN_TYPE,
                                                                IN_ACTION_TYPE     => 2,
                                                                IN_SOURCE_TYPE     => '02',
                                                                IN_ORDER_ID        => R_LG_ORDER_LINE.ORDER_HEAD_ID,
                                                                IN_PROJ_NUMBER     => NULL,
                                                                IN_DISCOUNT_TYPE   => NVL(R_LG_ORDER_LINE.DISCOUNT_TYPE, DISCOUNT_TYPE_COMMON),
                                                                IN_AMOUNT          => ROUND(V_CANCEL_AMOUNT, 2),
                                                                IN_DIS_AMOUNT      => ROUND(V_CANCEL_DIS_AMOUNT, 2),
                                                                IN_RECORD_ERR      => 'N',
                                                                IN_USER_CODE       => IN_USER_CODE,
                                                                OUT_RESULT         => OUT_RESULT);
                          IF OUT_RESULT <> V_SUCCESS THEN
                            OUT_RESULT := '销售转采购（转二次发运差异数量取消订单）处理客户款项失败！' || V_NL || OUT_RESULT;
                          END IF;
                        END IF;
                      END IF;
                    
                      --批文锁定处理
                      IF OUT_RESULT = V_SUCCESS AND
                         R_LG_ORDER_LINE.PROJECT_ORDER_TYPE IS NOT Null And nvl(r_lg_order_line.price_apply_id,-1) <> -1 THEN
                        V_IN_PARAM := '单据号=' ||
                                      R_LG_ORDER_LINE.HEAD_ORDER_NUMBER || V_NL ||
                                      '批文号=' ||
                                      R_LG_ORDER_LINE.PROJECT_ORDER_NUMBER || V_NL ||
                                      '产品编码=' || R_LG_ORDER_LINE.ITEM_CODE || V_NL ||
                                      '批文行ID=' ||
                                      TO_CHAR(R_LG_ORDER_LINE.PROJECT_ORDER_LINE_ID) || V_NL ||
                                      '解锁数量=' || TO_CHAR(V_CURR_CANCEL_QTY);
                        PKG_BD_PRICE.P_APPLY_UNLOCK(P_APPLY_DETAIL_ID => R_LG_ORDER_LINE.PROJECT_ORDER_LINE_ID, --批文明细ID
                                                    P_UNLOCK_CNT      => NVL(V_CURR_CANCEL_QTY,
                                                                             0), --解除锁定数量
                                                    P_BILL_NO         => R_LG_ORDER_LINE.HEAD_ORDER_NUMBER, --关联单号
                                                    P_RETURN_CODE     => V_RESULT, --返回编码，1成功，0失败
                                                    P_RETURN_MSG      => OUT_RESULT);
                        IF V_RESULT = '1' THEN
                          OUT_RESULT := V_SUCCESS;
                        END IF;
                      END IF;
                    
                      --回写订单数量和状态
                      IF OUT_RESULT = V_SUCCESS THEN
                        UPDATE T_PLN_LG_ORDER_LINE L
                           SET L.CANCEL_QTY       = NVL(L.CANCEL_QTY, 0) +
                                                    NVL(V_CURR_CANCEL_QTY, 0),
                               L.LAST_UPDATED_BY  = IN_USER_CODE,
                               L.LAST_UPDATE_DATE = SYSDATE,
                               L.VERSION = NVL(L.VERSION, 0) + 1
                         WHERE L.ORDER_LINE_ID =
                               R_LG_ORDER_LINE.ORDER_LINE_ID;
                      END IF;
                    
                      IF OUT_RESULT = V_SUCCESS THEN
                        BEGIN
                          V_IN_PARAM := '写入评审明细';
                          INSERT INTO T_PLN_ORDER_REVIEW_INFO
                            (ENTITY_ID, --业务主体
                             ORDER_REVIEW_ID, --订单评审记录ID
                             LOT_NUM, --批次（用于记录订单评审第几次）
                             ORDER_PERIOD, --订单周期（汇总的订单评审，记录订单周期）
                             SOURCE_ORDER_TYPE_ID, --源订单类型ID
                             ORDER_TYPE_ID, --订单类型ID
                             ORDER_STATE, --订单状态（送审、汇总、库评、产地分解等）
                             ORDER_TYPE_NAME, --订单类型名称
                             ORDER_NUMBER, --订单号（单单评审，记录订单号）
                             HQ_DATE, --总部评审日期
                             HQ_USER, --总部评审人员
                             REMARK, --备注
                             CREATED_BY, --创建人
                             CREATION_DATE, --创建日期
                             LAST_UPDATED_BY, --最后修改人
                             LAST_UPDATE_DATE, --最后修改日期
                             PRE_FIELD_01, --预留字段1
                             PRE_FIELD_02, --预留字段2
                             PRE_FIELD_03, --预留字段3
                             PRE_FIELD_04, --预留字段4
                             PRE_FIELD_05, --预留字段5
                             PRE_FIELD_06, --预留字段6
                             ORIGIN_ORDER_HEAD_ID, --来源订单头ID
                             ORIGIN_ORDER_LINE_ID, --来源订单行ID
                             ITEM_ID, --产品ID
                             ITEM_CODE, --产品编码
                             ITEM_NAME, --产品描述
                             AFFIRM_QTY, --评审数量
                             RECEIVE_INVENTORY_ID, --收货仓库ID
                             SEND_INVENTORY_ID, --发货仓库ID
                             IS_CANCEL_DIRECT_SEND,
                             CHECKUP_CONTENT, --评审意见  add by lilh6 160909
                             CUSTOMER_ORDER_NUMBER, --客户订单号 add by lilh6 160909
                             CONSIGNEE_ADDR_NAME --收货地址 add by lilh6 160920
                             )
                          VALUES
                            (R_LG_ORDER_LINE.ENTITY_ID, --业务主体
                             S_PLN_ORDER_REVIEW_INFO.NEXTVAL, --订单评审记录ID
                             (SELECT COUNT(1)
                                FROM T_PLN_ORDER_REVIEW_INFO RI
                               WHERE RI.ORIGIN_ORDER_HEAD_ID =
                                     R_LG_ORDER_LINE.ORDER_HEAD_ID
                                 AND RI.ORIGIN_ORDER_LINE_ID =
                                     R_LG_ORDER_LINE.ORDER_LINE_ID) + 1, --批次（用于记录订单评审第几次）
                             NULL, --订单周期（汇总的订单评审，记录订单周期）
                             1, --源订单类型ID
                             R_LG_ORDER_LINE.HEAD_ORDER_TYPE_ID, --订单类型ID
                             R_LG_ORDER_LINE.HEAD_ORDER_HEAD_STATE, --订单状态（送审、汇总、库评、产地分解等）
                             R_LG_ORDER_LINE.HEAD_ORDER_TYPE_NAME, --订单类型名称
                             R_LG_ORDER_LINE.HEAD_ORDER_NUMBER, --订单号（单单评审，记录订单号）
                             TRUNC(SYSDATE), --总部评审日期
                             IN_USER_CODE, --总部评审人员
                             '销售转采购匹配二次发运，差异数量回写订单取消数量', --备注
                             IN_USER_CODE, --创建人
                             SYSDATE, --创建日期
                             IN_USER_CODE, --最后修改人
                             SYSDATE, --最后修改日期
                             NULL, --Pre_Field_01, --预留字段1
                             NULL, --Pre_Field_02, --预留字段2
                             NULL, --Pre_Field_03, --预留字段3
                             NULL, --Pre_Field_04, --预留字段4
                             NULL, --Pre_Field_05, --预留字段5
                             NULL, --Pre_Field_06, --预留字段6
                             R_LG_ORDER_LINE.ORDER_HEAD_ID, --Origin_Order_Head_Id, --来源订单头ID
                             R_LG_ORDER_LINE.ORDER_LINE_ID, --Origin_Order_Line_Id, --来源订单行ID
                             R_LG_ORDER_LINE.ITEM_ID, --Item_Id, --产品ID
                             R_LG_ORDER_LINE.ITEM_CODE, --Item_Code, --产品编码
                             R_LG_ORDER_LINE.ITEM_NAME, --Item_Name, --产品描述
                             (-1) * V_CURR_CANCEL_QTY, --Affirm_Qty --评审数量
                             NULL, --收货仓库ID
                             NULL, --发货仓库ID
                             'N', --add by xuhongjiu 2016-05-05
                             R_LG_ORDER_LINE.HEAD_CHECKUP_CONTENT, --评审意见 add by lilh6 160909
                             R_LG_ORDER_LINE.HEAD_CUSTOMER_ORDER_NUMBER, --客户订单号 add by lilh6 160909
                             R_LG_ORDER_LINE.HEAD_CONSIGNEE_ADDR_NAME --收货地址 add by lilh6 160920
                             );
                        EXCEPTION
                          WHEN OTHERS THEN
                            OUT_RESULT := '插入评审记录信息失败，失败原因：' || SQLERRM;
                        END;
                      END IF;
                    END IF;
                  
                    IF OUT_RESULT <> V_SUCCESS OR V_REMAIN_DIFF_QTY <= 0 THEN
                      EXIT;
                    END IF;
                  END LOOP; --按来源客户提货订单循环处理end
                END IF; --实收破损数+短少数大于0才处理end
              END IF;
            END IF;
            IF OUT_RESULT <> V_SUCCESS THEN
              EXIT;
            END IF;
          END LOOP; --循环入库的产品end
        END IF;
      END IF;
    END IF;
  
    IF OUT_RESULT <> V_SUCCESS THEN
      RAISE V_BASE_EXCEPTION;
    ELSE
      IF V_SECOND_SEND_ORDER <> '可做二次发运订单：' THEN
        UPDATE T_SO_TO_SUPP_PARAM_HEAD H
           SET H.TO_SUPP_MSG = H.TO_SUPP_MSG || '；' || V_SECOND_SEND_ORDER
         WHERE H.PARAM_ID = R_PARAM_HEAD.PARAM_ID;
      
        UPDATE T_SO_HEADER H
           SET H.TO_SUPP_MSG = H.TO_SUPP_MSG || '；' || V_SECOND_SEND_ORDER
         WHERE H.SO_HEADER_ID = R_PARAM_HEAD.SOURCE_ORDER_ID;
      END IF;
    END IF;
  EXCEPTION
    WHEN V_BASE_EXCEPTION THEN
      ROLLBACK TO SAVEPOINT SP_PRE_INV_OCCUPY_USEPARAM;
      OUT_RESULT := '二次发运库存占用出错，错误提示：' || OUT_RESULT || V_NL || V_IN_PARAM;
    WHEN OTHERS THEN
      ROLLBACK TO SAVEPOINT SP_PRE_INV_OCCUPY_USEPARAM;
      OUT_RESULT := '二次发运库存占用出错，错误提示：' || SQLERRM || V_NL || V_IN_PARAM;
  END P_PRE_INV_OCCUPY_USEPARAM;

  ---------------------------------------------------------
  --生成状态调拨单据
  --转采购销售单实收破损数大于0的产品
  ---------------------------------------------------------
  PROCEDURE P_TO_INV_TRSF_USEPARAM(IN_ENTITY_ID    IN NUMBER, --主体ID
                                   IN_PARAM_ID     IN NUMBER, --转采购参数表ID
                                   IN_OPT_TYPE     IN VARCHAR2, --处理类型 02 破损，03 残次品
                                   IN_USER_CODE    IN VARCHAR2, --操作用户
                                   OUT_TRSF_NUMBER OUT VARCHAR2, --调拨单据号
                                   OUT_RESULT      IN OUT VARCHAR2) IS
    R_PARAM_HEAD          T_SO_TO_SUPP_PARAM_HEAD%ROWTYPE;
    V_IN_PARAM            VARCHAR2(4000);
    R_TRSF_ORDER          T_INV_TRSF_ORDER%ROWTYPE;
    R_TRSF_LINE           T_INV_TRSF_ORDER_LINE%ROWTYPE;
    R_TRSF_DETAIL         T_INV_TRSF_ORDER_LINE_DETAIL%ROWTYPE;
    V_COUNT               NUMBER;
    V_SHIP_INV_STOCK_TYPE T_INV_INVENTORIES.STOCK_TYPE%TYPE; --发货仓库存货类型
    V_REV_INV_STOCK_TYPE  T_INV_INVENTORIES.STOCK_TYPE%TYPE; --接收仓库存货类型
    V_TRSF_LINE_NUM       NUMBER; --调拨单行号
    V_SHIP_INV_ORG_ID     NUMBER; --发货仓库库存组织
    V_REV_INV_ORG_ID      NUMBER; --调拨仓库库存组织
    OUT_ERR_NUM           NUMBER;
  BEGIN
    OUT_RESULT := V_SUCCESS;
    SAVEPOINT SP_TO_INV_TRSF_USEPARAM;
  
    --锁定转采购参数表数据
    V_IN_PARAM := '转采购参数表ID=' || TO_CHAR(IN_PARAM_ID);
    BEGIN
      SELECT *
        INTO R_PARAM_HEAD
        FROM T_SO_TO_SUPP_PARAM_HEAD H
       WHERE H.PARAM_ID = IN_PARAM_ID;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        OUT_RESULT := '传入参数有误，找不到转采购的数据！';
    END;
  
    IF OUT_RESULT = V_SUCCESS THEN
      SELECT COUNT(1)
        INTO V_COUNT
        FROM T_SO_TO_SUPP_PARAM_LINE L
       WHERE L.PARAM_ID = IN_PARAM_ID
         AND ((IN_OPT_TYPE = '02' AND L.FACT_REV_SHATTER_QTY > 0)
          OR (IN_OPT_TYPE = '03' AND L.FACT_REV_DEFECTIVE_QTY > 0));
    END IF;
  
    IF OUT_RESULT = V_SUCCESS AND V_COUNT > 0 THEN
      --存在实收破损数大于0的产品
      --检查单据类型
      IF OUT_RESULT = V_SUCCESS THEN
        V_IN_PARAM := '单据类型编码=' || TRSF_BILL_TYPE_1055;
        BEGIN
          SELECT T.BILL_TYPE_ID, T.BILL_TYPE_CODE
            INTO R_TRSF_ORDER.BILL_TYPE_ID, R_TRSF_ORDER.BILL_TYPE
            FROM T_INV_BILL_TYPES T
           WHERE T.ENTITY_ID = R_PARAM_HEAD.ENTITY_ID
             AND T.BILL_TYPE_CODE = TRSF_BILL_TYPE_1055
             AND NVL(T.CANCEL_FLAG, V_NO) = V_NO --非红冲单据类型
             AND T.SOURCE_TYPE_ID IN
                 (SELECT ST.SOURCE_TYPE_ID
                    FROM T_INV_SOURCE_TYPES ST
                   WHERE ST.SOURCE_TYPE_CODE = '1008'
                     AND ST.ENTITY_ID = T.ENTITY_ID)
             AND SYSDATE BETWEEN T.BEGIN_DATE AND
                 NVL(T.END_DATE, SYSDATE + 1);
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            OUT_RESULT := '调拨单据类型不存在或已失效，请检查单据类型设置！';
        END;
      END IF;
    
      --检查发货仓库是否可调拨
      IF OUT_RESULT = V_SUCCESS THEN
        V_IN_PARAM := '仓库ID=' || TO_CHAR(R_PARAM_HEAD.FINANCE_INV_ID) ||
                      ',编码=' || R_PARAM_HEAD.FINANCE_INV_CODE || ',名称=' ||
                      R_PARAM_HEAD.FINANCE_INV_NAME;
        BEGIN
          SELECT I.INVENTORY_ID,
                 I.INVENTORY_CODE,
                 I.INVENTORY_NAME,
                 I.STOCK_TYPE,
                 I.ORGANIZATION_ID
            INTO R_TRSF_ORDER.SHIP_INV_ID,
                 R_TRSF_ORDER.SHIP_INV_CODE,
                 R_TRSF_ORDER.SHIP_INV_NAME,
                 V_SHIP_INV_STOCK_TYPE,
                 V_SHIP_INV_ORG_ID
            FROM T_INV_INVENTORIES I
           WHERE I.INVENTORY_ID = R_PARAM_HEAD.FINANCE_INV_ID
             AND I.ALLOT_FLAG = V_YES --可调拨
             AND I.INVENTORY_CATEGORY = V_INVENTORY_CATEGORY_01 --关联仓
             AND SYSDATE BETWEEN I.BEGIN_DATE AND
                 NVL(I.END_DATE, SYSDATE + 1);
        EXCEPTION
          WHEN OTHERS THEN
            OUT_RESULT := '发货仓库不存在或已失效，请检查仓库设置！' || V_NL ||
                          '仓库需满足条件：调拨标志=Y，仓库类别=关联仓';
        END;
      END IF;
    
      --检查接收仓库
      IF OUT_RESULT = V_SUCCESS THEN
        V_IN_PARAM := '仓库ID=' || TO_CHAR(R_PARAM_HEAD.TRSF_INV_ID) ||
                      ',仓库编码=' || R_PARAM_HEAD.TRSF_INV_CODE || ',仓库名称=' ||
                      R_PARAM_HEAD.TRSF_INV_NAME;
        BEGIN
          IF IN_OPT_TYPE = '02' THEN
            SELECT I.INVENTORY_ID,
                   I.INVENTORY_CODE,
                   I.INVENTORY_NAME,
                   I.STOCK_TYPE,
                   I.ORGANIZATION_ID
              INTO R_TRSF_ORDER.CONSIGNEE_INV_ID,
                   R_TRSF_ORDER.CONSIGNEE_INV_CODE,
                   R_TRSF_ORDER.CONSIGNEE_INV_NAME,
                   V_REV_INV_STOCK_TYPE,
                   V_REV_INV_ORG_ID
              FROM T_INV_INVENTORIES I
             WHERE I.INVENTORY_ID = R_PARAM_HEAD.TRSF_INV_ID
               AND I.ALLOT_FLAG = V_YES --可调拨
               AND I.INVENTORY_CATEGORY = V_INVENTORY_CATEGORY_01 --关联仓
               AND I.INVENTORY_TYPE = INVENTORY_TYPE_04 --破损仓
               AND SYSDATE BETWEEN I.BEGIN_DATE AND
                   NVL(I.END_DATE, SYSDATE + 1);
          ELSE
            SELECT I.INVENTORY_ID,
                   I.INVENTORY_CODE,
                   I.INVENTORY_NAME,
                   I.STOCK_TYPE,
                   I.ORGANIZATION_ID
              INTO R_TRSF_ORDER.CONSIGNEE_INV_ID,
                   R_TRSF_ORDER.CONSIGNEE_INV_CODE,
                   R_TRSF_ORDER.CONSIGNEE_INV_NAME,
                   V_REV_INV_STOCK_TYPE,
                   V_REV_INV_ORG_ID
              FROM T_INV_INVENTORIES I
             WHERE I.INVENTORY_ID = R_PARAM_HEAD.DEFECTIVE_INV_ID
               AND I.ALLOT_FLAG = V_YES --可调拨
               AND I.INVENTORY_CATEGORY = V_INVENTORY_CATEGORY_01 --关联仓
               AND I.INVENTORY_TYPE = INVENTORY_TYPE_03 --残次品仓
               AND SYSDATE BETWEEN I.BEGIN_DATE AND
                   NVL(I.END_DATE, SYSDATE + 1);
          END IF;
        EXCEPTION
          WHEN OTHERS THEN
            OUT_RESULT := '接收仓库不存在或已失效，请检查仓库设置！' || V_NL ||
                          '仓库需满足条件：调拨标志=Y，仓库类别=关联仓，仓库类型=破损仓';
        END;
      END IF;
    
      IF OUT_RESULT = V_SUCCESS THEN
        IF R_TRSF_ORDER.SHIP_INV_CODE = R_TRSF_ORDER.CONSIGNEE_INV_CODE OR
           V_SHIP_INV_ORG_ID <> V_REV_INV_ORG_ID OR
           V_SHIP_INV_STOCK_TYPE <> V_REV_INV_STOCK_TYPE THEN
          OUT_RESULT := '发货仓库和接收仓库不能相同、需属于同一个库存组织、且需为相同的存货类型！';
        END IF;
      END IF;
    
      IF OUT_RESULT = V_SUCCESS THEN
        R_TRSF_ORDER.ENTITY_ID         := R_PARAM_HEAD.ENTITY_ID;
        R_TRSF_ORDER.SALES_CENTER_ID   := R_PARAM_HEAD.SALES_CENTER_ID;
        R_TRSF_ORDER.SALES_CENTER_CODE := R_PARAM_HEAD.SALES_CENTER_CODE;
        R_TRSF_ORDER.SALES_CENTER_NAME := R_PARAM_HEAD.SALES_CENTER_NAME;
        R_TRSF_ORDER.ORIG_ORDER_TYPE   := '12';
        R_TRSF_ORDER.ORIG_ORDER_NUM    := R_PARAM_HEAD.SOURCE_ORDER_NUMBER;
        R_TRSF_ORDER.ORIG_ORDER_ID     := R_PARAM_HEAD.SOURCE_ORDER_ID;
        R_TRSF_ORDER.BILLED_DATE       := TRUNC(SYSDATE);
        R_TRSF_ORDER.CREATED_BY        := IN_USER_CODE;
        R_TRSF_ORDER.CREATION_DATE     := SYSDATE;
        R_TRSF_ORDER.LAST_UPDATED_BY   := IN_USER_CODE;
        R_TRSF_ORDER.LAST_UPDATE_DATE  := SYSDATE;
        R_TRSF_ORDER.TRSF_ORDER_STATUS := '11'; --已审核
        R_TRSF_ORDER.AUDIT_FLAG        := '1'; --审核标志
        R_TRSF_ORDER.AUDIT_BY          := IN_USER_CODE; --审核人
        R_TRSF_ORDER.AUDIT_DATE        := SYSDATE; --审核日期
        R_TRSF_ORDER.CLOSE_FLAG        := 'N'; --关闭标志
        IF IN_OPT_TYPE = '02' THEN
          R_TRSF_ORDER.REMARK            := '[来源单号:' ||
                                            R_PARAM_HEAD.SOURCE_ORDER_NUMBER ||
                                            ',转采购破损处理]';
        ELSIF IN_OPT_TYPE = '03' THEN
          R_TRSF_ORDER.REMARK            := '[来源单号:' ||
                                            R_PARAM_HEAD.SOURCE_ORDER_NUMBER ||
                                            ',转采购残次品处理]';
        END IF;
      END IF;
    
      --按营销大类拆单
      IF OUT_RESULT = V_SUCCESS THEN
        FOR R_SPLIT IN (SELECT DISTINCT NVL(L.ASS_ITEM_MAIN_TYPE,
                                            BI.SALES_MAIN_TYPE) SALES_MAIN_TYPE
                          FROM T_SO_TO_SUPP_PARAM_LINE L, T_BD_ITEM BI
                         WHERE L.PARAM_ID = IN_PARAM_ID
                           AND BI.ITEM_CODE = L.SUB_ITEM_CODE
                           AND BI.ENTITY_ID = L.ENTITY_ID
                           AND ((IN_OPT_TYPE = '02' AND L.FACT_REV_SHATTER_QTY > 0)
                             OR (IN_OPT_TYPE = '03' AND L.FACT_REV_DEFECTIVE_QTY > 0))
                           ) LOOP
          --检查营销大类
          IF OUT_RESULT = V_SUCCESS THEN
            V_IN_PARAM := '营销大类=' || R_SPLIT.SALES_MAIN_TYPE;
            BEGIN
              SELECT C.CLASS_CODE
                INTO R_TRSF_ORDER.SALES_MAIN_TYPE
                FROM T_BD_ITEM_CLASS C
               WHERE C.CLASS_CODE = R_SPLIT.SALES_MAIN_TYPE
                 AND C.CLASS_TYPE = 'M'
                 AND C.ACTIVE_FLAG = V_YES
                 AND C.ENTITY_ID = R_PARAM_HEAD.ENTITY_ID;
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                OUT_RESULT := '营销大类不存在或已失效，请检查营销分类设置！';
            END;
          END IF;
        
          --获取调拨单号
          IF OUT_RESULT = V_SUCCESS THEN
            --获取采购单号
            PKG_BD.P_GET_BILL_NO(P_BILL_TYPE  => 'invTrsfOrderNum',
                                 P_PREFIX_ADD => NULL,
                                 P_ENTITY_ID  => R_TRSF_ORDER.ENTITY_ID,
                                 P_USER_ID    => NULL,
                                 P_BILL_NO    => R_TRSF_ORDER.TRSF_ORDER_NUM);
            IF R_TRSF_ORDER.TRSF_ORDER_NUM IS NULL THEN
              OUT_RESULT := '生成调拨单号失败，编码规则编号[invTrsfOrderNum]';
            ELSE
              IF OUT_TRSF_NUMBER IS NULL THEN
                OUT_TRSF_NUMBER := R_TRSF_ORDER.TRSF_ORDER_NUM;
              ELSE
                OUT_TRSF_NUMBER := OUT_TRSF_NUMBER || ',' ||
                                   R_TRSF_ORDER.TRSF_ORDER_NUM;
              END IF;
            END IF;
          END IF;
        
          --插入调拨单头表
          IF OUT_RESULT = V_SUCCESS THEN
            SELECT S_INV_TRSF_ORDER.NEXTVAL
              INTO R_TRSF_ORDER.TRSF_ORDER_ID
              FROM DUAL;
            BEGIN
              INSERT INTO T_INV_TRSF_ORDER
                (TRSF_ORDER_ID,
                 ENTITY_ID,
                 TRSF_ORDER_NUM,
                 BILL_TYPE_ID,
                 BILL_TYPE,
                 TRSF_ORDER_STATUS,
                 SALES_MAIN_TYPE,
                 SALES_CENTER_ID,
                 SALES_CENTER_CODE,
                 SALES_CENTER_NAME,
                 SHIP_INV_ID,
                 SHIP_INV_CODE,
                 SHIP_INV_NAME,
                 CONSIGNEE_INV_ID,
                 CONSIGNEE_INV_CODE,
                 CONSIGNEE_INV_NAME,
                 ORIG_ORDER_TYPE,
                 ORIG_ORDER_NUM,
                 AUDIT_FLAG,
                 AUDIT_BY,
                 AUDIT_DATE,
                 CREATED_BY,
                 CREATION_DATE,
                 LAST_UPDATED_BY,
                 LAST_UPDATE_DATE,
                 REMARK,
                 ORIG_ORDER_ID,
                 BILLED_DATE,
                 CLOSE_FLAG)
              VALUES
                (R_TRSF_ORDER.TRSF_ORDER_ID,
                 R_TRSF_ORDER.ENTITY_ID,
                 R_TRSF_ORDER.TRSF_ORDER_NUM,
                 R_TRSF_ORDER.BILL_TYPE_ID,
                 R_TRSF_ORDER.BILL_TYPE,
                 R_TRSF_ORDER.TRSF_ORDER_STATUS,
                 R_TRSF_ORDER.SALES_MAIN_TYPE,
                 R_TRSF_ORDER.SALES_CENTER_ID,
                 R_TRSF_ORDER.SALES_CENTER_CODE,
                 R_TRSF_ORDER.SALES_CENTER_NAME,
                 R_TRSF_ORDER.SHIP_INV_ID,
                 R_TRSF_ORDER.SHIP_INV_CODE,
                 R_TRSF_ORDER.SHIP_INV_NAME,
                 R_TRSF_ORDER.CONSIGNEE_INV_ID,
                 R_TRSF_ORDER.CONSIGNEE_INV_CODE,
                 R_TRSF_ORDER.CONSIGNEE_INV_NAME,
                 R_TRSF_ORDER.ORIG_ORDER_TYPE,
                 R_TRSF_ORDER.ORIG_ORDER_NUM,
                 R_TRSF_ORDER.AUDIT_FLAG,
                 R_TRSF_ORDER.AUDIT_BY,
                 R_TRSF_ORDER.AUDIT_DATE,
                 R_TRSF_ORDER.CREATED_BY,
                 R_TRSF_ORDER.CREATION_DATE,
                 R_TRSF_ORDER.LAST_UPDATED_BY,
                 R_TRSF_ORDER.LAST_UPDATE_DATE,
                 R_TRSF_ORDER.REMARK,
                 R_TRSF_ORDER.ORIG_ORDER_ID,
                 R_TRSF_ORDER.BILLED_DATE,
                 R_TRSF_ORDER.CLOSE_FLAG);
            EXCEPTION
              WHEN OTHERS THEN
                OUT_RESULT := '插入调拨单头表失败！' || V_NL || '系统提示：' || SQLERRM;
            END;
          END IF;
        
          V_TRSF_LINE_NUM := 0;
          --按营销大类取数据
          FOR R_PARAM_LINE IN (SELECT L.*
                                 FROM T_SO_TO_SUPP_PARAM_LINE L,
                                      T_BD_ITEM               BI
                                WHERE L.PARAM_ID = IN_PARAM_ID
                                  AND L.ENTITY_ID = BI.ENTITY_ID
                                  AND L.SUB_ITEM_CODE = BI.ITEM_CODE
                                  AND NVL(L.ASS_ITEM_MAIN_TYPE, BI.SALES_MAIN_TYPE) = R_SPLIT.SALES_MAIN_TYPE
                                  AND ((IN_OPT_TYPE = '02' AND L.FACT_REV_SHATTER_QTY > 0)
                                    OR (IN_OPT_TYPE = '03' AND L.FACT_REV_DEFECTIVE_QTY > 0))
                                  ) LOOP
            IF OUT_RESULT = V_SUCCESS THEN
              --检查产品是否有效
              V_IN_PARAM := '产品编码=' || R_PARAM_LINE.SUB_ITEM_CODE || ',名称=' ||
                            R_PARAM_LINE.SUB_ITEM_NAME;
              BEGIN
                SELECT I.ITEM_ID, I.ITEM_CODE, I.ITEM_NAME, I.DEFAULTUNIT
                  INTO R_TRSF_LINE.ITEM_ID,
                       R_TRSF_LINE.ITEM_CODE,
                       R_TRSF_LINE.ITEM_NAME,
                       R_TRSF_LINE.UOM
                  FROM T_BD_ITEM I
                 WHERE I.ENTITY_ID = R_PARAM_LINE.ENTITY_ID
                   AND I.ITEM_CODE = R_PARAM_LINE.SUB_ITEM_CODE
                   AND I.ACTIVE_FLAG = V_YES;
              EXCEPTION
                WHEN NO_DATA_FOUND THEN
                  OUT_RESULT := '产品不存在或已失效，请检查产品属性设置！';
              END;
            END IF;
          
            IF OUT_RESULT = V_SUCCESS THEN
              V_TRSF_LINE_NUM                 := V_TRSF_LINE_NUM + 1;
              R_TRSF_LINE.TRSF_ORDER_LINE_NUM := V_TRSF_LINE_NUM;
              R_TRSF_LINE.ENTITY_ID           := R_PARAM_LINE.ENTITY_ID;
              R_TRSF_LINE.TRSF_ORDER_ID       := R_TRSF_ORDER.TRSF_ORDER_ID;
              R_TRSF_LINE.ORDER_LINE_ID_ORIG  := R_PARAM_LINE.SOURCE_LINE_ID;
              IF IN_OPT_TYPE = '02' THEN
                R_TRSF_LINE.BILLED_QTY          := R_PARAM_LINE.FACT_REV_SHATTER_QTY;
              ELSIF IN_OPT_TYPE = '03' THEN
                R_TRSF_LINE.BILLED_QTY          := R_PARAM_LINE.FACT_REV_DEFECTIVE_QTY;
              END IF;
              
              R_TRSF_LINE.CREATED_BY          := IN_USER_CODE;
              R_TRSF_LINE.CREATION_DATE       := SYSDATE;
              R_TRSF_LINE.LAST_UPDATED_BY     := IN_USER_CODE;
              R_TRSF_LINE.LAST_UPDATE_DATE    := SYSDATE;
            END IF;
          
            --插入调拨单行表
            IF OUT_RESULT = V_SUCCESS THEN
              SELECT S_INV_TRSF_ORDER_LINE.NEXTVAL
                INTO R_TRSF_LINE.TRSF_ORDER_LINE_ID
                FROM DUAL;
              BEGIN
                INSERT INTO T_INV_TRSF_ORDER_LINE
                  (TRSF_ORDER_LINE_ID,
                   ENTITY_ID,
                   TRSF_ORDER_ID,
                   TRSF_ORDER_LINE_NUM,
                   ORDER_LINE_ID_ORIG,
                   ITEM_ID,
                   ITEM_CODE,
                   ITEM_NAME,
                   UOM,
                   BILLED_QTY,
                   CREATED_BY,
                   CREATION_DATE,
                   LAST_UPDATED_BY,
                   LAST_UPDATE_DATE)
                VALUES
                  (R_TRSF_LINE.TRSF_ORDER_LINE_ID,
                   R_TRSF_LINE.ENTITY_ID,
                   R_TRSF_LINE.TRSF_ORDER_ID,
                   R_TRSF_LINE.TRSF_ORDER_LINE_NUM,
                   R_TRSF_LINE.ORDER_LINE_ID_ORIG,
                   R_TRSF_LINE.ITEM_ID,
                   R_TRSF_LINE.ITEM_CODE,
                   R_TRSF_LINE.ITEM_NAME,
                   R_TRSF_LINE.UOM,
                   R_TRSF_LINE.BILLED_QTY,
                   R_TRSF_LINE.CREATED_BY,
                   R_TRSF_LINE.CREATION_DATE,
                   R_TRSF_LINE.LAST_UPDATED_BY,
                   R_TRSF_LINE.LAST_UPDATE_DATE);
              EXCEPTION
                WHEN OTHERS THEN
                  OUT_RESULT := '插入调拨单行表失败！' || V_NL || '系统提示：' || SQLERRM;
              END;
            END IF;
          
            IF OUT_RESULT = V_SUCCESS THEN
              R_TRSF_DETAIL.TRSF_ORDER_LINE_ID := R_TRSF_LINE.TRSF_ORDER_LINE_ID;
              R_TRSF_DETAIL.ENTITY_ID          := R_TRSF_LINE.ENTITY_ID;
              R_TRSF_DETAIL.ITEM_ID            := R_TRSF_LINE.ITEM_ID;
              R_TRSF_DETAIL.ITEM_CODE          := R_TRSF_LINE.ITEM_CODE;
              R_TRSF_DETAIL.ITEM_NAME          := R_TRSF_LINE.ITEM_NAME;
              R_TRSF_DETAIL.UOM_CODE           := R_TRSF_LINE.UOM;
              R_TRSF_DETAIL.BILLED_QTY         := R_TRSF_LINE.BILLED_QTY;
              R_TRSF_DETAIL.TRSF_ORDER_ID      := R_TRSF_LINE.TRSF_ORDER_ID;
              R_TRSF_DETAIL.CREATED_BY         := IN_USER_CODE;
              R_TRSF_DETAIL.CREATION_DATE      := SYSDATE;
              R_TRSF_DETAIL.LAST_UPDATED_BY    := IN_USER_CODE;
              R_TRSF_DETAIL.LAST_UPDATE_DATE   := SYSDATE;
            END IF;
          
            --插入调拨单行表
            IF OUT_RESULT = V_SUCCESS THEN
              SELECT S_INV_TRSF_ORDER_LINE_DETAIL.NEXTVAL
                INTO R_TRSF_DETAIL.TRSF_ORDER_LINE_DETAIL_ID
                FROM DUAL;
              BEGIN
                INSERT INTO T_INV_TRSF_ORDER_LINE_DETAIL
                  (TRSF_ORDER_LINE_DETAIL_ID,
                   TRSF_ORDER_LINE_ID,
                   ENTITY_ID,
                   ITEM_ID,
                   ITEM_CODE,
                   ITEM_NAME,
                   UOM_CODE,
                   BILLED_QTY,
                   CREATED_BY,
                   CREATION_DATE,
                   LAST_UPDATED_BY,
                   LAST_UPDATE_DATE,
                   TRSF_ORDER_ID)
                VALUES
                  (R_TRSF_DETAIL.TRSF_ORDER_LINE_DETAIL_ID,
                   R_TRSF_DETAIL.TRSF_ORDER_LINE_ID,
                   R_TRSF_DETAIL.ENTITY_ID,
                   R_TRSF_DETAIL.ITEM_ID,
                   R_TRSF_DETAIL.ITEM_CODE,
                   R_TRSF_DETAIL.ITEM_NAME,
                   R_TRSF_DETAIL.UOM_CODE,
                   R_TRSF_DETAIL.BILLED_QTY,
                   R_TRSF_DETAIL.CREATED_BY,
                   R_TRSF_DETAIL.CREATION_DATE,
                   R_TRSF_DETAIL.LAST_UPDATED_BY,
                   R_TRSF_DETAIL.LAST_UPDATE_DATE,
                   R_TRSF_DETAIL.TRSF_ORDER_ID);
              EXCEPTION
                WHEN OTHERS THEN
                  OUT_RESULT := '插入调拨单行表失败！' || V_NL || '系统提示：' || SQLERRM;
              END;
            END IF;
          
            IF OUT_RESULT <> V_SUCCESS THEN
              EXIT; --退出循环
            END IF;
          END LOOP;
        
          --做审核物料事务
          IF OUT_RESULT = V_SUCCESS THEN
            V_IN_PARAM := '调拨单审核物料库存事务';
            PKG_INV_TRANSACTION.INV_TRANSACTION_TOTAL_DEAL(IN_ENTITY_ID          => R_TRSF_ORDER.ENTITY_ID,
                                                           IN_BILL_TYPE_ID       => R_TRSF_ORDER.BILL_TYPE_ID,
                                                           IS_BUSINESS_STATE     => R_TRSF_ORDER.TRSF_ORDER_STATUS,
                                                           ID_TRANSACTION_DATE   => R_TRSF_ORDER.BILLED_DATE,
                                                           IN_BUSINESS_HEADER_ID => R_TRSF_ORDER.TRSF_ORDER_ID,
                                                           IN_IF_NULL            => 0,
                                                           IS_BILL_KIND          => 'B2',
                                                           ON_FLAG               => OUT_ERR_NUM,
                                                           OS_PROMPT             => OUT_RESULT);
            IF OUT_ERR_NUM = 0 THEN
              --处理成功
              OUT_RESULT := V_SUCCESS;
            END IF;
          END IF;
        
          --接收处理
          IF OUT_RESULT = V_SUCCESS THEN
            UPDATE T_INV_TRSF_ORDER_LINE L
               SET L.RCV_QTY = L.BILLED_QTY
             WHERE L.TRSF_ORDER_ID = R_TRSF_ORDER.TRSF_ORDER_ID;
          
            UPDATE T_INV_TRSF_ORDER O
               SET O.TRSF_ORDER_STATUS   = '13', --已接收
                   O.RCV_FLAG            = '1',
                   O.RCV_BY              = IN_USER_CODE,
                   O.RCV_DATE            = SYSDATE,
                   O.ASSEMBLIES_RCV_FLAG = 'N' --按散件接收
             WHERE O.TRSF_ORDER_ID = R_TRSF_ORDER.TRSF_ORDER_ID;
          
            --做接收物料事务
            V_IN_PARAM := '调拨单接收物料库存事务';
            PKG_INV_TRANSACTION.INV_TRANSACTION_TOTAL_DEAL(IN_ENTITY_ID          => R_TRSF_ORDER.ENTITY_ID,
                                                           IN_BILL_TYPE_ID       => R_TRSF_ORDER.BILL_TYPE_ID,
                                                           IS_BUSINESS_STATE     => '13',
                                                           ID_TRANSACTION_DATE   => R_TRSF_ORDER.BILLED_DATE,
                                                           IN_BUSINESS_HEADER_ID => R_TRSF_ORDER.TRSF_ORDER_ID,
                                                           IN_IF_NULL            => 0,
                                                           IS_BILL_KIND          => 'B2',
                                                           ON_FLAG               => OUT_ERR_NUM,
                                                           OS_PROMPT             => OUT_RESULT);
            IF OUT_ERR_NUM = 0 THEN
              --处理成功
              OUT_RESULT := V_SUCCESS;
            END IF;
          END IF;
        
          IF OUT_RESULT <> V_SUCCESS THEN
            EXIT; --退出循环
          END IF;
        END LOOP;
      END IF;
    END IF;
  
    IF OUT_RESULT <> V_SUCCESS THEN
      OUT_TRSF_NUMBER := NULL;
      RAISE V_BASE_EXCEPTION;
    ELSE
      IF OUT_TRSF_NUMBER IS NOT NULL THEN
        IF IN_OPT_TYPE = '02' THEN
          UPDATE T_SO_TO_SUPP_PARAM_HEAD H
             SET H.TO_SUPP_MSG = H.TO_SUPP_MSG || '；破损调拨单号：' || OUT_TRSF_NUMBER
           WHERE H.PARAM_ID = R_PARAM_HEAD.PARAM_ID;
        
          UPDATE T_SO_HEADER H
             SET H.TO_SUPP_MSG = H.TO_SUPP_MSG || '；破损调拨单号：' || OUT_TRSF_NUMBER
           WHERE H.SO_HEADER_ID = R_PARAM_HEAD.SOURCE_ORDER_ID;
        ELSIF IN_OPT_TYPE = '03' THEN
          UPDATE T_SO_TO_SUPP_PARAM_HEAD H
             SET H.TO_SUPP_MSG = H.TO_SUPP_MSG || '；残次品调拨单号：' || OUT_TRSF_NUMBER
           WHERE H.PARAM_ID = R_PARAM_HEAD.PARAM_ID;
        
          UPDATE T_SO_HEADER H
             SET H.TO_SUPP_MSG = H.TO_SUPP_MSG || '；残次品调拨单号：' || OUT_TRSF_NUMBER
           WHERE H.SO_HEADER_ID = R_PARAM_HEAD.SOURCE_ORDER_ID;
        END IF;
      END IF;
    END IF;
  EXCEPTION
    WHEN V_BASE_EXCEPTION THEN
      ROLLBACK TO SAVEPOINT SP_TO_INV_TRSF_USEPARAM;
      OUT_RESULT := '生成状态调拨单据出错，错误提示：' || OUT_RESULT || V_NL || V_IN_PARAM;
    WHEN OTHERS THEN
      ROLLBACK TO SAVEPOINT SP_TO_INV_TRSF_USEPARAM;
      OUT_RESULT := '生成状态调拨单据出错，错误提示：' || SQLERRM || V_NL || V_IN_PARAM;
  END P_TO_INV_TRSF_USEPARAM;

  ---------------------------------------------------------
  --生成承运商全赔单据
  --转采购销售单短少数大于0的产品
  ---------------------------------------------------------
  PROCEDURE P_TO_LGVENDOR_CLAIM_USEPARAM(IN_ENTITY_ID     IN NUMBER, --主体ID
                                         IN_PARAM_ID      IN NUMBER, --转采购参数表ID
                                         IN_USER_CODE     IN VARCHAR2, --操作用户
                                         OUT_CLAIM_NUMBER OUT VARCHAR2, --全赔销售单据号
                                         OUT_RESULT       IN OUT VARCHAR2) IS
    R_PARAM_HEAD   T_SO_TO_SUPP_PARAM_HEAD%ROWTYPE;
    V_IN_PARAM     VARCHAR2(4000);
    R_SO_HEAD      T_SO_HEADER%ROWTYPE; --总部销售单
    R_SO_HEAD_INTF T_SO_HEADER_INTERFACE%ROWTYPE; --销售单接口
    R_SO_LINE_INTF T_SO_LINE_INTERFACE%ROWTYPE; --销售单接口行
    V_COUNT        NUMBER;
    OUT_ERR_NUM    NUMBER;
    V_CX_FLAG      VARCHAR2(10);
  BEGIN
    OUT_RESULT := V_SUCCESS;
    SAVEPOINT SP_TO_LGVENDOR_CLAIM_USEPARAM;
  
    --锁定转采购参数表数据
    V_IN_PARAM := '转采购参数表ID=' || TO_CHAR(IN_PARAM_ID);
    BEGIN
      SELECT *
        INTO R_PARAM_HEAD
        FROM T_SO_TO_SUPP_PARAM_HEAD H
       WHERE H.PARAM_ID = IN_PARAM_ID;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        OUT_RESULT := '传入参数有误，找不到转采购的数据！';
    END;
  
    --获取来源销售单
    IF OUT_RESULT = V_SUCCESS THEN
      V_IN_PARAM := '销售单ID=' || TO_CHAR(R_PARAM_HEAD.SOURCE_ORDER_ID) ||
                    ',销售单号=' || R_PARAM_HEAD.SOURCE_ORDER_NUMBER;
      BEGIN
        SELECT H.*
          INTO R_SO_HEAD
          FROM T_SO_HEADER H
         WHERE H.SO_HEADER_ID = R_PARAM_HEAD.SOURCE_ORDER_ID;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          OUT_RESULT := '找不到转采购的销售单！';
      END;
    END IF;
  
    IF OUT_RESULT = V_SUCCESS THEN
      SELECT COUNT(1)
        INTO V_COUNT
        FROM T_SO_TO_SUPP_PARAM_LINE L
       WHERE L.PARAM_ID = IN_PARAM_ID
         AND L.MISSING_QTY > 0;
    END IF;
  
    IF OUT_RESULT = V_SUCCESS AND V_COUNT > 0 THEN
      --有短少数大于0的产品才处理
      --检查单据类型
      IF OUT_RESULT = V_SUCCESS THEN
        V_IN_PARAM := '单据类型编码=' || CLAIM_BILL_TYPE_1020;
        BEGIN
          SELECT T.BILL_TYPE_ID, T.BILL_TYPE_CODE, T.BILL_TYPE_NAME
            INTO R_SO_HEAD_INTF.BILL_TYPE_ID,
                 R_SO_HEAD_INTF.BILL_TYPE_CODE,
                 R_SO_HEAD_INTF.BILL_TYPE_NAME
            FROM T_INV_BILL_TYPES T
           WHERE T.ENTITY_ID = R_PARAM_HEAD.ENTITY_ID
             AND T.BILL_TYPE_CODE = CLAIM_BILL_TYPE_1020
             AND NVL(T.CANCEL_FLAG, V_NO) = V_NO --非红冲单据类型
             AND T.SOURCE_TYPE_ID IN
                 (SELECT ST.SOURCE_TYPE_ID
                    FROM T_INV_SOURCE_TYPES ST
                   WHERE ST.SOURCE_TYPE_CODE = '1006'
                     AND ST.ENTITY_ID = T.ENTITY_ID)
             AND SYSDATE BETWEEN T.BEGIN_DATE AND
                 NVL(T.END_DATE, SYSDATE + 1);
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            OUT_RESULT := '销售单据类型不存在或已失效，请检查单据类型设置！';
        END;
      END IF;
    
      --检查发货仓库是否可销售
      IF OUT_RESULT = V_SUCCESS THEN
        V_IN_PARAM := '仓库ID=' || TO_CHAR(R_PARAM_HEAD.FINANCE_INV_ID) ||
                      ',编码=' || R_PARAM_HEAD.FINANCE_INV_CODE || ',名称=' ||
                      R_PARAM_HEAD.FINANCE_INV_NAME;
        BEGIN
          SELECT I.INVENTORY_ID
            INTO R_SO_HEAD_INTF.SHIP_INV_ID
            FROM T_INV_INVENTORIES I
           WHERE I.INVENTORY_ID = R_PARAM_HEAD.FINANCE_INV_ID
             AND I.SALES_FLAG = V_YES --可销售
             AND I.INVENTORY_CATEGORY = V_INVENTORY_CATEGORY_01 --关联仓
             AND SYSDATE BETWEEN I.BEGIN_DATE AND
                 NVL(I.END_DATE, SYSDATE + 1);
        EXCEPTION
          WHEN OTHERS THEN
            OUT_RESULT := '销售发货仓库不存在或已失效，请检查仓库设置！' || V_NL ||
                          '仓库需满足条件：销售标志=Y，仓库类别=关联仓';
        END;
      END IF;
    END IF;
  
    --检查客户
    IF OUT_RESULT = V_SUCCESS THEN
      V_IN_PARAM := '客户ID=' || TO_CHAR(R_PARAM_HEAD.LG_VENDOR_ID) || ',编码=' ||
                    R_PARAM_HEAD.LG_VENDOR_CODE || ',名称=' ||
                    R_PARAM_HEAD.LG_VENDOR_NAME;
      BEGIN
        SELECT H.CUSTOMER_ID, H.CUSTOMER_CODE, H.CUSTOMER_NAME
          INTO R_SO_HEAD_INTF.CUSTOMER_ID,
               R_SO_HEAD_INTF.CUSTOMER_CODE,
               R_SO_HEAD_INTF.CUSTOMER_NAME
          FROM T_CUSTOMER_HEADER H
         WHERE H.CUSTOMER_ID = R_PARAM_HEAD.LG_VENDOR_ID
           AND H.ACTIVE_FLAG = V_ACTIVE;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          OUT_RESULT := '客户不存在或已失效，请检查客户设置！';
      END;
    END IF;
  
    --检查客户账户关系
    IF OUT_RESULT = V_SUCCESS THEN
      V_IN_PARAM := '中心ID=' || TO_CHAR(R_PARAM_HEAD.SALES_CENTER_ID) ||
                    ',编码=' || R_PARAM_HEAD.SALES_CENTER_CODE || ',名称=' ||
                    R_PARAM_HEAD.SALES_CENTER_NAME || V_NL || '客户ID=' ||
                    TO_CHAR(R_SO_HEAD_INTF.CUSTOMER_ID) || ',编码=' ||
                    R_SO_HEAD_INTF.CUSTOMER_CODE || ',名称=' ||
                    R_SO_HEAD_INTF.CUSTOMER_NAME;
      BEGIN
        SELECT S.ACCOUNT_ID,
               S.ACCOUNT_CODE,
               S.ACCOUNT_NAME,
               S.SALES_CENTER_ID,
               S.SALES_CENTER_CODE,
               S.SALES_CENTER_NAME
          INTO R_SO_HEAD_INTF.ACCOUNT_ID,
               R_SO_HEAD_INTF.ACCOUNT_CODE,
               R_SO_HEAD_INTF.ACCOUNT_NAME,
               R_SO_HEAD_INTF.SALES_CENTER_ID,
               R_SO_HEAD_INTF.SALES_CENTER_CODE,
               R_SO_HEAD_INTF.SALES_CENTER_NAME
          FROM V_CUSTOMER_ACCOUNT_SALECENTER S
         WHERE S.SALES_CENTER_ID = R_PARAM_HEAD.SALES_CENTER_ID
           AND S.CUSTOMER_ID = R_SO_HEAD_INTF.CUSTOMER_ID
           AND S.ENTITY_ID = R_PARAM_HEAD.ENTITY_ID
           AND S.ACTIVE_FLAG = V_ACTIVE
           AND S.ACCOUNT_STATUS = V_ACCOUNT_ACTIVE;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          OUT_RESULT := '当前中心和承运商客户不存在有效的账户关系，请检查账户设置！';
      END;
    END IF;
  
    --获取省市区县编码
    IF OUT_RESULT = V_SUCCESS THEN
      R_SO_HEAD_INTF.ENTITY_ID := R_PARAM_HEAD.ENTITY_ID;
      --省
      R_SO_HEAD_INTF.CONSIGNEE_PROVINCE_CODE := R_SO_HEAD.CONSIGNEE_PROVINCE_CODE;
      --市
      R_SO_HEAD_INTF.CONSIGNEE_CITY_CODE := R_SO_HEAD.CONSIGNEE_CITY_CODE;
      --区
      R_SO_HEAD_INTF.CONSIGNEE_DISTRICT_CODE := R_SO_HEAD.CONSIGNEE_DISTRICT_CODE;
      --县
      R_SO_HEAD_INTF.CONSIGNEE_TOWN_CODE    := R_SO_HEAD.CONSIGNEE_TOWN_CODE;
      R_SO_HEAD_INTF.SO_DATE                := TRUNC(SYSDATE);
      R_SO_HEAD_INTF.COMPENSATION_FLAG      := V_YES; --全赔标志
      R_SO_HEAD_INTF.CONSIGNEE_ADDRESS      := R_SO_HEAD.CONSIGNEE_ADDRESS;
      R_SO_HEAD_INTF.RECEIVE_FLAG           := V_YES; --签收标志
      R_SO_HEAD_INTF.RECEIVE_DATE           := SYSDATE; --签收日期
      R_SO_HEAD_INTF.CREATED_MODE           := '88'; --特殊处理方式
      R_SO_HEAD_INTF.REMARK                 := '本单据为销售单短少，转采购时产生给承运商的销售单据，原销售单号为' ||
                                               R_SO_HEAD.SO_NUM || '#' ||
                                               TO_CHAR(SYSDATE,
                                                       'YYYY-MM-DD');
      R_SO_HEAD_INTF.RAW_SRC_TYPE           := '12';
      R_SO_HEAD_INTF.RAW_SRC_BILL_TYPE_ID   := R_SO_HEAD.BILL_TYPE_ID;
      R_SO_HEAD_INTF.RAW_SRC_BILL_TYPE_CODE := R_SO_HEAD.BILL_TYPE_CODE;
      R_SO_HEAD_INTF.RAW_SRC_BILL_TYPE_NAME := R_SO_HEAD.BILL_TYPE_NAME;
      R_SO_HEAD_INTF.RAW_SRC_BILL_ID        := R_SO_HEAD.SO_HEADER_ID;
      R_SO_HEAD_INTF.RAW_SRC_BILL_NUM       := R_SO_HEAD.SO_NUM;
      R_SO_HEAD_INTF.SHIP_FLAG              := 'Y';
      R_SO_HEAD_INTF.SHIP_DATE              := SYSDATE;
      R_SO_HEAD_INTF.DISCOUNT_TYPE          := 'COMMON';
    END IF;
  
    IF OUT_RESULT = V_SUCCESS THEN
      --按产品大类拆单
      FOR R_SPLIT IN (SELECT DISTINCT NVL(L.ASS_ITEM_MAIN_TYPE,
                                          BI.SALES_MAIN_TYPE) SALES_MAIN_TYPE
                        FROM T_SO_TO_SUPP_PARAM_LINE L, T_BD_ITEM BI
                       WHERE L.PARAM_ID = IN_PARAM_ID
                         AND L.ENTITY_ID = BI.ENTITY_ID
                         AND L.SUB_ITEM_CODE = BI.ITEM_CODE
                         AND L.MISSING_QTY > 0) LOOP
        IF OUT_RESULT = V_SUCCESS THEN
          --检查营销大类
          V_IN_PARAM := '营销大类=' || R_SPLIT.SALES_MAIN_TYPE;
          BEGIN
            SELECT C.CLASS_CODE, C.CLASS_NAME
              INTO R_SO_HEAD_INTF.SALES_MAIN_TYPE,
                   R_SO_HEAD_INTF.SALES_MAIN_TYPE_NAME
              FROM T_BD_ITEM_CLASS C
             WHERE C.CLASS_CODE = R_SPLIT.SALES_MAIN_TYPE
               AND C.CLASS_TYPE = 'M'
               AND C.ACTIVE_FLAG = V_YES
               AND C.ENTITY_ID = R_PARAM_HEAD.ENTITY_ID;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              OUT_RESULT := '营销大类不存在或已失效，请检查营销分类设置！';
          END;
        END IF;
      
        --插入销售单接口头表
        IF OUT_RESULT = V_SUCCESS THEN
          V_IN_PARAM := '插入销售单接口头表';
          PKG_SO_BIZ.P_SO_CREATE_INTF_HEADER(P_SO_INTF_HEADER => R_SO_HEAD_INTF,
                                             P_USER_CODE      => IN_USER_CODE,
                                             P_RESULT         => OUT_ERR_NUM,
                                             P_ERR_MSG        => OUT_RESULT);
        END IF;
      
        IF OUT_RESULT = V_SUCCESS THEN
          FOR R_PARAM_LINE IN (SELECT L.*
                                 FROM T_SO_TO_SUPP_PARAM_LINE L,
                                      T_BD_ITEM               BI
                                WHERE L.ENTITY_ID = BI.ENTITY_ID
                                  AND L.SUB_ITEM_CODE = BI.ITEM_CODE
                                  AND L.PARAM_ID = IN_PARAM_ID
                                  AND NVL(L.ASS_ITEM_MAIN_TYPE,
                                          BI.SALES_MAIN_TYPE) =
                                      R_SPLIT.SALES_MAIN_TYPE
                                  AND L.MISSING_QTY > 0) LOOP
            --更新来源销售单全赔数量
            UPDATE T_SO_LINE_DETAIL D
               SET D.TO_VENDER_QTY = D.MISSING_QTY
             WHERE D.SO_LINE_ID = R_PARAM_LINE.SOURCE_LINE_ID
               AND D.COMPONENT_CODE = R_PARAM_LINE.SUB_ITEM_CODE;
          
            R_SO_LINE_INTF.ENTITY_ID              := R_SO_HEAD_INTF.ENTITY_ID;
            R_SO_LINE_INTF.SO_HEADER_INTERFACE_ID := R_SO_HEAD_INTF.SO_HEADER_INTERFACE_ID;
          
            --转采购过程已检查产品，直接获取
            SELECT BI.ITEM_ID,
                   BI.ITEM_CODE,
                   BI.ITEM_NAME,
                   BI.DEFAULTUNIT,
                   BI.PACKINGSIZE,
                   BI.GROSSWEIGHT
              INTO R_SO_LINE_INTF.ITEM_ID,
                   R_SO_LINE_INTF.ITEM_CODE,
                   R_SO_LINE_INTF.ITEM_NAME,
                   R_SO_LINE_INTF.ITEM_UOM,
                   R_SO_LINE_INTF.ITEM_VOLUME,
                   R_SO_LINE_INTF.ITEM_WEIGHT
              FROM T_BD_ITEM BI
             WHERE BI.ENTITY_ID = R_SO_LINE_INTF.ENTITY_ID
               AND BI.ITEM_CODE = R_PARAM_LINE.SUB_ITEM_CODE;
          
            R_SO_LINE_INTF.ITEM_QTY := R_PARAM_LINE.MISSING_QTY; --产品数量取实收数量
          
            --获取价格
            BEGIN
              V_IN_PARAM := '账户ID=' || TO_CHAR(R_SO_HEAD_INTF.ACCOUNT_ID) ||
                            ',编码=' || R_SO_HEAD_INTF.ACCOUNT_CODE || V_NL ||
                            '产品编码=' || R_SO_LINE_INTF.ITEM_CODE;
              PKG_BD_PRICE.P_GET_PRICE(P_ACC_ID         => R_SO_HEAD_INTF.ACCOUNT_ID,
                                       P_ITEM_CODE      => R_SO_LINE_INTF.ITEM_CODE,
                                       P_BILL_DATE      => TO_CHAR(SYSDATE,
                                                                   'YYYYMMDD'),
                                       P_PRICE_LIST_ID  => NULL,
                                       P_ENTITY_ID      => R_SO_LINE_INTF.ENTITY_ID,
                                       P_PRICE          => R_SO_LINE_INTF.ITEM_PRICE,
                                       P_DISCOUNT       => R_SO_LINE_INTF.DISCOUNT_RATE,
                                       P_MONTH_DISCOUNT => R_SO_LINE_INTF.MONTH_DISCOUNT_RATE,
                                       P_CX_FLAG        => V_CX_FLAG);
            
              IF R_SO_LINE_INTF.ITEM_PRICE IS NULL THEN
                OUT_RESULT := '未维护产品价格，请检查价格列表！';
              END IF;
            EXCEPTION
              WHEN OTHERS THEN
                OUT_RESULT := '获取产品价格异常，系统提示：' || SQLERRM;
            END;
          
            IF OUT_RESULT = V_SUCCESS THEN
              V_IN_PARAM := '产品编码=' || R_PARAM_LINE.ASS_ITEM_CODE || ',折扣=' ||
                            TO_CHAR(R_PARAM_LINE.CUST_SO_DISCOUNT_RATE) ||
                            ',月返=' ||
                            TO_CHAR(R_PARAM_LINE.CUST_SO_MONTH_DIS_RATE);
              IF NVL(R_SO_LINE_INTF.DISCOUNT_RATE, 0) +
                 NVL(R_SO_LINE_INTF.MONTH_DISCOUNT_RATE, 0) < 0 OR
                 NVL(R_SO_LINE_INTF.DISCOUNT_RATE, 0) +
                 NVL(R_SO_LINE_INTF.MONTH_DISCOUNT_RATE, 0) > 100 THEN
                OUT_RESULT := '折扣+月返需在0~100之间';
              END IF;
            END IF;
          
            IF OUT_RESULT = V_SUCCESS THEN
              R_SO_LINE_INTF.ITEM_SETTLE_PRICE  := R_SO_LINE_INTF.ITEM_PRICE *
                                                   (100 - NVL(R_SO_LINE_INTF.DISCOUNT_RATE,
                                                              0) -
                                                   NVL(R_SO_LINE_INTF.MONTH_DISCOUNT_RATE,
                                                        0)) / 100;
              R_SO_LINE_INTF.ITEM_SETTLE_AMOUNT := R_SO_LINE_INTF.ITEM_QTY *
                                                   R_SO_LINE_INTF.ITEM_SETTLE_PRICE;
              R_SO_LINE_INTF.DISCOUNT_AMOUNT    := R_SO_LINE_INTF.ITEM_QTY *
                                                   R_SO_LINE_INTF.ITEM_PRICE *
                                                   NVL(R_SO_LINE_INTF.DISCOUNT_RATE,
                                                       0) / 100;
              R_SO_LINE_INTF.ITEM_LIST_AMOUNT   := R_SO_LINE_INTF.ITEM_QTY *
                                                   R_SO_LINE_INTF.ITEM_PRICE;
            
              R_SO_LINE_INTF.SRC_HEADER_ID     := R_SO_HEAD_INTF.RAW_SRC_BILL_ID;
              R_SO_LINE_INTF.SRC_LINE_ID       := R_PARAM_LINE.SOURCE_LINE_ID;
              R_SO_LINE_INTF.RAW_SRC_HEADER_ID := R_SO_HEAD_INTF.RAW_SRC_BILL_ID;
              R_SO_LINE_INTF.RAW_SRC_LINE_ID   := R_PARAM_LINE.SOURCE_LINE_ID;
            END IF;
          
            --插入接口行
            IF OUT_RESULT = V_SUCCESS THEN
              V_IN_PARAM := '插入销售单接口行表';
              PKG_SO_BIZ.P_SO_CREATE_INTF_LINE(P_SO_INTF_LINE => R_SO_LINE_INTF,
                                               P_USER_CODE    => IN_USER_CODE,
                                               P_RESULT       => OUT_ERR_NUM,
                                               P_ERR_MSG      => OUT_RESULT);
            END IF; --插入接口行end
          
            IF OUT_RESULT <> V_SUCCESS THEN
              EXIT;
            END IF;
          END LOOP; --处理接口行end
        END IF; --处理接口行end
      
        --调用销售接口处理过程
        IF OUT_RESULT = V_SUCCESS THEN
          V_IN_PARAM := '调用销售单接口过程生成全赔单';
          PKG_SO_BIZ.P_SO_GENERATE(P_SO_HEADER_INTERFACE_ID => R_SO_HEAD_INTF.SO_HEADER_INTERFACE_ID,
                                   P_USER_CODE              => IN_USER_CODE,
                                   P_RESULT                 => OUT_ERR_NUM,
                                   P_ERR_MSG                => OUT_RESULT);
        
          IF OUT_ERR_NUM = 0 THEN
            --返回0为成功
            OUT_RESULT := V_SUCCESS;
          END IF;
        END IF;
      
        IF OUT_RESULT <> V_SUCCESS THEN
          EXIT; --退出循环
        END IF;
      END LOOP;
    END IF;
  
    --获取全赔销售单号
    IF OUT_RESULT = V_SUCCESS THEN
      SELECT TO_CHAR(WM_CONCAT(H.SO_NUM))
        INTO OUT_CLAIM_NUMBER
        FROM T_SO_HEADER H
       WHERE H.RAW_SRC_TYPE = '12'
         AND H.RAW_SRC_BILL_ID = R_SO_HEAD.SO_HEADER_ID
         AND H.RAW_SRC_BILL_NUM = R_SO_HEAD.SO_NUM
         AND H.CUSTOMER_ID = R_PARAM_HEAD.LG_VENDOR_ID
         AND H.COMPENSATION_FLAG = V_YES;
    END IF;
  
    IF OUT_RESULT <> V_SUCCESS THEN
      OUT_CLAIM_NUMBER := NULL;
      RAISE V_BASE_EXCEPTION;
    ELSE
      IF OUT_CLAIM_NUMBER IS NOT NULL THEN
        UPDATE T_SO_TO_SUPP_PARAM_HEAD H
           SET H.TO_SUPP_MSG = H.TO_SUPP_MSG || '；全赔单号：' || OUT_CLAIM_NUMBER
         WHERE H.PARAM_ID = R_PARAM_HEAD.PARAM_ID;
      
        UPDATE T_SO_HEADER H
           SET H.TO_SUPP_MSG = H.TO_SUPP_MSG || '；全赔单号：' || OUT_CLAIM_NUMBER
         WHERE H.SO_HEADER_ID = R_PARAM_HEAD.SOURCE_ORDER_ID;
      END IF;
    END IF;
  EXCEPTION
    WHEN V_BASE_EXCEPTION THEN
      ROLLBACK TO SAVEPOINT SP_TO_LGVENDOR_CLAIM_USEPARAM;
      OUT_RESULT := '生成承运商全赔单据出错，错误提示：' || OUT_RESULT || V_NL || V_IN_PARAM;
    WHEN OTHERS THEN
      ROLLBACK TO SAVEPOINT SP_TO_LGVENDOR_CLAIM_USEPARAM;
      OUT_RESULT := '生成承运商全赔单据出错，错误提示：' || SQLERRM || V_NL || V_IN_PARAM;
  END P_TO_LGVENDOR_CLAIM_USEPARAM;
  ---------------------------------------------------------
  --生成退货申请单
  --转采购销售单拒收数大于0的产品
  ---------------------------------------------------------
  PROCEDURE P_TO_INV_RETURN_USEPARAM(IN_ENTITY_ID      IN NUMBER, --主体ID
                                     IN_PARAM_ID       IN NUMBER, --转采购参数表ID
                                     IN_USER_CODE      IN VARCHAR2, --操作用户
                                     OUT_RETURN_NUMBER OUT VARCHAR2, --退货申请单据号
                                     OUT_RESULT        IN OUT VARCHAR2) IS
    R_PARAM_HEAD               T_SO_TO_SUPP_PARAM_HEAD%ROWTYPE;
    R_SO_HEAD                  T_SO_HEADER%ROWTYPE;
    V_IN_PARAM                 VARCHAR2(4000);
    R_SO_RETURN_APPLY_HEADER   INTF_SO_RETURN_APPLY_HEADER%ROWTYPE;
    R_SO_RETURN_APPLY_LINE     INTF_SO_RETURN_APPLY_LINE%ROWTYPE;
    R_SO_RETURN_APPLY_LINE_SUB INTF_SO_RETURN_APPLY_LINE%ROWTYPE;
    r_RETURN_APPLY_HEADER      t_so_return_apply_header%Rowtype;
    r_RETURN_APPLY_LINE        t_so_return_apply_line%Rowtype;
    V_ASS_ITEM_CODE            T_BD_ITEM.ITEM_CODE%TYPE; --套件编码
    V_MAX_REJECTED_QTY         NUMBER;
    V_MIN_REJECTED_QTY         NUMBER;
    V_COUNT                    NUMBER;
    V_FLAG                     VARCHAR2(1) := V_NO; --用于判断是否进入行表处理
    V_ASS_FLAG                 VARCHAR2(1) := V_NO; --套件是否写接口表标志
    V_1                        NUMBER;
    V_2                        NUMBER;
    V_3                        VARCHAR2(1000);
    V_4                        VARCHAR2(1000);
    v_po_num                   varchar2(500);
    R_PO_HEAD                     T_INV_PO_HEADERS%ROWTYPE;
    R_PO_LINE                     T_INV_PO_LINES%ROWTYPE;
    R_PO_ASS_LINE                 T_INV_PO_ASSEMBLE_LINES%ROWTYPE;
    R_PO_SUB_LINE                 T_INV_PO_ASSEMBLE_LINES%ROWTYPE; --用于写散件
    V_PO_LINE_ID                  NUMBER;
    V_APPLY_LINE_ID  Number; --退货申请行id
  BEGIN
    OUT_RESULT := V_SUCCESS;
    SAVEPOINT SP_TO_INV_RETURN_USEPARAM;
  
    --锁定转采购参数表数据
    V_IN_PARAM := '转采购参数表ID=' || TO_CHAR(IN_PARAM_ID);
    BEGIN
      SELECT *
        INTO R_PARAM_HEAD
        FROM T_SO_TO_SUPP_PARAM_HEAD H
       WHERE H.PARAM_ID = IN_PARAM_ID
         FOR UPDATE NOWAIT;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        OUT_RESULT := '传入参数有误，找不到转采购的数据！';
      WHEN OTHERS THEN
        OUT_RESULT := '锁定销售转采购的数据失败，可能有其他人正在操作，请稍后重试！';
    END;
  
    IF OUT_RESULT = V_SUCCESS THEN
      --获取来源销售单信息
      V_IN_PARAM := '销售单ID=' || TO_CHAR(R_PARAM_HEAD.SOURCE_ORDER_ID) ||
                    ',销售单号=' || R_PARAM_HEAD.SOURCE_ORDER_NUMBER;
      BEGIN
        SELECT H.*
          INTO R_SO_HEAD
          FROM T_SO_HEADER H
         WHERE H.SO_HEADER_ID = R_PARAM_HEAD.SOURCE_ORDER_ID
           FOR UPDATE NOWAIT;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          OUT_RESULT := '找不到转采购的销售单！';
        WHEN OTHERS THEN
          OUT_RESULT := '锁定转采购的销售单失败，可能有其他人正在操作，请稍后重试！';
      END;
    END IF;
  
    IF OUT_RESULT = V_SUCCESS THEN
      SELECT COUNT(1)
        INTO V_COUNT
        FROM T_SO_TO_SUPP_PARAM_LINE L
       WHERE L.PARAM_ID = IN_PARAM_ID
         AND L.REJECTED_QTY > 0;
    END IF;
    --存在拒收数大于0的产品，才开始处理
    IF OUT_RESULT = V_SUCCESS AND V_COUNT > 0 THEN
      R_SO_RETURN_APPLY_HEADER.ENTITY_ID            := IN_ENTITY_ID;
      R_SO_RETURN_APPLY_HEADER.SALES_MAIN_TYPE      := R_SO_HEAD.SALES_MAIN_TYPE;
      R_SO_RETURN_APPLY_HEADER.SALES_MAIN_TYPE_NAME := R_SO_HEAD.SALES_MAIN_TYPE_NAME;
      R_SO_RETURN_APPLY_HEADER.CUSTOMER_ID          := R_SO_HEAD.CUSTOMER_ID;
      R_SO_RETURN_APPLY_HEADER.CUSTOMER_CODE        := R_SO_HEAD.CUSTOMER_CODE;
      R_SO_RETURN_APPLY_HEADER.CUSTOMER_NAME        := R_SO_HEAD.CUSTOMER_NAME;
      R_SO_RETURN_APPLY_HEADER.SALES_CENTER_ID      := R_SO_HEAD.SALES_CENTER_ID;
      R_SO_RETURN_APPLY_HEADER.SALES_CENTER_CODE    := R_SO_HEAD.SALES_CENTER_CODE;
      R_SO_RETURN_APPLY_HEADER.SALES_CENTER_NAME    := R_SO_HEAD.SALES_CENTER_NAME;
      R_SO_RETURN_APPLY_HEADER.REMARK               := '[来源单号:' ||
                                                       R_PARAM_HEAD.SOURCE_ORDER_NUMBER ||
                                                       ',转采购拒收处理]';
      R_SO_RETURN_APPLY_HEADER.CREATED_BY           := IN_USER_CODE;
      R_SO_RETURN_APPLY_HEADER.CREATION_DATE        := SYSDATE;
      R_SO_RETURN_APPLY_HEADER.LAST_UPDATED_BY      := IN_USER_CODE;
      R_SO_RETURN_APPLY_HEADER.LAST_UPDATE_DATE     := SYSDATE;
      R_SO_RETURN_APPLY_HEADER.INTF_STATUS          := '01'; --接口状态
      R_SO_RETURN_APPLY_HEADER.SYS_SOURCE           := 'CIMS'; --数据来源（系统编码） CCS、CIMS
      R_SO_RETURN_APPLY_HEADER.SRC_TYPE             := '12'; --来源类型：必填项 101 CCS代理商退货；102 京东EDI退货
      R_SO_RETURN_APPLY_HEADER.SRC_BILL_NUM         := R_SO_HEAD.SO_NUM;
      R_SO_RETURN_APPLY_HEADER.RECEIVE_INV_ID       := R_PARAM_HEAD.REJECTED_INV_ID;
      R_SO_RETURN_APPLY_HEADER.RECEIVE_INV_CODE     := R_PARAM_HEAD.REJECTED_INV_CODE;
      R_SO_RETURN_APPLY_HEADER.RECEIVE_INV_NAME     := R_PARAM_HEAD.REJECTED_INV_NAME;
      SELECT S_SO_INTF_RETURN_APPLY_HEADER.NEXTVAL
        INTO R_SO_RETURN_APPLY_HEADER.APPLY_HEADER_ID
        FROM DUAL;
      --插入退货申请接口头表
      BEGIN
        INSERT INTO INTF_SO_RETURN_APPLY_HEADER
          (APPLY_HEADER_ID,
           ENTITY_ID,
           SALES_MAIN_TYPE,
           SALES_MAIN_TYPE_NAME,
           CUSTOMER_ID,
           CUSTOMER_CODE,
           CUSTOMER_NAME,
           SALES_CENTER_ID,
           SALES_CENTER_CODE,
           SALES_CENTER_NAME,
           REMARK,
           CREATED_BY,
           CREATION_DATE,
           LAST_UPDATED_BY,
           LAST_UPDATE_DATE,
           INTF_STATUS,
           SYS_SOURCE,
           SRC_TYPE,
           SRC_BILL_NUM,
           RECEIVE_INV_ID,
           RECEIVE_INV_CODE,
           RECEIVE_INV_NAME)
        VALUES
          (R_SO_RETURN_APPLY_HEADER.APPLY_HEADER_ID,
           R_SO_RETURN_APPLY_HEADER.ENTITY_ID,
           R_SO_RETURN_APPLY_HEADER.SALES_MAIN_TYPE,
           R_SO_RETURN_APPLY_HEADER.SALES_MAIN_TYPE_NAME,
           R_SO_RETURN_APPLY_HEADER.CUSTOMER_ID,
           R_SO_RETURN_APPLY_HEADER.CUSTOMER_CODE,
           R_SO_RETURN_APPLY_HEADER.CUSTOMER_NAME,
           R_SO_RETURN_APPLY_HEADER.SALES_CENTER_ID,
           R_SO_RETURN_APPLY_HEADER.SALES_CENTER_CODE,
           R_SO_RETURN_APPLY_HEADER.SALES_CENTER_NAME,
           R_SO_RETURN_APPLY_HEADER.REMARK,
           R_SO_RETURN_APPLY_HEADER.CREATED_BY,
           R_SO_RETURN_APPLY_HEADER.CREATION_DATE,
           R_SO_RETURN_APPLY_HEADER.LAST_UPDATED_BY,
           R_SO_RETURN_APPLY_HEADER.LAST_UPDATE_DATE,
           R_SO_RETURN_APPLY_HEADER.INTF_STATUS,
           R_SO_RETURN_APPLY_HEADER.SYS_SOURCE,
           R_SO_RETURN_APPLY_HEADER.SRC_TYPE,
           R_SO_RETURN_APPLY_HEADER.SRC_BILL_NUM,
           R_SO_RETURN_APPLY_HEADER.RECEIVE_INV_ID,
           R_SO_RETURN_APPLY_HEADER.RECEIVE_INV_CODE,
           R_SO_RETURN_APPLY_HEADER.RECEIVE_INV_NAME);
      EXCEPTION
        WHEN OTHERS THEN
          OUT_RESULT := '插入退货申请接口头表失败！' || V_NL || '系统提示：' || SQLERRM;
      END;
      V_ASS_ITEM_CODE := '_';
      --循环处理
      FOR R_PARAM_LINE IN (SELECT L.*
                             FROM T_SO_TO_SUPP_PARAM_LINE L
                            WHERE L.PARAM_ID = IN_PARAM_ID
                              AND L.ASS_ITEM_CODE IN
                                  (SELECT LL.ASS_ITEM_CODE
                                     FROM T_SO_TO_SUPP_PARAM_LINE LL
                                    WHERE LL.PARAM_ID = IN_PARAM_ID
                                      AND LL.REJECTED_QTY > 0)
                            ORDER BY L.ASS_ITEM_CODE) LOOP
        IF OUT_RESULT = V_SUCCESS THEN
          IF V_ASS_ITEM_CODE <> R_PARAM_LINE.ASS_ITEM_CODE OR V_FLAG = V_NO THEN
            IF V_ASS_ITEM_CODE <> R_PARAM_LINE.ASS_ITEM_CODE THEN
              V_ASS_FLAG      := V_NO;
              V_ASS_ITEM_CODE := R_PARAM_LINE.ASS_ITEM_CODE;
            END IF;
            R_SO_RETURN_APPLY_LINE.APPLY_HEADER_ID := R_SO_RETURN_APPLY_HEADER.APPLY_HEADER_ID;
            SELECT S_SO_INTF_RETURN_APPLY_LINE.NEXTVAL
              INTO R_SO_RETURN_APPLY_LINE.APPLY_LINE_ID
              FROM DUAL;
            R_SO_RETURN_APPLY_LINE.ENTITY_ID        := IN_ENTITY_ID;
            R_SO_RETURN_APPLY_LINE.CREATED_BY       := IN_USER_CODE;
            R_SO_RETURN_APPLY_LINE.CREATION_DATE    := SYSDATE;
            R_SO_RETURN_APPLY_LINE.LAST_UPDATED_BY  := IN_USER_CODE;
            R_SO_RETURN_APPLY_LINE.LAST_UPDATE_DATE := SYSDATE;
            --检查产品是否有效
            V_IN_PARAM := '产品编码=' || R_PARAM_LINE.ASS_ITEM_CODE || ',名称=' ||
                          R_PARAM_LINE.ASS_ITEM_CODE;
            BEGIN
              SELECT I.ITEM_ID, I.ITEM_CODE, I.ITEM_NAME, I.DEFAULTUNIT
                INTO R_SO_RETURN_APPLY_LINE.ITEM_ID,
                     R_SO_RETURN_APPLY_LINE.ITEM_CODE,
                     R_SO_RETURN_APPLY_LINE.ITEM_NAME,
                     R_SO_RETURN_APPLY_LINE.ITEM_UOM
                FROM T_BD_ITEM I
               WHERE I.ENTITY_ID = IN_ENTITY_ID
                 AND I.ITEM_CODE = R_PARAM_LINE.ASS_ITEM_CODE
                 AND I.ACTIVE_FLAG = V_YES;
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                OUT_RESULT := '产品不存在或已失效，请检查产品属性设置！';
            END;
            IF OUT_RESULT = V_SUCCESS THEN
              --获取最大与最小拒收数
              SELECT NVL(MAX(NVL(SPL.REJECTED_QTY, 0)), 0),
                     NVL(MIN(NVL(SPL.REJECTED_QTY, 0)), 0)
                INTO V_MAX_REJECTED_QTY, V_MIN_REJECTED_QTY
                FROM T_SO_TO_SUPP_PARAM_LINE SPL
               WHERE SPL.ASS_ITEM_CODE = R_PARAM_LINE.ASS_ITEM_CODE
                 AND SPL.PARAM_ID = IN_PARAM_ID;
              R_SO_RETURN_APPLY_LINE.APPLIED_QTY := V_MIN_REJECTED_QTY;
              --取价格
              SELECT L.ITEM_PRICE, L.DISCOUNT_RATE, L.MONTH_DISCOUNT_RATE
                INTO R_SO_RETURN_APPLY_LINE.APPLIED_PRICE,
                     R_SO_RETURN_APPLY_LINE.DISCOUNT_RATE,
                     R_SO_RETURN_APPLY_LINE.MONTH_DISCOUNT_RATE
                FROM T_SO_LINE L
               WHERE L.SO_LINE_ID = R_PARAM_LINE.SOURCE_LINE_ID;
            
              IF V_MAX_REJECTED_QTY = V_MIN_REJECTED_QTY THEN
                V_FLAG := V_YES;
              ELSIF V_MAX_REJECTED_QTY > V_MIN_REJECTED_QTY THEN
                --最大拒收数大于最小拒收数，则按散件处理拒收数大的
                V_FLAG := V_NO;
                IF NVL(R_PARAM_LINE.REJECTED_QTY, 0) > V_MIN_REJECTED_QTY Then
                  --先判断退货申请行上是否存在产品
                  BEGIN
                    SELECT L.APPLY_LINE_ID
                      INTO V_APPLY_LINE_ID
                      From INTF_SO_RETURN_APPLY_LINE L
                     WHERE L.APPLY_HEADER_ID = R_SO_RETURN_APPLY_HEADER.APPLY_HEADER_ID
                       AND L.Item_Code = R_PARAM_LINE.SUB_ITEM_CODE;
                  EXCEPTION
                    WHEN NO_DATA_FOUND THEN
                      V_APPLY_LINE_ID := NULL;
                  END;
                  
                  If V_APPLY_LINE_ID Is Not Null Then
                    --不为空，则更新数量
                    Update Intf_So_Return_Apply_Line Il
                       Set Il.Applied_Qty = Nvl(Il.Applied_Qty, 0) +
                                            Nvl(r_Param_Line.Rejected_Qty, 0) -
                                            v_Min_Rejected_Qty
                     Where il.apply_line_id = V_APPLY_LINE_ID;
                  Else
                    --没有才插入
                    R_SO_RETURN_APPLY_LINE_SUB.APPLY_HEADER_ID := R_SO_RETURN_APPLY_HEADER.APPLY_HEADER_ID;
                    SELECT S_SO_RETURN_APPLY_LINE.NEXTVAL
                      INTO R_SO_RETURN_APPLY_LINE_SUB.APPLY_LINE_ID
                      FROM DUAL;
                    R_SO_RETURN_APPLY_LINE_SUB.ENTITY_ID        := IN_ENTITY_ID;
                    R_SO_RETURN_APPLY_LINE_SUB.CREATED_BY       := IN_USER_CODE;
                    R_SO_RETURN_APPLY_LINE_SUB.CREATION_DATE    := SYSDATE;
                    R_SO_RETURN_APPLY_LINE_SUB.LAST_UPDATED_BY  := IN_USER_CODE;
                    R_SO_RETURN_APPLY_LINE_SUB.LAST_UPDATE_DATE := SYSDATE;
                    --检查散件编码
                    BEGIN
                      SELECT I.ITEM_ID,
                             I.ITEM_CODE,
                             I.ITEM_NAME,
                             I.DEFAULTUNIT
                        INTO R_SO_RETURN_APPLY_LINE_SUB.ITEM_ID,
                             R_SO_RETURN_APPLY_LINE_SUB.ITEM_CODE,
                             R_SO_RETURN_APPLY_LINE_SUB.ITEM_NAME,
                             R_SO_RETURN_APPLY_LINE_SUB.ITEM_UOM
                        FROM T_BD_ITEM I
                       WHERE I.ENTITY_ID = IN_ENTITY_ID
                         AND I.ITEM_CODE = R_PARAM_LINE.SUB_ITEM_CODE
                         AND I.ACTIVE_FLAG = V_YES;
                    EXCEPTION
                      WHEN NO_DATA_FOUND THEN
                        V_IN_PARAM := NULL;
                        OUT_RESULT := '产品:' || R_PARAM_LINE.SUB_ITEM_CODE ||
                                      ',在总部主体不存在或已失效，请检查产品属性设置！';
                        RAISE V_BASE_EXCEPTION;
                    END;
                    --获取散件价格
                    BEGIN
                      PKG_BD_PRICE.P_GET_PRICE_LINE(IN_ACC_ID         => R_SO_HEAD.ACCOUNT_ID,
                                                    IS_ITEM_CODE      => R_PARAM_LINE.SUB_ITEM_CODE,
                                                    IS_BILL_DATE      => TO_CHAR(TRUNC(SYSDATE),
                                                                                 'yyyyMMdd'),
                                                    IN_PRICE_LIST_ID  => NULL,
                                                    IN_ENTITY_ID      => IN_ENTITY_ID,
                                                    ON_PRICE          => R_SO_RETURN_APPLY_LINE_SUB.APPLIED_PRICE,
                                                    ON_DISCOUNT       => R_SO_RETURN_APPLY_LINE_SUB.DISCOUNT_RATE,
                                                    ON_MONTH_DISCOUNT => R_SO_RETURN_APPLY_LINE_SUB.MONTH_DISCOUNT_RATE,
                                                    OS_CX_FLAG        => V_3,
                                                    OS_COMPE_ATTR     => V_4);
                      IF R_SO_RETURN_APPLY_LINE_SUB.APPLIED_PRICE IS NULL THEN
                        OUT_RESULT := '生成总部主体退货申请单失败，原因：获取总部主体客户对应的散件价格失败！散件编码：' ||
                                      R_PARAM_LINE.SUB_ITEM_CODE || V_NL ||
                                      '中心：' || R_SO_HEAD.SALES_CENTER_CODE ||
                                      '客户：' || R_SO_HEAD.CUSTOMER_CODE;
                        V_IN_PARAM := NULL;
                        RAISE V_BASE_EXCEPTION;
                      END IF;
                    EXCEPTION
                      WHEN OTHERS THEN
                        OUT_RESULT := '生成总部主体退货申请单失败！获取散件价格时失败！' || V_NL ||
                                      '系统提示：' || SQLERRM;
                        V_IN_PARAM := NULL;
                        RAISE V_BASE_EXCEPTION;
                    END;
                    R_SO_RETURN_APPLY_LINE_SUB.APPLIED_QTY := NVL(R_PARAM_LINE.REJECTED_QTY, 0) - V_MIN_REJECTED_QTY;
                    --以散件写退货申请行表
                    BEGIN
                      INSERT INTO INTF_SO_RETURN_APPLY_LINE
                        (APPLY_LINE_ID,
                         APPLY_HEADER_ID,
                         ENTITY_ID,
                         ITEM_ID,
                         ITEM_CODE,
                         ITEM_NAME,
                         ITEM_UOM,
                         APPLIED_PRICE,
                         APPLIED_QTY,
                         CREATED_BY,
                         CREATION_DATE,
                         LAST_UPDATED_BY,
                         LAST_UPDATE_DATE,
                         DISCOUNT_RATE,
                         MONTH_DISCOUNT_RATE)
                      VALUES
                        (R_SO_RETURN_APPLY_LINE_SUB.APPLY_LINE_ID,
                         R_SO_RETURN_APPLY_LINE_SUB.APPLY_HEADER_ID,
                         R_SO_RETURN_APPLY_LINE_SUB.ENTITY_ID,
                         R_SO_RETURN_APPLY_LINE_SUB.ITEM_ID,
                         R_SO_RETURN_APPLY_LINE_SUB.ITEM_CODE,
                         R_SO_RETURN_APPLY_LINE_SUB.ITEM_NAME,
                         R_SO_RETURN_APPLY_LINE_SUB.ITEM_UOM,
                         R_SO_RETURN_APPLY_LINE_SUB.APPLIED_PRICE,
                         R_SO_RETURN_APPLY_LINE_SUB.APPLIED_QTY,
                         R_SO_RETURN_APPLY_LINE_SUB.CREATED_BY,
                         R_SO_RETURN_APPLY_LINE_SUB.CREATION_DATE,
                         R_SO_RETURN_APPLY_LINE_SUB.LAST_UPDATED_BY,
                         R_SO_RETURN_APPLY_LINE_SUB.LAST_UPDATE_DATE,
                         R_SO_RETURN_APPLY_LINE_SUB.DISCOUNT_RATE,
                         R_SO_RETURN_APPLY_LINE_SUB.MONTH_DISCOUNT_RATE);
                    EXCEPTION
                      WHEN OTHERS THEN
                        OUT_RESULT := '生成总部主体退货申请单失败！' || V_NL || '系统提示：' ||
                                      SQLERRM;
                        V_IN_PARAM := NULL;
                        RAISE V_BASE_EXCEPTION;
                    END;   
                  End If;
                  
                  
                
                END IF;
              END IF;
            
              --套件写入退货申请行表
              IF V_ASS_FLAG = V_NO AND R_SO_RETURN_APPLY_LINE.APPLIED_QTY > 0 Then
                --先判断退货申请行上是否存在产品
                BEGIN
                  SELECT L.APPLY_LINE_ID
                    INTO V_APPLY_LINE_ID
                    From INTF_SO_RETURN_APPLY_LINE L
                   WHERE L.APPLY_HEADER_ID = R_SO_RETURN_APPLY_HEADER.APPLY_HEADER_ID
                     AND L.Item_Code = R_SO_RETURN_APPLY_LINE.ITEM_CODE;
                EXCEPTION
                  WHEN NO_DATA_FOUND THEN
                    V_APPLY_LINE_ID := NULL;
                END;
                If V_APPLY_LINE_ID Is Not Null Then
                  --不为空，则更新数量
                  Update Intf_So_Return_Apply_Line Il
                     Set Il.Applied_Qty = Nvl(Il.Applied_Qty, 0) + R_SO_RETURN_APPLY_LINE.APPLIED_QTY
                   Where il.apply_line_id = V_APPLY_LINE_ID;
                Else
                  BEGIN
                    INSERT INTO INTF_SO_RETURN_APPLY_LINE
                      (APPLY_LINE_ID,
                       APPLY_HEADER_ID,
                       ENTITY_ID,
                       ITEM_ID,
                       ITEM_CODE,
                       ITEM_NAME,
                       ITEM_UOM,
                       APPLIED_PRICE,
                       APPLIED_QTY,
                       CREATED_BY,
                       CREATION_DATE,
                       LAST_UPDATED_BY,
                       LAST_UPDATE_DATE,
                       DISCOUNT_RATE,
                       MONTH_DISCOUNT_RATE)
                    VALUES
                      (R_SO_RETURN_APPLY_LINE.APPLY_LINE_ID,
                       R_SO_RETURN_APPLY_LINE.APPLY_HEADER_ID,
                       R_SO_RETURN_APPLY_LINE.ENTITY_ID,
                       R_SO_RETURN_APPLY_LINE.ITEM_ID,
                       R_SO_RETURN_APPLY_LINE.ITEM_CODE,
                       R_SO_RETURN_APPLY_LINE.ITEM_NAME,
                       R_SO_RETURN_APPLY_LINE.ITEM_UOM,
                       R_SO_RETURN_APPLY_LINE.APPLIED_PRICE,
                       R_SO_RETURN_APPLY_LINE.APPLIED_QTY,
                       R_SO_RETURN_APPLY_LINE.CREATED_BY,
                       R_SO_RETURN_APPLY_LINE.CREATION_DATE,
                       R_SO_RETURN_APPLY_LINE.LAST_UPDATED_BY,
                       R_SO_RETURN_APPLY_LINE.LAST_UPDATE_DATE,
                       R_SO_RETURN_APPLY_LINE.DISCOUNT_RATE,
                       R_SO_RETURN_APPLY_LINE.MONTH_DISCOUNT_RATE);
                  EXCEPTION
                    WHEN OTHERS THEN
                      OUT_RESULT := '生成总部主体退货申请单失败！' || V_NL || '系统提示：' ||
                                    SQLERRM;
                      V_IN_PARAM := NULL;
                      RAISE V_BASE_EXCEPTION;
                  END;
                End If;
                V_ASS_FLAG := V_YES;
              END IF;
            END IF;
          
          END IF;
        
        END IF;
      
      END LOOP;
      IF OUT_RESULT = V_SUCCESS THEN
        --调用过程生成退货申请单（写正式表）
        BEGIN
          PKG_SO_INFT_CCS.P_SO_GEN_RETURN_APPLY_ENTRY(P_APPLY_HEADER_ID => R_SO_RETURN_APPLY_HEADER.APPLY_HEADER_ID,
                                                      P_SYS_SOURCE      => 'CIMS',
                                                      P_RESULT          => OUT_RETURN_NUMBER,
                                                      P_ERR_MSG         => OUT_RESULT);
        EXCEPTION
          WHEN OTHERS THEN
            OUT_RESULT := '调用PKG_SO_INFT_CCS.P_SO_GEN_RETURN_APPLY_ENTRY生成总部主体退货申请单失败！' || V_NL ||
                          '系统提示：' || SQLERRM;
            V_IN_PARAM := NULL;
            RAISE V_BASE_EXCEPTION;
        END;
        IF OUT_RETURN_NUMBER <> 0 THEN
          OUT_RETURN_NUMBER := NULL;
          V_IN_PARAM        := NULL;
          RAISE V_BASE_EXCEPTION;
        ELSIF OUT_RETURN_NUMBER = 0 THEN
          --取退货申请单号
          SELECT RAH.BILL_NUM
            INTO OUT_RETURN_NUMBER
            FROM INTF_SO_RETURN_APPLY_HEADER RAH
           WHERE RAH.APPLY_HEADER_ID =
                 R_SO_RETURN_APPLY_HEADER.APPLY_HEADER_ID;
          UPDATE T_SO_TO_SUPP_PARAM_HEAD H
             SET H.TO_SUPP_MSG = H.TO_SUPP_MSG || '；退货申请单号：' ||
                                 OUT_RETURN_NUMBER
           WHERE H.PARAM_ID = R_PARAM_HEAD.PARAM_ID;
        
          UPDATE T_SO_HEADER H
             SET H.TO_SUPP_MSG = H.TO_SUPP_MSG || '；退货申请单号：' ||
                                 OUT_RETURN_NUMBER
           WHERE H.SO_HEADER_ID = R_PARAM_HEAD.SOURCE_ORDER_ID;
           
           --生成采购退货单 lilh6 2019-11-22
           Begin
             Select *
               Into r_Return_Apply_Header
               From t_So_Return_Apply_Header h
              Where h.Bill_Num = Out_Return_Number;
           Exception
             When Others Then
               OUT_RESULT := '找不到拒收生成的退货申请单！退货申请单号：' || Out_Return_Number;
               RAISE V_BASE_EXCEPTION;
           End;
           
           --检查采购单据类型有效性
          IF OUT_RESULT = V_SUCCESS THEN
            V_IN_PARAM := '';
            BEGIN
              Select b.Bill_Type_Id, b.Bill_Type_Code
                Into r_Po_Head.Po_Type_Id, r_Po_Head.Po_Type
                From t_Pln_Order_Type_Rela r, t_Inv_Bill_Types b
               Where r.Relation_Type = 'SO_TO_POX'
                 And r.Source_Order_Type_Id = r_Return_Apply_Header.Bill_Type_Id
                 And r.Source_Entity_Id = r_RETURN_APPLY_HEADER.Entity_Id
                 And r.Transfer_Order_Type_Id = b.Bill_Type_Id
                 And r.Transfer_Entity_Id = R_PARAM_HEAD.Entity_Id
                 And Sysdate Between b.Begin_Date And Nvl(b.End_Date, Sysdate + 1);
            EXCEPTION
              WHEN Others THEN
                OUT_RESULT := '采购退货入库单据类型与退货申请关系不存在，或采购退货入库单据类型不存在或已失效，请检查！';
                RAISE V_BASE_EXCEPTION;
            END;
          END IF;
          
          IF OUT_RESULT = V_SUCCESS THEN
            R_PO_HEAD.SOURCE_TYPE      := '销售转采购';
            R_PO_HEAD.Sched_Order_Num  := r_RETURN_APPLY_HEADER.Bill_Num;
            R_PO_HEAD.SOURCE_SYSTEM    := 'CIMS';
            R_PO_HEAD.REMARK           := R_PARAM_HEAD.REMARK || '[来源单号：' ||
                                          r_RETURN_APPLY_HEADER.Bill_Num || ']';
            R_PO_HEAD.ENTITY_ID        := R_PARAM_HEAD.ENTITY_ID;
            R_PO_HEAD.BILLED_DATE := R_PARAM_HEAD.PO_BILL_DATE;
            R_PO_HEAD.PO_STATUS        := '10'; --制单状态
            R_PO_HEAD.PRICE_LIST_ID    := 0;
            R_PO_HEAD.CREATED_BY       := IN_USER_CODE;
            R_PO_HEAD.CREATION_DATE    := SYSDATE;
            R_PO_HEAD.LAST_UPDATED_BY  := IN_USER_CODE;
            R_PO_HEAD.LAST_UPDATE_DATE := SYSDATE;
            R_PO_HEAD.CLOSE_FLAG       := 'N';
            --正向的时候都检查过有效性，直接赋值即可
            --中心
            SELECT U.UNIT_ID, U.CODE, U.NAME
              INTO R_PO_HEAD.SALES_CENTER_ID,
                   R_PO_HEAD.SALES_CENTER_CODE,
                   R_PO_HEAD.SALES_CENTER_NAME
              FROM UP_ORG_UNIT U
             WHERE U.UNIT_ID = R_PARAM_HEAD.SALES_CENTER_ID
               AND U.IS_ENABLED = V_TRUE
               AND U.ACTIVE_FLAG = V_TRUE;
            --仓库
            SELECT I.INVENTORY_ID,
                   I.INVENTORY_CODE,
                   I.INVENTORY_NAME,
                   O.OPERATING_UNIT,
                   O.ORGANIZATION_ID
              INTO R_PO_HEAD.INV_FINANCE_ID,
                   R_PO_HEAD.INV_FINANCE_CODE,
                   R_PO_HEAD.INV_FINANCE_NAME,
                   R_PO_HEAD.FINANCE_OPERATING_ID,
                   R_PO_HEAD.FINANCE_ORGANIZATION_ID
              FROM T_INV_INVENTORIES I, T_INV_ORGANIZATION O
             WHERE I.INVENTORY_ID = R_PARAM_HEAD.FINANCE_INV_ID
               AND I.PURCHASE_FLAG = V_YES --可采购
               AND I.INVENTORY_CATEGORY = V_INVENTORY_CATEGORY_01 --关联仓
               AND I.ORGANIZATION_ID = O.ORGANIZATION_ID(+)
               AND I.ENTITY_ID = O.ENTITY_ID(+)
               AND SYSDATE BETWEEN I.BEGIN_DATE AND
                   NVL(I.END_DATE, SYSDATE + 1);
            --供应商       
            SELECT V.VENDOR_ID,
                   V.VENDOR_CODE,
                   V.VENDOR_NAME,
                   V.OPERATING_UNIT,
                   V.ORGANIZATION_ID,
                   V.VENDOR_SITE_CODE
              INTO R_PO_HEAD.VENDOR_ID,
                   R_PO_HEAD.VENDOR_CODE,
                   R_PO_HEAD.VENDOR_NAME,
                   R_PO_HEAD.VENDOR_OPERATING_ID,
                   R_PO_HEAD.VENDOR_ORGANIZATION_ID,
                   R_PO_HEAD.VENDOR_SITE_CODE
              FROM V_INV_VENDOR_VIEW V
             WHERE V.VENDOR_ID = R_PARAM_HEAD.VENDOR_ID
               AND ROWNUM = 1;
          END IF;
          
          --按照转采购产品明细行大类进行拆单
          IF OUT_RESULT = V_SUCCESS THEN
            FOR R_ITEM_TYPE IN (SELECT DISTINCT NVL(L.ASS_ITEM_MAIN_TYPE,
                                                    BI.SALES_MAIN_TYPE) SALES_MAIN_TYPE
                                  FROM T_SO_TO_SUPP_PARAM_LINE L, T_BD_ITEM BI
                                 WHERE L.PARAM_ID = IN_PARAM_ID
                                   AND L.ENTITY_ID = BI.ENTITY_ID
                                   AND L.ASS_ITEM_CODE = BI.ITEM_CODE
                                   And nvl(l.rejected_qty,0) > 0) LOOP
              V_IN_PARAM                := '营销大类=' || R_ITEM_TYPE.SALES_MAIN_TYPE;
              R_PO_HEAD.SALES_MAIN_TYPE := R_ITEM_TYPE.SALES_MAIN_TYPE;
            
              --获取采购单号
              PKG_BD.P_GET_BILL_NO(P_BILL_TYPE  => 'invPONum',
                                   P_PREFIX_ADD => NULL,
                                   P_ENTITY_ID  => R_PO_HEAD.ENTITY_ID,
                                   P_USER_ID    => NULL,
                                   P_BILL_NO    => R_PO_HEAD.PO_NUM);
              IF R_PO_HEAD.PO_NUM IS NULL THEN
                OUT_RESULT := '生成采购单号失败，编码规则编号[invPONum]';
                RAISE V_BASE_EXCEPTION;
              END IF;
              IF v_po_num IS NULL THEN
                v_po_num := R_PO_HEAD.PO_NUM;
              ELSE
                v_po_num := v_po_num || ',' || R_PO_HEAD.PO_NUM;
              END IF;
              --获取采购单据ID
              SELECT S_INV_PO_HEADERS.NEXTVAL INTO R_PO_HEAD.PO_ID FROM DUAL;
              
              BEGIN
                --插入采购单头表
                INSERT INTO T_INV_PO_HEADERS
                  (PO_ID,
                   ENTITY_ID,
                   PO_TYPE_ID,
                   PO_TYPE,
                   PO_NUM,
                   BILLED_DATE,
                   PO_STATUS,
                   SALES_MAIN_TYPE,
                   INV_FINANCE_ID,
                   INV_FINANCE_CODE,
                   INV_FINANCE_NAME,
                   VENDOR_ID,
                   VENDOR_CODE,
                   VENDOR_NAME,
                   SALES_CENTER_ID,
                   SALES_CENTER_CODE,
                   SALES_CENTER_NAME,
                   PRICE_LIST_ID,
                   CREATED_BY,
                   CREATION_DATE,
                   REMARK,
                   LAST_UPDATED_BY,
                   LAST_UPDATE_DATE,
                   SOURCE_TYPE,
                   SOURCE_SYSTEM,
                   SOURCE_ORDER_NUM,
                   SOURCE_ORDER_ID,
                   Sched_Order_Num,
                   VENDOR_OPERATING_ID,
                   VENDOR_ORGANIZATION_ID,
                   VENDOR_SITE_CODE,
                   FINANCE_OPERATING_ID,
                   FINANCE_ORGANIZATION_ID,
                   CLOSE_FLAG)
                VALUES
                  (R_PO_HEAD.PO_ID,
                   R_PO_HEAD.ENTITY_ID,
                   R_PO_HEAD.PO_TYPE_ID,
                   R_PO_HEAD.PO_TYPE,
                   R_PO_HEAD.PO_NUM,
                   R_PO_HEAD.BILLED_DATE,
                   R_PO_HEAD.PO_STATUS,
                   R_PO_HEAD.SALES_MAIN_TYPE,
                   R_PO_HEAD.INV_FINANCE_ID,
                   R_PO_HEAD.INV_FINANCE_CODE,
                   R_PO_HEAD.INV_FINANCE_NAME,
                   R_PO_HEAD.VENDOR_ID,
                   R_PO_HEAD.VENDOR_CODE,
                   R_PO_HEAD.VENDOR_NAME,
                   R_PO_HEAD.SALES_CENTER_ID,
                   R_PO_HEAD.SALES_CENTER_CODE,
                   R_PO_HEAD.SALES_CENTER_NAME,
                   R_PO_HEAD.PRICE_LIST_ID,
                   R_PO_HEAD.CREATED_BY,
                   R_PO_HEAD.CREATION_DATE,
                   R_PO_HEAD.REMARK,
                   R_PO_HEAD.LAST_UPDATED_BY,
                   R_PO_HEAD.LAST_UPDATE_DATE,
                   R_PO_HEAD.SOURCE_TYPE,
                   R_PO_HEAD.SOURCE_SYSTEM,
                   R_PO_HEAD.SOURCE_ORDER_NUM,
                   R_PO_HEAD.SOURCE_ORDER_ID,
                   R_PO_HEAD.Sched_Order_Num,
                   R_PO_HEAD.VENDOR_OPERATING_ID,
                   R_PO_HEAD.VENDOR_ORGANIZATION_ID,
                   R_PO_HEAD.VENDOR_SITE_CODE,
                   R_PO_HEAD.FINANCE_OPERATING_ID,
                   R_PO_HEAD.FINANCE_ORGANIZATION_ID,
                   R_PO_HEAD.CLOSE_FLAG);
              EXCEPTION
                WHEN OTHERS THEN
                  OUT_RESULT := '插入采购退货单头失败！' || V_NL || '系统提示：' || SQLERRM;
                  RAISE V_BASE_EXCEPTION;
              END;
              
              IF OUT_RESULT = V_SUCCESS THEN
                R_PO_LINE.PO_LINE_NUM := 0;
                --处理采购单据行
                FOR R_PARAM_LINE IN (SELECT L.*
                                       FROM T_SO_TO_SUPP_PARAM_LINE L,
                                            T_BD_ITEM               BI
                                      WHERE L.PARAM_ID = IN_PARAM_ID
                                        AND L.ENTITY_ID = BI.ENTITY_ID
                                        AND L.ASS_ITEM_CODE = BI.ITEM_CODE
                                        AND NVL(L.ASS_ITEM_MAIN_TYPE,
                                                BI.SALES_MAIN_TYPE) =
                                            R_PO_HEAD.SALES_MAIN_TYPE
                                        AND nvl(l.rejected_qty,0) > 0
                                      ORDER BY L.ASS_ITEM_CODE) LOOP
                  --检查是否已存在当前产品编码的采购单行
                  BEGIN
                    SELECT L.PO_LINE_ID
                      INTO V_PO_LINE_ID
                      FROM T_INV_PO_LINES L
                     WHERE L.PO_ID = R_PO_HEAD.PO_ID
                       AND L.ITEM_CODE = R_PARAM_LINE.SUB_ITEM_CODE;
                  EXCEPTION
                    WHEN NO_DATA_FOUND THEN
                      V_PO_LINE_ID := NULL;
                  END;
                
                  --存在则更新数量
                  IF V_PO_LINE_ID IS NOT NULL THEN
                    UPDATE T_INV_PO_LINES L
                       SET L.BILLED_QTY = L.BILLED_QTY + R_PARAM_LINE.Rejected_Qty
                     WHERE L.PO_LINE_ID = V_PO_LINE_ID;
                  ELSE
                    --不存在则插入
                    R_PO_LINE.BILLED_QTY       := R_PARAM_LINE.Rejected_Qty;
                    --数量大于0才处理
                    IF R_PO_LINE.BILLED_QTY > 0 THEN
                      --检查产品是否有效
                      V_IN_PARAM := '产品编码=' || R_PARAM_LINE.SUB_ITEM_CODE || ',名称=' ||
                                    R_PARAM_LINE.SUB_ITEM_NAME;
                      BEGIN
                        SELECT I.ITEM_ID,
                               I.ITEM_CODE,
                               I.ITEM_NAME,
                               I.DEFAULTUNIT,
                               I.BARCODE
                          INTO R_PO_LINE.ITEM_ID,
                               R_PO_LINE.ITEM_CODE,
                               R_PO_LINE.ITEM_NAME,
                               R_PO_LINE.UOM_CODE,
                               R_PO_LINE.ITEM_BAR_CODE
                          FROM T_BD_ITEM I
                         WHERE I.ENTITY_ID = R_PARAM_LINE.ENTITY_ID
                           AND I.ITEM_CODE = R_PARAM_LINE.SUB_ITEM_CODE
                           AND I.ACTIVE_FLAG = V_YES;
                      EXCEPTION
                        WHEN NO_DATA_FOUND THEN
                          OUT_RESULT := '产品不存在或已失效，请检查产品属性设置！';
                          RAISE V_BASE_EXCEPTION;
                      END;
                    
                      IF OUT_RESULT = V_SUCCESS THEN
                        --获取产品价格
                        BEGIN
                          SELECT NVL(L.ITEM_SETTLE_PRICE, L.ITEM_PRICE)
                            INTO R_PO_LINE.ITEM_PRICE
                            FROM T_SO_LINE L
                           WHERE L.SO_LINE_ID = R_PARAM_LINE.SOURCE_LINE_ID;
                        
                        EXCEPTION
                          WHEN NO_DATA_FOUND THEN
                            R_PO_LINE.ITEM_PRICE := 0;
                        END;
                      END IF;
                    
                      IF OUT_RESULT = V_SUCCESS THEN
                        SELECT S_INV_PO_LINES.NEXTVAL
                          INTO R_PO_LINE.PO_LINE_ID
                          FROM DUAL;
                        R_PO_LINE.PO_LINE_NUM      := R_PO_LINE.PO_LINE_NUM + 1;
                        
                        R_PO_LINE.CREATED_BY       := IN_USER_CODE;
                        R_PO_LINE.CREATION_DATE    := SYSDATE;
                        R_PO_LINE.LAST_UPDATED_BY  := IN_USER_CODE;
                        R_PO_LINE.LAST_UPDATE_DATE := SYSDATE;
                      END IF;
                    
                      --插入采购单行
                      V_IN_PARAM := NULL;
                      BEGIN
                        INSERT INTO T_INV_PO_LINES
                          (PO_LINE_ID,
                           PO_ID,
                           PO_LINE_NUM,
                           ITEM_ID,
                           ITEM_CODE,
                           ITEM_NAME,
                           ITEM_BAR_CODE,
                           UOM_CODE,
                           ITEM_PRICE,
                           BILLED_QTY,
                           CREATED_BY,
                           CREATION_DATE,
                           LAST_UPDATED_BY,
                           LAST_UPDATE_DATE)
                        VALUES
                          (R_PO_LINE.PO_LINE_ID,
                           R_PO_HEAD.PO_ID,
                           R_PO_LINE.PO_LINE_NUM,
                           R_PO_LINE.ITEM_ID,
                           R_PO_LINE.ITEM_CODE,
                           R_PO_LINE.ITEM_NAME,
                           R_PO_LINE.ITEM_BAR_CODE,
                           R_PO_LINE.UOM_CODE,
                           R_PO_LINE.ITEM_PRICE,
                           R_PO_LINE.BILLED_QTY,
                           R_PO_LINE.CREATED_BY,
                           R_PO_LINE.CREATION_DATE,
                           R_PO_LINE.LAST_UPDATED_BY,
                           R_PO_LINE.LAST_UPDATE_DATE);
                      EXCEPTION
                        WHEN OTHERS THEN
                          OUT_RESULT := '新增采购单行失败！' || V_NL || '系统提示：' || SQLERRM;
                          RAISE V_BASE_EXCEPTION;
                      END;
                    END IF;
                  END If;
                  
                END LOOP;
              END IF;
              
              If OUT_RESULT = V_SUCCESS Then
                --插入采购套件行，按退货申请行数据处理即可
                FOR R_ASS_LINE In(
                  Select l.*
                    From t_So_Return_Apply_Line l,t_bd_item t
                   Where l.Apply_Header_Id =
                         r_RETURN_APPLY_HEADER.Apply_Header_Id
                     And l.item_code = t.item_code
                     And t.entity_id = R_PO_HEAD.Entity_Id
                     And t.sales_main_type = R_PO_HEAD.Sales_Main_Type
                  ) Loop
                  --检查套件产品是否有效
                  V_IN_PARAM := '产品编码=' || R_ASS_LINE.Item_Code ||
                                ',名称=' || R_ASS_LINE.Item_Name;
                  BEGIN
                    SELECT I.ITEM_ID, I.ITEM_CODE, I.ITEM_NAME, I.DEFAULTUNIT
                      INTO R_PO_ASS_LINE.ITEM_ID,
                           R_PO_ASS_LINE.ITEM_CODE,
                           R_PO_ASS_LINE.ITEM_NAME,
                           R_PO_ASS_LINE.ITEM_UOM_CODE
                      FROM T_BD_ITEM I
                     WHERE I.ENTITY_ID = R_PO_HEAD.Entity_Id
                       AND I.ITEM_CODE = R_ASS_LINE.Item_Code
                       AND I.ACTIVE_FLAG = V_YES;
                  EXCEPTION
                    WHEN NO_DATA_FOUND THEN
                      OUT_RESULT := '套件产品不存在或已失效，请检查产品属性设置！';
                      RAISE V_BASE_EXCEPTION;
                  End;
                        
                  IF R_ASS_LINE.Tax_Rate IS NULL THEN
                    OUT_RESULT := '退货申请单产品行税率为空，请联系运维人员处理。产品编码=' || R_PO_ASS_LINE.ITEM_CODE;
                    RAISE V_BASE_EXCEPTION;
                  ELSE
                    R_PO_ASS_LINE.LIST_PRICE := ROUND(R_ASS_LINE.APPLIED_PRICE / (1 + R_ASS_LINE.Tax_Rate / 100), 4);
                  END IF;
                  
                  R_PO_ASS_LINE.Source_Line_Id   := R_ASS_LINE.APPLY_LINE_ID;
                  R_PO_ASS_LINE.CREATED_BY       := IN_USER_CODE;
                  R_PO_ASS_LINE.CREATION_DATE    := SYSDATE;
                  R_PO_ASS_LINE.LAST_UPDATED_BY  := IN_USER_CODE;
                  R_PO_ASS_LINE.LAST_UPDATE_DATE := SYSDATE;
                  R_PO_ASS_LINE.Entity_Id := R_PO_HEAD.ENTITY_ID;
                   R_PO_ASS_LINE.PO_HEADER_ID := R_PO_HEAD.PO_ID;
                  SELECT S_INV_PO_ASSEMBLE_LINES.NEXTVAL
                    INTO R_PO_ASS_LINE.ASSEMBLE_LINE_ID
                    FROM DUAL;
                  R_PO_ASS_LINE.ITEM_QTY := r_ass_line.applied_qty;
                  BEGIN
                    INSERT INTO T_INV_PO_ASSEMBLE_LINES
                      (ENTITY_ID,
                       ASSEMBLE_LINE_ID,
                       PO_HEADER_ID,
                       ITEM_ID,
                       ITEM_CODE,
                       ITEM_NAME,
                       ITEM_UOM_CODE,
                       ITEM_QTY,
                       LIST_PRICE,
                       SOURCE_LINE_ID,
                       CREATED_BY,
                       CREATION_DATE,
                       LAST_UPDATED_BY,
                       LAST_UPDATE_DATE,
                       shipped_qty,
                       executed_qty)
                    VALUES
                      (R_PO_ASS_LINE.ENTITY_ID,
                       R_PO_ASS_LINE.ASSEMBLE_LINE_ID,
                       R_PO_ASS_LINE.PO_HEADER_ID,
                       R_PO_ASS_LINE.ITEM_ID,
                       R_PO_ASS_LINE.ITEM_CODE,
                       R_PO_ASS_LINE.ITEM_NAME,
                       R_PO_ASS_LINE.ITEM_UOM_CODE,
                       R_PO_ASS_LINE.ITEM_QTY,
                       R_PO_ASS_LINE.LIST_PRICE,
                       R_PO_ASS_LINE.Source_Line_Id,
                       R_PO_ASS_LINE.CREATED_BY,
                       R_PO_ASS_LINE.CREATION_DATE,
                       R_PO_ASS_LINE.LAST_UPDATED_BY,
                       R_PO_ASS_LINE.LAST_UPDATE_DATE,
                       R_PO_ASS_LINE.ITEM_QTY,
                       R_PO_ASS_LINE.ITEM_QTY);
                  EXCEPTION
                    WHEN OTHERS THEN
                      OUT_RESULT := '插入采购单套件行表失败！' || V_NL || '系统提示：' ||
                                    SQLERRM;
                      RAISE V_BASE_EXCEPTION;
                  END;
                End Loop;
                
              End If;
              
            End Loop;
          End If;
          
          OUT_RETURN_NUMBER := OUT_RETURN_NUMBER || ',' || v_po_num;
          UPDATE T_SO_TO_SUPP_PARAM_HEAD H
             SET H.TO_SUPP_MSG = H.TO_SUPP_MSG || '；采购退货单号：' ||
                                 v_po_num
           WHERE H.PARAM_ID = R_PARAM_HEAD.PARAM_ID;
        
          UPDATE T_SO_HEADER H
             SET H.TO_SUPP_MSG = H.TO_SUPP_MSG || '；采购退货单号：' ||
                                 v_po_num
           WHERE H.SO_HEADER_ID = R_PARAM_HEAD.SOURCE_ORDER_ID;
        END IF;
      END IF;
    
    END IF;
  
  EXCEPTION
    WHEN V_BASE_EXCEPTION THEN
      ROLLBACK TO SAVEPOINT SP_TO_INV_RETURN_USEPARAM;
      OUT_RESULT := '生成退货申请单据出错，错误提示：' || OUT_RESULT || V_NL || V_IN_PARAM;
    WHEN OTHERS THEN
      ROLLBACK TO SAVEPOINT SP_TO_INV_RETURN_USEPARAM;
      OUT_RESULT := '生成退货申请单据出错，错误提示：' || SQLERRM || V_NL || V_IN_PARAM;
  END P_TO_INV_RETURN_USEPARAM;
  ---------------------------------------------------------
  --销售转采购折扣类型或扣率修改后，款项处理
  ---------------------------------------------------------
    PROCEDURE P_SO_ADJUST_CREDIT(IN_ENTITY_ID IN NUMBER, --主体ID
                               IN_PARAM_ID  IN NUMBER, --转采购参数表ID
                               IN_USER_CODE IN VARCHAR2, --操作用户
                               OUT_RESULT   IN OUT VARCHAR2) IS
    R_PARAM_HEAD               T_SO_TO_SUPP_PARAM_HEAD%ROWTYPE;
    R_SO_HEAD                  T_SO_HEADER%ROWTYPE;
    V_IN_PARAM                 VARCHAR2(4000);
    V_ASS_ITEM_CODE            T_BD_ITEM.ITEM_CODE%TYPE; --套件编码
    V_OLD_AMOUNT               NUMBER := 0;
    V_OLD_DIS_AMOUNT           NUMBER := 0;
    V_NEW_AMOUNT               NUMBER := 0;
    V_NEW_DIS_AMOUNT           NUMBER := 0;
    V_DIFF_AMOUNT              NUMBER := 0;
    V_DIFF_DIS_AMOUNT          NUMBER := 0;
    OUT_ERR_NUM                NUMBER;
    V_OS_ATTRIB01              VARCHAR2(1000);
    V_OS_ATTRIB02              VARCHAR2(1000);
    V_PRICE_APPLY_USE_DISCOUNT T_BD_PARAM_LIST.DEFAULT_VALUE%TYPE := 'N'; --价格批文开单使用折扣
    V_ACTION1                  NUMBER;
    V_ACTION_DP1               NUMBER;
    V_ACTION2                  NUMBER;
    V_ACTION_DP2               NUMBER;
    v_Hq_Affirm_Lock_Full_Amount t_bd_param_list.default_value%type := 'N';
  BEGIN
    OUT_RESULT := V_SUCCESS;
    SAVEPOINT SP_SO_ADJUST_CREDIT;
  
    --锁定转采购参数表数据
    V_IN_PARAM := '转采购参数表ID=' || TO_CHAR(IN_PARAM_ID);
    BEGIN
      SELECT *
        INTO R_PARAM_HEAD
        FROM T_SO_TO_SUPP_PARAM_HEAD H
       WHERE H.PARAM_ID = IN_PARAM_ID
         FOR UPDATE NOWAIT;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        OUT_RESULT := '传入参数有误，找不到转采购的数据！';
      WHEN OTHERS THEN
        OUT_RESULT := '锁定销售转采购的数据失败，可能有其他人正在操作，请稍后重试！';
    END;
  
    IF OUT_RESULT = V_SUCCESS THEN
      --获取来源销售单信息
      V_IN_PARAM := '销售单ID=' || TO_CHAR(R_PARAM_HEAD.SOURCE_ORDER_ID) ||
                    ',销售单号=' || R_PARAM_HEAD.SOURCE_ORDER_NUMBER;
      BEGIN
        SELECT H.*
          INTO R_SO_HEAD
          FROM T_SO_HEADER H
         WHERE H.SO_HEADER_ID = R_PARAM_HEAD.SOURCE_ORDER_ID
           FOR UPDATE NOWAIT;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          OUT_RESULT := '找不到转采购的销售单！';
        WHEN OTHERS THEN
          OUT_RESULT := '锁定转采购的销售单失败，可能有其他人正在操作，请稍后重试！';
      END;
    END IF;
  
    --获取价格批文开单使用折扣参数
    BEGIN
      V_PRICE_APPLY_USE_DISCOUNT := PKG_BD.F_GET_PARAMETER_VALUE('PLN_PRICE_APPLY_USE_DISCOUNT',
                                                                 R_PARAM_HEAD.ENTITY_ID);
    EXCEPTION
      WHEN OTHERS THEN
        V_PRICE_APPLY_USE_DISCOUNT := 'N';
    END;
    
    --获取参数:销司订单总部评审锁全款
    Begin
      v_Hq_Affirm_Lock_Full_Amount := Pkg_Bd.f_Get_Parameter_Value('PLN_HQ_AFFIRM_LOCK_FULL_AMOUNT',
                                                         R_PARAM_HEAD.Entity_Id);
    Exception
      When Others Then
        OUT_RESULT := '获取销司订单总部评审锁全款参数PLN_HQ_AFFIRM_LOCK_FULL_AMOUNT参数失败！' || v_Nl ||
                      Sqlerrm;
        Raise v_Base_Exception;
    End;
  
    --循环处理，检查是否有改动过扣率或折扣类型
    V_ASS_ITEM_CODE := '_';
    FOR R_PARAM_LINE IN (SELECT L.*
                           FROM T_SO_TO_SUPP_PARAM_LINE L
                          WHERE L.PARAM_ID = IN_PARAM_ID
                          ORDER BY L.ASS_ITEM_CODE) LOOP
      IF OUT_RESULT = V_SUCCESS THEN
        IF V_ASS_ITEM_CODE <> R_PARAM_LINE.ASS_ITEM_CODE THEN
          V_ASS_ITEM_CODE := R_PARAM_LINE.ASS_ITEM_CODE;
          --有来源客户提货订单的
          IF R_PARAM_HEAD.CUSTOMER_LG_ORDER IS NOT NULL THEN
            FOR R_LG_ORDER_LINE IN (SELECT L.*, H.ORDER_TYPE_CODE, H.ORDER_TYPE_ID, H.LOCK_AMOUNT_FLAG
                                      FROM T_PLN_LG_ORDER_LINE L,
                                           T_PLN_LG_ORDER_HEAD H
                                     WHERE H.ORDER_HEAD_ID = L.ORDER_HEAD_ID
                                       AND H.ORDER_NUMBER =
                                           R_PARAM_HEAD.CUSTOMER_LG_ORDER
                                       AND L.ITEM_CODE =
                                           R_PARAM_LINE.ASS_ITEM_CODE
                                       AND NVL(L.SHARE_VENDOR_TYPE, '_') <> 'AGENT') LOOP
              --首先检查是否修改了折扣类型
              IF NVL(R_PARAM_LINE.DISCOUNT_TYPE, 'COMMON') <>
                 NVL(R_LG_ORDER_LINE.DISCOUNT_TYPE, 'COMMON') THEN
                --原款项情况
                SELECT DECODE(R_LG_ORDER_LINE.PROJECT_ORDER_LINE_ID,
                              NULL,
                              R_LG_ORDER_LINE.LIST_PRICE *
                              (100 - NVL(R_LG_ORDER_LINE.DISCOUNT_RATE, 0) -
                              NVL(R_LG_ORDER_LINE.ORDERED_DISCOUNT_RATE, 0)),
                              R_LG_ORDER_LINE.APPLY_LIST_PRICE *
                              (100 -
                              NVL(R_LG_ORDER_LINE.APPLY_DISCOUNT_RATE, 0) -
                              NVL(R_LG_ORDER_LINE.ORDERED_DISCOUNT_RATE, 0))) *
                       R_PARAM_LINE.ITEM_QTY / 100,
                       DECODE(R_LG_ORDER_LINE.PROJECT_ORDER_LINE_ID,
                              NULL,
                              R_LG_ORDER_LINE.LIST_PRICE *
                              NVL(R_LG_ORDER_LINE.DISCOUNT_RATE, 0),
                              R_LG_ORDER_LINE.APPLY_LIST_PRICE *
                              DECODE(V_PRICE_APPLY_USE_DISCOUNT,
                                     'Y',
                                     NVL(R_LG_ORDER_LINE.APPLY_DISCOUNT_RATE,
                                         0),
                                     0)) * R_PARAM_LINE.ITEM_QTY / 100
                  INTO V_OLD_AMOUNT, V_OLD_DIS_AMOUNT
                  FROM DUAL;
                --修改折扣类型后的款项情况
                SELECT DECODE(R_LG_ORDER_LINE.PROJECT_ORDER_LINE_ID,
                              NULL,
                              R_LG_ORDER_LINE.LIST_PRICE *
                              (100 -
                              NVL(R_PARAM_LINE.CUST_SO_DISCOUNT_RATE, 0) -
                              NVL(R_PARAM_LINE.CUST_SO_MONTH_DIS_RATE, 0)),
                              R_LG_ORDER_LINE.APPLY_LIST_PRICE *
                              (100 -
                              NVL(R_PARAM_LINE.CUST_SO_DISCOUNT_RATE, 0) -
                              NVL(R_PARAM_LINE.CUST_SO_MONTH_DIS_RATE, 0))) *
                       R_PARAM_LINE.ITEM_QTY / 100,
                       DECODE(R_LG_ORDER_LINE.PROJECT_ORDER_LINE_ID,
                              NULL,
                              R_LG_ORDER_LINE.LIST_PRICE *
                              NVL(R_PARAM_LINE.CUST_SO_DISCOUNT_RATE, 0),
                              R_LG_ORDER_LINE.APPLY_LIST_PRICE *
                              DECODE(V_PRICE_APPLY_USE_DISCOUNT,
                                     'Y',
                                     NVL(R_PARAM_LINE.CUST_SO_DISCOUNT_RATE,
                                         0),
                                     0)) * R_PARAM_LINE.ITEM_QTY / 100
                  INTO V_NEW_AMOUNT, V_NEW_DIS_AMOUNT
                  FROM DUAL;
                
                --先解锁原来折扣类型的款项
                IF (R_LG_ORDER_LINE.LOCK_AMOUNT_FLAG = V_LOCK_AMOUNT_FLAG_S AND v_Hq_Affirm_Lock_Full_Amount = 'Y')
                  OR R_LG_ORDER_LINE.LOCK_AMOUNT_FLAG = V_LOCK_AMOUNT_FLAG_HQ
                THEN
                  PKG_PLN_PUB.P_CUSTOMER_AMOUNT_PROCESS(IN_ENTITY_ID       => IN_ENTITY_ID,
                                                      IN_ORDER_TYPE_ID   => R_LG_ORDER_LINE.ORDER_TYPE_ID,
                                                      IN_ORDER_TYPE_CODE => R_LG_ORDER_LINE.ORDER_TYPE_CODE,
                                                      IN_CUSTOMER_ID     => R_PARAM_HEAD.TRANSFER_CUSTOMER_ID,
                                                      IN_ACCOUNT_ID      => R_PARAM_HEAD.TRANSFER_ACCOUNT_ID,
                                                      IN_SALES_MAIN_TYPE => R_LG_ORDER_LINE.SALES_MAIN_TYPE,
                                                      IN_ACTION_TYPE     => 29,
                                                      IN_SOURCE_TYPE     => '02',
                                                      IN_ORDER_ID        => R_LG_ORDER_LINE.ORDER_HEAD_ID,
                                                      IN_PROJ_NUMBER     => null,
                                                      IN_DISCOUNT_TYPE   => NVL(R_LG_ORDER_LINE.DISCOUNT_TYPE, 'COMMON'),
                                                      IN_AMOUNT          => ROUND(V_OLD_AMOUNT, 2),
                                                      IN_DIS_AMOUNT      => ROUND(V_OLD_DIS_AMOUNT, 2),
                                                      IN_RECORD_ERR      => 'N',
                                                      IN_USER_CODE       => IN_USER_CODE,
                                                      OUT_RESULT         => OUT_RESULT);
                  IF OUT_RESULT <> V_SUCCESS THEN
                    OUT_RESULT := '转采购修改折扣类型处理客户款项失败：' || OUT_RESULT;
                  END IF;
                END IF;
              
                IF OUT_RESULT = V_SUCCESS THEN
                  PKG_PLN_PUB.P_CUSTOMER_AMOUNT_PROCESS(IN_ENTITY_ID       => IN_ENTITY_ID,
                                                        IN_ORDER_TYPE_ID   => R_LG_ORDER_LINE.ORDER_TYPE_ID,
                                                        IN_ORDER_TYPE_CODE => R_LG_ORDER_LINE.ORDER_TYPE_CODE,
                                                        IN_CUSTOMER_ID     => R_PARAM_HEAD.TRANSFER_CUSTOMER_ID,
                                                        IN_ACCOUNT_ID      => R_PARAM_HEAD.TRANSFER_ACCOUNT_ID,
                                                        IN_SALES_MAIN_TYPE => R_LG_ORDER_LINE.SALES_MAIN_TYPE,
                                                        IN_ACTION_TYPE     => 2,
                                                        IN_SOURCE_TYPE     => '02',
                                                        IN_ORDER_ID        => R_LG_ORDER_LINE.ORDER_HEAD_ID,
                                                        IN_PROJ_NUMBER     => null,
                                                        IN_DISCOUNT_TYPE   => NVL(R_LG_ORDER_LINE.DISCOUNT_TYPE, 'COMMON'),
                                                        IN_AMOUNT          => ROUND(V_OLD_AMOUNT, 2),
                                                        IN_DIS_AMOUNT      => ROUND(V_OLD_DIS_AMOUNT, 2),
                                                        IN_RECORD_ERR      => 'N',
                                                        IN_USER_CODE       => IN_USER_CODE,
                                                        OUT_RESULT         => OUT_RESULT);
                  IF OUT_RESULT <> V_SUCCESS THEN
                    OUT_RESULT := '转采购修改折扣类型处理客户款项失败：' || OUT_RESULT;
                  END IF;
                END IF;
                /*V_IN_PARAM := '营销大类=' || R_LG_ORDER_LINE.SALES_MAIN_TYPE || V_NL ||
                              '客户ID=' ||
                              TO_CHAR(R_PARAM_HEAD.TRANSFER_CUSTOMER_ID) ||
                              ',客户编码=' ||
                              R_PARAM_HEAD.TRANSFER_CUSTOMER_CODE || V_NL ||
                              ',账户编码=' ||
                              R_PARAM_HEAD.TRANSFER_ACCOUNT_CODE;
                --解锁款项
                PKG_CREDIT_ACCOUNT_CONTROL.PRC_CREDIT_ORDER_BILL(IN_ENTITY_ID, --主体ID
                                                                 2, --动作(取消信用占用）
                                                                 ROUND(V_OLD_AMOUNT,
                                                                       2), --结算金额
                                                                 ROUND(V_OLD_DIS_AMOUNT,
                                                                       2), --折让金额
                                                                 --20170517 hejy3 按行营销大类
                                                                 --v_Sales_Main_Type,
                                                                 R_LG_ORDER_LINE.SALES_MAIN_TYPE,
                                                                 R_PARAM_HEAD.TRANSFER_ACCOUNT_ID, --账户ID
                                                                 R_PARAM_HEAD.TRANSFER_CUSTOMER_ID, --客户ID
                                                                 NULL, --项目编码
                                                                 R_LG_ORDER_LINE.ORDER_HEAD_ID, --单据头ID
                                                                 --r_Lgorder_Head.Order_Type_Name, --单据类型名
                                                                 R_LG_ORDER_LINE.ORDER_TYPE_CODE, --20160912 hejy3 传入订单类型编码
                                                                 IN_USER_CODE,
                                                                 OUT_ERR_NUM,
                                                                 OUT_RESULT,
                                                                 NVL(R_LG_ORDER_LINE.DISCOUNT_TYPE,
                                                                     'COMMON') --add lizhen 2017-08-08
                                                                 );
                IF OUT_RESULT = V_SUCCESS THEN
                  IF NVL(R_LG_ORDER_LINE.DISCOUNT_TYPE, 'COMMON') !=
                     'COMMON' THEN
                    V_IN_PARAM := '营销大类=' ||
                                  R_LG_ORDER_LINE.SALES_MAIN_TYPE || V_NL ||
                                  '客户ID=' ||
                                  TO_CHAR(R_PARAM_HEAD.TRANSFER_CUSTOMER_ID) ||
                                  ',客户编码=' ||
                                  R_PARAM_HEAD.TRANSFER_CUSTOMER_CODE || V_NL ||
                                  ',账户编码=' ||
                                  R_PARAM_HEAD.TRANSFER_ACCOUNT_CODE || V_NL ||
                                  '折扣类型=' || R_LG_ORDER_LINE.DISCOUNT_TYPE;
                    PKG_CREDIT_DIS.P_CHECK_DIS_AMOUNT(IN_ACTION_TYPE     => 2, --操作类型 与信用控制动作标识一致
                                                      IN_ENTITY_ID       => IN_ENTITY_ID, --主体ID
                                                      IN_ACCOUNT_ID      => R_PARAM_HEAD.TRANSFER_ACCOUNT_ID, --客户账户ID
                                                      IS_SOURCE_TYPE     => '02', --来源类型 取码表SO_SRC_TYPE
                                                      IN_SOURCE_BILL_ID  => R_LG_ORDER_LINE.ORDER_HEAD_ID, --来源单据ID 取相应的单据头ID
                                                      IS_SALES_MAIN_TYPE => R_LG_ORDER_LINE.SALES_MAIN_TYPE, --营销大类
                                                      IS_DISCOUNT_TYPE   => NVL(R_LG_ORDER_LINE.DISCOUNT_TYPE,
                                                                                'COMMON'), --折扣类型 取行上的折扣类型
                                                      IN_AMOUNT          => ROUND(V_OLD_AMOUNT,
                                                                                  2), --金额
                                                      IS_USER_NAME       => IN_USER_CODE, --用户编码
                                                      IS_ATTRIB01        => NULL, --预留输入参数01
                                                      IS_ATTRIB02        => NULL, --预留输入参数02
                                                      ON_RESULT          => OUT_ERR_NUM, --成功则返回0，否则返回对应的出错代码
                                                      OS_MESSAGE         => OUT_RESULT, --成功返回“SUCCESS”；失败返回出错信息
                                                      OS_ATTRIB01        => V_OS_ATTRIB01, --预留输出参数01
                                                      OS_ATTRIB02        => V_OS_ATTRIB02 --预留输出参数02
                                                      );
                    IF OUT_RESULT <> V_SUCCESS THEN
                      OUT_RESULT := '修改折扣类型后，检查并解锁折扣类型金额失败，请检查折扣类型余额是否足够！' || V_NL ||
                                    OUT_RESULT;
                    END IF;
                  END IF;
                ELSE
                  OUT_RESULT := '修改折扣类型后，检查并解锁客户款项失败，请检查客户余款是否足够！' || V_NL ||
                                OUT_RESULT;
                END IF;*/
                --重新锁定修改折扣类型后的款项
                IF OUT_RESULT = V_SUCCESS THEN
                  PKG_PLN_PUB.P_CUSTOMER_AMOUNT_PROCESS(IN_ENTITY_ID       => IN_ENTITY_ID,
                                                        IN_ORDER_TYPE_ID   => R_LG_ORDER_LINE.ORDER_TYPE_ID,
                                                        IN_ORDER_TYPE_CODE => R_LG_ORDER_LINE.ORDER_TYPE_CODE,
                                                        IN_CUSTOMER_ID     => R_PARAM_HEAD.TRANSFER_CUSTOMER_ID,
                                                        IN_ACCOUNT_ID      => R_PARAM_HEAD.TRANSFER_ACCOUNT_ID,
                                                        IN_SALES_MAIN_TYPE => R_LG_ORDER_LINE.SALES_MAIN_TYPE,
                                                        IN_ACTION_TYPE     => 1,
                                                        IN_SOURCE_TYPE     => '02',
                                                        IN_ORDER_ID        => R_LG_ORDER_LINE.ORDER_HEAD_ID,
                                                        IN_PROJ_NUMBER     => null,
                                                        IN_DISCOUNT_TYPE   => NVL(R_PARAM_LINE.DISCOUNT_TYPE, 'COMMON'),
                                                        IN_AMOUNT          => ROUND(V_NEW_AMOUNT, 2),
                                                        IN_DIS_AMOUNT      => ROUND(V_NEW_DIS_AMOUNT, 2),
                                                        IN_RECORD_ERR      => 'N',
                                                        IN_USER_CODE       => IN_USER_CODE,
                                                        OUT_RESULT         => OUT_RESULT);
                  IF OUT_RESULT <> V_SUCCESS THEN
                    OUT_RESULT := '转采购修改折扣类型处理客户款项失败：' || OUT_RESULT;
                  END IF;
                  /*V_IN_PARAM := '营销大类=' || R_LG_ORDER_LINE.SALES_MAIN_TYPE || V_NL ||
                                '客户ID=' ||
                                TO_CHAR(R_PARAM_HEAD.TRANSFER_CUSTOMER_ID) ||
                                ',客户编码=' ||
                                R_PARAM_HEAD.TRANSFER_CUSTOMER_CODE || V_NL ||
                                ',账户编码=' ||
                                R_PARAM_HEAD.TRANSFER_ACCOUNT_CODE;
                  --锁定款项
                  PKG_CREDIT_ACCOUNT_CONTROL.PRC_CREDIT_ORDER_BILL(IN_ENTITY_ID, --主体ID
                                                                   1, --动作(取消信用占用）
                                                                   ROUND(V_NEW_AMOUNT,
                                                                         2), --结算金额
                                                                   ROUND(V_NEW_DIS_AMOUNT,
                                                                         2), --折让金额
                                                                   --20170517 hejy3 按行营销大类
                                                                   --v_Sales_Main_Type,
                                                                   R_LG_ORDER_LINE.SALES_MAIN_TYPE,
                                                                   R_PARAM_HEAD.TRANSFER_ACCOUNT_ID, --账户ID
                                                                   R_PARAM_HEAD.TRANSFER_CUSTOMER_ID, --客户ID
                                                                   NULL, --项目编码
                                                                   R_LG_ORDER_LINE.ORDER_HEAD_ID, --单据头ID
                                                                   --r_Lgorder_Head.Order_Type_Name, --单据类型名
                                                                   R_LG_ORDER_LINE.ORDER_TYPE_CODE, --20160912 hejy3 传入订单类型编码
                                                                   IN_USER_CODE,
                                                                   OUT_ERR_NUM,
                                                                   OUT_RESULT,
                                                                   NVL(R_PARAM_LINE.DISCOUNT_TYPE,
                                                                       'COMMON') --add lizhen 2017-08-08
                                                                   );
                  IF OUT_RESULT = V_SUCCESS THEN
                    IF NVL(R_PARAM_LINE.DISCOUNT_TYPE, 'COMMON') !=
                       'COMMON' THEN
                      V_IN_PARAM := '营销大类=' ||
                                    R_LG_ORDER_LINE.SALES_MAIN_TYPE || V_NL ||
                                    '客户ID=' ||
                                    TO_CHAR(R_PARAM_HEAD.TRANSFER_CUSTOMER_ID) ||
                                    ',客户编码=' ||
                                    R_PARAM_HEAD.TRANSFER_CUSTOMER_CODE || V_NL ||
                                    ',账户编码=' ||
                                    R_PARAM_HEAD.TRANSFER_ACCOUNT_CODE || V_NL ||
                                    '折扣类型=' ||
                                    R_LG_ORDER_LINE.DISCOUNT_TYPE;
                      PKG_CREDIT_DIS.P_CHECK_DIS_AMOUNT(IN_ACTION_TYPE     => 1, --操作类型 与信用控制动作标识一致
                                                        IN_ENTITY_ID       => IN_ENTITY_ID, --主体ID
                                                        IN_ACCOUNT_ID      => R_PARAM_HEAD.TRANSFER_ACCOUNT_ID, --客户账户ID
                                                        IS_SOURCE_TYPE     => '02', --来源类型 取码表SO_SRC_TYPE
                                                        IN_SOURCE_BILL_ID  => R_LG_ORDER_LINE.ORDER_HEAD_ID, --来源单据ID 取相应的单据头ID
                                                        IS_SALES_MAIN_TYPE => R_LG_ORDER_LINE.SALES_MAIN_TYPE, --营销大类
                                                        IS_DISCOUNT_TYPE   => NVL(R_PARAM_LINE.DISCOUNT_TYPE,
                                                                                  'COMMON'), --折扣类型 取行上的折扣类型
                                                        IN_AMOUNT          => ROUND(V_NEW_AMOUNT,
                                                                                    2), --金额
                                                        IS_USER_NAME       => IN_USER_CODE, --用户编码
                                                        IS_ATTRIB01        => NULL, --预留输入参数01
                                                        IS_ATTRIB02        => NULL, --预留输入参数02
                                                        ON_RESULT          => OUT_ERR_NUM, --成功则返回0，否则返回对应的出错代码
                                                        OS_MESSAGE         => OUT_RESULT, --成功返回“SUCCESS”；失败返回出错信息
                                                        OS_ATTRIB01        => V_OS_ATTRIB01, --预留输出参数01
                                                        OS_ATTRIB02        => V_OS_ATTRIB02 --预留输出参数02
                                                        );
                      IF OUT_RESULT <> V_SUCCESS THEN
                        OUT_RESULT := '修改折扣类型后，检查并重新锁定折扣类型金额失败，请检查折扣类型余额是否足够！' || V_NL ||
                                      OUT_RESULT;
                      END IF;
                    END IF;
                  ELSE
                    OUT_RESULT := '修改折扣类型后，检查并重新锁定客户款项失败，请检查客户余款是否足够！' || V_NL ||
                                  OUT_RESULT;
                  END IF;*/
                END IF;
                
                IF OUT_RESULT = V_SUCCESS THEN
                  IF (R_LG_ORDER_LINE.LOCK_AMOUNT_FLAG = V_LOCK_AMOUNT_FLAG_S AND v_Hq_Affirm_Lock_Full_Amount = 'Y')
                    OR R_LG_ORDER_LINE.LOCK_AMOUNT_FLAG = V_LOCK_AMOUNT_FLAG_HQ
                  THEN
                    PKG_PLN_PUB.P_CUSTOMER_AMOUNT_PROCESS(IN_ENTITY_ID       => IN_ENTITY_ID,
                                                        IN_ORDER_TYPE_ID   => R_LG_ORDER_LINE.ORDER_TYPE_ID,
                                                        IN_ORDER_TYPE_CODE => R_LG_ORDER_LINE.ORDER_TYPE_CODE,
                                                        IN_CUSTOMER_ID     => R_PARAM_HEAD.TRANSFER_CUSTOMER_ID,
                                                        IN_ACCOUNT_ID      => R_PARAM_HEAD.TRANSFER_ACCOUNT_ID,
                                                        IN_SALES_MAIN_TYPE => R_LG_ORDER_LINE.SALES_MAIN_TYPE,
                                                        IN_ACTION_TYPE     => 28,
                                                        IN_SOURCE_TYPE     => '02',
                                                        IN_ORDER_ID        => R_LG_ORDER_LINE.ORDER_HEAD_ID,
                                                        IN_PROJ_NUMBER     => null,
                                                        IN_DISCOUNT_TYPE   => NVL(R_PARAM_LINE.DISCOUNT_TYPE, 'COMMON'),
                                                        IN_AMOUNT          => ROUND(V_NEW_AMOUNT, 2),
                                                        IN_DIS_AMOUNT      => ROUND(V_NEW_DIS_AMOUNT, 2),
                                                        IN_RECORD_ERR      => 'N',
                                                        IN_USER_CODE       => IN_USER_CODE,
                                                        OUT_RESULT         => OUT_RESULT);
                    IF OUT_RESULT <> V_SUCCESS THEN
                      OUT_RESULT := '转采购修改折扣类型处理客户款项失败：' || OUT_RESULT;
                    END IF;
                  END IF;
                END IF;
                --折扣类型相同，则检查是否修改过扣率，备注：折让到款的是不能修改扣率的，因此不会存在是否修改过的情况
              ELSIF ((NVL(R_PARAM_LINE.CUST_SO_DISCOUNT_RATE, 0) <> NVL(R_LG_ORDER_LINE.DISCOUNT_RATE, 0) AND R_LG_ORDER_LINE.Project_Order_Line_Id IS NULL) OR 
                    (NVL(R_PARAM_LINE.CUST_SO_DISCOUNT_RATE, 0) <> NVL(R_LG_ORDER_LINE.APPLY_DISCOUNT_RATE, 0) AND R_LG_ORDER_LINE.Project_Order_Line_Id IS NOT NULL)) AND
                    NVL(R_LG_ORDER_LINE.DISCOUNT_TYPE, 'COMMON') = 'COMMON' THEN
                --计算差额
                SELECT DECODE(R_LG_ORDER_LINE.PROJECT_ORDER_LINE_ID,
                              NULL,
                              R_LG_ORDER_LINE.LIST_PRICE *
                              (NVL(R_PARAM_LINE.CUST_SO_DISCOUNT_RATE, 0) -
                              NVL(R_LG_ORDER_LINE.DISCOUNT_RATE, 0)),
                              R_LG_ORDER_LINE.APPLY_LIST_PRICE *
                              DECODE(V_PRICE_APPLY_USE_DISCOUNT,
                                     'Y',
                                     (NVL(R_PARAM_LINE.CUST_SO_DISCOUNT_RATE,
                                          0) - NVL(R_LG_ORDER_LINE.APPLY_DISCOUNT_RATE,
                                                    0)),
                                     0)) * R_PARAM_LINE.ITEM_QTY / 100,
                       DECODE(R_LG_ORDER_LINE.PROJECT_ORDER_LINE_ID,
                              NULL,
                              R_LG_ORDER_LINE.LIST_PRICE *
                              (NVL(R_LG_ORDER_LINE.DISCOUNT_RATE, 0) -
                              NVL(R_PARAM_LINE.CUST_SO_DISCOUNT_RATE, 0)),
                              R_LG_ORDER_LINE.APPLY_LIST_PRICE *
                              DECODE(V_PRICE_APPLY_USE_DISCOUNT,
                                     'Y',
                                     (NVL(R_LG_ORDER_LINE.APPLY_DISCOUNT_RATE,
                                          0) - NVL(R_PARAM_LINE.CUST_SO_DISCOUNT_RATE,
                                                    0)),
                                     0)) * R_PARAM_LINE.ITEM_QTY / 100
                  INTO V_DIFF_AMOUNT, V_DIFF_DIS_AMOUNT
                  FROM DUAL;
              
                --结算金额差额大于0，表示调大了扣率，要解锁相应结算金额
                IF V_DIFF_AMOUNT > 0 THEN
                  V_ACTION1 := 2;
                  V_ACTION_DP1 := 29;
                ELSE
                  V_ACTION1 := 1;
                  V_ACTION_DP1 := 28;
                END IF;
              
                --扣率金额差额大于0，表示调小了扣率，要解锁相应扣率金额
                IF V_DIFF_DIS_AMOUNT > 0 THEN
                  V_ACTION2 := 2;
                  V_ACTION_DP2 := 29;
                ELSE
                  V_ACTION2 := 1;
                  V_ACTION_DP2 := 28;
                END IF;
              
                IF OUT_RESULT = V_SUCCESS THEN
                  IF V_DIFF_AMOUNT <> 0 AND V_DIFF_DIS_AMOUNT <> 0 THEN
                    /*V_IN_PARAM := '营销大类=' ||
                                  R_LG_ORDER_LINE.SALES_MAIN_TYPE || V_NL ||
                                  '客户ID=' ||
                                  TO_CHAR(R_PARAM_HEAD.TRANSFER_CUSTOMER_ID) ||
                                  ',客户编码=' ||
                                  R_PARAM_HEAD.TRANSFER_CUSTOMER_CODE || V_NL ||
                                  ',账户编码=' ||
                                  R_PARAM_HEAD.TRANSFER_ACCOUNT_CODE;
                    --处理结算金额
                    PKG_CREDIT_ACCOUNT_CONTROL.PRC_CREDIT_ORDER_BILL(IN_ENTITY_ID, --主体ID
                                                                     V_ACTION1, --动作(取消信用占用）
                                                                     ROUND(ABS(V_DIFF_AMOUNT),
                                                                           2), --结算金额
                                                                     0, --折让金额
                                                                     --20170517 hejy3 按行营销大类
                                                                     --v_Sales_Main_Type,
                                                                     R_LG_ORDER_LINE.SALES_MAIN_TYPE,
                                                                     R_PARAM_HEAD.TRANSFER_ACCOUNT_ID, --账户ID
                                                                     R_PARAM_HEAD.TRANSFER_CUSTOMER_ID, --客户ID
                                                                     NULL, --项目编码
                                                                     R_LG_ORDER_LINE.ORDER_HEAD_ID, --单据头ID
                                                                     --r_Lgorder_Head.Order_Type_Name, --单据类型名
                                                                     R_LG_ORDER_LINE.ORDER_TYPE_CODE, --20160912 hejy3 传入订单类型编码
                                                                     IN_USER_CODE,
                                                                     OUT_ERR_NUM,
                                                                     OUT_RESULT,
                                                                     NVL(R_LG_ORDER_LINE.DISCOUNT_TYPE,
                                                                         'COMMON') --add lizhen 2017-08-08
                                                                     );*/
                    IF V_ACTION1 = 1 THEN
                      IF OUT_RESULT = V_SUCCESS THEN
                        PKG_PLN_PUB.P_CUSTOMER_AMOUNT_PROCESS(IN_ENTITY_ID       => IN_ENTITY_ID,
                                                              IN_ORDER_TYPE_ID   => R_LG_ORDER_LINE.ORDER_TYPE_ID,
                                                              IN_ORDER_TYPE_CODE => R_LG_ORDER_LINE.ORDER_TYPE_CODE,
                                                              IN_CUSTOMER_ID     => R_PARAM_HEAD.TRANSFER_CUSTOMER_ID,
                                                              IN_ACCOUNT_ID      => R_PARAM_HEAD.TRANSFER_ACCOUNT_ID,
                                                              IN_SALES_MAIN_TYPE => R_LG_ORDER_LINE.SALES_MAIN_TYPE,
                                                              IN_ACTION_TYPE     => V_ACTION1,
                                                              IN_SOURCE_TYPE     => '02',
                                                              IN_ORDER_ID        => R_LG_ORDER_LINE.ORDER_HEAD_ID,
                                                              IN_PROJ_NUMBER     => null,
                                                              IN_DISCOUNT_TYPE   => NVL(R_LG_ORDER_LINE.DISCOUNT_TYPE, 'COMMON'),
                                                              IN_AMOUNT          => ROUND(ABS(V_DIFF_AMOUNT), 2),
                                                              IN_DIS_AMOUNT      => 0,
                                                              IN_RECORD_ERR      => 'N',
                                                              IN_USER_CODE       => IN_USER_CODE,
                                                              OUT_RESULT         => OUT_RESULT);
                        IF OUT_RESULT <> V_SUCCESS THEN
                          OUT_RESULT := '转采购修改折扣率处理客户款项失败：' || OUT_RESULT;
                        END IF;
                      END IF;
                      
                      IF OUT_RESULT = V_SUCCESS THEN
                        IF (R_LG_ORDER_LINE.LOCK_AMOUNT_FLAG = V_LOCK_AMOUNT_FLAG_S AND v_Hq_Affirm_Lock_Full_Amount = 'Y')
                          OR R_LG_ORDER_LINE.LOCK_AMOUNT_FLAG = V_LOCK_AMOUNT_FLAG_HQ
                        THEN
                          PKG_PLN_PUB.P_CUSTOMER_AMOUNT_PROCESS(IN_ENTITY_ID       => IN_ENTITY_ID,
                                                                IN_ORDER_TYPE_ID   => R_LG_ORDER_LINE.ORDER_TYPE_ID,
                                                                IN_ORDER_TYPE_CODE => R_LG_ORDER_LINE.ORDER_TYPE_CODE,
                                                                IN_CUSTOMER_ID     => R_PARAM_HEAD.TRANSFER_CUSTOMER_ID,
                                                                IN_ACCOUNT_ID      => R_PARAM_HEAD.TRANSFER_ACCOUNT_ID,
                                                                IN_SALES_MAIN_TYPE => R_LG_ORDER_LINE.SALES_MAIN_TYPE,
                                                                IN_ACTION_TYPE     => V_ACTION_DP1,
                                                                IN_SOURCE_TYPE     => '02',
                                                                IN_ORDER_ID        => R_LG_ORDER_LINE.ORDER_HEAD_ID,
                                                                IN_PROJ_NUMBER     => null,
                                                                IN_DISCOUNT_TYPE   => NVL(R_LG_ORDER_LINE.DISCOUNT_TYPE, 'COMMON'),
                                                                IN_AMOUNT          => ROUND(ABS(V_DIFF_AMOUNT), 2),
                                                                IN_DIS_AMOUNT      => 0,
                                                                IN_RECORD_ERR      => 'N',
                                                                IN_USER_CODE       => IN_USER_CODE,
                                                                OUT_RESULT         => OUT_RESULT);
                          IF OUT_RESULT <> V_SUCCESS THEN
                            OUT_RESULT := '转采购修改折扣率处理客户款项失败：' || OUT_RESULT;
                          END IF;
                        END IF;
                      END IF;
                    ELSE
                      IF OUT_RESULT = V_SUCCESS THEN
                        IF (R_LG_ORDER_LINE.LOCK_AMOUNT_FLAG = V_LOCK_AMOUNT_FLAG_S AND v_Hq_Affirm_Lock_Full_Amount = 'Y')
                          OR R_LG_ORDER_LINE.LOCK_AMOUNT_FLAG = V_LOCK_AMOUNT_FLAG_HQ
                        THEN
                          PKG_PLN_PUB.P_CUSTOMER_AMOUNT_PROCESS(IN_ENTITY_ID       => IN_ENTITY_ID,
                                                                IN_ORDER_TYPE_ID   => R_LG_ORDER_LINE.ORDER_TYPE_ID,
                                                                IN_ORDER_TYPE_CODE => R_LG_ORDER_LINE.ORDER_TYPE_CODE,
                                                                IN_CUSTOMER_ID     => R_PARAM_HEAD.TRANSFER_CUSTOMER_ID,
                                                                IN_ACCOUNT_ID      => R_PARAM_HEAD.TRANSFER_ACCOUNT_ID,
                                                                IN_SALES_MAIN_TYPE => R_LG_ORDER_LINE.SALES_MAIN_TYPE,
                                                                IN_ACTION_TYPE     => V_ACTION_DP1,
                                                                IN_SOURCE_TYPE     => '02',
                                                                IN_ORDER_ID        => R_LG_ORDER_LINE.ORDER_HEAD_ID,
                                                                IN_PROJ_NUMBER     => null,
                                                                IN_DISCOUNT_TYPE   => NVL(R_LG_ORDER_LINE.DISCOUNT_TYPE, 'COMMON'),
                                                                IN_AMOUNT          => ROUND(ABS(V_DIFF_AMOUNT), 2),
                                                                IN_DIS_AMOUNT      => 0,
                                                                IN_RECORD_ERR      => 'N',
                                                                IN_USER_CODE       => IN_USER_CODE,
                                                                OUT_RESULT         => OUT_RESULT);
                          IF OUT_RESULT <> V_SUCCESS THEN
                            OUT_RESULT := '转采购修改折扣率处理客户款项失败：' || OUT_RESULT;
                          END IF;
                        END IF;
                      END IF;
                      
                      IF OUT_RESULT = V_SUCCESS THEN
                        PKG_PLN_PUB.P_CUSTOMER_AMOUNT_PROCESS(IN_ENTITY_ID       => IN_ENTITY_ID,
                                                              IN_ORDER_TYPE_ID   => R_LG_ORDER_LINE.ORDER_TYPE_ID,
                                                              IN_ORDER_TYPE_CODE => R_LG_ORDER_LINE.ORDER_TYPE_CODE,
                                                              IN_CUSTOMER_ID     => R_PARAM_HEAD.TRANSFER_CUSTOMER_ID,
                                                              IN_ACCOUNT_ID      => R_PARAM_HEAD.TRANSFER_ACCOUNT_ID,
                                                              IN_SALES_MAIN_TYPE => R_LG_ORDER_LINE.SALES_MAIN_TYPE,
                                                              IN_ACTION_TYPE     => V_ACTION1,
                                                              IN_SOURCE_TYPE     => '02',
                                                              IN_ORDER_ID        => R_LG_ORDER_LINE.ORDER_HEAD_ID,
                                                              IN_PROJ_NUMBER     => null,
                                                              IN_DISCOUNT_TYPE   => NVL(R_LG_ORDER_LINE.DISCOUNT_TYPE, 'COMMON'),
                                                              IN_AMOUNT          => ROUND(ABS(V_DIFF_AMOUNT), 2),
                                                              IN_DIS_AMOUNT      => 0,
                                                              IN_RECORD_ERR      => 'N',
                                                              IN_USER_CODE       => IN_USER_CODE,
                                                              OUT_RESULT         => OUT_RESULT);
                        IF OUT_RESULT <> V_SUCCESS THEN
                          OUT_RESULT := '转采购修改折扣率处理客户款项失败：' || OUT_RESULT;
                        END IF;
                      END IF;
                    END IF;
                    
                    --处理折让金额
                    IF OUT_RESULT = V_SUCCESS THEN
                      IF V_ACTION2 = 1 THEN
                        IF OUT_RESULT = V_SUCCESS THEN
                          PKG_PLN_PUB.P_CUSTOMER_AMOUNT_PROCESS(IN_ENTITY_ID       => IN_ENTITY_ID,
                                                                IN_ORDER_TYPE_ID   => R_LG_ORDER_LINE.ORDER_TYPE_ID,
                                                                IN_ORDER_TYPE_CODE => R_LG_ORDER_LINE.ORDER_TYPE_CODE,
                                                                IN_CUSTOMER_ID     => R_PARAM_HEAD.TRANSFER_CUSTOMER_ID,
                                                                IN_ACCOUNT_ID      => R_PARAM_HEAD.TRANSFER_ACCOUNT_ID,
                                                                IN_SALES_MAIN_TYPE => R_LG_ORDER_LINE.SALES_MAIN_TYPE,
                                                                IN_ACTION_TYPE     => V_ACTION2,
                                                                IN_SOURCE_TYPE     => '02',
                                                                IN_ORDER_ID        => R_LG_ORDER_LINE.ORDER_HEAD_ID,
                                                                IN_PROJ_NUMBER     => null,
                                                                IN_DISCOUNT_TYPE   => NVL(R_LG_ORDER_LINE.DISCOUNT_TYPE, 'COMMON'),
                                                                IN_AMOUNT          => 0,
                                                                IN_DIS_AMOUNT      => ROUND(ABS(V_DIFF_DIS_AMOUNT), 2),
                                                                IN_RECORD_ERR      => 'N',
                                                                IN_USER_CODE       => IN_USER_CODE,
                                                                OUT_RESULT         => OUT_RESULT);
                          IF OUT_RESULT <> V_SUCCESS THEN
                            OUT_RESULT := '转采购修改折扣率处理客户款项失败：' || OUT_RESULT;
                          END IF;
                        END IF;
                        
                        IF OUT_RESULT = V_SUCCESS THEN
                          IF (R_LG_ORDER_LINE.LOCK_AMOUNT_FLAG = V_LOCK_AMOUNT_FLAG_S AND v_Hq_Affirm_Lock_Full_Amount = 'Y')
                            OR R_LG_ORDER_LINE.LOCK_AMOUNT_FLAG = V_LOCK_AMOUNT_FLAG_HQ
                          THEN
                            PKG_PLN_PUB.P_CUSTOMER_AMOUNT_PROCESS(IN_ENTITY_ID       => IN_ENTITY_ID,
                                                                  IN_ORDER_TYPE_ID   => R_LG_ORDER_LINE.ORDER_TYPE_ID,
                                                                  IN_ORDER_TYPE_CODE => R_LG_ORDER_LINE.ORDER_TYPE_CODE,
                                                                  IN_CUSTOMER_ID     => R_PARAM_HEAD.TRANSFER_CUSTOMER_ID,
                                                                  IN_ACCOUNT_ID      => R_PARAM_HEAD.TRANSFER_ACCOUNT_ID,
                                                                  IN_SALES_MAIN_TYPE => R_LG_ORDER_LINE.SALES_MAIN_TYPE,
                                                                  IN_ACTION_TYPE     => V_ACTION_DP2,
                                                                  IN_SOURCE_TYPE     => '02',
                                                                  IN_ORDER_ID        => R_LG_ORDER_LINE.ORDER_HEAD_ID,
                                                                  IN_PROJ_NUMBER     => null,
                                                                  IN_DISCOUNT_TYPE   => NVL(R_LG_ORDER_LINE.DISCOUNT_TYPE, 'COMMON'),
                                                                  IN_AMOUNT          => 0,
                                                                  IN_DIS_AMOUNT      => ROUND(ABS(V_DIFF_DIS_AMOUNT), 2),
                                                                  IN_RECORD_ERR      => 'N',
                                                                  IN_USER_CODE       => IN_USER_CODE,
                                                                  OUT_RESULT         => OUT_RESULT);
                            IF OUT_RESULT <> V_SUCCESS THEN
                              OUT_RESULT := '转采购修改折扣率处理客户款项失败：' || OUT_RESULT;
                            END IF;
                          END IF;
                        END IF;
                      ELSE
                        IF OUT_RESULT = V_SUCCESS THEN
                          IF (R_LG_ORDER_LINE.LOCK_AMOUNT_FLAG = V_LOCK_AMOUNT_FLAG_S AND v_Hq_Affirm_Lock_Full_Amount = 'Y')
                            OR R_LG_ORDER_LINE.LOCK_AMOUNT_FLAG = V_LOCK_AMOUNT_FLAG_HQ
                          THEN
                            PKG_PLN_PUB.P_CUSTOMER_AMOUNT_PROCESS(IN_ENTITY_ID       => IN_ENTITY_ID,
                                                                  IN_ORDER_TYPE_ID   => R_LG_ORDER_LINE.ORDER_TYPE_ID,
                                                                  IN_ORDER_TYPE_CODE => R_LG_ORDER_LINE.ORDER_TYPE_CODE,
                                                                  IN_CUSTOMER_ID     => R_PARAM_HEAD.TRANSFER_CUSTOMER_ID,
                                                                  IN_ACCOUNT_ID      => R_PARAM_HEAD.TRANSFER_ACCOUNT_ID,
                                                                  IN_SALES_MAIN_TYPE => R_LG_ORDER_LINE.SALES_MAIN_TYPE,
                                                                  IN_ACTION_TYPE     => V_ACTION_DP2,
                                                                  IN_SOURCE_TYPE     => '02',
                                                                  IN_ORDER_ID        => R_LG_ORDER_LINE.ORDER_HEAD_ID,
                                                                  IN_PROJ_NUMBER     => null,
                                                                  IN_DISCOUNT_TYPE   => NVL(R_LG_ORDER_LINE.DISCOUNT_TYPE, 'COMMON'),
                                                                  IN_AMOUNT          => 0,
                                                                  IN_DIS_AMOUNT      => ROUND(ABS(V_DIFF_DIS_AMOUNT), 2),
                                                                  IN_RECORD_ERR      => 'N',
                                                                  IN_USER_CODE       => IN_USER_CODE,
                                                                  OUT_RESULT         => OUT_RESULT);
                            IF OUT_RESULT <> V_SUCCESS THEN
                              OUT_RESULT := '转采购修改折扣率处理客户款项失败：' || OUT_RESULT;
                            END IF;
                          END IF;
                        END IF;
                        
                        IF OUT_RESULT = V_SUCCESS THEN
                          PKG_PLN_PUB.P_CUSTOMER_AMOUNT_PROCESS(IN_ENTITY_ID       => IN_ENTITY_ID,
                                                                IN_ORDER_TYPE_ID   => R_LG_ORDER_LINE.ORDER_TYPE_ID,
                                                                IN_ORDER_TYPE_CODE => R_LG_ORDER_LINE.ORDER_TYPE_CODE,
                                                                IN_CUSTOMER_ID     => R_PARAM_HEAD.TRANSFER_CUSTOMER_ID,
                                                                IN_ACCOUNT_ID      => R_PARAM_HEAD.TRANSFER_ACCOUNT_ID,
                                                                IN_SALES_MAIN_TYPE => R_LG_ORDER_LINE.SALES_MAIN_TYPE,
                                                                IN_ACTION_TYPE     => V_ACTION2,
                                                                IN_SOURCE_TYPE     => '02',
                                                                IN_ORDER_ID        => R_LG_ORDER_LINE.ORDER_HEAD_ID,
                                                                IN_PROJ_NUMBER     => null,
                                                                IN_DISCOUNT_TYPE   => NVL(R_LG_ORDER_LINE.DISCOUNT_TYPE, 'COMMON'),
                                                                IN_AMOUNT          => 0,
                                                                IN_DIS_AMOUNT      => ROUND(ABS(V_DIFF_DIS_AMOUNT), 2),
                                                                IN_RECORD_ERR      => 'N',
                                                                IN_USER_CODE       => IN_USER_CODE,
                                                                OUT_RESULT         => OUT_RESULT);
                          IF OUT_RESULT <> V_SUCCESS THEN
                            OUT_RESULT := '转采购修改折扣率处理客户款项失败：' || OUT_RESULT;
                          END IF;
                        END IF;
                      END IF;
                    END IF;
                    /*IF OUT_RESULT = V_SUCCESS THEN
                      --处理折让金额
                      PKG_CREDIT_ACCOUNT_CONTROL.PRC_CREDIT_ORDER_BILL(IN_ENTITY_ID, --主体ID
                                                                       V_ACTION2, --动作(取消信用占用）
                                                                       0, --结算金额
                                                                       ROUND(ABS(V_DIFF_DIS_AMOUNT),
                                                                             2), --折让金额
                                                                       --20170517 hejy3 按行营销大类
                                                                       --v_Sales_Main_Type,
                                                                       R_LG_ORDER_LINE.SALES_MAIN_TYPE,
                                                                       R_PARAM_HEAD.TRANSFER_ACCOUNT_ID, --账户ID
                                                                       R_PARAM_HEAD.TRANSFER_CUSTOMER_ID, --客户ID
                                                                       NULL, --项目编码
                                                                       R_LG_ORDER_LINE.ORDER_HEAD_ID, --单据头ID
                                                                       --r_Lgorder_Head.Order_Type_Name, --单据类型名
                                                                       R_LG_ORDER_LINE.ORDER_TYPE_CODE, --20160912 hejy3 传入订单类型编码
                                                                       IN_USER_CODE,
                                                                       OUT_ERR_NUM,
                                                                       OUT_RESULT,
                                                                       NVL(R_LG_ORDER_LINE.DISCOUNT_TYPE,
                                                                           'COMMON') --add lizhen 2017-08-08
                                                                       );
                      IF OUT_RESULT <> V_SUCCESS THEN
                        OUT_RESULT := '修改扣率后，检查并重新处理折扣金额失败，请检查客户折扣金额是否足够！' || V_NL ||
                                      OUT_RESULT;
                      END IF;
                    ELSE
                      OUT_RESULT := '修改扣率后，检查并重新处理金额失败，请检查客户余款是否足够！' || V_NL ||
                                    OUT_RESULT;
                    END IF;*/
                  END IF;
                END IF;
              
              END IF;
            END LOOP;
            --直发，没有客户来源单号的,销售单头的直发客户id不为空的
          ELSIF NVL(R_PARAM_HEAD.DIRECT_SEND_FLAG, 'N') = 'Y' AND
                R_PARAM_HEAD.CUSTOMER_LG_ORDER IS NULL AND
                R_SO_HEAD.TRANSFER_ACCOUNT_ID IS NOT NULL THEN
            FOR R_SO_LINE IN (SELECT *
                                FROM T_SO_LINE SL
                               WHERE SL.SO_LINE_ID =
                                     R_PARAM_LINE.SOURCE_LINE_ID) LOOP
              --首先检查是否修改了折扣类型
              IF R_SO_LINE.TRANSFER_DISCOUNT_TYPE <>
                 R_PARAM_LINE.DISCOUNT_TYPE THEN
                --原款项情况
                SELECT R_SO_LINE.TRANSFER_LIST_PRICE *
                       (100 - NVL(R_SO_LINE.TRANSFER_DISCOUNT_RATE, 0) -
                       NVL(R_SO_LINE.TRANSFER_MONTH_DISCOUNT_RATE, 0)) *
                       R_PARAM_LINE.ITEM_QTY / 100,
                       R_SO_LINE.TRANSFER_LIST_PRICE *
                       NVL(R_SO_LINE.TRANSFER_DISCOUNT_RATE, 0) *
                       R_PARAM_LINE.ITEM_QTY / 100
                  INTO V_OLD_AMOUNT, V_OLD_DIS_AMOUNT
                  FROM DUAL;
                --修改折扣类型后的款项情况
                SELECT R_SO_LINE.TRANSFER_LIST_PRICE *
                       (100 - NVL(R_PARAM_LINE.CUST_SO_DISCOUNT_RATE, 0) -
                       NVL(R_PARAM_LINE.CUST_SO_MONTH_DIS_RATE, 0)) *
                       R_PARAM_LINE.ITEM_QTY / 100,
                       R_SO_LINE.TRANSFER_LIST_PRICE *
                       NVL(R_PARAM_LINE.CUST_SO_DISCOUNT_RATE, 0) *
                       R_PARAM_LINE.ITEM_QTY / 100
                  INTO V_NEW_AMOUNT, V_NEW_DIS_AMOUNT
                  FROM DUAL;
              
                --先解锁原来折扣类型的款项
                V_IN_PARAM := '营销大类=' || R_PARAM_LINE.ASS_ITEM_MAIN_TYPE || V_NL ||
                              '客户ID=' ||
                              TO_CHAR(R_PARAM_HEAD.TRANSFER_CUSTOMER_ID) ||
                              ',客户编码=' ||
                              R_PARAM_HEAD.TRANSFER_CUSTOMER_CODE || V_NL ||
                              ',账户编码=' ||
                              R_PARAM_HEAD.TRANSFER_ACCOUNT_CODE;
                --解锁款项
                PKG_CREDIT_ACCOUNT_CONTROL.PRC_CREDIT_ORDER_BILL(IN_ENTITY_ID, --主体ID
                                                                 2, --动作(取消信用占用）
                                                                 ROUND(V_OLD_AMOUNT,
                                                                       2), --结算金额
                                                                 ROUND(V_OLD_DIS_AMOUNT,
                                                                       2), --折让金额
                                                                 --20170517 hejy3 按行营销大类
                                                                 --v_Sales_Main_Type,
                                                                 R_PARAM_LINE.ASS_ITEM_MAIN_TYPE,
                                                                 R_PARAM_HEAD.TRANSFER_ACCOUNT_ID, --账户ID
                                                                 R_PARAM_HEAD.TRANSFER_CUSTOMER_ID, --客户ID
                                                                 NULL, --项目编码
                                                                 R_SO_HEAD.RAW_SRC_BILL_ID, --单据头ID
                                                                 --r_Lgorder_Head.Order_Type_Name, --单据类型名
                                                                 R_SO_HEAD.RAW_SRC_BILL_TYPE_CODE, --20160912 hejy3 传入订单类型编码
                                                                 IN_USER_CODE,
                                                                 OUT_ERR_NUM,
                                                                 OUT_RESULT,
                                                                 NVL(R_SO_LINE.TRANSFER_DISCOUNT_TYPE,
                                                                     'COMMON') --add lizhen 2017-08-08
                                                                 );
                IF OUT_RESULT = V_SUCCESS THEN
                  IF NVL(R_SO_LINE.TRANSFER_DISCOUNT_TYPE, 'COMMON') != 'COMMON' THEN
                    V_IN_PARAM := '营销大类=' ||
                                  R_PARAM_LINE.ASS_ITEM_MAIN_TYPE || V_NL ||
                                  '客户ID=' ||
                                  TO_CHAR(R_PARAM_HEAD.TRANSFER_CUSTOMER_ID) ||
                                  ',客户编码=' ||
                                  R_PARAM_HEAD.TRANSFER_CUSTOMER_CODE || V_NL ||
                                  ',账户编码=' ||
                                  R_PARAM_HEAD.TRANSFER_ACCOUNT_CODE || V_NL ||
                                  '折扣类型=' || R_SO_LINE.TRANSFER_DISCOUNT_TYPE;
                    PKG_CREDIT_DIS.P_CHECK_DIS_AMOUNT(IN_ACTION_TYPE     => 2, --操作类型 与信用控制动作标识一致
                                                      IN_ENTITY_ID       => IN_ENTITY_ID, --主体ID
                                                      IN_ACCOUNT_ID      => R_PARAM_HEAD.TRANSFER_ACCOUNT_ID, --客户账户ID
                                                      IS_SOURCE_TYPE     => '01', --来源类型 取码表SO_SRC_TYPE
                                                      IN_SOURCE_BILL_ID  => R_SO_HEAD.RAW_SRC_BILL_ID, --来源单据ID 取相应的单据头ID
                                                      IS_SALES_MAIN_TYPE => R_PARAM_LINE.ASS_ITEM_MAIN_TYPE, --营销大类
                                                      IS_DISCOUNT_TYPE   => NVL(R_SO_LINE.TRANSFER_DISCOUNT_TYPE,
                                                                                'COMMON'), --折扣类型 取行上的折扣类型
                                                      IN_AMOUNT          => ROUND(V_OLD_AMOUNT,
                                                                                  2), --金额
                                                      IS_USER_NAME       => IN_USER_CODE, --用户编码
                                                      IS_ATTRIB01        => NULL, --预留输入参数01
                                                      IS_ATTRIB02        => NULL, --预留输入参数02
                                                      ON_RESULT          => OUT_ERR_NUM, --成功则返回0，否则返回对应的出错代码
                                                      OS_MESSAGE         => OUT_RESULT, --成功返回“SUCCESS”；失败返回出错信息
                                                      OS_ATTRIB01        => V_OS_ATTRIB01, --预留输出参数01
                                                      OS_ATTRIB02        => V_OS_ATTRIB02 --预留输出参数02
                                                      );
                    IF OUT_RESULT <> V_SUCCESS THEN
                      OUT_RESULT := '修改折扣类型后，检查并解锁折扣类型金额失败，请检查折扣类型余额是否足够！' || V_NL ||
                                    OUT_RESULT;
                    END IF;
                  END IF;
                ELSE
                  OUT_RESULT := '修改折扣类型后，检查并解锁客户款项失败，请检查客户余款是否足够！' || V_NL ||
                                OUT_RESULT;
                END IF;
                --重新锁定修改折扣类型后的款项
                IF OUT_RESULT = V_SUCCESS THEN
                  V_IN_PARAM := '营销大类=' || R_PARAM_LINE.ASS_ITEM_MAIN_TYPE || V_NL ||
                                '客户ID=' ||
                                TO_CHAR(R_PARAM_HEAD.TRANSFER_CUSTOMER_ID) ||
                                ',客户编码=' ||
                                R_PARAM_HEAD.TRANSFER_CUSTOMER_CODE || V_NL ||
                                ',账户编码=' ||
                                R_PARAM_HEAD.TRANSFER_ACCOUNT_CODE;
                  --锁定
                  PKG_CREDIT_ACCOUNT_CONTROL.PRC_CREDIT_ORDER_BILL(IN_ENTITY_ID, --主体ID
                                                                   1, --动作(取消信用占用）
                                                                   ROUND(V_NEW_AMOUNT,
                                                                         2), --结算金额
                                                                   ROUND(V_NEW_DIS_AMOUNT,
                                                                         2), --折让金额
                                                                   --20170517 hejy3 按行营销大类
                                                                   --v_Sales_Main_Type,
                                                                   R_PARAM_LINE.ASS_ITEM_MAIN_TYPE,
                                                                   R_PARAM_HEAD.TRANSFER_ACCOUNT_ID, --账户ID
                                                                   R_PARAM_HEAD.TRANSFER_CUSTOMER_ID, --客户ID
                                                                   NULL, --项目编码
                                                                   R_SO_HEAD.RAW_SRC_BILL_ID, --单据头ID
                                                                   --r_Lgorder_Head.Order_Type_Name, --单据类型名
                                                                   R_SO_HEAD.RAW_SRC_BILL_TYPE_CODE, --20160912 hejy3 传入订单类型编码
                                                                   IN_USER_CODE,
                                                                   OUT_ERR_NUM,
                                                                   OUT_RESULT,
                                                                   NVL(R_PARAM_LINE.DISCOUNT_TYPE,
                                                                       'COMMON') --add lizhen 2017-08-08
                                                                   );
                  IF OUT_RESULT = V_SUCCESS THEN
                    IF NVL(R_PARAM_LINE.DISCOUNT_TYPE, 'COMMON') !=
                       'COMMON' THEN
                      V_IN_PARAM := '营销大类=' ||
                                    R_PARAM_LINE.ASS_ITEM_MAIN_TYPE || V_NL ||
                                    '客户ID=' ||
                                    TO_CHAR(R_PARAM_HEAD.TRANSFER_CUSTOMER_ID) ||
                                    ',客户编码=' ||
                                    R_PARAM_HEAD.TRANSFER_CUSTOMER_CODE || V_NL ||
                                    ',账户编码=' ||
                                    R_PARAM_HEAD.TRANSFER_ACCOUNT_CODE || V_NL ||
                                    '折扣类型=' || R_PARAM_LINE.DISCOUNT_TYPE;
                      PKG_CREDIT_DIS.P_CHECK_DIS_AMOUNT(IN_ACTION_TYPE     => 1, --操作类型 与信用控制动作标识一致
                                                        IN_ENTITY_ID       => IN_ENTITY_ID, --主体ID
                                                        IN_ACCOUNT_ID      => R_PARAM_HEAD.TRANSFER_ACCOUNT_ID, --客户账户ID
                                                        IS_SOURCE_TYPE     => '01', --来源类型 取码表SO_SRC_TYPE
                                                        IN_SOURCE_BILL_ID  => R_SO_HEAD.RAW_SRC_BILL_ID, --来源单据ID 取相应的单据头ID
                                                        IS_SALES_MAIN_TYPE => R_PARAM_LINE.ASS_ITEM_MAIN_TYPE, --营销大类
                                                        IS_DISCOUNT_TYPE   => NVL(R_PARAM_LINE.DISCOUNT_TYPE,
                                                                                  'COMMON'), --折扣类型 取行上的折扣类型
                                                        IN_AMOUNT          => ROUND(V_OLD_AMOUNT,
                                                                                    2), --金额
                                                        IS_USER_NAME       => IN_USER_CODE, --用户编码
                                                        IS_ATTRIB01        => NULL, --预留输入参数01
                                                        IS_ATTRIB02        => NULL, --预留输入参数02
                                                        ON_RESULT          => OUT_ERR_NUM, --成功则返回0，否则返回对应的出错代码
                                                        OS_MESSAGE         => OUT_RESULT, --成功返回“SUCCESS”；失败返回出错信息
                                                        OS_ATTRIB01        => V_OS_ATTRIB01, --预留输出参数01
                                                        OS_ATTRIB02        => V_OS_ATTRIB02 --预留输出参数02
                                                        );
                      IF OUT_RESULT <> V_SUCCESS THEN
                        OUT_RESULT := '修改折扣类型后，检查并解锁折扣类型金额失败，请检查折扣类型余额是否足够！' || V_NL ||
                                      OUT_RESULT;
                      END IF;
                    END IF;
                  ELSE
                    OUT_RESULT := '修改折扣类型后，检查并解锁客户款项失败，请检查客户余款是否足够！' || V_NL ||
                                  OUT_RESULT;
                  END IF;
                END IF;
                --折扣类型相同，则检查是否修改过扣率 备注：折让到款的是不能修改扣率的，因此不会存在是否修改过的情况
              ELSIF NVL(R_SO_LINE.TRANSFER_DISCOUNT_RATE, 0) <>
                    NVL(R_PARAM_LINE.CUST_SO_DISCOUNT_RATE, 0) AND
                    NVL(R_SO_LINE.TRANSFER_DISCOUNT_TYPE, 'COMMON') =
                    'COMMON' THEN
                --计算差额
                SELECT R_SO_LINE.TRANSFER_LIST_PRICE *
                       (NVL(R_PARAM_LINE.CUST_SO_DISCOUNT_RATE, 0) -
                       NVL(R_SO_LINE.TRANSFER_DISCOUNT_RATE, 0)) *
                       R_PARAM_LINE.ITEM_QTY / 100,
                       R_SO_LINE.TRANSFER_LIST_PRICE *
                       (NVL(R_SO_LINE.TRANSFER_DISCOUNT_RATE, 0) -
                       NVL(R_PARAM_LINE.CUST_SO_DISCOUNT_RATE, 0)) *
                       R_PARAM_LINE.ITEM_QTY / 100
                  INTO V_DIFF_AMOUNT, V_DIFF_DIS_AMOUNT
                  FROM DUAL;
              
                --结算金额差额大于0，表示调大了扣率，要解锁相应结算金额
                IF V_DIFF_AMOUNT > 0 THEN
                  V_ACTION1 := 2;
                ELSE
                  V_ACTION1 := 1;
                END IF;
              
                --扣率金额差额大于0，表示调小了扣率，要解锁相应扣率金额
                IF V_DIFF_DIS_AMOUNT > 0 THEN
                  V_ACTION2 := 2;
                ELSE
                  V_ACTION2 := 1;
                END IF;
              
                IF OUT_RESULT = V_SUCCESS THEN
                  IF V_DIFF_AMOUNT <> 0 AND V_DIFF_DIS_AMOUNT <> 0 THEN
                    V_IN_PARAM := '营销大类=' ||
                                  R_PARAM_LINE.ASS_ITEM_MAIN_TYPE || V_NL ||
                                  '客户ID=' ||
                                  TO_CHAR(R_PARAM_HEAD.TRANSFER_CUSTOMER_ID) ||
                                  ',客户编码=' ||
                                  R_PARAM_HEAD.TRANSFER_CUSTOMER_CODE || V_NL ||
                                  ',账户编码=' ||
                                  R_PARAM_HEAD.TRANSFER_ACCOUNT_CODE;
                    --处理结算金额
                    PKG_CREDIT_ACCOUNT_CONTROL.PRC_CREDIT_ORDER_BILL(IN_ENTITY_ID, --主体ID
                                                                     V_ACTION1, --动作(取消信用占用）
                                                                     ROUND(ABS(V_DIFF_AMOUNT),
                                                                           2), --结算金额
                                                                     0, --折让金额
                                                                     --20170517 hejy3 按行营销大类
                                                                     --v_Sales_Main_Type,
                                                                     R_PARAM_LINE.ASS_ITEM_MAIN_TYPE,
                                                                     R_PARAM_HEAD.TRANSFER_ACCOUNT_ID, --账户ID
                                                                     R_PARAM_HEAD.TRANSFER_CUSTOMER_ID, --客户ID
                                                                     NULL, --项目编码
                                                                     R_SO_HEAD.RAW_SRC_BILL_ID, --单据头ID
                                                                     --r_Lgorder_Head.Order_Type_Name, --单据类型名
                                                                     R_SO_HEAD.RAW_SRC_BILL_TYPE_CODE, --20160912 hejy3 传入订单类型编码
                                                                     IN_USER_CODE,
                                                                     OUT_ERR_NUM,
                                                                     OUT_RESULT,
                                                                     NVL(R_SO_LINE.TRANSFER_DISCOUNT_TYPE,
                                                                         'COMMON') --add lizhen 2017-08-08
                                                                     );
                    IF OUT_RESULT = V_SUCCESS THEN
                      --处理折让金额
                      PKG_CREDIT_ACCOUNT_CONTROL.PRC_CREDIT_ORDER_BILL(IN_ENTITY_ID, --主体ID
                                                                       V_ACTION2, --动作(取消信用占用）
                                                                       0, --结算金额
                                                                       ROUND(ABS(V_DIFF_DIS_AMOUNT),
                                                                             2), --折让金额
                                                                       --20170517 hejy3 按行营销大类
                                                                       --v_Sales_Main_Type,
                                                                       R_PARAM_LINE.ASS_ITEM_MAIN_TYPE,
                                                                       R_PARAM_HEAD.TRANSFER_ACCOUNT_ID, --账户ID
                                                                       R_PARAM_HEAD.TRANSFER_CUSTOMER_ID, --客户ID
                                                                       NULL, --项目编码
                                                                       R_SO_HEAD.RAW_SRC_BILL_ID, --单据头ID
                                                                       --r_Lgorder_Head.Order_Type_Name, --单据类型名
                                                                       R_SO_HEAD.RAW_SRC_BILL_TYPE_CODE, --20160912 hejy3 传入订单类型编码
                                                                       IN_USER_CODE,
                                                                       OUT_ERR_NUM,
                                                                       OUT_RESULT,
                                                                       NVL(R_SO_LINE.TRANSFER_DISCOUNT_TYPE,
                                                                           'COMMON') --add lizhen 2017-08-08
                                                                       );
                      IF OUT_RESULT <> V_SUCCESS THEN
                        OUT_RESULT := '修改扣率后，检查并重新处理折扣金额失败，请检查客户折扣金额是否足够！' || V_NL ||
                                      OUT_RESULT;
                      END IF;
                    ELSE
                      OUT_RESULT := '修改扣率后，检查并重新处理金额失败，请检查客户余款是否足够！' || V_NL ||
                                    OUT_RESULT;
                    END IF;
                  END IF;
                END IF;
              END IF;
            END LOOP;
          END IF;
        END IF;
      END IF;
    END LOOP;
  
  EXCEPTION
    WHEN V_BASE_EXCEPTION THEN
      ROLLBACK TO SAVEPOINT SP_SO_ADJUST_CREDIT;
      OUT_RESULT := '修改折扣类型或扣率处理款项出错，错误提示：' || OUT_RESULT || V_NL ||
                    V_IN_PARAM;
    WHEN OTHERS THEN
      ROLLBACK TO SAVEPOINT SP_SO_ADJUST_CREDIT;
      OUT_RESULT := '修改折扣类型或扣率处理款项出错，错误提示：' || SQLERRM || V_NL ||
                    V_IN_PARAM;
  END P_SO_ADJUST_CREDIT;
  
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2018-03-27
  *     创建者：周建刚
  *   功能说明：总部销售单结算更新销司PO价格以及PO引NC接口表信息
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_SETTLE_PO_UPDATE(P_SO_HEADER_ID IN T_SO_HEADER.SO_HEADER_ID%TYPE, --销售单头id
                                  P_RESULT       IN OUT NUMBER, --返回错误ID
                                  P_ERR_MSG      IN OUT VARCHAR2 --返回错误信息
                                  ) AS
    --销售单据头
    R_SO_HEADER             T_SO_HEADER%ROWTYPE;
    
    R_INTF_NC_INV_HEADER    INTF_NC_INV_HEADER%ROWTYPE;
    V_PO_INTF_CONTROL_FLAG  VARCHAR2(2) := 'N';
    V_NC_PO_INTF_COUNT      NUMBER       := 0;
    V_TAX_RATE NUMBER; --20180409 hejy3 默认税率
  BEGIN
    --初始返回值
    P_RESULT  := PKG_SO_PUB.V_RESULT;
    P_ERR_MSG := PKG_SO_PUB.V_SUCCESS;
    
    --获取销售单头信息
    SELECT H.* INTO R_SO_HEADER FROM CIMS.T_SO_HEADER H
     WHERE H.SO_HEADER_ID = P_SO_HEADER_ID;
     
    --chenyj8,20180817,退货单需要关联退货申请找到采购退货单更新
    IF R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE = PKG_SO_PUB.V_BIZ_SRC_BILL_RETURN
       AND R_SO_HEADER.SRC_BILL_NUM IS NOT NULL THEN
     UPDATE CIMS.INTF_NC_INV_HEADER H
        SET H.INTF_STATUS      = PKG_SO_PUB.V_NO,
            H.ACCOUNT_PERIOD   = R_SO_HEADER.SETTLE_DATE,
            H.BILL_DATE        = R_SO_HEADER.SETTLE_DATE,
            H.LAST_UPDATE_DATE = SYSDATE,
            H.LAST_UPDATED_BY  = R_SO_HEADER.LAST_UPDATED_BY
      WHERE H.INTF_STATUS = V_PO_NC_INV_INTF_STATUS_WAIT
        AND EXISTS (SELECT 1
               FROM T_INV_PO_HEADERS         POH,
                    T_SO_HEADER              SOH,
                    T_SO_RETURN_APPLY_HEADER AH
              WHERE H.ORDER_NUM = POH.PO_NUM
                AND SOH.SO_HEADER_ID = P_SO_HEADER_ID
                AND SOH.SRC_BILL_NUM = AH.BILL_NUM
                AND POH.SCHED_ORDER_NUM = AH.BILL_NUM);
    END IF;
    
    --判断是否有对应的PO单接口记录(等待状态)
    SELECT COUNT(1)
      INTO V_NC_PO_INTF_COUNT
      FROM INTF_NC_INV_HEADER H
     WHERE H.INTF_STATUS = V_PO_NC_INV_INTF_STATUS_WAIT
       AND EXISTS (SELECT 1
              FROM T_INV_PO_HEADERS POH, T_SO_HEADER SOH
             WHERE H.ORDER_NUM = POH.PO_NUM
               AND POH.SOURCE_TYPE = '销售转采购'
               AND POH.SOURCE_ORDER_NUM = SOH.SO_NUM
               AND SOH.TO_SUPP_FLAG = PKG_SO_PUB.V_YES
               AND SOH.SO_HEADER_ID = P_SO_HEADER_ID);
    
    IF V_NC_PO_INTF_COUNT < 1 THEN
      RETURN;
    END IF;

    SELECT H.*
      INTO R_INTF_NC_INV_HEADER
      FROM INTF_NC_INV_HEADER H
     WHERE H.INTF_STATUS = V_PO_NC_INV_INTF_STATUS_WAIT
       AND EXISTS (SELECT 1
              FROM T_INV_PO_HEADERS POH, T_SO_HEADER SOH
             WHERE H.ORDER_NUM = POH.PO_NUM
               AND POH.SOURCE_TYPE = '销售转采购'
               AND POH.SOURCE_ORDER_NUM = SOH.SO_NUM
               AND SOH.TO_SUPP_FLAG = PKG_SO_PUB.V_YES
               AND SOH.SO_HEADER_ID = P_SO_HEADER_ID)
       AND ROWNUM = 1;
    
    --销售转采购：总部销售单结算后销司PO单才引入NC控制标识
    BEGIN
      PKG_BD.P_GET_PARAMETER_VALUE(V_NC_PO_INTF_CONTROL_FLAG,
                                   R_INTF_NC_INV_HEADER.ENTITY_ID,
                                   NULL,
                                   NULL,
                                   V_PO_INTF_CONTROL_FLAG);
    EXCEPTION
      WHEN OTHERS THEN
        P_ERR_MSG := 'SO_TO_PO_NC_PO_INTF_CONTROL_FLAG 主体参数,主体:' ||
                     R_INTF_NC_INV_HEADER.ENTITY_ID || '的参数设置异常，请检查。' ||
                     SQLERRM;
        RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
    END;
    
    IF(V_PO_INTF_CONTROL_FLAG <> PKG_SO_PUB.V_YES) THEN
      RETURN;
    END IF;
    
    FOR REC IN (SELECT L.*
                  FROM T_SO_LINE L
                 WHERE L.SO_HEADER_ID = P_SO_HEADER_ID
                 ORDER BY L.SO_LINE_NUM) LOOP
      
      IF REC.TAX_RATE IS NULL THEN
        P_RESULT := -27001;
        P_ERR_MSG := '销售单产品行税率为空，请联系运维人员处理。产品编码=' || REC.ITEM_CODE;
        RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      ELSE
        V_TAX_RATE := REC.TAX_RATE;
      END IF;
      
      --根据结算时最新的价格，更新PO套件行价格
      UPDATE CIMS.T_INV_PO_ASSEMBLE_LINES L
         SET L.LIST_PRICE      =
             (ROUND(NVL(REC.ITEM_SETTLE_PRICE, REC.ITEM_PRICE) / (1 + V_TAX_RATE / 100), 4)), --hejy3 使用系统配置税率
             L.LAST_UPDATE_DATE = SYSDATE,
             L.LAST_UPDATED_BY  = R_SO_HEADER.LAST_UPDATED_BY
       WHERE L.SOURCE_LINE_ID = REC.SO_LINE_ID;
       
      --根据结算时最新的价格，更新PO接口表行价格
      UPDATE CIMS.INTF_NC_INV_LINE L
         SET L.ITEM_PRICE =
             (ROUND(NVL(REC.ITEM_SETTLE_PRICE, REC.ITEM_PRICE) / (1 + V_TAX_RATE / 100), 4)), --hejy3 使用系统配置税率
             L.BILL_DATE  = R_SO_HEADER.SETTLE_DATE
       WHERE L.ITEM_CODE = REC.ITEM_CODE
         AND EXISTS
       (SELECT 1
                FROM T_INV_PO_HEADERS   POH,
                     T_SO_HEADER        SOH,
                     INTF_NC_INV_HEADER H
               WHERE H.INTF_STATUS = V_PO_NC_INV_INTF_STATUS_WAIT
                 AND H.INTF_ID = L.INTF_ID
                 AND H.ORDER_NUM = POH.PO_NUM
                 AND POH.SOURCE_TYPE = '销售转采购'
                 AND POH.SOURCE_ORDER_NUM = SOH.SO_NUM
                 AND SOH.TO_SUPP_FLAG = PKG_SO_PUB.V_YES
                 AND SOH.SO_HEADER_ID = P_SO_HEADER_ID);

    END LOOP;
    
    UPDATE CIMS.INTF_NC_INV_HEADER H
       SET H.INTF_STATUS      = PKG_SO_PUB.V_NO,
           H.ACCOUNT_PERIOD   = R_SO_HEADER.SETTLE_DATE,
           H.BILL_DATE        = R_SO_HEADER.SETTLE_DATE,
           H.LAST_UPDATE_DATE = SYSDATE,
           H.LAST_UPDATED_BY  = R_SO_HEADER.LAST_UPDATED_BY
     WHERE H.INTF_STATUS = V_PO_NC_INV_INTF_STATUS_WAIT
       AND EXISTS (SELECT 1
              FROM T_INV_PO_HEADERS POH, T_SO_HEADER SOH
             WHERE H.ORDER_NUM = POH.PO_NUM
               AND POH.SOURCE_TYPE = '销售转采购'
               AND POH.SOURCE_ORDER_NUM = SOH.SO_NUM
               AND SOH.TO_SUPP_FLAG = PKG_SO_PUB.V_YES
               AND SOH.SO_HEADER_ID = P_SO_HEADER_ID);

  EXCEPTION
    WHEN OTHERS THEN
      P_RESULT  := -27001;
      P_ERR_MSG := '转采购：销售单据头[' || P_SO_HEADER_ID || ']结算时更新PO单出错，原因：' ||
                   P_ERR_MSG || SQLERRM;
      PKG_SO_INTF.P_TABLE_ACTION_LOG('P_SO_TO_POX.P_SO_UPDATE_PO', --操作表名称
                         '转采购，PO单出错', --操作说明
                         R_SO_HEADER.SO_NUM, --关键主键
                         1, --是否出错，1出错，0未出错
                         P_ERR_MSG --错误信息
                         );
  END;
  
  ---------------------------------------------------------
  --修改直发标志、自提需二次发运款项处理
  ---------------------------------------------------------
  PROCEDURE P_SO_MODIFY_FLAG_UPD_AMOUNT(IN_SO_HEADER_ID IN T_SO_HEADER.SO_HEADER_ID%TYPE, --销售单头id
                                        IN_SIGN         IN NUMBER, --方向：1 增加锁款 2 减少锁款
                                        IN_USER_CODE    IN VARCHAR2, --操作用户
                                        OUT_RESULT      IN OUT VARCHAR2)
  IS
    R_SO_HEAD T_SO_HEADER%ROWTYPE;
    V_SRC_TYPE T_SO_HEADER.RAW_SRC_TYPE%TYPE;
    R_LG_ORDER T_PLN_LG_ORDER_HEAD%ROWTYPE;
    V_COUNT NUMBER;
    v_Price_Apply_Use_Discount t_bd_param_list.default_value%type;
    V_ACTION_TYPE NUMBER;
    V_ENTITY_NAME V_BD_ENTITY.entity_name%TYPE;
    v_OS_ATTRIB01 varchar2(1000);
    v_OS_ATTRIB02 varchar2(1000);
    V_IN_PARAM VARCHAR2(1000);
    V_ERR_NUM NUMBER;
  BEGIN
    OUT_RESULT := V_SUCCESS;
    SAVEPOINT SP_SO_MODIFY_FLAG_UPD_AMOUNT;
    --获取销售单
    IF OUT_RESULT = V_SUCCESS THEN
      V_IN_PARAM := '销售单ID=' || TO_CHAR(IN_SO_HEADER_ID);
      BEGIN
        SELECT H.*
          INTO R_SO_HEAD
          FROM T_SO_HEADER H
         WHERE H.SO_HEADER_ID = IN_SO_HEADER_ID;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          OUT_RESULT := '找不到销售单数据！';
          Raise v_Base_Exception;
      END;
    END IF;
    
    --检查是否来源提货订单
    IF OUT_RESULT = V_SUCCESS THEN
      IF R_SO_HEAD.ORIGIN_ORIGIN_TYPE = '02' OR R_SO_HEAD.RAW_SRC_TYPE = '02' THEN
        V_SRC_TYPE := '02';
        IF R_SO_HEAD.ORIGIN_ORIGIN_TYPE = '02' THEN
          R_LG_ORDER.HQ_LG_ORDER_HEAD_ID := R_SO_HEAD.ORIGIN_ORIGIN_HEAD_ID;
        ELSE
          R_LG_ORDER.HQ_LG_ORDER_HEAD_ID := R_SO_HEAD.RAW_SRC_BILL_ID;
        END IF;
      ELSE
        RETURN;
      END IF; 
    END IF;
    
    --检查来源提货订单是不是只对应一张销司主体提货订单
    IF OUT_RESULT = V_SUCCESS THEN
      SELECT COUNT(1)
        INTO V_COUNT
        FROM T_PLN_LG_ORDER_HEAD H
       WHERE H.HQ_LG_ORDER_HEAD_ID = R_LG_ORDER.HQ_LG_ORDER_HEAD_ID
         AND H.ORDER_HEAD_STATE IN ('20', '1455');
      
      --没有对应的销司主体提货订单或对应多张（齐套汇总）则返回
      IF V_COUNT <> 1 THEN
        RETURN;
      END IF;
    END IF;
    
    --获取销售公司主体订单
    SELECT H.*
      INTO R_LG_ORDER
      FROM T_PLN_LG_ORDER_HEAD H
     WHERE H.HQ_LG_ORDER_HEAD_ID = R_LG_ORDER.HQ_LG_ORDER_HEAD_ID;
    
    SELECT E.entity_name INTO V_ENTITY_NAME
      FROM V_BD_ENTITY E
     WHERE E.entity_id = R_LG_ORDER.ENTITY_ID;
     
    Begin
      v_Price_Apply_Use_Discount := Pkg_Bd.f_Get_Parameter_Value('PLN_PRICE_APPLY_USE_DISCOUNT',
                                                          r_Lg_Order.Entity_Id);
    Exception
      When Others Then
        v_Price_Apply_Use_Discount := 'N';
    End;
    
    IF R_LG_ORDER.CUSTOMIZE_FLAG = 'Y' THEN
      --校验款项
      For r_Check_Amount In (--甲方
                             Select lol.entity_id,
                                    be.entity_name,
                                    h.customer_id,
                                    H.CUSTOMER_CODE,
                                    h.account_id,
                                    H.ACCOUNT_CODE,
                                    nvl(lol.Sales_Main_Type, bi.sales_main_type) Sales_Main_Type,
                                    Nvl(lol.DISCOUNT_TYPE, DISCOUNT_TYPE_COMMON) Discount_Type,                                    
                                    Sum(IN_SIGN * Round(Nvl(SL.ITEM_QTY, 0)
                                              *
                                              Decode(lol.Project_Order_Type,
                                                     Null,
                                                     (Nvl(lol.List_Price, 0) *
                                                     (100 - Nvl(lol.Discount_Rate, 0) - Nvl(lol.Ordered_Discount_Rate, 0))) / 100,
                                                     (Nvl(lol.Apply_List_Price, 0) *
                                                     (100 - decode(v_Price_Apply_Use_Discount, 'Y', nvl(lol.Apply_Discount_Rate, 0), 0)
                                                       - Nvl(lol.Ordered_Discount_Rate, 0))) / 100)
                                              * case
                                                  when lol.customize_flag = 'Y' then
                                                    0
                                                  when nvl(lol.customize_flag, 'N') = 'N' then
                                                    case
                                                      when h.lock_amount_flag in (V_LOCK_AMOUNT_FLAG_S, V_LOCK_AMOUNT_FLAG_RS) 
                                                        or (h.lock_amount_flag = V_LOCK_AMOUNT_FLAG_HQ and hqh.submit_to_hq_flag = 'Y') then
                                                        1 - nvl(lol.down_pay_scale, 100) / 100
                                                      when h.lock_amount_flag = V_LOCK_AMOUNT_FLAG_HQ and nvl(hqh.submit_to_hq_flag, 'N') = 'N' then
                                                        1
                                                      when h.lock_amount_flag in (V_LOCK_AMOUNT_FLAG_Y, V_LOCK_AMOUNT_FLAG_RT) then
                                                        1
                                                      else
                                                        0
                                                    end
                                                  else
                                                    0
                                                end,2)) apply_Amount,
                                    Sum(IN_SIGN * Round(Nvl(SL.ITEM_QTY, 0)
                                              *
                                              Decode(lol.Project_Order_Type,
                                                     Null,
                                                     Nvl(lOL.List_Price, 0) * Nvl(lOL.Discount_Rate, 0) / 100,
                                                     Nvl(lOL.Apply_List_Price, 0) *
                                                     decode(v_Price_Apply_Use_Discount, 'Y', nvl(lOL.Apply_Discount_Rate, 0), 0) / 100)
                                              *
                                              case
                                                when lol.customize_flag = 'Y' then
                                                  0
                                                when nvl(lol.customize_flag, 'N') = 'N' then
                                                  case
                                                    when h.lock_amount_flag in (V_LOCK_AMOUNT_FLAG_S, V_LOCK_AMOUNT_FLAG_RS) 
                                                      or (h.lock_amount_flag = V_LOCK_AMOUNT_FLAG_HQ and hqh.submit_to_hq_flag = 'Y') then
                                                      1 - nvl(lol.down_pay_scale, 100) / 100
                                                    when h.lock_amount_flag = V_LOCK_AMOUNT_FLAG_HQ and nvl(hqh.submit_to_hq_flag, 'N') = 'N' then
                                                      1
                                                    when h.lock_amount_flag in (V_LOCK_AMOUNT_FLAG_Y, V_LOCK_AMOUNT_FLAG_RT) then
                                                      1
                                                    else
                                                      0
                                                  end
                                                else
                                                  0
                                              end,2)) Discount_Amount
                               From t_Pln_Lg_Order_Line Lol,
                                    t_Bd_Item Bi,
                                    t_pln_lg_order_head h,
                                    v_bd_entity be,
                                    t_pln_lg_order_head hqh,
                                    T_SO_LINE SL
                              Where lol.order_head_id = h.order_head_id
                                and Lol.Item_Id = Bi.Item_Id
                                And Bi.Entity_Id = Lol.Entity_Id
                                And Lol.Order_Head_Id = R_LG_ORDER.Order_Head_Id
                                And Lol.Entity_Id = R_LG_ORDER.Entity_Id
                                and h.entity_id = be.entity_id
                                and h.hq_lg_order_head_id = hqh.order_head_id
                                and sl.so_header_id = IN_SO_HEADER_ID
                                AND SL.ITEM_CODE = lOL.ITEM_CODE
                              Group By lol.entity_id,
                                       be.entity_name,
                                       h.customer_id,
                                       h.customer_code,
                                       h.account_id,
                                       h.account_code,
                                       nvl(lol.Sales_Main_Type, bi.sales_main_type),
                                       Nvl(lol.DISCOUNT_TYPE, DISCOUNT_TYPE_COMMON)
                              ) Loop
        PKG_CREDIT_ACCOUNT_CONTROL.P_CREDIT_CHECK_AMOUNT(IN_ENTITY_ID       => r_Check_Amount.Entity_Id,
                                                         IN_CUSTOMER_ID     => r_Check_Amount.Customer_Id,
                                                         IN_ACCOUNT_ID      => r_Check_Amount.Account_Id,
                                                         IN_SALES_MAIN_TYPE => r_Check_Amount.Sales_Main_Type,
                                                         IN_PROJ_NUMBER     => null,
                                                         IN_AMOUNT_SUM      => r_Check_Amount.Apply_Amount,
                                                         IN_DISAMOUNT_SUM   => r_Check_Amount.Discount_Amount,
                                                         IN_DISCOUNT_TYPE   => r_Check_Amount.Discount_Type,
                                                         IN_USER_ACCOUNT    => IN_USER_CODE,
                                                         OUT_RESULT         => V_ERR_NUM,
                                                         OUT_ERR_MSG        => OUT_RESULT);
        IF V_ERR_NUM <> 0 THEN
          OUT_RESULT := '自提二次发运/修改直发标志校验客户款项失败！错误提示：'||v_Nl||OUT_RESULT||v_Nl||
                      '事业部='||r_Check_Amount.entity_name||v_Nl||
                      '客户ID='||r_Check_Amount.Customer_Id||' 编码='||r_Check_Amount.customer_code||v_Nl||
                      '账户ID='||r_Check_Amount.Account_Id||' 编码='||r_Check_Amount.account_code||v_Nl||
                      '营销大类='||r_Check_Amount.Sales_Main_Type||v_Nl||
                      '折扣类型='||r_Check_Amount.Discount_Type;
          raise v_Base_Exception;
        END IF;
      End Loop;

      --锁定款项
      For r_Check_Amount In (--甲方
                             Select lol.entity_id,
                                    be.entity_name,
                                    h.customer_id,
                                    H.CUSTOMER_CODE,
                                    h.account_id,
                                    H.ACCOUNT_CODE,
                                    nvl(lol.sales_main_type, bi.sales_main_type) Sales_Main_Type,
                                    Nvl(lol.Discount_Type, Discount_Type_Common) Discount_Type,
                                    decode(lol.customize_flag, 'Y', ah.project_code, null) project_code,
                                    decode(lol.customize_flag, 'Y', 100, lol.down_pay_scale) down_pay_scale,
                                    h.order_head_id order_id,
                                    h.order_number order_number,
                                    '02' src_type,
                                    Sum(IN_SIGN * Round(Nvl(SL.ITEM_QTY, 0)
                                              *
                                              Decode(lol.Project_Order_Type,
                                                     Null,
                                                     (Nvl(lol.List_Price, 0) *
                                                     (100 - Nvl(lol.Discount_Rate, 0) - Nvl(lol.Ordered_Discount_Rate, 0))) / 100,
                                                     (Nvl(lol.Apply_List_Price, 0) *
                                                     (100 - decode(v_Price_Apply_Use_Discount, 'Y', nvl(lol.Apply_Discount_Rate, 0), 0)
                                                       - Nvl(lol.Ordered_Discount_Rate, 0))) / 100)
                                              * case
                                                  when lol.customize_flag = 'Y' then
                                                    1
                                                  when nvl(lol.customize_flag, 'N') = 'N' then
                                                    case
                                                      when h.lock_amount_flag in (V_LOCK_AMOUNT_FLAG_S, V_LOCK_AMOUNT_FLAG_RS) 
                                                        or (h.lock_amount_flag = V_LOCK_AMOUNT_FLAG_HQ and hqh.submit_to_hq_flag = 'Y') then
                                                        1
                                                      when h.lock_amount_flag = V_LOCK_AMOUNT_FLAG_HQ and nvl(hqh.submit_to_hq_flag, 'N') = 'N' then
                                                        1
                                                      when h.lock_amount_flag in (V_LOCK_AMOUNT_FLAG_Y, V_LOCK_AMOUNT_FLAG_RT) then
                                                        1
                                                      else
                                                        0
                                                    end
                                                  else
                                                    0
                                                end,2)) apply_Amount,
                                    Sum(IN_SIGN * Round(Nvl(SL.ITEM_QTY, 0)
                                              *
                                              Decode(lol.Project_Order_Type,
                                                     Null,
                                                     Nvl(lOL.List_Price, 0) * Nvl(lOL.Discount_Rate, 0) / 100,
                                                     Nvl(lOL.Apply_List_Price, 0) *
                                                     decode(v_Price_Apply_Use_Discount, 'Y', nvl(lOL.Apply_Discount_Rate, 0), 0) / 100)
                                              *
                                              case
                                                when lol.customize_flag = 'Y' then
                                                  1
                                                when nvl(lol.customize_flag, 'N') = 'N' then
                                                  case
                                                    when h.lock_amount_flag in (V_LOCK_AMOUNT_FLAG_S, V_LOCK_AMOUNT_FLAG_RS) 
                                                      or (h.lock_amount_flag = V_LOCK_AMOUNT_FLAG_HQ and hqh.submit_to_hq_flag = 'Y') then
                                                      1
                                                    when h.lock_amount_flag = V_LOCK_AMOUNT_FLAG_HQ and nvl(hqh.submit_to_hq_flag, 'N') = 'N' then
                                                      1
                                                    when h.lock_amount_flag in (V_LOCK_AMOUNT_FLAG_Y, V_LOCK_AMOUNT_FLAG_RT) then
                                                      1
                                                    else
                                                      0
                                                  end
                                                else
                                                  0
                                              end,2)) Discount_Amount,
                                    Sum(IN_SIGN * Round(Nvl(SL.ITEM_QTY, 0)
                                              *
                                              Decode(lol.Project_Order_Type,
                                                     Null,
                                                     (Nvl(lol.List_Price, 0) *
                                                     (100 - Nvl(lol.Discount_Rate, 0) - Nvl(lol.Ordered_Discount_Rate, 0))) / 100,
                                                     (Nvl(lol.Apply_List_Price, 0) *
                                                     (100 - decode(v_Price_Apply_Use_Discount, 'Y', nvl(lol.Apply_Discount_Rate, 0), 0)
                                                       - Nvl(lol.Ordered_Discount_Rate, 0))) / 100)
                                              * case
                                                  when lol.customize_flag = 'Y' then
                                                    -1
                                                  when nvl(lol.customize_flag, 'N') = 'N' then
                                                    case
                                                      when h.lock_amount_flag in (V_LOCK_AMOUNT_FLAG_S, V_LOCK_AMOUNT_FLAG_RS) 
                                                        or (h.lock_amount_flag = V_LOCK_AMOUNT_FLAG_HQ and hqh.submit_to_hq_flag = 'Y') then
                                                        -1 * nvl(lol.down_pay_scale, 100) / 100
                                                      when h.lock_amount_flag = V_LOCK_AMOUNT_FLAG_HQ and nvl(hqh.submit_to_hq_flag, 'N') = 'N' then
                                                        0
                                                      when h.lock_amount_flag in (V_LOCK_AMOUNT_FLAG_Y, V_LOCK_AMOUNT_FLAG_RT) then
                                                        0
                                                      else
                                                        0
                                                    end
                                                  else
                                                    0
                                                end,2)) dp_apply_Amount,
                                    Sum(IN_SIGN * Round(Nvl(SL.ITEM_QTY, 0)
                                              *
                                              Decode(lol.Project_Order_Type,
                                                     Null,
                                                     Nvl(lOL.List_Price, 0) * Nvl(lOL.Discount_Rate, 0) / 100,
                                                     Nvl(lOL.Apply_List_Price, 0) *
                                                     decode(v_Price_Apply_Use_Discount, 'Y', nvl(lOL.Apply_Discount_Rate, 0), 0) / 100)
                                              *
                                              case
                                                when lol.customize_flag = 'Y' then
                                                  -1
                                                when nvl(lol.customize_flag, 'N') = 'N' then
                                                  case
                                                    when h.lock_amount_flag in (V_LOCK_AMOUNT_FLAG_S, V_LOCK_AMOUNT_FLAG_RS) 
                                                      or (h.lock_amount_flag = V_LOCK_AMOUNT_FLAG_HQ and hqh.submit_to_hq_flag = 'Y') then
                                                      -1 * nvl(lol.down_pay_scale, 100) / 100
                                                    when h.lock_amount_flag = V_LOCK_AMOUNT_FLAG_HQ and nvl(hqh.submit_to_hq_flag, 'N') = 'N' then
                                                      0
                                                    when h.lock_amount_flag in (V_LOCK_AMOUNT_FLAG_Y, V_LOCK_AMOUNT_FLAG_RT) then
                                                      0
                                                    else
                                                      0
                                                  end
                                                else
                                                  0
                                              end,2)) dp_Discount_Amount
                               From t_Pln_Lg_Order_Line Lol,
                                    t_Bd_Item Bi,
                                    t_pln_lg_order_head h,
                                    v_bd_entity be,
                                    t_pg_price_apply_head ah,
                                    t_pln_lg_order_head hqh,
                                    T_SO_LINE SL
                              Where lol.order_head_id = h.order_head_id
                                and Lol.Item_Id = Bi.Item_Id
                                And Bi.Entity_Id = Lol.Entity_Id
                                And Lol.Order_Head_Id = R_LG_ORDER.Order_Head_Id
                                And Lol.Entity_Id = R_LG_ORDER.Entity_Id
                                and h.entity_id = be.entity_id
                                and lol.entity_id = ah.entity_id(+)
                                and lol.project_order_number = ah.apply_code(+)
                                and h.hq_lg_order_head_id = hqh.order_head_id
                                and sl.so_header_id = IN_SO_HEADER_ID
                                and sl.item_code = lol.item_code
                              Group By lol.entity_id,
                                       be.entity_name,
                                       h.customer_id,
                                       h.customer_code,
                                       h.account_id,
                                       h.account_code,
                                       nvl(lol.sales_main_type, bi.sales_main_type),
                                       Nvl(lol.Discount_Type, Discount_Type_Common),
                                       decode(lol.customize_flag, 'Y', ah.project_code, null),
                                       decode(lol.customize_flag, 'Y', 100, lol.down_pay_scale),
                                       h.order_head_id,
                                       h.order_number
                              ) Loop
        PKG_CREDIT_ACCOUNT_CONTROL.P_CREDIT_LOCK_DETAIL_HAND(IN_ENTITY_ID   => r_Check_Amount.Entity_Id,
                                                         IN_CUSTOMER_ID     => r_Check_Amount.Customer_Id,
                                                         IN_ACCOUNT_ID      => r_Check_Amount.Account_Id,
                                                         IN_SALES_MAIN_TYPE => r_Check_Amount.Sales_Main_Type,
                                                         IN_PROJ_NUMBER     => r_Check_Amount.project_code,
                                                         IN_AMOUNT_SUM      => r_Check_Amount.Apply_Amount,
                                                         IN_DISAMOUNT_SUM   => r_Check_Amount.Discount_Amount,
                                                         IN_DP_AMOUNT_SUM   => r_Check_Amount.dp_apply_Amount,
                                                         IN_DP_DISAMOUNT_SUM => r_Check_Amount.dp_Discount_Amount,
                                                         IN_DISCOUNT_TYPE   => r_Check_Amount.Discount_Type,
                                                         IN_ORDER_ID        => r_Check_Amount.order_id,
                                                         IN_ORDER_NUMBER    => r_Check_Amount.order_number,
                                                         IN_DOWNPAY_RATE    => r_Check_Amount.down_pay_scale,
                                                         IN_SRC_TYPE        => r_Check_Amount.src_type,
                                                         IN_USER_ACCOUNT    => IN_USER_CODE,
                                                         OUT_RESULT         => V_ERR_NUM,
                                                         OUT_ERR_MSG        => OUT_RESULT);
        IF V_ERR_NUM <> 0 THEN
          OUT_RESULT := '自提二次发运/修改直发标志处理客户款项失败！错误提示：'||v_Nl||OUT_RESULT||v_Nl||
                      '事业部='||r_Check_Amount.entity_name||v_Nl||
                      '客户ID='||r_Check_Amount.Customer_Id||' 编码='||r_Check_Amount.customer_code||v_Nl||
                      '账户ID='||r_Check_Amount.Account_Id||' 编码='||r_Check_Amount.account_code||v_Nl||
                      '营销大类='||r_Check_Amount.Sales_Main_Type||v_Nl||
                      '折扣类型='||r_Check_Amount.Discount_Type;
          raise v_Base_Exception;
        END IF;
      End Loop;
    ELSE 
    --按照当前销售单行产品增加或减少锁款
    IF R_LG_ORDER.LOCK_AMOUNT_FLAG = 'Y' OR (R_LG_ORDER.LOCK_AMOUNT_FLAG = 'S'
      AND PKG_BD.F_GET_PARAMETER_VALUE('PLN_HQ_AFFIRM_LOCK_FULL_AMOUNT', R_LG_ORDER.ENTITY_ID) = 'Y')
      OR R_LG_ORDER.LOCK_AMOUNT_FLAG = V_LOCK_AMOUNT_FLAG_HQ THEN
      FOR R_SO_LINE IN (
        SELECT NVL(OL.SALES_MAIN_TYPE, BI.SALES_MAIN_TYPE) SALES_MAIN_TYPE,
               NVL(OL.DISCOUNT_TYPE, DISCOUNT_TYPE_COMMON) DISCOUNT_TYPE,
               Sum(Round(Decode(OL.Project_Order_Type,
                         Null,
                         (Nvl(SL.ITEM_QTY, 0) * Nvl(OL.List_Price, 0) *
                         (100 - Nvl(OL.Discount_Rate, 0) - Nvl(OL.Ordered_Discount_Rate, 0))) / 100,
                         (Nvl(SL.ITEM_QTY, 0) * Nvl(OL.Apply_List_Price, 0) *
                         (100 - decode(v_Price_Apply_Use_Discount, 'Y', nvl(OL.Apply_Discount_Rate, 0), 0)
                           - Nvl(OL.Ordered_Discount_Rate, 0))) / 100),2)) sum_Amount,
               Sum(Round(Decode(ol.Project_Order_Type,
                         Null,
                         (Nvl(SL.ITEM_QTY, 0) * Nvl(OL.List_Price, 0) * Nvl(OL.Discount_Rate, 0)) / 100,
                         Nvl(SL.ITEM_QTY, 0) * Nvl(OL.Apply_List_Price, 0) *
                         decode(v_Price_Apply_Use_Discount, 'Y', nvl(OL.Apply_Discount_Rate, 0), 0) / 100),2)) sum_Discount_Amount
          FROM T_SO_LINE SL, T_PLN_LG_ORDER_LINE OL, T_BD_ITEM BI
         WHERE SL.SO_HEADER_ID = IN_SO_HEADER_ID
           AND OL.ORDER_HEAD_ID = R_LG_ORDER.ORDER_HEAD_ID
           AND SL.ITEM_CODE = OL.ITEM_CODE
           AND NVL(OL.SHARE_VENDOR_TYPE, '_') <> 'AGENT'
           AND OL.ITEM_ID = BI.ITEM_ID
         GROUP BY NVL(OL.SALES_MAIN_TYPE, BI.SALES_MAIN_TYPE),
                  NVL(OL.DISCOUNT_TYPE, DISCOUNT_TYPE_COMMON)
        )
      LOOP
        IF IN_SIGN = 1 THEN
          V_ACTION_TYPE := 1;
          PKG_PLN_PUB.P_CUSTOMER_AMOUNT_PROCESS(IN_ENTITY_ID       => r_Lg_Order.Entity_Id,
                                                IN_ORDER_TYPE_ID   => r_Lg_Order.Order_Type_Id,
                                                IN_ORDER_TYPE_CODE => r_Lg_Order.Order_Type_Code,
                                                IN_CUSTOMER_ID     => r_Lg_Order.Customer_Id,
                                                IN_ACCOUNT_ID      => r_Lg_Order.Account_Id,
                                                IN_SALES_MAIN_TYPE => R_SO_LINE.Sales_Main_Type,
                                                IN_ACTION_TYPE     => V_ACTION_TYPE,
                                                IN_SOURCE_TYPE     => '02',
                                                IN_ORDER_ID        => r_Lg_Order.Order_Head_Id,
                                                IN_PROJ_NUMBER     => NULL,
                                                IN_DISCOUNT_TYPE   => R_SO_LINE.Discount_Type,
                                                IN_AMOUNT          => Nvl(R_SO_LINE.Sum_Amount, 0),
                                                IN_DIS_AMOUNT      => Nvl(R_SO_LINE.Sum_Discount_Amount, 0),
                                                IN_RECORD_ERR      => 'N',
                                                IN_USER_CODE       => IN_USER_CODE,
                                                OUT_RESULT         => OUT_RESULT);
          IF OUT_RESULT <> V_SUCCESS THEN
            OUT_RESULT := '修改直发标志（标记直发）处理客户款项失败！' || V_NL || OUT_RESULT;
            RAISE V_BASE_EXCEPTION;
          END IF;
          
          IF R_LG_ORDER.LOCK_AMOUNT_FLAG = V_LOCK_AMOUNT_FLAG_HQ OR
            (R_LG_ORDER.LOCK_AMOUNT_FLAG = V_LOCK_AMOUNT_FLAG_S AND PKG_BD.F_GET_PARAMETER_VALUE('PLN_HQ_AFFIRM_LOCK_FULL_AMOUNT', R_LG_ORDER.ENTITY_ID) = 'Y') THEN
            V_ACTION_TYPE := 28;
            PKG_PLN_PUB.P_CUSTOMER_AMOUNT_PROCESS(IN_ENTITY_ID       => r_Lg_Order.Entity_Id,
                                                  IN_ORDER_TYPE_ID   => r_Lg_Order.Order_Type_Id,
                                                  IN_ORDER_TYPE_CODE => r_Lg_Order.Order_Type_Code,
                                                  IN_CUSTOMER_ID     => r_Lg_Order.Customer_Id,
                                                  IN_ACCOUNT_ID      => r_Lg_Order.Account_Id,
                                                  IN_SALES_MAIN_TYPE => R_SO_LINE.Sales_Main_Type,
                                                  IN_ACTION_TYPE     => V_ACTION_TYPE,
                                                  IN_SOURCE_TYPE     => '02',
                                                  IN_ORDER_ID        => r_Lg_Order.Order_Head_Id,
                                                  IN_PROJ_NUMBER     => NULL,
                                                  IN_DISCOUNT_TYPE   => R_SO_LINE.Discount_Type,
                                                  IN_AMOUNT          => Nvl(R_SO_LINE.Sum_Amount, 0),
                                                  IN_DIS_AMOUNT      => Nvl(R_SO_LINE.Sum_Discount_Amount, 0),
                                                  IN_RECORD_ERR      => 'N',
                                                  IN_USER_CODE       => IN_USER_CODE,
                                                  OUT_RESULT         => OUT_RESULT);
            IF OUT_RESULT <> V_SUCCESS THEN
              OUT_RESULT := '修改直发标志（标记直发）处理客户款项失败！' || V_NL || OUT_RESULT;
              RAISE V_BASE_EXCEPTION;
            END IF;
          END IF;
        ELSIF IN_SIGN = -1 THEN
          IF R_LG_ORDER.LOCK_AMOUNT_FLAG = V_LOCK_AMOUNT_FLAG_HQ OR
            (R_LG_ORDER.LOCK_AMOUNT_FLAG = V_LOCK_AMOUNT_FLAG_S AND PKG_BD.F_GET_PARAMETER_VALUE('PLN_HQ_AFFIRM_LOCK_FULL_AMOUNT', R_LG_ORDER.ENTITY_ID) = 'Y') THEN
            V_ACTION_TYPE := 29;
            PKG_PLN_PUB.P_CUSTOMER_AMOUNT_PROCESS(IN_ENTITY_ID       => r_Lg_Order.Entity_Id,
                                                  IN_ORDER_TYPE_ID   => r_Lg_Order.Order_Type_Id,
                                                  IN_ORDER_TYPE_CODE => r_Lg_Order.Order_Type_Code,
                                                  IN_CUSTOMER_ID     => r_Lg_Order.Customer_Id,
                                                  IN_ACCOUNT_ID      => r_Lg_Order.Account_Id,
                                                  IN_SALES_MAIN_TYPE => R_SO_LINE.Sales_Main_Type,
                                                  IN_ACTION_TYPE     => V_ACTION_TYPE,
                                                  IN_SOURCE_TYPE     => '02',
                                                  IN_ORDER_ID        => r_Lg_Order.Order_Head_Id,
                                                  IN_PROJ_NUMBER     => NULL,
                                                  IN_DISCOUNT_TYPE   => R_SO_LINE.Discount_Type,
                                                  IN_AMOUNT          => Nvl(R_SO_LINE.Sum_Amount, 0),
                                                  IN_DIS_AMOUNT      => Nvl(R_SO_LINE.Sum_Discount_Amount, 0),
                                                  IN_RECORD_ERR      => 'N',
                                                  IN_USER_CODE       => IN_USER_CODE,
                                                  OUT_RESULT         => OUT_RESULT);
            IF OUT_RESULT <> V_SUCCESS THEN
              OUT_RESULT := '自提二次发运、修改直发标志（取消直发）处理客户款项失败！' || V_NL || OUT_RESULT;
              RAISE V_BASE_EXCEPTION;
            END IF;
          END IF;

          V_ACTION_TYPE := 2;
          PKG_PLN_PUB.P_CUSTOMER_AMOUNT_PROCESS(IN_ENTITY_ID       => r_Lg_Order.Entity_Id,
                                                IN_ORDER_TYPE_ID   => r_Lg_Order.Order_Type_Id,
                                                IN_ORDER_TYPE_CODE => r_Lg_Order.Order_Type_Code,
                                                IN_CUSTOMER_ID     => r_Lg_Order.Customer_Id,
                                                IN_ACCOUNT_ID      => r_Lg_Order.Account_Id,
                                                IN_SALES_MAIN_TYPE => R_SO_LINE.Sales_Main_Type,
                                                IN_ACTION_TYPE     => V_ACTION_TYPE,
                                                IN_SOURCE_TYPE     => '02',
                                                IN_ORDER_ID        => r_Lg_Order.Order_Head_Id,
                                                IN_PROJ_NUMBER     => NULL,
                                                IN_DISCOUNT_TYPE   => R_SO_LINE.Discount_Type,
                                                IN_AMOUNT          => Nvl(R_SO_LINE.Sum_Amount, 0),
                                                IN_DIS_AMOUNT      => Nvl(R_SO_LINE.Sum_Discount_Amount, 0),
                                                IN_RECORD_ERR      => 'N',
                                                IN_USER_CODE       => IN_USER_CODE,
                                                OUT_RESULT         => OUT_RESULT);
          IF OUT_RESULT <> V_SUCCESS THEN
            OUT_RESULT := '自提二次发运、修改直发标志（取消直发）处理客户款项失败！' || V_NL || OUT_RESULT;
            RAISE V_BASE_EXCEPTION;
          END IF;
        END IF;
        
      END LOOP;
    END IF;
    END IF;
    
    --更新提货订单行数量
    IF OUT_RESULT = V_SUCCESS THEN
      UPDATE T_PLN_LG_ORDER_LINE L
         SET L.TRANSFER_HQ_AFFIRMED_QTY = NVL(L.TRANSFER_HQ_AFFIRMED_QTY, 0) +
                                          IN_SIGN * (SELECT TSL.ITEM_QTY FROM T_SO_LINE TSL
                                                      WHERE TSL.SO_HEADER_ID = IN_SO_HEADER_ID
                                                        AND TSL.ITEM_CODE = L.ITEM_CODE),
             L.LAST_UPDATE_DATE = SYSDATE
       WHERE L.ORDER_HEAD_ID = r_Lg_Order.Order_Head_Id
         AND NVL(L.SHARE_VENDOR_TYPE, '_') <> 'AGENT'
         AND EXISTS (SELECT 1 FROM T_SO_LINE SL
                      WHERE SL.SO_HEADER_ID = IN_SO_HEADER_ID
                        AND SL.ITEM_CODE = L.ITEM_CODE);
    END IF;
  EXCEPTION
    WHEN V_BASE_EXCEPTION THEN
      ROLLBACK TO SAVEPOINT SP_SO_MODIFY_FLAG_UPD_AMOUNT;
      OUT_RESULT := '修改直发标志/自提转二次发运出错，错误提示：' || OUT_RESULT || V_NL || V_IN_PARAM;
    WHEN OTHERS THEN
      ROLLBACK TO SAVEPOINT SP_SO_MODIFY_FLAG_UPD_AMOUNT;
      OUT_RESULT := '修改直发标志/自提转二次发运出错，错误提示：' || SQLERRM || V_NL || V_IN_PARAM;
  END P_SO_MODIFY_FLAG_UPD_AMOUNT;

  ---------------------------------------------------------
  --生成预占用数据，用于提货订单二次发运
  --销售生成中转单类型触发。只考虑正向
  --LILH6 2018-8-6
  ---------------------------------------------------------
  Procedure p_Pre_Inv_Occupy_Useinvpo(In_Entity_Id In Number, --主体ID
                                      In_Po_Id     In Number, --转采购参数表ID
                                      In_User_Code In Varchar2, --操作用户
                                      Out_Result   In Out Varchar2) Is
    r_Po_Head           t_Inv_Po_Headers%Rowtype;
    r_So_Head           t_So_Header%Rowtype; --总部销售单
    v_In_Param          Varchar2(4000);
    v_Remain_Rev_Qty    Number;
    v_Curr_Order_Qty    Number;
    v_Curr_Lock_Qty     Number;
    v_Second_Send_Order Varchar2(4000) := '可做二次发运订单：';
  Begin
    Out_Result := v_Success;
    Savepoint Sp_Pre_Inv_Occupy_Useinvpo;
  
    --锁定销售生成中转单数据
    v_In_Param := '销售生成中转单ID=' || To_Char(In_Po_Id);
    Begin
      Select *
        Into r_Po_Head
        From t_Inv_Po_Headers h
       Where h.Po_Id = In_Po_Id;
    Exception
      When No_Data_Found Then
        Out_Result := '传入参数有误，找不到对应的销售生成中转单！';
    End;
  
    --Sched_Order_Num为空的，无需处理，直接返回成功
    If Out_Result = v_Success And r_Po_Head.Sched_Order_Num Is Null Then
      Return;
    End If;
  
    --获取来源销售单
    If Out_Result = v_Success Then
      v_In_Param := '销售单号=' || Substr(r_Po_Head.Sched_Order_Num, 2);
      Begin
        Select h.*
          Into r_So_Head
          From t_So_Header h
         Where h.So_Num = Substr(r_Po_Head.Sched_Order_Num, 2);
      Exception
        When No_Data_Found Then
          Out_Result := '找不到销售生成中转单对应的的销售单！';
      End;
    End If;
  
    If Out_Result = v_Success Then
    
      --循环入库的产品
      For r_So_Line In (Select *
                          From t_So_Line l
                         Where l.So_Header_Id = r_So_Head.So_Header_Id
                         Order By l.Item_Code) Loop
        If Out_Result = v_Success Then
        
          v_Remain_Rev_Qty := r_So_Line.Item_Qty;
        
          --按来源客户提货订单循环处理
          For r_Lg_Order_Line In (Select h.Order_Number, l.*
                                    From t_Pln_Lg_Order_Head h,
                                         t_Pln_Lg_Order_Line l
                                   Where h.Hq_Lg_Order_Head_Id =
                                         Nvl(r_So_Head.Origin_Origin_Head_Id,
                                             r_So_Head.Raw_Src_Bill_Id)
                                     And h.Order_Head_Id = l.Order_Head_Id
                                     And l.Item_Code = r_So_Line.Item_Code
                                     AND NVL(L.SHARE_VENDOR_TYPE, '_') <> 'AGENT'
                                     And Nvl(l.Center_Affirm_Quantity,
                                             l.Quantity) -
                                         Nvl(l.Center_Affirmed_Qty, 0) -
                                         Nvl(l.Hq_Affirmed_Qty, 0) -
                                         Nvl(l.Cancel_Qty, 0) -
                                         Nvl(l.Lock_Inv_Pre, 0) > 0
                                     And Nvl(l.Order_Line_State, 'NORMAL') <>
                                         'CLOSED' --行未关闭
                                     And h.Order_Head_State <> '304' --单未关闭
                                   Order By h.To_Checkup_Date) --按送审时间从前往后排序
           Loop
            --当前订单可占用量=申请量-中心库评量-总部库评量-已预占用量
            v_Curr_Order_Qty := Nvl(r_Lg_Order_Line.Center_Affirm_Quantity,
                                    r_Lg_Order_Line.Quantity) -
                                Nvl(r_Lg_Order_Line.Center_Affirmed_Qty, 0) -
                                Nvl(r_Lg_Order_Line.Hq_Affirmed_Qty, 0) -
                                Nvl(r_Lg_Order_Line.Cancel_Qty, 0) -
                                Nvl(r_Lg_Order_Line.Lock_Inv_Pre, 0);
          
            If v_Curr_Order_Qty <= v_Remain_Rev_Qty Then
              v_Curr_Lock_Qty := v_Curr_Order_Qty;
            Else
              v_Curr_Lock_Qty := v_Remain_Rev_Qty;
            End If;
            v_Remain_Rev_Qty := v_Remain_Rev_Qty - v_Curr_Lock_Qty;
          
            If v_Curr_Lock_Qty > 0 Then
              If Instr(v_Second_Send_Order, r_Lg_Order_Line.Order_Number) <= 0 Then
                If v_Second_Send_Order = '可做二次发运订单：' Then
                  v_Second_Send_Order := v_Second_Send_Order ||
                                         r_Lg_Order_Line.Order_Number;
                Else
                  v_Second_Send_Order := v_Second_Send_Order || ',' ||
                                         r_Lg_Order_Line.Order_Number;
                End If;
              End If;
            
              Update t_Pln_Lg_Order_Line l
                 Set l.Affirm_Quantity = v_Curr_Lock_Qty,
                     l.Inv_Id          = r_Po_Head.Inv_Finance_Id,
                     l.Inv_Code        = r_Po_Head.Inv_Finance_Code,
                     l.Inv_Name        = r_Po_Head.Inv_Finance_Name
               Where l.Order_Line_Id = r_Lg_Order_Line.Order_Line_Id;
            
              --做预占用
              Pkg_So_To_Pox.p_Lg_Order_Pre_Inv_Occupy(In_Entity_Id     => r_Po_Head.Entity_Id,
                                                      In_Order_Head_Id => r_Lg_Order_Line.Order_Head_Id,
                                                      In_Order_Line_Id => r_Lg_Order_Line.Order_Line_Id,
                                                      In_Occupy_Sign   => 1,
                                                      In_User_Code     => In_User_Code,
                                                      Out_Result       => Out_Result);
            End If;
          
            If Out_Result <> v_Success Or v_Remain_Rev_Qty <= 0 Then
              Exit;
            End If;
          End Loop; --按来源客户提货订单循环处理end
        End If;
        If Out_Result <> v_Success Then
          Exit;
        End If;
      End Loop; --循环入库的产品end
    
    End If;
  
    If Out_Result <> v_Success Then
      Raise v_Base_Exception;
    Else
      If v_Second_Send_Order <> '可做二次发运订单：' Then
        Update t_Inv_Po_Headers h
           Set h.Remark = h.Remark || '；' || v_Second_Send_Order
         Where h.Po_Id = In_Po_Id;
      End If;
    End If;
  Exception
    When v_Base_Exception Then
      Rollback To Savepoint Sp_Pre_Inv_Occupy_Useinvpo;
      Out_Result := '中转单执行，二次发运库存占用出错，错误提示：' || Out_Result || v_Nl ||
                    v_In_Param;
    When Others Then
      Rollback To Savepoint Sp_Pre_Inv_Occupy_Useinvpo;
      Out_Result := '中转单执行，二次发运库存占用出错，错误提示：' || Sqlerrm || v_Nl ||
                    v_In_Param;
  End p_Pre_Inv_Occupy_Useinvpo;
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2018-02-28
  *     创建者：周建刚
  *   功能说明：根据供方主体销售单的签收信息，更新需方主体销售的签收信息
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_RECEIVE_BY_PO_ENTITY_SO(P_ENTITY_ID            IN NUMBER,    --主体ID
                                         P_START_DATE           IN VARCHAR2,  --起始日期
                                         P_RESULT               OUT NUMBER,   --返回错误ID
                                         P_ERR_MSG              OUT VARCHAR2  --返回错误信息
                                         ) IS
    PRAGMA AUTONOMOUS_TRANSACTION; --自治事务
    R_SO_HEADER   T_SO_HEADER%ROWTYPE;
    R_SO_LINE     T_SO_LINE%ROWTYPE;
    R_LG_CONTRACT      T_LG_CONTRACT%ROWTYPE;
    R_LG_CONTRACT_LINE T_LG_CONTRACT_LINE%ROWTYPE;
    V_RECEIVED_DATE    DATE;
  BEGIN
    P_RESULT  := PKG_SO_PUB.V_RESULT;
    P_ERR_MSG := PKG_SO_PUB.V_SUCCESS;
    --补全销售单行签收信息：存在采购关系（总部、销司）的销售单据由于总部运输合同有差异不会触发第二步签收动作，导致总部销售单的行签收信息为空
    FOR REC IN (SELECT SH.*
                  FROM CIMS.T_SO_HEADER SH
                 WHERE EXISTS (SELECT 1
                          FROM CIMS.T_SO_LINE SL
                         WHERE SL.RECEIVED_DATE IS NULL
                           AND SL.SO_HEADER_ID = SH.SO_HEADER_ID)
                   AND EXISTS
                 (SELECT 1
                          FROM CIMS.T_LG_CONTRACT_LINE CL
                         WHERE CL.SO_DOC_NUM = SH.SO_NUM
                           AND EXISTS
                         (SELECT 1
                                  FROM CIMS.T_LG_CONTRACT C,CIMS.T_BD_CENTER_RELATION R
                                 WHERE 1 = 1
                                   AND C.CREATION_DATE > SYSDATE - 120
                                   AND C.BILLS_STATUS = '02'
                                   AND C.CONTRACT_ID = CL.CONTRACT_ID
                                   AND R.HQ_ENTITY_ID <> R.SC_ENTITY_ID
                                   AND R.HQ_ENTITY_ID = C.ENTITY_ID
                                   AND R.HQ_SALES_CENTER_CODE = C.SALES_CENTER_CODE
                                   AND R.HQ_CUSTOMER_CODE = C.CUSTOMER_CODE
                                   AND R.HQ_ENTITY_ID = P_ENTITY_ID))
                    AND SH.LAST_UPDATE_DATE > TO_DATE(P_START_DATE, 'yyyy-MM-dd')
                    AND SH.CONTRACT_CODE IS NOT NULL
                    AND SH.RECEIVE_FLAG = 'Y' 
                    AND SH.ENTITY_ID = P_ENTITY_ID
                ) LOOP
      V_RECEIVED_DATE := SYSDATE;
      BEGIN
        --运输合同签收信息更新到销售单行明细签收信息
        FOR C_LINE_REC IN (SELECT CL.*
                         FROM CIMS.T_LG_CONTRACT CH, CIMS.T_LG_CONTRACT_LINE CL
                        WHERE CH.CONTRACT_ID = CL.CONTRACT_ID
                          AND CH.ENTITY_ID = REC.ENTITY_ID
                          AND CL.SO_DOC_NUM = REC.SO_NUM
                          AND CH.CONTRACT_CODE = REC.CONTRACT_CODE
                        ) LOOP
          UPDATE CIMS.T_SO_LINE_DETAIL D
             SET D.RECEIVED_DATE    = V_RECEIVED_DATE,
                 D.RECEIVED_QTY     = NVL(C_LINE_REC.FACT_RECEIVE_QTY, 0),
                 D.LAST_UPDATE_DATE = SYSDATE
           WHERE D.COMPONENT_CODE = C_LINE_REC.ITEM_CODE
             AND D.ITEM_CODE = C_LINE_REC.SET_CODE
             AND EXISTS (SELECT 1
                    FROM CIMS.T_SO_HEADER H
                   WHERE H.SO_HEADER_ID = D.SO_HEADER_ID
                     AND H.SO_NUM = REC.SO_NUM);
        END LOOP;
        --更新销售单行明细的签收信息更新行的签收信息
        FOR S_LINE_REC IN (SELECT SL.*
                             FROM CIMS.T_SO_LINE SL
                            WHERE SL.SO_HEADER_ID = REC.SO_HEADER_ID
                            ) LOOP
          --套件
          IF (S_LINE_REC.ITEM_UOM = 'Set') THEN
            --取配套后的最小值
            UPDATE CIMS.T_SO_LINE SL
               SET SL.RECEIVED_DATE    = V_RECEIVED_DATE,
                   SL.RECEIVED_QTY    =
                   (SELECT MIN(NVL(D.RECEIVED_QTY, 0) / S.QUANTITY)
                      FROM CIMS.V_BD_ITEM_ASSEMBLIES_SUB S, CIMS.T_SO_LINE_DETAIL D
                     WHERE S.ACTIVE_FLAG = 'Y'
                       AND S.ASSEMBLE_ACTIVE_FLAG = 'Y'
                       AND S.ENTITY_ID = S_LINE_REC.ENTITY_ID
                       AND S.ITEM_CODE = S_LINE_REC.ITEM_CODE
                       AND D.SO_LINE_ID = S_LINE_REC.SO_LINE_ID
                       AND D.SO_HEADER_ID = REC.SO_HEADER_ID),
                   SL.LAST_UPDATE_DATE = SYSDATE
             WHERE SL.SO_LINE_ID = S_LINE_REC.SO_LINE_ID
               AND SL.SO_HEADER_ID = REC.SO_HEADER_ID;
          ELSE
            UPDATE CIMS.T_SO_LINE SL
               SET SL.RECEIVED_DATE    = V_RECEIVED_DATE,
                   SL.RECEIVED_QTY    =
                   (SELECT D.RECEIVED_QTY
                      FROM CIMS.T_SO_LINE_DETAIL D
                     WHERE D.ITEM_CODE = SL.ITEM_CODE
                       AND D.SO_HEADER_ID = REC.SO_HEADER_ID
                       AND ROWNUM = 1),
                   SL.LAST_UPDATE_DATE = SYSDATE
             WHERE SL.SO_HEADER_ID = REC.SO_HEADER_ID
               AND SL.SO_LINE_ID = S_LINE_REC.SO_LINE_ID;
          END IF;
        END LOOP;
      EXCEPTION
        WHEN OTHERS THEN
          PKG_SO_RT.P_TABLE_ACTION_LOG('PKG_SO_TO_POX.P_SO_RECEIVE_BY_PO_ENTITY_SO', --操作表名称
                             '根据合同定时更新销售单签收信息出错', --操作说明
                             REC.SO_NUM, --关键主键
                             1, --是否出错，1出错，0未出错
                             substr(dbms_utility.format_error_backtrace,
                                                   1,
                                                   100) || SQLERRM --错误信息
                             );
      END;
    END LOOP;
    COMMIT;
    FOR REC IN (SELECT H.*
                  FROM T_SO_HEADER H
                 WHERE H.ENTITY_ID = P_ENTITY_ID
                   AND H.SRC_TYPE = '31'
                   AND H.RECEIVE_FLAG = 'N'
                   AND EXISTS
                 (SELECT 1
                          FROM CIMS.T_SO_HEADER HQ, CIMS.T_SO_LINE LQ
                         WHERE HQ.SO_HEADER_ID = LQ.SO_HEADER_ID
                           AND HQ.SO_NUM = H.SRC_BILL_NUM
                           AND LQ.RECEIVED_DATE IS NOT NULL
                           AND HQ.RECEIVE_FLAG = 'Y')
                   AND H.LAST_UPDATE_DATE > TO_DATE(P_START_DATE, 'yyyy-MM-dd')
                   AND ROWNUM <= 500
                ) LOOP
      BEGIN
        SAVEPOINT SP;
        --供方销售单头（总部主体单据）
        SELECT HQ.*
          INTO R_SO_HEADER
          FROM CIMS.T_SO_HEADER HQ
         WHERE HQ.SO_NUM = REC.SRC_BILL_NUM;
        UPDATE T_SO_HEADER T
           SET T.RECEIVE_FLAG     = 'Y',
               T.RECEIVE_DATE     = R_SO_HEADER.RECEIVE_DATE,
               T.LAST_UPDATE_DATE = SYSDATE
         WHERE T.ENTITY_ID = P_ENTITY_ID
           AND T.SO_HEADER_ID = REC.SO_HEADER_ID;
        FOR L_REC IN (SELECT L.*
                      FROM T_SO_LINE L
                     WHERE L.SO_HEADER_ID = REC.SO_HEADER_ID) LOOP
          --供方销售单行（总部主体单据）
          SELECT LHQ.*
            INTO R_SO_LINE
            FROM CIMS.T_SO_LINE LHQ
           WHERE LHQ.ITEM_CODE = L_REC.ITEM_CODE
             AND LHQ.SO_HEADER_ID = R_SO_HEADER.SO_HEADER_ID;
          UPDATE T_SO_LINE L
             SET L.RECEIVED_DATE = R_SO_LINE.RECEIVED_DATE,
                 L.RECEIVED_QTY = R_SO_LINE.RECEIVED_QTY,
                 L.LAST_UPDATE_DATE = SYSDATE
           WHERE L.SO_LINE_ID = L_REC.SO_LINE_ID;
        END LOOP;
        COMMIT;
      EXCEPTION
        WHEN OTHERS THEN
          ROLLBACK TO SP;
          PKG_SO_INTF.P_TABLE_ACTION_LOG('T_SO_HEADER', --操作表名称
                                         '跨事业部采购,更新需方销售单签收信息',        --操作说明
                                         REC.SO_NUM,                    --关键主键
                                         1,                             --是否出错，1出错，0未出错
                                         '跨事业部采购,更新需方销售单签收信息，异常信息：' || P_ERR_MSG || SQLERRM --错误信息
                                         );
          --初始返回值
          P_RESULT  := PKG_SO_PUB.V_RESULT;
          P_ERR_MSG := PKG_SO_PUB.V_SUCCESS;
      END;
    END LOOP;
  EXCEPTION
    WHEN PKG_SO_PUB.V_BIZ_EXCEPTION THEN
      P_RESULT := -28027;
    WHEN OTHERS THEN
      P_RESULT  := -28027;
      P_ERR_MSG := '跨事业部采购,更新需方销售单签收信息：' || substr(dbms_utility.format_error_backtrace,
                                                   1,
                                                   100) || SQLERRM;
  END;
  
end PKG_SO_TO_POX;
/

