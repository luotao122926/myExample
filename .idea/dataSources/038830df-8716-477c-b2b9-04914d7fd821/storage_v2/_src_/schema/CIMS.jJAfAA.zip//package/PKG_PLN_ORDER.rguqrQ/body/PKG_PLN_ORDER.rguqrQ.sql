create Package Body Pkg_Pln_Order Is

  v_Nl      Constant Varchar2(2) := Chr(13) || Chr(10); --换行
  v_Null    Constant Varchar2(4) := 'NULL'; --空值
  v_True    Constant Varchar2(2) := 'Y';
  v_False   Constant Varchar2(2) := 'N';
  v_Result  Constant Number := 0; --成功返回
  v_Success Constant Varchar2(10) := 'SUCCESS';
  v_Failure Constant Varchar2(10) := 'FAILURE';
  v_Warning Constant Varchar2(10) := 'WARNING';
  v_Base_Exception Exception; --自定义异常

  v_Month_Edition    Number Not Null := -1; --本月版本号
  v_Month_Begin_Date Date; --月起始日期
  v_Month_End_Date   Date; --月终止日期
  v_ten_days_begin_date  DATE; --旬起始日期
  v_ten_days_end_date    DATE; --旬起始日期
  v_Week_Edition     Number Not Null := -1; --本周版本号
  v_Week_Begin_Date  Date; --周起始日期
  v_Week_End_Date    Date; --周起始日期

  v_State_Review_Complete Varchar2(100) := '评审完毕';

  v_Action_Submit           Varchar2(100) := '送审';
  v_Action_Inv_Review       Varchar2(100) := '库存评审';
  v_Action_Hq_Review        Varchar2(100) := '总部评审';
  v_Action_Check_Complete   Varchar2(100) := '审核';
  v_Action_Factory_Review   Varchar2(100) := '工厂评审';
  v_Action_Center_Confirm   Varchar2(100) := '中心确认';
  v_Action_Center_Review   Varchar2(100)  := '中心评审';
  v_Action_Aps_Interactive  Varchar2(100) := 'APS交互';
  v_Action_Hq_Confirm       Varchar2(100) := '总部确认';
  v_Action_Into_Aps_Intf    Varchar2(100) := '引APS接口';
  v_Action_Aps_Promise      Varchar2(100) := 'APS订单承诺';
  v_Action_Ord_Auto_Prdc    Varchar2(100) := '订单自动排产';
  v_Action_Review_Complete  Varchar2(100) := '评审完毕';
  v_Action_Back             Varchar2(100) := '退回';
  v_Action_Rebut            Varchar2(100) := '驳回';
  v_Action_Revoke           Varchar2(100) := '撤回';
  v_Action_Close            Varchar2(100) := '关闭';

  v_Action_SubmitHQ_Review  Varchar2(100) := '送总部评审'; --add by lizhen 2015-11-24

  v_Line_State_Closed     Varchar2(32) := 'CLOSED'; --已关闭状态
  v_Line_State_Awaited    Varchar2(32) := 'AWAITED'; --待关闭状态
  v_LineState_Normal      Varchar2(32) := 'NORMAL'; --正常

  -----------------------------------------------------------------------------
  -- AUTHOR  : NICRO.LI
  -- CREATED : 2014-07-14 11:05:52
  -- PURPOSE :获取入库期间
  -----------------------------------------------------------------------------
  Procedure p_Get_Supply_Date(p_Days  In Number, ---起始完成
                              p_Range In Number, ---终止完成
                              p_Begin Out Number, --起始日期
                              p_End   Out Number ---终止日期
                              ) Is

    v_Begin_End_Range Integer Not Null := 3;
    v_Week_Day        Integer Not Null := 0;
    v_Week_Ends       Integer Not Null := 0;

  Begin

    --起始完成
    Select Decode(Sign(Trunc(Nvl(p_Days, 0))), 1, Trunc(Nvl(p_Days, 0)), 0)
      Into p_Begin
      From Dual;

    --日期范围
    Select Decode(Sign(Trunc(Nvl(p_Range, 3))),
                  1,
                  Trunc(Nvl(p_Range, 3)),
                  0,
                  1,
                  3)
      Into v_Begin_End_Range
      From Dual;

    --日期循环
    For i In 1 .. v_Begin_End_Range Loop
      Select To_Number(To_Char(Sysdate + p_Begin + i - 1, 'D'))
        Into v_Week_Day
        From Dual;

      If v_Week_Day = 1 Then
        v_Week_Ends := v_Week_Ends + 1;
      End If;
    End Loop;

    --终止完成
    p_End := p_Begin + v_Begin_End_Range - 1 + v_Week_Ends;

  End p_Get_Supply_Date;

  -----------------------------------------------------------------------------
  -- AUTHOR  : NICRO.LI
  -- CREATED : 2014-07-16 11:05:52
  -- PURPOSE : 初始化计划阶段
  -----------------------------------------------------------------------------
  Procedure p_Init_Order_Period(p_Year_Code In Varchar2, --计划年度编码
                                p_Entity_Id In Number, --主体ID
                                p_User_Code In Varchar2, --用户编码
                                p_Result    Out Number,
                                p_Err_Msg   Out Varchar2 --返回结果：成功返回"SUCCESS"，失败返回原因
                                ) Is

    v_Month_Number Number Not Null := 0; --月度计数
    v_Week_Number  Number Not Null := 0; --周计数
    v_ten_days_number NUMBER NOT NULL := 0; -- 旬计数, by ex_zhangka 2018-04-08
    v_Begin_Date   Date; --起始日期
    v_End_Date     Date; --终止日期

    v_p_Year_Id      Number Not Null := -1; --上年ID
    v_p_Month_Id     Number;
    v_p_ten_days_id  NUMBER; -- 上一个旬度ID, by ex_zhangka 2018-04-08
    v_p_Week_Id      Number;
    v_Year_Id        Number;
    v_Month_Id       Number;
    v_ten_days_id    Number; -- 当前旬度ID, by ex_zhangka 2018-04-08
    v_Week_Id        Number;
    v_Version_Number Number; --月份版本数
    v_Index          Number;

    v_Message Varchar2(50); --辅助结果
    v_Status  Varchar2(50); --辅助状态
    v_String  Varchar2(500); --辅助信息
    v_Tmp_Int Number;
  Begin
    p_Result  := v_Result;
    p_Err_Msg := v_Success;
    --获取年度开始日期
    Select To_Date(p_Year_Code || '0101', 'YYYYMMDD')
      Into v_Begin_Date
      From Dual;

    --获取年度结束日期
    Select Last_Day(To_Date(p_Year_Code || '1201', 'YYYYMMDD'))
      Into v_End_Date
      From Dual;

    v_Message := Substrb(('初始化计划阶段' || '失败' || v_Nl), 1, 50);
    v_Status  := Substrb((v_Nl || '初始化' || '：'), 1, 50);
    v_String  := Substrb((v_Nl || v_Nl || '起始日期：' ||
                         To_Char(v_Begin_Date, 'YYYY-MM-DD') || v_Nl ||
                         '终止日期：' || To_Char(v_End_Date, 'YYYY-MM-DD') || v_Nl ||
                         '主主体ID：' || To_Char(p_Entity_Id) || v_Nl ||
                         '用户编码：' || p_User_Code || v_Nl),
                         1,
                         500);

    v_Status := Substrb((v_Nl || '输入参数检查' || '：'), 1, 50);
    If v_Begin_Date Is Null Or v_End_Date Is Null Or p_Entity_Id Is Null Or
       p_User_Code Is Null Then
      p_Err_Msg := Substrb((v_Result || v_Status || '部分参数为空或错误' || v_String),
                           1,
                           2000);
      p_Result  := -21000;
      Return;
    End If;

    v_Status := Substrb((v_Nl || '检查日期范围' || '：'), 1, 50);
    Begin
      Select 1
        Into v_Tmp_Int
        From Dual
       Where v_Begin_Date = Trunc(v_Begin_Date, 'MM') --起始日期为月第一天
         And v_End_Date = Trunc(Last_Day(v_End_Date)) --终止日期为月最后一天
         And Months_Between(Trunc(v_End_Date, 'MM'), v_Begin_Date) = 11 --日期范围为1整年
         And Not Exists ( --起始日期大于已存在年月周的最大终止日期
              Select Null
                From (Select Max(End_Date) Max_End_Date
                         From t_Pln_Order_Period --取已存在年月周的最大终止日期，不分年月周
                        Where Entity_Id = p_Entity_Id)
               Where v_Begin_Date <= Max_End_Date);
    Exception
      When Others Then
        p_Err_Msg := Substrb((v_Result || v_Status || '检查失败' || v_Nl ||
                             '请参照以下要求，检查日期范围' || v_Nl ||
                             '1、起始日期为月初，终止日期为月末，两者相隔一整年；' || v_Nl ||
                             '2、起始、终止日期范围不能与已有计划年、月、周重复；' || v_String),
                             1,
                             2000);
        p_Result  := -21000;
        Return;
    End;

    v_Status := Substrb((v_Nl || '取上年' || '：'), 1, 50);
    Begin
      Select Period_Id
        Into v_p_Year_Id
        From t_Pln_Order_Period
       Where Period_Type = '年'
         And Entity_Id = p_Entity_Id
         And End_Date = Trunc(v_Begin_Date - 1)
         And Next_Period_Id = -1;

      v_Status := Substrb((v_Nl || '取上月' || '：'), 1, 50);
      Begin
        Select Period_Id
          Into v_p_Month_Id
          From t_Pln_Order_Period
         Where Period_Type = '月'
           And Parent_Period_Id = v_p_Year_Id
           And Entity_Id = p_Entity_Id
           And End_Date = Trunc(v_Begin_Date - 1)
           And Next_Period_Id = -1;

        -- 获取上一个旬度的周期ID赋值给变量, by ex_zhangka 2018-04-08
        v_status := SUBSTRB((v_nl || '取上一个旬度' || '：'), 1, 50);
        BEGIN
          SELECT period_id
            INTO v_p_ten_days_id
            FROM t_pln_order_period
           WHERE period_type = '旬'
             AND parent_period_id = v_p_month_id
             AND entity_id = p_entity_id
             AND end_date = TRUNC(v_begin_date - 1)
             AND next_period_id = -1;
        EXCEPTION
          WHEN OTHERS THEN
            v_p_ten_days_id := -1;
        END;

        v_Status := Substrb((v_Nl || '取上周' || '：'), 1, 50);
        Begin
          Select Period_Id
            Into v_p_Week_Id
            From t_Pln_Order_Period
           Where Period_Type = '周'
             And Parent_Period_Id = v_p_Month_Id
             And Entity_Id = p_Entity_Id
             And End_Date = Trunc(v_Begin_Date - 1)
             And Next_Period_Id = -1;
        Exception
          When Others Then
            v_p_Week_Id := -1;
        End;
      Exception
        When Others Then
          v_p_Month_Id := -1;
          v_p_ten_days_id := -1; -- ex_zhangka 2018-04-08
          v_p_Week_Id  := -1;
      End;
    Exception
      When Others Then
        v_p_Year_Id  := -1;
        v_p_Month_Id := -1;
        v_p_ten_days_id := -1; -- ex_zhangka 2018-04-08
        v_p_Week_Id  := -1;
    End;

    v_Status := Substrb((v_Nl || '读锁定上年' || '：'), 1, 50);
    If Nvl(v_p_Year_Id, -1) <> -1 Then
      Begin
        Select 1
          Into v_Tmp_Int
          From t_Pln_Order_Period
         Where Period_Id = v_p_Year_Id
           And Next_Period_Id = -1; --FOR UPDATE NOWAIT;
      Exception
        When Others Then
          p_Err_Msg := Substrb((v_Result || v_Status || '读锁定失败' || v_String ||
                               '上年ID：' || To_Char(v_p_Year_Id) || v_Nl),
                               1,
                               2000);
          p_Result  := -21000;
          Return;
      End;
    End If;

    v_Status := Substrb((v_Nl || '读锁定上月' || '：'), 1, 50);
    If Nvl(v_p_Month_Id, -1) <> -1 Then
      Begin
        Select 1
          Into v_Tmp_Int
          From t_Pln_Order_Period
         Where Period_Id = v_p_Month_Id
           And Next_Period_Id = -1; --FOR UPDATE NOWAIT;
      Exception
        When Others Then
          p_Err_Msg := Substrb((v_Result || v_Status || '读锁定失败' || v_String ||
                               '上年ID：' || To_Char(v_p_Year_Id) || v_Nl ||
                               '上月ID：' || To_Char(v_p_Month_Id) || v_Nl),
                               1,
                               2000);
          p_Result  := -21000;
          Return;
      End;
    End If;

    -- 获取上一个旬度的锁定信息, by ex_zhangka 2018-04-08
    v_status := SUBSTRB((v_nl || '读锁定上一个旬度' || '：'), 1, 50);
    IF NVL(v_p_ten_days_id, -1) <> -1 THEN
      BEGIN
        SELECT 1
          INTO v_tmp_int
          FROM t_pln_order_period
         WHERE period_id = v_p_ten_days_id
           AND next_period_id = -1;
      EXCEPTION
        WHEN OTHERS THEN
          p_err_msg := SUBSTRB((v_result || v_status || '读锁定失败' || v_string ||
                               '上年id：' || to_char(v_p_year_id) || v_nl ||
                               '上月id：' || to_char(v_p_month_id) || v_nl ||
                               '上一个旬度id：' || to_char(v_p_ten_days_id) || v_nl),
                               1,
                               2000);
          p_result  := -21000;
          RETURN;
      END;
    END IF;

    v_Status := Substrb((v_Nl || '读锁定上周' || '：'), 1, 50);
    If Nvl(v_p_Week_Id, -1) <> -1 Then
      Begin
        Select 1
          Into v_Tmp_Int
          From t_Pln_Order_Period
         Where Period_Id = v_p_Week_Id
           And Next_Period_Id = -1; --FOR UPDATE NOWAIT;
      Exception
        When Others Then
          p_Err_Msg := Substrb((v_Result || v_Status || '读锁定失败' || v_String ||
                               '上年ID：' || To_Char(v_p_Year_Id) || v_Nl ||
                               '上月ID：' || To_Char(v_p_Month_Id) || v_Nl ||
                               '上周ID：' || To_Char(v_p_Week_Id) || v_Nl),
                               1,
                               2000);
          p_Result  := -21000;
          Return;
      End;
    End If;

    v_Status := Substrb((v_Nl || '取年序列' || '：'), 1, 50);
    Select s_Pln_Order_Period.Nextval Into v_Year_Id From Dual;

    v_Status := Substrb((v_Nl || '插入年度' || '：'), 1, 50);
    Insert Into t_Pln_Order_Period
      (Period_Id,
       Period_Type,
       Period_Code,
       Description,
       Parent_Period_Id,
       Prior_Period_Id,
       Next_Period_Id,
       Statistic_Year,
       Sale_Year_Year,
       Begin_Date,
       End_Date,
       Entity_Id,
       Created_By,
       Creation_Date,
       Last_Updated_By,
       Last_Update_Date)
    Values
      (v_Year_Id,
       '年',
       Substrb((To_Char(v_End_Date, 'YYYY') || '计划年度'), 1, 40),
       Substrb((To_Char(v_Begin_Date, 'YYYY-MM-DD') || '至' ||
               To_Char(v_End_Date, 'YYYY-MM-DD')),
               1,
               240),
       -1,
       v_p_Year_Id,
       -1,
       To_Number(To_Char(v_End_Date, 'YYYY')),
       To_Number(To_Char(v_End_Date, 'YYYY')),
       v_Begin_Date,
       v_End_Date,
       p_Entity_Id,
       p_User_Code,
       Sysdate,
       p_User_Code,
       Sysdate);

    v_Status := Substrb((v_Nl || '更新上年关联属性' || '：'), 1, 50);
    If Nvl(v_p_Year_Id, -1) <> -1 Then
      Update t_Pln_Order_Period
         Set Next_Period_Id = v_Year_Id
       Where Period_Id = v_p_Year_Id
         And Next_Period_Id = -1;
    End If;

    v_Status           := Substrb((v_Nl || '循环插入月度' || '：'), 1, 50);
    v_Month_Number     := 1;
    v_Month_Begin_Date := Trunc(v_Begin_Date, 'MM');
    v_Month_End_Date   := Trunc(Last_Day(v_Month_Begin_Date));
    While (Nvl(v_Month_Number, -1) <= 12) Loop
      v_Status := Substrb((v_Nl || '取月序列' || '：'), 1, 50);
      Select s_Pln_Order_Period.Nextval Into v_Month_Id From Dual;

      v_Status := Substrb((v_Nl || '插入月' || '：'), 1, 50);
      Insert Into t_Pln_Order_Period
        (Period_Id,
         Period_Type,
         Period_Code,
         Description,
         Parent_Period_Id,
         Prior_Period_Id,
         Next_Period_Id,
         Statistic_Year,
         Statistic_Season,
         Statistic_Month,
         Sale_Year_Year,
         Sale_Year_Month,
         Dead_Busy,
         Begin_Date,
         End_Date,
         Entity_Id,
         Created_By,
         Creation_Date,
         Last_Updated_By,
         Last_Update_Date)
      Values
        (v_Month_Id,
         '月',
         Substrb((To_Char(v_Month_End_Date, 'YYYY') || '年' ||
                 To_Char(v_Month_End_Date, 'MM') || '月'),
                 1,
                 40),
         Substrb((To_Char(v_Month_Begin_Date, 'YYYY-MM-DD') || '至' ||
                 To_Char(v_Month_End_Date, 'YYYY-MM-DD')),
                 1,
                 240),
         v_Year_Id,
         v_p_Month_Id,
         -1,
         To_Number(To_Char(v_Month_End_Date, 'YYYY')),
         Trunc((v_Month_Number - 1) / 3) + 1,
         To_Number(To_Char(v_Month_End_Date, 'MM')),
         To_Number(To_Char(v_End_Date, 'YYYY')),
         v_Month_Number,
         Decode(Sign(v_Month_Number - 6), 1, '旺季', '淡季'),
         v_Month_Begin_Date,
         v_Month_End_Date,
         p_Entity_Id,
         p_User_Code,
         Sysdate,
         p_User_Code,
         Sysdate);

      v_Status := Substrb((v_Nl || '更新上月关联属性' || '：'), 1, 50);
      If Nvl(v_p_Month_Id, -1) <> -1 Then
        Update t_Pln_Order_Period
           Set Next_Period_Id = v_Month_Id
         Where Period_Id = v_p_Month_Id
           And Next_Period_Id = -1;
      End If;
      v_p_Month_Id := v_Month_Id;

      --取消生成0周的代码
      /*
      INSERT INTO T_PLN_ORDER_PERIOD
        (PERIOD_ID, --
         PERIOD_TYPE, --
         PERIOD_CODE, --
         DESCRIPTION, --
         PARENT_PERIOD_ID, --
         PRIOR_PERIOD_ID, --
         NEXT_PERIOD_ID, --
         STATISTIC_YEAR, --
         STATISTIC_SEASON, --
         STATISTIC_MONTH, --
         STATISTIC_WEEK, --
         SALE_YEAR_YEAR, --
         SALE_YEAR_MONTH, --
         SALE_YEAR_WEEK, --
         DEAD_BUSY, --
         BEGIN_DATE, --
         END_DATE, --
         ENTITY_ID, --
         CREATED_BY, --
         CREATION_DATE, --
         LAST_UPDATED_BY, --
         LAST_UPDATE_DATE) --
      VALUES
        (S_PLN_ORDER_PERIOD.NEXTVAL, --PERIOD_ID, --
         '周', --PERIOD_TYPE, --
         SUBSTRB((TO_CHAR(V_MONTH_END_DATE, 'YYYY') || '年' ||
                 TO_CHAR(V_MONTH_END_DATE, 'MM') || '月0周'),
                 1,
                 40), --PERIOD_CODE, --
         SUBSTRB((TO_CHAR(V_MONTH_BEGIN_DATE, 'YYYY-MM-DD') || '至' ||
                 TO_CHAR(V_MONTH_END_DATE, 'YYYY-MM-DD')),
                 1,
                 240), --DESCRIPTION, --
         V_MONTH_ID, --PARENT_PERIOD_ID, --
         -1, --PRIOR_PERIOD_ID, --
         -1, --NEXT_PERIOD_ID, --
         TO_NUMBER(TO_CHAR(V_MONTH_END_DATE, 'YYYY')), --STATISTIC_YEAR, --
         TRUNC((V_MONTH_NUMBER - 1) / 3) + 1, --STATISTIC_SEASON, --
         TO_NUMBER(TO_CHAR(V_MONTH_END_DATE, 'MM')), --STATISTIC_MONTH, --
         0, --STATISTIC_WEEK, --
         TO_NUMBER(TO_CHAR(V_END_DATE, 'YYYY')), --SALE_YEAR_YEAR, --
         V_MONTH_NUMBER, --SALE_YEAR_MONTH, --
         0, --SALE_YEAR_WEEK, --
         DECODE(SIGN(V_MONTH_NUMBER - 6), 1, '旺季', '淡季'), --DEAD_BUSY, --
         V_MONTH_BEGIN_DATE, --BEGIN_DATE, --
         V_MONTH_END_DATE, --END_DATE, --
         P_ENTITY_ID, --ENTITY_ID, --
         P_USER_CODE, --CREATED_BY, --
         SYSDATE, --CREATION_DATE, --
         P_USER_CODE, --LAST_UPDATED_BY, --
         SYSDATE); --LAST_UPDATE_DATE) --*/

      v_Status          := Substrb((v_Nl || '循环插入周' || '：'), 1, 50);
      v_Week_Number     := 1;
      v_Week_Begin_Date := Trunc(v_Month_Begin_Date, 'MM');
      v_Week_End_Date   := Trunc(v_Week_Begin_Date + 6);
      While (Nvl(v_Week_Number, -1) <= 4) Loop
        v_Status := Substrb((v_Nl || '取周序列' || '：'), 1, 50);
        Select s_Pln_Order_Period.Nextval Into v_Week_Id From Dual;

        v_Status := Substrb((v_Nl || '插入周' || '：'), 1, 50);
        Insert Into t_Pln_Order_Period
          (Period_Id,
           Period_Type,
           Period_Code,
           Description,
           Parent_Period_Id,
           Prior_Period_Id,
           Next_Period_Id,
           Statistic_Year,
           Statistic_Season,
           Statistic_Month,
           Statistic_Week,
           Sale_Year_Year,
           Sale_Year_Month,
           Sale_Year_Week,
           Dead_Busy,
           Begin_Date,
           End_Date,
           Entity_Id,
           Created_By,
           Creation_Date,
           Last_Updated_By,
           Last_Update_Date)
        Values
          (v_Week_Id,
           '周',
           Substrb((To_Char(v_Week_End_Date, 'YYYY') || '年' ||
                   To_Char(v_Week_End_Date, 'MM') || '月' || v_Week_Number || '周'),
                   1,
                   40),
           Substrb((To_Char(v_Week_Begin_Date, 'YYYY-MM-DD') || '至' ||
                   To_Char(v_Week_End_Date, 'YYYY-MM-DD')),
                   1,
                   240),
           v_Month_Id,
           v_p_Week_Id,
           -1,
           To_Number(To_Char(v_Week_End_Date, 'YYYY')),
           Trunc((v_Month_Number - 1) / 3) + 1,
           To_Number(To_Char(v_Week_End_Date, 'MM')),
           v_Week_Number,
           To_Number(To_Char(v_End_Date, 'YYYY')),
           v_Month_Number,
           v_Week_Number,
           Decode(Sign(v_Month_Number - 6), 1, '旺季', '淡季'),
           v_Week_Begin_Date,
           v_Week_End_Date,
           p_Entity_Id,
           p_User_Code,
           Sysdate,
           p_User_Code,
           Sysdate);

        v_Status := Substrb((v_Nl || '更新上周关联属性' || '：'), 1, 50);
        If Nvl(v_p_Week_Id, -1) <> -1 Then
          Update t_Pln_Order_Period
             Set Next_Period_Id = v_Week_Id
           Where Period_Id = v_p_Week_Id
             And Next_Period_Id = -1;
        End If;

        v_p_Week_Id := v_Week_Id;

        v_Week_Number     := v_Week_Number + 1;
        v_Week_Begin_Date := Trunc(v_Week_End_Date + 1);
        v_Week_End_Date   := Trunc(v_Week_Begin_Date + 6);
        If Nvl(v_Week_Number, -1) >= 4 Then
          v_Week_End_Date := Trunc(v_Month_End_Date);
        End If;
      End Loop;

      -- 设置初始参数, by ex_zhangka 2018-04-08 start
      v_status              := SUBSTRB((v_nl || '循环插入旬' || '：'), 1, 50);
      v_ten_days_number     := 1;
      v_ten_days_begin_date := TRUNC(v_month_begin_date, 'MM');
      v_ten_days_end_date   := TRUNC(v_ten_days_begin_date + 9);

      -- 开始循环旬
      WHILE (NVL(v_ten_days_number, -1) <= 3) LOOP

        -- 设置当前ID的值
        v_status := SUBSTRB((v_nl || '取旬序列' || '：'), 1, 50);
        SELECT s_pln_order_period.nextval INTO v_ten_days_id FROM dual;

        -- 插入语句
        v_status := SUBSTRB((v_nl || '插入旬' || '：'), 1, 50);
        INSERT INTO t_pln_order_period
          (period_id,
           period_type,
           period_code,
           description,
           parent_period_id,
           prior_period_id,
           next_period_id,
           statistic_year,
           statistic_season,
           statistic_month,
           statistic_ten_days,
           sale_year_year,
           sale_year_month,
           sale_year_ten_days,
           dead_busy,
           begin_date,
           end_date,
           entity_id,
           created_by,
           creation_date,
           last_updated_by,
           last_update_date)
        VALUES
          (v_ten_days_id,
           '旬',
           -- 拼接2018年1月上旬
           SUBSTRB((to_char(v_ten_days_end_date, 'yyyy') || '年' ||
                   to_char(v_ten_days_end_date, 'mm') || '月' ||
                   DECODE(v_ten_days_number, 1, '上', 2, '中', '下') || '旬'),
                   1,
                   40),
           -- 拼接2018-01-01至2018-01-10
           SUBSTRB((to_char(v_ten_days_begin_date, 'yyyy-mm-dd') || '至' ||
                   to_char(v_ten_days_end_date, 'yyyy-mm-dd')),
                   1,
                   240),
           v_month_id,
           v_p_ten_days_id,
           -1,
           TO_NUMBER(TO_CHAR(v_ten_days_end_date, 'yyyy')),
           TRUNC((v_month_number - 1) / 3) + 1,
           TO_NUMBER(TO_CHAR(v_ten_days_end_date, 'mm')),
           DECODE(v_ten_days_number, 1, '上', 2, '中', '下'),
           TO_NUMBER(TO_CHAR(v_end_date, 'yyyy')),
           v_month_number,
           DECODE(v_ten_days_number, 1, '上', 2, '中', '下'),
           DECODE(SIGN(v_month_number - 6), 1, '旺季', '淡季'),
           v_ten_days_begin_date,
           v_ten_days_end_date,
           p_entity_id,
           p_user_code,
           SYSDATE,
           p_user_code,
           SYSDATE);

        -- 更新关联属性
        v_status := SUBSTRB((v_nl || '更新上旬度关联属性' || '：'), 1, 50);
        IF NVL(v_p_ten_days_id, -1) <> -1 THEN
          UPDATE t_pln_order_period
             SET next_period_id = v_ten_days_id
           WHERE period_id = v_p_ten_days_id
             AND next_period_id = -1;
        END IF;

        -- 重新赋值，准备下一次循环
        v_p_ten_days_id       := v_ten_days_id;
        v_ten_days_number     := v_ten_days_number + 1;
        v_ten_days_begin_date := TRUNC(v_ten_days_end_date + 1);
        v_ten_days_end_date   := TRUNC(v_ten_days_begin_date + 9);
        IF NVL(v_ten_days_number, -1) >= 3 THEN
          v_ten_days_end_date := TRUNC(v_month_end_date); -- 下旬结束日期取月底最后一天
        END IF;
      END LOOP;
      -- by ex_zhangka 2018-04-08 end

      v_Month_Number     := v_Month_Number + 1;
      v_Month_Begin_Date := Trunc(Add_Months(v_Month_Begin_Date, 1), 'MM');
      v_Month_End_Date   := Trunc(Last_Day(v_Month_Begin_Date));
    End Loop;

    p_Result  := v_Result;
    p_Err_Msg := v_Success;
  Exception
    When v_Base_Exception Then
      p_Err_Msg := Substrb((v_Result || v_Status || '未知错误' || v_Nl ||
                           Sqlerrm || v_String),
                           1,
                           2000);
      p_Result  := -21000;
      Rollback;
    When Others Then
      p_Err_Msg := Substrb((v_Result || v_Status || '未知错误' || v_Nl ||
                           Sqlerrm || v_String),
                           1,
                           2000);
      p_Result  := -21000;
      Rollback;
  End p_Init_Order_Period;

  -----------------------------------------------------------------------------
  -- AUTHOR  : NICRO.LI
  -- CREATED : 2014-07-14 11:05:52
  -- PURPOSE : 检查送审的订单行 (产品如果没有在当前生产产地维护则返回提示)
  -----------------------------------------------------------------------------
  Procedure p_Chk_Order_Line_Mtl_Producing(p_Order_Head_Id In Number, ----订单ID
                                           p_Result        Out Varchar2 --返回结果：成功返回"SUCCESS"，失败返回原因
                                           ) Is
    v_Order_Type_Id   Number;
    v_Order_Type_Name Varchar2(100);
  Begin
    p_Result := v_Success;
    Select Nvl(Order_Type_Id, -1), Order_Type_Name
      Into v_Order_Type_Id, v_Order_Type_Name
      From t_Pln_Order_Head
     Where Order_Head_Id = p_Order_Head_Id;
    If v_Order_Type_Name <> '临时订单' Then
      Return;
    End If;

    --清空评审结果
    Update t_Pln_Order_Line
       Set Check_Result = Null
     Where Order_Head_Id = p_Order_Head_Id;

    For C1 In (Select l.Item_Id, l.Order_Line_Id
                 From t_Pln_Order_Line l
                Where Not Exists
                (Select 1
                         From t_Pln_Item_Producing_Area Mpa
                        Where Mpa.Item_Id = l.Item_Id
                          And Mpa.Producing_Area_Id = l.Producing_Area_Id
                          And Trunc(Sysdate) Between Mpa.Begin_Date And
                              Nvl(Mpa.End_Date, Trunc(Sysdate))
                          And Mpa.Entity_Id = l.Entity_Id)
                  And l.Order_Head_Id = p_Order_Head_Id) Loop
      Update t_Pln_Order_Line
         Set Check_Result = '产品产地未维护'
       Where Order_Head_Id = p_Order_Head_Id
         And Order_Line_Id = C1.Order_Line_Id;

      p_Result := '请在[产品生产产地维护]界面中维护产品产地';
    End Loop;
  End;

  -----------------------------------------------------------------------------
  ---- AUTHOR  : NICRO.LI
  -- CREATED : 2014-07-16 11:05:52
  -- PURPOSE : 评审完毕生成生订单明细行
  -----------------------------------------------------------------------------
  Procedure p_Create_Order_Detail(p_Order_Head_Id In Number, ----订单ID
                                  p_User_Code     In Varchar2, ----用户编码
                                  p_Result        In Out Varchar2 --返回结果：成功返回"SUCCESS"，失败返回原因
                                  ) Is

    v_Cur_Nd_Smtl Integer Not Null := 0; --计数变量
    v_Entity_Id   Number;
    v_Item_Product_Form        Varchar2(100);
    v_Assemblies_Value_Scale   Number;
    Cursor c_s_Item(p_Item_Id Number, p_Entity_Id Number) Is
      Select c.Item_Id Sub_Item_Id,
             Trunc(Nvl(c.Quantity, 0)) Sub_Qty,
             d.Item_Code Sub_Item_Code,
             d.Item_Name Sub_Item_Desc,
             d.Defaultunit Sub_Item_Uom
        From t_Bd_Item                a,
             t_Bd_Item_Assemblies     b,
             t_Bd_Item_Assemblies_Sub c,
             t_Bd_Item                d
       Where a.Item_Id = Nvl(p_Item_Id, -1)
         And a.Entity_Id = Nvl(p_Entity_Id, -1)
            --AND A.ASSEMBLED_ENABLED_FLAG = 'Y'
         And a.Item_Id = b.Item_Id
         And b.Entity_Id = Nvl(p_Entity_Id, -1)
         And Trunc(Sysdate) Between Trunc(Nvl(b.Begin_Date, Sysdate + 1)) And
             Trunc(Nvl(b.End_Date, Sysdate + 1))
         And b.Item_Assembly_Id = c.Item_Assembly_Id
         And c.Entity_Id = Nvl(p_Entity_Id, -1)
         And Trunc(Sysdate) Between Trunc(Nvl(c.Begin_Date, Sysdate + 1)) And
             Trunc(Nvl(c.End_Date, Sysdate + 1))
         And Trunc(Nvl(c.Quantity, 0)) >= 1
         And c.Item_Id = d.Item_Id
         And d.Entity_Id = Nvl(p_Entity_Id, -1)
      Union All
      Select a.Item_Id     Sub_Item_Id,
             1             Sub_Qty,
             a.Item_Code   Sub_Item_Code,
             a.Item_Name   Sub_Item_Desc,
             a.Defaultunit Sub_Item_Uom
        From t_Bd_Item a
       Where a.Item_Id = Nvl(p_Item_Id, -1)
         And a.Entity_Id = Nvl(p_Entity_Id, -1)
            --And a.Productform <> 'productForm_enum_set1'
         And Not Exists
       (Select 1
                From t_Bd_Item_Assemblies Ia
               Where Ia.Item_Id = a.Item_Id
                 And Ia.Entity_Id = p_Entity_Id
                 And Trunc(Sysdate) Between
                     Trunc(Nvl(Ia.Begin_Date, Sysdate + 1)) And
                     Trunc(Nvl(Ia.End_Date, Sysdate + 1)));
    r_s_Item c_s_Item%Rowtype;
  Begin
    --删除订单散件明细
    Delete From t_Pln_Order_Detail Where Order_Head_Id = p_Order_Head_Id;

    Select Oh.Entity_Id
      Into v_Entity_Id
      From t_Pln_Order_Head Oh
     Where Oh.Order_Head_Id = p_Order_Head_Id;

    --循环订单产品明细
    For r_Line In (Select l.Entity_Id,
                          l.Order_Head_Id,
                          l.Order_Line_Id,
                          l.Item_Id,
                          l.item_code,
                          h.Customer_Id,
                          l.Producing_Area_Id,
                          l.Producing_Area_Code,
                          l.Producing_Area_Name,
                          Nvl(l.Can_Produce_Qty, 0) Usable_Produce_Qty,
                          l.begin_supply_date,
                          l.end_supply_date
                     From t_Pln_Order_Head h, t_Pln_Order_Line l
                    Where h.Order_Head_Id = p_Order_Head_Id
                      And h.Order_Head_Id = l.Order_Head_Id
                      And l.Entity_Id = v_Entity_Id
                      And Nvl(l.Can_Produce_Qty, 0) > 0) Loop
      --ADD BY LIZHEN 2015-01-31 判断套件产品是否存在套散件关系，无套散件关系则提示异常
      Begin
        Select Bi.Productform
          Into v_Item_Product_Form
          From t_Bd_Item Bi
         Where Bi.Item_Code = r_Line.Item_Code
           And Bi.Item_Id = r_Line.Item_id
           And Bi.Entity_Id = r_Line.Entity_Id;
      Exception
        When Others Then
          p_Result := '获取产品套散件属性失败！' || v_Nl || '产品编码：' ||
                      r_Line.Item_Code || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
      End;
      --add by lizhen 2015-01-31 判断套件产品是否存在套散件关系，无套散件关系则提示异常
      --产品属性说明
      /*SET_PRODUCT       套机
        INDOOR_PRODUCT    室内机
        OUTDOOR_PRODUCT   室外机
        WHOLE_PRODUCT     整体机
        SAMPLE_PRODUCT    样机
        PARTS_PRODUCT     散件
        ACCESSORIES_PRODUCT 独立销售模块*/
      If v_Item_Product_Form = 'SET_PRODUCT' Then
        Select Sum(Ias.Value_Scale)
          Into v_Assemblies_Value_Scale
          From t_Bd_Item_Assemblies Bia, t_Bd_Item_Assemblies_Sub Ias
         Where Bia.Item_Assembly_Id = Ias.Item_Assembly_Id
           And Nvl(Bia.Active_Flag, 'N') = 'Y'
           And Nvl(Ias.Active_Flag, 'N') = 'Y'
           And Bia.Entity_Id = r_Line.Entity_Id
           And Bia.Item_Id = r_Line.Item_Id;
        If Nvl(v_Assemblies_Value_Scale, 0) < 100 Then
          p_Result := '检查套件产品套散件关系失败。' || v_Nl ||
            '原因：1、不存在套散件关系；' || v_Nl ||
            ' 2、套散件关系已失效；' || v_Nl ||
            ' 3、散件价值比率小于100，散件产品价值比率合计：' || To_Char(Nvl(v_Assemblies_Value_Scale, 0)) || '；' || v_Nl ||
            '套件产品编码：' || r_Line.Item_Code;
          Raise v_Base_Exception;
        End If;
      End If;
      --循环产品的散件
      For r_s_Item In c_s_Item(r_Line.Item_Id, v_Entity_Id) Loop
        v_Cur_Nd_Smtl := Nvl(r_Line.Usable_Produce_Qty, 0) *
                         Nvl(r_s_Item.Sub_Qty, 0);
        --生成订单散件行
        Insert Into t_Pln_Order_Detail
          (Order_Detail_Id,
           Order_Head_Id,
           Order_Line_Id,
           Item_Id,
           Item_Code,
           Item_Name,
           Item_Uom,
           Can_Produce_Qty,
           Entity_Id,
           Created_By,
           Creation_Date,
           Last_Updated_By,
           Last_Update_Date,
           Producing_Area_Id,
           Producing_Area_Code,
           Producing_Area_Name,
           Begin_Supply_Date,
           End_Supply_Date)
        Values
          (s_Pln_Order_Detail.Nextval,
           r_Line.Order_Head_Id,
           r_Line.Order_Line_Id,
           r_s_Item.Sub_Item_Id,
           r_s_Item.Sub_Item_Code,
           r_s_Item.Sub_Item_Desc,
           r_s_Item.Sub_Item_Uom,
           v_Cur_Nd_Smtl,
           v_Entity_Id,
           p_User_Code,
           Sysdate,
           p_User_Code,
           Sysdate,
           r_Line.Producing_Area_Id,
           r_Line.Producing_Area_Code,
           r_Line.Producing_Area_Name,
           Null,
           Null);
      End Loop;
    End Loop;

    --成功返回
    p_Result := v_Success;
  Exception
    When v_Base_Exception Then
      Rollback;
      p_Result := p_Result;
    When Others Then
      Rollback;
      p_Result := '生成订单明细行失败，未知错误。' || v_Nl ||
        p_Result || v_Nl || Sqlerrm;
  End;

  -----------------------------------------------------------------------------
  ---- AUTHOR  : NICRO.LI
  -- CREATED : 2014-07-16 11:05:52
  -- PURPOSE : 临时订单评审完毕
  -----------------------------------------------------------------------------
  Procedure p_Complete_Review_Order(p_Order_Head_Id    In Number, ----订单ID
                                    p_Operation_Action In Varchar2, --当前单据动作
                                    p_User_Code        In Varchar2, ----用户编码
                                    p_Result           Out Varchar2 --返回结果：成功返回"SUCCESS"，失败返回原因
                                    ) Is
    v_Entity_Id       Number;
    v_Sales_Center_Id Number;
    v_Customer_Id     Number;
    v_Account_Id      Number;   --add by xuhongjiu 锁款用的
    v_Period_Id       Number;
    v_Period_Type     Varchar2(60);
    v_Tmp_Flag        Varchar2(1); --临时标识，01位长

    v_Order_Type_Id   Number;
    v_Order_Type_Name Varchar2(50); --订单类型
    r_Order_Type      t_pln_order_type%Rowtype;

    v_Message Varchar2(50); --辅助结果
    v_Status  Varchar2(50); --辅助状态
    v_String  Varchar2(500); --辅助信息

    v_Defer_Supply_Days Varchar2(200); --20081222 LUOHANG
    n_Defer_Supply_Days Number; --20081222 LUOHANG 延迟入库天数
    n_Discount_Type_Id  Number; --20081230 LUOHANG 折扣类型ID
    n_Customer_Balance  Number; --20081230 LUOHANG 中心订单信用余额
    n_Order_Amount      Number; --20081230 LUOHANG 单据金额

    --V_ORDER_STATE  VARCHAR2(50);--20070417 ADD BY ZHONGLIMING 单据状态变量
    v_Oem_Uses             Varchar2(5); --20070417 ADD BY ZHONGLIMING 是否使用OEM仓库
    v_Erp_Produce_Area     Varchar2(5); --20070417 ADD BY ZHONGLIMING 是否使用OEM产地
    n_Productng_Area_Count Number;
    p_Order_Number_l       Varchar2(100);
    v_Count                Number;
    v_Pln_Wip_Ord_Match    Varchar2(100);
    v_Value                Varchar2(2000);
    v_Sys_Source           Varchar2(50);  --add by xuhongjiu 用于判断如果是提货订单过来的就不锁款了
    v_source_type          Varchar2(60);  --add bu xuhongjiu 同上
  Begin
    p_Result  := v_Success;
    v_Message := Substrb(('临时订单评审完毕' || '失败' || v_Nl), 1, 50);
    v_Status  := Substrb((v_Nl || '输入参数检查' || '：'), 1, 50);
    If p_Order_Head_Id Is Null Or p_User_Code Is Null Then
      p_Result := Substrb((v_Message || v_Status || '部分参数为空或错误' || v_String),
                          1,
                          2000);
      Return;
    End If;

    v_Status := Substrb((v_Nl || '检查订单状态，并读锁定' || '：'), 1, 50);
    Begin
      Select h.Entity_Id,
             h.Sales_Center_Id,
             h.Customer_Id,
             h.account_id,
             h.Period_Id,
             h.Order_Type_Name,
             h.Order_Type_Id,
             h.sys_source,
             h.source_type
        Into v_Entity_Id,
             v_Sales_Center_Id,
             v_Customer_Id,
             v_Account_Id,
             v_Period_Id,
             v_Order_Type_Name,
             v_Order_Type_Id,
             v_Sys_Source,
             v_source_type
        From t_Pln_Order_Head h
       Where Order_Head_Id = p_Order_Head_Id
         For Update Nowait;
    Exception
      When Others Then
        p_Result := Substrb((v_Status || '检查失败，请检查订单状态;当前单据可能已被退回'),
                            1,
                            2000);
        Return;
    End;

    --获取工单与订单是否完全匹配参数
    Begin
      v_Pln_Wip_Ord_Match := Pkg_Bd.f_Get_Parameter_Value('PLN_WIP_ORD_MATCH',
                                                          v_Entity_Id);
    Exception
      When Others Then
        p_Result := '获取参数PLN_WIP_ORD_MATCH失败！' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;

    Begin
      Select *
        Into r_Order_Type
        From t_Pln_Order_Type t
       Where t.Order_Type_Id = v_Order_Type_Id;
    Exception
      When Others Then
        p_Result := '获取单据类型失败，单据类型ID:' || to_Char(v_Order_Type_Id);
        Return;
    End;
    --检查当前主体产地数量
    Select Count(*)
      Into n_Productng_Area_Count
      From t_Pln_Producing_Area p
     Where p.Entity_Id = v_Entity_Id;
    --主体产地数小于2个的主体,不检查产品产地
    If n_Productng_Area_Count > 1 Then
      --检查临时订单单据行,产品是否属于当前订单产地
      p_Chk_Order_Line_Mtl_Producing(p_Order_Head_Id, p_Result);
      If p_Result <> v_Success Then
        Raise v_Base_Exception;
      End If;
    End If;

    --对于 '需中心确认' 的单据检查 中心信用余额(以前是在前台处理,现在放到后台) 20081230 LUOHANG
    /*BEGIN
      --取中心是否分扣余款的标志
      IF PKG_SM.F_SM_GET_ENTITY_PARAM('PLN4_WOD_CUS_BLC_CHK',
                                      V_ENTITY_ID) = 'Y' THEN
        P_GET_CUSTOMER_BALANCE(V_CUSTOMER_ID,
                               N_DISCOUNT_TYPE_ID,
                               P_ORDER_HEAD_ID,
                               P_USER_CODE,
                               N_CUSTOMER_BALANCE,
                               'N' --扣除已送审未评审完毕的订单金额：“Y”是“N”否
                              ,
                               P_RESULT);

        IF P_RESULT = V_SUCCESS AND N_CUSTOMER_BALANCE < N_ORDER_AMOUNT THEN
          P_RESULT := '中心信用余额小于订单金额，不能评审！';
          RETURN;
        ELSIF P_RESULT <> V_SUCCESS THEN
          P_RESULT := '订单为需中心确认状态,取中心信用余款出错';
          RETURN;
        END IF;
      END IF;
    END;*/

    --检查本周
    p_Result := v_Success;
    Begin
      Select p.Period_Type
        Into v_Period_Type
        From t_Pln_Order_Period p
       Where p.Entity_Id = v_Entity_Id
         And p.Period_Id = v_Period_Id;
    Exception
      When Others Then
        p_Result := '获取周期类型失败,周期ID：' || v_Period_Id;
        Raise v_Base_Exception;
    End;
    Pkg_Pln_Pub.p_Check_Period(v_Period_Id,
                               v_Period_Type,
                               'Y',
                               'N',
                               'O',
                               p_Result);
    If Nvl(p_Result, v_Null) <> v_Success Then
      Raise v_Base_Exception;
    End If;
    -- add by zcc 增加凑整检查
    if r_Order_Type.Is_Count='Y' then
       begin
          for r_result in(
           select  l.item_id ,l.can_produce_qty ,l.entity_id
                     from t_pln_order_head h ,
                     t_pln_order_line l
                     where  h.order_head_id=p_Order_Head_Id
                            and h.order_head_id=l.order_head_id
                    ) loop
                    Pkg_Pln_Pub.p_Check_Item_Rounding(r_result.entity_id,
                                                      r_result.item_id,
                                                      r_result.can_produce_qty,
                                                      p_Result);
                      If p_Result != v_Success Then
                         v_Value :=v_Value|| p_Result||v_nl;
                         End If;
                    end loop;
        end;
        if v_value is not null then
          p_result :=v_value;
          raise v_Base_Exception;
          end if;
    end if;
    --end
    /*--检查中心
    PKG_PUB_F_P.P_CHK_CUSTOMER(V_ENTITY_ID,
                               V_ENTITY_ID,
                               V_CUSTOMER_ID,
                               V_Y,
                               V_Y,
                               V_CUSTOMER_CODE,
                               V_CUSTOMER_NAME,
                               P_RESULT);
    IF NVL(P_RESULT, V_NULL) <> V_SUCCESS THEN
      P_RESULT := SUBSTRB((V_RESULT || P_RESULT), 1, 2000);
      RETURN;
    END IF;*/

    --订单明细检查
    /*P_RESULT := V_ERROR;
    P_DETAIL_WEEK_ORDER(P_ORDER_HEAD_ID, 3, P_RESULT);
    IF NVL(P_RESULT, V_NULL) <> V_SUCCESS THEN
      P_RESULT := SUBSTRB((V_RESULT || P_RESULT), 1, 2000);
      RETURN;
    END IF;*/
    --检查订单行是否存在小于0或者未取整的行，并更新错误信息
    If Nvl(p_Result, v_Null) = v_Success Then
      Select Count(1)
        Into v_Count
        From t_Pln_Order_Line l
       Where l.Order_Head_Id = p_Order_Head_Id
         And Not
              (((Nvl(l.Apply_Qty, 0) + Nvl(l.Adjust_Qty, 0)) >= 0 And
              (Nvl(l.Apply_Qty, 0) + Nvl(l.Adjust_Qty, 0)) =
              Trunc(Nvl(l.Apply_Qty, 0) + Nvl(l.Adjust_Qty, 0))) Or
              (Nvl(l.Check_Qty, 0) >= 0 And
              Nvl(l.Check_Qty, 0) = Trunc(Nvl(l.Check_Qty, 0))) Or
              (Nvl(l.Can_Produce_Qty, 0) >= 0 And
              Nvl(l.Can_Produce_Qty, 0) = Trunc(Nvl(l.Can_Produce_Qty, 0))));
      If v_Count > 0 Then
        p_Result := '存在【' || To_Char(v_Count) || '】行数据， 数量小于零或没有取整。';
        Rollback;
        Update t_Pln_Order_Line l
           Set l.Status       = 'E',
               l.Check_Result = Substrb((Check_Result || '数量小于零或没有取整；'),
                                        1,
                                        240)
         Where l.Order_Head_Id = p_Order_Head_Id
           And Not (((Nvl(l.Apply_Qty, 0) + Nvl(l.Adjust_Qty, 0)) >= 0 And
                (Nvl(l.Apply_Qty, 0) + Nvl(l.Adjust_Qty, 0)) =
                Trunc(Nvl(l.Apply_Qty, 0) + Nvl(l.Adjust_Qty, 0))) Or
                (Nvl(l.Check_Qty, 0) >= 0 And
                Nvl(l.Check_Qty, 0) = Trunc(Nvl(l.Check_Qty, 0))) Or
                (Nvl(l.Can_Produce_Qty, 0) >= 0 And
                Nvl(l.Can_Produce_Qty, 0) =
                Trunc(Nvl(l.Can_Produce_Qty, 0))));
        Commit;
        Raise v_Base_Exception;
      End If;
    End If;
    --ADD BY LIZHEN 2015-04-09 工厂评审时，更新已排产数量
    --更新排产数量
    Update t_Pln_Order_Line
       Set Can_Produce_Qty = Check_Qty
     Where Order_Head_Id = p_Order_Head_Id;

    --临时订单评审完毕生成订单散件明细;
    p_Create_Order_Detail(p_Order_Head_Id, p_User_Code, p_Result);
    If Nvl(p_Result, v_Null) <> v_Success Then
      p_Result := Substrb(p_Result, 1, 2000);
      Raise v_Base_Exception;
    End If;

    /*Select Count(1)
      Into v_Count
      From t_Pln_Order_Line Pol
     Where Pol.Order_Head_Id = p_Order_Head_Id
       And (Select Count(1)
              From t_Pln_Order_Detail Pod
             Where Pod.Order_Line_Id = Pol.Order_Line_Id) = 0;
    If v_Count > 0 Then
      p_Result := '订单行存在无法生成明细行的数据，共有：' || To_Char(v_Count) || '行数据。';
      Raise v_Base_Exception;
    End If;*/

    --根据单据类型取延迟入库天数
    Begin
      Select Nvl(Defer_Supply_Days, 0)
        Into n_Defer_Supply_Days
        From t_Pln_Order_Type
       Where Order_Type_Id = v_Order_Type_Id
         And Entity_Id = v_Entity_Id;
    Exception
      When No_Data_Found Then
        n_Defer_Supply_Days := 0;
      When Others Then
        p_Result := '取主体参数PLN_ERP_NUM_RULE出错,出错代码位置PKG_PLN_ORDER.P_AFFIRM_ORDER';
        Return;
    End;

    --终止入库日期,加上延迟天数
    For i In (Select Order_Line_Id, Apply_Qty
                From t_Pln_Order_Line
               Where Order_Head_Id = p_Order_Head_Id) Loop
      If r_Order_Type.Source_Order_Type_Id <> 2 Then
        Update t_Pln_Order_Line
           Set Complete_Date = Can_Supply_Date
        --MODI BY LIZHEN 2015-01-01 最后入库日期不更新
        --,End_Supply_Date = End_Supply_Date + n_Defer_Supply_Days
         Where Order_Line_Id = i.Order_Line_Id;
      Else
        Update t_Pln_Order_Line l
           Set l.Complete_Date   = Can_Supply_Date,
               l.Can_Produce_Qty = l.Apply_Qty
         Where l.Order_Line_Id = i.Order_Line_Id;

        Update t_Pln_Order_Detail d
           Set d.Can_Produce_Qty = i.apply_qty
         Where d.Order_Line_Id = i.Order_Line_Id;
      End If;
    End Loop;

    --将订单明细状态改为“评审完毕”  根据参数取状态
    v_Oem_Uses := 'N'; /*PKG_SM.F_SM_GET_ENTITY_PARAM('OEM产地自动匹配订单',

                                                       V_ENTITY_ID);*/
    --add by lizhen 2015-07-29 更新计划订单发货齐套率
    Pkg_Pln_Pub.p_Count_Order_Neat_Set_Rate(p_Order_Head_Id => p_Order_Head_Id,
                                            p_Entity_Id     => v_Entity_Id,
                                            p_User_Code     => p_User_Code,
                                            p_Result        => p_Result);
    If p_Result <> v_Success Then
      Raise v_Base_Exception;
    End If;

    If Nvl(r_Order_Type.Inv_Chk_Auto_Share, v_False) = v_True Then
      For r_Inv_Affirm In (Select Oh.Order_Head_Id,
                                  Oh.Order_Number,
                                  Ol.Order_Line_Id,
                                  Ol.Item_Id,
                                  Ir.Affirm_Qty,
                                  Ir.Inventory_Id,
                                  Oh.Entity_Id
                             From t_Pln_Order_Head       Oh,
                                  t_Pln_Order_Line       Ol,
                                  t_Pln_Order_Inv_Review Ir,
                                  t_Pln_Order_Type       Ot
                            Where Oh.Order_Head_Id = Ol.Order_Head_Id
                              And Ir.Order_Head_Id = Ol.Order_Head_Id
                              And Ir.Order_Line_Id = Ol.Order_Line_Id
                              And Ir.Item_Id = Ol.Item_Id
                              And Ot.Order_Type_Id = Oh.Order_Type_Id
                              And Nvl(Ot.Inv_Chk_Auto_Share, v_False) =
                                  v_True
                              And Oh.Form_State In ('23') --评审完毕
                              And Oh.Order_Head_Id = p_Order_Head_Id
                              And Ir.Affirm_Qty > 0) Loop
        Pkg_Pln_Shares.p_Auto_Create_Share(p_Pln_Order_Line_Id => r_Inv_Affirm.Order_Line_Id, --订单行ID
                                           p_Inventory_Id      => r_Inv_Affirm.Inventory_Id, --仓库ID(财务仓)
                                           p_Trans_Sign_Flag   => 1, --生成发货计划方向，1：生成发货计划  -1：取消发货计划
                                           p_Trans_Share_Qty   => r_Inv_Affirm.Affirm_Qty, --分配数量（只传正数）
                                           p_Entity_Id         => r_Inv_Affirm.Entity_Id, --主体ID
                                           p_Pln_Wip_Ord_Match => v_Pln_Wip_Ord_Match, --工单与订单新匹配模式
                                           p_User_Code         => p_User_Code,
                                           p_Result            => p_Result,
                                           p_Inv_Affirm_Flag   => 'Y' --库存评审标志
                                           );
        If p_Result <> v_Success Then
          Raise v_Base_Exception;
        End If;
      End Loop;
    End If;

    --add by xuhongjiu 2015-12-5
    If nvl(v_Sys_Source,'_') <> 'CIMS' And nvl(v_source_type,'_') <> '提货订单' Then
    --订单评审完毕后，根据最终的评审数量计算出与申请数量的款项差额
    --进行客户项的加锁款项（大于申请数量）或者解锁款项（小于申请数量）。
      -- 金额 =（单价*数量*（100-折扣率-月返））/100
    If nvl(r_Order_Type.Chk_Cusg_Amount_Flag,'_') = pkg_pln_pub.V_LOCK_AMOUNT_FLAG_S Then
      For r_Check_Amount In (Select --20170517 hejy3 按行营销大类
                                    --bi.sales_main_type,
                                    nvl(l.sales_main_type, bi.sales_main_type) sales_main_type,
                                    Sum(Round((nvl(l.apply_qty,0) - nvl(l.can_produce_qty,0) - nvl(l.inv_affirm_qty,0)) *
                                    nvl(l.item_price,0) *
                                    (100 -  nvl(l.discount_rate,0) - nvl(l.ordered_discount_rate,0))/100,2)) apply_amount,
                                    Sum(Round((nvl(l.apply_qty,0) - nvl(l.can_produce_qty,0) - nvl(l.inv_affirm_qty,0)) *
                                    nvl(l.item_price,0) *
                                    nvl(l.discount_rate,0)/100,2)) discount_Amount
                               From cims.t_Pln_Order_Line l,cims.t_bd_item bi
                              Where l.item_code = bi.item_code
                                And l.entity_id = bi.entity_id
                                And l.Order_Head_Id = p_Order_Head_Id
                                --20170517 hejy3 按行营销大类
                             Group By nvl(l.sales_main_type, bi.sales_main_type)--bi.sales_main_type
                             ) Loop
         --申请数量大于评审数量，则要把多锁的款项释放
         If nvl(r_Check_Amount.Apply_Amount,0) > 0 Then
           /*Pkg_Credit_Account_Control.Prc_Credit_Order_Bill(p_Entity_Id       => v_Entity_Id,
                                                             p_Action_Type     => 2, --释放到款
                                                             p_Settlement_Sum  => Nvl(r_Check_Amount.Apply_Amount,
                                                                                      0),
                                                             p_Discount_Sum    => Nvl(r_Check_Amount.Discount_Amount,
                                                                                      0),
                                                             p_Sales_Main_Type => r_Check_Amount.Sales_Main_Type,
                                                             p_Account_Id      => v_Account_Id,
                                                             p_Customer_Id     => v_Customer_Id,
                                                             p_Proj_Number     => Null,
                                                             p_Order_Id        => p_Order_Head_Id,
                                                             --p_Order_Type      => v_Order_Type_Name,
                                                             p_Order_Type => r_Order_Type.Order_Type_Code, --20160912 hejy3 传入订单类型编码
                                                             p_Username        => p_User_Code,
                                                             p_Result          => v_Count,
                                                             p_Err_Msg         => p_Result);
            If p_Result <> v_Success Then
              p_Result := '检查并解锁资金失败，产品大类：' ||
                          r_Check_Amount.Sales_Main_Type || v_Nl ||
                          p_Result;
              Raise v_Base_Exception;
            End If;*/
            pkg_pln_pub.P_CUSTOMER_AMOUNT_PROCESS(IN_ENTITY_ID       => v_Entity_Id,
                                                  IN_ORDER_TYPE_ID   => v_Order_Type_Id,
                                                  IN_ORDER_TYPE_CODE => v_Order_Type_Name,
                                                  IN_CUSTOMER_ID     => v_Customer_Id,
                                                  IN_ACCOUNT_ID      => v_Account_Id,
                                                  IN_SALES_MAIN_TYPE => r_Check_Amount.Sales_Main_Type,
                                                  IN_ACTION_TYPE     => 2,
                                                  IN_SOURCE_TYPE     => '01',
                                                  IN_ORDER_ID        => p_Order_Head_Id,
                                                  IN_PROJ_NUMBER     => null,
                                                  IN_DISCOUNT_TYPE   => pkg_pln_pub.v_Discount_Type_Common,
                                                  IN_AMOUNT          => Nvl(r_Check_Amount.Apply_Amount, 0),
                                                  IN_DIS_AMOUNT      => Nvl(r_Check_Amount.Discount_Amount, 0),
                                                  IN_RECORD_ERR      => 'N',
                                                  IN_USER_CODE       => p_User_Code,
                                                  OUT_RESULT         => p_Result);
           if p_Result <> v_Success then
             p_Result := '接单数量小于申请数量，处理客户款项失败(锁款方式:'||r_Order_Type.Chk_Cusg_Amount_Flag||')！' || v_Nl || p_Result;
             raise v_Base_Exception;
           end if;
         End If;
         --申请数量小于评审数量，则要增加锁款
         If nvl(r_Check_Amount.Apply_Amount,0) < 0 Then
            /*Pkg_Credit_Account_Control.Prc_Credit_Order_Bill(p_Entity_Id       => v_Entity_Id,
                                                               p_Action_Type     => 1,
                                                               p_Settlement_Sum  => abs(Nvl(r_Check_Amount.apply_Amount,
                                                                                        0)),
                                                               p_Discount_Sum    => abs(Nvl(r_Check_Amount.Discount_Amount,
                                                                                        0)),
                                                               p_Sales_Main_Type => r_Check_Amount.Sales_Main_Type,
                                                               p_Account_Id      => v_Account_Id,
                                                               p_Customer_Id     => v_Customer_Id,
                                                               p_Proj_Number     => Null,
                                                               p_Order_Id        => v_Customer_Id,
                                                               --p_Order_Type      => v_Order_Type_Name,
                                                               P_ORDER_TYPE => r_Order_Type.Order_Type_Code, --20160912 hejy3 传入订单类型编码
                                                               p_Username        => p_User_Code,
                                                               p_Result          => v_Count,
                                                               p_Err_Msg         => p_Result);
              If p_Result <> v_Success Then
                p_Result := '检查并锁定资金失败，产品大类：' || r_Check_Amount.Sales_Main_Type || v_Nl ||
                            p_Result;
                Raise v_Base_Exception;
              End If;*/
           pkg_pln_pub.P_CUSTOMER_AMOUNT_PROCESS(IN_ENTITY_ID       => v_Entity_Id,
                                                  IN_ORDER_TYPE_ID   => v_Order_Type_Id,
                                                  IN_ORDER_TYPE_CODE => v_Order_Type_Name,
                                                  IN_CUSTOMER_ID     => v_Customer_Id,
                                                  IN_ACCOUNT_ID      => v_Account_Id,
                                                  IN_SALES_MAIN_TYPE => r_Check_Amount.Sales_Main_Type,
                                                  IN_ACTION_TYPE     => 1,
                                                  IN_SOURCE_TYPE     => '01',
                                                  IN_ORDER_ID        => p_Order_Head_Id,
                                                  IN_PROJ_NUMBER     => null,
                                                  IN_DISCOUNT_TYPE   => pkg_pln_pub.v_Discount_Type_Common,
                                                  IN_AMOUNT          => Nvl(r_Check_Amount.Apply_Amount, 0),
                                                  IN_DIS_AMOUNT      => Nvl(r_Check_Amount.Discount_Amount, 0),
                                                  IN_RECORD_ERR      => 'N',
                                                  IN_USER_CODE       => p_User_Code,
                                                  OUT_RESULT         => p_Result);
           if p_Result <> v_Success then
             p_Result := '接单数量大于申请数量，处理客户款项失败(锁款方式:'||r_Order_Type.Chk_Cusg_Amount_Flag||')！' || v_Nl || p_Result;
             raise v_Base_Exception;
           end if;
         End If;
      End Loop;
    End If;
    End If;

    --add by  lizhen 2016-01-14 检查产品是否为虚拟生产,在订单评审完毕后再更新一次虚拟生产标志
    Update t_Pln_Order_Line Pol
       Set Pol.Synt_Producing_Area_Id =
           (Select Pi.Po_Area_Id
              From v_inv_producting_item_list  Pi
             Where Pi.Entity_Id = Pol.Entity_Id
               And Pi.Item_Id = Pol.Item_Id
               And Trunc(Sysdate) Between Pi.Begin_Date And
                   Trunc(Nvl(Pi.End_Date, Sysdate))),
           Pol.Synt_Order_Flag        = Nvl((Select 'Y'
                                              From v_inv_producting_item_list Pi
                                             Where Pi.Entity_Id =
                                                   Pol.Entity_Id
                                               And Pi.Item_Id = Pol.Item_Id
                                               And Trunc(Sysdate) Between
                                                   Pi.Begin_Date And
                                                   Trunc(Nvl(Pi.End_Date,
                                                             Sysdate))),
                                            'N')
     Where Pol.Order_Head_Id = p_Order_Head_Id;

  Exception
    When v_Base_Exception Then
      p_Result := p_Result;
      Rollback;
    When Others Then
      p_Result := p_Result || v_Nl || Sqlerrm;
      Rollback;
  End;

  -----------------------------------------------------------------------------
  ---- AUTHOR  : NICRO.LI
  -- CREATED : 2014-07-16 11:05:52
  -- PURPOSE : 执行订单操作
  -----------------------------------------------------------------------------
  Procedure p_Check_Next_State_Complete(p_Order_Head_Id    In Number, ----订单ID
                                        p_Operation_Action In Varchar2, --当前单据动作
                                        p_Next_State       In Varchar2, --下一状态值
                                        p_User_Code        In Varchar2, ----用户编码
                                        p_Result           In Out Varchar2 --返回结果：成功返回"SUCCESS"，失败返回原因
                                        ) Is
    v_Next_State_Code Varchar2(100);
  Begin
    p_Result := v_Success;
    Begin
      Select s.Status_Code
        Into v_Next_State_Code
        From t_Pln_Flow_Type_Status s
       Where s.Status_Id = p_Next_State;
    Exception
      When Others Then
        p_Result := '检查下一状态编码失败。' || v_Nl || Sqlerrm;
    End;
    If p_Result = v_Success And v_Next_State_Code = v_State_Review_Complete Then
      p_Complete_Review_Order(p_Order_Head_Id    => p_Order_Head_Id, ----订单ID
                              p_Operation_Action => p_Operation_Action, --当前单据动作
                              p_User_Code        => p_User_Code, ----用户编码
                              p_Result           => p_Result --返回结果：成功返回"SUCCESS"，失败返回原因
                              );
    End If;
  Exception
    When Others Then
      p_Result := '检查下一状态编码失败。' || v_Nl || Sqlerrm;
  End;

  -----------------------------------------------------------------------------
  -- AUTHOR  : NICRO.LI
  -- CREATED : 2014-07-14 11:05:52
  -- PURPOSE : 订单送审
  -- 增加紧急程度的数量限制（紧急(1)：不能超过4个；急(2)：不能超过6个）
  -----------------------------------------------------------------------------
  Procedure p_Submit_Order(p_Order_Head_Id    In Number, ----订单ID
                           p_Operation_Action In Varchar2, --当前单据动作
                           p_User_Code        In Varchar2, ----用户编码
                           p_Result           Out Varchar2 --返回结果：成功返回"SUCCESS"，失败返回原因
                           ) Is

    r_Order_Type           t_Pln_Order_Type%Rowtype;
    v_Stock_Qty            Number := 0; --产品全国库存
    v_Sale_Qty             Number := 0; --产品30日销售
    v_Order_Amount         Number := 0; --订单金额
    v_Message              Varchar2(3000); --辅助结果
    v_Status               Varchar2(50); --辅助状态
    v_String               Varchar2(500); --辅助信息
    v_Week_Id              Number;
    v_Period_Code          Varchar2(100);
    v_Entity_Id            Number;
    v_Material_Range_Flag  Varchar2(1); --使用定制机标志
    v_Source_Order_Type_Id Number; --订单源类型
    v_Chk_Cusg_Amount_Flag Varchar2(1); --需检查客户金额标志
    v_Order_Type_Id        Number; --订单类型
    v_Order_Type_Name      Varchar2(100);
    v_Order_State          Varchar2(100);
    v_Cnt                  Number; --计数

    v_Next_Excute_Step Number;
    v_Next_Action      Varchar2(100);
    v_Nextauto_Excute  Varchar2(100);
    v_Next_State       Varchar2(100);

    v_Discount_Type_Id Number Not Null := -1; --折扣类型ID

    v_Producing_Area_Id   Number := -1; --产地ID   --去掉NOT NULL 因为样机订单可以为空
    v_Producing_Area_Code Varchar2(20) := v_Null; --产地名称
    v_On_Make_Qty         Number; --未入库

    v_Customer_Id          Number;
    v_Customer_Code        Varchar2(40);
    v_Customer_Name        Varchar2(100);
    v_account_id           Number;  --add by xuhongjiu 锁款用到账户
    v_Sales_Center_Id      Number;
    v_Sales_Center_Name    Varchar2(240);
    v_Hq_Cen_Flag          Varchar2(1);
    v_Hq_Order_Chk_Flag    Varchar2(1) := 'N';
    n_Productng_Area_Count Number; --当前主体的产地个数
    --V_CONTROL_BY_WEEK        VARCHAR2(1); --当前订单是否按周控制报送
    v_Total_Order_Type     Varchar2(60); --当前订单的汇总类型
    v_Collect_Order_Status Varchar2(40); --当前订单的汇总订单的状态
    v_Count                Number;
    v_Sourdes              Number;

    v_Splite_Producing_Aera  Varchar2(2); --是否需要拆分产地
    n_Ord_Line_Pro_Area_Id   Number; --单据行产地ID
    v_Ord_Line_Pro_Area_Code Varchar2(60); --单据行产地编码
    v_Ord_Line_Pro_Area_Name Varchar2(255);

    v_Period_Type  Varchar2(20); --周期类型
    v_Send_By_Type Varchar2(15); --报送类型
    v_Max_Rate     Varchar2(20);
    v_Min_Rate     Varchar2(20);

    n_Apply_Qty   Number;
    n_Week_Minqty Number;
    v_Temp        Number;
    v_Temstr      Varchar2(4000);
    v_Source_Sys  Varchar2(30);
    v_Source_Type Varchar2(60);
    --v_Item_Main_Type Varchar2(10); --大类
    --v_Item_Sub_Type Varchar2(10); -- 小类
    v_Item_Main_Type Varchar2(32);
    v_Item_Sub_Type Varchar2(32);
    v_Item_Main_Type_Filter varchar2(10); --营销大类参数
    v_Item_Sub_Type_Filter  varchar2(10); -- 营销小类参数
    v_sys_parameter         varchar2(10);--系统参数
    v_Account_Sys_Flag      Varchar2(10);
    v_item_cost        number;
    v_entity_flag      number;--用于判断洗衣机

    --add by fenggq 2015-03-10 校验产品生命周期
    --VN_ITEM_COUNT NUMBER; --生命周期内不能送审产品的数量
    VS_ITEM_LIFE_CYCLE VARCHAR2(10);
    VS_CHECK_RESULT VARCHAR2(4000);
    v_main_param  varchar2(32);
    v_Item_Cycle_Order_Phase  Varchar2(100);
    v_Update_Sql       varchar2(8000);
    v_Sys_Source       Varchar2(50);  --add by xuhongjiu 用于判断如果是提货订单过来的就不锁款了
    v_Item_Code_List   Varchar2(2000);
    --end by fenggq
    v_Can_Change_Period VARCHAR2(2);
    v_Pln_Capacity_Modle          Varchar2(32);  --add by lizhen 2017-05-05

    V_DOWN_PAY_RATE NUMBER; --订金比例
  Begin
    p_Result  := v_Success;
    v_Message := Substrb(('订单送审' || '失败' || v_Nl), 1, 50);
    v_Status  := Substrb((v_Nl || '初始化' || '：'), 1, 50);
    v_String  := Substrb((v_Nl || v_Nl || '订单ID：' ||
                         To_Char(p_Order_Head_Id) || v_Nl || '用户编码：' ||
                         To_Char(p_User_Code) || v_Nl),
                         1,
                         500);

    v_Status := Substrb((v_Nl || '输入参数检查' || '：'), 1, 50);
    If p_Order_Head_Id Is Null Or p_User_Code Is Null Then
      p_Result := Substrb((v_Message || v_Status || '部分参数为空或错误' || v_String),
                          1,
                          2000);
      Raise v_Base_Exception;
    End If;

    v_Status := Substrb((v_Nl || '检查订单状态，并读锁定' || '：'), 1, 50);
    Begin
      Select h.Period_Id,
             h.Period_Code,
             h.Entity_Id,
             h.Customer_Id,
             h.account_id,
             h.Order_Type_Id,
             h.Order_Type_Name,
             h.Producing_Area_Id,
             h.Producing_Area_Code,
             p.Period_Type,
             h.Sys_Source,
             h.Source_Type,
             h.Form_State,
             h.Sales_Center_Id,
             h.Sales_Center_Name,
             h.sales_main_type,
             h.sales_sub_type,
             h.sys_source
        Into v_Week_Id,
             v_Period_Code,
             v_Entity_Id,
             v_Customer_Id,
             v_account_id,
             v_Order_Type_Id,
             v_Order_Type_Name,
             v_Producing_Area_Id,
             v_Producing_Area_Code,
             v_Period_Type,
             v_Source_Sys,
             v_Source_Type,
             v_Order_State,
             v_Sales_Center_Id,
             v_Sales_Center_Name,
             v_Item_Main_Type,
             v_Item_Sub_Type,
             v_Sys_Source
        From t_Pln_Order_Head h, t_Pln_Order_Period p
       Where Order_Head_Id = p_Order_Head_Id
         And p.Period_Id = h.Period_Id
         --And h.Form_State In ('19', '303', '415') --('制单', '退回', '驳回')
         For Update Nowait;
    Exception
      When Others Then
        p_Result := Substrb((v_Message || v_Status || '检查失败' || v_Nl ||
                            '要执行此操作，请检查该订单为录入或退回状态' || v_String),
                            1,
                            2000);
        Return;
    End;
    --ADD BY LIZHEN 2015-01-31 获取单据类型信息
    Begin
      Select *
        Into r_Order_Type
        From t_Pln_Order_Type Ot
       Where Ot.Entity_Id = v_Entity_Id
         And Ot.Order_Type_Id = v_Order_Type_Id;
    Exception
      When Others Then
        p_Result := '获取单据类型信息失败。' || v_Nl || '单据类型ID：' ||
                    To_Char(v_Order_Type_Id) || v_Nl || Sqlerrm;
        Return;
    End;
    --add by lizhen 2017-05-05
    --获取系统参数产能可视模式参数
    Begin
      v_Pln_Capacity_Modle := Pkg_Bd.f_Get_Parameter_Value('PLN_CAPACITY_MODEL',
                                                           v_Entity_Id);
    Exception
      When Others Then
        p_Result := '获取产能可视模式参数PLN_CAPACITY_MODEL参数失败！' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;
    --add by lizhen 2015-01-31 返修订单类型检查产品在ERP组织是否存在
    If r_Order_Type.Source_Order_Type_Id = 2  Then
      v_Message := Null;
      /*For r In (Select Ol.Item_Code, Ol.Order_Line_Id, Ppa.Mrp_Org_Id
                  From Cims.t_Pln_Order_Line     Ol,
                       Cims.t_Pln_Order_Head     Oh,
                       Cims.t_Pln_Producing_Area Ppa
                 Where Oh.Order_Head_Id = Ol.Order_Head_Id
                   And Oh.Producing_Area_Id = Ppa.Producing_Area_Id
                   And Oh.Order_Head_Id = p_Order_Head_Id
                   And Not Exists
                 (Select 1
                          From Apps.Mtl_System_Items@Mdims2mderp m
                         Where m.Organization_Id = Ppa.Mrp_Org_Id
                           And m.Segment1 = Ol.Item_Code
                           And Nvl(m.Customer_Order_Enabled_Flag, 'N') = 'Y'
                           And Nvl(m.Customer_Order_Flag, 'N') = 'Y'
                           And Nvl(m.Shippable_Item_Flag, 'N') = 'Y'
                           And Nvl(m.So_Transactions_Flag, 'N') = 'Y'
                           And Nvl(m.Returnable_Flag, 'N') = 'Y'
                           And m.Atp_Components_Flag = 'N'
                           And m.Atp_Flag = 'N'
                           and m.Inventory_Item_Status_code !='Inactive')) Loop

        v_Message := v_Message || '  ' || r.item_code;
      End Loop;*/
      If v_Message Is Not Null Then
        p_Result := '检查返修订单产地对应的ERP组织不存以下产品。' || v_Nl ||
          '产品编码：' || v_Message || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
        --modi by lizhen 2017-05-05 改用异常抛出，不做直接返回
        --Return;
      End If;
      --返修订单类型检查物料成本
      --MODI BY LIZHEN 2015-04-23 应IT转业务要求，在返修、工厂增补订单时只检查ERP产品状态，不检查标准成本
      /*For Rw In (Select Ol.Item_Code, Ol.Order_Line_Id, Ppa.Mrp_Org_Id
                   From Cims.t_Pln_Order_Line     Ol,
                        Cims.t_Pln_Order_Head     Oh,
                        Cims.t_Pln_Producing_Area Ppa
                  Where Oh.Order_Head_Id = Ol.Order_Head_Id
                    And Oh.Producing_Area_Id = Ppa.Producing_Area_Id
                    And Oh.Order_Head_Id = p_Order_Head_Id) Loop
        Select Nvl(Max(Cic.Item_Cost), 0)
          Into v_Item_Cost
          From Apps.Cst_Item_Costs@Mdims2mderp   Cic, --ERP产品成本表
               Apps.Mtl_System_Items@Mdims2mderp Mtl --ERP产品表
         Where Cic.Inventory_Item_Id = Mtl.Inventory_Item_Id
           And Cic.Organization_Id = Mtl.Organization_Id
           And Cic.Organization_Id = Rw.Mrp_Org_Id
           And Mtl.Segment1 = Rw.Item_Code;
        If v_Item_Cost = 0 Then
          v_Message := v_Message || '  ' || Rw.Item_Code;
        End If;
        v_Item_Cost := Null;
      End Loop;
      If v_Message Is Not Null Then
        p_Result := '以下物料未维护冻结成本：' || v_Nl || '产品编码：' || v_Message || v_Nl ||
                    Sqlerrm;
        Return;
      End If;*/
    End If;

    Begin
      v_Account_Sys_Flag := Pkg_Bd.f_Get_Parameter_Value('ACCOUNT_SYS',
                                                              v_Entity_Id);
    Exception
      When Others Then
        p_Result := '获取ACCOUNT_SYS参数失败' || v_Nl ||
                    Sqlerrm;
        Raise v_Base_Exception;
    End;
    Begin
      v_Item_Main_Type_Filter := Pkg_Bd.f_Get_Parameter_Value('ITEM_SALES_MAIN_TYPE_FILTER',
                                                              v_Entity_Id);
    Exception
      When Others Then
        p_Result := '获取ITEM_SALES_MAIN_TYPE_FILTER参数失败' || v_Nl ||
                    Sqlerrm;
        Raise v_Base_Exception;
    End;
    Begin
      v_Item_Sub_Type_Filter := Pkg_Bd.f_Get_Parameter_Value('ITEM_SALES_SUB_TYPE_FILTER',
                                                             v_Entity_Id);
    Exception
      When Others Then
        p_Result := '获取ITEM_SALES_SUB_TYPE_FILTER参数失败' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;
    --提货汇总参数
    --add by zcc 2015-7-29
    begin
        v_main_param := pkg_bd.F_GET_PARAMETER_VALUE('PLN_IS_MERGE_LG_ORDER',
                                                  v_Entity_Id);
    exception
      when others then
        p_Result := '获取提货转计划汇总参数失败' || v_nl || sqlerrm;
        raise v_Base_Exception;
    end;

    --20170517 hejy3 更新订单行的营销大类和营销小类
    update t_pln_order_line l
       set (l.sales_main_type, l.sales_sub_type) =
           (select bi.sales_main_type, bi.sales_sub_type
              from t_bd_item bi
             where bi.item_id = l.item_id)
     where l.order_head_id = p_Order_Head_Id;

     begin
     -- 2015-10-22
     select e.entity_id into v_entity_flag
     from up_codelist u,up_codelist_entity e
     where e.codelist_id=u.id
     and u.codetype='plnMergeEntity'
     and e.entity_id=v_Entity_Id;
     Exception
       when others then
         null;
     end;
    if v_entity_flag is null then
    If v_Item_Main_Type_Filter = 'Y' Then
      Select Count(1)
        Into v_Count
        From t_Pln_Order_Line l, t_Bd_Item Bi
       Where l.Order_Head_Id = p_Order_Head_Id
         And Bi.Item_Id = l.Item_Id
         And Bi.Entity_Id = v_Entity_Id
         --And Bi.Sales_Main_Type = v_Item_Main_Type;
         -- 张开安 2018-10-15 T+3总部临时订单的品类可以有多个值
         And instr(v_Item_Main_Type, Bi.Sales_Main_Type) > 0;
      If Nvl(v_Count, 0) = 0 Then
        p_Result := '计划订单头的大类和产品基础数据的大类不匹配';
        Raise v_Base_Exception;
        v_Count := 0;
      End If;
    End If;

    If v_Item_Sub_Type_Filter = 'Y' Then
      Select Count(1)
        Into v_Count
        From t_Pln_Order_Line l, t_Bd_Item Bi
       Where l.Order_Head_Id = p_Order_Head_Id
         And Bi.Item_Id = l.Item_Id
         And Bi.Entity_Id = v_Entity_Id
         --And Bi.Sales_Sub_Type = v_Item_Sub_Type;
         And instr(v_Item_Sub_Type, Bi.Sales_Sub_Type) > 0;
      If Nvl(v_Count, 0) = 0 Then
        p_Result := '计划订单头的小类和产品基础数据的小类不匹配';
        Raise v_Base_Exception;
        v_Count := 0;
      End If;
    End If;
   end if;
    --检查本周
    If v_Order_Type_Name <> '客户订单' Then
      v_Status := Substrb((v_Nl || '检查本周' || '：'), 1, 50);
      Pkg_Pln_Pub.p_Check_Period(v_Week_Id,
                                 v_Period_Type,
                                 'Y',
                                 'N',
                                 'O',
                                 p_Result);
      If Nvl(p_Result, v_Null) <> v_Success Then
        p_Result := Substrb((v_Status || p_Result), 1, 2000);
        Raise v_Base_Exception;
        --modi by lizhen 2017-05-05 改用异常抛出，不做直接返回
        --Return;
      End If;
    End If;

    Begin
      Select Decode(p.Period_Type, '月', p.Begin_Date, Null),
             Decode(p.Period_Type, '月', p.End_Date, Null),
             Decode(p.Period_Type, '周', p.Begin_Date, Decode(p.Period_Type, 'T+3周期', p.Begin_Date, Null)),
             Decode(p.Period_Type, '周', p.End_Date, Decode(p.Period_Type, 'T+3周期', p.end_date, Null))
        Into v_Month_Begin_Date,
             v_Month_End_Date,
             v_Week_Begin_Date,
             v_Week_End_Date
        From t_Pln_Order_Period p
       Where p.Entity_Id = v_Entity_Id
         And p.Period_Id = v_Week_Id;
    Exception
      When Others Then
        p_Result := '获取周期开始日期，终止日期失败！';
        Raise v_Base_Exception;
        --modi by lizhen 2017-05-05 改用异常抛出，不做直接返回
        --Return;
    End;

    --检查订单是否只有订单头，无订单行。无订单行的订单不允许送审
    Select Count(1)
      Into v_Count
      From t_Pln_Order_Line Ol
     Where Ol.Order_Head_Id = p_Order_Head_Id
       And Ol.Entity_Id = v_Entity_Id;
    If v_Count = 0 Then
      p_Result := '无订单行数据，送审失败！';
      Raise v_Base_Exception;
      --modi by lizhen 2017-05-05 改用异常抛出，不做直接返回
      --Return;
    End If;

    --检查当前订单类型是否为:一个周期只能送审一次,
    --如果是,则检查当前周期的订单是否还能送审

    --取是否按周控制标志
    v_Message := '取是否按周控制标志';
    Select t.Send_By_Type
      Into v_Send_By_Type
      From t_Pln_Order_Type t, Up_Codelist Uc
     Where t.Order_Type_Id = v_Order_Type_Id
       And Uc.Codetype = 'plnSendByType'
       And Uc.Code_Value = t.Send_By_Type
       And t.Entity_Id = v_Entity_Id;

    /*
    0 按周报送  plnSendByType
    1 按月报送  plnSendByType
    2 按月多次报送  plnSendByType
    3 按年报送  plnSendByType
    4 按周多次报送  plnSendByType

    6  按T+N周期报送
    7  按T+N周期多次报送

    */
    If v_Send_By_Type Not In ('2', '4', '7') Then
      --增加按月报送检查
      Select Count(1)
        Into v_Count
        From t_Pln_Order_Head h
       Where h.Form_State Not In ('19', '303', '304', '305', '248') --制单,已退回，已作废,已关闭，已取消
         And h.Order_Type_Id = v_Order_Type_Id
         And h.Sales_Center_Id = v_Sales_Center_Id
         And h.Period_Id = v_Week_Id
         And h.Order_Head_Id <> p_Order_Head_Id
         --ADD BY LIHZNE 2015-02-02 增加大小类控制。
         And (v_Account_Sys_Flag = v_False Or (v_Account_Sys_Flag = v_True And v_Customer_Id = h.customer_id))
         And (v_Item_Main_Type_Filter = v_False Or
         (v_Item_Main_Type_Filter = v_True And v_Item_Main_Type = h.Sales_Main_Type))
         And (v_Item_Sub_Type_Filter = v_False Or
         (v_Item_Sub_Type_Filter = v_True And v_Item_Sub_Type = h.Sales_Sub_Type));
      If v_Count > 0 Then
        p_Result := '中心名称:' || v_Sales_Center_Name || '，周期编码：' ||
                    v_Period_Code || '，在本周期存在已送审后的订单，当前周期不可多次报送订单。';
        Raise v_Base_Exception;
        --modi by lizhen 2017-05-05 改用异常抛出，不做直接返回
        --Return;
      End If;

      --检查汇总订单是否存在未评审完成
      Select Count(1)
        Into v_Count
        From t_Pln_Order_Collect_Head Och
       Where Och.Order_Type_Id = v_Order_Type_Id
         And Och.Period_Id = v_Week_Id
         --ADD BY LIHZNE 2015-02-02 增加大小类控制。
         And (v_Item_Main_Type_Filter = v_False Or
         (v_Item_Main_Type_Filter = v_True And v_Item_Main_Type = Och.Sales_Main_Type))
         And (v_Item_Sub_Type_Filter = v_False Or
         (v_Item_Sub_Type_Filter = v_True And v_Item_Sub_Type = Och.Sales_Sub_Type))
         And Och.Form_State Not In ('248', '32', '31');  --已作废、已排产、已完成
      If v_Count > 0 Then
        p_Result := '中心名称:' || v_Sales_Center_Name || '，周期编码：' ||
                      v_Period_Code || '，本周期存在未评审完成的汇总订单，请联系总部计划人员处理。';
        Return;
      End If;
    Else
      --多次报送的订单在送审时，重新更新批次ID
      Update t_Pln_Order_Head Poh
         Set Poh.Batch_Id =
             (Select Count(1) + 1
                From t_Pln_Order_Collect_Head Och
               Where Och.Order_Type_Id = Poh.Order_Type_Id
                 And Och.Period_Id = Poh.Period_Id
                 --ADD BY LIHZNE 2015-02-02 增加大小类控制。
                 And (v_Item_Main_Type_Filter = v_False Or
                 (v_Item_Main_Type_Filter = v_True And Poh.Sales_Main_Type = Och.Sales_Main_Type))
                 And (v_Item_Sub_Type_Filter = v_False Or
                 (v_Item_Sub_Type_Filter = v_True And Poh.Sales_Sub_Type = Och.Sales_Sub_Type))
                 )
       Where Poh.Order_Head_Id = p_Order_Head_Id;
    End If;

    --获取订单需检查信息
    v_Message := '获取订单需检查信息';
    Begin
      Select Nvl(t.Is_Product_Area_Split, 'N'),
             Nvl(t.Is_Material_Range_Flag, 'N'),
             Nvl(t.Chk_Cusg_Amount_Flag, 'N'),
             t.Source_Order_Type_Id
        Into v_Splite_Producing_Aera,
             v_Material_Range_Flag,
             v_Chk_Cusg_Amount_Flag,
             v_Source_Order_Type_Id
        From t_Pln_Order_Type t
       Where t.Order_Type_Id = v_Order_Type_Id
         And t.Entity_Id = v_Entity_Id
         And Trunc(Sysdate) Between t.Begin_Date And
             Trunc(Nvl(t.End_Date, Sysdate));
    Exception
      When Others Then
        p_Result := '检查单据类型失败，单据类型名称:' || v_Order_Type_Name || v_Nl ||
                    '请检查单据类型是否已终止!';
        Raise v_Base_Exception;
        --modi by lizhen 2017-05-05 改用异常抛出，不做直接返回
        --Return;
    End;

    --订单行，同一产品、同一产地只允许报送送审时，检查
    Begin
      Select Count(1)
        Into v_Count
        From t_Pln_Order_Line Pol
       Where Pol.Order_Head_Id = p_Order_Head_Id Having Count(1) > 1
       Group By Pol.Item_Id, Pol.Producing_Area_Id;
      If v_count > 1 Then
          p_Result := '订单行，存在同一产品、同一产地报送了多次，送审失败！订单头ID：' || To_Char(p_Order_Head_Id);
        Raise v_Base_Exception;
        --modi by lizhen 2017-05-05 改用异常抛出，不做直接返回
        --Return;
      End If;
    Exception
      When Others Then
        null;
    End;

    Begin
      Select Count(1)
        Into v_Count
        From t_Pln_Order_Line Pol,t_pln_order_head poh,t_pln_order_type pot
       Where Pol.Order_Head_Id = p_Order_Head_Id
         And pol.order_head_id = poh.order_head_id
         And poh.order_type_id = pot.order_type_id
         And Nvl(pot.is_price_check, v_False) = v_True
         And pot.source_order_type_id != 2
         And pol.item_price Is Null;
      If v_count > 0 Then
          p_Result := '订单行存在【' || To_Char(v_Count) || '】行价格为空的产品数据。订单头ID：' || To_Char(p_Order_Head_Id);
        Raise v_Base_Exception;
        --modi by lizhen 2017-05-05 改用异常抛出，不做直接返回
        --Return;
      End If;
    Exception
      When Others Then
        Null;
    End;

    --add by lizhen 2016-07-13 检查行产品信息是否存在与产品信息表不一致的
    Begin
      Select Listagg(Pol.Item_Code, ',') Within Group(Order By Pol.Order_Head_Id)
        Into v_Item_Code_List
        From t_Pln_Order_Line Pol
       Where Not Exists (Select 1
                From t_Bd_Item Tbi
               Where Tbi.Item_Id = Pol.Item_Id
                 And Tbi.Item_Code = Pol.Item_Code
                 And Tbi.Entity_Id = Pol.Entity_Id)
         And Pol.Order_Head_Id = p_Order_Head_Id;
    Exception
      When No_Data_Found Then
        v_Item_Code_List := Null;
      When Others Then
        p_Result := '检查产品信息一致性失败。' || v_Nl ||
          '计划订单头ID：' || To_Char(p_Order_Head_Id) || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
        --modi by lizhen 2017-05-05 改用异常抛出，不做直接返回
        --Return;
    End;
    If v_Item_Code_List Is Not Null Then
      p_Result := '检查产品信息一致性失败，请检查产品表产品编码、产品ID是否与提货订单行产品编码、产品ID一致！'
        || v_Nl || '产品编码：' || v_Item_Code_List;
      Raise v_Base_Exception;
      --modi by lizhen 2017-05-05 改用异常抛出，不做直接返回
      --Return;
    End If;

    --判断当前订单是否需要拆分产地
    v_Message := '当前订单是否需要拆分产地,周排产订单不做产地重新分配';
    Select Count(0)
      Into v_Sourdes
      From t_Pln_Order_Type Ty
     Where Ty.Dest_Order_Type_Id = v_Order_Type_Id
       And Ty.Entity_Id = v_Entity_Id;
    If v_sourDes = 0 and Nvl(r_Order_Type.Is_Product_Area_Split, 0) = 'Y' Then
      v_Message := Null;
      --取出产品产地未维护的产品行,
      For C1 In (Select Item_Code,
                        Entity_Id,
                        Order_Line_Id,
                        Item_Id,
                        l.Item_Price
                   From t_Pln_Order_Line l
                  Where l.Entity_Id = v_Entity_Id
                    And l.Order_Head_Id = p_Order_Head_Id
                  --MODI BY LIZHEN 2015-04-20 送审时重新获取产品的最优产地
                  /*Not Exists
                  (Select 1
                           From t_Pln_Item_Producing_Area a
                          Where a.Producing_Area_Id = l.Producing_Area_Id
                            And a.Entity_Id = l.Entity_Id
                            And a.Item_Id = l.Item_Id
                            And Trunc(Sysdate) Between Trunc(a.Begin_Date) And
                                Trunc(Nvl(a.End_Date, Sysdate)))*/
                    ) Loop
        --取已经维护的产地ID,不存在则报错
        /*Begin
          ---  增加排序:先按中心取  ,再按物料取
          --modi by lizhen 2015-04-20
          Select Producing_Area_Id,
                 Producing_Area_Code,
                 Producing_Area_Name
            Into n_Ord_Line_Pro_Area_Id,
                 v_Ord_Line_Pro_Area_Code,
                 v_Ord_Line_Pro_Area_Name
            From (Select a.Producing_Area_Id,
                         Pa.Producing_Area_Code,
                         Pa.Producing_Area_Name,
                         Nvl(Pc.Priority, 999) * 100 +
                         a.Producing_Area_Priority Priority
                    From t_Pln_Item_Producing_Area a,
                         t_Pln_Producing_Area Pa,
                         (Select Rownum Priority,
                                 a.Sales_Center_Id,
                                 a.Producing_Area_Id,
                                 a.Producing_Area_Code,
                                 a.Entity_Id
                            From (Select *
                                    From (Select t.Sales_Center_Id,
                                                 t.Producing_Area_Id,
                                                 t.Producing_Area_Code,
                                                 t.Entity_Id,
                                                 t.Cost_Price,
                                                 Rank() Over(Partition By t.Sales_Center_Id Order By t.Producing_Area_Priority) Priority
                                            From t_Pln_Customer_Priority t
                                           Where t.Sales_Center_Id =
                                                 v_Sales_Center_Id
                                             And t.Item_Id = C1.Item_Id
                                          Union All
                                          Select t.Sales_Center_Id,
                                                 t.Producing_Area_Id,
                                                 t.Producing_Area_Code,
                                                 t.Entity_Id,
                                                 Null Cost_Price,
                                                 Rank() Over(Partition By t.Sales_Center_Id Order By t.Producing_Area_Priority) Priority
                                            From t_Pln_Customer_Priority t
                                           Where t.Sales_Center_Id = v_Sales_Center_Id
                                             And t.item_id Is Null
                                             \*And Not Exists
                                           (Select 1
                                                    From t_Pln_Customer_Priority Pcp
                                                   Where Pcp.Sales_Center_Id =
                                                         t.Sales_Center_Id
                                                     And Pcp.Producing_Area_Id =
                                                         t.Producing_Area_Id
                                                     And Pcp.Item_Id =
                                                         C1.Item_Id)*\)
                                   Order By Cost_Price, Priority) a) Pc
                   Where Pa.Entity_Id = a.Entity_Id
                     And Pa.Producing_Area_Id = a.Producing_Area_Id
                     And Pc.Sales_Center_Id(+) = v_Sales_Center_Id
                     And Pc.Entity_Id(+) = C1.Entity_Id
                     And Pc.Producing_Area_Id(+) = a.Producing_Area_Id
                     And a.Entity_Id = C1.Entity_Id
                     And a.Item_Id = C1.Item_Id
                     And Trunc(Sysdate) Between Trunc(a.Begin_Date) And
                         Trunc(Nvl(a.End_Date, Sysdate))
                     And Trunc(Sysdate) Between Trunc(Pa.Begin_Date) And
                         Trunc(Nvl(Pa.End_Date, Sysdate))
                   Order By Nvl(Pc.Priority, 999) * 100 +
                            a.Producing_Area_Priority)
           Where Rownum = 1;
        Exception
          When Others Then
            v_Message := v_Message || ' ' || C1.Item_Code;
        End;*/
        --add by lizhen 2015-04-20
        n_Ord_Line_Pro_Area_Id := Null;
        n_Ord_Line_Pro_Area_Id := Pkg_Pln_Pub.f_Get_Item_Prod_Area_Priority(p_Entity_Id       => v_Entity_Id,
                                                                            p_Sales_Center_Id => v_Sales_Center_Id,
                                                                            p_Item_Id         => C1.Item_Id
                                                                            );
        If n_Ord_Line_Pro_Area_Id =0 Or n_Ord_Line_Pro_Area_Id Is Null Then
          v_Message := v_Message || ' ' || C1.Item_Code;
        Else
          Begin
            Select Pa.Producing_Area_Code, Pa.Producing_Area_Name
              Into v_Ord_Line_Pro_Area_Code, v_Ord_Line_Pro_Area_Name
              From t_Pln_Producing_Area Pa
             Where Pa.Producing_Area_Id = n_Ord_Line_Pro_Area_Id;
          Exception
            When Others Then
              p_Result := '获取产地信息失败，产地ID：' ||
                          To_Char(n_Ord_Line_Pro_Area_Id) || v_Nl ||
                          Sqlerrm;
              Raise v_Base_Exception;
          End;
        End If;
        If Nvl(n_Ord_Line_Pro_Area_Id, 0) <> 0 Then
          --更新为系统中已经维护的产地
          Update t_Pln_Order_Line l
             Set l.Producing_Area_Id   = n_Ord_Line_Pro_Area_Id,
                 l.Producing_Area_Code = v_Ord_Line_Pro_Area_Code,
                 l.Producing_Area_Name = v_Ord_Line_Pro_Area_Name
           Where l.Entity_Id = C1.Entity_Id
             And l.Order_Line_Id = C1.Order_Line_Id;
        Else
          --更新为系统中已经维护的产地
          Update t_Pln_Order_Line l
             Set l.Check_Result = '查询不到产品产地最优产地'
           Where l.Entity_Id = C1.Entity_Id
             And l.Order_Line_Id = C1.Order_Line_Id;
        End If;
      End Loop;

      If v_Message Is Not Null Then
        p_Result := '下列产品的查询不到最优产地:' || v_Nl || v_Message || v_Nl ||
                    '原因:产品产地未维护,产品所属生命周期不能送审!';
        Raise v_Base_Exception;
      End If;
    End If;

    --add by lizhen 2017-05-05 写入CIMS产能可视排队队列表,单据类型必须设置产能可视标志
    --产能检查放在行表重新取最产地后进行产能检查
    If v_Pln_Capacity_Modle = 'CIMS' And r_Order_Type.Is_Pln_Capacity = 'Y' Then
      Pkg_Pln_Capacity.p_Chk_Item_Capacity(p_Entity_Id        => v_Entity_Id,
                                           p_Order_Head_Id    => p_Order_Head_Id,
                                           p_Order_Type_Id    => r_Order_Type.Order_Type_Id,
                                           p_Order_Check_Date => Trunc(Sysdate), --检查日期
                                           p_User_Code        => p_User_Code,
                                           p_Result           => p_Result,
                                           p_Chk_Msg          => v_Temstr);
      If p_Result = v_Failure Then
        p_Result := Nvl(v_Temstr, p_Result);
        Raise v_Base_Exception;
      Else
        p_Result := v_Success;
      End If;
      --检查是否存在未处理完的产能占用，存在则一直循环直到处理完为止
      Begin
        Select 1
          Into v_Count
          From t_Pln_Capacity_Single_Process Csp
         Where Csp.Entity_Id = v_Entity_Id
           For Update;
      Exception
        When Others Then
          p_Result := '检查产能占用事务串行记录表失败!' || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
      End;
    End If;

    --检查是否凑整
    Begin
      If r_Order_Type.Is_Count = 'Y' Then
        For Line In (Select l.Item_Id, l.Check_Qty, l.Entity_Id
                       From t_Pln_Order_Line l
                      Where l.Order_Head_Id = p_Order_Head_Id) Loop
          --检查凑整
          Pkg_Pln_Pub.p_Check_Item_Rounding(Line.Entity_Id,
                                            Line.Item_Id,
                                            Line.Check_Qty,
                                            p_Result);
          If p_Result != v_Success Then
            Raise v_Base_Exception;
          End If;
        End Loop;
      End If;
    End;

    --add by fenggq 2015-03-10 校验产品生命周期
    BEGIN
      VS_ITEM_LIFE_CYCLE := PKG_BD.F_GET_PARAMETER_VALUE('PLN_ITEM_LIFE_CYCLE', V_ENTITY_ID);
    EXCEPTION
      WHEN OTHERS THEN
        P_RESULT := '获取PLN_ITEM_LIFE_CYCLE参数失败' || V_NL || SQLERRM;
        RAISE V_BASE_EXCEPTION;
    END;

    --是否校验产品生命周期
    IF VS_ITEM_LIFE_CYCLE != 'N' THEN
      V_MESSAGE := NULL;
      --返修订单、工厂增补订单不校验产品生命周期
      IF R_ORDER_TYPE.SOURCE_ORDER_TYPE_ID != 2 AND Upper(NVL(R_ORDER_TYPE.IS_BUSINESS_CONTROL, '-')) != 'PLN_CHECK_COST' THEN
        --modi by lizhen 2015-08-29
        For c_Pln_Item_Life_Cycle In (Select Ol.Entity_Id,
                                             Ol.Item_Id,
                                             Ol.Producing_Area_Id,
                                             Decode(v_Send_By_Type,
                                                    '1',
                                                    Pkg_Pln_Pub.v_Phase_Month_Submit,
                                                    '2',
                                                    Pkg_Pln_Pub.v_Phase_Month_Submit,
                                                    '0',
                                                    Pkg_Pln_Pub.v_Phase_Week_Submit,
                                                    '4',
                                                    Pkg_Pln_Pub.v_Phase_Week_Submit,
                                                    '6',
                                                    Pkg_Pln_Pub.v_Phase_Week_Submit,
                                                    '7',
                                                    Pkg_Pln_Pub.v_Phase_Week_Submit,
                                                    Null ) Phase_State,
                                                ol.order_head_id ,
                                                ol.order_line_id ,
                                                ol.item_code,
                                                ta.state
                                        From t_Pln_Order_Head Oh,
                                             t_Pln_Order_Line Ol,
                                             t_pln_item_producing_area ta
                                       Where Oh.Order_Head_Id = p_Order_Head_Id
                                         And Oh.Order_Head_Id = Ol.Order_Head_Id
                                         and ta.item_id=ol.item_id
                                         and ta.producing_area_id=ol.producing_area_id
                                         and ta.entity_id=ol.entity_id
                                         and ta.entity_id=v_Entity_Id
                                         And nvl(Ol.Apply_Qty,0) > 0) Loop
          Vs_Check_Result := Null;
          Vs_Check_Result := Pkg_Pln_Pub.p_Chk_Item_Prdc_Life_Cycle(c_Pln_Item_Life_Cycle.Entity_Id,
                                                                    c_Pln_Item_Life_Cycle.Item_Id,
                                                                    c_Pln_Item_Life_Cycle.Producing_Area_Id,
                                                                    c_Pln_Item_Life_Cycle.Phase_State);
          If Vs_Check_Result != 'Y' Then
            v_Message := v_Message || Vs_Check_Result || v_Nl;
            -- add by lizhen 2015-9-21
/*            if v_Update_Sql is null then
              v_Update_Sql := 'update t_pln_order_line l set l.remark=''品编码:'||c_Pln_Item_Life_Cycle.Item_Code
                || '  生命周期状态:'|| c_Pln_Item_Life_Cycle.State || '不能送审!'' ' ||
                ' where l.order_head_id= ' || to_char(c_Pln_Item_Life_Cycle.Order_Head_Id) ||
                ' and l.order_line_id= ' ||to_char(c_Pln_Item_Life_Cycle.Order_Line_Id)  ||
                ' and l.entity_id= ' || to_char(v_Entity_Id) || ';';
            else
              v_Update_Sql := v_Update_Sql || v_Nl ||
               'update t_pln_order_line l set l.remark=''品编码:'||c_Pln_Item_Life_Cycle.Item_Code
                || '  生命周期状态:'|| c_Pln_Item_Life_Cycle.State || '不能送审!'' ' ||
                ' where l.order_head_id= ' || to_char(c_Pln_Item_Life_Cycle.Order_Head_Id) ||
                ' and l.order_line_id= ' ||to_char(c_Pln_Item_Life_Cycle.Order_Line_Id)  ||
                ' and l.entity_id= ' || to_char(v_Entity_Id) || ';';
            end if;
*/          End If;
        End Loop;
        IF V_MESSAGE IS NOT NULL THEN
         /* rollback;
          execute immediate 'begin ' || v_Update_Sql || '  end;';
          commit;
    */
          P_RESULT := '以下产品在所属生命周期内不能送审。' || V_NL || V_MESSAGE;
          RAISE V_BASE_EXCEPTION;
        END IF;
        --按月送审
        /*IF V_SEND_BY_TYPE IN ('1', '2') THEN
          FOR C_PLN_ITEM_LIFE_CYCLE IN
            (SELECT OL.ENTITY_ID,
                    OL.ITEM_ID,
                    OL.PRODUCING_AREA_ID
               FROM T_PLN_ORDER_HEAD          OH,
                    T_PLN_ORDER_LINE          OL
              WHERE OH.ORDER_HEAD_ID = P_ORDER_HEAD_ID
                AND OH.ORDER_HEAD_ID = OL.ORDER_HEAD_ID
                AND OL.CAN_PRODUCE_QTY > 0) LOOP
            VS_CHECK_RESULT := NULL;
            VS_CHECK_RESULT := PKG_PLN_PUB.P_CHK_ITEM_PRDC_LIFE_CYCLE(C_PLN_ITEM_LIFE_CYCLE.ENTITY_ID, C_PLN_ITEM_LIFE_CYCLE.ITEM_ID,
                                        C_PLN_ITEM_LIFE_CYCLE.PRODUCING_AREA_ID, PKG_PLN_PUB.V_PHASE_MONTH_SUBMIT);
            IF VS_CHECK_RESULT != 'Y' THEN
              V_MESSAGE := V_MESSAGE || VS_CHECK_RESULT || V_NL;
            END IF;
          END LOOP;

          IF V_MESSAGE IS NOT NULL THEN
            P_RESULT := '以下产品在所属生命周期内不能送审。' || V_NL || V_MESSAGE;
            RAISE V_BASE_EXCEPTION;
          END IF;
        --按周送审
        ELSIF V_SEND_BY_TYPE IN ('0', '4') THEN
          FOR C_PLN_ITEM_LIFE_CYCLE IN
            (SELECT OL.ENTITY_ID,
                    OL.ITEM_ID,
                    OL.PRODUCING_AREA_ID
               FROM T_PLN_ORDER_HEAD          OH,
                    T_PLN_ORDER_LINE          OL
              WHERE OH.ORDER_HEAD_ID = P_ORDER_HEAD_ID
                AND OH.ORDER_HEAD_ID = OL.ORDER_HEAD_ID
                AND OL.CAN_PRODUCE_QTY > 0) LOOP
            VS_CHECK_RESULT := NULL;
            VS_CHECK_RESULT := PKG_PLN_PUB.P_CHK_ITEM_PRDC_LIFE_CYCLE(C_PLN_ITEM_LIFE_CYCLE.ENTITY_ID, C_PLN_ITEM_LIFE_CYCLE.ITEM_ID,
                                        C_PLN_ITEM_LIFE_CYCLE.PRODUCING_AREA_ID, PKG_PLN_PUB.V_PHASE_WEEK_SUBMIT);
            IF VS_CHECK_RESULT != 'Y' THEN
              V_MESSAGE := V_MESSAGE || VS_CHECK_RESULT || V_NL;
            END IF;
          END LOOP;

          IF V_MESSAGE IS NOT NULL THEN
            P_RESULT := '以下产品在所属生命周期内不能送审。' || V_NL || V_MESSAGE;
            RAISE V_BASE_EXCEPTION;
          END IF;
        END IF;*/
      END IF;
    END IF;
    --end by fenggq

    if r_Order_Type.Is_Business_Control='pln_check_cost' then
       v_Message := Null;
      /*For cr In (Select Ol.Item_Code, Ol.Order_Line_Id, Ppa.Mrp_Org_Id
                  From Cims.t_Pln_Order_Line     Ol,
                       Cims.t_Pln_Order_Head     Oh,
                       Cims.t_Pln_Producing_Area Ppa
                 Where Oh.Order_Head_Id = Ol.Order_Head_Id
                   And Oh.Producing_Area_Id = Ppa.Producing_Area_Id
                   And Oh.Order_Head_Id = p_Order_Head_Id
                   And Not Exists
                 (Select 1
                          From Apps.Mtl_System_Items@Mdims2mderp m
                         Where m.Organization_Id = Ppa.Mrp_Org_Id
                           And m.Segment1 = Ol.Item_Code
                           And Nvl(m.Customer_Order_Enabled_Flag, 'N') = 'Y'
                           And Nvl(m.Customer_Order_Flag, 'N') = 'Y'
                           And Nvl(m.Shippable_Item_Flag, 'N') = 'Y'
                           And Nvl(m.So_Transactions_Flag, 'N') = 'Y'
                           And Nvl(m.Returnable_Flag, 'N') = 'Y'
                           And m.Atp_Components_Flag = 'N'
                           And m.Atp_Flag = 'N'
                           and m.Inventory_Item_Status_code !='Inactive')) Loop
        v_Message := v_Message || '  ' || cr.item_code;
      End Loop;*/
      If v_Message Is Not Null Then
        p_Result := '检查工厂增补订单产地对应的ERP组织不存以下产品。' || v_Nl ||
          '产品编码：' || v_Message || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
        --modi by lizhen 2017-05-05 改用异常抛出，不做直接返回
        --Return;
      End If;
      --返修订单类型检查物料成本
      --MODI BY LIZHEN 2015-04-23 应IT转业务要求，在返修、工厂增补订单时只检查ERP产品状态，不检查标准成本
      /*For Crw In (Select Ol.Item_Code, Ol.Order_Line_Id, Ppa.Mrp_Org_Id
                    From Cims.t_Pln_Order_Line     Ol,
                         Cims.t_Pln_Order_Head     Oh,
                         Cims.t_Pln_Producing_Area Ppa
                   Where Oh.Order_Head_Id = Ol.Order_Head_Id
                     And Ol.Producing_Area_Id = Ppa.Producing_Area_Id
                     And Oh.Order_Head_Id = p_Order_Head_Id) Loop
        Select Nvl(Max(Cic.Item_Cost), 0)
          Into v_Item_Cost
          From Apps.Cst_Item_Costs@Mdims2mderp   Cic, --ERP产品成本表
               Apps.Mtl_System_Items@Mdims2mderp Mtl --ERP产品表
         Where Cic.Inventory_Item_Id = Mtl.Inventory_Item_Id
           And Cic.Organization_Id = Mtl.Organization_Id
           And Cic.Organization_Id = Crw.Mrp_Org_Id
           And Mtl.Segment1 = Crw.Item_Code;
        If v_Item_Cost = 0 Then
          v_Message := v_Message || '  ' || Crw.Item_Code;
        End If;
        v_Item_Cost := Null;
      End Loop;
      If v_Message Is Not Null Then
        p_Result := '以下物料未维护冻结成本：' || v_Nl || '产品编码：' || v_Message || v_Nl ||
                    Sqlerrm;
        Return;
      End If;*/
    end if;

    --add by lizhen 2015-01-31 判断套件产品是否存在套散件关系，无套散件关系则提示异常
      --产品属性说明
      /*SET_PRODUCT       套机
        INDOOR_PRODUCT    室内机
        OUTDOOR_PRODUCT   室外机
        WHOLE_PRODUCT     整体机
        SAMPLE_PRODUCT    样机
        PARTS_PRODUCT     散件
        ACCESSORIES_PRODUCT 独立销售模块*/
      v_Message := Null;
      For Item In (Select Ol.Item_Code,
                          (Select Sum(Ias.Value_Scale)
                             From t_Bd_Item_Assemblies     Bia,
                                  t_Bd_Item_Assemblies_Sub Ias
                            Where Bia.Item_Assembly_Id = Ias.Item_Assembly_Id
                              And Nvl(Bia.Active_Flag, 'N') = 'Y'
                              And Nvl(Ias.Active_Flag, 'N') = 'Y'
                              And Bia.Item_Id = Bi.Item_Id) Item_Value_Scale
                     From t_Pln_Order_Line Ol, t_Bd_Item Bi
                    Where Ol.Item_Id = Bi.Item_Id
                      And Ol.Entity_Id = Bi.Entity_Id
                      And Bi.Productform = 'SET_PRODUCT'
                      And Ol.Order_Head_Id = p_Order_Head_Id) Loop
        If Nvl(Item.Item_Value_Scale, 0) < 100 Then
          v_Message := v_Message || '   ' || Item.Item_Code;
        End If;
      End Loop;
      If v_Message Is Not Null Then
        p_Result := '检查套件产品套散件关系失败。' || v_Nl ||
          '原因：1、不存在套散件关系；' || v_Nl ||
          ' 2、套散件关系已失效；' || v_Nl ||
          ' 3、散件价值比率小于100；' || v_Nl ||
          '套件产品编码：' || v_Message;
        Raise v_Base_Exception;
        --modi by lizhen 2017-05-05 改用异常抛出，不做直接返回
        --Return;
      End If;

    --是否检查产品型普
    If v_Material_Range_Flag = v_True OR v_Material_Range_Flag = 'S' THEN --何加源 增加按SKU控制逻辑
      IF v_Material_Range_Flag = v_True THEN
        v_Message := Null;
        For C2 In (Select Item_Code
                     From t_Pln_Order_Line l
                    Where l.Entity_Id = v_Entity_Id
                      And l.Order_Head_Id = p_Order_Head_Id
                      And Not Exists
                    (Select 1
                             From t_Pln_Item_Dyn_Attribute a
                            Where a.Entity_Id = l.Entity_Id
                              And a.Item_Id = l.Item_Id
                              And a.Item_Dynamic_Attribute = '定制机型'
                              And Sysdate Between Nvl(a.Begin_Date, Sysdate) And
                                  Nvl(a.End_Date, Sysdate + 1))) Loop
          v_Message := v_Message || ' ' || C2.Item_Code;
        End Loop;

        If v_Message Is Not Null Then
          p_Result := '下列产品:' || v_Nl || v_Message || v_Nl ||
                      '在订单产品型普未定义，请重新定义订单产品型普后重新送审!';
          Raise v_Base_Exception;
          --modi by lizhen 2017-05-05 改用异常抛出，不做直接返回
          --Return;
        End If;
      ELSIF v_Material_Range_Flag = 'S' THEN --按SKU控制
        PKG_PLN_PUB.P_PLN_CHECK_SC_SKU(p_Order_Head_Id => p_Order_Head_Id,
                                       p_Entity_Id     => v_Entity_Id,
                                       p_Order_Type    => 'PLN',
                                       p_Result        => p_Result);
        IF p_Result <> v_Success THEN
          Return;
        END IF;
      END IF;

      -- 订单源类型为样机订单 检查所有的产品是否样机标识
      If v_Order_Type_Id In (196) Then
        v_Message := Null;
        For C2 In (Select Item_Code
                     From t_Pln_Order_Line l
                    Where l.Entity_Id = v_Entity_Id
                      And l.Order_Head_Id = p_Order_Head_Id
                      And Not Exists
                    (Select 1
                             From t_Pln_Item_Dyn_Attribute a
                            Where a.Entity_Id = l.Entity_Id
                              And a.Item_Id = l.Item_Id
                              And a.Sample_Flag = 'Y' --是否样机标识
                              And Sysdate Between Nvl(a.Begin_Date, Sysdate) And
                                  Nvl(a.End_Date, Sysdate + 1))) Loop
          v_Message := v_Message || ' ' || C2.Item_Code;
        End Loop;
        If v_Message Is Not Null Then
          p_Result := '下列产品:' || v_Nl || v_Message || v_Nl ||
                      '在订单产品型普中不为样机标识，请重新定义订单产品型普后重新送审!';
          Raise v_Base_Exception;
          --modi by lizhen 2017-05-05 改用异常抛出，不做直接返回
          --Return;
        End If;
      End If;

      --检查产品所在产品型普的订单最大申请量及最小申请量
      Begin
        v_Message := Null;
        For r_Ord_Lin In (Select Apply_Qty,
                                 Item_Id,
                                 Item_Code,
                                 Item_Max_Qty,
                                 Item_Min_Qty
                            From (Select Nvl(Sum(Pol.Apply_Qty), 0) Apply_Qty,
                                         Pol.Item_Id,
                                         Pol.Item_Code,
                                         Nvl((Select i.Item_Max_Qty
                                               From t_Pln_Item_Dyn_Attribute i
                                              Where i.Item_Id = Pol.Item_Id
                                                And Trunc(Sysdate) Between
                                                    i.Begin_Date And
                                                    Trunc(Nvl(i.End_Date,
                                                              Sysdate))),
                                             0) Item_Max_Qty,
                                         Nvl((Select i.Item_Min_Qty
                                               From t_Pln_Item_Dyn_Attribute i
                                              Where i.Item_Id = Pol.Item_Id
                                                And Trunc(Sysdate) Between
                                                    i.Begin_Date And
                                                    Trunc(Nvl(i.End_Date,
                                                              Sysdate))),
                                             0) Item_Min_Qty
                                    From t_Pln_Order_Line Pol
                                   Where Pol.Order_Head_Id = p_Order_Head_Id
                                     And Pol.Entity_Id = v_Entity_Id
                                     And Exists
                                   (Select 1
                                            From t_Pln_Item_Dyn_Attribute a
                                           Where a.Entity_Id = Pol.Entity_Id
                                             And a.Item_Id = Pol.Item_Id
                                             And a.Item_Dynamic_Attribute =
                                                 '定制机型'
                                             And Sysdate Between
                                                 Nvl(a.Begin_Date, Sysdate) And
                                                 Nvl(a.End_Date, Sysdate + 1))
                                   Group By Pol.Order_Line_Id,
                                            Pol.Item_Id,
                                            Pol.Item_Code) Ord
                           Where Ord.Apply_Qty > Ord.Item_Max_Qty
                              Or Ord.Apply_Qty < Ord.Item_Min_Qty) Loop
          v_Message := v_Message || ' ' || r_Ord_Lin.Item_Code;
        End Loop;
        If v_Message Is Not Null Then
          p_Result := '下列产品:' || v_Nl || v_Message || v_Nl ||
                      '申请数量大于产品型普的最大申请数量，或者申请数量小于产品型普的最小申请数量!';
          Raise v_Base_Exception;
          --modi by lizhen 2017-05-05 改用异常抛出，不做直接返回
          --Return;
        End If;
      Exception
        When Others Then
          p_Result := '下列产品:' || v_Nl || v_Message || v_Nl ||
                      '申请数量大于产品型普的最大申请数量，或者申请数量小于产品型普的最小申请数量!';
          Raise v_Base_Exception;
          --modi by lizhen 2017-05-05 改用异常抛出，不做直接返回
          --Return;
      End;
    End If;

    --检查库存占比
    IF r_Order_Type.Is_Inv_Cost_Proportion = v_True THEN
      PKG_PLN_PUB.P_PLN_CHK_INV_COST_PROPORTION(p_Order_Head_Id => p_Order_Head_Id,
                                                p_Entity_Id     => v_Entity_Id,
                                                p_Order_Type    => 'PLN',
                                                p_Result        => p_Result);
      IF p_Result <> v_Success THEN
        Raise v_Base_Exception;
        --modi by lizhen 2017-05-05 改用异常抛出，不做直接返回
        --Return;
      END IF;
    END IF;

    --检查当前主体产地数量
    If Nvl(v_Order_Type_Name, ' ') <> '客户订单' Then
      Select Count(*)
        Into n_Productng_Area_Count
        From t_Pln_Producing_Area p
       Where p.Entity_Id = v_Entity_Id;
      --主体产地数小于2个的主体,不检查产品产地
      If n_Productng_Area_Count > 1 Then
        --检查临时订单单据行,产品是否属于当前订单产地
        p_Chk_Order_Line_Mtl_Producing(p_Order_Head_Id, p_Result);
        If p_Result <> v_Success Then
          Raise v_Base_Exception;
          --modi by lizhen 2017-05-05 改用异常抛出，不做直接返回
          --Return;
        End If;
      End If;
    End If;

    --检查是否存在重复的订单行
    v_Status := Substrb((v_Nl || '检查订单行' || '：'), 1, 50);
    Select Count(*)
      Into v_Cnt
      From (Select Item_Id, Producing_Area_Id
              From t_Pln_Order_Line
             Where Order_Head_Id = p_Order_Head_Id
             Group By Item_Id, Producing_Area_Id
            Having Count(*) > 1);
    If v_Cnt > 0 Then
      Rollback;
      p_Result := Substrb((v_Message || v_Status || '失败，不能有重复的产品、产地'),
                          1,
                          2000);
      Raise v_Base_Exception;
      --modi by lizhen 2017-05-05 改用异常抛出，不做直接返回
      --Return;
    End If;
    --除第0周外，需检查紧急程度的量
    If v_Week_Edition > 0 Or (v_Month_Edition > 0 And v_Week_Edition < 0) Then
      --增加紧急程度的数量限制（紧急：不能超过4个）
      Select Count(*)
        Into v_Cnt
        From t_Pln_Order_Line
       Where Order_Head_Id = p_Order_Head_Id
         And Nvl(Apply_Qty, 0) + Nvl(Adjust_Qty, 0) > 0
         And Priority = 1;
      If v_Cnt > 4 Then
        p_Result := Substrb((v_Message || v_Status || '失败，紧急的产品不能超过4个（现有' ||
                            To_Char(v_Cnt) || '个）'),
                            1,
                            2000);
        Raise v_Base_Exception;
        --modi by lizhen 2017-05-05 改用异常抛出，不做直接返回
        --Return;
      End If;

      --增加紧急程度的数量限制（急：不能超过6个）
      Select Count(*)
        Into v_Cnt
        From t_Pln_Order_Line
       Where Order_Head_Id = p_Order_Head_Id
         And Nvl(Apply_Qty, 0) + Nvl(Adjust_Qty, 0) > 0
         And Priority = 2;
      If v_Cnt > 6 Then
        p_Result := Substrb((v_Message || v_Status || '失败，急的产品不能超过6个（现有' ||
                            To_Char(v_Cnt) || '个）'),
                            1,
                            2000);
        Raise v_Base_Exception;
        --modi by lizhen 2017-05-05 改用异常抛出，不做直接返回
        --Return;
      End If;
    End If;

    Begin
      v_Can_Change_Period := Pkg_Bd.f_Get_Parameter_Value('PLN_ORDER_CAN_CHANGE_PERIOD',
                                                         v_Entity_Id);
    Exception
      When Others Then
        p_Result := '获取PLN_ORDER_CAN_CHANGE_PERIOD参数失败' || v_Nl ||
                    Sqlerrm;
        Raise v_Base_Exception;
    End;

    --更新供货日期
    If v_Source_Order_Type_Id != 2 Then
      If v_Order_Type_Name = '工厂增补' Then
        Update t_Pln_Order_Line Wol
           Set Wol.Can_Supply_Date   = Decode(v_Period_Type,
                                              '月',
                                              v_Month_End_Date,
                                              v_Week_End_Date),
               Wol.Begin_Supply_Date = Trunc(Sysdate),
               Wol.End_Supply_Date   = Trunc(Sysdate) + 3
         Where Wol.Order_Head_Id = p_Order_Head_Id;
      Elsif v_Order_Type_Name <> '客户订单' Then
        IF v_Can_Change_Period = 'Y'Or r_Order_Type.Promise_Days Is Not Null THEN
          Update t_Pln_Order_Line Wol
             Set Wol.Can_Supply_Date   = Decode(v_Period_Type,
                                                '月',
                                                v_Month_End_Date,
                                                v_Week_End_Date)
           Where Wol.Order_Head_Id = p_Order_Head_Id
             AND wol.can_supply_date IS NULL;

          Update t_Pln_Order_Line Wol
             SET Wol.Begin_Supply_Date = Decode(v_Period_Type,
                                                '月',
                                                v_Month_Begin_Date,
                                                v_Week_Begin_Date),
                 Wol.End_Supply_Date   = wol.can_supply_date
           Where Wol.Order_Head_Id = p_Order_Head_Id;
        ELSE
          Update t_Pln_Order_Line Wol
             Set Wol.Can_Supply_Date   = Decode(v_Period_Type,
                                                '月',
                                                v_Month_End_Date,
                                                v_Week_End_Date),
                 Wol.Begin_Supply_Date = Decode(v_Period_Type,
                                                '月',
                                                v_Month_Begin_Date,
                                                v_Week_Begin_Date),
                 Wol.End_Supply_Date   = Decode(v_Period_Type,
                                                '月',
                                                v_Month_End_Date,
                                                v_Week_End_Date)
           Where Wol.Order_Head_Id = p_Order_Head_Id;
        End If;
      End If;
    Else
      Update t_Pln_Order_Line Wol
           Set Wol.Begin_Supply_Date = Decode(v_Period_Type,
                                              '月',
                                              v_Month_Begin_Date,
                                              v_Week_Begin_Date),
               Wol.End_Supply_Date   = Decode(v_Period_Type,
                                              '月',
                                              v_Month_End_Date,
                                              v_Week_End_Date)
         Where Wol.Order_Head_Id = p_Order_Head_Id;
    End If;

    -- add by ex_zhangcc 2015-12-5
    -- 检查虚拟产地、产品 是否对应
    -- 只有工厂增补和返修订单
    if r_Order_Type.Is_Business_Control='pln_check_cost' or r_Order_Type.Source_Order_Type_Id=2 then
      For r_lg_order_line In (
                      select l.item_id,
                             l.item_code,
                             h.virtual_producing_area_id,
                             l.entity_id
                      　from t_pln_order_line l ,t_pln_order_head h
                      where h.order_head_id=l.order_head_id
                      and l.order_head_id=p_Order_Head_Id
        )  Loop
          if r_lg_order_line.virtual_producing_area_id is not null
            or Nvl(To_Char(r_lg_order_line.virtual_producing_area_id), '_') <> '_' then
            begin
            select t.po_area_id
              into v_Cnt
              from v_inv_producting_item_list t
             where t.po_area_id =
                   r_lg_order_line.virtual_producing_area_id
               and t.item_id = r_lg_order_line.item_id
               and (trunc(sysdate) between t.begin_date and
                   nvl(t.end_date, trunc(sysdate)))
               and t.entity_id = r_lg_order_line.entity_id;
            Exception
              when no_data_found then p_Result := '产品编码:' || r_lg_order_line.item_code
                || v_Nl || '在v_inv_producting_item_list中不存在,或者已失效!';
                 raise v_Base_Exception;
            end;
          end If;
      end Loop;
    end if;
  If nvl(v_Sys_Source,'_') <> 'CIMS' And nvl(v_source_type,'_') <> '提货订单' Then
    If p_Result = v_Success And nvl(r_Order_Type.Chk_Cusg_Amount_Flag,'_') = pkg_pln_pub.V_LOCK_AMOUNT_FLAG_S Then
      --设置订金比例
      --优先取订单类型配置的锁款比例
      if r_Order_Type.Locked_Proportion is not null then
        V_DOWN_PAY_RATE := r_Order_Type.Locked_Proportion;
      else
        BEGIN
          SELECT L.DOWN_PAY_RATE INTO V_DOWN_PAY_RATE
            FROM T_CREDIT_ACCOUNT_LIMIT L
           WHERE L.ENTITY_ID = v_Entity_Id
             AND L.CUSTOMER_ID = v_Customer_Id
             AND L.SALES_CENTER_ID = v_Sales_Center_Id
             AND L.ACCOUNT_ID = v_account_id;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            --获取参数值
            BEGIN
              V_DOWN_PAY_RATE := PKG_BD.F_GET_PARAMETER_VALUE('CREDIT_DOWN_PAY_SCALE',
                                                               v_Entity_Id);
            EXCEPTION
              WHEN OTHERS THEN
                P_RESULT := '获取CREDIT_DOWN_PAY_SCALE参数失败！' || V_NL ||
                            SQLERRM;
                RAISE V_BASE_EXCEPTION;
            END;
        END;
      end if;
    end if;

    --更新计划订单头订金比例
    UPDATE T_PLN_ORDER_HEAD H
       SET H.DOWN_PAY_SCALE = V_DOWN_PAY_RATE,
           H.LOCK_AMOUNT_FLAG = r_Order_Type.Chk_Cusg_Amount_Flag
     WHERE H.ORDER_HEAD_ID = p_Order_Head_Id;

    --只有送审锁款时才锁款
    --modi by xuhongjiu 2015-11-27 金额=（单价*数量*（100-折扣率-月返））/100
    If p_Result = v_Success And nvl(r_Order_Type.Chk_Cusg_Amount_Flag,'_') = pkg_pln_pub.V_LOCK_AMOUNT_FLAG_S Then
      For r_Check_Amount In (Select --20170517 hejy3 按行营销大类
                                    --Bi.Sales_Main_Type,
                                    nvl(pol.sales_main_type, Bi.Sales_Main_Type) Sales_Main_Type,
                                    Sum(Round(nvl(pol.item_price,0) * nvl(pol.apply_qty,0) *
                                       (100 - nvl(pol.discount_rate,0) - nvl(pol.ordered_discount_rate,0)) / 100,2)) apply_Amount,
                                    Sum(Round(nvl(pol.item_price,0) * nvl(pol.apply_qty,0) * nvl(pol.discount_rate,0)/100,2)) Discount_Amount
                               From t_Pln_Order_Line pol, t_Bd_Item Bi
                              Where pol.Item_Id = Bi.Item_Id
                                And Bi.Entity_Id = pol.Entity_Id
                                And pol.Order_Head_Id = p_Order_Head_Id
                                And pol.Entity_Id = v_Entity_Id
                                --20170517 hejy3 按行营销大类
                              Group By nvl(pol.sales_main_type, Bi.Sales_Main_Type)--Bi.Sales_Main_Type
                              ) Loop
          If r_check_amount.sales_main_type Is Null Then
             p_Result := '订单行里存在产品没有营销大类' || v_Order_State || v_Nl || p_Result;
             Raise v_Base_Exception;
          End If;
        If Nvl(r_Check_Amount.apply_Amount, 0) + Nvl(r_Check_Amount.Discount_Amount, 0) > 0 Then
          --检查并锁定资金
          /*Pkg_Credit_Account_Control.Prc_Credit_Order_Bill(p_Entity_Id       => v_Entity_Id,
                                                           p_Action_Type     => 1,
                                                           p_Settlement_Sum  => Nvl(r_Check_Amount.apply_Amount,
                                                                                    0),
                                                           p_Discount_Sum    => Nvl(r_Check_Amount.Discount_Amount,
                                                                                    0),
                                                           p_Sales_Main_Type => r_Check_Amount.Sales_Main_Type,
                                                           p_Account_Id      => v_account_id,
                                                           p_Customer_Id     => v_Customer_Id,
                                                           p_Proj_Number     => Null,
                                                           p_Order_Id        => p_Order_Head_Id,
                                                           --p_Order_Type      => r_Order_Type.Order_Type_Name,
                                                           P_ORDER_TYPE => r_Order_Type.Order_Type_Code, --20160912 hejy3 传入订单类型编码
                                                           p_Username        => p_User_Code,
                                                           p_Result          => v_Count,
                                                           p_Err_Msg         => p_Result);
          If p_Result <> v_Success Then
            p_Result := '检查并锁定资金失败，产品大类：' || r_Check_Amount.Sales_Main_Type || v_Nl ||
                        p_Result;
            Raise v_Base_Exception;
          End If;*/
          pkg_pln_pub.P_CUSTOMER_AMOUNT_PROCESS(IN_ENTITY_ID       => v_Entity_Id,
                                                IN_ORDER_TYPE_ID   => v_Order_Type_Id,
                                                IN_ORDER_TYPE_CODE => r_Order_Type.Order_Type_Code,
                                                IN_CUSTOMER_ID     => v_Customer_Id,
                                                IN_ACCOUNT_ID      => v_account_id,
                                                IN_SALES_MAIN_TYPE => r_Check_Amount.Sales_Main_Type,
                                                IN_ACTION_TYPE     => 1,
                                                IN_SOURCE_TYPE     => '01',
                                                IN_ORDER_ID        => p_Order_Head_Id,
                                                IN_PROJ_NUMBER     => null,
                                                IN_DISCOUNT_TYPE   => pkg_pln_pub.v_Discount_Type_Common,
                                                IN_AMOUNT          => Nvl(r_Check_Amount.apply_Amount, 0),
                                                IN_DIS_AMOUNT      => Nvl(r_Check_Amount.Discount_Amount, 0),
                                                IN_RECORD_ERR      => 'N',
                                                IN_USER_CODE       => p_User_Code,
                                                OUT_RESULT         => p_Result);

          if p_Result <> v_Success then
            p_Result := '提交订单处理客户款项失败(锁款方式:'||r_Order_Type.Chk_Cusg_Amount_Flag||')！' || v_Nl || p_Result;
            raise v_Base_Exception;
          End If;
        End If;
      End Loop;
    End If;
    End If;

    Begin
      v_Message := Null;
      v_Status  := '获取当单据据类型的下一单据状态';
      Pkg_Pln_Pub.p_Get_Order_Next_Status(p_Order_Type_Id    => v_Order_Type_Id,
                                          p_Curr_State       => v_Order_State,
                                          p_Curr_Action      => p_Operation_Action,
                                          p_Can_Option_Flag  => 'N',
                                          p_Next_Excute_Step => v_Next_Excute_Step,
                                          p_Next_Action      => v_Next_Action,
                                          p_Nextauto_Excute  => v_Nextauto_Excute,
                                          p_Next_State       => v_Next_State,
                                          p_Result           => p_Result);
      If p_Result <> v_Success Then
        p_Result := '获取订单下一状态失败！当前订单状态：' || v_Order_State || v_Nl ||
                    p_Result;
        Raise v_Base_Exception;
      End If;
    Exception
      When Others Then
        p_Result := p_Result;
        Raise v_Base_Exception;
    End;

    --add by lizhen 2017-05-05 产能占用处理
    If v_Pln_Capacity_Modle = 'CIMS' And r_Order_Type.Is_Pln_Capacity = 'Y' Then
      --add by  lizhen 2017-05-05 CIMS产能占用处理
      Pkg_Pln_Capacity.p_Capacity_Occupy_New(p_Order_Head_Id    => p_Order_Head_Id,
                                             p_Order_Type_Id    => r_Order_Type.Order_Type_Id,
                                             p_Order_Check_Date => Trunc(Sysdate),
                                             p_Capacity_Sign    => 1,
                                             --modi by lizhen 2017-08-30
                                             p_Capacity_Type    => Pkg_Bd.f_Get_Parameter_Value(p_Config_Code => 'PLN_CAPACITY_PERIOD_TYPE', p_Entity_Id => v_Entity_Id),
                                             p_User_Code        => p_User_Code,
                                             p_Result           => p_Result);
      If p_Result <> v_Success Then
        Raise v_Base_Exception;
      End If;
      --更新提货订单头信息
      Update t_Pln_Order_Head Poh
         Set Poh.Form_State = Case
                                When (Select Count(1)
                                        From t_Pln_Order_Line Pol
                                       Where Pol.Order_Head_Id =
                                             Poh.Order_Head_Id
                                         And Nvl(Pol.To_Aps_Capacity_Qty, 0) <> Nvl(Pol.Aps_Capacity_Rec_Qty, 0)
                                         And Pol.To_Aps_Capacity_Qty Is Not Null) > 0 Then
                                 '2225'
                                Else
                                 v_Next_State
                              End,
             Poh.Aps_Capacity_State    = 'S',
             Poh.Aps_Capacity_Rec_Date = Sysdate,
             Poh.Refer_User            = p_User_Code,
             Poh.Refer_Date            = Sysdate,
             Poh.Version               = Nvl(Poh.Version, 0) + 1,
             Poh.Last_Update_Date      = Sysdate,
             Poh.Last_Updated_By       = p_User_Code,
             Poh.Lock_Amount_Flag      = r_Order_Type.Chk_Cusg_Amount_Flag --add by xuhongjiu 2015-11-27
       Where Poh.Order_Head_Id = p_Order_Head_Id;
    Else
      --修改订单状态为“送审”
      Update t_Pln_Order_Head
         Set Form_State       = v_Next_State,
             Refer_User       = p_User_Code,
             Refer_Date       = Sysdate,
             Last_Updated_By  = p_User_Code,
             Last_Update_Date = Sysdate,
             Version               = Nvl(Version, 0) + 1,
             lock_amount_flag = r_Order_Type.Chk_Cusg_Amount_Flag --add by xuhongjiu 2015-11-27
       Where Order_Head_Id = p_Order_Head_Id;

    End If;
    --修改订单明细评审数量
    Update t_Pln_Order_Line
       Set Status    = v_Next_State,
           center_check_qty = Nvl(Apply_Qty, 0),
           Check_Qty = Trunc(Nvl(Apply_Qty, 0) + Nvl(Adjust_Qty, 0))
     Where Order_Head_Id = p_Order_Head_Id;

     --add by  lizhen 2016-01-14 检查产品是否为虚拟生产
     Update t_Pln_Order_Line Pol
        Set Pol.Synt_Producing_Area_Id =
            (Select Pi.Po_Area_Id
               From v_inv_producting_item_list Pi
              Where Pi.Entity_Id = Pol.Entity_Id
                And Pi.Item_Id = Pol.Item_Id
                And Trunc(Sysdate) Between Pi.Begin_Date And
                    Trunc(Nvl(Pi.End_Date, Sysdate))),
            Pol.Synt_Order_Flag        = Nvl((Select 'Y'
                                               From v_inv_producting_item_list Pi
                                              Where Pi.Entity_Id = Pol.Entity_Id
                                                And Pi.Item_Id = Pol.Item_Id
                                                And Trunc(Sysdate) Between
                                                    Pi.Begin_Date And
                                                    Trunc(Nvl(Pi.End_Date,
                                                              Sysdate))),
                                             'N')
      Where Pol.Order_Head_Id = p_Order_Head_Id;

    --修改订单状态为“送审”
    Update t_Pln_Order_Head
       Set Form_State       = v_Next_State,
           Refer_User       = p_User_Code,
           Refer_Date       = Sysdate,
           Last_Updated_By  = p_User_Code,
           Last_Update_Date = Sysdate,
           lock_amount_flag = r_Order_Type.Chk_Cusg_Amount_Flag --add by xuhongjiu 2015-11-27
     Where Order_Head_Id = p_Order_Head_Id;

    --不再检查是否总部评审, 但以前的相关控制,需要在流程配置中配置
    --为兼容老版本程序,继续使用以下检查,新程序需把参数设为
    --总部中心报送的非周订单、工厂增补订单，或返修订单，则自动设为总部评审
    --增加临时订单增加总部评审流程
    Select Count(*)
      Into v_Count
      From t_Pln_Order_Type Ot
     Where Ot.Source_Order_Type_Id = 2 --'返修订单'
       And Ot.Order_Type_Id = v_Order_Type_Id
       And Ot.Entity_Id = v_Entity_Id;

    If p_Result <> v_Success Then
      Rollback;
    Else
      p_Result := v_Success;
    End If;
  Exception
    When v_Base_Exception Then
      p_Result := Substrb(p_Result, 1, 2000);
      Rollback;
    When Others Then
      p_Result := Substrb((v_Message || v_Status || '未知错误' || v_Nl ||
                          Sqlerrm || v_String),
                          1,
                          2000);
      Rollback;
  End;

  -----------------------------------------------------------------------------
  -- AUTHOR  : NICRO.LI
  -- CREATED : 2014-07-16 11:05:52
  -- PURPOSE : [订单动作]总部评审 把前台操作移至后台
  -----------------------------------------------------------------------------
  Procedure p_Hq_Order_Check(p_Order_Head_Id    In Number, ----订单头ID
                             p_Operation_Action In Varchar2, --当前单据动作
                             p_User_Code        In Varchar2, ----用户编码
                             p_Result           Out Varchar2 ----返回结果：成功返回"SUCCESS"，失败返回原因
                             ) Is
    v_Count            Number;
    v_Period_Id        Number;
    v_Order_Type_Id    Number;
    v_Order_Type_Name  Varchar2(20);
    v_Temp             Number;
    v_Entity_Id        Number;
    v_Program          Varchar2(50) := 'PKG_PLN_ORDER.P_HQ_ORDER_CHECK';
    v_Order_State      Varchar2(100);
    v_Next_Excute_Step Number;
    v_Next_Action      Varchar2(100);
    v_Nextauto_Excute  Varchar2(100);
    v_Next_State       Varchar2(100);
  Begin
    p_Result := v_Success;

    --锁定单据
    Begin
      Select h.Entity_Id,
             h.Order_Type_Id,
             h.Order_Type_Name,
             h.Period_Id,
             h.Form_State
        Into v_Entity_Id,
             v_Order_Type_Id,
             v_Order_Type_Name,
             v_Period_Id,
             v_Order_State
        From t_Pln_Order_Head h
       Where Order_Head_Id = p_Order_Head_Id
         For Update Nowait;
    Exception
      When Others Then
        p_Result := '读锁定单据失败,该单据正被其他用户操作';
        Raise v_Base_Exception;
    End;

    Begin
      --'获取当单据据类型的下一单据状态';
      Pkg_Pln_Pub.p_Get_Order_Next_Status(p_Order_Type_Id    => v_Order_Type_Id,
                                          p_Curr_State       => v_Order_State,
                                          p_Curr_Action      => p_Operation_Action,
                                          p_Can_Option_Flag  => 'N',
                                          p_Next_Excute_Step => v_Next_Excute_Step,
                                          p_Nextauto_Excute  => v_Nextauto_Excute,
                                          p_Next_State       => v_Next_State,
                                          p_Next_Action      => v_Next_Action,
                                          p_Result           => p_Result);
      If p_Result <> v_Success Then
        p_Result := '获取订单下一状态失败！当前订单状态：' || v_Order_State || v_Nl ||
                    p_Result;
        Raise v_Base_Exception;
      End If;
    Exception
      When Others Then
        p_Result := p_Result;
        Raise v_Base_Exception;
    End;

    Begin
      --检查是否存在产地为空的行
      Select Count(*)
        Into v_Temp
        From t_Pln_Order_Line Lpol
       Where Lpol.Order_Head_Id = p_Order_Head_Id
         And Lpol.Entity_Id = v_Entity_Id
         And Lpol.Producing_Area_Id Is Null;
      If v_Temp > 0 Then
        p_Result := '存在未分产地的订单行数共有' || To_Char(v_Temp) || '行。';
        Raise v_Base_Exception;
      End If;
    Exception
      When Others Then
        p_Result := p_Result;
        Raise v_Base_Exception;
    End;

    --把以前前台的处理移到后台处理
    If v_Order_Type_Name = '工厂增补A' /*AND  --工厂增补
                   (P_SALES_CENTER_ID = -1 OR P_SALES_CENTER_ID IS NULL) */
     Then
      --检查是否为工厂增补,如果为工厂增补则检查是否录入中心
      p_Result := '请录入营销中心信息后，重新评审。';
      Return;
    Else
      v_Temp := 0;
      --如果不为工厂增补,则检查评审数量是否小于申请数量,如果小于必须录入评审意见
      Select Count(*)
        Into v_Count
        From t_Pln_Order_Line
       Where (Check_Qty + Nvl(Inv_Affirm_Qty, 0) < Apply_Qty And
             Check_Comment Is Null) --增加库存评审数量检查
         And Order_Head_Id = p_Order_Head_Id;
      If v_Temp > 0 Then
        p_Result := '存在评审数量小于申请数量,请录入总部评审意见！';
        Raise v_Base_Exception;
      End If;
    End If;

    --更新排产数量
    Update t_Pln_Order_Line
       Set Can_Produce_Qty = Check_Qty
     Where Order_Head_Id = p_Order_Head_Id;

    Update t_Pln_Order_Head h
       Set h.Form_State    = v_Next_State,
           h.Affirm_Flag   = 'N',
           h.Hq_Check_User = p_User_Code,
           h.Hq_Check_Date = Sysdate
     Where Order_Head_Id = p_Order_Head_Id;

    --检查库存评审数据，如果订单行全部为库存评审且评审数量=申请数量，单据修改成“已排产”
    Select Count(1)
      Into v_Count
      From t_Pln_Order_Line Ol
     Where Nvl(Ol.Apply_Qty, 0) <> Nvl(Ol.Inv_Affirm_Qty, 0)
       And Ol.Order_Head_Id = p_Order_Head_Id;
    If v_Count = 0 Then
      Update t_Pln_Order_Line l
         Set Status           = '32', --'已排产',
             Can_Produce_Qty  = 0,
             Last_Updated_By  = p_User_Code,
             Last_Update_Date = Sysdate
       Where Order_Head_Id = p_Order_Head_Id;

      Update t_Pln_Order_Head
         Set Form_State       = '32', --已排产
             Last_Updated_By  = p_User_Code,
             Last_Update_Date = Sysdate
       Where Order_Head_Id = p_Order_Head_Id;
    End If;

    /*IF V_ORDER_TYPE_NAME = '工厂增补' THEN  --工厂增补
      \*IF PKG_SM.F_SM_GET_ENTITY_PARAM('ORD中心报送周订单',
                                      V_ENTITY_ID) = 'Y' THEN*\
        --如果不需要中心确认,调用过程P_CT_AFFIRM_WEEK_ORDER,状态设为评审完毕
        P_AFFIRM_ORDER(P_ORDER_HEAD_ID, P_USER_CODE, P_RESULT, P_ERR_MSG);
    END IF;*/

    If p_Result <> v_Success Then
      Rollback;
    Else
      p_Result := v_Success;
    End If;
  Exception
    When v_Base_Exception Then
      p_Result := p_Result || v_Nl || Sqlerrm;
      Rollback;
    When Others Then
      p_Result := p_Result || v_Nl || Sqlerrm;
      Rollback;
  End;

  -----------------------------------------------------------------------------
  -- AUTHOR  : 张楚材
  -- CREATED : 2015-1-15
  -- PURPOSE : 厨电中心中心评审
  -- p_Result: 成功把回SUCCESS。
  -----------------------------------------------------------------------------
  Procedure p_Center_Review_Order(p_order_head_id    In Number, --订单头Id
                                  p_Operation_Action in varchar2, --动作
                                  p_user_code        varchar2, --用户
                                  p_Result           In Out Varchar2) is
    v_Tmp_Flag         Varchar2(1); --临时标识，01位长
    v_Entity_Id        Number;
    v_Order_Type_Id    Number;
    v_Order_Type_Name  Varchar2(50); --订单类型
    v_Customer_Id      Number;
    v_Period_Id        Number;
    v_Order_State      Varchar2(100);
    v_Next_Excute_Step Number;
    v_Next_Action      Varchar2(100);
    v_Nextauto_Excute  Varchar2(100);
    v_Next_State       Varchar2(100);

    v_Err_Number Number;
    v_Status     Varchar2(50); --辅助状态
    v_String     Varchar2(500); --辅助信息

    v_Defer_Supply_Days    Varchar2(200);
    n_Productng_Area_Count Number;
    p_Order_Number_l       Varchar2(100);
    v_Count                Number;
  Begin
    p_Result := v_Success;
    Begin
      Select Entity_Id, Customer_Id, Period_Id, Order_Type_Id, Form_State
        Into v_Entity_Id,
             v_Customer_Id,
             v_Period_Id,
             v_Order_Type_Id,
             v_Order_State
        From t_Pln_Order_Head
       Where Order_Head_Id = p_Order_Head_Id
         For Update Nowait;
    Exception
      When Others Then
        p_Result := '检查失败,锁定计划订单头失败';
        Raise v_Base_Exception;
    End;
    Select Count(1)
      Into v_Count
      From t_Pln_Order_Line Pol
     Where Pol.Order_Head_Id = p_Order_Head_Id
       And Nvl(Pol.Center_Check_Qty, 0) > Nvl(Pol.Check_Qty, 0);
    If v_Count > 0 Then
      p_Result := '订单行存在中心评审数量大于申请数量的数据，评审失败。';
      Raise v_Base_Exception;
    End If;
    Begin
      --'获取当单据据类型的下一单据状态';
      Pkg_Pln_Pub.p_Get_Order_Next_Status(p_Order_Type_Id    => v_Order_Type_Id,
                                          p_Curr_State       => v_Order_State,
                                          p_Curr_Action      => p_Operation_Action,
                                          p_Can_Option_Flag  => 'N',
                                          p_Next_Excute_Step => v_Next_Excute_Step,
                                          p_Nextauto_Excute  => v_Nextauto_Excute,
                                          p_Next_State       => v_Next_State,
                                          p_Next_Action      => v_Next_Action,
                                          p_Result           => p_Result);
      If p_Result <> v_Success Then
        p_Result := '获取订单下一状态失败！当前订单状态：' || v_Order_State || v_Nl ||
                    p_Result;
        Raise v_Base_Exception;
      End If;
    Exception
      When Others Then
        p_Result := p_Result;
        Raise v_Base_Exception;
    End;
    Update t_Pln_Order_Head
       Set Form_State        = v_Next_State,
           Last_Updated_By   = p_User_Code,
           Last_Update_Date  = Sysdate,
           Center_Check_User = p_User_Code,
           Center_Check_Date = Sysdate
     Where Order_Head_Id = p_Order_Head_Id;

    update t_pln_order_line l
       set l.can_produce_qty  = decode(nvl(l.center_check_qty, 0),
                                       0,
                                       l.can_produce_qty,
                                       l.center_check_qty),
           l.check_qty        = decode(nvl(l.center_check_qty, 0),
                                       0,
                                       l.check_qty,
                                       l.center_check_qty),
           l.last_updated_by  = p_user_code,
           l.last_update_date = sysdate
     where l.order_head_id = p_order_head_id;
  Exception
    When v_Base_Exception Then
      p_Result := p_Result;
      Rollback;
    When Others Then
      p_Result := p_Result || v_Nl || Sqlerrm;
      Rollback;
  End;

  -----------------------------------------------------------------------------
  ---- AUTHOR  : NICRO.LI
  -- CREATED : 2014-08-07 11:05:52
  -- PURPOSE : 单单库存评审
  -----------------------------------------------------------------------------
  Procedure p_Stock_Review_Order(p_Order_Head_Id    In Number, ----订单ID
                                 p_Operation_Action In Varchar2, --当前单据动作
                                 p_User_Code        In Varchar2, ----用户编码
                                 p_Result           Out Varchar2 --返回结果：成功返回"SUCCESS"，失败返回原因
                                 ) Is
    v_Tmp_Flag         Varchar2(1); --临时标识，01位长
    v_Entity_Id        Number;
    v_Order_Type_Id    Number;
    v_Order_Type_Name  Varchar2(50); --订单类型
    v_Customer_Id      Number;
    v_Period_Id        Number;
    v_Order_State      Varchar2(100);
    v_Next_Excute_Step Number;
    v_Next_Action      Varchar2(100);
    v_Nextauto_Excute  Varchar2(100);
    v_Next_State       Varchar2(100);

    v_Err_Number Number;
    v_Status     Varchar2(50); --辅助状态
    v_String     Varchar2(500); --辅助信息

    v_Defer_Supply_Days    Varchar2(200);
    n_Productng_Area_Count Number;
    p_Order_Number_l       Varchar2(100);
  Begin
    p_Result := v_Success;
    Begin
      Select Entity_Id, Customer_Id, Period_Id, Order_Type_Id, Form_State
        Into v_Entity_Id,
             v_Customer_Id,
             v_Period_Id,
             v_Order_Type_Id,
             v_Order_State
        From t_Pln_Order_Head
       Where Order_Head_Id = p_Order_Head_Id
         For Update Nowait;
    Exception
      When Others Then
        p_Result := '检查失败，请检查订单状态;当前单据可能已被退回';
        Raise v_Base_Exception;
    End;
    Begin
      --'获取当单据据类型的下一单据状态';
      Pkg_Pln_Pub.p_Get_Order_Next_Status(p_Order_Type_Id    => v_Order_Type_Id,
                                          p_Curr_State       => v_Order_State,
                                          p_Curr_Action      => p_Operation_Action,
                                          p_Can_Option_Flag  => v_True,
                                          p_Next_Excute_Step => v_Next_Excute_Step,
                                          p_Nextauto_Excute  => v_Nextauto_Excute,
                                          p_Next_State       => v_Next_State,
                                          p_Next_Action      => v_Next_Action,
                                          p_Result           => p_Result);
      If p_Result <> v_Success Then
        p_Result := '获取订单下一状态失败！当前订单状态：' || v_Order_State || v_Nl ||
                    p_Result;
        Raise v_Base_Exception;
      End If;
    Exception
      When Others Then
        p_Result := p_Result;
        Raise v_Base_Exception;
    End;

    Update t_Pln_Order_Head
       Set Form_State       = v_Next_State,
           Affirm_Flag      = v_False,
           Affirm_User      = p_User_Code,
           Affirm_Date      = Sysdate,
           Last_Updated_By  = p_User_Code,
           Last_Update_Date = Sysdate
     Where Order_Head_Id = p_Order_Head_Id;
  Exception
    When v_Base_Exception Then
      Rollback;
    When Others Then
      Rollback;
  End;

  -----------------------------------------------------------------------------
  ---- AUTHOR  : 吴泽军
  -- CREATED : 2014-08-07 11:05:52
  -- PURPOSE : 单单订单中心确认
  -----------------------------------------------------------------------------
  Procedure p_Center_Confirm_Order(p_Order_Head_Id    In Number, ----订单ID
                                  p_Operation_Action In Varchar2, --当前单据动作
                                  p_User_Code        In Varchar2, ----用户编码
                                  p_Result           Out Varchar2 --返回结果：成功返回"SUCCESS"，失败返回原因
                                  ) Is

    v_Tmp_Flag         Varchar2(1); --临时标识，01位长
    v_Entity_Id        Number;
    v_Order_Type_Id    Number;
    v_Order_Type_Name  Varchar2(50); --订单类型
    v_Customer_Id      Number;
    v_Period_Id        Number;
    v_Order_State      Varchar2(100);
    v_Next_Excute_Step Number;
    v_Next_Action      Varchar2(100);
    v_Nextauto_Excute  Varchar2(100);
    v_Next_State       Varchar2(100);
    v_Period_Type      Varchar2(100);

    v_Err_Number Number;
    v_Status     Varchar2(50); --辅助状态
    v_String     Varchar2(500); --辅助信息

    v_Defer_Supply_Days    Varchar2(200);
    n_Productng_Area_Count Number;
    p_Order_Number_l       Varchar2(100);
  Begin
    p_Result := v_Success;
    --V_RESULT := SUBSTRB(('临时订单评审完毕' || '失败' || V_NL), 1, 50);
    v_Status := Substrb((v_Nl || '初始化' || '：'), 1, 50);
    v_String := Substrb((v_Nl || v_Nl || '订单ID：' ||
                        To_Char(p_Order_Head_Id) || v_Nl || '用户编码：' ||
                        p_User_Code || v_Nl),
                        1,
                        500);

    v_Status := Substrb((v_Nl || '输入参数检查' || '：'), 1, 50);
    If p_Order_Head_Id Is Null Or p_User_Code Is Null Then
      p_Result := Substrb((v_Result || v_Status || '部分参数为空或错误' || v_String),
                          1,
                          2000);
      Raise v_Base_Exception;
    End If;

    v_Status := Substrb((v_Nl || '检查订单状态，并读锁定' || '：'), 1, 50);
    Begin
      Select Entity_Id, Customer_Id, Period_Id, Order_Type_Id, Form_State
        Into v_Entity_Id,
             v_Customer_Id,
             v_Period_Id,
             v_Order_Type_Id,
             v_Order_State
        From t_Pln_Order_Head
       Where Order_Head_Id = p_Order_Head_Id
         --And (Form_State In ('26', '20', '30') --'已库存评审、送审、需中心确认'
          --   Or Order_Type_Name = '工厂增补')
      --AND (FORM_STATE IN ('已总部评审', '需中心确认') OR ORDER_TYPE_NAME = '工厂增补')
         For Update Nowait;
    Exception
      When Others Then
        p_Result := Substrb((v_Result || v_Status ||
                            '检查失败，请检查订单状态;当前单据可能已被退回' || v_String),
                            1,
                            2000);
        Raise v_Base_Exception;
    End;

    Begin
      Select p.Period_Type
        Into v_Period_Type
        From t_Pln_Order_Period p
       Where p.Entity_Id = v_Entity_Id
         And p.Period_Id = v_Period_Id;
    Exception
      When Others Then
        p_Result := '获取周期类型失败,周期ID：' || v_Period_Id;
        Raise v_Base_Exception;
    End;

    --检查当前主体产地数量
    Select Count(*)
      Into n_Productng_Area_Count
      From t_Pln_Producing_Area p
     Where p.Entity_Id = v_Entity_Id;
    --主体产地数小于2个的主体,不检查产品产地
    If n_Productng_Area_Count > 1 Then
      --检查临时订单单据行,产品是否属于当前订单产地
      p_Chk_Order_Line_Mtl_Producing(p_Order_Head_Id, p_Result);
      If p_Result <> v_Success Then
        Raise v_Base_Exception;
      End If;
    End If;

    --对于 '需中心确认' 的单据检查 中心信用余额(以前是在前台处理,现在放到后台)
    --BEGIN
    --取中心是否分扣余款的标志
    --IF PKG_SM.F_SM_GET_ENTITY_PARAM('PLN4_WOD_CUS_BLC_CHK', V_FINANCE_MAIN_ENTITY_ID) = 'Y'
    --THEN
    --P_GET_CUSTOMER_BALANCE(V_CUSTOMER_ID
    --,N_DISCOUNT_TYPE_ID
    --,P_ORDER_HEAD_ID
    --,P_USER_CODE
    --,N_CUSTOMER_BALANCE
    --,'N'      --扣除已送审未评审完毕的订单金额：“Y”是“N”否
    --,P_RESULT);

    --IF P_RESULT = V_SUCCESS AND
    --N_CUSTOMER_BALANCE < N_ORDER_AMOUNT THEN
    --P_RESULT := '中心信用余额小于订单金额，不能评审！';
    --RETURN;
    --ELSIF P_RESULT <> V_SUCCESS THEN
    --P_RESULT := '订单为需中心确认状态,取中心信用余款出错';
    --RETURN;
    --END IF;
    --END IF;
    --END;

    --检查本周
    p_Result := v_Success;
    Pkg_Pln_Pub.p_Check_Period(v_Period_Id,
                               v_Period_Type,
                               'Y',
                               'N',
                               'O',
                               p_Result);
    If Nvl(p_Result, v_Null) <> v_Success Then
      p_Result := Substrb((p_Result), 1, 2000);
      Raise v_Base_Exception;
    End If;

    --检查中心
    --PKG_PUB_F_P.P_CHK_CUSTOMER(V_FINANCE_MAIN_ENTITY_ID, V_ENTITY_ID, V_CUSTOMER_ID, V_Y, V_Y, V_CUSTOMER_CODE, V_CUSTOMER_NAME, P_RESULT);
    --IF NVL(P_RESULT, V_NULL) <> V_SUCCESS
    --THEN
    --P_RESULT := SUBSTRB((V_RESULT || P_RESULT), 1, 2000);
    --RETURN;
    --END IF;

    --订单明细检查
    --P_RESULT := V_ERROR;
    --P_DETAIL_WEEK_ORDER(P_ORDER_HEAD_ID, 3, P_RESULT);
    /*IF NVL(P_RESULT, V_NULL) <> V_SUCCESS
    THEN
      P_RESULT := SUBSTRB((V_RESULT || P_RESULT), 1, 2000);
      RETURN;
    END IF;*/

    --根据主体参数'PLN4_ERP_NUM_RULE'取延迟入库天数
    --BEGIN
    --SELECT NVL(DEFER_SUPPLY_DAYS,0)
    --INTO N_DEFER_SUPPLY_DAYS
    --FROM T_PLN4_ORDER_TYPE
    --WHERE ORDER_TYPE = V_ORDER_TYPE
    --AND FINANCE_MAIN_ENTITY_ID = V_FINANCE_MAIN_ENTITY_ID;
    --EXCEPTION
    --WHEN NO_DATA_FOUND THEN
    --N_DEFER_SUPPLY_DAYS := 0;
    --WHEN OTHERS THEN
    --P_RESULT := '取主体参数PLN4_ERP_NUM_RULE出错,出错代码位置PLN4.P_CT_AFFIRM_WEEK_ORDER';
    --RETURN;
    --END;

    Begin
      --'获取当单据据类型的下一单据状态';
      Pkg_Pln_Pub.p_Get_Order_Next_Status(p_Order_Type_Id    => v_Order_Type_Id,
                                          p_Curr_State       => v_Order_State,
                                          p_Curr_Action      => p_Operation_Action,
                                          p_Can_Option_Flag  => 'N',
                                          p_Next_Excute_Step => v_Next_Excute_Step,
                                          p_Nextauto_Excute  => v_Nextauto_Excute,
                                          p_Next_State       => v_Next_State,
                                          p_Next_Action      => v_Next_Action,
                                          p_Result           => p_Result);
      If p_Result <> v_Success Then
        p_Result := '获取订单下一状态失败！当前订单状态：' || v_Order_State || v_Nl ||
                    p_Result;
        Raise v_Base_Exception;
      End If;
    Exception
      When Others Then
        p_Result := p_Result;
        Raise v_Base_Exception;
    End;

    --将订单状态改为“评审完毕”
    Update t_Pln_Order_Head
       Set Form_State = v_Next_State,
           -- 通过变量获取状态
           --STATUS           = V_ORDER_STATE,
           Affirm_Flag      = v_True,
           Hq_Check_User    = Decode(Hq_Check_User,
                                     Null,
                                     p_User_Code,
                                     Hq_Check_User),
           Hq_Check_Date    = Decode(Hq_Check_Date,
                                     Null,
                                     Sysdate,
                                     Hq_Check_Date),
           Fc_Check_User    = Decode(Fc_Check_User,
                                     Null,
                                     p_User_Code,
                                     Fc_Check_User),
           Fc_Check_Date    = Decode(Fc_Check_Date,
                                     Null,
                                     Sysdate,
                                     Fc_Check_Date),
           Affirm_User      = p_User_Code,
           Affirm_Date      = Sysdate,
           Last_Updated_By  = p_User_Code,
           Last_Update_Date = Sysdate
     Where Order_Head_Id = p_Order_Head_Id;

    p_Result := v_Success;
  Exception
    When v_Base_Exception Then
      p_Result := p_Result || '，失败。' || v_Nl || Sqlerrm;
      Rollback;
    When Others Then
      p_Result := Substrb((v_Result || v_Status || '未知错误' || v_Nl ||
                          Sqlerrm || v_String),
                          1,
                          2000);
      Rollback;
      Return;
  End;

  -----------------------------------------------------------------------------
  ---- AUTHOR  : NICRO.LI
  ---PURPOSE:[订单动作]工厂评审
  -----------------------------------------------------------------------------
  Procedure p_Fc_Check_Order(p_Order_Head_Id    In Number, ----订单ID
                             p_Operation_Action In Varchar2, --当前单据动作
                             p_User_Code        In Varchar2, ----用户编码
                             p_Result           Out Varchar2 --返回结果：成功返回"SUCCESS"，失败返回原因
                             ) Is
    v_Tmp_Flag         Varchar2(1); --临时标识，01位长
    v_Entity_Id        Number;
    v_Order_Type_Id    Number;
    v_Order_Type_Name  Varchar2(50); --订单类型
    v_Customer_Id      Number;
    v_Period_Id        Number;
    v_Order_State      Varchar2(100);
    v_Next_Excute_Step Number;
    v_Next_Action      Varchar2(100);
    v_Nextauto_Excute  Varchar2(100);
    v_Next_State       Varchar2(100);
    v_Period_Type      Varchar2(100);
    v_Count            Number;
  Begin
    p_Result := v_Success;
    Select Oh.Form_State, Oh.Order_Type_Id
      Into v_Order_State, v_Order_Type_Id
      From t_Pln_Order_Head Oh
     Where Oh.Order_Head_Id = p_Order_Head_Id;

    --检查是否需要中心确认，CIMS系统暂不做中心确认检查
    v_Count := 0;
    /*Select \*Count(*)*\ 0
     Into v_Count
     From t_Pln_Order_Line l
    Where l.Order_Head_Id = p_Order_Head_Id
      And (l.Can_Produce_Qty + Nvl(l.Inv_Affirm_Qty, 0) < Apply_Qty Or
          Trunc(Sysdate) > l.End_Supply_Date);*/
    --ADD BY LIZHEN 2015-04-09 工厂评审时，更新已排产数量
    --更新排产数量
    Update t_Pln_Order_Line
       Set Can_Produce_Qty = Check_Qty
     Where Order_Head_Id = p_Order_Head_Id;

    If v_Count > 0 Then
      Begin
        --'获取当单据据类型的下一单据状态';
        Pkg_Pln_Pub.p_Get_Order_Next_Status(p_Order_Type_Id    => v_Order_Type_Id,
                                            p_Curr_State       => v_Order_State,
                                            p_Curr_Action      => p_Operation_Action,
                                            p_Can_Option_Flag  => 'Y',
                                            p_Next_Excute_Step => v_Next_Excute_Step,
                                            p_Nextauto_Excute  => v_Nextauto_Excute,
                                            p_Next_State       => v_Next_State,
                                            p_Next_Action      => v_Next_Action,
                                            p_Result           => p_Result);
        If p_Result <> v_Success Then
          p_Result := '获取订单下一状态失败！当前订单状态：' || v_Order_State || v_Nl ||
                    p_Result;
          Raise v_Base_Exception;
        End If;
      Exception
        When Others Then
          p_Result := p_Result;
          Raise v_Base_Exception;
      End;

      --需要中心确认
      Update t_Pln_Order_Head
         Set Form_State    = v_Next_State,
             Affirm_Flag   = v_False,
             Fc_Check_Date = Sysdate,
             Fc_Check_User = p_User_Code
       Where Order_Head_Id = p_Order_Head_Id;
      p_Result := v_Success;
    Else
      --不需要中心确认
      p_Center_Confirm_Order(p_Order_Head_Id,

                            p_Operation_Action,
                            p_User_Code,
                            p_Result);
    End If;
  Exception
    When v_Base_Exception Then
      Rollback;
      p_Result := p_Result || '，工厂评审失败!';
    When Others Then
      Rollback;
      p_Result := p_Result || '，工厂评审失败!';
  End;

  -----------------------------------------------------------------------------
  ---- AUTHOR  : NICRO.LI
  -- CREATED : 2014-07-16 11:05:52
  -- PURPOSE : 系统自动更新新排产标志过程，
  -----------------------------------------------------------------------------
  Procedure p_Auto_Produce_Order(p_Order_Head_Id    In Number, ----订单ID
                                 p_Operation_Action In Varchar2, --当前单据动作
                                 p_User_Code        In Varchar2, ----用户编码
                                 p_Result           Out Varchar2 --返回结果：成功返回"SUCCESS"，失败返回原因
                                 ) Is
    v_Order_State      Varchar2(100);
    v_Next_Excute_Step Number;
    v_Next_Action      Varchar2(100);
    v_Nextauto_Excute  Varchar2(100);
    v_Next_State       Varchar2(100);
    v_Order_Type_Id    Number;
    v_Entity_Id        Number;
  Begin
    --检查输入参数
    If p_Order_Head_Id Is Null Or p_User_Code Is Null Then
      p_Result := '修改订单排产状态修改失败，输入参数部分为空或错误';
    Else
      --初始返回结果
      p_Result := v_Success;
    End If;

    Begin
      Select Entity_Id, Order_Type_Id, Form_State
        Into v_Entity_Id, v_Order_Type_Id, v_Order_State
        From t_Pln_Order_Head
       Where Order_Head_Id = p_Order_Head_Id
         For Update Nowait;
    Exception
      When Others Then
        p_Result := '检查失败，请检查订单状态;当前单据可能已被退回。' || v_Nl || Sqlerrm;
    End;

    Begin
      --'获取当单据据类型的下一单据状态';
      Pkg_Pln_Pub.p_Get_Order_Next_Status(p_Order_Type_Id    => v_Order_Type_Id,
                                          p_Curr_State       => v_Order_State,
                                          p_Curr_Action      => p_Operation_Action,
                                          p_Can_Option_Flag  => 'N',
                                          p_Next_Excute_Step => v_Next_Excute_Step,
                                          p_Nextauto_Excute  => v_Nextauto_Excute,
                                          p_Next_State       => v_Next_State,
                                          p_Next_Action      => v_Next_Action,
                                          p_Result           => p_Result);
      If p_Result <> v_Success Then
        p_Result := '获取订单下一状态失败！当前订单状态：' || v_Order_State || v_Nl ||
                    p_Result;
      End If;
    Exception
      When Others Then
        p_Result := '获取订单下一状态失败！当前订单状态：' || v_Order_State || v_Nl ||
                    Sqlerrm;
    End;

    --修改订单为已排产状态
    If Nvl(p_Result, v_Null) = v_Success Then
      --修改订单头为已排产状态
      Update t_Pln_Order_Head
         Set Form_State       = v_Next_State,
             Last_Updated_By  = p_User_Code,
             Last_Update_Date = Sysdate
       Where Order_Head_Id = p_Order_Head_Id;

      --修改订单行为已排产状态
      Update t_Pln_Order_Line l
         Set /*AP_MTL_QTY = NVL(CAN_PRODUCE_QTY, 0) -
             NVL(L.CANCEL_INV_IN_QTY, 0) -
             NVL(L.CANCEL_INV_CHECK_QTY, 0),*/ Status = v_Next_State
       Where Order_Head_Id = p_Order_Head_Id;
    End If;
    If p_Result <> v_Success Then
      Rollback;
    End If;
  Exception
    When Others Then
      p_Result := '失败原因：' || p_Result;
  End;

  -----------------------------------------------------------------------------
  ---- AUTHOR  : NICRO.LI
  -- CREATED : 2014-07-16 11:05:52
  -- PURPOSE : 订单退回、审核驳回
  -----------------------------------------------------------------------------
  Procedure p_Back_Order(p_Order_Head_Id      In Number, ----订单头ID(如果没有则需传入-1)
                         p_Operation_Action   In Varchar2, --订单当前操作类型
                         p_User_Code          In Varchar2, ----用户编码
                         p_Result             In Out Varchar2, ----退回原因,/返回结果
                         p_Order_Collect_Flag In Varchar2 Default 'N' --是否为汇总订单
                         ) Is
    n_Count              Number;
    v_Next_Status        Varchar2(100);
    v_Back_Message       Varchar2(4000);
    v_Message            Varchar2(4000);
    v_Total_Order_Type   Varchar2(2);
    v_Is_Inv_Affirm_Flag Varchar2(10);
    v_Current_Status     Varchar2(100);
    --V_PROGRAM          VARCHAR2(50) := 'PKG_PLN4.P_PLN4_BACK';

    r_Order_Type          t_Pln_Order_Type%Rowtype;
    r_Order_Head           t_Pln_Order_Head%Rowtype;
    v_Pln_Capacity_Modle   Varchar2(32);
    v_Is_Capacity          Varchar2(32) := 'N';
    v_Count                Number := 0;
    v_Entity_Id            Number;
    v_Order_Type_Id        Number;
  Begin
    v_Back_Message := p_Result;
    p_Result       := v_Success;

/*    Select ot.*
      Into r_Order_Type
      From cims.t_Pln_Order_Head oh,
           cims.t_Pln_Order_Type ot
     Where oh.order_type_id = ot.order_type_id
       And oh.entity_id = ot.entity_id
       And oh.Order_Head_Id = p_Order_Head_Id;*/

    If p_Order_Collect_Flag <> v_False Then
      --汇总订单
      Begin
        v_Message := '取订单退回目标状态失败';
        Select To_Char(Fs.Next_Status_Id),
               Ot.Is_Inv_Affirm_Flag,
               Ch.Form_State,
               Ot.Entity_Id,    --add by lizhen 2017-05-05
               Ot.Is_Pln_Capacity,  --add by lizhen 2017-05-05
               Ot.Order_Type_Id     --add by lizhen 2017-05-05
          Into v_Next_Status,
               v_Is_Inv_Affirm_Flag,
               v_Current_Status,
               v_Entity_Id,     --add by lizhen 2017-05-05
               v_Is_Capacity,   --add by lizhen 2017-05-05
               v_Order_Type_Id  --add by lizhen 2017-05-05
          From t_Pln_Flow_Status        Fs,
               t_Pln_Flow               Tpl,
               t_Pln_Order_Type         Ot,
               t_Pln_Order_Collect_Head Ch
         Where Fs.Action_Code = p_Operation_Action
           And Fs.Flow_Id = Tpl.Flow_Id
           And Ot.Flow_Id = Fs.Flow_Id
           And Fs.Curr_Status_Id = Ch.Form_State
           And Ot.Order_Type_Id = Ch.Order_Type_Id
           And Ot.Entity_Id = Ch.Entity_Id
           And Ch.Coll_Ord_Head_Id = p_Order_Head_Id;
      Exception
        When Others Then
          p_Result := '获取订单退回的下一状态失败，汇总订单头ID：' || To_Char(p_Order_Head_Id);
      End;
      If p_Result = v_Success And
         Nvl(v_Is_Inv_Affirm_Flag, v_False) = v_True And
         v_Current_Status = 26 Then
        p_Result := '汇总的单据类型为需库存评审，不允许从库存评审状态退回！' || v_Nl || '汇总订单头ID：' ||
                    To_Char(p_Order_Head_Id);
      End If;
      --获取系统参数产能可视模式参数
      Begin
        v_Pln_Capacity_Modle := Pkg_Bd.f_Get_Parameter_Value('PLN_CAPACITY_MODEL',
                                                             v_Entity_Id);
      Exception
        When Others Then
          p_Result := '获取产能可视模式参数PLN_CAPACITY_MODEL参数失败！' || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
      End;

      --add by lizhen 2017-05-05
      If v_Pln_Capacity_Modle = 'CIMS' And v_Is_Capacity = 'Y' And v_Next_Status In ('19', '303', '304', '305') Then
        --检查是否存在未处理完的产能占用，存在则一直循环直到处理完为止
        Begin
          Select 1
            Into v_Count
            From t_Pln_Capacity_Single_Process Csp
           Where Csp.Entity_Id = v_Entity_Id For Update;
        Exception
          When Others Then
            p_Result := '检查产能占用事务串行记录表失败!' || v_Nl || Sqlerrm;
            Raise v_Base_Exception;
        End;
        For r_Order_Head In (Select Distinct Pol.Order_Head_Id,
                                             Poh.Refer_Date
                               From t_Pln_Order_Collect_Relation Ocr,
                                    t_Pln_Order_Collect_Head     Och,
                                    t_Pln_Order_Line             Pol,
                                    t_Pln_Order_Head             Poh
                              Where Ocr.Order_Collect_Head_Id = Och.Coll_Ord_Head_Id
                                And Ocr.Order_Line_Id = Pol.Order_Line_Id
                                And Pol.Order_Head_Id = Poh.Order_Head_Id
                                And Poh.Order_Type_Id = v_Order_Type_Id
                                And Och.Entity_Id = v_Entity_Id
                                And Och.Coll_Ord_Head_Id = p_Order_Head_Id) Loop
          Pkg_Pln_Capacity.p_Capacity_Occupy_New(p_Order_Head_Id    => r_Order_Head.Order_Head_Id,
                                                 p_Order_Type_Id    => v_Order_Type_Id,
                                                 p_Order_Check_Date => Trunc(r_Order_Head.Refer_Date),
                                                 p_Capacity_Sign    => -1,
                                                 --modi by lizhen 2017-08-30
                                                 p_Capacity_Type    => Pkg_Bd.f_Get_Parameter_Value(p_Config_Code => 'PLN_CAPACITY_PERIOD_TYPE', p_Entity_Id => v_Entity_Id),
                                                 p_User_Code        => p_User_Code,
                                                 p_Result           => p_Result);
          If p_Result != v_Success Then
            Raise v_Base_Exception;
          End If;

          Update t_Pln_Order_Line Lol
             Set Lol.To_Aps_Capacity_Qty   = Null,
                 Lol.Aps_Capacity_Rec_Qty  = Null,
                 Lol.Aps_Capacity_Rec_Date = Null,
                 Lol.Version               = Nvl(Lol.Version, 0) + 1
           Where Lol.Order_Head_Id = r_Order_Head.Order_Head_Id;

          Update t_Pln_Order_Head Poh
           Set Poh.Aps_Capacity_State    = 'N',
               Poh.Aps_Capacity_Rec_Date = Null,
               Poh.Last_Updated_By       = p_User_Code,
               Poh.Last_Update_Date      = Sysdate,
               Poh.Version               = Nvl(Poh.Version, 0) + 1
         Where Order_Head_Id = r_Order_Head.Order_Head_Id;
        End Loop;
      End If;

      If p_Result = v_Success Then
        Update t_Pln_Order_Collect_Head
           Set Form_State = v_Next_Status, Remark = v_Back_Message
         Where Coll_Ord_Head_Id = p_Order_Head_Id;
      End If;

    Else
      --非汇总订单
      Select Oh.*
        Into r_Order_Head
        From Cims.t_Pln_Order_Head Oh
       Where Oh.Order_Head_Id = p_Order_Head_Id;
      --add by lizhen 2017-05-05
      --获取系统参数产能可视模式参数
      Begin
        v_Pln_Capacity_Modle := Pkg_Bd.f_Get_Parameter_Value('PLN_CAPACITY_MODEL',
                                                             r_Order_Head.Entity_Id);
      Exception
        When Others Then
          p_Result := '获取产能可视模式参数PLN_CAPACITY_MODEL参数失败！' || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
      End;

      Begin
        v_Message := '取订单退回目标状态失败';
        Select To_Char(Fs.Next_Status_Id),
               Ot.Is_Pln_Capacity,--add by lizhen 2017-05-05
               Ot.Order_Type_Id  --add by lizhen 2017-05-05
          Into v_Next_Status, v_Is_Capacity, v_Order_Type_Id --add by lizhen 2016-12-29
          From t_Pln_Flow_Status Fs,
               t_Pln_Flow        Tpl,
               t_Pln_Order_Type  Ot,
               t_Pln_Order_Head  Oh
         Where Fs.Action_Code = p_Operation_Action
           And Fs.Flow_Id = Tpl.Flow_Id
           And Ot.Flow_Id = Fs.Flow_Id
           And Fs.Curr_Status_Id = Oh.Form_State
           And Ot.Order_Type_Id = Oh.Order_Type_Id
           And Ot.Entity_Id = Oh.Entity_Id
           And Oh.Order_Head_Id = p_Order_Head_Id;
      Exception
        When Others Then
          p_Result := '获取订单退回的下一状态失败，汇总订单头ID：' || To_Char(p_Order_Head_Id);
          Raise v_Base_Exception;
      End;

      --add by lizhen 2017-05-05 产能可视处理
      If v_Pln_Capacity_Modle = 'CIMS' And v_Is_Capacity = 'Y' And v_Next_Status In ('19', '303', '304', '305') Then
        --检查是否存在未处理完的产能占用，存在则一直循环直到处理完为止
        Begin
          Select 1
            Into v_Count
            From t_Pln_Capacity_Single_Process Csp
           Where Csp.Entity_Id = r_Order_Head.Entity_Id For Update;
        Exception
          When Others Then
            p_Result := '检查产能占用事务串行记录表失败!' || v_Nl || Sqlerrm;
            Raise v_Base_Exception;
        End;

        --modi by lizhen 2017-05-18产能使用实时计算退回时不需做产能处理
        Pkg_Pln_Capacity.p_Capacity_Occupy_New(p_Order_Head_Id    => p_Order_Head_Id,
                                               p_Order_Type_Id    => v_Order_Type_Id,
                                               p_Order_Check_Date => Trunc(r_Order_Head.Refer_Date),
                                               p_Capacity_Sign    => -1,
                                               --modi by lizhen 2017-08-30
                                               p_Capacity_Type    => Pkg_Bd.f_Get_Parameter_Value(p_Config_Code => 'PLN_CAPACITY_PERIOD_TYPE', p_Entity_Id => v_Entity_Id),
                                               p_User_Code        => p_User_Code,
                                               p_Result           => p_Result);
        If p_Result != v_Success Then
          Raise v_Base_Exception;
        End If;


        Update t_Pln_Order_Line Lol
           Set Lol.To_Aps_Capacity_Qty   = Null,
               Lol.Aps_Capacity_Rec_Qty  = Null,
               Lol.Aps_Capacity_Rec_Date = Null,
               Lol.Version               = Nvl(Lol.Version, 0) + 1
        Where Lol.Order_Head_Id = p_Order_Head_Id;
      End If;

      If p_Result = v_Success Then
        Update t_Pln_Order_Head
           Set Form_State    = v_Next_Status,
               Back_Reason   = v_Back_Message,
               Hq_Check_Date = Trunc(Sysdate)
         Where Order_Head_Id = p_Order_Head_Id;
      End If;

      --解款
      If v_Next_Status = 19 And nvl(r_Order_Head.Lock_Amount_Flag,'_') = 'S'Then
        Pkg_Pln_Lg_Order.p_LockOrRelease_Money(p_Entity_Id        => r_Order_Head.Entity_Id,
                                               p_Order_Head_Id    => p_Order_Head_Id,
                                               p_Action_Type      => 2,
                                               p_User_Code        => p_User_Code,
                                               p_Result           => p_Result);
        If p_Result <> v_Success Then
           p_Result := '检查并锁定资金失败，订单头ID：。' || p_Order_Head_Id || v_Nl ||
                        p_Result;
          Raise v_Base_Exception;
        End If;
      End If;
      --add by lizhen 2017-05-05 更新产能可视处理标志
      If v_Pln_Capacity_Modle = 'CIMS' And v_Is_Capacity = 'Y' And v_Next_Status In ('19', '303', '304', '305') Then
        Update t_Pln_Order_Head Poh
           Set Poh.Aps_Capacity_State    = 'N',
               Poh.Aps_Capacity_Rec_Date = Null,
               Poh.Last_Updated_By       = p_User_Code,
               Poh.Last_Update_Date      = Sysdate,
               Poh.Version               = Nvl(Poh.Version, 0) + 1
         Where Order_Head_Id = p_Order_Head_Id;
      End If;
    End If;

  Exception
    When Others Then
      p_Result := v_Message || v_Nl || Sqlerrm;
  End;
  -----------------------------------------------------------------------------
  ---- AUTHOR  : 吴泽军
  -- CREATED : 2014-08-07 11:05:52
  -- PURPOSE : 单单订单中心确认
  -----------------------------------------------------------------------------
  Procedure p_Hq_Confirm_Order(p_Order_Head_Id    In Number, ----订单ID
                              p_Operation_Action In Varchar2, --当前单据动作
                              p_User_Code        In Varchar2, ----用户编码
                              p_Result           Out Varchar2 --返回结果：成功返回"SUCCESS"，失败返回原因
                              ) Is

    v_Tmp_Flag         Varchar2(1); --临时标识，01位长
    v_Entity_Id        Number;
    v_Order_Type_Id    Number;
    v_Order_Type_Name  Varchar2(50); --订单类型
    v_Customer_Id      Number;
    v_Period_Id        Number;
    v_Order_State      Varchar2(100);
    v_Next_Excute_Step Number;
    v_Next_Action      Varchar2(100);
    v_Nextauto_Excute  Varchar2(100);
    v_Next_State       Varchar2(100);
    v_Period_Type      Varchar2(100);

    v_Err_Number Number;
    v_Status     Varchar2(50); --辅助状态
    v_String     Varchar2(500); --辅助信息

    v_Defer_Supply_Days    Varchar2(200);
    n_Productng_Area_Count Number;
    p_Order_Number_l       Varchar2(100);
  Begin
    p_Result := v_Success;
    --V_RESULT := SUBSTRB(('临时订单评审完毕' || '失败' || V_NL), 1, 50);
    v_Status := Substrb((v_Nl || '初始化' || '：'), 1, 50);
    v_String := Substrb((v_Nl || v_Nl || '订单ID：' ||
                        To_Char(p_Order_Head_Id) || v_Nl || '用户编码：' ||
                        p_User_Code || v_Nl),
                        1,
                        500);

    v_Status := Substrb((v_Nl || '输入参数检查' || '：'), 1, 50);
    If p_Order_Head_Id Is Null Or p_User_Code Is Null Then
      p_Result := Substrb((v_Result || v_Status || '部分参数为空或错误' || v_String),
                          1,
                          2000);
      Raise v_Base_Exception;
    End If;

    v_Status := Substrb((v_Nl || '检查订单状态，并读锁定' || '：'), 1, 50);
    Begin
      Select Entity_Id, Customer_Id, Period_Id, Order_Type_Id, Form_State
        Into v_Entity_Id,
             v_Customer_Id,
             v_Period_Id,
             v_Order_Type_Id,
             v_Order_State
        From t_Pln_Order_Head
       Where Order_Head_Id = p_Order_Head_Id
         --And Form_State In ('639') --'已APS产销平衡'
      --AND (FORM_STATE IN ('已总部评审', '需中心确认') OR ORDER_TYPE_NAME = '工厂增补')
         For Update Nowait;
    Exception
      When Others Then
        p_Result := Substrb((v_Result || v_Status ||
                            '检查失败，请检查订单状态;当前单据可能已被退回' || v_String),
                            1,
                            2000);
        Raise v_Base_Exception;
    End;

    Begin
      Select p.Period_Type
        Into v_Period_Type
        From t_Pln_Order_Period p
       Where p.Entity_Id = v_Entity_Id
         And p.Period_Id = v_Period_Id;
    Exception
      When Others Then
        p_Result := '获取周期类型失败,周期ID：' || v_Period_Id || V_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;

    --检查本周
    p_Result := v_Success;
    Pkg_Pln_Pub.p_Check_Period(v_Period_Id,
                               v_Period_Type,
                               'Y',
                               'N',
                               'O',
                               p_Result);
    If Nvl(p_Result, v_Null) <> v_Success Then
      p_Result := Substrb((p_Result), 1, 2000);
      Raise v_Base_Exception;
    End If;

    Begin
      --'获取当单据据类型的下一单据状态';
      Pkg_Pln_Pub.p_Get_Order_Next_Status(p_Order_Type_Id    => v_Order_Type_Id,
                                          p_Curr_State       => v_Order_State,
                                          p_Curr_Action      => p_Operation_Action,
                                          p_Can_Option_Flag  => 'N',
                                          p_Next_Excute_Step => v_Next_Excute_Step,
                                          p_Nextauto_Excute  => v_Nextauto_Excute,
                                          p_Next_State       => v_Next_State,
                                          p_Next_Action      => v_Next_Action,
                                          p_Result           => p_Result);
      If p_Result <> v_Success Then
        p_Result := '获取订单下一状态失败！当前订单状态：' || v_Order_State || v_Nl ||
                    p_Result;
        Raise v_Base_Exception;
      End If;
    Exception
      When Others Then
        p_Result := p_Result;
        Raise v_Base_Exception;
    End;

    --将订单状态改为“评审完毕”
    Update t_Pln_Order_Head
       Set Form_State       = v_Next_State,
           Hq_Confirm_By    = p_User_Code,
           Hq_Confirm_Date  = Sysdate,
           Last_Updated_By  = p_User_Code,
           Last_Update_Date = Sysdate
     Where Order_Head_Id = p_Order_Head_Id;
    p_Result := v_Success;
  Exception
    When v_Base_Exception Then
      p_Result := p_Result || '，失败。' || v_Nl || Sqlerrm;
      Rollback;
    When Others Then
      p_Result := Substrb((v_Result || v_Status || '未知错误' || v_Nl ||
                          Sqlerrm || v_String),
                          1,
                          2000);
      Rollback;
      Return;
  End;

  -----------------------------------------------------------------------------
  ---- AUTHOR  : NICRO.LI
  -- CREATED : 2014-11-12
  -- PURPOSE : 单单订单  APS产销平衡
  -----------------------------------------------------------------------------
  Procedure p_Aps_Order_Promise(p_Order_Head_Id    In Number, ----订单ID
                                p_Operation_Action In Varchar2, --当前单据动作
                                p_User_Code        In Varchar2, ----用户ID
                                p_Result           Out Varchar2 --返回结果：成功返回"SUCCESS"，失败返回原因
                                ) Is
    v_Tmp_Flag          Varchar2(1); --临时标识，01位长
    v_Entity_Id         Number;
    v_Order_Type_Id     Number;
    v_Order_Type_Name   Varchar2(50); --订单类型
    v_Customer_Id       Number;
    v_Period_Id         Number;
    v_Order_State       Varchar2(100);
    v_Next_Excute_Step  Number;
    v_Next_Action       Varchar2(100);
    v_Nextauto_Excute   Varchar2(100);
    v_Next_State        Varchar2(100);
    v_Period_Type       Varchar2(100);
    v_Pln_Wip_Ord_Match Varchar2(10);

    v_Value      Varchar2(2000);
    r_Order_Head t_Pln_Order_Head%Rowtype;
    r_Order_Type t_Pln_Order_Type%Rowtype;
  Begin
    p_Result := v_Success;
    If p_Order_Head_Id Is Null Or p_User_Code Is Null Then
      p_Result := '部分参数为空或错误';
      Raise v_Base_Exception;
    End If;

    Begin
      Select *
        Into r_Order_Head
        From t_Pln_Order_Head h
       Where Order_Head_Id = p_Order_Head_Id
         --And Form_State In ('22') --汇总订单状态“已工厂评审”
         For Update Nowait;

      v_Entity_Id     := r_Order_Head.Entity_Id;
      v_Period_Id     := r_Order_Head.Period_Id;
      v_Order_Type_Id := r_Order_Head.Order_Type_Id;
      v_Order_State   := r_Order_Head.Form_State;
    Exception
      When Others Then
        p_Result := '锁定计划订单失败，请检查订单状态;当前单据可能已被退回。' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;

    --获取工单与订单是否完全匹配参数
    Begin
      v_Pln_Wip_Ord_Match := Pkg_Bd.f_Get_Parameter_Value('PLN_WIP_ORD_MATCH',
                                                          v_Entity_Id);
    Exception
      When Others Then
        p_Result := '获取参数PLN_WIP_ORD_MATCH失败！' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;

    Begin
      Select *
        Into r_Order_Type
        From t_Pln_Order_Type Ot
       Where Ot.Order_Type_Id = r_Order_Head.Order_Type_Id
         And Ot.Entity_Id = v_Entity_Id;
    Exception
      When Others Then
        p_Result := '获取计划订单单据类型失败，单据类型ID：' || r_Order_Head.Order_Type_Id;
        Raise v_Base_Exception;
    End;

    Begin
      Select p.Period_Type
        Into v_Period_Type
        From t_Pln_Order_Period p
       Where p.Entity_Id = v_Entity_Id
         And p.Period_Id = v_Period_Id;
    Exception
      When Others Then
        p_Result := '获取周期类型失败,周期ID：' || v_Period_Id || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;
    --检查周期是否打开、关闭
    Pkg_Pln_Pub.p_Check_Period(v_Period_Id,
                               v_Period_Type,
                               v_True,
                               v_False,
                               'O',
                               p_Result);
    If Nvl(p_Result, v_Null) <> v_Success Then
      Raise v_Base_Exception;
    End If;

    Begin
      --'获取当单据据类型的下一单据状态';
      Pkg_Pln_Pub.p_Get_Order_Next_Status(p_Order_Type_Id    => v_Order_Type_Id,
                                          p_Curr_State       => v_Order_State,
                                          p_Curr_Action      => p_Operation_Action,
                                          p_Can_Option_Flag  => v_False,
                                          p_Next_Excute_Step => v_Next_Excute_Step,
                                          p_Nextauto_Excute  => v_Nextauto_Excute,
                                          p_Next_State       => v_Next_State,
                                          p_Next_Action      => v_Next_Action,
                                          p_Result           => p_Result);
      If p_Result <> v_Success Then
        p_Result := '获取订单下一状态失败！当前订单状态：' || v_Order_State || v_Nl ||
                    p_Result;
        Raise v_Base_Exception;
      End If;
    Exception
      When Others Then
        p_Result := p_Result;
        Raise v_Base_Exception;
    End;

    --更新计划订单状态为“已排产”
    Update t_Pln_Order_Head Oh
       Set Oh.Form_State       = v_Next_State, --更新计划订单状态为“已排产”
           Oh.Last_Updated_By  = p_User_Code,
           Oh.Last_Update_Date = Sysdate
     Where Oh.Order_Head_Id = p_Order_Head_Id
       And Oh.Form_State = '22'; --计划订单必须是“评审完毕”
    If Sql%Notfound Then
      p_Result := '更新计划订单头失败，无可更新的订单数据。' || v_Nl || Sqlerrm;
      Raise v_Base_Exception;
    End If;
    p_Result := v_Success;
  Exception
    When v_Base_Exception Then
      p_Result := '失败原因：' || p_Result;
      Rollback;
    When Others Then
      p_Result := '未知错误：' || p_Result || v_Nl || Sqlerrm;
      Rollback;
  End;

  -----------------------------------------------------------------------------
  ---- AUTHOR  : NICRO.LI
  -- CREATED : 201409-06
  -- PURPOSE : 单单订单  引APS接口
  -----------------------------------------------------------------------------
  Procedure p_Into_Aps_Intf(p_Order_Head_Id    In Number, ----订单ID
                            p_Operation_Action In Varchar2, --当前单据动作
                            p_User_Code        In Varchar2, ----用户ID
                            p_Result           Out Varchar2 --返回结果：成功返回"SUCCESS"，失败返回原因
                            ) Is

    v_Tmp_Flag          Varchar2(1); --临时标识，01位长
    v_Entity_Id         Number;
    v_Order_Type_Id     Number;
    v_Order_Type_Name   Varchar2(50); --订单类型
    v_Customer_Id       Number;
    v_Period_Id         Number;
    v_Order_State       Varchar2(100);
    v_Next_Excute_Step  Number;
    v_Next_Action       Varchar2(100);
    v_Nextauto_Excute   Varchar2(100);
    v_Next_State        Varchar2(100);
    v_Period_Type       Varchar2(100);
    v_Pln_Wip_Ord_Match Varchar2(10);

    v_Value      Varchar2(2000);
    r_Order_Head t_Pln_Order_Head%Rowtype;
    r_Order_Type t_Pln_Order_Type%Rowtype;
  Begin
    p_Result := v_Success;
    If p_Order_Head_Id Is Null Or p_User_Code Is Null Then
      p_Result := '部分参数为空或错误';
      Raise v_Base_Exception;
    End If;

    Begin
      Select *
        Into r_Order_Head
        From t_Pln_Order_Head h
       Where Order_Head_Id = p_Order_Head_Id
         --And Form_State In ('23') --汇总订单状态“已评审完毕”
         For Update Nowait;

      v_Entity_Id     := r_Order_Head.Entity_Id;
      v_Period_Id     := r_Order_Head.Period_Id;
      v_Order_Type_Id := r_Order_Head.Order_Type_Id;
      v_Order_State   := r_Order_Head.Form_State;
    Exception
      When Others Then
        p_Result := '锁定计划订单失败，请检查订单状态;当前单据可能已被退回。' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;

    --获取工单与订单是否完全匹配参数
    Begin
      v_Pln_Wip_Ord_Match := Pkg_Bd.f_Get_Parameter_Value('PLN_WIP_ORD_MATCH',
                                                          v_Entity_Id);
    Exception
      When Others Then
        p_Result := '获取参数PLN_WIP_ORD_MATCH失败！' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;

    Begin
      Select *
        Into r_Order_Type
        From t_Pln_Order_Type Ot
       Where Ot.Order_Type_Id = r_Order_Head.Order_Type_Id
         And Ot.Entity_Id = v_Entity_Id;
    Exception
      When Others Then
        p_Result := '获取计划订单单据类型失败，单据类型ID：' || r_Order_Head.Order_Type_Id;
        Raise v_Base_Exception;
    End;

    Begin
      Select p.Period_Type
        Into v_Period_Type
        From t_Pln_Order_Period p
       Where p.Entity_Id = v_Entity_Id
         And p.Period_Id = v_Period_Id;
    Exception
      When Others Then
        p_Result := '获取周期类型失败,周期ID：' || v_Period_Id || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;
    --检查周期是否打开、关闭
    Pkg_Pln_Pub.p_Check_Period(v_Period_Id,
                               v_Period_Type,
                               v_True,
                               v_False,
                               'O',
                               p_Result);
    If Nvl(p_Result, v_Null) <> v_Success Then
      Raise v_Base_Exception;
    End If;

    /*If Nvl(r_Order_Type.Inv_Chk_Auto_Share, v_False) = v_True Then
      For r_Inv_Affirm In (Select Oh.Order_Head_Id,
                                  Oh.Order_Number,
                                  Ol.Order_Line_Id,
                                  Ol.Item_Id,
                                  Ir.Affirm_Qty,
                                  Ir.Inventory_Id,
                                  Oh.Entity_Id
                             From t_Pln_Order_Head       Oh,
                                  t_Pln_Order_Line       Ol,
                                  t_Pln_Order_Inv_Review Ir,
                                  t_Pln_Order_Type       Ot
                            Where Oh.Order_Head_Id = Ol.Order_Head_Id
                              And Ir.Order_Head_Id = Ol.Order_Head_Id
                              And Ir.Order_Line_Id = Ol.Order_Line_Id
                              And Ir.Item_Id = Ol.Item_Id
                              And Ot.Order_Type_Id = Oh.Order_Type_Id
                              And Nvl(Ot.Inv_Chk_Auto_Share, v_False) =
                                  v_True
                              And Oh.Form_State In ('23') --评审完毕
                              And Oh.Order_Head_Id = p_Order_Head_Id
                              And Ir.Affirm_Qty > 0) Loop
        Pkg_Pln_Shares.p_Auto_Create_Share(p_Pln_Order_Line_Id => r_Inv_Affirm.Order_Line_Id, --订单行ID
                                           p_Inventory_Id      => r_Inv_Affirm.Inventory_Id, --仓库ID(财务仓)
                                           p_Trans_Sign_Flag   => 1, --生成发货计划方向，1：生成发货计划  -1：取消发货计划
                                           p_Trans_Share_Qty   => r_Inv_Affirm.Affirm_Qty, --分配数量（只传正数）
                                           p_Entity_Id         => r_Inv_Affirm.Entity_Id, --主体ID
                                           p_Pln_Wip_Ord_Match => v_Pln_Wip_Ord_Match, --工单与订单新匹配模式
                                           p_User_Code         => p_User_Code,
                                           p_Result            => p_Result,
                                           p_Inv_Affirm_Flag   => 'Y' --库存评审标志
                                           );
        If p_Result <> v_Success Then
          Raise v_Base_Exception;
        End If;
      End Loop;
    End If;*/

    Begin
      --'获取当单据据类型的下一单据状态';
      Pkg_Pln_Pub.p_Get_Order_Next_Status(p_Order_Type_Id    => v_Order_Type_Id,
                                          p_Curr_State       => v_Order_State,
                                          p_Curr_Action      => p_Operation_Action,
                                          p_Can_Option_Flag  => v_False,
                                          p_Next_Excute_Step => v_Next_Excute_Step,
                                          p_Nextauto_Excute  => v_Nextauto_Excute,
                                          p_Next_State       => v_Next_State,
                                          p_Next_Action      => v_Next_Action,
                                          p_Result           => p_Result);
      If p_Result <> v_Success Then
        p_Result := '获取订单下一状态失败！当前订单状态：' || v_Order_State || v_Nl ||
                    p_Result;
        Raise v_Base_Exception;
      End If;
    Exception
      When Others Then
        p_Result := p_Result;
        Raise v_Base_Exception;
    End;

    --更新计划订单状态为“已排产”
    Update t_Pln_Order_Line Ol
       Set Ol.Status           = v_Next_State, --更新计划订单状态为“已排产”
           Ol.Last_Updated_By  = p_User_Code,
           Ol.Last_Update_Date = Sysdate
     Where Ol.Order_Head_Id In (Select h.Order_Head_Id
                                  From t_Pln_Order_Head h
                                 Where h.Order_Head_Id = p_Order_Head_Id
                                   And h.Form_State = '23' --计划订单必须是“评审完毕”
                                );
    If Sql%Notfound Then
      p_Result := '更新计划订单行失败，无可更新的订单数据';
      Raise v_Base_Exception;
    End If;

    --更新计划订单状态为“已排产”
    Update t_Pln_Order_Head Oh
       Set Oh.Form_State          = v_Next_State, --更新计划订单状态为“已排产”
           Oh.Last_Updated_By     = p_User_Code,
           Oh.Last_Update_Date    = Sysdate,
           Oh.Is_Aps_Need         = v_True,
           Oh.Aps_Ims_Import_Date = Sysdate
     Where Oh.Order_Head_Id = p_Order_Head_Id
       And Oh.Form_State = '23' --计划订单必须是“评审完毕”
    ;
    If Sql%Notfound Then
      p_Result := '更新计划订单头失败，无可更新的订单数据';
      Raise v_Base_Exception;
    End If;
    p_Result := v_Success;
  Exception
    When v_Base_Exception Then
      p_Result := '失败原因：' || p_Result;
      Rollback;
    When Others Then
      p_Result := '未知错误：' || p_Result || v_Nl || Sqlerrm;
      Rollback;
  End;

  -----------------------------------------------------------------------------
  ---- AUTHOR  : NICRO.LI
  -- CREATED : 2014-07-16 11:05:52
  -- PURPOSE : 执行订单操作
  -----------------------------------------------------------------------------
  Procedure p_Execute_Order_Operate(p_Order_Head_Id      In Number, ----订单ID
                                    p_Operation_Action   In Varchar2, --当前单据动作
                                    p_Next_State         In Varchar2, --下一状态值
                                    p_User_Code          In Varchar2, ----用户编码
                                    p_Result             In Out Varchar2, --返回结果：成功返回"SUCCESS"，失败返回原因
                                    p_Order_Collect_Flag In Varchar2 Default 'N' --是否为汇总订单
                                    ) Is
    v_Err_Num       Number;
    v_Order_Status  Varchar2(100);
    v_Is_Inv_Review Varchar2(3);
  Begin
    If p_Order_Collect_Flag = v_False Or
       p_Operation_Action In (v_Action_Submit,v_Action_Center_Review) Then
      If p_Operation_Action = v_Action_Submit Then
        -- '送审'
        p_Submit_Order(p_Order_Head_Id    => p_Order_Head_Id, ----订单ID
                       p_Operation_Action => p_Operation_Action, --当前单据动作
                       p_User_Code        => p_User_Code, ----用户编码
                       p_Result           => p_Result --返回结果：成功返回"SUCCESS"，失败返回原因
                       );
      ELSIF p_Operation_Action =v_Action_Center_Review THEN
      p_Center_Review_Order(
                       p_Order_Head_Id    => p_Order_Head_Id, ----订单ID
                       p_Operation_Action => p_Operation_Action, --当前单据动作
                       p_User_Code        => p_User_Code, ----用户编码
                       p_Result           => p_Result --返回结果：成功返回"SUCCESS"，失败返回原因
      );
      Elsif p_Operation_Action = v_Action_Inv_Review Then
        --库存评审
        p_Stock_Review_Order(p_Order_Head_Id    => p_Order_Head_Id, ----订单ID
                             p_Operation_Action => p_Operation_Action, --当前单据动作
                             p_User_Code        => p_User_Code, ----用户编码
                             p_Result           => p_Result);
      Elsif p_Operation_Action = v_Action_Hq_Review Or
            p_Operation_Action = v_Action_Check_Complete Then
        --'总部评审' or '审核'
        p_Hq_Order_Check(p_Order_Head_Id    => p_Order_Head_Id, ----订单ID
                         p_Operation_Action => p_Operation_Action, --当前单据动作
                         p_User_Code        => p_User_Code, ----用户编码
                         p_Result           => p_Result --返回结果：成功返回"SUCCESS"，失败返回原因
                         );
      Elsif p_Operation_Action = v_Action_Factory_Review Then
        --工厂评审
        p_Fc_Check_Order(p_Order_Head_Id    => p_Order_Head_Id, ----订单ID
                         p_Operation_Action => p_Operation_Action, --当前单据动作
                         p_User_Code        => p_User_Code, ----用户编码
                         p_Result           => p_Result);
      Elsif p_Operation_Action = v_Action_Aps_Promise Then
        --APS订单承诺
        p_Aps_Order_Promise(p_Order_Head_Id    => p_Order_Head_Id, ----订单ID
                            p_Operation_Action => p_Operation_Action, --当前单据动作
                            p_User_Code        => p_User_Code, ----用户编码
                            p_Result           => p_Result);
      Elsif p_Operation_Action = v_Action_Center_Confirm Then
        --'中心确认'
        p_Center_Confirm_Order(p_Order_Head_Id    => p_Order_Head_Id, ----订单ID
                              p_Operation_Action => p_Operation_Action, --当前单据动作
                              p_User_Code        => p_User_Code, ----用户编码
                              p_Result           => p_Result);
      Elsif p_Operation_Action = v_Action_Hq_Confirm Then
        --'总部确认'
        p_Hq_Confirm_Order(p_Order_Head_Id    => p_Order_Head_Id, ----订单ID
                           p_Operation_Action => p_Operation_Action, --当前单据动作
                           p_User_Code        => p_User_Code, ----用户编码
                           p_Result           => p_Result);

      Elsif p_Operation_Action = v_Action_Ord_Auto_Prdc Then
        -- '订单自动排产'
        --订单不需要入APS系统进行排产，由系统自动更新排产状态
        p_Auto_Produce_Order(p_Order_Head_Id    => p_Order_Head_Id, ----订单ID
                             p_Operation_Action => p_Operation_Action, --当前单据动作
                             p_User_Code        => p_User_Code, ----用户编码
                             p_Result           => p_Result --返回结果：成功返回"SUCCESS"，失败返回原因
                             );
      Elsif p_Operation_Action = v_Action_Review_Complete Then
        --'评审完毕'
        p_Complete_Review_Order(p_Order_Head_Id    => p_Order_Head_Id, ----订单ID
                                p_Operation_Action => p_Operation_Action, --当前单据动作
                                p_User_Code        => p_User_Code, ----用户编码
                                p_Result           => p_Result --返回结果：成功返回"SUCCESS"，失败返回原因
                                );
      Elsif p_Operation_Action = v_Action_Into_Aps_Intf Then
        --引APS接口
        p_Into_Aps_Intf(p_Order_Head_Id    => p_Order_Head_Id, ----订单ID
                        p_Operation_Action => p_Operation_Action, --当前单据动作
                        p_User_Code        => p_User_Code, ----用户编码
                        p_Result           => p_Result --返回结果：成功返回"SUCCESS"，失败返回原因
                        );
      Elsif p_Operation_Action In (v_Action_Back, v_Action_Rebut) Then
        --退回、审核驳回
        p_Back_Order(p_Order_Head_Id    => p_Order_Head_Id, ----订单头ID(如果没有则需传入-1)
                     p_Operation_Action => p_Operation_Action, --订单当前操作类型
                     p_User_Code        => p_User_Code, ----用户编码
                     p_Result           => p_Result ----退回原因,/返回结果
                     );
      End If;
      If p_Result <> v_Success Then
        Raise v_Base_Exception;
      Else
        Begin
          Select Oh.Form_State, Ot.Is_Inv_Affirm_Flag
            Into v_Order_Status, v_Is_Inv_Review
            From t_Pln_Order_Head Oh, t_Pln_Order_Type Ot
           Where Oh.Order_Head_Id = p_Order_Head_Id
             And Oh.Order_Type_Id = Ot.Order_Type_Id
             And Oh.Entity_Id = Ot.Entity_Id;
        Exception
          When Others Then
            p_Result := '获取订单单据类型是否库存评审失败，订单单据头ID：' || To_Char(p_Order_Head_Id);
           Raise v_Base_Exception;
        End;
        --检查单据类型是否不需库存评审，是则系统自动更新状态
        If p_Next_State = '26' And Nvl(v_Is_Inv_Review, v_False) = v_False Then
          p_Stock_Review_Order(p_Order_Head_Id    => p_Order_Head_Id, ----订单ID
                               p_Operation_Action => p_Operation_Action, --当前单据动作
                               p_User_Code        => p_User_Code, ----用户编码
                               p_Result           => p_Result);
          If p_Result <> v_Success Then
            Raise v_Base_Exception;
          End If;
        End If;
        --检查下一状态是否为评审完毕
        p_Check_Next_State_Complete(p_Order_Head_Id    => p_Order_Head_Id, ----订单ID
                                    p_Operation_Action => p_Operation_Action, --当前单据动作
                                    p_Next_State       => v_Order_Status, --下一状态
                                    p_User_Code        => p_User_Code, ----用户编码
                                    p_Result           => p_Result --返回结果：成功返回"SUCCESS"，失败返回原因
                                    );
        If p_Result <> v_Success Then
          Raise v_Base_Exception;
        End If;
      End If;
    Else
      If p_Operation_Action Not In
         (v_Action_Back, v_Action_Rebut, v_Action_Submit) Then
        Pkg_Pln_Order_Collect.p_Execute_Order_Operate(p_Collect_Head_Id  => p_Order_Head_Id, ----订单ID
                                                      p_Operation_Action => p_Operation_Action, --当前单据动作
                                                      p_Next_State       => p_Next_State, --下一状态值
                                                      p_User_Code        => p_User_Code, ----用户编码
                                                      p_Result           => p_Result --错误ID: 成功返回 0 ，失败改返回 -21000
                                                      );
      Elsif p_Operation_Action In (v_Action_Back, v_Action_Rebut) Then
        p_Back_Order(p_Order_Head_Id      => p_Order_Head_Id, ----订单头ID(如果没有则需传入-1)
                     p_Operation_Action   => p_Operation_Action, --订单当前操作类型
                     p_User_Code          => p_User_Code, ----用户编码
                     p_Result             => p_Result, ----退回原因,/返回结果
                     p_Order_Collect_Flag => p_Order_Collect_Flag);
        If p_Result <> v_Success Then
          Raise v_Base_Exception;
        End If;
      End If;
    End If;
  Exception
    When v_Base_Exception Then
      p_Result := p_Result;
      Rollback;
    When Others Then
      p_Result := p_Result || '订单流程处理失败。' || v_Nl || Sqlerrm;
      Rollback;
  End;
  -----------------------------------------------------------------------------
  -- AUTHOR  : NICRO.LI
  -- CREATED : 2014-07-14 11:05:52
  -- PURPOSE : 订单流程处理公共入口过程
  -- p_Result: 退回、审核驳回去,传入退回原因。
  -----------------------------------------------------------------------------
  Procedure p_Order_Operate(p_Order_Head_Id    In Number, ----单据头ID（订单头ID、汇总头ID、提货订单头ID）
                            p_Order_Type_Id    In Number, --单据类型ID
                            p_Operation_Action In Varchar2, --当前单据动作
                            p_User_Code        In Varchar2, ----用户编码
                            p_Result           In Out VARCHAR2 --返回结果：成功返回"SUCCESS"，失败返回原因
                            ) Is
    v_Next_Excute_Step Varchar2(100);
    v_Nextauto_Excute  Varchar2(100);
    v_Next_State       Varchar2(100);
    v_Next_Action      Varchar2(100);
    v_Curr_Action      Varchar2(100);
    v_Curr_State       Varchar2(100);
    v_Period_Id        Number;
    v_Order_Type_Id    Number;
    v_Can_Option_Flag  Varchar2(2);
    v_Err_Num          Number;
    r_Order_Type       t_Pln_Order_Type%Rowtype;
  Begin
    --p_Result      := v_Success;
    v_Curr_Action := p_Operation_Action;
    Begin
      Select *
        Into r_Order_Type
        From t_Pln_Order_Type t
       Where t.Order_Type_Id = p_Order_Type_Id;
    Exception
      When Others Then
        p_Result := '检查单据类型失败，单据类型ID:' || p_Order_Type_Id;
        Raise v_Base_Exception;
    End;
    /*
    0   计划订单
    1   提货订单
    2   返修订单
    3   调拨申请
    4   订单调整申请
    5   其他
    8   样机订单
    */
    If r_Order_Type.Source_Order_Type_Id In (0, 8, 2) And
       (p_Operation_Action In (v_Action_Submit, v_Action_Center_Review) --送审时不按汇总流程处理
       Or Nvl(r_Order_Type.Is_Collect_Order_Flag, v_False) = v_False) Then
      Begin
        Select Oh.Order_Type_Id, Oh.Period_Id, Oh.Form_State
          Into v_Order_Type_Id, v_Period_Id, v_Curr_State
          From t_Pln_Order_Head Oh
         Where Oh.Order_Head_Id = p_Order_Head_Id;
      Exception
        When Others Then
          p_Result := '获取订单头信息失败。';
          Raise v_Base_Exception;
      End;
    Elsif r_Order_Type.Source_Order_Type_Id In (0, 8) And
          p_Operation_Action Not In (v_Action_Submit,v_Action_Center_Review) --送审时不按汇总流程处理
          And Nvl(r_Order_Type.Is_Collect_Order_Flag, v_False) = v_True Then
      Begin
        Select Ch.Order_Type_Id, Ch.Period_Id, Ch.Form_State
          Into v_Order_Type_Id, v_Period_Id, v_Curr_State
          From t_Pln_Order_Collect_Head Ch
         Where Ch.Coll_Ord_Head_Id = p_Order_Head_Id;
      Exception
        When Others Then
          p_Result := '获取汇部订单头信息失败。';
          Raise v_Base_Exception;
      End;
    Elsif r_Order_Type.Source_Order_Type_Id In (1, 3) Then
      --提货订单、调拨申请
      Select Oh.Order_Type_Id, 0, Oh.Order_Head_State
        Into v_Order_Type_Id, v_Period_Id, v_Curr_State
        From t_Pln_Lg_Order_Head Oh
       Where Oh.Order_Head_Id = p_Order_Head_Id;
    End If;
    --库存评审 状态时，获取下一状态可选流程为Y
    Select Decode(p_Operation_Action,
                  v_Action_Inv_Review,
                  v_True,
                  v_Action_Center_Review,
                  Decode(r_Order_Type.Source_Order_Type_Id,
                         1,
                         v_True,
                         v_False),
                  v_False)
      Into v_Can_Option_Flag
      From Dual;
    If p_Operation_Action In
       (v_Action_Back, v_Action_Rebut, v_Action_Close, v_Action_Revoke) And
       r_Order_Type.Source_Order_Type_Id In (0, 2, 8) Then
      --计划订单的订单退回、驳回、关闭、撤回
      p_Execute_Order_Operate(p_Order_Head_Id      => p_Order_Head_Id, ----订单ID
                              p_Operation_Action   => v_Curr_Action, --当前单据动作
                              p_Next_State         => v_Next_State,
                              p_User_Code          => p_User_Code, ----用户编码
                              p_Result             => p_Result, --返回结果：成功返回"SUCCESS"，失败返回原因
                              p_Order_Collect_Flag => Nvl(r_Order_Type.Is_Collect_Order_Flag,
                                                          v_False));
      If p_Result <> v_Success Then
        Raise v_Base_Exception;
      End If;
    Elsif p_Operation_Action In
          (v_Action_Back, v_Action_Rebut, v_Action_Close, v_Action_Revoke) And
          r_Order_Type.Source_Order_Type_Id In (1, 3) Then
      --提货订单、调拨申请的订单退回、驳回、关闭、
      Pkg_Pln_Lg_Order.p_Execute_Lgorder_Operate(p_Order_Head_Id    => p_Order_Head_Id, ----订单ID
                                                 p_Operation_Action => v_Curr_Action, --当前单据动作
                                                 p_Next_State       => v_Next_State,
                                                 p_User_Code        => p_User_Code, ----用户编码
                                                 p_Result           => p_Result --返回结果：成功返回"SUCCESS"，失败返回原因
                                                 );
      If p_Result <> v_Success Then
        Raise v_Base_Exception;
      End If;
    Else
      Loop
        --'获取当单据据类型的下一单据状态';
        Pkg_Pln_Pub.p_Get_Order_Next_Status(p_Order_Type_Id    => v_Order_Type_Id,
                                            p_Curr_State       => v_Curr_State,
                                            p_Curr_Action      => v_Curr_Action,
                                            p_Can_Option_Flag  => v_Can_Option_Flag,
                                            p_Next_Excute_Step => v_Next_Excute_Step,
                                            p_Nextauto_Excute  => v_Nextauto_Excute,
                                            p_Next_State       => v_Next_State,
                                            p_Next_Action      => v_Next_Action,
                                            p_Result           => p_Result);
        If p_Result <> v_Success Then
          p_Result := '获取订单下一状态失败！当前订单状态：' || v_Curr_State || v_Nl ||
                    p_Result;
          Raise v_Base_Exception;
        End If;
        If r_Order_Type.Source_Order_Type_Id In (0, 2, 8) Then
          p_Execute_Order_Operate(p_Order_Head_Id      => p_Order_Head_Id, ----订单ID
                                  p_Operation_Action   => v_Curr_Action, --当前单据动作
                                  p_Next_State         => v_Next_State,
                                  p_User_Code          => p_User_Code, ----用户编码
                                  p_Result             => p_Result, --返回结果：成功返回"SUCCESS"，失败返回原因
                                  p_Order_Collect_Flag => Nvl(r_Order_Type.Is_Collect_Order_Flag,
                                                              v_False));
          If p_Result <> v_Success Then
            Raise v_Base_Exception;
          End If;
        Elsif r_Order_Type.Source_Order_Type_Id In (1, 3) Then
          Pkg_Pln_Lg_Order.p_Execute_Lgorder_Operate(p_Order_Head_Id    => p_Order_Head_Id, ----订单ID
                                                     p_Operation_Action => v_Curr_Action, --当前单据动作
                                                     p_Next_State       => v_Next_State,
                                                     p_User_Code        => p_User_Code, ----用户编码
                                                     p_Result           => p_Result --返回结果：成功返回"SUCCESS"，失败返回原因
                                                     );
          --add by lizheng 2017-05-05提货订单处理完成后重新取一次状态值
          Select Loh.Order_Head_State
            Into v_Next_State
            From t_Pln_Lg_Order_Head Loh
           Where Loh.Order_Head_Id = p_Order_Head_Id;
          If p_Result <> v_Success Then
            Raise v_Base_Exception;
          End If;
        End If;

        --非自动执行则退出循环
        --add by lizheng 2017-05-05 产能可视状态值时不再进行自动处理
        If v_Nextauto_Excute <> v_True Or v_Next_State = '2225' Then
          Exit;
        End If;
        v_Curr_State  := v_Next_State;
        v_Curr_Action := v_Next_Action;
        --'获取当单据据类型的下一单据状态';
        Pkg_Pln_Pub.p_Get_Order_Next_Status(p_Order_Type_Id    => v_Order_Type_Id,
                                            p_Curr_State       => v_Curr_State,
                                            p_Curr_Action      => v_Curr_Action,
                                            p_Can_Option_Flag  => v_Can_Option_Flag,
                                            p_Next_Excute_Step => v_Next_Excute_Step,
                                            p_Nextauto_Excute  => v_Nextauto_Excute,
                                            p_Next_State       => v_Next_State,
                                            p_Next_Action      => v_Next_Action,
                                            p_Result           => p_Result);
        If p_Result <> v_Success Then
          p_Result := '获取订单下一状态失败！当前订单状态：' || v_Curr_State || v_Nl ||
                    p_Result;
          Raise v_Base_Exception;
        End If;
      End Loop;
    End If;
  Exception
    When v_Base_Exception Then
      p_Result := p_Result;
    When Others Then
      p_Result := p_Result || v_Nl || Sqlerrm;
  End;

  -----------------------------------------------------------------------------
  ---- AUTHOR  : NICRO.LI
  -- CREATED : 2014-07-16 11:05:52
  -- PURPOSE : 发货计划订单取消订单数量及发货计划数量取消
  --           P_ORDER_SHARES 参数 发货计划行ID使用英文的“,”分隔
  -----------------------------------------------------------------------------
  Procedure p_Order_Cancel(p_Entity_Id    In Number, --主主体ID,
                           p_Order_Shares In Varchar2, --产品行ID列表
                           p_User_Code    In Varchar2, --用户编码
                           p_Result       In Out Varchar2) Is
    v_Value Varchar2(1000);
    Type c_Order_Shares Is Ref Cursor; --声明动态游标
    v_Order_Shares       c_Order_Shares;
    r_Order_Shares       t_Pln_Order_Share_Shipment%Rowtype;
    r_Order_Line         t_Pln_Order_Line%Rowtype;
    n_Material_Lock_Qty  Number;
    n_Material_Share_Qty Number;

    v_Inv_Affrim_Qty    Number;
    v_Inv_Cancel_Qty    Number;
    v_Inv_Carry_Qty     Number; --库评已下达数量
    v_Current_Inv_Carry_Qty Number; --当前发货计划对应的库评已下达数量
    v_Inv_So_Order_Qty  Number;
    v_Prdc_Carry_Qty    Number; --排产已下达数量
    v_Prdc_So_Order_Qty Number;

    v_Pln_Wip_Ord_Match  Varchar2(10);
    v_Order_Number       Varchar2(40);
    v_Pln_Order_Share_Id Number;
    v_Count              Number;
    v_Area_Count         Number;
    v_Item_Occ_Qty       Number; --库存占用数量
    v_Source_Share_Inventory_id  Number; --源发货计划行发货仓库ID
    v_Lg_Ship_Review_Qty    Number;  --提货订单已评审未下达
    v_Sales_Main_Type    Varchar2(32); --营销大类
    v_Cancel_amount      Number;   --取消数量的金额
    v_Discount_Amount    Number;   --取消数量的折扣金额
    v_origin_share_id    NUMBER; --原始来源分配行
    v_origin_source_share_id NUMBER;
    v_order_type_code t_pln_order_head.order_type_code%TYPE; --20160912 hejy3 订单类型编码
    v_order_type_id t_pln_order_type.order_type_id%type; --订单类型ID
    v_curr_entity_id number;
  Begin
    p_Result := v_Success;

    --获取工单与订单是否完全匹配参数
    Begin
      v_Pln_Wip_Ord_Match := Pkg_Bd.f_Get_Parameter_Value('PLN_WIP_ORD_MATCH',
                                                          p_Entity_Id);
    Exception
      When Others Then
        p_Result := '获取参数PLN_WIP_ORD_MATCH失败！' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;

    If p_Result = v_Success Then
      Open v_Order_Shares For 'SELECT *
        FROM T_PLN_ORDER_SHARE_SHIPMENT OS
       WHERE OS.ORDER_SHARE_ID IN (' || p_Order_Shares || ') FOR UPDATE NOWAIT';
      Loop
        Fetch v_Order_Shares
          Into r_Order_Shares;
        Exit When v_Order_Shares%Notfound;
        --取制定发货需求计划主体ID
        v_curr_entity_id := r_Order_Shares.Entity_Id;
        If Nvl(r_Order_Shares.Canceling_Qty, 0) = 0 Then
          p_Result := '取消数量为0，先保存数据在取消订单数量！';
          Raise v_Base_Exception;
        End If;
        If r_Order_Shares.Share_Qty - Nvl(r_Order_Shares.Carry_Qty, 0) <
           r_Order_Shares.Canceling_Qty Then
          p_Result := '发货计划取消数量失改，取消数量大已可用于取消的数量！' || '本次取消数量：' ||
                      To_Char(r_Order_Shares.Canceling_Qty) || '，可用于取消的数量：' ||
                      To_Char(r_Order_Shares.Share_Qty -
                              Nvl(r_Order_Shares.Carry_Qty, 0));
          Raise v_Base_Exception;
        End If;

        Begin
          Select Oh.Order_Number, oh.order_type_code, oh.order_type_id
            Into v_Order_Number, v_order_type_code, v_order_type_id
            From t_Pln_Order_Head Oh
           Where Oh.Entity_Id = v_curr_entity_id--p_Entity_Id
             And Oh.Order_Head_Id = r_Order_Shares.Origin_Head_Id;
        Exception
          When Others Then
            p_Result := '获取订单单号失败！' || v_NL || Sqlerrm;
            Raise v_Base_Exception;
        End;

        --add by lizhen 2015-03-18 获取提货订单未评审的发货计划数量
        Begin
          Select Sum(Osr.Review_Qty)
            Into v_Lg_Ship_Review_Qty
            From t_Pln_Lg_Order_Ship_Review Osr
           Where Osr.Entity_Id = v_curr_entity_id--p_Entity_Id
             And Osr.Origin_Order_Head_Id = r_Order_Shares.Origin_Head_Id
             And Osr.Origin_Order_Line_Id = r_Order_Shares.Origin_Line_Id
             And Osr.Origin_Order_Share_Id = r_Order_Shares.Order_Share_Id
             And Nvl(Osr.Review_Status, 'N') = 'N';
        Exception
          When No_Data_Found Then
            v_Lg_Ship_Review_Qty := 0;
          When Others Then
            p_Result := '获取提货订单未评审的发货计划数量失败！';
            Raise v_Base_Exception;
        End;
        If Nvl(r_Order_Shares.Share_Qty, 0) - Nvl(r_Order_Shares.Canceling_Qty, 0)
          - Nvl(r_Order_Shares.Carry_Qty, 0) < Nvl(v_Lg_Ship_Review_Qty, 0) Then
          p_Result := '发货计划取消订单失败，当前可取消数量不满足本次取消需求。' || v_Nl ||
            '订单单号：' || r_Order_Shares.Origin_Head_Code || v_Nl ||
            '产品编码：' || r_Order_Shares.Item_Code || v_Nl ||
            '未下达数量：' || To_Char(Nvl(r_Order_Shares.Share_Qty, 0) - Nvl(r_Order_Shares.Carry_Qty, 0)) || v_Nl ||
            '本次取消数量：' || To_Char(Nvl(r_Order_Shares.Canceling_Qty, 0)) || v_Nl ||
            '提货订单发货计划未评审数量：' || To_Char(Nvl(v_Lg_Ship_Review_Qty, 0)) || v_Nl ||
            '未下达数量-本次取消数量 < 提货订单发货计划未评审数量，取消订单失败。';
          Raise v_Base_Exception;
        End If;

        Begin
          Select *
            Into r_Order_Line
            From t_Pln_Order_Line l
           Where l.Order_Line_Id = r_Order_Shares.Origin_Line_Id;
        Exception
          When Others Then
            p_Result := '获取订单行数据失败，订单行ID：' ||
                        To_Char(r_Order_Shares.Origin_Line_Id) || v_Nl ||
                        Sqlerrm;
            Raise v_Base_Exception;
        End;
        --add by lizhen 2017-03-08 检查匹配数量与取消数量关系，当前行是否满足取消数量
        --可取消数量 = 排产数量 + 库存评审数量 - 排产入库取消数量 - 库存评审取消数量 - 调整取消数量 - 已匹配数量
        If Nvl(r_Order_Line.Can_Produce_Qty, 0) + Nvl(r_Order_Line.Inv_Affirm_Qty, 0) -
          Nvl(r_Order_Line.Cancel_Inv_Check_Qty, 0) - Nvl(r_Order_Line.Cancel_Inv_In_Qty, 0) -
          Nvl(r_Order_Line.Match_Qty, 0)  < r_Order_Shares.Canceling_Qty Then
          p_Result := '取消订单失败，订单产品行可取消数量【' || (Nvl(r_Order_Line.Can_Produce_Qty, 0) + Nvl(r_Order_Line.Inv_Affirm_Qty, 0) -
          Nvl(r_Order_Line.Cancel_Inv_Check_Qty, 0) - Nvl(r_Order_Line.Cancel_Inv_In_Qty, 0) -
          Nvl(r_Order_Line.Match_Qty, 0)) || '】小于本次订单行取消数量【'
          || r_Order_Shares.Canceling_Qty || '】。' || v_Nl ||
          '订单行ID：' || To_Char(r_Order_Shares.Origin_Line_Id);
          Raise v_Base_Exception;
        End If;

        If r_Order_Shares.Source_Order_Share_Id Is Null Then
          v_Source_Share_Inventory_id := r_Order_Shares.Inventory_From_Id;
        ELSE
          --取最原始的分配行
          v_origin_share_id := r_Order_Shares.Source_Order_Share_Id;
          v_Current_Inv_Carry_Qty := nvl(r_Order_Shares.Carry_Qty, 0);
          FOR RS IN 1..30 LOOP
            SELECT s.order_share_id, s.source_order_share_id, v_Current_Inv_Carry_Qty + nvl(s.carry_qty, 0)
              INTO v_origin_share_id, v_origin_source_share_id, v_Current_Inv_Carry_Qty
              FROM t_Pln_Order_Share_Shipment S
             WHERE s.order_share_id = v_origin_share_id;

            --当来源分配行的来源分配行ID为空，代表最原始的分配行，结束循环
            IF v_origin_source_share_id IS NULL THEN
              EXIT;
            ELSE
              v_origin_share_id := v_origin_source_share_id;
            END IF;
          END LOOP;

          Begin
            Select Oss.Inventory_From_Id
              Into v_Source_Share_Inventory_Id
              From t_Pln_Order_Share_Shipment Oss
             --Where Oss.Order_Share_Id = r_Order_Shares.Source_Order_Share_Id;
             WHERE oss.order_share_id = v_origin_share_id;
          Exception
            When Others Then
              p_Result := '获取来源订单发货计划行的发货仓库ID失败，来源发货计划行ID：' ||
                          --To_Char(r_Order_Shares.Source_Order_Share_Id) || v_Nl ||
                          To_Char(v_origin_share_id) || v_Nl ||
                          Sqlerrm;
              Raise v_Base_Exception;
          End;
        End If;

        Begin
          Select Sum(Nvl(Oss.Carry_Qty, 0)), Sum(Nvl(Oss.So_Order_Qty, 0))
            Into v_Inv_Carry_Qty, v_Inv_So_Order_Qty
            From t_Pln_Order_Share_Shipment Oss
           Where Oss.Origin_Head_Id = r_Order_Shares.Origin_Head_Id
             And Oss.Origin_Line_Id = r_Order_Shares.Origin_Line_Id
             And Oss.Inventory_From_Id = r_Order_Shares.Inventory_From_Id
             And Oss.Entity_Id = v_curr_entity_id--p_Entity_Id
             And Nvl(Oss.Inv_Share_Flag, v_False) = v_True;

          --汇总非库存评审的已下达数量
          Select Sum(Nvl(Oss.Carry_Qty, 0)), Sum(Nvl(Oss.So_Order_Qty, 0))
            Into v_Prdc_Carry_Qty, v_Prdc_So_Order_Qty
            From t_Pln_Order_Share_Shipment Oss
           Where Oss.Origin_Head_Id = r_Order_Shares.Origin_Head_Id
             And Oss.Origin_Line_Id = r_Order_Shares.Origin_Line_Id
             And Oss.Inventory_From_Id = r_Order_Shares.Inventory_From_Id
             And Oss.Entity_Id = v_curr_entity_id--p_Entity_Id
             And Nvl(Oss.Inv_Share_Flag, v_False) = v_False;

          --汇总订单库存评审数量
          Select Sum(Nvl(Inv.Affirm_Qty, 0)), Sum(Nvl(Inv.Cancel_Qty, 0))
            Into v_Inv_Affrim_Qty, v_Inv_Cancel_Qty
            From t_Pln_Order_Inv_Review Inv
           Where Inv.Order_Head_Id = r_Order_Shares.Origin_Head_Id
             And Inv.Order_Line_Id = r_Order_Shares.Origin_Line_Id
             And Inv.Inventory_Id = v_Source_Share_Inventory_Id
             And Inv.Item_Id = r_Order_Shares.Item_Id
             And Inv.Entity_Id = v_curr_entity_id--p_Entity_Id
             ;
        Exception
          When Others Then
            v_Inv_Carry_Qty := 0;
        End;

        Select Count(1)
          Into v_Area_Count
          From v_Pln_Producing_Area_Inventory Ari
         Where Exists
         (Select 1
                  From t_Pln_Order_Line Ol
                 Where Ol.Order_Line_Id = r_Order_Shares.Origin_Line_Id
                   And Ol.Producing_Area_Id = Ari.Producing_Area_Id)
           And Ari.Inventory_Id = r_Order_Shares.Inventory_From_Id;

        -- 若无库存评审，检查仓库与产地是否匹配
        If r_Order_Shares.Inv_Share_Flag <> v_True Then
          If v_Area_Count = 0 And r_Order_Shares.Source_Order_Share_Id Is Null Then
            p_Result := '检查仓库与产地关系失败，产地ID：' ||
                        r_Order_Shares.Producing_Area_Id || '，仓库ID:' ||
                        To_Char(r_Order_Shares.Inventory_From_Id) ||
                        '，订单号：' || v_Order_Number;
            Raise v_Base_Exception;
          Elsif v_Area_Count > 0 Then
            --非库存评审发货计划，但存在辐射关系
            --可生产 -  入库取消数量 - 下达 + 库存评审已下达   < 本次取消数量
            If p_Result = v_Success And
               (Nvl(r_Order_Line.Can_Produce_Qty, 0) -
               Nvl(r_Order_Line.Cancel_Inv_In_Qty, 0) -
               Nvl(r_Order_Shares.Carry_Qty, 0) + Nvl(v_Inv_Carry_Qty, 0)) <
               Nvl(r_Order_Shares.Canceling_Qty, 0) Then
              p_Result := '订单产品行可取消数量' ||
                          To_Char((Nvl(r_Order_Line.Can_Produce_Qty, 0) -
                                  Nvl(r_Order_Line.Cancel_Inv_In_Qty, 0) -
                                  Nvl(r_Order_Shares.Carry_Qty, 0) +
                                  Nvl(v_Inv_Carry_Qty, 0))) || '少于取消订单数量' ||
                          To_Char(Nvl(r_Order_Shares.Canceling_Qty, 0)) ||
                          '，无法取消订单(' || v_Order_Number || ')！';
              Raise v_Base_Exception;
            End If;
          End If;
        Else
          --按来源发货计划行的发货仓库获取已下达数量、已开单数量
          /*Select Sum(Nvl(Oss.Carry_Qty, 0))
            Into v_Current_Inv_Carry_Qty
            From t_Pln_Order_Share_Shipment Oss
           Where Oss.Origin_Head_Id = r_Order_Shares.Origin_Head_Id
             And Oss.Origin_Line_Id = r_Order_Shares.Origin_Line_Id
             And ((Oss.Source_Order_Share_Id = r_Order_Shares.Source_Order_Share_Id Or
                 Oss.Order_Share_Id = r_Order_Shares.Source_Order_Share_Id) And
                 Oss.Source_Order_Share_Id Is Not Null Or
                 Oss.Inventory_From_Id = v_Source_Share_Inventory_Id)
             And Oss.Entity_Id = p_Entity_Id
             And Nvl(Oss.Inv_Share_Flag, v_False) = v_True;*/
          --库存评审，因存在仓库资料，单独判断是否满足本次取消量
          --库存评审 - 库存取消 - 库存评审已下达
          If p_Result = v_Success And
             (Nvl(v_Inv_Affrim_Qty, 0) - Nvl(v_Inv_Cancel_Qty, 0) -
             Nvl(v_Current_Inv_Carry_Qty, 0)) <
             Nvl(r_Order_Shares.Canceling_Qty, 0) Then
            p_Result := '订单产品行库存评审可取消数量' ||
                        To_Char(Nvl(v_Inv_Affrim_Qty, 0) -
                                Nvl(v_Inv_Cancel_Qty, 0) -
                                Nvl(v_Current_Inv_Carry_Qty, 0)) || '少于取消订单数量' ||
                        To_Char(Nvl(r_Order_Shares.Canceling_Qty, 0)) ||
                        '，无法取消订单(' || v_Order_Number || ')！';
            Raise v_Base_Exception;
          End If;
        End If;

        --订单可取消数 = 可生产数 + 库存评审数量 - 总取消 - 已下达
        If p_Result = v_Success And
           (Nvl(r_Order_Line.Can_Produce_Qty, 0) +
           Nvl(r_Order_Line.Inv_Affirm_Qty, 0) -
           Nvl(r_Order_Line.Cancel_Inv_Check_Qty, 0) -
           Nvl(r_Order_Line.Cancel_Inv_In_Qty, 0) -
           Nvl(r_Order_Line.Carry_Qty, 0)) <
           Nvl(r_Order_Shares.Canceling_Qty, 0) Then
          p_Result := '订单产品行可取消数量' ||
                      To_Char(Nvl(r_Order_Line.Can_Produce_Qty, 0) +
                              Nvl(r_Order_Line.Inv_Affirm_Qty, 0) -
                              Nvl(r_Order_Line.Cancel_Inv_Check_Qty, 0) -
                              Nvl(r_Order_Line.Cancel_Inv_In_Qty, 0) -
                              Nvl(r_Order_Line.Carry_Qty, 0)) || '少于取消订单数量' ||
                      To_Char(Nvl(r_Order_Shares.Canceling_Qty, 0)) ||
                      '，无法取消订单(' || v_Order_Number || ')！';
          Raise v_Base_Exception;
        End If;

        If p_Result = v_Success Then
          v_Item_Occ_Qty := Pkg_Pln_Inv_Occupy.f_Item_Ass_Occupy_Qty(p_Inventory_Id     => r_Order_Shares.Inventory_From_Id, --仓库ID
                                                                     p_Item_Id          => r_Order_Shares.Item_Id, --产品ID
                                                                     p_Match_Pln_To_Wip => v_Pln_Wip_Ord_Match, --工单与订单完全匹配标志
                                                                     p_Entity_Id        => v_curr_entity_id/*p_Entity_Id*/, --主体ID
                                                                     p_Origin_Line_Id   => r_Order_Shares.Origin_Line_Id, --来源行ID
                                                                     p_Origin_Type      => Null --库存占用来源类型
                                                                     );
          --IF N_MATERIAL_LOCK_QTY - N_MATERIAL_SHARE_QTY < R_ORDER_SHARES.CANCELING_QTY THEN
          --库存占用量 - 入库已下达 + 入库已开单 - 库评已下达 + 库评已开单
          If v_Item_Occ_Qty - Nvl(v_Prdc_Carry_Qty, 0) +
             Nvl(v_Prdc_So_Order_Qty, 0) - Nvl(v_Inv_Carry_Qty, 0) +
             Nvl(v_Inv_So_Order_Qty, 0) < r_Order_Shares.Canceling_Qty Then
            p_Result := '订单行ID：' || r_Order_Line.Order_Line_Id || '，订单号：' ||
                        v_Order_Number || '，产品编码：' ||
                        r_Order_Shares.Item_Code ||
                        '，库存占用数量不足，无法取消订单数量。库存占用数量：' || v_Item_Occ_Qty ||
                        '，已下达未开单：' ||
                        To_Char(Nvl(v_Prdc_Carry_Qty, 0) -
                                Nvl(v_Prdc_So_Order_Qty, 0) +
                                Nvl(v_Inv_Carry_Qty, 0) -
                                Nvl(v_Inv_So_Order_Qty, 0)) || '，本次取消数量：' ||
                        r_Order_Shares.Canceling_Qty ||
                        '，库存占用数量-已下达未开单 < 本次取消数量';
            Raise v_Base_Exception;
          End If;
        End If;

        v_Value := '产品：' || r_Order_Shares.Item_Code || ',释放占用库存!';
        If p_Result = v_Success And r_Order_Shares.Inv_Share_Flag = v_True Then
          --更新订单产品库存评审行信息
          Select Count(1)
            Into v_Count
            From t_Pln_Order_Inv_Review Inv
           Where Inv.Order_Head_Id = r_Order_Shares.Origin_Head_Id
             And Inv.Order_Line_Id = r_Order_Shares.Origin_Line_Id
             And Inv.Item_Id = r_Order_Shares.Item_Id
             And Inv.Inventory_Id = v_Source_Share_Inventory_id
             And Inv.Affirm_Qty - Nvl(Inv.Cancel_Qty, 0) >=
                 r_Order_Shares.Canceling_Qty;

          If v_Count <= 0 Then
            p_Result := '当前仓库库存评审数量不满足此次取消，订单号：' || v_Order_Number;
            Raise v_Base_Exception;
          End If;

          If (p_Result = v_Success) Then
            Update t_Pln_Order_Inv_Review Inv
               Set Inv.Cancel_Qty  = Nvl(Inv.Cancel_Qty, 0) +
                                     r_Order_Shares.Canceling_Qty,
                   Inv.Cancel_Flag = Decode(Nvl(Inv.Affirm_Qty, 0) -
                                            (Nvl(Inv.Cancel_Qty, 0) +
                                             r_Order_Shares.Canceling_Qty),
                                            0,
                                            'Y',
                                            'N'),
                   Inv.Version = Nvl(Inv.Version, 0) + 1 --add by lizhen 2015-10-26
             Where Inv.Order_Head_Id = r_Order_Shares.Origin_Head_Id
               And Inv.Order_Line_Id = r_Order_Shares.Origin_Line_Id
               And Inv.Item_Id = r_Order_Shares.Item_Id
               And Inv.Inventory_Id = v_Source_Share_Inventory_id;
          End If;
        End If;
        Pkg_Pln_Inv_Occupy.p_Others_Occupy_Stocks(p_Inventory_Id      => r_Order_Shares.Inventory_From_Id, --仓库ID
                                                  p_Item_Id           => r_Order_Shares.Item_Id, --产品ID
                                                  p_Occupy_Qty        => r_Order_Shares.Canceling_Qty, --占用数量
                                                  p_Match_Pln_To_Wip  => v_Pln_Wip_Ord_Match, --工单与订单完全匹配标志
                                                  p_Action_Desc       => '发货计划订单取消', --单据操作描述 例：中转单据执行、中转红冲单执行
                                                  p_Entity_Id         => v_curr_entity_id/*p_Entity_Id*/, --主体ID
                                                  p_Origin_Type       => '计划订单', --来源类型
                                                  p_Origin_Head_Id    => r_Order_Shares.Origin_Head_Id, --来源头ID
                                                  p_Origin_Number     => r_Order_Shares.Origin_Head_Code, --来源头编码
                                                  p_Origin_Line_Id    => r_Order_Shares.Origin_Line_Id, --来源行ID
                                                  p_Source_Order_Type => r_Order_Shares.Origin_Type, --事务来源单据类型
                                                  p_Source_Head_Id    => r_Order_Shares.Origin_Head_Id, --事务来源头ID
                                                  p_Source_Number     => r_Order_Shares.Origin_Head_Code, --事务来源头编码
                                                  p_Source_Line_Id    => r_Order_Shares.Origin_Line_Id, --事务来源行ID
                                                  p_User_Code         => p_User_Code, --用户编码
                                                  p_Result            => v_Count, --返回错误ID
                                                  p_Err_Msg           => p_Result --返回错误信息
                                                  );
        If p_Result <> v_Success Then
          p_Result := v_Value || v_Nl || p_Result || '，订单号：' ||
                      v_Order_Number;
          Raise v_Base_Exception;
        End If;

        --送审锁款时取消订单要解锁款项
        --modi by xuhongjiu 2015-11-30 金额 =（单价*数量*（100-折扣率-月返））/100
        If p_Result = v_Success And nvl(r_Order_Shares.Lock_Amount_Flag,'_') = pkg_pln_pub.V_LOCK_AMOUNT_FLAG_S Then
          --计算取消金额和扣率金额
          Select --20170517 hejy3 按行营销大类
                 --bi.sales_main_type,
                 nvl(ol.sales_main_type, bi.sales_main_type),
                 nvl(t.List_Price,0) * nvl(t.Canceling_Qty,0) *
                 (100 - nvl(t.Discount_Rate,0) - nvl(t.Ordered_Discount_Rate,0))/100,
                 nvl(t.List_Price,0) * nvl(t.Canceling_Qty,0) *
                 nvl(t.Discount_Rate,0)/100
            Into v_Sales_Main_Type,v_Cancel_amount,v_Discount_Amount
            From cims.t_pln_order_share_shipment t,cims.t_bd_item bi
                 --20170517 hejy3 按行营销大类
                 ,t_pln_order_line ol
           Where t.item_code = bi.item_code
             And t.entity_id = bi.entity_id
             and t.origin_line_id = ol.order_line_id --20170517 hejy3 按行营销大类
             And t.order_share_id = r_Order_Shares.Order_Share_Id;

           If nvl(v_Cancel_amount,0) + nvl(v_Discount_Amount,0) > 0 Then
             /*Pkg_Credit_Account_Control.Prc_Credit_Order_Bill(p_Entity_Id       => r_Order_Shares.Entity_Id,
                                                               p_Action_Type     => 2, --释放到款
                                                               p_Settlement_Sum  => Nvl(v_Cancel_amount,0),
                                                               p_Discount_Sum    => Nvl(v_Discount_Amount,0),
                                                               p_Sales_Main_Type => v_Sales_Main_Type,
                                                               p_Account_Id      => r_Order_Shares.Account_Id,
                                                               p_Customer_Id     => r_Order_Shares.Customer_Id,
                                                               p_Proj_Number     => Null,
                                                               p_Order_Id        => r_Order_Shares.Origin_Head_Id,
                                                               --p_Order_Type      => r_Order_Shares.Origin_Type,
                                                               P_ORDER_TYPE => v_order_type_code, --20160912 hejy3 传入订单类型编码
                                                               p_Username        => p_User_Code,
                                                               p_Result          => v_Count,
                                                               p_Err_Msg         => p_Result);
             If p_Result <> v_Success Then
               p_Result := '检查资金失败，产品大类：' ||
                           v_Sales_Main_Type || v_Nl ||
                           p_Result;
               Raise v_Base_Exception;
             End If;*/
            pkg_pln_pub.P_CUSTOMER_AMOUNT_PROCESS(IN_ENTITY_ID       => r_Order_Shares.Entity_Id,
                                                  IN_ORDER_TYPE_ID   => v_order_type_id,
                                                  IN_ORDER_TYPE_CODE => v_order_type_code,
                                                  IN_CUSTOMER_ID     => r_Order_Shares.Customer_Id,
                                                  IN_ACCOUNT_ID      => r_Order_Shares.Account_Id,
                                                  IN_SALES_MAIN_TYPE => v_Sales_Main_Type,
                                                  IN_ACTION_TYPE     => 2,
                                                  IN_SOURCE_TYPE     => '01',
                                                  IN_ORDER_ID        => r_Order_Shares.Origin_Head_Id,
                                                  IN_PROJ_NUMBER     => null,
                                                  IN_DISCOUNT_TYPE   => pkg_pln_pub.v_Discount_Type_Common,
                                                  IN_AMOUNT          => Nvl(v_Cancel_amount,0),
                                                  IN_DIS_AMOUNT      => Nvl(v_Discount_Amount,0),
                                                  IN_RECORD_ERR      => 'N',
                                                  IN_USER_CODE       => p_User_Code,
                                                  OUT_RESULT         => p_Result);
            if p_Result <> v_Success then
              p_Result := '取消订单处理客户款项失败(锁款方式:'||r_Order_Shares.Lock_Amount_Flag||')！' || v_Nl || p_Result;
              raise v_Base_Exception;
            end if;
          End If;
        End If;

        If p_Result = v_Success Then
          v_Value := '更新订单产品库存评审行取消数量资料';
          --更新取消数量，已发货计划数量
          Update t_Pln_Order_Line Ol
             Set Ol.Cancel_Inv_Check_Qty = Decode(r_Order_Shares.Inv_Share_Flag,
                                                  v_True,
                                                  Nvl(Ol.Cancel_Inv_Check_Qty,
                                                      0) + Nvl(r_Order_Shares.Canceling_Qty,
                                                               0),
                                                  Ol.Cancel_Inv_Check_Qty),
                 Ol.Cancel_Inv_In_Qty    = Decode(r_Order_Shares.Inv_Share_Flag,
                                                  v_True,
                                                  Ol.Cancel_Inv_In_Qty,
                                                  Nvl(Ol.Cancel_Inv_In_Qty, 0) +
                                                  Nvl(r_Order_Shares.Canceling_Qty,
                                                      0)),
                 Ol.Share_Qty            = Nvl(Ol.Share_Qty, 0) -
                                           r_Order_Shares.Canceling_Qty,
                 Ol.Last_Updated_By      = p_User_Code,
                 Ol.Last_Update_Date     = Sysdate,
                 Ol.Version = Nvl(Ol.Version, 0) + 1 --add by lizhen 2015-10-26
           Where Ol.Order_Line_Id = r_Order_Shares.Origin_Line_Id;
          --更新订单明细行已分配数量
          Update t_Pln_Order_Detail Od
             Set Od.Share_Qty        = Nvl(Od.Share_Qty, 0) -
                                       r_Order_Shares.Canceling_Qty,
                 Od.Last_Updated_By  = p_User_Code,
                 Od.Last_Update_Date = Sysdate,
                 Od.Version = Nvl(Od.Version, 0) + 1 --add by lizhen 2015-10-26
           Where Od.Order_Line_Id = r_Order_Shares.Origin_Line_Id;

          --add by lizhen 2015-10-26更新订单头状态，订单行他问完成测把订单更新为已完成
          Update t_Pln_Order_Head Poh
             Set Poh.Form_State      =
                 (Select Decode(Sign(Sum(Nvl(Pol.Can_Produce_Qty, 0)) +
                                     Sum(Nvl(Pol.Inv_Affirm_Qty, 0)) -
                                     Sum(Nvl(Pol.Cancel_Inv_Check_Qty, 0)) -
                                     Sum(Nvl(Pol.Cancel_Inv_In_Qty, 0)) -
                                     Sum(Nvl(Pol.So_Order_Qty, 0))),
                                1,
                                Poh.Form_State, --已排产
                                '306' --已完成
                                )
                    From t_Pln_Order_Line Pol
                   Where Pol.Order_Head_Id = Poh.Order_Head_Id),
                 Poh.Last_Updated_By  = p_User_Code,
                 Poh.Last_Update_Date = Sysdate,
                 Poh.Version          = Nvl(Poh.Version, 0) + 1
           Where Poh.Order_Head_Id = r_Order_Shares.Origin_Head_Id;
        End If;

        If p_Result = v_Success Then
          v_Value := '更新订单发货计划的分配数量：';
          Update t_Pln_Order_Share_Shipment Oss
             Set Oss.Share_Qty    = Oss.Share_Qty - Oss.Canceling_Qty,
                 Oss.Carrying_Qty = Oss.Share_Qty - Oss.Canceling_Qty -
                                    Nvl(Oss.Carry_Qty, 0),
                 /*Oss.Shareing_Qty     = Oss.Share_Qty - Oss.Canceling_Qty -
                 Nvl(Oss.Carry_Qty, 0),*/
                 Oss.Last_Updated_By  = p_User_Code,
                 Oss.Last_Update_Date = Sysdate,
                 Oss.Version = Nvl(Oss.Version, 0) + 1 --add by lizhen 2015-10-26
           Where Oss.Order_Share_Id = r_Order_Shares.Order_Share_Id;

          Update t_Pln_Order_Share_Shipment Oss
             Set Oss.Canceling_Qty = 0,
                 Oss.Close_Flag    = Decode(Sign(Nvl(Oss.Share_Qty, 0) -
                                                 Nvl(Oss.Carry_Qty, 0)),
                                            0,
                                            v_True,
                                            v_False)
           Where Oss.Order_Share_Id = r_Order_Shares.Order_Share_Id;
        End If;

        Begin
          If p_Result = v_Success Then
            v_Value := '插入单据操作历史记录';
            Insert Into t_Pln_Order_Share_History
              (Order_Share_History_Id,
               Entity_Id, --主体ID
               Order_Header_Id, --单据头ID
               Order_Line_Id, --单据行ID
               Order_Share_Id, --发货计划ID
               Item_Id, --产品ID
               Item_Code, --产品编码
               Item_Name, --产品描述
               Inventory_From_Id, --发货仓库
               Option_Type, --操作类型
               Quantity, --数量
               Created_By,
               Creation_Date,
               Last_Updated_By,
               Last_Update_Date,
               Remark)
            Values
              (s_Pln_Order_Share_History.Nextval,
               /*p_Entity_Id*/v_curr_entity_id,
               r_Order_Shares.Origin_Head_Id,
               r_Order_Shares.Origin_Line_Id,
               r_Order_Shares.Order_Share_Id,
               r_Order_Shares.Item_Id,
               r_Order_Shares.Item_Code,
               r_Order_Shares.Item_Name,
               r_Order_Shares.Inventory_From_Id,
               '取消订单数量',
               Nvl(r_Order_Shares.Canceling_Qty, 0),
               p_User_Code,
               Sysdate,
               p_User_Code,
               Sysdate,
               '计划订单发货计划，取消订单数据处理！');
          End If;
        Exception
          When Others Then
            p_Result := v_Value || Sqlerrm || '，订单号：' || v_Order_Number;
            Raise v_Base_Exception;
        End;
      End Loop;
    End If;
    If p_Result <> v_Success Then
      Rollback;
    End If;

  Exception
    When v_Base_Exception Then
      p_Result := p_Result;
      Rollback;
    When Others Then
      p_Result := p_Result;
      --P_ERR_MSG := V_VALUE || '失败，' || SQLERRM;
      Rollback;
  End;

  -----------------------------------------------------------------------------
  -- AUTHOR  : 何加源
  -- CREATED : 2016-06-20
  -- PURPOSE : 提货订单关闭时，若计划订单存在特殊占用，优先处理特殊占用
  -----------------------------------------------------------------------------
  PROCEDURE p_lg_Close_Cancel_Sp_Occ(p_order_line_id IN NUMBER, --计划订单行ID
                                     p_close_qty     IN NUMBER, --关闭数量
                                     p_lg_order_id   IN NUMBER,
                                     p_lg_order_number  IN VARCHAR2,
                                     p_lg_order_line_id IN NUMBER,
                                     p_user_code     IN VARCHAR2, --用户
                                     p_remain_qty    IN OUT NUMBER, --剩余数量
                                     p_Result        In Out VARCHAR2--返回结果：成功返回SUCCESS，失败返回原因
                                     ) IS
    v_total_cancel_qty NUMBER := 0;
    v_remain_cancel_qty NUMBER := 0;
    v_curr_remain_cancel_qty NUMBER := 0;
    v_curr_occupy_qty NUMBER := 0; --本次需处理的特殊占用数量
    v_curr_cancel_qty NUMBER := 0; --当次处理数量
    v_count NUMBER;
    V_ORDER_SHARE_ID NUMBER; --分配行ID
    v_inv_flag VARCHAR2(10); --库存评审标志
    v_can_produce_qty NUMBER; --排产数量
    v_inv_affirm_qty NUMBER; --库存评审数量
    v_Entity_Id      Number;
  BEGIN
    p_Result := v_Success;
    --add by lizhen 2016-07-30 获取主体ID
    Begin
      Select Lol.Entity_Id
        Into v_Entity_Id
        From t_Pln_Lg_Order_Line Lol
       Where Lol.Order_Line_Id = p_Lg_Order_Line_Id;
    Exception
      When Others Then
        p_Result := '获取提货订单行信息失败！';
        Raise v_Base_Exception;
    End;
    v_total_cancel_qty := p_close_qty;
    v_remain_cancel_qty := v_total_cancel_qty;
    IF v_total_cancel_qty > 0 THEN --数量大于0才处理
      --按仓库
      FOR R_SP_INV IN (SELECT Q.ORDER_LINE_ID, Q.INVENTORY_ID
                         FROM V_PLN_ORDER_INV_OCC_QTY Q
                        WHERE Q.ORDER_LINE_ID = p_order_line_id
                        GROUP BY Q.ORDER_LINE_ID, Q.INVENTORY_ID
                        ORDER BY MAX(Q.SUB_OCCUPY_QTY) - MIN(Q.SUB_OCCUPY_QTY)) LOOP

        --获取套机的特殊占用数量
        SELECT least(nvl(max(D.ASS_OCCUPY_QTY), 0), v_remain_cancel_qty)
          INTO v_curr_cancel_qty
          FROM V_PLN_ORDER_INV_OCC_QTY D
         WHERE D.ORDER_LINE_ID = R_SP_INV.Order_Line_Id
           AND d.INVENTORY_ID = R_SP_INV.Inventory_Id;

        --剩余待处理取消数量
        v_remain_cancel_qty := v_remain_cancel_qty - v_curr_cancel_qty;

        IF v_curr_cancel_qty > 0 THEN
          FOR r_sp_line_item IN (SELECT Q.ORDER_LINE_ID, Q.INVENTORY_ID, Q.SUB_ITEM_ID,
                                        LEAST(SUM(Q.SUB_OCCUPY_QTY), v_curr_cancel_qty) item_cancel_qty
                                   FROM V_PLN_ORDER_INV_OCC_QTY Q
                                  WHERE Q.ORDER_LINE_ID = R_SP_INV.ORDER_LINE_ID
                                    AND Q.INVENTORY_ID = R_SP_INV.INVENTORY_ID
                                   GROUP BY Q.ORDER_LINE_ID, Q.INVENTORY_ID, Q.SUB_ITEM_ID) LOOP
            v_curr_remain_cancel_qty := r_sp_line_item.item_cancel_qty;

            FOR r_detail IN (SELECT o.*
                               FROM t_pln_inv_special_occupy o
                              WHERE o.origin_line_id = r_sp_line_item.Order_Line_Id
                                AND o.inventory_id = r_sp_line_item.Inventory_Id
                                AND o.item_id = r_sp_line_item.sub_item_id
                                And O.ENTITY_ID = v_Entity_Id
                                AND nvl(o.occupy_qty, 0) - nvl(o.release_qty, 0) > 0) LOOP
              v_curr_occupy_qty := least(v_curr_remain_cancel_qty, nvl(r_detail.occupy_qty,0)-nvl(r_detail.release_qty,0));
              v_curr_remain_cancel_qty := v_curr_remain_cancel_qty - v_curr_occupy_qty;

              IF v_curr_occupy_qty > 0 THEN
                --特殊占用释放
                Pkg_Pln_Inv_Occupy.p_Dispose_Special_Occupy(p_Inventory_Id         => r_detail.inventory_id,
                                                            p_Item_Id              => r_detail.item_id,
                                                            --modi by lizhen 2016-07-30 特殊占用日期事务日期使用特殊占用表的日期
                                                            p_Trans_Date           => trunc(r_detail.transaction_date),
                                                            p_Sign_Type            => -1,
                                                            p_Trans_Qty            => v_curr_occupy_qty,
                                                            p_Special_Type         => '44',
                                                            p_Entity_Id            => r_detail.entity_id,
                                                            p_Origin_Order_Type_Id => r_detail.origin_order_type_id,
                                                            p_Origin_Head_Id       => r_detail.origin_head_id,
                                                            p_Origin_Order_Number  => r_detail.origin_order_number,
                                                            p_Origin_Line_Id       => r_detail.origin_line_id,
                                                            p_Source_Order_Type    => '提货订单',
                                                            p_Source_Head_Id       => p_lg_order_id,
                                                            p_Source_Order_Number  => p_lg_order_number,
                                                            p_Source_Line_Id       => p_lg_order_line_id,
                                                            p_User_Code            => p_user_code,
                                                            p_Result               => p_Result);

                IF p_Result <> v_Success THEN
                  RAISE v_Base_Exception;
                END IF;

                --更新锁定表历史
                Insert Into Cims.t_Pln_Order_Inv_Occupy_His
                 (Entity_Id,
                  Inv_Occupy_His_Id,
                  Origin_Type,
                  Origin_Head_Id,
                  Origin_Number,
                  Origin_Line_Id,
                  Source_Order_Type,
                  Source_Order_Head_Id,
                  Source_Order_Number,
                  Source_Order_Line_Id,
                  Operation_Type,
                  Action_Desc,
                  Item_Id,
                  Inventory_Id,
                  Stock_Affirm_Qty,
                  Supply_Qty,
                  So_Order_Qty,
                  Sundry_Qty,
                  Sundry_Type,
                  Created_By,
                  Creation_Date,
                  Last_Updated_By,
                  Last_Update_Date,
                  Reamrk)
                  Select Iso.Entity_Id,
                         s_Pln_Order_Inv_Occupy_His.Nextval Inv_Occupy_His_Id,
                         '订单与工单完全匹配' Origin_Type,
                         Iso.Origin_Head_Id,
                         Iso.Origin_Order_Number Origin_Number,
                         Iso.Origin_Line_Id,
                         Iso.Origin_Order_Type_Name Source_Order_Type,
                         Iso.Origin_Head_Id Source_Order_Head_Id,
                         Iso.Origin_Order_Number Source_Order_Number,
                         Iso.Origin_Line_Id Source_Order_Line_Id,
                         Iso.Special_Type Operation_Type,
                         '提货订单关闭，释放特殊占用数量' Action_Desc,
                         Iso.Item_Id,
                         Iso.Inventory_Id,
                         0 Stock_Affirm_Qty,
                         0 Supply_Qty,
                         0 So_Order_Qty,
                         -1 * v_curr_occupy_qty Sundry_Qty,
                         Iso.Special_Type Sundry_Type,
                         p_user_code Created_By,
                         Sysdate Creation_Date,
                         p_user_code Last_Updated_By,
                         Sysdate Last_Update_Date,
                         '提货订单关闭，释放特殊占用数量' Reamrk
                    FROM t_Pln_Inv_Special_Occupy Iso
                   Where Iso.Special_Occupy_Id = r_detail.special_occupy_id;

                --更新锁定表
                UPDATE Cims.t_Pln_Order_Inv_Occupy O
                   SET o.sundry_qty = o.sundry_qty - v_curr_occupy_qty,
                       o.sundry_type = r_detail.special_type,
                       O.LAST_UPDATED_BY = 'admin',
                       o.last_update_date = SYSDATE,
                       o.version = NVL(o.version, 0) + 1
                 WHERE O.ORIGIN_TYPE = '订单与工单完全匹配'
                   AND O.ORIGIN_LINE_ID = r_detail.Origin_Line_Id
                   AND o.inventory_id = r_detail.inventory_id
                   AND o.item_id = r_detail.item_id;

              END IF;

              IF v_curr_remain_cancel_qty <= 0 THEN
                EXIT;
              END IF;
            END LOOP;
          END LOOP;

          --取消订单处理
          SELECT COUNT(1) INTO v_count
            FROM cims.t_pln_order_share_shipment s
           WHERE s.inventory_from_id = R_SP_INV.Inventory_Id
             AND s.origin_line_id = R_SP_INV.Order_Line_Id;

          IF v_count = 1 THEN --若分配行只有1行数据
            SELECT S.ORDER_SHARE_ID, S.INV_SHARE_FLAG
              INTO V_ORDER_SHARE_ID, v_inv_flag
              FROM cims.t_pln_order_share_shipment s
             WHERE S.INVENTORY_FROM_ID = R_SP_INV.Inventory_Id
               AND S.ORIGIN_LINE_ID = R_SP_INV.Order_Line_Id;
          ELSIF v_count > 1 THEN --若分配行有超过1行数据
            SELECT l.can_produce_qty - nvl(l.cancel_inv_in_qty,0),
                   l.inv_affirm_qty - NVL(l.cancel_inv_check_qty,0)
              INTO v_can_produce_qty, v_inv_affirm_qty
              FROM cims.t_pln_order_line l
             WHERE l.order_line_id = R_SP_INV.order_line_id;

            IF v_can_produce_qty >= v_curr_cancel_qty THEN
              v_inv_flag := 'N';
            ELSIF v_inv_affirm_qty >= v_curr_cancel_qty THEN
              v_inv_flag := 'Y';
            END IF;

            SELECT S.ORDER_SHARE_ID, S.INV_SHARE_FLAG
              INTO V_ORDER_SHARE_ID, v_inv_flag
              FROM cims.t_pln_order_share_shipment s
             WHERE S.INVENTORY_FROM_ID = R_SP_INV.Inventory_Id
               AND S.ORIGIN_LINE_ID = R_SP_INV.order_line_id
               AND NVL(S.INV_SHARE_FLAG,'N') = v_inv_flag
               AND ROWNUM = 1;
          END IF;

          --取消订单
          --插入分配历史
          IF v_count > 0 THEN
            Insert Into t_Pln_Order_Share_History
             (Order_Share_History_Id,
              Entity_Id,
              Order_Header_Id,
              Order_Line_Id,
              Order_Share_Id,
              Item_Id,
              Item_Code,
              Item_Name,
              Inventory_From_Id,
              Option_Type,
              Quantity,
              Created_By,
              Creation_Date,
              Last_Updated_By,
              Last_Update_Date,
              Remark,
              Version,
              Lg_Order_Head_Id,
              Lg_Order_Line_Id)
            Select s_Pln_Order_Share_History.Nextval Order_Share_History_Id,
                   Oss.Entity_Id,
                   Oss.Origin_Head_Id Order_Header_Id,
                   Oss.Origin_Line_Id Order_Line_Id,
                   Oss.Order_Share_Id,
                   Oss.Item_Id,
                   Oss.Item_Code,
                   Oss.Item_Name,
                   Oss.Inventory_From_Id,
                   '取消订单数量' Option_Type,
                   v_curr_cancel_qty Quantity,
                   p_user_code Created_By,
                   Sysdate Creation_Date,
                   p_user_code Last_Updated_By,
                   Sysdate Last_Update_Date,
                   '提货订单关闭，取消订单' Remark,
                   1 Version,
                   p_lg_order_id Lg_Order_Head_Id,
                   p_lg_order_line_id Lg_Order_Line_Id
              From Cims.t_Pln_Order_Share_Shipment Oss
             WHERE oss.order_share_id = V_ORDER_SHARE_ID;
          ELSE
            Insert Into t_Pln_Order_Share_History
              (Order_Share_History_Id,
              Entity_Id,
              Order_Header_Id,
              Order_Line_Id,
              Order_Share_Id,
              Item_Id,
              Item_Code,
              Item_Name,
              Inventory_From_Id,
              Option_Type,
              Quantity,
              Created_By,
              Creation_Date,
              Last_Updated_By,
              Last_Update_Date,
              Remark,
              Version,
              Lg_Order_Head_Id,
              Lg_Order_Line_Id)
            Select s_Pln_Order_Share_History.Nextval Order_Share_History_Id,
                   h.Entity_Id,
                   h.order_head_id Order_Header_Id,
                   l.order_line_id Order_Line_Id,
                   -1,
                   l.item_id,
                   l.Item_Code,
                   l.Item_Desc,
                   R_SP_INV.Inventory_Id,
                   '取消订单数量' Option_Type,
                   v_curr_cancel_qty Quantity,
                   p_user_code Created_By,
                   Sysdate Creation_Date,
                   p_user_code Last_Updated_By,
                   Sysdate Last_Update_Date,
                   '提货订单关闭，取消订单' Remark,
                   1 Version,
                   p_lg_order_id Lg_Order_Head_Id,
                   p_lg_order_line_id Lg_Order_Line_Id
              From Cims.t_Pln_Order_Line l,cims.t_pln_order_head h
             WHERE l.order_line_id = R_SP_INV.order_line_id
               AND l.order_head_id = h.order_head_id;
          END IF;

          --取消订单
          Insert Into Cims.t_Pln_Order_Inv_Occupy_His
           (Entity_Id,
            Inv_Occupy_His_Id,
            Origin_Type,
            Origin_Head_Id,
            Origin_Number,
            Origin_Line_Id,
            Source_Order_Type,
            Source_Order_Head_Id,
            Source_Order_Number,
            Source_Order_Line_Id,
            Operation_Type,
            Action_Desc,
            Item_Id,
            Inventory_Id,
            Stock_Affirm_Qty,
            Supply_Qty,
            So_Order_Qty,
            Sundry_Qty,
            Sundry_Type,
            Created_By,
            Creation_Date,
            Last_Updated_By,
            Last_Update_Date,
            Reamrk,
            Version)
            Select o.Entity_Id,
                   s_Pln_Order_Inv_Occupy_His.Nextval Inv_Occupy_His_Id,
                   '订单与工单完全匹配' Origin_Type,
                   o.Origin_Head_Id,
                   o.origin_number Origin_Number,
                   o.Origin_Line_Id,
                   o.origin_type Source_Order_Type,
                   o.origin_head_id Source_Order_Head_Id,
                   o.origin_number Source_Order_Number,
                   o.origin_line_id Source_Order_Line_Id,
                   '44' Operation_Type,
                   '提货订单关闭，取消订单' Action_Desc,
                   o.Item_Id,
                   o.Inventory_Id,
                   0 Stock_Affirm_Qty,
                   0 Supply_Qty,
                   0 So_Order_Qty,
                   v_curr_cancel_qty Sundry_Qty,
                   '44' Sundry_Type,
                   p_user_code Created_By,
                   Sysdate Creation_Date,
                   p_user_code Last_Updated_By,
                   Sysdate Last_Update_Date,
                   '提货订单关闭，取消订单' Reamrk,
                   1 Version
              From Cims.t_Pln_Order_Inv_Occupy o
             Where o.origin_line_id = R_SP_INV.Order_Line_Id
               AND o.inventory_id = R_SP_INV.Inventory_Id
               and o.ORIGIN_TYPE = '订单与工单完全匹配';

          --更新锁定表
          UPDATE Cims.t_Pln_Order_Inv_Occupy O
             SET o.sundry_qty = o.sundry_qty + v_curr_cancel_qty,
                 o.sundry_type = '44',
                 o.last_updated_by = p_user_code,
                 o.last_update_date = SYSDATE,
                 o.version = NVL(o.version, 0) + 1
           WHERE O.ORIGIN_TYPE = '订单与工单完全匹配'
             AND O.ORIGIN_LINE_ID = R_SP_INV.Order_Line_Id
             AND o.inventory_id = R_SP_INV.Inventory_Id;

          --更新订单行
          Update Cims.t_Pln_Order_Line Ol
             Set Ol.Cancel_Inv_In_Qty    = Nvl(Ol.Cancel_Inv_In_Qty, 0) +
                                           Decode(v_inv_flag,
                                                  'N',
                                                  Nvl(v_curr_cancel_qty, 0),
                                                  0),
                 Ol.Cancel_Inv_Check_Qty = Nvl(Ol.Cancel_Inv_Check_Qty, 0) +
                                           Decode(v_inv_flag,
                                                  'Y',
                                                  Nvl(v_curr_cancel_qty, 0),
                                                  0),
                 ol.last_updated_by = p_user_code,
                 ol.last_update_date = SYSDATE,
                 ol.version = NVL(ol.version, 0) + 1
           Where Ol.Order_Line_Id = R_SP_INV.order_line_id;

          --更新订单头状态
          Update Cims.t_Pln_Order_Head Poh
             Set Poh.Form_State      =
                 (Select Decode(Sign(Sum(Nvl(Pol.Can_Produce_Qty, 0)) +
                                     Sum(Nvl(Pol.Inv_Affirm_Qty, 0)) -
                                     Sum(Nvl(Pol.Cancel_Inv_Check_Qty, 0)) -
                                     Sum(Nvl(Pol.Cancel_Inv_In_Qty, 0)) -
                                     Sum(Nvl(Pol.So_Order_Qty, 0))),
                                1,
                                '32', --已排产
                                '306' --已完成
                                )
                    From Cims.t_Pln_Order_Line Pol
                   Where Pol.Order_Head_Id = Poh.Order_Head_Id),
                 Poh.Last_Updated_By  = p_user_code,
                 Poh.Last_Update_Date = Sysdate,
                 Poh.Version          = Nvl(Poh.Version, 0) + 1
           Where Poh.Order_Head_Id = (SELECT l.order_head_id FROM cims.t_pln_order_line l
                                       WHERE l.order_line_id = R_SP_INV.Order_Line_Id);

          IF v_remain_cancel_qty <= 0 THEN
            EXIT;
          END IF;
        END IF;
      END LOOP;
    END IF;

    p_remain_qty := v_remain_cancel_qty;
  EXCEPTION
    WHEN v_Base_Exception THEN
      p_Result := p_Result;
      Rollback;
    When Others Then
      p_Result := '提货订单关闭释放计划订单特殊占用失败！' || v_Nl || Sqlerrm;
      Rollback;
  END p_lg_Close_Cancel_Sp_Occ;

  -----------------------------------------------------------------------------
  -- AUTHOR  : 李振
  -- CREATED : 2015-08-29
  -- PURPOSE : 提货订单关闭时，同步取消计划订单
  -----------------------------------------------------------------------------
  Procedure p_Lg_Close_Cancel_Order(p_Order_Head_Id    In Number, --订单ID
                                    p_User_Code        In Varchar2, ----用户ID
                                    p_Result           In Out Varchar2,--返回结果：成功返回SUCCESS，失败返回原因
                                    p_Close_Line_Flag  In Varchar2 Default 'N' --是否关闭订单行 --add by lizhen 2016-06-14
                                    ) Is
    r_Lg_Order_head    t_pln_lg_order_head%Rowtype;
    v_Count            Number;
    v_Lg_Close_Qty     Number;
    v_Sum_Close_Qty    Number;
    v_can_cancel_qty   Number;
    v_remain_close_qty NUMBER;
    v_Item_Code_List   Varchar2(4000);
    v_Match_Qty        Number;
    v_Sum_Cancel_Match_Qty   Number := 0;
    v_Remain_Cancel_Match_Qty Number := 0;
    v_current_Cancel_Match_Qty Number := 0;
    v_Relation_Type          Varchar2(32);
    v_trsf_order_num   varchar2(4000);
    v_ship_doc_code    varchar2(4000);
  Begin
    p_Result := v_Success;
    Select Count(*)
      Into v_Count
      From t_Pln_Lg_Order_Line Ol,
           t_Pln_Lg_Relation   Lr,
           t_Pln_Order_Line    Pol
     Where Ol.Order_Line_Id = Lr.Lg_Order_Line_Id
       And Pol.Order_Line_Id = Lr.Order_Line_Id
       And Ol.Order_Head_Id = p_Order_Head_Id
          --add by lizhen 2016-06-14增加按行关闭功能控制
       And ((p_Close_Line_Flag = 'N' And
           Nvl(Ol.Order_Line_State, 'NORMAL') != v_Line_State_Closed) Or
           (p_Close_Line_Flag = 'Y' And
           Nvl(Ol.Order_Line_State, 'NORMAL') = v_Line_State_Awaited));
    If Nvl(v_Count, 0) = 0 Then
      --无计划订单关联则不需往下处理，直接返回。
      Return;
    End If;
    Begin
      Select *
        Into r_Lg_Order_Head
        From t_Pln_Lg_Order_Head Oh
       Where Oh.Order_Head_Id = p_Order_Head_Id
         For Update Nowait;
    Exception
      When Others Then
        p_Result := '查询提货订单头失败！' || v_Nl || '提货订单头ID：' ||
                    To_Char(p_Order_Head_Id) || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;
    Begin
      Select Count(*),
             Listagg(Ol.Item_Code, ',') Within Group(Order By Ol.Order_Head_Id) Item_Code_List
        Into v_Count, v_Item_Code_List
        From t_Pln_Lg_Order_Line Ol,
             t_Pln_Lg_Relation   Lr,
             t_Pln_Order_Line    Pol,
             t_Pln_Order_Head    Poh
       Where Ol.Order_Line_Id = Lr.Lg_Order_Line_Id
         And Pol.Order_Line_Id = Lr.Order_Line_Id
         And Ol.Order_Head_Id = p_Order_Head_Id
         And Pol.Order_Head_Id = Poh.Order_Head_Id
         --add by lizhen 2017-02-27 T+3订单检查是否全部入库
         And Lr.Relation_Type = 'T3_ORDER_TYPE'
            --add by lizhen 2016-06-12增加按行关闭功能控制
         And ((p_Close_Line_Flag = 'N' And
             Nvl(Ol.Order_Line_State, 'NORMAL') != v_Line_State_Closed) Or
             (p_Close_Line_Flag = 'Y' And
             Nvl(Ol.Order_Line_State, 'NORMAL') = v_Line_State_Awaited))
         And ((Pol.Can_Produce_Qty >
             Nvl(Pol.Supply_Qty, 0) + Nvl(Pol.Check_Adjust_Qty, 0) And
             Poh.Form_State In ('23', '32')) Or
             Poh.Form_State Not In ('23', '32', '304', '306'))
      --统计检查取消数量时，库存评审的不统计，放到后面取消后检查
      /*And Pol.Can_Produce_Qty + Nvl(Pol.Inv_Affirm_Qty, 0) >
      Nvl(Pol.Supply_Qty, 0) + Nvl(Pol.Cancel_Inv_In_Qty, 0) +
      Nvl(Pol.Cancel_Inv_Check_Qty, 0)*/
      ;
    Exception
      When Others Then
        p_Result := '获取提货订单对应计划订单的入库情况，是否已全部入库完成。' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;
    If Nvl(v_Count, 0) > 0 Then
      If p_Close_Line_Flag = 'Y' Then
        p_Result := '提货订单对应计划订单的未全部入库，不允许提货订单关闭！' || v_Nl ||
          '本次关闭行的产品编码信息：' || v_Item_Code_List || v_Nl ||
          '提货订单单号：' || r_Lg_Order_head.Order_Number;
      Else
        p_Result := '提货订单对应计划订单的未全部入库，不允许提货订单关闭！' || v_Nl ||
          '提货订单单号：' || r_Lg_Order_head.Order_Number;
      End If;
      Raise v_Base_Exception;
    End If;
    For r_Lg_Order_Line In (Select Ol.*
                              From t_Pln_Lg_Order_Line Ol
                             Where Ol.Order_Head_Id = p_Order_Head_Id
                             --add by lizhen 2016-06-12增加按行关闭功能控制
                             And ((p_Close_Line_Flag = 'N' And
                                 Nvl(Ol.Order_Line_State, 'NORMAL') != v_Line_State_Closed) Or
                                 (p_Close_Line_Flag = 'Y' And
                                 Nvl(Ol.Order_Line_State, 'NORMAL') = v_Line_State_Awaited))
                             And Exists(Select 1 From t_Pln_Lg_Relation t
                                                Where t.Lg_Order_Head_Id = p_Order_Head_Id
                                                 And t.Lg_Order_Line_Id = Ol.Order_Line_Id)) Loop
      --modi by lizhen 2015-12-04 提货订单关闭时，取消T+3订单数量计算,匹配订单数量
      If p_Close_Line_Flag = 'Y' And nvl(r_Lg_Order_Line.closing_qty,0) > 0 Then
        v_Lg_Close_Qty := r_Lg_Order_Line.closing_qty;
      Else
        v_Lg_Close_Qty := Nvl(r_Lg_Order_Line.To_Pln_Qty, 0) - Nvl(r_Lg_Order_Line.Pln_Affirmed_Qty, 0)
                        - (nvl(r_Lg_Order_Line.direct_transport_qty,0) - nvl(r_Lg_Order_Line.already_direct_transport_qty,0)) ;
      End If;
      /*v_Lg_Close_Qty := Nvl(r_Lg_Order_Line.Center_Affirm_Quantity,
                            r_Lg_Order_Line.Quantity) -
                        Nvl(r_Lg_Order_Line.Affirmed_Quantity, 0);*/
      --循环计划订单行，为将来订单订单行拆分多计划订单行做预留
      --add by lizhen 2016-02-01 已全部发完货的T+3提货行不需要进行发货计划取消
      If Nvl(v_Lg_Close_Qty, 0) != 0 Then
        v_Remain_Cancel_Match_Qty := v_Lg_Close_Qty;
        For r_Order_Line In (Select Plr.Relation_Type, --add by lizhen 2017-02-27
                                    Nvl(Plr.Match_Qty, 0) - Nvl(Plr.Ship_Qty, 0) Cancel_Match_Qty,
                                    Plr.Relation_Id,
                                    Pol.*
                               From t_Pln_Order_Line  Pol,
                                    t_Pln_Order_Head  Poh,
                                    t_Pln_Lg_Relation Plr
                              Where Pol.Order_Head_Id = Poh.Order_Head_Id
                                And Plr.Order_Line_Id = Pol.Order_Line_Id
                                --add by lizhen 2017-02-27 取消订单时，只查询匹配数量大于0的数据
                                And (Plr.Relation_Type In ('T3_ORDER_TYPE','CUS_T3_ORDER_TYPE') Or
                                    (Plr.Relation_Type = 'PLN_ORDER_TYPE' And Plr.Match_Qty > 0))
                                And Plr.Lg_Order_Line_Id = r_Lg_Order_Line.Order_Line_Id) Loop
          v_Relation_Type := r_Order_Line.Relation_Type;
          If r_Order_Line.Relation_Type = 'T3_ORDER_TYPE' Then
            Begin
              --先处理特殊占用
              p_lg_Close_Cancel_Sp_Occ(p_order_line_id    => r_Order_Line.Order_Line_Id,
                                       p_close_qty        => v_Lg_Close_Qty, --关闭数量
                                       p_lg_order_id      => r_Lg_Order_Line.order_head_id,
                                       p_lg_order_number  => r_Lg_Order_Head.Order_Number,
                                       p_lg_order_line_id => r_Lg_Order_Line.order_line_id,
                                       p_user_code        => p_User_Code, --用户
                                       p_remain_qty       => v_remain_close_qty, --剩余数量
                                       p_Result           => p_Result);

              IF p_Result <> v_Success THEN
                RAISE v_Base_Exception;
              END IF;

              --剩余数量大于0才处理
              IF v_remain_close_qty > 0 THEN
                For r_Share_Ship In (Select Nvl(Oss.Share_Qty, 0) -
                                            Nvl(Oss.Carry_Qty, 0) Usable_Cancel_Qty,
                                            Oss.*
                                       From t_Pln_Order_Share_Shipment Oss
                                      Where Oss.Origin_Line_Id = r_Order_Line.Order_Line_Id) LOOP
                  --检查是否存在为确认的发货计划
                  SELECT COUNT(1)
                    INTO v_Count
                    FROM T_LG_SHIP_PLAN P
                   WHERE P.ORIGIN_ORDER_NUM = r_Share_Ship.Origin_Head_Code
                     AND P.ORIGIN_SHIP_PLAN_ID = r_Share_Ship.Order_Share_Id
                     AND P.STATUS IN ('00', '01') --未分配、已分配
                     AND P.ORIGIN_ORIGIN_HEAD_ID IS NULL
                     AND P.ORIGIN_ORIGIN_LINE_ID IS NULL
                     AND P.CONSIGNEE_INVENTORY_CODE IS NOT NULL
                     AND P.UNAFFIRM_QTY > 0;
                  If v_Count > 0 Then
                    p_Result := '计划订单存在未确认的发货计划，提货订单关闭失败！' || v_Nl ||
                      '计划订单号：' || r_Share_Ship.Origin_Head_Code || v_Nl ||
                      '请通过【物流管理-分配承运商】界面查看';
                    Raise v_Base_Exception;
                  End If;

                  --检查制定发货需求计划调拨生成的未发的发货通知单 lilh6 18-6-5
                  SELECT to_char(wm_concat(d.ship_doc_code))
                    INTO v_ship_doc_code
                    FROM T_LG_SHIP_DOC D, T_LG_SHIP_DOC_LINE L
                   WHERE D.SHIP_DOC_ID = L.SHIP_DOC_ID
                     AND L.ORIGIN_ORDER_NUM = r_share_ship.origin_head_code
                     AND L.ORIGIN_SHIP_PLAN_ID = r_share_ship.order_share_id
                     AND D.DOC_STATUS = '00'
                     AND L.ORIGIN_ORIGIN_HEAD_ID IS NULL
                     AND L.ORIGIN_ORIGIN_LINE_ID IS NULL
                     AND D.CONSIGNEE_INVENTORY_CODE IS NOT NULL
                     AND NVL(L.ITEM_QTY, 0) - NVL(L.FACT_SHIP_QTY, 0) - NVL(L.CANCEL_QTY, 0) > 0;
                  If v_ship_doc_code IS NOT NULL Then
                    p_Result := '计划订单存在调拨的发货通知单未全部发货或取消，提货订单关闭失败！' || v_Nl ||
                      '计划订单单号：' || r_Share_Ship.Origin_Head_Code || v_Nl ||
                      '发货通知单号：' || v_ship_doc_code;
                    Raise v_Base_Exception;
                  End If;
                  --检查未接收的调拨单
                  Select to_char(wm_concat(ito.trsf_order_num))
                    Into v_trsf_order_num
                    From t_Inv_Trsf_Order Ito, t_Inv_Trsf_Order_Line Tol
                   Where Ito.Trsf_Order_Id = Tol.Trsf_Order_Id
                     And Tol.Origin_Ship_Plan_Id = r_Share_Ship.Order_Share_Id
                     And Ito.Trsf_Order_Status != '13' --未接收的调拨单
                     And Ito.Entity_Id = r_Share_Ship.Entity_Id;
                  If v_trsf_order_num IS NOT NULL Then
                    p_Result := '计划订单存在调拨单据未做接收，提货订单关闭失败！' || v_Nl ||
                      '计划订单单号：' || r_Share_Ship.Origin_Head_Code || v_Nl ||
                      '调拨单号：' || v_trsf_order_num;
                    Raise v_Base_Exception;
                  End If;

                  --更新订单发货计划待取消数量
                  IF r_Share_Ship.Usable_Cancel_Qty > 0 THEN
                    Update t_Pln_Order_Share_Shipment Oss
                       Set Oss.Canceling_Qty = least(r_Share_Ship.Usable_Cancel_Qty,v_Lg_Close_Qty)
                     Where Oss.Order_Share_Id = r_Share_Ship.Order_Share_Id;
                    p_Order_Cancel(p_Entity_Id    => r_Share_Ship.Entity_Id,
                                   p_Order_Shares => r_Share_Ship.Order_Share_Id,
                                   p_User_Code    => p_User_Code,
                                   p_Result       => p_Result);
                    If p_Result <> v_Success Then
                      Raise v_Base_Exception;
                    End If;
                  END IF;
                  v_Lg_Close_Qty := v_Lg_Close_Qty - least(r_Share_Ship.Usable_Cancel_Qty,v_Lg_Close_Qty);
                  If v_Lg_Close_Qty = 0 Then
                    Exit;
                  End If;
                End Loop;
              END IF;
            End;
          Elsif r_Order_Line.Relation_Type = 'PLN_ORDER_TYPE' Then
            If v_Remain_Cancel_Match_Qty > r_Order_Line.Cancel_Match_Qty Then
              v_current_Cancel_Match_Qty := r_Order_Line.Cancel_Match_Qty;
              v_Remain_Cancel_Match_Qty := v_Remain_Cancel_Match_Qty - r_Order_Line.Cancel_Match_Qty;
            Else
              v_current_Cancel_Match_Qty := v_Remain_Cancel_Match_Qty;
              v_Remain_Cancel_Match_Qty := 0;
            End If;
            If v_current_Cancel_Match_Qty > 0 Then
              --add by lizhen 2017-02-27
              Update t_Pln_Order_Line Pol
                 Set Pol.Match_Qty        = Nvl(Pol.Match_Qty, 0) -
                                           v_current_Cancel_Match_Qty,
                     Pol.Last_Updated_By  = p_User_Code,
                     Pol.Last_Update_Date = Sysdate
               Where Pol.Order_Line_Id = r_Order_Line.Order_Line_Id
               Returning Pol.Match_Qty Into v_Match_Qty;
               If Nvl(v_Match_Qty, 0) < 0 Then
                 p_Result := '提货订单关闭失败，更新计划订单匹配数量后，计划订单匹配数量为负数！';
                 Raise v_Base_Exception;
               End If;

               --更新关系表已匹配数量
              Update t_Pln_Lg_Relation Plr
                 Set Plr.Match_Qty        = Nvl(Plr.Match_Qty, 0) -
                                            v_current_Cancel_Match_Qty,
                     Plr.Last_Update_Date = Sysdate,
                     Plr.Last_Updated_By  = p_User_Code,
                     Plr.Close_Flag       = 'Y'
               Where Plr.Relation_Id = r_Order_Line.Relation_Id;

               --插入匹配历史表
               Begin
                 Insert Into t_Pln_Lg_Match_His
                   (Entity_Id,
                    Match_His_Id, --id
                    Lg_Order_Head_Id, --提货订单头ID
                    Lg_Order_Line_Id, --提货订单行ID
                    Pln_Order_Head_Id, --计划订单头ID
                    Pln_Order_Line_Id, --计划订单行ID
                    Operation_Type, --操作类型
                    Match_Qty, --匹配数量
                    Remark, --备注
                    Creation_Date, --创建日期
                    Created_By, --创建人
                    Last_Update_Date,
                    Last_Updated_By)
                 Values
                   (r_Lg_Order_Head.Entity_Id, --Entity_Id,
                    s_Pln_Lg_Match_His.Nextval, --Match_His_Id, --id
                    r_Lg_Order_Line.Order_Head_Id, --Lg_Order_Head_Id, --提货订单头ID
                    r_Lg_Order_Line.Order_Line_Id, --Lg_Order_Line_Id, --提货订单行ID
                    r_Order_Line.Order_Head_Id, --Pln_Order_Head_Id, --计划订单头ID
                    r_Order_Line.Order_Line_Id, --Pln_Order_Line_Id, --计划订单行ID
                    'LGORDER_CLOSE_CANCEL_MATCH',--Operation_Type, --操作类型
                    v_current_Cancel_Match_Qty, --Match_Qty, --匹配数量
                    '提货订单关闭,取消未发货的匹配数量',-- Remark, --备注
                    Sysdate, --Creation_Date, --创建日期
                    p_User_Code, --Created_By, --创建人
                    Sysdate, -- Last_Update_Date,
                    p_User_Code --Last_Updated_By
                    );
              Exception
                When Others Then
                  p_Result := '提货订单关闭失败，插入匹配关系表异常。' || v_Nl || Sqlerrm;
                  Raise v_Base_Exception;
              End;
              v_Sum_Cancel_Match_Qty := v_Sum_Cancel_Match_Qty + v_current_Cancel_Match_Qty;
            End If;
          --发货计划提货订单匹配计划订单的，只更新下匹配数量
          Elsif r_Order_Line.Relation_Type = 'CUS_T3_ORDER_TYPE'Then
            Update t_Pln_Order_Line Pol
               Set Pol.Match_Qty        = greatest(Nvl(Pol.Match_Qty, 0) -
                                          v_Lg_Close_Qty,0),
                   Pol.Last_Updated_By  = p_User_Code,
                   Pol.Last_Update_Date = Sysdate
             Where Pol.Order_Line_Id = r_Order_Line.Order_Line_Id;

          End If;
        End Loop;
      End If;
        --统计对应计划订单行可取消数量，如果小于提货订单关闭数量则报异常
      Select Sum(Nvl(Pol.Inv_Affirm_Qty, 0) + Nvl(Pol.Can_Produce_Qty, 0) -
                 Nvl(Pol.Cancel_Inv_In_Qty, 0) -
                 Nvl(Pol.Cancel_Inv_Check_Qty, 0) +
                 --获取已调整取消数量
                 Nvl((Select Sum(Nvl(Al.Adjust_Qty, 0))
                       From t_Pln_Order_Adjust_Line Al,
                            t_Pln_Order_Adjust_Head Ah
                      Where Al.Order_Adjust_Head_Id =
                            Ah.Order_Adjust_Head_Id
                        And Ah.Adjust_State = '23'
                        And Al.Order_Line_Id = Pol.Order_Line_Id
                        And Al.Order_Head_Id = Pol.Order_Head_Id
                        And Ah.Order_Head_Id = Poh.Order_Head_Id),
                     0)),
             Sum(Nvl(Pol.Inv_Affirm_Qty, 0) + Nvl(Pol.Can_Produce_Qty, 0) -
                 Nvl(Pol.Cancel_Inv_In_Qty, 0) -
                 Nvl(Pol.Cancel_Inv_Check_Qty, 0) - Nvl(pol.carry_qty, 0))
        Into v_Sum_Close_Qty,v_can_cancel_qty
        From t_Pln_Order_Line  Pol,
             t_Pln_Order_Head  Poh,
             t_Pln_Lg_Relation Plr
       Where Pol.Order_Head_Id = Poh.Order_Head_Id
         And Plr.Order_Line_Id = Pol.Order_Line_Id
         And Plr.Lg_Order_Line_Id = r_Lg_Order_Line.Order_Line_Id;

      If Nvl(v_Lg_Close_Qty, 0) > nvl(v_Sum_Close_Qty, 0) And nvl(v_can_cancel_qty,0) <> 0 Then
        p_Result := '提货订单关闭失败。未提货数量【' || To_Char(Nvl(v_Lg_Close_Qty, 0)) || '】' ||
          ' > 计划订单可取消数量【' || To_Char(nvl(v_Sum_Close_Qty, 0)) ||'】';
        Raise v_Base_Exception;
      End If;

      --add by lizhen 2017-02-27 检查数据一致性
      If v_Lg_Close_Qty != v_Sum_Cancel_Match_Qty And v_Relation_Type = 'PLN_ORDER_TYPE' Then
        p_Result := '提货订单关闭失败，行与关系表可取消匹配数量不一致。行可取消匹配数量【' || To_Char(Nvl(v_Lg_Close_Qty, 0)) || '】' ||
          ' > 关系行取消匹配数量【' || To_Char(nvl(v_Sum_Cancel_Match_Qty, 0)) ||'】';
        Raise v_Base_Exception;
      End If;

      --更新行评数量信息
      If v_Relation_Type = 'T3_ORDER_TYPE' Then
        Update t_Pln_Lg_Order_Line Ol
           Set Ol.Affirm_Quantity = 0
         Where Ol.Order_Line_Id = r_Lg_Order_Line.Order_Line_Id;
      Else
        --add by lizhen 2017-02-27
        Update t_Pln_Lg_Order_Line Ol
           Set Ol.Affirm_Quantity = 0,
               Ol.To_Pln_Qty      = Nvl(Ol.To_Pln_Qty, 0) - v_Lg_Close_Qty
         Where Ol.Order_Line_Id = r_Lg_Order_Line.Order_Line_Id;
       End If;
      v_Sum_Cancel_Match_Qty := 0;
    End Loop;
  Exception
    When v_Base_Exception Then
      p_Result := p_Result;
      Rollback;
    When Others Then
      p_Result := '提货订单关联计划订单取消失败！' || v_Nl || Sqlerrm;
      Rollback;
  End;

  -----------------------------------------------------------------------------
  -- AUTHOR  :zhangchucai
  -- CREATED : 2014-10-27
  -- 自动生成周排产 第四周订单数据
  -----------------------------------------------------------------------------
  Procedure p_Order_Last_Week_Single(p_Produncing_Id   In Number, --产地Id
                                     p_Sales_Center_Id In Number, --营销中心Id
                                     p_Order_Type_Id   In Number, --订单类型Id
                                     p_Period_Id       In Number, --周期Id
                                     p_main_type_sys in varchar2,--订单大类参数
                                     p_sub_type_sys  in varchar2,-- 订单小类参数
                                     p_main_type     in varchar2,--订单大类
                                     p_sub_type      in varchar2,-- 订单小类
                                     p_Entity_Id       In Number, --主体Id
                                     p_User_Name       In Varchar2, --用户
                                     p_Result          In Out Varchar2) Is

    v_Order_Number         Varchar2(100);
    v_Order_Head_Id        Number;
    v_Result               Varchar2(200);
    v_Make_Rule            Varchar2(100);
    v_Form_State           Varchar2(10);
    v_Period_Code          Varchar2(100);
    v_Order_Type_Code      Varchar2(32);
    v_Order_Type_Name      Varchar2(100);
    v_Sales_Code           Varchar2(100);
    v_Sales_Name           Varchar2(100);
    v_Customer_Id          Number;
    v_Customer_Code        Varchar2(100);
    v_Customer_Name        Varchar2(100);
    v_Count_Id             Number;
    v_Count_Code           Varchar2(100);
    v_Count_Name           Varchar2(100);
    v_Produc_Id            Number;
    v_Produc_Code          Varchar2(100);
    v_Produc_Name          Varchar2(100);
    v_Invoice_Contract_Id  Number;
    v_Invoice_Contract     Varchar2(50);
    v_Invoice_Tel          Varchar2(100);
    v_Consignee_Id         Number; --收货单位ID
    v_Consignee_Code       Varchar2(200); --收货单位编码
    v_Consignee_Name       Varchar2(100); --收货单位名称
    v_Consignee_Addr       Varchar2(240); --收货单位地址
    v_Consignment_Addr_Id  Number; --收货地点Id
    v_Consignee_Addr_Code  Varchar2(20); --收货地点编码
    v_Consignee_Contact_Id Number; --收货单位联系人ID
    v_Consignee_Contract   Varchar2(50); --收货单位联系人
    v_Consignee_Tel        Varchar2(100); --收货单位联系人电话
    v_Creation_Date        Date;
    v_Sales_Main_Type      Varchar2(32); --营销大类
    v_Sales_Sub_Type       Varchar2(32); --营销小类
    v_Can_Supply_Date      Date;
    v_Beign_Date           Date;
    v_Batch_Id             Number;
    v_Temp                 Number;
    v_Period_Id            Number;
    v_Order_Line_Id        Number;
    v_Month_Period_Id      Number;
    v_Week_Sum_Check_Qty   Number; --周订单已评审数量
    Cursor Week_Month(p_Month_Period_Id Number) Is
      Select Line.Item_Id,
             TI.Item_Code,
             TI.ITEM_NAME ITEM_DESC,
             TI.DEFAULTUNIT Item_Uom,
             Max(Line.Item_Price) Item_Price,
             Line.Producing_Area_Id,
             TP.Producing_Area_Code,
             TP.Producing_Area_Name,
             Sum(Line.Can_Produce_Qty - Nvl(Line.Check_Adjust_Qty, 0)) Check_Qty,
             Max(ph.customer_id) Customer_Id
        From t_Pln_Order_Line Line,
             t_Pln_Order_Head Ph,
             t_Pln_Order_Type Ot,
             T_PLN_PRODUCING_AREA TP,
             T_BD_ITEM TI
       Where /*Line.Order_Head_Id In
                   (Select Ph.Order_Head_Id
                      From t_Pln_Order_Head Ph, t_Pln_Order_Type Ot
                     Where Ph.Sales_Center_Id = p_Sales_Center_Id
                       And Ot.Order_Type_Id = Ph.Order_Type_Id
                       And Ot.Dest_Order_Type_Id = p_Order_Type_Id
                       And Ph.Period_Id = p_Month_Period_Id
                       And Ot.Send_By_Type In (1, 2) --必须是月、月多次报送的订单类型
                       And Ph.Form_State = '23'
                       And Ph.Entity_Id = p_Entity_Id)*/

       Ph.Order_Head_Id = Line.Order_Head_Id
       And Ph.Sales_Center_Id = p_Sales_Center_Id
       And Ot.Order_Type_Id = Ph.Order_Type_Id
       And Ot.Dest_Order_Type_Id = p_Order_Type_Id
       AND LINE.ITEM_ID=TI.ITEM_ID
       AND TP.PRODUCING_AREA_ID=LINE.PRODUCING_AREA_ID
       And Ph.Period_Id = p_Month_Period_Id
       And Ot.Send_By_Type In (1, 2) --必须是月、月多次报送的订单类型
       And Ph.Form_State = '23'
       And Ph.Entity_Id = p_Entity_Id
       And (Line.Can_Produce_Qty+nvl(line.inv_affirm_qty,0)) > 0
       AND ('N'=p_main_type_sys or ('Y'=p_main_type_sys and ph.sales_main_type=p_main_type))--增加大类
       And ('N'=p_sub_type_sys or ('Y'=p_sub_type_sys and ph.sales_sub_type=p_sub_type))--增加小类
       Group By Line.Item_Id,
                TI.ITEM_CODE,
                TI.ITEM_NAME,
                TI.DEFAULTUNIT,
                Line.Producing_Area_Id,
                TP.Producing_Area_Code,
                TP.Producing_Area_Name;

    v_Pln_Order_Head t_Pln_Order_Head%Rowtype;
    Wm               Week_Month%Rowtype;
  Begin
    p_Result := v_Success;
    Begin
      Select Opp.Period_Id
        Into v_Month_Period_Id
        From t_Pln_Order_Period Op, t_Pln_Order_Period Opp
       Where Op.Period_Id = p_Period_Id
         And Opp.Period_Id = Op.Parent_Period_Id
         And Opp.Period_Type = '月';
    Exception
      When Others Then
        p_Result := '获取月周期ID失败，周订单周期ID:' || To_Char(p_Period_Id) || v_Nl ||
                    Sqlerrm;
        Raise v_Base_Exception;
    End;

    Begin
      Select Ph.*
        Into v_Pln_Order_Head --进行赋值
        From t_Pln_Order_Head Ph, t_Pln_Order_Type Ot
       Where Ph.Sales_Center_Id = p_Sales_Center_Id
         And Ot.Order_Type_Id = Ph.Order_Type_Id
         And Ot.Dest_Order_Type_Id = p_Order_Type_Id
         And Ph.Period_Id = v_Month_Period_Id
         And Ph.Form_State = '23'
         And Ph.Entity_Id = p_Entity_Id
         AND ('N'=p_main_type_sys or ('Y'=p_main_type_sys and ph.sales_main_type=p_main_type))--增加大类
         And ('N'=p_sub_type_sys or ('Y'=p_sub_type_sys and ph.sales_sub_type=p_sub_type))--增加小类
         And Rownum <= 1;
    Exception
      When Others Then
        p_Result := '获取月、增补订单信息失败' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;
    v_Sales_Code           := v_Pln_Order_Head.Sales_Center_Code;
    v_Sales_Name           := v_Pln_Order_Head.Sales_Center_Name;
    v_Customer_Id          := v_Pln_Order_Head.Customer_Id;
    v_Customer_Code        := v_Pln_Order_Head.Customer_Code;
    v_Customer_Name        := v_Pln_Order_Head.Customer_Name;
    v_Count_Id             := v_Pln_Order_Head.Account_Id;
    v_Count_Code           := v_Pln_Order_Head.Account_Code;
    v_Count_Name           := v_Pln_Order_Head.Account_Name;
    v_Produc_Id            := v_Pln_Order_Head.Producing_Area_Id;
    v_Produc_Code          := v_Pln_Order_Head.Producing_Area_Code;
    v_Produc_Name          := v_Pln_Order_Head.Producing_Area_Name;
    v_Consignee_Id         := v_Pln_Order_Head.Consignee_Id;
    v_Consignee_Code       := v_Pln_Order_Head.Consignee_Code;
    v_Consignee_Name       := v_Pln_Order_Head.Consignee_Name;
    v_Consignee_Addr       := v_Pln_Order_Head.Consignee_Addr;
    v_Consignment_Addr_Id  := v_Pln_Order_Head.Consignment_Addr_Id;
    v_Consignee_Addr_Code  := v_Pln_Order_Head.Consignee_Addr_Code;
    v_Consignee_Contact_Id := v_Pln_Order_Head.Consignee_Contact_Id;
    v_Consignee_Contract   := v_Pln_Order_Head.Consignee_Contract;
    v_Consignee_Tel        := v_Pln_Order_Head.Consignee_Tel;
    v_Sales_Main_Type      := v_Pln_Order_Head.Sales_Main_Type;
    v_Sales_Sub_Type       := v_Pln_Order_Head.Sales_Sub_Type;
    v_Invoice_Contract_Id  := v_Pln_Order_Head.Invoice_Contract_Id;
    v_Invoice_Contract     := v_Pln_Order_Head.Invoice_Contract;
    v_Invoice_Tel          := v_Pln_Order_Head.Invoice_Tel;

    Select p.Period_Code, p.End_Date, p.Begin_Date
      Into v_Period_Code, v_Can_Supply_Date, v_Beign_Date
      From t_Pln_Order_Period p
     Where p.Period_Id = p_Period_Id
       And p.Entity_Id = p_Entity_Id;

    Select Ty.Order_Type_Code, Ty.Order_Type_Name
      Into v_Order_Type_Code, v_Order_Type_Name
      From t_Pln_Order_Type Ty
     Where Ty.Order_Type_Id = p_Order_Type_Id
       And Ty.Entity_Id = p_Entity_Id;

    v_Batch_Id      := 1;
    v_Order_Head_Id := s_Pln_Order_Head.Nextval;
    v_Result        := Null;
    v_Make_Rule     := 'plnMakeOrder';
    v_Temp          := 1;
    v_Form_State    := '19';
    v_Period_Id     := p_Period_Id ;


    Begin
      Open Week_Month(v_Month_Period_Id);
    Exception
      When Others Then
        p_Result := '打开月、增补订单数据失败' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;

    Loop
      Fetch Week_Month
        Into Wm;
      If Week_Month%Rowcount = 0 Then
       Return ;
      End If;
      Exit When Week_Month%Notfound;

      Begin
        Select Sum(Pol.Can_Produce_Qty - Nvl(Pol.Check_Adjust_Qty, 0))
          Into v_Week_Sum_Check_Qty
          From t_Pln_Order_Line Pol, t_Pln_Order_Head Poh
         Where Pol.Order_Head_Id = Poh.Order_Head_Id
           And Poh.Form_State In (23, 32,306) --已评审完毕、已排产、已完成
           And Poh.Sales_Center_Id = p_Sales_Center_Id
           And Poh.Order_Type_Id = p_Order_Type_Id
           AND ('N'=p_main_type_sys or ('Y'=p_main_type_sys and Poh.sales_main_type=p_main_type))--增加大类
           And ('N'=p_sub_type_sys or ('Y'=p_sub_type_sys and Poh.sales_sub_type=p_sub_type))--增加小类
           And Exists
         (Select 1
                  From t_Pln_Order_Period Pop
                 Where Pop.Parent_Period_Id = v_Month_Period_Id
                   And Pop.Period_Id = Poh.Period_Id)
           And Pol.Item_Id = Wm.Item_Id
           And Pol.Producing_Area_Id = Wm.Producing_Area_Id;
      Exception
        When Others Then
          v_Week_Sum_Check_Qty := 0;
      End;

      Begin
        if v_Week_Sum_Check_Qty is null then
          v_Week_Sum_Check_Qty :=0;
        end if ;
        Insert Into t_Pln_Order_Line
          (Entity_Id,
           Order_Line_Id,
           Order_Head_Id,
           Producing_Area_Id,
           Producing_Area_Code,
           Producing_Area_Name,
           Item_Id,
           Item_Code,
           Item_Desc,
           Item_Uom,
           Item_Price,
           Month_Plan_Qty,
           Apply_Qty,
           Check_Qty,
           Can_Produce_Qty,
           Amount,
           Can_Supply_Date,
           Begin_Supply_Date,
           End_Supply_Date,
           Adjust_Qty,
           Created_By,
           Creation_Date,
           Last_Updated_By,
           Last_Update_Date)
        Values
          (p_Entity_Id,
           s_Pln_Order_Line.Nextval,
           v_Order_Head_Id,
           wm.Producing_Area_Id,
           wm.Producing_Area_Code,
           wm.Producing_Area_Name,
           wm.Item_Id,
           wm.Item_Code,
           wm.Item_Desc,
           wm.Item_Uom,
           wm.Item_Price,
           0,
           Wm.Check_Qty - v_Week_Sum_Check_Qty,
           Wm.Check_Qty - v_Week_Sum_Check_Qty,
           Wm.Check_Qty - v_Week_Sum_Check_Qty,
           (Wm.Check_Qty - v_Week_Sum_Check_Qty) * wm.Item_Price,
           v_Can_Supply_Date,
           v_Beign_Date,
           v_Can_Supply_Date,
           0,
           p_User_Name,
           Sysdate,
           p_User_Name,
           Sysdate);
      Exception
        When Others Then
          p_Result := Sqlerrm;
          Raise v_Base_Exception;
      End;
    End Loop;

    Pkg_Pln_Pub.p_Create_Order_Number(p_Order_Number_Type => v_Make_Rule, --订单号生产规则
                                      p_Period_Id         => v_Period_Id, --订单周期Id
                                      p_Sales_Center_Id   => p_Sales_Center_Id, --营销中心Id
                                      p_Entity_Id         => p_Entity_Id, --主体Id
                                      p_Order_Number      => v_Order_Number);
    If v_Order_Number Is Null Then
      p_Result := '没有获取正确的单号' || v_Nl || Sqlerrm;
      Raise v_Base_Exception;
    End If;

    --插入周排产第4周数据。
    Begin
      Insert Into t_Pln_Order_Head
        (Entity_Id,
         Order_Head_Id,
         Order_Number,
         Order_Type_Id,
         Order_Type_Code,
         Order_Type_Name,
         Period_Id,
         Period_Code,
         Form_State,
         Sales_Center_Id,
         Sales_Center_Code,
         Sales_Center_Name,
         Customer_Id,
         Customer_Code,
         Customer_Name,
         Account_Id,
         Account_Code,
         Account_Name,
         Sales_Main_Type,
         Batch_Id,
         Invoice_Customer_Id,
         Invoice_Customer_Code,
         Invoice_Customer_Name,
         Invoice_Contract_Id,
         Invoice_Contract,
         Invoice_Tel,
         Consignee_Id,
         Consignee_Code,
         Consignee_Name,
         Consignee_Addr,
         Consignment_Addr_Id,
         Consignee_Addr_Code,
         Consignee_Contact_Id,
         Consignee_Contract,
         Consignee_Tel,
         Created_By,
         Creation_Date,
         Last_Updated_By,
         Last_Update_Date,
         Remark,
         Producing_Area_Id,
         Producing_Area_Code,
         Producing_Area_Name,
         Sales_Sub_Type)
      Values
        (p_Entity_Id,
         v_Order_Head_Id,
         v_Order_Number,
         p_Order_Type_Id,
         v_Order_Type_Code,
         v_Order_Type_Name,
         p_Period_Id ,
         v_Period_Code,
         v_Form_State,
         p_Sales_Center_Id,
         v_Sales_Code,
         v_Sales_Name,
         v_Customer_Id,
         v_Customer_Code,
         v_Customer_Name,
         v_Count_Id,
         v_Count_Code,
         v_Count_Name,
         v_Sales_Main_Type,
         v_Batch_Id,
         v_Customer_Id,
         v_Customer_Code,
         v_Customer_Name,
         v_Invoice_Contract_Id,
         v_Invoice_Contract,
         v_Invoice_Tel,
         v_Consignee_Id,
         v_Consignee_Code,
         v_Consignee_Name,
         v_Consignee_Addr,
         v_Consignment_Addr_Id,
         v_Consignee_Addr_Code,
         v_Consignee_Contact_Id,
         v_Consignee_Contract,
         v_Consignee_Tel,
         p_User_Name,
         Sysdate,
         p_User_Name,
         Sysdate,
         Null,
         p_Produncing_Id,
         v_Produc_Code,
         v_Produc_Name,
         v_Sales_Sub_Type);
    Exception
      When Others Then
        p_Result := '插入周排产第4周订单头失败，' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;

    -- 是否有月增补月订单库存评审写到第四周
    p_Import_Order_Inv_Review(p_Sales_Center_Id ,   --中心ID
                              p_Period_Id     ,     --周排产订单周期ID
                              p_Order_Type_Id ,     --目标单据类型ID(目前是周排产订单）
                              v_Order_Head_Id  ,    --目标单据头ID
                              p_Entity_Id     ,     --主体ID
                              p_User_Name   ,       ----用户编码
                              p_Result             --返回结果：成功返回"SUCCESS"，失败返回原因
                              );
    If p_Result <> v_Success Then
      p_Result := p_Result;
      Raise v_Base_Exception;
    End If;
    --进行提交
    p_Submit_Order(v_Order_Head_Id, ----订单ID
                   v_Action_Submit, --当前单据动作
                   p_User_Name, ----用户编码
                   p_Result);
    If p_Result <> v_Success Then
      p_Result := p_Result;
      Raise v_Base_Exception;
    End If;
    Close Week_Month;
    If p_Result Is Null Then
      p_Result := v_Success;
    End If;
  Exception
    When v_Base_Exception Then
      Rollback;
      p_Result := p_Result;
    When Others Then
      p_Result := p_Result || v_Nl || Sqlerrm;
      Rollback;
  End;
  -----------------------------------------------------------------------------
  -- AUTHOR  : NICRO.LI
  -- CREATED : 2014-07-14 11:05:52
  -- PURPOSE : 从月、增补订单生成周排产，库存评审数量评审到周订单
  -- p_Result: 成功把回SUCCESS。
  -----------------------------------------------------------------------------
  Procedure p_Import_Order_Inv_Review(p_Sales_Center_Id    In Number, --中心ID
                                      p_Dest_Period_Id     In Number, --周排产订单周期ID
                                      p_Dest_Order_Type_Id In Number, --目标单据类型ID(目前是周排产订单）
                                      p_Dest_Order_Head_Id In Number, --目标单据头ID
                                      p_Entity_Id          In Number, --主体ID
                                      p_User_Code          In Varchar2, ----用户编码
                                      p_Result             In Out Varchar2 --返回结果：成功返回"SUCCESS"，失败返回原因
                                      ) Is
    v_Desc_Order_Line_Id   Number;
    v_Desc_Order_Type_Name Varchar2(240);
    v_Desc_Order_Number    Varchar2(240);
    v_Pln_Wip_Ord_Match    Varchar2(10);
    v_Err_Num              Number;
    v_Month_Period_Id      Number;
    v_sales_main_type_para varchar2(20);--大类参数
    v_sales_sub_type_para  varchar2(20);--小类参数
    v_account_para         varchar2(20);--账户参数
    v_customer_code        varchar2(100);--账户
    v_sales_main_type      varchar2(20);-- 营销大类
    v_sales_sub_type       varchar2(20);--营销小类
  Begin
    p_Result := v_Success;
    If p_Sales_Center_Id Is Null Or p_Dest_Period_Id Is Null Or
       p_Dest_Order_Type_Id Is Null Or p_Dest_Order_Head_Id Is Null Then
      p_Result := '检查参数，传入带NULL参数。p_Sales_Center_Id：' || p_Sales_Center_Id ||
                  ', p_Dest_Period_Id:' || p_Dest_Period_Id ||
                  ', p_Dest_Order_Type_Id:' || p_Dest_Order_Type_Id ||
                  ', p_Dest_Order_Head_Id:' || p_Dest_Order_Head_Id || v_Nl ||
                  Sqlerrm;
      Raise v_Base_Exception;
    End If;
    --获取工单与订单是否完全匹配参数
    Begin
      v_Pln_Wip_Ord_Match := Pkg_Bd.f_Get_Parameter_Value('PLN_WIP_ORD_MATCH',
                                                          p_Entity_Id);
    Exception
      When Others Then
        p_Result := '获取参数PLN_WIP_ORD_MATCH失败！' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;
    Begin
      Select Oh.Order_Type_Name, Oh.Order_Number
        Into v_Desc_Order_Type_Name, v_Desc_Order_Number
        From t_Pln_Order_Head Oh
       Where Oh.Order_Head_Id = p_Dest_Order_Head_Id;
    Exception
      When Others Then
        p_Result := '获取周排产订单头失败，周排产订单头ID:' || To_Char(p_Dest_Order_Head_Id) || v_Nl ||
                    Sqlerrm;
        Raise v_Base_Exception;
    End;
    Begin
      Select Opp.Period_Id
        Into v_Month_Period_Id
        From t_Pln_Order_Period Op, t_Pln_Order_Period Opp
       Where Op.Period_Id = p_Dest_Period_Id
         And Opp.Period_Id = Op.Parent_Period_Id
         And opp.period_type = '月';
    Exception
      When Others Then
        p_Result := '获取月周期ID失败，周订单周期ID:' || To_Char(p_Dest_Period_Id) || v_Nl ||
                    Sqlerrm;
        Raise v_Base_Exception;
    End;
    -- 取参数
    begin
      select th.customer_code,th.sales_main_type,th.customer_code
      into v_customer_code,v_sales_main_type ,v_customer_code
      from t_pln_order_head th
      where
      th.order_head_id=p_Dest_Order_Head_Id;
    end ;
    --取系统参数营销大类
     begin
      v_sales_main_type_para := pkg_bd.F_GET_PARAMETER_VALUE('ITEM_SALES_MAIN_TYPE_FILTER',
                                                   p_Entity_Id);
    exception
      when others then
        p_Result := '获取营销大类参数失败' || v_nl || sqlerrm;
        raise v_Base_Exception;
    end;
    --营销小类
    begin
      v_sales_sub_type_para := pkg_bd.F_GET_PARAMETER_VALUE('ITEM_SALES_SUB_TYPE_FILTER',
                                                  p_Entity_Id);
    exception
      when others then
        p_Result := '获取营销小类参数失败' || v_nl || sqlerrm;
        raise v_Base_Exception;
    end;
    -- 账户参数
     begin
      v_account_para := pkg_bd.F_GET_PARAMETER_VALUE('ACCOUNT_SYS',
                                                  p_Entity_Id);
    exception
      when others then
        p_Result := '获取账户参数失败,ACCOUNT_SYS' || v_nl || sqlerrm;
        raise v_Base_Exception;
    end;

    For r_Order_Inv In (Select Poh.Order_Head_Id,
                               Poh.Order_Number,
                               Pol.Order_Line_Id,
                               Poh.Order_Type_Name,
                               Pol.Item_Id,
                               Bi.Item_Code,
                               Bi.Item_Name,
                               Pol.Producing_Area_Id,
                               Oir.Inventory_Id,
                               Ii.Inventory_Code,
                               Ii.Inventory_Name,
                               Nvl(Oir.Affirm_Qty, 0) Affirm_Qty
                          From t_Pln_Order_Line       Pol,
                               t_Pln_Order_Head       Poh,
                               t_Pln_Order_Type       Pot,
                               t_Pln_Order_Inv_Review Oir,
                               t_Bd_Item              Bi,
                               t_Inv_Inventories      Ii
                         Where Pol.Order_Head_Id = Poh.Order_Head_Id
                           And Poh.Order_Type_Id = Pot.Order_Type_Id
                           And Pot.Dest_Order_Type_Id = p_Dest_Order_Type_Id
                           And Poh.Sales_Center_Id = p_Sales_Center_Id
                           And Poh.Period_Id = v_Month_Period_Id
                           and ('N'=v_sales_main_type_para or
                           ('Y'=v_sales_main_type_para and Poh.Sales_Main_Type=v_sales_main_type))
                           and ('N'=v_sales_sub_type_para or
                           ('Y'=v_sales_sub_type_para and Poh.Sales_Sub_Type=v_sales_sub_type))
                           and ('N'=v_account_para or
                           ('Y'=v_account_para and Poh.Customer_Code=v_customer_code))
                           And pot.send_by_type In (1, 2)
                           And Poh.Form_State = 23 --必须评审完毕
                           And Pol.Order_Line_Id = Oir.Order_Line_Id
                           And Bi.Item_Id = Pol.Item_Id
                           And Ii.Inventory_Id = Oir.Inventory_Id
                           And Nvl(Oir.Affirm_Qty, 0) > 0) Loop

      Begin
        Select Pol.Order_Line_Id
          Into v_Desc_Order_Line_Id
          From t_Pln_Order_Line Pol
         Where Pol.Order_Head_Id = p_Dest_Order_Head_Id
           And Pol.Item_Id = r_Order_Inv.Item_Id
           And Pol.Producing_Area_Id = r_Order_Inv.Producing_Area_Id;
      Exception
        When Others Then
          p_Result := '获取周排产订单行失败，周排产订单头ID:' || To_Char(p_Dest_Order_Head_Id) || v_Nl ||
                      Sqlerrm;
          Raise v_Base_Exception;
      End;

      Pkg_Pln_Inv_Occupy.p_Affirm_Unoccupy_Stocks(p_Inventory_Id      => r_Order_Inv.Inventory_Id,
                                                  p_Item_Id           => r_Order_Inv.Item_Id,
                                                  p_Occupy_Qty        => r_Order_Inv.Affirm_Qty,
                                                  p_Match_Pln_To_Wip  => v_Pln_Wip_Ord_Match,
                                                  p_Action_Desc       => r_Order_Inv.Order_Type_Name ||
                                                                         '生成周订单库存评审，释入库存占用',
                                                  p_Entity_Id         => p_Entity_Id,
                                                  p_Origin_Type       => r_Order_Inv.Order_Type_Name,
                                                  p_Origin_Head_Id    => r_Order_Inv.Order_Head_Id,
                                                  p_Origin_Number     => r_Order_Inv.Order_Number,
                                                  p_Origin_Line_Id    => r_Order_Inv.Order_Line_Id,
                                                  p_Source_Order_Type => r_Order_Inv.Order_Type_Name,
                                                  p_Source_Head_Id    => r_Order_Inv.Order_Head_Id,
                                                  p_Source_Number     => r_Order_Inv.Order_Number,
                                                  p_Source_Line_Id    => r_Order_Inv.Order_Line_Id,
                                                  p_User_Code         => p_User_Code,
                                                  p_Allow_No_Occupy   => 'N',
                                                  p_Result            => v_Err_Num,
                                                  p_Err_Msg           => p_Result);
      If p_Result <> v_Success Then
        Raise v_Base_Exception;
      End If;
      --更新月订单库存评审数量
      Update t_Pln_Order_Inv_Review Oir
         Set Oir.Affirm_Qty      = Nvl(Oir.Affirm_Qty, 0) -
                                   r_Order_Inv.Affirm_Qty,
             Oir.Affirm_Qty_Week = Nvl(Oir.Affirm_Qty_Week, 0) +
                                   r_Order_Inv.Affirm_Qty
       Where Oir.Order_Head_Id = r_Order_Inv.Order_Head_Id
         And Oir.Order_Line_Id = r_Order_Inv.Order_Line_Id
         And Oir.Item_Id = r_Order_Inv.Item_Id
         And Oir.Inventory_Id = r_Order_Inv.Inventory_Id;
      If Sql%Notfound Then
        p_Result := '更新月、增补订单的库存评审数据失败，订单头ID：' ||
                    To_Char(r_Order_Inv.Order_Head_Id) || '，订单行ID：' ||
                    To_Char(r_Order_Inv.Order_Line_Id) || '，产品ID：' ||
                    To_Char(r_Order_Inv.Item_Id) || '，仓库ID：' ||
                    To_Char(r_Order_Inv.Inventory_Id) || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
      End If;

      Update t_Pln_Order_Inv_Review Oir
         Set Oir.Affirm_Qty = Nvl(Oir.Affirm_Qty, 0) + r_Order_Inv.Affirm_Qty
       Where Oir.Order_Head_Id = p_Dest_Order_Head_Id
         And Oir.Order_Line_Id = v_Desc_Order_Line_Id
         And Oir.Item_Id = r_Order_Inv.Item_Id
         And Oir.Inventory_Id = r_Order_Inv.Inventory_Id;
      If Sql%Notfound Then
        Insert Into t_Pln_Order_Inv_Review
          (Entity_Id, --主体ID
           Order_Inv_Id,
           Order_Line_Id, --订单行ID
           Order_Head_Id, --订单头ID
           Head_Id, --汇总头ID
           Line_Id, --汇总行ID
           Inventory_Id, --仓库ID
           Inventory_Code, --仓库编码
           Inventory_Name, --仓库名称
           Item_Id, --产品ID
           Item_Code, --产品编码
           Item_Name, --产品描述
           Affirm_Type, --评审类型  单单，汇总
           Affirm_Qty, --评审数量
           Cancel_Qty, --取消数量
           Cancel_Flag, --取消标志
           Created_By, --创建人
           Creation_Date, --创建日期
           Last_Updated_By, --最后修改人
           Last_Update_Date, --最后修改日期
           Remark,
           Pre_Field_01,
           Pre_Field_02,
           Pre_Field_03,
           Pre_Field_04,
           Pre_Field_05,
           Pre_Field_06)
          Select p_Entity_Id, -- ENTITY_ID, --主体ID
                 s_Pln_Order_Inv_Review.Nextval,
                 v_Desc_Order_Line_Id, --ORDER_LINE_ID, --订单行ID
                 p_Dest_Order_Head_Id, --ORDER_HEAD_ID --订单头ID
                 -1, --COLL_HEAD_ID, --汇总头ID
                 -1, --COLL_LINE_ID, --汇总行ID
                 r_Order_Inv.Inventory_Id, -- INVENTORY_ID, --仓库ID
                 r_Order_Inv.Inventory_Code, --INVENTORY_CODE, --仓库编码
                 r_Order_Inv.Inventory_Name, --INVENTORY_NAME, --仓库名称
                 r_Order_Inv.Item_Id, --ITEM_ID, --产品ID
                 r_Order_Inv.Item_Code, --ITEM_CODE, --产品编码
                 r_Order_Inv.Item_Name, --ITEM_DESC, --产品描述
                 '单单', --AFFIRM_TYPE, --评审类型  单单，汇总
                 r_Order_Inv.Affirm_Qty, --AFFIRM_QTY, --评审数量
                 0                              Cancel_Qty, --取消数量
                 v_False, -- CANCEL_FLAG, --取消标志
                 p_User_Code, --CREATED_BY, --创建人
                 Sysdate, --CREATION_DATE, --创建日期
                 p_User_Code, --LAST_UPDATED_BY, --最后修改人
                 Sysdate, --LAST_UPDATE_DATE, --最后修改日期
                 Null                           Remark,
                 Null                           Pre_Field_01,
                 Null                           Pre_Field_02,
                 Null                           Pre_Field_03,
                 Null                           Pre_Field_04,
                 Null                           Pre_Field_05,
                 Null                           Pre_Field_06
            From Dual;
      End If;

      --周订单库存评审占用
      Pkg_Pln_Inv_Occupy.p_Affirm_Occupy_Stocks(p_Inventory_Id      => r_Order_Inv.Inventory_Id,
                                                p_Item_Id           => r_Order_Inv.Item_Id,
                                                p_Occupy_Qty        => r_Order_Inv.Affirm_Qty,
                                                p_Match_Pln_To_Wip  => v_Pln_Wip_Ord_Match,
                                                p_Action_Desc       => v_Desc_Order_Type_Name ||
                                                                       '，生成周订单库存评审，释入库存占用',
                                                p_Entity_Id         => p_Entity_Id,
                                                p_Origin_Type       => v_Desc_Order_Type_Name,
                                                p_Origin_Head_Id    => p_Dest_Order_Head_Id,
                                                p_Origin_Number     => v_Desc_Order_Number,
                                                p_Origin_Line_Id    => v_Desc_Order_Line_Id,
                                                p_Source_Order_Type => r_Order_Inv.Order_Type_Name,
                                                p_Source_Head_Id    => r_Order_Inv.Order_Head_Id,
                                                p_Source_Number     => r_Order_Inv.Order_Number,
                                                p_Source_Line_Id    => r_Order_Inv.Order_Line_Id,
                                                p_User_Code         => p_User_Code,
                                                p_Result            => v_Err_Num,
                                                p_Err_Msg           => p_Result);
      If p_Result <> v_Success Then
        Raise v_Base_Exception;
      End If;
    End Loop;

    --更新订单行库存评审数量
    Update t_Pln_Order_Line Pol
       Set Pol.Inv_Affirm_Qty = Nvl((Select Sum(Oir.Affirm_Qty)
                                      From t_Pln_Order_Inv_Review Oir
                                     Where Oir.Order_Head_Id = Pol.Order_Head_Id
                                       And Oir.Order_Line_Id = Pol.Order_Line_Id),
                                    0)
     Where Pol.Order_Head_Id = p_Dest_Order_Head_Id;

    /*Update t_Pln_Order_Line Pol
       Set Pol.Apply_Qty = Nvl(Pol.Check_Qty, 0) +
                           Nvl(Pol.Inv_Affirm_Qty, 0)
     Where Pol.Order_Head_Id = p_Dest_Order_Head_Id;*/
  Exception
    When v_Base_Exception Then
      Rollback;
      p_Result := '引入月、增补订单库存评审数据致周排产订单失败。' || v_Nl || p_Result;
    When Others Then
      Rollback;
      p_Result := '引入月、增补订单库存评审数据致周排产订单失败。' || v_Nl || p_Result || v_Nl ||
                  Sqlerrm;
  End;

  -----------------------------------------------------------------------------
  -- AUTHOR  : 张楚材
  -- CREATED : 2014-11-12 11:05:52
  -- PURPOSE : 根据月(M+1)、月(M+2)、月增补批量生成所有销售公司周排产第4周订单
  -- p_Result: 成功把回SUCCESS。
  -----------------------------------------------------------------------------
  Procedure p_Create_Order_Last_Week_All(p_Order_Type_Id In Number, --订单类型Id
                                         p_Period_Id     In Number, --周期Id
                                         p_main_type_sys in varchar2,--订单大类参数
                                         p_sub_type_sys  in varchar2,-- 订单小类参数
                                         p_main_type     in varchar2,--订单大类
                                         p_sub_type      in varchar2,-- 订单小类
                                         p_Entity_Id     In Number, --主体Id
                                         p_User_Name     In Varchar2, --用户
                                         p_Result        In Out Varchar2) Is
    v_Order_Head_Number Varchar2(50);
    v_Make_Rule         Varchar2(50);
    v_Batch_Id          Number;
    v_Producing_Id      Number;
    v_Month_Period_Id   Number;
    v_Month_Period_Code Varchar2(100);
    Cursor c_Sales_Center(p_Month_Period_Id Number) Is
      Select Bsc.Sales_Center_Id,
             Bsc.Sales_Center_Code,
             Bsc.Sales_Center_Name
        From v_Bd_Sales_Center Bsc
       Where Exists (Select 1
                From t_Pln_Order_Head Poh, t_Pln_Order_Type Pot
               Where Poh.Period_Id = p_Month_Period_Id
                 And Poh.Entity_Id = Bsc.Entity_Id
                 And Poh.Sales_Center_Id = Bsc.Sales_Center_Id
                 And Poh.Order_Type_Id = Pot.Order_Type_Id
                 And Poh.Form_State In (23) --已排产、已评完毕
                 And Pot.Dest_Order_Type_Id = p_Order_Type_Id
                 AND ('N'=p_main_type_sys or ('Y'=p_main_type_sys and poh.sales_main_type=p_main_type))--增加大类
                 And ('N'=p_sub_type_sys or ('Y'=p_sub_type_sys and poh.sales_sub_type=p_sub_type))--增加小类
                 )
         And Bsc.Entity_Id = p_Entity_Id;

    r_Sales_Center c_Sales_Center%Rowtype;
    v_Value      Varchar2(4000);
  Begin
    Begin
      Select Opp.Period_Id, Opp.Period_Code
        Into v_Month_Period_Id, v_Month_Period_Code
        From t_Pln_Order_Period Op, t_Pln_Order_Period Opp
       Where Op.Period_Id = p_Period_Id
         And Opp.Period_Id = Op.Parent_Period_Id
         And Opp.Period_Type = '月';
    Exception
      When Others Then
        p_Result := '获取月周期ID失败，周订单周期ID:' || To_Char(p_Period_Id) || v_Nl ||
                    Sqlerrm;
        Raise v_Base_Exception;
    End;

    --add by lizhen 2015-01-01
    --增加检查月订单是否存在未评审完毕的单据，有则报异常
    For r_Order In (Select Poh.Order_Number,
                           Poh.Form_State,
                           Fts.Status_Code,
                           Bsc.Sales_Center_Code,
                           Bsc.Sales_Center_Name
                      From t_Pln_Order_Head       Poh,
                           t_Pln_Order_Type       Pot,
                           v_Bd_Sales_Center      Bsc,
                           t_Pln_Flow_Type_Status Fts
                     Where Poh.Period_Id = v_Month_Period_Id
                       And Poh.Entity_Id = Bsc.Entity_Id
                       And Poh.Sales_Center_Id = Bsc.Sales_Center_Id
                       And Poh.Order_Type_Id = Pot.Order_Type_Id
                          --已排产、评审完毕、已作废、已关闭、已取消
                       And Poh.Form_State Not In (23, 248, 304, 305)
                       AND ('N'=p_main_type_sys or ('Y'=p_main_type_sys and poh.sales_main_type=p_main_type))--增加大类
                       And ('N'=p_sub_type_sys or ('Y'=p_sub_type_sys and poh.sales_sub_type=p_sub_type))--增加小类
                       And Pot.Dest_Order_Type_Id = p_Order_Type_Id
                       And To_Char(Fts.Status_Id) = Poh.Form_State
                       And Bsc.Entity_Id = p_Entity_Id) Loop
      If v_Value Is Null Then
        v_Value := '中心名称：' || r_Order.Sales_Center_Name || '    订单单号：' ||
                   r_Order.Order_Number || '     订单状态：' ||
                   r_Order.Status_Code;
      Else
        v_Value := v_Value || v_Nl || '中心名称：' ||
                   r_Order.Sales_Center_Name || '    订单单号：' ||
                   r_Order.Order_Number || '     订单状态：' ||
                   r_Order.Status_Code;
      End If;
    End Loop;
    If v_Value Is Not Null Then
      p_Result := v_Month_Period_Code || '周期月订单存在以下订单单据未评审毕：' || v_Nl ||
                  v_Value;
      Raise v_Base_Exception;
    End If;

    -- 打开周期
    Update t_Pln_Order_Period Op
       Set Op.Open_Date = Trunc(Sysdate)
     Where Op.Period_Id = p_Period_Id
       And Op.Open_Date Is Null;

    Open c_Sales_Center(v_Month_Period_Id);
    Loop
      Fetch c_Sales_Center
        Into r_Sales_Center;
      If c_Sales_Center%Rowcount = 0 Then
        p_Result := '获取营销中心失败，可能当月未报送月订单。' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
      End If;
      Exit When c_Sales_Center%Notfound;
      -- 寻找最优产地
      v_Producing_Id := Pkg_Pln_Pub.f_Get_Cen_Prod_Area_Priority(r_Sales_Center.Sales_Center_Id,
                                                                 0,
                                                                 p_Entity_Id,
                                                                 p_User_Name);
      If v_Producing_Id = 0 Then
        p_Result := '获取最优产地失败，营销中心编码：' || r_Sales_Center.Sales_Center_Code ||
                 v_Nl || Sqlerrm;
        Raise v_Base_Exception;
      End If;
      --生成当月最后一周订单
      p_Order_Last_Week_Single(v_Producing_Id, --产地Id
                               r_Sales_Center.Sales_Center_Id, --营销中心Id
                               p_Order_Type_Id, --订单类型Id
                               p_Period_Id, --周期Id
                               p_main_type_sys,
                               p_sub_type_sys,
                               p_main_type,
                               p_sub_type,
                               p_Entity_Id, --主体Id
                               p_User_Name, --用户
                               p_Result);
      If p_Result <> v_Success Then
        p_Result := p_Result|| v_nl || r_Sales_Center.Sales_Center_Name || ' 生成当月最后一周周排产订单失败。' || v_Nl ||
                    Sqlerrm;
        Raise v_Base_Exception;
      End If;
    End Loop;
    Close c_Sales_Center;
  Exception
    When v_Base_Exception Then
      Rollback;
      p_Result := p_Result;
    When Others Then
      Rollback;
      p_Result := p_Result;
  End;

  -----------------------------------------------------------------------------
  -- AUTHOR  : 李振
  -- CREATED : 2015-02-10 11:05:52
  -- PURPOSE : 检查产品在产地是否生产，是返回：SUCCESS  否：返回异常信息
  -----------------------------------------------------------------------------
  Procedure p_Check_Item_ProducingArea(p_Order_Head_Id      In Number, ----订单ID、汇总单头ID
                                       p_Order_Collect_Type In Number, --汇总订单标识：1：汇总  2：单单
                                       p_User_Code          In Varchar2, ----用户ID
                                       p_Result             In Out Varchar2 --返回结果：成功返回"SUCCESS"，失败返回原因
                                       ) Is
    Cursor c_Get_Order_Head Is
      Select Oh.Entity_Id, Oh.Order_Head_Id, Oh.Order_Number
        From t_Pln_Order_Head Oh
       Where Oh.Order_Head_Id = p_Order_Head_Id
         And p_Order_Collect_Type = 2
      Union All
      Select Poh.Entity_Id, Poh.Order_Head_Id, Poh.Order_Number
        From t_Pln_Order_Collect_Head     Och,
             t_Pln_Order_Collect_Line     Ocl,
             t_Pln_Order_Collect_Relation Ocr,
             t_Pln_Order_Line             Pol,
             t_Pln_Order_Head             Poh
       Where Och.Coll_Ord_Head_Id = Ocl.Coll_Ord_Head_Id
         And Ocl.Coll_Ord_Line_Id = Ocr.Coll_Ord_Line_Id
         And Pol.Order_Line_Id = Ocr.Order_Line_Id
         And Poh.Order_Head_Id = Pol.Order_Head_Id
         And Och.Coll_Ord_Head_Id = p_Order_Head_Id
         And p_Order_Collect_Type = 1;
    r_Order_Head c_Get_Order_Head%Rowtype;

    Cursor c_Get_Order_Line Is
      Select *
        From t_Pln_Order_Line Ol
       Where Ol.Order_Head_Id = p_Order_Head_Id;
    r_Order_Line c_Get_Order_Line%Rowtype;
    v_Message             Varchar2(2000);
    v_Producing_Area_Name varchar2(240);
    v_Count               Number;
  Begin
    p_Result := v_Success;
    v_Message := Null;
    Begin
      Open c_Get_Order_Head;
    Exception
      When Others Then
        p_Result := '打开计划订单头游标失败。' || v_Nl || '订单头ID：' ||
                    To_Char(p_Order_Head_Id) || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;
    Fetch c_Get_Order_Head Into r_Order_Head;
    If c_Get_Order_Head%Notfound Then
      Begin
        Open c_Get_Order_Line;
      Exception
        When Others Then
          p_Result := '打开计划订单行游标失败.' || v_Nl || '订单头ID：' ||
                    To_Char(p_Order_Head_Id) || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
      End;
      Loop
        Fetch c_Get_Order_Line Into r_Order_Line;
        Exit When c_Get_Order_Line%Notfound ;
        Begin
          Select Pa.Producing_Area_Name
            Into v_Producing_Area_Name
            From t_Pln_Producing_Area Pa
           Where pa.Entity_Id = r_Order_Line.Entity_Id
             And pa.producing_area_id = r_Order_Line.Producing_Area_Id;
        Exception
          When Others Then
            p_Result := '获取产地信息失败！' || v_Nl || '产地ID：' ||
                        To_Char(r_Order_Line.Producing_Area_Id);
            Raise v_Base_Exception;
        End;
        --统计是否存在产品产地
        Select Count(Ipa.Item_Id)
          Into v_Count
          From t_Pln_Item_Producing_Area Ipa
         Where Ipa.Producing_Area_Id = r_Order_Line.Producing_Area_Id
           And Ipa.Item_Id = r_Order_Line.Item_Id
           And Ipa.Entity_Id = r_Order_Line.Entity_Id
           And Ipa.State Is Not Null
           And Exists (Select 1
                  From Up_Codelist Uc, Up_Codelist_Entity Uce
                 Where Uc.Id = Uce.Codelist_Id
                   And Ipa.State = Uc.Code_Value
                   And Uc.Codetype = 'PLN_ITEM_PRODUCING_AREA_STATE'
                   And Uce.Entity_Id = r_Order_Head.Entity_Id
                   And Nvl(Uc.Code_Name, 'N') = 'Y'
                   And Uc.Entity_Flag = '0');
        If v_Count = 0 Then
          If v_Message Is Null Then
            v_Message := '订单单号【'|| r_Order_Head.Order_Number ||'】产品编码【' || r_Order_Line.Item_Code || '】在产地【' ||
              v_Producing_Area_Name ||'】不生产;';
          Else
            v_Message := v_Message || v_Nl || '订单单号【'|| r_Order_Head.Order_Number ||'】产品编码【' || r_Order_Line.Item_Code || '】在产地【' ||
              v_Producing_Area_Name ||'】不生产;';
          End If;
        End If;
      End Loop;
      Close c_Get_Order_Line;
      If v_Message Is Not Null Then
        p_Result := '检查产品产地失败，以下产品在对应产地不生产：' || v_Nl || v_Message;
        Raise v_Base_Exception;
      End If;
    End If;
    Close c_Get_Order_Head;
    If p_Result <> v_Success Then
      Raise v_Base_Exception;
    End If;
  Exception
    When v_Base_Exception Then
      Rollback;
      p_Result := p_Result;
    When Others Then
      Rollback;
      p_Result := '检查订单行产品在产地对应的ERP组织是否生产。' || v_Nl || Sqlerrm;
  End;

  -----------------------------------------------------------------------------
  -- AUTHOR  : 唐家智
  -- CREATED : 2015-07-10 10:06:52
  -- PURPOSE : 取消计划订单和提货订单关联关系，成功返回：SUCCESS  失败：返回异常信息
  -----------------------------------------------------------------------------
  Procedure p_Cancel_LgPlnRela(p_Relation_Id_List   In Varchar2, --计划订单行、提货订单行 关系表主键id列表
                               p_User_Code  In Varchar2, --用户编码
                               p_Entity_Id  In Number, --主体Id
                               p_Result     In Out Varchar2 --返回结果：成功返回"SUCCESS"，失败返回原因
                               ) Is
  TYPE C_PLR_CURSOR_TYPE IS REF CURSOR; --声明动态游标
  V_PLR_CURSOR C_PLR_CURSOR_TYPE;
  TYPE TYPE_RELATION IS RECORD( --定义提货订单行 计划订单行关系
    RELATION_ID  T_PLN_LG_RELATION.RELATION_ID%type,
    ORDER_LINE_ID  T_PLN_LG_RELATION.ORDER_LINE_ID%type,
    LG_ORDER_LINE_ID  T_PLN_LG_RELATION.LG_ORDER_LINE_ID%type
    );
  V_PLR  TYPE_RELATION;

  v_Pln_Order_Line_Id Number;--计划订单行id
  v_Pln_Lg_Line_Id Number;--提货订单行id
  v_Coll_Ord_Head_Id Number;--汇总订单头id
  v_Coll_Ord_Line_Id Number;--汇总订单行id
  v_Lgtopln_Qty Number := 0;--提货转计划的数量
  v_Check_Qty Number := 0;--当前排产数量
  v_Check_Qty_Minus Number := 0;--要减去的排产数量
  v_Inv_Affirm_Qty_Minus Number := 0;--要减去的库存评审数量
  v_Item_Id Number;--产品id
  v_sql VARCHAR2(1000);
  v_Err_Msg VARCHAR2(200);
  v_PRODUCING_AREA_ID NUMBER; --产地ID
  v_pro_sort NUMBER; --产地排序

  Begin
    p_Result := v_Success;
    --获取关联的 计划订单行id、提货订单行id
    v_sql := 'select RELATION_ID,ORDER_LINE_ID,LG_ORDER_LINE_ID from T_PLN_LG_RELATION where RELATION_ID in (' ||  p_Relation_Id_List || ')';
    BEGIN
      OPEN V_PLR_CURSOR FOR v_sql;
    END;
    LOOP
      FETCH V_PLR_CURSOR INTO V_PLR;
      EXIT WHEN V_PLR_CURSOR%NOTFOUND;

      --删除关联表（T_PLN_LG_RELATION）提货订单行和计划订单行关系
      delete from T_PLN_LG_RELATION where RELATION_ID = V_PLR.RELATION_ID;

      v_Pln_Order_Line_Id := V_PLR.ORDER_LINE_ID;
      v_Pln_Lg_Line_Id := V_PLR.LG_ORDER_LINE_ID;

      --查询提货订单行的 转计划的数量（中心评审 - 已评审）
      select t.item_id, nvl(t.CENTER_AFFIRM_QUANTITY,0) - nvl(t.AFFIRMED_QUANTITY,0)
                                              into v_Item_Id, v_Lgtopln_Qty
                                              from T_PLN_LG_ORDER_LINE t
                                              where t.ORDER_LINE_ID = v_Pln_Lg_Line_Id;

      --查询计划订单当前的 排产数量CHECK_QTY或者CAN_PRODUCE_QTY
      select nvl(CHECK_QTY,0),PRODUCING_AREA_ID into v_Check_Qty,v_PRODUCING_AREA_ID from T_PLN_ORDER_LINE where ORDER_LINE_ID = v_Pln_Order_Line_Id;
      if v_Check_Qty<v_Lgtopln_Qty then
        v_Check_Qty_Minus := v_Check_Qty;
        v_Inv_Affirm_Qty_Minus := v_Lgtopln_Qty - v_Check_Qty;
      else
        v_Check_Qty_Minus := v_Lgtopln_Qty;
        v_Inv_Affirm_Qty_Minus := 0;
      end if;

      --减少计划订单行的 申请数量、评审数量和可生产数量
      update T_PLN_ORDER_LINE set APPLY_QTY = NVL(APPLY_QTY,0) - NVL(v_Lgtopln_Qty,0),
                                  center_check_qty = NVL(center_check_qty,0) - NVL(v_Lgtopln_Qty,0),
                                  CHECK_QTY = NVL(CHECK_QTY,0) - NVL(v_Check_Qty_Minus,0),
                                  CAN_PRODUCE_QTY = NVL(CAN_PRODUCE_QTY,0) -  NVL(v_Check_Qty_Minus,0),
                                  LAST_UPDATED_BY = p_User_Code,
                                  LAST_UPDATE_DATE = sysdate
                                  where ORDER_LINE_ID = v_Pln_Order_Line_Id;

      --获取关联的 汇总订单行id
      select t.COLL_ORD_LINE_ID into v_Coll_Ord_Line_Id from T_PLN_ORDER_COLLECT_RELATION t
                                       where t.ORDER_LINE_ID = v_Pln_Order_Line_Id;
      --获取关联的 汇总订单头id
      select t.coll_ord_head_id into v_Coll_Ord_Head_Id from T_PLN_ORDER_COLLECT_LINE t
                                       where t.coll_ord_line_id = v_Coll_Ord_Line_Id;

      --减少汇总订单行 总申请数量， 包括排产库存
      update T_PLN_ORDER_COLLECT_LINE set TOTAL_APPLY_QTY = NVL(TOTAL_APPLY_QTY,0) - NVL(v_Lgtopln_Qty,0),
                                          LAST_UPDATED_BY = p_User_Code,
                                          LAST_UPDATE_DATE = sysdate
                                          where COLL_ORD_LINE_ID = v_Coll_Ord_Line_Id;

      --减少汇总订单明细对应产地的 申请数量、评审数量,只包括排产
      update T_PLN_ORDER_COLLECT_DETAIL set QUANTITY = NVL(QUANTITY,0) - NVL(v_Lgtopln_Qty,0),
                                            CHECK_QTY = NVL(CHECK_QTY,0) - NVL(v_Lgtopln_Qty,0),
                                            LAST_UPDATED_BY = p_User_Code,
                                            LAST_UPDATE_DATE = sysdate
                                            where COLL_ORD_LINE_ID = v_Coll_Ord_Line_Id
                                              AND PRODUCING_AREA_ID = v_PRODUCING_AREA_ID;

      --更新汇总订单显示表的申请数量
      select tp.pro_sort
        into v_pro_sort
        from t_pln_producing_area tp
       where tp.entity_id = p_Entity_Id
         and tp.producing_area_id = v_PRODUCING_AREA_ID;

      v_sql := 'UPDATE T_PLN_ORDER_COLLECT_SHOW S SET S.APPLY_QTY=S.APPLY_QTY - ' || NVL(v_Lgtopln_Qty,0) ||
               ',S.QTY'||TO_CHAR(v_pro_sort*2-1)||'=S.QTY'||TO_CHAR(v_pro_sort*2-1)||'-'|| NVL(v_Lgtopln_Qty,0) ||
               ' WHERE S.ORDER_COLLECT_LINE_ID='||TO_CHAR(v_Coll_Ord_Line_Id);

      EXECUTE IMMEDIATE v_sql;

      if v_Inv_Affirm_Qty_Minus>0 then
        declare
        cursor v_review_cursor is select AFFIRM_QTY,ORDER_INV_ID from T_PLN_ORDER_INV_REVIEW t where t.order_line_id = v_Pln_Order_Line_Id;
        v_review   v_review_cursor%rowtype;
        begin
          for v_review in v_review_cursor loop
            exit when v_Inv_Affirm_Qty_Minus=0;
            if v_review.AFFIRM_QTY<v_Inv_Affirm_Qty_Minus then
              v_Inv_Affirm_Qty_Minus := v_Inv_Affirm_Qty_Minus - v_review.AFFIRM_QTY;
              update T_PLN_ORDER_INV_REVIEW set AFFIRMING_QTY = 0 where ORDER_INV_ID = v_review.ORDER_INV_ID;
            else
              update T_PLN_ORDER_INV_REVIEW set AFFIRMING_QTY = AFFIRM_QTY - v_Inv_Affirm_Qty_Minus where ORDER_INV_ID = v_review.ORDER_INV_ID;
              v_Inv_Affirm_Qty_Minus := 0;
            end if;
          end loop;
        end;
        PKG_PLN_ORDER_INV_REVIEW.p_Inv_Review_Lock(v_Coll_Ord_Head_Id, v_Coll_Ord_Line_Id, 1, p_Entity_Id, p_User_Code, p_Result, v_Err_Msg);
        p_Result := v_Err_Msg;
      end if;

      --减少汇总订单显示的 总申请数量、总评审数量、对应产地评审数量（调用重新生成汇总显示的过程）
      Pkg_Pln_Order_Collect.p_up_total_collect_show(v_Coll_Ord_Head_Id, v_Coll_Ord_Head_Id,
                                                    v_Item_Id, p_Entity_Id, p_User_Code, p_Result);

      --更新提货订单行汇总和转计划标志
      UPDATE T_PLN_LG_ORDER_LINE L
         SET L.MAKE_ORDER_LINE_FLAG = 'N', L.COLLECT_ORDER_LINE_FLAG = 'N',
             L.LAST_UPDATED_BY = p_User_Code, L.LAST_UPDATE_DATE = SYSDATE
       WHERE L.ORDER_LINE_ID = v_Pln_Lg_Line_Id;

      --更新提货订单头最后更新信息
      UPDATE T_PLN_LG_ORDER_HEAD H
         SET H.LAST_UPDATED_BY = p_User_Code,
             H.LAST_UPDATE_DATE = SYSDATE,
             H.VERSION = NVL(H.VERSION, 0) + 1
       WHERE H.ORDER_HEAD_ID = (SELECT L.ORDER_HEAD_ID FROM T_PLN_LG_ORDER_LINE L
                                 WHERE L.ORDER_LINE_ID = v_Pln_Lg_Line_Id);

       --add by zhangcc 2015-11-3
       delete CIMS.INTF_PLN_LG_COLLECT_LINE L
       WHERE L.ORDER_LINE_ID=v_Pln_Lg_Line_Id;

       delete CIMS.t_Pln_Lg_Collect_Line l
       WHERE L.ORDER_LINE_ID=v_Pln_Lg_Line_Id;
    END LOOP;
    close V_PLR_CURSOR;
  End;

  -----------------------------------------------------------------------------
  -- AUTHOR  : xuhongjiu
  -- CREATED : 2015-12-3
  -- PURPOSE : 订单调整审核操作
  -----------------------------------------------------------------------------
    Procedure p_Adjust_Order_Review(p_Order_Head_Id    In Number, ----订单头ID
                                   p_User_Code        In Varchar2, ----用户编码
                                   p_Result           Out Varchar2 ----返回结果：成功返回"SUCCESS"，失败返回原因
                                   )Is
      r_Order_Head    T_Pln_Order_Head%Rowtype;
      r_order_type    t_Pln_Order_Type%Rowtype;
      v_Count   Number;
      Begin
          p_Result := v_Success;
         Begin
            Select oh.*
              Into r_Order_Head
              From cims.t_Pln_Order_Head oh
             Where oh.order_head_id = p_Order_Head_Id;
         Exception
           When Others Then
           p_Result := '查询对应订单失败。';
           Raise v_Base_Exception;
         End;

         Begin
           Select ot.*
             Into r_order_type
             From cims.t_pln_order_type ot,
                  cims.t_Pln_Order_Head oh
            Where ot.order_type_id = oh.order_type_id
              And ot.entity_id = oh.entity_id
              And oh.Order_Head_Id = p_Order_Head_Id;
         Exception
           When Others Then
             p_Result := '查询订单类型失败。';
             Raise v_Base_Exception;
         End ;
         --从提货订单过来的不用锁款了
         If nvl(r_Order_Head.Sys_Source,'_') <> 'CIMS' And nvl(r_Order_Head.Source_Type,'_') <> '提货订单' Then
         --送审锁款时有调整数量要把多锁的款项释放
         If nvl(r_order_type.chk_cusg_amount_flag,'_') = pkg_pln_pub.V_LOCK_AMOUNT_FLAG_S Then
            For r_check_amount In (Select
                  --20170517 hejy3 按行营销大类
                  --bi.sales_main_type,
                  nvl(ol.sales_main_type, bi.sales_main_type) sales_main_type,
                  sum(round(nvl(ol.item_price,0) * nvl(al.adjust_qty,0) *
                  (100 - nvl(ol.discount_rate,0) - nvl(ol.ordered_discount_rate,0))/100,2)) apply_amount,
                  Sum(round(nvl(ol.item_price,0) * nvl(al.adjust_qty,0) *
                  nvl(ol.discount_rate,0)/100,2)) discount_amount
             From cims.t_pln_order_adjust_line al,
                  cims.t_Pln_Order_Line ol,
                  cims.t_bd_item bi
            Where al.Order_Line_Id = ol.Order_Line_Id
              And al.Order_Head_Id = ol.Order_Head_Id
              And ol.item_code = bi.item_code
              And ol.entity_id = bi.entity_id
              And ol.Order_Head_Id = p_Order_Head_Id
              --20170517 hejy3 按行营销大类
            Group By nvl(ol.sales_main_type, bi.sales_main_type)--bi.sales_main_type
            ) Loop

            If nvl(r_check_amount.apply_amount,0) > 0 Then
               /*Pkg_Credit_Account_Control.Prc_Credit_Order_Bill(p_Entity_Id       => r_Order_Head.Entity_Id,
                                                               p_Action_Type     => 2, --释放到款
                                                               p_Settlement_Sum  => Nvl(r_check_amount.Apply_Amount,
                                                                                        0),
                                                               p_Discount_Sum    => Nvl(r_check_amount.Discount_Amount,
                                                                                        0),
                                                               p_Sales_Main_Type => r_Check_Amount.Sales_Main_Type,
                                                               p_Account_Id      => r_Order_Head.Account_Id,
                                                               p_Customer_Id     => r_Order_Head.Customer_Id,
                                                               p_Proj_Number     => Null,
                                                               p_Order_Id        => r_Order_Head.Order_Head_Id,
                                                               --p_Order_Type      => r_Order_Head.Order_Type_Name,
                                                               P_ORDER_TYPE => r_Order_Head.Order_Type_Code, --20160912 hejy3 传入订单类型编码
                                                               p_Username        => p_User_Code,
                                                               p_Result          => v_Count,
                                                               p_Err_Msg         => p_Result);
                If p_Result <> v_Success Then
                  p_Result := '检查资金失败，产品大类：' ||
                              r_Check_Amount.Sales_Main_Type || v_Nl ||
                              p_Result;
                  Raise v_Base_Exception;
                End If;*/
              pkg_pln_pub.P_CUSTOMER_AMOUNT_PROCESS(IN_ENTITY_ID       => r_Order_Head.Entity_Id,
                                                    IN_ORDER_TYPE_ID   => r_Order_Head.Order_Type_id,
                                                    IN_ORDER_TYPE_CODE => r_Order_Head.Order_Type_Code,
                                                    IN_CUSTOMER_ID     => r_Order_Head.Customer_Id,
                                                    IN_ACCOUNT_ID      => r_Order_Head.Account_Id,
                                                    IN_SALES_MAIN_TYPE => r_Check_Amount.Sales_Main_Type,
                                                    IN_ACTION_TYPE     => 2,
                                                    IN_SOURCE_TYPE     => '01',
                                                    IN_ORDER_ID        => r_Order_Head.Order_Head_Id,
                                                    IN_PROJ_NUMBER     => null,
                                                    IN_DISCOUNT_TYPE   => pkg_pln_pub.v_Discount_Type_Common,
                                                    IN_AMOUNT          => Nvl(r_check_amount.Apply_Amount, 0),
                                                    IN_DIS_AMOUNT      => Nvl(r_check_amount.Discount_Amount, 0),
                                                    IN_RECORD_ERR      => 'N',
                                                    IN_USER_CODE       => p_User_Code,
                                                    OUT_RESULT         => p_Result);
              if p_Result <> v_Success then
                p_Result := '调整取消订单处理客户款项失败(锁款方式:'||r_order_type.chk_cusg_amount_flag||')！' || v_Nl || p_Result;
                raise v_Base_Exception;
              end if;
            End If;
            End Loop;
            End If;
          End If;
      Exception
        When v_Base_Exception Then
        p_Result := p_Result;
        Rollback;
        When Others Then
        p_Result := p_Result || v_Nl || Sqlerrm;
        Rollback;
      End ;
  -----------------------------------------------------------------------------
  -- AUTHOR  : lilh6
  -- CREATED : 2018-7-4
  -- PURPOSE : 解锁提货订单对应的T+3订单
  -----------------------------------------------------------------------------
  Procedure P_CANCEL_T3_ORDER(p_Order_Head_Id IN NUMBER, --提货订单头id
                              P_USER_CODE     IN VARCHAR2, --产品
                              p_Result        In Out Varchar2 --返回结果：成功返回SUCCESS，失败返回原因
                              ) IS
    r_Lg_Order_head        t_pln_lg_order_head%Rowtype;
    v_Count                Number;
    v_Lg_Close_Qty         Number;
    v_Sum_Close_Qty        Number;
    v_can_cancel_qty       Number;
    v_remain_cancel_qty       Number;
    v_cancel_qty       Number;
    v_deal_qty  number;
    v_remain_close_qty     NUMBER;
    v_Item_Code_List       Varchar2(4000);
    v_Match_Qty            Number;
    v_Relation_Type        Varchar2(32);
    v_Message              Varchar2(4000);
    v_lg_ship_count number;
  BEGIN
    p_Result := v_Success;
    Select Count(*)
      Into v_Count
      From t_Pln_Lg_Order_Line Ol,
           t_Pln_Lg_Relation   Lr,
           t_Pln_Order_Line    Pol
     Where Ol.Order_Line_Id = Lr.Lg_Order_Line_Id
       And Pol.Order_Line_Id = Lr.Order_Line_Id
       And Ol.Order_Head_Id = p_Order_Head_Id;
    If Nvl(v_Count, 0) = 0 Then
      --无计划订单关联则不需往下处理，直接返回。
      Return;
    End If;
    Begin
      Select *
        Into r_Lg_Order_Head
        From t_Pln_Lg_Order_Head Oh
       Where Oh.Order_Head_Id = p_Order_Head_Id
         For Update Nowait;
    Exception
      When Others Then
        p_Result := '查询提货订单头失败！' || v_Nl || '提货订单头ID：' ||
                    To_Char(p_Order_Head_Id) || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;
    For r_Lg_Order_Line In (Select Ol.*
                              From t_Pln_Lg_Order_Line Ol
                             Where Ol.Order_Head_Id = p_Order_Head_Id
                               and nvl(ol.canceling_qty, 0) > 0 --待取消数量大于0
                               And Exists
                             (Select 1
                                      From t_Pln_Lg_Relation t
                                     Where t.Lg_Order_Head_Id = p_Order_Head_Id
                                       And t.Lg_Order_Line_Id = Ol.Order_Line_Id)) Loop
      v_cancel_qty := r_Lg_Order_Line.canceling_qty;
      --取消T+3订单数量时，检查行上的可取消数量=结转T+3的数量-T+3已评审量-已取消释放库存数量-已确认预约直发量+已直发量）
      v_can_cancel_qty := Nvl(r_Lg_Order_Line.To_Pln_Qty, 0) - Nvl(r_Lg_Order_Line.Pln_Affirmed_Qty,0) - nvl(r_Lg_Order_Line.pln_cancel_qty,0)-
                         (nvl(r_lg_order_line.DIRECT_TRANSPORT_QTY,0) - nvl(r_lg_order_line.ALREADY_DIRECT_TRANSPORT_QTY,0));
      if v_cancel_qty > v_can_cancel_qty then
        p_Result := '待取消数量('|| v_cancel_qty || ')大于当前行可取消数量('||v_can_cancel_qty || ')！'|| v_Nl || '产品编码：'|| r_Lg_Order_Line.item_code || '订单行id：' || r_Lg_Order_Line.order_line_id;
        raise v_Base_Exception;
      end if;
      --循环计划订单行，为将来订单订单行拆分多计划订单行做预留
      --add by lizhen 2016-02-01 已全部发完货的T+3提货行不需要进行发货计划取消
      If v_cancel_qty <= v_can_cancel_qty Then
        v_remain_cancel_qty := v_cancel_qty;
        For r_Order_Line In (Select Plr.Relation_Type, --add by lizhen 2017-02-27
                                    Nvl(Plr.Match_Qty, 0) -
                                    Nvl(Plr.Ship_Qty, 0) Cancel_Match_Qty,
                                    Plr.Relation_Id,
                                    Pol.*
                               From t_Pln_Order_Line  Pol,
                                    t_Pln_Order_Head  Poh,
                                    t_Pln_Lg_Relation Plr
                              Where Pol.Order_Head_Id = Poh.Order_Head_Id
                                And Plr.Order_Line_Id = Pol.Order_Line_Id
                                   --add by lizhen 2017-02-27 取消订单时，只查询匹配数量大于0的数据
                                And (Plr.Relation_Type = 'T3_ORDER_TYPE' Or
                                    (Plr.Relation_Type = 'PLN_ORDER_TYPE' And
                                    Plr.Match_Qty > 0))
                                And Plr.Lg_Order_Line_Id =
                                    r_Lg_Order_Line.Order_Line_Id) Loop
          v_Relation_Type := r_Order_Line.Relation_Type;
          If r_Order_Line.Relation_Type != 'PLN_ORDER_TYPE' Then
            Begin
              --先处理特殊占用
              p_lg_Close_Cancel_Sp_Occ(p_order_line_id    => r_Order_Line.Order_Line_Id,
                                       p_close_qty        => v_remain_cancel_qty, --关闭数量
                                       p_lg_order_id      => r_Lg_Order_Line.order_head_id,
                                       p_lg_order_number  => r_Lg_Order_Head.Order_Number,
                                       p_lg_order_line_id => r_Lg_Order_Line.order_line_id,
                                       p_user_code        => p_User_Code, --用户
                                       p_remain_qty       => v_remain_close_qty, --剩余数量
                                       p_Result           => p_Result);

              IF p_Result <> v_Success THEN
                RAISE v_Base_Exception;
              END IF;

              --剩余数量大于0才处理
              IF v_remain_close_qty > 0 Then
                v_remain_cancel_qty := v_remain_close_qty;
                For r_Share_Ship In (Select Nvl(Oss.Share_Qty, 0) -
                                            Nvl(Oss.Carry_Qty, 0) Usable_Cancel_Qty,
                                            Oss.*
                                       From t_Pln_Order_Share_Shipment Oss
                                      Where Oss.Origin_Line_Id =
                                            r_Order_Line.Order_Line_Id
                                        and Nvl(Oss.Share_Qty, 0) - nvl(oss.carry_qty,0) > 0) LOOP
                  if  v_remain_cancel_qty <= 0 then --剩余带取消数量小于等于0，跳出循环
                    exit;
                  end if;
                  --检查可取消数量与待取消数量
                  if v_remain_cancel_qty > 0 and v_remain_cancel_qty > r_Share_Ship.Usable_Cancel_Qty then
                    v_deal_qty := r_Share_Ship.Usable_Cancel_Qty;
                    v_remain_cancel_qty := v_remain_cancel_qty - r_Share_Ship.Usable_Cancel_Qty;
                  elsif v_remain_cancel_qty > 0 and v_remain_cancel_qty <= r_Share_Ship.Usable_Cancel_Qty then
                    v_deal_qty := v_remain_cancel_qty;
                    v_remain_cancel_qty := 0;
                  end if;

                  --更新订单发货计划待取消数量
                  IF v_deal_qty > 0 THEN
                    Update t_Pln_Order_Share_Shipment Oss
                       Set Oss.Canceling_Qty = v_deal_qty
                     Where Oss.Order_Share_Id = r_Share_Ship.Order_Share_Id;
                    p_Order_Cancel(p_Entity_Id    => r_Share_Ship.Entity_Id,
                                   p_Order_Shares => r_Share_Ship.Order_Share_Id,
                                   p_User_Code    => p_User_Code,
                                   p_Result       => p_Result);
                    If p_Result <> v_Success Then
                      Raise v_Base_Exception;
                    End If;
                  END IF;
                End Loop;
              Else
                v_remain_cancel_qty := 0; --特殊占用释放了，剩余取消数量清0
              END IF;
            End;
          End If;
        End Loop;
        if v_remain_cancel_qty > 0 then
          p_Result := '当前行的待取消数量('|| v_cancel_qty || ')大于计划订单的可取消数量！'|| v_Nl || '产品编码：'|| r_Lg_Order_Line.item_code || '订单行id：' || r_Lg_Order_Line.order_line_id;
          Raise v_Base_Exception;
        end if;
      End If;

      --更新行评数量信息
      If v_Relation_Type != 'PLN_ORDER_TYPE' Then
        Update t_Pln_Lg_Order_Line Ol
           Set Ol.Affirm_Quantity = 0
         Where Ol.Order_Line_Id = r_Lg_Order_Line.Order_Line_Id;
      End If;
    End Loop;
  EXCEPTION
    When v_Base_Exception Then
      Rollback;
      p_Result := p_Result;
    When Others Then
      p_Result := v_Message || v_Nl || Sqlerrm;
  END P_CANCEL_T3_ORDER;

End Pkg_Pln_Order;
/

