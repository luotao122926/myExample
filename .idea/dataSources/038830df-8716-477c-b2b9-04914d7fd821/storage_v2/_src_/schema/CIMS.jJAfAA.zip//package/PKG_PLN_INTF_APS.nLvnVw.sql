create Package Pkg_Pln_Intf_Aps Is

  -- Author  : NICRO.LI
  -- Created : 2016-04-09 10:28:09
  -- Purpose : APS DBLINK接口包
  
  -----------------------------------------------------------------------------
  -- AUTHOR  : Nicro.Li
  -- CREATED : 2016-04-09
  -- PURPOSE : 根据产品、组织ID获取APS剩余产能
  -----------------------------------------------------------------------------
  Function f_Get_Item_Capacity_Qty(p_Organization_Id In Number, ----主体ID
                                   p_Item_Code       In Varchar2 --产品编码
                                   ) Return Number;
  
  -----------------------------------------------------------------------------
  -- AUTHOR  : Nicro.Li
  -- CREATED : 2016-04-09
  -- PURPOSE : 根据产品、组织ID获取APS剩余产能
  -----------------------------------------------------------------------------
  Procedure p_Import_Aps_Capacity(p_Batch_Id In Number,
                                  p_Result   Out Varchar2);
                                                                   
  -----------------------------------------------------------------------------
  -- AUTHOR  : Nicro.Li
  -- CREATED : 2016-04-09
  -- PURPOSE : 根据产品、组织ID获取APS剩余产能
  -----------------------------------------------------------------------------
  Procedure p_Lgorder_Aps_Capacity_Send(p_Lg_Order_Head_Id In Number, --提货订单头ID
                                        p_Cancel_Flag      In Varchar2, --是否取消订单  N:正常引入  Y：取消提货订单
                                        p_User_Code        In Varchar2,
                                        p_Result           Out Varchar2,
                                        p_Batch_Id         Out Number,    --返回批次ID
                                        p_Entity_Code      Out Varchar2,   --返回主体编码
                                        p_Close_Line_Flag  In Varchar2 Default 'N' --是否关闭订单行 --add by lizhen 2016-06-12
                                        );

  -----------------------------------------------------------------------------
  -- AUTHOR  : Nicro.Li
  -- CREATED : 2016-05-06
  -- PURPOSE : 把已引APS产能可视状态，且有被删除的行数据引入APS产能可视
  -----------------------------------------------------------------------------
  Procedure p_DelLine_Aps_Capacity_Send(p_Lg_Order_Head_Id In Number, --提货订单头ID
                                        p_User_Code        In Varchar2,
                                        p_Result           Out Varchar2,
                                        p_Batch_Id         Out Number,    --返回批次ID
                                        p_Entity_Code      Out Varchar2   --返回主体编码
                                        );
                                        
  --------------------------------------------------------------------------
  --Author: Nicro.li
  --Created: 2016-05-18
  --Purpose:产能可视结果回写提货订单
  --------------------------------------------------------------------------
  Procedure p_Capacity_Receiver_Pro(p_Batch_Id    In Number,
                                    p_Entity_Code In Varchar2,
                                    p_Result      Out Varchar2);
  
  -----------------------------------------------------------------------------
  -- AUTHOR  : Nicro.Li
  -- CREATED : 2017-11-02
  -- PURPOSE : 预约汇总数据引入APS预约接口表
  -----------------------------------------------------------------------------
  Procedure p_Lg_Aps_Reservation_Send(In_Reservation_Head_Id   In Number, --提货订单头ID
                                      In_Cancel_Flag           In Varchar2, --是否取消订单  N:正常引入  Y：取消提货订单
                                      In_User_Code             In Varchar2,
                                      Out_Result               Out Varchar2,
                                      Out_Batch_Id             Out Number,
                                      Out_Entity_Code          Out Varchar2,
                                      Out_Organization_Id      Out Number
                                      );       
                                      
  -----------------------------------------------------------------------------
  -- AUTHOR  : Nicro.Li
  -- CREATED : 2017-11-02
  -- PURPOSE : 调用APS方法处理已引入的预约数据
  -----------------------------------------------------------------------------
  Procedure p_Aps_Reservation_Request(In_Reservation_Head_Id   In Number, --提货订单头ID               
                                      In_User_Code             In Varchar2,
                                      Out_Result               Out Varchar2                                      
                                      );                                                                 
End Pkg_Pln_Intf_Aps;
/

