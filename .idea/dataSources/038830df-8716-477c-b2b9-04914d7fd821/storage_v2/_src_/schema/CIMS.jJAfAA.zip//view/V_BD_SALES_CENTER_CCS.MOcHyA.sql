create view V_BD_SALES_CENTER_CCS as
select t.unit_id   sales_center_id, --单位ID
       t.code      sales_center_code, --单位编码
       t.name      sales_center_name, --单位名称
       t.type_code, --单位编码（事业部：BU,营销区域：SR ，营销中心：SC）
       --t.par_unit_id, --上级单位ID
       (select unit_id
          from up_org_unit r
         where r.unit_id = t.par_unit_id
           and r.type_code = 'SR'
           and r.is_enabled = 'T') sales_region_id, --区域ID
       (select code
          from up_org_unit r
         where r.unit_id = t.par_unit_id
           and r.type_code = 'SR'
           and r.is_enabled = 'T') sales_region_code, --区域编码
       (select name
          from up_org_unit r
         where r.unit_id = t.par_unit_id
           and r.type_code = 'SR'
           and r.is_enabled = 'T') sales_region_name, --区域ID
       t.entity_id,
       t.active_flag,
       t.created_by,
       t.creation_date,
       t.last_updated_by,
       t.last_update_date,
       t.level_seq, --层级
       t.level_num, --层级码
       t.full_name --单位全称
  from up_org_unit t
 where t.type_code = 'SC'
 order by t.level_num
/

comment on column V_BD_SALES_CENTER_CCS.SALES_CENTER_ID is '单位ID'
/

comment on column V_BD_SALES_CENTER_CCS.SALES_CENTER_CODE is '单位编码'
/

comment on column V_BD_SALES_CENTER_CCS.SALES_CENTER_NAME is '单位名称'
/

comment on column V_BD_SALES_CENTER_CCS.TYPE_CODE is '单位编码'
/

comment on column V_BD_SALES_CENTER_CCS.SALES_REGION_ID is '区域ID'
/

comment on column V_BD_SALES_CENTER_CCS.SALES_REGION_CODE is '区域编码'
/

comment on column V_BD_SALES_CENTER_CCS.SALES_REGION_NAME is '区域名称'
/

comment on column V_BD_SALES_CENTER_CCS.LEVEL_SEQ is '层级'
/

comment on column V_BD_SALES_CENTER_CCS.LEVEL_NUM is '层级码'
/

comment on column V_BD_SALES_CENTER_CCS.FULL_NAME is '单位全称'
/

