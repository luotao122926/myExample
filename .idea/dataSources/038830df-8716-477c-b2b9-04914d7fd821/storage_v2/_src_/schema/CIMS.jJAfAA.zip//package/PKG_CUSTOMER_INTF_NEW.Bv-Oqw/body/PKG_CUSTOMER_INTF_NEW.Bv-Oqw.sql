create PACKAGE BODY PKG_CUSTOMER_INTF_NEW IS
	V_NL CONSTANT VARCHAR2(2) := CHR(13) || CHR(10); --换行
  PROCEDURE P_CUSTOMER_INTF_PROCLOV(P_INTF_TRANSCODE in varchar2, --接口流水号
                                    P_MESSAGE        out varchar2 --成功则返回“SUCCESS”，否则返回出错信息
                                    ) IS
    V_BIZ_EXCEPTION EXCEPTION; --自定义业务异常
    V_CODELIST_COUNT NUMBER;
    V_CODEVALUE      VARCHAR2(100);
    CURSOR C_INTFCUST_CODELIST IS
      SELECT *
        FROM INTF_CUSTOMER_UPCODELIST
       WHERE TRANSCODE = P_INTF_TRANSCODE;
  BEGIN
    P_MESSAGE := 'SUCCESS';
  
    FOR R_INTFCUST_CODELIST IN C_INTFCUST_CODELIST LOOP
      BEGIN
        SELECT REPLACE(R_INTFCUST_CODELIST.Name, ' ', '')
          INTO V_CODEVALUE
          FROM DUAL;
      
        SELECT COUNT(0)
          INTO V_CODELIST_COUNT
          FROM UP_CODELIST cl
         WHERE cl.code_value = V_CODEVALUE
           AND cl.codetype = R_INTFCUST_CODELIST.Type;
      
        IF (V_CODELIST_COUNT = 0) THEN
          INSERT INTO UP_CODELIST
            (ID,
             CODE_VALUE,
             CODE_NAME,
             CODETYPE,
             PARENT,
             CODE_ORDER,
             ENABLED,
             REMARK,
             LANGUAGE,
             CODETYPE_NAME,
             FILTER,
             CREATED_BY,
             CREATION_TIME,
             MODIFIED_BY,
             MODIFICATION_TIME,
             ENTITY_FLAG)
          VALUES
            ('CRM' || R_INTFCUST_CODELIST.ID,
             V_CODEVALUE,
             R_INTFCUST_CODELIST.Value,
             R_INTFCUST_CODELIST.Type,
             '-1',
             NULL,
             '0',
             R_INTFCUST_CODELIST.DESCRIPTION,
             'zh_CN',
             R_INTFCUST_CODELIST.LANGUAGE,
             NULL,
             'CRM',
             NULL,
             NULL,
             R_INTFCUST_CODELIST.UPDATED,
             'N');
        
          UPDATE INTF_CUSTOMER_UPCODELIST
             SET RESPONSETYPE    = 'N',
                 RESPNOSECODE    = '000000',
                 RESPONSEMESSAGE = P_MESSAGE,
                 OPERSTATUS      = '0'
           WHERE TRANSCODE = P_INTF_TRANSCODE
             AND ID = R_INTFCUST_CODELIST.ID;
        
        ELSE
          UPDATE UP_CODELIST cl
             SET cl.code_name         = R_INTFCUST_CODELIST.Value,
                 cl.modification_time = R_INTFCUST_CODELIST.UPDATED,
                 cl.enabled           = decode(R_INTFCUST_CODELIST.ACTIVE,
                                               'Y',
                                               '0',
                                               'N',
                                               '1')
          
           WHERE cl.code_value = V_CODEVALUE
             AND cl.codetype = R_INTFCUST_CODELIST.Type;
        
          UPDATE INTF_CUSTOMER_UPCODELIST
             SET RESPONSETYPE    = 'N',
                 RESPNOSECODE    = '000000',
                 RESPONSEMESSAGE = P_MESSAGE,
                 OPERSTATUS      = '0'
           WHERE TRANSCODE = P_INTF_TRANSCODE
             AND ID = R_INTFCUST_CODELIST.ID;
        END IF;
      
      EXCEPTION
        WHEN OTHERS THEN
        
          ROLLBACK;
          --记录出错信息
          P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_CUSTOMER_INTF.P_CUSTOMER_INTF_PROCLOV',
                                              SQLCODE,
                                              '插入字典表失败！：' || SQLERRM);
          UPDATE INTF_CUSTOMER_UPCODELIST
             SET RESPONSETYPE    = 'E',
                 RESPNOSECODE    = '000013',
                 RESPONSEMESSAGE = P_MESSAGE,
                 OPERSTATUS      = '1'
           WHERE TRANSCODE = P_INTF_TRANSCODE
             AND ID = R_INTFCUST_CODELIST.ID;
      END;
    END LOOP;
  
    --RAISE V_BIZ_EXCEPTION;
  END;

  PROCEDURE P_CUSTOMER_INTF_PROC(P_INTF_HEADER_ID_LIST in varchar2, --接口表中的客户头ID，用逗号分隔
                                 P_MESSAGE             out varchar2, --成功则返回“SUCCESS”，否则返回出错信息
                                 IS_CTRL_PARAM         IN  VARCHAR2 DEFAULT NULL--NOTGTWIDTH 不联动失效
                                 --NOTGTWIDTHANDNODEPT 不联动失效也不处理客户头、事业部、OU
                                 ) IS
    V_INTF_HEADER_ID_LIST PKG_BD_UTIL.T_VARRAY := PKG_BD_UTIL.T_VARRAY(); --声明集合,接口表客户ID
    V_BIZ_EXCEPTION EXCEPTION; --自定义业务异常
    V_INTF_HEADER_COUNT         NUMBER; --接口表中的头信息数量
    V_INTF_ADDRESS_COUNT        NUMBER; --接口表中地址的数量
    V_INTF_BANK_COUNT           NUMBER; --接口表中银行的数量
    V_INTF_BRAND_COUNT          NUMBER; --接口表中品牌的数量
    V_INTF_CHANNEL_TYPE_COUNT   NUMBER; --接口表中的渠道类型（业态类型）数量
    V_INTF_CONNECTION_COUNT     NUMBER; --接口表中的关联关系数量
    V_INTF_CONTACTS_COUNT       NUMBER; --接口表中的联系人数量
    V_INTF_DEPT_COUNT           NUMBER; --接口表中的事业部的数量
    V_INTF_ORG_COUNT            NUMBER; --接口表中的组织信息的数量
    V_INTF_OU_COUNT             NUMBER; --接口表中的OU信息的数量
    V_INTF_SALE_MAIN_TYPE_COUNT NUMBER; --接口表中营销大类信息数量
  
    V_CUST_DEPT_COUNT VARCHAR2(2); --业务表中的事业部的数量
    V_INTF_HEADER     INTF_CUSTOMER_HEADER%ROWTYPE;
  
    V_CUST_HEADER_ID     NUMBER; --客户头ID
    V_HEADER_ID          NUMBER; --客户头ID
    V_CUST_HEADER_STATUS VARCHAR2(30); --客户头状态
    VT_MESSAGE           VARCHAR2(4000);
    VT_HEAD_ERRMSG       VARCHAR2(4000);
    VT_DEPT_ERRMSG       VARCHAR2(4000);
  
  BEGIN
  
    V_INTF_HEADER_ID_LIST := PKG_BD_UTIL.STR_SPLIT(P_INTF_HEADER_ID_LIST,
                                                   ',');
    FOR i IN 1 .. V_INTF_HEADER_ID_LIST.COUNT() LOOP
      V_CUST_DEPT_COUNT := '1';
      --查询数量
      SELECT COUNT(0)
        INTO V_INTF_ADDRESS_COUNT
        FROM INTF_CUSTOMER_ADDRESS
       WHERE PRE_FIELD_01 = V_INTF_HEADER_ID_LIST(i);
      SELECT COUNT(0)
        INTO V_INTF_BANK_COUNT
        FROM INTF_CUSTOMER_BANK
       WHERE PRE_FIELD_01 = V_INTF_HEADER_ID_LIST(i);
      SELECT COUNT(0)
        INTO V_INTF_BRAND_COUNT
        FROM INTF_CUSTOMER_BRAND
       WHERE PRE_FIELD_01 = V_INTF_HEADER_ID_LIST(i);
      SELECT COUNT(0)
        INTO V_INTF_CHANNEL_TYPE_COUNT
        FROM INTF_CUSTOMER_CHANNEL_TYPE
       WHERE PRE_FIELD_01 = V_INTF_HEADER_ID_LIST(i);
      SELECT COUNT(0)
        INTO V_INTF_CONNECTION_COUNT
        FROM INTF_CUSTOMER_CONNECTION
       WHERE PRE_FIELD_01 = V_INTF_HEADER_ID_LIST(i);
      SELECT COUNT(0)
        INTO V_INTF_CONTACTS_COUNT
        FROM INTF_CUSTOMER_CONTACTS
       WHERE PRE_FIELD_01 = V_INTF_HEADER_ID_LIST(i);
      SELECT COUNT(0)
        INTO V_INTF_DEPT_COUNT
        FROM INTF_CUSTOMER_DEPT
       WHERE PRE_FIELD_01 = V_INTF_HEADER_ID_LIST(i);
      SELECT COUNT(0)
        INTO V_INTF_HEADER_COUNT
        FROM INTF_CUSTOMER_HEADER
       WHERE CUSTOMER_ID = V_INTF_HEADER_ID_LIST(i);
      SELECT COUNT(0)
        INTO V_INTF_ORG_COUNT
        FROM INTF_CUSTOMER_ORG
       WHERE PRE_FIELD_01 = V_INTF_HEADER_ID_LIST(i);
      SELECT COUNT(0)
        INTO V_INTF_OU_COUNT
        FROM INTF_CUSTOMER_OU
       WHERE PRE_FIELD_01 = V_INTF_HEADER_ID_LIST(i);
      SELECT COUNT(0)
        INTO V_INTF_SALE_MAIN_TYPE_COUNT
        FROM INTF_CUSTOMER_SALES_MAIN_TYPE
       WHERE PRE_FIELD_01 = V_INTF_HEADER_ID_LIST(i);
    
      --插入客户头业务表
      BEGIN
        IF ('NOTGTWIDTHANDNODEPT' <> IS_CTRL_PARAM OR IS_CTRL_PARAM IS NULL) AND (V_INTF_HEADER_COUNT > 0) THEN
        
          SELECT H.*
            INTO V_INTF_HEADER
            FROM INTF_CUSTOMER_HEADER H
           WHERE CUSTOMER_ID = V_INTF_HEADER_ID_LIST(i);
        
          --调用函数插入或者更新客户头表
          PRC_INSERT_OR_UPDATE_HEADER(V_INTF_HEADER,
                                      V_CUST_HEADER_ID,
                                      V_CUST_HEADER_STATUS,
                                      V_HEADER_ID,
                                      VT_MESSAGE);
          IF 'SUCCESS' <> VT_MESSAGE THEN
            IF VT_HEAD_ERRMSG IS NULL THEN
              VT_HEAD_ERRMSG := VT_MESSAGE;
            ELSE
              VT_HEAD_ERRMSG := VT_HEAD_ERRMSG || V_NL || VT_MESSAGE;
            END IF;
            UPDATE INTF_CUSTOMER_HEADER
               SET RESPONSETYPE    = 'E',
                   RESPNOSECODE    = '000013',
                   RESPONSEMESSAGE = VT_MESSAGE,
                   OPERSTATUS      = '1'
             WHERE CUSTOMER_ID = V_INTF_HEADER_ID_LIST(i);
            GOTO LPEND;
          ELSE
            VT_MESSAGE := 'SUCCESS';
            UPDATE INTF_CUSTOMER_HEADER
               SET RESPONSETYPE    = 'N',
                   RESPNOSECODE    = '000000',
                   RESPONSEMESSAGE = VT_MESSAGE,
                   OPERSTATUS      = '0'
             WHERE CUSTOMER_ID = V_INTF_HEADER_ID_LIST(i);
          END IF;
        
        END IF;
      EXCEPTION
        WHEN OTHERS THEN
        
          ROLLBACK;
          --记录出错信息
          VT_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_CUSTOMER_INTF.P_CUSTOMER_INTF_PROC.F_INSERT_OR_UPDATE_BANK',
                                              SQLCODE,
                                              '插入客户头表失败！：' || SQLERRM);
          IF VT_HEAD_ERRMSG IS NULL THEN
            VT_HEAD_ERRMSG := VT_MESSAGE;
          ELSE
            VT_HEAD_ERRMSG := VT_HEAD_ERRMSG || V_NL || VT_MESSAGE;
          END IF;
          UPDATE INTF_CUSTOMER_HEADER
             SET RESPONSETYPE    = 'E',
                 RESPNOSECODE    = '000013',
                 RESPONSEMESSAGE = VT_MESSAGE,
                 OPERSTATUS      = '1'
           WHERE CUSTOMER_ID = V_INTF_HEADER_ID_LIST(i);
          GOTO LPEND;
          --RAISE V_BIZ_EXCEPTION;
      END;
    
      --插入事业部业务表
      BEGIN
        IF ('NOTGTWIDTHANDNODEPT' <> IS_CTRL_PARAM OR IS_CTRL_PARAM IS NULL) AND (V_INTF_DEPT_COUNT > 0) THEN
          --调用函数插入或者更新事业部表
          VT_MESSAGE := F_INSERT_OR_UPDATE_DEPT(V_INTF_HEADER_ID_LIST(i));
          IF VT_MESSAGE <> 'SUCCESS' AND VT_MESSAGE NOT LIKE '%不是内销%' THEN
            IF VT_DEPT_ERRMSG IS NULL THEN
              VT_DEPT_ERRMSG := VT_MESSAGE;
            ELSE
              VT_DEPT_ERRMSG := VT_DEPT_ERRMSG || V_NL || VT_MESSAGE;
            END IF;
          END IF;
        
          /*        UPDATE INTF_CUSTOMER_DEPT SET RESPONSETYPE = 'N',RESPNOSECODE = '000000',RESPONSEMESSAGE = P_MESSAGE,OPERSTATUS = '0'
          WHERE PRE_FIELD_01 = V_INTF_HEADER_ID_LIST(i);
          COMMIT;*/
        END IF;
        /*      EXCEPTION
        WHEN OTHERS THEN
        
          ROLLBACK;
          --记录出错信息
          P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_CUSTOMER_INTF.P_CUSTOMER_INTF_PROCF_INSERT_OR_UPDATE_DEPT',
                                              SQLCODE,
                                              '插入客户事业部表失败！：' || SQLERRM);
         UPDATE INTF_CUSTOMER_DEPT SET RESPONSETYPE = 'E',RESPNOSECODE = '000013',RESPONSEMESSAGE = P_MESSAGE,OPERSTATUS = '1'
        WHERE PRE_FIELD_01 = V_INTF_HEADER_ID_LIST(i);
        COMMIT;*/
        --RAISE V_BIZ_EXCEPTION;
      END;
    
      BEGIN
        --插入联系人业务表
        IF (V_INTF_CONTACTS_COUNT > 0) THEN
          P_MESSAGE := F_INSERT_OR_UPDATE_CONTACTS(V_INTF_HEADER_ID_LIST(i));
          /*        UPDATE INTF_CUSTOMER_CONTACTS SET RESPONSETYPE = 'N',RESPNOSECODE = '000000',RESPONSEMESSAGE = P_MESSAGE,OPERSTATUS = '0'
          WHERE PRE_FIELD_01 = V_INTF_HEADER_ID_LIST(i);
          COMMIT;*/
        END IF;
        /*EXCEPTION
        WHEN OTHERS THEN
        
          ROLLBACK;
          --记录出错信息
          P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_CUSTOMER_INTF.P_CUSTOMER_INTF_PROC.F_INSERT_OR_UPDATE_CONTACTS',
                                              SQLCODE,
                                              '插入客户联系人表失败！：' || SQLERRM);
         UPDATE INTF_CUSTOMER_CONTACTS SET RESPONSETYPE = 'E',RESPNOSECODE = '000013',RESPONSEMESSAGE = P_MESSAGE,OPERSTATUS = '1'
        WHERE PRE_FIELD_01 = V_INTF_HEADER_ID_LIST(i);
        COMMIT;
          --RAISE V_BIZ_EXCEPTION;*/
      END;
    
      BEGIN
        --插入银行业务表
        IF (V_INTF_BANK_COUNT > 0) THEN
          P_MESSAGE := F_INSERT_OR_UPDATE_BANK(V_INTF_HEADER_ID_LIST(i));
          /*        UPDATE INTF_CUSTOMER_BANK SET RESPONSETYPE = 'N',RESPNOSECODE = '000000',RESPONSEMESSAGE = P_MESSAGE,OPERSTATUS = '1'
          WHERE PRE_FIELD_01 = V_INTF_HEADER_ID_LIST(i);
          COMMIT;*/
        END IF;
        /* EXCEPTION
        WHEN OTHERS THEN
        
          ROLLBACK;
          --记录出错信息
          P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_CUSTOMER_INTF.P_CUSTOMER_INTF_PROC.F_INSERT_OR_UPDATE_BANK',
                                              SQLCODE,
                                              '插入银行业务表失败！：' || SQLERRM);
          UPDATE INTF_CUSTOMER_BANK SET RESPONSETYPE = 'E',RESPNOSECODE = '000013',RESPONSEMESSAGE = P_MESSAGE,OPERSTATUS = '1'
        WHERE PRE_FIELD_01 = V_INTF_HEADER_ID_LIST(i);
        COMMIT;*/
        --RAISE V_BIZ_EXCEPTION;
      END;
    
      BEGIN
        --插入渠道类型（业态类型）业务表
        IF (V_INTF_CHANNEL_TYPE_COUNT > 0) THEN
          P_MESSAGE := F_INSERT_OR_UPDATE_CHANN_TYPE(V_INTF_HEADER_ID_LIST(i));
          /*UPDATE INTF_CUSTOMER_CHANNEL_TYPE SET RESPONSETYPE = 'N',RESPNOSECODE = '000000',RESPONSEMESSAGE = P_MESSAGE,OPERSTATUS = '1'
          WHERE PRE_FIELD_01 = V_INTF_HEADER_ID_LIST(i);
          COMMIT;*/
        END IF;
        /*EXCEPTION
        WHEN OTHERS THEN
        
          ROLLBACK;
          --记录出错信息
          P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_CUSTOMER_INTF.P_CUSTOMER_INTF_PROC.F_INSERT_OR_UPDATE_CHANN_TYPE',
                                              SQLCODE,
                                              '插入银行业务表失败！：' || SQLERRM);
           UPDATE INTF_CUSTOMER_CHANNEL_TYPE SET RESPONSETYPE = 'E',RESPNOSECODE = '000013',RESPONSEMESSAGE = P_MESSAGE,OPERSTATUS = '1'
        WHERE PRE_FIELD_01 = V_INTF_HEADER_ID_LIST(i);
        COMMIT;*/
        --RAISE V_BIZ_EXCEPTION;
      END;
    
      BEGIN
        --插入组织业务表
        IF (V_INTF_ORG_COUNT > 0) THEN
          P_MESSAGE := F_INSERT_OR_UPDATE_ORG(V_INTF_HEADER_ID_LIST(i));
          /*  UPDATE INTF_CUSTOMER_ORG SET RESPONSETYPE = 'N',RESPNOSECODE = '000000',RESPONSEMESSAGE = P_MESSAGE,OPERSTATUS = '1'
          WHERE PRE_FIELD_01 = V_INTF_HEADER_ID_LIST(i);
          COMMIT;*/
        END IF;
        /* EXCEPTION
        WHEN OTHERS THEN
        
          ROLLBACK;
          --记录出错信息
          P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_CUSTOMER_INTF.P_CUSTOMER_INTF_PROC.F_INSERT_OR_UPDATE_ORG',
                                              SQLCODE,
                                              '插入银行业务表失败！：' || SQLERRM);
          UPDATE INTF_CUSTOMER_ORG SET RESPONSETYPE = 'E',RESPNOSECODE = '000013',RESPONSEMESSAGE = P_MESSAGE,OPERSTATUS = '1'
        WHERE PRE_FIELD_01 = V_INTF_HEADER_ID_LIST(i);
        COMMIT;*/
        -- RAISE V_BIZ_EXCEPTION;
      END;
    
      BEGIN
        --插入品牌业务表
        IF (V_INTF_BRAND_COUNT > 0) THEN
          P_MESSAGE := F_INSERT_OR_UPDATE_BRAND(V_INTF_HEADER_ID_LIST(i));
          /*        UPDATE INTF_CUSTOMER_BRAND SET RESPONSETYPE = 'N',RESPNOSECODE = '000000',RESPONSEMESSAGE = P_MESSAGE,OPERSTATUS = '1'
          WHERE PRE_FIELD_01 = V_INTF_HEADER_ID_LIST(i);
          COMMIT;*/
        END IF;
        /* EXCEPTION
        WHEN OTHERS THEN
        
          ROLLBACK;
          --记录出错信息
          P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_CUSTOMER_INTF.P_CUSTOMER_INTF_PROC.F_INSERT_OR_UPDATE_BRAND',
                                              SQLCODE,
                                              '插入银行业务表失败！：' || SQLERRM);
         UPDATE INTF_CUSTOMER_BRAND SET RESPONSETYPE = 'E',RESPNOSECODE = '000013',RESPONSEMESSAGE = P_MESSAGE,OPERSTATUS = '1'
        WHERE PRE_FIELD_01 = V_INTF_HEADER_ID_LIST(i);
        COMMIT;*/
        --RAISE V_BIZ_EXCEPTION;
      END;
    
      BEGIN
        --插入关联关系业务表
        IF (V_INTF_CONNECTION_COUNT > 0) THEN
          P_MESSAGE := F_INSERT_OR_UPDATE_CONNECTION(V_INTF_HEADER_ID_LIST(i));
          /*UPDATE INTF_CUSTOMER_CONNECTION SET RESPONSETYPE = 'N',RESPNOSECODE = '000000',RESPONSEMESSAGE = P_MESSAGE,OPERSTATUS = '1'
          WHERE PRE_FIELD_01 = V_INTF_HEADER_ID_LIST(i);
          COMMIT;*/
        END IF;
        /*EXCEPTION
         WHEN OTHERS THEN
        
           ROLLBACK;
           --记录出错信息
           P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_CUSTOMER_INTF.P_CUSTOMER_INTF_PROC.F_INSERT_OR_UPDATE_CONNECTION',
                                               SQLCODE,
                                               '插入银行业务表失败！：' || SQLERRM);
        UPDATE INTF_CUSTOMER_CONNECTION SET RESPONSETYPE = 'E',RESPNOSECODE = '000013',RESPONSEMESSAGE = P_MESSAGE,OPERSTATUS = '1'
         WHERE PRE_FIELD_01 = V_INTF_HEADER_ID_LIST(i);
         COMMIT;*/
        -- RAISE V_BIZ_EXCEPTION;
      END;
    
      BEGIN
        --插入客户地址业务表
        IF (V_INTF_ADDRESS_COUNT > 0) THEN
          P_MESSAGE := F_INSERT_OR_UPDATE_ADDRESS(V_INTF_HEADER_ID_LIST(i));
          /* UPDATE INTF_CUSTOMER_ADDRESS SET RESPONSETYPE = 'N',RESPNOSECODE = '000000',RESPONSEMESSAGE = P_MESSAGE,OPERSTATUS = '0'
          WHERE PRE_FIELD_01 = V_INTF_HEADER_ID_LIST(i);
          COMMIT;*/
          /*BEGIN
            SELECT ADDR.ERROR_INFO INTO VT_MESSAGE FROM INTF_CUSTOMER_ADDRESS ADDR
            WHERE ADDR.PRE_FIELD_01 = V_INTF_HEADER_ID_LIST(i)
            AND 'N' <> ADDR.RESPONSETYPE
            AND '000000' <> ADDR.RESPNOSECODE
            AND ADDR.RESPONSEMESSAGE IS NOT NULL
            AND ADDR.ERROR_INFO IS NOT NULL
            AND 1 = ROWNUM;
            VT_DEPT_ERRMSG := VT_MESSAGE;
          EXCEPTION
                WHEN OTHERS THEN
                  NULL;
          END;*/
        END IF;
        /* EXCEPTION
        WHEN OTHERS THEN
        
          ROLLBACK;
          --记录出错信息
          P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_CUSTOMER_INTF.P_CUSTOMER_INTF_PROC.F_INSERT_OR_UPDATE_ADDRESS',
                                              SQLCODE,
                                              '插入客户地址表失败！：' || SQLERRM);
        UPDATE INTF_CUSTOMER_ADDRESS SET RESPONSETYPE = 'E',RESPNOSECODE = '000013',RESPONSEMESSAGE = P_MESSAGE,OPERSTATUS = '1'
        WHERE PRE_FIELD_01 = V_INTF_HEADER_ID_LIST(i);
        COMMIT;*/
        --RAISE V_BIZ_EXCEPTION;
      END;
    
      --插入OU业务表
      BEGIN
        IF ('NOTGTWIDTHANDNODEPT' <> IS_CTRL_PARAM OR IS_CTRL_PARAM IS NULL) AND (V_INTF_OU_COUNT > 0) THEN
          P_MESSAGE := F_INSERT_OR_UPDATE_OU(V_INTF_HEADER_ID_LIST(i));
          /* UPDATE INTF_CUSTOMER_OU SET RESPONSETYPE = 'N',RESPNOSECODE = '000000',RESPONSEMESSAGE = P_MESSAGE,OPERSTATUS = '1'
          WHERE PRE_FIELD_01 = V_INTF_HEADER_ID_LIST(i);
          COMMIT;*/
        END IF;
        /*EXCEPTION
        WHEN OTHERS THEN
        
          ROLLBACK;
          --记录出错信息
          P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_CUSTOMER_INTF.P_CUSTOMER_INTF_PROC.F_INSERT_OR_UPDATE_OU',
                                              SQLCODE,
                                              '插入银行业务表失败！：' || SQLERRM);
         UPDATE INTF_CUSTOMER_OU SET RESPONSETYPE = 'E',RESPNOSECODE = '000013',RESPONSEMESSAGE = P_MESSAGE,OPERSTATUS = '1'
        WHERE PRE_FIELD_01 = V_INTF_HEADER_ID_LIST(i);
        COMMIT;*/
        -- RAISE V_BIZ_EXCEPTION;
      END;
    
      --插入营销大类业务表
      BEGIN
        IF (V_INTF_SALE_MAIN_TYPE_COUNT > 0) THEN
          P_MESSAGE := F_INSERT_OR_UPDATE_MAIN_TYPE(V_INTF_HEADER_ID_LIST(i));
          /*UPDATE INTF_CUSTOMER_SALES_MAIN_TYPE SET RESPONSETYPE = 'N',RESPNOSECODE = '000000',RESPONSEMESSAGE = P_MESSAGE,OPERSTATUS = '1'
          WHERE PRE_FIELD_01 = V_INTF_HEADER_ID_LIST(i);
          COMMIT;*/
        END IF;
        /*EXCEPTION
        WHEN OTHERS THEN
        
          ROLLBACK;
          --记录出错信息
          P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_CUSTOMER_INTF.P_CUSTOMER_INTF_PROC.F_INSERT_OR_UPDATE_MAIN_TYPE',
                                              SQLCODE,
                                              '插入银行业务表失败！：' || SQLERRM);
         UPDATE INTF_CUSTOMER_SALES_MAIN_TYPE SET RESPONSETYPE = 'E',RESPNOSECODE = '000013',RESPONSEMESSAGE = P_MESSAGE,OPERSTATUS = '1'
        WHERE PRE_FIELD_01 = V_INTF_HEADER_ID_LIST(i);
        COMMIT;
          --RAISE V_BIZ_EXCEPTION;*/
      END;
    
      --插入客户头业务表
      IF IS_CTRL_PARAM IS NULL OR ('NOTGTWIDTH' <> IS_CTRL_PARAM AND 'NOTGTWIDTHANDNODEPT' <> IS_CTRL_PARAM) THEN
        BEGIN
          PRC_UPDATE_STATUS_CHANGED(V_INTF_HEADER_ID_LIST(i), V_HEADER_ID);
        EXCEPTION
          WHEN OTHERS THEN
            ROLLBACK;
            --记录出错信息
            P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_CUSTOMER_INTF.P_CUSTOMER_INTF_PROC.PRC_UPDATE_STATUS_CHANGED',
                                                SQLCODE,
                                                '冻结失效处理出错！：' || SQLERRM);
            UPDATE INTF_CUSTOMER_HEADER
               SET RESPONSETYPE    = 'E',
                   RESPNOSECODE    = '000013',
                   RESPONSEMESSAGE = P_MESSAGE,
                   OPERSTATUS      = '1'
             WHERE CUSTOMER_ID = V_INTF_HEADER_ID_LIST(i);
        END;
      END IF;
      
      --2017 4 17 梁颜明 对接财务系统如果是NC，将客户头、银行信息插入NC接口表
      FOR ENTITY_ID_ARR IN (SELECT ENTITY_ID ENTITY_ID FROM V_BD_ENTITY V
        WHERE 'NC' = PKG_BD.F_GET_PARAMETER_VALUE('PUB_FIN_SYS',
      V.ENTITY_ID,
      NULL,
      NULL)--
      ) LOOP
        BEGIN
          PKG_CUSTOMER_INTF_NC.P_CUSTOMER_INTF_NC_PROC(ENTITY_ID_ARR.ENTITY_ID,
          V_INTF_HEADER_ID_LIST(i), V_HEADER_ID,P_MESSAGE);
        EXCEPTION
        WHEN OTHERS THEN
          NULL;
        END;
      END LOOP;
      
      <<LPEND>>
      NULL;
    END LOOP;
    IF VT_HEAD_ERRMSG <> 'SUCCESS' THEN
      P_MESSAGE := VT_HEAD_ERRMSG;
    ELSIF VT_DEPT_ERRMSG <> 'SUCCESS' THEN
      P_MESSAGE := VT_DEPT_ERRMSG;
    ELSE
      P_MESSAGE := 'SUCCESS';
    END IF;
    /*IF P_MESSAGE IS NULL THEN
      P_MESSAGE := 'SUCCESS';
    END IF;*/
  END;

  PROCEDURE P_CUSTOMER_CHECK_CANVALID_PROC(P_INVALID_ID    in NUMBER, --失效历史ID
                                           P_CUSTOMER_CODE in varchar2, --客户编码
                                           P_INVALID_TYPE  in varchar2, --失效类型
                                           --001代表客户头失效，002代表事业部层失效，003代表客户OU失效
                                           P_DEPT_CODE      in varchar2, --事业部编码
                                           P_DEPT_NAME      in varchar2, --事业部名称
                                           P_CUSTOMER_OU_ID in varchar2, --客户OU ID
                                           P_TRANSCODE      in varchar2, --流水号
                                           P_SOURCE_CODE    in varchar2, --来源系统
                                           P_REQUEST_ID     in varchar2, --请求ID
                                           P_RESULT         OUT varchar2,
                                           --返回结果：Y 可以失效 N不可以失效 W未处理 E异常
                                           P_MESSAGE out varchar2
                                           --P_RESULT等于2时返回，或者有错误时返回
                                           ) IS
    V_MESSAGE1 VARCHAR2(4000);
    V_MESSAGE2 VARCHAR2(4000);
    V_MESSAGE3 VARCHAR2(4000);
    V_MESSAGE4 VARCHAR2(4000);
    V_COUNT    NUMBER;
    V_LAST_MANUAL_DATE                     INTF_CUSTOMER_INVALID_HIS.LAST_UPDATE_DATE%TYPE;
  BEGIN
    P_RESULT  := 'N';
    P_MESSAGE := '无';
    
    --取打开手工开关的最新时间
    SELECT MAX(S.LAST_UPDATE_DATE) INTO V_LAST_MANUAL_DATE FROM INTF_CUSTOMER_INVALID_HIS S
    WHERE 'Y' = S.PRE_FIELD_01
    AND EXISTS (SELECT 1 FROM INTF_CUSTOMER_INVALID_HIS H
    WHERE H.INVALID_ID = P_INVALID_ID
    AND H.CUSTOMER_CODE = S.CUSTOMER_CODE
    AND H.SOURCE_CODE = S.SOURCE_CODE
    AND H.INVALID_TYPE = S.INVALID_TYPE
    AND ((H.DEPT_CODE IS NULL AND S.DEPT_CODE IS NULL)
    OR H.DEPT_CODE = S.DEPT_CODE)
    AND ((H.CUSTOMER_OU_ID IS NULL AND S.CUSTOMER_OU_ID IS NULL)
    OR H.CUSTOMER_OU_ID = S.CUSTOMER_OU_ID)
    );
    SELECT count(0)
      INTO V_COUNT
      FROM T_CUSTOMER_HEADER H
     WHERE H.Customer_Code = P_CUSTOMER_CODE
    --and H.Dept_Id IS NOT NULL
    ;
    IF 0 = V_COUNT THEN
      P_RESULT  := 'Y';
      P_MESSAGE := NULL;
      --P_MESSAGE := 'CIMS客户头表不存在';
      /*UPDATE INTF_CUSTOMER_INVALID_HIS T
         SET T.Can_Invalid = P_RESULT, T.REASON_DESC = P_MESSAGE
       WHERE T.INVALID_ID = P_INVALID_ID;
      COMMIT;*/
      RETURN;
    END IF;
    /*
       ①  检查余款：检查客户是否存在可提货金额（不为零）。如果有，则反馈不能失效，
       原因：该客户在CIMS中存在可提货金额，无法进行客户失效。
    ② 未结业务：检查客户在OU下是否存在未引入ERP的销售单（检查范围为销售单表中OU_ID is not null），
    或者ERP中存在不是最终状态的销售单。如果有，则反馈不能失效，
    原因：该客户在CIMS中存在未结算完成的销售单，无法进行客户失效
    */
    --
    BEGIN
      /*
          客户头失效：按所有主体检查条件①校验；按客户对应OU检查条件②校验。
      客户事业部失效：按事业部编码所在主体检查条件①校验；按客户对应OU检查条件②校验。
      客户OU失效：按传入的客户、OU进行检查条件②校验
      */
      if '001' = P_INVALID_TYPE OR '002' = P_INVALID_TYPE then
        --可提货金额：到款金额-销售金额+铺底额度+临时额度-锁定到款金额 
        --折让金额-核销折让金额+冻结扣率折让金额-锁定扣率折让金额
        BEGIN
          with m as
           (select be.entity_id,
                   be.entity_name,
                   be.entity_code,
                   t.credit_group_id,
                   cg.credit_group_name
                   || '(' || t.account_code || '/' || a.sales_center_name || ')' as credit_group_name,
                   sum(t.received_amount - t.sales_amount +
                       t.delaypay_amount + t.temp_delaypay_amount -
                       t.lock_received_amount + t.discount_amount +
                       t.freeze_discount_amount - t.lock_discount_amount -
                       t.applied_discount_amount
                       + t.mpay_stream_amount - t.mpay_cash_amount) as delivery_amount,
                   sum(t.received_amount - t.sales_amount) as account_balance,
                   sum(t.discount_amount - t.applied_discount_amount) as allowance_balance
              from t_sales_account_amount t,
                   v_bd_entity            be,
                   t_credit_group         cg,
                   t_customer_account     a
             where t.entity_id = be.entity_id
               and t.credit_group_id = cg.credit_group_id
               and t.customer_code = P_CUSTOMER_CODE
               and a.account_id = t.account_id
               and ('001' = P_INVALID_TYPE OR
                   ('002' = P_INVALID_TYPE AND EXISTS
                    (SELECT 1
                        FROM UP_ORG_UNIT U
                       WHERE U.CODE = P_DEPT_CODE
                         AND U.ENTITY_ID = be.ENTITY_ID)
                   --
                   ))
             group by be.entity_id,
                      be.entity_name,
                      be.entity_code,
                      t.credit_group_id,
                      cg.credit_group_name
                      || '(' || t.account_code || '/' || a.sales_center_name || ')'
            having 0 <> sum(t.received_amount - t.sales_amount + t.delaypay_amount
            --
            +t.temp_delaypay_amount - t.lock_received_amount + t.discount_amount
            --
            +t.freeze_discount_amount - t.lock_discount_amount - t.applied_discount_amount
            + t.mpay_stream_amount -t.mpay_cash_amount) OR 0 <> sum(t.received_amount - t.sales_amount) OR 0 <> sum(t.discount_amount - t.applied_discount_amount)
            --
            ),
          m2 as
           (select m.entity_name,
                   listagg(m.credit_group_name, ',') WITHIN GROUP(order by m.credit_group_id) as credit_group_name,
                   '可提货金额' as amount_name,
                   listagg(m.delivery_amount, ',') WITHIN GROUP(order by m.credit_group_id) as delivery_amount
              from m
             where 0 <> m.delivery_amount
             group by m.entity_name
            union all
            select m.entity_name,
                   listagg(m.credit_group_name, ',') WITHIN GROUP(order by m.credit_group_id) as credit_group_name,
                   '到款余额' as amount_name,
                   listagg(m.account_balance, ',') WITHIN GROUP(order by m.credit_group_id) as delivery_amount
              from m
             where 0 = m.delivery_amount
               and 0 <> m.account_balance
             group by m.entity_name
            union all
            select m.entity_name,
                   listagg(m.credit_group_name, ',') WITHIN GROUP(order by m.credit_group_id) as credit_group_name,
                   '折让余额' as amount_name,
                   listagg(m.allowance_balance, ',') WITHIN GROUP(order by m.credit_group_id) as delivery_amount
              from m
             where 0 = m.delivery_amount
               and 0 = m.account_balance
               and 0 <> m.allowance_balance
             group by m.entity_name)
          select listagg(m2.entity_name || ',额度组:' || m2.credit_group_name || ',' ||
                          m2.amount_name || ':' || m2.delivery_amount,
                          chr(10))
                 --
                  WITHIN GROUP(order by m2.entity_name, m2.amount_name)
            INTO V_MESSAGE1
            from m2 -- where 10 >= rownum
          ;
        EXCEPTION
          WHEN VALUE_ERROR THEN
            V_MESSAGE1 := '查询可提货金额SQL异常' || SQLERRM;
          WHEN OTHERS THEN
            V_MESSAGE1 := '查询可提货金额SQL异常' || SQLERRM;
        END;
      end if;
      BEGIN
        with ou as
         (select min(nvl(t.entity_id, 0)) as min_entity_id,
                 max(nvl(t.entity_id, 0)) as max_entity_id,
                 count(distinct nvl(t.entity_id, 0)) as cnt_entity_id,
                 t.operating_unit,
                 t.operating_unit_code,
                 t.operating_unit_name
            from t_inv_organization t
           group by t.operating_unit,
                    t.operating_unit_code,
                    t.operating_unit_name),
        m as
         (select rank() over(partition by be.entity_id, order_cims.erp_ou_name order by order_cims.so_header_id) as rn,
                 be.entity_id,
                 be.entity_name,
                 be.entity_code,
                 cus_ou.customer_code,
                 order_cims.erp_ou_name,
                 order_cims.so_num
            from t_so_header      order_cims,
                 t_so_type_extend order_type_cims,
                 t_customer_ou    cus_ou,
                 v_bd_entity      be
           where order_cims.bill_type_id = order_type_cims.bill_type_id
             and order_type_cims.to_erp_flag = 'Y'
             and cus_ou.customer_id = order_cims.customer_id
             and cus_ou.customer_code = order_cims.customer_code
             and to_number(cus_ou.erpou) = order_cims.erp_ou_id
             and 'Active' = cus_ou.active_flag
             and order_cims.entity_id = be.entity_id
             and order_type_cims.entity_id = be.entity_id
             and order_cims.customer_code = P_CUSTOMER_CODE
             AND (V_LAST_MANUAL_DATE IS NULL OR order_cims.Creation_Date >= V_LAST_MANUAL_DATE)
             and ('001' = P_INVALID_TYPE OR
                 ('002' = P_INVALID_TYPE AND EXISTS
                  (SELECT 1
                      FROM UP_ORG_UNIT U
                     WHERE U.CODE = P_DEPT_CODE
                       AND U.ENTITY_ID = be.ENTITY_ID)
                 --
                 ) OR ('003' = P_INVALID_TYPE AND
                 P_CUSTOMER_OU_ID = cus_ou.erpou))
             AND EXISTS
           (SELECT 1
                    FROM ou
                   WHERE ou.operating_unit = order_cims.erp_ou_id --cus_ou.erpou
                     AND be.entity_id =
                         DECODE(ou.min_entity_id,
                                0,
                                decode(ou.max_entity_id,
                                       0,
                                       null,
                                       ou.max_entity_id),
                                ou.min_entity_id)
                  --
                  )
             and exists
           (select 1
                    from t_so_line l
                   where l.so_header_id = order_cims.so_header_id
                     and l.item_qty > 0)
             and ( ('NC' = PKG_BD.F_GET_PARAMETER_VALUE('PUB_FIN_SYS',order_cims.Entity_Id,NULL,NULL) AND NOT('Y' = order_cims.Settle_Flag OR ('12' = order_cims.So_Status AND order_cims.Settle_Date IS NOT NULL)) )
             or ('ERP' = PKG_BD.F_GET_PARAMETER_VALUE('PUB_FIN_SYS',order_cims.Entity_Id,NULL,NULL) AND NOT exists
           (select 1
                    from apps.oe_order_headers_all@mdims2mderp a
                   where a.order_number = order_cims.so_num
                     and a.org_id = order_cims.erp_ou_id
                     and a.flow_status_code in ('BOOKED', 'CLOSED')) )
                     )
          --
          ),
        m2 as
         (select m.entity_name,
                 m.erp_ou_name,
                 wm_concat((case
                             when m.rn <= 5 then
                              m.so_num
                             else
                              null
                           end)) as so_nums,
                 count(distinct m.so_num) as so_num_cnt
            from m
           group by m.entity_name, m.erp_ou_name)
        
        select listagg(m2.entity_name || ',' || m2.erp_ou_name || '共' ||
                        m2.so_num_cnt || '笔，' || m2.so_nums || (case
                          when m2.so_num_cnt <= 5 then
                           ''
                          else
                           '......'
                        end),
                        chr(10))
               --
                WITHIN GROUP(order by m2.entity_name, m2.erp_ou_name) as msg
          INTO V_MESSAGE2
          from m2;
      EXCEPTION
        WHEN VALUE_ERROR THEN
          V_MESSAGE2 := '查询未结单据SQL异常' || SQLERRM;
        WHEN OTHERS THEN
          V_MESSAGE2 := '查询未结单据SQL异常' || SQLERRM;
      END;
      --VALUE_ERROR
      /*
      核销关系对应，收款（收款单） 核销 发票（销售单，退款单等）
 select * from cims.intf_ar_writeoff where INTF_STATUS='E' and CANCEL_FLAG='N' and customer_number='';
*/
      /*BEGIN
        with ou as
         (select min(nvl(t.entity_id, 0)) as min_entity_id,
                 max(nvl(t.entity_id, 0)) as max_entity_id,
                 count(distinct nvl(t.entity_id, 0)) as cnt_entity_id,
                 t.operating_unit,
                 t.operating_unit_code,
                 t.operating_unit_name
            from t_inv_organization t
           group by t.operating_unit,
                    t.operating_unit_code,
                    t.operating_unit_name),
        m as
         (select rank() over(partition by be.entity_id, ou.operating_unit_name order by wo.trx_id) as rn,
                 be.entity_id,
                 be.entity_name,
                 be.entity_code,
                 cus_ou.customer_code,
                 ou.operating_unit_name as erp_ou_name,
                 wo.receipt_number as so_num
            from intf_ar_writeoff      wo,
                 t_customer_ou    cus_ou,
                 v_bd_entity      be,
                 ou
           where cus_ou.customer_id = wo.customer_id
             and cus_ou.customer_code = wo.customer_number
             and to_number(cus_ou.erpou) = wo.org_id
             and 'Active' = cus_ou.active_flag
             and wo.customer_number = P_CUSTOMER_CODE
             AND (V_LAST_MANUAL_DATE IS NULL
             OR (wo.return_date is null and wo.post_date is null)
             OR wo.return_date >= V_LAST_MANUAL_DATE
             )
             and wo.INTF_STATUS in ('N','E') and wo.CANCEL_FLAG='N'
             and ('001' = P_INVALID_TYPE OR
                 ('002' = P_INVALID_TYPE AND EXISTS
                  (SELECT 1
                      FROM UP_ORG_UNIT U
                     WHERE U.CODE = P_DEPT_CODE
                       AND U.ENTITY_ID = be.ENTITY_ID)
                 --
                 ) OR ('003' = P_INVALID_TYPE AND
                 P_CUSTOMER_OU_ID = cus_ou.erpou))
                 
             AND ou.operating_unit = wo.org_id
                     AND be.entity_id =
                         DECODE(ou.min_entity_id,
                                0,
                                decode(ou.max_entity_id,
                                       0,
                                       null,
                                       ou.max_entity_id),
                                ou.min_entity_id)
          --
          ),
        m2 as
         (select m.entity_name,
                 m.erp_ou_name,
                 wm_concat((case
                             when m.rn <= 5 then
                              m.so_num
                             else
                              null
                           end)) as so_nums,
                 count(distinct m.so_num) as so_num_cnt
            from m
           group by m.entity_name, m.erp_ou_name)
        
        select listagg(m2.entity_name || ',' || m2.erp_ou_name || '共' ||
                        m2.so_num_cnt || '笔，' || m2.so_nums || (case
                          when m2.so_num_cnt <= 5 then
                           ''
                          else
                           '......'
                        end),
                        chr(10))
               --
                WITHIN GROUP(order by m2.entity_name, m2.erp_ou_name) as msg
          INTO V_MESSAGE3
          from m2;
      EXCEPTION
        WHEN VALUE_ERROR THEN
          V_MESSAGE3 := '查询异常收款核销发票关系SQL异常' || SQLERRM;
        WHEN OTHERS THEN
          V_MESSAGE3 := '查询异常收款核销发票关系SQL异常' || SQLERRM;
      END;*/
      /*核销关系对应  负数发票（折让单，退货单等）核销发票（销售单，退款单等）
select * from cims.intf_ar_writeoff_inv where INTF_STATUS='E' and CANCEL_FLAG='N' and  customer_number='';
*/
      /*BEGIN
        with ou as
         (select min(nvl(t.entity_id, 0)) as min_entity_id,
                 max(nvl(t.entity_id, 0)) as max_entity_id,
                 count(distinct nvl(t.entity_id, 0)) as cnt_entity_id,
                 t.operating_unit,
                 t.operating_unit_code,
                 t.operating_unit_name
            from t_inv_organization t
           group by t.operating_unit,
                    t.operating_unit_code,
                    t.operating_unit_name),
        m as
         (select rank() over(partition by be.entity_id, ou.operating_unit_name order by wo.trx_id) as rn,
                 be.entity_id,
                 be.entity_name,
                 be.entity_code,
                 cus_ou.customer_code,
                 ou.operating_unit_name as erp_ou_name,
                 wo.cm_trx_number || '(' || wo.invoice_trx_number || ')' as so_num
            from intf_ar_writeoff_inv      wo,
                 t_customer_ou    cus_ou,
                 v_bd_entity      be,
                 ou
           where cus_ou.customer_id = wo.customer_id
             and cus_ou.customer_code = wo.customer_number
             and to_number(cus_ou.erpou) = wo.org_id
             and 'Active' = cus_ou.active_flag
             and wo.customer_number = P_CUSTOMER_CODE
             AND (V_LAST_MANUAL_DATE IS NULL
             OR (wo.return_date is null and wo.post_date is null)
             OR wo.return_date >= V_LAST_MANUAL_DATE
             )
             and wo.INTF_STATUS in ('N','E') and wo.CANCEL_FLAG='N'
             and ('001' = P_INVALID_TYPE OR
                 ('002' = P_INVALID_TYPE AND EXISTS
                  (SELECT 1
                      FROM UP_ORG_UNIT U
                     WHERE U.CODE = P_DEPT_CODE
                       AND U.ENTITY_ID = be.ENTITY_ID)
                 --
                 ) OR ('003' = P_INVALID_TYPE AND
                 P_CUSTOMER_OU_ID = cus_ou.erpou))
                 
             AND ou.operating_unit = wo.org_id
                     AND be.entity_id =
                         DECODE(ou.min_entity_id,
                                0,
                                decode(ou.max_entity_id,
                                       0,
                                       null,
                                       ou.max_entity_id),
                                ou.min_entity_id)
          --
          ),
        m2 as
         (select m.entity_name,
                 m.erp_ou_name,
                 wm_concat((case
                             when m.rn <= 5 then
                              m.so_num
                             else
                              null
                           end)) as so_nums,
                 count(distinct m.so_num) as so_num_cnt
            from m
           group by m.entity_name, m.erp_ou_name)
        
        select listagg(m2.entity_name || ',' || m2.erp_ou_name || '共' ||
                        m2.so_num_cnt || '笔，' || m2.so_nums || (case
                          when m2.so_num_cnt <= 5 then
                           ''
                          else
                           '......'
                        end),
                        chr(10))
               --
                WITHIN GROUP(order by m2.entity_name, m2.erp_ou_name) as msg
          INTO V_MESSAGE4
          from m2;
      EXCEPTION
        WHEN VALUE_ERROR THEN
          V_MESSAGE4 := '查询异常负数发票核销发票关系SQL异常' || SQLERRM;
        WHEN OTHERS THEN
          V_MESSAGE4 := '查询异常负数发票核销发票关系SQL异常' || SQLERRM;
      END;
      */
    
      IF V_MESSAGE1 IS NULL AND V_MESSAGE2 IS NULL
        AND V_MESSAGE3 IS NULL
        AND V_MESSAGE4 IS NULL THEN
        P_RESULT  := 'Y';
        P_MESSAGE := null;
      ELSE
        /*
           ①  检查余款： 原因：该客户在CIMS中存在可提货金额，无法进行客户失效。
        ② 未结业务：原因：该客户在CIMS中存在未结算完成的销售单，无法进行客户失效
        */
        P_RESULT  := 'N';
        P_MESSAGE := '';
        IF V_MESSAGE1 IS NOT NULL THEN
          P_MESSAGE := '存在可提货金额、到款余额、折让余额，无法进行失效。额度组如下：';
          P_MESSAGE := P_MESSAGE || chr(10);
          P_MESSAGE := P_MESSAGE || V_MESSAGE1;
        END IF;
        IF V_MESSAGE2 IS NOT NULL THEN
          IF P_MESSAGE IS NOT NULL THEN
            P_MESSAGE := P_MESSAGE || chr(10);
          END IF;
          P_MESSAGE := P_MESSAGE || '存在未结算完成的销售单，无法进行失效。';
          P_MESSAGE := P_MESSAGE || chr(10);
          P_MESSAGE := P_MESSAGE || V_MESSAGE2;
        END IF;
        IF V_MESSAGE3 IS NOT NULL THEN
          IF P_MESSAGE IS NOT NULL THEN
            P_MESSAGE := P_MESSAGE || chr(10);
          END IF;
          P_MESSAGE := P_MESSAGE || '存在异常收款核销发票关系，无法进行失效。';
          P_MESSAGE := P_MESSAGE || chr(10);
          P_MESSAGE := P_MESSAGE || V_MESSAGE3;
        END IF;
        IF V_MESSAGE4 IS NOT NULL THEN
          IF P_MESSAGE IS NOT NULL THEN
            P_MESSAGE := P_MESSAGE || chr(10);
          END IF;
          P_MESSAGE := P_MESSAGE || '存在异常负数发票（折让单，退货单等）核销发票（销售单，退款单等）关系，无法进行失效。';
          P_MESSAGE := P_MESSAGE || chr(10);
          P_MESSAGE := P_MESSAGE || V_MESSAGE4;
        END IF;
      END IF;
    
      /*BEGIN
        UPDATE INTF_CUSTOMER_INVALID_HIS T
           SET T.Can_Invalid = P_RESULT, T.REASON_DESC = P_MESSAGE
         WHERE T.INVALID_ID = P_INVALID_ID;
        COMMIT;
      EXCEPTION
        WHEN OTHERS THEN
          NULL;
      END;*/
    EXCEPTION
      WHEN OTHERS THEN
        P_RESULT  := 'N';
        P_MESSAGE := '客户失效校验数据库层异常：' || SQLERRM;
        /*UPDATE INTF_CUSTOMER_INVALID_HIS T
           SET T.Can_Invalid = P_RESULT, T.REASON_DESC = P_MESSAGE
         WHERE T.INVALID_ID = P_INVALID_ID;
        COMMIT;*/
    END;
  END;

  FUNCTION F_CUSTORG_CHECK_CANVALID(P_CUSTOMER_CODE      in varchar2, --客户编码
                                    P_DEPT_CODE          in varchar2, --事业部编码
                                    P_SALES_CENTER_ID    in number, --中心ID
                                    P_SALES_CENTER_CODE  in varchar2, --中心编码
                                    P_CUST_ORG_ID        in number, --客户中心关系ID
                                    P_SIEBEL_CUST_ORG_ID in varchar2, --客户中心关系主数据ID
                                    P_ACCOUNT_ID         in number --账户ID
                                    ) return VARCHAR2 IS
    V_MESSAGE1 VARCHAR2(4000);
    V_MESSAGE2 VARCHAR2(4000);
    V_MESSAGE3 VARCHAR2(4000);
    V_MESSAGE4 VARCHAR2(4000);
    P_MESSAGE  VARCHAR2(4000);
  BEGIN
    P_MESSAGE := NULL;
    /*
       ①  检查余款：检查客户是否存在可提货金额（不为零）。如果有，则反馈不能失效，
       原因：该客户在CIMS中存在可提货金额，无法进行客户失效。
    ② 未结业务：检查客户在OU下是否存在未引入ERP的销售单（检查范围为销售单表中OU_ID is not null），
    或者ERP中存在不是最终状态的销售单。如果有，则反馈不能失效，
    原因：该客户在CIMS中存在未结算完成的销售单，无法进行客户失效
    */
    /*
        客户头失效：按所有主体检查条件①校验；按客户对应OU检查条件②校验。
    客户事业部失效：按事业部编码所在主体检查条件①校验；按客户对应OU检查条件②校验。
    客户OU失效：按传入的客户、OU进行检查条件②校验
    */
    --可提货金额：到款金额-销售金额+铺底额度+临时额度-锁定到款金额 
    --折让金额-核销折让金额+冻结扣率折让金额-锁定扣率折让金额
    BEGIN
      BEGIN
        with m as
         (select be.entity_id,
                 be.entity_name,
                 be.entity_code,
                 t.credit_group_id,
                 cg.credit_group_name,
                 A.ACCOUNT_ID,
                 A.ACCOUNT_CODE,
                 sum(t.received_amount - t.sales_amount + t.delaypay_amount +
                     t.temp_delaypay_amount - t.lock_received_amount +
                     t.discount_amount + t.freeze_discount_amount -
                     t.lock_discount_amount - t.applied_discount_amount
                     + t.mpay_stream_amount -t.mpay_cash_amount) as delivery_amount,
                 sum(t.received_amount - t.sales_amount) as account_balance,
                 sum(t.discount_amount - t.applied_discount_amount) as allowance_balance
            from t_sales_account_amount      t,
                 v_bd_entity                 be,
                 t_credit_group              cg,
                 t_customer_org              co,
                 t_customer_account          a
                 --,t_customer_acc_org_relation ar
           where t.entity_id = be.entity_id
             --AND co.entity_id = be.entity_id
             AND a.entity_id = be.entity_id
             and t.credit_group_id = cg.credit_group_id
             --AND A.ACCOUNT_ID = AR.ACCOUNT_ID
             AND A.ACCOUNT_ID = T.ACCOUNT_ID
             AND A.CUSTOMER_ORG_ID = CO.CUSTOMER_ORG_ID
             --AND CO.CUSTOMER_ORG_ID = AR.CUSTOMER_ORG_ID
             --AND CO.ACTIVE_FLAG <> 'Inactive'
             AND 'Y' = A.ACTIVE_FLAG
                --AND ('1' = A.ACCOUNT_STATUS OR '-1' = A.ACCOUNT_STATUS)
             and (P_DEPT_CODE IS NULL OR EXISTS
                  (SELECT 1
                     FROM UP_ORG_UNIT U
                    WHERE U.CODE = P_DEPT_CODE
                      AND U.ENTITY_ID = be.ENTITY_ID))
             AND ((P_CUSTOMER_CODE IS NOT NULL AND
                 T.CUSTOMER_CODE = P_CUSTOMER_CODE) OR
                 (P_CUSTOMER_CODE IS NULL AND
                 T.CUSTOMER_ID = A.CUSTOMER_ID))
             and a.sales_center_id =
                 NVL(P_SALES_CENTER_ID, a.sales_center_id)
             and a.sales_center_code =
                 NVL(P_SALES_CENTER_CODE, a.sales_center_code)
             and a.customer_org_id = NVL(P_CUST_ORG_ID, a.customer_org_id)
             and co.SIEBEL_ORG_ID =
                 NVL(P_SIEBEL_CUST_ORG_ID, co.SIEBEL_ORG_ID)
             /*AND ((P_CUSTOMER_CODE IS NOT NULL AND
                 T.CUSTOMER_CODE = P_CUSTOMER_CODE) OR
                 (P_CUSTOMER_CODE IS NULL AND
                 T.CUSTOMER_ID = CO.CUSTOMER_ID))
             and co.sales_center_id =
                 NVL(P_SALES_CENTER_ID, co.sales_center_id)
             and co.sales_center_code =
                 NVL(P_SALES_CENTER_CODE, co.sales_center_code)
             and co.customer_org_id = NVL(P_CUST_ORG_ID, co.customer_org_id)
             and co.SIEBEL_ORG_ID =
                 NVL(P_SIEBEL_CUST_ORG_ID, co.SIEBEL_ORG_ID)*/
             and A.ACCOUNT_ID = NVL(P_ACCOUNT_ID, A.ACCOUNT_ID)
           group by be.entity_id,
                    be.entity_name,
                    be.entity_code,
                    t.credit_group_id,
                    cg.credit_group_name,
                    A.ACCOUNT_ID,
                    A.ACCOUNT_CODE
          having 0 <> sum(t.received_amount - t.sales_amount + t.delaypay_amount
          --
          +t.temp_delaypay_amount - t.lock_received_amount + t.discount_amount
          --
          +t.freeze_discount_amount - t.lock_discount_amount - t.applied_discount_amount
          + t.mpay_stream_amount -t.mpay_cash_amount) OR 0 <> sum(t.received_amount - t.sales_amount) OR 0 <> sum(t.discount_amount - t.applied_discount_amount)
          --
          ),
        m2 as
         (select m.entity_name,
                 listagg(M.ACCOUNT_CODE || '_' || m.credit_group_name, ',') WITHIN GROUP(order by m.credit_group_id, M.ACCOUNT_ID) as credit_group_name,
                 '可提货金额' as amount_name,
                 listagg(m.delivery_amount, ',') WITHIN GROUP(order by m.credit_group_id, M.ACCOUNT_ID) as delivery_amount
            from m
           where 0 <> m.delivery_amount
           group by m.entity_name
          union all
          select m.entity_name,
                 listagg(M.ACCOUNT_CODE || '_' || m.credit_group_name, ',') WITHIN GROUP(order by m.credit_group_id, M.ACCOUNT_ID) as credit_group_name,
                 '到款余额' as amount_name,
                 listagg(m.account_balance, ',') WITHIN GROUP(order by m.credit_group_id) as delivery_amount
            from m
           where 0 = m.delivery_amount
             and 0 <> m.account_balance
           group by m.entity_name
          union all
          select m.entity_name,
                 listagg(M.ACCOUNT_CODE || '_' || m.credit_group_name, ',') WITHIN GROUP(order by m.credit_group_id, M.ACCOUNT_ID) as credit_group_name,
                 '折让余额' as amount_name,
                 listagg(m.allowance_balance, ',') WITHIN GROUP(order by m.credit_group_id) as delivery_amount
            from m
           where 0 = m.delivery_amount
             and 0 = m.account_balance
             and 0 <> m.allowance_balance
           group by m.entity_name)
        select listagg(m2.entity_name || ',账户_额度组:' || m2.credit_group_name || ',' ||
                        m2.amount_name || ':' || m2.delivery_amount,
                        chr(10))
               --
                WITHIN GROUP(order by m2.entity_name, m2.amount_name)
          INTO V_MESSAGE1
          from m2 -- where 10 >= rownum
        ;
      EXCEPTION
        WHEN VALUE_ERROR THEN
          V_MESSAGE1 := '查询可提货金额SQL异常' || SQLERRM;
        WHEN OTHERS THEN
          V_MESSAGE1 := '查询可提货金额SQL异常' || SQLERRM;
      END;
      BEGIN
        with ou as
         (select min(nvl(t.entity_id, 0)) as min_entity_id,
                 max(nvl(t.entity_id, 0)) as max_entity_id,
                 count(distinct nvl(t.entity_id, 0)) as cnt_entity_id,
                 t.operating_unit,
                 t.operating_unit_code,
                 t.operating_unit_name
            from t_inv_organization t
           group by t.operating_unit,
                    t.operating_unit_code,
                    t.operating_unit_name),
        m as
         (select rank() over(partition by be.entity_id, A.ACCOUNT_ID, A.ACCOUNT_CODE, order_cims.erp_ou_name order by order_cims.so_header_id) as rn,
                 be.entity_id,
                 be.entity_name,
                 be.entity_code,
                 cus_ou.customer_code,
                 order_cims.erp_ou_name,
                 A.ACCOUNT_ID,
                 A.ACCOUNT_CODE,
                 order_cims.so_num
            from t_so_header                 order_cims,
                 t_so_type_extend            order_type_cims,
                 t_customer_ou               cus_ou,
                 v_bd_entity                 be,
                 t_customer_org              co,
                 t_customer_account          a,
                 t_customer_acc_org_relation ar
           where order_cims.bill_type_id = order_type_cims.bill_type_id
             and order_type_cims.to_erp_flag = 'Y'
             and cus_ou.customer_id = order_cims.customer_id
             and cus_ou.customer_code = order_cims.customer_code
             and to_number(cus_ou.erpou) = order_cims.erp_ou_id
             and 'Active' = cus_ou.active_flag
             and order_cims.entity_id = be.entity_id
             and order_type_cims.entity_id = be.entity_id
             AND co.entity_id = be.entity_id
             AND a.entity_id = be.entity_id
             AND A.ACCOUNT_ID = AR.ACCOUNT_ID
             AND A.ACCOUNT_ID = order_cims.ACCOUNT_ID
             AND CO.CUSTOMER_ORG_ID = AR.CUSTOMER_ORG_ID
             AND CO.ACTIVE_FLAG <> 'Inactive'
             AND 'Y' = A.ACTIVE_FLAG
                --AND ('1' = A.ACCOUNT_STATUS OR '-1' = A.ACCOUNT_STATUS)
             and (P_DEPT_CODE IS NULL OR EXISTS
                  (SELECT 1
                     FROM UP_ORG_UNIT U
                    WHERE U.CODE = P_DEPT_CODE
                      AND U.ENTITY_ID = be.ENTITY_ID))
             AND ((P_CUSTOMER_CODE IS NOT NULL AND
                 order_cims.CUSTOMER_CODE = P_CUSTOMER_CODE) OR
                 (P_CUSTOMER_CODE IS NULL AND
                 order_cims.CUSTOMER_ID = CO.CUSTOMER_ID))
             and co.sales_center_id =
                 NVL(P_SALES_CENTER_ID, co.sales_center_id)
             and co.sales_center_code =
                 NVL(P_SALES_CENTER_CODE, co.sales_center_code)
             and co.customer_org_id = NVL(P_CUST_ORG_ID, co.customer_org_id)
             and co.SIEBEL_ORG_ID =
                 NVL(P_SIEBEL_CUST_ORG_ID, co.SIEBEL_ORG_ID)
             AND A.ACCOUNT_ID = NVL(P_ACCOUNT_ID, A.ACCOUNT_ID)
             AND order_cims.Creation_Date >= NVL(
             (
             --取打开手工开关的最新时间
    SELECT MAX(S.LAST_UPDATE_DATE) FROM INTF_CUSTOMER_INVALID_HIS S
    WHERE 'Y' = S.PRE_FIELD_01
    AND order_cims.customer_code = S.CUSTOMER_CODE
             )
             ,(-1+order_cims.Creation_Date))--不能加1而是减1，因为要确保取不到开关时间时通过，取到时直接比较就可以了
             AND EXISTS
           (SELECT 1
                    FROM ou
                   WHERE ou.operating_unit = order_cims.erp_ou_id --cus_ou.erpou
                     AND be.entity_id =
                         DECODE(ou.min_entity_id,
                                0,
                                decode(ou.max_entity_id,
                                       0,
                                       null,
                                       ou.max_entity_id),
                                ou.min_entity_id)
                  --
                  )
             and exists
           (select 1
                    from t_so_line l
                   where l.so_header_id = order_cims.so_header_id
                     and l.item_qty > 0)
             and ( ('NC' = PKG_BD.F_GET_PARAMETER_VALUE('PUB_FIN_SYS',order_cims.Entity_Id,NULL,NULL) AND NOT('Y' = order_cims.Settle_Flag OR ('12' = order_cims.So_Status AND order_cims.Settle_Date IS NOT NULL)) )
             or ('ERP' = PKG_BD.F_GET_PARAMETER_VALUE('PUB_FIN_SYS',order_cims.Entity_Id,NULL,NULL) AND NOT exists
           (select 1
                    from apps.oe_order_headers_all@mdims2mderp a
                   where a.order_number = order_cims.so_num
                     and a.org_id = order_cims.erp_ou_id
                     and a.flow_status_code in ('BOOKED', 'CLOSED')) )
                     )
          --
          ),
        m2 as
         (select m.entity_name,
                 m.erp_ou_name,
                 M.ACCOUNT_ID,
                 M.ACCOUNT_CODE,
                 wm_concat((case
                             when m.rn <= 5 then
                              m.so_num
                             else
                              null
                           end)) as so_nums,
                 count(distinct m.so_num) as so_num_cnt
            from m
           group by m.entity_name,
                    m.erp_ou_name,
                    M.ACCOUNT_ID,
                    M.ACCOUNT_CODE)
        
        select listagg(m2.entity_name || ',' || m2.ACCOUNT_CODE || ',' ||
                        m2.erp_ou_name || '共' || m2.so_num_cnt || '笔，' ||
                        m2.so_nums || (case
                          when m2.so_num_cnt <= 5 then
                           ''
                          else
                           '......'
                        end),
                        chr(10))
               --
                WITHIN GROUP(order by m2.entity_name, m2.erp_ou_name, M2.ACCOUNT_CODE) as msg
          INTO V_MESSAGE2
          from m2;
      EXCEPTION
        WHEN VALUE_ERROR THEN
          V_MESSAGE2 := '查询未结单据SQL异常' || SQLERRM;
        WHEN OTHERS THEN
          V_MESSAGE2 := '查询未结单据SQL异常' || SQLERRM;
      END;
      --VALUE_ERROR
      /*
      核销关系对应，收款（收款单） 核销 发票（销售单，退款单等）
 select * from cims.intf_ar_writeoff where INTF_STATUS='E' and CANCEL_FLAG='N' and customer_number='';
*//*
      BEGIN
        with ou as
         (select min(nvl(t.entity_id, 0)) as min_entity_id,
                 max(nvl(t.entity_id, 0)) as max_entity_id,
                 count(distinct nvl(t.entity_id, 0)) as cnt_entity_id,
                 t.operating_unit,
                 t.operating_unit_code,
                 t.operating_unit_name
            from t_inv_organization t
           group by t.operating_unit,
                    t.operating_unit_code,
                    t.operating_unit_name),
        m as
         (select rank() over(partition by be.entity_id, ou.operating_unit_name order by wo.trx_id) as rn,
                 be.entity_id,
                 be.entity_name,
                 be.entity_code,
                 cus_ou.customer_code,
                 ou.operating_unit_name as erp_ou_name,
                 wo.receipt_number as so_num,
                 --wo.cm_trx_number || '(' || wo.invoice_trx_number || ')' as so_num
                 A.ACCOUNT_ID,
                 A.ACCOUNT_CODE
            from ou,intf_ar_writeoff   wo,
                 t_customer_ou               cus_ou,
                 v_bd_entity                 be,
                 t_customer_org              co,
                 t_customer_account          a,
                 t_customer_acc_org_relation ar
           where cus_ou.customer_id = wo.customer_id
             and cus_ou.customer_code = wo.customer_number
             
             and to_number(cus_ou.erpou) = wo.org_id
             and 'Active' = cus_ou.active_flag
             
             AND co.entity_id = be.entity_id
             AND a.entity_id = be.entity_id
             AND A.ACCOUNT_ID = AR.ACCOUNT_ID
             --AND A.ACCOUNT_ID = order_cims.ACCOUNT_ID
             AND CO.CUSTOMER_ORG_ID = AR.CUSTOMER_ORG_ID
             AND CO.ACTIVE_FLAG <> 'Inactive'
             AND 'Y' = A.ACTIVE_FLAG
                --AND ('1' = A.ACCOUNT_STATUS OR '-1' = A.ACCOUNT_STATUS)
             and (P_DEPT_CODE IS NULL OR EXISTS
                  (SELECT 1
                     FROM UP_ORG_UNIT U
                    WHERE U.CODE = P_DEPT_CODE
                      AND U.ENTITY_ID = be.ENTITY_ID))
             AND ((P_CUSTOMER_CODE IS NOT NULL AND
                 wo.customer_number = P_CUSTOMER_CODE) OR
                 (P_CUSTOMER_CODE IS NULL AND
                 wo.customer_id = CO.CUSTOMER_ID))
             and co.sales_center_id =
                 NVL(P_SALES_CENTER_ID, co.sales_center_id)
             and co.sales_center_code =
                 NVL(P_SALES_CENTER_CODE, co.sales_center_code)
             and co.customer_org_id = NVL(P_CUST_ORG_ID, co.customer_org_id)
             and co.SIEBEL_ORG_ID =
                 NVL(P_SIEBEL_CUST_ORG_ID, co.SIEBEL_ORG_ID)
             AND A.ACCOUNT_ID = NVL(P_ACCOUNT_ID, A.ACCOUNT_ID)
             
             and wo.INTF_STATUS in ('N','E') and wo.CANCEL_FLAG='N'
             
             AND (
             (wo.return_date is null and wo.post_date is null)
             OR wo.return_date >= NVL(
             (
             --取打开手工开关的最新时间
    SELECT MAX(S.LAST_UPDATE_DATE) FROM INTF_CUSTOMER_INVALID_HIS S
    WHERE 'Y' = S.PRE_FIELD_01
    AND wo.customer_number = S.CUSTOMER_CODE
             )
             ,(-1+wo.return_date)--不能加1而是减1，因为要确保取不到开关时间时通过，取到时直接比较就可以了
             )
             )
             AND ou.operating_unit = wo.org_id
                     AND be.entity_id =
                         DECODE(ou.min_entity_id,
                                0,
                                decode(ou.max_entity_id,
                                       0,
                                       null,
                                       ou.max_entity_id),
                                ou.min_entity_id)
          --
          ),
        m2 as
         (select m.entity_name,
                 m.erp_ou_name,
                 M.ACCOUNT_ID,
                 M.ACCOUNT_CODE,
                 wm_concat((case
                             when m.rn <= 5 then
                              m.so_num
                             else
                              null
                           end)) as so_nums,
                 count(distinct m.so_num) as so_num_cnt
            from m
           group by m.entity_name,
                    m.erp_ou_name,
                    M.ACCOUNT_ID,
                    M.ACCOUNT_CODE)
        
        select listagg(m2.entity_name || ',' || m2.ACCOUNT_CODE || ',' ||
                        m2.erp_ou_name || '共' || m2.so_num_cnt || '笔，' ||
                        m2.so_nums || (case
                          when m2.so_num_cnt <= 5 then
                           ''
                          else
                           '......'
                        end),
                        chr(10))
               --
                WITHIN GROUP(order by m2.entity_name, m2.erp_ou_name, M2.ACCOUNT_CODE) as msg
          INTO V_MESSAGE3
          from m2;
      EXCEPTION
        WHEN VALUE_ERROR THEN
          V_MESSAGE3 := '查询收款核销发票关系SQL异常' || SQLERRM;
        WHEN OTHERS THEN
          V_MESSAGE3 := '查询收款核销发票关系SQL异常' || SQLERRM;
      END;*/
      /*
      核销关系对应，收款（收款单） 核销 发票（销售单，退款单等）
 select * from cims.intf_ar_writeoff where INTF_STATUS='E' and CANCEL_FLAG='N' and customer_number='';
*/
      /*BEGIN
        with ou as
         (select min(nvl(t.entity_id, 0)) as min_entity_id,
                 max(nvl(t.entity_id, 0)) as max_entity_id,
                 count(distinct nvl(t.entity_id, 0)) as cnt_entity_id,
                 t.operating_unit,
                 t.operating_unit_code,
                 t.operating_unit_name
            from t_inv_organization t
           group by t.operating_unit,
                    t.operating_unit_code,
                    t.operating_unit_name),
        m as
         (select rank() over(partition by be.entity_id, ou.operating_unit_name order by wo.trx_id) as rn,
                 be.entity_id,
                 be.entity_name,
                 be.entity_code,
                 cus_ou.customer_code,
                 ou.operating_unit_name as erp_ou_name,
                 --wo.receipt_number as so_num,
                 wo.cm_trx_number || '(' || wo.invoice_trx_number || ')' as so_num,
                 A.ACCOUNT_ID,
                 A.ACCOUNT_CODE
            from ou,intf_ar_writeoff_inv   wo,
                 t_customer_ou               cus_ou,
                 v_bd_entity                 be,
                 t_customer_org              co,
                 t_customer_account          a,
                 t_customer_acc_org_relation ar
           where cus_ou.customer_id = wo.customer_id
             and cus_ou.customer_code = wo.customer_number
             
             and to_number(cus_ou.erpou) = wo.org_id
             and 'Active' = cus_ou.active_flag
             
             AND co.entity_id = be.entity_id
             AND a.entity_id = be.entity_id
             AND A.ACCOUNT_ID = AR.ACCOUNT_ID
             --AND A.ACCOUNT_ID = order_cims.ACCOUNT_ID
             AND CO.CUSTOMER_ORG_ID = AR.CUSTOMER_ORG_ID
             AND CO.ACTIVE_FLAG <> 'Inactive'
             AND 'Y' = A.ACTIVE_FLAG
                --AND ('1' = A.ACCOUNT_STATUS OR '-1' = A.ACCOUNT_STATUS)
             and (P_DEPT_CODE IS NULL OR EXISTS
                  (SELECT 1
                     FROM UP_ORG_UNIT U
                    WHERE U.CODE = P_DEPT_CODE
                      AND U.ENTITY_ID = be.ENTITY_ID))
             AND ((P_CUSTOMER_CODE IS NOT NULL AND
                 wo.customer_number = P_CUSTOMER_CODE) OR
                 (P_CUSTOMER_CODE IS NULL AND
                 wo.customer_id = CO.CUSTOMER_ID))
             and co.sales_center_id =
                 NVL(P_SALES_CENTER_ID, co.sales_center_id)
             and co.sales_center_code =
                 NVL(P_SALES_CENTER_CODE, co.sales_center_code)
             and co.customer_org_id = NVL(P_CUST_ORG_ID, co.customer_org_id)
             and co.SIEBEL_ORG_ID =
                 NVL(P_SIEBEL_CUST_ORG_ID, co.SIEBEL_ORG_ID)
             AND A.ACCOUNT_ID = NVL(P_ACCOUNT_ID, A.ACCOUNT_ID)
             
             and wo.INTF_STATUS in ('N','E') and wo.CANCEL_FLAG='N'
             
             AND (
             (wo.return_date is null and wo.post_date is null)
             OR wo.return_date >= NVL(
             (
             --取打开手工开关的最新时间
    SELECT MAX(S.LAST_UPDATE_DATE) FROM INTF_CUSTOMER_INVALID_HIS S
    WHERE 'Y' = S.PRE_FIELD_01
    AND wo.customer_number = S.CUSTOMER_CODE
             )
             ,(-1+wo.return_date)--不能加1而是减1，因为要确保取不到开关时间时通过，取到时直接比较就可以了
             )
             )
             AND ou.operating_unit = wo.org_id
                     AND be.entity_id =
                         DECODE(ou.min_entity_id,
                                0,
                                decode(ou.max_entity_id,
                                       0,
                                       null,
                                       ou.max_entity_id),
                                ou.min_entity_id)
          --
          ),
        m2 as
         (select m.entity_name,
                 m.erp_ou_name,
                 M.ACCOUNT_ID,
                 M.ACCOUNT_CODE,
                 wm_concat((case
                             when m.rn <= 5 then
                              m.so_num
                             else
                              null
                           end)) as so_nums,
                 count(distinct m.so_num) as so_num_cnt
            from m
           group by m.entity_name,
                    m.erp_ou_name,
                    M.ACCOUNT_ID,
                    M.ACCOUNT_CODE)
        
        select listagg(m2.entity_name || ',' || m2.ACCOUNT_CODE || ',' ||
                        m2.erp_ou_name || '共' || m2.so_num_cnt || '笔，' ||
                        m2.so_nums || (case
                          when m2.so_num_cnt <= 5 then
                           ''
                          else
                           '......'
                        end),
                        chr(10))
               --
                WITHIN GROUP(order by m2.entity_name, m2.erp_ou_name, M2.ACCOUNT_CODE) as msg
          INTO V_MESSAGE4
          from m2;
      EXCEPTION
        WHEN VALUE_ERROR THEN
          V_MESSAGE4 := '查询负数发票（折让单，退货单等）核销发票（销售单，退款单等）关系SQL异常' || SQLERRM;
        WHEN OTHERS THEN
          V_MESSAGE4 := '查询负数发票（折让单，退货单等）核销发票（销售单，退款单等）关系SQL异常' || SQLERRM;
      END;*/
    
      IF V_MESSAGE1 IS NULL AND V_MESSAGE2 IS NULL
        AND V_MESSAGE3 IS NULL
        AND V_MESSAGE4 IS NULL THEN
        RETURN NULL;
      ELSE
        /*
           ①  检查余款： 原因：该客户在CIMS中存在可提货金额，无法进行客户失效。
        ② 未结业务：原因：该客户在CIMS中存在未结算完成的销售单，无法进行客户失效
        */
        P_MESSAGE := '';
        IF V_MESSAGE1 IS NOT NULL THEN
          P_MESSAGE := '存在可提货金额、到款余额、折让余额，无法进行失效。额度组如下：';
          P_MESSAGE := P_MESSAGE || chr(10);
          P_MESSAGE := P_MESSAGE || V_MESSAGE1;
        END IF;
        IF V_MESSAGE2 IS NOT NULL THEN
          IF P_MESSAGE IS NOT NULL THEN
            P_MESSAGE := P_MESSAGE || chr(10);
          END IF;
          P_MESSAGE := P_MESSAGE || '存在未结算完成的销售单，无法进行失效。';
          P_MESSAGE := P_MESSAGE || chr(10);
          P_MESSAGE := P_MESSAGE || V_MESSAGE2;
        END IF;
        IF V_MESSAGE3 IS NOT NULL THEN
          IF P_MESSAGE IS NOT NULL THEN
            P_MESSAGE := P_MESSAGE || chr(10);
          END IF;
          P_MESSAGE := P_MESSAGE || '存在异常收款核销发票关系，无法进行失效。';
          P_MESSAGE := P_MESSAGE || chr(10);
          P_MESSAGE := P_MESSAGE || V_MESSAGE3;
        END IF;
        IF V_MESSAGE4 IS NOT NULL THEN
          IF P_MESSAGE IS NOT NULL THEN
            P_MESSAGE := P_MESSAGE || chr(10);
          END IF;
          P_MESSAGE := P_MESSAGE || '存在异常负数发票（折让单，退货单等）核销发票（销售单，退款单等）关系，无法进行失效。';
          P_MESSAGE := P_MESSAGE || chr(10);
          P_MESSAGE := P_MESSAGE || V_MESSAGE4;
        END IF;
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        RETURN '客户中心失效校验数据库层异常：' || SQLERRM;
    END;
    RETURN P_MESSAGE;
  END;

  FUNCTION F_CUSTORG_CHECK_UNDO(P_CUSTOMER_CODE      in varchar2, --客户编码
                                P_DEPT_CODE          in varchar2, --事业部编码
                                P_SALES_CENTER_ID    in number, --中心ID
                                P_SALES_CENTER_CODE  in varchar2, --中心编码
                                P_CUST_ORG_ID        in number, --客户中心关系ID
                                P_SIEBEL_CUST_ORG_ID in varchar2, --客户中心关系主数据ID
                                P_ACCOUNT_ID         in number, --账户ID
                                IN_INTF_OR_BUSI      IN NUMBER DEFAULT NULL,
                                --1或空非系统初始化账户 2系统初始化 3不区分
                                IN_AMOUNT_NOCHK IN NUMBER DEFAULT NULL
                                --1不检查余额
                                ) return VARCHAR2 IS
    V_MESSAGE1 VARCHAR2(4000);
    P_MESSAGE  VARCHAR2(4000);
    V_CNT      NUMBER;
    V_CNT1     NUMBER;
    V_CNT2     NUMBER;
  BEGIN
    IF (P_CUSTOMER_CODE IS NULL AND P_DEPT_CODE IS NULL AND
       P_CUST_ORG_ID IS NULL AND P_SIEBEL_CUST_ORG_ID IS NULL) THEN
      RETURN '客户编码参数为空，事业部编码、客户中心关系ID和客户中心关系主数据ID不能为空';
    END IF;
    P_MESSAGE := NULL;
    /*
       ①  检查余款：检查客户是否存在可提货金额（不为零）。如果有，则反馈不能失效，
       原因：该客户在CIMS中存在可提货金额，无法进行客户失效。
    */
    --可提货金额：到款金额-销售金额+铺底额度+临时额度-锁定到款金额 
    --折让金额-核销折让金额+冻结扣率折让金额-锁定扣率折让金额
    BEGIN
      BEGIN
        SELECT COUNT(DECODE((SELECT COUNT(0)
                  FROM T_CREDIT_GROUP CG, T_SALES_ACCOUNT_AMOUNT T --T_SALES_ACCOUNT_MX_AMOUNT
                 WHERE T.ENTITY_ID = BE.ENTITY_ID
                   AND T.CREDIT_GROUP_ID = CG.CREDIT_GROUP_ID
                   AND A.ACCOUNT_ID = T.ACCOUNT_ID),0,0,NULL)),
               NVL(MAX((SELECT COUNT(0)
                         FROM T_CUSTOMER_ORG O
                        WHERE O.ENTITY_ID = CO.ENTITY_ID
                          AND O.CUSTOMER_ID = CO.CUSTOMER_ID
                          AND 'Inactive' <> O.ACTIVE_FLAG
                          AND O.SALES_CENTER_ID <> CO.SALES_CENTER_ID)),
                   0),
               COUNT(PKG_CUSTOMER_PUB.F_CHECK_CUST_H_UNDO_SHIP(BE.ENTITY_ID,
                                                               NULL,
                                                               A.ACCOUNT_CODE))
          INTO V_CNT, V_CNT1, V_CNT2
          FROM V_BD_ENTITY                 BE,
               T_CUSTOMER_ORG              CO,
               T_CUSTOMER_ACCOUNT          A,
               T_CUSTOMER_ACC_ORG_RELATION AR
         WHERE CO.ENTITY_ID = BE.ENTITY_ID
           AND A.ENTITY_ID = BE.ENTITY_ID
           AND A.ACCOUNT_ID = AR.ACCOUNT_ID
           AND CO.CUSTOMER_ORG_ID = AR.CUSTOMER_ORG_ID
           AND CO.ACTIVE_FLAG <> 'Inactive'
           AND (3 = IN_INTF_OR_BUSI OR
               (2 = IN_INTF_OR_BUSI AND
               ('INTF' = NVL(A.CREATED_BY, 'INTF') AND
               'INTF' = NVL(A.LAST_UPDATE_BY, 'INTF')
               --
               )) OR (1 = NVL(IN_INTF_OR_BUSI, 1) AND
               NOT ('INTF' = NVL(A.CREATED_BY, 'INTF') AND
                'INTF' = NVL(A.LAST_UPDATE_BY, 'INTF'))
               --
               ))
           AND 'Y' = A.ACTIVE_FLAG
              --AND ('1' = A.ACCOUNT_STATUS OR '-1' = A.ACCOUNT_STATUS)
           AND (P_DEPT_CODE IS NULL OR EXISTS
                (SELECT 1
                   FROM UP_ORG_UNIT U
                  WHERE U.CODE = P_DEPT_CODE
                    AND U.ENTITY_ID = BE.ENTITY_ID))
           AND ((P_CUSTOMER_CODE IS NOT NULL AND
               CO.CUSTOMER_CODE = P_CUSTOMER_CODE) OR
               (P_CUSTOMER_CODE IS NULL AND A.CUSTOMER_ID = CO.CUSTOMER_ID))
           AND CO.SALES_CENTER_ID =
               NVL(P_SALES_CENTER_ID, CO.SALES_CENTER_ID)
           AND CO.SALES_CENTER_CODE =
               NVL(P_SALES_CENTER_CODE, CO.SALES_CENTER_CODE)
           AND CO.CUSTOMER_ORG_ID = NVL(P_CUST_ORG_ID, CO.CUSTOMER_ORG_ID)
           AND CO.SIEBEL_ORG_ID =
               NVL(P_SIEBEL_CUST_ORG_ID, CO.SIEBEL_ORG_ID)
           AND A.ACCOUNT_ID = NVL(P_ACCOUNT_ID, A.ACCOUNT_ID);
        IF 0 < V_CNT2 THEN
          RETURN '中心所挂账户存在未完成的发货计划或者发货通知单，不能失效';
        END IF;
        IF 0 < V_CNT AND 1 <> NVL(IN_AMOUNT_NOCHK,0) THEN
          RETURN '中心所在账户未初始化任何客户款项，不允许直接将中心失效（可在CIMS将账户失效' ||(CASE WHEN
                                                              0 < V_CNT1 THEN '' ELSE
                                                              '、或在CRM将事业部或客户失效' END) || '）';
        END IF;
        IF 1 = IN_AMOUNT_NOCHK THEN
          RETURN NULL;
        END IF;
        WITH m AS
         (select be.entity_id,
                 be.entity_name,
                 be.entity_code,
                 t.credit_group_id,
                 cg.credit_group_name,
                 A.ACCOUNT_ID,
                 A.ACCOUNT_CODE,
                 sum(t.received_amount - t.sales_amount + t.delaypay_amount +
                     t.temp_delaypay_amount - t.lock_received_amount +
                     t.discount_amount + t.freeze_discount_amount -
                     t.lock_discount_amount - t.applied_discount_amount) as delivery_amount,
                 sum(t.received_amount - t.sales_amount) as account_balance,
                 sum(t.discount_amount - t.applied_discount_amount) as allowance_balance
            from t_sales_account_amount      t,
                 v_bd_entity                 be,
                 t_credit_group              cg,
                 t_customer_org              co,
                 t_customer_account          a,
                 t_customer_acc_org_relation ar
           where t.entity_id = be.entity_id
             AND co.entity_id = be.entity_id
             AND a.entity_id = be.entity_id
             and t.credit_group_id = cg.credit_group_id
             AND A.ACCOUNT_ID = AR.ACCOUNT_ID
             AND A.ACCOUNT_ID = T.ACCOUNT_ID
             AND CO.CUSTOMER_ORG_ID = AR.CUSTOMER_ORG_ID
             AND CO.ACTIVE_FLAG <> 'Inactive'
             AND (3 = IN_INTF_OR_BUSI OR
                 (2 = IN_INTF_OR_BUSI AND
                 ('INTF' = NVL(UPPER(A.CREATED_BY), 'INTF') AND
                  'INTF' = NVL(UPPER(A.LAST_UPDATE_BY), 'INTF')
                  --
                  )) OR (1 = NVL(IN_INTF_OR_BUSI, 1) AND
                  NOT(
                 'INTF' = NVL(UPPER(A.CREATED_BY), 'INTF') AND
                 'INTF' = NVL(UPPER(A.LAST_UPDATE_BY), 'INTF'))
                 --
                 ))
             AND 'Y' = A.ACTIVE_FLAG
                --AND ('1' = A.ACCOUNT_STATUS OR '-1' = A.ACCOUNT_STATUS)
             and (P_DEPT_CODE IS NULL OR EXISTS
                  (SELECT 1
                     FROM UP_ORG_UNIT U
                    WHERE U.CODE = P_DEPT_CODE
                      AND U.ENTITY_ID = be.ENTITY_ID))
             AND ((P_CUSTOMER_CODE IS NOT NULL AND
                 T.CUSTOMER_CODE = P_CUSTOMER_CODE) OR
                 (P_CUSTOMER_CODE IS NULL AND
                 T.CUSTOMER_ID = CO.CUSTOMER_ID))
             and co.sales_center_id =
                 NVL(P_SALES_CENTER_ID, co.sales_center_id)
             and co.sales_center_code =
                 NVL(P_SALES_CENTER_CODE, co.sales_center_code)
             and co.customer_org_id = NVL(P_CUST_ORG_ID, co.customer_org_id)
             and co.SIEBEL_ORG_ID =
                 NVL(P_SIEBEL_CUST_ORG_ID, co.SIEBEL_ORG_ID)
             and A.ACCOUNT_ID = NVL(P_ACCOUNT_ID, A.ACCOUNT_ID)
           group by be.entity_id,
                    be.entity_name,
                    be.entity_code,
                    t.credit_group_id,
                    cg.credit_group_name,
                    A.ACCOUNT_ID,
                    A.ACCOUNT_CODE
          having 0 <> sum(t.received_amount - t.sales_amount + t.delaypay_amount
          --
          +t.temp_delaypay_amount - t.lock_received_amount + t.discount_amount
          --
          +t.freeze_discount_amount - t.lock_discount_amount - t.applied_discount_amount) OR 0 <> sum(t.received_amount - t.sales_amount) OR 0 <> sum(t.discount_amount - t.applied_discount_amount)
          --
          ),
        m2 as
         (select m.entity_name,
                 listagg(M.ACCOUNT_CODE || '_' || m.credit_group_name, ',') WITHIN GROUP(order by m.credit_group_id, M.ACCOUNT_ID) as credit_group_name,
                 '可提货金额' as amount_name,
                 listagg(m.delivery_amount, ',') WITHIN GROUP(order by m.credit_group_id, M.ACCOUNT_ID) as delivery_amount
            from m
           where 0 <> m.delivery_amount
           group by m.entity_name
          union all
          select m.entity_name,
                 listagg(M.ACCOUNT_CODE || '_' || m.credit_group_name, ',') WITHIN GROUP(order by m.credit_group_id, M.ACCOUNT_ID) as credit_group_name,
                 '到款余额' as amount_name,
                 listagg(m.account_balance, ',') WITHIN GROUP(order by m.credit_group_id) as delivery_amount
            from m
           where 0 = m.delivery_amount
             and 0 <> m.account_balance
           group by m.entity_name
          union all
          select m.entity_name,
                 listagg(M.ACCOUNT_CODE || '_' || m.credit_group_name, ',') WITHIN GROUP(order by m.credit_group_id, M.ACCOUNT_ID) as credit_group_name,
                 '折让余额' as amount_name,
                 listagg(m.allowance_balance, ',') WITHIN GROUP(order by m.credit_group_id) as delivery_amount
            from m
           where 0 = m.delivery_amount
             and 0 = m.account_balance
             and 0 <> m.allowance_balance
           group by m.entity_name)
        select listagg(m2.entity_name || ',账户_额度组:' || m2.credit_group_name || ',' ||
                        m2.amount_name || ':' || m2.delivery_amount,
                        chr(10))
               --
                WITHIN GROUP(order by m2.entity_name, m2.amount_name)
          INTO V_MESSAGE1
          from m2 -- where 10 >= rownum
        ;
      EXCEPTION
        WHEN VALUE_ERROR THEN
          V_MESSAGE1 := '查询可提货金额SQL异常' || SQLERRM;
        WHEN OTHERS THEN
          V_MESSAGE1 := '查询可提货金额SQL异常' || SQLERRM;
      END;
    
      IF V_MESSAGE1 IS NOT NULL THEN
        P_MESSAGE := '';
        P_MESSAGE := '存在可提货金额、到款余额、折让余额，无法进行失效。额度组如下：';
        P_MESSAGE := P_MESSAGE || chr(10);
        P_MESSAGE := P_MESSAGE || V_MESSAGE1;
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        RETURN '客户中心失效校验数据库层异常：' || SQLERRM;
    END;
    RETURN P_MESSAGE;
  END F_CUSTORG_CHECK_UNDO;

  FUNCTION F_INSERT_OR_UPDATE_HEADER
  --更新或插入客户头业务表
  (P_INTF_HEAD_ID number --客户头ID
   ) RETURN VARCHAR2 IS
    V_INTF_HEADER        INTF_CUSTOMER_HEADER%ROWTYPE;
    V_CUST_HEADER_ID     NUMBER; --客户头ID
    V_CUST_HEADER_STATUS VARCHAR2(30); --客户头状态
    V_MESSAGE            VARCHAR2(1000);
  BEGIN
    SELECT H.*
      INTO V_INTF_HEADER
      FROM INTF_CUSTOMER_HEADER H
     WHERE CUSTOMER_ID = P_INTF_HEAD_ID;
    PRC_INSERT_OR_UPDATE_HEADER(V_INTF_HEADER,
                                V_CUST_HEADER_ID,
                                V_CUST_HEADER_STATUS,
                                V_CUST_HEADER_ID,
                                V_MESSAGE);
    RETURN V_MESSAGE;
  END;

  PROCEDURE PRC_INSERT_OR_UPDATE_HEADER
  --更新或插入客户头业务表
  (P_INTF_HEADER        IN INTF_CUSTOMER_HEADER%ROWTYPE, --客户头
   P_CUST_HEADER_ID     OUT NUMBER, --客户头ID
   P_CUST_HEADER_STATUS OUT VARCHAR2, --客户头状态
   P_HEADER_ID          OUT NUMBER, --客户头ID
   P_MESSAGE            OUT VARCHAR2) IS
   V_CNT                NUMBER;
   V_ERR_MSG            INTF_CUSTOMER_HEADER.RESPONSEMESSAGE%TYPE;
  BEGIN
    --查看主数据客户头ID是否存在
    SELECT H.CUSTOMER_ID, H.Customer_Status
      INTO P_CUST_HEADER_ID, P_CUST_HEADER_STATUS
      FROM T_CUSTOMER_HEADER H
     RIGHT JOIN INTF_CUSTOMER_HEADER IH
        ON (H.SIEBEL_CUSTOMER_ID = IH.SIEBEL_CUSTOMER_ID)
     WHERE IH.CUSTOMER_ID = P_INTF_HEADER.CUSTOMER_ID;

    /*SELECT COUNT(0) INTO V_CNT FROM INTF_CUSTOMER_DEPT ID
    WHERE ID.SIEBEL_CUSTOMER_ID = P_INTF_HEADER.SIEBEL_CUSTOMER_ID
    AND ID.TRANSCODE = P_INTF_HEADER.TRANSCODE
    AND EXISTS (SELECT 1 FROM UP_ORG_UNIT U WHERE U.CODE = ID.DEPT_CODE)
    ;
    IF 0 = V_CNT THEN
      P_MESSAGE := '本次没有推送事业部的数据';
      RETURN ;
    END IF;*/
    
    P_HEADER_ID := P_CUST_HEADER_ID;
    --如果不存在，则插入
    IF (P_CUST_HEADER_ID IS NULL) THEN
      SELECT S_CUSTOMER_HEADER.NEXTVAL INTO P_HEADER_ID FROM DUAL;
      INSERT INTO T_CUSTOMER_HEADER
        (CUSTOMER_ID,
         CUSTOMER_CODE,
         CUSTOMER_NAME,
         CUSTOMER_SHORT_NAME,
         CUSTOMER_PHONES,
         CUSTOMER_FAX,
         CUSTOMER_MAIL,
         CUSTOMER_POSTAL_CODE,
         CUSTOMER_REGIST_ADDRESS,
         CUSTOMER_BUSINESS_LICENSE,
         CUSTOMER_ORGANIZATION_CODE,
         CUSTOMER_REGISTRATION_CODE,
         CUSTOMER_ENTERPRISE_NATURE,
         CUSTOMER_REGISTERED_FUNDS,
         CUSTOMER_REGISTRATION,
         CUSTOMER_LEGAL_PERSON,
         CUSTOMER_REGISTRATION_TYPE,
         CUSTOMER_FOUNDED_DATE,
         CUSTOMER_STATUS,
         CUSTOMER_COMMENTS,
         CUSTOMER_IS_TOP,
         CUSTOMER_IS_VENDOR,
         CUSTOMER_VENDOR_CODE,
         CUSTOMER_IS_INTERNAL,
         CUSTOMER_IS_AFTERSALES,
         CUSTOMER_PROP_COUNT,
         CUSTOMER_REGIST_COUNTRY,
         CUSTOMER_REGIST_PROVINCE,
         CUSTOMER_REGIST_CITY,
         CUSTOMER_REGIST_AREA,
         CUSTOMER_REGIST_TOWNS,
         CUSTOMER_REGADDRESS_COMMENTS,
         CUSTOMER_URL,
         CREATED_BY,
         CREATION_DATE,
         LAST_UPDATE_DATE,
         LAST_UPDATE_BY,
         LAST_INTERFACE_DATE,
         CUSTOMER_SYSTEM_NAME,
         CUSTOMER_FATHER_CODE,
         CUSTOMER_MANAGER,
         CUSTOMER_MANAGER_PHONES,
         CUSTOMER_OFFICE_ADDRESS,
         SIEBEL_CUSTOMER_ID,
         IS_VIRTUAL_CUSTOMER,
         ACTIVE_FLAG,
         PRE_FIELD_01,
         PRE_FIELD_02,
         PRE_FIELD_03,
         PRE_FIELD_04,
         PRE_FIELD_05,
         PRE_FIELD_06)
        SELECT P_HEADER_ID,
               P_INTF_HEADER.CUSTOMER_CODE,
               P_INTF_HEADER.CUSTOMER_NAME,
               P_INTF_HEADER.CUSTOMER_SHORT_NAME,
               P_INTF_HEADER.CUSTOMER_PHONES,
               P_INTF_HEADER.CUSTOMER_FAX,
               P_INTF_HEADER.CUSTOMER_MAIL,
               P_INTF_HEADER.CUSTOMER_POSTAL_CODE,
               P_INTF_HEADER.CUSTOMER_REGIST_ADDRESS,
               P_INTF_HEADER.CUSTOMER_BUSINESS_LICENSE,
               P_INTF_HEADER.CUSTOMER_ORGANIZATION_CODE,
               P_INTF_HEADER.CUSTOMER_REGISTRATION_CODE,
               P_INTF_HEADER.CUSTOMER_ENTERPRISE_NATURE,
               P_INTF_HEADER.CUSTOMER_REGISTERED_FUNDS,
               P_INTF_HEADER.CUSTOMER_REGISTRATION,
               P_INTF_HEADER.CUSTOMER_LEGAL_PERSON,
               P_INTF_HEADER.CUSTOMER_REGISTRATION_TYPE,
               P_INTF_HEADER.CUSTOMER_FOUNDED_DATE,
               P_INTF_HEADER.CUSTOMER_STATUS,
               P_INTF_HEADER.CUSTOMER_COMMENTS,
               P_INTF_HEADER.CUSTOMER_IS_TOP,
               P_INTF_HEADER.CUSTOMER_IS_VENDOR,
               P_INTF_HEADER.CUSTOMER_VENDOR_CODE,
               P_INTF_HEADER.CUSTOMER_IS_INTERNAL,
               P_INTF_HEADER.CUSTOMER_IS_AFTERSALES,
               P_INTF_HEADER.CUSTOMER_PROP_COUNT,
               P_INTF_HEADER.CUSTOMER_REGIST_COUNTRY,
               P_INTF_HEADER.CUSTOMER_REGIST_PROVINCE,
               P_INTF_HEADER.CUSTOMER_REGIST_CITY,
               P_INTF_HEADER.CUSTOMER_REGIST_AREA,
               P_INTF_HEADER.CUSTOMER_REGIST_TOWNS,
               P_INTF_HEADER.CUSTOMER_REGADDRESS_COMMENTS,
               P_INTF_HEADER.CUSTOMER_URL,
               P_INTF_HEADER.CREATED_BY,
               P_INTF_HEADER.CREATION_DATE,
               P_INTF_HEADER.LAST_UPDATE_DATE,
               P_INTF_HEADER.LAST_UPDATE_BY,
               P_INTF_HEADER.LAST_INTERFACE_DATE,
               P_INTF_HEADER.CUSTOMER_SYSTEM_NAME,
               P_INTF_HEADER.CUSTOMER_FATHER_CODE,
               P_INTF_HEADER.CUSTOMER_MANAGER,
               P_INTF_HEADER.CUSTOMER_MANAGER_PHONES,
               P_INTF_HEADER.CUSTOMER_OFFICE_ADDRESS,
               P_INTF_HEADER.SIEBEL_CUSTOMER_ID,
               P_INTF_HEADER.IS_VIRTUAL_CUSTOMER,
               P_INTF_HEADER.ACTIVE_FLAG,
               P_INTF_HEADER.PRE_FIELD_01,
               P_INTF_HEADER.CUSTOMER_ID,
               P_INTF_HEADER.PRE_FIELD_03,
               P_INTF_HEADER.PRE_FIELD_04,
               P_INTF_HEADER.PRE_FIELD_05,
               P_INTF_HEADER.PRE_FIELD_06
          FROM DUAL;
      --COMMIT;
    ELSE
      --若存在，则更新
      UPDATE T_CUSTOMER_HEADER head
         SET (head.CUSTOMER_CODE,
              head.CUSTOMER_NAME,
              head.CUSTOMER_SHORT_NAME,
              head.CUSTOMER_PHONES,
              head.CUSTOMER_FAX,
              head.CUSTOMER_MAIL,
              head.CUSTOMER_POSTAL_CODE,
              head.CUSTOMER_REGIST_ADDRESS,
              head.CUSTOMER_BUSINESS_LICENSE,
              head.CUSTOMER_ORGANIZATION_CODE,
              head.CUSTOMER_REGISTRATION_CODE,
              head.CUSTOMER_ENTERPRISE_NATURE,
              head.CUSTOMER_REGISTERED_FUNDS,
              head.CUSTOMER_REGISTRATION,
              head.CUSTOMER_LEGAL_PERSON,
              head.CUSTOMER_REGISTRATION_TYPE,
              head.CUSTOMER_FOUNDED_DATE,
              head.CUSTOMER_STATUS,
              head.CUSTOMER_COMMENTS,
              head.CUSTOMER_IS_TOP,
              head.CUSTOMER_IS_VENDOR,
              head.CUSTOMER_VENDOR_CODE,
              head.CUSTOMER_IS_INTERNAL,
              head.CUSTOMER_IS_AFTERSALES,
              head.CUSTOMER_PROP_COUNT,
              head.CUSTOMER_REGIST_COUNTRY,
              head.CUSTOMER_REGIST_PROVINCE,
              head.CUSTOMER_REGIST_CITY,
              head.CUSTOMER_REGIST_AREA,
              head.CUSTOMER_REGIST_TOWNS,
              head.CUSTOMER_REGADDRESS_COMMENTS,
              head.CUSTOMER_URL,
              head.CREATED_BY,
              head.CREATION_DATE,
              head.LAST_UPDATE_DATE,
              head.LAST_UPDATE_BY,
              head.LAST_INTERFACE_DATE,
              head.CUSTOMER_SYSTEM_NAME,
              head.CUSTOMER_FATHER_CODE,
              head.CUSTOMER_MANAGER,
              head.CUSTOMER_MANAGER_PHONES,
              head.CUSTOMER_OFFICE_ADDRESS,
              head.SIEBEL_CUSTOMER_ID,
              head.IS_VIRTUAL_CUSTOMER,
              head.ACTIVE_FLAG,
              head.PRE_FIELD_01,
              head.PRE_FIELD_02,
              head.PRE_FIELD_03,
              head.PRE_FIELD_04,
              head.PRE_FIELD_05,
              head.PRE_FIELD_06) =
             (SELECT P_INTF_HEADER.CUSTOMER_CODE,
                     P_INTF_HEADER.CUSTOMER_NAME,
                     P_INTF_HEADER.CUSTOMER_SHORT_NAME,
                     P_INTF_HEADER.CUSTOMER_PHONES,
                     P_INTF_HEADER.CUSTOMER_FAX,
                     P_INTF_HEADER.CUSTOMER_MAIL,
                     P_INTF_HEADER.CUSTOMER_POSTAL_CODE,
                     P_INTF_HEADER.CUSTOMER_REGIST_ADDRESS,
                     P_INTF_HEADER.CUSTOMER_BUSINESS_LICENSE,
                     P_INTF_HEADER.CUSTOMER_ORGANIZATION_CODE,
                     P_INTF_HEADER.CUSTOMER_REGISTRATION_CODE,
                     P_INTF_HEADER.CUSTOMER_ENTERPRISE_NATURE,
                     P_INTF_HEADER.CUSTOMER_REGISTERED_FUNDS,
                     P_INTF_HEADER.CUSTOMER_REGISTRATION,
                     P_INTF_HEADER.CUSTOMER_LEGAL_PERSON,
                     P_INTF_HEADER.CUSTOMER_REGISTRATION_TYPE,
                     P_INTF_HEADER.CUSTOMER_FOUNDED_DATE,
                     P_INTF_HEADER.CUSTOMER_STATUS,
                     P_INTF_HEADER.CUSTOMER_COMMENTS,
                     P_INTF_HEADER.CUSTOMER_IS_TOP,
                     P_INTF_HEADER.CUSTOMER_IS_VENDOR,
                     P_INTF_HEADER.CUSTOMER_VENDOR_CODE,
                     P_INTF_HEADER.CUSTOMER_IS_INTERNAL,
                     P_INTF_HEADER.CUSTOMER_IS_AFTERSALES,
                     P_INTF_HEADER.CUSTOMER_PROP_COUNT,
                     P_INTF_HEADER.CUSTOMER_REGIST_COUNTRY,
                     P_INTF_HEADER.CUSTOMER_REGIST_PROVINCE,
                     P_INTF_HEADER.CUSTOMER_REGIST_CITY,
                     P_INTF_HEADER.CUSTOMER_REGIST_AREA,
                     P_INTF_HEADER.CUSTOMER_REGIST_TOWNS,
                     P_INTF_HEADER.CUSTOMER_REGADDRESS_COMMENTS,
                     P_INTF_HEADER.CUSTOMER_URL,
                     P_INTF_HEADER.CREATED_BY,
                     P_INTF_HEADER.CREATION_DATE,
                     P_INTF_HEADER.LAST_UPDATE_DATE,
                     P_INTF_HEADER.LAST_UPDATE_BY,
                     P_INTF_HEADER.LAST_INTERFACE_DATE,
                     P_INTF_HEADER.CUSTOMER_SYSTEM_NAME,
                     P_INTF_HEADER.CUSTOMER_FATHER_CODE,
                     P_INTF_HEADER.CUSTOMER_MANAGER,
                     P_INTF_HEADER.CUSTOMER_MANAGER_PHONES,
                     P_INTF_HEADER.CUSTOMER_OFFICE_ADDRESS,
                     P_INTF_HEADER.SIEBEL_CUSTOMER_ID,
                     P_INTF_HEADER.IS_VIRTUAL_CUSTOMER,
                     P_INTF_HEADER.ACTIVE_FLAG,
                     P_INTF_HEADER.PRE_FIELD_01,
                     P_INTF_HEADER.CUSTOMER_ID,
                     P_INTF_HEADER.PRE_FIELD_03,
                     P_INTF_HEADER.PRE_FIELD_04,
                     P_INTF_HEADER.PRE_FIELD_05,
                     P_INTF_HEADER.PRE_FIELD_06
                FROM DUAL)
       WHERE CUSTOMER_ID = P_CUST_HEADER_ID;
      --COMMIT;
    END IF;
    
    UPDATE T_CUSTOMER_ORG UO
    SET (UO.ORG_CUSTOMER_FATHER_ID,UO.ORG_CUSTOMER_FATHER_NAME)
    = (SELECT H.CUSTOMER_ID,H.CUSTOMER_NAME FROM T_CUSTOMER_HEADER H
    WHERE H.CUSTOMER_CODE = UO.ORG_CUSTOMER_FATHER_CODE AND 1 = ROWNUM)
    WHERE UO.ORG_CUSTOMER_FATHER_CODE = P_INTF_HEADER.CUSTOMER_CODE
    AND (P_CUST_HEADER_ID IS NULL OR 0 >= UO.ORG_CUSTOMER_FATHER_ID
    OR P_CUST_HEADER_ID = UO.ORG_CUSTOMER_FATHER_ID)
    AND EXISTS (SELECT 1 FROM T_CUSTOMER_HEADER H WHERE H.CUSTOMER_CODE = UO.ORG_CUSTOMER_FATHER_CODE)
    ;
    
    IF P_INTF_HEADER.ACTIVE_FLAG NOT IN ('Inactive','Delete') THEN
    
      SELECT COUNT(0) INTO V_CNT
    FROM UP_CODELIST C
   WHERE C.CODETYPE = 'temp_all_free'--临时自由码表
     AND C.CODE_VALUE = '临时主体无关'
     AND C.CODE_NAME = '临时主体无关'
     AND C.ENTITY_FLAG = 'N'
     AND C.ENABLED = '0';
      IF 0 = V_CNT THEN
        SELECT COUNT(0) INTO V_CNT FROM DUAL
        WHERE NOT EXISTS (
        SELECT 1 FROM T_CUSTOMER_HEADER H INNER JOIN T_CUSTOMER_OU OU
        ON (OU.CUSTOMER_CODE = H.CUSTOMER_CODE AND H.SIEBEL_CUSTOMER_ID = P_INTF_HEADER.SIEBEL_CUSTOMER_ID
        AND OU.ACTIVE_FLAG = P_INTF_HEADER.ACTIVE_FLAG/* AND EXISTS (SELECT 1 FROM T_INV_ORGANIZATION IO WHERE IO.ENTITY_ID IS NOT NULL
        AND IO.OPERATING_UNIT = OU.ERPOU)*/
        AND EXISTS (SELECT 1 FROM V_UP_CODELIST CL WHERE CL.CODETYPE = 'ar_ou_id' AND CL.ENTITY_ID IS NOT NULL
        AND CL.CODE_VALUE = OU.ERPOU
        )--modify by liangym2 2017-6-14
        )
        )
        AND NOT EXISTS (
        SELECT 1 FROM INTF_CUSTOMER_OU OU
        WHERE OU.CUSTOMER_CODE = P_INTF_HEADER.CUSTOMER_CODE AND OU.TRANSCODE = P_INTF_HEADER.TRANSCODE
        AND OU.ACTIVE_FLAG = P_INTF_HEADER.ACTIVE_FLAG/* AND EXISTS (SELECT 1 FROM T_INV_ORGANIZATION IO WHERE IO.ENTITY_ID IS NOT NULL
        AND IO.OPERATING_UNIT = OU.ERPOU)*/
        AND EXISTS (SELECT 1 FROM V_UP_CODELIST CL WHERE CL.CODETYPE = 'ar_ou_id' AND CL.ENTITY_ID IS NOT NULL
        AND CL.CODE_VALUE = OU.ERPOU
        )--modify by liangym2 2017-6-14
        )
        AND (EXISTS (
        SELECT 1 FROM T_CUSTOMER_DEPT CD WHERE CD.SIEBEL_CUSTOMER_ID = P_INTF_HEADER.SIEBEL_CUSTOMER_ID
        AND CD.ACTIVE_FLAG NOT IN ('Inactive','Delete') AND CD.DEPT_ID IS NOT NULL
        AND NOT EXISTS (
        SELECT 1 FROM INTF_CUSTOMER_DEPT ICD WHERE ICD.SIEBEL_ID = CD.SIEBEL_ID AND ICD.TRANSCODE = P_INTF_HEADER.TRANSCODE
        AND ICD.ACTIVE_FLAG IN ('Inactive','Delete')
        )
        )
        OR EXISTS (
        SELECT 1 FROM INTF_CUSTOMER_DEPT ICD WHERE ICD.SIEBEL_CUSTOMER_ID = P_INTF_HEADER.SIEBEL_CUSTOMER_ID
        AND ICD.ACTIVE_FLAG NOT IN ('Inactive','Delete') AND ICD.TRANSCODE = P_INTF_HEADER.TRANSCODE
        AND EXISTS (SELECT 1 FROM UP_ORG_UNIT U WHERE U.CODE = ICD.DEPT_CODE AND U.ENTITY_ID IS NOT NULL)
        )
        )
        --推送数据不存在非有效、非冻结,或者压根不推送事业部
        AND (NOT EXISTS (
        SELECT 1 FROM INTF_CUSTOMER_DEPT ICD WHERE ICD.SIEBEL_CUSTOMER_ID = P_INTF_HEADER.SIEBEL_CUSTOMER_ID
        AND ICD.ACTIVE_FLAG NOT IN ('Active','Freezing') AND ICD.TRANSCODE = P_INTF_HEADER.TRANSCODE
        AND EXISTS (SELECT 1 FROM UP_ORG_UNIT U WHERE U.CODE = ICD.DEPT_CODE AND U.ENTITY_ID IS NOT NULL)
        )
        --不推送事业部，前面条件成立，还有判断正式表不存在非有效、非冻结
        AND NOT EXISTS (
        SELECT 1 FROM T_CUSTOMER_DEPT CD WHERE CD.SIEBEL_CUSTOMER_ID = P_INTF_HEADER.SIEBEL_CUSTOMER_ID
        AND CD.ACTIVE_FLAG NOT IN ('Active','Freezing') AND CD.DEPT_ID IS NOT NULL
        AND NOT EXISTS (
        SELECT 1 FROM INTF_CUSTOMER_DEPT ICD WHERE ICD.SIEBEL_ID = CD.SIEBEL_ID AND ICD.TRANSCODE = P_INTF_HEADER.TRANSCODE
        AND ICD.ACTIVE_FLAG IN ('Active','Freezing')
        )
        )
        )
        /*AND EXISTS (SELECT 1 FROM T_CUSTOMER_HEADER H INNER JOIN T_SALES_ACCOUNT_MX_AMOUNT MX
        ON (H.CUSTOMER_ID = MX.CUSTOMER_ID AND H.SIEBEL_CUSTOMER_ID = P_INTF_HEADER.SIEBEL_CUSTOMER_ID)
        WHERE MX.ENTITY_ID IS NOT NULL
        )*/
        ;
        IF 0 < V_CNT THEN
          P_MESSAGE := P_INTF_HEADER.CUSTOMER_CODE || '，客户头没有推送（包括历史）有效的OU';
          UPDATE T_CUSTOMER_DEPT D
          SET D.DEPT_CUSTOMER_STATUS = 'Inactive',
          D.LAST_UPDATE_BY = P_INTF_HEADER.LAST_UPDATE_BY,
          D.LAST_UPDATE_DATE = P_INTF_HEADER.LAST_INTERFACE_DATE,
          D.LAST_INTERFACE_DATE = P_INTF_HEADER.LAST_INTERFACE_DATE
          WHERE D.SIEBEL_CUSTOMER_ID = P_INTF_HEADER.SIEBEL_CUSTOMER_ID;
          BEGIN
          P_CUSTOMER_INTF_PROC(P_INTF_HEADER_ID_LIST => P_INTF_HEADER.CUSTOMER_ID
          ,P_MESSAGE => V_ERR_MSG,IS_CTRL_PARAM => 'NOTGTWIDTHANDNODEPT');
          EXCEPTION WHEN OTHERS THEN
            NULL;
          END;
          RETURN ;
        END IF;
      END IF;
    
    END IF;
    
    P_MESSAGE := 'SUCCESS';
  END;

  FUNCTION F_INSERT_OR_UPDATE_DEPT
  --更新或插入客户事业部业务表
  (P_INTF_HEAD_ID number --客户头ID
   ) return varchar2 is
    V_CUST_DEPT_COUNT        NUMBER; --业务表中的事业部的数量
    P_MESSAGE                VARCHAR2(1000);
    --VS_MESSAGE               VARCHAR2(4000);
    V_ERR_MSG                VARCHAR2(4000);--循环中出现的所有错误
    P_ERR_MESSAGE            VARCHAR2(1000);--本次错误
    P_PARENT_ID              VARCHAR2(1000); --客户事业部ID
    V_ACCOUNT_COUNT          NUMBER; --账户数量
    V_ACCOUNT_CODE           VARCHAR2(100); --账户编码
    V_ACCOUNT_CODE_TMP       VARCHAR2(100); --账户编码(后缀)
    V_ACCOUNT_ID             NUMBER; --账户ID
    V_ENTITY_ID              NUMBER; --主体ID
    V_CUSTOMER_ID            NUMBER; --客户ID
    V_CUSTOMER_CODE          VARCHAR2(100); --客户编码
    V_ORG_INDEX              NUMBER; --S_CUSTOMER_ORG.NEXTVAL
    --V_SALES_CENTER_CODE      VARCHAR2(100); --中心编码
    --V_SALES_CENTER_ID        NUMBER; --中心ID
    --V_SALES_CENTER_TYPE_CODE UP_ORG_UNIT.Type_Code%type;
    dept                     INTF_CUSTOMER_DEPT%ROWTYPE;
    intf_org                 INTF_CUSTOMER_ORG%ROWTYPE;
    VR_SALES_CENTER          UP_ORG_UNIT%ROWTYPE;
    cust_org                 T_CUSTOMER_ORG%ROWTYPE;
    V_ACC_ORG_REL_ID         T_CUSTOMER_ACC_ORG_RELATION.RELATION_ID%TYPE;
    --V_CUST_ORG_COUNT           NUMBER; --推送报表各事业部下的组织个数
    CURSOR C_INTF_CUSTOMER_DEPT IS
      SELECT * FROM INTF_CUSTOMER_DEPT WHERE PRE_FIELD_01 = P_INTF_HEAD_ID;
  
    CURSOR C_INTF_CUSTOMER_ORG IS
      SELECT *
        FROM INTF_CUSTOMER_ORG o
       WHERE PRE_FIELD_01 = P_INTF_HEAD_ID
         AND PARENT_ID = P_PARENT_ID
         AND 'Active' = o.active_flag
         AND EXISTS (SELECT 1 FROM UP_ORG_UNIT unit
               WHERE unit.code = o.SALES_CENTER_CODE
               AND UNIT.ENTITY_ID IS NOT NULL AND UNIT.TYPE_CODE NOT IN ('MC','BU')
               )
               ;
   TYPE T_INTF_DEPT IS TABLE OF INTF_CUSTOMER_DEPT%ROWTYPE
   INDEX BY BINARY_INTEGER
   ;
   V_INTF_DEPT T_INTF_DEPT;
   V_INDEX     NUMBER;
   
   TYPE T_INTF_ORG IS TABLE OF INTF_CUSTOMER_ORG%ROWTYPE
   INDEX BY BINARY_INTEGER
   ;
   V_INTF_ORG T_INTF_ORG;
   V_INDEX1     NUMBER;
  BEGIN
    --查看主数据ID是否存在
    OPEN C_INTF_CUSTOMER_DEPT;
    FETCH C_INTF_CUSTOMER_DEPT BULK COLLECT INTO V_INTF_DEPT;
    CLOSE C_INTF_CUSTOMER_DEPT;
    V_INDEX := (V_INTF_DEPT.FIRST - 1);
    LOOP
      <<LP_DEPT>>
      V_INDEX := (1 + V_INDEX);
      IF V_INDEX IS NULL OR V_INDEX > V_INTF_DEPT.LAST THEN
        EXIT;
      END IF;
      dept := V_INTF_DEPT(V_INDEX);
      P_MESSAGE := 'SUCCESS';
      BEGIN
        V_ACCOUNT_COUNT := 0;
        SELECT (SELECT unit.Entity_Id
                FROM UP_ORG_UNIT unit
               WHERE unit.code = dept.dept_code)
               ,(SELECT CUSTOMER_ID
                            FROM T_CUSTOMER_HEADER head
                           WHERE head.CUSTOMER_CODE = dept.CUSTOMER_CODE)
                           INTO dept.dept_id,DEPT.CUSTOMER_ID FROM DUAL;
        IF DEPT.DEPT_ID IS NULL THEN
           P_ERR_MESSAGE := '该事业部不是内销的';
           UPDATE INTF_CUSTOMER_DEPT
              SET RESPONSETYPE    = 'E',
                  RESPNOSECODE    = '000013',
                  RESPONSEMESSAGE = P_ERR_MESSAGE,
                  OPERSTATUS      = '1'
            WHERE ID = DEPT.ID;
           GOTO LP_DEPT ;
        END IF;
        
        IF DEPT.ACTIVE_FLAG IN ('Active','Freezing') THEN
        
          SELECT COUNT(0) INTO V_CUST_DEPT_COUNT
            FROM UP_CODELIST C,UP_CODELIST_ENTITY CE
       WHERE CE.CODELIST_ID = C.ID
         AND CE.ENTITY_ID = dept.dept_id
         AND NVL(CE.ENABLED,'0')='0'
         AND C.CODETYPE = 'temp_all_free'--临时自由码表
         AND C.CODE_VALUE = '临时主体相关'
         AND C.CODE_NAME = '临时主体相关'
         AND C.ENTITY_FLAG = 'Y'
         AND C.ENABLED = '0';
          IF dept.dept_id IS NOT NULL AND 0 = V_CUST_DEPT_COUNT THEN
            SELECT COUNT(0) INTO V_CUST_DEPT_COUNT FROM T_CUSTOMER_HEADER H
            WHERE H.SIEBEL_CUSTOMER_ID = DEPT.SIEBEL_CUSTOMER_ID
            AND NOT EXISTS (
            SELECT 1 FROM T_CUSTOMER_OU OU
            WHERE OU.CUSTOMER_CODE = H.CUSTOMER_CODE
            AND ( (OU.ACTIVE_FLAG = DEPT.ACTIVE_FLAG AND 'Active' = DEPT.ACTIVE_FLAG)
            OR ('Active' <> DEPT.ACTIVE_FLAG AND OU.ACTIVE_FLAG IN ('Active','Freezing')) )
            /*AND EXISTS (SELECT 1 FROM T_INV_ORGANIZATION IO WHERE IO.ENTITY_ID = DEPT.DEPT_ID
            AND IO.OPERATING_UNIT = OU.ERPOU)*/
            AND EXISTS (SELECT 1 FROM V_UP_CODELIST CL WHERE CL.CODETYPE = 'ar_ou_id' AND CL.ENTITY_ID = DEPT.DEPT_ID
            AND CL.CODE_VALUE = OU.ERPOU
            )--modify by liangym2 2017-6-14
            )
            AND NOT EXISTS (
            SELECT 1 FROM INTF_CUSTOMER_OU OU
            WHERE OU.CUSTOMER_CODE = DEPT.CUSTOMER_CODE AND OU.TRANSCODE = DEPT.TRANSCODE
            AND ( (OU.ACTIVE_FLAG = DEPT.ACTIVE_FLAG AND 'Active' = DEPT.ACTIVE_FLAG)
            OR ('Active' <> DEPT.ACTIVE_FLAG AND OU.ACTIVE_FLAG IN ('Active','Freezing')) )
            /*AND EXISTS (SELECT 1 FROM T_INV_ORGANIZATION IO WHERE IO.ENTITY_ID = DEPT.DEPT_ID
            AND IO.OPERATING_UNIT = OU.ERPOU)*/
            AND EXISTS (SELECT 1 FROM V_UP_CODELIST CL WHERE CL.CODETYPE = 'ar_ou_id' AND CL.ENTITY_ID = DEPT.DEPT_ID
            AND CL.CODE_VALUE = OU.ERPOU
            )--modify by liangym2 2017-6-14
            )
            --只对新增客户、事业部才做检查
            --AND NOT EXISTS (SELECT 1 FROM T_CUSTOMER_DEPT ND WHERE ND.SIEBEL_ID = DEPT.SIEBEL_ID)
            ;
            IF 0 < V_CUST_DEPT_COUNT THEN
              P_ERR_MESSAGE := DEPT.CUSTOMER_CODE || '，事业部' || DEPT.DEPT_CODE
              || '，没有推送（包括历史）事业部的有效OU';
              UPDATE INTF_CUSTOMER_DEPT
                 SET RESPONSETYPE    = 'E',
                     RESPNOSECODE    = '000013',
                     RESPONSEMESSAGE = P_ERR_MESSAGE,
                     OPERSTATUS      = '1'
               WHERE ID = DEPT.ID;
          UPDATE T_CUSTOMER_DEPT D
          SET D.DEPT_CUSTOMER_STATUS = 'Inactive',
          D.LAST_UPDATE_BY = DEPT.LAST_UPDATE_BY,
          D.LAST_UPDATE_DATE = DEPT.LAST_INTERFACE_DATE,
          D.LAST_INTERFACE_DATE = DEPT.LAST_INTERFACE_DATE
          WHERE D.SIEBEL_ID = DEPT.SIEBEL_ID
          --D.SIEBEL_CUSTOMER_ID = DEPT.SIEBEL_CUSTOMER_ID
          ;
              IF V_ERR_MSG IS NULL THEN
                V_ERR_MSG := P_ERR_MESSAGE;
              ELSE
                V_ERR_MSG := V_ERR_MSG ||V_NL || P_ERR_MESSAGE;
              END IF;
              GOTO LP_DEPT ;
            END IF;
          END IF;
        
        END IF;
    
        SELECT COUNT(0)
          INTO V_CUST_DEPT_COUNT
          FROM T_CUSTOMER_DEPT
         WHERE SIEBEL_ID = dept.Siebel_Id;
        /* (SELECT SIEBEL_ID
         FROM INTF_CUSTOMER_DEPT
        WHERE PRE_FIELD_01 = P_INTF_HEAD_ID);*/
      
        --若不存在，则插入
        IF (V_CUST_DEPT_COUNT = 0) THEN
          INSERT INTO T_CUSTOMER_DEPT
            (ID,
             DEPT_ID,
             DEPT_CODE,
             CUSTOMER_ID,
             CUSTOMER_CODE,
             CUSTOMER_SHORT_NAME,
             DEPT_CUSTOM_LEVEL,
             CUSTOMER_MARKET_HIERARCHY,
             DEPT_CUSTOMER_STATUS,
             CUSTOMER_ACTIVE_DATE,
             CUSTOMER_END_DATE,
             CREATED_BY,
             CREATION_DATE,
             LAST_UPDATE_DATE,
             LAST_UPDATE_BY,
             LAST_INTERFACE_DATE,
             YEAR_SCALE,
             BAKE_YEAR_REAL_SCALE,
             SIEBEL_ID,
             SIEBEL_CUSTOMER_ID,
             ACTIVE_FLAG,
             PRE_FIELD_01,
             PRE_FIELD_02,
             PRE_FIELD_03,
             PRE_FIELD_04,
             PRE_FIELD_05,
             PRE_FIELD_06)
          VALUES
            (S_CUSTOMER_DEPT.NEXTVAL,
             DEPT.DEPT_ID, --DEPT_ID,
             dept.DEPT_CODE,
             DEPT.CUSTOMER_ID, --CUSTOMER_ID, AND head.active_flag = 'Active'
             dept.CUSTOMER_CODE,
             dept.CUSTOMER_SHORT_NAME,
             dept.DEPT_CUSTOM_LEVEL,
             dept.CUSTOMER_MARKET_HIERARCHY,
             dept.DEPT_CUSTOMER_STATUS,
             dept.CUSTOMER_ACTIVE_DATE,
             dept.CUSTOMER_END_DATE,
             dept.CREATED_BY,
             dept.CREATION_DATE,
             dept.LAST_UPDATE_DATE,
             dept.LAST_UPDATE_BY,
             dept.LAST_INTERFACE_DATE,
             dept.YEAR_SCALE,
             dept.BAKE_YEAR_REAL_SCALE,
             dept.SIEBEL_ID,
             dept.SIEBEL_CUSTOMER_ID,
             NVL(dept.ACTIVE_FLAG, 'Active'),
             dept.PRE_FIELD_01,
             dept.PRE_FIELD_02,
             dept.PRE_FIELD_03,
             dept.PRE_FIELD_04,
             dept.PRE_FIELD_05,
             dept.PRE_FIELD_06);
        
          --若存在，则更新
        ELSE
          UPDATE T_CUSTOMER_DEPT
             SET (DEPT_ID,
                  DEPT_CODE,
                  CUSTOMER_ID,
                  CUSTOMER_CODE,
                  CUSTOMER_SHORT_NAME,
                  DEPT_CUSTOM_LEVEL,
                  CUSTOMER_MARKET_HIERARCHY,
                  DEPT_CUSTOMER_STATUS,
                  CUSTOMER_ACTIVE_DATE,
                  CUSTOMER_END_DATE,
                  CREATED_BY,
                  CREATION_DATE,
                  LAST_UPDATE_DATE,
                  LAST_UPDATE_BY,
                  LAST_INTERFACE_DATE,
                  SIEBEL_ID,
                  SIEBEL_CUSTOMER_ID,
                  ACTIVE_FLAG,
                  PRE_FIELD_01,
                  PRE_FIELD_02,
                  PRE_FIELD_03,
                  PRE_FIELD_04,
                  PRE_FIELD_05,
                  PRE_FIELD_06) =
                 (SELECT DEPT.DEPT_ID, --DEPT_ID,
                         dept.DEPT_CODE,
                         DEPT.CUSTOMER_ID, --CUSTOMER_ID, and head.active_flag = 'Active'
                         dept.CUSTOMER_CODE,
                         dept.CUSTOMER_SHORT_NAME,
                         dept.DEPT_CUSTOM_LEVEL,
                         dept.CUSTOMER_MARKET_HIERARCHY,
                         dept.DEPT_CUSTOMER_STATUS,
                         dept.CUSTOMER_ACTIVE_DATE,
                         dept.CUSTOMER_END_DATE,
                         dept.CREATED_BY,
                         dept.CREATION_DATE,
                         dept.LAST_UPDATE_DATE,
                         dept.LAST_UPDATE_BY,
                         dept.LAST_INTERFACE_DATE,
                         dept.SIEBEL_ID,
                         dept.SIEBEL_CUSTOMER_ID,
                         NVL(dept.ACTIVE_FLAG, 'Active'),
                         dept.PRE_FIELD_01,
                         dept.PRE_FIELD_02,
                         dept.PRE_FIELD_03,
                         dept.PRE_FIELD_04,
                         dept.PRE_FIELD_05,
                         dept.PRE_FIELD_06
                    FROM DUAL)
           WHERE siebel_id = dept.siebel_id;
          /*FROM INTF_CUSTOMER_DEPT intf
                   WHERE intf.PRE_FIELD_01 = P_INTF_HEAD_ID
                   AND   intf.siebel_id = dept.siebel_id)
                   WHERE EXISTS (SELECT 1 from INTF_CUSTOMER_DEPT intfx WHERE intfx.PRE_FIELD_01 = P_INTF_HEAD_ID AND intfx.siebel_id = dept.siebel_id);
          */ --
        
        END IF;
      
        --增加账户
        --取主体，客户
        SELECT d.dept_id, d.CUSTOMER_ID, d.CUSTOMER_CODE
          INTO V_ENTITY_ID, V_CUSTOMER_ID, V_CUSTOMER_CODE
          FROM T_CUSTOMER_DEPT d
         WHERE d.SIEBEL_ID = dept.siebel_id
           and rownum = 1;
      
        IF V_ENTITY_ID IS NULL THEN
          GOTO SUCC_DEPT_LG;
        END IF;
          
        P_PARENT_ID := dept.siebel_id;
      
        IF (V_CUST_DEPT_COUNT > 0) THEN
          --20151120 梁颜明 判断是否不存在账户
          select count(0)
            into V_ACCOUNT_COUNT
            from T_CUSTOMER_ACCOUNT t
           where t.entity_id = V_ENTITY_ID
             and t.customer_code = dept.customer_code;
        END IF;
      
        --如果是第一次插入该事业部、或者账户不存在、或者只有一个分部
        IF (V_CUST_DEPT_COUNT = 0) or (V_ACCOUNT_COUNT = 0) -- or (V_CUST_ORG_COUNT = 1)
         THEN
          BEGIN
            OPEN C_INTF_CUSTOMER_ORG;
            FETCH C_INTF_CUSTOMER_ORG BULK COLLECT INTO V_INTF_ORG;
            CLOSE C_INTF_CUSTOMER_ORG;
            V_INDEX1 := (V_INTF_ORG.FIRST - 1);
            LOOP
              <<LP_INTF_ORG>>
              V_INDEX1 := (1 + V_INDEX1);
              IF V_INDEX1 IS NULL OR V_INDEX1 > V_INTF_ORG.LAST THEN
                EXIT;
              END IF;
              intf_org := V_INTF_ORG(V_INDEX1);
              --取中心
              SELECT UNIT.* INTO VR_SALES_CENTER FROM UP_ORG_UNIT UNIT
              WHERE unit.code = intf_org.SALES_CENTER_CODE;
              /*SELECT unit.UNIT_ID,
                     intf_org.SALES_CENTER_CODE,
                     unit.type_code
                INTO V_SALES_CENTER_ID,
                     V_SALES_CENTER_CODE,
                     V_SALES_CENTER_TYPE_CODE
                FROM UP_ORG_UNIT unit
               WHERE unit.code = intf_org.SALES_CENTER_CODE;*/
            
              IF 'SC' <> VR_SALES_CENTER.TYPE_CODE THEN
                GOTO LP_INTF_ORG;
              END IF;
            
              BEGIN
                SELECT * INTO CUST_ORG FROM T_CUSTOMER_ORG
                WHERE SIEBEL_ORG_ID = INTF_ORG.SIEBEL_ORG_ID;
              EXCEPTION WHEN NO_DATA_FOUND THEN
                NULL;
              END;
              --梁颜明 2017-09-27 万一事业部推送、中心处理无先后顺序 可能存在 所以不能假定不是第一次插入事业部、不存在账户的情形下
              --相应的中心已经插入到正式表
              V_ORG_INDEX := CUST_ORG.CUSTOMER_ORG_ID;
              /*V_ORG_INDEX := null;
              IF (0 < V_CUST_DEPT_COUNT) THEN
                V_ORG_INDEX := CUST_ORG.CUSTOMER_ORG_ID;
              END IF;*/
              IF (V_ORG_INDEX is null) THEN
                ---取组织序列,并赋值给组织接口表保留字段2，在插入组织的时候，获取序列
                SELECT S_CUSTOMER_ORG.NEXTVAL INTO V_ORG_INDEX FROM DUAL;
              ELSIF CUST_ORG.CUSTOMER_ID <> DEPT.CUSTOMER_ID THEN
                GOTO LP_INTF_ORG;
              END IF;
              UPDATE INTF_CUSTOMER_ORG U
                 SET pre_field_02 = V_ORG_INDEX
               WHERE customer_org_id = intf_org.customer_org_id
               AND NOT EXISTS (
               SELECT 1 FROM INTF_CUSTOMER_ORG EI
               WHERE EI.PRE_FIELD_02 = V_ORG_INDEX
               AND EI.CUSTOMER_ORG_ID <> U.CUSTOMER_ORG_ID
               );
              IF 0 = SQL%ROWCOUNT THEN
                GOTO LP_INTF_ORG;
              END IF;
              /*         intf_org.pre_field_02 := V_ORG_INDEX;*/
            
              --取账户表序列
              SELECT S_CUSTOMER_ACCOUNT.NEXTVAL
                INTO V_ACCOUNT_ID
                FROM DUAL;
            
              --取主体，客户
              /*SELECT dept.dept_id,dept.CUSTOMER_ID,dept.CUSTOMER_CODE
              INTO  V_ENTITY_ID,V_CUSTOMER_ID,V_CUSTOMER_CODE
              FROM T_CUSTOMER_DEPT dept
              WHERE dept.SIEBEL_ID = intf_org.parent_id;*/
            
              IF (V_ACCOUNT_COUNT = 0) THEN
                V_ACCOUNT_CODE := V_CUSTOMER_CODE;
              ELSE
                select lpad(to_char(V_ACCOUNT_COUNT), 3, '0')
                  INTO V_ACCOUNT_CODE_TMP
                  from dual;
                V_ACCOUNT_CODE := V_CUSTOMER_CODE || '-' ||
                                  V_ACCOUNT_CODE_TMP;
              END IF;
            
              SELECT S_CUSTOMER_ACC_ORG_RELATION.NEXTVAL INTO V_ACC_ORG_REL_ID FROM DUAL;
              --插入账户表
              INSERT INTO T_CUSTOMER_ACCOUNT
                (ACCOUNT_ID,
                 ENTITY_ID,
                 ACCOUNT_CODE,
                 ACCOUNT_NAME,
                 ACCOUNT_STATUS,
                 CUSTOMER_ID,
                 CUSTOMER_CODE,
                 --APPROVE_STATUS,
                 /*APPROVE_OPINION,
                 LAST_APPROVE_TIME,*/
                 CREATED_BY,
                 CREATION_DATE,
                 LAST_UPDATE_BY,
                 LAST_UPDATE_DATE,
                 ACTIVE_FLAG,
                 SALES_CENTER_ID,
                 SALES_CENTER_CODE,
                 SALES_CENTER_NAME,
                 CUSTOMER_ORG_ID,
                 RELATION_ID
                 /* PRE_FIELD_01,
                 PRE_FIELD_02,
                 PRE_FIELD_03,
                 PRE_FIELD_04,
                 PRE_FIELD_05,
                 PRE_FIELD_06*/)
              VALUES
                (V_ACCOUNT_ID,
                 V_ENTITY_ID,
                 V_ACCOUNT_CODE,
                 NULL,
                 '1',
                 V_CUSTOMER_ID,
                 V_CUSTOMER_CODE,
                 --'1',
                 'INTF',
                 SYSDATE,
                 'INTF',
                 SYSDATE,
                 'Y',
                 VR_SALES_CENTER.UNIT_ID,
                 INTF_ORG.SALES_CENTER_CODE,
                 VR_SALES_CENTER.NAME,
                 V_ORG_INDEX,
                 V_ACC_ORG_REL_ID);
            
              --插入账户和组织对应关系表
              INSERT INTO T_CUSTOMER_ACC_ORG_RELATION
                (RELATION_ID,
                 ACCOUNT_ID,
                 CUSTOMER_ORG_ID,
                 CREATED_BY,
                 CREATION_DATE)
              VALUES
                (V_ACC_ORG_REL_ID,
                 V_ACCOUNT_ID,
                 V_ORG_INDEX,
                 'INTF',
                 SYSDATE);
              BEGIN
                PKG_CREDIT_DOWN_PAY.PRC_CREDIT_ACC_LIMIT_UPDATE(V_ENTITY_ID
                ,V_CUSTOMER_ID,V_ACCOUNT_ID,'CRM推送事业部' || dept.transcode,P_ERR_MESSAGE);
              EXCEPTION
                WHEN OTHERS THEN
                  P_ERR_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_CUSTOMER_INTF.P_CUSTOMER_INTF_PROCF_INSERT_OR_UPDATE_DEPT',
                                              SQLCODE,
                                              '初始化客户账户额度失败！：' || P_ERR_MESSAGE || SQLERRM);
              END;
            
              V_ACCOUNT_COUNT := V_ACCOUNT_COUNT + 1;
            END LOOP;
          EXCEPTION
            WHEN OTHERS THEN
              --CLOSE C_INTF_CUSTOMER_ORG;
              ROLLBACK;
              --记录出错信息
              P_ERR_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_CUSTOMER_INTF.P_CUSTOMER_INTF_PROCF_INSERT_OR_UPDATE_DEPT',
                                                      SQLCODE,
                                                      '插入客户事业部表分配账户异常：' ||
                                                      SQLERRM);
              UPDATE INTF_CUSTOMER_DEPT
                 SET RESPONSETYPE    = 'E',
                     RESPNOSECODE    = '000013',
                     RESPONSEMESSAGE = P_ERR_MESSAGE,
                     OPERSTATUS      = '1'
               WHERE ID = DEPT.ID;
              GOTO LP_DEPT;
          END;
        ELSE
          FOR LI IN (select CUSTOMER_ID,ACCOUNT_ID from T_CUSTOMER_ACCOUNT t
           where t.entity_id = V_ENTITY_ID
             and t.customer_code = dept.customer_code) LOOP
          BEGIN
          PKG_CREDIT_SETTING.P_CREDIT_CUSTOMER_INIT(V_ENTITY_ID,LI.CUSTOMER_ID,LI.ACCOUNT_ID,P_ERR_MESSAGE);
          EXCEPTION
            WHEN OTHERS THEN
              NULL; --默认值
          END;
          END LOOP;
        END IF;
      
        <<SUCC_DEPT_LG>>
        UPDATE INTF_CUSTOMER_DEPT
           SET RESPONSETYPE    = 'N',
               RESPNOSECODE    = '000000',
               RESPONSEMESSAGE = P_MESSAGE,
               OPERSTATUS      = '0'
         WHERE ID = DEPT.ID;
      
      EXCEPTION
        WHEN OTHERS THEN
        
          ROLLBACK;
          --记录出错信息
          P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_CUSTOMER_INTF.P_CUSTOMER_INTF_PROCF_INSERT_OR_UPDATE_DEPT',
                                              SQLCODE,
                                              '插入客户事业部表失败！：' || SQLERRM);
          UPDATE INTF_CUSTOMER_DEPT
             SET RESPONSETYPE    = 'E',
                 RESPNOSECODE    = '000013',
                 RESPONSEMESSAGE = P_MESSAGE,
                 OPERSTATUS      = '1'
           WHERE ID = DEPT.ID;
          --RAISE V_BIZ_EXCEPTION;
      END;
    END LOOP;
    
    IF V_ERR_MSG IS NOT NULL THEN
      IF V_ERR_MSG LIKE '%没有推送（包括历史）事业部的有效OU%' THEN
        BEGIN
          P_CUSTOMER_INTF_PROC(P_INTF_HEADER_ID_LIST => P_INTF_HEAD_ID
          ,P_MESSAGE => P_ERR_MESSAGE,IS_CTRL_PARAM => 'NOTGTWIDTHANDNODEPT');
          EXCEPTION WHEN OTHERS THEN
            NULL;
          END;
      END IF;
      RETURN V_ERR_MSG;
    END IF;
    RETURN P_MESSAGE;
  END;

  FUNCTION F_INSERT_OR_UPDATE_ADDRESS
  --更新或插入客户地址业务表
  (P_INTF_HEAD_ID number --客户头ID
   ) return varchar2 is
  
    V_CUST_ADDRESS_COUNT  NUMBER; --业务表中地址的数量
    V_CUST_ACC_ADDR_COUNT NUMBER; --业务表中客户地址在账户地址中的数量
    P_MESSAGE             VARCHAR2(1000);
    P_ERROR_MESSAGE       VARCHAR2(1000);
    V_S_CUSTOMER_ADDRESS  NUMBER; --存序列
    V_ENTITY_ID           NUMBER; --主体ID
    V_CUSTOMER_ID         NUMBER; --客户ID
    V_DEPT_ID             NUMBER; --事业部ID
    V_DEPT_CODE           VARCHAR2(100); --事业部编码
    V_CUSTOMER_CODE       VARCHAR2(100); --客户编码
  
    V_ACCOUNT_COUNT NUMBER; --客户账户数量
    V_ACCOUNT_CODE  VARCHAR2(100); --账户编码
    V_ACCOUNT_ID    NUMBER; --账户ID
    V_DISTRICT_CODE VARCHAR2(32); --区域编码
  
    CURSOR C_INTF_CUSTOMER_ADDRESS IS
      SELECT *
        FROM INTF_CUSTOMER_ADDRESS
       WHERE PRE_FIELD_01 = P_INTF_HEAD_ID;
    address INTF_CUSTOMER_ADDRESS%ROWTYPE;
   TYPE T_INTF_ADDR IS TABLE OF INTF_CUSTOMER_ADDRESS%ROWTYPE
   INDEX BY BINARY_INTEGER
   ;
   V_INTF_ADDR T_INTF_ADDR;
   V_INDEX     NUMBER;
  BEGIN
    P_MESSAGE := 'SUCCESS';
    --查看主数据客户头ID是否存在
    OPEN C_INTF_CUSTOMER_ADDRESS;
    FETCH C_INTF_CUSTOMER_ADDRESS BULK COLLECT INTO V_INTF_ADDR;
    CLOSE C_INTF_CUSTOMER_ADDRESS;
    V_INDEX := (V_INTF_ADDR.FIRST - 1);
    LOOP
      <<loop_here>>
      V_INDEX := (1 + V_INDEX);
      IF V_INDEX IS NULL OR V_INDEX > V_INTF_ADDR.LAST THEN
        EXIT;
      END IF;
      address := V_INTF_ADDR(V_INDEX);
      BEGIN
        P_MESSAGE := null;
        --地址进行校验
        if ('Inactive' <> address.active_flag) then
          FOR LI IN (SELECT D.DISTRICT_CODE,D.FULL_NAME,D.ACTIVE_FLAG,D.LEVEL_SEQ
            ,MAX(D1.DISTRICT_CODE) OVER (PARTITION BY D1.ROW_ID
            ORDER BY DECODE(D.ACTIVE_FLAG, 'Y', 0, 1),DECODE(D1.ACTIVE_FLAG, 'Y', 0, 1)) AS P_DISTRICT_CODE
            ,MAX(D1.DISTRICT_NAME) OVER (PARTITION BY D1.ROW_ID
            ORDER BY DECODE(D.ACTIVE_FLAG, 'Y', 0, 1),DECODE(D1.ACTIVE_FLAG, 'Y', 0, 1)) AS P_DISTRICT_NAME
            ,DECODE(D.LEVEL_SEQ,1,'国家地区编码',2,'省份编码',3,'地级市编码',4,'县区编码',5,'乡镇编码') AS D_KIND
            ,DECODE(D.LEVEL_SEQ,1,NULL,2,'国家地区编码',3,'省份编码',4,'地级市编码',5,'县区编码') AS P_D_KIND
            ,MAX(D2.DISTRICT_CODE) OVER (PARTITION BY D2.ROW_ID
            ORDER BY DECODE(D.ACTIVE_FLAG, 'Y', 0, 1),DECODE(D2.ACTIVE_FLAG, 'Y', 0, 1)) AS P_DISTRICT_CODE1
            ,MAX(D2.DISTRICT_NAME) OVER (PARTITION BY D2.ROW_ID
            ORDER BY DECODE(D.ACTIVE_FLAG, 'Y', 0, 1),DECODE(D2.ACTIVE_FLAG, 'Y', 0, 1)) AS P_DISTRICT_NAME1
            ,MAX(D2.FULL_NAME) OVER (PARTITION BY D2.ROW_ID
            ORDER BY DECODE(D.ACTIVE_FLAG, 'Y', 0, 1),DECODE(D2.ACTIVE_FLAG, 'Y', 0, 1)) AS P_FULL_NAME1
            FROM T_BD_DISTRICT D LEFT JOIN T_BD_DISTRICT D1
            ON (D.PAR_ROW_ID = D1.ROW_ID) LEFT JOIN T_BD_DISTRICT D2
            ON (D2.DISTRICT_CODE = DECODE(D.LEVEL_SEQ,1,NULL,2,NULL,3,ADDRESS.PROVINCE,4,ADDRESS.CITY,5,ADDRESS.AREA))
            WHERE D.DISTRICT_CODE IN (
            ADDRESS.PROVINCE,ADDRESS.CITY,ADDRESS.AREA,ADDRESS.TOWNS) ORDER BY D.LEVEL_SEQ) LOOP
            IF 'Y' <> LI.ACTIVE_FLAG THEN
               P_MESSAGE := '客户地址' || LI.D_KIND || LI.DISTRICT_CODE
              || '[' || LI.FULL_NAME || ']'|| '不是有效状态';
            ELSIF LI.P_DISTRICT_CODE1 IS NOT NULL AND LI.P_DISTRICT_CODE <> LI.P_DISTRICT_CODE1 THEN
              P_MESSAGE := '客户地址' || LI.D_KIND || LI.DISTRICT_CODE
              || '[' || LI.FULL_NAME || ']'
              || '的上级行政区域' || LI.P_D_KIND || LI.P_DISTRICT_CODE
              || '[' || LI.P_DISTRICT_NAME || ']'
              || '，与客户地址的上级编码' || LI.P_DISTRICT_CODE1
              || '[' || LI.P_FULL_NAME1 || ']' || '不一致';
            END IF;
          END LOOP;
          /*if address.city is not null and address.province is not null and
             1 <> instr(address.city, address.province) then
            P_MESSAGE := '客户地址地级市编码' || address.city || '必须以省份编码开头';
          end if;
          if address.area is not null and address.city is not null and
             1 <> instr(address.area, address.city) then
            P_MESSAGE := '客户地址县区编码' || address.area || '必须以地级市编码开头';
          end if;
          if address.towns is not null and address.area is not null then
            select max(t1.district_code) over(order by decode(t.active_flag, 'Y', 0, 1), decode(t1.active_flag, 'Y', 0, 1))
              INTO V_DISTRICT_CODE
              from t_bd_district t
             inner join t_bd_district t1
                on (t.par_row_id = t1.row_id and
                   address.towns = t.district_code);
            IF V_DISTRICT_CODE <> address.area THEN
              P_MESSAGE := '客户地址乡镇编码' || address.towns || '必须以县区编码' ||
                           V_DISTRICT_CODE || '开头';
            END IF;
          end if;*/
        end if;
        if (P_MESSAGE is not null) then
          P_ERROR_MESSAGE := P_MESSAGE;
          UPDATE INTF_CUSTOMER_ADDRESS
             SET RESPONSETYPE    = 'E',
                 RESPNOSECODE    = '000013',
                 RESPONSEMESSAGE = P_MESSAGE,
                 ERROR_INFO      = P_MESSAGE,
                 OPERSTATUS      = '1'
           WHERE ADDRESS_ID = address.address_id;
        end if;
      
        SELECT count(0), max(ADDRESS_ID)
          INTO V_CUST_ADDRESS_COUNT, V_S_CUSTOMER_ADDRESS
          FROM T_CUSTOMER_ADDRESS
         WHERE SIEBEL_ADDRESS_ID = address.Siebel_Address_Id;
        /*         (SELECT SIEBEL_ADDRESS_ID
         FROM INTF_CUSTOMER_ADDRESS
        WHERE PRE_FIELD_01 = P_INTF_HEAD_ID);*/
      
        --取客户和主体
        SELECT dept.dept_id,
               dept.CUSTOMER_ID,
               dept.CUSTOMER_CODE,
               dept.dept_code,
               dept.id
          INTO V_ENTITY_ID,
               V_CUSTOMER_ID,
               V_CUSTOMER_CODE,
               V_DEPT_CODE,
               V_DEPT_ID
          FROM T_CUSTOMER_DEPT dept
         WHERE dept.SIEBEL_ID = address.parent_id;
        --如果不存在，则插入
        IF (V_CUST_ADDRESS_COUNT = 0) and (P_MESSAGE is null) THEN
          --取序列
          SELECT S_CUSTOMER_ADDRESS.NEXTVAL
            INTO V_S_CUSTOMER_ADDRESS
            FROM DUAL;
        
          INSERT INTO T_CUSTOMER_ADDRESS
            (ADDRESS_ID,
             ENTITY_ID,
             CUSTOMER_ID,
             CUSTOMER_CODE,
             DEPT_ID,
             DEPT_CODE,
             COUNTRY,
             PROVINCE,
             CITY,
             AREA,
             TOWNS,
             ADDRESS,
             ADDRESS_COMMENTS,
             IS_MAIN,
             CONTACTS_ID,
             CONTACTS_NAME,
             CONTACTS_PHONES,
             ADDRESS_TYPE,
             ACTIVE_FLAG,
             CREATED_BY,
             CREATION_DATE,
             LAST_UPDATE_DATE,
             LAST_UPDATE_BY,
             LAST_INTERFACE_DATE,
             SIEBEL_ADDRESS_ID,
             SIEBEL_CUSTOMER_ID,
             PRE_FIELD_01,
             PRE_FIELD_02,
             PRE_FIELD_03,
             PRE_FIELD_04,
             PRE_FIELD_05,
             PRE_FIELD_06,
             PARENT_ID)
          VALUES
            (V_S_CUSTOMER_ADDRESS, --ADDRESS_ID,
             V_ENTITY_ID, --(SELECT dept.dept_id FROM T_CUSTOMER_DEPT dept WHERE dept.SIEBEL_ID = address.parent_id),-- ENTITY_ID,
             V_CUSTOMER_ID, --(SELECT dept.CUSTOMER_ID FROM T_CUSTOMER_DEPT dept WHERE dept.siebel_id = address.parent_id),-- CUSTOMER_ID,
             V_CUSTOMER_CODE, --(SELECT dept.CUSTOMER_CODE FROM T_CUSTOMER_DEPT dept WHERE dept.siebel_id = address.parent_id),-- CUSTOMER_CODE,
             V_ENTITY_ID, -- DEPT_ID,
             V_DEPT_CODE, -- DEPT_CODE,
             address.COUNTRY,
             address.PROVINCE,
             address.CITY,
             address.AREA,
             address.TOWNS,
             address.ADDRESS,
             address.ADDRESS_COMMENTS,
             address.IS_MAIN,
             NVL((SELECT NVL(con.contacts_id, 0)
                   FROM T_CUSTOMER_CONTACTS con
                  WHERE con.siebel_contacts_id =
                        to_char(NVL(address.contacts_id, '0'))),
                 0), -- CONTACTS_ID,
             address.CONTACTS_NAME,
             address.CONTACTS_PHONES,
             address.ADDRESS_TYPE,
             NVL(address.ACTIVE_FLAG, 'Active'),
             address.CREATED_BY,
             address.CREATION_DATE,
             address.LAST_UPDATE_DATE,
             address.LAST_UPDATE_BY,
             address.LAST_INTERFACE_DATE,
             address.SIEBEL_ADDRESS_ID,
             address.SIEBEL_CUSTOMER_ID,
             address.PRE_FIELD_01,
             address.PRE_FIELD_02,
             address.PRE_FIELD_03,
             address.PRE_FIELD_04,
             address.PRE_FIELD_05,
             address.PRE_FIELD_06,
             V_DEPT_ID); -- PARENT_ID
        
          /*        FROM INTF_CUSTOMER_ADDRESS intf
          WHERE intf.PRE_FIELD_01 = P_INTF_HEAD_ID;*/
        ELSIF (V_CUST_ADDRESS_COUNT <> 0) THEN
          UPDATE T_CUSTOMER_ADDRESS a
             SET (ENTITY_ID,
                  CUSTOMER_ID,
                  CUSTOMER_CODE,
                  DEPT_ID,
                  DEPT_CODE,
                  COUNTRY,
                  PROVINCE,
                  CITY,
                  AREA,
                  TOWNS,
                  ADDRESS,
                  ADDRESS_COMMENTS,
                  IS_MAIN,
                  CONTACTS_ID,
                  CONTACTS_NAME,
                  CONTACTS_PHONES,
                  ADDRESS_TYPE,
                  ACTIVE_FLAG,
                  CREATED_BY,
                  CREATION_DATE,
                  LAST_UPDATE_DATE,
                  LAST_UPDATE_BY,
                  LAST_INTERFACE_DATE,
                  SIEBEL_ADDRESS_ID,
                  SIEBEL_CUSTOMER_ID,
                  PRE_FIELD_01,
                  PRE_FIELD_02,
                  PRE_FIELD_03,
                  PRE_FIELD_04,
                  PRE_FIELD_05,
                  PRE_FIELD_06,
                  PARENT_ID) =
                 (SELECT
                  --(SELECT unit.entity_id FROM UP_ORG_UNIT unit WHERE unit.code =  (SELECT dept.DEPT_CODE FROM T_CUSTOMER_DEPT dept WHERE dept.siebel_id = intf.parent_id)) ENTITY_ID,
                   V_ENTITY_ID,
                   V_CUSTOMER_ID,
                   V_CUSTOMER_CODE,
                   V_ENTITY_ID,
                   V_DEPT_CODE,
                   decode(P_MESSAGE, null, address.COUNTRY, a.COUNTRY),
                   decode(P_MESSAGE, null, address.PROVINCE, a.PROVINCE),
                   decode(P_MESSAGE, null, address.CITY, a.CITY),
                   decode(P_MESSAGE, null, address.AREA, a.AREA),
                   decode(P_MESSAGE, null, address.TOWNS, a.TOWNS),
                   address.ADDRESS,
                   address.ADDRESS_COMMENTS,
                   decode(P_MESSAGE, null, address.IS_MAIN, a.IS_MAIN),
                   NVL((SELECT NVL(con.contacts_id, 0)
                         FROM T_CUSTOMER_CONTACTS con
                        WHERE con.siebel_contacts_id =
                              to_char(NVL(address.contacts_id, '0'))),
                       0) CONTACTS_ID,
                   address.CONTACTS_NAME,
                   address.CONTACTS_PHONES,
                   address.ADDRESS_TYPE,
                   NVL(address.ACTIVE_FLAG, 'Active'),
                   address.CREATED_BY,
                   address.CREATION_DATE,
                   address.LAST_UPDATE_DATE,
                   address.LAST_UPDATE_BY,
                   address.LAST_INTERFACE_DATE,
                   address.SIEBEL_ADDRESS_ID,
                   address.SIEBEL_CUSTOMER_ID,
                   address.PRE_FIELD_01,
                   address.PRE_FIELD_02,
                   address.PRE_FIELD_03,
                   address.PRE_FIELD_04,
                   address.PRE_FIELD_05,
                   address.PRE_FIELD_06,
                   V_DEPT_ID
                    FROM DUAL)
           WHERE Siebel_Address_Id = address.siebel_address_id;
          /*  FROM INTF_CUSTOMER_ADDRESS intf
                 WHERE intf.PRE_FIELD_01 = P_INTF_HEAD_ID
                 AND intf.Siebel_Address_Id = address.siebel_address_id)
                 WHERE EXISTS (SELECT 1 from INTF_CUSTOMER_ADDRESS intfx WHERE intfx.PRE_FIELD_01 = P_INTF_HEAD_ID AND intfx.Siebel_Address_Id = address.siebel_address_id);
          */ --COMMIT;
        END IF;
      
        --无效的地址能不能insert 缺少主要地址不检查
        --更新账户地址的状态，必须更新否则需要删除账户地址再重新选
        if (0 < V_CUST_ADDRESS_COUNT) then
          update T_CUSTOMER_ACCOUNT_ADDRESS addr
             set addr.active_flag = address.active_flag,
                 addr.is_default  = nvl(address.is_main, 'N')
           where addr.address_id = V_S_CUSTOMER_ADDRESS
             and addr.entity_id = V_ENTITY_ID
             and exists
           (select 1
                    from T_CUSTOMER_ACCOUNT acc
                   where acc.account_id = addr.account_id
                     and acc.customer_id = V_CUSTOMER_ID);
          V_CUST_ACC_ADDR_COUNT := sql%rowcount;
        end if;
      
        --如果检验有错误
        IF (P_MESSAGE is not null) THEN
          goto loop_here;
        END IF;
        if ('Active' = address.active_flag) and
           ((0 = V_CUST_ADDRESS_COUNT) or (0 = V_CUST_ACC_ADDR_COUNT)) then
          --如果该客户该主体下只存在一个账户，则把这个地址分配到这个账户上面
          select count(0)
            into V_ACCOUNT_COUNT
            from T_CUSTOMER_ACCOUNT acc
           where acc.customer_id = V_CUSTOMER_ID
             and acc.entity_id = V_ENTITY_ID
             and acc.account_status = '1';
        
          IF (V_ACCOUNT_COUNT = 1) THEN
            select acc.account_id, acc.account_code
              into V_ACCOUNT_ID, V_ACCOUNT_CODE
              from T_CUSTOMER_ACCOUNT acc
             where acc.customer_id = V_CUSTOMER_ID
               and acc.entity_id = V_ENTITY_ID
               and acc.account_status = '1';
          
            INSERT INTO T_CUSTOMER_ACCOUNT_ADDRESS
              (ACCOUNT_ADDRESS_ID,
               ENTITY_ID,
               ACCOUNT_ID,
               ACCOUNT_CODE,
               ADDRESS_ID,
               LAST_UPDATE_DATE,
               ACTIVE_FLAG,
               APPROVE_STATUS,
               IS_DEFAULT)
            VALUES
              (S_CUSTOMER_ACCOUNT_ADDRESS.NEXTVAL,
               V_ENTITY_ID,
               V_ACCOUNT_ID,
               V_ACCOUNT_CODE,
               V_S_CUSTOMER_ADDRESS,
               SYSDATE,
               address.active_flag,
               '1',
               nvl(address.is_main, 'N'));
          
          END IF;
        END IF;
      
        UPDATE INTF_CUSTOMER_ADDRESS
           SET RESPONSETYPE    = 'N',
               RESPNOSECODE    = '000000',
               RESPONSEMESSAGE = 'SUCCESS',
               OPERSTATUS      = '0'
         WHERE ADDRESS_ID = address.address_id;
      EXCEPTION
        WHEN OTHERS THEN
        
          ROLLBACK;
          --记录出错信息
          P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_CUSTOMER_INTF.P_CUSTOMER_INTF_PROC.F_INSERT_OR_UPDATE_ADDRESS',
                                              SQLCODE,
                                              '插入客户地址表失败！：' || SQLERRM);
          UPDATE INTF_CUSTOMER_ADDRESS
             SET RESPONSETYPE    = 'E',
                 RESPNOSECODE    = '000013',
                 RESPONSEMESSAGE = P_MESSAGE,
                 OPERSTATUS      = '1'
           WHERE ADDRESS_ID = address.address_id;
          --RAISE V_BIZ_EXCEPTION;
      END;
    END LOOP;
  
    IF P_ERROR_MESSAGE is not null THEN
      RETURN P_ERROR_MESSAGE;
    END IF;
    P_MESSAGE := 'SUCCESS';
    RETURN P_MESSAGE;
  END;

  FUNCTION F_INSERT_OR_UPDATE_CONTACTS
  --更新或插入客户联系人业务表
  (P_INTF_HEAD_ID number --客户头ID
   ) return varchar2 IS
    V_CUST_CONTACTS_COUNT NUMBER; --业务表中的联系人数量
    P_MESSAGE             VARCHAR2(500);
  
    CURSOR C_INTF_CUSTOMER_CONTACTS IS
      SELECT *
        FROM INTF_CUSTOMER_CONTACTS
       WHERE PRE_FIELD_01 = P_INTF_HEAD_ID;
   /*TYPE T_INTF_CONTACTS IS TABLE OF INTF_CUSTOMER_CONTACTS%ROWTYPE
   INDEX BY BINARY_INTEGER
   ;
   V_INTF_CONTACTS T_INTF_CONTACTS;
   V_INDEX     NUMBER;*/
  
  BEGIN
    P_MESSAGE := 'SUCCESS';
    --查看主数据客户头ID是否存在
    FOR contacts IN C_INTF_CUSTOMER_CONTACTS LOOP
    
      BEGIN
        SELECT COUNT(0)
          INTO V_CUST_CONTACTS_COUNT
          FROM T_CUSTOMER_CONTACTS
         WHERE SIEBEL_CONTACTS_ID = contacts.Siebel_Contacts_Id;
        /*           (SELECT SIEBEL_CONTACTS_ID
         FROM INTF_CUSTOMER_CONTACTS
        WHERE PRE_FIELD_01 = P_INTF_HEAD_ID);*/
      
        IF (V_CUST_CONTACTS_COUNT = 0) THEN
          INSERT INTO T_CUSTOMER_CONTACTS
            (CONTACTS_ID,
             ENTITY_ID,
             CUSTOMER_ID,
             CUSTOMER_CODE,
             DEPT_ID,
             DEPT_CODE,
             CONTACTS_POSITION,
             CONTACTS_NAME,
             CONTACTS_PHONES,
             CONTACTS_MAIL,
             ACTIVE_FLAG,
             CREATED_BY,
             CREATION_DATE,
             LAST_UPDATE_DATE,
             LAST_UPDATE_BY,
             LAST_INTERFACE_DATE,
             SIEBEL_CONTACTS_ID,
             SIEBEL_CUSTOMER_ID,
             PRE_FIELD_01,
             PRE_FIELD_02,
             PRE_FIELD_03,
             PRE_FIELD_04,
             PRE_FIELD_05,
             PRE_FIELD_06,
             PARENT_ID)
          VALUES
            (
             --SELECT
             S_CUSTOMER_CONTACTS.NEXTVAL, -- CONTACTS_ID,
             --(SELECT unit.entity_id FROM UP_ORG_UNIT unit WHERE unit.code =  (SELECT dept.DEPT_CODE FROM T_CUSTOMER_DEPT dept WHERE dept.siebel_id = intf.parent_id)) ENTITY_ID,
             (SELECT dept.dept_id
                FROM T_CUSTOMER_DEPT dept
               WHERE dept.SIEBEL_ID = contacts.parent_id), -- ENTITY_ID,
             (SELECT dept.CUSTOMER_ID
                FROM T_CUSTOMER_DEPT dept
               WHERE dept.siebel_id = contacts.parent_id), -- CUSTOMER_ID,
             (SELECT dept.CUSTOMER_CODE
                FROM T_CUSTOMER_DEPT dept
               WHERE dept.siebel_id = contacts.parent_id), -- CUSTOMER_CODE,
             (SELECT dept.DEPT_ID
                FROM T_CUSTOMER_DEPT dept
               WHERE dept.siebel_id = contacts.parent_id), -- DEPT_ID,
             (SELECT dept.DEPT_CODE
                FROM T_CUSTOMER_DEPT dept
               WHERE dept.siebel_id = contacts.parent_id), -- DEPT_CODE,
             contacts.CONTACTS_POSITION,
             contacts.CONTACTS_NAME,
             contacts.CONTACTS_PHONES,
             contacts.CONTACTS_MAIL,
             NVL(contacts.ACTIVE_FLAG, 'Active'),
             contacts.CREATED_BY,
             contacts.CREATION_DATE,
             contacts.LAST_UPDATE_DATE,
             contacts.LAST_UPDATE_BY,
             contacts.LAST_INTERFACE_DATE,
             contacts.SIEBEL_CONTACTS_ID,
             contacts.SIEBEL_CUSTOMER_ID,
             contacts.PRE_FIELD_01,
             contacts.PRE_FIELD_02,
             contacts.PRE_FIELD_03,
             contacts.PRE_FIELD_04,
             contacts.PRE_FIELD_05,
             contacts.PRE_FIELD_06,
             (SELECT dept.id
                FROM T_CUSTOMER_DEPT dept
               WHERE dept.siebel_id = contacts.parent_id)); --PARENT_ID
          /*      FROM INTF_CUSTOMER_CONTACTS intf
          WHERE intf.PRE_FIELD_01 = P_INTF_HEAD_ID;*/
        
        ELSE
          UPDATE T_CUSTOMER_CONTACTS
             SET (ENTITY_ID,
                  CUSTOMER_ID,
                  CUSTOMER_CODE,
                  DEPT_ID,
                  DEPT_CODE,
                  CONTACTS_POSITION,
                  CONTACTS_NAME,
                  CONTACTS_PHONES,
                  CONTACTS_MAIL,
                  ACTIVE_FLAG,
                  CREATED_BY,
                  CREATION_DATE,
                  LAST_UPDATE_DATE,
                  LAST_UPDATE_BY,
                  LAST_INTERFACE_DATE,
                  SIEBEL_CONTACTS_ID,
                  SIEBEL_CUSTOMER_ID,
                  PRE_FIELD_01,
                  PRE_FIELD_02,
                  PRE_FIELD_03,
                  PRE_FIELD_04,
                  PRE_FIELD_05,
                  PRE_FIELD_06,
                  PARENT_ID) =
                 (SELECT
                  --(SELECT unit.entity_id FROM UP_ORG_UNIT unit WHERE unit.code =  (SELECT dept.DEPT_CODE FROM T_CUSTOMER_DEPT dept WHERE dept.siebel_id = intf.parent_id)) ENTITY_ID,
                   (SELECT dept.dept_id
                      FROM T_CUSTOMER_DEPT dept
                     WHERE dept.SIEBEL_ID = contacts.parent_id) ENTITY_ID,
                   (SELECT dept.CUSTOMER_ID
                      FROM T_CUSTOMER_DEPT dept
                     WHERE dept.siebel_id = contacts.parent_id) CUSTOMER_ID,
                   (SELECT dept.CUSTOMER_CODE
                      FROM T_CUSTOMER_DEPT dept
                     WHERE dept.siebel_id = contacts.parent_id) CUSTOMER_CODE,
                   (SELECT dept.DEPT_ID
                      FROM T_CUSTOMER_DEPT dept
                     WHERE dept.siebel_id = contacts.parent_id) DEPT_ID,
                   (SELECT dept.DEPT_CODE
                      FROM T_CUSTOMER_DEPT dept
                     WHERE dept.siebel_id = contacts.parent_id) DEPT_CODE,
                   contacts.CONTACTS_POSITION,
                   contacts.CONTACTS_NAME,
                   contacts.CONTACTS_PHONES,
                   contacts.CONTACTS_MAIL,
                   NVL(contacts.ACTIVE_FLAG, 'Active'),
                   contacts.CREATED_BY,
                   contacts.CREATION_DATE,
                   contacts.LAST_UPDATE_DATE,
                   contacts.LAST_UPDATE_BY,
                   contacts.LAST_INTERFACE_DATE,
                   contacts.SIEBEL_CONTACTS_ID,
                   contacts.SIEBEL_CUSTOMER_ID,
                   contacts.PRE_FIELD_01,
                   contacts.PRE_FIELD_02,
                   contacts.PRE_FIELD_03,
                   contacts.PRE_FIELD_04,
                   contacts.PRE_FIELD_05,
                   contacts.PRE_FIELD_06,
                   (SELECT dept.id
                      FROM T_CUSTOMER_DEPT dept
                     WHERE dept.siebel_id = contacts.parent_id) PARENT_ID
                    FROM DUAL)
           WHERE siebel_contacts_id = contacts.siebel_contacts_id;
          /*FROM INTF_CUSTOMER_CONTACTS intf
                 WHERE intf.PRE_FIELD_01 = P_INTF_HEAD_ID
                 AND intf.siebel_contacts_id = contacts.siebel_contacts_id)
                 WHERE EXISTS (SELECT 1 from INTF_CUSTOMER_CONTACTS intfx  WHERE intfx.PRE_FIELD_01 = P_INTF_HEAD_ID AND intfx.siebel_contacts_id = contacts.siebel_contacts_id);
          */
        END IF;
      
        UPDATE INTF_CUSTOMER_CONTACTS
           SET RESPONSETYPE    = 'N',
               RESPNOSECODE    = '000000',
               RESPONSEMESSAGE = P_MESSAGE,
               OPERSTATUS      = '0'
         WHERE CONTACTS_ID = contacts.Contacts_Id;
      EXCEPTION
        WHEN OTHERS THEN
        
          ROLLBACK;
          --记录出错信息
          P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_CUSTOMER_INTF.P_CUSTOMER_INTF_PROC.F_INSERT_OR_UPDATE_CONTACTS',
                                              SQLCODE,
                                              '插入客户联系人表失败！：' || SQLERRM);
          UPDATE INTF_CUSTOMER_CONTACTS
             SET RESPONSETYPE    = 'E',
                 RESPNOSECODE    = '000013',
                 RESPONSEMESSAGE = P_MESSAGE,
                 OPERSTATUS      = '1'
           WHERE CONTACTS_ID = contacts.Contacts_Id;
          --RAISE V_BIZ_EXCEPTION;
      END;
    END LOOP;
    ---COMMIT;
    RETURN P_MESSAGE;
  END;

  FUNCTION F_INSERT_OR_UPDATE_BANK
  --更新或插入客户联系人业务表
  (P_INTF_HEAD_ID number --客户头ID
   ) return varchar2 IS
    V_CUST_BANK_COUNT NUMBER; --业务表中的银行数量
    P_MESSAGE         VARCHAR2(500);
  
    CURSOR C_INTF_CUSTOMER_BANK IS
      SELECT * FROM INTF_CUSTOMER_BANK WHERE PRE_FIELD_01 = P_INTF_HEAD_ID;
   /*TYPE T_INTF_BANK IS TABLE OF INTF_CUSTOMER_BANK%ROWTYPE
   INDEX BY BINARY_INTEGER
   ;
   V_INTF_BANK T_INTF_BANK;
   V_INDEX     NUMBER;*/
  
  BEGIN
    P_MESSAGE := 'SUCCESS';
    --查看主数据客户头ID是否存在
    FOR bank IN C_INTF_CUSTOMER_BANK LOOP
      BEGIN
        SELECT COUNT(0)
          INTO V_CUST_BANK_COUNT
          FROM T_CUSTOMER_BANK
         WHERE SIEBEL_BANK_ID = bank.siebel_bank_id;
        /*           (SELECT SIEBEL_BANK_ID
         FROM INTF_CUSTOMER_BANK
        WHERE PRE_FIELD_01 = P_INTF_HEAD_ID);*/
      
        IF (V_CUST_BANK_COUNT = 0) THEN
          INSERT INTO T_CUSTOMER_BANK
            (BANK_ID,
             ENTITY_ID,
             CUSTOMER_ID,
             CUSTOMER_CODE,
             DEPT_ID,
             DEPT_CODE,
             BANK,
             BRANCH,
             ACCOUNTS_NAME,
             BANK_ACCOUNT,
             ACTIVE_FLAG,
             CREATED_BY,
             CREATION_DATE,
             LAST_UPDATE_DATE,
             LAST_UPDATE_BY,
             LAST_INTERFACE_DATE,
             SIEBEL_BANK_ID,
             SIEBEL_CUSTOMER_ID,
             PRE_FIELD_01,
             PRE_FIELD_02,
             PRE_FIELD_03,
             PRE_FIELD_04,
             PRE_FIELD_05,
             PRE_FIELD_06,
             PARENT_ID,
             SSA_PRIMARY_FIELD)
          --SELECT
          VALUES
            (S_CUSTOMER_BANK.NEXTVAL, --BANK_ID,
             --(SELECT unit.entity_id FROM UP_ORG_UNIT unit WHERE unit.code =  (SELECT dept.DEPT_CODE FROM T_CUSTOMER_DEPT dept WHERE dept.siebel_id = intf.parent_id)) ENTITY_ID,
             (SELECT dept.dept_id
                FROM T_CUSTOMER_DEPT dept
               WHERE dept.SIEBEL_ID = bank.parent_id), -- ENTITY_ID,
             (SELECT dept.CUSTOMER_ID
                FROM T_CUSTOMER_DEPT dept
               WHERE dept.siebel_id = bank.parent_id), -- CUSTOMER_ID,
             (SELECT dept.CUSTOMER_CODE
                FROM T_CUSTOMER_DEPT dept
               WHERE dept.siebel_id = bank.parent_id), -- CUSTOMER_CODE,
             (SELECT dept.DEPT_ID
                FROM T_CUSTOMER_DEPT dept
               WHERE dept.siebel_id = bank.parent_id), -- DEPT_ID,
             (SELECT dept.DEPT_CODE
                FROM T_CUSTOMER_DEPT dept
               WHERE dept.siebel_id = bank.parent_id), -- DEPT_CODE,
             bank.BANK,
             bank.BRANCH,
             bank.ACCOUNTS_NAME,
             bank.BANK_ACCOUNT,
             NVL(bank.ACTIVE_FLAG, 'Active'),
             bank.CREATED_BY,
             bank.CREATION_DATE,
             bank.LAST_UPDATE_DATE,
             bank.LAST_UPDATE_BY,
             bank.LAST_INTERFACE_DATE,
             bank.SIEBEL_BANK_ID,
             bank.SIEBEL_CUSTOMER_ID,
             bank.PRE_FIELD_01,
             bank.PRE_FIELD_02,
             bank.PRE_FIELD_03,
             bank.PRE_FIELD_04,
             bank.PRE_FIELD_05,
             bank.PRE_FIELD_06,
             (SELECT dept.id
                FROM T_CUSTOMER_DEPT dept
               WHERE dept.siebel_id = bank.parent_id), -- PARENT_ID,
             bank.SSA_PRIMARY_FIELD);
          /*          FROM INTF_CUSTOMER_BANK intf
          WHERE intf.PRE_FIELD_01 = P_INTF_HEAD_ID;*/
        
        ELSE
          UPDATE T_CUSTOMER_BANK
             SET (ENTITY_ID,
                  CUSTOMER_ID,
                  CUSTOMER_CODE,
                  DEPT_ID,
                  DEPT_CODE,
                  BANK,
                  BRANCH,
                  ACCOUNTS_NAME,
                  BANK_ACCOUNT,
                  ACTIVE_FLAG,
                  CREATED_BY,
                  CREATION_DATE,
                  LAST_UPDATE_DATE,
                  LAST_UPDATE_BY,
                  LAST_INTERFACE_DATE,
                  SIEBEL_BANK_ID,
                  SIEBEL_CUSTOMER_ID,
                  PRE_FIELD_01,
                  PRE_FIELD_02,
                  PRE_FIELD_03,
                  PRE_FIELD_04,
                  PRE_FIELD_05,
                  PRE_FIELD_06,
                  PARENT_ID,
                  SSA_PRIMARY_FIELD) =
                 (SELECT
                  --(SELECT unit.entity_id FROM UP_ORG_UNIT unit WHERE unit.code =  (SELECT dept.DEPT_CODE FROM T_CUSTOMER_DEPT dept WHERE dept.siebel_id = intf.parent_id)) ENTITY_ID,
                   (SELECT dept.dept_id
                      FROM T_CUSTOMER_DEPT dept
                     WHERE dept.SIEBEL_ID = bank.parent_id) ENTITY_ID,
                   (SELECT dept.CUSTOMER_ID
                      FROM T_CUSTOMER_DEPT dept
                     WHERE dept.siebel_id = bank.parent_id) CUSTOMER_ID,
                   (SELECT dept.CUSTOMER_CODE
                      FROM T_CUSTOMER_DEPT dept
                     WHERE dept.siebel_id = bank.parent_id) CUSTOMER_CODE,
                   (SELECT dept.DEPT_ID
                      FROM T_CUSTOMER_DEPT dept
                     WHERE dept.siebel_id = bank.parent_id) DEPT_ID,
                   (SELECT dept.DEPT_CODE
                      FROM T_CUSTOMER_DEPT dept
                     WHERE dept.siebel_id = bank.parent_id) DEPT_CODE,
                   bank.BANK,
                   bank.BRANCH,
                   bank.ACCOUNTS_NAME,
                   bank.BANK_ACCOUNT,
                   NVL(bank.ACTIVE_FLAG, 'Active'),
                   bank.CREATED_BY,
                   bank.CREATION_DATE,
                   bank.LAST_UPDATE_DATE,
                   bank.LAST_UPDATE_BY,
                   bank.LAST_INTERFACE_DATE,
                   bank.SIEBEL_BANK_ID,
                   bank.SIEBEL_CUSTOMER_ID,
                   bank.PRE_FIELD_01,
                   bank.PRE_FIELD_02,
                   bank.PRE_FIELD_03,
                   bank.PRE_FIELD_04,
                   bank.PRE_FIELD_05,
                   bank.PRE_FIELD_06,
                   (SELECT dept.id
                      FROM T_CUSTOMER_DEPT dept
                     WHERE dept.siebel_id = bank.parent_id) PARENT_ID,
                   bank.SSA_PRIMARY_FIELD
                    FROM DUAL)
           WHERE siebel_bank_id = bank.siebel_bank_id;
          /*FROM INTF_CUSTOMER_BANK intf
                       WHERE intf.PRE_FIELD_01 = P_INTF_HEAD_ID
                       AND intf.siebel_bank_id = bank.siebel_bank_id)
                        WHERE EXISTS (SELECT 1 from INTF_CUSTOMER_BANK intfx  WHERE intfx.PRE_FIELD_01 = P_INTF_HEAD_ID AND intfx.siebel_bank_id = bank.siebel_bank_id);
          */
        END IF;
        UPDATE INTF_CUSTOMER_BANK
           SET RESPONSETYPE    = 'N',
               RESPNOSECODE    = '000000',
               RESPONSEMESSAGE = P_MESSAGE,
               OPERSTATUS      = '1'
         WHERE BANK_ID = bank.bank_id;
      EXCEPTION
        WHEN OTHERS THEN
        
          ROLLBACK;
          --记录出错信息
          P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_CUSTOMER_INTF.P_CUSTOMER_INTF_PROC.F_INSERT_OR_UPDATE_BANK',
                                              SQLCODE,
                                              '插入银行业务表失败！：' || SQLERRM);
          UPDATE INTF_CUSTOMER_BANK
             SET RESPONSETYPE    = 'E',
                 RESPNOSECODE    = '000013',
                 RESPONSEMESSAGE = P_MESSAGE,
                 OPERSTATUS      = '1'
           WHERE BANK_ID = bank.bank_id;
          --RAISE V_BIZ_EXCEPTION;
      END;
    END LOOP;
    RETURN P_MESSAGE;
  END;

  FUNCTION F_INSERT_OR_UPDATE_BRAND
  --更新或插入客户联系人业务表
  (P_INTF_HEAD_ID number --客户头ID
   ) return varchar2 IS
    V_CUST_BRAND               T_CUSTOMER_BRAND%ROWTYPE; --
    V_CUST_BRAND_SALES_CODE    T_CUSTOMER_BRAND.Sales_Main_Type_Code%TYPE; --业务表中的银行数量
    brand                      INTF_CUSTOMER_BRAND%ROWTYPE;
    dept                       T_CUSTOMER_DEPT%ROWTYPE;
    V_COUNT                    NUMBER;
    V_ACTIVE_COOPERATION_MODEL T_CUSTOMER_BRAND.COOPERATION_MODEL%TYPE;
    P_MESSAGE                  VARCHAR2(500);
    P_ERR_MESSAGE            VARCHAR2(2000);--本次错误
    V_SALES_MAIN_TYPE_NAME     VARCHAR2(100);
    V_SALES_MAIN_TYPE_NAME_CL  VARCHAR2(100);
    V_CLASS_MAIN_IS_PMT        VARCHAR(100);
    V_SALES_MAIN_CNT1          NUMBER; --业务表中的营销大类数量
    V_SALES_MAIN_CNT2          NUMBER; --业务表中的营销大类数量
    VN_RESULT                  NUMBER;
    VN_CREDIT_GROUP_ID         NUMBER;
    VV_INIT       VARCHAR2(100);
    V_COUNT_S                  NUMBER;
    V_ACTIVE_COOPERATION_MODEL_S       T_CUSTOMER_BRAND.COOPERATION_MODEL%TYPE;
  
    CURSOR C_INTF_CUSTOMER_BRAND IS
      WITH T1 AS (SELECT *
  FROM INTF_CUSTOMER_BRAND I
 WHERE PRE_FIELD_01 = P_INTF_HEAD_ID)
, T2 AS (SELECT I.*
  FROM INTF_CUSTOMER_BRAND I
 WHERE TO_NUMBER(PRE_FIELD_01) < P_INTF_HEAD_ID AND I.RESPONSETYPE <> 'N' AND I.RESPNOSECODE = 'MAYNOERR' AND I.ACTIVE_FLAG = 'Active'
 AND EXISTS (SELECT 1 FROM T1 WHERE T1.PARENT_ID = I.PARENT_ID
 --
  AND T1.ACTIVE_FLAG <> 'Active' AND I.BRAND_CODE = T1.BRAND_CODE AND I.SALES_MAIN_TYPE_CODE = T1.SALES_MAIN_TYPE_CODE
  --AND I.COOPERATION_MODEL <> T1.COOPERATION_MODEL
 ) AND NOT EXISTS (SELECT 1 FROM T1 WHERE I.SIEBEL_BRAND_ID = T1.SIEBEL_BRAND_ID AND I.ACTIVE_FLAG = T1.ACTIVE_FLAG)
 )
,T3 AS (SELECT T2.PARENT_ID,MAX(TO_NUMBER(T2.PRE_FIELD_01)) AS LAST_PRE_FIELD_01 FROM T2 GROUP BY T2.PARENT_ID)
,T4 AS (SELECT T1.* FROM T1
UNION ALL
SELECT T2.* FROM T2 INNER JOIN T3 ON (T3.PARENT_ID = T2.PARENT_ID AND T2.PRE_FIELD_01 = T3.LAST_PRE_FIELD_01))
SELECT * FROM T4 ORDER BY TO_NUMBER(T4.PRE_FIELD_01) DESC,
          DECODE(T4.ACTIVE_FLAG,
                 'Inactive',
                 0,
                 'Deleted',
                 0,
                 'Freezing',
                 1,
                 'Active',
                 99,
                 2)
      /*SELECT *
        FROM INTF_CUSTOMER_BRAND I
       WHERE PRE_FIELD_01 = P_INTF_HEAD_ID
       ORDER BY DECODE(I.Active_Flag,
                       'Inactive',
                       0,
                       'Deleted',
                       0,
                       'Freezing',
                       1,
                       'Active',
                       99,
                       2)*/;
   TYPE T_INTF_BRAND IS TABLE OF INTF_CUSTOMER_BRAND%ROWTYPE
   INDEX BY BINARY_INTEGER
   ;
   V_INTF_BRAND T_INTF_BRAND;
   V_INDEX     NUMBER;
  
  BEGIN
    P_MESSAGE := 'SUCCESS';
    --查看主数据客户头ID是否存在
    OPEN C_INTF_CUSTOMER_BRAND;
    FETCH C_INTF_CUSTOMER_BRAND BULK COLLECT INTO V_INTF_BRAND;
    CLOSE C_INTF_CUSTOMER_BRAND;
    V_INDEX := (V_INTF_BRAND.FIRST - 1);
    LOOP
      <<LP_INTF_BRAND>>
      V_INDEX := (1 + V_INDEX);
      IF V_INDEX IS NULL OR V_INDEX > V_INTF_BRAND.LAST THEN
        EXIT;
      END IF;
      BRAND := V_INTF_BRAND(V_INDEX);
      P_MESSAGE := 'SUCCESS';
      BEGIN
        SELECT D.*
          INTO dept
          FROM T_CUSTOMER_DEPT D
         WHERE D.SIEBEL_ID = brand.parent_id;
        BEGIN
          V_CUST_BRAND            := NULL;
          V_CUST_BRAND_SALES_CODE := NULL;
          SELECT *
            INTO V_CUST_BRAND
            FROM T_CUSTOMER_BRAND
           WHERE SIEBEL_BRAND_ID = brand.Siebel_Brand_Id;
          V_CUST_BRAND_SALES_CODE := V_CUST_BRAND.SALES_MAIN_TYPE_CODE;
        EXCEPTION
          WHEN OTHERS THEN
            NULL;
        END;
      
        IF (V_CUST_BRAND_SALES_CODE IS NULL) THEN
          INSERT INTO T_CUSTOMER_BRAND
            (BRAND_ID,
             ENTITY_ID,
             CUSTOMER_ID,
             CUSTOMER_CODE,
             DEPT_ID,
             DEPT_CODE,
             BRAND_CODE,
             CUSTOMER_LEVEL,
             CUSTOMER_CREDIT_LEVEL,
             CREDIT_LINE,
             COOPERATION_MODEL,
             ACTIVE_FLAG,
             CREATED_BY,
             CREATION_DATE,
             LAST_UPDATE_DATE,
             LAST_UPDATE_BY,
             LAST_INTERFACE_DATE,
             SIEBEL_BRAND_ID,
             SIEBEL_CUSTOMER_ID,
             PRE_FIELD_01,
             PRE_FIELD_02,
             PRE_FIELD_03,
             PRE_FIELD_04,
             PRE_FIELD_05,
             PRE_FIELD_06,
             SALES_MAIN_TYPE_CODE,
             PARENT_ID)
          VALUES
            (
             --/*SELECT*/
             S_CUSTOMER_BRAND.NEXTVAL, -- BRAND_ID,
             --(SELECT unit.entity_id FROM UP_ORG_UNIT unit WHERE unit.code =  (SELECT dept.DEPT_CODE FROM T_CUSTOMER_DEPT dept WHERE dept.siebel_id = intf.parent_id)) ENTITY_ID,
             dept.dept_id, -- ENTITY_ID,
             dept.CUSTOMER_ID, -- CUSTOMER_ID,
             dept.CUSTOMER_CODE, -- CUSTOMER_CODE,
             dept.dept_id, -- DEPT_ID,
             dept.DEPT_CODE, -- DEPT_CODE,
             brand.BRAND_CODE,
             brand.CUSTOMER_LEVEL,
             brand.CUSTOMER_CREDIT_LEVEL,
             brand.CREDIT_LINE,
             brand.COOPERATION_MODEL,
             NVL(brand.ACTIVE_FLAG, 'Active'),
             brand.CREATED_BY,
             brand.CREATION_DATE,
             brand.LAST_UPDATE_DATE,
             brand.LAST_UPDATE_BY,
             brand.LAST_INTERFACE_DATE,
             brand.SIEBEL_BRAND_ID,
             brand.SIEBEL_CUSTOMER_ID,
             brand.PRE_FIELD_01,
             brand.PRE_FIELD_02,
             brand.PRE_FIELD_03,
             brand.PRE_FIELD_04,
             brand.PRE_FIELD_05,
             brand.PRE_FIELD_06,
             brand.SALES_MAIN_TYPE_CODE,
             (SELECT dept.id
                FROM T_CUSTOMER_DEPT dept
               WHERE dept.siebel_id = brand.parent_id)); -- PARENT_ID
        
          /*          FROM INTF_CUSTOMER_BRAND intf
          WHERE intf.PRE_FIELD_01 = P_INTF_HEAD_ID;*/
        
        ELSE
          UPDATE T_CUSTOMER_BRAND
             SET (ENTITY_ID,
                  CUSTOMER_ID,
                  CUSTOMER_CODE,
                  DEPT_ID,
                  DEPT_CODE,
                  BRAND_CODE,
                  COOPERATION_MODEL,
                  ACTIVE_FLAG,
                  CREATED_BY,
                  CREATION_DATE,
                  LAST_UPDATE_DATE,
                  LAST_UPDATE_BY,
                  LAST_INTERFACE_DATE,
                  SIEBEL_BRAND_ID,
                  SIEBEL_CUSTOMER_ID,
                  PRE_FIELD_01,
                  PRE_FIELD_02,
                  PRE_FIELD_03,
                  PRE_FIELD_04,
                  PRE_FIELD_05,
                  PRE_FIELD_06,
                  SALES_MAIN_TYPE_CODE,
                  PARENT_ID) =
                 (SELECT
                  -- (SELECT unit.entity_id FROM UP_ORG_UNIT unit WHERE unit.code =  (SELECT dept.DEPT_CODE FROM T_CUSTOMER_DEPT dept WHERE dept.siebel_id = intf.parent_id)) ENTITY_ID,
                   dept.dept_id       ENTITY_ID,
                   dept.CUSTOMER_ID   CUSTOMER_ID,
                   dept.CUSTOMER_CODE CUSTOMER_CODE,
                   dept.dept_id       DEPT_ID,
                   dept.DEPT_CODE     DEPT_CODE,
                   brand.BRAND_CODE,
                   
                   brand.COOPERATION_MODEL,
                   NVL(brand.ACTIVE_FLAG, 'Active'),
                   brand.CREATED_BY,
                   brand.CREATION_DATE,
                   brand.LAST_UPDATE_DATE,
                   brand.LAST_UPDATE_BY,
                   brand.LAST_INTERFACE_DATE,
                   brand.SIEBEL_BRAND_ID,
                   brand.SIEBEL_CUSTOMER_ID,
                   brand.PRE_FIELD_01,
                   brand.PRE_FIELD_02,
                   brand.PRE_FIELD_03,
                   brand.PRE_FIELD_04,
                   brand.PRE_FIELD_05,
                   brand.PRE_FIELD_06,
                   brand.SALES_MAIN_TYPE_CODE,
                   (SELECT dept.id
                      FROM T_CUSTOMER_DEPT dept
                     WHERE dept.siebel_id = brand.parent_id) PARENT_ID
                    FROM DUAL)
           WHERE siebel_brand_id = brand.siebel_brand_id;
          /* FROM INTF_CUSTOMER_BRAND intf
                       WHERE intf.PRE_FIELD_01 = P_INTF_HEAD_ID
                       AND intf.siebel_brand_id = brand.siebel_brand_id)
                       WHERE EXISTS (SELECT 1 from INTF_CUSTOMER_BRAND intfx  WHERE intfx.PRE_FIELD_01 = P_INTF_HEAD_ID AND intfx.siebel_brand_id = brand.siebel_brand_id);
          */
        END IF;
        --2016-4-13 仅为有效时判断
        --IF 'Active' = brand.active_flag THEN
        /*DECODE(BRAND_CODE,brand.brand_code,DECODE(ACTIVE_FLAG, 'Active', COOPERATION_MODEL, NULL
        , NULL)*/
          SELECT COUNT( DECODE(BRAND_CODE,brand.brand_code,DECODE(ACTIVE_FLAG, 'Active', 0, NULL)
                 , NULL) ),
                 MAX( DECODE(ACTIVE_FLAG, 'Active',
                 --COOPERATION_MODEL
                 DECODE(BRAND_CODE,brand.brand_code,COOPERATION_MODEL, NULL)
                 , NULL)
                 )
                 ,COUNT(DECODE(ACTIVE_FLAG, 'Active', 0, NULL)),
                 MAX( DECODE(ACTIVE_FLAG, 'Active', COOPERATION_MODEL, NULL) )
            INTO V_COUNT, V_ACTIVE_COOPERATION_MODEL, V_COUNT_S, V_ACTIVE_COOPERATION_MODEL_S
            FROM T_CUSTOMER_BRAND
           WHERE ENTITY_ID = dept.dept_id
             AND CUSTOMER_ID = dept.customer_id
             --AND BRAND_CODE = brand.brand_code
             AND SALES_MAIN_TYPE_CODE = brand.sales_main_type_code;
          --ENTITY_ID CUSTOMER_ID BRAND_CODE SALES_MAIN_TYPE_CODE COOPERATION_MODEL ACTIVE_FLAG
          V_ACTIVE_COOPERATION_MODEL := NVL(V_ACTIVE_COOPERATION_MODEL,V_ACTIVE_COOPERATION_MODEL_S);
          IF 1 < V_COUNT THEN
            ROLLBACK;
            UPDATE INTF_CUSTOMER_BRAND
            SET RESPONSETYPE    = 'E',
            RESPNOSECODE    = 'MAYNOERR',
            RESPONSEMESSAGE = '客户同一主体、品牌、大类不能存在多条有效的经营品牌',
            OPERSTATUS      = '1'
            WHERE BRAND_ID = brand.brand_id;
            GOTO LP_INTF_BRAND;
          END IF;
        --END IF;
      
        BEGIN
          SELECT IC.CLASS_NAME,IC.PROMOTION_FLAG,CODELIST.CODE_NAME
            INTO V_SALES_MAIN_TYPE_NAME,V_CLASS_MAIN_IS_PMT,V_SALES_MAIN_TYPE_NAME_CL
            FROM T_BD_ITEM_CLASS IC
           LEFT JOIN UP_CODELIST codelist
              ON (codelist.code_value = IC.CLASS_CODE AND
                 codelist.codetype = 'MIDEA_ACCOUNT_PROD_TYPE')
           WHERE IC.CLASS_CODE = brand.sales_main_type_code
             AND IC.ENTITY_ID = dept.dept_id
             AND IC.CLASS_TYPE = 'M'
             AND IC.ACTIVE_FLAG = 'Y';
          IF V_SALES_MAIN_TYPE_NAME_CL IS NULL THEN
            ROLLBACK;
            UPDATE INTF_CUSTOMER_BRAND
               SET RESPONSETYPE    = 'E',
                   RESPNOSECODE    = '000002',
                   RESPONSEMESSAGE = '营销大类在CRM推送码表不存在，ENTITY_ID='
                   || dept.dept_id || '，大类编码：' || brand.sales_main_type_code
                   || '，码值：MIDEA_ACCOUNT_PROD_TYPE',
                   OPERSTATUS      = '1'
             WHERE BRAND_ID = brand.brand_id;
            GOTO LP_INTF_BRAND;
          /*ELSIF V_SALES_MAIN_TYPE_NAME_CL <> V_SALES_MAIN_TYPE_NAME THEN
            ROLLBACK;
            UPDATE INTF_CUSTOMER_BRAND
               SET RESPONSETYPE    = 'E',
                   RESPNOSECODE    = '000002',
                   RESPONSEMESSAGE = '营销大类在CRM推送码表的名称与在T_BD_ITEM_CLASS的名称不一致，ENTITY_ID='
                   || dept.dept_id || '，大类编码：' || brand.sales_main_type_code,
                   OPERSTATUS      = '1'
             WHERE BRAND_ID = brand.brand_id;
            COMMIT;
            GOTO LP_INTF_BRAND;*/
          END IF;
        EXCEPTION
          WHEN OTHERS THEN
            ROLLBACK;
            UPDATE INTF_CUSTOMER_BRAND
               SET RESPONSETYPE    = 'E',
                   RESPNOSECODE    = '000002',
                   RESPONSEMESSAGE = '营销大类在T_BD_ITEM_CLASS不存在（甚至可能是“CRM推送码表或T_BD_ITEM_CLASS”重复），ENTITY_ID='
                   || dept.dept_id || '，大类编码：' || brand.sales_main_type_code,
                   OPERSTATUS      = '1'
             WHERE BRAND_ID = brand.brand_id;
            GOTO LP_INTF_BRAND;
        END;
        
        UPDATE INTF_CUSTOMER_BRAND
           SET RESPONSETYPE    = 'N',
               RESPNOSECODE    = '000000',
               RESPONSEMESSAGE = P_MESSAGE,
               OPERSTATUS      = '0'
         WHERE BRAND_ID = brand.brand_id;
        
        SELECT count(DECODE(mtype.sales_main_type_code,
                            nvl(V_CUST_BRAND_SALES_CODE,
                                brand.sales_main_type_code),
                            0)) --需要插入或更新的记录
              ,
               count(DECODE(mtype.sales_main_type_code,
                            (CASE
                              WHEN V_CUST_BRAND_SALES_CODE <> brand.sales_main_type_code THEN
                               brand.sales_main_type_code
                              ELSE
                               NULL
                            END),
                            0)) --当更改大类时已存在的记录
          INTO V_SALES_MAIN_CNT1, V_SALES_MAIN_CNT2
          FROM T_CUSTOMER_SALES_MAIN_TYPE mtype
         WHERE mtype.custom_code = dept.CUSTOMER_CODE
           AND mtype.entity_id = dept.dept_id;
      
        if (0 = V_SALES_MAIN_CNT1) then
          INSERT INTO T_CUSTOMER_SALES_MAIN_TYPE
            (SALES_MAIN_TYPE_ID,
             ENTITY_ID,
             CUSTOM_ID,
             CUSTOM_CODE,
             DEPT_ID,
             DEPT_CODE,
             SALES_MAIN_TYPE_NAME,
             COOPERATION_MODEL_ID,
             ACTIVE_FLAG,
             CREATED_BY,
             CREATION_DATE,
             LAST_UPDATE_DATE,
             LAST_UPDATE_BY,
             LAST_INTERFACE_DATE,
             SALES_MAIN_TYPE_CODE,
             PARENT_ID,
             CUSTOMER_NAME)
          VALUES
            (S_CUSTOMER_SALES_MAIN_TYPE.NEXTVAL,
             dept.dept_id,
             dept.CUSTOMER_ID,
             dept.CUSTOMER_CODE,
             dept.dept_id,
             dept.DEPT_CODE,
             V_SALES_MAIN_TYPE_NAME,
             brand.cooperation_model,
             NVL(brand.Active_Flag, 'Active'),
             brand.created_by,
             brand.creation_date,
             brand.last_update_date,
             brand.last_update_by,
             brand.last_interface_date,
             brand.sales_main_type_code,
             dept.id,
             NVL((SELECT H.CUSTOMER_NAME
                               FROM T_CUSTOMER_HEADER H
                              WHERE H.CUSTOMER_ID = DEPT.CUSTOMER_ID),
                             NVL(''||DEPT.CUSTOMER_ID, DEPT.CUSTOMER_CODE))
             );
        elsif (0 = V_SALES_MAIN_CNT2) then
          --主数据对经营品牌如果不做校验控制，客户同一个品牌、大类存在多条有效数据的情况
          update T_CUSTOMER_SALES_MAIN_TYPE mtype
             set LAST_UPDATE_DATE     = brand.last_update_date,
                 LAST_UPDATE_BY       = brand.last_update_by,
                 LAST_INTERFACE_DATE  = brand.last_interface_date,
                 SALES_MAIN_TYPE_NAME = V_SALES_MAIN_TYPE_NAME,
                 sales_main_type_code = brand.sales_main_type_code,
                 --ACTIVE_FLAG = NVL(brand.Active_Flag,'Active'),
                 ACTIVE_FLAG = DECODE(V_COUNT,
                                      1,
                                      'Active',
                                      NVL(brand.Active_Flag, 'Active')),
                 --cooperation_model_id = brand.cooperation_model
                 cooperation_model_id = DECODE(V_COUNT,
                                               1,
                                               V_ACTIVE_COOPERATION_MODEL,
                                               brand.cooperation_model),
                 CUSTOMER_NAME = NVL((SELECT H.CUSTOMER_NAME
                               FROM T_CUSTOMER_HEADER H
                              WHERE H.CUSTOMER_ID = DEPT.CUSTOMER_ID),
                             NVL(''||DEPT.CUSTOMER_ID, DEPT.CUSTOMER_CODE))
           WHERE mtype.sales_main_type_code =
                 nvl(V_CUST_BRAND_SALES_CODE, brand.sales_main_type_code)
             AND mtype.custom_code = dept.CUSTOMER_CODE
             AND mtype.entity_id = dept.dept_id;
        
        else
          update T_CUSTOMER_SALES_MAIN_TYPE mtype
             set LAST_UPDATE_DATE    = brand.last_update_date,
                 LAST_UPDATE_BY      = brand.last_update_by,
                 LAST_INTERFACE_DATE = brand.last_interface_date,
                 ACTIVE_FLAG         = 'Inactive',
                 CUSTOMER_NAME = NVL((SELECT H.CUSTOMER_NAME
                               FROM T_CUSTOMER_HEADER H
                              WHERE H.CUSTOMER_ID = DEPT.CUSTOMER_ID),
                             NVL(''||DEPT.CUSTOMER_ID, DEPT.CUSTOMER_CODE))
           WHERE mtype.sales_main_type_code = V_CUST_BRAND_SALES_CODE
             AND mtype.custom_code = dept.CUSTOMER_CODE
             AND mtype.entity_id = dept.dept_id;
        
          update T_CUSTOMER_SALES_MAIN_TYPE mtype
             set LAST_UPDATE_DATE     = brand.last_update_date,
                 LAST_UPDATE_BY       = brand.last_update_by,
                 LAST_INTERFACE_DATE  = brand.last_interface_date,
                 SALES_MAIN_TYPE_NAME = V_SALES_MAIN_TYPE_NAME,
                 sales_main_type_code = brand.sales_main_type_code,
                 ACTIVE_FLAG          = DECODE(V_COUNT,
                                               1,
                                               'Active',
                                               NVL(brand.Active_Flag,
                                                   'Active')),
                 cooperation_model_id = DECODE(V_COUNT,
                                               1,
                                               V_ACTIVE_COOPERATION_MODEL,
                                               brand.cooperation_model),
                 CUSTOMER_NAME = NVL((SELECT H.CUSTOMER_NAME
                               FROM T_CUSTOMER_HEADER H
                              WHERE H.CUSTOMER_ID = DEPT.CUSTOMER_ID),
                             NVL(''||DEPT.CUSTOMER_ID, DEPT.CUSTOMER_CODE))
           WHERE mtype.sales_main_type_code = brand.sales_main_type_code
             AND mtype.custom_code = dept.CUSTOMER_CODE
             AND mtype.entity_id = dept.dept_id;
        
        end if;
        IF (0 < V_COUNT_S) THEN
          UPDATE T_CUSTOMER_SALES_MAIN_TYPE S
          SET S.ACTIVE_FLAG = 'Active',
          S.COOPERATION_MODEL_ID = V_ACTIVE_COOPERATION_MODEL,
          S.LAST_UPDATE_BY = BRAND.LAST_UPDATE_BY,
          S.LAST_UPDATE_DATE = BRAND.LAST_UPDATE_DATE,
          S.LAST_INTERFACE_DATE = BRAND.LAST_INTERFACE_DATE
          WHERE S.ENTITY_ID = DEPT.DEPT_ID
          AND S.CUSTOM_ID = DEPT.CUSTOMER_ID
          AND S.SALES_MAIN_TYPE_CODE = BRAND.SALES_MAIN_TYPE_CODE
          AND (S.ACTIVE_FLAG IS NULL OR 'Active' <> S.ACTIVE_FLAG)
          ;
        END IF;
          
        --2017-04-28 生成信用额度客户信息表
          BEGIN
          PKG_CREDIT_SETTING.P_CREDIT_CUSTOMER_INIT(dept.dept_id,DEPT.CUSTOMER_ID
          ,BRAND.SALES_MAIN_TYPE_CODE,NULL,P_ERR_MESSAGE);
          EXCEPTION
            WHEN OTHERS THEN
              NULL; --默认值
          END;
          VV_INIT := 'Y';
          BEGIN
            PKG_BD.P_GET_PARAMETER_VALUE('CUST_ACCOUNT_CREDIT_AMOUNT_INIT',
                                         DEPT.DEPT_ID,
                                         NULL,
                                         NULL,
                                         VV_INIT);
          EXCEPTION
            WHEN OTHERS THEN
              VV_INIT := 'Y'; --默认值
          END;
        
        IF 'Y' = VV_INIT AND 'Active' = brand.Active_Flag
          AND (V_CLASS_MAIN_IS_PMT IS NULL OR V_CLASS_MAIN_IS_PMT <> 'Y') THEN
      
          /*SELECT COUNT(0) INTO VN_RESULT
          FROM DUAL
          WHERE 1 = NVL((SELECT MIN(DECODE(A.CREATED_BY,'INTF',1,0))
          FROM T_CUSTOMER_ACCOUNT A WHERE A.ENTITY_ID = DEPT.DEPT_ID
          AND A.CUSTOMER_ID = DEPT.CUSTOMER_ID),0)
          ;
          --当存在全部是推送初始化的账户，自动初始化该大类的客户款项
          IF 0 < VN_RESULT THEN*/
            BEGIN
                PKG_CREDIT_ACCOUNT_CONTROL.PRC_CREDIT_ACC_AMOUNT_INIT(dept.dept_id
                ,dept.Customer_Id,NULL,NULL,NULL,'CRM_BRAND_INIT',VN_RESULT,P_ERR_MESSAGE);
                --,dept.Customer_Id,NULL,NULL,brand.Sales_Main_Type_Code,'CRM_BRAND_INIT',VN_RESULT,P_ERR_MESSAGE);
            EXCEPTION
              WHEN OTHERS THEN
                      P_ERR_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_CUSTOMER_INTF.F_INSERT_OR_UPDATE_BRAND',
                                                  SQLCODE,
                                                  '初始化客户款项失败！：' || P_ERR_MESSAGE || SQLERRM);
            END;
          --END IF;
          
          --梁颜明 2017 5 26
          /*FOR GL IN (
          SELECT G.CREDIT_GROUP_ID FROM T_CREDIT_CATEGORY_GROUP_REL T,T_CREDIT_GROUP G
          WHERE G.CREDIT_GROUP_ID = T.CREDIT_GROUP_ID
          AND T.SALES_MAIN_TYPE = BRAND.SALES_MAIN_TYPE_CODE
          AND G.ENTITY_ID = DEPT.DEPT_ID) LOOP
            FOR LI IN (
              SELECT M.ACCOUNT_ID
            FROM T_SALES_ACCOUNT_AMOUNT M
            WHERE M.ENTITY_ID = DEPT.DEPT_ID AND M.CUSTOMER_ID = DEPT.CUSTOMER_ID
            GROUP BY M.ACCOUNT_ID
            --对已存在的账户，如果已经存在该大类其他额度组的客户款项，但是不存在该大类所在额度组的客户款项，自动初始化
            HAVING 0 = MAX(DECODE(M.CREDIT_GROUP_ID,GL.CREDIT_GROUP_ID,1,0))
            )
            LOOP
              BEGIN
                  PKG_CREDIT_ACCOUNT_CONTROL.PRC_CREDIT_ACC_AMOUNT_INIT(dept.dept_id
                  ,dept.Customer_Id,LI.ACCOUNT_ID,NULL,brand.Sales_Main_Type_Code,'CRM_BRAND_INIT',VN_RESULT,P_ERR_MESSAGE);
              EXCEPTION
                WHEN OTHERS THEN
                        P_ERR_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_CUSTOMER_INTF.F_INSERT_OR_UPDATE_BRAND',
                                                    SQLCODE,
                                                    '初始化客户款项失败！：' || P_ERR_MESSAGE || SQLERRM);
              END;
            END LOOP;
          END LOOP;*/
        END IF;
        
        BEGIN
          PKG_CREDIT_DOWN_PAY.PRC_CREDIT_ACC_LIMIT_UPDATE(dept.dept_id
          ,dept.customer_id,NULL,'CRM_BRAND_INIT',P_ERR_MESSAGE);
        EXCEPTION
          WHEN OTHERS THEN
                  P_ERR_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_CUSTOMER_INTF.F_INSERT_OR_UPDATE_BRAND',
                                              SQLCODE,
                                              '初始化客户账户额度失败！：' || P_ERR_MESSAGE || SQLERRM);
        END;
      EXCEPTION
        WHEN OTHERS THEN
          ROLLBACK;
          --记录出错信息
          P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_CUSTOMER_INTF.P_CUSTOMER_INTF_PROC.F_INSERT_OR_UPDATE_BRAND',
                                              SQLCODE,
                                              '插入自定义营销大类业务表失败！：' || SQLERRM);
          UPDATE INTF_CUSTOMER_BRAND
             SET RESPONSETYPE    = 'E',
                 RESPNOSECODE    = '000013',
                 RESPONSEMESSAGE = P_MESSAGE,
                 OPERSTATUS      = '1'
           WHERE BRAND_ID = brand.brand_id;
          --RAISE V_BIZ_EXCEPTION;
      END;
    END LOOP;
    RETURN P_MESSAGE;
  END;

  FUNCTION F_INSERT_OR_UPDATE_CHANN_TYPE
  --更新或插入客户联系人业务表
  (P_INTF_HEAD_ID number --客户头ID
   ) return varchar2 IS
    V_CUST_CHANNEL_TYPE_COUNT NUMBER; --业务表中的渠道类型（业态类型）数量
    P_MESSAGE                 VARCHAR2(500);
    V_ERR_MESSAGE             VARCHAR2(500);
  
    V_ACTIVE_CNT NUMBER; --
    dept         T_CUSTOMER_DEPT%ROWTYPE;
    channel      INTF_CUSTOMER_CHANNEL_TYPE%ROWTYPE;
    CURSOR C_INTF_CUSTOMER_CHANNEL_TYPE IS
      SELECT *
        FROM INTF_CUSTOMER_CHANNEL_TYPE I
       WHERE PRE_FIELD_01 = P_INTF_HEAD_ID
       ORDER BY DECODE(I.Active_Flag,
                       'Inactive',
                       0,
                       'Deleted',
                       0,
                       'Freezing',
                       1,
                       'Active',
                       99,
                       2) --, I.CREATION_DATE DESC
      ;
   TYPE T_INTF_CHN_TYPE IS TABLE OF INTF_CUSTOMER_CHANNEL_TYPE%ROWTYPE
   INDEX BY BINARY_INTEGER
   ;
   V_INTF_CHN_TYPE T_INTF_CHN_TYPE;
   V_INDEX     NUMBER;
  
  BEGIN
    P_MESSAGE := 'SUCCESS';
    --查看主数据客户头ID是否存在
    OPEN C_INTF_CUSTOMER_CHANNEL_TYPE;
    FETCH C_INTF_CUSTOMER_CHANNEL_TYPE BULK COLLECT INTO V_INTF_CHN_TYPE;
    CLOSE C_INTF_CUSTOMER_CHANNEL_TYPE;
    V_INDEX := (V_INTF_CHN_TYPE.FIRST - 1);
    LOOP
      <<LP_INTF_CHANNEL_TYPE>>
      V_INDEX := (1 + V_INDEX);
      IF V_INDEX IS NULL OR V_INDEX > V_INTF_CHN_TYPE.LAST THEN
        EXIT;
      END IF;
      channel := V_INTF_CHN_TYPE(V_INDEX);
    
      BEGIN
        SELECT D.*
          INTO dept
          FROM T_CUSTOMER_DEPT D
         WHERE D.SIEBEL_ID = channel.parent_id;
        SELECT COUNT(0)
          INTO V_CUST_CHANNEL_TYPE_COUNT
          FROM T_CUSTOMER_CHANNEL_TYPE
         WHERE SIEBEL_CHANNEL_TYPE_ID = channel.Siebel_Channel_Type_Id;
      
        --2016-4-13 增加校验 因为IT不知道哪个业态类型是有效的 业务也不管这个规则 所以有必要进行校验
        IF 'Active' = channel.Active_Flag THEN
          SELECT COUNT(DECODE(T.ACTIVE_FLAG, 'Active', 0))
            INTO V_ACTIVE_CNT
            FROM T_CUSTOMER_CHANNEL_TYPE T
           WHERE T.ENTITY_ID = DEPT.DEPT_ID
             AND T.CUSTOMER_ID = DEPT.CUSTOMER_ID
             AND T.SIEBEL_CHANNEL_TYPE_ID <> channel.Siebel_Channel_Type_Id;
          IF 0 < V_ACTIVE_CNT THEN
            ROLLBACK;
            IF 0 < V_CUST_CHANNEL_TYPE_COUNT THEN
              UPDATE T_CUSTOMER_CHANNEL_TYPE T
                 SET T.ACTIVE_FLAG = 'Inactive'
               WHERE T.SIEBEL_CHANNEL_TYPE_ID =
                     channel.Siebel_Channel_Type_Id;
            END IF;
            V_ERR_MESSAGE := '同一客户同一主体只能保留最多一个有效的业态类型';
            UPDATE INTF_CUSTOMER_CHANNEL_TYPE
               SET RESPONSETYPE    = 'E',
                   RESPNOSECODE    = '000013',
                   RESPONSEMESSAGE = V_ERR_MESSAGE,
                   OPERSTATUS      = '1'
             WHERE CHANNEL_TYPE_ID = channel.Channel_Type_Id;
            GOTO LP_INTF_CHANNEL_TYPE;
          END IF;
        END IF;
        /*           (SELECT SIEBEL_CHANNEL_TYPE_ID
         FROM INTF_CUSTOMER_CHANNEL_TYPE
        WHERE PRE_FIELD_01 = P_INTF_HEAD_ID);*/
      
        IF (V_CUST_CHANNEL_TYPE_COUNT = 0) THEN
          INSERT INTO T_CUSTOMER_CHANNEL_TYPE
            (CHANNEL_TYPE_ID,
             ENTITY_ID,
             CUSTOMER_ID,
             CUSTOMER_CODE,
             DEPT_ID,
             DEPT_CODE,
             INDUSTRY_TYPE,
             ACTIVE_FLAG,
             CREATED_BY,
             CREATION_DATE,
             LAST_UPDATE_DATE,
             LAST_UPDATE_BY,
             LAST_INTERFACE_DATE,
             SIEBEL_CUSTOMER_ID,
             SIEBEL_CHANNEL_TYPE_ID,
             PRE_FIELD_01,
             PRE_FIELD_02,
             PRE_FIELD_03,
             PRE_FIELD_04,
             PRE_FIELD_05,
             PRE_FIELD_06,
             PARENT_ID)
          --SELECT
          VALUES
            (S_CUSTOMER_CHANNEL_TYPE.Nextval, -- CHANNEL_TYPE_ID,
             --(SELECT unit.entity_id FROM UP_ORG_UNIT unit WHERE unit.code =  (SELECT dept.DEPT_CODE FROM T_CUSTOMER_DEPT dept WHERE dept.siebel_id = intf.parent_id)) ENTITY_ID,
             dept.dept_id, -- ENTITY_ID,
             dept.CUSTOMER_ID, -- CUSTOMER_ID,
             dept.CUSTOMER_CODE, -- CUSTOMER_CODE,
             dept.DEPT_ID, -- DEPT_ID,
             dept.DEPT_CODE, -- DEPT_CODE,
             channel.INDUSTRY_TYPE,
             NVL(channel.ACTIVE_FLAG, 'Active'),
             channel.CREATED_BY,
             channel.CREATION_DATE,
             channel.LAST_UPDATE_DATE,
             channel.LAST_UPDATE_BY,
             channel.LAST_INTERFACE_DATE,
             channel.SIEBEL_CUSTOMER_ID,
             channel.SIEBEL_CHANNEL_TYPE_ID,
             channel.PRE_FIELD_01,
             channel.PRE_FIELD_02,
             channel.PRE_FIELD_03,
             channel.PRE_FIELD_04,
             channel.PRE_FIELD_05,
             channel.PRE_FIELD_06,
             dept.id); -- PARENT_ID
        
          /*
          FROM INTF_CUSTOMER_CHANNEL_TYPE intf
          WHERE intf.PRE_FIELD_01 = P_INTF_HEAD_ID;*/
        
        ELSE
          UPDATE T_CUSTOMER_CHANNEL_TYPE
             SET (ENTITY_ID,
                  CUSTOMER_ID,
                  CUSTOMER_CODE,
                  DEPT_ID,
                  DEPT_CODE,
                  INDUSTRY_TYPE,
                  ACTIVE_FLAG,
                  CREATED_BY,
                  CREATION_DATE,
                  LAST_UPDATE_DATE,
                  LAST_UPDATE_BY,
                  LAST_INTERFACE_DATE,
                  SIEBEL_CUSTOMER_ID,
                  SIEBEL_CHANNEL_TYPE_ID,
                  PRE_FIELD_01,
                  PRE_FIELD_02,
                  PRE_FIELD_03,
                  PRE_FIELD_04,
                  PRE_FIELD_05,
                  PRE_FIELD_06,
                  PARENT_ID) =
                 (SELECT
                  --(SELECT unit.entity_id FROM UP_ORG_UNIT unit WHERE unit.code =  (SELECT dept.DEPT_CODE FROM T_CUSTOMER_DEPT dept WHERE dept.siebel_id = intf.parent_id)) ENTITY_ID,
                   dept.dept_id ENTITY_ID,
                   dept.CUSTOMER_ID CUSTOMER_ID,
                   dept.CUSTOMER_CODE CUSTOMER_CODE,
                   dept.DEPT_ID DEPT_ID,
                   dept.DEPT_CODE DEPT_CODE,
                   channel.INDUSTRY_TYPE,
                   NVL(channel.ACTIVE_FLAG, 'Active'),
                   channel.CREATED_BY,
                   channel.CREATION_DATE,
                   channel.LAST_UPDATE_DATE,
                   channel.LAST_UPDATE_BY,
                   channel.LAST_INTERFACE_DATE,
                   channel.SIEBEL_CUSTOMER_ID,
                   channel.SIEBEL_CHANNEL_TYPE_ID,
                   channel.PRE_FIELD_01,
                   channel.PRE_FIELD_02,
                   channel.PRE_FIELD_03,
                   channel.PRE_FIELD_04,
                   channel.PRE_FIELD_05,
                   channel.PRE_FIELD_06,
                   dept.id PARENT_ID
                    FROM DUAL)
           WHERE siebel_channel_type_id = channel.siebel_channel_type_id;
          /*   FROM INTF_CUSTOMER_CHANNEL_TYPE intf
                    WHERE intf.PRE_FIELD_01 = P_INTF_HEAD_ID
                    AND intf.siebel_channel_type_id = channel.siebel_channel_type_id)
                    WHERE EXISTS (SELECT 1 from INTF_CUSTOMER_CHANNEL_TYPE intfx  WHERE intfx.PRE_FIELD_01 = P_INTF_HEAD_ID  AND intfx.siebel_channel_type_id = channel.siebel_channel_type_id);
          */
        
        END IF;
        UPDATE INTF_CUSTOMER_CHANNEL_TYPE
           SET RESPONSETYPE    = 'N',
               RESPNOSECODE    = '000000',
               RESPONSEMESSAGE = P_MESSAGE,
               OPERSTATUS      = '1'
         WHERE CHANNEL_TYPE_ID = channel.Channel_Type_Id;
      EXCEPTION
        WHEN OTHERS THEN
        
          ROLLBACK;
          --记录出错信息
          P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_CUSTOMER_INTF.P_CUSTOMER_INTF_PROC.F_INSERT_OR_UPDATE_CHANN_TYPE',
                                              SQLCODE,
                                              '插入银行业务表失败！：' || SQLERRM);
          UPDATE INTF_CUSTOMER_CHANNEL_TYPE
             SET RESPONSETYPE    = 'E',
                 RESPNOSECODE    = '000013',
                 RESPONSEMESSAGE = P_MESSAGE,
                 OPERSTATUS      = '1'
           WHERE CHANNEL_TYPE_ID = channel.Channel_Type_Id;
          --RAISE V_BIZ_EXCEPTION;
      END;
    END LOOP;
    RETURN P_MESSAGE;
  END;

  FUNCTION F_INSERT_OR_UPDATE_CONNECTION
  --更新或插入客户联系人业务表
  (P_INTF_HEAD_ID number --客户头ID
   ) return varchar2 IS
    V_CUST_CONNECTION_COUNT NUMBER; --业务表中的关联关系数量
    P_MESSAGE               VARCHAR2(500);
  
    CURSOR C_INTF_CUSTOMER_CONNECTION IS
      SELECT *
        FROM INTF_CUSTOMER_CONNECTION
       WHERE PRE_FIELD_01 = P_INTF_HEAD_ID;
  
  BEGIN
    P_MESSAGE := 'SUCCESS';
    --查看主数据客户头ID是否存在
    FOR connection IN C_INTF_CUSTOMER_CONNECTION LOOP
      BEGIN
        SELECT COUNT(0)
          INTO V_CUST_CONNECTION_COUNT
          FROM T_CUSTOMER_CONNECTION
         WHERE SIEBEL_CONNECTION_ID = connection.Siebel_Connection_Id;
        /*           (SELECT SIEBEL_CONNECTION_ID
         FROM INTF_CUSTOMER_CONNECTION
        WHERE PRE_FIELD_01 = P_INTF_HEAD_ID);*/
      
        IF (V_CUST_CONNECTION_COUNT = 0) THEN
          INSERT INTO T_CUSTOMER_CONNECTION
            (CONNECTION_ID,
             -- ENTITY_ID,
             CUSTOMER_ID,
             CUSTOMER_CODE,
             CONNECTION_RELATION,
             CONNECTION_CUSTOM_CODE,
             ACTIVE_FLAG,
             CREATED_BY,
             CREATION_DATE,
             LAST_UPDATE_DATE,
             LAST_UPDATE_BY,
             LAST_INTERFACE_DATE,
             SIEBEL_CUSTOMER_ID,
             SIEBEL_CONNECTION_ID,
             PRE_FIELD_01,
             PRE_FIELD_02,
             PRE_FIELD_03,
             PRE_FIELD_04,
             PRE_FIELD_05,
             PRE_FIELD_06)
          --SELECT
          VALUES
            (S_CUSTOMER_CONNECTION.Nextval, -- CONNECTION_ID,
             --(SELECT unit.entity_id FROM UP_ORG_UNIT unit WHERE unit.code =  (SELECT dept.DEPT_CODE FROM T_CUSTOMER_DEPT dept WHERE dept.siebel_id = intf.parent_id)) ENTITY_ID,
             (SELECT CUSTOMER_ID
                FROM T_CUSTOMER_HEADER head
               where connection.Customer_Code = head.customer_code), -- CUSTOMER_ID, and head.active_flag = 'Active'
             connection.CUSTOMER_CODE,
             connection.CONNECTION_RELATION,
             connection.CONNECTION_CUSTOM_CODE,
             NVL(connection.ACTIVE_FLAG, 'Active'),
             connection.CREATED_BY,
             connection.CREATION_DATE,
             connection.LAST_UPDATE_DATE,
             connection.LAST_UPDATE_BY,
             connection.LAST_INTERFACE_DATE,
             connection.SIEBEL_CUSTOMER_ID,
             connection.SIEBEL_CONNECTION_ID,
             connection.PRE_FIELD_01,
             connection.PRE_FIELD_02,
             connection.PRE_FIELD_03,
             connection.PRE_FIELD_04,
             connection.PRE_FIELD_05,
             connection.PRE_FIELD_06);
        
          /*
          FROM INTF_CUSTOMER_CONNECTION intf
          WHERE intf.PRE_FIELD_01 = P_INTF_HEAD_ID;*/
        
        ELSE
          UPDATE T_CUSTOMER_CONNECTION
             SET (
                  -- ENTITY_ID,
                  CUSTOMER_ID,
                  CUSTOMER_CODE,
                  CONNECTION_RELATION,
                  CONNECTION_CUSTOM_CODE,
                  ACTIVE_FLAG,
                  CREATED_BY,
                  CREATION_DATE,
                  LAST_UPDATE_DATE,
                  LAST_UPDATE_BY,
                  LAST_INTERFACE_DATE,
                  SIEBEL_CUSTOMER_ID,
                  SIEBEL_CONNECTION_ID,
                  PRE_FIELD_01,
                  PRE_FIELD_02,
                  PRE_FIELD_03,
                  PRE_FIELD_04,
                  PRE_FIELD_05,
                  PRE_FIELD_06) =
                 (SELECT (SELECT CUSTOMER_ID
                            FROM T_CUSTOMER_HEADER head
                           where connection.Customer_Code =
                                 head.customer_code) CUSTOMER_ID, --and head.active_flag = 'Active'
                         connection.CUSTOMER_CODE,
                         connection.CONNECTION_RELATION,
                         connection.CONNECTION_CUSTOM_CODE,
                         NVL(connection.ACTIVE_FLAG, 'Active'),
                         connection.CREATED_BY,
                         connection.CREATION_DATE,
                         connection.LAST_UPDATE_DATE,
                         connection.LAST_UPDATE_BY,
                         connection.LAST_INTERFACE_DATE,
                         connection.SIEBEL_CUSTOMER_ID,
                         connection.SIEBEL_CONNECTION_ID,
                         connection.PRE_FIELD_01,
                         connection.PRE_FIELD_02,
                         connection.PRE_FIELD_03,
                         connection.PRE_FIELD_04,
                         connection.PRE_FIELD_05,
                         connection.PRE_FIELD_06
                    FROM DUAL)
           WHERE siebel_connection_id = connection.siebel_connection_id;
          /* FROM INTF_CUSTOMER_CONNECTION intf
                       WHERE intf.PRE_FIELD_01 = P_INTF_HEAD_ID
                       AND intf.siebel_connection_id = connection.siebel_connection_id)
                       WHERE EXISTS (SELECT 1 from INTF_CUSTOMER_CONNECTION intfx WHERE intfx.PRE_FIELD_01 = P_INTF_HEAD_ID  AND intfx.siebel_connection_id = connection.siebel_connection_id);
          */
        END IF;
        UPDATE INTF_CUSTOMER_CONNECTION
           SET RESPONSETYPE    = 'N',
               RESPNOSECODE    = '000000',
               RESPONSEMESSAGE = P_MESSAGE,
               OPERSTATUS      = '1'
         WHERE CONNECTION_ID = connection.Connection_Id;
      EXCEPTION
        WHEN OTHERS THEN
        
          ROLLBACK;
          --记录出错信息
          P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_CUSTOMER_INTF.P_CUSTOMER_INTF_PROC.F_INSERT_OR_UPDATE_CONNECTION',
                                              SQLCODE,
                                              '插入银行业务表失败！：' || SQLERRM);
          UPDATE INTF_CUSTOMER_CONNECTION
             SET RESPONSETYPE    = 'E',
                 RESPNOSECODE    = '000013',
                 RESPONSEMESSAGE = P_MESSAGE,
                 OPERSTATUS      = '1'
           WHERE CONNECTION_ID = connection.Connection_Id;
          -- RAISE V_BIZ_EXCEPTION;
      END;
    END LOOP;
    RETURN P_MESSAGE;
  END;

  FUNCTION F_INSERT_OR_UPDATE_OU
  --更新或插入客户联系人业务表
  (P_INTF_HEAD_ID number --客户头ID
   ) return varchar2 IS
    V_CUST_OU_COUNT NUMBER; --业务表中的OU信息的数量
    P_MESSAGE       VARCHAR2(500);
    ou              INTF_CUSTOMER_OU%rowtype;
  
    CURSOR C_INTF_CUSTOMER_OU IS
      SELECT * FROM INTF_CUSTOMER_OU WHERE PRE_FIELD_01 = P_INTF_HEAD_ID;
   TYPE T_INTF_OU IS TABLE OF INTF_CUSTOMER_OU%ROWTYPE
   INDEX BY BINARY_INTEGER
   ;
   V_INTF_OU T_INTF_OU;
   V_INDEX     NUMBER;
  
  BEGIN
    UPDATE INTF_CUSTOMER_OU O
       SET O.SIEBEL_CUSTOMER_ID =
           (SELECT head.siebel_customer_id
              FROM INTF_CUSTOMER_HEADER head
             where head.customer_id = O.PRE_FIELD_01)
     WHERE O.PRE_FIELD_01 = P_INTF_HEAD_ID
       AND O.SIEBEL_CUSTOMER_ID IS NULL;
    --查看主数据客户头ID是否存在
    OPEN C_INTF_CUSTOMER_OU;
    FETCH C_INTF_CUSTOMER_OU BULK COLLECT INTO V_INTF_OU;
    CLOSE C_INTF_CUSTOMER_OU;
    V_INDEX := (V_INTF_OU.FIRST - 1);
    LOOP
      <<loop_here>>
      V_INDEX := (1 + V_INDEX);
      IF V_INDEX IS NULL OR V_INDEX > V_INTF_OU.LAST THEN
        EXIT;
      END IF;
      ou := V_INTF_OU(V_INDEX);
      P_MESSAGE := 'SUCCESS';
      BEGIN
        IF 'Inactive' = ou.active_flag THEN
          select count(0)
            INTO V_CUST_OU_COUNT
            from V_UP_CODELIST CL
           where ou.erpou = CL.CODE_VALUE
           AND CL.CODETYPE = 'ar_ou_id';--modify by liangym2 2017-6-14
        ElSE
          select count(distinct d.siebel_id)
            INTO V_CUST_OU_COUNT
            from intf_customer_dept d, V_UP_CODELIST CL,up_org_unit u
           where d.siebel_customer_id =
                 (select h.siebel_customer_id
                    from intf_customer_header ih, t_customer_header h
                   where h.siebel_customer_id = ih.siebel_customer_id
                     and ih.customer_id = P_INTF_HEAD_ID)
             and d.dept_code = u.code
             and u.type_code in ('BU','MC')
             and u.entity_id = CL.ENTITY_ID
             and ou.erpou = CL.CODE_VALUE
             AND CL.CODETYPE = 'ar_ou_id'--modify by liangym2 2017-6-14
             and d.dept_customer_status in ('Active', 'Freezing');
        END IF;
        IF 0 = V_CUST_OU_COUNT THEN
          UPDATE INTF_CUSTOMER_OU
             SET RESPONSETYPE    = 'E',
                 RESPNOSECODE    = '000013',
                 RESPONSEMESSAGE = 'OU在内销不存在:' || ou.erpou || '（如果存在就是相关事业部没有推送、有效）',
                 OPERSTATUS      = '1'
           WHERE ERPOU_ID = ou.erpou_id;
          goto loop_here;
        END IF;
      
        SELECT COUNT(0)
          INTO V_CUST_OU_COUNT
          FROM T_CUSTOMER_OU
         WHERE SIEBEL_ERPOU_ID = ou.siebel_erpou_id;
        /*           (SELECT SIEBEL_ERPOU_ID
         FROM INTF_CUSTOMER_OU
        WHERE PRE_FIELD_01 = P_INTF_HEAD_ID);*/
        /*
                    select *
         from cims.t_customer_ou t
        where exists (select 1
                 from cims.t_customer_dept d, cims.t_inv_organization o
                where d.customer_id = t.customer_id
                and d.dept_id = o.entity_id
                and t.erpou = o.operating_unit)*/
      
        IF (V_CUST_OU_COUNT = 0) THEN
          INSERT INTO T_CUSTOMER_OU
            (ERPOU_ID,
             -- ENTITY_ID,
             CUSTOMER_ID,
             CUSTOMER_CODE,
             ERPOU,
             COUNTRY,
             PROVINCE,
             ADDRESS,
             ACTIVE_FLAG,
             CREATED_BY,
             CREATION_DATE,
             LAST_UPDATE_DATE,
             LAST_UPDATE_BY,
             LAST_INTERFACE_DATE,
             SIEBEL_ERPOU_ID,
             SIEBEL_CUSTOMER_ID,
             PRE_FIELD_01,
             PRE_FIELD_02,
             PRE_FIELD_03,
             PRE_FIELD_04,
             PRE_FIELD_05,
             PRE_FIELD_06)
          --SELECT
          VALUES
            (S_CUSTOMER_OU.NEXTVAL, -- ERPOU_ID,
             --ENTITY_ID,
             (SELECT CUSTOMER_ID
                FROM T_CUSTOMER_HEADER head
               where ou.Customer_Code = head.customer_code), -- CUSTOMER_ID,and head.active_flag = 'Active'
             ou.CUSTOMER_CODE,
             ou.ERPOU,
             ou.COUNTRY,
             ou.PROVINCE,
             ou.ADDRESS,
             NVL(ou.ACTIVE_FLAG, 'Active'),
             ou.CREATED_BY,
             ou.CREATION_DATE,
             ou.LAST_UPDATE_DATE,
             ou.LAST_UPDATE_BY,
             ou.LAST_INTERFACE_DATE,
             ou.SIEBEL_ERPOU_ID,
             ou.SIEBEL_CUSTOMER_ID,
             ou.PRE_FIELD_01,
             ou.PRE_FIELD_02,
             ou.PRE_FIELD_03,
             ou.PRE_FIELD_04,
             ou.PRE_FIELD_05,
             ou.PRE_FIELD_06);
        
          /*          FROM INTF_CUSTOMER_OU intf
          WHERE intf.PRE_FIELD_01 = P_INTF_HEAD_ID;*/
        
        ELSE
          UPDATE T_CUSTOMER_OU
             SET (
                  -- ENTITY_ID,
                  CUSTOMER_ID,
                  CUSTOMER_CODE,
                  ERPOU,
                  COUNTRY,
                  PROVINCE,
                  ADDRESS,
                  ACTIVE_FLAG,
                  CREATED_BY,
                  CREATION_DATE,
                  LAST_UPDATE_DATE,
                  LAST_UPDATE_BY,
                  LAST_INTERFACE_DATE,
                  SIEBEL_ERPOU_ID,
                  SIEBEL_CUSTOMER_ID,
                  PRE_FIELD_01,
                  PRE_FIELD_02,
                  PRE_FIELD_03,
                  PRE_FIELD_04,
                  PRE_FIELD_05,
                  PRE_FIELD_06) =
                 (SELECT (SELECT CUSTOMER_ID
                            FROM T_CUSTOMER_HEADER head
                           where ou.Customer_Code = head.customer_code) CUSTOMER_ID, --and head.active_flag = 'Active'
                         ou.CUSTOMER_CODE,
                         ou.ERPOU,
                         ou.COUNTRY,
                         ou.PROVINCE,
                         ou.ADDRESS,
                         NVL(ou.ACTIVE_FLAG, 'Active'),
                         ou.CREATED_BY,
                         ou.CREATION_DATE,
                         ou.LAST_UPDATE_DATE,
                         ou.LAST_UPDATE_BY,
                         ou.LAST_INTERFACE_DATE,
                         ou.SIEBEL_ERPOU_ID,
                         ou.SIEBEL_CUSTOMER_ID,
                         ou.PRE_FIELD_01,
                         ou.PRE_FIELD_02,
                         ou.PRE_FIELD_03,
                         ou.PRE_FIELD_04,
                         ou.PRE_FIELD_05,
                         ou.PRE_FIELD_06
                    FROM DUAL)
           WHERE siebel_erpou_id = ou.siebel_erpou_id;
          /* FROM INTF_CUSTOMER_OU intf
                       WHERE intf.PRE_FIELD_01 = P_INTF_HEAD_ID
                       AND intf.siebel_erpou_id = ou.siebel_erpou_id)
                       WHERE EXISTS (SELECT 1 from INTF_CUSTOMER_OU intfx  WHERE intfx.PRE_FIELD_01 = P_INTF_HEAD_ID  AND intfx.siebel_erpou_id = ou.siebel_erpou_id);
          */
        END IF;
        UPDATE INTF_CUSTOMER_OU
           SET RESPONSETYPE    = 'N',
               RESPNOSECODE    = '000000',
               RESPONSEMESSAGE = P_MESSAGE,
               OPERSTATUS      = '1'
         WHERE ERPOU_ID = ou.erpou_id;
      EXCEPTION
        WHEN OTHERS THEN
        
          ROLLBACK;
          --记录出错信息
          P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_CUSTOMER_INTF.P_CUSTOMER_INTF_PROC.F_INSERT_OR_UPDATE_OU',
                                              SQLCODE,
                                              '插入OU失败！：' || SQLERRM);
          UPDATE INTF_CUSTOMER_OU
             SET RESPONSETYPE    = 'E',
                 RESPNOSECODE    = '000013',
                 RESPONSEMESSAGE = P_MESSAGE,
                 OPERSTATUS      = '1'
           WHERE ERPOU_ID = ou.erpou_id;
          -- RAISE V_BIZ_EXCEPTION;
      END;
    END LOOP;
    RETURN P_MESSAGE;
  END;

  FUNCTION F_INSERT_OR_UPDATE_ORG
  --更新或插入客户组织业务表
  (P_INTF_HEAD_ID number --客户头ID
   ) return varchar2 IS
    VT_ORG_FATHER_TIME   UP_CODELIST.CODE_VALUE%TYPE;
    VT_ORG_FATHER_TIME_FM UP_CODELIST.CODE_VALUE%TYPE;
    VT_CUST_FATHER_CODE  T_CUSTOMER_HEADER.CUSTOMER_FATHER_CODE%TYPE;
    V_CUST_ORG_ACTIVE_FLAG T_CUSTOMER_ORG.ACTIVE_FLAG%TYPE; --
    V_CUST_ORG_NAME        T_CUSTOMER_ORG.Sales_Center_Name%TYPE; --业务表中的组织信息的数量
    P_MESSAGE              VARCHAR2(500);
    V_CHECK_MSG            VARCHAR2(4000);
    V_SALES_CENTER_ID      UP_ORG_UNIT.Unit_Id%type;
    org                    INTF_CUSTOMER_ORG%rowtype;
  
    --V_COUNT  NUMBER;
    --V_COUNT1 NUMBER;
  
    dept    T_CUSTOMER_DEPT%ROWTYPE;
    unit    UP_ORG_UNIT%ROWTYPE;
    unit_sr UP_ORG_UNIT%ROWTYPE;
    CURSOR C_INTF_CUSTOMER_ORG IS
      SELECT * FROM INTF_CUSTOMER_ORG WHERE PRE_FIELD_01 = P_INTF_HEAD_ID
      AND (RESPONSETYPE IS NULL);
      --AND (RESPONSETYPE IS NULL OR RESPONSETYPE <> 'E');
   TYPE T_INTF_ORG IS TABLE OF INTF_CUSTOMER_ORG%ROWTYPE
   INDEX BY BINARY_INTEGER
   ;
   V_INTF_ORG T_INTF_ORG;
   V_INDEX     NUMBER;
  
  BEGIN
    --
    UPDATE INTF_CUSTOMER_ORG U
    SET U.RESPONSETYPE = 'E',
    RESPNOSECODE    = '000013',
    RESPONSEMESSAGE = '处理前提：中心所在事业部[SIEBEL_ID=' || U.PARENT_ID
    || ']在正式表T_CUSTOMER_DEPT不存在记录，即INTF_CUSTOMER_DEPT【三（事业部信息）】不存在处理成功的记录',
    OPERSTATUS      = '1'
    WHERE PRE_FIELD_01 = P_INTF_HEAD_ID
    AND NOT EXISTS (SELECT 1 FROM T_CUSTOMER_DEPT D WHERE D.SIEBEL_ID = U.PARENT_ID);
    
    --查看主数据客户头ID是否存在
    OPEN C_INTF_CUSTOMER_ORG;
    FETCH C_INTF_CUSTOMER_ORG BULK COLLECT INTO V_INTF_ORG;
    CLOSE C_INTF_CUSTOMER_ORG;
    V_INDEX := (V_INTF_ORG.FIRST - 1);
    LOOP
      <<loop_here>>
      V_INDEX := (1 + V_INDEX);
      IF V_INDEX IS NULL OR V_INDEX > V_INTF_ORG.LAST THEN
        EXIT;
      END IF;
      org := V_INTF_ORG(V_INDEX);
      P_MESSAGE := 'SUCCESS';
      BEGIN
        SELECT D.*
          INTO dept
          FROM T_CUSTOMER_DEPT D
         WHERE D.SIEBEL_ID = org.parent_id;
        SELECT (SELECT unit.UNIT_ID
                  FROM UP_ORG_UNIT unit
                 WHERE unit.code = org.SALES_CENTER_CODE
                   and 'T' = unit.is_enabled
                   and 'T' = unit.active_flag)
          INTO V_SALES_CENTER_ID
          FROM DUAL;
        IF V_SALES_CENTER_ID is null THEN
          UPDATE INTF_CUSTOMER_ORG
             SET RESPONSETYPE    = 'E',
                 RESPNOSECODE    = '000013',
                 RESPONSEMESSAGE = '中心编码在内销不存在:' || org.SALES_CENTER_CODE
                 || '(在UP_ORG_UNIT表不存在或存在无效记录，需要在CRM走客户主数据流程)',
                 OPERSTATUS      = '1'
           WHERE CUSTOMER_ORG_ID = org.customer_org_id;
          goto loop_here;
        END IF;
        SELECT t.*
          INTO unit
          FROM UP_ORG_UNIT t
         WHERE t.unit_id = V_SALES_CENTER_ID;
        IF UNIT.ENTITY_ID IS NULL THEN
          UPDATE INTF_CUSTOMER_ORG
             SET RESPONSETYPE    = 'E',
                 RESPNOSECODE    = '000013',
                 RESPONSEMESSAGE = '中心组织在对应主体为空:' || org.SALES_CENTER_CODE,
                 OPERSTATUS      = '1'
           WHERE CUSTOMER_ORG_ID = org.customer_org_id;
          goto loop_here;
        END IF;
        IF UNIT.TYPE_CODE IS NULL THEN
          UPDATE INTF_CUSTOMER_ORG
             SET RESPONSETYPE    = 'E',
                 RESPNOSECODE    = '000013',
                 RESPONSEMESSAGE = '中心组织的类型为空:' || org.SALES_CENTER_CODE,
                 OPERSTATUS      = '1'
           WHERE CUSTOMER_ORG_ID = org.customer_org_id;
          goto loop_here;
        END IF;
        
        IF dept.dept_id IS NOT NULL AND unit.entity_id <> dept.dept_id THEN
          UPDATE INTF_CUSTOMER_ORG
             SET RESPONSETYPE    = 'E',
                 RESPNOSECODE    = '000013',
                 RESPONSEMESSAGE = '中心编码在对应主体不存在:' || org.SALES_CENTER_CODE,
                 OPERSTATUS      = '1'
           WHERE CUSTOMER_ORG_ID = org.customer_org_id;
          goto loop_here;
        END IF;
        
        IF UNIT.TYPE_CODE IN ('MC','BU') THEN
          UPDATE INTF_CUSTOMER_ORG
             SET RESPONSETYPE    = 'E',
                 RESPNOSECODE    = '000013',
                 RESPONSEMESSAGE = '组织编码不能是事业部或内销总公司编码:' || org.SALES_CENTER_CODE,
                 OPERSTATUS      = '1'
           WHERE CUSTOMER_ORG_ID = org.customer_org_id;
          goto loop_here;
        END IF;
      
        --关联销售大区
        BEGIN
          select r.*
            INTO unit_sr
            from up_org_unit r
           where r.unit_id = unit.par_unit_id
             and r.type_code = 'SR'
             and r.is_enabled = 'T';
        EXCEPTION
          WHEN OTHERS THEN
            NULL;
        END;
      
        SELECT T.Sales_Center_Name, T.ACTIVE_FLAG
          INTO V_CUST_ORG_NAME, V_CUST_ORG_ACTIVE_FLAG
          FROM DUAL
          LEFT JOIN T_CUSTOMER_ORG T
            ON (T.SIEBEL_ORG_ID = org.siebel_org_id);
        --F_CUSTORG_CHECK_UNDO
        IF org.Active_Flag = 'Inactive' AND
           'Inactive' <> V_CUST_ORG_ACTIVE_FLAG THEN
          --系统初始化账户，CIMS业务、CRM业务没有感知，如果上游失效
          --避免CIMS、CRM的中心不一致，又避免业务处理账务的麻烦，保守的检查未完成单据，不检查余额
          SELECT DECODE(M,
                        NULL,
                        (F_CUSTORG_CHECK_UNDO(NULL,
                                              NULL,
                                              NULL,
                                              NULL,
                                              NULL,
                                              ORG.SIEBEL_ORG_ID,
                                              NULL,
                                              2,
                                              1)),--系统初始化账户，仅检查未完成发货计划、发货通知单
                        '业务账户' || M)
            INTO V_CHECK_MSG
            FROM (SELECT F_CUSTORG_CHECK_UNDO(NULL,
                                              NULL,
                                              NULL,
                                              NULL,
                                              NULL,
                                              ORG.SIEBEL_ORG_ID,
                                              NULL,
                                              1) AS M--非系统初始化账户，检查所有
                    FROM DUAL);
          
          IF 'SUCCESS' <> NVL(V_CHECK_MSG, 'SUCCESS') THEN
            IF '业务账户' = SUBSTR(V_CHECK_MSG,1,4) THEN
              V_CHECK_MSG := SUBSTR(V_CHECK_MSG,5);
            ELSE
              org.Active_Flag := 'Freezing';
              P_MESSAGE := P_MESSAGE || '：' || V_CHECK_MSG;
              GOTO IN_UP;
            END IF;
            BEGIN
              UPDATE INTF_CUSTOMER_ORG
                 SET RESPONSETYPE    = 'E',
                     RESPNOSECODE    = '000013',
                     RESPONSEMESSAGE = '失效校验错误:' || V_CHECK_MSG,
                     OPERSTATUS      = '1'
               WHERE CUSTOMER_ORG_ID = org.customer_org_id;
            EXCEPTION
              WHEN OTHERS THEN
                UPDATE INTF_CUSTOMER_ORG
                   SET RESPONSETYPE    = 'E',
                       RESPNOSECODE    = '000013',
                       RESPONSEMESSAGE = '失效校验错误:' ||
                                         SUBSTR(V_CHECK_MSG, 1, 400),
                       OPERSTATUS      = '1'
                 WHERE CUSTOMER_ORG_ID = org.customer_org_id;
            END;
            GOTO loop_here;
          END IF;
        END IF;
        /*           (SELECT SIEBEL_ORG_ID
         FROM INTF_CUSTOMER_ORG
        WHERE PRE_FIELD_01 = P_INTF_HEAD_ID);*/
        <<IN_UP>>
      
        SELECT (SELECT CL.CODE_VALUE FROM UP_CODELIST CL WHERE CL.CODETYPE = 'cust_org_fathercode'
        AND CL.CODE_NAME = '中心关联客户切换时间') INTO VT_ORG_FATHER_TIME FROM DUAL;
        SELECT (SELECT CL.CODE_VALUE FROM UP_CODELIST CL WHERE CL.CODETYPE = 'cust_org_fathercode'
        AND CL.CODE_NAME = '中心关联客户切换时间格式') INTO VT_ORG_FATHER_TIME_FM FROM DUAL;
        
        IF VT_ORG_FATHER_TIME IS NOT NULL OR VT_ORG_FATHER_TIME IS NOT NULL THEN
          
          VT_ORG_FATHER_TIME := NVL(VT_ORG_FATHER_TIME,'2017-11-24 23:00:00');
          VT_ORG_FATHER_TIME_FM := NVL(VT_ORG_FATHER_TIME_FM,'YYYY-MM-DD HH24:MI:SS');
        --2017-11-24 23之前，取客户头的关联客户编码作为中心关联客户编码
        --2017-11-24 23之后，当客户所在事业部存在中心关联客户编码不为空的客户中心推送记录才取推送记录
        --否则仍然取客户头的关联客户编码作为中心关联客户编码
        SELECT DECODE(CUST_FATHER_CODE,NULL,ORG.ORG_CUSTOMER_FATHER_CODE,CUST_FATHER_CODE)
        INTO ORG.ORG_CUSTOMER_FATHER_CODE FROM (
        SELECT --CH.CUSTOMER_FATHER_CODE,ET.*,
        DECODE(ET.CUSTOMER_CODE,NULL,CH.CUSTOMER_FATHER_CODE) AS CUST_FATHER_CODE
        --DECODE(ET.CUSTOMER_CODE,NULL,CH.CUSTOMER_FATHER_CODE) INTO VT_CUST_FATHER_CODE
        FROM T_CUSTOMER_HEADER CH LEFT JOIN (SELECT * FROM (
        SELECT H.CUSTOMER_CODE FROM INTF_CUSTOMER_ORG ICO
        INNER JOIN T_CUSTOMER_HEADER H
        ON (H.CUSTOMER_CODE = ICO.ORG_CUSTOMER_FATHER_CODE)
        WHERE ICO.PARENT_ID = ORG.PARENT_ID
        AND LENGTH(ICO.ORG_CUSTOMER_FATHER_CODE) = LENGTHB(ICO.ORG_CUSTOMER_FATHER_CODE)
        AND ICO.LAST_INTERFACE_DATE >= TO_DATE(VT_ORG_FATHER_TIME,VT_ORG_FATHER_TIME_FM)
        GROUP BY H.CUSTOMER_CODE HAVING COUNT(0) > 0) WHERE 1 = ROWNUM
        ) ET ON (1 = 1)
        --) ET ON (ET.CUSTOMER_CODE IS NULL)
        WHERE CH.CUSTOMER_ID = DEPT.CUSTOMER_ID
        )
        ;
        /*IF VT_CUST_FATHER_CODE IS NOT NULL THEN
          ORG.ORG_CUSTOMER_FATHER_CODE := VT_CUST_FATHER_CODE;
        END IF;*/
        
        END IF;
        
        IF (V_CUST_ORG_NAME IS NULL) THEN
          INSERT INTO T_CUSTOMER_ORG
            (CUSTOMER_ORG_ID,
             ENTITY_ID,
             CUSTOMER_ID,
             CUSTOMER_CODE,
             SALES_CENTER_ID,
             SALES_CENTER_CODE,
             SALES_REGION_ID,
             SALES_REGION_CODE,
             DEPT_ID,
             DEPT_CODE,
             CREATED_BY,
             CREATION_DATE,
             LAST_UPDATE_DATE,
             LAST_UPDATE_BY,
             LAST_INTERFACE_DATE,
             SIEBEL_ORG_ID,
             SIEBEL_CUSTOMER_ID,
             ACTIVE_FLAG,
             PRE_FIELD_01,
             PRE_FIELD_02,
             PRE_FIELD_03,
             PRE_FIELD_04,
             PRE_FIELD_05,
             PRE_FIELD_06,
             SALES_CENTER_NAME,
             PARENT_ID,
             ORG_CUSTOMER_FATHER_CODE)
          --SELECT
          VALUES
            (NVL(org.pre_field_02, S_CUSTOMER_ORG.NEXTVAL), -- CUSTOMER_ORG_ID,
             --(SELECT unit.entity_id FROM UP_ORG_UNIT unit WHERE unit.code =  (SELECT dept.DEPT_CODE FROM T_CUSTOMER_DEPT dept WHERE dept.siebel_id = intf.parent_id)) ENTITY_ID,
             dept.dept_id, -- ENTITY_ID,
             dept.CUSTOMER_ID, -- CUSTOMER_ID,
             dept.CUSTOMER_CODE, -- CUSTOMER_CODE,
             V_SALES_CENTER_ID, --  SALES_CENTER_ID,
             org.SALES_CENTER_CODE,
             unit_sr.unit_id, -- SALES_REGION_ID,
             unit_sr.code, -- SALES_REGION_CODE,
             dept.DEPT_ID, -- DEPT_ID,
             dept.DEPT_CODE, -- DEPT_CODE,
             org.CREATED_BY,
             org.CREATION_DATE,
             org.LAST_UPDATE_DATE,
             org.LAST_UPDATE_BY,
             org.LAST_INTERFACE_DATE,
             org.SIEBEL_ORG_ID,
             org.SIEBEL_CUSTOMER_ID,
             NVL(org.ACTIVE_FLAG, 'Active'),
             org.PRE_FIELD_01,
             org.PRE_FIELD_02,
             org.PRE_FIELD_03,
             org.PRE_FIELD_04,
             org.PRE_FIELD_05,
             org.PRE_FIELD_06,
             unit.name, -- SALES_CENTER_NAME,
             dept.id,
             --add by liangym2 2017-11-20 中心关联客户编码，取报文预留字段1，保存到接口表的预留字段5
             DECODE(LENGTH(org.ORG_CUSTOMER_FATHER_CODE)
             ,LENGTHB(org.ORG_CUSTOMER_FATHER_CODE),ORG.ORG_CUSTOMER_FATHER_CODE,NULL)
             ); -- PARENT_ID);
        
          /*          FROM INTF_CUSTOMER_ORG intf
          WHERE intf.PRE_FIELD_01 = P_INTF_HEAD_ID;*/
        
        ELSE
          UPDATE T_CUSTOMER_ORG
             SET (ENTITY_ID,
                  CUSTOMER_ID,
                  CUSTOMER_CODE,
                  SALES_CENTER_ID,
                  SALES_CENTER_CODE,
                  SALES_REGION_ID,
                  SALES_REGION_CODE,
                  DEPT_ID,
                  DEPT_CODE,
                  CREATED_BY,
                  CREATION_DATE,
                  LAST_UPDATE_DATE,
                  LAST_UPDATE_BY,
                  LAST_INTERFACE_DATE,
                  SIEBEL_ORG_ID,
                  SIEBEL_CUSTOMER_ID,
                  ACTIVE_FLAG,
                  PRE_FIELD_01,
                  PRE_FIELD_02,
                  PRE_FIELD_03,
                  PRE_FIELD_04,
                  PRE_FIELD_05,
                  PRE_FIELD_06,
                  SALES_CENTER_NAME,
                  PARENT_ID,
                  ORG_CUSTOMER_FATHER_CODE) =
                 (SELECT
                  --(SELECT unit.entity_id FROM UP_ORG_UNIT unit WHERE unit.code =  (SELECT dept.DEPT_CODE FROM T_CUSTOMER_DEPT dept WHERE dept.siebel_id = intf.parent_id)) ENTITY_ID,
                   dept.dept_id ENTITY_ID,
                   dept.CUSTOMER_ID CUSTOMER_ID,
                   dept.CUSTOMER_CODE CUSTOMER_CODE,
                   V_SALES_CENTER_ID,
                   org.SALES_CENTER_CODE,
                   unit_sr.unit_id SALES_REGION_ID,
                   unit_sr.code SALES_REGION_CODE,
                   dept.DEPT_ID DEPT_ID,
                   dept.DEPT_CODE DEPT_CODE,
                   org.CREATED_BY,
                   org.CREATION_DATE,
                   org.LAST_UPDATE_DATE,
                   org.LAST_UPDATE_BY,
                   org.LAST_INTERFACE_DATE,
                   org.SIEBEL_ORG_ID,
                   org.SIEBEL_CUSTOMER_ID,
                   NVL(org.ACTIVE_FLAG, 'Active'),
                   org.PRE_FIELD_01,
                   org.PRE_FIELD_02,
                   org.PRE_FIELD_03,
                   org.PRE_FIELD_04,
                   org.PRE_FIELD_05,
                   org.PRE_FIELD_06,
                   unit.name SALES_CENTER_NAME,
                   dept.id PARENT_ID,
                   --add by liangym2 2017-11-20 中心关联客户编码，取报文预留字段1
                   DECODE(LENGTH(org.ORG_CUSTOMER_FATHER_CODE)
                   ,LENGTHB(org.ORG_CUSTOMER_FATHER_CODE),ORG.ORG_CUSTOMER_FATHER_CODE,NULL)
                    FROM DUAL)
           WHERE Siebel_Org_Id = org.siebel_org_id;
          /*  FROM INTF_CUSTOMER_ORG intf
                       WHERE intf.PRE_FIELD_01 = P_INTF_HEAD_ID
                       AND intf.Siebel_Org_Id = org.siebel_org_id)
                       WHERE EXISTS (SELECT 1 from INTF_CUSTOMER_ORG intfx  WHERE intfx.PRE_FIELD_01 = P_INTF_HEAD_ID  AND intfx.Siebel_Org_Id = org.siebel_org_id);
          */
          IF V_CUST_ORG_NAME <> unit.Name THEN
            --当基础数据中心名称更改时，仅更新业务表时更新冗余字段 2016-4-13
            UPDATE T_CUSTOMER_ORG O
               SET O.SALES_CENTER_NAME = unit.Name,
                   O.LAST_UPDATE_DATE  = SYSDATE
             WHERE O.ENTITY_ID = dept.Dept_Id
               AND O.SALES_CENTER_CODE = org.Sales_Center_Code -- unit.Code
               AND O.SALES_CENTER_NAME = V_CUST_ORG_NAME;
            UPDATE T_CREDIT_DISCOUNT_AMOUNT O
               SET O.SALES_CENTER_NAME = unit.Name,
                   O.LAST_UPDATE_DATE  = SYSDATE
             WHERE O.ENTITY_ID = dept.Dept_Id
               AND O.SALES_CENTER_CODE = org.Sales_Center_Code -- unit.Code
               AND O.SALES_CENTER_NAME = V_CUST_ORG_NAME;
            UPDATE T_BD_PRICE_LIST O
               SET O.UNIT_NAME = unit.Name,
                   O.LAST_UPDATE_DATE  = SYSDATE
             WHERE O.ENTITY_ID = dept.Dept_Id
               AND O.UNIT_CODE = org.Sales_Center_Code -- unit.Code
               AND O.UNIT_NAME = V_CUST_ORG_NAME;
            UPDATE T_BD_PRICE_LIST O
               SET O.USER_UNIT_NAME = unit.Name,
                   O.LAST_UPDATE_DATE  = SYSDATE
             WHERE O.ENTITY_ID = dept.Dept_Id
               AND O.USER_UNIT_CODE = org.Sales_Center_Code -- unit.Code
               AND O.USER_UNIT_NAME = V_CUST_ORG_NAME;
            UPDATE T_CUSTOMER_ACCOUNT O
               SET O.SALES_CENTER_NAME = unit.Name,
                   O.LAST_UPDATE_DATE  = SYSDATE
             WHERE O.ENTITY_ID = dept.Dept_Id
               AND O.SALES_CENTER_CODE = org.Sales_Center_Code -- unit.Code
               AND O.SALES_CENTER_NAME = V_CUST_ORG_NAME;
            UPDATE T_BD_PRICE_SYSTEM_ORG O
               SET O.SALES_CENTER_NAME = unit.Name,
                   O.LAST_UPDATE_DATE  = SYSDATE
             WHERE O.ENTITY_ID = dept.Dept_Id
               AND O.SALES_CENTER_CODE = org.Sales_Center_Code -- unit.Code
               AND O.SALES_CENTER_NAME = V_CUST_ORG_NAME;
          END IF;
        END IF;
        --
        IF LENGTH(ORG.ORG_CUSTOMER_FATHER_CODE) = LENGTHB(ORG.ORG_CUSTOMER_FATHER_CODE) THEN
       --IF ORG.ORG_CUSTOMER_FATHER_CODE IS NOT NULL THEN
          UPDATE T_CUSTOMER_ORG UO
          SET (UO.ORG_CUSTOMER_FATHER_ID,UO.ORG_CUSTOMER_FATHER_NAME)
          = (SELECT H.CUSTOMER_ID,H.CUSTOMER_NAME FROM T_CUSTOMER_HEADER H
          WHERE H.CUSTOMER_CODE = UO.ORG_CUSTOMER_FATHER_CODE AND 1 = ROWNUM)
          WHERE UO.SIEBEL_ORG_ID = ORG.SIEBEL_ORG_ID AND UO.ORG_CUSTOMER_FATHER_CODE = ORG.ORG_CUSTOMER_FATHER_CODE;
        END IF;
        UPDATE INTF_CUSTOMER_ORG
           SET RESPONSETYPE    = 'N',
               RESPNOSECODE    = '000000',
               RESPONSEMESSAGE = P_MESSAGE,
               OPERSTATUS      = '1'
         WHERE CUSTOMER_ORG_ID = org.customer_org_id;
      EXCEPTION
        WHEN OTHERS THEN
        
          ROLLBACK;
          --记录出错信息
          P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_CUSTOMER_INTF.P_CUSTOMER_INTF_PROC.F_INSERT_OR_UPDATE_ORG',
                                              SQLCODE,
                                              '插入客户中心关系业务表失败！：' || SQLERRM);
          UPDATE INTF_CUSTOMER_ORG
             SET RESPONSETYPE    = 'E',
                 RESPNOSECODE    = '000013',
                 RESPONSEMESSAGE = P_MESSAGE,
                 OPERSTATUS      = '1'
           WHERE CUSTOMER_ORG_ID = org.customer_org_id;
          BEGIN
            DELETE FROM t_customer_account a
             where exists
             (select 1
                      from t_customer_acc_org_relation r
                     where exists
                     (select 1
                              from intf_customer_org io
                             where io.customer_org_id = org.customer_org_id
                               and TO_NUMBER(io.pre_field_02) = r.customer_org_id
                               and '000000' <> io.respnosecode
                               and not exists (select 1 from t_customer_org co
                                     where '' || co.customer_org_id = io.pre_field_02
                                       and io.siebel_org_id = co.siebel_org_id))
                       and r.account_id = a.account_id);
          
            IF 0 = SQL%ROWCOUNT THEN
              ROLLBACK;
              GOTO loop_here;
            END IF;
          
            DELETE FROM t_customer_acc_org_relation r
             where exists
             (select 1
                      from intf_customer_org io
                     where io.customer_org_id = org.customer_org_id
                       and TO_NUMBER(io.pre_field_02) = r.customer_org_id
                       and '000000' <> io.respnosecode
                       and not exists (select 1 from t_customer_org co
                             where '' || co.customer_org_id = io.pre_field_02
                               and io.siebel_org_id = co.siebel_org_id));
            IF 0 = SQL%ROWCOUNT THEN
              ROLLBACK;
              --GOTO loop_here;
            END IF;
          EXCEPTION
            WHEN OTHERS THEN
              ROLLBACK;
          END;
          -- RAISE V_BIZ_EXCEPTION;
      END;
    END LOOP;
  
    RETURN P_MESSAGE;
  END;

  FUNCTION F_INSERT_OR_UPDATE_MAIN_TYPE
  --更新或插入客户联系人业务表
  (P_INTF_HEAD_ID number --客户头ID
   ) return varchar2 IS
    V_CUST_SALE_MAIN_TYPE_COUNT NUMBER; --业务表中营销大类信息数量
    P_MESSAGE                   VARCHAR2(500);
  
    CURSOR C_INTF_CUSTOMER_MAIN_TYPE IS
      SELECT *
        FROM INTF_CUSTOMER_SALES_MAIN_TYPE
       WHERE PRE_FIELD_01 = P_INTF_HEAD_ID;
  
  BEGIN
    P_MESSAGE := 'SUCCESS';
    --查看主数据客户头ID是否存在
    FOR maintype in C_INTF_CUSTOMER_MAIN_TYPE LOOP
      BEGIN
        SELECT COUNT(0)
          INTO V_CUST_SALE_MAIN_TYPE_COUNT
          FROM T_CUSTOMER_SALES_MAIN_TYPE
         WHERE SIEBEL_PRODUCT_ID = maintype.Siebel_Product_Id;
      
        IF (V_CUST_SALE_MAIN_TYPE_COUNT = 0) THEN
          INSERT INTO T_CUSTOMER_SALES_MAIN_TYPE
            (SALES_MAIN_TYPE_ID,
             ENTITY_ID,
             CUSTOM_ID,
             CUSTOM_CODE,
             DEPT_ID,
             DEPT_CODE,
             SALES_MAIN_TYPE_NAME,
             CUSTOM_LEVEL,
             CUSTOM_CREDIT_LEVEL,
             CREDIT_LINE,
             COOPERATION_MODEL_ID,
             ACTIVE_FLAG,
             CREATED_BY,
             CREATION_DATE,
             LAST_UPDATE_DATE,
             LAST_UPDATE_BY,
             LAST_INTERFACE_DATE,
             SIEBEL_PRODUCT_ID,
             SIEBEL_CUSTOMER_ID,
             PRE_FIELD_01,
             PRE_FIELD_02,
             PRE_FIELD_03,
             PRE_FIELD_04,
             PRE_FIELD_05,
             PRE_FIELD_06,
             SALES_MAIN_TYPE_CODE,
             PARENT_ID)
          --SELECT
          VALUES
            (S_CUSTOMER_SALES_MAIN_TYPE.NEXTVAL, -- SALES_MAIN_TYPE_ID,
             (SELECT dept.dept_id
                FROM T_CUSTOMER_DEPT dept
               WHERE dept.SIEBEL_ID = maintype.parent_id), -- ENTITY_ID,
             (SELECT dept.CUSTOMER_ID
                FROM T_CUSTOMER_DEPT dept
               WHERE dept.siebel_id = maintype.parent_id), -- CUSTOMER_ID,
             (SELECT dept.CUSTOMER_CODE
                FROM T_CUSTOMER_DEPT dept
               WHERE dept.siebel_id = maintype.parent_id), -- CUSTOMER_CODE,
             (SELECT dept.DEPT_ID
                FROM T_CUSTOMER_DEPT dept
               WHERE dept.siebel_id = maintype.parent_id), -- DEPT_ID,
             (SELECT dept.DEPT_CODE
                FROM T_CUSTOMER_DEPT dept
               WHERE dept.siebel_id = maintype.parent_id), -- DEPT_CODE,
             (SELECT codelist.code_name
                FROM UP_CODELIST codelist
               WHERE codelist.code_value = maintype.sales_main_type_code
                 AND codelist.codetype = 'MIDEA_ACCOUNT_PROD_TYPE'), -- SALES_MAIN_TYPE_NAME,
             maintype.CUSTOM_LEVEL,
             maintype.CUSTOM_CREDIT_LEVEL,
             maintype.CREDIT_LINE,
             maintype.COOPERATION_MODEL_ID,
             NVL(maintype.ACTIVE_FLAG, 'Active'),
             maintype.CREATED_BY,
             maintype.CREATION_DATE,
             maintype.LAST_UPDATE_DATE,
             maintype.LAST_UPDATE_BY,
             maintype.LAST_INTERFACE_DATE,
             maintype.SIEBEL_PRODUCT_ID,
             maintype.SIEBEL_CUSTOMER_ID,
             maintype.PRE_FIELD_01,
             maintype.PRE_FIELD_02,
             maintype.PRE_FIELD_03,
             maintype.PRE_FIELD_04,
             maintype.PRE_FIELD_05,
             maintype.PRE_FIELD_06,
             maintype.SALES_MAIN_TYPE_CODE,
             (SELECT dept.id
                FROM T_CUSTOMER_DEPT dept
               WHERE dept.siebel_id = maintype.parent_id)); -- PARENT_ID
        
          /*          FROM INTF_CUSTOMER_SALES_MAIN_TYPE intf
          WHERE intf.PRE_FIELD_01 = P_INTF_HEAD_ID;*/
        
        ELSE
          UPDATE T_CUSTOMER_SALES_MAIN_TYPE maintype
             SET (
                  -- ENTITY_ID,
                  ENTITY_ID,
                  CUSTOM_ID,
                  CUSTOM_CODE,
                  DEPT_ID,
                  DEPT_CODE,
                  SALES_MAIN_TYPE_NAME,
                  CUSTOM_LEVEL,
                  CUSTOM_CREDIT_LEVEL,
                  CREDIT_LINE,
                  COOPERATION_MODEL_ID,
                  ACTIVE_FLAG,
                  CREATED_BY,
                  CREATION_DATE,
                  LAST_UPDATE_DATE,
                  LAST_UPDATE_BY,
                  LAST_INTERFACE_DATE,
                  SIEBEL_PRODUCT_ID,
                  SIEBEL_CUSTOMER_ID,
                  PRE_FIELD_01,
                  PRE_FIELD_02,
                  PRE_FIELD_03,
                  PRE_FIELD_04,
                  PRE_FIELD_05,
                  PRE_FIELD_06,
                  SALES_MAIN_TYPE_CODE,
                  PARENT_ID) =
                 (SELECT (SELECT dept.dept_id
                            FROM T_CUSTOMER_DEPT dept
                           WHERE dept.SIEBEL_ID = maintype.parent_id) ENTITY_ID,
                         (SELECT dept.CUSTOMER_ID
                            FROM T_CUSTOMER_DEPT dept
                           WHERE dept.siebel_id = maintype.parent_id) CUSTOMER_ID,
                         (SELECT dept.CUSTOMER_CODE
                            FROM T_CUSTOMER_DEPT dept
                           WHERE dept.siebel_id = maintype.parent_id) CUSTOMER_CODE,
                         (SELECT dept.DEPT_ID
                            FROM T_CUSTOMER_DEPT dept
                           WHERE dept.siebel_id = maintype.parent_id) DEPT_ID,
                         (SELECT dept.DEPT_CODE
                            FROM T_CUSTOMER_DEPT dept
                           WHERE dept.siebel_id = maintype.parent_id) DEPT_CODE,
                         (SELECT codelist.code_name
                            FROM UP_CODELIST codelist
                           WHERE codelist.code_value =
                                 maintype.sales_main_type_code
                             AND codelist.codetype =
                                 'MIDEA_ACCOUNT_PROD_TYPE') SALES_MAIN_TYPE_NAME,
                         maintype.CUSTOM_LEVEL,
                         maintype.CUSTOM_CREDIT_LEVEL,
                         maintype.CREDIT_LINE,
                         maintype.COOPERATION_MODEL_ID,
                         NVL(maintype.ACTIVE_FLAG, 'Active'),
                         maintype.CREATED_BY,
                         maintype.CREATION_DATE,
                         maintype.LAST_UPDATE_DATE,
                         maintype.LAST_UPDATE_BY,
                         maintype.LAST_INTERFACE_DATE,
                         maintype.SIEBEL_PRODUCT_ID,
                         maintype.SIEBEL_CUSTOMER_ID,
                         maintype.PRE_FIELD_01,
                         maintype.PRE_FIELD_02,
                         maintype.PRE_FIELD_03,
                         maintype.PRE_FIELD_04,
                         maintype.PRE_FIELD_05,
                         maintype.PRE_FIELD_06,
                         maintype.SALES_MAIN_TYPE_CODE,
                         (SELECT dept.id
                            FROM T_CUSTOMER_DEPT dept
                           WHERE dept.siebel_id = maintype.parent_id) PARENT_ID
                    FROM DUAL)
           WHERE siebel_product_id = maintype.siebel_product_id;
          /* FROM INTF_CUSTOMER_SALES_MAIN_TYPE intf
                       WHERE intf.PRE_FIELD_01 = P_INTF_HEAD_ID
                       AND intf.siebel_product_id = maintype.siebel_product_id)
                       WHERE EXISTS (SELECT 1 from INTF_CUSTOMER_SALES_MAIN_TYPE intfx  WHERE intfx.PRE_FIELD_01 = P_INTF_HEAD_ID AND intfx.siebel_product_id = maintype.siebel_product_id);
          */
        END IF;
        UPDATE INTF_CUSTOMER_SALES_MAIN_TYPE
           SET RESPONSETYPE    = 'N',
               RESPNOSECODE    = '000000',
               RESPONSEMESSAGE = P_MESSAGE,
               OPERSTATUS      = '1'
         WHERE SALES_MAIN_TYPE_ID = maintype.Sales_Main_Type_Id;
      EXCEPTION
        WHEN OTHERS THEN
        
          ROLLBACK;
          --记录出错信息
          P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_CUSTOMER_INTF.P_CUSTOMER_INTF_PROC.F_INSERT_OR_UPDATE_MAIN_TYPE',
                                              SQLCODE,
                                              '插入银行业务表失败！：' || SQLERRM);
          UPDATE INTF_CUSTOMER_SALES_MAIN_TYPE
             SET RESPONSETYPE    = 'E',
                 RESPNOSECODE    = '000013',
                 RESPONSEMESSAGE = P_MESSAGE,
                 OPERSTATUS      = '1'
           WHERE SALES_MAIN_TYPE_ID = maintype.Sales_Main_Type_Id;
          --RAISE V_BIZ_EXCEPTION;
      END;
    END LOOP;
    RETURN P_MESSAGE;
  END;

  PROCEDURE PRC_UPDATE_STATUS_CHANGED
  --当客户头状态、事业部有效状态、事业部客户状态、组织状态失效、冻结时更新
  (P_INTF_HEAD_ID IN number, --客户头ID
   P_HEAD_ID      IN number --客户头ID
   ) IS
    V_COUNT                    NUMBER;
    V_CUSTOMER_ID              NUMBER;
    V_CUSTOMER_CODE            VARCHAR2(100);
    V_ACTIVE_FLAG              VARCHAR2(32);
    V_LOG_ACTIVE_FLAG          VARCHAR2(32);
    V_LOG_DEPT_CUSTOMER_STATUS VARCHAR2(32);
    V_DATETIME_CHAR            VARCHAR2(32) := TO_CHAR(SYSDATE,
                                                       'YYYYMMDDHH24MISS');
    CURSOR C_H_CHANGED(P_CUSTOMER_ID NUMBER) IS
      SELECT H.CUSTOMER_ID, H.CUSTOMER_STATUS, H.ACTIVE_FLAG
        FROM T_CUSTOMER_HEADER H
       WHERE H.CUSTOMER_ID = P_CUSTOMER_ID
         AND ((H.ACTIVE_FLAG = 'Inactive') OR
             (H.CUSTOMER_STATUS = 'Freezing' AND
             (H.ACTIVE_FLAG = 'Active' OR H.ACTIVE_FLAG = 'Freezing')))
         AND NOT EXISTS
       (SELECT 1
                FROM T_CUSTOMER_HEADER T
               WHERE T.SIEBEL_CUSTOMER_ID <> H.SIEBEL_CUSTOMER_ID
                 AND T.CUSTOMER_ID = H.CUSTOMER_ID
                 AND T.CUSTOMER_STATUS NOT IN ('Freezing', 'Inactive'));
    CURSOR C_H_DEPT_CHANGED(P_CUSTOMER_ID NUMBER, P_ACTIVE_FLAG VARCHAR2) IS
      SELECT D.ID, D.DEPT_ID, D.DEPT_CUSTOMER_STATUS, D.ACTIVE_FLAG
        FROM T_CUSTOMER_DEPT D
       WHERE D.CUSTOMER_ID = P_CUSTOMER_ID
         AND D.DEPT_ID IS NOT NULL
         AND ((P_ACTIVE_FLAG = 'Inactive' AND
             D.ACTIVE_FLAG <> P_ACTIVE_FLAG) OR
             (P_ACTIVE_FLAG = 'Freezing' AND
             (D.ACTIVE_FLAG <> 'Inactive' OR
             D.DEPT_CUSTOMER_STATUS <> 'Inactive') AND
             (D.ACTIVE_FLAG <> 'Active' OR
             D.DEPT_CUSTOMER_STATUS <> P_ACTIVE_FLAG) --
             ));
    CURSOR C_DEPT_CHANGED(P_CUSTOMER_ID NUMBER) IS
      SELECT D.ID, D.DEPT_ID, D.DEPT_CUSTOMER_STATUS, D.ACTIVE_FLAG
        FROM T_CUSTOMER_DEPT D
       WHERE D.CUSTOMER_ID = P_CUSTOMER_ID
         AND D.DEPT_ID IS NOT NULL
         AND ((D.ACTIVE_FLAG = 'Inactive') OR
             (D.DEPT_CUSTOMER_STATUS = 'Freezing' AND
             (D.ACTIVE_FLAG = 'Active' OR D.ACTIVE_FLAG = 'Freezing')))
         AND NOT EXISTS
       (SELECT 1
                FROM T_CUSTOMER_DEPT T
               WHERE T.SIEBEL_ID <> D.SIEBEL_ID
                 AND T.CUSTOMER_ID = D.CUSTOMER_ID
                 AND T.DEPT_ID = D.DEPT_ID
                 AND T.DEPT_CUSTOMER_STATUS NOT IN ('Freezing', 'Inactive'));
    CURSOR C_H_ORG_CHANGED(P_CUSTOMER_ID NUMBER,
                           P_ENTITY_ID   NUMBER,
                           P_ACTIVE_FLAG VARCHAR2) IS
      SELECT O.CUSTOMER_ORG_ID, O.ENTITY_ID, O.ACTIVE_FLAG
        FROM T_CUSTOMER_ORG O
       WHERE O.CUSTOMER_ID = P_CUSTOMER_ID
         AND P_ACTIVE_FLAG = 'Inactive'
         AND O.ACTIVE_FLAG <> P_ACTIVE_FLAG
         AND NVL(P_ENTITY_ID, O.ENTITY_ID) = O.ENTITY_ID
         AND O.SALES_CENTER_ID IS NOT NULL
      --AND (P_ACTIVE_FLAG <> 'Freezing' OR (O.ACTIVE_FLAG <> 'Inactive'))
      ;
    CURSOR C_ORG_CHANGED(P_CUSTOMER_ID NUMBER) IS
      SELECT O.CUSTOMER_ORG_ID,
             O.ENTITY_ID,
             O.ACTIVE_FLAG,
             O.SALES_CENTER_CODE,
             O.SALES_CENTER_NAME
        FROM T_CUSTOMER_ORG O
       WHERE O.CUSTOMER_ID = P_CUSTOMER_ID
         AND O.ACTIVE_FLAG IN ('Freezing', 'Inactive')
         AND O.ENTITY_ID IS NOT NULL
         AND O.SALES_CENTER_ID IS NOT NULL
         AND NOT EXISTS
       (SELECT 1
                FROM T_CUSTOMER_ORG T
               WHERE T.SIEBEL_ORG_ID <> O.SIEBEL_ORG_ID
                 AND T.CUSTOMER_ID = O.CUSTOMER_ID
                 AND T.ENTITY_ID = O.ENTITY_ID
                 AND T.SALES_CENTER_ID = O.SALES_CENTER_ID
                 AND T.ACTIVE_FLAG NOT IN ('Freezing', 'Inactive'));
    CURSOR C_H_ACC_CHANGED(P_CUSTOMER_ID NUMBER,
                           P_ENTITY_ID   NUMBER,
                           P_ORG_ID      NUMBER,
                           P_ACTIVE_FLAG VARCHAR2) IS
      SELECT A.ACCOUNT_ID,
             A.ENTITY_ID,
             A.ACTIVE_FLAG,
             A.ACCOUNT_STATUS,
             A1.CUSTOMER_ORG_ID
        FROM T_CUSTOMER_ACCOUNT A
       INNER JOIN T_CUSTOMER_ACC_ORG_RELATION A1
          ON (A1.ACCOUNT_ID = A.ACCOUNT_ID)
       WHERE P_CUSTOMER_ID = A.CUSTOMER_ID
         AND NVL(P_ENTITY_ID, A.ENTITY_ID) = A.ENTITY_ID
         AND NVL(P_ORG_ID, A1.CUSTOMER_ORG_ID) = A1.CUSTOMER_ORG_ID
         AND ((P_ACTIVE_FLAG <> 'Freezing'
             --
             AND
             A.ACTIVE_FLAG <> DECODE(P_ACTIVE_FLAG, 'Active', 'Y', 'N')
             --
             AND A.ACCOUNT_STATUS <>
             DECODE(P_ACTIVE_FLAG, 'Active', '1', '2'))
             --冻结时仅将正常的账户冻结，对于失效的不能改为冻结
             OR (P_ACTIVE_FLAG = 'Freezing' AND A.ACCOUNT_STATUS = '1'
             -- AND A.ACTIVE_FLAG = 'Y'--
             ))
         AND (--集团、事业部冻结联动 必须检查中心有效，因为如果中心失效了，不能把账户改为有效
             (P_ACTIVE_FLAG = 'Freezing' AND EXISTS (SELECT 1
                          FROM T_CUSTOMER_ORG O
                         WHERE O.CUSTOMER_ORG_ID = A1.CUSTOMER_ORG_ID
                           AND O.ACTIVE_FLAG NOT IN ('Freezing','Inactive')))
             OR (P_ACTIVE_FLAG IS NOT NULL)
             --集团、事业部失效联动，不需要检查未完成发货通知单，因为CRM会调用失效校验接口
             /*OR (P_ACTIVE_FLAG = 'Inactive' AND EXISTS (SELECT 1
                          FROM T_CUSTOMER_ORG O
                         WHERE O.CUSTOMER_ORG_ID = A1.CUSTOMER_ORG_ID
                         AND F_CUSTORG_CHECK_UNDO(NULL,
                                              NULL,
                                              NULL,
                                              NULL,
                                              NULL,
                                              ORG.SIEBEL_ORG_ID,
                                              NULL,
                                              2,
                                              1) IS NULL
                         ))*/
                           )
      /*AND (A.ACTIVE_FLAG <>
          DECODE(P_ACTIVE_FLAG, 'Active', 'Y', 'Freezing', 'Y', 'N') OR
          A.ACCOUNT_STATUS <>
          DECODE(P_ACTIVE_FLAG, 'Active', '1', 'Freezing', '-1', '2'))
      AND (P_ACTIVE_FLAG <> 'Freezing' OR (A.ACTIVE_FLAG <> 'N' OR A.ACCOUNT_STATUS <> '2'))*/
      ;
  BEGIN
    V_CUSTOMER_ID := P_HEAD_ID;
    IF 0 >= NVL(P_HEAD_ID, 0) THEN
      SELECT H1.CUSTOMER_ID, H1.Customer_Code
        INTO V_CUSTOMER_ID, V_CUSTOMER_CODE
        FROM INTF_CUSTOMER_HEADER IH
       INNER JOIN T_CUSTOMER_HEADER H1
          ON (H1.SIEBEL_CUSTOMER_ID = IH.SIEBEL_CUSTOMER_ID)
       WHERE IH.CUSTOMER_ID = P_INTF_HEAD_ID;
    ELSE
      SELECT H.Customer_Code
        INTO V_CUSTOMER_CODE
        FROM T_CUSTOMER_HEADER H
       WHERE H.Customer_Id = V_CUSTOMER_ID;
    END IF;
  
    V_COUNT := 0;
    FOR LH IN C_H_CHANGED(V_CUSTOMER_ID) LOOP
      --
      FOR LH_DEPT IN C_H_DEPT_CHANGED(V_CUSTOMER_ID, LH.CUSTOMER_STATUS) LOOP
        UPDATE T_CUSTOMER_DEPT D
           SET D.ACTIVE_FLAG          = DECODE(LH.CUSTOMER_STATUS,
                                               'Freezing',
                                               'Active',
                                               LH.CUSTOMER_STATUS),
               D.DEPT_CUSTOMER_STATUS = LH.CUSTOMER_STATUS
         WHERE D.ID = LH_DEPT.ID;
        V_COUNT := (1 + V_COUNT);
      
        INSERT INTO T_CUSTOMER_STATUS_LOG
          (ID,
           CUSTOMER_ID,
           CUSTOMER_CODE,
           ACTIVE_FLAG,
           ENTITY_ID,
           DEPT_ID,
           DEPT_ACTIVE_FLAG,
           DEPT_CUSTOMER_STATUS,
           CUSTOMER_ORG_ID,
           ORG_ACTIVE_FLAG,
           ACCOUNT_ID,
           ACC_ACTIVE_FLAG,
           ACCOUNT_STATUS,
           ACC_CUSTOMER_ORG_ID,
           TAB_NAME,
           TAB_ID,
           REMARK)
        VALUES
          (SEQ_BD_ROW_ID.NEXTVAL,
           V_CUSTOMER_ID,
           V_CUSTOMER_CODE,
           LH.ACTIVE_FLAG,
           LH_DEPT.DEPT_ID,
           LH_DEPT.ID,
           LH_DEPT.ACTIVE_FLAG,
           LH_DEPT.DEPT_CUSTOMER_STATUS,
           NULL,
           NULL,
           NULL,
           NULL,
           NULL,
           NULL,
           'T_CUSTOMER_DEPT',
           LH_DEPT.ID,
           '客户' || DECODE(LH.CUSTOMER_STATUS,
                          'Freezing',
                          '冻结',
                          'Inactive',
                          '失效'));
      
        FOR LH_ORG IN C_H_ORG_CHANGED(V_CUSTOMER_ID,
                                      LH_DEPT.DEPT_ID,
                                      LH.CUSTOMER_STATUS) LOOP
          UPDATE T_CUSTOMER_ORG O
             SET O.ACTIVE_FLAG = LH.CUSTOMER_STATUS
           WHERE O.CUSTOMER_ORG_ID = LH_ORG.CUSTOMER_ORG_ID;
        
          INSERT INTO T_CUSTOMER_STATUS_LOG
            (ID,
             CUSTOMER_ID,
             CUSTOMER_CODE,
             ACTIVE_FLAG,
             ENTITY_ID,
             DEPT_ID,
             DEPT_ACTIVE_FLAG,
             DEPT_CUSTOMER_STATUS,
             CUSTOMER_ORG_ID,
             ORG_ACTIVE_FLAG,
             ACCOUNT_ID,
             ACC_ACTIVE_FLAG,
             ACCOUNT_STATUS,
             ACC_CUSTOMER_ORG_ID,
             TAB_NAME,
             TAB_ID,
             REMARK)
          VALUES
            (SEQ_BD_ROW_ID.NEXTVAL,
             V_CUSTOMER_ID,
             V_CUSTOMER_CODE,
             LH.ACTIVE_FLAG,
             LH_ORG.Entity_Id,
             LH_DEPT.ID,
             LH_DEPT.ACTIVE_FLAG,
             LH_DEPT.DEPT_CUSTOMER_STATUS,
             LH_ORG.CUSTOMER_ORG_ID,
             LH_ORG.Active_Flag,
             NULL,
             NULL,
             NULL,
             NULL,
             'T_CUSTOMER_ORG',
             LH_ORG.CUSTOMER_ORG_ID,
             '客户' || DECODE(LH.CUSTOMER_STATUS,
                            'Freezing',
                            '冻结',
                            'Inactive',
                            '失效'));
        END LOOP;
      
        FOR LH_ACC IN C_H_ACC_CHANGED(V_CUSTOMER_ID,
                                      LH_DEPT.DEPT_ID,
                                      NULL,
                                      LH.CUSTOMER_STATUS) LOOP
          UPDATE T_CUSTOMER_ACCOUNT A
             SET A.ACTIVE_FLAG    = DECODE(LH.ACTIVE_FLAG,
                                           'Active',
                                           'Y',
                                           'Freezing',
                                           'Y',
                                           'N'),
                 A.ACCOUNT_STATUS = DECODE(LH.CUSTOMER_STATUS,
                                           'Active',
                                           '1',
                                           'Freezing',
                                           '-1',
                                           '2'),
                 A.REMARK         = 'CIMS接收CRM推送的客户状态' ||
                                    DECODE(LH.CUSTOMER_STATUS,
                                           'Freezing',
                                           '已冻结，CIMS联动将账户冻结（自动），时间：',
                                           'Inactive',
                                           '已失效，CIMS联动将账户失效（自动），时间：') ||
                                    V_DATETIME_CHAR ||
                                    '。若有误请找到误操作人在CRM维护客户状态并推送给CIMS后再手工在CIMS手工维护账户状态（非自动），请自己掌握操作'
           WHERE A.ACCOUNT_ID = LH_ACC.ACCOUNT_ID;
          INSERT INTO T_CUSTOMER_STATUS_LOG
            (ID,
             CUSTOMER_ID,
             CUSTOMER_CODE,
             ACTIVE_FLAG,
             ENTITY_ID,
             DEPT_ID,
             DEPT_ACTIVE_FLAG,
             DEPT_CUSTOMER_STATUS,
             CUSTOMER_ORG_ID,
             ORG_ACTIVE_FLAG,
             ACCOUNT_ID,
             ACC_ACTIVE_FLAG,
             ACCOUNT_STATUS,
             ACC_CUSTOMER_ORG_ID,
             TAB_NAME,
             TAB_ID,
             REMARK)
          VALUES
            (SEQ_BD_ROW_ID.NEXTVAL,
             V_CUSTOMER_ID,
             V_CUSTOMER_CODE,
             LH.ACTIVE_FLAG,
             LH_ACC.Entity_Id,
             LH_DEPT.Id,
             LH_DEPT.ACTIVE_FLAG,
             LH_DEPT.DEPT_CUSTOMER_STATUS,
             NULL,
             NULL,
             LH_ACC.ACCOUNT_ID,
             LH_ACC.ACTIVE_FLAG,
             LH_ACC.ACCOUNT_STATUS,
             LH_ACC.CUSTOMER_ORG_ID,
             'T_CUSTOMER_ACCOUNT',
             LH_ACC.ACCOUNT_ID,
             '客户' || DECODE(LH.CUSTOMER_STATUS,
                            'Freezing',
                            '冻结',
                            'Inactive',
                            '失效'));
        END LOOP;
      END LOOP;
    
      --
      FOR LH_ORG IN C_H_ORG_CHANGED(V_CUSTOMER_ID, NULL, LH.CUSTOMER_STATUS) LOOP
        UPDATE T_CUSTOMER_ORG O
           SET O.ACTIVE_FLAG = LH.CUSTOMER_STATUS
         WHERE O.CUSTOMER_ORG_ID = LH_ORG.CUSTOMER_ORG_ID;
        V_COUNT := (1 + V_COUNT);
      
        INSERT INTO T_CUSTOMER_STATUS_LOG
          (ID,
           CUSTOMER_ID,
           CUSTOMER_CODE,
           ACTIVE_FLAG,
           ENTITY_ID,
           DEPT_ID,
           DEPT_ACTIVE_FLAG,
           DEPT_CUSTOMER_STATUS,
           CUSTOMER_ORG_ID,
           ORG_ACTIVE_FLAG,
           ACCOUNT_ID,
           ACC_ACTIVE_FLAG,
           ACCOUNT_STATUS,
           ACC_CUSTOMER_ORG_ID,
           TAB_NAME,
           TAB_ID,
           REMARK)
        VALUES
          (SEQ_BD_ROW_ID.NEXTVAL,
           V_CUSTOMER_ID,
           V_CUSTOMER_CODE,
           LH.ACTIVE_FLAG,
           LH_ORG.Entity_Id,
           NULL,
           NULL,
           NULL,
           LH_ORG.CUSTOMER_ORG_ID,
           LH_ORG.Active_Flag,
           NULL,
           NULL,
           NULL,
           NULL,
           'T_CUSTOMER_ORG',
           LH_ORG.CUSTOMER_ORG_ID,
           '客户' || DECODE(LH.CUSTOMER_STATUS,
                          'Freezing',
                          '冻结',
                          'Inactive',
                          '失效'));
      
        FOR LH_ACC IN C_H_ACC_CHANGED(V_CUSTOMER_ID,
                                      LH_ORG.Entity_Id,
                                      LH_ORG.CUSTOMER_ORG_ID,
                                      LH.CUSTOMER_STATUS) LOOP
          UPDATE T_CUSTOMER_ACCOUNT A
             SET A.ACTIVE_FLAG    = DECODE(LH.ACTIVE_FLAG,
                                           'Active',
                                           'Y',
                                           'Freezing',
                                           'Y',
                                           'N'),
                 A.ACCOUNT_STATUS = DECODE(LH.CUSTOMER_STATUS,
                                           'Active',
                                           '1',
                                           'Freezing',
                                           '-1',
                                           '2'),
                 A.REMARK         = 'CIMS接收CRM推送的客户状态' ||
                                    DECODE(LH.CUSTOMER_STATUS,
                                           'Freezing',
                                           '已冻结，CIMS联动将账户冻结（自动），时间：',
                                           'Inactive',
                                           '已失效，CIMS联动将账户失效（自动），时间：') ||
                                    V_DATETIME_CHAR ||
                                    '。若有误请找到误操作人在CRM维护客户状态并推送给CIMS后再手工在CIMS手工维护账户状态（非自动），请自己掌握操作'
           WHERE A.ACCOUNT_ID = LH_ACC.ACCOUNT_ID;
          INSERT INTO T_CUSTOMER_STATUS_LOG
            (ID,
             CUSTOMER_ID,
             CUSTOMER_CODE,
             ACTIVE_FLAG,
             ENTITY_ID,
             DEPT_ID,
             DEPT_ACTIVE_FLAG,
             DEPT_CUSTOMER_STATUS,
             CUSTOMER_ORG_ID,
             ORG_ACTIVE_FLAG,
             ACCOUNT_ID,
             ACC_ACTIVE_FLAG,
             ACCOUNT_STATUS,
             ACC_CUSTOMER_ORG_ID,
             TAB_NAME,
             TAB_ID,
             REMARK)
          VALUES
            (SEQ_BD_ROW_ID.NEXTVAL,
             V_CUSTOMER_ID,
             V_CUSTOMER_CODE,
             LH.ACTIVE_FLAG,
             LH_ACC.Entity_Id,
             NULL,
             NULL,
             NULL,
             LH_ORG.CUSTOMER_ORG_ID,
             LH_ORG.ACTIVE_FLAG,
             LH_ACC.ACCOUNT_ID,
             LH_ACC.ACTIVE_FLAG,
             LH_ACC.ACCOUNT_STATUS,
             LH_ACC.CUSTOMER_ORG_ID,
             'T_CUSTOMER_ACCOUNT',
             LH_ACC.ACCOUNT_ID,
             '客户' || DECODE(LH.CUSTOMER_STATUS,
                            'Freezing',
                            '冻结',
                            'Inactive',
                            '失效'));
        END LOOP;
      END LOOP;
    
      --
      FOR LH_ACC IN C_H_ACC_CHANGED(V_CUSTOMER_ID,
                                    NULL,
                                    NULL,
                                    LH.CUSTOMER_STATUS) LOOP
        UPDATE T_CUSTOMER_ACCOUNT A
           SET A.ACTIVE_FLAG    = DECODE(LH.ACTIVE_FLAG,
                                         'Active',
                                         'Y',
                                         'Freezing',
                                         'Y',
                                         'N'),
               A.ACCOUNT_STATUS = DECODE(LH.CUSTOMER_STATUS,
                                         'Active',
                                         '1',
                                         'Freezing',
                                         '-1',
                                         '2'),
               A.REMARK         = 'CIMS接收CRM推送的客户状态' ||
                                  DECODE(LH.CUSTOMER_STATUS,
                                         'Freezing',
                                         '已冻结，CIMS联动将账户冻结（自动），时间：',
                                         'Inactive',
                                         '已失效，CIMS联动将账户失效（自动），时间：') ||
                                  V_DATETIME_CHAR ||
                                  '。若有误请找到误操作人在CRM维护客户状态并推送给CIMS后再手工在CIMS手工维护账户状态（非自动），请自己掌握操作'
         WHERE A.ACCOUNT_ID = LH_ACC.ACCOUNT_ID;
        V_COUNT := (1 + V_COUNT);
        INSERT INTO T_CUSTOMER_STATUS_LOG
          (ID,
           CUSTOMER_ID,
           CUSTOMER_CODE,
           ACTIVE_FLAG,
           ENTITY_ID,
           DEPT_ID,
           DEPT_ACTIVE_FLAG,
           DEPT_CUSTOMER_STATUS,
           CUSTOMER_ORG_ID,
           ORG_ACTIVE_FLAG,
           ACCOUNT_ID,
           ACC_ACTIVE_FLAG,
           ACCOUNT_STATUS,
           ACC_CUSTOMER_ORG_ID,
           TAB_NAME,
           TAB_ID,
           REMARK)
        VALUES
          (SEQ_BD_ROW_ID.NEXTVAL,
           V_CUSTOMER_ID,
           V_CUSTOMER_CODE,
           LH.ACTIVE_FLAG,
           LH_ACC.Entity_Id,
           NULL,
           NULL,
           NULL,
           NULL,
           NULL,
           LH_ACC.ACCOUNT_ID,
           LH_ACC.ACTIVE_FLAG,
           LH_ACC.ACCOUNT_STATUS,
           LH_ACC.CUSTOMER_ORG_ID,
           'T_CUSTOMER_ACCOUNT',
           LH_ACC.ACCOUNT_ID,
           '客户' || DECODE(LH.CUSTOMER_STATUS,
                          'Freezing',
                          '冻结',
                          'Inactive',
                          '失效'));
      END LOOP;
    END LOOP;
  
    IF (0 < V_COUNT) THEN
      RETURN;
    END IF;
  
    --
    FOR LH_DEPT IN C_DEPT_CHANGED(V_CUSTOMER_ID) LOOP
      V_ACTIVE_FLAG := LH_DEPT.DEPT_CUSTOMER_STATUS;
      IF (LH_DEPT.ACTIVE_FLAG <> 'Inactive' AND
         LH_DEPT.DEPT_CUSTOMER_STATUS = 'Inactive') THEN
        V_ACTIVE_FLAG := 'Inactive';
        UPDATE T_CUSTOMER_DEPT D
           SET D.ACTIVE_FLAG = V_ACTIVE_FLAG
         WHERE D.ID = LH_DEPT.ID;
        V_LOG_ACTIVE_FLAG          := NULL;
        V_LOG_DEPT_CUSTOMER_STATUS := V_ACTIVE_FLAG;
      ELSIF (LH_DEPT.DEPT_CUSTOMER_STATUS <> 'Inactive' AND
            LH_DEPT.ACTIVE_FLAG = 'Inactive') THEN
        V_ACTIVE_FLAG := 'Inactive';
        UPDATE T_CUSTOMER_DEPT D
           SET D.DEPT_CUSTOMER_STATUS = V_ACTIVE_FLAG
         WHERE D.ID = LH_DEPT.ID;
        V_LOG_ACTIVE_FLAG          := V_ACTIVE_FLAG;
        V_LOG_DEPT_CUSTOMER_STATUS := NULL;
      ELSIF (LH_DEPT.ACTIVE_FLAG = 'Freezing') THEN
        V_ACTIVE_FLAG := LH_DEPT.ACTIVE_FLAG;
        UPDATE T_CUSTOMER_DEPT D
           SET D.DEPT_CUSTOMER_STATUS = V_ACTIVE_FLAG,
               D.ACTIVE_FLAG          = DECODE(V_ACTIVE_FLAG,
                                               'Freezing',
                                               'Active',
                                               V_ACTIVE_FLAG)
         WHERE D.ID = LH_DEPT.ID;
        V_LOG_ACTIVE_FLAG          := V_ACTIVE_FLAG;
        V_LOG_DEPT_CUSTOMER_STATUS := NULL;
      ELSIF (LH_DEPT.DEPT_CUSTOMER_STATUS = 'Freezing' AND
            LH_DEPT.ACTIVE_FLAG <> 'Active') THEN
        V_ACTIVE_FLAG := LH_DEPT.DEPT_CUSTOMER_STATUS;
        UPDATE T_CUSTOMER_DEPT D
           SET D.ACTIVE_FLAG = DECODE(V_ACTIVE_FLAG,
                                      'Freezing',
                                      'Active',
                                      V_ACTIVE_FLAG)
         WHERE D.ID = LH_DEPT.ID;
        V_LOG_ACTIVE_FLAG          := NULL;
        V_LOG_DEPT_CUSTOMER_STATUS := V_ACTIVE_FLAG;
      END IF;
    
      IF (V_LOG_ACTIVE_FLAG IS NOT NULL) OR
         (V_LOG_DEPT_CUSTOMER_STATUS IS NOT NULL) THEN
        INSERT INTO T_CUSTOMER_STATUS_LOG
          (ID,
           CUSTOMER_ID,
           CUSTOMER_CODE,
           ACTIVE_FLAG,
           ENTITY_ID,
           DEPT_ID,
           DEPT_ACTIVE_FLAG,
           DEPT_CUSTOMER_STATUS,
           CUSTOMER_ORG_ID,
           ORG_ACTIVE_FLAG,
           ACCOUNT_ID,
           ACC_ACTIVE_FLAG,
           ACCOUNT_STATUS,
           ACC_CUSTOMER_ORG_ID,
           TAB_NAME,
           TAB_ID,
           REMARK)
        VALUES
          (SEQ_BD_ROW_ID.NEXTVAL,
           V_CUSTOMER_ID,
           V_CUSTOMER_CODE,
           NULL,
           LH_DEPT.DEPT_ID,
           LH_DEPT.ID,
           V_LOG_ACTIVE_FLAG,
           V_LOG_DEPT_CUSTOMER_STATUS,
           NULL,
           NULL,
           NULL,
           NULL,
           NULL,
           NULL,
           'T_CUSTOMER_DEPT',
           LH_DEPT.ID,
           '事业部' ||
           DECODE(V_ACTIVE_FLAG, 'Freezing', '冻结', 'Inactive', '失效'));
      END IF;
    
      FOR LH_ORG IN C_H_ORG_CHANGED(V_CUSTOMER_ID,
                                    LH_DEPT.DEPT_ID,
                                    V_ACTIVE_FLAG) LOOP
        UPDATE T_CUSTOMER_ORG O
           SET O.ACTIVE_FLAG = V_ACTIVE_FLAG
         WHERE O.CUSTOMER_ORG_ID = LH_ORG.CUSTOMER_ORG_ID;
        V_COUNT := (1 + V_COUNT);
        INSERT INTO T_CUSTOMER_STATUS_LOG
          (ID,
           CUSTOMER_ID,
           CUSTOMER_CODE,
           ACTIVE_FLAG,
           ENTITY_ID,
           DEPT_ID,
           DEPT_ACTIVE_FLAG,
           DEPT_CUSTOMER_STATUS,
           CUSTOMER_ORG_ID,
           ORG_ACTIVE_FLAG,
           ACCOUNT_ID,
           ACC_ACTIVE_FLAG,
           ACCOUNT_STATUS,
           ACC_CUSTOMER_ORG_ID,
           TAB_NAME,
           TAB_ID,
           REMARK)
        VALUES
          (SEQ_BD_ROW_ID.NEXTVAL,
           V_CUSTOMER_ID,
           V_CUSTOMER_CODE,
           NULL,
           LH_ORG.ENTITY_ID,
           LH_DEPT.ID,
           LH_DEPT.ACTIVE_FLAG,
           LH_DEPT.DEPT_CUSTOMER_STATUS,
           LH_ORG.CUSTOMER_ORG_ID,
           LH_ORG.ACTIVE_FLAG,
           NULL,
           NULL,
           NULL,
           NULL,
           'T_CUSTOMER_ORG',
           LH_ORG.CUSTOMER_ORG_ID,
           '事业部' ||
           DECODE(V_ACTIVE_FLAG, 'Freezing', '冻结', 'Inactive', '失效'));
      
        FOR LH_ACC IN C_H_ACC_CHANGED(V_CUSTOMER_ID,
                                      LH_DEPT.DEPT_ID,
                                      LH_ORG.CUSTOMER_ORG_ID,
                                      V_ACTIVE_FLAG) LOOP
          UPDATE T_CUSTOMER_ACCOUNT A
             SET A.ACTIVE_FLAG    = DECODE(V_ACTIVE_FLAG,
                                           'Active',
                                           'Y',
                                           'Freezing',
                                           'Y',
                                           'N'),
                 A.ACCOUNT_STATUS = DECODE(V_ACTIVE_FLAG,
                                           'Active',
                                           '1',
                                           'Freezing',
                                           '-1',
                                           '2'),
                 A.REMARK         = 'CIMS接收CRM推送的客户事业部状态' ||
                                    DECODE(V_ACTIVE_FLAG,
                                           'Freezing',
                                           '已冻结，CIMS联动将账户冻结（自动），时间：',
                                           'Inactive',
                                           '已失效，CIMS联动将账户失效（自动），时间：') ||
                                    V_DATETIME_CHAR ||
                                    '。若有误请找到误操作人在CRM维护客户事业部状态并推送给CIMS后再手工在CIMS手工维护账户状态（非自动），请自己掌握操作'
           WHERE A.ACCOUNT_ID = LH_ACC.ACCOUNT_ID;
          INSERT INTO T_CUSTOMER_STATUS_LOG
            (ID,
             CUSTOMER_ID,
             CUSTOMER_CODE,
             ACTIVE_FLAG,
             ENTITY_ID,
             DEPT_ID,
             DEPT_ACTIVE_FLAG,
             DEPT_CUSTOMER_STATUS,
             CUSTOMER_ORG_ID,
             ORG_ACTIVE_FLAG,
             ACCOUNT_ID,
             ACC_ACTIVE_FLAG,
             ACCOUNT_STATUS,
             ACC_CUSTOMER_ORG_ID,
             TAB_NAME,
             TAB_ID,
             REMARK)
          VALUES
            (SEQ_BD_ROW_ID.NEXTVAL,
             V_CUSTOMER_ID,
             V_CUSTOMER_CODE,
             NULL,
             LH_DEPT.Dept_Id,
             LH_DEPT.ID,
             LH_DEPT.ACTIVE_FLAG,
             LH_DEPT.DEPT_CUSTOMER_STATUS,
             LH_ORG.CUSTOMER_ORG_ID,
             LH_ORG.ACTIVE_FLAG,
             LH_ACC.ACCOUNT_ID,
             LH_ACC.ACTIVE_FLAG,
             LH_ACC.ACCOUNT_STATUS,
             LH_ACC.CUSTOMER_ORG_ID,
             'T_CUSTOMER_ACCOUNT',
             LH_ACC.ACCOUNT_ID,
             '事业部' ||
             DECODE(V_ACTIVE_FLAG, 'Freezing', '冻结', 'Inactive', '失效'));
        END LOOP;
      END LOOP;
    
      FOR LH_ACC IN C_H_ACC_CHANGED(V_CUSTOMER_ID,
                                    LH_DEPT.DEPT_ID,
                                    NULL,
                                    V_ACTIVE_FLAG) LOOP
        UPDATE T_CUSTOMER_ACCOUNT A
           SET A.ACTIVE_FLAG    = DECODE(V_ACTIVE_FLAG,
                                         'Active',
                                         'Y',
                                         'Freezing',
                                         'Y',
                                         'N'),
               A.ACCOUNT_STATUS = DECODE(V_ACTIVE_FLAG,
                                         'Active',
                                         '1',
                                         'Freezing',
                                         '-1',
                                         '2'),
               A.REMARK         = 'CIMS接收CRM推送的客户事业部状态' ||
                                  DECODE(V_ACTIVE_FLAG,
                                         'Freezing',
                                         '已冻结，CIMS联动将账户冻结（自动），时间：',
                                         'Inactive',
                                         '已失效，CIMS联动将账户失效（自动），时间：') ||
                                  V_DATETIME_CHAR ||
                                  '。若有误请找到误操作人在CRM维护客户事业部状态并推送给CIMS后再手工在CIMS手工维护账户状态（非自动），请自己掌握操作'
         WHERE A.ACCOUNT_ID = LH_ACC.ACCOUNT_ID;
        INSERT INTO T_CUSTOMER_STATUS_LOG
          (ID,
           CUSTOMER_ID,
           CUSTOMER_CODE,
           ACTIVE_FLAG,
           ENTITY_ID,
           DEPT_ID,
           DEPT_ACTIVE_FLAG,
           DEPT_CUSTOMER_STATUS,
           CUSTOMER_ORG_ID,
           ORG_ACTIVE_FLAG,
           ACCOUNT_ID,
           ACC_ACTIVE_FLAG,
           ACCOUNT_STATUS,
           ACC_CUSTOMER_ORG_ID,
           TAB_NAME,
           TAB_ID,
           REMARK)
        VALUES
          (SEQ_BD_ROW_ID.NEXTVAL,
           V_CUSTOMER_ID,
           V_CUSTOMER_CODE,
           NULL,
           LH_ACC.ENTITY_ID,
           LH_DEPT.ID,
           LH_DEPT.ACTIVE_FLAG,
           LH_DEPT.DEPT_CUSTOMER_STATUS,
           NULL,
           NULL,
           LH_ACC.ACCOUNT_ID,
           LH_ACC.ACTIVE_FLAG,
           LH_ACC.ACCOUNT_STATUS,
           LH_ACC.CUSTOMER_ORG_ID,
           'T_CUSTOMER_ACCOUNT',
           LH_ACC.ACCOUNT_ID,
           '事业部' ||
           DECODE(V_ACTIVE_FLAG, 'Freezing', '冻结', 'Inactive', '失效'));
      END LOOP;
    END LOOP;
  
    IF (0 < V_COUNT) THEN
      RETURN;
    END IF;
  
    --
    FOR LH_ORG IN C_ORG_CHANGED(V_CUSTOMER_ID) LOOP
      V_ACTIVE_FLAG := LH_ORG.ACTIVE_FLAG;
    
      FOR LH_ACC IN C_H_ACC_CHANGED(V_CUSTOMER_ID,
                                    LH_ORG.ENTITY_ID,
                                    LH_ORG.CUSTOMER_ORG_ID,
                                    V_ACTIVE_FLAG) LOOP
        UPDATE T_CUSTOMER_ACCOUNT A
           SET A.ACTIVE_FLAG    = DECODE(V_ACTIVE_FLAG,
                                         'Active',
                                         'Y',
                                         'Freezing',
                                         'Y',
                                         'N'),
               A.ACCOUNT_STATUS = DECODE(V_ACTIVE_FLAG,
                                         'Active',
                                         '1',
                                         'Freezing',
                                         '-1',
                                         '2'),
               A.REMARK         = 'CIMS接收CRM推送的客户中心状态' ||
                                  DECODE(V_ACTIVE_FLAG,
                                         'Freezing',
                                         '已冻结，CIMS联动将账户冻结（自动），时间：',
                                         'Inactive',
                                         '已失效，CIMS联动将账户失效（自动），时间：') ||
                                  V_DATETIME_CHAR ||
                                  '。若有误请找到误操作人在CRM维护客户中心状态并推送给CIMS后再手工在CIMS手工维护账户状态（非自动），请自己掌握操作' ||
                                  '。所挂客户中心：' || LH_ORG.SALES_CENTER_NAME
         WHERE A.ACCOUNT_ID = LH_ACC.ACCOUNT_ID;
        V_COUNT := (1 + V_COUNT);
        INSERT INTO T_CUSTOMER_STATUS_LOG
          (ID,
           CUSTOMER_ID,
           CUSTOMER_CODE,
           ACTIVE_FLAG,
           ENTITY_ID,
           DEPT_ID,
           DEPT_ACTIVE_FLAG,
           DEPT_CUSTOMER_STATUS,
           CUSTOMER_ORG_ID,
           ORG_ACTIVE_FLAG,
           ACCOUNT_ID,
           ACC_ACTIVE_FLAG,
           ACCOUNT_STATUS,
           ACC_CUSTOMER_ORG_ID,
           TAB_NAME,
           TAB_ID,
           REMARK)
        VALUES
          (SEQ_BD_ROW_ID.NEXTVAL,
           V_CUSTOMER_ID,
           V_CUSTOMER_CODE,
           NULL,
           LH_ORG.ENTITY_ID,
           NULL,
           NULL,
           NULL,
           LH_ORG.CUSTOMER_ORG_ID,
           V_ACTIVE_FLAG,
           LH_ACC.ACCOUNT_ID,
           LH_ACC.ACTIVE_FLAG,
           LH_ACC.ACCOUNT_STATUS,
           LH_ACC.CUSTOMER_ORG_ID,
           'T_CUSTOMER_ACCOUNT',
           LH_ACC.ACCOUNT_ID,
           '客户中心' ||
           DECODE(V_ACTIVE_FLAG, 'Freezing', '冻结', 'Inactive', '失效'));
      END LOOP;
    END LOOP;
  
    IF (0 < V_COUNT) THEN
      NULL;
    END IF;
  END PRC_UPDATE_STATUS_CHANGED;

  PROCEDURE P_CUSTOMER_INTF_PROC(IS_WHAT           IN VARCHAR2, --
                                 IS_USER_ACCOUNT   IN VARCHAR2, --
                                 IS_INTF_HEADER_ID IN VARCHAR2, --
                                 OS_MESSAGE        OUT VARCHAR2 --成功则返回“SUCCESS”，否则返回出错信息
                                 ) IS
    V_MAX_INTF_HEADER_ID NUMBER;
    V_WHAT               VARCHAR2(100);
    V_WHAT1              VARCHAR2(100);
    V_MAX_TRANSCODE      INTF_CUSTOMER_HEADER.TRANSCODE%TYPE;
  BEGIN
    V_WHAT1 := LOWER(IS_WHAT);
    V_WHAT  := V_WHAT1;
    IF V_WHAT = 'header' OR V_WHAT = 'all' THEN
      V_WHAT1     := '客户头';
      OS_MESSAGE := F_INSERT_OR_UPDATE_HEADER(IS_INTF_HEADER_ID);
    END IF;
    IF V_WHAT = 'addr' OR V_WHAT = 'all' THEN
      V_WHAT1     := '客户地址';
      OS_MESSAGE := F_INSERT_OR_UPDATE_ADDRESS(IS_INTF_HEADER_ID);
    END IF;
    IF V_WHAT = 'contacts' OR V_WHAT = 'all' THEN
      V_WHAT1     := '客户联系人';
      OS_MESSAGE := F_INSERT_OR_UPDATE_CONTACTS(IS_INTF_HEADER_ID);
    END IF;
    IF V_WHAT = 'brand' OR V_WHAT = 'all' THEN
      V_WHAT1     := '客户经营品牌';
      OS_MESSAGE := F_INSERT_OR_UPDATE_BRAND(IS_INTF_HEADER_ID);
    END IF;
    IF V_WHAT = 'bank' OR V_WHAT = 'all' THEN
      V_WHAT1     := '客户银行信息';
      OS_MESSAGE := F_INSERT_OR_UPDATE_BANK(IS_INTF_HEADER_ID);
    END IF;
    IF V_WHAT = 'org' OR V_WHAT = 'all' THEN
      V_WHAT1     := '客户营销中心';
      OS_MESSAGE := F_INSERT_OR_UPDATE_ORG(IS_INTF_HEADER_ID);
    END IF;
    IF V_WHAT = 'dept' OR V_WHAT = 'all' THEN
      V_WHAT1     := '客户事业部';
      OS_MESSAGE := F_INSERT_OR_UPDATE_DEPT(IS_INTF_HEADER_ID);
    END IF;
    IF V_WHAT = 'channeltype' OR V_WHAT = 'all' THEN
      V_WHAT1     := '客户业态类型';
      OS_MESSAGE := F_INSERT_OR_UPDATE_CHANN_TYPE(IS_INTF_HEADER_ID);
    END IF;
    IF V_WHAT = 'ou' OR V_WHAT = 'all' THEN
      V_WHAT1     := '客户OU';
      OS_MESSAGE := F_INSERT_OR_UPDATE_OU(IS_INTF_HEADER_ID);
    END IF;
    IF V_WHAT = 'all' THEN
      V_WHAT1     := '客户';
    END IF;
    V_WHAT  := V_WHAT1;
    WITH WT AS
     (SELECT IH.CUSTOMER_ID,
             IH.TRANSCODE,
             DENSE_RANK() OVER(PARTITION BY IH.SIEBEL_CUSTOMER_ID ORDER BY IH.LAST_UPDATE_DATE DESC, IH.TRANSCODE DESC, IH.CUSTOMER_ID DESC) AS RK
        FROM INTF_CUSTOMER_HEADER IH
       WHERE EXISTS
       (SELECT 1
                FROM INTF_CUSTOMER_HEADER H
               WHERE H.CUSTOMER_ID = IS_INTF_HEADER_ID
                 AND IH.SIEBEL_CUSTOMER_ID = H.SIEBEL_CUSTOMER_ID))
    SELECT CUSTOMER_ID, TRANSCODE
      INTO V_MAX_INTF_HEADER_ID, V_MAX_TRANSCODE
      FROM WT
     WHERE RK = 1
       AND 1 = ROWNUM;
  --SUCCESS
    IF V_WHAT = '客户头' THEN
      UPDATE INTF_CUSTOMER_HEADER
         SET RESPONSETYPE    = DECODE(OS_MESSAGE,'SUCCESS', 'N','E'),
             RESPNOSECODE    = DECODE(OS_MESSAGE,'SUCCESS', '000000','000013'),
             RESPONSEMESSAGE = OS_MESSAGE,
             OPERSTATUS      = DECODE(OS_MESSAGE,'SUCCESS', '0','1')
       WHERE CUSTOMER_ID = IS_INTF_HEADER_ID;
    END IF;
    IF OS_MESSAGE = 'SUCCESS' THEN
      OS_MESSAGE := '处理成功';
    ELSE
      OS_MESSAGE := '处理失败：' || OS_MESSAGE;
    END IF;
    OS_MESSAGE := V_WHAT || OS_MESSAGE;
    IF V_MAX_INTF_HEADER_ID <> IS_INTF_HEADER_ID THEN
      OS_MESSAGE := OS_MESSAGE || '。处理的不是最新的数据，最新的流水号：' || V_MAX_TRANSCODE;
    END IF;
  
  END P_CUSTOMER_INTF_PROC;

  PROCEDURE P_INVALID_HIS_PRE01_PROC(IS_USER_ACCOUNT   IN VARCHAR2, --
                                 IS_INVALID_HIS_ID IN VARCHAR2, --
                                 OS_MESSAGE        OUT VARCHAR2 --成功则返回“SUCCESS”，否则返回出错信息
                                 ) IS
    --VT_PRE_FIELD_01              INTF_CUSTOMER_INVALID_HIS.PRE_FIELD_01%TYPE;
  BEGIN
    UPDATE INTF_CUSTOMER_INVALID_HIS H SET H.PRE_FIELD_01 = DECODE(H.PRE_FIELD_01,'Y','N','Y')
    ,H.LAST_UPDATE_DATE = SYSDATE,H.LAST_UPDATE_BY = IS_USER_ACCOUNT
    WHERE H.INVALID_ID = IS_INVALID_HIS_ID AND (H.PRE_FIELD_01 IS NULL OR H.PRE_FIELD_01 = 'Y')
    AND 'N' = H.CAN_INVALID;
    SELECT DECODE(CAN_INVALID,'Y','已允许失效，不需手工处理',DECODE(PRE_FIELD_01,'Y','开关生效：手工可失效请重推','开关关闭：不可手工失效'))
    INTO OS_MESSAGE
    FROM INTF_CUSTOMER_INVALID_HIS WHERE INVALID_ID = IS_INVALID_HIS_ID;
  END P_INVALID_HIS_PRE01_PROC;
  
 /**
 *客户主数据接口超时处理（无响应）
 */
 PROCEDURE P_CUST_INTF_TIMEOUT_HANDLE(IN_BEFORE_DAYS      IN VARCHAR2, --
                                      IN_CLEAR_OVER_COUNT IN NUMBER, --
                                      IN_BF_MONTHS_CLR    IN NUMBER, --
                                      OS_MESSAGE          OUT VARCHAR2 --成功则返回“SUCCESS”，否则返回出错信息
                                      ) IS
   TYPE REC_FL IS RECORD
   (
   I1 INTF_CUSTOMER_HEADER.CUSTOMER_ID%TYPE,
   I2 INTF_CUSTOMER_HEADER.CUSTOMER_ID%TYPE
   );
   TYPE T_FL IS TABLE OF REC_FL
   INDEX BY BINARY_INTEGER
   --INDEX BY [BINARY_INTEGER|PLS_INTEGER|VARRAY2]
   ;
   V_FL T_FL;
   VN_BEFORE_DAYS NUMBER := TO_NUMBER(NVL(IN_BEFORE_DAYS, '1'));
 BEGIN
   OS_MESSAGE := 'SUCCESS';
   select H.CUSTOMER_ID, max(h0.customer_id) AS CUSTOMER_ID_NEW
   BULK COLLECT INTO V_FL
                from (select t.customer_id
                        from cims.intf_customer_header t
                       where t.responsetype is null
                         and t.last_interface_date > sysdate - VN_BEFORE_DAYS
                      union
                      select to_number(t.pre_field_01) as customer_id
                        from cims.intf_customer_dept t
                       where t.responsetype is null
                         and t.last_interface_date > sysdate - VN_BEFORE_DAYS
                      union
                      select to_number(t.pre_field_01) as customer_id
                        from cims.intf_customer_address t
                       where t.responsetype is null
                         and t.last_interface_date > sysdate - VN_BEFORE_DAYS
                      union
                      select to_number(t.pre_field_01) as customer_id
                        from cims.intf_customer_bank t
                       where t.responsetype is null
                         and t.last_interface_date > sysdate - VN_BEFORE_DAYS
                      union
                      select to_number(t.pre_field_01) as customer_id
                        from cims.intf_customer_brand t
                       where t.responsetype is null
                         and t.last_interface_date > sysdate - VN_BEFORE_DAYS
                      union
                      select to_number(t.pre_field_01) as customer_id
                        from cims.intf_customer_channel_type t
                       where t.responsetype is null
                         and t.last_interface_date > sysdate - VN_BEFORE_DAYS
                      union
                      select to_number(t.pre_field_01) as customer_id
                        from cims.intf_customer_connection t
                       where t.responsetype is null
                         and t.last_interface_date > sysdate - VN_BEFORE_DAYS
                      union
                      select to_number(t.pre_field_01) as customer_id
                        from cims.intf_customer_contacts t
                       where t.responsetype is null
                         and t.last_interface_date > sysdate - VN_BEFORE_DAYS
                      union
                      select to_number(t.pre_field_01) as customer_id
                        from cims.intf_customer_org t
                       where t.responsetype is null
                         and t.last_interface_date > sysdate - VN_BEFORE_DAYS
                      union
                      select to_number(t.pre_field_01) as customer_id
                        from cims.intf_customer_ou t
                       where t.responsetype is null
                         and t.last_interface_date > sysdate - VN_BEFORE_DAYS) nt
               inner join cims.intf_customer_header h
                  on (h.customer_id = nt.customer_id)
                left join cims.intf_customer_header h0
                  on (h0.customer_id > h.customer_id and
                     h0.siebel_customer_id = h.siebel_customer_id and h0.responsetype is not null)
               group by h.customer_id
               order by h.customer_id;
   IF 0 < V_FL.COUNT THEN
     FOR V_INDEX IN V_FL.FIRST .. V_FL.LAST LOOP
       P_CUSTOMER_INTF_PROC(V_FL(V_INDEX).I1, OS_MESSAGE, 'NOTGTWIDTH');
       IF V_FL(V_INDEX).I2 > 0 THEN
         P_CUSTOMER_INTF_PROC(V_FL(V_INDEX).I2, OS_MESSAGE, 'NOTGTWIDTH');
       END IF;
     END LOOP;
   END IF;
 END P_CUST_INTF_TIMEOUT_HANDLE;
  
 /**
 *客户主数据接口失败处理
 */
 PROCEDURE P_CUST_INTF_FAILURE_HANDLE(OS_MESSAGE OUT VARCHAR2 --成功则返回“SUCCESS”，否则返回出错信息
                                      ) IS
 BEGIN
   --推送组织没有插入到正式表的处理
   FOR LI IN (select ico.siebel_org_id,
                     d.customer_code,
                     du.entity_id,
                     su.name,
                     max(to_number(ico.pre_field_01)) AS ID
                from intf_customer_org ico
               inner join intf_customer_dept icd
                  on (icd.siebel_id = ico.parent_id)
               inner join up_org_unit du
                  on (du.code = icd.dept_code and
                     du.type_code in ('BU', 'MC'))
               inner join up_org_unit su
                  on (su.code = ico.sales_center_code and
                     su.entity_id = du.entity_id and
                     su.type_code in ('SC', 'SD'))
               inner join t_customer_dept d
                  on (d.siebel_id = icd.siebel_id)
               where not exists
               (select 1
                        from t_customer_org co
                       where co.entity_id = du.entity_id
                         and co.siebel_org_id = ico.siebel_org_id)
               group by ico.siebel_org_id,
                        d.customer_code,
                        du.entity_id,
                        su.name) LOOP
     OS_MESSAGE := F_INSERT_OR_UPDATE_ORG(LI.ID);
   END LOOP;
   --推送组织名称冗余字段与正式表不一致的处理
   FOR LI IN (select co.customer_org_id,
                     max(to_number(ico.pre_field_01)) AS ID
                from t_customer_org co
               inner join intf_customer_org ico
                  on (co.siebel_org_id = ico.siebel_org_id)
               inner join up_org_unit u
                  on (co.entity_id = u.entity_id and
                     co.sales_center_id = u.unit_id and
                     u.name <> co.sales_center_name)
               group by co.customer_org_id) LOOP
     OS_MESSAGE := F_INSERT_OR_UPDATE_ORG(LI.ID);
   END LOOP;
 END P_CUST_INTF_FAILURE_HANDLE;

END PKG_CUSTOMER_INTF_NEW;
/

