create Package Body Pkg_Pln_Intf_Ims Is

  v_Intf_Exception   Exception;
  v_Nl               Constant Varchar2(2) := Chr(13) || Chr(10); --换行
  v_True             Constant Varchar2(2) := 'Y';
  v_False            Constant Varchar2(2) := 'N';
  v_Active           Constant Varchar2(10) := 'Active';
  v_Success          Constant Varchar2(10) := 'SUCCESS';
  v_Account_Active   Constant Varchar2(10) := '1'; --有效
  v_Account_Noactive Constant Varchar2(10) := '2'; --无效

  v_Status_Init    Constant Varchar2(10) :='01'; --接口表状态
  v_Status_Sucess  Constant Varchar2(10) :='02';
  v_Status_Fail    Constant Varchar2(10) :='03';

  v_head_state_init     Constant Varchar2(50) :='19';  --制单状态
  v_head_state_back     Constant Varchar2(50) :='415'; --已驳回状态
  v_head_state_send     Constant Varchar2(50) :='20';  --已送审状态
  v_head_state_check    Constant Varchar2(50) :='23';  --评审完毕
  v_head_state_make     Constant Varchar2(50) :='32';  --已排产
  v_head_state_finish   Constant Varchar2(50) :='306'; --已完成(销售回写）


  v_Account_Parameter      Constant Varchar2(500) :='ACCOUNT_SYS';
  v_Main_Parameter         Constant Varchar2(500) :='ITEM_SALES_MAIN_TYPE_FILTER';
  v_Sub_Parameter          Constant Varchar2(500) :='ITEM_SALES_SUB_TYPE_FILTER';
  v_Bussiness_Control      Constant Varchar2(500) :='share_ship_order';
  v_Pro_Order              CONSTANT VARCHAR2(500) := 'pro_order'; --推广物料

  ------------------------------------------------------------------------------------------
  -- Author  : NICRO.LI
  -- Created : 2015-07-18 17:24:25
  -- Purpose : IMS物流订单引入CIMS提货订单接口
  ------------------------------------------------------------------------------------------
  Procedure p_Create_Lgorder(p_Intf_Id In Number, p_Result Out Varchar2) Is
    r_Pln_Lg_Order_Head     Intf_Pln_Lg_Order_Head%Rowtype;
    r_Pln_Lg_Order_Headlock t_Pln_Lg_Order_Head%Rowtype;

    Cursor c_Pln_Lg_Order_Line Is
      Select *
        From Intf_Pln_Lg_Order_Line Ol
       Where Ol.Intf_Head_Id = p_Intf_Id
         And Ol.Intf_Status = v_Status_Init;
    r_Pln_Lg_Order_Line c_Pln_Lg_Order_Line%Rowtype;

    r_Pln_Order_Type t_Pln_Order_Type%Rowtype;

    v_Value           Varchar2(1000);
    v_Count           Number;
    v_Entity_Name     Varchar2(100);
    v_Sys_Source      Varchar2(50);
    v_Item_Id         Number;
    v_Item_Desc       Varchar2(240);
    v_Item_Uom        Varchar2(32);
    v_Is_Rounding     Varchar2(2);
    v_Rounding_Cnt    Number;
    v_Sales_Main_Type Varchar2(32);
    v_Sales_Sub_Type  Varchar2(32);
    v_Order_Type_Code Varchar2(40);
    v_Order_Type_Name Varchar2(100);

    v_Sales_Center_Code Varchar2(100);
    v_Sales_Center_Name Varchar2(240);

    v_Customer_Code Varchar2(100);
    v_Customer_Name Varchar2(240);
    v_Customer_Id   Number;

    v_Account_Id   Number;
    v_Account_Code Varchar2(100);
    v_Account_Name Varchar2(240);

    v_Invoice_Contract_Id Number; --开票单位联系人ID
    v_Invoice_Contract    Varchar2(100); --开票单位联系人名称
    v_Invoice_Tel         Varchar2(100); --开票单位联系人电话

    v_Consignee_Id   Number; --收货单位ID
    v_Consignee_Code Varchar2(240); --收货单位编码
    v_Consignee_Name Varchar2(240); --收货单位名称

    v_Consignment_Addr_Id  Number; --收货地点ID
    v_Consignee_Addr       Varchar2(240); --收货地址
    v_Consignee_Addr_Code  Varchar2(240); --收货地址编码
    v_Consignee_Contact_Id Number; --收货联系人ID
    v_Consignee_Contract   Varchar2(240); --收货联系人
    v_Consignee_Tel        Varchar2(240); --收货联系电话
    --产品价格
    v_Apply_Price    Number; --批文申请价
    v_Apply_Cnt      Number; --批文可使用数量
    v_Apply_Discount Number; --批文折扣
    v_Item_Price     Number; --产品价格
    v_Discount       Number; --折扣
    v_Month_Discount Number; --月返
    v_Cx_Flag        Varchar2(10); --是否促销机
    v_Apply_Amount   Number; --申请金额
    v_Apply_Type     Varchar2(128); --批文类型
    v_Apply_Code     Varchar2(32); --批文编码

    v_Lg_Order_Head_Id Number; --提货订单头ID
    v_Order_Number     Varchar2(100); --订单编码
    v_Lg_Order_Line_Id Number; --提货订单行ID

    v_Message       Varchar2(500);
    v_Ordertypecode Varchar2(32);

    v_Is_Material  t_Bd_Item.Is_Material%Type; --物料标志
    v_Default_Unit t_Bd_Item.Defaultunit%Type; --产品单位

    v_Producing_Area_Id     Number;
    v_Producing_Area_Code   t_Pln_Producing_Area.Producing_Area_Code%Type;
    v_Producing_Area_Name   t_Pln_Producing_Area.Producing_Area_Name%Type;
    v_Pln_Is_Merge_Lg_Order Varchar2(100);
    v_Consignee_Add_4_Flag  Varchar2(10); --add by lizhen 2016-01-16
    --Pragma Autonomous_Transaction;
  Begin
    p_Result := v_Success;
    ----------------------------------------------------------------------
    --  接口数据头表数据检测
    ----------------------------------------------------------------------

    --检测订单接口
    Begin
      v_Value := '锁定订单接口头表失败！';
      Select *
        Into r_Pln_Lg_Order_Head
        From Intf_Pln_Lg_Order_Head h
       Where h.Intf_Id = p_Intf_Id
         And h.Intf_Status = v_Status_Init
         For Update Nowait;
    Exception
      When Others Then
        p_Result := v_Value || v_Nl || Sqlerrm;
        Raise v_Intf_Exception;
    End;

    If p_Result = v_Success Then
      v_Value := '来源系统检测：';
      If Nvl(r_Pln_Lg_Order_Head.Sys_Source, '_') = '_' Then
        p_Result := v_Value || '未录入来源系统标示。';
        Raise v_Intf_Exception;
      End If;
    End If;
    
    --add by lizhen 2016-01-16 快码设置是否不启用4级收货地点
    Begin
      Select Nvl(Uc.Code_Value, 'Y')
        Into v_Consignee_Add_4_Flag
        From Up_Codelist Uc
       Where Uc.Codetype = 'PLN_CONSIGNEE_ADD_4'
         And Uc.Enabled = 0;
    Exception
      When Others Then
        v_Consignee_Add_4_Flag := 'Y';
    End;

    --主体编码检测
    If p_Result = v_Success Then
      Begin
        v_Value := '主体编码检测：';
        Select b.Entity_Name
          Into v_Entity_Name
          From v_Bd_Entity b
         Where b.Entity_Id = r_Pln_Lg_Order_Head.Entity_Id;
      Exception
        When Others Then
          p_Result := v_Value || '主体编码' || r_Pln_Lg_Order_Head.Entity_Id ||
                      '无效。';
          Raise v_Intf_Exception;
      End;
    End If;

    --检查单据类型
    If p_Result = v_Success Then
      Begin
        v_Value := '单据类型检查：';
        Select *
          Into r_Pln_Order_Type
          From t_Pln_Order_Type Ot
         Where Ot.Order_Type_Id = r_Pln_Lg_Order_Head.Order_Type_Id
           And Trunc(r_Pln_Lg_Order_Head.Intf_Date) Between Ot.Begin_Date And
               Trunc(Nvl(Ot.End_Date, Sysdate));
      Exception
        When Others Then
          p_Result := v_Value || '单据类型ID：' ||
                      To_Char(r_Pln_Lg_Order_Head.Order_Type_Id) ||
                      '不存在或者单据类型失效。';
          Raise v_Intf_Exception;
      End;
    End If;
    --营销大类检测
    If p_Result = v_Success And
       r_Pln_Lg_Order_Head.Sales_Main_Type Is Not Null Then
      Begin
        v_Value := '营销大类检测：';
        Select Ic.Class_Code
          Into v_Sales_Main_Type
          From t_Bd_Item_Class Ic
         Where Ic.Class_Code = r_Pln_Lg_Order_Head.Sales_Main_Type
           And Ic.Entity_Id = r_Pln_Lg_Order_Head.Entity_Id
           And Ic.Active_Flag = v_True;
      Exception
        When Others Then
          p_Result := v_Value || '营销大类编码 ' ||
                      r_Pln_Lg_Order_Head.Sales_Main_Type || '不存在或者失效。';
          Raise v_Intf_Exception;
      End;
    End If;
    --营销小类检测
    If p_Result = v_Success And
       r_Pln_Lg_Order_Head.Sales_Sub_Type Is Not Null Then
      Begin
        v_Value := '营销小类检测：';
        Select Ic.Class_Code
          Into v_Sales_Sub_Type
          From t_Bd_Item_Class Ic
         Where Ic.Class_Code = r_Pln_Lg_Order_Head.Sales_Sub_Type
           And Ic.Entity_Id = r_Pln_Lg_Order_Head.Entity_Id
           And Ic.Active_Flag = v_True;
      Exception
        When Others Then
          p_Result := v_Value || '营销小类编码 ' ||
                      r_Pln_Lg_Order_Head.Sales_Sub_Type || '不存在或者失效。';
          Raise v_Intf_Exception;
      End;
    End If;

    --获取T+3系统参数
    Begin
      Select Pkg_Bd.f_Get_Parameter_Value(p_Config_Code => 'PLN_IS_MERGE_LG_ORDER',
                                          p_Entity_Id   => r_Pln_Lg_Order_Head.Entity_Id)
        Into v_Pln_Is_Merge_Lg_Order
        From Dual;
    Exception
      When Others Then
        p_Result := '获取主体参数失败，系统参数编码【PLN_IS_MERGE_LG_ORDER】';
        Raise v_Intf_Exception;
    End;

    --订单行检测
    If p_Result = v_Success Then
      Select Count(1)
        Into v_Count
        From Intf_Pln_Lg_Order_Line l
       Where l.Intf_Head_Id = r_Pln_Lg_Order_Head.Intf_Id
         And l.Entity_Id = r_Pln_Lg_Order_Head.Entity_Id;
      If v_Count = 0 Then
        p_Result := '无订单行资料，校验失败。';
        Raise v_Intf_Exception;
      End If;
    End If;

    --20150506 add by wildwind 推广物料订单产品校验
    /*IF p_Result = v_Success THEN
       --推广物料订单
        v_OrderTypeCode := Pkg_Bd.f_Get_Parameter_Value('PLN_MATERIAL_TYPE_CODE',
                                                           r_Pln_Lg_Order_Head.Entity_Id);
        IF r_Pln_Order_Type.Order_Type_Code=v_OrderTypeCode THEN
          SELECT COUNT(1)
            INTO V_COUNT
            FROM INTF_PLN_LG_ORDER_LINE L
           WHERE L.INTF_HEAD_ID = R_PLN_LG_ORDER_HEAD.INTF_ID
             AND L.ENTITY_ID = R_PLN_LG_ORDER_HEAD.ENTITY_ID
             AND NOT EXISTS (SELECT 1
                    FROM T_BD_ITEM BI
                   WHERE BI.IS_MATERIAL = 'Y'
                     AND BI.ITEM_ID = L.ITEM_ID);
            If v_Count > 0 Then
             p_Result := '推广物料订单不可报送非推广物料产品。';
               raise v_Intf_Exception;
           End If;
        ELSE
           SELECT COUNT(1)
            INTO V_COUNT
            FROM INTF_PLN_LG_ORDER_LINE L
           WHERE L.INTF_HEAD_ID = R_PLN_LG_ORDER_HEAD.INTF_ID
             AND L.ENTITY_ID = R_PLN_LG_ORDER_HEAD.ENTITY_ID
             AND EXISTS (SELECT 1
                    FROM T_BD_ITEM BI
                   WHERE BI.IS_MATERIAL = 'Y'
                     AND BI.ITEM_ID = L.ITEM_ID);
            If v_Count > 0 Then
             p_Result := '普通提货订单不可报送推广物料产品。';
               raise v_Intf_Exception;
           End If;
        END IF;
     END IF;
    */
    --检测营销中心编码
    If p_Result = v_Success Then
      Begin
        v_Value := '营销中心检查：';
        Select u.Code, u.Name
          Into v_Sales_Center_Code, v_Sales_Center_Name
          From Up_Org_Unit u
         Where u.Unit_Id = r_Pln_Lg_Order_Head.Sales_Center_Id
           And u.Active_Flag = 'T';
      Exception
        When Others Then
          p_Result := v_Value || '营销中心ID：' ||
                      To_Char(r_Pln_Lg_Order_Head.Sales_Center_Id) ||
                      '不存在或者中心已失效。';
          Raise v_Intf_Exception;
      End;
    End If;
    --检测客户编码
    If p_Result = v_Success Then
      Begin
        v_Value := '客户检查：';
        Select Customer_Code, Customer_Name
          Into v_Customer_Code, v_Customer_Name
          From t_Customer_Header Ch
         Where Ch.Customer_Id = r_Pln_Lg_Order_Head.Customer_Id
           And Ch.Active_Flag = v_Active;
      Exception
        When Others Then
          p_Result := v_Value || '客户ID：' ||
                      To_Char(r_Pln_Lg_Order_Head.Customer_Id) ||
                      '不存在或已失效。';
          Raise v_Intf_Exception;
      End;
    End If;
    --检测账户编码
    If p_Result = v_Success Then
      Begin
        v_Value := '客户账户检查：';
        Select Ca.Account_Code, Nvl(Ca.Account_Name, ' '), Ca.Account_Id
          Into v_Account_Code, v_Account_Name, v_Account_Id
          From v_Customer_Account_Salecenter Ca
         Where Ca.Sales_Center_Id = r_Pln_Lg_Order_Head.Sales_Center_Id
           And Ca.Customer_Id = r_Pln_Lg_Order_Head.Customer_Id
           And Ca.Entity_Id = r_Pln_Lg_Order_Head.Entity_Id
           And Ca.Active_Flag = v_Active
           And Ca.Account_Status = v_Account_Active;
        If v_Account_Id <> r_Pln_Lg_Order_Head.Account_Id Then
          p_Result := v_Value || ' 主体ID：' ||
                      To_Char(r_Pln_Lg_Order_Head.Entity_Id) || ' 中心ID：' ||
                      To_Char(r_Pln_Lg_Order_Head.Customer_Id) || ' 客户ID：' ||
                      To_Char(r_Pln_Lg_Order_Head.Customer_Id) || ' 账户ID：' ||
                      To_Char(r_Pln_Lg_Order_Head.Account_Id) || '对应关系有误';
          Raise v_Intf_Exception;
        End If;
      Exception
        When Others Then
          p_Result := v_Value || ' 主体ID：' ||
                      To_Char(r_Pln_Lg_Order_Head.Entity_Id) || ' 中心ID：' ||
                      To_Char(r_Pln_Lg_Order_Head.Sales_Center_Id) ||
                      ' 客户ID：' || To_Char(r_Pln_Lg_Order_Head.Customer_Id) ||
                      '不存在对应的账户，或账户未激活。';
          Raise v_Intf_Exception;
      End;
    End If;

    --开票单位检测
    If p_Result = v_Success Then
      Begin
        v_Value := '开票联系人检查：';

        Select Tca.Contacts_Name, Tca.Contacts_Phones
          Into v_Invoice_Contract, v_Invoice_Tel
          From t_Customer_Account_Address Ca, t_Customer_Address Tca
         Where Ca.Account_Id = r_Pln_Lg_Order_Head.Account_Id
           And Tca.Contacts_Id = r_Pln_Lg_Order_Head.Invoice_Contact_Id
           And Tca.Address_Id = Ca.Address_Id
           And Tca.Address_Type = 'BillTo'
           And Tca.Entity_Id = r_Pln_Lg_Order_Head.Entity_Id
           And Ca.Entity_Id = r_Pln_Lg_Order_Head.Entity_Id
           And Tca.Active_Flag = v_Active;
      Exception
        When Others Then
          /* p_Result := v_Value || '账号：' ||
                      To_Char(r_Pln_Lg_Order_Head.Account_Id) ||
                      ' 开票联系人ID：'||
                       To_Char(r_Pln_Lg_Order_Head.Invoice_Contact_Id) ||
                      '不存在。';
          raise v_Intf_Exception;*/
          Null;
      End;
    End If;

    --收货单位检测
    If p_Result = v_Success Then
      If /*Nvl(r_Pln_Lg_Order_Head.Direct_Send_Flag, 'N') = 'Y'
        And*/ Nvl(r_Pln_Lg_Order_Head.Sys_Source, '_') = 'IMS' Then
        Select r_Pln_Lg_Order_Head.Consignee_Id,
               r_Pln_Lg_Order_Head.Consignee_Addr_Code,
               r_Pln_Lg_Order_Head.Consignee_Addr_Name,
               r_Pln_Lg_Order_Head.Consignee_Contact_Id,
               r_Pln_Lg_Order_Head.Consignee_Contract,
               r_Pln_Lg_Order_Head.Consignee_Tel
          Into v_Consignee_Id,
               v_Consignee_Addr_Code,
               v_Consignee_Addr,
               v_Consignee_Contact_Id,
               v_Consignee_Contract,
               v_Consignee_Tel
          From Dual;
      Else
        Begin
          Select Tca.Address_Id,
                  Decode(v_Consignee_Add_4_Flag, 'N', Tca.Area, Tca.Towns), --add by lizhen 2016-01-12 客户收货地点取4级地点信息Tca.Area,
                 Tca.Address,
                 Tca.Contacts_Id,
                 Tca.Contacts_Name,
                 Tca.Contacts_Phones
            Into v_Consignee_Id,
                 v_Consignee_Addr_Code,
                 v_Consignee_Addr,
                 v_Consignee_Contact_Id,
                 v_Consignee_Contract,
                 v_Consignee_Tel
            From t_Customer_Account_Address Ca, t_Customer_Address Tca
           Where Ca.Account_Id = r_Pln_Lg_Order_Head.Account_Id
             And Tca.Address_Id = r_Pln_Lg_Order_Head.Consignee_Id
             And Tca.Address_Id = Ca.Address_Id
             And Tca.Address_Type = 'ShipTo'
             And Tca.Active_Flag = v_Active;
        Exception
          When Others Then
            p_Result := v_Value || '账号：' ||
                        To_Char(r_Pln_Lg_Order_Head.Account_Id) || ' 收货地址ID：' ||
                        To_Char(r_Pln_Lg_Order_Head.Consignee_Id) ||
                        '不存在或已失效。';
            Raise v_Intf_Exception;
        End;
      End If;
      --收货地点检测
      Begin
        --add by lizhen 2016-01-12 客户收货地点取4级地点信息
        v_Value := '获取客户收货地点取4级地点信息。';
        Select Bd.Row_Id
          Into v_Consignment_Addr_Id
          From t_Bd_District Bd
         Where Bd.District_Code = v_Consignee_Addr_Code
           And Bd.Level_Seq = Decode(v_Consignee_Add_4_Flag, 'N', Bd.Level_Seq, 5); --add by lizhen 2016-01-12 客户收货地点取4级地点信息
      Exception
        When Others Then
          p_Result := v_Value || v_Nl || '收货地址ID：' || r_Pln_Lg_Order_Head.Consignee_Id || v_Nl ||
                       ' 收货地址编码：' || To_Char(v_Consignee_Addr_Code) || v_Nl || 
                       '客户编码：' || r_Pln_Lg_Order_Head.Customer_Code || v_Nl ||
                       '账户编码：' || r_Pln_Lg_Order_Head.Account_Code || v_Nl ||
                       '无对应的收货地点信息。';
          Raise v_Intf_Exception;
      End;
    End If;

    ----------------------------------------------------------------------
    --  接口头表数据插入正式表
    ----------------------------------------------------------------------

    If p_Result = v_Success Then
      --修改订单头 适用退回后重新提交的情况
      If r_Pln_Lg_Order_Head.Order_Head_Id Is Not Null Then

        --检测订单接口
        Begin
          v_Value := '锁定提货订单驳回状态业务表失败,订单已被锁定或状态异常！';
          Select *
            Into r_Pln_Lg_Order_Headlock
            From t_Pln_Lg_Order_Head h
           Where h.Order_Head_Id = r_Pln_Lg_Order_Head.Order_Head_Id
             And h.Order_Head_State = v_Head_State_Back
             For Update Nowait;

          v_Lg_Order_Head_Id := r_Pln_Lg_Order_Head.Order_Head_Id;
        Exception
          When Others Then
            p_Result := v_Value || v_Nl || Sqlerrm;
            Raise v_Intf_Exception;
        End;

        Begin
          v_Value := '驳回后重新报送更新提货订单头表信息：';

          Update t_Pln_Lg_Order_Head
             Set Entity_Id             = r_Pln_Lg_Order_Head.Entity_Id, --主体编码
                 Order_Type_Id         = r_Pln_Order_Type.Order_Type_Id,
                 Order_Type_Code       = r_Pln_Order_Type.Order_Type_Code, --单据类型
                 Order_Type_Name       = r_Pln_Order_Type.Order_Type_Name,
                 Sales_Year_Id         = Null, --销售年度
                 Period_Id             = Null, --周期ID
                 Period_Code           = Null, --周期编码
                 Order_Head_State      = v_Head_State_Init, --单据状态，默认制单状态
                 Form_State            = Null, --表单状态，计划订单使用
                 Sales_Center_Id       = r_Pln_Lg_Order_Head.Sales_Center_Id,
                 Sales_Center_Code     = v_Sales_Center_Code, --营销中心
                 Sales_Center_Name     = v_Sales_Center_Name,
                 Customer_Id           = r_Pln_Lg_Order_Head.Customer_Id,
                 Customer_Code         = v_Customer_Code, --客户信息
                 Customer_Name         = v_Customer_Name,
                 Account_Id            = r_Pln_Lg_Order_Head.Account_Id,
                 Account_Code          = v_Account_Code, --账户信息
                 Account_Name          = v_Account_Name,
                 Sales_Main_Type       = r_Pln_Lg_Order_Head.Sales_Main_Type, --营销大小类
                 Sales_Sub_Type        = r_Pln_Lg_Order_Head.Sales_Sub_Type,
                 Order_Effective_Date  = r_Pln_Lg_Order_Head.Order_Effective_Date,
                 Source_Order_Id       = r_Pln_Lg_Order_Head.Source_Order_Id, --SOURCE_ORDER_ID 来源订单ID
                 Source_Order_Number   = r_Pln_Lg_Order_Head.Source_Order_Number, --SOURCE_ORDER_NUMBER 来源订单号
                 Customer_Order_Number = r_Pln_Lg_Order_Head.Customer_Order_Number, --客户订单号（电商订单）
                 Customer_Order_Date   = r_Pln_Lg_Order_Head.Customer_Order_Date, --客户订单日期
                 Exigence              = r_Pln_Lg_Order_Head.Exigence, --紧急程度
                 Trun_Flag             = 'N', --是否结转
                 Lock_Inv_Flag         = r_Pln_Order_Type.Is_Lock_Inv_Flag, --是否锁定库存
                 Lock_Amount_Flag      = 'N', --是否锁定余款
                 To_Plan_Flag          = 'N', --是否生产运力计划
                 Ship_Mode             = r_Pln_Lg_Order_Head.Ship_Mode, --发运方式
                 Project_Order_Flag    = r_Pln_Lg_Order_Head.Project_Order_Flag, --工程项目标示
                 Project_Number        = r_Pln_Lg_Order_Head.Project_Number, --工程项目编号
                 Direct_Send_Flag      = r_Pln_Lg_Order_Head.Direct_Send_Flag, --直发标志
                 Is_Need_Bill          = r_Pln_Lg_Order_Head.Is_Need_Bill, --是否需要随货同行联（厨电）
                 Client_Carry_Flag     = r_Pln_Lg_Order_Head.Client_Carry_Flag, --是否客户自提
                 Ship_Flag             = 'N', --SHIP_FLAG  是否确认发货（返写，该订单是否发货）
                 Cancel_Flag           = 'N', --CANCEL_FLAG 是否取消（评审时，关闭订单，小电结案标识）
                 Link_Pipe_Flag        = 'N', --LINK_PIPE_FLAG 是否含连接管
                 Finance_Flag          = 'N', --FINANCE_FLAG 是否开单完毕（回写）
                 Order_Date            = r_Pln_Lg_Order_Head.Order_Date, --订单日期
                 Invoice_Customer_Id   = r_Pln_Lg_Order_Head.Customer_Id, --INVOICE_CUSTOMER_ID 开票客户ID
                 Invoice_Customer_Code = v_Customer_Code, --INVOICE_CUSTOMER_CODE 开票客户编码
                 Invoice_Customer_Name = v_Customer_Name, --INVOICE_CUSTOMER_NAME 开票客户名称
                 Invoice_Contact_Id    = r_Pln_Lg_Order_Head.Invoice_Contact_Id, --INVOICE_CONTACT_ID 开票单位联系人ID
                 Invoice_Contract      = v_Invoice_Contract, --INVOICE_CONTRACT 开票单位联系人
                 Invoice_Tel           = v_Invoice_Tel, --INVOICE_TEL 开票单位电话
                 Consignee_Id          = r_Pln_Lg_Order_Head.Consignee_Id,--v_Consignee_Id, --CONSIGNEE_ID 收货单位ID
                 Consignee_Code        = r_Pln_Lg_Order_Head.Consignee_Code,--v_Customer_Code, --CONSIGNEE_CODE 收货单位编码
                 Consignee_Name        = r_Pln_Lg_Order_Head.Consignee_Name,--v_Customer_Name, --CONSIGNEE_NAME 收货单位名称
                 Consignee_Addr_Name   = v_Consignee_Addr, --CONSIGNEE_ADDR_NAME 收货单位地址
                 Consignee_Extend_Addr = r_Pln_Lg_Order_Head.Consignee_Extend_Addr, --CONSIGNEE_EXTEND_ADDR 收货扩展地址（主要应用与工程机）
                 Consignment_Add_Id    = v_Consignment_Addr_Id, --CONSIGNMENT_ADD_ID 收货地点ID
                 Consignee_Addr_Code   = v_Consignee_Addr_Code, --CONSIGNEE_ADDR_CODE 收货单位地址编码（物流根据该编码选择承运商）
                 Consignee_Contact_Id  = v_Consignee_Contact_Id, --CONSIGNEE_CONTACT_ID 收货单位联系人ID
                 Consignee_Contract    = v_Consignee_Contract, --CONSIGNEE_CONTRACT 收货单位联系人
                 Consignee_Tel         = v_Consignee_Tel, --CONSIGNEE_TEL 收货单位联系电话
                 Transfer_Customer_Id  = r_Pln_Lg_Order_Head.Transfer_Customer_Id, --分部客户ID（冰洗客户订单所属ID）
                 Sys_Source            = r_Pln_Lg_Order_Head.Sys_Source, --系统来源
                 Created_By            = 'PKG_PLN_INTF_IMS',
                 Creation_Date         = Sysdate,
                 Last_Updated_By       = 'PKG_PLN_INTF_IMS',
                 Last_Update_Date      = Sysdate,
                 Remark                = r_Pln_Lg_Order_Head.Remark,
                 Pre_Field_01          = r_Pln_Lg_Order_Head.Pre_Field_01,
                 Pre_Field_02          = r_Pln_Lg_Order_Head.Pre_Field_02,
                 Pre_Field_03          = r_Pln_Lg_Order_Head.Pre_Field_03,
                 Pre_Field_04          = r_Pln_Lg_Order_Head.Pre_Field_04,
                 Pre_Field_05          = r_Pln_Lg_Order_Head.Pre_Field_05,
                 Pre_Field_06          = r_Pln_Lg_Order_Head.Pre_Field_06,
                 Preferential_Flag     = r_Pln_Lg_Order_Head.Preferential_Flag, --优惠品标示
                 Program_Updated_By    = 'PKG_PLN_INTF_IMS',
                 Program_Update_Date   = Sysdate,
                 AGENT_CUSTOMER_ID     = r_Pln_Lg_Order_Head.Agent_Customer_Id,
                 AGENT_CUSTOMER_CODE   = r_Pln_Lg_Order_Head.Agent_Customer_Code,
                 AGENT_CUSTOMER_NAME   = r_Pln_Lg_Order_Head.Agent_Customer_Name,
                 SYS_ORIGIN            = r_Pln_Lg_Order_Head.Sys_Origin,
                 ORIGIN_ORDER_ID       = r_Pln_Lg_Order_Head.Origin_Order_Id,
                 ORIGIN_ORDER_NUMBER   = r_Pln_Lg_Order_Head.Origin_Order_Number
           Where Order_Head_Id = r_Pln_Lg_Order_Head.Order_Head_Id;
        Exception
          When Others Then
            p_Result := v_Value || '单号ID ' ||
                        r_Pln_Lg_Order_Head.Order_Head_Id || '，失败。' || v_Nl ||
                        Sqlerrm;
            Raise v_Intf_Exception;
        End;
      Else

        --生成订单号
        Begin
          Pkg_Pln_Pub.p_Create_Order_Number(p_Order_Number_Type => 'plnLgOrder', --单据编码规则
                                            p_Period_Id         => 0,
                                            p_Sales_Center_Id   => r_Pln_Lg_Order_Head.Sales_Center_Id,
                                            p_Entity_Id         => r_Pln_Lg_Order_Head.Entity_Id,
                                            p_Order_Number      => v_Order_Number);

          If Nvl(v_Order_Number, '_') = '_' Then
            p_Result := '获取客户订单单号失败，单号编码规则：plnLgOrder。';
            Raise v_Intf_Exception;
          End If;
        Exception
          When Others Then
            p_Result := '获取客户订单单号失败，单号编码规则：plnLgOrder。';
            Raise v_Intf_Exception;
        End;
        --新增订单头
        Begin
          Select s_Pln_Lg_Order_Head.Nextval
            Into v_Lg_Order_Head_Id
            From Dual;

          v_Value := '开始插入提货订单头表信息：';

          Insert Into t_Pln_Lg_Order_Head
            (Entity_Id, -- 主体ID
             Order_Head_Id, -- 订单头ID
             Order_Number, -- 订单编码
             Order_Type_Id,
             Order_Type_Code, --订单类型
             Order_Type_Name,
             Sales_Year_Id, --销售年度
             Period_Id, --周期
             Period_Code,
             Order_Head_State, --订单状态，提货订单使用
             Form_State, --订单状态，计划订单使用
             Sales_Center_Id, --营销中心
             Sales_Center_Code,
             Sales_Center_Name,
             Customer_Id, --客户信息
             Customer_Code,
             Customer_Name,
             Account_Id, --账户信息
             Account_Code,
             Account_Name,
             Sales_Main_Type, --营销大类*
             Sales_Sub_Type, --营销小类
             Order_Effective_Date, --订单有效期
             Source_Order_Id, --来源订单ID
             Source_Order_Number, --来源订单号
             Customer_Order_Number, --客户订单号（电商订单）
             Customer_Order_Date, --客户订单号
             Exigence, --紧急程度
             Trun_Flag, --是否结转
             Lock_Inv_Flag, --是否锁定库存
             Lock_Amount_Flag, --是否锁定余款
             To_Plan_Flag, --是否生产运力计划
             Ship_Mode, --发运方式*
             Project_Order_Flag, --工程项目标示
             Project_Number, --工程项目编号
             Direct_Send_Flag, --直发标志*
             Is_Need_Bill, --是否需要随货同行联（厨电）
             Client_Carry_Flag, --是否客户自提
             Ship_Flag, --是否确认发货（返写，该订单是否发货）
             Cancel_Flag, --是否取消（评审时，关闭订单，小电结案标识）
             Link_Pipe_Flag, --是否含连接管
             Finance_Flag, --是否开单完毕（回写）
             Order_Date, --订单日期
             Invoice_Customer_Id, --开票客户ID
             Invoice_Customer_Code, --开票客户编码
             Invoice_Customer_Name, --开票客户名称
             Invoice_Contact_Id, --开票单位联系人ID
             Invoice_Contract, --开票单位联系人
             Invoice_Tel, --开票单位电话
             Consignee_Id, --收货单位ID
             Consignee_Code, --收货单位编码
             Consignee_Name, --收货单位名称
             Consignee_Addr_Name, --收货单位地址
             Consignee_Extend_Addr, --收货扩展地址（主要应用与工程机）
             Consignment_Add_Id, --收货地点ID
             Consignee_Addr_Code, --收货单位地址编码（物流根据该编码选择承运商）
             Consignee_Contact_Id, --收货单位联系人ID
             Consignee_Contract, --收货单位联系人
             Consignee_Tel, --收货单位联系电话
             Transfer_Customer_Id, --分部客户ID（冰洗客户订单所属ID）
             Sys_Source, --系统来源
             Created_By,
             Creation_Date,
             Last_Updated_By,
             Last_Update_Date,
             Remark,
             Pre_Field_01,
             Pre_Field_02,
             Pre_Field_03,
             Pre_Field_04,
             Pre_Field_05,
             Pre_Field_06,
             Preferential_Flag, --优惠品标示
             Program_Updated_By,
             Program_Update_Date,
             Ship_Type,  --发货类型
             Consignment_Date,       --订单效货日期
             Lg_Transfer_Flag,  --是否结转计划订单
             Customer_Channel_Type  --客户渠道类型
             ,AGENT_CUSTOMER_ID
             ,AGENT_CUSTOMER_CODE
             ,AGENT_CUSTOMER_NAME
             ,SYS_ORIGIN
             ,ORIGIN_ORDER_ID
             ,ORIGIN_ORDER_NUMBER
             )
          Values
            (r_Pln_Lg_Order_Head.Entity_Id, --主体编码
             v_Lg_Order_Head_Id, --订单头ID
             v_Order_Number, --订单编号
             r_Pln_Order_Type.Order_Type_Id,
             r_Pln_Order_Type.Order_Type_Code, --单据类型
             r_Pln_Order_Type.Order_Type_Name,
             Null, --销售年度
             Null, --周期ID
             Null, --周期编码
             v_Head_State_Init, --单据状态，默认制单状态
             Null, --表单状态，计划订单使用
             r_Pln_Lg_Order_Head.Sales_Center_Id,
             v_Sales_Center_Code, --营销中心
             v_Sales_Center_Name,
             r_Pln_Lg_Order_Head.Customer_Id,
             v_Customer_Code, --客户信息
             v_Customer_Name,
             r_Pln_Lg_Order_Head.Account_Id,
             v_Account_Code, --账户信息
             v_Account_Name,
             r_Pln_Lg_Order_Head.Sales_Main_Type, --营销大小类
             r_Pln_Lg_Order_Head.Sales_Sub_Type,
             r_Pln_Lg_Order_Head.Order_Effective_Date,
             r_Pln_Lg_Order_Head.Source_Order_Id, --SOURCE_ORDER_ID 来源订单ID
             r_Pln_Lg_Order_Head.Source_Order_Number, --SOURCE_ORDER_NUMBER 来源订单号
             r_Pln_Lg_Order_Head.Customer_Order_Number, --客户订单号（电商订单）
             r_Pln_Lg_Order_Head.Customer_Order_Date, --客户订单日期
             r_Pln_Lg_Order_Head.Exigence, --紧急程度
             'N', --是否结转
             r_Pln_Order_Type.Is_Lock_Inv_Flag, --是否锁定库存
             'N', --是否锁定余款
             'N', --是否生产运力计划
             r_Pln_Lg_Order_Head.Ship_Mode, --发运方式
             r_Pln_Lg_Order_Head.Project_Order_Flag, --工程项目标示
             r_Pln_Lg_Order_Head.Project_Number, --工程项目编号
             r_Pln_Lg_Order_Head.Direct_Send_Flag, --直发标志
             r_Pln_Lg_Order_Head.Is_Need_Bill, --是否需要随货同行联（厨电）
             r_Pln_Lg_Order_Head.Client_Carry_Flag, --是否客户自提
             'N', --SHIP_FLAG  是否确认发货（返写，该订单是否发货）
             'N', --CANCEL_FLAG 是否取消（评审时，关闭订单，小电结案标识）
             'N', --LINK_PIPE_FLAG 是否含连接管
             'N', --FINANCE_FLAG 是否开单完毕（回写）
             r_Pln_Lg_Order_Head.Order_Date, --订单日期
             r_Pln_Lg_Order_Head.Customer_Id, --INVOICE_CUSTOMER_ID 开票客户ID
             v_Customer_Code, --INVOICE_CUSTOMER_CODE 开票客户编码
             v_Customer_Name, --INVOICE_CUSTOMER_NAME 开票客户名称
             r_Pln_Lg_Order_Head.Invoice_Contact_Id, --INVOICE_CONTACT_ID 开票单位联系人ID
             v_Invoice_Contract, --INVOICE_CONTRACT 开票单位联系人
             v_Invoice_Tel, --INVOICE_TEL 开票单位电话
             r_Pln_Lg_Order_Head.Consignee_Id,--v_Consignee_Id, --CONSIGNEE_ID 收货单位ID
             r_Pln_Lg_Order_Head.Consignee_Code,--v_Customer_Code, --CONSIGNEE_CODE 收货单位编码
             r_Pln_Lg_Order_Head.Consignee_Name,--v_Customer_Name, --CONSIGNEE_NAME 收货单位名称
             v_Consignee_Addr, --CONSIGNEE_ADDR_NAME 收货单位地址
             r_Pln_Lg_Order_Head.Consignee_Extend_Addr, --CONSIGNEE_EXTEND_ADDR 收货扩展地址（主要应用与工程机）
             v_Consignment_Addr_Id, --CONSIGNMENT_ADD_ID 收货地点ID
             v_Consignee_Addr_Code, --CONSIGNEE_ADDR_CODE 收货单位地址编码（物流根据该编码选择承运商）
             v_Consignee_Contact_Id, --CONSIGNEE_CONTACT_ID 收货单位联系人ID
             v_Consignee_Contract, --CONSIGNEE_CONTRACT 收货单位联系人
             v_Consignee_Tel, --CONSIGNEE_TEL 收货单位联系电话
             r_Pln_Lg_Order_Head.Transfer_Customer_Id, --分部客户ID（冰洗客户订单所属ID）
             r_Pln_Lg_Order_Head.Sys_Source, --系统来源
             'CIMS',
             Sysdate,
             'CIMS',
             Sysdate,
             r_Pln_Lg_Order_Head.Remark,
             r_Pln_Lg_Order_Head.Pre_Field_01,
             r_Pln_Lg_Order_Head.Pre_Field_02,
             r_Pln_Lg_Order_Head.Pre_Field_03,
             r_Pln_Lg_Order_Head.Pre_Field_04,
             r_Pln_Lg_Order_Head.Pre_Field_05,
             r_Pln_Lg_Order_Head.Pre_Field_06,
             r_Pln_Lg_Order_Head.Preferential_Flag, --优惠品标示
             'PKG_PLN_INTF_IMS',
             Sysdate,
             '01', --发运类型（01工厂发货 02省内发货 03直发超市 04异地调拨）
             r_Pln_Lg_Order_Head.Consignment_Date,  --Consignment_Date --订单效货日期
             'N', --LG_TRANSFER_FLAG    --是否结转计划订单
             r_Pln_Lg_Order_Head.Customer_Channel_Type  --客户渠道类型
             ,r_Pln_Lg_Order_Head.Agent_Customer_Id
             ,r_Pln_Lg_Order_Head.Agent_Customer_Code
             ,r_Pln_Lg_Order_Head.Agent_Customer_Name
             ,r_Pln_Lg_Order_Head.Sys_Origin
             ,r_Pln_Lg_Order_Head.Origin_Order_Id
             ,r_Pln_Lg_Order_Head.Origin_Order_Number
             );

          --更新接口表数据
          Update Intf_Pln_Lg_Order_Head h
             Set h.Order_Head_Id = v_Lg_Order_Head_Id, --订单头ID
                 h.Order_Number  = v_Order_Number
           Where h.Intf_Id = p_Intf_Id;
        Exception
          When Others Then
            p_Result := v_Value || '，失败。' || v_Nl || Sqlerrm;
            Raise v_Intf_Exception;
        End;
      End If;
    End If;

    ----------------------------------------------------------------------
    --  接口数据行表数据检测
    ----------------------------------------------------------------------

    --驳回后重新报送删除提货订单行信息
    If r_Pln_Lg_Order_Head.Order_Head_Id Is Not Null And
       r_Pln_Lg_Order_Headlock.Order_Head_State = v_Head_State_Back Then

      --检测订单接口
      Begin
        v_Value := '驳回后重新报送删除提货订单行信息';
        Delete From t_Pln_Lg_Order_Line Lol
         Where Lol.Order_Head_Id = r_Pln_Lg_Order_Head.Order_Head_Id;
      Exception
        When Others Then
          p_Result := v_Value || v_Nl || Sqlerrm;
          Raise v_Intf_Exception;
      End;
    End If;
    --检测并将接口表行数据插入业务表
    If p_Result = v_Success Then
      Open c_Pln_Lg_Order_Line;
      Loop
        Fetch c_Pln_Lg_Order_Line
          Into r_Pln_Lg_Order_Line;
        Exit When c_Pln_Lg_Order_Line%Notfound Or p_Result <> v_Success;

        Select s_Pln_Lg_Order_Line.Nextval
          Into v_Lg_Order_Line_Id
          From Dual;

        If r_Pln_Order_Type.Is_Material_Range_Flag = v_True Then
          Begin
            v_Value := '产品型谱编码检查：';
            Select Bi.Item_Id,
                   Bi.Defaultunit,
                   Bi.Item_Name,
                   Nvl(Bi.Sales_Main_Type, '-'),
                   Nvl(Bi.Sales_Sub_Type, '-'),
                   Bi.Is_Rounding,
                   Bi.Rounding_Cnt,
                   Nvl(Bi.Is_Material, 'N'),
                   Bi.Defaultunit
              Into v_Item_Id,
                   v_Item_Uom,
                   v_Item_Desc,
                   v_Sales_Main_Type,
                   v_Sales_Sub_Type,
                   v_Is_Rounding,
                   v_Rounding_Cnt,
                   v_Is_Material,
                   v_Default_Unit
              From t_Bd_Item Bi, t_Pln_Item_Dyn_Attribute Da
             Where Bi.Item_Id = Da.Item_Id
               And Bi.Entity_Id = Da.Entity_Id
               And Trunc(Sysdate) Between Da.Begin_Date And
                   Trunc(Nvl(Da.End_Date, Sysdate))
               And Bi.Item_Code = r_Pln_Lg_Order_Line.Item_Code
               And Bi.Entity_Id = r_Pln_Lg_Order_Line.Entity_Id
               And Bi.Active_Flag = v_True;
          Exception
            When Others Then
              p_Result := v_Value || '，产品编码：' ||
                          r_Pln_Lg_Order_Line.Item_Code || '不在型谱范围或产品已失效';
              Raise v_Intf_Exception;
          End;

        Elsif r_Pln_Order_Type.Is_Sample_Need = v_True Then
          Begin
            v_Value := '样机产品检查：';
            Select Bi.Item_Id,
                   Bi.Defaultunit,
                   Bi.Item_Name,
                   Nvl(Bi.Sales_Main_Type, '-'),
                   Nvl(Bi.Sales_Sub_Type, '-'),
                   Bi.Is_Rounding,
                   Bi.Rounding_Cnt,
                   Nvl(Bi.Is_Material, 'N'),
                   Bi.Defaultunit
              Into v_Item_Id,
                   v_Item_Uom,
                   v_Item_Desc,
                   v_Sales_Main_Type,
                   v_Sales_Sub_Type,
                   v_Is_Rounding,
                   v_Rounding_Cnt,
                   v_Is_Material,
                   v_Default_Unit
              From t_Bd_Item Bi
             Where Bi.Item_Code = r_Pln_Lg_Order_Line.Item_Code
               And Bi.Entity_Id = r_Pln_Lg_Order_Line.Entity_Id
               And Bi.Active_Flag = v_True
               And Bi.Productform = 'SAMPLE_PRODUCT';
          Exception
            When Others Then
              p_Result := v_Value || '，样机产品编码：' ||
                          r_Pln_Lg_Order_Line.Item_Code || '不存在或者已失效';
              Raise v_Intf_Exception;
          End;

        Else

          Begin
            v_Value := '产品编码检查：';
            Select Bi.Item_Id,
                   Bi.Defaultunit,
                   Bi.Item_Name,
                   Nvl(Bi.Sales_Main_Type, '-'),
                   Nvl(Bi.Sales_Sub_Type, '-'),
                   Bi.Is_Rounding,
                   Bi.Rounding_Cnt,
                   Nvl(Bi.Is_Material, 'N'),
                   Bi.Defaultunit
              Into v_Item_Id,
                   v_Item_Uom,
                   v_Item_Desc,
                   v_Sales_Main_Type,
                   v_Sales_Sub_Type,
                   v_Is_Rounding,
                   v_Rounding_Cnt,
                   v_Is_Material,
                   v_Default_Unit
              From t_Bd_Item Bi
             Where Bi.Item_Code = r_Pln_Lg_Order_Line.Item_Code
               And Bi.Entity_Id = r_Pln_Lg_Order_Line.Entity_Id
               And Bi.Active_Flag = v_True;
          Exception
            When Others Then
              p_Result := v_Value || '，产品编码：' ||
                          r_Pln_Lg_Order_Line.Item_Code || '不存在或者产品已失效';
              Raise v_Intf_Exception;
          End;

        End If;

        --推广物料检查
        v_Value := '推广物料检查';
        If r_Pln_Order_Type.Is_Business_Control = v_Pro_Order And
           v_Is_Material <> 'Y' Then
          p_Result := v_Value || '，产品：' || r_Pln_Lg_Order_Line.Item_Code ||
                      '不是推广物料，不允许通过单据类型：' ||
                      r_Pln_Order_Type.Order_Type_Name || '报送';
          Raise v_Intf_Exception;
        Elsif r_Pln_Order_Type.Is_Business_Control <> v_Pro_Order And
              v_Is_Material = 'Y' Then
          p_Result := v_Value || '，产品：' || r_Pln_Lg_Order_Line.Item_Code ||
                      '是推广物料，不允许通过单据类型：' ||
                      r_Pln_Order_Type.Order_Type_Name || '报送';
          Raise v_Intf_Exception;
        End If;

        --获取产品价格
        If p_Result = v_Success Then

          v_Apply_Type     := Null;
          v_Apply_Code     := Null;
          v_Item_Price     := Null;
          v_Apply_Price    := Null;
          v_Apply_Discount := Null;

          If r_Pln_Lg_Order_Line.Project_Order_Line_Id Is Not Null Then
            --引用批文
            Begin
              v_Value := '取批文价格：';
              Select p.Apply_Price,
                     (p.Apply_Cnt - Nvl(p.Used_Cnt, 0) - Nvl(p.Lock_Cnt, 0)) a_Cnt,
                     Nvl(p.Discount, 0) As Discount,
                     a.Apply_Type,
                     a.Apply_Code
                Into v_Apply_Price,
                     v_Apply_Cnt,
                     v_Apply_Discount,
                     v_Apply_Type,
                     v_Apply_Code
                From t_Bd_Price_Apply_Detail p, t_Bd_Price_Apply a
               Where p.Price_Apply_Id = a.Price_Apply_Id
                 And p.Apply_Detail_Id =
                     r_Pln_Lg_Order_Line.Project_Order_Line_Id
                 And p.Item_Code = r_Pln_Lg_Order_Line.Item_Code;
            Exception
              When Others Then
                v_Apply_Price    := Null;
                v_Apply_Discount := 0;
                v_Apply_Cnt      := 0;

            End;

          Elsif r_Pln_Lg_Order_Head.Preferential_Flag = v_True Then
            Begin
              v_Value := '获取产品单价：';
              Pkg_Bd_Price.p_Get_Price_Yh(p_Acc_Id         => r_Pln_Lg_Order_Head.Account_Id,
                                          p_Item_Code      => r_Pln_Lg_Order_Line.Item_Code,
                                          p_Bill_Date      => To_Char(Sysdate,
                                                                      'yyyymmdd'),
                                          p_Price_List_Id  => Null,
                                          p_Entity_Id      => r_Pln_Lg_Order_Head.Entity_Id,
                                          p_Price          => v_Item_Price,
                                          p_Discount       => v_Discount,
                                          p_Month_Discount => v_Month_Discount,
                                          p_Cx_Flag        => v_Cx_Flag);
            Exception
              When Others Then
                v_Item_Price     := Null;
                v_Discount       := 0;
                v_Month_Discount := 0;
                v_Cx_Flag        := 'N';
            End;
          Else
            Begin
              v_Value := '获取产品单价：';
              Pkg_Bd_Price.p_Get_Price(p_Acc_Id         => r_Pln_Lg_Order_Head.Account_Id,
                                       p_Item_Code      => r_Pln_Lg_Order_Line.Item_Code,
                                       p_Bill_Date      => To_Char(Sysdate,
                                                                   'yyyymmdd'),
                                       p_Price_List_Id  => Null,
                                       p_Entity_Id      => r_Pln_Lg_Order_Head.Entity_Id,
                                       p_Price          => v_Item_Price,
                                       p_Discount       => v_Discount,
                                       p_Month_Discount => v_Month_Discount,
                                       p_Cx_Flag        => v_Cx_Flag);
            Exception
              When Others Then
                v_Item_Price     := Null;
                v_Discount       := 0;
                v_Month_Discount := 0;
                v_Cx_Flag        := 'N';
            End;
          End If;
        End If;

        If Nvl(r_Pln_Lg_Order_Line.Quantity, 0) = 0 Then
          p_Result := '订单行有误，产品编码：' || r_Pln_Lg_Order_Line.Item_Code ||
                      '，产品申请数量为0。';
          Raise v_Intf_Exception;
        End If;

        If r_Pln_Lg_Order_Line.Project_Order_Line_Id Is Not Null Then
          --使用批文
          If v_Apply_Price Is Null Then
            p_Result := '获取批文价格失败：批文行ID：' ||
                        r_Pln_Lg_Order_Line.Project_Order_Line_Id ||
                        ' 申请产品编码：' || r_Pln_Lg_Order_Line.Item_Code ||
                        '，批文价格为空或引用批文行无效。';
            Raise v_Intf_Exception;
          End If;
          If r_Pln_Lg_Order_Line.Quantity > v_Apply_Cnt Then
            p_Result := '获取引入失败：批文行ID：' ||
                        r_Pln_Lg_Order_Line.Project_Order_Line_Id ||
                        ' 申请产品数量：' || r_Pln_Lg_Order_Line.Quantity ||
                        ' 超过批文可使用数量 ' || v_Apply_Cnt || '。';
            Raise v_Intf_Exception;
          End If;
          v_Apply_Amount := Round((Nvl(r_Pln_Lg_Order_Line.Quantity, 0) *
                                  v_Apply_Price *
                                  (100 - Nvl(v_Apply_Discount, 0))) / 100,
                                  2);

        Else
          --不使用批文
          If v_Item_Price Is Null And
             r_Pln_Order_Type.Is_Price_Check = v_True Then
            p_Result := '获取产品价格失败：产品编码：' || r_Pln_Lg_Order_Line.Item_Code ||
                        '，单价为空。';
            Raise v_Intf_Exception;
          End If;

          v_Apply_Amount := Round((Nvl(r_Pln_Lg_Order_Line.Quantity, 0) *
                                  Nvl(v_Item_Price, 0) *
                                  (100 - Nvl(v_Discount, 0))) / 100,
                                  2);
        End If;

        --add by lizhen 2015-08-24 T+3提货模式接口无产地时，系统自动获取
        If v_Pln_Is_Merge_Lg_Order In ('TN_SUM', 'TN_SINGLE') Then
          Begin
            v_Producing_Area_Id := Pkg_Pln_Pub.f_Get_Item_Prod_Area_Priority(p_Entity_Id       => r_Pln_Lg_Order_Head.Entity_Id,
                                                                             p_Sales_Center_Id => r_Pln_Lg_Order_Head.Sales_Center_Id,
                                                                             p_Item_Id         => v_Item_Id,
                                                                             P_Item_life_cycle => 'N');
            Select Pa.Producing_Area_Code, Pa.Producing_Area_Name
              Into v_Producing_Area_Code, v_Producing_Area_Name
              From t_Pln_Producing_Area Pa
             Where Pa.Producing_Area_Id = v_Producing_Area_Id;
          Exception
            When Others Then
              p_Result := '获取默认产地信息失败！';
              Raise v_Intf_Exception;
          End;
        End If;

        --接口表行数据插入业务表行
        If p_Result = v_Success Then

          Begin
            v_Value := '开始插入订单行表数据';

            Insert Into t_Pln_Lg_Order_Line
              (Entity_Id, --业务主体
               Order_Line_Id, -- 订单行id
               Order_Head_Id, -- 订单头id
               Order_Line_State, -- 订单行状态
               Item_Id, -- 产品id
               Item_Code, -- 产品编码
               Item_Name, -- 产品名称
               Unit_Volume, -- 单位体积
               Unit_Weight, -- 单位重量
               List_Price, -- 单价
               Sales_Sub_Type, -- 营销小类
               Sales_Main_Type, -- 营销大类
               Quantity, -- 申请数量
               Affirm_Quantity, -- 评审数量
               Finance_Quantity, -- 开单数量（出仓单数量，销售回写）
               Cancel_Qty, -- 取消数量（物流回写）
               Received_Qty, -- 签收数量（厨电，物流回写，建议删除）
               Way_Qty, -- 在途数量（厨电，建议删除）
               Virtual_Qty, -- 提货计划数（厨电，现有量）
               Apply_Amount, -- 申请金额=申请数量*单价
               Inv_Id, -- 仓库id
               Inv_Code, -- 仓库编码
               Inv_Name, -- 仓库名称
               Ship_Inv_Code, -- 发货仓编码（调拨使用）
               Ship_Inv_Name, -- 发货仓名称（调拨使用）
               Price_List_Id, -- 价格列表id
               Price_System_Id, -- 价格体系id
               Discount_Rate, -- 扣率（从价格列表带出，或手工填写）
               Ordered_Discount_Rate, -- 月返。从价格列表获取的折扣（荣事达洗衣机需求）
               Discount_Type_Id, -- 款项类型id（额度组、折扣类型统一名称）
               Sales_Order_Type_Id, -- 销售单类型id
               Project_Order_Type, -- 批文类型（新增）
               Project_Order_Number, -- 批文号
               Project_Order_Line_Id, -- 批文行id（用于基础模块进行对应产品扣减）
               Apply_List_Price, -- 申请价（工程机批文价格）
               Apply_Discount_Rate, -- 申请折扣（工程机批文折扣）
               Source_Type, -- 发货状态（“紧急订单”）
               Spec_Qty, -- 凑整数量（厨电，从产品数据获取）
               Is_Need_Int, -- 是否凑整（厨电，从产品数据获取）
               Is_Logistics, -- 是否生成发货单或运输合同（厨电）
               Biz_Source_Type, -- 来源类型
               Biz_Source_Number, -- 来源号
               Source_Head_Id, -- 来源头id
               Source_Head_Code, -- 来源头编码
               Source_Line_Id, -- 来源行iid
               Lock_Inv_Pre, -- 锁定库存数量
               Lock_Amount_Percent, -- 行锁定金额百分比
               Lock_Amount_Pre, -- 行锁定金额
               Low_Stock_Init, -- 默认最低库存？
               High_Stock_Init, -- 默认最高库存？
               Low_Stock_Adjust, -- 调整最低库存？
               High_Stock_Adjust, -- 调整最高库存？
               Low_Stock_Confirm, -- 确认最低库存？
               High_Stock_Confirm, -- 确认最高库存？
               Sended_Qty, -- 已直发数量？
               Hq_Pln4_Order_Qty, -- 转总部计划订单数量（提货订单库存评审未满足部分需要转计划订单）
               Pln4_Order_Awaiting_Qty, -- 转总部计划订单等待数量
               Created_By, -- 创建人
               Creation_Date, -- 创建日期
               Last_Updated_By, -- 最后修改人
               Last_Update_Date, -- 最后修改日期
               Remark, -- 备注
               Pre_Field_01, -- 订单行评审意见（原预留字段1）
               Pre_Field_02, -- 预留字段2
               Pre_Field_03, -- 预留字段3
               Pre_Field_04, -- 预留字段4
               Pre_Field_05, -- 预留字段5
               Pre_Field_06, -- 预留字段6
               Carried_Quantity, -- 已提货数
               Affirmed_Quantity, -- 已评审数量
               Lg_Ship_Doc_Id, -- 发货通知单头id
               Check_Content, -- 评审意见
               Program_Updated_By, -- 程序修改来源
               Program_Update_Date, -- 修改时间
               Default_Unit, --产品单位
               Producing_Area_Id, --产地ID
               Producing_Area_Code, --产地编码
               Producing_Area_Name --产地名称

               )
            Values
              (r_Pln_Lg_Order_Line.Entity_Id, --ENTITY_ID --主体ID
               v_Lg_Order_Line_Id, --ORDER_LINE_ID --行ID
               v_Lg_Order_Head_Id, --ORDER_HEAD_ID --头ID
               Null, --ORDER_LINE_STATE --单据行状态
               v_Item_Id, -- 产品id
               r_Pln_Lg_Order_Line.Item_Code, -- 产品编码
               v_Item_Desc, -- 产品名称
               r_Pln_Lg_Order_Line.Unit_Volume, --unit_volume   单位体积
               r_Pln_Lg_Order_Line.Unit_Weight, --unit_weight   单位重量
               v_Item_Price, --list_price 单价
               v_Sales_Sub_Type, -- 营销小类
               v_Sales_Main_Type, -- 营销大类
               r_Pln_Lg_Order_Line.Quantity, -- 申请数量
               Null, -- 评审数量
               Null, -- 开单数量（出仓单数量，销售回写）
               Null, -- 取消数量（物流回写）
               Null, -- 签收数量（厨电，物流回写，建议删除）
               Null, -- 在途数量（厨电，建议删除）
               r_Pln_Lg_Order_Line.Virtual_Qty, -- 提货计划数（厨电，现有量）
               v_Apply_Amount, -- 申请金额=申请数量*单价
               0, -- 仓库id
               Null, -- 仓库编码
               Null, -- 仓库名称
               Null, -- 发货仓编码（调拨使用）
               Null, -- 发货仓名称（调拨使用）
               Null, -- 价格列表id
               Null, -- 价格体系id
               v_Discount, -- 扣率（从价格列表带出，或手工填写）
               v_Month_Discount, -- 月返。从价格列表获取的折扣（荣事达洗衣机需求）
               Null, -- 款项类型id（额度组、折扣类型统一名称）
               Null, -- 销售单类型id
               v_Apply_Type, -- 批文类型（新增）
               v_Apply_Code, -- 批文号
               r_Pln_Lg_Order_Line.Project_Order_Line_Id, -- 批文行id（用于基础模块进行对应产品扣减）
               v_Apply_Price, -- 申请价（工程机批文价格）
               v_Apply_Discount, -- 申请折扣（工程机批文折扣）
               r_Pln_Lg_Order_Line.Source_Type, -- 发货状态（“紧急订单”）
               v_Rounding_Cnt, -- 凑整数量（厨电，从产品数据获取）
               v_Is_Rounding, -- 是否凑整（厨电，从产品数据获取）
               Null, -- 是否生成发货单或运输合同（厨电）
               r_Pln_Lg_Order_Line.Biz_Source_Type, -- 来源类型
               r_Pln_Lg_Order_Line.Biz_Source_Number, -- 来源号
               r_Pln_Lg_Order_Line.Source_Head_Id, -- 来源头id
               r_Pln_Lg_Order_Line.Source_Head_Code, -- 来源头编码
               r_Pln_Lg_Order_Line.Source_Line_Id, -- 来源行iid
               Null, -- 锁定库存数量
               Null, -- 行锁定金额百分比
               Null, -- 行锁定金额
               Null, -- 默认最低库存？
               Null, -- 默认最高库存？
               Null, -- 调整最低库存？
               Null, -- 调整最高库存？
               Null, -- 确认最低库存？
               Null, -- 确认最高库存？
               Null, -- 已直发数量？
               Null, -- 转总部计划订单数量（提货订单库存评审未满足部分需要转计划订单）
               Null, -- 转总部计划订单等待数量
               'PKG_PLN_INTF_IMS', -- 创建人
               Sysdate, -- 创建日期
               'PKG_PLN_INTF_IMS', -- 最后修改人
               Sysdate, -- 最后修改日期
               r_Pln_Lg_Order_Line.Remark, -- 备注
               r_Pln_Lg_Order_Line.Pre_Field_01, -- 订单行评审意见（原预留字段1）
               r_Pln_Lg_Order_Line.Pre_Field_02, -- 预留字段2
               r_Pln_Lg_Order_Line.Pre_Field_03, -- 预留字段3
               r_Pln_Lg_Order_Line.Pre_Field_04, -- 预留字段4
               r_Pln_Lg_Order_Line.Pre_Field_05, -- 预留字段5
               r_Pln_Lg_Order_Line.Pre_Field_06, -- 预留字段6
               Null, -- 已提货数
               Null, -- 已评审数量
               Null, -- 发货通知单头id
               Null, -- 评审意见
               'PKG_PLN_INTF_IMS', -- 程序修改来源
               Sysdate, -- 修改时间
               v_Default_Unit, --产品单位
               v_Producing_Area_Id, --产地ID   --modi by lizhen 2015-08-24
               v_Producing_Area_Code, --产地编码 --modi by lizhen 2015-08-24
               v_Producing_Area_Name  --产地名称 --modi by lizhen 2015-08-24
               );

            --更新接口行表
            Update Intf_Pln_Lg_Order_Line l
               Set l.Order_Line_Id = v_Lg_Order_Line_Id,
                   l.Order_Head_Id = v_Lg_Order_Head_Id
             Where l.Intf_Id = r_Pln_Lg_Order_Line.Intf_Id;

          Exception
            When Others Then
              p_Result := v_Value || '失败。' || v_Nl || Sqlerrm;
              Raise v_Intf_Exception;
          End;
        End If;
      End Loop;
      Close c_Pln_Lg_Order_Line;
    End If;

    If p_Result = v_Success Then
      Begin
        v_Value := '订单送审：';
        Pkg_Pln_Order.p_Order_Operate(p_Order_Head_Id    => v_Lg_Order_Head_Id,
                                      p_Order_Type_Id    => r_Pln_Lg_Order_Head.Order_Type_Id,
                                      p_Operation_Action => '送审',
                                      p_User_Code        => 'admin',
                                      p_Result           => p_Result);
        If p_Result <> v_Success Then
          Raise v_Intf_Exception;
        End If;
      Exception
        When v_Intf_Exception Then
          p_Result := v_Value || '失败。' || p_Result;
          Raise v_Intf_Exception;
        When Others Then
          p_Result := v_Value || '失败。' || p_Result || v_Nl || Sqlerrm;
          Raise v_Intf_Exception;
      End;

      If r_Pln_Order_Type.Is_Business_Control = v_Bussiness_Control Then

        Begin
          v_Value := '自动库存评审：';
          Pkg_Pln_Lg_Order.p_Lgorder_Shareship_Review(v_Lg_Order_Head_Id,
                                                      'admin',
                                                      p_Result);
          If p_Result <> v_Success Then
            Raise v_Intf_Exception;
          End If;

          /* v_Message:='提货订单可发货数量不足: '||v_Nl;
          v_Count:=0;
          For r_pln_lg_line_check in ( select *
                          from t_pln_lg_order_line l
                          where nvl(l.quantity,0) <> nvl(l.affirm_quantity,0)
                          and l.order_head_id=v_Lg_Order_Head_Id
                          and l.entity_id=r_Pln_Lg_Order_Head.Entity_Id) loop
          v_Message:=v_Message|| '产品编码 '|| r_pln_lg_line_check.item_code||
                       ' 申请数量 '||r_pln_lg_line_check.quantity||
                       ' 可提货数量 '||r_pln_lg_line_check.affirm_quantity||v_Nl;
          v_Count:=v_Count+1;
          End loop;

          if v_Count>0 then
            p_Result:=v_Message;
            raise v_Intf_Exception;
          end if;*/

        Exception
          When v_Intf_Exception Then
            p_Result := v_Value || '失败。' || p_Result;
            Raise v_Intf_Exception;
          When Others Then
            p_Result := v_Value || '失败。' || p_Result || v_Nl || Sqlerrm;
            Raise v_Intf_Exception;
        End;

      End If;

    End If;

    If p_Result = v_Success Then
      Begin
        v_Value := '更新接口表状态：';
        Update Intf_Pln_Lg_Order_Head Oh
           Set Oh.Intf_Status   = v_Status_Sucess,
               Oh.Error_Message = p_Result,
               Oh.Order_Head_Id = v_Lg_Order_Head_Id,
               Oh.Order_Number  = v_Order_Number
         Where Oh.Intf_Id = r_Pln_Lg_Order_Head.Intf_Id;
        --Commit;
      Exception
        When Others Then
          p_Result := v_Value || '接口表ID ' || r_Pln_Lg_Order_Head.Intf_Id ||
                      '失败。';
          Raise v_Intf_Exception;
      End;
    End If;

    <<errlable>>
    If p_Result <> v_Success Then
      Raise v_Intf_Exception;
    End If;

  Exception
    When v_Intf_Exception Then
      Rollback;
      p_Result := '失败：' || p_Result;
      Update Intf_Pln_Lg_Order_Head Oh
         Set Oh.Intf_Status = v_Status_Fail, Oh.Error_Message = p_Result
       Where Oh.Intf_Id = r_Pln_Lg_Order_Head.Intf_Id;

      v_Value := Pkg_Bd.f_Add_Error_Log('pkg_pln_intfims.P_CREATE_LGORDER',
                                        1000,
                                        r_Pln_Lg_Order_Head.Intf_Id || '|' ||
                                        p_Result);
    When Others Then
      Rollback;
      p_Result := '失败：' || p_Result || v_Nl || Sqlerrm;
      Update Intf_Pln_Lg_Order_Head Oh
         Set Oh.Intf_Status = v_Status_Fail, Oh.Error_Message = p_Result
       Where Oh.Intf_Id = r_Pln_Lg_Order_Head.Intf_Id;

      v_Value := Pkg_Bd.f_Add_Error_Log('pkg_pln_intf_IMS.P_CREATE_LGORDER',
                                        1000,
                                        r_Pln_Lg_Order_Head.Intf_Id || '|' ||
                                        p_Result);
      --Commit;
  End;

  ------------------------------------------------------------------------------------------
  -- Author  : NICRO.LI
  -- Created : 2015-07-18 17:24:25
  -- Purpose : 生成CIMS销售单后，同时生成IMS的采购单、财务单
  ------------------------------------------------------------------------------------------
  Procedure p_Soorder_To_Ims_Pox(p_Lg_Ship_Info_Id In Number,
                                 p_Result          Out Varchar2) Is

    Cursor c_So_Head(v_Origin_Type           In Varchar2,
                     v_Origin_Order_Id       In Varchar2,
                     v_Origin_Origin_Type    In Varchar2,
                     v_Origin_Origin_Head_Id In Varchar2) Is
      Select Sh.So_Header_Id, Sh.Entity_Id
        From t_So_Header Sh
       Where Sh.Raw_Src_Type = v_Origin_Type
         And Sh.Raw_Src_Bill_Id = v_Origin_Order_Id
         And Nvl(Sh.Origin_Origin_Type, '_') = v_Origin_Origin_Type
         And Nvl(Sh.Origin_Origin_Head_Id, 0) = v_Origin_Origin_Head_Id
         And Nvl(Sh.To_Ims_Pox_Flag, 'N') = 'N'
         And (Select Count(*)
                From t_So_Line Sl
               Where Sl.So_Header_Id = Sh.So_Header_Id) > 0
        For Update;

    r_So_Head c_So_Head%Rowtype;
    v_Cims_So_Head_Id  Number;
    v_Lg_Order_Head_Id Number;
    v_Sys_Source       t_pln_lg_order_head.sys_source%Type;
    v_Return           Number;
    v_Value            Varchar2(2000);
    v_To_Ims_Pox       Varchar2(10);
    v_entity_id NUMBER; --主体ID
    v_Entity_Is_To_Pox_So T_BD_PARAM_ENTITY.ENTITY_VALUE%TYPE;  --是否生成分部采购单和分部销售单
  BEGIN
    /*SELECT s.entity_id INTO v_entity_id
      FROM T_LG_ACTUAL_SHIP s
     WHERE s.actual_ship_id = p_Lg_Ship_Info_Id;

    Select Pkg_Bd.f_Get_Parameter_Value(p_Config_Code => 'PLN_LG_SHIP_TO_POX_AND_SO',
                                        p_Entity_Id   => v_entity_id)
      Into v_Entity_Is_To_Pox_So
      From Dual;

    IF v_Entity_Is_To_Pox_So = 'Y' THEN --根据参数设置是否同步生成
      For r_Ship_Doc In (Select Distinct b.Ship_Doc_Id,
                                         b.Origin_Type,
                                         b.Origin_Order_Num,
                                         b.Origin_Order_Id,
                                         Nvl(b.Origin_Origin_Type, '_') Origin_Origin_Type,
                                         Nvl(b.Origin_Origin_Doc_Code, '_') Origin_Origin_Doc_Code,
                                         Nvl(b.Origin_Origin_Head_Id, 0) Origin_Origin_Head_Id
                           From t_Lg_Actual_Ship_Line a, t_Lg_Ship_Doc_Line b
                          Where a.Ship_Doc_Line_Id = b.Ship_Doc_Line_Id
                            And a.Ship_Info_Id = p_Lg_Ship_Info_Id) Loop
        If (r_Ship_Doc.Origin_Type = '01' And r_Ship_Doc.Origin_Origin_Type = '02')
          Or r_Ship_Doc.Origin_Type = '02' Then
          Begin
            Select Decode(r_Ship_Doc.Origin_Type,
                          '01',
                          r_Ship_Doc.Origin_Origin_Head_Id,
                          '02',
                          r_Ship_Doc.Origin_Order_Id,
                          0)
              Into v_Lg_Order_Head_Id
              From Dual;

            --跨主体提货，来源为IMS 且为客户直发订单才允许自动转采购及销售单
            Select Nvl(Oh.Sys_Source, '_'),
                   Case
                     When Nvl(Oh.Sys_Source, '_') = 'IMS' And
                          Nvl(Oh.Direct_Send_Flag, 'N') = 'Y' Then
                      'Y'
                     Else
                      'N'
                   End
              Into v_Sys_Source, v_To_Ims_Pox
              From t_Pln_Lg_Order_Head Oh
             Where Oh.Order_Head_Id = v_Lg_Order_Head_Id;
          Exception
            When Others Then
              p_Result := '获取提货订单失败!' || v_Nl || '提货订单头ID：' ||
                          To_Char(v_Lg_Order_Head_Id);
              Raise v_Intf_Exception;
          End;

          If v_Sys_Source = 'IMS' And Nvl(v_To_Ims_Pox, 'N') = 'Y' Then
            Begin
              Open c_So_Head(r_Ship_Doc.Origin_Type,
                             r_Ship_Doc.Origin_Order_Id,
                             r_Ship_Doc.Origin_Origin_Type,
                             r_Ship_Doc.Origin_Origin_Head_Id);
            Exception
              When Others Then
                p_Result := '获取提货订单已生成销售单据失败！' || v_Nl || '提货订单ID：' ||
                            To_Char(v_Lg_Order_Head_Id) || v_Nl || Sqlerrm;
                Raise v_Intf_Exception;
            End;
            Loop
              Fetch c_So_Head Into r_So_Head;
              Exit When c_So_Head%Notfound;
              Pkg_Io_Cims_Ims.p_Cims_To_Ims_Pox_So(p_Cims_Entity_Id  => r_So_Head.Entity_Id, --CIMS主体ID
                                                   p_Source_Type     => '财务单', --CIMS来源类型（财务单。。。）
                                                   p_Source_Order_Id => r_So_Head.So_Header_Id, --CIMS来源单据ID
                                                   p_Return          => v_Return, --错误号，无错误返回0
                                                   p_Result          => p_Result --返回信息
                                                   );
              If p_Result <> 'OK' Then
                Raise v_Intf_Exception;
              Else
                p_Result := v_Success;
                Update t_So_Header Sh
                   Set Sh.To_Ims_Pox_Flag  = 'Y',
                       Sh.To_Ims_Pox_Date  = Sysdate,
                       Sh.Last_Updated_By  = 'p_Soorder_To_Ims_Pox',
                       Sh.Last_Update_Date = Sysdate,
                       Sh.Version          = Nvl(Sh.Version, 0) + 1
                 Where Sh.So_Header_Id = r_So_Head.So_Header_Id;
              End If;
            End Loop;
          End If;
        End If;
      End Loop;
    ELSE
      p_Result := v_Success;
    END IF;*/
    p_Result := v_Success;
  Exception
    When v_Intf_Exception Then
      Rollback;
      p_Result := 'Pkg_Pln_Intf_Ims.p_Soorder_To_Ims_Pox失败：' || p_Result;
      v_Value  := Pkg_Bd.f_Add_Error_Log('pkg_pln_intf_ims.p_Soorder_To_Ims_Supplier',
                                         1000,
                                         p_Lg_Ship_Info_Id || '|' ||
                                         p_Result);
    When Others Then
      Rollback;
      p_Result := 'Pkg_Pln_Intf_Ims.p_Soorder_To_Ims_Pox失败：' || p_Result || v_Nl || Sqlerrm;
      v_Value  := Pkg_Bd.f_Add_Error_Log('pkg_pln_intf_ims.p_Soorder_To_Ims_Supplier',
                                         1000,
                                         p_Lg_Ship_Info_Id || '|' ||
                                         p_Result);
  End;

  ---------------------------------------------------------------------------------
  -- Author  : 何加源
  -- Created : 2015-11-20
  -- Purpose : 获取独资主体订单锁款标志
  ---------------------------------------------------------------------------------
  FUNCTION f_get_Ims_Lg_Lock_flag(p_Lg_Order_Head_Id In Number, --提货订单头ID
                                  p_Entity_Id        In NUMBER) --主体ID
  RETURN VARCHAR2 IS
    V_IMS_LG_LOCK_AMOUNT_FLAG VARCHAR2(5) := 'S'; --T：结转时锁款；S：发货时锁款
  BEGIN
    /*BEGIN
      SELECT Imsh.to_Cims_Lock_amount_flag
        INTO V_IMS_LG_LOCK_AMOUNT_FLAG
        FROM t_Pln_Lg_Order_Head Loh,
             Ims_t_Lg_Order_Head Imsh
       WHERE Loh.Sys_Source = 'IMS'
         And LoH.Source_Order_Id = ImsH.ORDER_ID
         And LoH.Order_Head_Id = p_Lg_Order_Head_Id
         And LoH.Entity_Id = p_Entity_Id;
    EXCEPTION
      WHEN OTHERS THEN
        V_IMS_LG_LOCK_AMOUNT_FLAG := 'S'; --默认为发货时锁款
    END;*/
    RETURN V_IMS_LG_LOCK_AMOUNT_FLAG;
  END;
  
  ---------------------------------------------------------------------------------
  -- Author  : 何加源
  -- Created : 2016-6-18
  -- Purpose : 回写IMS订单
  ---------------------------------------------------------------------------------
  PROCEDURE p_WriteBack_Ims_Lg_Order(p_Io_Opt_Id IN NUMBER, --操作接口ID
                                     p_Result OUT VARCHAR2) --返回信息
  IS
    v_Value VARCHAR2(4000);
  BEGIN
    /*Pkg_Io_Cims_Ims.P_LG_ORDER_WRITEBACK(P_IO_OPT_ID => p_Io_Opt_Id,
                                         P_MESSAGE => p_Result);
    
    IF p_Result <> 'OK' THEN
      RAISE v_Intf_Exception;
    ELSE
      p_Result := 'SUCCESS';
    END IF;*/
    p_Result := 'SUCCESS';
  EXCEPTION
    WHEN v_Intf_Exception THEN
      Rollback;
      p_Result := '回写IMS订单失败：' || v_Nl || p_Result;
      v_Value  := Pkg_Bd.f_Add_Error_Log('pkg_pln_intf_ims.p_WriteBack_Ims_Lg_Order',
                                         'IMS-00001',
                                         p_Io_Opt_Id || '|' || p_Result);
    WHEN OTHERS THEN
      Rollback;
      p_Result := '回写IMS订单失败：' || v_Nl || Sqlerrm;
      v_Value  := Pkg_Bd.f_Add_Error_Log('pkg_pln_intf_ims.p_WriteBack_Ims_Lg_Order',
                                         'IMS-00001',
                                         p_Io_Opt_Id || '|' || p_Result);
  END p_WriteBack_Ims_Lg_Order;
  
  ---------------------------------------------------------------------------------
  -- Author  : 何加源
  -- Created : 2016-8-29
  -- Purpose : 回写CIMS单号
  ---------------------------------------------------------------------------------
  PROCEDURE p_WriteBack_Cims_PoxSo
  IS
    v_Value VARCHAR2(4000);
    v_so_header_id NUMBER;
  BEGIN
    /*UPDATE T_SO_TO_POX_SO_MSG M
       SET M.DEAL_FLAG = 'P' --设置标志
     WHERE M.DEAL_FLAG = 'N';
    
    FOR RP IN (SELECT DISTINCT M.SO_HEADER_ID FROM T_SO_TO_POX_SO_MSG M
                WHERE M.DEAL_FLAG = 'P') LOOP
      v_so_header_id := RP.SO_HEADER_ID;
      FOR RW IN (SELECT * FROM T_SO_TO_POX_SO_MSG M
                  WHERE M.DEAL_FLAG = 'P'
                    AND M.SO_HEADER_ID = v_so_header_id) LOOP
        
        UPDATE T_SO_HEADER H
           SET H.REMARK = SUBSTRB(H.REMARK || RW.POX_SO_NUMBER, 1, 4000),
               H.LAST_UPDATED_BY = 'admin',
               H.LAST_UPDATE_DATE = SYSDATE,
               H.VERSION = NVL(H.VERSION, 0) + 1
         WHERE H.SO_HEADER_ID = v_so_header_id;
      END LOOP;
      UPDATE T_SO_TO_POX_SO_MSG M
         SET M.DEAL_FLAG = 'Y'
       WHERE M.SO_HEADER_ID = v_so_header_id
         AND M.DEAL_FLAG = 'P';
    END LOOP;*/
    NULL;
  EXCEPTION
    WHEN OTHERS THEN
      Rollback;
      v_Value := '回写IMS订单失败：' || v_Nl || Sqlerrm;
      v_Value  := Pkg_Bd.f_Add_Error_Log('pkg_pln_intf_ims.p_WriteBack_Cims_PoxSo',
                                         'IMS-00001',
                                         v_so_header_id || '|' || v_Value);
  END p_WriteBack_Cims_PoxSo;
  
  ---------------------------------------------------------------------------------
  -- Author  : 何加源
  -- Created : 2015-11-20
  -- Purpose : 写操作接口表
  ---------------------------------------------------------------------------------
  PROCEDURE P_WriteBack_Opt_Intf(p_Lg_Order_Head_Id In Number, --提货订单头ID
                                 p_Lg_Order_Line_Id In Number, --提货订单行ID
                                 p_Entity_Id        In NUMBER, --主体ID
                                 p_Opt_Type         IN VARCHAR2, --操作类型
                                 p_Transaction_Qty  IN NUMBER, --数量
                                 p_Deal_Money_Cims  IN VARCHAR2, --CIMS款项处理标志
                                 p_Deal_Money_Ims   IN VARCHAR2, --IMS款项处理标志
                                 p_User_Code        IN VARCHAR2, --操作用户
                                 p_Result           Out Varchar2)
  IS
  BEGIN
    p_Result := v_Success;
    /*IF p_Opt_Type IN ('关闭', '驳回') THEN
      INSERT INTO INTF_PLN_LG_ORDER_OPT
        (ENTITY_ID,
         INTF_OPT_ID,
         OPT_TYPE,
         ORDER_HEAD_ID,
         ORDER_LINE_ID,
         SYS_SOURCE,
         SOURCE_HEAD_ID,
         SOURCE_LINE_ID,
         OPT_QUANTITY,
         DEAL_MONEY,
         DEAL_FLAG,
         CREATED_BY,
         CREATION_DATE)
      SELECT p_Entity_Id,
             S_INTF_PLN_LG_ORDER_OPT.NEXTVAL,
             p_Opt_Type,
             H.order_head_id,
             p_Lg_Order_Line_Id,
             'CIMS',
             H.ORDER_HEAD_ID,
             p_Lg_Order_Line_Id,
             p_Transaction_Qty,
             p_Deal_Money_Cims,
             DECODE(p_Deal_Money_Cims, '不处理款项', 'C', 'N'),
             p_User_Code,
             SYSDATE
        FROM T_PLN_LG_ORDER_HEAD H
       WHERE H.ORDER_HEAD_ID = p_Lg_Order_Head_Id;

      INSERT INTO IMS_IO_LG_ORDER_OPT
        (IO_OPT_ID,
         OPT_TYPE,
         ORDER_HEAD_ID,
         ORDER_LINE_ID,
         SYS_SOURCE,
         SOURCE_HEAD_ID,
         SOURCE_LINE_ID,
         OPT_QUANTITY,
         DEAL_MONEY,
         DEAL_FLAG,
         CREATED_BY,
         CREATION_DATE,
         CHECKUP_CONTENT)
      SELECT IMS_S_IO_LG_ORDER_OPT.NEXTVAL,
             p_Opt_Type,
             H.order_head_id,
             p_Lg_Order_Line_Id,
             H.SYS_SOURCE,
             Imsh.ORDER_ID,
             -1,
             p_Transaction_Qty,
             p_Deal_Money_ims,
             'N',
             p_User_Code,
             SYSDATE,
             (SELECT L.LINE_CLOSE_REASON
                FROM T_PLN_LG_ORDER_LINE L
               WHERE L.ORDER_HEAD_ID = H.ORDER_HEAD_ID
                 AND NVL(L.ORDER_LINE_STATE, 'NORMAL') <> 'CLOSED'
                 AND ROWNUM = 1)
        FROM T_PLN_LG_ORDER_HEAD H,
             Ims_t_Lg_Order_Head Imsh
       WHERE H.ORDER_HEAD_ID = p_Lg_Order_Head_Id
         AND H.SYS_SOURCE = 'IMS'
         AND H.SOURCE_ORDER_ID = Imsh.Order_Id;
    ELSE
      INSERT INTO INTF_PLN_LG_ORDER_OPT
        (ENTITY_ID,
         INTF_OPT_ID,
         OPT_TYPE,
         ORDER_HEAD_ID,
         ORDER_LINE_ID,
         SYS_SOURCE,
         SOURCE_HEAD_ID,
         SOURCE_LINE_ID,
         OPT_QUANTITY,
         DEAL_MONEY,
         DEAL_FLAG,
         CREATED_BY,
         CREATION_DATE)
      SELECT p_Entity_Id,
             S_INTF_PLN_LG_ORDER_OPT.NEXTVAL,
             p_Opt_Type,
             l.order_head_id,
             l.order_line_id,
             'CIMS',
             L.ORDER_HEAD_ID,
             L.ORDER_LINE_ID,
             p_Transaction_Qty,
             p_Deal_Money_Cims,
             DECODE(p_Deal_Money_Cims, '不处理款项', 'C', 'N'),
             p_User_Code,
             SYSDATE
        FROM T_PLN_LG_ORDER_LINE L
       WHERE L.ORDER_LINE_ID = p_Lg_Order_Line_Id;

      INSERT INTO IMS_IO_LG_ORDER_OPT
        (IO_OPT_ID,
         OPT_TYPE,
         ORDER_HEAD_ID,
         ORDER_LINE_ID,
         SYS_SOURCE,
         SOURCE_HEAD_ID,
         SOURCE_LINE_ID,
         OPT_QUANTITY,
         DEAL_MONEY,
         DEAL_FLAG,
         CREATED_BY,
         CREATION_DATE,
         CHECKUP_CONTENT)
      SELECT IMS_S_IO_LG_ORDER_OPT.NEXTVAL,
             p_Opt_Type,
             l.order_head_id,
             l.order_line_id,
             H.SYS_SOURCE,
             Imsl.ORDER_ID,
             Imsl.LINE_ID,
             p_Transaction_Qty,
             p_Deal_Money_ims,
             'N',
             p_User_Code,
             SYSDATE,
             L.LINE_CLOSE_REASON
        FROM T_PLN_LG_ORDER_LINE L,
             T_PLN_LG_ORDER_HEAD H,
             Ims_t_Lg_Order_Line Imsl
       WHERE L.ORDER_LINE_ID = p_Lg_Order_Line_Id
         AND H.ORDER_HEAD_ID = L.ORDER_HEAD_ID
         AND H.ORDER_HEAD_ID = p_Lg_Order_Head_Id
         AND H.SYS_SOURCE = 'IMS'
         AND L.SOURCE_LINE_ID = Imsl.Line_Id;
    END IF;*/
  Exception
    When v_Intf_Exception Then
      Rollback;
      p_Result := '回写提货订单操作接口表失败！' || v_Nl || p_Result;
    When Others Then
      Rollback;
      p_Result := '回写提货订单操作接口表失败！' || v_Nl || p_Result || v_Nl || Sqlerrm;
  END;

End Pkg_Pln_Intf_Ims;
/

