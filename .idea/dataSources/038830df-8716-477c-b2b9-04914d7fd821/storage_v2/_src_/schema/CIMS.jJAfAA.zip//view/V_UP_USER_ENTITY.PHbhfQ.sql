create view V_UP_USER_ENTITY as
select distinct user_id, up_user_id,user_code, user_name, entity_id,entity_name
  from (select us.user_id,
               us.id up_user_id,
               us.account user_code,
               us.name user_name,
               ut.entity_id,
               tt.entity_name entity_name
          from up_org_user us, up_org_unit_user uu, up_org_unit ut,v_bd_entity tt
         where us.id = uu.user_id
           and uu.unit_id = ut.id
           and ut.entity_id = tt.entity_id
        --and ut.entity_id is not null
        union all
        select us.user_id,
               us.id up_user_id,
               us.account user_code,
               us.name user_name,
               ut.entity_id,
               tt.entity_name entity_name
          from up_org_user us, v_bd_user_org_priv uu, up_org_unit ut,v_bd_entity tt
         where us.user_id = uu.user_id
           and uu.unit_id = ut.unit_id
           and ut.entity_id = tt.entity_id
           ) t
/

