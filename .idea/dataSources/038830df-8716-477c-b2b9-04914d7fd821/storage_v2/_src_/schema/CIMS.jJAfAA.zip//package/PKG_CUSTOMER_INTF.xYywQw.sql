create PACKAGE PKG_CUSTOMER_INTF IS

  PROCEDURE P_CUSTOMER_INTF_PROC(P_INTF_HEADER_ID_LIST IN VARCHAR2, --接口表中的客户头ID，用逗号分隔
                                 P_MESSAGE             OUT VARCHAR2, --成功则返回“SUCCESS”，否则返回出错信息
                                 IS_CTRL_PARAM         IN  VARCHAR2 DEFAULT NULL--NOTGTWIDTH 不联动失效
                                 );

  PROCEDURE P_CUSTOMER_INTF_PROCLOV(P_INTF_TRANSCODE IN VARCHAR2, --接口流水号
                                    P_MESSAGE        OUT VARCHAR2 --成功则返回“SUCCESS”，否则返回出错信息
                                    );

  PROCEDURE P_CUSTOMER_CHECK_CANVALID_PROC(P_INVALID_ID    IN NUMBER, --失效历史ID
                                           P_CUSTOMER_CODE IN VARCHAR2, --客户编码
                                           P_INVALID_TYPE  IN VARCHAR2, --失效类型
                                           --001代表客户头失效，002代表事业部层失效，003代表客户OU失效
                                           P_DEPT_CODE      IN VARCHAR2, --事业部编码
                                           P_DEPT_NAME      IN VARCHAR2, --事业部名称
                                           P_CUSTOMER_OU_ID IN VARCHAR2, --客户OU ID
                                           P_TRANSCODE      IN VARCHAR2, --流水号
                                           P_SOURCE_CODE    IN VARCHAR2, --来源系统
                                           P_REQUEST_ID     IN VARCHAR2, --请求ID
                                           P_RESULT         OUT VARCHAR2,
                                           --返回结果：Y 可以失效 N不可以失效 U未处理 E异常
                                           P_MESSAGE OUT VARCHAR2
                                           --P_RESULT等于2时返回，或者有错误时返回
                                           );

  FUNCTION F_CUSTORG_CHECK_CANVALID(P_CUSTOMER_CODE      IN VARCHAR2, --客户编码
                                    P_DEPT_CODE          IN VARCHAR2, --事业部编码
                                    P_SALES_CENTER_ID    IN NUMBER, --中心ID
                                    P_SALES_CENTER_CODE  IN VARCHAR2, --中心编码
                                    P_CUST_ORG_ID        IN NUMBER, --客户中心关系ID
                                    P_SIEBEL_CUST_ORG_ID IN VARCHAR2, --客户中心关系主数据ID
                                    P_ACCOUNT_ID         IN NUMBER --账户ID
                                    ) RETURN VARCHAR2;

  FUNCTION F_CUSTORG_CHECK_UNDO(P_CUSTOMER_CODE      IN VARCHAR2, --客户编码
                                P_DEPT_CODE          IN VARCHAR2, --事业部编码
                                P_SALES_CENTER_ID    IN NUMBER, --中心ID
                                P_SALES_CENTER_CODE  IN VARCHAR2, --中心编码
                                P_CUST_ORG_ID        IN NUMBER, --客户中心关系ID
                                P_SIEBEL_CUST_ORG_ID IN VARCHAR2, --客户中心关系主数据ID
                                P_ACCOUNT_ID         IN NUMBER, --账户ID
                                IN_INTF_OR_BUSI      IN NUMBER DEFAULT NULL,
                                --1或空非系统初始化账户 2系统初始化 3不区分
                                IN_AMOUNT_NOCHK IN NUMBER DEFAULT NULL
                                --1不检查余额
                                ) RETURN VARCHAR2;

  FUNCTION F_INSERT_OR_UPDATE_HEADER
  --更新或插入客户头业务表
  (P_INTF_HEAD_ID NUMBER --客户头ID
   ) RETURN VARCHAR2;

  PROCEDURE PRC_INSERT_OR_UPDATE_HEADER
  --更新或插入客户头业务表
  (P_INTF_HEADER        IN INTF_CUSTOMER_HEADER%ROWTYPE, --客户头
   P_CUST_HEADER_ID     OUT NUMBER, --客户头ID
   P_CUST_HEADER_STATUS OUT VARCHAR2, --客户头状态
   P_HEADER_ID          OUT NUMBER, --客户头ID
   P_MESSAGE            OUT VARCHAR2);

  FUNCTION F_INSERT_OR_UPDATE_DEPT
  --更新或插入客户事业部业务表
  (P_INTF_HEAD_ID NUMBER --客户头ID
   ) RETURN VARCHAR2;

  FUNCTION F_INSERT_OR_UPDATE_CONTACTS
  --更新或插入客户联系人业务表
  (P_INTF_HEAD_ID NUMBER --客户头ID
   ) RETURN VARCHAR2;

  FUNCTION F_INSERT_OR_UPDATE_ADDRESS
  --更新或插入客户地址业务表
  (P_INTF_HEAD_ID NUMBER --客户头ID
   ) RETURN VARCHAR2;

  FUNCTION F_INSERT_OR_UPDATE_BANK
  --更新或插入客户银行业务表
  (P_INTF_HEAD_ID NUMBER --客户头ID
   ) RETURN VARCHAR2;

  FUNCTION F_INSERT_OR_UPDATE_BRAND
  --更新或插入客户品牌业务表
  (P_INTF_HEAD_ID NUMBER --客户头ID
   ) RETURN VARCHAR2;

  FUNCTION F_INSERT_OR_UPDATE_CHANN_TYPE
  --更新或插入客户业态类型（渠道类型）业务表
  (P_INTF_HEAD_ID NUMBER --客户头ID
   ) RETURN VARCHAR2;

  FUNCTION F_INSERT_OR_UPDATE_CONNECTION
  --更新或插入客户关联关系业务表
  (P_INTF_HEAD_ID NUMBER --客户头ID
   ) RETURN VARCHAR2;

  FUNCTION F_INSERT_OR_UPDATE_ORG
  --更新或插入客户组织业务表
  (P_INTF_HEAD_ID NUMBER --客户头ID
   ) RETURN VARCHAR2;

  FUNCTION F_INSERT_OR_UPDATE_OU
  --更新或插入客户OU业务表
  (P_INTF_HEAD_ID NUMBER --客户头ID
   ) RETURN VARCHAR2;

  FUNCTION F_INSERT_OR_UPDATE_MAIN_TYPE
  --更新或插入客户营销大类业务表
  (P_INTF_HEAD_ID NUMBER --客户头ID
   ) RETURN VARCHAR2;

  PROCEDURE PRC_UPDATE_STATUS_CHANGED
  --当客户头状态、事业部有效状态、事业部客户状态、组织状态失效、冻结时更新
  (P_INTF_HEAD_ID IN NUMBER, --客户头ID
   P_HEAD_ID      IN NUMBER --客户头ID
   );

  PROCEDURE P_CUSTOMER_INTF_PROC(IS_WHAT           IN VARCHAR2,
                                 IS_USER_ACCOUNT   IN VARCHAR2,
                                 IS_INTF_HEADER_ID IN VARCHAR2,
                                 OS_MESSAGE        OUT VARCHAR2 --成功则返回“SUCCESS”，否则返回出错信息
                                 );

  PROCEDURE P_INVALID_HIS_PRE01_PROC(IS_USER_ACCOUNT   IN VARCHAR2,
                                     IS_INVALID_HIS_ID IN VARCHAR2,
                                     OS_MESSAGE        OUT VARCHAR2 --成功则返回“SUCCESS”，否则返回出错信息
                                     );
  /**
  *客户主数据接口超时处理（无响应）
  */
  PROCEDURE P_CUST_INTF_TIMEOUT_HANDLE(IN_BEFORE_DAYS     IN VARCHAR2,
                                      IN_CLEAR_OVER_COUNT IN NUMBER,
                                      IN_BF_MONTHS_CLR    IN NUMBER,
                                      OS_MESSAGE          OUT VARCHAR2 --成功则返回“SUCCESS”，否则返回出错信息
                                      );
  /**
  *客户主数据接口失败处理
  */
  PROCEDURE P_CUST_INTF_FAILURE_HANDLE(OS_MESSAGE OUT VARCHAR2 --成功则返回“SUCCESS”，否则返回出错信息
                                       );

END PKG_CUSTOMER_INTF;
/

