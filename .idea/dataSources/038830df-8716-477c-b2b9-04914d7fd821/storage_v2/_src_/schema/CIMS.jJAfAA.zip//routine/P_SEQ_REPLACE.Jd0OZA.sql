create procedure      p_seq_replace(v_seqname varchar2,v_num in out number)
as
  v_sql1 varchar2(1000);
  v_sql2 varchar2(1000);

begin
  --1删除序列
  v_sql1:='drop sequence  '||v_seqname;
  execute immediate v_sql1;
  --2重新创建序列
  v_sql2:='create sequence  '||v_seqname;
  if v_num is null or v_num = 0 then 
     v_num :=1;
  end if;
  v_sql2:=v_sql2||' minvalue 1 maxvalue 9999999999999999999999999999 start with '||v_num ||' increment by 1 cache 10';

  execute immediate v_sql2;

end p_seq_replace;
/

