create Package Body PKG_INV_REPORT_LBCS Is
  --生成期末库存量
  Procedure INV_REPORT_LBCS_INSERT(p_batch_id     Number, --批次ID
                                   p_inventory_id Number, --仓库
                                   p_end_date     Date, --期末日期
                                   p_user         Varchar2, --创建人
                                   p_return_code  Out Varchar2, --返回代码，OK表示成功，其他表示错误
                                   p_return_msg   Out Varchar2 --返回信息
                                   ) Is
    Pragma Autonomous_Transaction; --自治事务，单独提交而不影响调用它的事务
    v_period_name      varchar2(20);
    v_next_period_name varchar2(20);
    V_entity_id        number;
    V_count            number;
  Begin
    p_return_code := 'OK';
    p_return_msg  := Null;
    select entity_id
      into V_entity_id
      from t_inv_inventories
     where inventory_id = p_inventory_id;
    select count(1)
      into V_count
      from (select period_name, period_id
              from t_inv_inventory_periods
             where entity_id = V_entity_id
               and checkout_flag = 01
               and last_day(begin_date) < last_day(p_end_date)
             order by period_name desc)
     where rowNum < 2;
    if (V_count > 0) then
      select period_name
        into v_period_name
        from (select period_name, period_id
                from t_inv_inventory_periods
               where entity_id = V_entity_id
                 and checkout_flag = 01
                 and last_day(begin_date) < last_day(p_end_date)
               order by period_name desc)
       where rowNum < 2;
    else
      v_period_name := '2000-01';
    end if;
    select to_char(add_months(to_date(v_period_name, 'yyyy/mm'), 1),
                   'yyyy-mm')
      into v_next_period_name
      from dual;
    DBMS_OUTPUT.put_line(v_next_period_name);
    DBMS_OUTPUT.put_line(v_period_name);
    insert into t_inv_onhond_lbcs
      (onhond_id,
       batch_id,
       entity_id,
       inventory_id,
       inventory_code,
       inventory_name,
       item_id,
       item_code,
       item_name,
       transaction_uom,
       quantity,
       count_date,
       created_by,
       creation_date,
       last_updated_by,
       last_update_date,
       remark)
      select S_INV_ONHOND_LBCS.NEXTVAL,
             p_batch_id,
             entity_id,
             inventory_id,
             inventory_code,
             inventory_name,
             item_id,
             item_code,
             item_name,
             UOM,
             quantity,
             p_end_date,
             'LBCS',
             sysdate,
             'LBCS',
             sysdate,
             remark
        from (select tii.entity_id,
                     tim.item_id item_id,
                     tbi.item_name item_name,
                     tbi.item_code item_code,
                     tim.inventory_id inventory_id,
                     tii.inventory_code inventory_code,
                     tii.inventory_name inventory_name,
                     tbi.defaultunit UOM,
                     tim.qty_blnc + nvl(tinv.quantity, 0) quantity,
                     nvl(tbi.last_updated_by, p_user) last_updated_by,
                     nvl(tbi.last_update_date, sysdate) last_update_date,
                     tbi.remark remark
                from t_bd_item tbi,
                     t_inv_monthsum tim,
                     t_inv_inventories tii,
                     (select t.inventory_id,
                             t.item_id,
                             sum(t.transaction_quantity) quantity
                        from T_INV_TRANSACTION_HISTORY t
                       where t.entity_id = V_entity_id
                         and t.TRANSACTION_DATE >=
                             to_date(v_next_period_name || '-1', 'YYYY/MM/DD')
                         and t.TRANSACTION_DATE <= p_end_date
                       group by t.inventory_id, t.item_id) tinv
              
               where tbi.item_id = tim.item_id
                 and tim.inventory_id = tii.inventory_id
                 and tim.item_id = tinv.item_Id(+)
                 and tim.inventory_id = tinv.inventory_id(+)
                 and tim.period_name = v_period_name
                 and tii.inventory_id = p_inventory_id
              union All
              select tii.entity_id,
                     tbi.item_id item_id,
                     tbi.item_name item_name,
                     tbi.item_code item_code,
                     tii.inventory_id inventory_id,
                     tii.inventory_code inventory_code,
                     tii.inventory_name inventory_name,
                     tbi.defaultunit UOM,
                     tinv.quantity quantity,
                     nvl(tbi.last_updated_by, p_user) last_updated_by,
                     nvl(tbi.last_update_date, sysdate) last_update_date,
                     tbi.remark remark
                from (select t.inventory_id,
                             t.item_id,
                             t.entity_id,
                             sum(transaction_quantity) quantity
                        from T_INV_TRANSACTION_HISTORY t
                       where t.entity_id = V_entity_id
                         and t.TRANSACTION_DATE >=
                             to_date(v_next_period_name || '-1', 'YYYY/MM/DD')
                         and t.TRANSACTION_DATE <= p_end_date
                       group by t.inventory_id, t.item_id, t.entity_id) tinv,
                     t_bd_item tbi,
                     t_inv_inventories tii
              
               where tii.inventory_id = tinv.inventory_id
                 and tbi.item_id = tinv.item_id
                 and tinv.item_id not in
                     (select item_id
                        from t_inv_monthsum tim
                       where tim.entity_id = tii.entity_id
                         and tim.inventory_id = tii.inventory_id
                         and tim.period_name = v_period_name)
                 and tii.inventory_id = p_inventory_id);
    commit;
  Exception
    WHEN NO_DATA_FOUND THEN
      p_return_code := 'FAILED';
      p_return_msg  := '仓库不存在';
    When Others Then
      p_return_code := 'FAILED';
      p_return_msg  := '生成期末库存量失败。错误信息：' || Sqlerrm;
  End;

  --删除期末库存量
  Procedure INV_REPORT_LBCS_DELETE(p_batch_id    Number, --批次ID
                                   p_return_code Out Varchar2, --返回代码，OK表示成功，其他表示错误
                                   p_return_msg  Out Varchar2 --返回信息
                                   ) Is
    Pragma Autonomous_Transaction; --自治事务，单独提交而不影响调用它的事务
    v_test varchar2(100);
  Begin
    p_return_code := 'OK';
    p_return_msg  := Null;
    Delete From t_inv_onhond_lbcs Where batch_id = p_batch_id;
    Commit;
  Exception
    When Others Then
      p_return_code := 'FAILED';
      p_return_msg  := '删除期末库存量失败。错误信息：' || Sqlerrm;
  End;
end PKG_INV_REPORT_LBCS;
/

