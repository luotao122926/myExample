create package body PKG_PG_INTF is
  v_Nl Constant Varchar2(2) := Chr(13) || Chr(10); --换行
  v_Success Constant Varchar2(10) := 'SUCCESS';
  
  -- Author  : LZH
  -- Created : 2014/12/30 9:10:40
  -- Purpose : 工程机接口

  ----------------------------------------------------------------------
  -- Author  : LZH
  -- Created : 2014/12/30 9:34:40
  -- Purpose : 商机录入
  ----------------------------------------------------------------------
  Procedure P_BUSINESS_ENTRY(p_Intf_Id In Number, p_Result Out Varchar2) Is Pragma Autonomous_Transaction;
  r_Pg_Business Intf_Pg_Business%Rowtype;
  Cursor c_Pg_Business_Line Is
    Select * From Intf_Pg_Business_Line bl
    Where bl.head_id = p_Intf_Id
    And bl.Intf_Status = 'N';
  r_Pg_Business_Line c_Pg_Business_Line%Rowtype;
  v_Value Varchar2(1024);
  v_Business_Id Number;
  v_Bussiness_Line_Id Number;
  v_Loc_Code Varchar2(30);
  v_Loc_Name Varchar2(50);
  v_Sales_Center_Code Varchar2(100);
  v_Sales_Center_Name Varchar2(100);
  v_Customer_Code Varchar2(100);
  v_Customer_Name Varchar2(300);
  v_Account_Code Varchar2(100);
  v_Project_Center_Code Varchar2(100);
  v_Project_Center_Name Varchar2(100);
  V_APPENDIX_ID VARCHAR2(100);--附件id	
  Begin
    p_Result := v_Success;
    Begin
      v_Value := '锁定商机录入接口头表失败！';
      Select *
      Into r_Pg_Business
      From Intf_Pg_Business h
      Where h.head_id = p_Intf_Id
      And h.Intf_Status = 'N'
      For Update Nowait;
    Exception
      When Others Then
        p_Result := v_Value || v_Nl || Sqlerrm;
    End;

    If p_Result = v_Success Then
      Begin
        v_Value := '项目所在区域检查：';
        Select d.district_code, d.district_name
          Into v_Loc_Code, v_Loc_Name
          From t_Bd_District d
         Where d.row_id = r_Pg_Business.Loc_Id
           And d.active_flag = 'Y';
      Exception
        When Others Then
          p_Result := v_Value || '区域ID：' ||
                      To_Char(r_Pg_Business.Loc_Id) ||
                      '不存在或者区域已失效。';
      End;
    End If;

    If p_Result = v_Success Then
      Begin
        v_Value := '营销中心检查：';
        Select u.Code, u.Name
          Into v_Sales_Center_Code, v_Sales_Center_Name
          From Up_Org_Unit u
         Where u.Unit_Id = r_Pg_Business.Sales_Center_Id
           And u.Active_Flag = 'T';
      Exception
        When Others Then
          p_Result := v_Value || '营销中心ID：' ||
                      To_Char(r_Pg_Business.Sales_Center_Id) ||
                      '不存在或者中心已失效。';
      End;
    End If;

    If p_Result = v_Success Then
      Begin
        v_Value := '经销商检查：';
        Select Ch.Customer_Code, Ch.Customer_Name
          Into v_Customer_Code, v_Customer_Name
          From t_Customer_Header Ch
         Where Ch.Customer_Id = r_Pg_Business.Customer_Id
           And Ch.Active_Flag = 'Active';
      Exception
        When Others Then
          p_Result := v_Value || '经销商ID：' ||
                      To_Char(r_Pg_Business.Customer_Id) ||
                      '不存在或者经销商已失效。';
      End;
    End If;

    If p_Result = v_Success Then
      Begin
        v_Value := '账户检查：';
        Select Ca.Account_Code
          Into v_Account_Code
          From t_Customer_Account Ca
         Where Ca.Account_Id = r_Pg_Business.Account_Id
           And Ca.Active_Flag = 'Active';
      Exception
        When Others Then
          p_Result := v_Value || '账户ID：' ||
                      To_Char(r_Pg_Business.Account_Id) ||
                      '不存在或者账户已失效。';
      End;
    End If;

    If p_Result = v_Success Then
      Begin
        v_Value := '项目所在中心检查：';
        Select Ao.Org_Code, Ao.Org_Name
          Into v_Project_Center_Code, v_Project_Center_Name
          From t_Pg_Area_Org Ao
         Where Ao.Unit_Id = r_Pg_Business.Project_Center_Id;
      Exception
        When Others Then
          p_Result := v_Value || '项目所在中心ID：' ||
                      To_Char(r_Pg_Business.Project_Center_Id) ||
                      '不存在或者未配置。';
      End;
    End If;
 --附件传输
    V_APPENDIX_ID:=NULL;
    PKG_PG_INTF.P_PG_BUSINESS_FILE_TRANSFER(P_INTF_HEAD_ID => P_INTF_ID,V_SUCCESS =>V_SUCCESS,P_MESSAGE =>P_RESULT,V_APPENDIX_ID =>V_APPENDIX_ID )  ;
    If p_Result = v_Success Then
      Select S_PG_BUSINESS.NEXTVAL Into v_Business_Id From Dual;
      Begin
        v_Value := '开始插入商机录入业务头表数据';
      Insert Into T_PG_BUSINESS
      (business_id,           --商机信息ID
       project_code,          --项目编号
       project_name,          --项目名称
       user_firm,             --使用单位名称
       user_phone,            --项目方联系电话
       user_name,             --项目方联系人
       project_address,       --工程项目详细地址
       loc_id,                --区域ID
       loc_code,              --项目所在区域
       loc_name,              --区域编码名称
       project_center_id,     --项目所在中心ID
       project_center_code,   --项目所在中心编码
       project_center_name,   --项目所在中心名称
       customer_id,           --经销商ID
       customer_code,         --经销商编码
       customer_name,         --经销商名称
       sales_center_id,       --营销中心ID
       sales_center_code,     --营销中心编码
       sales_center_name,     --营销中心名称
       account_id,            --账户ID
       account_code,          --账户名称
       agent_id,              --代理商ID
       agent_code,            --代理商编码
       agent_name,            --代理商名称
       project_type,          --工程类型:精装房产配套、公租保障配套、家装橱柜配套、燃气公司合作
       expected_bid_time,     --预计投标时间
       login_time,            --登录日期
       login_ptotect_time,    --登录保护时间
       project_num,           --项目规模
       project_progress,      --项目进度:在建项目、建好未定、准备投标
       business_type,         --商机类型
       delivery_cycle,        --供货周期:单位为天
       buyout_type,           --买断类型:事前买断、时候买断
       customer_person,       --经销商联系人
       customer_person_phone, --联系方式
       area_manager,          --区域经理
       area_manager_phone,    --区域经理电话
       install_flag,          --是否我司安装
       otherlogin_flag,       --是否是异地登录
       status,                --登录状态，有以下几种：已录入、已送审、已审核、已退回、已作废
       competitors,           --工程竞争对手
       special_need,          --特殊要求
       other_desc,            --其他说明资料
       entity_id,             --主体ID
       created_by,            --创建人
       creation_date,         --创建时间
       last_updated_by,       --修改人
       last_update_date,      --修改时间
       send_person,           --送审人
       send_date,             --送审日期
       approval_person,       --审核人
       approval_date,         --审核日期
       back_person,           --退回人
       back_date,             --退回日期
       scrapped_person,       --作废人
       scrapped_date,         --作废时间
       relogin_flag,          --重新登录标识
       bid_status,            --中标状态
       freeze_status,         --冻结状态
       freeze_person,         --冻结人
       freeze_time,           --冻结时间
       unfreeze_person,       --解冻人
       unfreeze_time,         --解冻时间
       is_market_strategy,    --战略大盘采购
       verfication_status,    --核销状态 0未核销 1已核销 2核销失败
       remark,                --备注
       is_groupbuy,           --是否团购
       program_updated_by,    --程序修改来源
       program_update_date    --修改时间
       ,APPENDIX_ID2
       ,big_panel
      )
      Values
      (v_Business_Id,                       --商机信息ID
       r_Pg_Business.Project_Code,          --项目编号
       r_Pg_Business.Project_Name,          --项目名称
       r_Pg_Business.User_Firm,             --使用单位名称
       r_Pg_Business.User_Phone,            --项目方联系电话
       r_Pg_Business.User_Name,             --项目方联系人
       r_Pg_Business.Project_Address,       --工程项目详细地址
       r_Pg_Business.Loc_Id,                --区域ID
       r_Pg_Business.Loc_Code,              --项目所在区域
       r_Pg_Business.Loc_Name,              --区域编码名称
       r_Pg_Business.Project_Center_Id,     --项目所在中心ID
       r_Pg_Business.Project_Center_Code,   --项目所在中心编码
       r_Pg_Business.Project_Center_Name,   --项目所在中心名称
       r_Pg_Business.Customer_Id,           --经销商ID
       r_Pg_Business.Customer_Code,         --经销商编码
       r_Pg_Business.Customer_Name,         --经销商名称
       r_Pg_Business.Sales_Center_Id,       --营销中心ID
       r_Pg_Business.Sales_Center_Name,     --营销中心名称
       r_Pg_Business.Sales_Center_Code,     --营销中心编码
       r_Pg_Business.Account_Id,            --账户ID
       r_Pg_Business.Account_Code,          --账户名称
       r_Pg_Business.Agent_Id,              --代理商ID
       r_Pg_Business.Agent_Code,            --代理商编码
       r_Pg_Business.Agent_Name,            --代理商名称
       r_Pg_Business.Project_Type,          --工程类型:精装房产配套、公租保障配套、家装橱柜配套、燃气公司合作
       r_Pg_Business.Expected_Bid_Time,     --预计投标时间
       sysdate,                             --登录日期
       add_months(sysdate-1, 3),            --登录保护时间
       r_Pg_Business.Project_Num,           --项目规模
       r_Pg_Business.Project_Progress,      --项目进度:在建项目、建好未定、准备投标
       r_Pg_Business.Business_Type,         --商机类型
       r_Pg_Business.Delivery_Cycle,        --供货周期:单位为天
       r_Pg_Business.Buyout_Type,           --买断类型:事前买断、时候买断
       r_Pg_Business.Customer_Person,       --经销商联系人
       r_Pg_Business.Customer_Person_Phone, --联系方式
       r_Pg_Business.Area_Manager,          --区域经理
       r_Pg_Business.Area_Manager_Phone,    --区域经理电话
       r_Pg_Business.Install_Flag,          --是否我司安装
       r_Pg_Business.Otherlogin_Flag,       --是否是异地登录
       '2',                                 --登录状态:已审核
       r_Pg_Business.Competitors,           --工程竞争对手
       r_Pg_Business.Special_Need,          --特殊要求
       r_Pg_Business.Other_Desc,            --其他说明资料
       r_Pg_Business.Entity_Id,             --主体ID
       r_Pg_Business.Created_By,            --创建人
       r_Pg_Business.Creation_Date,         --创建时间
       r_Pg_Business.Last_Updated_By,       --修改人
       r_Pg_Business.Last_Update_Date,      --修改时间
       r_Pg_Business.Send_Person,           --送审人
       r_Pg_Business.Send_Date,             --送审日期
       r_Pg_Business.Approval_Person,       --审核人
       r_Pg_Business.Approval_Date,         --审核日期
       r_Pg_Business.Back_Person,           --退回人
       r_Pg_Business.Back_Date,             --退回日期
       r_Pg_Business.Scrapped_Person,       --作废人
       r_Pg_Business.Scrapped_Date,         --作废时间
       r_Pg_Business.Relogin_Flag,          --重新登录标识
       r_Pg_Business.Bid_Status,            --中标状态
       r_Pg_Business.Freeze_Status,         --冻结状态
       r_Pg_Business.Freeze_Person,         --冻结人
       r_Pg_Business.Freeze_Time,           --冻结时间
       r_Pg_Business.Unfreeze_Person,       --解冻人
       r_Pg_Business.Unfreeze_Time,         --解冻时间
       r_Pg_Business.Is_Market_Strategy,    --战略大盘采购
       r_Pg_Business.Verfication_Status,    --核销状态 0未核销 1已核销 2核销失败
       r_Pg_Business.Remark,                --备注
       r_Pg_Business.Is_Groupbuy,           --是否团购
       r_Pg_Business.Program_Updated_By,    --程序修改来源
       r_Pg_Business.Program_Update_Date    --修改时间
	, V_APPENDIX_ID--附件
  ,r_Pg_Business.Big_Panel
       );
    Exception
      When Others Then
        p_Result := v_Value || '，失败。' || v_Nl || Sqlerrm;
      End;
    End If;

    If p_Result = v_Success Then
      Open c_Pg_Business_Line;
      Loop
        Fetch c_Pg_Business_Line
          Into r_Pg_Business_Line;
        Exit When c_Pg_Business_Line%Notfound Or p_Result <> v_Success;
        If p_Result = v_Success Then
          Select S_PG_BUSINESS_LINE.NEXTVAL Into v_Bussiness_Line_Id From Dual;
          Begin
            v_Value := '开始插入商机录入业务行表数据';
            Insert Into T_PG_BUSINESS_LINE
            (bussiness_line_id,    --商机商品行信息ID
             business_id,          --商机信息ID
             sales_main_type,      --营销大类编码
             sales_main_type_name, --营销大类名称
             sales_sub_type,       --营销小类编码
             sales_sub_type_name,  --营销小类名称
             item_id,              --产品ID
             item_code,            --产品编码
             item_desc,            --产品型号
             uom_code,             --单位
             common_price,         --直供价
             requis_price,         --预计报价
             requis_qty,           --申请数量
             created_by,           --创建人
             creation_date,        --创建时间
             last_updated_by,      --修改人
             last_update_date,     --修改时间
             entity_id             --主体ID
            )
            Values
            (v_Bussiness_Line_Id,                     --商机商品行信息ID
             v_Business_Id,                           --商机信息ID
             r_Pg_Business_Line.Sales_Main_Type,      --营销大类编码
             r_Pg_Business_Line.Sales_Main_Type_Name, --营销大类名称
             r_Pg_Business_Line.Sales_Sub_Type,       --营销小类编码
             r_Pg_Business_Line.Sales_Sub_Type_Name,  --营销小类名称
             r_Pg_Business_Line.Item_Id,              --产品ID
             r_Pg_Business_Line.Item_Code,            --产品编码
             r_Pg_Business_Line.Item_Desc,            --产品型号
             r_Pg_Business_Line.Uom_Code,             --单位
             r_Pg_Business_Line.Common_Price,         --直供价
             r_Pg_Business_Line.Requis_Price,         --预计报价
             r_Pg_Business_Line.Requis_Qty,           --申请数量
             r_Pg_Business_Line.Created_By,           --创建人
             r_Pg_Business_Line.Creation_Date,        --创建时间
             r_Pg_Business_Line.Last_Updated_By,      --修改人
             r_Pg_Business_Line.Last_Update_Date,     --修改时间
             r_Pg_Business_Line.Entity_Id             --主体ID
            );
          Exception
            When Others Then
              p_Result := v_Value || '失败。' || v_Nl || Sqlerrm;
          End;
        End If;
        If p_Result <> v_Success Then
          Rollback;
          Update INTF_PG_BUSINESS_LINE bl
             Set bl.Intf_Err_Msg = p_Result, bl.Intf_Status = 'E', bl.intf_date = sysdate
           Where bl.line_id = r_Pg_Business_Line.Line_Id;

          Update INTF_PG_BUSINESS bh
             Set bh.Intf_Err_Msg = p_Result, bh.Intf_Status = 'E', bh.intf_date = sysdate
           Where bh.head_id = r_Pg_Business.Head_Id;
          Commit;
        else
          Update INTF_PG_BUSINESS bh
             Set bh.business_id = v_Business_Id, bh.intf_status = 'Y',
                 bh.intf_err_msg = Null, bh.intf_date = sysdate
           Where bh.head_id = r_Pg_Business.Head_Id;
          Update INTF_PG_BUSINESS_LINE bl
             Set bl.Intf_Status = 'Y', bl.business_id = v_Business_Id, bl.intf_date = sysdate,
                 bl.bussiness_line_id = v_Bussiness_Line_Id, bl.intf_err_msg = Null
           Where bl.line_id = r_Pg_Business_Line.Line_Id;
          Commit;
        End If;
      End Loop;
    End If;
  Exception
    When Others Then
      Rollback;
      p_Result := '失败：' || p_Result || v_Nl || Sqlerrm;
  End;

  ----------------------------------------------------------------------
  -- Author  : LZH
  -- Created : 2015/01/06 9:39:40
  -- Purpose : 产品定制
  ----------------------------------------------------------------------
  Procedure P_PRODUCT_CUSTOMIZE(p_Intf_Id In Number, p_Result Out Varchar2) Is Pragma Autonomous_Transaction;
  r_Pg_Customize Intf_Pg_Customize%Rowtype;
  Cursor c_Pg_Customize_Line Is
    Select * From Intf_Pg_Customize_Line cl
    Where cl.head_id = p_Intf_Id
    And cl.Intf_Status = 'N';
  r_Pg_Customize_Line c_Pg_Customize_Line%Rowtype;
  v_Value Varchar2(1024);
  v_Customize_Id Number;
  v_Customize_Line_Id Number;
  v_Business_Id Number;
  v_Project_Name Varchar2(100);
  v_Project_Address Varchar2(200);
  v_Loc_Name Varchar2(100);
  Begin
    p_Result := v_Success;
    Begin
      v_Value := '锁定产品定制接口头表失败！';
      Select *
      Into r_Pg_Customize
      From Intf_Pg_Customize h
      Where h.head_id = p_Intf_Id
      And h.Intf_Status = 'N'
      For Update Nowait;
    Exception
      When Others Then
        p_Result := v_Value || v_Nl || Sqlerrm;
    End;

    If p_Result = v_Success Then
      --检查商机信息
      Begin
        v_Value := '商机信息检查：';
        Select b.business_id
          Into v_Business_Id
          From t_Pg_Business b
         Where b.business_id = r_Pg_Customize.Business_Id;
      Exception
        When Others Then
          p_Result := v_Value || '商机信息ID：' ||
                      To_Char(r_Pg_Customize.Business_Id) ||
                      '不存在或者商机信息已失效。';
      End;
    End If;

    If p_Result = v_Success Then
      Begin
        v_Value := '项目名称检查：';
        Select b.project_name, b.project_address
          Into v_Project_Name, v_Project_Address
          From t_Pg_Business b
         Where b.project_name = r_Pg_Customize.Project_Name
           And b.project_address = r_Pg_Customize.Project_Address and nvl(b.document_type,'0') in ('0','2');
      Exception
        When Others Then
          p_Result := v_Value || '项目名称：' ||
                      To_Char(r_Pg_Customize.Project_Name) ||
                      '不存在！';
      End;
    End If;

    If p_Result = v_Success Then
      Begin
        v_Value := '定制数量检查：';
        If r_Pg_Customize_Line.Customize_Qty < 0 or r_Pg_Customize_Line.Customize_Qty = 0 Then

           p_Result := v_Value || '定制数量：' ||
                      To_Char(r_Pg_Customize_Line.Customize_Qty) ||
                    '未大于0！';
        end if;
      End;
    End If;

    If p_Result = v_Success Then
      Begin
        v_Value := '项目所在区域检查：';
        Select d.district_name
          Into v_Loc_Name
          From t_Bd_District d
         Where d.row_id = r_Pg_Customize.Loc_Id;
      Exception
        When Others Then
          p_Result := v_Value || '所在区域ID：' ||
                      To_Char(r_Pg_Customize.Loc_Id) ||
                      '不存在！';
      End;
    End If;

    If p_Result = v_Success Then
      Select S_PG_CUSTOMIZE.NEXTVAL Into v_Customize_Id From Dual;
      Begin
        v_Value := '开始插入产品定制业务头表数据';
      Insert Into T_PG_CUSTOMIZE
      (customize_id,          --定制申请ID
       business_id,           --商机信息ID
       customize_code,        --定制申请编号
       loc_id,                --所在区域ID
       loc_name,              --所在区域名称
       sales_sub_type,        --营销小类ID
       sales_sub_type_name,   --营销小类名称
       customer_id,           --客户ID
       customer_name,         --客户名称
       account_id,            --账户ID
       account_name,          --账户名称
       project_name,          --项目名称
       project_address,       --详细安装地址
       customer_person,       --联系人
       customer_person_pnone, --联系电话
       login_flag,            --是否登录标识
       status,                --00：已录入 01：已送审 02：已审核 03：已退回 04：已作废
       check_info,            --审核信息
       apply_time,            --申请日期
       apply_id,              --申请人ID
       apply_name,            --申请人姓名
       created_by,            --创建人
       creation_date,         --创建时间
       last_update_date,      --修改时间
       last_updated_by,       --修改人
       entity_id,             --主体ID
       customer_code,         --客户编码
       sales_main_type,       --营销大类编码
       sales_main_type_name   --营销大类名称
      )
      Values
      (v_Customize_Id,                       --定制申请ID
       v_Business_Id,                        --商机信息ID
       r_Pg_Customize.Customize_Code,        --定制申请编号
       r_Pg_Customize.Loc_Id,                --所在区域ID
       r_Pg_Customize.Loc_Name,              --所在区域名称
       r_Pg_Customize.Sales_Sub_Type,        --营销小类ID
       r_Pg_Customize.Sales_Sub_Type_Name,   --营销小类名称
       r_Pg_Customize.Customer_Id,           --客户ID
       r_Pg_Customize.Customer_Name,         --客户名称
       r_Pg_Customize.Account_Id,            --账户ID
       r_Pg_Customize.Account_Name,          --账户名称
       r_Pg_Customize.Project_Name,          --项目名称
       r_Pg_Customize.Project_Address,       --详细安装地址
       r_Pg_Customize.Customer_Person,       --联系人
       r_Pg_Customize.Customer_Person_Pnone, --联系电话
       r_Pg_Customize.Login_Flag,            --是否登录标识
       r_Pg_Customize.Status,                --00：已录入 01：已送审 02：已审核 03：已退回 04：已作废
       r_Pg_Customize.Check_Info,            --审核信息
       r_Pg_Customize.Apply_Time,            --申请日期
       r_Pg_Customize.Apply_Id,              --申请人ID
       r_Pg_Customize.Apply_Name,            --申请人姓名
       r_Pg_Customize.Created_By,            --创建人
       r_Pg_Customize.Creation_Date,         --创建时间
       r_Pg_Customize.Last_Update_Date,      --修改时间
       r_Pg_Customize.Last_Updated_By,       --修改人
       r_Pg_Customize.Entity_Id,             --主体ID
       r_Pg_Customize.Customize_Code,        --客户编码
       r_Pg_Customize.Sales_Main_Type,       --营销大类编码
       r_Pg_Customize.Sales_Main_Type_Name   --营销大类名称
       );
    Exception
      When Others Then
        p_Result := v_Value || '，失败。' || v_Nl || Sqlerrm;
      End;
    End If;

    If p_Result = v_Success Then
      Open c_Pg_Customize_Line;
      Loop
        Fetch c_Pg_Customize_Line
          Into r_Pg_Customize_Line;
        Exit When c_Pg_Customize_Line%Notfound Or p_Result <> v_Success;
        If p_Result = v_Success Then
          Select S_PG_CUSTOMIZE_LINE.NEXTVAL Into v_Customize_Line_Id From Dual;
          Begin
            v_Value := '开始插入产品定制业务行表数据';
            Insert Into T_PG_CUSTOMIZE_LINE
            (customize_line_id,     --定制产品行ID
             customize_id,          --定制申请ID
             item_id,               --产品ID
             item_code,             --产品编码
             item_desc,             --产品型号
             customize_qty,         --定制数量
             customize_need,        --定制要求
             delivery_time,         --提货日期
             factory_complete_time, --工厂回复完成日期
             creation_date,         --创建时间
             last_update_date,      --修改时间
             last_updated_by,       --修改人
             created_by,            --创建人
             entity_id              --主体ID
            )
            Values
            (v_Customize_Line_Id,                       --定制产品行ID
             v_Customize_Id,                            --定制申请ID
             r_Pg_Customize_Line.Item_Id,               --产品ID
             r_Pg_Customize_Line.Item_Code,             --产品编码
             r_Pg_Customize_Line.Item_Desc,             --产品型号
             r_Pg_Customize_Line.Customize_Qty,         --定制数量
             r_Pg_Customize_Line.Customize_Need,        --定制要求
             r_Pg_Customize_Line.Delivery_Time,         --提货日期
             r_Pg_Customize_Line.Factory_Complete_Time, --工厂回复完成日期
             r_Pg_Customize_Line.Creation_Date,         --创建时间
             r_Pg_Customize_Line.Last_Update_Date,      --修改时间
             r_Pg_Customize_Line.Last_Updated_By,       --修改人
             r_Pg_Customize_Line.Created_By,            --创建人
             r_Pg_Customize_Line.Entity_Id              --主体ID
            );
          Exception
            When Others Then
              p_Result := v_Value || '失败。' || v_Nl || Sqlerrm;
          End;
        End If;
        If p_Result <> v_Success Then
          Rollback;
          Update INTF_PG_CUSTOMIZE_LINE cl
             Set cl.Intf_Err_Msg = p_Result, cl.Intf_Status = 'E', cl.intf_date = sysdate
           Where cl.line_id = r_Pg_Customize_Line.Line_Id;

          Update INTF_PG_CUSTOMIZE ch
             Set ch.Intf_Err_Msg = p_Result, ch.Intf_Status = 'E', ch.intf_date = sysdate
           Where ch.head_id = r_Pg_Customize.Head_Id;
          Commit;
        else
          Update INTF_PG_CUSTOMIZE ch
             Set ch.customize_id = v_Customize_Id, ch.intf_status = 'Y',
                 ch.intf_err_msg = Null, ch.intf_date = sysdate
           Where ch.head_id = r_Pg_Customize.Head_Id;
          Update INTF_PG_CUSTOMIZE_LINE cl
             Set cl.Intf_Status = 'Y', cl.customize_id = v_Customize_Id, cl.intf_date = sysdate,
                 cl.customize_line_id = v_Customize_Line_Id, cl.intf_err_msg = Null
           Where cl.line_id = r_Pg_Customize_Line.Line_Id;
          Commit;
        End If;
      End Loop;
    End If;
  Exception
    When Others Then
      Rollback;
      p_Result := '失败：' || p_Result || v_Nl || Sqlerrm;
  End;

  ----------------------------------------------------------------------
  -- Author  : LZH
  -- Created : 2015/01/16 14:14:40
  -- Purpose : 价格申请
  ----------------------------------------------------------------------
  Procedure P_PRICE_APPLY(p_Intf_Id In Number, p_Result Out Varchar2) Is Pragma Autonomous_Transaction;
  r_Bd_Price_Apply Intf_Bd_Price_Apply%Rowtype;
  Cursor c_Bd_Price_Apply_Line Is
    Select * From Intf_Bd_Price_Apply_Line pl
    Where pl.head_id = p_Intf_Id
    And pl.Intf_Status = 'N';
  r_Bd_Price_Apply_Line c_Bd_Price_Apply_Line%Rowtype;
  v_Value Varchar2(1024);
  v_Price_Apply_Id Number;
  v_Apply_Detail_Id Number;
  v_Project_Code Varchar2(32);
  v_Center_Code  Varchar2(32);
  v_Center_Name  Varchar2(100);
  v_Customer_Code Varchar2(100);
  v_Customer_Name Varchar2(300);
  v_Item_Code Varchar2(100);
  v_Item_Name Varchar2(240);
  Begin
    p_Result := v_Success;
    Begin
      v_Value := '锁定价格申请接口头表失败！';
      Select *
      Into r_Bd_Price_Apply
      From Intf_Bd_Price_Apply h
      Where h.head_id = p_Intf_Id
      And h.Intf_Status = 'N'
      For Update Nowait;
    Exception
      When Others Then
        p_Result := v_Value || v_Nl || Sqlerrm;
    End;

    If p_Result = v_Success Then
      Begin
        v_Value := '项目编码检查：';
        Select b.Project_Code
          Into v_Project_Code
          From t_Pg_Business b
         Where b.project_code = r_Bd_Price_Apply.Project_Code
           And b.status = '2'
           And b.verfication_status = '0';
      Exception
        When Others Then
          p_Result := v_Value || '项目编码：' ||
                      To_Char(r_Bd_Price_Apply.Project_Code) ||
                      '不存在或者不是已评审未核销';
      End;
    End If;

    If p_Result = v_Success Then
      Begin
        v_Value := '行表营销中心检查：';
        Select u.Code, u.Name
          Into v_Center_Code, v_Center_Name
          From Up_Org_Unit u
         Where u.Unit_Id = r_Bd_Price_Apply_Line.Center_Id
           And u.Active_Flag = 'T';
      Exception
        When Others Then
          p_Result := v_Value || '营销中心ID：' ||
                      To_Char(r_Bd_Price_Apply_Line.Center_Id) ||
                      '不存在或者中心已失效。';
      End;
    End If;

    If p_Result = v_Success Then
      Begin
        v_Value := '行表客户检查：';
        Select Ch.Customer_Code, Ch.Customer_Name
          Into v_Customer_Code, v_Customer_Name
          From t_Customer_Header Ch
         Where Ch.Customer_Id = r_Bd_Price_Apply_Line.Customer_Id
           And Ch.Active_Flag = 'Active';
      Exception
        When Others Then
          p_Result := v_Value || '客户ID：' ||
                      To_Char(r_Bd_Price_Apply_Line.Customer_Id) ||
                      '不存在或者客户已失效。';
      End;
    End If;

    If p_Result = v_Success Then
      Begin
        v_Value := '行表产品检查：';
        Select Bi.Item_Code, Bi.Item_Name
          Into v_Item_Code, v_Item_Name
          From t_Bd_Item Bi
         Where Bi.Item_Id = r_Bd_Price_Apply_Line.Item_Id
           And Bi.Active_Flag = 'Y';
      Exception
        When Others Then
          p_Result := v_Value || '客户ID：' ||
                      To_Char(r_Bd_Price_Apply_Line.Item_Id) ||
                      '不存在或者产品已失效。';
      End;
    End If;

    If p_Result = v_Success Then
      Select SEQ_BD_ROW_ID.NEXTVAL Into v_Price_Apply_Id From Dual;
      Begin
        v_Value := '开始插入价格申请业务头表数据';
      Insert Into T_BD_PRICE_APPLY
      (price_apply_id,        --主键ID
       apply_code,            --申请编码
       apply_status,          --申请状态
       apply_date,            --申请日期
       apply_person,          --申请人
       apply_type,            --申请类型：如限量批文，工程机批文
       lock_flag,             --是否锁定
       project_flag,          --是否工程机
       tuan_flag,             --是否团购
       project_id,            --项目ID
       project_code,          --项目编码
       customer_id,           --客户ID
       customer_code,         --客户编码
       customer_account_id,   --账户ID
       customer_account_code, --账户编码
       begin_date,            --启用日期
       end_date,              --停用日期
       created_by,            --创建人
       creation_date,         --创建时间
       last_updated_by,       --修改人
       last_update_date,      --修改时间
       remark,                --备注
       entity_id,             --主体ID
       doc_status             --文档状态
      )
      Values
      (v_Price_Apply_Id,                       --主键ID
       r_Bd_Price_Apply.Apply_Code,            --申请编码
       r_Bd_Price_Apply.Apply_Status,          --申请状态
       r_Bd_Price_Apply.Apply_Date,            --申请日期
       r_Bd_Price_Apply.Apply_Person,          --申请人
       r_Bd_Price_Apply.Apply_Type,            --申请类型：如限量批文，工程机批文
       r_Bd_Price_Apply.Lock_Flag,             --是否锁定
       r_Bd_Price_Apply.Project_Flag,          --是否工程机
       r_Bd_Price_Apply.Tuan_Flag,             --是否团购
       r_Bd_Price_Apply.Project_Id,            --项目ID
       v_Project_Code,                         --项目编码
       r_Bd_Price_Apply.Customer_Id,           --客户ID
       r_Bd_Price_Apply.Customer_Code,         --客户编码
       r_Bd_Price_Apply.Customer_Account_Id,   --账户ID
       r_Bd_Price_Apply.Customer_Account_Code, --账户编码
       r_Bd_Price_Apply.Begin_Date,            --启用日期
       r_Bd_Price_Apply.End_Date,              --停用日期
       r_Bd_Price_Apply.Created_By,            --创建人
       r_Bd_Price_Apply.Creation_Date,         --创建时间
       r_Bd_Price_Apply.Last_Updated_By,       --修改人
       r_Bd_Price_Apply.Last_Update_Date,      --修改时间
       r_Bd_Price_Apply.Remark,                --备注
       r_Bd_Price_Apply.Entity_Id,             --主体ID
       r_Bd_Price_Apply.Doc_Status             --文档状态
       );
    Exception
      When Others Then
        p_Result := v_Value || '，失败。' || v_Nl || Sqlerrm;
      End;
    End If;

    If p_Result = v_Success Then
      Open c_Bd_Price_Apply_Line;
      Loop
        Fetch c_Bd_Price_Apply_Line
          Into r_Bd_Price_Apply_Line;
        Exit When c_Bd_Price_Apply_Line%Notfound Or p_Result <> v_Success;
        If p_Result = v_Success Then
          Select SEQ_BD_ROW_ID.NEXTVAL Into v_Apply_Detail_Id From Dual;
          Begin
            v_Value := '开始插入价格申请业务行表数据';
            Insert Into T_BD_PRICE_APPLY_DETAIL
            (apply_detail_id,  --主键ID
             price_apply_id,   --特价申请ID
             region_id,        --区域ID
             region_code,      --区域编码
             region_name,      --区域名称
             center_id,        --中心ID
             center_code,      --中心编码
             center_name,      --中心名称
             customer_model,   --客户类型
             customer_id,      --客户ID
             customer_code,    --客户编码
             item_code,        --产品编码
             item_name,        --产品名称
             buyout_flag,      --买断标志
             list_price,       --开单价
             apply_price,      --申请价
             discount,         --折扣
             apply_cnt,        --申请数量
             use_start_cnt,    --起始数量
             gross_rate,       --毛利率
             used_cnt,         --已提货数量
             lock_cnt,         --锁定数量
             begin_date,       --启用日期
             end_date,         --停用日期
             created_by,       --创建人
             creation_date,    --创建时间
             last_updated_by,  --修改人
             last_update_date, --修改时间
             remark,           --备注
             entity_id,        --主体ID
             item_id,          --产品ID
             item_uom,         --产品单位
             customer_name,    --客户名称
             contract_price,   --合同价
             submit_price,     --提交申请价
             submit_cnt,       --提交申请数量
             verification_cnt  --核销数量
            )
            Values
            (v_Apply_Detail_Id,                      --主键ID
             v_Price_Apply_Id,                       --特价申请ID
             r_Bd_Price_Apply_Line.Region_Id,        --区域ID
             r_Bd_Price_Apply_Line.Region_Code,      --区域编码
             r_Bd_Price_Apply_Line.Region_Name,      --区域名称
             r_Bd_Price_Apply_Line.Center_Id,        --中心ID
             r_Bd_Price_Apply_Line.Center_Code,      --中心编码
             r_Bd_Price_Apply_Line.Center_Name,      --中心名称
             r_Bd_Price_Apply_Line.Customer_Model,   --客户类型
             r_Bd_Price_Apply_Line.Customer_Id,      --客户ID
             r_Bd_Price_Apply_Line.Customer_Code,    --客户编码
             r_Bd_Price_Apply_Line.Item_Code,        --产品编码
             r_Bd_Price_Apply_Line.Item_Name,        --产品名称
             r_Bd_Price_Apply_Line.Buyout_Flag,      --买断标志
             r_Bd_Price_Apply_Line.List_Price,       --开单价
             r_Bd_Price_Apply_Line.Apply_Price,      --申请价
             r_Bd_Price_Apply_Line.Discount,         --折扣
             r_Bd_Price_Apply_Line.Apply_Cnt,        --申请数量
             r_Bd_Price_Apply_Line.Use_Start_Cnt,    --起始数量
             r_Bd_Price_Apply_Line.Gross_Rate,       --毛利率
             r_Bd_Price_Apply_Line.Used_Cnt,         --已提货数量
             r_Bd_Price_Apply_Line.Lock_Cnt,         --锁定数量
             r_Bd_Price_Apply_Line.Begin_Date,       --启用日期
             r_Bd_Price_Apply_Line.End_Date,         --停用日期
             r_Bd_Price_Apply_Line.Created_By,       --创建人
             r_Bd_Price_Apply_Line.Creation_Date,    --创建时间
             r_Bd_Price_Apply_Line.Last_Updated_By,  --修改人
             r_Bd_Price_Apply_Line.Last_Update_Date, --修改时间
             r_Bd_Price_Apply_Line.Remark,           --备注
             r_Bd_Price_Apply_Line.Entity_Id,        --主体ID
             r_Bd_Price_Apply_Line.Item_Id,          --产品ID
             r_Bd_Price_Apply_Line.Item_Uom,         --产品单位
             r_Bd_Price_Apply_Line.Customer_Name,    --客户名称
             r_Bd_Price_Apply_Line.Contract_Price,   --合同价
             r_Bd_Price_Apply_Line.Submit_Price,     --提交申请价
             r_Bd_Price_Apply_Line.Submit_Cnt,       --提交申请数量
             r_Bd_Price_Apply_Line.Verification_Cnt  --核销数量
            );
          Exception
            When Others Then
              p_Result := v_Value || '失败。' || v_Nl || Sqlerrm;
          End;
        End If;
        If p_Result <> v_Success Then
          Rollback;
          Update INTF_BD_PRICE_APPLY_LINE pl
             Set pl.Intf_Err_Msg = p_Result, pl.Intf_Status = 'E', pl.intf_date = sysdate
           Where pl.line_id = r_Bd_Price_Apply_Line.Line_Id;

          Update INTF_BD_PRICE_APPLY ph
             Set ph.Intf_Err_Msg = p_Result, ph.Intf_Status = 'E', ph.intf_date = sysdate
           Where ph.head_id = r_Bd_Price_Apply.Head_Id;
          Commit;
        else
          Update INTF_BD_PRICE_APPLY ph
             Set ph.price_apply_id = v_Price_Apply_Id, ph.intf_status = 'Y',
                 ph.intf_err_msg = Null, ph.intf_date = sysdate
           Where ph.head_id = r_Bd_Price_Apply.Head_Id;
          Update INTF_BD_PRICE_APPLY_LINE pl
             Set pl.Intf_Status = 'Y', pl.price_apply_id = v_Price_Apply_Id, pl.intf_date = sysdate,
                 pl.apply_detail_id = v_Apply_Detail_Id, pl.intf_err_msg = Null
           Where pl.line_id = r_Bd_Price_Apply_Line.Line_Id;
          Commit;
        End If;
      End Loop;
    End If;
  Exception
    When Others Then
      Rollback;
      p_Result := '失败：' || p_Result || v_Nl || Sqlerrm;
  End;

    ----------------------------------------------------------------------
  -- Author  : LZH
  -- Created : 2015/01/20 17:41:40
  -- Purpose : 授权申请
  ----------------------------------------------------------------------
  Procedure P_AUTHORIZATION_APPLY(p_intf_authorization_id In Number, p_Result Out Varchar2) Is Pragma Autonomous_Transaction;
  r_Pg_Authorization Intf_Pg_Authorization%Rowtype;
  r_Pg_BUSINESS T_PG_BUSINESS%Rowtype;
  v_Value                     Varchar2(1024);
  v_Authorization_Id          Number;
  v_Project_Code              Varchar2(32);
  v_Project_Name              Varchar2(32);
  v_authorization_code        Varchar2(32);
  Begin
      p_Result := v_Success;
    Begin
      v_Value := '锁定授权申请接口头表失败！';
      Select h.*
        Into r_Pg_Authorization
        From Intf_Pg_Authorization h
       Where h.intf_authorization_id = p_intf_authorization_id
         And h.Intf_Status = 'N'
         For Update Nowait;
    Exception
      When Others Then
      p_Result := v_Value || v_Nl || Sqlerrm;
    End;

    If p_Result = v_Success Then
      Begin
        v_Value := '项目编码检查：';
        --根据上级商机信息ID获取项目信息
        Select b.Project_Code
          Into v_Project_Code
          From t_Pg_Business b
         Where b.BUSINESS_ID = r_Pg_Authorization.ORI_BUSINESS_ID;
           --   如果没有，则检查老系统
      Exception
          When Others Then
          --20171219 hejy3 屏蔽老IMS同义词
          /*begin
          select t.Project_Code
            into v_Project_Code
            from IMS_PG_LOGIN_IMS t
           where t.head_id = r_Pg_Authorization.ORI_BUSINESS_ID;
            --   如果有，调用上级商机同步接口自动同步 (IMS_PG_LOGIN_IMS   V_PG_LOGIN_IMS  商机表   )
          exception
             when others then*/
            --没有返回错误信息
             p_Result := v_Value || '项目编码：' ||  To_Char(r_Pg_Authorization.ORI_BUSINESS_ID) ||   '不存在！';
          --end;
      End;
    End If;

    If p_Result = v_Success Then
      Select S_PG_AUTHORIZATION.NEXTVAL Into v_Authorization_Id From Dual;
      Begin
        --根据上级商机信息ID获取营销中心信息
         select b.*
         into r_Pg_BUSINESS
         from t_pg_business  b
         Where b.BUSINESS_ID = r_Pg_Authorization.ORI_BUSINESS_ID;

         --授权书编码  --编码为tpgAuthCode的系统参数没找到
        pkg_bd.P_GET_BILL_NO('tpgAuthCode', null,r_Pg_Authorization.Entity_Id,null,v_authorization_code);


        v_Value := '开始插入授权申请业务头表数据';
        Insert Into T_PG_AUTHORIZATION(
                                       authorization_id, ----授权书ID,
                                       business_id, ----商机信息ID,
                                       authorization_code, ----授权书编码,
                                       project_code, ----项目编码,
                                       project_name, ----项目名称,
                                       bid_code, ----标书编号,
                                       bid_firm_name, ----招标单位名称,
                                       apply_time, ----申请日期,
                                       authoriz_firm, ----授权单位名称,
                                       authorization_desc, ----授权书描述,
                                       status, ----00：已录入01：已送审02：已审核03：已退回04：已作废,
                                       created_by, ----创建人,
                                       creation_date, ----创建时间,
                                       last_update_date, ----修改时间,
                                       last_updated_by, ----修改人,
                                       entity_id, ----主体ID,
                                       version, ----乐观锁,
                                       sales_center_id, ----营销中心ID,
                                       sales_center_name, ----营销中心名称,
                                       sales_center_code)
                                 Values(
                                       v_Authorization_Id, --授权书ID
                                       r_Pg_Authorization.Business_Id, --商机信息ID
                                       v_authorization_code, --授权书编码
                                       r_Pg_Authorization.Project_Code, --项目编码
                                       r_Pg_Authorization.Project_Name, --项目名称
                                       r_Pg_Authorization.Bid_Code, --标书编号
                                       r_Pg_Authorization.Bid_Firm_Name, --招标单位名称
                                       r_Pg_Authorization.Apply_Time, --申请日期
                                       r_Pg_Authorization.Authoriz_Firm, --授权单位名称
                                       r_Pg_Authorization.Authorization_Desc, --授权书描述
                                       r_Pg_Authorization.INTF_RESULT, ---处理结果（成功或者失败的原因）
                                       'admin',
                                       sysdate,
                                       sysdate,
                                       'admin',
                                       r_Pg_Authorization.Entity_Id,             --主体ID
                                       '1',                                   --默认值
                                       r_Pg_BUSINESS.sales_center_id,
                                       r_Pg_BUSINESS.sales_center_name,
                                       r_Pg_BUSINESS.sales_center_code);


    Exception
      When Others Then
        p_Result := v_Value || '，失败。' || v_Nl || Sqlerrm;
      End;
    End If;

    If p_Result = v_Success Then
          Begin
               v_Value := '开始插入MDP平台附件同步接口表数据';
          insert  into IMS_FILEINFO_INTERFACE(
                                              id,
                                              business_id,
                                              business_type,
                                              file_path,
                                              file_name,
                                              created_date,
                                              exc_date,
                                              exc_finish,
                                              fcount,
                                              remark)
                                              --origin)
                                     select   S_IMS_FILEINFO_INTERFACE.NEXTVAL,  --授权书资料行ID
                                              r_Pg_Authorization.Business_Id,
                                              'AutLineFile',
                                              al.file_path,
                                              al.File_Name,
                                              sysdate,
                                              '',
                                              '',
                                              '',
                                              al.REMARK
                                            --  'CSS'
                                        from   Intf_Pg_Authorization_Line al
                                        where  al.intf_authorization_line_id = p_intf_authorization_id
                                        And    al.Intf_Status = 'N';

          Exception
            When Others Then
              p_Result := v_Value || '失败。' || v_Nl || Sqlerrm;
          End;

      --同步后，修改‘处理状态’和‘处理结果’字段
        If p_Result <> v_Success Then
          Rollback;
          Update INTF_PG_AUTHORIZATION ah
             Set ah.INTF_RESULT = p_Result, ah.Intf_Status = 'E'
           Where ah.AUTHORIZATION_ID = r_Pg_Authorization.AUTHORIZATION_ID;
       --   Commit;
        else
          Update INTF_PG_AUTHORIZATION ah
             Set ah.authorization_id = v_Authorization_Id, ah.intf_status = 'S',
                 ah.INTF_RESULT = 'SUCCESS'
           Where ah.AUTHORIZATION_ID = r_Pg_Authorization.AUTHORIZATION_ID;
        --  Commit;
        End If;

    End If;
  Exception
    When Others Then
      Rollback;
      p_Result := '失败：' || p_Result || v_Nl || Sqlerrm;
  End;



----------------------------------------------------------------------
  -- Author  : ZWL
  -- Created : 2015/7/22 10:48:52
  -- Purpose : 中标信息循环调用方法
  -----------------------------------------------------------------------
  /*
  Procedure P_BID_MESSAGE_PASSBACK_HEAD(p_business_bid_id In Number, p_Result Out Varchar2) Is Pragma Autonomous_Transaction;
  Cursor c_INTF_PG_BUSINESS_BID Is
    Select * From intf_pg_business_bid pl
    Where pl.head_id = p_Intf_Id
    And pl.Intf_Status = 'N';
  r_Intf_pg_business_bid_id INTF_PG_BUSINESS_BID%rowtype;
  BEGIN
     p_Result := v_Success;
      begin
        declare c_1 cursor for SELECT city_name,COUNT(city_name) FROM view_alarm_KZ1 GROUP BY city_name;

        select t.*
        into r_Intf_pg_business_bid_id
        from  intf_pg_business_bid t
        where  T.INTF_STATUS = 'N' ;

    exception
        when others then
        p_Result := '没有新插入数据。' || sqlerrm;
    end;
    if p_Result = v_Success then
     Begin
        select t.*
        into r_Intf_pg_business_bid_id
        from  intf_pg_business_bid t
        where  T.INTF_STATUS = 'N'
        for update nowait;

     Exception
        When Others Then
        p_Result := '锁定数据表失败。' || sqlerrm;
     End;
    End If;
     BEGIN
        Loop
        Fetch c_Bd_Price_Apply_Line
          Into r_Bd_Price_Apply_Line;
        Exit When c_Bd_Price_Apply_Line%Notfound Or p_Result <> v_Success;
        END LOOP;
     EXCEPTION
      When Others Then
      Rollback;
     END;
  End;*/
  ----------------------------------------------------------------------
  -- Author  : ZWL
  -- Created : 2015/7/22 10:48:52
  -- Purpose : 中标信息回传
  -----------------------------------------------------------------------
  Procedure P_BID_MESSAGE_PASSBACK(p_business_bid_id In Number, p_Result Out Varchar2) Is Pragma Autonomous_Transaction;
  v_BUSINESS_TARGET_BID_ID  INTF_PG_BUSINESS_TARGET_BID.BUSINESS_BID_ID%type;
  r_Intf_pg_business_bid_id Intf_pg_business_bid%rowtype;
  Begin
    p_Result := v_Success;
    begin
        select t.*
        into r_Intf_pg_business_bid_id
        from  intf_pg_business_bid t
        where t.business_bid_id = p_business_bid_id
        AND T.INTF_STATUS = 'N' ;

    exception
        when others then
        p_Result := '没有新插入数据。' || sqlerrm;
    end;
    if p_Result = v_Success then
     Begin
        select t.*
        into r_Intf_pg_business_bid_id
        from  intf_pg_business_bid t
        where t.business_bid_id = p_business_bid_id
        AND T.INTF_STATUS = 'N'
        for update nowait;

     Exception
        When Others Then
        p_Result := '锁定数据表失败。' || sqlerrm;
     End;
    End If;

    if p_Result = v_Success then
    begin
      select S_BID_MESSAGE_PASSBACK.NEXTVAL
       into v_BUSINESS_TARGET_BID_ID
       from DUAL;

     insert into INTF_PG_BUSINESS_TARGET_BID(
        business_bid_id,
        ENTITY_ID,
        BUSINESS_ID,
        PROJECT_CODE,
        PROJECT_NAME,
        IS_HEAD_HANDLE,
        FIRSTPART_CUSTOMER_ID,
        FIRSTPART_CUSTOMER_CODE,
        FIRSTPART_CUSTOMER_NAME,
        FIRSTPART_ACCOUNTID,
        ORI_BUSINESS_CODE,
        ORI_BUSINESS_ID,
        INTF_STATUS,
        INTF_RESULT
        )
        values(
        v_BUSINESS_TARGET_BID_ID,
        r_Intf_pg_business_bid_id.ENTITY_ID,
        r_Intf_pg_business_bid_id.BUSINESS_ID,
        r_Intf_pg_business_bid_id.PROJECT_CODE,
        r_Intf_pg_business_bid_id.PROJECT_NAME,
        r_Intf_pg_business_bid_id.IS_HEAD_HANDLE,
        r_Intf_pg_business_bid_id.FIRSTPART_CUSTOMER_ID,
        r_Intf_pg_business_bid_id.FIRSTPART_CUSTOMER_CODE,
        r_Intf_pg_business_bid_id.FIRSTPART_CUSTOMER_NAME,
        r_Intf_pg_business_bid_id.FIRSTPART_ACCOUNTID,
        r_Intf_pg_business_bid_id.ORI_BUSINESS_CODE,
        r_Intf_pg_business_bid_id.ORI_BUSINESS_ID,
        r_Intf_pg_business_bid_id.INTF_STATUS,
        r_Intf_pg_business_bid_id.INTF_RESULT
        );


    Exception
        when others then
       p_Result:= '抽取失败！ ' || sqlerrm;
    end;
    end if;
    if  p_Result <> v_Success then
       rollback;
       update intf_pg_business_bid  t
         set t.intf_status = 'E'
         where t.intf_result = p_Result
         and t.business_bid_id = p_Business_Bid_Id;
      -- commit;
    else
        update intf_pg_business_bid  t
         set t.intf_status = 'S',
             t.intf_result = p_Result
         where  t.business_bid_id = r_Intf_pg_business_bid_id.Business_Bid_Id;
      -- commit;
    end if;
  End;

  ----------------------------------------------------------------------
  -- Author  : ZWL
  -- Created : 2015/7/27 10:48:52
  -- Purpose : 价格申报接口
  -----------------------------------------------------------------------
  Procedure P_PG_PRICE_APPLY(P_PRICE_APPLY_ID IN NUMBER,P_RESULT OUT VARCHAR2) Is
    --Pragma Autonomous_Transaction;
    R_PG_PRICE_APPLY_HEAD INTF_PG_PRICE_APPLY_HEAD%ROWTYPE;
    
    CURSOR C_PG_PRICE_APPLY_LINE IS
      SELECT *
        FROM INTF_PG_PRICE_APPLY_LINE PL
       WHERE PL.INTF_APPLY_ID = P_PRICE_APPLY_ID;
    
    CURSOR C_PG_PRICE_APPLY_APPENDIX IS
      SELECT *
        FROM INTF_PG_APPENDIX_CCS IC
       WHERE IC.INTF_TABLE_ID = P_PRICE_APPLY_ID;
    
    TYPE C_PG_BUSINESS_LINE IS REF CURSOR ;
    V_PG_BUSINESS_LINE C_PG_BUSINESS_LINE;
    V_PG_TMP_BUSINESS_LINE  T_PG_BUSINESS_LINE%ROWTYPE;
    
    TYPE C_PG_BUSINESS_APPROVAL IS REF CURSOR;
    V_PG_BUSINESS_APPROVAL C_PG_BUSINESS_APPROVAL;
    V_PG_TMP_BUSINESS_APPROVAL T_PG_BUSINESS_APPROVAL%ROWTYPE;
    
    --CURSOR C_PG_BUSINESS_LINE IS SYS_REFCURSOR;
        
    V_VALUE               VARCHAR2(1024); --程序处理动作
    V_PROJECT_CODE        VARCHAR2(50);
    V_PROJECT_NAME        VARCHAR2(500);
    V_PROJECT_ID          NUMBER;
    -- V_PROJECT_TYPE                                 VARCHAR2(50);
    V_APPLY_ID          NUMBER; --生成的价格申报头ID
    V_APPLY_CODE        VARCHAR2(30); --取到的申报编号
    V_APPLY_LINE_ID     NUMBER; --生成的价格申报行ID
    V_PRODUCTLINE_ID    VARCHAR2(50);
    V_PRODUCTLINE_CODE  VARCHAR2(50);
    V_SALES_CENTER_ID   VARCHAR2(50);
    V_SALES_CENTER_NAME VARCHAR2(500);
    V_CUSTOMER_ID       VARCHAR2(50);
    V_CUSTOMER_NAME     VARCHAR2(500);
    V_ACCOUNT_ID        VARCHAR2(50);
    V_ACCOUNT_NAME      NUMBER;
    V_ACCOUNT_CODE      VARCHAR2(50);
    V_ITEM_ID           VARCHAR2(50);
    V_ITEM_NAME         VARCHAR2(500);
    V_DEFAULT_UNIT      VARCHAR2(50);
    V_LIST_PRICE        NUMBER;
    V_LOW_PRICE         NUMBER;
    V_LOWEST_PRICE      NUMBER;
    V_ACRONYM           VARCHAR2(50);
    V_ACRONYM_STR       VARCHAR2(50);
    V_PG_PRICE          NUMBER;
    V_DISCOUNT          NUMBER;
    V_MONTH_DISCOUNT    NUMBER;
    V_CX_FLAG           VARCHAR2(10);
    V_PROJECT_TYPE      VARCHAR2(12); --工程类型
    V_BEGIN_DATE        DATE; --申报生效日期
    V_END_DATE        DATE; --申报失效日期
    
    
    --ADD BY WANGCONG 2017-4-22 销司需求
    V_INTF_BUSINESS_ID          T_PG_BUSINESS.BUSINESS_ID%TYPE;
    V_INTF_BUSINESS_CODE        T_PG_BUSINESS.PROJECT_CODE%TYPE;
    V_INTF_ORI_BUSINESS_CODE    INTF_PG_PRICE_APPLY_HEAD.ORI_BUSINESS_CODE%TYPE;
    V_PG_PRODUCT_LINE           VARCHAR2(32); --记录是否按产品线登录，调用存储过程PKG_PG.P_GET_PARAMETER_VALUE，传入参数编码‘PG_PRODUCT_LINE’
                                              --是否按产品线登录，N同步到T_PG_BUSINESS_LINE，Y同步到T_PG_BUSINESS_APPROVAL
    V_PG_BUSINESS_COUNT         NUMBER;
    V_PG_NEW_BUSINESS_CODE      T_PG_BUSINESS.PROJECT_CODE%TYPE;
    V_BUSINESS_NEW_ID           T_PG_BUSINESS.BUSINESS_ID%TYPE;
    V_BUSINESS_LINE_NEW_ID      T_PG_BUSINESS_LINE.BUSSINESS_LINE_ID%TYPE;
    V_BUSINESS_APPROVAL_NEW_ID  T_PG_BUSINESS_APPROVAL.BUSINESS_AUDIT_ID%TYPE;
    
    R_PG_BUSINESS_LINE          T_PG_BUSINESS_LINE%ROWTYPE;
    R_PG_PRICE_APPLY_LINE       INTF_PG_PRICE_APPLY_LINE%ROWTYPE;
    R_PG_BUSINESS               T_PG_BUSINESS%ROWTYPE;
    R_PG_BUSINESS_APPROVAL      T_PG_BUSINESS_APPROVAL%ROWTYPE;
    
    V_GROUP_MARK               VARCHAR2(32);--团购标识，取系统参数
    V_IS_GROUP_BUY             T_PG_BUSINESS.IS_GROUPBUY%TYPE;
    
    V_INTF_PG_APPLY_ID         INTF_PG_PRICE_APPLY_HEAD.APPLY_ID%TYPE;
    V_INTF_PG_APPLY_CODE       INTF_PG_PRICE_APPLY_HEAD.APPLY_CODE%TYPE;
    V_IS_UPDATE                VARCHAR2(4);
    
    V_TMP_COUNT                NUMBER; --记录更新操作影响的行数
    V_APPENDIX_COUNT           NUMBER; --附件数
    V_APPENDIX_ID              T_PG_PRICE_APPLY_HEAD.APPENDIX_ID%TYPE;--附件ID
    R_PG_PRICE_APPENDIX        C_PG_PRICE_APPLY_APPENDIX%ROWTYPE;
    
    V_BUYOUT_TYPE              T_PG_PRICE_APPLY_HEAD.BUYOUT_TYPE%TYPE;
    V_AREA_MANAGE              T_PG_BUSINESS.AREA_MANAGER%TYPE;
    V_AREA_MANAGE_PHONE        T_PG_BUSINESS.AREA_MANAGER_PHONE%TYPE;
    V_APPLY_DATE               DATE;
    
    V_IF_NEED_DISCOUNT         VARCHAR2(32);
    V_APPLY_STORE_CODE         VARCHAR2(100);--备货单号
    
    V_IS_CHECK_PROJECT_FOR_PRICE  VARCHAR2(4);--是否校验商机被批文使用过
    V_BD_APPLY_CODE  T_BD_PRICE_APPLY.Apply_Code%TYPE;
	v_big_panel  T_PG_PRICE_APPLY_HEAD.big_panel%Type;
     
  BEGIN
    P_RESULT := v_Success;
    V_IS_UPDATE := 'N';
    V_TMP_COUNT := 0;
    BEGIN
      V_VALUE := '锁定价格申报接口头表失败！';
      SELECT I.*
        INTO R_PG_PRICE_APPLY_HEAD
        FROM INTF_PG_PRICE_APPLY_HEAD I
       WHERE I.INTF_APPLY_ID = P_PRICE_APPLY_ID
         AND I.INTF_STATUS = 'N'
         FOR UPDATE NOWAIT;
    EXCEPTION
      WHEN OTHERS THEN
        P_RESULT := V_VALUE || v_Nl || SQLERRM;
    END;
  
    V_INTF_BUSINESS_CODE     := R_PG_PRICE_APPLY_HEAD.PROJECT_CODE;
    V_INTF_ORI_BUSINESS_CODE := R_PG_PRICE_APPLY_HEAD.ORI_BUSINESS_CODE;
    V_IS_GROUP_BUY := R_PG_PRICE_APPLY_HEAD.IS_GROUPBUY;
    
     --取被引用的备货单号
    V_APPLY_STORE_CODE := R_PG_PRICE_APPLY_HEAD.Apply_Store_Code;--CCS传入接口的是 cims单号
    /*if R_PG_PRICE_APPLY_HEAD.Apply_Store_Code is not null then
      BEGIN
         select a.apply_code into V_APPLY_STORE_CODE from T_PG_PRICE_APPLY_HEAD a where 
                                                 a.ccs_apply_code = R_PG_PRICE_APPLY_HEAD.Ccs_Apply_Code
                                                 and a.status = '2'
                                                 and a.document_type in ('0','2');
      EXCEPTION
          WHEN OTHERS THEN
             P_RESULT := '获取备货单号出错。' || v_Nl || SQLERRM;
        END;
    end if;*/
    
    --取团购标识
    BEGIN
      V_VALUE := '查询团购标识：';
      PKG_BD.P_GET_PARAMETER_VALUE('PG_GROUP_BUY_MARK',
                                    R_PG_PRICE_APPLY_HEAD.ENTITY_ID,
                                    Null,
                                    Null,
                                    V_GROUP_MARK);
    EXCEPTION
      WHEN OTHERS THEN
        P_RESULT := V_VALUE || '出错。' || v_Nl || SQLERRM;
    END;
    
    --是否需要月返
    BEGIN
      V_VALUE := '查询是否需要月返：';
      PKG_BD.P_GET_PARAMETER_VALUE('PG_IF_NEED_DISCOUNT',
                                    R_PG_PRICE_APPLY_HEAD.ENTITY_ID,
                                    Null,
                                    Null,
                                    V_IF_NEED_DISCOUNT);
    EXCEPTION
      WHEN OTHERS THEN
        P_RESULT := V_VALUE || '出错。' || v_Nl || SQLERRM;
    END;
    
    --查询系统参数
    BEGIN
       V_VALUE := '获取主体参数';
       PKG_BD.P_GET_PARAMETER_VALUE('PG_PRODUCT_LINE',
                                     R_PG_PRICE_APPLY_HEAD.ENTITY_ID,
                                     Null,
                                     Null,
                                     V_PG_PRODUCT_LINE);
    EXCEPTION
      WHEN OTHERS THEN
        P_RESULT := V_VALUE || '失败。' || v_Nl || SQLERRM;
    END;
    
    --查询系统参数
    BEGIN
       V_VALUE := '获取主体参数';
       PKG_BD.P_GET_PARAMETER_VALUE('PG_IS_CHECK_PROJECT_FOR_PRICE',
                                     R_PG_PRICE_APPLY_HEAD.ENTITY_ID,
                                     Null,
                                     Null,
                                     V_IS_CHECK_PROJECT_FOR_PRICE);
    EXCEPTION
      WHEN OTHERS THEN
        P_RESULT := V_VALUE || '失败。' || v_Nl || SQLERRM;
    END;
  
    --判断是否为更新操作
    V_INTF_PG_APPLY_ID := R_PG_PRICE_APPLY_HEAD.APPLY_ID;
    V_INTF_PG_APPLY_CODE := R_PG_PRICE_APPLY_HEAD.APPLY_CODE;
    
    IF V_INTF_PG_APPLY_CODE IS NOT NULL THEN
      V_IS_UPDATE := 'Y';
      SELECT H.APPLY_ID,H.APPLY_DATE
      INTO V_APPLY_ID,V_APPLY_DATE
      FROM T_PG_PRICE_APPLY_HEAD H 
      WHERE H.APPLY_CODE = V_INTF_PG_APPLY_CODE
        AND H.ENTITY_ID = R_PG_PRICE_APPLY_HEAD.ENTITY_ID;
      V_APPLY_CODE := V_INTF_PG_APPLY_CODE;
      V_INTF_PG_APPLY_ID := V_APPLY_ID;
      IF V_APPLY_DATE IS NULL THEN
        V_APPLY_DATE := TRUNC(SYSDATE);
      END IF;
    END IF;
    
    --校验项目
      IF V_INTF_ORI_BUSINESS_CODE IS NOT NULL THEN
        BEGIN
          V_VALUE := '校验项目信息失败：';
          SELECT B.BUSINESS_ID, B.PROJECT_CODE, B.PROJECT_NAME,B.BUYOUT_TYPE,B.AREA_MANAGER,B.AREA_MANAGER_PHONE,b.big_panel
            INTO V_PROJECT_ID, V_PROJECT_CODE, V_PROJECT_NAME,V_BUYOUT_TYPE,V_AREA_MANAGE,V_AREA_MANAGE_PHONE,v_big_panel
            FROM T_PG_BUSINESS B
          WHERE B.ORI_BUSINESS_CODE = V_INTF_ORI_BUSINESS_CODE
            and nvl(b.document_type,'0') in ('0','2')
            AND B.ADJUST_BUSINESS_CODE IS NULL
            and B.BUSINESS_ID = (
                SELECT max(s.BUSINESS_ID) from T_PG_BUSINESS s
              WHERE s.ORI_BUSINESS_CODE = V_INTF_ORI_BUSINESS_CODE
                and nvl(s.document_type,'0') in ('0','2')
                AND s.ADJUST_BUSINESS_CODE IS NULL
            );
        EXCEPTION
          WHEN OTHERS THEN
             P_RESULT := V_VALUE || R_PG_PRICE_APPLY_HEAD.ORI_BUSINESS_CODE || v_Nl ||
                        SQLERRM;
        END;
      ELSE
         BEGIN
          V_VALUE := '校验项目信息失败:未录入商机信息！';
          RAISE V_CCS_EXCEPTION;
          EXCEPTION WHEN V_CCS_EXCEPTION THEN 
            P_RESULT := V_VALUE || v_Nl || SQLERRM;
         END;
      END IF;
    
    --校验商机是否被价格批文直接引用
    if V_IS_CHECK_PROJECT_FOR_PRICE = 'Y' then
      V_VALUE := '';
      begin
        select a.apply_code
          into V_BD_APPLY_CODE
          from T_BD_PRICE_APPLY a
         where a.project_code = V_PROJECT_CODE
           and a.entity_id = R_PG_PRICE_APPLY_HEAD.ENTITY_ID
           and a.apply_status <> '00'
           and not exists (select 1
                  from t_pg_price_apply_head b
                 where 1=1
                   and b.apply_code = a.apply_code
                   and b.entity_id = a.entity_id)
           and rownum = 1;
      exception
        when others then
          V_BD_APPLY_CODE := null;
      end;
      if V_BD_APPLY_CODE is not null then
        P_RESULT := '商机已经被价格批文直接引用，不能够再被价格申报引用。价格批文编码：' 
                    || V_BD_APPLY_CODE;
      end if;
    end if;
    
    --处理附件信息
    --查询附件接口表行数
    SELECT COUNT(*)
      INTO V_APPENDIX_COUNT
      FROM INTF_PG_APPENDIX_CCS AC
     WHERE AC.INTF_TABLE_ID = P_PRICE_APPLY_ID;
     
    IF V_APPENDIX_COUNT > 0 THEN
      --生成附件ID
      SELECT 'PRICEAPP' || S_PG_PRICE_APPENDIX.NEXTVAL
        INTO V_APPENDIX_ID
        FROM DUAL;
      
      OPEN C_PG_PRICE_APPLY_APPENDIX;
      LOOP
        FETCH C_PG_PRICE_APPLY_APPENDIX
          INTO R_PG_PRICE_APPENDIX;
        EXIT WHEN C_PG_PRICE_APPLY_APPENDIX%NOTFOUND OR P_RESULT <> v_Success;
          
        BEGIN
          V_VALUE := '同步附件信息到CIMS附件表：';
          INSERT INTO IMS_FILEINFO_INTERFACE
            (ID, BUSINESS_ID, BUSINESS_TYPE, FILE_PATH,FILE_NAME, CREATED_DATE)
          VALUES
            (SEQ_IMS_FILEINFO.NEXTVAL,
             V_APPENDIX_ID,
             'pgPriceAppendix',
             R_PG_PRICE_APPENDIX.FILE_PATH,
             R_PG_PRICE_APPENDIX.FILE_NAME,
             SYSDATE);
        EXCEPTION
          WHEN OTHERS THEN
            P_RESULT := V_VALUE || '出错。' || v_Nl || SQLERRM;
        END;
     END LOOP;  
    END IF;
      
    IF P_RESULT = v_Success AND V_IS_UPDATE = 'N' THEN
      --校验项目
      --MODIFY BY WANGCONG 2017-4-22 销司需求
     /** IF V_INTF_ORI_BUSINESS_CODE IS NOT NULL THEN
        BEGIN
          V_VALUE := '校验项目信息失败:';
          SELECT B.BUSINESS_ID, B.PROJECT_CODE, B.PROJECT_NAME
            INTO V_PROJECT_ID, V_PROJECT_CODE, V_PROJECT_NAME
            FROM T_PG_BUSINESS B
           WHERE B.ORI_BUSINESS_CODE = V_INTF_ORI_BUSINESS_CODE;
        EXCEPTION
          WHEN OTHERS THEN
            P_RESULT := V_VALUE || R_PG_PRICE_APPLY_HEAD.ORI_BUSINESS_CODE || v_Nl ||
                        SQLERRM;
        END;
      ELSIF V_INTF_BUSINESS_CODE IS NOT NULL AND
            V_INTF_ORI_BUSINESS_CODE IS NULL THEN
        BEGIN
          V_VALUE := '校验项目信息失败:';
          SELECT B.BUSINESS_ID, B.PROJECT_CODE, B.PROJECT_NAME
            INTO V_PROJECT_ID, V_PROJECT_CODE, V_PROJECT_NAME
            FROM T_PG_BUSINESS B
           WHERE B.PROJECT_CODE = V_INTF_BUSINESS_CODE;
        EXCEPTION
          WHEN OTHERS THEN
            P_RESULT := V_VALUE || R_PG_PRICE_APPLY_HEAD.ORI_BUSINESS_CODE || v_Nl ||
                        SQLERRM;
        END;
      ELSIF V_INTF_BUSINESS_CODE IS NULL AND
            V_INTF_ORI_BUSINESS_CODE IS NULL THEN
        BEGIN
          V_VALUE := '校验项目信息失败:未录入商机信息！';
          RAISE V_CCS_EXCEPTION;
          EXCEPTION WHEN V_CCS_EXCEPTION THEN 
            P_RESULT := V_VALUE || v_Nl || SQLERRM;
        END;
      END IF;
      **/
      
    --add by wangcong 判断是否需要复制项目
    SELECT COUNT(*) INTO V_PG_BUSINESS_COUNT FROM T_PG_PRICE_APPLY_HEAD H WHERE H.PROJECT_CODE = V_PROJECT_CODE AND H.STATUS <> '3';
    IF V_PG_BUSINESS_COUNT > 0 AND V_IS_UPDATE = 'N' THEN
     --取原头表数据                  
     SELECT TB.*
      INTO R_PG_BUSINESS
      FROM T_PG_BUSINESS TB
      WHERE TB.PROJECT_CODE = V_PROJECT_CODE;
      --查询是否是团购项目
      V_IS_GROUP_BUY := R_PG_BUSINESS.IS_GROUPBUY;
      
      IF V_IS_GROUP_BUY = '1' AND V_GROUP_MARK = 'Y' THEN
        
        IF V_PG_BUSINESS_COUNT > 0 THEN
          --此项目已做价格申报 判断此项目是否在有效时间内 做复制
          SELECT COUNT(*)
            INTO V_PG_BUSINESS_COUNT
            FROM T_PG_BUSINESS B
           WHERE B.PROJECT_CODE = V_PROJECT_CODE and nvl(b.document_type,'0') in ('0','2')
             AND trunc(SYSDATE) BETWEEN B.DEAL_START_DATE AND
                 B.DEAL_END_DATE;
           
           IF V_PG_BUSINESS_COUNT > 0 THEN
             --复制项目
             --生成新项目编码和主键ID;
              SELECT S_PG_BUSINESS.NEXTVAL INTO V_BUSINESS_NEW_ID FROM DUAL;
              --营销中心简称
               SELECT T.EXT_TEXTBOX
                 INTO V_ACRONYM
                 FROM UP_ORG_UNIT_EXT T
                WHERE T.ID IN
                      (SELECT U.ID
                         FROM UP_ORG_UNIT U
                        WHERE U.CODE =
                              R_PG_PRICE_APPLY_HEAD.SALES_CENTER_CODE);
               V_ACRONYM_STR := 'TG'|| V_ACRONYM || '录';
               BEGIN
                 V_VALUE := '生成团购登陆编码：';
                 PKG_BD.P_GET_BILL_NO('TG_PROJECT_CODE',
                                       V_ACRONYM_STR,
                                       R_PG_PRICE_APPLY_HEAD.ENTITY_ID,
                                       Null,
                                       V_PG_NEW_BUSINESS_CODE);
               EXCEPTION
                 WHEN OTHERS THEN
                   P_RESULT := V_VALUE || '出错。' || v_Nl || SQLERRM;
               END;
               
               --判断是否是团购项目
                
               --生成新项目头
               BEGIN
                 V_VALUE := '复制项目头表：';
                 INSERT INTO T_PG_BUSINESS
                  (BUSINESS_ID, --商机信息ID
                   PROJECT_CODE, --项目编号
                   PROJECT_NAME, --项目名称
                   USER_FIRM, --使用单位名称
                   USER_PHONE, --项目方联系电话
                   USER_NAME, --项目方联系人
                   PROJECT_ADDRESS, --工程项目详细地址
                   LOC_ID, --区域ID
                   LOC_CODE, --项目所在区域
                   LOC_NAME, --区域编码名称
                   PROJECT_CENTER_ID, --项目所在中心ID
                   PROJECT_CENTER_CODE, --项目所在中心编码
                   PROJECT_CENTER_NAME, --项目所在中心名称
                   CUSTOMER_ID, --经销商ID
                   CUSTOMER_CODE, --经销商编码
                   CUSTOMER_NAME, --经销商名称
                   SALES_CENTER_ID, --营销中心ID
                   SALES_CENTER_NAME, --营销中心名称
                   SALES_CENTER_CODE, --营销中心编码
                   ACCOUNT_ID, --账户ID
                   ACCOUNT_CODE,          --账户名称
                   AGENT_ID, --经销商ID
                   AGENT_CODE, --经销商编码
                   AGENT_NAME, --经销商名称
                   PROJECT_TYPE, --工程类型:精装房产配套、公租保障配套、家装橱柜配套、燃气公司合作
                   EXPECTED_BID_TIME, --预计投标时间
                   LOGIN_TIME, --登录日期
                   LOGIN_PTOTECT_TIME, --登录保护时间
                   PROJECT_NUM, --项目规模
                   PROJECT_PROGRESS, --项目进度:在建项目、建好未定、准备投标
                   BUSINESS_TYPE, --商机类型
                   DELIVERY_CYCLE, --供货周期:单位为天
                   BUYOUT_TYPE, --买断类型:事前买断、时候买断
                   -- CUSTOMER_PERSON,       --经销商联系人
                   -- CUSTOMER_PERSON_PHONE, --联系方式
                   AREA_MANAGER,          --区域经理
                   AREA_MANAGER_PHONE,    --区域经理电话
                   INSTALL_FLAG, --是否我司安装
                   OTHERLOGIN_FLAG, --是否是异地登录
                   STATUS, --登录状态，有以下几种：已录入、已送审、已审核、已退回、已作废
                   --  COMPETITORS,           --工程竞争对手
                   SPECIAL_NEED, --特殊要求
                   OTHER_DESC, --其他说明资料
                   ENTITY_ID, --主体ID
                   CREATED_BY, --创建人
                   CREATION_DATE, --创建时间
                   LAST_UPDATED_BY, --修改人
                   LAST_UPDATE_DATE, --修改时间
                   --SEND_PERSON,           --送审人
                   --SEND_DATE,             --送审日期
                   --APPROVAL_PERSON,       --审核人
                   --APPROVAL_DATE,         --审核日期
                   --BACK_PERSON,           --退回人
                   --BACK_DATE,             --退回日期
                   --SCRAPPED_PERSON,       --作废人
                   --SCRAPPED_DATE,         --作废时间
                   --RELOGIN_FLAG,          --重新登录标识
                   BID_STATUS, --中标状态
                   --FREEZE_STATUS,         --冻结状态
                   --FREEZE_PERSON,         --冻结人
                   --FREEZE_TIME,           --冻结时间
                   --UNFREEZE_PERSON,       --解冻人
                   --UNFREEZE_TIME,         --解冻时间
                   --IS_MARKET_STRATEGY,    --战略大盘采购
                   --VERFICATION_STATUS,    --核销状态 0未核销 1已核销 2核销失败
                   --REMARK,                --备注
                   IS_GROUPBUY,           --是否团购
                   --PROGRAM_UPDATED_BY,    --程序修改来源
                   PROGRAM_UPDATE_DATE, --修改时间
                   ORI_BUSINESS_ID, --上级项目ID
                   ORI_BUSINESS_CODE, --上级项目编码
                   ADJUST_BUSINESS_ID,
                   ADJUST_BUSINESS_CODE,
                   TRADE,--所属行业
                   BRAND,--品牌
                   CATEGORY,--品类
                   CUSTOMER_FAX,--经销商传真电话
                   FOLLOW_MAN,--分部业务员
                   FOLLOWER_TELEPHONE,--分部业务员电话
                   MAIN_MATERIAL,--涉及机型
                   QUERY_KEYWORDS,--查询关键字
                   STAT_KEYWORDS,--统计关键字
                   TG_COMMISSIONER,--团购专员
                   TG_COMMI_PHONE,--团购专员电话
                   REFER_AREA_ID,--安装涉及区域ID
                   REFER_AREA,--安装涉及区域
                   DEAL_START_DATE,--登录开始日期
                   DEAL_END_DATE,--登录结束日期
                   GROUP_BUY_SALES_MAIN_TYPE--营销大类
                   ,big_panel
                   )
                Values
                  (V_BUSINESS_NEW_ID, --商机信息ID
                   V_PG_NEW_BUSINESS_CODE, --项目编号
                   R_PG_BUSINESS.PROJECT_NAME, --项目名称
                   R_PG_BUSINESS.USER_FIRM, --使用单位名称
                   R_PG_BUSINESS.USER_PHONE, --项目方联系电话
                   R_PG_BUSINESS.USER_NAME, --项目方联系人
                   R_PG_BUSINESS.PROJECT_ADDRESS, --工程项目详细地址
                   R_PG_BUSINESS.LOC_ID, --区域ID
                   R_PG_BUSINESS.LOC_CODE, --项目所在区域
                   R_PG_BUSINESS.LOC_NAME, --区域编码名称
                   R_PG_BUSINESS.PROJECT_CENTER_ID, --项目所在中心ID
                   R_PG_BUSINESS.PROJECT_CENTER_CODE, --项目所在中心编码
                   R_PG_BUSINESS.PROJECT_CENTER_NAME, --项目所在中心名称
                   R_PG_BUSINESS.CUSTOMER_ID,
                   R_PG_BUSINESS.CUSTOMER_CODE,
                   R_PG_BUSINESS.CUSTOMER_NAME,
                   R_PG_BUSINESS.SALES_CENTER_ID, --营销中心ID
                   R_PG_BUSINESS.SALES_CENTER_NAME, --营销中心名称
                   R_PG_BUSINESS.SALES_CENTER_CODE, --营销中心编码
                   R_PG_BUSINESS.ACCOUNT_ID, --账户ID
                   R_PG_BUSINESS.ACCOUNT_CODE,                      --账户名称
                   R_PG_BUSINESS.AGENT_ID, --经销商ID
                   R_PG_BUSINESS.AGENT_CODE, --经销商编码
                   R_PG_BUSINESS.AGENT_NAME, --经销商名称
                   R_PG_BUSINESS.PROJECT_TYPE,
                   R_PG_BUSINESS.EXPECTED_BID_TIME, --v_Expected_Bid_Time,--预计投标时间
                   R_PG_BUSINESS.LOGIN_TIME, --登录日期
                   R_PG_BUSINESS.LOGIN_PTOTECT_TIME, --登录保护时间
                   R_PG_BUSINESS.PROJECT_NUM, --项目规模
                   R_PG_BUSINESS.PROJECT_PROGRESS, --项目进度:在建项目、建好未定、准备投标
                   R_PG_BUSINESS.BUSINESS_TYPE, --存在问题，先置为0
                   R_PG_BUSINESS.DELIVERY_CYCLE, --供货周期:单位为天
                   R_PG_BUSINESS.BUYOUT_TYPE, --买断类型:事前买断、时候买断
                   -- r_Pg_Business.Project_Man,           --经销商联系人
                   --R_PG_BUSINESS.PRO.Project_Telephone,     --联系方式
                   V_AREA_MANAGE,--r_Pg_Business.Follow_Man,            --区域经理
                   V_AREA_MANAGE_PHONE,-- r_Pg_Business.Follower_Telephone,    --区域经理电话
                   R_PG_BUSINESS.INSTALL_FLAG, --是否我司安装
                   R_PG_BUSINESS.OTHERLOGIN_FLAG, --是否是异地登录
                   '8', --登录状态:已公示
                   --   R_PG_BUSINESS.Main_Material,         --工程竞争对手
                   R_PG_BUSINESS.SPECIAL_NEED, --特殊要求
                   R_PG_BUSINESS.OTHER_DESC, --其他说明资料
                   R_PG_BUSINESS.ENTITY_ID, --主体ID
                   'CCS', --创建人
                   SYSDATE, --创建时间
                   R_PG_BUSINESS.LAST_UPDATED_BY, --修改人
                   R_PG_BUSINESS.LAST_UPDATE_DATE, --修改时间
                   -- r_Pg_Business.To_Checkup_By_Name,    --送审人
                   -- r_Pg_Business.To_Checkup_Date,       --送审日期
                   -- r_Pg_Business.Checkup_By_Name,       --审核人
                   -- r_Pg_Business.Checkup_Date,          --审核日期
                   -- r_Pg_Business.Back_By_Name,          --退回人
                   -- r_Pg_Business.Back_Date,             --退回日期
                   --- r_Pg_Business.Back_By,               --作废人
                   -- r_Pg_Business.Reject_Date,           --作废时间
                   --r_Pg_Business.Relogin_Flag,          --重新登录标识
                   '0', --中标状态
                   --r_Pg_Business.Freeze_Status,         --冻结状态
                   --r_Pg_Business.Freeze_Person,         --冻结人
                   --r_Pg_Business.Freeze_Time,           --冻结时间
                   --r_Pg_Business.Unfreeze_Person,       --解冻人
                   --r_Pg_Business.Unfreeze_Time,         --解冻时间
                   --r_Pg_Business.Is_Market_StLrategy,    --战略大盘采购
                   --r_Pg_Business.Verfication_Status,    --核销状态 0未核销 1已核销 2核销失败
                   --r_Pg_Business.Remark,                --备注
                   R_PG_BUSINESS.IS_GROUPBUY,           --是否团购
                   --r_Pg_Business.Program_Updated_By,    --程序修改来源
                   SYSDATE, --修改时间
                   R_PG_BUSINESS.ORI_BUSINESS_ID, --上级项目ID
                   R_PG_BUSINESS.ORI_BUSINESS_CODE, --上级项目编码
                   R_PG_BUSINESS.BUSINESS_ID,
                   V_PROJECT_CODE,
                   R_PG_BUSINESS.TRADE, ----所属行业
                   R_PG_BUSINESS.BRAND, ----品牌
                   R_PG_BUSINESS.CATEGORY, ----品类
                   R_PG_BUSINESS.CUSTOMER_FAX, ----经销商传真电话
                   R_PG_BUSINESS.FOLLOW_MAN, ----分部业务员
                   R_PG_BUSINESS.FOLLOWER_TELEPHONE, ----分部业务员电话
                   R_PG_BUSINESS.MAIN_MATERIAL, ----涉及机型
                   R_PG_BUSINESS.QUERY_KEYWORDS, ----查询关键字
                   R_PG_BUSINESS.STAT_KEYWORDS, ----统计关键字
                   R_PG_BUSINESS.TG_COMMISSIONER, ----团购专员
                   R_PG_BUSINESS.TG_COMMI_PHONE, ----团购专员电话
                   R_PG_BUSINESS.REFER_AREA_ID, ----安装涉及区域ID
                   R_PG_BUSINESS.REFER_AREA, ----安装涉及区域
                   R_PG_BUSINESS.DEAL_START_DATE, ----登录开始日期
                   R_PG_BUSINESS.DEAL_END_DATE, ----登录结束日期
                   R_PG_BUSINESS.GROUP_BUY_SALES_MAIN_TYPE ----营销大类 
                   ,R_PG_BUSINESS.Big_Panel --大盘简称
                   );
                   
                   V_PROJECT_ID := V_BUSINESS_NEW_ID;
                   V_PROJECT_CODE := V_PG_NEW_BUSINESS_CODE;
               EXCEPTION 
                 WHEN OTHERS THEN
                 P_RESULT := V_VALUE || '失败。' || v_Nl || SQLERRM;
               END;
               
               IF V_PG_PRODUCT_LINE = 'N' THEN 
                 --原项目行数据                     
                 OPEN V_PG_BUSINESS_LINE FOR 
                      'SELECT * FROM T_PG_BUSINESS_LINE L WHERE L.BUSINESS_ID = '||R_PG_BUSINESS.BUSINESS_ID;
                 LOOP
                   FETCH V_PG_BUSINESS_LINE 
                    INTO V_PG_TMP_BUSINESS_LINE;
                   EXIT WHEN V_PG_BUSINESS_LINE%NOTFOUND;
                   
                   --序列
                   SELECT S_PG_BUSINESS_LINE.NEXTVAL
                     INTO V_BUSINESS_LINE_NEW_ID
                     FROM DUAL;
                   
                   --生成新行数据  
                   BEGIN
                     V_VALUE := '复制商机行表：';
                     
                     Insert Into T_PG_BUSINESS_LINE
                    (bussiness_line_id, --商机商品行信息ID
                     business_id, --商机信息ID
                     sales_main_type, --营销大类编码
                     sales_main_type_name, --营销大类名称
                     sales_sub_type, --营销小类编码
                     sales_sub_type_name, --营销小类名称
                     item_id, --产品ID
                     item_code, --产品编码
                     item_desc, --产品型号
                     uom_code, --单位
                     common_price, --直供价
                     requis_price, --预计报价
                     requis_qty, --申请数量
                     created_by, --创建人
                     creation_date, --创建时间
                     last_updated_by, --修改人
                     last_update_date, --修改时间
                     entity_id --主体ID
                     )
                  Values
                    (V_BUSINESS_LINE_NEW_ID, --商机商品行信息ID
                     V_BUSINESS_NEW_ID, --商机信息ID
                     V_PG_TMP_BUSINESS_LINE.SALES_MAIN_TYPE, --营销大类编码
                     V_PG_TMP_BUSINESS_LINE.SALES_MAIN_TYPE_NAME, --营销大类名称
                     V_PG_TMP_BUSINESS_LINE.SALES_SUB_TYPE, --营销小类编码
                     V_PG_TMP_BUSINESS_LINE.SALES_SUB_TYPE_NAME, --营销小类名称
                     V_PG_TMP_BUSINESS_LINE.ITEM_ID, --产品ID
                     V_PG_TMP_BUSINESS_LINE.ITEM_CODE, --产品编码
                     V_PG_TMP_BUSINESS_LINE.ITEM_DESC, --产品型号
                     V_PG_TMP_BUSINESS_LINE.UOM_CODE, --单位
                     V_PG_TMP_BUSINESS_LINE.COMMON_PRICE, --直供价
                     V_PG_TMP_BUSINESS_LINE.REQUIS_PRICE, --预计报价
                     V_PG_TMP_BUSINESS_LINE.REQUIS_QTY, --申请数量
                     'CCS', --创建人
                     SYSDATE, --创建时间
                     'CCS', --修改人
                     SYSDATE, --修改时间
                     V_PG_TMP_BUSINESS_LINE.ENTITY_ID --主体ID
                     );
                   EXCEPTION
                     WHEN OTHERS THEN
                       P_RESULT := V_VALUE || '失败。' || v_Nl || SQLERRM;
                   END;
                 END LOOP;   
               ELSIF V_PG_PRODUCT_LINE = 'Y' THEN
                 OPEN V_PG_BUSINESS_APPROVAL FOR 
                    'SELECT * FROM T_PG_BUSINESS_APPROVAL L WHERE L.BUSINESS_ID = '||R_PG_BUSINESS.BUSINESS_ID;
                 LOOP
                   FETCH V_PG_BUSINESS_APPROVAL 
                    INTO V_PG_TMP_BUSINESS_APPROVAL;
                   EXIT WHEN V_PG_BUSINESS_APPROVAL%NOTFOUND;
                   
                    ---序列
                    SELECT S_PG_BUSINESS_APPROVAL.NEXTVAL
                      INTO V_BUSINESS_APPROVAL_NEW_ID
                      FROM DUAL;
                    BEGIN
                      V_VALUE := '复制产品线行表：';  
                      --更新产品线行表
                      Insert Into T_Pg_Business_Approval
                        (business_audit_id, --产品线登录行ID
                         business_id, --商机信息ID
                         productline_id, --产品线ID
                         productline_code, --产品线编码
                         productline_name, --产品线名称
                         creation_date, --创建时间
                         last_update_date, --修改时间
                         entity_id, --主体ID
                         created_by,
                         last_updated_by)
                      Values
                        (V_BUSINESS_APPROVAL_NEW_ID, --商机商品行信息ID
                         V_BUSINESS_NEW_ID, --商机信息ID
                         V_PG_TMP_BUSINESS_APPROVAL.PRODUCTLINE_ID, --产品线ID
                         V_PG_TMP_BUSINESS_APPROVAL.PRODUCTLINE_CODE, --产品线编码
                         V_PG_TMP_BUSINESS_APPROVAL.PRODUCTLINE_NAME, --产品线名称
                         SYSDATE, --创建时间
                         SYSDATE, --修改时间
                         R_PG_BUSINESS.ENTITY_ID, --主体ID
                         'CCS',
                         'CCS');
                     EXCEPTION
                       WHEN OTHERS THEN
                         P_RESULT := V_VALUE || '失败。' || v_Nl || SQLERRM;
                     END;
                  END LOOP;
                END IF;
                
           ELSE
             BEGIN
               V_VALUE := '校验项目失败：';
               RAISE V_CCS_EXCEPTION;
             EXCEPTION WHEN V_CCS_EXCEPTION THEN
               P_RESULT := V_VALUE || V_INTF_BUSINESS_CODE || '项目已做申报且不在有效期内。'|| v_Nl || SQLERRM;
             END;
           END IF;
         END IF;
       END IF;
     END IF;
    END IF;  
      --判断是否校验产品线信息
      IF V_PG_PRODUCT_LINE = 'Y' THEN
        --校验产品线
        BEGIN
          V_VALUE := '校验产品线信息失败:';
          -- PRODUCTLINE_CODE                 T_PG_PRODUCT_LINE
          SELECT T.PRODUCTLINE_ID, T.PRODUCTLINE_CODE
            INTO V_PRODUCTLINE_ID, V_PRODUCTLINE_CODE
            FROM T_PG_PRODUCT_LINE T
           WHERE T.PRODUCTLINE_NAME = R_PG_PRICE_APPLY_HEAD.PRODUCTLINE_NAME
             AND T.ENTITY_ID = R_PG_PRICE_APPLY_HEAD.ENTITY_ID;
        EXCEPTION
          WHEN OTHERS THEN
            P_RESULT := V_VALUE || R_PG_PRICE_APPLY_HEAD.PRODUCTLINE_NAME || v_Nl ||
                        SQLERRM;
        END;
      END IF;
    
      --校验营销中心
      BEGIN
        V_VALUE := '校验营销中心信息失败:';
        --  SALES_CENTER_CODE                UP_ORG_UNIT
        SELECT T.UNIT_ID, T.NAME
          INTO V_SALES_CENTER_ID, V_SALES_CENTER_NAME
          FROM UP_ORG_UNIT T
         WHERE T.CODE = R_PG_PRICE_APPLY_HEAD.SALES_CENTER_CODE
           AND T.ENTITY_ID = R_PG_PRICE_APPLY_HEAD.ENTITY_ID;
      EXCEPTION
        WHEN OTHERS THEN
          P_RESULT := V_VALUE || R_PG_PRICE_APPLY_HEAD.SALES_CENTER_CODE || v_Nl ||
                      SQLERRM;
      END;
    
      --校验客户
      BEGIN
        V_VALUE := '校验客户信息失败:';
        --  CUSTOMER_CODE                    T_CUSTOMER_HEADER
        SELECT T.CUSTOMER_ID, T.CUSTOMER_NAME
          INTO V_CUSTOMER_ID, V_CUSTOMER_NAME
          FROM T_CUSTOMER_HEADER T
         WHERE T.CUSTOMER_CODE = R_PG_PRICE_APPLY_HEAD.CUSTOMER_CODE;
      EXCEPTION
        WHEN OTHERS THEN
          P_RESULT := V_VALUE || R_PG_PRICE_APPLY_HEAD.CUSTOMER_CODE || v_Nl ||
                      SQLERRM;
      END;
    
      --校验账户
      BEGIN
        V_VALUE := '校验账户信息失败:';
        --  ACCOUNT_CODE                     V_CUSTOMER_ACCOUNT_SALECENTER
        SELECT V.ACCOUNT_ID, V.ACCOUNT_CODE
          INTO V_ACCOUNT_ID, V_ACCOUNT_CODE
          FROM CIMS.V_CUSTOMER_ACCOUNT_SALECENTER V
         WHERE V.CUSTOMER_CODE = R_PG_PRICE_APPLY_HEAD.CUSTOMER_CODE
           AND V.ENTITY_ID = R_PG_PRICE_APPLY_HEAD.ENTITY_ID
           AND V.ACTIVE_FLAG = 'Active'
           AND V.ORGACTIVE_FLAG = 'Active'
           AND V.ACCOUNT_STATUS = '1'
           AND V.SALES_CENTER_CODE =
               R_PG_PRICE_APPLY_HEAD.SALES_CENTER_CODE;
      EXCEPTION
        WHEN OTHERS THEN
          P_RESULT := V_VALUE || R_PG_PRICE_APPLY_HEAD.CUSTOMER_CODE || v_Nl ||
                      SQLERRM;
      END;
    
  
    --工程类型转码
    IF P_RESULT = v_Success THEN
      BEGIN
        V_VALUE := '工程类型转码：';
       /* SELECT U.CODE_VALUE
          INTO V_PROJECT_TYPE
          FROM UP_CODELIST U
         WHERE U.CODE_NAME LIKE
               '%'||R_PG_PRICE_APPLY_HEAD.PROJECT_TYPE||'%'
           AND U.CODETYPE = 'tpgProjectType';*/
        SELECT L.CODE_VALUE
          INTO V_PROJECT_TYPE
          FROM V_UP_CODELIST L
         WHERE L.CODE_NAME LIKE
               '%' || R_PG_PRICE_APPLY_HEAD.PROJECT_TYPE || '%'
           AND L.CODETYPE = 'tpgProjectType'
           AND L.ENTITY_ID = R_PG_PRICE_APPLY_HEAD.ENTITY_ID;
      EXCEPTION
        WHEN OTHERS THEN
          P_RESULT := V_VALUE || '工程类型' ||
                      TO_CHAR(R_PG_PRICE_APPLY_HEAD.PROJECT_TYPE) ||
                      '不存在或者已失效。';
      END;
    END IF;
  
    --申报生效日期校验
    IF R_PG_PRICE_APPLY_HEAD.BEGIN_DATE IS NULL THEN
      V_BEGIN_DATE := TRUNC(SYSDATE);
    ELSE
      V_BEGIN_DATE := TRUNC(R_PG_PRICE_APPLY_HEAD.BEGIN_DATE);
    END IF;
    --申报失效日期校验
    IF R_PG_PRICE_APPLY_HEAD.END_DATE IS NULL THEN
      V_END_DATE := to_date(to_char(SYSDATE,'yyyy')||'12/31','yyyy/MM/dd');
    ELSE
      V_END_DATE := TRUNC(R_PG_PRICE_APPLY_HEAD.END_DATE);
    END IF;
  
    --头表数据处理
    IF P_RESULT = v_Success AND V_IS_UPDATE = 'N' THEN
      --新增操作
      BEGIN
        V_VALUE := '开始插入价格申报头表数据';
        SELECT S_PG_PRICE_APPLY_HEADER.NEXTVAL INTO V_APPLY_ID FROM DUAL;
        --营销中心简称
        SELECT T.EXT_TEXTBOX
          INTO V_ACRONYM
          FROM UP_ORG_UNIT_EXT T
         WHERE T.ID IN
               (SELECT U.ID
                  FROM UP_ORG_UNIT U
                 WHERE U.CODE = R_PG_PRICE_APPLY_HEAD.SALES_CENTER_CODE);
                 
        IF V_IS_GROUP_BUY='1' AND V_GROUP_MARK = 'Y' THEN
          V_ACRONYM_STR := V_ACRONYM || '团申' || R_PG_PRICE_APPLY_HEAD.ENTITY_ID;
        ELSE
          V_ACRONYM_STR := V_ACRONYM || '申'|| R_PG_PRICE_APPLY_HEAD.ENTITY_ID;
        END IF;
        
        --申报编码
        PKG_BD.P_GET_BILL_NO('pgPriceCode',
                             V_ACRONYM_STR,
                             R_PG_PRICE_APPLY_HEAD.ENTITY_ID,
                             NULL,
                             V_APPLY_CODE);
      
        INSERT INTO T_PG_PRICE_APPLY_HEAD
          (ENTITY_ID,
           APPLY_ID,
           APPLY_CODE,
           PRODUCTLINE_ID,
           PRODUCTLINE_CODE,
           PRODUCTLINE_NAME,
           SALES_CENTER_ID,
           SALES_CENTER_CODE,
           SALES_CENTER_NAME,
           APPLY_DATE,
           CUSTOMER_ID,
           CUSTOMER_CODE,
           CUSTOMER_NAME,
           ACCOUNT_ID,
           ACCOUNT_CODE,
           BUSINESS_ID,
           PROJECT_CODE,
           PROJECT_NAME,
           USER_FIRM,
           USER_PHONE,
           USER_NAME,
           PROJECT_ADDRESS,
           AGENT_ID,
           AGENT_CODE,
           AGENT_NAME,
           PROJECT_TYPE,
           BEGIN_DATE,
           END_DATE,
           SPECIAL_NEED,
           OTHER_DESC,
           CREATED_BY,
           CREATION_DATE,
           LAST_UPDATED_BY,
           LAST_UPDATE_DATE,
           PROGRAM_UPDATED_BY,
           PROGRAM_UPDATE_DATE,
           VERSION,
           AREA_FOLLOW,
           IS_ADJUST,
           OLD_APPLY_ID,
           STATUS,
           IS_VALID,
           CCS_APPLY_ID,
           CCS_APPLY_CODE,
           IS_GROUPBUY,
           APPENDIX_ID,
           INSTALL_ADD,
           INSTALL_ADD_CONTACTS,
           INSTALL_ADD_TEL,
           BUYOUT_TYPE,
           DOCUMENT_TYPE,
           AREA_MANAGER,
           AREA_MANAGER_PHONE,
           IS_STORE,
           APPLY_STORE_CODE
		   ,big_panel
		   )
        VALUES
          (R_PG_PRICE_APPLY_HEAD.ENTITY_ID,
           V_APPLY_ID,
           V_APPLY_CODE,
           V_PRODUCTLINE_ID,
           V_PRODUCTLINE_CODE,
           R_PG_PRICE_APPLY_HEAD.PRODUCTLINE_NAME,
           V_SALES_CENTER_ID,
           R_PG_PRICE_APPLY_HEAD.SALES_CENTER_CODE,
           V_SALES_CENTER_NAME,
           TRUNC(SYSDATE), --R_PG_PRICE_APPLY_HEAD.APPLY_DATE,
           V_CUSTOMER_ID,
           R_PG_PRICE_APPLY_HEAD.CUSTOMER_CODE,
           V_CUSTOMER_NAME,
           V_ACCOUNT_ID,
           V_ACCOUNT_CODE,
           V_PROJECT_ID,
           V_PROJECT_CODE,
           V_PROJECT_NAME,
           R_PG_PRICE_APPLY_HEAD.USER_FIRM,
           R_PG_PRICE_APPLY_HEAD.USER_PHONE,
           R_PG_PRICE_APPLY_HEAD.USER_NAME,
           R_PG_PRICE_APPLY_HEAD.PROJECT_ADDRESS,
           R_PG_PRICE_APPLY_HEAD.AGENT_ID,
           R_PG_PRICE_APPLY_HEAD.AGENT_CODE,
           R_PG_PRICE_APPLY_HEAD.AGENT_NAME,
           V_PROJECT_TYPE,
           V_BEGIN_DATE, -- R_PG_PRICE_APPLY_HEAD.BEGIN_DATE,
           V_END_DATE, --R_PG_PRICE_APPLY_HEAD.END_DATE,
           R_PG_PRICE_APPLY_HEAD.SPECIAL_NEED,
           R_PG_PRICE_APPLY_HEAD.OTHER_DESC,
           'ADMIN',
           SYSDATE,
           'ADMIN',
           SYSDATE,
           'CCS',
           SYSDATE,
           '1',
           R_PG_PRICE_APPLY_HEAD.AREA_FOLLOW,
           R_PG_PRICE_APPLY_HEAD.IS_ADJUST,
           R_PG_PRICE_APPLY_HEAD.OLD_APPLY_ID,
           '0',
           'Y',
           R_PG_PRICE_APPLY_HEAD.CCS_APPLY_ID,
           R_PG_PRICE_APPLY_HEAD.CCS_APPLY_CODE,
           R_PG_PRICE_APPLY_HEAD.IS_GROUPBUY,
           V_APPENDIX_ID,
           R_PG_PRICE_APPLY_HEAD.INSTALL_ADD,
           R_PG_PRICE_APPLY_HEAD.INSTALL_ADD_CONTACTS,
           R_PG_PRICE_APPLY_HEAD.INSTALL_ADD_TEL,
           V_BUYOUT_TYPE,
           '0',
           V_AREA_MANAGE,
           V_AREA_MANAGE_PHONE,
           R_PG_PRICE_APPLY_HEAD.IS_STORE,
           V_APPLY_STORE_CODE
		        ,v_big_panel
		   );
      EXCEPTION
        WHEN OTHERS THEN
          P_RESULT := V_VALUE || v_Nl || SQLERRM;
      END;
    ELSIF P_RESULT = v_Success AND V_IS_UPDATE = 'Y' THEN
      --更新操作
      BEGIN
        V_VALUE := '更新价格申报头表：';
        UPDATE T_PG_PRICE_APPLY_HEAD H SET
               H.PRODUCTLINE_ID = V_PRODUCTLINE_ID,--R_PG_PRICE_APPLY_HEAD.PRODUCTLINE_ID,
               H.PRODUCTLINE_CODE = V_PRODUCTLINE_CODE,-- R_PG_PRICE_APPLY_HEAD.PRODUCTLINE_CODE,
               H.PRODUCTLINE_NAME = R_PG_PRICE_APPLY_HEAD.PRODUCTLINE_NAME,
               H.SALES_CENTER_ID = V_SALES_CENTER_ID,--R_PG_PRICE_APPLY_HEAD.SALES_CENTER_ID,
               H.SALES_CENTER_CODE = R_PG_PRICE_APPLY_HEAD.SALES_CENTER_CODE,
               H.SALES_CENTER_NAME = V_SALES_CENTER_NAME,--R_PG_PRICE_APPLY_HEAD.SALES_CENTER_NAME,
               H.APPLY_DATE = V_APPLY_DATE,
               H.CUSTOMER_ID = V_CUSTOMER_ID,--R_PG_PRICE_APPLY_HEAD.CUSTOMER_ID,
               H.CUSTOMER_CODE = R_PG_PRICE_APPLY_HEAD.CUSTOMER_CODE,
               H.CUSTOMER_NAME = V_CUSTOMER_NAME,--R_PG_PRICE_APPLY_HEAD.CUSTOMER_NAME,
               H.ACCOUNT_ID = V_ACCOUNT_ID,--R_PG_PRICE_APPLY_HEAD.ACCOUNT_ID,
               H.ACCOUNT_CODE = V_ACCOUNT_CODE,--R_PG_PRICE_APPLY_HEAD.ACCOUNT_CODE,
             --  H.BUSINESS_ID = V_PROJECT_ID,--R_PG_PRICE_APPLY_HEAD.BUSINESS_ID,
             --  H.PROJECT_CODE = V_PROJECT_CODE,--R_PG_PRICE_APPLY_HEAD.PROJECT_CODE,
             --  H.PROJECT_NAME = R_PG_PRICE_APPLY_HEAD.PROJECT_NAME,
               H.USER_FIRM = R_PG_PRICE_APPLY_HEAD.USER_FIRM,
               H.USER_PHONE = R_PG_PRICE_APPLY_HEAD.USER_PHONE,
               H.USER_NAME = R_PG_PRICE_APPLY_HEAD.USER_NAME,
               H.PROJECT_ADDRESS = R_PG_PRICE_APPLY_HEAD.PROJECT_ADDRESS,
               H.AGENT_ID = R_PG_PRICE_APPLY_HEAD.AGENT_ID,
               H.AGENT_CODE = R_PG_PRICE_APPLY_HEAD.AGENT_CODE,
               H.AGENT_NAME = R_PG_PRICE_APPLY_HEAD.AGENT_NAME,
               H.PROJECT_TYPE = V_PROJECT_TYPE,--R_PG_PRICE_APPLY_HEAD.PROJECT_TYPE,
               H.BEGIN_DATE = V_BEGIN_DATE,--R_PG_PRICE_APPLY_HEAD.BEGIN_DATE,
               H.END_DATE = V_END_DATE,--R_PG_PRICE_APPLY_HEAD.END_DATE,
               H.SPECIAL_NEED = R_PG_PRICE_APPLY_HEAD.SPECIAL_NEED,
               H.OTHER_DESC = R_PG_PRICE_APPLY_HEAD.OTHER_DESC,
               H.CREATED_BY = 'CCS',
               H.CREATION_DATE = SYSDATE, 
               H.LAST_UPDATED_BY = 'CCS',
               H.LAST_UPDATE_DATE = SYSDATE,
               H.PROGRAM_UPDATED_BY = 'CCS',
               H.PROGRAM_UPDATE_DATE = SYSDATE,
               H.VERSION = '1',
               H.AREA_FOLLOW = R_PG_PRICE_APPLY_HEAD.AREA_FOLLOW,
               H.IS_ADJUST = R_PG_PRICE_APPLY_HEAD.IS_ADJUST,
               H.OLD_APPLY_ID = R_PG_PRICE_APPLY_HEAD.OLD_APPLY_ID,
               H.STATUS = '0',
               H.IS_VALID = 'Y',
               H.CCS_APPLY_ID = R_PG_PRICE_APPLY_HEAD.CCS_APPLY_ID,
               H.CCS_APPLY_CODE = R_PG_PRICE_APPLY_HEAD.CCS_APPLY_CODE,
               H.APPENDIX_ID = V_APPENDIX_ID,
               H.INSTALL_ADD = R_PG_PRICE_APPLY_HEAD.INSTALL_ADD,
               H.INSTALL_ADD_CONTACTS = R_PG_PRICE_APPLY_HEAD.INSTALL_ADD_CONTACTS,
               H.INSTALL_ADD_TEL = R_PG_PRICE_APPLY_HEAD.INSTALL_ADD_TEL,
               H.AREA_MANAGER = V_AREA_MANAGE,
               H.AREA_MANAGER_PHONE = V_AREA_MANAGE_PHONE,
               H.IS_STORE = R_PG_PRICE_APPLY_HEAD.IS_STORE,
               H.APPLY_STORE_CODE = V_APPLY_STORE_CODE,
			   h.big_panel=v_big_panel
               WHERE H.APPLY_CODE = V_INTF_PG_APPLY_CODE;
		--add by tangjz2 2018-6-14
		--团购申报商机编号会改变，如果是团购，则不更新商机信息
		UPDATE T_PG_PRICE_APPLY_HEAD H SET
             H.BUSINESS_ID = V_PROJECT_ID,--R_PG_PRICE_APPLY_HEAD.BUSINESS_ID,
             H.PROJECT_CODE = V_PROJECT_CODE,--R_PG_PRICE_APPLY_HEAD.PROJECT_CODE,
             H.PROJECT_NAME = R_PG_PRICE_APPLY_HEAD.PROJECT_NAME
             WHERE H.APPLY_CODE = V_INTF_PG_APPLY_CODE and nvl(H.Is_Groupbuy,'0') <> '1';
      
       EXCEPTION
         WHEN OTHERS THEN
           P_RESULT := V_VALUE || '失败。' || v_Nl || SQLERRM;
       END;
    END IF;        
    
    
    
    
    
    --处理行表数据
    IF V_IS_UPDATE = 'Y' THEN
      --删除原行表数据
      BEGIN
        V_VALUE := '更新行数据，删除原行表数据：';
        DELETE FROM T_PG_PRICE_APPLY_LINE TL
         WHERE TL.ITEM_CODE NOT IN
               (SELECT L.ITEM_CODE FROM INTF_PG_PRICE_APPLY_LINE L
                 WHERE L.INTF_APPLY_ID = P_PRICE_APPLY_ID)
           AND TL.APPLY_ID = V_INTF_PG_APPLY_ID;
      EXCEPTION
        WHEN OTHERS THEN
          P_RESULT := V_VALUE || '失败。' || v_Nl || SQLERRM;
      END;
    END IF;
    
    IF P_RESULT = v_Success THEN
      OPEN C_PG_PRICE_APPLY_LINE;
      LOOP
        FETCH C_PG_PRICE_APPLY_LINE
          INTO R_PG_PRICE_APPLY_LINE;
        EXIT WHEN C_PG_PRICE_APPLY_LINE%NOTFOUND OR P_RESULT <> v_Success;
        
        --校验产品信息
        BEGIN
          V_VALUE := '校验产品信息失败:';
          SELECT T.ITEM_ID, T.ITEM_NAME, T.DEFAULTUNIT
            INTO V_ITEM_ID, V_ITEM_NAME, V_DEFAULT_UNIT
            FROM T_BD_ITEM T
           WHERE T.ITEM_CODE = R_PG_PRICE_APPLY_LINE.ITEM_CODE
             AND T.ENTITY_ID = R_PG_PRICE_APPLY_HEAD.ENTITY_ID;
        EXCEPTION
          WHEN OTHERS THEN
            P_RESULT := V_VALUE || R_PG_PRICE_APPLY_LINE.ITEM_CODE || '不存在。'|| v_Nl || SQLERRM;
        END;
      
        BEGIN
          V_VALUE := '查询产品审批底价';
          SELECT L.LIST_PRICE
            INTO V_LOW_PRICE
            FROM T_BD_PRICE_LINE L
           WHERE L.ITEM_CODE = R_PG_PRICE_APPLY_LINE.ITEM_CODE
             AND L.PRICE_LIST_ID =
                 (SELECT R.PRICE_LIST_1
                    FROM T_PG_PRICE_LIST_REL R
                   WHERE R.SALES_CENTER_CODE =
                         R_PG_PRICE_APPLY_HEAD.SALES_CENTER_CODE
                     AND R.ENTITY_ID = R_PG_PRICE_APPLY_HEAD.ENTITY_ID)
             AND L.ENTITY_ID = R_PG_PRICE_APPLY_HEAD.ENTITY_ID
             AND TRUNC(SYSDATE,'dd') >= L.BEGIN_DATE
             AND (TRUNC(SYSDATE,'dd') <= L.END_DATE OR
                 L.END_DATE IS NULL)
             AND L.ACTIVE_FLAG = 'Y';
        EXCEPTION
          WHEN OTHERS THEN
            P_RESULT := '查询' || R_PG_PRICE_APPLY_LINE.ITEM_CODE ||
                        '产品审批底价失败,' || '时间为:' || TRUNC(SYSDATE,'dd') || v_Nl ||
                        SQLERRM;
        END;
      
        BEGIN
          V_VALUE := '查询产品最低价';
          SELECT MIN(L.LIST_PRICE)
            INTO V_LOWEST_PRICE
            FROM T_BD_PRICE_LINE L
           WHERE L.PRICE_LIST_ID IN
                 (SELECT NVL(R.PRICE_LIST_1, 0)
                    FROM T_PG_PRICE_LIST_REL R
                   WHERE R.SALES_CENTER_CODE =
                         R_PG_PRICE_APPLY_HEAD.SALES_CENTER_CODE
                  UNION
                  SELECT NVL(R.PRICE_LIST_2, 0)
                    FROM T_PG_PRICE_LIST_REL R
                   WHERE R.SALES_CENTER_CODE =
                         R_PG_PRICE_APPLY_HEAD.SALES_CENTER_CODE
                  UNION
                  SELECT NVL(R.PRICE_LIST_3, 0)
                    FROM T_PG_PRICE_LIST_REL R
                   WHERE R.SALES_CENTER_CODE =
                         R_PG_PRICE_APPLY_HEAD.SALES_CENTER_CODE
                  UNION
                  SELECT NVL(R.PRICE_LIST_4, 0)
                    FROM T_PG_PRICE_LIST_REL R
                   WHERE R.SALES_CENTER_CODE =
                         R_PG_PRICE_APPLY_HEAD.SALES_CENTER_CODE
                  UNION
                  SELECT NVL(R.PRICE_LIST_5, 0)
                    FROM T_PG_PRICE_LIST_REL R
                   WHERE R.SALES_CENTER_CODE =
                         R_PG_PRICE_APPLY_HEAD.SALES_CENTER_CODE
                  UNION
                  SELECT NVL(R.PRICE_LIST_6, 0)
                    FROM T_PG_PRICE_LIST_REL R
                   WHERE R.SALES_CENTER_CODE =
                         R_PG_PRICE_APPLY_HEAD.SALES_CENTER_CODE
                  UNION
                  SELECT NVL(R.PRICE_LIST_7, 0)
                    FROM T_PG_PRICE_LIST_REL R
                   WHERE R.SALES_CENTER_CODE =
                         R_PG_PRICE_APPLY_HEAD.SALES_CENTER_CODE
                  UNION
                  SELECT NVL(R.PRICE_LIST_8, 0)
                    FROM T_PG_PRICE_LIST_REL R
                   WHERE R.SALES_CENTER_CODE =
                         R_PG_PRICE_APPLY_HEAD.SALES_CENTER_CODE
                  UNION
                  SELECT NVL(R.PRICE_LIST_9, 0)
                    FROM T_PG_PRICE_LIST_REL R
                   WHERE R.SALES_CENTER_CODE =
                         R_PG_PRICE_APPLY_HEAD.SALES_CENTER_CODE)
             AND L.ITEM_CODE = R_PG_PRICE_APPLY_LINE.ITEM_CODE
             AND L.BEGIN_DATE <= trunc(SYSDATE) 
             AND (L.END_DATE >= trunc(SYSDATE) OR L.END_DATE IS NULL);
        EXCEPTION
          WHEN OTHERS THEN
            P_RESULT := '查询产品最低价失败' || v_Nl || SQLERRM;
        END;
      
        --查找面价
        BEGIN
          V_VALUE := '查询产品面价';
          PKG_BD_PRICE.P_GET_PRICE(V_ACCOUNT_ID,
                                   R_PG_PRICE_APPLY_LINE.ITEM_CODE,
                                   TO_CHAR(SYSDATE, 'YYYYMMDD'),
                                   NULL,
                                   R_PG_PRICE_APPLY_LINE.ENTITY_ID,
                                   V_PG_PRICE,
                                   V_DISCOUNT,
                                   V_MONTH_DISCOUNT,
                                   V_CX_FLAG);
        EXCEPTION
          WHEN OTHERS THEN
            P_RESULT := '查询产品面价失败' || v_Nl || SQLERRM || '账户ID:' ||
                        V_ACCOUNT_ID || ';产品编码:' ||
                        R_PG_PRICE_APPLY_LINE.ITEM_CODE || ';单据日期:' ||
                        TO_CHAR(SYSDATE, 'YYYYMMDD') || ';业务主体ID:' ||
                        R_PG_PRICE_APPLY_LINE.ENTITY_ID || SQLERRM;
        END;
      
        IF V_PG_PRICE IS NULL THEN
          P_RESULT := '价格申报明细产品编码' || R_PG_PRICE_APPLY_LINE.ITEM_CODE ||
                      '未定义价格';
        ELSIF R_PG_PRICE_APPLY_LINE.APPLY_PRICE > V_PG_PRICE AND V_IF_NEED_DISCOUNT = 'Y' THEN
          P_RESULT := '价格申报明细产品编码' || R_PG_PRICE_APPLY_LINE.ITEM_CODE ||
                      '的申请价不能大于直供价';
        END IF;
      
        --更新数据
        IF V_IS_UPDATE = 'Y' THEN
          BEGIN
            V_VALUE := '更新行表数据：';
            UPDATE T_PG_PRICE_APPLY_LINE TAL SET
                   TAL.LIST_PRICE = V_PG_PRICE,
                   TAL.CONTRACT_PRICE = R_PG_PRICE_APPLY_LINE.CONTRACT_PRICE,
                   TAL.APPLY_PRICE = R_PG_PRICE_APPLY_LINE.APPLY_PRICE,
                   TAL.APPLY_QUANTITY = R_PG_PRICE_APPLY_LINE.APPLY_QUANTITY,
                   TAL.APPLY_AMOUNT = R_PG_PRICE_APPLY_LINE.APPLY_PRICE *
                                      R_PG_PRICE_APPLY_LINE.APPLY_QUANTITY,
                   TAL.LOW_PRICE = V_LOW_PRICE,
                   TAL.CATCH_DATE = R_PG_PRICE_APPLY_LINE.CATCH_DATE,
                   TAL.LAST_UPDATED_BY = 'CCS',
                   TAL.LAST_UPDATE_DATE = SYSDATE,
                   TAL.PROGRAM_UPDATED_BY = 'CCS',
                   TAL.PROGRAM_UPDATE_DATE = SYSDATE,
                   TAL.LOWEST_PRICE = V_LOWEST_PRICE,
                   TAL.DELIVERY_PRICE = R_PG_PRICE_APPLY_LINE.DELIVERY_PRICE
             WHERE TAL.APPLY_ID = V_INTF_PG_APPLY_ID
               AND TAL.ITEM_CODE = R_PG_PRICE_APPLY_LINE.ITEM_CODE;
             
             V_TMP_COUNT := SQL%ROWCOUNT;
           EXCEPTION
             WHEN OTHERS THEN
               P_RESULT := V_VALUE || '失败。' || v_Nl || SQLERRM;
           END;
        END IF;
        
        IF V_TMP_COUNT = 0 THEN 
          BEGIN
            V_VALUE := '开始插入价格申报行表数据';
            IF P_RESULT = v_Success THEN
              SELECT S_PG_PRICE_APPLY_LINE.NEXTVAL
                INTO V_APPLY_LINE_ID
                FROM DUAL;
              INSERT INTO T_PG_PRICE_APPLY_LINE
                (ENTITY_ID,
                 APPLY_LINE_ID,
                 APPLY_ID,
                 ITEM_ID,
                 ITEM_CODE,
                 ITEM_DESC,
                 UOM_CODE,
                 LIST_PRICE,
                 CONTRACT_PRICE,
                 APPLY_PRICE,
                 APPLY_QUANTITY,
                 APPLY_AMOUNT,
                 LOW_PRICE,
                 CATCH_DATE,
                 CREATED_BY,
                 CREATION_DATE,
                 LAST_UPDATED_BY,
                 LAST_UPDATE_DATE,
                 PROGRAM_UPDATED_BY,
                 PROGRAM_UPDATE_DATE,
                 VERSION,
                 LOWEST_PRICE,
                 MONTH_DISCOUNT,
                 DELIVERY_PRICE)
              VALUES
                (R_PG_PRICE_APPLY_LINE.ENTITY_ID,
                 V_APPLY_LINE_ID,
                 V_APPLY_ID,
                 V_ITEM_ID,
                 R_PG_PRICE_APPLY_LINE.ITEM_CODE,
                 V_ITEM_NAME,
                 V_DEFAULT_UNIT,
                 V_PG_PRICE,
                 R_PG_PRICE_APPLY_LINE.CONTRACT_PRICE,
                 R_PG_PRICE_APPLY_LINE.APPLY_PRICE,
                 R_PG_PRICE_APPLY_LINE.APPLY_QUANTITY,
                 R_PG_PRICE_APPLY_LINE.APPLY_PRICE *
                 R_PG_PRICE_APPLY_LINE.APPLY_QUANTITY,
                 V_LOW_PRICE,
                 R_PG_PRICE_APPLY_LINE.CATCH_DATE,
                 'ADMIN',
                 SYSDATE,
                 'CCS',
                 SYSDATE,
                 'CCS',
                 SYSDATE,
                 1,
                 V_LOWEST_PRICE,
                 (1 - R_PG_PRICE_APPLY_LINE.APPLY_PRICE/V_PG_PRICE)*100,
                 R_PG_PRICE_APPLY_LINE.DELIVERY_PRICE);
            
            END IF;
          EXCEPTION
            WHEN OTHERS THEN
              P_RESULT := V_VALUE || '失败' || v_Nl || SQLERRM || '产品编码为:' ||
                          R_PG_PRICE_APPLY_LINE.ITEM_CODE || SQLERRM;
          END;
        END IF;
        --同步成功后回写标志位 ：INTF_STATUS，INTF_RESULT
        IF P_RESULT <> v_Success THEN
          --ROLLBACK;
          UPDATE INTF_PG_PRICE_APPLY_HEAD T
             SET T.INTF_STATUS = 'E',
                 T.INTF_RESULT = P_RESULT,
                 T.APPLY_ID    = V_APPLY_ID,
                 T.APPLY_CODE  = V_APPLY_CODE
           WHERE T.INTF_APPLY_ID = R_PG_PRICE_APPLY_HEAD.INTF_APPLY_ID;
        
          UPDATE INTF_PG_PRICE_APPLY_LINE T
             SET T.INTF_STATUS = 'E', T.INTF_RESULT = P_RESULT
           WHERE T.INTF_APPLY_LINE_ID =
                 R_PG_PRICE_APPLY_LINE.INTF_APPLY_LINE_ID;
          -- COMMIT;
        ELSE
          UPDATE INTF_PG_PRICE_APPLY_HEAD T
             SET T.INTF_STATUS = 'S',
                 T.INTF_RESULT = 'SUCCESS',
                 T.APPLY_ID    = V_APPLY_ID,
                 T.APPLY_CODE  = V_APPLY_CODE
           WHERE T.INTF_APPLY_ID = R_PG_PRICE_APPLY_HEAD.INTF_APPLY_ID;
        
          UPDATE INTF_PG_PRICE_APPLY_LINE T
             SET T.INTF_STATUS = 'S', T.INTF_RESULT = 'SUCCESS'
           WHERE T.INTF_APPLY_LINE_ID =
                 R_PG_PRICE_APPLY_LINE.INTF_APPLY_LINE_ID;
          -- COMMIT;
        END IF;
      END LOOP;
    END IF;
  
  End;

  ----------------------------------------------------------------------
  -- Author  : WYF
  -- Created : 2015/08/03 11:08:40
  -- Purpose : 商机同步
  ----------------------------------------------------------------------
  Procedure P_PG_BUSINESS_SYNC(p_Business_Id In Number, p_Entity_Id In Number, p_Result Out Varchar2) Is Pragma Autonomous_Transaction;
    --20171219 hejy3 屏蔽IMS同义词
    /*r_Pg_Business V_IMS_PG_LOGIN_IMS%Rowtype;

    Cursor c_Pg_Business_Line Is
      Select *
        From V_IMS_PG_LOGIN_LINE_IMS i
      Where i.Head_Id = p_Business_Id;
    r_Pg_Business_Line c_Pg_Business_Line%Rowtype;

    Cursor c_Pg_Business_Approval Is
      Select *
        From V_IMS_PG_LOGIN_CHECKUP_IMS i
      Where i.Head_Id = p_Business_Id;
    r_Pg_Business_Approval c_Pg_Business_Approval%Rowtype;*/

    v_Project_Code Varchar2(32);                  --项目编号
    v_Record Number;                              --记录是否已录入的记录数
    v_Value Varchar2(1024);                       --记录处理状态
    v_Loc_Id Number;                              --项目所在区域转码，项目所在区域ID
    v_Loc_Code Varchar2(30);                      --项目所在区域转码，项目所在区域编码
    v_Loc_Name Varchar2(500);                      --项目所在区域转码，项目所在区域名称
    v_Project_Center_Id Number;                   --项目所在中心转码，项目所在中心ID
    v_Project_Center_Code Varchar2(100);          --项目所在中心转码，项目所在中心编码
    v_Project_Center_Name Varchar2(500);          --项目所在中心转码，项目所在中心名称
    v_Account_Id NUMBER;                          --账户ID
    v_Account_Code VARCHAR2(100);                 --账户名称
    v_Customer_Id Number;                         --经销商转码，经销商ID
    v_Customer_Code Varchar2(100);                --经销商转码，经销商编码
    v_Customer_Name Varchar2(500);                --经销商转码，经销商名称
    v_Sales_Center_Id Number;                     --营销中心转码，营销中心ID
    v_Sales_Center_Code Varchar2(100);            --营销中心转码，营销中心编码
    v_Sales_Center_Name Varchar2(500);            --营销中心转码，营销中心名称
    --v_Expected_Bid_Time Date;                     --记录预计投标时间，若没有，则存登录日期
    v_Business_Id Number;                         --记录生成的商机信息ID
    v_Bussiness_Line_Id Number;                   --记录生成的商机商品行信息ID
    --v_Business_Audit_Id Number;                 --记录生成的产品线登录行ID
    v_Pg_Product_Line Varchar2(10);                      --记录是否按产品线登录，调用存储过程Pkg_Pg.P_Get_Parameter_Value，传入参数编码‘PG_PRODUCT_LINE’,是否按产品线登录，N同步到T_PG_BUSINESS_LINE，Y同步到T_PG_BUSINESS_APPROVAL
    v_Project_Type Varchar2(10);                  --工程类型
    v_Business_Type Varchar2(32);                 --商机类型
    v_BuyOut_Type Varchar2(2);                    --买断类型
    v_Productline_Id Number;                      --产品线ID
    v_Business_Audit_Id Number;                   --产品线登录行ID
     
    Begin
      p_Result := v_Success;

      --检查是否已录入
      --20171219 hejy3 屏蔽IMS同义词
      /*Begin
        v_Value := '项目是否录入检查';
        Select count(*)
          Into v_Record
          From t_Pg_Business t
        Where t.Ori_Business_Id = p_Business_Id;
      Exception
        When Others Then
          p_Result := v_Value || '失败！' || v_Nl || Sqlerrm;
      End;

      Begin
        v_Value := '获取主体参数';
        Pkg_Bd.P_Get_Parameter_Value('PG_PRODUCT_LINE',p_Entity_Id,Null,Null,v_Pg_Product_Line);
      Exception
        When Others Then
          p_Result := v_Value || '失败！' || v_Nl || Sqlerrm;
      End;

     If v_Record = 0 Then
        --记录为0，未录入，执行录入操作
        Begin
          Select *
            Into r_Pg_Business
            From V_IMS_PG_LOGIN_IMS v
           Where v.Head_Id = p_Business_Id
             And v.CIMS_ENTITY_ID = p_Entity_Id;
        End;

        If p_Result = v_Success Then
          Begin
            v_Value := '项目所在区域检查：';
            Select t.Row_Id,t.District_Code, t.District_Name
              Into v_Loc_Id,v_Loc_Code, v_Loc_Name
              From t_Bd_District t
            Where t.District_Code = r_Pg_Business.Loc_Code
            And t.Active_Flag = 'Y';
          Exception
            When Others Then
              p_Result := v_Value || '区域编码' || To_Char(r_Pg_Business.Loc_Code) || '不存在或者区域已失效。';
          End;
        End If;

        \*If p_Result =  v_Success Then
          Begin
            v_Value := '项目所在中心检查：';
            Select t.Unit_Id, t.Org_Code, t.Org_Name
              Into v_Project_Center_Id,v_Project_Center_Code, v_Project_Center_Name
              From t_Pg_Area_Org t
            Where t.Org_Code = r_Pg_Business.Project_Center_Code;
          Exception
            When Others Then
              p_Result := v_Value || '项目所在中心编码' || To_Char(r_Pg_Business.Project_Center_Code) || '不存在或未配置。';
          End;
        End If;*\
        If p_Result = v_Success Then
          Begin
            v_Value := '项目所在中心检查：';
            Select u.Unit_Id, u.Code, u.Name
              Into v_Project_Center_Id,v_Project_Center_Code, v_Project_Center_Name
              From Up_Org_Unit u
             Where u.Code = r_Pg_Business.Project_Center_Code
               And u.entity_id = p_Entity_Id
               And u.Active_Flag = 'T';
          Exception
            When Others Then
               p_Result := v_Value || '项目所在中心编码' || To_Char(r_Pg_Business.Project_Center_Code) || '不存在或未配置。';
          End;
        End If;

        If p_Result = v_Success Then
          Begin
            v_Value := '营销中心检查：';
            Select u.Unit_Id, u.Code, u.Name
              Into v_Sales_Center_Id,v_Sales_Center_Code, v_Sales_Center_Name
              From Up_Org_Unit u
             Where u.Code = r_Pg_Business.Sales_Center_Code
               And u.entity_id = p_Entity_Id
               And u.Active_Flag = 'T';
          Exception
            When Others Then
              p_Result := v_Value || '营销中心编码' || To_Char(r_Pg_Business.Sales_Center_Code) || '不存在或者中心已失效。';
          End;
        End If;

\*        If p_Result = v_Success Then
          Begin
            v_Value := '经销商检查：';
            Select t.Customer_Id,t.Customer_Code, t.Customer_Name
              Into v_Customer_Id,v_Customer_Code, v_Customer_Name
              From t_Customer_Header t
            Where t.Customer_Code = r_Pg_Business.MD_AGENT_CODE
              And t.Active_Flag = 'Active';
          Exception
            When Others Then
              p_Result := v_Value || '经销商编码' || To_Char(r_Pg_Business.MD_AGENT_CODE) || '不存在或者经销商已失效。';
          End;
        End If;

        If p_Result = v_Success Then
          Begin
            v_Value := '账户ID、名称生成：';
            Select v.Account_Id,v.Account_Code
              Into v_Account_Id,v_Account_Code
              From v_customer_account_salecenter v
             Where v.customer_code  = r_Pg_Business.MD_AGENT_CODE
               And v.entity_id = p_Entity_Id
               And v.active_flag  = 'Active'
               And v.orgActive_flag = 'Active'
               And v.account_status = '1';
          Exception
            When Others Then
              p_Result := v_Value || '失败！' || v_Nl || Sqlerrm;
          End;
        End If;*\

        --Begin
        --  v_Value := '获取预计投标时间';
        --  Select r.Expected_Bid_Time
        --   Into v_Expected_Bid_Time
        --    From r_Pg_Business r
        --  Where r.Expected_Bid_Time Is Not Null;
        --  Exception
        --    When Others Then
        --      p_Result := v_Value || '失败！' || v_Nl || Sqlerrm;
        --End;
        --If v_Expected_bid_time = Null Then
        --  Begin
        --    v_Value := '预计投标时间为空';
        --    v_Expected_Bid_Time := sysdate;
        --  Exception
        --    When Others Then
        --      p_Result := v_Value || '设置时间失败！' || v_Nl || Sqlerrm;
        --  End;
        --End If;

        If p_Result = v_Success Then
          Begin
            v_Value := '项目编号生成：';
            PKG_BD.P_GET_BILL_NO('tpgProjectCode',Null,p_Entity_Id,Null,v_Project_Code);
          Exception
            When Others Then
              p_Result := v_Value || '失败！' || v_Nl || Sqlerrm;
          End;
        End If;

        \*If p_Result = v_Success Then
          Begin
            v_Value := '工程类型转码：';
            Select u.Code_Value
            Into v_Project_Type
            From Up_CodeList u
            Where u.Code_Name like '%'|| r_Pg_Business.Bulding_Use || '%' And u.Codetype='tpgProjectType';
          Exception
            When Others Then
              p_Result := v_Value || '工程类型' || To_Char(r_Pg_Business.Bulding_Use) || '不存在或者已失效。';
          End;
        End If;*\

       \* If p_Result = v_Success Then
          Begin
            v_Value := '商机类型转码：';
            Select u.Code_Value
            Into v_Business_Type
            From Up_CodeList u
            Where u.Code_Name like '%'|| r_Pg_Business.Business_Type || '%' And u.Codetype='tpgBusinessType';
          Exception
            When Others Then
              p_Result := v_Value || '商机类型' || To_Char(r_Pg_Business.Business_Type) || '不存在或者已失效。';
          End;
        End If;*\

        If p_Result = v_Success Then
          Begin
            v_Value := '买断类型转码';
            Select l.code_value
              Into v_BuyOut_Type
              From cims.up_codelist l
             Where l.codetype = 'tpgBuyoutType' And l.code_name like '%'|| r_Pg_Business.Apply_Data_Type || '%';
          Exception
            When Others Then
              p_Result := v_Value || '买断类型' || To_Char(r_Pg_Business.Apply_Data_Type) || '不存在或未配置。';
          End;
        End If;

        If p_Result = v_Success Then
          Select S_PG_BUSINESS.NEXTVAL Into v_Business_Id From Dual;
          Begin
            v_Value := '开始插入商机录入业务头表数据';
            Insert Into T_PG_BUSINESS
            (business_id,           --商机信息ID
             project_code,          --项目编号
             project_name,          --项目名称
             user_firm,             --使用单位名称
             user_phone,            --项目方联系电话
             user_name,             --项目方联系人
             project_address,       --工程项目详细地址
             loc_id,                --区域ID
             loc_code,              --项目所在区域
             loc_name,              --区域编码名称
             project_center_id,     --项目所在中心ID
             project_center_code,   --项目所在中心编码
             project_center_name,   --项目所在中心名称
             customer_id,           --经销商ID
             customer_code,         --经销商编码
             customer_name,         --经销商名称
             sales_center_id,       --营销中心ID
             sales_center_name,      --营销中心名称
             sales_center_code,     --营销中心编码
            -- account_id,            --账户ID
             --account_code,          --账户名称
             agent_id,              --经销商ID
             agent_code,            --经销商编码
             agent_name,            --经销商名称
             project_type,          --工程类型:精装房产配套、公租保障配套、家装橱柜配套、燃气公司合作
             expected_bid_time,     --预计投标时间
             login_time,            --登录日期
             login_ptotect_time,    --登录保护时间
             --project_num,           --项目规模
             --project_progress,      --项目进度:在建项目、建好未定、准备投标
             business_type,         --商机类型
             --delivery_cycle,        --供货周期:单位为天
             buyout_type,           --买断类型:事前买断、时候买断
             customer_person,       --经销商联系人
             customer_person_phone, --联系方式
             area_manager,          --区域经理
             area_manager_phone,    --区域经理电话
             --install_flag,          --是否我司安装
             otherlogin_flag,       --是否是异地登录
             status,                --登录状态，有以下几种：已录入、已送审、已审核、已退回、已作废
             competitors,           --工程竞争对手
             special_need,          --特殊要求
             other_desc,            --其他说明资料
             entity_id,             --主体ID
             created_by,            --创建人
             creation_date,         --创建时间
             last_updated_by,       --修改人
             last_update_date,      --修改时间
             send_person,           --送审人
             send_date,             --送审日期
             approval_person,       --审核人
             approval_date,         --审核日期
             back_person,           --退回人
             back_date,             --退回日期
             scrapped_person,       --作废人
             scrapped_date,         --作废时间
             --relogin_flag,          --重新登录标识
             bid_status,            --中标状态
             --freeze_status,         --冻结状态
             --freeze_person,         --冻结人
             --freeze_time,           --冻结时间
             --unfreeze_person,       --解冻人
             --unfreeze_time,         --解冻时间
             --is_market_strategy,    --战略大盘采购
             --verfication_status,    --核销状态 0未核销 1已核销 2核销失败
             --remark,                --备注
             --is_groupbuy,           --是否团购
             --program_updated_by,    --程序修改来源
             program_update_date,   --修改时间
             ori_business_id,       --上级项目ID
             ori_business_code      --上级项目编码
            )
            Values
            (v_Business_Id,                       --商机信息ID
             v_Project_Code,                      --项目编号
             r_Pg_Business.Project_Name,          --项目名称
             r_Pg_Business.User_Firm,             --使用单位名称
             r_Pg_Business.Firm_Telephone,        --项目方联系电话
             r_Pg_Business.User_Man,              --项目方联系人
             r_Pg_Business.Detail_Of_Address,     --工程项目详细地址
             v_Loc_Id,                            --区域ID
             v_Loc_Code,                          --项目所在区域
             v_Loc_Name,                          --区域编码名称
             v_Project_Center_Id,                 --项目所在中心ID
             v_Project_Center_Code,               --项目所在中心编码
             v_Project_Center_Name,               --项目所在中心名称
             --v_Customer_Id,                       --经销商ID
             --v_Customer_Code,                     --经销商编码
             --v_Customer_Name,                     --经销商名称
             r_Pg_Business.APPLY_CUSTOMER_ID,       --存在问题，先使用原值
             r_Pg_Business.APPLY_CUSTOMER_CODE,     --存在问题，先使用原值
             r_Pg_Business.APPLY_CUSTOMER,          --存在问题，先使用原值
             v_Sales_Center_Id,                   --营销中心ID
             v_Sales_Center_Name,                 --营销中心名称
             v_Sales_Center_Code,                 --营销中心编码
            -- v_Account_Id,                        --账户ID
            -- v_Account_Code,                      --账户名称
             r_Pg_Business.Agent_Id,              --经销商ID
             r_Pg_Business.Agent_Code,            --经销商编码
             r_Pg_Business.Agent_Name,            --经销商名称
             --v_Project_Type,                      --工程类型，使用tpgProjectType码表
             '0',                                   --存在问题，先置为0
             trunc(sysdate),                      --v_Expected_Bid_Time,--预计投标时间
             trunc(sysdate),                      --登录日期
             add_months(sysdate-1, 3),            --登录保护时间
             --r_Pg_Business.Project_Num,           --项目规模
             --r_Pg_Business.Project_Progress,      --项目进度:在建项目、建好未定、准备投标
             --v_Business_Type,                     --商机类型
             '0',                                   --存在问题，先置为0
             --r_Pg_Business.Delivery_Cycle,        --供货周期:单位为天
             v_BuyOut_Type,                       --买断类型:事前买断、时候买断
             r_Pg_Business.Project_Man,           --经销商联系人
             r_Pg_Business.Project_Telephone,     --联系方式
             r_Pg_Business.Follow_Man,            --区域经理
             r_Pg_Business.Follower_Telephone,    --区域经理电话
             --r_Pg_Business.Install_Flag,          --是否我司安装
             r_Pg_Business.Otherlogin_Flag,       --是否是异地登录
             '2',                                 --登录状态:已审核
             r_Pg_Business.Main_Material,         --工程竞争对手
             r_Pg_Business.Special_Need,          --特殊要求
             r_Pg_Business.Other_Reamark,         --其他说明资料
             p_Entity_Id,                         --主体ID
             r_Pg_Business.Created_By,            --创建人
             r_Pg_Business.Creation_Date,         --创建时间
             r_Pg_Business.Last_Updated_By,       --修改人
             r_Pg_Business.Last_Update_Date,      --修改时间
             r_Pg_Business.To_Checkup_By_Name,    --送审人
             r_Pg_Business.To_Checkup_Date,       --送审日期
             r_Pg_Business.Checkup_By_Name,       --审核人
             r_Pg_Business.Checkup_Date,          --审核日期
             r_Pg_Business.Back_By_Name,          --退回人
             r_Pg_Business.Back_Date,             --退回日期
             r_Pg_Business.Back_By,               --作废人
             r_Pg_Business.Reject_Date,           --作废时间
             --r_Pg_Business.Relogin_Flag,          --重新登录标识
             '0',                                   --中标状态
             --r_Pg_Business.Freeze_Status,         --冻结状态
             --r_Pg_Business.Freeze_Person,         --冻结人
             --r_Pg_Business.Freeze_Time,           --冻结时间
             --r_Pg_Business.Unfreeze_Person,       --解冻人
             --r_Pg_Business.Unfreeze_Time,         --解冻时间
             --r_Pg_Business.Is_Market_Strategy,    --战略大盘采购
             --r_Pg_Business.Verfication_Status,    --核销状态 0未核销 1已核销 2核销失败
             --r_Pg_Business.Remark,                --备注
             --r_Pg_Business.Is_Groupbuy,           --是否团购
             --r_Pg_Business.Program_Updated_By,    --程序修改来源
             trunc(sysdate),                      --修改时间
             r_Pg_Business.Head_Id,               --上级项目ID
             r_Pg_Business.LOGIN_CODE             --上级项目编码
             );
          Exception
            When Others Then
              p_Result := v_Value || '，失败。' || v_Nl || Sqlerrm;
          End;
        End If;

        If p_Result = v_Success And v_Pg_Product_Line = 'N' Then
          Open c_Pg_Business_Line;
          Loop
            Fetch c_Pg_Business_Line
              Into r_Pg_Business_Line;
            Exit When c_Pg_Business_Line%Notfound Or p_Result <> v_Success;
            If p_Result = v_Success Then
              Select S_PG_BUSINESS_LINE.NEXTVAL Into v_Bussiness_Line_Id From Dual;
              Begin
                v_Value := '开始插入商机商品行行表数据';
                Insert Into T_PG_BUSINESS_LINE
                (bussiness_line_id,    --商机商品行信息ID
                 business_id,          --商机信息ID
                 --sales_main_type,      --营销大类编码
                 --sales_main_type_name, --营销大类名称
                 --sales_sub_type,       --营销小类编码
                 --sales_sub_type_name,  --营销小类名称
                 --item_id,              --产品ID
                 item_code,            --产品编码
                 item_desc,            --产品型号
                 uom_code,             --单位
                 common_price,         --直供价
                 requis_price,         --预计报价
                 requis_qty,           --申请数量
                 created_by,           --创建人
                 creation_date,        --创建时间
                 last_updated_by,      --修改人
                 last_update_date,     --修改时间
                 entity_id             --主体ID
                )
                Values
                (v_Bussiness_Line_Id,                     --商机商品行信息ID
                 v_Business_Id,                           --商机信息ID
                 --r_Pg_Business_Line.Sales_Main_Type,      --营销大类编码
                 --r_Pg_Business_Line.Sales_Main_Type_Name, --营销大类名称
                 --r_Pg_Business_Line.Sales_Sub_Type,       --营销小类编码
                 --r_Pg_Business_Line.Sales_Sub_Type_Name,  --营销小类名称
                 --r_Pg_Business_Line.Material_Id,              --产品ID
                 r_Pg_Business_Line.Material_Code,        --产品编码
                 r_Pg_Business_Line.Description,          --产品型号
                 r_Pg_Business_Line.Uom_Code,             --单位
                 r_Pg_Business_Line.List_Price,           --直供价
                 r_Pg_Business_Line.Contract_Price,       --预计报价
                 r_Pg_Business_Line.Apply_Quantity,       --申请数量
                 r_Pg_Business_Line.Created_By,           --创建人
                 r_Pg_Business_Line.Creation_Date,        --创建时间
                 r_Pg_Business_Line.Last_Updated_By,      --修改人
                 r_Pg_Business_Line.Last_Update_Date,     --修改时间
                 p_Entity_Id                              --主体ID
                );
              Exception
                When Others Then
                  p_Result := v_Value || '失败。' || v_Nl || Sqlerrm;
              End;
            End If;
          End Loop;

        Elsif p_Result = v_Success And v_Pg_Product_Line = 'Y' Then
           Open c_Pg_Business_Approval;
          Loop
            Fetch c_Pg_Business_Approval
              Into r_Pg_Business_Approval;
            Exit When c_Pg_Business_Approval%Notfound Or p_Result <> v_Success;
            If p_Result = v_Success Then
              Select S_PG_BUSINESS_APPROVAL.NEXTVAL Into v_Business_Audit_Id From Dual;

             \* If p_Result = v_Success Then
                Begin
                  v_Value := '根据产品线编码查询产品线ID';
                  Select t.productline_id
                    Into v_Productline_Id
                    From cims.t_pg_product_line t
                   Where t.productline_code = r_Pg_Business_Approval.Prod_Line_Code;
                Exception
                  When Others Then
                    p_Result := v_Value || '产品线编码' || To_Char(r_Pg_Business_Approval.Prod_Line_Code) || '不存在或未配置。';
                End;
              End If;*\

              Begin
                v_Value := '开始插入商机产品线行表数据';
                Insert Into T_Pg_Business_Approval
                (business_audit_id,                      --产品线登录行ID
                 business_id,                            --商机信息ID
                 productline_id,                         --产品线ID
                 productline_code,                       --产品线编码
                 productline_name,                       --产品线名称
                 self_result,                            --本中心审核状态
                 self_person_id,                         --本中心审核人ID
                 self_person_name,                       --本中心审核人名称
                 self_audit_time  ,                      --本中心审核时间
                 self_comment,                           --本中心审核建议
                 other_result,                           --跨中心审核状态
                 other_person_id,                        --跨中心审核人id
                 other_person_name,                      --跨中心审核人名称
                 other_audit_time,                       --跨中心审核时间
                 other_comment,                          --跨中心审核建议
                 creation_date,                          --创建时间
                 last_update_date,                       --修改时间
                 entity_id,                              --主体ID
                 created_by,
                 last_updated_by
                )
                Values
                (v_Business_Audit_Id,                    --商机商品行信息ID
                 v_Business_Id,                          --商机信息ID
                 r_Pg_Business_Approval.Checkup_Id,      --产品线ID
                 r_Pg_Business_Approval.Prod_Line_Code,  --产品线编码
                 r_Pg_Business_Approval.Prod_Line_Name,  --产品线名称
                 r_Pg_Business_Approval.Self_Status,     --本中心审核状态
                 r_Pg_Business_Approval.Self_By,         --本中心审核人ID
                 r_Pg_Business_Approval.Self_Name,       --本中心审核人名称
                 r_Pg_Business_Approval.Self_Date,       --本中心审核时间
                 r_Pg_Business_Approval.Self_Comment,    --本中心审核建议
                 r_Pg_Business_Approval.Tran_Status,     --跨中心审核状态
                 r_Pg_Business_Approval.Tran_By,         --跨中心审核人id
                 r_Pg_Business_Approval.Tran_Name,       --跨中心审核人名称
                 r_Pg_Business_Approval.Tran_Date,       --跨中心审核时间
                 r_Pg_Business_Approval.Tran_Comment,    --跨中心审核建议
                 trunc(sysdate),                         --创建时间
                 trunc(sysdate),                         --修改时间
                 p_entity_id,                            --主体ID
                 'CCS',
                 'CCS'
                );
              Exception
                When Others Then
                  p_Result := v_Value || '失败。' || v_Nl || Sqlerrm;
              End;
            End If;
          End Loop;

        End If;

      Else
        p_Result := '项目已存在，不需同步。';
      End If;

      If p_Result <> v_Success Then
          Rollback;
        Else
          Commit;
      End If;*/
    Exception
      When Others Then
        Rollback;
        p_Result := '失败：' || p_Result || v_Nl || Sqlerrm;
    End;

  ----------------------------------------------------------------------
  -- Author  : WANGCONG
  -- Created : 2015/10/12
  -- Purpose : 价格申报调整
  ----------------------------------------------------------------------
  Procedure P_PG_PRICE_APPLY_ADJUST(P_PRICE_APPLY_ID IN NUMBER,
                                    P_RESULT         OUT VARCHAR2) IS
    --PRAGMA AUTONOMOUS_TRANSACTION;
   r_Pg_Price_Apply_Head INTF_PG_PRICE_APPLY_HEAD%rowtype;

  Cursor c_pg_price_apply_line Is
    Select * From intf_pg_price_apply_line pl
    Where pl.intf_apply_id = p_Price_Apply_Id;
  
  CURSOR C_PG_PRICE_APPLY_APPENDIX IS
    SELECT *
      FROM INTF_PG_APPENDIX_CCS IC
    WHERE IC.INTF_TABLE_ID = P_PRICE_APPLY_ID;

  r_pg_price_apply_line intf_pg_price_apply_line%Rowtype;                    --用于锁定价格申报头表数据
  R_PG_PRICE_APPLY_HEAD_OLD INTF_PG_PRICE_APPLY_HEAD%ROWTYPE ;               --原价格申报信息
  v_Value                                        varchar2(4000);             --程序处理动作
  v_project_code                                  varchar2(50);
  v_Project_name                                  varchar2(500);
  v_project_id                                    number;
 -- v_Project_type                                 varchar2(50);
  v_APPLY_ID                                     NUMBER;                     --生成的价格申报头ID
  v_apply_code                                   varchar2(30);               --取到的申报编号
  v_APPLY_LINE_ID                                NUMBER;                     --生成的价格申报行ID
  v_Productline_Id                               varchar2(50);
  v_Productline_Code                             varchar2(50);
  v_Sales_Center_Id                              varchar2(50);
  v_Sales_Center_Name                            varchar2(500);
  v_Customer_Id                                  varchar2(50);
  v_Customer_Name                                varchar2(500);
  v_Account_Id                                   NUMBER;
  v_Account_Name                                 varchar2(500);
  V_BD_PRICE_APPLY_ID                            NUMBER;                     --生成的价格批文ID
  V_BD_PRICE_APPLY_CODE                          VARCHAR2(32);               --生成的价格批文号
  V_BD_PRICE_LINE_ID                             NUMBER;                     --价格批文行ID
  V_PG_LAST_PRICE_APPLY_ID                       NUMBER;                     --上次调整ID
  V_PG_ORI_PRICE_APPLY_ID                        NUMBER;                     --原申报ID
  V_PG_APPLY_CODE_OLD                            VARCHAR2(50);               --原价格申报code
  V_PG_APPLY_ID                                  NUMBER;                     --原价格申报ID
  v_Account_Code                                 varchar2(50);
  v_item_Id                                      varchar2(50);
  v_item_Name                                    varchar2(500);
  v_default_unit                                 varchar2(50);
  v_list_price                                   number;
  v_low_price                                    number;
  v_lowest_price                                 number;
  V_PG_PRICE                                     NUMBER;
  V_DISCOUNT                                     NUMBER;
  V_MONTH_DISCOUNT                               NUMBER;
  V_CX_FLAG                                      VARCHAR2(10);
  v_Project_Type                                 VARCHAR2(12);
  v_Area_Manage                                  t_pg_business.area_manager%type;
  v_Area_Manage_Phone                            t_pg_business.area_manager_phone%type;

  R_PG_PRICE_APPLY_LINE_OLD_ONE T_PG_PRICE_APPLY_LINE%Rowtype;            --记录一条旧的价格申报行数据
  V_PAL_RECORD                                   NUMBER;                  --旧的价格申报行记录数
  V_APPLY_ID_OLD                                 NUMBER;                  --旧的价格申报头申报ID
  V_IS_ADJUST                                    VARCHAR2(10);            --价格申报行表是否是调整列
  V_HAS_PICK_UP_CNT                              NUMBER;                  --价格申报行已提货数量
  V_LOCK_CNT                                     NUMBER;                  --价格申报行锁定数量
  v_Begin_Date                                   Date;                    --申报生效日期
  v_End_Date                                     Date;                    --申报失效日期
  
  ----------------------------2016-8-9---------------
  V_NEW_MIDDLE_AMOUNT                            NUMBER;                  --反算的中间费用
  V_NEW_MIDDLE_DISCOUNT                          NUMBER;                  --反算的中间折扣
  V_NEW_PRICE_DATE                               DATE;                    --按当前时间查询审批底价
  V_NEW_MIDDLE_COST                              NUMBER;
  ----------------------------------------------------
  
  ------------------销司需求 2017-4-25--------------------------
  V_INTF_APPLY_ID                                INTF_PG_PRICE_APPLY_HEAD.APPLY_ID%TYPE;
  V_INTF_APPLY_CODE                              INTF_PG_PRICE_APPLY_HEAD.APPLY_CODE%TYPE;
  V_IS_UPDATE                                    VARCHAR2(32);
  V_PG_PRODUCT_LINE                              VARCHAR2(32);
  V_GROUP_MARK                                   VARCHAR2(32);
  V_TMP_COUNT                                    NUMBER;
  V_APPENDIX_COUNT           NUMBER; --附件数
  V_APPENDIX_ID              T_PG_PRICE_APPLY_HEAD.APPENDIX_ID%TYPE;--附件ID
  R_PG_PRICE_APPENDIX        C_PG_PRICE_APPLY_APPENDIX%ROWTYPE;
  V_IF_NEED_DISCOUNT         VARCHAR2(32);
  V_BEFORE_PRICE             NUMBER;
  V_BEFORE_QUANTITY          NUMBER;
  
  V_IS_STORE                 VARCHAR2(2);--是否备货机
  V_APPLY_STORE_CODE         VARCHAR2(100);--被引用的备货机单号
  
  v_intf_item_count number;
  v_big_panel t_pg_price_apply_head.big_panel%Type;
  ---------------------------------------------------------------
  Begin
     p_Result := v_Success;
     V_IS_UPDATE := 'N';
     V_TMP_COUNT := 0;
   Begin
     v_Value := '锁定价格申报接口头表失败！';
     Select i.*
     into r_Pg_Price_Apply_Head
     From INTF_PG_PRICE_APPLY_HEAD i
     Where i.INTF_APPLY_ID = p_Price_Apply_Id
     And  i.INTF_STATUS = 'N'
     AND I.IS_ADJUST = 'Y'
     for update nowait;
    Exception
      when others then
      p_Result := v_Value || v_Nl || sqlerrm;
   End;
   
   --add by tangjz2 2018-06-04
   --备货工程、或者引用备货工程的价格申报不允许调整
   if r_Pg_Price_Apply_Head.Apply_Code is not null then
     Begin
       v_Value := '查询价格申报单号失败！';
       select nvl(a.is_store,'N'),a.apply_store_code into V_IS_STORE,V_APPLY_STORE_CODE from T_PG_PRICE_APPLY_HEAD a where a.apply_code = r_Pg_Price_Apply_Head.Apply_Code;
       if V_IS_STORE = 'Y' then
          P_RESULT := '属于备货工程的价格申报不允许调整';
          return;
        elsif V_APPLY_STORE_CODE is not null then
          P_RESULT := '引用备货工程的价格申报不允许调整';
          return;
        end if;
     Exception
     when others then
        p_Result := v_Value || v_Nl || sqlerrm;
        return;
     End;
   end if;  
   
   --add by tangjz2 2018-07-13
   --对于已提货或有锁定数量的，不允许删除型号，根据行ID和产品型号判断
    if P_RESULT = v_Success THEN
      v_Value := '不允许删除已提货或有锁定数量的产品，';
      FOR DETAIL_ITEM IN (select a.* from T_BD_PRICE_APPLY_DETAIL a where 
                                           a.price_apply_id =  (select h.BD_PRICE_APPLY_ID from t_pg_price_apply_head h,INTF_PG_PRICE_APPLY_HEAD i where 
                                                                 h.apply_code = i.apply_code and i.intf_apply_id = r_Pg_Price_Apply_Head.Old_Apply_Id)
                                       and (a.used_cnt > 0 or a.lock_cnt >0)) LOOP
          select count(*) into v_intf_item_count from INTF_PG_PRICE_APPLY_LINE l where l.intf_apply_id = r_Pg_Price_Apply_Head.Intf_Apply_Id and l.item_code = DETAIL_ITEM.Item_Code;
          if v_intf_item_count = 0 then
            v_Value := v_Value || '产品编码：' || DETAIL_ITEM.Item_Code || '，已提货：' || DETAIL_ITEM.Used_Cnt || '，已锁定：' || DETAIL_ITEM.Lock_Cnt || ';';
            P_RESULT := v_Value;
          end if;   
          if length(v_Value) > 1000 then
            P_RESULT := v_Value;
            return;
          end if;                 
      end loop;
      if P_RESULT != v_Success then
        P_RESULT := v_Value;
        return;
      end if;                           
    end if;
      
   -----ADD BY WANGCONG 2017-4-25---
   --查询系统参数
   --取团购标识
   BEGIN
     V_VALUE := '查询团购标识：';
     PKG_BD.P_GET_PARAMETER_VALUE('PG_GROUP_BUY_MARK',
                                  r_Pg_Price_Apply_Head.ENTITY_ID,
                                  Null, 
                                  Null,
                                  V_GROUP_MARK);
   EXCEPTION
     WHEN OTHERS THEN
       p_Result := V_VALUE || '出错。' || v_Nl || SQLERRM;
   END;
   
    --是否需要月返
    BEGIN
      V_VALUE := '查询是否需要月返：';
      PKG_BD.P_GET_PARAMETER_VALUE('PG_IF_NEED_DISCOUNT',
                                    r_Pg_Price_Apply_Head.ENTITY_ID,
                                    Null,
                                    Null,
                                    V_IF_NEED_DISCOUNT);
    EXCEPTION
      WHEN OTHERS THEN
        P_RESULT := V_VALUE || '出错。' || v_Nl || SQLERRM;
    END; 
    
    --查询系统参数
   BEGIN
      V_VALUE := '获取主体参数';
      PKG_BD.P_GET_PARAMETER_VALUE('PG_PRODUCT_LINE',
                                    r_Pg_Price_Apply_Head.ENTITY_ID,
                                    Null,
                                    Null,
                                    V_PG_PRODUCT_LINE);
   EXCEPTION
     WHEN OTHERS THEN
       p_Result := V_VALUE || '失败。' || v_Nl || SQLERRM;
   END;
   
   -------------------判断是否是更新操作2017-4-25------
   V_INTF_APPLY_CODE := r_Pg_Price_Apply_Head.Apply_Code;
   IF V_INTF_APPLY_CODE IS NOT NULL THEN
     V_IS_UPDATE := 'Y';
     SELECT H.APPLY_ID
     INTO V_INTF_APPLY_ID
     FROM T_PG_PRICE_APPLY_HEAD H
     WHERE H.APPLY_CODE = V_INTF_APPLY_CODE;
   END IF;
   -----------------------------------------------

   IF p_Result = v_Success then
          Begin
     v_Value := '校验价格申报信息失败';
     Select b.business_id,b.Project_Code,b.project_name,b.area_manager,b.area_manager_phone,b.big_panel
     into v_project_id,v_project_code,v_Project_name,v_Area_Manage,v_Area_Manage_Phone,v_big_panel
     From t_Pg_Business b
     Where b.ori_business_code = r_Pg_Price_Apply_Head.Ori_Business_Code and nvl(b.document_type,'0') in ('0','2')
     and B.BUSINESS_ID = (
                SELECT max(s.BUSINESS_ID) from T_PG_BUSINESS s
              WHERE s.ORI_BUSINESS_CODE = r_Pg_Price_Apply_Head.Ori_Business_Code
                and nvl(s.document_type,'0') in ('0','2')
            );
     
     -- PRODUCTLINE_CODE                 T_PG_PRODUCT_LINE
     ---MODIFY BY WANGCONG 2017-4-25 --------
     IF V_PG_PRODUCT_LINE = 'Y' THEN
      select t.productline_id, t.productline_code
        into v_Productline_Id, v_Productline_Code
        from T_PG_PRODUCT_LINE t
       where t.productline_name = r_Pg_Price_Apply_Head.Productline_Name
         and t.entity_id = r_Pg_Price_Apply_Head.Entity_Id;
     END IF;
     ------------------------------------------
     
    --  sales_center_code                up_org_unit
      select t.unit_id,t.name
      into v_Sales_Center_Id,v_Sales_Center_Name
      from up_org_unit  t
      where t.code = r_Pg_Price_Apply_Head.sales_center_code
       and t.entity_id = r_Pg_Price_Apply_Head.Entity_Id;
    --  CUSTOMER_CODE                    t_customer_header
      select t.customer_id,t.customer_name
      into v_Customer_Id, v_Customer_Name
      from t_customer_header  t
      where t.customer_code = r_Pg_Price_Apply_Head.CUSTOMER_CODE;
    --  ACCOUNT_CODE                     V_Customer_Account_Salecenter
      select v.account_id,v.account_code into v_Account_Id,v_Account_Code
      from cims.v_customer_account_salecenter v
      where v.customer_code  = r_Pg_Price_Apply_Head.Customer_Code
      and v.entity_id = r_Pg_Price_Apply_Head.Entity_Id
      and v.active_flag  = 'Active'
      and v.orgActive_flag = 'Active'
      and v.account_status = '1'
      and v.sales_center_code = r_Pg_Price_Apply_Head.sales_center_code;

     Exception
      when others then
      p_Result := v_Value || v_Nl || sqlerrm;
     End;
   End IF;

      --工程类型转码
   If p_Result = v_Success Then
      Begin
        v_Value := '工程类型转码：';
       /* Select u.Code_Value
        Into v_Project_Type
        From Up_CodeList u
        Where u.Code_Name like '%'|| r_Pg_Price_Apply_Head.PROJECT_TYPE || '%' And u.Codetype='tpgProjectType';*/
        SELECT L.CODE_VALUE
          INTO v_Project_Type
          FROM V_UP_CODELIST L
         WHERE L.CODE_NAME LIKE
               '%' || r_Pg_Price_Apply_Head.PROJECT_TYPE || '%'
           AND L.CODETYPE = 'tpgProjectType'
           AND L.ENTITY_ID = r_Pg_Price_Apply_Head.Entity_Id;  
    Exception
        When Others Then
          p_Result := v_Value || '工程类型' || To_Char(r_Pg_Price_Apply_Head.PROJECT_TYPE) || '不存在或者已失效。';
      End;
   End If;

   --申报生效日期校验
   If r_Pg_Price_Apply_Head.Begin_Date is NULL Then
      v_Begin_Date := trunc(sysdate);
   Else
      v_Begin_Date := trunc(r_Pg_Price_Apply_Head.Begin_Date);
   End If;
   --申报失效日期校验
   If r_Pg_Price_Apply_Head.End_Date is NULL Then
      v_End_Date := to_date(to_char(SYSDATE,'yyyy')||'12/31','yyyy/MM/dd');
   Else
      v_End_Date := trunc(r_Pg_Price_Apply_Head.End_Date);
   End If;

   V_NEW_PRICE_DATE := trunc(sysdate);
   
   
    --处理附件信息
    --查询附件接口表行数
    SELECT COUNT(*)
      INTO V_APPENDIX_COUNT
      FROM INTF_PG_APPENDIX_CCS AC
     WHERE AC.INTF_TABLE_ID = P_PRICE_APPLY_ID;
     
    IF V_APPENDIX_COUNT > 0 THEN
      --生成附件ID
      SELECT 'PRICEAPP' || S_PG_PRICE_APPENDIX.NEXTVAL
        INTO V_APPENDIX_ID
        FROM DUAL;
      
      OPEN C_PG_PRICE_APPLY_APPENDIX;
      LOOP
        FETCH C_PG_PRICE_APPLY_APPENDIX
          INTO R_PG_PRICE_APPENDIX;
        EXIT WHEN C_PG_PRICE_APPLY_APPENDIX%NOTFOUND OR P_RESULT <> v_Success;
          
        BEGIN
          V_VALUE := '同步附件信息到CIMS附件表：';
          INSERT INTO IMS_FILEINFO_INTERFACE
            (ID, BUSINESS_ID, BUSINESS_TYPE, FILE_PATH,FILE_NAME, CREATED_DATE)
          VALUES
            (SEQ_IMS_FILEINFO.NEXTVAL,
             V_APPENDIX_ID,
             'pgPriceAppendix',
             R_PG_PRICE_APPENDIX.FILE_PATH,
             R_PG_PRICE_APPENDIX.FILE_NAME,
             SYSDATE);
        EXCEPTION
          WHEN OTHERS THEN
            P_RESULT := V_VALUE || '出错。' || v_Nl || SQLERRM;
        END;
     END LOOP;  
    END IF;
   
   
   --锁定价格批文
   IF p_Result = v_Success  THEN
     BEGIN
       v_Value := '锁定价格批文';
       V_PG_LAST_PRICE_APPLY_ID := r_Pg_Price_Apply_Head.Last_Apply_Id;
       V_PG_ORI_PRICE_APPLY_ID := r_Pg_Price_Apply_Head.Old_Apply_Id;
       IF V_PG_LAST_PRICE_APPLY_ID IS NOT NULL
         THEN
         --不是第一次调整根据上次调整id查询价格批文
/*        SELECT IH.APPLY_CODE
         INTO V_PG_APPLY_CODE_OLD
           FROM INTF_PG_PRICE_APPLY_HEAD IH
          WHERE IH.INTF_APPLY_ID = V_PG_LAST_PRICE_APPLY_ID;*/

         SELECT IH.*
         INTO R_PG_PRICE_APPLY_HEAD_OLD
         FROM INTF_PG_PRICE_APPLY_HEAD IH
         WHERE IH.INTF_APPLY_ID = V_PG_LAST_PRICE_APPLY_ID;


         SELECT PH.BD_PRICE_APPLY_ID, PH.BD_PRICE_APPLY_CODE, PH.APPLY_ID
           INTO V_BD_PRICE_APPLY_ID, V_BD_PRICE_APPLY_CODE, V_APPLY_ID_OLD
           FROM T_PG_PRICE_APPLY_HEAD PH
          WHERE PH.APPLY_CODE = R_PG_PRICE_APPLY_HEAD_OLD.APPLY_CODE;

         --锁定价格批文
         UPDATE T_BD_PRICE_APPLY TBPA
            SET TBPA.LOCK_FLAG = 'Y',
                TBPA.LOCK_REMARK = '系统自动锁定：申报调整',
                TBPA.LOCKED_BY = 'CCS',
                TBPA.LOCKED_DATE = SYSDATE
          WHERE TBPA.PRICE_APPLY_ID = V_BD_PRICE_APPLY_ID;

       ELSIF V_PG_LAST_PRICE_APPLY_ID IS NULL AND V_PG_ORI_PRICE_APPLY_ID IS NOT NULL
         THEN

         SELECT IH.*
           INTO R_PG_PRICE_APPLY_HEAD_OLD
           FROM INTF_PG_PRICE_APPLY_HEAD IH
          WHERE IH.INTF_APPLY_ID = V_PG_ORI_PRICE_APPLY_ID;


         SELECT PH.BD_PRICE_APPLY_ID, PH.BD_PRICE_APPLY_CODE, PH.APPLY_ID
           INTO V_BD_PRICE_APPLY_ID, V_BD_PRICE_APPLY_CODE, V_APPLY_ID_OLD
          FROM T_PG_PRICE_APPLY_HEAD PH
         WHERE PH.APPLY_CODE = R_PG_PRICE_APPLY_HEAD_OLD.APPLY_CODE;

         --锁定价格批文
         UPDATE T_BD_PRICE_APPLY TBPA
            SET TBPA.LOCK_FLAG = 'Y',
                TBPA.LOCK_REMARK = '系统自动锁定：申报调整',
                TBPA.LOCKED_BY = 'CCS',
                TBPA.LOCKED_DATE = SYSDATE
          WHERE TBPA.PRICE_APPLY_ID = V_BD_PRICE_APPLY_ID;

         END IF;
       END;
   END IF;


   
   IF V_IS_UPDATE = 'N' THEN
     ------新增操作
   IF p_Result = v_Success then
   Begin
    v_Value := '开始插入价格申报头表数据';
    Select  s_pg_price_apply_header.nextval  into v_APPLY_ID From dual;
    --申报编码
    V_PG_APPLY_CODE_OLD := R_PG_PRICE_APPLY_HEAD_OLD.Apply_Code;
    pkg_bd.P_GET_BILL_NO('pgPriceAdjust',V_PG_APPLY_CODE_OLD,r_Pg_Price_Apply_Head.ENTITY_ID,null,v_apply_code);

    --更新原申报单数据
    UPDATE T_PG_PRICE_APPLY_HEAD TPAH
       SET TPAH.APPLY_CODE = v_apply_code,TPAH.DOCUMENT_TYPE = '1',TPAH.STATUS = '10'
     WHERE TPAH.APPLY_ID = R_PG_PRICE_APPLY_HEAD_OLD.APPLY_ID;

    UPDATE INTF_PG_PRICE_APPLY_HEAD IPAH
       SET IPAH.APPLY_CODE = v_apply_code
     WHERE IPAH.INTF_APPLY_ID = R_PG_PRICE_APPLY_HEAD_OLD.INTF_APPLY_ID;


    insert into T_PG_PRICE_APPLY_HEAD
                                    (entity_id,
                                     APPLY_ID,
                                     apply_code,
                                     productline_id,
                                     productline_code,
                                     productline_name,
                                     sales_center_id,
                                     sales_center_code,
                                     sales_center_name,
                                     apply_date,
                                     customer_id,
                                     customer_code,
                                     customer_name,
                                     account_id,
                                     account_code,
                                     business_id,
                                     project_code,
                                     project_name,
                                     user_firm,
                                     user_phone,
                                     user_name,
                                     project_address,
                                     agent_id,
                                     agent_code,
                                     agent_name,
                                     project_type,
                                     Begin_date,
                                     end_date,
                                     special_need,
                                     other_desc,
                                     created_by,
                                     creation_date,
                                     last_updated_by,
                                     last_update_date,
                                     program_updated_by,
                                     program_update_date,
                                     version,
                                     area_follow,
                                     is_adjust,
                                     old_APPLY_ID,
                                     BD_PRICE_APPLY_ID,
                                     AUDIT_NODE,
                                     STATUS,
                                     IS_VALID,
                                     BD_PRICE_APPLY_CODE,
                                     CCS_APPLY_ID,
                                     CCS_APPLY_CODE,
                                     DOCUMENT_TYPE,
                                     APPENDIX_ID,
                                     AREA_MANAGER,
                                     AREA_MANAGER_PHONE
                                     ,big_panel
                                     )
                               values
                                    (r_Pg_Price_Apply_Head.ENTITY_ID,
                                     v_APPLY_ID,
                                     V_PG_APPLY_CODE_OLD,
                                     v_Productline_Id,
                                     v_Productline_Code,
                                     r_Pg_Price_Apply_Head.Productline_Name,
                                     v_Sales_Center_Id,
                                     r_Pg_Price_Apply_Head.SALES_CENTER_CODE,
                                     v_Sales_Center_Name,
                                     R_PG_PRICE_APPLY_HEAD_OLD.APPLY_DATE,--r_Pg_Price_Apply_Head.Apply_Date,
                                     v_Customer_Id,
                                     r_Pg_Price_Apply_Head.CUSTOMER_CODE,
                                     v_Customer_Name,
                                     v_Account_Id,
                                     v_Account_Code,
                                     v_project_id,
                                     v_project_code,
                                     v_Project_name,
                                     r_Pg_Price_Apply_Head.USER_FIRM,
                                     r_Pg_Price_Apply_Head.USER_PHONE,
                                     r_Pg_Price_Apply_Head.USER_NAME,
                                     r_Pg_Price_Apply_Head.PROJECT_ADDRESS,
                                     r_Pg_Price_Apply_Head.AGENT_ID,
                                     r_Pg_Price_Apply_Head.AGENT_CODE,
                                     r_Pg_Price_Apply_Head.AGENT_NAME,
                                     v_Project_Type,
                                     v_Begin_Date,                                                                 -- r_Pg_Price_Apply_Head.BEGIN_DATE,
                                     v_End_Date,                                               --r_Pg_Price_Apply_Head.END_DATE,
                                     r_Pg_Price_Apply_Head.SPECIAL_NEED,
                                     r_Pg_Price_Apply_Head.OTHER_DESC ,
                                     'admin',
                                     sysdate,
                                     'admin',
                                     sysdate,
                                     'CCS',
                                     sysdate,
                                     '1' ,
                                     r_Pg_Price_Apply_Head.AREA_FOLLOW,
                                     r_Pg_Price_Apply_Head.IS_ADJUST,
                                     r_Pg_Price_Apply_Head.OLD_APPLY_ID,
                                     V_BD_PRICE_APPLY_ID,
                                     1,
                                     '0',
                                     'Y',
                                     V_BD_PRICE_APPLY_CODE,
                                     r_Pg_Price_Apply_Head.Ccs_Apply_Id,
                                     r_Pg_Price_Apply_Head.Ccs_Apply_Code,
                                     '2',
                                     V_APPENDIX_ID,
                                     v_Area_Manage,
                                     v_Area_Manage_Phone
                                     ,v_big_panel
                                     );
  Exception
     when others then
      p_Result := v_Value || v_Nl || sqlerrm;
  End;
  End IF;
  ELSIF V_IS_UPDATE = 'Y' THEN
    -------更新数据----
    BEGIN
      V_VALUE := '更新头表数据：';
      UPDATE T_PG_PRICE_APPLY_HEAD H SET
             H.PRODUCTLINE_ID = R_PG_PRICE_APPLY_HEAD.PRODUCTLINE_ID,
             H.PRODUCTLINE_CODE = R_PG_PRICE_APPLY_HEAD.PRODUCTLINE_CODE,
             H.PRODUCTLINE_NAME = R_PG_PRICE_APPLY_HEAD.PRODUCTLINE_NAME,
             H.SALES_CENTER_ID = R_PG_PRICE_APPLY_HEAD.SALES_CENTER_ID,
             H.SALES_CENTER_CODE = R_PG_PRICE_APPLY_HEAD.SALES_CENTER_CODE,
             H.SALES_CENTER_NAME = R_PG_PRICE_APPLY_HEAD.SALES_CENTER_NAME,
             H.APPLY_DATE = R_PG_PRICE_APPLY_HEAD_OLD.APPLY_DATE,--R_PG_PRICE_APPLY_HEAD.APPLY_DATE,
             H.CUSTOMER_ID = R_PG_PRICE_APPLY_HEAD.CUSTOMER_ID,
             H.CUSTOMER_CODE = R_PG_PRICE_APPLY_HEAD.CUSTOMER_CODE,
             H.CUSTOMER_NAME = R_PG_PRICE_APPLY_HEAD.CUSTOMER_NAME,
             H.ACCOUNT_ID = R_PG_PRICE_APPLY_HEAD.ACCOUNT_ID,
             H.ACCOUNT_CODE = R_PG_PRICE_APPLY_HEAD.ACCOUNT_CODE,
             H.BUSINESS_ID =  v_project_id,
             H.PROJECT_CODE = v_project_code,
             H.PROJECT_NAME = v_Project_name,
             H.USER_FIRM = R_PG_PRICE_APPLY_HEAD.USER_FIRM,
             H.USER_PHONE = R_PG_PRICE_APPLY_HEAD.USER_PHONE,
             H.USER_NAME = R_PG_PRICE_APPLY_HEAD.USER_NAME,
             H.PROJECT_ADDRESS = R_PG_PRICE_APPLY_HEAD.PROJECT_ADDRESS,
             H.AGENT_ID = R_PG_PRICE_APPLY_HEAD.AGENT_ID,
             H.AGENT_CODE = R_PG_PRICE_APPLY_HEAD.AGENT_CODE,
             H.AGENT_NAME = R_PG_PRICE_APPLY_HEAD.AGENT_NAME,
             H.PROJECT_TYPE = R_PG_PRICE_APPLY_HEAD.PROJECT_TYPE,
             H.BEGIN_DATE = v_Begin_Date,
             H.END_DATE = v_End_Date,
             H.SPECIAL_NEED = R_PG_PRICE_APPLY_HEAD.SPECIAL_NEED,
             H.OTHER_DESC = R_PG_PRICE_APPLY_HEAD.OTHER_DESC,
             H.CREATED_BY = 'CCS',
             H.CREATION_DATE = sysdate, 
             H.LAST_UPDATED_BY = 'CCS',
             H.LAST_UPDATE_DATE = sysdate,
             H.PROGRAM_UPDATED_BY = 'CCS',
             H.PROGRAM_UPDATE_DATE = sysdate,
             H.VERSION = '1',
             H.AREA_FOLLOW = R_PG_PRICE_APPLY_HEAD.AREA_FOLLOW,
             H.IS_ADJUST = R_PG_PRICE_APPLY_HEAD.IS_ADJUST,
             H.OLD_APPLY_ID = R_PG_PRICE_APPLY_HEAD.OLD_APPLY_ID,
             H.STATUS = '0',
             H.IS_VALID = 'Y',
             H.CCS_APPLY_ID = r_Pg_Price_Apply_Head.Ccs_Apply_Id,
             H.CCS_APPLY_CODE = r_Pg_Price_Apply_Head.Ccs_Apply_Code,
             H.APPENDIX_ID = V_APPENDIX_ID,
             h.big_panel=v_big_panel
             WHERE H.Apply_Id = V_INTF_APPLY_ID;
             
             v_APPLY_ID := V_INTF_APPLY_ID;
             V_PG_APPLY_CODE_OLD := V_INTF_APPLY_CODE;
       EXCEPTION
         WHEN OTHERS THEN
           p_Result := V_VALUE || '失败。' || v_Nl || SQLERRM;
       END;
  END IF;

  --------------------------更新行表数据 先删除原数据再新增---------------
  IF V_IS_UPDATE = 'Y' THEN
    BEGIN
      V_VALUE := '删除行表数据：';
      DELETE FROM T_PG_PRICE_APPLY_LINE TL
       WHERE TL.ITEM_CODE NOT IN
             (SELECT L.ITEM_CODE
                FROM INTF_PG_PRICE_APPLY_LINE L
               WHERE L.INTF_APPLY_ID = P_PRICE_APPLY_ID)
         AND TL.APPLY_ID = V_INTF_APPLY_ID;
    EXCEPTION
      WHEN OTHERS THEN
        p_Result := V_VALUE || '失败。' || v_Nl || SQLERRM;
    END;
  END IF;
  -------------------------------------------------------------------------
  
  IF p_Result = v_Success  then
    Open c_pg_price_apply_line;
    Loop
        Fetch c_pg_price_apply_line
          Into r_pg_price_apply_line;
        Exit When c_pg_price_apply_line%Notfound Or p_Result <> v_Success;

     --价格申报行接口表申请价，申请数量与价格申报行表审批价，审批数量对比，确定是否是调整列
     BEGIN
       v_Value := '确定是否是调整列';
       V_BEFORE_PRICE := null;
       V_BEFORE_QUANTITY := null;
       V_NEW_MIDDLE_COST :=  0;
        --查询旧的价格申报行数据
        SELECT COUNT(*)
          INTO V_PAL_RECORD
          FROM T_PG_PRICE_APPLY_LINE PL
         WHERE PL.ITEM_CODE = r_pg_price_apply_line.Item_Code
           AND PL.APPLY_ID = V_APPLY_ID_OLD
           AND PL.LAST_QUANTITY <> 0; --允许为0后，需要增加条件控制

        IF V_PAL_RECORD > 0 THEN
          SELECT *
            INTO R_PG_PRICE_APPLY_LINE_OLD_ONE
            FROM T_PG_PRICE_APPLY_LINE PL
           WHERE PL.ITEM_CODE = r_pg_price_apply_line.Item_Code
             AND PL.APPLY_ID = V_APPLY_ID_OLD;
             
             V_BEFORE_PRICE := R_PG_PRICE_APPLY_LINE_OLD_ONE.Approval_Price;
             V_BEFORE_QUANTITY := R_PG_PRICE_APPLY_LINE_OLD_ONE.Last_Quantity;
             
        ---------------------------------增加只调整数量的场景----------2016/8/9----
           IF round(R_PG_PRICE_APPLY_LINE_OLD_ONE.LAST_PRICE, 2) = round(r_pg_price_apply_line.apply_price, 2)
             AND R_PG_PRICE_APPLY_LINE_OLD_ONE.LAST_QUANTITY <> r_pg_price_apply_line.apply_quantity THEN

             --只调整数量
             V_IS_ADJUST := 'C';
           ELSIF round(R_PG_PRICE_APPLY_LINE_OLD_ONE.LAST_PRICE, 2) <> round(r_pg_price_apply_line.apply_price, 2) THEN
             --价格有调整
             V_IS_ADJUST := 'P';

           ELSIF round(R_PG_PRICE_APPLY_LINE_OLD_ONE.LAST_PRICE, 2) = round(r_pg_price_apply_line.apply_price, 2)
             AND R_PG_PRICE_APPLY_LINE_OLD_ONE.LAST_QUANTITY = r_pg_price_apply_line.apply_quantity THEN

             --表示接口表里此行数据不是调整列
             V_IS_ADJUST := 'N';

           END IF;
        ELSIF V_PAL_RECORD = 0 THEN
         --表示接口表里的此行数据是新增的
         V_IS_ADJUST := 'P';
        END IF;
        ---------------------------------------------------------------------------
     EXCEPTION
       WHEN OTHERS THEN
         p_Result := v_Value || '失败!' || v_Nl || sqlerrm;
     END;

     Begin
       v_Value := '开始插入价格申报行表数据';

       BEGIN
         v_Value := '从价格批文行里获得对应已提货数量';
         IF V_PAL_RECORD > 0 THEN
           SELECT PAD.USED_CNT,PAD.LOCK_CNT
             INTO V_HAS_PICK_UP_CNT,V_LOCK_CNT
             FROM T_BD_PRICE_APPLY_DETAIL PAD
            WHERE PAD.APPLY_DETAIL_ID = R_PG_PRICE_APPLY_LINE_OLD_ONE.BD_PRICE_APPLY_LINE_ID;
         ELSIF V_PAL_RECORD = 0 THEN
           V_HAS_PICK_UP_CNT := NULL;
         END IF;
       EXCEPTION
         WHEN OTHERS THEN
           p_Result := v_Value || '失败！' || v_Nl || sqlerrm;
           V_HAS_PICK_UP_CNT := NULL;
       END;
       
       BEGIN
            v_Value := '查询产品审批底价';
             select l.list_price
             into v_low_price
               from t_bd_price_line l
              where l.item_code = r_pg_price_apply_line.item_code
                and l.price_list_id =
                    (select r.price_list_1
                       from t_pg_price_list_rel r
                      where r.sales_center_code = r_Pg_Price_Apply_Head.Sales_Center_Code
                        and r.entity_id =  r_Pg_Price_Apply_Head.Entity_Id)
                and l.entity_id = r_Pg_Price_Apply_Head.Entity_Id
                and trunc(V_NEW_PRICE_DATE,'dd') >= l.begin_date
                and (trunc(V_NEW_PRICE_DATE,'dd') <= l.end_date or l.end_date is null)
                and l.active_flag = 'Y';
         Exception
          when others then
           p_Result := '查询产品审批底价失败' || v_Nl || sqlerrm;
         end;

         BEGIN
           v_Value := '查询产品最低价';
            select min(l.list_price)
            into v_lowest_price
            from t_bd_price_line l
            where l.price_list_id in
              (select nvl(r.price_list_1, 0) from t_pg_price_list_rel r where r.sales_center_code = r_Pg_Price_Apply_Head.Sales_Center_Code
              union select nvl(r.price_list_2, 0) from t_pg_price_list_rel r where r.sales_center_code = r_Pg_Price_Apply_Head.Sales_Center_Code
              union select nvl(r.price_list_3, 0) from t_pg_price_list_rel r where r.sales_center_code = r_Pg_Price_Apply_Head.Sales_Center_Code
              union select nvl(r.price_list_4, 0) from t_pg_price_list_rel r where r.sales_center_code = r_Pg_Price_Apply_Head.Sales_Center_Code
              union select nvl(r.price_list_5, 0) from t_pg_price_list_rel r where r.sales_center_code = r_Pg_Price_Apply_Head.Sales_Center_Code
              union select nvl(r.price_list_6, 0) from t_pg_price_list_rel r where r.sales_center_code = r_Pg_Price_Apply_Head.Sales_Center_Code
              union select nvl(r.price_list_7, 0) from t_pg_price_list_rel r where r.sales_center_code = r_Pg_Price_Apply_Head.Sales_Center_Code
              union select nvl(r.price_list_8, 0) from t_pg_price_list_rel r where r.sales_center_code = r_Pg_Price_Apply_Head.Sales_Center_Code
              union select nvl(r.price_list_9, 0) from t_pg_price_list_rel r where r.sales_center_code = r_Pg_Price_Apply_Head.Sales_Center_Code)
            and l.item_code = r_pg_price_apply_line.item_code
            and l.begin_date <= trunc(sysdate)
            and (l.end_date >= trunc(sysdate) or l.end_date is null);
         Exception
          when others then
           p_Result := '查询产品最低价失败' || v_Nl || sqlerrm;
         END;
         
         
       IF V_IS_ADJUST = 'P' AND p_Result = v_Success  THEN

         begin
           select t.item_id,t.item_name,t.defaultunit
           into  v_item_Id,v_item_Name,v_default_unit
           from t_bd_item t
           where t.item_code = r_pg_price_apply_line.ITEM_CODE
           and t.entity_id = r_Pg_Price_Apply_Head.entity_id;
         Exception
          when others then
           p_Result := '校验价格申报信息失败' || v_Nl || sqlerrm;
         end;

         --查找面价
         BEGIN
          v_Value := '查询产品面价';
          pkg_bd_price.P_GET_PRICE(v_Account_Id,r_pg_price_apply_line.ITEM_CODE,TO_CHAR(SYSDATE,'YYYYMMDD'),NULL,r_pg_price_apply_line.ENTITY_ID,V_PG_PRICE,V_DISCOUNT,V_MONTH_DISCOUNT,V_CX_FLAG);
         Exception
          when others then
           p_Result := '查询产品面价失败' || v_Nl || sqlerrm;
         END;

         IF V_PG_PRICE IS NULL THEN
           p_Result := '价格申报明细产品编码'|| r_pg_price_apply_line.Item_Code ||'未定义价格';
         ELSIF r_pg_price_apply_line.APPLY_PRICE > V_PG_PRICE AND V_IF_NEED_DISCOUNT = 'Y' THEN
           p_Result := '价格申报明细产品编码'|| r_pg_price_apply_line.item_code ||'的申请价不能大于直供价';
         END IF;

         IF V_PAL_RECORD > 0 THEN
           BEGIN
              v_Value := '查询明细行对应的批文行信息';
              SELECT L.BD_PRICE_APPLY_LINE_ID
                INTO V_BD_PRICE_LINE_ID
                FROM T_PG_PRICE_APPLY_LINE L
               WHERE L.APPLY_ID = V_APPLY_ID_OLD
                 AND L.ITEM_CODE =  r_pg_price_apply_line.ITEM_CODE;
           Exception
            when others then
             p_Result := '查询明细行对应的批文行信息失败' || v_Nl || sqlerrm;
           END;
         ELSE
           V_BD_PRICE_LINE_ID := NULL;
         END IF;

         IF p_Result = v_Success THEN
            --更新数据并返回受影响行数
            IF V_IS_UPDATE = 'Y' THEN
                BEGIN
                  v_Value := '更新行表数据：';
                  update t_pg_price_apply_line l
                     set item_id                = v_item_Id,
                         item_code              = r_pg_price_apply_line.item_code,
                         item_desc              = v_item_Name,
                         uom_code               = v_default_unit,
                         list_price             = V_PG_PRICE,
                         contract_price         = r_pg_price_apply_line.contract_price,
                         apply_price            = r_pg_price_apply_line.apply_price,
                         apply_quantity         = r_pg_price_apply_line.apply_quantity,
                         apply_amount           = r_pg_price_apply_line.apply_price *
                                                  r_pg_price_apply_line.apply_quantity,
                         low_price              = v_low_price,
                         catch_date             = r_pg_price_apply_line.catch_date,
                         created_by             = 'CCS',
                         creation_date          = sysdate,
                         last_updated_by        = 'CCS',
                         last_update_date       = sysdate,
                         program_updated_by     = 'CCS',
                         program_update_date    = sysdate,
                         is_adjust              = V_IS_ADJUST,
                         bd_price_apply_line_id = V_BD_PRICE_LINE_ID,
                         lowest_price           = v_lowest_price,
                         has_pick_up_cnt        = V_HAS_PICK_UP_CNT,
                         lock_cnt               = V_LOCK_CNT,
                         version                = 1,
                         last_quantity          = null,
                         middle_amount          = null,
                         middle_discount        = null,
                         middle_cost            = null,
                         middle_cost_discount   = null,
                         discount               = null,
                         before_price           = null,
                         before_quantity        = null,
                         last_amount            = null,
                         approval_price         = null,
                         price_difference       = null,
                         price_one              = null,
                         quantity_one           = null,
                         price_two              = null,
                         quantity_two           = null,
                         price_three            = null,
                         quantity_three         = null,
                         price_four             = null,
                         quantity_four          = null,
                         price_five             = null,
                         quantity_five          = null,
                         price_six              = null,
                         quantity_six           = null,
                         price_seven            = null,
                         quantity_seven         = null,
                         price_eight            = null,
                         quantity_eight         = null,
                         price_nine             = null,
                         quantity_nine          = null,
                         month_discount         = (1 - r_pg_price_apply_line.apply_price/V_PG_PRICE)*100,
                         DELIVERY_PRICE = R_PG_PRICE_APPLY_LINE.DELIVERY_PRICE
                   where l.apply_id = v_APPLY_ID
                     and l.item_code = r_pg_price_apply_line.item_code;
                  V_TMP_COUNT :=  SQL%ROWCOUNT;
                EXCEPTION
                  WHEN OTHERS THEN
                    p_Result := v_Value || '出错！' || SQLERRM;
                END;
            END IF;
            
            IF V_TMP_COUNT = 0 AND p_Result = v_Success then    
                Select s_pg_price_apply_line.nextval into  v_APPLY_LINE_ID   From  dual;
                insert into T_PG_PRICE_APPLY_LINE(
                                                 entity_id,
                                                 APPLY_LINE_ID,
                                                 apply_id,
                                                 item_id,
                                                 item_code,
                                                 item_desc,
                                                 UOM_CODE,
                                                 LIST_PRICE,
                                                 contract_price,
                                                 apply_price,
                                                 APPLY_QUANTITY,
                                                 apply_amount,
                                                 LOW_PRICE,
                                                 catch_date,
                                                 created_by,
                                                 creation_date,
                                                 last_updated_by,
                                                 last_update_date,
                                                 program_updated_by,
                                                 program_update_date,
                                                 IS_ADJUST,
                                                 BD_PRICE_APPLY_LINE_ID,
                                                 LOWEST_PRICE,
                                                 HAS_PICK_UP_CNT,
                                                 lock_cnt,
                                                 version,
                                                 before_price,
                                                 before_quantity,
                                                 month_discount,
                                                 DELIVERY_PRICE)
                                          values
                                                (r_pg_price_apply_line.ENTITY_ID,
                                                 v_APPLY_LINE_ID,
                                                 v_APPLY_ID,
                                                 v_item_Id,
                                                 r_pg_price_apply_line.ITEM_CODE,
                                                 v_item_Name,
                                                 v_default_unit,
                                                 V_PG_PRICE,
                                                 r_pg_price_apply_line.CONTRACT_PRICE ,
                                                 r_pg_price_apply_line.APPLY_PRICE,
                                                 r_pg_price_apply_line.APPLY_QUANTITY,
                                                 r_pg_price_apply_line.APPLY_PRICE*r_pg_price_apply_line.APPLY_QUANTITY,
                                                 v_low_price,
                                                 r_pg_price_apply_line.CATCH_DATE,
                                                 'admin',
                                                 sysdate,
                                                 'CCS',
                                                 sysdate,
                                                 'CCS',
                                                 sysdate,
                                                 V_IS_ADJUST,
                                                 V_BD_PRICE_LINE_ID,
                                                 v_lowest_price,
                                                 V_HAS_PICK_UP_CNT,
                                                 V_LOCK_CNT,
                                                 1,
                                                 V_BEFORE_PRICE,
                                                 V_BEFORE_QUANTITY,
                                                 (1 - r_pg_price_apply_line.apply_price/V_PG_PRICE)*100,
                                                 R_PG_PRICE_APPLY_LINE.DELIVERY_PRICE);
                                         -- from  INTF_PG_PRICE_APPLY_LINE t
                                          -- Where  t.intf_apply_id = p_Price_Apply_Id
                                         -- And    t.INTF_STATUS= 'N''
           END IF;                   
         END IF;
         ----增加只调整数量的场景-----------------------2016/8/9-----------------------------------------------------------------
       ELSIF V_IS_ADJUST = 'C' AND p_Result = v_Success  THEN
         --根据开单价反算中间费用和中间折扣
         IF R_PG_PRICE_APPLY_LINE_OLD_ONE.LAST_PRICE IS NOT NULL AND R_PG_PRICE_APPLY_LINE_OLD_ONE.APPROVAL_PRICE IS NOT NULL AND r_pg_price_apply_line.apply_quantity IS NOT NULL AND R_PG_PRICE_APPLY_LINE_OLD_ONE.LIST_PRICE IS NOT NULL THEN 
           --中间费用（返利）
           V_NEW_MIDDLE_AMOUNT := (NVL(R_PG_PRICE_APPLY_LINE_OLD_ONE.MIDDLE_AMOUNT,0)/R_PG_PRICE_APPLY_LINE_OLD_ONE.LAST_QUANTITY)*NVL(R_PG_PRICE_APPLY_LINE.APPLY_QUANTITY,0);
           --V_NEW_MIDDLE_DISCOUNT := ROUND((V_NEW_MIDDLE_AMOUNT/R_PG_PRICE_APPLY_LINE_OLD_ONE.LIST_PRICE),2);
           --修改中间折扣 = 单台中间费用/面价*100
           V_NEW_MIDDLE_DISCOUNT := (R_PG_PRICE_APPLY_LINE_OLD_ONE.MIDDLE_AMOUNT/R_PG_PRICE_APPLY_LINE_OLD_ONE.LAST_QUANTITY/R_PG_PRICE_APPLY_LINE_OLD_ONE.LIST_PRICE) * 100;
           --中间费用（费用）
           --V_NEW_MIDDLE_COST := (NVL(R_PG_PRICE_APPLY_LINE_OLD_ONE.MIDDLE_COST,0)/R_PG_PRICE_APPLY_LINE_OLD_ONE.LAST_QUANTITY)*NVL(R_PG_PRICE_APPLY_LINE.APPLY_QUANTITY,0);
           V_NEW_MIDDLE_COST := NVL(R_PG_PRICE_APPLY_LINE_OLD_ONE.MIDDLE_COST_PIECES,0) * NVL(R_PG_PRICE_APPLY_LINE.APPLY_QUANTITY,0);
           
           IF p_Result = v_Success THEN
             IF V_IS_UPDATE = 'Y' THEN
               BEGIN
                 v_Value := '更新行表数据：';
                 update t_pg_price_apply_line l
                    set item_id                = R_PG_PRICE_APPLY_LINE_OLD_ONE.ITEM_ID,
                        item_code              = R_PG_PRICE_APPLY_LINE_OLD_ONE.ITEM_CODE,
                        item_desc              = R_PG_PRICE_APPLY_LINE_OLD_ONE.ITEM_DESC,
                        uom_code               = R_PG_PRICE_APPLY_LINE_OLD_ONE.UOM_CODE,
                        list_price             = R_PG_PRICE_APPLY_LINE_OLD_ONE.LIST_PRICE,
                        contract_price         = R_PG_PRICE_APPLY_LINE_OLD_ONE.CONTRACT_PRICE,
                        apply_price            = R_PG_PRICE_APPLY_LINE_OLD_ONE.APPLY_PRICE,
                        last_price             = R_PG_PRICE_APPLY_LINE_OLD_ONE.LAST_PRICE,
                        low_price              = v_low_price,--R_PG_PRICE_APPLY_LINE_OLD_ONE.LOW_PRICE,
                        apply_quantity         = r_pg_price_apply_line.Apply_Quantity,
                        last_quantity          = r_pg_price_apply_line.Apply_Quantity,
                        middle_amount          = V_NEW_MIDDLE_AMOUNT,
                        middle_discount        = V_NEW_MIDDLE_DISCOUNT,
                        middle_cost            = V_NEW_MIDDLE_COST,
                        middle_cost_discount   = R_PG_PRICE_APPLY_LINE_OLD_ONE.MIDDLE_COST_DISCOUNT,
                        middle_cost_pieces     = R_PG_PRICE_APPLY_LINE_OLD_ONE.MIDDLE_COST_PIECES,
                        discount               = R_PG_PRICE_APPLY_LINE_OLD_ONE.DISCOUNT,
                        before_price           = V_BEFORE_PRICE,
                        before_quantity        = V_BEFORE_QUANTITY,
                        apply_amount           = R_PG_PRICE_APPLY_LINE_OLD_ONE.APPLY_PRICE *
                                                 r_pg_price_apply_line.Apply_Quantity,
                        last_amount            = R_PG_PRICE_APPLY_LINE_OLD_ONE.APPROVAL_PRICE *
                                                 r_pg_price_apply_line.Apply_Quantity,
                        bd_price_apply_line_id = R_PG_PRICE_APPLY_LINE_OLD_ONE.BD_PRICE_APPLY_LINE_ID,
                        catch_date             = R_PG_PRICE_APPLY_LINE_OLD_ONE.CATCH_DATE,
                        created_by             = R_PG_PRICE_APPLY_LINE_OLD_ONE.CREATED_BY,
                        creation_date          = R_PG_PRICE_APPLY_LINE_OLD_ONE.CREATION_DATE,
                        last_updated_by        = R_PG_PRICE_APPLY_LINE_OLD_ONE.LAST_UPDATED_BY,
                        last_update_date       = R_PG_PRICE_APPLY_LINE_OLD_ONE.LAST_UPDATE_DATE,
                        program_updated_by     = R_PG_PRICE_APPLY_LINE_OLD_ONE.PROGRAM_UPDATED_BY,
                        program_update_date    = R_PG_PRICE_APPLY_LINE_OLD_ONE.PROGRAM_UPDATE_DATE,
                        version                = R_PG_PRICE_APPLY_LINE_OLD_ONE.VERSION,
                        approval_price         = R_PG_PRICE_APPLY_LINE_OLD_ONE.APPROVAL_PRICE,
                        lowest_price           = v_lowest_price,--R_PG_PRICE_APPLY_LINE_OLD_ONE.LOWEST_PRICE,
                        is_adjust              = V_IS_ADJUST,
                        price_difference       = R_PG_PRICE_APPLY_LINE_OLD_ONE.PRICE_DIFFERENCE,
                        has_pick_up_cnt        = V_HAS_PICK_UP_CNT,
                        lock_cnt               = V_LOCK_CNT,
                        price_one              = R_PG_PRICE_APPLY_LINE_OLD_ONE.PRICE_ONE,
                        quantity_one           = R_PG_PRICE_APPLY_LINE_OLD_ONE.QUANTITY_ONE,
                        price_two              = R_PG_PRICE_APPLY_LINE_OLD_ONE.PRICE_TWO,
                        quantity_two           = R_PG_PRICE_APPLY_LINE_OLD_ONE.QUANTITY_TWO,
                        price_three            = R_PG_PRICE_APPLY_LINE_OLD_ONE.PRICE_THREE,
                        quantity_three         = R_PG_PRICE_APPLY_LINE_OLD_ONE.QUANTITY_THREE,
                        price_four             = R_PG_PRICE_APPLY_LINE_OLD_ONE.PRICE_FOUR,
                        quantity_four          = R_PG_PRICE_APPLY_LINE_OLD_ONE.QUANTITY_FOUR,
                        price_five             = R_PG_PRICE_APPLY_LINE_OLD_ONE.PRICE_FIVE,
                        quantity_five          = R_PG_PRICE_APPLY_LINE_OLD_ONE.QUANTITY_FIVE,
                        price_six              = R_PG_PRICE_APPLY_LINE_OLD_ONE.PRICE_SIX,
                        quantity_six           = R_PG_PRICE_APPLY_LINE_OLD_ONE.QUANTITY_SIX,
                        price_seven            = R_PG_PRICE_APPLY_LINE_OLD_ONE.PRICE_SEVEN,
                        quantity_seven         = R_PG_PRICE_APPLY_LINE_OLD_ONE.QUANTITY_SEVEN,
                        price_eight            = R_PG_PRICE_APPLY_LINE_OLD_ONE.PRICE_EIGHT,
                        quantity_eight         = R_PG_PRICE_APPLY_LINE_OLD_ONE.QUANTITY_EIGHT,
                        price_nine             = R_PG_PRICE_APPLY_LINE_OLD_ONE.PRICE_NINE,
                        quantity_nine          = R_PG_PRICE_APPLY_LINE_OLD_ONE.QUANTITY_NINE,
                        month_discount         = R_PG_PRICE_APPLY_LINE_OLD_ONE.MONTH_DISCOUNT,
                        DELIVERY_PRICE = R_PG_PRICE_APPLY_LINE.DELIVERY_PRICE
                 where l.apply_id = v_APPLY_ID and l.item_code = r_pg_price_apply_line.item_code;
                 V_TMP_COUNT := SQL%ROWCOUNT;
              exception
                when others then
                  p_Result := v_Value || '失败。' || SQLERRM;
              end;
             end if;
             
             if p_Result = v_Success and V_TMP_COUNT = 0 then      
               Select s_pg_price_apply_line.nextval into  v_APPLY_LINE_ID   From  dual;
                  INSERT INTO T_PG_PRICE_APPLY_LINE(entity_id,
                                                    apply_line_id,
                                                    apply_id,
                                                    item_id,
                                                    item_code,
                                                    item_desc,
                                                    uom_code,
                                                    list_price,
                                                    contract_price,
                                                    apply_price,
                                                    last_price,
                                                    low_price,
                                                    apply_quantity,
                                                    last_quantity,
                                                    middle_amount,
                                                    middle_discount,
                                                    middle_cost,
                                                    middle_cost_discount,
                                                    middle_cost_pieces,
                                                    discount,
                                                    before_price,
                                                    before_quantity,
                                                    apply_amount,
                                                    last_amount,
                                                    bd_price_apply_line_id,
                                                    catch_date,
                                                    created_by,
                                                    creation_date,
                                                    last_updated_by,
                                                    last_update_date,
                                                    program_updated_by,
                                                    program_update_date,
                                                    version,
                                                    approval_price,
                                                    lowest_price,
                                                    is_adjust,
                                                    price_difference,
                                                    has_pick_up_cnt,
                                                    lock_cnt,
                                                    price_one,
                                                    quantity_one,
                                                    price_two,
                                                    quantity_two,
                                                    price_three,
                                                    quantity_three,
                                                    price_four,
                                                    quantity_four,
                                                    price_five,
                                                    quantity_five,
                                                    price_six,
                                                    quantity_six,
                                                    price_seven,
                                                    quantity_seven,
                                                    price_eight,
                                                    quantity_eight,
                                                    price_nine,
                                                    quantity_nine,
                                                    month_discount,
                                                    DELIVERY_PRICE)
                                              values
                                                   (r_Pg_Price_Apply_Head.ENTITY_ID,
                                                    v_APPLY_LINE_ID,
                                                    v_APPLY_ID,
                                                    R_PG_PRICE_APPLY_LINE_OLD_ONE.ITEM_ID,
                                                    R_PG_PRICE_APPLY_LINE_OLD_ONE.ITEM_CODE,
                                                    R_PG_PRICE_APPLY_LINE_OLD_ONE.ITEM_DESC,
                                                    R_PG_PRICE_APPLY_LINE_OLD_ONE.UOM_CODE,
                                                    R_PG_PRICE_APPLY_LINE_OLD_ONE.LIST_PRICE,
                                                    R_PG_PRICE_APPLY_LINE_OLD_ONE.CONTRACT_PRICE,
                                                    R_PG_PRICE_APPLY_LINE_OLD_ONE.APPLY_PRICE,
                                                    R_PG_PRICE_APPLY_LINE_OLD_ONE.LAST_PRICE,
                                                    v_low_price,--R_PG_PRICE_APPLY_LINE_OLD_ONE.LOW_PRICE,
                                                    r_pg_price_apply_line.Apply_Quantity,
                                                    r_pg_price_apply_line.Apply_Quantity, 
                                                    V_NEW_MIDDLE_AMOUNT,
                                                    V_NEW_MIDDLE_DISCOUNT,
                                                    V_NEW_MIDDLE_COST,
                                                    R_PG_PRICE_APPLY_LINE_OLD_ONE.MIDDLE_COST_DISCOUNT,
                                                    R_PG_PRICE_APPLY_LINE_OLD_ONE.MIDDLE_COST_PIECES,
                                                    R_PG_PRICE_APPLY_LINE_OLD_ONE.DISCOUNT,
                                                    V_BEFORE_PRICE,
                                                    V_BEFORE_QUANTITY,
                                                    R_PG_PRICE_APPLY_LINE_OLD_ONE.APPLY_PRICE*r_pg_price_apply_line.Apply_Quantity,
                                                    R_PG_PRICE_APPLY_LINE_OLD_ONE.APPROVAL_PRICE*r_pg_price_apply_line.Apply_Quantity,
                                                    R_PG_PRICE_APPLY_LINE_OLD_ONE.BD_PRICE_APPLY_LINE_ID,
                                                    R_PG_PRICE_APPLY_LINE_OLD_ONE.CATCH_DATE,
                                                    R_PG_PRICE_APPLY_LINE_OLD_ONE.CREATED_BY,
                                                    R_PG_PRICE_APPLY_LINE_OLD_ONE.CREATION_DATE,
                                                    R_PG_PRICE_APPLY_LINE_OLD_ONE.LAST_UPDATED_BY,
                                                    R_PG_PRICE_APPLY_LINE_OLD_ONE.LAST_UPDATE_DATE,
                                                    R_PG_PRICE_APPLY_LINE_OLD_ONE.PROGRAM_UPDATED_BY,
                                                    R_PG_PRICE_APPLY_LINE_OLD_ONE.PROGRAM_UPDATE_DATE,
                                                    R_PG_PRICE_APPLY_LINE_OLD_ONE.VERSION,
                                                    R_PG_PRICE_APPLY_LINE_OLD_ONE.APPROVAL_PRICE,
                                                    v_lowest_price,--R_PG_PRICE_APPLY_LINE_OLD_ONE.LOWEST_PRICE,
                                                    V_IS_ADJUST,
                                                    R_PG_PRICE_APPLY_LINE_OLD_ONE.PRICE_DIFFERENCE,
                                                    V_HAS_PICK_UP_CNT,
                                                    V_LOCK_CNT,
                                                    R_PG_PRICE_APPLY_LINE_OLD_ONE.PRICE_ONE,
                                                    R_PG_PRICE_APPLY_LINE_OLD_ONE.QUANTITY_ONE,
                                                    R_PG_PRICE_APPLY_LINE_OLD_ONE.PRICE_TWO,
                                                    R_PG_PRICE_APPLY_LINE_OLD_ONE.QUANTITY_TWO,
                                                    R_PG_PRICE_APPLY_LINE_OLD_ONE.PRICE_THREE,
                                                    R_PG_PRICE_APPLY_LINE_OLD_ONE.QUANTITY_THREE,
                                                    R_PG_PRICE_APPLY_LINE_OLD_ONE.PRICE_FOUR,
                                                    R_PG_PRICE_APPLY_LINE_OLD_ONE.QUANTITY_FOUR,
                                                    R_PG_PRICE_APPLY_LINE_OLD_ONE.PRICE_FIVE,
                                                    R_PG_PRICE_APPLY_LINE_OLD_ONE.QUANTITY_FIVE,
                                                    R_PG_PRICE_APPLY_LINE_OLD_ONE.PRICE_SIX,
                                                    R_PG_PRICE_APPLY_LINE_OLD_ONE.QUANTITY_SIX,
                                                    R_PG_PRICE_APPLY_LINE_OLD_ONE.PRICE_SEVEN,
                                                    R_PG_PRICE_APPLY_LINE_OLD_ONE.QUANTITY_SEVEN,
                                                    R_PG_PRICE_APPLY_LINE_OLD_ONE.PRICE_EIGHT,
                                                    R_PG_PRICE_APPLY_LINE_OLD_ONE.QUANTITY_EIGHT,
                                                    R_PG_PRICE_APPLY_LINE_OLD_ONE.PRICE_NINE,
                                                    R_PG_PRICE_APPLY_LINE_OLD_ONE.QUANTITY_NINE,
                                                    R_PG_PRICE_APPLY_LINE_OLD_ONE.MONTH_DISCOUNT,
                                                    R_PG_PRICE_APPLY_LINE.DELIVERY_PRICE);
             end if;
           END IF;
         END IF;
         -------------------------------------------------------------------------------------------------------
       ELSIF  p_Result = v_Success AND V_IS_ADJUST = 'N' AND V_PAL_RECORD > 0 THEN
         IF R_PG_PRICE_APPLY_LINE_OLD_ONE.APPLY_PRICE > R_PG_PRICE_APPLY_LINE_OLD_ONE.LIST_PRICE AND V_IF_NEED_DISCOUNT = 'Y' THEN
           p_Result := '价格申报明细产品编码' || R_PG_PRICE_APPLY_LINE_OLD_ONE.Item_Code || '的申请价不能大于直供价';
         END IF;
         if V_IS_UPDATE = 'Y' then
           begin
             v_Value := '更新接口行数据：';
             update t_pg_price_apply_line l
                set item_id                = R_PG_PRICE_APPLY_LINE_OLD_ONE.ITEM_ID,
                    item_code              = R_PG_PRICE_APPLY_LINE_OLD_ONE.ITEM_CODE,
                    item_desc              = R_PG_PRICE_APPLY_LINE_OLD_ONE.ITEM_DESC,
                    uom_code               = R_PG_PRICE_APPLY_LINE_OLD_ONE.UOM_CODE,
                    list_price             = R_PG_PRICE_APPLY_LINE_OLD_ONE.LIST_PRICE,
                    contract_price         = R_PG_PRICE_APPLY_LINE_OLD_ONE.CONTRACT_PRICE,
                    apply_price            = R_PG_PRICE_APPLY_LINE_OLD_ONE.APPLY_PRICE,
                    last_price             = R_PG_PRICE_APPLY_LINE_OLD_ONE.LAST_PRICE,
                    low_price              = v_low_price,--R_PG_PRICE_APPLY_LINE_OLD_ONE.LOW_PRICE,
                    apply_quantity         = r_pg_price_apply_line.Apply_Quantity,
                    last_quantity          = r_pg_price_apply_line.Apply_Quantity,
                    middle_amount          = R_PG_PRICE_APPLY_LINE_OLD_ONE.Middle_Amount,--V_NEW_MIDDLE_AMOUNT,
                    middle_discount        = R_PG_PRICE_APPLY_LINE_OLD_ONE.Middle_Discount,--V_NEW_MIDDLE_DISCOUNT,
                    middle_cost            = R_PG_PRICE_APPLY_LINE_OLD_ONE.Middle_Cost,--V_NEW_MIDDLE_COST,
                    middle_cost_discount   = R_PG_PRICE_APPLY_LINE_OLD_ONE.Middle_Cost_Discount,
                    middle_cost_pieces     = R_PG_PRICE_APPLY_LINE_OLD_ONE.Middle_Cost_Pieces,
                    discount               = R_PG_PRICE_APPLY_LINE_OLD_ONE.DISCOUNT,
                    before_price           = V_BEFORE_PRICE,
                    before_quantity        = V_BEFORE_QUANTITY,
                    apply_amount           = R_PG_PRICE_APPLY_LINE_OLD_ONE.APPLY_PRICE *
                                             r_pg_price_apply_line.Apply_Quantity,
                    last_amount            = R_PG_PRICE_APPLY_LINE_OLD_ONE.APPROVAL_PRICE *
                                             r_pg_price_apply_line.Apply_Quantity,
                    bd_price_apply_line_id = R_PG_PRICE_APPLY_LINE_OLD_ONE.BD_PRICE_APPLY_LINE_ID,
                    catch_date             = R_PG_PRICE_APPLY_LINE_OLD_ONE.CATCH_DATE,
                    created_by             = R_PG_PRICE_APPLY_LINE_OLD_ONE.CREATED_BY,
                    creation_date          = R_PG_PRICE_APPLY_LINE_OLD_ONE.CREATION_DATE,
                    last_updated_by        = R_PG_PRICE_APPLY_LINE_OLD_ONE.LAST_UPDATED_BY,
                    last_update_date       = R_PG_PRICE_APPLY_LINE_OLD_ONE.LAST_UPDATE_DATE,
                    program_updated_by     = R_PG_PRICE_APPLY_LINE_OLD_ONE.PROGRAM_UPDATED_BY,
                    program_update_date    = R_PG_PRICE_APPLY_LINE_OLD_ONE.PROGRAM_UPDATE_DATE,
                    version                = R_PG_PRICE_APPLY_LINE_OLD_ONE.VERSION,
                    approval_price         = R_PG_PRICE_APPLY_LINE_OLD_ONE.APPROVAL_PRICE,
                    lowest_price           = v_lowest_price,--R_PG_PRICE_APPLY_LINE_OLD_ONE.LOWEST_PRICE,
                    is_adjust              = V_IS_ADJUST,
                    price_difference       = R_PG_PRICE_APPLY_LINE_OLD_ONE.PRICE_DIFFERENCE,
                    has_pick_up_cnt        = V_HAS_PICK_UP_CNT,
                    lock_cnt               = V_LOCK_CNT,
                    price_one              = R_PG_PRICE_APPLY_LINE_OLD_ONE.PRICE_ONE,
                    quantity_one           = R_PG_PRICE_APPLY_LINE_OLD_ONE.QUANTITY_ONE,
                    price_two              = R_PG_PRICE_APPLY_LINE_OLD_ONE.PRICE_TWO,
                    quantity_two           = R_PG_PRICE_APPLY_LINE_OLD_ONE.QUANTITY_TWO,
                    price_three            = R_PG_PRICE_APPLY_LINE_OLD_ONE.PRICE_THREE,
                    quantity_three         = R_PG_PRICE_APPLY_LINE_OLD_ONE.QUANTITY_THREE,
                    price_four             = R_PG_PRICE_APPLY_LINE_OLD_ONE.PRICE_FOUR,
                    quantity_four          = R_PG_PRICE_APPLY_LINE_OLD_ONE.QUANTITY_FOUR,
                    price_five             = R_PG_PRICE_APPLY_LINE_OLD_ONE.PRICE_FIVE,
                    quantity_five          = R_PG_PRICE_APPLY_LINE_OLD_ONE.QUANTITY_FIVE,
                    price_six              = R_PG_PRICE_APPLY_LINE_OLD_ONE.PRICE_SIX,
                    quantity_six           = R_PG_PRICE_APPLY_LINE_OLD_ONE.QUANTITY_SIX,
                    price_seven            = R_PG_PRICE_APPLY_LINE_OLD_ONE.PRICE_SEVEN,
                    quantity_seven         = R_PG_PRICE_APPLY_LINE_OLD_ONE.QUANTITY_SEVEN,
                    price_eight            = R_PG_PRICE_APPLY_LINE_OLD_ONE.PRICE_EIGHT,
                    quantity_eight         = R_PG_PRICE_APPLY_LINE_OLD_ONE.QUANTITY_EIGHT,
                    price_nine             = R_PG_PRICE_APPLY_LINE_OLD_ONE.PRICE_NINE,
                    quantity_nine          = R_PG_PRICE_APPLY_LINE_OLD_ONE.QUANTITY_NINE,
                    month_discount         = R_PG_PRICE_APPLY_LINE_OLD_ONE.MONTH_DISCOUNT,
                    DELIVERY_PRICE         = R_PG_PRICE_APPLY_LINE.DELIVERY_PRICE
              where l.apply_id = v_APPLY_ID
                and l.item_code = r_pg_price_apply_line.item_code;
              
              V_TMP_COUNT := SQL%ROWCOUNT;
           exception
             when others then
                 p_Result := v_Value || '失败！' || SQLERRM;
           end;
         end if;
          
         IF p_Result = v_Success and V_TMP_COUNT = 0 THEN
            Select s_pg_price_apply_line.nextval into  v_APPLY_LINE_ID   From  dual;
            INSERT INTO T_PG_PRICE_APPLY_LINE(entity_id,
                                              apply_line_id,
                                              apply_id,
                                              item_id,
                                              item_code,
                                              item_desc,
                                              uom_code,
                                              list_price,
                                              contract_price,
                                              apply_price,
                                              last_price,
                                              low_price,
                                              apply_quantity,
                                              last_quantity,
                                              middle_amount,
                                              middle_discount,
                                              middle_cost,
                                              middle_cost_discount,
                                              discount,
                                              before_price,
                                              before_quantity,
                                              apply_amount,
                                              last_amount,
                                              bd_price_apply_line_id,
                                              catch_date,
                                              created_by,
                                              creation_date,
                                              last_updated_by,
                                              last_update_date,
                                              program_updated_by,
                                              program_update_date,
                                              version,
                                              approval_price,
                                              lowest_price,
                                              is_adjust,
                                              price_difference,
                                              has_pick_up_cnt,
                                              lock_cnt,
                                              price_one,
                                              quantity_one,
                                              price_two,
                                              quantity_two,
                                              price_three,
                                              quantity_three,
                                              price_four,
                                              quantity_four,
                                              price_five,
                                              quantity_five,
                                              price_six,
                                              quantity_six,
                                              price_seven,
                                              quantity_seven,
                                              price_eight,
                                              quantity_eight,
                                              price_nine,
                                              quantity_nine,
                                              month_discount,
                                              DELIVERY_PRICE)
                                        values
                                             (r_Pg_Price_Apply_Head.ENTITY_ID,
                                              v_APPLY_LINE_ID,
                                              v_APPLY_ID,
                                              R_PG_PRICE_APPLY_LINE_OLD_ONE.ITEM_ID,
                                              R_PG_PRICE_APPLY_LINE_OLD_ONE.ITEM_CODE,
                                              R_PG_PRICE_APPLY_LINE_OLD_ONE.ITEM_DESC,
                                              R_PG_PRICE_APPLY_LINE_OLD_ONE.UOM_CODE,
                                              R_PG_PRICE_APPLY_LINE_OLD_ONE.LIST_PRICE,
                                              R_PG_PRICE_APPLY_LINE_OLD_ONE.CONTRACT_PRICE,
                                              R_PG_PRICE_APPLY_LINE_OLD_ONE.APPLY_PRICE,
                                              R_PG_PRICE_APPLY_LINE_OLD_ONE.LAST_PRICE,
                                              v_low_price,--R_PG_PRICE_APPLY_LINE_OLD_ONE.LOW_PRICE,
                                              R_PG_PRICE_APPLY_LINE_OLD_ONE.APPLY_QUANTITY,
                                              R_PG_PRICE_APPLY_LINE_OLD_ONE.LAST_QUANTITY,
                                              R_PG_PRICE_APPLY_LINE_OLD_ONE.MIDDLE_AMOUNT,
                                              R_PG_PRICE_APPLY_LINE_OLD_ONE.MIDDLE_DISCOUNT,
                                              R_PG_PRICE_APPLY_LINE_OLD_ONE.MIDDLE_COST,
                                              R_PG_PRICE_APPLY_LINE_OLD_ONE.MIDDLE_COST_DISCOUNT,
                                              R_PG_PRICE_APPLY_LINE_OLD_ONE.DISCOUNT,
                                              V_BEFORE_PRICE,
                                              V_BEFORE_QUANTITY,
                                              R_PG_PRICE_APPLY_LINE_OLD_ONE.APPLY_AMOUNT,
                                              R_PG_PRICE_APPLY_LINE_OLD_ONE.LAST_AMOUNT,
                                              R_PG_PRICE_APPLY_LINE_OLD_ONE.BD_PRICE_APPLY_LINE_ID,
                                              R_PG_PRICE_APPLY_LINE_OLD_ONE.CATCH_DATE,
                                              R_PG_PRICE_APPLY_LINE_OLD_ONE.CREATED_BY,
                                              R_PG_PRICE_APPLY_LINE_OLD_ONE.CREATION_DATE,
                                              R_PG_PRICE_APPLY_LINE_OLD_ONE.LAST_UPDATED_BY,
                                              R_PG_PRICE_APPLY_LINE_OLD_ONE.LAST_UPDATE_DATE,
                                              R_PG_PRICE_APPLY_LINE_OLD_ONE.PROGRAM_UPDATED_BY,
                                              R_PG_PRICE_APPLY_LINE_OLD_ONE.PROGRAM_UPDATE_DATE,
                                              R_PG_PRICE_APPLY_LINE_OLD_ONE.VERSION,
                                              R_PG_PRICE_APPLY_LINE_OLD_ONE.APPROVAL_PRICE,
                                              v_lowest_price,--R_PG_PRICE_APPLY_LINE_OLD_ONE.LOWEST_PRICE,
                                              V_IS_ADJUST,
                                              R_PG_PRICE_APPLY_LINE_OLD_ONE.PRICE_DIFFERENCE,
                                              V_HAS_PICK_UP_CNT,
                                              V_LOCK_CNT,
                                              R_PG_PRICE_APPLY_LINE_OLD_ONE.PRICE_ONE,
                                              R_PG_PRICE_APPLY_LINE_OLD_ONE.QUANTITY_ONE,
                                              R_PG_PRICE_APPLY_LINE_OLD_ONE.PRICE_TWO,
                                              R_PG_PRICE_APPLY_LINE_OLD_ONE.QUANTITY_TWO,
                                              R_PG_PRICE_APPLY_LINE_OLD_ONE.PRICE_THREE,
                                              R_PG_PRICE_APPLY_LINE_OLD_ONE.QUANTITY_THREE,
                                              R_PG_PRICE_APPLY_LINE_OLD_ONE.PRICE_FOUR,
                                              R_PG_PRICE_APPLY_LINE_OLD_ONE.QUANTITY_FOUR,
                                              R_PG_PRICE_APPLY_LINE_OLD_ONE.PRICE_FIVE,
                                              R_PG_PRICE_APPLY_LINE_OLD_ONE.QUANTITY_FIVE,
                                              R_PG_PRICE_APPLY_LINE_OLD_ONE.PRICE_SIX,
                                              R_PG_PRICE_APPLY_LINE_OLD_ONE.QUANTITY_SIX,
                                              R_PG_PRICE_APPLY_LINE_OLD_ONE.PRICE_SEVEN,
                                              R_PG_PRICE_APPLY_LINE_OLD_ONE.QUANTITY_SEVEN,
                                              R_PG_PRICE_APPLY_LINE_OLD_ONE.PRICE_EIGHT,
                                              R_PG_PRICE_APPLY_LINE_OLD_ONE.QUANTITY_EIGHT,
                                              R_PG_PRICE_APPLY_LINE_OLD_ONE.PRICE_NINE,
                                              R_PG_PRICE_APPLY_LINE_OLD_ONE.QUANTITY_NINE,
                                              R_PG_PRICE_APPLY_LINE_OLD_ONE.MONTH_DISCOUNT,
                                              R_PG_PRICE_APPLY_LINE.DELIVERY_PRICE);

         END IF;

       END IF;

     Exception
       when others then
       p_Result := v_Value || '失败' || v_Nl || sqlerrm;
     End;
    --同步成功后回写标志位 ：INTF_STATUS，INTF_RESULT
    IF p_Result <> v_Success then
    --Rollback;
     update INTF_PG_PRICE_APPLY_HEAD t
        set t.INTF_STATUS= 'E' , t.INTF_RESULT= p_Result , t.apply_id = v_APPLY_ID , t.apply_code = V_PG_APPLY_CODE_OLD
      Where t.INTF_APPLY_ID  = r_Pg_Price_Apply_Head.INTF_APPLY_ID;

     update intf_pg_price_apply_line  t
       set  t.intf_status = 'E' , t.intf_result = p_Result
     where t.intf_apply_line_id = r_pg_price_apply_line.intf_apply_line_id;
    -- Commit;
    else
     update INTF_PG_PRICE_APPLY_HEAD t
        set t.INTF_STATUS= 'S' , t.INTF_RESULT= 'SUCCESS' , t.apply_id = v_APPLY_ID , t.apply_code = V_PG_APPLY_CODE_OLD
      Where t.INTF_APPLY_ID  = r_Pg_Price_Apply_Head.INTF_APPLY_ID;

      update intf_pg_price_apply_line  t
       set   t.intf_status = 'S' , t.intf_result = 'SUCCESS'
     where   t.intf_apply_line_id = r_pg_price_apply_line.intf_apply_line_id;
     --如果中中间费用、中间折扣为空 则默认为0
     --update T_PG_PRICE_APPLY_LINE a set a.middle_amount = nvl(a.middle_amount,0),a.middle_discount = nvl(a.middle_discount,0),a.middle_cost = nvl(a.middle_cost,0) where a.apply_id = v_APPLY_ID;
    -- Commit
    End IF;
   End Loop;
  END IF;
  End;

  ----------------------------------------------------------------------
  -- Author  : WYF
  -- Created : 2015/10/19
  -- Purpose : 价格申报调整校验
  ----------------------------------------------------------------------
  Procedure P_PG_PRICE_APPLY_ADJUST_VERIFY(P_INTF_APPLY_ID IN NUMBER, P_ENTITY_ID IN NUMBER, P_APPLY_CODE OUT VARCHAR2, P_RESULT OUT VARCHAR2) IS

    v_Value                varchar2(1024);
    V_APPLY_CODE           VARCHAR2(100);                    --申报编号
    V_RECORD               NUMBER;                           --价格申报头行数
    P_LOCK_FLAG            VARCHAR2(2);                      --价格批文是否锁定
    V_IS_STORE                 VARCHAR2(2);--是否备货机
    V_APPLY_STORE_CODE         VARCHAR2(100);--被引用的备货机单号
    V_VERI_COUNT number;   --核销单数量
    
    CURSOR C_PG_PRICE_APPLY_HEAD IS
    SELECT *
      FROM T_PG_PRICE_APPLY_HEAD PH
     WHERE PH.APPLY_CODE = V_APPLY_CODE
       AND PH.ENTITY_ID = P_ENTITY_ID;
    R_PG_PRICE_APPLY_HEAD  C_PG_PRICE_APPLY_HEAD%ROWTYPE ;   --价格申报头

    BEGIN
      P_RESULT := v_Success;

      BEGIN
        v_Value := '查询接口表申报编号';
        SELECT H.APPLY_CODE
          INTO V_APPLY_CODE
          FROM INTF_PG_PRICE_APPLY_HEAD H
         WHERE H.INTF_APPLY_ID = P_INTF_APPLY_ID
           AND H.ENTITY_ID = P_ENTITY_ID;
      EXCEPTION
        WHEN OTHERS THEN
          P_RESULT := v_Value || '失败！价格申报接口头ID：' || To_Char(P_INTF_APPLY_ID) || '不存在';
      END;

      --add by tangjz2 2018-06-04
      --备货工程、或者引用备货工程的价格申报不允许调整
      if V_APPLY_CODE is not null then
        Begin
          v_Value := '查询价格申报单号失败！';
          select nvl(a.is_store,'N'),a.apply_store_code into V_IS_STORE,V_APPLY_STORE_CODE from T_PG_PRICE_APPLY_HEAD a where a.apply_code = V_APPLY_CODE;
          if V_IS_STORE = 'Y' then
             P_RESULT := '属于备货工程的价格申报不允许调整';
             return;
          elsif V_APPLY_STORE_CODE is not null then
             P_RESULT := '引用备货工程的价格申报不允许调整';
             return;
          end if;
        Exception
        when others then
           p_Result := v_Value || v_Nl || sqlerrm;
           return;
        End;
      end if;
      
      --add by tangjz2 2018-09-26
      --根据价格申报号查询存在未作废的分批核销单的不允许调整
      if V_APPLY_CODE is not null then
        select count(*) into V_VERI_COUNT from T_PG_VERI_HEADER t where t.veri_status <> '3' and t.apply_code = V_APPLY_CODE and t.entity_id = P_ENTITY_ID;
        if V_VERI_COUNT > 0 then
          P_RESULT := '该单据已经被分批核销，不允许调整！价格申报号：' || V_APPLY_CODE;
          return;
        end if;
      end if;

      SELECT COUNT(*)
        INTO V_RECORD
        FROM T_PG_PRICE_APPLY_HEAD PH
       WHERE PH.APPLY_CODE = V_APPLY_CODE
         AND PH.ENTITY_ID = P_ENTITY_ID;

     IF P_RESULT = v_Success AND V_RECORD = 1 THEN
       FOR R_PG_PRICE_APPLY_HEAD IN C_PG_PRICE_APPLY_HEAD LOOP
         IF R_PG_PRICE_APPLY_HEAD.STATUS = '2' THEN
           BEGIN
             v_Value := '查询价格批文批文号';
             SELECT TA.APPLY_CODE, TA.LOCK_FLAG
               INTO P_APPLY_CODE, P_LOCK_FLAG
               FROM T_BD_PRICE_APPLY TA
              WHERE TA.PRICE_APPLY_ID = R_PG_PRICE_APPLY_HEAD.BD_PRICE_APPLY_ID;

             IF P_LOCK_FLAG = 'Y' THEN
               P_RESULT := '价格批文已锁定，不能进行调整！';
               P_APPLY_CODE := NULL;
             ELSIF P_LOCK_FLAG is NULL THEN
               P_RESULT := '价格批文锁定状态为空！';
               P_APPLY_CODE := NULL;
             END IF;
           EXCEPTION
             WHEN OTHERS THEN
               P_RESULT := v_Value || '失败！';
               P_APPLY_CODE := NULL;
           END;
         ELSE
           P_RESULT := '价格申报还在审批中不能调整！';
           P_APPLY_CODE := NULL;
         END IF;
       END LOOP;
    ELSE
       P_RESULT := '价格申报头数据有误！';
       P_APPLY_CODE := NULL;
    END IF;
      
  END;

  ----------------------------------------------------------------------
  -- Author  : WANGCONG
  -- Created : 2015/10/19
  -- Purpose : 锁定/解锁批文
  ----------------------------------------------------------------------
  Procedure P_PG_LOCK_UNLOCK_PRICE_APPLY(P_BD_APPLY_CODE IN VARCHAR2,P_ENTITY_ID IN NUMBER,IS_LOCK IN VARCHAR2,P_RESULT OUT VARCHAR2) IS
     v_Value                varchar2(1024);

     BEGIN
       P_RESULT := v_Success;

       IF IS_LOCK='Y' THEN
         --锁定价格批文
         BEGIN
           v_Value := '锁定价格批文';
           UPDATE T_BD_PRICE_APPLY TBA
              SET TBA.LOCK_FLAG = 'Y'
            WHERE TBA.APPLY_CODE = P_BD_APPLY_CODE
              AND TBA.ENTITY_ID = P_ENTITY_ID;
           EXCEPTION
             WHEN OTHERS THEN
               P_RESULT := v_Value || '失败！';
           END;
       ELSIF IS_LOCK = 'N' THEN
         --解锁价格批文
         BEGIN
            v_Value := '解锁价格批文';
            UPDATE T_BD_PRICE_APPLY TBA
              SET TBA.LOCK_FLAG = 'N'
            WHERE TBA.APPLY_CODE = P_BD_APPLY_CODE
              AND TBA.ENTITY_ID = P_ENTITY_ID;
           EXCEPTION
             WHEN OTHERS THEN
               P_RESULT := v_Value || '失败！';
           END;
        ELSE
          P_RESULT := '锁定标识只能为Y/N';
        END IF;
      END;

  ----------------------------------------------------------------------
  -- Author  : WANGCONG
  -- Created : 2016/06/07
  -- Purpose : ccs商机引入从接口表同步数据到正式表
  ----------------------------------------------------------------------
  Procedure P_PG_BUSINESS_CCS_SALES(P_INTF_HEAD_ID IN NUMBER,P_MESSAGE OUT VARCHAR2) IS
    
    V_VALUE       VARCHAR2(1024);
    R_INTF_PG_BUSINESS_HEAD INTF_PG_BUSINESS%ROWTYPE;
    R_INTF_PG_BUSINESS_LINE INTF_PG_BUSINESS_LINE%ROWTYPE;
    
    CURSOR C_INTF_PG_BUSINESS_LINE IS
     SELECT * FROM INTF_PG_BUSINESS_LINE L WHERE L.HEAD_ID = P_INTF_HEAD_ID;
     
    V_PROJECT_CODE T_PG_BUSINESS.PROJECT_CODE%TYPE;
    V_BUSINESS_ID  T_PG_BUSINESS.BUSINESS_ID%TYPE;
    

    V_LOC_ID              T_PG_BUSINESS.LOC_ID%TYPE;
    V_LOC_NAME            T_PG_BUSINESS.LOC_NAME%TYPE;
    V_CUSTOMER_ID         T_PG_BUSINESS.CUSTOMER_ID%TYPE;
    V_CUSTOMER_NAME       T_PG_BUSINESS.CUSTOMER_NAME%TYPE;
    V_ACCOUNT_ID          T_PG_BUSINESS.ACCOUNT_ID%TYPE;
    V_ACCOUNT_CODE        T_PG_BUSINESS.ACCOUNT_CODE%TYPE;
    V_AGENT_ID            T_PG_BUSINESS.AGENT_ID%TYPE;
    V_AGENT_NAME          T_PG_BUSINESS.AGENT_NAME%TYPE;
    V_SALES_CENTER_ID     T_PG_BUSINESS.SALES_CENTER_ID%TYPE;
    V_SALES_CENTER_NAME   T_PG_BUSINESS.SALES_CENTER_NAME%TYPE;
    V_PROJECT_CENTER_ID   T_PG_BUSINESS.PROJECT_CENTER_ID%TYPE;
    V_PROJECT_CENTER_NAME T_PG_BUSINESS.PROJECT_CENTER_NAME%TYPE;
    V_OTHER_LOGIN_FLAG    T_PG_BUSINESS.OTHERLOGIN_FLAG%TYPE;
    
    V_BUSINESS_LINE_ID     T_PG_BUSINESS_LINE.BUSSINESS_LINE_ID%TYPE;
    V_ITEM_NAME            T_PG_BUSINESS_LINE.ITEM_DESC%TYPE;
    V_ITEM_ID              T_PG_BUSINESS_LINE.ITEM_ID%TYPE;
    V_SALES_MAIN_TYPE_NAME T_PG_BUSINESS_LINE.SALES_MAIN_TYPE_NAME%TYPE;
    V_SALES_SUB_TYPE       T_PG_BUSINESS_LINE.SALES_SUB_TYPE%TYPE;
    V_SALES_SUB_TYPE_NAME  T_PG_BUSINESS_LINE.SALES_SUB_TYPE_NAME%TYPE;
    V_UOM_CODE             T_PG_BUSINESS_LINE.UOM_CODE%TYPE;
    V_COMMON_PRICE         T_PG_BUSINESS_LINE.COMMON_PRICE%TYPE;
      V_APPENDIX_ID VARCHAR2(100);--附件id
    BEGIN
      P_MESSAGE := v_Success;
      --校验接口
      BEGIN
        V_VALUE := '锁定接口表头表失败';
        SELECT *
          INTO R_INTF_PG_BUSINESS_HEAD
          FROM INTF_PG_BUSINESS B
         WHERE B.HEAD_ID = P_INTF_HEAD_ID
           FOR UPDATE NOWAIT;
        EXCEPTION 
          WHEN OTHERS THEN
            P_MESSAGE := V_VALUE || v_Nl ||SQLERRM;
       END; 
       
       IF P_MESSAGE = v_Success THEN
         BEGIN
           V_VALUE := '校验来源系统：';
           IF NVL(R_INTF_PG_BUSINESS_HEAD.SOURCE_SYSTEM,'_') = '_' THEN
             RAISE V_CCS_EXCEPTION;
           END IF;
           EXCEPTION
              WHEN V_CCS_EXCEPTION THEN
               P_MESSAGE := V_VALUE || '未录入来源系统。'|| v_Nl ||
                          SQLERRM;
          END;
        END IF;
        
        IF P_MESSAGE = v_Success THEN
          BEGIN
            V_VALUE := '校验来源项目编号：';
            IF NVL(R_INTF_PG_BUSINESS_HEAD.ORI_BUSINESS_CODE,'_') = '_' THEN
              RAISE V_CCS_EXCEPTION;
            END IF;
            EXCEPTION
              WHEN V_CCS_EXCEPTION THEN
                P_MESSAGE := V_VALUE || '未录入来源项目编号。'|| v_Nl ||
                          SQLERRM;
          END;
        END IF;
        
        IF P_MESSAGE = v_Success THEN
          BEGIN
            V_VALUE := '校验来源项目ID：';
            IF NVL(R_INTF_PG_BUSINESS_HEAD.ORI_BUSINESS_ID,0) = 0 THEN
              RAISE V_CCS_EXCEPTION;
            END IF;
            EXCEPTION
              WHEN V_CCS_EXCEPTION THEN
                 P_MESSAGE := V_VALUE || '未录入来源项目ID。'|| v_Nl ||
                          SQLERRM;
          END;
        END IF;
        
        IF P_MESSAGE = v_Success THEN
          BEGIN
            V_VALUE := '登陆类型：';
            IF NVL(R_INTF_PG_BUSINESS_HEAD.DOC_FLOW_TYPE,'_') = '_' THEN
              RAISE V_CCS_EXCEPTION;
            END IF;
            EXCEPTION
              WHEN V_CCS_EXCEPTION THEN
                 P_MESSAGE := V_VALUE || '未录入登陆类型。'|| v_Nl ||
                          SQLERRM;
          END;
        END IF;
        
        IF P_MESSAGE = v_Success THEN
        --数据检查
          BEGIN
            V_VALUE := '检查项目区域：';
            SELECT TD.ROW_ID, TD.DISTRICT_NAME
              INTO V_LOC_ID, V_LOC_NAME
              FROM T_BD_DISTRICT TD
             WHERE TD.DISTRICT_CODE = R_INTF_PG_BUSINESS_HEAD.LOC_CODE
               AND TD.ACTIVE_FLAG = 'Y';
            EXCEPTION
              WHEN OTHERS THEN
                P_MESSAGE := V_VALUE || R_INTF_PG_BUSINESS_HEAD.LOC_CODE || '项目区域不存在或已失效。' || v_Nl ||SQLERRM;
          END;
        END IF;
        
        IF P_MESSAGE = v_Success THEN     
          BEGIN
            V_VALUE := '检查经销商：';
            SELECT CH.CUSTOMER_ID, CH.CUSTOMER_NAME
              INTO V_CUSTOMER_ID, V_CUSTOMER_NAME
              FROM T_CUSTOMER_HEADER CH
             WHERE CH.CUSTOMER_CODE = R_INTF_PG_BUSINESS_HEAD.CUSTOMER_CODE
               AND CH.ACTIVE_FLAG = 'Active';
            EXCEPTION
              WHEN OTHERS THEN
                P_MESSAGE := V_VALUE || R_INTF_PG_BUSINESS_HEAD.CUSTOMER_CODE || '经销商不存在或已失效。' || v_Nl ||SQLERRM;
          END;
        END IF;
        
          IF P_MESSAGE = v_Success THEN
          BEGIN
            V_VALUE := '检查营销中心：';
            SELECT U.UNIT_ID, U.NAME
              INTO V_SALES_CENTER_ID, V_SALES_CENTER_NAME
              FROM UP_ORG_UNIT U
             WHERE U.CODE = R_INTF_PG_BUSINESS_HEAD.SALES_CENTER_CODE
               AND U.ENTITY_ID = R_INTF_PG_BUSINESS_HEAD.ENTITY_ID
               AND U.ACTIVE_FLAG = 'T';
            EXCEPTION
              WHEN OTHERS THEN
                P_MESSAGE := V_VALUE || R_INTF_PG_BUSINESS_HEAD.SALES_CENTER_CODE || '营销中心不存在或已失效。' || v_Nl ||SQLERRM;
           END;
         END IF;
        
        IF P_MESSAGE = v_Success THEN
          BEGIN
            V_VALUE := '检查账户：';
            SELECT VC.account_id,VC.account_code
              INTO V_ACCOUNT_ID,V_ACCOUNT_CODE
              FROM V_CUSTOMER_ACCOUNT_SALECENTER VC
             WHERE VC.entity_id = R_INTF_PG_BUSINESS_HEAD.ENTITY_ID
               AND VC.active_flag = 'Active'
               AND VC.orgActive_flag = 'Active'
               AND VC.account_status = '1'
               AND VC.sales_center_code =
                   R_INTF_PG_BUSINESS_HEAD.SALES_CENTER_CODE
               AND VC.customer_code = R_INTF_PG_BUSINESS_HEAD.CUSTOMER_CODE;
             EXCEPTION
               WHEN OTHERS THEN
                 P_MESSAGE := V_VALUE || R_INTF_PG_BUSINESS_HEAD.ACCOUNT_ID || '账户不存在或已失效。' || v_Nl || SQLERRM;
           END;
         END IF;      
         
         IF P_MESSAGE = v_Success THEN
           BEGIN
             V_VALUE := '检查项目所在中心：';
            SELECT U.UNIT_ID, U.NAME
              INTO V_PROJECT_CENTER_ID, V_PROJECT_CENTER_NAME
              FROM UP_ORG_UNIT U
             WHERE U.CODE = R_INTF_PG_BUSINESS_HEAD.PROJECT_CENTER_CODE
               AND U.ENTITY_ID = R_INTF_PG_BUSINESS_HEAD.ENTITY_ID
               AND U.ACTIVE_FLAG = 'T';
             EXCEPTION
               WHEN OTHERS THEN
                 P_MESSAGE := V_VALUE || R_INTF_PG_BUSINESS_HEAD.PROJECT_CENTER_CODE || '不存在或已失效。' || v_Nl ||SQLERRM;
           END;
         END IF;
         
         IF P_MESSAGE = v_Success THEN
           --判断是否异地登陆
           IF R_INTF_PG_BUSINESS_HEAD.SALES_CENTER_CODE = R_INTF_PG_BUSINESS_HEAD.PROJECT_CENTER_CODE THEN
              V_OTHER_LOGIN_FLAG := 'N';
           ELSE
              V_OTHER_LOGIN_FLAG := 'Y';
           END IF;
         END IF;
         
         IF P_MESSAGE =  v_Success THEN
           SELECT S_PG_BUSINESS.NEXTVAL INTO V_BUSINESS_ID FROM DUAL;
           BEGIN
             V_VALUE := '生成商机编码：';
             PKG_BD.P_GET_BILL_NO('tpgProjectCode',Null,R_INTF_PG_BUSINESS_HEAD.ENTITY_ID,Null,V_PROJECT_CODE);
             EXCEPTION
               WHEN OTHERS THEN
                 P_MESSAGE := V_VALUE || '出错。' || v_Nl || SQLERRM;
            END;
               V_APPENDIX_ID:=NULL;
      PKG_PG_INTF.P_PG_BUSINESS_FILE_TRANSFER(P_INTF_HEAD_ID => P_INTF_HEAD_ID,V_SUCCESS =>V_SUCCESS,P_MESSAGE =>P_MESSAGE,V_APPENDIX_ID =>V_APPENDIX_ID )  ;
    
            BEGIN
              V_VALUE := '插入正式表头表';
            
              INSERT INTO T_PG_BUSINESS
                (business_id, --商机信息ID
                 project_code, --项目编号
                 project_name, --项目名称
                 user_firm, --使用单位名称
                 user_phone, --项目方联系电话
                 user_name, --项目方联系人
                 project_address, --工程项目详细地址
                 loc_id, --区域ID
                 loc_code, --项目所在区域
                 loc_name, --区域编码名称
                 project_center_id, --项目所在中心ID
                 project_center_code, --项目所在中心编码
                 project_center_name, --项目所在中心名称
                 customer_id, --经销商ID
                 customer_code, --经销商编码
                 customer_name, --经销商名称
                 sales_center_id, --营销中心ID
                 sales_center_name, --营销中心名称
                 sales_center_code, --营销中心编码
                 account_id, --账户ID
                 account_code,          --账户名称
                 agent_id, --经销商ID
                 agent_code, --经销商编码
                 agent_name, --经销商名称
                 project_type, --工程类型:精装房产配套、公租保障配套、家装橱柜配套、燃气公司合作
                 expected_bid_time, --预计投标时间
                 login_time, --登录日期
                 login_ptotect_time, --登录保护时间
                 project_num, --项目规模
                 project_progress, --项目进度:在建项目、建好未定、准备投标
                 business_type, --商机类型
                 delivery_cycle, --供货周期:单位为天
                 buyout_type, --买断类型:事前买断、时候买断
                 -- customer_person,       --经销商联系人
                 -- customer_person_phone, --联系方式
                 -- area_manager,          --区域经理
                 -- area_manager_phone,    --区域经理电话
                 install_flag, --是否我司安装
                 otherlogin_flag, --是否是异地登录
                 status, --登录状态，有以下几种：已录入、已送审、已审核、已退回、已作废
                 --  competitors,           --工程竞争对手
                 special_need, --特殊要求
                 other_desc, --其他说明资料
                 entity_id, --主体ID
                 created_by, --创建人
                 creation_date, --创建时间
                 last_updated_by, --修改人
                 last_update_date, --修改时间
                 --send_person,           --送审人
                 --send_date,             --送审日期
                 --approval_person,       --审核人
                 --approval_date,         --审核日期
                 --back_person,           --退回人
                 --back_date,             --退回日期
                 --scrapped_person,       --作废人
                 --scrapped_date,         --作废时间
                 --relogin_flag,          --重新登录标识
                 bid_status, --中标状态
                 --freeze_status,         --冻结状态
                 --freeze_person,         --冻结人
                 --freeze_time,           --冻结时间
                 --unfreeze_person,       --解冻人
                 --unfreeze_time,         --解冻时间
                 --is_market_strategy,    --战略大盘采购
                 --verfication_status,    --核销状态 0未核销 1已核销 2核销失败
                 --remark,                --备注
                 --is_groupbuy,           --是否团购
                 --program_updated_by,    --程序修改来源
                 program_update_date, --修改时间
                 ori_business_id, --上级项目ID
                 ori_business_code --上级项目编码
  		,APPENDIX_ID2
      ,big_panel
                 )
              Values
                (V_BUSINESS_ID, --商机信息ID
                 V_PROJECT_CODE, --项目编号
                 R_INTF_PG_BUSINESS_HEAD.PROJECT_NAME, --项目名称
                 R_INTF_PG_BUSINESS_HEAD.USER_FIRM, --使用单位名称
                 R_INTF_PG_BUSINESS_HEAD.USER_PHONE, --项目方联系电话
                 R_INTF_PG_BUSINESS_HEAD.USER_NAME, --项目方联系人
                 R_INTF_PG_BUSINESS_HEAD.PROJECT_ADDRESS, --工程项目详细地址
                 V_LOC_ID, --区域ID
                 R_INTF_PG_BUSINESS_HEAD.LOC_CODE, --项目所在区域
                 V_LOC_NAME, --区域编码名称
                 V_PROJECT_CENTER_ID, --项目所在中心ID
                 R_INTF_PG_BUSINESS_HEAD.PROJECT_CENTER_CODE, --项目所在中心编码
                 V_PROJECT_CENTER_NAME, --项目所在中心名称
                 V_CUSTOMER_ID,
                 R_INTF_PG_BUSINESS_HEAD.CUSTOMER_CODE,
                 V_CUSTOMER_NAME,
                 V_SALES_CENTER_ID, --营销中心ID
                 V_SALES_CENTER_NAME, --营销中心名称
                 R_INTF_PG_BUSINESS_HEAD.SALES_CENTER_CODE, --营销中心编码
                 V_ACCOUNT_ID, --账户ID
                 V_ACCOUNT_CODE,                      --账户名称
                 R_INTF_PG_BUSINESS_HEAD.AGENT_ID, --经销商ID
                 R_INTF_PG_BUSINESS_HEAD.AGENT_CODE, --经销商编码
                 R_INTF_PG_BUSINESS_HEAD.AGENT_NAME, --经销商名称
                 R_INTF_PG_BUSINESS_HEAD.PROJECT_TYPE,
                 trunc(sysdate), --v_Expected_Bid_Time,--预计投标时间
                 trunc(sysdate), --登录日期
                 add_months(sysdate - 1, 3), --登录保护时间
                 R_INTF_PG_BUSINESS_HEAD.PROJECT_NUM, --项目规模
                 R_INTF_PG_BUSINESS_HEAD.PROJECT_PROGRESS, --项目进度:在建项目、建好未定、准备投标
                 R_INTF_PG_BUSINESS_HEAD.BUSINESS_TYPE, --存在问题，先置为0
                 R_INTF_PG_BUSINESS_HEAD.DELIVERY_CYCLE, --供货周期:单位为天
                 R_INTF_PG_BUSINESS_HEAD.BUYOUT_TYPE, --买断类型:事前买断、时候买断
                 -- r_Pg_Business.Project_Man,           --经销商联系人
                 --R_INTF_PG_BUSINESS_HEAD.PRO.Project_Telephone,     --联系方式
                 --r_Pg_Business.Follow_Man,            --区域经理
                 -- r_Pg_Business.Follower_Telephone,    --区域经理电话
                 R_INTF_PG_BUSINESS_HEAD.INSTALL_FLAG, --是否我司安装
                 V_OTHER_LOGIN_FLAG, --是否是异地登录
                 '0', --登录状态:已审核
                 --   R_INTF_PG_BUSINESS_HEAD.Main_Material,         --工程竞争对手
                 R_INTF_PG_BUSINESS_HEAD.SPECIAL_NEED, --特殊要求
                 R_INTF_PG_BUSINESS_HEAD.OTHER_DESC, --其他说明资料
                 R_INTF_PG_BUSINESS_HEAD.ENTITY_ID, --主体ID
                 'CCS', --创建人
                 trunc(sysdate), --创建时间
                 R_INTF_PG_BUSINESS_HEAD.LAST_UPDATED_BY, --修改人
                 R_INTF_PG_BUSINESS_HEAD.LAST_UPDATE_DATE, --修改时间
                 -- r_Pg_Business.To_Checkup_By_Name,    --送审人
                 -- r_Pg_Business.To_Checkup_Date,       --送审日期
                 -- r_Pg_Business.Checkup_By_Name,       --审核人
                 -- r_Pg_Business.Checkup_Date,          --审核日期
                 -- r_Pg_Business.Back_By_Name,          --退回人
                 -- r_Pg_Business.Back_Date,             --退回日期
                 --- r_Pg_Business.Back_By,               --作废人
                 -- r_Pg_Business.Reject_Date,           --作废时间
                 --r_Pg_Business.Relogin_Flag,          --重新登录标识
                 '0', --中标状态
                 --r_Pg_Business.Freeze_Status,         --冻结状态
                 --r_Pg_Business.Freeze_Person,         --冻结人
                 --r_Pg_Business.Freeze_Time,           --冻结时间
                 --r_Pg_Business.Unfreeze_Person,       --解冻人
                 --r_Pg_Business.Unfreeze_Time,         --解冻时间
                 --r_Pg_Business.Is_Market_StLrategy,    --战略大盘采购
                 --r_Pg_Business.Verfication_Status,    --核销状态 0未核销 1已核销 2核销失败
                 --r_Pg_Business.Remark,                --备注
                 --r_Pg_Business.Is_Groupbuy,           --是否团购
                 --r_Pg_Business.Program_Updated_By,    --程序修改来源
                 trunc(sysdate), --修改时间
                 R_INTF_PG_BUSINESS_HEAD.HEAD_ID, --上级项目ID
                 R_INTF_PG_BUSINESS_HEAD.LOC_CODE --上级项目编码
		 ,V_APPENDIX_ID
     ,R_INTF_PG_BUSINESS_HEAD.Big_Panel
                 );
            EXCEPTION
              WHEN OTHERS THEN
                P_MESSAGE := V_VALUE || '出错。' || v_Nl || SQLERRM;
            END;
          END IF;
           
           IF P_MESSAGE = v_Success THEN
             OPEN C_INTF_PG_BUSINESS_LINE;
             LOOP 
               FETCH C_INTF_PG_BUSINESS_LINE
               INTO R_INTF_PG_BUSINESS_LINE;
               EXIT WHEN C_INTF_PG_BUSINESS_LINE%NOTFOUND OR P_MESSAGE <> v_Success;
               
               IF  P_MESSAGE = v_Success THEN
                 --校验行表数据
                 
                 BEGIN
                   V_VALUE := '检查营销大类：';
                   SELECT TC.CLASS_NAME
                     INTO V_SALES_MAIN_TYPE_NAME
                     FROM T_BD_ITEM_CLASS TC
                    WHERE TC.ENTITY_ID = R_INTF_PG_BUSINESS_HEAD.ENTITY_ID
                      AND TC.CLASS_CODE =
                          R_INTF_PG_BUSINESS_LINE.SALES_MAIN_TYPE
                      AND TC.ACTIVE_FLAG = 'Y'
                      AND TC.CLASS_TYPE = 'M';
                 EXCEPTION
                   WHEN OTHERS THEN
                     P_MESSAGE := V_VALUE ||
                                  R_INTF_PG_BUSINESS_LINE.SALES_MAIN_TYPE ||
                                  '失败。' || v_Nl || SQLERRM;
                 END;
                 
                 BEGIN
                   V_VALUE := '检查产品信息：';
                   SELECT TI.ITEM_ID, TI.ITEM_NAME, TI.DEFAULTUNIT
                     INTO V_ITEM_ID, V_ITEM_NAME, V_UOM_CODE
                     FROM T_BD_ITEM TI
                    WHERE TI.ENTITY_ID = R_INTF_PG_BUSINESS_HEAD.ENTITY_ID
                      AND TI.SALES_MAIN_TYPE =
                          R_INTF_PG_BUSINESS_LINE.SALES_MAIN_TYPE
                      AND TI.ACTIVE_FLAG = 'Y'
                      AND TI.ITEM_CODE = R_INTF_PG_BUSINESS_LINE.ITEM_CODE;
                 EXCEPTION
                   WHEN OTHERS THEN
                     P_MESSAGE := V_VALUE ||
                                  R_INTF_PG_BUSINESS_LINE.ITEM_CODE ||
                                  '失败。' || v_Nl || SQLERRM;
                 END;
                 
                 BEGIN
                   V_VALUE := '查询营销小类：';
                   SELECT TC.CLASS_CODE, TC.CLASS_NAME
                     INTO V_SALES_SUB_TYPE, V_SALES_SUB_TYPE_NAME
                     FROM T_BD_ITEM_CLASS TC
                    WHERE TC.CLASS_CODE =
                          (SELECT TI.SALES_SUB_TYPE
                             FROM T_BD_ITEM TI
                            WHERE TI.ITEM_CODE =
                                  R_INTF_PG_BUSINESS_LINE.ITEM_CODE)
                      AND TC.ENTITY_ID = R_INTF_PG_BUSINESS_HEAD.ENTITY_ID
                      AND TC.ACTIVE_FLAG = 'Y';
                 EXCEPTION
                   WHEN OTHERS THEN
                     P_MESSAGE := V_VALUE || '失败。不存在或无效' || v_Nl || SQLERRM;
                 END;
                 
                 /*BEGIN
                   V_VALUE := '查询产品价格：';
                   pkg_bd_price.P_GET_PRICE(v_Account_Id,r_pg_price_apply_line.ITEM_CODE,TO_CHAR(SYSDATE,'YYYYMMDD'),NULL,r_pg_price_apply_line.ENTITY_ID,V_PG_PRICE,V_DISCOUNT,V_MONTH_DISCOUNT,V_CX_FLAG);*/
                 IF P_MESSAGE = v_Success THEN
                   SELECT S_PG_BUSINESS_LINE.NEXTVAL INTO V_BUSINESS_LINE_ID FROM DUAL;
                   BEGIN
                     V_VALUE := '开始插入行表数据：';
                      Insert Into T_PG_BUSINESS_LINE
                        (bussiness_line_id, --商机商品行信息ID
                         business_id, --商机信息ID
                         sales_main_type, --营销大类编码
                         sales_main_type_name, --营销大类名称
                         sales_sub_type, --营销小类编码
                         sales_sub_type_name, --营销小类名称
                         item_id, --产品ID
                         item_code, --产品编码
                         item_desc, --产品型号
                         uom_code, --单位
                         common_price, --直供价
                         requis_price, --预计报价
                         requis_qty, --申请数量
                         created_by, --创建人
                         creation_date, --创建时间
                         last_updated_by, --修改人
                         last_update_date, --修改时间
                         entity_id --主体ID
                         )
                      Values
                        (V_BUSINESS_LINE_ID, --商机商品行信息ID
                         V_BUSINESS_ID, --商机信息ID
                         R_INTF_PG_BUSINESS_LINE.SALES_MAIN_TYPE, --营销大类编码
                         V_SALES_MAIN_TYPE_NAME, --营销大类名称
                         V_SALES_SUB_TYPE, --营销小类编码
                         V_SALES_SUB_TYPE_NAME, --营销小类名称
                         V_ITEM_ID, --产品ID
                         R_INTF_PG_BUSINESS_LINE.ITEM_CODE, --产品编码
                         V_ITEM_NAME, --产品型号
                         V_UOM_CODE, --单位
                         R_INTF_PG_BUSINESS_LINE.COMMON_PRICE, --直供价
                         R_INTF_PG_BUSINESS_LINE.REQUIS_PRICE, --预计报价
                         R_INTF_PG_BUSINESS_LINE.REQUIS_QTY, --申请数量
                         'CCS', --创建人
                         trunc(sysdate), --创建时间
                         R_INTF_PG_BUSINESS_LINE.LAST_UPDATED_BY, --修改人
                         R_INTF_PG_BUSINESS_LINE.LAST_UPDATE_DATE, --修改时间
                         R_INTF_PG_BUSINESS_HEAD.ENTITY_ID --主体ID
                         );
                    EXCEPTION
                       WHEN OTHERS THEN
                           P_MESSAGE := V_VALUE || '失败。' || v_Nl || SQLERRM;
                    END;
                  END IF;  
               END IF;
            END LOOP;         
         END IF;
         
         ----更新状态
        IF P_MESSAGE <> v_Success THEN
          UPDATE INTF_PG_BUSINESS B
             SET B.INTF_STATUS  = 'E',
                 B.INTF_ERR_MSG  = P_MESSAGE,
                 B.BUSINESS_ID  = V_BUSINESS_ID,
                 B.PROJECT_CODE = V_PROJECT_CODE
           WHERE B.HEAD_ID = P_INTF_HEAD_ID;
        ELSE
           UPDATE INTF_PG_BUSINESS B
             SET B.INTF_STATUS  = 'S',
                 B.INTF_ERR_MSG  = P_MESSAGE,
                 B.BUSINESS_ID  = V_BUSINESS_ID,
                 B.PROJECT_CODE = V_PROJECT_CODE
           WHERE B.HEAD_ID = P_INTF_HEAD_ID;
        End IF;      
    END; 
    
    
  ----------------------------------------------------------------------
  -- Author  : WANGCONG
  -- Created : 2017/04/12
  -- Purpose : 独资主体商机从CCS引入CIMS
  ----------------------------------------------------------------------
  Procedure P_PG_BUSINESS_CCS(P_INTF_HEAD_ID IN NUMBER,P_MESSAGE OUT VARCHAR2) IS
    
    V_VALUE             VARCHAR2(1024);
    V_IS_ADJUST         VARCHAR2(10);
    V_PG_PRODUCT_LINE   VARCHAR2(32); --记录是否按产品线登录，调用存储过程Pkg_Pg.P_Get_Parameter_Value，传入参数编码‘PG_PRODUCT_LINE’
                                      --是否按产品线登录，N同步到T_PG_BUSINESS_LINE，Y同步到T_PG_BUSINESS_APPROVAL
    R_INTF_PG_BUSINESS_HEAD INTF_PG_BUSINESS%ROWTYPE;
    R_INTF_PG_BUSINESS_LINE INTF_PG_BUSINESS_LINE%ROWTYPE;
    R_INTF_PG_BUSINESS_APPROVAL INTF_PG_BUSINESS_APPROVAL%ROWTYPE;
    
    --产品行数据
    CURSOR C_INTF_PG_BUSINESS_LINE IS
     SELECT * FROM INTF_PG_BUSINESS_LINE L WHERE L.HEAD_ID = P_INTF_HEAD_ID;
    
    --产品线数据
    CURSOR C_INTF_PG_BUSINESS_APPROVAL IS
     SELECT * FROM INTF_PG_BUSINESS_APPROVAL BA WHERE BA.INTF_HEAD_ID = P_INTF_HEAD_ID;
     
    V_PROJECT_CODE T_PG_BUSINESS.PROJECT_CODE%TYPE;
    V_BUSINESS_ID  T_PG_BUSINESS.BUSINESS_ID%TYPE;
    

    V_LOC_ID              T_PG_BUSINESS.LOC_ID%TYPE;
    V_LOC_NAME            T_PG_BUSINESS.LOC_NAME%TYPE;
    V_CUSTOMER_ID         T_PG_BUSINESS.CUSTOMER_ID%TYPE;
    V_CUSTOMER_NAME       T_PG_BUSINESS.CUSTOMER_NAME%TYPE;
    V_ACCOUNT_ID          T_PG_BUSINESS.ACCOUNT_ID%TYPE;
    V_ACCOUNT_CODE        T_PG_BUSINESS.ACCOUNT_CODE%TYPE;
    V_AGENT_ID            T_PG_BUSINESS.AGENT_ID%TYPE;
    V_AGENT_CODE          T_PG_BUSINESS.AGENT_CODE%TYPE;
    V_AGENT_NAME          T_PG_BUSINESS.AGENT_NAME%TYPE;
    V_SALES_CENTER_ID     T_PG_BUSINESS.SALES_CENTER_ID%TYPE;
    V_SALES_CENTER_NAME   T_PG_BUSINESS.SALES_CENTER_NAME%TYPE;
    V_PROJECT_CENTER_ID   T_PG_BUSINESS.PROJECT_CENTER_ID%TYPE;
    V_PROJECT_CENTER_NAME T_PG_BUSINESS.PROJECT_CENTER_NAME%TYPE;
    V_OTHER_LOGIN_FLAG    T_PG_BUSINESS.OTHERLOGIN_FLAG%TYPE;
    V_IS_GROUPBUY         T_PG_BUSINESS.IS_GROUPBUY%TYPE;
    V_GROUPBUY_SALES_TYPE T_PG_BUSINESS.GROUP_BUY_SALES_MAIN_TYPE%TYPE;
    V_BRAND               T_PG_BUSINESS.BRAND%TYPE;
    V_ENTITY_ID           T_PG_BUSINESS.ENTITY_ID%TYPE;
    V_BIZ_SUB_TYPE        T_PG_BUSINESS.BUSINESS_SUB_TYPE%TYPE;
    
    V_CCS_SALES_MAIN_TYPE INTF_PG_BUSINESS.CCS_SALES_MAIN_TYPE%TYPE;
    V_ORI_BUSINESS_ID    INTF_PG_BUSINESS.BUSINESS_ID%TYPE;
    V_ORI_BUSINESS_CODE  INTF_PG_BUSINESS.PROJECT_CODE%TYPE;
    
    
    V_BUSINESS_LINE_ID     T_PG_BUSINESS_LINE.BUSSINESS_LINE_ID%TYPE;
    V_ITEM_NAME            T_PG_BUSINESS_LINE.ITEM_DESC%TYPE;
    V_ITEM_ID              T_PG_BUSINESS_LINE.ITEM_ID%TYPE;
    V_SALES_MAIN_TYPE_CODE T_PG_BUSINESS_LINE.SALES_MAIN_TYPE%TYPE;
    V_SALES_MAIN_TYPE_NAME T_PG_BUSINESS_LINE.SALES_MAIN_TYPE_NAME%TYPE;
    V_SALES_SUB_TYPE_CODE  T_PG_BUSINESS_LINE.SALES_SUB_TYPE%TYPE;
    V_SALES_SUB_TYPE_NAME  T_PG_BUSINESS_LINE.SALES_SUB_TYPE_NAME%TYPE;
    V_UOM_CODE             T_PG_BUSINESS_LINE.UOM_CODE%TYPE;
    V_COMMON_PRICE         T_PG_BUSINESS_LINE.COMMON_PRICE%TYPE;
    
    
    V_BUSINESS_APPROVAL_ID T_PG_BUSINESS_APPROVAL.BUSINESS_AUDIT_ID%TYPE;
    V_PRODUCT_LINE_ID      T_PG_BUSINESS_APPROVAL.PRODUCTLINE_ID%TYPE;
    V_PRODUCT_LINE_NAME    T_PG_BUSINESS_APPROVAL.PRODUCTLINE_NAME%TYPE;
    
    V_TMP_COUNT            NUMBER;---记录行表更新受影响行数
    V_ACRONYM              VARCHAR2(50);
    V_ACRONYM_STR          VARCHAR2(50);
    
    V_BUSINESS_TYPE        T_PG_BUSINESS.BUSINESS_TYPE%TYPE;
    V_PROJECT_TYPE         T_PG_BUSINESS.PROJECT_TYPE%TYPE;
    V_GROUP_MARK           VARCHAR2(32);--团购标识，取系统参数
    V_IF_NEED_BIZ_SUB_TYPE VARCHAR2(32);
    
    V_LOGIN_TIME_COUNT     NUMBER;
    V_LOGIN_PROTECT_TIME   NUMBER;
    V_LOGIN_PROTECT_DATE   T_PG_BUSINESS.LOGIN_PTOTECT_TIME%TYPE;
    V_APPENDIX_ID VARCHAR2(100);--附件id
    
    V_SALES_MAIN_TYPE_ID NUMBER;
     
    BEGIN
      P_MESSAGE := v_Success;
      V_IS_ADJUST := 'N';
      V_TMP_COUNT := 0;
      --校验接口
      BEGIN
        V_VALUE := '锁定接口表头表失败';
        SELECT *
          INTO R_INTF_PG_BUSINESS_HEAD
          FROM INTF_PG_BUSINESS B
         WHERE B.HEAD_ID = P_INTF_HEAD_ID
           --AND B.INTF_STATUS = 'N'
           FOR UPDATE NOWAIT;
        EXCEPTION 
          WHEN OTHERS THEN
            P_MESSAGE := V_VALUE || v_Nl ||SQLERRM;
       END; 
       
       --记录事务
       SAVEPOINT P_PG_BUSINESS_CCS;
       
       -- add by tangjz2 2018-9-10
       /*if nvl(R_INTF_PG_BUSINESS_HEAD.Is_Adjust,'N') = 'Y' then
         P_MESSAGE := '调整的商机不允许调用该接口P_PG_BUSINESS_CCS';
         goto err_here;
       end if;*/
       
    
       V_IS_GROUPBUY := R_INTF_PG_BUSINESS_HEAD.IS_GROUPBUY;
       
       IF P_MESSAGE = v_Success THEN
          BEGIN
             V_VALUE := '校验来源系统：';
             IF NVL(R_INTF_PG_BUSINESS_HEAD.SOURCE_SYSTEM,'_') = '_' THEN
               RAISE V_CCS_EXCEPTION;
             END IF;
             EXCEPTION
                WHEN V_CCS_EXCEPTION THEN
                  P_MESSAGE := V_VALUE || '未录入来源系统。'|| v_Nl ||
                            SQLERRM;
            END;
        END IF;
        
        IF P_MESSAGE = v_Success THEN
          BEGIN
            V_VALUE := '校验来源项目编号：';
            IF NVL(R_INTF_PG_BUSINESS_HEAD.ORI_BUSINESS_CODE,'_') = '_' THEN
              RAISE V_CCS_EXCEPTION;
            END IF;
             EXCEPTION
              WHEN V_CCS_EXCEPTION THEN
               P_MESSAGE := V_VALUE || '未录入来源项目编号。'|| v_Nl ||
                          SQLERRM;
          END;
        END IF;
        
        IF P_MESSAGE = v_Success THEN
          BEGIN
            V_VALUE := '校验来源项目ID：';
            IF NVL(R_INTF_PG_BUSINESS_HEAD.ORI_BUSINESS_ID, 0) = 0 THEN
              RAISE V_CCS_EXCEPTION;
            END IF;
          EXCEPTION
            WHEN V_CCS_EXCEPTION THEN
              P_MESSAGE := V_VALUE || '未录入来源项目ID。'|| v_Nl ||
                          SQLERRM;
          END;
        END IF;
        
        IF P_MESSAGE = v_Success THEN
          BEGIN
            V_VALUE := '登陆类型：';
            IF NVL(R_INTF_PG_BUSINESS_HEAD.DOC_FLOW_TYPE, '_') = '_' THEN
              RAISE V_CCS_EXCEPTION;
            END IF;
          EXCEPTION
            WHEN V_CCS_EXCEPTION THEN
              P_MESSAGE := V_VALUE || '未录入登陆类型。'|| v_Nl ||
                          SQLERRM;
          END;
        END IF;
         IF P_MESSAGE = v_Success THEN
         V_BIZ_SUB_TYPE := R_INTF_PG_BUSINESS_HEAD.BUSINESS_SUB_TYPE;
           --查询是否需要商机小类
           BEGIN
              V_VALUE := '获取是否需要商机小类';
              PKG_BD.P_GET_PARAMETER_VALUE('PG_IF_NEED_BIZ_SUB_TYPE',
                                           R_INTF_PG_BUSINESS_HEAD.ENTITY_ID,
                                           Null,
                                           Null,
                                           V_IF_NEED_BIZ_SUB_TYPE);
           EXCEPTION
             WHEN OTHERS THEN
               P_MESSAGE := V_VALUE || '失败。' || v_Nl || SQLERRM;
           END;
         END IF;
         
         IF P_MESSAGE = v_Success AND V_IF_NEED_BIZ_SUB_TYPE = 'Y' THEN
           BEGIN
             V_VALUE := '校验商机小类';
             IF NVL(V_BIZ_SUB_TYPE, '_') = '_' THEN
               RAISE V_CCS_EXCEPTION;
             END IF;
           EXCEPTION
             WHEN V_CCS_EXCEPTION THEN
             P_MESSAGE := V_VALUE || '未录入商机小类。'|| v_Nl ||
                        SQLERRM;
           END;
         END IF;
         
           
        IF P_MESSAGE = v_Success THEN
          IF V_IS_GROUPBUY = '0' THEN
          --数据检查
            BEGIN
              V_VALUE := '检查项目区域：';
              SELECT TD.ROW_ID, TD.DISTRICT_NAME
                INTO V_LOC_ID, V_LOC_NAME
                FROM T_BD_DISTRICT TD
               WHERE TD.DISTRICT_CODE = R_INTF_PG_BUSINESS_HEAD.LOC_CODE
                 AND TD.ACTIVE_FLAG = 'Y';
              EXCEPTION
                WHEN OTHERS THEN
                  P_MESSAGE := V_VALUE || R_INTF_PG_BUSINESS_HEAD.LOC_CODE || '项目区域不存在或已失效。' || v_Nl ||SQLERRM;
            END;
          END IF;
        END IF;
        
        
        --工程类型转码
        IF P_MESSAGE = v_Success THEN
          BEGIN
            V_VALUE := '工程类型转码：';
            SELECT U.CODE_VALUE
              INTO V_PROJECT_TYPE
              FROM UP_CODELIST U
             WHERE U.CODE_VALUE = R_INTF_PG_BUSINESS_HEAD.PROJECT_TYPE
               AND U.CODETYPE = 'tpgProjectType';
          EXCEPTION
            WHEN OTHERS THEN
              P_MESSAGE := V_VALUE || '工程类型' ||
                          TO_CHAR(R_INTF_PG_BUSINESS_HEAD.PROJECT_TYPE) ||
                          '不存在或者已失效。';
          END;
        END IF;

        --检查开户客户信息
        IF P_MESSAGE = v_Success THEN
          IF nvl(R_INTF_PG_BUSINESS_HEAD.Is_Open,'Y') = 'N' THEN
             if R_INTF_PG_BUSINESS_HEAD.Source_Customer_Code is null or R_INTF_PG_BUSINESS_HEAD.Source_Customer_name is null then
                P_MESSAGE :=   R_INTF_PG_BUSINESS_HEAD.CUSTOMER_CODE || '未开户项目来源客户信息不能为空。' ;
             end if;
          
          ELSIF nvl(R_INTF_PG_BUSINESS_HEAD.Is_Open,'Y') = 'Y' THEN
              BEGIN
                V_VALUE := '检查经销商：';
                SELECT CH.CUSTOMER_ID, CH.CUSTOMER_NAME
                  INTO V_CUSTOMER_ID, V_CUSTOMER_NAME
                  FROM T_CUSTOMER_HEADER CH
                 WHERE CH.CUSTOMER_CODE = R_INTF_PG_BUSINESS_HEAD.CUSTOMER_CODE
                   AND CH.ACTIVE_FLAG = 'Active';
              EXCEPTION
                WHEN OTHERS THEN
                  P_MESSAGE := V_VALUE || R_INTF_PG_BUSINESS_HEAD.CUSTOMER_CODE || '经销商不存在或已失效。' || V_NL || SQLERRM;
              END;
          END IF;
        END IF;  
        /*BEGIN
           V_VALUE := '检查分销商：';
           IF NVL(R_INTF_PG_BUSINESS_HEAD.AGENT_CODE,'_') = '_' THEN
             RAISE V_CCS_EXCEPTION;
           END IF;
           EXCEPTION
            WHEN V_CCS_EXCEPTION THEN
             P_MESSAGE := V_VALUE || '未录入分销商信息。'|| v_Nl ||
                        SQLERRM;
        END;*/
       IF P_MESSAGE = v_Success THEN  
         BEGIN
            V_VALUE := '检查营销中心：';
            SELECT U.UNIT_ID, U.NAME
              INTO V_SALES_CENTER_ID, V_SALES_CENTER_NAME
              FROM UP_ORG_UNIT U
             WHERE U.CODE = R_INTF_PG_BUSINESS_HEAD.SALES_CENTER_CODE
               AND U.ENTITY_ID = R_INTF_PG_BUSINESS_HEAD.ENTITY_ID
               AND U.ACTIVE_FLAG = 'T';
            EXCEPTION
              WHEN OTHERS THEN
                P_MESSAGE := V_VALUE || '营销中心不存在或已失效。中心编码：' || R_INTF_PG_BUSINESS_HEAD.SALES_CENTER_CODE 
                || '，主体ID：' ||R_INTF_PG_BUSINESS_HEAD.ENTITY_ID || '，' || v_Nl ||SQLERRM;
         END;
       END IF;
       
       IF P_MESSAGE = v_Success THEN
         IF R_INTF_PG_BUSINESS_HEAD.LOGIN_PTOTECT_TIME IS NULL THEN
           BEGIN
             V_VALUE := '检查登陆保护日期：';
             SELECT COUNT(*)
               INTO V_LOGIN_TIME_COUNT
               FROM T_PG_LOGIN_PROTECT_TIME T
              WHERE T.ENTITY_ID = R_INTF_PG_BUSINESS_HEAD.ENTITY_ID
                AND T.SALES_CENTER_CODE =
                    R_INTF_PG_BUSINESS_HEAD.SALES_CENTER_CODE;
             
             IF V_LOGIN_TIME_COUNT = 1 THEN
               SELECT T.LOGIN_PROTECT_TIME
                 INTO V_LOGIN_PROTECT_TIME
                 FROM T_PG_LOGIN_PROTECT_TIME T
                WHERE T.ENTITY_ID = R_INTF_PG_BUSINESS_HEAD.ENTITY_ID
                  AND T.SALES_CENTER_CODE =
                      R_INTF_PG_BUSINESS_HEAD.SALES_CENTER_CODE;
                
                V_LOGIN_PROTECT_DATE := SYSDATE+V_LOGIN_PROTECT_TIME;
             ELSIF V_LOGIN_TIME_COUNT = 0 THEN
               V_LOGIN_PROTECT_DATE := add_months(sysdate - 1, 3);
             ELSIF V_LOGIN_TIME_COUNT > 1 THEN
                RAISE V_CCS_EXCEPTION;
             END IF;
            EXCEPTION
              WHEN V_CCS_EXCEPTION THEN
                P_MESSAGE := V_VALUE || '出错，请检查CIMS登陆保护日期配置。' || v_Nl ||SQLERRM;
              WHEN OTHERS THEN
                P_MESSAGE := V_VALUE || '出错，请检查CIMS登陆保护日期配置。' || v_Nl ||SQLERRM;
            END;
          ELSE 
            V_LOGIN_PROTECT_DATE := R_INTF_PG_BUSINESS_HEAD.LOGIN_PTOTECT_TIME;
          END IF;
        END IF;
        
        IF P_MESSAGE = v_Success and nvl(R_INTF_PG_BUSINESS_HEAD.Is_Open,'Y') = 'Y' THEN
          BEGIN
            V_VALUE := '检查账户：';
            SELECT VC.account_id,VC.account_code
              INTO V_ACCOUNT_ID,V_ACCOUNT_CODE
              FROM V_CUSTOMER_ACCOUNT_SALECENTER VC
             WHERE VC.entity_id = R_INTF_PG_BUSINESS_HEAD.ENTITY_ID
               AND VC.active_flag = 'Active'
               AND VC.orgActive_flag = 'Active'
               AND VC.account_status = '1'
               AND VC.sales_center_code =
                   R_INTF_PG_BUSINESS_HEAD.SALES_CENTER_CODE
               AND VC.customer_code = R_INTF_PG_BUSINESS_HEAD.CUSTOMER_CODE;
             EXCEPTION
               WHEN OTHERS THEN
                 P_MESSAGE := V_VALUE || R_INTF_PG_BUSINESS_HEAD.ACCOUNT_ID || '账户不存在或已失效。' || v_Nl || SQLERRM;
           END;
         END IF;      
         
         IF V_IS_GROUPBUY = '0' AND  P_MESSAGE = v_Success THEN
           BEGIN
             V_VALUE := '检查项目所在中心：';
            SELECT U.UNIT_ID, U.NAME
              INTO V_PROJECT_CENTER_ID, V_PROJECT_CENTER_NAME
              FROM UP_ORG_UNIT U
             WHERE U.CODE = R_INTF_PG_BUSINESS_HEAD.PROJECT_CENTER_CODE
               AND U.ENTITY_ID = R_INTF_PG_BUSINESS_HEAD.ENTITY_ID
               AND U.ACTIVE_FLAG = 'T';
             EXCEPTION
               WHEN OTHERS THEN
                 P_MESSAGE := V_VALUE || R_INTF_PG_BUSINESS_HEAD.PROJECT_CENTER_CODE || '不存在或已失效。' || v_Nl ||SQLERRM;
           END;
         END IF;
         

         
         ------------检查品牌和大类--------------
         IF P_MESSAGE = v_Success THEN
           V_BRAND := R_INTF_PG_BUSINESS_HEAD.BRAND;
           V_CCS_SALES_MAIN_TYPE := R_INTF_PG_BUSINESS_HEAD.CCS_SALES_MAIN_TYPE;
           IF V_BRAND IS NOT NULL AND V_CCS_SALES_MAIN_TYPE IS NOT NULL THEN
             --转换为CIMS大类
             BEGIN
               V_VALUE := '转换CIMS大类，';
               SELECT R.SC_ITEM_CLASS_CODE
                 INTO V_GROUPBUY_SALES_TYPE
                 FROM T_BD_ITEM_CLASS_RELATION R
               WHERE R.HQ_ITEM_CLASS_CODE = V_CCS_SALES_MAIN_TYPE
                 AND R.HQ_ITEM_BRAND = V_BRAND;
               EXCEPTION
               WHEN OTHERS THEN
                 P_MESSAGE := V_VALUE || '大类：' || V_CCS_SALES_MAIN_TYPE || '品牌：'|| V_BRAND || '失败，请检查CIMS与CCS大类对应关系。' || v_Nl ||SQLERRM;
             END;
           END IF;
         END IF;
         
         -----------判断是否是更新操作-----------------
         --V_ORI_BUSINESS_ID := R_INTF_PG_BUSINESS_HEAD.BUSINESS_ID;
         IF P_MESSAGE = v_Success THEN
           V_ORI_BUSINESS_CODE := R_INTF_PG_BUSINESS_HEAD.PROJECT_CODE;
           
           IF V_ORI_BUSINESS_CODE IS NOT NULL THEN
             V_IS_ADJUST := 'Y';
             SELECT TB.BUSINESS_ID
             INTO V_ORI_BUSINESS_ID
             FROM T_PG_BUSINESS TB
             WHERE TB.PROJECT_CODE = V_ORI_BUSINESS_CODE;
             
             V_BUSINESS_ID := V_ORI_BUSINESS_ID;
             V_PROJECT_CODE := V_ORI_BUSINESS_CODE;
           END IF;
         END IF;
         
         IF P_MESSAGE = v_Success THEN
           --查询系统参数
           BEGIN
              V_VALUE := '获取主体参数';
              PKG_BD.P_GET_PARAMETER_VALUE('PG_PRODUCT_LINE',
                                           R_INTF_PG_BUSINESS_HEAD.ENTITY_ID,
                                           Null,
                                           Null,
                                           V_PG_PRODUCT_LINE);
           EXCEPTION
             WHEN OTHERS THEN
               P_MESSAGE := V_VALUE || '失败。' || v_Nl || SQLERRM;
           END;
         END IF;
        
         IF P_MESSAGE = v_Success THEN
           --取团购标识
           BEGIN
             V_VALUE := '查询团购标识：';
             PKG_BD.P_GET_PARAMETER_VALUE('PG_GROUP_BUY_MARK',
                                           R_INTF_PG_BUSINESS_HEAD.ENTITY_ID,
                                           Null,
                                           Null,
                                           V_GROUP_MARK);
           EXCEPTION
             WHEN OTHERS THEN
               P_MESSAGE := V_VALUE || '出错。' || v_Nl || SQLERRM;
           END;
         END IF;
         
         IF P_MESSAGE = v_Success  THEN
           --判断是否异地登陆
           IF R_INTF_PG_BUSINESS_HEAD.SALES_CENTER_CODE = R_INTF_PG_BUSINESS_HEAD.PROJECT_CENTER_CODE THEN
              V_OTHER_LOGIN_FLAG := 'N';
              V_BUSINESS_TYPE := '0';
           ELSE
              V_OTHER_LOGIN_FLAG := 'Y';
              V_BUSINESS_TYPE := '1';
           END IF;
           
           IF V_IS_GROUPBUY = '1' AND V_GROUP_MARK = 'Y' THEN
             V_BUSINESS_TYPE := '3';
           END IF;
         END IF;
           
         
                  
	
    
         IF V_IS_GROUPBUY = '1' AND V_GROUP_MARK = 'Y' AND  P_MESSAGE = v_Success  THEN
           BEGIN
             V_VALUE := '检查项目安装涉及区域：';
             IF R_INTF_PG_BUSINESS_HEAD.REFER_AREA_ID IS NULL OR R_INTF_PG_BUSINESS_HEAD.REFER_AREA IS NULL THEN
                RAISE V_CCS_EXCEPTION;
             END IF;
           EXCEPTION
             WHEN V_CCS_EXCEPTION THEN
               P_MESSAGE := V_VALUE || '未录入。'|| v_Nl ||
                           SQLERRM;
           END;
         END IF;
         
         ---头表
         IF P_MESSAGE =  v_Success THEN              
            IF V_IS_ADJUST = 'N' THEN
               SELECT S_PG_BUSINESS.NEXTVAL INTO V_BUSINESS_ID FROM DUAL;
               --营销中心简称
               SELECT T.EXT_TEXTBOX
                 INTO V_ACRONYM
                 FROM UP_ORG_UNIT_EXT T
                WHERE T.ID IN
                      (SELECT U.ID
                         FROM UP_ORG_UNIT U
                        WHERE U.CODE =
                              R_INTF_PG_BUSINESS_HEAD.SALES_CENTER_CODE);
               IF V_GROUP_MARK = 'Y' AND R_INTF_PG_BUSINESS_HEAD.IS_GROUPBUY = '1' THEN
                 --生成团购登陆编码
                 V_ACRONYM_STR := 'TG'|| V_ACRONYM || '录';
                 BEGIN
                   V_VALUE := '生成团购登陆编码：';
                   PKG_BD.P_GET_BILL_NO('TG_PROJECT_CODE',
                                         V_ACRONYM_STR,
                                         R_INTF_PG_BUSINESS_HEAD.ENTITY_ID,
                                         Null,
                                         V_PROJECT_CODE);
                 EXCEPTION
                   WHEN OTHERS THEN
                     P_MESSAGE := V_VALUE || '出错。' || v_Nl || SQLERRM;
                 END;
               ELSE
                 V_ACRONYM_STR := V_ACRONYM || '录'|| R_INTF_PG_BUSINESS_HEAD.ENTITY_ID;
                 BEGIN
                   V_VALUE := '生成商机编码：';
                   PKG_BD.P_GET_BILL_NO('tpgProjectCode',
                                        V_ACRONYM_STR,
                                        R_INTF_PG_BUSINESS_HEAD.ENTITY_ID,
                                        Null,
                                        V_PROJECT_CODE);
                 EXCEPTION
                   WHEN OTHERS THEN
                     P_MESSAGE := V_VALUE || '出错。' || v_Nl || SQLERRM;
                 END;
               END IF;
               --V_PROJECT_CODE := '测试'|| V_BUSINESS_ID;
                 V_APPENDIX_ID:=NULL;
      PKG_PG_INTF.P_PG_BUSINESS_FILE_TRANSFER(P_INTF_HEAD_ID => P_INTF_HEAD_ID,V_SUCCESS =>V_SUCCESS,P_MESSAGE =>P_MESSAGE,V_APPENDIX_ID =>V_APPENDIX_ID )  ;
	      
	      ----新增操作
              BEGIN
                V_VALUE := '插入正式表头表';
                INSERT INTO T_PG_BUSINESS
                  (business_id, --商机信息ID
                   project_code, --项目编号
                   project_name, --项目名称
                   user_firm, --使用单位名称
                   user_phone, --项目方联系电话
                   user_name, --项目方联系人
                   project_address, --工程项目详细地址
                   loc_id, --区域ID
                   loc_code, --项目所在区域
                   loc_name, --区域编码名称
                   project_center_id, --项目所在中心ID
                   project_center_code, --项目所在中心编码
                   project_center_name, --项目所在中心名称
                   customer_id, --经销商ID
                   customer_code, --经销商编码
                   customer_name, --经销商名称
                   sales_center_id, --营销中心ID
                   sales_center_name, --营销中心名称
                   sales_center_code, --营销中心编码
                   account_id, --账户ID
                   account_code,          --账户名称
                   agent_id, --经销商ID
                   agent_code, --经销商编码
                   agent_name, --经销商名称
                   project_type, --工程类型:精装房产配套、公租保障配套、家装橱柜配套、燃气公司合作
                   expected_bid_time, --预计投标时间
                   login_time, --登录日期
                   login_ptotect_time, --登录保护时间
                   project_num, --项目规模
                   project_progress, --项目进度:在建项目、建好未定、准备投标
                   business_type, --商机类型
                   delivery_cycle, --供货周期:单位为天
                   buyout_type, --买断类型:事前买断、时候买断
                   customer_person,       --经销商联系人
                   customer_person_phone, --联系方式
                   area_manager,          --区域经理
                   area_manager_phone,    --区域经理电话
                   install_flag, --是否我司安装
                   otherlogin_flag, --是否是异地登录
                   status, --登录状态，有以下几种：已录入、已送审、已审核、已退回、已作废
                   --  competitors,           --工程竞争对手
                   special_need, --特殊要求
                   other_desc, --其他说明资料
                   entity_id, --主体ID
                   created_by, --创建人
                   creation_date, --创建时间
                   last_updated_by, --修改人
                   last_update_date, --修改时间
                   --send_person,           --送审人
                   --send_date,             --送审日期
                   --approval_person,       --审核人
                   --approval_date,         --审核日期
                   --back_person,           --退回人
                   --back_date,             --退回日期
                   --scrapped_person,       --作废人
                   --scrapped_date,         --作废时间
                   --relogin_flag,          --重新登录标识
                   bid_status, --中标状态
                   --freeze_status,         --冻结状态
                   --freeze_person,         --冻结人
                   --freeze_time,           --冻结时间
                   --unfreeze_person,       --解冻人
                   --unfreeze_time,         --解冻时间
                   --is_market_strategy,    --战略大盘采购
                   --verfication_status,    --核销状态 0未核销 1已核销 2核销失败
                   --remark,                --备注
                   is_groupbuy,           --是否团购
                   --program_updated_by,    --程序修改来源
                   program_update_date, --修改时间
                   ori_business_id, --上级项目ID
                   ori_business_code, --上级项目编码
                   trade,--所属行业
                   brand,--品牌
                   category,--品类
                   customer_fax,--经销商传真电话
                   follow_man,--分部业务员
                   follower_telephone,--分部业务员电话
                   main_material,--涉及机型
                   query_keywords,--查询关键字
                   stat_keywords,--统计关键字
                   tg_commissioner,--团购专员
                   tg_commi_phone,--团购专员电话
                   refer_area_id,--安装涉及区域ID
                   refer_area,--安装涉及区域
                   deal_start_date,--登录开始日期
                   deal_end_date,--登录结束日期
                   group_buy_sales_main_type,--营销大类
                   source_system,
                   business_sub_type
                    ,APPENDIX_ID2
                    ,is_adjust
                    ,DOCUMENT_TYPE
		                ,SOURCE_BUSINESS_ID --来源总工程id
                    ,IS_OPEN --是否开户
                    ,SOURCE_CUSTOMER_CODE --来源客户编码
                    ,SOURCE_CUSTOMER_NAME --来源客户名称
                    ,IS_FROM_OVIDATABASE  --是否引自奥维数据库 add by houhs at 20190322
                    ,big_panel
		                )
                Values
                  (V_BUSINESS_ID, --商机信息ID
                   V_PROJECT_CODE, --项目编号
                   R_INTF_PG_BUSINESS_HEAD.PROJECT_NAME, --项目名称
                   R_INTF_PG_BUSINESS_HEAD.USER_FIRM, --使用单位名称
                   R_INTF_PG_BUSINESS_HEAD.USER_PHONE, --项目方联系电话
                   R_INTF_PG_BUSINESS_HEAD.USER_NAME, --项目方联系人
                   R_INTF_PG_BUSINESS_HEAD.PROJECT_ADDRESS, --工程项目详细地址
                   V_LOC_ID, --区域ID
                   R_INTF_PG_BUSINESS_HEAD.LOC_CODE, --项目所在区域
                   V_LOC_NAME, --区域编码名称
                   V_PROJECT_CENTER_ID, --项目所在中心ID
                   R_INTF_PG_BUSINESS_HEAD.PROJECT_CENTER_CODE, --项目所在中心编码
                   V_PROJECT_CENTER_NAME, --项目所在中心名称
                   V_CUSTOMER_ID,
                   R_INTF_PG_BUSINESS_HEAD.CUSTOMER_CODE,
                   V_CUSTOMER_NAME,
                   V_SALES_CENTER_ID, --营销中心ID
                   V_SALES_CENTER_NAME, --营销中心名称
                   R_INTF_PG_BUSINESS_HEAD.SALES_CENTER_CODE, --营销中心编码
                   V_ACCOUNT_ID, --账户ID
                   V_ACCOUNT_CODE,                      --账户名称
                   R_INTF_PG_BUSINESS_HEAD.AGENT_ID, --经销商ID
                   R_INTF_PG_BUSINESS_HEAD.AGENT_CODE, --经销商编码
                   R_INTF_PG_BUSINESS_HEAD.AGENT_NAME, --经销商名称
                   V_PROJECT_TYPE,
                   trunc(sysdate), --v_Expected_Bid_Time,--预计投标时间
                   trunc(sysdate),--trunc(sysdate),
                   --to_date(sysdate,'yyyy-MM-dd HH24:mi:ss'), --登录日期
                   V_LOGIN_PROTECT_DATE,--add_months(sysdate - 1, 3), --登录保护时间
                   R_INTF_PG_BUSINESS_HEAD.PROJECT_NUM, --项目规模
                   R_INTF_PG_BUSINESS_HEAD.PROJECT_PROGRESS, --项目进度:在建项目、建好未定、准备投标
                   V_BUSINESS_TYPE, --存在问题，先置为0
                   R_INTF_PG_BUSINESS_HEAD.DELIVERY_CYCLE, --供货周期:单位为天
                   R_INTF_PG_BUSINESS_HEAD.BUYOUT_TYPE, --买断类型:事前买断、时候买断
                   R_INTF_PG_BUSINESS_HEAD.CUSTOMER_PERSON,           --经销商联系人
                   R_INTF_PG_BUSINESS_HEAD.CUSTOMER_PERSON_PHONE,     --联系方式
                   R_INTF_PG_BUSINESS_HEAD.AREA_MANAGER,            --区域经理
                   R_INTF_PG_BUSINESS_HEAD.AREA_MANAGER_PHONE,    --区域经理电话
                   R_INTF_PG_BUSINESS_HEAD.INSTALL_FLAG, --是否我司安装
                   V_OTHER_LOGIN_FLAG, --是否是异地登录
                   '0', --登录状态:已审核
                   --   R_INTF_PG_BUSINESS_HEAD.Main_Material,         --工程竞争对手
                   R_INTF_PG_BUSINESS_HEAD.SPECIAL_NEED, --特殊要求
                   R_INTF_PG_BUSINESS_HEAD.OTHER_DESC, --其他说明资料
                   R_INTF_PG_BUSINESS_HEAD.ENTITY_ID, --主体ID
                   'CCS', --创建人
                   sysdate,
                   --to_date(sysdate,'yyyy-MM-dd HH24:mi:ss'), --创建时间
                   R_INTF_PG_BUSINESS_HEAD.LAST_UPDATED_BY, --修改人
                   R_INTF_PG_BUSINESS_HEAD.LAST_UPDATE_DATE, --修改时间
                   -- r_Pg_Business.To_Checkup_By_Name,    --送审人
                   -- r_Pg_Business.To_Checkup_Date,       --送审日期
                   -- r_Pg_Business.Checkup_By_Name,       --审核人
                   -- r_Pg_Business.Checkup_Date,          --审核日期
                   -- r_Pg_Business.Back_By_Name,          --退回人
                   -- r_Pg_Business.Back_Date,             --退回日期
                   --- r_Pg_Business.Back_By,               --作废人
                   -- r_Pg_Business.Reject_Date,           --作废时间
                   --r_Pg_Business.Relogin_Flag,          --重新登录标识
                   '0', --中标状态
                   --r_Pg_Business.Freeze_Status,         --冻结状态
                   --r_Pg_Business.Freeze_Person,         --冻结人
                   --r_Pg_Business.Freeze_Time,           --冻结时间
                   --r_Pg_Business.Unfreeze_Person,       --解冻人
                   --r_Pg_Business.Unfreeze_Time,         --解冻时间
                   --r_Pg_Business.Is_Market_StLrategy,    --战略大盘采购
                   --r_Pg_Business.Verfication_Status,    --核销状态 0未核销 1已核销 2核销失败
                   --r_Pg_Business.Remark,                --备注
                   R_INTF_PG_BUSINESS_HEAD.IS_GROUPBUY,           --是否团购
                   --r_Pg_Business.Program_Updated_By,    --程序修改来源
                   sysdate,
                   --to_date(sysdate,'yyyy-MM-dd HH24:mi:ss'), --修改时间
                   R_INTF_PG_BUSINESS_HEAD.ORI_BUSINESS_ID, --上级项目ID
                   R_INTF_PG_BUSINESS_HEAD.ORI_BUSINESS_CODE, --上级项目编码
                   R_INTF_PG_BUSINESS_HEAD.TRADE, ----所属行业
                   R_INTF_PG_BUSINESS_HEAD.BRAND, ----品牌
                   R_INTF_PG_BUSINESS_HEAD.CATEGORY, ----品类
                   R_INTF_PG_BUSINESS_HEAD.CUSTOMER_FAX, ----经销商传真电话
                   R_INTF_PG_BUSINESS_HEAD.FOLLOW_MAN, ----分部业务员
                   R_INTF_PG_BUSINESS_HEAD.FOLLOWER_TELEPHONE, ----分部业务员电话
                   R_INTF_PG_BUSINESS_HEAD.MAIN_MATERIAL, ----涉及机型
                   R_INTF_PG_BUSINESS_HEAD.QUERY_KEYWORDS, ----查询关键字
                   R_INTF_PG_BUSINESS_HEAD.STAT_KEYWORDS, ----统计关键字
                   R_INTF_PG_BUSINESS_HEAD.TG_COMMISSIONER, ----团购专员
                   R_INTF_PG_BUSINESS_HEAD.TG_COMMI_PHONE, ----团购专员电话
                   R_INTF_PG_BUSINESS_HEAD.REFER_AREA_ID, ----安装涉及区域ID
                   R_INTF_PG_BUSINESS_HEAD.REFER_AREA, ----安装涉及区域
                   R_INTF_PG_BUSINESS_HEAD.DEAL_START_DATE, ----登录开始日期
                   R_INTF_PG_BUSINESS_HEAD.DEAL_END_DATE, ----登录结束日期
                   V_GROUPBUY_SALES_TYPE, ----营销大类
                   R_INTF_PG_BUSINESS_HEAD.SOURCE_SYSTEM ,
                   R_INTF_PG_BUSINESS_HEAD.BUSINESS_SUB_TYPE,
                   V_APPENDIX_ID,
                   R_INTF_PG_BUSINESS_HEAD.Is_Adjust,
                   '0'
		               ,R_INTF_PG_BUSINESS_HEAD.SOURCE_BUSINESS_ID --来源总工程id
                   ,R_INTF_PG_BUSINESS_HEAD.IS_OPEN --是否开户
                   ,R_INTF_PG_BUSINESS_HEAD.SOURCE_CUSTOMER_CODE --来源客户编码
                   ,R_INTF_PG_BUSINESS_HEAD.SOURCE_CUSTOMER_NAME --来源客户名称
                   ,R_INTF_PG_BUSINESS_HEAD.IS_FROM_OVIDATABASE  --是否引自奥维数据库
                   ,R_INTF_PG_BUSINESS_HEAD.Big_Panel
		   );
              EXCEPTION
                WHEN OTHERS THEN
                  P_MESSAGE := V_VALUE || '出错。' || v_Nl || SQLERRM;
              END;
            ELSIF V_IS_ADJUST = 'Y' AND  P_MESSAGE = v_Success THEN
			              V_APPENDIX_ID:=NULL;
      PKG_PG_INTF.P_PG_BUSINESS_FILE_TRANSFER(P_INTF_HEAD_ID => P_INTF_HEAD_ID,V_SUCCESS =>V_SUCCESS,P_MESSAGE =>P_MESSAGE,V_APPENDIX_ID =>V_APPENDIX_ID )  ;
	
              ----更新操作
              BEGIN
                V_VALUE := '更新头表数据';
                UPDATE T_PG_BUSINESS TB SET 
                       TB.PROJECT_NAME = R_INTF_PG_BUSINESS_HEAD.PROJECT_NAME,--项目名称
                       TB.USER_FIRM = R_INTF_PG_BUSINESS_HEAD.USER_FIRM,    ---使用单位名称
                       TB.USER_PHONE = R_INTF_PG_BUSINESS_HEAD.USER_PHONE,  ---项目方联系电话
                       TB.USER_NAME = R_INTF_PG_BUSINESS_HEAD.USER_NAME,    ---项目方联系人
                       TB.PROJECT_ADDRESS = R_INTF_PG_BUSINESS_HEAD.PROJECT_ADDRESS,---工程项目详细地址
                       TB.LOC_ID = V_LOC_ID,          ----区域ID
                       TB.LOC_CODE = R_INTF_PG_BUSINESS_HEAD.LOC_CODE,      ----项目所在区域
                       TB.LOC_NAME = V_LOC_NAME,      ----区域编码名称
                       TB.PROJECT_CENTER_ID = V_PROJECT_CENTER_ID,     ----项目所在中心ID
                       TB.PROJECT_CENTER_CODE = R_INTF_PG_BUSINESS_HEAD.PROJECT_CENTER_CODE, ----项目所在中心编码
                       TB.PROJECT_CENTER_NAME = V_PROJECT_CENTER_NAME, ----项目所在中心名称
                       TB.CUSTOMER_ID = V_CUSTOMER_ID,    ----客户ID
                       TB.CUSTOMER_CODE = R_INTF_PG_BUSINESS_HEAD.CUSTOMER_CODE, ----客户编码
                       TB.CUSTOMER_NAME = V_CUSTOMER_NAME,   ----客户名称
                       TB.SALES_CENTER_ID = V_SALES_CENTER_ID, ----营销中心ID
                       TB.SALES_CENTER_NAME = V_SALES_CENTER_NAME, ----营销中心名称
                       TB.SALES_CENTER_CODE = R_INTF_PG_BUSINESS_HEAD.SALES_CENTER_CODE,   ----营销中心编码
                       TB.ACCOUNT_ID = V_ACCOUNT_ID, ----账户ID
                       TB.ACCOUNT_CODE = R_INTF_PG_BUSINESS_HEAD.ACCOUNT_CODE, ----账户编码
                       TB.AGENT_ID = R_INTF_PG_BUSINESS_HEAD.AGENT_ID,  ----分销商ID
                       TB.AGENT_CODE = R_INTF_PG_BUSINESS_HEAD.AGENT_CODE,  ----分销商编码
                       TB.AGENT_NAME = R_INTF_PG_BUSINESS_HEAD.AGENT_NAME,  ----分销商名称
                       TB.PROJECT_TYPE = R_INTF_PG_BUSINESS_HEAD.PROJECT_TYPE,   ----登陆类型
                       TB.EXPECTED_BID_TIME = trunc(sysdate),
                       TB.LOGIN_TIME = trunc(sysdate),--to_date(sysdate,'yyyy-MM-dd HH24:mi:ss'), ----登录时间
                       TB.LOGIN_PTOTECT_TIME = V_LOGIN_PROTECT_DATE,--add_months(sysdate - 1, 3),  ----登陆保护时间
                       TB.PROJECT_NUM = R_INTF_PG_BUSINESS_HEAD.PROJECT_NUM, ----项目规模
                       TB.PROJECT_PROGRESS = R_INTF_PG_BUSINESS_HEAD.PROJECT_PROGRESS, ----项目进度
                       TB.BUSINESS_TYPE = V_BUSINESS_TYPE,
                       TB.DELIVERY_CYCLE = R_INTF_PG_BUSINESS_HEAD.DELIVERY_CYCLE, ----供货周期
                       TB.BUYOUT_TYPE = R_INTF_PG_BUSINESS_HEAD.BUYOUT_TYPE,   ----买断类型
                       TB.CUSTOMER_PERSON = R_INTF_PG_BUSINESS_HEAD.CUSTOMER_PERSON, ----经销商联系人
                       TB.CUSTOMER_PERSON_PHONE = R_INTF_PG_BUSINESS_HEAD.CUSTOMER_PERSON_PHONE,----联系方式
                       TB.AREA_MANAGER = R_INTF_PG_BUSINESS_HEAD.AREA_MANAGER, ----区域经理
                       TB.AREA_MANAGER_PHONE = R_INTF_PG_BUSINESS_HEAD.AREA_MANAGER_PHONE, ----区域经理电话
                       TB.INSTALL_FLAG = R_INTF_PG_BUSINESS_HEAD.INSTALL_FLAG, ----是否我司安装
                       TB.OTHERLOGIN_FLAG = V_OTHER_LOGIN_FLAG, ----是否是异地登录
                       TB.STATUS = '0',   ----状态
                       TB.COMPETITORS = R_INTF_PG_BUSINESS_HEAD.COMPETITORS, ---- 工程竞争对手
                       TB.SPECIAL_NEED = R_INTF_PG_BUSINESS_HEAD.SPECIAL_NEED, ----特殊要求
                       TB.OTHER_DESC = R_INTF_PG_BUSINESS_HEAD.OTHER_DESC, ----其他说明资料
                       TB.CREATED_BY = 'CCS',----创建人
                       TB.CREATION_DATE = sysdate,--to_date(sysdate,'yyyy-MM-dd HH24:mi:ss'), ----创建时间
                       TB.LAST_UPDATED_BY = 'CCS',----修改人
                       TB.LAST_UPDATE_DATE = sysdate,--to_date(sysdate,'yyyy-MM-dd HH24:mi:ss'), ----修改时间
                       TB.BID_STATUS = '0', ----中标状态
                       TB.PROGRAM_UPDATED_BY = 'CCS', ---- 程序修改来源
                       TB.PROGRAM_UPDATE_DATE = trunc(sysdate), ----程序修改时间
                       TB.ORI_BUSINESS_ID = R_INTF_PG_BUSINESS_HEAD.ORI_BUSINESS_ID, ----上级项目ID
                       TB.ORI_BUSINESS_CODE = R_INTF_PG_BUSINESS_HEAD.ORI_BUSINESS_CODE, ----上级项目编码
                       TB.TRADE = R_INTF_PG_BUSINESS_HEAD.TRADE, ----所属行业
                       TB.BRAND = R_INTF_PG_BUSINESS_HEAD.BRAND, ----品牌
                       TB.CATEGORY = R_INTF_PG_BUSINESS_HEAD.CATEGORY, ----品类
                       TB.CUSTOMER_FAX = R_INTF_PG_BUSINESS_HEAD.CUSTOMER_FAX, ----经销商传真电话
                       TB.FOLLOW_MAN = R_INTF_PG_BUSINESS_HEAD.FOLLOW_MAN, ----分部业务员
                       TB.FOLLOWER_TELEPHONE = R_INTF_PG_BUSINESS_HEAD.FOLLOWER_TELEPHONE, ----分部业务员电话
                       TB.MAIN_MATERIAL = R_INTF_PG_BUSINESS_HEAD.MAIN_MATERIAL, ----涉及机型
                       TB.QUERY_KEYWORDS = R_INTF_PG_BUSINESS_HEAD.QUERY_KEYWORDS, ----查询关键字
                       TB.STAT_KEYWORDS = R_INTF_PG_BUSINESS_HEAD.STAT_KEYWORDS, ----统计关键字
                       TB.TG_COMMISSIONER = R_INTF_PG_BUSINESS_HEAD.TG_COMMISSIONER, ----团购专员
                       TB.TG_COMMI_PHONE = R_INTF_PG_BUSINESS_HEAD.TG_COMMI_PHONE, ----团购专员电话
                       TB.REFER_AREA_ID = R_INTF_PG_BUSINESS_HEAD.REFER_AREA_ID, ----安装涉及区域ID
                       TB.REFER_AREA = R_INTF_PG_BUSINESS_HEAD.REFER_AREA, ----安装涉及区域
                       TB.DEAL_START_DATE = R_INTF_PG_BUSINESS_HEAD.DEAL_START_DATE, ----登录开始日期
                       TB.DEAL_END_DATE = R_INTF_PG_BUSINESS_HEAD.DEAL_END_DATE, ----登录结束日期
                       TB.GROUP_BUY_SALES_MAIN_TYPE = V_GROUPBUY_SALES_TYPE, ----营销大类 
                       TB.IS_GROUPBUY = R_INTF_PG_BUSINESS_HEAD.IS_GROUPBUY,
                       TB.BUSINESS_SUB_TYPE = R_INTF_PG_BUSINESS_HEAD.BUSINESS_SUB_TYPE,
					   TB.APPENDIX_ID2=V_APPENDIX_ID
                   ,  TB.SOURCE_BUSINESS_ID=R_INTF_PG_BUSINESS_HEAD.SOURCE_BUSINESS_ID --来源总工程id
                   ,  TB.IS_OPEN=R_INTF_PG_BUSINESS_HEAD.IS_OPEN --是否开户
                   ,  TB.SOURCE_CUSTOMER_CODE=R_INTF_PG_BUSINESS_HEAD.SOURCE_CUSTOMER_CODE --来源客户编码
                   ,  TB.SOURCE_CUSTOMER_NAME=R_INTF_PG_BUSINESS_HEAD.SOURCE_CUSTOMER_NAME --来源客户名称
                 WHERE TB.PROJECT_CODE = V_ORI_BUSINESS_CODE;
              END;
            END IF;    
          END IF;
           
         --行表
         IF P_MESSAGE = v_Success AND V_IS_ADJUST = 'Y' THEN
           --删除原数据
           IF V_PG_PRODUCT_LINE = 'N' THEN
             BEGIN
               V_VALUE := '删除原行数据：';
               DELETE FROM T_PG_BUSINESS_LINE TL
                WHERE TL.ITEM_CODE NOT IN
                      (SELECT IL.ITEM_CODE
                         FROM INTF_PG_BUSINESS_LINE IL
                        WHERE IL.HEAD_ID = P_INTF_HEAD_ID)
                  AND TL.BUSINESS_ID = V_ORI_BUSINESS_ID;
              EXCEPTION
                  WHEN OTHERS THEN
                     P_MESSAGE := V_VALUE || '失败。' || v_Nl || SQLERRM;
              END;
            ELSIF V_PG_PRODUCT_LINE = 'Y' THEN
              BEGIN
                V_VALUE := '删除原行数据：';
                DELETE FROM T_PG_BUSINESS_APPROVAL BA
                 WHERE BA.PRODUCTLINE_CODE NOT IN
                       (SELECT IA.PRODUCTLINE_CODE
                          FROM INTF_PG_BUSINESS_APPROVAL IA
                         WHERE IA.INTF_HEAD_ID = P_INTF_HEAD_ID)
                   AND BA.BUSINESS_ID = V_ORI_BUSINESS_ID;
              EXCEPTION
                WHEN OTHERS THEN
                  P_MESSAGE := V_VALUE || '失败。' || v_Nl || SQLERRM;
              END;
            END IF;
         END IF;
         
         IF P_MESSAGE = v_Success  THEN
           IF V_PG_PRODUCT_LINE = 'N'THEN
            OPEN C_INTF_PG_BUSINESS_LINE;
             LOOP 
               FETCH C_INTF_PG_BUSINESS_LINE
               INTO R_INTF_PG_BUSINESS_LINE;
               EXIT WHEN C_INTF_PG_BUSINESS_LINE%NOTFOUND OR P_MESSAGE <> v_Success;
              
             
              
              BEGIN
                V_VALUE := '查询产品营销大类、小类编码：';
                SELECT TI.SALES_MAIN_TYPE, TI.SALES_SUB_TYPE
                  INTO V_SALES_MAIN_TYPE_CODE, V_SALES_SUB_TYPE_CODE
                  FROM T_BD_ITEM TI
                 WHERE TI.ITEM_CODE = R_INTF_PG_BUSINESS_LINE.ITEM_CODE
                   AND TI.ENTITY_ID = R_INTF_PG_BUSINESS_HEAD.ENTITY_ID;
                EXCEPTION
                   WHEN OTHERS THEN
                     P_MESSAGE := V_VALUE ||
                                  R_INTF_PG_BUSINESS_LINE.ITEM_CODE ||
                                  '失败。' || v_Nl || SQLERRM;
              END;
              
              BEGIN
                V_VALUE := '查询产品营销大类名称：';
                SELECT TC.CLASS_NAME,TC.ITEM_CLASS_ID
                  INTO V_SALES_MAIN_TYPE_NAME,V_SALES_MAIN_TYPE_ID
                  FROM T_BD_ITEM_CLASS TC
                 WHERE TC.CLASS_CODE = V_SALES_MAIN_TYPE_CODE
                   AND TC.ENTITY_ID = R_INTF_PG_BUSINESS_HEAD.ENTITY_ID
                   AND TC.ACTIVE_FLAG = 'Y';
              EXCEPTION
                WHEN OTHERS THEN
                  P_MESSAGE := V_VALUE || R_INTF_PG_BUSINESS_LINE.ITEM_CODE ||
                               '失败。' || v_Nl || SQLERRM;
              END;
              
              BEGIN
                V_VALUE := '查询产品营销小类名称：';
                SELECT TC.CLASS_NAME
                  INTO V_SALES_SUB_TYPE_NAME
                  FROM T_BD_ITEM_CLASS TC
                 WHERE TC.CLASS_CODE = V_SALES_SUB_TYPE_CODE
                   AND TC.ENTITY_ID = R_INTF_PG_BUSINESS_HEAD.ENTITY_ID
                   AND TC.PARENTC_LASS_ID = V_SALES_MAIN_TYPE_ID
                   AND TC.ACTIVE_FLAG = 'Y';
              EXCEPTION
                WHEN OTHERS THEN
                  P_MESSAGE := V_VALUE || R_INTF_PG_BUSINESS_LINE.ITEM_CODE ||
                               '失败。' || v_Nl || SQLERRM;
              END;
              --检查直供价
              IF R_INTF_PG_BUSINESS_HEAD.Is_Open='Y' AND R_INTF_PG_BUSINESS_LINE.Common_Price ='' THEN
                 P_MESSAGE :=  R_INTF_PG_BUSINESS_LINE.ITEM_CODE ||'已开户直供价不能为空';                 
              END IF;
               --校验行数据
              BEGIN
                V_VALUE := '校验产品信息：';
                SELECT TI.ITEM_ID, TI.ITEM_NAME, TI.DEFAULTUNIT
                     INTO V_ITEM_ID, V_ITEM_NAME, V_UOM_CODE
                     FROM T_BD_ITEM TI
                    WHERE TI.ENTITY_ID = R_INTF_PG_BUSINESS_HEAD.ENTITY_ID
                      AND TI.SALES_MAIN_TYPE =
                          V_SALES_MAIN_TYPE_CODE
                      AND TI.ACTIVE_FLAG = 'Y'
                      AND TI.ITEM_CODE = R_INTF_PG_BUSINESS_LINE.ITEM_CODE;
                 EXCEPTION
                   WHEN OTHERS THEN
                     P_MESSAGE := V_VALUE ||
                                  R_INTF_PG_BUSINESS_LINE.ITEM_CODE ||
                                  '失败。' || v_Nl || SQLERRM;
              END;
              
              IF V_IS_ADJUST = 'Y' AND P_MESSAGE = v_Success THEN
                --执行更新并返回受影响行数
                BEGIN
                  V_VALUE := '更新行表数据：';
                  UPDATE T_PG_BUSINESS_LINE TL SET 
                         TL.SALES_MAIN_TYPE = V_SALES_MAIN_TYPE_CODE,
                         TL.SALES_MAIN_TYPE_NAME = V_SALES_MAIN_TYPE_NAME,
                         TL.SALES_SUB_TYPE = V_SALES_SUB_TYPE_CODE,
                         TL.SALES_SUB_TYPE_NAME = V_SALES_SUB_TYPE_NAME,
                         TL.COMMON_PRICE = R_INTF_PG_BUSINESS_LINE.COMMON_PRICE,
                         TL.REQUIS_PRICE = R_INTF_PG_BUSINESS_LINE.REQUIS_PRICE,
                         TL.REQUIS_QTY = R_INTF_PG_BUSINESS_LINE.REQUIS_QTY,
                         TL.LAST_UPDATED_BY = 'CCS',
                         TL.LAST_UPDATE_DATE = SYSDATE
                   WHERE TL.ITEM_CODE = R_INTF_PG_BUSINESS_LINE.ITEM_CODE
                     AND TL.BUSINESS_ID = V_ORI_BUSINESS_ID;
                   
                   V_TMP_COUNT := SQL%ROWCOUNT;
                   
                   EXCEPTION
                     WHEN OTHERS THEN
                       P_MESSAGE := V_VALUE || '失败。' || v_Nl || SQLERRM;
                   END;
                END IF;
              
              IF V_TMP_COUNT = 0 AND P_MESSAGE = v_Success THEN
                BEGIN
                  V_VALUE := '插入行表数据：';
                
                  ---序列
                  SELECT S_PG_BUSINESS_LINE.NEXTVAL
                    INTO V_BUSINESS_LINE_ID
                    FROM DUAL;
                
                  Insert Into T_PG_BUSINESS_LINE
                    (bussiness_line_id, --商机商品行信息ID
                     business_id, --商机信息ID
                     sales_main_type, --营销大类编码
                     sales_main_type_name, --营销大类名称
                     sales_sub_type, --营销小类编码
                     sales_sub_type_name, --营销小类名称
                     item_id, --产品ID
                     item_code, --产品编码
                     item_desc, --产品型号
                     uom_code, --单位
                     common_price, --直供价
                     requis_price, --预计报价
                     requis_qty, --申请数量
                     created_by, --创建人
                     creation_date, --创建时间
                     last_updated_by, --修改人
                     last_update_date, --修改时间
                     entity_id --主体ID
                     )
                  Values
                    (V_BUSINESS_LINE_ID, --商机商品行信息ID
                     V_BUSINESS_ID, --商机信息ID
                     V_SALES_MAIN_TYPE_CODE, --营销大类编码
                     V_SALES_MAIN_TYPE_NAME, --营销大类名称
                     V_SALES_SUB_TYPE_CODE, --营销小类编码
                     V_SALES_SUB_TYPE_NAME, --营销小类名称
                     V_ITEM_ID, --产品ID
                     R_INTF_PG_BUSINESS_LINE.ITEM_CODE, --产品编码
                     V_ITEM_NAME, --产品型号
                     V_UOM_CODE, --单位
                     R_INTF_PG_BUSINESS_LINE.COMMON_PRICE, --直供价
                     R_INTF_PG_BUSINESS_LINE.REQUIS_PRICE, --预计报价
                     R_INTF_PG_BUSINESS_LINE.REQUIS_QTY, --申请数量
                     'CCS', --创建人
                     sysdate,--to_date(sysdate,'yyyy-MM-dd HH24:mi:ss'), --创建时间
                     'CCS', --修改人
                     sysdate,--to_date(sysdate,'yyyy-MM-dd HH24:mi:ss'), --修改时间
                     R_INTF_PG_BUSINESS_HEAD.ENTITY_ID --主体ID
                     );

                EXCEPTION
                  WHEN OTHERS THEN
                    P_MESSAGE := V_VALUE || '失败。' || v_Nl || SQLERRM;
                END;
                END IF;
              END LOOP;
            ELSIF V_PG_PRODUCT_LINE = 'Y'THEN
              OPEN C_INTF_PG_BUSINESS_APPROVAL;
             LOOP 
               FETCH C_INTF_PG_BUSINESS_APPROVAL
               INTO R_INTF_PG_BUSINESS_APPROVAL;
               EXIT WHEN C_INTF_PG_BUSINESS_APPROVAL%NOTFOUND OR P_MESSAGE <> v_Success;
              
              --校验行数据
              BEGIN
                V_VALUE := '校验产品线信息：';
                SELECT TPL.PRODUCTLINE_ID, TPL.PRODUCTLINE_NAME
                  INTO V_PRODUCT_LINE_ID, V_PRODUCT_LINE_NAME
                  FROM T_PG_PRODUCT_LINE TPL
                 WHERE TPL.PRODUCTLINE_CODE =
                       R_INTF_PG_BUSINESS_APPROVAL.PRODUCTLINE_CODE
                   AND TPL.ENTITY_ID =
                       R_INTF_PG_BUSINESS_APPROVAL.ENTITY_ID;
              EXCEPTION
                WHEN OTHERS THEN
                   P_MESSAGE := V_VALUE || '失败。' || v_Nl || SQLERRM;
              END;
              
              IF V_IS_ADJUST = 'Y'AND P_MESSAGE = v_Success THEN
                --更新行数据并返回受影响行数
                BEGIN
                  V_VALUE := '更新行数据：';
                  UPDATE T_PG_BUSINESS_APPROVAL TA SET
                         TA.LAST_UPDATED_BY = 'CCS',
                         TA.LAST_UPDATE_DATE = SYSDATE
                  WHERE TA.PRODUCTLINE_CODE = R_INTF_PG_BUSINESS_APPROVAL.PRODUCTLINE_CODE
                    AND TA.BUSINESS_ID = V_ORI_BUSINESS_ID;
                  
                  V_TMP_COUNT := SQL%ROWCOUNT;
                  
                  EXCEPTION
                    WHEN OTHERS THEN
                      P_MESSAGE := V_VALUE || '失败。' || v_Nl || SQLERRM;
                  END;
               END IF;
               
              IF V_TMP_COUNT = 0 AND P_MESSAGE = v_Success THEN
                BEGIN
                  V_VALUE := '开始插入行表数据：';
                
                  ---序列
                  SELECT S_PG_BUSINESS_APPROVAL.NEXTVAL
                    INTO V_BUSINESS_LINE_ID
                    FROM DUAL;
                
                  Insert Into T_Pg_Business_Approval
                  (business_audit_id,                      --产品线登录行ID
                   business_id,                            --商机信息ID
                   productline_id,                         --产品线ID
                   productline_code,                       --产品线编码
                   productline_name,                       --产品线名称
                   creation_date,                          --创建时间
                   last_update_date,                       --修改时间
                   entity_id,                              --主体ID
                   created_by,
                   last_updated_by
                  )
                  Values
                  (V_BUSINESS_LINE_ID, --商机商品行信息ID
                   V_BUSINESS_ID, --商机信息ID
                   V_PRODUCT_LINE_ID, --产品线ID
                   R_INTF_PG_BUSINESS_APPROVAL.PRODUCTLINE_CODE,--产品线编码
                   V_PRODUCT_LINE_NAME,  --产品线名称
                   sysdate,--to_date(sysdate,'yyyy-MM-dd HH24:mi:ss'),--创建时间
                   sysdate,--to_date(sysdate,'yyyy-MM-dd HH24:mi:ss'),--修改时间
                   R_INTF_PG_BUSINESS_HEAD.ENTITY_ID,--主体ID
                   'CCS',
                   'CCS'
                  );
                EXCEPTION
                  WHEN OTHERS THEN
                    P_MESSAGE := V_VALUE || '失败。' || v_Nl || SQLERRM;
                END;
              END IF;
              END LOOP; 
            END IF;
          END IF; 
         
        <<err_here>>
         ----更新状态
        IF P_MESSAGE <> v_Success THEN
          --回滚事务
          ROLLBACK TO SAVEPOINT P_PG_BUSINESS_CCS;
          UPDATE INTF_PG_BUSINESS B
             SET B.INTF_STATUS  = 'E',
                 B.INTF_ERR_MSG  = P_MESSAGE,
                 B.BUSINESS_ID  = V_BUSINESS_ID,
                 B.PROJECT_CODE = V_PROJECT_CODE
           WHERE B.HEAD_ID = P_INTF_HEAD_ID;
        ELSE
           UPDATE INTF_PG_BUSINESS B
             SET B.INTF_STATUS  = 'S',
                 B.INTF_ERR_MSG  = P_MESSAGE,
                 B.BUSINESS_ID  = V_BUSINESS_ID,
                 B.PROJECT_CODE = V_PROJECT_CODE
           WHERE B.HEAD_ID = P_INTF_HEAD_ID;
        End IF;      
    END; 
    
  ----------------------------------------------------------------------
  -- Author  : WANGCONG
  -- Created : 2017/04/17
  -- Purpose : CCS撤回校验
  ----------------------------------------------------------------------
    Procedure P_PG_BUSINESS_REVOKE_VERIFY(P_BUSINESS_CODE IN VARCHAR2,P_ENTITY_ID IN NUMBER,P_MESSAGE OUT VARCHAR2) IS
      V_VALUE           VARCHAR2(1024);
      V_STATUS_NAME     VARCHAR2(32);
      
      V_BUSINESS_STATUS T_PG_BUSINESS.STATUS%TYPE;
      V_BUSINESS_CODE   T_PG_BUSINESS.PROJECT_CODE%TYPE;
      
      BEGIN
        P_MESSAGE := v_Success;
      
        BEGIN
          V_VALUE := '校验项目：';
          SELECT TB.PROJECT_CODE, TB.STATUS
            INTO V_BUSINESS_CODE, V_BUSINESS_STATUS
            FROM T_PG_BUSINESS TB
           WHERE TB.PROJECT_CODE = P_BUSINESS_CODE
             AND TB.ENTITY_ID = P_ENTITY_ID;
        EXCEPTION
          WHEN OTHERS THEN
            P_MESSAGE := V_VALUE || P_BUSINESS_CODE || '失败，项目不存在。' || v_Nl ||
                         SQLERRM;
        END;
       
       IF P_MESSAGE = v_Success THEN 
           BEGIN
             V_VALUE := '校验项目状态：';
             IF P_MESSAGE = v_Success AND V_BUSINESS_STATUS <> '0' THEN
               SELECT CL.CODE_NAME
                 INTO V_STATUS_NAME
                 FROM V_UP_CODELIST CL
                WHERE CL.CODE_VALUE = V_BUSINESS_STATUS
                 -- AND CL.ENTITY_ID = P_ENTITY_ID
                  AND CL.CODETYPE = 'tpgBusinessStatus';
               RAISE V_CCS_EXCEPTION;
             END IF;
           EXCEPTION
             WHEN V_CCS_EXCEPTION THEN
               P_MESSAGE := V_VALUE || '状态为，' || V_STATUS_NAME || '不允许撤回。' || v_Nl ||
                            SQLERRM;
           END;
       END IF;
       
       IF P_MESSAGE = v_Success THEN
         BEGIN
           V_VALUE := '更新单据状态：';
           --更新单据状态
           UPDATE T_PG_BUSINESS TB
              SET TB.STATUS = '5',
                  TB.RETRACT_PERSON = 'CCS',
                  TB.RETRACT_DATE = SYSDATE,
                  TB.LAST_UPDATED_BY = 'CCS',
                  TB.LAST_UPDATE_DATE = SYSDATE
            WHERE TB.PROJECT_CODE = P_BUSINESS_CODE
              AND TB.ENTITY_ID = P_ENTITY_ID; 
         EXCEPTION
           WHEN OTHERS THEN
             P_MESSAGE := V_VALUE || '失败。' || V_STATUS_NAME || '不允许撤回。' || v_Nl ||
                          SQLERRM;
         END;
       END IF; 
     END;
     
     ----------------------------------------------------------------------
     -- Author  : WANGCONG
     -- Created : 2017/04/24
     -- Purpose : 价格申报CCS撤回校验
     ----------------------------------------------------------------------	
     Procedure P_PG_PRICE_APPLY_REVOKE_VERIFY(P_APPLY_CODE IN VARCHAR2,P_ENTITY_ID IN NUMBER,P_MESSAGE OUT VARCHAR2) IS
        V_VALUE           VARCHAR2(1024);
        V_STATUS_NAME     VARCHAR2(32);
        
        V_PRICE_APPLY_STATUS	    T_PG_PRICE_APPLY_HEAD.STATUS%TYPE;
        
        BEGIN
          V_VALUE := v_Success;
          P_MESSAGE := v_Success;
          BEGIN
            V_VALUE := '价格申报校验：';
            SELECT TA.STATUS
            INTO V_PRICE_APPLY_STATUS
            FROM T_PG_PRICE_APPLY_HEAD TA
            WHERE TA.APPLY_CODE = P_APPLY_CODE
              AND TA.ENTITY_ID = P_ENTITY_ID;
          EXCEPTION
            WHEN OTHERS THEN
              P_MESSAGE := V_VALUE || '失败，' || P_APPLY_CODE || ' 申报不存在。' || v_Nl || SQLERRM;
           END;
           
           IF P_MESSAGE = v_Success THEN
               BEGIN
                 V_VALUE := '校验价格申报状态：';
                 IF P_MESSAGE = v_Success AND V_PRICE_APPLY_STATUS <> '0' THEN
                    SELECT CL.CODE_NAME
                      INTO V_STATUS_NAME
                      FROM V_UP_CODELIST CL
                     WHERE CL.CODE_VALUE = V_PRICE_APPLY_STATUS
                       --AND CL.ENTITY_ID = P_ENTITY_ID
                       AND CL.CODETYPE = 'tpgBusinessStatus';
                       RAISE V_CCS_EXCEPTION;
                  END IF;
                 EXCEPTION
                     WHEN V_CCS_EXCEPTION THEN
                          P_MESSAGE := V_VALUE || '状态为，' || V_STATUS_NAME || '不允许撤回。' || v_Nl ||
                                          SQLERRM;
                 END;
             END IF;
             
             IF P_MESSAGE = v_Success THEN
               BEGIN
                 V_VALUE := '更新价格申报状态：';
                 UPDATE T_PG_PRICE_APPLY_HEAD H
                    SET H.STATUS = '5',
                        H.RETRACT_PERSON = 'CCS',
                        H.RETRACT_DATE = SYSDATE,
                        H.LAST_UPDATED_BY = 'CCS',
                        H.LAST_UPDATE_DATE = SYSDATE
                  WHERE H.APPLY_CODE = P_APPLY_CODE
                    AND H.ENTITY_ID = P_ENTITY_ID;
                EXCEPTION
                  WHEN OTHERS THEN
                    P_MESSAGE := V_VALUE || '失败。' || v_Nl || SQLERRM;
                END;
              END IF;
     END;
     
    ----------------------------------------------------------------------
    -- Author  : WANGCONG
    -- Created : 2017/04/28
    -- Purpose : 价格申报CCS驳回
    ----------------------------------------------------------------------
    Procedure P_PG_PROJECT_REJECT_VERIFY(P_PROJECT_ID IN NUMBER,P_REJECT_REASON IN VARCHAR2,P_MESSAGE OUT VARCHAR2) IS
      V_VALUE                VARCHAR2(1024);
      V_CCS_MESSAGE          VARCHAR2(1024);
      BEGIN
        V_VALUE := '调用CCS驳回校验：';
        --PRO_CCS_CIMS_BUSINESS_REJECT@MDIMS2GCCS(P_PROJECT_ID,P_REJECT_REASON,V_CCS_MESSAGE);
        CCS_PG_REJECT_PKG.PRO_CCS_CIMS_BUSINESS_REJECT(P_PROJECT_ID,P_REJECT_REASON,V_CCS_MESSAGE);
        IF V_CCS_MESSAGE IS NOT NULL THEN
          P_MESSAGE := V_CCS_MESSAGE;
        END IF;
      EXCEPTION
        WHEN OTHERS THEN
          P_MESSAGE := 'CCS提示：' || V_CCS_MESSAGE || v_Nl || SQLERRM;
      END;
      
    ----------------------------------------------------------------------
    -- Author  : WANGCONG
    -- Created : 2017/04/28
    -- Purpose : 价格申报CCS驳回
    ----------------------------------------------------------------------
    Procedure P_PG_PRICE_APPLY_REJECT_VERIFY(P_INTF_ID IN NUMBER,P_REJECT_REASON IN VARCHAR2,P_MESSAGE OUT VARCHAR2) IS
      V_VALUE         VARCHAR2(1024);
      V_CCS_MESSAGE   VARCHAR2(1024);
      BEGIN
        V_VALUE := '调用CCS驳回校验：';
        CCS_PG_REJECT_PKG.PRO_CCS_CIMS_PRICE_REJECT(P_INTF_ID,P_REJECT_REASON,V_CCS_MESSAGE);
        IF V_CCS_MESSAGE IS NOT NULL THEN
          P_MESSAGE := V_CCS_MESSAGE;
        END IF;
      EXCEPTION
        WHEN OTHERS THEN
          P_MESSAGE := 'CCS提示：' || V_CCS_MESSAGE || v_Nl || SQLERRM;
      END;
    
     ----------------------------------------------------------------------
     -- Author  : WANGCONG
     -- Created : 2017/05/17
     -- Purpose : 团购项目CCS驳回
     ----------------------------------------------------------------------
     Procedure P_PG_GROUP_BUSINESS_REJECT(P_PROJECT_ID IN NUMBER,P_REJECT_REASON IN VARCHAR2,P_MESSAGE OUT VARCHAR2) IS
       V_VALUE         VARCHAR2(1024);
       V_CCS_MESSAGE   VARCHAR2(1024);
       BEGIN
         V_VALUE := '调用CCS驳回校验：';
         CCS_PG_REJECT_PKG.PRO_CCS_CIMS_CONTRACT_REJECT(P_PROJECT_ID,P_REJECT_REASON,V_CCS_MESSAGE);
         IF V_CCS_MESSAGE IS NOT NULL THEN
           P_MESSAGE := V_CCS_MESSAGE;
         END IF;
       EXCEPTION
         WHEN OTHERS THEN
           P_MESSAGE := 'CCS提示：' || V_CCS_MESSAGE || v_Nl || SQLERRM;
      END;
      
    ----------------------------------------------------------------------
    -- Author  : WANGCONG
    -- Created : 2017/05/17
    -- Purpose : 团购申报CCS驳回
    ----------------------------------------------------------------------
    Procedure P_PG_GROUP_PRICE_REJECT(P_PRICE_ID IN NUMBER,P_REJECT_REASON 
      IN VARCHAR2,P_MESSAGE OUT VARCHAR2) IS
      V_VALUE         VARCHAR2(1024);
       V_CCS_MESSAGE   VARCHAR2(1024);
       BEGIN
         V_VALUE := '调用CCS驳回校验：';
         CCS_PG_REJECT_PKG.PRO_CCS_CIMS_CONTRACT_P_REJECT(P_PRICE_ID,P_REJECT_REASON,V_CCS_MESSAGE);
         IF V_CCS_MESSAGE IS NOT NULL THEN
           P_MESSAGE := V_CCS_MESSAGE;
         END IF;
       EXCEPTION
         WHEN OTHERS THEN
           P_MESSAGE := 'CCS提示：' || V_CCS_MESSAGE || v_Nl || SQLERRM;
      END;
      
  ----------------------------------------------------------------------
  -- Author  : WANGCONG
  -- Created : 2017/11/01
  -- Purpose : 销司商机引入总部
  ----------------------------------------------------------------------
  Procedure P_PG_SC_BUSINESS_SYNC(P_BUSINESS_ID IN NUMBER,P_ENTITY_ID IN NUMBER,P_MESSAGE OUT VARCHAR2) IS
      V_VALUE           VARCHAR2(1024);
    
      V_HQ_CENTER_ID    T_PG_BUSINESS.SALES_CENTER_ID%TYPE;
      V_HQ_CENTER_CODE  T_PG_BUSINESS.SALES_CENTER_CODE%TYPE;
      V_HQ_CENTER_NAME  T_PG_BUSINESS.SALES_CENTER_NAME%TYPE;
      V_HQ_PROJECT_CENTER_ID     T_PG_BUSINESS.PROJECT_CENTER_ID%TYPE;
      V_HQ_PROJECT_CENTER_CODE   T_PG_BUSINESS.PROJECT_CENTER_CODE%TYPE;
      V_HQ_PROJECT_CENTER_NAME   T_PG_BUSINESS.PROJECT_CENTER_NAME%TYPE;
      V_PROJECT_CODE    T_PG_BUSINESS.PROJECT_CODE%TYPE;
      V_LOC_ID          T_PG_BUSINESS.LOC_ID%TYPE;
      V_LOC_NAME        T_PG_BUSINESS.LOC_NAME%TYPE;
      V_LOC_CODE        T_PG_BUSINESS.LOC_CODE%TYPE;
      
      V_IF_PRODUCT_LINE  VARCHAR2(10);
      V_RECORD_NUM       NUMBER;
      V_GROUP_MARK       VARCHAR2(10);   
      V_BUSINESS_ID      NUMBER;
      V_BUSINESS_LINE_ID NUMBER;
      V_ACRONYM          VARCHAR2(10);
      V_ACRONYM_STR      VARCHAR2(32);
      
      V_ITEM_ID          T_PG_BUSINESS_LINE.ITEM_ID%TYPE;
      V_ITEM_CODE        T_PG_BUSINESS_LINE.ITEM_CODE%TYPE;
      V_ITEM_NAME        T_PG_BUSINESS_LINE.ITEM_DESC%TYPE;
      V_UOM_CODE         T_PG_BUSINESS_LINE.UOM_CODE%TYPE;
      V_SALES_MAIN_TYPE_CODE  T_PG_BUSINESS_LINE.SALES_MAIN_TYPE%TYPE;
      V_SALES_MAIN_TYPE_NAME  T_PG_BUSINESS_LINE.SALES_MAIN_TYPE_NAME%TYPE;
      V_SALES_SUB_TYPE_CODE   T_PG_BUSINESS_LINE.SALES_SUB_TYPE%TYPE;
      V_SALES_SUB_TYPE_NAME   T_PG_BUSINESS_LINE.SALES_SUB_TYPE_NAME%TYPE;
      V_PRODUCT_LINE_ID       T_PG_BUSINESS_APPROVAL.PRODUCTLINE_ID%TYPE;
      V_PRODUCT_LINE_NAME     T_PG_BUSINESS_APPROVAL.PRODUCTLINE_NAME%TYPE;
      
      R_PG_SC_BUSINESS_VIEW  V_PG_SC_BUSINESS_INFO%ROWTYPE;
      R_PG_SC_BUSINESS_INFO  T_PG_BUSINESS%ROWTYPE;
      
      CURSOR C_PG_SC_BUSINESS_LINE IS
          SELECT * FROM T_PG_BUSINESS_LINE L WHERE L.BUSINESS_ID = P_BUSINESS_ID;
      R_PG_SC_BUSINESS_LINE C_PG_SC_BUSINESS_LINE%ROWTYPE;
      
      CURSOR C_PG_SC_BUSINESS_PRODUCT_LINE IS
          SELECT * FROM T_PG_BUSINESS_APPROVAL A  WHERE A.BUSINESS_ID = P_BUSINESS_ID;
      R_PG_SC_BUSINESS_PRODUCT_LINE C_PG_SC_BUSINESS_PRODUCT_LINE%ROWTYPE;
      
                                   
    BEGIN
      P_MESSAGE := v_Success;
      BEGIN
        V_VALUE := '锁定销司商机：';
        SELECT *
          INTO R_PG_SC_BUSINESS_INFO
          FROM T_PG_BUSINESS B
         WHERE B.BUSINESS_ID = P_BUSINESS_ID
           AND B.SUB_BUSINESS_CODE IS NULL
           FOR UPDATE NOWAIT;
        EXCEPTION
          WHEN OTHERS THEN
            P_MESSAGE := V_VALUE || '失败，商机不存在或已引入。'|| v_Nl ||SQLERRM;
      END;
      
      IF P_MESSAGE = v_Success THEN
        BEGIN
          V_VALUE := '查询销司商机对应的总部中心：';
          SELECT *
            INTO R_PG_SC_BUSINESS_VIEW
            FROM V_PG_SC_BUSINESS_INFO V
           WHERE V.business_id = P_BUSINESS_ID
             AND V.hq_entity_id = P_ENTITY_ID;
           
           V_HQ_CENTER_ID := R_PG_SC_BUSINESS_VIEW.HQ_SALES_CENTER_ID;
           V_HQ_CENTER_CODE := R_PG_SC_BUSINESS_VIEW.HQ_SALES_CENTER_CODE;
           V_HQ_CENTER_NAME := R_PG_SC_BUSINESS_VIEW.HQ_SALES_CENTER_NAME;
           V_HQ_PROJECT_CENTER_ID := R_PG_SC_BUSINESS_VIEW.hq_project_sales_center_id;
           V_HQ_PROJECT_CENTER_CODE := R_PG_SC_BUSINESS_VIEW.hq_project_sales_center_code;
           V_HQ_PROJECT_CENTER_NAME := R_PG_SC_BUSINESS_VIEW.hq_project_sales_center_name;
         EXCEPTION
           WHEN OTHERS THEN
             P_MESSAGE := V_VALUE || '失败。' || v_Nl || SQLERRM;
         END;
      END IF;
      
      IF P_MESSAGE = v_Success THEN
        BEGIN
          V_VALUE := '项目所在区域检查：';
          SELECT T.ROW_ID, T.DISTRICT_CODE, T.DISTRICT_NAME
            INTO V_LOC_ID, V_LOC_CODE, V_LOC_NAME
            FROM T_BD_DISTRICT T
           WHERE T.DISTRICT_CODE = R_PG_SC_BUSINESS_INFO.LOC_CODE
             AND T.ACTIVE_FLAG = 'Y';
        EXCEPTION
          WHEN OTHERS THEN
            P_MESSAGE := V_VALUE || '出错，区域编码'|| R_PG_SC_BUSINESS_INFO.LOC_CODE || '对应的总部区域不存在。' || v_Nl ||SQLERRM;
        END;
      END IF;
      
      IF P_MESSAGE = v_Success THEN
        BEGIN
          V_VALUE := '查询是否产品线登录：';
          PKG_BD.P_GET_PARAMETER_VALUE('PG_PRODUCT_LINE',
                                       P_ENTITY_ID,
                                       Null,
                                       Null,
                                       V_IF_PRODUCT_LINE);
        EXCEPTION
          WHEN OTHERS THEN
            P_MESSAGE := V_VALUE || '出错。' || v_Nl || SQLERRM;
        END;
        
         --取团购标识
         BEGIN
           V_VALUE := '查询团购标识：';
           PKG_BD.P_GET_PARAMETER_VALUE('PG_GROUP_BUY_MARK',
                                        P_ENTITY_ID,
                                         Null,
                                         Null,
                                         V_GROUP_MARK);
         EXCEPTION
           WHEN OTHERS THEN
             P_MESSAGE := V_VALUE || '出错。' || v_Nl || SQLERRM;
         END;
         
         IF P_MESSAGE = v_Success THEN
             SELECT S_PG_BUSINESS.NEXTVAL INTO V_BUSINESS_ID FROM DUAL;
             --营销中心简称
             SELECT T.EXT_TEXTBOX
               INTO V_ACRONYM
               FROM UP_ORG_UNIT_EXT T
              WHERE T.ID IN
                    (SELECT U.ID
                       FROM UP_ORG_UNIT U
                      WHERE U.CODE = V_HQ_CENTER_CODE);
             IF V_GROUP_MARK = 'Y' AND
                R_PG_SC_BUSINESS_INFO.IS_GROUPBUY = '1' THEN
               --生成团购登陆编码
               V_ACRONYM_STR := 'TG' || V_ACRONYM || '录';
               BEGIN
                 V_VALUE := '生成团购登陆编码：';
                 PKG_BD.P_GET_BILL_NO('TG_PROJECT_CODE',
                                      V_ACRONYM_STR,
                                      P_ENTITY_ID,
                                      Null,
                                      V_PROJECT_CODE);
               EXCEPTION
                 WHEN OTHERS THEN
                   P_MESSAGE := V_VALUE || '出错。' || v_Nl || SQLERRM;
               END;
             ELSE
               V_ACRONYM_STR := 'S' || V_ACRONYM || '录' ||
                                P_ENTITY_ID;
               BEGIN
                 V_VALUE := '生成商机编码：';
                 PKG_BD.P_GET_BILL_NO('tpgProjectCode',
                                      V_ACRONYM_STR,
                                      P_ENTITY_ID,
                                      Null,
                                      V_PROJECT_CODE);
               EXCEPTION
                 WHEN OTHERS THEN
                   P_MESSAGE := V_VALUE || '出错。' || v_Nl || SQLERRM;
               END;
             END IF;
             
             IF P_MESSAGE = v_Success THEN
               BEGIN
                V_VALUE := '插入商机头表';
                INSERT INTO T_PG_BUSINESS
                  (business_id, --商机信息ID
                   project_code, --项目编号
                   project_name, --项目名称
                   user_firm, --使用单位名称
                   user_phone, --项目方联系电话
                   user_name, --项目方联系人
                   project_address, --工程项目详细地址
                   loc_id, --区域ID
                   loc_code, --项目所在区域
                   loc_name, --区域编码名称
                   project_center_id, --项目所在中心ID
                   project_center_code, --项目所在中心编码
                   project_center_name, --项目所在中心名称
                   customer_id, --经销商ID
                   customer_code, --经销商编码
                   customer_name, --经销商名称
                   sales_center_id, --营销中心ID
                   sales_center_name, --营销中心名称
                   sales_center_code, --营销中心编码
                   --account_id, --账户ID
                   --account_code,          --账户名称
                   agent_id, --经销商ID
                   agent_code, --经销商编码
                   agent_name, --经销商名称
                   project_type, --工程类型:精装房产配套、公租保障配套、家装橱柜配套、燃气公司合作
                   expected_bid_time, --预计投标时间
                   login_time, --登录日期
                   login_ptotect_time, --登录保护时间
                   project_num, --项目规模
                   project_progress, --项目进度:在建项目、建好未定、准备投标
                   business_type, --商机类型
                   delivery_cycle, --供货周期:单位为天
                   buyout_type, --买断类型:事前买断、时候买断
                   customer_person,       --经销商联系人
                   customer_person_phone, --联系方式
                   area_manager,          --区域经理
                   area_manager_phone,    --区域经理电话
                   install_flag, --是否我司安装
                   otherlogin_flag, --是否是异地登录
                   status, --登录状态，有以下几种：已录入、已送审、已审核、已退回、已作废
                   --  competitors,           --工程竞争对手
                   special_need, --特殊要求
                   other_desc, --其他说明资料
                   entity_id, --主体ID
                   created_by, --创建人
                   creation_date, --创建时间
                   last_updated_by, --修改人
                   last_update_date, --修改时间
                   --send_person,           --送审人
                   --send_date,             --送审日期
                   --approval_person,       --审核人
                   --approval_date,         --审核日期
                   --back_person,           --退回人
                   --back_date,             --退回日期
                   --scrapped_person,       --作废人
                   --scrapped_date,         --作废时间
                   --relogin_flag,          --重新登录标识
                   bid_status, --中标状态
                   --freeze_status,         --冻结状态
                   --freeze_person,         --冻结人
                   --freeze_time,           --冻结时间
                   --unfreeze_person,       --解冻人
                   --unfreeze_time,         --解冻时间
                   --is_market_strategy,    --战略大盘采购
                   --verfication_status,    --核销状态 0未核销 1已核销 2核销失败
                   --remark,                --备注
                   is_groupbuy,           --是否团购
                   --program_updated_by,    --程序修改来源
                   program_update_date, --修改时间
                   ori_business_id, --上级项目ID
                   ori_business_code, --上级项目编码
                   trade,--所属行业
                   brand,--品牌
                   category,--品类
                   customer_fax,--经销商传真电话
                   follow_man,--分部业务员
                   follower_telephone,--分部业务员电话
                   main_material,--涉及机型
                   query_keywords,--查询关键字
                   stat_keywords,--统计关键字
                   tg_commissioner,--团购专员
                   tg_commi_phone,--团购专员电话
                   refer_area_id,--安装涉及区域ID
                   refer_area,--安装涉及区域
                   deal_start_date,--登录开始日期
                   deal_end_date,--登录结束日期
                   group_buy_sales_main_type,--营销大类
                   source_system
                   ,big_panel
                   )
                Values
                  (V_BUSINESS_ID, --商机信息ID
                   V_PROJECT_CODE, --项目编号
                   R_PG_SC_BUSINESS_INFO.PROJECT_NAME, --项目名称
                   R_PG_SC_BUSINESS_INFO.USER_FIRM, --使用单位名称
                   R_PG_SC_BUSINESS_INFO.USER_PHONE, --项目方联系电话
                   R_PG_SC_BUSINESS_INFO.USER_NAME, --项目方联系人
                   R_PG_SC_BUSINESS_INFO.PROJECT_ADDRESS, --工程项目详细地址
                   V_LOC_ID, --区域ID
                   V_LOC_CODE, --项目所在区域
                   V_LOC_NAME, --区域编码名称
                   V_HQ_PROJECT_CENTER_ID, --项目所在中心ID
                   V_HQ_PROJECT_CENTER_CODE, --项目所在中心编码
                   V_HQ_PROJECT_CENTER_NAME, --项目所在中心名称
                   R_PG_SC_BUSINESS_INFO.CUSTOMER_ID,
                   R_PG_SC_BUSINESS_INFO.CUSTOMER_CODE,
                   R_PG_SC_BUSINESS_INFO.CUSTOMER_NAME,
                   V_HQ_CENTER_ID, --营销中心ID
                   V_HQ_CENTER_NAME, --营销中心名称
                   V_HQ_CENTER_CODE, --营销中心编码
                   --V_ACCOUNT_ID, --账户ID
                   --V_ACCOUNT_CODE,                      --账户名称
                   R_PG_SC_BUSINESS_INFO.AGENT_ID, --经销商ID
                   R_PG_SC_BUSINESS_INFO.AGENT_CODE, --经销商编码
                   R_PG_SC_BUSINESS_INFO.AGENT_NAME, --经销商名称
                   R_PG_SC_BUSINESS_INFO.PROJECT_TYPE,
                   R_PG_SC_BUSINESS_INFO.EXPECTED_BID_TIME, --v_Expected_Bid_Time,--预计投标时间
                   R_PG_SC_BUSINESS_INFO.LOGIN_TIME,--trunc(sysdate),
                   --to_date(sysdate,'yyyy-MM-dd HH24:mi:ss'), --登录日期
                   R_PG_SC_BUSINESS_INFO.LOGIN_PTOTECT_TIME,--add_months(sysdate - 1, 3), --登录保护时间
                   R_PG_SC_BUSINESS_INFO.PROJECT_NUM, --项目规模
                   R_PG_SC_BUSINESS_INFO.PROJECT_PROGRESS, --项目进度:在建项目、建好未定、准备投标
                   R_PG_SC_BUSINESS_INFO.BUSINESS_TYPE, --存在问题，先置为0
                   R_PG_SC_BUSINESS_INFO.DELIVERY_CYCLE, --供货周期:单位为天
                   R_PG_SC_BUSINESS_INFO.BUYOUT_TYPE, --买断类型:事前买断、时候买断
                   R_PG_SC_BUSINESS_INFO.CUSTOMER_PERSON,           --经销商联系人
                   R_PG_SC_BUSINESS_INFO.CUSTOMER_PERSON_PHONE,     --联系方式
                   R_PG_SC_BUSINESS_INFO.AREA_MANAGER,            --区域经理
                   R_PG_SC_BUSINESS_INFO.AREA_MANAGER_PHONE,    --区域经理电话
                   R_PG_SC_BUSINESS_INFO.INSTALL_FLAG, --是否我司安装
                   R_PG_SC_BUSINESS_INFO.OTHERLOGIN_FLAG, --是否是异地登录
                   '2', --登录状态:已审核
                   --R_PG_SC_BUSINESS_INFO.MAIN_MATERIAL,         --工程竞争对手
                   R_PG_SC_BUSINESS_INFO.SPECIAL_NEED, --特殊要求
                   R_PG_SC_BUSINESS_INFO.OTHER_DESC, --其他说明资料
                   P_ENTITY_ID, --主体ID
                   'CIMS销司', --创建人
                   sysdate,
                   --to_date(sysdate,'yyyy-MM-dd HH24:mi:ss'), --创建时间
                   R_PG_SC_BUSINESS_INFO.LAST_UPDATED_BY, --修改人
                   R_PG_SC_BUSINESS_INFO.LAST_UPDATE_DATE, --修改时间
                   -- r_Pg_Business.To_Checkup_By_Name,    --送审人
                   -- r_Pg_Business.To_Checkup_Date,       --送审日期
                   -- r_Pg_Business.Checkup_By_Name,       --审核人
                   -- r_Pg_Business.Checkup_Date,          --审核日期
                   -- r_Pg_Business.Back_By_Name,          --退回人
                   -- r_Pg_Business.Back_Date,             --退回日期
                   --- r_Pg_Business.Back_By,               --作废人
                   -- r_Pg_Business.Reject_Date,           --作废时间
                   --r_Pg_Business.Relogin_Flag,          --重新登录标识
                   '0', --中标状态
                   --r_Pg_Business.Freeze_Status,         --冻结状态
                   --r_Pg_Business.Freeze_Person,         --冻结人
                   --r_Pg_Business.Freeze_Time,           --冻结时间
                   --r_Pg_Business.Unfreeze_Person,       --解冻人
                   --r_Pg_Business.Unfreeze_Time,         --解冻时间
                   --r_Pg_Business.Is_Market_StLrategy,    --战略大盘采购
                   --r_Pg_Business.Verfication_Status,    --核销状态 0未核销 1已核销 2核销失败
                   --r_Pg_Business.Remark,                --备注
                   R_PG_SC_BUSINESS_INFO.IS_GROUPBUY,           --是否团购
                   --r_Pg_Business.Program_Updated_By,    --程序修改来源
                   sysdate,
                   --to_date(sysdate,'yyyy-MM-dd HH24:mi:ss'), --修改时间
                   R_PG_SC_BUSINESS_INFO.BUSINESS_ID, --上级项目ID
                   R_PG_SC_BUSINESS_INFO.PROJECT_CODE, --上级项目编码
                   R_PG_SC_BUSINESS_INFO.TRADE, ----所属行业
                   R_PG_SC_BUSINESS_INFO.BRAND, ----品牌
                   R_PG_SC_BUSINESS_INFO.CATEGORY, ----品类
                   R_PG_SC_BUSINESS_INFO.CUSTOMER_FAX, ----经销商传真电话
                   R_PG_SC_BUSINESS_INFO.FOLLOW_MAN, ----分部业务员
                   R_PG_SC_BUSINESS_INFO.FOLLOWER_TELEPHONE, ----分部业务员电话
                   R_PG_SC_BUSINESS_INFO.MAIN_MATERIAL, ----涉及机型
                   R_PG_SC_BUSINESS_INFO.QUERY_KEYWORDS, ----查询关键字
                   R_PG_SC_BUSINESS_INFO.STAT_KEYWORDS, ----统计关键字
                   R_PG_SC_BUSINESS_INFO.TG_COMMISSIONER, ----团购专员
                   R_PG_SC_BUSINESS_INFO.TG_COMMI_PHONE, ----团购专员电话
                   R_PG_SC_BUSINESS_INFO.REFER_AREA_ID, ----安装涉及区域ID
                   R_PG_SC_BUSINESS_INFO.REFER_AREA, ----安装涉及区域
                   R_PG_SC_BUSINESS_INFO.DEAL_START_DATE, ----登录开始日期
                   R_PG_SC_BUSINESS_INFO.DEAL_END_DATE, ----登录结束日期
                   R_PG_SC_BUSINESS_INFO.GROUP_BUY_SALES_MAIN_TYPE, ----营销大类
                   R_PG_SC_BUSINESS_INFO.SOURCE_SYSTEM 
                   ,R_PG_SC_BUSINESS_INFO.Big_Panel
                   );
              EXCEPTION
                WHEN OTHERS THEN
                  P_MESSAGE := V_VALUE || '出错。' || v_Nl || SQLERRM;
              END;
             END IF;
             
             IF P_MESSAGE = v_Success AND V_IF_PRODUCT_LINE = 'N' THEN
               OPEN C_PG_SC_BUSINESS_LINE;
                 LOOP 
                   FETCH C_PG_SC_BUSINESS_LINE
                   INTO R_PG_SC_BUSINESS_LINE;
                 EXIT WHEN C_PG_SC_BUSINESS_LINE%NOTFOUND OR P_MESSAGE <> v_Success;
                             
                BEGIN
                V_VALUE := '查询产品营销大类、小类编码：';
                SELECT TI.SALES_MAIN_TYPE, TI.SALES_SUB_TYPE
                  INTO V_SALES_MAIN_TYPE_CODE, V_SALES_SUB_TYPE_CODE
                  FROM T_BD_ITEM TI
                 WHERE TI.ITEM_CODE = R_PG_SC_BUSINESS_LINE.ITEM_CODE
                   AND TI.ENTITY_ID = P_ENTITY_ID;
                EXCEPTION
                   WHEN OTHERS THEN
                     P_MESSAGE := V_VALUE ||
                                  R_PG_SC_BUSINESS_LINE.ITEM_CODE ||
                                  '失败。' || v_Nl || SQLERRM;
                END;
                
              BEGIN
                V_VALUE := '查询产品营销大类名称：';
                SELECT TC.CLASS_NAME
                  INTO V_SALES_MAIN_TYPE_NAME
                  FROM T_BD_ITEM_CLASS TC
                 WHERE TC.CLASS_CODE = V_SALES_MAIN_TYPE_CODE
                   AND TC.ENTITY_ID = P_ENTITY_ID
                   AND TC.ACTIVE_FLAG = 'Y';
              EXCEPTION
                WHEN OTHERS THEN
                  P_MESSAGE := V_VALUE || R_PG_SC_BUSINESS_LINE.ITEM_CODE ||
                               '失败。' || v_Nl || SQLERRM;
              END;
              
              BEGIN
                V_VALUE := '查询产品营销小类名称：';
                SELECT TC.CLASS_NAME
                  INTO V_SALES_SUB_TYPE_NAME
                  FROM T_BD_ITEM_CLASS TC
                 WHERE TC.CLASS_CODE = V_SALES_SUB_TYPE_CODE
                   AND TC.ENTITY_ID = P_ENTITY_ID
                   AND TC.ACTIVE_FLAG = 'Y';
              EXCEPTION
                WHEN OTHERS THEN
                  P_MESSAGE := V_VALUE || R_PG_SC_BUSINESS_LINE.ITEM_CODE ||
                               '失败。' || v_Nl || SQLERRM;
              END;
              /*
                BEGIN
                  V_VALUE := '查询产品营销大类：';
                  SELECT TC.CLASS_NAME,TC.CLASS_CODE
                    INTO V_SALES_MAIN_TYPE_NAME,V_SALES_MAIN_TYPE_CODE
                    FROM T_BD_ITEM_CLASS TC
                   WHERE TC.CLASS_CODE = R_PG_SC_BUSINESS_LINE.SALES_MAIN_TYPE
                     AND TC.ENTITY_ID = P_ENTITY_ID
                     AND TC.ACTIVE_FLAG = 'Y';
                EXCEPTION
                  WHEN OTHERS THEN
                    P_MESSAGE := V_VALUE || R_PG_SC_BUSINESS_LINE.SALES_MAIN_TYPE ||
                                 '失败。' || v_Nl || SQLERRM;
                END;
                
                BEGIN
                  V_VALUE := '查询产品营销小类：';
                  SELECT TC.CLASS_NAME,TC.CLASS_CODE
                    INTO V_SALES_SUB_TYPE_NAME,V_SALES_SUB_TYPE_CODE
                    FROM T_BD_ITEM_CLASS TC
                   WHERE TC.CLASS_CODE = R_PG_SC_BUSINESS_LINE.SALES_SUB_TYPE
                     AND TC.ENTITY_ID = P_ENTITY_ID
                     AND TC.ACTIVE_FLAG = 'Y';
                EXCEPTION
                  WHEN OTHERS THEN
                    P_MESSAGE := V_VALUE || R_PG_SC_BUSINESS_LINE.SALES_SUB_TYPE ||
                                 '失败。' || v_Nl || SQLERRM;
                END;
                
                */
                 --校验行数据
                BEGIN
                  V_VALUE := '校验产品信息：';
                  SELECT TI.ITEM_ID, TI.ITEM_NAME, TI.DEFAULTUNIT
                       INTO V_ITEM_ID, V_ITEM_NAME, V_UOM_CODE
                       FROM T_BD_ITEM TI
                      WHERE TI.ENTITY_ID = P_ENTITY_ID
                        AND TI.SALES_MAIN_TYPE =
                            V_SALES_MAIN_TYPE_CODE
                        AND TI.ACTIVE_FLAG = 'Y'
                        AND TI.ITEM_CODE = R_PG_SC_BUSINESS_LINE.ITEM_CODE;
                   EXCEPTION
                     WHEN OTHERS THEN
                       P_MESSAGE := V_VALUE ||
                                    R_PG_SC_BUSINESS_LINE.ITEM_CODE ||
                                    '失败。' || v_Nl || SQLERRM;
                END;
               
               BEGIN
                 V_VALUE := '插入商机行表：';
                 SELECT S_PG_BUSINESS_LINE.NEXTVAL INTO V_BUSINESS_LINE_ID FROM DUAL;
                 Insert Into T_PG_BUSINESS_LINE
                    (bussiness_line_id, --商机商品行信息ID
                     business_id, --商机信息ID
                     sales_main_type, --营销大类编码
                     sales_main_type_name, --营销大类名称
                     sales_sub_type, --营销小类编码
                     sales_sub_type_name, --营销小类名称
                     item_id, --产品ID
                     item_code, --产品编码
                     item_desc, --产品型号
                     uom_code, --单位
                     common_price, --直供价
                     requis_price, --预计报价
                     requis_qty, --申请数量
                     created_by, --创建人
                     creation_date, --创建时间
                     last_updated_by, --修改人
                     last_update_date, --修改时间
                     entity_id --主体ID
                     )
                  Values
                    (V_BUSINESS_LINE_ID, --商机商品行信息ID
                     V_BUSINESS_ID, --商机信息ID
                     V_SALES_MAIN_TYPE_CODE, --营销大类编码
                     V_SALES_MAIN_TYPE_NAME, --营销大类名称
                     V_SALES_SUB_TYPE_CODE, --营销小类编码
                     V_SALES_SUB_TYPE_NAME, --营销小类名称
                     V_ITEM_ID, --产品ID
                     V_ITEM_CODE, --产品编码
                     V_ITEM_NAME, --产品型号
                     V_UOM_CODE, --单位
                     R_PG_SC_BUSINESS_LINE.COMMON_PRICE, --直供价
                     R_PG_SC_BUSINESS_LINE.REQUIS_PRICE, --预计报价
                     R_PG_SC_BUSINESS_LINE.REQUIS_QTY, --申请数量
                     'CIMS销司', --创建人
                     sysdate,--to_date(sysdate,'yyyy-MM-dd HH24:mi:ss'), --创建时间
                     'CIMS销司', --修改人
                     sysdate,--to_date(sysdate,'yyyy-MM-dd HH24:mi:ss'), --修改时间
                     P_ENTITY_ID --主体ID
                     );
               EXCEPTION
                 WHEN OTHERS THEN
                   P_MESSAGE := V_VALUE || '出错。'|| v_Nl || SQLERRM;
               END;
               END LOOP;
             ELSIF P_MESSAGE = v_Success AND V_IF_PRODUCT_LINE = 'Y' THEN
                OPEN C_PG_SC_BUSINESS_PRODUCT_LINE;
                 LOOP 
                 FETCH C_PG_SC_BUSINESS_PRODUCT_LINE
                 INTO R_PG_SC_BUSINESS_PRODUCT_LINE;
                 EXIT WHEN C_PG_SC_BUSINESS_PRODUCT_LINE%NOTFOUND OR P_MESSAGE <> v_Success;
                
                --校验行数据
                BEGIN
                  V_VALUE := '校验产品线信息：';
                  SELECT TPL.PRODUCTLINE_ID, TPL.PRODUCTLINE_NAME
                    INTO V_PRODUCT_LINE_ID, V_PRODUCT_LINE_NAME
                    FROM T_PG_PRODUCT_LINE TPL
                   WHERE TPL.PRODUCTLINE_CODE =
                         R_PG_SC_BUSINESS_PRODUCT_LINE.PRODUCTLINE_CODE
                     AND TPL.ENTITY_ID = P_ENTITY_ID;
                EXCEPTION
                  WHEN OTHERS THEN
                     P_MESSAGE := V_VALUE || '失败。' || v_Nl || SQLERRM;
                END;
              
               BEGIN
                 V_VALUE := '插入产品线行表：';
                 ---序列
                  SELECT S_PG_BUSINESS_APPROVAL.NEXTVAL
                    INTO V_BUSINESS_LINE_ID
                    FROM DUAL;
                
                  Insert Into T_Pg_Business_Approval
                  (business_audit_id,                      --产品线登录行ID
                   business_id,                            --商机信息ID
                   productline_id,                         --产品线ID
                   productline_code,                       --产品线编码
                   productline_name,                       --产品线名称
                   creation_date,                          --创建时间
                   last_update_date,                       --修改时间
                   entity_id,                              --主体ID
                   created_by,
                   last_updated_by
                  )
                  Values
                  (V_BUSINESS_LINE_ID, --商机商品行信息ID
                   V_BUSINESS_ID, --商机信息ID
                   V_PRODUCT_LINE_ID, --产品线ID
                   R_PG_SC_BUSINESS_PRODUCT_LINE.PRODUCTLINE_CODE,--产品线编码
                   V_PRODUCT_LINE_NAME,  --产品线名称
                   sysdate,--to_date(sysdate,'yyyy-MM-dd HH24:mi:ss'),--创建时间
                   sysdate,--to_date(sysdate,'yyyy-MM-dd HH24:mi:ss'),--修改时间
                   P_ENTITY_ID,--主体ID
                   'CIMS销司',
                   'CIMS销司'
                  );
               EXCEPTION
                 WHEN OTHERS THEN
                   P_MESSAGE := V_VALUE || '失败。' || v_Nl || SQLERRM;
               END;
               END LOOP;
             END IF;  
         END IF;
        
      END IF;
      
       ----更新销司商机下级项目编码
      IF P_MESSAGE = v_Success THEN
        UPDATE T_PG_BUSINESS B
           SET B.SUB_BUSINESS_ID   = V_BUSINESS_ID,
               B.SUB_BUSINESS_CODE = V_PROJECT_CODE
         WHERE B.BUSINESS_ID = P_BUSINESS_ID;
      END IF;          
    END;

-- author  : huanghb12
-- created : 2018/02/28 16:34:40
-- purpose : 工程机核销单录入
----------------------------------------------------------------------
--输入项：p_header_id 核销头接口表id
--输出项：p_Result 记录错误信息   
procedure P_PG_VERIFICATION(p_header_id in number, p_Result Out Varchar2) is
    --pragma autonomous_transaction;
  
    r_pg_veri_header intf_pg_veri_header%rowtype; --核销头接口表信息变量
  
    --使用游标保存多行，根据id查询未处理的核销行信息
    cursor c_pg_veri_line is
      select *
        from intf_pg_veri_line vl
       where vl.intf_header_id = p_header_id
         and vl.flag = '0';
  
    --使用游标保存多行，根据id，查询未处理的，核销附件信息    
    cursor C_FILES is
      select *
        from intf_pg_veri_files t
       where t.intf_header_id = p_header_id
         and t.flag = '0';
  
    FILES_ROW     C_FILES%ROWTYPE; --待处理附件行表数据
    V_COUNT_FILES NUMBER; --待处理附件的个数
  
    r_pg_veri_line c_pg_veri_line%rowtype; --提取核销行游标的数据
    v_value        varchar2(500); --存储信息
    veri_mode   VARCHAR2(32); --记录是那种模式，厨热模式与其他不一样
  
    v_price_apply_id number; --存储价格批文号，查询价格批文中获得
    v_veri_header_id number; --存储核销头id，查询核销头序列获得
    v_veri_line_id   number; --存储核销行id，查询核销行序列获得
    v_item_id        number; --存储cims价格批文中的商品id  

    v_pv_veri_num varchar2(32); --存储核销单编号，查询编码规则存储过程获得
    
    v_pg_is_big_order         varchar2(2);  --存储申报头表的是否大单
    v_pg_is_point_check       varchar2(2);  --存储申报头表的是否重点稽查
  
    v_used_cnt                number; --已提货数量
    v_verification_cnt        number; --已核销数量
    v_to_buyout_cnt           number; --已转买断数量
    v_total_Verifing_Quantity number; --正在核销的商品数量，且暂未核销完成
    v_total_to_buyout_num     number; --正在核销的转买断商品数量，且暂未核销完成
    v_can_Verification_Cnt    number; --计算之后的可核销数量（包括正在核销的数量）
    v_unqualified_num         number; --计算同一单据号同一产品的不合格数量之和
    --v_can_to_buyout_num       number; --计算之后的转买断数量（包括正在转买断的数量）
    v_total_count             number;
    v_total_last_amount       number; --累计上次补差金额
    v_sales_main_type         varchar2(32);--营销大类
    v_standard_price          number; --标准开单价
    v_order_price             number; --结算价
    v_is_after_cash           varchar2(2);--是否事后返差
    v_after_cash_approval     varchar2(32);--事后返差批文
    v_project_list_price      varchar2(32);--事后返差取得的列表工程价
  begin
    p_Result := v_Success; --处理成功
  
    begin
      v_value := '锁定核销接口头表失败！';
      --获取核销头接口表数据，根据输入的id和flag状态为 0-未处理
      select *
        into r_pg_veri_header
        from intf_pg_veri_header h
       where h.intf_header_id = p_header_id
         and h.flag = '0'
         for update nowait;
    exception
      when others then
        p_Result := v_value || v_nl || sqlerrm;
    end;
    
    IF p_Result = v_Success THEN
       --查询系统参数
       BEGIN
          v_value := '获取主体参数';
          PKG_BD.P_GET_PARAMETER_VALUE('PG_VERI_MODE',
                                       r_pg_veri_header.ENTITY_ID,
                                       Null,
                                       Null,
                                       veri_mode);
       EXCEPTION
         WHEN OTHERS THEN
           p_Result := v_value || '获取主体参数失败。' || v_nl || SQLERRM;
       END;
     END IF;
  
    --校验价格批文编号是否有效,modify by houhs at 20190904对于厨热模式的核销不进行校验批文，校验
    if p_Result = v_Success then
      --非厨热模式的工程机核销
      if nvl(veri_mode,'N') = 'N' then
        begin
          v_value := '检查账户价格批文号：';
          select a.price_apply_id
            into v_price_apply_id
            from cims.t_bd_price_apply a
           where 1 = 1
             and a.apply_code = r_pg_veri_header.apply_code
             and a.apply_status = '30';
        exception
          when others then
            p_Result := v_value || '价格批文编号：' || r_pg_veri_header.apply_code ||
                        '不存在或者已失效。p_header_id = ' || p_header_id;
        end;
       
       elsif nvl(veri_mode,'N') = 'Y' then
          begin
             v_value := '检查项目登录编码：';
            if r_pg_veri_header.project_code_ccs is null then 
              p_Result := v_value || '项目登录编码project_code_ccs' || r_pg_veri_header.project_code_ccs ||
                          '为空或不存在 ';
            end if;
          end;
       end if;
    end if;
    
     --add by houhs at 20190312 将申报表的是否大单是否稽查写入核销表是否大单是否稽查字段
     -- modify by houhs 对于非厨热模式才进行取是否大单以及是否稽查字段
    if p_Result = v_Success then
      if nvl(veri_mode,'N') = 'N' then
        begin
          select h.is_big_order,h.is_point_check
            into v_pg_is_big_order,v_pg_is_point_check
            from cims.t_pg_price_apply_head h
          where 1 = 1
            and h.apply_code = r_pg_veri_header.apply_code;
        exception
          when others then
            v_pg_is_big_order := null;v_pg_is_point_check := null;
        end;
        --对于厨热模式直接将是否稽查和是否大单设置为空
       elsif nvl(veri_mode,'N') = 'Y' then
          begin
              v_pg_is_big_order := null;v_pg_is_point_check := null;
          end;
       end if;
    end if;
    
    
    --校验当次核销数量、当次转买断数量至少有一项不等于0，对于厨热模式不存在转买断,直接判断核销数量
    if p_Result = v_Success then
      if nvl(veri_mode,'N') = 'N' then
        select count(*) into v_total_count from intf_pg_veri_line v where v.intf_header_id = p_header_id
        and (nvl(v.verification_quantity,0)!=0 or nvl(v.to_buyout_num,0)!=0);
        if v_total_count <= 0 then
          p_Result := '当次核销数量、当次转买断数量至少有一项不等于0，p_header_id = ' || p_header_id;
        end if;
      --对于厨热模式直接将是否稽查和是否大单设置为空
       elsif nvl(veri_mode,'N') = 'Y' then
          select count(*) into v_total_count from intf_pg_veri_line v where v.intf_header_id = p_header_id
          and nvl(v.verification_quantity,0)!=0 ;
          if v_total_count <= 0 then
            p_Result := '当次核销数量不能等于0，p_header_id = ' || p_header_id;
          end if;
       end if;
    end if;
  
    --处理核销头接口表数据，插入核销头业务表
    if p_Result = v_Success then
      --查询序列，获得核销单id
      select s_t_pg_veri_header.nextval into v_veri_header_id from dual;
      --调用过程，获得核销单一个核销单据号
      pkg_bd.p_get_bill_no('PG_VERI_NUM',
                           null,
                           r_pg_veri_header.entity_id,
                           null,
                           v_pv_veri_num);
      begin
        v_value := '开始插入核销头业务头表数据';
        insert into t_pg_veri_header
          (veri_header_id, --核销头id
           pv_veri_num, --核销单据号        
           veri_date, --核销日期
           apply_code, --价格批文号         
           --apply_date        --价格申报申请日期（非价格批文申请日期）
           project_name, --项目名称
           project_address, --项目地址  
           veri_status, --核销单状态          
           is_big_order,  --是否大单    
           is_point_check,  --是否重点稽查
           --oi_css_recall_fla    varchar2(1)                    null,
           --recall_by            varchar2(32)                   null,
           --recall_date          date                           null,
           --recall_msg           varchar2(1000)                 null,
           --close_by             number                         null,
           --close_date           date                           null,
           --close_flag           varchar2(1)                    null,
           source_system, --信息来源  varchar2(32)
           created_by, -- 创建人为系统来源 varchar2(32)                   null,
           creation_date, --date                           null,
           last_updated_by, --varchar2(32)                   null,
           last_update_date, --date                           null,
           remark, --varchar2(1000)                 null,
           entity_id, --主体number                         not null,
           --appendix_id           --附件业务idM，在上传附件成功的时候更新，
           project_code_ccs,     --商机登录编码CCS
           user_firm_ccs,        --使用单位 add by houhs at 20190904
           user_name_ccs,        --项目方联系人
           user_phone_ccs,       --联系方式
           customer_person_ccs,       --经销商联系人
           customer_phone_ccs,        --联系方式
           customer_code_ccs              --经销商编码
           )
        values
          (v_veri_header_id, --核销头id
           v_pv_veri_num, --核销单据号
           sysdate, --核销日期
           r_pg_veri_header.apply_code, --价格批文编号                       
           r_pg_veri_header.project_name, --项目名称
           r_pg_veri_header.project_address, --项目地址
           '0', --核销单状态 0- 已录入、1-已送审、2-已审核、6-已驳回、3-已作废
           v_pg_is_big_order，  --是否大单
           v_pg_is_point_check， --是否稽查
           r_pg_veri_header.source_system, --信息来源   ccs
           r_pg_veri_header.source_system, --创建人为系统来源
           sysdate, --创建日期
           r_pg_veri_header.source_system, --最后修改人为系统来源
           sysdate, --最后修改日期
           r_pg_veri_header.remark, --备注
           r_pg_veri_header.entity_id, --主体
           r_pg_veri_header.project_code_ccs, --商机登录编码
           r_pg_veri_header.user_firm_ccs,  --使用单位
           r_pg_veri_header.user_name_ccs,  --联系方式
           r_pg_veri_header.user_phone_ccs,  --联系方式
           r_pg_veri_header.customer_person_ccs,  --经销商联系人
           r_pg_veri_header.customer_phone_ccs,  --联系方式
           r_pg_veri_header.customer_code        --经销商编码
           );
      
      exception
        when others then
          p_Result := v_value || '，失败。' || v_nl || sqlerrm;
      end;
    end if;
  
    --处理核销行接口表数据，插入核销行表
    if p_Result = v_Success then
      open c_pg_veri_line;
      loop
        fetch c_pg_veri_line
          into r_pg_veri_line;
        exit when c_pg_veri_line%notfound or p_Result <> v_Success;
        
         --对于厨热模式核销行上的单据号为必须传送的，做非空校验
        if p_Result = v_Success and nvl(veri_mode,'N') = 'Y' then
          --非厨热模式的工程机核销
              begin
                 v_value := '检查核销行上的单据号：';
                if r_pg_veri_line.so_num is null then 
                  p_Result := v_value || 'so_num' || r_pg_veri_line.so_num ||
                              '为空或不存在,请CCS传送销售单单据号';
                end if;
              end;
        end if;
      
        --获得单个商品的可核销数量
        --当次核销数量需要小于可核销数量，厨热模式与原来模式存在区别，根据系统参数来分别
        --非厨热模式 
        if p_result = v_Success then
          if nvl(veri_mode,'N') = 'N' then
            v_value := '查询价格批文中核销数量';
            select nvl(pd.used_cnt, 0), --已提货数量
                   nvl(pd.verification_cnt, 0), --已核销数量
                   nvl(pd.to_buyout_cnt, 0), --已转买断
                   pd.item_id            --cims系统中商品id
              into v_used_cnt, v_verification_cnt, v_to_buyout_cnt,v_item_id
              from cims.t_bd_price_apply_detail pd
             where 1 = 1
               and pd.price_apply_id = v_price_apply_id
               and pd.item_code = r_pg_veri_line.item_code
               and pd.entity_id = r_pg_veri_line.entity_id;
                 
            --本价格批文下，正在审批的核销单的商品总数量与总转买断数量，且暂未核销完成
            v_value := '查询核销行中核销数量';
            select nvl(sum(t.verification_quantity), 0),nvl(sum(t.to_buyout_num), 0)
              into v_total_Verifing_Quantity, v_total_to_buyout_num
              from cims.t_pg_veri_line t
              left join cims.t_pg_veri_header h
                on t.veri_header_id = h.veri_header_id
             where 1 = 1
               --0已录入1已核销的都要减去 zhouly2 18-6-13
               and h.veri_status in('0','1','6')--正在核销的状态，且核销未完成
               and h.apply_code = r_pg_veri_header.apply_code
               and t.item_id = v_item_id;
            
            begin
              v_value := '本次核销数量超过可核销数量（已提数量-已核销数量-已转买断数量)-正在审批(总核销数量 + 总转买断）- 本次转买断数量 - 本次核销的数量';
              --计算可核销或者转买断数量:（已提数量-已核销数量-已转买断数量)-正在审批(总核销数量 + 总转买断）- 本次转买断数量 - 本次核销的数量
              v_can_Verification_Cnt := (v_used_cnt - v_verification_cnt - v_to_buyout_cnt) - (v_total_Verifing_Quantity + v_total_to_buyout_num) - (nvl(r_pg_veri_line.to_buyout_num,0) + nvl(r_pg_veri_line.verification_quantity,0));
              if v_can_Verification_Cnt < 0 then
                p_result := v_value;
               end if;
           exception
              when others then
                p_result := v_value;
             end;
             
            elsif  nvl(veri_mode,'N') = 'Y' then
            
            v_value := '查询核销行中的cims的商品id';
              select t.item_id
                into v_item_id
                from cims.t_so_line_extend t
                where 1 = 1
                 and t.so_num = r_pg_veri_line.so_num
                 and t.item_code = r_pg_veri_line.item_code;
            
            --厨热模式
              v_value := '查询正在核销的数量';
              select nvl(sum(t.verification_quantity), 0)
                into v_total_Verifing_Quantity
                from cims.t_pg_veri_line t
                left join cims.t_pg_veri_header h
                  on t.veri_header_id = h.veri_header_id
               where 1 = 1
                 --0已录入1已核销的都要减去 zhouly2 18-6-13
                 and h.veri_status in('0','1','2','6')--正在核销的状态，且核销未完成
                 and t.so_num = r_pg_veri_line.so_num
                 and t.item_code = r_pg_veri_line.item_code;
                 
               --查询已核销数量，以及营销大类
              v_value := '查询已经核销数量，不合格数量，累计上次补差金额，营销大类，结算价，标准开单价';
              select nvl(t.veri_sum, 0),nvl(t.total_all_amount,0),nvl(t.unqualified_sum, 0),t.sales_main_type,t.standard_price,t.item_settle_price
                into v_verification_cnt,v_total_count, v_unqualified_num,v_sales_main_type,v_standard_price,v_order_price
                from cims.t_so_line_extend t
               where 1 = 1
                 and t.so_num = r_pg_veri_line.so_num
                 and t.item_id = v_item_id;
               
               --检查是否存在事后返差批文 
               BEGIN
               v_value := '查询该核销单行上是否存在事后返差批文';
               SELECT 'Y',TA.APPLY_CODE,TD.APPLY_PRICE*(100 - NVL(TD.MONTH_DISCOUNT,0))*0.01
                 INTO v_is_after_cash,v_after_cash_approval,v_project_list_price
                 FROM CIMS.T_BD_PRICE_APPLY TA, CIMS.T_BD_PRICE_APPLY_DETAIL TD
                WHERE TA.PRICE_APPLY_ID = TD.PRICE_APPLY_ID
                  AND TA.ENTITY_ID = r_pg_veri_line.entity_id
                  AND TA.BACK_DIFF = 'Y'
                  AND TA.APPLY_STATUS = '30'
                  AND TA.PROJECT_CODE = r_pg_veri_header.Project_Code_Ccs
                  AND TD.ITEM_CODE = r_pg_veri_line.Item_Code;
                 EXCEPTION
                WHEN OTHERS THEN
                 v_is_after_cash := 'N';
                END;
                 
              
                 
               begin
              v_value := '本次核销数量超过可核销数量（已提数量-已核销数量-)-正在审批(总核销数量）- 不合格数量';
              --本次核销数量超过可核销数量（已提数量-已核销数量)-正在审批(总核销数量）- 不合格数量
              v_can_Verification_Cnt := nvl(r_pg_veri_line.used_cnt,0) - v_verification_cnt - v_total_Verifing_Quantity - v_unqualified_num - nvl(r_pg_veri_line.verification_quantity,0);
              if v_can_Verification_Cnt < 0 then
                p_result := v_value;
               end if;
               exception
                  when others then
                    p_result := v_value;
             end;
            end if;
        end if;
      
        --处理单行数据，插入业务表中
        if p_result = v_Success then
          select cims.s_t_pg_veri_line.nextval
            into v_veri_line_id
            from dual;
          begin
            v_value := '开始将核销单插入业务行表数据';
            insert into cims.t_pg_veri_line
              (VERI_LINE_ID, --核销行         NUMBER                         NOT NULL,
               VERI_HEADER_ID, --核销头id       NUMBER                         NOT NULL,
               ITEM_ID, --商品id              NUMBER                         NOT NULL,
               ITEM_CODE, --商品编码            VARCHAR2(100)                  NOT NULL,
               ITEM_NAME, --商品名            VARCHAR2(240)                  NOT NULL,
               LIST_PRICE, --           NUMBER                         NULL,
               CONTRACT_PRICE, --       NUMBER                         NULL,
               APPLY_PRICE, --          NUMBER                         NULL,
               LAST_PRICE, --           NUMBER                         NULL,
               APPLY_CNT, --        NUMBER                         NULL,
               VERIFICATION_QUANTITY, -- NUMBER                         NOT NULL,
               TO_BUYOUT_NUM, --        NUMBER                         NULL,
               POLICY_NUMBER, --        VARCHAR2(40)                   NULL,
               USED_CNT, --        NUMBER                         NOT NULL,
               CREATED_BY, --           VARCHAR2(32)                   NULL,
               CREATION_DATE, --        DATE                           NULL,
               LAST_UPDATED_BY, --      VARCHAR2(32)                   NULL,
               LAST_UPDATE_DATE, --     DATE                           NULL,
               ENTITY_ID, --            NUMBER                         NOT NULL,
               REMARK, --备注
               VERI_SUM, --累计核检通过数量
               INSTALL_ADD, --安装地址
               INSTALL_TIME, --安装时间
               SO_NUM, --销售单号
               PROJECT_TYPE_CODE, --批文类型
               PROJECT_NUM, --批文号
               IS_BATCH_VERI, --是否分批核销
               UNQUALIFIED_NUM, --不合格数量
               TOTAL_LAST_AMOUNT, --累计上次补差金额
               SALES_MAIN_TYPE,   --营销大类
               STANDARD_PRICE,     --标准开单价
               ORDER_PRICE,        --结算价
               PROJECT_LIST_PRICE,   --工程列表价针对事后返差
               IS_AFTER_CASH,     --是否事后返差
               AFTER_CASH_APPROVAL   --事后返差批文
               )
            values
              (v_veri_line_id, --核销行id
               v_veri_header_id, --核销头id
               v_item_id,        --cims 商品id
               r_pg_veri_line.item_code, --商品编码
               r_pg_veri_line.item_name, --商品名称
               r_pg_veri_line.list_price,
               r_pg_veri_line.contract_price,
               r_pg_veri_line.apply_price,
               r_pg_veri_line.last_price,
               r_pg_veri_line.apply_cnt,
               nvl(r_pg_veri_line.verification_quantity,0),
               nvl(r_pg_veri_line.to_buyout_num,0),
               r_pg_veri_line.policy_number,
               r_pg_veri_line.used_cnt, --已提数量 
               r_pg_veri_header.source_system, --创建人为系统来源
               sysdate, --创建日期
               r_pg_veri_header.source_system, --最后修改人为系统来源
               sysdate, --最后修改日期
               r_pg_veri_header.entity_id, --主体
               r_pg_veri_header.remark, --备注
               v_verification_cnt, --累计核检通过数量          
               r_pg_veri_line.install_add, --安装地址
               r_pg_veri_line.install_time, --安装时间
               r_pg_veri_line.so_num, --销售单号
               r_pg_veri_line.project_type_code, --批文类型
               r_pg_veri_line.project_num, --批文编号
               r_pg_veri_line.is_batch_veri, --是否分批核销
               v_unqualified_num, --累计不合格数量
               v_total_count, -- 累计上次补差金额
               v_sales_main_type, --营销大类
               v_standard_price,   --标准开单价
               v_order_price,     --结算价
               v_project_list_price,  --工程列表价针对事后返差
               v_is_after_cash,    --是否事后返差
               v_after_cash_approval  --事后返差批文号
               );
          exception
            when others then
              p_result := v_value || '失败。' || v_nl || sqlerrm;
          end;
           
        end if;
      
        --更新接口行表
        if p_result <> v_success then
          --如果失败就回滚，且更新接口表
          --rollback;
          --更新接口行表
          update intf_pg_veri_line vl
             set vl.error_info = p_result, --记录错误信息
                 vl.status     = '1', --处理失败
                 vl.flag       = '1' --已处理
          --vl.insert_time    = sysdate
           where vl.intf_line_id = r_pg_veri_line.intf_line_id;
          --commit;
          --否则，处理成功，则回填数据
        else
          update intf_pg_veri_line vl
             set vl.veri_header_id = v_veri_header_id, --回填核销头业务表id
                 vl.veri_line_id   = v_veri_line_id, --回填核销行业务表id
                 vl.error_info     = p_result, --记录错误信息
                 vl.status         = '0', --处理失败
                 vl.flag           = '1' --已处理
          --vl.insert_time    = sysdate
           where vl.intf_line_id = r_pg_veri_line.intf_line_id;
          --commit;
        end if;
      end loop; --行数据循环结束
    end if; --结束接口行表的处理
  
    --处理附件，处理附件之前，需要判断是会否存在附件
    if p_result = v_Success then
      select count(*)
        into V_COUNT_FILES --文件的数量
        from intf_pg_veri_files t
       where t.intf_header_id = p_header_id
         and t.flag = '0';
    
      --处理附件数据
      if V_COUNT_FILES > 0 then
        v_value := '开始将附件接口表的数据插入平台附件行表';
        FOR FILES_ROW IN C_FILES LOOP
          BEGIN
            --插入往来对账单附件信息表
            INSERT INTO IMS_FILEINFO_INTERFACE
              (ID, BUSINESS_ID, BUSINESS_TYPE, FILE_PATH, FILE_NAME)
            VALUES
              (SEQ_IMS_FILEINFO.NEXTVAL, --附件表序列
               v_pv_veri_num, --附件业务id，与核销单保持一致
               'verificationAppendix', --配置的附件类型
               FILES_ROW.Local_Path,
               FILES_ROW.File_Name);
            --更新接口表INTF_PG_VERI_FILES状态为0：成功
            UPDATE INTF_PG_VERI_FILES F
               SET F.STATUS     = '0',
                   F.ERROR_INFO = p_Result,
                   F.FLAG       = '1',
                   --F.INSERT_TIME    = sysdate,
                   F.Veri_Header_Id = v_veri_header_id --回写核销头表id到附件接口表中
             WHERE F.INTF_HEADER_ID = p_header_id
               AND FLAG = '0';
          
            --有附件则更新头表附件业务id
            UPDATE CIMS.T_PG_VERI_HEADER H
               SET H.APPENDIX_ID = v_pv_veri_num --附件的业务id，等于核销单据的id  
             WHERE H.VERI_HEADER_ID = v_veri_header_id; --条件就是
            --COMMIT;
          
          EXCEPTION
            WHEN OTHERS THEN
              p_result := v_value || '失败。' || v_nl || sqlerrm;
              UPDATE INTF_PG_VERI_FILES F
                 SET F.STATUS     = '1', --处理失败
                     F.ERROR_INFO = p_Result,
                     F.FLAG       = '1',
                     --F.INSERT_TIME    = sysdate,
                     F.Veri_Header_Id = v_veri_header_id --回写核销头表id到附件接口表中
               WHERE F.INTF_HEADER_ID = p_header_id
                 AND FLAG = '0';
          END;
        END LOOP; --附件接口表数据循环结束
      end if; --结束循环条件进入
    end if; --结束处理附件数据
  
    --更新接口头表
    --如果处理失败，则回滚
    if p_result <> v_success then
      --如果失败就回滚，且更新接口表
      --rollback;
      --更新接口头表
      update intf_pg_veri_header vh
         set vh.error_info = p_result, --记录错误信息
             vh.status     = '1', --处理失败
             vh.flag       = '1' --已处理
      --vh.insert_time    = sysdate
       where vh.intf_header_id = r_pg_veri_header.intf_header_id;
      --commit;
      --否则，处理成功，则回填数据
    else
      update intf_pg_veri_header vh
         set vh.veri_header_id = v_veri_header_id, --回写核销头表id到核销头接口表中
             VH.PV_VERI_NUM = V_PV_VERI_NUM,        --回写核销单号
             vh.status         = '0', --处理成功                                            
             vh.error_info     = p_result,
             --vh.insert_time    = sysdate,
             vh.flag = '1' --已处理
       where vh.intf_header_id = r_pg_veri_header.intf_header_id;
      --commit;
    end if; --更新接口头表
  exception
    when others then
      --rollback;
      p_result := '失败：' || p_result || v_nl || sqlerrm;
  end;
  
  ----------------------------------------------------------------------
  -- Author  : huanghb12
  -- Created : 2018/03/21
  -- Purpose : 工程机核销CCS驳回
  ----------------------------------------------------------------------
  Procedure P_PG_VERIFICATION_REJECT(CSS_ID IN NUMBER,P_REJECT_REASON IN VARCHAR2,P_MESSAGE OUT VARCHAR2) IS
    V_VALUE                VARCHAR2(1024);
    V_CCS_MESSAGE          VARCHAR2(1024);
    BEGIN
      V_VALUE := '调用CCS驳回校验：';
      CCS_PG_REJECT_PKG.PRO_CCS_CIMS_VERIFY_REJECT(CSS_ID,P_REJECT_REASON,V_CCS_MESSAGE);
      IF V_CCS_MESSAGE IS NOT NULL THEN
        P_MESSAGE := V_CCS_MESSAGE;
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        P_MESSAGE := 'CCS提示：' || V_CCS_MESSAGE || v_Nl || SQLERRM;
    END;
      
  ----------------------------------------------------------------------
  PROCEDURE P_PG_VERIFICATION_REVOKE(IN_VERI_HEADER_ID IN NUMBER    --核销单ID
                                    ,IS_REVOKE_REASON  IN VARCHAR2  --撤回原因
                                    ,OS_MESSAGE        OUT VARCHAR2 --返回信息：OK表示成功，其它表示出错信息
                                     ) IS
    S_VERI_STATUS T_PG_VERI_HEADER.VERI_STATUS%TYPE;
  BEGIN
    OS_MESSAGE := 'OK';
    IF IN_VERI_HEADER_ID IS NULL THEN
      OS_MESSAGE := '输入参数核销单ID不能为空！';
    END IF;
    IF IS_REVOKE_REASON IS NULL THEN
      OS_MESSAGE := '输入参数撤回原因不能为空！';
    END IF;
    IF OS_MESSAGE = 'OK' THEN
      BEGIN
        SELECT H.VERI_STATUS
          INTO S_VERI_STATUS
          FROM T_PG_VERI_HEADER H
         WHERE H.VERI_HEADER_ID = IN_VERI_HEADER_ID
           FOR UPDATE NOWAIT;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          OS_MESSAGE := '锁定核销单不成功，请稍后再试！';
      END;
    END IF;
    IF OS_MESSAGE = 'OK' THEN
      --CIMS核销单‘已录入’、‘已驳回’状态才允许撤回
      IF S_VERI_STATUS = '0' OR S_VERI_STATUS = '6' THEN
        UPDATE T_PG_VERI_HEADER T
           SET T.VERI_STATUS      = '3'
              ,T.LAST_UPDATED_BY  = 'CCS'
              ,T.LAST_UPDATE_DATE = SYSDATE
              ,T.REVOKE_BY        = 'CCS'
              ,T.REVOKE_DATE      = SYSDATE
              ,T.REVOKE_MSG       = IS_REVOKE_REASON
              ,T.VERSION          = T.VERSION + 1
         WHERE T.VERI_HEADER_ID = IN_VERI_HEADER_ID;
         --COMMIT;
      ELSE
        OS_MESSAGE := 'CIMS核销单‘已录入’、‘已驳回’状态才允许撤回！'; 
      END IF;  
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      OS_MESSAGE := SQLERRM;
  END P_PG_VERIFICATION_REVOKE;
 ----------------------------------------------------------------------
  -- Author  : zhouly2
  -- Created : 2018/08/01
  -- Purpose : 工程机附件
  ----------------------------------------------------------------------
PROCEDURE P_PG_BUSINESS_FILE_TRANSFER(P_INTF_HEAD_ID IN NUMBER,
                                      V_SUCCESS      IN VARCHAR2,
                                      P_MESSAGE      IN OUT VARCHAR2,
                                      V_APPENDIX_ID  OUT VARCHAR2) IS
  R_BUSINESS_APPENDIX INTF_PG_BUSINESS_APPENDIX_CCS%ROWTYPE;
  --附件信息
  CURSOR C_PG_BUSINESS_APPENDIX IS
    SELECT *
      FROM INTF_PG_BUSINESS_APPENDIX_CCS IC
     WHERE IC.INTF_TABLE_ID = P_INTF_HEAD_ID;
  V_APPENDIX_COUNT NUMBER; --附件数量
  V_VALUE          VARCHAR2(100);
BEGIN
  --处理附件信息
  --查询附件接口表行数
  SELECT COUNT(*)
    INTO V_APPENDIX_COUNT
    FROM INTF_PG_BUSINESS_APPENDIX_CCS AC
   WHERE AC.INTF_TABLE_ID = P_INTF_HEAD_ID;
   V_APPENDIX_ID:=NULL;
  IF V_APPENDIX_COUNT > 0 THEN
    V_APPENDIX_ID := 'PGBUF' || S_PG_BUSINESS_APPENDIX_ID.NEXTVAL;
  
    OPEN C_PG_BUSINESS_APPENDIX;
    LOOP
      FETCH C_PG_BUSINESS_APPENDIX
        INTO R_BUSINESS_APPENDIX;
      EXIT WHEN C_PG_BUSINESS_APPENDIX%NOTFOUND OR P_MESSAGE <> V_SUCCESS;
    
      BEGIN
        V_VALUE := '同步商机登录附件信息到CIMS附件表：';
        INSERT INTO IMS_FILEINFO_INTERFACE
          (ID,
           BUSINESS_ID,
           BUSINESS_TYPE,
           FILE_PATH,
           FILE_NAME,
           CREATED_DATE)
        VALUES
          (SEQ_IMS_FILEINFO.NEXTVAL,
           V_APPENDIX_ID, --附件id
           'businessFile2', --附件code
           R_BUSINESS_APPENDIX.FILE_PATH,
           R_BUSINESS_APPENDIX.FILE_NAME,
           SYSDATE);
      EXCEPTION
        WHEN OTHERS THEN
          P_MESSAGE := V_VALUE || '出错。' || V_NL || SQLERRM;
      END;
    END LOOP;
  END IF;
END P_PG_BUSINESS_FILE_TRANSFER;

Procedure P_PG_BUSINESS_CCS_ADJUST(P_INTF_HEAD_ID IN NUMBER,P_MESSAGE OUT VARCHAR2) IS
  
  V_VALUE             VARCHAR2(1024);
  V_PG_PRODUCT_LINE   VARCHAR2(32);
  
  R_INTF_PG_BUSINESS_HEAD INTF_PG_BUSINESS%ROWTYPE;
  R_INTF_PG_BUSINESS_LINE INTF_PG_BUSINESS_LINE%ROWTYPE;
  R_INTF_PG_BUSINESS_APPROVAL INTF_PG_BUSINESS_APPROVAL%ROWTYPE;
  
  R_T_PG_BUSINESS T_PG_BUSINESS%ROWTYPE;
  
  v_count number;
  v_hq_bid_count number;
  
  --产品行数据
  CURSOR C_INTF_PG_BUSINESS_LINE IS
     SELECT * FROM INTF_PG_BUSINESS_LINE L WHERE L.HEAD_ID = P_INTF_HEAD_ID;
    
  --产品线数据
  CURSOR C_INTF_PG_BUSINESS_APPROVAL IS
     SELECT * FROM INTF_PG_BUSINESS_APPROVAL BA WHERE BA.INTF_HEAD_ID = P_INTF_HEAD_ID;
     
  V_PROJECT_CODE T_PG_BUSINESS.PROJECT_CODE%TYPE;
  V_BUSINESS_ID  T_PG_BUSINESS.BUSINESS_ID%TYPE;
  
  V_PROJECT_CODE_ADJUST T_PG_BUSINESS.PROJECT_CODE%TYPE;
    

  V_LOC_ID              T_PG_BUSINESS.LOC_ID%TYPE;
  V_LOC_NAME            T_PG_BUSINESS.LOC_NAME%TYPE;
  V_CUSTOMER_ID         T_PG_BUSINESS.CUSTOMER_ID%TYPE;
  V_CUSTOMER_NAME       T_PG_BUSINESS.CUSTOMER_NAME%TYPE;
  V_ACCOUNT_ID          T_PG_BUSINESS.ACCOUNT_ID%TYPE;
  V_ACCOUNT_CODE        T_PG_BUSINESS.ACCOUNT_CODE%TYPE;
  V_AGENT_ID            T_PG_BUSINESS.AGENT_ID%TYPE;
  V_AGENT_CODE          T_PG_BUSINESS.AGENT_CODE%TYPE;
  V_AGENT_NAME          T_PG_BUSINESS.AGENT_NAME%TYPE;
  V_SALES_CENTER_ID     T_PG_BUSINESS.SALES_CENTER_ID%TYPE;
  V_SALES_CENTER_NAME   T_PG_BUSINESS.SALES_CENTER_NAME%TYPE;
  V_PROJECT_CENTER_ID   T_PG_BUSINESS.PROJECT_CENTER_ID%TYPE;
  V_PROJECT_CENTER_NAME T_PG_BUSINESS.PROJECT_CENTER_NAME%TYPE;
  V_OTHER_LOGIN_FLAG    T_PG_BUSINESS.OTHERLOGIN_FLAG%TYPE;
  V_IS_GROUPBUY         T_PG_BUSINESS.IS_GROUPBUY%TYPE;
  V_GROUPBUY_SALES_TYPE T_PG_BUSINESS.GROUP_BUY_SALES_MAIN_TYPE%TYPE;
  V_BRAND               T_PG_BUSINESS.BRAND%TYPE;
  V_ENTITY_ID           T_PG_BUSINESS.ENTITY_ID%TYPE;
  V_BIZ_SUB_TYPE        T_PG_BUSINESS.BUSINESS_SUB_TYPE%TYPE;
    
  V_CCS_SALES_MAIN_TYPE INTF_PG_BUSINESS.CCS_SALES_MAIN_TYPE%TYPE;
  V_ORI_BUSINESS_ID    INTF_PG_BUSINESS.BUSINESS_ID%TYPE;
  V_ORI_BUSINESS_CODE  INTF_PG_BUSINESS.PROJECT_CODE%TYPE;
    
    
  V_BUSINESS_LINE_ID     T_PG_BUSINESS_LINE.BUSSINESS_LINE_ID%TYPE;
  V_ITEM_NAME            T_PG_BUSINESS_LINE.ITEM_DESC%TYPE;
  V_ITEM_ID              T_PG_BUSINESS_LINE.ITEM_ID%TYPE;
  V_SALES_MAIN_TYPE_CODE T_PG_BUSINESS_LINE.SALES_MAIN_TYPE%TYPE;
  V_SALES_MAIN_TYPE_NAME T_PG_BUSINESS_LINE.SALES_MAIN_TYPE_NAME%TYPE;
  V_SALES_SUB_TYPE_CODE  T_PG_BUSINESS_LINE.SALES_SUB_TYPE%TYPE;
  V_SALES_SUB_TYPE_NAME  T_PG_BUSINESS_LINE.SALES_SUB_TYPE_NAME%TYPE;
  V_UOM_CODE             T_PG_BUSINESS_LINE.UOM_CODE%TYPE;
  V_COMMON_PRICE         T_PG_BUSINESS_LINE.COMMON_PRICE%TYPE;
    
    
  V_BUSINESS_APPROVAL_ID T_PG_BUSINESS_APPROVAL.BUSINESS_AUDIT_ID%TYPE;
  V_PRODUCT_LINE_ID      T_PG_BUSINESS_APPROVAL.PRODUCTLINE_ID%TYPE;
  V_PRODUCT_LINE_NAME    T_PG_BUSINESS_APPROVAL.PRODUCTLINE_NAME%TYPE;
    
  V_TMP_COUNT            NUMBER;---记录行表更新受影响行数
  V_ACRONYM              VARCHAR2(50);
  V_ACRONYM_STR          VARCHAR2(50);
    
  V_BUSINESS_TYPE        T_PG_BUSINESS.BUSINESS_TYPE%TYPE;
  V_PROJECT_TYPE         T_PG_BUSINESS.PROJECT_TYPE%TYPE;
  V_GROUP_MARK           VARCHAR2(32);--团购标识，取系统参数
  V_IF_NEED_BIZ_SUB_TYPE VARCHAR2(32);
    
  V_LOGIN_TIME_COUNT     NUMBER;
  V_LOGIN_PROTECT_TIME   NUMBER;
  V_LOGIN_PROTECT_DATE   T_PG_BUSINESS.LOGIN_PTOTECT_TIME%TYPE;
  V_APPENDIX_ID VARCHAR2(100);--附件id
  
BEGIN
  P_MESSAGE := v_Success;
  
  BEGIN
    V_VALUE := 'ADJUST锁定接口表头表失败P_INTF_HEAD_ID = ' || P_INTF_HEAD_ID;
    SELECT *
      INTO R_INTF_PG_BUSINESS_HEAD
      FROM INTF_PG_BUSINESS B
     WHERE B.HEAD_ID = P_INTF_HEAD_ID
       FOR UPDATE NOWAIT;
    EXCEPTION 
      WHEN OTHERS THEN
        P_MESSAGE := V_VALUE || v_Nl ||SQLERRM;
        return;
  END;   

  --记录事务
  SAVEPOINT P_PG_BUSINESS_CCS_ADJUST;
  
  if nvl(R_INTF_PG_BUSINESS_HEAD.Is_Adjust,'N') != 'Y' then
    P_MESSAGE := '非调整的商机单据不允许使用该接口P_PG_BUSINESS_CCS_ADJUST';
    goto err_here;
  end if;
  
  --如果单号不为空，则属于更新操作
  if R_INTF_PG_BUSINESS_HEAD.Project_Code is not null then
     P_PG_BUSINESS_CCS(P_INTF_HEAD_ID, P_MESSAGE);
     return;
  end if;
  
  BEGIN
    V_VALUE := '获取原商机单据失败';
    
    --根据OLD_BUSINESS_ID读取原商机单据信息
    select * INTO R_T_PG_BUSINESS from T_PG_BUSINESS a where a.business_id = R_INTF_PG_BUSINESS_HEAD.Old_Business_Id;
    
    --校验原商机单据的状态是否已审批，如果不是，则提示未审批通过，不能调整
    if nvl(R_T_PG_BUSINESS.Status,'-1') <> '2' then
      P_MESSAGE := '商机未审批通过，不能调整，商机编号：' || R_T_PG_BUSINESS.PROJECT_CODE;
    end if;
    
    --校验原商机单据是否被未作废的价格申报或者价格批文引用过，如果有，则提示已经被引用，不能调整
    select count(*) into v_count from t_pg_price_apply_head a where a.project_code = R_T_PG_BUSINESS.PROJECT_CODE 
                                                                    and a.status != '3';
    if v_count > 0 then
      P_MESSAGE := '商机已经被价格申报引用，商机编号：' || R_T_PG_BUSINESS.PROJECT_CODE;
    end if;
    
    select count(*) into v_count from T_BD_PRICE_APPLY a where a.project_code = R_T_PG_BUSINESS.PROJECT_CODE 
                                                                    and a.apply_status != '00';
    if v_count > 0 then
      P_MESSAGE := '商机已经被价格批文引用，商机编号：' || R_T_PG_BUSINESS.PROJECT_CODE;
    end if;
    
    --校验原商机单据是否中标，如果有，则提示已经中标，不能调整
    if nvl(R_T_PG_BUSINESS.Bid_Status,'0') = '1' then
      P_MESSAGE := '商机处于中标状态，不能调整，商机编号：' || R_T_PG_BUSINESS.PROJECT_CODE;
    end if;
    
    --校验总部原商机单据是否中标，如果有，则提示已经中标，不能调整
    select count(*) into v_hq_bid_count from T_PG_BUSINESS a where a.ori_business_code = R_T_PG_BUSINESS.PROJECT_CODE and a.bid_status = '1';
    if v_hq_bid_count > 0 then
      P_MESSAGE := '商机处于中标状态，不能调整，商机编号：' || R_T_PG_BUSINESS.PROJECT_CODE;
    end if;
    
  EXCEPTION 
    WHEN OTHERS THEN
      P_MESSAGE := V_VALUE || v_Nl ||SQLERRM; 
  END;   
  if P_MESSAGE <> v_Success then goto err_here; end if;
  
  --将接口表数据转换成正式表数据
  V_IS_GROUPBUY := R_INTF_PG_BUSINESS_HEAD.IS_GROUPBUY;
       
  IF P_MESSAGE = v_Success THEN
    BEGIN
       V_VALUE := '校验来源系统：';
       IF NVL(R_INTF_PG_BUSINESS_HEAD.SOURCE_SYSTEM,'_') = '_' THEN
         RAISE V_CCS_EXCEPTION;
       END IF;
       EXCEPTION
          WHEN V_CCS_EXCEPTION THEN
            P_MESSAGE := V_VALUE || '未录入来源系统。'|| v_Nl || SQLERRM;
      END;
  END IF;	
        
  IF P_MESSAGE = v_Success THEN
    BEGIN
      V_VALUE := '校验来源项目编号：';
      IF NVL(R_INTF_PG_BUSINESS_HEAD.ORI_BUSINESS_CODE,'_') = '_' THEN
        RAISE V_CCS_EXCEPTION;
      END IF;
       EXCEPTION
        WHEN V_CCS_EXCEPTION THEN
         P_MESSAGE := V_VALUE || '未录入来源项目编号。'|| v_Nl || SQLERRM;
    END;
  END IF;
        
  IF P_MESSAGE = v_Success THEN
    BEGIN
      V_VALUE := '校验来源项目ID：';
      IF NVL(R_INTF_PG_BUSINESS_HEAD.ORI_BUSINESS_ID, 0) = 0 THEN
        RAISE V_CCS_EXCEPTION;
      END IF;
    EXCEPTION
      WHEN V_CCS_EXCEPTION THEN
        P_MESSAGE := V_VALUE || '未录入来源项目ID。'|| v_Nl || SQLERRM;
    END;
  END IF;
        
  IF P_MESSAGE = v_Success THEN
    BEGIN
      V_VALUE := '登陆类型：';
      IF NVL(R_INTF_PG_BUSINESS_HEAD.DOC_FLOW_TYPE, '_') = '_' THEN
        RAISE V_CCS_EXCEPTION;
      END IF;
    EXCEPTION
      WHEN V_CCS_EXCEPTION THEN
        P_MESSAGE := V_VALUE || '未录入登陆类型。'|| v_Nl || SQLERRM;
    END;
  END IF;
  IF P_MESSAGE = v_Success THEN
    V_BIZ_SUB_TYPE := R_INTF_PG_BUSINESS_HEAD.BUSINESS_SUB_TYPE;
    --查询是否需要商机小类
    BEGIN
      V_VALUE := '获取是否需要商机小类';
      PKG_BD.P_GET_PARAMETER_VALUE('PG_IF_NEED_BIZ_SUB_TYPE',
                                   R_INTF_PG_BUSINESS_HEAD.ENTITY_ID,
                                   Null,
                                   Null,
                                   V_IF_NEED_BIZ_SUB_TYPE);
    EXCEPTION
      WHEN OTHERS THEN
       P_MESSAGE := V_VALUE || '失败。' || v_Nl || SQLERRM;
    END;
  END IF;
         
  IF P_MESSAGE = v_Success AND V_IF_NEED_BIZ_SUB_TYPE = 'Y' THEN
    BEGIN
      V_VALUE := '校验商机小类';
      IF NVL(V_BIZ_SUB_TYPE, '_') = '_' THEN
        RAISE V_CCS_EXCEPTION;
      END IF;
    EXCEPTION
      WHEN V_CCS_EXCEPTION THEN
      P_MESSAGE := V_VALUE || '未录入商机小类。'|| v_Nl || SQLERRM;
    END;
  END IF;
         
           
  IF P_MESSAGE = v_Success THEN
    IF V_IS_GROUPBUY = '0' THEN
    --数据检查
      BEGIN
        V_VALUE := '检查项目区域：';
        SELECT TD.ROW_ID, TD.DISTRICT_NAME
          INTO V_LOC_ID, V_LOC_NAME
          FROM T_BD_DISTRICT TD
         WHERE TD.DISTRICT_CODE = R_INTF_PG_BUSINESS_HEAD.LOC_CODE
           AND TD.ACTIVE_FLAG = 'Y';
        EXCEPTION
          WHEN OTHERS THEN
            P_MESSAGE := V_VALUE || R_INTF_PG_BUSINESS_HEAD.LOC_CODE || '项目区域不存在或已失效。' || v_Nl ||SQLERRM;
      END;
    END IF;
  END IF;
        
        
  --工程类型转码
  IF P_MESSAGE = v_Success THEN
    BEGIN
      V_VALUE := '工程类型转码：';
      SELECT U.CODE_VALUE
        INTO V_PROJECT_TYPE
        FROM UP_CODELIST U
       WHERE U.CODE_VALUE = R_INTF_PG_BUSINESS_HEAD.PROJECT_TYPE
         AND U.CODETYPE = 'tpgProjectType';
    EXCEPTION
      WHEN OTHERS THEN
        P_MESSAGE := V_VALUE || '工程类型' || TO_CHAR(R_INTF_PG_BUSINESS_HEAD.PROJECT_TYPE) || '不存在或者已失效。';
    END;
  END IF;
  
  IF P_MESSAGE = v_Success THEN
    BEGIN
      V_VALUE := '检查经销商：';
      SELECT CH.CUSTOMER_ID, CH.CUSTOMER_NAME
        INTO V_CUSTOMER_ID, V_CUSTOMER_NAME
        FROM T_CUSTOMER_HEADER CH
       WHERE CH.CUSTOMER_CODE = R_INTF_PG_BUSINESS_HEAD.CUSTOMER_CODE
         AND CH.ACTIVE_FLAG = 'Active';
      EXCEPTION
        WHEN OTHERS THEN
          P_MESSAGE := V_VALUE || R_INTF_PG_BUSINESS_HEAD.CUSTOMER_CODE || '经销商不存在或已失效。' || v_Nl ||SQLERRM;
    END;
  END IF;
  /*BEGIN
     V_VALUE := '检查分销商：';
     IF NVL(R_INTF_PG_BUSINESS_HEAD.AGENT_CODE,'_') = '_' THEN
       RAISE V_CCS_EXCEPTION;
     END IF;
     EXCEPTION
      WHEN V_CCS_EXCEPTION THEN
       P_MESSAGE := V_VALUE || '未录入分销商信息。'|| v_Nl ||
                  SQLERRM;
  END;*/
        
  IF P_MESSAGE = v_Success THEN  
    BEGIN
      V_VALUE := '检查营销中心：';
      SELECT U.UNIT_ID, U.NAME
        INTO V_SALES_CENTER_ID, V_SALES_CENTER_NAME
        FROM UP_ORG_UNIT U
       WHERE U.CODE = R_INTF_PG_BUSINESS_HEAD.SALES_CENTER_CODE
         AND U.ENTITY_ID = R_INTF_PG_BUSINESS_HEAD.ENTITY_ID
         AND U.ACTIVE_FLAG = 'T';
      EXCEPTION
        WHEN OTHERS THEN
          P_MESSAGE := V_VALUE || R_INTF_PG_BUSINESS_HEAD.SALES_CENTER_CODE || '营销中心不存在或已失效。' || v_Nl ||SQLERRM;
    END;
  END IF;
       
  IF P_MESSAGE = v_Success THEN
   IF R_INTF_PG_BUSINESS_HEAD.LOGIN_PTOTECT_TIME IS NULL THEN
     BEGIN
       V_VALUE := '检查登陆保护日期：';
       SELECT COUNT(*)
         INTO V_LOGIN_TIME_COUNT
         FROM T_PG_LOGIN_PROTECT_TIME T
        WHERE T.ENTITY_ID = R_INTF_PG_BUSINESS_HEAD.ENTITY_ID
          AND T.SALES_CENTER_CODE =
              R_INTF_PG_BUSINESS_HEAD.SALES_CENTER_CODE;
               
       IF V_LOGIN_TIME_COUNT = 1 THEN
         SELECT T.LOGIN_PROTECT_TIME
           INTO V_LOGIN_PROTECT_TIME
           FROM T_PG_LOGIN_PROTECT_TIME T
          WHERE T.ENTITY_ID = R_INTF_PG_BUSINESS_HEAD.ENTITY_ID
            AND T.SALES_CENTER_CODE =
                R_INTF_PG_BUSINESS_HEAD.SALES_CENTER_CODE;
                  
          V_LOGIN_PROTECT_DATE := SYSDATE+V_LOGIN_PROTECT_TIME;
       ELSIF V_LOGIN_TIME_COUNT = 0 THEN
         V_LOGIN_PROTECT_DATE := add_months(sysdate - 1, 3);
       ELSIF V_LOGIN_TIME_COUNT > 1 THEN
          RAISE V_CCS_EXCEPTION;
       END IF;
      EXCEPTION
        WHEN V_CCS_EXCEPTION THEN
          P_MESSAGE := V_VALUE || '出错，请检查CIMS登陆保护日期配置。' || v_Nl ||SQLERRM;
        WHEN OTHERS THEN
          P_MESSAGE := V_VALUE || '出错，请检查CIMS登陆保护日期配置。' || v_Nl ||SQLERRM;
      END;
    ELSE 
      V_LOGIN_PROTECT_DATE := R_INTF_PG_BUSINESS_HEAD.LOGIN_PTOTECT_TIME;
    END IF;
  END IF;
        
  IF P_MESSAGE = v_Success THEN
    BEGIN
      V_VALUE := '检查账户：';
      SELECT VC.account_id,VC.account_code
        INTO V_ACCOUNT_ID,V_ACCOUNT_CODE
        FROM V_CUSTOMER_ACCOUNT_SALECENTER VC
       WHERE VC.entity_id = R_INTF_PG_BUSINESS_HEAD.ENTITY_ID
         AND VC.active_flag = 'Active'
         AND VC.orgActive_flag = 'Active'
         AND VC.account_status = '1'
         AND VC.sales_center_code =
             R_INTF_PG_BUSINESS_HEAD.SALES_CENTER_CODE
         AND VC.customer_code = R_INTF_PG_BUSINESS_HEAD.CUSTOMER_CODE;
       EXCEPTION
         WHEN OTHERS THEN
           P_MESSAGE := V_VALUE || R_INTF_PG_BUSINESS_HEAD.ACCOUNT_ID || '账户不存在或已失效。' || v_Nl || SQLERRM;
    END;
  END IF;      
         
  IF V_IS_GROUPBUY = '0' AND  P_MESSAGE = v_Success THEN
    BEGIN
       V_VALUE := '检查项目所在中心：';
      SELECT U.UNIT_ID, U.NAME
        INTO V_PROJECT_CENTER_ID, V_PROJECT_CENTER_NAME
        FROM UP_ORG_UNIT U
       WHERE U.CODE = R_INTF_PG_BUSINESS_HEAD.PROJECT_CENTER_CODE
         AND U.ENTITY_ID = R_INTF_PG_BUSINESS_HEAD.ENTITY_ID
         AND U.ACTIVE_FLAG = 'T';
       EXCEPTION
         WHEN OTHERS THEN
           P_MESSAGE := V_VALUE || R_INTF_PG_BUSINESS_HEAD.PROJECT_CENTER_CODE || '不存在或已失效。' || v_Nl ||SQLERRM;
    END;
  END IF;
         

         
  ------------检查品牌和大类--------------
  IF P_MESSAGE = v_Success THEN
    V_BRAND := R_INTF_PG_BUSINESS_HEAD.BRAND;
    V_CCS_SALES_MAIN_TYPE := R_INTF_PG_BUSINESS_HEAD.CCS_SALES_MAIN_TYPE;
    IF V_BRAND IS NOT NULL AND V_CCS_SALES_MAIN_TYPE IS NOT NULL THEN
     --转换为CIMS大类
     BEGIN
       V_VALUE := '转换CIMS大类，';
       SELECT R.SC_ITEM_CLASS_CODE
         INTO V_GROUPBUY_SALES_TYPE
         FROM T_BD_ITEM_CLASS_RELATION R
       WHERE R.HQ_ITEM_CLASS_CODE = V_CCS_SALES_MAIN_TYPE
         AND R.HQ_ITEM_BRAND = V_BRAND;
       EXCEPTION
       WHEN OTHERS THEN
         P_MESSAGE := V_VALUE || '大类：' || V_CCS_SALES_MAIN_TYPE || '品牌：'|| V_BRAND || '失败，请检查CIMS与CCS大类对应关系。' || v_Nl ||SQLERRM;
     END;
    END IF;
  END IF;
         
         
         
  IF P_MESSAGE = v_Success THEN
    --查询系统参数
    BEGIN
      V_VALUE := '获取主体参数';
      PKG_BD.P_GET_PARAMETER_VALUE('PG_PRODUCT_LINE',
                                   R_INTF_PG_BUSINESS_HEAD.ENTITY_ID,
                                   Null,
                                   Null,
                                   V_PG_PRODUCT_LINE);
    EXCEPTION
     WHEN OTHERS THEN
       P_MESSAGE := V_VALUE || '失败。' || v_Nl || SQLERRM;
    END;
  END IF;
        
  IF P_MESSAGE = v_Success THEN
    --取团购标识
    BEGIN
     V_VALUE := '查询团购标识：';
     PKG_BD.P_GET_PARAMETER_VALUE('PG_GROUP_BUY_MARK',
                                   R_INTF_PG_BUSINESS_HEAD.ENTITY_ID,
                                   Null,
                                   Null,
                                   V_GROUP_MARK);
    EXCEPTION
     WHEN OTHERS THEN
       P_MESSAGE := V_VALUE || '出错。' || v_Nl || SQLERRM;
    END;
  END IF;
         
  IF P_MESSAGE = v_Success  THEN
    --判断是否异地登陆
    IF R_INTF_PG_BUSINESS_HEAD.SALES_CENTER_CODE = R_INTF_PG_BUSINESS_HEAD.PROJECT_CENTER_CODE THEN
      V_OTHER_LOGIN_FLAG := 'N';
      V_BUSINESS_TYPE := '0';
    ELSE
      V_OTHER_LOGIN_FLAG := 'Y';
      V_BUSINESS_TYPE := '1';
    END IF;
                 
    IF V_IS_GROUPBUY = '1' AND V_GROUP_MARK = 'Y' THEN
     V_BUSINESS_TYPE := '3';
    END IF;
  END IF;
    
  IF V_IS_GROUPBUY = '1' AND V_GROUP_MARK = 'Y' AND  P_MESSAGE = v_Success  THEN
    BEGIN
     V_VALUE := '检查项目安装涉及区域：';
     IF R_INTF_PG_BUSINESS_HEAD.REFER_AREA_ID IS NULL OR R_INTF_PG_BUSINESS_HEAD.REFER_AREA IS NULL THEN
        RAISE V_CCS_EXCEPTION;
     END IF;
    EXCEPTION
     WHEN V_CCS_EXCEPTION THEN
       P_MESSAGE := V_VALUE || '未录入。'|| v_Nl || SQLERRM;
    END;
  END IF;
         
  ---头表
  IF P_MESSAGE =  v_Success THEN              
    
    SELECT S_PG_BUSINESS.NEXTVAL INTO V_BUSINESS_ID FROM DUAL;
    --营销中心简称
    SELECT T.EXT_TEXTBOX
     INTO V_ACRONYM
     FROM UP_ORG_UNIT_EXT T
    WHERE T.ID IN
          (SELECT U.ID
             FROM UP_ORG_UNIT U
            WHERE U.CODE =
                  R_INTF_PG_BUSINESS_HEAD.SALES_CENTER_CODE);
    --新单据取原单据的编码
    V_PROJECT_CODE := R_T_PG_BUSINESS.PROJECT_CODE;
    
    --生成商机调整记录单号
    pkg_bd.P_GET_BILL_NO('tpgProjectCodeAdjust',V_PROJECT_CODE,R_T_PG_BUSINESS.ENTITY_ID,null,V_PROJECT_CODE_ADJUST);
    
    --更新原商机单数据
    UPDATE T_PG_BUSINESS a
       SET a.project_code = V_PROJECT_CODE_ADJUST,a.DOCUMENT_TYPE = '1',a.status = '10'
     WHERE a.business_id = R_T_PG_BUSINESS.BUSINESS_ID;
    --更新原商机单对应的接口表数据
    UPDATE INTF_PG_BUSINESS a
       SET a.project_code = V_PROJECT_CODE_ADJUST
     WHERE a.business_id = R_T_PG_BUSINESS.BUSINESS_ID;
     
    --同步附件信息;
    V_APPENDIX_ID:=NULL;
    PKG_PG_INTF.P_PG_BUSINESS_FILE_TRANSFER(P_INTF_HEAD_ID => P_INTF_HEAD_ID,
                                                          V_SUCCESS =>V_SUCCESS,
                                                          P_MESSAGE =>P_MESSAGE,
                                                          V_APPENDIX_ID =>V_APPENDIX_ID );	
  	
    if P_MESSAGE <> v_Success then goto err_here; end if;      
    ----新增操作
    BEGIN
      V_VALUE := '插入正式表头表';
      INSERT INTO T_PG_BUSINESS
        (business_id, --商机信息ID
         project_code, --项目编号
         project_name, --项目名称
         user_firm, --使用单位名称
         user_phone, --项目方联系电话
         user_name, --项目方联系人
         project_address, --工程项目详细地址
         loc_id, --区域ID
         loc_code, --项目所在区域
         loc_name, --区域编码名称
         project_center_id, --项目所在中心ID
         project_center_code, --项目所在中心编码
         project_center_name, --项目所在中心名称
         customer_id, --经销商ID
         customer_code, --经销商编码
         customer_name, --经销商名称
         sales_center_id, --营销中心ID
         sales_center_name, --营销中心名称
         sales_center_code, --营销中心编码
         account_id, --账户ID
         account_code,          --账户名称
         agent_id, --经销商ID
         agent_code, --经销商编码
         agent_name, --经销商名称
         project_type, --工程类型:精装房产配套、公租保障配套、家装橱柜配套、燃气公司合作
         expected_bid_time, --预计投标时间
         login_time, --登录日期
         login_ptotect_time, --登录保护时间
         project_num, --项目规模
         project_progress, --项目进度:在建项目、建好未定、准备投标
         business_type, --商机类型
         delivery_cycle, --供货周期:单位为天
         buyout_type, --买断类型:事前买断、时候买断
         customer_person,       --经销商联系人
         customer_person_phone, --联系方式
         area_manager,          --区域经理
         area_manager_phone,    --区域经理电话
         install_flag, --是否我司安装
         otherlogin_flag, --是否是异地登录
         status, --登录状态，有以下几种：已录入、已送审、已审核、已退回、已作废
         --  competitors,           --工程竞争对手
         special_need, --特殊要求
         other_desc, --其他说明资料
         entity_id, --主体ID
         created_by, --创建人
         creation_date, --创建时间
         last_updated_by, --修改人
         last_update_date, --修改时间
         --send_person,           --送审人
         --send_date,             --送审日期
         --approval_person,       --审核人
         --approval_date,         --审核日期
         --back_person,           --退回人
         --back_date,             --退回日期
         --scrapped_person,       --作废人
         --scrapped_date,         --作废时间
         --relogin_flag,          --重新登录标识
         bid_status, --中标状态
         --freeze_status,         --冻结状态
         --freeze_person,         --冻结人
         --freeze_time,           --冻结时间
         --unfreeze_person,       --解冻人
         --unfreeze_time,         --解冻时间
         --is_market_strategy,    --战略大盘采购
         --verfication_status,    --核销状态 0未核销 1已核销 2核销失败
         --remark,                --备注
         is_groupbuy,           --是否团购
         --program_updated_by,    --程序修改来源
         program_update_date, --修改时间
         ori_business_id, --上级项目ID
         ori_business_code, --上级项目编码
         trade,--所属行业
         brand,--品牌
         category,--品类
         customer_fax,--经销商传真电话
         follow_man,--分部业务员
         follower_telephone,--分部业务员电话
         main_material,--涉及机型
         query_keywords,--查询关键字
         stat_keywords,--统计关键字
         tg_commissioner,--团购专员
         tg_commi_phone,--团购专员电话
         refer_area_id,--安装涉及区域ID
         refer_area,--安装涉及区域
         deal_start_date,--登录开始日期
         deal_end_date,--登录结束日期
         group_buy_sales_main_type,--营销大类
         source_system,
         business_sub_type
          ,APPENDIX_ID2
       --   ,SOURCE_BUSINESS_ID --来源总工程id
        --  ,IS_OPEN --是否开户
        --  ,SOURCE_CUSTOMER_CODE --来源客户编码
        --  ,SOURCE_CUSTOMER_NAME --来源客户名称
          ,DOCUMENT_TYPE    --资料类型
          ,is_adjust         --是否调整
          ,big_panel
          )
      Values
        (V_BUSINESS_ID, --商机信息ID
         V_PROJECT_CODE, --项目编号
         R_INTF_PG_BUSINESS_HEAD.PROJECT_NAME, --项目名称
         R_INTF_PG_BUSINESS_HEAD.USER_FIRM, --使用单位名称
         R_INTF_PG_BUSINESS_HEAD.USER_PHONE, --项目方联系电话
         R_INTF_PG_BUSINESS_HEAD.USER_NAME, --项目方联系人
         R_INTF_PG_BUSINESS_HEAD.PROJECT_ADDRESS, --工程项目详细地址
         V_LOC_ID, --区域ID
         R_INTF_PG_BUSINESS_HEAD.LOC_CODE, --项目所在区域
         V_LOC_NAME, --区域编码名称
         V_PROJECT_CENTER_ID, --项目所在中心ID
         R_INTF_PG_BUSINESS_HEAD.PROJECT_CENTER_CODE, --项目所在中心编码
         V_PROJECT_CENTER_NAME, --项目所在中心名称
         V_CUSTOMER_ID,
         R_INTF_PG_BUSINESS_HEAD.CUSTOMER_CODE,
         V_CUSTOMER_NAME,
         V_SALES_CENTER_ID, --营销中心ID
         V_SALES_CENTER_NAME, --营销中心名称
         R_INTF_PG_BUSINESS_HEAD.SALES_CENTER_CODE, --营销中心编码
         V_ACCOUNT_ID, --账户ID
         V_ACCOUNT_CODE,                      --账户名称
         R_INTF_PG_BUSINESS_HEAD.AGENT_ID, --经销商ID
         R_INTF_PG_BUSINESS_HEAD.AGENT_CODE, --经销商编码
         R_INTF_PG_BUSINESS_HEAD.AGENT_NAME, --经销商名称
         V_PROJECT_TYPE,
         R_T_PG_BUSINESS.Expected_Bid_Time, --v_Expected_Bid_Time,--预计投标时间
         R_T_PG_BUSINESS.Login_Time,--trunc(sysdate),--登录日期
         V_LOGIN_PROTECT_DATE,--add_months(sysdate - 1, 3), --登录保护时间
         R_INTF_PG_BUSINESS_HEAD.PROJECT_NUM, --项目规模
         R_INTF_PG_BUSINESS_HEAD.PROJECT_PROGRESS, --项目进度:在建项目、建好未定、准备投标
         V_BUSINESS_TYPE, --存在问题，先置为0
         R_INTF_PG_BUSINESS_HEAD.DELIVERY_CYCLE, --供货周期:单位为天
         R_INTF_PG_BUSINESS_HEAD.BUYOUT_TYPE, --买断类型:事前买断、时候买断
         R_INTF_PG_BUSINESS_HEAD.CUSTOMER_PERSON,           --经销商联系人
         R_INTF_PG_BUSINESS_HEAD.CUSTOMER_PERSON_PHONE,     --联系方式
         R_INTF_PG_BUSINESS_HEAD.AREA_MANAGER,            --区域经理
         R_INTF_PG_BUSINESS_HEAD.AREA_MANAGER_PHONE,    --区域经理电话
         R_INTF_PG_BUSINESS_HEAD.INSTALL_FLAG, --是否我司安装
         V_OTHER_LOGIN_FLAG, --是否是异地登录
         '0', --登录状态:已审核
         --   R_INTF_PG_BUSINESS_HEAD.Main_Material,         --工程竞争对手
         R_INTF_PG_BUSINESS_HEAD.SPECIAL_NEED, --特殊要求
         R_INTF_PG_BUSINESS_HEAD.OTHER_DESC, --其他说明资料
         R_INTF_PG_BUSINESS_HEAD.ENTITY_ID, --主体ID
         'CCS', --创建人
         sysdate,
         --to_date(sysdate,'yyyy-MM-dd HH24:mi:ss'), --创建时间
         R_INTF_PG_BUSINESS_HEAD.LAST_UPDATED_BY, --修改人
         R_INTF_PG_BUSINESS_HEAD.LAST_UPDATE_DATE, --修改时间
         -- r_Pg_Business.To_Checkup_By_Name,    --送审人
         -- r_Pg_Business.To_Checkup_Date,       --送审日期
         -- r_Pg_Business.Checkup_By_Name,       --审核人
         -- r_Pg_Business.Checkup_Date,          --审核日期
         -- r_Pg_Business.Back_By_Name,          --退回人
         -- r_Pg_Business.Back_Date,             --退回日期
         --- r_Pg_Business.Back_By,               --作废人
         -- r_Pg_Business.Reject_Date,           --作废时间
         --r_Pg_Business.Relogin_Flag,          --重新登录标识
         '0', --中标状态
         --r_Pg_Business.Freeze_Status,         --冻结状态
         --r_Pg_Business.Freeze_Person,         --冻结人
         --r_Pg_Business.Freeze_Time,           --冻结时间
         --r_Pg_Business.Unfreeze_Person,       --解冻人
         --r_Pg_Business.Unfreeze_Time,         --解冻时间
         --r_Pg_Business.Is_Market_StLrategy,    --战略大盘采购
         --r_Pg_Business.Verfication_Status,    --核销状态 0未核销 1已核销 2核销失败
         --r_Pg_Business.Remark,                --备注
         R_INTF_PG_BUSINESS_HEAD.IS_GROUPBUY,           --是否团购
         --r_Pg_Business.Program_Updated_By,    --程序修改来源
         sysdate,
         --to_date(sysdate,'yyyy-MM-dd HH24:mi:ss'), --修改时间
         R_INTF_PG_BUSINESS_HEAD.ORI_BUSINESS_ID, --上级项目ID
         R_INTF_PG_BUSINESS_HEAD.ORI_BUSINESS_CODE, --上级项目编码
         R_INTF_PG_BUSINESS_HEAD.TRADE, ----所属行业
         R_INTF_PG_BUSINESS_HEAD.BRAND, ----品牌
         R_INTF_PG_BUSINESS_HEAD.CATEGORY, ----品类
         R_INTF_PG_BUSINESS_HEAD.CUSTOMER_FAX, ----经销商传真电话
         R_INTF_PG_BUSINESS_HEAD.FOLLOW_MAN, ----分部业务员
         R_INTF_PG_BUSINESS_HEAD.FOLLOWER_TELEPHONE, ----分部业务员电话
         R_INTF_PG_BUSINESS_HEAD.MAIN_MATERIAL, ----涉及机型
         R_INTF_PG_BUSINESS_HEAD.QUERY_KEYWORDS, ----查询关键字
         R_INTF_PG_BUSINESS_HEAD.STAT_KEYWORDS, ----统计关键字
         R_INTF_PG_BUSINESS_HEAD.TG_COMMISSIONER, ----团购专员
         R_INTF_PG_BUSINESS_HEAD.TG_COMMI_PHONE, ----团购专员电话
         R_INTF_PG_BUSINESS_HEAD.REFER_AREA_ID, ----安装涉及区域ID
         R_INTF_PG_BUSINESS_HEAD.REFER_AREA, ----安装涉及区域
         R_INTF_PG_BUSINESS_HEAD.DEAL_START_DATE, ----登录开始日期
         R_INTF_PG_BUSINESS_HEAD.DEAL_END_DATE, ----登录结束日期
         V_GROUPBUY_SALES_TYPE, ----营销大类
         R_INTF_PG_BUSINESS_HEAD.SOURCE_SYSTEM ,
         R_INTF_PG_BUSINESS_HEAD.BUSINESS_SUB_TYPE,
         V_APPENDIX_ID
       --  ,R_INTF_PG_BUSINESS_HEAD.SOURCE_BUSINESS_ID --来源总工程id
        -- ,R_INTF_PG_BUSINESS_HEAD.IS_OPEN --是否开户
       --  ,R_INTF_PG_BUSINESS_HEAD.SOURCE_CUSTOMER_CODE --来源客户编码
       --  ,R_INTF_PG_BUSINESS_HEAD.SOURCE_CUSTOMER_NAME --来源客户名称
         ,'2'    --资料类型
         ,R_INTF_PG_BUSINESS_HEAD.Is_Adjust
         ,R_INTF_PG_BUSINESS_HEAD.Big_Panel
          );
    EXCEPTION
      WHEN OTHERS THEN
        P_MESSAGE := V_VALUE || '出错。' || v_Nl || SQLERRM;
    END;
  END IF;
           
  IF P_MESSAGE = v_Success  THEN
    IF V_PG_PRODUCT_LINE = 'N'THEN
      OPEN C_INTF_PG_BUSINESS_LINE;
      LOOP 
        FETCH C_INTF_PG_BUSINESS_LINE
        INTO R_INTF_PG_BUSINESS_LINE;
        EXIT WHEN C_INTF_PG_BUSINESS_LINE%NOTFOUND OR P_MESSAGE <> v_Success;
                   
        BEGIN
          V_VALUE := '查询产品营销大类、小类编码：';
          SELECT TI.SALES_MAIN_TYPE, TI.SALES_SUB_TYPE
            INTO V_SALES_MAIN_TYPE_CODE, V_SALES_SUB_TYPE_CODE
            FROM T_BD_ITEM TI
           WHERE TI.ITEM_CODE = R_INTF_PG_BUSINESS_LINE.ITEM_CODE
             AND TI.ENTITY_ID = R_INTF_PG_BUSINESS_HEAD.ENTITY_ID;
          EXCEPTION
             WHEN OTHERS THEN
               P_MESSAGE := V_VALUE || R_INTF_PG_BUSINESS_LINE.ITEM_CODE || '失败。' || v_Nl || SQLERRM;
        END;
        if P_MESSAGE <> v_Success then goto err_here; end if;
                    
        BEGIN
          V_VALUE := '查询产品营销大类名称：';
          SELECT TC.CLASS_NAME
            INTO V_SALES_MAIN_TYPE_NAME
            FROM T_BD_ITEM_CLASS TC
           WHERE TC.CLASS_CODE = V_SALES_MAIN_TYPE_CODE
             AND TC.ENTITY_ID = R_INTF_PG_BUSINESS_HEAD.ENTITY_ID
             AND TC.ACTIVE_FLAG = 'Y';
        EXCEPTION
          WHEN OTHERS THEN
            P_MESSAGE := V_VALUE || R_INTF_PG_BUSINESS_LINE.ITEM_CODE || '失败。' || v_Nl || SQLERRM;
        END;
                    
        BEGIN
          V_VALUE := '查询产品营销小类名称：';
          SELECT TC.CLASS_NAME
            INTO V_SALES_SUB_TYPE_NAME
            FROM T_BD_ITEM_CLASS TC
           WHERE TC.CLASS_CODE = V_SALES_SUB_TYPE_CODE
             AND TC.ENTITY_ID = R_INTF_PG_BUSINESS_HEAD.ENTITY_ID
             AND TC.ACTIVE_FLAG = 'Y';
        EXCEPTION
          WHEN OTHERS THEN
            P_MESSAGE := V_VALUE || R_INTF_PG_BUSINESS_LINE.ITEM_CODE || '失败。' || v_Nl || SQLERRM;
        END;
        --检查直供价
        /*IF R_INTF_PG_BUSINESS_HEAD.Is_Open='Y' AND R_INTF_PG_BUSINESS_LINE.Common_Price ='' THEN
           P_MESSAGE :=  R_INTF_PG_BUSINESS_LINE.ITEM_CODE ||'已开户直供价不能为空';                 
        END IF;*/
        --校验行数据
        BEGIN
          V_VALUE := '校验产品信息：';
          SELECT TI.ITEM_ID, TI.ITEM_NAME, TI.DEFAULTUNIT
               INTO V_ITEM_ID, V_ITEM_NAME, V_UOM_CODE
               FROM T_BD_ITEM TI
              WHERE TI.ENTITY_ID = R_INTF_PG_BUSINESS_HEAD.ENTITY_ID
                AND TI.SALES_MAIN_TYPE = V_SALES_MAIN_TYPE_CODE
                AND TI.ACTIVE_FLAG = 'Y'
                AND TI.ITEM_CODE = R_INTF_PG_BUSINESS_LINE.ITEM_CODE;
           EXCEPTION
             WHEN OTHERS THEN
               P_MESSAGE := V_VALUE || R_INTF_PG_BUSINESS_LINE.ITEM_CODE || '失败。' || v_Nl || SQLERRM;
        END;
        if P_MESSAGE <> v_Success then goto err_here; end if;
                    
        IF P_MESSAGE = v_Success THEN
          BEGIN
            V_VALUE := '插入行表数据：';
                          
            ---序列
            SELECT S_PG_BUSINESS_LINE.NEXTVAL
              INTO V_BUSINESS_LINE_ID
              FROM DUAL;
                          
            Insert Into T_PG_BUSINESS_LINE
              (bussiness_line_id, --商机商品行信息ID
               business_id, --商机信息ID
               sales_main_type, --营销大类编码
               sales_main_type_name, --营销大类名称
               sales_sub_type, --营销小类编码
               sales_sub_type_name, --营销小类名称
               item_id, --产品ID
               item_code, --产品编码
               item_desc, --产品型号
               uom_code, --单位
               common_price, --直供价
               requis_price, --预计报价
               requis_qty, --申请数量
               created_by, --创建人
               creation_date, --创建时间
               last_updated_by, --修改人
               last_update_date, --修改时间
               entity_id --主体ID
               )
            Values
              (V_BUSINESS_LINE_ID, --商机商品行信息ID
               V_BUSINESS_ID, --商机信息ID
               V_SALES_MAIN_TYPE_CODE, --营销大类编码
               V_SALES_MAIN_TYPE_NAME, --营销大类名称
               V_SALES_SUB_TYPE_CODE, --营销小类编码
               V_SALES_SUB_TYPE_NAME, --营销小类名称
               V_ITEM_ID, --产品ID
               R_INTF_PG_BUSINESS_LINE.ITEM_CODE, --产品编码
               V_ITEM_NAME, --产品型号
               V_UOM_CODE, --单位
               R_INTF_PG_BUSINESS_LINE.COMMON_PRICE, --直供价
               R_INTF_PG_BUSINESS_LINE.REQUIS_PRICE, --预计报价
               R_INTF_PG_BUSINESS_LINE.REQUIS_QTY, --申请数量
               'CCS', --创建人
               sysdate,--to_date(sysdate,'yyyy-MM-dd HH24:mi:ss'), --创建时间
               'CCS', --修改人
               sysdate,--to_date(sysdate,'yyyy-MM-dd HH24:mi:ss'), --修改时间
               R_INTF_PG_BUSINESS_HEAD.ENTITY_ID --主体ID
               );

          EXCEPTION
            WHEN OTHERS THEN
              P_MESSAGE := V_VALUE || '失败。' || v_Nl || SQLERRM;
          END;
        END IF;
      END LOOP;
    ELSIF V_PG_PRODUCT_LINE = 'Y'THEN
      OPEN C_INTF_PG_BUSINESS_APPROVAL;
      LOOP 
        FETCH C_INTF_PG_BUSINESS_APPROVAL
        INTO R_INTF_PG_BUSINESS_APPROVAL;
        EXIT WHEN C_INTF_PG_BUSINESS_APPROVAL%NOTFOUND OR P_MESSAGE <> v_Success;
                          
        --校验行数据
        BEGIN
          V_VALUE := '校验产品线信息：';
          SELECT TPL.PRODUCTLINE_ID, TPL.PRODUCTLINE_NAME
            INTO V_PRODUCT_LINE_ID, V_PRODUCT_LINE_NAME
            FROM T_PG_PRODUCT_LINE TPL
           WHERE TPL.PRODUCTLINE_CODE =
                 R_INTF_PG_BUSINESS_APPROVAL.PRODUCTLINE_CODE
             AND TPL.ENTITY_ID =
                 R_INTF_PG_BUSINESS_APPROVAL.ENTITY_ID;
        EXCEPTION
          WHEN OTHERS THEN
             P_MESSAGE := V_VALUE || '失败。' || v_Nl || SQLERRM;
        END;                       
                           
        IF P_MESSAGE = v_Success THEN
          BEGIN
            V_VALUE := '开始插入行表数据：';
                                              
            ---序列
            SELECT S_PG_BUSINESS_APPROVAL.NEXTVAL INTO V_BUSINESS_LINE_ID  FROM DUAL;
                                              
            Insert Into T_Pg_Business_Approval
            (business_audit_id,                      --产品线登录行ID
             business_id,                            --商机信息ID
             productline_id,                         --产品线ID
             productline_code,                       --产品线编码
             productline_name,                       --产品线名称
             creation_date,                          --创建时间
             last_update_date,                       --修改时间
             entity_id,                              --主体ID
             created_by,
             last_updated_by
            )
            Values
            (V_BUSINESS_LINE_ID, --商机商品行信息ID
             V_BUSINESS_ID, --商机信息ID
             V_PRODUCT_LINE_ID, --产品线ID
             R_INTF_PG_BUSINESS_APPROVAL.PRODUCTLINE_CODE,--产品线编码
             V_PRODUCT_LINE_NAME,  --产品线名称
             sysdate,--to_date(sysdate,'yyyy-MM-dd HH24:mi:ss'),--创建时间
             sysdate,--to_date(sysdate,'yyyy-MM-dd HH24:mi:ss'),--修改时间
             R_INTF_PG_BUSINESS_HEAD.ENTITY_ID,--主体ID
             'CCS',
             'CCS'
            );
          EXCEPTION
            WHEN OTHERS THEN
              P_MESSAGE := V_VALUE || '失败。' || v_Nl || SQLERRM;
          END;
          END IF;
      END LOOP; 
    END IF;
  END IF; 

 
  <<err_here>>
  ----更新状态
  IF P_MESSAGE <> v_Success THEN
    --回滚事务
    ROLLBACK TO SAVEPOINT P_PG_BUSINESS_CCS_ADJUST;
    UPDATE INTF_PG_BUSINESS B
       SET B.INTF_STATUS  = 'E',
           B.INTF_ERR_MSG  = P_MESSAGE--,
          -- B.BUSINESS_ID  = V_BUSINESS_ID,
          -- B.PROJECT_CODE = V_PROJECT_CODE
     WHERE B.HEAD_ID = P_INTF_HEAD_ID;
  ELSE
     UPDATE INTF_PG_BUSINESS B
       SET B.INTF_STATUS  = 'S',
           B.INTF_ERR_MSG  = P_MESSAGE,
           B.BUSINESS_ID  = V_BUSINESS_ID,
           B.PROJECT_CODE = V_PROJECT_CODE
     WHERE B.HEAD_ID = P_INTF_HEAD_ID;
  End IF;     
END;

Procedure P_PG_BUSINESS_CCS_ADJ_VERIFY(P_INTF_HEAD_ID IN NUMBER,P_RESULT OUT VARCHAR2) IS
  
  V_VALUE             VARCHAR2(1024); 
  R_INTF_PG_BUSINESS_HEAD INTF_PG_BUSINESS%ROWTYPE;
  R_T_PG_BUSINESS T_PG_BUSINESS%ROWTYPE;
  v_count number;
  v_hq_bid_count number;

BEGIN
  P_RESULT := v_Success;
  
  BEGIN
    V_VALUE := 'ADJ_VERIFY查询商机接口表失败P_INTF_HEAD_ID = ' || P_INTF_HEAD_ID;
    SELECT *
      INTO R_INTF_PG_BUSINESS_HEAD
      FROM INTF_PG_BUSINESS B
     WHERE B.HEAD_ID = P_INTF_HEAD_ID;
    EXCEPTION 
      WHEN OTHERS THEN
        P_RESULT := V_VALUE || v_Nl ||SQLERRM;
        return;
  END;   
  
  BEGIN
    V_VALUE := '获取商机单据失败';
    
    --根据OLD_BUSINESS_ID读取原商机单据信息
    select * INTO R_T_PG_BUSINESS from T_PG_BUSINESS a where a.business_id = R_INTF_PG_BUSINESS_HEAD.BUSINESS_ID;
    
    --校验原商机单据的状态是否已审批，如果不是，则提示未审批通过，不能调整
    if nvl(R_T_PG_BUSINESS.Status,'-1') <> '2' then
      P_RESULT := '商机未审批通过，不能调整，商机编号：' || R_T_PG_BUSINESS.PROJECT_CODE;
      return;
    end if;
    
    --校验原商机单据是否被未作废的价格申报或者价格批文引用过，如果有，则提示已经被引用，不能调整
    select count(*) into v_count from t_pg_price_apply_head a where a.project_code = R_T_PG_BUSINESS.PROJECT_CODE 
                                                                    and a.status != '3';
    if v_count > 0 then
      P_RESULT := '商机已经被价格申报引用，商机编号：' || R_T_PG_BUSINESS.PROJECT_CODE;
      return;
    end if;
    
    select count(*) into v_count from T_BD_PRICE_APPLY a where a.project_code = R_T_PG_BUSINESS.PROJECT_CODE 
                                                                    and a.apply_status != '00';
    if v_count > 0 then
      P_RESULT := '商机已经被价格批文引用，商机编号：' || R_T_PG_BUSINESS.PROJECT_CODE;
      return;
    end if;
    
    --校验原商机单据是否中标，如果有，则提示已经中标，不能调整
    if nvl(R_T_PG_BUSINESS.Bid_Status,'0') = '1' then
      P_RESULT := '商机处于中标状态，不能调整，商机编号：' || R_T_PG_BUSINESS.PROJECT_CODE;
      return;
    end if;
    
    --校验总部原商机单据是否中标，如果有，则提示已经中标，不能调整
    select count(*) into v_hq_bid_count from T_PG_BUSINESS a where a.ori_business_code = R_T_PG_BUSINESS.PROJECT_CODE and a.bid_status = '1';
    if v_hq_bid_count > 0 then
      P_RESULT := '商机处于中标状态，不能调整，商机编号：' || R_T_PG_BUSINESS.PROJECT_CODE;
      return;
    end if;
    
  EXCEPTION 
    WHEN OTHERS THEN
      P_RESULT := V_VALUE || v_Nl ||SQLERRM; 
  END;
END;
  
END PKG_PG_INTF;
/

