create PACKAGE BODY PKG_POL_RPT AS
  ----------------------------------------------------------------------
  --  author:梁颜明 中心本年返利计提报表
  --之所以使用存储过程，是因为rdx报表不支持解释带有with等的复杂SQL
  ----------------------------------------------------------------------
  FUNCTION ORDER_CLS_AMOUNT(IN_ENTITY_ID         IN NUMBER,
                            IS_YEAR_CODE         IN VARCHAR2,
                            IN_SALES_CENTER_ID   IN NUMBER,
                            IS_SALES_CENTER_CODE IN VARCHAR2,
                            IS_SALES_CENTER_NAME IN VARCHAR2,
                            IS_USER_CODE         IN VARCHAR2)
    RETURN TAB_POL_ORDER_CLS_AMOUNT
    PIPELINED IS
    v OBJ_POL_ORDER_CLS_AMOUNT;
  BEGIN
    for thisrow in (with nt as--十二个月的数字
                       (SELECT REGEXP_SUBSTR(T.C, '[^,]{1,}', 1, LEVEL) AS LI
                         FROM (SELECT '0,1,2,3,4,5,6,7,8,9,10,11' C FROM DUAL) T
                       CONNECT BY LEVEL <=
                                  (1 +
                                  LENGTH(REGEXP_REPLACE(T.C, '[^,]', '')))
                        ORDER BY LEVEL),
                      mt as--某年每月1号的时间
                       (select nt.li,
                              add_months(to_date(IS_YEAR_CODE || '01',
                                                 'YYYYMM'),
                                         nt.li) as ym
                         from dual
                        inner join nt
                           on (1 = 1)),
                      dt as--统计各中心各月的申请金额、回收金额
                       (select oh.entity_id,
                              oh.sales_center_id,
                              trunc(oh.order_date, 'mm') as order_date,
                              sum((case
                                    when oh.discount_pay_dept <> '1' then
                                     oh.policy_amount
                                    else
                                     0
                                  end)) as total_policy_amount,
                              sum((case
                                    when oh.discount_pay_dept <> '1' then
                                     oh.CLOSED_CALLBACK_AMOUNT
                                    else
                                     0
                                  end)) as total_CLOSED_CALLBACK_AMOUNT,
                              sum((case
                                    when oh.discount_pay_dept = '1' and
                                         oh.discount_item <> '3' then
                                     oh.policy_amount - oh.closed_callback_amount
                                    else
                                     0
                                  end)) as nonres_left_amount,
                              sum((case
                                    when oh.discount_pay_dept = '1' and
                                         oh.discount_item = '3' then
                                     oh.policy_amount - oh.closed_callback_amount
                                    else
                                     0
                                  end)) as zk_left_amount
                         from t_pol_order_headers oh
                        where oh.entity_id = IN_ENTITY_ID
                          AND oh.order_date between
                              to_date(IS_YEAR_CODE || '01', 'YYYYMM') and
                              add_months(to_date(IS_YEAR_CODE || '01',
                                                 'YYYYMM'),
                                         12) - 1
                          and oh.policy_amount <> oh.closed_callback_amount
                          and (IN_SALES_CENTER_ID is null or IN_SALES_CENTER_ID = oh.sales_center_id)
                          and exists (select 1 from v_bd_user_org_priv op where op.ENTITY_ID = IN_ENTITY_ID
                          and op.USER_CODE = IS_USER_CODE AND OP.UNIT_ID = OH.SALES_CENTER_ID)
                        group by oh.entity_id,
                                 oh.sales_center_id,
                                 trunc(oh.order_date, 'mm')
                       having(sum(oh.policy_amount) - sum(oh.CLOSED_CALLBACK_AMOUNT)) <> 0),
                      st as--统计各中心该年份的申请金额、回收金额
                       (select dt.entity_id,
                              dt.sales_center_id,
                              sum(dt.total_policy_amount) as total_policy_amount,
                              sum(dt.total_CLOSED_CALLBACK_AMOUNT) as total_CLOSED_CALLBACK_AMOUNT,
                              sum(dt.total_policy_amount -
                                  dt.total_CLOSED_CALLBACK_AMOUNT) as total_policy_left_amount,
                              sum(dt.nonres_left_amount) as nonres_left_amount,
                              sum(dt.zk_left_amount) as zk_left_amount,
                              sum(dt.nonres_left_amount + dt.zk_left_amount) as left_amount,
                              sum(dt.total_policy_amount -
                                  dt.total_CLOSED_CALLBACK_AMOUNT +
                                  dt.nonres_left_amount + dt.zk_left_amount) as total_policy_all_amount
                         from dt
                        group by dt.entity_id, dt.sales_center_id)
                      select ST.ENTITY_ID,
                             ST.SALES_CENTER_ID,
                             ST.TOTAL_POLICY_AMOUNT,
                             ST.TOTAL_CLOSED_CALLBACK_AMOUNT,
                             ST.TOTAL_POLICY_LEFT_AMOUNT,
                             ST.NONRES_LEFT_AMOUNT,
                             ST.ZK_LEFT_AMOUNT,
                             ST.LEFT_AMOUNT,
                             ST.TOTAL_POLICY_ALL_AMOUNT,
                             nvl((select dt.total_policy_amount
                                from dt, mt
                               where dt.entity_id = st.entity_id
                                 and dt.sales_center_id = st.sales_center_id
                                 and dt.order_date = mt.ym
                                 and mt.li = 0),0) as total_policy_amount_ym0,
                             nvl((select dt.total_policy_amount
                                from dt, mt
                               where dt.entity_id = st.entity_id
                                 and dt.sales_center_id = st.sales_center_id
                                 and dt.order_date = mt.ym
                                 and mt.li = 1),0) as total_policy_amount_ym1,
                             nvl((select dt.total_policy_amount
                                from dt, mt
                               where dt.entity_id = st.entity_id
                                 and dt.sales_center_id = st.sales_center_id
                                 and dt.order_date = mt.ym
                                 and mt.li = 2),0) as total_policy_amount_ym2,
                             nvl((select dt.total_policy_amount
                                from dt, mt
                               where dt.entity_id = st.entity_id
                                 and dt.sales_center_id = st.sales_center_id
                                 and dt.order_date = mt.ym
                                 and mt.li = 3),0) as total_policy_amount_ym3,
                             nvl((select dt.total_policy_amount
                                from dt, mt
                               where dt.entity_id = st.entity_id
                                 and dt.sales_center_id = st.sales_center_id
                                 and dt.order_date = mt.ym
                                 and mt.li = 4),0) as total_policy_amount_ym4,
                             nvl((select dt.total_policy_amount
                                from dt, mt
                               where dt.entity_id = st.entity_id
                                 and dt.sales_center_id = st.sales_center_id
                                 and dt.order_date = mt.ym
                                 and mt.li = 5),0) as total_policy_amount_ym5,
                             nvl((select dt.total_policy_amount
                                from dt, mt
                               where dt.entity_id = st.entity_id
                                 and dt.sales_center_id = st.sales_center_id
                                 and dt.order_date = mt.ym
                                 and mt.li = 6),0) as total_policy_amount_ym6,
                             nvl((select dt.total_policy_amount
                                from dt, mt
                               where dt.entity_id = st.entity_id
                                 and dt.sales_center_id = st.sales_center_id
                                 and dt.order_date = mt.ym
                                 and mt.li = 7),0) as total_policy_amount_ym7,
                             nvl((select dt.total_policy_amount
                                from dt, mt
                               where dt.entity_id = st.entity_id
                                 and dt.sales_center_id = st.sales_center_id
                                 and dt.order_date = mt.ym
                                 and mt.li = 8),0) as total_policy_amount_ym8,
                             nvl((select dt.total_policy_amount
                                from dt, mt
                               where dt.entity_id = st.entity_id
                                 and dt.sales_center_id = st.sales_center_id
                                 and dt.order_date = mt.ym
                                 and mt.li = 9),0) as total_policy_amount_ym9,
                             nvl((select dt.total_policy_amount
                                from dt, mt
                               where dt.entity_id = st.entity_id
                                 and dt.sales_center_id = st.sales_center_id
                                 and dt.order_date = mt.ym
                                 and mt.li = 10),0) as total_policy_amount_ym10,
                             nvl((select dt.total_policy_amount
                                from dt, mt
                               where dt.entity_id = st.entity_id
                                 and dt.sales_center_id = st.sales_center_id
                                 and dt.order_date = mt.ym
                                 and mt.li = 11),0) as total_policy_amount_ym11,
                             nvl((select dt.total_CLOSED_CALLBACK_AMOUNT
                                from dt, mt
                               where dt.entity_id = st.entity_id
                                 and dt.sales_center_id = st.sales_center_id
                                 and dt.order_date = mt.ym
                                 and mt.li = 0),0) as total_cls_clb_AMOUNT_ym0,
                             nvl((select dt.total_CLOSED_CALLBACK_AMOUNT
                                from dt, mt
                               where dt.entity_id = st.entity_id
                                 and dt.sales_center_id = st.sales_center_id
                                 and dt.order_date = mt.ym
                                 and mt.li = 1),0) as total_cls_clb_AMOUNT_ym1,
                             nvl((select dt.total_CLOSED_CALLBACK_AMOUNT
                                from dt, mt
                               where dt.entity_id = st.entity_id
                                 and dt.sales_center_id = st.sales_center_id
                                 and dt.order_date = mt.ym
                                 and mt.li = 2),0) as total_cls_clb_AMOUNT_ym2,
                             nvl((select dt.total_CLOSED_CALLBACK_AMOUNT
                                from dt, mt
                               where dt.entity_id = st.entity_id
                                 and dt.sales_center_id = st.sales_center_id
                                 and dt.order_date = mt.ym
                                 and mt.li = 3),0) as total_cls_clb_AMOUNT_ym3,
                             nvl((select dt.total_CLOSED_CALLBACK_AMOUNT
                                from dt, mt
                               where dt.entity_id = st.entity_id
                                 and dt.sales_center_id = st.sales_center_id
                                 and dt.order_date = mt.ym
                                 and mt.li = 4),0) as total_cls_clb_AMOUNT_ym4,
                             nvl((select dt.total_CLOSED_CALLBACK_AMOUNT
                                from dt, mt
                               where dt.entity_id = st.entity_id
                                 and dt.sales_center_id = st.sales_center_id
                                 and dt.order_date = mt.ym
                                 and mt.li = 5),0) as total_cls_clb_AMOUNT_ym5,
                             nvl((select dt.total_CLOSED_CALLBACK_AMOUNT
                                from dt, mt
                               where dt.entity_id = st.entity_id
                                 and dt.sales_center_id = st.sales_center_id
                                 and dt.order_date = mt.ym
                                 and mt.li = 6),0) as total_cls_clb_AMOUNT_ym6,
                             nvl((select dt.total_CLOSED_CALLBACK_AMOUNT
                                from dt, mt
                               where dt.entity_id = st.entity_id
                                 and dt.sales_center_id = st.sales_center_id
                                 and dt.order_date = mt.ym
                                 and mt.li = 7),0) as total_cls_clb_AMOUNT_ym7,
                             nvl((select dt.total_CLOSED_CALLBACK_AMOUNT
                                from dt, mt
                               where dt.entity_id = st.entity_id
                                 and dt.sales_center_id = st.sales_center_id
                                 and dt.order_date = mt.ym
                                 and mt.li = 8),0) as total_cls_clb_AMOUNT_ym8,
                             nvl((select dt.total_CLOSED_CALLBACK_AMOUNT
                                from dt, mt
                               where dt.entity_id = st.entity_id
                                 and dt.sales_center_id = st.sales_center_id
                                 and dt.order_date = mt.ym
                                 and mt.li = 9),0) as total_cls_clb_AMOUNT_ym9,
                             nvl((select dt.total_CLOSED_CALLBACK_AMOUNT
                                from dt, mt
                               where dt.entity_id = st.entity_id
                                 and dt.sales_center_id = st.sales_center_id
                                 and dt.order_date = mt.ym
                                 and mt.li = 10),0) as total_cls_clb_AMOUNT_ym10,
                             nvl((select dt.total_CLOSED_CALLBACK_AMOUNT
                                from dt, mt
                               where dt.entity_id = st.entity_id
                                 and dt.sales_center_id = st.sales_center_id
                                 and dt.order_date = mt.ym
                                 and mt.li = 11),0) as total_cls_clb_AMOUNT_ym11
                      
                        from st) loop
      v := OBJ_POL_ORDER_CLS_AMOUNT(thisrow.ENTITY_ID,
                                    thisrow.SALES_CENTER_ID,
                                    thisrow.TOTAL_POLICY_AMOUNT,
                                    thisrow.TOTAL_CLOSED_CALLBACK_AMOUNT,
                                    thisrow.TOTAL_POLICY_LEFT_AMOUNT,
                                    thisrow.NONRES_LEFT_AMOUNT,
                                    thisrow.ZK_LEFT_AMOUNT,
                                    thisrow.LEFT_AMOUNT,
                                    thisrow.TOTAL_POLICY_ALL_AMOUNT,
                                    thisrow.TOTAL_POLICY_AMOUNT_YM0,
                                    thisrow.TOTAL_POLICY_AMOUNT_YM1,
                                    thisrow.TOTAL_POLICY_AMOUNT_YM2,
                                    thisrow.TOTAL_POLICY_AMOUNT_YM3,
                                    thisrow.TOTAL_POLICY_AMOUNT_YM4,
                                    thisrow.TOTAL_POLICY_AMOUNT_YM5,
                                    thisrow.TOTAL_POLICY_AMOUNT_YM6,
                                    thisrow.TOTAL_POLICY_AMOUNT_YM7,
                                    thisrow.TOTAL_POLICY_AMOUNT_YM8,
                                    thisrow.TOTAL_POLICY_AMOUNT_YM9,
                                    thisrow.TOTAL_POLICY_AMOUNT_YM10,
                                    thisrow.TOTAL_POLICY_AMOUNT_YM11,
                                    thisrow.TOTAL_CLS_CLB_AMOUNT_YM0,
                                    thisrow.TOTAL_CLS_CLB_AMOUNT_YM1,
                                    thisrow.TOTAL_CLS_CLB_AMOUNT_YM2,
                                    thisrow.TOTAL_CLS_CLB_AMOUNT_YM3,
                                    thisrow.TOTAL_CLS_CLB_AMOUNT_YM4,
                                    thisrow.TOTAL_CLS_CLB_AMOUNT_YM5,
                                    thisrow.TOTAL_CLS_CLB_AMOUNT_YM6,
                                    thisrow.TOTAL_CLS_CLB_AMOUNT_YM7,
                                    thisrow.TOTAL_CLS_CLB_AMOUNT_YM8,
                                    thisrow.TOTAL_CLS_CLB_AMOUNT_YM9,
                                    thisrow.TOTAL_CLS_CLB_AMOUNT_YM10,
                                    thisrow.TOTAL_CLS_CLB_AMOUNT_YM11);
      pipe row(v);
    end loop;
  END ORDER_CLS_AMOUNT;
END PKG_POL_RPT;
/

