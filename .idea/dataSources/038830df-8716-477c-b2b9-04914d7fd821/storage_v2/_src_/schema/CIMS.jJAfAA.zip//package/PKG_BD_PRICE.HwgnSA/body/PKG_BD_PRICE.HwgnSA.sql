create Package Body PKG_BD_PRICE Is
  /*取价函数*/
  function F_GET_PRICE(P_ACC_ID        t_customer_account.account_id%type, --账户ID
                       P_ITEM_CODE     t_bd_item.item_code%type, --产品编码
                       P_BILL_DATE     VARCHAR2, --单据日期
                       P_PRICE_LIST_ID t_bd_price_list.price_list_id%type, --价格列表ID
                       P_ENTITY_ID     up_org_unit.ENTITY_ID%type --业务主体ID
                       ) --
   return NUMBER is
    LD_PRICE          NUMBER;
    LD_DISCOUNT       NUMBER;
    LD_MONTH_DISCOUNT NUMBER;
    LS_CX_FLAG        varchar2(2);
  begin
    P_GET_PRICE(P_ACC_ID,
                P_ITEM_CODE,
                P_BILL_DATE,
                P_PRICE_LIST_ID,
                P_ENTITY_ID,
                LD_PRICE,
                LD_DISCOUNT,
                LD_MONTH_DISCOUNT,
                LS_CX_FLAG);
    return LD_PRICE;
  end;

  -------------------------------------------------------------------------------
  /*
    *   创建日期：2017-07-27
    *     创建者：liangym2
  p_get_price  *   功能说明：取价格行后台接口方法
    */
  -------------------------------------------------------------------------------
  procedure P_GET_PRICE_LINE(IN_ACC_ID         IN t_customer_account.account_id%type, --账户ID
                             IS_ITEM_CODE      IN t_bd_item.item_code%type, --产品编码
                             IS_BILL_DATE      IN VARCHAR2, --单据日期,YYYYMMDD
                             IN_PRICE_LIST_ID  IN t_bd_price_list.price_list_id%type, --价格列表ID
                             IN_ENTITY_ID      IN up_org_unit.ENTITY_ID%type, --业务主体ID
                             ON_PRICE          out NUMBER, --返回价格
                             ON_DISCOUNT       out NUMBER, --返回折扣率
                             ON_MONTH_DISCOUNT out NUMBER, --返回月返
                             OS_CX_FLAG        out VARCHAR2, --返回是否促销机
                             OS_COMPE_ATTR     OUT VARCHAR2 --价格行的竞争属性
                             ) is
  
    LS_PRICE_MODE     varchar2(32);
    LD_PRICE          NUMBER;
    LD_DISCOUNT       NUMBER;
    LD_MONTH_DISCOUNT NUMBER;
    LS_CX_FLAG        varchar2(2);
    VN_PRICE_LINE_ID  NUMBER; --
    v_PLN_C2M_PRICE_PRIORITY varchar2(50); --定制机取价优先级
    v_C2m_Customized_Flag varchar2(2);  --是否定制机产品
    v_COMPE_ATTR     varchar2(200);
    V_COUNT          Number;
  
  begin
    -- BD_PRICE_MODE :(XSGS:销司多层级定价模式  JXS: 经销商模式)
    LS_PRICE_MODE := pkg_bd.F_GET_PARAMETER_VALUE('BD_PRICE_MODE',
                                                  IN_ENTITY_ID,
                                                  null,
                                                  null);
    --获取定制机取价优先级
    v_PLN_C2M_PRICE_PRIORITY := Pkg_Bd.f_Get_Parameter_Value('PLN_C2M_PRICE_PRIORITY',
                                                           IN_ENTITY_ID);
    --获取产品是否C2M定制产品
    Begin
      Select Count(1)
        Into V_COUNT
        From t_Bd_Item i
       Where i.Item_Code = IS_ITEM_CODE
         And i.Entity_Id = IN_ENTITY_ID
         And I.ITEM_CODE Like '71%';
      If V_COUNT > 0 Then
        v_C2m_Customized_Flag := 'Y';
      Else
        v_C2m_Customized_Flag := 'N';
      End If;
    Exception
      When Others Then
        v_C2m_Customized_Flag := 'N';
    End;
    if (LS_PRICE_MODE = 'XSGS') then
      --非定制机产品或者是定制机产品,且取价模式优先价格体系的，先取价格列表价格
      --有传入价格列表id的，根据价格列表id取价，不取看是否定制机
      If v_C2m_Customized_Flag = 'N' Or (v_Pln_C2m_Price_Priority = 'PRICE' And
         v_C2m_Customized_Flag = 'Y') Or IN_PRICE_LIST_ID Is Not Null Then
        --家用
        P_GET_PRICE_10(IN_ENTITY_ID,
                       IN_ACC_ID,
                       IS_ITEM_CODE,
                       IS_BILL_DATE,
                       IN_PRICE_LIST_ID,
                       LD_PRICE,
                       LD_DISCOUNT,
                       LD_MONTH_DISCOUNT,
                       LS_CX_FLAG,
                       VN_PRICE_LINE_ID);
        --定制机按价格体系取价，取不到，则在按选配项取价
        If v_C2m_Customized_Flag = 'Y'And LD_PRICE Is Null And IN_PRICE_LIST_ID Is Null Then
          P_GET_PRICE_C2M(IN_ACC_ID,
                       IS_ITEM_CODE,
                       IS_BILL_DATE,
                       IN_PRICE_LIST_ID,
                       IN_ENTITY_ID,
                       LD_PRICE,
                       LD_DISCOUNT,
                       LD_MONTH_DISCOUNT,
                       LS_CX_FLAG,
                       v_COMPE_ATTR);
        End If;
      --如果是定制机产品，取价优先级是取选配项价格，先取选配项价格
      --有传入价格列表id的，根据价格列表id取价，不取看是否定制机
      Elsif v_Pln_C2m_Price_Priority = 'C2M' And v_C2m_Customized_Flag = 'Y' And IN_PRICE_LIST_ID Is Null Then
        P_GET_PRICE_C2M(IN_ACC_ID,
                       IS_ITEM_CODE,
                       IS_BILL_DATE,
                       IN_PRICE_LIST_ID,
                       IN_ENTITY_ID,
                       LD_PRICE,
                       LD_DISCOUNT,
                       LD_MONTH_DISCOUNT,
                       LS_CX_FLAG,
                       v_COMPE_ATTR);
        --按选配项取不到价格，则取价格体系价格
        --优先按选配价格取价的，取不到价后不找价格体系的价格列表价格 2020-5-6 lilh6
        /*If LD_PRICE Is Null Then
          --家用
          P_GET_PRICE_10(IN_ENTITY_ID,
                         IN_ACC_ID,
                         IS_ITEM_CODE,
                         IS_BILL_DATE,
                         IN_PRICE_LIST_ID,
                         LD_PRICE,
                         LD_DISCOUNT,
                         LD_MONTH_DISCOUNT,
                         LS_CX_FLAG,
                         VN_PRICE_LINE_ID);  
        End If;*/
      End If;
    end if;
    if (LS_PRICE_MODE = 'JXS') then
      --非定制机产品或者是定制机产品,且取价模式优先价格体系的，先取价格列表价格
      If v_C2m_Customized_Flag = 'N' Or (v_Pln_C2m_Price_Priority = 'PRICE' And
         v_C2m_Customized_Flag = 'Y') Or IN_PRICE_LIST_ID Is Not Null Then
        --厨电
        P_GET_PRICE_14(IN_ENTITY_ID,
                       IN_ACC_ID,
                       IS_ITEM_CODE,
                       IS_BILL_DATE,
                       IN_PRICE_LIST_ID,
                       LD_PRICE,
                       LD_DISCOUNT,
                       LD_MONTH_DISCOUNT,
                       LS_CX_FLAG,
                       VN_PRICE_LINE_ID);
        IF VN_PRICE_LINE_ID > 0 THEN
          BEGIN
            SELECT COMPETITE_ATTR
              INTO OS_COMPE_ATTR
              FROM T_BD_PRICE_LINE
             WHERE VN_PRICE_LINE_ID = PRICE_LINE_ID;
          EXCEPTION
            WHEN OTHERS THEN
              NULL;
          END;
        END IF;
        --定制机按价格体系取价，取不到，则在按选配项取价
        If v_C2m_Customized_Flag = 'Y'And LD_PRICE Is Null And IN_PRICE_LIST_ID Is Null Then
          P_GET_PRICE_C2M(IN_ACC_ID,
                       IS_ITEM_CODE,
                       IS_BILL_DATE,
                       IN_PRICE_LIST_ID,
                       IN_ENTITY_ID,
                       LD_PRICE,
                       LD_DISCOUNT,
                       LD_MONTH_DISCOUNT,
                       LS_CX_FLAG,
                       v_COMPE_ATTR);
        End If;
      --如果是定制机产品，取价优先级是取选配项价格，先取选配项价格
      Elsif v_Pln_C2m_Price_Priority = 'C2M' And v_C2m_Customized_Flag = 'Y'And IN_PRICE_LIST_ID Is Null Then
        P_GET_PRICE_C2M(IN_ACC_ID,
                       IS_ITEM_CODE,
                       IS_BILL_DATE,
                       IN_PRICE_LIST_ID,
                       IN_ENTITY_ID,
                       LD_PRICE,
                       LD_DISCOUNT,
                       LD_MONTH_DISCOUNT,
                       LS_CX_FLAG,
                       v_COMPE_ATTR);
        --按选配项取不到价格，则取价格体系价格
        --优先按选配价格取价的，取不到价后不找价格体系的价格列表价格 2020-5-6 lilh6
        /*If LD_PRICE Is Null Then
          P_GET_PRICE_14(IN_ENTITY_ID,
                         IN_ACC_ID,
                         IS_ITEM_CODE,
                         IS_BILL_DATE,
                         IN_PRICE_LIST_ID,
                         LD_PRICE,
                         LD_DISCOUNT,
                         LD_MONTH_DISCOUNT,
                         LS_CX_FLAG,
                         VN_PRICE_LINE_ID);
          IF VN_PRICE_LINE_ID > 0 THEN
            BEGIN
              SELECT COMPETITE_ATTR
                INTO OS_COMPE_ATTR
                FROM T_BD_PRICE_LINE
               WHERE VN_PRICE_LINE_ID = PRICE_LINE_ID;
            EXCEPTION
              WHEN OTHERS THEN
                NULL;
            END;
          END IF;
        End if;*/
      End If; 
      
    end if;
    ON_PRICE          := LD_PRICE; --返回价格
    ON_DISCOUNT       := LD_DISCOUNT; --返回折扣率
    ON_MONTH_DISCOUNT := LD_MONTH_DISCOUNT; --返回月返
    OS_CX_FLAG        := LS_CX_FLAG; --返回是否促销机
    --OS_COMPE_ATTR      := 'COMMON';--竞争属性
  
  end;

  -------------------------------------------------------------------------------
  /*
    *   创建日期：2014-08-15
    *     创建者：xiongpl
  p_get_price  *   功能说明：取价后台接口方法
    */
  -------------------------------------------------------------------------------
  procedure P_GET_PRICE(P_ACC_ID         IN t_customer_account.account_id%type, --账户ID
                        P_ITEM_CODE      IN t_bd_item.item_code%type, --产品编码
                        P_BILL_DATE      IN VARCHAR2, --单据日期,YYYYMMDD
                        P_PRICE_LIST_ID  IN t_bd_price_list.price_list_id%type, --价格列表ID
                        P_ENTITY_ID      IN up_org_unit.ENTITY_ID%type, --业务主体ID
                        P_PRICE          out NUMBER, --返回价格
                        P_DISCOUNT       out NUMBER, --返回折扣率
                        P_MONTH_DISCOUNT out NUMBER, --返回月返
                        P_CX_FLAG        out VARCHAR2 --返回是否促销机
                        ) is
  
    LS_PRICE_MODE     varchar2(32);
    LD_PRICE          NUMBER;
    LD_DISCOUNT       NUMBER;
    LD_MONTH_DISCOUNT NUMBER;
    LS_CX_FLAG        varchar2(2);
    VN_PRICE_LINE_ID  NUMBER; --
    v_PLN_C2M_PRICE_PRIORITY varchar2(50); --定制机取价优先级
    v_C2m_Customized_Flag varchar2(2);  --是否定制机产品
    v_COMPE_ATTR     varchar2(2000);
    V_COUNT          Number;
  
  begin
    -- BD_PRICE_MODE :(XSGS:销司多层级定价模式  JXS: 经销商模式)
    LS_PRICE_MODE := pkg_bd.F_GET_PARAMETER_VALUE('BD_PRICE_MODE',
                                                  P_ENTITY_ID,
                                                  null,
                                                  null);
    --获取定制机取价优先级
    v_PLN_C2M_PRICE_PRIORITY := Pkg_Bd.f_Get_Parameter_Value('PLN_C2M_PRICE_PRIORITY',
                                                           P_ENTITY_ID);
    --获取产品是否C2M定制产品
    Begin
      Select Count(1)
        Into V_COUNT
        From t_Bd_Item i
       Where i.Item_Code = P_ITEM_CODE
         And i.Entity_Id = P_ENTITY_ID
         And I.ITEM_CODE Like '71%';
      If V_COUNT > 0 Then
        v_C2m_Customized_Flag := 'Y';
      Else
        v_C2m_Customized_Flag := 'N';
      End If;
    Exception
      When Others Then
        v_C2m_Customized_Flag := 'N';
    End;
    if (LS_PRICE_MODE = 'XSGS') then
      --非定制机产品或者是定制机产品,且取价模式优先价格体系的，先取价格列表价格
      --有传入价格列表id的，根据价格列表id取价，不取看是否定制机
      If v_C2m_Customized_Flag = 'N' Or (v_Pln_C2m_Price_Priority = 'PRICE' And
         v_C2m_Customized_Flag = 'Y') Or P_PRICE_LIST_ID Is Not Null Then
        --家用
        P_GET_PRICE_10(P_ENTITY_ID,
                       P_ACC_ID,
                       P_ITEM_CODE,
                       P_BILL_DATE,
                       P_PRICE_LIST_ID,
                       LD_PRICE,
                       LD_DISCOUNT,
                       LD_MONTH_DISCOUNT,
                       LS_CX_FLAG,
                       VN_PRICE_LINE_ID);
      --定制机按价格体系取价，取不到，则在按选配项取价
        If v_C2m_Customized_Flag = 'Y'And LD_PRICE Is Null And P_PRICE_LIST_ID Is Null Then
          P_GET_PRICE_C2M(P_ACC_ID,
                       P_ITEM_CODE,
                       P_BILL_DATE,
                       P_PRICE_LIST_ID,
                       P_ENTITY_ID,
                       LD_PRICE,
                       LD_DISCOUNT,
                       LD_MONTH_DISCOUNT,
                       LS_CX_FLAG,
                       v_COMPE_ATTR);
        End If;
      --如果是定制机产品，取价优先级是取选配项价格，先取选配项价格
      --有传入价格列表id的，根据价格列表id取价，不取看是否定制机
      Elsif v_Pln_C2m_Price_Priority = 'C2M' And v_C2m_Customized_Flag = 'Y'And P_PRICE_LIST_ID Is Null Then
        P_GET_PRICE_C2M(P_ACC_ID,
                       P_ITEM_CODE,
                       P_BILL_DATE,
                       P_PRICE_LIST_ID,
                       P_ENTITY_ID,
                       LD_PRICE,
                       LD_DISCOUNT,
                       LD_MONTH_DISCOUNT,
                       LS_CX_FLAG,
                       v_COMPE_ATTR);
        --按选配项取不到价格，则取价格体系价格
        --优先按选配价格取价的，取不到价后不找价格体系的价格列表价格 2020-5-6 lilh6
        /*If LD_PRICE Is Null Then
          --家用
          P_GET_PRICE_10(P_ENTITY_ID,
                         P_ACC_ID,
                         P_ITEM_CODE,
                         P_BILL_DATE,
                         P_PRICE_LIST_ID,
                         LD_PRICE,
                         LD_DISCOUNT,
                         LD_MONTH_DISCOUNT,
                         LS_CX_FLAG,
                         VN_PRICE_LINE_ID);  
        End If;*/
      End If;
    end if;
    if (LS_PRICE_MODE = 'JXS') then
      --非定制机产品或者是定制机产品,且取价模式优先价格体系的，先取价格列表价格
      If v_C2m_Customized_Flag = 'N' Or (v_Pln_C2m_Price_Priority = 'PRICE' And
         v_C2m_Customized_Flag = 'Y') Or P_PRICE_LIST_ID Is Not Null Then
        --厨电
        P_GET_PRICE_14(P_ENTITY_ID,
                       P_ACC_ID,
                       P_ITEM_CODE,
                       P_BILL_DATE,
                       P_PRICE_LIST_ID,
                       LD_PRICE,
                       LD_DISCOUNT,
                       LD_MONTH_DISCOUNT,
                       LS_CX_FLAG,
                       VN_PRICE_LINE_ID);
        --定制机按价格体系取价，取不到，则在按选配项取价
        If v_C2m_Customized_Flag = 'Y'And LD_PRICE Is Null And P_PRICE_LIST_ID Is Null Then
          P_GET_PRICE_C2M(P_ACC_ID,
                       P_ITEM_CODE,
                       P_BILL_DATE,
                       P_PRICE_LIST_ID,
                       P_ENTITY_ID,
                       LD_PRICE,
                       LD_DISCOUNT,
                       LD_MONTH_DISCOUNT,
                       LS_CX_FLAG,
                       v_COMPE_ATTR);
        End If;
      --如果是定制机产品，取价优先级是取选配项价格，先取选配项价格
      Elsif v_Pln_C2m_Price_Priority = 'C2M' And v_C2m_Customized_Flag = 'Y' And P_PRICE_LIST_ID Is Null Then
        P_GET_PRICE_C2M(P_ACC_ID,
                       P_ITEM_CODE,
                       P_BILL_DATE,
                       P_PRICE_LIST_ID,
                       P_ENTITY_ID,
                       LD_PRICE,
                       LD_DISCOUNT,
                       LD_MONTH_DISCOUNT,
                       LS_CX_FLAG,
                       v_COMPE_ATTR);
        --按选配项取不到价格，则取价格体系价格
        --优先按选配价格取价的，取不到价后不找价格体系的价格列表价格 2020-5-6 lilh6
        /*If LD_PRICE Is Null Then
          P_GET_PRICE_14(P_ENTITY_ID,
                         P_ACC_ID,
                         P_ITEM_CODE,
                         P_BILL_DATE,
                         P_PRICE_LIST_ID,
                         LD_PRICE,
                         LD_DISCOUNT,
                         LD_MONTH_DISCOUNT,
                         LS_CX_FLAG,
                         VN_PRICE_LINE_ID);
        End if;*/
      End If;
    end if;
    P_PRICE          := LD_PRICE; --返回价格
    P_DISCOUNT       := LD_DISCOUNT; --返回折扣率
    P_MONTH_DISCOUNT := LD_MONTH_DISCOUNT; --返回月返
    P_CX_FLAG        := LS_CX_FLAG; --返回是否促销机
  
  end;

  /*取价过程,入口过程，优惠品*/
  procedure P_GET_PRICE_YH(P_ACC_ID         IN t_customer_account.account_id%type, --账户ID
                           P_ITEM_CODE      IN t_bd_item.item_code%type, --产品编码
                           P_BILL_DATE      IN VARCHAR2, --单据日期 YYYYMMDD
                           P_PRICE_LIST_ID  IN t_bd_price_list.price_list_id%type, --价格列表ID
                           P_ENTITY_ID      IN up_org_unit.ENTITY_ID%type, --业务主体ID
                           P_PRICE          out NUMBER, --返回价格
                           P_DISCOUNT       out NUMBER, --返回折扣率
                           P_MONTH_DISCOUNT out NUMBER, --返回月返
                           P_CX_FLAG        out VARCHAR2 --返回是否促销机
                           ) is
  
    LS_PRICE_MODE     varchar2(32);
    LD_PRICE          NUMBER;
    LD_DISCOUNT       NUMBER;
    LD_MONTH_DISCOUNT NUMBER;
    LS_CX_FLAG        varchar2(2);
    VN_PRICE_LINE_ID  NUMBER; --
  
  begin
    --优惠品
    -- BD_PRICE_MODE :(XSGS:销司多层级定价模式  JXS: 经销商模式)
    LS_PRICE_MODE := pkg_bd.F_GET_PARAMETER_VALUE('BD_PRICE_MODE',
                                                  P_ENTITY_ID,
                                                  null,
                                                  null);
    if (LS_PRICE_MODE = 'XSGS') then
      --家用
      P_GET_PRICE_10_YH(P_ENTITY_ID,
                        P_ACC_ID,
                        P_ITEM_CODE,
                        P_BILL_DATE,
                        P_PRICE_LIST_ID,
                        LD_PRICE,
                        LD_DISCOUNT,
                        LD_MONTH_DISCOUNT,
                        LS_CX_FLAG,
                        VN_PRICE_LINE_ID);
    end if;
    if (LS_PRICE_MODE = 'JXS') then
      --厨电
      P_GET_PRICE_14_YH(P_ENTITY_ID,
                        P_ACC_ID,
                        P_ITEM_CODE,
                        P_BILL_DATE,
                        P_PRICE_LIST_ID,
                        LD_PRICE,
                        LD_DISCOUNT,
                        LD_MONTH_DISCOUNT,
                        LS_CX_FLAG,
                        VN_PRICE_LINE_ID);
    end if;
  
    P_PRICE          := LD_PRICE; --返回价格
    P_DISCOUNT       := LD_DISCOUNT; --返回折扣率
    P_MONTH_DISCOUNT := LD_MONTH_DISCOUNT; --返回月返
    P_CX_FLAG        := LS_CX_FLAG; --返回是否促销机
  
  end;

  /*取价格列表行过程,入口过程，优惠品*/
  procedure P_GET_PRICE_LINE_YH(IN_ACC_ID         IN t_customer_account.account_id%type, --账户ID
                                IS_ITEM_CODE      IN t_bd_item.item_code%type, --产品编码
                                IS_BILL_DATE      IN VARCHAR2, --单据日期 YYYYMMDD
                                IN_PRICE_LIST_ID  IN t_bd_price_list.price_list_id%type, --价格列表ID
                                IN_ENTITY_ID      IN up_org_unit.ENTITY_ID%type, --业务主体ID
                                ON_PRICE          out NUMBER, --返回价格
                                ON_DISCOUNT       out NUMBER, --返回折扣率
                                ON_MONTH_DISCOUNT out NUMBER, --返回月返
                                OS_CX_FLAG        out VARCHAR2, --返回是否促销机
                                OS_COMPE_ATTR     OUT VARCHAR2 --价格行的竞争属性
                                ) is
  
    LS_PRICE_MODE     varchar2(32);
    LD_PRICE          NUMBER;
    LD_DISCOUNT       NUMBER;
    LD_MONTH_DISCOUNT NUMBER;
    LS_CX_FLAG        varchar2(2);
    VN_PRICE_LINE_ID  NUMBER; --
  
  begin
    --优惠品
    -- BD_PRICE_MODE :(XSGS:销司多层级定价模式  JXS: 经销商模式)
    LS_PRICE_MODE := pkg_bd.F_GET_PARAMETER_VALUE('BD_PRICE_MODE',
                                                  IN_ENTITY_ID,
                                                  null,
                                                  null);
    if (LS_PRICE_MODE = 'XSGS') then
      --家用
      P_GET_PRICE_10_YH(IN_ENTITY_ID,
                        IN_ACC_ID,
                        IS_ITEM_CODE,
                        IS_BILL_DATE,
                        IN_PRICE_LIST_ID,
                        LD_PRICE,
                        LD_DISCOUNT,
                        LD_MONTH_DISCOUNT,
                        LS_CX_FLAG,
                        VN_PRICE_LINE_ID);
    end if;
    if (LS_PRICE_MODE = 'JXS') then
      --厨电
      P_GET_PRICE_14_YH(IN_ENTITY_ID,
                        IN_ACC_ID,
                        IS_ITEM_CODE,
                        IS_BILL_DATE,
                        IN_PRICE_LIST_ID,
                        LD_PRICE,
                        LD_DISCOUNT,
                        LD_MONTH_DISCOUNT,
                        LS_CX_FLAG,
                        VN_PRICE_LINE_ID);
      IF VN_PRICE_LINE_ID > 0 THEN
        BEGIN
          SELECT COMPETITE_ATTR
            INTO OS_COMPE_ATTR
            FROM T_BD_PRICE_LINE
           WHERE VN_PRICE_LINE_ID = PRICE_LINE_ID;
        EXCEPTION
          WHEN OTHERS THEN
            NULL;
        END;
      END IF;
    end if;
  
    ON_PRICE          := LD_PRICE; --返回价格
    ON_DISCOUNT       := LD_DISCOUNT; --返回折扣率
    ON_MONTH_DISCOUNT := LD_MONTH_DISCOUNT; --返回月返
    OS_CX_FLAG        := LS_CX_FLAG; --返回是否促销机
    --OS_COMPE_ATTR      := 'COMMON';--竞争属性
  
  end;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-08-15
  *     创建者：xiongpl
  *   功能说明：家用取价过程  ，正品
  
  注：
    结算金额 = SUM(数量 * 单价 * (1 -月返/100 - 折扣/100 ))
    折让金额 = SUM(数量 * 单价 * 折扣/100)
  */
  -------------------------------------------------------------------------------
  procedure P_GET_PRICE_10(P_ENTITY_ID      IN NUMBER,
                           P_ACC_ID         IN t_customer_account.account_id%type, --账户ID
                           P_ITEM_CODE      IN t_bd_item.item_code%type, --产品编码
                           P_BILL_DATE      IN VARCHAR2, --单据日期
                           P_PRICE_LIST_ID  IN t_bd_price_list.price_list_id%type, --价格列表ID
                           P_PRICE          out NUMBER, --返回价格
                           P_DISCOUNT       out NUMBER, --返回折扣率
                           P_MONTH_DISCOUNT out NUMBER, --返回月返
                           P_CX_FLAG        out VARCHAR2, --返回是否促销机
                           ON_PRICE_LINE_ID OUT NUMBER --
                           ) is
    LD_CUSR_ID       t_customer_account.customer_id%type;
    LD_UNIT_ID       up_org_unit.unit_id%type;
    LD_SYSTEM_ID     t_bd_price_system.price_system_id%type;
    priceSystemCust  t_bd_price_system_cust%ROWTYPE;
    LD_PRICE_LIST_ID t_bd_price_list.price_list_id%type;
    LS_PRICE_TYPE    t_bd_price_system.price_type%type; --价格体系类型，T推广物料，C成品
  
    priceSystemOrg t_bd_price_system_org%ROWTYPE;
    priceSystem    t_bd_price_system%ROWTYPE;
    LD_CUST_CNT    number;
    LD_ORG_CNT     number;
    LD_CNT         number;
    VD_BILL_DATE   DATE;
  
  begin
    VD_BILL_DATE := TO_DATE(P_BILL_DATE, 'YYYYMMDD');
  
    if (P_PRICE_LIST_ID is not null) then
      --DBMS_OUTPUT.PUT_LINE('P_PRICE_LIST_ID: NULL');
      --1、如果价格列表不为空，则直接从价格列表上取价格,月返
      P_DISCOUNT := 0;
      P_CX_FLAG  := 'N';
      --1.1 根据价格列表ID、产品ID，查找价格、月返率
      P_GET_PRICE_FROM_LIST_10(P_ENTITY_ID,
                               P_ITEM_CODE,
                               VD_BILL_DATE,
                               P_PRICE_LIST_ID,
                               P_PRICE,
                               P_MONTH_DISCOUNT,
                               P_CX_FLAG,
                               ON_PRICE_LINE_ID);
    else
      --2、如果价格列表为空，则从价格体系上定位到具体价格列表，并从价格列表上取价格
      --2.1 根据账户ID、找对应的客户
      select customer_id
        into LD_CUSR_ID
        from t_customer_account
       where account_id = P_ACC_ID
         and entity_id = P_ENTITY_ID;
      --and active_flag = 'Y';
      --2.2 根据账户ID、找对应的中心
      select co.sales_center_id
        into LD_UNIT_ID
        from t_customer_acc_org_relation rl, t_customer_org co
       where rl.customer_org_id = co.customer_org_id
         and rl.account_id = P_ACC_ID
         and co.entity_id = P_ENTITY_ID;
      --and active_flag = 'Y';
      --判断产品是成品还是推广物料，用于取不同的价格体系
      select decode(is_material, 'Y', 'T', 'C')
        into LS_PRICE_TYPE
        from t_bd_item
       where item_code = P_ITEM_CODE
         and entity_id = P_ENTITY_ID;
      --2.3 根据单据日期找到对应的价格体系，并找到对应的价格列表ID、折扣率
      select price_system_id
        into LD_SYSTEM_ID
        from t_bd_price_system ps
       where (PS.END_DATE IS NULL OR PS.END_DATE >= VD_BILL_DATE)
         AND VD_BILL_DATE >= PS.BEGIN_DATE /*P_BILL_DATE >= to_char(ps.begin_date, 'YYYYMMDD')
                      and P_BILL_DATE <= to_char(nvl(ps.end_date,to_date(P_BILL_DATE,'YYYYMMDD')+1), 'YYYYMMDD')*/
         and ps.entity_id = P_ENTITY_ID
         and ps.price_type = LS_PRICE_TYPE
         and ps.active_flag = 'Y';
    
      select count(1)
        into LD_CUST_CNT
        from t_bd_price_system_cust sc
       where sc.price_system_id = LD_SYSTEM_ID
         and sc.sales_center_id = LD_UNIT_ID
         and sc.customer_id = LD_CUSR_ID
         and sc.active_flag = 'Y';
      --2.4判断是否找到客户关联价格列表
      if (LD_CUST_CNT > 0) then
        select sc.*
          into priceSystemCust
          from t_bd_price_system_cust sc
         where sc.price_system_id = LD_SYSTEM_ID
           and sc.sales_center_id = LD_UNIT_ID
           and sc.customer_id = LD_CUSR_ID
           and sc.active_flag = 'Y';
      
        P_DISCOUNT       := nvl(priceSystemCust.Discount, 0); --20150424 为空返回0
        LD_PRICE_LIST_ID := priceSystemCust.Price_List_Id;
      else
        --2.5 如果没找到客户价格，则取对应中心价格列表
        select count(1)
          into LD_ORG_CNT
          from t_bd_price_system_org so
         where so.price_system_id = LD_SYSTEM_ID
           and so.sales_center_id = LD_UNIT_ID
           and so.active_flag = 'Y';
        if (LD_ORG_CNT > 0) then
          select so.*
            into priceSystemOrg
            from t_bd_price_system_org so
           where so.price_system_id = LD_SYSTEM_ID
             and so.sales_center_id = LD_UNIT_ID
             and so.active_flag = 'Y';
        
          P_DISCOUNT       := nvl(priceSystemOrg.Discount, 0); --20150424 为空返回0
          LD_PRICE_LIST_ID := priceSystemOrg.Price_List_Id;
        else
          --2.6 如果没找到中心价格列表，则取总部默认价格列表
          select ps.*
            into priceSystem
            from t_bd_price_system ps
           where ps.price_system_id = LD_SYSTEM_ID
             and ps.active_flag = 'Y';
        
          P_DISCOUNT       := 0;
          LD_PRICE_LIST_ID := priceSystem.bu_price_list_id;
          --DBMS_OUTPUT.PUT_LINE('总部P_PRICE_LIST_ID: '||LD_PRICE_LIST_ID);
        end if;
      
      end if;
    
      P_CX_FLAG := 'N'; --是否促销机
      --2.4 根据价格列表ID、产品ID，查找价格、月返率
      P_GET_PRICE_FROM_LIST_10(P_ENTITY_ID,
                               P_ITEM_CODE,
                               VD_BILL_DATE,
                               LD_PRICE_LIST_ID,
                               P_PRICE,
                               P_MONTH_DISCOUNT,
                               P_CX_FLAG,
                               ON_PRICE_LINE_ID);
    end if;
  
  end;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-08-15
  *     创建者：xiongpl
  *   功能说明：家用取价过程  ，优惠品
  
  注：
    结算金额 = SUM(数量 * 单价 * (1 -月返/100 - 折扣/100 ))
    折让金额 = SUM(数量 * 单价 * 折扣/100)
  */
  -------------------------------------------------------------------------------
  procedure P_GET_PRICE_10_YH(P_ENTITY_ID      IN NUMBER,
                              P_ACC_ID         IN t_customer_account.account_id%type, --账户ID
                              P_ITEM_CODE      IN t_bd_item.item_code%type, --产品编码
                              P_BILL_DATE      IN VARCHAR2, --单据日期
                              P_PRICE_LIST_ID  IN t_bd_price_list.price_list_id%type, --价格列表ID
                              P_PRICE          out NUMBER, --返回价格
                              P_DISCOUNT       out NUMBER, --返回折扣率
                              P_MONTH_DISCOUNT out NUMBER, --返回月返
                              P_CX_FLAG        out VARCHAR2, --返回是否促销机
                              ON_PRICE_LINE_ID OUT NUMBER --
                              ) is
    LD_CUSR_ID    t_customer_account.customer_id%type;
    LD_UNIT_ID    up_org_unit.unit_id%type;
    LD_SYSTEM_ID  t_bd_price_system.price_system_id%type;
    LS_PRICE_TYPE t_bd_price_system.price_type%type; --价格体系类型，T推广物料，C成品
  
    priceSystemCust  t_bd_price_system_cust%ROWTYPE;
    LD_PRICE_LIST_ID t_bd_price_list.price_list_id%type;
  
    priceSystemOrg t_bd_price_system_org%ROWTYPE;
    priceSystem    t_bd_price_system%ROWTYPE;
    LD_CUST_CNT    number;
    LD_ORG_CNT     number;
    LD_CNT         number;
    VD_BILL_DATE   DATE;
  
  begin
    VD_BILL_DATE := TO_DATE(P_BILL_DATE, 'YYYYMMDD');
  
    if (P_PRICE_LIST_ID is not null) then
      --DBMS_OUTPUT.PUT_LINE('P_PRICE_LIST_ID: NULL');
      --1、如果价格列表不为空，则直接从价格列表上取价格,月返
      P_DISCOUNT := 0;
      P_CX_FLAG  := 'N';
      --1.1 根据价格列表ID、产品ID，查找价格、月返率
      P_GET_PRICE_FROM_LIST_10(P_ENTITY_ID,
                               P_ITEM_CODE,
                               VD_BILL_DATE,
                               P_PRICE_LIST_ID,
                               P_PRICE,
                               P_MONTH_DISCOUNT,
                               P_CX_FLAG,
                               ON_PRICE_LINE_ID);
    else
      --2、如果价格列表为空，则从价格体系上定位到具体价格列表，并从价格列表上取价格
      --2.1 根据账户ID、找对应的客户
      select customer_id
        into LD_CUSR_ID
        from t_customer_account
       where account_id = P_ACC_ID
         and entity_id = P_ENTITY_ID;
      --and active_flag = 'Y';
      --2.2 根据账户ID、找对应的中心
      select co.sales_center_id
        into LD_UNIT_ID
        from t_customer_acc_org_relation rl, t_customer_org co
       where rl.customer_org_id = co.customer_org_id
         and rl.account_id = P_ACC_ID
         and co.entity_id = P_ENTITY_ID;
      --and active_flag = 'Y';
      --判断产品是成品还是推广物料，用于取不同的价格体系
      select decode(is_material, 'Y', 'T', 'C')
        into LS_PRICE_TYPE
        from t_bd_item
       where item_code = P_ITEM_CODE
         and entity_id = P_ENTITY_ID;
      --2.3 根据单据日期找到对应的价格体系，并找到对应的价格列表ID、折扣率
      select price_system_id
        into LD_SYSTEM_ID
        from t_bd_price_system ps
       where (PS.END_DATE IS NULL OR PS.END_DATE >= VD_BILL_DATE)
         AND VD_BILL_DATE >= PS.BEGIN_DATE /*P_BILL_DATE >= to_char(ps.begin_date, 'YYYYMMDD')
                      and P_BILL_DATE <= to_char(nvl(ps.end_date,to_date(P_BILL_DATE,'YYYYMMDD')+1), 'YYYYMMDD')*/
         and ps.entity_id = P_ENTITY_ID
         and ps.price_type = LS_PRICE_TYPE
         and ps.active_flag = 'Y';
    
      select count(1)
        into LD_CUST_CNT
        from t_bd_price_system_cust sc
       where sc.price_system_id = LD_SYSTEM_ID
         and sc.sales_center_id = LD_UNIT_ID
         and sc.customer_id = LD_CUSR_ID
         and sc.sub_price_list_id is not null --优惠品新增判断
         and sc.active_flag = 'Y';
      --2.4判断是否找到客户关联价格列表
      if (LD_CUST_CNT > 0) then
        select sc.*
          into priceSystemCust
          from t_bd_price_system_cust sc
         where sc.price_system_id = LD_SYSTEM_ID
           and sc.sales_center_id = LD_UNIT_ID
           and sc.customer_id = LD_CUSR_ID
           and sc.sub_price_list_id is not null --优惠品新增判断
           and sc.active_flag = 'Y';
      
        P_DISCOUNT       := nvl(priceSystemCust.Sub_Discount, 0); --优惠品折扣 --20150424 为空返回0
        LD_PRICE_LIST_ID := priceSystemCust.Sub_Price_List_Id; --优惠品列表ID
      else
        --2.5 如果没找到客户价格，则取对应中心价格列表
        select count(1)
          into LD_ORG_CNT
          from t_bd_price_system_org so
         where so.price_system_id = LD_SYSTEM_ID
           and so.sales_center_id = LD_UNIT_ID
           and so.sub_price_list_id is not null --优惠品新增判断
           and so.active_flag = 'Y';
        if (LD_ORG_CNT > 0) then
          select so.*
            into priceSystemOrg
            from t_bd_price_system_org so
           where so.price_system_id = LD_SYSTEM_ID
             and so.sales_center_id = LD_UNIT_ID
             and so.sub_price_list_id is not null --优惠品新增判断
             and so.active_flag = 'Y';
        
          P_DISCOUNT       := nvl(priceSystemOrg.Sub_Discount, 0); --优惠品折扣 --20150424 为空返回0
          LD_PRICE_LIST_ID := priceSystemOrg.Sub_Price_List_Id; --优惠品列表ID
        else
          --2.6 如果没找到中心价格列表，则返回
        
          P_PRICE          := null;
          P_DISCOUNT       := 0;
          P_MONTH_DISCOUNT := 0;
          P_CX_FLAG        := 'N';
          return;
          --2.6 如果没找到中心价格列表，则取总部默认价格列表
          select ps.*
            into priceSystem
            from t_bd_price_system ps
           where ps.price_system_id = LD_SYSTEM_ID
             and ps.active_flag = 'Y';
        
          P_DISCOUNT       := 0;
          LD_PRICE_LIST_ID := priceSystem.bu_price_list_id;
          --DBMS_OUTPUT.PUT_LINE('总部P_PRICE_LIST_ID: '||LD_PRICE_LIST_ID);
        end if;
      
      end if;
    
      P_CX_FLAG := 'N'; --是否促销机
      --2.4 根据价格列表ID、产品ID，查找价格、月返率
      P_GET_PRICE_FROM_LIST_10(P_ENTITY_ID,
                               P_ITEM_CODE,
                               VD_BILL_DATE,
                               LD_PRICE_LIST_ID,
                               P_PRICE,
                               P_MONTH_DISCOUNT,
                               P_CX_FLAG,
                               ON_PRICE_LINE_ID);
    end if;
  
  end;
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-08-15
  *     创建者：xiongpl
  *   功能说明：厨电取价过程 ,正品
  
  注：
    结算金额 = SUM(数量 * 单价 * (1 -月返/100 - 折扣/100 ))
    折让金额 = SUM(数量 * 单价 * 折扣/100)
  */
  -------------------------------------------------------------------------------
  procedure P_GET_PRICE_14(P_ENTITY_ID      IN NUMBER,
                           P_ACC_ID         IN t_customer_account.account_id%type, --账户ID
                           P_ITEM_CODE      IN t_bd_item.item_code%type, --产品编码
                           P_BILL_DATE      IN VARCHAR2, --单据日期
                           P_PRICE_LIST_ID  IN t_bd_price_list.price_list_id%type, --价格列表ID
                           P_PRICE          out NUMBER, --返回价格
                           P_DISCOUNT       out NUMBER, --返回折扣率
                           P_MONTH_DISCOUNT out NUMBER, --返回月返
                           P_CX_FLAG        out VARCHAR2, --返回是否促销机
                           ON_PRICE_LINE_ID OUT NUMBER --
                           ) is
    LD_CNT      number;
    LD_CUST_CNT number;
    LD_ORG_CNT  number;
  
    LD_CUSR_ID    t_customer_account.customer_id%type;
    LD_UNIT_ID    up_org_unit.unit_id%type;
    LD_SYSTEM_ID  t_bd_price_system.price_system_id%type;
    LS_PRICE_TYPE t_bd_price_system.price_type%type; --价格体系类型，T推广物料，C成品
  
    priceSystemCust  t_bd_price_system_cust%ROWTYPE;
    priceSystemOrg   t_bd_price_system_org%ROWTYPE;
    priceSystem      t_bd_price_system%ROWTYPE;
    LD_PRICE_LIST_ID t_bd_price_list.price_list_id%type;
  
    LS_CUSR_TYPE   t_bd_price_cust_config.price_type%type;
    LS_IS_MATERIAL t_bd_item.is_material%type;
    VD_BILL_DATE   DATE;
  
  begin
    VD_BILL_DATE := TO_DATE(P_BILL_DATE, 'YYYYMMDD');
    LS_CUSR_TYPE := null;
    IF P_ACC_ID is not null then
      --1 根据账户ID、找对应的客户
      select customer_id
        into LD_CUSR_ID
        from t_customer_account
       where account_id = P_ACC_ID
         and entity_id = P_ENTITY_ID;
      --and active_flag = 'Y';
      --2 根据账户ID、找对应的中心
      select co.sales_center_id
        into LD_UNIT_ID
        from t_customer_acc_org_relation rl, t_customer_org co
       where rl.customer_org_id = co.customer_org_id
         and rl.account_id = P_ACC_ID
         and co.entity_id = P_ENTITY_ID;
      --and active_flag = 'Y';
      --3、找客户中心对应的取价类型（客户渠道类型）  EBUSINESS:电商客户,  PROJECT:工程客户,OEM:OEM客户,  COMMON:常规客户,CARRIER:承运商客户
      /*select p.price_type
       into LS_CUSR_TYPE
       from t_bd_price_cust_config p
      where p.customer_id = LD_CUSR_ID
        and p.sales_center_id = LD_UNIT_ID
        and p.active_flag='Y';      */
      --Engineering 工程客户；WholesaleChannels 渠道客户；E-Commerce  电商客户；CommonChannelsofRetail  零售客户
      SELECT (select t.industry_type
                from t_customer_channel_type t
               where t.customer_id = LD_CUSR_ID
                 and t.entity_id = P_ENTITY_ID
                 and t.active_flag = 'Active')
        into LS_CUSR_TYPE
        FROM DUAL;
    end if;
    if (P_PRICE_LIST_ID is not null) then
      --4、如果价格列表不为空，则直接从价格列表上取价格,月返率
      P_DISCOUNT := 0;
      --4.1 根据价格列表ID、产品ID，查找价格、月返率
      P_GET_PRICE_FROM_LIST_14(P_ENTITY_ID,
                               P_ITEM_CODE,
                               VD_BILL_DATE,
                               LS_CUSR_TYPE,
                               P_PRICE_LIST_ID,
                               P_PRICE,
                               P_MONTH_DISCOUNT,
                               P_CX_FLAG,
                               ON_PRICE_LINE_ID);
    else
      --5、如果价格列表为空，则从价格类型对应的价格体系上定位到具体价格列表，并从价格列表上取价格
      --5.1 根据单据日期找到对应的价格体系，并找到对应的价格列表ID、折扣率
      /* select price_system_id
        into LD_SYSTEM_ID
        from t_bd_price_type pt
       where P_BILL_DATE >= to_char(pt.begin_date, 'YYYYMMDD')
         and P_BILL_DATE <= to_char(pt.end_date, 'YYYYMMDD')
         and pt.entity_id = P_ENTITY_ID
         and pt.price_type = LS_CUSR_TYPE
         and pt.active_flag = 'Y';
      
      select bu_price_list_id
        into LD_PRICE_LIST_ID
        from t_bd_price_system ps
       where ps.price_system_id=LD_SYSTEM_ID;      */
    
      --调整为： 如果价格列表为空，则从价格列表中取客户专用价格列表，如果没取到，则进一步取价格体系
      --判断推广物料时，不走客户专用取价  --产品表：W物料、N产品 、Y推广物料  --价格列表：Y成品   N成品优惠品  T推广物料
    
      select decode(is_material, 'Y', 'T', 'Y')
        into LS_IS_MATERIAL
        from t_bd_item bi
       where bi.item_code = P_ITEM_CODE
         and bi.entity_id = P_ENTITY_ID;
    
      select count(1)
        into LD_CNT
        from t_bd_price_list pl
       where (PL.END_DATE IS NULL OR PL.END_DATE >= VD_BILL_DATE)
         AND VD_BILL_DATE >= PL.BEGIN_DATE /*P_BILL_DATE >= to_char(pl.begin_date, 'YYYYMMDD')
                     and P_BILL_DATE <=
                         to_char(nvl(pl.end_date, to_date(P_BILL_DATE, 'YYYYMMDD') + 1),
                                 'YYYYMMDD')*/
         and pl.entity_id = P_ENTITY_ID
         and pl.cust_flag = 'Y'
         and pl.customer_id = LD_CUSR_ID
         and pl.qualtity_flag = LS_IS_MATERIAL --正品 或 推广物料
         and pl.active_flag = 'Y';
      if (LD_CNT = 1) then
        select pl.price_list_id
          into LD_PRICE_LIST_ID
          from t_bd_price_list pl
         where (PL.END_DATE IS NULL OR PL.END_DATE >= VD_BILL_DATE)
           AND VD_BILL_DATE >= PL.BEGIN_DATE /*P_BILL_DATE >= to_char(pl.begin_date, 'YYYYMMDD')
                         and P_BILL_DATE <= to_char(nvl(pl.end_date,
                                                        to_date(P_BILL_DATE, 'YYYYMMDD') + 1),
                                                    'YYYYMMDD')*/
           and pl.entity_id = P_ENTITY_ID
           and pl.cust_flag = 'Y'
           and pl.customer_id = LD_CUSR_ID
           and pl.qualtity_flag = LS_IS_MATERIAL --正品 或 推广物料
           and pl.active_flag = 'Y';
        P_DISCOUNT := 0;
      else
        --
        --判断产品是成品还是推广物料，用于取不同的价格体系
        select decode(is_material, 'Y', 'T', 'C')
          into LS_PRICE_TYPE
          from t_bd_item
         where item_code = P_ITEM_CODE
           and entity_id = P_ENTITY_ID;
        --5.3 根据单据日期找到对应的价格体系，并找到对应的价格列表ID、折扣率
        select price_system_id
          into LD_SYSTEM_ID
          from t_bd_price_system ps
         where (PS.END_DATE IS NULL OR PS.END_DATE >= VD_BILL_DATE)
           AND VD_BILL_DATE >= PS.BEGIN_DATE /*P_BILL_DATE >= to_char(ps.begin_date, 'YYYYMMDD')
                          and P_BILL_DATE <= to_char(nvl(ps.end_date,to_date(P_BILL_DATE,'YYYYMMDD')+1), 'YYYYMMDD')*/
           and ps.entity_id = P_ENTITY_ID
           and ps.price_type = LS_PRICE_TYPE
           and ps.active_flag = 'Y';
      
        select count(1)
          into LD_CUST_CNT
          from t_bd_price_system_cust sc
         where sc.price_system_id = LD_SYSTEM_ID
           and sc.sales_center_id = LD_UNIT_ID
           and sc.customer_id = LD_CUSR_ID
           and sc.active_flag = 'Y';
        --5.4判断是否找到客户关联价格列表
        if (LD_CUST_CNT > 0) then
          select sc.*
            into priceSystemCust
            from t_bd_price_system_cust sc
           where sc.price_system_id = LD_SYSTEM_ID
             and sc.sales_center_id = LD_UNIT_ID
             and sc.customer_id = LD_CUSR_ID
             and sc.active_flag = 'Y';
        
          P_DISCOUNT       := nvl(priceSystemCust.Discount, 0); --20150424 为空返回0
          LD_PRICE_LIST_ID := priceSystemCust.Price_List_Id;
        else
          --5.5 如果没找到客户价格，则取对应中心价格列表
          select count(1)
            into LD_ORG_CNT
            from t_bd_price_system_org so
           where so.price_system_id = LD_SYSTEM_ID
             and so.sales_center_id = LD_UNIT_ID
             and so.active_flag = 'Y';
          if (LD_ORG_CNT > 0) then
            select so.*
              into priceSystemOrg
              from t_bd_price_system_org so
             where so.price_system_id = LD_SYSTEM_ID
               and so.sales_center_id = LD_UNIT_ID
               and so.active_flag = 'Y';
          
            P_DISCOUNT       := nvl(priceSystemOrg.Discount, 0); --20150424 为空返回0
            LD_PRICE_LIST_ID := priceSystemOrg.Price_List_Id;
          else
            --5.6 如果没找到中心价格列表，则取总部默认价格列表
            select ps.*
              into priceSystem
              from t_bd_price_system ps
             where ps.price_system_id = LD_SYSTEM_ID
               and ps.active_flag = 'Y';
          
            P_DISCOUNT       := 0;
            LD_PRICE_LIST_ID := priceSystem.bu_price_list_id;
            --DBMS_OUTPUT.PUT_LINE('总部P_PRICE_LIST_ID: '||LD_PRICE_LIST_ID);
          end if;
        end if;
        --
      end if;
    
      --5.7 根据价格列表ID、产品ID，查找价格、月返率
      P_GET_PRICE_FROM_LIST_14(P_ENTITY_ID,
                               P_ITEM_CODE,
                               P_BILL_DATE,
                               LS_CUSR_TYPE,
                               LD_PRICE_LIST_ID,
                               P_PRICE,
                               P_MONTH_DISCOUNT,
                               P_CX_FLAG,
                               ON_PRICE_LINE_ID);
    end if;
  
  end;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-08-15
  *     创建者：xiongpl
  *   功能说明：厨电取价过程 ,优惠品
  
  注：
    结算金额 = SUM(数量 * 单价 * (1 -月返/100 - 折扣/100 ))
    折让金额 = SUM(数量 * 单价 * 折扣/100)
  */
  -------------------------------------------------------------------------------
  procedure P_GET_PRICE_14_YH(P_ENTITY_ID      IN NUMBER,
                              P_ACC_ID         IN t_customer_account.account_id%type, --账户ID
                              P_ITEM_CODE      IN t_bd_item.item_code%type, --产品编码
                              P_BILL_DATE      IN VARCHAR2, --单据日期
                              P_PRICE_LIST_ID  IN t_bd_price_list.price_list_id%type, --价格列表ID
                              P_PRICE          out NUMBER, --返回价格
                              P_DISCOUNT       out NUMBER, --返回折扣率
                              P_MONTH_DISCOUNT out NUMBER, --返回月返
                              P_CX_FLAG        out VARCHAR2, --返回是否促销机
                              ON_PRICE_LINE_ID OUT NUMBER --
                              ) is
    LD_CNT      number;
    LD_CUST_CNT number;
    LD_ORG_CNT  number;
  
    LD_CUSR_ID    t_customer_account.customer_id%type;
    LD_UNIT_ID    up_org_unit.unit_id%type;
    LD_SYSTEM_ID  t_bd_price_system.price_system_id%type;
    LS_PRICE_TYPE t_bd_price_system.price_type%type; --价格体系类型，T推广物料，C成品
  
    priceSystemCust  t_bd_price_system_cust%ROWTYPE;
    priceSystemOrg   t_bd_price_system_org%ROWTYPE;
    priceSystem      t_bd_price_system%ROWTYPE;
    LD_PRICE_LIST_ID t_bd_price_list.price_list_id%type;
  
    LS_CUSR_TYPE t_bd_price_cust_config.price_type%type;
    VD_BILL_DATE DATE;
  
  begin
    VD_BILL_DATE := TO_DATE(P_BILL_DATE, 'YYYYMMDD');
  
    --1 根据账户ID、找对应的客户
    select customer_id
      into LD_CUSR_ID
      from t_customer_account
     where account_id = P_ACC_ID
       and entity_id = P_ENTITY_ID;
    --and active_flag = 'Y';
    --2 根据账户ID、找对应的中心
    select co.sales_center_id
      into LD_UNIT_ID
      from t_customer_acc_org_relation rl, t_customer_org co
     where rl.customer_org_id = co.customer_org_id
       and rl.account_id = P_ACC_ID
       and co.entity_id = P_ENTITY_ID;
    --and active_flag = 'Y';
    --3、找客户中心对应的取价类型（客户渠道类型）  EBUSINESS:电商客户,  PROJECT:工程客户,OEM:OEM客户,  COMMON:常规客户,CARRIER:承运商客户
    /*select p.price_type
     into LS_CUSR_TYPE
     from t_bd_price_cust_config p
    where p.customer_id = LD_CUSR_ID
      and p.sales_center_id = LD_UNIT_ID
      and p.active_flag='Y';      */
    --Engineering 工程客户；WholesaleChannels 渠道客户；E-Commerce  电商客户；CommonChannelsofRetail  零售客户
    SELECT (select t.industry_type
              from t_customer_channel_type t
             where t.customer_id = LD_CUSR_ID
               and t.entity_id = P_ENTITY_ID
               and t.active_flag = 'Active')
      into LS_CUSR_TYPE
      FROM DUAL;
  
    if (P_PRICE_LIST_ID is not null) then
      --4、如果价格列表不为空，则直接从价格列表上取价格,月返率
      P_DISCOUNT := 0;
      --4.1 根据价格列表ID、产品ID，查找价格、月返率
      P_GET_PRICE_FROM_LIST_14(P_ENTITY_ID,
                               P_ITEM_CODE,
                               VD_BILL_DATE,
                               LS_CUSR_TYPE,
                               P_PRICE_LIST_ID,
                               P_PRICE,
                               P_MONTH_DISCOUNT,
                               P_CX_FLAG,
                               ON_PRICE_LINE_ID);
    else
      --5、如果价格列表为空，则从价格类型对应的价格体系上定位到具体价格列表，并从价格列表上取价格
      --5.1 根据单据日期找到对应的价格体系，并找到对应的价格列表ID、折扣率
      /* select price_system_id
        into LD_SYSTEM_ID
        from t_bd_price_type pt
       where P_BILL_DATE >= to_char(pt.begin_date, 'YYYYMMDD')
         and P_BILL_DATE <= to_char(pt.end_date, 'YYYYMMDD')
         and pt.entity_id = P_ENTITY_ID
         and pt.price_type = LS_CUSR_TYPE
         and pt.active_flag = 'Y';
      
      select bu_price_list_id
        into LD_PRICE_LIST_ID
        from t_bd_price_system ps
       where ps.price_system_id=LD_SYSTEM_ID;      */
    
      --调整为： 如果价格列表为空，则从价格列表中取客户专用价格列表，如果没取到，则进一步取价格体系
      select count(1)
        into LD_CNT
        from t_bd_price_list pl
       where (PL.END_DATE IS NULL OR PL.END_DATE >= VD_BILL_DATE)
         AND VD_BILL_DATE >= PL.BEGIN_DATE /*P_BILL_DATE >= to_char(pl.begin_date, 'YYYYMMDD')
                      and P_BILL_DATE <= to_char(nvl(pl.end_date,to_date(P_BILL_DATE,'YYYYMMDD')+1), 'YYYYMMDD')*/
         and pl.entity_id = P_ENTITY_ID
         and pl.cust_flag = 'Y'
         and pl.customer_id = LD_CUSR_ID
         and nvl(pl.qualtity_flag, 'Y') = 'N' --优惠品
         and pl.active_flag = 'Y';
      if (LD_CNT = 1) then
        select pl.price_list_id
          into LD_PRICE_LIST_ID
          from t_bd_price_list pl
         where (PL.END_DATE IS NULL OR PL.END_DATE >= VD_BILL_DATE)
           AND VD_BILL_DATE >= PL.BEGIN_DATE /*P_BILL_DATE >= to_char(pl.begin_date, 'YYYYMMDD')
                          and P_BILL_DATE <= to_char(nvl(pl.end_date,to_date(P_BILL_DATE,'YYYYMMDD')+1), 'YYYYMMDD')*/
           and pl.entity_id = P_ENTITY_ID
           and pl.cust_flag = 'Y'
           and pl.customer_id = LD_CUSR_ID
           and nvl(pl.qualtity_flag, 'Y') = 'N' --优惠品
           and pl.active_flag = 'Y';
        P_DISCOUNT := 0;
      else
        --
        --判断产品是成品还是推广物料，用于取不同的价格体系
        select decode(is_material, 'Y', 'T', 'C')
          into LS_PRICE_TYPE
          from t_bd_item
         where item_code = P_ITEM_CODE
           and entity_id = P_ENTITY_ID;
        --5.3 根据单据日期找到对应的价格体系，并找到对应的价格列表ID、折扣率
        select price_system_id
          into LD_SYSTEM_ID
          from t_bd_price_system ps
         where (PS.END_DATE IS NULL OR PS.END_DATE >= VD_BILL_DATE)
           AND VD_BILL_DATE >= PS.BEGIN_DATE /*P_BILL_DATE >= to_char(ps.begin_date, 'YYYYMMDD')
                          and P_BILL_DATE <= to_char(nvl(ps.end_date,to_date(P_BILL_DATE,'YYYYMMDD')+1), 'YYYYMMDD')*/
           and ps.entity_id = P_ENTITY_ID
           and ps.price_type = LS_PRICE_TYPE
           and ps.active_flag = 'Y';
      
        select count(1)
          into LD_CUST_CNT
          from t_bd_price_system_cust sc
         where sc.price_system_id = LD_SYSTEM_ID
           and sc.sales_center_id = LD_UNIT_ID
           and sc.customer_id = LD_CUSR_ID
           and sc.sub_price_list_id is not null --优惠品新增判断
           and sc.active_flag = 'Y';
        --5.4判断是否找到客户关联价格列表
        if (LD_CUST_CNT > 0) then
          select sc.*
            into priceSystemCust
            from t_bd_price_system_cust sc
           where sc.price_system_id = LD_SYSTEM_ID
             and sc.sales_center_id = LD_UNIT_ID
             and sc.customer_id = LD_CUSR_ID
             and sc.sub_price_list_id is not null --优惠品新增判断
             and sc.active_flag = 'Y';
        
          P_DISCOUNT       := nvl(priceSystemCust.Sub_Discount, 0); --优惠品折扣 --20150424 为空返回0
          LD_PRICE_LIST_ID := priceSystemCust.Sub_Price_List_Id; --优惠品列表
        else
          --5.5 如果没找到客户价格，则取对应中心价格列表
          select count(1)
            into LD_ORG_CNT
            from t_bd_price_system_org so
           where so.price_system_id = LD_SYSTEM_ID
             and so.sales_center_id = LD_UNIT_ID
             and so.sub_price_list_id is not null --优惠品新增判断
             and so.active_flag = 'Y';
          if (LD_ORG_CNT > 0) then
            select so.*
              into priceSystemOrg
              from t_bd_price_system_org so
             where so.price_system_id = LD_SYSTEM_ID
               and so.sales_center_id = LD_UNIT_ID
               and so.sub_price_list_id is not null --优惠品新增判断
               and so.active_flag = 'Y';
          
            P_DISCOUNT       := nvl(priceSystemOrg.Sub_Discount, 0); --20150424 为空返回0
            LD_PRICE_LIST_ID := priceSystemOrg.Sub_Price_List_Id;
          else
            --5.6 如果没找到中心价格列表，则取总部默认价格列表
            select ps.*
              into priceSystem
              from t_bd_price_system ps
             where ps.price_system_id = LD_SYSTEM_ID
               and ps.active_flag = 'Y';
          
            P_DISCOUNT       := 0;
            LD_PRICE_LIST_ID := priceSystem.bu_price_list_id;
            --DBMS_OUTPUT.PUT_LINE('总部P_PRICE_LIST_ID: '||LD_PRICE_LIST_ID);
          end if;
        end if;
        --
      end if;
    
      --5.7 根据价格列表ID、产品ID，查找价格、月返率
      P_GET_PRICE_FROM_LIST_14(P_ENTITY_ID,
                               P_ITEM_CODE,
                               VD_BILL_DATE,
                               LS_CUSR_TYPE,
                               LD_PRICE_LIST_ID,
                               P_PRICE,
                               P_MONTH_DISCOUNT,
                               P_CX_FLAG,
                               ON_PRICE_LINE_ID);
    end if;
  
  end;

  /*家用主体，根据价格列表进行取价错误描述*/
  procedure P_G_PRICE_DESC_FROM_LIST_10(P_ENTITY_ID     IN NUMBER,
                                        P_ITEM_CODE     IN t_bd_item.item_code%type, --产品编码
                                        P_BILL_DATE     IN DATE, --单据日期
                                        P_PRICE_LIST_ID IN t_bd_price_list.price_list_id%type, --价格列表ID
                                        P_DESC          out VARCHAR2 --返回
                                        ) is
    vn_cnt_all   number;
    vn_cnt_bg    number;
    vn_cnt_el    number;
    vn_cnt_ber_n number;
    --vn_cnt_y     number;
    vn_cnt_n         number;
    vt_list_name     t_bd_price_list.list_name%type;
    vt_cust_flag     t_bd_price_list.cust_flag%type;
    vt_customer_code t_bd_price_list.customer_code%type;
    vn_cnt_valid         number;
    vn_times             number;
    vs_bill_date         varchar2(100);
  begin
    vs_bill_date := TO_CHAR(P_BILL_DATE,'YYYY-MM-DD');
    select l.list_name,
           l.cust_flag,
           l.customer_code,
           count((case
                   when pl.price_line_id > 0 then
                    0
                   else
                    null
                 end)),
           count((case
                   when pl.price_line_id > 0 and PL.BEGIN_DATE > P_BILL_DATE then
                    0
                   else
                    null
                 end)),
           count((case
                   when pl.price_line_id > 0 and 'Y' = pl.ACTIVE_FLAG and
                        PL.BEGIN_DATE <= P_BILL_DATE and
                        (PL.END_DATE IS NULL OR PL.END_DATE >= P_BILL_DATE) then
                    0
                   else
                    null
                 end)),
           count((case
                   when pl.price_line_id > 0 and PL.END_DATE < P_BILL_DATE then
                    0
                   else
                    null
                 end)),
           count((case
                   when pl.price_line_id > 0 and 'N' = pl.ACTIVE_FLAG and
                        PL.BEGIN_DATE <= P_BILL_DATE and
                        (PL.END_DATE IS NULL OR PL.END_DATE >= P_BILL_DATE) then
                    0
                   else
                    null
                 end)),
           count((case
                   when pl.price_line_id > 0 and 'N' = pl.ACTIVE_FLAG then
                    0
                   else
                    null
                 end)) /*,
               count((case
                       when pl.price_line_id > 0 and 'Y' = pl.ACTIVE_FLAG then
                        0
                       else
                        null
                     end))*/
      into vt_list_name,
           vt_cust_flag,
           vt_customer_code,
           vn_cnt_all,vn_cnt_valid,
           vn_cnt_bg,
           vn_cnt_el,
           vn_cnt_ber_n,
           vn_cnt_n /*,
               vn_cnt_y*/
      from t_bd_price_line pl
     right join t_bd_price_list l
        on (l.price_list_id = pl.price_list_id and
           pl.item_code = P_ITEM_CODE)
     where l.price_list_id = P_PRICE_LIST_ID
     group by l.list_name, l.cust_flag, l.customer_code;
    if 'Y' = vt_cust_flag and vt_customer_code is not null then
      vt_list_name := (vt_list_name || '（注意是' || vt_customer_code || '专用）');
    end if;
    if 1 < vn_cnt_valid then
      P_DESC := '根据价格列表ID：' || P_PRICE_LIST_ID || '【价格列表名称：' ||
                vt_list_name || '】找到' || vn_cnt_valid || '条产品编码为' || P_ITEM_CODE || '且都有效的价格的重复维护记录，请核查问题根源';
    elsif 0 < vn_cnt_valid then
      null;
    elsif 0 = vn_cnt_all then
      P_DESC := '根据价格列表ID：' || P_PRICE_LIST_ID || '【价格列表名称：' ||
                vt_list_name || '】找不到产品编码为' || P_ITEM_CODE || '的价格维护记录';
    else
      P_DESC := '根据价格列表ID：' || P_PRICE_LIST_ID || '【价格列表名称：' ||
                vt_list_name || '】找到' || vn_cnt_all || '条产品编码为' ||
                P_ITEM_CODE || '的价格维护记录，但都不是有效的记录';
      vn_times := 0;
      if 0 < vn_cnt_bg then
        vn_times := (1 + vn_times);
        P_DESC := P_DESC || V_NL || vn_times || '、' || vn_cnt_bg || '条价格维护的开始日期大于' ||
                  vs_bill_date;
      end if;
      if 0 < vn_cnt_el then
        vn_times := (1 + vn_times);
        P_DESC := P_DESC || V_NL || vn_times || '、' || vn_cnt_el || '条价格维护的停用日期小于' ||
                  vs_bill_date;
      end if;
      if 0 < vn_cnt_n and vn_cnt_n <> vn_cnt_ber_n then
        vn_times := (1 + vn_times);
        P_DESC := P_DESC || V_NL || vn_times || '、' || vn_cnt_n || '条价格维护的有效标识为“无效”';
      elsif 0 < vn_cnt_ber_n then
        vn_times := (1 + vn_times);
        P_DESC := P_DESC || V_NL || vn_times || '、' || vn_cnt_ber_n ||
                  '条价格维护的开始日期、停用日期在指定范围内，但是有效标识却为“无效”';
      end if;
      /*if 0 < vn_cnt_y then
        P_DESC := P_DESC || V_NL || vn_cnt_y || '条价格维护的有效标识为“有效”';
      end if;*/
    end if;
  exception
    WHEN NO_DATA_FOUND THEN
      P_DESC := '价格列表ID[' || P_PRICE_LIST_ID || ']在系统找不到价格列表记录：';
  end;

  /*厨电主体，根据价格列表进行取价错误描述
  --产品竞争属性  COMMON:常规机  PROMOTION:促销机
  */
  procedure P_G_PRICE_DESC_FROM_LIST_14(P_ENTITY_ID     IN NUMBER,
                                        P_ITEM_CODE     IN t_bd_item.item_code%type, --产品编码
                                        P_BILL_DATE     IN DATE, --单据日期
                                        P_CUSR_TYPE     IN t_bd_price_type.price_type%type, --取价类型
                                        P_PRICE_LIST_ID IN t_bd_price_list.price_list_id%type, --价格列表ID
                                        P_DESC          out VARCHAR2 --返回价格
                                        ) is
    vn_cnt_all   number;
    vn_cnt_bg    number;
    vn_cnt_el    number;
    vn_cnt_ber_n number;
    --vn_cnt_y     number;
    vn_cnt_n number;
  
    vn_cnt_nvl_nvl number;
    vn_cnt_nvl_n   number;
  
    vn_cnt_n_ce number;
    vn_cnt_n_cn number;
  
    vt_list_name     t_bd_price_list.list_name%type;
    vt_cl_name       up_codelist.code_name%type;
    vt_cust_flag     t_bd_price_list.cust_flag%type;
    vt_customer_code t_bd_price_list.customer_code%type;
    vn_cnt_valid         number;
    vn_times             number;
    vs_bill_date         varchar2(100);
  begin
    vs_bill_date := TO_CHAR(P_BILL_DATE,'YYYY-MM-DD');
    select l.list_name,
           CL.CODE_NAME,
           l.cust_flag,
           l.customer_code,
           count((case
                   when pl.price_line_id > 0 then
                    0
                   else
                    null
                 end)),
           count((case
                   when (P_CUSR_TYPE = PL.CHANNEL_ATTR OR PL.CHANNEL_ATTR IS NULL) AND
                        pl.price_line_id > 0 and 'Y' = pl.ACTIVE_FLAG and
                        PL.BEGIN_DATE <= P_BILL_DATE and
                        (PL.END_DATE IS NULL OR PL.END_DATE >= P_BILL_DATE) then
                    0
                   else
                    null
                 end)),
           count((case
                   when P_CUSR_TYPE IS NULL AND PL.CHANNEL_ATTR IS NULL AND
                        pl.price_line_id > 0 then
                    0
                   else
                    null
                 end)),
           count((case
                   when P_CUSR_TYPE IS NULL AND PL.CHANNEL_ATTR IS NOT NULL AND
                        pl.price_line_id > 0 then
                    0
                   else
                    null
                 end)),
           count((case
                   when (P_CUSR_TYPE = PL.CHANNEL_ATTR OR
                        (P_CUSR_TYPE IS NOT NULL AND PL.CHANNEL_ATTR IS NULL)) AND
                        pl.price_line_id > 0 then
                    0
                   else
                    null
                 end)),
           count((case
                   when P_CUSR_TYPE = PL.CHANNEL_ATTR AND pl.price_line_id > 0 then
                    0
                   else
                    null
                 end)),
           /*count((case
             when (P_CUSR_TYPE IS NOT NULL AND PL.CHANNEL_ATTR IS NULL) AND pl.price_line_id > 0 then
              0
             else
              null
           end)),*/
           count((case
                   when (P_CUSR_TYPE = PL.CHANNEL_ATTR OR PL.CHANNEL_ATTR IS NULL) AND
                        pl.price_line_id > 0 and PL.BEGIN_DATE > P_BILL_DATE then
                    0
                   else
                    null
                 end)),
           count((case
                   when (P_CUSR_TYPE = PL.CHANNEL_ATTR OR PL.CHANNEL_ATTR IS NULL) AND
                        pl.price_line_id > 0 and PL.END_DATE < P_BILL_DATE then
                    0
                   else
                    null
                 end)),
           count((case
                   when (P_CUSR_TYPE = PL.CHANNEL_ATTR OR PL.CHANNEL_ATTR IS NULL) AND
                        pl.price_line_id > 0 and 'N' = pl.ACTIVE_FLAG and
                        PL.BEGIN_DATE <= P_BILL_DATE and
                        (PL.END_DATE IS NULL OR PL.END_DATE >= P_BILL_DATE) then
                    0
                   else
                    null
                 end)),
           count((case
                   when (P_CUSR_TYPE = PL.CHANNEL_ATTR OR PL.CHANNEL_ATTR IS NULL) AND
                        pl.price_line_id > 0 and 'N' = pl.ACTIVE_FLAG then
                    0
                   else
                    null
                 end)) /*,
                   count((case
                           when pl.price_line_id > 0 and 'Y' = pl.ACTIVE_FLAG then
                            0
                           else
                            null
                         end))*/
      into vt_list_name,
           vt_cl_name,
           vt_cust_flag,
           vt_customer_code,
           vn_cnt_all,vn_cnt_valid,
           vn_cnt_nvl_nvl,
           vn_cnt_nvl_n,
           vn_cnt_n_ce,
           vn_cnt_n_cn,
           vn_cnt_bg,
           vn_cnt_el,
           vn_cnt_ber_n,
           vn_cnt_n /*,
                   vn_cnt_y*/
      from t_bd_price_list l
      left join t_bd_price_line pl
        on (l.price_list_id = pl.price_list_id and
           pl.item_code = P_ITEM_CODE)
      left join UP_CODELIST CL
        ON (CL.CODETYPE = 'MIDEA_ACCNT_CHANNEL_TYPE' AND
           CL.CODE_VALUE = P_CUSR_TYPE)
     where l.price_list_id = P_PRICE_LIST_ID
     group by l.list_name, CL.CODE_NAME, l.cust_flag, l.customer_code;
    if 'Y' = vt_cust_flag and vt_customer_code is not null then
      vt_list_name := (vt_list_name || '（注意是' || vt_customer_code || '专用）');
    end if;
    if 1 < vn_cnt_valid then
      P_DESC := '根据价格列表ID：' || P_PRICE_LIST_ID || '【价格列表名称：' ||
                vt_list_name || '】找到' || vn_cnt_valid || '条产品编码为' || P_ITEM_CODE || '且都有效的价格的重复维护记录，请核查问题根源';
    elsif 0 < vn_cnt_valid then
      null;
    elsif 0 = vn_cnt_all then
      P_DESC := '根据价格列表ID：' || P_PRICE_LIST_ID || '【价格列表名称：' ||
                vt_list_name || '】找不到产品编码为' || P_ITEM_CODE || '的价格维护记录';
    else
      P_DESC := '根据价格列表ID：' || P_PRICE_LIST_ID || '【价格列表名称：' ||
                vt_list_name || '】找到' || vn_cnt_all || '条产品编码为' ||
                P_ITEM_CODE || '的价格维护记录，但都不是有效的记录';
      if P_CUSR_TYPE is null then
        if 0 = vn_cnt_nvl_nvl and 0 < vn_cnt_nvl_n then
          P_DESC := P_DESC || V_NL || vn_cnt_nvl_n ||
                    '条价格的客户业态类型维护成非空值，不是可取的价格';
        else
          vn_times := 0;
          if 0 < vn_cnt_nvl_nvl and 0 < vn_cnt_nvl_n then
            --vn_times := (1 + vn_times);
            P_DESC := P_DESC || V_NL || vn_cnt_nvl_nvl ||
                      '条价格的客户业态类型维护为空，是可取的价格【并且另外' || vn_cnt_nvl_n ||
                      '条价格的客户业态类型维护成非空值，不是可取的价格】';
          end if;
          if 0 < vn_cnt_bg then
            vn_times := (1 + vn_times);
            P_DESC := P_DESC || V_NL || vn_times || '、' || vn_cnt_bg || '条可取价格维护的开始日期大于' ||
                      vs_bill_date;
          end if;
          if 0 < vn_cnt_el then
            vn_times := (1 + vn_times);
            P_DESC := P_DESC || V_NL || vn_times || '、' || vn_cnt_el || '条可取价格维护的停用日期小于' ||
                      vs_bill_date;
          end if;
          if 0 < vn_cnt_n and vn_cnt_n <> vn_cnt_ber_n then
            vn_times := (1 + vn_times);
            P_DESC := P_DESC || V_NL || vn_times || '、' || vn_cnt_n || '条可取价格维护的有效标识为“无效”';
          elsif 0 < vn_cnt_ber_n then
            vn_times := (1 + vn_times);
            P_DESC := P_DESC || V_NL || vn_times || '、' || vn_cnt_ber_n ||
                      '条可取价格维护的开始日期、停用日期在指定范围内，但是有效标识却为“无效”';
          end if;
          /*if 0 < vn_cnt_y then
            P_DESC := P_DESC || V_NL || vn_cnt_y || '条可取价格维护的有效标识为“有效”';
          end if;*/
        end if;
      elsif 0 = vn_cnt_n_ce then
        P_DESC := '根据价格列表ID：' || P_PRICE_LIST_ID || '【价格列表名称：' ||
                  vt_list_name || '】找到' || vn_cnt_all || '条产品编码为' ||
                  P_ITEM_CODE || '的价格维护记录，但这些价格的客户业态类型都不是空值等于“' ||
                  vt_cl_name || '（当前取价的客户的业态类型）”';
      else
        if vn_cnt_n_ce = vn_cnt_n_cn then
          P_DESC := '根据价格列表ID：' || P_PRICE_LIST_ID || '【价格列表名称：' ||
                    vt_list_name || '】找到' || vn_cnt_n_ce || '条产品编码为' ||
                    P_ITEM_CODE || '的价格维护记录，且这些价格维护的客户业态类型与当前取价的客户的业态类型“' ||
                    vt_cl_name || '”是相匹配的';
        elsif 0 < vn_cnt_n_cn then
          P_DESC := '根据价格列表ID：' || P_PRICE_LIST_ID || '【价格列表名称：' ||
                    vt_list_name || '】找到' || vn_cnt_n_ce || '条产品编码为' ||
                    P_ITEM_CODE || '可取的价格维护记录，其中' || vn_cnt_n_cn
                    || '条价格维护的客户业态类型与当前取价的客户的业态类型“' ||
                    vt_cl_name || '”相匹配，另外' || (vn_cnt_n_ce - vn_cnt_n_cn) || '条维护的客户业态类型为空（为空也是可取的价格）';
        else
          P_DESC := '当前取价的客户的业态类型“' || vt_cl_name || '”，根据价格列表ID：' || P_PRICE_LIST_ID || '【价格列表名称：' ||
                    vt_list_name || '】找到' || vn_cnt_n_ce || '条产品编码为' ||
                    P_ITEM_CODE || '的价格维护记录';--，虽然这些价格的客户业态类型都已维护成空值，但原则上还是可取的
        end if;
        P_DESC := P_DESC || V_NL || '虽然这些价格的客户业态类型与当前取价的匹配或者为空，但是还必须同时满足时间范围以及有效标识的条件。';
        vn_times := 0;
        if 0 < vn_cnt_bg then
            vn_times := (1 + vn_times);
            P_DESC := P_DESC || V_NL || vn_times || '、' || vn_cnt_bg || '条可取价格维护的开始日期大于' || vs_bill_date;
        end if;
          if 0 < vn_cnt_el then
            vn_times := (1 + vn_times);
            P_DESC := P_DESC || V_NL || vn_times || '、' || vn_cnt_el || '条可取价格维护的停用日期小于' || vs_bill_date;
          end if;
            vn_times := (1 + vn_times);
          if 0 < vn_cnt_n and vn_cnt_n <> vn_cnt_ber_n then
            vn_times := (1 + vn_times);
            P_DESC := P_DESC || V_NL || vn_times || '、' || vn_cnt_n || '条可取价格维护的有效标识为“无效”';
          elsif 0 < vn_cnt_ber_n then
            vn_times := (1 + vn_times);
            P_DESC := P_DESC || V_NL || vn_times || '、' || vn_cnt_ber_n ||
                      '条可取价格维护的开始日期、停用日期在指定范围内，但是有效标识却为“无效”';
          end if;
          /*if 0 < vn_cnt_y then
            P_DESC := P_DESC || V_NL || vn_cnt_y || '条可取价格维护的有效标识为“有效”';
          end if;*/
      end if;
    end if;
  exception
    WHEN NO_DATA_FOUND THEN
      P_DESC := '价格列表ID[' || P_PRICE_LIST_ID || ']在系统找不到价格列表记录：';
  end;

  /*家用主体，根据价格列表进行取价*/
  procedure P_GET_PRICE_FROM_LIST_10(P_ENTITY_ID      IN NUMBER,
                                     P_ITEM_CODE      IN t_bd_item.item_code%type, --产品编码
                                     P_BILL_DATE      IN VARCHAR2, --单据日期
                                     P_PRICE_LIST_ID  IN t_bd_price_list.price_list_id%type, --价格列表ID
                                     P_PRICE          out NUMBER, --返回价格
                                     P_MONTH_DISCOUNT out NUMBER, --返回月返
                                     P_CX_FLAG        out VARCHAR2, --返回是否促销机
                                     ON_PRICE_LINE_ID OUT NUMBER --
                                     ) is
    VD_BILL_DATE DATE;
  
  begin
    VD_BILL_DATE := TO_DATE(P_BILL_DATE, 'YYYYMMDD');
    P_GET_PRICE_FROM_LIST_10(P_ENTITY_ID,
                             P_ITEM_CODE,
                             VD_BILL_DATE,
                             P_PRICE_LIST_ID,
                             P_PRICE,
                             P_MONTH_DISCOUNT,
                             P_CX_FLAG,
                             ON_PRICE_LINE_ID);
  end;

  /*家用主体，根据价格列表进行取价*/
  procedure P_GET_PRICE_FROM_LIST_10(P_ENTITY_ID      IN NUMBER,
                                     P_ITEM_CODE      IN t_bd_item.item_code%type, --产品编码
                                     P_BILL_DATE      IN DATE, --单据日期
                                     P_PRICE_LIST_ID  IN t_bd_price_list.price_list_id%type, --价格列表ID
                                     P_PRICE          out NUMBER, --返回价格
                                     P_MONTH_DISCOUNT out NUMBER, --返回月返
                                     P_CX_FLAG        out VARCHAR2, --返回是否促销机
                                     ON_PRICE_LINE_ID OUT NUMBER --
                                     ) is
    --LD_MONTH_DISCOUNT t_bd_price_line.discount%type;
  begin
    --DBMS_OUTPUT.PUT_LINE('P_PRICE_LIST_ID:'||P_PRICE_LIST_ID);
    select pl.list_price, nvl(pl.discount, 0) discount, PL.PRICE_LINE_ID
      into P_PRICE, P_MONTH_DISCOUNT, ON_PRICE_LINE_ID
      from t_bd_price_line pl
     where pl.price_list_id = P_PRICE_LIST_ID
       and pl.item_code = P_ITEM_CODE
       AND (PL.END_DATE IS NULL OR PL.END_DATE >= P_BILL_DATE)
       AND P_BILL_DATE >= PL.BEGIN_DATE
          /*and P_BILL_DATE >= to_char(nvl(pl.begin_date,to_date(P_BILL_DATE,'YYYYMMDD')-1), 'YYYYMMDD')
          and P_BILL_DATE <= to_char(nvl(pl.end_date,to_date(P_BILL_DATE,'YYYYMMDD')+1), 'YYYYMMDD')*/
       and 'Y' = pl.ACTIVE_FLAG
    --and rownum = 1
    ;
    P_CX_FLAG := 'N';
  
  exception
    when NO_DATA_FOUND then
      P_PRICE          := null;
      P_MONTH_DISCOUNT := 0;
      P_CX_FLAG        := 'N';
  end;

  /*厨电主体，根据价格列表进行取价
  --产品竞争属性  COMMON:常规机  PROMOTION:促销机
  */
  procedure P_GET_PRICE_FROM_LIST_14(P_ENTITY_ID      IN NUMBER,
                                     P_ITEM_CODE      IN t_bd_item.item_code%type, --产品编码
                                     P_BILL_DATE      IN VARCHAR2, --单据日期
                                     P_CUSR_TYPE      IN t_bd_price_type.price_type%type, --取价类型
                                     P_PRICE_LIST_ID  IN t_bd_price_list.price_list_id%type, --价格列表ID
                                     P_PRICE          out NUMBER, --返回价格
                                     P_MONTH_DISCOUNT out NUMBER, --返回月返
                                     P_CX_FLAG        out VARCHAR2, --返回是否促销机
                                     ON_PRICE_LINE_ID OUT NUMBER --
                                     ) is
    VD_BILL_DATE DATE;
  
  begin
    VD_BILL_DATE := TO_DATE(P_BILL_DATE, 'YYYYMMDD');
    P_GET_PRICE_FROM_LIST_14(P_ENTITY_ID,
                             P_ITEM_CODE,
                             VD_BILL_DATE,
                             P_CUSR_TYPE,
                             P_PRICE_LIST_ID,
                             P_PRICE,
                             P_MONTH_DISCOUNT,
                             P_CX_FLAG,
                             ON_PRICE_LINE_ID);
  end;

  /*厨电主体，根据价格列表进行取价
  --产品竞争属性  COMMON:常规机  PROMOTION:促销机
  */
  procedure P_GET_PRICE_FROM_LIST_14(P_ENTITY_ID      IN NUMBER,
                                     P_ITEM_CODE      IN t_bd_item.item_code%type, --产品编码
                                     P_BILL_DATE      IN DATE, --单据日期
                                     P_CUSR_TYPE      IN t_bd_price_type.price_type%type, --取价类型
                                     P_PRICE_LIST_ID  IN t_bd_price_list.price_list_id%type, --价格列表ID
                                     P_PRICE          out NUMBER, --返回价格
                                     P_MONTH_DISCOUNT out NUMBER, --返回月返
                                     P_CX_FLAG        out VARCHAR2, --返回是否促销机
                                     ON_PRICE_LINE_ID OUT NUMBER --
                                     ) IS
    LS_COMPET_ATTR t_bd_price_line.competite_attr%type; --产品竞争属性
  BEGIN
    if P_CUSR_TYPE is not null then
      begin
        select pl.list_price,
               nvl(pl.discount, 0) discount,
               pl.competite_attr,
               PL.PRICE_LINE_ID
          into P_PRICE, P_MONTH_DISCOUNT, LS_COMPET_ATTR, ON_PRICE_LINE_ID
          from t_bd_price_line pl
         where pl.price_list_id = P_PRICE_LIST_ID
           and pl.item_code = P_ITEM_CODE
           and pl.channel_attr = P_CUSR_TYPE
           AND (PL.END_DATE IS NULL OR PL.END_DATE >= P_BILL_DATE)
           AND P_BILL_DATE >= PL.BEGIN_DATE
              /*and P_BILL_DATE >= to_char(nvl(pl.begin_date,to_date(P_BILL_DATE,'YYYYMMDD')-1), 'YYYYMMDD')
              and P_BILL_DATE <= to_char(nvl(pl.end_date,to_date(P_BILL_DATE,'YYYYMMDD')+1), 'YYYYMMDD')*/
           and 'Y' = pl.ACTIVE_FLAG
        --and rownum = 1
        ;
      exception
        when NO_DATA_FOUND then
          select pl.list_price,
                 nvl(pl.discount, 0) discount,
                 pl.competite_attr,
                 PL.PRICE_LINE_ID
            into P_PRICE,
                 P_MONTH_DISCOUNT,
                 LS_COMPET_ATTR,
                 ON_PRICE_LINE_ID
            from t_bd_price_line pl
           where pl.price_list_id = P_PRICE_LIST_ID
             and pl.item_code = P_ITEM_CODE
             and pl.channel_attr is null
             AND (PL.END_DATE IS NULL OR PL.END_DATE >= P_BILL_DATE)
             AND P_BILL_DATE >= PL.BEGIN_DATE
                /*and P_BILL_DATE >= to_char(nvl(pl.begin_date,to_date(P_BILL_DATE,'YYYYMMDD')-1), 'YYYYMMDD')
                and P_BILL_DATE <= to_char(nvl(pl.end_date,to_date(P_BILL_DATE,'YYYYMMDD')+1), 'YYYYMMDD')*/
             and 'Y' = pl.ACTIVE_FLAG
          --and rownum = 1
          ;
      end;
    
    else
      select pl.list_price,
             nvl(pl.discount, 0) discount,
             pl.competite_attr,
             PL.PRICE_LINE_ID
        into P_PRICE, P_MONTH_DISCOUNT, LS_COMPET_ATTR, ON_PRICE_LINE_ID
        from t_bd_price_line pl
       where pl.price_list_id = P_PRICE_LIST_ID
         and pl.item_code = P_ITEM_CODE
         and pl.channel_attr is null
         AND (PL.END_DATE IS NULL OR PL.END_DATE >= P_BILL_DATE)
         AND P_BILL_DATE >= PL.BEGIN_DATE
            /*and P_BILL_DATE >= to_char(nvl(pl.begin_date,to_date(P_BILL_DATE,'YYYYMMDD')-1), 'YYYYMMDD')
            and P_BILL_DATE <= to_char(nvl(pl.end_date,to_date(P_BILL_DATE,'YYYYMMDD')+1), 'YYYYMMDD')*/
         and 'Y' = pl.ACTIVE_FLAG
      --and rownum = 1
      ;
    end if;
    if (LS_COMPET_ATTR = 'PROMOTION') then
      --促销机
      P_CX_FLAG := 'Y';
    else
      P_CX_FLAG := 'N';
    end if;
  exception
    when NO_DATA_FOUND then
      P_PRICE          := null;
      P_MONTH_DISCOUNT := 0;
      P_CX_FLAG        := 'N';
  END;

  procedure P_MONTH_ITEM_COST
  -- 生成指定月份的销售成本
  
    --工厂人工 = 材料成本*（1+工费率）
    --销售成本 = 材料成本 + 制造费用 + 工厂人工
  
  (P_MONTH in varchar2, --年月：如:201407
   -- P_UPDATE_CNT     out number,
   P_RETURN_CODE out varchar2, --返回编码
   P_RETURN_MSG  out varchar2) --返回提示信息
   is
    TEMP_ITEM_CODE        t_bd_item_cost.item_code%type; --临时变量，产品编码
    TEMP_ITEM_ID          t_bd_item_cost.item_id%TYPE; --临时变量，产品ID
    TEMP_ITEM_NAME        t_bd_item_cost.item_name%TYPE; --临时变量，产品名称
    TEMP_ITEM_UOM         t_bd_item.defaultunit%TYPE; ----临时变量，产品单位
    TEMP_MTL_COST         t_bd_item_cost.item_cost%type; --临时变量，材料成本
    TEMP_MANUFACTURE_COST t_bd_price_cost_rate.manufacture_cost%type; --临时变量，材料成本
    TEMP_EXPECT_RATE      t_bd_price_cost_rate.expect_rate%type; --临时变量，预计工费率
    TEMP_ACTUAL_RATE      t_bd_price_cost_rate.actual_rate%type; --临时变量，实际工费率
  
    TEMP_PRICE_COST_NUM number; --查找当月已生成销售成本的记录
    TEMP_ITEM_COST_NUM  number; --通过判断指定月份是否配置工费率
    RT_UPDATE_NUM       number; --update记录条数
    RT_INSERT_NUM       number; --update记录条数
  
    --查询产品成本游标
    cursor c_item_cost is
      select ic.* from t_bd_item_cost ic;
    TEMP_ITEM_COST_ROW c_item_cost%ROWTYPE; --临时变量，记录成本表一条记录
  
  BEGIN
    RT_UPDATE_NUM := 0;
    RT_INSERT_NUM := 0;
    --1、判断是否维护当月工费率
    SELECT count(1)
      into TEMP_ITEM_COST_NUM
      from (select distinct (bi.sales_sub_type)
              from T_BD_ITEM_COST bic, t_bd_item bi
             where bi.item_code = bic.item_code
            MINUS
            select pcr.sales_sub_type
              from T_BD_PRICE_COST_RATE pcr
             where pcr.cost_month = P_MONTH
               and pcr.active_flag = 'Y');
    if (TEMP_ITEM_COST_NUM > 0) THEN
      --如果没有维护
      P_RETURN_CODE := 'failed';
      P_RETURN_MSG  := '没有维护' || P_MONTH || '月份的工费率';
      return;
    END IF;
  
    --2、判断该产品是否已有生成当月销售成本
    BEGIN
    
      OPEN c_item_cost; --打开游标
      LOOP
        FETCH c_item_cost
          INTO TEMP_ITEM_COST_ROW;
        EXIT WHEN c_item_cost%NOTFOUND;
      
        --获取该产品编码
        TEMP_ITEM_CODE := TEMP_ITEM_COST_ROW.ITEM_CODE;
        --获取该产品编码的材料成本、制造费用、预计工费率、实际工费率
        select item.item_id,
               item.item_name,
               item.defaultunit,
               nvl(ic.item_cost, 0),
               nvl(pcr.manufacture_cost, 0),
               nvl(pcr.expect_rate, 0),
               nvl(pcr.actual_rate, 0)
          INTO TEMP_ITEM_ID,
               TEMP_ITEM_NAME,
               TEMP_ITEM_UOM,
               TEMP_MTL_COST,
               TEMP_MANUFACTURE_COST,
               TEMP_EXPECT_RATE,
               TEMP_ACTUAL_RATE
          from t_bd_item_cost ic, t_bd_item item, t_bd_price_cost_rate pcr
         where item.item_code = ic.item_code
           and item.sales_sub_type = pcr.sales_sub_type
           and item.item_code = TEMP_ITEM_CODE
           and pcr.cost_month = P_MONTH;
      
        select count(2)
          INTO TEMP_PRICE_COST_NUM
          from dual
         where exists (SELECT *
                  FROM t_bd_price_cost pc
                 WHERE pc.item_code = TEMP_ITEM_CODE);
      
        IF TEMP_PRICE_COST_NUM > 0 THEN
          RT_UPDATE_NUM := RT_UPDATE_NUM + 1;
          --2.1如果已生成，则更新
          UPDATE T_BD_PRICE_COST pc
             SET pc.uom_code         = TEMP_ITEM_UOM,
                 pc.MTL_COST         = TEMP_MTL_COST,
                 pc.manufacture_cost = TEMP_MANUFACTURE_COST,
                 pc.EXPECT_RATE      = TEMP_EXPECT_RATE,
                 pc.ACTUAL_RATE      = TEMP_ACTUAL_RATE,
                 pc.expect_work_cost = TEMP_MTL_COST *
                                       (1 + TEMP_EXPECT_RATE),
                 pc.actual_work_cost = TEMP_MTL_COST *
                                       (1 + TEMP_ACTUAL_RATE),
                 pc.expect_price     = TEMP_MTL_COST + TEMP_MANUFACTURE_COST +
                                       TEMP_MTL_COST *
                                       (1 + TEMP_EXPECT_RATE),
                 pc.actual_price     = TEMP_MTL_COST + TEMP_MANUFACTURE_COST +
                                       TEMP_MTL_COST *
                                       (1 + TEMP_ACTUAL_RATE)
           where pc.cost_month = P_MONTH
             and pc.item_code = TEMP_ITEM_CODE;
        
        ELSE
          RT_INSERT_NUM := RT_INSERT_NUM + 1;
          --2.2 如果没有生成，则插入
          insert into T_BD_PRICE_COST
            (PRICE_COST_ID,
             ITEM_ID,
             ITEM_CODE,
             ITEM_NAME,
             UOM_CODE， --产品单位
             MTL_COST, --材料成本
             MANUFACTURE_COST, --制造费用
             COST_MONTH, --成本月
             EXPECT_RATE, --预计工费率
             ACTUAL_RATE, --实际工费率
             EXPECT_WORK_COST, --预计人工成本
             ACTUAL_WORK_COST, --实际人工成本
             EXPECT_PRICE, --预计销售成本
             ACTUAL_PRICE --实际销售成本
             )
          VALUES
            (seq_bd_row_id.nextval,
             TEMP_ITEM_ID,
             TEMP_ITEM_CODE,
             TEMP_ITEM_NAME,
             TEMP_ITEM_UOM， TEMP_MTL_COST,
             TEMP_MANUFACTURE_COST,
             P_MONTH,
             TEMP_EXPECT_RATE,
             TEMP_ACTUAL_RATE,
             TEMP_MTL_COST * (1 + TEMP_EXPECT_RATE),
             TEMP_MTL_COST * (1 + TEMP_ACTUAL_RATE),
             TEMP_MTL_COST + TEMP_MANUFACTURE_COST +
             TEMP_MTL_COST * (1 + TEMP_EXPECT_RATE),
             TEMP_MTL_COST + TEMP_MANUFACTURE_COST +
             TEMP_MTL_COST * (1 + TEMP_ACTUAL_RATE));
        END IF;
      
      END LOOP;
      commit;
      CLOSE c_item_cost; --关闭游标
    
    END;
    P_RETURN_CODE := 'succesed';
    P_RETURN_MSG  := '成功引入销售成本：新增' || RT_INSERT_NUM || '条，修改' ||
                     RT_UPDATE_NUM || '条';
  exception
    when others then
      rollback;
      P_RETURN_CODE := 'failed';
      P_RETURN_MSG  := PKG_BD.F_ADD_ERROR_LOG('PKG_BD.P_MONTH_ITEM_COST',
                                              sqlcode,
                                              '销售成本计算失败' || sqlerrm);
  END;

  procedure P_APPLY_LOCK
  -- 提货订单评审时
    -- 价格申请锁，PriceApplyBO.lock('批文明细ID','占用数量’,'关联单号' )
  (P_APPLY_DETAIL_ID in T_BD_PRICE_APPLY_DETAIL.APPLY_DETAIL_ID%TYPE, --批文明细ID
   P_LOCK_CNT        IN NUMBER, --锁定数量,正数
   P_BILL_NO         IN VARCHAR2, -- 关联单号
   P_RETURN_CODE     out varchar2, --返回编码，1成功，0失败
   P_RETURN_MSG      out varchar2) is
    --返回提示信息
  
    LD_USABLE_CNT NUMBER;
    V_COMMON_TIP  VARCHAR2(3000) := ''; --通用提示信息  add by zhoujg3 2016-07-20
  begin
    V_COMMON_TIP := '锁定操作：批文行 APPLY_DETAIL_ID[' || P_APPLY_DETAIL_ID ||
                    '],数量[' || P_LOCK_CNT || '],关联单号[' || P_BILL_NO || '] ';
  
    --1、获取可用数量
    select (APPLY_CNT - NVL(USED_CNT, 0) - NVL(LOCK_CNT, 0)) applyCnt
      into LD_USABLE_CNT
      from T_BD_PRICE_APPLY_DETAIL
     where APPLY_DETAIL_ID = P_APPLY_DETAIL_ID;
    --2.1、如果锁定数量超出可用量，返回0失败
    IF LD_USABLE_CNT < P_LOCK_CNT THEN
      P_RETURN_CODE := '0';
      P_RETURN_MSG  := V_COMMON_TIP || '可用余额不足[可用数：' || LD_USABLE_CNT ||
                       ',本次锁定数：' || P_LOCK_CNT || '],不能执行锁定！';
      return;
    else
      --2.2、否则更新锁定数量，插入锁定明细，并返回1成功
      update T_BD_PRICE_APPLY_DETAIL
         set LOCK_CNT = P_LOCK_CNT + nvl(LOCK_CNT, 0)
       where APPLY_DETAIL_ID = P_APPLY_DETAIL_ID;
      insert into T_BD_PRICE_APPLY_DETAIL_HIS
        (DETAIL_HIS_ID,
         BILL_NO,
         OPERATE_TYPE,
         OPERATE_CNT,
         APPLY_DETAIL_ID,
         CREATED_BY,
         CREATION_DATE)
      values
        (seq_bd_row_id.nextval,
         P_BILL_NO,
         'O',
         P_LOCK_CNT,
         P_APPLY_DETAIL_ID,
         'SYS',
         sysdate);
    
    END IF;
  
    P_RETURN_CODE := '1';
    P_RETURN_MSG  := '执行成功';
    -- end;
  exception
    when others then
      P_RETURN_CODE := '0';
      P_RETURN_MSG  := V_COMMON_TIP || '执行异常：' || sqlerrm;
  end;

  procedure P_APPLY_UNLOCK
  -- 价格申请解锁（提货订单评审驳回时），PriceApplyBO.unlock(‘批文明细ID’，'解锁数量’，‘关联单号’ )
  (P_APPLY_DETAIL_ID in T_BD_PRICE_APPLY_DETAIL.APPLY_DETAIL_ID%TYPE, --批文明细ID
   P_UNLOCK_CNT      IN NUMBER, --解除锁定数量
   P_BILL_NO         IN VARCHAR2, -- 关联单号
   P_RETURN_CODE     out varchar2, --返回编码，1成功，0失败
   P_RETURN_MSG      out varchar2) is
    --返回提示信息
  
    LD_LOCK_CNT  NUMBER;
    V_COMMON_TIP VARCHAR2(3000) := ''; --通用提示信息  add by zhoujg3 2016-07-20
  begin
    V_COMMON_TIP := '解锁操作：批文行 APPLY_DETAIL_ID[' || P_APPLY_DETAIL_ID ||
                    '],数量[' || P_UNLOCK_CNT || '],关联单号[' || P_BILL_NO || '] ';
  
    --1、获取锁定数量
    select NVL(LOCK_CNT, 0) lockCnt
      into LD_LOCK_CNT
      from T_BD_PRICE_APPLY_DETAIL
     where APPLY_DETAIL_ID = P_APPLY_DETAIL_ID;
    --2.1、如果解锁数据大于锁定数量，返回0失败
    IF LD_LOCK_CNT < P_UNLOCK_CNT THEN
      P_RETURN_CODE := '0';
      P_RETURN_MSG  := V_COMMON_TIP || '解锁数量[' || P_UNLOCK_CNT ||
                       ']大于锁定数量[' || LD_LOCK_CNT || ']，不能执行解锁！';
      return;
    else
      --2.2、否则更新锁定数量，插入锁定明细，并返回1成功
      update T_BD_PRICE_APPLY_DETAIL
         set LOCK_CNT = LOCK_CNT - P_UNLOCK_CNT
       where APPLY_DETAIL_ID = P_APPLY_DETAIL_ID;
      insert into T_BD_PRICE_APPLY_DETAIL_HIS
        (DETAIL_HIS_ID,
         BILL_NO,
         OPERATE_TYPE,
         OPERATE_CNT,
         APPLY_DETAIL_ID,
         CREATED_BY,
         CREATION_DATE)
      values
        (seq_bd_row_id.nextval,
         P_BILL_NO,
         'R',
         -P_UNLOCK_CNT,
         P_APPLY_DETAIL_ID,
         'SYS',
         sysdate);
    
    END IF;
  
    P_RETURN_CODE := '1';
    P_RETURN_MSG  := '执行成功';
    -- end;
  exception
    when others then
      P_RETURN_CODE := '0';
      P_RETURN_MSG  := V_COMMON_TIP || '执行异常：' || sqlerrm;
  end;

  procedure P_APPLY_EXECUTE
  -- 价格申请执行（生成销售单时），PriceApplyBO.execute('批文明细ID'，'占用数量’,'关联单号’ ,'更新锁标识')，
  (P_APPLY_DETAIL_ID in T_BD_PRICE_APPLY_DETAIL.APPLY_DETAIL_ID%TYPE, --批文明细ID
   P_EXE_CNT         IN NUMBER, --执行数量,正数
   P_BILL_NO         IN VARCHAR2, -- 关联单号
   P_UPDATE_LOCK     IN VARCHAR2, --更新锁标识为Y，则需要解锁
   P_RETURN_CODE     out varchar2, --返回编码，1成功，0失败
   P_RETURN_MSG      out varchar2) is
    --返回提示信息
  
    LD_LOCK_CNT   NUMBER;
    LD_USABLE_CNT NUMBER;
    V_COMMON_TIP  VARCHAR2(3000) := ''; --通用提示信息  add by zhoujg3 2016-07-20
  begin
    V_COMMON_TIP := '执行操作：批文行 APPLY_DETAIL_ID[' || P_APPLY_DETAIL_ID ||
                    '],数量[' || P_EXE_CNT || '],关联单号[' || P_BILL_NO ||
                    '],标识[' || P_UPDATE_LOCK || '] ';
  
    --2.1、如果更新锁，则更新锁定数量=锁定数量-P_EXE_CNT，流水记录释放P_EXE_CNT
    IF P_UPDATE_LOCK = 'Y' THEN
      --2.1.1 判断可解锁数量
      select NVL(LOCK_CNT, 0) applyCnt
        into LD_LOCK_CNT
        from T_BD_PRICE_APPLY_DETAIL
       where APPLY_DETAIL_ID = P_APPLY_DETAIL_ID;
      if P_EXE_CNT > LD_LOCK_CNT then
        P_RETURN_CODE := '0';
        P_RETURN_MSG  := V_COMMON_TIP || '执行失败，执行数量[' || P_EXE_CNT ||
                         ']超出可解锁数量[' || LD_LOCK_CNT || ']！';
        return;
      end if;
      update T_BD_PRICE_APPLY_DETAIL
         set LOCK_CNT = LOCK_CNT - P_EXE_CNT
       where APPLY_DETAIL_ID = P_APPLY_DETAIL_ID;
      insert into T_BD_PRICE_APPLY_DETAIL_HIS
        (DETAIL_HIS_ID,
         BILL_NO,
         OPERATE_TYPE,
         OPERATE_CNT,
         APPLY_DETAIL_ID,
         CREATED_BY,
         CREATION_DATE)
      values
        (seq_bd_row_id.nextval,
         P_BILL_NO,
         'R',
         -P_EXE_CNT,
         P_APPLY_DETAIL_ID,
         'SYS',
         sysdate);
    END IF;
    --2.2、否则执行数量P_EXE_CNT，流水记录执行P_EXE_CNT
    select (APPLY_CNT - NVL(USED_CNT, 0) - NVL(LOCK_CNT, 0)) applyCnt
      into LD_USABLE_CNT
      from T_BD_PRICE_APPLY_DETAIL
     where APPLY_DETAIL_ID = P_APPLY_DETAIL_ID;
    if P_EXE_CNT > LD_USABLE_CNT then
      P_RETURN_CODE := '0';
      P_RETURN_MSG  := V_COMMON_TIP || '执行失败，执行数量[' || P_EXE_CNT ||
                       ']超出可用数量[' || LD_USABLE_CNT || ']！';
      return;
    end if;
  
    update T_BD_PRICE_APPLY_DETAIL
       set USED_CNT = P_EXE_CNT + nvl(USED_CNT, 0),
           LAST_SALES_DATE = SYSDATE
     where APPLY_DETAIL_ID = P_APPLY_DETAIL_ID;
    insert into T_BD_PRICE_APPLY_DETAIL_HIS
      (DETAIL_HIS_ID,
       BILL_NO,
       OPERATE_TYPE,
       OPERATE_CNT,
       APPLY_DETAIL_ID,
       CREATED_BY,
       CREATION_DATE)
    values
      (seq_bd_row_id.nextval,
       P_BILL_NO,
       'P',
       P_EXE_CNT,
       P_APPLY_DETAIL_ID,
       'SYS',
       sysdate);
  
    P_RETURN_CODE := '1';
    P_RETURN_MSG  := '执行成功';
    -- end;
  exception
    when others then
      P_RETURN_CODE := '0';
      P_RETURN_MSG  := V_COMMON_TIP || '执行异常：' || sqlerrm;
  end;

  procedure P_APPLY_UNEXECUTE
  -- 价格申请红冲（销售单红冲时），PriceApplyBO.unexecute('批文明细ID'，'占用数量’，'关联单号','更新锁标识' )，
  (P_APPLY_DETAIL_ID in T_BD_PRICE_APPLY_DETAIL.APPLY_DETAIL_ID%TYPE, --批文明细ID
   P_UNEXE_CNT       IN NUMBER, --红冲数量,正数
   P_BILL_NO         IN VARCHAR2, -- 关联单号
   P_UPDATE_LOCK     IN VARCHAR2, --更新锁标识为Y，则需要解锁
   P_RETURN_CODE     out varchar2, --返回编码，1成功，0失败
   P_RETURN_MSG      out varchar2) is
    --返回提示信息
  
    LD_LOCK_CNT  NUMBER;
    V_COMMON_TIP VARCHAR2(3000) := ''; --通用提示信息  add by zhoujg3 2016-07-20
  begin
    V_COMMON_TIP := '反执行[红冲]操作：批文行 APPLY_DETAIL_ID[' || P_APPLY_DETAIL_ID ||
                    '],数量[' || P_UNEXE_CNT || '],关联单号[' || P_BILL_NO ||
                    '],标识[' || P_UPDATE_LOCK || '] ';
  
    --2.1、如果更新锁，则重新占用锁，更新锁定数量=锁定数量+P_UNEXE_CNT，流水记录锁定P_UNEXE_CNT
    IF P_UPDATE_LOCK = 'Y' THEN
      P_APPLY_LOCK(P_APPLY_DETAIL_ID,
                   P_UNEXE_CNT,
                   P_BILL_NO,
                   P_RETURN_CODE,
                   P_RETURN_MSG);
      if P_RETURN_CODE = '0' then
        return;
      end if;
    END IF;
    --2.2、否则执行数量P_UNEXE_CNT，流水记录执行P_UNEXE_CNT
    update T_BD_PRICE_APPLY_DETAIL
       set USED_CNT = nvl(USED_CNT, 0) - P_UNEXE_CNT,
           LAST_SALES_DATE = SYSDATE
     where APPLY_DETAIL_ID = P_APPLY_DETAIL_ID;
    insert into T_BD_PRICE_APPLY_DETAIL_HIS
      (DETAIL_HIS_ID,
       BILL_NO,
       OPERATE_TYPE,
       OPERATE_CNT,
       APPLY_DETAIL_ID,
       CREATED_BY,
       CREATION_DATE)
    values
      (seq_bd_row_id.nextval,
       P_BILL_NO,
       'P',
       -P_UNEXE_CNT,
       P_APPLY_DETAIL_ID,
       'SYS',
       sysdate);
    P_RETURN_CODE := '1';
    P_RETURN_MSG  := '执行成功';
  
    -- end;
  exception
    when others then
      P_RETURN_CODE := '0';
      P_RETURN_MSG  := V_COMMON_TIP || '执行异常：' || sqlerrm;
  end;

  -----------------------------------------------------------------------------
  --  取价格列表ID           --
  -----------------------------------------------------------------------------
  PROCEDURE P_GET_PRICE_LIST_ID(P_ENTITY_ID     IN NUMBER,
                                P_ACC_ID        IN t_customer_account.account_id%type, --账户ID
                                P_BILL_DATE     IN VARCHAR2, --单据日期
                                P_PRICE_LIST_ID OUT NUMBER, --价格列表ID
                                P_MESSAGE       out VARCHAR2 --返回是否促销机
                                ) is
    LD_CUSR_ID       t_customer_account.customer_id%type;
    LD_UNIT_ID       up_org_unit.unit_id%type;
    LD_SYSTEM_ID     t_bd_price_system.price_system_id%type;
    priceSystemCust  t_bd_price_system_cust%ROWTYPE;
    LD_PRICE_LIST_ID t_bd_price_list.price_list_id%type;
  
    priceSystemOrg t_bd_price_system_org%ROWTYPE;
    priceSystem    t_bd_price_system%ROWTYPE;
    LD_CUST_CNT    number;
    LD_ORG_CNT     number;
    LD_CNT         number;
  
  begin
    P_MESSAGE := 'OK';
  
    if (P_PRICE_LIST_ID is null) then
      --2、如果价格列表为空，则从价格体系上定位到具体价格列表，并从价格列表上取价格
      --2.1 根据账户ID、找对应的客户
      select customer_id
        into LD_CUSR_ID
        from t_customer_account
       where account_id = P_ACC_ID
         and entity_id = P_ENTITY_ID;
      --2.2 根据账户ID、找对应的中心
      select co.sales_center_id
        into LD_UNIT_ID
        from t_customer_acc_org_relation rl, t_customer_org co
       where rl.customer_org_id = co.customer_org_id
         and rl.account_id = P_ACC_ID
         and co.entity_id = P_ENTITY_ID;
      --and active_flag = 'Y';
      --2.3 根据单据日期找到对应的价格体系，并找到对应的价格列表ID、折扣率
      select price_system_id
        into LD_SYSTEM_ID
        from t_bd_price_system ps
       where P_BILL_DATE >= to_char(ps.begin_date, 'YYYYMMDD')
         and P_BILL_DATE <=
             to_char(nvl(ps.end_date, to_date(P_BILL_DATE, 'YYYYMMDD') + 1),
                     'YYYYMMDD')
         and ps.entity_id = P_ENTITY_ID
         and ps.active_flag = 'Y';
    
      select count(1)
        into LD_CUST_CNT
        from t_bd_price_system_cust sc
       where sc.price_system_id = LD_SYSTEM_ID
         and sc.sales_center_id = LD_UNIT_ID
         and sc.customer_id = LD_CUSR_ID
         and sc.active_flag = 'Y';
      --2.4判断是否找到客户关联价格列表
      if (LD_CUST_CNT > 0) then
        select sc.*
          into priceSystemCust
          from t_bd_price_system_cust sc
         where sc.price_system_id = LD_SYSTEM_ID
           and sc.sales_center_id = LD_UNIT_ID
           and sc.customer_id = LD_CUSR_ID
           and sc.active_flag = 'Y';
      
        --P_DISCOUNT := priceSystemCust.Discount;
        LD_PRICE_LIST_ID := priceSystemCust.Price_List_Id;
      else
        --2.5 如果没找到客户价格，则取对应中心价格列表
        select count(1)
          into LD_ORG_CNT
          from t_bd_price_system_org so
         where so.price_system_id = LD_SYSTEM_ID
           and so.sales_center_id = LD_UNIT_ID
           and so.active_flag = 'Y';
        if (LD_ORG_CNT > 0) then
          select so.*
            into priceSystemOrg
            from t_bd_price_system_org so
           where so.price_system_id = LD_SYSTEM_ID
             and so.sales_center_id = LD_UNIT_ID
             and so.active_flag = 'Y';
        
          --P_DISCOUNT := priceSystemOrg.Discount;
          LD_PRICE_LIST_ID := priceSystemOrg.Price_List_Id;
        else
          --2.6 如果没找到中心价格列表，则取总部默认价格列表
          select ps.*
            into priceSystem
            from t_bd_price_system ps
           where ps.price_system_id = LD_SYSTEM_ID
             and ps.active_flag = 'Y';
        
          --P_DISCOUNT := 0;
          LD_PRICE_LIST_ID := priceSystem.bu_price_list_id;
        
          --DBMS_OUTPUT.PUT_LINE('总部P_PRICE_LIST_ID: '||LD_PRICE_LIST_ID);
        END IF;
      
      END IF;
      P_PRICE_LIST_ID := LD_PRICE_LIST_ID;
    END IF;
  
  END P_GET_PRICE_LIST_ID;

  -----------------------------------------------------------------------------
  --  取价格列表ID   根据中心        --add by wangcong   update by lixiuhan 20151107
  -----------------------------------------------------------------------------
  PROCEDURE P_GET_PRICE_LIST_ID_CENTER(P_ENTITY_ID         IN NUMBER,
                                       P_SALES_CENTER_CODE IN T_BD_PRICE_SYSTEM_ORG.SALES_CENTER_CODE%TYPE, --中心CODE
                                       P_BILL_DATE         IN VARCHAR2, --单据日期
                                       P_ITEM_CODE         IN T_BD_PRICE_LINE.ITEM_CODE%TYPE, --产品编码
                                       P_PRICE             OUT NUMBER, --价格
                                       P_MONTH_DISCOUNT    OUT NUMBER, --月返
                                       P_MESSAGE           OUT VARCHAR2 --返回提示信息
                                       ) IS
    P_PRICE_SYS_ID         NUMBER; --价格体系ID
    P_BU_PRICE_LIST_ID     T_BD_PRICE_SYSTEM.Bu_Price_List_Id%TYPE; --价格体系价格列表ID
    V_BILL_DATE            DATE;
    P_PRICE_SYS_CNT        NUMBER; --价格体系数量
    P_CENTER_PRICE_SYS_CNT NUMBER; --中心价格体系数量
    R_PRICE_SYS_CENTER     T_BD_PRICE_SYSTEM_ORG%ROWTYPE; --中心价格体系记录
    P_PRICE_LIST_ID        NUMBER; --价格列表ID
    P_PRICE_LINE_CNT       NUMBER; --价格列表行数量
    R_PRICE_LINE           T_BD_PRICE_LINE%ROWTYPE; --价格列表行记录
    P_IS_METERIAL          T_BD_PRICE_SYSTEM.PRICE_TYPE%TYPE; --产品类型（物料、产品、推广物料）                                     --是否推广物料
    P_PRICE_LINE_CNT_NC    NUMBER; --价格列表行数量
  BEGIN
    P_MESSAGE := 'SUCCESS';
    V_BILL_DATE := TO_DATE(P_BILL_DATE,'YYYYMMDD');
  
    --取是否推广物料
    SELECT DECODE(TBI.IS_MATERIAL, 'Y', 'T', 'C')
      INTO P_IS_METERIAL
      FROM T_BD_ITEM TBI
     WHERE TBI.ITEM_CODE = P_ITEM_CODE
       AND TBI.ENTITY_ID = P_ENTITY_ID;
  
    --1、查询统计单据日期内的价格体系
    SELECT COUNT(*)
      INTO P_PRICE_SYS_CNT
      FROM T_BD_PRICE_SYSTEM TPS
     WHERE V_BILL_DATE >= TPS.BEGIN_DATE
       AND V_BILL_DATE <= nvl(TPS.END_DATE, V_BILL_DATE + 1)
       AND TPS.ENTITY_ID = P_ENTITY_ID
       AND TPS.ACTIVE_FLAG = 'Y'
       AND TPS.PRICE_TYPE = P_IS_METERIAL;
  
    IF P_PRICE_SYS_CNT = 1 THEN
      --1.1查找到对应的1条价格体系
      SELECT TPS.PRICE_SYSTEM_ID, TPS.BU_PRICE_LIST_ID
        INTO P_PRICE_SYS_ID, P_BU_PRICE_LIST_ID
        FROM T_BD_PRICE_SYSTEM TPS
       WHERE V_BILL_DATE >= TPS.BEGIN_DATE
         AND V_BILL_DATE <= nvl(TPS.END_DATE, V_BILL_DATE + 1)
         AND TPS.ENTITY_ID = P_ENTITY_ID
         AND TPS.ACTIVE_FLAG = 'Y'
         AND TPS.PRICE_TYPE = P_IS_METERIAL;
    
      --根据中心编码、价格体系ID，查找中心价格体系  
      SELECT COUNT(*)
        INTO P_CENTER_PRICE_SYS_CNT
        FROM T_BD_PRICE_SYSTEM_ORG TSO
       WHERE TSO.PRICE_SYSTEM_ID = P_PRICE_SYS_ID
         AND TSO.ACTIVE_FLAG = 'Y'
         AND TSO.SALES_CENTER_CODE = P_SALES_CENTER_CODE;
    
      IF P_CENTER_PRICE_SYS_CNT = 1 THEN
        --1.1.1查找到对应的1条中心价格体系
        SELECT *
          INTO R_PRICE_SYS_CENTER
          FROM T_BD_PRICE_SYSTEM_ORG BSO
         WHERE BSO.PRICE_SYSTEM_ID = P_PRICE_SYS_ID
           AND BSO.ACTIVE_FLAG = 'Y'
           AND BSO.SALES_CENTER_CODE = P_SALES_CENTER_CODE;
      
        --取价格列表ID
        P_PRICE_LIST_ID := R_PRICE_SYS_CENTER.PRICE_LIST_ID;
      
      ELSIF P_CENTER_PRICE_SYS_CNT > 1 THEN
        --1.1.2查找到多条中心价格体系
        P_MESSAGE := '中心对应不能对应多个价格列表';
        RETURN;
      
      ELSE
        --1.1.3没有查找到中心价格体系，则取价格体系的价格
        P_PRICE_LIST_ID := P_BU_PRICE_LIST_ID;
      END IF;
    
      --1.1.4取得价格列表后，再去取产品价格
      --根据价格列表ID和产品查询价格
      SELECT COUNT(0),COUNT(DECODE(BPL.CHANNEL_ATTR,NULL,0))
        INTO P_PRICE_LINE_CNT,P_PRICE_LINE_CNT_NC
        FROM T_BD_PRICE_LINE BPL
       WHERE BPL.PRICE_LIST_ID = P_PRICE_LIST_ID
         AND BPL.ITEM_CODE = P_ITEM_CODE
         AND V_BILL_DATE >= BPL.BEGIN_DATE
         AND V_BILL_DATE <= nvl(BPL.END_DATE, V_BILL_DATE + 1)
         --
         --AND BPL.CHANNEL_ATTR IS NULL
         AND 'Y' = BPL.ACTIVE_FLAG;
    
      IF 1 = P_PRICE_LINE_CNT_NC THEN
      --IF P_PRICE_LINE_CNT = 1 THEN
      --IF P_PRICE_LINE_CNT >= 1 THEN
        --1.1.4.1取价产品价格
        --SELECT * INTO R_PRICE_LINE FROM (
        SELECT * INTO R_PRICE_LINE 
          FROM T_BD_PRICE_LINE BPL
         WHERE BPL.PRICE_LIST_ID = P_PRICE_LIST_ID
           AND BPL.ITEM_CODE = P_ITEM_CODE
           AND V_BILL_DATE >= BPL.BEGIN_DATE
           AND V_BILL_DATE <= nvl(BPL.END_DATE,V_BILL_DATE + 1)
           --ADD BY LIANGYM2 无客户业态类型参数，为了避免取到多条，限制CHANNEL_ATTR为空？
           AND BPL.CHANNEL_ATTR IS NULL
           AND 'Y' = BPL.ACTIVE_FLAG
           --ORDER BY DECODE(BPL.CHANNEL_ATTR,NULL,0,1)
           --) WHERE 1 = ROWNUM
           ;
      
        P_PRICE          := R_PRICE_LINE.LIST_PRICE;
        P_MONTH_DISCOUNT := R_PRICE_LINE.DISCOUNT;
      ELSIF P_PRICE_LINE_CNT > 1 THEN
        --1.1.4.2取价产品价格
        P_MESSAGE := '单据时间内产品查询到多个价格';
        RETURN;
      ELSE
        --1.1.4.3取价产品价格
        P_MESSAGE := '单据时间内查没有询到产品价格';
        RETURN;
      END IF;
    
    ELSIF P_PRICE_SYS_CNT > 1 THEN
      --1.2查找到对应的多条价格体系
      P_MESSAGE := '单据时间内查询到多个价格体系';
      RETURN;
    ELSE
      --1.3没有查找到对应的价格体系
      P_MESSAGE := '单据时间内未查询到价格体系';
      RETURN;
    END IF;
  
  END;

  -----------------------------------------------------------------------------
  --  价格列表同步（从总部主体同步到对应的销售公司主体）
  -----------------------------------------------------------------------------
  PROCEDURE P_SYN_PRICE_LIST(ON_RESULT  OUT NUMBER, --成功则返回0，否则返回对应的出错代码。
                             OS_MESSAGE OUT VARCHAR2 --成功返回“SUCCESS”；失败返回出错信息。
                             ) IS
    --来源价格列表ID
    N_SOURCE_PRICE_LIST_ID T_BD_PRICE_SYN_RELA.SOURCE_PRICE_LIST_ID % TYPE;
    --来源主体ID
    N_SOURCE_ENTITY_ID T_BD_PRICE_SYN_RELA.SOURCE_ENTITY_ID % TYPE;
    --目标价格列表ID
    N_TARGET_PRICE_LIST_ID T_BD_PRICE_SYN_RELA.TARGET_PRICE_LIST_ID % TYPE;
    --目标主体ID
    N_TARGET_ENTITY_ID T_BD_PRICE_SYN_RELA.TARGET_ENTITY_ID % TYPE;
    --税率
    N_TAX_RATE T_BD_PRICE_SYN_RELA.TAX_RATE % TYPE;
  
    --价格列表同步关系表游标
    CURSOR C_BD_PRICE_SYN_RELA IS
      SELECT * FROM T_BD_PRICE_SYN_RELA;
  
  BEGIN
    ON_RESULT  := 0;
    OS_MESSAGE := 'SUCCESS';
  
    FOR PRICE_SYN_RELA_ROW IN C_BD_PRICE_SYN_RELA LOOP
      N_SOURCE_PRICE_LIST_ID := PRICE_SYN_RELA_ROW.SOURCE_PRICE_LIST_ID;
      N_SOURCE_ENTITY_ID     := PRICE_SYN_RELA_ROW.SOURCE_ENTITY_ID;
      N_TARGET_PRICE_LIST_ID := PRICE_SYN_RELA_ROW.TARGET_PRICE_LIST_ID;
      N_TARGET_ENTITY_ID     := PRICE_SYN_RELA_ROW.TARGET_ENTITY_ID;
      N_TAX_RATE             := PRICE_SYN_RELA_ROW.TAX_RATE;
    
      --在目标价格列表中按产品编码、渠道属性、启用日期、终止日期、有效标识
      --检查是否在来源价格列表中存在，不存在则删除对应的目标价格列表行。
      BEGIN
        DELETE FROM T_BD_PRICE_LINE T1
         WHERE T1.PRICE_LIST_ID = N_TARGET_PRICE_LIST_ID
           AND T1.ENTITY_ID = N_TARGET_ENTITY_ID
           AND NOT EXISTS
         (SELECT 1
                  FROM T_BD_PRICE_LINE T2, T_BD_ITEM T3
                 WHERE T2.PRICE_LIST_ID = N_SOURCE_PRICE_LIST_ID
                   --AND T2.ITEM_CODE = T1.ITEM_CODE
                   --改为通过产品表关联，利用产品表的唯一索引加快过滤
                   AND T2.ITEM_ID = T3.ITEM_ID
                   AND T3.ITEM_CODE = T1.ITEM_CODE
                   AND T3.ENTITY_ID = N_SOURCE_ENTITY_ID
                   AND NVL(T2.CHANNEL_ATTR, '1') = NVL(T1.CHANNEL_ATTR, '1')
                   --AND T2.LIST_PRICE = T1.LIST_PRICE 不需要判断价格相等
                   AND T2.BEGIN_DATE = T1.BEGIN_DATE
                   AND ((T2.END_DATE = T1.END_DATE) OR
                       (T2.END_DATE IS NULL AND T1.END_DATE IS NULL))
                   AND T2.ACTIVE_FLAG = T1.ACTIVE_FLAG);
      EXCEPTION
        WHEN OTHERS THEN
          ON_RESULT  := 1;
          OS_MESSAGE := '删除目标价格列表行失败！' || SQLERRM;
      END;
    
      --在来源价格列表中取渠道属性为空的内容，按产品编码、启用日期、终止日期
      --检查是否在目标价格列表中存在，不存在则插入到目标价格列表行中。    
      BEGIN
        INSERT INTO T_BD_PRICE_LINE
          (PRICE_LINE_ID,
           PRICE_LIST_ID,
           ITEM_ID,
           ITEM_CODE,
           ITEM_NAME,
           COMPETITE_ATTR,
           CHANNEL_ATTR,
           UNIT_CODE,
           LIST_PRICE,
           FLOOR_PRICE,
           COST_PRICE,
           RETAIL_PRICE,
           DISCOUNT,
           BEGIN_DATE,
           END_DATE,
           CREATED_BY,
           CREATION_DATE,
           LAST_UPDATED_BY,
           LAST_UPDATE_DATE,
           REMARK,
           ENTITY_ID,
           ACTIVE_FLAG,
           UQ_CHECK_FLAG)
          SELECT SEQ_BD_ROW_ID.NEXTVAL,
                 N_TARGET_PRICE_LIST_ID,
                 T2.ITEM_ID,
                 T2.ITEM_CODE,
                 T2.ITEM_NAME,
                 T1.COMPETITE_ATTR,
                 T1.CHANNEL_ATTR,
                 T1.UNIT_CODE,
                 ROUND(T1.LIST_PRICE / NVL(N_TAX_RATE, 1), 4),
                 T1.FLOOR_PRICE,
                 T1.COST_PRICE,
                 T1.RETAIL_PRICE,
                 T1.DISCOUNT,
                 T1.BEGIN_DATE,
                 T1.END_DATE,
                 'admin',
                 SYSDATE,
                 'admin',
                 SYSDATE,
                 T1.REMARK,
                 N_TARGET_ENTITY_ID,
                 'Y',
                 0
            FROM T_BD_PRICE_LINE T1, T_BD_ITEM T2
           WHERE T1.PRICE_LIST_ID = N_SOURCE_PRICE_LIST_ID
             AND T1.ENTITY_ID = N_SOURCE_ENTITY_ID
             AND T1.CHANNEL_ATTR IS NULL
             AND T1.ACTIVE_FLAG = 'Y'
             AND T1.ITEM_CODE = T2.ITEM_CODE
             AND T2.ENTITY_ID = N_TARGET_ENTITY_ID
             AND NOT EXISTS
           (SELECT 1
                    FROM T_BD_PRICE_LINE T3
                   WHERE T3.PRICE_LIST_ID = N_TARGET_PRICE_LIST_ID
                     AND T3.ITEM_ID = T2.ITEM_ID
                     --AND T3.LIST_PRICE = T1.LIST_PRICE 不需要判断价格相等
                     AND T3.BEGIN_DATE = T1.BEGIN_DATE
                     AND ((T3.END_DATE = T1.END_DATE) OR
                         (T3.END_DATE IS NULL AND T1.END_DATE IS NULL)));
      EXCEPTION
        WHEN OTHERS THEN
          ON_RESULT  := 2;
          OS_MESSAGE := '插入目标价格列表行失败！' || SQLERRM;
      END;
    END LOOP;
  END;
  ----------------------------------------------------------------------
  -- Author  : huanghb12
  -- Created : 2018/04/20 16:34:40
  -- Purpose : 检查临时表INTF_BD_PRICE_LINE_TMP数据的有效性     
  ----------------------------------------------------------------------
PROCEDURE P_CHECK_ITEM_INFO_FROM_ERP(P_POST_DATE IN VARCHAR2, P_RESULT OUT VARCHAR2)  
  Is Pragma Autonomous_Transaction;
   v_Nl      Constant Varchar2(2) := Chr(13) || Chr(10); --换行
   v_Success Constant Varchar2(10) := 'SUCCESS';
   
   V_VALUE        VARCHAR2(500); --存储信息
  
   V_POST_DATE  DATE := TO_DATE(P_POST_DATE,'YYYY-MM-DD HH24:MI:SS');
   
   
   BEGIN
     p_Result := v_Success;
     V_VALUE := '检测ERP产品数据的有效性';
     --验证数据的有效性,比对ims产品表中item_code是否存在,如果存在，则更新商品的id和商品名称
     MERGE INTO INTF_BD_PRICE_LINE_TMP MT
      USING (SELECT DISTINCT IT.Intf_Id, T.ITEM_ID,T.ITEM_NAME,T.DEFAULTUNIT
              FROM CIMS.T_BD_ITEM T , INTF_BD_PRICE_LINE_TMP IT
              WHERE T.ITEM_CODE = IT.ITEM_CODE
              AND T.ENTITY_ID = IT.ENTITY_ID
              AND IT.POST_DATE = V_POST_DATE
              AND IT.INTF_STATUS = 'N'
              AND T.ACTIVE_FLAG = 'Y'
            ) UT
      ON (UT.Intf_Id = MT.Intf_Id)
      WHEN MATCHED THEN
        UPDATE
           SET MT.Item_Id   = UT.Item_Id,     --产品id
               MT.Item_Name = UT.Item_Name,   --产品名称
               MT.UNIT_CODE = UT.DEFAULTUNIT, --计量单位
               MT.ACTIVE_FLAG = 'Y';
      UPDATE INTF_BD_PRICE_LINE_TMP T  --标记无效数据,也算是处理成功，只是我们系统中没有这个产品而已
         SET T.ACTIVE_FLAG = 'N',      --表示这条是无效数据
             T.INTF_STATUS = 'S'       --N 新建、P 已提、S 成功、E 失败  标记已处理，
       WHERE (T.ITEM_ID IS NULL OR T.ITEM_ID = 0)
         AND T.ITEM_CODE IS NOT NULL
         AND T.POST_DATE = V_POST_DATE;  
       
       --处理接口表中当前批次有效的数据
       begin   
         V_VALUE := '处理接口表中当前批次且有效的数据';
         --对比接口表中当前批次的且有效的数据，T_BD_PRICE_LINE表，找出重复数据进行更新，新的数据则执行插入操作
         MERGE INTO T_BD_PRICE_LINE TL
          USING (SELECT DISTINCT L.PRICE_LINE_ID,IT.LIST_PRICE
                  FROM CIMS.T_BD_PRICE_LINE L , INTF_BD_PRICE_LINE_TMP IT
                  WHERE L.ITEM_CODE = IT.ITEM_CODE
                  AND L.PRICE_LIST_ID = IT.PRICE_LIST_ID
                  AND L.ACTIVE_FLAG = IT.ACTIVE_FLAG
                  AND L.ENTITY_ID = IT.ENTITY_ID
                  AND IT.ACTIVE_FLAG = 'Y'
                  AND IT.POST_DATE = V_POST_DATE
                  AND IT.INTF_STATUS = 'N'
                ) UT
          ON (UT.PRICE_LINE_ID = TL.PRICE_LINE_ID)
          WHEN MATCHED THEN
            UPDATE
               SET TL.LIST_PRICE   = UT.LIST_PRICE, --只修改列表价格，其它不变
                   TL.LAST_UPDATE_DATE = sysdate,
                   TL.LAST_UPDATED_BY = 'PROGRAM';
          --修改已处理的临时表数据
          V_VALUE := '修改已处理的临时表数据';         
          MERGE INTO INTF_BD_PRICE_LINE_TMP TL
          USING (SELECT DISTINCT IT.Intf_Id
                  FROM CIMS.T_BD_PRICE_LINE L , INTF_BD_PRICE_LINE_TMP IT
                  WHERE L.ITEM_CODE = IT.ITEM_CODE
		  AND L.PRICE_LIST_ID = IT.PRICE_LIST_ID
                  AND L.ACTIVE_FLAG = IT.ACTIVE_FLAG
                  AND L.ENTITY_ID = IT.ENTITY_ID
                  AND IT.ACTIVE_FLAG = 'Y'
                  AND IT.POST_DATE = V_POST_DATE
                  AND IT.INTF_STATUS = 'N'
                ) UT
          ON (UT.INTF_ID = TL.Intf_Id)
          WHEN MATCHED THEN
            UPDATE
               SET TL.INTF_STATUS = 'S';--改为已处理
               
               
           --将本批次、有效、未处理的数据INSERT到正式表  T_BD_PRICE_LINE          
          V_VALUE := '向正式表插入数据';
            INSERT INTO CIMS.T_BD_PRICE_LINE
                (	PRICE_LINE_ID,---- NUMBER NOT NULL ENABLE, 
                  PRICE_LIST_ID,---- NUMBER NOT NULL ENABLE, 
                  ITEM_ID,---- NUMBER NOT NULL ENABLE, 
                  ITEM_CODE,---- VARCHAR2(100) NOT NULL ENABLE, 
                  ITEM_NAME,---- VARCHAR2(240), 
                  COMPETITE_ATTR,---- VARCHAR2(32), 
                  CHANNEL_ATTR,---- VARCHAR2(32), 
                  UNIT_CODE,---- VARCHAR2(32), 
                  LIST_PRICE,---- NUMBER, 
                  FLOOR_PRICE,---- NUMBER, 
                  COST_PRICE,---- NUMBER, 
                  RETAIL_PRICE,---- NUMBER, 
                  DISCOUNT,---- NUMBER, 
                  BEGIN_DATE,---- DATE, 
                  END_DATE,---- DATE, 
                  CREATED_BY,---- VARCHAR2(32), 
                  CREATION_DATE,---- DATE, 
                  LAST_UPDATED_BY,---- VARCHAR2(32), 
                  LAST_UPDATE_DATE,---- DATE, 
                  REMARK,---- VARCHAR2(1000), 
                  ENTITY_ID,---- NUMBER, 
                  ACTIVE_FLAG,---- VARCHAR2(2) DEFAULT 'Y', 
                  ADJUST_LIST_ID,---- NUMBER, 
                  PROCESS_INSTANCE_ID,---- VARCHAR2(500), 
                  MODIFY_LIST_NUM,---- VARCHAR2(100), 
                  UQ_CHECK_FLAG,---- NUMBER DEFAULT 0 NOT NULL ENABLE, 
                  MODIFY_SOURCE---- VARCHAR2(5)
                 )
                SELECT 
                    SEQ_BD_ROW_ID.NEXTVAL, --确定序列 PRICE_LINE_ID
                    UT.PRICE_LIST_ID,---- NUMBER NOT NULL ENABLE, 
                    UT.ITEM_ID,---- NUMBER NOT NULL ENABLE, 
                    UT.ITEM_CODE,---- VARCHAR2(100) NOT NULL ENABLE, 
                    UT.ITEM_NAME,---- VARCHAR2(240), 
                    null,---- VARCHAR2(32), 
                    null,---- VARCHAR2(32), 
                    UT.UNIT_CODE,---- VARCHAR2(32), 
                    UT.LIST_PRICE,---- NUMBER, 
                    null,---- NUMBER, 
                    null,---- NUMBER, 
                    null,---- NUMBER, 
                    null,---- NUMBER, 
                    UT.BEGIN_DATE,---- DATE, 
                    null,---- DATE, 
                    'PROGRAM',---- VARCHAR2(32), 
                    sysdate,---- DATE, 
                    'PROGRAM',---- VARCHAR2(32), 
                    sysdate,---- DATE, 
                    null,---- VARCHAR2(1000), 
                    UT.ENTITY_ID,---- NUMBER, 
                    UT.ACTIVE_FLAG,---- VARCHAR2(2) DEFAULT 'Y', 
                    null,---- NUMBER, 
                    null,---- VARCHAR2(500), 
                    null,---- VARCHAR2(100), 
                    0,---- NUMBER DEFAULT 0 NOT NULL ENABLE, 
                    null---- VARCHAR2(5)
                  FROM INTF_BD_PRICE_LINE_TMP UT 
                  WHERE UT.ACTIVE_FLAG = 'Y'  --有效
                  AND UT.POST_DATE = V_POST_DATE     --本批次
                  AND UT.INTF_STATUS = 'N';          --未处理
         --全部处理完成后，修改接口表中的数据
         UPDATE INTF_BD_PRICE_LINE_TMP T  
           SET T.INTF_STATUS = 'S'       --N 新建、P 已提、S 成功、E 失败  标记已处理，
           WHERE T.ACTIVE_FLAG = 'Y'
             AND T.POST_DATE = V_POST_DATE
             AND T.INTF_STATUS = 'N'; 
       EXCEPTION
         WHEN OTHERS THEN
             p_Result := v_value || '，失败。' || v_nl || sqlerrm;
             --如果处理失败，则本批次（插入时间）所有插入的条目都标记为处理失败和无效
             UPDATE INTF_BD_PRICE_LINE_TMP T  --标记无效数据
               SET T.INTF_STATUS = 'E',       --N 新建、P 已提、S 成功、E 失败  
                   T.ACTIVE_FLAG = 'N'        --所有条目都置为无效
               WHERE T.POST_DATE = V_POST_DATE; 
       END;
       commit;
     EXCEPTION  --抓取整个范围的异常
    WHEN OTHERS THEN
      rollback;
      P_RESULT := '失败：' || P_RESULT || V_NL || SQLERRM;
      --如果处理失败，则本批次（插入时间）所有插入的条目都标记为处理失败和无效
       UPDATE INTF_BD_PRICE_LINE_TMP T  --标记无效数据
         SET T.INTF_STATUS = 'E',       --N 新建、P 已提、S 成功、E 失败  
             T.ACTIVE_FLAG = 'N'        --所有条目都置为无效
         WHERE T.POST_DATE = V_POST_DATE;
      commit;
  END;
  /*取价格列表行过程,入口过程，优惠品,返回价格列表头行id
     比P_GET_PRICE_LINE_YH 多返回价格列表头行ID
  */
  procedure P_GET_PRICE_LINE_YH_BACKID(IN_ACC_ID         IN t_customer_account.account_id%type, --账户ID
                                IS_ITEM_CODE      IN t_bd_item.item_code%type, --产品编码
                                IS_BILL_DATE      IN VARCHAR2, --单据日期 YYYYMMDD
                                IN_PRICE_LIST_ID  IN t_bd_price_list.price_list_id%type, --价格列表ID
                                IN_ENTITY_ID      IN up_org_unit.ENTITY_ID%type, --业务主体ID
                                ON_PRICE          out NUMBER, --返回价格
                                ON_DISCOUNT       out NUMBER, --返回折扣率
                                ON_MONTH_DISCOUNT out NUMBER, --返回月返
                                OS_CX_FLAG        out VARCHAR2, --返回是否促销机
                                OS_COMPE_ATTR     OUT VARCHAR2, --价格行的竞争属性
                                price_list_id out NUMBER, 
                                price_line_id out NUMBER
                                ) is
  
    LS_PRICE_MODE     varchar2(32);
    LD_PRICE          NUMBER;
    LD_DISCOUNT       NUMBER;
    LD_MONTH_DISCOUNT NUMBER;
    LS_CX_FLAG        varchar2(2);
    VN_PRICE_LINE_ID  NUMBER; --
  
  begin
    --初始化
    price_list_id:=0;
    price_line_id:=0;
    --优惠品
    -- BD_PRICE_MODE :(XSGS:销司多层级定价模式  JXS: 经销商模式)
    LS_PRICE_MODE := pkg_bd.F_GET_PARAMETER_VALUE('BD_PRICE_MODE',
                                                  IN_ENTITY_ID,
                                                  null,
                                                  null);
    if (LS_PRICE_MODE = 'XSGS') then
      --家用
      P_GET_PRICE_10_YH(IN_ENTITY_ID,
                        IN_ACC_ID,
                        IS_ITEM_CODE,
                        IS_BILL_DATE,
                        IN_PRICE_LIST_ID,
                        LD_PRICE,
                        LD_DISCOUNT,
                        LD_MONTH_DISCOUNT,
                        LS_CX_FLAG,
                        VN_PRICE_LINE_ID);
      --家电的没有取竞争属性
      IF VN_PRICE_LINE_ID > 0 THEN
        BEGIN
          SELECT price_line_id,price_list_id
            INTO price_line_id,price_list_id
            FROM T_BD_PRICE_LINE
           WHERE VN_PRICE_LINE_ID = PRICE_LINE_ID;
        EXCEPTION
          WHEN OTHERS THEN
            NULL;
        END;
      END IF;                
                        
    end if;
    if (LS_PRICE_MODE = 'JXS') then
      --厨电
      P_GET_PRICE_14_YH(IN_ENTITY_ID,
                        IN_ACC_ID,
                        IS_ITEM_CODE,
                        IS_BILL_DATE,
                        IN_PRICE_LIST_ID,
                        LD_PRICE,
                        LD_DISCOUNT,
                        LD_MONTH_DISCOUNT,
                        LS_CX_FLAG,
                        VN_PRICE_LINE_ID);
      IF VN_PRICE_LINE_ID > 0 THEN
        BEGIN
          SELECT COMPETITE_ATTR,price_line_id,price_list_id
            INTO OS_COMPE_ATTR,price_line_id,price_list_id
            FROM T_BD_PRICE_LINE
           WHERE VN_PRICE_LINE_ID = PRICE_LINE_ID;
        EXCEPTION
          WHEN OTHERS THEN
            NULL;
        END;
      END IF;
  
    end if;
  
    ON_PRICE          := LD_PRICE; --返回价格
    ON_DISCOUNT       := LD_DISCOUNT; --返回折扣率
    ON_MONTH_DISCOUNT := LD_MONTH_DISCOUNT; --返回月返
    OS_CX_FLAG        := LS_CX_FLAG; --返回是否促销机 
  
  end;
-------------------------------------------------------------------------------
  /*
    *   创建日期：2019-06-05
    *     创建者：zhouly2
     *   功能说明：取价格行后台接口方法,比 P_GET_PRICE_LINE 多返回价格列表行头ID
    */
  -------------------------------------------------------------------------------
  procedure P_GET_PRICE_LINE_BACKID(IN_ACC_ID         IN t_customer_account.account_id%type, --账户ID
                             IS_ITEM_CODE      IN t_bd_item.item_code%type, --产品编码
                             IS_BILL_DATE      IN VARCHAR2, --单据日期,YYYYMMDD
                             IN_PRICE_LIST_ID  IN t_bd_price_list.price_list_id%type, --价格列表ID
                             IN_ENTITY_ID      IN up_org_unit.ENTITY_ID%type, --业务主体ID
                             ON_PRICE          out NUMBER, --返回价格
                             ON_DISCOUNT       out NUMBER, --返回折扣率
                             ON_MONTH_DISCOUNT out NUMBER, --返回月返
                             OS_CX_FLAG        out VARCHAR2, --返回是否促销机
                             OS_COMPE_ATTR     OUT VARCHAR2, --价格行的竞争属性
                             price_list_id out number,
                             price_line_id out number
                             ) is
  
    LS_PRICE_MODE     varchar2(32);
    LD_PRICE          NUMBER;
    LD_DISCOUNT       NUMBER;
    LD_MONTH_DISCOUNT NUMBER;
    LS_CX_FLAG        varchar2(2);
    VN_PRICE_LINE_ID  NUMBER; --
    v_PLN_C2M_PRICE_PRIORITY varchar2(50); --定制机取价优先级
    v_C2m_Customized_Flag varchar2(2);  --是否定制机产品
    v_COMPE_ATTR     varchar2(32);
    V_COUNT          Number;
  
  begin
   --初始化
    price_list_id:=0;
    price_line_id:=0;                 
    -- BD_PRICE_MODE :(XSGS:销司多层级定价模式  JXS: 经销商模式)
    LS_PRICE_MODE := pkg_bd.F_GET_PARAMETER_VALUE('BD_PRICE_MODE',
                                                  IN_ENTITY_ID,
                                                  null,
                                                  null);
    --获取定制机取价优先级
    v_PLN_C2M_PRICE_PRIORITY := Pkg_Bd.f_Get_Parameter_Value('PLN_C2M_PRICE_PRIORITY',
                                                           IN_ENTITY_ID);
    --获取产品是否C2M定制产品
    Begin
      Select Count(1)
        Into V_COUNT
        From t_Bd_Item i
       Where i.Item_Code = IS_ITEM_CODE
         And i.Entity_Id = IN_ENTITY_ID
         And I.ITEM_CODE Like '71%';
      If V_COUNT > 0 Then
        v_C2m_Customized_Flag := 'Y';
      Else
        v_C2m_Customized_Flag := 'N';
      End If;
    Exception
      When Others Then
        v_C2m_Customized_Flag := 'N';
    End;
    
    if (LS_PRICE_MODE = 'XSGS') then
      --非定制机产品或者是定制机产品,且取价模式优先价格体系的，先取价格列表价格
      If v_C2m_Customized_Flag = 'N' Or (v_Pln_C2m_Price_Priority = 'PRICE' And
        v_C2m_Customized_Flag = 'Y') Then
        --家用
        P_GET_PRICE_10(IN_ENTITY_ID,
                       IN_ACC_ID,
                       IS_ITEM_CODE,
                       IS_BILL_DATE,
                       IN_PRICE_LIST_ID,
                       LD_PRICE,
                       LD_DISCOUNT,
                       LD_MONTH_DISCOUNT,
                       LS_CX_FLAG,
                       VN_PRICE_LINE_ID);
        IF VN_PRICE_LINE_ID > 0 THEN
          BEGIN
            SELECT price_line_id,price_list_id
              INTO price_line_id,price_list_id
              FROM T_BD_PRICE_LINE
             WHERE VN_PRICE_LINE_ID = PRICE_LINE_ID;
          EXCEPTION
            WHEN OTHERS THEN
              NULL;
          END;
        END IF;
        --定制机按价格体系取价，取不到，则在按选配项取价
        If v_C2m_Customized_Flag = 'Y'And LD_PRICE Is Null Then
          P_GET_PRICE_C2M(IN_ACC_ID,
                         IS_ITEM_CODE,
                         IS_BILL_DATE,
                         IN_PRICE_LIST_ID,
                         IN_ENTITY_ID,
                         LD_PRICE,
                         LD_DISCOUNT,
                         LD_MONTH_DISCOUNT,
                         LS_CX_FLAG,
                         v_COMPE_ATTR);
        End If;
      --如果是定制机产品，取价优先级是取选配项价格，先取选配项价格
      Elsif v_Pln_C2m_Price_Priority = 'C2M' And v_C2m_Customized_Flag = 'Y' Then
        P_GET_PRICE_C2M(IN_ACC_ID,
                       IS_ITEM_CODE,
                       IS_BILL_DATE,
                       IN_PRICE_LIST_ID,
                       IN_ENTITY_ID,
                       LD_PRICE,
                       LD_DISCOUNT,
                       LD_MONTH_DISCOUNT,
                       LS_CX_FLAG,
                       v_COMPE_ATTR);
        --按选配项取不到价格，则取价格体系价格
        --优先按选配价格取价的，取不到价后不找价格体系的价格列表价格 2020-5-6 lilh6
        /*If LD_PRICE Is Null Then
          --家用
          P_GET_PRICE_10(IN_ENTITY_ID,
                         IN_ACC_ID,
                         IS_ITEM_CODE,
                         IS_BILL_DATE,
                         IN_PRICE_LIST_ID,
                         LD_PRICE,
                         LD_DISCOUNT,
                         LD_MONTH_DISCOUNT,
                         LS_CX_FLAG,
                         VN_PRICE_LINE_ID);
          IF VN_PRICE_LINE_ID > 0 THEN
            BEGIN
              SELECT  price_line_id,price_list_id
                INTO  price_line_id,price_list_id
                FROM T_BD_PRICE_LINE
               WHERE VN_PRICE_LINE_ID = PRICE_LINE_ID;
            EXCEPTION
              WHEN OTHERS THEN
                NULL;
            END;
          END IF;
        End If;*/
      End If;                
    end if;
    if (LS_PRICE_MODE = 'JXS') then
      --非定制机产品或者是定制机产品,且取价模式优先价格体系的，先取价格列表价格
      If v_C2m_Customized_Flag = 'N' Or (v_Pln_C2m_Price_Priority = 'PRICE' And
        v_C2m_Customized_Flag = 'Y') Then
        --厨电
        P_GET_PRICE_14(IN_ENTITY_ID,
                       IN_ACC_ID,
                       IS_ITEM_CODE,
                       IS_BILL_DATE,
                       IN_PRICE_LIST_ID,
                       LD_PRICE,
                       LD_DISCOUNT,
                       LD_MONTH_DISCOUNT,
                       LS_CX_FLAG,
                       VN_PRICE_LINE_ID);
        IF VN_PRICE_LINE_ID > 0 THEN
          BEGIN
            SELECT COMPETITE_ATTR,price_line_id,price_list_id
              INTO OS_COMPE_ATTR,price_line_id,price_list_id
              FROM T_BD_PRICE_LINE
             WHERE VN_PRICE_LINE_ID = PRICE_LINE_ID;
          EXCEPTION
            WHEN OTHERS THEN
              NULL;
          END;
        END IF;
        --定制机按价格体系取价，取不到，则在按选配项取价
        If v_C2m_Customized_Flag = 'Y'And LD_PRICE Is Null Then
          P_GET_PRICE_C2M(IN_ACC_ID,
                         IS_ITEM_CODE,
                         IS_BILL_DATE,
                         IN_PRICE_LIST_ID,
                         IN_ENTITY_ID,
                         LD_PRICE,
                         LD_DISCOUNT,
                         LD_MONTH_DISCOUNT,
                         LS_CX_FLAG,
                         v_COMPE_ATTR);
        End If;
      --如果是定制机产品，取价优先级是取选配项价格，先取选配项价格
      Elsif v_Pln_C2m_Price_Priority = 'C2M' And v_C2m_Customized_Flag = 'Y' Then
        P_GET_PRICE_C2M(IN_ACC_ID,
                       IS_ITEM_CODE,
                       IS_BILL_DATE,
                       IN_PRICE_LIST_ID,
                       IN_ENTITY_ID,
                       LD_PRICE,
                       LD_DISCOUNT,
                       LD_MONTH_DISCOUNT,
                       LS_CX_FLAG,
                       v_COMPE_ATTR);
        --按选配项取不到价格，则取价格体系价格
        --优先按选配价格取价的，取不到价后不找价格体系的价格列表价格 2020-5-6 lilh6
        /*If LD_PRICE Is Null Then
          --厨电
          P_GET_PRICE_14(IN_ENTITY_ID,
                         IN_ACC_ID,
                         IS_ITEM_CODE,
                         IS_BILL_DATE,
                         IN_PRICE_LIST_ID,
                         LD_PRICE,
                         LD_DISCOUNT,
                         LD_MONTH_DISCOUNT,
                         LS_CX_FLAG,
                         VN_PRICE_LINE_ID);
          IF VN_PRICE_LINE_ID > 0 THEN
            BEGIN
              SELECT COMPETITE_ATTR,price_line_id,price_list_id
                INTO OS_COMPE_ATTR,price_line_id,price_list_id
                FROM T_BD_PRICE_LINE
               WHERE VN_PRICE_LINE_ID = PRICE_LINE_ID;
            EXCEPTION
              WHEN OTHERS THEN
                NULL;
            END;
          END IF;
        End If;*/
      End If;
    end if;
    ON_PRICE          := LD_PRICE; --返回价格
    ON_DISCOUNT       := LD_DISCOUNT; --返回折扣率
    ON_MONTH_DISCOUNT := LD_MONTH_DISCOUNT; --返回月返
    OS_CX_FLAG        := LS_CX_FLAG; --返回是否促销机
  end;
  ----------------------------------------------------------------------                           
  -- Author  : lilh6
  -- Created : 2019-06-12
  -- Purpose : 根据选配项定价获取定制机价格     
  ----------------------------------------------------------------------
  Procedure p_Get_Price_C2m(In_Acc_Id         In t_Customer_Account.Account_Id%Type, --账户ID
                            Is_Item_Code      In t_Bd_Item.Item_Code%Type, --产品编码
                            Is_Bill_Date      In Varchar2, --单据日期,YYYYMMDD
                            In_Price_List_Id  In t_Bd_Price_List.Price_List_Id%Type, --价格列表ID
                            In_Entity_Id      In Up_Org_Unit.Entity_Id%Type, --业务主体ID
                            On_Price          Out Number, --返回价格
                            On_Discount       Out Number, --返回折扣率
                            On_Month_Discount Out Number, --返回月返
                            Os_Cx_Flag        Out Varchar2, --返回是否促销机
                            Os_Compe_Attr     Out Varchar2 --价格行的竞争属性  定制机取价报错时用此字段返回错误信息
                            ) Is
    Ls_Price_Mode              Varchar2(32);
    Ld_Price                   Number;
    Ld_Discount                Number;
    Ld_Month_Discount          Number;
    Ls_Cx_Flag                 Varchar2(2);
    v_Compe_Attr               Varchar2(32);
    Vn_Price_Line_Id           Number; --
    v_Pln_Item_C2m_Price_Mode  Varchar2(50); --标准机取价模式
    v_Standard_Item_Code       Varchar2(100); --标准机编码
    v_Standard_Item_Code_Price Number; --标准机价格
    v_Option_Item_Price        Number; --选配项组合价
    v_Max_Head_Id              Number; --选配项定价头id
    v_Item_Packaget_Price      Number; --产品包装价
    v_item_match_price_msg     varchar2(3000);  --记录没有维护选配项定价的选配项信息或者选项项定价失效的选配项信息
  Begin
    --获取标准机取价模式
    v_Pln_Item_C2m_Price_Mode := Pkg_Bd.f_Get_Parameter_Value('PLN_ITEM_C2M_PRICE_MODE',
                                                              In_Entity_Id);
    Begin
      --获取标准机编码
      Select r.Item_Code
        Into v_Standard_Item_Code
        From t_Pln_Option_Item_Match m, t_Item_Match_Relation r
       Where m.Custom_Made_Item_Code = Is_Item_Code
         And m.Entity_Id = In_Entity_Id
         And m.Item_Match_Relation_Id = r.Id
         And Rownum = 1;
    Exception
      When Others Then
        --没有标准机，直接返回空价格
        On_Price          := Null;
        On_Discount       := 0;
        On_Month_Discount := 0;
        Os_Cx_Flag        := 'N';
        Return;
    End;
  
    If v_Pln_Item_C2m_Price_Mode = 'C2M' Then
      --取选配项定价价格
      Begin
        Select Ph.Price
          Into v_Standard_Item_Code_Price
          From t_Item_Match_Price_Head Ph
         Where Ph.Head_Id = (Select Max(h.Head_Id)
                               From t_Item_Match_Price_Head h
                              Where h.Item_Code = v_Standard_Item_Code
                                And h.Active_Flag = 'Y'
                                And h.List_Name = '代理商定制价'
                                And h.Status = '30');
        On_Discount       := 0;
        On_Month_Discount := 0;
      Exception
        When Others Then
          --没有标准机价格，直接返回空价格
          On_Price          := Null;
          On_Discount       := 0;
          On_Month_Discount := 0;
          Os_Cx_Flag        := 'N';
          Os_Compe_Attr     := '定制机对应的标机没有维护有效的代理商定制价！';
          Return;
      End;
    Elsif v_Pln_Item_C2m_Price_Mode = 'PRICE' Then
      --取价格体系价格
      p_Get_Price_Line(In_Acc_Id, --账户ID
                       v_Standard_Item_Code, --产品编码
                       Is_Bill_Date, --单据日期,YYYYMMDD
                       In_Price_List_Id, --价格列表ID
                       In_Entity_Id, --业务主体ID
                       v_Standard_Item_Code_Price, --返回价格
                       Ld_Discount, --返回折扣率
                       Ld_Month_Discount, --返回月返
                       Ls_Cx_Flag, --返回是否促销机
                       v_Compe_Attr --价格行的竞争属性
                       );
      If v_Standard_Item_Code_Price Is Null Then
        --没有标准机价格，直接返回空价格
        On_Price          := Null;
        On_Discount       := 0;
        On_Month_Discount := 0;
        Os_Cx_Flag        := 'N';
        Os_Compe_Attr     := '定制机对应的标机没有维护客户价格列表价格！';
        Return;
      End If;
      On_Discount       := Ld_Discount;
      On_Month_Discount := Ld_Month_Discount;
    End If;
    --判断标准机是否有维护代理商定制价
    Select Max(h.Head_Id)
      Into v_Max_Head_Id
      From t_Item_Match_Price_Head h
     Where h.Item_Code = v_Standard_Item_Code
       And h.Active_Flag = 'Y'
       And h.List_Name = '代理商定制价'
       And h.Status = '30';
    If v_Max_Head_Id Is Null Then
      --标准机没有维护代理商定制价，直接返回空价格
      On_Price          := Null;
      On_Discount       := 0;
      On_Month_Discount := 0;
      Os_Cx_Flag        := 'N';
      Os_Compe_Attr     := '定制机对应的标机没有维护有效的代理商定制价！';
      Return;
    End If;
    --获取选配项价格前，先检查是否存在个别选配项定价没有维护
    Begin
      Select To_Char(Wm_Concat('配置项[' || r.Item_Match_Name || ']选配项[' ||
                               r.Item_Option_Name || ']'))
        Into v_item_match_price_msg
        From t_Pln_Option_Item_Match m, t_Item_Match_Relation r
       Where m.Item_Match_Relation_Id = r.Id
         And r.Active_Flag = 'Y'
         And m.Entity_Id = In_Entity_Id
         And m.Custom_Made_Item_Code = Is_Item_Code
         And Not Exists (Select 1
                From t_Item_Match_Price_Line l
               Where l.Head_Id = v_Max_Head_Id
                 And r.Item_Option_Code = l.Item_Option_Code
                 And r.Item_Match_Code = l.Item_Match_Code
                 And r.Entity_Id = l.Entity_Id);
    Exception
      When Others Then
        v_item_match_price_msg := Null;
    End;
    If v_item_match_price_msg Is Not Null Then
      --存在个别选配项定价没有维护，直接返回空价格
      On_Price          := Null;
      On_Discount       := 0;
      On_Month_Discount := 0;
      Os_Cx_Flag        := 'N';
      Os_Compe_Attr     := '定制机的' || v_item_match_price_msg ||'没有维护选配项定价！';
      Return;
    End If;
    --获取选配项价格前，先检查是否存在个别选配项定价已失效或者没有生效
    Begin
      Select To_Char(Wm_Concat('配置项[' || l.Item_Match_Name || ']选配项[' ||
                               l.Item_Option_Name || ']'))
        Into v_item_match_price_msg
        From t_Item_Match_Price_Line l,
             t_Pln_Option_Item_Match m,
             t_Item_Match_Relation   r
       Where l.Head_Id = v_Max_Head_Id
         And m.Custom_Made_Item_Code = Is_Item_Code
         And m.Entity_Id = In_Entity_Id
         And m.Item_Match_Relation_Id = r.Id
         And r.Active_Flag = 'Y'
         And r.Item_Option_Code = l.Item_Option_Code
         And r.Item_Match_Code = l.Item_Match_Code
         And r.Entity_Id = l.Entity_Id
         And (l.Begin_Date >= Sysdate Or Nvl(l.End_Date, Sysdate) <= Sysdate);
    Exception
      When Others Then
        v_item_match_price_msg := Null;
    End;
    If v_item_match_price_msg Is Not Null Then
      --存在个别选配项定价没有维护，直接返回空价格
      On_Price          := Null;
      On_Discount       := 0;
      On_Month_Discount := 0;
      Os_Cx_Flag        := 'N';
      Os_Compe_Attr     := '定制机的' || v_item_match_price_msg ||'选配项定价已失效或者没到生效日期！';
      Return;
    End If;
    --获取选配项价格
    Select Sum(l.Price)
      Into v_Option_Item_Price
      From t_Item_Match_Price_Line l,
           t_Pln_Option_Item_Match m,
           t_Item_Match_Relation   r
     Where l.Head_Id = v_Max_Head_Id
       And m.Custom_Made_Item_Code = Is_Item_Code
       And m.Entity_Id = In_Entity_Id
       And m.Item_Match_Relation_Id = r.Id
       And r.Active_Flag = 'Y'
       And r.Item_Option_Code = l.Item_Option_Code
       And r.Item_Match_Code = l.Item_Match_Code
       And r.Entity_Id = l.Entity_Id
       And l.Begin_Date <= Sysdate
       And Nvl(l.End_Date, Sysdate) >= Sysdate;
    --包装价
    v_Item_Packaget_Price := 0;
    Select Sum(a.Package_Price)
      Into v_Item_Packaget_Price
      From t_Item_Package_Price a
     Where a.Entity_Id = In_Entity_Id
       And a.Account_Id = In_Acc_Id
       And a.Item_Code = Is_Item_Code
       And a.Active_Flag = 'Y';
    --定制机价格=标准机价格+选配项价格总和
    On_Price   := Nvl(v_Standard_Item_Code_Price, 999999) +
                  Nvl(v_Option_Item_Price, 0) +
                  Nvl(v_Item_Packaget_Price, 0);
    Os_Cx_Flag := 'N';
  End;
END PKG_BD_PRICE;
/

