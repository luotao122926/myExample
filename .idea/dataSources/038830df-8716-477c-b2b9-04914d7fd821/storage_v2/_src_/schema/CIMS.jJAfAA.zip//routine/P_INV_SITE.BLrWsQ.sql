create procedure P_INV_SITE(O_RESULT     OUT VARCHAR2, --返回错误码
                                       O_RESULT_MSG OUT VARCHAR2 --返回错误信息
                                       ) is

  --查询游标
  cursor V_SITE_cost is
    select dl.FINANCE_ENTITY_ID,
           dl.FINANCIAL_INV,
           dl.WEBSIT_CODE,
           dl.ITEM_STATUS
      from A3_C_IMS_SITE dl;

  --临时变量，游标
  TEMP_V_SITE_ROW V_SITE_cost%ROWTYPE;

  --临时变量
  TEMP_CountSite number;


BEGIN
  O_RESULT     := '1';
  O_RESULT_MSG := '';

BEGIN
  --打开游标
  open V_SITE_cost;

  LOOP
    FETCH V_SITE_cost
      INTO TEMP_V_SITE_ROW;
    EXIT WHEN V_SITE_cost%NOTFOUND;

    --设置回滚点
    SAVEPOINT savepoint_1;

    --把视图数据保存到本地表INTF_INV_SITE
    --判断更新或插入
    select count(1)
      INTO TEMP_CountSite
      from INTF_INV_SITE t
     where t.FINANCE_ENTITY_ID = TEMP_V_SITE_ROW.FINANCE_ENTITY_ID
       and t.WEBSIT_CODE = TEMP_V_SITE_ROW.WEBSIT_CODE;

    IF (TEMP_CountSite = 0) THEN

      --insert
      insert into INTF_INV_SITE
        (INTF_INV_SITE_ID,
         FINANCE_ENTITY_ID,
         FINANCIAL_INV,
         WEBSIT_CODE,
         ITEM_STATUS)
      VALUES
        (S_INTF_INV_SITE.nextval,
         TEMP_V_SITE_ROW.FINANCE_ENTITY_ID,
         TEMP_V_SITE_ROW.FINANCIAL_INV,
         TEMP_V_SITE_ROW.WEBSIT_CODE,
         TEMP_V_SITE_ROW.ITEM_STATUS);

    ELSE

      update INTF_INV_SITE t
         set t.FINANCIAL_INV = TEMP_V_SITE_ROW.FINANCIAL_INV,
             t.ITEM_STATUS   = TEMP_V_SITE_ROW.ITEM_STATUS
       where t.FINANCE_ENTITY_ID = TEMP_V_SITE_ROW.FINANCE_ENTITY_ID
         and t.WEBSIT_CODE = TEMP_V_SITE_ROW.WEBSIT_CODE;

    END IF;

  END LOOP;
  --commit;
  CLOSE V_SITE_cost;
Exception
  When no_data_found THEN
    --回滚
    O_RESULT     := '0';
    O_RESULT_MSG := O_RESULT_MSG || 'no_data_found';
    --ROLLBACK TO SAVEPOINT savepoint_1;

END;

end P_INV_SITE;

/

