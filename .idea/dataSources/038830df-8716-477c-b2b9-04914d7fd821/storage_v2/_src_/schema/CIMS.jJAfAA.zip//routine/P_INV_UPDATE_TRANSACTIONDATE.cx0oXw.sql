create procedure P_INV_UPDATE_TRANSACTIONDATE(I_ENTITY_ID IN INTEGER) IS

  v_entity_id number;
begin
  v_entity_id := I_ENTITY_ID;
  update cims.t_inv_taction_reconciliation t
     set t.transaction_date = (select h.transaction_date
                                 from cims.t_inv_transaction_history h
                                where h.business_num = t.business_num
                                  and t.inv_code = h.inventory_code
                                  and t.entity_id = h.entity_id
                                  and rownum < 2)
   where t.transaction_date is null
     and t.entity_id = v_entity_id
     and exists (select h.transaction_date
            from cims.t_inv_transaction_history h
           where h.business_num = t.business_num
             and t.inv_code = h.inventory_code
             and t.entity_id = h.entity_id);

  commit;

end P_INV_UPDATE_TRANSACTIONDATE;
/

