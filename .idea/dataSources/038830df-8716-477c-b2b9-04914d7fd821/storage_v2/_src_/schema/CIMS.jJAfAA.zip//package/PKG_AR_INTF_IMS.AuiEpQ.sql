create PACKAGE PKG_AR_INTF_IMS is

-- 到款接口表数据插入业务表
  PROCEDURE P_PURCHASEFEETURNFEE_IMS(
    P_REFUND_APPLY_ID          in number, --批处理ID
    P_MESSAGE                  out varchar2 --成功则返回“SUCCESS”，否则返回出错信息
    );

-- 退款接口表数据插入业务表
PROCEDURE P_DISCOUNTPAYAPPLY_IMS(
		P_REFUND_APPLY_ID          in number, --退款申请ID
		P_MESSAGE                  out varchar2 --成功则返回“SUCCESS”，否则返回出错信息
    );


END PKG_AR_INTF_IMS;
/

