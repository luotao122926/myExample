create PACKAGE BODY PKG_PMT_QUOTATION IS

  /**
  *检查报价单预算
  */
  PROCEDURE P_QUOT_CHECK_BUDGET(P_ORDER_HEAD_ID         IN NUMBER,
                               I_BUDGET_AMOUNT         IN NUMBER, --预算
                               P_BUDGET_AMOUNT         OUT NUMBER, --占用预算
                               P_BUDGET_AMOUNT_CAN_USE OUT NUMBER, --可用预算
                               P_BUDGET_AMOUNT_USING1  OUT NUMBER, --同节点制单占用预算
                               P_BUDGET_AMOUNT_USING2  OUT NUMBER, --同节点送审占用预算
                               P_MESSAGE               OUT VARCHAR2) AS
  BEGIN
    UPDATE T_PMT_QUOTATION_HEAD T
       SET T.TOTAL_AMOUNT = I_BUDGET_AMOUNT
     WHERE T.QUOTATION_ID = P_ORDER_HEAD_ID;
    P_QUOT_CHECK_BUDGET(P_ORDER_HEAD_ID,
                       P_BUDGET_AMOUNT,
                       P_BUDGET_AMOUNT,
                       P_BUDGET_AMOUNT_USING1,
                       P_BUDGET_AMOUNT_USING2,
                       P_MESSAGE);
  END P_QUOT_CHECK_BUDGET;

  /**
  *检查报价单预算
  */
  PROCEDURE P_QUOT_CHECK_BUDGET(P_ORDER_HEAD_ID         IN NUMBER,
                               P_BUDGET_AMOUNT         OUT NUMBER, --占用预算
                               P_BUDGET_AMOUNT_CAN_USE OUT NUMBER, --可用预算
                               P_BUDGET_AMOUNT_USING1  OUT NUMBER, --同节点制单占用预算
                               P_BUDGET_AMOUNT_USING2  OUT NUMBER, --同节点送审占用预算
                               P_MESSAGE               OUT VARCHAR2) AS
    V_CNT NUMBER;
    CURSOR C_PMT_ORDER_BUDGET_LINE IS
      SELECT H.QUOTATION_NO     AS POLICY_NUMBER,
             BT.Data_Flow_Id AS DATA_FLOW_ID,
             --H.DATE_FLOW_ID         AS H_DATA_FLOW_ID,
             BT.BUDGET_TREE_ID      AS BUDGET_TREE_ID,
             H.BUDGET_TREE_ID       AS H_BUDGET_TREE_ID,
             H.BUDGET_SEGMENT_01_ID,
             H.BUDGET_SEGMENT_02_ID,
             H.BUDGET_SEGMENT_03_ID,
             H.BUDGET_SEGMENT_04_ID,
             H.BUDGET_SEGMENT_05_ID,
             H.BUDGET_SEGMENT_06_ID,
             H.TOTAL_AMOUNT AS BUDGET_AMOUNT,
             H.QUOTATION_ID        AS DETAIL_ID,
             H.ENTITY_ID,
             --H.CREATED_BY,
             NVL((SELECT T.USER_ID
                   FROM UP_ORG_USER T
                  WHERE T.ACCOUNT = H.CREATED_BY
                    AND 'T' = T.ACCOUNT_ENABLED
                    AND 'T' = T.ACTIVE_FLAG
                    AND 1 = ROWNUM),
                 0) AS CREATED_BY
        FROM T_PMT_QUOTATION_HEAD H, T_POL_BUDGET_TREE BT
       WHERE H.DATE_FLOW_ID = BT.DATA_FLOW_ID
         AND NVL(H.BUDGET_SEGMENT_01_ID, -1) =
             NVL(BT.BUDGET_SEGMENT_01_ID, -1)
         AND NVL(H.BUDGET_SEGMENT_02_ID, -1) =
             NVL(BT.BUDGET_SEGMENT_02_ID, -1)
         AND NVL(H.BUDGET_SEGMENT_03_ID, -1) =
             NVL(BT.BUDGET_SEGMENT_03_ID, -1)
         AND NVL(H.BUDGET_SEGMENT_04_ID, -1) =
             NVL(BT.BUDGET_SEGMENT_04_ID, -1)
         AND NVL(H.BUDGET_SEGMENT_05_ID, -1) =
             NVL(BT.BUDGET_SEGMENT_05_ID, -1)
         AND NVL(H.BUDGET_SEGMENT_06_ID, -1) =
             NVL(BT.BUDGET_SEGMENT_06_ID, -1)
         AND H.QUOTATION_ID = P_ORDER_HEAD_ID;
  
    R_PMT_ORDER_BUDGET_LINE C_PMT_ORDER_BUDGET_LINE%ROWTYPE;
  BEGIN
    V_CNT     := 0;
    P_MESSAGE := 'SUCCESS';
    OPEN C_PMT_ORDER_BUDGET_LINE;
    LOOP
      BEGIN
        FETCH C_PMT_ORDER_BUDGET_LINE
          INTO R_PMT_ORDER_BUDGET_LINE;
      
        EXIT WHEN C_PMT_ORDER_BUDGET_LINE%NOTFOUND;
        IF 0 <> V_CNT THEN
          P_MESSAGE := '该报价单的预算节点存在重复数据';
          EXIT;
        END IF;
        V_CNT := (1 + V_CNT);
        /*IF R_PMT_ORDER_BUDGET_LINE.BUDGET_TREE_ID <>
           NVL(R_PMT_ORDER_BUDGET_LINE.H_BUDGET_TREE_ID, 0) THEN
          --SAVEPOINT SP1;
          UPDATE T_PMT_QUOTATION_HEAD H
             SET H.BUDGET_TREE_ID = R_PMT_ORDER_BUDGET_LINE.BUDGET_TREE_ID
           WHERE H.ORDER_HEAD_ID = P_ORDER_HEAD_ID;
          --COMMIT;
        END IF;*/
        PKG_BUDGET.p_Check_Fee(R_PMT_ORDER_BUDGET_LINE.DATA_FLOW_ID,
                               R_PMT_ORDER_BUDGET_LINE.ENTITY_ID,
                               R_PMT_ORDER_BUDGET_LINE.BUDGET_TREE_ID,
                               '报价单',
                               R_PMT_ORDER_BUDGET_LINE.DETAIL_ID,
                               R_PMT_ORDER_BUDGET_LINE.POLICY_NUMBER,
                               NULL,
                               NULL,
                               NULL,
                               NULL,
                               NULL,
                               NULL,
                               NULL,
                               NULL,
                               NULL,
                               NULL,
                               R_PMT_ORDER_BUDGET_LINE.BUDGET_AMOUNT,
                               R_PMT_ORDER_BUDGET_LINE.CREATED_BY,
                               P_MESSAGE);
        /*PKG_BUDGET.p_Check_Fee(R_PMT_ORDER_BUDGET_LINE.DATA_FLOW_ID,
        R_PMT_ORDER_BUDGET_LINE.ENTITY_ID,
        NVL(R_PMT_ORDER_BUDGET_LINE.BUDGET_SEGMENT_01_ID,
            -1),
        NVL(R_PMT_ORDER_BUDGET_LINE.BUDGET_SEGMENT_02_ID,
            -1),
        NVL(R_PMT_ORDER_BUDGET_LINE.BUDGET_SEGMENT_03_ID,
            -1),
        NVL(R_PMT_ORDER_BUDGET_LINE.BUDGET_SEGMENT_04_ID,
            -1),
        NVL(R_PMT_ORDER_BUDGET_LINE.BUDGET_SEGMENT_05_ID,
            -1),
        NVL(R_PMT_ORDER_BUDGET_LINE.BUDGET_SEGMENT_06_ID,
            -1),
        '报价单', --费用类型
        R_PMT_ORDER_BUDGET_LINE.DETAIL_ID,
        R_PMT_ORDER_BUDGET_LINE.POLICY_NUMBER,
        NULL,
        NULL,
        R_PMT_ORDER_BUDGET_LINE.BUDGET_AMOUNT,
        --P_USER_ID,
        R_PMT_ORDER_BUDGET_LINE.CREATED_BY, -- 1 admin
        P_MESSAGE);*/
      EXCEPTION
        WHEN OTHERS THEN
          P_MESSAGE := '检查报价单预算发生异常：' || SQLCODE || SQLERRM;
      END;
    END LOOP;
    CLOSE C_PMT_ORDER_BUDGET_LINE;
    IF 0 = V_CNT THEN
      P_MESSAGE := '该报价单或者报价单的预算节点不存在，请检查';
    END IF;
  END P_QUOT_CHECK_BUDGET;
  
  /*
        * 报价单占用预算
        */
  PROCEDURE P_QUOT_OCCUPY_BUDGET(HEADER_ID       IN T_PMT_QUOTATION_HEAD.QUOTATION_ID%TYPE, --头表ID
                                  USER_ID         IN NUMBER, --用户ID
                                  I_BUDGET_AMOUNT IN NUMBER, --预算
                                  FLAG            OUT VARCHAR2, --返回值
                                  FLAG_MSG        OUT VARCHAR2 --返回信息
                                  ) AS
  BEGIN
    UPDATE T_PMT_QUOTATION_HEAD T
       SET T.TOTAL_AMOUNT = I_BUDGET_AMOUNT
     WHERE T.QUOTATION_ID = HEADER_ID AND 'N' = NVL(T.BUDGET_FLAG,'N');
    IF 0 = SQL%ROWCOUNT THEN
      FLAG     := '02';
      FLAG_MSG := '报价单不存在或已占用预算';
      RETURN;
    END IF;
    P_QUOT_OCCUPY_BUDGET(HEADER_ID, USER_ID, FLAG, FLAG_MSG);
  END P_QUOT_OCCUPY_BUDGET;

  /*
  *报价单占用预算
  */
  PROCEDURE P_QUOT_OCCUPY_BUDGET(HEADER_ID IN T_PMT_QUOTATION_HEAD.QUOTATION_ID%TYPE, --头表ID
                                  USER_ID   IN NUMBER, --用户ID
                                  FLAG      OUT VARCHAR2, --返回值
                                  FLAG_MSG  OUT VARCHAR2 --返回信息
                                  ) IS
  
    V_DATE_FLOW_ID         T_PMT_QUOTATION_HEAD.DATE_FLOW_ID%TYPE; --预算流ID
    V_ENTITY_ID            T_PMT_QUOTATION_HEAD.ENTITY_ID%TYPE; --主体ID
    V_BUDGET_AMOUNT        T_PMT_QUOTATION_HEAD.TOTAL_AMOUNT%TYPE; --占用金额
    V_ORDER_HEADER_INFO    T_PMT_QUOTATION_HEAD%ROWTYPE; --采购单头表信息
    V_RETURN_MESSAGE       VARCHAR2(4000); --返回信息
    V_BUDGET_SEGMENT_01_ID T_PMT_QUOTATION_HEAD.BUDGET_SEGMENT_01_ID%TYPE; --预算树第一层
    V_BUDGET_SEGMENT_02_ID T_PMT_QUOTATION_HEAD.BUDGET_SEGMENT_02_ID%TYPE; --预算树第二层
    V_BUDGET_SEGMENT_03_ID T_PMT_QUOTATION_HEAD.BUDGET_SEGMENT_03_ID%TYPE; --预算树第三层
    V_BUDGET_SEGMENT_04_ID T_PMT_QUOTATION_HEAD.BUDGET_SEGMENT_04_ID%TYPE; --预算树第四层
    V_BUDGET_SEGMENT_05_ID T_PMT_QUOTATION_HEAD.BUDGET_SEGMENT_05_ID%TYPE; --预算树第五层
    V_BUDGET_SEGMENT_06_ID T_PMT_QUOTATION_HEAD.BUDGET_SEGMENT_06_ID%TYPE; --预算树第六层
    -- V_MAIN_TYPE         T_PMT_QUOTATION_HEAD.CHARGES_MAIN_TYPE_ID%TYPE; --大类
    -- V_SUB_TYPE          T_PMT_QUOTATION_HEAD.CHARGES_SUB_TYPE_ID%TYPE; --小类
  
  BEGIN
    FLAG     := '01';
    FLAG_MSG := '占用预算成功';
  
    BEGIN
      SELECT *
        INTO V_ORDER_HEADER_INFO
        FROM T_PMT_QUOTATION_HEAD
       WHERE QUOTATION_ID = HEADER_ID
       FOR UPDATE WAIT 2;
    EXCEPTION
      WHEN OTHERS THEN
        FLAG     := '02';
        FLAG_MSG := '采购订单不存在';
        RETURN;
    END;
    
    IF 'Y' = NVL(V_ORDER_HEADER_INFO.BUDGET_FLAG,'N') THEN
       FLAG     := '02';
       FLAG_MSG := '采购订单已占用预算';
       RETURN;
    END IF;
  
    V_DATE_FLOW_ID         := V_ORDER_HEADER_INFO.DATE_FLOW_ID;
    V_ENTITY_ID            := V_ORDER_HEADER_INFO.ENTITY_ID;
    V_BUDGET_AMOUNT        := V_ORDER_HEADER_INFO.TOTAL_AMOUNT;
    V_BUDGET_SEGMENT_01_ID := V_ORDER_HEADER_INFO.BUDGET_SEGMENT_01_ID;
    V_BUDGET_SEGMENT_02_ID := V_ORDER_HEADER_INFO.BUDGET_SEGMENT_02_ID;
    V_BUDGET_SEGMENT_03_ID := V_ORDER_HEADER_INFO.BUDGET_SEGMENT_03_ID;
    V_BUDGET_SEGMENT_04_ID := V_ORDER_HEADER_INFO.BUDGET_SEGMENT_04_ID;
    V_BUDGET_SEGMENT_05_ID := V_ORDER_HEADER_INFO.BUDGET_SEGMENT_05_ID;
    V_BUDGET_SEGMENT_06_ID := V_ORDER_HEADER_INFO.BUDGET_SEGMENT_06_ID;
    /* V_ORGANIZATION_ID := V_ORDER_HEADER_INFO.ORGANIZATION_ID;
    V_MAIN_TYPE       := V_ORDER_HEADER_INFO.CHARGES_MAIN_TYPE_ID;
    V_SUB_TYPE        := V_ORDER_HEADER_INFO.CHARGES_SUB_TYPE_ID;*/
  
    IF (V_DATE_FLOW_ID IS NULL) THEN
      FLAG     := '03';
      FLAG_MSG := '预算流ID为空';
      RETURN;
    END IF;
  
    IF (V_ENTITY_ID IS NULL) THEN
      FLAG     := '04';
      FLAG_MSG := '主体ID为空';
      RETURN;
    END IF;
  
    IF (V_BUDGET_AMOUNT IS NULL) THEN
      FLAG     := '05';
      FLAG_MSG := '占用金额为0';
      RETURN;
    END IF;
    IF (V_BUDGET_SEGMENT_01_ID IS NULL) THEN
      V_BUDGET_SEGMENT_01_ID := -1;
    END IF;
    IF (V_BUDGET_SEGMENT_02_ID IS NULL) THEN
      V_BUDGET_SEGMENT_02_ID := -1;
    END IF;
    IF (V_BUDGET_SEGMENT_03_ID IS NULL) THEN
      V_BUDGET_SEGMENT_03_ID := -1;
    END IF;
    IF (V_BUDGET_SEGMENT_04_ID IS NULL) THEN
      V_BUDGET_SEGMENT_04_ID := -1;
    END IF;
    IF (V_BUDGET_SEGMENT_05_ID IS NULL) THEN
      V_BUDGET_SEGMENT_05_ID := -1;
    END IF;
    IF (V_BUDGET_SEGMENT_06_ID IS NULL) THEN
      V_BUDGET_SEGMENT_06_ID := -1;
    END IF;
    /*IF (V_ORGANIZATION_ID IS NULL) THEN
      V_ORGANIZATION_ID := -1;
    END IF;
    
    IF (V_MAIN_TYPE IS NULL) THEN
      V_MAIN_TYPE := -1;
    END IF;
    
    IF (V_SUB_TYPE IS NULL) THEN
      V_SUB_TYPE := -1;
    END IF;*/
    BEGIN
      PKG_BUDGET.P_WRITE_FEE(V_DATE_FLOW_ID,
                             V_ENTITY_ID,
                             V_BUDGET_SEGMENT_01_ID,
                             V_BUDGET_SEGMENT_02_ID,
                             V_BUDGET_SEGMENT_03_ID,
                             V_BUDGET_SEGMENT_04_ID,
                             V_BUDGET_SEGMENT_05_ID,
                             V_BUDGET_SEGMENT_06_ID,
                             '报价单',
                             HEADER_ID,
                             V_ORDER_HEADER_INFO.QUOTATION_NO,
                             NULL,
                             NULL,
                             V_BUDGET_AMOUNT,
                             USER_ID,
                             V_RETURN_MESSAGE);
      IF 'SUCCESS' <> V_RETURN_MESSAGE THEN
        FLAG     := '06';
        FLAG_MSG := '预算占用调用不成功：' || V_RETURN_MESSAGE;
        RETURN;
      END IF;
      UPDATE T_PMT_QUOTATION_HEAD T SET T.BUDGET_FLAG = 'Y'
      WHERE QUOTATION_ID = HEADER_ID;
    EXCEPTION
      WHEN OTHERS THEN
        FLAG     := '07';
        FLAG_MSG := '占用预算异常';
        RETURN;
        --RAISE PKG_PMT_PUB.PMT_EXCEPTION;
    END;
  
    /*  FLAG:='06';
    FLAG_MSG:=V_RETURN_MESSAGE;*/
  END P_QUOT_OCCUPY_BUDGET;

  /**
  * 报价单红冲时释放预算
  */
  PROCEDURE P_QUOT_UNOCCUPY_BUDGET(HEADER_ID IN T_PMT_QUOTATION_HEAD.QUOTATION_ID%TYPE, --头表ID
                                    USER_ID   IN NUMBER, --用户ID
                                    FLAG      OUT VARCHAR2, --返回值
                                    FLAG_MSG  OUT VARCHAR2 --返回信息
                                    ) IS
  
    --V_DATE_FLOW_ID      T_PMT_QUOTATION_HEAD.DATE_FLOW_ID%TYPE; --预算流ID
    V_ENTITY_ID         T_PMT_QUOTATION_HEAD.ENTITY_ID%TYPE; --主体ID
    V_BUDGET_AMOUNT     T_PMT_QUOTATION_HEAD.TOTAL_AMOUNT%TYPE; --占用金额
    V_ORDER_HEADER_INFO T_PMT_QUOTATION_HEAD%ROWTYPE; --采购单头表信息
    --V_RETURN_MESSAGE    VARCHAR2(4000); --返回信息
    /* V_ORGANIZATION_ID   T_PMT_QUOTATION_HEAD.ORGANIZATION_ID%TYPE; --组织机构
    V_MAIN_TYPE         T_PMT_QUOTATION_HEAD.CHARGES_MAIN_TYPE_ID%TYPE; --大类
    V_SUB_TYPE          T_PMT_QUOTATION_HEAD.CHARGES_SUB_TYPE_ID%TYPE; --小类*/
    V_BUDGET_SEGMENT_01_ID T_PMT_QUOTATION_HEAD.BUDGET_SEGMENT_01_ID%TYPE; --预算树第一层
    V_BUDGET_SEGMENT_02_ID T_PMT_QUOTATION_HEAD.BUDGET_SEGMENT_02_ID%TYPE; --预算树第二层
    V_BUDGET_SEGMENT_03_ID T_PMT_QUOTATION_HEAD.BUDGET_SEGMENT_03_ID%TYPE; --预算树第三层
    V_BUDGET_SEGMENT_04_ID T_PMT_QUOTATION_HEAD.BUDGET_SEGMENT_04_ID%TYPE; --预算树第四层
    V_BUDGET_SEGMENT_05_ID T_PMT_QUOTATION_HEAD.BUDGET_SEGMENT_05_ID%TYPE; --预算树第五层
    V_BUDGET_SEGMENT_06_ID T_PMT_QUOTATION_HEAD.BUDGET_SEGMENT_06_ID%TYPE; --预算树第六层
    V_BUDGET_TREE_ID       T_PMT_QUOTATION_HEAD.BUDGET_TREE_ID%TYPE; --预算树ID
  
  BEGIN
    FLAG     := '1';
    FLAG_MSG := '释放预算成功';
  
    BEGIN
      SELECT *
        INTO V_ORDER_HEADER_INFO
        FROM T_PMT_QUOTATION_HEAD
       WHERE QUOTATION_ID = HEADER_ID
       FOR UPDATE WAIT 2;
    EXCEPTION
      WHEN OTHERS THEN
        FLAG     := '02';
        FLAG_MSG := '采购订单不存在';
        RETURN;
    END;
    
    IF 'N' = NVL(V_ORDER_HEADER_INFO.BUDGET_FLAG,'N') THEN
       FLAG     := '02';
       FLAG_MSG := '采购订单已释放预算';
       RETURN;
    END IF;
  
    V_ENTITY_ID     := V_ORDER_HEADER_INFO.ENTITY_ID;
    V_BUDGET_AMOUNT := V_ORDER_HEADER_INFO.TOTAL_AMOUNT;
    /*  V_ORGANIZATION_ID := V_ORDER_HEADER_INFO.ORGANIZATION_ID;
    V_MAIN_TYPE       := V_ORDER_HEADER_INFO.CHARGES_MAIN_TYPE_ID;
    V_SUB_TYPE        := V_ORDER_HEADER_INFO.CHARGES_SUB_TYPE_ID;*/
    V_BUDGET_SEGMENT_01_ID := V_ORDER_HEADER_INFO.BUDGET_SEGMENT_01_ID;
    V_BUDGET_SEGMENT_02_ID := V_ORDER_HEADER_INFO.BUDGET_SEGMENT_02_ID;
    V_BUDGET_SEGMENT_03_ID := V_ORDER_HEADER_INFO.BUDGET_SEGMENT_03_ID;
    V_BUDGET_SEGMENT_04_ID := V_ORDER_HEADER_INFO.BUDGET_SEGMENT_04_ID;
    V_BUDGET_SEGMENT_05_ID := V_ORDER_HEADER_INFO.BUDGET_SEGMENT_05_ID;
    V_BUDGET_SEGMENT_06_ID := V_ORDER_HEADER_INFO.BUDGET_SEGMENT_06_ID;
    V_BUDGET_TREE_ID       := V_ORDER_HEADER_INFO.BUDGET_TREE_ID;
  
    IF (V_BUDGET_TREE_ID IS NULL) THEN
      FLAG     := '03';
      FLAG_MSG := '预算树ID为空';
      RETURN;
    END IF;
  
    IF (V_ENTITY_ID IS NULL) THEN
      FLAG     := '04';
      FLAG_MSG := '主体ID为空';
      RETURN;
    END IF;
  
    IF (V_BUDGET_AMOUNT IS NULL OR 0 = V_BUDGET_AMOUNT) THEN
      FLAG     := '05';
      FLAG_MSG := '占用金额为0';
      RETURN;
    END IF;
  
    /*IF (V_ORGANIZATION_ID IS NULL) THEN
      V_ORGANIZATION_ID := -1;
    END IF;
    
    IF (V_MAIN_TYPE IS NULL) THEN
      V_MAIN_TYPE := -1;
    END IF;
    
    IF (V_SUB_TYPE IS NULL) THEN
      V_SUB_TYPE := -1;
    END IF;*/
    IF (V_BUDGET_SEGMENT_01_ID IS NULL) THEN
      V_BUDGET_SEGMENT_01_ID := -1;
    END IF;
    IF (V_BUDGET_SEGMENT_02_ID IS NULL) THEN
      V_BUDGET_SEGMENT_02_ID := -1;
    END IF;
    IF (V_BUDGET_SEGMENT_03_ID IS NULL) THEN
      V_BUDGET_SEGMENT_03_ID := -1;
    END IF;
    IF (V_BUDGET_SEGMENT_04_ID IS NULL) THEN
      V_BUDGET_SEGMENT_04_ID := -1;
    END IF;
    IF (V_BUDGET_SEGMENT_05_ID IS NULL) THEN
      V_BUDGET_SEGMENT_05_ID := -1;
    END IF;
    IF (V_BUDGET_SEGMENT_06_ID IS NULL) THEN
      V_BUDGET_SEGMENT_06_ID := -1;
    END IF;
  
    PKG_BUDGET.P_WRITE_FEE(V_BUDGET_TREE_ID,
                           V_ENTITY_ID,
                           V_BUDGET_SEGMENT_01_ID,
                           V_BUDGET_SEGMENT_02_ID,
                           V_BUDGET_SEGMENT_03_ID,
                           V_BUDGET_SEGMENT_04_ID,
                           V_BUDGET_SEGMENT_05_ID,
                           V_BUDGET_SEGMENT_06_ID,
                           '报价单',
                           HEADER_ID,
                           V_ORDER_HEADER_INFO.QUOTATION_NO,
                           NULL,
                           NULL,
                           '-' || V_BUDGET_AMOUNT,
                           USER_ID,
                           FLAG_MSG);
  
    IF 'SUCCESS' <> FLAG_MSG THEN
      FLAG     := -1;
      FLAG_MSG := '调用PKG_BUDGET.P_WRITE_FEE不成功:' || FLAG_MSG;
      RETURN;
    END IF;
    UPDATE T_PMT_QUOTATION_HEAD T SET T.BUDGET_FLAG = 'N'
    WHERE QUOTATION_ID = HEADER_ID;
  END P_QUOT_UNOCCUPY_BUDGET;
  
  /**
  *  报价单核销时释放预算
  *  lilh6  2018-7-26
  */
    Procedure p_Quot_Cancel_Budget(Header_Id In t_Pmt_Quotation_Head.Quotation_Id%Type, --头表ID
                                 User_Id   In Number, --用户ID
                                 Flag      Out Varchar2, --返回值
                                 Flag_Msg  Out Varchar2 --返回信息
                                 ) Is
  
    --V_DATE_FLOW_ID      T_PMT_QUOTATION_HEAD.DATE_FLOW_ID%TYPE; --预算流ID
    v_Entity_Id         t_Pmt_Quotation_Head.Entity_Id%Type; --主体ID
    v_Budget_Amount     t_Pmt_Quotation_Head.Total_Amount%Type; --占用金额
    v_Order_Header_Info t_Pmt_Quotation_Head%Rowtype; --采购单头表信息
    --V_RETURN_MESSAGE    VARCHAR2(4000); --返回信息
    /* V_ORGANIZATION_ID   T_PMT_QUOTATION_HEAD.ORGANIZATION_ID%TYPE; --组织机构
    V_MAIN_TYPE         T_PMT_QUOTATION_HEAD.CHARGES_MAIN_TYPE_ID%TYPE; --大类
    V_SUB_TYPE          T_PMT_QUOTATION_HEAD.CHARGES_SUB_TYPE_ID%TYPE; --小类*/
    v_Budget_Segment_01_Id t_Pmt_Quotation_Head.Budget_Segment_01_Id%Type; --预算树第一层
    v_Budget_Segment_02_Id t_Pmt_Quotation_Head.Budget_Segment_02_Id%Type; --预算树第二层
    v_Budget_Segment_03_Id t_Pmt_Quotation_Head.Budget_Segment_03_Id%Type; --预算树第三层
    v_Budget_Segment_04_Id t_Pmt_Quotation_Head.Budget_Segment_04_Id%Type; --预算树第四层
    v_Budget_Segment_05_Id t_Pmt_Quotation_Head.Budget_Segment_05_Id%Type; --预算树第五层
    v_Budget_Segment_06_Id t_Pmt_Quotation_Head.Budget_Segment_06_Id%Type; --预算树第六层
    v_Budget_Tree_Id       t_Pmt_Quotation_Head.Budget_Tree_Id%Type; --预算树ID
    v_Po_Num               t_Pmt_Quotation_Head.Quotation_No%Type; --报价单号
    v_Account_Num_List     Varchar2(2000); --验收单列表
    v_Uesed_Amount         Number; --已结算成功的金额
    v_count                Number;
  Begin
    Flag     := '1';
    Flag_Msg := '释放预算成功';
  
    Begin
      Select *
        Into v_Order_Header_Info
        From t_Pmt_Quotation_Head
       Where Quotation_Id = Header_Id
         For Update Wait 2;
    Exception
      When Others Then
        Flag     := '02';
        Flag_Msg := '报价单不存在';
        Return;
    End;
  
    If 'N' = Nvl(v_Order_Header_Info.Budget_Flag, 'N') Then
      Flag     := '02';
      Flag_Msg := '报价单已释放预算';
      Return;
    End If;
  
    v_Entity_Id     := v_Order_Header_Info.Entity_Id;
    v_Budget_Amount := v_Order_Header_Info.Total_Amount;
    /*  V_ORGANIZATION_ID := V_ORDER_HEADER_INFO.ORGANIZATION_ID;
    V_MAIN_TYPE       := V_ORDER_HEADER_INFO.CHARGES_MAIN_TYPE_ID;
    V_SUB_TYPE        := V_ORDER_HEADER_INFO.CHARGES_SUB_TYPE_ID;*/
    v_Budget_Segment_01_Id := v_Order_Header_Info.Budget_Segment_01_Id;
    v_Budget_Segment_02_Id := v_Order_Header_Info.Budget_Segment_02_Id;
    v_Budget_Segment_03_Id := v_Order_Header_Info.Budget_Segment_03_Id;
    v_Budget_Segment_04_Id := v_Order_Header_Info.Budget_Segment_04_Id;
    v_Budget_Segment_05_Id := v_Order_Header_Info.Budget_Segment_05_Id;
    v_Budget_Segment_06_Id := v_Order_Header_Info.Budget_Segment_06_Id;
    v_Budget_Tree_Id       := v_Order_Header_Info.Budget_Tree_Id;
    v_Po_Num               := v_Order_Header_Info.Quotation_No;
  
    If (v_Budget_Tree_Id Is Null) Then
      Flag     := '03';
      Flag_Msg := '预算树ID为空';
      Return;
    End If;
  
    If (v_Entity_Id Is Null) Then
      Flag     := '04';
      Flag_Msg := '主体ID为空';
      Return;
    End If;
  
    If (v_Budget_Amount Is Null Or 0 = v_Budget_Amount) Then
      Flag     := '05';
      Flag_Msg := '占用金额为0';
      Return;
    End If;
    
    --检查报价单对应的EA单是否为RELEASED状态，是才能才能关闭
    Begin
      Select nvl(Count(1),0)
        Into v_count
        From Sie_Ems.Cux_Cims_Ea_Apply_h_v@Mdims2zlemsprd
       Where Fee_Apply_Code = v_Order_Header_Info.Ea_No
         And biz_status = 'RELEASED';
      If v_count <= 0 Then
        Flag     := '02';
        Flag_Msg := '报价单对应的EA单[' || v_Order_Header_Info.Ea_No || ']在EMS的状态不是RELEASED释放状态，不允许关闭！';
        Return;
      End If;
    Exception
      When Others Then
        Flag     := '02';
        Flag_Msg := '获取报价单对应的EA单[' || v_Order_Header_Info.Ea_No || ']在EMS的状态出错！' || Sqlerrm;
        Return;
    End;
  
    --检查报价单能否释放预算
    Select To_Char(Wm_Concat(t.Account_Num))
      Into v_Account_Num_List
      From (Select Distinct h.Account_Num
              From Cims.t_Pmt_Account_Head h, Cims.t_Pmt_Account_Line l
             Where h.Account_Head_Id = l.Account_Head_Id
               And l.Po_Num = v_Po_Num
               --And h.Status <> '07') t; --结算成功
               And h.Status not in ('07', '08')) t; --结算成功，08：作废
  
    If v_Account_Num_List Is Not Null Then
      Flag     := '02';
      Flag_Msg := '报价单存在未结算成功的验收单[' || v_Account_Num_List || ']，不允许关闭释放预算！';
      Return;
    Else
      Select Nvl(Sum(l.Total_Amount), 0)
        Into v_Uesed_Amount
        From Cims.t_Pmt_Account_Head h, Cims.t_Pmt_Account_Line l
       Where h.Account_Head_Id = l.Account_Head_Id
         And l.Po_Num = v_Po_Num
         And h.Status = '07';
      v_Budget_Amount := v_Budget_Amount - v_Uesed_Amount;
      If v_Budget_Amount <= 0 Then
        Flag     := '05';
        Flag_Msg := '扣减已结算成功的金额后，预算占用金额' || v_Budget_Amount ||
                    '小于或等于0，不用释放！';
        Return;
      End If;
    End If;
    /*IF (V_ORGANIZATION_ID IS NULL) THEN
      V_ORGANIZATION_ID := -1;
    END IF;
    
    IF (V_MAIN_TYPE IS NULL) THEN
      V_MAIN_TYPE := -1;
    END IF;
    
    IF (V_SUB_TYPE IS NULL) THEN
      V_SUB_TYPE := -1;
    END IF;*/
    If (v_Budget_Segment_01_Id Is Null) Then
      v_Budget_Segment_01_Id := -1;
    End If;
    If (v_Budget_Segment_02_Id Is Null) Then
      v_Budget_Segment_02_Id := -1;
    End If;
    If (v_Budget_Segment_03_Id Is Null) Then
      v_Budget_Segment_03_Id := -1;
    End If;
    If (v_Budget_Segment_04_Id Is Null) Then
      v_Budget_Segment_04_Id := -1;
    End If;
    If (v_Budget_Segment_05_Id Is Null) Then
      v_Budget_Segment_05_Id := -1;
    End If;
    If (v_Budget_Segment_06_Id Is Null) Then
      v_Budget_Segment_06_Id := -1;
    End If;
  
    Pkg_Budget.p_Write_Fee(v_Budget_Tree_Id,
                           v_Entity_Id,
                           v_Budget_Segment_01_Id,
                           v_Budget_Segment_02_Id,
                           v_Budget_Segment_03_Id,
                           v_Budget_Segment_04_Id,
                           v_Budget_Segment_05_Id,
                           v_Budget_Segment_06_Id,
                           '报价单',
                           Header_Id,
                           v_Order_Header_Info.Quotation_No,
                           Null,
                           Null,
                           '-' || v_Budget_Amount,
                           User_Id,
                           Flag_Msg);
  
    If 'SUCCESS' <> Flag_Msg Then
      Flag     := -1;
      Flag_Msg := '调用PKG_BUDGET.P_WRITE_FEE不成功:' || Flag_Msg;
      Return;
    Else
      Flag     := '1';
      Flag_Msg := '释放预算成功！释放预算金额：' || v_Budget_Amount;
    End If;
    --最后更新报价单状态
    Update t_Pmt_Quotation_Head t
       Set t.Budget_Flag    = 'N',
           t.Status         = '80', --已关闭
           t.Release_Amount = v_Budget_Amount,
           t.Version        = Nvl(t.Version, 0) + 1
     Where Quotation_Id = Header_Id;
  End p_Quot_Cancel_Budget;
END PKG_PMT_QUOTATION;
/

