create view V_INV_INVENTORIES as
select
ENTITY_ID,
INVENTORY_CODE,
INVENTORY_NAME,
SALES_CENTER_FLAG,
BASE_FLAG,
UNIT_ID,
INVENTORY_CATEGORY,
INVENTORY_TYPE,
ORGANIZATION_ID,
ORGANIZATION_CODE,
ORGANIZATION_NAME,
BEGIN_DATE,
END_DATE,
CREATED_BY,
CREATION_DATE,
LAST_UPDATED_BY,
LAST_UPDATE_DATE,
REMARK
from T_INV_INVENTORIES
with read only
/

comment on column V_INV_INVENTORIES.ENTITY_ID is '经营主体'
/

comment on column V_INV_INVENTORIES.INVENTORY_CODE is '仓库编码'
/

comment on column V_INV_INVENTORIES.INVENTORY_NAME is '仓库名称'
/

comment on column V_INV_INVENTORIES.SALES_CENTER_FLAG is '中心仓标识，是  01，否 00，默认只为是 01。'
/

comment on column V_INV_INVENTORIES.BASE_FLAG is '基地仓标识，是  01，否 00，默认只为否 00。'
/

comment on column V_INV_INVENTORIES.UNIT_ID is '所属中心ID，从组织单位表中选择中心，为基地仓库时，从组织单位表中选择虚拟中心。'
/

comment on column V_INV_INVENTORIES.INVENTORY_CATEGORY is '仓库类别，从代码表中获取仓库类别，仓库类别有：财务仓、虚拟仓。'
/

comment on column V_INV_INVENTORIES.INVENTORY_TYPE is '仓库类型，选择仓库类别为财务仓时，从代码中获取财务仓类型，仓库类别选择虚拟仓时，从代码表中获取虚拟仓类型。财务仓类型：正品、优惠品、破损、残次、待检、保险赔偿，虚拟仓类型：在途、未结算、退货未结算。'
/

comment on column V_INV_INVENTORIES.ORGANIZATION_ID is '组织ID，仓库对应的库存组织ID。'
/

comment on column V_INV_INVENTORIES.ORGANIZATION_CODE is '组织编码，仓库对应的库存组织编码。'
/

comment on column V_INV_INVENTORIES.ORGANIZATION_NAME is '组织名称，仓库对应的库存组织名称。'
/

comment on column V_INV_INVENTORIES.BEGIN_DATE is '生效日期'
/

comment on column V_INV_INVENTORIES.END_DATE is '失效日期'
/

comment on column V_INV_INVENTORIES.CREATED_BY is '创建人员'
/

comment on column V_INV_INVENTORIES.CREATION_DATE is '创建时间'
/

comment on column V_INV_INVENTORIES.LAST_UPDATED_BY is '最后修改人'
/

comment on column V_INV_INVENTORIES.LAST_UPDATE_DATE is '最后修改时间'
/

comment on column V_INV_INVENTORIES.REMARK is '备注'
/

