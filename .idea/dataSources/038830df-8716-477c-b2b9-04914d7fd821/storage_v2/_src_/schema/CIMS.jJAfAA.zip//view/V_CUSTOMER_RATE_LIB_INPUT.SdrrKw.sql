create view V_CUSTOMER_RATE_LIB_INPUT as
select
       max(t.template_id||h.customer_id||s.sales_main_type_id||rs.index_id) as thrsId,
       max(t.entity_id) as entity_id,
       max(t.template_id) as template_id,
       max(t.rate_description) as template_description,
       h.customer_id as customer_id,
       h.customer_code as customer_code,
       h.customer_name as customer_name,
       s.sales_main_type_code as sales_main_type_code,
       s.sales_main_type_name as sales_main_type_name,
       rs.standard_id as standard_id,
       rs.index_id as index_id,
       max(rs.index_name) as index_name,
       max(rs.is_subtract) as is_subtract,
       max(rs.is_manually) as is_manually
  from t_customer_header          h,
       t_customer_sales_main_type s,
       t_customer_brand           b,
       t_customer_channel_type    c,
       t_customer_rate_template   t,
       t_customer_rate_standard   rs
 where h.customer_id = s.custom_id
   and h.customer_id = b.customer_id
   and h.customer_id = c.customer_id
   and s.active_flag='Active' and b.active_flag='Active' and c.active_flag='Active'
   and s.entity_id=t.entity_id and b.entity_id=t.entity_id and c.entity_id=t.entity_id
   and t.sales_main_type like '%' || s.sales_main_type_code || '%'
   and t.marketing_model like '%' || s.cooperation_model_id || '%'
   and t.brand_code like '%' || b.brand_code || '%'
   and t.channel_type like '%' || c.industry_type || '%'
   and t.template_id = rs.template_id
  group by h.customer_id,h.customer_code,h.customer_name,s.sales_main_type_code,s.sales_main_type_name,rs.standard_id,rs.index_id
/

comment on column V_CUSTOMER_RATE_LIB_INPUT.THRSID is 'ID'
/

comment on column V_CUSTOMER_RATE_LIB_INPUT.ENTITY_ID is '主体ID'
/

comment on column V_CUSTOMER_RATE_LIB_INPUT.TEMPLATE_ID is '模板ID'
/

comment on column V_CUSTOMER_RATE_LIB_INPUT.TEMPLATE_DESCRIPTION is '模板描述'
/

comment on column V_CUSTOMER_RATE_LIB_INPUT.CUSTOMER_ID is '客户ID'
/

comment on column V_CUSTOMER_RATE_LIB_INPUT.CUSTOMER_CODE is '客户编码'
/

comment on column V_CUSTOMER_RATE_LIB_INPUT.CUSTOMER_NAME is '客户名称'
/

comment on column V_CUSTOMER_RATE_LIB_INPUT.SALES_MAIN_TYPE_CODE is '营销大类编码'
/

comment on column V_CUSTOMER_RATE_LIB_INPUT.SALES_MAIN_TYPE_NAME is '营销大类名称'
/

comment on column V_CUSTOMER_RATE_LIB_INPUT.STANDARD_ID is '标准ID'
/

comment on column V_CUSTOMER_RATE_LIB_INPUT.INDEX_ID is '指标ID'
/

comment on column V_CUSTOMER_RATE_LIB_INPUT.INDEX_NAME is '指标名称'
/

comment on column V_CUSTOMER_RATE_LIB_INPUT.IS_SUBTRACT is '是否减分项'
/

comment on column V_CUSTOMER_RATE_LIB_INPUT.IS_MANUALLY is '是否手动输入'
/

