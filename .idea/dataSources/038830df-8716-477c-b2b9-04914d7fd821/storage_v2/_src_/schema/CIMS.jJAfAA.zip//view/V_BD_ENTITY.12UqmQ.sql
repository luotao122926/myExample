create view V_BD_ENTITY as
select t.unit_id entity_id, --单位ID
       t.code entity_code,  --单位编码
       t.name entity_name, --单位名称
       t.type_code, --单位编码（事业部：BU,营销区域：SR ，营销中心：SC）
       t.created_by,
       t.creation_date,
       t.last_updated_by,
       t.last_update_date
  from up_org_unit t
  where t.type_code = 'BU'
 order by t.unit_id
/

