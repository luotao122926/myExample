create PACKAGE      PKG_INV_ERP_ICP_SYN  AS

  -----------------------------------------------------------------------------
  --处理ERP单边关联交易物流信息同步主过程
  -----------------------------------------------------------------------------
  PROCEDURE P_INV_ERP_ICP_SYN_MAIN
  (
    P_REQUIREMENT_ORDER_NUM IN INTF_CUX_ICP_LOGIST_REQ_HEADER.REQUIREMENT_ORDER_NUM%TYPE,--来源单据
    P_RESULT         IN OUT NUMBER, --返回错误ID
    P_ERR_MSG        IN OUT VARCHAR2 --返回错误信息
  );

  -----------------------------------------------------------------------------
  --更新头表
  -----------------------------------------------------------------------------
  PROCEDURE P_UPDATE_LOGIST_HEADER_INTF
  (
    P_HEADER IN INTF_CUX_ICP_LOGIST_REQ_HEADER%ROWTYPE,
    P_RESULT         IN OUT NUMBER, --返回错误ID
    P_ERR_MSG        IN OUT VARCHAR2 --返回错误信息
  );

  -----------------------------------------------------------------------------
  --处理订单产品单位
  -----------------------------------------------------------------------------
  PROCEDURE P_UPDATE_ITEM_UNIT
  (
    P_ORDER_NUM IN   VARCHAR2,--来源单据
    P_RESULT         IN OUT NUMBER, --返回错误ID
    P_ERR_MSG        IN OUT VARCHAR2 --返回错误信息
  );

END PKG_INV_ERP_ICP_SYN;
/

