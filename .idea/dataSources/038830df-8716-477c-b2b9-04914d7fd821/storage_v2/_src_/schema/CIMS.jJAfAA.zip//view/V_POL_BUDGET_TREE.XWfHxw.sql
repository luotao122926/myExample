create view V_POL_BUDGET_TREE as
SELECT
    t.entity_id ENTITY_ID,
    t.last_year_amount LAST_YEAR_AMOUNT,
    t.beginning_balance_amount BEGINNING_BALANCE_AMOUNT,
    t.current_new_amount CURRENT_NEW_AMOUNT,
    t.current_occupation_amount CURRENT_OCCUPATION_AMOUNT,
    t.effective_amount EFFECTIVE_AMOUNT,
    t.ending_balance_amount ENDING_BALANCE_AMOUNT,
    '' SALES_MAIN_TYPE,
    t.settle_flag SETTLE_FLAG,
    '' CUSTOMER_CODE,
    '' SALES_CENTER_CODE
  FROM T_POL_BUDGET_TREE t
/

