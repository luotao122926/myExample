create package body      PKG_PUB is
  
  v_Nl      Constant Varchar2(2) := Chr(13) || Chr(10); --换行
  v_Null    Constant Varchar2(4) := 'NULL'; --空值
  v_True    Constant Varchar2(2) := 'Y';
  v_False   Constant Varchar2(2) := 'N';
  v_Result  Constant Number := 0; --成功返回
  v_Success Constant Varchar2(10) := 'SUCCESS';
  v_Failure Constant Varchar2(10) := 'FAILURE';
  v_Base_Exception Exception; --自定义异常
-------------------------------------------------------------------------------
--锁定数据（动态）
--返回：锁定成功1，失败0
-------------------------------------------------------------------------------
FUNCTION F_PUB_LOCK_RECORD
(
  P_TABLE_NAME VARCHAR2                       --表名
  ,P_SQL_WHERE VARCHAR2 DEFAULT NULL          --条件
  ,P_FIELDS VARCHAR2 DEFAULT NULL             --列名
)
RETURN NUMBER                                 --锁定成功1，失败0
IS
  V_CHECK_SQL VARCHAR2(4000);
  V_CHECK_HANDLE INTEGER;
  V_CNT NUMBER;
BEGIN
  IF P_SQL_WHERE IS NULL THEN
    V_CHECK_SQL := 'SELECT * FROM '||P_TABLE_NAME||' FOR UPDATE';
  ELSE
    V_CHECK_SQL := 'SELECT * FROM '||P_TABLE_NAME||' WHERE '||P_SQL_WHERE||' FOR UPDATE';
  END IF;
  IF P_FIELDS IS NULL THEN
    V_CHECK_SQL := V_CHECK_SQL||' NOWAIT';
  ELSE
    V_CHECK_SQL := V_CHECK_SQL||' OF '||P_FIELDS||' NOWAIT';
  END IF;
  V_CHECK_HANDLE:=DBMS_SQL.OPEN_CURSOR;
  DBMS_SQL.PARSE(V_CHECK_HANDLE,V_CHECK_SQL,DBMS_SQL.V7);
  V_CNT:=DBMS_SQL.EXECUTE(V_CHECK_HANDLE);
  DBMS_SQL.CLOSE_CURSOR(V_CHECK_HANDLE);
  RETURN 1;
EXCEPTION
    WHEN OTHERS THEN
        RETURN 0;
END;

  --------------------------------------------------------------------------------------------
  -- Author  : huanghb12
  -- Created : 2019-03-14
  -- Purpose : 写入平台统一下载的附件表，job会每隔几分钟下载一次
  --------------------------------------------------------------------------------------------
  PROCEDURE P_DOWNLOAD_FILE(P_BUSINESS_ID     IN VARCHAR2, --附件ID
                                  P_BUSINESS_TYPE   IN VARCHAR2, --附件业务类型
                                  P_FILE_PATH       IN VARCHAR2, --文件路径
                                  P_FILE_NAME       IN VARCHAR2, --文件名称
                                  P_RESULT          OUT VARCHAR2 --返回信息
                                  ) IS
    
    V_VALUE   VARCHAR2(500);
  BEGIN
    --非空校验
    P_RESULT := v_Success;
    
    IF(P_BUSINESS_ID IS NULL OR P_BUSINESS_TYPE IS NULL OR P_FILE_PATH IS NULL )THEN
        V_VALUE := '入参【P_BUSINESS_ID,P_BUSINESS_TYPE,P_FILE_PATH】不能为空！' || V_NL || SQLERRM;
        RAISE V_BASE_EXCEPTION;
    END IF;
    --插入附件表，将收到的附件路径，插入到附件表，后台JOB将会自动从美的云下载附件
    V_VALUE := '插入附件表';
    INSERT INTO IMS_FILEINFO_INTERFACE i
      (ID, BUSINESS_ID, BUSINESS_TYPE, FILE_PATH, FILE_NAME, CREATED_DATE)
    VALUES
      (SEQ_IMS_FILEINFO.NEXTVAL,
       P_BUSINESS_ID,
       P_BUSINESS_TYPE,
       P_FILE_PATH,
       P_FILE_NAME,
       SYSDATE);
  EXCEPTION
    WHEN V_BASE_EXCEPTION THEN
      P_RESULT := V_VALUE;
    WHEN OTHERS THEN
      P_RESULT := V_VALUE || '失败！' || V_NL || SQLERRM;
  END;

end PKG_PUB;
/

