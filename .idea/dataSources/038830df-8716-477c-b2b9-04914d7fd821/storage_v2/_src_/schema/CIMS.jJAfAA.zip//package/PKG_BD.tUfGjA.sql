create PACKAGE      PKG_BD  AS
  /*
  2016-1-25 梁学荣
  增加行政区域从接口表写正式表的处理
  2018-3-22 梁学荣
  
  
  */
  
  --通用数据权限的VPD策略
  function F_VPD_FOR_ALL(p_schema in varchar2 default NULL,
                       p_object in varchar2 default NULL) RETURN varchar2;

  procedure P_UPD_FULL_NAME
  --更新full_name值,去除字符串最后的'-'
  (P_TABLE_CODE      in varchar2, --表名
   P_FULLNAME_COLUMN in varchar2, --全称字段列
   P_ROWID_COLUMN    in varchar2, --row_id字段列
   P_FILTER_SQL      in varchar2, --过滤SQL
   P_RETURN_CODE     out varchar2, --返回编码
   P_RETURN_MSG      out varchar2); --返回提示信息

  procedure P_UPD_LEVEL_NUM_PARENT
  --当前节点作为父节点，更新其所有下级节点的分片值level_seq, level_num
  (P_TABLE_CODE      in varchar2, --表名
   P_NAME_COLUMN     in varchar2, --名称字段列
   P_FULLNAME_COLUMN in varchar2, --全称字段列
   P_ROWID_COLUMN    in varchar2, --row_id字段列
   P_PARROWID_COLUMN in varchar2, --上级ID字段列
   P_PAR_ROW_ID      in number, --上级记录ID
   P_FILTER_SQL      in varchar2, --过滤SQL
   P_RETURN_CODE     out varchar2, --返回编码
   P_RETURN_MSG      out varchar2); --返回提示信息

  procedure P_UPD_LEVEL_NUM_SELF
  --更新当前节点以及下级节点分片值level_seq, level_num
  (P_TABLE_CODE     in varchar2, --表名
   P_NAME_COLUMN    in varchar2, --名称字段
   P_FULLNAME_COLUMN in varchar2, --全称字段列
   P_ROWID_COLUMN    in varchar2, --row_id字段列名
   P_PARROWID_COLUMN in varchar2, --上级ID字段列名
   P_CURRENT_ROW_ID in out number, --本记录ID
   P_FILTER_SQL      in varchar2, --过滤SQL
   P_RETURN_CODE    out varchar2, --返回码
   P_RETURN_MSG     out varchar2); --返回提示信息

  procedure P_UPD_ORG_UNIT
  --更新up_org_unit扩展字段内容
  (P_FILTER_SQL      in varchar2, --过滤SQL
   P_RETURN_CODE     out varchar2, --返回编码
   P_RETURN_MSG      out varchar2); --返回提示信息

  procedure P_UPD_DISTINCT
  --更新t_bd_district扩展字段内容
  (P_FILTER_SQL      in varchar2, --过滤SQL
   P_RETURN_CODE     out varchar2, --返回编码
   P_RETURN_MSG      out varchar2); --返回提示信息

  function F_GET_BILL_NO
  -- --取单据号
  (
   P_BILL_TYPE    T_BD_CODE_RULE.CODE_NO%type,  --单据类别
   P_PREFIX_ADD   T_BD_CODE_RULE_DETAIL.DICT_CODE_VALUE%type, --动态附加前缀,除特别说明，一般为空
   P_ENTITY_ID    up_org_unit.ENTITY_ID%type, --业务主体ID
   P_USER_ID      up_org_user.user_id%type, --登录用户ID
   P_WAIT_BY      NUMBER DEFAULT NULL--
   ) --
   return varchar2;

  function F_GET_PARAMETER_VALUE
  -- --取系统参数值
  (
   P_CONFIG_CODE    t_bd_param_list.param_code%type,  --参数配置编码
   P_ENTITY_ID      up_org_unit.ENTITY_ID%type, --业务主体ID
   P_UNIT_ID        up_org_unit.Unit_Id%type default null, --中心ID
   P_CUSTOMER_ID    t_customer_header.customer_id%type default null --客户ID
   ) --
   return varchar2;

  procedure P_GET_BILL_NO
  --取单据号
  (
   P_BILL_TYPE    T_BD_CODE_RULE.CODE_NO%type,  --单据类别
   P_PREFIX_ADD   T_BD_CODE_RULE_DETAIL.DICT_CODE_VALUE%type, --动态附加前缀,除特别说明，一般为空
   P_ENTITY_ID    up_org_unit.ENTITY_ID%type, --业务主体ID
   P_USER_ID      up_org_user.user_id%type, --登录用户ID
   P_BILL_NO      out varchar2, --返回的单据号
   P_WAIT_BY      IN NUMBER DEFAULT NULL--
   );

  procedure P_GET_PARAMETER_VALUE
  --取系统参数值
  (
   P_CONFIG_CODE    t_bd_param_list.param_code%type,  --参数配置编码
   P_ENTITY_ID      up_org_unit.ENTITY_ID%type, --业务主体ID
   P_UNIT_ID        up_org_unit.Unit_Id%type default null, --中心ID
   P_CUSTOMER_ID    t_customer_header.customer_id%type default null, --客户ID
   P_PARAM_VALUE      out varchar2 --返回的单据号
   );

  function F_ADD_ERROR_LOG
  ----后台运行错误日志记录
  (P_ERROR_FROM  in varchar2, --错误发生来源
   P_ERROR_CODE in varchar2, --错误代码
   P_ERROR_DESC in varchar2) --错误信息
   return varchar2;

  procedure P_MONTH_ITEM_COST
  -- 生成指定月份的销售成本
  (
   P_MONTH         in varchar2,  --年月：如:201407
   P_RETURN_CODE     out varchar2, --返回编码
   P_RETURN_MSG      out varchar2); --返回提示信息

  function F_GET_PRINT_TITLE
  --取打印抬头
  (
   P_INV_ID        t_inv_inventories.inventory_id%type  --仓库ID
   ) return varchar2;

  -----------------------------------------------------------------------------
  --将行政区域接口表写正式表
  -----------------------------------------------------------------------------
  PROCEDURE P_INTF_TO_DISTRICT
  (
    IN_BATCH_ID   NUMBER   --批次ID
    ,IS_ALLOW_ERR VARCHAR2 --是否允许出错，Y：允许（将出错记录接口表中）；N：不允许（全部回滚，性能较佳）
    ,OS_MESSAGE   OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  );

  -----------------------------------------------------------------------------
  --根据树形结构关系新全称、层级等信息
  -----------------------------------------------------------------------------
  PROCEDURE P_UPDATE_DISTRICT_INFO;

  --取系统参数值(按范围取旧值表)
  function F_GET_OLD_PARAM_VALUE
  (
   P_CONFIG_CODE    t_bd_param_list.param_code%type,  --参数配置编码
   P_ENTITY_ID      up_org_unit.ENTITY_ID%type, --业务主体ID
   P_UNIT_ID        up_org_unit.Unit_Id%type default null, --中心ID
   P_CUSTOMER_ID    t_customer_header.customer_id%type default null, --客户ID, --中心ID
   IN_SCOPE         number default 0 --取旧值表范围，0取中心、客户旧值表
   )--
   return varchar2;
  
  --取系统参数值(找不到就返回主体系统参数)
  function F_GET_PARAM_VALUE_ENTITY_PRIOR
  (
   P_CONFIG_CODE    t_bd_param_list.param_code%type,  --参数配置编码
   P_ENTITY_ID      up_org_unit.ENTITY_ID%type, --业务主体ID
   P_UNIT_ID        up_org_unit.Unit_Id%type default null, --中心ID
   P_CUSTOMER_ID    t_customer_header.customer_id%type default null --客户ID
   ) --
   return varchar2;

  procedure P_GET_PARAM_VALUE_ENTITY_PRIOR
  --取系统参数值
  (
   P_CONFIG_CODE    t_bd_param_list.param_code%type,  --参数配置编码
   P_ENTITY_ID      up_org_unit.ENTITY_ID%type, --业务主体ID
   P_UNIT_ID        up_org_unit.Unit_Id%type default null, --中心ID
   P_CUSTOMER_ID    t_customer_header.customer_id%type default null, --客户ID
   P_PARAM_VALUE      out varchar2 --返回的单据号
   );
   
  -----------------------------------------------------------------------------
  -- AUTHOR  : lilh6
  -- CREATED : 2018-11-2
  -- PURPOSE : 根据收货地点编码获取4级地址返回。
  ------------------------------------------------------------------------------------                              
  Procedure p_Full_District_Code(p_Addr_Code     In Varchar2, --地点编码
                                 p_Result        Out Varchar2, --返回结果,成功返回SUCCESS，错误返回对应信息
                                 p_Province_Code Out Varchar2, --省
                                 p_City_Code     Out Varchar2, --市
                                 p_District_Code Out Varchar2, --区
                                 p_Town_Code     Out Varchar2 --镇
                                 );


  --------------------------------------------------------------------------
  --Author: guibr
  --Created: 2020-01-01
  --日志表清理
  --------------------------------------------------------------------------                              
  Procedure P_SYSTEM_LOG_DELETE(OS_MESSAGE OUT VARCHAR2);


END PKG_BD;
/

