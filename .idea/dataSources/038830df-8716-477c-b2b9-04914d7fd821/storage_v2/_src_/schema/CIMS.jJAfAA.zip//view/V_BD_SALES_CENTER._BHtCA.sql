create view V_BD_SALES_CENTER as
select t.unit_id sales_center_id, --单位ID
       t.code sales_center_code,  --单位编码
       t.name sales_center_name, --单位名称
       t.type_code, --单位编码（事业部：BU,营销区域：SR ，营销中心：SC）
       --t.par_unit_id, --上级单位ID
       (select unit_id
          from up_org_unit r
         where r.unit_id = t.par_unit_id
           and r.type_code = 'SR'
           and r.is_enabled = 'T') sales_region_id, --区域ID
       (select code
          from up_org_unit r
         where r.unit_id = t.par_unit_id
           and r.type_code = 'SR'
           and r.is_enabled = 'T') sales_region_code, --区域编码
       (select name
          from up_org_unit r
         where r.unit_id = t.par_unit_id
           and r.type_code = 'SR'
           and r.is_enabled = 'T') sales_region_name,     --区域ID
       t.entity_id,
       t.created_by,
       t.creation_date,
       t.last_updated_by,
       t.last_update_date,
       t.level_seq, --层级
       t.level_num, --层级码
       t.full_name, --单位全称
       t.unit_type
  from up_org_unit t
  where t.type_code = 'SC'
 order by t.level_num
/

