create view V_BD_USER_INV_PRIV as
select  distinct i."USER_ID",i."USER_CODE",i."USER_NAME",i."UNIT_ID",i."INVENTORY_ID",i."INVENTORY_CODE",i."INVENTORY_NAME",i."SALES_FLAG",i."ALLOT_FLAG",i."RETURN_FLAG",i."PURCHASE_FLAG",i."ENTITY_ID",i."NEGATIVE_INVENTORY_FLAG"
  from (select up.user_id, --用户ID
               up.user_code, --用户编码
               up.user_name, --用户名称
               inv.unit_id, --中心ID
               inv.inventory_id, --仓库ID
               inv.inventory_code, --仓库编码
               inv.inventory_name, --仓库名称
               inv.sales_flag, --是否可销售标识
               inv.allot_flag, --是否可调拨标识
               inv.return_flag, --是否可退货标识
               inv.purchase_flag, --是否可采购标识
               inv.negative_inventory_flag, --是否允许负库存
               up.entity_id --主体ID
          from v_bd_user_org_priv_default             up,
               t_inv_inventories_sales_center isc,
               t_inv_inventories              inv
         where up.unit_id = isc.unit_id
           and isc.inventory_id = inv.inventory_id
        --and isc.active_flag='Y'
        --and inv.active_flag = 'Y'
        union all
        --用户独立授权的仓库
        select dpi.user_id,
               uu.account user_code,
               uu.name user_name,
               inv.unit_id　unit_id, --无中心的仓库中心ID
               inv.inventory_id, --仓库ID
               inv.inventory_code, --仓库编码
               inv.inventory_name, --仓库名称
               inv.sales_flag, --是否可销售标识
               inv.allot_flag, --是否可调拨标识
               inv.return_flag, --是否可退货标识
               inv.purchase_flag, --是否可采购标识
               inv.negative_inventory_flag, --是否允许负库存
               dpi.entity_id
          from t_bd_datapriv_inv dpi, t_inv_inventories inv, up_org_user uu
         where dpi.inventory_id = inv.inventory_id
           and dpi.user_id = uu.user_id
           and dpi.active_flag = 'Y' --有效记录
        --and inv.active_flag='Y'
        union all
        select pp.user_id, --用户ID
                       pp.user_code, --用户编码
                       pp.user_name, --用户名称
                       inv.unit_id, --中心ID
                       inv.inventory_id, --仓库ID
                       inv.inventory_code, --仓库编码
                       inv.inventory_name, --仓库名称
                       inv.sales_flag, --是否可销售标识
                       inv.allot_flag, --是否可调拨标识
                       inv.return_flag, --是否可退货标识
                       inv.purchase_flag, --是否可采购标识
                       inv.negative_inventory_flag, --是否允许负库存
                       pp.entity_id --主体ID
                  from v_bd_user_prodarea_priv             pp,
                       t_pln_prdc_area_rcv_inventory pri,
                       t_inv_inventories              inv
                 where pp.PRODUCING_AREA_ID = pri.producing_area_id
                   and pri.inventory_id = inv.inventory_id
        union all
        select pp.user_id, --用户ID
                       pp.user_code, --用户编码
                       pp.user_name, --用户名称
                       inv.unit_id, --中心ID
                       inv.inventory_id, --仓库ID
                       inv.inventory_code, --仓库编码
                       inv.inventory_name, --仓库名称
                       inv.sales_flag, --是否可销售标识
                       inv.allot_flag, --是否可调拨标识
                       inv.return_flag, --是否可退货标识
                       inv.purchase_flag, --是否可采购标识
                       inv.negative_inventory_flag, --是否允许负库存
                       pp.entity_id --主体ID
                  from v_bd_user_prodarea_priv             pp,
                       t_pln_prdc_area_ec_inventory pei,
                       t_inv_inventories              inv
                 where pp.PRODUCING_AREA_ID = pei.producing_area_id
                   and pei.inventory_id = inv.inventory_id
        ) i
/

