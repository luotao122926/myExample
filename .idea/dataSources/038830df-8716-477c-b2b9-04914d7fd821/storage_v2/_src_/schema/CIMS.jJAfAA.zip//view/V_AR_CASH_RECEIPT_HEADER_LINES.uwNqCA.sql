create view V_AR_CASH_RECEIPT_HEADER_LINES as
SELECT h.cash_receipt_id, h.receipt_method_id, h.receipt_status_id,
          h.sales_year_id, h.account_id, h.cash_receipt_code,
          h.cash_receipt_date, h.gl_date, h.currency_code, h.cash_code,
          h.sub_cash_code, h.unite_flag, h.cash_date, h.due_date, h.drawer,
          h.drawer_bank_account, h.drawer_bank, h.back_write_name,
          h.first_receipt_name, h.first_receipt_bank_account,
          h.first_receipt_bank, h.acceptance_bank_name, h.budget_item_name,
          h.ar_receipt_code, h.into_erp_date, h.into_erp_error,
          h.gtms_receipt_code, h.into_gtms_date, h.into_gtms_error,
          h.created_by, h.creation_date, h.reviewed_by, h.reviewed_date,
          h.writeoff_by, h.writeoff_date, h.remaek, h.writeoff_receipt_code,
          h.customer_id, h.customer_code, h.customer_name, h.account_code,
          h.account_name, h.sales_center_id, h.entity_id, h.TYPE,
          h.is_honestly, h.source_type, h.contract_num, h.is_writeoff,
          h.erp_ou_name, h.print_num, h.is_print_lock, h.gtms_regis_time,
          h.gtms_sign_time, h.gtms_sign_flag, h.cash_turnfee_id,
          h.refund_apply_id, h.erp_ou_id, h.upper_amount, h.into_gtms_status,
          h.into_erp_status, h.invoice_header_id, h.invoice_line_id,
          h.gtsp_intf_status, h.writeoff_reason, h.bad_bill_header_id,
          h.appendix_id, h.updated_by, h.updated_date, h.used_flag,
          h.attribute1, h.attribute2, h.attribute3, h.attribute4,
          h.attribute5, h.attribute6, h.attribute7, h.attribute8,
          h.attribute9, h.attribute10, l.cash_receipt_lines_id, l.amount,
          l.sales_main_type_id, l.sales_main_type_code,
          l.sales_main_type_name, l.brand_code,L.REMARK line_remark,h.discount_type
     FROM t_ar_cash_receipt_headers h, t_ar_cash_receipt_lines l
    WHERE h.cash_receipt_id = l.cash_receipt_id(+)
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.CASH_RECEIPT_ID is '收款单据ID'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.RECEIPT_METHOD_ID is '收款方法ID'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.RECEIPT_STATUS_ID is '状态ID.码表CODETYPE=ar_reciept_status'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.SALES_YEAR_ID is '销售年度id'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.ACCOUNT_ID is '账户ID'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.CASH_RECEIPT_CODE is '收款单据号'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.CASH_RECEIPT_DATE is '单据日期'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.GL_DATE is '总账日期'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.CURRENCY_CODE is '币种'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.CASH_CODE is '票据号'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.SUB_CASH_CODE is '票据分号'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.UNITE_FLAG is '分并导入'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.CASH_DATE is '出票日期'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.DUE_DATE is '票据到期日期'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.DRAWER is '出票人'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.DRAWER_BANK_ACCOUNT is '出票人银行账户'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.DRAWER_BANK is '出票银行'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.BACK_WRITE_NAME is '上手背书人'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.FIRST_RECEIPT_NAME is '第一收款人'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.FIRST_RECEIPT_BANK_ACCOUNT is '第一收款人开户银行账户'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.FIRST_RECEIPT_BANK is '第一收款人开户银行'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.ACCEPTANCE_BANK_NAME is '承兑银行号'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.BUDGET_ITEM_NAME is '预算项目'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.AR_RECEIPT_CODE is 'ERP收款单据号'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.INTO_ERP_DATE is '引入ERP时间'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.INTO_ERP_ERROR is '引入ERP错误'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.GTMS_RECEIPT_CODE is '资金系统回单号'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.INTO_GTMS_DATE is '引入资金系统时间'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.INTO_GTMS_ERROR is '引入资金系统错误'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.CREATED_BY is '制单人'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.CREATION_DATE is '制单时间'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.REVIEWED_BY is '确认人'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.REVIEWED_DATE is '确认时间'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.WRITEOFF_BY is '冲销人'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.WRITEOFF_DATE is '冲销时间'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.REMAEK is '备注'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.WRITEOFF_RECEIPT_CODE is '冲销原单据号'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.CUSTOMER_ID is '客户ID'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.CUSTOMER_CODE is '客户编码'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.CUSTOMER_NAME is '客户名称'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.ACCOUNT_CODE is '账户编码'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.ACCOUNT_NAME is '账户名称'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.SALES_CENTER_ID is '营销中心ID'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.ENTITY_ID is '主体ID'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.TYPE is '业务类型'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.IS_HONESTLY is '是否专款专用(Y/N)'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.SOURCE_TYPE is '来源类型(甲方合同/工程项目)'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.CONTRACT_NUM is '合同号（对应来源类型）'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.IS_WRITEOFF is '是否已冲销'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.ERP_OU_NAME is 'ERP_OU'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.PRINT_NUM is '打印次数'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.IS_PRINT_LOCK is '是否打印锁定'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.GTMS_REGIS_TIME is '资金系统登记时间'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.GTMS_SIGN_TIME is '资金系统签收时间'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.GTMS_SIGN_FLAG is '资金系统签收标志'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.CASH_TURNFEE_ID is '转款ID'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.REFUND_APPLY_ID is '退款申请ID'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.ERP_OU_ID is 'ERP_OU_ID'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.UPPER_AMOUNT is '大写金额'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.INTO_GTMS_STATUS is '引入资金状态 0：成功 1：失败'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.INTO_ERP_STATUS is '引入ERP状态  0：成功 1：失败'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.INVOICE_HEADER_ID is '发票头ID'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.INVOICE_LINE_ID is '发票行ID'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.GTSP_INTF_STATUS is '资金系统接口状态'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.WRITEOFF_REASON is '收款冲销原因id'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.BAD_BILL_HEADER_ID is '坏账确认头id'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.APPENDIX_ID is '附件上传id'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.UPDATED_BY is '修改人'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.UPDATED_DATE is '修改时间'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.USED_FLAG is '是否已使用（核销财务单）核销标志 N:未核销 P:部分核销 Y：已核销'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.ATTRIBUTE1 is '是否引入内部ERP接口表（后台代码标记）'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.ATTRIBUTE2 is '是否引入GTMS内部接口表（后台代码标记）'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.ATTRIBUTE3 is '单据来源（如IMS、ESB等）'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.ATTRIBUTE4 is '来源单号'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.ATTRIBUTE5 is '核销状态'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.ATTRIBUTE6 is '核销日期'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.ATTRIBUTE7 is '电汇收款-银行账户名称'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.ATTRIBUTE8 is '自动确认提示信息'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.ATTRIBUTE9 is '关联交易号'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.ATTRIBUTE10 is '中心审核标志（Y表示已审核；其他值表示未审核)'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.CASH_RECEIPT_LINES_ID is '收款单据行ID'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.AMOUNT is '行金额'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.SALES_MAIN_TYPE_ID is '营销大类ID'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.SALES_MAIN_TYPE_CODE is '营销大类编码'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.SALES_MAIN_TYPE_NAME is '营销大类名称'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.BRAND_CODE is '经营品牌'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.LINE_REMARK is '行备注'
/

comment on column V_AR_CASH_RECEIPT_HEADER_LINES.DISCOUNT_TYPE is '折扣类型'
/

