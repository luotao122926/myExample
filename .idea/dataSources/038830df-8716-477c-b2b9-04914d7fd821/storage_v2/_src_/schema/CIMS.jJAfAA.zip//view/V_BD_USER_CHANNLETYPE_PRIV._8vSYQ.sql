create view V_BD_USER_CHANNLETYPE_PRIV as
select distinct c."USER_ID",c."USER_CODE",c."USER_NAME",c."CODE_ID",c."CODE_VALUE",c."CODE_NAME",c."ENTITY_ID"
  from (select dpc.user_id,
               uu.account user_code,
               uu.name user_name,
               uc.code_id, --渠道类型ID
               uc.code_value, --渠道类型编码
               uc.code_name, --渠道类型名称
               dpc.entity_id
          from t_bd_datapriv_channeltype dpc,
               (select codetype,
                       codetype_name,
                       id code_id,
                       code_value,
                       code_name
                  from up_codelist
                 where codetype = 'MIDEA_ACCNT_CHANNEL_TYPE') uc,
               up_org_user uu
         where dpc.cust_channel_type = uc.code_value
           and dpc.user_id = uu.user_id
           and dpc.active_flag = 'Y' --有效记录
        ) c
/

