create procedure P_INV_CHECK_TRANSACTION(I_ENTITY_ID IN INTEGER) IS
  /** v1.1
     增加不需要对账内容
  */

  /** v1.2
    -- 20150813
    1、排除不对账单据内容-inv_check_all
  
  */

  --ERP库存事务记录数
  count_inv_gerp integer;

  --数量，查询结果
  i_qty_temp number;

  -- 单据记录数
  i_bill_count number;

  -- 备注长度，1000个字(数字、字母、汉字均按照1个字计算)
  i_remark_length number := 1000;

  -- 主体
  v_entity_id integer;

  -- 执行SQL后是否及时提交事务
  b_immediate_commit boolean;

  -- 单据对账是否成功标志
  str_status varchar2(2);
  -- 对账开始日期
  str_start_date varchar2(20);
  -- 对账结束日期
  str_end_date varchar2(20);
  -- 对账结果
  str_msg varchar2(2000);

  --单据最终状态-盘点执行
  str_status_end varchar2(2);
  --单据状态名称
  str_status_meaning varchar2(20);
  --仓库编码
  str_inv_code varchar2(40);
  -- 单据行信息
  str_bill_line_msg varchar2(2000);

  -- 调拨单、仓库、产品编码、CIMS数量、GERP数量，差异原因
  str_select_sql varchar2(4000);
  -- 插入对照表SQL
  str_insert_sql varchar2(4000);
  -- 删除已出错单据
  str_delete_sql varchar2(4000);

  -- CIMS盘点单
  cursor inv_check_all(in_entity_id number, in_start_date varchar2, in_end_date varchar2) is
    select inv_check.check_order_num bill_no,
           bill_type.bill_period_head_id,
           bill_type.bill_type_name bill_type
      from cims.t_inv_check_orders inv_check,
           cims.t_inv_bill_types   bill_type
     where bill_type.entity_id = in_entity_id
       and inv_check.entity_id = in_entity_id
       and inv_check.check_order_type = bill_type.bill_type_code
       and not exists
     (select 1
              from cims.t_inv_taction_reconciliation rec
             where rec.entity_id = in_entity_id
               and rec.business_num = inv_check.check_order_num)
       and exists
     (select 1
              from cims.t_inv_transaction_history invh
             where invh.business_num = inv_check.check_order_num
               and invh.entity_id = inv_check.entity_id
               and invh.transaction_date >=
                   to_date(in_start_date, 'yyyy-mm-dd')
               and invh.transaction_date <
                   to_date(in_end_date, 'yyyy-mm-dd'));

  -- 盘点单库存事务
  cursor inv_check_cims(in_entity_id number, in_bill_no varchar2, in_status varchar2) is
    select 'CIMS' sys_name,
           inv_his.business_num bill_no,
           inv_his.inventory_code inv_code,
           inv_his.item_code,
           sum(inv_his.transaction_quantity) qty
      from cims.t_inv_transaction_history inv_his
     where inv_his.entity_id = in_entity_id
       and inv_his.business_num = in_bill_no
       and inv_his.business_state = in_status
       and exists
     (select 1
              from cims.t_inv_check_orders inv_check
             where inv_check.check_order_num = inv_his.business_num
               and inv_check.entity_id = in_entity_id)
     group by inv_his.business_num,
              inv_his.inventory_code,
              inv_his.item_code;

  -- CIMS没有形成库存事务
  cursor inv_check_cims_nexists(in_entity_id number, in_status varchar2) is
    select bill_no, inv_code, item_code, bill_type, status, sum(qty) qty
      from (select inv_check.check_order_num bill_no,
                   inv_check.inv_code        inv_code,
                   inv_check_l.item_code     item_code,
                   bill_type.bill_type_name  bill_type,
                   period_l.bill_status_code status,
                   inv_check_l.exec_qty      qty
              from cims.t_inv_check_orders      inv_check,
                   cims.t_inv_check_order_lines inv_check_l,
                   cims.t_inv_bill_types        bill_type,
                   cims.t_inv_bill_period_line  period_l
             where inv_check.check_order_id = inv_check_l.check_order_id
               and inv_check.check_order_type = bill_type.bill_type_code
               and bill_type.bill_period_head_id =
                   period_l.bill_period_head_id
                  --and inv_check.check_order_num = ''
               and bill_type.entity_id = in_entity_id
               and inv_check.entity_id = in_entity_id
               and period_l.transaction_flag = 'Y'
               and inv_check.po_status = in_status
               and not exists
             (select 1
                      from cims.t_inv_taction_reconciliation rec
                     where rec.business_num = inv_check.check_order_num
                       and rec.entity_id = in_entity_id
                       and rec.item_code = inv_check_l.item_code)
               and not exists
             (select 1
                      from cims.t_inv_transaction_history invh
                     where invh.business_num = inv_check.check_order_num
                       and invh.item_code = inv_check_l.item_code
                       and invh.business_state = period_l.bill_status_code))
     group by bill_no, inv_code, item_code, bill_type, status;

  -- 单据周期
  cursor bill_period(in_period_head_id number) is
    select inv_period_l.bill_status_code status
      from cims.t_inv_bill_period_line inv_period_l
     where inv_period_l.transaction_flag = 'Y'
       and inv_period_l.bill_period_head_id = in_period_head_id;

  -- 返回不对账的SQL
  function f_get_n_reconciliation(in_entity_id_f in varchar2) return varchar2 is
    return_sql      varchar2(4000);
    return_sql_temp varchar2(4000);
  begin
    return_sql_temp := 'select inv_bill.bill_type_name business_type, ' ||
                       '       h.business_num bill_no, ' ||
                       '       h.inventory_code inv_code, ' ||
                       '       h.item_code item_code, ' ||
                       '       sum(h.transaction_quantity) cims_qty, ' ||
                       '       sum(h.transaction_quantity) gerp_qty ' ||
                       '  from cims.t_inv_transaction_history h, cims.t_inv_bill_types inv_bill ' ||
                       ' where h.entity_id = ' || in_entity_id_f ||
                       '   and h.bill_type_id = inv_bill.bill_type_id ' ||
                       '   and h.entity_id = inv_bill.entity_id ' ||
                       '  and not exists(select 1 from cims.t_inv_taction_reconciliation rec ' ||
                       '  where rec.entity_id=' || in_entity_id_f ||
                       '    and rec.business_num=h.business_num ' ||
                       '    and rec.inv_code=h.inventory_code ' ||
                       '    and rec.reconciliation_type = ''INV_CHECK''' ||
                       '    and rec.item_code=h.item_code)' ||
                       '   and exists (select 1 ' ||
                       '          from cims.t_inv_taction_reconcil_line recl ' ||
                       '         where h.business_num = recl.business_num ' ||
                       '           and recl.reconciliation_type = ''INV_CHECK'') ' ||
                       ' group by inv_bill.bill_type_name, ' ||
                       '          h.business_num, ' ||
                       '          h.inventory_code, ' ||
                       '          h.item_code ';
  
    return_sql := ' insert into cims.t_inv_taction_reconciliation ' ||
                  '  (entity_id, ' || '   business_type, ' ||
                  '   business_num, ' || '   reconciliation_time, ' ||
                  '   reconciliation_flag, ' || '   status, ' ||
                  '   inv_code, ' || '   item_code, ' || '   cims_qty, ' ||
                  '   gerp_qty, ' || '   remark, ' || '   created_by, ' ||
                  '   creation_date, ' || '   last_updated_by, ' ||
                  '   last_update_date,reconciliation_type,' ||
                  'erp_order_header_id,erp_logist_header_id) ' ||
                  ' select ' || in_entity_id_f ||
                  ' entity_id, business_type, bill_no  business_num, ' ||
                  ' sysdate  reconciliation_time, ' ||
                  ' ''00''  reconciliation_flag, decode(sign(cims_qty-cims_qty),0,''00'',''01'')  status, ' ||
                  '   inv_code, ' || '   item_code, ' || '   cims_qty, ' ||
                  ' cims_qty gerp_qty, ' ||
                  '   ''盘点单账务调整-无差异'' remark, ' ||
                  ' ''SYS''  created_by, ' || ' sysdate  creation_date, ' ||
                  ' ''SYS''  last_updated_by, ' ||
                  ' sysdate  last_update_date,''INV_CHECK'' reconciliation_type,0 erp_order_header_id,0 erp_logist_header_id from (' ||
                  return_sql_temp || ') bill_all ' || '  where 1=1 ';
  
    return return_sql;
  end;
begin
  -- Test statements here

  -- 初始化参数
  --v_entity_id    := 10;
  v_entity_id := I_ENTITY_ID;
  --str_start_date := '2014-12-01';
  str_start_date := to_char(sysdate - 90, 'yyyy-mm-dd');
  --str_end_date   := '2015-01-23';
  str_end_date := to_char(sysdate + 1, 'yyyy-mm-dd');

  b_immediate_commit := true; -- 全过程处理一次完成

  str_status_end := '14'; -- 单据最终状态，盘点执行

  --- 删除对账不成功单据
  str_delete_sql := ' delete cims.t_inv_taction_reconciliation rec ' ||
                    '  where rec.entity_id = ' || v_entity_id ||
                    '   and rec.reconciliation_type = ''INV_CHECK''' ||
                    '   and exists (select 1 ' ||
                    '          from cims.t_inv_taction_reconciliation rec2 ' ||
                    '         where rec.business_num = rec2.business_num ' ||
                    '           and rec2.status = ''01'' ' ||
                    '           and rec2.reconciliation_type = ''INV_CHECK'') ';

  execute immediate str_delete_sql;
  if b_immediate_commit then
    commit;
  end if;

  --不参与对账单据
  str_insert_sql := f_get_n_reconciliation(v_entity_id);

  if str_insert_sql is not null then
    execute immediate str_insert_sql;
    if b_immediate_commit then
      commit;
    end if;
  end if;

  for inv_check_all_01 in inv_check_all(v_entity_id,
                                        str_start_date,
                                        str_end_date) loop
  
    -- 单据周期                      
    for bill_period_01 in bill_period(inv_check_all_01.bill_period_head_id) loop
    
      -- CIMS库存事务
      for inv_check_cims_01 in inv_check_cims(v_entity_id,
                                              inv_check_all_01.bill_no,
                                              bill_period_01.status) loop
      
        select count(*)
          into count_inv_gerp
          from apps.mtl_material_transactions@mdims2mderp inv_erp,
               apps.mtl_system_items_b@mdims2mderp        mtl
         where 1 = 1
           and inv_erp.inventory_item_id = mtl.inventory_item_id
           and inv_erp.organization_id = mtl.organization_id
           and inv_erp.transaction_reference = inv_check_cims_01.bill_no
           and inv_erp.subinventory_code = inv_check_cims_01.inv_code
           and mtl.segment1 = inv_check_cims_01.item_code
           and inv_erp.source_code = 'CIMS';
      
        -- ERP没有库存事务,查找原因
        if count_inv_gerp = 0 then
          begin
            -- 库存事务接口表
            select count(*)
              into i_bill_count
              from cims.intf_inv_transaction_head invh
             where invh.order_num = inv_check_cims_01.bill_no
               and invh.status <> 'S';
          
            -- 取其中1个的事务异常
            if i_bill_count > 0 then
              begin
                select decode(nvl(invh.error_flag, 'N'),
                              'Y',
                              invh.error_msg,
                              decode(nvl(invh.response_type, 'N'),
                                     'E',
                                     invh.response_message,
                                     '等待GERP返回调拨单处理结果'))
                  into str_bill_line_msg
                  from cims.intf_inv_transaction_head invh
                 where invh.order_num = inv_check_cims_01.bill_no
                   and invh.status <> 'S'
                   and invh.entity_id = v_entity_id
                   and rownum < 2;
              
                if str_bill_line_msg is null then
                  str_bill_line_msg := 'CIMS库存事务接口正常,需进一步验证';
                end if;
              end;
            else
              begin
                str_bill_line_msg := 'CIMS库存事务接口无数据';
              end;
            end if; -- end 取事务异常 if i_inv_bill_count >= 1 then            
          end; -- -- end ERP没有库存事务查找原因
        else
          begin
            -- 有库存事务，核对结果
            select sum(inv_erp.transaction_quantity)
              into i_qty_temp
              from apps.mtl_material_transactions@mdims2mderp inv_erp,
                   apps.mtl_system_items_b@mdims2mderp        mtl
             where 1 = 1
               and inv_erp.inventory_item_id = mtl.inventory_item_id
               and inv_erp.organization_id = mtl.organization_id
               and inv_erp.transaction_reference =
                   inv_check_cims_01.bill_no
               and inv_erp.subinventory_code = inv_check_cims_01.inv_code
               and mtl.segment1 = inv_check_cims_01.item_code
               and inv_erp.source_code = 'CIMS';
          
            -- 库存事务数量不相等
            if inv_check_cims_01.qty <> i_qty_temp then
              begin
                str_bill_line_msg := 'CIMS与GERP均有库存事务,但数量不相等';
              end;
            else
              begin
                str_bill_line_msg := null; --无差异
                --str_msg               := '盘点单无差异';
              end;
            end if;
          end;
        end if;
      
        if str_bill_line_msg is null then
          str_msg    := '盘点单无差异';
          str_status := '00';
        else
          str_msg    := '盘点单有差异' || str_bill_line_msg;
          str_status := '01';
        end if;
      
        str_select_sql := 'select bill_no,inv_code,item_code,sum(cims_qty) cims_qty,' ||
                          'sum(gerp_qty) gerp_qty,substr(''' || str_msg ||
                          ''',1,' || I_remark_length || ') remark ' ||
                          ' from (select invh.business_num bill_no,' ||
                          '  invh.inventory_code inv_code,' ||
                          '  invh.item_code,' ||
                          '  invh.transaction_quantity cims_qty,' ||
                          '  0 gerp_qty ' ||
                          '  from cims.t_inv_transaction_history invh' ||
                          ' where invh.entity_id = ' || v_entity_id ||
                          ' and invh.business_num = ''' ||
                          inv_check_all_01.bill_no ||
                          ''' and invh.inventory_code = ''' ||
                          inv_check_cims_01.inv_code ||
                          ''' and invh.item_code = ''' ||
                          inv_check_cims_01.item_code || ''' union all ' ||
                          ' select inv_erp.transaction_reference bill_no,' ||
                          '  inv_erp.subinventory_code inv_code,' ||
                          '  mtl.segment1 item_code,' || '  0 cims_qty,' ||
                          '  inv_erp.transaction_quantity gerp_qty ' ||
                          '  from apps.mtl_material_transactions@mdims2mderp inv_erp,' ||
                          '  apps.mtl_system_items_b@mdims2mderp        mtl' ||
                          ' where 1 = 1 ' ||
                          '  and inv_erp.inventory_item_id = mtl.inventory_item_id' ||
                          '   and inv_erp.organization_id = mtl.organization_id ' ||
                          '   and inv_erp.transaction_reference = ''' ||
                          inv_check_all_01.bill_no ||
                          ''' and inv_erp.subinventory_code = ''' ||
                          inv_check_cims_01.inv_code ||
                          ''' and mtl.segment1 = ''' ||
                          inv_check_cims_01.item_code ||
                          ''' and inv_erp.source_code=''CIMS'')' ||
                          ' group by bill_no,inv_code,item_code ';
      
        str_insert_sql := ' insert into cims.t_inv_taction_reconciliation ' ||
                          '  (entity_id, ' || '   business_type, ' ||
                          '   business_num, ' || '   reconciliation_time, ' ||
                          '   reconciliation_flag, ' || '   status, ' ||
                          '   inv_code, ' || '   item_code, ' ||
                          '   cims_qty, ' || '   gerp_qty, ' ||
                          '   remark, ' || '   created_by, ' ||
                          '   creation_date, ' || '   last_updated_by, ' ||
                          '   last_update_date,reconciliation_type) ' ||
                          ' select ' || v_entity_id || ' entity_id, ''' ||
                          inv_check_all_01.bill_type ||
                          '''   business_type, ''' ||
                          inv_check_all_01.bill_no || '''   business_num, ' ||
                          ' sysdate  reconciliation_time, ' ||
                          ' ''00''  reconciliation_flag, ' || ' ''' ||
                          str_status || '''  status, ' || '   inv_code, ' ||
                          '   item_code, ' || '   cims_qty, ' ||
                          '   gerp_qty, ' || '   remark, ' ||
                          ' ''SYS''  created_by, ' ||
                          ' sysdate  creation_date, ' ||
                          ' ''SYS''  last_updated_by, ' ||
                          ' sysdate  last_update_date,''INV_CHECK'' reconciliation_type from (' ||
                          str_select_sql || ') bill_all ' || '  where 1=1 ' ||
                          '  and not exists(select 1 from cims.t_inv_taction_reconciliation recc' ||
                          '  where recc.entity_id=' || v_entity_id ||
                          ' and recc.business_num=bill_all.bill_no ' ||
                          ' and recc.inv_code=bill_all.inv_code ' ||
                          ' and recc.reconciliation_type = ''INV_CHECK%''' ||
                          ' and recc.item_code=bill_all.item_code)';
      
        --dbms_output.put_line(str_select_sql);    
        -- execute immediate str_select_sql;
        execute immediate str_insert_sql;
        if b_immediate_commit then
          commit;
        end if;
      
      end loop; -- end CIMS库存事务 for inv_check_cims_01     
    
    end loop; -- end 单据周期 for bill_period_01                                  
  
  end loop; -- end 循环盘点单 for inv_check_all_01

  for inv_check_cims_nexists_01 in inv_check_cims_nexists(v_entity_id,
                                                          str_status_end) loop
    -- str_status_meaning
    select codelist.code_name
      into str_status_meaning
      from cims.up_codelist codelist
     where codelist.codetype = 'INV_CHECK_ORDERS_STATUS'
       and codelist.code_value = inv_check_cims_nexists_01.status
       and rownum < 2;
  
    str_bill_line_msg := '盘点单有差异，单据在' || str_status_meaning ||
                         '时CIMS未产生库存事务,数量' ||
                         inv_check_cims_nexists_01.qty;
  
    select nvl(sum(inv_erp.transaction_quantity), 0) qty
      into i_qty_temp
      from apps.mtl_material_transactions@mdims2mderp inv_erp,
           apps.mtl_system_items_b@mdims2mderp        mtl
     where 1 = 1
       and inv_erp.inventory_item_id = mtl.inventory_item_id
       and inv_erp.organization_id = mtl.organization_id
       and inv_erp.transaction_reference =
           inv_check_cims_nexists_01.bill_no
       and inv_erp.subinventory_code = inv_check_cims_nexists_01.inv_code
       and mtl.segment1 = inv_check_cims_nexists_01.item_code
       and inv_erp.source_code = 'CIMS';
  
    str_select_sql := ' select ''' || inv_check_cims_nexists_01.bill_no ||
                      ''' bill_no ,''' ||
                      inv_check_cims_nexists_01.inv_code ||
                      ''' inv_code,''' ||
                      inv_check_cims_nexists_01.item_code ||
                      ''' item_code,' || '''' ||
                      inv_check_cims_nexists_01.bill_type ||
                      ''' bill_type,0 cims_qty,' || ' ' || i_qty_temp ||
                      ' gerp_qty,substr(''' || str_bill_line_msg || ''',1,' ||
                      i_remark_length || ') remark ' || ' from dual ';
  
    str_insert_sql := ' insert into cims.t_inv_taction_reconciliation ' ||
                      '  (entity_id, ' || '   business_type, ' ||
                      '   business_num, ' || '   reconciliation_time, ' ||
                      '   reconciliation_flag, ' || '   status, ' ||
                      '   inv_code, ' || '   item_code, ' ||
                      '   cims_qty, ' || '   gerp_qty, ' || '   remark, ' ||
                      '   created_by, ' || '   creation_date, ' ||
                      '   last_updated_by, ' ||
                      '   last_update_date,reconciliation_type) ' ||
                      ' select ' || v_entity_id ||
                      ' entity_id, bill_type  business_type, ''' ||
                      inv_check_cims_nexists_01.bill_no ||
                      '''   business_num, ' ||
                      ' sysdate  reconciliation_time, ' ||
                      ' ''00''  reconciliation_flag, ' ||
                      ' ''01''  status, ' || '   inv_code, ' ||
                      '   item_code, ' || '   cims_qty, ' ||
                      '   gerp_qty, ' || '   remark, ' ||
                      ' ''SYS''  created_by, ' ||
                      ' sysdate  creation_date, ' ||
                      ' ''SYS''  last_updated_by, ' ||
                      ' sysdate  last_update_date,''INV_CHECK'' reconciliation_type from (' ||
                      str_select_sql || ') bill_all ' || '  where 1=1 ' ||
                      '  and not exists(select 1 from cims.t_inv_taction_reconciliation recc' ||
                      '  where recc.entity_id=' || v_entity_id ||
                      ' and recc.business_num=bill_all.bill_no ' ||
                      ' and recc.inv_code=bill_all.inv_code ' ||
                      ' and recc.reconciliation_type = ''INV_CHECK''' ||
                      ' and recc.item_code=bill_all.item_code)';
  
    --execute immediate str_select_sql;
    execute immediate str_insert_sql;
    if b_immediate_commit then
      commit;
    end if;
  end loop;

  commit;

end P_INV_CHECK_TRANSACTION;
/

