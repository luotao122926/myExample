create package PKG_INV_DBLINK is

  -- Author  : SUU
  -- Created : 2016-12-13 09:31:35
  -- Purpose : 和erp关联的dblink独立出来
  

  --------------------------------------------------------------------------
  --Author: sushu
  -- Created : 2016-12-13
  --Purpose:中转单关联交易校验产品是否分配有效的供应商
  --------------------------------------------------------------------------
  Procedure p_item_vendor_relation(p_Po_Num In varchar2, --中转单号
                                   p_Entity_Id In Number, --主体
                                   p_Result       Out varchar2); --返回的结果
                                   
  --------------------------------------------------------------------------
  --Author: sushu
  -- Created : 2016-12-19
  --Purpose:工单入库校验产品是否分配有效的供应商
  --------------------------------------------------------------------------
  Procedure p_wip_item_vendor_relation(p_Trace_Trans_Id In Number, --中转单号
                                   p_Entity_Id In Number, --主体
                                   p_Result       Out varchar2); --返回的结果


end PKG_INV_DBLINK;
/

