create view V_AR_SO_TRX_HEADER as
SELECT d.invoice_corporation, d.erp_ou_name, d.so_header_id, d.entity_id,
          d.sales_year_id, d.bill_type_id, d.bill_type_code, d.bill_type_name,
          d.biz_src_bill_type_id, d.biz_src_bill_type_code,
          d.biz_src_bill_type_name, d.so_num, d.so_status, d.so_date,
          d.orig_so_num, d.src_bill_type_id, d.src_bill_id, d.src_bill_num,
          d.project_type_code, d.project_id, d.project_num, d.brand_id,
          d.brand_code, d.brand_name, d.sales_main_type,
          d.sales_main_type_name, d.customer_id, d.customer_code,
          d.customer_name, d.account_id, d.account_code, d.account_name,
          d.cust_order_num, d.cust_order_date, d.sales_center_id,
          d.sales_center_code, d.sales_center_name, d.proj_reg_code,
          d.ship_inv_id, d.ship_inv_code, d.ship_inv_name, d.consignee_inv_id,
          d.consignee_inv_code, d.consignee_inv_name, d.consignee_address_id,
          d.consignee_address, d.consignee_province_code,
          d.consignee_city_code, d.consignee_district_code, d.middle_inv_id,
          d.middle_inv_code, d.middle_inv_name, d.self_pick_flag, d.ship_way,
          d.ship_way_name, d.vehicle_num, d.contract_code, d.ship_info_id,
          d.vendor_id, d.vendor_name, d.inc_dec_code, d.ship_flag,
          d.ship_date, d.direct_ship_flag, d.receive_flag, d.receive_date,
          d.checked_account_flag, d.checked_account_date, d.reversal_flag,
          d.applied_flag, d.applied_date, d.remark, d.audit_by, d.audit_flag,
          d.audit_result, d.audit_opinion, d.audit_date, p.applied_plus_minus_flag*d.list_amount as list_amount,
          p.applied_plus_minus_flag*d.settle_amount as settle_amount, p.applied_plus_minus_flag*d.discount_amount as discount_amount,
          p.applied_plus_minus_flag*d.month_discount_amount as month_discount_amount,
          d.settled_by, d.settle_date, d.print_price_flag,
          d.allow_auto_settle_flag, d.locked_flag, d.printed_times,
          d.inv_trans_flag1, d.inv_trans_flag2, d.inv_trans_time2,
          d.inv_trans_time1, d.fund_ctrl_mode, d.fund_src_type,
          d.fund_src_num, d.cancled_by, d.cancled_date, d.closed_by,
          d.closed_date, d.reversaled_by, d.reversaled_date, d.erp_ou_id,
          d.erp_subinv_id, d.erp_so_id, d.erp_so_code, d.erp_pick_flag,
          d.erp_ship_flag, d.erp_ship_code, d.erp_arinvoice_code,
          d.erp_received_flag, d.erp_credit_memo_code, d.erp_rma_id,
          d.erp_rma_num, d.rebate_year, d.payment_src, d.discount_item,
          d.discount_mode, d.machine_model, d.discount_prove_flag,
          d.received_discount_prove_flag, d.sales_price_id, d.sales_region,
          d.payment_terms, d.created_by, d.creation_date, d.last_updated_by,
          d.last_update_date, d.factory_po_id, d.factory_po_num,
          d.invoice_apply_id, d.invoice_apply_code, d.entity_cust_flag,
          NVL (p.settle_flag, 'N') AS settle_flag, p.settle_auto_flag,
          p.applied_plus_minus_flag, p.reversal_bill_flag, p.return_bill_flag,D.CUSTOMER_REGISTRATION_CODE
           ,d.invoice_type
                  ,d.invoice_customer
                  ,d.identification_number
                  ,d.invoice_address
                  ,d.invoice_tel
                  ,d.invoice_bank
                  ,d.invoice_bank_account
                  ,d.invoice_contact
                  ,d.invoice_contact_tel
                  ,d.invoice_contact_addr
                  ,d.invoice_number
     FROM (SELECT s.invoice_corporation, s.erp_ou_name, s.so_header_id,
                  s.entity_id, s.sales_year_id, s.bill_type_id,
                  s.bill_type_code, s.bill_type_name, s.biz_src_bill_type_id,
                  s.biz_src_bill_type_code, s.biz_src_bill_type_name,
                  s.so_num, s.so_status, s.so_date, s.orig_so_num,
                  s.src_bill_type_id, s.src_bill_id, s.src_bill_num,
                  s.project_type_code, s.project_id, s.project_num,
                  s.brand_id, s.brand_code, s.brand_name, s.sales_main_type,
                  s.sales_main_type_name, s.customer_id, s.customer_code,
                  s.customer_name, s.account_id, s.account_code,
                  s.account_name, s.cust_order_num, s.cust_order_date,
                  s.sales_center_id, s.sales_center_code, s.sales_center_name,
                  s.proj_reg_code, s.ship_inv_id, s.ship_inv_code,
                  s.ship_inv_name, s.consignee_inv_id, s.consignee_inv_code,
                  s.consignee_inv_name, s.consignee_address_id,
                  s.consignee_address, s.consignee_province_code,
                  s.consignee_city_code, s.consignee_district_code,
                  s.middle_inv_id, s.middle_inv_code, s.middle_inv_name,
                  s.self_pick_flag, s.ship_way, s.ship_way_name,
                  s.vehicle_num, s.contract_code, s.ship_info_id, s.vendor_id,
                  s.vendor_name, s.inc_dec_code, s.ship_flag, s.ship_date,
                  s.direct_ship_flag, s.receive_flag, s.receive_date,
                  s.checked_account_flag, s.checked_account_date,
                  s.reversal_flag, s.applied_flag, s.applied_date, s.remark,
                  s.audit_by, s.audit_flag, s.audit_result, s.audit_opinion,
                  s.audit_date, s.list_amount, s.settle_amount,
                  s.discount_amount, s.month_discount_amount, s.settled_by,
                  s.settle_date, s.print_price_flag, s.allow_auto_settle_flag,
                  s.locked_flag, s.printed_times, s.inv_trans_flag1,
                  s.inv_trans_flag2, s.inv_trans_time2, s.inv_trans_time1,
                  s.fund_ctrl_mode, s.fund_src_type, s.fund_src_num,
                  s.cancled_by, s.cancled_date, s.closed_by, s.closed_date,
                  s.reversaled_by, s.reversaled_date, s.erp_ou_id,
                  s.erp_subinv_id, s.erp_so_id, s.erp_so_code,
                  s.erp_pick_flag, s.erp_ship_flag, s.erp_ship_code,
                  s.erp_arinvoice_code, s.erp_received_flag,
                  s.erp_credit_memo_code, s.erp_rma_id, s.erp_rma_num,
                  s.rebate_year, s.payment_src, s.discount_item,
                  s.discount_mode, s.machine_model, s.discount_prove_flag,
                  s.received_discount_prove_flag, s.sales_price_id,
                  s.sales_region, s.payment_terms, s.created_by,
                  s.creation_date, s.last_updated_by, s.last_update_date,
                  s.factory_po_id, s.factory_po_num, s.invoice_apply_id,
                  s.entity_cust_flag, i.invoice_apply_code,s.CUSTOMER_REGISTRATION_CODE
                  ,f.invoice_type
                  ,f.invoice_customer
                  ,f.identification_number
                  ,f.invoice_address
                  ,f.invoice_tel
                  ,f.invoice_bank
                  ,f.invoice_bank_account
                  ,f.invoice_contact
                  ,f.invoice_contact_tel
                  ,f.invoice_contact_addr
                  ,f.invoice_number
             FROM v_so_header_for_ar s LEFT JOIN t_ar_invoice_apply_header i
                  ON s.invoice_apply_id = i.invoice_apply_id
                  left join cims.T_SO_INVOICE_INFO f
                  on s.SO_NUM = f.source_order_number
            WHERE NVL (s.invoice_num_list, '-') = '-') d
          LEFT JOIN
          t_so_type_extend p
          ON d.entity_id = p.entity_id AND d.bill_type_id = p.bill_type_id
    WHERE 1=1
      and NOT EXISTS (SELECT a.so_head_id
                        FROM t_so_trx_header_relation a
                       WHERE d.so_header_id = a.so_head_id)
      AND NOT EXISTS (
             SELECT c.customer_id
               FROM t_ar_conf c
              WHERE NVL (c.is_advance_flag, 'N') = 'Y'
                AND d.entity_id = c.entity_id
                AND d.customer_id = c.customer_id
                AND d.sales_center_id = c.sales_center_id)
          WITH READ ONLY
/

comment on column V_AR_SO_TRX_HEADER.INVOICE_CORPORATION is '开票单位：手工制单时人工录入，自动制单时默认为客户名称。'
/

comment on column V_AR_SO_TRX_HEADER.ERP_OU_NAME is 'ERP的OU名称：取库存组织表的经营单位名称字段。'
/

comment on column V_AR_SO_TRX_HEADER.SO_HEADER_ID is '销售单据头ID'
/

comment on column V_AR_SO_TRX_HEADER.ENTITY_ID is '主体ID'
/

comment on column V_AR_SO_TRX_HEADER.SALES_YEAR_ID is '销售年度ID'
/

comment on column V_AR_SO_TRX_HEADER.BILL_TYPE_ID is '业务单据类型：从库存模块的业务单据类型表获取，包括对应的ERP订单类型（8种）。'
/

comment on column V_AR_SO_TRX_HEADER.BILL_TYPE_CODE is '业务单据类型编码'
/

comment on column V_AR_SO_TRX_HEADER.BILL_TYPE_NAME is '业务单据类型名称'
/

comment on column V_AR_SO_TRX_HEADER.BIZ_SRC_BILL_TYPE_ID is '业务单据源类型ID'
/

comment on column V_AR_SO_TRX_HEADER.BIZ_SRC_BILL_TYPE_CODE is '业务单据源类型编码：业务单据类型对应的销售单据源类型编码'
/

comment on column V_AR_SO_TRX_HEADER.BIZ_SRC_BILL_TYPE_NAME is '业务单据源类型名称：业务单据类型对应的销售单据源类型名称'
/

comment on column V_AR_SO_TRX_HEADER.SO_NUM is '单据号'
/

comment on column V_AR_SO_TRX_HEADER.SO_STATUS is '单据状态：10制单、11审核、12已结算'
/

comment on column V_AR_SO_TRX_HEADER.SO_DATE is '单据日期'
/

comment on column V_AR_SO_TRX_HEADER.ORIG_SO_NUM is '原单据号：主要是红冲单对应的原单据号。'
/

comment on column V_AR_SO_TRX_HEADER.SRC_BILL_TYPE_ID is '来源单据类型(直接来源)：计划订单、提货订单、调拨单、备货单、退货申请单、F单、F红冲单、折让单互转时的源单等。'
/

comment on column V_AR_SO_TRX_HEADER.SRC_BILL_ID is '来源单据ID(直接来源)：其实就是来源单据头ID'
/

comment on column V_AR_SO_TRX_HEADER.SRC_BILL_NUM is '来源单据号(直接来源)'
/

comment on column V_AR_SO_TRX_HEADER.PROJECT_TYPE_CODE is '批文类型编码：LIMIT-限量批文，PG-工程机批文'
/

comment on column V_AR_SO_TRX_HEADER.PROJECT_ID is '批文ID'
/

comment on column V_AR_SO_TRX_HEADER.PROJECT_NUM is '批文单号'
/

comment on column V_AR_SO_TRX_HEADER.BRAND_ID is '品牌ID'
/

comment on column V_AR_SO_TRX_HEADER.BRAND_CODE is '品牌代码'
/

comment on column V_AR_SO_TRX_HEADER.BRAND_NAME is '品牌名称'
/

comment on column V_AR_SO_TRX_HEADER.SALES_MAIN_TYPE is '营销大类编码'
/

comment on column V_AR_SO_TRX_HEADER.SALES_MAIN_TYPE_NAME is '营销大类名称'
/

comment on column V_AR_SO_TRX_HEADER.CUSTOMER_ID is '客户ID'
/

comment on column V_AR_SO_TRX_HEADER.CUSTOMER_CODE is '客户编码'
/

comment on column V_AR_SO_TRX_HEADER.CUSTOMER_NAME is '客户名称'
/

comment on column V_AR_SO_TRX_HEADER.ACCOUNT_ID is '帐户ID'
/

comment on column V_AR_SO_TRX_HEADER.ACCOUNT_CODE is '帐户编码'
/

comment on column V_AR_SO_TRX_HEADER.ACCOUNT_NAME is '帐户名称'
/

comment on column V_AR_SO_TRX_HEADER.CUST_ORDER_NUM is '客户订单号：苏宁、国美等美的外部客户的系统订单号。'
/

comment on column V_AR_SO_TRX_HEADER.CUST_ORDER_DATE is '客户订单日期'
/

comment on column V_AR_SO_TRX_HEADER.SALES_CENTER_ID is '营销中心ID'
/

comment on column V_AR_SO_TRX_HEADER.SALES_CENTER_CODE is '营销中心编码'
/

comment on column V_AR_SO_TRX_HEADER.SALES_CENTER_NAME is '营销中心名称'
/

comment on column V_AR_SO_TRX_HEADER.PROJ_REG_CODE is '项目登录号'
/

comment on column V_AR_SO_TRX_HEADER.SHIP_INV_ID is '发货仓库ID'
/

comment on column V_AR_SO_TRX_HEADER.SHIP_INV_CODE is '发货仓库编码'
/

comment on column V_AR_SO_TRX_HEADER.SHIP_INV_NAME is '发货仓库名称'
/

comment on column V_AR_SO_TRX_HEADER.CONSIGNEE_INV_ID is '收货仓库ID'
/

comment on column V_AR_SO_TRX_HEADER.CONSIGNEE_INV_CODE is '收货仓库编码'
/

comment on column V_AR_SO_TRX_HEADER.CONSIGNEE_INV_NAME is '收货仓库名称'
/

comment on column V_AR_SO_TRX_HEADER.CONSIGNEE_ADDRESS_ID is '收货地址ID'
/

comment on column V_AR_SO_TRX_HEADER.CONSIGNEE_ADDRESS is '收货地址'
/

comment on column V_AR_SO_TRX_HEADER.CONSIGNEE_PROVINCE_CODE is '收货省编码'
/

comment on column V_AR_SO_TRX_HEADER.CONSIGNEE_CITY_CODE is '收货市编码'
/

comment on column V_AR_SO_TRX_HEADER.CONSIGNEE_DISTRICT_CODE is '收货县(区)编码'
/

comment on column V_AR_SO_TRX_HEADER.MIDDLE_INV_ID is '中间仓库ID'
/

comment on column V_AR_SO_TRX_HEADER.MIDDLE_INV_CODE is '中间仓库编码'
/

comment on column V_AR_SO_TRX_HEADER.MIDDLE_INV_NAME is '中间仓库名称，主要在进行（子库）库存转移，包括：待结算仓库、退货未结算仓库等，从库存管理的相关配置表获取。'
/

comment on column V_AR_SO_TRX_HEADER.SELF_PICK_FLAG is '自提标记'
/

comment on column V_AR_SO_TRX_HEADER.SHIP_WAY is '发运方式编码'
/

comment on column V_AR_SO_TRX_HEADER.SHIP_WAY_NAME is '发运方式名称'
/

comment on column V_AR_SO_TRX_HEADER.VEHICLE_NUM is '排车编号'
/

comment on column V_AR_SO_TRX_HEADER.CONTRACT_CODE is '运输合同号'
/

comment on column V_AR_SO_TRX_HEADER.SHIP_INFO_ID is '发货信息ID'
/

comment on column V_AR_SO_TRX_HEADER.VENDOR_ID is '承运商ID'
/

comment on column V_AR_SO_TRX_HEADER.VENDOR_NAME is '承运商名称'
/

comment on column V_AR_SO_TRX_HEADER.INC_DEC_CODE is '费用增减单编号：销售全赔单费用增减单编号，物流模块回写。'
/

comment on column V_AR_SO_TRX_HEADER.SHIP_FLAG is '发货标记'
/

comment on column V_AR_SO_TRX_HEADER.SHIP_DATE is '发货日期'
/

comment on column V_AR_SO_TRX_HEADER.DIRECT_SHIP_FLAG is '直发标记'
/

comment on column V_AR_SO_TRX_HEADER.RECEIVE_FLAG is '签收标记'
/

comment on column V_AR_SO_TRX_HEADER.RECEIVE_DATE is '签收日期'
/

comment on column V_AR_SO_TRX_HEADER.CHECKED_ACCOUNT_FLAG is '对帐标记'
/

comment on column V_AR_SO_TRX_HEADER.CHECKED_ACCOUNT_DATE is '对账日期'
/

comment on column V_AR_SO_TRX_HEADER.REVERSAL_FLAG is '红冲标记：10-未红冲，11-全部红冲，12-部分红冲'
/

comment on column V_AR_SO_TRX_HEADER.APPLIED_FLAG is '核销标记：0-全部核销，1-部分核销，2-未核销'
/

comment on column V_AR_SO_TRX_HEADER.APPLIED_DATE is '核销日期'
/

comment on column V_AR_SO_TRX_HEADER.REMARK is '备注'
/

comment on column V_AR_SO_TRX_HEADER.AUDIT_BY is '审核人'
/

comment on column V_AR_SO_TRX_HEADER.AUDIT_FLAG is '审核标识'
/

comment on column V_AR_SO_TRX_HEADER.AUDIT_RESULT is '审核结果'
/

comment on column V_AR_SO_TRX_HEADER.AUDIT_OPINION is '审核意见'
/

comment on column V_AR_SO_TRX_HEADER.AUDIT_DATE is '审核日期'
/

comment on column V_AR_SO_TRX_HEADER.LIST_AMOUNT is '列表总金额：行产品列表金额汇总'
/

comment on column V_AR_SO_TRX_HEADER.SETTLE_AMOUNT is '结算总金额：行产品结算金额汇总'
/

comment on column V_AR_SO_TRX_HEADER.DISCOUNT_AMOUNT is '扣率折让总金额：行产品扣率折让汇总，销售单、退货单时，为使用的扣率折让金额（核销折让金额）；扣率折让单时为折让单本身的扣率折让金额（F单返利上账金额）；销售折让单、折让证明单为0。'
/

comment on column V_AR_SO_TRX_HEADER.MONTH_DISCOUNT_AMOUNT is '月返总金额：行产品月返金额汇总'
/

comment on column V_AR_SO_TRX_HEADER.SETTLED_BY is '结算人'
/

comment on column V_AR_SO_TRX_HEADER.SETTLE_DATE is '结算日期'
/

comment on column V_AR_SO_TRX_HEADER.PRINT_PRICE_FLAG is '打印单价标识：用于控制打印销售单时，是否打印出产品列表价格。'
/

comment on column V_AR_SO_TRX_HEADER.ALLOW_AUTO_SETTLE_FLAG is '允许自动结算标识：用于控制是否参与自动结算。（预留暂不用）'
/

comment on column V_AR_SO_TRX_HEADER.LOCKED_FLAG is '锁定标识'
/

comment on column V_AR_SO_TRX_HEADER.PRINTED_TIMES is '打印次数'
/

comment on column V_AR_SO_TRX_HEADER.INV_TRANS_FLAG1 is '物料事务处理标识(制单)'
/

comment on column V_AR_SO_TRX_HEADER.INV_TRANS_FLAG2 is '物料事务处理标识(结算)'
/

comment on column V_AR_SO_TRX_HEADER.INV_TRANS_TIME2 is '物料事务处理时间(结算)'
/

comment on column V_AR_SO_TRX_HEADER.INV_TRANS_TIME1 is '物料事务处理时间(制单)'
/

comment on column V_AR_SO_TRX_HEADER.FUND_CTRL_MODE is '款项控制方式：用于控制款型所属类型的。'
/

comment on column V_AR_SO_TRX_HEADER.FUND_SRC_TYPE is '款项来源类型'
/

comment on column V_AR_SO_TRX_HEADER.FUND_SRC_NUM is '款项来源号'
/

comment on column V_AR_SO_TRX_HEADER.CANCLED_BY is '取消人ID'
/

comment on column V_AR_SO_TRX_HEADER.CANCLED_DATE is '取消日期'
/

comment on column V_AR_SO_TRX_HEADER.CLOSED_BY is '关闭人ID'
/

comment on column V_AR_SO_TRX_HEADER.CLOSED_DATE is '关闭日期'
/

comment on column V_AR_SO_TRX_HEADER.REVERSALED_BY is '红冲人ID'
/

comment on column V_AR_SO_TRX_HEADER.REVERSALED_DATE is '红冲日期'
/

comment on column V_AR_SO_TRX_HEADER.ERP_OU_ID is 'ERP的OU ID：取库存组织表的经营单位ID。'
/

comment on column V_AR_SO_TRX_HEADER.ERP_SUBINV_ID is '对应ERP子库组织ID：取发货仓库/收货仓库对应的库存组织ID'
/

comment on column V_AR_SO_TRX_HEADER.ERP_SO_ID is 'ERP SO订单ID：销售订单、销售折让订单、折让证明订单统称为SO订单'
/

comment on column V_AR_SO_TRX_HEADER.ERP_SO_CODE is 'ERP SO订单号'
/

comment on column V_AR_SO_TRX_HEADER.ERP_PICK_FLAG is 'ERP挑库标记'
/

comment on column V_AR_SO_TRX_HEADER.ERP_SHIP_FLAG is 'ERP发运标记'
/

comment on column V_AR_SO_TRX_HEADER.ERP_SHIP_CODE is 'ERP发运号'
/

comment on column V_AR_SO_TRX_HEADER.ERP_ARINVOICE_CODE is 'ERP应收(AR)发票号'
/

comment on column V_AR_SO_TRX_HEADER.ERP_RECEIVED_FLAG is 'ERP接收入库标记'
/

comment on column V_AR_SO_TRX_HEADER.ERP_CREDIT_MEMO_CODE is 'ERP贷项通知号'
/

comment on column V_AR_SO_TRX_HEADER.ERP_RMA_ID is 'ERP退货单ID'
/

comment on column V_AR_SO_TRX_HEADER.ERP_RMA_NUM is 'ERP退货单号'
/

comment on column V_AR_SO_TRX_HEADER.REBATE_YEAR is '返利年度'
/

comment on column V_AR_SO_TRX_HEADER.PAYMENT_SRC is '支付来源'
/

comment on column V_AR_SO_TRX_HEADER.DISCOUNT_ITEM is '折让项目'
/

comment on column V_AR_SO_TRX_HEADER.DISCOUNT_MODE is '折让方式'
/

comment on column V_AR_SO_TRX_HEADER.MACHINE_MODEL is '涉及机型'
/

comment on column V_AR_SO_TRX_HEADER.DISCOUNT_PROVE_FLAG is '是否开折让证明'
/

comment on column V_AR_SO_TRX_HEADER.RECEIVED_DISCOUNT_PROVE_FLAG is '是否收到折让证明'
/

comment on column V_AR_SO_TRX_HEADER.SALES_PRICE_ID is '销售价目'
/

comment on column V_AR_SO_TRX_HEADER.SALES_REGION is '销售区域'
/

comment on column V_AR_SO_TRX_HEADER.PAYMENT_TERMS is '付款条件'
/

comment on column V_AR_SO_TRX_HEADER.CREATED_BY is '创建人ID'
/

comment on column V_AR_SO_TRX_HEADER.CREATION_DATE is '创建日期'
/

comment on column V_AR_SO_TRX_HEADER.LAST_UPDATED_BY is '最后更新人'
/

comment on column V_AR_SO_TRX_HEADER.LAST_UPDATE_DATE is '最后更新日期'
/

comment on column V_AR_SO_TRX_HEADER.FACTORY_PO_ID is '工厂PO订单ID'
/

comment on column V_AR_SO_TRX_HEADER.FACTORY_PO_NUM is '工厂PO订单号'
/

comment on column V_AR_SO_TRX_HEADER.INVOICE_APPLY_ID is '开票申请单ID'
/

comment on column V_AR_SO_TRX_HEADER.INVOICE_APPLY_CODE is '开票申请单号'
/

comment on column V_AR_SO_TRX_HEADER.ENTITY_CUST_FLAG is '是否事业部客户'
/

comment on column V_AR_SO_TRX_HEADER.SETTLE_FLAG is '是否参与结算：N-否、Y-是'
/

comment on column V_AR_SO_TRX_HEADER.SETTLE_AUTO_FLAG is '是否自动结算：N-否、Y是'
/

comment on column V_AR_SO_TRX_HEADER.APPLIED_PLUS_MINUS_FLAG is '核销正负值标识：用于财务核销时标识出单据的数据正负，值为1或-1。'
/

comment on column V_AR_SO_TRX_HEADER.REVERSAL_BILL_FLAG is '红冲单标识：N-否、Y-是。'
/

comment on column V_AR_SO_TRX_HEADER.RETURN_BILL_FLAG is '退货单标识：N-否、Y-是。'
/

comment on column V_AR_SO_TRX_HEADER.CUSTOMER_REGISTRATION_CODE is '客户税票号。'
/

comment on column V_AR_SO_TRX_HEADER.INVOICE_TYPE is '发票类型'
/

comment on column V_AR_SO_TRX_HEADER.INVOICE_CUSTOMER is '客户名称'
/

comment on column V_AR_SO_TRX_HEADER.IDENTIFICATION_NUMBER is '纳税人识别号'
/

comment on column V_AR_SO_TRX_HEADER.INVOICE_ADDRESS is '开票地址'
/

comment on column V_AR_SO_TRX_HEADER.INVOICE_TEL is '开票电话'
/

comment on column V_AR_SO_TRX_HEADER.INVOICE_BANK is '开户行'
/

comment on column V_AR_SO_TRX_HEADER.INVOICE_BANK_ACCOUNT is '银行账号'
/

comment on column V_AR_SO_TRX_HEADER.INVOICE_CONTACT is '收票人'
/

comment on column V_AR_SO_TRX_HEADER.INVOICE_CONTACT_TEL is '收票电话'
/

comment on column V_AR_SO_TRX_HEADER.INVOICE_CONTACT_ADDR is '收票地址'
/

comment on column V_AR_SO_TRX_HEADER.INVOICE_NUMBER is '发票号'
/

