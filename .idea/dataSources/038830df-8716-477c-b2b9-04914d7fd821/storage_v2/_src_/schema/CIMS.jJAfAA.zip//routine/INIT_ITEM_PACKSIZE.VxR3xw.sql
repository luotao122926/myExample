create PROCEDURE      init_item_packsize  (
   P_MAIN_CODE    t_bd_item.item_code%type  --套件编码
   )
 IS

  --套件列表游标
  cursor itemAssemCur is
    select l.item_assembly_id,l.item_id, l.item_code
      from t_bd_item_assemblies l
     where l.entity_id = 10
        --and (select nvl(m.packingsize, '0') packsize
        --      from t_bd_item m
        --     where m.item_id = l.item_id) = '0'
        and l.item_code = nvl(P_MAIN_CODE,l.item_code)  ;
  itemAssem      itemAssemCur%ROWTYPE;
  v_item_id      number;
  v_cnt          number;
  v_quantity     number;
  v_pagesize     number;
  v_bodysize     number;
  v_pagesize_sum number;
  v_bodysize_sum number;

BEGIN

  --1、LOOP循环,遍历所有套件
  OPEN itemAssemCur;
  LOOP
    FETCH itemAssemCur
      INTO itemAssem;
    EXIT WHEN itemAssemCur%NOTFOUND;
    --1.1 初始化套件机身体积，外包装体积
    v_pagesize_sum := 0;
    v_bodysize_sum := 0;
    --1.2 遍历套机的散件
    FOR CUR_ITEM_ID IN (select s.item_id,s.quantity
                          from t_bd_item_assemblies_sub s
                         where s.item_assembly_id =
                               itemAssem.item_assembly_id and s.fittings_flag<>'Y') LOOP
        v_item_id := CUR_ITEM_ID.item_id;
        v_quantity := CUR_ITEM_ID.quantity;
        select count(1) into v_cnt from t_bd_item where item_id = itemAssem.item_id;
        if (v_cnt = 0) then
          continue;
        end if;
        --1.2.1 取散机机身体积、外包装体积
        select To_number(nvl(packingsize,'0'))*v_quantity, To_number(nvl(bodysize,'0'))*v_quantity
          into v_pagesize, v_bodysize
          from t_bd_item
         where item_id = v_item_id;
        --1.2.2 累计
        v_pagesize_sum := v_pagesize_sum + v_pagesize;
        v_bodysize_sum := v_bodysize_sum + v_bodysize;

    END LOOP;
    --1.2.3 更新套件机身体积、外包装体积
    update t_bd_item
          set packingsize = to_char(v_pagesize_sum),
               bodysize    = to_char(v_bodysize_sum)
         where item_id = itemAssem.item_id;
    commit;
  END LOOP;
  CLOSE itemAssemCur;
END;

/

