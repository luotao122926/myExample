create PACKAGE      PKG_INV_WIP_APS_VIEW AS

  -----------------------------------------------------------------------------
  --处理MES视图更新扫码信息主过程
  -----------------------------------------------------------------------------
  PROCEDURE P_INV_WIP_MES_MAIN(P_ORGANIZATION_ID IN INTF_INV_WIP_IN_INFO_MES.ORGANIZATION_ID%TYPE, --组织ID
                               P_MES_BATCH_ID    IN INTF_INV_WIP_IN_INFO_MES.MES_BATCH_ID%TYPE, --扫码批次号
                               P_RESULT          IN OUT NUMBER, --返回错误ID
                               P_ERR_MSG         IN OUT VARCHAR2 --返回错误信息
                               );

  -----------------------------------------------------------------------------
  --插入扫码接口表
  -----------------------------------------------------------------------------
  PROCEDURE P_INSERT_INTF_WIP_MES(P_IMS_IF_MES_WIS_INTERFACE IN MESPRO.IMS_IF_MES_WIS_INTERFACE@MDIMS2SMES%ROWTYPE,
                                  P_RESULT                   IN OUT NUMBER, --返回错误ID
                                  P_ERR_MSG                  IN OUT VARCHAR2 --返回错误信息
                                  );
                                  
  ----------------------------------------------------------------------------------------
  --按组织同步ERP工单信息主过程，原视图拆分的新视图：
  --工单信息：apps.CUX_WIP_IMSMAPPING_V@mdims2mderp
  --订单关系：apps.CUX_ASCP_SOMAPPING_V@mdims2mdaps
  ----------------------------------------------------------------------------------------
  PROCEDURE P_INV_WIP_SYN(P_ORGANIZATION_ID IN INTF_INV_WIP_IN_INFO_ERP.ORGANIZATION_ID%TYPE, --组织ID
                          P_WIP_DELAY_HOURS IN NUMBER, --工单增量时间，单位：小时
                          P_RESULT          IN OUT NUMBER, --返回错误ID
                          P_ERR_MSG         IN OUT VARCHAR2 --返回错误信息
                          );

  ----------------------------------------------------------------------------------------
  --按组织同步APS工单与订单关系信息主过程，原视图拆分的新视图：
  --工单信息：apps.CUX_WIP_IMSMAPPING_V@mdims2mderp
  --订单关系：apps.CUX_ASCP_SOMAPPING_V@mdims2mdaps
  ----------------------------------------------------------------------------------------
  PROCEDURE P_INV_WIP_ORDER_SYN(P_ORGANIZATION_ID       IN INTF_INV_WIP_IN_INFO_ERP.ORGANIZATION_ID%TYPE, --组织ID
                                P_WIP_ORDER_DELAY_HOURS IN NUMBER, --订单关系增量时间，单位：小时
                                P_RESULT                IN OUT NUMBER, --返回错误ID
                                P_ERR_MSG               IN OUT VARCHAR2 --返回错误信息
                                );

  ----------------------------------------------------------------------------------------
  --检漏工单同步，原视图拆分的新视图：
  --工单信息：apps.CUX_WIP_IMSMAPPING_V@mdims2mderp
  --订单关系：apps.CUX_ASCP_SOMAPPING_V@mdims2mdaps
  ----------------------------------------------------------------------------------------
  PROCEDURE P_INV_WIP_CHECK_SYN(P_ORGANIZATION_ID IN INTF_INV_WIP_IN_INFO_ERP.ORGANIZATION_ID%TYPE, --组织ID
                                P_WIP_DELAY_HOURS IN NUMBER, --工单增量时间，单位：小时
                                P_RESULT          IN OUT NUMBER, --返回错误ID
                                P_ERR_MSG         IN OUT VARCHAR2 --返回错误信息
                                );
  ----------------------------------------------------------------------------------------
  --单个工单同步引入
  ----------------------------------------------------------------------------------------
  PROCEDURE P_INV_WIP_CHECK_SYN_SINGLE(P_ORGANIZATION_ID IN INTF_INV_WIP_IN_INFO_ERP.ORGANIZATION_ID%TYPE, --组织ID
                                P_WIP_DELAY_DAYS IN NUMBER, --工单增量时间，单位：天
                                P_USER_ACCOUNT IN VARCHAR2,--用户账号
                                p_WIP_ENTITY_NAME IN VARCHAR2,--工单号
                                P_RESULT          IN OUT NUMBER, --返回错误ID
                                P_ERR_MSG         IN OUT VARCHAR2 --返回错误信息
                                );    
  ----------------------------------------------------------------------------------------
  --按projectID引入工单与订单关系
  ----------------------------------------------------------------------------------------
  PROCEDURE P_INV_WIP_ORDER_SYN_SINGLE(P_ORGANIZATION_ID       IN INTF_INV_WIP_IN_INFO_ERP.ORGANIZATION_ID%TYPE, --组织ID
                                P_PROJECT_ID IN INTF_PLN_WIP_RELATION_APS.PROJECT_ID%TYPE, --PROJECT_ID,ERP视图跟APS视图关联字段
                                P_USER_ACCOUNT    IN VARCHAR2, --用户账号
                                P_RESULT                IN OUT NUMBER, --返回错误ID
                                P_ERR_MSG               IN OUT VARCHAR2 --返回错误信息
                                );                                                         
END PKG_INV_WIP_APS_VIEW;
/

