create Package Body PKG_PROTO Is
  v_Success Constant Varchar2(10) := 'SUCCESS';
  v_Nl      Constant Varchar2(2) := Chr(13) || Chr(10); --换行
  v_Base_Exception Exception; --自定义异常



-----------------------------------------------------------------------------
  --  将实发数量记录到实际发货信息表中（调拨单）             --
  -----------------------------------------------------------------------------
  PROCEDURE P_TO_ACTUAL_SHIP(
     IN_ORDER_HEAD_ID         IN  NUMBER   --样机申请单ID
    ,IS_USER_ACCOUNT             IN  VARCHAR2 --用户ID
    ,OS_MESSAGE               OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  ) IS
    S_STEP             VARCHAR2(40);
    S_BILL_STATUS      VARCHAR2(32);
    S_ORDER_TYPE_CODE  VARCHAR2(32);
    N_CNT              NUMBER;
    N_ACTUAL_SHIP_ID   NUMBER;
    S_ORDER_NUMBER     VARCHAR2(32);
    N_ORDER_TYPE_ID    NUMBER;
    S_IS_BUSINESS_CONTROL      VARCHAR2(32);
    N_CONSIGNEE_INVENTORY_ID   NUMBER;
    N_SHIP_INVENTORY_ID        NUMBER;
    S_INVENTORY_TYPE           T_INV_INVENTORIES.INVENTORY_TYPE%TYPE;               --财务仓类型
    D_ORDER_DATE               DATE;
  BEGIN
    OS_MESSAGE := 'OK';
    SAVEPOINT SP;

    --锁定样机申请单表
    BEGIN
      SELECT
         ORDER_HEAD_STATE
        ,ORDER_TYPE_CODE
        ,ORDER_NUMBER
        ,ORDER_TYPE_ID
        ,INVENTORY_TO_ID
        ,ORDER_DATE
      INTO
        S_BILL_STATUS
        ,S_ORDER_TYPE_CODE
        ,S_ORDER_NUMBER
        ,N_ORDER_TYPE_ID
        ,N_CONSIGNEE_INVENTORY_ID
        ,D_ORDER_DATE
      FROM
        T_PLN_LG_ORDER_HEAD
      WHERE
        ORDER_HEAD_ID = IN_ORDER_HEAD_ID
      FOR UPDATE NOWAIT;

      SELECT
         IS_BUSINESS_CONTROL
      INTO
         S_IS_BUSINESS_CONTROL
      FROM
         T_PLN_ORDER_TYPE
      WHERE
        ORDER_TYPE_ID = N_ORDER_TYPE_ID;

      IF S_IS_BUSINESS_CONTROL <> 'proto_order_005' AND  S_IS_BUSINESS_CONTROL <> 'proto_order_004' THEN
        OS_MESSAGE := '只有场外销售，门店直发才能写实际发货信息。';
      END IF;

    EXCEPTION
      WHEN TIMEOUT_ON_RESOURCE THEN
        OS_MESSAGE := '锁定样机申请单不成功！请稍后再试。';
    END;


    --检查是否已写发货信息表
    IF OS_MESSAGE = 'OK' THEN
      S_STEP := '检查是否已写发货信息';
      SELECT
        COUNT(*)
      INTO
        N_CNT
      FROM
        T_LG_ACTUAL_SHIP
      WHERE
        SOURCE_BILL_ID = IN_ORDER_HEAD_ID
        AND SOURCE_TYPE = 'PROTO_BILL'
        AND ROWNUM = 1;
      IF N_CNT > 0 THEN
        OS_MESSAGE := '当前样机申请单已写发货信息，不能重复调拨！';
      END IF;
    END IF;

    --写发货信息
    IF OS_MESSAGE = 'OK' THEN
      --按发货通知单对应的来源单据号分组，循环生成发货信息
      S_STEP := '写发货信息';
      FOR R_BILL IN
      (
        SELECT DISTINCT
          OL.SALES_MAIN_TYPE
         ,OL.SHIP_INV_ID      --样机仓
         ,INV.INVENTORY_CODE SHIP_INV_CODE
         ,OL.TERMINAL_ENTITY_ID  --门店主体ID
         ,PT.TERMINAL_CODE
         ,PT.TERMINAL_NAME
         ,OL.INV_ID           --实际发货仓 样机暂存仓
         ,CINV.INVENTORY_CODE  INV_CODE
        FROM
           T_PLN_LG_ORDER_LINE OL
          ,T_INV_INVENTORIES INV
          ,V_PRO_TERMINAL PT
          ,T_INV_INVENTORIES CINV
        WHERE
              OL.SHIP_INV_ID = INV.INVENTORY_ID
         AND  OL.INV_ID = CINV.INVENTORY_ID
         AND  OL.TERMINAL_ENTITY_ID = PT.TERMINAL_ENTITY_ID
         AND　INV.INVENTORY_TYPE = '10'   --  发货仓是样机仓情况
         AND  OL.ORDER_HEAD_ID = IN_ORDER_HEAD_ID
      )
      LOOP
      SELECT
         INVENTORY_TYPE
      INTO
         S_INVENTORY_TYPE
      FROM
         T_INV_INVENTORIES
      WHERE
         INVENTORY_ID = R_BILL.SHIP_INV_ID
      AND BEGIN_DATE <= TRUNC(D_ORDER_DATE)
      AND (END_DATE >= TRUNC(D_ORDER_DATE) OR END_DATE IS NULL);

      IF S_INVENTORY_TYPE = '10' AND R_BILL.SHIP_INV_ID <> R_BILL.INV_ID  THEN --发货仓库类型 财务仓类型是样机仓 收货仓为暂存仓
           --获取发货信息头ID
    SELECT
      S_LG_ACTUAL_SHIP.NEXTVAL
    INTO
      N_ACTUAL_SHIP_ID
    FROM
      DUAL;

    --写发货信息头表
    INSERT INTO T_LG_ACTUAL_SHIP
    (
      ACTUAL_SHIP_ID
      ,ENTITY_ID
      ,SALES_MAIN_TYPE
      ,VEHICLE_NUM
      ,SALES_ORDER_TYPE_ID
      ,VENDOR_ID
      ,VENDOR_CODE
      ,VENDOR_NAME
      ,SHIP_INVENTORY_ID
      ,SHIP_TERMINAL_ENTITY_ID
      ,SHIP_TERMINAL_CODE
      ,SHIP_TERMINAL_NAME
      ,CONSIGNEE_INVENTORY_ID
      ,CONSIGNEE_LOCATION_CODE
      ,CONSIGNEE_ADDR
      ,SHIP_WAY
      ,ORIGIN_TYPE
      ,ORIGIN_ORDER_NUM
      ,ORIGIN_ORDER_ID
      ,CUSTOMER_ID
      ,CUSTOMER_CODE
      ,CUSTOMER_NAME
      ,ACCOUNT_CODE
      ,SHIP_DATE
      ,SOURCE_TYPE
      ,SOURCE_BILL_ID
      ,SOURCE_BILL_NUM
      ,CREATED_BY
      ,CREATION_DATE
      ,LAST_UPDATED_BY
      ,LAST_UPDATE_DATE
      ,WHETHER_A3
    )
    SELECT
      N_ACTUAL_SHIP_ID ACTUAL_SHIP_ID
      ,SD.ENTITY_ID
      ,R_BILL.SALES_MAIN_TYPE
      ,SD.ORDER_NUMBER
      ,NULL SALES_ORDER_TYPE_ID
      ,NULL VENDOR_ID
      ,NULL VENDOR_CODE
      ,NULL VENDOR_NAME
      ,R_BILL.SHIP_INV_ID SHIP_INVENTORY_ID
      ,R_BILL.TERMINAL_ENTITY_ID SHIP_TERMINAL_ENTITY_ID --发货门店
      ,R_BILL.TERMINAL_CODE SHIP_TERMINAL_CODE    --发货门店编码
      ,R_BILL.TERMINAL_NAME SHIP_TERMINAL_NAME
      ,R_BILL.INV_ID CONSIGNEE_INVENTORY_ID
      ,R_BILL.INV_CODE CONSIGNEE_LOCATION_CODE
      ,SD.CONSIGNEE_ADDR_NAME CONSIGNEE_ADDR
      ,SD.SHIP_MODE
      ,'05' ORIGIN_TYPE
      ,SD.ORDER_NUMBER  ORIGIN_ORDER_NUM
      ,SD.ORDER_HEAD_ID ORIGIN_ORDER_ID
      ,SD.CUSTOMER_ID
      ,SD.CUSTOMER_CODE
      ,SD.CUSTOMER_NAME
      ,SD.ACCOUNT_CODE
      ,TRUNC(SYSDATE) SHIP_DATE
      ,'PROTO_BILL' SOURCE_TYPE
      ,SD.ORDER_HEAD_ID SOURCE_BILL_ID
      ,SD.ORDER_NUMBER SOURCE_BILL_NUM
      ,IS_USER_ACCOUNT CREATED_BY
      ,SYSDATE CREATION_DATE
      ,IS_USER_ACCOUNT LAST_UPDATED_BY
      ,SYSDATE LAST_UPDATE_DATE
      ,'N'
    FROM
      T_PLN_LG_ORDER_HEAD SD
    WHERE
      SD.ORDER_HEAD_ID = IN_ORDER_HEAD_ID;

    --写发货信息行表
    INSERT INTO T_LG_ACTUAL_SHIP_LINE
    (
      SOURCE_BILL_LINE_ID
      ,ORIGIN_SHIP_PLAN_ID
      ,ACTUAL_SHIP_LINE_ID
      ,SHIP_INFO_ID
      ,SHIP_DOC_LINE_ID
      ,ORIGIN_LINE_ID
      ,ITEM_CODE
      ,ITEM_NAME
      ,ITEM_QTY
      ,CREATED_BY
      ,CREATION_DATE
      ,LAST_UPDATED_BY
      ,LAST_UPDATE_DATE
    )
    SELECT
      OL.ORDER_LINE_ID SOURCE_BILL_LINE_ID
      ,NULL ORIGIN_SHIP_PLAN_ID
      ,S_LG_ACTUAL_SHIP_LINE.NEXTVAL ACTUAL_SHIP_LINE_ID
      ,N_ACTUAL_SHIP_ID SHIP_INFO_ID
      ,0 SHIP_DOC_LINE_ID
      ,OL.ORDER_LINE_ID ORIGIN_LINE_ID
      ,OL.ITEM_CODE
      ,OL.ITEM_NAME ITEM_NAME
      ,OL.Affirm_Quantity ITEM_QTY
      ,IS_USER_ACCOUNT CREATED_BY
      ,SYSDATE CREATION_DATE
      ,IS_USER_ACCOUNT LAST_UPDATED_BY
      ,SYSDATE LAST_UPDATE_DATE
    FROM
         T_PLN_LG_ORDER_LINE OL
    WHERE
     OL.SALES_MAIN_TYPE = R_BILL.SALES_MAIN_TYPE
    AND　 OL.SHIP_INV_ID = R_BILL.SHIP_INV_ID                 --发货仓库 样机仓
    AND   OL.TERMINAL_ENTITY_ID =  R_BILL.TERMINAL_ENTITY_ID  --发货门店
    AND　 OL.INV_ID = R_BILL.INV_ID                           --收货仓库 暂存仓
    AND   OL.ORDER_HEAD_ID = IN_ORDER_HEAD_ID;
      END IF;
      END LOOP;
    END IF;

    IF OS_MESSAGE <> 'OK' THEN
      ROLLBACK TO SAVEPOINT SP;
    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK TO SAVEPOINT SP;
      OS_MESSAGE := '写实际发货信息(样机申请单ID:' || TO_CHAR(IN_ORDER_HEAD_ID) || ')-'|| S_STEP || ':' || SQLERRM;
  END P_TO_ACTUAL_SHIP;



  PROCEDURE P_INV_UPDATE_TERMINAL_ONHAND(
       IN_TRANSACTION_ID     IN       T_INV_TRANSACTION_HISTORY.TRANSACTION_ID%TYPE
      ,OS_MESSAGE            OUT      VARCHAR2
   )
   AS
      N_COUNT                 NUMBER;
      N_SUM_FACT_QTY          NUMBER;
      N_TEMP_QUANTITY         NUMBER;
      D_TRANSACTION_DATE      T_INV_TRANSACTION_HISTORY.TRANSACTION_DATE%TYPE;     --业务日期
      N_QUANTITY              T_INV_TRANSACTION_HISTORY.TRANSACTION_QUANTITY%TYPE; --发生数量
      N_ITEM_ID               T_INV_TRANSACTION_HISTORY.ITEM_ID%TYPE;              --产品
      S_ITEM_CODE             T_INV_TRANSACTION_HISTORY.ITEM_CODE%TYPE;            --产品编码
      S_ITEM_NAME             T_INV_TRANSACTION_HISTORY.ITEM_NAME%TYPE;            --产品名称
      N_INVENTORY_ID          T_INV_TRANSACTION_HISTORY.INVENTORY_ID%TYPE;         --仓库
      S_INVENTORY_CODE        T_INV_TRANSACTION_HISTORY.INVENTORY_CODE%TYPE;       --仓库编码
      S_INVENTORY_NAME        T_INV_TRANSACTION_HISTORY.INVENTORY_NAME%TYPE;       --仓库名称
      S_NEGATIVE_INVENTORY_FLAG  t_Inv_Inventories.NEGATIVE_INVENTORY_FLAG%TYPE; 
      N_TERMINAL_ENTITY_ID    T_INV_TRANSACTION_HISTORY.TERMINAL_ENTITY_ID%TYPE;   --门店主体ID
      S_TERMINAL_CODE         T_INV_TRANSACTION_HISTORY.TERMINAL_CODE%TYPE;        --门店编码
      S_TERMINAL_NAME         T_INV_TRANSACTION_HISTORY.TERMINAL_NAME%TYPE;        --门店名称
      S_LAST_UPDATED_BY       T_INV_TRANSACTION_HISTORY.LAST_UPDATED_BY%TYPE;      --最后创建人
      N_ENTITY_ID             NUMBER;                                              --主体
      S_INVENTORY_TYPE        T_INV_INVENTORIES.INVENTORY_TYPE%TYPE;               --财务仓类型
      
      N_LOCK_QUANTITY         T_INV_TRANSACTION_HISTORY.TRANSACTION_QUANTITY%TYPE; --发生数量
      
      N_TERMINAL_QUANTITY     NUMBER;  --门店数量
      N_ITEM_QUANTITY         NUMBER;  --门店产品数量
      
      N_TERMINAL_MAX     NUMBER;  --门店最大上样数量
      N_ITEM_MAX         NUMBER;  --门店单品最大上样数量

      S_RETURN_CODE           VARCHAR2(1000);
      S_RETURN_MSG            VARCHAR2(1000);
      
      V_PRO_COUNT NUMBER;
      N_ITEM_ONWAY_QUANTITY NUMBER; --单个型号在途量
      N_TERMINAL_ONWAY_QUANTITY NUMBER; --全部型号在途量
      V_PRO_BILL_COUNT NUMBER; -- 样机单据数量
      V_BUSINESS_NUM VARCHAR2(32); --调拨单号
      
  BEGIN
       OS_MESSAGE := 'OK';
       SELECT
            ENTITY_ID
           ,TRANSACTION_DATE
           ,ITEM_ID
           ,ITEM_CODE
           ,ITEM_NAME
           ,INVENTORY_ID
           ,INVENTORY_CODE
           ,INVENTORY_NAME
           ,TERMINAL_ENTITY_ID
           ,TERMINAL_CODE
           ,TERMINAL_NAME
           ,TRANSACTION_QUANTITY
           ,LAST_UPDATED_BY
           ,BUSINESS_NUM 
       INTO
              N_ENTITY_ID
             ,D_TRANSACTION_DATE
             ,N_ITEM_ID
             ,S_ITEM_CODE
             ,S_ITEM_NAME
             ,N_INVENTORY_ID
             ,S_INVENTORY_CODE
             ,S_INVENTORY_NAME
             ,N_TERMINAL_ENTITY_ID
             ,S_TERMINAL_CODE
             ,S_TERMINAL_NAME
             ,N_QUANTITY
             ,S_LAST_UPDATED_BY
             ,V_BUSINESS_NUM
       FROM
             T_INV_TRANSACTION_HISTORY TH
       WHERE
            TH.TRANSACTION_ID = IN_TRANSACTION_ID;

    IF nvl(N_QUANTITY,0) = 0 THEN --库存事物数量为0，直接跳出
       RETURN;
    END IF;
    
    --校验门店信息完整度
    select count(*) into v_pro_count from t_pro_terminal_entity a where a.terminal_entity_id = N_TERMINAL_ENTITY_ID
        and nvl(a.terminal_id,0) > 0 
        and nvl(a.sales_center_id,0) > 0 
        and nvl(a.customer_id,0) > 0
        and nvl(a.account_id,0) > 0;
    if v_pro_count = 0 then
      OS_MESSAGE    :=
                       '门店、中心、客户、帐号ID数据不完整，主体'
                       || N_ENTITY_ID
                       || ');门店编码：'
                       || S_TERMINAL_CODE;
       RETURN;
    end if;

    SELECT
       INVENTORY_TYPE
       ,INVENTORY_CODE
       ,INVENTORY_NAME
       ,NEGATIVE_INVENTORY_FLAG 
    INTO
       S_INVENTORY_TYPE
       ,S_INVENTORY_CODE
       ,S_INVENTORY_NAME
       ,S_NEGATIVE_INVENTORY_FLAG 
    FROM
       T_INV_INVENTORIES
    WHERE
       INVENTORY_ID = N_INVENTORY_ID
    AND BEGIN_DATE <= D_TRANSACTION_DATE
    AND (END_DATE >= D_TRANSACTION_DATE OR END_DATE IS NULL);

    IF S_INVENTORY_TYPE <> '10' THEN --财务仓类型不是样机仓
       RETURN;
    END IF;

    IF  N_TERMINAL_ENTITY_ID IS NULL THEN
       OS_MESSAGE    :=
                       '更新门店库存现有量异常：经营主体(ID:'
                       || N_ENTITY_ID
                       || ');仓库(ID:'
                       || N_INVENTORY_ID
                       || ',仓库编码:'
                       || S_INVENTORY_CODE||')的是样机财务仓，必须录入门店信息！';
       RETURN;
    END IF;


    D_TRANSACTION_DATE := TRUNC(D_TRANSACTION_DATE);
    IF nvl(N_QUANTITY,0) > 0 THEN    --如果入库
               
            SELECT                   --验证最大上样量
               SUM(NVL(FACT_QTY,0))
            INTO
               N_ITEM_QUANTITY
            FROM
               T_PRO_ONHAND PO
            WHERE
               PO.ENTITY_ID = N_ENTITY_ID
            AND PO.TERMINAL_ENTITY_ID = N_TERMINAL_ENTITY_ID
            AND PO.ITEM_ID = N_ITEM_ID ; 
            N_ITEM_QUANTITY := NVL(N_ITEM_QUANTITY,0);  
            
            SELECT
               SUM(NVL(FACT_QTY,0))
            INTO
               N_TERMINAL_QUANTITY
            FROM
               T_PRO_ONHAND PO
            WHERE
               PO.ENTITY_ID = N_ENTITY_ID
            AND PO.TERMINAL_ENTITY_ID = N_TERMINAL_ENTITY_ID;
            N_TERMINAL_QUANTITY := NVL(N_TERMINAL_QUANTITY,0); 
            
           SELECT 
              MAXIMUM_SAMPLE
             ,SINGLE_MAXIMUM_SAMPLE
           INTO 
              N_TERMINAL_MAX
             ,N_ITEM_MAX
           FROM 
             T_PRO_TERMINAL_ENTITY TE
           WHERE   
                TE.TERMINAL_ENTITY_ID = N_TERMINAL_ENTITY_ID
            AND TE.ENTITY_ID = N_ENTITY_ID;
            N_TERMINAL_MAX := NVL(N_TERMINAL_MAX,0);
            N_ITEM_MAX := NVL(N_ITEM_MAX,0);
           
            
           IF N_ITEM_QUANTITY + N_QUANTITY > N_ITEM_MAX THEN
              OS_MESSAGE := '门店' || S_TERMINAL_CODE ||'产品'||S_ITEM_CODE||'单品上样量超上限'||N_ITEM_MAX||'。'
              || '当前产品上样量：'||N_ITEM_QUANTITY||'，本次上样量：'||N_QUANTITY;
              RETURN;
           END IF;
           
           IF N_TERMINAL_QUANTITY + N_QUANTITY > N_TERMINAL_MAX THEN
              OS_MESSAGE := '门店' || S_TERMINAL_CODE || '最大上样量超上限'||N_TERMINAL_MAX||'。'
              || '当前门店全部上样量：'||N_TERMINAL_QUANTITY||'，本次上样量：'||N_QUANTITY;
              RETURN;
           END IF;                                  
           
           --add by tangjz2 2018-10-16 如果以上校验通过，增加在途量的校验
           --获取当前门店、当前型号的在途量
          -- SELECT NVL(SUM(A.QUANTITY),0) INTO N_ITEM_ONWAY_QUANTITY FROM  V_PRO_PROTOTYPE_TRANSIT A 
           --                                                         WHERE A.TERMINAL_ENTITY_ID = N_TERMINAL_ENTITY_ID 
            --                                                        AND A.ITEM_ID = N_ITEM_ID 
            --                                                        AND A.ENTITY_ID = N_ENTITY_ID;
                                                                    
           SELECT
             -- OH.ENTITY_ID
             -- ,OH.INVENTORY_TO_ID INVENTORY_ID
             -- ,OH.TERMINAL_ENTITY_ID
             -- ,OL.ITEM_ID
             -- ,
              nvl(SUM(OL.QUANTITY),0) INTO N_ITEM_ONWAY_QUANTITY
            FROM
             T_PLN_LG_ORDER_HEAD OH
             ,T_PLN_ORDER_TYPE OT
             ,T_PLN_LG_ORDER_LINE OL
             ,T_INV_INVENTORIES INV
            WHERE OH.ORDER_TYPE_ID = OT.ORDER_TYPE_ID
            AND   OH.ORDER_HEAD_ID = OL.ORDER_HEAD_ID
            AND   OH.INVENTORY_TO_ID = INV.INVENTORY_ID
            AND   INV.INVENTORY_TYPE = '10'   --样机仓
            AND   OT.SOURCE_ORDER_TYPE_ID=10  --样机申请订单
            AND   ORDER_HEAD_STATE in('19','20','23')       --制单 已审核 已评审
            AND   OH.ORDER_DATE >= trunc(sysdate - 15)  and OH.ORDER_DATE <  trunc(sysdate + 1)
            AND   OL.Creation_Date >= trunc(sysdate - 15)  and OL.Creation_Date <  trunc(sysdate + 1)
            AND  OH.TERMINAL_ENTITY_ID = N_TERMINAL_ENTITY_ID
            AND OL.ITEM_ID = N_ITEM_ID
            AND OH.ENTITY_ID = N_ENTITY_ID
            AND   NOT EXISTS
            ( SELECT
                 (1)
              FROM
                 T_INV_TRSF_ORDER TR
                 ,T_INV_TRSF_ORDER_LINE EL
              WHERE
               TR.TRSF_ORDER_ID = EL.TRSF_ORDER_ID
               AND TR.ORIG_ORDER_TYPE='03'   --调拨申请
               AND TR.Orig_Order_Id = OH.Order_Head_Id
               AND TR.ORIG_ORDER_NUM = OH.ORDER_NUMBER
               AND OL.ORDER_LINE_ID = EL.ORDER_LINE_ID_ORIG
               AND TR.RCV_FLAG = 1
             )AND  NOT EXISTS
            (SELECT
                 (1)
              FROM
                  T_LG_SHIP_DOC TD
                 ,T_LG_SHIP_DOC_LINE DL
              WHERE
                 TD.SHIP_DOC_ID = DL.SHIP_DOC_ID
                 AND TD.DOC_STATUS = '00'
                 AND DL.Origin_Type in ('02','03')
                 AND DL.ORIGIN_ORDER_ID = OH.ORDER_HEAD_ID
                 AND DL.ORIGIN_LINE_ID = OL.ORDER_LINE_ID
                 AND NVL(DL.ITEM_QTY,0)-NVL(DL.CANCEL_QTY,0) <= 0
             )AND  NOT EXISTS
            (SELECT
                 1
              FROM
                  cims.T_LG_SHIP_PLAN sp
              WHERE
                 1=1
                 AND sp.origin_order_num = OH.Order_Number
                 AND sp.entity_id = OH.Entity_Id
                 AND sp.STATUS = '03'
                 AND sp.ORIGIN_ORDER_ID = OH.ORDER_HEAD_ID
                 AND sp.ORIGIN_LINE_ID = OL.ORDER_LINE_ID
             )
             /*GROUP BY
               OH.ENTITY_ID
              ,OH.INVENTORY_TO_ID
              ,OH.TERMINAL_ENTITY_ID
              ,OL.ITEM_ID*/
              ;                                                     
            
           --获取当前门店、所有型号的在途量
          -- SELECT NVL(SUM(A.QUANTITY),0) INTO N_TERMINAL_ONWAY_QUANTITY FROM  V_PRO_PROTOTYPE_TRANSIT A 
           --                                                             WHERE A.TERMINAL_ENTITY_ID = N_TERMINAL_ENTITY_ID 
            --                                                            AND A.ENTITY_ID = N_ENTITY_ID;
                                                                        
                                                                        
           SELECT
             -- OH.ENTITY_ID
             -- ,OH.INVENTORY_TO_ID INVENTORY_ID
             -- ,OH.TERMINAL_ENTITY_ID
             -- ,OL.ITEM_ID
             -- ,
              nvl(SUM(OL.QUANTITY),0) INTO N_TERMINAL_ONWAY_QUANTITY
            FROM
             T_PLN_LG_ORDER_HEAD OH
             ,T_PLN_ORDER_TYPE OT
             ,T_PLN_LG_ORDER_LINE OL
             ,T_INV_INVENTORIES INV
            WHERE OH.ORDER_TYPE_ID = OT.ORDER_TYPE_ID
            AND   OH.ORDER_HEAD_ID = OL.ORDER_HEAD_ID
            AND   OH.INVENTORY_TO_ID = INV.INVENTORY_ID
            AND   INV.INVENTORY_TYPE = '10'   --样机仓
            AND   OT.SOURCE_ORDER_TYPE_ID=10  --样机申请订单
            AND   ORDER_HEAD_STATE in('19','20','23')       --制单 已审核 已评审
            AND   OH.ORDER_DATE >= trunc(sysdate - 15)  and OH.ORDER_DATE <  trunc(sysdate + 1)
            AND   OL.Creation_Date >= trunc(sysdate - 15)  and OL.Creation_Date <  trunc(sysdate + 1)
            AND  OH.TERMINAL_ENTITY_ID = N_TERMINAL_ENTITY_ID
            --AND OL.ITEM_ID = N_ITEM_ID
            AND OH.ENTITY_ID = N_ENTITY_ID
            AND   NOT EXISTS
            ( SELECT
                 (1)
              FROM
                 T_INV_TRSF_ORDER TR
                 ,T_INV_TRSF_ORDER_LINE EL
              WHERE
               TR.TRSF_ORDER_ID = EL.TRSF_ORDER_ID
               AND TR.ORIG_ORDER_TYPE='03'   --调拨申请
               AND TR.Orig_Order_Id = OH.Order_Head_Id
               AND TR.ORIG_ORDER_NUM = OH.ORDER_NUMBER
               AND OL.ORDER_LINE_ID = EL.ORDER_LINE_ID_ORIG
               AND TR.RCV_FLAG = 1
             )AND  NOT EXISTS
            (SELECT
                 (1)
              FROM
                  T_LG_SHIP_DOC TD
                 ,T_LG_SHIP_DOC_LINE DL
              WHERE
                 TD.SHIP_DOC_ID = DL.SHIP_DOC_ID
                 AND TD.DOC_STATUS = '00'
                 AND DL.Origin_Type in ('02','03')
                 AND DL.ORIGIN_ORDER_ID = OH.ORDER_HEAD_ID
                 AND DL.ORIGIN_LINE_ID = OL.ORDER_LINE_ID
                 AND NVL(DL.ITEM_QTY,0)-NVL(DL.CANCEL_QTY,0) <= 0
             )AND  NOT EXISTS
            (SELECT
                 1
              FROM
                  cims.T_LG_SHIP_PLAN sp
              WHERE
                 1=1
                 AND sp.origin_order_num = OH.Order_Number
                 AND sp.entity_id = OH.Entity_Id
                 AND sp.STATUS = '03'
                 AND sp.ORIGIN_ORDER_ID = OH.ORDER_HEAD_ID
                 AND sp.ORIGIN_LINE_ID = OL.ORDER_LINE_ID
             )
             /*GROUP BY
               OH.ENTITY_ID
              ,OH.INVENTORY_TO_ID
              ,OH.TERMINAL_ENTITY_ID
              ,OL.ITEM_ID*/
              ;
           
           --如果来源数据是样机单据，而不是直接手工录入的盘点、状态调整调拨单，在途量需要减去当前数量
           SELECT COUNT(*) INTO V_PRO_BILL_COUNT FROM T_PLN_LG_ORDER_HEAD H,T_INV_TRSF_ORDER O WHERE O.ORIG_ORDER_NUM = H.ORDER_NUMBER
                                                                  AND O.TRSF_ORDER_NUM = V_BUSINESS_NUM;
           IF V_PRO_BILL_COUNT > 0 THEN
             N_ITEM_ONWAY_QUANTITY := N_ITEM_ONWAY_QUANTITY - N_QUANTITY;
             N_TERMINAL_ONWAY_QUANTITY := N_TERMINAL_ONWAY_QUANTITY - N_QUANTITY;
           END IF;
           
           IF N_ITEM_QUANTITY + N_ITEM_ONWAY_QUANTITY + N_QUANTITY > N_ITEM_MAX THEN
              OS_MESSAGE := '门店' || S_TERMINAL_CODE ||'产品'||S_ITEM_CODE||'单品上样量超上限'||N_ITEM_MAX||'。'
              || '当前产品上样量：'||N_ITEM_QUANTITY||'，当前产品在途量：'||N_ITEM_ONWAY_QUANTITY||'，本次上样量：'||N_QUANTITY;
              RETURN;
           END IF;
           
           IF N_TERMINAL_QUANTITY + N_TERMINAL_ONWAY_QUANTITY + N_QUANTITY > N_TERMINAL_MAX THEN
              OS_MESSAGE := '门店' || S_TERMINAL_CODE || '最大上样量超上限'||N_TERMINAL_MAX||'。'
              || '当前门店全部上样量：'||N_TERMINAL_QUANTITY||'，当前门店全部在途量：'||N_TERMINAL_ONWAY_QUANTITY||'，本次上样量：'||N_QUANTITY;
              RETURN;
           END IF;   

      SELECT
          COUNT (*)
      INTO
          N_COUNT
      FROM
          T_PRO_ONHAND PO
      WHERE
          PO.ENTITY_ID = N_ENTITY_ID
      AND   PO.INVENTORY_ID = N_INVENTORY_ID
      AND   PO.TERMINAL_ENTITY_ID = N_TERMINAL_ENTITY_ID
      AND   PO.ITEM_ID = N_ITEM_ID
      AND   PO.STORAGE_DATE = D_TRANSACTION_DATE;
      IF N_COUNT = 0 THEN    --没有插入现有量数据
                INSERT INTO T_PRO_ONHAND
                (
                  VERSION
                  ,ONHAND_ID
                  ,ENTITY_ID
                  ,INVENTORY_ID
                  ,INVENTORY_CODE
                  ,INVENTORY_NAME
                  ,SALES_CENTER_ID
                  ,SALES_CENTER_CODE
                  ,SALES_CENTER_NAME
                  ,CUSTOMER_ID
                  ,CUSTOMER_CODE
                  ,CUSTOMER_NAME
                  ,TERMINAL_ENTITY_ID
                  ,TERMINAL_CODE
                  ,TERMINAL_NAME
                  ,CREATED_BY
                  ,CREATION_DATE
                  ,LAST_UPDATED_BY
                  ,LAST_UPDATE_DATE
                  ,ACCOUNT_ID
                  ,ACCOUNT_CODE
                  ,ITEM_ID
                  ,ITEM_CODE
                  ,ITEM_NAME
                  ,STORAGE_DATE
                  ,FACT_QTY
                  ,LAST_TRANSACTION_ID
                )
               SELECT
                   0
                   ,S_PRO_ONHAND.NEXTVAL ONHAND_ID
                   ,PT.ENTITY_ID
                   ,N_INVENTORY_ID
                   ,S_INVENTORY_CODE
                   ,S_INVENTORY_NAME
                   ,PT.SALES_CENTER_ID
                   ,PT.SALES_CENTER_CODE
                   ,PT.SALES_CENTER_NAME
                   ,PT.CUSTOMER_ID
                   ,PT.CUSTOMER_CODE
                   ,PT.CUSTOMER_NAME
                   ,PT.TERMINAL_ENTITY_ID
                   ,PT.TERMINAL_CODE
                   ,PT.TERMINAL_NAME
                   ,S_LAST_UPDATED_BY
                   ,SYSDATE
                   ,S_LAST_UPDATED_BY
                   ,SYSDATE
                   ,PT.ACCOUNT_ID
                   ,PT.ACCOUNT_CODE
                   ,N_ITEM_ID
                   ,S_ITEM_CODE
                   ,S_ITEM_NAME
                   ,D_TRANSACTION_DATE
                   ,N_QUANTITY
                   ,IN_TRANSACTION_ID
               FROM
                    V_PRO_TERMINAL PT
               WHERE
                      PT.ENTITY_ID = N_ENTITY_ID
               AND    PT.TERMINAL_ENTITY_ID = N_TERMINAL_ENTITY_ID;
      ELSE
               --锁定样机现有量表，获取当前数量
        SELECT
           FACT_QTY
        INTO
           N_LOCK_QUANTITY
        FROM
           T_PRO_ONHAND PO
        WHERE
           PO.ENTITY_ID = N_ENTITY_ID
        AND   PO.INVENTORY_ID = N_INVENTORY_ID
        AND   PO.TERMINAL_ENTITY_ID = N_TERMINAL_ENTITY_ID
        AND   PO.ITEM_ID = N_ITEM_ID
        AND   PO.STORAGE_DATE = D_TRANSACTION_DATE
        FOR UPDATE NOWAIT;

        UPDATE
            T_PRO_ONHAND PO
        SET
            FACT_QTY = FACT_QTY + N_QUANTITY,
            LAST_TRANSACTION_ID = IN_TRANSACTION_ID,
            LAST_UPDATED_BY = S_LAST_UPDATED_BY,
            LAST_UPDATE_DATE = SYSDATE
        WHERE
              PO.ENTITY_ID = N_ENTITY_ID
        AND   PO.INVENTORY_ID = N_INVENTORY_ID
        AND   PO.TERMINAL_ENTITY_ID = N_TERMINAL_ENTITY_ID
        AND   PO.ITEM_ID = N_ITEM_ID
        AND   PO.STORAGE_DATE = D_TRANSACTION_DATE;

      END IF;

   ELSE
        SELECT
          SUM(NVL(FACT_QTY,0))
        INTO
           N_SUM_FACT_QTY
        FROM
           T_PRO_ONHAND PO
        WHERE
           PO.ENTITY_ID = N_ENTITY_ID
        AND   PO.INVENTORY_ID = N_INVENTORY_ID
        AND   PO.TERMINAL_ENTITY_ID = N_TERMINAL_ENTITY_ID
        AND   PO.ITEM_ID = N_ITEM_ID;
        
        

        IF nvl(S_NEGATIVE_INVENTORY_FLAG,'N') = 'N' and (nvl(N_SUM_FACT_QTY,0)+nvl(N_QUANTITY,0)) < 0   THEN    --门店现有量
                   OS_MESSAGE    :=
                          '更新门店库存现有量异常：经营主体(ID:'
                       || N_ENTITY_ID
                       || ');仓库(ID:'
                       || N_INVENTORY_ID
                       || ',仓库编码:'
                       || S_INVENTORY_CODE
                       || ');门店(ID:'
                       || N_TERMINAL_ENTITY_ID
                       || ',门店编码:'
                       || S_TERMINAL_CODE
                       || ');产品(ID:'
                       || N_ITEM_ID
                       || ',产品编码:'
                       || S_ITEM_CODE
                       || ')的库存不足！';
             RETURN;
         ELSE
                N_TEMP_QUANTITY := N_QUANTITY;
                FOR VR_ONHAND_ROW IN (
                    SELECT
                        PO.ONHAND_ID    ONHAND_ID
                       ,PO.STORAGE_DATE STORAGE_DATE
                       ,PO.FACT_QTY     FACT_QTY
                    FROM
                        T_PRO_ONHAND PO
                    WHERE
                        PO.ENTITY_ID = N_ENTITY_ID
                    AND   PO.INVENTORY_ID = N_INVENTORY_ID
                    AND   PO.TERMINAL_ENTITY_ID = N_TERMINAL_ENTITY_ID
                    AND   PO.ITEM_ID = N_ITEM_ID
                    ORDER BY
                         PO.STORAGE_DATE ASC
                        ,PO.ONHAND_ID ASC
                     FOR UPDATE NOWAIT
                  )
                      LOOP
                          BEGIN
                               IF  nvl(N_TEMP_QUANTITY,0) = 0 THEN
                                 EXIT;
                               END IF;
                               IF  ( NVL(VR_ONHAND_ROW.FACT_QTY,0) + nvl(N_TEMP_QUANTITY,0) ) <= 0 THEN  --出库数量大于等于当前日期的现有量
                                  DELETE
                                  FROM
                                     T_PRO_ONHAND PO
                                  WHERE
                                     PO.ONHAND_ID = VR_ONHAND_ROW.ONHAND_ID;
                                  N_TEMP_QUANTITY := nvl(N_TEMP_QUANTITY,0) + NVL(VR_ONHAND_ROW.FACT_QTY,0);
                               ELSE
                                  UPDATE
                                     T_PRO_ONHAND PO
                                  SET
                                     FACT_QTY = FACT_QTY + nvl(N_TEMP_QUANTITY,0),
                                     LAST_TRANSACTION_ID = IN_TRANSACTION_ID,
                                     LAST_UPDATED_BY = S_LAST_UPDATED_BY,
                                     LAST_UPDATE_DATE = SYSDATE
                                  WHERE
                                     PO.ONHAND_ID = VR_ONHAND_ROW.ONHAND_ID;
                                     N_TEMP_QUANTITY := 0;
                                 EXIT;
                             END IF;
                    END;
                 END LOOP;
        END IF;
   END IF;

  END P_INV_UPDATE_TERMINAL_ONHAND;


   -----------------------------------------------------------------------------
   --  校验样机订单是否有库存           --
   -----------------------------------------------------------------------------
   PROCEDURE P_TERMINAL_ONHAND_CHECK(
       IN_ORDER_HEAD_ID     IN       T_PLN_LG_ORDER_HEAD.ORDER_HEAD_ID%TYPE
      ,OS_MESSAGE           OUT      VARCHAR2
   )
   AS
      N_FACT_QTY                NUMBER;
      N_OCCUPY_QTY              NUMBER;
      S_ITEM_CODE              T_BD_ITEM.ITEM_CODE%TYPE;
  BEGIN
      OS_MESSAGE := 'OK';

      FOR V_ORDER_LINE_ROW IN (
         SELECT
            OL.SHIP_INV_ID      --样机仓
           ,INV.INVENTORY_CODE SHIP_INV_CODE
           ,OL.TERMINAL_ENTITY_ID  --门店主体ID
           ,PT.TERMINAL_CODE
           ,OL.ENTITY_ID
           ,OL.ITEM_ID
          ,SUM(nvl(ol.affirm_quantity,0)) QUANTITY
         FROM
           T_PLN_LG_ORDER_LINE OL
          ,T_INV_INVENTORIES INV
          ,V_PRO_TERMINAL PT
         WHERE
           OL.SHIP_INV_ID = INV.INVENTORY_ID
         AND  OL.TERMINAL_ENTITY_ID = PT.TERMINAL_ENTITY_ID
         AND　INV.INVENTORY_TYPE = '10'   --  发货仓是样机仓情况
         AND  OL.ORDER_HEAD_ID = IN_ORDER_HEAD_ID
         GROUP BY
            OL.ENTITY_ID
           ,OL.SHIP_INV_ID
           ,OL.TERMINAL_ENTITY_ID
           ,OL.ITEM_ID
           ,INV.INVENTORY_CODE
           ,PT.TERMINAL_CODE
       )
       LOOP
          BEGIN
            SELECT
              NVL(SUM(NVL(PO.FACT_QTY,0)), 0)
            INTO
               N_FACT_QTY
            FROM
               T_PRO_ONHAND PO
            WHERE
               PO.ENTITY_ID = V_ORDER_LINE_ROW.ENTITY_ID
            AND   PO.INVENTORY_ID = V_ORDER_LINE_ROW.SHIP_INV_ID
            AND   PO.TERMINAL_ENTITY_ID = V_ORDER_LINE_ROW.TERMINAL_ENTITY_ID
            AND   PO.ITEM_ID =  V_ORDER_LINE_ROW.ITEM_ID;     --找库存现有量

            SELECT
              NVL(SUM(NVL(PC.STOCK_NUM,0)), 0)
            INTO
               N_OCCUPY_QTY
            FROM
               V_PRO_TERMINAL_OCCUPY PC
            WHERE
               PC.ENTITY_ID = V_ORDER_LINE_ROW.ENTITY_ID
            AND   PC.INVENTORY_ID = V_ORDER_LINE_ROW.SHIP_INV_ID
            AND   PC.TERMINAL_ENTITY_ID = V_ORDER_LINE_ROW.TERMINAL_ENTITY_ID
            AND   PC.ITEM_ID =  V_ORDER_LINE_ROW.ITEM_ID;     --找锁定库存

            IF(nvl(V_ORDER_LINE_ROW.QUANTITY,0) + nvl(N_OCCUPY_QTY,0)) > nvl(N_FACT_QTY,0)  THEN
            SELECT
              I.ITEM_CODE
            INTO
              S_ITEM_CODE
            FROM
              T_BD_ITEM I
            WHERE
            I.ITEM_ID = V_ORDER_LINE_ROW.ITEM_ID;
            IF OS_MESSAGE = 'OK' THEN
                 OS_MESSAGE := '';
            END IF;

            OS_MESSAGE  :=
                OS_MESSAGE||'门店库存可用量异常：经营主体(ID:'
                 || V_ORDER_LINE_ROW.ENTITY_ID
                 || ');仓库(ID:'
                 || V_ORDER_LINE_ROW.SHIP_INV_ID
                 || ',仓库编码:'
                 || V_ORDER_LINE_ROW.SHIP_INV_CODE
                 || ');门店(ID:'
                 || V_ORDER_LINE_ROW.TERMINAL_ENTITY_ID
                 || ',门店编码:'
                 || V_ORDER_LINE_ROW.TERMINAL_CODE
                 || ');产品(ID:'
                 || V_ORDER_LINE_ROW.ITEM_ID
                 || ',产品编码:'
                 || S_ITEM_CODE
                 || ')的库存可用量不足!;';
                END IF;
          END;
       END LOOP;
   END P_TERMINAL_ONHAND_CHECK;


    -----------------------------------------------------------------------------
    --  校验样机订单是否超过门店最大上样量           --
    -----------------------------------------------------------------------------
   PROCEDURE P_TERMINAL_MAX_CHECK(
       IN_ORDER_HEAD_ID     IN       T_PLN_LG_ORDER_HEAD.ORDER_HEAD_ID%TYPE
      ,OS_MESSAGE           OUT      VARCHAR2
   )
   AS
        N_FACT_QTY              NUMBER;
        S_ITEM_CODE             T_BD_ITEM.ITEM_CODE%TYPE;
        
        N_TERMINAL_QUANTITY     NUMBER;  --门店数量
        N_ITEM_QUANTITY         NUMBER;  --门店产品数量
        
        N_TERMINAL_LOCK     NUMBER;  --门店锁定数量
        N_ITEM_LOCK         NUMBER;  --门店产品锁定数量
      
        N_TERMINAL_MAX     NUMBER;  --门店最大上样数量
        N_ITEM_MAX         NUMBER;  --门店单品最大上样数量
        
        
        S_RETURN_CODE           VARCHAR2(1000);
        S_RETURN_MSG            VARCHAR2(1000);
   BEGIN
        OS_MESSAGE := 'OK';
        SELECT
          nvl(SUM(NVL(OL.Affirm_Quantity,0)),0)
        INTO
          N_FACT_QTY
        FROM
          T_PLN_LG_ORDER_LINE OL
        WHERE
          OL.ORDER_HEAD_ID = IN_ORDER_HEAD_ID;
       
          
        FOR V_ORDER_LINE_ROW IN (
           SELECT
              OH.TERMINAL_ENTITY_ID  --门店主体ID
             ,PT.TERMINAL_CODE
             ,OL.ENTITY_ID
             ,OL.ITEM_ID
             ,OL.ITEM_CODE
            ,SUM(nvl(ol.affirm_quantity,0)) QUANTITY
           FROM
             T_PLN_LG_ORDER_LINE OL
            ,T_PLN_LG_ORDER_HEAD OH
            ,T_INV_INVENTORIES INV
            ,V_PRO_TERMINAL PT
           WHERE
            OH.Inventory_To_Id = INV.INVENTORY_ID
           AND  OH.ORDER_HEAD_ID = OL.ORDER_HEAD_ID
           AND  OH.TERMINAL_ENTITY_ID = PT.TERMINAL_ENTITY_ID
           AND　INV.INVENTORY_TYPE = '10'   --  收货仓是样机仓情况
           AND  OL.ORDER_HEAD_ID = IN_ORDER_HEAD_ID
           GROUP BY
              OL.ENTITY_ID
             ,OH.TERMINAL_ENTITY_ID
             ,OL.ITEM_ID
             ,PT.TERMINAL_CODE
             ,OL.ITEM_CODE
         )
         LOOP
            BEGIN
                  SELECT                   --验证最大上样量
                     SUM(NVL(FACT_QTY,0))
                  INTO
                     N_ITEM_QUANTITY
                  FROM
                     T_PRO_ONHAND PO
                  WHERE
                     PO.ENTITY_ID = V_ORDER_LINE_ROW.ENTITY_ID
                  AND PO.TERMINAL_ENTITY_ID = V_ORDER_LINE_ROW.TERMINAL_ENTITY_ID
                  AND PO.ITEM_ID =  V_ORDER_LINE_ROW.ITEM_ID ; 
                  N_ITEM_QUANTITY := NVL(N_ITEM_QUANTITY,0);  
                  
                  SELECT
                     SUM(NVL(FACT_QTY,0))
                  INTO
                     N_TERMINAL_QUANTITY
                  FROM
                     T_PRO_ONHAND PO
                  WHERE
                     PO.ENTITY_ID = V_ORDER_LINE_ROW.ENTITY_ID
                  AND PO.TERMINAL_ENTITY_ID = V_ORDER_LINE_ROW.TERMINAL_ENTITY_ID;
                  N_TERMINAL_QUANTITY := NVL(N_TERMINAL_QUANTITY,0); 
                  
                 SELECT 
                    MAXIMUM_SAMPLE
                   ,SINGLE_MAXIMUM_SAMPLE
                 INTO 
                    N_TERMINAL_MAX
                   ,N_ITEM_MAX
                 FROM 
                   T_PRO_TERMINAL_ENTITY TE
                 WHERE   
                      TE.TERMINAL_ENTITY_ID = V_ORDER_LINE_ROW.TERMINAL_ENTITY_ID
                  AND TE.ENTITY_ID = V_ORDER_LINE_ROW.ENTITY_ID;
                  N_TERMINAL_MAX := NVL(N_TERMINAL_MAX,0);
                  N_ITEM_MAX := NVL(N_ITEM_MAX,0);
                  
                 SELECT
                      SUM(nvl(OL.QUANTITY,0))
                 INTO 
                      N_TERMINAL_LOCK    
                 FROM
                       T_PLN_LG_ORDER_HEAD OH
                       ,T_PLN_ORDER_TYPE OT
                       ,T_PLN_LG_ORDER_LINE OL
                       ,T_INV_INVENTORIES INV
                  WHERE OH.ORDER_TYPE_ID = OT.ORDER_TYPE_ID
                  AND   OH.ORDER_HEAD_ID = OL.ORDER_HEAD_ID
                  AND   OH.INVENTORY_TO_ID = INV.INVENTORY_ID
                  AND   INV.INVENTORY_TYPE = '10'   --样机仓
                  AND   OT.SOURCE_ORDER_TYPE_ID = 10  --样机申请订单
                  AND   OH.ORDER_HEAD_ID <> IN_ORDER_HEAD_ID
                  AND   OH.TERMINAL_ENTITY_ID = V_ORDER_LINE_ROW.TERMINAL_ENTITY_ID
                  AND   OH.ENTITY_ID = V_ORDER_LINE_ROW.ENTITY_ID
                  AND   ORDER_HEAD_STATE in('19','20','23')       --制单 已审核 已评审
                  AND   NOT EXISTS
                  (SELECT
                         (1)
                      FROM
                         T_INV_TRSF_ORDER TR
                         ,T_INV_TRSF_ORDER_LINE EL
                      WHERE
                        TR.TRSF_ORDER_ID = EL.TRSF_ORDER_ID
                       AND TR.ORIG_ORDER_TYPE='03'   --调拨申请
                       AND TR.Orig_Order_Id = OH.Order_Head_Id
                       AND TR.ORIG_ORDER_NUM = OH.ORDER_NUMBER
                       AND OL.ORDER_LINE_ID = EL.ORDER_LINE_ID_ORIG
                       AND TR.RCV_FLAG = 1
                   )AND  NOT EXISTS
                    (SELECT
                         (1)
                      FROM
                          T_LG_SHIP_DOC TD
                         ,T_LG_SHIP_DOC_LINE DL
                      WHERE
                         TD.SHIP_DOC_ID = DL.SHIP_DOC_ID
                         AND TD.DOC_STATUS = '00'
                         AND DL.Origin_Type in ('02','03')
                         AND DL.ORIGIN_ORDER_ID = OH.ORDER_HEAD_ID
                         AND DL.ORIGIN_LINE_ID = OL.ORDER_LINE_ID
                         AND NVL(DL.ITEM_QTY,0)-NVL(DL.CANCEL_QTY,0) <= 0
                    )AND  NOT EXISTS
                    (SELECT
                         1
                      FROM
                          cims.T_LG_SHIP_PLAN sp
                      WHERE
                         1=1
                         AND sp.origin_order_num = OH.Order_Number
                         AND sp.entity_id = OH.Entity_Id
                         AND sp.STATUS = '03'
                         AND sp.ORIGIN_ORDER_ID = OH.ORDER_HEAD_ID
                         AND sp.ORIGIN_LINE_ID = OL.ORDER_LINE_ID
                     );
                   N_TERMINAL_LOCK := NVL(N_TERMINAL_LOCK,0);  
                  
                  SELECT
                      SUM(nvl(OL.QUANTITY,0))
                  INTO 
                      N_ITEM_LOCK    
                  FROM
                       T_PLN_LG_ORDER_HEAD OH
                       ,T_PLN_ORDER_TYPE OT
                       ,T_PLN_LG_ORDER_LINE OL
                       ,T_INV_INVENTORIES INV
                    WHERE OH.ORDER_TYPE_ID = OT.ORDER_TYPE_ID
                    AND   OH.ORDER_HEAD_ID = OL.ORDER_HEAD_ID
                    AND   OH.INVENTORY_TO_ID = INV.INVENTORY_ID
                    AND   INV.INVENTORY_TYPE = '10'   --样机仓
                    AND   OT.SOURCE_ORDER_TYPE_ID = 10  --样机申请订单
                    AND   OH.ORDER_HEAD_ID <> IN_ORDER_HEAD_ID
                    AND   OH.TERMINAL_ENTITY_ID = V_ORDER_LINE_ROW.TERMINAL_ENTITY_ID
                    AND   OH.ENTITY_ID = V_ORDER_LINE_ROW.ENTITY_ID
                    AND   OL.ITEM_ID = V_ORDER_LINE_ROW.ITEM_ID
                    AND   ORDER_HEAD_STATE in('19','20','23')       --制单 已审核 已评审
                    AND   NOT EXISTS
                    (SELECT
                           (1)
                        FROM
                           T_INV_TRSF_ORDER TR
                           ,T_INV_TRSF_ORDER_LINE EL
                        WHERE
                          TR.TRSF_ORDER_ID = EL.TRSF_ORDER_ID
                         AND TR.ORIG_ORDER_TYPE='03'   --调拨申请
                         AND TR.Orig_Order_Id = OH.Order_Head_Id
                         AND TR.ORIG_ORDER_NUM = OH.ORDER_NUMBER
                         AND OL.ORDER_LINE_ID = EL.ORDER_LINE_ID_ORIG
                         AND TR.RCV_FLAG = 1
                     )AND  NOT EXISTS
                     (SELECT
                         (1)
                      FROM
                          T_LG_SHIP_DOC TD
                         ,T_LG_SHIP_DOC_LINE DL
                      WHERE
                         TD.SHIP_DOC_ID = DL.SHIP_DOC_ID
                         AND TD.DOC_STATUS = '00'
                         AND DL.Origin_Type in ('02','03')
                         AND DL.ORIGIN_ORDER_ID = OH.ORDER_HEAD_ID
                         AND DL.ORIGIN_LINE_ID = OL.ORDER_LINE_ID
                         AND NVL(DL.ITEM_QTY,0)-NVL(DL.CANCEL_QTY,0) <= 0
                     )AND  NOT EXISTS
                    (SELECT
                         1
                      FROM
                          cims.T_LG_SHIP_PLAN sp
                      WHERE
                         1=1
                         AND sp.origin_order_num = OH.Order_Number
                         AND sp.entity_id = OH.Entity_Id
                         AND sp.STATUS = '03'
                         AND sp.ORIGIN_ORDER_ID = OH.ORDER_HEAD_ID
                         AND sp.ORIGIN_LINE_ID = OL.ORDER_LINE_ID
                     );
                      N_ITEM_LOCK := NVL(N_ITEM_LOCK,0);  
                  
                 IF N_ITEM_QUANTITY + V_ORDER_LINE_ROW.QUANTITY + N_ITEM_LOCK  > N_ITEM_MAX THEN
                    OS_MESSAGE := '门店' || V_ORDER_LINE_ROW.TERMINAL_CODE||'产品'||V_ORDER_LINE_ROW.ITEM_CODE || '单品上样量超上限'||N_ITEM_MAX||'。'
                    || '当前产品已上样量：'||N_ITEM_QUANTITY||'，当前产品已在途量：'||N_ITEM_LOCK||'，本次产品上样量：'||V_ORDER_LINE_ROW.QUANTITY;
                    RETURN;
                 END IF;
                 
                 IF N_TERMINAL_QUANTITY + N_FACT_QTY + N_TERMINAL_LOCK  > N_TERMINAL_MAX THEN
                    OS_MESSAGE := '门店' || V_ORDER_LINE_ROW.TERMINAL_CODE || '最大上样量超上限'||N_TERMINAL_MAX||'。'
                    || '当前门店全部已上样量：'||N_TERMINAL_QUANTITY||'，当前门店全部已在途量：'||N_TERMINAL_LOCK||'，本次门店上样量：'|| N_FACT_QTY;
                    RETURN;
                 END IF;      
            END;
         END LOOP;

   END P_TERMINAL_MAX_CHECK;


    -----------------------------------------------------------------------------
    --  场内场外销售审核生成 销售单        --
    -----------------------------------------------------------------------------
   PROCEDURE P_PROTO_SO_HEADER(
       IN_ORDER_HEAD_ID     IN       T_PLN_LG_ORDER_HEAD.ORDER_HEAD_ID%TYPE
      ,IS_USER_ACCOUNT      IN      VARCHAR2 --用户ID
      ,OS_MESSAGE           OUT      VARCHAR2
   )
   AS
      N_ENTITY_ID               NUMBER;
      S_BILL_NUMBER             VARCHAR2(100);
      S_ORDER_NUMBER            VARCHAR2(100);
      N_CNT                     NUMBER;
      N_SHIP_BATCH_ID           NUMBER;
      N_ORDER_TYPE_ID           NUMBER;
      S_ORDER_HEAD_STATE        VARCHAR2(100);
      S_IS_BUSINESS_CONTROL      VARCHAR2(32);
  BEGIN
      OS_MESSAGE := 'OK';

       --锁定样机申请单表
    BEGIN
      SELECT
         ENTITY_ID
         ,ORDER_NUMBER
         ,ORDER_TYPE_ID
         ,ORDER_HEAD_STATE
      INTO
         N_ENTITY_ID
         ,S_ORDER_NUMBER
         ,N_ORDER_TYPE_ID
         ,S_ORDER_HEAD_STATE
      FROM
        T_PLN_LG_ORDER_HEAD
      WHERE
        ORDER_HEAD_ID = IN_ORDER_HEAD_ID
      FOR UPDATE NOWAIT;

      IF S_ORDER_HEAD_STATE <> '23' THEN
        OS_MESSAGE := '只有已审核的单据才可以生成财务单';
        RETURN;
      END IF;

      SELECT
         IS_BUSINESS_CONTROL
      INTO
         S_IS_BUSINESS_CONTROL
      FROM
         T_PLN_ORDER_TYPE
      WHERE
        ORDER_TYPE_ID = N_ORDER_TYPE_ID;

      --IF S_IS_BUSINESS_CONTROL <> 'proto_order_004' AND  S_IS_BUSINESS_CONTROL <> 'proto_order_003' THEN
      --  OS_MESSAGE := '只有场外销售，场外销售才能生成销售单。';
      --  RETURN;
    --  END IF;

    EXCEPTION
      WHEN TIMEOUT_ON_RESOURCE THEN
        OS_MESSAGE := '锁定样机申请单不成功！请稍后再试。';
  RETURN;
    END;

    --检查是否已写发货信息表
    IF OS_MESSAGE = 'OK' THEN
      SELECT
        COUNT(*)
      INTO
        N_CNT
      FROM
        T_LG_SHIP_DOC_SHIP_BATCH
      WHERE
        ORIGIN_ORDER_ID = IN_ORDER_HEAD_ID
        AND ORIGIN_TYPE = '02'
        AND ROWNUM = 1;
      IF N_CNT > 0 THEN
        OS_MESSAGE := '当前样机申请单已写发货信息，不能重复！';
        RETURN ;
      END IF;
    END IF;

    --查询发货通知单，循环生成多条销售单
    FOR R_DOC IN(
      select A.Ship_Doc_Id
             ,A.CONSIGNEE_INVENTORY_ID
             from T_LG_SHIP_DOC A
                  WHERE exists (select 1
                        from T_LG_SHIP_DOC_LINE B
                        where B.SHIP_DOC_ID = A.SHIP_DOC_ID
                        and B.ORIGIN_ORDER_NUM = S_ORDER_NUMBER)
                  and entity_id = N_ENTITY_ID
                  )
    LOOP
      --获取发货信息头ID
      SELECT
         S_LG_SHIP_DOC_SHIP_BATCH.NEXTVAL
      INTO
         N_SHIP_BATCH_ID
      FROM
         DUAL;

      S_BILL_NUMBER := PKG_BD.F_GET_BILL_NO('invShipMentNo',NULL,N_ENTITY_ID,NULL);

      INSERT INTO T_LG_SHIP_DOC_SHIP_BATCH
      (
        SHIP_BATCH_ID
       ,ENTITY_ID
       ,VEHICLE_NUM
       ,SHIP_DATE
       ,CREATED_BY
       ,CREATION_DATE
       ,LAST_UPDATED_BY
       ,LAST_UPDATE_DATE
       ,ORIGIN_TYPE
       ,ORIGIN_ORDER_ID
      )
      VALUES
      (
        N_SHIP_BATCH_ID
       ,N_ENTITY_ID
       ,S_BILL_NUMBER
       ,TRUNC(SYSDATE)
       ,IS_USER_ACCOUNT
       ,SYSDATE
       ,IS_USER_ACCOUNT
       ,SYSDATE
       ,'02'            --提货订单 原有的规则
       ,IN_ORDER_HEAD_ID
      );

       INSERT INTO T_LG_SHIP_DOC_SHIP_LINE
       (
           SHIP_LINE_ID
          ,SHIP_BATCH_ID
          ,SHIP_DOC_ID
          ,SHIP_DOC_LINE_ID
          ,QUANTITY
          ,CREATED_BY
          ,CREATION_DATE
          ,LAST_UPDATED_BY
          ,LAST_UPDATE_DATE
        )
        SELECT
            S_LG_SHIP_DOC_SHIP_LINE.NEXTVAL
            ,N_SHIP_BATCH_ID SHIP_BATCH_ID
            ,SD.SHIP_DOC_ID
            ,SD.SHIP_DOC_LINE_ID
            ,SD.ITEM_QTY
            ,IS_USER_ACCOUNT
            ,SYSDATE
            ,IS_USER_ACCOUNT
            ,SYSDATE
    FROM
      T_LG_SHIP_DOC_LINE SD
    WHERE
        SD.ORIGIN_TYPE in('02','03')
      AND  SD.ORIGIN_ORDER_NUM = S_ORDER_NUMBER
      AND  SD.ORIGIN_ORDER_ID = IN_ORDER_HEAD_ID
      AND  SD.SHIP_DOC_ID = R_DOC.SHIP_DOC_ID;

     PKG_LG_DOC_SHIP.P_SHIP_AFFIRM(IN_SHIP_BATCH_ID     =>  N_SHIP_BATCH_ID,   --调用过程生成销售单
             IS_USER_ID           =>  IS_USER_ACCOUNT,
             OS_MESSAGE           =>  OS_MESSAGE
            );
     --add by tangjz 2016-4-7
     if OS_MESSAGE != 'OK' then
        return;
     end if;

     IF OS_MESSAGE = 'OK' and R_DOC.CONSIGNEE_INVENTORY_ID is null   THEN    --回写发货通知单
        PKG_LG_DOC_SHIP.P_UPDATE_SHIP_DOC(IN_SHIP_BATCH_ID     =>  N_SHIP_BATCH_ID,
                                  IS_USER_ID           =>  IS_USER_ACCOUNT,
                                  OS_MESSAGE           =>  OS_MESSAGE
                                );
     END IF;
   END LOOP;
  END P_PROTO_SO_HEADER;

  PROCEDURE P_RED_DOC_TO_ACTUAL_SHIP(
     IN_SHIP_DOC_ID         IN  NUMBER   --红冲发货通知单ID
    ,IS_USER_ACCOUNT             IN  VARCHAR2 --用户ID
    ,OS_MESSAGE               OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  ) IS
    S_STEP             VARCHAR2(40);
    N_CNT              NUMBER;
    N_ACTUAL_SHIP_ID   NUMBER;

  BEGIN
    OS_MESSAGE := 'OK';
    --检查是否已写发货信息表
    IF OS_MESSAGE = 'OK' THEN
      S_STEP := '检查是否已写发货信息';
      SELECT
        COUNT(*)
      INTO
        N_CNT
      FROM
        T_LG_ACTUAL_SHIP
      WHERE
        SOURCE_BILL_ID = IN_SHIP_DOC_ID
        AND SOURCE_TYPE = 'PROTO_RED_BILL'
        AND ROWNUM = 1;
      IF N_CNT > 0 THEN
        OS_MESSAGE := '当前发货红冲单已写发货信息，不能重复调拨！';
      END IF;
    END IF;
    --写发货信息
    IF OS_MESSAGE = 'OK' THEN
      --按发货通知单对应的来源单据号分组，循环生成发货信息
      S_STEP := '写发货信息';
      FOR R_BILL IN
      (
        SELECT DISTINCT LINE.SALES_MAIN_TYPE,
          DOC.SHIP_INVENTORY_ID   SHIP_INVENTORY_ID,--发货仓,样机暂存仓
          DOC.SHIP_INVENTORY_CODE SHIP_INVENTORY_CODE,
          DOC.SHIP_INVENTORY_NAME SHIP_INVENTORY_NAME,
          INV.INVENTORY_ID CONSIGNEE_INVENTORY_ID,--收货仓
          INV.INVENTORY_CODE CONSIGNEE_INVENTORY_CODE,
          INV.INVENTORY_NAME CONSIGNEE_INVENTORY_NAME,
          DOC.SHIP_TERMINAL_ENTITY_ID CONSIGNEE_TERMINAL_ENTITY_ID, --收货门店
          DOC.SHIP_TERMINAL_CODE CONSIGNEE_TERMINAL_CODE,
          DOC.SHIP_TERMINAL_NAME CONSIGNEE_TERMINAL_NAME,
          PROE.CUSTOMER_ID,
          PROE.CUSTOMER_CODE,
          PROE.CUSTOMER_NAME,
          PROE.SALES_CENTER_ID,
          PROE.SALES_CENTER_CODE,
          PROE.SALES_CENTER_NAME,
          PROE.ACCOUNT_ID,
          PROE.ACCOUNT_CODE
        FROM T_LG_SHIP_DOC DOC, T_LG_SHIP_DOC_LINE LINE, T_INV_INVENTORIES INV, T_PRO_TERMINAL_ENTITY PROE
       WHERE 1 = 1
         AND DOC.SHIP_DOC_ID = LINE.SHIP_DOC_ID
         AND DOC.SHIP_DOC_ID = IN_SHIP_DOC_ID
         AND INV.TEMPORARY_INVENTORY_ID = DOC.SHIP_INVENTORY_ID
         AND INV.ENTITY_ID = DOC.ENTITY_ID
         AND PROE.TERMINAL_ENTITY_ID = DOC.SHIP_TERMINAL_ENTITY_ID
      )
      LOOP

             --获取发货信息头ID
          SELECT
            S_LG_ACTUAL_SHIP.NEXTVAL
          INTO
            N_ACTUAL_SHIP_ID
          FROM
            DUAL;

          --写发货信息头表
          INSERT INTO T_LG_ACTUAL_SHIP
          (
            ACTUAL_SHIP_ID
            ,ENTITY_ID
            ,SALES_MAIN_TYPE
            ,VEHICLE_NUM
            ,SALES_ORDER_TYPE_ID
            ,VENDOR_ID
            ,VENDOR_CODE
            ,VENDOR_NAME
            ,SHIP_INVENTORY_ID
            ,CONSIGNEE_TERMINAL_ENTITY_ID
            ,CONSIGNEE_TERMINAL_CODE
            ,CONSIGNEE_TERMINAL_NAME
            ,CONSIGNEE_INVENTORY_ID
            ,CONSIGNEE_LOCATION_CODE
            ,CONSIGNEE_ADDR
            ,SHIP_WAY
            ,ORIGIN_TYPE
            ,ORIGIN_ORDER_NUM
            ,ORIGIN_ORDER_ID
            ,CUSTOMER_ID
            ,CUSTOMER_CODE
            ,CUSTOMER_NAME
            ,ACCOUNT_CODE
            ,SHIP_DATE
            ,SOURCE_TYPE
            ,SOURCE_BILL_ID
            ,SOURCE_BILL_NUM
            ,CREATED_BY
            ,CREATION_DATE
            ,LAST_UPDATED_BY
            ,LAST_UPDATE_DATE
            ,WHETHER_A3
          )
          SELECT
            N_ACTUAL_SHIP_ID ACTUAL_SHIP_ID
            ,DOC.Entity_Id
            ,R_BILL.Sales_Main_Type
            ,DOC.SHIP_DOC_CODE
            ,NULL SALES_ORDER_TYPE_ID
            ,NULL VENDOR_ID
            ,NULL VENDOR_CODE
            ,NULL VENDOR_NAME
            ,R_BILL.SHIP_INVENTORY_ID
            ,R_BILL.CONSIGNEE_TERMINAL_ENTITY_ID--收货门店
            ,R_BILL.CONSIGNEE_TERMINAL_CODE--收货门店编码
            ,R_BILL.CONSIGNEE_TERMINAL_NAME
            ,R_BILL.CONSIGNEE_INVENTORY_ID
            ,DOC.ship_to_location_code CONSIGNEE_LOCATION_CODE
            ,DOC.ship_addr CONSIGNEE_ADDR
            ,DOC.SHIP_WAY SHIP_MODE
            ,'06' ORIGIN_TYPE
            ,DOC.SHIP_DOC_CODE  ORIGIN_ORDER_NUM
            ,DOC.SHIP_DOC_ID ORIGIN_ORDER_ID
            ,R_BILL.CUSTOMER_ID
            ,R_BILL.CUSTOMER_CODE
            ,R_BILL.CUSTOMER_NAME
            ,R_BILL.ACCOUNT_CODE
            ,TRUNC(SYSDATE) SHIP_DATE
            ,'PROTO_RED_BILL' SOURCE_TYPE
            ,DOC.SHIP_DOC_ID SOURCE_BILL_ID
            ,DOC.SHIP_DOC_CODE SOURCE_BILL_NUM
            ,IS_USER_ACCOUNT CREATED_BY
            ,SYSDATE CREATION_DATE
            ,IS_USER_ACCOUNT LAST_UPDATED_BY
            ,SYSDATE LAST_UPDATE_DATE
            ,'N'
          FROM
            T_LG_SHIP_DOC DOC
          WHERE 1=1
            AND DOC.SHIP_DOC_ID = IN_SHIP_DOC_ID;

          --写发货信息行表
          INSERT INTO T_LG_ACTUAL_SHIP_LINE
          (
            SOURCE_BILL_LINE_ID
            ,ORIGIN_SHIP_PLAN_ID
            ,ACTUAL_SHIP_LINE_ID
            ,SHIP_INFO_ID
            ,SHIP_DOC_LINE_ID
            ,ORIGIN_LINE_ID
            ,ITEM_CODE
            ,ITEM_NAME
            ,ITEM_QTY
            ,CREATED_BY
            ,CREATION_DATE
            ,LAST_UPDATED_BY
            ,LAST_UPDATE_DATE
          )
          SELECT
            LINE.SHIP_DOC_LINE_ID SOURCE_BILL_LINE_ID
            ,NULL ORIGIN_SHIP_PLAN_ID
            ,S_LG_ACTUAL_SHIP_LINE.NEXTVAL ACTUAL_SHIP_LINE_ID
            ,N_ACTUAL_SHIP_ID SHIP_INFO_ID
            ,LINE.Ship_Doc_Line_Id SHIP_DOC_LINE_ID
            ,LINE.SHIP_DOC_LINE_ID ORIGIN_LINE_ID
            ,LINE.ITEM_CODE
            ,LINE.ITEM_DESC ITEM_NAME
            ,LINE.Item_Qty ITEM_QTY
            ,IS_USER_ACCOUNT CREATED_BY
            ,SYSDATE CREATION_DATE
            ,IS_USER_ACCOUNT LAST_UPDATED_BY
            ,SYSDATE LAST_UPDATE_DATE
          FROM
            T_LG_SHIP_DOC DOC,
            T_LG_SHIP_DOC_LINE LINE
           WHERE 1=1
             AND DOC.Ship_Doc_Id = LINE.Ship_Doc_Id
             AND DOC.SHIP_DOC_ID = IN_SHIP_DOC_ID;

      END LOOP;
    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      OS_MESSAGE := '写实际发货信息(红冲发货通知单ID:' || TO_CHAR(IN_SHIP_DOC_ID) || ')-'|| S_STEP || ':' || SQLERRM;
  END P_RED_DOC_TO_ACTUAL_SHIP;

  -----------------------------------------------------------------------------
  --  样机销售单锁款
  -----------------------------------------------------------------------------
  PROCEDURE P_PRO_LOCK_AMOUNT(
     p_Order_Head_Id     IN       T_PLN_LG_ORDER_HEAD.ORDER_HEAD_ID%TYPE
     ,p_User_Code        IN       VARCHAR2 --用户ID
     ,p_Result           OUT      VARCHAR2
  ) IS
  r_Lg_Order   t_Pln_Lg_Order_Head%Rowtype;
  r_Order_Type t_Pln_Order_Type%Rowtype;
  v_Discount_Type_Common Varchar2(32) := 'COMMON';
  v_Price_Apply_Use_Discount t_bd_param_list.default_value%type := 'N'; --20170710 hejy3 价格批文开单使用折扣
  v_code                   Number := 0;
  v_OS_ATTRIB01           Varchar2(1000);
  v_OS_ATTRIB02           Varchar2(1000);
  v_Action_Type             Number;
  BEGIN
    p_Result := v_Success;
    Select *
        Into r_Lg_Order
        From t_Pln_Lg_Order_Head Oh
       Where Oh.Order_Head_Id = p_Order_Head_Id
         --And oh.order_head_state = 19
         For Update Nowait;
    Select *
        Into r_Order_Type
        From t_Pln_Order_Type Ot
       Where Ot.Order_Type_Id = r_Lg_Order.Order_Type_Id;
    
    --金额=（单价*数量*（100-折扣率-月返））/100
    --If p_Result = v_Success And Nvl(r_Lg_Order.Lock_Amount_Flag, r_Order_Type.Chk_Cusg_Amount_Flag) In ('Y', 'RT') Then
    If r_Order_Type.Is_Business_Control in ('proto_order_003','proto_order_004') 
       and r_Order_Type.Chk_Cusg_Amount_Flag = 'S' 
       and nvl(r_Lg_Order.LOCK_AMOUNT_FLAG,'Y') <> 'S' Then
      For r_Check_Amount In (Select --20170516 hejy3 按行营销大类
                                    nvl(lol.sales_main_type, bi.sales_main_type) Sales_Main_Type, --Bi.Sales_Main_Type,
                                    Nvl(Lol.Discount_Type, v_Discount_Type_Common) Discount_Type,   -- add by lizhen 2017-04-17
																		Sum(Round(Decode(Lol.Project_Order_Type,
                                               Null,
                                               (Nvl(Lol.Affirm_Quantity, 0) * Nvl(Lol.List_Price, 0) *
                                               (100 - Nvl(Lol.Discount_Rate, 0) -
                                               nvl(lol.ordered_discount_rate,0))) / 100,
                                               (Nvl(Lol.Affirm_Quantity, 0) *
                                               Nvl(Lol.Apply_List_Price, 0) *
                                               (100
                                                 --20170710 hejy3 价格批文开单使用折扣
                                                 - decode(v_Price_Apply_Use_Discount, 'Y', nvl(lol.apply_discount_rate, 0), 0)
                                                 - nvl(lol.ordered_discount_rate,0))) / 100),2)) Affirm_Amount,
                                    Sum(Round(Decode(Lol.Project_Order_Type,
                                               Null,
                                               (Nvl(Lol.Affirm_Quantity, 0) * Nvl(Lol.List_Price, 0) *
                                               Nvl(Lol.Discount_Rate, 0)) / 100,
                                               Nvl(Lol.Affirm_Quantity, 0) * Nvl(Lol.Apply_List_Price, 0) *
                                               --20170710 hejy3 价格批文开单使用折扣
                                               decode(v_Price_Apply_Use_Discount, 'Y', nvl(lol.apply_discount_rate, 0), 0) / 100),2)) Discount_Amount
                               From t_Pln_Lg_Order_Line Lol, t_Bd_Item Bi
                              Where Lol.Item_Id = Bi.Item_Id
                                And Bi.Entity_Id = Lol.Entity_Id
                                And Lol.Order_Head_Id = p_Order_Head_Id
                                And Lol.Entity_Id = r_Lg_Order.Entity_Id
                                --20170516 hejy3 按行营销大类
                              Group By nvl(lol.sales_main_type, bi.sales_main_type), --Bi.Sales_Main_Type
																Nvl(Lol.Discount_Type, v_Discount_Type_Common)  -- add by lizhen 2017-04-17
                              ) Loop

        If Nvl(r_Check_Amount.Affirm_Amount, 0) + Nvl(r_Check_Amount.Discount_Amount, 0) <> 0 Then
          --检查并锁定资金
          --MODI BY LIZHEN 2015-07-17  按提货订单头的锁款标志进行提货订单锁款判断
          --If Nvl(r_Order_Type.Chk_Cusg_Amount_Flag, '_') = v_True And nvl(r_Order_Type.Is_Business_Control,'_') <> 'share_ship_order' Then
          --modi by lizhen 2015-08-11 增加推广物料到款锁定
          If Nvl(r_Lg_Order.Lock_Amount_Flag, r_Order_Type.Chk_Cusg_Amount_Flag) = 'Y' Then
              Pkg_Credit_Account_Control.Prc_Credit_Order_Bill(p_Entity_Id       => r_Lg_Order.Entity_Id,
                                                               p_Action_Type     => 1,
                                                               p_Settlement_Sum  => Nvl(r_Check_Amount.Affirm_Amount,
                                                                                        0),
                                                               p_Discount_Sum    => Nvl(r_Check_Amount.Discount_Amount,
                                                                                        0),
                                                               p_Sales_Main_Type => r_Check_Amount.Sales_Main_Type,
                                                               p_Account_Id      => r_Lg_Order.Account_Id,
                                                               p_Customer_Id     => r_Lg_Order.Customer_Id,
                                                               p_Proj_Number     => Null,
                                                               p_Order_Id        => r_Lg_Order.Order_Head_Id,
                                                               --p_Order_Type      => r_Lg_Order.Order_Type_Name,
                                                               P_ORDER_TYPE => r_Lg_Order.Order_Type_Code, --20160912 hejy3 传入订单类型编码
                                                               p_Username        => p_User_Code,
                                                               p_Result          => v_code,
                                                               p_Err_Msg         => p_Result,
                                                               IS_DISCOUNT_TYPE  => r_Check_Amount.Discount_Type --ADD BY LIZHEN 2017-08-08折扣类型
                                                               );
              If p_Result <> v_Success Then
                p_Result := '检查并锁定资金失败，产品大类：' || r_Check_Amount.Sales_Main_Type || v_Nl ||
                            p_Result;
                return;
              End If;
              If r_Check_Amount.Discount_Type != v_Discount_Type_Common  Then
                PKG_CREDIT_DIS.P_CHECK_DIS_AMOUNT(IN_ACTION_TYPE     => 1, --操作类型 与信用控制动作标识一致
                                                   IN_ENTITY_ID      => r_Lg_Order.Entity_Id, --主体ID
                                                   IN_ACCOUNT_ID      => r_Lg_Order.Account_Id, --客户账户ID
                                                   IS_SOURCE_TYPE     => '02', --来源类型 取码表SO_SRC_TYPE
                                                   IN_SOURCE_BILL_ID  => r_Lg_Order.Order_Head_Id, --来源单据ID 取相应的单据头ID
                                                   IS_SALES_MAIN_TYPE => r_Check_Amount.Sales_Main_Type, --营销大类
                                                   IS_DISCOUNT_TYPE   => r_Check_Amount.Discount_Type, --折扣类型 取行上的折扣类型
                                                   IN_AMOUNT          => r_Check_Amount.Affirm_Amount, --金额
                                                   Is_User_Name       => p_User_Code, --用户编码
                                                   IS_ATTRIB01        => Null, --预留输入参数01
                                                   IS_ATTRIB02        => Null, --预留输入参数02
                                                   ON_RESULT          => v_code, --成功则返回0，否则返回对应的出错代码
                                                   OS_MESSAGE         => p_Result, --成功返回“SUCCESS”；失败返回出错信息
                                                   OS_ATTRIB01        => v_OS_ATTRIB01, --预留输出参数01
                                                   OS_ATTRIB02        => v_OS_ATTRIB02 --预留输出参数02
                                                   );
                If p_Result <> v_Success Then
                  p_Result := '检查并锁定折扣类型金额失败。' || v_Nl || 
                              '产品大类：' || r_Check_Amount.Sales_Main_Type || v_Nl ||
                              '折扣类型：' || r_Check_Amount.Discount_Type || v_Nl ||
                              p_Result;
                  return;
                End If;
              End If;
            End If;
        End If;
      End Loop;
      If p_Result = v_Success Then
         update t_Pln_Lg_Order_Head h set h.lock_amount_flag = 'S' Where h.Order_Head_Id = p_Order_Head_Id;
      End If;
    End If;
  END;
  -----------------------------------------------------------------------------
  --  样机销售单解锁款
  -----------------------------------------------------------------------------
  PROCEDURE P_PRO_RELEASE_AMOUNT(
     p_Order_Head_Id     IN       T_PLN_LG_ORDER_HEAD.ORDER_HEAD_ID%TYPE
     ,p_User_Code        IN       VARCHAR2 --用户ID
     ,p_Result           OUT      VARCHAR2
  ) IS
  r_Lg_Order   t_Pln_Lg_Order_Head%Rowtype;
  r_Order_Type t_Pln_Order_Type%Rowtype;
  v_Discount_Type_Common Varchar2(32) := 'COMMON';
  v_Price_Apply_Use_Discount t_bd_param_list.default_value%type := 'N'; --20170710 hejy3 价格批文开单使用折扣
  v_code                   Number := 0;
  v_OS_ATTRIB01           Varchar2(1000);
  v_OS_ATTRIB02           Varchar2(1000);
  v_Action_Type             Number;
  BEGIN
    p_Result := v_Success;
    Select *
        Into r_Lg_Order
        From t_Pln_Lg_Order_Head Oh
       Where Oh.Order_Head_Id = p_Order_Head_Id
         --And oh.order_head_state = 19
         For Update Nowait;
    Select *
        Into r_Order_Type
        From t_Pln_Order_Type Ot
       Where Ot.Order_Type_Id = r_Lg_Order.Order_Type_Id;
    
    --金额=（单价*数量*（100-折扣率-月返））/100
    --If p_Result = v_Success And Nvl(r_Lg_Order.Lock_Amount_Flag, r_Order_Type.Chk_Cusg_Amount_Flag) In ('Y', 'RT') Then
    If r_Order_Type.Is_Business_Control in ('proto_order_003','proto_order_004') 
       and nvl(r_Lg_Order.LOCK_AMOUNT_FLAG,'Y') = 'S' Then
      For r_Check_Amount In (Select --20170516 hejy3 按行营销大类
                                    nvl(lol.sales_main_type, bi.sales_main_type) Sales_Main_Type, --Bi.Sales_Main_Type,
                                    Nvl(Lol.Discount_Type, v_Discount_Type_Common) Discount_Type,   -- add by lizhen 2017-04-17
																		Sum(Round(Decode(Lol.Project_Order_Type,
                                               Null,
                                               (Nvl(Lol.Affirm_Quantity, 0) * Nvl(Lol.List_Price, 0) *
                                               (100 - Nvl(Lol.Discount_Rate, 0) -
                                               nvl(lol.ordered_discount_rate,0))) / 100,
                                               (Nvl(Lol.Affirm_Quantity, 0) *
                                               Nvl(Lol.Apply_List_Price, 0) *
                                               (100
                                                 --20170710 hejy3 价格批文开单使用折扣
                                                 - decode(v_Price_Apply_Use_Discount, 'Y', nvl(lol.apply_discount_rate, 0), 0)
                                                 - nvl(lol.ordered_discount_rate,0))) / 100),2)) Affirm_Amount,
                                    Sum(Round(Decode(Lol.Project_Order_Type,
                                               Null,
                                               (Nvl(Lol.Affirm_Quantity, 0) * Nvl(Lol.List_Price, 0) *
                                               Nvl(Lol.Discount_Rate, 0)) / 100,
                                               Nvl(Lol.Affirm_Quantity, 0) * Nvl(Lol.Apply_List_Price, 0) *
                                               --20170710 hejy3 价格批文开单使用折扣
                                               decode(v_Price_Apply_Use_Discount, 'Y', nvl(lol.apply_discount_rate, 0), 0) / 100),2)) Discount_Amount
                               From t_Pln_Lg_Order_Line Lol, t_Bd_Item Bi
                              Where Lol.Item_Id = Bi.Item_Id
                                And Bi.Entity_Id = Lol.Entity_Id
                                And Lol.Order_Head_Id = p_Order_Head_Id
                                And Lol.Entity_Id = r_Lg_Order.Entity_Id
                                --20170516 hejy3 按行营销大类
                              Group By nvl(lol.sales_main_type, bi.sales_main_type), --Bi.Sales_Main_Type
																Nvl(Lol.Discount_Type, v_Discount_Type_Common)  -- add by lizhen 2017-04-17
                              ) Loop

        If Nvl(r_Check_Amount.Affirm_Amount, 0) + Nvl(r_Check_Amount.Discount_Amount, 0) <> 0 Then
          --检查并锁定资金
          If Nvl(r_Lg_Order.Lock_Amount_Flag, 'Y') = 'S' Then
              Pkg_Credit_Account_Control.Prc_Credit_Order_Bill(p_Entity_Id       => r_Lg_Order.Entity_Id,
                                                               p_Action_Type     => 2,
                                                               p_Settlement_Sum  => Nvl(r_Check_Amount.Affirm_Amount,
                                                                                        0),
                                                               p_Discount_Sum    => Nvl(r_Check_Amount.Discount_Amount,
                                                                                        0),
                                                               p_Sales_Main_Type => r_Check_Amount.Sales_Main_Type,
                                                               p_Account_Id      => r_Lg_Order.Account_Id,
                                                               p_Customer_Id     => r_Lg_Order.Customer_Id,
                                                               p_Proj_Number     => Null,
                                                               p_Order_Id        => r_Lg_Order.Order_Head_Id,
                                                               --p_Order_Type      => r_Lg_Order.Order_Type_Name,
                                                               P_ORDER_TYPE => r_Lg_Order.Order_Type_Code, --20160912 hejy3 传入订单类型编码
                                                               p_Username        => p_User_Code,
                                                               p_Result          => v_code,
                                                               p_Err_Msg         => p_Result,
                                                               IS_DISCOUNT_TYPE  => r_Check_Amount.Discount_Type --ADD BY LIZHEN 2017-08-08折扣类型
                                                               );
              If p_Result <> v_Success Then
                p_Result := '检查并锁定资金失败，产品大类：' || r_Check_Amount.Sales_Main_Type || v_Nl ||
                            p_Result;
                return;
              End If;
              If r_Check_Amount.Discount_Type != v_Discount_Type_Common  Then
                PKG_CREDIT_DIS.P_CHECK_DIS_AMOUNT(IN_ACTION_TYPE     => 2, --操作类型 与信用控制动作标识一致
                                                   IN_ENTITY_ID      => r_Lg_Order.Entity_Id, --主体ID
                                                   IN_ACCOUNT_ID      => r_Lg_Order.Account_Id, --客户账户ID
                                                   IS_SOURCE_TYPE     => '02', --来源类型 取码表SO_SRC_TYPE
                                                   IN_SOURCE_BILL_ID  => r_Lg_Order.Order_Head_Id, --来源单据ID 取相应的单据头ID
                                                   IS_SALES_MAIN_TYPE => r_Check_Amount.Sales_Main_Type, --营销大类
                                                   IS_DISCOUNT_TYPE   => r_Check_Amount.Discount_Type, --折扣类型 取行上的折扣类型
                                                   IN_AMOUNT          => r_Check_Amount.Affirm_Amount, --金额
                                                   Is_User_Name       => p_User_Code, --用户编码
                                                   IS_ATTRIB01        => Null, --预留输入参数01
                                                   IS_ATTRIB02        => Null, --预留输入参数02
                                                   ON_RESULT          => v_code, --成功则返回0，否则返回对应的出错代码
                                                   OS_MESSAGE         => p_Result, --成功返回“SUCCESS”；失败返回出错信息
                                                   OS_ATTRIB01        => v_OS_ATTRIB01, --预留输出参数01
                                                   OS_ATTRIB02        => v_OS_ATTRIB02 --预留输出参数02
                                                   );
                If p_Result <> v_Success Then
                  p_Result := '检查并锁定折扣类型金额失败。' || v_Nl || 
                              '产品大类：' || r_Check_Amount.Sales_Main_Type || v_Nl ||
                              '折扣类型：' || r_Check_Amount.Discount_Type || v_Nl ||
                              p_Result;
                  return;
                End If;
              End If;
            End If;
        End If;
      End Loop;
      If p_Result = v_Success Then
         update t_Pln_Lg_Order_Head h set h.lock_amount_flag = 'Y' Where h.Order_Head_Id = p_Order_Head_Id;
      End If;
    End If;
  END;
END PKG_PROTO;
/

