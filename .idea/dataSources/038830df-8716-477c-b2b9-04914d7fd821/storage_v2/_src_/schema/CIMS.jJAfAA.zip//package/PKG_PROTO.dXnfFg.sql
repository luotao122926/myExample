create PACKAGE PKG_PROTO AS
  ------------------------------------------------------------------------------------------------
  --                                                                                            --
  -- 样机后台包                                                                                 --
  --                                                                                            --
  --                                                                 --
  ------------------------------------------------------------------------------------------------
  /*
  2015-07-22 桂必荣
  创建样机后台包。
  */

-----------------------------------------------------------------------------
  --  将实发数量记录到实际发货信息表中（调拨单）             --
  -----------------------------------------------------------------------------
  PROCEDURE P_TO_ACTUAL_SHIP(
     IN_ORDER_HEAD_ID         IN  NUMBER   --样机申请单ID
    ,IS_USER_ACCOUNT               IN  VARCHAR2 --用户ID
    ,OS_MESSAGE               OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  );



  -----------------------------------------------------------------------------
  --  计算门店库存现有量            --
  -----------------------------------------------------------------------------
   PROCEDURE P_INV_UPDATE_TERMINAL_ONHAND(
       IN_TRANSACTION_ID     IN       T_INV_TRANSACTION_HISTORY.TRANSACTION_ID%TYPE
      ,OS_MESSAGE            OUT      VARCHAR2
   );


    -----------------------------------------------------------------------------
    --  校验样机订单是否有库存           --
    -----------------------------------------------------------------------------
   PROCEDURE P_TERMINAL_ONHAND_CHECK(
       IN_ORDER_HEAD_ID     IN       T_PLN_LG_ORDER_HEAD.ORDER_HEAD_ID%TYPE
      ,OS_MESSAGE           OUT      VARCHAR2
   );

    -----------------------------------------------------------------------------
    --  校验样机订单是否超过门店最大上样量           --
    -----------------------------------------------------------------------------
   PROCEDURE P_TERMINAL_MAX_CHECK(
       IN_ORDER_HEAD_ID     IN       T_PLN_LG_ORDER_HEAD.ORDER_HEAD_ID%TYPE
      ,OS_MESSAGE           OUT      VARCHAR2
   );



    -----------------------------------------------------------------------------
    --  场内场外销售审核生成 销售单        --
    -----------------------------------------------------------------------------
   PROCEDURE P_PROTO_SO_HEADER(
       IN_ORDER_HEAD_ID     IN       T_PLN_LG_ORDER_HEAD.ORDER_HEAD_ID%TYPE
      ,IS_USER_ACCOUNT      IN       VARCHAR2 --用户ID
      ,OS_MESSAGE           OUT      VARCHAR2
   );

  -----------------------------------------------------------------------------
  --  根据红冲发货通知单  实发数量记录到实际发货信息表中（调拨单）          --
  -----------------------------------------------------------------------------
  PROCEDURE P_RED_DOC_TO_ACTUAL_SHIP(
     IN_SHIP_DOC_ID        IN  NUMBER   --红冲发货通知单ID
    ,IS_USER_ACCOUNT               IN  VARCHAR2 --用户ID
    ,OS_MESSAGE               OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  );
  
  -----------------------------------------------------------------------------
  --  样机销售单锁款
  -----------------------------------------------------------------------------
  PROCEDURE P_PRO_LOCK_AMOUNT(
     p_Order_Head_Id     IN       T_PLN_LG_ORDER_HEAD.ORDER_HEAD_ID%TYPE
     ,p_User_Code        IN       VARCHAR2 --用户ID
     ,p_Result           OUT      VARCHAR2
  );
  
  -----------------------------------------------------------------------------
  --  样机销售单解锁款
  -----------------------------------------------------------------------------
  PROCEDURE P_PRO_RELEASE_AMOUNT(
     p_Order_Head_Id     IN       T_PLN_LG_ORDER_HEAD.ORDER_HEAD_ID%TYPE
     ,p_User_Code        IN       VARCHAR2 --用户ID
     ,p_Result           OUT      VARCHAR2
  );
  

END PKG_PROTO;
/

