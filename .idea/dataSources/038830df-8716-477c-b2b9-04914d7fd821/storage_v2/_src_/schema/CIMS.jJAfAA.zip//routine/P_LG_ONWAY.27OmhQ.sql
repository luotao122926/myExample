create procedure      P_LG_ONWAY(I_VELNUM     IN  VARCHAR2,
                                            O_RESULT     OUT VARCHAR2, --返回错误码
                                            O_RESULT_MSG OUT VARCHAR2 --返回错误信息
                                            ) is

  TYPE ref_cursor_type IS REF CURSOR;  --定义一个动态游标
  v_sql varchar2(1000); 
  --跟踪表最大ID
  followD date;
  followDateC varchar2(200);
  --排车编号是否存在的临时变量
  TEMP_CountVehicle number;
  --排除信息编号ID
  TEMP_VEHICLE_INFO_ID number;
  --主键是否冲突0正常,>1主键冲突
  -- TEMP_CountKey number;
  --状态,在途or到达
  TEMP_VEHICLE_FOLLOW_STATUS VARCHAR2(20);

  --查到记录数
  TEMP_VIEW_INFO_COUNT number;

  --能匹配到排车信息ID的记录数
  TEMP_CIMS_INFO_COUNT number;

  --主键冲突在途跟踪信息数量
  TEMP_KEY_ERROR_COUNT number;

  --合同ID
  --TEMP_CONTRACT_ID T_LG_CONTRACT.CONTRACT_ID%TYPE;

  --TYPE C_LG_CONTRACT IS REF CURSOR; --声明动态游标
  --V_LG_CONTRACT_CURSOR C_LG_CONTRACT; --定义游标

  --查询在途跟踪信息游标
  VEHICLE_FOLLOW_cost ref_cursor_type;

  --字段临时变量
  --TEMP_ROWNUM            number;
  TEMP_VEHICLE_NUM       VARCHAR2(220);
  TEMP_VEHICLE_FOLLOW_ID number;
  TEMP_FOLLOW_DATE       VARCHAR2(120);
  TEMP_LOCATION          VARCHAR2(300);
  TEMP_ABNORMITY_CIRCS   VARCHAR2(586);
  TEMP_EXCEPTION_FLAG    VARCHAR2(16);
  TEMP_REAL_ARRIVE_DATE  VARCHAR2(120);
  TEMP_CONTRACT_ID       number;
  I_VELNUM2              VARCHAR2(200);
  TEMP_CREATE_DATE       date;
  TEMP_SITE_NAME         VARCHAR2(200);--运输服务平台名称
  TEMP_ETTA_REQ_ARRIVAL_DATE date;--预计到货时间

BEGIN
  O_RESULT     := '1';
  O_RESULT_MSG := '生成成功';

  TEMP_VIEW_INFO_COUNT := 0;
  TEMP_CIMS_INFO_COUNT := 0;
  TEMP_KEY_ERROR_COUNT := 0;

  v_sql := 'SELECT *
      FROM (select dl.VEHICLE_NUM,
                   dl.VEHICLE_FOLLOW_ID,
                   to_char(dl.FOLLOW_DATE, ''yyyy-MM-dd HH24:mi:ss'') as FOLLOW_DATE,
                   dl.LOCATION,
                   dl.ABNORMITY_CIRCS,
                   dl.EXCEPTION_FLAG,
                   to_char(dl.REAL_ARRIVE_DATE, ''yyyy-MM-dd HH24:mi:ss'') as REAL_ARRIVE_DATE,
                   SITE_NAME,
                   ETTA_REQ_ARRIVAL_DATE
              from a3_lg_onway_info dl
             where 1=1 ';
             
   BEGIN
     --获取已导入的最大流水号
     select max(dl.creation_date)-1/24/60
       INTO followD
       from T_LG_VEHICLE_FOLLOW dl;
   Exception
     When no_data_found THEN
        followD := sysdate - 10;
   END;
   followDateC := to_char(followD,'yyyy-MM-dd hh24:mi:ss');          
   
   if I_VELNUM is null then
     TEMP_CREATE_DATE := sysdate;
     v_sql := v_sql || ' and dl.modify_date > to_date('''||followDateC||''',''yyyy-MM-dd hh24:mi:ss'') order by dl.modify_date)';
   else
     TEMP_CREATE_DATE := followD;
     select nvl(substr(I_VELNUM, 1, instr(I_VELNUM, '_') - 1),I_VELNUM) into I_VELNUM2 from dual;
     v_sql := v_sql || ' and dl.VEHICLE_NUM = '''||I_VELNUM2||'''';
     v_sql := v_sql || ' and dl.modify_date < to_date('''||followDateC||''',''yyyy-MM-dd hh24:mi:ss'') order by dl.modify_date)';
     
   end if;

  BEGIN

    --设置回滚点
    SAVEPOINT savepoint_1;
    --打开游标
    --open VEHICLE_FOLLOW_cost(followD);
    open VEHICLE_FOLLOW_cost for v_sql ;
    --把在途跟踪记录保存到本地表
    LOOP
      FETCH VEHICLE_FOLLOW_cost
        INTO TEMP_VEHICLE_NUM,
             TEMP_VEHICLE_FOLLOW_ID,
             TEMP_FOLLOW_DATE,
             TEMP_LOCATION,
             TEMP_ABNORMITY_CIRCS,
             TEMP_EXCEPTION_FLAG,
             TEMP_REAL_ARRIVE_DATE,
             TEMP_SITE_NAME,
             TEMP_ETTA_REQ_ARRIVAL_DATE;
      EXIT WHEN VEHICLE_FOLLOW_cost%NOTFOUND;

      --找到的记录数量---------------------------------------------------------------------------
      TEMP_VIEW_INFO_COUNT := TEMP_VIEW_INFO_COUNT + 1;

      --判断排车编号是否存在
      select count(VEHICLE_INFO_ID)
        INTO TEMP_CountVehicle
        from T_LG_VEHICLE_INFO t
       where t.VEHICLE_NUM like TEMP_VEHICLE_NUM||'%';
         -- nvl(substr(t.VEHICLE_NUM, 1, instr(t.VEHICLE_NUM, '_') - 1),t.VEHICLE_NUM) = TEMP_VEHICLE_NUM;

      --如果排除编号存在则获取排车信息ID
      IF (TEMP_CountVehicle > 0) THEN
        select VEHICLE_INFO_ID
          INTO TEMP_VEHICLE_INFO_ID
          from T_LG_VEHICLE_INFO t
         where t.VEHICLE_NUM like TEMP_VEHICLE_NUM||'%'
           --nvl(substr(t.VEHICLE_NUM, 1, instr(t.VEHICLE_NUM, '_') - 1),t.VEHICLE_NUM) = TEMP_VEHICLE_NUM
           and rownum = 1;

        -- 更新排车表最新时间、最新地点
        update T_LG_VEHICLE_INFO F
           set f.follow_date = to_date(TEMP_FOLLOW_DATE,
                                       'yyyy-mm-dd hh24:mi:ss'),
               f.location    = TEMP_LOCATION
         where f.VEHICLE_NUM like TEMP_VEHICLE_NUM||'%'
         --nvl(substr(f.VEHICLE_NUM, 1, instr(f.VEHICLE_NUM, '_') - 1),f.VEHICLE_NUM) = TEMP_VEHICLE_NUM
           and ((f.follow_date is null) or
                (f.follow_date is not null and
                f.follow_date <
                to_date(TEMP_FOLLOW_DATE, 'yyyy-mm-dd hh24:mi:ss')));

        --能匹配到的排车编号的数量
        TEMP_CIMS_INFO_COUNT := TEMP_CIMS_INFO_COUNT + 1;

      END IF;

      IF (TEMP_CountVehicle > 0) THEN

        IF (TEMP_REAL_ARRIVE_DATE is not NULL) THEN
          for i in (SELECT s.vehicle_info_id, s.contract_id
                      FROM T_LG_CONTRACT s
                     WHERE s.VEHICLE_INFO_ID in
                           (select VEHICLE_INFO_ID
                              from T_LG_VEHICLE_INFO t
                             where t.VEHICLE_NUM like TEMP_VEHICLE_NUM||'%')) loop
            --先锁表
            select contract_id
              into TEMP_CONTRACT_ID
              FROM T_LG_CONTRACT
             WHERE contract_id = i.contract_id;

            update T_LG_CONTRACT
               set FACT_ARRIVE_DATE = to_date(TEMP_REAL_ARRIVE_DATE,
                                              'yyyy-mm-dd hh24:mi:ss'),
                    Transport_Platform = nvl(Transport_Platform,TEMP_SITE_NAME),
                    ETTA_REQ_ARRIVAL_DATE = nvl(ETTA_REQ_ARRIVAL_DATE,TEMP_ETTA_REQ_ARRIVAL_DATE)                          
             where VEHICLE_INFO_ID = i.vehicle_info_id
               and contract_id = i.contract_id;

          end loop;

          TEMP_VEHICLE_FOLLOW_STATUS := '已到达';
        ELSE
          TEMP_VEHICLE_FOLLOW_STATUS := '在途';
        END IF;
        --写入排车信息
        insert into T_LG_VEHICLE_FOLLOW
          (VEHICLE_FOLLOW_ID,
           VEHICLE_INFO_ID,
           FOLLOW_DATE,
           LOCATION,
           VEHICLE_STATE,
           ABNORMITY_CIRCS,
           EXCEPTION_FLAG,
           CREATED_BY,
           CREATION_DATE,
           LAST_UPDATED_BY,
           LAST_UPDATE_DATE)
        VALUES
          (S_LG_VEHICLE_FOLLOW.nextval,
           TEMP_VEHICLE_INFO_ID,
           to_date(TEMP_FOLLOW_DATE, 'yyyy-mm-dd hh24:mi:ss'),
           TEMP_LOCATION,
           TEMP_VEHICLE_FOLLOW_STATUS,
           TEMP_ABNORMITY_CIRCS,
           TEMP_EXCEPTION_FLAG,
           'C-IMS-A3',
           TEMP_CREATE_DATE,
           'C-IMS-A3',
           TEMP_CREATE_DATE);
      END IF;
    END LOOP;
    --O_RESULT_MSG := '视图中所有的排车编号=' || TEMP_VEHICLE_NUM_ALL || '写入排车信息' ||
    --TEMP_VEHICLE_NUM_INSERT;
    --commit;
    --CLOSE VEHICLE_FOLLOW_cost;
    O_RESULT_MSG := O_RESULT_MSG || '视图找到的新记录数量=' || TEMP_VIEW_INFO_COUNT ||
                    '能匹配到排车信息ID的记录数=' || TEMP_CIMS_INFO_COUNT ||
                    '主键重复的记录数=' || TEMP_KEY_ERROR_COUNT;
  Exception
    When OTHERS THEN
      --回滚
      O_RESULT     := '0';
      O_RESULT_MSG := O_RESULT_MSG || 'no_data_found'||SQLERRM;
      O_RESULT_MSG  := PKG_BD.F_ADD_ERROR_LOG('P_LG_ONWAY',sqlcode,'排车号TEMP_VEHICLE_NUM'||TEMP_VEHICLE_NUM||O_RESULT_MSG);
      --ROLLBACK TO SAVEPOINT savepoint_1;
  END;
end P_LG_ONWAY;
/

