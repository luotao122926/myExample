create package body PKG_CREDIT_INTF_DUE is
  /*----------------------------------------------------------------
  *         包：PKG_CREDIT_INTF_DUE
  *   创建日期：2014-07-24
  *     创建者：苏冬渊
  *   功能说明：处理接口同步功能
  *
  *   过程成功：P_RESULT = 0
  *             P_ERR_MSG = 'SUCCESS';
  *
  *   过程失败：P_RESULT < -20000;
  *             P_ERR_MSG = 过程异常失败的提示信息
  *
  */ ----------------------------------------------------------------

  --V_NL             CONSTANT VARCHAR2(2) := CHR(13) || CHR(10); --换行
  V_SEC_RESULT CONSTANT NUMBER := 0; --成功返回
  V_ERR_RESULT CONSTANT NUMBER := -1; --失败
  V_SUCCESS    CONSTANT VARCHAR2(10) := 'SUCCESS';
  V_BASE_EXCEPTION EXCEPTION; --自定义异常
  --------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-24
  *     创建者：苏冬渊
  *   功能说明：处理小电铺底单据从接口表同步到业务表
  *
  *
  */
  -------------------------------------------------------------------------------
  PROCEDURE PRC_INTF_CREDIT_DELAYPAY(P_RESULT  IN OUT NUMBER, --返回错误ID
                                     P_ERR_MSG IN OUT VARCHAR2 --返回错误信息
                                     ) IS
    V_BILL_ID NUMBER;
    CURSOR CUR_CREDIT_DELAYPAY IS
      SELECT T.Source_Bill_Id
        FROM INTF_CREDIT_DELAYPAY T
       WHERE T.DUE_FLAG IS NULL;
  BEGIN
    P_RESULT  := V_SEC_RESULT;
    P_ERR_MSG := V_SUCCESS;
  
    FOR I IN CUR_CREDIT_DELAYPAY LOOP
      PRC_INTF_CREDIT_DELAYPAY_BILL(P_SRC_BILL_ID => I.SOURCE_BILL_ID,
                                    P_BILL_ID     => V_BILL_ID,
                                    P_RESULT      => P_RESULT,
                                    P_ERR_MSG     => P_ERR_MSG);
      --重置变量
      P_RESULT  := V_SEC_RESULT;
      P_ERR_MSG := V_SUCCESS;
    
    END LOOP;
    COMMIT;
  END; --PRC_INTF_CREDIT_DELAYPAY

  --------------------------------------------------------------------------------
  /*
  *   创建日期：2015-08-01
  *     创建者：梁颜明
  *   功能说明：CSS调用小电铺底单据从接口表同步到业务表的处理
  *
  *
  */
  -------------------------------------------------------------------------------
  PROCEDURE PRC_INTF_CREDIT_DELAYPAY_BILL(P_SRC_BILL_ID IN NUMBER, --接口铺底单据ID
                                          P_BILL_ID     OUT NUMBER, --铺底单据ID
                                          P_RESULT      IN OUT NUMBER, --返回错误ID
                                          P_ERR_MSG     IN OUT VARCHAR2 --返回错误信息
                                          ) IS
    V_CUSTOMER_ID   T_CREDIT_DELAYPAY.CUSTOMER_ID%TYPE;
    V_ACCOUNT_ID    T_CREDIT_DELAYPAY.ACCOUNT_ID%TYPE;
    V_COUNT         NUMBER;
    V_BILL_ID       NUMBER;
    V_PLANPAY_DATE  T_CREDIT_DELAYPAY.PLANPAY_DATE%Type; --计划还款日期
    entityGroupCode Varchar2(100); --主体组
    V_BILL_NUM      T_CREDIT_DELAYPAY.BILL_NUM%Type;
    V_BILL_NUM_NEW  T_CREDIT_DELAYPAY.BILL_NUM%Type;
  
    V_INTF_CREDIT INTF_CREDIT_DELAYPAY%rowtype;
  
    --tianmzh 2016-06-14增加
    V_ACCOUNT_STATUS VARCHAR2(1000); --账户状态
    V_S_HEAD_ID      T_CREDIT_DELAYPAY_HEAD.BILL_HEAD_ID%TYPE; --头表主键序列
    V_CASH_RECEIPT_CODE T_AR_CASH_RECEIPT_HEADERS.CASH_RECEIPT_CODE%TYPE; --收款单号
  
  BEGIN
  
    select *
      into V_INTF_CREDIT
      from INTF_CREDIT_DELAYPAY t
     where t.source_bill_id = P_SRC_BILL_ID;
  
    if 0 = V_INTF_CREDIT.Due_Flag then
      P_RESULT  := V_INTF_CREDIT.Due_Flag;
      P_ERR_MSG := V_INTF_CREDIT.Due_Result;
      P_BILL_ID := V_INTF_CREDIT.Bill_Id;
    end if;
  
    P_RESULT  := V_SEC_RESULT;
    P_ERR_MSG := V_SUCCESS;
  
    BEGIN
      --获取客户ID
      BEGIN
        SELECT T.CUSTOMER_ID
          INTO V_CUSTOMER_ID
          FROM T_CUSTOMER_HEADER T
         WHERE T.CUSTOMER_CODE = V_INTF_CREDIT.CUSTOMER_CODE;
      EXCEPTION
        WHEN OTHERS THEN
          P_RESULT  := -20000;
          P_ERR_MSG := SUBSTR('根据客户编码查不到相应客户信息！请检查！' || SQLERRM,
                              1,
                              240);
          GOTO HERE;
      END;
      --获取账户ID
      BEGIN
        SELECT T.ACCOUNT_ID
          INTO V_ACCOUNT_ID
          FROM T_CUSTOMER_ACCOUNT T
         WHERE t.entity_id = V_INTF_CREDIT.entity_id
           and T.CUSTOMER_CODE = V_INTF_CREDIT.CUSTOMER_CODE
           AND T.ACCOUNT_CODE = V_INTF_CREDIT.ACCOUNT_CODE;
      EXCEPTION
        WHEN OTHERS THEN
          P_RESULT  := -20000;
          P_ERR_MSG := SUBSTR('根据客户编码和账户编码查不到相应账户信息！请检查！' || SQLERRM,
                              1,
                              240);
          GOTO HERE;
      END;
    
      --------------------------------- tianmzh 修改 start ---------------------------------------------------
      --增加校验，账户状态为有效时，校验通过，否则校验不通过（即账户状态为冻结、无效时，校验不通过）
      V_ACCOUNT_STATUS := PKG_CUSTOMER_PUB.F_CHECK_CUST_HAVE_FREEZING_MSG('01',
                                                                          V_CUSTOMER_ID,
                                                                          V_INTF_CREDIT.ENTITY_ID,
                                                                          null,
                                                                          V_ACCOUNT_ID);
      IF V_ACCOUNT_STATUS <> 'SUCCESS' THEN
        P_RESULT  := -20000;
        P_ERR_MSG := SUBSTR(V_ACCOUNT_STATUS, 1, 240);
        GOTO HERE;
      END IF;
      --------------------------------- tianmzh 修改 end ---------------------------------------------------
    
      IF V_INTF_CREDIT.Delaypay_Type = 3 THEN
        null;
      ELSE
      
        --获取计划还款日期
        entityGroupCode := pkg_bd.F_GET_PARAMETER_VALUE('ar_entity_group',
                                                        V_INTF_CREDIT.Entity_Id,
                                                        null,
                                                        null);
        IF entityGroupCode = 'XSGS' THEN
          --家用事业部 
          --如果铺底单据为常规铺底，则需要校验是否交叉
          If V_INTF_CREDIT.bill_type_id = 1 Then
            --1：常规铺底
            Begin
              Select T.Bill_Num
                Into V_Bill_Num
                From T_Credit_Delaypay t
               Where T.Entity_Id = V_INTF_CREDIT.Entity_Id
                 And T.Customer_Code = V_INTF_CREDIT.Customer_Code
                 And T.Sales_Main_Type = V_INTF_CREDIT.Sales_Main_Type
                 And ((V_INTF_CREDIT.Requis_Date >= T.Requis_Date And
                     V_INTF_CREDIT.Requis_Date <= T.End_Date) Or
                     (V_INTF_CREDIT.End_Date >= T.Requis_Date And
                     V_INTF_CREDIT.End_Date <= T.End_Date))
                 And T.Bill_Status <> '5'
                 And T.Bill_Status <> '6'
                 And t.bill_type_id = V_INTF_CREDIT.bill_type_id
                 And t.delaypay_type = 1; --1:跨月
            Exception
              When Others Then
                Null;
            End;
            If V_Bill_Num Is Not Null Then
              P_RESULT  := -20000;
              P_ERR_MSG := SUBSTR('单据日期跟CIMS中单据日期交叉，对应单据号为【' || V_Bill_Num || '】！' ||
                                  SQLERRM,
                                  1,
                                  240);
              GOTO HERE;
            End If;
          End If;
          V_PLANPAY_DATE := last_day(V_INTF_CREDIT.end_date);
        Elsif entityGroupCode = 'JXS' THEN
          --厨电事业部
          Begin
            Select T.Bill_Num
              Into V_Bill_Num
              From T_Credit_Delaypay t
             Where T.Entity_Id = V_INTF_CREDIT.Entity_Id
               And T.Customer_Code = V_INTF_CREDIT.Customer_Code
               And T.Sales_Main_Type = V_INTF_CREDIT.Sales_Main_Type
               And ((V_INTF_CREDIT.Requis_Date >= T.Requis_Date And
                   V_INTF_CREDIT.Requis_Date <= T.End_Date) Or
                   (V_INTF_CREDIT.End_Date >= T.Requis_Date And
                   V_INTF_CREDIT.End_Date <= T.End_Date))
               And T.Bill_Status <> '5'
               And T.Bill_Status <> '6';
          Exception
            When Others Then
              Null;
          End;
        
          --如果单据编号不为空，则说明有cims有日期交叉单据存在
          If V_Bill_Num Is Not Null Then
            P_RESULT  := -20000;
            P_ERR_MSG := SUBSTR('单据日期跟CIMS中单据日期交叉，对应单据号为【' || V_Bill_Num || '】！' ||
                                SQLERRM,
                                1,
                                240);
            GOTO HERE;
          End If;
          V_PLANPAY_DATE := V_INTF_CREDIT.end_date;
        End If;
      End If;
      
      ---------------------------------2016-09-06 tianmzh 修改 start ---------------------------------------------------
      --三方铺底：CCS过来的铺底单信息，没有收款单号，需要根据三方承兑票号，获取收款单号，存入铺底行表
      IF V_INTF_CREDIT.MONEYORDER_NUMBER IS NOT NULL THEN
        BEGIN
          SELECT TH.CASH_RECEIPT_CODE
            INTO V_CASH_RECEIPT_CODE
            FROM CIMS.T_AR_CASH_RECEIPT_HEADERS TH,
                 CIMS.T_AR_RECEIPT_METHODS      TM
           WHERE TH.RECEIPT_STATUS_ID IN (3, 5, 6)
             AND TH.CASH_CODE = V_INTF_CREDIT.MONEYORDER_NUMBER
             AND TH.AMOUNT > 0
             AND TH.RECEIPT_METHOD_ID = TM.RECEIPT_METHOD_ID
             AND TM.RECEIPT_TYPE = '3';
        EXCEPTION
          WHEN OTHERS THEN
            P_RESULT  := -20000;
            P_ERR_MSG := SUBSTRB('根据三方承兑票号获取CIMS收款单号出错！请检查！' || SQLERRM,
                                 1,
                                 240);
        END;
      END IF;
      --------------------------------- tianmzh 修改 end ---------------------------------------------------
    
      --获取铺底单据ID（C-IMS）
      BEGIN
        SELECT s_credit_delaypay.nextval INTO V_BILL_ID FROM DUAL;
      EXCEPTION
        WHEN OTHERS THEN
          P_RESULT  := -20000;
          P_ERR_MSG := SUBSTRB('从序列获取铺底单据ID出错！请检查！' || SQLERRM,
                               1,
                               240);
          GOTO HERE;
      END;
    
      --获取铺底单据编码（C-IMS）
      BEGIN
        V_BILL_NUM_NEW := pkg_bd.F_GET_BILL_NO(P_BILL_TYPE  => 'CreditDelayBillNum',
                                               P_PREFIX_ADD => Null,
                                               P_ENTITY_ID  => V_INTF_CREDIT.entity_id,
                                               P_USER_ID    => Null);
      EXCEPTION
        WHEN OTHERS THEN
          P_RESULT  := -20000;
          P_ERR_MSG := SUBSTRB('从序列获取铺底单据编码出错！请检查！' || SQLERRM,
                               1,
                               240);
          GOTO HERE;
      END;
      
    
      --插入铺底单据信息
      BEGIN
        INSERT INTO t_credit_delaypay --铺底单据信息表
          (bill_id, --单据ID
           entity_id, --业务主体
           bill_num, --铺底单据号
           bill_status, --单据状态（1：制单；2：送审；3：已审；4：驳回；5：作废；6：强制到期）
           create_by, --制单人
           creation_time, --制单时间
           bill_date, --单据日期
           bill_type_id, --单据类型（1：常规铺底单据；2：超额铺底单据；3：临时铺底单据）
           customer_id, --客户ID
           customer_code, --客户编码
           customer_name, --客户名称
           account_id, --账户ID
           account_code, --账户编码
           account_name, --账户名称
           sales_center_id, --营销中心ID
           sales_center_code, --营销中心编码
           sales_center_name, --营销中心名称
           sales_region_id, --销售区域ID
           sales_region_code, --销售区域编码
           sales_region_name, --销售区域名称
           sales_main_type, --营销大类
           sales_year_id, --销售年度ID
           delaypay_type, --铺底类型（1：铺底（跨月）；2：铺底（不跨月）；3：三方铺底；4：折让铺底）
           requis_date, --申请日期
           end_date, --终止日期
           planpay_date, --还款日期
           requis_amount, --申请金额
           approval_amount, --审批金额
           moneyorder_number, --三方承兑票号
           deposit_cash, --保证金
           actualpay_date, --实际还款日期
           pay_date, --还清日期
           payed_flag, --是否还清（1：是；0：否）
           cancel_by, --作废人
           cancel_time, --作废时间
           due_by, --到期操作员
           due_time, --到期时间
           remark, --备注
           delay_flag, --是否延期（1：是；0：否）
           delay_date, --延期日期
           delay_amount, --延期金额
           delay_reson, --延期原因
           transaction_amount, --未核销金额
           bring_accrual_amount, --产生利息金额
           bring_accrual_days, --产生利息天数
           accrual_amount, --利息金额
           overdue_flag, --是否逾期（1：是；0：否）
           last_updated_by, --最后修改人
           last_update_date, --最后修改日期
           last_approval_time) --最终审批时间
        VALUES
          (V_BILL_ID, --单据ID
           V_INTF_CREDIT.ENTITY_ID, --业务主体
           --V_INTF_CREDIT.SOURCE_BILL_NUM,   --铺底单据号
           V_BILL_NUM_NEW, --铺底单据号
           V_INTF_CREDIT.BILL_STATUS, --单据状态（1：制单；2：送审；3：已审；4：驳回；5：作废；6：强制到期）
           V_INTF_CREDIT.CREATE_BY, --制单人
           V_INTF_CREDIT.CREATION_TIME, --制单时间
           V_INTF_CREDIT.BILL_DATE, --单据日期
           V_INTF_CREDIT.BILL_TYPE_ID, --单据类型（1：常规铺底单据；2：超额铺底单据；3：临时铺底单据）
           V_CUSTOMER_ID, --客户ID
           V_INTF_CREDIT.CUSTOMER_CODE, --客户编码
           V_INTF_CREDIT.CUSTOMER_NAME, --客户名称
           V_ACCOUNT_ID, --账户ID
           V_INTF_CREDIT.ACCOUNT_CODE, --账户编码
           V_INTF_CREDIT.ACCOUNT_NAME, --账户名称
           TO_NUMBER(FUN_GET_SALES_CENTER_INTO(V_INTF_CREDIT.ENTITY_ID,
                                               V_CUSTOMER_ID,
                                               V_ACCOUNT_ID,
                                               1)), --营销中心ID
           FUN_GET_SALES_CENTER_INTO(V_INTF_CREDIT.ENTITY_ID,
                                     V_CUSTOMER_ID,
                                     V_ACCOUNT_ID,
                                     2), --营销中心编码
           FUN_GET_SALES_CENTER_INTO(V_INTF_CREDIT.ENTITY_ID,
                                     V_CUSTOMER_ID,
                                     V_ACCOUNT_ID,
                                     3), --营销中心名称
           TO_NUMBER(FUN_GET_SALES_CENTER_INTO(V_INTF_CREDIT.ENTITY_ID,
                                               V_CUSTOMER_ID,
                                               V_ACCOUNT_ID,
                                               4)), --销售区域ID
           FUN_GET_SALES_CENTER_INTO(V_INTF_CREDIT.ENTITY_ID,
                                     V_CUSTOMER_ID,
                                     V_ACCOUNT_ID,
                                     5), --销售区域编码
           FUN_GET_SALES_CENTER_INTO(V_INTF_CREDIT.ENTITY_ID,
                                     V_CUSTOMER_ID,
                                     V_ACCOUNT_ID,
                                     6), --销售区域名称
           V_INTF_CREDIT.SALES_MAIN_TYPE, --营销大类
           NULL, --销售年度ID
           V_INTF_CREDIT.delaypay_type, --铺底类型（1：铺底（跨月）；2：铺底（不跨月）；3：三方铺底；4：折让铺底）
           V_INTF_CREDIT.REQUIS_DATE, --申请日期
           V_INTF_CREDIT.END_DATE, --终止日期
           V_PLANPAY_DATE, --还款日期
           V_INTF_CREDIT.REQUIS_AMOUNT, --申请金额
           NULL, --审批金额
           V_INTF_CREDIT.MONEYORDER_NUMBER, --三方承兑票号
           V_INTF_CREDIT.DEPOSIT_CASH, --保证金
           NULL, --实际还款日期
           NULL, --还清日期
           '0', --是否还清（1：是；0：否）
           NULL, --作废人
           NULL, --作废时间
           NULL, --到期操作员
           NULL, --到期时间
           '来源CCS，来源单号:' || V_INTF_CREDIT.SOURCE_BILL_NUM, --备注
           '0', --是否延期（1：是；0：否）
           NULL, --延期日期
           NULL, --延期金额
           NULL, --延期原因
           NULL, --未核销金额
           NULL, --产生利息金额
           NULL, --产生利息天数
           NULL, --利息金额
           NULL, --是否逾期（1：是；0：否）
           V_INTF_CREDIT.CREATE_BY, --最后修改人
           V_INTF_CREDIT.CREATION_TIME, --最后修改日期
           NULL --最终审批时间
           );
      
        P_BILL_ID := V_BILL_ID;
      EXCEPTION
        WHEN OTHERS THEN
          P_RESULT  := -20000;
          P_ERR_MSG := SUBSTR('向业务表插入铺底单据信息出错！请检查！' || SQLERRM,
                              1,
                              240);
          GOTO HERE;
      END;
      --检查是否有附件信息
      BEGIN
        SELECT COUNT(1)
          INTO V_COUNT
          FROM INTF_CREDIT_DELAYPAY_ATT T
         WHERE T.SOURCE_BILL_ID = V_INTF_CREDIT.SOURCE_BILL_ID;
      EXCEPTION
        WHEN OTHERS THEN
          P_RESULT  := -20000;
          P_ERR_MSG := SUBSTRB('查询接口铺底单据是否存在附件信息出错！请检查！' || SQLERRM,
                               1,
                               240);
          GOTO HERE;
      END;
      --插入附件信息
      IF V_COUNT > 0 THEN
        /*BEGIN
            INSERT INTO t_credit_delaypay_att -- 铺底附件信息表
              (att_id, --附件ID
               bill_id, --单据ID
               att_name, --附件名称
               att_size, --附件大小
               att_code, --附件编码
               att_path, --附件路径
               created_by, --创建人
               creation_date, --创建日期
               last_updated_by, --修改人
               last_update_date) --修改日期
              SELECT s_credit_delaypay_att.Nextval, --附件ID
                     V_BILL_ID, --单据ID
                     T.ATT_NAME, --附件名称
                     T.ATT_SIZE, --附件大小
                     T.ATT_CODE, --附件编码
                     T.ATT_PATH, --附件路径
                     V_INTF_CREDIT.CREATE_BY, --创建人
                     V_INTF_CREDIT.CREATION_TIME, --创建日期
                     V_INTF_CREDIT.CREATE_BY, --修改人
                     V_INTF_CREDIT.CREATION_TIME --修改日期
                FROM INTF_CREDIT_DELAYPAY_ATT T
               WHERE T.SOURCE_BILL_ID = V_INTF_CREDIT.SOURCE_BILL_ID;
        EXCEPTION WHEN OTHERS THEN
          P_RESULT := -20000 ;
          P_ERR_MSG := SUBSTR('向业务表插入铺底单据附件信息出错！请检查！'||SQLERRM,1,240) ;
          GOTO HERE ;
        END ;*/
        /*
             1.ID: 插入时使用序列，序列名称是SEQ_IMS_FILEINFO
        2.BUSINESS_ID:  表单ID
        3.BUSINESS_TYPE:  业务类型编码，对应表mdp_business_type 中的BUSINESS_CODE
        4.FILE_PATH: 文件存放的全路径，路径包含文件名称和文件后缀，如 /mdims_upload/invCode/201501/test.doc
           */
        BEGIN
          INSERT INTO IMS_FILEINFO_INTERFACE -- 铺底附件信息表
            (id,
             business_id,
             business_type,
             file_path,
             file_name,
             created_date,
             exc_date,
             exc_finish,
             fcount,
             remark) --修改日期
            SELECT SEQ_IMS_FILEINFO.Nextval, --附件ID
                   -- 2016-07-05 tianmzh修改，将原来附件business_id 为 'creditDP'+ V_BILL_NUM_NEW 
                   --V_BILL_ID, --单据ID
                   'creditDP' || V_BILL_NUM_NEW,
                   'creditDelayCode',
                   T.ATT_PATH, --附件路径
                   t.Att_Name, --附件名称
                   Sysdate, --创建日期
                   Null,
                   Null,
                   Null,
                   Null
              FROM INTF_CREDIT_DELAYPAY_ATT T
             WHERE T.SOURCE_BILL_ID = V_INTF_CREDIT.SOURCE_BILL_ID;
        EXCEPTION
          WHEN OTHERS THEN
            P_RESULT  := -20000;
            P_ERR_MSG := SUBSTR('向业务表插入铺底单据附件信息出错！请检查！' || SQLERRM,
                                1,
                                240);
            GOTO HERE;
        END;
      
        --------------------------------- tianmzh 修改 start -------------------------------------------------
        /*
        *  1、行表数据转头表数据；2、更新行表单据头ID；
        */
        BEGIN
          --获取头表主键序列
          SELECT S_CREDIT_DELAYPAY_HEAD.NEXTVAL INTO V_S_HEAD_ID FROM DUAL;
          --查询行表，插入头表
          INSERT INTO CIMS.T_CREDIT_DELAYPAY_HEAD H
            (BILL_HEAD_ID,
             BILL_NUM,
             ENTITY_ID,
             BILL_STATUS,
             CREATE_BY,
             CREATION_TIME,
             BILL_DATE,
             BILL_TYPE_ID,
             DELAYPAY_TYPE,
             REQUIS_DATE,
             END_DATE,
             PLANPAY_DATE,
             LAST_APPROVAL_TIME,
             HEAD_REMARK,
             VERSION,
             UPDATED_BY,
             UPDATED_TIME,
             APPENDIX_ID,
             SOURCE_SYS,
             SOURCE_CODE)
            SELECT V_S_HEAD_ID,
                   T.BILL_NUM,
                   T.ENTITY_ID,
                   T.BILL_STATUS,
                   T.CREATE_BY,
                   T.CREATION_TIME,
                   T.BILL_DATE,
                   T.BILL_TYPE_ID,
                   T.DELAYPAY_TYPE,
                   T.REQUIS_DATE,
                   T.END_DATE,
                   T.PLANPAY_DATE,
                   T.LAST_APPROVAL_TIME,
                   T.REMARK,
                   0,
                   T.LAST_UPDATED_BY,
                   T.LAST_UPDATE_DATE,
                   'creditDP' || T.BILL_NUM,
                   'CCS',
                   V_INTF_CREDIT.SOURCE_BILL_NUM
              FROM CIMS.T_CREDIT_DELAYPAY T
             WHERE T.BILL_ID = V_BILL_ID;
          --更新行表数据
          UPDATE CIMS.T_CREDIT_DELAYPAY TL
             SET TL.BILL_HEAD_ID = V_S_HEAD_ID
           WHERE TL.BILL_ID = V_BILL_ID;
        EXCEPTION
          WHEN OTHERS THEN
            P_RESULT  := -20000;
            P_ERR_MSG := SUBSTR('向业务头表插入铺底单据信息出错！请检查！' || SQLERRM,
                                1,
                                240);
            GOTO HERE;
        END;
        --------------------------------- tianmzh 修改 end ---------------------------------------------------
      
      END IF;
      --更新单据信息读取状态
      <<HERE>>
      UPDATE INTF_CREDIT_DELAYPAY T
         SET T.BILL_ID    = decode(P_RESULT, V_SEC_RESULT, V_BILL_ID),
             T.DUE_FLAG   = DECODE(P_RESULT,
                                   V_SEC_RESULT,
                                   V_SEC_RESULT,
                                   V_ERR_RESULT),
             T.DUE_RESULT = P_ERR_MSG
       WHERE T.SOURCE_BILL_ID = V_INTF_CREDIT.SOURCE_BILL_ID;
      UPDATE INTF_CREDIT_DELAYPAY_ATT T
         SET T.BILL_ID = decode(P_RESULT, V_SEC_RESULT, V_BILL_ID)
       WHERE T.SOURCE_BILL_ID = V_INTF_CREDIT.SOURCE_BILL_ID;
    EXCEPTION
      WHEN OTHERS THEN
        ROLLBACK;
        P_RESULT  := -20000;
        P_ERR_MSG := SUBSTR('读取铺底单据信息出错！请检查！' || SQLERRM,
                            1,
                            240);
        --更新单据信息读取状态
        UPDATE INTF_CREDIT_DELAYPAY T
           SET --T.BILL_ID = V_BILL_ID ,
                T.DUE_FLAG = V_ERR_RESULT,
               T.DUE_RESULT = P_ERR_MSG
         WHERE T.SOURCE_BILL_ID = V_INTF_CREDIT.SOURCE_BILL_ID;
    END;
  END; --

  --------------------------------------------------------------------------------
  /*
  *   创建日期：2015-03-27
  *     创建者：苏冬渊
  *   功能说明：处理小电铺底单据从接口表同步到业务表
  *
  *
  */
  -------------------------------------------------------------------------------
  /*PROCEDURE PRC_INTF_CREDIT_DELAYPAY(P_SOURCE_BILL_ID  In Number , --单据ID
                                     P_RESULT             IN OUT NUMBER, --返回错误ID
                                     P_ERR_MSG            IN OUT VARCHAR2 --返回错误信息
                                   ) IS
    \* V_CUSTOMER_ID T_CREDIT_DELAYPAY.CUSTOMER_ID%TYPE ;
     V_ACCOUNT_ID T_CREDIT_DELAYPAY.ACCOUNT_ID%TYPE ;
     V_COUNT NUMBER ;
     V_BILL_ID NUMBER ;
     V_PLANPAY_DATE T_CREDIT_DELAYPAY.PLANPAY_DATE%Type ; --计划还款日期
     entityGroupCode Varchar2(100) ; --主体组
     CURSOR CUR_CREDIT_DELAYPAY IS
       SELECT T.* FROM INTF_CREDIT_DELAYPAY T
       WHERE T.DUE_FLAG IS NULL ;*\
    row_credit_delaypay INTF_CREDIT_DELAYPAY%Rowtype ;
    V_BILL_ID NUMBER ;
    V_PLANPAY_DATE T_CREDIT_DELAYPAY.PLANPAY_DATE%Type ; --计划还款日期
    V_CUSTOMER_ID T_CREDIT_DELAYPAY.CUSTOMER_ID%TYPE ;
    V_ACCOUNT_ID T_CREDIT_DELAYPAY.ACCOUNT_ID%TYPE ;
    entityGroupCode Varchar2(100) ; --主体组
  BEGIN
     P_RESULT := V_SEC_RESULT ;
     P_ERR_MSG := V_SUCCESS ;
     
     --根据源单据ID获取接口单据信息
     Begin
       Select T.*
         Into Row_Credit_Delaypay
         From Intf_Credit_Delaypay t
        Where T.Source_Bill_Id = P_Source_Bill_Id 
         And T.BILL_ID Is Null ;
     Exception When Others Then
        P_RESULT := -20000 ;
        P_ERR_MSG := SUBSTR('根据源单据ID接口表中没找到相应的单据信息！' || SQLERRM,1,240) ;
        GOTO HERE ;
     End ;
     
     --根据接口单据信息获取客户ID，账户ID
     
        --获取客户ID
        BEGIN
          SELECT T.CUSTOMER_ID
            INTO V_CUSTOMER_ID
            FROM T_CUSTOMER_HEADER T
           WHERE T.CUSTOMER_CODE = Row_Credit_Delaypay.CUSTOMER_CODE;
        EXCEPTION WHEN OTHERS THEN
          P_RESULT := -20000 ;
          P_ERR_MSG := SUBSTR('根据客户编码查不到相应客户信息！请检查！' || SQLERRM,1,240) ;
          GOTO HERE ;
        END ;
         --获取账户ID
        BEGIN
          SELECT T.ACCOUNT_ID
            INTO V_ACCOUNT_ID
            FROM T_CUSTOMER_ACCOUNT T
           WHERE T.CUSTOMER_CODE = Row_Credit_Delaypay.CUSTOMER_CODE
             AND T.ACCOUNT_CODE = Row_Credit_Delaypay.ACCOUNT_CODE;
        EXCEPTION WHEN OTHERS THEN
          P_RESULT := -20000 ;
          P_ERR_MSG := SUBSTR('根据客户编码和账户编码查不到相应账户信息！请检查！'||SQLERRM,1,240) ;
          GOTO HERE ;
        END ;
        
        --获取计划还款日期
        entityGroupCode := pkg_bd.F_GET_PARAMETER_VALUE('ar_entity_group',Row_Credit_Delaypay.Entity_Id,null,null);
        IF entityGroupCode = 'XSGS' THEN --家用事业部
           V_PLANPAY_DATE := last_day(Row_Credit_Delaypay.end_date);
        Elsif entityGroupCode = 'JXS' THEN --厨电事业部
           V_PLANPAY_DATE := Row_Credit_Delaypay.end_date ;
        End If ;
        
        --获取铺底单据ID（C-IMS）
        BEGIN
         SELECT s_credit_delaypay.nextval INTO V_BILL_ID FROM DUAL ;
        EXCEPTION WHEN OTHERS THEN
          P_RESULT := -20000 ;
          P_ERR_MSG := SUBSTRB('从序列获取铺底单据ID出错！请检查！'||SQLERRM,1,240) ;
          GOTO HERE ;
        END ;
        --插入铺底单据信息
        BEGIN
        INSERT INTO t_credit_delaypay   --铺底单据信息表
          ( bill_id,   --单据ID
            entity_id,   --业务主体
            bill_num,   --铺底单据号
            bill_status,   --单据状态（1：制单；2：送审；3：已审；4：驳回；5：作废；6：强制到期）
            create_by,   --制单人
            creation_time,   --制单时间
            bill_date,   --单据日期
            bill_type_id,   --单据类型（1：常规铺底单据；2：超额铺底单据；3：临时铺底单据）
            customer_id,   --客户ID
            customer_code,  --客户编码
            customer_name,  --客户名称
            account_id,   --账户ID
            account_code,   --账户编码
            account_name,   --账户名称
            sales_center_id,   --营销中心ID
            sales_center_code,   --营销中心编码
            sales_center_name,   --营销中心名称
            sales_region_id,   --销售区域ID
            sales_region_code,   --销售区域编码
            sales_region_name,   --销售区域名称
            sales_main_type,   --营销大类
            sales_year_id,   --销售年度ID
            delaypay_type,   --铺底类型（1：铺底（跨月）；2：铺底（不跨月）；3：三方铺底；4：折让铺底）
            requis_date,   --申请日期
            end_date,   --终止日期
            planpay_date,   --还款日期
            requis_amount,   --申请金额
            approval_amount,   --审批金额
            moneyorder_number,   --三方承兑票号
            deposit_cash,   --保证金
            actualpay_date,   --实际还款日期
            pay_date,   --还清日期
            payed_flag,   --是否还清（1：是；0：否）
            cancel_by,   --作废人
            cancel_time,   --作废时间
            due_by,   --到期操作员
            due_time,   --到期时间
            remark,   --备注
            delay_flag,   --是否延期（1：是；0：否）
            delay_date,   --延期日期
            delay_amount,   --延期金额
            delay_reson,   --延期原因
            transaction_amount,   --未核销金额
            bring_accrual_amount,   --产生利息金额
            bring_accrual_days,   --产生利息天数
            accrual_amount,   --利息金额
            overdue_flag,   --是否逾期（1：是；0：否）
            last_updated_by,   --最后修改人
            last_update_date,   --最后修改日期
            last_approval_time)   --最终审批时间
     VALUES
          ( V_BILL_ID,   --单据ID
            Row_Credit_Delaypay.ENTITY_ID,   --业务主体
            Row_Credit_Delaypay.SOURCE_BILL_NUM,   --铺底单据号
            Row_Credit_Delaypay.BILL_STATUS,   --单据状态（1：制单；2：送审；3：已审；4：驳回；5：作废；6：强制到期）
            Row_Credit_Delaypay.CREATE_BY,   --制单人
            Row_Credit_Delaypay.CREATION_TIME,   --制单时间
            Row_Credit_Delaypay.BILL_DATE,   --单据日期
            Row_Credit_Delaypay.BILL_TYPE_ID,   --单据类型（1：常规铺底单据；2：超额铺底单据；3：临时铺底单据）
            V_CUSTOMER_ID,   --客户ID
            Row_Credit_Delaypay.CUSTOMER_CODE,   --客户编码
            Row_Credit_Delaypay.CUSTOMER_NAME,   --客户名称
            V_ACCOUNT_ID,   --账户ID
            Row_Credit_Delaypay.ACCOUNT_CODE,   --账户编码
            Row_Credit_Delaypay.ACCOUNT_NAME,   --账户名称
            TO_NUMBER(FUN_GET_SALES_CENTER_INTO(Row_Credit_Delaypay.ENTITY_ID,V_CUSTOMER_ID,V_ACCOUNT_ID,1)),   --营销中心ID
            FUN_GET_SALES_CENTER_INTO(Row_Credit_Delaypay.ENTITY_ID,V_CUSTOMER_ID,V_ACCOUNT_ID,2),   --营销中心编码
            FUN_GET_SALES_CENTER_INTO(Row_Credit_Delaypay.ENTITY_ID,V_CUSTOMER_ID,V_ACCOUNT_ID,3),   --营销中心名称
            TO_NUMBER(FUN_GET_SALES_CENTER_INTO(Row_Credit_Delaypay.ENTITY_ID,V_CUSTOMER_ID,V_ACCOUNT_ID,4)),   --销售区域ID
            FUN_GET_SALES_CENTER_INTO(Row_Credit_Delaypay.ENTITY_ID,V_CUSTOMER_ID,V_ACCOUNT_ID,5),   --销售区域编码
            FUN_GET_SALES_CENTER_INTO(Row_Credit_Delaypay.ENTITY_ID,V_CUSTOMER_ID,V_ACCOUNT_ID,6),   --销售区域名称
            Row_Credit_Delaypay.SALES_MAIN_TYPE,   --营销大类
            NULL,   --销售年度ID
            Row_Credit_Delaypay.delaypay_type,   --铺底类型（1：铺底（跨月）；2：铺底（不跨月）；3：三方铺底；4：折让铺底）
            Row_Credit_Delaypay.REQUIS_DATE,   --申请日期
            Row_Credit_Delaypay.END_DATE,   --终止日期
            V_PLANPAY_DATE,   --还款日期
            Row_Credit_Delaypay.REQUIS_AMOUNT,   --申请金额
            NULL,   --审批金额
            Row_Credit_Delaypay.MONEYORDER_NUMBER,   --三方承兑票号
            Row_Credit_Delaypay.DEPOSIT_CASH,   --保证金
            NULL,   --实际还款日期
            NULL,   --还清日期
            '0',   --是否还清（1：是；0：否）
            NULL,   --作废人
            NULL,   --作废时间
            NULL,   --到期操作员
            NULL,   --到期时间
            NULL,   --备注
            '0',   --是否延期（1：是；0：否）
            NULL,   --延期日期
            NULL,   --延期金额
            NULL,   --延期原因
            NULL,   --未核销金额
            NULL,   --产生利息金额
            NULL,   --产生利息天数
            NULL,   --利息金额
            NULL,   --是否逾期（1：是；0：否）
            Row_Credit_Delaypay.CREATE_BY,   --最后修改人
            Row_Credit_Delaypay.CREATION_TIME,   --最后修改日期
            NULL   --最终审批时间
             );
     EXCEPTION WHEN OTHERS Then
       Rollback ;
       P_RESULT := -20000 ;
       P_ERR_MSG := SUBSTR('向业务表插入铺底单据信息出错！请检查！'||SQLERRM,1,240) ;
       GOTO HERE ;
     END ;
     --检查是否有附件信息
     \*BEGIN
       SELECT COUNT(1) INTO V_COUNT FROM INTF_CREDIT_DELAYPAY_ATT T WHERE T.SOURCE_BILL_ID = Row_Credit_Delaypay.SOURCE_BILL_ID ;
     EXCEPTION WHEN OTHERS THEN
       P_RESULT := -20000 ;
       P_ERR_MSG := SUBSTRB('查询接口铺底单据是否存在附件信息出错！请检查！'||SQLERRM,1,240) ;
       GOTO HERE ;
     END ;
        --插入附件信息
     IF V_COUNT > 0 THEN
     BEGIN
       INSERT INTO t_credit_delaypay_att -- 铺底附件信息表
         (att_id, --附件ID
          bill_id, --单据ID
          att_name, --附件名称
          att_size, --附件大小
          att_code, --附件编码
          att_path, --附件路径
          created_by, --创建人
          creation_date, --创建日期
          last_updated_by, --修改人
          last_update_date) --修改日期
         SELECT s_credit_delaypay_att.Nextval, --附件ID
                V_BILL_ID, --单据ID
                T.ATT_NAME, --附件名称
                T.ATT_SIZE, --附件大小
                T.ATT_CODE, --附件编码
                T.ATT_PATH, --附件路径
                V_INTF_CREDIT.CREATE_BY, --创建人
                V_INTF_CREDIT.CREATION_TIME, --创建日期
                V_INTF_CREDIT.CREATE_BY, --修改人
                V_INTF_CREDIT.CREATION_TIME --修改日期
           FROM INTF_CREDIT_DELAYPAY_ATT T
          WHERE T.SOURCE_BILL_ID = V_INTF_CREDIT.SOURCE_BILL_ID;
   EXCEPTION WHEN OTHERS THEN
     P_RESULT := -20000 ;
     P_ERR_MSG := SUBSTR('向业务表插入铺底单据附件信息出错！请检查！'||SQLERRM,1,240) ;
     GOTO HERE ;
   END ;
   END IF ;*\
   --更新单据信息读取状态
   <<HERE>>
   BEGIN
   UPDATE INTF_CREDIT_DELAYPAY T SET T.BILL_ID = V_BILL_ID ,
                                       T.DUE_FLAG = DECODE(P_RESULT,V_SEC_RESULT,V_SEC_RESULT,V_ERR_RESULT),
                                       T.DUE_RESULT = P_ERR_MSG
                                       WHERE T.SOURCE_BILL_ID = Row_Credit_Delaypay.SOURCE_BILL_ID ;
   UPDATE INTF_CREDIT_DELAYPAY_ATT T
      SET T.BILL_ID = V_BILL_ID
    WHERE T.SOURCE_BILL_ID = Row_Credit_Delaypay.SOURCE_BILL_ID;
   EXCEPTION WHEN OTHERS THEN
     ROLLBACK ;
     P_RESULT := -20000 ;
     P_ERR_MSG := SUBSTR('读取铺底单据信息出错！请检查！'||SQLERRM,1,240) ;
     --更新单据信息读取状态
     UPDATE INTF_CREDIT_DELAYPAY T SET T.BILL_ID = V_BILL_ID ,
                                       T.DUE_FLAG = V_ERR_RESULT,
                                       T.DUE_RESULT = P_ERR_MSG
                                       WHERE T.SOURCE_BILL_ID = Row_Credit_Delaypay.SOURCE_BILL_ID ;
   END ;
  
  END; --PRC_INTF_CREDIT_DELAYPAY*/

  FUNCTION FUN_GET_SALES_CENTER_INTO(P_ENTITY_ID   NUMBER,
                                     P_CUSTOMER_ID NUMBER,
                                     p_ACCOUNT_ID  NUMBER,
                                     P_FLAG        NUMBER) RETURN VARCHAR2 IS
    V_STR VARCHAR2(4000) := '';
  BEGIN
    IF NVL(p_ACCOUNT_ID, -1) <> -1 THEN
      FOR I IN (SELECT A.*
                  FROM T_CUSTOMER_ORG A, T_CUSTOMER_ACC_ORG_RELATION B
                 WHERE A.ENTITY_ID = P_ENTITY_ID
                   AND A.CUSTOMER_ORG_ID = B.CUSTOMER_ORG_ID
                   AND A.CUSTOMER_ID = P_CUSTOMER_ID
                   AND B.ACCOUNT_ID = p_ACCOUNT_ID) LOOP
        IF P_FLAG = 1 THEN
          V_STR := V_STR || I.SALES_CENTER_ID;
        ELSIF P_FLAG = 2 THEN
          V_STR := V_STR || ',' || i.sales_center_code;
        ELSIF P_FLAG = 3 THEN
          V_STR := V_STR || ',' || i.sales_center_name;
        ELSIF P_FLAG = 4 THEN
          V_STR := V_STR || i.sales_region_id;
        ELSIF P_FLAG = 5 THEN
          V_STR := V_STR || ',' || i.sales_region_CODE;
        ELSIF P_FLAG = 6 THEN
          V_STR := V_STR || ',' || i.sales_center_name;
        ELSE
          V_STR := '';
        END IF;
      END LOOP;
    ELSE
      FOR I IN (SELECT A.*
                  FROM T_CUSTOMER_ORG A, T_CUSTOMER_ACC_ORG_RELATION B
                 WHERE A.ENTITY_ID = P_ENTITY_ID
                   AND A.CUSTOMER_ORG_ID = B.CUSTOMER_ORG_ID
                   AND A.CUSTOMER_ID = P_CUSTOMER_ID) LOOP
        IF P_FLAG = 1 AND nvl(INSTR(V_STR, I.SALES_CENTER_ID), 0) = 0 THEN
          V_STR := V_STR || I.SALES_CENTER_ID;
        ELSIF P_FLAG = 2 AND nvl(INSTR(V_STR, I.sales_center_code), 0) = 0 THEN
          V_STR := V_STR || ',' || i.sales_center_code;
        ELSIF P_FLAG = 3 AND nvl(INSTR(V_STR, I.sales_center_name), 0) = 0 THEN
          V_STR := V_STR || ',' || i.sales_center_name;
        ELSIF P_FLAG = 4 AND nvl(INSTR(V_STR, I.sales_region_id), 0) = 0 THEN
          V_STR := V_STR || i.sales_region_id;
        ELSIF P_FLAG = 5 AND nvl(INSTR(V_STR, I.sales_region_CODE), 0) = 0 THEN
          V_STR := V_STR || ',' || i.sales_region_CODE;
        ELSIF P_FLAG = 6 AND nvl(INSTR(V_STR, I.SALES_REGION_CODE), 0) = 0 THEN
          V_STR := V_STR || ',' || i.SALES_REGION_CODE;
        ELSE
          V_STR := V_STR || '';
        END IF;
      END LOOP;
    END IF;
    IF P_FLAG IN (2, 3, 4, 5, 6) THEN
      V_STR := SUBSTR(V_STR, 2);
    END IF;
    RETURN V_STR;
  END;

  FUNCTION FUN_GET_ENTITY_DELAYPAY RETURN C_ENTITY_DELAYPAY_TYPE
    PIPELINED IS
    ROW_ENTITY_DELAYPAY_TYPE R_ENTITY_DELAYPAY_TYPE;
  BEGIN
  
    --家用关系处理
    For I In (Select 10           entity_id,
                     a.code_value delaypay_bill_code,
                     a.code_name  delaypay_bill_name,
                     b.code_value delaypay_code,
                     b.code_name  delaypay_name
                From UP_CODELIST A, UP_CODELIST B
               Where A.CODETYPE = 'credit_bill_type'
                 And b.codetype = 'credit_delaypay_type') Loop
    
      If (i.delaypay_bill_code In ('1', '2') And i.delaypay_code < 3) Or
         (i.delaypay_bill_code = '3' And i.delaypay_code > 3) Then
        ROW_ENTITY_DELAYPAY_TYPE.ENTITY_ID          := i.entity_id;
        ROW_ENTITY_DELAYPAY_TYPE.DELAYPAY_BILL_CODE := i.delaypay_bill_code;
        ROW_ENTITY_DELAYPAY_TYPE.DELAYPAY_BILL_NAME := I.DELAYPAY_BILL_NAME;
        ROW_ENTITY_DELAYPAY_TYPE.DELAYPAY_CODE      := I.DELAYPAY_CODE;
        ROW_ENTITY_DELAYPAY_TYPE.DELAYPAY_NAME      := I.DELAYPAY_NAME;
        pipe row(ROW_ENTITY_DELAYPAY_TYPE);
      End If;
    
    End Loop;
  
    --厨电关系处理
    For I In (Select 14           entity_id,
                     a.code_value delaypay_bill_code,
                     a.code_name  delaypay_bill_name,
                     b.code_value delaypay_code,
                     b.code_name  delaypay_name
                From UP_CODELIST A, UP_CODELIST B
               Where A.CODETYPE = 'credit_bill_type'
                 And b.codetype = 'credit_delaypay_type') Loop
    
      If (i.delaypay_bill_code In ('1', '2') And i.delaypay_code < 3) Or
         (i.delaypay_bill_code = '3' And i.delaypay_code > 3) Then
        ROW_ENTITY_DELAYPAY_TYPE.ENTITY_ID          := i.entity_id;
        ROW_ENTITY_DELAYPAY_TYPE.DELAYPAY_BILL_CODE := i.delaypay_bill_code;
        ROW_ENTITY_DELAYPAY_TYPE.DELAYPAY_BILL_NAME := I.DELAYPAY_BILL_NAME;
        ROW_ENTITY_DELAYPAY_TYPE.DELAYPAY_CODE      := I.DELAYPAY_CODE;
        ROW_ENTITY_DELAYPAY_TYPE.DELAYPAY_NAME      := I.DELAYPAY_NAME;
        pipe row(ROW_ENTITY_DELAYPAY_TYPE);
      End If;
    
    End Loop;
    RETURN;
  END;

end PKG_CREDIT_INTF_DUE;
/

