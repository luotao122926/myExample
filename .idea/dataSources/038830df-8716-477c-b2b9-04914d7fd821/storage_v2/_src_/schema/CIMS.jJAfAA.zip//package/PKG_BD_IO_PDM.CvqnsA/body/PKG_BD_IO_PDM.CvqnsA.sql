create PACKAGE BODY      PKG_BD_IO_PDM IS

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-04-21
  *     创建者：杨福伟
  *   功能说明：PDM产品同步于CIMS
  */
  -------------------------------------------------------------------------------
  procedure P_SYNC_PDM_ITEM(P_ENTITY      number, --主体
                            P_USER        varchar2, --用户
                            P_RETURN_CODE out varchar2, --返回编码
                            P_RETURN_MSG  out varchar2 --返回提示信息
                            ) IS
    ERROR_DESC    varchar2(1000) := '';
    LAST_DATE     varchar2(30) := '';
    P_UPDATE_TIME varchar2(30) := '';
    P_UNIT varchar2(30) := '';--单位
    EXIST_T_ITEM  number := 0;
    EXIST_ITEM    number := 0;
    upd_count     number := 0;--更新产品接口表数据量
    ins_count     number := 0;--插入接口表数据量
    unit_count    number := 0;--单位是否存在

    PURCHASE_F       T_BD_ITEM.Purchase_Flag%TYPE := 'Y';--采购使用标志PURCHASE_FLAG
    SALE_F           T_BD_ITEM.Sale_Flag%TYPE := 'Y';--销售使用标志SALE_FLAG
    INVOICE_F        T_BD_ITEM.Invoice_Flag%TYPE := 'Y';--发票使用标志INVOICE_FLAG
    PLAN_F           T_BD_ITEM.Plan_Flag%TYPE := 'Y';--计划使用标志PLAN_FLAG
    INVSTRAN_F       T_BD_ITEM.Invstran_Flag%TYPE := 'Y';--库存事务使用标志INVSTRAN_FLAG
    ATSALE_F         T_BD_ITEM.Atsale_Flag%TYPE := 'Y';--是否在产在销ATSALE_FLAG
    ORG_ACTIVITY_F   T_BD_ITEM.Productphase%TYPE := 'ACTIVITY';--生命周期ORG_ACTIVITY_STATUS


  BEGIN
    SAVEPOINT SP;
    P_RETURN_CODE := 'OK';
    P_RETURN_MSG  := 'PDM产品物料信息引入:';

    -- 获取同步时间
    select l.default_value
      into P_UPDATE_TIME
      from t_bd_param_list l
     where l.module_code = 'product'
       and l.param_code = 'SYNC_PDM_ITEM_TIME';

    FOR ITEM IN (SELECT distinct itemdesc,itemunit,itemcode,updatetime
                   FROM pdm_cpcitempdmbycims B
                  WHERE B.updatetime > P_UPDATE_TIME
                  order by B.updatetime asc) LOOP

      -- 单位处理
      select count(*) into unit_count from cims.v_up_codelist aa where aa.CODETYPE ='BD_UOM' and aa.CODE_NAME=item.itemunit;
      if unit_count > 0 then
        select aa.CODE_VALUE into P_UNIT from cims.v_up_codelist aa where aa.CODETYPE ='BD_UOM' and aa.CODE_NAME=item.itemunit;
      else
        P_UNIT := item.itemunit;
      end if;


      -- 是否存在产品
      select count(*)
        into EXIST_ITEM
        from INTF_BD_ITEM i
       where i.item_code = item.itemcode
         and i.entity_id = P_ENTITY;

      -- 已经引入，则更新
      if EXIST_ITEM > 0 then
        -- 是否存在产品
        select count(*)
          into EXIST_T_ITEM
          from t_bd_item i
         where i.item_code = item.itemcode
           and i.entity_id = P_ENTITY;

        -- 已经引入，则更新
        if EXIST_T_ITEM > 0 then
          --更新产品表t_bd_item
          update t_bd_item i
             set i.item_name        = item.itemdesc,
                 i.productdesc      = item.itemdesc,
                 i.defaultunit      = P_UNIT,
                 i.last_updated_by  = P_USER,
                 i.last_update_date = sysdate
           where i.item_code = item.itemcode
             and i.entity_id = P_ENTITY;
        end if;

        -- 数据插入历史记录接口表 intf_bd_item_his
        insert into intf_bd_item_his
          (ID,
           ITEM_CODE,
           ITEM_NAME,
           PRODUCTDESC,
           DEFAULTUNIT,
           SUBMIT_STATUS,
           ACTIVE_FLAG,
           IS_MATERIAL,
           PRODUCTFORM,
           ENTITY_ID,
           PURCHASE_FLAG,
           SALE_FLAG,
           INVOICE_FLAG,
           PLAN_FLAG,
           INVSTRAN_FLAG,
           ATSALE_FLAG,
           PRODUCTPHASE,
           CREATED_BY,
           CREATION_DATE,
           LAST_UPDATED_BY,
           LAST_UPDATE_DATE)
          select seq_bd_intf_id.NEXTVAL,
                 item.itemcode,
                 item.itemdesc,
                 item.itemdesc,
                 P_UNIT,
                 'N',
                 'Y',
                 'W',
                 'WL_MATERIEL',
                 P_ENTITY,
                 PURCHASE_F,
                 SALE_F,
                 INVOICE_F,
                 PLAN_F,
                 INVSTRAN_F,
                 ATSALE_F,
                 ORG_ACTIVITY_F,
                 P_USER,
                 sysdate,
                 P_USER,
                 sysdate
            from DUAL;

        --更新产品接口表intf_bd_item
        update intf_bd_item t
           set t.item_name        = item.itemdesc,
               t.productdesc      = item.itemdesc,
               t.defaultunit      = P_UNIT,
               t.last_updated_by  = P_USER,
               t.last_update_date = sysdate
         where t.item_code = item.itemcode
           and t.entity_id = P_ENTITY;

        upd_count := upd_count + 1;

      else
        -- 未引入，则数据插入接口表 intf_bd_item_his
        insert into intf_bd_item_his
          (ID,
           ITEM_CODE,
           ITEM_NAME,
           PRODUCTDESC,
           DEFAULTUNIT,
           SUBMIT_STATUS,
           ACTIVE_FLAG,
           IS_MATERIAL,
           PRODUCTFORM,
           ENTITY_ID,
           PURCHASE_FLAG,
           SALE_FLAG,
           INVOICE_FLAG,
           PLAN_FLAG,
           INVSTRAN_FLAG,
           ATSALE_FLAG,
           PRODUCTPHASE,
           CREATED_BY,
           CREATION_DATE,
           LAST_UPDATED_BY,
           LAST_UPDATE_DATE)
          select seq_bd_intf_id.NEXTVAL,
                 item.itemcode,
                 item.itemdesc,
                 item.itemdesc,
                 P_UNIT,
                 'N',
                 'Y',
                 'W',
                 'WL_MATERIEL',
                 P_ENTITY,
                 PURCHASE_F,
                 SALE_F,
                 INVOICE_F,
                 PLAN_F,
                 INVSTRAN_F,
                 ATSALE_F,
                 ORG_ACTIVITY_F,
                 P_USER,
                 sysdate,
                 P_USER,
                 sysdate
            from DUAL;

        -- 未引入，则数据插入接口表 intf_bd_item
        insert into intf_bd_item
          (ITEM_ID,
           ITEM_CODE,
           ITEM_NAME,
           PRODUCTDESC,
           DEFAULTUNIT,
           SUBMIT_STATUS,
           ACTIVE_FLAG,
           IS_MATERIAL,
           PRODUCTFORM,
           ENTITY_ID,
           PURCHASE_FLAG,
           SALE_FLAG,
           INVOICE_FLAG,
           PLAN_FLAG,
           INVSTRAN_FLAG,
           ATSALE_FLAG,
           PRODUCTPHASE,
           CREATED_BY,
           CREATION_DATE,
           LAST_UPDATED_BY,
           LAST_UPDATE_DATE)
          select seq_bd_row_id.NEXTVAL,
                 item.itemcode,
                 item.itemdesc,
                 item.itemdesc,
                 P_UNIT,
                 'N',
                 'Y',
                 'W',
                 'WL_MATERIEL',
                 P_ENTITY,
                 PURCHASE_F,
                 SALE_F,
                 INVOICE_F,
                 PLAN_F,
                 INVSTRAN_F,
                 ATSALE_F,
                 ORG_ACTIVITY_F,
                 P_USER,
                 sysdate,
                 P_USER,
                 sysdate
            from DUAL;

        ins_count := ins_count + 1;
      end if;

      if item.updatetime > LAST_DATE or LAST_DATE is NULL then
        LAST_DATE := item.updatetime; --记录下次比较的日期
      end if;

    END LOOP;

    -- 更新系统时间
    if LAST_DATE is not NULL then
      update t_bd_param_list t
         set t.default_value = LAST_DATE
       where t.module_code = 'product'
         and t.param_code = 'SYNC_PDM_ITEM_TIME';
    end if;

    P_RETURN_MSG := P_RETURN_MSG || '更新产品物料信息' || upd_count ||
                    '条,新增加产品物料信息' || ins_count || '条.';
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK TO SAVEPOINT SP;
      ERROR_DESC    := SQLERRM;
      P_RETURN_CODE := 'FAIL';
      P_RETURN_MSG  := '同步PDM产品信息失败:' || ERROR_DESC;
  END;

END PKG_BD_IO_PDM;
/

