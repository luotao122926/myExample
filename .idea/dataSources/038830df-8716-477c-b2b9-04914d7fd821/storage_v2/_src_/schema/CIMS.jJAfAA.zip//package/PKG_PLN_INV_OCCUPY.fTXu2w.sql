create Package      Pkg_Pln_Inv_Occupy Is
  /*----------------------------------------------------------------
  *         包：PKG_PLN_INV_OCCUPY
  *   创建日期：2014-06-24
  *     创建者：李振
  *   功能说明：处理订单管理的定制机库存占用增加及占用减少
  *             订单库存占用重算
  *
  *   过程成功：P_RESULT = 0
  *             P_ERR_MSG = 'SUCCESS';
  *
  *   过程失败：P_RESULT < -20000;
  *             P_ERR_MSG = 过程异常失败的提示信息
  *
  */ ----------------------------------------------------------------

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-06-24
  *     创建者：李振
  *   功能说明：处理订单管理的定制机库存占用增加
  *             该过程只处理散件
  *             P_SOURCE开头的参数只做历史记录查询
  *             P_ORIGIN开头的参数占用数据来源单据，占用数据计算条件
  */
  -------------------------------------------------------------------------------
  Procedure p_Occupy_Stocks(p_Inventory_Id      In Number, --仓库ID
                            p_Item_Id           In Number, --产品ID
                            p_Occupy_Qty        In Number, --占用数量
                            p_Match_Pln_To_Wip  In Varchar2, --工单与订单完全匹配标志 Y:完全匹配  N:非完全匹配
                            p_Operation_Type    In Varchar2, --操作类型(01:库存评审  02:中转入库  03:销售开单  04:杂项(含：41:破损调拨、42:盘盈亏、43:采购退货、44:其它))
                            p_Action_Desc       In Varchar2, --单据操作描述 例：中转单据执行、中转红冲单执行
                            p_Entity_Id         In Number, --主体ID
                            p_Origin_Type       In Varchar2, --来源类型
                            p_Origin_Head_Id    In Number, --来源头ID
                            p_Origin_Number     In Varchar2, --来源头编码
                            p_Origin_Line_Id    In Number, --来源行ID
                            p_Source_Order_Type In Varchar2, --事务来源单据类型
                            p_Source_Head_Id    In Number, --事务来源头ID
                            p_Source_Number     In Varchar2, --事务来源头编码
                            p_Source_Line_Id    In Number, --事务来源行ID
                            p_User_Code         In Varchar2, --用户ID
                            p_Result            In Out Number, --返回错误ID
                            p_Err_Msg           In Out Varchar2 --返回错误信息
                            );

  -------------------------------------------------------------------------------
  /*
   *  创建日期：2014-06-24
  *     创建者：李振
  *   功能说明：处理订单管理的定制机库存占用减少，
  *             该过程只处理散件
  *             P_SOURCE开头的参数只做历史记录查询
  *             P_ORIGIN开头的参数占用数据来源单据，占用数据计算条件
  */
  -------------------------------------------------------------------------------
  Procedure p_Unoccupy_Stocks(p_Inventory_Id      In Number, --仓库ID
                              p_Item_Id           In Number, --产品ID
                              p_Occupy_Qty        In Number, --占用数量
                              p_Match_Pln_To_Wip  In Varchar2, --工单与订单完全匹配标志
                              p_Operation_Type    In Varchar2, --操作类型(01:库存评审  02:中转入库  03:销售开单  04:杂项(含：41:破损调拨、42:盘盈亏、43:采购退货、44:其它))
                              p_Action_Desc       In Varchar2, --单据操作描述 例：中转单据执行、中转红冲单执行
                              p_Entity_Id         In Number, --主体ID
                              p_Origin_Type       In Varchar2, --来源类型
                              p_Origin_Head_Id    In Number, --来源头ID
                              p_Origin_Number     In Varchar2, --来源头编码
                              p_Origin_Line_Id    In Number, --来源行ID
                              p_Source_Order_Type In Varchar2, --事务来源单据类型
                              p_Source_Head_Id    In Number, --事务来源头ID
                              p_Source_Number     In Varchar2, --事务来源头编码
                              p_Source_Line_Id    In Number, --事务来源行ID
                              p_User_Code         In Varchar2, --用户ID
                              p_Allow_No_Occupy   In Varchar2, --是否允许没有锁定（Y/N，Y则对于没找到对应的锁定记录则不作任何处理）
                              p_Result            In Out Number, --返回错误ID
                              p_Err_Msg           In Out Varchar2 --返回错误信息
                              );

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-06-24
  *     创建者：李振
  *   功能说明：处理订单管理的定制机库存占用增加
  *             该过程只处理散件，如果传入的商品为套件则使用递归算法
  *             P_MATCH_PLN_TO_WIP 参数可传入3个值分别为：Y:订单与工单完全匹配  N:定制机锁定，工单随机匹配订单  O:其它模块占用库存
  *             P_SOURCE开头的参数只做历史记录查询
  *             P_ORIGIN开头的参数占用数据来源单据，占用数据计算条件
  */
  -------------------------------------------------------------------------------
  Procedure p_Into_Occupy_Stocks(p_Inventory_Id      In Number, --仓库ID
                                 p_Item_Id           In Number, --产品ID
                                 p_Occupy_Qty        In Number, --占用数量
                                 p_Match_Pln_To_Wip  In Varchar2, --工单与订单完全匹配标志 Y:完全匹配  N:非完全匹配
                                 p_Operation_Type    In Varchar2, --操作类型(01:库存评审  02:中转入库  03:销售开单  04:杂项(含：41:破损调拨、42:盘盈亏、43:采购退货、44:其它))
                                 p_Action_Desc       In Varchar2, --单据操作描述 例：中转单据执行、中转红冲单执行
                                 p_Entity_Id         In Number, --主体ID
                                 p_Origin_Type       In Varchar2, --来源类型
                                 p_Origin_Head_Id    In Number, --来源头ID
                                 p_Origin_Number     In Varchar2, --来源头编码
                                 p_Origin_Line_Id    In Number, --来源行ID
                                 p_Source_Order_Type In Varchar2, --事务来源单据类型
                                 p_Source_Head_Id    In Number, --事务来源头ID
                                 p_Source_Number     In Varchar2, --事务来源头编码
                                 p_Source_Line_Id    In Number, --事务来源行ID
                                 p_User_Code         In Varchar2, --用户ID
                                 p_Result            In Out Number, --返回错误ID
                                 p_Err_Msg           In Out Varchar2 --返回错误信息
                                 );

  -------------------------------------------------------------------------------
  /*
   *  创建日期：2014-06-24
  *     创建者：李振
  *   功能说明：处理订单管理的定制机库存占用减少，
  *             该过程只处理散件，如果传入的商品为套件则使用递归算法
  *             P_SOURCE开头的参数只做历史记录查询
  *             P_ORIGIN开头的参数占用数据来源单据，占用数据计算条件
  */
  -------------------------------------------------------------------------------
  Procedure p_Into_Unoccupy_Stocks(p_Inventory_Id      In Number, --仓库ID
                                   p_Item_Id           In Number, --产品ID
                                   p_Occupy_Qty        In Number, --占用数量
                                   p_Match_Pln_To_Wip  In Varchar2, --工单与订单完全匹配标志
                                   p_Operation_Type    In Varchar2, --操作类型(01:库存评审  02:中转入库  03:销售开单  04:杂项(含：41:破损调拨、42:盘盈亏、43:采购退货、44:其它))
                                   p_Action_Desc       In Varchar2, --单据操作描述 例：中转单据执行、中转红冲单执行
                                   p_Entity_Id         In Number, --主体ID
                                   p_Origin_Type       In Varchar2, --来源类型
                                   p_Origin_Head_Id    In Number, --来源头ID
                                   p_Origin_Number     In Varchar2, --来源头编码
                                   p_Origin_Line_Id    In Number, --来源行ID
                                   p_Source_Order_Type In Varchar2, --事务来源单据类型
                                   p_Source_Head_Id    In Number, --事务来源头ID
                                   p_Source_Number     In Varchar2, --事务来源头编码
                                   p_Source_Line_Id    In Number, --事务来源行ID
                                   p_User_Code         In Varchar2, --用户ID
                                   p_Allow_No_Occupy   In Varchar2, --是否允许没有锁定（Y/N，Y则对于没找到对应的锁定记录则不作任何处理）
                                   p_Result            In Out Number, --返回错误ID
                                   p_Err_Msg           In Out Varchar2 --返回错误信息
                                   );

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-06-24
  *     创建者：李振
  *   功能说明：处理订单管理的库存评审定制机库存占用增加
  */
  -------------------------------------------------------------------------------
  Procedure p_Affirm_Occupy_Stocks(p_Inventory_Id     In Number, --仓库ID
                                   p_Item_Id          In Number, --产品ID
                                   p_Occupy_Qty       In Number, --占用数量
                                   p_Match_Pln_To_Wip In Varchar2, --工单与订单完全匹配标志 Y:完全匹配  N:非完全匹配
                                   --P_OPERATION_TYPE    IN VARCHAR2, --操作类型(01:库存评审  02:中转入库  03:销售开单  04:杂项(含：41:破损调拨、42:盘盈亏、43:采购退货、44:其它))
                                   p_Action_Desc       In Varchar2, --单据操作描述 例：中转单据执行、中转红冲单执行
                                   p_Entity_Id         In Number, --主体ID
                                   p_Origin_Type       In Varchar2, --来源类型
                                   p_Origin_Head_Id    In Number, --来源头ID
                                   p_Origin_Number     In Varchar2, --来源头编码
                                   p_Origin_Line_Id    In Number, --来源行ID
                                   p_Source_Order_Type In Varchar2, --事务来源单据类型
                                   p_Source_Head_Id    In Number, --事务来源头ID
                                   p_Source_Number     In Varchar2, --事务来源头编码
                                   p_Source_Line_Id    In Number, --事务来源行ID
                                   p_User_Code         In Varchar2, --用户ID
                                   p_Result            In Out Number, --返回错误ID
                                   p_Err_Msg           In Out Varchar2 --返回错误信息
                                   );

  -------------------------------------------------------------------------------
  /*  创建日期：2014-06-24
  *     创建者：李振
  *   功能说明：处理订单管理的取消库存评审定制机库存占用减少，
  */ -----------------------------------------------------------------------------
  Procedure p_Affirm_Unoccupy_Stocks(p_Inventory_Id     In Number, --仓库ID
                                     p_Item_Id          In Number, --产品ID
                                     p_Occupy_Qty       In Number, --占用数量
                                     p_Match_Pln_To_Wip In Varchar2, --工单与订单完全匹配标志
                                     --P_OPERATION_TYPE    IN VARCHAR2, --操作类型(01:库存评审  02:中转入库  03:销售开单  04:杂项(含：41:破损调拨、42:盘盈亏、43:采购退货、44:其它))
                                     p_Action_Desc       In Varchar2, --单据操作描述 例：中转单据执行、中转红冲单执行
                                     p_Entity_Id         In Number, --主体ID
                                     p_Origin_Type       In Varchar2, --来源类型
                                     p_Origin_Head_Id    In Number, --来源头ID
                                     p_Origin_Number     In Varchar2, --来源头编码
                                     p_Origin_Line_Id    In Number, --来源行ID
                                     p_Source_Order_Type In Varchar2, --事务来源单据类型
                                     p_Source_Head_Id    In Number, --事务来源头ID
                                     p_Source_Number     In Varchar2, --事务来源头编码
                                     p_Source_Line_Id    In Number, --事务来源行ID
                                     p_User_Code         In Varchar2, --用户ID
                                     p_Allow_No_Occupy   In Varchar2, --是否允许没有锁定（Y/N，Y则对于没找到对应的锁定记录则不作任何处理）
                                     p_Result            In Out Number, --返回错误ID
                                     p_Err_Msg           In Out Varchar2 --返回错误信息
                                     );

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-06-24
  *     创建者：李振
  *   功能说明：处理订单管理的中转采购入库定制机库存占用增加
  */
  -------------------------------------------------------------------------------
  Procedure p_Supply_Occupy_Stocks(p_Inventory_Id     In Number, --仓库ID
                                   p_Item_Id          In Number, --产品ID
                                   p_Occupy_Qty       In Number, --占用数量
                                   p_Match_Pln_To_Wip In Varchar2, --工单与订单完全匹配标志 Y:完全匹配  N:非完全匹配
                                   --P_OPERATION_TYPE    IN VARCHAR2, --操作类型(01:库存评审  02:中转入库  03:销售开单  04:杂项(含：41:破损调拨、42:盘盈亏、43:采购退货、44:其它))
                                   p_Action_Desc       In Varchar2, --单据操作描述 例：中转单据执行、中转红冲单执行
                                   p_Entity_Id         In Number, --主体ID
                                   p_Origin_Type       In Varchar2, --来源类型
                                   p_Origin_Head_Id    In Number, --来源头ID
                                   p_Origin_Number     In Varchar2, --来源头编码
                                   p_Origin_Line_Id    In Number, --来源行ID
                                   p_Source_Order_Type In Varchar2, --事务来源单据类型
                                   p_Source_Head_Id    In Number, --事务来源头ID
                                   p_Source_Number     In Varchar2, --事务来源头编码
                                   p_Source_Line_Id    In Number, --事务来源行ID
                                   p_User_Code         In Varchar2, --用户ID
                                   p_Result            In Out Number, --返回错误ID
                                   p_Err_Msg           In Out Varchar2 --返回错误信息
                                   );

  -------------------------------------------------------------------------------
  /*  创建日期：2014-06-24
  *     创建者：李振
  *   功能说明：处理订单管理的采购中转单红冲定制机库存占用减少，
  */ -----------------------------------------------------------------------------
  Procedure p_Supply_Unoccupy_Stocks(p_Inventory_Id     In Number, --仓库ID
                                     p_Item_Id          In Number, --产品ID
                                     p_Occupy_Qty       In Number, --占用数量
                                     p_Match_Pln_To_Wip In Varchar2, --工单与订单完全匹配标志
                                     --P_OPERATION_TYPE    IN VARCHAR2, --操作类型(01:库存评审  02:中转入库  03:销售开单  04:杂项(含：41:破损调拨、42:盘盈亏、43:采购退货、44:其它))
                                     p_Action_Desc       In Varchar2, --单据操作描述 例：中转单据执行、中转红冲单执行
                                     p_Entity_Id         In Number, --主体ID
                                     p_Origin_Type       In Varchar2, --来源类型
                                     p_Origin_Head_Id    In Number, --来源头ID
                                     p_Origin_Number     In Varchar2, --来源头编码
                                     p_Origin_Line_Id    In Number, --来源行ID
                                     p_Source_Order_Type In Varchar2, --事务来源单据类型
                                     p_Source_Head_Id    In Number, --事务来源头ID
                                     p_Source_Number     In Varchar2, --事务来源头编码
                                     p_Source_Line_Id    In Number, --事务来源行ID
                                     p_User_Code         In Varchar2, --用户ID
                                     p_Allow_No_Occupy   In Varchar2, --是否允许没有锁定（Y/N，Y则对于没找到对应的锁定记录则不作任何处理）
                                     p_Result            In Out Number, --返回错误ID
                                     p_Err_Msg           In Out Varchar2 --返回错误信息
                                     );

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-06-24
  *     创建者：李振
  *   功能说明：处理订单管理的销售开单定制机库存占用增加
  */
  -------------------------------------------------------------------------------
  Procedure p_Soorder_Occupy_Stocks(p_Inventory_Id     In Number, --仓库ID
                                    p_Item_Id          In Number, --产品ID
                                    p_Occupy_Qty       In Number, --占用数量
                                    p_Match_Pln_To_Wip In Varchar2, --工单与订单完全匹配标志 Y:完全匹配  N:非完全匹配
                                    --P_OPERATION_TYPE    IN VARCHAR2, --操作类型(01:库存评审  02:中转入库  03:销售开单  04:杂项(含：41:破损调拨、42:盘盈亏、43:采购退货、44:其它))
                                    p_Action_Desc       In Varchar2, --单据操作描述 例：中转单据执行、中转红冲单执行
                                    p_Entity_Id         In Number, --主体ID
                                    p_Origin_Type       In Varchar2, --来源类型
                                    p_Origin_Head_Id    In Number, --来源头ID
                                    p_Origin_Number     In Varchar2, --来源头编码
                                    p_Origin_Line_Id    In Number, --来源行ID
                                    p_Source_Order_Type In Varchar2, --事务来源单据类型
                                    p_Source_Head_Id    In Number, --事务来源头ID
                                    p_Source_Number     In Varchar2, --事务来源头编码
                                    p_Source_Line_Id    In Number, --事务来源行ID
                                    p_User_Code         In Varchar2, --用户ID
                                    p_Result            In Out Number, --返回错误ID
                                    p_Err_Msg           In Out Varchar2 --返回错误信息
                                    );

  -------------------------------------------------------------------------------
  /*  创建日期：2014-06-24
  *     创建者：李振
  *   功能说明：处理订单管理的销售单红冲定制机库存占用减少，
  */ -----------------------------------------------------------------------------
  Procedure p_Soorder_Unoccupy_Stocks(p_Inventory_Id     In Number, --仓库ID
                                      p_Item_Id          In Number, --产品ID
                                      p_Occupy_Qty       In Number, --占用数量
                                      p_Match_Pln_To_Wip In Varchar2, --工单与订单完全匹配标志
                                      --P_OPERATION_TYPE    IN VARCHAR2, --操作类型(01:库存评审  02:中转入库  03:销售开单  04:杂项(含：41:破损调拨、42:盘盈亏、43:采购退货、44:其它))
                                      p_Action_Desc       In Varchar2, --单据操作描述 例：中转单据执行、中转红冲单执行
                                      p_Entity_Id         In Number, --主体ID
                                      p_Origin_Type       In Varchar2, --来源类型
                                      p_Origin_Head_Id    In Number, --来源头ID
                                      p_Origin_Number     In Varchar2, --来源头编码
                                      p_Origin_Line_Id    In Number, --来源行ID
                                      p_Source_Order_Type In Varchar2, --事务来源单据类型
                                      p_Source_Head_Id    In Number, --事务来源头ID
                                      p_Source_Number     In Varchar2, --事务来源头编码
                                      p_Source_Line_Id    In Number, --事务来源行ID
                                      p_User_Code         In Varchar2, --用户ID
                                      p_Allow_No_Occupy   In Varchar2, --是否允许没有锁定（Y/N，Y则对于没找到对应的锁定记录则不作任何处理）
                                      p_Result            In Out Number, --返回错误ID
                                      p_Err_Msg           In Out Varchar2 --返回错误信息
                                      );

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-06-24
  *     创建者：李振
  *   功能说明：处理订单管理的破损调拨定制机库存占用增加
  */
  -------------------------------------------------------------------------------
  Procedure p_Torn_Transfer_Occupy_Stocks(p_Inventory_Id     In Number, --仓库ID
                                          p_Item_Id          In Number, --产品ID
                                          p_Occupy_Qty       In Number, --占用数量
                                          p_Match_Pln_To_Wip In Varchar2, --工单与订单完全匹配标志 Y:完全匹配  N:非完全匹配
                                          --P_OPERATION_TYPE    IN VARCHAR2, --操作类型(01:库存评审  02:中转入库  03:销售开单  04:杂项(含：41:破损调拨、42:盘盈亏、43:采购退货、44:其它))
                                          p_Action_Desc       In Varchar2, --单据操作描述 例：中转单据执行、中转红冲单执行
                                          p_Entity_Id         In Number, --主体ID
                                          p_Origin_Type       In Varchar2, --来源类型
                                          p_Origin_Head_Id    In Number, --来源头ID
                                          p_Origin_Number     In Varchar2, --来源头编码
                                          p_Origin_Line_Id    In Number, --来源行ID
                                          p_Source_Order_Type In Varchar2, --事务来源单据类型
                                          p_Source_Head_Id    In Number, --事务来源头ID
                                          p_Source_Number     In Varchar2, --事务来源头编码
                                          p_Source_Line_Id    In Number, --事务来源行ID
                                          p_User_Code         In Varchar2, --用户ID
                                          p_Result            In Out Number, --返回错误ID
                                          p_Err_Msg           In Out Varchar2 --返回错误信息
                                          );

  -------------------------------------------------------------------------------
  /*  创建日期：2014-06-24
  *     创建者：李振
  *   功能说明：处理订单管理的破损调拨入库定制机库存占用减少，
  */ -----------------------------------------------------------------------------
  Procedure p_Torn_Tf_Unoccupy_Stocks(p_Inventory_Id     In Number, --仓库ID
                                      p_Item_Id          In Number, --产品ID
                                      p_Occupy_Qty       In Number, --占用数量
                                      p_Match_Pln_To_Wip In Varchar2, --工单与订单完全匹配标志
                                      --P_OPERATION_TYPE    IN VARCHAR2, --操作类型(01:库存评审  02:中转入库  03:销售开单  04:杂项(含：41:破损调拨、42:盘盈亏、43:采购退货、44:其它))
                                      p_Action_Desc       In Varchar2, --单据操作描述 例：中转单据执行、中转红冲单执行
                                      p_Entity_Id         In Number, --主体ID
                                      p_Origin_Type       In Varchar2, --来源类型
                                      p_Origin_Head_Id    In Number, --来源头ID
                                      p_Origin_Number     In Varchar2, --来源头编码
                                      p_Origin_Line_Id    In Number, --来源行ID
                                      p_Source_Order_Type In Varchar2, --事务来源单据类型
                                      p_Source_Head_Id    In Number, --事务来源头ID
                                      p_Source_Number     In Varchar2, --事务来源头编码
                                      p_Source_Line_Id    In Number, --事务来源行ID
                                      p_User_Code         In Varchar2, --用户ID
                                      p_Allow_No_Occupy   In Varchar2, --是否允许没有锁定（Y/N，Y则对于没找到对应的锁定记录则不作任何处理）
                                      p_Result            In Out Number, --返回错误ID
                                      p_Err_Msg           In Out Varchar2 --返回错误信息
                                      );

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-06-24
  *     创建者：李振
  *   功能说明：处理订单管理的库存盘点定制机库存占用增加
  */
  -------------------------------------------------------------------------------
  Procedure p_Makeinvof_Occupy_Stocks(p_Inventory_Id     In Number, --仓库ID
                                      p_Item_Id          In Number, --产品ID
                                      p_Occupy_Qty       In Number, --占用数量
                                      p_Match_Pln_To_Wip In Varchar2, --工单与订单完全匹配标志 Y:完全匹配  N:非完全匹配
                                      --P_OPERATION_TYPE    IN VARCHAR2, --操作类型(01:库存评审  02:中转入库  03:销售开单  04:杂项(含：41:破损调拨、42:盘盈亏、43:采购退货、44:其它))
                                      p_Action_Desc       In Varchar2, --单据操作描述 例：中转单据执行、中转红冲单执行
                                      p_Entity_Id         In Number, --主体ID
                                      p_Origin_Type       In Varchar2, --来源类型
                                      p_Origin_Head_Id    In Number, --来源头ID
                                      p_Origin_Number     In Varchar2, --来源头编码
                                      p_Origin_Line_Id    In Number, --来源行ID
                                      p_Source_Order_Type In Varchar2, --事务来源单据类型
                                      p_Source_Head_Id    In Number, --事务来源头ID
                                      p_Source_Number     In Varchar2, --事务来源头编码
                                      p_Source_Line_Id    In Number, --事务来源行ID
                                      p_User_Code         In Varchar2, --用户ID
                                      p_Result            In Out Number, --返回错误ID
                                      p_Err_Msg           In Out Varchar2 --返回错误信息
                                      );

  -------------------------------------------------------------------------------
  /*  创建日期：2014-06-24
  *     创建者：李振
  *   功能说明：处理订单管理的库存盘点单红冲定制机库存占用减少，
  */ -----------------------------------------------------------------------------
  Procedure p_Makeinvof_Unoccupy_Stocks(p_Inventory_Id     In Number, --仓库ID
                                        p_Item_Id          In Number, --产品ID
                                        p_Occupy_Qty       In Number, --占用数量
                                        p_Match_Pln_To_Wip In Varchar2, --工单与订单完全匹配标志
                                        --P_OPERATION_TYPE    IN VARCHAR2, --操作类型(01:库存评审  02:中转入库  03:销售开单  04:杂项(含：41:破损调拨、42:盘盈亏、43:采购退货、44:其它))
                                        p_Action_Desc       In Varchar2, --单据操作描述 例：中转单据执行、中转红冲单执行
                                        p_Entity_Id         In Number, --主体ID
                                        p_Origin_Type       In Varchar2, --来源类型
                                        p_Origin_Head_Id    In Number, --来源头ID
                                        p_Origin_Number     In Varchar2, --来源头编码
                                        p_Origin_Line_Id    In Number, --来源行ID
                                        p_Source_Order_Type In Varchar2, --事务来源单据类型
                                        p_Source_Head_Id    In Number, --事务来源头ID
                                        p_Source_Number     In Varchar2, --事务来源头编码
                                        p_Source_Line_Id    In Number, --事务来源行ID
                                        p_User_Code         In Varchar2, --用户ID
                                        p_Allow_No_Occupy   In Varchar2, --是否允许没有锁定（Y/N，Y则对于没找到对应的锁定记录则不作任何处理）
                                        p_Result            In Out Number, --返回错误ID
                                        p_Err_Msg           In Out Varchar2 --返回错误信息
                                        );
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-06-24
  *     创建者：李振
  *   功能说明：处理订单管理的采购退货定制机库存占用增加
  */
  -------------------------------------------------------------------------------
  Procedure p_Procure_Return_Occupy_Stocks(p_Inventory_Id     In Number, --仓库ID
                                           p_Item_Id          In Number, --产品ID
                                           p_Occupy_Qty       In Number, --占用数量
                                           p_Match_Pln_To_Wip In Varchar2, --工单与订单完全匹配标志 Y:完全匹配  N:非完全匹配
                                           --P_OPERATION_TYPE    IN VARCHAR2, --操作类型(01:库存评审  02:中转入库  03:销售开单  04:杂项(含：41:破损调拨、42:盘盈亏、43:采购退货、44:其它))
                                           p_Action_Desc       In Varchar2, --单据操作描述 例：中转单据执行、中转红冲单执行
                                           p_Entity_Id         In Number, --主体ID
                                           p_Origin_Type       In Varchar2, --来源类型
                                           p_Origin_Head_Id    In Number, --来源头ID
                                           p_Origin_Number     In Varchar2, --来源头编码
                                           p_Origin_Line_Id    In Number, --来源行ID
                                           p_Source_Order_Type In Varchar2, --事务来源单据类型
                                           p_Source_Head_Id    In Number, --事务来源头ID
                                           p_Source_Number     In Varchar2, --事务来源头编码
                                           p_Source_Line_Id    In Number, --事务来源行ID
                                           p_User_Code         In Varchar2, --用户ID
                                           p_Result            In Out Number, --返回错误ID
                                           p_Err_Msg           In Out Varchar2 --返回错误信息
                                           );

  -------------------------------------------------------------------------------
  /*  创建日期：2014-06-24
  *     创建者：李振
  *   功能说明：处理订单管理的采购退货红冲定制机库存占用减少，
  */ -----------------------------------------------------------------------------
  Procedure p_Procreturn_Unoccupy_Stocks(p_Inventory_Id     In Number, --仓库ID
                                         p_Item_Id          In Number, --产品ID
                                         p_Occupy_Qty       In Number, --占用数量
                                         p_Match_Pln_To_Wip In Varchar2, --工单与订单完全匹配标志
                                         --P_OPERATION_TYPE    IN VARCHAR2, --操作类型(01:库存评审  02:中转入库  03:销售开单  04:杂项(含：41:破损调拨、42:盘盈亏、43:采购退货、44:其它))
                                         p_Action_Desc       In Varchar2, --单据操作描述 例：中转单据执行、中转红冲单执行
                                         p_Entity_Id         In Number, --主体ID
                                         p_Origin_Type       In Varchar2, --来源类型
                                         p_Origin_Head_Id    In Number, --来源头ID
                                         p_Origin_Number     In Varchar2, --来源头编码
                                         p_Origin_Line_Id    In Number, --来源行ID
                                         p_Source_Order_Type In Varchar2, --事务来源单据类型
                                         p_Source_Head_Id    In Number, --事务来源头ID
                                         p_Source_Number     In Varchar2, --事务来源头编码
                                         p_Source_Line_Id    In Number, --事务来源行ID
                                         p_User_Code         In Varchar2, --用户ID
                                         p_Allow_No_Occupy   In Varchar2, --是否允许没有锁定（Y/N，Y则对于没找到对应的锁定记录则不作任何处理）
                                         p_Result            In Out Number, --返回错误ID
                                         p_Err_Msg           In Out Varchar2 --返回错误信息
                                         );
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-06-24
  *     创建者：李振
  *   功能说明：处理订单管理的提货订单、调拨申请定制机库存占用增加
  */
  -------------------------------------------------------------------------------
  Procedure p_Lgorder_Occupy_Stocks(p_Inventory_Id      In Number, --仓库ID
                                    p_Item_Id           In Number, --产品ID
                                    p_Occupy_Qty        In Number, --占用数量
                                    p_Action_Desc       In Varchar2, --单据操作描述 例：中转单据执行、中转红冲单执行
                                    p_Entity_Id         In Number, --主体ID
                                    p_Origin_Type       In Varchar2, --来源类型
                                    p_Origin_Head_Id    In Number, --来源头ID
                                    p_Origin_Number     In Varchar2, --来源头编码
                                    p_Origin_Line_Id    In Number, --来源行ID
                                    p_Source_Order_Type In Varchar2, --事务来源单据类型
                                    p_Source_Head_Id    In Number, --事务来源头ID
                                    p_Source_Number     In Varchar2, --事务来源头编码
                                    p_Source_Line_Id    In Number, --事务来源行ID
                                    p_User_Code         In Varchar2, --用户ID
                                    p_Result            In Out Number, --返回错误ID
                                    p_Err_Msg           In Out Varchar2 --返回错误信息
                                    );

  -------------------------------------------------------------------------------
  /*  创建日期：2014-06-24
  *     创建者：李振
  *   功能说明：处理订单管理的提货订单、调拨申请定定制机库存占用减少，
  */ -----------------------------------------------------------------------------
  Procedure p_Lgorder_Unoccupy_Stocks(p_Inventory_Id In Number, --仓库ID
                                      p_Item_Id      In Number, --产品ID
                                      p_Occupy_Qty   In Number, --占用数量
                                      --p_Match_Pln_To_Wip In Varchar2, --工单与订单完全匹配标志
                                      --P_OPERATION_TYPE    IN VARCHAR2, --操作类型(01:库存评审  02:中转入库  03:销售开单  04:杂项(含：41:破损调拨、42:盘盈亏、43:采购退货、44:其它))
                                      p_Action_Desc       In Varchar2, --单据操作描述 例：中转单据执行、中转红冲单执行
                                      p_Entity_Id         In Number, --主体ID
                                      p_Origin_Type       In Varchar2, --来源类型
                                      p_Origin_Head_Id    In Number, --来源头ID
                                      p_Origin_Number     In Varchar2, --来源头编码
                                      p_Origin_Line_Id    In Number, --来源行ID
                                      p_Source_Order_Type In Varchar2, --事务来源单据类型
                                      p_Source_Head_Id    In Number, --事务来源头ID
                                      p_Source_Number     In Varchar2, --事务来源头编码
                                      p_Source_Line_Id    In Number, --事务来源行ID
                                      p_User_Code         In Varchar2, --用户ID
                                      p_Allow_No_Occupy   In Varchar2, --是否允许没有锁定（Y/N，Y则对于没找到对应的锁定记录则不作任何处理）
                                      p_Result            In Out Number, --返回错误ID
                                      p_Err_Msg           In Out Varchar2 --返回错误信息
                                      );

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-09-24
  *     创建者：李振
  *   功能说明：处理特殊占用 其它单据占用方式 特殊占用数量增加
  */
  -------------------------------------------------------------------------------
  Procedure p_Others_Occupy_Stocks(p_Inventory_Id     In Number, --仓库ID
                                   p_Item_Id          In Number, --产品ID
                                   p_Occupy_Qty       In Number, --占用数量
                                   p_Match_Pln_To_Wip In Varchar2, --工单与订单完全匹配标志 Y:完全匹配  N:非完全匹配
                                   --P_OPERATION_TYPE    IN VARCHAR2, --操作类型(01:库存评审  02:中转入库  03:销售开单  04:杂项(含：41:破损调拨、42:盘盈亏、43:采购退货、44:其它))
                                   p_Action_Desc       In Varchar2, --单据操作描述 例：中转单据执行、中转红冲单执行
                                   p_Entity_Id         In Number, --主体ID
                                   p_Origin_Type       In Varchar2, --来源类型
                                   p_Origin_Head_Id    In Number, --来源头ID
                                   p_Origin_Number     In Varchar2, --来源头编码
                                   p_Origin_Line_Id    In Number, --来源行ID
                                   p_Source_Order_Type In Varchar2, --事务来源单据类型
                                   p_Source_Head_Id    In Number, --事务来源头ID
                                   p_Source_Number     In Varchar2, --事务来源头编码
                                   p_Source_Line_Id    In Number, --事务来源行ID
                                   p_User_Code         In Varchar2, --用户ID
                                   p_Result            In Out Number, --返回错误ID
                                   p_Err_Msg           In Out Varchar2 --返回错误信息
                                   );

  -------------------------------------------------------------------------------
  /*  创建日期：2014-09-24
  *     创建者：李振
  *   功能说明：处理特殊占用 其它单据占用方式 特殊占用数量减少，
  */ -----------------------------------------------------------------------------
  Procedure p_Others_Unoccupy_Stocks(p_Inventory_Id     In Number, --仓库ID
                                     p_Item_Id          In Number, --产品ID
                                     p_Occupy_Qty       In Number, --占用数量
                                     p_Match_Pln_To_Wip In Varchar2, --工单与订单完全匹配标志
                                     --P_OPERATION_TYPE    IN VARCHAR2, --操作类型(01:库存评审  02:中转入库  03:销售开单  04:杂项(含：41:破损调拨、42:盘盈亏、43:采购退货、44:其它))
                                     p_Action_Desc       In Varchar2, --单据操作描述 例：中转单据执行、中转红冲单执行
                                     p_Entity_Id         In Number, --主体ID
                                     p_Origin_Type       In Varchar2, --来源类型
                                     p_Origin_Head_Id    In Number, --来源头ID
                                     p_Origin_Number     In Varchar2, --来源头编码
                                     p_Origin_Line_Id    In Number, --来源行ID
                                     p_Source_Order_Type In Varchar2, --事务来源单据类型
                                     p_Source_Head_Id    In Number, --事务来源头ID
                                     p_Source_Number     In Varchar2, --事务来源头编码
                                     p_Source_Line_Id    In Number, --事务来源行ID
                                     p_User_Code         In Varchar2, --用户ID
                                     p_Allow_No_Occupy   In Varchar2, --是否允许没有锁定（Y/N，Y则对于没找到对应的锁定记录则不作任何处理）
                                     p_Result            In Out Number, --返回错误ID
                                     p_Err_Msg           In Out Varchar2 --返回错误信息
                                     );

  -------------------------------------------------------------------------------
  /*
   *  CreateDate：2015-03-10
  *   Author： 李振
  *   Purpose：返回散件的中转入库红冲单已开单未执行的数量
  */
  -------------------------------------------------------------------------------
  Function f_Get_Item_Read_Wip_Qty(p_Inventory_Id  Number,
                                   p_Sub_Item_Id   Number, --散件产品ID
                                   p_Entity_Id     Number, --主体ID
                                   p_Order_Line_Id Number --计划订单行ID
                                   ) Return Number;

  -------------------------------------------------------------------------------
  /*
   *  创建日期：2014-06-27
  *     创建者：李振
  *   功能说明：返回套件或者散件的仓库占用数量
  *             如果是套件则按最小占用量的散件来配套
  */
  -------------------------------------------------------------------------------
  Function f_Item_Ass_Occupy_Qty(p_Inventory_Id     In Number, --仓库ID
                                 p_Item_Id          In Number, --产品ID
                                 p_Match_Pln_To_Wip In Varchar2, --工单与订单完全匹配标志
                                 p_Entity_Id        In Number, --主体ID
                                 p_Origin_Line_Id   In Number, --来源行ID
                                 p_Origin_Type      In Varchar2 Default '_' --库存占用来源类型
                                 ) Return Number;

  -------------------------------------------------------------------------------
  /*
  *  创建日期：2014-06-27
  *     创建者：李振
  *   功能说明：返回套件或者散件的仓库占用数量
  *             如果是套件则按最小占用量的散件来配套
  */
  -------------------------------------------------------------------------------
  Function f_Get_Item_Occupy_Qty(p_Inventory_Id     In Number, --仓库id
                                 p_Item_Id          In Number, --产品id
                                 p_Entity_Id        In Number, --主体id
                                 p_Match_Pln_To_Wip In Varchar2 Default 'A' --工单与订单完全匹配标志
                                 ) Return Number;

  -------------------------------------------------------------------------------
  /*
   *  创建日期：2014-06-24
  *     创建者：李振
  *   功能说明：特殊库存占用信息记录，
  *             该过程只处理散件
  *             p_Sign_Type: 1：占用  -1：释放
  */
  -------------------------------------------------------------------------------
  Procedure p_Dispose_Special_Occupy(p_Inventory_Id         In Number, --仓库ID
                                     p_Item_Id              In Number, --产品ID
                                     p_Trans_Date           In Date,   --事务日期
                                     p_Sign_Type            In Number, --处理标识  1：占用  -1：释放
                                     p_Trans_Qty            In Number, --占用数量
                                     p_Special_Type         In Varchar2, --操作类型(01:库存评审  02:中转入库  03:销售开单  04:杂项(含：41:破损调拨、42:盘盈亏、43:采购退货、44:其它))
                                     p_Entity_Id            In Number, --主体ID
                                     p_Origin_Order_Type_Id In Varchar2, --来源类型
                                     p_Origin_Head_Id       In Number, --来源头ID
                                     p_Origin_Order_Number  In Varchar2, --来源头编码
                                     p_Origin_Line_Id       In Number, --来源行ID
                                     p_Source_Order_Type    In Varchar2, --事务来源单据类型
                                     p_Source_Head_Id       In Number, --事务来源头ID
                                     p_Source_Order_Number  In Varchar2, --事务来源头编码
                                     p_Source_Line_Id       In Number, --事务来源行ID
                                     p_User_Code            In Varchar2, --用户ID
                                     p_Result               Out Varchar2 --返回错误信息, 成功返回“SUCCESS”
                                     );

   -------------------------------------------------------------------------------
  /*
   *  创建日期：2014-11-24
  *   创建者：李振
  *   功能说明：重算库存占用数据的JOB
  */
  -------------------------------------------------------------------------------
  Procedure P_Atuo_Recalulation_Job;

  -------------------------------------------------------------------------------
  /*
   *  创建日期：2014-11-24
  *   创建者：李振
  *   功能说明：重算库存占用数据，重算时只重算当前未释放完的占用行
  *             该功能只重算订单相关的数据，
  */
  -------------------------------------------------------------------------------
  Procedure p_Auto_Recalculation_Occupy(p_Entity_Id         In Number,
                                        p_Pln_Wip_Ord_Match In Varchar2);
End Pkg_Pln_Inv_Occupy;
/

