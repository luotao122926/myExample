create PACKAGE BODY PKG_PLN_PRODUCING_AREA_ALLOT IS

  V_NL    CONSTANT VARCHAR2(2) := CHR(13) || CHR(10); --换行
  V_SUCCESS CONSTANT VARCHAR2(10) := 'SUCCESS';

  V_BASE_EXCEPTION EXCEPTION; --自定义异常

  ----------------------------------------------------------------------
  -- Author  : fenggq
  -- Created : 2014-09-09 10:35:00
  -- Purpose : 初次产地分解
  ----------------------------------------------------------------------
  PROCEDURE P_PRODUCING_AREA_ALLOT_1ST(P_ORDER_TYPE_ID IN NUMBER, --订单类型ID
                                       P_PERIOD_ID     IN NUMBER, --订单周期ID
                                       P_BATCH_ID      IN NUMBER, --批次ID
                                       P_ENTITY_ID     IN NUMBER, --主体ID
                                       P_CREATED_BY    IN VARCHAR2, --创建人
                                       P_RESULT        OUT VARCHAR2) IS

    --校验产品模具对应关系
    VS_ITEM_CODE            T_PLN_ORDER_LINE.ITEM_CODE%TYPE;
    VS_ITEM_NAME            T_PLN_ORDER_LINE.ITEM_DESC%TYPE;
    VS_PLASTIC_CODE         T_PLN_ITEM_PLASTIC.PLASTIC_CODE%TYPE;
    --校验产地模具对应关系
    VS_PLASTIC_NAME         T_PLN_ITEM_PLASTIC.PLASTIC_NAME%TYPE;
    VN_MOULD_COUNT          NUMBER;
    --校验产地总装对应关系
    VS_PRODUCING_AREA_NAME  T_PLN_PRODUCING_AREA.PRODUCING_AREA_NAME%TYPE;
    VN_TOTAL_COUNT          NUMBER;

    VN_SALES_CENTER_COUNT   NUMBER; --营销中心数量
    VS_COST_FLAG            T_PLN_CENTER_COST_RELATION.COST_FLAG%TYPE; --成本标识
    VN_ITEM_COUNT           NUMBER; --产品数量

    VN_TOTAL_CHECK_QTY      NUMBER; --总装订单数量

  BEGIN
    P_RESULT := V_SUCCESS;

    --校验产品模具对应关系
    BEGIN
      FOR C_PLN_ORDER_ITEM IN
        (SELECT DISTINCT ITEM_CODE
           FROM T_PLN_ORDER_HEAD A,
                T_PLN_ORDER_LINE B,
                T_PLN_ORDER_TYPE D
          WHERE A.ORDER_TYPE_ID = P_ORDER_TYPE_ID
            AND A.PERIOD_ID = P_PERIOD_ID
            AND A.FORM_STATE = 25
            AND A.BATCH_ID = P_BATCH_ID
            AND A.ENTITY_ID = P_ENTITY_ID
            AND B.ORDER_HEAD_ID = A.ORDER_HEAD_ID
            AND D.ORDER_TYPE_ID = A.ORDER_TYPE_ID
            AND D.SEND_BY_TYPE IN (1, 2)) LOOP

         VS_ITEM_CODE := C_PLN_ORDER_ITEM.ITEM_CODE;

         SELECT ITEM_NAME
           INTO VS_ITEM_NAME
           FROM T_BD_ITEM
          WHERE ITEM_CODE = C_PLN_ORDER_ITEM.ITEM_CODE
            AND ENTITY_ID = P_ENTITY_ID;

         SELECT PLASTIC_CODE
           INTO VS_PLASTIC_CODE
           FROM T_PLN_ITEM_PLASTIC
          WHERE ITEM_CODE = C_PLN_ORDER_ITEM.ITEM_CODE
            AND ENTITY_ID = P_ENTITY_ID;
      END LOOP;

    EXCEPTION
      WHEN OTHERS THEN
      P_RESULT := '产品：' || VS_ITEM_CODE || ' ' || VS_ITEM_NAME || '，没有维护产品模具对应关系。';
      RETURN;
    END;
    --校验产地模具对应关系
    BEGIN
      FOR C_PLN_ORDER_PLASTIC IN
        (SELECT DISTINCT PLASTIC_CODE
           FROM T_PLN_ORDER_HEAD A,
                T_PLN_ORDER_LINE B,
                T_PLN_ITEM_PLASTIC C,
                T_PLN_ORDER_TYPE D
          WHERE A.ORDER_TYPE_ID = P_ORDER_TYPE_ID
            AND A.PERIOD_ID = P_PERIOD_ID
            AND A.FORM_STATE = 25
            AND A.BATCH_ID = P_BATCH_ID
            AND A.ENTITY_ID = P_ENTITY_ID
            AND B.ORDER_HEAD_ID = A.ORDER_HEAD_ID
            AND C.ITEM_CODE = B.ITEM_CODE
            AND D.ORDER_TYPE_ID = A.ORDER_TYPE_ID
            AND D.SEND_BY_TYPE IN (1, 2)) LOOP

         SELECT DISTINCT PLASTIC_NAME
           INTO VS_PLASTIC_NAME
           FROM T_PLN_ITEM_PLASTIC
          WHERE PLASTIC_CODE = C_PLN_ORDER_PLASTIC.PLASTIC_CODE
            AND ENTITY_ID = P_ENTITY_ID;

         SELECT COUNT(*)
           INTO VN_MOULD_COUNT
           FROM T_PLN_MOULD_PRODUCTIVITY_AREA
          WHERE PLASTIC_CODE = C_PLN_ORDER_PLASTIC.PLASTIC_CODE
            AND PERIOD_ID = P_PERIOD_ID
            AND ENTITY_ID = P_ENTITY_ID;

         IF VN_MOULD_COUNT = 0 THEN
           P_RESULT := '模具：' || C_PLN_ORDER_PLASTIC.PLASTIC_CODE || ' ' || VS_PLASTIC_NAME || '，没有维护产地模具对应关系。';
           RETURN;
         END IF;
      END LOOP;
    END;
    --校验产地总装对应关系
    BEGIN
      FOR C_PLN_ORDER_TOTAL IN
        (SELECT DISTINCT B.PRODUCING_AREA_CODE
           FROM T_PLN_ORDER_HEAD A,
                T_PLN_ORDER_LINE B,
                T_PLN_ORDER_TYPE D
          WHERE A.ORDER_TYPE_ID = P_ORDER_TYPE_ID
            AND A.PERIOD_ID = P_PERIOD_ID
            AND A.FORM_STATE = 25
            AND A.BATCH_ID = P_BATCH_ID
            AND A.ENTITY_ID = P_ENTITY_ID
            AND B.ORDER_HEAD_ID = A.ORDER_HEAD_ID
            AND D.ORDER_TYPE_ID = A.ORDER_TYPE_ID
            AND D.SEND_BY_TYPE IN (1, 2)) LOOP

         SELECT PRODUCING_AREA_NAME
           INTO VS_PRODUCING_AREA_NAME
           FROM T_PLN_PRODUCING_AREA
          WHERE PRODUCING_AREA_CODE = C_PLN_ORDER_TOTAL.PRODUCING_AREA_CODE
            AND ENTITY_ID = P_ENTITY_ID;

         SELECT COUNT(*)
           INTO VN_TOTAL_COUNT
           FROM T_PLN_TOTAL_PRODUCTIVITY_AREA
          WHERE PRODUCING_AREA_CODE = C_PLN_ORDER_TOTAL.PRODUCING_AREA_CODE
            AND PERIOD_ID = P_PERIOD_ID
            AND ENTITY_ID = P_ENTITY_ID;

         IF VN_TOTAL_COUNT = 0 THEN
           P_RESULT := '产地：' || C_PLN_ORDER_TOTAL.PRODUCING_AREA_CODE || ' ' || VS_PRODUCING_AREA_NAME || '，没有维护产地总装对应关系。';
           RETURN;
         END IF;
      END LOOP;
    END;

    --参与初次产地分解的订单头
    FOR C_PLN_ORDER_HEAD IN (SELECT *
                               FROM T_PLN_ORDER_HEAD
                              WHERE ORDER_TYPE_ID = P_ORDER_TYPE_ID
                                AND PERIOD_ID = P_PERIOD_ID
                                AND FORM_STATE = 25
                                AND BATCH_ID = P_BATCH_ID
                                AND ENTITY_ID = P_ENTITY_ID
                              ORDER BY ORDER_HEAD_ID) LOOP
      --记录配置到中心优先级表中的营销中心数量
      SELECT COUNT(*)
        INTO VN_SALES_CENTER_COUNT
        FROM T_PLN_CUSTOMER_PRIORITY
       WHERE SALES_CENTER_CODE = C_PLN_ORDER_HEAD.SALES_CENTER_CODE
         AND ENTITY_ID = P_ENTITY_ID;
      --判断营销中心是否存在
      IF VN_SALES_CENTER_COUNT > 0 THEN
        --记录营销中心优先成本标识
        SELECT COST_FLAG
          INTO VS_COST_FLAG
          FROM T_PLN_CENTER_COST_RELATION
         WHERE SALES_CENTER_CODE = C_PLN_ORDER_HEAD.SALES_CENTER_CODE
           AND ENTITY_ID = P_ENTITY_ID;
        --优先成本选择物流成本
        IF VS_COST_FLAG = 1 THEN
          --参与初次产地分解的订单行
          FOR C_PLN_ORDER_LINE IN (SELECT *
                                     FROM T_PLN_ORDER_LINE
                                    WHERE ORDER_HEAD_ID = C_PLN_ORDER_HEAD.ORDER_HEAD_ID
                                    ORDER BY ORDER_LINE_ID) LOOP
            --记录配置到中心优先级表中的产品数量
            SELECT COUNT(ITEM_CODE)
              INTO VN_ITEM_COUNT
              FROM T_PLN_CUSTOMER_PRIORITY
             WHERE SALES_CENTER_CODE = C_PLN_ORDER_HEAD.SALES_CENTER_CODE
               AND ITEM_CODE = C_PLN_ORDER_LINE.ITEM_CODE
               AND ENTITY_ID = P_ENTITY_ID;
            --判断产品是否存在
            IF VN_ITEM_COUNT > 0 THEN
              --物流成本最优，区域辐射最优的产地
              FOR C_PLN_COST_LOGISTICS IN (SELECT PRODUCING_AREA_ID,
                                                  PRODUCING_AREA_CODE,
                                                  PRODUCING_AREA_NAME
                                             FROM T_PLN_CUSTOMER_PRIORITY
                                            WHERE SALES_CENTER_CODE = C_PLN_ORDER_HEAD.SALES_CENTER_CODE
                                              AND ITEM_CODE = C_PLN_ORDER_LINE.ITEM_CODE
                                              AND ENTITY_ID = P_ENTITY_ID
                                            ORDER BY COST_LOGISTICS, PRODUCING_AREA_PRIORITY) LOOP --取物流成本最优，取区域辐射最优
                --更新订单行产地信息
                --@@是否要返回不在C_PLN_COST_LOGISTICS.PRODUCING_AREA_NAME产地生产的产品？
                BEGIN
                  VS_ITEM_CODE := '-1';
                  SELECT A.ITEM_CODE --在C_PLN_COST_LOGISTICS.PRODUCING_AREA_NAME产地生产的产品
                    INTO VS_ITEM_CODE
                    FROM T_PLN_ORDER_LINE A, T_PLN_ITEM_PRODUCING_AREA B
                   WHERE A.ORDER_LINE_ID = C_PLN_ORDER_LINE.ORDER_LINE_ID
                     AND A.ITEM_CODE = B.ITEM_CODE
                     AND B.PRODUCING_AREA_ID = C_PLN_COST_LOGISTICS.PRODUCING_AREA_ID;
                EXCEPTION
                  WHEN OTHERS THEN
                  NULL;
                END;
                --判断产品在C_PLN_COST_LOGISTICS.PRODUCING_AREA_NAME产地是否生产
                IF VS_ITEM_CODE <> '-1' THEN
                  IF C_PLN_ORDER_LINE.PRODUCING_AREA_ID <> C_PLN_COST_LOGISTICS.PRODUCING_AREA_ID THEN
                    INSERT INTO T_PLN_ORDER_LINE
                      (ENTITY_ID,
                       ORDER_LINE_ID,
                       ORDER_HEAD_ID,
                       PRODUCING_AREA_ID,
                       PRODUCING_AREA_CODE,
                       PRODUCING_AREA_NAME,
                       ITEM_ID,
                       ITEM_CODE,
                       ITEM_DESC,
                       ITEM_UOM,
                       ITEM_PRICE,
                       APPLY_QTY,
                       CHECK_QTY,
                       CAN_PRODUCE_QTY, --?
                       AMOUNT,
                       STATUS,
                       CAN_SUPPLY_DATE,
                       BEGIN_SUPPLY_DATE,
                       END_SUPPLY_DATE,
                       ADJUST_QTY, --?
                       CREATED_BY,
                       CREATION_DATE,
                       LAST_UPDATED_BY,
                       LAST_UPDATE_DATE)
                      SELECT ENTITY_ID,
                             S_PLN_ORDER_LINE.NEXTVAL,
                             ORDER_HEAD_ID,
                             C_PLN_COST_LOGISTICS.PRODUCING_AREA_ID,
                             C_PLN_COST_LOGISTICS.PRODUCING_AREA_CODE,
                             C_PLN_COST_LOGISTICS.PRODUCING_AREA_NAME,
                             ITEM_ID,
                             ITEM_CODE,
                             ITEM_DESC,
                             ITEM_UOM,
                             ITEM_PRICE,
                             0,
                             CHECK_QTY,
                             CAN_PRODUCE_QTY,
                             AMOUNT,
                             STATUS,
                             CAN_SUPPLY_DATE,
                             BEGIN_SUPPLY_DATE,
                             END_SUPPLY_DATE,
                             ADJUST_QTY,
                             P_CREATED_BY,
                             SYSDATE,
                             P_CREATED_BY,
                             SYSDATE
                        FROM T_PLN_ORDER_LINE
                       WHERE ORDER_LINE_ID = C_PLN_ORDER_LINE.ORDER_LINE_ID;

                      UPDATE T_PLN_ORDER_LINE
                         SET CHECK_QTY = 0,
                             CAN_PRODUCE_QTY = 0,
                             LAST_UPDATED_BY = P_CREATED_BY,
                             LAST_UPDATE_DATE = SYSDATE
                       WHERE ORDER_LINE_ID = C_PLN_ORDER_LINE.ORDER_LINE_ID;
                    EXIT;
                  ELSE
                    EXIT;
                  END IF;
                END IF;
              END LOOP;
            ELSE
              --区域辐射最优的产地
              FOR C_PLN_PRODUCING_AREA_PRIORITY IN (SELECT PRODUCING_AREA_ID,
                                                           PRODUCING_AREA_CODE,
                                                           PRODUCING_AREA_NAME
                                                      FROM T_PLN_CUSTOMER_PRIORITY
                                                     WHERE SALES_CENTER_CODE = C_PLN_ORDER_HEAD.SALES_CENTER_CODE
                                                       AND ITEM_CODE IS NULL
                                                       AND ENTITY_ID = P_ENTITY_ID
                                                     ORDER BY PRODUCING_AREA_PRIORITY) LOOP --取区域辐射最优
                --更新订单行产地信息
                --@@是否要返回不在C_PLN_PRODUCING_AREA_PRIORITY.PRODUCING_AREA_NAME产地生产的产品？
                BEGIN
                  VS_ITEM_CODE := '-1';
                  SELECT A.ITEM_CODE --在C_PLN_PRODUCING_AREA_PRIORITY.PRODUCING_AREA_NAME产地生产的产品
                    INTO VS_ITEM_CODE
                    FROM T_PLN_ORDER_LINE A, T_PLN_ITEM_PRODUCING_AREA B
                   WHERE A.ORDER_LINE_ID = C_PLN_ORDER_LINE.ORDER_LINE_ID
                     AND A.ITEM_CODE = B.ITEM_CODE
                     AND B.PRODUCING_AREA_ID = C_PLN_PRODUCING_AREA_PRIORITY.PRODUCING_AREA_ID;
                EXCEPTION
                  WHEN OTHERS THEN
                  NULL;
                END;
                --判断产品在C_PLN_PRODUCING_AREA_PRIORITY.PRODUCING_AREA_NAME产地是否生产
                IF VS_ITEM_CODE <> '-1' THEN
                  IF C_PLN_ORDER_LINE.PRODUCING_AREA_ID <> C_PLN_PRODUCING_AREA_PRIORITY.PRODUCING_AREA_ID THEN
                    INSERT INTO T_PLN_ORDER_LINE
                      (ENTITY_ID,
                       ORDER_LINE_ID,
                       ORDER_HEAD_ID,
                       PRODUCING_AREA_ID,
                       PRODUCING_AREA_CODE,
                       PRODUCING_AREA_NAME,
                       ITEM_ID,
                       ITEM_CODE,
                       ITEM_DESC,
                       ITEM_UOM,
                       ITEM_PRICE,
                       APPLY_QTY,
                       CHECK_QTY,
                       CAN_PRODUCE_QTY, --?
                       AMOUNT,
                       STATUS,
                       CAN_SUPPLY_DATE,
                       BEGIN_SUPPLY_DATE,
                       END_SUPPLY_DATE,
                       ADJUST_QTY, --?
                       CREATED_BY,
                       CREATION_DATE,
                       LAST_UPDATED_BY,
                       LAST_UPDATE_DATE)
                      SELECT ENTITY_ID,
                             S_PLN_ORDER_LINE.NEXTVAL,
                             ORDER_HEAD_ID,
                             C_PLN_PRODUCING_AREA_PRIORITY.PRODUCING_AREA_ID,
                             C_PLN_PRODUCING_AREA_PRIORITY.PRODUCING_AREA_CODE,
                             C_PLN_PRODUCING_AREA_PRIORITY.PRODUCING_AREA_NAME,
                             ITEM_ID,
                             ITEM_CODE,
                             ITEM_DESC,
                             ITEM_UOM,
                             ITEM_PRICE,
                             0,
                             CHECK_QTY,
                             CAN_PRODUCE_QTY,
                             AMOUNT,
                             STATUS,
                             CAN_SUPPLY_DATE,
                             BEGIN_SUPPLY_DATE,
                             END_SUPPLY_DATE,
                             ADJUST_QTY,
                             P_CREATED_BY,
                             SYSDATE,
                             P_CREATED_BY,
                             SYSDATE
                        FROM T_PLN_ORDER_LINE
                       WHERE ORDER_LINE_ID = C_PLN_ORDER_LINE.ORDER_LINE_ID;

                      UPDATE T_PLN_ORDER_LINE
                         SET CHECK_QTY = 0,
                             CAN_PRODUCE_QTY = 0,
                             LAST_UPDATED_BY = P_CREATED_BY,
                             LAST_UPDATE_DATE = SYSDATE
                       WHERE ORDER_LINE_ID = C_PLN_ORDER_LINE.ORDER_LINE_ID;
                    EXIT;
                  ELSE
                    EXIT;
                  END IF;
                END IF;
              END LOOP;
            END IF;
          END LOOP;

          --模具产能信息
          FOR C_PLN_MOULD IN (SELECT B.PLASTIC_CODE,
                                     A.PRODUCING_AREA_ID,
                                     SUM(A.CHECK_QTY) CHECK_QTY,
                                     C.PLASTIC_PRODUCTIVITY,
                                     NVL(C.SURPLUS_PRODUCTIVITY, 0) OCCUPIED_PRODUCTIVITY
                                FROM T_PLN_ORDER_LINE A, T_PLN_ITEM_PLASTIC B, T_PLN_MOULD_PRODUCTIVITY_AREA C, T_PLN_ORDER_TYPE D
                               WHERE A.ORDER_HEAD_ID = C_PLN_ORDER_HEAD.ORDER_HEAD_ID
                                 AND A.ITEM_CODE = B.ITEM_CODE
                                 AND A.PRODUCING_AREA_ID = C.PRODUCING_AREA_ID
                                 AND B.PLASTIC_CODE = C.PLASTIC_CODE
                                 AND C.PERIOD_ID = P_PERIOD_ID
                                 AND D.ORDER_TYPE_ID = P_ORDER_TYPE_ID
                                 AND D.SEND_BY_TYPE IN (1, 2)
                               GROUP BY B.PLASTIC_CODE, A.PRODUCING_AREA_ID, C.PLASTIC_PRODUCTIVITY, C.SURPLUS_PRODUCTIVITY) LOOP
            --更新模具占用产能
            /*IF C_PLN_MOULD.PLASTIC_PRODUCTIVITY - C_PLN_MOULD.OCCUPIED_PRODUCTIVITY - C_PLN_MOULD.CHECK_QTY >= 0 THEN
              UPDATE T_PLN_MOULD_PRODUCTIVITY_AREA
                 SET SURPLUS_PRODUCTIVITY = SURPLUS_PRODUCTIVITY + C_PLN_MOULD.CHECK_QTY
               WHERE PRODUCING_AREA_ID = C_PLN_MOULD.PRODUCING_AREA_ID
                 AND PLASTIC_CODE = C_PLN_MOULD.PLASTIC_CODE
                 AND PERIOD_ID = P_PERIOD_ID;
            ELSE
              UPDATE T_PLN_MOULD_PRODUCTIVITY_AREA
                 SET PLASTIC_PRODUCTIVITY = SURPLUS_PRODUCTIVITY + C_PLN_MOULD.CHECK_QTY,
                     SURPLUS_PRODUCTIVITY = SURPLUS_PRODUCTIVITY + C_PLN_MOULD.CHECK_QTY
               WHERE PRODUCING_AREA_ID = C_PLN_MOULD.PRODUCING_AREA_ID
                 AND PLASTIC_CODE = C_PLN_MOULD.PLASTIC_CODE
                 AND PERIOD_ID = P_PERIOD_ID;
            END IF;*/
            UPDATE T_PLN_MOULD_PRODUCTIVITY_AREA
               SET SURPLUS_PRODUCTIVITY = NVL(SURPLUS_PRODUCTIVITY, 0) + C_PLN_MOULD.CHECK_QTY,
                   LAST_UPDATED_BY = P_CREATED_BY,
                   LAST_UPDATE_DATE = SYSDATE
             WHERE PRODUCING_AREA_ID = C_PLN_MOULD.PRODUCING_AREA_ID
               AND PLASTIC_CODE = C_PLN_MOULD.PLASTIC_CODE
               AND PERIOD_ID = P_PERIOD_ID
               AND ENTITY_ID = P_ENTITY_ID;
          END LOOP;
          --总装产能信息
          FOR C_PLN_TOTAL IN (SELECT A.PRODUCING_AREA_ID,
                                     SUM(A.CHECK_QTY) CHECK_QTY,
                                     SUM(C.PRODUCTIVITY) TOTAL_PRODUCTIVITY,
                                     SUM(NVL(C.SURPLUS_PRODUCTIVITY,  0)) OCCUPIED_PRODUCTIVITY
                                FROM T_PLN_ORDER_LINE A, T_PLN_TOTAL_PRODUCTIVITY_AREA C, T_PLN_ORDER_TYPE D
                               WHERE A.ORDER_HEAD_ID = C_PLN_ORDER_HEAD.ORDER_HEAD_ID
                                 AND A.PRODUCING_AREA_ID = C.PRODUCING_AREA_ID
                                 AND C.PERIOD_ID = P_PERIOD_ID
                                 AND D.ORDER_TYPE_ID = P_ORDER_TYPE_ID
                                 AND D.SEND_BY_TYPE IN (1, 2)
                               GROUP BY A.PRODUCING_AREA_ID) LOOP
            --更新总装占用产能
            /*IF C_PLN_TOTAL.TOTAL_PRODUCTIVITY - C_PLN_TOTAL.OCCUPIED_PRODUCTIVITY - C_PLN_TOTAL.CHECK_QTY >= 0 THEN
              SELECT ROUND(C_PLN_TOTAL.CHECK_QTY/
                (SELECT COUNT(*)
                   FROM T_PLN_TOTAL_PRODUCTIVITY_AREA
                  WHERE PRODUCING_AREA_ID = C_PLN_TOTAL.PRODUCING_AREA_ID
                    AND PERIOD_ID = P_PERIOD_ID), 0)
                INTO VN_TOTAL_CHECK_QTY
                FROM DUAL;

              UPDATE T_PLN_TOTAL_PRODUCTIVITY_AREA
                 SET SURPLUS_PRODUCTIVITY = SURPLUS_PRODUCTIVITY + VN_TOTAL_CHECK_QTY
               WHERE PRODUCING_AREA_ID = C_PLN_TOTAL.PRODUCING_AREA_ID
                 AND PERIOD_ID = P_PERIOD_ID;
            ELSE
              UPDATE T_PLN_TOTAL_PRODUCTIVITY_AREA
                 SET PRODUCTIVITY = SURPLUS_PRODUCTIVITY + VN_TOTAL_CHECK_QTY,
                     SURPLUS_PRODUCTIVITY = SURPLUS_PRODUCTIVITY + VN_TOTAL_CHECK_QTY
               WHERE PRODUCING_AREA_ID = C_PLN_TOTAL.PRODUCING_AREA_ID
                 AND PERIOD_ID = P_PERIOD_ID;
            END IF;*/
            SELECT ROUND(C_PLN_TOTAL.CHECK_QTY/
              (SELECT COUNT(*)
                 FROM T_PLN_TOTAL_PRODUCTIVITY_AREA
                WHERE PRODUCING_AREA_ID = C_PLN_TOTAL.PRODUCING_AREA_ID
                  AND PERIOD_ID = P_PERIOD_ID
                  AND ENTITY_ID = P_ENTITY_ID), 0)
              INTO VN_TOTAL_CHECK_QTY
              FROM DUAL;

            UPDATE T_PLN_TOTAL_PRODUCTIVITY_AREA
               SET SURPLUS_PRODUCTIVITY = NVL(SURPLUS_PRODUCTIVITY, 0) + VN_TOTAL_CHECK_QTY,
                   LAST_UPDATED_BY = P_CREATED_BY,
                   LAST_UPDATE_DATE = SYSDATE
             WHERE PRODUCING_AREA_ID = C_PLN_TOTAL.PRODUCING_AREA_ID
               AND PERIOD_ID = P_PERIOD_ID
               AND ENTITY_ID = P_ENTITY_ID;
          END LOOP;

        --优先成本选择综合成本
        ELSIF VS_COST_FLAG = 2 THEN
          --参与初次产地分解的订单行
          FOR C_PLN_ORDER_LINE IN (SELECT *
                                     FROM T_PLN_ORDER_LINE
                                    WHERE ORDER_HEAD_ID = C_PLN_ORDER_HEAD.ORDER_HEAD_ID
                                    ORDER BY ORDER_LINE_ID) LOOP
            --记录配置到中心优先级表中的产品数量
            SELECT COUNT(ITEM_CODE)
              INTO VN_ITEM_COUNT
              FROM T_PLN_CUSTOMER_PRIORITY
             WHERE SALES_CENTER_CODE = C_PLN_ORDER_HEAD.SALES_CENTER_CODE
               AND ITEM_CODE = C_PLN_ORDER_LINE.ITEM_CODE
               AND ENTITY_ID = P_ENTITY_ID;
            --判断产品是否存在
            IF VN_ITEM_COUNT > 0 THEN
              --综合成本最优，区域辐射最优的产地
              FOR C_PLN_COST_PRICE IN (SELECT PRODUCING_AREA_ID,
                                              PRODUCING_AREA_CODE,
                                              PRODUCING_AREA_NAME
                                         FROM T_PLN_CUSTOMER_PRIORITY
                                        WHERE SALES_CENTER_CODE = C_PLN_ORDER_HEAD.SALES_CENTER_CODE
                                          AND ITEM_CODE = C_PLN_ORDER_LINE.ITEM_CODE
                                          AND ENTITY_ID = P_ENTITY_ID
                                        ORDER BY COST_PRICE, PRODUCING_AREA_PRIORITY) LOOP --取物流成本最优，取区域辐射最优
                --更新订单行产地信息
                --@@是否要返回不在C_PLN_COST_PRICE.PRODUCING_AREA_NAME产地生产的产品？
                BEGIN
                  VS_ITEM_CODE := '-1';
                  SELECT A.ITEM_CODE --在C_PLN_COST_PRICE.PRODUCING_AREA_NAME产地生产的产品
                    INTO VS_ITEM_CODE
                    FROM T_PLN_ORDER_LINE A, T_PLN_ITEM_PRODUCING_AREA B
                   WHERE A.ORDER_LINE_ID = C_PLN_ORDER_LINE.ORDER_LINE_ID
                     AND A.ITEM_CODE = B.ITEM_CODE
                     AND B.PRODUCING_AREA_ID = C_PLN_COST_PRICE.PRODUCING_AREA_ID;
                EXCEPTION
                  WHEN OTHERS THEN
                  NULL;
                END;
                --判断产品在C_PLN_COST_PRICE.PRODUCING_AREA_NAME产地是否生产
                IF VS_ITEM_CODE <> '-1' THEN
                  IF C_PLN_ORDER_LINE.PRODUCING_AREA_ID <> C_PLN_COST_PRICE.PRODUCING_AREA_ID THEN
                    INSERT INTO T_PLN_ORDER_LINE
                      (ENTITY_ID,
                       ORDER_LINE_ID,
                       ORDER_HEAD_ID,
                       PRODUCING_AREA_ID,
                       PRODUCING_AREA_CODE,
                       PRODUCING_AREA_NAME,
                       ITEM_ID,
                       ITEM_CODE,
                       ITEM_DESC,
                       ITEM_UOM,
                       ITEM_PRICE,
                       APPLY_QTY,
                       CHECK_QTY,
                       CAN_PRODUCE_QTY, --?
                       AMOUNT,
                       STATUS,
                       CAN_SUPPLY_DATE,
                       BEGIN_SUPPLY_DATE,
                       END_SUPPLY_DATE,
                       ADJUST_QTY, --?
                       CREATED_BY,
                       CREATION_DATE,
                       LAST_UPDATED_BY,
                       LAST_UPDATE_DATE)
                      SELECT ENTITY_ID,
                             S_PLN_ORDER_LINE.NEXTVAL,
                             ORDER_HEAD_ID,
                             C_PLN_COST_PRICE.PRODUCING_AREA_ID,
                             C_PLN_COST_PRICE.PRODUCING_AREA_CODE,
                             C_PLN_COST_PRICE.PRODUCING_AREA_NAME,
                             ITEM_ID,
                             ITEM_CODE,
                             ITEM_DESC,
                             ITEM_UOM,
                             ITEM_PRICE,
                             0,
                             CHECK_QTY,
                             CAN_PRODUCE_QTY,
                             AMOUNT,
                             STATUS,
                             CAN_SUPPLY_DATE,
                             BEGIN_SUPPLY_DATE,
                             END_SUPPLY_DATE,
                             ADJUST_QTY,
                             P_CREATED_BY,
                             SYSDATE,
                             P_CREATED_BY,
                             SYSDATE
                        FROM T_PLN_ORDER_LINE
                       WHERE ORDER_LINE_ID = C_PLN_ORDER_LINE.ORDER_LINE_ID;

                      UPDATE T_PLN_ORDER_LINE
                         SET CHECK_QTY = 0,
                             CAN_PRODUCE_QTY = 0,
                             LAST_UPDATED_BY = P_CREATED_BY,
                             LAST_UPDATE_DATE = SYSDATE
                       WHERE ORDER_LINE_ID = C_PLN_ORDER_LINE.ORDER_LINE_ID;
                    EXIT;
                  ELSE
                    EXIT;
                  END IF;
                END IF;
              END LOOP;
            ELSE
              --区域辐射最优的产地
              FOR C_PLN_PRODUCING_AREA_PRIORITY2 IN (SELECT PRODUCING_AREA_ID,
                                                            PRODUCING_AREA_CODE,
                                                            PRODUCING_AREA_NAME
                                                       FROM T_PLN_CUSTOMER_PRIORITY
                                                      WHERE SALES_CENTER_CODE = C_PLN_ORDER_HEAD.SALES_CENTER_CODE
                                                        AND ITEM_CODE IS NULL
                                                        AND ENTITY_ID = P_ENTITY_ID
                                                      ORDER BY PRODUCING_AREA_PRIORITY) LOOP --取区域辐射最优
                --更新订单行产地信息
                --@@是否要返回不在C_PLN_PRODUCING_AREA_PRIORITY2.PRODUCING_AREA_NAME产地生产的产品？
                BEGIN
                  VS_ITEM_CODE := '-1';
                  SELECT A.ITEM_CODE --在C_PLN_PRODUCING_AREA_PRIORITY2.PRODUCING_AREA_NAME产地生产的产品
                    INTO VS_ITEM_CODE
                    FROM T_PLN_ORDER_LINE A, T_PLN_ITEM_PRODUCING_AREA B
                   WHERE A.ORDER_LINE_ID = C_PLN_ORDER_LINE.ORDER_LINE_ID
                     AND A.ITEM_CODE = B.ITEM_CODE
                     AND B.PRODUCING_AREA_ID = C_PLN_PRODUCING_AREA_PRIORITY2.PRODUCING_AREA_ID;
                EXCEPTION
                  WHEN OTHERS THEN
                  NULL;
                END;
                --判断产品在C_PLN_PRODUCING_AREA_PRIORITY2.PRODUCING_AREA_NAME产地是否生产
                IF VS_ITEM_CODE <> '-1' THEN
                  IF C_PLN_ORDER_LINE.PRODUCING_AREA_ID <> C_PLN_PRODUCING_AREA_PRIORITY2.PRODUCING_AREA_ID THEN
                    INSERT INTO T_PLN_ORDER_LINE
                      (ENTITY_ID,
                       ORDER_LINE_ID,
                       ORDER_HEAD_ID,
                       PRODUCING_AREA_ID,
                       PRODUCING_AREA_CODE,
                       PRODUCING_AREA_NAME,
                       ITEM_ID,
                       ITEM_CODE,
                       ITEM_DESC,
                       ITEM_UOM,
                       ITEM_PRICE,
                       APPLY_QTY,
                       CHECK_QTY,
                       CAN_PRODUCE_QTY, --?
                       AMOUNT,
                       STATUS,
                       CAN_SUPPLY_DATE,
                       BEGIN_SUPPLY_DATE,
                       END_SUPPLY_DATE,
                       ADJUST_QTY, --?
                       CREATED_BY,
                       CREATION_DATE,
                       LAST_UPDATED_BY,
                       LAST_UPDATE_DATE)
                      SELECT ENTITY_ID,
                             S_PLN_ORDER_LINE.NEXTVAL,
                             ORDER_HEAD_ID,
                             C_PLN_PRODUCING_AREA_PRIORITY2.PRODUCING_AREA_ID,
                             C_PLN_PRODUCING_AREA_PRIORITY2.PRODUCING_AREA_CODE,
                             C_PLN_PRODUCING_AREA_PRIORITY2.PRODUCING_AREA_NAME,
                             ITEM_ID,
                             ITEM_CODE,
                             ITEM_DESC,
                             ITEM_UOM,
                             ITEM_PRICE,
                             0,
                             CHECK_QTY,
                             CAN_PRODUCE_QTY,
                             AMOUNT,
                             STATUS,
                             CAN_SUPPLY_DATE,
                             BEGIN_SUPPLY_DATE,
                             END_SUPPLY_DATE,
                             ADJUST_QTY,
                             P_CREATED_BY,
                             SYSDATE,
                             P_CREATED_BY,
                             SYSDATE
                        FROM T_PLN_ORDER_LINE
                       WHERE ORDER_LINE_ID = C_PLN_ORDER_LINE.ORDER_LINE_ID;

                      UPDATE T_PLN_ORDER_LINE
                         SET CHECK_QTY = 0,
                             CAN_PRODUCE_QTY = 0,
                             LAST_UPDATED_BY = P_CREATED_BY,
                             LAST_UPDATE_DATE = SYSDATE
                       WHERE ORDER_LINE_ID = C_PLN_ORDER_LINE.ORDER_LINE_ID;
                    EXIT;
                  ELSE
                    EXIT;
                  END IF;
                END IF;
              END LOOP;
            END IF;
          END LOOP;

        --没有选择优先成本（区域辐射）
        ELSIF VS_COST_FLAG = 0 THEN
          --参与初次产地分解的订单行
          FOR C_PLN_ORDER_LINE IN (SELECT *
                                     FROM T_PLN_ORDER_LINE
                                    WHERE ORDER_HEAD_ID = C_PLN_ORDER_HEAD.ORDER_HEAD_ID
                                    ORDER BY ORDER_LINE_ID) LOOP
            --区域辐射最优的产地
            FOR C_PLN_PRODUCING_AREA_PRIORITY3 IN (SELECT PRODUCING_AREA_ID,
                                                          PRODUCING_AREA_CODE,
                                                          PRODUCING_AREA_NAME
                                                     FROM T_PLN_CUSTOMER_PRIORITY
                                                    WHERE SALES_CENTER_CODE = C_PLN_ORDER_HEAD.SALES_CENTER_CODE
                                                      AND ITEM_CODE IS NULL
                                                      AND ENTITY_ID = P_ENTITY_ID
                                                    ORDER BY PRODUCING_AREA_PRIORITY) LOOP --取区域辐射最优
              --更新订单行产地信息
              --@@是否要返回不在C_PLN_PRODUCING_AREA_PRIORITY3.PRODUCING_AREA_NAME产地生产的产品？
              BEGIN
                VS_ITEM_CODE := '-1';
                SELECT A.ITEM_CODE --在C_PLN_PRODUCING_AREA_PRIORITY3.PRODUCING_AREA_NAME产地生产的产品
                  INTO VS_ITEM_CODE
                  FROM T_PLN_ORDER_LINE A, T_PLN_ITEM_PRODUCING_AREA B
                 WHERE A.ORDER_LINE_ID = C_PLN_ORDER_LINE.ORDER_LINE_ID
                   AND A.ITEM_CODE = B.ITEM_CODE
                   AND B.PRODUCING_AREA_ID = C_PLN_PRODUCING_AREA_PRIORITY3.PRODUCING_AREA_ID;
              EXCEPTION
                WHEN OTHERS THEN
                NULL;
              END;
              --判断产品在C_PLN_PRODUCING_AREA_PRIORITY3.PRODUCING_AREA_NAME产地是否生产
              IF VS_ITEM_CODE <> '-1' THEN
                IF C_PLN_ORDER_LINE.PRODUCING_AREA_ID <> C_PLN_PRODUCING_AREA_PRIORITY3.PRODUCING_AREA_ID THEN
                  INSERT INTO T_PLN_ORDER_LINE
                    (ENTITY_ID,
                     ORDER_LINE_ID,
                     ORDER_HEAD_ID,
                     PRODUCING_AREA_ID,
                     PRODUCING_AREA_CODE,
                     PRODUCING_AREA_NAME,
                     ITEM_ID,
                     ITEM_CODE,
                     ITEM_DESC,
                     ITEM_UOM,
                     ITEM_PRICE,
                     APPLY_QTY,
                     CHECK_QTY,
                     CAN_PRODUCE_QTY, --?
                     AMOUNT,
                     STATUS,
                     CAN_SUPPLY_DATE,
                     BEGIN_SUPPLY_DATE,
                     END_SUPPLY_DATE,
                     ADJUST_QTY, --?
                     CREATED_BY,
                     CREATION_DATE,
                     LAST_UPDATED_BY,
                     LAST_UPDATE_DATE)
                    SELECT ENTITY_ID,
                           S_PLN_ORDER_LINE.NEXTVAL,
                           ORDER_HEAD_ID,
                           C_PLN_PRODUCING_AREA_PRIORITY3.PRODUCING_AREA_ID,
                           C_PLN_PRODUCING_AREA_PRIORITY3.PRODUCING_AREA_CODE,
                           C_PLN_PRODUCING_AREA_PRIORITY3.PRODUCING_AREA_NAME,
                           ITEM_ID,
                           ITEM_CODE,
                           ITEM_DESC,
                           ITEM_UOM,
                           ITEM_PRICE,
                           0,
                           CHECK_QTY,
                           CAN_PRODUCE_QTY,
                           AMOUNT,
                           STATUS,
                           CAN_SUPPLY_DATE,
                           BEGIN_SUPPLY_DATE,
                           END_SUPPLY_DATE,
                           ADJUST_QTY,
                           P_CREATED_BY,
                           SYSDATE,
                           P_CREATED_BY,
                           SYSDATE
                      FROM T_PLN_ORDER_LINE
                     WHERE ORDER_LINE_ID = C_PLN_ORDER_LINE.ORDER_LINE_ID;

                    UPDATE T_PLN_ORDER_LINE
                       SET CHECK_QTY = 0,
                           CAN_PRODUCE_QTY = 0,
                           LAST_UPDATED_BY = P_CREATED_BY,
                           LAST_UPDATE_DATE = SYSDATE
                     WHERE ORDER_LINE_ID = C_PLN_ORDER_LINE.ORDER_LINE_ID;
                  EXIT;
                ELSE
                  EXIT;
                END IF;
              END IF;
            END LOOP;
          END LOOP;
        END IF;

      ELSE
        P_RESULT := '营销中心：' || C_PLN_ORDER_HEAD.SALES_CENTER_CODE || ' ' || C_PLN_ORDER_HEAD.SALES_CENTER_NAME || '，在T_PLN_CUSTOMER_PRIORITY（中心供货优先级）中没有维护。';
        RETURN;
      END IF;

    END LOOP;

    DELETE FROM T_PLN_ORDER_MOULD_INTF WHERE ORDER_TYPE_ID = P_ORDER_TYPE_ID AND PERIOD_ID = P_PERIOD_ID AND ENTITY_ID = P_ENTITY_ID;
    DELETE FROM T_PLN_ORDER_TOTAL_INTF WHERE ORDER_TYPE_ID = P_ORDER_TYPE_ID AND PERIOD_ID = P_PERIOD_ID AND ENTITY_ID = P_ENTITY_ID;
    --插入模具临时表
    INSERT INTO T_PLN_ORDER_MOULD_INTF
      (ORDER_MOULD_INTF_ID,
       ORDER_TYPE_ID,
       PERIOD_ID,
       PLASTIC_CODE,
       PRODUCING_AREA_CODE,
       ORDER_QTY,
       PLASTIC_PRODUCTIVITY,
       SURPLUS_PRODUCTIVITY,
       ENTITY_ID,
       CREATED_BY,
       CREATION_DATE,
       LAST_UPDATED_BY,
       LAST_UPDATE_DATE)
      SELECT S_PLN_ORDER_MOULD_INTF.NEXTVAL,
             P_ORDER_TYPE_ID ORDER_TYPE_ID,
             P_PERIOD_ID PERIOD_ID,
             PLASTIC_CODE,
             PRODUCING_AREA_CODE,
             0,
             PLASTIC_PRODUCTIVITY,
             PLASTIC_PRODUCTIVITY - NVL(SURPLUS_PRODUCTIVITY, 0) SURPLUS_PRODUCTIVITY,
             P_ENTITY_ID,
             P_CREATED_BY,
             SYSDATE,
             P_CREATED_BY,
             SYSDATE
        FROM T_PLN_MOULD_PRODUCTIVITY_AREA
       WHERE PERIOD_ID = P_PERIOD_ID
         AND ENTITY_ID = P_ENTITY_ID;

    FOR C_PLN_ORDER_QTY IN (SELECT C.PLASTIC_CODE,
                                   B.PRODUCING_AREA_CODE,
                                   SUM(B.CHECK_QTY) ORDER_QTY
                              FROM T_PLN_ORDER_HEAD A, T_PLN_ORDER_LINE B, T_PLN_ITEM_PLASTIC C
                             WHERE A.ORDER_TYPE_ID = P_ORDER_TYPE_ID
                               AND A.PERIOD_ID = P_PERIOD_ID
                               AND A.FORM_STATE = 25
                               AND A.BATCH_ID = P_BATCH_ID
                               AND A.ENTITY_ID = P_ENTITY_ID
                               AND B.ORDER_HEAD_ID = A.ORDER_HEAD_ID
                               AND C.ITEM_CODE = B.ITEM_CODE
                             GROUP BY C.PLASTIC_CODE, B.PRODUCING_AREA_CODE) LOOP
      UPDATE T_PLN_ORDER_MOULD_INTF
         SET ORDER_QTY = ORDER_QTY + C_PLN_ORDER_QTY.ORDER_QTY
       WHERE PLASTIC_CODE = C_PLN_ORDER_QTY.PLASTIC_CODE
         AND PRODUCING_AREA_CODE = C_PLN_ORDER_QTY.PRODUCING_AREA_CODE
         AND ORDER_TYPE_ID = P_ORDER_TYPE_ID
         AND PERIOD_ID = P_PERIOD_ID
         AND ENTITY_ID = P_ENTITY_ID;
    END LOOP;
    --插入总装临时表
    INSERT INTO T_PLN_ORDER_TOTAL_INTF
      (ORDER_TOTAL_INTF_ID,
       ORDER_TYPE_ID,
       PERIOD_ID,
       PRODUCING_AREA_CODE,
       ORDER_QTY,
       TOTAL_PRODUCTIVITY,
       SURPLUS_PRODUCTIVITY,
       ENTITY_ID,
       CREATED_BY,
       CREATION_DATE,
       LAST_UPDATED_BY,
       LAST_UPDATE_DATE)
      SELECT S_PLN_ORDER_TOTAL_INTF.NEXTVAL,
             P_ORDER_TYPE_ID ORDER_TYPE_ID,
             P_PERIOD_ID PERIOD_ID,
             T.PRODUCING_AREA_CODE,
             0,
             T.TOTAL_PRODUCTIVITY,
             T.SURPLUS_PRODUCTIVITY SURPLUS_PRODUCTIVITY,
             P_ENTITY_ID,
             P_CREATED_BY,
             SYSDATE,
             P_CREATED_BY,
             SYSDATE
        FROM (SELECT PRODUCING_AREA_CODE,
                     SUM(PRODUCTIVITY) TOTAL_PRODUCTIVITY,
                     SUM(PRODUCTIVITY) - SUM(NVL(SURPLUS_PRODUCTIVITY, 0)) SURPLUS_PRODUCTIVITY
                FROM T_PLN_TOTAL_PRODUCTIVITY_AREA
               WHERE PERIOD_ID = P_PERIOD_ID
                 AND ENTITY_ID = P_ENTITY_ID
               GROUP BY PRODUCING_AREA_CODE) T;

    FOR C_PLN_ORDER_QTY1 IN (SELECT B.PRODUCING_AREA_CODE,
                                    SUM(B.CHECK_QTY) ORDER_QTY
                               FROM T_PLN_ORDER_HEAD A,
                                    T_PLN_ORDER_LINE B
                              WHERE A.ORDER_TYPE_ID = P_ORDER_TYPE_ID
                                AND A.PERIOD_ID = P_PERIOD_ID
                                AND A.FORM_STATE = 25
                                AND A.BATCH_ID = P_BATCH_ID
                                AND A.ENTITY_ID = P_ENTITY_ID
                                AND B.ORDER_HEAD_ID = A.ORDER_HEAD_ID
                              GROUP BY B.PRODUCING_AREA_CODE) LOOP
      UPDATE T_PLN_ORDER_TOTAL_INTF
         SET ORDER_QTY = ORDER_QTY + C_PLN_ORDER_QTY1.ORDER_QTY
       WHERE PRODUCING_AREA_CODE = C_PLN_ORDER_QTY1.PRODUCING_AREA_CODE
         AND ORDER_TYPE_ID = P_ORDER_TYPE_ID
         AND PERIOD_ID = P_PERIOD_ID
         AND ENTITY_ID = P_ENTITY_ID;
    END LOOP;

  EXCEPTION
    WHEN OTHERS THEN
      P_RESULT := '初次产地分解失败。' || V_NL || '失败信息：' || SQLERRM;
      ROLLBACK;
  END;

  ----------------------------------------------------------------------
  -- Author  : fenggq
  -- Created : 2014-09-17 14:16:00
  -- Purpose : 二次产地分解
  ----------------------------------------------------------------------
  PROCEDURE P_PRODUCING_AREA_ALLOT_2ND(P_ORDER_TYPE_ID IN NUMBER, --订单类型ID
                                       P_PERIOD_ID     IN NUMBER, --订单周期ID
                                       P_BATCH_ID      IN NUMBER, --批次ID
                                       P_ENTITY_ID     IN NUMBER, --主体ID
                                       P_CREATED_BY    IN VARCHAR2, --创建人
                                       P_RESULT        OUT VARCHAR2) IS

    --校验产品模具对应关系
    VS_ITEM_CODE            T_PLN_ORDER_LINE.ITEM_CODE%TYPE;
    VS_ITEM_NAME            T_PLN_ORDER_LINE.ITEM_DESC%TYPE;
    VS_PLASTIC_CODE         T_PLN_ITEM_PLASTIC.PLASTIC_CODE%TYPE;
    --校验产地模具对应关系
    VS_PLASTIC_NAME         T_PLN_ITEM_PLASTIC.PLASTIC_NAME%TYPE;
    VN_MOULD_COUNT          NUMBER;
    --校验产地总装对应关系
    VS_PRODUCING_AREA_NAME  T_PLN_PRODUCING_AREA.PRODUCING_AREA_NAME%TYPE;
    VN_TOTAL_COUNT          NUMBER;

    VN_COST_PRICE           T_PLN_CUSTOMER_PRIORITY.COST_PRICE%TYPE; --超出模具产能的产品成本
    VN_SUB_COST_PRICE       NUMBER; --成本差
    VN_CHECK_QTY            T_PLN_ORDER_LINE.CHECK_QTY%TYPE; --被调整产品数量
    VN_EXCESS_QTY           NUMBER; --超出模具剩余产能数量
    --VN_NEW_CHECK_QTY        T_PLN_ORDER_LINE.CHECK_QTY%TYPE; --待调整产品数量
    VN_SURPLUS_PRODUCTIVITY T_PLN_MOULD_PRODUCTIVITY_AREA.SURPLUS_PRODUCTIVITY%TYPE; --调整模具的剩余产能

  BEGIN
    P_RESULT := V_SUCCESS;

    DELETE FROM T_PLN_ORDER_MOULD_INTF WHERE ORDER_TYPE_ID = P_ORDER_TYPE_ID AND PERIOD_ID = P_PERIOD_ID AND ENTITY_ID = P_ENTITY_ID;

    --校验产品模具对应关系
    BEGIN
      FOR C_PLN_ORDER_ITEM IN
        (SELECT DISTINCT ITEM_CODE
           FROM T_PLN_ORDER_HEAD A,
                T_PLN_ORDER_LINE B
          WHERE A.ORDER_TYPE_ID = P_ORDER_TYPE_ID
            AND A.PERIOD_ID = P_PERIOD_ID
            AND A.FORM_STATE = 25
            AND A.BATCH_ID = P_BATCH_ID
            AND A.ENTITY_ID = P_ENTITY_ID
            AND B.ORDER_HEAD_ID = A.ORDER_HEAD_ID) LOOP

         VS_ITEM_CODE := C_PLN_ORDER_ITEM.ITEM_CODE;

         SELECT ITEM_NAME
           INTO VS_ITEM_NAME
           FROM T_BD_ITEM
          WHERE ITEM_CODE = C_PLN_ORDER_ITEM.ITEM_CODE
            AND ENTITY_ID = P_ENTITY_ID;

         SELECT PLASTIC_CODE
           INTO VS_PLASTIC_CODE
           FROM T_PLN_ITEM_PLASTIC
          WHERE ITEM_CODE = C_PLN_ORDER_ITEM.ITEM_CODE
            AND ENTITY_ID = P_ENTITY_ID;
      END LOOP;

    EXCEPTION
      WHEN OTHERS THEN
      P_RESULT := '产品：' || VS_ITEM_CODE || ' ' || VS_ITEM_NAME || '，没有维护产品模具对应关系。';
      RETURN;
    END;
    --校验产地模具对应关系
    BEGIN
      FOR C_PLN_ORDER_PLASTIC IN
        (SELECT DISTINCT PLASTIC_CODE
           FROM T_PLN_ORDER_HEAD A,
                T_PLN_ORDER_LINE B,
                T_PLN_ITEM_PLASTIC C
          WHERE A.ORDER_TYPE_ID = P_ORDER_TYPE_ID
            AND A.PERIOD_ID = P_PERIOD_ID
            AND A.FORM_STATE = 25
            AND A.BATCH_ID = P_BATCH_ID
            AND A.ENTITY_ID = P_ENTITY_ID
            AND B.ORDER_HEAD_ID = A.ORDER_HEAD_ID
            AND C.ITEM_CODE = B.ITEM_CODE) LOOP

         SELECT DISTINCT PLASTIC_NAME
           INTO VS_PLASTIC_NAME
           FROM T_PLN_ITEM_PLASTIC
          WHERE PLASTIC_CODE = C_PLN_ORDER_PLASTIC.PLASTIC_CODE
            AND ENTITY_ID = P_ENTITY_ID;

         SELECT COUNT(*)
           INTO VN_MOULD_COUNT
           FROM T_PLN_MOULD_PRODUCTIVITY_AREA
          WHERE PLASTIC_CODE = C_PLN_ORDER_PLASTIC.PLASTIC_CODE
            AND PERIOD_ID = P_PERIOD_ID
            AND ENTITY_ID = P_ENTITY_ID;

         IF VN_MOULD_COUNT = 0 THEN
           P_RESULT := '模具：' || C_PLN_ORDER_PLASTIC.PLASTIC_CODE || ' ' || VS_PLASTIC_NAME || '，没有维护产地模具对应关系。';
           RETURN;
         END IF;
      END LOOP;
    END;
    --校验产地总装对应关系
    BEGIN
      FOR C_PLN_ORDER_TOTAL IN
        (SELECT DISTINCT B.PRODUCING_AREA_CODE
           FROM T_PLN_ORDER_HEAD A,
                T_PLN_ORDER_LINE B
          WHERE A.ORDER_TYPE_ID = P_ORDER_TYPE_ID
            AND A.PERIOD_ID = P_PERIOD_ID
            AND A.FORM_STATE = 25
            AND A.BATCH_ID = P_BATCH_ID
            AND A.ENTITY_ID = P_ENTITY_ID
            AND B.ORDER_HEAD_ID = A.ORDER_HEAD_ID) LOOP

         SELECT PRODUCING_AREA_NAME
           INTO VS_PRODUCING_AREA_NAME
           FROM T_PLN_PRODUCING_AREA
          WHERE PRODUCING_AREA_CODE = C_PLN_ORDER_TOTAL.PRODUCING_AREA_CODE
            AND ENTITY_ID = P_ENTITY_ID;

         SELECT COUNT(*)
           INTO VN_TOTAL_COUNT
           FROM T_PLN_TOTAL_PRODUCTIVITY_AREA
          WHERE PRODUCING_AREA_CODE = C_PLN_ORDER_TOTAL.PRODUCING_AREA_CODE
            AND PERIOD_ID = P_PERIOD_ID
            AND ENTITY_ID = P_ENTITY_ID;

         IF VN_TOTAL_COUNT = 0 THEN
           P_RESULT := '产地：' || C_PLN_ORDER_TOTAL.PRODUCING_AREA_CODE || ' ' || VS_PRODUCING_AREA_NAME || '，没有维护产地总装对应关系。';
           RETURN;
         END IF;
      END LOOP;
    END;
    --插入模具临时表
    INSERT INTO T_PLN_ORDER_MOULD_INTF
      (ORDER_MOULD_INTF_ID,
       ORDER_TYPE_ID,
       PERIOD_ID,
       PLASTIC_CODE,
       PRODUCING_AREA_CODE,
       ORDER_QTY,
       PLASTIC_PRODUCTIVITY,
       SURPLUS_PRODUCTIVITY,
       ENTITY_ID,
       CREATED_BY,
       CREATION_DATE,
       LAST_UPDATED_BY,
       LAST_UPDATE_DATE)
      SELECT S_PLN_ORDER_MOULD_INTF.NEXTVAL,
             P_ORDER_TYPE_ID ORDER_TYPE_ID,
             P_PERIOD_ID PERIOD_ID,
             PLASTIC_CODE,
             PRODUCING_AREA_CODE,
             0,
             PLASTIC_PRODUCTIVITY,
             PLASTIC_PRODUCTIVITY - NVL(SURPLUS_PRODUCTIVITY, 0) SURPLUS_PRODUCTIVITY,
             P_ENTITY_ID,
             P_CREATED_BY,
             SYSDATE,
             P_CREATED_BY,
             SYSDATE
        FROM T_PLN_MOULD_PRODUCTIVITY_AREA
       WHERE PERIOD_ID = P_PERIOD_ID
         AND ENTITY_ID = P_ENTITY_ID;

    FOR C_PLN_ORDER_QTY IN (SELECT C.PLASTIC_CODE,
                                   B.PRODUCING_AREA_CODE,
                                   SUM(B.CHECK_QTY) ORDER_QTY
                              FROM T_PLN_ORDER_HEAD A, T_PLN_ORDER_LINE B, T_PLN_ITEM_PLASTIC C
                             WHERE A.ORDER_TYPE_ID = P_ORDER_TYPE_ID
                               AND A.PERIOD_ID = P_PERIOD_ID
                               AND A.FORM_STATE = 25
                               AND A.BATCH_ID = P_BATCH_ID
                               AND A.ENTITY_ID = P_ENTITY_ID
                               AND B.ORDER_HEAD_ID = A.ORDER_HEAD_ID
                               AND C.ITEM_CODE = B.ITEM_CODE
                             GROUP BY C.PLASTIC_CODE, B.PRODUCING_AREA_CODE) LOOP
      UPDATE T_PLN_ORDER_MOULD_INTF
         SET ORDER_QTY = ORDER_QTY + C_PLN_ORDER_QTY.ORDER_QTY
       WHERE PLASTIC_CODE = C_PLN_ORDER_QTY.PLASTIC_CODE
         AND PRODUCING_AREA_CODE = C_PLN_ORDER_QTY.PRODUCING_AREA_CODE
         AND ORDER_TYPE_ID = P_ORDER_TYPE_ID
         AND PERIOD_ID = P_PERIOD_ID
         AND ENTITY_ID = P_ENTITY_ID;
    END LOOP;

    --超出模具剩余产能的模具信息
    FOR C_PLN_EXCESS_PLASTIC IN
      (SELECT T1.PLASTIC_CODE,         --模具
              T1.PRODUCING_AREA_CODE,  --产地
              T1.ORDER_QTY,            --订单量
              NVL(T2.PLASTIC_PRODUCTIVITY, 0), --产能
              T2.SURPLUS_PRODUCTIVITY OCCUPIED_PRODUCTIVITY, --占用产能
              T2.PLASTIC_PRODUCTIVITY - NVL(T2.SURPLUS_PRODUCTIVITY, 0) SURPLUS_PRODUCTIVITY --剩余产能
         FROM
           (SELECT B.PLASTIC_CODE,
                   A.PRODUCING_AREA_CODE,
                   SUM(A.CHECK_QTY) ORDER_QTY
              FROM T_PLN_ORDER_LINE A, T_PLN_ITEM_PLASTIC B
             WHERE A.ORDER_HEAD_ID IN
               (SELECT ORDER_HEAD_ID
                  FROM T_PLN_ORDER_HEAD
                 WHERE ORDER_TYPE_ID = P_ORDER_TYPE_ID
                   AND PERIOD_ID = P_PERIOD_ID
                   AND FORM_STATE = 25
                   AND BATCH_ID = P_BATCH_ID
                   AND SALES_CENTER_CODE NOT IN
                     (SELECT SALES_CENTER_CODE
                        FROM T_PLN_CENTER_COST_RELATION
                       WHERE COST_FLAG = '1'
                         AND ENTITY_ID = P_ENTITY_ID)
                   AND ENTITY_ID = P_ENTITY_ID) --不参与产地分解的已送审订单
               AND A.ITEM_CODE = B.ITEM_CODE
             GROUP BY B.PLASTIC_CODE,
                      A.PRODUCING_AREA_CODE) T1, --产地模具订单量
           T_PLN_MOULD_PRODUCTIVITY_AREA T2 --产地模具产能
        WHERE T1.PLASTIC_CODE = T2.PLASTIC_CODE
          AND T1.PRODUCING_AREA_CODE = T2.PRODUCING_AREA_CODE
          AND T2.PERIOD_ID = P_PERIOD_ID
          AND T1.ORDER_QTY > (T2.PLASTIC_PRODUCTIVITY - NVL(T2.SURPLUS_PRODUCTIVITY, 0))) LOOP
      --超出模具剩余产能对应销司的产品信息
      FOR C_PLN_EXCESS_ITEM IN
        (SELECT A.SALES_CENTER_CODE,
                B.ITEM_CODE,
                B.CHECK_QTY
           FROM T_PLN_ORDER_HEAD A,
                T_PLN_ORDER_LINE B,
                T_PLN_ITEM_PLASTIC C
          WHERE A.ORDER_HEAD_ID IN
            (SELECT ORDER_HEAD_ID
               FROM T_PLN_ORDER_HEAD
              WHERE ORDER_TYPE_ID = P_ORDER_TYPE_ID
                AND PERIOD_ID = P_PERIOD_ID
                AND FORM_STATE = 25
                AND BATCH_ID = P_BATCH_ID
                AND SALES_CENTER_CODE NOT IN
                  (SELECT SALES_CENTER_CODE
                     FROM T_PLN_CENTER_COST_RELATION
                    WHERE COST_FLAG = '1'
                      AND ENTITY_ID = P_ENTITY_ID)
                AND ENTITY_ID = P_ENTITY_ID)
                AND A.BATCH_ID = P_BATCH_ID
                AND A.ORDER_HEAD_ID = B.ORDER_HEAD_ID
                AND B.PRODUCING_AREA_CODE = C_PLN_EXCESS_PLASTIC.PRODUCING_AREA_CODE
                AND B.ITEM_CODE = C.ITEM_CODE
                AND C.PLASTIC_CODE = C_PLN_EXCESS_PLASTIC.PLASTIC_CODE) LOOP

          BEGIN
            VN_COST_PRICE := -99999999;
            SELECT COST_PRICE
              INTO VN_COST_PRICE --超出模具产能的产品成本
              FROM T_PLN_CUSTOMER_PRIORITY
             WHERE SALES_CENTER_CODE = C_PLN_EXCESS_ITEM.SALES_CENTER_CODE
               AND ITEM_CODE = C_PLN_EXCESS_ITEM.ITEM_CODE
               AND PRODUCING_AREA_CODE = C_PLN_EXCESS_PLASTIC.PRODUCING_AREA_CODE
               AND ENTITY_ID = P_ENTITY_ID;
          EXCEPTION
            WHEN OTHERS THEN
            NULL;
          END;
          --原产地产品存在
          IF VN_COST_PRICE <> -99999999 THEN
            --目的产地产品存在，取产品综合成本差
            INSERT INTO T_PLN_COST_PRIORITY
              (SALES_CENTER_CODE,
               ITEM_CODE,
               OLD_PRODUCING_AREA_CODE,
               NEW_PRODUCING_AREA_CODE,
               SUB_COST_PRICE)
              SELECT A.SALES_CENTER_CODE,
                     A.ITEM_CODE,
                     C_PLN_EXCESS_PLASTIC.PRODUCING_AREA_CODE, --原产地
                     A.PRODUCING_AREA_CODE,
                     A.COST_PRICE - VN_COST_PRICE --成本差
                FROM T_PLN_CUSTOMER_PRIORITY A, T_PLN_ITEM_PRODUCING_AREA B
               WHERE A.SALES_CENTER_CODE = C_PLN_EXCESS_ITEM.SALES_CENTER_CODE
                 AND A.ITEM_CODE = C_PLN_EXCESS_ITEM.ITEM_CODE
                 AND A.PRODUCING_AREA_CODE <> C_PLN_EXCESS_PLASTIC.PRODUCING_AREA_CODE
                 AND A.ENTITY_ID = P_ENTITY_ID
                 AND B.ITEM_CODE = A.ITEM_CODE --判断产品在C_PLN_EXCESS_PLASTIC.PRODUCING_AREA_CODE以外的产地是否生产
                 AND B.PRODUCING_AREA_CODE = A.PRODUCING_AREA_CODE;
            --目的产地产品不存在，取销司区域辐射
            VN_SUB_COST_PRICE := 10000;
            FOR C_PLN_PRODUCING_AREA IN
              (SELECT A.PRODUCING_AREA_CODE
                 FROM T_PLN_CUSTOMER_PRIORITY A,
                      T_PLN_ITEM_PRODUCING_AREA B
                WHERE A.SALES_CENTER_CODE = C_PLN_EXCESS_ITEM.SALES_CENTER_CODE
                  AND A.ITEM_CODE IS NULL
                  AND A.PRODUCING_AREA_CODE <> C_PLN_EXCESS_PLASTIC.PRODUCING_AREA_CODE
                  AND A.ENTITY_ID = P_ENTITY_ID
                  AND B.ITEM_CODE = C_PLN_EXCESS_ITEM.ITEM_CODE --判断产品在C_PLN_EXCESS_PLASTIC.PRODUCING_AREA_CODE以外的产地是否生产
                  AND B.PRODUCING_AREA_CODE = A.PRODUCING_AREA_CODE
                ORDER BY A.PRODUCING_AREA_PRIORITY) LOOP
              VN_SUB_COST_PRICE := VN_SUB_COST_PRICE + 1;
              INSERT INTO T_PLN_COST_PRIORITY
                (SALES_CENTER_CODE,
                 ITEM_CODE,
                 OLD_PRODUCING_AREA_CODE,
                 NEW_PRODUCING_AREA_CODE,
                 SUB_COST_PRICE)
                VALUES(C_PLN_EXCESS_ITEM.SALES_CENTER_CODE,
                       C_PLN_EXCESS_ITEM.ITEM_CODE,
                       C_PLN_EXCESS_PLASTIC.PRODUCING_AREA_CODE,
                       C_PLN_PRODUCING_AREA.PRODUCING_AREA_CODE,
                       VN_SUB_COST_PRICE);
            END LOOP;
          --原产地产品不存在
          ELSE
            --目的产地产品存在，取产品综合成本
            INSERT INTO T_PLN_COST_PRIORITY
              (SALES_CENTER_CODE,
               ITEM_CODE,
               OLD_PRODUCING_AREA_CODE,
               NEW_PRODUCING_AREA_CODE,
               SUB_COST_PRICE)
              SELECT A.SALES_CENTER_CODE,
                     A.ITEM_CODE,
                     C_PLN_EXCESS_PLASTIC.PRODUCING_AREA_CODE, --原产地
                     A.PRODUCING_AREA_CODE,
                     ROWNUM + 10000 --成本差
                FROM T_PLN_CUSTOMER_PRIORITY A, T_PLN_ITEM_PRODUCING_AREA B
               WHERE A.SALES_CENTER_CODE = C_PLN_EXCESS_ITEM.SALES_CENTER_CODE
                 AND A.ITEM_CODE = C_PLN_EXCESS_ITEM.ITEM_CODE
                 AND A.PRODUCING_AREA_CODE <> C_PLN_EXCESS_PLASTIC.PRODUCING_AREA_CODE
                 AND A.ENTITY_ID = P_ENTITY_ID
                 AND B.ITEM_CODE = A.ITEM_CODE --判断产品在C_PLN_EXCESS_PLASTIC.PRODUCING_AREA_CODE以外的产地是否生产
                 AND B.PRODUCING_AREA_CODE = A.PRODUCING_AREA_CODE
               ORDER BY A.COST_PRICE;
            --目的产地产品不存在，取销司区域辐射
            VN_SUB_COST_PRICE := 10000;
            FOR C_PLN_PRODUCING_AREA2 IN
              (SELECT A.PRODUCING_AREA_CODE
                 FROM T_PLN_CUSTOMER_PRIORITY A,
                      T_PLN_ITEM_PRODUCING_AREA B
                WHERE A.SALES_CENTER_CODE = C_PLN_EXCESS_ITEM.SALES_CENTER_CODE
                  AND A.ITEM_CODE IS NULL
                  AND A.PRODUCING_AREA_CODE <> C_PLN_EXCESS_PLASTIC.PRODUCING_AREA_CODE
                  AND A.ENTITY_ID = P_ENTITY_ID
                  AND B.ITEM_CODE = C_PLN_EXCESS_ITEM.ITEM_CODE --判断产品在C_PLN_EXCESS_PLASTIC.PRODUCING_AREA_CODE以外的产地是否生产
                  AND B.PRODUCING_AREA_CODE = A.PRODUCING_AREA_CODE
                ORDER BY A.PRODUCING_AREA_PRIORITY) LOOP
              VN_SUB_COST_PRICE := VN_SUB_COST_PRICE + 1;
              INSERT INTO T_PLN_COST_PRIORITY
                (SALES_CENTER_CODE,
                 ITEM_CODE,
                 OLD_PRODUCING_AREA_CODE,
                 NEW_PRODUCING_AREA_CODE,
                 SUB_COST_PRICE)
                VALUES(C_PLN_EXCESS_ITEM.SALES_CENTER_CODE,
                       C_PLN_EXCESS_ITEM.ITEM_CODE,
                       C_PLN_EXCESS_PLASTIC.PRODUCING_AREA_CODE,
                       C_PLN_PRODUCING_AREA2.PRODUCING_AREA_CODE,
                       VN_SUB_COST_PRICE);
            END LOOP;
          END IF;
        END LOOP;

        --待调整销司的产品成本优先级
        FOR C_PLN_COST_PRIORITY IN
          (SELECT *
             FROM T_PLN_COST_PRIORITY
            ORDER BY SUB_COST_PRICE) LOOP

          SELECT B.CHECK_QTY
            INTO VN_CHECK_QTY --被调整产品数量
            FROM T_PLN_ORDER_HEAD A, T_PLN_ORDER_LINE B
           WHERE A.ORDER_TYPE_ID = P_ORDER_TYPE_ID
             AND A.PERIOD_ID = P_PERIOD_ID
             AND A.FORM_STATE = 25
             AND A.BATCH_ID = P_BATCH_ID
             AND A.ENTITY_ID = P_ENTITY_ID
             AND A.SALES_CENTER_CODE = C_PLN_COST_PRIORITY.SALES_CENTER_CODE
             AND B.ORDER_HEAD_ID = A.ORDER_HEAD_ID
             AND B.PRODUCING_AREA_CODE = C_PLN_COST_PRIORITY.OLD_PRODUCING_AREA_CODE
             AND B.ITEM_CODE = C_PLN_COST_PRIORITY.ITEM_CODE;

          SELECT ORDER_QTY - SURPLUS_PRODUCTIVITY
            INTO VN_EXCESS_QTY --超出模具剩余产能数量
            FROM T_PLN_ORDER_MOULD_INTF
           WHERE ORDER_TYPE_ID = P_ORDER_TYPE_ID
             AND PERIOD_ID = P_PERIOD_ID
             AND PLASTIC_CODE = C_PLN_EXCESS_PLASTIC.PLASTIC_CODE
             AND PRODUCING_AREA_CODE = C_PLN_EXCESS_PLASTIC.PRODUCING_AREA_CODE
             AND ENTITY_ID = P_ENTITY_ID;

          BEGIN
            VN_SURPLUS_PRODUCTIVITY := -99999999;
            SELECT SURPLUS_PRODUCTIVITY - ORDER_QTY
              INTO VN_SURPLUS_PRODUCTIVITY --待调整模具的剩余产能
              FROM T_PLN_ORDER_MOULD_INTF
             WHERE ORDER_TYPE_ID = P_ORDER_TYPE_ID
               AND PERIOD_ID = P_PERIOD_ID
               AND PLASTIC_CODE = C_PLN_EXCESS_PLASTIC.PLASTIC_CODE
               AND PRODUCING_AREA_CODE = C_PLN_COST_PRIORITY.NEW_PRODUCING_AREA_CODE
               AND ENTITY_ID = P_ENTITY_ID;
          EXCEPTION
            WHEN OTHERS THEN
            NULL;
          END;

          /*BEGIN
            VN_NEW_CHECK_QTY := -1;
            SELECT B.CHECK_QTY
              INTO VN_NEW_CHECK_QTY --待调整产品数量
              FROM T_PLN_ORDER_HEAD A, T_PLN_ORDER_LINE B
             WHERE A.ORDER_TYPE_ID = P_ORDER_TYPE_ID
               AND A.PERIOD_ID = P_PERIOD_ID
               AND A.FORM_STATE = 25
               AND A.BATCH_ID = P_BATCH_ID
               AND A.ENTITY_ID = P_ENTITY_ID
               AND A.SALES_CENTER_CODE = C_PLN_COST_PRIORITY.SALES_CENTER_CODE
               AND B.ORDER_HEAD_ID = A.ORDER_HEAD_ID
               AND B.PRODUCING_AREA_CODE = C_PLN_COST_PRIORITY.NEW_PRODUCING_AREA_CODE
               AND B.ITEM_CODE = C_PLN_COST_PRIORITY.ITEM_CODE;
           EXCEPTION
             WHEN OTHERS THEN
             NULL;
          END;
          --判断待调整产品数量是否存在
          IF VN_NEW_CHECK_QTY <> -1 THEN
            BEGIN
              VN_SURPLUS_PRODUCTIVITY := -99999999;
              SELECT PLASTIC_PRODUCTIVITY - NVL(SURPLUS_PRODUCTIVITY, 0) - VN_NEW_CHECK_QTY SURPLUS_PRODUCTIVITY
                INTO VN_SURPLUS_PRODUCTIVITY --待调整模具的剩余产能
                FROM T_PLN_MOULD_PRODUCTIVITY_AREA
               WHERE PERIOD_ID = P_PERIOD_ID
                 AND PLASTIC_CODE = C_PLN_EXCESS_PLASTIC.PLASTIC_CODE
                 AND PRODUCING_AREA_CODE = C_PLN_COST_PRIORITY.NEW_PRODUCING_AREA_CODE
                 AND ENTITY_ID = P_ENTITY_ID;
            EXCEPTION
              WHEN OTHERS THEN
              NULL;
            END;
          ELSE
            BEGIN
              VN_SURPLUS_PRODUCTIVITY := -99999999;
              SELECT PLASTIC_PRODUCTIVITY - NVL(SURPLUS_PRODUCTIVITY, 0) SURPLUS_PRODUCTIVITY
                INTO VN_SURPLUS_PRODUCTIVITY --待调整模具的剩余产能
                FROM T_PLN_MOULD_PRODUCTIVITY_AREA
               WHERE PERIOD_ID = P_PERIOD_ID
                 AND PLASTIC_CODE = C_PLN_EXCESS_PLASTIC.PLASTIC_CODE
                 AND PRODUCING_AREA_CODE = C_PLN_COST_PRIORITY.NEW_PRODUCING_AREA_CODE
                 AND ENTITY_ID = P_ENTITY_ID;
            EXCEPTION
              WHEN OTHERS THEN
              NULL;
            END;
          END IF;*/
          --判断待调整模具的剩余产能是否存在
          IF VN_SURPLUS_PRODUCTIVITY = -99999999 THEN
            SELECT ITEM_NAME
              INTO VS_ITEM_NAME
              FROM T_BD_ITEM
             WHERE ITEM_CODE = C_PLN_COST_PRIORITY.ITEM_CODE
               AND ENTITY_ID = P_ENTITY_ID;

            SELECT PRODUCING_AREA_NAME
              INTO VS_PRODUCING_AREA_NAME
              FROM T_PLN_PRODUCING_AREA
             WHERE PRODUCING_AREA_CODE = C_PLN_COST_PRIORITY.NEW_PRODUCING_AREA_CODE
               AND ENTITY_ID = P_ENTITY_ID;
            P_RESULT := '产品：' || C_PLN_COST_PRIORITY.ITEM_CODE || ' ' || VS_ITEM_NAME || '在'
              || C_PLN_COST_PRIORITY.NEW_PRODUCING_AREA_CODE || ' ' || VS_PRODUCING_AREA_NAME || '可以生产，但T_PLN_MOULD_PRODUCTIVITY_AREA（产地-模具产能维护）没有维护该产地。';
            ROLLBACK;
            RETURN;
          ELSE
            --判断新产地是否有模具剩余产能
            IF VN_SURPLUS_PRODUCTIVITY >= VN_EXCESS_QTY AND VN_CHECK_QTY > 0 AND VN_EXCESS_QTY > 0 AND VN_SURPLUS_PRODUCTIVITY > 0 THEN
              --判断超剩余产能数量是否大于被调整产品数量
              IF VN_EXCESS_QTY >= VN_CHECK_QTY THEN
                INSERT INTO T_PLN_ORDER_LINE
                  (ENTITY_ID,
                   ORDER_LINE_ID,
                   ORDER_HEAD_ID,
                   PRODUCING_AREA_ID,
                   PRODUCING_AREA_CODE,
                   PRODUCING_AREA_NAME,
                   ITEM_ID,
                   ITEM_CODE,
                   ITEM_DESC,
                   ITEM_UOM,
                   ITEM_PRICE,
                   APPLY_QTY,
                   CHECK_QTY,
                   CAN_PRODUCE_QTY, --?
                   AMOUNT,
                   STATUS,
                   CAN_SUPPLY_DATE,
                   BEGIN_SUPPLY_DATE,
                   END_SUPPLY_DATE,
                   ADJUST_QTY, --?
                   CREATED_BY,
                   CREATION_DATE,
                   LAST_UPDATED_BY,
                   LAST_UPDATE_DATE)
                  SELECT P_ENTITY_ID,
                         S_PLN_ORDER_LINE.NEXTVAL,
                         B.ORDER_HEAD_ID,
                         (SELECT PRODUCING_AREA_ID
                            FROM T_PLN_PRODUCING_AREA
                           WHERE PRODUCING_AREA_CODE = C_PLN_COST_PRIORITY.NEW_PRODUCING_AREA_CODE
                             AND ENTITY_ID = P_ENTITY_ID),
                         C_PLN_COST_PRIORITY.NEW_PRODUCING_AREA_CODE,
                         (SELECT PRODUCING_AREA_NAME
                            FROM T_PLN_PRODUCING_AREA
                           WHERE PRODUCING_AREA_CODE = C_PLN_COST_PRIORITY.NEW_PRODUCING_AREA_CODE
                             AND ENTITY_ID = P_ENTITY_ID),
                         B.ITEM_ID,
                         B.ITEM_CODE,
                         B.ITEM_DESC,
                         B.ITEM_UOM,
                         B.ITEM_PRICE,
                         0,
                         VN_CHECK_QTY,
                         VN_CHECK_QTY,
                         B.AMOUNT,
                         B.STATUS,
                         B.CAN_SUPPLY_DATE,
                         B.BEGIN_SUPPLY_DATE,
                         B.END_SUPPLY_DATE,
                         B.ADJUST_QTY,
                         P_CREATED_BY,
                         SYSDATE,
                         P_CREATED_BY,
                         SYSDATE
                    FROM T_PLN_ORDER_HEAD A, T_PLN_ORDER_LINE B
                   WHERE A.SALES_CENTER_CODE = C_PLN_COST_PRIORITY.SALES_CENTER_CODE
                     AND A.ORDER_TYPE_ID = P_ORDER_TYPE_ID
                     AND A.PERIOD_ID = P_PERIOD_ID
                     AND A.FORM_STATE = 25
                     AND A.BATCH_ID = P_BATCH_ID
                     AND A.ENTITY_ID = P_ENTITY_ID
                     AND B.ORDER_HEAD_ID = A.ORDER_HEAD_ID
                     AND B.PRODUCING_AREA_CODE = C_PLN_COST_PRIORITY.OLD_PRODUCING_AREA_CODE
                     AND B.ITEM_CODE = C_PLN_COST_PRIORITY.ITEM_CODE;

                UPDATE T_PLN_ORDER_LINE B
                   SET B.CHECK_QTY = B.CHECK_QTY - VN_CHECK_QTY,
                       B.CAN_PRODUCE_QTY = B.CHECK_QTY - VN_CHECK_QTY,
                       B.ADJUST_QTY = B.ADJUST_QTY, --?
                       B.LAST_UPDATED_BY = P_CREATED_BY,
                       B.LAST_UPDATE_DATE = SYSDATE
                 WHERE B.ORDER_HEAD_ID =
                   (SELECT A.ORDER_HEAD_ID
                      FROM T_PLN_ORDER_HEAD A
                     WHERE A.SALES_CENTER_CODE = C_PLN_COST_PRIORITY.SALES_CENTER_CODE
                       AND A.ORDER_TYPE_ID = P_ORDER_TYPE_ID
                       AND A.PERIOD_ID = P_PERIOD_ID
                       AND A.FORM_STATE = 25
                       AND A.BATCH_ID = P_BATCH_ID
                       AND A.ENTITY_ID = P_ENTITY_ID)
                   AND B.PRODUCING_AREA_CODE = C_PLN_COST_PRIORITY.OLD_PRODUCING_AREA_CODE
                   AND B.ITEM_CODE = C_PLN_COST_PRIORITY.ITEM_CODE;
                --更新订单模具产能临时表（原产地）
                UPDATE T_PLN_ORDER_MOULD_INTF
                   SET ORDER_QTY = ORDER_QTY - VN_CHECK_QTY
                 WHERE ORDER_TYPE_ID = P_ORDER_TYPE_ID
                   AND PERIOD_ID = P_PERIOD_ID
                   AND PLASTIC_CODE = C_PLN_EXCESS_PLASTIC.PLASTIC_CODE
                   AND PRODUCING_AREA_CODE = C_PLN_EXCESS_PLASTIC.PRODUCING_AREA_CODE
                   AND ENTITY_ID = P_ENTITY_ID;
                --更新订单模具产能临时表（目的产地）
                UPDATE T_PLN_ORDER_MOULD_INTF
                   SET ORDER_QTY = ORDER_QTY + VN_CHECK_QTY
                 WHERE ORDER_TYPE_ID = P_ORDER_TYPE_ID
                   AND PERIOD_ID = P_PERIOD_ID
                   AND PLASTIC_CODE = C_PLN_EXCESS_PLASTIC.PLASTIC_CODE
                   AND PRODUCING_AREA_CODE = C_PLN_COST_PRIORITY.NEW_PRODUCING_AREA_CODE
                   AND ENTITY_ID = P_ENTITY_ID;
                --@@缺少更新订单行与订单汇总行关系表
              ELSE
                INSERT INTO T_PLN_ORDER_LINE
                  (ENTITY_ID,
                   ORDER_LINE_ID,
                   ORDER_HEAD_ID,
                   PRODUCING_AREA_ID,
                   PRODUCING_AREA_CODE,
                   PRODUCING_AREA_NAME,
                   ITEM_ID,
                   ITEM_CODE,
                   ITEM_DESC,
                   ITEM_UOM,
                   ITEM_PRICE,
                   APPLY_QTY,
                   CHECK_QTY,
                   CAN_PRODUCE_QTY, --?
                   AMOUNT,
                   STATUS,
                   CAN_SUPPLY_DATE,
                   BEGIN_SUPPLY_DATE,
                   END_SUPPLY_DATE,
                   ADJUST_QTY, --?
                   CREATED_BY,
                   CREATION_DATE,
                   LAST_UPDATED_BY,
                   LAST_UPDATE_DATE)
                  SELECT P_ENTITY_ID,
                         S_PLN_ORDER_LINE.NEXTVAL,
                         B.ORDER_HEAD_ID,
                         (SELECT PRODUCING_AREA_ID
                            FROM T_PLN_PRODUCING_AREA
                           WHERE PRODUCING_AREA_CODE = C_PLN_COST_PRIORITY.NEW_PRODUCING_AREA_CODE
                             AND ENTITY_ID = P_ENTITY_ID),
                         C_PLN_COST_PRIORITY.NEW_PRODUCING_AREA_CODE,
                         (SELECT PRODUCING_AREA_NAME
                            FROM T_PLN_PRODUCING_AREA
                           WHERE PRODUCING_AREA_CODE = C_PLN_COST_PRIORITY.NEW_PRODUCING_AREA_CODE
                             AND ENTITY_ID = P_ENTITY_ID),
                         B.ITEM_ID,
                         B.ITEM_CODE,
                         B.ITEM_DESC,
                         B.ITEM_UOM,
                         B.ITEM_PRICE,
                         0,
                         VN_EXCESS_QTY,
                         VN_EXCESS_QTY,
                         B.AMOUNT,
                         B.STATUS,
                         B.CAN_SUPPLY_DATE,
                         B.BEGIN_SUPPLY_DATE,
                         B.END_SUPPLY_DATE,
                         B.ADJUST_QTY,
                         P_CREATED_BY,
                         SYSDATE,
                         P_CREATED_BY,
                         SYSDATE
                    FROM T_PLN_ORDER_HEAD A, T_PLN_ORDER_LINE B
                   WHERE A.SALES_CENTER_CODE = C_PLN_COST_PRIORITY.SALES_CENTER_CODE
                     AND A.ORDER_TYPE_ID = P_ORDER_TYPE_ID
                     AND A.PERIOD_ID = P_PERIOD_ID
                     AND A.FORM_STATE = 25
                     AND A.BATCH_ID = P_BATCH_ID
                     AND A.ENTITY_ID = P_ENTITY_ID
                     AND B.ORDER_HEAD_ID = A.ORDER_HEAD_ID
                     AND B.PRODUCING_AREA_CODE = C_PLN_COST_PRIORITY.OLD_PRODUCING_AREA_CODE
                     AND B.ITEM_CODE = C_PLN_COST_PRIORITY.ITEM_CODE;

                UPDATE T_PLN_ORDER_LINE B
                   SET B.CHECK_QTY = B.CHECK_QTY - VN_EXCESS_QTY,
                       B.CAN_PRODUCE_QTY = B.CHECK_QTY - VN_EXCESS_QTY,
                       B.ADJUST_QTY = B.ADJUST_QTY, --?
                       B.LAST_UPDATED_BY = P_CREATED_BY,
                       B.LAST_UPDATE_DATE = SYSDATE
                 WHERE B.ORDER_HEAD_ID =
                   (SELECT A.ORDER_HEAD_ID
                      FROM T_PLN_ORDER_HEAD A
                     WHERE A.SALES_CENTER_CODE = C_PLN_COST_PRIORITY.SALES_CENTER_CODE
                       AND A.ORDER_TYPE_ID = P_ORDER_TYPE_ID
                       AND A.PERIOD_ID = P_PERIOD_ID
                       AND A.FORM_STATE = 25
                       AND A.BATCH_ID = P_BATCH_ID
                       AND A.ENTITY_ID = P_ENTITY_ID)
                   AND B.PRODUCING_AREA_CODE = C_PLN_COST_PRIORITY.OLD_PRODUCING_AREA_CODE
                   AND B.ITEM_CODE = C_PLN_COST_PRIORITY.ITEM_CODE;
                --更新订单模具产能临时表（原产地）
                UPDATE T_PLN_ORDER_MOULD_INTF
                   SET ORDER_QTY = ORDER_QTY - VN_EXCESS_QTY
                 WHERE ORDER_TYPE_ID = P_ORDER_TYPE_ID
                   AND PERIOD_ID = P_PERIOD_ID
                   AND PLASTIC_CODE = C_PLN_EXCESS_PLASTIC.PLASTIC_CODE
                   AND PRODUCING_AREA_CODE = C_PLN_EXCESS_PLASTIC.PRODUCING_AREA_CODE
                   AND ENTITY_ID = P_ENTITY_ID;
                --更新订单模具产能临时表（目的产地）
                UPDATE T_PLN_ORDER_MOULD_INTF
                   SET ORDER_QTY = ORDER_QTY + VN_EXCESS_QTY
                 WHERE ORDER_TYPE_ID = P_ORDER_TYPE_ID
                   AND PERIOD_ID = P_PERIOD_ID
                   AND PLASTIC_CODE = C_PLN_EXCESS_PLASTIC.PLASTIC_CODE
                   AND PRODUCING_AREA_CODE = C_PLN_COST_PRIORITY.NEW_PRODUCING_AREA_CODE
                   AND ENTITY_ID = P_ENTITY_ID;

                --@@缺少更新订单行与订单汇总行关系表
              END IF;
            ELSIF VN_SURPLUS_PRODUCTIVITY < VN_EXCESS_QTY AND VN_CHECK_QTY > 0 AND VN_EXCESS_QTY > 0 AND VN_SURPLUS_PRODUCTIVITY > 0 THEN
              --判断待调整模具的剩余产能是否大于被调整产品数量
              IF VN_SURPLUS_PRODUCTIVITY >= VN_CHECK_QTY THEN
                INSERT INTO T_PLN_ORDER_LINE
                  (ENTITY_ID,
                   ORDER_LINE_ID,
                   ORDER_HEAD_ID,
                   PRODUCING_AREA_ID,
                   PRODUCING_AREA_CODE,
                   PRODUCING_AREA_NAME,
                   ITEM_ID,
                   ITEM_CODE,
                   ITEM_DESC,
                   ITEM_UOM,
                   ITEM_PRICE,
                   APPLY_QTY,
                   CHECK_QTY,
                   CAN_PRODUCE_QTY, --?
                   AMOUNT,
                   STATUS,
                   CAN_SUPPLY_DATE,
                   BEGIN_SUPPLY_DATE,
                   END_SUPPLY_DATE,
                   ADJUST_QTY, --?
                   CREATED_BY,
                   CREATION_DATE,
                   LAST_UPDATED_BY,
                   LAST_UPDATE_DATE)
                  SELECT P_ENTITY_ID,
                         S_PLN_ORDER_LINE.NEXTVAL,
                         B.ORDER_HEAD_ID,
                         (SELECT PRODUCING_AREA_ID
                            FROM T_PLN_PRODUCING_AREA
                           WHERE PRODUCING_AREA_CODE = C_PLN_COST_PRIORITY.NEW_PRODUCING_AREA_CODE
                             AND ENTITY_ID = P_ENTITY_ID),
                         C_PLN_COST_PRIORITY.NEW_PRODUCING_AREA_CODE,
                         (SELECT PRODUCING_AREA_NAME
                            FROM T_PLN_PRODUCING_AREA
                           WHERE PRODUCING_AREA_CODE = C_PLN_COST_PRIORITY.NEW_PRODUCING_AREA_CODE
                             AND ENTITY_ID = P_ENTITY_ID),
                         B.ITEM_ID,
                         B.ITEM_CODE,
                         B.ITEM_DESC,
                         B.ITEM_UOM,
                         B.ITEM_PRICE,
                         0,
                         VN_CHECK_QTY,
                         VN_CHECK_QTY,
                         B.AMOUNT,
                         B.STATUS,
                         B.CAN_SUPPLY_DATE,
                         B.BEGIN_SUPPLY_DATE,
                         B.END_SUPPLY_DATE,
                         B.ADJUST_QTY,
                         P_CREATED_BY,
                         SYSDATE,
                         P_CREATED_BY,
                         SYSDATE
                    FROM T_PLN_ORDER_HEAD A, T_PLN_ORDER_LINE B
                   WHERE A.SALES_CENTER_CODE = C_PLN_COST_PRIORITY.SALES_CENTER_CODE
                     AND A.ORDER_TYPE_ID = P_ORDER_TYPE_ID
                     AND A.PERIOD_ID = P_PERIOD_ID
                     AND A.FORM_STATE = 25
                     AND A.BATCH_ID = P_BATCH_ID
                     AND A.ENTITY_ID = P_ENTITY_ID
                     AND B.ORDER_HEAD_ID = A.ORDER_HEAD_ID
                     AND B.PRODUCING_AREA_CODE = C_PLN_COST_PRIORITY.OLD_PRODUCING_AREA_CODE
                     AND B.ITEM_CODE = C_PLN_COST_PRIORITY.ITEM_CODE;
                --更新订单行
                UPDATE T_PLN_ORDER_LINE B
                   SET B.CHECK_QTY = B.CHECK_QTY - VN_CHECK_QTY,
                       B.CAN_PRODUCE_QTY = B.CHECK_QTY - VN_CHECK_QTY,
                       B.ADJUST_QTY = B.ADJUST_QTY, --?
                       B.LAST_UPDATED_BY = P_CREATED_BY,
                       B.LAST_UPDATE_DATE = SYSDATE
                 WHERE B.ORDER_HEAD_ID =
                   (SELECT A.ORDER_HEAD_ID
                      FROM T_PLN_ORDER_HEAD A
                     WHERE A.SALES_CENTER_CODE = C_PLN_COST_PRIORITY.SALES_CENTER_CODE
                       AND A.ORDER_TYPE_ID = P_ORDER_TYPE_ID
                       AND A.PERIOD_ID = P_PERIOD_ID
                       AND A.FORM_STATE = 25
                       AND A.BATCH_ID = P_BATCH_ID
                       AND A.ENTITY_ID = P_ENTITY_ID)
                   AND B.PRODUCING_AREA_CODE = C_PLN_COST_PRIORITY.OLD_PRODUCING_AREA_CODE
                   AND B.ITEM_CODE = C_PLN_COST_PRIORITY.ITEM_CODE;
                --更新订单模具产能临时表（原产地）
                UPDATE T_PLN_ORDER_MOULD_INTF
                   SET ORDER_QTY = ORDER_QTY - VN_CHECK_QTY
                 WHERE ORDER_TYPE_ID = P_ORDER_TYPE_ID
                   AND PERIOD_ID = P_PERIOD_ID
                   AND PLASTIC_CODE = C_PLN_EXCESS_PLASTIC.PLASTIC_CODE
                   AND PRODUCING_AREA_CODE = C_PLN_EXCESS_PLASTIC.PRODUCING_AREA_CODE
                   AND ENTITY_ID = P_ENTITY_ID;
                --更新订单模具产能临时表（目的产地）
                UPDATE T_PLN_ORDER_MOULD_INTF
                   SET ORDER_QTY = ORDER_QTY + VN_CHECK_QTY
                 WHERE ORDER_TYPE_ID = P_ORDER_TYPE_ID
                   AND PERIOD_ID = P_PERIOD_ID
                   AND PLASTIC_CODE = C_PLN_EXCESS_PLASTIC.PLASTIC_CODE
                   AND PRODUCING_AREA_CODE = C_PLN_COST_PRIORITY.NEW_PRODUCING_AREA_CODE
                   AND ENTITY_ID = P_ENTITY_ID;

                --@@缺少更新订单行与订单汇总行关系表
              ELSE
                INSERT INTO T_PLN_ORDER_LINE
                  (ENTITY_ID,
                   ORDER_LINE_ID,
                   ORDER_HEAD_ID,
                   PRODUCING_AREA_ID,
                   PRODUCING_AREA_CODE,
                   PRODUCING_AREA_NAME,
                   ITEM_ID,
                   ITEM_CODE,
                   ITEM_DESC,
                   ITEM_UOM,
                   ITEM_PRICE,
                   APPLY_QTY,
                   CHECK_QTY,
                   CAN_PRODUCE_QTY, --?
                   AMOUNT,
                   STATUS,
                   CAN_SUPPLY_DATE,
                   BEGIN_SUPPLY_DATE,
                   END_SUPPLY_DATE,
                   ADJUST_QTY, --?
                   CREATED_BY,
                   CREATION_DATE,
                   LAST_UPDATED_BY,
                   LAST_UPDATE_DATE)
                  SELECT P_ENTITY_ID,
                         S_PLN_ORDER_LINE.NEXTVAL,
                         B.ORDER_HEAD_ID,
                         (SELECT PRODUCING_AREA_ID
                            FROM T_PLN_PRODUCING_AREA
                           WHERE PRODUCING_AREA_CODE = C_PLN_COST_PRIORITY.NEW_PRODUCING_AREA_CODE
                             AND ENTITY_ID = P_ENTITY_ID),
                         C_PLN_COST_PRIORITY.NEW_PRODUCING_AREA_CODE,
                         (SELECT PRODUCING_AREA_NAME
                            FROM T_PLN_PRODUCING_AREA
                           WHERE PRODUCING_AREA_CODE = C_PLN_COST_PRIORITY.NEW_PRODUCING_AREA_CODE
                             AND ENTITY_ID = P_ENTITY_ID),
                         B.ITEM_ID,
                         B.ITEM_CODE,
                         B.ITEM_DESC,
                         B.ITEM_UOM,
                         B.ITEM_PRICE,
                         0,
                         VN_SURPLUS_PRODUCTIVITY,
                         VN_SURPLUS_PRODUCTIVITY,
                         B.AMOUNT,
                         B.STATUS,
                         B.CAN_SUPPLY_DATE,
                         B.BEGIN_SUPPLY_DATE,
                         B.END_SUPPLY_DATE,
                         B.ADJUST_QTY,
                         P_CREATED_BY,
                         SYSDATE,
                         P_CREATED_BY,
                         SYSDATE
                    FROM T_PLN_ORDER_HEAD A, T_PLN_ORDER_LINE B
                   WHERE A.SALES_CENTER_CODE = C_PLN_COST_PRIORITY.SALES_CENTER_CODE
                     AND A.ORDER_TYPE_ID = P_ORDER_TYPE_ID
                     AND A.PERIOD_ID = P_PERIOD_ID
                     AND A.FORM_STATE = 25
                     AND A.BATCH_ID = P_BATCH_ID
                     AND A.ENTITY_ID = P_ENTITY_ID
                     AND B.ORDER_HEAD_ID = A.ORDER_HEAD_ID
                     AND B.PRODUCING_AREA_CODE = C_PLN_COST_PRIORITY.OLD_PRODUCING_AREA_CODE
                     AND B.ITEM_CODE = C_PLN_COST_PRIORITY.ITEM_CODE;
                --更新订单行
                UPDATE T_PLN_ORDER_LINE B
                   SET B.CHECK_QTY = B.CHECK_QTY - VN_SURPLUS_PRODUCTIVITY,
                       B.CAN_PRODUCE_QTY = B.CHECK_QTY - VN_SURPLUS_PRODUCTIVITY,
                       B.ADJUST_QTY = B.ADJUST_QTY, --?
                       B.LAST_UPDATED_BY = P_CREATED_BY,
                       B.LAST_UPDATE_DATE = SYSDATE
                 WHERE B.ORDER_HEAD_ID =
                   (SELECT A.ORDER_HEAD_ID
                      FROM T_PLN_ORDER_HEAD A
                     WHERE A.SALES_CENTER_CODE = C_PLN_COST_PRIORITY.SALES_CENTER_CODE
                       AND A.ORDER_TYPE_ID = P_ORDER_TYPE_ID
                       AND A.PERIOD_ID = P_PERIOD_ID
                       AND A.FORM_STATE = 25
                       AND A.BATCH_ID = P_BATCH_ID
                       AND A.ENTITY_ID = P_ENTITY_ID)
                   AND B.PRODUCING_AREA_CODE = C_PLN_COST_PRIORITY.OLD_PRODUCING_AREA_CODE
                   AND B.ITEM_CODE = C_PLN_COST_PRIORITY.ITEM_CODE;
                --更新订单模具产能临时表（原产地）
                UPDATE T_PLN_ORDER_MOULD_INTF
                   SET ORDER_QTY = ORDER_QTY - VN_SURPLUS_PRODUCTIVITY
                 WHERE ORDER_TYPE_ID = P_ORDER_TYPE_ID
                   AND PERIOD_ID = P_PERIOD_ID
                   AND PLASTIC_CODE = C_PLN_EXCESS_PLASTIC.PLASTIC_CODE
                   AND PRODUCING_AREA_CODE = C_PLN_EXCESS_PLASTIC.PRODUCING_AREA_CODE
                   AND ENTITY_ID = P_ENTITY_ID;
                --更新订单模具产能临时表（目的产地）
                UPDATE T_PLN_ORDER_MOULD_INTF
                   SET ORDER_QTY = ORDER_QTY + VN_SURPLUS_PRODUCTIVITY
                 WHERE ORDER_TYPE_ID = P_ORDER_TYPE_ID
                   AND PERIOD_ID = P_PERIOD_ID
                   AND PLASTIC_CODE = C_PLN_EXCESS_PLASTIC.PLASTIC_CODE
                   AND PRODUCING_AREA_CODE = C_PLN_COST_PRIORITY.NEW_PRODUCING_AREA_CODE
                   AND ENTITY_ID = P_ENTITY_ID;

                --@@缺少更新订单行与订单汇总行关系表
              END IF;
            END IF;
          END IF;

        END LOOP;
        EXECUTE IMMEDIATE 'TRUNCATE TABLE T_PLN_COST_PRIORITY';
        --DELETE FROM T_PLN_COST_PRIORITY;

    END LOOP;

    DELETE FROM T_PLN_ORDER_TOTAL_INTF WHERE ORDER_TYPE_ID = P_ORDER_TYPE_ID AND PERIOD_ID = P_PERIOD_ID AND ENTITY_ID = P_ENTITY_ID;
    --插入总装临时表
    INSERT INTO T_PLN_ORDER_TOTAL_INTF
      (ORDER_TOTAL_INTF_ID,
       ORDER_TYPE_ID,
       PERIOD_ID,
       PRODUCING_AREA_CODE,
       ORDER_QTY,
       TOTAL_PRODUCTIVITY,
       SURPLUS_PRODUCTIVITY,
       ENTITY_ID,
       CREATED_BY,
       CREATION_DATE,
       LAST_UPDATED_BY,
       LAST_UPDATE_DATE)
      SELECT S_PLN_ORDER_TOTAL_INTF.NEXTVAL,
             P_ORDER_TYPE_ID ORDER_TYPE_ID,
             P_PERIOD_ID PERIOD_ID,
             T.PRODUCING_AREA_CODE,
             0,
             T.TOTAL_PRODUCTIVITY,
             T.SURPLUS_PRODUCTIVITY SURPLUS_PRODUCTIVITY,
             P_ENTITY_ID,
             P_CREATED_BY,
             SYSDATE,
             P_CREATED_BY,
             SYSDATE
        FROM (SELECT PRODUCING_AREA_CODE,
                     SUM(PRODUCTIVITY) TOTAL_PRODUCTIVITY,
                     SUM(PRODUCTIVITY) - SUM(NVL(SURPLUS_PRODUCTIVITY, 0)) SURPLUS_PRODUCTIVITY
                FROM T_PLN_TOTAL_PRODUCTIVITY_AREA
               WHERE PERIOD_ID = P_PERIOD_ID
                 AND ENTITY_ID = P_ENTITY_ID
               GROUP BY PRODUCING_AREA_CODE) T;

    FOR C_PLN_ORDER_QTY1 IN (SELECT B.PRODUCING_AREA_CODE,
                                    SUM(B.CHECK_QTY) ORDER_QTY
                               FROM T_PLN_ORDER_HEAD A,
                                    T_PLN_ORDER_LINE B
                              WHERE A.ORDER_TYPE_ID = P_ORDER_TYPE_ID
                                AND A.PERIOD_ID = P_PERIOD_ID
                                AND A.FORM_STATE = 25
                                AND A.BATCH_ID = P_BATCH_ID
                                AND A.ENTITY_ID = P_ENTITY_ID
                                AND B.ORDER_HEAD_ID = A.ORDER_HEAD_ID
                              GROUP BY B.PRODUCING_AREA_CODE) LOOP
      UPDATE T_PLN_ORDER_TOTAL_INTF
         SET ORDER_QTY = ORDER_QTY + C_PLN_ORDER_QTY1.ORDER_QTY
       WHERE PRODUCING_AREA_CODE = C_PLN_ORDER_QTY1.PRODUCING_AREA_CODE
         AND ORDER_TYPE_ID = P_ORDER_TYPE_ID
         AND PERIOD_ID = P_PERIOD_ID
         AND ENTITY_ID = P_ENTITY_ID;
    END LOOP;

  EXCEPTION
    WHEN OTHERS THEN
      P_RESULT := '二次产地分解失败。' || V_NL || '失败信息：' || SQLERRM;
      ROLLBACK;
  END;

  ----------------------------------------------------------------------
  -- Author  : fenggq
  -- Created : 2014-09-27 14:16:00
  -- Purpose : 三次产地分解
  ----------------------------------------------------------------------
  PROCEDURE P_PRODUCING_AREA_ALLOT_3RD(P_ORDER_TYPE_ID           IN NUMBER,   --订单类型ID
                                       P_PERIOD_ID               IN NUMBER,   --订单周期ID
                                       P_BATCH_ID                IN NUMBER,   --批次ID
                                       P_OLD_PRODUCING_AREA_CODE IN VARCHAR2, --原产地
                                       P_NEW_PRODUCING_AREA_CODE IN VARCHAR2, --目的产地
                                       P_ADJUST_QTY              IN NUMBER,   --调整数量
                                       P_ENTITY_ID               IN NUMBER,   --主体ID
                                       P_CREATED_BY              IN VARCHAR2, --创建人
                                       P_RESULT                  OUT VARCHAR2) IS

    --校验产品模具对应关系
    VS_ITEM_CODE            T_PLN_ORDER_LINE.ITEM_CODE%TYPE;
    VS_ITEM_NAME            T_PLN_ORDER_LINE.ITEM_DESC%TYPE;
    VS_PLASTIC_CODE         T_PLN_ITEM_PLASTIC.PLASTIC_CODE%TYPE;
    --校验产地模具对应关系
    VS_PLASTIC_NAME         T_PLN_ITEM_PLASTIC.PLASTIC_NAME%TYPE;
    VN_MOULD_COUNT          NUMBER;
    --校验产地总装对应关系
    VS_PRODUCING_AREA_NAME  T_PLN_PRODUCING_AREA.PRODUCING_AREA_NAME%TYPE;
    VN_TOTAL_COUNT          NUMBER;

    VN_ADJUST_QTY           NUMBER; --调整数量
    VN_TEMP_QTY             NUMBER; --临时数量
    VN_COST_PRICE           T_PLN_CUSTOMER_PRIORITY.COST_PRICE%TYPE; --超出模具产能的产品成本
    VN_SUB_COST_PRICE       NUMBER; --成本差
    VN_CHECK_QTY            T_PLN_ORDER_LINE.CHECK_QTY%TYPE; --被调整产品数量
    --VN_NEW_CHECK_QTY        T_PLN_ORDER_LINE.CHECK_QTY%TYPE; --待调整产品数量
    VN_SURPLUS_PRODUCTIVITY T_PLN_MOULD_PRODUCTIVITY_AREA.SURPLUS_PRODUCTIVITY%TYPE; --调整模具的剩余产能

  BEGIN
    P_RESULT := V_SUCCESS;

    --SELECT ROUND(P_ADJUST_QTY * 1.1, 0) INTO VN_ADJUST_QTY FROM DUAL;
    VN_ADJUST_QTY := P_ADJUST_QTY;

    DELETE FROM T_PLN_ORDER_MOULD_INTF WHERE ORDER_TYPE_ID = P_ORDER_TYPE_ID AND PERIOD_ID = P_PERIOD_ID AND ENTITY_ID = P_ENTITY_ID;
    DELETE FROM T_PLN_ORDER_ADJUST WHERE ORDER_TYPE_ID = P_ORDER_TYPE_ID AND PERIOD_ID = P_PERIOD_ID AND ENTITY_ID = P_ENTITY_ID;

    --校验产品模具对应关系
    BEGIN
      FOR C_PLN_ORDER_ITEM IN
        (SELECT DISTINCT ITEM_CODE
           FROM T_PLN_ORDER_HEAD A,
                T_PLN_ORDER_LINE B
          WHERE A.ORDER_TYPE_ID = P_ORDER_TYPE_ID
            AND A.PERIOD_ID = P_PERIOD_ID
            AND A.FORM_STATE = 25
            AND A.BATCH_ID = P_BATCH_ID
            AND A.ENTITY_ID = P_ENTITY_ID
            AND B.ORDER_HEAD_ID = A.ORDER_HEAD_ID) LOOP

         VS_ITEM_CODE := C_PLN_ORDER_ITEM.ITEM_CODE;

         SELECT ITEM_NAME
           INTO VS_ITEM_NAME
           FROM T_BD_ITEM
          WHERE ITEM_CODE = C_PLN_ORDER_ITEM.ITEM_CODE
            AND ENTITY_ID = P_ENTITY_ID;

         SELECT PLASTIC_CODE
           INTO VS_PLASTIC_CODE
           FROM T_PLN_ITEM_PLASTIC
          WHERE ITEM_CODE = C_PLN_ORDER_ITEM.ITEM_CODE
            AND ENTITY_ID = P_ENTITY_ID;
      END LOOP;

    EXCEPTION
      WHEN OTHERS THEN
      P_RESULT := '产品：' || VS_ITEM_CODE || ' ' || VS_ITEM_NAME || '，没有维护产品模具对应关系。';
      RETURN;
    END;
    --校验产地模具对应关系
    BEGIN
      FOR C_PLN_ORDER_PLASTIC IN
        (SELECT DISTINCT PLASTIC_CODE
           FROM T_PLN_ORDER_HEAD A,
                T_PLN_ORDER_LINE B,
                T_PLN_ITEM_PLASTIC C
          WHERE A.ORDER_TYPE_ID = P_ORDER_TYPE_ID
            AND A.PERIOD_ID = P_PERIOD_ID
            AND A.FORM_STATE = 25
            AND A.BATCH_ID = P_BATCH_ID
            AND A.ENTITY_ID = P_ENTITY_ID
            AND B.ORDER_HEAD_ID = A.ORDER_HEAD_ID
            AND C.ITEM_CODE = B.ITEM_CODE) LOOP

         SELECT DISTINCT PLASTIC_NAME
           INTO VS_PLASTIC_NAME
           FROM T_PLN_ITEM_PLASTIC
          WHERE PLASTIC_CODE = C_PLN_ORDER_PLASTIC.PLASTIC_CODE
            AND ENTITY_ID = P_ENTITY_ID;

         SELECT COUNT(*)
           INTO VN_MOULD_COUNT
           FROM T_PLN_MOULD_PRODUCTIVITY_AREA
          WHERE PLASTIC_CODE = C_PLN_ORDER_PLASTIC.PLASTIC_CODE
            AND PERIOD_ID = P_PERIOD_ID
            AND ENTITY_ID = P_ENTITY_ID;

         IF VN_MOULD_COUNT = 0 THEN
           P_RESULT := '模具：' || C_PLN_ORDER_PLASTIC.PLASTIC_CODE || ' ' || VS_PLASTIC_NAME || '，没有维护产地模具对应关系。';
           RETURN;
         END IF;
      END LOOP;
    END;
    --校验产地总装对应关系
    BEGIN
      FOR C_PLN_ORDER_TOTAL IN
        (SELECT DISTINCT B.PRODUCING_AREA_CODE
           FROM T_PLN_ORDER_HEAD A,
                T_PLN_ORDER_LINE B
          WHERE A.ORDER_TYPE_ID = P_ORDER_TYPE_ID
            AND A.PERIOD_ID = P_PERIOD_ID
            AND A.FORM_STATE = 25
            AND A.BATCH_ID = P_BATCH_ID
            AND A.ENTITY_ID = P_ENTITY_ID
            AND B.ORDER_HEAD_ID = A.ORDER_HEAD_ID) LOOP

         SELECT PRODUCING_AREA_NAME
           INTO VS_PRODUCING_AREA_NAME
           FROM T_PLN_PRODUCING_AREA
          WHERE PRODUCING_AREA_CODE = C_PLN_ORDER_TOTAL.PRODUCING_AREA_CODE
            AND ENTITY_ID = P_ENTITY_ID;

         SELECT COUNT(*)
           INTO VN_TOTAL_COUNT
           FROM T_PLN_TOTAL_PRODUCTIVITY_AREA
          WHERE PRODUCING_AREA_CODE = C_PLN_ORDER_TOTAL.PRODUCING_AREA_CODE
            AND PERIOD_ID = P_PERIOD_ID
            AND ENTITY_ID = P_ENTITY_ID;

         IF VN_TOTAL_COUNT = 0 THEN
           P_RESULT := '产地：' || C_PLN_ORDER_TOTAL.PRODUCING_AREA_CODE || ' ' || VS_PRODUCING_AREA_NAME || '，没有维护产地总装对应关系。';
           RETURN;
         END IF;
      END LOOP;
    END;
    --插入模具临时表
    INSERT INTO T_PLN_ORDER_MOULD_INTF
      (ORDER_MOULD_INTF_ID,
       ORDER_TYPE_ID,
       PERIOD_ID,
       PLASTIC_CODE,
       PRODUCING_AREA_CODE,
       ORDER_QTY,
       PLASTIC_PRODUCTIVITY,
       SURPLUS_PRODUCTIVITY,
       ENTITY_ID,
       CREATED_BY,
       CREATION_DATE,
       LAST_UPDATED_BY,
       LAST_UPDATE_DATE)
      SELECT S_PLN_ORDER_MOULD_INTF.NEXTVAL,
             P_ORDER_TYPE_ID ORDER_TYPE_ID,
             P_PERIOD_ID PERIOD_ID,
             PLASTIC_CODE,
             PRODUCING_AREA_CODE,
             0,
             PLASTIC_PRODUCTIVITY,
             PLASTIC_PRODUCTIVITY - NVL(SURPLUS_PRODUCTIVITY, 0) SURPLUS_PRODUCTIVITY,
             P_ENTITY_ID,
             P_CREATED_BY,
             SYSDATE,
             P_CREATED_BY,
             SYSDATE
        FROM T_PLN_MOULD_PRODUCTIVITY_AREA
       WHERE PERIOD_ID = P_PERIOD_ID
         AND ENTITY_ID = P_ENTITY_ID;

    FOR C_PLN_ORDER_QTY IN (SELECT C.PLASTIC_CODE,
                                   B.PRODUCING_AREA_CODE,
                                   SUM(B.CHECK_QTY) ORDER_QTY
                              FROM T_PLN_ORDER_HEAD A, T_PLN_ORDER_LINE B, T_PLN_ITEM_PLASTIC C
                             WHERE A.ORDER_TYPE_ID = P_ORDER_TYPE_ID
                               AND A.PERIOD_ID = P_PERIOD_ID
                               AND A.FORM_STATE = 25
                               AND A.BATCH_ID = P_BATCH_ID
                               AND A.ENTITY_ID = P_ENTITY_ID
                               AND B.ORDER_HEAD_ID = A.ORDER_HEAD_ID
                               AND C.ITEM_CODE = B.ITEM_CODE
                             GROUP BY C.PLASTIC_CODE, B.PRODUCING_AREA_CODE) LOOP
      UPDATE T_PLN_ORDER_MOULD_INTF
         SET ORDER_QTY = ORDER_QTY + C_PLN_ORDER_QTY.ORDER_QTY
       WHERE PLASTIC_CODE = C_PLN_ORDER_QTY.PLASTIC_CODE
         AND PRODUCING_AREA_CODE = C_PLN_ORDER_QTY.PRODUCING_AREA_CODE
         AND ORDER_TYPE_ID = P_ORDER_TYPE_ID
         AND PERIOD_ID = P_PERIOD_ID
         AND ENTITY_ID = P_ENTITY_ID;
    END LOOP;

    --超出总装剩余产能的模具
    FOR C_PLN_EXCESS_TOTAL IN
      (SELECT T1.ORDER_QTY, --订单量
              SUM(T2.PRODUCTIVITY) TOTAL_PRODUCTIVITY, --总装产能
              SUM(NVL(T2.SURPLUS_PRODUCTIVITY, 0)) OCCUPIED_PRODUCTIVITY, --占用产能
              SUM(T2.PRODUCTIVITY) - SUM(NVL(T2.SURPLUS_PRODUCTIVITY, 0)) SURPLUS_PRODUCTIVITY --剩余产能
         FROM
           (SELECT SUM(A.CHECK_QTY) ORDER_QTY
              FROM T_PLN_ORDER_LINE A
             WHERE A.ORDER_HEAD_ID IN
               (SELECT ORDER_HEAD_ID
                  FROM T_PLN_ORDER_HEAD
                 WHERE ORDER_TYPE_ID = P_ORDER_TYPE_ID
                   AND PERIOD_ID = P_PERIOD_ID
                   AND FORM_STATE = 25
                   AND BATCH_ID = P_BATCH_ID
                   AND SALES_CENTER_CODE NOT IN
                     (SELECT SALES_CENTER_CODE
                        FROM T_PLN_CENTER_COST_RELATION
                       WHERE COST_FLAG = '1'
                         AND ENTITY_ID = P_ENTITY_ID)
                   AND ENTITY_ID = P_ENTITY_ID) --不参与产地分解的已送审订单
               AND A.PRODUCING_AREA_CODE = P_OLD_PRODUCING_AREA_CODE) T1, --产地模具订单量
           T_PLN_TOTAL_PRODUCTIVITY_AREA T2   --产地总装产能
        WHERE T2.PRODUCING_AREA_CODE = P_OLD_PRODUCING_AREA_CODE
          AND T2.PERIOD_ID = P_PERIOD_ID
       --HAVING T1.ORDER_QTY > (SUM(T2.PRODUCTIVITY) - SUM(NVL(T2.SURPLUS_PRODUCTIVITY, 0)))
        GROUP BY T1.ORDER_QTY) LOOP
      --超出总装剩余产能对应销司的产品
      FOR C_PLN_EXCESS_ITEM IN
        (SELECT A.SALES_CENTER_CODE,
                B.ITEM_CODE,
                B.CHECK_QTY
           FROM T_PLN_ORDER_HEAD A,
                T_PLN_ORDER_LINE B
          WHERE A.ORDER_HEAD_ID IN
            (SELECT ORDER_HEAD_ID
               FROM T_PLN_ORDER_HEAD
              WHERE ORDER_TYPE_ID = P_ORDER_TYPE_ID
                AND PERIOD_ID = P_PERIOD_ID
                AND FORM_STATE = 25
                AND BATCH_ID = P_BATCH_ID
                AND SALES_CENTER_CODE NOT IN
                  (SELECT C.SALES_CENTER_CODE
                     FROM T_PLN_CENTER_COST_RELATION C
                    WHERE C.COST_FLAG = '1'
                      AND ENTITY_ID = P_ENTITY_ID)
                AND ENTITY_ID = P_ENTITY_ID)
                AND A.BATCH_ID = P_BATCH_ID
                AND A.ORDER_HEAD_ID = B.ORDER_HEAD_ID
                AND B.PRODUCING_AREA_CODE = P_OLD_PRODUCING_AREA_CODE
                AND B.CHECK_QTY <> 0) LOOP

          BEGIN
            VN_COST_PRICE := -99999999;
            SELECT COST_PRICE
              INTO VN_COST_PRICE  --超出总装产能的产品成本
              FROM T_PLN_CUSTOMER_PRIORITY
             WHERE SALES_CENTER_CODE = C_PLN_EXCESS_ITEM.SALES_CENTER_CODE
               AND ITEM_CODE = C_PLN_EXCESS_ITEM.ITEM_CODE
               AND PRODUCING_AREA_CODE = P_OLD_PRODUCING_AREA_CODE
               AND ENTITY_ID = P_ENTITY_ID;
          EXCEPTION
            WHEN OTHERS THEN
            NULL;
          END;
          --原产地产品存在
          IF VN_COST_PRICE <> -99999999 THEN
            --目的产地产品存在，取产品综合成本差
            INSERT INTO T_PLN_COST_PRIORITY
              (SALES_CENTER_CODE,
               ITEM_CODE,
               OLD_PRODUCING_AREA_CODE,
               NEW_PRODUCING_AREA_CODE,
               SUB_COST_PRICE)
              SELECT A.SALES_CENTER_CODE,
                     A.ITEM_CODE,
                     P_OLD_PRODUCING_AREA_CODE, --原产地
                     P_NEW_PRODUCING_AREA_CODE,
                     A.COST_PRICE - VN_COST_PRICE --成本差
                FROM T_PLN_CUSTOMER_PRIORITY A, T_PLN_ITEM_PRODUCING_AREA B
               WHERE A.SALES_CENTER_CODE = C_PLN_EXCESS_ITEM.SALES_CENTER_CODE
                 AND A.ITEM_CODE = C_PLN_EXCESS_ITEM.ITEM_CODE
                 AND A.PRODUCING_AREA_CODE = P_NEW_PRODUCING_AREA_CODE
                 AND A.ENTITY_ID = P_ENTITY_ID
                 AND B.ITEM_CODE = A.ITEM_CODE --判断产品在P_NEW_PRODUCING_AREA_CODE产地是否生产
                 AND B.PRODUCING_AREA_CODE = A.PRODUCING_AREA_CODE;
            --目的产地产品不存在，取销司区域辐射
            VN_SUB_COST_PRICE := 10000;
            FOR C_PLN_PRODUCING_AREA IN
              (SELECT A.PRODUCING_AREA_CODE
                 FROM T_PLN_CUSTOMER_PRIORITY A,
                      T_PLN_ITEM_PRODUCING_AREA B
                WHERE A.SALES_CENTER_CODE = C_PLN_EXCESS_ITEM.SALES_CENTER_CODE
                  AND A.ITEM_CODE IS NULL
                  AND A.PRODUCING_AREA_CODE <> P_NEW_PRODUCING_AREA_CODE
                  AND A.ENTITY_ID = P_ENTITY_ID
                  AND B.ITEM_CODE = C_PLN_EXCESS_ITEM.ITEM_CODE --判断产品在C_PLN_EXCESS_PLASTIC.PRODUCING_AREA_CODE以外的产地是否生产
                  AND B.PRODUCING_AREA_CODE = A.PRODUCING_AREA_CODE) LOOP
              VN_SUB_COST_PRICE := VN_SUB_COST_PRICE + 1;
              INSERT INTO T_PLN_COST_PRIORITY
                (SALES_CENTER_CODE,
                 ITEM_CODE,
                 OLD_PRODUCING_AREA_CODE,
                 NEW_PRODUCING_AREA_CODE,
                 SUB_COST_PRICE)
                VALUES(C_PLN_EXCESS_ITEM.SALES_CENTER_CODE,
                       C_PLN_EXCESS_ITEM.ITEM_CODE,
                       P_OLD_PRODUCING_AREA_CODE,
                       P_NEW_PRODUCING_AREA_CODE,
                       VN_SUB_COST_PRICE);
             END LOOP;
          --原产地产品不存在
          ELSE
            --目的产地产品存在，取产品综合成本
            INSERT INTO T_PLN_COST_PRIORITY
              (SALES_CENTER_CODE,
               ITEM_CODE,
               OLD_PRODUCING_AREA_CODE,
               NEW_PRODUCING_AREA_CODE,
               SUB_COST_PRICE)
              SELECT A.SALES_CENTER_CODE,
                     A.ITEM_CODE,
                     P_OLD_PRODUCING_AREA_CODE, --原产地
                     P_NEW_PRODUCING_AREA_CODE,
                     ROWNUM + 10000 --成本差
                FROM T_PLN_CUSTOMER_PRIORITY A, T_PLN_ITEM_PRODUCING_AREA B
               WHERE A.SALES_CENTER_CODE = C_PLN_EXCESS_ITEM.SALES_CENTER_CODE
                 AND A.ITEM_CODE = C_PLN_EXCESS_ITEM.ITEM_CODE
                 AND A.PRODUCING_AREA_CODE = P_NEW_PRODUCING_AREA_CODE
                 AND A.ENTITY_ID = P_ENTITY_ID
                 AND B.ITEM_CODE = A.ITEM_CODE --判断产品在P_NEW_PRODUCING_AREA_CODE产地是否生产
                 AND B.PRODUCING_AREA_CODE = A.PRODUCING_AREA_CODE;
            --目的产地产品不存在，取销司区域辐射
            VN_SUB_COST_PRICE := 10000;
            FOR C_PLN_PRODUCING_AREA2 IN
              (SELECT A.PRODUCING_AREA_CODE
                 FROM T_PLN_CUSTOMER_PRIORITY A,
                      T_PLN_ITEM_PRODUCING_AREA B
                WHERE A.SALES_CENTER_CODE = C_PLN_EXCESS_ITEM.SALES_CENTER_CODE
                  AND A.ITEM_CODE IS NULL
                  AND A.PRODUCING_AREA_CODE <> P_NEW_PRODUCING_AREA_CODE
                  AND A.ENTITY_ID = P_ENTITY_ID
                  AND B.ITEM_CODE = C_PLN_EXCESS_ITEM.ITEM_CODE --判断产品在C_PLN_EXCESS_PLASTIC.PRODUCING_AREA_CODE以外的产地是否生产
                  AND B.PRODUCING_AREA_CODE = A.PRODUCING_AREA_CODE
                ORDER BY A.PRODUCING_AREA_PRIORITY) LOOP
              VN_SUB_COST_PRICE := VN_SUB_COST_PRICE + 1;
              INSERT INTO T_PLN_COST_PRIORITY
                (SALES_CENTER_CODE,
                 ITEM_CODE,
                 OLD_PRODUCING_AREA_CODE,
                 NEW_PRODUCING_AREA_CODE,
                 SUB_COST_PRICE)
                VALUES(C_PLN_EXCESS_ITEM.SALES_CENTER_CODE,
                       C_PLN_EXCESS_ITEM.ITEM_CODE,
                       P_OLD_PRODUCING_AREA_CODE,
                       P_NEW_PRODUCING_AREA_CODE,
                       VN_SUB_COST_PRICE);
            END LOOP;
          END IF;
      END LOOP;

      --待调整销司的产品成本优先级
      FOR C_PLN_COST_PRIORITY IN
        (SELECT *
           FROM T_PLN_COST_PRIORITY
          ORDER BY SUB_COST_PRICE) LOOP

        SELECT B.CHECK_QTY
          INTO VN_CHECK_QTY --被调整产品数量
          FROM T_PLN_ORDER_HEAD A, T_PLN_ORDER_LINE B
         WHERE ORDER_TYPE_ID = P_ORDER_TYPE_ID
           AND PERIOD_ID = P_PERIOD_ID
           AND FORM_STATE = 25
           AND A.BATCH_ID = P_BATCH_ID
           AND A.ENTITY_ID = P_ENTITY_ID
           AND A.ORDER_HEAD_ID = B.ORDER_HEAD_ID
           AND A.SALES_CENTER_CODE = C_PLN_COST_PRIORITY.SALES_CENTER_CODE
           AND B.PRODUCING_AREA_CODE = C_PLN_COST_PRIORITY.OLD_PRODUCING_AREA_CODE
           AND B.ITEM_CODE = C_PLN_COST_PRIORITY.ITEM_CODE;

        SELECT PLASTIC_CODE
          INTO VS_PLASTIC_CODE
          FROM T_PLN_ITEM_PLASTIC
         WHERE ITEM_CODE = C_PLN_COST_PRIORITY.ITEM_CODE
           AND ENTITY_ID = P_ENTITY_ID;

        BEGIN
          VN_SURPLUS_PRODUCTIVITY := -99999999;
          SELECT SURPLUS_PRODUCTIVITY - ORDER_QTY
            INTO VN_SURPLUS_PRODUCTIVITY --待调整模具的剩余产能
            FROM T_PLN_ORDER_MOULD_INTF
           WHERE ORDER_TYPE_ID = P_ORDER_TYPE_ID
             AND PERIOD_ID = P_PERIOD_ID
             AND PLASTIC_CODE = VS_PLASTIC_CODE
             AND PRODUCING_AREA_CODE = C_PLN_COST_PRIORITY.NEW_PRODUCING_AREA_CODE
             AND ENTITY_ID = P_ENTITY_ID;
        EXCEPTION
          WHEN OTHERS THEN
          NULL;
        END;

        /*BEGIN
          VN_NEW_CHECK_QTY := -1;
          SELECT B.CHECK_QTY
           INTO VN_NEW_CHECK_QTY --待调整产品数量
           FROM T_PLN_ORDER_HEAD A, T_PLN_ORDER_LINE B
          WHERE ORDER_TYPE_ID = P_ORDER_TYPE_ID
            AND PERIOD_ID = P_PERIOD_ID
            AND FORM_STATE = 25
            AND A.ORDER_HEAD_ID = B.ORDER_HEAD_ID
            AND A.SALES_CENTER_CODE = C_PLN_COST_PRIORITY.SALES_CENTER_CODE
            AND B.ITEM_CODE = C_PLN_COST_PRIORITY.ITEM_CODE
            AND B.PRODUCING_AREA_CODE = C_PLN_COST_PRIORITY.NEW_PRODUCING_AREA_CODE;
        EXCEPTION
          WHEN OTHERS THEN
          NULL;
        END;
        --判断待调整产品数量是否存在
        IF VN_NEW_CHECK_QTY <> -1 THEN
          BEGIN
            VN_SURPLUS_PRODUCTIVITY := -99999999;
            SELECT PLASTIC_PRODUCTIVITY - NVL(SURPLUS_PRODUCTIVITY, 0) - VN_NEW_CHECK_QTY SURPLUS_PRODUCTIVITY
              INTO VN_SURPLUS_PRODUCTIVITY --待调整模具的剩余产能
              FROM T_PLN_MOULD_PRODUCTIVITY_AREA
             WHERE PERIOD_ID = P_PERIOD_ID
               AND PLASTIC_CODE = VS_PLASTIC_CODE
               AND PRODUCING_AREA_CODE = C_PLN_COST_PRIORITY.NEW_PRODUCING_AREA_CODE;
          EXCEPTION
            WHEN OTHERS THEN
            NULL;
          END;
        ELSE
          BEGIN
            VN_SURPLUS_PRODUCTIVITY := -99999999;
            SELECT PLASTIC_PRODUCTIVITY - NVL(SURPLUS_PRODUCTIVITY, 0) SURPLUS_PRODUCTIVITY
              INTO VN_SURPLUS_PRODUCTIVITY --待调整模具的剩余产能
              FROM T_PLN_MOULD_PRODUCTIVITY_AREA
             WHERE PERIOD_ID = P_PERIOD_ID
               AND PLASTIC_CODE = VS_PLASTIC_CODE
               AND PRODUCING_AREA_CODE = C_PLN_COST_PRIORITY.NEW_PRODUCING_AREA_CODE;
          EXCEPTION
            WHEN OTHERS THEN
            NULL;
          END;
        END IF;*/
        --判断待调整模具的剩余产能是否存在
        IF VN_SURPLUS_PRODUCTIVITY = -99999999 THEN
          SELECT ITEM_NAME
            INTO VS_ITEM_NAME
            FROM T_BD_ITEM
           WHERE ITEM_CODE = C_PLN_COST_PRIORITY.ITEM_CODE
             AND ENTITY_ID = P_ENTITY_ID;

          SELECT PRODUCING_AREA_NAME
            INTO VS_PRODUCING_AREA_NAME
            FROM T_PLN_PRODUCING_AREA
           WHERE PRODUCING_AREA_CODE = C_PLN_COST_PRIORITY.NEW_PRODUCING_AREA_CODE
             AND ENTITY_ID = P_ENTITY_ID;
          P_RESULT := '产品：' || C_PLN_COST_PRIORITY.ITEM_CODE || ' ' || VS_ITEM_NAME || '在'
              || C_PLN_COST_PRIORITY.NEW_PRODUCING_AREA_CODE || ' ' || VS_PRODUCING_AREA_NAME || '可以生产，但T_PLN_MOULD_PRODUCTIVITY_AREA（产地-模具产能维护）没有维护该产地。';
          ROLLBACK;
          RETURN;
        --判断调整数量是否大于被调整产品数量
        ELSIF VN_ADJUST_QTY >= VN_CHECK_QTY THEN
          --判断新产地是否有模具剩余产能，模具剩余产能是否大于被调整产品数量
          IF VN_SURPLUS_PRODUCTIVITY >= VN_CHECK_QTY AND VN_SURPLUS_PRODUCTIVITY > 0 THEN
            INSERT INTO T_PLN_ORDER_ADJUST
              (ORDER_ADJUST_ID,
               ORDER_TYPE_ID,
               PERIOD_ID,
               ITEM_CODE,
               ITEM_NAME,
               SALES_CENTER_CODE,
               SALES_CENTER_NAME,
               OLD_PRODUCING_AREA_CODE,
               NEW_PRODUCING_AREA_CODE,
               ORDER_QTY,
               ADJUST_QTY,
               ENTITY_ID,
               CREATED_BY,
               CREATION_DATE,
               LAST_UPDATED_BY,
               LAST_UPDATE_DATE)
              VALUES(S_PLN_ORDER_ADJUST.NEXTVAL,
                     P_ORDER_TYPE_ID,
                     P_PERIOD_ID,
                     C_PLN_COST_PRIORITY.ITEM_CODE,
                     (SELECT ITEM_NAME
                        FROM T_BD_ITEM
                       WHERE ITEM_CODE = C_PLN_COST_PRIORITY.ITEM_CODE
                         AND ENTITY_ID = P_ENTITY_ID),
                     C_PLN_COST_PRIORITY.SALES_CENTER_CODE,
                     (SELECT SALES_CENTER_NAME
                        FROM V_BD_SALES_CENTER
                       WHERE SALES_CENTER_CODE = C_PLN_COST_PRIORITY.SALES_CENTER_CODE
                         AND ENTITY_ID = P_ENTITY_ID),
                     C_PLN_COST_PRIORITY.OLD_PRODUCING_AREA_CODE,
                     C_PLN_COST_PRIORITY.NEW_PRODUCING_AREA_CODE,
                     VN_CHECK_QTY,
                     VN_CHECK_QTY,
                     P_ENTITY_ID,
                     P_CREATED_BY,
                     SYSDATE,
                     P_CREATED_BY,
                     SYSDATE);

            VN_ADJUST_QTY := VN_ADJUST_QTY - VN_CHECK_QTY;

            --更新订单模具产能临时表（原产地）
            UPDATE T_PLN_ORDER_MOULD_INTF
               SET ORDER_QTY = ORDER_QTY - VN_CHECK_QTY
             WHERE ORDER_TYPE_ID = P_ORDER_TYPE_ID
               AND PERIOD_ID = P_PERIOD_ID
               AND PLASTIC_CODE = VS_PLASTIC_CODE
               AND PRODUCING_AREA_CODE = C_PLN_COST_PRIORITY.OLD_PRODUCING_AREA_CODE
               AND ENTITY_ID = P_ENTITY_ID;
            --更新订单模具产能临时表（目的产地）
            UPDATE T_PLN_ORDER_MOULD_INTF
               SET ORDER_QTY = ORDER_QTY + VN_CHECK_QTY
             WHERE ORDER_TYPE_ID = P_ORDER_TYPE_ID
               AND PERIOD_ID = P_PERIOD_ID
               AND PLASTIC_CODE = VS_PLASTIC_CODE
               AND PRODUCING_AREA_CODE = C_PLN_COST_PRIORITY.NEW_PRODUCING_AREA_CODE
               AND ENTITY_ID = P_ENTITY_ID;

          ELSIF VN_SURPLUS_PRODUCTIVITY < VN_CHECK_QTY AND VN_SURPLUS_PRODUCTIVITY > 0 THEN
            INSERT INTO T_PLN_ORDER_ADJUST
             (ORDER_ADJUST_ID,
              ORDER_TYPE_ID,
              PERIOD_ID,
              ITEM_CODE,
              ITEM_NAME,
              SALES_CENTER_CODE,
              SALES_CENTER_NAME,
              OLD_PRODUCING_AREA_CODE,
              NEW_PRODUCING_AREA_CODE,
              ORDER_QTY,
              ADJUST_QTY,
              ENTITY_ID,
              CREATED_BY,
              CREATION_DATE,
              LAST_UPDATED_BY,
              LAST_UPDATE_DATE)
             VALUES(S_PLN_ORDER_ADJUST.NEXTVAL,
                    P_ORDER_TYPE_ID,
                    P_PERIOD_ID,
                    C_PLN_COST_PRIORITY.ITEM_CODE,
                    (SELECT ITEM_NAME
                       FROM T_BD_ITEM
                      WHERE ITEM_CODE = C_PLN_COST_PRIORITY.ITEM_CODE
                        AND ENTITY_ID = P_ENTITY_ID),
                    C_PLN_COST_PRIORITY.SALES_CENTER_CODE,
                    (SELECT SALES_CENTER_NAME
                       FROM V_BD_SALES_CENTER
                      WHERE SALES_CENTER_CODE = C_PLN_COST_PRIORITY.SALES_CENTER_CODE
                        AND ENTITY_ID = P_ENTITY_ID),
                    C_PLN_COST_PRIORITY.OLD_PRODUCING_AREA_CODE,
                    C_PLN_COST_PRIORITY.NEW_PRODUCING_AREA_CODE,
                    VN_CHECK_QTY,
                    VN_SURPLUS_PRODUCTIVITY,
                    P_ENTITY_ID,
                    P_CREATED_BY,
                    SYSDATE,
                    P_CREATED_BY,
                    SYSDATE);

            VN_ADJUST_QTY := VN_ADJUST_QTY - VN_SURPLUS_PRODUCTIVITY;

            --更新订单模具产能临时表（原产地）
            UPDATE T_PLN_ORDER_MOULD_INTF
               SET ORDER_QTY = ORDER_QTY - VN_SURPLUS_PRODUCTIVITY
             WHERE ORDER_TYPE_ID = P_ORDER_TYPE_ID
               AND PERIOD_ID = P_PERIOD_ID
               AND PLASTIC_CODE = VS_PLASTIC_CODE
               AND PRODUCING_AREA_CODE = C_PLN_COST_PRIORITY.OLD_PRODUCING_AREA_CODE
               AND ENTITY_ID = P_ENTITY_ID;
            --更新订单模具产能临时表（目的产地）
            UPDATE T_PLN_ORDER_MOULD_INTF
               SET ORDER_QTY = ORDER_QTY + VN_SURPLUS_PRODUCTIVITY
             WHERE ORDER_TYPE_ID = P_ORDER_TYPE_ID
               AND PERIOD_ID = P_PERIOD_ID
               AND PLASTIC_CODE = VS_PLASTIC_CODE
               AND PRODUCING_AREA_CODE = C_PLN_COST_PRIORITY.NEW_PRODUCING_AREA_CODE
               AND ENTITY_ID = P_ENTITY_ID;

          END IF;
        ELSIF VN_ADJUST_QTY < VN_CHECK_QTY AND VN_ADJUST_QTY > 0 THEN
          --判断新产地是否有模具剩余产能，模具剩余产能是否大于调整数量
          IF VN_SURPLUS_PRODUCTIVITY >= VN_ADJUST_QTY AND VN_SURPLUS_PRODUCTIVITY > 0 THEN
            INSERT INTO T_PLN_ORDER_ADJUST
              (ORDER_ADJUST_ID,
               ORDER_TYPE_ID,
               PERIOD_ID,
               ITEM_CODE,
               ITEM_NAME,
               SALES_CENTER_CODE,
               SALES_CENTER_NAME,
               OLD_PRODUCING_AREA_CODE,
               NEW_PRODUCING_AREA_CODE,
               ORDER_QTY,
               ADJUST_QTY,
               ENTITY_ID,
               CREATED_BY,
               CREATION_DATE,
               LAST_UPDATED_BY,
               LAST_UPDATE_DATE)
              VALUES(S_PLN_ORDER_ADJUST.NEXTVAL,
                     P_ORDER_TYPE_ID,
                     P_PERIOD_ID,
                     C_PLN_COST_PRIORITY.ITEM_CODE,
                     (SELECT ITEM_NAME
                        FROM T_BD_ITEM
                       WHERE ITEM_CODE = C_PLN_COST_PRIORITY.ITEM_CODE
                         AND ENTITY_ID = P_ENTITY_ID),
                     C_PLN_COST_PRIORITY.SALES_CENTER_CODE,
                     (SELECT SALES_CENTER_NAME
                        FROM V_BD_SALES_CENTER
                       WHERE SALES_CENTER_CODE = C_PLN_COST_PRIORITY.SALES_CENTER_CODE
                         AND ENTITY_ID = P_ENTITY_ID),
                     C_PLN_COST_PRIORITY.OLD_PRODUCING_AREA_CODE,
                     C_PLN_COST_PRIORITY.NEW_PRODUCING_AREA_CODE,
                     VN_ADJUST_QTY,
                     VN_ADJUST_QTY,
                     P_ENTITY_ID,
                     P_CREATED_BY,
                     SYSDATE,
                     P_CREATED_BY,
                     SYSDATE);

            VN_TEMP_QTY := VN_ADJUST_QTY;
            VN_ADJUST_QTY := VN_ADJUST_QTY - VN_ADJUST_QTY;

            --更新订单模具产能临时表（原产地）
            UPDATE T_PLN_ORDER_MOULD_INTF
               SET ORDER_QTY = ORDER_QTY - VN_TEMP_QTY
             WHERE ORDER_TYPE_ID = P_ORDER_TYPE_ID
               AND PERIOD_ID = P_PERIOD_ID
               AND PLASTIC_CODE = VS_PLASTIC_CODE
               AND PRODUCING_AREA_CODE = C_PLN_COST_PRIORITY.OLD_PRODUCING_AREA_CODE
               AND ENTITY_ID = P_ENTITY_ID;
            --更新订单模具产能临时表（目的产地）
            UPDATE T_PLN_ORDER_MOULD_INTF
               SET ORDER_QTY = ORDER_QTY + VN_TEMP_QTY
             WHERE ORDER_TYPE_ID = P_ORDER_TYPE_ID
               AND PERIOD_ID = P_PERIOD_ID
               AND PLASTIC_CODE = VS_PLASTIC_CODE
               AND PRODUCING_AREA_CODE = C_PLN_COST_PRIORITY.NEW_PRODUCING_AREA_CODE
               AND ENTITY_ID = P_ENTITY_ID;

          ELSIF VN_SURPLUS_PRODUCTIVITY < VN_ADJUST_QTY AND VN_SURPLUS_PRODUCTIVITY > 0 THEN
            INSERT INTO T_PLN_ORDER_ADJUST
             (ORDER_ADJUST_ID,
              ORDER_TYPE_ID,
              PERIOD_ID,
              ITEM_CODE,
              ITEM_NAME,
              SALES_CENTER_CODE,
              SALES_CENTER_NAME,
              OLD_PRODUCING_AREA_CODE,
              NEW_PRODUCING_AREA_CODE,
              ORDER_QTY,
              ADJUST_QTY,
              ENTITY_ID,
              CREATED_BY,
              CREATION_DATE,
              LAST_UPDATED_BY,
              LAST_UPDATE_DATE)
             VALUES(S_PLN_ORDER_ADJUST.NEXTVAL,
                    P_ORDER_TYPE_ID,
                    P_PERIOD_ID,
                    C_PLN_COST_PRIORITY.ITEM_CODE,
                    (SELECT ITEM_NAME
                       FROM T_BD_ITEM
                      WHERE ITEM_CODE = C_PLN_COST_PRIORITY.ITEM_CODE
                        AND ENTITY_ID = P_ENTITY_ID),
                    C_PLN_COST_PRIORITY.SALES_CENTER_CODE,
                    (SELECT SALES_CENTER_NAME
                       FROM V_BD_SALES_CENTER
                      WHERE SALES_CENTER_CODE = C_PLN_COST_PRIORITY.SALES_CENTER_CODE
                        AND ENTITY_ID = P_ENTITY_ID),
                    C_PLN_COST_PRIORITY.OLD_PRODUCING_AREA_CODE,
                    C_PLN_COST_PRIORITY.NEW_PRODUCING_AREA_CODE,
                    VN_CHECK_QTY,
                    VN_SURPLUS_PRODUCTIVITY,
                    P_ENTITY_ID,
                    P_CREATED_BY,
                    SYSDATE,
                    P_CREATED_BY,
                    SYSDATE);

            VN_ADJUST_QTY := VN_ADJUST_QTY - VN_SURPLUS_PRODUCTIVITY;

            --更新订单模具产能临时表（原产地）
            UPDATE T_PLN_ORDER_MOULD_INTF
               SET ORDER_QTY = ORDER_QTY - VN_SURPLUS_PRODUCTIVITY
             WHERE ORDER_TYPE_ID = P_ORDER_TYPE_ID
               AND PERIOD_ID = P_PERIOD_ID
               AND PLASTIC_CODE = VS_PLASTIC_CODE
               AND PRODUCING_AREA_CODE = C_PLN_COST_PRIORITY.OLD_PRODUCING_AREA_CODE
               AND ENTITY_ID = P_ENTITY_ID;
            --更新订单模具产能临时表（目的产地）
            UPDATE T_PLN_ORDER_MOULD_INTF
               SET ORDER_QTY = ORDER_QTY + VN_SURPLUS_PRODUCTIVITY
             WHERE ORDER_TYPE_ID = P_ORDER_TYPE_ID
               AND PERIOD_ID = P_PERIOD_ID
               AND PLASTIC_CODE = VS_PLASTIC_CODE
               AND PRODUCING_AREA_CODE = C_PLN_COST_PRIORITY.NEW_PRODUCING_AREA_CODE
               AND ENTITY_ID = P_ENTITY_ID;

          END IF;
        END IF;
      END LOOP;
      EXECUTE IMMEDIATE 'TRUNCATE TABLE T_PLN_COST_PRIORITY';

    END LOOP;

    DELETE FROM T_PLN_ORDER_TOTAL_INTF WHERE ORDER_TYPE_ID = P_ORDER_TYPE_ID AND PERIOD_ID = P_PERIOD_ID AND ENTITY_ID = P_ENTITY_ID;
    --插入总装临时表
    INSERT INTO T_PLN_ORDER_TOTAL_INTF
      (ORDER_TOTAL_INTF_ID,
       ORDER_TYPE_ID,
       PERIOD_ID,
       PRODUCING_AREA_CODE,
       ORDER_QTY,
       TOTAL_PRODUCTIVITY,
       SURPLUS_PRODUCTIVITY,
       ENTITY_ID,
       CREATED_BY,
       CREATION_DATE,
       LAST_UPDATED_BY,
       LAST_UPDATE_DATE)
      SELECT S_PLN_ORDER_TOTAL_INTF.NEXTVAL,
             P_ORDER_TYPE_ID ORDER_TYPE_ID,
             P_PERIOD_ID PERIOD_ID,
             T.PRODUCING_AREA_CODE,
             0,
             T.TOTAL_PRODUCTIVITY,
             T.SURPLUS_PRODUCTIVITY SURPLUS_PRODUCTIVITY,
             P_ENTITY_ID,
             P_CREATED_BY,
             SYSDATE,
             P_CREATED_BY,
             SYSDATE
        FROM (SELECT PRODUCING_AREA_CODE,
                     SUM(PRODUCTIVITY) TOTAL_PRODUCTIVITY,
                     SUM(PRODUCTIVITY) - SUM(NVL(SURPLUS_PRODUCTIVITY, 0)) SURPLUS_PRODUCTIVITY
                FROM T_PLN_TOTAL_PRODUCTIVITY_AREA
               WHERE PERIOD_ID = P_PERIOD_ID
                 AND ENTITY_ID = P_ENTITY_ID
               GROUP BY PRODUCING_AREA_CODE) T;

    FOR C_PLN_ORDER_QTY1 IN (SELECT B.PRODUCING_AREA_CODE,
                                    SUM(B.CHECK_QTY) ORDER_QTY
                               FROM T_PLN_ORDER_HEAD A,
                                    T_PLN_ORDER_LINE B
                              WHERE A.ORDER_TYPE_ID = P_ORDER_TYPE_ID
                                AND A.PERIOD_ID = P_PERIOD_ID
                                AND A.FORM_STATE = 25
                                AND A.BATCH_ID = P_BATCH_ID
                                AND A.ENTITY_ID = P_ENTITY_ID
                                AND A.ORDER_HEAD_ID = B.ORDER_HEAD_ID
                              GROUP BY B.PRODUCING_AREA_CODE) LOOP
      UPDATE T_PLN_ORDER_TOTAL_INTF
         SET ORDER_QTY = ORDER_QTY + C_PLN_ORDER_QTY1.ORDER_QTY
       WHERE PRODUCING_AREA_CODE = C_PLN_ORDER_QTY1.PRODUCING_AREA_CODE
         AND ORDER_TYPE_ID = P_ORDER_TYPE_ID
         AND PERIOD_ID = P_PERIOD_ID
         AND ENTITY_ID = P_ENTITY_ID;
    END LOOP;

  EXCEPTION
    WHEN OTHERS THEN
      P_RESULT := '三次产地分解失败。' || V_NL || '失败信息：' || SQLERRM;
      ROLLBACK;
  END;

  ----------------------------------------------------------------------
  -- Author  : fenggq
  -- Created : 2014-11-13 14:26:00
  -- Purpose : 校验调整数量
  ----------------------------------------------------------------------
  PROCEDURE P_CHECK_ADJUST_QTY(P_ORDER_TYPE_ID           IN NUMBER,   --订单类型ID
                               P_PERIOD_ID               IN NUMBER,   --订单周期ID
                               P_BATCH_ID                IN NUMBER,   --批次ID
                               P_OLD_PRODUCING_AREA_CODE IN VARCHAR2, --原产地
                               P_NEW_PRODUCING_AREA_CODE IN VARCHAR2, --目的产地
                               P_ADJUST_QTY              IN NUMBER,   --调整数量
                               P_ENTITY_ID               IN NUMBER,   --主体ID
                               P_CREATED_BY              IN VARCHAR2, --创建人
                               P_RESULT                  OUT VARCHAR2) IS

    --校验产品模具对应关系
    VS_ITEM_CODE            T_PLN_ORDER_LINE.ITEM_CODE%TYPE;
    VS_ITEM_NAME            T_PLN_ORDER_LINE.ITEM_DESC%TYPE;
    VS_PLASTIC_CODE         T_PLN_ITEM_PLASTIC.PLASTIC_CODE%TYPE;
    --校验产地模具对应关系
    VS_PLASTIC_NAME         T_PLN_ITEM_PLASTIC.PLASTIC_NAME%TYPE;
    VN_MOULD_COUNT          NUMBER;
    --校验产地总装对应关系
    VS_PRODUCING_AREA_NAME  T_PLN_PRODUCING_AREA.PRODUCING_AREA_NAME%TYPE;
    VN_TOTAL_COUNT          NUMBER;

    VN_ADJUST_QTY           NUMBER; --调整数量
    VN_CHECK_SURPLUS_QTY    NUMBER; --校验总装剩余产能
    VN_CHECK_ORDER_QTY      NUMBER; --校验订单数量
    VN_RETURN_QTY           NUMBER; --返回调整数量
    VN_TEMP_QTY             NUMBER; --临时数量

    VN_COST_PRICE           T_PLN_CUSTOMER_PRIORITY.COST_PRICE%TYPE; --超出模具产能的产品成本
    VN_SUB_COST_PRICE       NUMBER; --成本差
    VN_CHECK_QTY            T_PLN_ORDER_LINE.CHECK_QTY%TYPE; --被调整产品数量
    --VN_NEW_CHECK_QTY        T_PLN_ORDER_LINE.CHECK_QTY%TYPE; --待调整产品数量
    VN_SURPLUS_PRODUCTIVITY T_PLN_MOULD_PRODUCTIVITY_AREA.SURPLUS_PRODUCTIVITY%TYPE; --调整模具的剩余产能

  BEGIN
    P_RESULT := V_SUCCESS;

    --SELECT ROUND(P_ADJUST_QTY * 1.1, 0) INTO VN_ADJUST_QTY FROM DUAL;
    VN_ADJUST_QTY := P_ADJUST_QTY;
    VN_RETURN_QTY := 0;

    DELETE FROM T_PLN_ORDER_MOULD_INTF WHERE ORDER_TYPE_ID = P_ORDER_TYPE_ID AND PERIOD_ID = P_PERIOD_ID AND ENTITY_ID = P_ENTITY_ID;
    DELETE FROM T_PLN_ORDER_TOTAL_INTF WHERE ORDER_TYPE_ID = P_ORDER_TYPE_ID AND PERIOD_ID = P_PERIOD_ID AND ENTITY_ID = P_ENTITY_ID;

    --校验产品模具对应关系
    BEGIN
      FOR C_PLN_ORDER_ITEM IN
        (SELECT DISTINCT ITEM_CODE
           FROM T_PLN_ORDER_HEAD A,
                T_PLN_ORDER_LINE B
          WHERE A.ORDER_TYPE_ID = P_ORDER_TYPE_ID
            AND A.PERIOD_ID = P_PERIOD_ID
            AND A.FORM_STATE = 25
            AND A.BATCH_ID = P_BATCH_ID
            AND A.ENTITY_ID = P_ENTITY_ID
            AND B.ORDER_HEAD_ID = A.ORDER_HEAD_ID) LOOP

         VS_ITEM_CODE := C_PLN_ORDER_ITEM.ITEM_CODE;

         SELECT ITEM_NAME
           INTO VS_ITEM_NAME
           FROM T_BD_ITEM
          WHERE ITEM_CODE = C_PLN_ORDER_ITEM.ITEM_CODE
            AND ENTITY_ID = P_ENTITY_ID;

         SELECT PLASTIC_CODE
           INTO VS_PLASTIC_CODE
           FROM T_PLN_ITEM_PLASTIC
          WHERE ITEM_CODE = C_PLN_ORDER_ITEM.ITEM_CODE
            AND ENTITY_ID = P_ENTITY_ID;
      END LOOP;

    EXCEPTION
      WHEN OTHERS THEN
      P_RESULT := '产品：' || VS_ITEM_CODE || ' ' || VS_ITEM_NAME || '，没有维护产品模具对应关系。';
      RETURN;
    END;
    --校验产地模具对应关系
    BEGIN
      FOR C_PLN_ORDER_PLASTIC IN
        (SELECT DISTINCT PLASTIC_CODE
           FROM T_PLN_ORDER_HEAD A,
                T_PLN_ORDER_LINE B,
                T_PLN_ITEM_PLASTIC C
          WHERE A.ORDER_TYPE_ID = P_ORDER_TYPE_ID
            AND A.PERIOD_ID = P_PERIOD_ID
            AND A.FORM_STATE = 25
            AND A.BATCH_ID = P_BATCH_ID
            AND A.ENTITY_ID = P_ENTITY_ID
            AND B.ORDER_HEAD_ID = A.ORDER_HEAD_ID
            AND C.ITEM_CODE = B.ITEM_CODE) LOOP

         SELECT DISTINCT PLASTIC_NAME
           INTO VS_PLASTIC_NAME
           FROM T_PLN_ITEM_PLASTIC
          WHERE PLASTIC_CODE = C_PLN_ORDER_PLASTIC.PLASTIC_CODE
            AND ENTITY_ID = P_ENTITY_ID;

         SELECT COUNT(*)
           INTO VN_MOULD_COUNT
           FROM T_PLN_MOULD_PRODUCTIVITY_AREA
          WHERE PLASTIC_CODE = C_PLN_ORDER_PLASTIC.PLASTIC_CODE
            AND PERIOD_ID = P_PERIOD_ID
            AND ENTITY_ID = P_ENTITY_ID;

         IF VN_MOULD_COUNT = 0 THEN
           P_RESULT := '模具：' || C_PLN_ORDER_PLASTIC.PLASTIC_CODE || ' ' || VS_PLASTIC_NAME || '，没有维护产地模具对应关系。';
           RETURN;
         END IF;
      END LOOP;
    END;
    --校验产地总装对应关系
    BEGIN
      FOR C_PLN_ORDER_TOTAL IN
        (SELECT DISTINCT B.PRODUCING_AREA_CODE
           FROM T_PLN_ORDER_HEAD A,
                T_PLN_ORDER_LINE B
          WHERE A.ORDER_TYPE_ID = P_ORDER_TYPE_ID
            AND A.PERIOD_ID = P_PERIOD_ID
            AND A.FORM_STATE = 25
            AND A.BATCH_ID = P_BATCH_ID
            AND A.ENTITY_ID = P_ENTITY_ID
            AND B.ORDER_HEAD_ID = A.ORDER_HEAD_ID) LOOP

         SELECT PRODUCING_AREA_NAME
           INTO VS_PRODUCING_AREA_NAME
           FROM T_PLN_PRODUCING_AREA
          WHERE PRODUCING_AREA_CODE = C_PLN_ORDER_TOTAL.PRODUCING_AREA_CODE
            AND ENTITY_ID = P_ENTITY_ID;

         SELECT COUNT(*)
           INTO VN_TOTAL_COUNT
           FROM T_PLN_TOTAL_PRODUCTIVITY_AREA
          WHERE PRODUCING_AREA_CODE = C_PLN_ORDER_TOTAL.PRODUCING_AREA_CODE
            AND PERIOD_ID = P_PERIOD_ID
            AND ENTITY_ID = P_ENTITY_ID;

         IF VN_TOTAL_COUNT = 0 THEN
           P_RESULT := '产地：' || C_PLN_ORDER_TOTAL.PRODUCING_AREA_CODE || ' ' || VS_PRODUCING_AREA_NAME || '，没有维护产地总装对应关系。';
           RETURN;
         END IF;
      END LOOP;
    END;
    --插入模具临时表
    INSERT INTO T_PLN_ORDER_MOULD_INTF
      (ORDER_MOULD_INTF_ID,
       ORDER_TYPE_ID,
       PERIOD_ID,
       PLASTIC_CODE,
       PRODUCING_AREA_CODE,
       ORDER_QTY,
       PLASTIC_PRODUCTIVITY,
       SURPLUS_PRODUCTIVITY,
       ENTITY_ID,
       CREATED_BY,
       CREATION_DATE,
       LAST_UPDATED_BY,
       LAST_UPDATE_DATE)
      SELECT S_PLN_ORDER_MOULD_INTF.NEXTVAL,
             P_ORDER_TYPE_ID ORDER_TYPE_ID,
             P_PERIOD_ID PERIOD_ID,
             PLASTIC_CODE,
             PRODUCING_AREA_CODE,
             0,
             PLASTIC_PRODUCTIVITY,
             PLASTIC_PRODUCTIVITY - NVL(SURPLUS_PRODUCTIVITY, 0) SURPLUS_PRODUCTIVITY,
             P_ENTITY_ID,
             P_CREATED_BY,
             SYSDATE,
             P_CREATED_BY,
             SYSDATE
        FROM T_PLN_MOULD_PRODUCTIVITY_AREA
       WHERE PERIOD_ID = P_PERIOD_ID
         AND ENTITY_ID = P_ENTITY_ID;

    FOR C_PLN_ORDER_QTY IN (SELECT C.PLASTIC_CODE,
                                   B.PRODUCING_AREA_CODE,
                                   SUM(B.CHECK_QTY) ORDER_QTY
                              FROM T_PLN_ORDER_HEAD A, T_PLN_ORDER_LINE B, T_PLN_ITEM_PLASTIC C
                             WHERE A.ORDER_TYPE_ID = P_ORDER_TYPE_ID
                               AND A.PERIOD_ID = P_PERIOD_ID
                               AND A.FORM_STATE = 25
                               AND A.BATCH_ID = P_BATCH_ID
                               AND A.ENTITY_ID = P_ENTITY_ID
                               AND B.ORDER_HEAD_ID = A.ORDER_HEAD_ID
                               AND C.ITEM_CODE = B.ITEM_CODE
                             GROUP BY C.PLASTIC_CODE, B.PRODUCING_AREA_CODE) LOOP
      UPDATE T_PLN_ORDER_MOULD_INTF
         SET ORDER_QTY = ORDER_QTY + C_PLN_ORDER_QTY.ORDER_QTY
       WHERE PLASTIC_CODE = C_PLN_ORDER_QTY.PLASTIC_CODE
         AND PRODUCING_AREA_CODE = C_PLN_ORDER_QTY.PRODUCING_AREA_CODE
         AND ORDER_TYPE_ID = P_ORDER_TYPE_ID
         AND PERIOD_ID = P_PERIOD_ID
         AND ENTITY_ID = P_ENTITY_ID;
    END LOOP;
    --插入总装临时表
    INSERT INTO T_PLN_ORDER_TOTAL_INTF
      (ORDER_TOTAL_INTF_ID,
       ORDER_TYPE_ID,
       PERIOD_ID,
       PRODUCING_AREA_CODE,
       ORDER_QTY,
       TOTAL_PRODUCTIVITY,
       SURPLUS_PRODUCTIVITY,
       ENTITY_ID,
       CREATED_BY,
       CREATION_DATE,
       LAST_UPDATED_BY,
       LAST_UPDATE_DATE)
      SELECT S_PLN_ORDER_TOTAL_INTF.NEXTVAL,
             P_ORDER_TYPE_ID ORDER_TYPE_ID,
             P_PERIOD_ID PERIOD_ID,
             T.PRODUCING_AREA_CODE,
             0,
             T.TOTAL_PRODUCTIVITY,
             T.SURPLUS_PRODUCTIVITY SURPLUS_PRODUCTIVITY,
             P_ENTITY_ID,
             P_CREATED_BY,
             SYSDATE,
             P_CREATED_BY,
             SYSDATE
        FROM (SELECT PRODUCING_AREA_CODE,
                     SUM(PRODUCTIVITY) TOTAL_PRODUCTIVITY,
                     SUM(PRODUCTIVITY) - SUM(NVL(SURPLUS_PRODUCTIVITY, 0)) SURPLUS_PRODUCTIVITY
                FROM T_PLN_TOTAL_PRODUCTIVITY_AREA
               WHERE PERIOD_ID = P_PERIOD_ID
                 AND ENTITY_ID = P_ENTITY_ID
               GROUP BY PRODUCING_AREA_CODE) T;

    FOR C_PLN_ORDER_QTY1 IN (SELECT B.PRODUCING_AREA_CODE,
                                    SUM(B.CHECK_QTY) ORDER_QTY
                               FROM T_PLN_ORDER_HEAD A,
                                    T_PLN_ORDER_LINE B
                              WHERE A.ORDER_TYPE_ID = P_ORDER_TYPE_ID
                                AND A.PERIOD_ID = P_PERIOD_ID
                                AND A.FORM_STATE = 25
                                AND A.BATCH_ID = P_BATCH_ID
                                AND A.ENTITY_ID = P_ENTITY_ID
                                AND A.ORDER_HEAD_ID = B.ORDER_HEAD_ID
                              GROUP BY B.PRODUCING_AREA_CODE) LOOP
      UPDATE T_PLN_ORDER_TOTAL_INTF
         SET ORDER_QTY = ORDER_QTY + C_PLN_ORDER_QTY1.ORDER_QTY
       WHERE PRODUCING_AREA_CODE = C_PLN_ORDER_QTY1.PRODUCING_AREA_CODE
         AND ORDER_TYPE_ID = P_ORDER_TYPE_ID
         AND PERIOD_ID = P_PERIOD_ID
         AND ENTITY_ID = P_ENTITY_ID;
    END LOOP;

    --校验产地总装对应关系
    SELECT PRODUCING_AREA_NAME
      INTO VS_PRODUCING_AREA_NAME
      FROM T_PLN_PRODUCING_AREA
     WHERE PRODUCING_AREA_CODE = P_NEW_PRODUCING_AREA_CODE
       AND ENTITY_ID = P_ENTITY_ID;

    BEGIN
      SELECT SURPLUS_PRODUCTIVITY
        INTO VN_CHECK_SURPLUS_QTY
        FROM T_PLN_ORDER_TOTAL_INTF
       WHERE ORDER_TYPE_ID = P_ORDER_TYPE_ID
         AND PERIOD_ID = P_PERIOD_ID
         AND PRODUCING_AREA_CODE = P_NEW_PRODUCING_AREA_CODE
         AND ENTITY_ID = P_ENTITY_ID;
    EXCEPTION
      WHEN OTHERS THEN
      P_RESULT := '目的产地：' || P_NEW_PRODUCING_AREA_CODE || ' ' || VS_PRODUCING_AREA_NAME || '，没有维护总装产能。';
      RETURN;
    END;

    BEGIN
      VN_CHECK_ORDER_QTY := -1;
      SELECT NVL(SUM(B.CHECK_QTY), 0)
        INTO VN_CHECK_ORDER_QTY
        FROM T_PLN_ORDER_HEAD A, T_PLN_ORDER_LINE B
       WHERE A.ORDER_TYPE_ID = P_ORDER_TYPE_ID
         AND A.PERIOD_ID = P_PERIOD_ID
         AND A.FORM_STATE = 25
         AND A.BATCH_ID = P_BATCH_ID
         AND A.ENTITY_ID = P_ENTITY_ID
         AND B.ORDER_HEAD_ID = A.ORDER_HEAD_ID
         AND B.PRODUCING_AREA_CODE = P_NEW_PRODUCING_AREA_CODE;
    EXCEPTION
      WHEN OTHERS THEN
      NULL;
    END;

    IF VN_CHECK_ORDER_QTY <> -1 THEN
      IF VN_CHECK_SURPLUS_QTY = 0 THEN
        P_RESULT := '目的产地：' || P_NEW_PRODUCING_AREA_CODE || ' ' || VS_PRODUCING_AREA_NAME || '，总装剩余产能为0。';
        RETURN;
      ELSIF VN_CHECK_SURPLUS_QTY - VN_CHECK_ORDER_QTY <= 0 THEN
        P_RESULT := '目的产地：' || P_NEW_PRODUCING_AREA_CODE || ' ' || VS_PRODUCING_AREA_NAME || '，总装剩余产能不足，评审数量超过总装剩余产能。';
        RETURN;
      ELSIF VN_CHECK_SURPLUS_QTY - VN_CHECK_ORDER_QTY < P_ADJUST_QTY THEN
        VN_ADJUST_QTY := VN_CHECK_SURPLUS_QTY - VN_CHECK_ORDER_QTY;
      END IF;
    END IF;

    --超出总装剩余产能的模具
    FOR C_PLN_EXCESS_TOTAL IN
      (SELECT T1.ORDER_QTY, --订单量
              SUM(T2.PRODUCTIVITY) TOTAL_PRODUCTIVITY, --总装产能
              SUM(NVL(T2.SURPLUS_PRODUCTIVITY, 0)) OCCUPIED_PRODUCTIVITY, --占用产能
              SUM(T2.PRODUCTIVITY) - SUM(NVL(T2.SURPLUS_PRODUCTIVITY, 0)) SURPLUS_PRODUCTIVITY --剩余产能
         FROM
           (SELECT SUM(A.CHECK_QTY) ORDER_QTY
              FROM T_PLN_ORDER_LINE A
             WHERE A.ORDER_HEAD_ID IN
               (SELECT ORDER_HEAD_ID
                  FROM T_PLN_ORDER_HEAD
                 WHERE ORDER_TYPE_ID = P_ORDER_TYPE_ID
                   AND PERIOD_ID = P_PERIOD_ID
                   AND FORM_STATE = 25
                   AND BATCH_ID = P_BATCH_ID
                   AND SALES_CENTER_CODE NOT IN
                     (SELECT SALES_CENTER_CODE
                        FROM T_PLN_CENTER_COST_RELATION
                       WHERE COST_FLAG = '1'
                         AND ENTITY_ID = P_ENTITY_ID)
                   AND ENTITY_ID = P_ENTITY_ID) --不参与产地分解的已送审订单
               AND A.PRODUCING_AREA_CODE = P_OLD_PRODUCING_AREA_CODE) T1, --产地模具订单量
           T_PLN_TOTAL_PRODUCTIVITY_AREA T2   --产地总装产能
        WHERE T2.PRODUCING_AREA_CODE = P_OLD_PRODUCING_AREA_CODE
          AND T2.PERIOD_ID = P_PERIOD_ID
       --HAVING T1.ORDER_QTY > (SUM(T2.PRODUCTIVITY) - SUM(NVL(T2.SURPLUS_PRODUCTIVITY, 0)))
        GROUP BY T1.ORDER_QTY) LOOP
      --超出总装剩余产能对应销司的产品
      FOR C_PLN_EXCESS_ITEM IN
        (SELECT A.SALES_CENTER_CODE,
                B.ITEM_CODE,
                B.CHECK_QTY
           FROM T_PLN_ORDER_HEAD A,
                T_PLN_ORDER_LINE B
          WHERE A.ORDER_HEAD_ID IN
            (SELECT ORDER_HEAD_ID
               FROM T_PLN_ORDER_HEAD
              WHERE ORDER_TYPE_ID = P_ORDER_TYPE_ID
                AND PERIOD_ID = P_PERIOD_ID
                AND FORM_STATE = 25
                AND BATCH_ID = P_BATCH_ID
                AND SALES_CENTER_CODE NOT IN
                  (SELECT C.SALES_CENTER_CODE
                     FROM T_PLN_CENTER_COST_RELATION C
                    WHERE C.COST_FLAG = '1'
                      AND ENTITY_ID = P_ENTITY_ID)
                AND ENTITY_ID = P_ENTITY_ID)
                AND A.BATCH_ID = P_BATCH_ID
                AND A.ORDER_HEAD_ID = B.ORDER_HEAD_ID
                AND B.PRODUCING_AREA_CODE = P_OLD_PRODUCING_AREA_CODE
                AND B.CHECK_QTY <> 0) LOOP

          BEGIN
            VN_COST_PRICE := -99999999;
            SELECT COST_PRICE
              INTO VN_COST_PRICE  --超出总装产能的产品成本
              FROM T_PLN_CUSTOMER_PRIORITY
             WHERE SALES_CENTER_CODE = C_PLN_EXCESS_ITEM.SALES_CENTER_CODE
               AND ITEM_CODE = C_PLN_EXCESS_ITEM.ITEM_CODE
               AND PRODUCING_AREA_CODE = P_OLD_PRODUCING_AREA_CODE
               AND ENTITY_ID = P_ENTITY_ID;
          EXCEPTION
            WHEN OTHERS THEN
            NULL;
          END;
          --原产地产品存在
          IF VN_COST_PRICE <> -99999999 THEN
            --目的产地产品存在，取产品综合成本差
            INSERT INTO T_PLN_COST_PRIORITY
              (SALES_CENTER_CODE,
               ITEM_CODE,
               OLD_PRODUCING_AREA_CODE,
               NEW_PRODUCING_AREA_CODE,
               SUB_COST_PRICE)
              SELECT A.SALES_CENTER_CODE,
                     A.ITEM_CODE,
                     P_OLD_PRODUCING_AREA_CODE, --原产地
                     P_NEW_PRODUCING_AREA_CODE,
                     A.COST_PRICE - VN_COST_PRICE --成本差
                FROM T_PLN_CUSTOMER_PRIORITY A, T_PLN_ITEM_PRODUCING_AREA B
               WHERE A.SALES_CENTER_CODE = C_PLN_EXCESS_ITEM.SALES_CENTER_CODE
                 AND A.ITEM_CODE = C_PLN_EXCESS_ITEM.ITEM_CODE
                 AND A.PRODUCING_AREA_CODE = P_NEW_PRODUCING_AREA_CODE
                 AND A.ENTITY_ID = P_ENTITY_ID
                 AND B.ITEM_CODE = A.ITEM_CODE --判断产品在P_NEW_PRODUCING_AREA_CODE产地是否生产
                 AND B.PRODUCING_AREA_CODE = A.PRODUCING_AREA_CODE;
            --目的产地产品不存在，取销司区域辐射
            VN_SUB_COST_PRICE := 10000;
            FOR C_PLN_PRODUCING_AREA IN
              (SELECT A.PRODUCING_AREA_CODE
                 FROM T_PLN_CUSTOMER_PRIORITY A,
                      T_PLN_ITEM_PRODUCING_AREA B
                WHERE A.SALES_CENTER_CODE = C_PLN_EXCESS_ITEM.SALES_CENTER_CODE
                  AND A.ITEM_CODE IS NULL
                  AND A.PRODUCING_AREA_CODE <> P_NEW_PRODUCING_AREA_CODE
                  AND A.ENTITY_ID = P_ENTITY_ID
                  AND B.ITEM_CODE = C_PLN_EXCESS_ITEM.ITEM_CODE --判断产品在C_PLN_EXCESS_PLASTIC.PRODUCING_AREA_CODE以外的产地是否生产
                  AND B.PRODUCING_AREA_CODE = A.PRODUCING_AREA_CODE) LOOP
              VN_SUB_COST_PRICE := VN_SUB_COST_PRICE + 1;
              INSERT INTO T_PLN_COST_PRIORITY
                (SALES_CENTER_CODE,
                 ITEM_CODE,
                 OLD_PRODUCING_AREA_CODE,
                 NEW_PRODUCING_AREA_CODE,
                 SUB_COST_PRICE)
                VALUES(C_PLN_EXCESS_ITEM.SALES_CENTER_CODE,
                       C_PLN_EXCESS_ITEM.ITEM_CODE,
                       P_OLD_PRODUCING_AREA_CODE,
                       P_NEW_PRODUCING_AREA_CODE,
                       VN_SUB_COST_PRICE);
             END LOOP;
          --原产地产品不存在
          ELSE
            --目的产地产品存在，取产品综合成本
            INSERT INTO T_PLN_COST_PRIORITY
              (SALES_CENTER_CODE,
               ITEM_CODE,
               OLD_PRODUCING_AREA_CODE,
               NEW_PRODUCING_AREA_CODE,
               SUB_COST_PRICE)
              SELECT A.SALES_CENTER_CODE,
                     A.ITEM_CODE,
                     P_OLD_PRODUCING_AREA_CODE, --原产地
                     P_NEW_PRODUCING_AREA_CODE,
                     ROWNUM + 10000 --成本差
                FROM T_PLN_CUSTOMER_PRIORITY A, T_PLN_ITEM_PRODUCING_AREA B
               WHERE A.SALES_CENTER_CODE = C_PLN_EXCESS_ITEM.SALES_CENTER_CODE
                 AND A.ITEM_CODE = C_PLN_EXCESS_ITEM.ITEM_CODE
                 AND A.PRODUCING_AREA_CODE = P_NEW_PRODUCING_AREA_CODE
                 AND A.ENTITY_ID = P_ENTITY_ID
                 AND B.ITEM_CODE = A.ITEM_CODE --判断产品在P_NEW_PRODUCING_AREA_CODE产地是否生产
                 AND B.PRODUCING_AREA_CODE = A.PRODUCING_AREA_CODE;
            --目的产地产品不存在，取销司区域辐射
            VN_SUB_COST_PRICE := 10000;
            FOR C_PLN_PRODUCING_AREA2 IN
              (SELECT A.PRODUCING_AREA_CODE
                 FROM T_PLN_CUSTOMER_PRIORITY A,
                      T_PLN_ITEM_PRODUCING_AREA B
                WHERE A.SALES_CENTER_CODE = C_PLN_EXCESS_ITEM.SALES_CENTER_CODE
                  AND A.ITEM_CODE IS NULL
                  AND A.PRODUCING_AREA_CODE <> P_NEW_PRODUCING_AREA_CODE
                  AND A.ENTITY_ID = P_ENTITY_ID
                  AND B.ITEM_CODE = C_PLN_EXCESS_ITEM.ITEM_CODE --判断产品在C_PLN_EXCESS_PLASTIC.PRODUCING_AREA_CODE以外的产地是否生产
                  AND B.PRODUCING_AREA_CODE = A.PRODUCING_AREA_CODE
                ORDER BY A.PRODUCING_AREA_PRIORITY) LOOP
              VN_SUB_COST_PRICE := VN_SUB_COST_PRICE + 1;
              INSERT INTO T_PLN_COST_PRIORITY
                (SALES_CENTER_CODE,
                 ITEM_CODE,
                 OLD_PRODUCING_AREA_CODE,
                 NEW_PRODUCING_AREA_CODE,
                 SUB_COST_PRICE)
                VALUES(C_PLN_EXCESS_ITEM.SALES_CENTER_CODE,
                       C_PLN_EXCESS_ITEM.ITEM_CODE,
                       P_OLD_PRODUCING_AREA_CODE,
                       P_NEW_PRODUCING_AREA_CODE,
                       VN_SUB_COST_PRICE);
            END LOOP;
          END IF;
      END LOOP;

      --待调整销司的产品成本优先级
      FOR C_PLN_COST_PRIORITY IN
        (SELECT *
           FROM T_PLN_COST_PRIORITY
          ORDER BY SUB_COST_PRICE) LOOP

        SELECT B.CHECK_QTY
          INTO VN_CHECK_QTY --被调整产品数量
          FROM T_PLN_ORDER_HEAD A, T_PLN_ORDER_LINE B
         WHERE ORDER_TYPE_ID = P_ORDER_TYPE_ID
           AND PERIOD_ID = P_PERIOD_ID
           AND FORM_STATE = 25
           AND A.BATCH_ID = P_BATCH_ID
           AND A.ENTITY_ID = P_ENTITY_ID
           AND A.ORDER_HEAD_ID = B.ORDER_HEAD_ID
           AND A.SALES_CENTER_CODE = C_PLN_COST_PRIORITY.SALES_CENTER_CODE
           AND B.PRODUCING_AREA_CODE = C_PLN_COST_PRIORITY.OLD_PRODUCING_AREA_CODE
           AND B.ITEM_CODE = C_PLN_COST_PRIORITY.ITEM_CODE;

        SELECT PLASTIC_CODE
          INTO VS_PLASTIC_CODE
          FROM T_PLN_ITEM_PLASTIC
         WHERE ITEM_CODE = C_PLN_COST_PRIORITY.ITEM_CODE
           AND ENTITY_ID = P_ENTITY_ID;

        BEGIN
          VN_SURPLUS_PRODUCTIVITY := -99999999;
          SELECT SURPLUS_PRODUCTIVITY - ORDER_QTY
            INTO VN_SURPLUS_PRODUCTIVITY --待调整模具的剩余产能
            FROM T_PLN_ORDER_MOULD_INTF
           WHERE ORDER_TYPE_ID = P_ORDER_TYPE_ID
             AND PERIOD_ID = P_PERIOD_ID
             AND PLASTIC_CODE = VS_PLASTIC_CODE
             AND PRODUCING_AREA_CODE = C_PLN_COST_PRIORITY.NEW_PRODUCING_AREA_CODE
             AND ENTITY_ID = P_ENTITY_ID;
        EXCEPTION
          WHEN OTHERS THEN
          NULL;
        END;

        /*BEGIN
          VN_NEW_CHECK_QTY := -1;
          SELECT B.CHECK_QTY
           INTO VN_NEW_CHECK_QTY --待调整产品数量
           FROM T_PLN_ORDER_HEAD A, T_PLN_ORDER_LINE B
          WHERE ORDER_TYPE_ID = P_ORDER_TYPE_ID
            AND PERIOD_ID = P_PERIOD_ID
            AND FORM_STATE = 25
            AND A.ORDER_HEAD_ID = B.ORDER_HEAD_ID
            AND A.SALES_CENTER_CODE = C_PLN_COST_PRIORITY.SALES_CENTER_CODE
            AND B.ITEM_CODE = C_PLN_COST_PRIORITY.ITEM_CODE
            AND B.PRODUCING_AREA_CODE = C_PLN_COST_PRIORITY.NEW_PRODUCING_AREA_CODE;
        EXCEPTION
          WHEN OTHERS THEN
          NULL;
        END;
        --判断待调整产品数量是否存在
        IF VN_NEW_CHECK_QTY <> -1 THEN
          BEGIN
            VN_SURPLUS_PRODUCTIVITY := -99999999;
            SELECT PLASTIC_PRODUCTIVITY - NVL(SURPLUS_PRODUCTIVITY, 0) - VN_NEW_CHECK_QTY SURPLUS_PRODUCTIVITY
              INTO VN_SURPLUS_PRODUCTIVITY --待调整模具的剩余产能
              FROM T_PLN_MOULD_PRODUCTIVITY_AREA
             WHERE PERIOD_ID = P_PERIOD_ID
               AND PLASTIC_CODE = VS_PLASTIC_CODE
               AND PRODUCING_AREA_CODE = C_PLN_COST_PRIORITY.NEW_PRODUCING_AREA_CODE;
          EXCEPTION
            WHEN OTHERS THEN
            NULL;
          END;
        ELSE
          BEGIN
            VN_SURPLUS_PRODUCTIVITY := -99999999;
            SELECT PLASTIC_PRODUCTIVITY - NVL(SURPLUS_PRODUCTIVITY, 0) SURPLUS_PRODUCTIVITY
              INTO VN_SURPLUS_PRODUCTIVITY --待调整模具的剩余产能
              FROM T_PLN_MOULD_PRODUCTIVITY_AREA
             WHERE PERIOD_ID = P_PERIOD_ID
               AND PLASTIC_CODE = VS_PLASTIC_CODE
               AND PRODUCING_AREA_CODE = C_PLN_COST_PRIORITY.NEW_PRODUCING_AREA_CODE;
          EXCEPTION
            WHEN OTHERS THEN
            NULL;
          END;
        END IF;*/
        --判断待调整模具的剩余产能是否存在
        IF VN_SURPLUS_PRODUCTIVITY = -99999999 THEN
          SELECT ITEM_NAME
            INTO VS_ITEM_NAME
            FROM T_BD_ITEM
           WHERE ITEM_CODE = C_PLN_COST_PRIORITY.ITEM_CODE
             AND ENTITY_ID = P_ENTITY_ID;

          SELECT PRODUCING_AREA_NAME
            INTO VS_PRODUCING_AREA_NAME
            FROM T_PLN_PRODUCING_AREA
           WHERE PRODUCING_AREA_CODE = C_PLN_COST_PRIORITY.NEW_PRODUCING_AREA_CODE
             AND ENTITY_ID = P_ENTITY_ID;
          P_RESULT := '产品：' || C_PLN_COST_PRIORITY.ITEM_CODE || ' ' || VS_ITEM_NAME || '在'
              || C_PLN_COST_PRIORITY.NEW_PRODUCING_AREA_CODE || ' ' || VS_PRODUCING_AREA_NAME || '可以生产，但T_PLN_MOULD_PRODUCTIVITY_AREA（产地-模具产能维护）没有维护该产地。';
          ROLLBACK;
          RETURN;
        --判断调整数量是否大于被调整产品数量
        ELSIF VN_ADJUST_QTY >= VN_CHECK_QTY THEN
          --判断新产地是否有模具剩余产能，模具剩余产能是否大于被调整产品数量
          IF VN_SURPLUS_PRODUCTIVITY >= VN_CHECK_QTY AND VN_SURPLUS_PRODUCTIVITY > 0 THEN
            INSERT INTO T_PLN_ORDER_ADJUST
              (ORDER_ADJUST_ID,
               ORDER_TYPE_ID,
               PERIOD_ID,
               ITEM_CODE,
               ITEM_NAME,
               SALES_CENTER_CODE,
               SALES_CENTER_NAME,
               OLD_PRODUCING_AREA_CODE,
               NEW_PRODUCING_AREA_CODE,
               ORDER_QTY,
               ADJUST_QTY,
               ENTITY_ID,
               CREATED_BY,
               CREATION_DATE,
               LAST_UPDATED_BY,
               LAST_UPDATE_DATE)
              VALUES(S_PLN_ORDER_ADJUST.NEXTVAL,
                     P_ORDER_TYPE_ID,
                     P_PERIOD_ID,
                     C_PLN_COST_PRIORITY.ITEM_CODE,
                     (SELECT ITEM_NAME
                        FROM T_BD_ITEM
                       WHERE ITEM_CODE = C_PLN_COST_PRIORITY.ITEM_CODE
                         AND ENTITY_ID = P_ENTITY_ID),
                     C_PLN_COST_PRIORITY.SALES_CENTER_CODE,
                     (SELECT SALES_CENTER_NAME
                        FROM V_BD_SALES_CENTER
                       WHERE SALES_CENTER_CODE = C_PLN_COST_PRIORITY.SALES_CENTER_CODE
                         AND ENTITY_ID = P_ENTITY_ID),
                     C_PLN_COST_PRIORITY.OLD_PRODUCING_AREA_CODE,
                     C_PLN_COST_PRIORITY.NEW_PRODUCING_AREA_CODE,
                     VN_CHECK_QTY,
                     VN_CHECK_QTY,
                     P_ENTITY_ID,
                     P_CREATED_BY,
                     SYSDATE,
                     P_CREATED_BY,
                     SYSDATE);

            VN_ADJUST_QTY := VN_ADJUST_QTY - VN_CHECK_QTY;

            --更新订单模具产能临时表（原产地）
            UPDATE T_PLN_ORDER_MOULD_INTF
               SET ORDER_QTY = ORDER_QTY - VN_CHECK_QTY
             WHERE ORDER_TYPE_ID = P_ORDER_TYPE_ID
               AND PERIOD_ID = P_PERIOD_ID
               AND PLASTIC_CODE = VS_PLASTIC_CODE
               AND PRODUCING_AREA_CODE = C_PLN_COST_PRIORITY.OLD_PRODUCING_AREA_CODE
               AND ENTITY_ID = P_ENTITY_ID;
            --更新订单模具产能临时表（目的产地）
            UPDATE T_PLN_ORDER_MOULD_INTF
               SET ORDER_QTY = ORDER_QTY + VN_CHECK_QTY
             WHERE ORDER_TYPE_ID = P_ORDER_TYPE_ID
               AND PERIOD_ID = P_PERIOD_ID
               AND PLASTIC_CODE = VS_PLASTIC_CODE
               AND PRODUCING_AREA_CODE = C_PLN_COST_PRIORITY.NEW_PRODUCING_AREA_CODE
               AND ENTITY_ID = P_ENTITY_ID;

             VN_RETURN_QTY := VN_RETURN_QTY + VN_CHECK_QTY;

          ELSIF VN_SURPLUS_PRODUCTIVITY < VN_CHECK_QTY AND VN_SURPLUS_PRODUCTIVITY > 0 THEN
            INSERT INTO T_PLN_ORDER_ADJUST
             (ORDER_ADJUST_ID,
              ORDER_TYPE_ID,
              PERIOD_ID,
              ITEM_CODE,
              ITEM_NAME,
              SALES_CENTER_CODE,
              SALES_CENTER_NAME,
              OLD_PRODUCING_AREA_CODE,
              NEW_PRODUCING_AREA_CODE,
              ORDER_QTY,
              ADJUST_QTY,
              ENTITY_ID,
              CREATED_BY,
              CREATION_DATE,
              LAST_UPDATED_BY,
              LAST_UPDATE_DATE)
             VALUES(S_PLN_ORDER_ADJUST.NEXTVAL,
                    P_ORDER_TYPE_ID,
                    P_PERIOD_ID,
                    C_PLN_COST_PRIORITY.ITEM_CODE,
                    (SELECT ITEM_NAME
                       FROM T_BD_ITEM
                      WHERE ITEM_CODE = C_PLN_COST_PRIORITY.ITEM_CODE
                        AND ENTITY_ID = P_ENTITY_ID),
                    C_PLN_COST_PRIORITY.SALES_CENTER_CODE,
                    (SELECT SALES_CENTER_NAME
                       FROM V_BD_SALES_CENTER
                      WHERE SALES_CENTER_CODE = C_PLN_COST_PRIORITY.SALES_CENTER_CODE
                        AND ENTITY_ID = P_ENTITY_ID),
                    C_PLN_COST_PRIORITY.OLD_PRODUCING_AREA_CODE,
                    C_PLN_COST_PRIORITY.NEW_PRODUCING_AREA_CODE,
                    VN_CHECK_QTY,
                    VN_SURPLUS_PRODUCTIVITY,
                    P_ENTITY_ID,
                    P_CREATED_BY,
                    SYSDATE,
                    P_CREATED_BY,
                    SYSDATE);

            VN_ADJUST_QTY := VN_ADJUST_QTY - VN_SURPLUS_PRODUCTIVITY;

            --更新订单模具产能临时表（原产地）
            UPDATE T_PLN_ORDER_MOULD_INTF
               SET ORDER_QTY = ORDER_QTY - VN_SURPLUS_PRODUCTIVITY
             WHERE ORDER_TYPE_ID = P_ORDER_TYPE_ID
               AND PERIOD_ID = P_PERIOD_ID
               AND PLASTIC_CODE = VS_PLASTIC_CODE
               AND PRODUCING_AREA_CODE = C_PLN_COST_PRIORITY.OLD_PRODUCING_AREA_CODE
               AND ENTITY_ID = P_ENTITY_ID;
            --更新订单模具产能临时表（目的产地）
            UPDATE T_PLN_ORDER_MOULD_INTF
               SET ORDER_QTY = ORDER_QTY + VN_SURPLUS_PRODUCTIVITY
             WHERE ORDER_TYPE_ID = P_ORDER_TYPE_ID
               AND PERIOD_ID = P_PERIOD_ID
               AND PLASTIC_CODE = VS_PLASTIC_CODE
               AND PRODUCING_AREA_CODE = C_PLN_COST_PRIORITY.NEW_PRODUCING_AREA_CODE
               AND ENTITY_ID = P_ENTITY_ID;

            VN_RETURN_QTY := VN_RETURN_QTY + VN_SURPLUS_PRODUCTIVITY;
          END IF;
        ELSIF VN_ADJUST_QTY < VN_CHECK_QTY AND VN_ADJUST_QTY > 0 THEN
          --判断新产地是否有模具剩余产能，模具剩余产能是否大于调整数量
          IF VN_SURPLUS_PRODUCTIVITY >= VN_ADJUST_QTY AND VN_SURPLUS_PRODUCTIVITY > 0 THEN
            INSERT INTO T_PLN_ORDER_ADJUST
              (ORDER_ADJUST_ID,
               ORDER_TYPE_ID,
               PERIOD_ID,
               ITEM_CODE,
               ITEM_NAME,
               SALES_CENTER_CODE,
               SALES_CENTER_NAME,
               OLD_PRODUCING_AREA_CODE,
               NEW_PRODUCING_AREA_CODE,
               ORDER_QTY,
               ADJUST_QTY,
               ENTITY_ID,
               CREATED_BY,
               CREATION_DATE,
               LAST_UPDATED_BY,
               LAST_UPDATE_DATE)
              VALUES(S_PLN_ORDER_ADJUST.NEXTVAL,
                     P_ORDER_TYPE_ID,
                     P_PERIOD_ID,
                     C_PLN_COST_PRIORITY.ITEM_CODE,
                     (SELECT ITEM_NAME
                        FROM T_BD_ITEM
                       WHERE ITEM_CODE = C_PLN_COST_PRIORITY.ITEM_CODE
                         AND ENTITY_ID = P_ENTITY_ID),
                     C_PLN_COST_PRIORITY.SALES_CENTER_CODE,
                     (SELECT SALES_CENTER_NAME
                        FROM V_BD_SALES_CENTER
                       WHERE SALES_CENTER_CODE = C_PLN_COST_PRIORITY.SALES_CENTER_CODE
                         AND ENTITY_ID = P_ENTITY_ID),
                     C_PLN_COST_PRIORITY.OLD_PRODUCING_AREA_CODE,
                     C_PLN_COST_PRIORITY.NEW_PRODUCING_AREA_CODE,
                     VN_ADJUST_QTY,
                     VN_ADJUST_QTY,
                     P_ENTITY_ID,
                     P_CREATED_BY,
                     SYSDATE,
                     P_CREATED_BY,
                     SYSDATE);

            VN_TEMP_QTY := VN_ADJUST_QTY;
            VN_ADJUST_QTY := VN_ADJUST_QTY - VN_ADJUST_QTY;

            --更新订单模具产能临时表（原产地）
            UPDATE T_PLN_ORDER_MOULD_INTF
               SET ORDER_QTY = ORDER_QTY - VN_TEMP_QTY
             WHERE ORDER_TYPE_ID = P_ORDER_TYPE_ID
               AND PERIOD_ID = P_PERIOD_ID
               AND PLASTIC_CODE = VS_PLASTIC_CODE
               AND PRODUCING_AREA_CODE = C_PLN_COST_PRIORITY.OLD_PRODUCING_AREA_CODE
               AND ENTITY_ID = P_ENTITY_ID;
            --更新订单模具产能临时表（目的产地）
            UPDATE T_PLN_ORDER_MOULD_INTF
               SET ORDER_QTY = ORDER_QTY + VN_TEMP_QTY
             WHERE ORDER_TYPE_ID = P_ORDER_TYPE_ID
               AND PERIOD_ID = P_PERIOD_ID
               AND PLASTIC_CODE = VS_PLASTIC_CODE
               AND PRODUCING_AREA_CODE = C_PLN_COST_PRIORITY.NEW_PRODUCING_AREA_CODE
               AND ENTITY_ID = P_ENTITY_ID;

             VN_RETURN_QTY := VN_RETURN_QTY + VN_TEMP_QTY;

          ELSIF VN_SURPLUS_PRODUCTIVITY < VN_ADJUST_QTY AND VN_SURPLUS_PRODUCTIVITY > 0 THEN
            INSERT INTO T_PLN_ORDER_ADJUST
             (ORDER_ADJUST_ID,
              ORDER_TYPE_ID,
              PERIOD_ID,
              ITEM_CODE,
              ITEM_NAME,
              SALES_CENTER_CODE,
              SALES_CENTER_NAME,
              OLD_PRODUCING_AREA_CODE,
              NEW_PRODUCING_AREA_CODE,
              ORDER_QTY,
              ADJUST_QTY,
              ENTITY_ID,
              CREATED_BY,
              CREATION_DATE,
              LAST_UPDATED_BY,
              LAST_UPDATE_DATE)
             VALUES(S_PLN_ORDER_ADJUST.NEXTVAL,
                    P_ORDER_TYPE_ID,
                    P_PERIOD_ID,
                    C_PLN_COST_PRIORITY.ITEM_CODE,
                    (SELECT ITEM_NAME
                       FROM T_BD_ITEM
                      WHERE ITEM_CODE = C_PLN_COST_PRIORITY.ITEM_CODE
                        AND ENTITY_ID = P_ENTITY_ID),
                    C_PLN_COST_PRIORITY.SALES_CENTER_CODE,
                    (SELECT SALES_CENTER_NAME
                       FROM V_BD_SALES_CENTER
                      WHERE SALES_CENTER_CODE = C_PLN_COST_PRIORITY.SALES_CENTER_CODE
                        AND ENTITY_ID = P_ENTITY_ID),
                    C_PLN_COST_PRIORITY.OLD_PRODUCING_AREA_CODE,
                    C_PLN_COST_PRIORITY.NEW_PRODUCING_AREA_CODE,
                    VN_CHECK_QTY,
                    VN_SURPLUS_PRODUCTIVITY,
                    P_ENTITY_ID,
                    P_CREATED_BY,
                    SYSDATE,
                    P_CREATED_BY,
                    SYSDATE);

            VN_ADJUST_QTY := VN_ADJUST_QTY - VN_SURPLUS_PRODUCTIVITY;

            --更新订单模具产能临时表（原产地）
            UPDATE T_PLN_ORDER_MOULD_INTF
               SET ORDER_QTY = ORDER_QTY - VN_SURPLUS_PRODUCTIVITY
             WHERE ORDER_TYPE_ID = P_ORDER_TYPE_ID
               AND PERIOD_ID = P_PERIOD_ID
               AND PLASTIC_CODE = VS_PLASTIC_CODE
               AND PRODUCING_AREA_CODE = C_PLN_COST_PRIORITY.OLD_PRODUCING_AREA_CODE
               AND ENTITY_ID = P_ENTITY_ID;
            --更新订单模具产能临时表（目的产地）
            UPDATE T_PLN_ORDER_MOULD_INTF
               SET ORDER_QTY = ORDER_QTY + VN_SURPLUS_PRODUCTIVITY
             WHERE ORDER_TYPE_ID = P_ORDER_TYPE_ID
               AND PERIOD_ID = P_PERIOD_ID
               AND PLASTIC_CODE = VS_PLASTIC_CODE
               AND PRODUCING_AREA_CODE = C_PLN_COST_PRIORITY.NEW_PRODUCING_AREA_CODE
               AND ENTITY_ID = P_ENTITY_ID;

            VN_RETURN_QTY := VN_RETURN_QTY + VN_SURPLUS_PRODUCTIVITY;
          END IF;
        END IF;
      END LOOP;
      EXECUTE IMMEDIATE 'TRUNCATE TABLE T_PLN_COST_PRIORITY';

    END LOOP;

    IF VN_RETURN_QTY > P_ADJUST_QTY THEN
      VN_RETURN_QTY := P_ADJUST_QTY;
    END IF;
    P_RESULT :=  'OK' || VN_RETURN_QTY;
    ROLLBACK;

  EXCEPTION
    WHEN OTHERS THEN
      P_RESULT := '校验调整数量失败。' || V_NL || '失败信息：' || SQLERRM;
      ROLLBACK;
  END;

  ----------------------------------------------------------------------
  -- Author  : Lizhen
  -- Created : 2014-11-18 16:12:00
  -- Purpose : 根据汇总订单行，生成产品分解行信息
  ----------------------------------------------------------------------
  PROCEDURE P_CREATE_ITEM_ALLOT(P_COLL_ORD_HEAD_ID     IN NUMBER,  --汇总头ID
                                P_COLL_ORD_LINE_ID     IN NUMBER,   --汇总行ID
                                P_PRODUCING_AREA_LIST  IN VARCHAR2, --产地ID更表，为NULL表示评审所有产地
                                P_ENTITY_ID            IN NUMBER,   --主体ID
                                P_USER_CODE            IN VARCHAR2, --创建人
                                P_RESULT               OUT VARCHAR2) IS
    TYPE C_GET_PRODUCING_AREA IS REF CURSOR; --声明动态游标
    V_PRODUCING_AREA C_GET_PRODUCING_AREA;
    R_PRODUCING_AREA T_PLN_PRODUCING_AREA%ROWTYPE;

    R_COLL_HEAD       T_PLN_ORDER_COLLECT_HEAD%ROWTYPE;
    V_MONTH_PERIOD_ID  NUMBER;
    V_WHERE            VARCHAR2(2000);
    V_SQL              VARCHAR2(4000);
    V_INDEX            NUMBER := 0;
    VS_NAME            VARCHAR2(20);
    V_UPDATE_SQL       VARCHAR2(4000);
    v_is_week          varchar2(2);
    V_COUNT            NUMBER;
    V_ACCOUNT_SYS      VARCHAR2(100);
    V_MAIN_TYPE_FILTER VARCHAR2(100);
  BEGIN
    P_RESULT := V_SUCCESS;

    BEGIN

      SELECT *
        INTO R_COLL_HEAD
        FROM T_PLN_ORDER_COLLECT_HEAD CH
       WHERE CH.COLL_ORD_HEAD_ID = P_COLL_ORD_HEAD_ID;

    EXCEPTION
      WHEN OTHERS THEN
        P_RESULT := '查询汇总订单头失败。' || V_NL || '汇总头ID：' ||
                    TO_CHAR(P_COLL_ORD_HEAD_ID) || V_NL || SQLERRM;
        RAISE V_BASE_EXCEPTION;
    END;

    select ty.is_week into v_is_week from t_pln_order_type ty
     where ty.order_type_id=R_COLL_HEAD.Order_Type_Id
     and ty.entity_id=R_COLL_HEAD.Entity_Id;
   
    BEGIN
      SELECT PKG_BD.F_GET_PARAMETER_VALUE('ACCOUNT_SYS', P_ENTITY_ID)
        INTO V_ACCOUNT_SYS
        FROM DUAL;
    EXCEPTION
      WHEN OTHERS THEN
        P_RESULT := '获取参数失败，参数编码：ACCOUNT_SYS';
        RAISE V_BASE_EXCEPTION;
    END;
    
    BEGIN
      SELECT PKG_BD.F_GET_PARAMETER_VALUE('ITEM_SALES_MAIN_TYPE_FILTER',
                                          P_ENTITY_ID)
        INTO V_MAIN_TYPE_FILTER
        FROM DUAL;
    EXCEPTION
      WHEN OTHERS THEN
        P_RESULT := '获取参数失败，参数编码：ITEM_SALES_MAIN_TYPE_FILTER';
        RAISE V_BASE_EXCEPTION;
    END;

    BEGIN
      SELECT OPP.PERIOD_ID
        INTO V_MONTH_PERIOD_ID
        FROM T_PLN_ORDER_PERIOD OP, T_PLN_ORDER_PERIOD OPP
       WHERE OP.PERIOD_ID = R_COLL_HEAD.PERIOD_ID
         AND OPP.PERIOD_ID = OP.PARENT_PERIOD_ID
         AND OPP.PERIOD_TYPE = '月';
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        V_MONTH_PERIOD_ID := NULL;
      WHEN OTHERS THEN
        P_RESULT := '获取月周期ID失败，周订单周期ID:' || TO_CHAR(R_COLL_HEAD.PERIOD_ID) || V_NL ||
                    SQLERRM;
        RAISE V_BASE_EXCEPTION;
    END;

    --增加检查订单汇总行关系表，同一订单行只允许存在一行数据
    SELECT COUNT(1)
      INTO V_COUNT
      FROM (SELECT COUNT(L.ORDER_LINE_ID) ROW_COUNT
              FROM T_PLN_ORDER_HEAD             H,
                   T_PLN_ORDER_LINE             L,
                   T_PLN_ORDER_COLLECT_RELATION OCR,
                   T_PLN_ORDER_COLLECT_HEAD     OCH,
                   T_PLN_ORDER_COLLECT_LINE     OCL
             WHERE OCH.COLL_ORD_HEAD_ID = P_COLL_ORD_HEAD_ID
               AND OCL.COLL_ORD_HEAD_ID = OCH.COLL_ORD_HEAD_ID
               AND OCL.COLL_ORD_LINE_ID = OCR.COLL_ORD_LINE_ID
               AND OCR.ORDER_LINE_ID = L.ORDER_LINE_ID
               AND H.ORDER_HEAD_ID = L.ORDER_HEAD_ID
               AND L.ENTITY_ID = P_ENTITY_ID HAVING
             COUNT(L.ORDER_LINE_ID) > 1
             GROUP BY L.ORDER_LINE_ID);
    IF V_COUNT > 0 THEN
      P_RESULT := '同一订单行在汇总行与订单行关系表存在多行数据，评审失败。' || V_NL ||
        '汇总订单头ID：' || TO_CHAR(P_COLL_ORD_HEAD_ID);
      RETURN;
    END IF;

    --删除未评审的临时数据
    DELETE FROM T_PLN_SALES_CENTER_PA CP
     WHERE CP.COLL_ORD_HEAD_ID = P_COLL_ORD_HEAD_ID
       AND CP.COLL_ORD_LINE_ID = P_COLL_ORD_LINE_ID
       AND CP.TYPE_FLAG IS NULL;

    --先插入关联的订单行数据
    BEGIN
      INSERT INTO T_PLN_SALES_CENTER_PA
        (SALES_CENTER_PA_ID,
         ENTITY_ID, --主体ID
         COLL_ORD_HEAD_ID, --汇总头ID
         COLL_ORD_LINE_ID, --汇总行ID
         ORDER_HEAD_ID, --订单头ID
         ORDER_LINE_ID, --订单知ID
         ORDER_NUMBER, --订单单号
         ORDER_TYPE_ID, --单据类型ID
         PERIOD_ID, --周期ID
         ITEM_CODE, --产品ID
         ITEM_NAME, --产品描述
         SALES_CENTER_CODE, --营销中心编码
         SALES_CENTER_NAME, --营销中心描述
         customerId,--客户Id
         customerCode,--客户编码
         customername,--客户名称
         accountcode,--账户编码
         accountId,--账户名称
         APPLY_QTY, --申请数量
         INV_AFFIRM_QTY, --库存评审数量
         MONTH_CAN_TOTAL_QTY, --月计划需求数量汇总
         WEEK_CAN_TOTAL_QTY, --周订单已排产数量汇总
         CHECK_TOTAL_QTY, --申请数量汇总
         RERIEW_TOTAL_QTY, --本次评审数量汇总
         CHECK_QTY, --评审数量
         CREATED_BY, --创建人
         CREATION_DATE, --创建日期
         LAST_UPDATED_BY, --最后修改人
         LAST_UPDATE_DATE, --最后修改日期
         PROGRAM_UPDATED_BY,
         PROGRAM_UPDATE_DATE,
         VERSION,
         TYPE_FLAG,
         PRE_FIELD_01,
         PRE_FIELD_02,
         PRE_FIELD_03,
         PRE_FIELD_04,
         PRE_FIELD_05,
         PRE_FIELD_06,
         PRODUCING_AREA_CODE_1ST)
        SELECT S_PLN_SALES_CENTER_PA.NEXTVAL,
               PLN.ENTITY_ID, --主体ID
               PLN.COLL_ORD_HEAD_ID, --汇总头ID
               PLN.COLL_ORD_LINE_ID, --汇总行ID
               PLN.ORDER_HEAD_ID, --订单头ID
               NULL ORDER_LINE_ID, --订单行ID
               PLN.ORDER_NUMBER, --订单单号
               PLN.ORDER_TYPE_ID, --单据类型ID
               PLN.PERIOD_ID, --周期ID
               PLN.ITEM_CODE, --产品ID
               PLN.ITEM_DESC, --产品描述
               PLN.SALES_CENTER_CODE, --营销中心编码
               PLN.SALES_CENTER_NAME, --营销中心描述
               pln.customer_id,
               pln.customer_code,
               pln.customer_name,
               pln.account_code,
               pln.account_Id,
               PLN.APPLY_QTY, --申请数量
               PLN.INV_AFFIRM_QTY, --库存评审数量
               0, --MONTH_CAN_TOTAL_QTY, --月计划需求数量汇总
               0, --WEEK_CAN_TOTAL_QTY, --周订单已排产数量汇总
               0, --CHECK_TOTAL_QTY, --申请数量汇总
               0, --RERIEW_TOTAL_QTY, --本次评审数量汇总
               PLN.CHECK_QTY, --评审数量
               P_USER_CODE, --CREATED_BY, --创建人
               SYSDATE, --CREATION_DATE, --创建日期
               P_USER_CODE, --LAST_UPDATED_BY, --最后修改人
               SYSDATE, --LAST_UPDATE_DATE, --最后修改日期
               NULL, --PROGRAM_UPDATED_BY,
               NULL, --PROGRAM_UPDATE_DATE,
               1, --VERSION,
               NULL, --TYPE_FLAG,
               NULL, --PRE_FIELD_01,
               NULL, --PRE_FIELD_02,
               NULL, --PRE_FIELD_03,
               NULL, --PRE_FIELD_04,
               NULL, --PRE_FIELD_05,
               NULL, --PRE_FIELD_06
               '_' --PRODUCING_AREA_CODE_1ST
          FROM (SELECT POH.ENTITY_ID, --主体ID
                       OCH.COLL_ORD_HEAD_ID, --汇总头ID
                       OCL.COLL_ORD_LINE_ID, --汇总行ID
                       POH.ORDER_HEAD_ID, --订单头ID
                       --POL.ORDER_LINE_ID, --订单行ID
                       POH.ORDER_NUMBER, --订单单号
                       POH.ORDER_TYPE_ID, --单据类型ID
                       POH.PERIOD_ID, --周期ID
                       POL.ITEM_CODE, --产品ID
                       POL.ITEM_DESC, --产品描述
                       POH.SALES_CENTER_CODE, --营销中心编码
                       POH.SALES_CENTER_NAME, --营销中心描述
                       poh.customer_id,
                       poh.customer_code,
                       poh.customer_name,
                       poh.account_id,
                       poh.account_code,
                       SUM(NVL(POL.APPLY_QTY, 0)) APPLY_QTY, --申请数量
                       SUM(NVL(POL.INV_AFFIRM_QTY, 0)) INV_AFFIRM_QTY, --库存评审数量
                       SUM(NVL(POL.CHECK_QTY, 0)) CHECK_QTY --评审数量
                  FROM T_PLN_ORDER_HEAD             POH,
                       T_PLN_ORDER_LINE             POL,
                       T_PLN_ORDER_COLLECT_RELATION OCR,
                       T_PLN_ORDER_COLLECT_HEAD     OCH,
                       T_PLN_ORDER_COLLECT_LINE     OCL
                 WHERE OCH.COLL_ORD_HEAD_ID = P_COLL_ORD_HEAD_ID
                   AND OCL.COLL_ORD_LINE_ID = P_COLL_ORD_LINE_ID
                   AND OCL.COLL_ORD_HEAD_ID = OCH.COLL_ORD_HEAD_ID
                   AND OCL.COLL_ORD_LINE_ID = OCR.COLL_ORD_LINE_ID
                   AND OCR.ORDER_LINE_ID = POL.ORDER_LINE_ID
                   AND POH.ORDER_HEAD_ID = POL.ORDER_HEAD_ID
                   AND POH.ENTITY_ID = P_ENTITY_ID
                 GROUP BY POH.ENTITY_ID, --主体ID
                          OCH.COLL_ORD_HEAD_ID, --汇总头ID
                          OCL.COLL_ORD_LINE_ID, --汇总行ID
                          POH.ORDER_HEAD_ID, --订单头ID
                          POH.ORDER_NUMBER, --订单单号
                          POH.ORDER_TYPE_ID, --单据类型ID
                          POH.PERIOD_ID, --周期ID
                          POL.ITEM_CODE, --产品ID
                          POL.ITEM_DESC, --产品描述
                          POH.SALES_CENTER_CODE, --营销中心编码
                          POH.SALES_CENTER_NAME, --营销中心描述
                          poh.customer_id,
                          poh.customer_code,
                          poh.customer_name,
                          poh.account_id,
                          poh.account_code
                ) PLN;
    EXCEPTION
      WHEN OTHERS THEN
        P_RESULT := '插入产品分解订单行信息表失败。' || V_NL ||
          '订单汇总头ID：' || TO_CHAR(P_COLL_ORD_HEAD_ID) || V_NL ||
          '订单汇总行ID：' || TO_CHAR(P_COLL_ORD_LINE_ID) || v_Nl || Sqlerrm;
        RAISE V_BASE_EXCEPTION;
    END;

    --更新产品分解订单行区域辐射第一产地、第二产地字段
    V_UPDATE_SQL := ' UPDATE T_PLN_SALES_CENTER_PA SCP ' || CHR(10) ||
        '   SET SCP.PRODUCING_AREA_CODE_1ST = ' || CHR(10) ||
        '         NVL((SELECT PRODUCING_AREA_CODE ' || CHR(10) ||
        '                FROM T_PLN_CUSTOMER_PRIORITY ' || CHR(10) ||
        '               WHERE PRODUCING_AREA_PRIORITY = ' || CHR(10) ||
        '                 (SELECT MIN(PRODUCING_AREA_PRIORITY) ' || CHR(10) ||
        '                    FROM T_PLN_CUSTOMER_PRIORITY ' || CHR(10) ||
        '                   WHERE SALES_CENTER_CODE = SCP.SALES_CENTER_CODE ' || CHR(10) ||
        '                     AND ITEM_CODE IS NULL ' || CHR(10) ||
        '                     AND ENTITY_ID = ' || TO_CHAR(P_ENTITY_ID) || ' ) ' || CHR(10) ||
        '                 AND SALES_CENTER_CODE = SCP.SALES_CENTER_CODE ' || CHR(10) ||
        '                 AND ITEM_CODE IS NULL ' || CHR(10) ||
        '                 AND ENTITY_ID = ' || TO_CHAR(P_ENTITY_ID) || ' ), ''无''), ' || CHR(10) ||
        '       SCP.PRODUCING_AREA_CODE_2ND = ' || CHR(10) ||
        '         NVL((SELECT PRODUCING_AREA_CODE ' || CHR(10) ||
        '                FROM T_PLN_CUSTOMER_PRIORITY ' || CHR(10) ||
        '               WHERE PRODUCING_AREA_PRIORITY = ' || CHR(10) ||
        '                 (SELECT MIN(PRODUCING_AREA_PRIORITY) + 1 ' || CHR(10) ||
        '                    FROM T_PLN_CUSTOMER_PRIORITY ' || CHR(10) ||
        '                   WHERE SALES_CENTER_CODE = SCP.SALES_CENTER_CODE ' || CHR(10) ||
        '                     AND ITEM_CODE IS NULL ' || CHR(10) ||
        '                     AND ENTITY_ID = ' || TO_CHAR(P_ENTITY_ID) || ' ) ' || CHR(10) ||
        '                 AND SALES_CENTER_CODE = SCP.SALES_CENTER_CODE ' || CHR(10) ||
        '                 AND ITEM_CODE IS NULL ' || CHR(10) ||
        '                 AND ENTITY_ID = ' || TO_CHAR(P_ENTITY_ID) || ' ), ''无'') ' || CHR(10) ||
        ' WHERE SCP.TYPE_FLAG IS NULL AND SCP.COLL_ORD_LINE_ID = ' || TO_CHAR(P_COLL_ORD_LINE_ID) ||
        '   AND SCP.COLL_ORD_HEAD_ID = ' || TO_CHAR(P_COLL_ORD_HEAD_ID) ||
        '   AND SCP.ENTITY_ID = ' || TO_CHAR(P_ENTITY_ID);
    BEGIN
      EXECUTE IMMEDIATE V_UPDATE_SQL;
    EXCEPTION
      WHEN OTHERS Then
        dbms_output.put_line(V_UPDATE_SQL);
        --P_RESULT := V_UPDATE_SQL;
        P_RESULT := '更新产品分解订单行区域辐射第一产地、第二产地字段失败。' || V_NL ||
         '汇总头ID：' || TO_CHAR(P_COLL_ORD_HEAD_ID) || V_NL ||
         '汇总行ID：' || TO_CHAR(P_COLL_ORD_LINE_ID) || V_NL || SQLERRM;
        RAISE V_BASE_EXCEPTION;
    END;

    --更新产品分解订单行各汇总数量字段
    V_UPDATE_SQL := ' UPDATE T_PLN_SALES_CENTER_PA SCP ' || CHR(10) ||
        '   SET (SCP.APPLY_QTY,' || CHR(10) ||
        '        SCP.INV_AFFIRM_QTY,' || CHR(10) ||
        '        SCP.CHECK_TOTAL_QTY,' || CHR(10) ||
        '        SCP.RERIEW_TOTAL_QTY) =' || CHR(10) ||
        '       (SELECT SUM(NVL(POL.CENTER_CHECK_QTY, NVL(POL.APPLY_QTY, 0))), ' || CHR(10) ||
        '               SUM(NVL(POL.INV_AFFIRM_QTY, 0)), ' || CHR(10) ||
        '               SUM(NVL(POL.CHECK_QTY, 0)),' || CHR(10) ||
        '               SUM(NVL(POL.CAN_PRODUCE_QTY, 0))' || CHR(10) ||
        '          FROM T_PLN_ORDER_HEAD             POH,' || CHR(10) ||
        '               T_PLN_ORDER_LINE             POL,' || CHR(10) ||
        '               T_PLN_ORDER_COLLECT_RELATION OCR,' || CHR(10) ||
        '               T_PLN_ORDER_COLLECT_HEAD     OCH,' || CHR(10) ||
        '               T_PLN_ORDER_COLLECT_LINE     OCL' || CHR(10) ||
        '         WHERE OCH.COLL_ORD_HEAD_ID = SCP.COLL_ORD_HEAD_ID' || CHR(10) ||
        '           AND OCL.COLL_ORD_LINE_ID = SCP.COLL_ORD_LINE_ID' || CHR(10) ||
        '           AND OCH.ENTITY_ID = SCP.ENTITY_ID' || CHR(10) ||
        '           AND POL.ITEM_CODE = SCP.ITEM_CODE' || CHR(10) ||
        '           AND POH.ORDER_TYPE_ID = SCP.ORDER_TYPE_ID' || CHR(10) ||
        '           AND POH.PERIOD_ID = SCP.PERIOD_ID' || CHR(10) ||
        '           AND POH.SALES_CENTER_CODE = SCP.SALES_CENTER_CODE' || CHR(10) ||
        '           AND POL.ORDER_HEAD_ID = SCP.ORDER_HEAD_ID' || CHR(10) ||
        '           AND OCL.COLL_ORD_HEAD_ID = OCH.COLL_ORD_HEAD_ID' || CHR(10) ||
        '           AND OCL.COLL_ORD_LINE_ID = OCR.COLL_ORD_LINE_ID' || CHR(10) ||
        '           AND OCR.ORDER_LINE_ID = POL.ORDER_LINE_ID' || CHR(10) ||
        '           AND POH.ORDER_HEAD_ID = POL.ORDER_HEAD_ID' || CHR(10) ||
        '         GROUP BY POH.ENTITY_ID, ' || CHR(10) ||
        '                  OCH.COLL_ORD_HEAD_ID, ' || CHR(10) ||
        '                  OCL.COLL_ORD_LINE_ID, ' || CHR(10) ||
        '                  POH.ORDER_HEAD_ID, ' || CHR(10) ||
        '                  POH.ORDER_TYPE_ID, ' || CHR(10) ||
        '                  POH.PERIOD_ID, ' || CHR(10) ||
        '                  POL.ITEM_CODE, ' || CHR(10) ||
        '                  POH.SALES_CENTER_CODE, ' || CHR(10) ||
        '                  POH.SALES_CENTER_NAME ' || CHR(10) ||
        '        )' || CHR(10) ||
        ' WHERE SCP.TYPE_FLAG IS NULL AND SCP.COLL_ORD_LINE_ID = ' || TO_CHAR(P_COLL_ORD_LINE_ID) ||
        ' AND SCP.COLL_ORD_HEAD_ID = ' || TO_CHAR(P_COLL_ORD_HEAD_ID) ||
        ' AND SCP.ENTITY_ID = ' || TO_CHAR(P_ENTITY_ID);
    BEGIN
      EXECUTE IMMEDIATE V_UPDATE_SQL;
    EXCEPTION
      WHEN OTHERS Then
        dbms_output.put_line(V_UPDATE_SQL);
        P_RESULT := '更新产品产地订单行各汇总数量字段失败。' || V_NL ||
         '汇总头ID：' || TO_CHAR(P_COLL_ORD_HEAD_ID) || V_NL ||
         '汇总行ID：' || TO_CHAR(P_COLL_ORD_LINE_ID) || V_NL || SQLERRM;
        RAISE V_BASE_EXCEPTION;
    END;
    IF P_PRODUCING_AREA_LIST IS NOT NULL THEN
      V_WHERE := ' AND PA.PRODUCING_AREA_ID IN (' ||  P_PRODUCING_AREA_LIST || ')';
    ELSE
      V_WHERE := ' ';
    END IF;
    --组合产地SQL
    V_SQL := 'SELECT * FROM T_PLN_PRODUCING_AREA PA WHERE PA.ENTITY_ID = ' ||
      TO_CHAR(P_ENTITY_ID) || ' AND TRUNC(SYSDATE) BETWEEN TRUNC(PA.BEGIN_DATE) ' ||
      ' AND TRUNC(NVL(PA.END_DATE, SYSDATE)) ' || V_WHERE ||
      ' ORDER BY PA.PRO_SORT ';
    BEGIN
      OPEN V_PRODUCING_AREA FOR V_SQL;
    EXCEPTION
      WHEN OTHERS Then
        dbms_output.put_line(V_UPDATE_SQL);
        P_RESULT := '获取产地信息列表失败。' || V_NL ||
          '产地ID列表：' || P_PRODUCING_AREA_LIST || V_NL || SQLERRM;
        RAISE V_BASE_EXCEPTION;
    END;
    V_INDEX := 1;
    LOOP
      FETCH V_PRODUCING_AREA INTO R_PRODUCING_AREA;
      EXIT WHEN V_PRODUCING_AREA%NOTFOUND;

      --更新产品分解行订单各产地对应的评审数量及申请数量
      V_UPDATE_SQL := 'UPDATE T_PLN_SALES_CENTER_PA SCP' || CHR(10) ||
        '   SET (SCP.PRDC_ID_' || LPAD(TO_CHAR(V_INDEX), 2, '0') || ',' || CHR(10) ||
        '        SCP.CHECK_QTY_' || LPAD(TO_CHAR(V_INDEX), 2, '0') || ',' || CHR(10) ||
        '        SCP.REVIEW_QTY_' || LPAD(TO_CHAR(V_INDEX), 2, '0') || ',' || CHR(10) ||
        '        SCP.APS_PROMISE_QTY_' || LPAD(TO_CHAR(V_INDEX), 2, '0') ||','|| CHR(10) || 
        '        SCP.APS_PROMISE_TIME_' || LPAD(TO_CHAR(V_INDEX), 2, '0') || ') =' || CHR(10) || --ADD BY ZCC 2015/05/25
        '       (SELECT ' || TO_CHAR(R_PRODUCING_AREA.PRODUCING_AREA_ID) || ',' || CHR(10) ||
        '               SUM(NVL(POL.CHECK_QTY, 0)),' || CHR(10) ||
        '               SUM(NVL(POL.CAN_PRODUCE_QTY, 0) -' || CHR(10) ||
        '                   NVL(POL.CANCEL_INV_IN_QTY, 0)),' || CHR(10) ||
        '               SUM(NVL(POL.APS_BACK_QTY, 0)),' || CHR(10) ||
        '               POL.APS_PROMISE_TIME'           || CHR(10) ||
        '          FROM T_PLN_ORDER_HEAD             POH,' || CHR(10) ||
        '               T_PLN_ORDER_LINE             POL,' || CHR(10) ||
        '               T_PLN_ORDER_COLLECT_RELATION OCR,' || CHR(10) ||
        '               T_PLN_ORDER_COLLECT_HEAD     OCH,' || CHR(10) ||
        '               T_PLN_ORDER_COLLECT_LINE     OCL' || CHR(10) ||
        '         WHERE OCH.COLL_ORD_HEAD_ID = SCP.COLL_ORD_HEAD_ID' || CHR(10) ||
        '           AND OCL.COLL_ORD_LINE_ID = SCP.COLL_ORD_LINE_ID' || CHR(10) ||
        '           AND OCH.ENTITY_ID = SCP.ENTITY_ID' || CHR(10) ||
        '           AND POL.ITEM_CODE = SCP.ITEM_CODE' || CHR(10) ||
        '           AND POL.ORDER_HEAD_ID = SCP.ORDER_HEAD_ID' || CHR(10) ||
        '           AND POH.ORDER_TYPE_ID = SCP.ORDER_TYPE_ID' || CHR(10) ||
        '           AND POH.PERIOD_ID = SCP.PERIOD_ID' || CHR(10) ||
        '           AND POH.SALES_CENTER_CODE = SCP.SALES_CENTER_CODE' || CHR(10) ||
        '           AND POL.PRODUCING_AREA_ID = ' || TO_CHAR(R_PRODUCING_AREA.PRODUCING_AREA_ID) ||  CHR(10) ||
        '           AND OCL.COLL_ORD_HEAD_ID = OCH.COLL_ORD_HEAD_ID' || CHR(10) ||
        '           AND OCL.COLL_ORD_LINE_ID = OCR.COLL_ORD_LINE_ID' || CHR(10) ||
        '           AND OCR.ORDER_LINE_ID = POL.ORDER_LINE_ID' || CHR(10) ||
        '           AND POH.ORDER_HEAD_ID = POL.ORDER_HEAD_ID' || CHR(10) ||
        '         GROUP BY POH.ENTITY_ID, ' || CHR(10) ||
        '                  OCH.COLL_ORD_HEAD_ID, ' || CHR(10) ||
        '                  OCL.COLL_ORD_LINE_ID, ' || CHR(10) ||
        '                  POH.ORDER_HEAD_ID, ' || CHR(10) ||
        '                  POH.ORDER_TYPE_ID, ' || CHR(10) ||
        '                  POH.PERIOD_ID, ' || CHR(10) ||
        '                  POL.ITEM_CODE,' || CHR(10) ||
        '                  POH.SALES_CENTER_CODE, ' || CHR(10) ||
        '                  POH.SALES_CENTER_NAME ,' || CHR(10) ||
        '                  POL.APS_PROMISE_TIME ' || CHR(10) ||
        '        )' || CHR(10) ||
        ' WHERE  SCP.TYPE_FLAG IS NULL AND SCP.COLL_ORD_LINE_ID = ' || TO_CHAR(P_COLL_ORD_LINE_ID) ||
        ' AND SCP.COLL_ORD_HEAD_ID = ' || TO_CHAR(P_COLL_ORD_HEAD_ID) ||
        ' AND SCP.ENTITY_ID = ' || TO_CHAR(P_ENTITY_ID);
      --dbms_output.put_line(V_UPDATE_SQL);
      BEGIN
       EXECUTE IMMEDIATE V_UPDATE_SQL;
      EXCEPTION
        WHEN OTHERS Then
          P_RESULT := '更新产品分解行订单各产地对应的评审数量及申请数量失败。' || V_NL ||
           '汇总头ID：' || TO_CHAR(P_COLL_ORD_HEAD_ID) || V_NL ||
           '汇总行ID：' || TO_CHAR(P_COLL_ORD_LINE_ID) || V_NL || SQLERRM;
          RAISE V_BASE_EXCEPTION;
      END;

      --月周期ID 不为空才更新数据
      If V_MONTH_PERIOD_ID Is Not Null and nvl(v_is_week,'N')='Y' Then
        --更新周排产对应的月计划需求数量
        V_UPDATE_SQL := 'UPDATE T_PLN_SALES_CENTER_PA SCP' || CHR(10) ||
          '   SET SCP.MONTH_CAN_QTY_' || LPAD(TO_CHAR(V_INDEX), 2, '0') || ' =' || CHR(10) ||
          '       (SELECT SUM(NVL(POL.CAN_PRODUCE_QTY, 0) -' || CHR(10) ||
          '                   NVL(POL.CANCEL_INV_IN_QTY, 0))' || CHR(10) ||
          '          FROM CIMS.T_PLN_ORDER_HEAD POH,' || CHR(10) ||
          '               CIMS.T_PLN_ORDER_LINE POL,' || CHR(10) ||
          '               CIMS.T_PLN_ORDER_TYPE POT' || CHR(10) ||
          '         WHERE POT.ORDER_TYPE_ID = POH.ORDER_TYPE_ID' || CHR(10) ||
          --ADD BY ZCC 2015-6-12
          '           AND POH.FORM_STATE =''23'' ' || CHR(10) ||
          
          '           AND POH.ORDER_HEAD_ID = POL.ORDER_HEAD_ID' || CHR(10) ||
          '           AND POT.ENTITY_ID = POH.ENTITY_ID' || CHR(10) ||
          '           AND POH.PERIOD_ID = ' || TO_CHAR(V_MONTH_PERIOD_ID) || CHR(10) ||
          '           AND POL.PRODUCING_AREA_ID = ' || TO_CHAR(R_PRODUCING_AREA.PRODUCING_AREA_ID) ||
          --' And ((Pkg_Bd.f_Get_Parameter_Value(''ACCOUNT_SYS'', Poh.Entity_Id) = ''N'') Or ' || CHR(10) ||
          ' And ((''' || V_ACCOUNT_SYS || ''' = ''N'') Or ' || CHR(10) ||
          --'    ((Pkg_Bd.f_Get_Parameter_Value(''ACCOUNT_SYS'', Poh.Entity_Id) = ''Y'') And   ' || CHR(10) ||
          '    ((''' || V_ACCOUNT_SYS || ''' = ''Y'') And   ' || CHR(10) ||
          '    Poh.Account_Id =' || CHR(10) ||
          '     (Select Oh.Account_Id' || CHR(10) ||
          '         From t_Pln_Order_Head Oh' || CHR(10) ||
          '        Where Oh.Order_Head_Id = Scp.Order_Head_Id)))' || CHR(10) ||
          --' And ((Pkg_Bd.f_Get_Parameter_Value(''ITEM_SALES_MAIN_TYPE_FILTER'', Poh.Entity_Id) = ''N'') Or' || chr(10) ||
          ' And ((''' || V_MAIN_TYPE_FILTER || ''' = ''N'') Or' || chr(10) ||
          --'   ((Pkg_Bd.f_Get_Parameter_Value(''ITEM_SALES_MAIN_TYPE_FILTER'', Poh.Entity_Id) = ''Y'') And' || chr(10) ||
          '   ((''' || V_MAIN_TYPE_FILTER || ''' = ''Y'') And' || chr(10) ||
          '   Poh.Sales_Main_Type =' || chr(10) ||
          ' (Select Oh.Sales_Main_Type' || chr(10) ||
          '       From t_Pln_Order_Head Oh' || chr(10) ||
          '       Where Oh.Order_Head_Id = Scp.Order_Head_Id)))' || CHR(10) ||
          '           AND POH.ENTITY_ID = SCP.ENTITY_ID' || CHR(10) ||
          '           AND POL.ITEM_CODE = SCP.ITEM_CODE' || CHR(10) ||
          '           AND POT.DEST_ORDER_TYPE_ID = SCP.ORDER_TYPE_ID' || CHR(10) ||
          '           AND POH.SALES_CENTER_CODE = SCP.SALES_CENTER_CODE' || CHR(10) ||
          ')' || CHR(10) ||
          ' WHERE SCP.TYPE_FLAG IS NULL AND SCP.COLL_ORD_LINE_ID = ' || TO_CHAR(P_COLL_ORD_LINE_ID) ||
          ' AND SCP.COLL_ORD_HEAD_ID = ' || TO_CHAR(P_COLL_ORD_HEAD_ID) ||
          ' AND SCP.ENTITY_ID = ' || TO_CHAR(P_ENTITY_ID);
        BEGIN
         EXECUTE IMMEDIATE V_UPDATE_SQL;
        EXCEPTION
          WHEN OTHERS Then
            --dbms_output.put_line(V_UPDATE_SQL);
            P_RESULT := '更新周排产对应的月计划需求数量失败。' || V_NL ||
             '汇总头ID：' || TO_CHAR(P_COLL_ORD_HEAD_ID) || V_NL ||
             '汇总行ID：' || TO_CHAR(P_COLL_ORD_LINE_ID) || V_NL || SQLERRM;
            RAISE V_BASE_EXCEPTION;
        END;

        --更新周排产对应的月计划需求数量
        V_UPDATE_SQL := 'UPDATE T_PLN_SALES_CENTER_PA SCP' || CHR(10) ||
          '   SET SCP.WEEK_CAN_QTY_' || LPAD(TO_CHAR(V_INDEX), 2, '0') || ' =' || CHR(10) ||
          '       (SELECT SUM(NVL(POL.CAN_PRODUCE_QTY, 0) -' || CHR(10) ||
          '                   NVL(POL.CANCEL_INV_IN_QTY, 0))' || CHR(10) ||
          '          FROM CIMS.T_PLN_ORDER_HEAD POH,' || CHR(10) ||
          '               CIMS.T_PLN_ORDER_LINE POL,' || CHR(10) ||
          '               CIMS.T_PLN_ORDER_TYPE POT,' || CHR(10) ||
          '               CIMS.T_PLN_ORDER_PERIOD OP ' || CHR(10) ||
          '         WHERE POT.ORDER_TYPE_ID = POH.ORDER_TYPE_ID' || CHR(10) ||
          '           AND POH.ORDER_HEAD_ID = POL.ORDER_HEAD_ID' || CHR(10) ||
          '           AND POT.ENTITY_ID = POH.ENTITY_ID' || CHR(10) ||
          
          '           AND OP.PERIOD_ID = POH.PERIOD_ID ' || CHR(10) ||
          '           AND OP.ENTITY_ID = POH.ENTITY_ID ' || CHR(10) ||
          '           AND OP.PARENT_PERIOD_ID = ' || TO_CHAR(V_MONTH_PERIOD_ID) || CHR(10) ||
          '           AND POL.PRODUCING_AREA_ID = ' || TO_CHAR(R_PRODUCING_AREA.PRODUCING_AREA_ID) ||
          --·'           AND POH.FORM_STATE<>248 ' || CHR(10) || --ADD BY ZCC
         -- '           AND POH.PERIOD_ID <> SCP.PERIOD_ID ' || CHR(10) ||
          '           AND POH.FORM_STATE IN (''23'',''32'',''306'')' || CHR(10) ||  --2015-5-11 ADD BY ZCC 
          --'And ((Pkg_Bd.f_Get_Parameter_Value(''ACCOUNT_SYS'', POH.Entity_Id) = ''N'') Or' || chr(10) ||
          'And ((''' || V_ACCOUNT_SYS || ''' = ''N'') Or' || chr(10) ||
          --'       ((Pkg_Bd.f_Get_Parameter_Value(''ACCOUNT_SYS'', POH.Entity_Id) = ''Y'') And' || chr(10) ||
          '       ((''' || V_ACCOUNT_SYS || ''' = ''Y'') And' || chr(10) ||
          '    POH.Account_Id =' || chr(10) ||
          '    (Select Oh.Account_Id' || chr(10) ||
          '         From t_Pln_Order_Head Oh' || chr(10) ||
          '        Where Oh.Order_Head_Id = SCP.Order_Head_Id)))' || chr(10) ||
          --'And ((Pkg_Bd.f_Get_Parameter_Value(''ITEM_SALES_MAIN_TYPE_FILTER'', POH.Entity_Id) = ''N'') Or' || chr(10) ||
          'And ((''' || V_MAIN_TYPE_FILTER || ''' = ''N'') Or' || chr(10) ||
          --'     ((Pkg_Bd.f_Get_Parameter_Value(''ITEM_SALES_MAIN_TYPE_FILTER'', POH.Entity_Id) = ''Y'') And' || chr(10) ||
          '     ((''' || V_MAIN_TYPE_FILTER || ''' = ''Y'') And' || chr(10) ||
          '     POH.Sales_Main_Type =' || chr(10) ||
          '     (Select Oh.Sales_Main_Type' || chr(10) ||
          '          From t_Pln_Order_Head Oh' || chr(10) ||
          '         Where Oh.Order_Head_Id = SCP.Order_Head_Id)))' || chr(10) ||
          '           AND POH.SALES_CENTER_CODE = SCP.SALES_CENTER_CODE' || CHR(10) ||
          '           AND POH.ENTITY_ID = SCP.ENTITY_ID' || CHR(10) ||
          '           AND POL.ITEM_CODE = SCP.ITEM_CODE' || CHR(10) ||
          '           AND POH.ORDER_TYPE_ID = SCP.ORDER_TYPE_ID' || CHR(10) ||
          ')' || CHR(10) ||
          ' WHERE SCP.TYPE_FLAG IS NULL AND SCP.COLL_ORD_LINE_ID = ' || TO_CHAR(P_COLL_ORD_LINE_ID) ||
          ' AND SCP.COLL_ORD_HEAD_ID = ' || TO_CHAR(P_COLL_ORD_HEAD_ID) ||
          ' AND SCP.ENTITY_ID = ' || TO_CHAR(P_ENTITY_ID);
        BEGIN
         EXECUTE IMMEDIATE V_UPDATE_SQL;
        EXCEPTION
          WHEN OTHERS Then
            dbms_output.put_line(V_UPDATE_SQL);
            P_RESULT := '更新周排产对应的月计划需求数量失败。' || V_NL ||
             '汇总头ID：' || TO_CHAR(P_COLL_ORD_HEAD_ID) || V_NL ||
             '汇总行ID：' || TO_CHAR(P_COLL_ORD_LINE_ID) || V_NL ||
             '月周期ID：' || TO_CHAR(V_MONTH_PERIOD_ID) || V_NL || SQLERRM;
            RAISE V_BASE_EXCEPTION;
        END;
      End If;

      --更新周排产对应的月计划需求数量
      V_UPDATE_SQL := 'UPDATE T_PLN_SALES_CENTER_PA SCP' || CHR(10) ||
        '   SET SCP.PRDC_ID_' || LPAD(TO_CHAR(V_INDEX), 2, '0') || ' = ' ||
        TO_CHAR(R_PRODUCING_AREA.PRODUCING_AREA_ID) ||
        ' WHERE SCP.TYPE_FLAG IS NULL AND SCP.COLL_ORD_LINE_ID = ' || TO_CHAR(P_COLL_ORD_LINE_ID) ||
        ' AND SCP.COLL_ORD_HEAD_ID = ' || TO_CHAR(P_COLL_ORD_HEAD_ID) ||
        ' AND SCP.ENTITY_ID = ' || TO_CHAR(P_ENTITY_ID);
      --dbms_output.put_line(V_UPDATE_SQL);
      BEGIN
       EXECUTE IMMEDIATE V_UPDATE_SQL;
      EXCEPTION
        WHEN OTHERS Then
          --dbms_output.put_line(V_UPDATE_SQL);
          P_RESULT := '更新周排产对应的月计划需求数量失败。' || V_NL ||
           '汇总头ID：' || TO_CHAR(P_COLL_ORD_HEAD_ID) || V_NL ||
           '汇总行ID：' || TO_CHAR(P_COLL_ORD_LINE_ID) || V_NL || SQLERRM;
          RAISE V_BASE_EXCEPTION;
      END;
      V_INDEX := V_INDEX + 1;
    END LOOP;
  EXCEPTION
    WHEN V_BASE_EXCEPTION THEN
      ROLLBACK;
      P_RESULT := '创建产品分解订单行信息失败！' || V_NL || P_RESULT;
    WHEN OTHERS THEN
      P_RESULT := '订单行转换销司产地信息失败。' || V_NL ||
        P_RESULT || '失败信息：' || SQLERRM;
      ROLLBACK;
  END;
  
  ----------------------------------------------------------------------
  -- Author  : Lizhen
  -- Created : 2017-06-27 20:12:00
  -- Purpose : 根据汇总头ID、中心ID生成中心产品分解明细数据
  ----------------------------------------------------------------------
  PROCEDURE P_CREATE_CENTER_ITEM_ALLOT(IN_COLL_ORD_HEAD_ID    IN NUMBER, --汇总头ID
                                       IN_SALES_CENTER_ID     IN NUMBER, --汇总行ID
                                       IN_PRODUCING_AREA_LIST IN VARCHAR2, --产地列表
                                       IN_ENTITY_ID           IN NUMBER, --主体ID
                                       IN_USER_CODE           IN VARCHAR2, --创建人
                                       OUT_RESULT             OUT VARCHAR2,
                                       OUT_ROWCOUNT           OUT NUMBER    --返回处理成功行数
                                       ) Is
    V_ROWCOUNT  NUMBER := 0;                                    
  Begin
    OUT_RESULT := V_SUCCESS;
    FOR R_LIST IN (SELECT POH.SALES_CENTER_ID,
                          POH.SALES_CENTER_CODE,
                          POH.SALES_CENTER_NAME,
                          OCH.COLL_ORD_HEAD_ID,
                          OCL.COLL_ORD_LINE_ID
                     FROM T_PLN_ORDER_HEAD             POH,
                          T_PLN_ORDER_LINE             POL,
                          T_PLN_ORDER_COLLECT_RELATION OCR,
                          T_PLN_ORDER_COLLECT_HEAD     OCH,
                          T_PLN_ORDER_COLLECT_LINE     OCL
                    WHERE OCH.COLL_ORD_HEAD_ID = IN_COLL_ORD_HEAD_ID
                      AND POH.SALES_CENTER_ID = IN_SALES_CENTER_ID
                      AND OCL.COLL_ORD_HEAD_ID = OCH.COLL_ORD_HEAD_ID
                      AND OCL.COLL_ORD_LINE_ID = OCR.COLL_ORD_LINE_ID
                      AND OCR.ORDER_LINE_ID = POL.ORDER_LINE_ID
                      AND POH.ORDER_HEAD_ID = POL.ORDER_HEAD_ID
                      AND POH.ENTITY_ID = IN_ENTITY_ID) LOOP
      P_CREATE_ITEM_ALLOT(P_COLL_ORD_HEAD_ID    => IN_COLL_ORD_HEAD_ID,
                          P_COLL_ORD_LINE_ID    => R_LIST.COLL_ORD_LINE_ID,
                          P_PRODUCING_AREA_LIST => IN_PRODUCING_AREA_LIST,
                          P_ENTITY_ID           => IN_ENTITY_ID,
                          P_USER_CODE           => IN_USER_CODE,
                          P_RESULT              => OUT_RESULT);
      IF OUT_RESULT != V_SUCCESS THEN
        RAISE V_BASE_EXCEPTION;
      Else
        V_ROWCOUNT := V_ROWCOUNT + 1;
      END IF;                    
    END LOOP;
    OUT_ROWCOUNT := V_ROWCOUNT;
  EXCEPTION
    WHEN V_BASE_EXCEPTION THEN
      ROLLBACK;
      OUT_RESULT := '按中心调整产地评审失败！' || V_NL || OUT_RESULT;
      OUT_ROWCOUNT := V_ROWCOUNT;
    WHEN OTHERS THEN
      OUT_RESULT := '按中心调整产地评审失败。' || V_NL || OUT_RESULT || '失败信息：' || SQLERRM;
      OUT_ROWCOUNT := V_ROWCOUNT;
      ROLLBACK;
  END;
  
  ----------------------------------------------------------------------
  -- Author  : Lizhen
  -- Created : 2014-11-18 16:12:00
  -- Purpose : 根据汇总订单行，更新订单行已评审数量，行无产地对应数据时生成新的订单行
  ----------------------------------------------------------------------
  Procedure P_UPD_ITEM_ALLOT(P_COLL_ORD_HEAD_ID     IN NUMBER,  --汇总头ID
                             P_COLL_ORD_LINE_ID     IN NUMBER,   --汇总行ID
                             P_ENTITY_ID            IN NUMBER,   --主体ID
                             P_USER_CODE            IN VARCHAR2, --创建人
                             P_RESULT               OUT VARCHAR2) Is

    R_COLL_ORD_HEAD    T_PLN_ORDER_COLLECT_HEAD%Rowtype;
    v_Sum_Apply_Qty_Line   Number;
    v_Sum_Apply_Qty_Pa     Number;
    v_Fmt_Sql              Varchar2(4000);
    v_Review_Qty_Field     Varchar2(4000);
    v_Check_Sql            Varchar2(4000);
    v_Count                Number;
    v_Producing_Area_Id    Number;
    v_Producing_Area_Code  Varchar2(100);
    v_Producing_Area_Name  Varchar2(100);
    v_Check_Qty            Number;
    v_Review_Qty           Number;
    V_ORDER_LINE_ID        Number;
    v_item_id              Number;
    v_item_Uom             Varchar2(100);
    v_Order_Collect_Show_Id Number;
    r_Order_Type            t_Pln_Order_Type%Rowtype;
    v_Month_Can_Qty         Number;
    v_Week_Can_Qty          Number;
    v_inv_check_qty         number;
    VS_ITEM_LIFE_CYCLE      VARCHAR2(2);
    V_COUNT_CYC             NUMBER;
    V_TEMP_LAST_UPDATED_BY  VARCHAR2(32);
    V_ADJUST_LG_MODE        VARCHAR2(100); --提货订单调整模式
  Begin
    P_RESULT := V_SUCCESS;
    BEGIN
      SELECT *
        INTO R_COLL_ORD_HEAD
        FROM T_PLN_ORDER_COLLECT_HEAD CH
       WHERE CH.COLL_ORD_HEAD_ID = P_COLL_ORD_HEAD_ID;
    EXCEPTION
      WHEN OTHERS THEN
        P_RESULT := '查询汇总订单头失败。' || V_NL || '汇总头ID：' ||
                    TO_CHAR(P_COLL_ORD_HEAD_ID) || V_NL || SQLERRM;
        RAISE V_BASE_EXCEPTION;
    END;
    BEGIN
      SELECT *
        INTO r_Order_Type
        FROM t_Pln_Order_Type Ot
       WHERE Ot.Order_Type_Id = R_COLL_ORD_HEAD.Order_Type_Id;
    EXCEPTION
      WHEN OTHERS THEN
        P_RESULT := '获取单据类型失败。' || V_NL || '单据类型ID：' ||
                    TO_CHAR(R_COLL_ORD_HEAD.Order_Type_Id) || V_NL || SQLERRM;
        RAISE V_BASE_EXCEPTION;
    END;
    --2015-09-15 add by exzhangcc
    BEGIN
      VS_ITEM_LIFE_CYCLE := PKG_BD.F_GET_PARAMETER_VALUE('PLN_ITEM_LIFE_CYCLE', P_ENTITY_ID);
    EXCEPTION
      WHEN OTHERS THEN
        P_RESULT := '获取PLN_ITEM_LIFE_CYCLE参数失败' || V_NL || SQLERRM;
        RAISE V_BASE_EXCEPTION;
    END;
    
    --2016-06-23 add by hejy3
    BEGIN
      V_ADJUST_LG_MODE := PKG_BD.F_GET_PARAMETER_VALUE('PLN_LG_PLNNOCHK_CANCEL', P_ENTITY_ID);
    EXCEPTION
      WHEN OTHERS THEN
        P_RESULT := '获取PLN_LG_PLNNOCHK_CANCEL参数失败' || V_NL || SQLERRM;
        RAISE V_BASE_EXCEPTION;
    END;
    
    SELECT TO_CHAR(SYSDATE, 'YYYYMMDDHH24MISS') INTO V_TEMP_LAST_UPDATED_BY FROM DUAL;
    For r_Sc_Pa In (Select sc.*
                      From t_Pln_Sales_Center_Pa Sc
                     Where Sc.Entity_Id = p_Entity_Id
                       And Sc.Coll_Ord_Head_Id = p_Coll_Ord_Head_Id
                       And Sc.Coll_Ord_Line_Id = p_Coll_Ord_Line_Id
                       And sc.type_flag Is Null) LOOP
      
      IF V_ADJUST_LG_MODE = 'CANCEL_ORDER' THEN
        --2015-11-27 何加源 先按计划评审调整数量和计划评审产地更新提货订单行的计划评审数量和产地
        UPDATE T_PLN_LG_RELATION R
           SET R.ORDER_LINE_ID = (-1) * R.ORDER_LINE_ID,
               R.ORDER_HEAD_ID = (-1) * R.ORDER_HEAD_ID,
               R.LAST_UPDATED_BY = V_TEMP_LAST_UPDATED_BY
         WHERE R.ENTITY_ID = P_ENTITY_ID
           AND EXISTS (SELECT 1 FROM T_PLN_ORDER_LINE L
                        WHERE L.ORDER_LINE_ID = R.ORDER_LINE_ID
                          AND L.ORDER_HEAD_ID = r_Sc_Pa.Order_Head_Id
                          AND L.ITEM_CODE = r_Sc_Pa.Item_Code);
        
        UPDATE T_PLN_LG_ORDER_LINE L
           SET (L.PRODUCING_AREA_ID,
                L.PRODUCING_AREA_CODE,
                L.PRODUCING_AREA_NAME) =
               (SELECT A.PRODUCING_AREA_ID,
                       A.PRODUCING_AREA_CODE,
                       A.PRODUCING_AREA_NAME
                  FROM T_PLN_PRODUCING_AREA A
                 WHERE A.ENTITY_ID = L.ENTITY_ID
                   AND A.PRODUCING_AREA_NAME = L.PLN_CHK_PRO_AREA
                   AND SYSDATE BETWEEN A.BEGIN_DATE AND NVL(A.END_DATE, SYSDATE + 1)),
               L.PLN_CHK_QTY = NVL(L.PLN_CHK_ADJUST_QTY, 0) + TO_NUMBER(NVL(L.PRE_FIELD_05,'0'))
         WHERE L.ENTITY_ID = P_ENTITY_ID
           AND EXISTS(SELECT 1 FROM T_PLN_LG_RELATION R, T_PLN_ORDER_LINE OL
                        WHERE R.LG_ORDER_LINE_ID = L.ORDER_LINE_ID
                          AND R.ORDER_LINE_ID = (-1)*OL.ORDER_LINE_ID
                          AND OL.ORDER_HEAD_ID = r_Sc_Pa.Order_Head_Id
                          AND OL.ITEM_CODE = r_Sc_Pa.Item_Code);
      END IF;
      
      --检查各产地的评审数量是否，超了申请数量。
      Select Sum(Nvl(Pol.Center_Check_Qty, Nvl(Pol.Apply_Qty, 0))),sum(nvl(pol.inv_affirm_qty,0))
        Into v_Sum_Apply_Qty_Line ,v_inv_check_qty
        From t_Pln_Order_Head             Poh,
             t_Pln_Order_Line             Pol,
             t_Pln_Order_Collect_Relation Ocr,
             t_Pln_Order_Collect_Head     Och,
             t_Pln_Order_Collect_Line     Ocl
       Where Och.Coll_Ord_Head_Id = r_Sc_Pa.Coll_Ord_Head_Id
         And Ocl.Coll_Ord_Line_Id = r_Sc_Pa.Coll_Ord_Line_Id
         And Och.Entity_Id = r_Sc_Pa.Entity_Id
         And Pol.Item_Code = r_Sc_Pa.Item_Code
         --add by fenggq 20150330 解决同一销司不同客户报送订单
         And Poh.Order_Head_Id = r_Sc_Pa.Order_Head_Id
         --end by fenggq 20150330
         And Poh.Order_Type_Id = r_Sc_Pa.Order_Type_Id
         And Poh.Period_Id = r_Sc_Pa.Period_Id
         And Poh.Sales_Center_Code = r_Sc_Pa.Sales_Center_Code
         And Ocl.Coll_Ord_Head_Id = Och.Coll_Ord_Head_Id
         And Ocl.Coll_Ord_Line_Id = Ocr.Coll_Ord_Line_Id
         And Ocr.Order_Line_Id = Pol.Order_Line_Id
         And Poh.Order_Head_Id = Pol.Order_Head_Id
       Group By Poh.Entity_Id,
                Och.Coll_Ord_Head_Id,
                Ocl.Coll_Ord_Line_Id,
                Poh.Order_Head_Id,
                Poh.Order_Type_Id,
                Poh.Period_Id,
                Pol.Item_Code,
                Poh.Sales_Center_Code;
      v_Fmt_Sql := Null;
      v_Review_Qty_Field := Null;
      v_Month_Can_Qty := Null;
      v_Week_Can_Qty := Null;
      v_Check_Sql := Null;
      v_Producing_Area_Name := Null;
      --检查订单行评审数量
      For i In 1..30 Loop
        v_Producing_Area_Name := Null;
        If v_Review_Qty_Field Is Null Then
          v_Review_Qty_Field := ' Nvl(scp.review_qty_' || Lpad(i, 2, '0') || ', 0)' || Chr(10);
        Else
          v_Review_Qty_Field := v_Review_Qty_Field || ' + Nvl(scp.review_qty_' || Lpad(i, 2, '0') || ', 0)' || Chr(10);
        End If;
        v_Check_Sql := ' Select Scp.Check_Qty_' || Lpad(i, 2, '0') || ',' || Chr(10) ||
               'Scp.Review_Qty_' || Lpad(i, 2, '0') || ',' || Chr(10) ||
               'Scp.Month_Can_Qty_' || Lpad(i, 2, '0') || ',' || Chr(10) ||
               'Scp.Week_Can_Qty_' || Lpad(i, 2, '0') || ',' || Chr(10) ||
               'Scp.Prdc_Id_' || Lpad(i, 2, '0') || ',' || Chr(10) ||
               'Ppa.Producing_Area_Name ' || Chr(10) ||
          ' From t_Pln_Sales_Center_Pa Scp, t_Pln_Producing_Area Ppa ' || Chr(10) ||
          ' Where Scp.Prdc_Id_' || Lpad(i, 2, '0') || ' = Ppa.Producing_Area_Id(+) ' || Chr(10) ||
          ' And Scp.Entity_Id = Ppa.Entity_Id(+) ' || Chr(10) ||
          ' and Scp.Sales_Center_Pa_Id = :01' || Chr(10) ||
          ' and Scp.Entity_Id = :02 ';
        --dbms_output.put_line(v_Check_Sql);
        Begin
          Execute Immediate v_Check_Sql
            Into v_Check_Qty, v_Review_Qty,v_Month_Can_Qty, v_Week_Can_Qty, v_Producing_Area_Id, v_Producing_Area_Name
            Using r_Sc_Pa.Sales_Center_Pa_Id, r_Sc_Pa.Entity_Id;
        Exception
          When Others Then
            p_Result := '查询产品分解订单信息失败，产品分解确认失败！' || v_Nl || '订单单号：' ||
                        r_Sc_Pa.Order_Number || v_Nl || '中心名称：' ||
                        r_Sc_Pa.Sales_Center_Name || v_Nl || Sqlerrm;
            Raise v_Base_Exception;
        End;
        Exit When v_Producing_Area_Id Is Null;
        If Nvl(v_Month_Can_Qty, 0) < Nvl(v_Review_Qty, 0) + Nvl(v_Week_Can_Qty, 0)
          And Nvl(r_Order_Type.Is_Week, 'N') = 'Y' Then
          P_RESULT := '周排产订单评审数量汇总大于月计划产地已排产数量！' || v_NL ||
                   '评审数量：' || To_Char(v_Review_Qty) || v_Nl ||
                   '周已排产数量：' || To_Char(v_Week_Can_Qty) || v_NL ||
                   '月已排产数量：' || To_Char(v_Month_Can_Qty) || v_NL ||
                   '产地名称：' || v_Producing_Area_Name || v_Nl ||
                   '订单单号：' || r_Sc_Pa.Order_Number || v_Nl ||
                   '中心名称：' || r_Sc_Pa.Sales_Center_Name;
          Raise V_BASE_EXCEPTION;
        End If;
      
        Begin
          Select i.Item_Id, i.Defaultunit
            Into v_Item_Id, v_Item_Uom
            From t_Bd_Item i
           Where i.Item_Code = r_Sc_Pa.Item_Code
             And i.Entity_Id = p_Entity_Id;
        Exception
          When Others Then
            p_Result := '获取产品信息失败！' || v_Nl || '产品编码：' ||
                        r_Sc_Pa.Item_Code || v_Nl || Sqlerrm;
            Raise v_Base_Exception;
        End;

        --更新订单行已排产数量
        Update t_Pln_Order_Line Ol
           Set Ol.Check_Qty        = nvl(v_Review_Qty,0),
               Ol.Can_Produce_Qty  = nvl(v_Review_Qty,0),
               Ol.Version          = Ol.Version + 1,
               Ol.Last_Updated_By  = p_User_Code,
               Ol.Last_Update_Date = Sysdate
         Where Ol.Order_Head_Id = r_Sc_Pa.Order_Head_Id
           And Ol.Producing_Area_Id = v_Producing_Area_Id
           And Ol.Item_Code = r_Sc_Pa.Item_Code
           And Ol.Entity_Id = p_Entity_Id;
        If Sql%Notfound Then
          Select Count(Pa.Producing_Area_Id)
            Into v_Count
            From t_Pln_Item_Producing_Area Pa
           Where Pa.Item_Code = r_Sc_Pa.Item_Code
             And Pa.Entity_Id = p_Entity_Id
             And Pa.Producing_Area_Id = v_Producing_Area_Id
             AND trunc(SYSDATE) BETWEEN pa.begin_date AND trunc(nvl(pa.end_date, SYSDATE+1));
          If v_Count > 0 And Nvl(v_Review_Qty, 0) > 0 Then
            Begin
              Select Pa.Producing_Area_Code, Pa.Producing_Area_Name
                Into v_Producing_Area_Code, v_Producing_Area_Name
                From t_Pln_Producing_Area Pa
               Where Pa.Producing_Area_Id = v_Producing_Area_Id
                 And Pa.Entity_Id = p_Entity_Id;
            Exception
              When Others Then
                p_Result := '获取产地信息失败。' || v_Nl || '产地ID：' ||
                            v_Producing_Area_Id || v_Nl || Sqlerrm;
                Raise v_Base_Exception;
            End;
                     -- add by exzhangcc 2015-09-15 检验产品生命周期
            If VS_ITEM_LIFE_CYCLE ='Y' Then 
              --modi by lizhen 2017-06-27检查生命周期使用公用函数
              If 'Y' != PKG_PLN_PUB.p_Chk_Item_Prdc_Life_Cycle(p_Entity_Id         => P_ENTITY_ID,
                                                               p_Item_Id           => v_Item_Id,
                                                               p_Producing_Area_Id => v_Producing_Area_Id,
                                                               p_Order_Phase       => PKG_PLN_PUB.v_Phase_Intf_Aps) Then
                P_RESULT :='产品在生命周期内无法引入APS，产品分解失败!' || V_NL ||
                            '产品编码: ' || r_sc_pa.item_code || V_NL||
                            '产地名称: ' || v_Producing_Area_Name;
                RAISE V_BASE_EXCEPTION;
              End If;
              /*
              BEGIN
                SELECT COUNT(0) INTO V_COUNT_CYC FROM
                T_PLN_ITEM_LIFE_CYCLE CY,
                T_PLN_ITEM_PRODUCING_AREA PA
                WHERE CY.ENTITY_ID=PA.ENTITY_ID
                AND CY.ENTITY_ID=P_ENTITY_ID
                AND PA.STATE=CY.SYSTEM_STATUS
                AND NVL(CY.IS_APS_FLAG,'N')='Y'
                AND PA.ITEM_ID=v_Item_Id
                AND PA.PRODUCING_AREA_ID=v_Producing_Area_Id
                AND (TRUNC(SYSDATE) BETWEEN PA.BEGIN_DATE AND nvl(PA.END_DATE,trunc(sysdate)));
                EXCEPTION
                WHEN OTHERS THEN
                  P_RESULT :='获取产品产地生命周期失败!' || v_nl || sqlerrm;
                  raise V_BASE_EXCEPTION;
              END; 
              IF NVL(V_COUNT_CYC,0)=0 THEN 
                   P_RESULT :='产品在生命周期内无法引入APS!' || V_NL ||
                              '产品编码: ' || r_sc_pa.item_code || V_NL||
                              '产地名称: ' || v_Producing_Area_Name;
                   RAISE V_BASE_EXCEPTION;
                END IF;
                */
              V_COUNT_CYC :=0; 
            End If;
            Begin
              Select s_Pln_Order_Line.Nextval
                Into v_Order_Line_Id
                From Dual;
              Insert Into t_Pln_Order_Line
                (Entity_Id,
                 Order_Line_Id,
                 Order_Head_Id,
                 Producing_Area_Id,
                 Producing_Area_Code,
                 Producing_Area_Name,
                 Item_Id,
                 Item_Code,
                 Item_Desc,
                 Item_Uom,
                 Item_Price,
                 Apply_Qty,
                 Check_Qty,
                 Can_Produce_Qty, --?
                 Amount,
                 Discount_Rate,
                 Status,
                 Can_Supply_Date,
                 Begin_Supply_Date,
                 End_Supply_Date,
                 Adjust_Qty, --?
                 Created_By,
                 Creation_Date,
                 Last_Updated_By,
                 Last_Update_Date,
                 aps_flag)
                Select p_Entity_Id,
                       V_ORDER_LINE_ID,
                       r_sc_pa.order_head_id,
                       v_Producing_Area_Id,
                       v_Producing_Area_Code,
                       v_Producing_Area_Name,
                       v_Item_Id,
                       r_sc_pa.Item_Code,
                       r_sc_pa.item_name,
                       v_item_Uom,
                       b.Item_Price,
                       0,
                       nvl(v_Review_Qty,0),
                       nvl(v_Review_Qty,0),
                       b.Item_Price * nvl(v_Review_Qty,0)*
                       (100 - Nvl(b.Discount_Rate, 0)) / 100,
                       b.Discount_Rate,
                       b.Status,
                       b.Can_Supply_Date,
                       b.Begin_Supply_Date,
                       b.End_Supply_Date,
                       b.Adjust_Qty,
                       P_USER_CODE,
                       Sysdate,
                       P_USER_CODE,
                       Sysdate,
                       'N'
                  From t_Pln_Order_Head a, t_Pln_Order_Line b
                 Where a.order_head_id = r_sc_pa.order_head_id
                   And a.Sales_Center_Code = r_sc_pa.sales_center_code
                   And a.Entity_Id = p_Entity_Id
                   And b.item_code = r_sc_pa.item_code
                   And b.Order_Head_Id = a.Order_Head_Id
                   And rownum <= 1;
            Exception
              When Others Then
                p_Result := '插入订单行表失败。' || v_Nl || Sqlerrm;
                Raise V_BASE_EXCEPTION;
            End;
            Begin
              Insert Into t_Pln_Order_Collect_Relation
                (Entity_Id,
                 Relation_Id,
                 Order_Line_Id,
                 Coll_Ord_Line_Id,
                 Order_Collect_Head_Id,
                 Created_By,
                 Creation_Date,
                 Last_Updated_By,
                 Last_Update_Date)
              Values
                (p_Entity_Id,
                 s_Pln_Order_Collect_Relation.Nextval,
                 v_Order_Line_Id,
                 p_Coll_Ord_Line_Id,
                 p_Coll_Ord_Head_Id,
                 p_User_Code,
                 Sysdate,
                 p_User_Code,
                 Sysdate);
            Exception
              When Others Then
                p_Result := '插入汇总行与订单行关系表失败!' || v_Nl || Sqlerrm;
                Raise v_Base_Exception;
            End;
          Elsif v_Count <= 0 And Nvl(v_Review_Qty, 0) > 0 Then
            P_RESULT := '检查产品产地数据失败！' || v_Nl ||
              '产品编码：' || r_Sc_Pa.Item_Code || v_Nl ||
              '产地名称：' || v_Producing_Area_Name;
            Raise V_BASE_EXCEPTION;
          End If;
        End If;
        
        IF V_ADJUST_LG_MODE = 'CANCEL_ORDER' THEN
          --2015-11-27 新增计划订单行与提货订单行关系
          INSERT INTO T_PLN_LG_RELATION
            (ENTITY_ID,
             RELATION_ID,
             LG_ORDER_LINE_ID,
             ORDER_LINE_ID,
             CREATION_DATE,
             CREATED_BY,
             LAST_UPDATE_DATE,
             LAST_UPDATED_BY,
             LG_ORDER_HEAD_ID,
             ORDER_HEAD_ID)
            SELECT L.ENTITY_ID,
                   SEQ_PLN_LG_RELATION.NEXTVAL,
                   L.ORDER_LINE_ID,
                   OL.ORDER_LINE_ID,
                   SYSDATE,
                   P_USER_CODE,
                   SYSDATE,
                   P_USER_CODE,
                   L.ORDER_HEAD_ID,
                   OL.ORDER_HEAD_ID
              FROM T_PLN_LG_ORDER_LINE L,
                   T_PLN_ORDER_LINE OL
             WHERE OL.ORDER_HEAD_ID = r_Sc_Pa.Order_Head_Id
               AND OL.ITEM_CODE = r_Sc_Pa.Item_Code
               AND L.PRODUCING_AREA_ID = OL.PRODUCING_AREA_ID
               AND OL.PRODUCING_AREA_ID = v_Producing_Area_Id
               AND EXISTS (SELECT 1 FROM T_PLN_LG_RELATION R
                            WHERE R.LG_ORDER_LINE_ID = L.ORDER_LINE_ID
                              AND R.ORDER_LINE_ID < 0
                              AND R.LAST_UPDATED_BY = V_TEMP_LAST_UPDATED_BY);
          
          --原关系中若计划订单行有库存评审的需重建关系  
          INSERT INTO T_PLN_LG_RELATION
            (ENTITY_ID,
             RELATION_ID,
             LG_ORDER_LINE_ID,
             ORDER_LINE_ID,
             CREATION_DATE,
             CREATED_BY,
             LAST_UPDATE_DATE,
             LAST_UPDATED_BY,
             LG_ORDER_HEAD_ID,
             ORDER_HEAD_ID)
            SELECT L.ENTITY_ID,
                   SEQ_PLN_LG_RELATION.NEXTVAL,
                   L.ORDER_LINE_ID,
                   OL.ORDER_LINE_ID,
                   SYSDATE,
                   P_USER_CODE,
                   SYSDATE,
                   P_USER_CODE,
                   L.ORDER_HEAD_ID,
                   OL.ORDER_HEAD_ID
              FROM T_PLN_LG_ORDER_LINE L,
                   T_PLN_ORDER_LINE OL
             WHERE OL.ORDER_HEAD_ID = r_Sc_Pa.Order_Head_Id
               AND OL.ITEM_CODE = r_Sc_Pa.Item_Code
               --AND L.PRODUCING_AREA_ID = OL.PRODUCING_AREA_ID
               AND OL.PRODUCING_AREA_ID = v_Producing_Area_Id
               AND OL.INV_AFFIRM_QTY > 0
               AND EXISTS (SELECT 1 FROM T_PLN_LG_RELATION R
                            WHERE R.LG_ORDER_LINE_ID = L.ORDER_LINE_ID
                              AND R.ORDER_LINE_ID = (-1) * OL.ORDER_LINE_ID
                              AND R.LAST_UPDATED_BY = V_TEMP_LAST_UPDATED_BY)
               AND NOT EXISTS (SELECT 1 FROM t_Pln_Lg_Relation lr
                                WHERE lr.lg_order_line_id = l.order_line_id
                                  AND lr.order_line_id = ol.order_line_id);
        END IF;
        
        Begin
          Select Cs.Order_Collect_Show_Id
            Into v_Order_Collect_Show_Id
            From t_Pln_Order_Collect_Show Cs
           Where Cs.Order_Collect_Head_Id = p_Coll_Ord_Head_Id
             And Cs.Order_Collect_Line_Id = p_Coll_Ord_Line_Id
             And Cs.Item_Id = v_Item_Id;
        Exception
          When Others Then
            p_Result := '获取汇总单显示行ID失败!' || v_Nl || '汇总单头ID：' ||
                        To_Char(p_Coll_Ord_Head_Id);
            Raise v_Base_Exception;
        End;
        Pkg_Pln_Order_Collect.p_Up_Inv_Collect_Show(p_Order_Collect_Head_Id => p_Coll_Ord_Head_Id,
                                                    p_Order_Collect_Show_Id => v_Order_Collect_Show_Id,
                                                    p_Item_Id               => v_Item_Id,
                                                    p_Entity_Id             => p_Entity_Id,
                                                    p_User_Code             => p_User_Code,
                                                    p_Result                => p_Result);
        If p_Result != v_Success Then
          Raise v_Base_Exception;
        End If;
      End Loop;
      
      IF V_ADJUST_LG_MODE = 'CANCEL_ORDER' THEN
        --2015-11-27 何加源 删除本次处理的订单行关联关系（订单行ID<0的数据）
        DELETE FROM T_PLN_LG_RELATION R
         WHERE R.ORDER_LINE_ID < 0
           AND R.LAST_UPDATED_BY = V_TEMP_LAST_UPDATED_BY;
      END IF;
      
      Begin
        v_Fmt_Sql := ' Select Sum(' || v_Review_Qty_Field || ')' || Chr(10) ||
          ' From t_Pln_Sales_Center_Pa Scp  ' || Chr(10) ||
          ' Where Scp.Sales_Center_Pa_Id = :01' || Chr(10) ||
          ' and Scp.Entity_Id = :02 ';
          Execute Immediate v_Fmt_Sql
            Into v_Sum_Apply_Qty_Pa
            Using r_Sc_Pa.Sales_Center_Pa_Id, r_Sc_Pa.Entity_Id;
        Exception
          When Others Then
            p_Result := '汇总产品分解订单行数据！' || v_Nl || '订单单号：' ||
                        r_Sc_Pa.Order_Number || v_Nl || '中心名称：' ||
                        r_Sc_Pa.Sales_Center_Name || v_Nl || Sqlerrm;
            Raise v_Base_Exception;
        End;
        If v_Sum_Apply_Qty_Line-v_inv_check_qty < v_Sum_Apply_Qty_Pa And Nvl(r_Order_Type.Is_Week, 'N') != 'Y' Then
          P_RESULT := '订单行所有产地分解数量大于产品申请数量！' || v_NL ||
                   '评审数量合计：' || To_Char(v_Sum_Apply_Qty_Pa) || v_Nl ||
                   '库存评审数量：' || To_Char(v_inv_check_qty) || v_Nl ||
                   '申请数量：' || To_Char(v_Sum_Apply_Qty_Line) || v_NL ||
                   '订单单号：' || r_Sc_Pa.Order_Number || v_Nl ||
                   '中心名称：' || r_Sc_Pa.Sales_Center_Name;
          Raise V_BASE_EXCEPTION;
        End If;
    End Loop;
  Exception
    WHEN V_BASE_EXCEPTION THEN
      ROLLBACK;
      P_RESULT := '确认产品分解失败！' || V_NL || P_RESULT;
    WHEN OTHERS THEN
      P_RESULT := '订单行转换销司产地信息失败。' || V_NL ||
        P_RESULT || '失败信息：' || SQLERRM;
      ROLLBACK;
  End;
  
  ----------------------------------------------------------------------
  -- Author  : Lizhen
  -- Created : 2017-06-27 20:12:00
  -- Purpose : 根据汇总头ID、中心编码 更新中心产品分解明细数据
  ----------------------------------------------------------------------
  PROCEDURE P_UPD_CENTER_ITEM_ALLOT(IN_COLL_ORD_HEAD_ID    IN NUMBER, --汇总头ID
                                    IN_SALES_CENTER_CODE   IN VARCHAR2, --汇总行ID
                                    IN_ENTITY_ID           IN NUMBER, --主体ID
                                    IN_USER_CODE           IN VARCHAR2, --创建人
                                    OUT_RESULT             OUT VARCHAR2
                                    ) IS
  BEGIN
    OUT_RESULT := V_SUCCESS;
    FOR R_CENTER IN (SELECT DISTINCT PSC.COLL_ORD_HEAD_ID, PSC.COLL_ORD_LINE_ID
                       FROM T_PLN_SALES_CENTER_PA PSC
                      WHERE PSC.COLL_ORD_HEAD_ID = IN_COLL_ORD_HEAD_ID
                        AND PSC.SALES_CENTER_CODE = IN_SALES_CENTER_CODE
                        AND PSC.ENTITY_ID = IN_ENTITY_ID) LOOP
      P_UPD_ITEM_ALLOT(P_COLL_ORD_HEAD_ID => IN_COLL_ORD_HEAD_ID,
                       P_COLL_ORD_LINE_ID => R_CENTER.COLL_ORD_LINE_ID,
                       P_ENTITY_ID        => IN_ENTITY_ID,
                       P_USER_CODE        => IN_USER_CODE,
                       P_RESULT           => OUT_RESULT);
      IF OUT_RESULT != V_SUCCESS THEN
        RAISE V_BASE_EXCEPTION;
      END IF;
    END LOOP;
    --更新SHOW数据
    FOR R_CENTER IN (SELECT DISTINCT PSC.COLL_ORD_HEAD_ID, PSC.COLL_ORD_LINE_ID, TBI.ITEM_ID
                       FROM T_PLN_SALES_CENTER_PA PSC,T_BD_ITEM TBI
                      WHERE PSC.COLL_ORD_HEAD_ID = IN_COLL_ORD_HEAD_ID
                        AND PSC.SALES_CENTER_CODE = IN_SALES_CENTER_CODE
                        And TBI.ITEM_CODE = PSC.ITEM_CODE
                        And TBI.ENTITY_ID = PSC.ENTITY_ID
                        AND PSC.ENTITY_ID = IN_ENTITY_ID) Loop
      PKG_PLN_ORDER_COLLECT.P_UP_INV_COLLECT_SHOW(P_ORDER_COLLECT_HEAD_ID => IN_COLL_ORD_HEAD_ID,
                                                  P_ORDER_COLLECT_SHOW_ID => R_CENTER.COLL_ORD_LINE_ID,
                                                  P_ITEM_ID               => R_CENTER.ITEM_ID,
                                                  P_ENTITY_ID             => IN_ENTITY_ID,
                                                  P_USER_CODE             => IN_USER_CODE,
                                                  P_RESULT                => OUT_RESULT);
      IF OUT_RESULT != V_SUCCESS THEN
        RAISE V_BASE_EXCEPTION;
      END IF;
    END LOOP;
  EXCEPTION
    WHEN V_BASE_EXCEPTION THEN
      ROLLBACK;
      OUT_RESULT := '按中心产品分解确认数据！' || V_NL || OUT_RESULT;
    WHEN OTHERS THEN
      OUT_RESULT := '按中心产品分解确认数据。' || V_NL ||
        OUT_RESULT || '失败信息：' || SQLERRM;
      ROLLBACK;  
  END;

  ----------------------------------------------------------------------
  -- Author  : fenggq
  -- Created : 2014-11-18 16:12:00
  -- Purpose : 订单行转换销司产地信息
  ----------------------------------------------------------------------
  PROCEDURE P_ORDER_CHANGE_SALES_CENTER_PA(P_ORDER_TYPE_ID    IN NUMBER,   --订单类型ID
                                           P_PERIOD_ID        IN NUMBER,   --订单周期ID
                                           P_BATCH_ID         IN NUMBER,   --批次ID
                                           P_ITEM_CODE        IN VARCHAR2, --产品编码
                                           P_COLL_ORD_LINE_ID IN NUMBER,   --汇总订单行ID
                                           P_ENTITY_ID        IN NUMBER,   --主体ID
                                           P_CREATED_BY       IN VARCHAR2, --创建人
                                           P_PA_LIST          IN VARCHAR2, --产地信息
                                           P_RESULT           OUT VARCHAR2) IS

    VS_SALES_CENTER_CODE  T_PLN_ORDER_HEAD.SALES_CENTER_CODE%TYPE; --营销中心编码
    VS_PRODUCING_AREA_1ST T_PLN_SALES_CENTER_PA.PRODUCING_AREA_CODE_1ST%TYPE; --第一产地
    VS_PRODUCING_AREA_2ND T_PLN_SALES_CENTER_PA.PRODUCING_AREA_CODE_2ND%TYPE; --第二产地

    VN_APPLY_COLLECT_QTY      T_PLN_SALES_CENTER_PA.APPLY_QTY%TYPE; --申请汇总数量
    VN_INV_AFFIRM_COLLECT_QTY T_PLN_SALES_CENTER_PA.INV_AFFIRM_QTY%TYPE; --库存汇总数量
    VN_CHECK_COLLECT_QTY      T_PLN_SALES_CENTER_PA.CHECK_QTY%TYPE; --评审汇总数量
    VS_ORDER_NUMBER           T_PLN_SALES_CENTER_PA.PRE_FIELD_01%TYPE; --订单号

    VS_PRODUCING_AREA1 VARCHAR2(10);
    VS_PRODUCING_AREA2 VARCHAR2(10);
    VS_PRODUCING_AREA3 VARCHAR2(10);
    VS_PRODUCING_AREA4 VARCHAR2(10);
    VS_PRODUCING_AREA5 VARCHAR2(10);
    VS_PRODUCING_AREA6 VARCHAR2(10);
    VS_PRODUCING_AREA7 VARCHAR2(10);

    VS_NAME            VARCHAR2(20);
    UPDATESQL          VARCHAR2(2000);

  BEGIN
    P_RESULT := V_SUCCESS;

    VS_PRODUCING_AREA1 := 'A0001';
    VS_PRODUCING_AREA2 := 'A0002';
    VS_PRODUCING_AREA3 := 'A0003';
    VS_PRODUCING_AREA4 := 'A0004';
    VS_PRODUCING_AREA5 := 'A0005';
    VS_PRODUCING_AREA6 := 'A0006';
    VS_PRODUCING_AREA7 := 'A0007';

    --删除未评审的临时数据
    DELETE FROM T_PLN_SALES_CENTER_PA
     WHERE ORDER_TYPE_ID = P_ORDER_TYPE_ID
       AND PERIOD_ID = P_PERIOD_ID
       AND ITEM_CODE = P_ITEM_CODE
       AND ENTITY_ID = P_ENTITY_ID
       AND TYPE_FLAG IS NULL;

    FOR C_PLN_SALES_CENTER IN (SELECT A.SALES_CENTER_CODE
                                 FROM T_PLN_ORDER_HEAD A, T_PLN_ORDER_LINE B
                                WHERE A.ORDER_TYPE_ID = P_ORDER_TYPE_ID
                                  AND A.PERIOD_ID = P_PERIOD_ID
                                  AND A.FORM_STATE = 25
                                  AND A.BATCH_ID = P_BATCH_ID
                                  AND A.ENTITY_ID = P_ENTITY_ID
                                  AND B.ORDER_HEAD_ID = A.ORDER_HEAD_ID
                                  AND B.ITEM_CODE = P_ITEM_CODE) LOOP
      BEGIN
        VS_SALES_CENTER_CODE := '-1';
        SELECT SALES_CENTER_CODE
          INTO VS_SALES_CENTER_CODE
          FROM T_PLN_SALES_CENTER_PA
         WHERE ORDER_TYPE_ID = P_ORDER_TYPE_ID
           AND PERIOD_ID = P_PERIOD_ID
           AND ITEM_CODE = P_ITEM_CODE
           AND SALES_CENTER_CODE = C_PLN_SALES_CENTER.SALES_CENTER_CODE
           AND ENTITY_ID = P_ENTITY_ID
           AND TYPE_FLAG IS NULL;
      EXCEPTION
        WHEN OTHERS THEN
        NULL;
      END;
      --判断营销中心是否存在
      IF VS_SALES_CENTER_CODE = '-1' THEN

        --取第一产地，产品在中心优先级表中没有配置
        FOR C_PRODUCING_AREA_PRIORITY IN (SELECT PRODUCING_AREA_PRIORITY
                                            FROM T_PLN_CUSTOMER_PRIORITY
                                           WHERE SALES_CENTER_CODE = C_PLN_SALES_CENTER.SALES_CENTER_CODE
                                             AND ITEM_CODE IS NULL
                                             AND ENTITY_ID = P_ENTITY_ID
                                           ORDER BY PRODUCING_AREA_PRIORITY) LOOP
          BEGIN
            VS_PRODUCING_AREA_1ST := '-1';
            SELECT A.PRODUCING_AREA_CODE
              INTO VS_PRODUCING_AREA_1ST
              FROM T_PLN_CUSTOMER_PRIORITY A--, T_PLN_ITEM_PRODUCING_AREA B
             WHERE A.SALES_CENTER_CODE = C_PLN_SALES_CENTER.SALES_CENTER_CODE
               AND A.ITEM_CODE IS NULL
               AND A.PRODUCING_AREA_PRIORITY = C_PRODUCING_AREA_PRIORITY.PRODUCING_AREA_PRIORITY
               AND A.ENTITY_ID = P_ENTITY_ID;
               --AND B.ITEM_CODE = P_ITEM_CODE --判断产品在VS_PRODUCING_AREA_1ST产地是否生产
               --AND B.PRODUCING_AREA_CODE = A.PRODUCING_AREA_CODE;
          EXCEPTION
            WHEN OTHERS THEN
            NULL;
          END;

          IF VS_PRODUCING_AREA_1ST <> '-1' THEN
            EXIT;
          END IF;
        END LOOP;

        --取第二产地，产品在中心优先级表中没有配置
        FOR C_PRODUCING_AREA_PRIORITY2 IN (SELECT PRODUCING_AREA_PRIORITY
                                             FROM T_PLN_CUSTOMER_PRIORITY
                                            WHERE SALES_CENTER_CODE = C_PLN_SALES_CENTER.SALES_CENTER_CODE
                                              AND ITEM_CODE IS NULL
                                              AND PRODUCING_AREA_CODE <> VS_PRODUCING_AREA_1ST
                                              AND ENTITY_ID = P_ENTITY_ID
                                            ORDER BY PRODUCING_AREA_PRIORITY) LOOP
          BEGIN
            VS_PRODUCING_AREA_2ND := '-1';
            SELECT A.PRODUCING_AREA_CODE
              INTO VS_PRODUCING_AREA_2ND
              FROM T_PLN_CUSTOMER_PRIORITY A--, T_PLN_ITEM_PRODUCING_AREA B
             WHERE A.SALES_CENTER_CODE = C_PLN_SALES_CENTER.SALES_CENTER_CODE
               AND A.ITEM_CODE IS NULL
             AND A.PRODUCING_AREA_CODE <> VS_PRODUCING_AREA_1ST
               AND A.PRODUCING_AREA_PRIORITY = C_PRODUCING_AREA_PRIORITY2.PRODUCING_AREA_PRIORITY
               AND A.ENTITY_ID = P_ENTITY_ID;
               --AND B.ITEM_CODE = P_ITEM_CODE --判断产品在VS_PRODUCING_AREA_1ST产地是否生产
               --AND B.PRODUCING_AREA_CODE = A.PRODUCING_AREA_CODE;
          EXCEPTION
            WHEN OTHERS THEN
            NULL;
          END;

          IF VS_PRODUCING_AREA_2ND <> '-1' THEN
            EXIT;
          END IF;
        END LOOP;

        --营销中心不存在，插入销司产地表
        INSERT INTO T_PLN_SALES_CENTER_PA
          (SALES_CENTER_PA_ID,
           ENTITY_ID,
           ORDER_TYPE_ID,
           PERIOD_ID,
           ITEM_CODE,
           SALES_CENTER_CODE,
           SALES_CENTER_NAME,
           PRODUCING_AREA_CODE_1ST,
           --PRODUCING_AREA_CODE_2ND,
           APPLY_QTY,
           INV_AFFIRM_QTY,
           CHECK_QTY,
           CREATED_BY,
           CREATION_DATE,
           LAST_UPDATED_BY,
           LAST_UPDATE_DATE,
           PRE_FIELD_01,
           PRE_FIELD_02)
          SELECT S_PLN_SALES_CENTER_PA.NEXTVAL,
                 P_ENTITY_ID,
                 P_ORDER_TYPE_ID,
                 P_PERIOD_ID,
                 T.ITEM_CODE,
                 T.SALES_CENTER_CODE,
                 T.SALES_CENTER_NAME,
                 VS_PRODUCING_AREA_1ST,
                 T.APPLY_COLLECT_QTY,
                 T.INV_AFFIRM_COLLECT_QTY,
                 T.CHECK_COLLECT_QTY,
                 P_CREATED_BY,
                 SYSDATE,
                 P_CREATED_BY,
                 SYSDATE,
                 T.ORDER_NUMBER,
                 P_COLL_ORD_LINE_ID
            FROM (SELECT B.ITEM_CODE,
                         A.SALES_CENTER_CODE,
                         A.SALES_CENTER_NAME,
                         SUM(B.APPLY_QTY) APPLY_COLLECT_QTY,
                         SUM(B.INV_AFFIRM_QTY) INV_AFFIRM_COLLECT_QTY,
                         SUM(B.CHECK_QTY) CHECK_COLLECT_QTY,
                         A.ORDER_NUMBER
                    FROM T_PLN_ORDER_HEAD A, T_PLN_ORDER_LINE B
                   WHERE A.ORDER_TYPE_ID = P_ORDER_TYPE_ID
                     AND A.PERIOD_ID = P_PERIOD_ID
                     AND A.FORM_STATE = 25
                     AND A.BATCH_ID = P_BATCH_ID
                     AND A.ENTITY_ID = P_ENTITY_ID
                     AND A.SALES_CENTER_CODE = C_PLN_SALES_CENTER.SALES_CENTER_CODE
                     AND B.ORDER_HEAD_ID = A.ORDER_HEAD_ID
                     AND B.ITEM_CODE = P_ITEM_CODE
                     --AND B.PRODUCING_AREA_CODE IN (P_PA_LIST)
                   GROUP BY B.ITEM_CODE, A.SALES_CENTER_CODE, A.SALES_CENTER_NAME, A.ORDER_NUMBER) T;

        IF VS_PRODUCING_AREA_2ND <> '-1' THEN
          UPDATE T_PLN_SALES_CENTER_PA
             SET PRODUCING_AREA_CODE_2ND = VS_PRODUCING_AREA_2ND
           WHERE ORDER_TYPE_ID = P_ORDER_TYPE_ID
             AND PERIOD_ID = P_PERIOD_ID
             AND ENTITY_ID = P_ENTITY_ID
             AND ITEM_CODE = P_ITEM_CODE
             AND SALES_CENTER_CODE = C_PLN_SALES_CENTER.SALES_CENTER_CODE;
        END IF;

        FOR C_PLN_PRODUCING_AREA IN (SELECT A.ORDER_NUMBER, B.PRODUCING_AREA_CODE, B.CHECK_QTY
                                       FROM T_PLN_ORDER_HEAD A, T_PLN_ORDER_LINE B
                                      WHERE A.ORDER_TYPE_ID = P_ORDER_TYPE_ID
                                        AND A.PERIOD_ID = P_PERIOD_ID
                                        AND A.FORM_STATE = 25
                                        AND A.BATCH_ID = P_BATCH_ID
                                        AND A.ENTITY_ID = P_ENTITY_ID
                                        AND A.SALES_CENTER_CODE = C_PLN_SALES_CENTER.SALES_CENTER_CODE
                                        AND B.ORDER_HEAD_ID = A.ORDER_HEAD_ID
                                        AND B.ITEM_CODE = P_ITEM_CODE) LOOP
          IF C_PLN_PRODUCING_AREA.PRODUCING_AREA_CODE = VS_PRODUCING_AREA1 THEN
            VS_NAME := 'PRODUCING_AREA1_QTY';
          ELSIF C_PLN_PRODUCING_AREA.PRODUCING_AREA_CODE = VS_PRODUCING_AREA2 THEN
            VS_NAME := 'PRODUCING_AREA2_QTY';
          ELSIF C_PLN_PRODUCING_AREA.PRODUCING_AREA_CODE = VS_PRODUCING_AREA3 THEN
            VS_NAME := 'PRODUCING_AREA3_QTY';
          ELSIF C_PLN_PRODUCING_AREA.PRODUCING_AREA_CODE = VS_PRODUCING_AREA4 THEN
            VS_NAME := 'PRODUCING_AREA4_QTY';
          ELSIF C_PLN_PRODUCING_AREA.PRODUCING_AREA_CODE = VS_PRODUCING_AREA5 THEN
            VS_NAME := 'PRODUCING_AREA5_QTY';
          ELSIF C_PLN_PRODUCING_AREA.PRODUCING_AREA_CODE = VS_PRODUCING_AREA6 THEN
            VS_NAME := 'PRODUCING_AREA6_QTY';
          ELSIF C_PLN_PRODUCING_AREA.PRODUCING_AREA_CODE = VS_PRODUCING_AREA7 THEN
            VS_NAME := 'PRODUCING_AREA7_QTY';
          END IF;

          UPDATESQL := ' UPDATE T_PLN_SALES_CENTER_PA SET ' || VS_NAME || ' = ' || C_PLN_PRODUCING_AREA.CHECK_QTY
            || ' WHERE ORDER_TYPE_ID =     ' || P_ORDER_TYPE_ID
            || ' AND   PERIOD_ID =         ' || P_PERIOD_ID
            || ' AND   ENTITY_ID =         ' || P_ENTITY_ID
            || ' AND   ITEM_CODE =         ' || '''' || P_ITEM_CODE || ''''
            || ' AND   SALES_CENTER_CODE = ' || '''' || C_PLN_SALES_CENTER.SALES_CENTER_CODE || ''''
            || ' AND   PRE_FIELD_01 =      ' || '''' || C_PLN_PRODUCING_AREA.ORDER_NUMBER || ''''
            || ' AND   TYPE_FLAG IS NULL ';
          EXECUTE IMMEDIATE UPDATESQL;
        END LOOP;
      ELSE
        --营销中心存在，更新销司产地表
        SELECT A.ORDER_NUMBER,
               SUM(B.APPLY_QTY) APPLY_COLLECT_QTY,
               SUM(B.INV_AFFIRM_QTY) INV_AFFIRM_COLLECT_QTY,
               SUM(B.CHECK_QTY) CHECK_COLLECT_QTY
          INTO VS_ORDER_NUMBER,
               VN_APPLY_COLLECT_QTY,
               VN_INV_AFFIRM_COLLECT_QTY,
               VN_CHECK_COLLECT_QTY
          FROM T_PLN_ORDER_HEAD A, T_PLN_ORDER_LINE B
         WHERE A.ORDER_TYPE_ID = P_ORDER_TYPE_ID
           AND A.PERIOD_ID = P_PERIOD_ID
           AND A.FORM_STATE = 25
           AND A.BATCH_ID = P_BATCH_ID
           AND A.ENTITY_ID = P_ENTITY_ID
           AND A.SALES_CENTER_CODE = C_PLN_SALES_CENTER.SALES_CENTER_CODE
           AND B.ORDER_HEAD_ID = A.ORDER_HEAD_ID
           AND B.ITEM_CODE = P_ITEM_CODE
           --AND B.PRODUCING_AREA_CODE IN (P_PA_LIST)
         GROUP BY A.ORDER_NUMBER;

        UPDATE T_PLN_SALES_CENTER_PA
           SET APPLY_QTY = VN_APPLY_COLLECT_QTY,
               INV_AFFIRM_QTY = VN_INV_AFFIRM_COLLECT_QTY,
               CHECK_QTY = VN_CHECK_COLLECT_QTY
         WHERE ORDER_TYPE_ID = P_ORDER_TYPE_ID
           AND PERIOD_ID = P_PERIOD_ID
           AND ENTITY_ID = P_ENTITY_ID
           AND ITEM_CODE = P_ITEM_CODE
           AND SALES_CENTER_CODE = C_PLN_SALES_CENTER.SALES_CENTER_CODE
           AND PRE_FIELD_01 = VS_ORDER_NUMBER
           AND TYPE_FLAG IS NULL;

        FOR C_PLN_PRODUCING_AREA2 IN (SELECT A.ORDER_NUMBER, B.PRODUCING_AREA_CODE, B.CHECK_QTY
                                        FROM T_PLN_ORDER_HEAD A, T_PLN_ORDER_LINE B
                                       WHERE A.ORDER_TYPE_ID = P_ORDER_TYPE_ID
                                         AND A.PERIOD_ID = P_PERIOD_ID
                                         AND A.FORM_STATE = 25
                                         AND A.BATCH_ID = P_BATCH_ID
                                         AND A.ENTITY_ID = P_ENTITY_ID
                                         AND A.SALES_CENTER_CODE = C_PLN_SALES_CENTER.SALES_CENTER_CODE
                                         AND B.ORDER_HEAD_ID = A.ORDER_HEAD_ID
                                         AND B.ITEM_CODE = P_ITEM_CODE) LOOP
          IF C_PLN_PRODUCING_AREA2.PRODUCING_AREA_CODE = VS_PRODUCING_AREA1 THEN
            VS_NAME := 'PRODUCING_AREA1_QTY';
          ELSIF C_PLN_PRODUCING_AREA2.PRODUCING_AREA_CODE = VS_PRODUCING_AREA2 THEN
            VS_NAME := 'PRODUCING_AREA2_QTY';
          ELSIF C_PLN_PRODUCING_AREA2.PRODUCING_AREA_CODE = VS_PRODUCING_AREA3 THEN
            VS_NAME := 'PRODUCING_AREA3_QTY';
          ELSIF C_PLN_PRODUCING_AREA2.PRODUCING_AREA_CODE = VS_PRODUCING_AREA4 THEN
            VS_NAME := 'PRODUCING_AREA4_QTY';
          ELSIF C_PLN_PRODUCING_AREA2.PRODUCING_AREA_CODE = VS_PRODUCING_AREA5 THEN
            VS_NAME := 'PRODUCING_AREA5_QTY';
          ELSIF C_PLN_PRODUCING_AREA2.PRODUCING_AREA_CODE = VS_PRODUCING_AREA6 THEN
            VS_NAME := 'PRODUCING_AREA6_QTY';
          ELSIF C_PLN_PRODUCING_AREA2.PRODUCING_AREA_CODE = VS_PRODUCING_AREA7 THEN
            VS_NAME := 'PRODUCING_AREA7_QTY';
          END IF;

          UPDATESQL := ' UPDATE T_PLN_SALES_CENTER_PA SET ' || VS_NAME || ' = ' || C_PLN_PRODUCING_AREA2.CHECK_QTY
            || ' WHERE ORDER_TYPE_ID =     ' || P_ORDER_TYPE_ID
            || ' AND   PERIOD_ID =         ' || P_PERIOD_ID
            || ' AND   ENTITY_ID =         ' || P_ENTITY_ID
            || ' AND   ITEM_CODE =         ' || '''' || P_ITEM_CODE || ''''
            || ' AND   SALES_CENTER_CODE = ' || '''' || C_PLN_SALES_CENTER.SALES_CENTER_CODE || ''''
            || ' AND   PRE_FIELD_01 =      ' || '''' || C_PLN_PRODUCING_AREA2.ORDER_NUMBER || ''''
            || ' AND   TYPE_FLAG IS NULL ';
          EXECUTE IMMEDIATE UPDATESQL;
        END LOOP;
      END IF;
    END LOOP;

  EXCEPTION
    WHEN OTHERS THEN
      P_RESULT := '订单行转换销司产地信息失败。' || V_NL || '失败信息：' || SQLERRM;
      ROLLBACK;
  END;

  ----------------------------------------------------------------------
  -- Author  : fenggq
  -- Created : 2014-11-19 16:31:00
  -- Purpose : 校验销司产地信息
  ----------------------------------------------------------------------
  PROCEDURE P_CHECK_SALES_CENTER_PA(P_ORDER_NUMBER        IN VARCHAR2, --订单号
                                    P_ORDER_TYPE_ID       IN NUMBER,   --订单类型ID
                                    P_PERIOD_ID           IN NUMBER,   --订单周期ID
                                    P_BATCH_ID            IN NUMBER,   --批次ID
                                    P_ITEM_CODE           IN VARCHAR2, --产品编码
                                    P_SALES_CENTER_CODE   IN VARCHAR2, --营销中心编码
                                    P_PRODUCING_AREA_CODE IN VARCHAR2, --产地编码
                                    P_PRODUCING_AREA_QTY  IN NUMBER,   --产地数量
                                    P_ENTITY_ID           IN NUMBER,   --主体ID
                                    P_CREATED_BY          IN VARCHAR2, --创建人
                                    P_RESULT              OUT VARCHAR2) Is
    VN_ORDER_COUNT         NUMBER; --待按产品分解的订单数量（按营销中心、产地、产品）
    VN_IFCP_COUNT          NUMBER; --在中心供货优先级配置的营销中心、产地、产品是否存在
    VN_IFPA_COUNT          NUMBER; --在产品产地表配置的产品、产地是否存在

    VS_ITEM_NAME           T_PLN_ORDER_LINE.ITEM_DESC%TYPE;
    VS_PRODUCING_AREA_NAME T_PLN_PRODUCING_AREA.PRODUCING_AREA_NAME%TYPE;
    VN_ORDER_LINE_ID       T_PLN_ORDER_LINE.ORDER_LINE_ID%TYPE;
    V_COLLECT_LINE_ID      NUMBER;
    V_COLLECT_HEAD_ID      NUMBER;

  BEGIN
    P_RESULT := V_SUCCESS;
    --ADD BY LIZHEN 2015-01-20 增加获取前锁定汇总单头
    BEGIN
      SELECT CH.COLL_ORD_HEAD_ID
        INTO V_COLLECT_HEAD_ID
        FROM T_PLN_ORDER_COLLECT_HEAD CH
       WHERE CH.ORDER_TYPE_ID = P_ORDER_TYPE_ID
         AND CH.PERIOD_ID = P_PERIOD_ID
         AND CH.COLL_ORD_NUMBER = TO_CHAR(P_BATCH_ID)
         AND CH.ENTITY_ID = P_ENTITY_ID
         FOR UPDATE NOWAIT;
    EXCEPTION
      WHEN OTHERS THEN
        P_RESULT := '锁定汇总订单头失败，' || SQLERRM;
        RETURN;
    END;

    BEGIN
      SELECT CL.COLL_ORD_LINE_ID
        INTO V_COLLECT_LINE_ID
        FROM T_PLN_ORDER_COLLECT_LINE CL
       WHERE CL.ENTITY_ID = P_ENTITY_ID
         AND CL.ITEM_CODE = P_ITEM_CODE
         AND CL.COLL_ORD_HEAD_ID = V_COLLECT_HEAD_ID;
    EXCEPTION
      WHEN OTHERS THEN
        P_RESULT := '锁定汇总订单行失败。' || SQLERRM || '产品编码：' || P_ITEM_CODE ||
                    CHR(13) || CHR(10) || '汇总订单头ID：' ||
                    TO_CHAR(V_COLLECT_HEAD_ID);
        RETURN;
    END;

    SELECT COUNT(*)
      INTO VN_ORDER_COUNT
      FROM T_PLN_ORDER_HEAD A, T_PLN_ORDER_LINE B
     WHERE A.ORDER_NUMBER = P_ORDER_NUMBER
       AND A.ORDER_TYPE_ID = P_ORDER_TYPE_ID
       AND A.PERIOD_ID = P_PERIOD_ID
       AND A.FORM_STATE = 25
       AND A.BATCH_ID = P_BATCH_ID
       AND A.ENTITY_ID = P_ENTITY_ID
       AND A.SALES_CENTER_CODE = P_SALES_CENTER_CODE
       AND B.ORDER_HEAD_ID = A.ORDER_HEAD_ID
       AND B.PRODUCING_AREA_CODE = P_PRODUCING_AREA_CODE
       AND B.ITEM_CODE = P_ITEM_CODE;

    SELECT COUNT(*)
      INTO VN_IFCP_COUNT
      FROM T_PLN_CUSTOMER_PRIORITY
     WHERE SALES_CENTER_CODE = P_SALES_CENTER_CODE
       AND ITEM_CODE = P_ITEM_CODE
       AND PRODUCING_AREA_CODE = P_PRODUCING_AREA_CODE
       AND ENTITY_ID = P_ENTITY_ID;

    --订单行不存在
    IF VN_ORDER_COUNT = 0 THEN
      --中心供货优先级已维护产品
      IF VN_IFCP_COUNT > 0 THEN
        SELECT COUNT(*)
          INTO VN_IFPA_COUNT
          FROM T_PLN_CUSTOMER_PRIORITY A, T_PLN_ITEM_PRODUCING_AREA B
         WHERE A.SALES_CENTER_CODE = P_SALES_CENTER_CODE
           AND A.ITEM_CODE = P_ITEM_CODE
           AND A.PRODUCING_AREA_CODE = P_PRODUCING_AREA_CODE
           AND A.ENTITY_ID = P_ENTITY_ID
           AND B.ITEM_CODE = A.ITEM_CODE --判断产品在P_PRODUCING_AREA_CODE是否生产
           AND B.PRODUCING_AREA_CODE = A.PRODUCING_AREA_CODE;
      --中心供货优先级没有维护产品
      ELSE
        SELECT COUNT(*)
          INTO VN_IFPA_COUNT
          FROM T_PLN_ITEM_PRODUCING_AREA
         WHERE ITEM_CODE = P_ITEM_CODE --判断产品在P_PRODUCING_AREA_CODE是否生产
           AND PRODUCING_AREA_CODE = P_PRODUCING_AREA_CODE;
      END IF;

      --产品不在产地生产
      IF VN_IFPA_COUNT = 0 AND P_PRODUCING_AREA_QTY > 0 THEN

        SELECT ITEM_NAME
           INTO VS_ITEM_NAME
           FROM T_BD_ITEM
          WHERE ITEM_CODE = P_ITEM_CODE
            AND ENTITY_ID = P_ENTITY_ID;

        SELECT PRODUCING_AREA_NAME
           INTO VS_PRODUCING_AREA_NAME
           FROM T_PLN_PRODUCING_AREA
          WHERE PRODUCING_AREA_CODE = P_PRODUCING_AREA_CODE
            AND ENTITY_ID = P_ENTITY_ID;

        P_RESULT := '产品：' || P_ITEM_CODE || ' ' || VS_ITEM_NAME || '，在产地：' || P_PRODUCING_AREA_CODE || ' ' || VS_PRODUCING_AREA_NAME || '不生产。';
        RETURN;
      --产品在产地生产
      ELSIF VN_IFPA_COUNT > 0 AND P_PRODUCING_AREA_QTY > 0 THEN
        VN_ORDER_LINE_ID := S_PLN_ORDER_LINE.NEXTVAL;
        INSERT INTO T_PLN_ORDER_LINE
          (ENTITY_ID,
           ORDER_LINE_ID,
           ORDER_HEAD_ID,
           PRODUCING_AREA_ID,
           PRODUCING_AREA_CODE,
           PRODUCING_AREA_NAME,
           ITEM_ID,
           ITEM_CODE,
           ITEM_DESC,
           ITEM_UOM,
           ITEM_PRICE,
           APPLY_QTY,
           CHECK_QTY,
           CAN_PRODUCE_QTY, --?
           AMOUNT,
           DISCOUNT_RATE,
           STATUS,
           CAN_SUPPLY_DATE,
           BEGIN_SUPPLY_DATE,
           END_SUPPLY_DATE,
           ADJUST_QTY, --?
           CREATED_BY,
           CREATION_DATE,
           LAST_UPDATED_BY,
           LAST_UPDATE_DATE)
          SELECT P_ENTITY_ID,
                 VN_ORDER_LINE_ID,
                 B.ORDER_HEAD_ID,
                 (SELECT PRODUCING_AREA_ID
                    FROM T_PLN_PRODUCING_AREA
                   WHERE PRODUCING_AREA_CODE = P_PRODUCING_AREA_CODE
                     AND ENTITY_ID = P_ENTITY_ID),
                 P_PRODUCING_AREA_CODE,
                 (SELECT PRODUCING_AREA_NAME
                    FROM T_PLN_PRODUCING_AREA
                   WHERE PRODUCING_AREA_CODE = P_PRODUCING_AREA_CODE
                     AND ENTITY_ID = P_ENTITY_ID),
                 B.ITEM_ID,
                 B.ITEM_CODE,
                 B.ITEM_DESC,
                 B.ITEM_UOM,
                 B.ITEM_PRICE,
                 0,
                 P_PRODUCING_AREA_QTY,
                 P_PRODUCING_AREA_QTY,
                 B.ITEM_PRICE * P_PRODUCING_AREA_QTY * (100 - NVL(B.DISCOUNT_RATE, 0)) / 100,
                 B.DISCOUNT_RATE,
                 B.STATUS,
                 B.CAN_SUPPLY_DATE,
                 B.BEGIN_SUPPLY_DATE,
                 B.END_SUPPLY_DATE,
                 B.ADJUST_QTY,
                 P_CREATED_BY,
                 SYSDATE,
                 P_CREATED_BY,
                 SYSDATE
            FROM T_PLN_ORDER_HEAD A, T_PLN_ORDER_LINE B
           WHERE A.ORDER_NUMBER = P_ORDER_NUMBER
             AND A.ORDER_TYPE_ID = P_ORDER_TYPE_ID
             AND A.PERIOD_ID = P_PERIOD_ID
             AND A.FORM_STATE = 25
             AND A.BATCH_ID = P_BATCH_ID
             AND A.SALES_CENTER_CODE = P_SALES_CENTER_CODE
             AND A.ENTITY_ID = P_ENTITY_ID
             AND B.ORDER_HEAD_ID = A.ORDER_HEAD_ID
             AND B.ITEM_CODE = P_ITEM_CODE
             AND B.APPLY_QTY <> 0;

        INSERT INTO T_PLN_ORDER_COLLECT_RELATION
          (ENTITY_ID,
           RELATION_ID,
           ORDER_LINE_ID,
           COLL_ORD_LINE_ID,
           ORDER_COLLECT_HEAD_ID,
           CREATED_BY,
           CREATION_DATE,
           LAST_UPDATED_BY,
           LAST_UPDATE_DATE)
        VALUES
          (P_ENTITY_ID,
           S_PLN_ORDER_COLLECT_RELATION.NEXTVAL,
           VN_ORDER_LINE_ID,
           V_COLLECT_LINE_ID,
           V_COLLECT_HEAD_ID,
           P_CREATED_BY,
           SYSDATE,
           P_CREATED_BY,
           SYSDATE);
      END IF;
    --订单行存在
    ELSE
      UPDATE T_PLN_ORDER_LINE
         SET CHECK_QTY = P_PRODUCING_AREA_QTY,
             CAN_PRODUCE_QTY = P_PRODUCING_AREA_QTY
       WHERE ORDER_HEAD_ID =
               (SELECT A.ORDER_HEAD_ID
                  FROM T_PLN_ORDER_HEAD A, T_PLN_ORDER_LINE B
                 WHERE A.ORDER_NUMBER = P_ORDER_NUMBER
                   AND A.ORDER_TYPE_ID = P_ORDER_TYPE_ID
                   AND A.PERIOD_ID = P_PERIOD_ID
                   AND A.FORM_STATE = 25
                   AND A.BATCH_ID = P_BATCH_ID
                   AND A.SALES_CENTER_CODE = P_SALES_CENTER_CODE
                   AND A.ENTITY_ID = P_ENTITY_ID
                   AND B.ORDER_HEAD_ID = A.ORDER_HEAD_ID
                   AND B.ITEM_CODE = P_ITEM_CODE
                   AND B.APPLY_QTY <> 0)
         AND ITEM_CODE = P_ITEM_CODE
         AND PRODUCING_AREA_CODE = P_PRODUCING_AREA_CODE;
    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      P_RESULT := '校验销司产品信息失败。' || V_NL || '失败信息：' || SQLERRM;
      ROLLBACK;
  END;

  ----------------------------------------------------------------------
  -- Author  : fenggq
  -- Created : 2014-11-29 10:23:00
  -- Purpose : 更新订单行
  ----------------------------------------------------------------------
  PROCEDURE P_UPDATE_ORDER_LINE(P_ORDER_TYPE_ID IN NUMBER,   --订单类型ID
                                P_PERIOD_ID     IN NUMBER,   --订单周期ID
                                P_BATCH_ID      IN NUMBER,   --批次ID
                                P_ENTITY_ID     IN NUMBER,   --主体ID
                                P_CREATED_BY    IN VARCHAR2, --创建人
                                P_RESULT        OUT VARCHAR2) IS

    VN_ORDER_COUNT NUMBER;

  BEGIN
    P_RESULT := V_SUCCESS;

    FOR C_PLN_ORDER_ADJUST IN
      (SELECT *
         FROM T_PLN_ORDER_ADJUST
        WHERE ORDER_TYPE_ID = P_ORDER_TYPE_ID
          AND PERIOD_ID = P_PERIOD_ID) LOOP
      UPDATE T_PLN_ORDER_LINE
         SET CHECK_QTY = CHECK_QTY - C_PLN_ORDER_ADJUST.ADJUST_QTY,
             CAN_PRODUCE_QTY = CAN_PRODUCE_QTY - C_PLN_ORDER_ADJUST.ADJUST_QTY
       WHERE ORDER_HEAD_ID =
               (SELECT ORDER_HEAD_ID
                  FROM T_PLN_ORDER_HEAD
                 WHERE ORDER_TYPE_ID = P_ORDER_TYPE_ID
                   AND PERIOD_ID = P_PERIOD_ID
                   AND FORM_STATE = 25
                   AND BATCH_ID = P_BATCH_ID
                   AND ENTITY_ID = P_ENTITY_ID
                   AND SALES_CENTER_CODE = C_PLN_ORDER_ADJUST.SALES_CENTER_CODE)
         AND PRODUCING_AREA_CODE = C_PLN_ORDER_ADJUST.OLD_PRODUCING_AREA_CODE
         AND ITEM_CODE = C_PLN_ORDER_ADJUST.ITEM_CODE;

      SELECT COUNT(*)
        INTO VN_ORDER_COUNT
        FROM T_PLN_ORDER_HEAD A, T_PLN_ORDER_LINE B
       WHERE A.ORDER_TYPE_ID = P_ORDER_TYPE_ID
         AND A.PERIOD_ID = P_PERIOD_ID
         AND A.FORM_STATE = 25
         AND A.BATCH_ID = P_BATCH_ID
         AND A.ENTITY_ID = P_ENTITY_ID
         AND A.SALES_CENTER_CODE = C_PLN_ORDER_ADJUST.SALES_CENTER_CODE
         AND B.ORDER_HEAD_ID = A.ORDER_HEAD_ID
         AND B.PRODUCING_AREA_CODE = C_PLN_ORDER_ADJUST.NEW_PRODUCING_AREA_CODE
         AND B.ITEM_CODE = C_PLN_ORDER_ADJUST.ITEM_CODE;

      --订单行不存在
      IF VN_ORDER_COUNT = 0 THEN
        INSERT INTO T_PLN_ORDER_LINE
          (ENTITY_ID,
           ORDER_LINE_ID,
           ORDER_HEAD_ID,
           PRODUCING_AREA_ID,
           PRODUCING_AREA_CODE,
           PRODUCING_AREA_NAME,
           ITEM_ID,
           ITEM_CODE,
           ITEM_DESC,
           ITEM_UOM,
           ITEM_PRICE,
           APPLY_QTY,
           CHECK_QTY,
           CAN_PRODUCE_QTY, --?
           AMOUNT,
           STATUS,
           CAN_SUPPLY_DATE,
           BEGIN_SUPPLY_DATE,
           END_SUPPLY_DATE,
           ADJUST_QTY, --?
           CREATED_BY,
           CREATION_DATE,
           LAST_UPDATED_BY,
           LAST_UPDATE_DATE)
          SELECT P_ENTITY_ID,
                 S_PLN_ORDER_LINE.NEXTVAL,
                 B.ORDER_HEAD_ID,
                 (SELECT PRODUCING_AREA_ID
                    FROM T_PLN_PRODUCING_AREA
                   WHERE PRODUCING_AREA_CODE = C_PLN_ORDER_ADJUST.NEW_PRODUCING_AREA_CODE
                     AND ENTITY_ID = P_ENTITY_ID),
                 C_PLN_ORDER_ADJUST.NEW_PRODUCING_AREA_CODE,
                 (SELECT PRODUCING_AREA_NAME
                    FROM T_PLN_PRODUCING_AREA
                   WHERE PRODUCING_AREA_CODE = C_PLN_ORDER_ADJUST.NEW_PRODUCING_AREA_CODE
                     AND ENTITY_ID = P_ENTITY_ID),
                 B.ITEM_ID,
                 B.ITEM_CODE,
                 B.ITEM_DESC,
                 B.ITEM_UOM,
                 B.ITEM_PRICE,
                 0,
                 C_PLN_ORDER_ADJUST.ADJUST_QTY,
                 C_PLN_ORDER_ADJUST.ADJUST_QTY,
                 B.AMOUNT,
                 B.STATUS,
                 B.CAN_SUPPLY_DATE,
                 B.BEGIN_SUPPLY_DATE,
                 B.END_SUPPLY_DATE,
                 B.ADJUST_QTY,
                 P_CREATED_BY,
                 SYSDATE,
                 P_CREATED_BY,
                 SYSDATE
            FROM T_PLN_ORDER_HEAD A, T_PLN_ORDER_LINE B
           WHERE A.ORDER_TYPE_ID = P_ORDER_TYPE_ID
             AND A.PERIOD_ID = P_PERIOD_ID
             AND A.FORM_STATE = 25
             AND A.BATCH_ID = P_BATCH_ID
             AND A.ENTITY_ID = P_ENTITY_ID
             AND A.SALES_CENTER_CODE = C_PLN_ORDER_ADJUST.SALES_CENTER_CODE
             AND B.ORDER_HEAD_ID = A.ORDER_HEAD_ID
             AND B.PRODUCING_AREA_CODE = C_PLN_ORDER_ADJUST.OLD_PRODUCING_AREA_CODE
             AND B.ITEM_CODE = C_PLN_ORDER_ADJUST.ITEM_CODE;
      --订单行存在
      ELSE
        UPDATE T_PLN_ORDER_LINE
           SET CHECK_QTY = CHECK_QTY + C_PLN_ORDER_ADJUST.ADJUST_QTY,
               CAN_PRODUCE_QTY = CAN_PRODUCE_QTY + C_PLN_ORDER_ADJUST.ADJUST_QTY,
               LAST_UPDATED_BY = P_CREATED_BY,
               LAST_UPDATE_DATE = SYSDATE
         WHERE ORDER_HEAD_ID =
                 (SELECT ORDER_HEAD_ID
                   FROM T_PLN_ORDER_HEAD
                  WHERE ORDER_TYPE_ID = P_ORDER_TYPE_ID
                    AND PERIOD_ID = P_PERIOD_ID
                    AND FORM_STATE = 25
                    AND BATCH_ID = P_BATCH_ID
                    AND ENTITY_ID = P_ENTITY_ID
                    AND SALES_CENTER_CODE = C_PLN_ORDER_ADJUST.SALES_CENTER_CODE)
           AND PRODUCING_AREA_CODE = C_PLN_ORDER_ADJUST.NEW_PRODUCING_AREA_CODE
           AND ITEM_CODE = C_PLN_ORDER_ADJUST.ITEM_CODE;
      END IF;
    END LOOP;

  EXCEPTION
    WHEN OTHERS THEN
      P_RESULT := '更新订单行失败。' || V_NL || '失败信息：' || SQLERRM;
      ROLLBACK;
  END;

  ----------------------------------------------------------------------
  -- Author  : fenggq
  -- Created : 2014-12-16 15:53:00
  -- Purpose : 校验周排产订单销司产地信息和排产量
  ----------------------------------------------------------------------
  PROCEDURE P_CHECK_WEEK_SC_PA_QTY(P_ORDER_NUMBER        IN VARCHAR2, --订单号
                                   P_ORDER_TYPE_ID       IN NUMBER,   --订单类型ID
                                   P_PERIOD_ID           IN NUMBER,   --订单周期ID
                                   P_BATCH_ID            IN NUMBER,   --批次ID
                                   P_ITEM_CODE           IN VARCHAR2, --产品编码
                                   P_SALES_CENTER_CODE   IN VARCHAR2, --营销中心编码
                                   P_PRODUCING_AREA_CODE IN VARCHAR2, --产地编码s
                                   P_PRODUCING_AREA_QTY  IN NUMBER,   --产地数量
                                   P_ENTITY_ID           IN NUMBER,   --主体ID
                                   P_CREATED_BY          IN VARCHAR2, --创建人
                                   P_RESULT              OUT VARCHAR2) IS

    VN_MONTH_COUNT         NUMBER;
    VN_WEEK_COUNT          NUMBER;

    VS_CAN_PRODUCE_QTY     T_PLN_ORDER_LINE.CAN_PRODUCE_QTY%TYPE;
    VS_CHECK_QTY           T_PLN_ORDER_LINE.CHECK_QTY%TYPE;
    VS_ITEM_NAME           T_PLN_ORDER_LINE.ITEM_DESC%TYPE;
    VS_PRODUCING_AREA_NAME T_PLN_PRODUCING_AREA.PRODUCING_AREA_NAME%TYPE;
    VN_ORDER_LINE_ID       T_PLN_ORDER_LINE.ORDER_LINE_ID%TYPE;
    V_COLLECT_LINE_ID      NUMBER;
    V_COLLECT_HEAD_ID      NUMBER;
  BEGIN
    P_RESULT := V_SUCCESS;
    --add by lizhen 2015-01-20 增加获取前锁定汇总单头
    BEGIN
      SELECT CH.COLL_ORD_HEAD_ID
        INTO V_COLLECT_HEAD_ID
        FROM T_PLN_ORDER_COLLECT_HEAD CH
       WHERE CH.ORDER_TYPE_ID = P_ORDER_TYPE_ID
         AND CH.PERIOD_ID = P_PERIOD_ID
         AND CH.COLL_ORD_NUMBER = TO_CHAR(P_BATCH_ID)
         AND CH.ENTITY_ID = P_ENTITY_ID
         FOR UPDATE NOWAIT;
    EXCEPTION
      WHEN OTHERS THEN
        P_RESULT := '锁定汇总订单头失败，' || SQLERRM;
        RETURN;
    END;

    BEGIN
      SELECT CL.COLL_ORD_LINE_ID
        INTO V_COLLECT_LINE_ID
        FROM T_PLN_ORDER_COLLECT_LINE CL
       WHERE CL.ENTITY_ID = P_ENTITY_ID
         AND CL.ITEM_CODE = P_ITEM_CODE
         AND CL.COLL_ORD_HEAD_ID = V_COLLECT_HEAD_ID;
    EXCEPTION
      WHEN OTHERS THEN
        P_RESULT := '获取汇总订单行ID失败。' || SQLERRM || '产品编码：' || P_ITEM_CODE ||
                    CHR(13) || CHR(10) || '汇总订单头ID：' ||
                    TO_CHAR(V_COLLECT_HEAD_ID);
        RETURN;
    END;
    --获取月订单行
    SELECT COUNT(*)
      INTO VN_MONTH_COUNT
      FROM T_PLN_ORDER_HEAD A, T_PLN_ORDER_LINE B
     WHERE A.ORDER_TYPE_ID IN (216, 217, 218)
       AND A.PERIOD_ID =
           (SELECT PERIOD_ID
              FROM T_PLN_ORDER_PERIOD
             WHERE SALE_YEAR_YEAR = (SELECT SALE_YEAR_YEAR
                                       FROM T_PLN_ORDER_PERIOD
                                      WHERE PERIOD_ID = P_PERIOD_ID
                                        AND ENTITY_ID = P_ENTITY_ID)
               AND SALE_YEAR_MONTH = (SELECT SALE_YEAR_MONTH
                                        FROM T_PLN_ORDER_PERIOD
                                       WHERE PERIOD_ID = P_PERIOD_ID
                                         AND ENTITY_ID = P_ENTITY_ID)
               AND SALE_YEAR_WEEK IS NULL)
       AND A.FORM_STATE = 23
       --AND A.BATCH_ID = P_BATCH_ID
       AND A.ENTITY_ID = P_ENTITY_ID
       AND A.SALES_CENTER_CODE = P_SALES_CENTER_CODE
       AND B.ORDER_HEAD_ID = A.ORDER_HEAD_ID
       AND B.PRODUCING_AREA_CODE = P_PRODUCING_AREA_CODE
       AND B.ITEM_CODE = P_ITEM_CODE;
    --获取周订单行
    SELECT COUNT(*)
      INTO VN_WEEK_COUNT
      FROM T_PLN_ORDER_HEAD A, T_PLN_ORDER_LINE B
     WHERE A.ORDER_TYPE_ID = P_ORDER_TYPE_ID
       AND A.PERIOD_ID = P_PERIOD_ID
       AND A.FORM_STATE = 25
       AND A.BATCH_ID = P_BATCH_ID
       AND A.ENTITY_ID = P_ENTITY_ID
       AND A.SALES_CENTER_CODE = P_SALES_CENTER_CODE
       AND B.ORDER_HEAD_ID = A.ORDER_HEAD_ID
       AND B.ITEM_CODE = P_ITEM_CODE
       AND B.PRODUCING_AREA_CODE = P_PRODUCING_AREA_CODE;

    --月订单行不存在
    IF VN_MONTH_COUNT = 0 AND P_PRODUCING_AREA_QTY > 0 THEN
      SELECT ITEM_NAME
        INTO VS_ITEM_NAME
        FROM T_BD_ITEM
       WHERE ITEM_CODE = P_ITEM_CODE
         AND ENTITY_ID = P_ENTITY_ID;

     SELECT PRODUCING_AREA_NAME
        INTO VS_PRODUCING_AREA_NAME
        FROM T_PLN_PRODUCING_AREA
       WHERE PRODUCING_AREA_CODE = P_PRODUCING_AREA_CODE
         AND ENTITY_ID = P_ENTITY_ID;

      P_RESULT := '月订单中没有产品：' || P_ITEM_CODE || ' ' || VS_ITEM_NAME || '，在产地：' || P_PRODUCING_AREA_CODE || ' ' || VS_PRODUCING_AREA_NAME || '排产的订单。';
      RETURN;
    --月订单行存在
    ELSE
      --周订单行不存在
      IF VN_WEEK_COUNT = 0 THEN
        --月订单（M+1）、月订单（M+2）、月增补订单同一周期可生产量
        SELECT NVL(SUM(B.CAN_PRODUCE_QTY), 0) - NVL(SUM(B.CHECK_ADJUST_QTY), 0)
          INTO VS_CAN_PRODUCE_QTY
          FROM T_PLN_ORDER_HEAD A, T_PLN_ORDER_LINE B
         WHERE A.ORDER_TYPE_ID IN (216, 217, 218)
           AND A.PERIOD_ID =
               (SELECT PERIOD_ID
                  FROM T_PLN_ORDER_PERIOD
                 WHERE SALE_YEAR_YEAR = (SELECT SALE_YEAR_YEAR
                                           FROM T_PLN_ORDER_PERIOD
                                          WHERE PERIOD_ID = P_PERIOD_ID
                                            AND ENTITY_ID = P_ENTITY_ID)
                   AND SALE_YEAR_MONTH = (SELECT SALE_YEAR_MONTH
                                            FROM T_PLN_ORDER_PERIOD
                                           WHERE PERIOD_ID = P_PERIOD_ID
                                             AND ENTITY_ID = P_ENTITY_ID)
                   AND SALE_YEAR_WEEK IS NULL)
           AND A.FORM_STATE = 23
           AND A.ENTITY_ID = P_ENTITY_ID
           AND A.SALES_CENTER_CODE = P_SALES_CENTER_CODE
           AND B.ORDER_HEAD_ID = A.ORDER_HEAD_ID
           AND B.PRODUCING_AREA_CODE = P_PRODUCING_AREA_CODE
           AND B.ITEM_CODE = P_ITEM_CODE;
        --周排产订单四周评审总量
        SELECT NVL(SUM(B.CAN_PRODUCE_QTY), 0) - NVL(SUM(B.CHECK_ADJUST_QTY), 0)
          INTO VS_CHECK_QTY
          FROM T_PLN_ORDER_HEAD A, T_PLN_ORDER_LINE B
         WHERE A.ORDER_TYPE_ID = 220
           AND A.PERIOD_ID IN
               (SELECT PERIOD_ID
                  FROM T_PLN_ORDER_PERIOD
                 WHERE SALE_YEAR_YEAR = (SELECT SALE_YEAR_YEAR
                                           FROM T_PLN_ORDER_PERIOD
                                          WHERE PERIOD_ID = P_PERIOD_ID
                                            AND ENTITY_ID = P_ENTITY_ID)
                   AND SALE_YEAR_MONTH = (SELECT SALE_YEAR_MONTH
                                            FROM T_PLN_ORDER_PERIOD
                                           WHERE PERIOD_ID = P_PERIOD_ID
                                             AND ENTITY_ID = P_ENTITY_ID)
                   AND SALE_YEAR_WEEK <> (SELECT SALE_YEAR_WEEK
                                            FROM T_PLN_ORDER_PERIOD
                                           WHERE PERIOD_ID = P_PERIOD_ID
                                             AND ENTITY_ID = P_ENTITY_ID)
                   AND SALE_YEAR_WEEK IS NOT NULL)
           AND A.FORM_STATE = 32
           AND A.ENTITY_ID = P_ENTITY_ID
           AND A.SALES_CENTER_CODE = P_SALES_CENTER_CODE
           AND B.ORDER_HEAD_ID = A.ORDER_HEAD_ID
           AND B.PRODUCING_AREA_CODE = P_PRODUCING_AREA_CODE
           AND B.ITEM_CODE = P_ITEM_CODE;

        IF VS_CAN_PRODUCE_QTY - VS_CHECK_QTY - P_PRODUCING_AREA_QTY < 0 THEN
          SELECT PRODUCING_AREA_NAME
            INTO VS_PRODUCING_AREA_NAME
            FROM T_PLN_PRODUCING_AREA
           WHERE PRODUCING_AREA_CODE = P_PRODUCING_AREA_CODE
             AND ENTITY_ID = P_ENTITY_ID;

          P_RESULT := '产地：' || P_PRODUCING_AREA_CODE || ' ' || VS_PRODUCING_AREA_NAME || '，排产量超过月订单可生产量。';
          RETURN;
        ELSE
          VN_ORDER_LINE_ID := S_PLN_ORDER_LINE.NEXTVAL;
          INSERT INTO T_PLN_ORDER_LINE
            (ENTITY_ID,
             ORDER_LINE_ID,
             ORDER_HEAD_ID,
             PRODUCING_AREA_ID,
             PRODUCING_AREA_CODE,
             PRODUCING_AREA_NAME,
             ITEM_ID,
             ITEM_CODE,
             ITEM_DESC,
             ITEM_UOM,
             ITEM_PRICE,
             APPLY_QTY,
             CHECK_QTY,
             CAN_PRODUCE_QTY, --?
             AMOUNT,
             DISCOUNT_RATE,
             STATUS,
             CAN_SUPPLY_DATE,
             BEGIN_SUPPLY_DATE,
             END_SUPPLY_DATE,
             ADJUST_QTY, --?
             CREATED_BY,
             CREATION_DATE,
             LAST_UPDATED_BY,
             LAST_UPDATE_DATE)
            SELECT DISTINCT P_ENTITY_ID,
                   VN_ORDER_LINE_ID,
                   B.ORDER_HEAD_ID,
                   (SELECT PRODUCING_AREA_ID
                      FROM T_PLN_PRODUCING_AREA
                     WHERE PRODUCING_AREA_CODE = P_PRODUCING_AREA_CODE
                       AND ENTITY_ID = P_ENTITY_ID),
                   P_PRODUCING_AREA_CODE,
                   (SELECT PRODUCING_AREA_NAME
                      FROM T_PLN_PRODUCING_AREA
                     WHERE PRODUCING_AREA_CODE = P_PRODUCING_AREA_CODE
                       AND ENTITY_ID = P_ENTITY_ID),
                   B.ITEM_ID,
                   B.ITEM_CODE,
                   B.ITEM_DESC,
                   B.ITEM_UOM,
                   B.ITEM_PRICE,
                   0,
                   P_PRODUCING_AREA_QTY,
                   P_PRODUCING_AREA_QTY,
                   B.ITEM_PRICE * P_PRODUCING_AREA_QTY * (100 - NVL(B.DISCOUNT_RATE, 0)) / 100,
                   B.DISCOUNT_RATE,
                   B.STATUS,
                   B.CAN_SUPPLY_DATE,
                   B.BEGIN_SUPPLY_DATE,
                   B.END_SUPPLY_DATE,
                   B.ADJUST_QTY,
                   P_CREATED_BY,
                   SYSDATE,
                   P_CREATED_BY,
                   SYSDATE
              FROM T_PLN_ORDER_HEAD A, T_PLN_ORDER_LINE B
             WHERE A.ORDER_TYPE_ID = P_ORDER_TYPE_ID
               AND A.PERIOD_ID = P_PERIOD_ID
               AND A.FORM_STATE = 25
               AND A.BATCH_ID = P_BATCH_ID
               AND A.ENTITY_ID = P_ENTITY_ID
               AND A.SALES_CENTER_CODE = P_SALES_CENTER_CODE
               AND B.ORDER_HEAD_ID = A.ORDER_HEAD_ID
               AND B.ITEM_CODE = P_ITEM_CODE
               AND B.APPLY_QTY <> 0;

          INSERT INTO T_PLN_ORDER_COLLECT_RELATION
            (ENTITY_ID,
             RELATION_ID,
             ORDER_LINE_ID,
             COLL_ORD_LINE_ID,
             ORDER_COLLECT_HEAD_ID,
             CREATED_BY,
             CREATION_DATE,
             LAST_UPDATED_BY,
             LAST_UPDATE_DATE)
          VALUES
            (P_ENTITY_ID,
             S_PLN_ORDER_COLLECT_RELATION.NEXTVAL,
             VN_ORDER_LINE_ID,
             V_COLLECT_LINE_ID,
             V_COLLECT_HEAD_ID,
             P_CREATED_BY,
             SYSDATE,
             P_CREATED_BY,
             SYSDATE);
        END IF;
      --周订单行存在
      ELSE
        --月订单（M+1）、月订单（M+2）、月增补订单同一周期可生产量
        SELECT NVL(SUM(B.CAN_PRODUCE_QTY), 0) - NVL(SUM(B.CHECK_ADJUST_QTY), 0)
          INTO VS_CAN_PRODUCE_QTY
          FROM T_PLN_ORDER_HEAD A, T_PLN_ORDER_LINE B
         WHERE A.ORDER_TYPE_ID IN (216, 217, 218)
           AND A.PERIOD_ID =
               (SELECT PERIOD_ID
                  FROM T_PLN_ORDER_PERIOD
                 WHERE SALE_YEAR_YEAR = (SELECT SALE_YEAR_YEAR
                                           FROM T_PLN_ORDER_PERIOD
                                          WHERE PERIOD_ID = P_PERIOD_ID
                                            AND ENTITY_ID = P_ENTITY_ID)
                   AND SALE_YEAR_MONTH = (SELECT SALE_YEAR_MONTH
                                            FROM T_PLN_ORDER_PERIOD
                                           WHERE PERIOD_ID = P_PERIOD_ID
                                             AND ENTITY_ID = P_ENTITY_ID)
                   AND SALE_YEAR_WEEK IS NULL)
           AND A.FORM_STATE = 23
           AND A.ENTITY_ID = P_ENTITY_ID
           AND A.SALES_CENTER_CODE = P_SALES_CENTER_CODE
           AND B.ORDER_HEAD_ID = A.ORDER_HEAD_ID
           AND B.PRODUCING_AREA_CODE = P_PRODUCING_AREA_CODE
           AND B.ITEM_CODE = P_ITEM_CODE;
        --周排产订单四周评审总量
        SELECT NVL(SUM(B.CAN_PRODUCE_QTY), 0) - NVL(SUM(B.CHECK_ADJUST_QTY), 0)
          INTO VS_CHECK_QTY
          FROM T_PLN_ORDER_HEAD A, T_PLN_ORDER_LINE B
         WHERE A.ORDER_TYPE_ID = 220
           AND A.PERIOD_ID IN
               (SELECT PERIOD_ID
                  FROM T_PLN_ORDER_PERIOD
                 WHERE SALE_YEAR_YEAR = (SELECT SALE_YEAR_YEAR
                                           FROM T_PLN_ORDER_PERIOD
                                          WHERE PERIOD_ID = P_PERIOD_ID
                                            AND ENTITY_ID = P_ENTITY_ID)
                   AND SALE_YEAR_MONTH = (SELECT SALE_YEAR_MONTH
                                            FROM T_PLN_ORDER_PERIOD
                                           WHERE PERIOD_ID = P_PERIOD_ID
                                             AND ENTITY_ID = P_ENTITY_ID)
                   AND SALE_YEAR_WEEK <> (SELECT SALE_YEAR_WEEK
                                            FROM T_PLN_ORDER_PERIOD
                                           WHERE PERIOD_ID = P_PERIOD_ID
                                             AND ENTITY_ID = P_ENTITY_ID)
                   AND SALE_YEAR_WEEK IS NOT NULL)
           AND A.FORM_STATE = 32
           AND A.ENTITY_ID = P_ENTITY_ID
           AND A.SALES_CENTER_CODE = P_SALES_CENTER_CODE
           AND B.ORDER_HEAD_ID = A.ORDER_HEAD_ID
           AND B.PRODUCING_AREA_CODE = P_PRODUCING_AREA_CODE
           AND B.ITEM_CODE = P_ITEM_CODE;

        IF VS_CAN_PRODUCE_QTY - VS_CHECK_QTY - P_PRODUCING_AREA_QTY < 0 THEN
          SELECT PRODUCING_AREA_NAME
            INTO VS_PRODUCING_AREA_NAME
            FROM T_PLN_PRODUCING_AREA
           WHERE PRODUCING_AREA_CODE = P_PRODUCING_AREA_CODE
             AND ENTITY_ID = P_ENTITY_ID;

          P_RESULT := '产地：' || P_PRODUCING_AREA_CODE || ' ' || VS_PRODUCING_AREA_NAME || '，排产量超过月订单可生产量。';
          RETURN;
        ELSE
          UPDATE T_PLN_ORDER_LINE
             SET CHECK_QTY = P_PRODUCING_AREA_QTY,
                 CAN_PRODUCE_QTY = P_PRODUCING_AREA_QTY
           WHERE ORDER_HEAD_ID =
                   (SELECT A.ORDER_HEAD_ID
                      FROM T_PLN_ORDER_HEAD A
                     WHERE A.ORDER_TYPE_ID = P_ORDER_TYPE_ID
                       AND A.PERIOD_ID = P_PERIOD_ID
                       AND A.FORM_STATE = 25
                       AND A.BATCH_ID = P_BATCH_ID
                       AND A.ENTITY_ID = P_ENTITY_ID
                       AND A.SALES_CENTER_CODE = P_SALES_CENTER_CODE)
             AND ITEM_CODE = P_ITEM_CODE
             AND PRODUCING_AREA_CODE = P_PRODUCING_AREA_CODE;
        END IF;
      END IF;

    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      P_RESULT := '校验周排产订单销司产地信息和排产量失败。' || V_NL || '失败信息：' || SQLERRM;
      ROLLBACK;
  END;

  ----------------------------------------------------------------------
  -- Author  : fenggq
  -- Created : 2014-12-17 14:57:00
  -- Purpose : 获取销司产品最优产地
  ----------------------------------------------------------------------
  PROCEDURE P_GET_SC_ITEM_OPTIMAL_PA(P_SALES_CENTER_ID   IN VARCHAR2, --营销中心ID
                                     P_ITEM_ID           IN VARCHAR2, --产品ID
                                     P_ENTITY_ID         IN NUMBER,   --主体ID
                                     P_RESULT            OUT VARCHAR2,
                                     P_PRODUCING_AREA_ID OUT VARCHAR2) IS

    VN_PRODUCING_AREA_ID T_PLN_ITEM_PRODUCING_AREA.PRODUCING_AREA_ID%TYPE;
    VS_ITEM_CODE         T_PLN_ORDER_LINE.ITEM_CODE%TYPE;
    VS_ITEM_NAME         T_PLN_ORDER_LINE.ITEM_DESC%TYPE;

  BEGIN
    P_RESULT := V_SUCCESS;
    P_PRODUCING_AREA_ID := 0;

    BEGIN
      SELECT ITEM_CODE
        INTO VS_ITEM_CODE
        FROM T_BD_ITEM
       WHERE ITEM_ID = P_ITEM_ID
         AND ENTITY_ID = P_ENTITY_ID;

      SELECT ITEM_NAME
        INTO VS_ITEM_NAME
        FROM T_BD_ITEM
       WHERE ITEM_ID = P_ITEM_ID
         AND ENTITY_ID = P_ENTITY_ID;

      Select Producing_Area_Id
        Into VN_PRODUCING_AREA_ID
        From (Select a.Producing_Area_Id,
                     Nvl(Pc.Priority, 999) * 100 + a.Producing_Area_Priority Priority
                From t_Pln_Item_Producing_Area a,
                     t_Pln_Producing_Area Pa,
                     (Select Rownum Priority,
                             a.Sales_Center_Id,
                             a.Producing_Area_Id,
                             a.Entity_Id
                        From (Select *
                                From (Select t.Sales_Center_Id,
                                             t.Producing_Area_Id,
                                             t.Entity_Id,
                                             t.Cost_Price,
                                             Rank() Over(Partition By t.Sales_Center_Id Order By t.Producing_Area_Priority) Priority
                                        From t_Pln_Customer_Priority t
                                       Where t.Sales_Center_Id = P_SALES_CENTER_ID
                                         And t.Item_Id = P_ITEM_ID
                                      Union All
                                      Select t.Sales_Center_Id,
                                             t.Producing_Area_Id,
                                             t.Entity_Id,
                                             Null Cost_Price,
                                             Rank() Over(Partition By t.Sales_Center_Id Order By t.Producing_Area_Priority) Priority
                                        From t_Pln_Customer_Priority t
                                       Where t.Sales_Center_Id = P_SALES_CENTER_ID
                                         And t.item_id Is Null
                                      /*And Not Exists
                                      (Select 1
                                               From t_Pln_Customer_Priority Pcp
                                              Where Pcp.Sales_Center_Id =
                                                    t.Sales_Center_Id
                                                And Pcp.Producing_Area_Id =
                                                    t.Producing_Area_Id
                                                And Pcp.Item_Id =
                                                    C1.Item_Id)*/
                                      )
                               Order By Cost_Price, Priority) a) Pc
               Where Pa.Entity_Id = a.Entity_Id
                 And Pa.Producing_Area_Id = a.Producing_Area_Id
                 And Pc.Sales_Center_Id(+) = P_SALES_CENTER_ID
                 And Pc.Entity_Id(+) = P_ENTITY_ID
                 And Pc.Producing_Area_Id(+) = a.Producing_Area_Id
                 And a.Entity_Id = P_ENTITY_ID
                 And a.Item_Id = P_ITEM_ID
                 And Trunc(Sysdate) Between Trunc(a.Begin_Date) And
                     Trunc(Nvl(a.End_Date, Sysdate))
                 And Trunc(Sysdate) Between Trunc(Pa.Begin_Date) And
                     Trunc(Nvl(Pa.End_Date, Sysdate))
                 AND ROWNUM = 1
               Order By Nvl(Pc.Priority, 999) * 100 + a.Producing_Area_Priority);

    EXCEPTION
      WHEN OTHERS THEN
      P_RESULT := '产品：' || VS_ITEM_CODE || ' ' || VS_ITEM_NAME || '，在T_PLN_CUSTOMER_PRIORITY（中心供货优先级）没有维护产地；' || V_NL || '或在T_PLN_ITEM_PRODUCING_AREA（产地-产品关系维护）没有维护产地。' || V_NL ;
      RETURN;
    END;

    P_PRODUCING_AREA_ID := VN_PRODUCING_AREA_ID;

  EXCEPTION
    WHEN OTHERS THEN
      P_RESULT := '获取销司产品最优产地失败。' || V_NL || '失败信息：' || SQLERRM;
      ROLLBACK;
  END;

  ----------------------------------------------------------------------
  -- Author  : fenggq
  -- Created : 2014-12-19 16:48:00
  -- Purpose : 订单行转换区域辐射信息
  ----------------------------------------------------------------------
  PROCEDURE P_ORDER_CHANGE_AREA_INFO(P_ORDER_TYPE_ID IN NUMBER,   --订单类型ID
                                     P_PERIOD_ID     IN NUMBER,   --订单周期ID
                                     P_BATCH_ID      IN NUMBER,   --批次ID
                                     P_ENTITY_ID     IN NUMBER,   --主体ID
                                     P_CREATED_BY    IN VARCHAR2, --创建人
                                     P_RESULT        OUT VARCHAR2) IS

    VS_PRODUCING_AREA_1ST T_PLN_SALES_CENTER_PA.PRODUCING_AREA_CODE_1ST%TYPE; --第一产地
    VS_PRODUCING_AREA_2ND T_PLN_SALES_CENTER_PA.PRODUCING_AREA_CODE_2ND%TYPE; --第二产地

    VS_PRODUCING_AREA1 VARCHAR2(10);
    VS_PRODUCING_AREA2 VARCHAR2(10);
    VS_PRODUCING_AREA3 VARCHAR2(10);
    VS_PRODUCING_AREA4 VARCHAR2(10);
    VS_PRODUCING_AREA5 VARCHAR2(10);
    VS_PRODUCING_AREA6 VARCHAR2(10);
    VS_PRODUCING_AREA7 VARCHAR2(10);

    VS_NAME            VARCHAR2(20);
    UPDATESQL          VARCHAR2(2000);

  BEGIN
    P_RESULT := V_SUCCESS;

    VS_PRODUCING_AREA1 := 'A0001';
    VS_PRODUCING_AREA2 := 'A0002';
    VS_PRODUCING_AREA3 := 'A0003';
    VS_PRODUCING_AREA4 := 'A0004';
    VS_PRODUCING_AREA5 := 'A0005';
    VS_PRODUCING_AREA6 := 'A0006';
    VS_PRODUCING_AREA7 := 'A0007';

    DELETE FROM T_PLN_SALES_CENTER_PA
     WHERE ORDER_TYPE_ID = P_ORDER_TYPE_ID
       AND PERIOD_ID = P_PERIOD_ID
       AND ENTITY_ID = P_ENTITY_ID
       AND TYPE_FLAG = 1;

    FOR C_PLN_SC_ITEM IN (SELECT A.SALES_CENTER_CODE, B.ITEM_CODE
                            FROM T_PLN_ORDER_HEAD A, T_PLN_ORDER_LINE B
                           WHERE A.ORDER_TYPE_ID = P_ORDER_TYPE_ID
                             AND A.PERIOD_ID = P_PERIOD_ID
                             AND A.FORM_STATE = 25
                             AND A.BATCH_ID = P_BATCH_ID
                             AND A.ENTITY_ID = P_ENTITY_ID
                             AND B.ORDER_HEAD_ID = A.ORDER_HEAD_ID
                             AND B.APPLY_QTY <> 0) LOOP
      --取第一产地，产品在中心优先级表中没有配置
      FOR C_PRODUCING_AREA_PRIORITY IN (SELECT PRODUCING_AREA_PRIORITY
                                          FROM T_PLN_CUSTOMER_PRIORITY
                                         WHERE SALES_CENTER_CODE = C_PLN_SC_ITEM.SALES_CENTER_CODE
                                           AND ITEM_CODE IS NULL
                                           AND ENTITY_ID = P_ENTITY_ID
                                         ORDER BY PRODUCING_AREA_PRIORITY) LOOP
        BEGIN
          VS_PRODUCING_AREA_1ST := '-1';
          SELECT A.PRODUCING_AREA_CODE
            INTO VS_PRODUCING_AREA_1ST
            FROM T_PLN_CUSTOMER_PRIORITY A--, T_PLN_ITEM_PRODUCING_AREA B
           WHERE A.SALES_CENTER_CODE = C_PLN_SC_ITEM.SALES_CENTER_CODE
             AND A.ITEM_CODE IS NULL
             AND A.PRODUCING_AREA_PRIORITY = C_PRODUCING_AREA_PRIORITY.PRODUCING_AREA_PRIORITY
             AND A.ENTITY_ID = P_ENTITY_ID;
             --AND B.ITEM_CODE = C_PLN_SC_ITEM.ITEM_CODE --判断产品在VS_PRODUCING_AREA_1ST产地是否生产
             --AND B.PRODUCING_AREA_CODE = A.PRODUCING_AREA_CODE;
        EXCEPTION
          WHEN OTHERS THEN
          NULL;
        END;

        IF VS_PRODUCING_AREA_1ST <> '-1' THEN
          EXIT;
        END IF;
      END LOOP;

      --取第二产地，产品在中心优先级表中没有配置
      FOR C_PRODUCING_AREA_PRIORITY2 IN (SELECT PRODUCING_AREA_PRIORITY
                                           FROM T_PLN_CUSTOMER_PRIORITY
                                          WHERE SALES_CENTER_CODE = C_PLN_SC_ITEM.SALES_CENTER_CODE
                                            AND ITEM_CODE IS NULL
                                            AND PRODUCING_AREA_CODE <> VS_PRODUCING_AREA_1ST
                                            AND ENTITY_ID = P_ENTITY_ID
                                          ORDER BY PRODUCING_AREA_PRIORITY) LOOP
        BEGIN
          VS_PRODUCING_AREA_2ND := '-1';
          SELECT A.PRODUCING_AREA_CODE
            INTO VS_PRODUCING_AREA_2ND
            FROM T_PLN_CUSTOMER_PRIORITY A--, T_PLN_ITEM_PRODUCING_AREA B
           WHERE A.SALES_CENTER_CODE = C_PLN_SC_ITEM.SALES_CENTER_CODE
             AND A.ITEM_CODE IS NULL
           AND A.PRODUCING_AREA_CODE <> VS_PRODUCING_AREA_1ST
             AND A.PRODUCING_AREA_PRIORITY = C_PRODUCING_AREA_PRIORITY2.PRODUCING_AREA_PRIORITY
             AND A.ENTITY_ID = P_ENTITY_ID;
             --AND B.ITEM_CODE = C_PLN_SC_ITEM.ITEM_CODE --判断产品在VS_PRODUCING_AREA_1ST产地是否生产
             --AND B.PRODUCING_AREA_CODE = A.PRODUCING_AREA_CODE;
        EXCEPTION
          WHEN OTHERS THEN
          NULL;
        END;

        IF VS_PRODUCING_AREA_2ND <> '-1' THEN
          EXIT;
        END IF;
      END LOOP;

      --插入销司产地表
      INSERT INTO T_PLN_SALES_CENTER_PA
        (SALES_CENTER_PA_ID,
         ENTITY_ID,
         ORDER_TYPE_ID,
         PERIOD_ID,
         ITEM_CODE,
         SALES_CENTER_CODE,
         SALES_CENTER_NAME,
         PRODUCING_AREA_CODE_1ST,
         --PRODUCING_AREA_CODE_2ND,
         APPLY_QTY,
         INV_AFFIRM_QTY,
         CHECK_QTY,
         CREATED_BY,
         CREATION_DATE,
         LAST_UPDATED_BY,
         LAST_UPDATE_DATE,
         ITEM_NAME,
         TYPE_FLAG,
         PRE_FIELD_01)
        SELECT S_PLN_SALES_CENTER_PA.NEXTVAL,
               P_ENTITY_ID,
               P_ORDER_TYPE_ID,
               P_PERIOD_ID,
               T.ITEM_CODE,
               T.SALES_CENTER_CODE,
               T.SALES_CENTER_NAME,
               VS_PRODUCING_AREA_1ST,
               T.APPLY_COLLECT_QTY,
               T.INV_AFFIRM_COLLECT_QTY,
               T.CHECK_COLLECT_QTY,
               P_CREATED_BY,
               SYSDATE,
               P_CREATED_BY,
               SYSDATE,
               T.ITEM_DESC,
               '1',
               T.ORDER_NUMBER
          FROM (SELECT B.ITEM_CODE,
                       A.SALES_CENTER_CODE,
                       A.SALES_CENTER_NAME,
                       SUM(APPLY_QTY) APPLY_COLLECT_QTY,
                       SUM(INV_AFFIRM_QTY) INV_AFFIRM_COLLECT_QTY,
                       SUM(CHECK_QTY) CHECK_COLLECT_QTY,
                       B.ITEM_DESC,
                       A.ORDER_NUMBER
                  FROM T_PLN_ORDER_HEAD A, T_PLN_ORDER_LINE B
                 WHERE A.ORDER_TYPE_ID = P_ORDER_TYPE_ID
                   AND A.PERIOD_ID = P_PERIOD_ID
                   AND A.FORM_STATE = 25
                   AND A.BATCH_ID = P_BATCH_ID
                   AND A.ENTITY_ID = P_ENTITY_ID
                   AND A.SALES_CENTER_CODE = C_PLN_SC_ITEM.SALES_CENTER_CODE
                   AND B.ORDER_HEAD_ID = A.ORDER_HEAD_ID
                   AND B.ITEM_CODE = C_PLN_SC_ITEM.ITEM_CODE
                 GROUP BY B.ITEM_CODE, B.ITEM_DESC, A.SALES_CENTER_CODE, A.SALES_CENTER_NAME, A.ORDER_NUMBER) T;

      IF VS_PRODUCING_AREA_2ND <> '-1' THEN
        UPDATE T_PLN_SALES_CENTER_PA
           SET PRODUCING_AREA_CODE_2ND = VS_PRODUCING_AREA_2ND
         WHERE ORDER_TYPE_ID = P_ORDER_TYPE_ID
           AND PERIOD_ID = P_PERIOD_ID
           AND ENTITY_ID = P_ENTITY_ID
           AND ITEM_CODE = C_PLN_SC_ITEM.ITEM_CODE
           AND SALES_CENTER_CODE = C_PLN_SC_ITEM.SALES_CENTER_CODE;
      END IF;

      FOR C_PLN_PRODUCING_AREA IN (SELECT A.ORDER_NUMBER, B.PRODUCING_AREA_CODE, B.CHECK_QTY, C.PRO_SORT
                                     FROM T_PLN_ORDER_HEAD A, T_PLN_ORDER_LINE B, T_PLN_PRODUCING_AREA C
                                    WHERE A.ORDER_TYPE_ID = P_ORDER_TYPE_ID
                                      AND A.PERIOD_ID = P_PERIOD_ID
                                      AND A.FORM_STATE = 25
                                      AND A.BATCH_ID = P_BATCH_ID
                                      AND A.ENTITY_ID = P_ENTITY_ID
                                      AND A.SALES_CENTER_CODE = C_PLN_SC_ITEM.SALES_CENTER_CODE
                                      AND B.ORDER_HEAD_ID = A.ORDER_HEAD_ID
                                      AND B.ITEM_CODE = C_PLN_SC_ITEM.ITEM_CODE
                                      AND B.PRODUCING_AREA_CODE = C.PRODUCING_AREA_CODE) LOOP
        /*IF C_PLN_PRODUCING_AREA.PRODUCING_AREA_CODE = VS_PRODUCING_AREA1 THEN
          VS_NAME := 'PRODUCING_AREA1_QTY';
        ELSIF C_PLN_PRODUCING_AREA.PRODUCING_AREA_CODE = VS_PRODUCING_AREA2 THEN
          VS_NAME := 'PRODUCING_AREA2_QTY';
        ELSIF C_PLN_PRODUCING_AREA.PRODUCING_AREA_CODE = VS_PRODUCING_AREA3 THEN
          VS_NAME := 'PRODUCING_AREA3_QTY';
        ELSIF C_PLN_PRODUCING_AREA.PRODUCING_AREA_CODE = VS_PRODUCING_AREA4 THEN
          VS_NAME := 'PRODUCING_AREA4_QTY';
        ELSIF C_PLN_PRODUCING_AREA.PRODUCING_AREA_CODE = VS_PRODUCING_AREA5 THEN
          VS_NAME := 'PRODUCING_AREA5_QTY';
        ELSIF C_PLN_PRODUCING_AREA.PRODUCING_AREA_CODE = VS_PRODUCING_AREA6 THEN
          VS_NAME := 'PRODUCING_AREA6_QTY';
        ELSIF C_PLN_PRODUCING_AREA.PRODUCING_AREA_CODE = VS_PRODUCING_AREA7 THEN
          VS_NAME := 'PRODUCING_AREA7_QTY';
        END IF;*/

        VS_NAME := 'REVIEW_QTY_' || LPAD(C_PLN_PRODUCING_AREA.PRO_SORT, 2, 0);

        UPDATESQL := ' UPDATE T_PLN_SALES_CENTER_PA SET ' || VS_NAME || ' = ' || C_PLN_PRODUCING_AREA.CHECK_QTY
          || ' WHERE ORDER_TYPE_ID =     ' || P_ORDER_TYPE_ID
          || ' AND   PERIOD_ID =         ' || P_PERIOD_ID
          || ' AND   ENTITY_ID =         ' || P_ENTITY_ID
          || ' AND   ITEM_CODE =         ' || '''' || C_PLN_SC_ITEM.ITEM_CODE || ''''
          || ' AND   SALES_CENTER_CODE = ' || '''' || C_PLN_SC_ITEM.SALES_CENTER_CODE || ''''
          || ' AND   PRE_FIELD_01 =      ' || '''' || C_PLN_PRODUCING_AREA.ORDER_NUMBER || ''''
          || ' AND   TYPE_FLAG =         ' || '''' || 1 || '''';
        EXECUTE IMMEDIATE UPDATESQL;
      END LOOP;
    END LOOP;

  EXCEPTION
    WHEN OTHERS THEN
      P_RESULT := '订单行转换区域辐射信息失败。' || V_NL || '失败信息：' || SQLERRM;
      ROLLBACK;
  END;

  ----------------------------------------------------------------------
  -- Author  : fenggq
  -- Created : 2015-03-12 10:17:00
  -- Purpose : 更新销售公司成本关系表
  ----------------------------------------------------------------------
  PROCEDURE P_UPDATE_CENTER_COST_RELATION(P_ENTITY_ID     IN NUMBER,   --主体ID
                                          P_CREATED_BY    IN VARCHAR2, --创建人
                                          P_RESULT        OUT VARCHAR2) IS

  BEGIN
    P_RESULT := V_SUCCESS;

    --删除销售公司成本关系表比组织单元表多的销售公司
    DELETE FROM T_PLN_CENTER_COST_RELATION CCR
     WHERE CCR.SALES_CENTER_CODE IN
           (SELECT CCR.SALES_CENTER_CODE
              FROM T_PLN_CENTER_COST_RELATION CCR
             WHERE CCR.SALES_CENTER_CODE NOT IN
                   (SELECT OU.CODE
                      FROM UP_ORG_UNIT OU
                     WHERE OU.ENTITY_ID = P_ENTITY_ID
                       AND OU.TYPE_CODE = 'SC'
                       AND OU.CODE NOT IN ('1013914084',
                                           '2764361681-1',
                                           '5550246442',
                                           '5550192986-1',
                                           '5550192986-2',
                                           '5550192986-3',
                                           '5550192986-4')));

    FOR C_OU_SC_INFO IN (SELECT OU.UNIT_ID, OU.CODE, OU.NAME
                           FROM UP_ORG_UNIT OU
                          WHERE OU.ENTITY_ID = P_ENTITY_ID
                            AND OU.TYPE_CODE = 'SC'
                            AND OU.CODE NOT IN ('1013914084',
                                                '2764361681-1',
                                                '5550246442',
                                                '5550192986-1',
                                                '5550192986-2',
                                                '5550192986-3',
                                                '5550192986-4')
                            AND OU.CODE NOT IN
                                (SELECT CCR.SALES_CENTER_CODE FROM T_PLN_CENTER_COST_RELATION CCR)) LOOP

      --插入销售公司成本关系表
      INSERT INTO T_PLN_CENTER_COST_RELATION
        (CENTER_COST_RELATION_ID,
         ENTITY_ID,
         SALES_CENTER_ID,
         SALES_CENTER_CODE,
         SALES_CENTER_NAME,
         COST_FLAG,
         CREATED_BY,
         CREATION_DATE,
         LAST_UPDATED_BY,
         LAST_UPDATE_DATE)
        VALUES(S_PLN_CENTER_COST_RELATION.NEXTVAL,
               P_ENTITY_ID,
               C_OU_SC_INFO.UNIT_ID,
               C_OU_SC_INFO.CODE,
               C_OU_SC_INFO.NAME,
               '0',
               P_CREATED_BY,
               SYSDATE,
               P_CREATED_BY,
               SYSDATE);
    END LOOP;

  EXCEPTION
    WHEN OTHERS THEN
      P_RESULT := '更新销售公司成本关系表失败。' || V_NL || '失败信息：' || SQLERRM;
      ROLLBACK;
  END;
  
  ----------------------------------------------------------------------
  -- Author  : 何加源
  -- Created : 2015-11-25
  -- Purpose : 提货订单调整后更新销司产地数据
  ----------------------------------------------------------------------
  PROCEDURE P_UPDATE_SALES_CENTER_PA(P_SALES_PA_ID   IN NUMBER, --销司产地ID
                                     P_ENTITY_ID     IN NUMBER,   --主体ID
                                     P_USER_CODE     IN VARCHAR2, --创建人
                                     P_RESULT        OUT VARCHAR2)
  IS
    R_SALES_CENTER_PA T_PLN_SALES_CENTER_PA%ROWTYPE;
    V_SQL VARCHAR2(4000);
    V_LG_PLN_CHK_QTY NUMBER; --提货订单计划评审数量
    V_INDEX NUMBER;
    V_COUNT NUMBER;
    VS_ITEM_LIFE_CYCLE T_BD_PARAM_LIST.DEFAULT_VALUE%TYPE;
  BEGIN
    P_RESULT := V_SUCCESS;
    
    BEGIN
      VS_ITEM_LIFE_CYCLE := PKG_BD.F_GET_PARAMETER_VALUE('PLN_ITEM_LIFE_CYCLE', P_ENTITY_ID);
    EXCEPTION
      WHEN OTHERS THEN
        P_RESULT := '获取PLN_ITEM_LIFE_CYCLE参数失败' || V_NL || SQLERRM;
        RAISE V_BASE_EXCEPTION;
    END;
    
    --获取销司产地数据
    SELECT *
      INTO R_SALES_CENTER_PA
      FROM T_PLN_SALES_CENTER_PA P
     WHERE P.SALES_CENTER_PA_ID = P_SALES_PA_ID;
    
    V_INDEX := 0;
    --循环主体产地
    FOR RPA IN (SELECT * FROM T_PLN_PRODUCING_AREA A
                 WHERE A.ENTITY_ID = P_ENTITY_ID
                   AND TRUNC(SYSDATE) BETWEEN A.BEGIN_DATE AND TRUNC(NVL(A.END_DATE, SYSDATE + 1))
                 ORDER BY A.PRO_SORT) LOOP
      V_INDEX := V_INDEX + 1;
      BEGIN
        --按产地获取提货订单计划评审数量
        SELECT NVL(SUM(L.PLN_CHK_ADJUST_QTY), 0)
          INTO V_LG_PLN_CHK_QTY
          FROM T_PLN_LG_ORDER_LINE L
         WHERE L.ENTITY_ID = P_ENTITY_ID
           AND L.PLN_CHK_PRO_AREA = RPA.PRODUCING_AREA_NAME
           AND EXISTS (SELECT 1 FROM T_PLN_LG_RELATION R, T_PLN_ORDER_LINE OL
                        WHERE R.LG_ORDER_LINE_ID = L.ORDER_LINE_ID
                          AND R.ORDER_LINE_ID = OL.ORDER_LINE_ID
                          AND OL.ORDER_HEAD_ID = R_SALES_CENTER_PA.ORDER_HEAD_ID
                          AND OL.ITEM_CODE = R_SALES_CENTER_PA.ITEM_CODE);
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          V_LG_PLN_CHK_QTY := 0;
      END;
     
      IF V_LG_PLN_CHK_QTY > 0 THEN
        --检查产品产地关系
        BEGIN
          SELECT COUNT(1) INTO V_COUNT
            FROM CIMS.T_PLN_ITEM_PRODUCING_AREA A
           WHERE A.PRODUCING_AREA_ID = RPA.PRODUCING_AREA_ID
             AND A.ITEM_CODE = R_SALES_CENTER_PA.ITEM_CODE
             AND A.ENTITY_ID = P_ENTITY_ID
             AND TRUNC(SYSDATE) BETWEEN A.BEGIN_DATE AND NVL(A.END_DATE, SYSDATE + 1);
          
          IF V_COUNT = 0 THEN
            P_RESULT := '无效产品产地优先级关系!' || V_NL ||
                        '产地名称：' || RPA.PRODUCING_AREA_NAME || '，产品编码：' || R_SALES_CENTER_PA.ITEM_CODE;
            RAISE V_BASE_EXCEPTION;
          END IF;
        END;
        
        --检查产品生命周期
        IF VS_ITEM_LIFE_CYCLE = 'Y' THEN
          BEGIN
            SELECT COUNT(1) INTO V_COUNT
              FROM T_PLN_ITEM_LIFE_CYCLE CY, T_PLN_ITEM_PRODUCING_AREA PA
             WHERE CY.ENTITY_ID = PA.ENTITY_ID
               AND CY.ENTITY_ID = P_ENTITY_ID
               AND PA.STATE = CY.SYSTEM_STATUS
               AND NVL(CY.IS_APS_FLAG, 'N') = 'Y'
               AND PA.Item_Code = R_SALES_CENTER_PA.ITEM_CODE
               AND PA.PRODUCING_AREA_ID = RPA.PRODUCING_AREA_ID
               AND (TRUNC(SYSDATE) BETWEEN PA.BEGIN_DATE AND
                   NVL(PA.END_DATE, TRUNC(SYSDATE)));
          EXCEPTION
            WHEN OTHERS THEN
              P_RESULT := '获取产品产地生命周期失败!' || V_NL || SQLERRM;
              RAISE V_BASE_EXCEPTION;
          END;
          IF NVL(V_COUNT, 0) = 0 THEN
            P_RESULT := '产品在生命周期内无法引入APS!' || V_NL ||
                        '产地名称: ' || RPA.PRODUCING_AREA_NAME || '，产品编码: ' || R_SALES_CENTER_PA.ITEM_CODE;
            RAISE V_BASE_EXCEPTION;
          END IF;
        END IF;
      END IF;
      
      --更新对应产地评审数量字段
      V_SQL := 'UPDATE T_PLN_SALES_CENTER_PA P' ||
               '   SET P.REVIEW_QTY_' || LPAD(TO_CHAR(V_INDEX), 2, '0') || ' = ' || TO_CHAR(V_LG_PLN_CHK_QTY) ||
               ' WHERE P.SALES_CENTER_PA_ID = ' || TO_CHAR(P_SALES_PA_ID);
      
      EXECUTE IMMEDIATE V_SQL;
    END LOOP;
  EXCEPTION
    WHEN V_BASE_EXCEPTION THEN
      ROLLBACK;
      P_RESULT := '更新销司产地数据表失败！' || V_NL || P_RESULT;
    WHEN OTHERS THEN
      ROLLBACK;
      P_RESULT := '更新销司产地数据表失败。' || V_NL || '失败信息：' || SQLERRM;
  END;
  
  ----------------------------------------------------------------------
  -- Author  : 何加源
  -- Created : 2015-11-25
  -- Purpose : 提货订单调整前更新相关数量
  ----------------------------------------------------------------------
  PROCEDURE P_UPD_PLN_LG_LINE_QTY(P_SALES_PA_ID   IN NUMBER, --销司产地ID
                                  P_ENTITY_ID     IN NUMBER,   --主体ID
                                  P_USER_CODE    IN VARCHAR2, --创建人
                                  P_RESULT        OUT VARCHAR2)
  IS
    R_SALES_CENTER_PA T_PLN_SALES_CENTER_PA%ROWTYPE;
    V_LG_REMAIN_QTY NUMBER;
    V_CURR_QTY NUMBER;
  BEGIN
    P_RESULT := V_SUCCESS;
    
    SELECT P.* INTO R_SALES_CENTER_PA
      FROM T_PLN_SALES_CENTER_PA P
     WHERE P.SALES_CENTER_PA_ID = P_SALES_PA_ID;
    
    V_LG_REMAIN_QTY := NVL(R_SALES_CENTER_PA.INV_AFFIRM_QTY, 0);
    
    FOR RL IN (
      SELECT LGH.ORDER_NUMBER,
             LGH.ORDER_TYPE_NAME,
             LGH.SALES_CENTER_NAME,
             LGH.CUSTOMER_NAME,
             LGH.AGENT_CUSTOMER_NAME,
             LGH.SALES_MAIN_TYPE,
             LGL.ITEM_CODE,
             LGL.ITEM_NAME,
             LGL.PRODUCING_AREA_NAME,
             LGL.PLN_CHK_PRO_AREA,
             LGL.ORDER_LINE_ID,
             --R.RELATION_ID,
             LGL.TO_PLN_QTY,
             LGL.PRE_FIELD_05,
             LGL.PLN_CHK_ADJUST_QTY
        FROM T_PLN_LG_ORDER_HEAD LGH,
             T_PLN_LG_ORDER_LINE LGL/*,
             T_PLN_LG_RELATION   R,
             T_PLN_ORDER_HEAD    OH,
             T_PLN_ORDER_LINE    OL*/
       WHERE LGH.ORDER_HEAD_ID = LGL.ORDER_HEAD_ID
         /*AND OL.ORDER_HEAD_ID = OH.ORDER_HEAD_ID
         AND OL.ORDER_LINE_ID = R.ORDER_LINE_ID
         AND R.LG_ORDER_LINE_ID = LGL.ORDER_LINE_ID
         AND OH.ORDER_HEAD_ID = R_SALES_CENTER_PA.ORDER_HEAD_ID
         AND OL.ITEM_CODE = R_SALES_CENTER_PA.ITEM_CODE
         AND OH.ENTITY_ID = P_ENTITY_ID*/
         AND NVL(LGL.PRE_FIELD_06, '_') <> TO_CHAR(P_SALES_PA_ID)
         AND EXISTS (SELECT 1
                       FROM T_PLN_LG_RELATION R,
                            T_PLN_ORDER_HEAD OH,
                            T_PLN_ORDER_LINE OL
                      WHERE R.LG_ORDER_LINE_ID = LGL.ORDER_LINE_ID
                        AND R.ORDER_LINE_ID = OL.ORDER_LINE_ID
                        AND OL.ORDER_HEAD_ID = OH.ORDER_HEAD_ID
                        AND OH.ORDER_HEAD_ID = R_SALES_CENTER_PA.ORDER_HEAD_ID
                        AND OL.ITEM_CODE = R_SALES_CENTER_PA.ITEM_CODE
                        AND OH.ENTITY_ID = P_ENTITY_ID)
       ORDER BY LGH.TO_CHECKUP_DATE, LGL.TO_PLN_QTY DESC
      )
    LOOP
      IF NVL(RL.TO_PLN_QTY, 0) <= V_LG_REMAIN_QTY THEN
        V_CURR_QTY := NVL(RL.TO_PLN_QTY, 0);
      ELSE
        V_CURR_QTY := V_LG_REMAIN_QTY;
      END IF;
      V_LG_REMAIN_QTY := V_LG_REMAIN_QTY - V_CURR_QTY;
      
      UPDATE T_PLN_LG_ORDER_LINE L
         SET L.PLN_CHK_PRO_AREA   = L.PRODUCING_AREA_NAME,
             L.PRE_FIELD_05 = TO_CHAR(V_CURR_QTY),
             L.PLN_CHK_ADJUST_QTY = L.PLN_CHK_QTY - V_CURR_QTY
       WHERE EXISTS (SELECT 1
                FROM T_PLN_LG_RELATION R, T_PLN_ORDER_LINE OL
               WHERE R.LG_ORDER_LINE_ID = L.ORDER_LINE_ID
                 AND R.ORDER_LINE_ID = OL.ORDER_LINE_ID
                 AND OL.ORDER_HEAD_ID = R_SALES_CENTER_PA.ORDER_HEAD_ID
                 AND OL.ITEM_CODE = R_SALES_CENTER_PA.ITEM_CODE)
         AND NVL(L.PRE_FIELD_06, '_') <> TO_CHAR(P_SALES_PA_ID)
         AND L.ORDER_LINE_ID = RL.ORDER_LINE_ID;
    END LOOP;
  EXCEPTION
    WHEN V_BASE_EXCEPTION THEN
      ROLLBACK;
      P_RESULT := '更新销司产地数据表失败！' || V_NL || P_RESULT;
    WHEN OTHERS THEN
      ROLLBACK;
      P_RESULT := '更新销司产地数据表失败。' || V_NL || '失败信息：' || SQLERRM;
  END;

END PKG_PLN_PRODUCING_AREA_ALLOT;
/

